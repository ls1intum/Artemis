# Simpler IO Test


Diese Aufgabe ist weniger ein Test für Studenten sondern soll eine Infrastruktur für das schnelle Erstellen von IO-Tests bereitstellen.

Im Gegensatz zu JUnit-Tests sollen IO-Tests eine Abfolge von Programm-Eingaben und eine dazu passende Abfolge von Ausgaben geprüft werden.

### Aufgabenstellung

Schreiben Sie ein einfaches Programm, dass von der Kommandozeile jeweils eine Zahl $$ n $$ 
 einliest, und dann die Ausgabe "Hello World" (ohne Anführungszeichen) $$ n $$-mal in jeweils einer eigenen Zeile ausgegeben wird.
Bei der Eingabe von 0 soll das Programm terminieren. Eine Beispiel-Ein/Ausgabe ist z.B.

Beispiel (-> bezeichnet eine Ausgabe, -> eine Eingabe, sind aber nicht selbst in der Ein-Ausgabe enthalten)
```
-> 3
<- Hello World
<- Hello World
<- Hello World
-> 1
<- Hello World
-> 0
```

Das Java-Programm soll in der Klasse at.ac.uibk.qe.artemis.iotest.HelloWorld durch eine main-Methode realisiert werden.

1. [task][Aufgabe: Zeilenbasiert](testClass[HelloWorld],testMethods[HelloWorld],runIOTest[erster IOTest],runIOTest[zweiter IOTest],runIOTest[sofortiger Abbruch]){}

Schreiben Sie ein HelloWorld Programm wie oben angegeben.

2. [task][Aufgabe: ohne Zeilenenden](runIOTest[IOTest1 2. Teil],runIOTest[IOTest2 2. Teil],runIOTest[IOTest2 ohne Pattern 2. Teil])

Erweitern Sie Ihr Programm:

Wird eine negative Zahl eingegeben so ändert sich das Verhalten des Programms wie folgt:

1. Es wird eine Eingabeaufforderung ausgegeben: "Bitte geben Sie eine Zahl ein: " (**ohne Zeilenende**)
2. Es wird anschliessend auf die Eingabe einer Zahl n gewartet.
3. Ist n <= 0 terminiert das Programm. Falls n>0 erfolgt die Ausgabe von n Strings "Hello World" (**ohne Zeilenende**). 
4. Anschliessend geht es wieder mit Schritt 1 weiter.

Beispiel (**->** bezeichnet eine Ausgabe, **->** eine Eingabe, diese Zeichen sind aber nicht selbst in der Ein-Ausgabe enthalten)
```
-> 3
<- Hello World
<- Hello World
<- Hello World
-> -1
<- Bitte geben Sie eine Zahl ein: -> 3 <-Hello World<-Hello World<-Hello World<-Bitte geben Sie eine Zahl ein: -> 0 
```





# Hinweise für die Verwendung:

Das Test-Verzeichnis enthält zwei json-Files:

- *test.json* enthält die bereits bekannten Spezifikationen für die Struktur der Klassen (Konstruktoren, Methode, Attribute, ...).
- *ioTests.json* enthält eine Abfolge von IO-Tests: Zunächst den Namen der Klasse, deren main-Methode aufgerufen werden soll. Dannach eine Sequenz von IO-Tests mit Name und ggf. einem testspezifischen Timeout. Hauptteil der IO-Tests ist aber jeweils eine alternierende Liste von Input- und erwarteten Outputzeilen. Outputzeilen können entweder als erwartete Strings oder als Pattern angegeben werden. Für den 2. Teil der Aufgabe kann explizit auf das Lesen bis zum Zeilenende verzichtet werden.


```plantuml 
@startuml
skinparam ArrowFontSize 16
skinparam shadowing false
skinparam class {
    FontSize 20
    AttributeFontSize 16
 BorderColor black
 ArrowColor black
}

class IOTests {
  +void runIOTest()
}

class IOTest {
  +void runIOTest()
}

class TestStep {
  input : List<String>
  output : List<String>
  outputPattern : List<Pattern>
  ignoreFurtherChars : boolean
}

IOTest -right-> testDefinitionFile : defined_by
IOTests .down.> "0..*" IOTest:  uses
IOTest .down.> "0..*" TestStep:  "consists of"

note right of testDefinitionFile : ioTest.json

```

In ioTest.json können mehrere Tests definiert werden.
Jeder Test instanitiert die in ioTest.json definierten Klasse (in jeweils einem neuen Classloader) und ruft die main-Methode auf. 
Dabei wird System.in und System.out umdefiniert, um dem JUnit-Test zu ermöglichen, die main-Methode per PipedInputStream mit Input zu versorgen, bzw. per PipedOutputStream den Output zu lesen.

Anschliessend werden die Teststeps ausgeführt. Jeder Teststep besteht aus einer Reihe von InputStrings, die intern an System.in übergeben werden. Anschliessend werden die OutputStrings aus System.out gelesen und auf Korrektheit geprüft.



**Anmerkung:** wird nicht mit Zeilenbasierten Output gearbeitet (ignoreFurtherChars: false), dann kann es ggf. zu unerwünschten Nebeneffekten kommen: Es wird an System.out solange gelesen, bis der gewünschte String kommt (bzw. das gewünschte Pattern matched). Für den nächsten Testschritt wird die bis jetzt gelesenen Eingabe gelöscht.
