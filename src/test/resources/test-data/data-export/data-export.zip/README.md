# General information in accordance with Art. 15 GDPR
## Purposes of processing
The purposes of processing of personal data are teaching and examinations in an university context.

## Categories of personal data
Artemis only processes general personal data

## Recipients of personal data
As operator of the Artemis instance at TUM the Rechnerbetriebsgruppe processes personal data.

## Right to lodge a complaint
According to Art. 15 1(f) GDPR you have the right to lodge a complaint with the supervisory authority

## Right of rectification or erasure of personal data
According to Art. 15 1(e) GDPR you have the right to
