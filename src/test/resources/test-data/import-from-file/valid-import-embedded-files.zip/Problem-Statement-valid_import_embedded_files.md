Problem statement
![mountain.jpg](/api/files/markdown/Markdown_2023-05-06T16-17-46-410_ad323711.jpg)
![matterhorn.jpg](/api/files/markdown/Markdown_2023-05-06T16-17-46-822_b921f475.jpg)
