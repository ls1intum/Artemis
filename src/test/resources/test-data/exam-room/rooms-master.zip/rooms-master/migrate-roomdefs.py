#!/usr/bin/env python3
import csv, sys, os, json

try:
    folder = sys.argv[1]
except:
    print('Usage: {} <path to "rooms" folder containing csv files>'.format(sys.argv[0]))
    print()
    print('Writes output to the current directory')
    sys.exit(1)


def read_table(name):
    with open(os.path.join(folder, name + '.csv'), 'r') as f:
        return list(csv.DictReader(f, delimiter=';'))

rooms = read_table('room')
layouts = read_table('room_layout')
rows = read_table('row')
seats = read_table('seat')

rows.sort(key=lambda r: int(r['row_num']))
seats.sort(key=lambda s: int(s['seat_num']))

for room in rooms:
    code = room['code']
    with open(code + '.json', 'w') as f:
        json.dump({
            "number": room['number'],
            "name": room['name'],
            "shortname": room['shortname'],
            "building": room['building'],

            "rows": [{
                "label": row['label'],
                "seats": [{
                    "label": seat['seat_label'],
                    "flag": seat['flag'],
                    "position": { "x": float(seat['xpos']), "y": float(seat['ypos']) }
                } for seat in seats if (seat['code'], seat['row_num']) == (code, row['row_num'])]
            } for row in rows if row['code'] == code],

            "layouts": {layout['name']:{
                "auto_layout": {
                    "first_row": int(layout['first_row']),
                    "xspace": int(layout['xspace']),
                    "yspace": int(layout['yspace']),
                }
            } for layout in layouts if layout['code'] == code}
        }, f, indent=4)

