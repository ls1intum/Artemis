#!/usr/bin/env python3
import csv, sys, os, json
import argparse

parser = argparse.ArgumentParser(description="Create new room from roomdef.csv")
parser.add_argument('roomdef', help='folder containing roomdefs as CSV files')

args = parser.parse_args()

with open(os.path.join(args.roomdef, 'rows.csv')) as f:
    rows = list(csv.DictReader(f, delimiter=';'))
with open(os.path.join(args.roomdef, 'seats.csv')) as f:
    seats = list(csv.DictReader(f, delimiter=';'))
with open(os.path.join(args.roomdef, 'layouts.csv')) as f:
    layouts_in = list(csv.DictReader(f, delimiter=';'))
with open(os.path.join(args.roomdef, 'info.csv')) as f:
    info = list(csv.DictReader(f, delimiter=';'))[0]

code = args.roomdef.split('/')[-1]

json_rows = [{
    'label': row['row_label'],
    'seats': [{
        'label': seat['seat_label'],
        'flag': seat['flag'],
        'position': { "x": float(seat['xpos']), "y": float(seat['ypos']) },
    } for seat in seats if (seat['row_index'] == row['row_index'])]
} for row in rows]


def get_useable_seats(layout):
    useable_seats = []
    for seat in layout:
        row = json_rows[int(seat['row_index'])]
        s = [s for s in row['seats'] if s['label'] == seat['seat_label']][0]
        index = row['seats'].index(s)
        aisle = False
        if seat['aisle_adjacent'] == 't':
            aisle = True
        useable_seats.append({
            'row_index': int(seat['row_index']),
            'seat_index': index,
            'aisle_adjacent': aisle,
        })
    return useable_seats

layouts = {}
for layout in layouts_in:
    try:
        with open(os.path.join(args.roomdef, layout['name']+'.csv')) as f:
            explicit_layout = list(csv.DictReader(f, delimiter=';'))
        useable_seats = get_useable_seats(explicit_layout)
        print('found explicit layout for', layout['name'])
        layouts[layout['name']] = {
            'useable_seats': get_useable_seats(explicit_layout),
        }
    except Exception as e:
        layouts[layout['name']] = {
            "auto_layout": {
                "first_row": int(layout['first_row']),
                "xspace": int(layout['xspace']),
                "yspace": int(layout['yspace']),
            }
        }

try:
    with open(os.path.join(args.roomdef, 'corona.csv')) as f:
        corona = list(csv.DictReader(f, delimiter=';'))
    layouts['corona'] = {
        'useable_seats': get_useable_seats(corona),
    }
except:
    print('no explicit corona layout found')

#layouts = {
#    layout['name']: {
#        "auto_layout": {
#            "first_row": int(layout['first_row']),
#            "xspace": int(layout['xspace']),
#            "yspace": int(layout['yspace']),
#        }
#    } for layout in layouts
#}
#
#layouts['corona'] = {
#    'useable_seats': useable_seats,
#}

with open(code + '.json', 'w') as f:
    json.dump({
        'number': code,
        'name': info['name'],
        'shortname': info['shortname'],
        'building': info['building'],
        'rows': json_rows,
        'layouts': layouts,
    }, f, indent=4)

