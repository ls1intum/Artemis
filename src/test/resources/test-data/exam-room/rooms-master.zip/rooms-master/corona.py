#!/usr/bin/env python3
import csv, sys, os, json
from glob import glob

try:
    folder = sys.argv[1]
except:
    print('Usage: {} <path to "rooms" folder containing csv layouts>'.format(sys.argv[0]))
    print()
    print('Writes output to the current directory')
    sys.exit(1)


def read_table(name):
    with open(os.path.join(folder, name + '.csv'), 'r') as f:
        return list(csv.DictReader(f, delimiter=';'))

rooms = glob('*.json')

for room in rooms:
    code = os.path.splitext(room)[0]
    try:
        with open(os.path.join(folder, code + '.csv'), 'r') as f:
            seats = list(csv.DictReader(f, delimiter=';'))
    except:
        continue
    with open(code + '.json', 'r') as f:
        room = json.load(f)
        room['layouts']['corona'] = dict()
        room['layouts']['corona']['useable_seats'] = [{
            'row_index': int(x['row_index']),
            'seat_index': int(x['seat_index']),
            'aisle_adjacent': bool(x['aisle_adjacent']),
        } for x in seats]
    with open(code + '.json', 'w') as f:
        json.dump(room, f, indent=4)

