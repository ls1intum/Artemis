# TUMexam Room Layouts

You are free to submit changes as merge request and issues.

Please keep in mind that:

- we likely do not know the specific room layout(s)
- cannot visit the location to investigate
- will merge/adopt those changes as we see fit

## Workflow

- `*.json` files are used to render layouts and are the basis to assign seats
- `*.json` are mostly created based on corresponding `csv/*` input

Individual systems might not automatically get the latest data.

## Flags

Irregular (unsuable) seats are marked

- `T`: no table
- `D`: defect
- `W`: wheelchair


# Usage

- Link/reference this repository in the location where this data is used:
- Contribute derived/updated data back
