#!/usr/bin/env python3
import csv, sys, os, json
from glob import glob

try:
    roomjson = sys.argv[1]
except:
    print('Usage: {} <room>.json'.format(sys.argv[0]))
    print()
    print('')

roomname = os.path.splitext(roomjson)[0]

with open(roomjson, 'r') as f:
    room = json.load(f)

csv.register_dialect(
    'mydialect',
    'excel',
    delimiter=';',
    quoting=csv.QUOTE_NONE,
    lineterminator='\n',
)

with open(os.path.join('csv',roomname,'info.csv'), 'w', newline='', encoding='utf-8') as csvfile:
    fieldnames = ['name','shortname','building']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames, dialect='mydialect')
    writer.writeheader()
    writer.writerow({
        'name': room['name'],
        'shortname': room['shortname'],
        'building': room['building'],
    })


def write_corona_csv(roomname):
    with open(os.path.join('csv',roomname,'corona.csv'), 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['row_index','seat_label','aisle_adjacent']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames, dialect='mydialect')
        writer.writeheader()
        layout = room['layouts']['corona']['useable_seats']
        for entry in layout:
            row_index = int(entry['row_index'])
            seat_index = int(entry['seat_index'])
            row = room['rows'][row_index]
            seat = row['seats'][seat_index]
            aisle = 'f'
            if entry['aisle_adjacent']:
                aisle = 't'
            writer.writerow({
                'row_index': row_index,
                'seat_label': seat['label'],
                'aisle_adjacent': aisle,
            })


with open(os.path.join('csv',roomname,'layouts.csv'), 'w', newline='', encoding='utf-8') as csvfile:
    fieldnames = ['name','first_row','xspace','yspace']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames, dialect='mydialect')
    writer.writeheader()
    for name in room['layouts']:
        if name == 'corona':
            write_corona_csv(roomname)
            continue
        layout = room['layouts'][name]['auto_layout']
        layout['name'] = name
        writer.writerow(layout)


with open(os.path.join('csv',roomname,'rows.csv'), 'w', newline='', encoding='utf-8') as csvfile:
    i = 0
    fieldnames = ['row_index','row_label']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames, dialect='mydialect')
    writer.writeheader()
    for row in room['rows']:
        writer.writerow({
            'row_index': i,
            'row_label': row['label'],
        })
        i += 1


with open(os.path.join('csv',roomname,'seats.csv'), 'w', newline='', encoding='utf-8') as csvfile:
    row_index = 0
    seat_index = 0
    fieldnames = ['row_index','seat_label','flag','xpos','ypos']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames, dialect='mydialect')
    writer.writeheader()
    for row in room['rows']:
        for seat in row['seats']:
            writer.writerow({
                'row_index': row_index,
                'seat_label': seat['label'],
                'flag': seat['flag'],
                'xpos': seat['position']['x'],
                'ypos': seat['position']['y'],
            })
            seat_index += 1
        row_index += 1
