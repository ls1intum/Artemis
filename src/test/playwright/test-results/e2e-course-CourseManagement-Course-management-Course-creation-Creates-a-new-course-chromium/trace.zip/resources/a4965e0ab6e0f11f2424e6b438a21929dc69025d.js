import {
  DocumentationButtonComponent,
  init_documentation_button_component
} from "/chunk-ORYTP7RT.js";
import {
  ArtemisTranslatePipe,
  GradeType,
  GradingSystemPresentationsComponent,
  HelpIconComponent,
  TranslateDirective,
  __esm,
  init_artemis_translate_pipe,
  init_grading_scale_model,
  init_grading_system_presentations_component,
  init_help_icon_component,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/grading-system/grading-system-info-modal/grading-system-info-modal.component.ts
import { Component } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faQuestionCircle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import { NgbModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function GradingSystemInfoModalComponent_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "div", 3);
    i0.\u0275\u0275text(2, "\n        ");
    i0.\u0275\u0275elementStart(3, "h4", 4);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275pipe(5, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n        ");
    i0.\u0275\u0275elementStart(7, "button", 5);
    i0.\u0275\u0275listener("click", function GradingSystemInfoModalComponent_ng_template_0_Template_button_click_7_listener() {
      const restoredCtx = i0.\u0275\u0275restoreView(_r5);
      const d_r3 = restoredCtx.dismiss;
      return i0.\u0275\u0275resetView(d_r3());
    });
    i0.\u0275\u0275element(8, "span", 6);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n    ");
    i0.\u0275\u0275elementStart(11, "div", 7);
    i0.\u0275\u0275text(12, "\n        ");
    i0.\u0275\u0275elementStart(13, "table", 8);
    i0.\u0275\u0275text(14, "\n            ");
    i0.\u0275\u0275elementStart(15, "tr");
    i0.\u0275\u0275text(16, "\n                ");
    i0.\u0275\u0275elementStart(17, "th");
    i0.\u0275\u0275text(18);
    i0.\u0275\u0275pipe(19, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(20, "\n                ");
    i0.\u0275\u0275elementStart(21, "td");
    i0.\u0275\u0275text(22);
    i0.\u0275\u0275pipe(23, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(24, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(25, "\n            ");
    i0.\u0275\u0275element(26, "hr");
    i0.\u0275\u0275text(27, "\n            ");
    i0.\u0275\u0275elementStart(28, "tr");
    i0.\u0275\u0275text(29, "\n                ");
    i0.\u0275\u0275elementStart(30, "th");
    i0.\u0275\u0275text(31);
    i0.\u0275\u0275pipe(32, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(33, "\n                ");
    i0.\u0275\u0275elementStart(34, "td");
    i0.\u0275\u0275text(35);
    i0.\u0275\u0275pipe(36, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(37, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(38, "\n            ");
    i0.\u0275\u0275element(39, "hr");
    i0.\u0275\u0275text(40, "\n            ");
    i0.\u0275\u0275elementStart(41, "tr");
    i0.\u0275\u0275text(42, "\n                ");
    i0.\u0275\u0275elementStart(43, "th");
    i0.\u0275\u0275text(44);
    i0.\u0275\u0275pipe(45, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(46, "\n                ");
    i0.\u0275\u0275elementStart(47, "td");
    i0.\u0275\u0275text(48);
    i0.\u0275\u0275pipe(49, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(50, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(51, "\n            ");
    i0.\u0275\u0275element(52, "hr");
    i0.\u0275\u0275text(53, "\n            ");
    i0.\u0275\u0275elementStart(54, "tr");
    i0.\u0275\u0275text(55, "\n                ");
    i0.\u0275\u0275elementStart(56, "th");
    i0.\u0275\u0275text(57);
    i0.\u0275\u0275pipe(58, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(59, "\n                ");
    i0.\u0275\u0275elementStart(60, "td");
    i0.\u0275\u0275text(61);
    i0.\u0275\u0275pipe(62, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(63, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(64, "\n            ");
    i0.\u0275\u0275element(65, "hr");
    i0.\u0275\u0275text(66, "\n            ");
    i0.\u0275\u0275elementStart(67, "tr");
    i0.\u0275\u0275text(68, "\n                ");
    i0.\u0275\u0275elementStart(69, "th");
    i0.\u0275\u0275text(70);
    i0.\u0275\u0275pipe(71, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(72, "\n                ");
    i0.\u0275\u0275elementStart(73, "td");
    i0.\u0275\u0275text(74);
    i0.\u0275\u0275pipe(75, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(76, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(77, "\n            ");
    i0.\u0275\u0275element(78, "hr");
    i0.\u0275\u0275text(79, "\n            ");
    i0.\u0275\u0275elementStart(80, "tr");
    i0.\u0275\u0275text(81, "\n                ");
    i0.\u0275\u0275elementStart(82, "th");
    i0.\u0275\u0275text(83);
    i0.\u0275\u0275pipe(84, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(85, "\n                ");
    i0.\u0275\u0275elementStart(86, "td");
    i0.\u0275\u0275text(87);
    i0.\u0275\u0275pipe(88, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(89, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(90, "\n        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(91, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(92, "\n    ");
    i0.\u0275\u0275elementStart(93, "div", 9);
    i0.\u0275\u0275text(94, "\n        ");
    i0.\u0275\u0275elementStart(95, "button", 10);
    i0.\u0275\u0275listener("click", function GradingSystemInfoModalComponent_ng_template_0_Template_button_click_95_listener() {
      const restoredCtx = i0.\u0275\u0275restoreView(_r5);
      const c_r2 = restoredCtx.close;
      return i0.\u0275\u0275resetView(c_r2());
    });
    i0.\u0275\u0275text(96, "Close");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(97, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(98, "\n");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(5, 13, "artemisApp.gradingSystem.info.title"));
    i0.\u0275\u0275advance(14);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(19, 15, "artemisApp.gradingSystem.info.general.title"));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(23, 17, "artemisApp.gradingSystem.info.general.explanation"));
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(32, 19, "artemisApp.gradingSystem.info.maxPoints.title"));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(36, 21, "artemisApp.gradingSystem.info.maxPoints.explanation"));
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(45, 23, "artemisApp.gradingSystem.info.gradeType.title"));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(49, 25, "artemisApp.gradingSystem.info.gradeType.explanation"));
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(58, 27, "artemisApp.gradingSystem.info.inclusivity.title"));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(62, 29, "artemisApp.gradingSystem.info.inclusivity.explanation"));
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(71, 31, "artemisApp.gradingSystem.info.firstPassingGrade.title"));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(75, 33, "artemisApp.gradingSystem.info.firstPassingGrade.explanation"));
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(84, 35, "artemisApp.gradingSystem.info.importExport.title"));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(88, 37, "artemisApp.gradingSystem.info.importExport.explanation"));
  }
}
var GradingSystemInfoModalComponent;
var init_grading_system_info_modal_component = __esm({
  "src/main/webapp/app/grading-system/grading-system-info-modal/grading-system-info-modal.component.ts"() {
    init_artemis_translate_pipe();
    GradingSystemInfoModalComponent = class _GradingSystemInfoModalComponent {
      modalService;
      farQuestionCircle = faQuestionCircle;
      constructor(modalService) {
        this.modalService = modalService;
      }
      open(content) {
        this.modalService.open(content, { size: "lg" });
      }
      static \u0275fac = function GradingSystemInfoModalComponent_Factory(t) {
        return new (t || _GradingSystemInfoModalComponent)(i0.\u0275\u0275directiveInject(i1.NgbModal));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _GradingSystemInfoModalComponent, selectors: [["jhi-grading-system-info-modal"]], decls: 9, vars: 1, consts: [["info", ""], [1, "btn", 3, "click"], [3, "icon"], [1, "modal-header"], [1, "modal-title"], ["type", "button", "aria-label", "Close", 1, "btn-close", 3, "click"], ["aria-hidden", "true"], [1, "modal-body"], [1, "table"], [1, "modal-footer"], ["type", "button", 1, "btn", "btn-outline", 3, "click"]], template: function GradingSystemInfoModalComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r7 = i0.\u0275\u0275getCurrentView();
          i0.\u0275\u0275template(0, GradingSystemInfoModalComponent_ng_template_0_Template, 99, 39, "ng-template", null, 0, i0.\u0275\u0275templateRefExtractor);
          i0.\u0275\u0275text(2, "\n");
          i0.\u0275\u0275elementStart(3, "div");
          i0.\u0275\u0275text(4, "\n    ");
          i0.\u0275\u0275elementStart(5, "button", 1);
          i0.\u0275\u0275listener("click", function GradingSystemInfoModalComponent_Template_button_click_5_listener() {
            i0.\u0275\u0275restoreView(_r7);
            const _r1 = i0.\u0275\u0275reference(1);
            return i0.\u0275\u0275resetView(ctx.open(_r1));
          });
          i0.\u0275\u0275element(6, "fa-icon", 2);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(7, "\n");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(8, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275advance(6);
          i0.\u0275\u0275property("icon", ctx.farQuestionCircle);
        }
      }, dependencies: [i2.FaIconComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(GradingSystemInfoModalComponent, { className: "GradingSystemInfoModalComponent" });
    })();
  }
});

// src/main/webapp/app/grading-system/grading-system.component.ts
import { Component as Component2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { faExclamationTriangle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function GradingSystemComponent_Conditional_10_Conditional_40_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275element(1, "jhi-help-icon", 30);
    i02.\u0275\u0275text(2, "\n                ");
  }
}
function GradingSystemComponent_Conditional_10_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275element(1, "fa-icon", 31);
    i02.\u0275\u0275pipe(2, "artemisTranslate");
    i02.\u0275\u0275text(3, "\n                ");
  }
  if (rf & 2) {
    const ctx_r2 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275propertyInterpolate("ngbTooltip", i02.\u0275\u0275pipeBind1(2, 2, "artemisApp.examManagement.maxPoints.warning"));
    i02.\u0275\u0275property("icon", ctx_r2.faExclamationTriangle);
  }
}
function GradingSystemComponent_Conditional_10_Conditional_77_For_7_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "option", 34);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const gradeStep_r5 = ctx.$implicit;
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("ngValue", gradeStep_r5.gradeName);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275textInterpolate1("\n                                ", gradeStep_r5.gradeName, "\n                            ");
  }
}
function GradingSystemComponent_Conditional_10_Conditional_77_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "span", 32);
    i02.\u0275\u0275text(2, "First Passing Grade");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
    i02.\u0275\u0275elementStart(4, "select", 33);
    i02.\u0275\u0275listener("ngModelChange", function GradingSystemComponent_Conditional_10_Conditional_77_Template_select_ngModelChange_4_listener($event) {
      i02.\u0275\u0275restoreView(_r11);
      const ctx_r10 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r10.childComponent.firstPassingGrade = $event);
    });
    i02.\u0275\u0275text(5, "\n                        ");
    i02.\u0275\u0275repeaterCreate(6, GradingSystemComponent_Conditional_10_Conditional_77_For_7_Template, 4, 2, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                ");
  }
  if (rf & 2) {
    const ctx_r3 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275property("ngModel", ctx_r3.childComponent.firstPassingGrade);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275repeater(ctx_r3.childComponent.gradeStepsWithNonemptyNames());
  }
}
function GradingSystemComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n    ");
    i02.\u0275\u0275elementStart(1, "div", 6);
    i02.\u0275\u0275text(2, "\n        ");
    i02.\u0275\u0275elementStart(3, "div", 8);
    i02.\u0275\u0275text(4, "\n            ");
    i02.\u0275\u0275elementStart(5, "button", 9);
    i02.\u0275\u0275listener("click", function GradingSystemComponent_Conditional_10_Template_button_click_5_listener() {
      i02.\u0275\u0275restoreView(_r13);
      const ctx_r12 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r12.childComponent.generateDefaultGradingScale());
    });
    i02.\u0275\u0275text(6, "\n                ");
    i02.\u0275\u0275elementStart(7, "span", 10);
    i02.\u0275\u0275text(8, "Generate Default Grading Scale");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n            ");
    i02.\u0275\u0275element(11, "jhi-grading-system-info-modal");
    i02.\u0275\u0275text(12, "\n            ");
    i02.\u0275\u0275elementStart(13, "div", 11);
    i02.\u0275\u0275text(14, "\n                ");
    i02.\u0275\u0275elementStart(15, "label", 12);
    i02.\u0275\u0275text(16, "\n                    ");
    i02.\u0275\u0275elementStart(17, "span", 13);
    i02.\u0275\u0275text(18, "Import (.csv)");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(19, "\n                    ");
    i02.\u0275\u0275elementStart(20, "input", 14);
    i02.\u0275\u0275listener("change", function GradingSystemComponent_Conditional_10_Template_input_change_20_listener($event) {
      i02.\u0275\u0275restoreView(_r13);
      const ctx_r14 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r14.childComponent.onCSVFileSelect($event));
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(21, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(22, "\n                ");
    i02.\u0275\u0275elementStart(23, "button", 15);
    i02.\u0275\u0275listener("click", function GradingSystemComponent_Conditional_10_Template_button_click_23_listener() {
      i02.\u0275\u0275restoreView(_r13);
      const ctx_r15 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r15.childComponent.exportGradingStepsToCsv());
    });
    i02.\u0275\u0275text(24, "\n                    ");
    i02.\u0275\u0275elementStart(25, "span", 16);
    i02.\u0275\u0275text(26, "Export (.csv)");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(27, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(28, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(29, "\n        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(30, "\n        ");
    i02.\u0275\u0275elementStart(31, "div", 17);
    i02.\u0275\u0275text(32, "\n            ");
    i02.\u0275\u0275elementStart(33, "div", 18);
    i02.\u0275\u0275text(34, "\n                ");
    i02.\u0275\u0275elementStart(35, "span", 19);
    i02.\u0275\u0275text(36);
    i02.\u0275\u0275pipe(37, "artemisTranslate");
    i02.\u0275\u0275pipe(38, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(39, "\n                ");
    i02.\u0275\u0275template(40, GradingSystemComponent_Conditional_10_Conditional_40_Template, 3, 0)(41, GradingSystemComponent_Conditional_10_Conditional_41_Template, 4, 4);
    i02.\u0275\u0275elementStart(42, "input", 20);
    i02.\u0275\u0275listener("ngModelChange", function GradingSystemComponent_Conditional_10_Template_input_ngModelChange_42_listener($event) {
      i02.\u0275\u0275restoreView(_r13);
      const ctx_r16 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r16.childComponent.maxPoints = $event);
    })("change", function GradingSystemComponent_Conditional_10_Template_input_change_42_listener() {
      i02.\u0275\u0275restoreView(_r13);
      const ctx_r17 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r17.childComponent.onChangeMaxPoints(ctx_r17.childComponent.maxPoints));
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(43, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(44, "\n            ");
    i02.\u0275\u0275elementStart(45, "div", 18);
    i02.\u0275\u0275text(46, "\n                ");
    i02.\u0275\u0275elementStart(47, "span", 21);
    i02.\u0275\u0275text(48, "Grade Type");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(49, "\n                ");
    i02.\u0275\u0275elementStart(50, "select", 22);
    i02.\u0275\u0275listener("ngModelChange", function GradingSystemComponent_Conditional_10_Template_select_ngModelChange_50_listener($event) {
      i02.\u0275\u0275restoreView(_r13);
      const ctx_r18 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r18.childComponent.gradingScale.gradeType = $event);
    })("change", function GradingSystemComponent_Conditional_10_Template_select_change_50_listener() {
      i02.\u0275\u0275restoreView(_r13);
      const ctx_r19 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r19.childComponent.deleteGradeNames());
    });
    i02.\u0275\u0275text(51, "\n                    ");
    i02.\u0275\u0275elementStart(52, "option", 23);
    i02.\u0275\u0275text(53, "Grade");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(54, "\n                    ");
    i02.\u0275\u0275elementStart(55, "option", 24);
    i02.\u0275\u0275text(56, "Bonus");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(57, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(58, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(59, "\n            ");
    i02.\u0275\u0275elementStart(60, "div", 18);
    i02.\u0275\u0275text(61, "\n                ");
    i02.\u0275\u0275elementStart(62, "span", 25);
    i02.\u0275\u0275text(63, "Inclusivity");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(64, "\n                ");
    i02.\u0275\u0275elementStart(65, "select", 26);
    i02.\u0275\u0275listener("ngModelChange", function GradingSystemComponent_Conditional_10_Template_select_ngModelChange_65_listener($event) {
      i02.\u0275\u0275restoreView(_r13);
      const ctx_r20 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r20.childComponent.lowerBoundInclusivity = $event);
    })("ngModelChange", function GradingSystemComponent_Conditional_10_Template_select_ngModelChange_65_listener() {
      i02.\u0275\u0275restoreView(_r13);
      const ctx_r21 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r21.childComponent.setInclusivity());
    });
    i02.\u0275\u0275text(66, "\n                    ");
    i02.\u0275\u0275elementStart(67, "option", 27);
    i02.\u0275\u0275text(68, "Lower Bound Inclusive");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(69, "\n                    ");
    i02.\u0275\u0275elementStart(70, "option", 28);
    i02.\u0275\u0275text(71, "Upper Bound Inclusive");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(72, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(73, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(74, "\n            ");
    i02.\u0275\u0275elementStart(75, "div", 18);
    i02.\u0275\u0275text(76, "\n                ");
    i02.\u0275\u0275template(77, GradingSystemComponent_Conditional_10_Conditional_77_Template, 9, 1);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(78, "\n        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(79, "\n        ");
    i02.\u0275\u0275element(80, "jhi-grading-system-presentations", 29);
    i02.\u0275\u0275text(81, "\n    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(82, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(36);
    i02.\u0275\u0275textInterpolate(ctx_r0.isExam ? i02.\u0275\u0275pipeBind1(37, 11, "artemisApp.examManagement.maxPoints.title") : i02.\u0275\u0275pipeBind1(38, 13, "artemisApp.course.maxPoints.title"));
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275conditional(40, !ctx_r0.isExam ? 40 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(41, ctx_r0.isExam ? 41 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("ngModel", ctx_r0.childComponent.maxPoints);
    i02.\u0275\u0275advance(8);
    i02.\u0275\u0275property("ngModel", ctx_r0.childComponent.gradingScale.gradeType);
    i02.\u0275\u0275advance(15);
    i02.\u0275\u0275property("ngModel", ctx_r0.childComponent.lowerBoundInclusivity);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("ngValue", true);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("ngValue", false);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275conditional(77, ctx_r0.childComponent.gradingScale.gradeType === ctx_r0.GradeType.GRADE ? 77 : -1);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("gradingScale", ctx_r0.childComponent.gradingScale)("presentationsConfig", ctx_r0.childComponent.presentationsConfig);
  }
}
var GradingSystemComponent;
var init_grading_system_component = __esm({
  "src/main/webapp/app/grading-system/grading-system.component.ts"() {
    init_grading_scale_model();
    init_translate_directive();
    init_help_icon_component();
    init_documentation_button_component();
    init_grading_system_info_modal_component();
    init_grading_system_presentations_component();
    init_artemis_translate_pipe();
    GradingSystemComponent = class _GradingSystemComponent {
      route;
      GradeType = GradeType;
      courseId;
      examId;
      isExam = false;
      childComponent;
      documentationType = "Grading";
      faExclamationTriangle = faExclamationTriangle;
      constructor(route) {
        this.route = route;
      }
      ngOnInit() {
        this.route.params.subscribe((params) => {
          this.courseId = Number(params["courseId"]);
          if (params["examId"]) {
            this.examId = Number(params["examId"]);
            this.isExam = true;
          }
        });
      }
      onChildActivate(instance) {
        this.childComponent = instance;
      }
      static \u0275fac = function GradingSystemComponent_Factory(t) {
        return new (t || _GradingSystemComponent)(i02.\u0275\u0275directiveInject(i12.ActivatedRoute));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _GradingSystemComponent, selectors: [["jhi-grading-system"]], decls: 33, vars: 14, consts: [[1, "d-flex", "align-items-center"], [3, "type"], ["id", "tab-bar", 1, "tab-bar"], [1, "col-12", "no-indent"], ["routerLink", "interval", "routerLinkActive", "active", 1, "tab-item", "interval"], ["routerLink", "detailed", "routerLinkActive", "active", 1, "tab-item", "detailed"], [1, "course-body-container"], [3, "activate"], [1, "d-flex"], ["type", "button", 1, "btn", "btn-primary", "me-1", "mb-1", 3, "click"], ["jhiTranslate", "artemisApp.gradingSystem.defaultButton"], [1, "ms-auto"], [1, "btn", "btn-primary", "me-1", "mb-1"], ["jhiTranslate", "artemisApp.gradingSystem.csv.importButton"], ["type", "file", "accept", ".json,.csv", 2, "display", "none", 3, "change"], ["type", "button", 1, "btn", "btn-primary", "mb-1", 3, "click"], ["jhiTranslate", "artemisApp.gradingSystem.csv.exportButton"], [1, "dropdown-container"], [1, "form-group"], [1, "colon-suffix", "no-flex-shrink"], ["type", "number", "min", "1", 1, "form-control", 3, "ngModel", "ngModelChange", "change"], ["jhiTranslate", "artemisApp.gradingSystem.gradeType.title", 1, "colon-suffix", "no-flex-shrink"], ["title", "grade type", 1, "form-select", 3, "ngModel", "ngModelChange", "change"], ["value", "GRADE", "jhiTranslate", "artemisApp.gradingSystem.gradeType.grade"], ["value", "BONUS", "jhiTranslate", "artemisApp.gradingSystem.gradeType.bonus"], ["jhiTranslate", "artemisApp.gradingSystem.inclusivity.title", 1, "colon-suffix", "no-flex-shrink"], ["title", "inclusivity", 1, "form-select", 3, "ngModel", "ngModelChange"], ["jhiTranslate", "artemisApp.gradingSystem.inclusivity.lower", 3, "ngValue"], ["jhiTranslate", "artemisApp.gradingSystem.inclusivity.upper", 3, "ngValue"], [3, "gradingScale", "presentationsConfig"], ["text", "artemisApp.course.maxPoints.info"], [1, "text-warning", 3, "icon", "ngbTooltip"], ["jhiTranslate", "artemisApp.gradingSystem.firstPassingGrade", 1, "colon-suffix", "no-flex-shrink"], ["title", "first passing grade", 1, "form-select", 3, "ngModel", "ngModelChange"], [3, "ngValue"]], template: function GradingSystemComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div", 0);
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275elementStart(2, "h2");
          i02.\u0275\u0275text(3);
          i02.\u0275\u0275pipe(4, "artemisTranslate");
          i02.\u0275\u0275pipe(5, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(6, "\n    ");
          i02.\u0275\u0275element(7, "jhi-documentation-button", 1);
          i02.\u0275\u0275text(8, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(9, "\n");
          i02.\u0275\u0275template(10, GradingSystemComponent_Conditional_10_Template, 83, 15);
          i02.\u0275\u0275elementStart(11, "div", 2);
          i02.\u0275\u0275text(12, "\n    ");
          i02.\u0275\u0275elementStart(13, "div", 3);
          i02.\u0275\u0275text(14, "\n        ");
          i02.\u0275\u0275elementStart(15, "div");
          i02.\u0275\u0275text(16, "\n            ");
          i02.\u0275\u0275elementStart(17, "div", 4);
          i02.\u0275\u0275text(18);
          i02.\u0275\u0275pipe(19, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(20, "\n            ");
          i02.\u0275\u0275elementStart(21, "div", 5);
          i02.\u0275\u0275text(22);
          i02.\u0275\u0275pipe(23, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(24, "\n        ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(25, "\n    ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(26, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(27, "\n");
          i02.\u0275\u0275elementStart(28, "div", 6);
          i02.\u0275\u0275text(29, "\n    ");
          i02.\u0275\u0275elementStart(30, "router-outlet", 7);
          i02.\u0275\u0275listener("activate", function GradingSystemComponent_Template_router_outlet_activate_30_listener($event) {
            return ctx.onChildActivate($event);
          });
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(31, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(32, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275textInterpolate2("\n        ", ctx.isExam ? i02.\u0275\u0275pipeBind1(4, 6, "artemisApp.gradingSystem.titleExam") : i02.\u0275\u0275pipeBind1(5, 8, "artemisApp.gradingSystem.titleCourse"), "\n        ", ctx.isExam ? ctx.childComponent == null ? null : ctx.childComponent.exam == null ? null : ctx.childComponent.exam.title : ctx.childComponent == null ? null : ctx.childComponent.course == null ? null : ctx.childComponent.course.title, "\n    ");
          i02.\u0275\u0275advance(4);
          i02.\u0275\u0275property("type", ctx.documentationType);
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275conditional(10, ctx.childComponent ? 10 : -1);
          i02.\u0275\u0275advance(8);
          i02.\u0275\u0275textInterpolate1("\n                ", i02.\u0275\u0275pipeBind1(19, 10, "artemisApp.gradingSystem.intervalTab.title"), "\n            ");
          i02.\u0275\u0275advance(4);
          i02.\u0275\u0275textInterpolate1("\n                ", i02.\u0275\u0275pipeBind1(23, 12, "artemisApp.gradingSystem.detailedTab.title"), "\n            ");
        }
      }, dependencies: [i22.NgSelectOption, i22.\u0275NgSelectMultipleOption, i22.DefaultValueAccessor, i22.NumberValueAccessor, i22.SelectControlValueAccessor, i22.NgControlStatus, i22.MinValidator, i22.NgModel, i3.NgbTooltip, i4.FaIconComponent, TranslateDirective, i12.RouterOutlet, i12.RouterLink, i12.RouterLinkActive, HelpIconComponent, DocumentationButtonComponent, GradingSystemInfoModalComponent, GradingSystemPresentationsComponent, ArtemisTranslatePipe], styles: ["\n\n.tab-bar[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  min-height: 60px;\n  margin-bottom: 0.5rem;\n  padding-top: 11px;\n  padding-bottom: 11px;\n  border-bottom: 1px solid var(--overview-border-color);\n}\n.tab-bar[_ngcontent-%COMP%]   .tab-item[_ngcontent-%COMP%] {\n  cursor: pointer;\n  margin-top: 0;\n  margin-right: 1em;\n  margin-bottom: 0;\n}\n.tab-bar[_ngcontent-%COMP%]   .tab-item.active[_ngcontent-%COMP%] {\n  box-shadow: 0 2px 0 var(--artemis-dark);\n}\n.tab-bar[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 0.5rem;\n}\n.tab-bar[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child    > div[_ngcontent-%COMP%]:first-child {\n  display: flex;\n  align-items: center;\n}\n.tab-bar[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child   .controls[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n  margin-right: 3px;\n  margin-left: 3px;\n}\n.tab-bar[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child.no-indent {\n  justify-content: start;\n}\n.tab-bar[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child.no-indent   .controls[_ngcontent-%COMP%] {\n  padding-right: 0.5rem;\n  margin-right: 0;\n}\n.dropdown-container[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  width: 100%;\n  margin-top: 1rem;\n  margin-right: 0;\n  margin-left: 0;\n}\n.dropdown-container[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%] {\n  width: 23%;\n  min-width: 20%;\n}\n.dropdown-container[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   .form-control[_ngcontent-%COMP%] {\n  margin-top: 0.25em;\n}\n@media screen and (max-width: 991px) {\n  .tab-bar[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child {\n    flex-wrap: wrap;\n  }\n  .tab-bar[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child   .controls[_ngcontent-%COMP%] {\n    padding-right: 0.5rem;\n    margin-right: 0;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9ncmFkaW5nLXN5c3RlbS9ncmFkaW5nLXN5c3RlbS5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLnRhYi1iYXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBtaW4taGVpZ2h0OiA2MHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDAuNXJlbTtcblxuICAgICRwYWRkaW5nLXk6IDExcHg7XG5cbiAgICBwYWRkaW5nLXRvcDogJHBhZGRpbmcteTtcbiAgICBwYWRkaW5nLWJvdHRvbTogJHBhZGRpbmcteTtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0tb3ZlcnZpZXctYm9yZGVyLWNvbG9yKTtcblxuICAgIC50YWItaXRlbSB7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgbWFyZ2luLXRvcDogMDtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxZW07XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDA7XG5cbiAgICAgICAgJi5hY3RpdmUge1xuICAgICAgICAgICAgYm94LXNoYWRvdzogMCAycHggMCB2YXIoLS1hcnRlbWlzLWRhcmspO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgPiBkaXY6Zmlyc3QtY2hpbGQge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgIGdhcDogMC41cmVtO1xuXG4gICAgICAgID4gZGl2OmZpcnN0LWNoaWxkIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICB9XG5cbiAgICAgICAgLmNvbnRyb2xzIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgZ2FwOiAwLjVyZW07XG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDNweDtcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAzcHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICA+IGRpdjpmaXJzdC1jaGlsZC5uby1pbmRlbnQge1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHN0YXJ0O1xuXG4gICAgICAgIC5jb250cm9scyB7XG4gICAgICAgICAgICBwYWRkaW5nLXJpZ2h0OiAwLjVyZW07XG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDA7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5kcm9wZG93bi1jb250YWluZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbi10b3A6IDFyZW07XG4gICAgbWFyZ2luLXJpZ2h0OiAwO1xuICAgIG1hcmdpbi1sZWZ0OiAwO1xuXG4gICAgLmZvcm0tZ3JvdXAge1xuICAgICAgICB3aWR0aDogMjMlO1xuICAgICAgICBtaW4td2lkdGg6IDIwJTtcbiAgICB9XG59XG5cbi5kcm9wZG93bi1jb250YWluZXIgLmZvcm0tZ3JvdXAgLmZvcm0tY29udHJvbCB7XG4gICAgbWFyZ2luLXRvcDogMC4yNWVtO1xufVxuXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA5OTFweCkge1xuICAgIC50YWItYmFyID4gZGl2OmZpcnN0LWNoaWxkIHtcbiAgICAgICAgZmxleC13cmFwOiB3cmFwO1xuXG4gICAgICAgIC5jb250cm9scyB7XG4gICAgICAgICAgICBwYWRkaW5nLXJpZ2h0OiAwLjVyZW07XG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDA7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBO0FBQ0EsY0FBQTtBQUNBLGlCQUFBO0FBSUEsZUFGWTtBQUdaLGtCQUhZO0FBSVosaUJBQUEsSUFBQSxNQUFBLElBQUE7O0FBRUEsQ0FaSixRQVlJLENBQUE7QUFDSSxVQUFBO0FBQ0EsY0FBQTtBQUNBLGdCQUFBO0FBQ0EsaUJBQUE7O0FBRUEsQ0FsQlIsUUFrQlEsQ0FOSixRQU1JLENBQUE7QUFDSSxjQUFBLEVBQUEsSUFBQSxFQUFBLElBQUE7O0FBSVIsQ0F2QkosUUF1QkksRUFBQSxHQUFBO0FBQ0ksV0FBQTtBQUNBLGVBQUE7QUFDQSxtQkFBQTtBQUNBLE9BQUE7O0FBRUEsQ0E3QlIsUUE2QlEsRUFBQSxHQUFBLGFBQUEsRUFBQSxHQUFBO0FBQ0ksV0FBQTtBQUNBLGVBQUE7O0FBR0osQ0FsQ1IsUUFrQ1EsRUFBQSxHQUFBLGFBQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBO0FBQ0EsT0FBQTtBQUNBLGdCQUFBO0FBQ0EsZUFBQTs7QUFJUixDQTNDSixRQTJDSSxFQUFBLEdBQUEsWUFBQSxDQUFBO0FBQ0ksbUJBQUE7O0FBRUEsQ0E5Q1IsUUE4Q1EsRUFBQSxHQUFBLFlBQUEsQ0FISixVQUdJLENBWkE7QUFhSSxpQkFBQTtBQUNBLGdCQUFBOztBQUtaLENBQUE7QUFDSSxXQUFBO0FBQ0EsbUJBQUE7QUFDQSxTQUFBO0FBQ0EsY0FBQTtBQUNBLGdCQUFBO0FBQ0EsZUFBQTs7QUFFQSxDQVJKLG1CQVFJLENBQUE7QUFDSSxTQUFBO0FBQ0EsYUFBQTs7QUFJUixDQWRBLG1CQWNBLENBTkksV0FNSixDQUFBO0FBQ0ksY0FBQTs7QUFHSixPQUFBLE9BQUEsSUFBQSxDQUFBLFNBQUEsRUFBQTtBQUNJLEdBeEVKLFFBd0VJLEVBQUEsR0FBQTtBQUNJLGVBQUE7O0FBRUEsR0EzRVIsUUEyRVEsRUFBQSxHQUFBLGFBQUEsQ0F6Q0E7QUEwQ0ksbUJBQUE7QUFDQSxrQkFBQTs7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(GradingSystemComponent, { className: "GradingSystemComponent" });
    })();
  }
});

export {
  init_grading_system_info_modal_component,
  GradingSystemComponent,
  init_grading_system_component
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZ3JhZGluZy1zeXN0ZW0vZ3JhZGluZy1zeXN0ZW0taW5mby1tb2RhbC9ncmFkaW5nLXN5c3RlbS1pbmZvLW1vZGFsLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZ3JhZGluZy1zeXN0ZW0vZ3JhZGluZy1zeXN0ZW0taW5mby1tb2RhbC9ncmFkaW5nLXN5c3RlbS1pbmZvLW1vZGFsLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9ncmFkaW5nLXN5c3RlbS9ncmFkaW5nLXN5c3RlbS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2dyYWRpbmctc3lzdGVtL2dyYWRpbmctc3lzdGVtLmNvbXBvbmVudC5odG1sIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZmFRdWVzdGlvbkNpcmNsZSB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXJlZ3VsYXItc3ZnLWljb25zJztcbmltcG9ydCB7IE5nYk1vZGFsIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1ncmFkaW5nLXN5c3RlbS1pbmZvLW1vZGFsJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vZ3JhZGluZy1zeXN0ZW0taW5mby1tb2RhbC5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIEdyYWRpbmdTeXN0ZW1JbmZvTW9kYWxDb21wb25lbnQge1xuICAgIC8vIEljb25zXG4gICAgZmFyUXVlc3Rpb25DaXJjbGUgPSBmYVF1ZXN0aW9uQ2lyY2xlO1xuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgbW9kYWxTZXJ2aWNlOiBOZ2JNb2RhbCkge31cblxuICAgIC8qKlxuICAgICAqIE9wZW4gYSBsYXJnZSBtb2RhbCB3aXRoIHRoZSBnaXZlbiBjb250ZW50LlxuICAgICAqIEBwYXJhbSBjb250ZW50IHRoZSBjb250ZW50IHRvIGRpc3BsYXlcbiAgICAgKi9cbiAgICBvcGVuKGNvbnRlbnQ6IGFueSkge1xuICAgICAgICB0aGlzLm1vZGFsU2VydmljZS5vcGVuKGNvbnRlbnQsIHsgc2l6ZTogJ2xnJyB9KTtcbiAgICB9XG59XG4iLCI8bmctdGVtcGxhdGUgI2luZm8gbGV0LWM9XCJjbG9zZVwiIGxldC1kPVwiZGlzbWlzc1wiPlxuICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1oZWFkZXJcIj5cbiAgICAgICAgPGg0IGNsYXNzPVwibW9kYWwtdGl0bGVcIj57eyAnYXJ0ZW1pc0FwcC5ncmFkaW5nU3lzdGVtLmluZm8udGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvaDQ+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWNsb3NlXCIgYXJpYS1sYWJlbD1cIkNsb3NlXCIgKGNsaWNrKT1cImQoKVwiPjxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvc3Bhbj48L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtYm9keVwiPlxuICAgICAgICA8dGFibGUgY2xhc3M9XCJ0YWJsZVwiPlxuICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0aD57eyAnYXJ0ZW1pc0FwcC5ncmFkaW5nU3lzdGVtLmluZm8uZ2VuZXJhbC50aXRsZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC90aD5cbiAgICAgICAgICAgICAgICA8dGQ+e3sgJ2FydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5pbmZvLmdlbmVyYWwuZXhwbGFuYXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvdGQ+XG4gICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPGhyIC8+XG4gICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRoPnt7ICdhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0uaW5mby5tYXhQb2ludHMudGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvdGg+XG4gICAgICAgICAgICAgICAgPHRkPnt7ICdhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0uaW5mby5tYXhQb2ludHMuZXhwbGFuYXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvdGQ+XG4gICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPGhyIC8+XG4gICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRoPnt7ICdhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0uaW5mby5ncmFkZVR5cGUudGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvdGg+XG4gICAgICAgICAgICAgICAgPHRkPnt7ICdhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0uaW5mby5ncmFkZVR5cGUuZXhwbGFuYXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvdGQ+XG4gICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPGhyIC8+XG4gICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRoPnt7ICdhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0uaW5mby5pbmNsdXNpdml0eS50aXRsZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC90aD5cbiAgICAgICAgICAgICAgICA8dGQ+e3sgJ2FydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5pbmZvLmluY2x1c2l2aXR5LmV4cGxhbmF0aW9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3RkPlxuICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDxociAvPlxuICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0aD57eyAnYXJ0ZW1pc0FwcC5ncmFkaW5nU3lzdGVtLmluZm8uZmlyc3RQYXNzaW5nR3JhZGUudGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvdGg+XG4gICAgICAgICAgICAgICAgPHRkPnt7ICdhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0uaW5mby5maXJzdFBhc3NpbmdHcmFkZS5leHBsYW5hdGlvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC90ZD5cbiAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8aHIgLz5cbiAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGg+e3sgJ2FydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5pbmZvLmltcG9ydEV4cG9ydC50aXRsZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC90aD5cbiAgICAgICAgICAgICAgICA8dGQ+e3sgJ2FydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5pbmZvLmltcG9ydEV4cG9ydC5leHBsYW5hdGlvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC90ZD5cbiAgICAgICAgICAgIDwvdHI+XG4gICAgICAgIDwvdGFibGU+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cIm1vZGFsLWZvb3RlclwiPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0biBidG4tb3V0bGluZVwiIChjbGljayk9XCJjKClcIj5DbG9zZTwvYnV0dG9uPlxuICAgIDwvZGl2PlxuPC9uZy10ZW1wbGF0ZT5cbjxkaXY+XG4gICAgPGJ1dHRvbiBjbGFzcz1cImJ0blwiIChjbGljayk9XCJvcGVuKGluZm8pXCI+PGZhLWljb24gW2ljb25dPVwiZmFyUXVlc3Rpb25DaXJjbGVcIj48L2ZhLWljb24+PC9idXR0b24+XG48L2Rpdj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBEb2N1bWVudGF0aW9uVHlwZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9kb2N1bWVudGF0aW9uLWJ1dHRvbi9kb2N1bWVudGF0aW9uLWJ1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgR3JhZGVUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2dyYWRpbmctc2NhbGUubW9kZWwnO1xuaW1wb3J0IHsgQmFzZUdyYWRpbmdTeXN0ZW1Db21wb25lbnQgfSBmcm9tICdhcHAvZ3JhZGluZy1zeXN0ZW0vYmFzZS1ncmFkaW5nLXN5c3RlbS9iYXNlLWdyYWRpbmctc3lzdGVtLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBmYUV4Y2xhbWF0aW9uVHJpYW5nbGUgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1ncmFkaW5nLXN5c3RlbScsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2dyYWRpbmctc3lzdGVtLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9ncmFkaW5nLXN5c3RlbS5jb21wb25lbnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBHcmFkaW5nU3lzdGVtQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICByZWFkb25seSBHcmFkZVR5cGUgPSBHcmFkZVR5cGU7XG5cbiAgICBjb3Vyc2VJZD86IG51bWJlcjtcbiAgICBleGFtSWQ/OiBudW1iZXI7XG4gICAgaXNFeGFtID0gZmFsc2U7XG4gICAgY2hpbGRDb21wb25lbnQ/OiBCYXNlR3JhZGluZ1N5c3RlbUNvbXBvbmVudDtcblxuICAgIHJlYWRvbmx5IGRvY3VtZW50YXRpb25UeXBlOiBEb2N1bWVudGF0aW9uVHlwZSA9ICdHcmFkaW5nJztcblxuICAgIC8vIEljb25zXG4gICAgcmVhZG9ubHkgZmFFeGNsYW1hdGlvblRyaWFuZ2xlID0gZmFFeGNsYW1hdGlvblRyaWFuZ2xlO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSByb3V0ZTogQWN0aXZhdGVkUm91dGUpIHt9XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5yb3V0ZS5wYXJhbXMuc3Vic2NyaWJlKChwYXJhbXMpID0+IHtcbiAgICAgICAgICAgIHRoaXMuY291cnNlSWQgPSBOdW1iZXIocGFyYW1zWydjb3Vyc2VJZCddKTtcbiAgICAgICAgICAgIGlmIChwYXJhbXNbJ2V4YW1JZCddKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5leGFtSWQgPSBOdW1iZXIocGFyYW1zWydleGFtSWQnXSk7XG4gICAgICAgICAgICAgICAgdGhpcy5pc0V4YW0gPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUaGlzIGZ1bmN0aW9uIGdldHMgY2FsbGVkIGlmIHRoZSByb3V0ZXIgb3V0bGV0IGdldHMgYWN0aXZhdGVkLiBUaGUgc3ViIHJvdXRlc1xuICAgICAqIHNob3VsZCBkZXJpdmUgZnJvbSBCYXNlR3JhZGluZ1N5c3RlbUNvbXBvbmVudFxuICAgICAqIEBwYXJhbSBpbnN0YW5jZSBUaGUgY29tcG9uZW50IGluc3RhbmNlXG4gICAgICovXG4gICAgb25DaGlsZEFjdGl2YXRlKGluc3RhbmNlOiBCYXNlR3JhZGluZ1N5c3RlbUNvbXBvbmVudCkge1xuICAgICAgICB0aGlzLmNoaWxkQ29tcG9uZW50ID0gaW5zdGFuY2U7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cImQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICA8aDI+XG4gICAgICAgIHt7IGlzRXhhbSA/ICgnYXJ0ZW1pc0FwcC5ncmFkaW5nU3lzdGVtLnRpdGxlRXhhbScgfCBhcnRlbWlzVHJhbnNsYXRlKSA6ICgnYXJ0ZW1pc0FwcC5ncmFkaW5nU3lzdGVtLnRpdGxlQ291cnNlJyB8IGFydGVtaXNUcmFuc2xhdGUpIH19XG4gICAgICAgIHt7IGlzRXhhbSA/IGNoaWxkQ29tcG9uZW50Py5leGFtPy50aXRsZSA6IGNoaWxkQ29tcG9uZW50Py5jb3Vyc2U/LnRpdGxlIH19XG4gICAgPC9oMj5cbiAgICA8amhpLWRvY3VtZW50YXRpb24tYnV0dG9uIFt0eXBlXT1cImRvY3VtZW50YXRpb25UeXBlXCI+PC9qaGktZG9jdW1lbnRhdGlvbi1idXR0b24+XG48L2Rpdj5cbkBpZiAoY2hpbGRDb21wb25lbnQpIHtcbiAgICA8ZGl2IGNsYXNzPVwiY291cnNlLWJvZHktY29udGFpbmVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXhcIj5cbiAgICAgICAgICAgIDxidXR0b24gKGNsaWNrKT1cImNoaWxkQ29tcG9uZW50LmdlbmVyYXRlRGVmYXVsdEdyYWRpbmdTY2FsZSgpXCIgY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgbWUtMSBtYi0xXCIgdHlwZT1cImJ1dHRvblwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5kZWZhdWx0QnV0dG9uXCI+R2VuZXJhdGUgRGVmYXVsdCBHcmFkaW5nIFNjYWxlPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8amhpLWdyYWRpbmctc3lzdGVtLWluZm8tbW9kYWw+PC9qaGktZ3JhZGluZy1zeXN0ZW0taW5mby1tb2RhbD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtcy1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IG1lLTEgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0uY3N2LmltcG9ydEJ1dHRvblwiPkltcG9ydCAoLmNzdik8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cIi5qc29uLC5jc3ZcIiBzdHlsZT1cImRpc3BsYXk6IG5vbmVcIiAoY2hhbmdlKT1cImNoaWxkQ29tcG9uZW50Lm9uQ1NWRmlsZVNlbGVjdCgkZXZlbnQpXCIgLz5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxidXR0b24gKGNsaWNrKT1cImNoaWxkQ29tcG9uZW50LmV4cG9ydEdyYWRpbmdTdGVwc1RvQ3N2KClcIiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBtYi0xXCIgdHlwZT1cImJ1dHRvblwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0uY3N2LmV4cG9ydEJ1dHRvblwiPkV4cG9ydCAoLmNzdik8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJkcm9wZG93bi1jb250YWluZXJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJjb2xvbi1zdWZmaXggbm8tZmxleC1zaHJpbmtcIj57e1xuICAgICAgICAgICAgICAgICAgICBpc0V4YW0gPyAoJ2FydGVtaXNBcHAuZXhhbU1hbmFnZW1lbnQubWF4UG9pbnRzLnRpdGxlJyB8IGFydGVtaXNUcmFuc2xhdGUpIDogKCdhcnRlbWlzQXBwLmNvdXJzZS5tYXhQb2ludHMudGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcbiAgICAgICAgICAgICAgICB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICBAaWYgKCFpc0V4YW0pIHtcbiAgICAgICAgICAgICAgICAgICAgPGpoaS1oZWxwLWljb24gdGV4dD1cImFydGVtaXNBcHAuY291cnNlLm1heFBvaW50cy5pbmZvXCI+PC9qaGktaGVscC1pY29uPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKGlzRXhhbSkge1xuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUV4Y2xhbWF0aW9uVHJpYW5nbGVcIiBjbGFzcz1cInRleHQtd2FybmluZ1wiIG5nYlRvb2x0aXA9XCJ7eyAnYXJ0ZW1pc0FwcC5leGFtTWFuYWdlbWVudC5tYXhQb2ludHMud2FybmluZycgfCBhcnRlbWlzVHJhbnNsYXRlIH19XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIGNsYXNzPVwiZm9ybS1jb250cm9sXCIgWyhuZ01vZGVsKV09XCJjaGlsZENvbXBvbmVudC5tYXhQb2ludHNcIiBtaW49XCIxXCIgKGNoYW5nZSk9XCJjaGlsZENvbXBvbmVudC5vbkNoYW5nZU1heFBvaW50cyhjaGlsZENvbXBvbmVudC5tYXhQb2ludHMpXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImNvbG9uLXN1ZmZpeCBuby1mbGV4LXNocmlua1wiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5ncmFkZVR5cGUudGl0bGVcIj5HcmFkZSBUeXBlPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3M9XCJmb3JtLXNlbGVjdFwiIFsobmdNb2RlbCldPVwiY2hpbGRDb21wb25lbnQuZ3JhZGluZ1NjYWxlLmdyYWRlVHlwZVwiIChjaGFuZ2UpPVwiY2hpbGRDb21wb25lbnQuZGVsZXRlR3JhZGVOYW1lcygpXCIgdGl0bGU9XCJncmFkZSB0eXBlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJHUkFERVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5ncmFkZVR5cGUuZ3JhZGVcIj5HcmFkZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQk9OVVNcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0uZ3JhZGVUeXBlLmJvbnVzXCI+Qm9udXM8L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImNvbG9uLXN1ZmZpeCBuby1mbGV4LXNocmlua1wiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5pbmNsdXNpdml0eS50aXRsZVwiPkluY2x1c2l2aXR5PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3M9XCJmb3JtLXNlbGVjdFwiIFsobmdNb2RlbCldPVwiY2hpbGRDb21wb25lbnQubG93ZXJCb3VuZEluY2x1c2l2aXR5XCIgKG5nTW9kZWxDaGFuZ2UpPVwiY2hpbGRDb21wb25lbnQuc2V0SW5jbHVzaXZpdHkoKVwiIHRpdGxlPVwiaW5jbHVzaXZpdHlcIj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBbbmdWYWx1ZV09XCJ0cnVlXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5ncmFkaW5nU3lzdGVtLmluY2x1c2l2aXR5Lmxvd2VyXCI+TG93ZXIgQm91bmQgSW5jbHVzaXZlPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gW25nVmFsdWVdPVwiZmFsc2VcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0uaW5jbHVzaXZpdHkudXBwZXJcIj5VcHBlciBCb3VuZCBJbmNsdXNpdmU8L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICBAaWYgKGNoaWxkQ29tcG9uZW50LmdyYWRpbmdTY2FsZS5ncmFkZVR5cGUgPT09IEdyYWRlVHlwZS5HUkFERSkge1xuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImNvbG9uLXN1ZmZpeCBuby1mbGV4LXNocmlua1wiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5maXJzdFBhc3NpbmdHcmFkZVwiPkZpcnN0IFBhc3NpbmcgR3JhZGU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3M9XCJmb3JtLXNlbGVjdFwiIHRpdGxlPVwiZmlyc3QgcGFzc2luZyBncmFkZVwiIFsobmdNb2RlbCldPVwiY2hpbGRDb21wb25lbnQuZmlyc3RQYXNzaW5nR3JhZGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKGdyYWRlU3RlcCBvZiBjaGlsZENvbXBvbmVudC5ncmFkZVN0ZXBzV2l0aE5vbmVtcHR5TmFtZXMoKTsgdHJhY2sgZ3JhZGVTdGVwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBbbmdWYWx1ZV09XCJncmFkZVN0ZXAuZ3JhZGVOYW1lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGdyYWRlU3RlcC5ncmFkZU5hbWUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8amhpLWdyYWRpbmctc3lzdGVtLXByZXNlbnRhdGlvbnNcbiAgICAgICAgICAgIFtncmFkaW5nU2NhbGVdPVwiY2hpbGRDb21wb25lbnQuZ3JhZGluZ1NjYWxlXCJcbiAgICAgICAgICAgIFtwcmVzZW50YXRpb25zQ29uZmlnXT1cImNoaWxkQ29tcG9uZW50LnByZXNlbnRhdGlvbnNDb25maWdcIlxuICAgICAgICA+PC9qaGktZ3JhZGluZy1zeXN0ZW0tcHJlc2VudGF0aW9ucz5cbiAgICA8L2Rpdj5cbn1cbjxkaXYgY2xhc3M9XCJ0YWItYmFyXCIgaWQ9XCJ0YWItYmFyXCI+XG4gICAgPGRpdiBjbGFzcz1cImNvbC0xMiBuby1pbmRlbnRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0YWItaXRlbSBpbnRlcnZhbFwiIHJvdXRlckxpbms9XCJpbnRlcnZhbFwiIHJvdXRlckxpbmtBY3RpdmU9XCJhY3RpdmVcIj5cbiAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5ncmFkaW5nU3lzdGVtLmludGVydmFsVGFiLnRpdGxlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRhYi1pdGVtIGRldGFpbGVkXCIgcm91dGVyTGluaz1cImRldGFpbGVkXCIgcm91dGVyTGlua0FjdGl2ZT1cImFjdGl2ZVwiPlxuICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0uZGV0YWlsZWRUYWIudGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuPC9kaXY+XG48ZGl2IGNsYXNzPVwiY291cnNlLWJvZHktY29udGFpbmVyXCI+XG4gICAgPHJvdXRlci1vdXRsZXQgKGFjdGl2YXRlKT1cIm9uQ2hpbGRBY3RpdmF0ZSgkZXZlbnQpXCI+PC9yb3V0ZXItb3V0bGV0PlxuPC9kaXY+XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLGlCQUFpQjtBQUMxQixTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLGdCQUFnQjs7Ozs7OztBQ0RyQixJQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBLENBQUE7QUFBd0IsSUFBQSxvQkFBQSxDQUFBOztBQUE4RCxJQUFBLDBCQUFBO0FBQ3RGLElBQUEsb0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUEyRCxJQUFBLHdCQUFBLFNBQUEsU0FBQSxpRkFBQTtBQUFBLFlBQUEsY0FBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxPQUFBLFlBQUE7QUFBQSxhQUFTLHlCQUFBLEtBQUEsQ0FBRztJQUFBLENBQUE7QUFBRSxJQUFBLHVCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQWdDLElBQUEsMEJBQUE7QUFDN0csSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsU0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsRUFBQTs7QUFBc0UsSUFBQSwwQkFBQTtBQUMxRSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsRUFBQTs7QUFBNEUsSUFBQSwwQkFBQTtBQUNwRixJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLElBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxvQkFBQSxFQUFBOztBQUF3RSxJQUFBLDBCQUFBO0FBQzVFLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxvQkFBQSxFQUFBOztBQUE4RSxJQUFBLDBCQUFBO0FBQ3RGLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHVCQUFBLElBQUEsSUFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLEVBQUE7O0FBQXdFLElBQUEsMEJBQUE7QUFDNUUsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLEVBQUE7O0FBQThFLElBQUEsMEJBQUE7QUFDdEYsSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsdUJBQUEsSUFBQSxJQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsRUFBQTs7QUFBMEUsSUFBQSwwQkFBQTtBQUM5RSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsRUFBQTs7QUFBZ0YsSUFBQSwwQkFBQTtBQUN4RixJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLElBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxvQkFBQSxFQUFBOztBQUFnRixJQUFBLDBCQUFBO0FBQ3BGLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxvQkFBQSxFQUFBOztBQUFzRixJQUFBLDBCQUFBO0FBQzlGLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHVCQUFBLElBQUEsSUFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLEVBQUE7O0FBQTJFLElBQUEsMEJBQUE7QUFDL0UsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLEVBQUE7O0FBQWlGLElBQUEsMEJBQUE7QUFDekYsSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUE4QyxJQUFBLHdCQUFBLFNBQUEsU0FBQSxrRkFBQTtBQUFBLFlBQUEsY0FBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxPQUFBLFlBQUE7QUFBQSxhQUFTLHlCQUFBLEtBQUEsQ0FBRztJQUFBLENBQUE7QUFBRSxJQUFBLG9CQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsMEJBQUE7QUFDckUsSUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLElBQUE7OztBQXZDZ0MsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxHQUFBLElBQUEscUNBQUEsQ0FBQTtBQU1aLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsSUFBQSxJQUFBLDZDQUFBLENBQUE7QUFDQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLElBQUEsSUFBQSxtREFBQSxDQUFBO0FBSUEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxJQUFBLElBQUEsK0NBQUEsQ0FBQTtBQUNBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsSUFBQSxJQUFBLHFEQUFBLENBQUE7QUFJQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLElBQUEsSUFBQSwrQ0FBQSxDQUFBO0FBQ0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxJQUFBLElBQUEscURBQUEsQ0FBQTtBQUlBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsSUFBQSxJQUFBLGlEQUFBLENBQUE7QUFDQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLElBQUEsSUFBQSx1REFBQSxDQUFBO0FBSUEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxJQUFBLElBQUEsdURBQUEsQ0FBQTtBQUNBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsSUFBQSxJQUFBLDZEQUFBLENBQUE7QUFJQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLElBQUEsSUFBQSxrREFBQSxDQUFBO0FBQ0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxJQUFBLElBQUEsd0RBQUEsQ0FBQTs7O0FEbENwQixJQVFhO0FBUmI7OztBQVFNLElBQU8sa0NBQVAsTUFBTyxpQ0FBK0I7TUFHcEI7TUFEcEIsb0JBQW9CO01BQ3BCLFlBQW9CLGNBQXNCO0FBQXRCLGFBQUEsZUFBQTtNQUF5QjtNQU03QyxLQUFLLFNBQVk7QUFDYixhQUFLLGFBQWEsS0FBSyxTQUFTLEVBQUUsTUFBTSxLQUFJLENBQUU7TUFDbEQ7O3lCQVhTLGtDQUErQiwrQkFBQSxXQUFBLENBQUE7TUFBQTtnRUFBL0Isa0NBQStCLFdBQUEsQ0FBQSxDQUFBLCtCQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLFFBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLGNBQUEsU0FBQSxHQUFBLGFBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxlQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLE9BQUEsZUFBQSxHQUFBLE9BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSx5Q0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7QUNSNUMsVUFBQSx3QkFBQSxHQUFBLHdEQUFBLElBQUEsSUFBQSxlQUFBLE1BQUEsR0FBQSxtQ0FBQTtBQTBDQSxVQUFBLG9CQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxLQUFBO0FBQ0ksVUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsVUFBQSxDQUFBO0FBQW9CLFVBQUEsd0JBQUEsU0FBQSxTQUFBLG1FQUFBO0FBQUEsWUFBQSwyQkFBQSxHQUFBO0FBQUEsa0JBQUEsTUFBQSx5QkFBQSxDQUFBO0FBQUEsbUJBQVMseUJBQUEsSUFBQSxLQUFBLEdBQUEsQ0FBVTtVQUFBLENBQUE7QUFBRSxVQUFBLHVCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQThDLFVBQUEsMEJBQUE7QUFDM0YsVUFBQSxvQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDBCQUFBO0FBQ0EsVUFBQSxvQkFBQSxHQUFBLElBQUE7OztBQUZzRCxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLHdCQUFBLFFBQUEsSUFBQSxpQkFBQTs7Ozs7b0ZEbkN6QyxpQ0FBK0IsRUFBQSxXQUFBLGtDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVI1QyxTQUFTLGFBQUFBLGtCQUF5QjtBQUNsQyxTQUFTLHNCQUFzQjtBQUkvQixTQUFTLDZCQUE2Qjs7Ozs7Ozs7QUN5QmxCLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxpQkFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7O0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7O0FBRGlFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsb0NBQUEsY0FBQSwwQkFBQSxHQUFBLEdBQUEsNkNBQUEsQ0FBQTtBQUFwRCxJQUFBLHlCQUFBLFFBQUEsT0FBQSxxQkFBQTs7Ozs7QUF1QkQsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7QUFIWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsYUFBQSxTQUFBO0FBQ0osSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxzQ0FBQSxhQUFBLFdBQUEsZ0NBQUE7Ozs7OztBQUpaLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBb0csSUFBQSxxQkFBQSxHQUFBLHFCQUFBO0FBQW1CLElBQUEsMkJBQUE7QUFDdkgsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUF3RCxJQUFBLHlCQUFBLGlCQUFBLFNBQUEsOEZBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBYSwwQkFBQSxRQUFBLGVBQUEsb0JBQUEsTUFBQTtJQUNwRixDQUFBO0FBQW1CLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsK0JBQUEsR0FBQSxxRUFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBO0FBS0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQVA0RCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsT0FBQSxlQUFBLGlCQUFBO0FBQ3BELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsT0FBQSxlQUFBLDRCQUFBLENBQUE7Ozs7OztBQS9DcEIsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUFRLElBQUEseUJBQUEsU0FBQSxTQUFBLHlFQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLGVBQUEsNEJBQUEsQ0FBNEM7SUFBQSxDQUFBO0FBQ3pELElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEQsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQThCLElBQUEsMkJBQUE7QUFDOUYsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSwrQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUErRCxJQUFBLHFCQUFBLElBQUEsZUFBQTtBQUFhLElBQUEsMkJBQUE7QUFDNUUsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUE2RCxJQUFBLHlCQUFBLFVBQUEsU0FBQSx3RUFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBVSwwQkFBQSxRQUFBLGVBQUEsZ0JBQUEsTUFBQSxDQUFzQztJQUFBLENBQUE7QUFBN0csSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQVEsSUFBQSx5QkFBQSxTQUFBLFNBQUEsMEVBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsZUFBQSx3QkFBQSxDQUF3QztJQUFBLENBQUE7QUFDckQsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUErRCxJQUFBLHFCQUFBLElBQUEsZUFBQTtBQUFhLElBQUEsMkJBQUE7QUFDaEYsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUEwQyxJQUFBLHFCQUFBLEVBQUE7OztBQUV4QyxJQUFBLDJCQUFBO0FBQ0YsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLCtEQUFBLEdBQUEsQ0FBQSxFQUVDLElBQUEsK0RBQUEsR0FBQSxDQUFBO0FBSUQsSUFBQSw2QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUEwQyxJQUFBLHlCQUFBLGlCQUFBLFNBQUEsK0VBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQWEsMEJBQUEsUUFBQSxlQUFBLFlBQUEsTUFBQTtJQUFnQyxDQUFBLEVBQVAsVUFBQSxTQUFBLDBFQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBbUIsMEJBQUEsUUFBQSxlQUFBLGtCQUFBLFFBQUEsZUFBQSxTQUFBLENBQTBEO0lBQUEsQ0FBQTtBQUE3SixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQWtHLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQVUsSUFBQSwyQkFBQTtBQUM1RyxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQTRCLElBQUEseUJBQUEsaUJBQUEsU0FBQSxnRkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBYSwwQkFBQSxRQUFBLGVBQUEsYUFBQSxZQUFBLE1BQUE7SUFBNkMsQ0FBQSxFQUFQLFVBQUEsU0FBQSwyRUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQVcsMEJBQUEsUUFBQSxlQUFBLGlCQUFBLENBQWlDO0lBQUEsQ0FBQTtBQUN2SCxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQThFLElBQUEscUJBQUEsSUFBQSxPQUFBO0FBQUssSUFBQSwyQkFBQTtBQUNuRixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQThFLElBQUEscUJBQUEsSUFBQSxPQUFBO0FBQUssSUFBQSwyQkFBQTtBQUN2RixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQW9HLElBQUEscUJBQUEsSUFBQSxhQUFBO0FBQVcsSUFBQSwyQkFBQTtBQUMvRyxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQTRCLElBQUEseUJBQUEsaUJBQUEsU0FBQSxnRkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBYSwwQkFBQSxRQUFBLGVBQUEsd0JBQUEsTUFBQTtJQUE0QyxDQUFBLEVBQVAsaUJBQUEsU0FBQSxrRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQWtCLDBCQUFBLFFBQUEsZUFBQSxlQUFBLENBQStCO0lBQUEsQ0FBQTtBQUMzSCxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQW1GLElBQUEscUJBQUEsSUFBQSx1QkFBQTtBQUFxQixJQUFBLDJCQUFBO0FBQ3hHLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBb0YsSUFBQSxxQkFBQSxJQUFBLHVCQUFBO0FBQXFCLElBQUEsMkJBQUE7QUFDN0csSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLCtEQUFBLEdBQUEsQ0FBQTtBQVVKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxvQ0FBQSxFQUFBO0FBSUosSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLElBQUE7Ozs7QUEzQzBELElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEsZ0NBQUEsT0FBQSxTQUFBLDBCQUFBLElBQUEsSUFBQSwyQ0FBQSxJQUFBLDBCQUFBLElBQUEsSUFBQSxtQ0FBQSxDQUFBO0FBRzFDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxDQUFBLE9BQUEsU0FBQSxLQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxTQUFBLEtBQUEsRUFBQTtBQUcwQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsT0FBQSxlQUFBLFNBQUE7QUFJZCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsT0FBQSxlQUFBLGFBQUEsU0FBQTtBQU9BLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxPQUFBLGVBQUEscUJBQUE7QUFDaEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLElBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsS0FBQTtBQUlaLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLGVBQUEsYUFBQSxjQUFBLE9BQUEsVUFBQSxRQUFBLEtBQUEsRUFBQTtBQWFKLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsZ0JBQUEsT0FBQSxlQUFBLFlBQUEsRUFBNEMsdUJBQUEsT0FBQSxlQUFBLG1CQUFBOzs7QURqRXhELElBWWE7QUFaYjs7QUFHQTs7Ozs7OztBQVNNLElBQU8seUJBQVAsTUFBTyx3QkFBc0I7TUFhWDtNQVpYLFlBQVk7TUFFckI7TUFDQTtNQUNBLFNBQVM7TUFDVDtNQUVTLG9CQUF1QztNQUd2Qyx3QkFBd0I7TUFFakMsWUFBb0IsT0FBcUI7QUFBckIsYUFBQSxRQUFBO01BQXdCO01BRTVDLFdBQVE7QUFDSixhQUFLLE1BQU0sT0FBTyxVQUFVLENBQUMsV0FBVTtBQUNuQyxlQUFLLFdBQVcsT0FBTyxPQUFPLFVBQVUsQ0FBQztBQUN6QyxjQUFJLE9BQU8sUUFBUSxHQUFHO0FBQ2xCLGlCQUFLLFNBQVMsT0FBTyxPQUFPLFFBQVEsQ0FBQztBQUNyQyxpQkFBSyxTQUFTOztRQUV0QixDQUFDO01BQ0w7TUFPQSxnQkFBZ0IsVUFBb0M7QUFDaEQsYUFBSyxpQkFBaUI7TUFDMUI7O3lCQWhDUyx5QkFBc0IsZ0NBQUEsa0JBQUEsQ0FBQTtNQUFBO2lFQUF0Qix5QkFBc0IsV0FBQSxDQUFBLENBQUEsb0JBQUEsQ0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxVQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLE1BQUEsV0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxXQUFBLEdBQUEsQ0FBQSxjQUFBLFlBQUEsb0JBQUEsVUFBQSxHQUFBLFlBQUEsVUFBQSxHQUFBLENBQUEsY0FBQSxZQUFBLG9CQUFBLFVBQUEsR0FBQSxZQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsdUJBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxPQUFBLGVBQUEsUUFBQSxRQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEsd0NBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxPQUFBLGVBQUEsUUFBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSwyQ0FBQSxHQUFBLENBQUEsUUFBQSxRQUFBLFVBQUEsY0FBQSxHQUFBLFdBQUEsUUFBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLE9BQUEsZUFBQSxRQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEsMkNBQUEsR0FBQSxDQUFBLEdBQUEsb0JBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxnQkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLE9BQUEsS0FBQSxHQUFBLGdCQUFBLEdBQUEsV0FBQSxpQkFBQSxRQUFBLEdBQUEsQ0FBQSxnQkFBQSw0Q0FBQSxHQUFBLGdCQUFBLGdCQUFBLEdBQUEsQ0FBQSxTQUFBLGNBQUEsR0FBQSxlQUFBLEdBQUEsV0FBQSxpQkFBQSxRQUFBLEdBQUEsQ0FBQSxTQUFBLFNBQUEsZ0JBQUEsMENBQUEsR0FBQSxDQUFBLFNBQUEsU0FBQSxnQkFBQSwwQ0FBQSxHQUFBLENBQUEsZ0JBQUEsOENBQUEsR0FBQSxnQkFBQSxnQkFBQSxHQUFBLENBQUEsU0FBQSxlQUFBLEdBQUEsZUFBQSxHQUFBLFdBQUEsZUFBQSxHQUFBLENBQUEsZ0JBQUEsOENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxnQkFBQSw4Q0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEscUJBQUEsR0FBQSxDQUFBLFFBQUEsa0NBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxRQUFBLFlBQUEsR0FBQSxDQUFBLGdCQUFBLDhDQUFBLEdBQUEsZ0JBQUEsZ0JBQUEsR0FBQSxDQUFBLFNBQUEsdUJBQUEsR0FBQSxlQUFBLEdBQUEsV0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxnQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1puQyxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLFVBQUEscUJBQUEsQ0FBQTs7O0FBRUosVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx3QkFBQSxHQUFBLDRCQUFBLENBQUE7QUFDSixVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxnREFBQSxJQUFBLEVBQUE7QUErREEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLEtBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxFQUFBOztBQUNKLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxFQUFBOztBQUNKLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxpQkFBQSxDQUFBO0FBQWUsVUFBQSx5QkFBQSxZQUFBLFNBQUEsbUVBQUEsUUFBQTtBQUFBLG1CQUFZLElBQUEsZ0JBQUEsTUFBQTtVQUF1QixDQUFBO0FBQUUsVUFBQSwyQkFBQTtBQUN4RCxVQUFBLHFCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBbkZRLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsaUNBQUEsY0FBQSxJQUFBLFNBQUEsMEJBQUEsR0FBQSxHQUFBLG9DQUFBLElBQUEsMEJBQUEsR0FBQSxHQUFBLHNDQUFBLEdBQUEsY0FBQSxJQUFBLFNBQUEsSUFBQSxrQkFBQSxPQUFBLE9BQUEsSUFBQSxlQUFBLFFBQUEsT0FBQSxPQUFBLElBQUEsZUFBQSxLQUFBLFFBQUEsSUFBQSxrQkFBQSxPQUFBLE9BQUEsSUFBQSxlQUFBLFVBQUEsT0FBQSxPQUFBLElBQUEsZUFBQSxPQUFBLE9BQUEsUUFBQTtBQUdzQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxpQkFBQTtBQUU5QixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxpQkFBQSxLQUFBLEVBQUE7QUFtRWdCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsaUNBQUEsc0JBQUEsMEJBQUEsSUFBQSxJQUFBLDRDQUFBLEdBQUEsZ0JBQUE7QUFHQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLHNCQUFBLDBCQUFBLElBQUEsSUFBQSw0Q0FBQSxHQUFBLGdCQUFBOzs7OztxRkRqRUgsd0JBQXNCLEVBQUEsV0FBQSx5QkFBQSxDQUFBO0lBQUEsR0FBQTs7OyIsIm5hbWVzIjpbIkNvbXBvbmVudCJdfQ==