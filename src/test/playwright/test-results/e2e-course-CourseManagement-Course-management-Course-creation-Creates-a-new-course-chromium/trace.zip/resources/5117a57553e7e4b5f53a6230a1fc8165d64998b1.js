import {
  FileUploadAssessmentService,
  init_file_upload_assessment_service
} from "/chunk-GXWDNQUC.js";
import {
  ArtemisFeedbackModule,
  FeedbackSuggestionBadgeComponent,
  init_feedback_module,
  init_feedback_suggestion_badge_component
} from "/chunk-K5HEFVC3.js";
import {
  TextAssessmentService,
  init_text_assessment_service
} from "/chunk-DFLF6UGC.js";
import {
  ComplaintType,
  TextareaCounterComponent,
  TextareaModule,
  init_complaint_model,
  init_textarea_counter_component,
  init_textarea_module
} from "/chunk-DBGVWL5C.js";
import {
  ProgrammingAssessmentManualResultService,
  init_programming_assessment_manual_result_service
} from "/chunk-XIMSG2TX.js";
import {
  ComplaintService,
  init_complaint_service
} from "/chunk-G2ISVTQO.js";
import {
  ArtemisMarkdownModule,
  init_markdown_module
} from "/chunk-UF4UUZTK.js";
import {
  ArtemisSharedComponentModule,
  init_result_model,
  init_shared_component_module
} from "/chunk-ORYTP7RT.js";
import {
  UserRouteAccessService,
  init_user_route_access_service
} from "/chunk-KQ77WIWP.js";
import {
  AccountService,
  AlertService,
  ArtemisDatePipe,
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  AssessmentType,
  AssessmentWarningComponent,
  Authority,
  ButtonSize,
  ComplaintResponseService,
  Course,
  CourseManagementService,
  DeleteButtonDirective,
  ExamManagementService,
  ExerciseType,
  FEEDBACK_SUGGESTION_ACCEPTED_IDENTIFIER,
  FEEDBACK_SUGGESTION_IDENTIFIER,
  Feedback,
  FeedbackType,
  ProfileService,
  TranslateDirective,
  __esm,
  convertDateFromServer,
  getCourseFromExercise,
  getIcon,
  getIconTooltip,
  init_account_service,
  init_alert_service,
  init_artemis_date_pipe,
  init_artemis_translate_pipe,
  init_assessment_type_model,
  init_assessment_warning_component,
  init_authority_constants,
  init_button_component,
  init_complaint_response_service,
  init_course_management_service,
  init_course_model,
  init_date_utils,
  init_delete_button_directive,
  init_exam_management_service,
  init_exercise_model,
  init_feedback_model,
  init_profile_service,
  init_shared_module,
  init_submission_model,
  init_translate_directive,
  init_utils,
  roundScorePercentSpecifiedByCourseSettings,
  roundValueSpecifiedByCourseSettings
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/entities/complaint-response.model.ts
var ComplaintResponse;
var init_complaint_response_model = __esm({
  "src/main/webapp/app/entities/complaint-response.model.ts"() {
    ComplaintResponse = class {
      id;
      responseText;
      submittedTime;
      complaint;
      reviewer;
      isCurrentlyLocked;
      lockEndDate;
      constructor() {
      }
    };
  }
});

// src/main/webapp/app/exercises/shared/navigate-back.util.ts
function assessmentNavigateBack(location, router, exercise, submission, isTestRun = false) {
  if (exercise) {
    const course = getCourseFromExercise(exercise);
    if (isTestRun) {
      const exam = exercise.exerciseGroup.exam;
      router.navigateByUrl(`/course-management/${course?.id}/exams/${exam.id}/test-assessment-dashboard/${exercise.id}`);
    } else {
      if (exercise.exerciseGroup) {
        const exam = exercise.exerciseGroup.exam;
        router.navigateByUrl(`/course-management/${course?.id}/exams/${exam.id}/assessment-dashboard/${exercise.id}`);
      } else if (exercise.teamMode && submission) {
        const teamId = submission.participation.team?.id;
        router.navigateByUrl(`/courses/${course?.id}/exercises/${exercise.id}/teams/${teamId}`);
      } else {
        router.navigateByUrl(`/course-management/${course?.id}/assessment-dashboard/${exercise.id}`);
      }
    }
  } else {
    location.back();
  }
}
var init_navigate_back_util = __esm({
  "src/main/webapp/app/exercises/shared/navigate-back.util.ts"() {
    init_exercise_model();
  }
});

// src/main/webapp/app/assessment/assessment.service.ts
var isAllowedToRespondToComplaintAction, isAllowedToModifyFeedback;
var init_assessment_service = __esm({
  "src/main/webapp/app/assessment/assessment.service.ts"() {
    init_complaint_model();
    init_assessment_type_model();
    isAllowedToRespondToComplaintAction = (isTestRun, isAssessor, complaint, exercise) => {
      if (exercise?.isAtLeastInstructor) {
        return true;
      }
      if (exercise?.teamMode || isTestRun) {
        return isAssessor;
      }
      if (exercise?.assessmentType === AssessmentType.AUTOMATIC && complaint.result && complaint.result.assessor === void 0) {
        return true;
      }
      return complaint.complaintType === ComplaintType.COMPLAINT ? !isAssessor : isAssessor;
    };
    isAllowedToModifyFeedback = (isTestRun, isAssessor, hasAssessmentDueDatePassed, result, complaint, exercise) => {
      if (exercise?.isAtLeastInstructor) {
        return true;
      }
      if (!result) {
        return false;
      }
      if (!result.completionDate) {
        return true;
      }
      if (complaint) {
        return complaint.complaintType === ComplaintType.COMPLAINT && isAllowedToRespondToComplaintAction(isTestRun, isAssessor, complaint, exercise);
      }
      return !hasAssessmentDueDatePassed;
    };
  }
});

// src/main/webapp/app/complaints/complaints-for-tutor/complaints-for-tutor.component.ts
import { Component, EventEmitter, Input, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { finalize } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { ActivatedRoute, Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { Location } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
function ComplaintsForTutorComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "div", 0);
    i0.\u0275\u0275text(2, "\n        ");
    i0.\u0275\u0275elementStart(3, "div", 1);
    i0.\u0275\u0275text(4, "\n            ");
    i0.\u0275\u0275elementStart(5, "span", 2);
    i0.\u0275\u0275text(6);
    i0.\u0275\u0275pipe(7, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(7, 1, "loading"));
  }
}
function ComplaintsForTutorComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "h3");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275pipe(4, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n        ", ctx_r1.complaint.complaintType === ctx_r1.ComplaintType.MORE_FEEDBACK ? i0.\u0275\u0275pipeBind1(3, 1, "artemisApp.moreFeedback.review") : i0.\u0275\u0275pipeBind1(4, 3, "artemisApp.complaint.review"), "\n    ");
  }
}
function ComplaintsForTutorComponent_Conditional_2_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275elementStart(1, "div", 8);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275pipe(4, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r3 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n                ", ctx_r3.complaint.complaintType === ctx_r3.ComplaintType.MORE_FEEDBACK ? i0.\u0275\u0275pipeBind1(3, 1, "artemisApp.moreFeedback.alreadyHandled") : i0.\u0275\u0275pipeBind1(4, 3, "artemisApp.complaint.complaintAlreadyHandled"), "\n            ");
  }
}
function ComplaintsForTutorComponent_Conditional_2_Conditional_6_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0);
    i0.\u0275\u0275pipe(1, "artemisTranslate");
    i0.\u0275\u0275pipe(2, "artemisDate");
  }
  if (rf & 2) {
    const ctx_r8 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275textInterpolate1("\n                        ", i0.\u0275\u0275pipeBind2(1, 1, "artemisApp.locks.lockInformationYou", i0.\u0275\u0275pureFunction1(6, _c0, i0.\u0275\u0275pipeBind1(2, 4, ctx_r8.complaintResponse.lockEndDate))), "\n                    ");
  }
}
function ComplaintsForTutorComponent_Conditional_2_Conditional_6_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0);
    i0.\u0275\u0275pipe(1, "artemisTranslate");
    i0.\u0275\u0275pipe(2, "artemisDate");
  }
  if (rf & 2) {
    const ctx_r9 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275textInterpolate1("\n                        ", i0.\u0275\u0275pipeBind2(1, 1, "artemisApp.locks.lockInformation", i0.\u0275\u0275pureFunction2(6, _c1, ctx_r9.complaintResponse == null ? null : ctx_r9.complaintResponse.reviewer == null ? null : ctx_r9.complaintResponse.reviewer.login, i0.\u0275\u0275pipeBind1(2, 4, ctx_r9.complaintResponse.lockEndDate))), "\n                    ");
  }
}
function ComplaintsForTutorComponent_Conditional_2_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                ");
    i0.\u0275\u0275elementStart(1, "div", 9);
    i0.\u0275\u0275text(2, "\n                    ");
    i0.\u0275\u0275template(3, ComplaintsForTutorComponent_Conditional_2_Conditional_6_Conditional_3_Template, 3, 8)(4, ComplaintsForTutorComponent_Conditional_2_Conditional_6_Conditional_4_Template, 3, 9);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r4 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(3, ctx_r4.lockedByCurrentUser ? 3 : 4);
  }
}
function ComplaintsForTutorComponent_Conditional_2_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                ");
    i0.\u0275\u0275elementStart(1, "button", 10);
    i0.\u0275\u0275listener("click", function ComplaintsForTutorComponent_Conditional_2_Conditional_7_Template_button_click_1_listener() {
      i0.\u0275\u0275restoreView(_r11);
      const ctx_r10 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r10.removeLock());
    });
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n                    ", i0.\u0275\u0275pipeBind1(3, 1, "artemisApp.locks.removeButton"), "\n                ");
  }
}
function ComplaintsForTutorComponent_Conditional_2_Conditional_20_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                                ");
    i0.\u0275\u0275elementStart(1, "span", 11);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275pipe(4, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r12 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n                                    \xA0", ctx_r12.complaint.complaintType === ctx_r12.ComplaintType.MORE_FEEDBACK ? i0.\u0275\u0275pipeBind1(3, 1, "artemisApp.moreFeedback.accepted") : i0.\u0275\u0275pipeBind1(4, 3, "artemisApp.complaint.accepted"), "\xA0\n                                ");
  }
}
function ComplaintsForTutorComponent_Conditional_2_Conditional_20_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                                ");
    i0.\u0275\u0275elementStart(1, "span", 12);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" \xA0", i0.\u0275\u0275pipeBind1(3, 1, "artemisApp.complaint.rejected"), "\xA0 ");
  }
}
function ComplaintsForTutorComponent_Conditional_2_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "small");
    i0.\u0275\u0275text(2, "\n                            ");
    i0.\u0275\u0275template(3, ComplaintsForTutorComponent_Conditional_2_Conditional_20_Conditional_3_Template, 6, 5)(4, ComplaintsForTutorComponent_Conditional_2_Conditional_20_Conditional_4_Template, 5, 3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r6 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(3, (ctx_r6.complaint == null ? null : ctx_r6.complaint.accepted) ? 3 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(4, !(ctx_r6.complaint == null ? null : ctx_r6.complaint.accepted) ? 4 : -1);
  }
}
function ComplaintsForTutorComponent_Conditional_2_Conditional_25_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "div", 16);
    i0.\u0275\u0275text(2, "\n                            ");
    i0.\u0275\u0275elementStart(3, "button", 17);
    i0.\u0275\u0275listener("click", function ComplaintsForTutorComponent_Conditional_2_Conditional_25_Conditional_17_Template_button_click_3_listener() {
      i0.\u0275\u0275restoreView(_r17);
      const ctx_r16 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r16.respondToComplaint(true));
    });
    i0.\u0275\u0275pipe(4, "artemisTranslate");
    i0.\u0275\u0275text(5);
    i0.\u0275\u0275pipe(6, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                            ");
    i0.\u0275\u0275elementStart(8, "button", 18);
    i0.\u0275\u0275listener("click", function ComplaintsForTutorComponent_Conditional_2_Conditional_25_Conditional_17_Template_button_click_8_listener() {
      i0.\u0275\u0275restoreView(_r17);
      const ctx_r18 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r18.respondToComplaint(false));
    });
    i0.\u0275\u0275pipe(9, "artemisTranslate");
    i0.\u0275\u0275text(10);
    i0.\u0275\u0275pipe(11, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12, "\n                            ");
    i0.\u0275\u0275text(13, "\n                            ");
    i0.\u0275\u0275element(14, "div", 19);
    i0.\u0275\u0275text(15, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(16, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r14 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275propertyInterpolate("title", i0.\u0275\u0275pipeBind1(4, 6, "artemisApp.complaintResponse.updateAssessmentTooltip"));
    i0.\u0275\u0275property("disabled", ctx_r14.isLockedForLoggedInUser || ctx_r14.complaintResponseTextLength() > ctx_r14.maxComplaintResponseTextLimit);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n                                ", i0.\u0275\u0275pipeBind1(6, 8, "artemisApp.complaintResponse.updateAssessment"), "\n                            ");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275propertyInterpolate("title", i0.\u0275\u0275pipeBind1(9, 10, "artemisApp.complaintResponse.rejectComplaintTooltip"));
    i0.\u0275\u0275property("disabled", ctx_r14.isLockedForLoggedInUser || ctx_r14.complaintResponseTextLength() > ctx_r14.maxComplaintResponseTextLimit);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n                                ", i0.\u0275\u0275pipeBind1(11, 12, "artemisApp.complaintResponse.rejectComplaint"), "\n                            ");
  }
}
function ComplaintsForTutorComponent_Conditional_2_Conditional_25_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "div", 20);
    i0.\u0275\u0275text(2, "\n                            ");
    i0.\u0275\u0275elementStart(3, "div", 21);
    i0.\u0275\u0275text(4, "\n                                ");
    i0.\u0275\u0275elementStart(5, "button", 22);
    i0.\u0275\u0275listener("click", function ComplaintsForTutorComponent_Conditional_2_Conditional_25_Conditional_18_Template_button_click_5_listener() {
      i0.\u0275\u0275restoreView(_r20);
      const ctx_r19 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r19.respondToComplaint(true));
    });
    i0.\u0275\u0275pipe(6, "artemisTranslate");
    i0.\u0275\u0275text(7);
    i0.\u0275\u0275pipe(8, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r15 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275propertyInterpolate("title", i0.\u0275\u0275pipeBind1(6, 3, "artemisApp.moreFeedbackResponse.sendResponseTooltip"));
    i0.\u0275\u0275property("disabled", ctx_r15.isLockedForLoggedInUser);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n                                    ", i0.\u0275\u0275pipeBind1(8, 5, "artemisApp.moreFeedbackResponse.provideFeedback"), "\n                                ");
  }
}
function ComplaintsForTutorComponent_Conditional_2_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                ");
    i0.\u0275\u0275elementStart(1, "div", 6);
    i0.\u0275\u0275text(2, "\n                    ");
    i0.\u0275\u0275elementStart(3, "h3");
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275pipe(5, "artemisTranslate");
    i0.\u0275\u0275pipe(6, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                    ");
    i0.\u0275\u0275elementStart(8, "div", 13);
    i0.\u0275\u0275text(9, "\n                        ");
    i0.\u0275\u0275elementStart(10, "textarea", 14);
    i0.\u0275\u0275listener("ngModelChange", function ComplaintsForTutorComponent_Conditional_2_Conditional_25_Template_textarea_ngModelChange_10_listener($event) {
      i0.\u0275\u0275restoreView(_r22);
      const ctx_r21 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r21.complaintResponse.responseText = $event);
    });
    i0.\u0275\u0275text(11, "                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12, "\n                        ");
    i0.\u0275\u0275elementStart(13, "jhi-textarea-counter", 15);
    i0.\u0275\u0275text(14, " ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(15, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(16, "\n                    ");
    i0.\u0275\u0275template(17, ComplaintsForTutorComponent_Conditional_2_Conditional_25_Conditional_17_Template, 17, 14)(18, ComplaintsForTutorComponent_Conditional_2_Conditional_25_Conditional_18_Template, 12, 7);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(19, "\n            ");
  }
  if (rf & 2) {
    const ctx_r7 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate1("\n                        ", ctx_r7.complaint.complaintType === ctx_r7.ComplaintType.MORE_FEEDBACK ? i0.\u0275\u0275pipeBind1(5, 10, "artemisApp.moreFeedbackResponse.title") : i0.\u0275\u0275pipeBind1(6, 12, "artemisApp.complaintResponse.title"), "\n                    ");
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275property("maxlength", ctx_r7.maxComplaintResponseTextLimit)("ngModel", ctx_r7.complaintResponse.responseText)("readonly", ctx_r7.handled || ctx_r7.isLockedForLoggedInUser)("disabled", ctx_r7.handled || ctx_r7.isLockedForLoggedInUser);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("maxLength", ctx_r7.maxComplaintResponseTextLimit)("content", ctx_r7.complaintResponse.responseText)("visible", !ctx_r7.handled);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275conditional(17, !ctx_r7.handled && ctx_r7.complaint.complaintType === ctx_r7.ComplaintType.COMPLAINT ? 17 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(18, !ctx_r7.complaint.accepted && ctx_r7.complaint.complaintType === ctx_r7.ComplaintType.MORE_FEEDBACK ? 18 : -1);
  }
}
function ComplaintsForTutorComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "div", 3);
    i0.\u0275\u0275text(2, "\n        ");
    i0.\u0275\u0275template(3, ComplaintsForTutorComponent_Conditional_2_Conditional_3_Template, 6, 5);
    i0.\u0275\u0275elementStart(4, "div", 4);
    i0.\u0275\u0275text(5, "\n            ");
    i0.\u0275\u0275template(6, ComplaintsForTutorComponent_Conditional_2_Conditional_6_Template, 6, 1)(7, ComplaintsForTutorComponent_Conditional_2_Conditional_7_Template, 5, 3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n        ");
    i0.\u0275\u0275elementStart(9, "div", 5);
    i0.\u0275\u0275text(10, "\n            ");
    i0.\u0275\u0275elementStart(11, "div", 6);
    i0.\u0275\u0275text(12, "\n                ");
    i0.\u0275\u0275elementStart(13, "h4");
    i0.\u0275\u0275text(14, "\n                    ");
    i0.\u0275\u0275elementStart(15, "span");
    i0.\u0275\u0275text(16);
    i0.\u0275\u0275pipe(17, "artemisTranslate");
    i0.\u0275\u0275pipe(18, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(19, "\n                    ");
    i0.\u0275\u0275template(20, ComplaintsForTutorComponent_Conditional_2_Conditional_20_Template, 6, 2);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(21, "\n                ");
    i0.\u0275\u0275elementStart(22, "textarea", 7);
    i0.\u0275\u0275listener("ngModelChange", function ComplaintsForTutorComponent_Conditional_2_Template_textarea_ngModelChange_22_listener($event) {
      i0.\u0275\u0275restoreView(_r24);
      const ctx_r23 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r23.complaintText = $event);
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(23, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(24, "\n            ");
    i0.\u0275\u0275template(25, ComplaintsForTutorComponent_Conditional_2_Conditional_25_Template, 20, 14);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(26, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(27, "\n");
  }
  if (rf & 2) {
    const ctx_r2 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275classProp("px-0", ctx_r2.zeroIndent);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(3, ctx_r2.handled ? 3 : -1);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(6, ctx_r2.showLockDuration ? 6 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(7, ctx_r2.lockedByCurrentUser ? 7 : -1);
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275textInterpolate1("", ctx_r2.complaint.complaintType === ctx_r2.ComplaintType.MORE_FEEDBACK ? i0.\u0275\u0275pipeBind1(17, 11, "artemisApp.moreFeedback.title") : i0.\u0275\u0275pipeBind1(18, 13, "artemisApp.complaint.title"), "\n                    ");
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275conditional(20, ctx_r2.handled ? 20 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("ngModel", ctx_r2.complaintText)("readonly", true)("disabled", true);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(25, ctx_r2.handled || ctx_r2.isAllowedToRespond ? 25 : -1);
  }
}
var _c0, _c1, ComplaintsForTutorComponent;
var init_complaints_for_tutor_component = __esm({
  "src/main/webapp/app/complaints/complaints-for-tutor/complaints-for-tutor.component.ts"() {
    init_alert_service();
    init_complaint_response_service();
    init_complaint_response_model();
    init_complaint_model();
    init_exercise_model();
    init_navigate_back_util();
    init_assessment_service();
    init_alert_service();
    init_complaint_response_service();
    init_textarea_counter_component();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    _c0 = (a0) => ({ endDate: a0 });
    _c1 = (a0, a1) => ({ user: a0, endDate: a1 });
    ComplaintsForTutorComponent = class _ComplaintsForTutorComponent {
      alertService;
      complaintResponseService;
      activatedRoute;
      router;
      location;
      complaint;
      isTestRun = false;
      isAssessor = false;
      zeroIndent = true;
      exercise;
      submission;
      updateAssessmentAfterComplaint = new EventEmitter();
      complaintText;
      handled;
      complaintResponse = new ComplaintResponse();
      ComplaintType = ComplaintType;
      isLoading = false;
      showLockDuration = false;
      lockedByCurrentUser = false;
      isLockedForLoggedInUser = false;
      course;
      maxComplaintResponseTextLimit;
      constructor(alertService, complaintResponseService, activatedRoute, router, location) {
        this.alertService = alertService;
        this.complaintResponseService = complaintResponseService;
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.location = location;
      }
      ngOnInit() {
        this.course = getCourseFromExercise(this.exercise);
        this.maxComplaintResponseTextLimit = this.course?.maxComplaintResponseTextLimit ?? 0;
        if (this.exercise?.exerciseGroup) {
          this.maxComplaintResponseTextLimit = Math.max(2e3, this.maxComplaintResponseTextLimit);
        }
        if (this.complaint) {
          this.complaintText = this.complaint.complaintText;
          this.handled = this.complaint.accepted !== void 0;
          if (this.handled) {
            this.complaintResponse = this.complaint.complaintResponse;
            this.lockedByCurrentUser = false;
            this.showLockDuration = false;
          } else {
            if (this.isAllowedToRespond) {
              if (this.complaint.complaintResponse) {
                this.refreshLock();
              } else {
                this.createLock();
              }
            } else {
              this.alertService.error("artemisApp.locks.notAllowedToRespond");
            }
          }
        }
      }
      createLock() {
        this.isLoading = true;
        this.complaintResponseService.createLock(this.complaint.id).pipe(finalize(() => {
          this.isLoading = false;
        })).subscribe({
          next: (response) => {
            this.complaintResponse = response.body;
            this.complaint = this.complaintResponse.complaint;
            this.lockedByCurrentUser = true;
            this.showLockDuration = true;
            this.alertService.success("artemisApp.locks.acquired");
          },
          error: (err) => {
            this.onError(err);
          }
        });
      }
      refreshLock() {
        this.complaintResponse = this.complaint.complaintResponse;
        this.showLockDuration = true;
        this.isLockedForLoggedInUser = this.complaintResponseService.isComplaintResponseLockedForLoggedInUser(this.complaintResponse, this.exercise);
        if (!this.isLockedForLoggedInUser) {
          this.isLoading = true;
          this.complaintResponseService.refreshLock(this.complaint.id).pipe(finalize(() => {
            this.isLoading = false;
          })).subscribe({
            next: (response) => {
              this.complaintResponse = response.body;
              this.complaint = this.complaintResponse.complaint;
              this.lockedByCurrentUser = true;
              this.alertService.success("artemisApp.locks.acquired");
            },
            error: (err) => {
              this.onError(err);
            }
          });
        } else {
          this.lockedByCurrentUser = false;
        }
      }
      navigateBack() {
        assessmentNavigateBack(this.location, this.router, this.exercise, this.submission, this.isTestRun);
      }
      removeLock() {
        this.complaintResponseService.removeLock(this.complaint.id).subscribe({
          next: () => {
            this.alertService.success("artemisApp.locks.lockRemoved");
            this.navigateBack();
          },
          error: (err) => {
            this.onError(err);
          }
        });
      }
      respondToComplaint(acceptComplaint) {
        if (!this.complaintResponse.responseText || this.complaintResponse.responseText.length <= 0) {
          this.alertService.error("artemisApp.complaintResponse.noText");
          return;
        }
        if (this.complaintResponse.responseText.length > this.maxComplaintResponseTextLimit) {
          this.alertService.error("artemisApp.complaint.exceededComplaintResponseTextLimit", {
            maxComplaintRespondTextLimit: this.maxComplaintResponseTextLimit
          });
          return;
        }
        if (!this.isAllowedToRespond) {
          return;
        }
        this.complaintResponse.complaint = this.complaint;
        this.complaintResponse.complaint.complaintResponse = void 0;
        this.complaintResponse.complaint.accepted = acceptComplaint;
        if (acceptComplaint && this.complaint.complaintType === ComplaintType.COMPLAINT) {
          this.isLoading = true;
          this.updateAssessmentAfterComplaint.emit({
            complaintResponse: this.complaintResponse,
            onSuccess: () => {
              this.isLoading = false;
              this.handled = true;
              this.showLockDuration = false;
              this.lockedByCurrentUser = false;
            },
            onError: () => {
              this.isLoading = false;
            }
          });
        } else {
          this.resolveComplaint();
        }
      }
      resolveComplaint() {
        this.isLoading = true;
        this.complaintResponseService.resolveComplaint(this.complaintResponse).pipe(finalize(() => {
          this.isLoading = false;
        })).subscribe({
          next: (response) => {
            this.handled = true;
            if (this.complaint.complaintType === ComplaintType.MORE_FEEDBACK) {
              this.alertService.success("artemisApp.moreFeedbackResponse.created");
            } else {
              this.alertService.success("artemisApp.complaintResponse.created");
            }
            this.complaintResponse = response.body;
            this.complaint = this.complaintResponse.complaint;
            this.isLockedForLoggedInUser = false;
            this.showLockDuration = false;
            this.lockedByCurrentUser = false;
          },
          error: (err) => {
            this.onError(err);
          }
        });
      }
      onError(httpErrorResponse) {
        const error = httpErrorResponse.error;
        if (error && error.errorKey && error.errorKey === "complaintLock") {
          this.alertService.error(error.message, error.params);
        } else {
          this.alertService.error("error.unexpectedError", {
            error: httpErrorResponse.message
          });
        }
      }
      get isAllowedToRespond() {
        return isAllowedToRespondToComplaintAction(this.isTestRun, this.isAssessor, this.complaint, this.exercise);
      }
      complaintResponseTextLength() {
        const textArea = document.querySelector("#responseTextArea");
        return textArea.value.length;
      }
      static \u0275fac = function ComplaintsForTutorComponent_Factory(t) {
        return new (t || _ComplaintsForTutorComponent)(i0.\u0275\u0275directiveInject(AlertService), i0.\u0275\u0275directiveInject(ComplaintResponseService), i0.\u0275\u0275directiveInject(i3.ActivatedRoute), i0.\u0275\u0275directiveInject(i3.Router), i0.\u0275\u0275directiveInject(i4.Location));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _ComplaintsForTutorComponent, selectors: [["jhi-complaints-for-tutor-form"]], inputs: { complaint: "complaint", isTestRun: "isTestRun", isAssessor: "isAssessor", zeroIndent: "zeroIndent", exercise: "exercise", submission: "submission" }, outputs: { updateAssessmentAfterComplaint: "updateAssessmentAfterComplaint" }, features: [i0.\u0275\u0275ProvidersFeature([])], decls: 3, vars: 3, consts: [[1, "d-flex", "justify-content-center"], ["role", "status", 1, "spinner-border"], [1, "sr-only"], [1, "col-12", "mt-2"], [1, "mt-3", "mb-3"], [1, "row"], [1, "col-12", "col-md-6"], ["id", "complaintTextArea", "rows", "4", 1, "col-12", "px-1", 3, "ngModel", "readonly", "disabled", "ngModelChange"], [1, "alert", "alert-info"], ["id", "lockDuration", 1, "alert", "alert-info"], ["id", "lockButton", 1, "btn", "btn-secondary", 3, "click"], [1, "badge", "bg-success"], [1, "badge", "bg-danger"], [1, "d-flex", "flex-column"], ["id", "responseTextArea", "rows", "4", "ondrop", "return false;", 1, "col-12", "px-1", 3, "maxlength", "ngModel", "readonly", "disabled", "ngModelChange"], [3, "maxLength", "content", "visible"], [1, "d-flex", "flex-wrap", "gap-1", "justify-content-between", "mt-1"], ["id", "acceptComplaintButton", "type", "button", 1, "btn", "btn-success", "btn-block", 3, "disabled", "title", "click"], ["id", "rejectComplaintButton", "type", "button", 1, "btn", "btn-danger", "btn-block", 3, "disabled", "title", "click"], [1, "d-none", "d-sm-block"], [1, "row", "justify-content-end", "mt-3"], [1, "col-12"], ["id", "respondToMoreFeedbackButton", "type", "button", 1, "btn", "btn-success", "btn-block", 3, "disabled", "title", "click"]], template: function ComplaintsForTutorComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275template(0, ComplaintsForTutorComponent_Conditional_0_Template, 11, 3)(1, ComplaintsForTutorComponent_Conditional_1_Template, 6, 5)(2, ComplaintsForTutorComponent_Conditional_2_Template, 28, 15);
        }
        if (rf & 2) {
          i0.\u0275\u0275conditional(0, ctx.isLoading ? 0 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275conditional(1, !ctx.isLoading && ctx.complaint ? 1 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275conditional(2, !ctx.isLoading && ctx.complaint ? 2 : -1);
        }
      }, dependencies: [i5.DefaultValueAccessor, i5.NgControlStatus, i5.MaxLengthValidator, i5.NgModel, TextareaCounterComponent, ArtemisDatePipe, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(ComplaintsForTutorComponent, { className: "ComplaintsForTutorComponent" });
    })();
  }
});

// src/main/webapp/app/complaints/complaints-for-tutor/complaints-for-tutor.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisComplaintsForTutorModule;
var init_complaints_for_tutor_module = __esm({
  "src/main/webapp/app/complaints/complaints-for-tutor/complaints-for-tutor.module.ts"() {
    init_shared_module();
    init_complaints_for_tutor_component();
    init_complaint_response_service();
    init_complaint_service();
    init_textarea_module();
    ArtemisComplaintsForTutorModule = class _ArtemisComplaintsForTutorModule {
      static \u0275fac = function ArtemisComplaintsForTutorModule_Factory(t) {
        return new (t || _ArtemisComplaintsForTutorModule)();
      };
      static \u0275mod = i02.\u0275\u0275defineNgModule({ type: _ArtemisComplaintsForTutorModule });
      static \u0275inj = i02.\u0275\u0275defineInjector({ providers: [ComplaintService, ComplaintResponseService], imports: [ArtemisSharedModule, TextareaModule] });
    };
  }
});

// src/main/webapp/app/shared/grading-instruction-link-icon/grading-instruction-link-icon.component.ts
import { Component as Component2, Input as Input2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faLink, faTrash } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i42 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function GradingInstructionLinkIconComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n    ");
    i03.\u0275\u0275elementStart(1, "fa-icon", 0);
    i03.\u0275\u0275listener("click", function GradingInstructionLinkIconComponent_Conditional_0_Template_fa_icon_click_1_listener() {
      i03.\u0275\u0275restoreView(_r3);
      const ctx_r2 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r2.toggle());
    });
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(2, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("icon", ctx_r0.linkIcon)("ngbTooltip", ctx_r0.setTooltip(ctx_r0.instruction));
  }
}
function GradingInstructionLinkIconComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n    ");
    i03.\u0275\u0275elementStart(1, "fa-icon", 1);
    i03.\u0275\u0275listener("mouseleave", function GradingInstructionLinkIconComponent_Conditional_1_Template_fa_icon_mouseleave_1_listener() {
      i03.\u0275\u0275restoreView(_r5);
      const ctx_r4 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r4.toggle());
    })("click", function GradingInstructionLinkIconComponent_Conditional_1_Template_fa_icon_click_1_listener() {
      i03.\u0275\u0275restoreView(_r5);
      const ctx_r6 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r6.removeLink());
    });
    i03.\u0275\u0275pipe(2, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("ngClass", "text-danger")("icon", ctx_r1.confirmIcon)("ngbTooltip", i03.\u0275\u0275pipeBind1(2, 3, "artemisApp.assessment.messages.removeAssessmentInstructionLink"));
  }
}
var GradingInstructionLinkIconComponent;
var init_grading_instruction_link_icon_component = __esm({
  "src/main/webapp/app/shared/grading-instruction-link-icon/grading-instruction-link-icon.component.ts"() {
    init_feedback_model();
    init_artemis_translate_pipe();
    init_artemis_translate_pipe();
    GradingInstructionLinkIconComponent = class _GradingInstructionLinkIconComponent {
      artemisTranslatePipe;
      linkIcon = faLink;
      feedback;
      instruction;
      confirmIcon = faTrash;
      showConfirm = false;
      constructor(artemisTranslatePipe) {
        this.artemisTranslatePipe = artemisTranslatePipe;
      }
      ngOnInit() {
        this.instruction = this.feedback.gradingInstruction;
      }
      removeLink() {
        this.toggle();
        this.feedback.gradingInstruction = void 0;
      }
      setTooltip(instruction) {
        return this.artemisTranslatePipe.transform("artemisApp.exercise.assessmentInstruction") + instruction.instructionDescription;
      }
      toggle() {
        this.showConfirm = !this.showConfirm;
      }
      static \u0275fac = function GradingInstructionLinkIconComponent_Factory(t) {
        return new (t || _GradingInstructionLinkIconComponent)(i03.\u0275\u0275directiveInject(ArtemisTranslatePipe));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _GradingInstructionLinkIconComponent, selectors: [["jhi-grading-instruction-link-icon"]], inputs: { linkIcon: "linkIcon", feedback: "feedback" }, decls: 2, vars: 2, consts: [[3, "icon", "ngbTooltip", "click"], [3, "ngClass", "icon", "ngbTooltip", "mouseleave", "click"]], template: function GradingInstructionLinkIconComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275template(0, GradingInstructionLinkIconComponent_Conditional_0_Template, 3, 2)(1, GradingInstructionLinkIconComponent_Conditional_1_Template, 4, 5);
        }
        if (rf & 2) {
          i03.\u0275\u0275conditional(0, !ctx.showConfirm ? 0 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(1, ctx.showConfirm ? 1 : -1);
        }
      }, dependencies: [i2.NgClass, i32.NgbTooltip, i42.FaIconComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(GradingInstructionLinkIconComponent, { className: "GradingInstructionLinkIconComponent" });
    })();
  }
});

// src/main/webapp/app/shared/grading-instruction-link-icon/grading-instruction-link-icon.module.ts
import { NgModule as NgModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisGradingInstructionLinkIconModule;
var init_grading_instruction_link_icon_module = __esm({
  "src/main/webapp/app/shared/grading-instruction-link-icon/grading-instruction-link-icon.module.ts"() {
    init_shared_module();
    init_grading_instruction_link_icon_component();
    ArtemisGradingInstructionLinkIconModule = class _ArtemisGradingInstructionLinkIconModule {
      static \u0275fac = function ArtemisGradingInstructionLinkIconModule_Factory(t) {
        return new (t || _ArtemisGradingInstructionLinkIconModule)();
      };
      static \u0275mod = i04.\u0275\u0275defineNgModule({ type: _ArtemisGradingInstructionLinkIconModule });
      static \u0275inj = i04.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule] });
    };
  }
});

// src/main/webapp/app/entities/text-assesment-event.model.ts
var TextAssessmentEventType, TextAssessmentEvent;
var init_text_assesment_event_model = __esm({
  "src/main/webapp/app/entities/text-assesment-event.model.ts"() {
    (function(TextAssessmentEventType2) {
      TextAssessmentEventType2["ADD_FEEDBACK_AUTOMATICALLY_SELECTED_BLOCK"] = "ADD_FEEDBACK_AUTOMATICALLY_SELECTED_BLOCK";
      TextAssessmentEventType2["ADD_FEEDBACK_MANUALLY_SELECTED_BLOCK"] = "ADD_FEEDBACK_MANUALLY_SELECTED_BLOCK";
      TextAssessmentEventType2["DELETE_FEEDBACK"] = "DELETE_FEEDBACK";
      TextAssessmentEventType2["EDIT_AUTOMATIC_FEEDBACK"] = "EDIT_AUTOMATIC_FEEDBACK";
      TextAssessmentEventType2["SUBMIT_ASSESSMENT"] = "SUBMIT_ASSESSMENT";
      TextAssessmentEventType2["ASSESS_NEXT_SUBMISSION"] = "ASSESS_NEXT_SUBMISSION";
    })(TextAssessmentEventType || (TextAssessmentEventType = {}));
    TextAssessmentEvent = class {
      id;
      userId;
      timestamp;
      eventType;
      feedbackType;
      segmentType;
      courseId;
      textExerciseId;
      participationId;
      submissionId;
      constructor(userId, courseId, textExerciseId, participationId, submissionId) {
        this.userId = userId;
        this.courseId = courseId;
        this.textExerciseId = textExerciseId;
        this.participationId = participationId;
        this.submissionId = submissionId;
      }
      setEventType(type) {
        this.eventType = type;
        return this;
      }
      setFeedbackType(type) {
        this.feedbackType = type;
      }
      setSegmentType(type) {
        this.segmentType = type;
      }
    };
  }
});

// src/main/webapp/app/exercises/text/assess/analytics/text-assesment-analytics.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Location as Location3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i43 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
var TextAssessmentAnalytics;
var init_text_assesment_analytics_service = __esm({
  "src/main/webapp/app/exercises/text/assess/analytics/text-assesment-analytics.service.ts"() {
    init_text_assessment_service();
    init_text_assesment_event_model();
    init_account_service();
    init_profile_service();
    init_text_assessment_service();
    init_account_service();
    init_profile_service();
    TextAssessmentAnalytics = class _TextAssessmentAnalytics {
      assessmentsService;
      accountService;
      profileService;
      location;
      userId;
      courseId;
      textExerciseId;
      participationId;
      submissionId;
      eventToSend = new TextAssessmentEvent();
      INVALID_VALUE = -1;
      route;
      analyticsEnabled = false;
      constructor(assessmentsService, accountService, profileService, location) {
        this.assessmentsService = assessmentsService;
        this.accountService = accountService;
        this.profileService = profileService;
        this.location = location;
        this.profileService.getProfileInfo().subscribe((profileInfo) => {
          this.analyticsEnabled = profileInfo.textAssessmentAnalyticsEnabled || false;
        });
      }
      setComponentRoute(route) {
        if (this.analyticsEnabled) {
          this.route = route;
          this.subscribeToRouteParameters();
        }
      }
      sendAssessmentEvent(eventType, feedbackType = void 0, textBlockType = void 0) {
        if (this.analyticsEnabled && !this.isExampleSubmissionRoute()) {
          this.eventToSend.setEventType(eventType);
          this.eventToSend.setFeedbackType(feedbackType);
          this.eventToSend.setSegmentType(textBlockType);
          this.assessmentsService.addTextAssessmentEvent(this.eventToSend).subscribe({
            error: (e) => console.error("Error sending statistics: " + e.message)
          });
        }
      }
      isExampleSubmissionRoute() {
        return !!this.location?.path().includes("example-submission");
      }
      subscribeToRouteParameters() {
        this.route.params.subscribe((params) => {
          this.userId = this.accountService.userIdentity ? Number(this.accountService.userIdentity.id) : this.INVALID_VALUE;
          this.courseId = Number(params["courseId"]);
          this.textExerciseId = Number(params["exerciseId"]);
          this.participationId = Number(params["participationId"]);
          this.submissionId = Number(params["submissionId"]);
          this.eventToSend = new TextAssessmentEvent(this.userId, this.courseId, this.textExerciseId, this.participationId, this.submissionId);
        });
      }
      static \u0275fac = function TextAssessmentAnalytics_Factory(t) {
        return new (t || _TextAssessmentAnalytics)(i05.\u0275\u0275inject(TextAssessmentService), i05.\u0275\u0275inject(AccountService), i05.\u0275\u0275inject(ProfileService), i05.\u0275\u0275inject(i43.Location));
      };
      static \u0275prov = i05.\u0275\u0275defineInjectable({ token: _TextAssessmentAnalytics, factory: _TextAssessmentAnalytics.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/assessment/assessment-header/assessment-header.component.ts
import { Component as Component3, EventEmitter as EventEmitter2, HostListener, Input as Input3, Output as Output2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import { faSave, faSpinner } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { faSquareCaretRight } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i33 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i44 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i52 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function AssessmentHeaderComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n            ");
    i06.\u0275\u0275elementStart(1, "span", 2);
    i06.\u0275\u0275text(2, "Assessment");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n        ");
  }
}
function AssessmentHeaderComponent_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n            ");
    i06.\u0275\u0275elementStart(1, "span", 3);
    i06.\u0275\u0275text(2, "Test Run Assessment");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n        ");
  }
}
function AssessmentHeaderComponent_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n            ");
    i06.\u0275\u0275elementStart(1, "span", 4);
    i06.\u0275\u0275text(2, "\n                Warning: You are viewing an illegal submission.\n            ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n        ");
  }
}
function AssessmentHeaderComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "ngb-alert", 5);
    i06.\u0275\u0275listener("close", function AssessmentHeaderComponent_Conditional_9_Template_ngb_alert_close_1_listener() {
      i06.\u0275\u0275restoreView(_r7);
      const ctx_r6 = i06.\u0275\u0275nextContext();
      return i06.\u0275\u0275resetView(ctx_r6.hasAssessmentDueDatePassed = false);
    });
    i06.\u0275\u0275text(2, "\n            Assessment Due Date is over, the assessment will be published immediately after submitting\n        ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n    ");
  }
  if (rf & 2) {
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275styleProp("font-size", "65%");
    i06.\u0275\u0275property("type", "warning");
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "span", 11);
    i06.\u0275\u0275text(2, "\n                    Assessment locked by: otherUser\n                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n            ");
  }
  if (rf & 2) {
    const ctx_r8 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("translateValues", i06.\u0275\u0275pureFunction1(1, _c02, (ctx_r8.result == null ? null : ctx_r8.result.assessor == null ? null : ctx_r8.result.assessor.name) + " (" + (ctx_r8.result == null ? null : ctx_r8.result.assessor == null ? null : ctx_r8.result.assessor.login) + ")"));
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "span", 12);
    i06.\u0275\u0275text(2, "\n                    You have to respond to the feedback request.\n                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n            ");
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "span", 13);
    i06.\u0275\u0275text(2, "\n                    You may respond to the feedback request.\n                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n            ");
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "span", 14);
    i06.\u0275\u0275text(2, " You have to respond to the complaint. ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n            ");
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "span", 15);
    i06.\u0275\u0275text(2, "\n                    You may respond to the complaint.\n                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n            ");
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "span", 16);
    i06.\u0275\u0275text(2, "\n                    There is a complaint for this assessment. Another tutor must respond.\n                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n            ");
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "span", 17);
    i06.\u0275\u0275text(2, "\n                    The complaint about your assessment has been resolved.\n                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n            ");
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "span", 18);
    i06.\u0275\u0275text(2, "\n                    You have the lock for this assessment\n                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n            ");
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_12_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                        ");
    i06.\u0275\u0275elementStart(1, "span", 20);
    i06.\u0275\u0275pipe(2, "artemisTranslate");
    i06.\u0275\u0275text(3, "Activate Diff-View");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275propertyInterpolate("ngbTooltip", i06.\u0275\u0275pipeBind1(2, 1, "artemisApp.assessment.diffView.highlightAssessmentDiffTooltipOn"));
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_12_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                        ");
    i06.\u0275\u0275elementStart(1, "span", 21);
    i06.\u0275\u0275pipe(2, "artemisTranslate");
    i06.\u0275\u0275text(3, "Deactivate Diff-View");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275propertyInterpolate("ngbTooltip", i06.\u0275\u0275pipeBind1(2, 1, "artemisApp.assessment.diffView.highlightAssessmentDiffTooltipOff"));
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "button", 19);
    i06.\u0275\u0275listener("click", function AssessmentHeaderComponent_Conditional_10_Conditional_12_Template_button_click_1_listener() {
      i06.\u0275\u0275restoreView(_r26);
      const ctx_r25 = i06.\u0275\u0275nextContext(2);
      return i06.\u0275\u0275resetView(ctx_r25.toggleHighlightDifferences());
    });
    i06.\u0275\u0275text(2, "\n                    ");
    i06.\u0275\u0275template(3, AssessmentHeaderComponent_Conditional_10_Conditional_12_Conditional_3_Template, 5, 3)(4, AssessmentHeaderComponent_Conditional_10_Conditional_12_Conditional_4_Template, 5, 3);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r16 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("disabled", ctx_r16.saveBusy || ctx_r16.submitBusy || ctx_r16.cancelBusy);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275conditional(3, !ctx_r16.highlightDifferences ? 3 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(4, ctx_r16.highlightDifferences ? 4 : -1);
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_17_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                            ");
    i06.\u0275\u0275elementStart(1, "fa-icon", 27);
    i06.\u0275\u0275text(2, "\xA0");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r27 = i06.\u0275\u0275nextContext(3);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r27.faSpinner)("spin", true);
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_17_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                            ");
    i06.\u0275\u0275elementStart(1, "fa-icon", 27);
    i06.\u0275\u0275text(2, "\xA0");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r28 = i06.\u0275\u0275nextContext(3);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r28.faSpinner)("spin", true);
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_17_Conditional_19_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                                ");
    i06.\u0275\u0275elementStart(1, "fa-icon", 27);
    i06.\u0275\u0275text(2, "\xA0");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r30 = i06.\u0275\u0275nextContext(4);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r30.faSpinner)("spin", true);
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_17_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n                        ");
    i06.\u0275\u0275elementStart(1, "button", 28);
    i06.\u0275\u0275listener("click", function AssessmentHeaderComponent_Conditional_10_Conditional_17_Conditional_19_Template_button_click_1_listener() {
      i06.\u0275\u0275restoreView(_r32);
      const ctx_r31 = i06.\u0275\u0275nextContext(3);
      return i06.\u0275\u0275resetView(ctx_r31.cancel.emit());
    });
    i06.\u0275\u0275text(2, "\n                            ");
    i06.\u0275\u0275template(3, AssessmentHeaderComponent_Conditional_10_Conditional_17_Conditional_19_Conditional_3_Template, 4, 2);
    i06.\u0275\u0275elementStart(4, "span", 29);
    i06.\u0275\u0275text(5, "Cancel");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(6, "\n                        ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r29 = i06.\u0275\u0275nextContext(3);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("disabled", !((ctx_r29.exercise == null ? null : ctx_r29.exercise.isAtLeastInstructor) || ctx_r29.isAssessor) || ctx_r29.saveBusy || ctx_r29.submitBusy || ctx_r29.cancelBusy);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275conditional(3, ctx_r29.cancelBusy ? 3 : -1);
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n                    ");
    i06.\u0275\u0275elementStart(1, "button", 22);
    i06.\u0275\u0275listener("click", function AssessmentHeaderComponent_Conditional_10_Conditional_17_Template_button_click_1_listener() {
      i06.\u0275\u0275restoreView(_r34);
      const ctx_r33 = i06.\u0275\u0275nextContext(2);
      return i06.\u0275\u0275resetView(ctx_r33.save.emit());
    });
    i06.\u0275\u0275pipe(2, "artemisTranslate");
    i06.\u0275\u0275text(3, "\n                        ");
    i06.\u0275\u0275template(4, AssessmentHeaderComponent_Conditional_10_Conditional_17_Conditional_4_Template, 4, 2);
    i06.\u0275\u0275element(5, "fa-icon", 23);
    i06.\u0275\u0275text(6, "\n                        ");
    i06.\u0275\u0275elementStart(7, "span", 24);
    i06.\u0275\u0275text(8, "Save");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(9, "\n                    ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(10, "\n                    ");
    i06.\u0275\u0275elementStart(11, "button", 25);
    i06.\u0275\u0275listener("click", function AssessmentHeaderComponent_Conditional_10_Conditional_17_Template_button_click_11_listener() {
      i06.\u0275\u0275restoreView(_r34);
      const ctx_r35 = i06.\u0275\u0275nextContext(2);
      ctx_r35.submit.emit();
      return i06.\u0275\u0275resetView(ctx_r35.sendSubmitAssessmentEventToAnalytics());
    });
    i06.\u0275\u0275pipe(12, "artemisTranslate");
    i06.\u0275\u0275text(13, "\n                        ");
    i06.\u0275\u0275template(14, AssessmentHeaderComponent_Conditional_10_Conditional_17_Conditional_14_Template, 4, 2);
    i06.\u0275\u0275elementStart(15, "span", 26);
    i06.\u0275\u0275text(16, "Submit");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(17, "\n                    ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(18, "\n                    ");
    i06.\u0275\u0275template(19, AssessmentHeaderComponent_Conditional_10_Conditional_17_Conditional_19_Template, 8, 2);
  }
  if (rf & 2) {
    const ctx_r17 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("disabled", ctx_r17.saveDisabled)("ngbTooltip", i06.\u0275\u0275pipeBind1(2, 8, "artemisApp.assessment.button.control") + " + S");
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275conditional(4, ctx_r17.saveBusy ? 4 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r17.faSave);
    i06.\u0275\u0275advance(6);
    i06.\u0275\u0275property("disabled", ctx_r17.submitDisabled)("ngbTooltip", i06.\u0275\u0275pipeBind1(12, 10, "artemisApp.assessment.button.control") + " + Enter");
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275conditional(14, ctx_r17.submitBusy ? 14 : -1);
    i06.\u0275\u0275advance(5);
    i06.\u0275\u0275conditional(19, !ctx_r17.isTestRun ? 19 : -1);
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_18_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                            ");
    i06.\u0275\u0275elementStart(1, "fa-icon", 27);
    i06.\u0275\u0275text(2, "\xA0");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r36 = i06.\u0275\u0275nextContext(3);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r36.faSpinner)("spin", true);
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r38 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n                    ");
    i06.\u0275\u0275elementStart(1, "button", 30);
    i06.\u0275\u0275listener("click", function AssessmentHeaderComponent_Conditional_10_Conditional_18_Template_button_click_1_listener() {
      i06.\u0275\u0275restoreView(_r38);
      const ctx_r37 = i06.\u0275\u0275nextContext(2);
      return i06.\u0275\u0275resetView(ctx_r37.submit.emit());
    });
    i06.\u0275\u0275pipe(2, "artemisTranslate");
    i06.\u0275\u0275text(3, "\n                        ");
    i06.\u0275\u0275template(4, AssessmentHeaderComponent_Conditional_10_Conditional_18_Conditional_4_Template, 4, 2);
    i06.\u0275\u0275elementStart(5, "span", 31);
    i06.\u0275\u0275text(6, "Override Assessment");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n                    ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(8, "\n                ");
  }
  if (rf & 2) {
    const ctx_r18 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("disabled", ctx_r18.overrideDisabled)("ngbTooltip", i06.\u0275\u0275pipeBind1(2, 3, "artemisApp.assessment.button.control") + " + Enter");
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275conditional(4, ctx_r18.submitBusy ? 4 : -1);
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_19_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                            ");
    i06.\u0275\u0275element(1, "fa-icon", 27);
    i06.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r39 = i06.\u0275\u0275nextContext(3);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r39.faSpinner)("spin", true);
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r41 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n                    ");
    i06.\u0275\u0275elementStart(1, "button", 32);
    i06.\u0275\u0275listener("click", function AssessmentHeaderComponent_Conditional_10_Conditional_19_Template_button_click_1_listener() {
      i06.\u0275\u0275restoreView(_r41);
      const ctx_r40 = i06.\u0275\u0275nextContext(2);
      return i06.\u0275\u0275resetView(ctx_r40.onUseAsExampleSolutionClicked());
    });
    i06.\u0275\u0275text(2, "\n                        ");
    i06.\u0275\u0275template(3, AssessmentHeaderComponent_Conditional_10_Conditional_19_Conditional_3_Template, 3, 2);
    i06.\u0275\u0275elementStart(4, "span", 33);
    i06.\u0275\u0275text(5, "Use as Example Submission");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(6, "\n                    ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n                ");
  }
  if (rf & 2) {
    const ctx_r19 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275conditional(3, ctx_r19.submitBusy ? 3 : -1);
  }
}
function AssessmentHeaderComponent_Conditional_10_ng_template_20_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0);
    i06.\u0275\u0275pipe(1, "artemisTranslate");
    i06.\u0275\u0275element(2, "fa-icon", 23);
    i06.\u0275\u0275text(3, "\n                ");
  }
  if (rf & 2) {
    const ctx_r20 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275textInterpolate1("\n                    ", i06.\u0275\u0275pipeBind1(1, 2, "artemisApp.assessment.button.control"), " + Shift + ");
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275property("icon", ctx_r20.faSquareCaretRight);
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_23_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                            ");
    i06.\u0275\u0275elementStart(1, "fa-icon", 27);
    i06.\u0275\u0275text(2, "\xA0");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r42 = i06.\u0275\u0275nextContext(3);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r42.faSpinner)("spin", true);
  }
}
function AssessmentHeaderComponent_Conditional_10_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r44 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n                    ");
    i06.\u0275\u0275elementStart(1, "button", 34);
    i06.\u0275\u0275listener("click", function AssessmentHeaderComponent_Conditional_10_Conditional_23_Template_button_click_1_listener() {
      i06.\u0275\u0275restoreView(_r44);
      const ctx_r43 = i06.\u0275\u0275nextContext(2);
      ctx_r43.nextSubmission.emit();
      return i06.\u0275\u0275resetView(ctx_r43.sendAssessNextEventToAnalytics());
    });
    i06.\u0275\u0275text(2, "\n                        ");
    i06.\u0275\u0275template(3, AssessmentHeaderComponent_Conditional_10_Conditional_23_Conditional_3_Template, 4, 2);
    i06.\u0275\u0275elementStart(4, "span", 35);
    i06.\u0275\u0275text(5, "Next Submission");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(6, "\n                    ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n                ");
  }
  if (rf & 2) {
    i06.\u0275\u0275nextContext();
    const _r21 = i06.\u0275\u0275reference(21);
    const ctx_r22 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("disabled", ctx_r22.assessNextDisabled)("ngbTooltip", _r21);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275conditional(3, ctx_r22.nextSubmissionBusy ? 3 : -1);
  }
}
function AssessmentHeaderComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "div", 6);
    i06.\u0275\u0275text(2, "\n            ");
    i06.\u0275\u0275template(3, AssessmentHeaderComponent_Conditional_10_Conditional_3_Template, 4, 3)(4, AssessmentHeaderComponent_Conditional_10_Conditional_4_Template, 4, 0)(5, AssessmentHeaderComponent_Conditional_10_Conditional_5_Template, 4, 0)(6, AssessmentHeaderComponent_Conditional_10_Conditional_6_Template, 4, 0)(7, AssessmentHeaderComponent_Conditional_10_Conditional_7_Template, 4, 0)(8, AssessmentHeaderComponent_Conditional_10_Conditional_8_Template, 4, 0)(9, AssessmentHeaderComponent_Conditional_10_Conditional_9_Template, 4, 0)(10, AssessmentHeaderComponent_Conditional_10_Conditional_10_Template, 4, 0);
    i06.\u0275\u0275text(11, "\n            ");
    i06.\u0275\u0275template(12, AssessmentHeaderComponent_Conditional_10_Conditional_12_Template, 6, 3);
    i06.\u0275\u0275element(13, "br");
    i06.\u0275\u0275text(14, "\n            ");
    i06.\u0275\u0275elementStart(15, "div", 7);
    i06.\u0275\u0275text(16, "\n                ");
    i06.\u0275\u0275template(17, AssessmentHeaderComponent_Conditional_10_Conditional_17_Template, 20, 12)(18, AssessmentHeaderComponent_Conditional_10_Conditional_18_Template, 9, 5)(19, AssessmentHeaderComponent_Conditional_10_Conditional_19_Template, 8, 1)(20, AssessmentHeaderComponent_Conditional_10_ng_template_20_Template, 4, 4, "ng-template", null, 8, i06.\u0275\u0275templateRefExtractor);
    i06.\u0275\u0275text(22, "\n                ");
    i06.\u0275\u0275template(23, AssessmentHeaderComponent_Conditional_10_Conditional_23_Template, 8, 3);
    i06.\u0275\u0275elementStart(24, "a", 9);
    i06.\u0275\u0275text(25, "\n                    ");
    i06.\u0275\u0275elementStart(26, "span", 10);
    i06.\u0275\u0275text(27, "Exercise dashboard");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(28, "\n                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(29, "\n            ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(30, "\n        ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(31, "\n    ");
  }
  if (rf & 2) {
    const ctx_r4 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275conditional(3, !ctx_r4.isAssessor && !ctx_r4.hasComplaint ? 3 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(4, ctx_r4.isAssessor && ctx_r4.exercise && !ctx_r4.exercise.isAtLeastInstructor && ctx_r4.hasComplaint && ctx_r4.complaintType != ctx_r4.ComplaintType.COMPLAINT && !ctx_r4.complaintHandled && ctx_r4.exercise.assessmentType !== ctx_r4.AssessmentType.AUTOMATIC ? 4 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(5, ctx_r4.isAssessor && ctx_r4.exercise && !ctx_r4.exercise.isAtLeastInstructor && ctx_r4.hasComplaint && ctx_r4.complaintType != ctx_r4.ComplaintType.COMPLAINT && ctx_r4.exercise.assessmentType === ctx_r4.AssessmentType.AUTOMATIC && !ctx_r4.complaintHandled && !ctx_r4.exercise.teamMode ? 5 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(6, ctx_r4.isAssessor && ctx_r4.exercise && !ctx_r4.exercise.isAtLeastInstructor && ctx_r4.hasComplaint && ctx_r4.complaintType == ctx_r4.ComplaintType.COMPLAINT && !ctx_r4.complaintHandled && ctx_r4.exercise.teamMode ? 6 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(7, ctx_r4.isAssessor && ctx_r4.exercise && !ctx_r4.exercise.isAtLeastInstructor && ctx_r4.hasComplaint && ctx_r4.complaintType == ctx_r4.ComplaintType.COMPLAINT && ctx_r4.exercise.assessmentType === ctx_r4.AssessmentType.AUTOMATIC && !ctx_r4.complaintHandled && !ctx_r4.exercise.teamMode ? 7 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(8, ctx_r4.isAssessor && ctx_r4.exercise && !ctx_r4.exercise.isAtLeastInstructor && ctx_r4.hasComplaint && ctx_r4.exercise.assessmentType !== ctx_r4.AssessmentType.AUTOMATIC && ctx_r4.complaintType == ctx_r4.ComplaintType.COMPLAINT && !ctx_r4.complaintHandled && !ctx_r4.exercise.teamMode ? 8 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(9, ctx_r4.isAssessor && ctx_r4.exercise && !ctx_r4.exercise.isAtLeastInstructor && ctx_r4.hasComplaint && ctx_r4.complaintHandled && !ctx_r4.exercise.teamMode ? 9 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(10, ctx_r4.isAssessor && (!ctx_r4.hasComplaint || (ctx_r4.exercise == null ? null : ctx_r4.exercise.isAtLeastInstructor)) ? 10 : -1);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275conditional(12, !ctx_r4.isProgrammingExercise && ctx_r4.result && ctx_r4.correctionRound > 0 ? 12 : -1);
    i06.\u0275\u0275advance(5);
    i06.\u0275\u0275conditional(17, !(ctx_r4.result == null ? null : ctx_r4.result.completionDate) ? 17 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(18, ctx_r4.overrideVisible ? 18 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(19, (ctx_r4.result == null ? null : ctx_r4.result.completionDate) && (ctx_r4.exercise == null ? null : ctx_r4.exercise.isAtLeastInstructor) && (ctx_r4.exercise.type === ctx_r4.ExerciseType.MODELING || ctx_r4.exercise.type === ctx_r4.ExerciseType.TEXT) ? 19 : -1);
    i06.\u0275\u0275advance(4);
    i06.\u0275\u0275conditional(23, ctx_r4.assessNextVisible ? 23 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("routerLink", ctx_r4.exerciseDashboardLink);
  }
}
function AssessmentHeaderComponent_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n    ");
    i06.\u0275\u0275element(1, "jhi-assessment-warning", 36);
    i06.\u0275\u0275text(2, "\n");
  }
  if (rf & 2) {
    const ctx_r5 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("exercise", ctx_r5.exercise);
  }
}
var _c02, AssessmentHeaderComponent;
var init_assessment_header_component = __esm({
  "src/main/webapp/app/assessment/assessment-header/assessment-header.component.ts"() {
    init_result_model();
    init_exercise_model();
    init_text_assesment_analytics_service();
    init_text_assesment_event_model();
    init_complaint_model();
    init_assessment_type_model();
    init_text_assesment_analytics_service();
    init_translate_directive();
    init_assessment_warning_component();
    init_artemis_translate_pipe();
    _c02 = (a0) => ({ otherUser: a0 });
    AssessmentHeaderComponent = class _AssessmentHeaderComponent {
      textAssessmentAnalytics;
      route;
      translateService;
      isLoading;
      saveBusy;
      submitBusy;
      cancelBusy;
      nextSubmissionBusy;
      correctionRound = 0;
      isTeamMode;
      isAssessor;
      isTestRun = false;
      exerciseDashboardLink;
      canOverride;
      exercise;
      result;
      isIllegalSubmission;
      hasComplaint = false;
      hasMoreFeedbackRequest = false;
      complaintHandled = false;
      complaintType;
      assessmentsAreValid;
      hasAssessmentDueDatePassed;
      isProgrammingExercise = false;
      save = new EventEmitter2();
      submit = new EventEmitter2();
      cancel = new EventEmitter2();
      nextSubmission = new EventEmitter2();
      highlightDifferencesChange = new EventEmitter2();
      useAsExampleSubmission = new EventEmitter2();
      _highlightDifferences;
      ExerciseType = ExerciseType;
      ComplaintType = ComplaintType;
      AssessmentType = AssessmentType;
      faSpinner = faSpinner;
      faSave = faSave;
      faSquareCaretRight = faSquareCaretRight;
      set highlightDifferences(highlightDifferences) {
        this._highlightDifferences = highlightDifferences;
        this.highlightDifferencesChange.emit(this.highlightDifferences);
      }
      constructor(textAssessmentAnalytics, route, translateService) {
        this.textAssessmentAnalytics = textAssessmentAnalytics;
        this.route = route;
        this.translateService = translateService;
        textAssessmentAnalytics.setComponentRoute(route);
      }
      get highlightDifferences() {
        return this._highlightDifferences;
      }
      get overrideVisible() {
        return this.result?.completionDate && this.canOverride;
      }
      get assessNextVisible() {
        return this.result?.completionDate && (this.isAssessor || this.exercise?.isAtLeastInstructor) && !this.hasComplaint && !this.isTeamMode && !this.isTestRun;
      }
      get saveDisabled() {
        if (this.result?.completionDate) {
          return true;
        } else {
          return !this.assessmentsAreValid || !this.isAssessor || this.saveBusy || this.submitBusy || this.cancelBusy;
        }
      }
      get submitDisabled() {
        return !this.assessmentsAreValid || !this.isAssessor || this.saveBusy || this.submitBusy || this.cancelBusy;
      }
      get overrideDisabled() {
        if (this.overrideVisible) {
          return !this.assessmentsAreValid || this.submitBusy;
        } else {
          return true;
        }
      }
      get assessNextDisabled() {
        if (this.assessNextVisible) {
          return this.nextSubmissionBusy || this.submitBusy;
        } else {
          return true;
        }
      }
      saveOnControlAndS(event) {
        event.preventDefault();
        if (!this.saveDisabled) {
          this.save.emit();
        }
      }
      submitOnControlAndEnter(event) {
        event.preventDefault();
        if (!this.overrideDisabled) {
          this.submit.emit();
        } else if (!this.submitDisabled) {
          this.submit.emit();
          this.sendSubmitAssessmentEventToAnalytics();
        }
      }
      assessNextOnControlShiftAndArrowRight(event) {
        event.preventDefault();
        if (!this.assessNextDisabled) {
          this.nextSubmission.emit();
          this.sendAssessNextEventToAnalytics();
        }
      }
      toggleHighlightDifferences() {
        this.highlightDifferences = !this.highlightDifferences;
        this.highlightDifferencesChange.emit(this.highlightDifferences);
      }
      sendSubmitAssessmentEventToAnalytics() {
        if (this.exercise?.type === ExerciseType.TEXT) {
          this.textAssessmentAnalytics.sendAssessmentEvent(TextAssessmentEventType.SUBMIT_ASSESSMENT);
        }
      }
      sendAssessNextEventToAnalytics() {
        if (this.exercise?.type === ExerciseType.TEXT) {
          this.textAssessmentAnalytics.sendAssessmentEvent(TextAssessmentEventType.ASSESS_NEXT_SUBMISSION);
        }
      }
      onUseAsExampleSolutionClicked() {
        const verificationMessage = this.translateService.instant("artemisApp.assessment.useAsExampleSubmissionVerificationQuestion");
        if (confirm(verificationMessage)) {
          this.useAsExampleSubmission.emit();
        }
      }
      static \u0275fac = function AssessmentHeaderComponent_Factory(t) {
        return new (t || _AssessmentHeaderComponent)(i06.\u0275\u0275directiveInject(TextAssessmentAnalytics), i06.\u0275\u0275directiveInject(i22.ActivatedRoute), i06.\u0275\u0275directiveInject(i33.TranslateService));
      };
      static \u0275cmp = i06.\u0275\u0275defineComponent({ type: _AssessmentHeaderComponent, selectors: [["jhi-assessment-header"]], hostBindings: function AssessmentHeaderComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          i06.\u0275\u0275listener("keydown.control.s", function AssessmentHeaderComponent_keydown_control_s_HostBindingHandler($event) {
            return ctx.saveOnControlAndS($event);
          }, false, i06.\u0275\u0275resolveDocument)("keydown.control.enter", function AssessmentHeaderComponent_keydown_control_enter_HostBindingHandler($event) {
            return ctx.submitOnControlAndEnter($event);
          }, false, i06.\u0275\u0275resolveDocument)("keydown.control.shift.arrowRight", function AssessmentHeaderComponent_keydown_control_shift_arrowRight_HostBindingHandler($event) {
            return ctx.assessNextOnControlShiftAndArrowRight($event);
          }, false, i06.\u0275\u0275resolveDocument);
        }
      }, inputs: { isLoading: "isLoading", saveBusy: "saveBusy", submitBusy: "submitBusy", cancelBusy: "cancelBusy", nextSubmissionBusy: "nextSubmissionBusy", correctionRound: "correctionRound", isTeamMode: "isTeamMode", isAssessor: "isAssessor", isTestRun: "isTestRun", exerciseDashboardLink: "exerciseDashboardLink", canOverride: "canOverride", exercise: "exercise", result: "result", isIllegalSubmission: "isIllegalSubmission", hasComplaint: "hasComplaint", hasMoreFeedbackRequest: "hasMoreFeedbackRequest", complaintHandled: "complaintHandled", complaintType: "complaintType", assessmentsAreValid: "assessmentsAreValid", hasAssessmentDueDatePassed: "hasAssessmentDueDatePassed", isProgrammingExercise: "isProgrammingExercise", highlightDifferences: "highlightDifferences" }, outputs: { save: "save", submit: "submit", cancel: "cancel", nextSubmission: "nextSubmission", highlightDifferencesChange: "highlightDifferencesChange", useAsExampleSubmission: "useAsExampleSubmission" }, decls: 13, vars: 6, consts: [[1, "top-container", "flex-wrap", "flex-lg-nowrap"], [1, "row-container", "me-2"], ["jhiTranslate", "artemisApp.assessment.assessment"], ["jhiTranslate", "artemisApp.assessment.testRunAssessment"], ["jhiTranslate", "artemisApp.assessment.assessmentIllegalSubmission", 1, "badge", "bg-danger", "ms-3", 2, "font-size", "65%"], ["jhiTranslate", "artemisApp.assessment.assessmentDueDateIsOver", 3, "type", "close"], [1, "row-container", "flex-wrap", "flex-lg-nowrap"], [1, "d-flex", "flex-wrap", "flex-lg-nowrap"], ["nextSubmissionShortcut", ""], [1, "btn", "m-1", "btn-info", 3, "routerLink"], ["jhiTranslate", "entity.action.exerciseDashboard"], ["id", "assessmentLocked", "jhiTranslate", "artemisApp.assessment.assessmentLocked", 1, "text-danger", "m-2", 2, "font-size", "65%", 3, "translateValues"], ["id", "moreFeedbackRequest", "jhiTranslate", "artemisApp.assessment.moreFeedbackRequest", 1, "m-2", 2, "font-size", "65%"], ["id", "automaticAssessmentFeedbackRequest", "jhiTranslate", "artemisApp.assessment.automaticAssessmentFeedbackRequest", 1, "m-2", 2, "font-size", "65%"], ["id", "teamComplaint", "jhiTranslate", "artemisApp.assessment.teamComplaint", 1, "m-2", 2, "font-size", "65%"], ["id", "automaticAssessmentComplaint", "jhiTranslate", "artemisApp.assessment.automaticAssessmentComplaint", 1, "m-2", 2, "font-size", "65%"], ["id", "assessmentReadOnlyUnhandledComplaint", "jhiTranslate", "artemisApp.assessment.assessmentReadOnlyUnhandledComplaint", 1, "m-2", 2, "font-size", "65%"], ["id", "assessmentReadOnlyHandled", "jhiTranslate", "artemisApp.assessment.assessmentReadOnlyHandledComplaint", 1, "m-2", 2, "font-size", "65%"], ["id", "assessmentLockedCurrentUser", "jhiTranslate", "artemisApp.assessment.assessmentLockedCurrentUser", 1, "text-danger", "m-2", 2, "font-size", "65%"], [1, "btn", "ms-2", "btn-primary", 3, "disabled", "click"], ["jhiTranslate", "artemisApp.assessment.diffView.differenceActivate", 3, "ngbTooltip"], ["jhiTranslate", "artemisApp.assessment.diffView.differenceDeactivate", 3, "ngbTooltip"], [1, "btn", "m-1", "btn-primary", 3, "disabled", "ngbTooltip", "click"], [3, "icon"], ["jhiTranslate", "entity.action.save"], ["id", "submit", 1, "btn", "m-1", "btn-success", 3, "disabled", "ngbTooltip", "click"], ["jhiTranslate", "entity.action.submit"], [3, "icon", "spin"], [1, "btn", "m-1", "btn-danger", 3, "disabled", "click"], ["jhiTranslate", "entity.action.cancel"], [1, "btn", "m-1", "btn-danger", 3, "disabled", "ngbTooltip", "click"], ["jhiTranslate", "artemisApp.assessment.button.overrideAssessment"], ["id", "useAsExampleSubmission", 1, "btn", "m-1", "btn-primary", 3, "click"], ["jhiTranslate", "artemisApp.assessment.button.useAsExampleSubmission"], ["id", "assessNextButton", 1, "btn", "m-1", "btn-success", 3, "disabled", "ngbTooltip", "click"], ["jhiTranslate", "artemisApp.assessment.button.nextSubmission"], [3, "exercise"]], template: function AssessmentHeaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          i06.\u0275\u0275elementStart(0, "h3", 0);
          i06.\u0275\u0275text(1, "\n    ");
          i06.\u0275\u0275text(2, "\n    ");
          i06.\u0275\u0275elementStart(3, "div", 1);
          i06.\u0275\u0275text(4, "\n        ");
          i06.\u0275\u0275template(5, AssessmentHeaderComponent_Conditional_5_Template, 4, 0)(6, AssessmentHeaderComponent_Conditional_6_Template, 4, 0)(7, AssessmentHeaderComponent_Conditional_7_Template, 4, 0);
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(8, "\n    ");
          i06.\u0275\u0275template(9, AssessmentHeaderComponent_Conditional_9_Template, 4, 3)(10, AssessmentHeaderComponent_Conditional_10_Template, 32, 14);
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(11, "\n");
          i06.\u0275\u0275template(12, AssessmentHeaderComponent_Conditional_12_Template, 3, 1);
        }
        if (rf & 2) {
          i06.\u0275\u0275advance(5);
          i06.\u0275\u0275conditional(5, !ctx.isTestRun ? 5 : -1);
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275conditional(6, ctx.isTestRun ? 6 : -1);
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275conditional(7, ctx.isIllegalSubmission ? 7 : -1);
          i06.\u0275\u0275advance(2);
          i06.\u0275\u0275conditional(9, ctx.hasAssessmentDueDatePassed && !(ctx.result == null ? null : ctx.result.completionDate) ? 9 : -1);
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275conditional(10, !ctx.isLoading ? 10 : -1);
          i06.\u0275\u0275advance(2);
          i06.\u0275\u0275conditional(12, ctx.exercise ? 12 : -1);
        }
      }, dependencies: [i44.NgbAlert, i44.NgbTooltip, i52.FaIconComponent, TranslateDirective, AssessmentWarningComponent, i22.RouterLink, ArtemisTranslatePipe], styles: ["\n\n.top-container[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.top-container[_ngcontent-%COMP%]   jhi-alert[_ngcontent-%COMP%] {\n  font-size: initial;\n}\n.row-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9hc3Nlc3NtZW50L2Fzc2Vzc21lbnQtaGVhZGVyL2Fzc2Vzc21lbnQtaGVhZGVyLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIudG9wLWNvbnRhaW5lciB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqaGktYWxlcnQge1xuICAgICAgICBmb250LXNpemU6IGluaXRpYWw7XG4gICAgfVxufVxuXG4ucm93LWNvbnRhaW5lciB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLENBQUE7QUFDSSxXQUFBO0FBQ0EsbUJBQUE7QUFDQSxlQUFBOztBQUNBLENBSkosY0FJSTtBQUNJLGFBQUE7O0FBSVIsQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i06.\u0275setClassDebugInfo(AssessmentHeaderComponent, { className: "AssessmentHeaderComponent" });
    })();
  }
});

// src/main/webapp/app/assessment/assessment-complaint-alert/assessment-complaint-alert.component.ts
import { Component as Component4, Input as Input4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function AssessmentComplaintAlertComponent_Conditional_0_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n        ");
    i07.\u0275\u0275elementStart(1, "div", 0);
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275pipe(3, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(4, "\n    ");
  }
  if (rf & 2) {
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(3, 1, "artemisApp.complaint.hint"));
  }
}
function AssessmentComplaintAlertComponent_Conditional_0_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n        ");
    i07.\u0275\u0275elementStart(1, "div", 0);
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275pipe(3, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(4, "\n    ");
  }
  if (rf & 2) {
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(3, 1, "artemisApp.moreFeedback.hint"));
  }
}
function AssessmentComplaintAlertComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n    ");
    i07.\u0275\u0275template(1, AssessmentComplaintAlertComponent_Conditional_0_Conditional_1_Template, 5, 3)(2, AssessmentComplaintAlertComponent_Conditional_0_Conditional_2_Template, 5, 3);
  }
  if (rf & 2) {
    const ctx_r0 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(1, (ctx_r0.complaint == null ? null : ctx_r0.complaint.complaintType) === ctx_r0.ComplaintType.COMPLAINT ? 1 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(2, (ctx_r0.complaint == null ? null : ctx_r0.complaint.complaintType) === ctx_r0.ComplaintType.MORE_FEEDBACK ? 2 : -1);
  }
}
var AssessmentComplaintAlertComponent;
var init_assessment_complaint_alert_component = __esm({
  "src/main/webapp/app/assessment/assessment-complaint-alert/assessment-complaint-alert.component.ts"() {
    init_complaint_model();
    init_artemis_translate_pipe();
    AssessmentComplaintAlertComponent = class _AssessmentComplaintAlertComponent {
      ComplaintType = ComplaintType;
      complaint;
      static \u0275fac = function AssessmentComplaintAlertComponent_Factory(t) {
        return new (t || _AssessmentComplaintAlertComponent)();
      };
      static \u0275cmp = i07.\u0275\u0275defineComponent({ type: _AssessmentComplaintAlertComponent, selectors: [["jhi-assessment-complaint-alert"]], inputs: { complaint: "complaint" }, decls: 1, vars: 1, consts: [[1, "alert", "alert-info"]], template: function AssessmentComplaintAlertComponent_Template(rf, ctx) {
        if (rf & 1) {
          i07.\u0275\u0275template(0, AssessmentComplaintAlertComponent_Conditional_0_Template, 3, 2);
        }
        if (rf & 2) {
          i07.\u0275\u0275conditional(0, ctx.complaint ? 0 : -1);
        }
      }, dependencies: [ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i07.\u0275setClassDebugInfo(AssessmentComplaintAlertComponent, { className: "AssessmentComplaintAlertComponent" });
    })();
  }
});

// src/main/webapp/app/assessment/assessment-layout/assessment-layout.component.ts
import { Component as Component5, EventEmitter as EventEmitter3, HostBinding, Input as Input5, Output as Output3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i08 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function AssessmentLayoutComponent_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n    ");
    i08.\u0275\u0275elementStart(1, "jhi-complaints-for-tutor-form", 2);
    i08.\u0275\u0275listener("updateAssessmentAfterComplaint", function AssessmentLayoutComponent_Conditional_6_Template_jhi_complaints_for_tutor_form_updateAssessmentAfterComplaint_1_listener($event) {
      i08.\u0275\u0275restoreView(_r2);
      const ctx_r1 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r1.updateAssessmentAfterComplaint.emit($event));
    });
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(2, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("zeroIndent", false)("complaint", ctx_r0.complaint)("exercise", ctx_r0.exercise)("isAssessor", ctx_r0.isAssessor)("submission", ctx_r0.submission)("isTestRun", ctx_r0.isTestRun);
  }
}
var _c03, AssessmentLayoutComponent;
var init_assessment_layout_component = __esm({
  "src/main/webapp/app/assessment/assessment-layout/assessment-layout.component.ts"() {
    init_result_model();
    init_complaint_model();
    init_exercise_model();
    init_submission_model();
    init_complaints_for_tutor_component();
    init_assessment_header_component();
    init_assessment_complaint_alert_component();
    _c03 = ["*"];
    AssessmentLayoutComponent = class _AssessmentLayoutComponent {
      assessmentContainerClass = true;
      navigateBack = new EventEmitter3();
      MORE_FEEDBACK = ComplaintType.MORE_FEEDBACK;
      isLoading;
      saveBusy;
      submitBusy;
      cancelBusy;
      nextSubmissionBusy;
      correctionRound;
      isTeamMode;
      isAssessor;
      canOverride;
      isTestRun = false;
      isIllegalSubmission;
      exerciseDashboardLink;
      result;
      assessmentsAreValid;
      complaint;
      exercise;
      submission;
      hasAssessmentDueDatePassed;
      isProgrammingExercise;
      _highlightDifferences;
      set highlightDifferences(highlightDifferences) {
        this._highlightDifferences = highlightDifferences;
        this.highlightDifferencesChange.emit(this.highlightDifferences);
      }
      get highlightDifferences() {
        return this._highlightDifferences;
      }
      save = new EventEmitter3();
      submit = new EventEmitter3();
      cancel = new EventEmitter3();
      nextSubmission = new EventEmitter3();
      updateAssessmentAfterComplaint = new EventEmitter3();
      highlightDifferencesChange = new EventEmitter3();
      useAsExampleSubmission = new EventEmitter3();
      static \u0275fac = function AssessmentLayoutComponent_Factory(t) {
        return new (t || _AssessmentLayoutComponent)();
      };
      static \u0275cmp = i08.\u0275\u0275defineComponent({ type: _AssessmentLayoutComponent, selectors: [["jhi-assessment-layout"]], hostVars: 2, hostBindings: function AssessmentLayoutComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i08.\u0275\u0275classProp("assessment-container", ctx.assessmentContainerClass);
        }
      }, inputs: { isLoading: "isLoading", saveBusy: "saveBusy", submitBusy: "submitBusy", cancelBusy: "cancelBusy", nextSubmissionBusy: "nextSubmissionBusy", correctionRound: "correctionRound", isTeamMode: "isTeamMode", isAssessor: "isAssessor", canOverride: "canOverride", isTestRun: "isTestRun", isIllegalSubmission: "isIllegalSubmission", exerciseDashboardLink: "exerciseDashboardLink", result: "result", assessmentsAreValid: "assessmentsAreValid", complaint: "complaint", exercise: "exercise", submission: "submission", hasAssessmentDueDatePassed: "hasAssessmentDueDatePassed", isProgrammingExercise: "isProgrammingExercise", highlightDifferences: "highlightDifferences" }, outputs: { navigateBack: "navigateBack", save: "save", submit: "submit", cancel: "cancel", nextSubmission: "nextSubmission", updateAssessmentAfterComplaint: "updateAssessmentAfterComplaint", highlightDifferencesChange: "highlightDifferencesChange", useAsExampleSubmission: "useAsExampleSubmission" }, ngContentSelectors: _c03, decls: 7, vars: 24, consts: [[3, "isLoading", "saveBusy", "submitBusy", "cancelBusy", "nextSubmissionBusy", "isTeamMode", "isAssessor", "isTestRun", "isIllegalSubmission", "exerciseDashboardLink", "canOverride", "assessmentsAreValid", "hasAssessmentDueDatePassed", "exercise", "result", "correctionRound", "isProgrammingExercise", "highlightDifferences", "hasComplaint", "hasMoreFeedbackRequest", "complaintHandled", "complaintType", "navigateBack", "save", "submit", "cancel", "highlightDifferencesChange", "nextSubmission", "useAsExampleSubmission"], [3, "complaint"], [1, "row", "mt-4", 3, "zeroIndent", "complaint", "exercise", "isAssessor", "submission", "isTestRun", "updateAssessmentAfterComplaint"]], template: function AssessmentLayoutComponent_Template(rf, ctx) {
        if (rf & 1) {
          i08.\u0275\u0275projectionDef();
          i08.\u0275\u0275elementStart(0, "jhi-assessment-header", 0);
          i08.\u0275\u0275listener("navigateBack", function AssessmentLayoutComponent_Template_jhi_assessment_header_navigateBack_0_listener() {
            return ctx.navigateBack.emit();
          })("save", function AssessmentLayoutComponent_Template_jhi_assessment_header_save_0_listener() {
            return ctx.save.emit();
          })("submit", function AssessmentLayoutComponent_Template_jhi_assessment_header_submit_0_listener() {
            return ctx.submit.emit();
          })("cancel", function AssessmentLayoutComponent_Template_jhi_assessment_header_cancel_0_listener() {
            return ctx.cancel.emit();
          })("highlightDifferencesChange", function AssessmentLayoutComponent_Template_jhi_assessment_header_highlightDifferencesChange_0_listener($event) {
            return ctx.highlightDifferences = $event;
          })("nextSubmission", function AssessmentLayoutComponent_Template_jhi_assessment_header_nextSubmission_0_listener() {
            return ctx.nextSubmission.emit();
          })("useAsExampleSubmission", function AssessmentLayoutComponent_Template_jhi_assessment_header_useAsExampleSubmission_0_listener() {
            return ctx.useAsExampleSubmission.emit();
          });
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(1, "\n");
          i08.\u0275\u0275element(2, "jhi-assessment-complaint-alert", 1);
          i08.\u0275\u0275text(3, "\n");
          i08.\u0275\u0275projection(4);
          i08.\u0275\u0275text(5, "\n");
          i08.\u0275\u0275template(6, AssessmentLayoutComponent_Conditional_6_Template, 3, 6);
        }
        if (rf & 2) {
          i08.\u0275\u0275property("isLoading", ctx.isLoading)("saveBusy", ctx.saveBusy)("submitBusy", ctx.submitBusy)("cancelBusy", ctx.cancelBusy)("nextSubmissionBusy", ctx.nextSubmissionBusy)("isTeamMode", ctx.isTeamMode)("isAssessor", ctx.isAssessor)("isTestRun", ctx.isTestRun)("isIllegalSubmission", ctx.isIllegalSubmission)("exerciseDashboardLink", ctx.exerciseDashboardLink)("canOverride", ctx.canOverride)("assessmentsAreValid", ctx.assessmentsAreValid)("hasAssessmentDueDatePassed", ctx.hasAssessmentDueDatePassed)("exercise", ctx.exercise)("result", ctx.result)("correctionRound", ctx.correctionRound)("isProgrammingExercise", ctx.isProgrammingExercise)("highlightDifferences", ctx.highlightDifferences)("hasComplaint", !!ctx.complaint)("hasMoreFeedbackRequest", (ctx.complaint == null ? null : ctx.complaint.complaintType) === ctx.MORE_FEEDBACK)("complaintHandled", !!ctx.complaint ? ctx.complaint.accepted !== void 0 : false)("complaintType", ctx.complaint == null ? null : ctx.complaint.complaintType);
          i08.\u0275\u0275advance(2);
          i08.\u0275\u0275property("complaint", ctx.complaint);
          i08.\u0275\u0275advance(4);
          i08.\u0275\u0275conditional(6, ctx.complaint ? 6 : -1);
        }
      }, dependencies: [ComplaintsForTutorComponent, AssessmentHeaderComponent, AssessmentComplaintAlertComponent], styles: ["\n\n.assessment-container[_ngcontent-%COMP%] {\n  display: flex;\n  min-height: calc(100vh - 173px);\n  flex-flow: column nowrap;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9hc3Nlc3NtZW50L2Fzc2Vzc21lbnQtbGF5b3V0L2Fzc2Vzc21lbnQtbGF5b3V0LmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuYXNzZXNzbWVudC1jb250YWluZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgbWluLWhlaWdodDogY2FsYygxMDB2aCAtIDE3M3B4KTtcbiAgICBmbGV4LWZsb3c6IGNvbHVtbiBub3dyYXA7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxjQUFBLEtBQUEsTUFBQSxFQUFBO0FBQ0EsYUFBQSxPQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassDebugInfo(AssessmentLayoutComponent, { className: "AssessmentLayoutComponent" });
    })();
  }
});

// src/main/webapp/app/shared/score-display/score-display.component.ts
import { Component as Component6, Input as Input6 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faQuestionCircle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i09 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i23 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ScoreDisplayComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n        ");
    i09.\u0275\u0275elementStart(1, "span");
    i09.\u0275\u0275text(2);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(3, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275textInterpolate1("/\xA0", ctx_r0.maxPoints, "\xA0");
  }
}
function ScoreDisplayComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n        ");
    i09.\u0275\u0275elementStart(1, "span");
    i09.\u0275\u0275text(2);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(3, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275textInterpolate1("(Bonus:\xA0", ctx_r1.bonusPoints, ")\xA0");
  }
}
function ScoreDisplayComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n        ");
    i09.\u0275\u0275elementStart(1, "fa-icon", 2);
    i09.\u0275\u0275pipe(2, "artemisTranslate");
    i09.\u0275\u0275text(3, "\n        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(4, "\n    ");
  }
  if (rf & 2) {
    const ctx_r2 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275propertyInterpolate("ngbTooltip", i09.\u0275\u0275pipeBind2(2, 2, "artemisApp.assessment.dashboard.bonusPointExplanation", i09.\u0275\u0275pureFunction4(5, _c04, ctx_r2.maxPoints, ctx_r2.maxBonusPoints, ctx_r2.maxPointsWithBonus, ctx_r2.maxPercentage)));
    i09.\u0275\u0275property("icon", ctx_r2.faQuestionCircle);
  }
}
var _c04, ScoreDisplayComponent;
var init_score_display_component = __esm({
  "src/main/webapp/app/shared/score-display/score-display.component.ts"() {
    init_utils();
    init_course_model();
    init_translate_directive();
    init_artemis_translate_pipe();
    _c04 = (a0, a1, a2, a3) => ({ maxPoints: a0, maxBonusPoints: a1, maxPointsWithBonus: a2, maxPercentage: a3 });
    ScoreDisplayComponent = class _ScoreDisplayComponent {
      maxBonusPoints = 0;
      maxPoints;
      score;
      course;
      bonusPoints;
      maxPointsWithBonus;
      maxPercentage;
      faQuestionCircle = faQuestionCircle;
      constructor() {
      }
      ngOnChanges() {
        if (this.maxPoints != void 0 && this.maxBonusPoints > 0) {
          if (this.score > this.maxPoints) {
            this.bonusPoints = roundValueSpecifiedByCourseSettings(this.score - this.maxPoints, this.course);
          } else {
            this.bonusPoints = void 0;
          }
          this.maxPointsWithBonus = this.maxPoints + this.maxBonusPoints;
          this.maxPercentage = roundScorePercentSpecifiedByCourseSettings(this.maxPointsWithBonus / this.maxPoints, this.course);
        } else {
          this.bonusPoints = void 0;
          this.maxPointsWithBonus = void 0;
          this.maxPercentage = void 0;
        }
        this.score = roundValueSpecifiedByCourseSettings(this.score, this.course);
      }
      static \u0275fac = function ScoreDisplayComponent_Factory(t) {
        return new (t || _ScoreDisplayComponent)();
      };
      static \u0275cmp = i09.\u0275\u0275defineComponent({ type: _ScoreDisplayComponent, selectors: [["jhi-score-display"]], inputs: { maxBonusPoints: "maxBonusPoints", maxPoints: "maxPoints", score: "score", course: "course" }, features: [i09.\u0275\u0275NgOnChangesFeature], decls: 12, vars: 4, consts: [[1, "display-container"], ["jhiTranslate", "artemisApp.modelingAssessment.points"], ["placement", "bottom auto", 3, "icon", "ngbTooltip"]], template: function ScoreDisplayComponent_Template(rf, ctx) {
        if (rf & 1) {
          i09.\u0275\u0275elementStart(0, "div", 0);
          i09.\u0275\u0275text(1, "\n    ");
          i09.\u0275\u0275elementStart(2, "span");
          i09.\u0275\u0275text(3);
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(4, "\n    ");
          i09.\u0275\u0275template(5, ScoreDisplayComponent_Conditional_5_Template, 4, 1);
          i09.\u0275\u0275elementStart(6, "span", 1);
          i09.\u0275\u0275text(7, "Points\xA0");
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(8, "\n    ");
          i09.\u0275\u0275template(9, ScoreDisplayComponent_Conditional_9_Template, 4, 1)(10, ScoreDisplayComponent_Conditional_10_Template, 5, 10);
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(11, "\n");
        }
        if (rf & 2) {
          i09.\u0275\u0275advance(3);
          i09.\u0275\u0275textInterpolate1("", ctx.score || 0, "\xA0");
          i09.\u0275\u0275advance(2);
          i09.\u0275\u0275conditional(5, ctx.maxPoints ? 5 : -1);
          i09.\u0275\u0275advance(4);
          i09.\u0275\u0275conditional(9, ctx.bonusPoints ? 9 : -1);
          i09.\u0275\u0275advance(1);
          i09.\u0275\u0275conditional(10, ctx.maxBonusPoints ? 10 : -1);
        }
      }, dependencies: [i1.NgbTooltip, i23.FaIconComponent, TranslateDirective, ArtemisTranslatePipe], styles: ["\n\n.display-container[_ngcontent-%COMP%] {\n  display: flex;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvc2NvcmUtZGlzcGxheS9zY29yZS1kaXNwbGF5LmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuZGlzcGxheS1jb250YWluZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFdBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i09.\u0275setClassDebugInfo(ScoreDisplayComponent, { className: "ScoreDisplayComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/structured-grading-criterion/structured-grading-criterion.service.ts
import { Injectable as Injectable2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i010 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var StructuredGradingCriterionService;
var init_structured_grading_criterion_service = __esm({
  "src/main/webapp/app/exercises/shared/structured-grading-criterion/structured-grading-criterion.service.ts"() {
    StructuredGradingCriterionService = class _StructuredGradingCriterionService {
      updateFeedbackWithStructuredGradingInstructionEvent(feedback, event) {
        event.preventDefault();
        try {
          const data = event.dataTransfer.getData("text/plain");
          const instruction = JSON.parse(data);
          feedback.gradingInstruction = instruction;
          feedback.credits = instruction.credits;
        } catch (err) {
          if (!(err instanceof SyntaxError)) {
            throw err;
          }
        }
      }
      computeTotalScore(assessments) {
        let score = 0;
        const gradingInstructions = {};
        for (const feedback of assessments) {
          if (feedback.gradingInstruction) {
            score = this.calculateScoreForGradingInstructions(feedback, score, gradingInstructions);
          } else {
            score += feedback.credits;
          }
        }
        return score;
      }
      calculateScoreForGradingInstructions(feedback, score, gradingInstructions) {
        if (gradingInstructions[feedback.gradingInstruction.id]) {
          const maxCount = feedback.gradingInstruction.usageCount;
          const encounters = gradingInstructions[feedback.gradingInstruction.id];
          if (maxCount && maxCount > 0) {
            if (encounters >= maxCount) {
              gradingInstructions[feedback.gradingInstruction.id] = encounters + 1;
            } else {
              gradingInstructions[feedback.gradingInstruction.id] = encounters + 1;
              score += feedback.gradingInstruction.credits;
            }
          } else {
            score += feedback.credits;
          }
        } else {
          gradingInstructions[feedback.gradingInstruction.id] = 1;
          score += feedback.credits;
        }
        return score;
      }
      static \u0275fac = function StructuredGradingCriterionService_Factory(t) {
        return new (t || _StructuredGradingCriterionService)();
      };
      static \u0275prov = i010.\u0275\u0275defineInjectable({ token: _StructuredGradingCriterionService, factory: _StructuredGradingCriterionService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/assessment/unreferenced-feedback-detail/assessment-correction-round-badge/assessment-correction-round-badge.component.ts
import { Component as Component7, Input as Input7 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i011 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
function AssessmentCorrectionRoundBadgeComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n        ");
    i011.\u0275\u0275elementStart(1, "h5", 0);
    i011.\u0275\u0275text(2, "\n            ");
    i011.\u0275\u0275elementStart(3, "span", 1);
    i011.\u0275\u0275text(4, "First correction round");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(5, "\n        ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(6, "\n    ");
  }
  if (rf & 2) {
    i011.\u0275\u0275advance(3);
    i011.\u0275\u0275property("ngStyle", i011.\u0275\u0275pureFunction0(1, _c05));
  }
}
function AssessmentCorrectionRoundBadgeComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n        ");
    i011.\u0275\u0275elementStart(1, "h5", 0);
    i011.\u0275\u0275text(2, "\n            ");
    i011.\u0275\u0275elementStart(3, "span", 2);
    i011.\u0275\u0275text(4, "Second correction round");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(5, "\n        ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(6, "\n    ");
  }
  if (rf & 2) {
    i011.\u0275\u0275advance(3);
    i011.\u0275\u0275property("ngStyle", i011.\u0275\u0275pureFunction0(1, _c12));
  }
}
var _c05, _c12, AssessmentCorrectionRoundBadgeComponent;
var init_assessment_correction_round_badge_component = __esm({
  "src/main/webapp/app/assessment/unreferenced-feedback-detail/assessment-correction-round-badge/assessment-correction-round-badge.component.ts"() {
    init_feedback_model();
    init_translate_directive();
    _c05 = () => ({ backgroundColor: "#3e8acc" });
    _c12 = () => ({ backgroundColor: "#ffa561" });
    AssessmentCorrectionRoundBadgeComponent = class _AssessmentCorrectionRoundBadgeComponent {
      feedback;
      highlightDifferences = false;
      static \u0275fac = function AssessmentCorrectionRoundBadgeComponent_Factory(t) {
        return new (t || _AssessmentCorrectionRoundBadgeComponent)();
      };
      static \u0275cmp = i011.\u0275\u0275defineComponent({ type: _AssessmentCorrectionRoundBadgeComponent, selectors: [["jhi-assessment-correction-round-badge"]], inputs: { feedback: "feedback", highlightDifferences: "highlightDifferences" }, decls: 6, vars: 2, consts: [[1, "correction-label"], ["jhiTranslate", "artemisApp.assessment.diffView.correctionRoundDiffFirst", 1, "badge", "text-white", "me-1", 3, "ngStyle"], ["jhiTranslate", "artemisApp.assessment.diffView.correctionRoundDiffSecond", 1, "badge", "text-white", "me-1", 3, "ngStyle"]], template: function AssessmentCorrectionRoundBadgeComponent_Template(rf, ctx) {
        if (rf & 1) {
          i011.\u0275\u0275elementStart(0, "div");
          i011.\u0275\u0275text(1, "\n    ");
          i011.\u0275\u0275text(2, "\n    ");
          i011.\u0275\u0275template(3, AssessmentCorrectionRoundBadgeComponent_Conditional_3_Template, 7, 2)(4, AssessmentCorrectionRoundBadgeComponent_Conditional_4_Template, 7, 2);
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(5, "\n");
        }
        if (rf & 2) {
          i011.\u0275\u0275advance(3);
          i011.\u0275\u0275conditional(3, ctx.highlightDifferences && ctx.feedback.copiedFeedbackId ? 3 : -1);
          i011.\u0275\u0275advance(1);
          i011.\u0275\u0275conditional(4, ctx.highlightDifferences && !ctx.feedback.copiedFeedbackId ? 4 : -1);
        }
      }, dependencies: [i12.NgStyle, TranslateDirective], styles: ["\n\n.correction-label[_ngcontent-%COMP%] {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9hc3Nlc3NtZW50L3VucmVmZXJlbmNlZC1mZWVkYmFjay1kZXRhaWwvYXNzZXNzbWVudC1jb3JyZWN0aW9uLXJvdW5kLWJhZGdlL2Fzc2Vzc21lbnQtY29ycmVjdGlvbi1yb3VuZC1iYWRnZS5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmNvcnJlY3Rpb24tbGFiZWwge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksY0FBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i011.\u0275setClassDebugInfo(AssessmentCorrectionRoundBadgeComponent, { className: "AssessmentCorrectionRoundBadgeComponent" });
    })();
  }
});

// src/main/webapp/app/assessment/unreferenced-feedback-detail/unreferenced-feedback-detail.component.ts
import { Component as Component8, EventEmitter as EventEmitter4, Input as Input8, Output as Output4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faCheck, faExclamation, faExclamationTriangle, faQuestionCircle as faQuestionCircle2, faTrash as faTrash2, faTrashAlt } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { Subject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i012 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i24 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i34 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i45 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function UnreferencedFeedbackDetailComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275text(0, "\n            ");
    i012.\u0275\u0275element(1, "jhi-feedback-suggestion-badge", 11);
    i012.\u0275\u0275text(2, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(1);
    i012.\u0275\u0275property("feedback", ctx_r0.feedback)("useDefaultText", ctx_r0.useDefaultFeedbackSuggestionBadgeText);
  }
}
function UnreferencedFeedbackDetailComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275text(0, "\n            ");
    i012.\u0275\u0275element(1, "jhi-grading-instruction-link-icon", 12);
    i012.\u0275\u0275text(2, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(1);
    i012.\u0275\u0275property("feedback", ctx_r1.feedback);
  }
}
function UnreferencedFeedbackDetailComponent_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275text(0, "\n            ");
    i012.\u0275\u0275elementStart(1, "button", 13);
    i012.\u0275\u0275listener("delete", function UnreferencedFeedbackDetailComponent_Conditional_6_Template_button_delete_1_listener() {
      i012.\u0275\u0275restoreView(_r8);
      const ctx_r7 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r7.delete());
    });
    i012.\u0275\u0275text(2, "\n                ");
    i012.\u0275\u0275element(3, "fa-icon", 14);
    i012.\u0275\u0275text(4, "\n            ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r2 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(1);
    i012.\u0275\u0275property("buttonSize", ctx_r2.ButtonSize.SMALL)("translateValues", i012.\u0275\u0275pureFunction1(6, _c06, ctx_r2.feedback.detailText))("dialogError", ctx_r2.dialogError$)("renderButtonStyle", false)("renderButtonText", false);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275property("icon", ctx_r2.faTrashAlt);
  }
}
function UnreferencedFeedbackDetailComponent_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275text(0, "\n            ");
    i012.\u0275\u0275elementStart(1, "div", 15);
    i012.\u0275\u0275text(2, "\n                ");
    i012.\u0275\u0275elementStart(3, "button", 16);
    i012.\u0275\u0275listener("click", function UnreferencedFeedbackDetailComponent_Conditional_8_Template_button_click_3_listener() {
      i012.\u0275\u0275restoreView(_r10);
      const ctx_r9 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r9.onAcceptSuggestion.emit(ctx_r9.feedback));
    });
    i012.\u0275\u0275text(4, "\n                    ");
    i012.\u0275\u0275element(5, "fa-icon", 14);
    i012.\u0275\u0275text(6, "\n                    ");
    i012.\u0275\u0275elementStart(7, "span", 17);
    i012.\u0275\u0275text(8, "Accept");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(9, "\n                ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(10, "\n                ");
    i012.\u0275\u0275elementStart(11, "button", 18);
    i012.\u0275\u0275listener("click", function UnreferencedFeedbackDetailComponent_Conditional_8_Template_button_click_11_listener() {
      i012.\u0275\u0275restoreView(_r10);
      const ctx_r11 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r11.onDiscardSuggestion.emit(ctx_r11.feedback));
    });
    i012.\u0275\u0275text(12, "\n                    ");
    i012.\u0275\u0275element(13, "fa-icon", 14);
    i012.\u0275\u0275text(14, "\n                    ");
    i012.\u0275\u0275elementStart(15, "span", 19);
    i012.\u0275\u0275text(16, "Discard");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(17, "\n                ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(18, "\n            ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(19, "\n        ");
  }
  if (rf & 2) {
    const ctx_r3 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(5);
    i012.\u0275\u0275property("icon", ctx_r3.faCheck);
    i012.\u0275\u0275advance(8);
    i012.\u0275\u0275property("icon", ctx_r3.faTrash);
  }
}
function UnreferencedFeedbackDetailComponent_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275text(0, "\n                    ");
    i012.\u0275\u0275elementStart(1, "div");
    i012.\u0275\u0275text(2, "\n                        ");
    i012.\u0275\u0275element(3, "fa-icon", 20);
    i012.\u0275\u0275pipe(4, "artemisTranslate");
    i012.\u0275\u0275text(5, "\n                    ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(6, "\n                ");
  }
  if (rf & 2) {
    const ctx_r4 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275property("icon", ctx_r4.faQuestionCircle)("ngbTooltip", i012.\u0275\u0275pipeBind1(4, 2, "artemisApp.assessment.feedbackHint"));
  }
}
function UnreferencedFeedbackDetailComponent_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275text(0, "\n                    ");
    i012.\u0275\u0275elementStart(1, "div");
    i012.\u0275\u0275text(2, "\n                        ");
    i012.\u0275\u0275elementStart(3, "span");
    i012.\u0275\u0275text(4);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(5, "\n                    ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(6, "\n                ");
  }
  if (rf & 2) {
    const ctx_r5 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(4);
    i012.\u0275\u0275textInterpolate(ctx_r5.feedback.gradingInstruction.feedback);
  }
}
function UnreferencedFeedbackDetailComponent_Conditional_37_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275text(0, "\n                    ");
    i012.\u0275\u0275elementStart(1, "span", 21);
    i012.\u0275\u0275text(2);
    i012.\u0275\u0275pipe(3, "artemisTranslate");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(4, "\n                ");
  }
  if (rf & 2) {
    const ctx_r12 = i012.\u0275\u0275nextContext(2);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate1("", i012.\u0275\u0275pipeBind1(3, 1, "artemisApp.exampleSubmission.feedback." + ctx_r12.feedback.correctionStatus), " ");
  }
}
function UnreferencedFeedbackDetailComponent_Conditional_37_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275text(0, "\n                    ");
    i012.\u0275\u0275elementStart(1, "span", 22);
    i012.\u0275\u0275text(2);
    i012.\u0275\u0275pipe(3, "artemisTranslate");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(4, "\n                ");
  }
  if (rf & 2) {
    const ctx_r13 = i012.\u0275\u0275nextContext(2);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate1("", i012.\u0275\u0275pipeBind1(3, 1, "artemisApp.exampleSubmission.feedback." + ctx_r13.feedback.correctionStatus), " ");
  }
}
function UnreferencedFeedbackDetailComponent_Conditional_37_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275text(0, "\n                    ");
    i012.\u0275\u0275elementStart(1, "fa-layers");
    i012.\u0275\u0275text(2, "\n                        ");
    i012.\u0275\u0275element(3, "fa-icon", 23);
    i012.\u0275\u0275text(4, "\n                        ");
    i012.\u0275\u0275element(5, "fa-icon", 24);
    i012.\u0275\u0275text(6, "\n                    ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(7, "\n                ");
  }
  if (rf & 2) {
    const ctx_r14 = i012.\u0275\u0275nextContext(2);
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275property("icon", ctx_r14.faExclamationTriangle);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275property("icon", ctx_r14.faExclamation);
  }
}
function UnreferencedFeedbackDetailComponent_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275text(0, "\n            ");
    i012.\u0275\u0275elementStart(1, "div");
    i012.\u0275\u0275text(2, "\n                ");
    i012.\u0275\u0275template(3, UnreferencedFeedbackDetailComponent_Conditional_37_Conditional_3_Template, 5, 3)(4, UnreferencedFeedbackDetailComponent_Conditional_37_Conditional_4_Template, 5, 3);
    i012.\u0275\u0275text(5, "\n                ");
    i012.\u0275\u0275template(6, UnreferencedFeedbackDetailComponent_Conditional_37_Conditional_6_Template, 8, 2);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(7, "\n        ");
  }
  if (rf & 2) {
    const ctx_r6 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275conditional(3, ctx_r6.feedback.correctionStatus === "CORRECT" ? 3 : -1);
    i012.\u0275\u0275advance(1);
    i012.\u0275\u0275conditional(4, ctx_r6.feedback.correctionStatus !== "CORRECT" ? 4 : -1);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275conditional(6, ctx_r6.feedback.correctionStatus !== "CORRECT" ? 6 : -1);
  }
}
var _c06, UnreferencedFeedbackDetailComponent;
var init_unreferenced_feedback_detail_component = __esm({
  "src/main/webapp/app/assessment/unreferenced-feedback-detail/unreferenced-feedback-detail.component.ts"() {
    init_feedback_model();
    init_structured_grading_criterion_service();
    init_button_component();
    init_structured_grading_criterion_service();
    init_translate_directive();
    init_delete_button_directive();
    init_grading_instruction_link_icon_component();
    init_feedback_suggestion_badge_component();
    init_assessment_correction_round_badge_component();
    init_artemis_translate_pipe();
    _c06 = (a0) => ({ text: a0 });
    UnreferencedFeedbackDetailComponent = class _UnreferencedFeedbackDetailComponent {
      structuredGradingCriterionService;
      feedback;
      isSuggestion;
      readOnly;
      highlightDifferences;
      useDefaultFeedbackSuggestionBadgeText;
      onFeedbackChange = new EventEmitter4();
      onFeedbackDelete = new EventEmitter4();
      onAcceptSuggestion = new EventEmitter4();
      onDiscardSuggestion = new EventEmitter4();
      faTrashAlt = faTrashAlt;
      faQuestionCircle = faQuestionCircle2;
      faExclamation = faExclamation;
      faExclamationTriangle = faExclamationTriangle;
      faCheck = faCheck;
      faTrash = faTrash2;
      Feedback = Feedback;
      ButtonSize = ButtonSize;
      dialogErrorSource = new Subject();
      dialogError$ = this.dialogErrorSource.asObservable();
      constructor(structuredGradingCriterionService) {
        this.structuredGradingCriterionService = structuredGradingCriterionService;
      }
      emitChanges() {
        if (this.feedback.type === FeedbackType.AUTOMATIC) {
          this.feedback.type = FeedbackType.AUTOMATIC_ADAPTED;
        }
        Feedback.updateFeedbackTypeOnChange(this.feedback);
        this.onFeedbackChange.emit(this.feedback);
      }
      delete() {
        this.onFeedbackDelete.emit(this.feedback);
        this.dialogErrorSource.next("");
      }
      updateFeedbackOnDrop(event) {
        this.structuredGradingCriterionService.updateFeedbackWithStructuredGradingInstructionEvent(this.feedback, event);
        this.onFeedbackChange.emit(this.feedback);
      }
      static \u0275fac = function UnreferencedFeedbackDetailComponent_Factory(t) {
        return new (t || _UnreferencedFeedbackDetailComponent)(i012.\u0275\u0275directiveInject(StructuredGradingCriterionService));
      };
      static \u0275cmp = i012.\u0275\u0275defineComponent({ type: _UnreferencedFeedbackDetailComponent, selectors: [["jhi-unreferenced-feedback-detail"]], inputs: { feedback: "feedback", isSuggestion: "isSuggestion", readOnly: "readOnly", highlightDifferences: "highlightDifferences", useDefaultFeedbackSuggestionBadgeText: "useDefaultFeedbackSuggestionBadgeText" }, outputs: { onFeedbackChange: "onFeedbackChange", onFeedbackDelete: "onFeedbackDelete", onAcceptSuggestion: "onAcceptSuggestion", onDiscardSuggestion: "onDiscardSuggestion" }, decls: 42, vars: 24, consts: [[1, "unreferenced-feedback-detail", "card", "mb-3", 3, "drop", "dragover"], [1, "card-header"], [1, "card-body"], [1, "form-group", "row"], ["for", "feedback-points", "jhiTranslate", "artemisApp.exercise.score", 1, "col-4", "feedback-label"], ["id", "feedback-points", "type", "number", "step", "0.5", 1, "col", "form-control", 3, "ngModel", "readOnly", "disabled", "required", "ngModelChange"], [1, "col-4", "assessment-label"], ["jhiTranslate", "artemisApp.assessment.detail.feedback", 1, "pe-0"], [1, "col", "p-0"], ["id", "feedback-textarea", "rows", "2", 1, "form-control", 3, "ngModel", "readOnly", "disabled", "placeholder", "required", "ngModelChange"], [3, "feedback", "highlightDifferences"], [3, "feedback", "useDefaultText"], [3, "feedback"], ["jhiDeleteButton", "", "deleteQuestion", "artemisApp.feedback.delete.question", 1, "btn", "float-end", 3, "buttonSize", "translateValues", "dialogError", "renderButtonStyle", "renderButtonText", "delete"], [3, "icon"], [1, "row", "float-end", "suggestion-action-buttons"], [1, "btn", "btn-success", "m-1", "btn-sm", 3, "click"], ["jhiTranslate", "artemisApp.assessment.detail.accept"], [1, "btn", "btn-danger", "m-1", "btn-sm", 3, "click"], ["jhiTranslate", "artemisApp.assessment.detail.discard"], [1, "text-secondary", "ps-1", 3, "icon", "ngbTooltip"], [1, "text-success"], [1, "text-danger"], [1, "text-warning", 3, "icon"], ["size", "2x", "transform", "shrink-10", 1, "text-dark", "exclamation-icon", 3, "icon"]], template: function UnreferencedFeedbackDetailComponent_Template(rf, ctx) {
        if (rf & 1) {
          i012.\u0275\u0275elementStart(0, "div", 0);
          i012.\u0275\u0275listener("drop", function UnreferencedFeedbackDetailComponent_Template_div_drop_0_listener($event) {
            return ctx.updateFeedbackOnDrop($event);
          })("dragover", function UnreferencedFeedbackDetailComponent_Template_div_dragover_0_listener($event) {
            return $event.preventDefault();
          });
          i012.\u0275\u0275text(1, "\n    ");
          i012.\u0275\u0275elementStart(2, "div", 1);
          i012.\u0275\u0275text(3, "\n        ");
          i012.\u0275\u0275template(4, UnreferencedFeedbackDetailComponent_Conditional_4_Template, 3, 2)(5, UnreferencedFeedbackDetailComponent_Conditional_5_Template, 3, 1)(6, UnreferencedFeedbackDetailComponent_Conditional_6_Template, 6, 8);
          i012.\u0275\u0275text(7, "\n        ");
          i012.\u0275\u0275template(8, UnreferencedFeedbackDetailComponent_Conditional_8_Template, 20, 2);
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(9, "\n    ");
          i012.\u0275\u0275elementStart(10, "div", 2);
          i012.\u0275\u0275text(11, "\n        ");
          i012.\u0275\u0275elementStart(12, "div", 3);
          i012.\u0275\u0275text(13, "\n            ");
          i012.\u0275\u0275element(14, "label", 4);
          i012.\u0275\u0275text(15, "\n            ");
          i012.\u0275\u0275elementStart(16, "input", 5);
          i012.\u0275\u0275listener("ngModelChange", function UnreferencedFeedbackDetailComponent_Template_input_ngModelChange_16_listener($event) {
            return ctx.feedback.credits = $event;
          })("ngModelChange", function UnreferencedFeedbackDetailComponent_Template_input_ngModelChange_16_listener() {
            return ctx.emitChanges();
          });
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(17, "\n        ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(18, "\n        ");
          i012.\u0275\u0275elementStart(19, "div", 3);
          i012.\u0275\u0275text(20, "\n            ");
          i012.\u0275\u0275elementStart(21, "div", 6);
          i012.\u0275\u0275text(22, "\n                ");
          i012.\u0275\u0275element(23, "label", 7);
          i012.\u0275\u0275text(24, "\n                ");
          i012.\u0275\u0275template(25, UnreferencedFeedbackDetailComponent_Conditional_25_Template, 7, 4);
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(26, "\n            ");
          i012.\u0275\u0275elementStart(27, "div", 8);
          i012.\u0275\u0275text(28, "\n                ");
          i012.\u0275\u0275template(29, UnreferencedFeedbackDetailComponent_Conditional_29_Template, 7, 1);
          i012.\u0275\u0275elementStart(30, "textarea", 9);
          i012.\u0275\u0275listener("ngModelChange", function UnreferencedFeedbackDetailComponent_Template_textarea_ngModelChange_30_listener($event) {
            return ctx.feedback.detailText = $event;
          })("ngModelChange", function UnreferencedFeedbackDetailComponent_Template_textarea_ngModelChange_30_listener() {
            return ctx.emitChanges();
          });
          i012.\u0275\u0275pipe(31, "artemisTranslate");
          i012.\u0275\u0275pipe(32, "artemisTranslate");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(33, "\n            ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(34, "\n        ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(35, "\n        ");
          i012.\u0275\u0275text(36, "\n        ");
          i012.\u0275\u0275template(37, UnreferencedFeedbackDetailComponent_Conditional_37_Template, 8, 3);
          i012.\u0275\u0275element(38, "jhi-assessment-correction-round-badge", 10);
          i012.\u0275\u0275text(39, "\n    ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(40, "\n");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(41, "\n");
        }
        if (rf & 2) {
          i012.\u0275\u0275classProp("is-suggestion", ctx.isSuggestion);
          i012.\u0275\u0275advance(4);
          i012.\u0275\u0275conditional(4, ctx.isSuggestion || ctx.Feedback.isFeedbackSuggestion(ctx.feedback) ? 4 : -1);
          i012.\u0275\u0275advance(1);
          i012.\u0275\u0275conditional(5, ctx.feedback.gradingInstruction ? 5 : -1);
          i012.\u0275\u0275advance(1);
          i012.\u0275\u0275conditional(6, !ctx.readOnly ? 6 : -1);
          i012.\u0275\u0275advance(2);
          i012.\u0275\u0275conditional(8, ctx.isSuggestion ? 8 : -1);
          i012.\u0275\u0275advance(8);
          i012.\u0275\u0275property("ngModel", ctx.feedback.credits)("readOnly", ctx.feedback.gradingInstruction || ctx.readOnly)("disabled", ctx.readOnly)("required", !ctx.feedback.gradingInstruction);
          i012.\u0275\u0275advance(9);
          i012.\u0275\u0275conditional(25, ctx.feedback.gradingInstruction ? 25 : -1);
          i012.\u0275\u0275advance(4);
          i012.\u0275\u0275conditional(29, ctx.feedback.gradingInstruction ? 29 : -1);
          i012.\u0275\u0275advance(1);
          i012.\u0275\u0275property("ngModel", ctx.feedback.detailText)("readOnly", ctx.readOnly)("disabled", ctx.readOnly)("placeholder", (ctx.feedback.gradingInstruction == null ? null : ctx.feedback.gradingInstruction.feedback) ? i012.\u0275\u0275pipeBind1(31, 20, "artemisApp.assessment.additionalFeedbackCommentPlaceholder") : i012.\u0275\u0275pipeBind1(32, 22, "artemisApp.assessment.feedbackCommentPlaceholder"))("required", !(ctx.feedback.gradingInstruction == null ? null : ctx.feedback.gradingInstruction.feedback));
          i012.\u0275\u0275advance(7);
          i012.\u0275\u0275conditional(37, ctx.feedback.correctionStatus !== void 0 ? 37 : -1);
          i012.\u0275\u0275advance(1);
          i012.\u0275\u0275property("feedback", ctx.feedback)("highlightDifferences", ctx.highlightDifferences);
        }
      }, dependencies: [i24.DefaultValueAccessor, i24.NumberValueAccessor, i24.NgControlStatus, i24.RequiredValidator, i24.NgModel, i34.NgbTooltip, i45.FaIconComponent, i45.FaLayersComponent, TranslateDirective, DeleteButtonDirective, GradingInstructionLinkIconComponent, FeedbackSuggestionBadgeComponent, AssessmentCorrectionRoundBadgeComponent, ArtemisTranslatePipe], styles: ["\n\n.card-body[_ngcontent-%COMP%] {\n  padding-top: 5px;\n  padding-bottom: 5px;\n}\n.assessment-label[_ngcontent-%COMP%]    > label[_ngcontent-%COMP%] {\n  float: left;\n}\nfa-icon.exclamation-icon[_ngcontent-%COMP%] {\n  width: 16px;\n  margin-top: -6px;\n}\n.is-suggestion[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%], .is-suggestion[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%] {\n  background-color: var(--feedback-suggestions-background);\n}\n.is-suggestion[_ngcontent-%COMP%]   input[_ngcontent-%COMP%], .is-suggestion[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {\n  background-color: var(--feedback-suggestions-input-background);\n}\n.is-suggestion[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\n  opacity: 0.6;\n  transition: opacity 0.2s ease-in-out;\n}\n.is-suggestion[_ngcontent-%COMP%]:hover   .card-body[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\n  opacity: 1;\n}\n.suggestion-action-buttons[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  width: fit-content;\n}\n.assessment-label[_ngcontent-%COMP%] {\n  padding-left: 5px;\n  padding-right: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9hc3Nlc3NtZW50L3VucmVmZXJlbmNlZC1mZWVkYmFjay1kZXRhaWwvdW5yZWZlcmVuY2VkLWZlZWRiYWNrLWRldGFpbC5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmNhcmQtYm9keSB7XG4gICAgcGFkZGluZy10b3A6IDVweDtcbiAgICBwYWRkaW5nLWJvdHRvbTogNXB4O1xufVxuXG4uYXNzZXNzbWVudC1sYWJlbCA+IGxhYmVsIHtcbiAgICBmbG9hdDogbGVmdDtcbn1cblxuZmEtaWNvbi5leGNsYW1hdGlvbi1pY29uIHtcbiAgICB3aWR0aDogMTZweDtcbiAgICBtYXJnaW4tdG9wOiAtNnB4O1xufVxuXG4uaXMtc3VnZ2VzdGlvbiAuY2FyZC1oZWFkZXIsXG4uaXMtc3VnZ2VzdGlvbiAuY2FyZC1ib2R5IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1mZWVkYmFjay1zdWdnZXN0aW9ucy1iYWNrZ3JvdW5kKTtcbn1cblxuLmlzLXN1Z2dlc3Rpb24gaW5wdXQsXG4uaXMtc3VnZ2VzdGlvbiB0ZXh0YXJlYSB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tZmVlZGJhY2stc3VnZ2VzdGlvbnMtaW5wdXQtYmFja2dyb3VuZCk7XG59XG5cbi8qIFNsaWdodCBvcGFjaXR5IGZvciBzdWdnZXN0aW9ucyB1bnRpbCB0aGV5IGFyZSBob3ZlcmVkICovXG4uaXMtc3VnZ2VzdGlvbiAuY2FyZC1ib2R5ID4gKiB7XG4gICAgb3BhY2l0eTogMC42OyAvKiBncmV5IG91dCB0aGUgc3VnZ2VzdGlvbiBjb250ZW50IHRvIGluZGljYXRlIHRoYXQgaXQgaXMgbm90IHNhdmVkIHlldCAqL1xuICAgIHRyYW5zaXRpb246IG9wYWNpdHkgMC4ycyBlYXNlLWluLW91dDtcbn1cblxuLmlzLXN1Z2dlc3Rpb246aG92ZXIgLmNhcmQtYm9keSA+ICoge1xuICAgIG9wYWNpdHk6IDE7IC8qIG1ha2UgdGhlIHN1Z2dlc3Rpb24gbW9yZSByZWFkYWJsZSBvbiBob3ZlciAqL1xufVxuXG4uc3VnZ2VzdGlvbi1hY3Rpb24tYnV0dG9ucyBidXR0b24ge1xuICAgIHdpZHRoOiBmaXQtY29udGVudDtcbn1cblxuLmFzc2Vzc21lbnQtbGFiZWwge1xuICAgIHBhZGRpbmctbGVmdDogNXB4O1xuICAgIHBhZGRpbmctcmlnaHQ6IDVweDtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksZUFBQTtBQUNBLGtCQUFBOztBQUdKLENBQUEsaUJBQUEsRUFBQTtBQUNJLFNBQUE7O0FBR0osT0FBQSxDQUFBO0FBQ0ksU0FBQTtBQUNBLGNBQUE7O0FBR0osQ0FBQSxjQUFBLENBQUE7QUFBQSxDQUFBLGNBQUEsQ0FkQTtBQWdCSSxvQkFBQSxJQUFBOztBQUdKLENBTEEsY0FLQTtBQUFBLENBTEEsY0FLQTtBQUVJLG9CQUFBLElBQUE7O0FBSUosQ0FYQSxjQVdBLENBekJBLFVBeUJBLEVBQUE7QUFDSSxXQUFBO0FBQ0EsY0FBQSxRQUFBLEtBQUE7O0FBR0osQ0FoQkEsYUFnQkEsT0FBQSxDQTlCQSxVQThCQSxFQUFBO0FBQ0ksV0FBQTs7QUFHSixDQUFBLDBCQUFBO0FBQ0ksU0FBQTs7QUFHSixDQWpDQTtBQWtDSSxnQkFBQTtBQUNBLGlCQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i012.\u0275setClassDebugInfo(UnreferencedFeedbackDetailComponent, { className: "UnreferencedFeedbackDetailComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/modeling/assess/modeling-assessment.service.ts
import { Injectable as Injectable3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient, HttpParams } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i013 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var ModelingAssessmentService;
var init_modeling_assessment_service = __esm({
  "src/main/webapp/app/exercises/modeling/assess/modeling-assessment.service.ts"() {
    init_date_utils();
    ModelingAssessmentService = class _ModelingAssessmentService {
      http;
      MAX_FEEDBACK_TEXT_LENGTH = 500;
      MAX_FEEDBACK_DETAIL_TEXT_LENGTH = 5e3;
      resourceUrl = "api";
      constructor(http) {
        this.http = http;
      }
      saveAssessment(resultId, feedbacks, submissionId, submit = false) {
        let params = new HttpParams();
        if (submit) {
          params = params.set("submit", "true");
        }
        const url = `${this.resourceUrl}/modeling-submissions/${submissionId}/result/${resultId}/assessment`;
        return this.http.put(url, feedbacks, { params }).pipe(map((res) => this.convertResult(res)));
      }
      saveExampleAssessment(feedbacks, exampleSubmissionId) {
        const url = `${this.resourceUrl}/modeling-submissions/${exampleSubmissionId}/example-assessment`;
        return this.http.put(url, feedbacks).pipe(map((res) => this.convertResult(res)));
      }
      updateAssessmentAfterComplaint(feedbacks, complaintResponse, submissionId) {
        const url = `${this.resourceUrl}/modeling-submissions/${submissionId}/assessment-after-complaint`;
        const assessmentUpdate = {
          feedbacks,
          complaintResponse
        };
        return this.http.put(url, assessmentUpdate, { observe: "response" }).pipe(map((res) => this.convertResultEntityResponseTypeFromServer(res)));
      }
      getAssessment(submissionId) {
        return this.http.get(`${this.resourceUrl}/modeling-submissions/${submissionId}/result`).pipe(map((res) => this.convertResult(res)));
      }
      getExampleAssessment(exerciseId, submissionId) {
        const url = `${this.resourceUrl}/exercise/${exerciseId}/modeling-submissions/${submissionId}/example-assessment`;
        return this.http.get(url).pipe(map((res) => this.convertResult(res)));
      }
      cancelAssessment(submissionId) {
        return this.http.put(`${this.resourceUrl}/modeling-submissions/${submissionId}/cancel-assessment`, null);
      }
      deleteAssessment(participationId, submissionId, resultId) {
        return this.http.delete(`${this.resourceUrl}/participations/${participationId}/modeling-submissions/${submissionId}/results/${resultId}`);
      }
      convertResultEntityResponseTypeFromServer(res) {
        let result = _ModelingAssessmentService.convertItemFromServer(res.body);
        result = this.convertResult(result);
        result.completionDate = convertDateFromServer(result.completionDate);
        if (result.submission) {
          result.submission.submissionDate = convertDateFromServer(result.submission.submissionDate);
        }
        if (result.participation) {
          result.participation.initializationDate = convertDateFromServer(result.participation.initializationDate);
        }
        return res.clone({ body: result });
      }
      static convertItemFromServer(result) {
        return Object.assign({}, result);
      }
      convertResult(result) {
        if (!result || !result.feedbacks) {
          return result;
        }
        for (const feedback of result.feedbacks) {
          if (feedback.reference) {
            feedback.referenceType = feedback.reference.split(":")[0];
            feedback.referenceId = feedback.reference.split(":")[1];
          }
        }
        return result;
      }
      isFeedbackTextValid(feedback) {
        if (!feedback) {
          return true;
        }
        return feedback.every((feedbackItem) => (!feedbackItem.text || feedbackItem.text.length <= this.MAX_FEEDBACK_TEXT_LENGTH) && (!feedbackItem.detailText || feedbackItem.detailText.length <= this.MAX_FEEDBACK_DETAIL_TEXT_LENGTH));
      }
      static \u0275fac = function ModelingAssessmentService_Factory(t) {
        return new (t || _ModelingAssessmentService)(i013.\u0275\u0275inject(i13.HttpClient));
      };
      static \u0275prov = i013.\u0275\u0275defineInjectable({ token: _ModelingAssessmentService, factory: _ModelingAssessmentService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/assessment/assessment-locks/assessment-locks.component.ts
import { Component as Component9 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { Location as Location5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import { TranslateService as TranslateService3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import { faBan, faFolderOpen } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { combineLatest } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i014 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i14 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i7 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i8 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i11 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i122 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function AssessmentLocksComponent_Conditional_16_For_37_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n                                    ");
    i014.\u0275\u0275elementStart(1, "span");
    i014.\u0275\u0275text(2);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(3, "\n                                ");
  }
  if (rf & 2) {
    const submission_r3 = i014.\u0275\u0275nextContext().$implicit;
    i014.\u0275\u0275advance(2);
    i014.\u0275\u0275textInterpolate1("", submission_r3.latestResult.score, "%");
  }
}
function AssessmentLocksComponent_Conditional_16_For_37_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n                                        ");
    i014.\u0275\u0275elementStart(1, "a", 13);
    i014.\u0275\u0275text(2, "\n                                            ");
    i014.\u0275\u0275element(3, "fa-icon", 14);
    i014.\u0275\u0275text(4);
    i014.\u0275\u0275pipe(5, "artemisTranslate");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(6, "\n                                    ");
  }
  if (rf & 2) {
    const submission_r3 = i014.\u0275\u0275nextContext().$implicit;
    const ctx_r9 = i014.\u0275\u0275nextContext(2);
    i014.\u0275\u0275advance(1);
    i014.\u0275\u0275property("routerLink", i014.\u0275\u0275pureFunction4(6, _c07, ctx_r9.courseId, submission_r3.participation.exercise.id, submission_r3.participation.id, submission_r3.id));
    i014.\u0275\u0275advance(2);
    i014.\u0275\u0275property("icon", ctx_r9.faFolderOpen)("fixedWidth", true);
    i014.\u0275\u0275advance(1);
    i014.\u0275\u0275textInterpolate1("\xA0", i014.\u0275\u0275pipeBind1(5, 4, "artemisApp.assessment.dashboard.actions.open"), "\n                                        ");
  }
}
function AssessmentLocksComponent_Conditional_16_For_37_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n                                        ");
    i014.\u0275\u0275elementStart(1, "a", 13);
    i014.\u0275\u0275text(2, "\n                                            ");
    i014.\u0275\u0275element(3, "fa-icon", 14);
    i014.\u0275\u0275text(4);
    i014.\u0275\u0275pipe(5, "artemisTranslate");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(6, "\n                                    ");
  }
  if (rf & 2) {
    const submission_r3 = i014.\u0275\u0275nextContext().$implicit;
    const ctx_r10 = i014.\u0275\u0275nextContext(2);
    i014.\u0275\u0275advance(1);
    i014.\u0275\u0275property("routerLink", i014.\u0275\u0275pureFunction4(6, _c13, ctx_r10.courseId, submission_r3.participation.exercise.type + "-exercises", submission_r3.participation.exercise.id, submission_r3.id));
    i014.\u0275\u0275advance(2);
    i014.\u0275\u0275property("icon", ctx_r10.faFolderOpen)("fixedWidth", true);
    i014.\u0275\u0275advance(1);
    i014.\u0275\u0275textInterpolate1("\xA0", i014.\u0275\u0275pipeBind1(5, 4, "artemisApp.assessment.dashboard.actions.open"), "\n                                        ");
  }
}
function AssessmentLocksComponent_Conditional_16_For_37_Conditional_35_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = i014.\u0275\u0275getCurrentView();
    i014.\u0275\u0275text(0, "\n                                        ");
    i014.\u0275\u0275elementStart(1, "button", 15);
    i014.\u0275\u0275listener("click", function AssessmentLocksComponent_Conditional_16_For_37_Conditional_35_Template_button_click_1_listener() {
      i014.\u0275\u0275restoreView(_r17);
      const submission_r3 = i014.\u0275\u0275nextContext().$implicit;
      const ctx_r15 = i014.\u0275\u0275nextContext(2);
      return i014.\u0275\u0275resetView(ctx_r15.cancelAssessment(submission_r3));
    });
    i014.\u0275\u0275text(2, "\n                                            ");
    i014.\u0275\u0275element(3, "fa-icon", 14);
    i014.\u0275\u0275text(4);
    i014.\u0275\u0275pipe(5, "artemisTranslate");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(6, "\n                                    ");
  }
  if (rf & 2) {
    const ctx_r11 = i014.\u0275\u0275nextContext(3);
    i014.\u0275\u0275advance(3);
    i014.\u0275\u0275property("icon", ctx_r11.faBan)("fixedWidth", true);
    i014.\u0275\u0275advance(1);
    i014.\u0275\u0275textInterpolate1("\xA0", i014.\u0275\u0275pipeBind1(5, 3, "artemisApp.assessment.dashboard.actions.cancel"), "\n                                        ");
  }
}
function AssessmentLocksComponent_Conditional_16_For_37_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n                        ");
    i014.\u0275\u0275elementStart(1, "tr");
    i014.\u0275\u0275text(2, "\n                            ");
    i014.\u0275\u0275elementStart(3, "td");
    i014.\u0275\u0275text(4);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(5, "\n                            ");
    i014.\u0275\u0275elementStart(6, "td");
    i014.\u0275\u0275text(7, "\n                                ");
    i014.\u0275\u0275element(8, "fa-icon", 12);
    i014.\u0275\u0275pipe(9, "artemisTranslate");
    i014.\u0275\u0275text(10, "\n                            ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(11, "\n                            ");
    i014.\u0275\u0275elementStart(12, "td");
    i014.\u0275\u0275text(13);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(14, "\n                            ");
    i014.\u0275\u0275elementStart(15, "td");
    i014.\u0275\u0275text(16);
    i014.\u0275\u0275pipe(17, "artemisDate");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(18, "\n                            ");
    i014.\u0275\u0275elementStart(19, "td");
    i014.\u0275\u0275text(20);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(21, "\n                            ");
    i014.\u0275\u0275elementStart(22, "td");
    i014.\u0275\u0275text(23, "\n                                ");
    i014.\u0275\u0275template(24, AssessmentLocksComponent_Conditional_16_For_37_Conditional_24_Template, 4, 1);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(25, "\n                            ");
    i014.\u0275\u0275elementStart(26, "td");
    i014.\u0275\u0275text(27, "\n                                ");
    i014.\u0275\u0275elementStart(28, "span");
    i014.\u0275\u0275text(29, "\n                                    ");
    i014.\u0275\u0275template(30, AssessmentLocksComponent_Conditional_16_For_37_Conditional_30_Template, 7, 11)(31, AssessmentLocksComponent_Conditional_16_For_37_Conditional_31_Template, 7, 11);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(32, "\n                                ");
    i014.\u0275\u0275elementStart(33, "span");
    i014.\u0275\u0275text(34, "\n                                    ");
    i014.\u0275\u0275template(35, AssessmentLocksComponent_Conditional_16_For_37_Conditional_35_Template, 7, 5);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(36, "\n                            ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(37, "\n                        ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(38, "\n                    ");
  }
  if (rf & 2) {
    const submission_r3 = ctx.$implicit;
    const ctx_r2 = i014.\u0275\u0275nextContext(2);
    i014.\u0275\u0275advance(4);
    i014.\u0275\u0275textInterpolate(submission_r3.id);
    i014.\u0275\u0275advance(4);
    i014.\u0275\u0275property("icon", ctx_r2.getIcon(submission_r3.participation.exercise.type))("ngbTooltip", i014.\u0275\u0275pipeBind1(9, 10, ctx_r2.getIconTooltip(submission_r3.participation.exercise.type)));
    i014.\u0275\u0275advance(5);
    i014.\u0275\u0275textInterpolate(submission_r3.participation.exercise.title || "");
    i014.\u0275\u0275advance(3);
    i014.\u0275\u0275textInterpolate(i014.\u0275\u0275pipeBind2(17, 12, submission_r3.submissionDate, "long-date"));
    i014.\u0275\u0275advance(4);
    i014.\u0275\u0275textInterpolate(submission_r3.participation.submissions ? submission_r3.participation.submissions.length : 0);
    i014.\u0275\u0275advance(4);
    i014.\u0275\u0275conditional(24, (submission_r3.latestResult == null ? null : submission_r3.latestResult.score) != void 0 ? 24 : -1);
    i014.\u0275\u0275advance(6);
    i014.\u0275\u0275conditional(30, submission_r3.participation.exercise.type === ctx_r2.ExerciseType.TEXT ? 30 : -1);
    i014.\u0275\u0275advance(1);
    i014.\u0275\u0275conditional(31, submission_r3.participation.exercise.type !== ctx_r2.ExerciseType.TEXT ? 31 : -1);
    i014.\u0275\u0275advance(4);
    i014.\u0275\u0275conditional(35, !submission_r3.latestResult.completionDate ? 35 : -1);
  }
}
function AssessmentLocksComponent_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n    ");
    i014.\u0275\u0275elementStart(1, "div");
    i014.\u0275\u0275text(2, "\n        ");
    i014.\u0275\u0275elementStart(3, "div", 3);
    i014.\u0275\u0275text(4, "\n            ");
    i014.\u0275\u0275elementStart(5, "table", 4);
    i014.\u0275\u0275text(6, "\n                ");
    i014.\u0275\u0275elementStart(7, "thead");
    i014.\u0275\u0275text(8, "\n                    ");
    i014.\u0275\u0275elementStart(9, "tr");
    i014.\u0275\u0275text(10, "\n                        ");
    i014.\u0275\u0275elementStart(11, "th", 5);
    i014.\u0275\u0275text(12, "Id");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(13, "\n                        ");
    i014.\u0275\u0275elementStart(14, "th", 6);
    i014.\u0275\u0275text(15, "Type");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(16, "\n                        ");
    i014.\u0275\u0275elementStart(17, "th", 7);
    i014.\u0275\u0275text(18, "Exercise");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(19, "\n                        ");
    i014.\u0275\u0275elementStart(20, "th", 8);
    i014.\u0275\u0275text(21, "Submission date");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(22, "\n                        ");
    i014.\u0275\u0275elementStart(23, "th", 9);
    i014.\u0275\u0275text(24, "Submission count");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(25, "\n                        ");
    i014.\u0275\u0275elementStart(26, "th", 10);
    i014.\u0275\u0275text(27, "Score");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(28, "\n                        ");
    i014.\u0275\u0275elementStart(29, "th", 11);
    i014.\u0275\u0275text(30, "Action");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(31, "\n                    ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(32, "\n                ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(33, "\n                ");
    i014.\u0275\u0275elementStart(34, "tbody");
    i014.\u0275\u0275text(35, "\n                    ");
    i014.\u0275\u0275repeaterCreate(36, AssessmentLocksComponent_Conditional_16_For_37_Template, 39, 15, null, null, i014.\u0275\u0275repeaterTrackByIdentity);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(38, "\n            ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(39, "\n        ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(40, "\n    ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(41, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i014.\u0275\u0275nextContext();
    i014.\u0275\u0275advance(36);
    i014.\u0275\u0275repeater(ctx_r0.submissions);
  }
}
function AssessmentLocksComponent_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n    ");
    i014.\u0275\u0275elementStart(1, "div", 16);
    i014.\u0275\u0275text(2, "\n        ");
    i014.\u0275\u0275elementStart(3, "p", 17);
    i014.\u0275\u0275text(4, "No Assessments locked by you!");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(5, "\n    ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(6, "\n");
  }
}
var _c07, _c13, AssessmentLocksComponent;
var init_assessment_locks_component = __esm({
  "src/main/webapp/app/assessment/assessment-locks/assessment-locks.component.ts"() {
    init_file_upload_assessment_service();
    init_course_management_service();
    init_exercise_model();
    init_alert_service();
    init_modeling_assessment_service();
    init_text_assessment_service();
    init_programming_assessment_manual_result_service();
    init_exam_management_service();
    init_alert_service();
    init_modeling_assessment_service();
    init_text_assessment_service();
    init_file_upload_assessment_service();
    init_programming_assessment_manual_result_service();
    init_course_management_service();
    init_exam_management_service();
    init_translate_directive();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    _c07 = (a1, a3, a5, a7) => ["/course-management", a1, "text-exercises", a3, "participations", a5, "submissions", a7, "assessment"];
    _c13 = (a1, a2, a3, a5) => ["/course-management", a1, a2, a3, "submissions", a5, "assessment"];
    AssessmentLocksComponent = class _AssessmentLocksComponent {
      route;
      alertService;
      modelingAssessmentService;
      textAssessmentService;
      fileUploadAssessmentService;
      programmingAssessmentService;
      location;
      courseService;
      examManagementService;
      PROGRAMMING_EXERCISE = ExerciseType.PROGRAMMING;
      ExerciseType = ExerciseType;
      course;
      courseId;
      tutorId;
      examId;
      showAll = false;
      exercises = [];
      submissions = [];
      cancelConfirmationText;
      getIcon = getIcon;
      getIconTooltip = getIconTooltip;
      faBan = faBan;
      faFolderOpen = faFolderOpen;
      constructor(route, alertService, modelingAssessmentService, textAssessmentService, fileUploadAssessmentService, programmingAssessmentService, translateService, location, courseService, examManagementService) {
        this.route = route;
        this.alertService = alertService;
        this.modelingAssessmentService = modelingAssessmentService;
        this.textAssessmentService = textAssessmentService;
        this.fileUploadAssessmentService = fileUploadAssessmentService;
        this.programmingAssessmentService = programmingAssessmentService;
        this.location = location;
        this.courseService = courseService;
        this.examManagementService = examManagementService;
        translateService.get("artemisApp.assessment.messages.confirmCancel").subscribe((text) => this.cancelConfirmationText = text);
      }
      ngOnInit() {
        combineLatest([this.route.params, this.route.queryParams]).subscribe(([params, queryParams]) => {
          this.courseId = Number(params["courseId"]);
          this.examId = Number(params["examId"]);
          this.tutorId = Number(queryParams["tutorId"]);
          this.getAllLockedSubmissions();
        });
      }
      getAllLockedSubmissions() {
        let lockedSubmissionsObservable;
        if (this.examId) {
          lockedSubmissionsObservable = this.examManagementService.findAllLockedSubmissionsOfExam(this.courseId, this.examId);
          this.showAll = true;
        } else {
          lockedSubmissionsObservable = this.courseService.findAllLockedSubmissionsOfCourse(this.courseId);
        }
        lockedSubmissionsObservable.subscribe({
          next: (response) => {
            this.submissions.push(...response.body ?? []);
          },
          error: (response) => this.onError(response)
        });
      }
      cancelAssessment(canceledSubmission) {
        const confirmCancel = window.confirm(this.cancelConfirmationText);
        if (confirmCancel) {
          switch (canceledSubmission.submissionExerciseType) {
            case "modeling":
              this.modelingAssessmentService.cancelAssessment(canceledSubmission.id).subscribe();
              break;
            case "text":
              if (canceledSubmission.participation?.exercise?.id) {
                this.textAssessmentService.cancelAssessment(canceledSubmission.participation.id, canceledSubmission.id).subscribe();
              }
              break;
            case "file-upload":
              this.fileUploadAssessmentService.cancelAssessment(canceledSubmission.id).subscribe();
              break;
            case "programming":
              this.programmingAssessmentService.cancelAssessment(canceledSubmission.id).subscribe();
              break;
            default:
              break;
          }
          this.submissions = this.submissions.filter((submission) => submission !== canceledSubmission);
        }
      }
      onError(error) {
        this.alertService.error(error);
      }
      static \u0275fac = function AssessmentLocksComponent_Factory(t) {
        return new (t || _AssessmentLocksComponent)(i014.\u0275\u0275directiveInject(i14.ActivatedRoute), i014.\u0275\u0275directiveInject(AlertService), i014.\u0275\u0275directiveInject(ModelingAssessmentService), i014.\u0275\u0275directiveInject(TextAssessmentService), i014.\u0275\u0275directiveInject(FileUploadAssessmentService), i014.\u0275\u0275directiveInject(ProgrammingAssessmentManualResultService), i014.\u0275\u0275directiveInject(i7.TranslateService), i014.\u0275\u0275directiveInject(i8.Location), i014.\u0275\u0275directiveInject(CourseManagementService), i014.\u0275\u0275directiveInject(ExamManagementService));
      };
      static \u0275cmp = i014.\u0275\u0275defineComponent({ type: _AssessmentLocksComponent, selectors: [["jhi-assessment-locks"]], decls: 18, vars: 5, consts: [[1, "course-info-bar"], [1, "row", "justify-content-between"], [1, "col-md-8"], [1, "table-responsive"], [1, "table", "table-striped", "exercise-table"], [1, "th-link"], ["jhiTranslate", "artemisApp.assessment.locks.type", 1, "th-link"], ["jhiTranslate", "artemisApp.assessment.locks.exercise", 1, "th-link"], ["jhiTranslate", "artemisApp.assessment.dashboard.columns.submissionDate", 1, "th-link"], ["jhiTranslate", "artemisApp.assessment.dashboard.columns.submissionCount", 1, "th-link"], ["jhiTranslate", "artemisApp.assessment.dashboard.columns.score", 1, "th-link"], ["jhiTranslate", "artemisApp.assessment.dashboard.columns.action", 1, "th-link"], ["placement", "right auto", 3, "icon", "ngbTooltip"], [1, "btn", "btn-outline-secondary", "btn-sm", "mb-1", 3, "routerLink"], [3, "icon", "fixedWidth"], [1, "btn", "btn-outline-secondary", "btn-sm", "mb-1", 3, "click"], [2, "margin-top", "10px"], ["jhiTranslate", "artemisApp.assessment.locks.empty"]], template: function AssessmentLocksComponent_Template(rf, ctx) {
        if (rf & 1) {
          i014.\u0275\u0275elementStart(0, "div", 0);
          i014.\u0275\u0275text(1, "\n    ");
          i014.\u0275\u0275elementStart(2, "div", 1);
          i014.\u0275\u0275text(3, "\n        ");
          i014.\u0275\u0275elementStart(4, "div", 2);
          i014.\u0275\u0275text(5, "\n            ");
          i014.\u0275\u0275elementStart(6, "h2");
          i014.\u0275\u0275text(7, "\n                ");
          i014.\u0275\u0275elementStart(8, "span");
          i014.\u0275\u0275text(9);
          i014.\u0275\u0275pipe(10, "artemisTranslate");
          i014.\u0275\u0275elementEnd();
          i014.\u0275\u0275text(11, "\n            ");
          i014.\u0275\u0275elementEnd();
          i014.\u0275\u0275text(12, "\n        ");
          i014.\u0275\u0275elementEnd();
          i014.\u0275\u0275text(13, "\n    ");
          i014.\u0275\u0275elementEnd();
          i014.\u0275\u0275text(14, "\n");
          i014.\u0275\u0275elementEnd();
          i014.\u0275\u0275text(15, "\n");
          i014.\u0275\u0275template(16, AssessmentLocksComponent_Conditional_16_Template, 42, 0)(17, AssessmentLocksComponent_Conditional_17_Template, 7, 0);
        }
        if (rf & 2) {
          i014.\u0275\u0275advance(9);
          i014.\u0275\u0275textInterpolate(i014.\u0275\u0275pipeBind1(10, 3, "artemisApp.assessment.locks.title" + (ctx.showAll ? "All" : "")));
          i014.\u0275\u0275advance(7);
          i014.\u0275\u0275conditional(16, ctx.submissions.length > 0 ? 16 : -1);
          i014.\u0275\u0275advance(1);
          i014.\u0275\u0275conditional(17, ctx.submissions.length === 0 ? 17 : -1);
        }
      }, dependencies: [i11.NgbTooltip, i122.FaIconComponent, TranslateDirective, i14.RouterLink, ArtemisDatePipe, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i014.\u0275setClassDebugInfo(AssessmentLocksComponent, { className: "AssessmentLocksComponent" });
    })();
  }
});

// src/main/webapp/app/course/manage/course-management-resolve.service.ts
import { Injectable as Injectable4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { filter, map as map2, of } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i015 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var CourseManagementResolve;
var init_course_management_resolve_service = __esm({
  "src/main/webapp/app/course/manage/course-management-resolve.service.ts"() {
    init_course_model();
    init_course_management_service();
    init_course_management_service();
    CourseManagementResolve = class _CourseManagementResolve {
      service;
      constructor(service) {
        this.service = service;
      }
      resolve(route) {
        if (route.params["courseId"]) {
          return this.service.find(route.params["courseId"]).pipe(filter((response) => response.ok), map2((course) => course.body));
        }
        return of(new Course());
      }
      static \u0275fac = function CourseManagementResolve_Factory(t) {
        return new (t || _CourseManagementResolve)(i015.\u0275\u0275inject(CourseManagementService));
      };
      static \u0275prov = i015.\u0275\u0275defineInjectable({ token: _CourseManagementResolve, factory: _CourseManagementResolve.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/assessment/assessment-locks/assessment-locks.route.ts
var assessmentLocksRoute;
var init_assessment_locks_route = __esm({
  "src/main/webapp/app/assessment/assessment-locks/assessment-locks.route.ts"() {
    init_user_route_access_service();
    init_assessment_locks_component();
    init_authority_constants();
    init_course_management_resolve_service();
    assessmentLocksRoute = [
      {
        path: ":courseId/exams/:examId/assessment-locks",
        component: AssessmentLocksComponent,
        resolve: {
          course: CourseManagementResolve
        },
        data: {
          authorities: [Authority.ADMIN, Authority.INSTRUCTOR, Authority.EDITOR, Authority.TA],
          pageTitle: "artemisApp.assessment.locks.home.title"
        },
        canActivate: [UserRouteAccessService]
      },
      {
        path: ":courseId/assessment-locks",
        component: AssessmentLocksComponent,
        resolve: {
          course: CourseManagementResolve
        },
        data: {
          authorities: [Authority.ADMIN, Authority.INSTRUCTOR, Authority.EDITOR, Authority.TA],
          pageTitle: "artemisApp.assessment.locks.home.title"
        },
        canActivate: [UserRouteAccessService]
      }
    ];
  }
});

// src/main/webapp/app/exercises/shared/unreferenced-feedback/unreferenced-feedback.component.ts
import { Component as Component10, EventEmitter as EventEmitter5, Input as Input9, Output as Output5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i016 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function UnreferencedFeedbackComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i016.\u0275\u0275text(0, "\n                ");
    i016.\u0275\u0275elementStart(1, "div", 5);
    i016.\u0275\u0275text(2, "\n                    ");
    i016.\u0275\u0275elementStart(3, "div", 6);
    i016.\u0275\u0275text(4, "\n                        ");
    i016.\u0275\u0275elementStart(5, "p");
    i016.\u0275\u0275text(6);
    i016.\u0275\u0275pipe(7, "artemisTranslate");
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275text(8, "\n                    ");
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275text(9, "\n                ");
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275text(10, "\n            ");
  }
  if (rf & 2) {
    i016.\u0275\u0275advance(6);
    i016.\u0275\u0275textInterpolate(i016.\u0275\u0275pipeBind1(7, 1, "artemisApp.fileUploadAssessment.assessInstructionWithDropOption"));
  }
}
function UnreferencedFeedbackComponent_For_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = i016.\u0275\u0275getCurrentView();
    i016.\u0275\u0275text(0, "\n                ");
    i016.\u0275\u0275elementStart(1, "div", 7);
    i016.\u0275\u0275text(2, "\n                    ");
    i016.\u0275\u0275elementStart(3, "jhi-unreferenced-feedback-detail", 8);
    i016.\u0275\u0275listener("onFeedbackChange", function UnreferencedFeedbackComponent_For_15_Template_jhi_unreferenced_feedback_detail_onFeedbackChange_3_listener() {
      const restoredCtx = i016.\u0275\u0275restoreView(_r9);
      const feedback_r3 = restoredCtx.$implicit;
      const ctx_r8 = i016.\u0275\u0275nextContext();
      return i016.\u0275\u0275resetView(ctx_r8.updateFeedback(feedback_r3));
    })("onFeedbackDelete", function UnreferencedFeedbackComponent_For_15_Template_jhi_unreferenced_feedback_detail_onFeedbackDelete_3_listener() {
      const restoredCtx = i016.\u0275\u0275restoreView(_r9);
      const feedback_r3 = restoredCtx.$implicit;
      const ctx_r10 = i016.\u0275\u0275nextContext();
      return i016.\u0275\u0275resetView(ctx_r10.deleteFeedback(feedback_r3));
    });
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275text(4, "\n                ");
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const feedback_r3 = ctx.$implicit;
    const ctx_r1 = i016.\u0275\u0275nextContext();
    i016.\u0275\u0275advance(3);
    i016.\u0275\u0275property("feedback", feedback_r3)("readOnly", ctx_r1.readOnly)("highlightDifferences", ctx_r1.highlightDifferences)("useDefaultFeedbackSuggestionBadgeText", ctx_r1.useDefaultFeedbackSuggestionBadgeText);
  }
}
function UnreferencedFeedbackComponent_For_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = i016.\u0275\u0275getCurrentView();
    i016.\u0275\u0275text(0, "\n                ");
    i016.\u0275\u0275elementStart(1, "div", 7);
    i016.\u0275\u0275text(2, "\n                    ");
    i016.\u0275\u0275elementStart(3, "jhi-unreferenced-feedback-detail", 9);
    i016.\u0275\u0275listener("onAcceptSuggestion", function UnreferencedFeedbackComponent_For_17_Template_jhi_unreferenced_feedback_detail_onAcceptSuggestion_3_listener($event) {
      i016.\u0275\u0275restoreView(_r17);
      const ctx_r16 = i016.\u0275\u0275nextContext();
      return i016.\u0275\u0275resetView(ctx_r16.acceptSuggestion($event));
    })("onDiscardSuggestion", function UnreferencedFeedbackComponent_For_17_Template_jhi_unreferenced_feedback_detail_onDiscardSuggestion_3_listener($event) {
      i016.\u0275\u0275restoreView(_r17);
      const ctx_r18 = i016.\u0275\u0275nextContext();
      return i016.\u0275\u0275resetView(ctx_r18.discardSuggestion($event));
    });
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275text(4, "\n                ");
    i016.\u0275\u0275elementEnd();
    i016.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const suggestion_r11 = ctx.$implicit;
    const ctx_r2 = i016.\u0275\u0275nextContext();
    i016.\u0275\u0275advance(3);
    i016.\u0275\u0275property("feedback", suggestion_r11)("isSuggestion", true)("readOnly", true)("useDefaultFeedbackSuggestionBadgeText", ctx_r2.useDefaultFeedbackSuggestionBadgeText);
  }
}
var UnreferencedFeedbackComponent;
var init_unreferenced_feedback_component = __esm({
  "src/main/webapp/app/exercises/shared/unreferenced-feedback/unreferenced-feedback.component.ts"() {
    init_feedback_model();
    init_structured_grading_criterion_service();
    init_structured_grading_criterion_service();
    init_translate_directive();
    init_unreferenced_feedback_detail_component();
    init_artemis_translate_pipe();
    UnreferencedFeedbackComponent = class _UnreferencedFeedbackComponent {
      structuredGradingCriterionService;
      FeedbackType = FeedbackType;
      unreferencedFeedback = [];
      assessmentsAreValid;
      readOnly;
      highlightDifferences;
      useDefaultFeedbackSuggestionBadgeText = false;
      addReferenceIdForExampleSubmission = false;
      set feedbacks(feedbacks) {
        this.unreferencedFeedback = [...feedbacks];
      }
      feedbackSuggestions = [];
      feedbacksChange = new EventEmitter5();
      onAcceptSuggestion = new EventEmitter5();
      onDiscardSuggestion = new EventEmitter5();
      constructor(structuredGradingCriterionService) {
        this.structuredGradingCriterionService = structuredGradingCriterionService;
      }
      deleteFeedback(feedbackToDelete) {
        const indexToDelete = this.unreferencedFeedback.indexOf(feedbackToDelete);
        this.unreferencedFeedback.splice(indexToDelete, 1);
        this.feedbacksChange.emit(this.unreferencedFeedback);
        this.validateFeedback();
      }
      validateFeedback() {
        if (!this.unreferencedFeedback || this.unreferencedFeedback.length === 0) {
          this.assessmentsAreValid = false;
          return;
        }
        for (const feedback of this.unreferencedFeedback) {
          if (feedback.credits == void 0 || isNaN(feedback.credits)) {
            this.assessmentsAreValid = false;
            return;
          }
        }
        this.assessmentsAreValid = true;
      }
      updateFeedback(feedback) {
        const indexToUpdate = this.unreferencedFeedback.indexOf(feedback);
        if (indexToUpdate < 0) {
          this.unreferencedFeedback.push(feedback);
        } else {
          this.unreferencedFeedback[indexToUpdate] = feedback;
        }
        this.validateFeedback();
        this.feedbacksChange.emit(this.unreferencedFeedback);
      }
      addUnreferencedFeedback() {
        const feedback = new Feedback();
        feedback.type = FeedbackType.MANUAL_UNREFERENCED;
        if (this.addReferenceIdForExampleSubmission) {
          feedback.reference = this.generateNewUnreferencedFeedbackReference().toString();
        }
        this.unreferencedFeedback.push(feedback);
        this.validateFeedback();
        this.feedbacksChange.emit(this.unreferencedFeedback);
      }
      generateNewUnreferencedFeedbackReference() {
        if (this.unreferencedFeedback.length === 0) {
          return 1;
        }
        const references = this.unreferencedFeedback.map((feedback) => {
          const id = +(feedback.reference ?? "0");
          if (isNaN(id)) {
            return 0;
          }
          return id;
        });
        return Math.max(...references.concat([0])) + 1;
      }
      acceptSuggestion(feedback) {
        this.feedbackSuggestions = this.feedbackSuggestions.filter((f) => f !== feedback);
        feedback.type = FeedbackType.MANUAL_UNREFERENCED;
        feedback.text = (feedback.text ?? FEEDBACK_SUGGESTION_IDENTIFIER).replace(FEEDBACK_SUGGESTION_IDENTIFIER, FEEDBACK_SUGGESTION_ACCEPTED_IDENTIFIER);
        this.updateFeedback(feedback);
        this.onAcceptSuggestion.emit(feedback);
      }
      discardSuggestion(feedback) {
        this.feedbackSuggestions = this.feedbackSuggestions.filter((f) => f !== feedback);
        this.onDiscardSuggestion.emit(feedback);
      }
      createAssessmentOnDrop(event) {
        this.addUnreferencedFeedback();
        const newFeedback = this.unreferencedFeedback.last();
        if (newFeedback) {
          this.structuredGradingCriterionService.updateFeedbackWithStructuredGradingInstructionEvent(newFeedback, event);
          this.updateFeedback(newFeedback);
        }
      }
      static \u0275fac = function UnreferencedFeedbackComponent_Factory(t) {
        return new (t || _UnreferencedFeedbackComponent)(i016.\u0275\u0275directiveInject(StructuredGradingCriterionService));
      };
      static \u0275cmp = i016.\u0275\u0275defineComponent({ type: _UnreferencedFeedbackComponent, selectors: [["jhi-unreferenced-feedback"]], inputs: { readOnly: "readOnly", highlightDifferences: "highlightDifferences", useDefaultFeedbackSuggestionBadgeText: "useDefaultFeedbackSuggestionBadgeText", addReferenceIdForExampleSubmission: "addReferenceIdForExampleSubmission", feedbacks: "feedbacks", feedbackSuggestions: "feedbackSuggestions" }, outputs: { feedbacksChange: "feedbacksChange", onAcceptSuggestion: "onAcceptSuggestion", onDiscardSuggestion: "onDiscardSuggestion" }, decls: 21, vars: 5, consts: [[3, "drop", "dragover"], [1, "col-md-6"], [1, "add-unreferenced-feedback", "btn", "btn-success", "mt-4", 3, "disabled", "click"], [1, "row", "mt-4"], ["jhiTranslate", "artemisApp.assessment.detail.feedback", 1, "col-12"], [1, "col-12", "col-lg-8", "col-xl-6"], ["role", "alert", 1, "alert", "alert-secondary", "text-center"], [1, "col-12", "col-lg-6", "col-xl-6"], [3, "feedback", "readOnly", "highlightDifferences", "useDefaultFeedbackSuggestionBadgeText", "onFeedbackChange", "onFeedbackDelete"], [3, "feedback", "isSuggestion", "readOnly", "useDefaultFeedbackSuggestionBadgeText", "onAcceptSuggestion", "onDiscardSuggestion"]], template: function UnreferencedFeedbackComponent_Template(rf, ctx) {
        if (rf & 1) {
          i016.\u0275\u0275elementStart(0, "div", 0);
          i016.\u0275\u0275listener("drop", function UnreferencedFeedbackComponent_Template_div_drop_0_listener($event) {
            return ctx.createAssessmentOnDrop($event);
          })("dragover", function UnreferencedFeedbackComponent_Template_div_dragover_0_listener($event) {
            return $event.preventDefault();
          });
          i016.\u0275\u0275text(1, "\n    ");
          i016.\u0275\u0275elementStart(2, "div", 1);
          i016.\u0275\u0275text(3, "\n        ");
          i016.\u0275\u0275elementStart(4, "button", 2);
          i016.\u0275\u0275listener("click", function UnreferencedFeedbackComponent_Template_button_click_4_listener() {
            return ctx.addUnreferencedFeedback();
          });
          i016.\u0275\u0275text(5);
          i016.\u0275\u0275pipe(6, "artemisTranslate");
          i016.\u0275\u0275elementEnd();
          i016.\u0275\u0275text(7, "\n        ");
          i016.\u0275\u0275elementStart(8, "div", 3);
          i016.\u0275\u0275text(9, "\n            ");
          i016.\u0275\u0275elementStart(10, "h4", 4);
          i016.\u0275\u0275text(11, "Feedback");
          i016.\u0275\u0275elementEnd();
          i016.\u0275\u0275text(12, "\n            ");
          i016.\u0275\u0275template(13, UnreferencedFeedbackComponent_Conditional_13_Template, 11, 3);
          i016.\u0275\u0275repeaterCreate(14, UnreferencedFeedbackComponent_For_15_Template, 6, 4, null, null, i016.\u0275\u0275repeaterTrackByIdentity);
          i016.\u0275\u0275repeaterCreate(16, UnreferencedFeedbackComponent_For_17_Template, 6, 4, null, null, i016.\u0275\u0275repeaterTrackByIdentity);
          i016.\u0275\u0275elementEnd();
          i016.\u0275\u0275text(18, "\n    ");
          i016.\u0275\u0275elementEnd();
          i016.\u0275\u0275text(19, "\n");
          i016.\u0275\u0275elementEnd();
          i016.\u0275\u0275text(20, "\n");
        }
        if (rf & 2) {
          i016.\u0275\u0275advance(4);
          i016.\u0275\u0275property("disabled", ctx.readOnly);
          i016.\u0275\u0275advance(1);
          i016.\u0275\u0275textInterpolate1("\n            ", i016.\u0275\u0275pipeBind1(6, 3, "artemisApp.fileUploadAssessment.addFeedback"), "\n        ");
          i016.\u0275\u0275advance(8);
          i016.\u0275\u0275conditional(13, ctx.unreferencedFeedback.length + ctx.feedbackSuggestions.length === 0 ? 13 : -1);
          i016.\u0275\u0275advance(1);
          i016.\u0275\u0275repeater(ctx.unreferencedFeedback);
          i016.\u0275\u0275advance(2);
          i016.\u0275\u0275repeater(ctx.feedbackSuggestions);
        }
      }, dependencies: [TranslateDirective, UnreferencedFeedbackDetailComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i016.\u0275setClassDebugInfo(UnreferencedFeedbackComponent, { className: "UnreferencedFeedbackComponent" });
    })();
  }
});

// src/main/webapp/app/assessment/assessment-shared.module.ts
import { NgModule as NgModule3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { RouterModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i017 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ENTITY_STATES, ArtemisAssessmentSharedModule;
var init_assessment_shared_module = __esm({
  "src/main/webapp/app/assessment/assessment-shared.module.ts"() {
    init_shared_module();
    init_assessment_header_component();
    init_assessment_layout_component();
    init_assessment_complaint_alert_component();
    init_score_display_component();
    init_unreferenced_feedback_detail_component();
    init_shared_component_module();
    init_complaints_for_tutor_module();
    init_assessment_locks_component();
    init_assessment_locks_route();
    init_unreferenced_feedback_component();
    init_markdown_module();
    init_assessment_correction_round_badge_component();
    init_grading_instruction_link_icon_module();
    init_feedback_module();
    ENTITY_STATES = [...assessmentLocksRoute];
    ArtemisAssessmentSharedModule = class _ArtemisAssessmentSharedModule {
      static \u0275fac = function ArtemisAssessmentSharedModule_Factory(t) {
        return new (t || _ArtemisAssessmentSharedModule)();
      };
      static \u0275mod = i017.\u0275\u0275defineNgModule({ type: _ArtemisAssessmentSharedModule });
      static \u0275inj = i017.\u0275\u0275defineInjector({ imports: [
        ArtemisSharedModule,
        ArtemisComplaintsForTutorModule,
        ArtemisSharedComponentModule,
        RouterModule.forChild(ENTITY_STATES),
        ArtemisMarkdownModule,
        ArtemisGradingInstructionLinkIconModule,
        ArtemisFeedbackModule
      ] });
    };
  }
});

export {
  TextAssessmentEventType,
  init_text_assesment_event_model,
  TextAssessmentAnalytics,
  init_text_assesment_analytics_service,
  assessmentNavigateBack,
  init_navigate_back_util,
  isAllowedToModifyFeedback,
  init_assessment_service,
  AssessmentLayoutComponent,
  init_assessment_layout_component,
  ScoreDisplayComponent,
  init_score_display_component,
  StructuredGradingCriterionService,
  init_structured_grading_criterion_service,
  GradingInstructionLinkIconComponent,
  init_grading_instruction_link_icon_component,
  AssessmentCorrectionRoundBadgeComponent,
  init_assessment_correction_round_badge_component,
  ArtemisComplaintsForTutorModule,
  init_complaints_for_tutor_module,
  ModelingAssessmentService,
  init_modeling_assessment_service,
  CourseManagementResolve,
  init_course_management_resolve_service,
  UnreferencedFeedbackComponent,
  init_unreferenced_feedback_component,
  ArtemisGradingInstructionLinkIconModule,
  init_grading_instruction_link_icon_module,
  ArtemisAssessmentSharedModule,
  init_assessment_shared_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvY29tcGxhaW50LXJlc3BvbnNlLm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL25hdmlnYXRlLWJhY2sudXRpbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXNzZXNzbWVudC9hc3Nlc3NtZW50LnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvbXBsYWludHMvY29tcGxhaW50cy1mb3ItdHV0b3IvY29tcGxhaW50cy1mb3ItdHV0b3IuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb21wbGFpbnRzL2NvbXBsYWludHMtZm9yLXR1dG9yL2NvbXBsYWludHMtZm9yLXR1dG9yLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb21wbGFpbnRzL2NvbXBsYWludHMtZm9yLXR1dG9yL2NvbXBsYWludHMtZm9yLXR1dG9yLm1vZHVsZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2dyYWRpbmctaW5zdHJ1Y3Rpb24tbGluay1pY29uL2dyYWRpbmctaW5zdHJ1Y3Rpb24tbGluay1pY29uLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2dyYWRpbmctaW5zdHJ1Y3Rpb24tbGluay1pY29uL2dyYWRpbmctaW5zdHJ1Y3Rpb24tbGluay1pY29uLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvZ3JhZGluZy1pbnN0cnVjdGlvbi1saW5rLWljb24vZ3JhZGluZy1pbnN0cnVjdGlvbi1saW5rLWljb24ubW9kdWxlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy90ZXh0LWFzc2VzbWVudC1ldmVudC5tb2RlbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3RleHQvYXNzZXNzL2FuYWx5dGljcy90ZXh0LWFzc2VzbWVudC1hbmFseXRpY3Muc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXNzZXNzbWVudC9hc3Nlc3NtZW50LWhlYWRlci9hc3Nlc3NtZW50LWhlYWRlci5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2Fzc2Vzc21lbnQvYXNzZXNzbWVudC1oZWFkZXIvYXNzZXNzbWVudC1oZWFkZXIuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2Fzc2Vzc21lbnQvYXNzZXNzbWVudC1jb21wbGFpbnQtYWxlcnQvYXNzZXNzbWVudC1jb21wbGFpbnQtYWxlcnQuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9hc3Nlc3NtZW50L2Fzc2Vzc21lbnQtY29tcGxhaW50LWFsZXJ0L2Fzc2Vzc21lbnQtY29tcGxhaW50LWFsZXJ0LmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9hc3Nlc3NtZW50L2Fzc2Vzc21lbnQtbGF5b3V0L2Fzc2Vzc21lbnQtbGF5b3V0LmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXNzZXNzbWVudC9hc3Nlc3NtZW50LWxheW91dC9hc3Nlc3NtZW50LWxheW91dC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3Njb3JlLWRpc3BsYXkvc2NvcmUtZGlzcGxheS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9zY29yZS1kaXNwbGF5L3Njb3JlLWRpc3BsYXkuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvc3RydWN0dXJlZC1ncmFkaW5nLWNyaXRlcmlvbi9zdHJ1Y3R1cmVkLWdyYWRpbmctY3JpdGVyaW9uLnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2Fzc2Vzc21lbnQvdW5yZWZlcmVuY2VkLWZlZWRiYWNrLWRldGFpbC9hc3Nlc3NtZW50LWNvcnJlY3Rpb24tcm91bmQtYmFkZ2UvYXNzZXNzbWVudC1jb3JyZWN0aW9uLXJvdW5kLWJhZGdlLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXNzZXNzbWVudC91bnJlZmVyZW5jZWQtZmVlZGJhY2stZGV0YWlsL2Fzc2Vzc21lbnQtY29ycmVjdGlvbi1yb3VuZC1iYWRnZS9hc3Nlc3NtZW50LWNvcnJlY3Rpb24tcm91bmQtYmFkZ2UuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2Fzc2Vzc21lbnQvdW5yZWZlcmVuY2VkLWZlZWRiYWNrLWRldGFpbC91bnJlZmVyZW5jZWQtZmVlZGJhY2stZGV0YWlsLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXNzZXNzbWVudC91bnJlZmVyZW5jZWQtZmVlZGJhY2stZGV0YWlsL3VucmVmZXJlbmNlZC1mZWVkYmFjay1kZXRhaWwuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9tb2RlbGluZy9hc3Nlc3MvbW9kZWxpbmctYXNzZXNzbWVudC5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9hc3Nlc3NtZW50L2Fzc2Vzc21lbnQtbG9ja3MvYXNzZXNzbWVudC1sb2Nrcy5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2Fzc2Vzc21lbnQvYXNzZXNzbWVudC1sb2Nrcy9hc3Nlc3NtZW50LWxvY2tzLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbWFuYWdlL2NvdXJzZS1tYW5hZ2VtZW50LXJlc29sdmUuc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXNzZXNzbWVudC9hc3Nlc3NtZW50LWxvY2tzL2Fzc2Vzc21lbnQtbG9ja3Mucm91dGUudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdW5yZWZlcmVuY2VkLWZlZWRiYWNrL3VucmVmZXJlbmNlZC1mZWVkYmFjay5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdW5yZWZlcmVuY2VkLWZlZWRiYWNrL3VucmVmZXJlbmNlZC1mZWVkYmFjay5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXNzZXNzbWVudC9hc3Nlc3NtZW50LXNoYXJlZC5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGRheWpzIGZyb20gJ2RheWpzL2VzbSc7XG5pbXBvcnQgeyBVc2VyIH0gZnJvbSAnYXBwL2NvcmUvdXNlci91c2VyLm1vZGVsJztcbmltcG9ydCB7IEJhc2VFbnRpdHkgfSBmcm9tICdhcHAvc2hhcmVkL21vZGVsL2Jhc2UtZW50aXR5JztcbmltcG9ydCB7IENvbXBsYWludCB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb21wbGFpbnQubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgQ29tcGxhaW50UmVzcG9uc2UgaW1wbGVtZW50cyBCYXNlRW50aXR5IHtcbiAgICBwdWJsaWMgaWQ/OiBudW1iZXI7XG5cbiAgICBwdWJsaWMgcmVzcG9uc2VUZXh0Pzogc3RyaW5nO1xuICAgIHB1YmxpYyBzdWJtaXR0ZWRUaW1lPzogZGF5anMuRGF5anM7XG4gICAgcHVibGljIGNvbXBsYWludD86IENvbXBsYWludDtcbiAgICBwdWJsaWMgcmV2aWV3ZXI/OiBVc2VyO1xuICAgIC8vIHRyYW5zaWVudCBwcm9wZXJ0eSB0aGF0IHdpbGwgYmUgY2FsY3VsYXRlZCBvbiB0aGUgc2VydmVyXG4gICAgcHVibGljIGlzQ3VycmVudGx5TG9ja2VkPzogYm9vbGVhbjtcbiAgICAvLyB0cmFuc2llbnQgcHJvcGVydHkgdGhhdCB3aWxsIGJlIGNhbGN1bGF0ZWQgb24gdGhlIHNlcnZlclxuICAgIHB1YmxpYyBsb2NrRW5kRGF0ZT86IGRheWpzLkRheWpzO1xuXG4gICAgY29uc3RydWN0b3IoKSB7fVxufVxuIiwiaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IFN0dWRlbnRQYXJ0aWNpcGF0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3BhcnRpY2lwYXRpb24vc3R1ZGVudC1wYXJ0aWNpcGF0aW9uLm1vZGVsJztcbmltcG9ydCB7IEV4ZXJjaXNlLCBnZXRDb3Vyc2VGcm9tRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgU3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9zdWJtaXNzaW9uLm1vZGVsJztcblxuLyoqXG4gKiBOYXZpZ2F0ZSBmcm9tIEFzc2Vzc21lbnQgRWRpdG9yIHRvIERhc2hib2FyZDpcbiAqICAgMS4gRm9yIFRlYW0gRXhlcmNpc2VzOiBOYXZpZ2F0ZSB0byBUZWFtIERhc2hib2FyZCB3aXRoIGFsbCBTdWJtaXNzaW9ucyBvZiB0aGUgVGVhbVxuICogICAyLiBGb3IgUmVndWxhciBFeGVyY2lzZXM6IE5hdmlnYXRlIHRvIHRoZSBFeGVyY2lzZSBBc3Nlc3NtZW50IERhc2hib2FyZFxuICogICBGYWxsYmFjazogSWYgd2UgZG8gbm90IGtub3cgdGhlIGV4ZXJjaXNlLCB3ZSBuYXZpZ2F0ZSBiYWNrIGluIHRoZSBicm93c2VyJ3MgaGlzdG9yeS5cbiAqXG4gKiBAcGFyYW0gbG9jYXRpb246IEFuZ3VsYXIgd3JhcHBlciBmb3IgaW50ZXJhY3Rpbmcgd2l0aCBCcm93c2VyIFVSTCBhbmQgSGlzdG9yeVxuICogQHBhcmFtIHJvdXRlcjogQW5ndWxhciByb3V0ZXIgdG8gbmF2aWdhdGUgdG8gVVJMXG4gKiBAcGFyYW0gZXhlcmNpc2U6IEV4ZXJjaXNlIGN1cnJlbnRseSBhc3Nlc3NlZFxuICogQHBhcmFtIHN1Ym1pc3Npb246IFN1Ym1pc3Npb24gY3VycmVudGx5IGFzc2Vzc2VkXG4gKiBAcGFyYW0gaXNUZXN0UnVuOiBmbGFnIHRvIGRldGVybWluZSBpZiBpdCBpcyBhbiBleGFtIHRlc3QgcnVuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhc3Nlc3NtZW50TmF2aWdhdGVCYWNrKGxvY2F0aW9uOiBMb2NhdGlvbiwgcm91dGVyOiBSb3V0ZXIsIGV4ZXJjaXNlPzogRXhlcmNpc2UsIHN1Ym1pc3Npb24/OiBTdWJtaXNzaW9uLCBpc1Rlc3RSdW4gPSBmYWxzZSkge1xuICAgIGlmIChleGVyY2lzZSkge1xuICAgICAgICBjb25zdCBjb3Vyc2UgPSBnZXRDb3Vyc2VGcm9tRXhlcmNpc2UoZXhlcmNpc2UpO1xuXG4gICAgICAgIGlmIChpc1Rlc3RSdW4pIHtcbiAgICAgICAgICAgIGNvbnN0IGV4YW0gPSBleGVyY2lzZS5leGVyY2lzZUdyb3VwIS5leGFtITtcbiAgICAgICAgICAgIHJvdXRlci5uYXZpZ2F0ZUJ5VXJsKGAvY291cnNlLW1hbmFnZW1lbnQvJHtjb3Vyc2U/LmlkfS9leGFtcy8ke2V4YW0uaWR9L3Rlc3QtYXNzZXNzbWVudC1kYXNoYm9hcmQvJHtleGVyY2lzZS5pZH1gKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmIChleGVyY2lzZS5leGVyY2lzZUdyb3VwKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZXhhbSA9IGV4ZXJjaXNlLmV4ZXJjaXNlR3JvdXAhLmV4YW0hO1xuICAgICAgICAgICAgICAgIHJvdXRlci5uYXZpZ2F0ZUJ5VXJsKGAvY291cnNlLW1hbmFnZW1lbnQvJHtjb3Vyc2U/LmlkfS9leGFtcy8ke2V4YW0uaWR9L2Fzc2Vzc21lbnQtZGFzaGJvYXJkLyR7ZXhlcmNpc2UuaWR9YCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGV4ZXJjaXNlLnRlYW1Nb2RlICYmIHN1Ym1pc3Npb24pIHtcbiAgICAgICAgICAgICAgICBjb25zdCB0ZWFtSWQgPSAoc3VibWlzc2lvbi5wYXJ0aWNpcGF0aW9uIGFzIFN0dWRlbnRQYXJ0aWNpcGF0aW9uKS50ZWFtPy5pZDtcbiAgICAgICAgICAgICAgICByb3V0ZXIubmF2aWdhdGVCeVVybChgL2NvdXJzZXMvJHtjb3Vyc2U/LmlkfS9leGVyY2lzZXMvJHtleGVyY2lzZS5pZH0vdGVhbXMvJHt0ZWFtSWR9YCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJvdXRlci5uYXZpZ2F0ZUJ5VXJsKGAvY291cnNlLW1hbmFnZW1lbnQvJHtjb3Vyc2U/LmlkfS9hc3Nlc3NtZW50LWRhc2hib2FyZC8ke2V4ZXJjaXNlLmlkfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgICAgbG9jYXRpb24uYmFjaygpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEV4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IENvbXBsYWludCwgQ29tcGxhaW50VHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb21wbGFpbnQubW9kZWwnO1xuaW1wb3J0IHsgQXNzZXNzbWVudFR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvYXNzZXNzbWVudC10eXBlLm1vZGVsJztcbmltcG9ydCB7IFJlc3VsdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9yZXN1bHQubW9kZWwnO1xuXG4vKipcbiAqIEZvciB0ZWFtIGV4ZXJjaXNlcywgdGhlIHRlYW0gdHV0b3IgaXMgdGhlIGFzc2Vzc29yIGFuZCBoYW5kbGVzIGJvdGggY29tcGxhaW50cyBhbmQgZmVlZGJhY2sgcmVxdWVzdHMgaGltc2VsZlxuICogRm9yIGluZGl2aWR1YWwgZXhlcmNpc2VzLCBjb21wbGFpbnRzIGFyZSBoYW5kbGVkIGJ5IGEgc2Vjb25kYXJ5IHJldmlld2VyIGFuZCBmZWVkYmFjayByZXF1ZXN0cyBieSB0aGUgYXNzZXNzb3IgaGltc2VsZlxuICogRm9yIGV4YW0gdGVzdCBydW5zLCB0aGUgb3JpZ2luYWwgYXNzZXNzb3IgaXMgYWxsb3dlZCB0byByZXNwb25kIHRvIGNvbXBsYWludHMuXG4gKi9cbmV4cG9ydCBjb25zdCBpc0FsbG93ZWRUb1Jlc3BvbmRUb0NvbXBsYWludEFjdGlvbiA9IChpc1Rlc3RSdW46IGJvb2xlYW4sIGlzQXNzZXNzb3I6IGJvb2xlYW4sIGNvbXBsYWludDogQ29tcGxhaW50LCBleGVyY2lzZT86IEV4ZXJjaXNlKTogYm9vbGVhbiA9PiB7XG4gICAgaWYgKGV4ZXJjaXNlPy5pc0F0TGVhc3RJbnN0cnVjdG9yKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoZXhlcmNpc2U/LnRlYW1Nb2RlIHx8IGlzVGVzdFJ1bikge1xuICAgICAgICByZXR1cm4gaXNBc3Nlc3NvcjtcbiAgICB9XG4gICAgaWYgKGV4ZXJjaXNlPy5hc3Nlc3NtZW50VHlwZSA9PT0gQXNzZXNzbWVudFR5cGUuQVVUT01BVElDICYmIGNvbXBsYWludC5yZXN1bHQgJiYgY29tcGxhaW50LnJlc3VsdC5hc3Nlc3NvciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gY29tcGxhaW50IS5jb21wbGFpbnRUeXBlID09PSBDb21wbGFpbnRUeXBlLkNPTVBMQUlOVCA/ICFpc0Fzc2Vzc29yIDogaXNBc3Nlc3Nvcjtcbn07XG5cbi8qKlxuICogRHVyaW5nIGFzc2Vzc21lbnQsIG1vZGlmeWluZyB0aGUgZmVlZGJhY2sgc2hvdWxkIGJlIGFsbG93ZWQuXG4gKiBBZnRlciB0aGUgYXNzZXNzbWVudCwgbW9kaWZpY2F0aW9uIHNob3VsZCBiZSBhbGxvd2VkIGlmIHRoZSBhc3Nlc3NtZW50IGR1ZSBkYXRlIGhhc24ndCBwYXNzZWQgeWV0LiBBZnRlciB0aGF0LCBpdCBzaG91bGQgYmUgcHJldmVudGVkLlxuICogSWYgYSBmZWVkYmFjayByZXF1ZXN0IHdhcyBmaWxlZCwgdGhlIGZlZWRiYWNrIHNob3VsZCBub3QgYmUgbW9kaWZpYWJsZS5cbiAqIElmIGEgY29tcGxhaW50IHdhcyBmaWxlZCwgdGhlIGZlZWRiYWNrIHNob3VsZCBiZSBvbmx5IG1vZGlmaWFibGUgaWYgdGhlIHVzZXIgaXMgYWxsb3dlZCB0byBoYW5kbGUgdGhlIGNvbXBsYWludC5cbiAqL1xuZXhwb3J0IGNvbnN0IGlzQWxsb3dlZFRvTW9kaWZ5RmVlZGJhY2sgPSAoXG4gICAgaXNUZXN0UnVuOiBib29sZWFuLFxuICAgIGlzQXNzZXNzb3I6IGJvb2xlYW4sXG4gICAgaGFzQXNzZXNzbWVudER1ZURhdGVQYXNzZWQ6IGJvb2xlYW4sXG4gICAgcmVzdWx0PzogUmVzdWx0LFxuICAgIGNvbXBsYWludD86IENvbXBsYWludCxcbiAgICBleGVyY2lzZT86IEV4ZXJjaXNlLFxuKTogYm9vbGVhbiA9PiB7XG4gICAgaWYgKGV4ZXJjaXNlPy5pc0F0TGVhc3RJbnN0cnVjdG9yKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoIXJlc3VsdCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmICghcmVzdWx0LmNvbXBsZXRpb25EYXRlKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoY29tcGxhaW50KSB7XG4gICAgICAgIHJldHVybiBjb21wbGFpbnQuY29tcGxhaW50VHlwZSA9PT0gQ29tcGxhaW50VHlwZS5DT01QTEFJTlQgJiYgaXNBbGxvd2VkVG9SZXNwb25kVG9Db21wbGFpbnRBY3Rpb24oaXNUZXN0UnVuLCBpc0Fzc2Vzc29yLCBjb21wbGFpbnQsIGV4ZXJjaXNlKTtcbiAgICB9XG4gICAgcmV0dXJuICFoYXNBc3Nlc3NtZW50RHVlRGF0ZVBhc3NlZDtcbn07XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBbGVydFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBDb21wbGFpbnRSZXNwb25zZVNlcnZpY2UgfSBmcm9tICdhcHAvY29tcGxhaW50cy9jb21wbGFpbnQtcmVzcG9uc2Uuc2VydmljZSc7XG5pbXBvcnQgeyBDb21wbGFpbnRSZXNwb25zZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb21wbGFpbnQtcmVzcG9uc2UubW9kZWwnO1xuaW1wb3J0IHsgQ29tcGxhaW50LCBDb21wbGFpbnRUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvbXBsYWludC5tb2RlbCc7XG5pbXBvcnQgeyBmaW5hbGl6ZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IEV4ZXJjaXNlLCBnZXRDb3Vyc2VGcm9tRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUsIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBhc3Nlc3NtZW50TmF2aWdhdGVCYWNrIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvbmF2aWdhdGUtYmFjay51dGlsJztcbmltcG9ydCB7IExvY2F0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IFN1Ym1pc3Npb24gfSBmcm9tICdhcHAvZW50aXRpZXMvc3VibWlzc2lvbi5tb2RlbCc7XG5pbXBvcnQgeyBpc0FsbG93ZWRUb1Jlc3BvbmRUb0NvbXBsYWludEFjdGlvbiB9IGZyb20gJ2FwcC9hc3Nlc3NtZW50L2Fzc2Vzc21lbnQuc2VydmljZSc7XG5pbXBvcnQgeyBDb3Vyc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvY291cnNlLm1vZGVsJztcblxuZXhwb3J0IHR5cGUgQXNzZXNzbWVudEFmdGVyQ29tcGxhaW50ID0geyBjb21wbGFpbnRSZXNwb25zZTogQ29tcGxhaW50UmVzcG9uc2U7IG9uU3VjY2VzczogKCkgPT4gdm9pZDsgb25FcnJvcjogKCkgPT4gdm9pZCB9O1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1jb21wbGFpbnRzLWZvci10dXRvci1mb3JtJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vY29tcGxhaW50cy1mb3ItdHV0b3IuY29tcG9uZW50Lmh0bWwnLFxuICAgIHByb3ZpZGVyczogW10sXG59KVxuZXhwb3J0IGNsYXNzIENvbXBsYWludHNGb3JUdXRvckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgQElucHV0KCkgY29tcGxhaW50OiBDb21wbGFpbnQ7XG4gICAgQElucHV0KCkgaXNUZXN0UnVuID0gZmFsc2U7XG4gICAgQElucHV0KCkgaXNBc3Nlc3NvciA9IGZhbHNlO1xuICAgIEBJbnB1dCgpIHplcm9JbmRlbnQgPSB0cnVlO1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlOiBFeGVyY2lzZSB8IHVuZGVmaW5lZDtcbiAgICBASW5wdXQoKSBzdWJtaXNzaW9uOiBTdWJtaXNzaW9uIHwgdW5kZWZpbmVkO1xuICAgIC8vIEluZGljYXRlcyB0aGF0IHRoZSBhc3Nlc3NtZW50IHNob3VsZCBiZSB1cGRhdGVkIGFmdGVyIGEgY29tcGxhaW50LiBJbmNsdWRlcyB0aGUgY29ycmVzcG9uZGluZyBjb21wbGFpbnRcbiAgICAvLyB0aGF0IHNob3VsZCBiZSBzZW50IHRvIHRoZSBzZXJ2ZXIgYWxvbmcgd2l0aCB0aGUgYXNzZXNzbWVudCB1cGRhdGUuXG4gICAgQE91dHB1dCgpIHVwZGF0ZUFzc2Vzc21lbnRBZnRlckNvbXBsYWludCA9IG5ldyBFdmVudEVtaXR0ZXI8QXNzZXNzbWVudEFmdGVyQ29tcGxhaW50PigpO1xuICAgIGNvbXBsYWludFRleHQ/OiBzdHJpbmc7XG4gICAgaGFuZGxlZDogYm9vbGVhbjtcbiAgICBjb21wbGFpbnRSZXNwb25zZTogQ29tcGxhaW50UmVzcG9uc2UgPSBuZXcgQ29tcGxhaW50UmVzcG9uc2UoKTtcbiAgICBDb21wbGFpbnRUeXBlID0gQ29tcGxhaW50VHlwZTtcbiAgICBpc0xvYWRpbmcgPSBmYWxzZTtcbiAgICBzaG93TG9ja0R1cmF0aW9uID0gZmFsc2U7XG4gICAgbG9ja2VkQnlDdXJyZW50VXNlciA9IGZhbHNlO1xuICAgIGlzTG9ja2VkRm9yTG9nZ2VkSW5Vc2VyID0gZmFsc2U7XG4gICAgY291cnNlPzogQ291cnNlO1xuICAgIG1heENvbXBsYWludFJlc3BvbnNlVGV4dExpbWl0OiBudW1iZXI7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBhbGVydFNlcnZpY2U6IEFsZXJ0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBjb21wbGFpbnRSZXNwb25zZVNlcnZpY2U6IENvbXBsYWludFJlc3BvbnNlU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBhY3RpdmF0ZWRSb3V0ZTogQWN0aXZhdGVkUm91dGUsXG4gICAgICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgICAgIHByaXZhdGUgbG9jYXRpb246IExvY2F0aW9uLFxuICAgICkge31cblxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICB0aGlzLmNvdXJzZSA9IGdldENvdXJzZUZyb21FeGVyY2lzZSh0aGlzLmV4ZXJjaXNlISk7XG5cbiAgICAgICAgdGhpcy5tYXhDb21wbGFpbnRSZXNwb25zZVRleHRMaW1pdCA9IHRoaXMuY291cnNlPy5tYXhDb21wbGFpbnRSZXNwb25zZVRleHRMaW1pdCA/PyAwO1xuICAgICAgICBpZiAodGhpcy5leGVyY2lzZT8uZXhlcmNpc2VHcm91cCkge1xuICAgICAgICAgICAgLy8gRXhhbXMgc2hvdWxkIGFsd2F5cyBhbGxvdyBhdCBsZWFzdCAyMDAwIGNoYXJhY3RlcnNcbiAgICAgICAgICAgIHRoaXMubWF4Q29tcGxhaW50UmVzcG9uc2VUZXh0TGltaXQgPSBNYXRoLm1heCgyMDAwLCB0aGlzLm1heENvbXBsYWludFJlc3BvbnNlVGV4dExpbWl0KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLmNvbXBsYWludCkge1xuICAgICAgICAgICAgdGhpcy5jb21wbGFpbnRUZXh0ID0gdGhpcy5jb21wbGFpbnQuY29tcGxhaW50VGV4dDtcbiAgICAgICAgICAgIHRoaXMuaGFuZGxlZCA9IHRoaXMuY29tcGxhaW50LmFjY2VwdGVkICE9PSB1bmRlZmluZWQ7XG4gICAgICAgICAgICBpZiAodGhpcy5oYW5kbGVkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jb21wbGFpbnRSZXNwb25zZSA9IHRoaXMuY29tcGxhaW50LmNvbXBsYWludFJlc3BvbnNlITtcbiAgICAgICAgICAgICAgICB0aGlzLmxvY2tlZEJ5Q3VycmVudFVzZXIgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dMb2NrRHVyYXRpb24gPSBmYWxzZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuaXNBbGxvd2VkVG9SZXNwb25kKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbXBsYWludC5jb21wbGFpbnRSZXNwb25zZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZWZyZXNoTG9jaygpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jcmVhdGVMb2NrKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5lcnJvcignYXJ0ZW1pc0FwcC5sb2Nrcy5ub3RBbGxvd2VkVG9SZXNwb25kJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBjcmVhdGVMb2NrKCkge1xuICAgICAgICB0aGlzLmlzTG9hZGluZyA9IHRydWU7XG4gICAgICAgIHRoaXMuY29tcGxhaW50UmVzcG9uc2VTZXJ2aWNlXG4gICAgICAgICAgICAuY3JlYXRlTG9jayh0aGlzLmNvbXBsYWludC5pZCEpXG4gICAgICAgICAgICAucGlwZShcbiAgICAgICAgICAgICAgICBmaW5hbGl6ZSgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXNMb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb21wbGFpbnRSZXNwb25zZSA9IHJlc3BvbnNlLmJvZHkhO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbXBsYWludCA9IHRoaXMuY29tcGxhaW50UmVzcG9uc2UuY29tcGxhaW50ITtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2NrZWRCeUN1cnJlbnRVc2VyID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zaG93TG9ja0R1cmF0aW9uID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGVydFNlcnZpY2Uuc3VjY2VzcygnYXJ0ZW1pc0FwcC5sb2Nrcy5hY3F1aXJlZCcpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgZXJyb3I6IChlcnI6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub25FcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHJlZnJlc2hMb2NrKCkge1xuICAgICAgICB0aGlzLmNvbXBsYWludFJlc3BvbnNlID0gdGhpcy5jb21wbGFpbnQuY29tcGxhaW50UmVzcG9uc2UhO1xuICAgICAgICB0aGlzLnNob3dMb2NrRHVyYXRpb24gPSB0cnVlO1xuICAgICAgICAvLyBpZiBhIGxvY2sgZXhpc3RzIHdlIGhhdmUgdG8gY2hlY2sgaWYgaXQgYWZmZWN0cyB0aGUgY3VycmVudGx5IGxvZ2dlZC1pbiB1c2VyXG4gICAgICAgIHRoaXMuaXNMb2NrZWRGb3JMb2dnZWRJblVzZXIgPSB0aGlzLmNvbXBsYWludFJlc3BvbnNlU2VydmljZS5pc0NvbXBsYWludFJlc3BvbnNlTG9ja2VkRm9yTG9nZ2VkSW5Vc2VyKHRoaXMuY29tcGxhaW50UmVzcG9uc2UsIHRoaXMuZXhlcmNpc2UhKTtcbiAgICAgICAgaWYgKCF0aGlzLmlzTG9ja2VkRm9yTG9nZ2VkSW5Vc2VyKSB7XG4gICAgICAgICAgICAvLyB1cGRhdGUgdGhlIGxvY2tcbiAgICAgICAgICAgIHRoaXMuaXNMb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMuY29tcGxhaW50UmVzcG9uc2VTZXJ2aWNlXG4gICAgICAgICAgICAgICAgLnJlZnJlc2hMb2NrKHRoaXMuY29tcGxhaW50LmlkISlcbiAgICAgICAgICAgICAgICAucGlwZShcbiAgICAgICAgICAgICAgICAgICAgZmluYWxpemUoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5pc0xvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIC5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgICAgICAgICBuZXh0OiAocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcGxhaW50UmVzcG9uc2UgPSByZXNwb25zZS5ib2R5ITtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcGxhaW50ID0gdGhpcy5jb21wbGFpbnRSZXNwb25zZS5jb21wbGFpbnQhO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2NrZWRCeUN1cnJlbnRVc2VyID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLnN1Y2Nlc3MoJ2FydGVtaXNBcHAubG9ja3MuYWNxdWlyZWQnKTtcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I6IChlcnI6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9uRXJyb3IoZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubG9ja2VkQnlDdXJyZW50VXNlciA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbmF2aWdhdGVCYWNrKCkge1xuICAgICAgICBhc3Nlc3NtZW50TmF2aWdhdGVCYWNrKHRoaXMubG9jYXRpb24sIHRoaXMucm91dGVyLCB0aGlzLmV4ZXJjaXNlLCB0aGlzLnN1Ym1pc3Npb24sIHRoaXMuaXNUZXN0UnVuKTtcbiAgICB9XG5cbiAgICByZW1vdmVMb2NrKCkge1xuICAgICAgICB0aGlzLmNvbXBsYWludFJlc3BvbnNlU2VydmljZS5yZW1vdmVMb2NrKHRoaXMuY29tcGxhaW50LmlkISkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5leHQ6ICgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5zdWNjZXNzKCdhcnRlbWlzQXBwLmxvY2tzLmxvY2tSZW1vdmVkJyk7XG4gICAgICAgICAgICAgICAgdGhpcy5uYXZpZ2F0ZUJhY2soKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogKGVycjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLm9uRXJyb3IoZXJyKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHJlc3BvbmRUb0NvbXBsYWludChhY2NlcHRDb21wbGFpbnQ6IGJvb2xlYW4pOiB2b2lkIHtcbiAgICAgICAgaWYgKCF0aGlzLmNvbXBsYWludFJlc3BvbnNlLnJlc3BvbnNlVGV4dCB8fCB0aGlzLmNvbXBsYWludFJlc3BvbnNlLnJlc3BvbnNlVGV4dC5sZW5ndGggPD0gMCkge1xuICAgICAgICAgICAgdGhpcy5hbGVydFNlcnZpY2UuZXJyb3IoJ2FydGVtaXNBcHAuY29tcGxhaW50UmVzcG9uc2Uubm9UZXh0Jyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuY29tcGxhaW50UmVzcG9uc2UucmVzcG9uc2VUZXh0Lmxlbmd0aCA+IHRoaXMubWF4Q29tcGxhaW50UmVzcG9uc2VUZXh0TGltaXQpIHtcbiAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLmVycm9yKCdhcnRlbWlzQXBwLmNvbXBsYWludC5leGNlZWRlZENvbXBsYWludFJlc3BvbnNlVGV4dExpbWl0Jywge1xuICAgICAgICAgICAgICAgIG1heENvbXBsYWludFJlc3BvbmRUZXh0TGltaXQ6IHRoaXMubWF4Q29tcGxhaW50UmVzcG9uc2VUZXh0TGltaXQsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuaXNBbGxvd2VkVG9SZXNwb25kKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmNvbXBsYWludFJlc3BvbnNlLmNvbXBsYWludCA9IHRoaXMuY29tcGxhaW50O1xuICAgICAgICB0aGlzLmNvbXBsYWludFJlc3BvbnNlLmNvbXBsYWludC5jb21wbGFpbnRSZXNwb25zZSA9IHVuZGVmaW5lZDsgLy8gYnJlYWtpbmcgY2lyY3VsYXIgc3RydWN0dXJlXG4gICAgICAgIHRoaXMuY29tcGxhaW50UmVzcG9uc2UuY29tcGxhaW50IS5hY2NlcHRlZCA9IGFjY2VwdENvbXBsYWludDtcblxuICAgICAgICBpZiAoYWNjZXB0Q29tcGxhaW50ICYmIHRoaXMuY29tcGxhaW50LmNvbXBsYWludFR5cGUgPT09IENvbXBsYWludFR5cGUuQ09NUExBSU5UKSB7XG4gICAgICAgICAgICAvLyBUZWxsIHRoZSBwYXJlbnQgKGFzc2Vzc21lbnQpIGNvbXBvbmVudCB0byB1cGRhdGUgdGhlIGNvcnJlc3BvbmRpbmcgcmVzdWx0IGlmIHRoZSBjb21wbGFpbnQgd2FzIGFjY2VwdGVkLlxuICAgICAgICAgICAgLy8gVGhlIGNvbXBsYWludCBpcyBzZW50IGFsb25nIHdpdGggdGhlIGFzc2Vzc21lbnQgdXBkYXRlIGJ5IHRoZSBwYXJlbnQgdG8gYXZvaWQgYWRkaXRpb25hbCByZXF1ZXN0cy5cbiAgICAgICAgICAgIHRoaXMuaXNMb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlQXNzZXNzbWVudEFmdGVyQ29tcGxhaW50LmVtaXQoe1xuICAgICAgICAgICAgICAgIGNvbXBsYWludFJlc3BvbnNlOiB0aGlzLmNvbXBsYWludFJlc3BvbnNlLFxuICAgICAgICAgICAgICAgIG9uU3VjY2VzczogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmhhbmRsZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNob3dMb2NrRHVyYXRpb24gPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2NrZWRCeUN1cnJlbnRVc2VyID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBvbkVycm9yOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXNMb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gSWYgdGhlIGNvbXBsYWludCB3YXMgcmVqZWN0ZWQgb3IgaXQgd2FzIGEgbW9yZSBmZWVkYmFjayByZXF1ZXN0LCBqdXN0IHRoZSBjb21wbGFpbnQgcmVzcG9uc2UgaXMgdXBkYXRlZC5cbiAgICAgICAgICAgIHRoaXMucmVzb2x2ZUNvbXBsYWludCgpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSByZXNvbHZlQ29tcGxhaW50KCkge1xuICAgICAgICB0aGlzLmlzTG9hZGluZyA9IHRydWU7XG4gICAgICAgIHRoaXMuY29tcGxhaW50UmVzcG9uc2VTZXJ2aWNlXG4gICAgICAgICAgICAucmVzb2x2ZUNvbXBsYWludCh0aGlzLmNvbXBsYWludFJlc3BvbnNlKVxuICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgZmluYWxpemUoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaGFuZGxlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbXBsYWludC5jb21wbGFpbnRUeXBlID09PSBDb21wbGFpbnRUeXBlLk1PUkVfRkVFREJBQ0spIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLnN1Y2Nlc3MoJ2FydGVtaXNBcHAubW9yZUZlZWRiYWNrUmVzcG9uc2UuY3JlYXRlZCcpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGVydFNlcnZpY2Uuc3VjY2VzcygnYXJ0ZW1pc0FwcC5jb21wbGFpbnRSZXNwb25zZS5jcmVhdGVkJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb21wbGFpbnRSZXNwb25zZSA9IHJlc3BvbnNlLmJvZHkhO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbXBsYWludCA9IHRoaXMuY29tcGxhaW50UmVzcG9uc2UuY29tcGxhaW50ITtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pc0xvY2tlZEZvckxvZ2dlZEluVXNlciA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNob3dMb2NrRHVyYXRpb24gPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2NrZWRCeUN1cnJlbnRVc2VyID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKGVycjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vbkVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgIH1cblxuICAgIG9uRXJyb3IoaHR0cEVycm9yUmVzcG9uc2U6IEh0dHBFcnJvclJlc3BvbnNlKSB7XG4gICAgICAgIGNvbnN0IGVycm9yID0gaHR0cEVycm9yUmVzcG9uc2UuZXJyb3I7XG4gICAgICAgIGlmIChlcnJvciAmJiBlcnJvci5lcnJvcktleSAmJiBlcnJvci5lcnJvcktleSA9PT0gJ2NvbXBsYWludExvY2snKSB7XG4gICAgICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5lcnJvcihlcnJvci5tZXNzYWdlLCBlcnJvci5wYXJhbXMpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5hbGVydFNlcnZpY2UuZXJyb3IoJ2Vycm9yLnVuZXhwZWN0ZWRFcnJvcicsIHtcbiAgICAgICAgICAgICAgICBlcnJvcjogaHR0cEVycm9yUmVzcG9uc2UubWVzc2FnZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRm9yIHRlYW0gZXhlcmNpc2VzLCB0aGUgdGVhbSB0dXRvciBpcyB0aGUgYXNzZXNzb3IgYW5kIGhhbmRsZXMgYm90aCBjb21wbGFpbnRzIGFuZCBmZWVkYmFjayByZXF1ZXN0cyBoaW1zZWxmXG4gICAgICogRm9yIGluZGl2aWR1YWwgZXhlcmNpc2VzLCBjb21wbGFpbnRzIGFyZSBoYW5kbGVkIGJ5IGEgc2Vjb25kYXJ5IHJldmlld2VyIGFuZCBmZWVkYmFjayByZXF1ZXN0cyBieSB0aGUgYXNzZXNzb3IgaGltc2VsZlxuICAgICAqIEZvciBleGFtIHRlc3QgcnVucywgdGhlIG9yaWdpbmFsIGFzc2Vzc29yIGlzIGFsbG93ZWQgdG8gcmVzcG9uZCB0byBjb21wbGFpbnRzLlxuICAgICAqL1xuICAgIGdldCBpc0FsbG93ZWRUb1Jlc3BvbmQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiBpc0FsbG93ZWRUb1Jlc3BvbmRUb0NvbXBsYWludEFjdGlvbih0aGlzLmlzVGVzdFJ1biwgdGhpcy5pc0Fzc2Vzc29yLCB0aGlzLmNvbXBsYWludCwgdGhpcy5leGVyY2lzZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2FsY3VsYXRlcyBhbmQgcmV0dXJucyB0aGUgbGVuZ3RoIG9mIHRoZSBlbnRlcmVkIHRleHQuXG4gICAgICovXG4gICAgY29tcGxhaW50UmVzcG9uc2VUZXh0TGVuZ3RoKCk6IG51bWJlciB7XG4gICAgICAgIGNvbnN0IHRleHRBcmVhOiBIVE1MVGV4dEFyZWFFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI3Jlc3BvbnNlVGV4dEFyZWEnKSBhcyBIVE1MVGV4dEFyZWFFbGVtZW50O1xuICAgICAgICByZXR1cm4gdGV4dEFyZWEudmFsdWUubGVuZ3RoO1xuICAgIH1cbn1cbiIsIkBpZiAoaXNMb2FkaW5nKSB7XG4gICAgPGRpdiBjbGFzcz1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyLWJvcmRlclwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwic3Itb25seVwiPnt7ICdsb2FkaW5nJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxufVxuQGlmICghaXNMb2FkaW5nICYmIGNvbXBsYWludCkge1xuICAgIDxoMz5cbiAgICAgICAge3sgY29tcGxhaW50LmNvbXBsYWludFR5cGUgPT09IENvbXBsYWludFR5cGUuTU9SRV9GRUVEQkFDSyA/ICgnYXJ0ZW1pc0FwcC5tb3JlRmVlZGJhY2sucmV2aWV3JyB8IGFydGVtaXNUcmFuc2xhdGUpIDogKCdhcnRlbWlzQXBwLmNvbXBsYWludC5yZXZpZXcnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSkgfX1cbiAgICA8L2gzPlxufVxuQGlmICghaXNMb2FkaW5nICYmIGNvbXBsYWludCkge1xuICAgIDxkaXYgY2xhc3M9XCJjb2wtMTIgbXQtMlwiIFtjbGFzcy5weC0wXT1cInplcm9JbmRlbnRcIj5cbiAgICAgICAgQGlmIChoYW5kbGVkKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWxlcnQgYWxlcnQtaW5mb1wiPlxuICAgICAgICAgICAgICAgIHt7XG4gICAgICAgICAgICAgICAgICAgIGNvbXBsYWludC5jb21wbGFpbnRUeXBlID09PSBDb21wbGFpbnRUeXBlLk1PUkVfRkVFREJBQ0tcbiAgICAgICAgICAgICAgICAgICAgICAgID8gKCdhcnRlbWlzQXBwLm1vcmVGZWVkYmFjay5hbHJlYWR5SGFuZGxlZCcgfCBhcnRlbWlzVHJhbnNsYXRlKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiAoJ2FydGVtaXNBcHAuY29tcGxhaW50LmNvbXBsYWludEFscmVhZHlIYW5kbGVkJyB8IGFydGVtaXNUcmFuc2xhdGUpXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICAgIDxkaXYgY2xhc3M9XCJtdC0zIG1iLTNcIj5cbiAgICAgICAgICAgIEBpZiAoc2hvd0xvY2tEdXJhdGlvbikge1xuICAgICAgICAgICAgICAgIDxkaXYgaWQ9XCJsb2NrRHVyYXRpb25cIiBjbGFzcz1cImFsZXJ0IGFsZXJ0LWluZm9cIj5cbiAgICAgICAgICAgICAgICAgICAgQGlmIChsb2NrZWRCeUN1cnJlbnRVc2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5sb2Nrcy5sb2NrSW5mb3JtYXRpb25Zb3UnIHwgYXJ0ZW1pc1RyYW5zbGF0ZTogeyBlbmREYXRlOiB0aGlzLmNvbXBsYWludFJlc3BvbnNlLmxvY2tFbmREYXRlIHwgYXJ0ZW1pc0RhdGUgfSB9fVxuICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2FydGVtaXNBcHAubG9ja3MubG9ja0luZm9ybWF0aW9uJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8IGFydGVtaXNUcmFuc2xhdGU6IHsgdXNlcjogdGhpcy5jb21wbGFpbnRSZXNwb25zZT8ucmV2aWV3ZXI/LmxvZ2luLCBlbmREYXRlOiB0aGlzLmNvbXBsYWludFJlc3BvbnNlLmxvY2tFbmREYXRlIHwgYXJ0ZW1pc0RhdGUgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmIChsb2NrZWRCeUN1cnJlbnRVc2VyKSB7XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImxvY2tCdXR0b25cIiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5XCIgKGNsaWNrKT1cInJlbW92ZUxvY2soKVwiPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5sb2Nrcy5yZW1vdmVCdXR0b24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC0xMiBjb2wtbWQtNlwiPlxuICAgICAgICAgICAgICAgIDxoND5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgID57e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBsYWludC5jb21wbGFpbnRUeXBlID09PSBDb21wbGFpbnRUeXBlLk1PUkVfRkVFREJBQ0tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAoJ2FydGVtaXNBcHAubW9yZUZlZWRiYWNrLnRpdGxlJyB8IGFydGVtaXNUcmFuc2xhdGUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogKCdhcnRlbWlzQXBwLmNvbXBsYWludC50aXRsZScgfCBhcnRlbWlzVHJhbnNsYXRlKVxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKGhhbmRsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzbWFsbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGNvbXBsYWludD8uYWNjZXB0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSBiZy1zdWNjZXNzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAmbmJzcDt7e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBsYWludC5jb21wbGFpbnRUeXBlID09PSBDb21wbGFpbnRUeXBlLk1PUkVfRkVFREJBQ0tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAoJ2FydGVtaXNBcHAubW9yZUZlZWRiYWNrLmFjY2VwdGVkJyB8IGFydGVtaXNUcmFuc2xhdGUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogKCdhcnRlbWlzQXBwLmNvbXBsYWludC5hY2NlcHRlZCcgfCBhcnRlbWlzVHJhbnNsYXRlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX0mbmJzcDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKCFjb21wbGFpbnQ/LmFjY2VwdGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctZGFuZ2VyXCI+ICZuYnNwO3t7ICdhcnRlbWlzQXBwLmNvbXBsYWludC5yZWplY3RlZCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19Jm5ic3A7IDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NtYWxsPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICA8dGV4dGFyZWEgaWQ9XCJjb21wbGFpbnRUZXh0QXJlYVwiIGNsYXNzPVwiY29sLTEyIHB4LTFcIiByb3dzPVwiNFwiIFsobmdNb2RlbCldPVwiY29tcGxhaW50VGV4dFwiIFtyZWFkb25seV09XCJ0cnVlXCIgW2Rpc2FibGVkXT1cInRydWVcIj48L3RleHRhcmVhPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICBAaWYgKGhhbmRsZWQgfHwgaXNBbGxvd2VkVG9SZXNwb25kKSB7XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC0xMiBjb2wtbWQtNlwiPlxuICAgICAgICAgICAgICAgICAgICA8aDM+XG4gICAgICAgICAgICAgICAgICAgICAgICB7e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBsYWludC5jb21wbGFpbnRUeXBlID09PSBDb21wbGFpbnRUeXBlLk1PUkVfRkVFREJBQ0tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAoJ2FydGVtaXNBcHAubW9yZUZlZWRiYWNrUmVzcG9uc2UudGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAoJ2FydGVtaXNBcHAuY29tcGxhaW50UmVzcG9uc2UudGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXggZmxleC1jb2x1bW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwicmVzcG9uc2VUZXh0QXJlYVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJjb2wtMTIgcHgtMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cz1cIjRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFttYXhsZW5ndGhdPVwibWF4Q29tcGxhaW50UmVzcG9uc2VUZXh0TGltaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFsobmdNb2RlbCldPVwiY29tcGxhaW50UmVzcG9uc2UucmVzcG9uc2VUZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbcmVhZG9ubHldPVwiaGFuZGxlZCB8fCBpc0xvY2tlZEZvckxvZ2dlZEluVXNlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2Rpc2FibGVkXT1cImhhbmRsZWQgfHwgaXNMb2NrZWRGb3JMb2dnZWRJblVzZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uZHJvcD1cInJldHVybiBmYWxzZTtcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZXh0YXJlYT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktdGV4dGFyZWEtY291bnRlciBbbWF4TGVuZ3RoXT1cIm1heENvbXBsYWludFJlc3BvbnNlVGV4dExpbWl0XCIgW2NvbnRlbnRdPVwiY29tcGxhaW50UmVzcG9uc2UucmVzcG9uc2VUZXh0XCIgW3Zpc2libGVdPVwiIWhhbmRsZWRcIj4gPC9qaGktdGV4dGFyZWEtY291bnRlcj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoIWhhbmRsZWQgJiYgY29tcGxhaW50LmNvbXBsYWludFR5cGUgPT09IENvbXBsYWludFR5cGUuQ09NUExBSU5UKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGZsZXgtd3JhcCBnYXAtMSBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImFjY2VwdENvbXBsYWludEJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tc3VjY2VzcyBidG4tYmxvY2tcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwicmVzcG9uZFRvQ29tcGxhaW50KHRydWUpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2Rpc2FibGVkXT1cImlzTG9ja2VkRm9yTG9nZ2VkSW5Vc2VyIHx8IGNvbXBsYWludFJlc3BvbnNlVGV4dExlbmd0aCgpID4gbWF4Q29tcGxhaW50UmVzcG9uc2VUZXh0TGltaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cInt7ICdhcnRlbWlzQXBwLmNvbXBsYWludFJlc3BvbnNlLnVwZGF0ZUFzc2Vzc21lbnRUb29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY29tcGxhaW50UmVzcG9uc2UudXBkYXRlQXNzZXNzbWVudCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInJlamVjdENvbXBsYWludEJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tZGFuZ2VyIGJ0bi1ibG9ja1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJyZXNwb25kVG9Db21wbGFpbnQoZmFsc2UpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2Rpc2FibGVkXT1cImlzTG9ja2VkRm9yTG9nZ2VkSW5Vc2VyIHx8IGNvbXBsYWludFJlc3BvbnNlVGV4dExlbmd0aCgpID4gbWF4Q29tcGxhaW50UmVzcG9uc2VUZXh0TGltaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cInt7ICdhcnRlbWlzQXBwLmNvbXBsYWludFJlc3BvbnNlLnJlamVjdENvbXBsYWludFRvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5jb21wbGFpbnRSZXNwb25zZS5yZWplY3RDb21wbGFpbnQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gZW1wdHkgZGl2IHRvIGNyZWF0ZSBhZGRpdGlvbmFsIHNwYWNpbmcgYWZ0ZXIgdGhlIGxhc3QgYnV0dG9uLCBidXQgb25seSBmb3Igc20gb3IgdXAgLS0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtbm9uZSBkLXNtLWJsb2NrXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKCFjb21wbGFpbnQuYWNjZXB0ZWQgJiYgY29tcGxhaW50LmNvbXBsYWludFR5cGUgPT09IENvbXBsYWludFR5cGUuTU9SRV9GRUVEQkFDSykge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvdyBqdXN0aWZ5LWNvbnRlbnQtZW5kIG10LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLTEyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwicmVzcG9uZFRvTW9yZUZlZWRiYWNrQnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gYnRuLXN1Y2Nlc3MgYnRuLWJsb2NrXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtkaXNhYmxlZF09XCJpc0xvY2tlZEZvckxvZ2dlZEluVXNlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwicmVzcG9uZFRvQ29tcGxhaW50KHRydWUpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwie3sgJ2FydGVtaXNBcHAubW9yZUZlZWRiYWNrUmVzcG9uc2Uuc2VuZFJlc3BvbnNlVG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAubW9yZUZlZWRiYWNrUmVzcG9uc2UucHJvdmlkZUZlZWRiYWNrJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbn1cbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IENvbXBsYWludHNGb3JUdXRvckNvbXBvbmVudCB9IGZyb20gJy4vY29tcGxhaW50cy1mb3ItdHV0b3IuY29tcG9uZW50JztcbmltcG9ydCB7IENvbXBsYWludFJlc3BvbnNlU2VydmljZSB9IGZyb20gJ2FwcC9jb21wbGFpbnRzL2NvbXBsYWludC1yZXNwb25zZS5zZXJ2aWNlJztcbmltcG9ydCB7IENvbXBsYWludFNlcnZpY2UgfSBmcm9tICdhcHAvY29tcGxhaW50cy9jb21wbGFpbnQuc2VydmljZSc7XG5pbXBvcnQgeyBUZXh0YXJlYU1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvdGV4dGFyZWEvdGV4dGFyZWEubW9kdWxlJztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZSwgVGV4dGFyZWFNb2R1bGVdLFxuICAgIGRlY2xhcmF0aW9uczogW0NvbXBsYWludHNGb3JUdXRvckNvbXBvbmVudF0sXG4gICAgZXhwb3J0czogW0NvbXBsYWludHNGb3JUdXRvckNvbXBvbmVudF0sXG4gICAgcHJvdmlkZXJzOiBbQ29tcGxhaW50U2VydmljZSwgQ29tcGxhaW50UmVzcG9uc2VTZXJ2aWNlXSxcbn0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc0NvbXBsYWludHNGb3JUdXRvck1vZHVsZSB7fVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBHcmFkaW5nSW5zdHJ1Y3Rpb24gfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9zdHJ1Y3R1cmVkLWdyYWRpbmctY3JpdGVyaW9uL2dyYWRpbmctaW5zdHJ1Y3Rpb24ubW9kZWwnO1xuaW1wb3J0IHsgRmVlZGJhY2sgfSBmcm9tICdhcHAvZW50aXRpZXMvZmVlZGJhY2subW9kZWwnO1xuaW1wb3J0IHsgQXJ0ZW1pc1RyYW5zbGF0ZVBpcGUgfSBmcm9tICdhcHAvc2hhcmVkL3BpcGVzL2FydGVtaXMtdHJhbnNsYXRlLnBpcGUnO1xuaW1wb3J0IHsgZmFMaW5rLCBmYVRyYXNoIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktZ3JhZGluZy1pbnN0cnVjdGlvbi1saW5rLWljb24nLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9ncmFkaW5nLWluc3RydWN0aW9uLWxpbmstaWNvbi5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIEdyYWRpbmdJbnN0cnVjdGlvbkxpbmtJY29uQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICBASW5wdXQoKSBsaW5rSWNvbiA9IGZhTGluaztcbiAgICBASW5wdXQoKSBmZWVkYmFjazogRmVlZGJhY2s7XG4gICAgaW5zdHJ1Y3Rpb246IEdyYWRpbmdJbnN0cnVjdGlvbiB8IHVuZGVmaW5lZDtcbiAgICBjb25maXJtSWNvbiA9IGZhVHJhc2g7XG4gICAgc2hvd0NvbmZpcm0gPSBmYWxzZTtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgYXJ0ZW1pc1RyYW5zbGF0ZVBpcGU6IEFydGVtaXNUcmFuc2xhdGVQaXBlKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuaW5zdHJ1Y3Rpb24gPSB0aGlzLmZlZWRiYWNrLmdyYWRpbmdJbnN0cnVjdGlvbjtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiByZW1vdmUgZ3JhZGluZyBpbnN0cnVjdGlvbiBvbiBjbGlja1xuICAgICAqL1xuICAgIHJlbW92ZUxpbmsoKTogdm9pZCB7XG4gICAgICAgIHRoaXMudG9nZ2xlKCk7XG4gICAgICAgIHRoaXMuZmVlZGJhY2suZ3JhZGluZ0luc3RydWN0aW9uID0gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNldCB0aGUgdG9vbHRpcCBvZiB0aGUgbGluayBpY29uIHRvIGJlIGVxdWFsIHRvIHRoZSBncmFkaW5nIGluc3RydWN0aW9uIGRlc2NyaXB0aW9uIHRleHRcbiAgICAgKiBAcGFyYW0ge0dyYWRpbmdJbnN0cnVjdGlvbn0gaW5zdHJ1Y3Rpb24gLSB0aGUgaW5zdHJ1Y3Rpb24gb2JqZWN0IHdoaWNoIGlzIGFzc29jaWF0ZWQgd2l0aCBmZWVkYmFja1xuICAgICAqL1xuICAgIHNldFRvb2x0aXAoaW5zdHJ1Y3Rpb246IEdyYWRpbmdJbnN0cnVjdGlvbikge1xuICAgICAgICByZXR1cm4gdGhpcy5hcnRlbWlzVHJhbnNsYXRlUGlwZS50cmFuc2Zvcm0oJ2FydGVtaXNBcHAuZXhlcmNpc2UuYXNzZXNzbWVudEluc3RydWN0aW9uJykgKyBpbnN0cnVjdGlvbi5pbnN0cnVjdGlvbkRlc2NyaXB0aW9uO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIHRvZ2dsZSBzaG93Q29uZmlybVxuICAgICAqL1xuICAgIHRvZ2dsZSgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5zaG93Q29uZmlybSA9ICF0aGlzLnNob3dDb25maXJtO1xuICAgIH1cbn1cbiIsIkBpZiAoIXNob3dDb25maXJtKSB7XG4gICAgPGZhLWljb24gW2ljb25dPVwibGlua0ljb25cIiBbbmdiVG9vbHRpcF09XCJzZXRUb29sdGlwKGluc3RydWN0aW9uISlcIiAoY2xpY2spPVwidG9nZ2xlKClcIj48L2ZhLWljb24+XG59XG5AaWYgKHNob3dDb25maXJtKSB7XG4gICAgPGZhLWljb25cbiAgICAgICAgW25nQ2xhc3NdPVwiJ3RleHQtZGFuZ2VyJ1wiXG4gICAgICAgIFtpY29uXT1cImNvbmZpcm1JY29uXCJcbiAgICAgICAgW25nYlRvb2x0aXBdPVwiJ2FydGVtaXNBcHAuYXNzZXNzbWVudC5tZXNzYWdlcy5yZW1vdmVBc3Nlc3NtZW50SW5zdHJ1Y3Rpb25MaW5rJyB8IGFydGVtaXNUcmFuc2xhdGVcIlxuICAgICAgICAobW91c2VsZWF2ZSk9XCJ0b2dnbGUoKVwiXG4gICAgICAgIChjbGljayk9XCJyZW1vdmVMaW5rKClcIlxuICAgID48L2ZhLWljb24+XG59XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IEdyYWRpbmdJbnN0cnVjdGlvbkxpbmtJY29uQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC9ncmFkaW5nLWluc3RydWN0aW9uLWxpbmstaWNvbi9ncmFkaW5nLWluc3RydWN0aW9uLWxpbmstaWNvbi5jb21wb25lbnQnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtHcmFkaW5nSW5zdHJ1Y3Rpb25MaW5rSWNvbkNvbXBvbmVudF0sXG4gICAgZXhwb3J0czogW0dyYWRpbmdJbnN0cnVjdGlvbkxpbmtJY29uQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc0dyYWRpbmdJbnN0cnVjdGlvbkxpbmtJY29uTW9kdWxlIHt9XG4iLCJpbXBvcnQgZGF5anMgZnJvbSAnZGF5anMvZXNtJztcbmltcG9ydCB7IEJhc2VFbnRpdHkgfSBmcm9tICdhcHAvc2hhcmVkL21vZGVsL2Jhc2UtZW50aXR5JztcbmltcG9ydCB7IEZlZWRiYWNrVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9mZWVkYmFjay5tb2RlbCc7XG5pbXBvcnQgeyBUZXh0QmxvY2tUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3RleHQtYmxvY2subW9kZWwnO1xuXG5leHBvcnQgZW51bSBUZXh0QXNzZXNzbWVudEV2ZW50VHlwZSB7XG4gICAgQUREX0ZFRURCQUNLX0FVVE9NQVRJQ0FMTFlfU0VMRUNURURfQkxPQ0sgPSAnQUREX0ZFRURCQUNLX0FVVE9NQVRJQ0FMTFlfU0VMRUNURURfQkxPQ0snLFxuICAgIEFERF9GRUVEQkFDS19NQU5VQUxMWV9TRUxFQ1RFRF9CTE9DSyA9ICdBRERfRkVFREJBQ0tfTUFOVUFMTFlfU0VMRUNURURfQkxPQ0snLFxuICAgIERFTEVURV9GRUVEQkFDSyA9ICdERUxFVEVfRkVFREJBQ0snLFxuICAgIEVESVRfQVVUT01BVElDX0ZFRURCQUNLID0gJ0VESVRfQVVUT01BVElDX0ZFRURCQUNLJyxcbiAgICBTVUJNSVRfQVNTRVNTTUVOVCA9ICdTVUJNSVRfQVNTRVNTTUVOVCcsXG4gICAgQVNTRVNTX05FWFRfU1VCTUlTU0lPTiA9ICdBU1NFU1NfTkVYVF9TVUJNSVNTSU9OJyxcbn1cblxuZXhwb3J0IGNsYXNzIFRleHRBc3Nlc3NtZW50RXZlbnQgaW1wbGVtZW50cyBCYXNlRW50aXR5IHtcbiAgICBwdWJsaWMgaWQ/OiBudW1iZXI7XG4gICAgcHVibGljIHVzZXJJZD86IG51bWJlcjtcbiAgICBwdWJsaWMgdGltZXN0YW1wPzogZGF5anMuRGF5anM7XG4gICAgcHVibGljIGV2ZW50VHlwZT86IFRleHRBc3Nlc3NtZW50RXZlbnRUeXBlO1xuICAgIHB1YmxpYyBmZWVkYmFja1R5cGU/OiBGZWVkYmFja1R5cGU7XG4gICAgcHVibGljIHNlZ21lbnRUeXBlPzogVGV4dEJsb2NrVHlwZTtcbiAgICBwdWJsaWMgY291cnNlSWQ/OiBudW1iZXI7XG4gICAgcHVibGljIHRleHRFeGVyY2lzZUlkPzogbnVtYmVyO1xuICAgIHB1YmxpYyBwYXJ0aWNpcGF0aW9uSWQ/OiBudW1iZXI7XG4gICAgcHVibGljIHN1Ym1pc3Npb25JZD86IG51bWJlcjtcblxuICAgIGNvbnN0cnVjdG9yKHVzZXJJZD86IG51bWJlciwgY291cnNlSWQ/OiBudW1iZXIsIHRleHRFeGVyY2lzZUlkPzogbnVtYmVyLCBwYXJ0aWNpcGF0aW9uSWQ/OiBudW1iZXIsIHN1Ym1pc3Npb25JZD86IG51bWJlcikge1xuICAgICAgICB0aGlzLnVzZXJJZCA9IHVzZXJJZDtcbiAgICAgICAgdGhpcy5jb3Vyc2VJZCA9IGNvdXJzZUlkO1xuICAgICAgICB0aGlzLnRleHRFeGVyY2lzZUlkID0gdGV4dEV4ZXJjaXNlSWQ7XG4gICAgICAgIHRoaXMucGFydGljaXBhdGlvbklkID0gcGFydGljaXBhdGlvbklkO1xuICAgICAgICB0aGlzLnN1Ym1pc3Npb25JZCA9IHN1Ym1pc3Npb25JZDtcbiAgICB9XG5cbiAgICBzZXRFdmVudFR5cGUodHlwZTogVGV4dEFzc2Vzc21lbnRFdmVudFR5cGUpIHtcbiAgICAgICAgdGhpcy5ldmVudFR5cGUgPSB0eXBlO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBzZXRGZWVkYmFja1R5cGUodHlwZT86IEZlZWRiYWNrVHlwZSkge1xuICAgICAgICB0aGlzLmZlZWRiYWNrVHlwZSA9IHR5cGU7XG4gICAgfVxuXG4gICAgc2V0U2VnbWVudFR5cGUodHlwZT86IFRleHRCbG9ja1R5cGUpIHtcbiAgICAgICAgdGhpcy5zZWdtZW50VHlwZSA9IHR5cGU7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgVGV4dEFzc2Vzc21lbnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy90ZXh0L2Fzc2Vzcy90ZXh0LWFzc2Vzc21lbnQuc2VydmljZSc7XG5pbXBvcnQgeyBUZXh0QXNzZXNzbWVudEV2ZW50LCBUZXh0QXNzZXNzbWVudEV2ZW50VHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy90ZXh0LWFzc2VzbWVudC1ldmVudC5tb2RlbCc7XG5pbXBvcnQgeyBBY2NvdW50U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL2F1dGgvYWNjb3VudC5zZXJ2aWNlJztcbmltcG9ydCB7IEZlZWRiYWNrVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9mZWVkYmFjay5tb2RlbCc7XG5pbXBvcnQgeyBUZXh0QmxvY2tUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3RleHQtYmxvY2subW9kZWwnO1xuaW1wb3J0IHsgUHJvZmlsZVNlcnZpY2UgfSBmcm9tICdhcHAvc2hhcmVkL2xheW91dHMvcHJvZmlsZXMvcHJvZmlsZS5zZXJ2aWNlJztcbmltcG9ydCB7IExvY2F0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcblxuLyoqXG4gKiBBIHNlcnZpY2UgdXNlZCB0byBtYW5hZ2Ugc2VuZGluZyBUZXh0QXNzZXNzbWVudEV2ZW50J3MgdG8gdGhlIHNlcnZlclxuICovXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIFRleHRBc3Nlc3NtZW50QW5hbHl0aWNzIHtcbiAgICBwcml2YXRlIHVzZXJJZDogbnVtYmVyO1xuICAgIHByaXZhdGUgY291cnNlSWQ6IG51bWJlcjtcbiAgICBwcml2YXRlIHRleHRFeGVyY2lzZUlkOiBudW1iZXI7XG4gICAgcHJpdmF0ZSBwYXJ0aWNpcGF0aW9uSWQ6IG51bWJlcjtcbiAgICBwcml2YXRlIHN1Ym1pc3Npb25JZDogbnVtYmVyO1xuICAgIHByaXZhdGUgZXZlbnRUb1NlbmQ6IFRleHRBc3Nlc3NtZW50RXZlbnQgPSBuZXcgVGV4dEFzc2Vzc21lbnRFdmVudCgpO1xuICAgIHByaXZhdGUgSU5WQUxJRF9WQUxVRSA9IC0xO1xuICAgIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlO1xuICAgIHB1YmxpYyBhbmFseXRpY3NFbmFibGVkID0gZmFsc2U7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJvdGVjdGVkIGFzc2Vzc21lbnRzU2VydmljZTogVGV4dEFzc2Vzc21lbnRTZXJ2aWNlLFxuICAgICAgICBwcm90ZWN0ZWQgYWNjb3VudFNlcnZpY2U6IEFjY291bnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHByb2ZpbGVTZXJ2aWNlOiBQcm9maWxlU2VydmljZSxcbiAgICAgICAgcHVibGljIGxvY2F0aW9uOiBMb2NhdGlvbixcbiAgICApIHtcbiAgICAgICAgLy8gcmV0cmlldmUgdGhlIGFuYWx5dGljcyBlbmFibGVkIHN0YXR1cyBmcm9tIHRoZSBwcm9maWxlIGluZm8gYW5kIHNldCB0byBjdXJyZW50IHByb3BlcnR5XG4gICAgICAgIHRoaXMucHJvZmlsZVNlcnZpY2UuZ2V0UHJvZmlsZUluZm8oKS5zdWJzY3JpYmUoKHByb2ZpbGVJbmZvKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmFuYWx5dGljc0VuYWJsZWQgPSBwcm9maWxlSW5mby50ZXh0QXNzZXNzbWVudEFuYWx5dGljc0VuYWJsZWQgfHwgZmFsc2U7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEFuZ3VsYXIgc2VydmljZXMgY2Fubm90IGluamVjdCByb3V0ZSBsaXN0ZW5lcnMgYXV0b21hdGljYWxseS4gVGhlIHJvdXRlIG5lZWRzIHRvIGJlIGluamVjdGVkIG1hbnVhbGx5LCBhbmQgdGhlblxuICAgICAqIGl0IGNhbiBiZSBsaXN0ZW5lZCB1cG9uLlxuICAgICAqIEBwYXJhbSByb3V0ZSB0aGUgcm91dGUgaW5zdGFuY2Ugb2YgdGhlIGNvbXBvbmVudCB1c2luZyB0aGUgc2VydmljZVxuICAgICAqL1xuICAgIHNldENvbXBvbmVudFJvdXRlKHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSkge1xuICAgICAgICBpZiAodGhpcy5hbmFseXRpY3NFbmFibGVkKSB7XG4gICAgICAgICAgICB0aGlzLnJvdXRlID0gcm91dGU7XG4gICAgICAgICAgICB0aGlzLnN1YnNjcmliZVRvUm91dGVQYXJhbWV0ZXJzKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVja3MgaWYgYXJ0ZW1pcyBhbmFseXRpY3MgaXMgZW5hYmxlZCwgYW5kIHRoZW4gc3VibWl0cyB0aGUgcHJlcGFyZWQgZXZlbnQgdG8gdGhlIHNlcnZlciB0aHJvdWdoIHRoZSBUZXh0QXNzZXNzbWVudFNlcnZpY2UuXG4gICAgICogQHBhcmFtIGV2ZW50VHlwZSB0eXBlIG9mIHRoZSBldmVudCB0byBiZSBzZW50XG4gICAgICogQHBhcmFtIGZlZWRiYWNrVHlwZSB0eXBlIG9mIHRoZSBmZWVkYmFjayB0byBiZSBzZW50LiBJdCBpcyB1bmRlZmluZWQgYnkgZGVmYXVsdCB0byBzdXBwb3J0IHNpbXBsZSBldmVudHMgdG9vLlxuICAgICAqIEBwYXJhbSB0ZXh0QmxvY2tUeXBlIHR5cGUgb2YgdGhlIHRleHQgYmxvY2sgdG8gYmUgc2VudC4gSXQgaXMgdW5kZWZpbmVkIGJ5IGRlZmF1bHQgdG8gc3VwcG9ydCBzaW1wbGUgZXZlbnRzIHRvby5cbiAgICAgKi9cbiAgICBzZW5kQXNzZXNzbWVudEV2ZW50KGV2ZW50VHlwZTogVGV4dEFzc2Vzc21lbnRFdmVudFR5cGUsIGZlZWRiYWNrVHlwZTogRmVlZGJhY2tUeXBlIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkLCB0ZXh0QmxvY2tUeXBlOiBUZXh0QmxvY2tUeXBlIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGlmICh0aGlzLmFuYWx5dGljc0VuYWJsZWQgJiYgIXRoaXMuaXNFeGFtcGxlU3VibWlzc2lvblJvdXRlKCkpIHtcbiAgICAgICAgICAgIHRoaXMuZXZlbnRUb1NlbmQuc2V0RXZlbnRUeXBlKGV2ZW50VHlwZSk7XG4gICAgICAgICAgICB0aGlzLmV2ZW50VG9TZW5kLnNldEZlZWRiYWNrVHlwZShmZWVkYmFja1R5cGUpO1xuICAgICAgICAgICAgdGhpcy5ldmVudFRvU2VuZC5zZXRTZWdtZW50VHlwZSh0ZXh0QmxvY2tUeXBlKTtcbiAgICAgICAgICAgIHRoaXMuYXNzZXNzbWVudHNTZXJ2aWNlLmFkZFRleHRBc3Nlc3NtZW50RXZlbnQodGhpcy5ldmVudFRvU2VuZCkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBlcnJvcjogKGUpID0+IGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHNlbmRpbmcgc3RhdGlzdGljczogJyArIGUubWVzc2FnZSksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgaXNFeGFtcGxlU3VibWlzc2lvblJvdXRlKCkge1xuICAgICAgICByZXR1cm4gISF0aGlzLmxvY2F0aW9uPy5wYXRoKCkuaW5jbHVkZXMoJ2V4YW1wbGUtc3VibWlzc2lvbicpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBTdWJzY3JpYmVzIHRvIHRoZSByb3V0ZSBwYXJhbWV0ZXJzIGFuZCB1cGRhdGVzIHRoZSByZXNwZWN0aXZlIGlkJ3MgYWNjb3JkaW5nbHkuXG4gICAgICogQXZvaWRzIGhhdmluZyB0byBzZXQgdGhlIGlkIG9uIHRoZSBjb21wb25lbnQncyBzaWRlLlxuICAgICAqL1xuICAgIHByaXZhdGUgc3Vic2NyaWJlVG9Sb3V0ZVBhcmFtZXRlcnMoKSB7XG4gICAgICAgIHRoaXMucm91dGUucGFyYW1zLnN1YnNjcmliZSgocGFyYW1zKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnVzZXJJZCA9IHRoaXMuYWNjb3VudFNlcnZpY2UudXNlcklkZW50aXR5ID8gTnVtYmVyKHRoaXMuYWNjb3VudFNlcnZpY2UudXNlcklkZW50aXR5LmlkKSA6IHRoaXMuSU5WQUxJRF9WQUxVRTtcbiAgICAgICAgICAgIHRoaXMuY291cnNlSWQgPSBOdW1iZXIocGFyYW1zWydjb3Vyc2VJZCddKTtcbiAgICAgICAgICAgIHRoaXMudGV4dEV4ZXJjaXNlSWQgPSBOdW1iZXIocGFyYW1zWydleGVyY2lzZUlkJ10pO1xuICAgICAgICAgICAgdGhpcy5wYXJ0aWNpcGF0aW9uSWQgPSBOdW1iZXIocGFyYW1zWydwYXJ0aWNpcGF0aW9uSWQnXSk7XG4gICAgICAgICAgICB0aGlzLnN1Ym1pc3Npb25JZCA9IE51bWJlcihwYXJhbXNbJ3N1Ym1pc3Npb25JZCddKTtcbiAgICAgICAgICAgIHRoaXMuZXZlbnRUb1NlbmQgPSBuZXcgVGV4dEFzc2Vzc21lbnRFdmVudCh0aGlzLnVzZXJJZCwgdGhpcy5jb3Vyc2VJZCwgdGhpcy50ZXh0RXhlcmNpc2VJZCwgdGhpcy5wYXJ0aWNpcGF0aW9uSWQsIHRoaXMuc3VibWlzc2lvbklkKTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIEhvc3RMaXN0ZW5lciwgSW5wdXQsIE91dHB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUmVzdWx0IH0gZnJvbSAnYXBwL2VudGl0aWVzL3Jlc3VsdC5tb2RlbCc7XG5pbXBvcnQgeyBFeGVyY2lzZSwgRXhlcmNpc2VUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IFRleHRBc3Nlc3NtZW50QW5hbHl0aWNzIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy90ZXh0L2Fzc2Vzcy9hbmFseXRpY3MvdGV4dC1hc3Nlc21lbnQtYW5hbHl0aWNzLnNlcnZpY2UnO1xuaW1wb3J0IHsgVGV4dEFzc2Vzc21lbnRFdmVudFR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvdGV4dC1hc3Nlc21lbnQtZXZlbnQubW9kZWwnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgQ29tcGxhaW50VHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb21wbGFpbnQubW9kZWwnO1xuaW1wb3J0IHsgQXNzZXNzbWVudFR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvYXNzZXNzbWVudC10eXBlLm1vZGVsJztcbmltcG9ydCB7IFRyYW5zbGF0ZVNlcnZpY2UgfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcbmltcG9ydCB7IGZhU2F2ZSwgZmFTcGlubmVyIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IGZhU3F1YXJlQ2FyZXRSaWdodCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXJlZ3VsYXItc3ZnLWljb25zJztcblxuLyoqXG4gKiBUaGUgPGpoaS1hc3Nlc3NtZW50LWhlYWRlcj4gY29tcG9uZW50IGlzIHVzZWQgaW4gdGhlIHNoYXJlZCBhc3Nlc3NtZW50IGxheW91dC5cbiAqIEl0IGRpc3BsYXlzIGEgaGVhZGVyIGJhciBhYm92ZSB0aGUgYXNzZXNzbWVudCBlZGl0b3Igd2l0aCBpbmZvcm1hdGlvbiBvZiBsb2NraW5nLCBhcyB3ZWxsIGFzIG9mZmVyaW5nIHNhdmUvc3VibWl0L2V0YyBidXR0b25zLlxuICogVGhpcyBndWFyYW50ZWVzIGEgdW5pZmllZCBsb29rIGFuZCBmZWVsIGZvciBib3RoIGludGVyZmFjZXMuXG4gKiBEZXBlbmRpbmcgQ29tcG9uZW50cyBuZWVkIHRvIHBlcmZvcm0gYWN0aW9ucyBiYXNlZCBvbiB0aGUgc2F2ZS9zdWJtaXQvY2FuY2VsL25leHRTdWJtaXNzaW9uL25hdmlnYXRlQmFjayBvdXRwdXRzLlxuICovXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1hc3Nlc3NtZW50LWhlYWRlcicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2Fzc2Vzc21lbnQtaGVhZGVyLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9hc3Nlc3NtZW50LWhlYWRlci5jb21wb25lbnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBBc3Nlc3NtZW50SGVhZGVyQ29tcG9uZW50IHtcbiAgICBASW5wdXQoKSBpc0xvYWRpbmc6IGJvb2xlYW47XG4gICAgQElucHV0KCkgc2F2ZUJ1c3k6IGJvb2xlYW47XG4gICAgQElucHV0KCkgc3VibWl0QnVzeTogYm9vbGVhbjtcbiAgICBASW5wdXQoKSBjYW5jZWxCdXN5OiBib29sZWFuO1xuICAgIEBJbnB1dCgpIG5leHRTdWJtaXNzaW9uQnVzeTogYm9vbGVhbjtcbiAgICBASW5wdXQoKSBjb3JyZWN0aW9uUm91bmQgPSAwOyAvLyBjb3JyZWN0aW9uUm91bmQgZGVmYXVsdHMgdG8gMFxuXG4gICAgQElucHV0KCkgaXNUZWFtTW9kZTogYm9vbGVhbjtcbiAgICBASW5wdXQoKSBpc0Fzc2Vzc29yOiBib29sZWFuO1xuICAgIEBJbnB1dCgpIGlzVGVzdFJ1biA9IGZhbHNlO1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlRGFzaGJvYXJkTGluazogc3RyaW5nW107XG4gICAgQElucHV0KCkgY2FuT3ZlcnJpZGU6IGJvb2xlYW47XG5cbiAgICBASW5wdXQoKSBleGVyY2lzZT86IEV4ZXJjaXNlO1xuICAgIEBJbnB1dCgpIHJlc3VsdD86IFJlc3VsdDtcbiAgICBASW5wdXQoKSBpc0lsbGVnYWxTdWJtaXNzaW9uOiBib29sZWFuO1xuICAgIEBJbnB1dCgpIGhhc0NvbXBsYWludCA9IGZhbHNlO1xuICAgIEBJbnB1dCgpIGhhc01vcmVGZWVkYmFja1JlcXVlc3QgPSBmYWxzZTtcbiAgICBASW5wdXQoKSBjb21wbGFpbnRIYW5kbGVkID0gZmFsc2U7XG4gICAgQElucHV0KCkgY29tcGxhaW50VHlwZT86IENvbXBsYWludFR5cGU7XG4gICAgQElucHV0KCkgYXNzZXNzbWVudHNBcmVWYWxpZDogYm9vbGVhbjtcbiAgICBASW5wdXQoKSBoYXNBc3Nlc3NtZW50RHVlRGF0ZVBhc3NlZDogYm9vbGVhbjtcbiAgICBASW5wdXQoKSBpc1Byb2dyYW1taW5nRXhlcmNpc2UgPSBmYWxzZTsgLy8gcmVtb3ZlIG9uY2UgZGlmZiB2aWV3IGFjdGl2YXRlZCBmb3IgcHJvZ3JhbW1pbmcgZXhlcmNpc2VzXG5cbiAgICBAT3V0cHV0KCkgc2F2ZSA9IG5ldyBFdmVudEVtaXR0ZXI8dm9pZD4oKTtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQGFuZ3VsYXItZXNsaW50L25vLW91dHB1dC1uYXRpdmVcbiAgICBAT3V0cHV0KCkgc3VibWl0ID0gbmV3IEV2ZW50RW1pdHRlcjx2b2lkPigpO1xuICAgIEBPdXRwdXQoKSBjYW5jZWwgPSBuZXcgRXZlbnRFbWl0dGVyPHZvaWQ+KCk7XG4gICAgQE91dHB1dCgpIG5leHRTdWJtaXNzaW9uID0gbmV3IEV2ZW50RW1pdHRlcjx2b2lkPigpO1xuICAgIEBPdXRwdXQoKSBoaWdobGlnaHREaWZmZXJlbmNlc0NoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8Ym9vbGVhbj4oKTtcbiAgICBAT3V0cHV0KCkgdXNlQXNFeGFtcGxlU3VibWlzc2lvbiA9IG5ldyBFdmVudEVtaXR0ZXI8dm9pZD4oKTtcblxuICAgIHByaXZhdGUgX2hpZ2hsaWdodERpZmZlcmVuY2VzOiBib29sZWFuO1xuICAgIHJlYWRvbmx5IEV4ZXJjaXNlVHlwZSA9IEV4ZXJjaXNlVHlwZTtcbiAgICByZWFkb25seSBDb21wbGFpbnRUeXBlID0gQ29tcGxhaW50VHlwZTtcbiAgICByZWFkb25seSBBc3Nlc3NtZW50VHlwZSA9IEFzc2Vzc21lbnRUeXBlO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYVNwaW5uZXIgPSBmYVNwaW5uZXI7XG4gICAgZmFTYXZlID0gZmFTYXZlO1xuICAgIGZhU3F1YXJlQ2FyZXRSaWdodCA9IGZhU3F1YXJlQ2FyZXRSaWdodDtcblxuICAgIEBJbnB1dCgpIHNldCBoaWdobGlnaHREaWZmZXJlbmNlcyhoaWdobGlnaHREaWZmZXJlbmNlczogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9oaWdobGlnaHREaWZmZXJlbmNlcyA9IGhpZ2hsaWdodERpZmZlcmVuY2VzO1xuICAgICAgICB0aGlzLmhpZ2hsaWdodERpZmZlcmVuY2VzQ2hhbmdlLmVtaXQodGhpcy5oaWdobGlnaHREaWZmZXJlbmNlcyk7XG4gICAgfVxuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHB1YmxpYyB0ZXh0QXNzZXNzbWVudEFuYWx5dGljczogVGV4dEFzc2Vzc21lbnRBbmFseXRpY3MsXG4gICAgICAgIHByb3RlY3RlZCByb3V0ZTogQWN0aXZhdGVkUm91dGUsXG4gICAgICAgIHByaXZhdGUgdHJhbnNsYXRlU2VydmljZTogVHJhbnNsYXRlU2VydmljZSxcbiAgICApIHtcbiAgICAgICAgdGV4dEFzc2Vzc21lbnRBbmFseXRpY3Muc2V0Q29tcG9uZW50Um91dGUocm91dGUpO1xuICAgIH1cblxuICAgIGdldCBoaWdobGlnaHREaWZmZXJlbmNlcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2hpZ2hsaWdodERpZmZlcmVuY2VzO1xuICAgIH1cblxuICAgIGdldCBvdmVycmlkZVZpc2libGUoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlc3VsdD8uY29tcGxldGlvbkRhdGUgJiYgdGhpcy5jYW5PdmVycmlkZTtcbiAgICB9XG5cbiAgICBnZXQgYXNzZXNzTmV4dFZpc2libGUoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlc3VsdD8uY29tcGxldGlvbkRhdGUgJiYgKHRoaXMuaXNBc3Nlc3NvciB8fCB0aGlzLmV4ZXJjaXNlPy5pc0F0TGVhc3RJbnN0cnVjdG9yKSAmJiAhdGhpcy5oYXNDb21wbGFpbnQgJiYgIXRoaXMuaXNUZWFtTW9kZSAmJiAhdGhpcy5pc1Rlc3RSdW47XG4gICAgfVxuXG4gICAgZ2V0IHNhdmVEaXNhYmxlZCgpIHtcbiAgICAgICAgLy8gaWYgdGhlcmUgaXMgbm8gJ3NhdmUnIGJ1dHRvblxuICAgICAgICBpZiAodGhpcy5yZXN1bHQ/LmNvbXBsZXRpb25EYXRlKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiAhdGhpcy5hc3Nlc3NtZW50c0FyZVZhbGlkIHx8ICF0aGlzLmlzQXNzZXNzb3IgfHwgdGhpcy5zYXZlQnVzeSB8fCB0aGlzLnN1Ym1pdEJ1c3kgfHwgdGhpcy5jYW5jZWxCdXN5O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZ2V0IHN1Ym1pdERpc2FibGVkKCkge1xuICAgICAgICByZXR1cm4gIXRoaXMuYXNzZXNzbWVudHNBcmVWYWxpZCB8fCAhdGhpcy5pc0Fzc2Vzc29yIHx8IHRoaXMuc2F2ZUJ1c3kgfHwgdGhpcy5zdWJtaXRCdXN5IHx8IHRoaXMuY2FuY2VsQnVzeTtcbiAgICB9XG5cbiAgICBnZXQgb3ZlcnJpZGVEaXNhYmxlZCgpIHtcbiAgICAgICAgaWYgKHRoaXMub3ZlcnJpZGVWaXNpYmxlKSB7XG4gICAgICAgICAgICByZXR1cm4gIXRoaXMuYXNzZXNzbWVudHNBcmVWYWxpZCB8fCB0aGlzLnN1Ym1pdEJ1c3k7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGdldCBhc3Nlc3NOZXh0RGlzYWJsZWQoKSB7XG4gICAgICAgIGlmICh0aGlzLmFzc2Vzc05leHRWaXNpYmxlKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5uZXh0U3VibWlzc2lvbkJ1c3kgfHwgdGhpcy5zdWJtaXRCdXN5O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBASG9zdExpc3RlbmVyKCdkb2N1bWVudDprZXlkb3duLmNvbnRyb2wucycsIFsnJGV2ZW50J10pXG4gICAgc2F2ZU9uQ29udHJvbEFuZFMoZXZlbnQ6IEtleWJvYXJkRXZlbnQpIHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaWYgKCF0aGlzLnNhdmVEaXNhYmxlZCkge1xuICAgICAgICAgICAgdGhpcy5zYXZlLmVtaXQoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIEBIb3N0TGlzdGVuZXIoJ2RvY3VtZW50OmtleWRvd24uY29udHJvbC5lbnRlcicsIFsnJGV2ZW50J10pXG4gICAgc3VibWl0T25Db250cm9sQW5kRW50ZXIoZXZlbnQ6IEtleWJvYXJkRXZlbnQpIHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaWYgKCF0aGlzLm92ZXJyaWRlRGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHRoaXMuc3VibWl0LmVtaXQoKTtcbiAgICAgICAgfSBlbHNlIGlmICghdGhpcy5zdWJtaXREaXNhYmxlZCkge1xuICAgICAgICAgICAgdGhpcy5zdWJtaXQuZW1pdCgpO1xuICAgICAgICAgICAgdGhpcy5zZW5kU3VibWl0QXNzZXNzbWVudEV2ZW50VG9BbmFseXRpY3MoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIEBIb3N0TGlzdGVuZXIoJ2RvY3VtZW50OmtleWRvd24uY29udHJvbC5zaGlmdC5hcnJvd1JpZ2h0JywgWyckZXZlbnQnXSlcbiAgICBhc3Nlc3NOZXh0T25Db250cm9sU2hpZnRBbmRBcnJvd1JpZ2h0KGV2ZW50OiBLZXlib2FyZEV2ZW50KSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGlmICghdGhpcy5hc3Nlc3NOZXh0RGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHRoaXMubmV4dFN1Ym1pc3Npb24uZW1pdCgpO1xuICAgICAgICAgICAgdGhpcy5zZW5kQXNzZXNzTmV4dEV2ZW50VG9BbmFseXRpY3MoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEluIEV4YW1Nb2RlOlxuICAgICAqIEhpZ2hsaWdodCB0aGUgZGlmZmVyZW5jZSBiZXR3ZWVuIHRoZSBmaXJzdCBhbmQgc2Vjb25kIGNvcnJlY3Rpb24gcm91bmRcbiAgICAgKi9cbiAgICBwdWJsaWMgdG9nZ2xlSGlnaGxpZ2h0RGlmZmVyZW5jZXMoKSB7XG4gICAgICAgIHRoaXMuaGlnaGxpZ2h0RGlmZmVyZW5jZXMgPSAhdGhpcy5oaWdobGlnaHREaWZmZXJlbmNlcztcbiAgICAgICAgdGhpcy5oaWdobGlnaHREaWZmZXJlbmNlc0NoYW5nZS5lbWl0KHRoaXMuaGlnaGxpZ2h0RGlmZmVyZW5jZXMpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGFuZCBhc3Nlc3NtZW50IGV2ZW50IGZvciB0aGUgc3VibWl0IGJ1dHRvbiB1c2luZyB0aGUgYW5hbHl0aWNzIHNlcnZpY2UgaW4gY2FzZSB0aGUgZXhlcmNpc2UgdHlwZSBpcyBURVhUXG4gICAgICovXG4gICAgc2VuZFN1Ym1pdEFzc2Vzc21lbnRFdmVudFRvQW5hbHl0aWNzKCkge1xuICAgICAgICBpZiAodGhpcy5leGVyY2lzZT8udHlwZSA9PT0gRXhlcmNpc2VUeXBlLlRFWFQpIHtcbiAgICAgICAgICAgIHRoaXMudGV4dEFzc2Vzc21lbnRBbmFseXRpY3Muc2VuZEFzc2Vzc21lbnRFdmVudChUZXh0QXNzZXNzbWVudEV2ZW50VHlwZS5TVUJNSVRfQVNTRVNTTUVOVCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZW5kcyBhbmQgYXNzZXNzbWVudCBldmVudCBmb3IgdGhlIGFzc2VzcyBuZXh0IGJ1dHRvbiB1c2luZyB0aGUgYW5hbHl0aWNzIHNlcnZpY2UgaW4gY2FzZSB0aGUgZXhlcmNpc2UgdHlwZSBpcyBURVhUXG4gICAgICovXG4gICAgc2VuZEFzc2Vzc05leHRFdmVudFRvQW5hbHl0aWNzKCkge1xuICAgICAgICBpZiAodGhpcy5leGVyY2lzZT8udHlwZSA9PT0gRXhlcmNpc2VUeXBlLlRFWFQpIHtcbiAgICAgICAgICAgIHRoaXMudGV4dEFzc2Vzc21lbnRBbmFseXRpY3Muc2VuZEFzc2Vzc21lbnRFdmVudChUZXh0QXNzZXNzbWVudEV2ZW50VHlwZS5BU1NFU1NfTkVYVF9TVUJNSVNTSU9OKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE9wZW5zIGRpYWxvZyB0byB2ZXJpZnkgdGhhdCBpbnN0cnVjdG9yIHdhbnRzIHRvIHVzZSBjdXJyZW50IHN1Ym1pc3Npb24gYXMgZXhhbXBsZSBzdWJtaXNzaW9uXG4gICAgICovXG4gICAgb25Vc2VBc0V4YW1wbGVTb2x1dGlvbkNsaWNrZWQoKSB7XG4gICAgICAgIGNvbnN0IHZlcmlmaWNhdGlvbk1lc3NhZ2UgPSB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LnVzZUFzRXhhbXBsZVN1Ym1pc3Npb25WZXJpZmljYXRpb25RdWVzdGlvbicpO1xuICAgICAgICBpZiAoY29uZmlybSh2ZXJpZmljYXRpb25NZXNzYWdlKSkge1xuICAgICAgICAgICAgdGhpcy51c2VBc0V4YW1wbGVTdWJtaXNzaW9uLmVtaXQoKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsIjxoMyBjbGFzcz1cInRvcC1jb250YWluZXIgZmxleC13cmFwIGZsZXgtbGctbm93cmFwXCI+XG4gICAgPCEtLWJhY2sgYnV0dG9uIG9ubHkgdXNlZCBpbiBhc3Nlc3NtZW50IGRhc2hib2FyZC0tPlxuICAgIDxkaXYgY2xhc3M9XCJyb3ctY29udGFpbmVyIG1lLTJcIj5cbiAgICAgICAgQGlmICghaXNUZXN0UnVuKSB7XG4gICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnQuYXNzZXNzbWVudFwiPkFzc2Vzc21lbnQ8L3NwYW4+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChpc1Rlc3RSdW4pIHtcbiAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC50ZXN0UnVuQXNzZXNzbWVudFwiPlRlc3QgUnVuIEFzc2Vzc21lbnQ8L3NwYW4+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChpc0lsbGVnYWxTdWJtaXNzaW9uKSB7XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLWRhbmdlciBtcy0zXCIgc3R5bGU9XCJmb250LXNpemU6IDY1JVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC5hc3Nlc3NtZW50SWxsZWdhbFN1Ym1pc3Npb25cIj5cbiAgICAgICAgICAgICAgICBXYXJuaW5nOiBZb3UgYXJlIHZpZXdpbmcgYW4gaWxsZWdhbCBzdWJtaXNzaW9uLlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICB9XG4gICAgPC9kaXY+XG4gICAgQGlmIChoYXNBc3Nlc3NtZW50RHVlRGF0ZVBhc3NlZCAmJiAhcmVzdWx0Py5jb21wbGV0aW9uRGF0ZSkge1xuICAgICAgICA8bmdiLWFsZXJ0IFtzdHlsZS5mb250U2l6ZV09XCInNjUlJ1wiIFt0eXBlXT1cIid3YXJuaW5nJ1wiIChjbG9zZSk9XCJoYXNBc3Nlc3NtZW50RHVlRGF0ZVBhc3NlZCA9IGZhbHNlXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmFzc2Vzc21lbnREdWVEYXRlSXNPdmVyXCI+XG4gICAgICAgICAgICBBc3Nlc3NtZW50IER1ZSBEYXRlIGlzIG92ZXIsIHRoZSBhc3Nlc3NtZW50IHdpbGwgYmUgcHVibGlzaGVkIGltbWVkaWF0ZWx5IGFmdGVyIHN1Ym1pdHRpbmdcbiAgICAgICAgPC9uZ2ItYWxlcnQ+XG4gICAgfVxuICAgIEBpZiAoIWlzTG9hZGluZykge1xuICAgICAgICA8ZGl2IGNsYXNzPVwicm93LWNvbnRhaW5lciBmbGV4LXdyYXAgZmxleC1sZy1ub3dyYXBcIj5cbiAgICAgICAgICAgIEBpZiAoIWlzQXNzZXNzb3IgJiYgIWhhc0NvbXBsYWludCkge1xuICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiYXNzZXNzbWVudExvY2tlZFwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwidGV4dC1kYW5nZXIgbS0yXCJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9XCJmb250LXNpemU6IDY1JVwiXG4gICAgICAgICAgICAgICAgICAgIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC5hc3Nlc3NtZW50TG9ja2VkXCJcbiAgICAgICAgICAgICAgICAgICAgW3RyYW5zbGF0ZVZhbHVlc109XCJ7IG90aGVyVXNlcjogcmVzdWx0Py5hc3Nlc3Nvcj8ubmFtZSArICcgKCcgKyByZXN1bHQ/LmFzc2Vzc29yPy5sb2dpbiArICcpJyB9XCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIEFzc2Vzc21lbnQgbG9ja2VkIGJ5OiBvdGhlclVzZXJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKFxuICAgICAgICAgICAgICAgIGlzQXNzZXNzb3IgJiZcbiAgICAgICAgICAgICAgICBleGVyY2lzZSAmJlxuICAgICAgICAgICAgICAgICFleGVyY2lzZS5pc0F0TGVhc3RJbnN0cnVjdG9yICYmXG4gICAgICAgICAgICAgICAgaGFzQ29tcGxhaW50ICYmXG4gICAgICAgICAgICAgICAgY29tcGxhaW50VHlwZSAhPSBDb21wbGFpbnRUeXBlLkNPTVBMQUlOVCAmJlxuICAgICAgICAgICAgICAgICFjb21wbGFpbnRIYW5kbGVkICYmXG4gICAgICAgICAgICAgICAgZXhlcmNpc2UuYXNzZXNzbWVudFR5cGUgIT09IEFzc2Vzc21lbnRUeXBlLkFVVE9NQVRJQ1xuICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgPHNwYW4gaWQ9XCJtb3JlRmVlZGJhY2tSZXF1ZXN0XCIgY2xhc3M9XCJtLTJcIiBzdHlsZT1cImZvbnQtc2l6ZTogNjUlXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50Lm1vcmVGZWVkYmFja1JlcXVlc3RcIj5cbiAgICAgICAgICAgICAgICAgICAgWW91IGhhdmUgdG8gcmVzcG9uZCB0byB0aGUgZmVlZGJhY2sgcmVxdWVzdC5cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKFxuICAgICAgICAgICAgICAgIGlzQXNzZXNzb3IgJiZcbiAgICAgICAgICAgICAgICBleGVyY2lzZSAmJlxuICAgICAgICAgICAgICAgICFleGVyY2lzZS5pc0F0TGVhc3RJbnN0cnVjdG9yICYmXG4gICAgICAgICAgICAgICAgaGFzQ29tcGxhaW50ICYmXG4gICAgICAgICAgICAgICAgY29tcGxhaW50VHlwZSAhPSBDb21wbGFpbnRUeXBlLkNPTVBMQUlOVCAmJlxuICAgICAgICAgICAgICAgIGV4ZXJjaXNlLmFzc2Vzc21lbnRUeXBlID09PSBBc3Nlc3NtZW50VHlwZS5BVVRPTUFUSUMgJiZcbiAgICAgICAgICAgICAgICAhY29tcGxhaW50SGFuZGxlZCAmJlxuICAgICAgICAgICAgICAgICFleGVyY2lzZS50ZWFtTW9kZVxuICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgPHNwYW4gaWQ9XCJhdXRvbWF0aWNBc3Nlc3NtZW50RmVlZGJhY2tSZXF1ZXN0XCIgY2xhc3M9XCJtLTJcIiBzdHlsZT1cImZvbnQtc2l6ZTogNjUlXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmF1dG9tYXRpY0Fzc2Vzc21lbnRGZWVkYmFja1JlcXVlc3RcIj5cbiAgICAgICAgICAgICAgICAgICAgWW91IG1heSByZXNwb25kIHRvIHRoZSBmZWVkYmFjayByZXF1ZXN0LlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAoaXNBc3Nlc3NvciAmJiBleGVyY2lzZSAmJiAhZXhlcmNpc2UuaXNBdExlYXN0SW5zdHJ1Y3RvciAmJiBoYXNDb21wbGFpbnQgJiYgY29tcGxhaW50VHlwZSA9PSBDb21wbGFpbnRUeXBlLkNPTVBMQUlOVCAmJiAhY29tcGxhaW50SGFuZGxlZCAmJiBleGVyY2lzZS50ZWFtTW9kZSkge1xuICAgICAgICAgICAgICAgIDxzcGFuIGlkPVwidGVhbUNvbXBsYWludFwiIGNsYXNzPVwibS0yXCIgc3R5bGU9XCJmb250LXNpemU6IDY1JVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC50ZWFtQ29tcGxhaW50XCI+IFlvdSBoYXZlIHRvIHJlc3BvbmQgdG8gdGhlIGNvbXBsYWludC4gPC9zcGFuPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmIChcbiAgICAgICAgICAgICAgICBpc0Fzc2Vzc29yICYmXG4gICAgICAgICAgICAgICAgZXhlcmNpc2UgJiZcbiAgICAgICAgICAgICAgICAhZXhlcmNpc2UuaXNBdExlYXN0SW5zdHJ1Y3RvciAmJlxuICAgICAgICAgICAgICAgIGhhc0NvbXBsYWludCAmJlxuICAgICAgICAgICAgICAgIGNvbXBsYWludFR5cGUgPT0gQ29tcGxhaW50VHlwZS5DT01QTEFJTlQgJiZcbiAgICAgICAgICAgICAgICBleGVyY2lzZS5hc3Nlc3NtZW50VHlwZSA9PT0gQXNzZXNzbWVudFR5cGUuQVVUT01BVElDICYmXG4gICAgICAgICAgICAgICAgIWNvbXBsYWludEhhbmRsZWQgJiZcbiAgICAgICAgICAgICAgICAhZXhlcmNpc2UudGVhbU1vZGVcbiAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgIDxzcGFuIGlkPVwiYXV0b21hdGljQXNzZXNzbWVudENvbXBsYWludFwiIGNsYXNzPVwibS0yXCIgc3R5bGU9XCJmb250LXNpemU6IDY1JVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC5hdXRvbWF0aWNBc3Nlc3NtZW50Q29tcGxhaW50XCI+XG4gICAgICAgICAgICAgICAgICAgIFlvdSBtYXkgcmVzcG9uZCB0byB0aGUgY29tcGxhaW50LlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAoXG4gICAgICAgICAgICAgICAgaXNBc3Nlc3NvciAmJlxuICAgICAgICAgICAgICAgIGV4ZXJjaXNlICYmXG4gICAgICAgICAgICAgICAgIWV4ZXJjaXNlLmlzQXRMZWFzdEluc3RydWN0b3IgJiZcbiAgICAgICAgICAgICAgICBoYXNDb21wbGFpbnQgJiZcbiAgICAgICAgICAgICAgICBleGVyY2lzZS5hc3Nlc3NtZW50VHlwZSAhPT0gQXNzZXNzbWVudFR5cGUuQVVUT01BVElDICYmXG4gICAgICAgICAgICAgICAgY29tcGxhaW50VHlwZSA9PSBDb21wbGFpbnRUeXBlLkNPTVBMQUlOVCAmJlxuICAgICAgICAgICAgICAgICFjb21wbGFpbnRIYW5kbGVkICYmXG4gICAgICAgICAgICAgICAgIWV4ZXJjaXNlLnRlYW1Nb2RlXG4gICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICA8c3BhbiBpZD1cImFzc2Vzc21lbnRSZWFkT25seVVuaGFuZGxlZENvbXBsYWludFwiIGNsYXNzPVwibS0yXCIgc3R5bGU9XCJmb250LXNpemU6IDY1JVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC5hc3Nlc3NtZW50UmVhZE9ubHlVbmhhbmRsZWRDb21wbGFpbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgVGhlcmUgaXMgYSBjb21wbGFpbnQgZm9yIHRoaXMgYXNzZXNzbWVudC4gQW5vdGhlciB0dXRvciBtdXN0IHJlc3BvbmQuXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmIChpc0Fzc2Vzc29yICYmIGV4ZXJjaXNlICYmICFleGVyY2lzZS5pc0F0TGVhc3RJbnN0cnVjdG9yICYmIGhhc0NvbXBsYWludCAmJiBjb21wbGFpbnRIYW5kbGVkICYmICFleGVyY2lzZS50ZWFtTW9kZSkge1xuICAgICAgICAgICAgICAgIDxzcGFuIGlkPVwiYXNzZXNzbWVudFJlYWRPbmx5SGFuZGxlZFwiIGNsYXNzPVwibS0yXCIgc3R5bGU9XCJmb250LXNpemU6IDY1JVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC5hc3Nlc3NtZW50UmVhZE9ubHlIYW5kbGVkQ29tcGxhaW50XCI+XG4gICAgICAgICAgICAgICAgICAgIFRoZSBjb21wbGFpbnQgYWJvdXQgeW91ciBhc3Nlc3NtZW50IGhhcyBiZWVuIHJlc29sdmVkLlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAoaXNBc3Nlc3NvciAmJiAoIWhhc0NvbXBsYWludCB8fCBleGVyY2lzZT8uaXNBdExlYXN0SW5zdHJ1Y3RvcikpIHtcbiAgICAgICAgICAgICAgICA8c3BhbiBpZD1cImFzc2Vzc21lbnRMb2NrZWRDdXJyZW50VXNlclwiIGNsYXNzPVwidGV4dC1kYW5nZXIgbS0yXCIgc3R5bGU9XCJmb250LXNpemU6IDY1JVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC5hc3Nlc3NtZW50TG9ja2VkQ3VycmVudFVzZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgWW91IGhhdmUgdGhlIGxvY2sgZm9yIHRoaXMgYXNzZXNzbWVudFxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwhLS0gSGlnaGxpZ2h0IHRoZSBkaWZmZXJlbmNlIGJldHdlZW4gZmlyc3QgYW5kIHNlY29uZCBjb3JyZWN0aW9uIC0tPlxuICAgICAgICAgICAgQGlmICghaXNQcm9ncmFtbWluZ0V4ZXJjaXNlICYmIHJlc3VsdCAmJiBjb3JyZWN0aW9uUm91bmQgPiAwKSB7XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBtcy0yIGJ0bi1wcmltYXJ5XCIgKGNsaWNrKT1cInRvZ2dsZUhpZ2hsaWdodERpZmZlcmVuY2VzKClcIiBbZGlzYWJsZWRdPVwic2F2ZUJ1c3kgfHwgc3VibWl0QnVzeSB8fCBjYW5jZWxCdXN5XCI+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoIWhpZ2hsaWdodERpZmZlcmVuY2VzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5nYlRvb2x0aXA9XCJ7eyAnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmRpZmZWaWV3LmhpZ2hsaWdodEFzc2Vzc21lbnREaWZmVG9vbHRpcE9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC5kaWZmVmlldy5kaWZmZXJlbmNlQWN0aXZhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5BY3RpdmF0ZSBEaWZmLVZpZXc8L3NwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKGhpZ2hsaWdodERpZmZlcmVuY2VzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5nYlRvb2x0aXA9XCJ7eyAnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmRpZmZWaWV3LmhpZ2hsaWdodEFzc2Vzc21lbnREaWZmVG9vbHRpcE9mZicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnQuZGlmZlZpZXcuZGlmZmVyZW5jZURlYWN0aXZhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5EZWFjdGl2YXRlIERpZmYtVmlldzwvc3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXggZmxleC13cmFwIGZsZXgtbGctbm93cmFwXCI+XG4gICAgICAgICAgICAgICAgQGlmICghcmVzdWx0Py5jb21wbGV0aW9uRGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBtLTEgYnRuLXByaW1hcnlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cInNhdmUuZW1pdCgpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtkaXNhYmxlZF09XCJzYXZlRGlzYWJsZWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW25nYlRvb2x0aXBdPVwiKCdhcnRlbWlzQXBwLmFzc2Vzc21lbnQuYnV0dG9uLmNvbnRyb2wnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSkgKyAnICsgUydcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHNhdmVCdXN5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFTcGlubmVyXCIgW3NwaW5dPVwidHJ1ZVwiPiZuYnNwOzwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhU2F2ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImVudGl0eS5hY3Rpb24uc2F2ZVwiPlNhdmU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBtLTEgYnRuLXN1Y2Nlc3NcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cInN1Ym1pdC5lbWl0KCk7IHNlbmRTdWJtaXRBc3Nlc3NtZW50RXZlbnRUb0FuYWx5dGljcygpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtkaXNhYmxlZF09XCJzdWJtaXREaXNhYmxlZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbbmdiVG9vbHRpcF09XCIoJ2FydGVtaXNBcHAuYXNzZXNzbWVudC5idXR0b24uY29udHJvbCcgfCBhcnRlbWlzVHJhbnNsYXRlKSArICcgKyBFbnRlcidcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHN1Ym1pdEJ1c3kpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVNwaW5uZXJcIiBbc3Bpbl09XCJ0cnVlXCI+Jm5ic3A7PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZW50aXR5LmFjdGlvbi5zdWJtaXRcIj5TdWJtaXQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKCFpc1Rlc3RSdW4pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBtLTEgYnRuLWRhbmdlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cImNhbmNlbC5lbWl0KClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtkaXNhYmxlZF09XCIhKGV4ZXJjaXNlPy5pc0F0TGVhc3RJbnN0cnVjdG9yIHx8IGlzQXNzZXNzb3IpIHx8IHNhdmVCdXN5IHx8IHN1Ym1pdEJ1c3kgfHwgY2FuY2VsQnVzeVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjYW5jZWxCdXN5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhU3Bpbm5lclwiIFtzcGluXT1cInRydWVcIj4mbmJzcDs8L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImVudGl0eS5hY3Rpb24uY2FuY2VsXCI+Q2FuY2VsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmIChvdmVycmlkZVZpc2libGUpIHtcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gbS0xIGJ0bi1kYW5nZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cInN1Ym1pdC5lbWl0KClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW2Rpc2FibGVkXT1cIm92ZXJyaWRlRGlzYWJsZWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW25nYlRvb2x0aXBdPVwiKCdhcnRlbWlzQXBwLmFzc2Vzc21lbnQuYnV0dG9uLmNvbnRyb2wnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSkgKyAnICsgRW50ZXInXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChzdWJtaXRCdXN5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFTcGlubmVyXCIgW3NwaW5dPVwidHJ1ZVwiPiZuYnNwOzwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC5idXR0b24ub3ZlcnJpZGVBc3Nlc3NtZW50XCI+T3ZlcnJpZGUgQXNzZXNzbWVudDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAocmVzdWx0Py5jb21wbGV0aW9uRGF0ZSAmJiBleGVyY2lzZT8uaXNBdExlYXN0SW5zdHJ1Y3RvciAmJiAoZXhlcmNpc2UhLnR5cGUgPT09IEV4ZXJjaXNlVHlwZS5NT0RFTElORyB8fCBleGVyY2lzZSEudHlwZSA9PT0gRXhlcmNpc2VUeXBlLlRFWFQpKSB7XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gbS0xIGJ0bi1wcmltYXJ5XCIgaWQ9XCJ1c2VBc0V4YW1wbGVTdWJtaXNzaW9uXCIgKGNsaWNrKT1cIm9uVXNlQXNFeGFtcGxlU29sdXRpb25DbGlja2VkKClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc3VibWl0QnVzeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhU3Bpbm5lclwiIFtzcGluXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnQuYnV0dG9uLnVzZUFzRXhhbXBsZVN1Ym1pc3Npb25cIj5Vc2UgYXMgRXhhbXBsZSBTdWJtaXNzaW9uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlICNuZXh0U3VibWlzc2lvblNob3J0Y3V0PlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmJ1dHRvbi5jb250cm9sJyB8IGFydGVtaXNUcmFuc2xhdGUgfX0gKyBTaGlmdCArIDxmYS1pY29uIFtpY29uXT1cImZhU3F1YXJlQ2FyZXRSaWdodFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIEBpZiAoYXNzZXNzTmV4dFZpc2libGUpIHtcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gbS0xIGJ0bi1zdWNjZXNzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiYXNzZXNzTmV4dEJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbZGlzYWJsZWRdPVwiYXNzZXNzTmV4dERpc2FibGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJuZXh0U3VibWlzc2lvbi5lbWl0KCk7IHNlbmRBc3Nlc3NOZXh0RXZlbnRUb0FuYWx5dGljcygpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtuZ2JUb29sdGlwXT1cIm5leHRTdWJtaXNzaW9uU2hvcnRjdXRcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKG5leHRTdWJtaXNzaW9uQnVzeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhU3Bpbm5lclwiIFtzcGluXT1cInRydWVcIj4mbmJzcDs8L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnQuYnV0dG9uLm5leHRTdWJtaXNzaW9uXCI+TmV4dCBTdWJtaXNzaW9uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiZXhlcmNpc2VEYXNoYm9hcmRMaW5rXCIgY2xhc3M9XCJidG4gbS0xIGJ0bi1pbmZvXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImVudGl0eS5hY3Rpb24uZXhlcmNpc2VEYXNoYm9hcmRcIj5FeGVyY2lzZSBkYXNoYm9hcmQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbjwvaDM+XG5AaWYgKGV4ZXJjaXNlKSB7XG4gICAgPGpoaS1hc3Nlc3NtZW50LXdhcm5pbmcgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCI+PC9qaGktYXNzZXNzbWVudC13YXJuaW5nPlxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29tcGxhaW50LCBDb21wbGFpbnRUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvbXBsYWludC5tb2RlbCc7XG5cbi8qKlxuICogVGhpcyBzaG93cyBhbiBhbGVydCwgbm90aWZ5aW5nIHRoZSBhc3Nlc3NvciBvbiBwb3NzaWJsZSBjb21wbGFpbnRzIGF0IHRoZSBib3R0b20gb2YgdGhlIHBhZ2UuXG4gKi9cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWFzc2Vzc21lbnQtY29tcGxhaW50LWFsZXJ0JyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXNzZXNzbWVudC1jb21wbGFpbnQtYWxlcnQuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogW10sXG59KVxuZXhwb3J0IGNsYXNzIEFzc2Vzc21lbnRDb21wbGFpbnRBbGVydENvbXBvbmVudCB7XG4gICAgQ29tcGxhaW50VHlwZSA9IENvbXBsYWludFR5cGU7XG5cbiAgICBASW5wdXQoKSBjb21wbGFpbnQ/OiBDb21wbGFpbnQ7XG59XG4iLCJAaWYgKGNvbXBsYWludCkge1xuICAgIEBpZiAoY29tcGxhaW50Py5jb21wbGFpbnRUeXBlID09PSBDb21wbGFpbnRUeXBlLkNPTVBMQUlOVCkge1xuICAgICAgICA8ZGl2IGNsYXNzPVwiYWxlcnQgYWxlcnQtaW5mb1wiPnt7ICdhcnRlbWlzQXBwLmNvbXBsYWludC5oaW50JyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2Rpdj5cbiAgICB9XG4gICAgQGlmIChjb21wbGFpbnQ/LmNvbXBsYWludFR5cGUgPT09IENvbXBsYWludFR5cGUuTU9SRV9GRUVEQkFDSykge1xuICAgICAgICA8ZGl2IGNsYXNzPVwiYWxlcnQgYWxlcnQtaW5mb1wiPnt7ICdhcnRlbWlzQXBwLm1vcmVGZWVkYmFjay5oaW50JyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2Rpdj5cbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSG9zdEJpbmRpbmcsIElucHV0LCBPdXRwdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJlc3VsdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9yZXN1bHQubW9kZWwnO1xuaW1wb3J0IHsgQ29tcGxhaW50LCBDb21wbGFpbnRUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvbXBsYWludC5tb2RlbCc7XG5pbXBvcnQgeyBFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBTdWJtaXNzaW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3N1Ym1pc3Npb24ubW9kZWwnO1xuaW1wb3J0IHsgQXNzZXNzbWVudEFmdGVyQ29tcGxhaW50IH0gZnJvbSAnYXBwL2NvbXBsYWludHMvY29tcGxhaW50cy1mb3ItdHV0b3IvY29tcGxhaW50cy1mb3ItdHV0b3IuY29tcG9uZW50JztcblxuLyoqXG4gKiBUaGUgPGpoaS1hc3Nlc3NtZW50LWxheW91dD4gY29tcG9uZW50IHByb3ZpZGVzIHRoZSBiYXNpYyBsYXlvdXQgZm9yIGFuIGFzc2Vzc21lbnQgcGFnZS5cbiAqIEl0IHNob3dzIHRoZSBoZWFkZXIsIGFsZXJ0cyBmb3IgY29tcGxhaW50cyBvbiB0b3AgYW5kIHRoZSBjb21wbGFpbnQgZm9ybSBhdCB0aGUgYm90dG9tIG9mIHRoZSBwYWdlLlxuICogVGhlIGFjdHVhbCBhc3Nlc3NtZW50IG5lZWRzIHRvIGJlIGluc2VydGVkIHVzaW5nIGNvbnRlbnQgcHJvamVjdGlvbi5cbiAqIENvbXBvbmVudHMgdXNpbmcgdGhpcyBjb21wb25lbnQgbmVlZCB0byBwcm92aWRlIElucHV0cyBhbmQgaGFuZGxlIE91dHB1dHMuIFRoaXMgY29tcG9uZW50IGRvZXMgbm90IHBlcmZvcm0gYXNzZXNzbWVudCBsb2dpYy5cbiAqL1xuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktYXNzZXNzbWVudC1sYXlvdXQnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9hc3Nlc3NtZW50LWxheW91dC5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vYXNzZXNzbWVudC1sYXlvdXQuY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgQXNzZXNzbWVudExheW91dENvbXBvbmVudCB7XG4gICAgQEhvc3RCaW5kaW5nKCdjbGFzcy5hc3Nlc3NtZW50LWNvbnRhaW5lcicpIHJlYWRvbmx5IGFzc2Vzc21lbnRDb250YWluZXJDbGFzcyA9IHRydWU7XG5cbiAgICBAT3V0cHV0KCkgbmF2aWdhdGVCYWNrID0gbmV3IEV2ZW50RW1pdHRlcjx2b2lkPigpO1xuICAgIE1PUkVfRkVFREJBQ0sgPSBDb21wbGFpbnRUeXBlLk1PUkVfRkVFREJBQ0s7XG4gICAgQElucHV0KCkgaXNMb2FkaW5nOiBib29sZWFuO1xuICAgIEBJbnB1dCgpIHNhdmVCdXN5OiBib29sZWFuO1xuICAgIEBJbnB1dCgpIHN1Ym1pdEJ1c3k6IGJvb2xlYW47XG4gICAgQElucHV0KCkgY2FuY2VsQnVzeTogYm9vbGVhbjtcbiAgICBASW5wdXQoKSBuZXh0U3VibWlzc2lvbkJ1c3k6IGJvb2xlYW47XG4gICAgQElucHV0KCkgY29ycmVjdGlvblJvdW5kOiBudW1iZXI7XG5cbiAgICBASW5wdXQoKSBpc1RlYW1Nb2RlOiBib29sZWFuO1xuICAgIEBJbnB1dCgpIGlzQXNzZXNzb3I6IGJvb2xlYW47XG4gICAgQElucHV0KCkgY2FuT3ZlcnJpZGU6IGJvb2xlYW47XG4gICAgQElucHV0KCkgaXNUZXN0UnVuID0gZmFsc2U7XG4gICAgQElucHV0KCkgaXNJbGxlZ2FsU3VibWlzc2lvbjogYm9vbGVhbjtcbiAgICBASW5wdXQoKSBleGVyY2lzZURhc2hib2FyZExpbms6IHN0cmluZ1tdO1xuXG4gICAgQElucHV0KCkgcmVzdWx0PzogUmVzdWx0O1xuICAgIEBJbnB1dCgpIGFzc2Vzc21lbnRzQXJlVmFsaWQ6IGJvb2xlYW47XG4gICAgQElucHV0KCkgY29tcGxhaW50PzogQ29tcGxhaW50O1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlPzogRXhlcmNpc2U7XG4gICAgQElucHV0KCkgc3VibWlzc2lvbj86IFN1Ym1pc3Npb247XG4gICAgQElucHV0KCkgaGFzQXNzZXNzbWVudER1ZURhdGVQYXNzZWQ6IGJvb2xlYW47XG4gICAgQElucHV0KCkgaXNQcm9ncmFtbWluZ0V4ZXJjaXNlOiBib29sZWFuOyAvLyByZW1vdmUgb25jZSBkaWZmIHZpZXcgYWN0aXZhdGVkIGZvciBwcm9ncmFtbWluZyBleGVyY2lzZXNcblxuICAgIHByaXZhdGUgX2hpZ2hsaWdodERpZmZlcmVuY2VzOiBib29sZWFuO1xuXG4gICAgQElucHV0KCkgc2V0IGhpZ2hsaWdodERpZmZlcmVuY2VzKGhpZ2hsaWdodERpZmZlcmVuY2VzOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX2hpZ2hsaWdodERpZmZlcmVuY2VzID0gaGlnaGxpZ2h0RGlmZmVyZW5jZXM7XG4gICAgICAgIHRoaXMuaGlnaGxpZ2h0RGlmZmVyZW5jZXNDaGFuZ2UuZW1pdCh0aGlzLmhpZ2hsaWdodERpZmZlcmVuY2VzKTtcbiAgICB9XG5cbiAgICBnZXQgaGlnaGxpZ2h0RGlmZmVyZW5jZXMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9oaWdobGlnaHREaWZmZXJlbmNlcztcbiAgICB9XG5cbiAgICBAT3V0cHV0KCkgc2F2ZSA9IG5ldyBFdmVudEVtaXR0ZXI8dm9pZD4oKTtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQGFuZ3VsYXItZXNsaW50L25vLW91dHB1dC1uYXRpdmVcbiAgICBAT3V0cHV0KCkgc3VibWl0ID0gbmV3IEV2ZW50RW1pdHRlcjx2b2lkPigpO1xuICAgIEBPdXRwdXQoKSBjYW5jZWwgPSBuZXcgRXZlbnRFbWl0dGVyPHZvaWQ+KCk7XG4gICAgQE91dHB1dCgpIG5leHRTdWJtaXNzaW9uID0gbmV3IEV2ZW50RW1pdHRlcjx2b2lkPigpO1xuICAgIEBPdXRwdXQoKSB1cGRhdGVBc3Nlc3NtZW50QWZ0ZXJDb21wbGFpbnQgPSBuZXcgRXZlbnRFbWl0dGVyPEFzc2Vzc21lbnRBZnRlckNvbXBsYWludD4oKTtcbiAgICBAT3V0cHV0KCkgaGlnaGxpZ2h0RGlmZmVyZW5jZXNDaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPGJvb2xlYW4+KCk7XG4gICAgQE91dHB1dCgpIHVzZUFzRXhhbXBsZVN1Ym1pc3Npb24gPSBuZXcgRXZlbnRFbWl0dGVyPHZvaWQ+KCk7XG59XG4iLCI8amhpLWFzc2Vzc21lbnQtaGVhZGVyXG4gICAgKG5hdmlnYXRlQmFjayk9XCJuYXZpZ2F0ZUJhY2suZW1pdCgpXCJcbiAgICBbaXNMb2FkaW5nXT1cImlzTG9hZGluZ1wiXG4gICAgW3NhdmVCdXN5XT1cInNhdmVCdXN5XCJcbiAgICBbc3VibWl0QnVzeV09XCJzdWJtaXRCdXN5XCJcbiAgICBbY2FuY2VsQnVzeV09XCJjYW5jZWxCdXN5XCJcbiAgICBbbmV4dFN1Ym1pc3Npb25CdXN5XT1cIm5leHRTdWJtaXNzaW9uQnVzeVwiXG4gICAgW2lzVGVhbU1vZGVdPVwiaXNUZWFtTW9kZVwiXG4gICAgW2lzQXNzZXNzb3JdPVwiaXNBc3Nlc3NvclwiXG4gICAgW2lzVGVzdFJ1bl09XCJpc1Rlc3RSdW5cIlxuICAgIFtpc0lsbGVnYWxTdWJtaXNzaW9uXT1cImlzSWxsZWdhbFN1Ym1pc3Npb25cIlxuICAgIFtleGVyY2lzZURhc2hib2FyZExpbmtdPVwiZXhlcmNpc2VEYXNoYm9hcmRMaW5rXCJcbiAgICBbY2FuT3ZlcnJpZGVdPVwiY2FuT3ZlcnJpZGVcIlxuICAgIFthc3Nlc3NtZW50c0FyZVZhbGlkXT1cImFzc2Vzc21lbnRzQXJlVmFsaWRcIlxuICAgIFtoYXNBc3Nlc3NtZW50RHVlRGF0ZVBhc3NlZF09XCJoYXNBc3Nlc3NtZW50RHVlRGF0ZVBhc3NlZFwiXG4gICAgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCJcbiAgICBbcmVzdWx0XT1cInJlc3VsdFwiXG4gICAgW2NvcnJlY3Rpb25Sb3VuZF09XCJjb3JyZWN0aW9uUm91bmRcIlxuICAgIFtpc1Byb2dyYW1taW5nRXhlcmNpc2VdPVwiaXNQcm9ncmFtbWluZ0V4ZXJjaXNlXCJcbiAgICAoc2F2ZSk9XCJzYXZlLmVtaXQoKVwiXG4gICAgKHN1Ym1pdCk9XCJzdWJtaXQuZW1pdCgpXCJcbiAgICAoY2FuY2VsKT1cImNhbmNlbC5lbWl0KClcIlxuICAgIFsoaGlnaGxpZ2h0RGlmZmVyZW5jZXMpXT1cImhpZ2hsaWdodERpZmZlcmVuY2VzXCJcbiAgICAobmV4dFN1Ym1pc3Npb24pPVwibmV4dFN1Ym1pc3Npb24uZW1pdCgpXCJcbiAgICBbaGFzQ29tcGxhaW50XT1cIiEhY29tcGxhaW50XCJcbiAgICBbaGFzTW9yZUZlZWRiYWNrUmVxdWVzdF09XCJjb21wbGFpbnQ/LmNvbXBsYWludFR5cGUgPT09IE1PUkVfRkVFREJBQ0tcIlxuICAgIFtjb21wbGFpbnRIYW5kbGVkXT1cIiEhY29tcGxhaW50ID8gY29tcGxhaW50LmFjY2VwdGVkICE9PSB1bmRlZmluZWQgOiBmYWxzZVwiXG4gICAgW2NvbXBsYWludFR5cGVdPVwiY29tcGxhaW50Py5jb21wbGFpbnRUeXBlXCJcbiAgICAodXNlQXNFeGFtcGxlU3VibWlzc2lvbik9XCJ1c2VBc0V4YW1wbGVTdWJtaXNzaW9uLmVtaXQoKVwiXG4+PC9qaGktYXNzZXNzbWVudC1oZWFkZXI+XG48amhpLWFzc2Vzc21lbnQtY29tcGxhaW50LWFsZXJ0IFtjb21wbGFpbnRdPVwiY29tcGxhaW50XCI+PC9qaGktYXNzZXNzbWVudC1jb21wbGFpbnQtYWxlcnQ+XG48bmctY29udGVudD48L25nLWNvbnRlbnQ+XG5AaWYgKGNvbXBsYWludCkge1xuICAgIDxqaGktY29tcGxhaW50cy1mb3ItdHV0b3ItZm9ybVxuICAgICAgICBjbGFzcz1cInJvdyBtdC00XCJcbiAgICAgICAgW3plcm9JbmRlbnRdPVwiZmFsc2VcIlxuICAgICAgICBbY29tcGxhaW50XT1cImNvbXBsYWludCFcIlxuICAgICAgICBbZXhlcmNpc2VdPVwiZXhlcmNpc2VcIlxuICAgICAgICBbaXNBc3Nlc3Nvcl09XCJpc0Fzc2Vzc29yXCJcbiAgICAgICAgW3N1Ym1pc3Npb25dPVwic3VibWlzc2lvblwiXG4gICAgICAgIFtpc1Rlc3RSdW5dPVwiaXNUZXN0UnVuXCJcbiAgICAgICAgKHVwZGF0ZUFzc2Vzc21lbnRBZnRlckNvbXBsYWludCk9XCJ1cGRhdGVBc3Nlc3NtZW50QWZ0ZXJDb21wbGFpbnQuZW1pdCgkZXZlbnQpXCJcbiAgICA+PC9qaGktY29tcGxhaW50cy1mb3ItdHV0b3ItZm9ybT5cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgcm91bmRTY29yZVBlcmNlbnRTcGVjaWZpZWRCeUNvdXJzZVNldHRpbmdzLCByb3VuZFZhbHVlU3BlY2lmaWVkQnlDb3Vyc2VTZXR0aW5ncyB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC91dGlscyc7XG5pbXBvcnQgeyBDb3Vyc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvY291cnNlLm1vZGVsJztcbmltcG9ydCB7IGZhUXVlc3Rpb25DaXJjbGUgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1zY29yZS1kaXNwbGF5JyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vc2NvcmUtZGlzcGxheS5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vc2NvcmUtZGlzcGxheS5jb21wb25lbnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBTY29yZURpc3BsYXlDb21wb25lbnQgaW1wbGVtZW50cyBPbkNoYW5nZXMge1xuICAgIEBJbnB1dCgpIG1heEJvbnVzUG9pbnRzID0gMDtcbiAgICBASW5wdXQoKSBtYXhQb2ludHM6IG51bWJlcjtcbiAgICBASW5wdXQoKSBzY29yZTogbnVtYmVyO1xuICAgIEBJbnB1dCgpIGNvdXJzZT86IENvdXJzZTtcbiAgICBib251c1BvaW50cz86IG51bWJlcjtcbiAgICBtYXhQb2ludHNXaXRoQm9udXM/OiBudW1iZXI7XG4gICAgbWF4UGVyY2VudGFnZT86IG51bWJlcjtcblxuICAgIC8vIEljb25zXG4gICAgZmFRdWVzdGlvbkNpcmNsZSA9IGZhUXVlc3Rpb25DaXJjbGU7XG5cbiAgICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgICAvKipcbiAgICAgKiBDYWxjdWxhdGUgdGhlIGJvbnVzIHBvaW50cyBqdXN0IGZvciBkaXNwbGF5IHJlYXNvbnNcbiAgICAgKi9cbiAgICBuZ09uQ2hhbmdlcygpIHtcbiAgICAgICAgaWYgKHRoaXMubWF4UG9pbnRzICE9IHVuZGVmaW5lZCAmJiB0aGlzLm1heEJvbnVzUG9pbnRzID4gMCkge1xuICAgICAgICAgICAgaWYgKHRoaXMuc2NvcmUgPiB0aGlzLm1heFBvaW50cykge1xuICAgICAgICAgICAgICAgIHRoaXMuYm9udXNQb2ludHMgPSByb3VuZFZhbHVlU3BlY2lmaWVkQnlDb3Vyc2VTZXR0aW5ncyh0aGlzLnNjb3JlIC0gdGhpcy5tYXhQb2ludHMsIHRoaXMuY291cnNlKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5ib251c1BvaW50cyA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMubWF4UG9pbnRzV2l0aEJvbnVzID0gdGhpcy5tYXhQb2ludHMgKyB0aGlzLm1heEJvbnVzUG9pbnRzO1xuICAgICAgICAgICAgdGhpcy5tYXhQZXJjZW50YWdlID0gcm91bmRTY29yZVBlcmNlbnRTcGVjaWZpZWRCeUNvdXJzZVNldHRpbmdzKHRoaXMubWF4UG9pbnRzV2l0aEJvbnVzIC8gdGhpcy5tYXhQb2ludHMsIHRoaXMuY291cnNlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuYm9udXNQb2ludHMgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICB0aGlzLm1heFBvaW50c1dpdGhCb251cyA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIHRoaXMubWF4UGVyY2VudGFnZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNjb3JlID0gcm91bmRWYWx1ZVNwZWNpZmllZEJ5Q291cnNlU2V0dGluZ3ModGhpcy5zY29yZSwgdGhpcy5jb3Vyc2UpO1xuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJkaXNwbGF5LWNvbnRhaW5lclwiPlxuICAgIDxzcGFuPnt7IHNjb3JlIHx8IDAgfX0mbmJzcDs8L3NwYW4+XG4gICAgQGlmIChtYXhQb2ludHMpIHtcbiAgICAgICAgPHNwYW4+LyZuYnNwO3t7IG1heFBvaW50cyB9fSZuYnNwOzwvc3Bhbj5cbiAgICB9XG4gICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5tb2RlbGluZ0Fzc2Vzc21lbnQucG9pbnRzXCI+UG9pbnRzJm5ic3A7PC9zcGFuPlxuICAgIEBpZiAoYm9udXNQb2ludHMpIHtcbiAgICAgICAgPHNwYW4+KEJvbnVzOiZuYnNwO3t7IGJvbnVzUG9pbnRzIH19KSZuYnNwOzwvc3Bhbj5cbiAgICB9XG4gICAgQGlmIChtYXhCb251c1BvaW50cykge1xuICAgICAgICA8ZmEtaWNvblxuICAgICAgICAgICAgW2ljb25dPVwiZmFRdWVzdGlvbkNpcmNsZVwiXG4gICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b20gYXV0b1wiXG4gICAgICAgICAgICBuZ2JUb29sdGlwPVwie3tcbiAgICAgICAgICAgICAgICAnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmRhc2hib2FyZC5ib251c1BvaW50RXhwbGFuYXRpb24nXG4gICAgICAgICAgICAgICAgICAgIHwgYXJ0ZW1pc1RyYW5zbGF0ZTogeyBtYXhQb2ludHM6IG1heFBvaW50cywgbWF4Qm9udXNQb2ludHM6IG1heEJvbnVzUG9pbnRzLCBtYXhQb2ludHNXaXRoQm9udXM6IG1heFBvaW50c1dpdGhCb251cywgbWF4UGVyY2VudGFnZTogbWF4UGVyY2VudGFnZSB9XG4gICAgICAgICAgICB9fVwiXG4gICAgICAgID5cbiAgICAgICAgPC9mYS1pY29uPlxuICAgIH1cbjwvZGl2PlxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRmVlZGJhY2sgfSBmcm9tICdhcHAvZW50aXRpZXMvZmVlZGJhY2subW9kZWwnO1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIFN0cnVjdHVyZWRHcmFkaW5nQ3JpdGVyaW9uU2VydmljZSB7XG4gICAgLyoqXG4gICAgICogQ29ubmVjdHMgdGhlIHN0cnVjdHVyZWQgZ3JhZGluZyBpbnN0cnVjdGlvbnMgd2l0aCB0aGUgZmVlZGJhY2sgb2YgYSBzdWJtaXNzaW9uIGVsZW1lbnRcbiAgICAgKiBAcGFyYW0ge0V2ZW50fSBldmVudCAtIFRoZSBkcm9wIGV2ZW50XG4gICAgICogQHBhcmFtIHtGZWVkYmFja30gZmVlZGJhY2sgLSBUaGUgZmVlZGJhY2sgb2YgdGhlIGFzc2Vzc21lbnQgdG8gYmUgdXBkYXRlZFxuICAgICAqIHRoZSBTR0kgZWxlbWVudCBzZW50IG9uIGRyYWcgaW4gcHJvY2Vzc2VkIGluIHRoaXMgbWV0aG9kXG4gICAgICogdGhlIGNvcnJlc3BvbmRpbmcgZHJhZyBtZXRob2QgaXMgaW4gU3RydWN0dXJlZEdyYWRpbmdJbnN0cnVjdGlvbnNBc3Nlc3NtZW50TGF5b3V0Q29tcG9uZW50XG4gICAgICovXG4gICAgdXBkYXRlRmVlZGJhY2tXaXRoU3RydWN0dXJlZEdyYWRpbmdJbnN0cnVjdGlvbkV2ZW50KGZlZWRiYWNrOiBGZWVkYmFjaywgZXZlbnQ6IGFueSkge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgZGF0YSA9IGV2ZW50LmRhdGFUcmFuc2Zlci5nZXREYXRhKCd0ZXh0L3BsYWluJyk7XG4gICAgICAgICAgICBjb25zdCBpbnN0cnVjdGlvbiA9IEpTT04ucGFyc2UoZGF0YSk7XG4gICAgICAgICAgICBmZWVkYmFjay5ncmFkaW5nSW5zdHJ1Y3Rpb24gPSBpbnN0cnVjdGlvbjtcbiAgICAgICAgICAgIGZlZWRiYWNrLmNyZWRpdHMgPSBpbnN0cnVjdGlvbi5jcmVkaXRzO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIC8vIFJldGhyb3cgYW55IG5vbiBzeW50YXggZXJyb3IuIHN5bnRheCBlcnJvcnMgYXJlIGNhdXNlZCBieSBpbnZhbGlkIEpTT04gaWYgc29tZW9uZSBkcm9wcyBzb21ldGhpbmcgdW5yZWxhdGVkLCBpZ25vcmUgdGhlbVxuICAgICAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgU3ludGF4RXJyb3IpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGNvbXB1dGVUb3RhbFNjb3JlKGFzc2Vzc21lbnRzOiBGZWVkYmFja1tdKSB7XG4gICAgICAgIGxldCBzY29yZSA9IDA7XG4gICAgICAgIGNvbnN0IGdyYWRpbmdJbnN0cnVjdGlvbnMgPSB7fTsgLy8geyBpbnN0cnVjdGlvbklkOiBub09mRW5jb3VudGVycyB9XG4gICAgICAgIGZvciAoY29uc3QgZmVlZGJhY2sgb2YgYXNzZXNzbWVudHMpIHtcbiAgICAgICAgICAgIGlmIChmZWVkYmFjay5ncmFkaW5nSW5zdHJ1Y3Rpb24pIHtcbiAgICAgICAgICAgICAgICBzY29yZSA9IHRoaXMuY2FsY3VsYXRlU2NvcmVGb3JHcmFkaW5nSW5zdHJ1Y3Rpb25zKGZlZWRiYWNrLCBzY29yZSwgZ3JhZGluZ0luc3RydWN0aW9ucyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHNjb3JlICs9IGZlZWRiYWNrLmNyZWRpdHMhO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzY29yZTtcbiAgICB9XG5cbiAgICBjYWxjdWxhdGVTY29yZUZvckdyYWRpbmdJbnN0cnVjdGlvbnMoZmVlZGJhY2s6IEZlZWRiYWNrLCBzY29yZTogbnVtYmVyLCBncmFkaW5nSW5zdHJ1Y3Rpb25zOiBhbnkpOiBudW1iZXIge1xuICAgICAgICBpZiAoZ3JhZGluZ0luc3RydWN0aW9uc1tmZWVkYmFjay5ncmFkaW5nSW5zdHJ1Y3Rpb24hLmlkIV0pIHtcbiAgICAgICAgICAgIC8vIFdlIEVuY291bnRlcmVkIHRoaXMgZ3JhZGluZyBpbnN0cnVjdGlvbiBiZWZvcmVcbiAgICAgICAgICAgIGNvbnN0IG1heENvdW50ID0gZmVlZGJhY2suZ3JhZGluZ0luc3RydWN0aW9uIS51c2FnZUNvdW50O1xuICAgICAgICAgICAgY29uc3QgZW5jb3VudGVycyA9IGdyYWRpbmdJbnN0cnVjdGlvbnNbZmVlZGJhY2suZ3JhZGluZ0luc3RydWN0aW9uIS5pZCFdO1xuICAgICAgICAgICAgaWYgKG1heENvdW50ICYmIG1heENvdW50ID4gMCkge1xuICAgICAgICAgICAgICAgIGlmIChlbmNvdW50ZXJzID49IG1heENvdW50KSB7XG4gICAgICAgICAgICAgICAgICAgIGdyYWRpbmdJbnN0cnVjdGlvbnNbZmVlZGJhY2suZ3JhZGluZ0luc3RydWN0aW9uIS5pZCFdID0gZW5jb3VudGVycyArIDE7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZ3JhZGluZ0luc3RydWN0aW9uc1tmZWVkYmFjay5ncmFkaW5nSW5zdHJ1Y3Rpb24hLmlkIV0gPSBlbmNvdW50ZXJzICsgMTtcbiAgICAgICAgICAgICAgICAgICAgc2NvcmUgKz0gZmVlZGJhY2suZ3JhZGluZ0luc3RydWN0aW9uIS5jcmVkaXRzO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgc2NvcmUgKz0gZmVlZGJhY2suY3JlZGl0cyE7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBGaXJzdCB0aW1lIGVuY291bnRlcmluZyB0aGUgZ3JhZGluZyBpbnN0cnVjdGlvblxuICAgICAgICAgICAgZ3JhZGluZ0luc3RydWN0aW9uc1tmZWVkYmFjay5ncmFkaW5nSW5zdHJ1Y3Rpb24hLmlkIV0gPSAxO1xuICAgICAgICAgICAgc2NvcmUgKz0gZmVlZGJhY2suY3JlZGl0cyE7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHNjb3JlO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZlZWRiYWNrIH0gZnJvbSAnYXBwL2VudGl0aWVzL2ZlZWRiYWNrLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktYXNzZXNzbWVudC1jb3JyZWN0aW9uLXJvdW5kLWJhZGdlJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXNzZXNzbWVudC1jb3JyZWN0aW9uLXJvdW5kLWJhZGdlLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9hc3Nlc3NtZW50LWNvcnJlY3Rpb24tcm91bmQtYmFkZ2UuY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgQXNzZXNzbWVudENvcnJlY3Rpb25Sb3VuZEJhZGdlQ29tcG9uZW50IHtcbiAgICBASW5wdXQoKSBmZWVkYmFjazogRmVlZGJhY2s7XG4gICAgQElucHV0KCkgaGlnaGxpZ2h0RGlmZmVyZW5jZXMgPSBmYWxzZTtcbn1cbiIsIjxkaXY+XG4gICAgPCEtLSBjb3JyZWN0aW9uIHJvdW5kIGxhYmVsLS0+XG4gICAgQGlmIChoaWdobGlnaHREaWZmZXJlbmNlcyAmJiBmZWVkYmFjay5jb3BpZWRGZWVkYmFja0lkKSB7XG4gICAgICAgIDxoNSBjbGFzcz1cImNvcnJlY3Rpb24tbGFiZWxcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgdGV4dC13aGl0ZSBtZS0xXCIgW25nU3R5bGVdPVwieyBiYWNrZ3JvdW5kQ29sb3I6ICcjM2U4YWNjJyB9XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmRpZmZWaWV3LmNvcnJlY3Rpb25Sb3VuZERpZmZGaXJzdFwiXG4gICAgICAgICAgICAgICAgPkZpcnN0IGNvcnJlY3Rpb24gcm91bmQ8L3NwYW5cbiAgICAgICAgICAgID5cbiAgICAgICAgPC9oNT5cbiAgICB9XG4gICAgQGlmIChoaWdobGlnaHREaWZmZXJlbmNlcyAmJiAhZmVlZGJhY2suY29waWVkRmVlZGJhY2tJZCkge1xuICAgICAgICA8aDUgY2xhc3M9XCJjb3JyZWN0aW9uLWxhYmVsXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIHRleHQtd2hpdGUgbWUtMVwiIFtuZ1N0eWxlXT1cInsgYmFja2dyb3VuZENvbG9yOiAnI2ZmYTU2MScgfVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC5kaWZmVmlldy5jb3JyZWN0aW9uUm91bmREaWZmU2Vjb25kXCJcbiAgICAgICAgICAgICAgICA+U2Vjb25kIGNvcnJlY3Rpb24gcm91bmQ8L3NwYW5cbiAgICAgICAgICAgID5cbiAgICAgICAgPC9oNT5cbiAgICB9XG48L2Rpdj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBmYUNoZWNrLCBmYUV4Y2xhbWF0aW9uLCBmYUV4Y2xhbWF0aW9uVHJpYW5nbGUsIGZhUXVlc3Rpb25DaXJjbGUsIGZhVHJhc2gsIGZhVHJhc2hBbHQgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgRmVlZGJhY2ssIEZlZWRiYWNrVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9mZWVkYmFjay5tb2RlbCc7XG5pbXBvcnQgeyBTdHJ1Y3R1cmVkR3JhZGluZ0NyaXRlcmlvblNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9zdHJ1Y3R1cmVkLWdyYWRpbmctY3JpdGVyaW9uL3N0cnVjdHVyZWQtZ3JhZGluZy1jcml0ZXJpb24uc2VydmljZSc7XG5pbXBvcnQgeyBCdXR0b25TaXplIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL2J1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS11bnJlZmVyZW5jZWQtZmVlZGJhY2stZGV0YWlsJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vdW5yZWZlcmVuY2VkLWZlZWRiYWNrLWRldGFpbC5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vdW5yZWZlcmVuY2VkLWZlZWRiYWNrLWRldGFpbC5jb21wb25lbnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBVbnJlZmVyZW5jZWRGZWVkYmFja0RldGFpbENvbXBvbmVudCB7XG4gICAgQElucHV0KCkgcHVibGljIGZlZWRiYWNrOiBGZWVkYmFjaztcbiAgICBASW5wdXQoKSBpc1N1Z2dlc3Rpb246IGJvb2xlYW47XG4gICAgQElucHV0KCkgcHVibGljIHJlYWRPbmx5OiBib29sZWFuO1xuICAgIEBJbnB1dCgpIGhpZ2hsaWdodERpZmZlcmVuY2VzOiBib29sZWFuO1xuICAgIEBJbnB1dCgpIHVzZURlZmF1bHRGZWVkYmFja1N1Z2dlc3Rpb25CYWRnZVRleHQ6IGJvb2xlYW47XG5cbiAgICBAT3V0cHV0KCkgcHVibGljIG9uRmVlZGJhY2tDaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPEZlZWRiYWNrPigpO1xuICAgIEBPdXRwdXQoKSBwdWJsaWMgb25GZWVkYmFja0RlbGV0ZSA9IG5ldyBFdmVudEVtaXR0ZXI8RmVlZGJhY2s+KCk7XG4gICAgQE91dHB1dCgpIG9uQWNjZXB0U3VnZ2VzdGlvbiA9IG5ldyBFdmVudEVtaXR0ZXI8RmVlZGJhY2s+KCk7XG4gICAgQE91dHB1dCgpIG9uRGlzY2FyZFN1Z2dlc3Rpb24gPSBuZXcgRXZlbnRFbWl0dGVyPEZlZWRiYWNrPigpO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYVRyYXNoQWx0ID0gZmFUcmFzaEFsdDtcbiAgICBmYVF1ZXN0aW9uQ2lyY2xlID0gZmFRdWVzdGlvbkNpcmNsZTtcbiAgICBmYUV4Y2xhbWF0aW9uID0gZmFFeGNsYW1hdGlvbjtcbiAgICBmYUV4Y2xhbWF0aW9uVHJpYW5nbGUgPSBmYUV4Y2xhbWF0aW9uVHJpYW5nbGU7XG4gICAgZmFDaGVjayA9IGZhQ2hlY2s7XG4gICAgZmFUcmFzaCA9IGZhVHJhc2g7XG5cbiAgICAvLyBFeHBvc2UgdG8gdGVtcGxhdGVcbiAgICBwcm90ZWN0ZWQgcmVhZG9ubHkgRmVlZGJhY2sgPSBGZWVkYmFjaztcbiAgICByZWFkb25seSBCdXR0b25TaXplID0gQnV0dG9uU2l6ZTtcblxuICAgIHByaXZhdGUgZGlhbG9nRXJyb3JTb3VyY2UgPSBuZXcgU3ViamVjdDxzdHJpbmc+KCk7XG4gICAgZGlhbG9nRXJyb3IkID0gdGhpcy5kaWFsb2dFcnJvclNvdXJjZS5hc09ic2VydmFibGUoKTtcblxuICAgIGNvbnN0cnVjdG9yKHB1YmxpYyBzdHJ1Y3R1cmVkR3JhZGluZ0NyaXRlcmlvblNlcnZpY2U6IFN0cnVjdHVyZWRHcmFkaW5nQ3JpdGVyaW9uU2VydmljZSkge31cblxuICAgIC8qKlxuICAgICAqIEVtaXRzIGFzc2Vzc21lbnQgY2hhbmdlcyB0byBwYXJlbnQgY29tcG9uZW50XG4gICAgICovXG4gICAgcHVibGljIGVtaXRDaGFuZ2VzKCk6IHZvaWQge1xuICAgICAgICBpZiAodGhpcy5mZWVkYmFjay50eXBlID09PSBGZWVkYmFja1R5cGUuQVVUT01BVElDKSB7XG4gICAgICAgICAgICB0aGlzLmZlZWRiYWNrLnR5cGUgPSBGZWVkYmFja1R5cGUuQVVUT01BVElDX0FEQVBURUQ7XG4gICAgICAgIH1cbiAgICAgICAgRmVlZGJhY2sudXBkYXRlRmVlZGJhY2tUeXBlT25DaGFuZ2UodGhpcy5mZWVkYmFjayk7XG4gICAgICAgIHRoaXMub25GZWVkYmFja0NoYW5nZS5lbWl0KHRoaXMuZmVlZGJhY2spO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEVtaXRzIHRoZSBkZWxldGlvbiBvZiBhIGZlZWRiYWNrXG4gICAgICovXG4gICAgcHVibGljIGRlbGV0ZSgpIHtcbiAgICAgICAgdGhpcy5vbkZlZWRiYWNrRGVsZXRlLmVtaXQodGhpcy5mZWVkYmFjayk7XG4gICAgICAgIHRoaXMuZGlhbG9nRXJyb3JTb3VyY2UubmV4dCgnJyk7XG4gICAgfVxuXG4gICAgdXBkYXRlRmVlZGJhY2tPbkRyb3AoZXZlbnQ6IEV2ZW50KSB7XG4gICAgICAgIHRoaXMuc3RydWN0dXJlZEdyYWRpbmdDcml0ZXJpb25TZXJ2aWNlLnVwZGF0ZUZlZWRiYWNrV2l0aFN0cnVjdHVyZWRHcmFkaW5nSW5zdHJ1Y3Rpb25FdmVudCh0aGlzLmZlZWRiYWNrLCBldmVudCk7XG4gICAgICAgIHRoaXMub25GZWVkYmFja0NoYW5nZS5lbWl0KHRoaXMuZmVlZGJhY2spO1xuICAgIH1cbn1cbiIsIjxkaXYgKGRyb3ApPVwidXBkYXRlRmVlZGJhY2tPbkRyb3AoJGV2ZW50KVwiIChkcmFnb3Zlcik9XCIkZXZlbnQucHJldmVudERlZmF1bHQoKVwiIGNsYXNzPVwidW5yZWZlcmVuY2VkLWZlZWRiYWNrLWRldGFpbCBjYXJkIG1iLTNcIiBbY2xhc3MuaXMtc3VnZ2VzdGlvbl09XCJpc1N1Z2dlc3Rpb25cIj5cbiAgICA8ZGl2IGNsYXNzPVwiY2FyZC1oZWFkZXJcIj5cbiAgICAgICAgQGlmIChpc1N1Z2dlc3Rpb24gfHwgRmVlZGJhY2suaXNGZWVkYmFja1N1Z2dlc3Rpb24oZmVlZGJhY2spKSB7XG4gICAgICAgICAgICA8amhpLWZlZWRiYWNrLXN1Z2dlc3Rpb24tYmFkZ2UgW2ZlZWRiYWNrXT1cImZlZWRiYWNrXCIgW3VzZURlZmF1bHRUZXh0XT1cInVzZURlZmF1bHRGZWVkYmFja1N1Z2dlc3Rpb25CYWRnZVRleHRcIj48L2poaS1mZWVkYmFjay1zdWdnZXN0aW9uLWJhZGdlPlxuICAgICAgICB9XG4gICAgICAgIEBpZiAoZmVlZGJhY2suZ3JhZGluZ0luc3RydWN0aW9uKSB7XG4gICAgICAgICAgICA8amhpLWdyYWRpbmctaW5zdHJ1Y3Rpb24tbGluay1pY29uIFtmZWVkYmFja109XCJmZWVkYmFja1wiPjwvamhpLWdyYWRpbmctaW5zdHJ1Y3Rpb24tbGluay1pY29uPlxuICAgICAgICB9XG4gICAgICAgIEBpZiAoIXJlYWRPbmx5KSB7XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgamhpRGVsZXRlQnV0dG9uXG4gICAgICAgICAgICAgICAgW2J1dHRvblNpemVdPVwiQnV0dG9uU2l6ZS5TTUFMTFwiXG4gICAgICAgICAgICAgICAgW3RyYW5zbGF0ZVZhbHVlc109XCJ7IHRleHQ6IGZlZWRiYWNrLmRldGFpbFRleHQgfVwiXG4gICAgICAgICAgICAgICAgZGVsZXRlUXVlc3Rpb249XCJhcnRlbWlzQXBwLmZlZWRiYWNrLmRlbGV0ZS5xdWVzdGlvblwiXG4gICAgICAgICAgICAgICAgKGRlbGV0ZSk9XCJkZWxldGUoKVwiXG4gICAgICAgICAgICAgICAgW2RpYWxvZ0Vycm9yXT1cImRpYWxvZ0Vycm9yJFwiXG4gICAgICAgICAgICAgICAgW3JlbmRlckJ1dHRvblN0eWxlXT1cImZhbHNlXCJcbiAgICAgICAgICAgICAgICBbcmVuZGVyQnV0dG9uVGV4dF09XCJmYWxzZVwiXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gZmxvYXQtZW5kXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVRyYXNoQWx0XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIH1cbiAgICAgICAgPCEtLSBBY2NlcHQvRGlzY2FyZCBmb3IgZmVlZGJhY2sgc3VnZ2VzdGlvbnMgLS0+XG4gICAgICAgIEBpZiAoaXNTdWdnZXN0aW9uKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93IGZsb2F0LWVuZCBzdWdnZXN0aW9uLWFjdGlvbi1idXR0b25zXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc3VjY2VzcyBtLTEgYnRuLXNtXCIgKGNsaWNrKT1cIm9uQWNjZXB0U3VnZ2VzdGlvbi5lbWl0KGZlZWRiYWNrKVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUNoZWNrXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnQuZGV0YWlsLmFjY2VwdFwiPkFjY2VwdDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1kYW5nZXIgbS0xIGJ0bi1zbVwiIChjbGljayk9XCJvbkRpc2NhcmRTdWdnZXN0aW9uLmVtaXQoZmVlZGJhY2spXCI+XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhVHJhc2hcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC5kZXRhaWwuZGlzY2FyZFwiPkRpc2NhcmQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJjYXJkLWJvZHlcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXAgcm93XCI+XG4gICAgICAgICAgICA8bGFiZWwgZm9yPVwiZmVlZGJhY2stcG9pbnRzXCIgY2xhc3M9XCJjb2wtNCBmZWVkYmFjay1sYWJlbFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZXhlcmNpc2Uuc2NvcmVcIj48L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgaWQ9XCJmZWVkYmFjay1wb2ludHNcIlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiY29sIGZvcm0tY29udHJvbFwiXG4gICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgc3RlcD1cIjAuNVwiXG4gICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJmZWVkYmFjay5jcmVkaXRzXCJcbiAgICAgICAgICAgICAgICAobmdNb2RlbENoYW5nZSk9XCJlbWl0Q2hhbmdlcygpXCJcbiAgICAgICAgICAgICAgICBbcmVhZE9ubHldPVwiZmVlZGJhY2suZ3JhZGluZ0luc3RydWN0aW9uIHx8IHJlYWRPbmx5XCJcbiAgICAgICAgICAgICAgICBbZGlzYWJsZWRdPVwicmVhZE9ubHlcIlxuICAgICAgICAgICAgICAgIFtyZXF1aXJlZF09XCIhZmVlZGJhY2suZ3JhZGluZ0luc3RydWN0aW9uXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cCByb3dcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtNCBhc3Nlc3NtZW50LWxhYmVsXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwicGUtMFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC5kZXRhaWwuZmVlZGJhY2tcIj48L2xhYmVsPlxuICAgICAgICAgICAgICAgIEBpZiAoZmVlZGJhY2suZ3JhZGluZ0luc3RydWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVF1ZXN0aW9uQ2lyY2xlXCIgY2xhc3M9XCJ0ZXh0LXNlY29uZGFyeSBwcy0xXCIgW25nYlRvb2x0aXBdPVwiJ2FydGVtaXNBcHAuYXNzZXNzbWVudC5mZWVkYmFja0hpbnQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sIHAtMFwiPlxuICAgICAgICAgICAgICAgIEBpZiAoZmVlZGJhY2suZ3JhZGluZ0luc3RydWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyBmZWVkYmFjay5ncmFkaW5nSW5zdHJ1Y3Rpb24hLmZlZWRiYWNrIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZmVlZGJhY2stdGV4dGFyZWFcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiXG4gICAgICAgICAgICAgICAgICAgIHJvd3M9XCIyXCJcbiAgICAgICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJmZWVkYmFjay5kZXRhaWxUZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgKG5nTW9kZWxDaGFuZ2UpPVwiZW1pdENoYW5nZXMoKVwiXG4gICAgICAgICAgICAgICAgICAgIFtyZWFkT25seV09XCJyZWFkT25seVwiXG4gICAgICAgICAgICAgICAgICAgIFtkaXNhYmxlZF09XCJyZWFkT25seVwiXG4gICAgICAgICAgICAgICAgICAgIFtwbGFjZWhvbGRlcl09XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrLmdyYWRpbmdJbnN0cnVjdGlvbj8uZmVlZGJhY2tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICgnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmFkZGl0aW9uYWxGZWVkYmFja0NvbW1lbnRQbGFjZWhvbGRlcicgfCBhcnRlbWlzVHJhbnNsYXRlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogKCdhcnRlbWlzQXBwLmFzc2Vzc21lbnQuZmVlZGJhY2tDb21tZW50UGxhY2Vob2xkZXInIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcbiAgICAgICAgICAgICAgICAgICAgXCJcbiAgICAgICAgICAgICAgICAgICAgW3JlcXVpcmVkXT1cIiFmZWVkYmFjay5ncmFkaW5nSW5zdHJ1Y3Rpb24/LmZlZWRiYWNrXCJcbiAgICAgICAgICAgICAgICA+PC90ZXh0YXJlYT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPCEtLSBUZXh0IHNob3dpbmcgd2hldGhlciB0aGUgdHV0b3IgZmVlZGJhY2sgaXMgY29ycmVjdCBvciBub3QgKHVwb24gdmFsaWRhdGlvbiBvbiB0aGUgc2VydmVyKSAtLT5cbiAgICAgICAgQGlmIChmZWVkYmFjay5jb3JyZWN0aW9uU3RhdHVzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgQGlmIChmZWVkYmFjay5jb3JyZWN0aW9uU3RhdHVzID09PSAnQ09SUkVDVCcpIHtcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXN1Y2Nlc3NcIj57eyAnYXJ0ZW1pc0FwcC5leGFtcGxlU3VibWlzc2lvbi5mZWVkYmFjay4nICsgZmVlZGJhY2suY29ycmVjdGlvblN0YXR1cyEgfCBhcnRlbWlzVHJhbnNsYXRlIH19IDwvc3Bhbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmIChmZWVkYmFjay5jb3JyZWN0aW9uU3RhdHVzICE9PSAnQ09SUkVDVCcpIHtcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LWRhbmdlclwiPnt7ICdhcnRlbWlzQXBwLmV4YW1wbGVTdWJtaXNzaW9uLmZlZWRiYWNrLicgKyBmZWVkYmFjay5jb3JyZWN0aW9uU3RhdHVzISB8IGFydGVtaXNUcmFuc2xhdGUgfX0gPC9zcGFuPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8IS0tIDp3YXJuaW5nOiBlbW9qaSB3YXMgcmVuZGVyZWQgYXMgYSBibGFjay13aGl0ZSBnbHlwaCwgaGVuY2UgdGhlIHNvbHV0aW9uIHdpdGggdGhlIGZhLWljb24gLS0+XG4gICAgICAgICAgICAgICAgQGlmIChmZWVkYmFjay5jb3JyZWN0aW9uU3RhdHVzICE9PSAnQ09SUkVDVCcpIHtcbiAgICAgICAgICAgICAgICAgICAgPGZhLWxheWVycz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIGNsYXNzPVwidGV4dC13YXJuaW5nXCIgW2ljb25dPVwiZmFFeGNsYW1hdGlvblRyaWFuZ2xlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gY2xhc3M9XCJ0ZXh0LWRhcmsgZXhjbGFtYXRpb24taWNvblwiIFtpY29uXT1cImZhRXhjbGFtYXRpb25cIiBzaXplPVwiMnhcIiB0cmFuc2Zvcm09XCJzaHJpbmstMTBcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDwvZmEtbGF5ZXJzPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICAgIDxqaGktYXNzZXNzbWVudC1jb3JyZWN0aW9uLXJvdW5kLWJhZGdlIFtmZWVkYmFja109XCJmZWVkYmFja1wiIFtoaWdobGlnaHREaWZmZXJlbmNlc109XCJoaWdobGlnaHREaWZmZXJlbmNlc1wiPjwvamhpLWFzc2Vzc21lbnQtY29ycmVjdGlvbi1yb3VuZC1iYWRnZT5cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cFBhcmFtcywgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgQ29tcGxhaW50UmVzcG9uc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvY29tcGxhaW50LXJlc3BvbnNlLm1vZGVsJztcbmltcG9ydCB7IEZlZWRiYWNrIH0gZnJvbSAnYXBwL2VudGl0aWVzL2ZlZWRiYWNrLm1vZGVsJztcbmltcG9ydCB7IFJlc3VsdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9yZXN1bHQubW9kZWwnO1xuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgY29udmVydERhdGVGcm9tU2VydmVyIH0gZnJvbSAnYXBwL3V0aWxzL2RhdGUudXRpbHMnO1xuXG5leHBvcnQgdHlwZSBFbnRpdHlSZXNwb25zZVR5cGUgPSBIdHRwUmVzcG9uc2U8UmVzdWx0PjtcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBNb2RlbGluZ0Fzc2Vzc21lbnRTZXJ2aWNlIHtcbiAgICBwcml2YXRlIHJlYWRvbmx5IE1BWF9GRUVEQkFDS19URVhUX0xFTkdUSCA9IDUwMDtcbiAgICBwcml2YXRlIHJlYWRvbmx5IE1BWF9GRUVEQkFDS19ERVRBSUxfVEVYVF9MRU5HVEggPSA1MDAwO1xuICAgIHByaXZhdGUgcmVzb3VyY2VVcmwgPSAnYXBpJztcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cENsaWVudCkge31cblxuICAgIHNhdmVBc3Nlc3NtZW50KHJlc3VsdElkOiBudW1iZXIsIGZlZWRiYWNrczogRmVlZGJhY2tbXSwgc3VibWlzc2lvbklkOiBudW1iZXIsIHN1Ym1pdCA9IGZhbHNlKTogT2JzZXJ2YWJsZTxSZXN1bHQ+IHtcbiAgICAgICAgbGV0IHBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKCk7XG4gICAgICAgIGlmIChzdWJtaXQpIHtcbiAgICAgICAgICAgIHBhcmFtcyA9IHBhcmFtcy5zZXQoJ3N1Ym1pdCcsICd0cnVlJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5yZXNvdXJjZVVybH0vbW9kZWxpbmctc3VibWlzc2lvbnMvJHtzdWJtaXNzaW9uSWR9L3Jlc3VsdC8ke3Jlc3VsdElkfS9hc3Nlc3NtZW50YDtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8UmVzdWx0Pih1cmwsIGZlZWRiYWNrcywgeyBwYXJhbXMgfSkucGlwZShtYXAoKHJlczogUmVzdWx0KSA9PiB0aGlzLmNvbnZlcnRSZXN1bHQocmVzKSkpO1xuICAgIH1cblxuICAgIHNhdmVFeGFtcGxlQXNzZXNzbWVudChmZWVkYmFja3M6IEZlZWRiYWNrW10sIGV4YW1wbGVTdWJtaXNzaW9uSWQ6IG51bWJlcik6IE9ic2VydmFibGU8UmVzdWx0PiB7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMucmVzb3VyY2VVcmx9L21vZGVsaW5nLXN1Ym1pc3Npb25zLyR7ZXhhbXBsZVN1Ym1pc3Npb25JZH0vZXhhbXBsZS1hc3Nlc3NtZW50YDtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8UmVzdWx0Pih1cmwsIGZlZWRiYWNrcykucGlwZShtYXAoKHJlcykgPT4gdGhpcy5jb252ZXJ0UmVzdWx0KHJlcykpKTtcbiAgICB9XG5cbiAgICB1cGRhdGVBc3Nlc3NtZW50QWZ0ZXJDb21wbGFpbnQoZmVlZGJhY2tzOiBGZWVkYmFja1tdLCBjb21wbGFpbnRSZXNwb25zZTogQ29tcGxhaW50UmVzcG9uc2UsIHN1Ym1pc3Npb25JZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxFbnRpdHlSZXNwb25zZVR5cGU+IHtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7dGhpcy5yZXNvdXJjZVVybH0vbW9kZWxpbmctc3VibWlzc2lvbnMvJHtzdWJtaXNzaW9uSWR9L2Fzc2Vzc21lbnQtYWZ0ZXItY29tcGxhaW50YDtcbiAgICAgICAgY29uc3QgYXNzZXNzbWVudFVwZGF0ZSA9IHtcbiAgICAgICAgICAgIGZlZWRiYWNrcyxcbiAgICAgICAgICAgIGNvbXBsYWludFJlc3BvbnNlLFxuICAgICAgICB9O1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnB1dDxSZXN1bHQ+KHVybCwgYXNzZXNzbWVudFVwZGF0ZSwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pLnBpcGUobWFwKChyZXM6IEVudGl0eVJlc3BvbnNlVHlwZSkgPT4gdGhpcy5jb252ZXJ0UmVzdWx0RW50aXR5UmVzcG9uc2VUeXBlRnJvbVNlcnZlcihyZXMpKSk7XG4gICAgfVxuXG4gICAgZ2V0QXNzZXNzbWVudChzdWJtaXNzaW9uSWQ6IG51bWJlcik6IE9ic2VydmFibGU8UmVzdWx0PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFJlc3VsdD4oYCR7dGhpcy5yZXNvdXJjZVVybH0vbW9kZWxpbmctc3VibWlzc2lvbnMvJHtzdWJtaXNzaW9uSWR9L3Jlc3VsdGApLnBpcGUobWFwKChyZXMpID0+IHRoaXMuY29udmVydFJlc3VsdChyZXMpKSk7XG4gICAgfVxuXG4gICAgZ2V0RXhhbXBsZUFzc2Vzc21lbnQoZXhlcmNpc2VJZDogbnVtYmVyLCBzdWJtaXNzaW9uSWQ6IG51bWJlcik6IE9ic2VydmFibGU8UmVzdWx0PiB7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMucmVzb3VyY2VVcmx9L2V4ZXJjaXNlLyR7ZXhlcmNpc2VJZH0vbW9kZWxpbmctc3VibWlzc2lvbnMvJHtzdWJtaXNzaW9uSWR9L2V4YW1wbGUtYXNzZXNzbWVudGA7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFJlc3VsdD4odXJsKS5waXBlKG1hcCgocmVzKSA9PiB0aGlzLmNvbnZlcnRSZXN1bHQocmVzKSkpO1xuICAgIH1cblxuICAgIGNhbmNlbEFzc2Vzc21lbnQoc3VibWlzc2lvbklkOiBudW1iZXIpOiBPYnNlcnZhYmxlPHZvaWQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8dm9pZD4oYCR7dGhpcy5yZXNvdXJjZVVybH0vbW9kZWxpbmctc3VibWlzc2lvbnMvJHtzdWJtaXNzaW9uSWR9L2NhbmNlbC1hc3Nlc3NtZW50YCwgbnVsbCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGVsZXRlcyBhbiBhc3Nlc3NtZW50XG4gICAgICogQHBhcmFtIHBhcnRpY2lwYXRpb25JZCBpZCBvZiB0aGUgcGFydGljaXBhdGlvbiwgdG8gd2hpY2ggdGhlIGFzc2Vzc21lbnQgYW5kIHRoZSBzdWJtaXNzaW9uIGJlbG9uZyB0b1xuICAgICAqIEBwYXJhbSBzdWJtaXNzaW9uSWQgaWQgb2YgdGhlIHN1Ym1pc3Npb24sIHRvIHdoaWNoIHRoZSBhc3Nlc3NtZW50IGJlbG9uZ3MgdG9cbiAgICAgKiBAcGFyYW0gcmVzdWx0SWQgICAgIGlkIG9mIHRoZSByZXN1bHQgd2hpY2ggaXMgZGVsZXRlZFxuICAgICAqL1xuICAgIGRlbGV0ZUFzc2Vzc21lbnQocGFydGljaXBhdGlvbklkOiBudW1iZXIsIHN1Ym1pc3Npb25JZDogbnVtYmVyLCByZXN1bHRJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTx2b2lkPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZGVsZXRlPHZvaWQ+KGAke3RoaXMucmVzb3VyY2VVcmx9L3BhcnRpY2lwYXRpb25zLyR7cGFydGljaXBhdGlvbklkfS9tb2RlbGluZy1zdWJtaXNzaW9ucy8ke3N1Ym1pc3Npb25JZH0vcmVzdWx0cy8ke3Jlc3VsdElkfWApO1xuICAgIH1cblxuICAgIHByaXZhdGUgY29udmVydFJlc3VsdEVudGl0eVJlc3BvbnNlVHlwZUZyb21TZXJ2ZXIocmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpOiBFbnRpdHlSZXNwb25zZVR5cGUge1xuICAgICAgICBsZXQgcmVzdWx0ID0gTW9kZWxpbmdBc3Nlc3NtZW50U2VydmljZS5jb252ZXJ0SXRlbUZyb21TZXJ2ZXIocmVzLmJvZHkhKTtcbiAgICAgICAgcmVzdWx0ID0gdGhpcy5jb252ZXJ0UmVzdWx0KHJlc3VsdCk7XG4gICAgICAgIHJlc3VsdC5jb21wbGV0aW9uRGF0ZSA9IGNvbnZlcnREYXRlRnJvbVNlcnZlcihyZXN1bHQuY29tcGxldGlvbkRhdGUpO1xuXG4gICAgICAgIGlmIChyZXN1bHQuc3VibWlzc2lvbikge1xuICAgICAgICAgICAgcmVzdWx0LnN1Ym1pc3Npb24uc3VibWlzc2lvbkRhdGUgPSBjb252ZXJ0RGF0ZUZyb21TZXJ2ZXIocmVzdWx0LnN1Ym1pc3Npb24uc3VibWlzc2lvbkRhdGUpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHQucGFydGljaXBhdGlvbikge1xuICAgICAgICAgICAgcmVzdWx0LnBhcnRpY2lwYXRpb24uaW5pdGlhbGl6YXRpb25EYXRlID0gY29udmVydERhdGVGcm9tU2VydmVyKHJlc3VsdC5wYXJ0aWNpcGF0aW9uLmluaXRpYWxpemF0aW9uRGF0ZSk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcmVzLmNsb25lKHsgYm9keTogcmVzdWx0IH0pO1xuICAgIH1cblxuICAgIHByaXZhdGUgc3RhdGljIGNvbnZlcnRJdGVtRnJvbVNlcnZlcihyZXN1bHQ6IFJlc3VsdCk6IFJlc3VsdCB7XG4gICAgICAgIHJldHVybiBPYmplY3QuYXNzaWduKHt9LCByZXN1bHQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEl0ZXJhdGVzIG92ZXIgYWxsIGZlZWRiYWNrIGVsZW1lbnRzIG9mIGEgcmVzcG9uc2UgYW5kIGNvbnZlcnRzIHRoZSByZWZlcmVuY2UgZmllbGQgb2YgdGhlIGZlZWRiYWNrIGludG9cbiAgICAgKiBzZXBhcmF0ZSByZWZlcmVuY2VUeXBlIGFuZCByZWZlcmVuY2VJZCBmaWVsZHMuIFRoZSByZWZlcmVuY2UgZmllbGQgaXMgb2YgdGhlIGZvcm0gPHJlZmVyZW5jZVR5cGU+OjxyZWZlcmVuY2VJZD4uXG4gICAgICovXG4gICAgY29udmVydFJlc3VsdChyZXN1bHQ6IFJlc3VsdCk6IFJlc3VsdCB7XG4gICAgICAgIGlmICghcmVzdWx0IHx8ICFyZXN1bHQuZmVlZGJhY2tzKSB7XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgZmVlZGJhY2sgb2YgcmVzdWx0LmZlZWRiYWNrcykge1xuICAgICAgICAgICAgaWYgKGZlZWRiYWNrLnJlZmVyZW5jZSkge1xuICAgICAgICAgICAgICAgIGZlZWRiYWNrLnJlZmVyZW5jZVR5cGUgPSBmZWVkYmFjay5yZWZlcmVuY2Uuc3BsaXQoJzonKVswXTtcbiAgICAgICAgICAgICAgICBmZWVkYmFjay5yZWZlcmVuY2VJZCA9IGZlZWRiYWNrLnJlZmVyZW5jZS5zcGxpdCgnOicpWzFdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2tzIGlmIHRoZSBmZWVkYmFjayB0ZXh0IGFuZCBkZXRhaWwgdGV4dCBvZiBldmVyeSBmZWVkYmFjayBpdGVtIGlzIHNtYWxsZXIgdGhhbiB0aGUgY29uZmlndXJlZCBtYXhpbXVtIGxlbmd0aC4gUmV0dXJucyB0cnVlIGlmIHRoZSBsZW5ndGggb2YgdGhlIHRleHRzIGlzIHZhbGlkIG9yIGlmXG4gICAgICogdGhlcmUgaXMgbm8gZmVlZGJhY2ssIGZhbHNlIG90aGVyd2lzZS5cbiAgICAgKi9cbiAgICBpc0ZlZWRiYWNrVGV4dFZhbGlkKGZlZWRiYWNrOiBGZWVkYmFja1tdKTogYm9vbGVhbiB7XG4gICAgICAgIGlmICghZmVlZGJhY2spIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmZWVkYmFjay5ldmVyeShcbiAgICAgICAgICAgIChmZWVkYmFja0l0ZW0pID0+XG4gICAgICAgICAgICAgICAgKCFmZWVkYmFja0l0ZW0udGV4dCB8fCBmZWVkYmFja0l0ZW0udGV4dC5sZW5ndGggPD0gdGhpcy5NQVhfRkVFREJBQ0tfVEVYVF9MRU5HVEgpICYmXG4gICAgICAgICAgICAgICAgKCFmZWVkYmFja0l0ZW0uZGV0YWlsVGV4dCB8fCBmZWVkYmFja0l0ZW0uZGV0YWlsVGV4dC5sZW5ndGggPD0gdGhpcy5NQVhfRkVFREJBQ0tfREVUQUlMX1RFWFRfTEVOR1RIKSxcbiAgICAgICAgKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgRmlsZVVwbG9hZEFzc2Vzc21lbnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9maWxlLXVwbG9hZC9hc3Nlc3MvZmlsZS11cGxvYWQtYXNzZXNzbWVudC5zZXJ2aWNlJztcbmltcG9ydCB7IFRyYW5zbGF0ZVNlcnZpY2UgfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcbmltcG9ydCB7IFN1Ym1pc3Npb24sIFN1Ym1pc3Npb25FeGVyY2lzZVR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvc3VibWlzc2lvbi5tb2RlbCc7XG5pbXBvcnQgeyBDb3Vyc2VNYW5hZ2VtZW50U2VydmljZSB9IGZyb20gJ2FwcC9jb3Vyc2UvbWFuYWdlL2NvdXJzZS1tYW5hZ2VtZW50LnNlcnZpY2UnO1xuaW1wb3J0IHsgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgQ291cnNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvdXJzZS5tb2RlbCc7XG5pbXBvcnQgeyBFeGVyY2lzZSwgRXhlcmNpc2VUeXBlLCBnZXRJY29uLCBnZXRJY29uVG9vbHRpcCB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBBbGVydFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuaW1wb3J0IHsgTW9kZWxpbmdBc3Nlc3NtZW50U2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvbW9kZWxpbmcvYXNzZXNzL21vZGVsaW5nLWFzc2Vzc21lbnQuc2VydmljZSc7XG5pbXBvcnQgeyBUZXh0QXNzZXNzbWVudFNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3RleHQvYXNzZXNzL3RleHQtYXNzZXNzbWVudC5zZXJ2aWNlJztcbmltcG9ydCB7IFByb2dyYW1taW5nQXNzZXNzbWVudE1hbnVhbFJlc3VsdFNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL2Fzc2Vzcy9tYW51YWwtcmVzdWx0L3Byb2dyYW1taW5nLWFzc2Vzc21lbnQtbWFudWFsLXJlc3VsdC5zZXJ2aWNlJztcbmltcG9ydCB7IEV4YW1NYW5hZ2VtZW50U2VydmljZSB9IGZyb20gJ2FwcC9leGFtL21hbmFnZS9leGFtLW1hbmFnZW1lbnQuc2VydmljZSc7XG5pbXBvcnQgeyBmYUJhbiwgZmFGb2xkZXJPcGVuIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IGNvbWJpbmVMYXRlc3QgfSBmcm9tICdyeGpzJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktYXNzZXNzbWVudC1sb2NrcycsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2Fzc2Vzc21lbnQtbG9ja3MuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBBc3Nlc3NtZW50TG9ja3NDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIFBST0dSQU1NSU5HX0VYRVJDSVNFID0gRXhlcmNpc2VUeXBlLlBST0dSQU1NSU5HO1xuXG4gICAgcmVhZG9ubHkgRXhlcmNpc2VUeXBlID0gRXhlcmNpc2VUeXBlO1xuXG4gICAgY291cnNlOiBDb3Vyc2U7XG4gICAgY291cnNlSWQ6IG51bWJlcjtcbiAgICB0dXRvcklkOiBudW1iZXI7XG4gICAgZXhhbUlkPzogbnVtYmVyO1xuICAgIHNob3dBbGwgPSBmYWxzZTtcbiAgICBleGVyY2lzZXM6IEV4ZXJjaXNlW10gPSBbXTtcblxuICAgIHN1Ym1pc3Npb25zOiBTdWJtaXNzaW9uW10gPSBbXTtcblxuICAgIHByaXZhdGUgY2FuY2VsQ29uZmlybWF0aW9uVGV4dDogc3RyaW5nO1xuXG4gICAgZ2V0SWNvbiA9IGdldEljb247XG4gICAgZ2V0SWNvblRvb2x0aXAgPSBnZXRJY29uVG9vbHRpcDtcblxuICAgIC8vIEljb25zXG4gICAgZmFCYW4gPSBmYUJhbjtcbiAgICBmYUZvbGRlck9wZW4gPSBmYUZvbGRlck9wZW47XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSByb3V0ZTogQWN0aXZhdGVkUm91dGUsXG4gICAgICAgIHByaXZhdGUgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgbW9kZWxpbmdBc3Nlc3NtZW50U2VydmljZTogTW9kZWxpbmdBc3Nlc3NtZW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSB0ZXh0QXNzZXNzbWVudFNlcnZpY2U6IFRleHRBc3Nlc3NtZW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBmaWxlVXBsb2FkQXNzZXNzbWVudFNlcnZpY2U6IEZpbGVVcGxvYWRBc3Nlc3NtZW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBwcm9ncmFtbWluZ0Fzc2Vzc21lbnRTZXJ2aWNlOiBQcm9ncmFtbWluZ0Fzc2Vzc21lbnRNYW51YWxSZXN1bHRTZXJ2aWNlLFxuICAgICAgICB0cmFuc2xhdGVTZXJ2aWNlOiBUcmFuc2xhdGVTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGxvY2F0aW9uOiBMb2NhdGlvbixcbiAgICAgICAgcHJpdmF0ZSBjb3Vyc2VTZXJ2aWNlOiBDb3Vyc2VNYW5hZ2VtZW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBleGFtTWFuYWdlbWVudFNlcnZpY2U6IEV4YW1NYW5hZ2VtZW50U2VydmljZSxcbiAgICApIHtcbiAgICAgICAgdHJhbnNsYXRlU2VydmljZS5nZXQoJ2FydGVtaXNBcHAuYXNzZXNzbWVudC5tZXNzYWdlcy5jb25maXJtQ2FuY2VsJykuc3Vic2NyaWJlKCh0ZXh0KSA9PiAodGhpcy5jYW5jZWxDb25maXJtYXRpb25UZXh0ID0gdGV4dCkpO1xuICAgIH1cblxuICAgIHB1YmxpYyBuZ09uSW5pdCgpIHtcbiAgICAgICAgY29tYmluZUxhdGVzdChbdGhpcy5yb3V0ZS5wYXJhbXMsIHRoaXMucm91dGUucXVlcnlQYXJhbXNdKS5zdWJzY3JpYmUoKFtwYXJhbXMsIHF1ZXJ5UGFyYW1zXSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5jb3Vyc2VJZCA9IE51bWJlcihwYXJhbXNbJ2NvdXJzZUlkJ10pO1xuICAgICAgICAgICAgdGhpcy5leGFtSWQgPSBOdW1iZXIocGFyYW1zWydleGFtSWQnXSk7XG4gICAgICAgICAgICB0aGlzLnR1dG9ySWQgPSBOdW1iZXIocXVlcnlQYXJhbXNbJ3R1dG9ySWQnXSk7XG5cbiAgICAgICAgICAgIHRoaXMuZ2V0QWxsTG9ja2VkU3VibWlzc2lvbnMoKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGFsbCBsb2NrZWQgc3VibWlzc2lvbnMgZm9yIGNvdXJzZSBhbmQgdXNlci5cbiAgICAgKi9cbiAgICBnZXRBbGxMb2NrZWRTdWJtaXNzaW9ucygpIHtcbiAgICAgICAgbGV0IGxvY2tlZFN1Ym1pc3Npb25zT2JzZXJ2YWJsZTtcbiAgICAgICAgaWYgKHRoaXMuZXhhbUlkKSB7XG4gICAgICAgICAgICBsb2NrZWRTdWJtaXNzaW9uc09ic2VydmFibGUgPSB0aGlzLmV4YW1NYW5hZ2VtZW50U2VydmljZS5maW5kQWxsTG9ja2VkU3VibWlzc2lvbnNPZkV4YW0odGhpcy5jb3Vyc2VJZCwgdGhpcy5leGFtSWQpO1xuICAgICAgICAgICAgdGhpcy5zaG93QWxsID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGxvY2tlZFN1Ym1pc3Npb25zT2JzZXJ2YWJsZSA9IHRoaXMuY291cnNlU2VydmljZS5maW5kQWxsTG9ja2VkU3VibWlzc2lvbnNPZkNvdXJzZSh0aGlzLmNvdXJzZUlkKTtcbiAgICAgICAgfVxuICAgICAgICBsb2NrZWRTdWJtaXNzaW9uc09ic2VydmFibGUuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5leHQ6IChyZXNwb25zZTogSHR0cFJlc3BvbnNlPFN1Ym1pc3Npb25bXT4pID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnN1Ym1pc3Npb25zLnB1c2goLi4uKHJlc3BvbnNlLmJvZHkgPz8gW10pKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogKHJlc3BvbnNlOiBzdHJpbmcpID0+IHRoaXMub25FcnJvcihyZXNwb25zZSksXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENhbmNlbCB0aGUgY3VycmVudCBhc3Nlc3NtZW50LlxuICAgICAqIEBwYXJhbSBjYW5jZWxlZFN1Ym1pc3Npb24gc3VibWlzc2lvblxuICAgICAqL1xuICAgIGNhbmNlbEFzc2Vzc21lbnQoY2FuY2VsZWRTdWJtaXNzaW9uOiBTdWJtaXNzaW9uKSB7XG4gICAgICAgIGNvbnN0IGNvbmZpcm1DYW5jZWwgPSB3aW5kb3cuY29uZmlybSh0aGlzLmNhbmNlbENvbmZpcm1hdGlvblRleHQpO1xuICAgICAgICBpZiAoY29uZmlybUNhbmNlbCkge1xuICAgICAgICAgICAgc3dpdGNoIChjYW5jZWxlZFN1Ym1pc3Npb24uc3VibWlzc2lvbkV4ZXJjaXNlVHlwZSkge1xuICAgICAgICAgICAgICAgIGNhc2UgU3VibWlzc2lvbkV4ZXJjaXNlVHlwZS5NT0RFTElORzpcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tb2RlbGluZ0Fzc2Vzc21lbnRTZXJ2aWNlLmNhbmNlbEFzc2Vzc21lbnQoY2FuY2VsZWRTdWJtaXNzaW9uLmlkISkuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgU3VibWlzc2lvbkV4ZXJjaXNlVHlwZS5URVhUOlxuICAgICAgICAgICAgICAgICAgICBpZiAoY2FuY2VsZWRTdWJtaXNzaW9uLnBhcnRpY2lwYXRpb24/LmV4ZXJjaXNlPy5pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy50ZXh0QXNzZXNzbWVudFNlcnZpY2UuY2FuY2VsQXNzZXNzbWVudChjYW5jZWxlZFN1Ym1pc3Npb24ucGFydGljaXBhdGlvbi5pZCEsIGNhbmNlbGVkU3VibWlzc2lvbi5pZCEpLnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgU3VibWlzc2lvbkV4ZXJjaXNlVHlwZS5GSUxFX1VQTE9BRDpcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5maWxlVXBsb2FkQXNzZXNzbWVudFNlcnZpY2UuY2FuY2VsQXNzZXNzbWVudChjYW5jZWxlZFN1Ym1pc3Npb24uaWQhKS5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBTdWJtaXNzaW9uRXhlcmNpc2VUeXBlLlBST0dSQU1NSU5HOlxuICAgICAgICAgICAgICAgICAgICB0aGlzLnByb2dyYW1taW5nQXNzZXNzbWVudFNlcnZpY2UuY2FuY2VsQXNzZXNzbWVudChjYW5jZWxlZFN1Ym1pc3Npb24uaWQhKS5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnN1Ym1pc3Npb25zID0gdGhpcy5zdWJtaXNzaW9ucy5maWx0ZXIoKHN1Ym1pc3Npb24pID0+IHN1Ym1pc3Npb24gIT09IGNhbmNlbGVkU3VibWlzc2lvbik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBQYXNzIG9uIGFuIGVycm9yIHRvIHRoZSBicm93c2VyIGNvbnNvbGUgYW5kIHRoZSBhbGVydFNlcnZpY2UuXG4gICAgICogQHBhcmFtIGVycm9yXG4gICAgICovXG4gICAgcHJpdmF0ZSBvbkVycm9yKGVycm9yOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5hbGVydFNlcnZpY2UuZXJyb3IoZXJyb3IpO1xuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJjb3Vyc2UtaW5mby1iYXJcIj5cbiAgICA8ZGl2IGNsYXNzPVwicm93IGp1c3RpZnktY29udGVudC1iZXR3ZWVuXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtbWQtOFwiPlxuICAgICAgICAgICAgPGgyPlxuICAgICAgICAgICAgICAgIDxzcGFuPnt7ICdhcnRlbWlzQXBwLmFzc2Vzc21lbnQubG9ja3MudGl0bGUnICsgKHNob3dBbGwgPyAnQWxsJyA6ICcnKSB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbjwvZGl2PlxuQGlmIChzdWJtaXNzaW9ucy5sZW5ndGggPiAwKSB7XG4gICAgPGRpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInRhYmxlLXJlc3BvbnNpdmVcIj5cbiAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlIHRhYmxlLXN0cmlwZWQgZXhlcmNpc2UtdGFibGVcIj5cbiAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz1cInRoLWxpbmtcIj5JZDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJ0aC1saW5rXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmxvY2tzLnR5cGVcIj5UeXBlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz1cInRoLWxpbmtcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnQubG9ja3MuZXhlcmNpc2VcIj5FeGVyY2lzZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJ0aC1saW5rXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmRhc2hib2FyZC5jb2x1bW5zLnN1Ym1pc3Npb25EYXRlXCI+U3VibWlzc2lvbiBkYXRlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz1cInRoLWxpbmtcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnQuZGFzaGJvYXJkLmNvbHVtbnMuc3VibWlzc2lvbkNvdW50XCI+U3VibWlzc2lvbiBjb3VudDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJ0aC1saW5rXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmRhc2hib2FyZC5jb2x1bW5zLnNjb3JlXCI+U2NvcmU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzPVwidGgtbGlua1wiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudC5kYXNoYm9hcmQuY29sdW1ucy5hY3Rpb25cIj5BY3Rpb248L3RoPlxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAgICBAZm9yIChzdWJtaXNzaW9uIG9mIHN1Ym1pc3Npb25zOyB0cmFjayBzdWJtaXNzaW9uOyBsZXQgaSA9ICRpbmRleCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyBzdWJtaXNzaW9uLmlkIH19PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbaWNvbl09XCJnZXRJY29uKHN1Ym1pc3Npb24ucGFydGljaXBhdGlvbiEuZXhlcmNpc2UhLnR5cGUpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cInJpZ2h0IGF1dG9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nYlRvb2x0aXBdPVwiZ2V0SWNvblRvb2x0aXAoc3VibWlzc2lvbi5wYXJ0aWNpcGF0aW9uIS5leGVyY2lzZSEudHlwZSkgfCBhcnRlbWlzVHJhbnNsYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyBzdWJtaXNzaW9uLnBhcnRpY2lwYXRpb24hLmV4ZXJjaXNlIS50aXRsZSB8fCAnJyB9fTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt7IHN1Ym1pc3Npb24uc3VibWlzc2lvbkRhdGUgfCBhcnRlbWlzRGF0ZTogJ2xvbmctZGF0ZScgfX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyBzdWJtaXNzaW9uLnBhcnRpY2lwYXRpb24hLnN1Ym1pc3Npb25zID8gc3VibWlzc2lvbi5wYXJ0aWNpcGF0aW9uIS5zdWJtaXNzaW9ucy5sZW5ndGggOiAwIH19PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc3VibWlzc2lvbi5sYXRlc3RSZXN1bHQ/LnNjb3JlICE9IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgc3VibWlzc2lvbi5sYXRlc3RSZXN1bHQhLnNjb3JlIH19JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc3VibWlzc2lvbi5wYXJ0aWNpcGF0aW9uIS5leGVyY2lzZSEudHlwZSA9PT0gRXhlcmNpc2VUeXBlLlRFWFQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbcm91dGVyTGlua109XCJbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnL2NvdXJzZS1tYW5hZ2VtZW50JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZUlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3RleHQtZXhlcmNpc2VzJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1Ym1pc3Npb24ucGFydGljaXBhdGlvbiEuZXhlcmNpc2UhLmlkISxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdwYXJ0aWNpcGF0aW9ucycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdWJtaXNzaW9uLnBhcnRpY2lwYXRpb24hLmlkISxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdzdWJtaXNzaW9ucycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdWJtaXNzaW9uLmlkISxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdhc3Nlc3NtZW50J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gYnRuLW91dGxpbmUtc2Vjb25kYXJ5IGJ0bi1zbSBtYi0xXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhRm9sZGVyT3BlblwiIFtmaXhlZFdpZHRoXT1cInRydWVcIj48L2ZhLWljb24+Jm5ic3A7e3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdhcnRlbWlzQXBwLmFzc2Vzc21lbnQuZGFzaGJvYXJkLmFjdGlvbnMub3BlbicgfCBhcnRlbWlzVHJhbnNsYXRlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChzdWJtaXNzaW9uLnBhcnRpY2lwYXRpb24hLmV4ZXJjaXNlIS50eXBlICE9PSBFeGVyY2lzZVR5cGUuVEVYVCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtyb3V0ZXJMaW5rXT1cIltcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICcvY291cnNlLW1hbmFnZW1lbnQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY291cnNlSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdWJtaXNzaW9uLnBhcnRpY2lwYXRpb24hLmV4ZXJjaXNlIS50eXBlICsgJy1leGVyY2lzZXMnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3VibWlzc2lvbi5wYXJ0aWNpcGF0aW9uIS5leGVyY2lzZSEuaWQhLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3N1Ym1pc3Npb25zJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1Ym1pc3Npb24uaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnYXNzZXNzbWVudCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYnRuIGJ0bi1vdXRsaW5lLXNlY29uZGFyeSBidG4tc20gbWItMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUZvbGRlck9wZW5cIiBbZml4ZWRXaWR0aF09XCJ0cnVlXCI+PC9mYS1pY29uPiZuYnNwO3t7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmRhc2hib2FyZC5hY3Rpb25zLm9wZW4nIHwgYXJ0ZW1pc1RyYW5zbGF0ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIXN1Ym1pc3Npb24ubGF0ZXN0UmVzdWx0IS5jb21wbGV0aW9uRGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gKGNsaWNrKT1cImNhbmNlbEFzc2Vzc21lbnQoc3VibWlzc2lvbilcIiBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1zZWNvbmRhcnkgYnRuLXNtIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFCYW5cIiBbZml4ZWRXaWR0aF09XCJ0cnVlXCI+PC9mYS1pY29uPiZuYnNwO3t7ICdhcnRlbWlzQXBwLmFzc2Vzc21lbnQuZGFzaGJvYXJkLmFjdGlvbnMuY2FuY2VsJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxufVxuQGlmIChzdWJtaXNzaW9ucy5sZW5ndGggPT09IDApIHtcbiAgICA8ZGl2IHN0eWxlPVwibWFyZ2luLXRvcDogMTBweFwiPlxuICAgICAgICA8cCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnQubG9ja3MuZW1wdHlcIj5ObyBBc3Nlc3NtZW50cyBsb2NrZWQgYnkgeW91ITwvcD5cbiAgICA8L2Rpdj5cbn1cbiIsImltcG9ydCB7IENvdXJzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb3Vyc2UubW9kZWwnO1xuaW1wb3J0IHsgQ291cnNlTWFuYWdlbWVudFNlcnZpY2UgfSBmcm9tICdhcHAvY291cnNlL21hbmFnZS9jb3Vyc2UtbWFuYWdlbWVudC5zZXJ2aWNlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlU25hcHNob3QsIFJlc29sdmUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgZmlsdGVyLCBtYXAsIG9mIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgQ291cnNlTWFuYWdlbWVudFJlc29sdmUgaW1wbGVtZW50cyBSZXNvbHZlPENvdXJzZT4ge1xuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgc2VydmljZTogQ291cnNlTWFuYWdlbWVudFNlcnZpY2UpIHt9XG5cbiAgICAvKipcbiAgICAgKiBSZXNvbHZlcyB0aGUgcm91dGUgYnkgZXh0cmFjdGluZyB0aGUgY291cnNlSWQgYW5kIHJldHVybnMgdGhlIGNvdXJzZSB3aXRoIHRoYXQgSWQgaWYgaXQgZXhpc3RzXG4gICAgICogYW5kIGNyZWF0ZXMgYSBuZXcgY291cnNlIG90aGVyd2lzZVxuICAgICAqIEBwYXJhbSByb3V0ZSAtIGNvbnRhaW5zIHRoZSBpbmZvcm1hdGlvbiBhYm91dCB0aGUgcm91dGUgdG8gYmUgcmVzb2x2ZWRcbiAgICAgKi9cbiAgICByZXNvbHZlKHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZVNuYXBzaG90KTogT2JzZXJ2YWJsZTxDb3Vyc2U+IHtcbiAgICAgICAgaWYgKHJvdXRlLnBhcmFtc1snY291cnNlSWQnXSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc2VydmljZS5maW5kKHJvdXRlLnBhcmFtc1snY291cnNlSWQnXSkucGlwZShcbiAgICAgICAgICAgICAgICBmaWx0ZXIoKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2U8Q291cnNlPikgPT4gcmVzcG9uc2Uub2spLFxuICAgICAgICAgICAgICAgIG1hcCgoY291cnNlOiBIdHRwUmVzcG9uc2U8Q291cnNlPikgPT4gY291cnNlLmJvZHkhKSxcbiAgICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG9mKG5ldyBDb3Vyc2UoKSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgUm91dGVzIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IFVzZXJSb3V0ZUFjY2Vzc1NlcnZpY2UgfSBmcm9tICdhcHAvY29yZS9hdXRoL3VzZXItcm91dGUtYWNjZXNzLXNlcnZpY2UnO1xuaW1wb3J0IHsgQXNzZXNzbWVudExvY2tzQ29tcG9uZW50IH0gZnJvbSAnLi9hc3Nlc3NtZW50LWxvY2tzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBdXRob3JpdHkgfSBmcm9tICdhcHAvc2hhcmVkL2NvbnN0YW50cy9hdXRob3JpdHkuY29uc3RhbnRzJztcbmltcG9ydCB7IENvdXJzZU1hbmFnZW1lbnRSZXNvbHZlIH0gZnJvbSAnYXBwL2NvdXJzZS9tYW5hZ2UvY291cnNlLW1hbmFnZW1lbnQtcmVzb2x2ZS5zZXJ2aWNlJztcblxuZXhwb3J0IGNvbnN0IGFzc2Vzc21lbnRMb2Nrc1JvdXRlOiBSb3V0ZXMgPSBbXG4gICAge1xuICAgICAgICBwYXRoOiAnOmNvdXJzZUlkL2V4YW1zLzpleGFtSWQvYXNzZXNzbWVudC1sb2NrcycsXG4gICAgICAgIGNvbXBvbmVudDogQXNzZXNzbWVudExvY2tzQ29tcG9uZW50LFxuICAgICAgICByZXNvbHZlOiB7XG4gICAgICAgICAgICBjb3Vyc2U6IENvdXJzZU1hbmFnZW1lbnRSZXNvbHZlLFxuICAgICAgICB9LFxuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICBhdXRob3JpdGllczogW0F1dGhvcml0eS5BRE1JTiwgQXV0aG9yaXR5LklOU1RSVUNUT1IsIEF1dGhvcml0eS5FRElUT1IsIEF1dGhvcml0eS5UQV0sXG4gICAgICAgICAgICBwYWdlVGl0bGU6ICdhcnRlbWlzQXBwLmFzc2Vzc21lbnQubG9ja3MuaG9tZS50aXRsZScsXG4gICAgICAgIH0sXG4gICAgICAgIGNhbkFjdGl2YXRlOiBbVXNlclJvdXRlQWNjZXNzU2VydmljZV0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIHBhdGg6ICc6Y291cnNlSWQvYXNzZXNzbWVudC1sb2NrcycsXG4gICAgICAgIGNvbXBvbmVudDogQXNzZXNzbWVudExvY2tzQ29tcG9uZW50LFxuICAgICAgICByZXNvbHZlOiB7XG4gICAgICAgICAgICBjb3Vyc2U6IENvdXJzZU1hbmFnZW1lbnRSZXNvbHZlLFxuICAgICAgICB9LFxuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICBhdXRob3JpdGllczogW0F1dGhvcml0eS5BRE1JTiwgQXV0aG9yaXR5LklOU1RSVUNUT1IsIEF1dGhvcml0eS5FRElUT1IsIEF1dGhvcml0eS5UQV0sXG4gICAgICAgICAgICBwYWdlVGl0bGU6ICdhcnRlbWlzQXBwLmFzc2Vzc21lbnQubG9ja3MuaG9tZS50aXRsZScsXG4gICAgICAgIH0sXG4gICAgICAgIGNhbkFjdGl2YXRlOiBbVXNlclJvdXRlQWNjZXNzU2VydmljZV0sXG4gICAgfSxcbl07XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE91dHB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRkVFREJBQ0tfU1VHR0VTVElPTl9BQ0NFUFRFRF9JREVOVElGSUVSLCBGRUVEQkFDS19TVUdHRVNUSU9OX0lERU5USUZJRVIsIEZlZWRiYWNrLCBGZWVkYmFja1R5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvZmVlZGJhY2subW9kZWwnO1xuaW1wb3J0IHsgU3RydWN0dXJlZEdyYWRpbmdDcml0ZXJpb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvc3RydWN0dXJlZC1ncmFkaW5nLWNyaXRlcmlvbi9zdHJ1Y3R1cmVkLWdyYWRpbmctY3JpdGVyaW9uLnNlcnZpY2UnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS11bnJlZmVyZW5jZWQtZmVlZGJhY2snLFxuICAgIHRlbXBsYXRlVXJsOiAnLi91bnJlZmVyZW5jZWQtZmVlZGJhY2suY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogW10sXG59KVxuZXhwb3J0IGNsYXNzIFVucmVmZXJlbmNlZEZlZWRiYWNrQ29tcG9uZW50IHtcbiAgICBGZWVkYmFja1R5cGUgPSBGZWVkYmFja1R5cGU7XG5cbiAgICB1bnJlZmVyZW5jZWRGZWVkYmFjazogRmVlZGJhY2tbXSA9IFtdO1xuICAgIGFzc2Vzc21lbnRzQXJlVmFsaWQ6IGJvb2xlYW47XG5cbiAgICBASW5wdXQoKSByZWFkT25seTogYm9vbGVhbjtcbiAgICBASW5wdXQoKSBoaWdobGlnaHREaWZmZXJlbmNlczogYm9vbGVhbjtcbiAgICBASW5wdXQoKSB1c2VEZWZhdWx0RmVlZGJhY2tTdWdnZXN0aW9uQmFkZ2VUZXh0OiBib29sZWFuID0gZmFsc2U7XG5cbiAgICAvKipcbiAgICAgKiBJbiBvcmRlciB0byBtYWtlIGl0IHBvc3NpYmxlIHRvIG1hcmsgdW5yZWZlcmVuY2VkIGZlZWRiYWNrIGJhc2VkIG9uIHRoZSBjb3JyZWN0aW9uIHN0YXR1cywgd2UgYXNzaWduIHJlZmVyZW5jZSBpZHMgdG8gdGhlIHVucmVmZXJlbmNlZCBmZWVkYmFja1xuICAgICAqL1xuICAgIEBJbnB1dCgpIGFkZFJlZmVyZW5jZUlkRm9yRXhhbXBsZVN1Ym1pc3Npb24gPSBmYWxzZTtcblxuICAgIEBJbnB1dCgpIHNldCBmZWVkYmFja3MoZmVlZGJhY2tzOiBGZWVkYmFja1tdKSB7XG4gICAgICAgIHRoaXMudW5yZWZlcmVuY2VkRmVlZGJhY2sgPSBbLi4uZmVlZGJhY2tzXTtcbiAgICB9XG4gICAgQElucHV0KCkgZmVlZGJhY2tTdWdnZXN0aW9uczogRmVlZGJhY2tbXSA9IFtdO1xuXG4gICAgQE91dHB1dCgpIGZlZWRiYWNrc0NoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8RmVlZGJhY2tbXT4oKTtcbiAgICBAT3V0cHV0KCkgb25BY2NlcHRTdWdnZXN0aW9uID0gbmV3IEV2ZW50RW1pdHRlcjxGZWVkYmFjaz4oKTtcbiAgICBAT3V0cHV0KCkgb25EaXNjYXJkU3VnZ2VzdGlvbiA9IG5ldyBFdmVudEVtaXR0ZXI8RmVlZGJhY2s+KCk7XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIHN0cnVjdHVyZWRHcmFkaW5nQ3JpdGVyaW9uU2VydmljZTogU3RydWN0dXJlZEdyYWRpbmdDcml0ZXJpb25TZXJ2aWNlKSB7fVxuXG4gICAgcHVibGljIGRlbGV0ZUZlZWRiYWNrKGZlZWRiYWNrVG9EZWxldGU6IEZlZWRiYWNrKTogdm9pZCB7XG4gICAgICAgIGNvbnN0IGluZGV4VG9EZWxldGUgPSB0aGlzLnVucmVmZXJlbmNlZEZlZWRiYWNrLmluZGV4T2YoZmVlZGJhY2tUb0RlbGV0ZSk7XG4gICAgICAgIHRoaXMudW5yZWZlcmVuY2VkRmVlZGJhY2suc3BsaWNlKGluZGV4VG9EZWxldGUsIDEpO1xuICAgICAgICB0aGlzLmZlZWRiYWNrc0NoYW5nZS5lbWl0KHRoaXMudW5yZWZlcmVuY2VkRmVlZGJhY2spO1xuICAgICAgICB0aGlzLnZhbGlkYXRlRmVlZGJhY2soKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogVmFsaWRhdGVzIHRoZSBmZWVkYmFjazpcbiAgICAgKiAgIC0gVGhlcmUgbXVzdCBiZSBhbnkgZm9ybSBvZiBmZWVkYmFjaywgZWl0aGVyIGdlbmVyYWwgZmVlZGJhY2sgb3IgZmVlZGJhY2sgcmVmZXJlbmNpbmcgYSBtb2RlbCBlbGVtZW50IG9yIGJvdGhcbiAgICAgKiAgIC0gRWFjaCByZWZlcmVuY2UgZmVlZGJhY2sgbXVzdCBoYXZlIGEgc2NvcmUgdGhhdCBpcyBhIHZhbGlkIG51bWJlclxuICAgICAqL1xuICAgIHZhbGlkYXRlRmVlZGJhY2soKSB7XG4gICAgICAgIGlmICghdGhpcy51bnJlZmVyZW5jZWRGZWVkYmFjayB8fCB0aGlzLnVucmVmZXJlbmNlZEZlZWRiYWNrLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgdGhpcy5hc3Nlc3NtZW50c0FyZVZhbGlkID0gZmFsc2U7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBmZWVkYmFjayBvZiB0aGlzLnVucmVmZXJlbmNlZEZlZWRiYWNrKSB7XG4gICAgICAgICAgICBpZiAoZmVlZGJhY2suY3JlZGl0cyA9PSB1bmRlZmluZWQgfHwgaXNOYU4oZmVlZGJhY2suY3JlZGl0cykpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmFzc2Vzc21lbnRzQXJlVmFsaWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5hc3Nlc3NtZW50c0FyZVZhbGlkID0gdHJ1ZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVcGRhdGUgdGhlIGZlZWRiYWNrIGluIHRoZSBsaXN0IG9mIHVucmVmZXJlbmNlZCBmZWVkYmFjaywgY2hhbmdpbmcgb3IgYWRkaW5nIGl0LlxuICAgICAqIEBwYXJhbSBmZWVkYmFjayBUaGUgZmVlZGJhY2sgdG8gdXBkYXRlXG4gICAgICovXG4gICAgdXBkYXRlRmVlZGJhY2soZmVlZGJhY2s6IEZlZWRiYWNrKSB7XG4gICAgICAgIGNvbnN0IGluZGV4VG9VcGRhdGUgPSB0aGlzLnVucmVmZXJlbmNlZEZlZWRiYWNrLmluZGV4T2YoZmVlZGJhY2spO1xuICAgICAgICBpZiAoaW5kZXhUb1VwZGF0ZSA8IDApIHtcbiAgICAgICAgICAgIHRoaXMudW5yZWZlcmVuY2VkRmVlZGJhY2sucHVzaChmZWVkYmFjayk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnVucmVmZXJlbmNlZEZlZWRiYWNrW2luZGV4VG9VcGRhdGVdID0gZmVlZGJhY2s7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy52YWxpZGF0ZUZlZWRiYWNrKCk7XG4gICAgICAgIHRoaXMuZmVlZGJhY2tzQ2hhbmdlLmVtaXQodGhpcy51bnJlZmVyZW5jZWRGZWVkYmFjayk7XG4gICAgfVxuXG4gICAgcHVibGljIGFkZFVucmVmZXJlbmNlZEZlZWRiYWNrKCk6IHZvaWQge1xuICAgICAgICBjb25zdCBmZWVkYmFjayA9IG5ldyBGZWVkYmFjaygpO1xuICAgICAgICBmZWVkYmFjay50eXBlID0gRmVlZGJhY2tUeXBlLk1BTlVBTF9VTlJFRkVSRU5DRUQ7XG5cbiAgICAgICAgLy8gQXNzaWduIHRoZSBuZXh0IGlkIHRvIHRoZSB1bnJlZmVyZW5jZWQgZmVlZGJhY2tcbiAgICAgICAgaWYgKHRoaXMuYWRkUmVmZXJlbmNlSWRGb3JFeGFtcGxlU3VibWlzc2lvbikge1xuICAgICAgICAgICAgZmVlZGJhY2sucmVmZXJlbmNlID0gdGhpcy5nZW5lcmF0ZU5ld1VucmVmZXJlbmNlZEZlZWRiYWNrUmVmZXJlbmNlKCkudG9TdHJpbmcoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMudW5yZWZlcmVuY2VkRmVlZGJhY2sucHVzaChmZWVkYmFjayk7XG4gICAgICAgIHRoaXMudmFsaWRhdGVGZWVkYmFjaygpO1xuICAgICAgICB0aGlzLmZlZWRiYWNrc0NoYW5nZS5lbWl0KHRoaXMudW5yZWZlcmVuY2VkRmVlZGJhY2spO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdlbmVyYXRlIHRoZSBuZXcgcmVmZXJlbmNlLCBieSBjb21wdXRpbmcgd2hhdCBpcyBjdXJyZW50bHkgdGhlIG1heGltdW0gcmVmZXJlbmNlIHdpdGhpbiBhbGwgZmVlZGJhY2sgYW5kIGFkZCAxXG4gICAgICovXG4gICAgcHJpdmF0ZSBnZW5lcmF0ZU5ld1VucmVmZXJlbmNlZEZlZWRiYWNrUmVmZXJlbmNlKCk6IG51bWJlciB7XG4gICAgICAgIGlmICh0aGlzLnVucmVmZXJlbmNlZEZlZWRiYWNrLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCByZWZlcmVuY2VzID0gdGhpcy51bnJlZmVyZW5jZWRGZWVkYmFjay5tYXAoKGZlZWRiYWNrKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBpZCA9ICsoZmVlZGJhY2sucmVmZXJlbmNlID8/ICcwJyk7XG4gICAgICAgICAgICBpZiAoaXNOYU4oaWQpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gaWQ7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gTWF0aC5tYXgoLi4ucmVmZXJlbmNlcy5jb25jYXQoWzBdKSkgKyAxO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEFjY2VwdCBhIGZlZWRiYWNrIHN1Z2dlc3Rpb246IE1ha2UgaXQgXCJyZWFsXCIgZmVlZGJhY2sgYW5kIHJlbW92ZSB0aGUgc3VnZ2VzdGlvbiBjYXJkXG4gICAgICovXG4gICAgYWNjZXB0U3VnZ2VzdGlvbihmZWVkYmFjazogRmVlZGJhY2spIHtcbiAgICAgICAgdGhpcy5mZWVkYmFja1N1Z2dlc3Rpb25zID0gdGhpcy5mZWVkYmFja1N1Z2dlc3Rpb25zLmZpbHRlcigoZikgPT4gZiAhPT0gZmVlZGJhY2spOyAvLyBSZW1vdmUgdGhlIHN1Z2dlc3Rpb24gY2FyZFxuICAgICAgICAvLyBXZSBuZWVkIHRvIGNoYW5nZSB0aGUgZmVlZGJhY2sgdHlwZSB0byBcIm1hbnVhbFwiIGJlY2F1c2Ugbm9uLW1hbnVhbCBmZWVkYmFjayBpcyBuZXZlciBlZGl0YWJsZSBpbiB0aGUgZWRpdG9yXG4gICAgICAgIC8vIGFuZCB3aWxsIGJlIGZpbHRlcmVkIG91dCBpbiBhbGwga2luZHMgb2YgcGxhY2VzXG4gICAgICAgIGZlZWRiYWNrLnR5cGUgPSBGZWVkYmFja1R5cGUuTUFOVUFMX1VOUkVGRVJFTkNFRDtcbiAgICAgICAgLy8gQ2hhbmdlIHRoZSBwcmVmaXggXCJGZWVkYmFja1N1Z2dlc3Rpb246XCIgdG8gXCJGZWVkYmFja1N1Z2dlc3Rpb246YWNjZXB0ZWQ6XCJcbiAgICAgICAgZmVlZGJhY2sudGV4dCA9IChmZWVkYmFjay50ZXh0ID8/IEZFRURCQUNLX1NVR0dFU1RJT05fSURFTlRJRklFUikucmVwbGFjZShGRUVEQkFDS19TVUdHRVNUSU9OX0lERU5USUZJRVIsIEZFRURCQUNLX1NVR0dFU1RJT05fQUNDRVBURURfSURFTlRJRklFUik7XG4gICAgICAgIHRoaXMudXBkYXRlRmVlZGJhY2soZmVlZGJhY2spOyAvLyBNYWtlIGl0IFwicmVhbFwiIGZlZWRiYWNrXG4gICAgICAgIHRoaXMub25BY2NlcHRTdWdnZXN0aW9uLmVtaXQoZmVlZGJhY2spO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERpc2NhcmQgYSBmZWVkYmFjayBzdWdnZXN0aW9uOiBSZW1vdmUgdGhlIHN1Z2dlc3Rpb24gY2FyZCBhbmQgZW1pdCB0aGUgZXZlbnRcbiAgICAgKi9cbiAgICBkaXNjYXJkU3VnZ2VzdGlvbihmZWVkYmFjazogRmVlZGJhY2spIHtcbiAgICAgICAgdGhpcy5mZWVkYmFja1N1Z2dlc3Rpb25zID0gdGhpcy5mZWVkYmFja1N1Z2dlc3Rpb25zLmZpbHRlcigoZikgPT4gZiAhPT0gZmVlZGJhY2spOyAvLyBSZW1vdmUgdGhlIHN1Z2dlc3Rpb24gY2FyZFxuICAgICAgICB0aGlzLm9uRGlzY2FyZFN1Z2dlc3Rpb24uZW1pdChmZWVkYmFjayk7XG4gICAgfVxuXG4gICAgY3JlYXRlQXNzZXNzbWVudE9uRHJvcChldmVudDogRXZlbnQpIHtcbiAgICAgICAgdGhpcy5hZGRVbnJlZmVyZW5jZWRGZWVkYmFjaygpO1xuICAgICAgICBjb25zdCBuZXdGZWVkYmFjazogRmVlZGJhY2sgfCB1bmRlZmluZWQgPSB0aGlzLnVucmVmZXJlbmNlZEZlZWRiYWNrLmxhc3QoKTtcbiAgICAgICAgaWYgKG5ld0ZlZWRiYWNrKSB7XG4gICAgICAgICAgICB0aGlzLnN0cnVjdHVyZWRHcmFkaW5nQ3JpdGVyaW9uU2VydmljZS51cGRhdGVGZWVkYmFja1dpdGhTdHJ1Y3R1cmVkR3JhZGluZ0luc3RydWN0aW9uRXZlbnQobmV3RmVlZGJhY2ssIGV2ZW50KTtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlRmVlZGJhY2sobmV3RmVlZGJhY2spO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiPGRpdiAoZHJvcCk9XCJjcmVhdGVBc3Nlc3NtZW50T25Ecm9wKCRldmVudClcIiAoZHJhZ292ZXIpPVwiJGV2ZW50LnByZXZlbnREZWZhdWx0KClcIj5cbiAgICA8ZGl2IGNsYXNzPVwiY29sLW1kLTZcIj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImFkZC11bnJlZmVyZW5jZWQtZmVlZGJhY2sgYnRuIGJ0bi1zdWNjZXNzIG10LTRcIiAoY2xpY2spPVwiYWRkVW5yZWZlcmVuY2VkRmVlZGJhY2soKVwiIFtkaXNhYmxlZF09XCJyZWFkT25seVwiPlxuICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuZmlsZVVwbG9hZEFzc2Vzc21lbnQuYWRkRmVlZGJhY2snIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInJvdyBtdC00XCI+XG4gICAgICAgICAgICA8aDQgY2xhc3M9XCJjb2wtMTJcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnQuZGV0YWlsLmZlZWRiYWNrXCI+RmVlZGJhY2s8L2g0PlxuICAgICAgICAgICAgQGlmICh1bnJlZmVyZW5jZWRGZWVkYmFjay5sZW5ndGggKyBmZWVkYmFja1N1Z2dlc3Rpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtMTIgY29sLWxnLTggY29sLXhsLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFsZXJ0IGFsZXJ0LXNlY29uZGFyeSB0ZXh0LWNlbnRlclwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+e3sgJ2FydGVtaXNBcHAuZmlsZVVwbG9hZEFzc2Vzc21lbnQuYXNzZXNzSW5zdHJ1Y3Rpb25XaXRoRHJvcE9wdGlvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBmb3IgKGZlZWRiYWNrIG9mIHVucmVmZXJlbmNlZEZlZWRiYWNrOyB0cmFjayBmZWVkYmFjaykge1xuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtMTIgY29sLWxnLTYgY29sLXhsLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgPGpoaS11bnJlZmVyZW5jZWQtZmVlZGJhY2stZGV0YWlsXG4gICAgICAgICAgICAgICAgICAgICAgICBbZmVlZGJhY2tdPVwiZmVlZGJhY2tcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKG9uRmVlZGJhY2tDaGFuZ2UpPVwidXBkYXRlRmVlZGJhY2soZmVlZGJhY2spXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIChvbkZlZWRiYWNrRGVsZXRlKT1cImRlbGV0ZUZlZWRiYWNrKGZlZWRiYWNrKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbcmVhZE9ubHldPVwicmVhZE9ubHlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW2hpZ2hsaWdodERpZmZlcmVuY2VzXT1cImhpZ2hsaWdodERpZmZlcmVuY2VzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFt1c2VEZWZhdWx0RmVlZGJhY2tTdWdnZXN0aW9uQmFkZ2VUZXh0XT1cInVzZURlZmF1bHRGZWVkYmFja1N1Z2dlc3Rpb25CYWRnZVRleHRcIlxuICAgICAgICAgICAgICAgICAgICA+PC9qaGktdW5yZWZlcmVuY2VkLWZlZWRiYWNrLWRldGFpbD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBmb3IgKHN1Z2dlc3Rpb24gb2YgZmVlZGJhY2tTdWdnZXN0aW9uczsgdHJhY2sgc3VnZ2VzdGlvbikge1xuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtMTIgY29sLWxnLTYgY29sLXhsLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgPGpoaS11bnJlZmVyZW5jZWQtZmVlZGJhY2stZGV0YWlsXG4gICAgICAgICAgICAgICAgICAgICAgICBbZmVlZGJhY2tdPVwic3VnZ2VzdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbaXNTdWdnZXN0aW9uXT1cInRydWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW3JlYWRPbmx5XT1cInRydWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKG9uQWNjZXB0U3VnZ2VzdGlvbik9XCJhY2NlcHRTdWdnZXN0aW9uKCRldmVudClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKG9uRGlzY2FyZFN1Z2dlc3Rpb24pPVwiZGlzY2FyZFN1Z2dlc3Rpb24oJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbdXNlRGVmYXVsdEZlZWRiYWNrU3VnZ2VzdGlvbkJhZGdlVGV4dF09XCJ1c2VEZWZhdWx0RmVlZGJhY2tTdWdnZXN0aW9uQmFkZ2VUZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgPjwvamhpLXVucmVmZXJlbmNlZC1mZWVkYmFjay1kZXRhaWw+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBBc3Nlc3NtZW50SGVhZGVyQ29tcG9uZW50IH0gZnJvbSAnLi9hc3Nlc3NtZW50LWhlYWRlci9hc3Nlc3NtZW50LWhlYWRlci5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXNzZXNzbWVudExheW91dENvbXBvbmVudCB9IGZyb20gJy4vYXNzZXNzbWVudC1sYXlvdXQvYXNzZXNzbWVudC1sYXlvdXQuY29tcG9uZW50JztcbmltcG9ydCB7IEFzc2Vzc21lbnRDb21wbGFpbnRBbGVydENvbXBvbmVudCB9IGZyb20gJy4vYXNzZXNzbWVudC1jb21wbGFpbnQtYWxlcnQvYXNzZXNzbWVudC1jb21wbGFpbnQtYWxlcnQuY29tcG9uZW50JztcbmltcG9ydCB7IFNjb3JlRGlzcGxheUNvbXBvbmVudCB9IGZyb20gJy4uL3NoYXJlZC9zY29yZS1kaXNwbGF5L3Njb3JlLWRpc3BsYXkuY29tcG9uZW50JztcbmltcG9ydCB7IFVucmVmZXJlbmNlZEZlZWRiYWNrRGV0YWlsQ29tcG9uZW50IH0gZnJvbSAnYXBwL2Fzc2Vzc21lbnQvdW5yZWZlcmVuY2VkLWZlZWRiYWNrLWRldGFpbC91bnJlZmVyZW5jZWQtZmVlZGJhY2stZGV0YWlsLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL3NoYXJlZC1jb21wb25lbnQubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNDb21wbGFpbnRzRm9yVHV0b3JNb2R1bGUgfSBmcm9tICdhcHAvY29tcGxhaW50cy9jb21wbGFpbnRzLWZvci10dXRvci9jb21wbGFpbnRzLWZvci10dXRvci5tb2R1bGUnO1xuaW1wb3J0IHsgQXNzZXNzbWVudExvY2tzQ29tcG9uZW50IH0gZnJvbSAnYXBwL2Fzc2Vzc21lbnQvYXNzZXNzbWVudC1sb2Nrcy9hc3Nlc3NtZW50LWxvY2tzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBSb3V0ZXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgYXNzZXNzbWVudExvY2tzUm91dGUgfSBmcm9tICdhcHAvYXNzZXNzbWVudC9hc3Nlc3NtZW50LWxvY2tzL2Fzc2Vzc21lbnQtbG9ja3Mucm91dGUnO1xuaW1wb3J0IHsgVW5yZWZlcmVuY2VkRmVlZGJhY2tDb21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC91bnJlZmVyZW5jZWQtZmVlZGJhY2svdW5yZWZlcmVuY2VkLWZlZWRiYWNrLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBcnRlbWlzTWFya2Rvd25Nb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLm1vZHVsZSc7XG5pbXBvcnQgeyBBc3Nlc3NtZW50Q29ycmVjdGlvblJvdW5kQmFkZ2VDb21wb25lbnQgfSBmcm9tICdhcHAvYXNzZXNzbWVudC91bnJlZmVyZW5jZWQtZmVlZGJhY2stZGV0YWlsL2Fzc2Vzc21lbnQtY29ycmVjdGlvbi1yb3VuZC1iYWRnZS9hc3Nlc3NtZW50LWNvcnJlY3Rpb24tcm91bmQtYmFkZ2UuY29tcG9uZW50JztcbmltcG9ydCB7IEFydGVtaXNHcmFkaW5nSW5zdHJ1Y3Rpb25MaW5rSWNvbk1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvZ3JhZGluZy1pbnN0cnVjdGlvbi1saW5rLWljb24vZ3JhZGluZy1pbnN0cnVjdGlvbi1saW5rLWljb24ubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNGZWVkYmFja01vZHVsZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL2ZlZWRiYWNrL2ZlZWRiYWNrLm1vZHVsZSc7XG5cbmNvbnN0IEVOVElUWV9TVEFURVMgPSBbLi4uYXNzZXNzbWVudExvY2tzUm91dGVdO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtcbiAgICAgICAgQXJ0ZW1pc1NoYXJlZE1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc0NvbXBsYWludHNGb3JUdXRvck1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSxcbiAgICAgICAgUm91dGVyTW9kdWxlLmZvckNoaWxkKEVOVElUWV9TVEFURVMpLFxuICAgICAgICBBcnRlbWlzTWFya2Rvd25Nb2R1bGUsXG4gICAgICAgIEFydGVtaXNHcmFkaW5nSW5zdHJ1Y3Rpb25MaW5rSWNvbk1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc0ZlZWRiYWNrTW9kdWxlLFxuICAgIF0sXG4gICAgZGVjbGFyYXRpb25zOiBbXG4gICAgICAgIEFzc2Vzc21lbnRIZWFkZXJDb21wb25lbnQsXG4gICAgICAgIEFzc2Vzc21lbnRMYXlvdXRDb21wb25lbnQsXG4gICAgICAgIEFzc2Vzc21lbnRDb21wbGFpbnRBbGVydENvbXBvbmVudCxcbiAgICAgICAgU2NvcmVEaXNwbGF5Q29tcG9uZW50LFxuICAgICAgICBVbnJlZmVyZW5jZWRGZWVkYmFja0RldGFpbENvbXBvbmVudCxcbiAgICAgICAgQXNzZXNzbWVudExvY2tzQ29tcG9uZW50LFxuICAgICAgICBVbnJlZmVyZW5jZWRGZWVkYmFja0NvbXBvbmVudCxcbiAgICAgICAgQXNzZXNzbWVudENvcnJlY3Rpb25Sb3VuZEJhZGdlQ29tcG9uZW50LFxuICAgIF0sXG4gICAgZXhwb3J0czogW1xuICAgICAgICBBc3Nlc3NtZW50TGF5b3V0Q29tcG9uZW50LFxuICAgICAgICBTY29yZURpc3BsYXlDb21wb25lbnQsXG4gICAgICAgIFVucmVmZXJlbmNlZEZlZWRiYWNrRGV0YWlsQ29tcG9uZW50LFxuICAgICAgICBBc3Nlc3NtZW50TG9ja3NDb21wb25lbnQsXG4gICAgICAgIFVucmVmZXJlbmNlZEZlZWRiYWNrQ29tcG9uZW50LFxuICAgICAgICBBc3Nlc3NtZW50Q29ycmVjdGlvblJvdW5kQmFkZ2VDb21wb25lbnQsXG4gICAgXSxcbn0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc0Fzc2Vzc21lbnRTaGFyZWRNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS0EsSUFBYTtBQUFiOztBQUFNLElBQU8sb0JBQVAsTUFBd0I7TUFDbkI7TUFFQTtNQUNBO01BQ0E7TUFDQTtNQUVBO01BRUE7TUFFUCxjQUFBO01BQWU7Ozs7OztBQ0NiLFNBQVUsdUJBQXVCLFVBQW9CLFFBQWdCLFVBQXFCLFlBQXlCLFlBQVksT0FBSztBQUN0SSxNQUFJLFVBQVU7QUFDVixVQUFNLFNBQVMsc0JBQXNCLFFBQVE7QUFFN0MsUUFBSSxXQUFXO0FBQ1gsWUFBTSxPQUFPLFNBQVMsY0FBZTtBQUNyQyxhQUFPLGNBQWMsc0JBQXNCLFFBQVEsRUFBRSxVQUFVLEtBQUssRUFBRSw4QkFBOEIsU0FBUyxFQUFFLEVBQUU7V0FDOUc7QUFDSCxVQUFJLFNBQVMsZUFBZTtBQUN4QixjQUFNLE9BQU8sU0FBUyxjQUFlO0FBQ3JDLGVBQU8sY0FBYyxzQkFBc0IsUUFBUSxFQUFFLFVBQVUsS0FBSyxFQUFFLHlCQUF5QixTQUFTLEVBQUUsRUFBRTtpQkFDckcsU0FBUyxZQUFZLFlBQVk7QUFDeEMsY0FBTSxTQUFVLFdBQVcsY0FBdUMsTUFBTTtBQUN4RSxlQUFPLGNBQWMsWUFBWSxRQUFRLEVBQUUsY0FBYyxTQUFTLEVBQUUsVUFBVSxNQUFNLEVBQUU7YUFDbkY7QUFDSCxlQUFPLGNBQWMsc0JBQXNCLFFBQVEsRUFBRSx5QkFBeUIsU0FBUyxFQUFFLEVBQUU7OztTQUdoRztBQUNILGFBQVMsS0FBSTs7QUFFckI7QUFwQ0E7Ozs7Ozs7QUNGQSxJQVNhLHFDQW1CQTtBQTVCYjs7O0FBQ0E7QUFRTyxJQUFNLHNDQUFzQyxDQUFDLFdBQW9CLFlBQXFCLFdBQXNCLGFBQWdDO0FBQy9JLFVBQUksVUFBVSxxQkFBcUI7QUFDL0IsZUFBTzs7QUFFWCxVQUFJLFVBQVUsWUFBWSxXQUFXO0FBQ2pDLGVBQU87O0FBRVgsVUFBSSxVQUFVLG1CQUFtQixlQUFlLGFBQWEsVUFBVSxVQUFVLFVBQVUsT0FBTyxhQUFhLFFBQVc7QUFDdEgsZUFBTzs7QUFFWCxhQUFPLFVBQVcsa0JBQWtCLGNBQWMsWUFBWSxDQUFDLGFBQWE7SUFDaEY7QUFRTyxJQUFNLDRCQUE0QixDQUNyQyxXQUNBLFlBQ0EsNEJBQ0EsUUFDQSxXQUNBLGFBQ1M7QUFDVCxVQUFJLFVBQVUscUJBQXFCO0FBQy9CLGVBQU87O0FBRVgsVUFBSSxDQUFDLFFBQVE7QUFDVCxlQUFPOztBQUVYLFVBQUksQ0FBQyxPQUFPLGdCQUFnQjtBQUN4QixlQUFPOztBQUVYLFVBQUksV0FBVztBQUNYLGVBQU8sVUFBVSxrQkFBa0IsY0FBYyxhQUFhLG9DQUFvQyxXQUFXLFlBQVksV0FBVyxRQUFROztBQUVoSixhQUFPLENBQUM7SUFDWjs7Ozs7QUNsREEsU0FBUyxXQUFXLGNBQWMsT0FBZSxjQUFjO0FBTS9ELFNBQVMsZ0JBQWdCO0FBRXpCLFNBQVMsZ0JBQWdCLGNBQWM7QUFFdkMsU0FBUyxnQkFBZ0I7Ozs7Ozs7QUNUckIsSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUFzQixJQUFBLG9CQUFBLENBQUE7O0FBQWtDLElBQUEsMEJBQUE7QUFDNUQsSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLElBQUE7OztBQUhrQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLEdBQUEsR0FBQSxTQUFBLENBQUE7Ozs7O0FBSzlCLElBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLENBQUE7OztBQUNKLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsSUFBQTs7OztBQUZRLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsY0FBQSxPQUFBLFVBQUEsa0JBQUEsT0FBQSxjQUFBLGdCQUFBLHlCQUFBLEdBQUEsR0FBQSxnQ0FBQSxJQUFBLHlCQUFBLEdBQUEsR0FBQSw2QkFBQSxHQUFBLFFBQUE7Ozs7O0FBTUksSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsQ0FBQTs7O0FBS0osSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxZQUFBOzs7O0FBTlEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxzQkFBQSxPQUFBLFVBQUEsa0JBQUEsT0FBQSxjQUFBLGdCQUFBLHlCQUFBLEdBQUEsR0FBQSx3Q0FBQSxJQUFBLHlCQUFBLEdBQUEsR0FBQSw4Q0FBQSxHQUFBLGdCQUFBOzs7OztBQVdRLElBQUEsb0JBQUEsQ0FBQTs7Ozs7O0FBQUEsSUFBQSxnQ0FBQSw4QkFBQSx5QkFBQSxHQUFBLEdBQUEsdUNBQUEsNkJBQUEsR0FBQSxLQUFBLHlCQUFBLEdBQUEsR0FBQSxPQUFBLGtCQUFBLFdBQUEsQ0FBQSxDQUFBLEdBQUEsd0JBQUE7Ozs7O0FBRUEsSUFBQSxvQkFBQSxDQUFBOzs7Ozs7QUFBQSxJQUFBLGdDQUFBLDhCQUFBLHlCQUFBLEdBQUEsR0FBQSxvQ0FBQSw2QkFBQSxHQUFBLEtBQUEsT0FBQSxxQkFBQSxPQUFBLE9BQUEsT0FBQSxrQkFBQSxZQUFBLE9BQUEsT0FBQSxPQUFBLGtCQUFBLFNBQUEsT0FBQSx5QkFBQSxHQUFBLEdBQUEsT0FBQSxrQkFBQSxXQUFBLENBQUEsQ0FBQSxHQUFBLHdCQUFBOzs7OztBQUpSLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsZ0ZBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSxnRkFBQSxHQUFBLENBQUE7QUFNTCxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLGdCQUFBOzs7O0FBVFEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLE9BQUEsc0JBQUEsSUFBQSxDQUFBOzs7Ozs7QUFXSixJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQWtELElBQUEsd0JBQUEsU0FBQSxTQUFBLDJGQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFTLHlCQUFBLFFBQUEsV0FBQSxDQUFZO0lBQUEsQ0FBQTtBQUNuRSxJQUFBLG9CQUFBLENBQUE7O0FBQ0osSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxnQkFBQTs7O0FBRlEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSx5QkFBQSxHQUFBLEdBQUEsK0JBQUEsR0FBQSxvQkFBQTs7Ozs7QUFpQlksSUFBQSxvQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsQ0FBQTs7O0FBS0osSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTs7OztBQU5RLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsOENBQUEsUUFBQSxVQUFBLGtCQUFBLFFBQUEsY0FBQSxnQkFBQSx5QkFBQSxHQUFBLEdBQUEsa0NBQUEsSUFBQSx5QkFBQSxHQUFBLEdBQUEsK0JBQUEsR0FBQSx3Q0FBQTs7Ozs7QUFRSixJQUFBLG9CQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQStCLElBQUEsb0JBQUEsQ0FBQTs7QUFBcUUsSUFBQSwwQkFBQTtBQUN4RyxJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7OztBQURtQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFNBQUEseUJBQUEsR0FBQSxHQUFBLCtCQUFBLEdBQUEsT0FBQTs7Ozs7QUFYdkMsSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsaUZBQUEsR0FBQSxDQUFBLEVBUUMsR0FBQSxpRkFBQSxHQUFBLENBQUE7QUFJTCxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLHdCQUFBOzs7O0FBYlEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxJQUFBLE9BQUEsYUFBQSxPQUFBLE9BQUEsT0FBQSxVQUFBLFlBQUEsSUFBQSxFQUFBO0FBU0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLEVBQUEsT0FBQSxhQUFBLE9BQUEsT0FBQSxPQUFBLFVBQUEsWUFBQSxJQUFBLEVBQUE7Ozs7OztBQWdDSixJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUlJLElBQUEsd0JBQUEsU0FBQSxTQUFBLDJHQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFTLHlCQUFBLFFBQUEsbUJBQW1CLElBQUksQ0FBQztJQUFBLENBQUE7O0FBSWpDLElBQUEsb0JBQUEsQ0FBQTs7QUFDSixJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUlJLElBQUEsd0JBQUEsU0FBQSxTQUFBLDJHQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFTLHlCQUFBLFFBQUEsbUJBQW1CLEtBQUssQ0FBQztJQUFBLENBQUE7O0FBSWxDLElBQUEsb0JBQUEsRUFBQTs7QUFDSixJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsd0JBQUE7Ozs7QUFqQlksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxtQ0FBQSxTQUFBLHlCQUFBLEdBQUEsR0FBQSxzREFBQSxDQUFBO0FBREEsSUFBQSx3QkFBQSxZQUFBLFFBQUEsMkJBQUEsUUFBQSw0QkFBQSxJQUFBLFFBQUEsNkJBQUE7QUFHQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLHNDQUFBLHlCQUFBLEdBQUEsR0FBQSwrQ0FBQSxHQUFBLGdDQUFBO0FBUUEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxtQ0FBQSxTQUFBLHlCQUFBLEdBQUEsSUFBQSxxREFBQSxDQUFBO0FBREEsSUFBQSx3QkFBQSxZQUFBLFFBQUEsMkJBQUEsUUFBQSw0QkFBQSxJQUFBLFFBQUEsNkJBQUE7QUFHQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLHNDQUFBLHlCQUFBLElBQUEsSUFBQSw4Q0FBQSxHQUFBLGdDQUFBOzs7Ozs7QUFPUixJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFLSSxJQUFBLHdCQUFBLFNBQUEsU0FBQSwyR0FBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSwyQkFBQSxDQUFBO0FBQUEsYUFBUyx5QkFBQSxRQUFBLG1CQUFtQixJQUFJLENBQUM7SUFBQSxDQUFBOztBQUdqQyxJQUFBLG9CQUFBLENBQUE7O0FBQ0osSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLHdCQUFBOzs7O0FBTmdCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsbUNBQUEsU0FBQSx5QkFBQSxHQUFBLEdBQUEscURBQUEsQ0FBQTtBQUZBLElBQUEsd0JBQUEsWUFBQSxRQUFBLHVCQUFBO0FBSUEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQ0FBQSx5QkFBQSxHQUFBLEdBQUEsaURBQUEsR0FBQSxvQ0FBQTs7Ozs7O0FBM0RwQixJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLENBQUE7OztBQUtKLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFlBQUEsRUFBQTtBQUtJLElBQUEsd0JBQUEsaUJBQUEsU0FBQSxxR0FBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFhLHlCQUFBLFFBQUEsa0JBQUEsZUFBQSxNQUFBO0lBQ25DLENBQUE7QUFJa0IsSUFBQSxvQkFBQSxJQUFBLDBCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSx3QkFBQSxFQUFBO0FBQW1JLElBQUEsb0JBQUEsSUFBQSxHQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUN2SSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLGtGQUFBLElBQUEsRUFBQSxFQXlCQyxJQUFBLGtGQUFBLElBQUEsQ0FBQTtBQWlCTCxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLGdCQUFBOzs7O0FBL0RZLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsOEJBQUEsT0FBQSxVQUFBLGtCQUFBLE9BQUEsY0FBQSxnQkFBQSx5QkFBQSxHQUFBLElBQUEsdUNBQUEsSUFBQSx5QkFBQSxHQUFBLElBQUEsb0NBQUEsR0FBQSx3QkFBQTtBQVdJLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsYUFBQSxPQUFBLDZCQUFBLEVBQTJDLFdBQUEsT0FBQSxrQkFBQSxZQUFBLEVBQUEsWUFBQSxPQUFBLFdBQUEsT0FBQSx1QkFBQSxFQUFBLFlBQUEsT0FBQSxXQUFBLE9BQUEsdUJBQUE7QUFPekIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxhQUFBLE9BQUEsNkJBQUEsRUFBMkMsV0FBQSxPQUFBLGtCQUFBLFlBQUEsRUFBQSxXQUFBLENBQUEsT0FBQSxPQUFBO0FBRXJFLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsSUFBQSxDQUFBLE9BQUEsV0FBQSxPQUFBLFVBQUEsa0JBQUEsT0FBQSxjQUFBLFlBQUEsS0FBQSxFQUFBO0FBMEJBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsSUFBQSxDQUFBLE9BQUEsVUFBQSxZQUFBLE9BQUEsVUFBQSxrQkFBQSxPQUFBLGNBQUEsZ0JBQUEsS0FBQSxFQUFBOzs7Ozs7QUEzR2hCLElBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLGtFQUFBLEdBQUEsQ0FBQTtBQVNBLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsa0VBQUEsR0FBQSxDQUFBLEVBV0MsR0FBQSxrRUFBQSxHQUFBLENBQUE7QUFNTCxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUE7QUFDSyxJQUFBLG9CQUFBLEVBQUE7OztBQUtMLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsbUVBQUEsR0FBQSxDQUFBO0FBZ0JKLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsWUFBQSxDQUFBO0FBQThELElBQUEsd0JBQUEsaUJBQUEsU0FBQSxzRkFBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBQSxRQUFBLGdCQUFBLE1BQUE7SUFBQSxDQUFBO0FBQWdFLElBQUEsMEJBQUE7QUFDbEksSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxtRUFBQSxJQUFBLEVBQUE7QUFtRUosSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxJQUFBOzs7O0FBL0g2QixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxVQUFBO0FBQ3JCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsR0FBQSxPQUFBLFVBQUEsSUFBQSxFQUFBO0FBVUksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLE9BQUEsbUJBQUEsSUFBQSxFQUFBO0FBWUEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLE9BQUEsc0JBQUEsSUFBQSxFQUFBO0FBVWEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxJQUFBLE9BQUEsVUFBQSxrQkFBQSxPQUFBLGNBQUEsZ0JBQUEseUJBQUEsSUFBQSxJQUFBLCtCQUFBLElBQUEseUJBQUEsSUFBQSxJQUFBLDRCQUFBLEdBQUEsd0JBQUE7QUFNTCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLElBQUEsT0FBQSxVQUFBLEtBQUEsRUFBQTtBQWlCMEQsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxXQUFBLE9BQUEsYUFBQSxFQUEyQixZQUFBLElBQUEsRUFBQSxZQUFBLElBQUE7QUFFN0YsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxJQUFBLE9BQUEsV0FBQSxPQUFBLHFCQUFBLEtBQUEsRUFBQTs7O0FEdkVaLGNBc0JhO0FBdEJiOztBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUdBOzs7Ozs7OztBQVVNLElBQU8sOEJBQVAsTUFBTyw2QkFBMkI7TUFzQnhCO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUF6Qkg7TUFDQSxZQUFZO01BQ1osYUFBYTtNQUNiLGFBQWE7TUFDYjtNQUNBO01BR0MsaUNBQWlDLElBQUksYUFBWTtNQUMzRDtNQUNBO01BQ0Esb0JBQXVDLElBQUksa0JBQWlCO01BQzVELGdCQUFnQjtNQUNoQixZQUFZO01BQ1osbUJBQW1CO01BQ25CLHNCQUFzQjtNQUN0QiwwQkFBMEI7TUFDMUI7TUFDQTtNQUVBLFlBQ1ksY0FDQSwwQkFDQSxnQkFDQSxRQUNBLFVBQWtCO0FBSmxCLGFBQUEsZUFBQTtBQUNBLGFBQUEsMkJBQUE7QUFDQSxhQUFBLGlCQUFBO0FBQ0EsYUFBQSxTQUFBO0FBQ0EsYUFBQSxXQUFBO01BQ1Q7TUFFSCxXQUFRO0FBQ0osYUFBSyxTQUFTLHNCQUFzQixLQUFLLFFBQVM7QUFFbEQsYUFBSyxnQ0FBZ0MsS0FBSyxRQUFRLGlDQUFpQztBQUNuRixZQUFJLEtBQUssVUFBVSxlQUFlO0FBRTlCLGVBQUssZ0NBQWdDLEtBQUssSUFBSSxLQUFNLEtBQUssNkJBQTZCOztBQUcxRixZQUFJLEtBQUssV0FBVztBQUNoQixlQUFLLGdCQUFnQixLQUFLLFVBQVU7QUFDcEMsZUFBSyxVQUFVLEtBQUssVUFBVSxhQUFhO0FBQzNDLGNBQUksS0FBSyxTQUFTO0FBQ2QsaUJBQUssb0JBQW9CLEtBQUssVUFBVTtBQUN4QyxpQkFBSyxzQkFBc0I7QUFDM0IsaUJBQUssbUJBQW1CO2lCQUNyQjtBQUNILGdCQUFJLEtBQUssb0JBQW9CO0FBQ3pCLGtCQUFJLEtBQUssVUFBVSxtQkFBbUI7QUFDbEMscUJBQUssWUFBVztxQkFDYjtBQUNILHFCQUFLLFdBQVU7O21CQUVoQjtBQUNILG1CQUFLLGFBQWEsTUFBTSxzQ0FBc0M7Ozs7TUFJOUU7TUFFUSxhQUFVO0FBQ2QsYUFBSyxZQUFZO0FBQ2pCLGFBQUsseUJBQ0EsV0FBVyxLQUFLLFVBQVUsRUFBRyxFQUM3QixLQUNHLFNBQVMsTUFBSztBQUNWLGVBQUssWUFBWTtRQUNyQixDQUFDLENBQUMsRUFFTCxVQUFVO1VBQ1AsTUFBTSxDQUFDLGFBQVk7QUFDZixpQkFBSyxvQkFBb0IsU0FBUztBQUNsQyxpQkFBSyxZQUFZLEtBQUssa0JBQWtCO0FBQ3hDLGlCQUFLLHNCQUFzQjtBQUMzQixpQkFBSyxtQkFBbUI7QUFDeEIsaUJBQUssYUFBYSxRQUFRLDJCQUEyQjtVQUN6RDtVQUNBLE9BQU8sQ0FBQyxRQUEwQjtBQUM5QixpQkFBSyxRQUFRLEdBQUc7VUFDcEI7U0FDSDtNQUNUO01BRVEsY0FBVztBQUNmLGFBQUssb0JBQW9CLEtBQUssVUFBVTtBQUN4QyxhQUFLLG1CQUFtQjtBQUV4QixhQUFLLDBCQUEwQixLQUFLLHlCQUF5Qix5Q0FBeUMsS0FBSyxtQkFBbUIsS0FBSyxRQUFTO0FBQzVJLFlBQUksQ0FBQyxLQUFLLHlCQUF5QjtBQUUvQixlQUFLLFlBQVk7QUFDakIsZUFBSyx5QkFDQSxZQUFZLEtBQUssVUFBVSxFQUFHLEVBQzlCLEtBQ0csU0FBUyxNQUFLO0FBQ1YsaUJBQUssWUFBWTtVQUNyQixDQUFDLENBQUMsRUFFTCxVQUFVO1lBQ1AsTUFBTSxDQUFDLGFBQVk7QUFDZixtQkFBSyxvQkFBb0IsU0FBUztBQUNsQyxtQkFBSyxZQUFZLEtBQUssa0JBQWtCO0FBQ3hDLG1CQUFLLHNCQUFzQjtBQUMzQixtQkFBSyxhQUFhLFFBQVEsMkJBQTJCO1lBQ3pEO1lBQ0EsT0FBTyxDQUFDLFFBQTBCO0FBQzlCLG1CQUFLLFFBQVEsR0FBRztZQUNwQjtXQUNIO2VBQ0Y7QUFDSCxlQUFLLHNCQUFzQjs7TUFFbkM7TUFFQSxlQUFZO0FBQ1IsK0JBQXVCLEtBQUssVUFBVSxLQUFLLFFBQVEsS0FBSyxVQUFVLEtBQUssWUFBWSxLQUFLLFNBQVM7TUFDckc7TUFFQSxhQUFVO0FBQ04sYUFBSyx5QkFBeUIsV0FBVyxLQUFLLFVBQVUsRUFBRyxFQUFFLFVBQVU7VUFDbkUsTUFBTSxNQUFLO0FBQ1AsaUJBQUssYUFBYSxRQUFRLDhCQUE4QjtBQUN4RCxpQkFBSyxhQUFZO1VBQ3JCO1VBQ0EsT0FBTyxDQUFDLFFBQTBCO0FBQzlCLGlCQUFLLFFBQVEsR0FBRztVQUNwQjtTQUNIO01BQ0w7TUFFQSxtQkFBbUIsaUJBQXdCO0FBQ3ZDLFlBQUksQ0FBQyxLQUFLLGtCQUFrQixnQkFBZ0IsS0FBSyxrQkFBa0IsYUFBYSxVQUFVLEdBQUc7QUFDekYsZUFBSyxhQUFhLE1BQU0scUNBQXFDO0FBQzdEOztBQUVKLFlBQUksS0FBSyxrQkFBa0IsYUFBYSxTQUFTLEtBQUssK0JBQStCO0FBQ2pGLGVBQUssYUFBYSxNQUFNLDJEQUEyRDtZQUMvRSw4QkFBOEIsS0FBSztXQUN0QztBQUNEOztBQUVKLFlBQUksQ0FBQyxLQUFLLG9CQUFvQjtBQUMxQjs7QUFHSixhQUFLLGtCQUFrQixZQUFZLEtBQUs7QUFDeEMsYUFBSyxrQkFBa0IsVUFBVSxvQkFBb0I7QUFDckQsYUFBSyxrQkFBa0IsVUFBVyxXQUFXO0FBRTdDLFlBQUksbUJBQW1CLEtBQUssVUFBVSxrQkFBa0IsY0FBYyxXQUFXO0FBRzdFLGVBQUssWUFBWTtBQUNqQixlQUFLLCtCQUErQixLQUFLO1lBQ3JDLG1CQUFtQixLQUFLO1lBQ3hCLFdBQVcsTUFBSztBQUNaLG1CQUFLLFlBQVk7QUFDakIsbUJBQUssVUFBVTtBQUNmLG1CQUFLLG1CQUFtQjtBQUN4QixtQkFBSyxzQkFBc0I7WUFDL0I7WUFDQSxTQUFTLE1BQUs7QUFDVixtQkFBSyxZQUFZO1lBQ3JCO1dBQ0g7ZUFDRTtBQUVILGVBQUssaUJBQWdCOztNQUU3QjtNQUVRLG1CQUFnQjtBQUNwQixhQUFLLFlBQVk7QUFDakIsYUFBSyx5QkFDQSxpQkFBaUIsS0FBSyxpQkFBaUIsRUFDdkMsS0FDRyxTQUFTLE1BQUs7QUFDVixlQUFLLFlBQVk7UUFDckIsQ0FBQyxDQUFDLEVBRUwsVUFBVTtVQUNQLE1BQU0sQ0FBQyxhQUFZO0FBQ2YsaUJBQUssVUFBVTtBQUNmLGdCQUFJLEtBQUssVUFBVSxrQkFBa0IsY0FBYyxlQUFlO0FBQzlELG1CQUFLLGFBQWEsUUFBUSx5Q0FBeUM7bUJBQ2hFO0FBQ0gsbUJBQUssYUFBYSxRQUFRLHNDQUFzQzs7QUFFcEUsaUJBQUssb0JBQW9CLFNBQVM7QUFDbEMsaUJBQUssWUFBWSxLQUFLLGtCQUFrQjtBQUN4QyxpQkFBSywwQkFBMEI7QUFDL0IsaUJBQUssbUJBQW1CO0FBQ3hCLGlCQUFLLHNCQUFzQjtVQUMvQjtVQUNBLE9BQU8sQ0FBQyxRQUEwQjtBQUM5QixpQkFBSyxRQUFRLEdBQUc7VUFDcEI7U0FDSDtNQUNUO01BRUEsUUFBUSxtQkFBb0M7QUFDeEMsY0FBTSxRQUFRLGtCQUFrQjtBQUNoQyxZQUFJLFNBQVMsTUFBTSxZQUFZLE1BQU0sYUFBYSxpQkFBaUI7QUFDL0QsZUFBSyxhQUFhLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTTtlQUNoRDtBQUNILGVBQUssYUFBYSxNQUFNLHlCQUF5QjtZQUM3QyxPQUFPLGtCQUFrQjtXQUM1Qjs7TUFFVDtNQU9BLElBQUkscUJBQWtCO0FBQ2xCLGVBQU8sb0NBQW9DLEtBQUssV0FBVyxLQUFLLFlBQVksS0FBSyxXQUFXLEtBQUssUUFBUTtNQUM3RztNQUtBLDhCQUEyQjtBQUN2QixjQUFNLFdBQWdDLFNBQVMsY0FBYyxtQkFBbUI7QUFDaEYsZUFBTyxTQUFTLE1BQU07TUFDMUI7O3lCQWpPUyw4QkFBMkIsK0JBQUEsWUFBQSxHQUFBLCtCQUFBLHdCQUFBLEdBQUEsK0JBQUEsaUJBQUEsR0FBQSwrQkFBQSxTQUFBLEdBQUEsK0JBQUEsV0FBQSxDQUFBO01BQUE7Z0VBQTNCLDhCQUEyQixXQUFBLENBQUEsQ0FBQSwrQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFdBQUEsYUFBQSxXQUFBLGFBQUEsWUFBQSxjQUFBLFlBQUEsY0FBQSxVQUFBLFlBQUEsWUFBQSxhQUFBLEdBQUEsU0FBQSxFQUFBLGdDQUFBLGlDQUFBLEdBQUEsVUFBQSxDQUFBLGdDQUZ6QixDQUFBLENBQUUsQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxVQUFBLHdCQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLFVBQUEsR0FBQSxDQUFBLE1BQUEscUJBQUEsUUFBQSxLQUFBLEdBQUEsVUFBQSxRQUFBLEdBQUEsV0FBQSxZQUFBLFlBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLFlBQUEsR0FBQSxDQUFBLE1BQUEsZ0JBQUEsR0FBQSxTQUFBLFlBQUEsR0FBQSxDQUFBLE1BQUEsY0FBQSxHQUFBLE9BQUEsaUJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxhQUFBLEdBQUEsQ0FBQSxNQUFBLG9CQUFBLFFBQUEsS0FBQSxVQUFBLGlCQUFBLEdBQUEsVUFBQSxRQUFBLEdBQUEsYUFBQSxXQUFBLFlBQUEsWUFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsV0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsYUFBQSxTQUFBLDJCQUFBLE1BQUEsR0FBQSxDQUFBLE1BQUEseUJBQUEsUUFBQSxVQUFBLEdBQUEsT0FBQSxlQUFBLGFBQUEsR0FBQSxZQUFBLFNBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSx5QkFBQSxRQUFBLFVBQUEsR0FBQSxPQUFBLGNBQUEsYUFBQSxHQUFBLFlBQUEsU0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLHVCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsTUFBQSwrQkFBQSxRQUFBLFVBQUEsR0FBQSxPQUFBLGVBQUEsYUFBQSxHQUFBLFlBQUEsU0FBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEscUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNwQmpCLFVBQUEsd0JBQUEsR0FBQSxvREFBQSxJQUFBLENBQUEsRUFNQyxHQUFBLG9EQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsb0RBQUEsSUFBQSxFQUFBOzs7QUFORCxVQUFBLDJCQUFBLEdBQUEsSUFBQSxZQUFBLElBQUEsRUFBQTtBQU9BLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsMkJBQUEsR0FBQSxDQUFBLElBQUEsYUFBQSxJQUFBLFlBQUEsSUFBQSxFQUFBO0FBS0EsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSwyQkFBQSxHQUFBLENBQUEsSUFBQSxhQUFBLElBQUEsWUFBQSxJQUFBLEVBQUE7Ozs7O29GRFVhLDZCQUEyQixFQUFBLFdBQUEsOEJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFdEJ4QyxTQUFTLGdCQUFnQjs7QUFBekIsSUFhYTtBQWJiOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFRTSxJQUFPLGtDQUFQLE1BQU8saUNBQStCOzt5QkFBL0Isa0NBQStCO01BQUE7Z0VBQS9CLGlDQUErQixDQUFBO3FFQUY3QixDQUFDLGtCQUFrQix3QkFBd0IsR0FBQyxTQUFBLENBSDdDLHFCQUFxQixjQUFjLEVBQUEsQ0FBQTs7Ozs7O0FDUmpELFNBQVMsYUFBQUEsWUFBVyxTQUFBQyxjQUFxQjtBQUl6QyxTQUFTLFFBQVEsZUFBZTs7Ozs7Ozs7QUNINUIsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQW1FLElBQUEseUJBQUEsU0FBQSxTQUFBLHNGQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxPQUFBLE9BQUEsQ0FBUTtJQUFBLENBQUE7QUFBRSxJQUFBLDJCQUFBO0FBQzFGLElBQUEscUJBQUEsR0FBQSxJQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsUUFBQSxFQUFpQixjQUFBLE9BQUEsV0FBQSxPQUFBLFdBQUEsQ0FBQTs7Ozs7O0FBRzFCLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUlJLElBQUEseUJBQUEsY0FBQSxTQUFBLDJGQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBYywwQkFBQSxPQUFBLE9BQUEsQ0FBUTtJQUFBLENBQUEsRUFBQyxTQUFBLFNBQUEsc0ZBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUNkLDBCQUFBLE9BQUEsV0FBQSxDQUFZO0lBQUEsQ0FBQTs7QUFDeEIsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSxJQUFBOzs7O0FBTlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLGFBQUEsRUFBeUIsUUFBQSxPQUFBLFdBQUEsRUFBQSxjQUFBLDBCQUFBLEdBQUEsR0FBQSxnRUFBQSxDQUFBOzs7QURMakMsSUFVYTtBQVZiOztBQUVBO0FBQ0E7O0FBT00sSUFBTyxzQ0FBUCxNQUFPLHFDQUFtQztNQU94QjtNQU5YLFdBQVc7TUFDWDtNQUNUO01BQ0EsY0FBYztNQUNkLGNBQWM7TUFFZCxZQUFvQixzQkFBMEM7QUFBMUMsYUFBQSx1QkFBQTtNQUE2QztNQUVqRSxXQUFRO0FBQ0osYUFBSyxjQUFjLEtBQUssU0FBUztNQUNyQztNQUtBLGFBQVU7QUFDTixhQUFLLE9BQU07QUFDWCxhQUFLLFNBQVMscUJBQXFCO01BQ3ZDO01BTUEsV0FBVyxhQUErQjtBQUN0QyxlQUFPLEtBQUsscUJBQXFCLFVBQVUsMkNBQTJDLElBQUksWUFBWTtNQUMxRztNQUtBLFNBQU07QUFDRixhQUFLLGNBQWMsQ0FBQyxLQUFLO01BQzdCOzt5QkFsQ1Msc0NBQW1DLGdDQUFBLG9CQUFBLENBQUE7TUFBQTtpRUFBbkMsc0NBQW1DLFdBQUEsQ0FBQSxDQUFBLG1DQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLFVBQUEsV0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxRQUFBLGNBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLFFBQUEsY0FBQSxjQUFBLE9BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSw2Q0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1ZoRCxVQUFBLHlCQUFBLEdBQUEsNERBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSw0REFBQSxHQUFBLENBQUE7OztBQUZELFVBQUEsNEJBQUEsR0FBQSxDQUFBLElBQUEsY0FBQSxJQUFBLEVBQUE7QUFHQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxjQUFBLElBQUEsRUFBQTs7Ozs7cUZET2EscUNBQW1DLEVBQUEsV0FBQSxzQ0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVWaEQsU0FBUyxZQUFBQyxpQkFBZ0I7O0FBQXpCLElBVWE7QUFWYjs7QUFFQTtBQUNBO0FBT00sSUFBTywwQ0FBUCxNQUFPLHlDQUF1Qzs7eUJBQXZDLDBDQUF1QztNQUFBO2dFQUF2Qyx5Q0FBdUMsQ0FBQTtvRUFKdEMsbUJBQW1CLEVBQUEsQ0FBQTs7Ozs7O0FDRGpDLElBQVkseUJBU0M7QUFUYjs7QUFBQSxLQUFBLFNBQVlDLDBCQUF1QjtBQUMvQixNQUFBQSx5QkFBQSwyQ0FBQSxJQUFBO0FBQ0EsTUFBQUEseUJBQUEsc0NBQUEsSUFBQTtBQUNBLE1BQUFBLHlCQUFBLGlCQUFBLElBQUE7QUFDQSxNQUFBQSx5QkFBQSx5QkFBQSxJQUFBO0FBQ0EsTUFBQUEseUJBQUEsbUJBQUEsSUFBQTtBQUNBLE1BQUFBLHlCQUFBLHdCQUFBLElBQUE7SUFDSixHQVBZLDRCQUFBLDBCQUF1QixDQUFBLEVBQUE7QUFTN0IsSUFBTyxzQkFBUCxNQUEwQjtNQUNyQjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUVQLFlBQVksUUFBaUIsVUFBbUIsZ0JBQXlCLGlCQUEwQixjQUFxQjtBQUNwSCxhQUFLLFNBQVM7QUFDZCxhQUFLLFdBQVc7QUFDaEIsYUFBSyxpQkFBaUI7QUFDdEIsYUFBSyxrQkFBa0I7QUFDdkIsYUFBSyxlQUFlO01BQ3hCO01BRUEsYUFBYSxNQUE2QjtBQUN0QyxhQUFLLFlBQVk7QUFDakIsZUFBTztNQUNYO01BRUEsZ0JBQWdCLE1BQW1CO0FBQy9CLGFBQUssZUFBZTtNQUN4QjtNQUVBLGVBQWUsTUFBb0I7QUFDL0IsYUFBSyxjQUFjO01BQ3ZCOzs7Ozs7QUM3Q0osU0FBUyxrQkFBa0I7QUFRM0IsU0FBUyxZQUFBQyxpQkFBZ0I7OztBQVJ6QixJQWNhO0FBZGI7O0FBRUE7QUFDQTtBQUNBO0FBR0E7Ozs7QUFPTSxJQUFPLDBCQUFQLE1BQU8seUJBQXVCO01BWWxCO01BQ0E7TUFDRjtNQUNEO01BZEg7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLGNBQW1DLElBQUksb0JBQW1CO01BQzFELGdCQUFnQjtNQUNoQjtNQUNELG1CQUFtQjtNQUUxQixZQUNjLG9CQUNBLGdCQUNGLGdCQUNELFVBQWtCO0FBSGYsYUFBQSxxQkFBQTtBQUNBLGFBQUEsaUJBQUE7QUFDRixhQUFBLGlCQUFBO0FBQ0QsYUFBQSxXQUFBO0FBR1AsYUFBSyxlQUFlLGVBQWMsRUFBRyxVQUFVLENBQUMsZ0JBQWU7QUFDM0QsZUFBSyxtQkFBbUIsWUFBWSxrQ0FBa0M7UUFDMUUsQ0FBQztNQUNMO01BT0Esa0JBQWtCLE9BQXFCO0FBQ25DLFlBQUksS0FBSyxrQkFBa0I7QUFDdkIsZUFBSyxRQUFRO0FBQ2IsZUFBSywyQkFBMEI7O01BRXZDO01BUUEsb0JBQW9CLFdBQW9DLGVBQXlDLFFBQVcsZ0JBQTJDLFFBQVM7QUFDNUosWUFBSSxLQUFLLG9CQUFvQixDQUFDLEtBQUsseUJBQXdCLEdBQUk7QUFDM0QsZUFBSyxZQUFZLGFBQWEsU0FBUztBQUN2QyxlQUFLLFlBQVksZ0JBQWdCLFlBQVk7QUFDN0MsZUFBSyxZQUFZLGVBQWUsYUFBYTtBQUM3QyxlQUFLLG1CQUFtQix1QkFBdUIsS0FBSyxXQUFXLEVBQUUsVUFBVTtZQUN2RSxPQUFPLENBQUMsTUFBTSxRQUFRLE1BQU0sK0JBQStCLEVBQUUsT0FBTztXQUN2RTs7TUFFVDtNQUVRLDJCQUF3QjtBQUM1QixlQUFPLENBQUMsQ0FBQyxLQUFLLFVBQVUsS0FBSSxFQUFHLFNBQVMsb0JBQW9CO01BQ2hFO01BS1EsNkJBQTBCO0FBQzlCLGFBQUssTUFBTSxPQUFPLFVBQVUsQ0FBQyxXQUFVO0FBQ25DLGVBQUssU0FBUyxLQUFLLGVBQWUsZUFBZSxPQUFPLEtBQUssZUFBZSxhQUFhLEVBQUUsSUFBSSxLQUFLO0FBQ3BHLGVBQUssV0FBVyxPQUFPLE9BQU8sVUFBVSxDQUFDO0FBQ3pDLGVBQUssaUJBQWlCLE9BQU8sT0FBTyxZQUFZLENBQUM7QUFDakQsZUFBSyxrQkFBa0IsT0FBTyxPQUFPLGlCQUFpQixDQUFDO0FBQ3ZELGVBQUssZUFBZSxPQUFPLE9BQU8sY0FBYyxDQUFDO0FBQ2pELGVBQUssY0FBYyxJQUFJLG9CQUFvQixLQUFLLFFBQVEsS0FBSyxVQUFVLEtBQUssZ0JBQWdCLEtBQUssaUJBQWlCLEtBQUssWUFBWTtRQUN2SSxDQUFDO01BQ0w7O3lCQXBFUywwQkFBdUIsdUJBQUEscUJBQUEsR0FBQSx1QkFBQSxjQUFBLEdBQUEsdUJBQUEsY0FBQSxHQUFBLHVCQUFBLFlBQUEsQ0FBQTtNQUFBO29FQUF2QiwwQkFBdUIsU0FBdkIseUJBQXVCLFdBQUEsWUFEVixPQUFNLENBQUE7Ozs7OztBQ2JoQyxTQUFTLGFBQUFDLFlBQVcsZ0JBQUFDLGVBQWMsY0FBYyxTQUFBQyxRQUFPLFVBQUFDLGVBQWM7QUFLckUsU0FBUyxrQkFBQUMsdUJBQXNCO0FBRy9CLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsUUFBUSxpQkFBaUI7QUFDbEMsU0FBUywwQkFBMEI7Ozs7Ozs7O0FDTnZCLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFBc0QsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBVSxJQUFBLDJCQUFBO0FBQ3BFLElBQUEscUJBQUEsR0FBQSxZQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFBNkQsSUFBQSxxQkFBQSxHQUFBLHFCQUFBO0FBQW1CLElBQUEsMkJBQUE7QUFDcEYsSUFBQSxxQkFBQSxHQUFBLFlBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxpRkFBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7Ozs7O0FBR0EsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsYUFBQSxDQUFBO0FBQXVELElBQUEseUJBQUEsU0FBQSxTQUFBLDhFQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBQSwwQkFBQSxPQUFBLDZCQUFzQyxLQUFLO0lBQUEsQ0FBQTtBQUM5RixJQUFBLHFCQUFBLEdBQUEsb0hBQUE7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7OztBQUhlLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsYUFBQSxLQUFBO0FBQXlCLElBQUEseUJBQUEsUUFBQSxTQUFBOzs7OztBQU81QixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBT0ksSUFBQSxxQkFBQSxHQUFBLHlFQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQUpRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsOEJBQUEsR0FBQUMsT0FBQSxPQUFBLFVBQUEsT0FBQSxPQUFBLE9BQUEsT0FBQSxZQUFBLE9BQUEsT0FBQSxPQUFBLE9BQUEsU0FBQSxRQUFBLFFBQUEsT0FBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLE9BQUEsWUFBQSxPQUFBLE9BQUEsT0FBQSxPQUFBLFNBQUEsU0FBQSxHQUFBLENBQUE7Ozs7O0FBY0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxzRkFBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7O0FBV0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxrRkFBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFnSCxJQUFBLHFCQUFBLEdBQUEseUNBQUE7QUFBc0MsSUFBQSwyQkFBQTtBQUMxSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7O0FBV0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSwyRUFBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7O0FBV0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSwrR0FBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnR0FBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSwrRUFBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7O0FBS1ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTs7QUFHSyxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBa0IsSUFBQSwyQkFBQTtBQUUzQixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7OztBQUpRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsb0NBQUEsY0FBQSwwQkFBQSxHQUFBLEdBQUEsaUVBQUEsQ0FBQTs7Ozs7QUFNSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBOztBQUdLLElBQUEscUJBQUEsR0FBQSxzQkFBQTtBQUFvQixJQUFBLDJCQUFBO0FBRTdCLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7O0FBSlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxjQUFBLDBCQUFBLEdBQUEsR0FBQSxrRUFBQSxDQUFBOzs7Ozs7QUFWWixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQXFDLElBQUEseUJBQUEsU0FBQSxTQUFBLDJGQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsMkJBQUEsQ0FBNEI7SUFBQSxDQUFBO0FBQ3RFLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxnRkFBQSxHQUFBLENBQUEsRUFNQyxHQUFBLGdGQUFBLEdBQUEsQ0FBQTtBQVFMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFoQmdGLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxRQUFBLFlBQUEsUUFBQSxjQUFBLFFBQUEsVUFBQTtBQUN4RSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxRQUFBLHVCQUFBLElBQUEsRUFBQTtBQU9BLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLHVCQUFBLElBQUEsRUFBQTs7Ozs7QUFtQlEsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUEwQyxJQUFBLHFCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsMkJBQUE7QUFDcEQsSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsU0FBQSxFQUFrQixRQUFBLElBQUE7Ozs7O0FBYTNCLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxXQUFBLEVBQUE7QUFBMEMsSUFBQSxxQkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLDJCQUFBO0FBQ3BELElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQURhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLFNBQUEsRUFBa0IsUUFBQSxJQUFBOzs7OztBQVd2QixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQTBDLElBQUEscUJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSwyQkFBQTtBQUNwRCxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7QUFEYSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxTQUFBLEVBQWtCLFFBQUEsSUFBQTs7Ozs7O0FBTm5DLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFFSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSwwR0FBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLE9BQUEsS0FBQSxDQUFhO0lBQUEsQ0FBQTtBQUd0QixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsK0ZBQUEsR0FBQSxDQUFBO0FBR0EsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUEwQyxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUE7QUFDcEQsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQVBRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxHQUFBLFFBQUEsWUFBQSxPQUFBLE9BQUEsUUFBQSxTQUFBLHdCQUFBLFFBQUEsZUFBQSxRQUFBLFlBQUEsUUFBQSxjQUFBLFFBQUEsVUFBQTtBQUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLGFBQUEsSUFBQSxFQUFBOzs7Ozs7QUE5QlIsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUVJLElBQUEseUJBQUEsU0FBQSxTQUFBLDJGQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsS0FBQSxLQUFBLENBQVc7SUFBQSxDQUFBOztBQUlwQixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsZ0ZBQUEsR0FBQSxDQUFBO0FBR0EsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBd0MsSUFBQSxxQkFBQSxHQUFBLE1BQUE7QUFBSSxJQUFBLDJCQUFBO0FBQ2hELElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBR0ksSUFBQSx5QkFBQSxTQUFBLFNBQUEsNEZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFTLGNBQUEsT0FBQSxLQUFBO0FBQWEsYUFBRSwwQkFBQSxRQUFBLHFDQUFBLENBQXNDO0lBQUEsQ0FBQTs7QUFJOUQsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLGlGQUFBLEdBQUEsQ0FBQTtBQUdBLElBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBMEMsSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBTSxJQUFBLDJCQUFBO0FBQ3BELElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsaUZBQUEsR0FBQSxDQUFBOzs7O0FBckJJLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxRQUFBLFlBQUEsRUFBeUIsY0FBQSwwQkFBQSxHQUFBLEdBQUEsc0NBQUEsSUFBQSxNQUFBO0FBR3pCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLFdBQUEsSUFBQSxFQUFBO0FBR1MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsTUFBQTtBQU9ULElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxRQUFBLGNBQUEsRUFBMkIsY0FBQSwwQkFBQSxJQUFBLElBQUEsc0NBQUEsSUFBQSxVQUFBO0FBRzNCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLGFBQUEsS0FBQSxFQUFBO0FBS0osSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLENBQUEsUUFBQSxZQUFBLEtBQUEsRUFBQTs7Ozs7QUFxQlEsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUEwQyxJQUFBLHFCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsMkJBQUE7QUFDcEQsSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsU0FBQSxFQUFrQixRQUFBLElBQUE7Ozs7OztBQVBuQyxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBRUksSUFBQSx5QkFBQSxTQUFBLFNBQUEsMkZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxPQUFBLEtBQUEsQ0FBYTtJQUFBLENBQUE7O0FBSXRCLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxnRkFBQSxHQUFBLENBQUE7QUFHQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXFFLElBQUEscUJBQUEsR0FBQSxxQkFBQTtBQUFtQixJQUFBLDJCQUFBO0FBQzVGLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUFSUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsUUFBQSxnQkFBQSxFQUE2QixjQUFBLDBCQUFBLEdBQUEsR0FBQSxzQ0FBQSxJQUFBLFVBQUE7QUFHN0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsYUFBQSxJQUFBLEVBQUE7Ozs7O0FBU0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQURhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLFNBQUEsRUFBa0IsUUFBQSxJQUFBOzs7Ozs7QUFGbkMsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFnRSxJQUFBLHlCQUFBLFNBQUEsU0FBQSwyRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLDhCQUFBLENBQStCO0lBQUEsQ0FBQTtBQUNwRyxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsZ0ZBQUEsR0FBQSxDQUFBO0FBR0EsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUF5RSxJQUFBLHFCQUFBLEdBQUEsMkJBQUE7QUFBeUIsSUFBQSwyQkFBQTtBQUN0RyxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7O0FBTFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsYUFBQSxJQUFBLEVBQUE7Ozs7O0FBT0osSUFBQSxxQkFBQSxDQUFBOztBQUEwRSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQzlFLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQURJLElBQUEsaUNBQUEsMEJBQUEsMEJBQUEsR0FBQSxHQUFBLHNDQUFBLEdBQUEsYUFBQTtBQUFtRixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxrQkFBQTs7Ozs7QUFXM0UsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUEwQyxJQUFBLHFCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsMkJBQUE7QUFDcEQsSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsU0FBQSxFQUFrQixRQUFBLElBQUE7Ozs7OztBQVJuQyxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBSUksSUFBQSx5QkFBQSxTQUFBLFNBQUEsMkZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFTLGNBQUEsZUFBQSxLQUFBO0FBQXFCLGFBQUUsMEJBQUEsUUFBQSwrQkFBQSxDQUFnQztJQUFBLENBQUE7QUFHaEUsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLGdGQUFBLEdBQUEsQ0FBQTtBQUdBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBaUUsSUFBQSxxQkFBQSxHQUFBLGlCQUFBO0FBQWUsSUFBQSwyQkFBQTtBQUNwRixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7Ozs7QUFUUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsUUFBQSxrQkFBQSxFQUErQixjQUFBLElBQUE7QUFJL0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEscUJBQUEsSUFBQSxFQUFBOzs7OztBQTNLaEIsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLGlFQUFBLEdBQUEsQ0FBQSxFQVVDLEdBQUEsaUVBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSxpRUFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLGlFQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsaUVBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSxpRUFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLGlFQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsa0VBQUEsR0FBQSxDQUFBO0FBc0VELElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxrRUFBQSxHQUFBLENBQUE7QUFrQkEsSUFBQSx3QkFBQSxJQUFBLElBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLGtFQUFBLElBQUEsRUFBQSxFQXFDQyxJQUFBLGtFQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsa0VBQUEsR0FBQSxDQUFBLEVBQUEsSUFBQSxrRUFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUE7QUF5QkQsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLGtFQUFBLEdBQUEsQ0FBQTtBQWNBLElBQUEsNkJBQUEsSUFBQSxLQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQXFELElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFrQixJQUFBLDJCQUFBO0FBQzNFLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7Ozs7QUFyTFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsT0FBQSxjQUFBLENBQUEsT0FBQSxlQUFBLElBQUEsRUFBQTtBQVdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLGNBQUEsT0FBQSxZQUFBLENBQUEsT0FBQSxTQUFBLHVCQUFBLE9BQUEsZ0JBQUEsT0FBQSxpQkFBQSxPQUFBLGNBQUEsYUFBQSxDQUFBLE9BQUEsb0JBQUEsT0FBQSxTQUFBLG1CQUFBLE9BQUEsZUFBQSxZQUFBLElBQUEsRUFBQTtBQWFBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLGNBQUEsT0FBQSxZQUFBLENBQUEsT0FBQSxTQUFBLHVCQUFBLE9BQUEsZ0JBQUEsT0FBQSxpQkFBQSxPQUFBLGNBQUEsYUFBQSxPQUFBLFNBQUEsbUJBQUEsT0FBQSxlQUFBLGFBQUEsQ0FBQSxPQUFBLG9CQUFBLENBQUEsT0FBQSxTQUFBLFdBQUEsSUFBQSxFQUFBO0FBY0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsY0FBQSxPQUFBLFlBQUEsQ0FBQSxPQUFBLFNBQUEsdUJBQUEsT0FBQSxnQkFBQSxPQUFBLGlCQUFBLE9BQUEsY0FBQSxhQUFBLENBQUEsT0FBQSxvQkFBQSxPQUFBLFNBQUEsV0FBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxjQUFBLE9BQUEsWUFBQSxDQUFBLE9BQUEsU0FBQSx1QkFBQSxPQUFBLGdCQUFBLE9BQUEsaUJBQUEsT0FBQSxjQUFBLGFBQUEsT0FBQSxTQUFBLG1CQUFBLE9BQUEsZUFBQSxhQUFBLENBQUEsT0FBQSxvQkFBQSxDQUFBLE9BQUEsU0FBQSxXQUFBLElBQUEsRUFBQTtBQWNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLGNBQUEsT0FBQSxZQUFBLENBQUEsT0FBQSxTQUFBLHVCQUFBLE9BQUEsZ0JBQUEsT0FBQSxTQUFBLG1CQUFBLE9BQUEsZUFBQSxhQUFBLE9BQUEsaUJBQUEsT0FBQSxjQUFBLGFBQUEsQ0FBQSxPQUFBLG9CQUFBLENBQUEsT0FBQSxTQUFBLFdBQUEsSUFBQSxFQUFBO0FBY0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsY0FBQSxPQUFBLFlBQUEsQ0FBQSxPQUFBLFNBQUEsdUJBQUEsT0FBQSxnQkFBQSxPQUFBLG9CQUFBLENBQUEsT0FBQSxTQUFBLFdBQUEsSUFBQSxFQUFBO0FBS0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsZUFBQSxDQUFBLE9BQUEsaUJBQUEsT0FBQSxZQUFBLE9BQUEsT0FBQSxPQUFBLFNBQUEsd0JBQUEsS0FBQSxFQUFBO0FBTUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLENBQUEsT0FBQSx5QkFBQSxPQUFBLFVBQUEsT0FBQSxrQkFBQSxJQUFBLEtBQUEsRUFBQTtBQW9CSSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsRUFBQSxPQUFBLFVBQUEsT0FBQSxPQUFBLE9BQUEsT0FBQSxrQkFBQSxLQUFBLEVBQUE7QUFzQ0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsa0JBQUEsS0FBQSxFQUFBO0FBYUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxLQUFBLE9BQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxPQUFBLG9CQUFBLE9BQUEsWUFBQSxPQUFBLE9BQUEsT0FBQSxTQUFBLHlCQUFBLE9BQUEsU0FBQSxTQUFBLE9BQUEsYUFBQSxZQUFBLE9BQUEsU0FBQSxTQUFBLE9BQUEsYUFBQSxRQUFBLEtBQUEsRUFBQTtBQVdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLG9CQUFBLEtBQUEsRUFBQTtBQWNHLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSxPQUFBLHFCQUFBOzs7OztBQVFmLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLDBCQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsSUFBQTs7OztBQUQ0QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsT0FBQSxRQUFBOzs7QUQ5TTVCLFVBdUJhO0FBdkJiOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7Ozs7O0FBZ0JNLElBQU8sNEJBQVAsTUFBTywyQkFBeUI7TUFpRHZCO01BQ0c7TUFDRjtNQWxESDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0Esa0JBQWtCO01BRWxCO01BQ0E7TUFDQSxZQUFZO01BQ1o7TUFDQTtNQUVBO01BQ0E7TUFDQTtNQUNBLGVBQWU7TUFDZix5QkFBeUI7TUFDekIsbUJBQW1CO01BQ25CO01BQ0E7TUFDQTtNQUNBLHdCQUF3QjtNQUV2QixPQUFPLElBQUlKLGNBQVk7TUFFdkIsU0FBUyxJQUFJQSxjQUFZO01BQ3pCLFNBQVMsSUFBSUEsY0FBWTtNQUN6QixpQkFBaUIsSUFBSUEsY0FBWTtNQUNqQyw2QkFBNkIsSUFBSUEsY0FBWTtNQUM3Qyx5QkFBeUIsSUFBSUEsY0FBWTtNQUUzQztNQUNDLGVBQWU7TUFDZixnQkFBZ0I7TUFDaEIsaUJBQWlCO01BRzFCLFlBQVk7TUFDWixTQUFTO01BQ1QscUJBQXFCO01BRXJCLElBQWEscUJBQXFCLHNCQUE2QjtBQUMzRCxhQUFLLHdCQUF3QjtBQUM3QixhQUFLLDJCQUEyQixLQUFLLEtBQUssb0JBQW9CO01BQ2xFO01BRUEsWUFDVyx5QkFDRyxPQUNGLGtCQUFrQztBQUZuQyxhQUFBLDBCQUFBO0FBQ0csYUFBQSxRQUFBO0FBQ0YsYUFBQSxtQkFBQTtBQUVSLGdDQUF3QixrQkFBa0IsS0FBSztNQUNuRDtNQUVBLElBQUksdUJBQW9CO0FBQ3BCLGVBQU8sS0FBSztNQUNoQjtNQUVBLElBQUksa0JBQWU7QUFDZixlQUFPLEtBQUssUUFBUSxrQkFBa0IsS0FBSztNQUMvQztNQUVBLElBQUksb0JBQWlCO0FBQ2pCLGVBQU8sS0FBSyxRQUFRLG1CQUFtQixLQUFLLGNBQWMsS0FBSyxVQUFVLHdCQUF3QixDQUFDLEtBQUssZ0JBQWdCLENBQUMsS0FBSyxjQUFjLENBQUMsS0FBSztNQUNySjtNQUVBLElBQUksZUFBWTtBQUVaLFlBQUksS0FBSyxRQUFRLGdCQUFnQjtBQUM3QixpQkFBTztlQUNKO0FBQ0gsaUJBQU8sQ0FBQyxLQUFLLHVCQUF1QixDQUFDLEtBQUssY0FBYyxLQUFLLFlBQVksS0FBSyxjQUFjLEtBQUs7O01BRXpHO01BRUEsSUFBSSxpQkFBYztBQUNkLGVBQU8sQ0FBQyxLQUFLLHVCQUF1QixDQUFDLEtBQUssY0FBYyxLQUFLLFlBQVksS0FBSyxjQUFjLEtBQUs7TUFDckc7TUFFQSxJQUFJLG1CQUFnQjtBQUNoQixZQUFJLEtBQUssaUJBQWlCO0FBQ3RCLGlCQUFPLENBQUMsS0FBSyx1QkFBdUIsS0FBSztlQUN0QztBQUNILGlCQUFPOztNQUVmO01BRUEsSUFBSSxxQkFBa0I7QUFDbEIsWUFBSSxLQUFLLG1CQUFtQjtBQUN4QixpQkFBTyxLQUFLLHNCQUFzQixLQUFLO2VBQ3BDO0FBQ0gsaUJBQU87O01BRWY7TUFHQSxrQkFBa0IsT0FBb0I7QUFDbEMsY0FBTSxlQUFjO0FBQ3BCLFlBQUksQ0FBQyxLQUFLLGNBQWM7QUFDcEIsZUFBSyxLQUFLLEtBQUk7O01BRXRCO01BR0Esd0JBQXdCLE9BQW9CO0FBQ3hDLGNBQU0sZUFBYztBQUNwQixZQUFJLENBQUMsS0FBSyxrQkFBa0I7QUFDeEIsZUFBSyxPQUFPLEtBQUk7bUJBQ1QsQ0FBQyxLQUFLLGdCQUFnQjtBQUM3QixlQUFLLE9BQU8sS0FBSTtBQUNoQixlQUFLLHFDQUFvQzs7TUFFakQ7TUFHQSxzQ0FBc0MsT0FBb0I7QUFDdEQsY0FBTSxlQUFjO0FBQ3BCLFlBQUksQ0FBQyxLQUFLLG9CQUFvQjtBQUMxQixlQUFLLGVBQWUsS0FBSTtBQUN4QixlQUFLLCtCQUE4Qjs7TUFFM0M7TUFNTyw2QkFBMEI7QUFDN0IsYUFBSyx1QkFBdUIsQ0FBQyxLQUFLO0FBQ2xDLGFBQUssMkJBQTJCLEtBQUssS0FBSyxvQkFBb0I7TUFDbEU7TUFLQSx1Q0FBb0M7QUFDaEMsWUFBSSxLQUFLLFVBQVUsU0FBUyxhQUFhLE1BQU07QUFDM0MsZUFBSyx3QkFBd0Isb0JBQW9CLHdCQUF3QixpQkFBaUI7O01BRWxHO01BS0EsaUNBQThCO0FBQzFCLFlBQUksS0FBSyxVQUFVLFNBQVMsYUFBYSxNQUFNO0FBQzNDLGVBQUssd0JBQXdCLG9CQUFvQix3QkFBd0Isc0JBQXNCOztNQUV2RztNQUtBLGdDQUE2QjtBQUN6QixjQUFNLHNCQUFzQixLQUFLLGlCQUFpQixRQUFRLGtFQUFrRTtBQUM1SCxZQUFJLFFBQVEsbUJBQW1CLEdBQUc7QUFDOUIsZUFBSyx1QkFBdUIsS0FBSTs7TUFFeEM7O3lCQWhLUyw0QkFBeUIsZ0NBQUEsdUJBQUEsR0FBQSxnQ0FBQSxrQkFBQSxHQUFBLGdDQUFBLG9CQUFBLENBQUE7TUFBQTtpRUFBekIsNEJBQXlCLFdBQUEsQ0FBQSxDQUFBLHVCQUFBLENBQUEsR0FBQSxjQUFBLFNBQUEsdUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7O21CQUF6QixJQUFBLGtCQUFBLE1BQUE7VUFBeUIsR0FBQSxPQUFBLCtCQUFBLEVBQUEseUJBQUEsU0FBQSxtRUFBQSxRQUFBO0FBQUEsbUJBQXpCLElBQUEsd0JBQUEsTUFBQTtVQUNWLEdBQUEsT0FBQSwrQkFBQSxFQUFBLG9DQUFBLFNBQUEsOEVBQUEsUUFBQTtBQUFBLG1CQURVLElBQUEsc0NBQUEsTUFBQTtVQUNJLEdBQUEsT0FBQSwrQkFBQTs7OztBQ3hCakIsVUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLEdBQUEsa0RBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSxrREFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLGtEQUFBLEdBQUEsQ0FBQTtBQVNMLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxrREFBQSxHQUFBLENBQUEsRUFJQyxJQUFBLG1EQUFBLElBQUEsRUFBQTtBQXlMTCxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsbURBQUEsR0FBQSxDQUFBOzs7QUExTVEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLENBQUEsSUFBQSxZQUFBLElBQUEsRUFBQTtBQUdBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLFlBQUEsSUFBQSxFQUFBO0FBR0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsc0JBQUEsSUFBQSxFQUFBO0FBTUosVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsOEJBQUEsRUFBQSxJQUFBLFVBQUEsT0FBQSxPQUFBLElBQUEsT0FBQSxrQkFBQSxJQUFBLEVBQUE7QUFLQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLFlBQUEsS0FBQSxFQUFBO0FBeUxKLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLFdBQUEsS0FBQSxFQUFBOzs7OztxRkR0TGEsMkJBQXlCLEVBQUEsV0FBQSw0QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUV2QnRDLFNBQVMsYUFBQUssWUFBVyxTQUFBQyxjQUFhOzs7O0FDRXpCLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUE4QixJQUFBLHFCQUFBLENBQUE7O0FBQW9ELElBQUEsMkJBQUE7QUFDdEYsSUFBQSxxQkFBQSxHQUFBLFFBQUE7OztBQURrQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsR0FBQSwyQkFBQSxDQUFBOzs7OztBQUc5QixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFBOEIsSUFBQSxxQkFBQSxDQUFBOztBQUF1RCxJQUFBLDJCQUFBO0FBQ3pGLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7QUFEa0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsOEJBQUEsQ0FBQTs7Ozs7QUFKbEMsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsd0VBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSx3RUFBQSxHQUFBLENBQUE7Ozs7QUFGRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxhQUFBLE9BQUEsT0FBQSxPQUFBLFVBQUEsbUJBQUEsT0FBQSxjQUFBLFlBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsYUFBQSxPQUFBLE9BQUEsT0FBQSxVQUFBLG1CQUFBLE9BQUEsY0FBQSxnQkFBQSxJQUFBLEVBQUE7OztBREpKLElBV2E7QUFYYjs7QUFDQTs7QUFVTSxJQUFPLG9DQUFQLE1BQU8sbUNBQWlDO01BQzFDLGdCQUFnQjtNQUVQOzt5QkFIQSxvQ0FBaUM7TUFBQTtpRUFBakMsb0NBQWlDLFdBQUEsQ0FBQSxDQUFBLGdDQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsV0FBQSxZQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFNBQUEsWUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDJDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDWDlDLFVBQUEseUJBQUEsR0FBQSwwREFBQSxHQUFBLENBQUE7OztBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLFlBQUEsSUFBQSxFQUFBOzs7OztxRkRXYSxtQ0FBaUMsRUFBQSxXQUFBLG9DQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVg5QyxTQUFTLGFBQUFDLFlBQVcsZ0JBQUFDLGVBQWMsYUFBYSxTQUFBQyxRQUFPLFVBQUFDLGVBQWM7Ozs7O0FDaUNoRSxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxpQ0FBQSxDQUFBO0FBUUksSUFBQSx5QkFBQSxrQ0FBQSxTQUFBLHlIQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFrQywwQkFBQSxPQUFBLCtCQUFBLEtBQUEsTUFBQSxDQUEyQztJQUFBLENBQUE7QUFDaEYsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSxJQUFBOzs7O0FBUlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLEtBQUEsRUFBb0IsYUFBQSxPQUFBLFNBQUEsRUFBQSxZQUFBLE9BQUEsUUFBQSxFQUFBLGNBQUEsT0FBQSxVQUFBLEVBQUEsY0FBQSxPQUFBLFVBQUEsRUFBQSxhQUFBLE9BQUEsU0FBQTs7O0FEbkM1QixVQWtCYTtBQWxCYjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7QUFjTSxJQUFPLDRCQUFQLE1BQU8sMkJBQXlCO01BQ2tCLDJCQUEyQjtNQUVyRSxlQUFlLElBQUlGLGNBQVk7TUFDekMsZ0JBQWdCLGNBQWM7TUFDckI7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BRUE7TUFDQTtNQUNBO01BQ0EsWUFBWTtNQUNaO01BQ0E7TUFFQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUVEO01BRVIsSUFBYSxxQkFBcUIsc0JBQTZCO0FBQzNELGFBQUssd0JBQXdCO0FBQzdCLGFBQUssMkJBQTJCLEtBQUssS0FBSyxvQkFBb0I7TUFDbEU7TUFFQSxJQUFJLHVCQUFvQjtBQUNwQixlQUFPLEtBQUs7TUFDaEI7TUFFVSxPQUFPLElBQUlBLGNBQVk7TUFFdkIsU0FBUyxJQUFJQSxjQUFZO01BQ3pCLFNBQVMsSUFBSUEsY0FBWTtNQUN6QixpQkFBaUIsSUFBSUEsY0FBWTtNQUNqQyxpQ0FBaUMsSUFBSUEsY0FBWTtNQUNqRCw2QkFBNkIsSUFBSUEsY0FBWTtNQUM3Qyx5QkFBeUIsSUFBSUEsY0FBWTs7eUJBN0MxQyw0QkFBeUI7TUFBQTtpRUFBekIsNEJBQXlCLFdBQUEsQ0FBQSxDQUFBLHVCQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsY0FBQSxTQUFBLHVDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBOzs7Ozs7QUNsQnRDLFVBQUEsNkJBQUEsR0FBQSx5QkFBQSxDQUFBO0FBQ0ksVUFBQSx5QkFBQSxnQkFBQSxTQUFBLG1GQUFBO0FBQUEsbUJBQWdCLElBQUEsYUFBQSxLQUFBO1VBQW1CLENBQUEsRUFBQyxRQUFBLFNBQUEsMkVBQUE7QUFBQSxtQkFrQjVCLElBQUEsS0FBQSxLQUFBO1VBQVcsQ0FBQSxFQWxCaUIsVUFBQSxTQUFBLDZFQUFBO0FBQUEsbUJBbUIxQixJQUFBLE9BQUEsS0FBQTtVQUFhLENBQUEsRUFuQmEsVUFBQSxTQUFBLDZFQUFBO0FBQUEsbUJBb0IxQixJQUFBLE9BQUEsS0FBQTtVQUFhLENBQUEsRUFwQmEsOEJBQUEsU0FBQSwrRkFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSx1QkFBQTtVQUFBLENBQUEsRUFBQSxrQkFBQSxTQUFBLHFGQUFBO0FBQUEsbUJBc0JsQixJQUFBLGVBQUEsS0FBQTtVQUFxQixDQUFBLEVBdEJILDBCQUFBLFNBQUEsNkZBQUE7QUFBQSxtQkEyQlYsSUFBQSx1QkFBQSxLQUFBO1VBQTZCLENBQUE7QUFDMUQsVUFBQSwyQkFBQTtBQUNELFVBQUEscUJBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSx3QkFBQSxHQUFBLGtDQUFBLENBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUEsQ0FBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLGtEQUFBLEdBQUEsQ0FBQTs7O0FBOUJJLFVBQUEseUJBQUEsYUFBQSxJQUFBLFNBQUEsRUFBdUIsWUFBQSxJQUFBLFFBQUEsRUFBQSxjQUFBLElBQUEsVUFBQSxFQUFBLGNBQUEsSUFBQSxVQUFBLEVBQUEsc0JBQUEsSUFBQSxrQkFBQSxFQUFBLGNBQUEsSUFBQSxVQUFBLEVBQUEsY0FBQSxJQUFBLFVBQUEsRUFBQSxhQUFBLElBQUEsU0FBQSxFQUFBLHVCQUFBLElBQUEsbUJBQUEsRUFBQSx5QkFBQSxJQUFBLHFCQUFBLEVBQUEsZUFBQSxJQUFBLFdBQUEsRUFBQSx1QkFBQSxJQUFBLG1CQUFBLEVBQUEsOEJBQUEsSUFBQSwwQkFBQSxFQUFBLFlBQUEsSUFBQSxRQUFBLEVBQUEsVUFBQSxJQUFBLE1BQUEsRUFBQSxtQkFBQSxJQUFBLGVBQUEsRUFBQSx5QkFBQSxJQUFBLHFCQUFBLEVBQUEsd0JBQUEsSUFBQSxvQkFBQSxFQUFBLGdCQUFBLENBQUEsQ0FBQSxJQUFBLFNBQUEsRUFBQSwyQkFBQSxJQUFBLGFBQUEsT0FBQSxPQUFBLElBQUEsVUFBQSxtQkFBQSxJQUFBLGFBQUEsRUFBQSxvQkFBQSxDQUFBLENBQUEsSUFBQSxZQUFBLElBQUEsVUFBQSxhQUFBLFNBQUEsS0FBQSxFQUFBLGlCQUFBLElBQUEsYUFBQSxPQUFBLE9BQUEsSUFBQSxVQUFBLGFBQUE7QUE0QkssVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxhQUFBLElBQUEsU0FBQTtBQUVoQyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxZQUFBLElBQUEsRUFBQTs7Ozs7cUZEZGEsMkJBQXlCLEVBQUEsV0FBQSw0QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVsQnRDLFNBQVMsYUFBQUcsWUFBVyxTQUFBQyxjQUF3QjtBQUc1QyxTQUFTLHdCQUF3Qjs7Ozs7O0FDQXpCLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBNEIsSUFBQSwyQkFBQTtBQUN0QyxJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsU0FBQSxPQUFBLFdBQUEsTUFBQTs7Ozs7QUFJTixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBO0FBQXFDLElBQUEsMkJBQUE7QUFDL0MsSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7QUFEVSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGVBQUEsT0FBQSxhQUFBLE9BQUE7Ozs7O0FBR04sSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsV0FBQSxDQUFBOztBQVFBLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBTlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxjQUFBLDBCQUFBLEdBQUEsR0FBQSx5REFBQSw4QkFBQSxHQUFBQyxNQUFBLE9BQUEsV0FBQSxPQUFBLGdCQUFBLE9BQUEsb0JBQUEsT0FBQSxhQUFBLENBQUEsQ0FBQTtBQUZBLElBQUEseUJBQUEsUUFBQSxPQUFBLGdCQUFBOzs7QURYWixVQVVhO0FBVmI7O0FBQ0E7QUFDQTs7OztBQVFNLElBQU8sd0JBQVAsTUFBTyx1QkFBcUI7TUFDckIsaUJBQWlCO01BQ2pCO01BQ0E7TUFDQTtNQUNUO01BQ0E7TUFDQTtNQUdBLG1CQUFtQjtNQUVuQixjQUFBO01BQWU7TUFLZixjQUFXO0FBQ1AsWUFBSSxLQUFLLGFBQWEsVUFBYSxLQUFLLGlCQUFpQixHQUFHO0FBQ3hELGNBQUksS0FBSyxRQUFRLEtBQUssV0FBVztBQUM3QixpQkFBSyxjQUFjLG9DQUFvQyxLQUFLLFFBQVEsS0FBSyxXQUFXLEtBQUssTUFBTTtpQkFDNUY7QUFDSCxpQkFBSyxjQUFjOztBQUV2QixlQUFLLHFCQUFxQixLQUFLLFlBQVksS0FBSztBQUNoRCxlQUFLLGdCQUFnQiwyQ0FBMkMsS0FBSyxxQkFBcUIsS0FBSyxXQUFXLEtBQUssTUFBTTtlQUNsSDtBQUNILGVBQUssY0FBYztBQUNuQixlQUFLLHFCQUFxQjtBQUMxQixlQUFLLGdCQUFnQjs7QUFFekIsYUFBSyxRQUFRLG9DQUFvQyxLQUFLLE9BQU8sS0FBSyxNQUFNO01BQzVFOzt5QkFoQ1Msd0JBQXFCO01BQUE7aUVBQXJCLHdCQUFxQixXQUFBLENBQUEsQ0FBQSxtQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLGdCQUFBLGtCQUFBLFdBQUEsYUFBQSxPQUFBLFNBQUEsUUFBQSxTQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLG1CQUFBLEdBQUEsQ0FBQSxnQkFBQSxzQ0FBQSxHQUFBLENBQUEsYUFBQSxlQUFBLEdBQUEsUUFBQSxZQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsK0JBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNWbEMsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxVQUFBLHFCQUFBLENBQUE7QUFBc0IsVUFBQSwyQkFBQTtBQUM1QixVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSw4Q0FBQSxHQUFBLENBQUE7QUFHQSxVQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQTBELFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQVksVUFBQSwyQkFBQTtBQUN0RSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSw4Q0FBQSxHQUFBLENBQUEsRUFFQyxJQUFBLCtDQUFBLEdBQUEsRUFBQTtBQVlMLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBcEJVLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsaUNBQUEsSUFBQSxJQUFBLFNBQUEsR0FBQSxNQUFBO0FBQ04sVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsWUFBQSxJQUFBLEVBQUE7QUFJQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxjQUFBLElBQUEsRUFBQTtBQUdBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLGlCQUFBLEtBQUEsRUFBQTs7Ozs7cUZEQ1MsdUJBQXFCLEVBQUEsV0FBQSx3QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVWbEMsU0FBUyxjQUFBQyxtQkFBa0I7O0FBQTNCLElBSWE7QUFKYjs7QUFJTSxJQUFPLG9DQUFQLE1BQU8sbUNBQWlDO01BUTFDLG9EQUFvRCxVQUFvQixPQUFVO0FBQzlFLGNBQU0sZUFBYztBQUNwQixZQUFJO0FBQ0EsZ0JBQU0sT0FBTyxNQUFNLGFBQWEsUUFBUSxZQUFZO0FBQ3BELGdCQUFNLGNBQWMsS0FBSyxNQUFNLElBQUk7QUFDbkMsbUJBQVMscUJBQXFCO0FBQzlCLG1CQUFTLFVBQVUsWUFBWTtpQkFDMUIsS0FBSztBQUVWLGNBQUksRUFBRSxlQUFlLGNBQWM7QUFDL0Isa0JBQU07OztNQUdsQjtNQUNBLGtCQUFrQixhQUF1QjtBQUNyQyxZQUFJLFFBQVE7QUFDWixjQUFNLHNCQUFzQixDQUFBO0FBQzVCLG1CQUFXLFlBQVksYUFBYTtBQUNoQyxjQUFJLFNBQVMsb0JBQW9CO0FBQzdCLG9CQUFRLEtBQUsscUNBQXFDLFVBQVUsT0FBTyxtQkFBbUI7aUJBQ25GO0FBQ0gscUJBQVMsU0FBUzs7O0FBRzFCLGVBQU87TUFDWDtNQUVBLHFDQUFxQyxVQUFvQixPQUFlLHFCQUF3QjtBQUM1RixZQUFJLG9CQUFvQixTQUFTLG1CQUFvQixFQUFHLEdBQUc7QUFFdkQsZ0JBQU0sV0FBVyxTQUFTLG1CQUFvQjtBQUM5QyxnQkFBTSxhQUFhLG9CQUFvQixTQUFTLG1CQUFvQixFQUFHO0FBQ3ZFLGNBQUksWUFBWSxXQUFXLEdBQUc7QUFDMUIsZ0JBQUksY0FBYyxVQUFVO0FBQ3hCLGtDQUFvQixTQUFTLG1CQUFvQixFQUFHLElBQUksYUFBYTttQkFDbEU7QUFDSCxrQ0FBb0IsU0FBUyxtQkFBb0IsRUFBRyxJQUFJLGFBQWE7QUFDckUsdUJBQVMsU0FBUyxtQkFBb0I7O2lCQUV2QztBQUNILHFCQUFTLFNBQVM7O2VBRW5CO0FBRUgsOEJBQW9CLFNBQVMsbUJBQW9CLEVBQUcsSUFBSTtBQUN4RCxtQkFBUyxTQUFTOztBQUV0QixlQUFPO01BQ1g7O3lCQXhEUyxvQ0FBaUM7TUFBQTtxRUFBakMsb0NBQWlDLFNBQWpDLG1DQUFpQyxXQUFBLFlBRHBCLE9BQU0sQ0FBQTs7Ozs7O0FDSGhDLFNBQVMsYUFBQUMsWUFBVyxTQUFBQyxjQUFhOzs7OztBQ0d6QixJQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxNQUFBLENBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQ0ssSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQXNCLElBQUEsNEJBQUE7QUFFL0IsSUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLFFBQUE7OztBQUo0QyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFdBQUEsK0JBQUEsR0FBQUMsSUFBQSxDQUFBOzs7OztBQU14QyxJQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxNQUFBLENBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQ0ssSUFBQSxzQkFBQSxHQUFBLHlCQUFBO0FBQXVCLElBQUEsNEJBQUE7QUFFaEMsSUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLFFBQUE7OztBQUo0QyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFdBQUEsK0JBQUEsR0FBQUMsSUFBQSxDQUFBOzs7QURYaEQsZ0JBUWE7QUFSYjs7QUFDQTs7OztBQU9NLElBQU8sMENBQVAsTUFBTyx5Q0FBdUM7TUFDdkM7TUFDQSx1QkFBdUI7O3lCQUZ2QiwwQ0FBdUM7TUFBQTtrRUFBdkMsMENBQXVDLFdBQUEsQ0FBQSxDQUFBLHVDQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLHNCQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxnQkFBQSwyREFBQSxHQUFBLFNBQUEsY0FBQSxRQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsZ0JBQUEsNERBQUEsR0FBQSxTQUFBLGNBQUEsUUFBQSxHQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxpREFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1JwRCxVQUFBLDhCQUFBLEdBQUEsS0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQ0EsVUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDBCQUFBLEdBQUEsZ0VBQUEsR0FBQSxDQUFBLEVBTUMsR0FBQSxnRUFBQSxHQUFBLENBQUE7QUFRTCxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxHQUFBLElBQUE7OztBQWZJLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxJQUFBLHdCQUFBLElBQUEsU0FBQSxtQkFBQSxJQUFBLEVBQUE7QUFPQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsSUFBQSx3QkFBQSxDQUFBLElBQUEsU0FBQSxtQkFBQSxJQUFBLEVBQUE7Ozs7O3NGRERTLHlDQUF1QyxFQUFBLFdBQUEsMENBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFUnBELFNBQVMsYUFBQUMsWUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFPLFVBQUFDLGVBQWM7QUFDdkQsU0FBUyxTQUFTLGVBQWUsdUJBQXVCLG9CQUFBQyxtQkFBa0IsV0FBQUMsVUFBUyxrQkFBa0I7QUFJckcsU0FBUyxlQUFlOzs7Ozs7O0FDRlosSUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLGlDQUFBLEVBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsWUFBQTs7OztBQURtQyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFlBQUEsT0FBQSxRQUFBLEVBQXFCLGtCQUFBLE9BQUEscUNBQUE7Ozs7O0FBR3BELElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxxQ0FBQSxFQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLFlBQUE7Ozs7QUFEdUMsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxZQUFBLE9BQUEsUUFBQTs7Ozs7O0FBR25DLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFLSSxJQUFBLDBCQUFBLFVBQUEsU0FBQSxzRkFBQTtBQUFBLE1BQUEsNkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQTtBQUFBLGFBQVUsMkJBQUEsT0FBQSxPQUFBLENBQVE7SUFBQSxDQUFBO0FBTWxCLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLFlBQUE7Ozs7QUFYUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGNBQUEsT0FBQSxXQUFBLEtBQUEsRUFBK0IsbUJBQUEsK0JBQUEsR0FBQUMsTUFBQSxPQUFBLFNBQUEsVUFBQSxDQUFBLEVBQUEsZUFBQSxPQUFBLFlBQUEsRUFBQSxxQkFBQSxLQUFBLEVBQUEsb0JBQUEsS0FBQTtBQVN0QixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsT0FBQSxVQUFBOzs7Ozs7QUFLYixJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUEyQyxJQUFBLDBCQUFBLFNBQUEsU0FBQSxxRkFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQTtBQUFBLGFBQVMsMkJBQUEsT0FBQSxtQkFBQSxLQUFBLE9BQUEsUUFBQSxDQUFpQztJQUFBLENBQUE7QUFDakYsSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBeUQsSUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBTSxJQUFBLDRCQUFBO0FBQ25FLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBO0FBQTBDLElBQUEsMEJBQUEsU0FBQSxTQUFBLHNGQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBO0FBQUEsYUFBUywyQkFBQSxRQUFBLG9CQUFBLEtBQUEsUUFBQSxRQUFBLENBQWtDO0lBQUEsQ0FBQTtBQUNqRixJQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUEwRCxJQUFBLHNCQUFBLElBQUEsU0FBQTtBQUFPLElBQUEsNEJBQUE7QUFDckUsSUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsWUFBQTs7OztBQVJxQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsT0FBQSxPQUFBO0FBSUEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsT0FBQTs7Ozs7QUF5QlQsSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsV0FBQSxFQUFBOztBQUNKLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsb0JBQUE7Ozs7QUFGaUIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsZ0JBQUEsRUFBeUIsY0FBQSwyQkFBQSxHQUFBLEdBQUEsb0NBQUEsQ0FBQTs7Ozs7QUFNdEMsSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsc0JBQUEsQ0FBQTtBQUEyQyxJQUFBLDRCQUFBO0FBQ3JELElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsb0JBQUE7Ozs7QUFGYyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLE9BQUEsU0FBQSxtQkFBQSxRQUFBOzs7OztBQXdCVixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTJCLElBQUEsc0JBQUEsQ0FBQTs7QUFBK0YsSUFBQSw0QkFBQTtBQUM5SCxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7Ozs7QUFEK0IsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSxJQUFBLDJCQUFBLEdBQUEsR0FBQSwyQ0FBQSxRQUFBLFNBQUEsZ0JBQUEsR0FBQSxHQUFBOzs7OztBQUczQixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTBCLElBQUEsc0JBQUEsQ0FBQTs7QUFBK0YsSUFBQSw0QkFBQTtBQUM3SCxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7Ozs7QUFEOEIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSxJQUFBLDJCQUFBLEdBQUEsR0FBQSwyQ0FBQSxRQUFBLFNBQUEsZ0JBQUEsR0FBQSxHQUFBOzs7OztBQUkxQixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsV0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxXQUFBLEVBQUE7QUFDQSxJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxvQkFBQTs7OztBQUhzQyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsUUFBQSxxQkFBQTtBQUNjLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxRQUFBLGFBQUE7Ozs7O0FBWHhELElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwwQkFBQSxHQUFBLDJFQUFBLEdBQUEsQ0FBQSxFQUVDLEdBQUEsMkVBQUEsR0FBQSxDQUFBO0FBS0QsSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwwQkFBQSxHQUFBLDJFQUFBLEdBQUEsQ0FBQTtBQU1KLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsWUFBQTs7OztBQWRRLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLFNBQUEscUJBQUEsWUFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxTQUFBLHFCQUFBLFlBQUEsSUFBQSxFQUFBO0FBSUEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsU0FBQSxxQkFBQSxZQUFBLElBQUEsRUFBQTs7O0FEOUZoQixVQVlhO0FBWmI7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7QUFRTSxJQUFPLHNDQUFQLE1BQU8scUNBQW1DO01BMkJ6QjtNQTFCSDtNQUNQO01BQ087TUFDUDtNQUNBO01BRVEsbUJBQW1CLElBQUlMLGNBQVk7TUFDbkMsbUJBQW1CLElBQUlBLGNBQVk7TUFDMUMscUJBQXFCLElBQUlBLGNBQVk7TUFDckMsc0JBQXNCLElBQUlBLGNBQVk7TUFHaEQsYUFBYTtNQUNiLG1CQUFtQkc7TUFDbkIsZ0JBQWdCO01BQ2hCLHdCQUF3QjtNQUN4QixVQUFVO01BQ1YsVUFBVUM7TUFHUyxXQUFXO01BQ3JCLGFBQWE7TUFFZCxvQkFBb0IsSUFBSSxRQUFPO01BQ3ZDLGVBQWUsS0FBSyxrQkFBa0IsYUFBWTtNQUVsRCxZQUFtQixtQ0FBb0U7QUFBcEUsYUFBQSxvQ0FBQTtNQUF1RTtNQUtuRixjQUFXO0FBQ2QsWUFBSSxLQUFLLFNBQVMsU0FBUyxhQUFhLFdBQVc7QUFDL0MsZUFBSyxTQUFTLE9BQU8sYUFBYTs7QUFFdEMsaUJBQVMsMkJBQTJCLEtBQUssUUFBUTtBQUNqRCxhQUFLLGlCQUFpQixLQUFLLEtBQUssUUFBUTtNQUM1QztNQUtPLFNBQU07QUFDVCxhQUFLLGlCQUFpQixLQUFLLEtBQUssUUFBUTtBQUN4QyxhQUFLLGtCQUFrQixLQUFLLEVBQUU7TUFDbEM7TUFFQSxxQkFBcUIsT0FBWTtBQUM3QixhQUFLLGtDQUFrQyxvREFBb0QsS0FBSyxVQUFVLEtBQUs7QUFDL0csYUFBSyxpQkFBaUIsS0FBSyxLQUFLLFFBQVE7TUFDNUM7O3lCQW5EUyxzQ0FBbUMsaUNBQUEsaUNBQUEsQ0FBQTtNQUFBO2tFQUFuQyxzQ0FBbUMsV0FBQSxDQUFBLENBQUEsa0NBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsY0FBQSxnQkFBQSxVQUFBLFlBQUEsc0JBQUEsd0JBQUEsdUNBQUEsd0NBQUEsR0FBQSxTQUFBLEVBQUEsa0JBQUEsb0JBQUEsa0JBQUEsb0JBQUEsb0JBQUEsc0JBQUEscUJBQUEsc0JBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsZ0NBQUEsUUFBQSxRQUFBLEdBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEtBQUEsR0FBQSxDQUFBLE9BQUEsbUJBQUEsZ0JBQUEsNkJBQUEsR0FBQSxTQUFBLGdCQUFBLEdBQUEsQ0FBQSxNQUFBLG1CQUFBLFFBQUEsVUFBQSxRQUFBLE9BQUEsR0FBQSxPQUFBLGdCQUFBLEdBQUEsV0FBQSxZQUFBLFlBQUEsWUFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsa0JBQUEsR0FBQSxDQUFBLGdCQUFBLHlDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLE1BQUEscUJBQUEsUUFBQSxLQUFBLEdBQUEsZ0JBQUEsR0FBQSxXQUFBLFlBQUEsWUFBQSxlQUFBLFlBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsbUJBQUEsSUFBQSxrQkFBQSx1Q0FBQSxHQUFBLE9BQUEsYUFBQSxHQUFBLGNBQUEsbUJBQUEsZUFBQSxxQkFBQSxvQkFBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxhQUFBLDJCQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsZUFBQSxPQUFBLFVBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxnQkFBQSxxQ0FBQSxHQUFBLENBQUEsR0FBQSxPQUFBLGNBQUEsT0FBQSxVQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEsc0NBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsUUFBQSxHQUFBLFFBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxRQUFBLE1BQUEsYUFBQSxhQUFBLEdBQUEsYUFBQSxvQkFBQSxHQUFBLE1BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSw2Q0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1poRCxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQUssVUFBQSwwQkFBQSxRQUFBLFNBQUEsaUVBQUEsUUFBQTtBQUFBLG1CQUFRLElBQUEscUJBQUEsTUFBQTtVQUE0QixDQUFBLEVBQUMsWUFBQSxTQUFBLHFFQUFBLFFBQUE7QUFBQSxtQkFBYSxPQUFBLGVBQUE7VUFBdUIsQ0FBQTtBQUMxRSxVQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsMEJBQUEsR0FBQSw0REFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLDREQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsNERBQUEsR0FBQSxDQUFBO0FBb0JELFVBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSwwQkFBQSxHQUFBLDREQUFBLElBQUEsQ0FBQTtBQVlKLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsU0FBQSxDQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUtJLFVBQUEsMEJBQUEsaUJBQUEsU0FBQSw2RUFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSxTQUFBLFVBQUE7VUFBQSxDQUFBLEVBQThCLGlCQUFBLFNBQUEsK0VBQUE7QUFBQSxtQkFDYixJQUFBLFlBQUE7VUFBYSxDQUFBO0FBTmxDLFVBQUEsNEJBQUE7QUFXSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMEJBQUEsSUFBQSw2REFBQSxHQUFBLENBQUE7QUFLSixVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMEJBQUEsSUFBQSw2REFBQSxHQUFBLENBQUE7QUFLQSxVQUFBLDhCQUFBLElBQUEsWUFBQSxDQUFBO0FBSUksVUFBQSwwQkFBQSxpQkFBQSxTQUFBLGdGQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLFNBQUEsYUFBQTtVQUFBLENBQUEsRUFBaUMsaUJBQUEsU0FBQSxrRkFBQTtBQUFBLG1CQUNoQixJQUFBLFlBQUE7VUFBYSxDQUFBOzs7QUFTakMsVUFBQSw0QkFBQTtBQUNMLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwwQkFBQSxJQUFBLDZEQUFBLEdBQUEsQ0FBQTtBQWlCQSxVQUFBLHlCQUFBLElBQUEseUNBQUEsRUFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxJQUFBOzs7QUF6RytILFVBQUEsMkJBQUEsaUJBQUEsSUFBQSxZQUFBO0FBRXZILFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxJQUFBLGdCQUFBLElBQUEsU0FBQSxxQkFBQSxJQUFBLFFBQUEsSUFBQSxJQUFBLEVBQUE7QUFHQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsSUFBQSxTQUFBLHFCQUFBLElBQUEsRUFBQTtBQUdBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxDQUFBLElBQUEsV0FBQSxJQUFBLEVBQUE7QUFnQkEsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLElBQUEsZUFBQSxJQUFBLEVBQUE7QUFxQlEsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxXQUFBLElBQUEsU0FBQSxPQUFBLEVBQThCLFlBQUEsSUFBQSxTQUFBLHNCQUFBLElBQUEsUUFBQSxFQUFBLFlBQUEsSUFBQSxRQUFBLEVBQUEsWUFBQSxDQUFBLElBQUEsU0FBQSxrQkFBQTtBQVU5QixVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsSUFBQSxTQUFBLHFCQUFBLEtBQUEsRUFBQTtBQU9BLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLFNBQUEscUJBQUEsS0FBQSxFQUFBO0FBU0ksVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxXQUFBLElBQUEsU0FBQSxVQUFBLEVBQWlDLFlBQUEsSUFBQSxRQUFBLEVBQUEsWUFBQSxJQUFBLFFBQUEsRUFBQSxnQkFBQSxJQUFBLFNBQUEsc0JBQUEsT0FBQSxPQUFBLElBQUEsU0FBQSxtQkFBQSxZQUFBLDJCQUFBLElBQUEsSUFBQSw0REFBQSxJQUFBLDJCQUFBLElBQUEsSUFBQSxrREFBQSxDQUFBLEVBQUEsWUFBQSxFQUFBLElBQUEsU0FBQSxzQkFBQSxPQUFBLE9BQUEsSUFBQSxTQUFBLG1CQUFBLFNBQUE7QUFjN0MsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLElBQUEsU0FBQSxxQkFBQSxTQUFBLEtBQUEsRUFBQTtBQWlCdUMsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxZQUFBLElBQUEsUUFBQSxFQUFxQix3QkFBQSxJQUFBLG9CQUFBOzs7OztzRkQxRnZELHFDQUFtQyxFQUFBLFdBQUEsc0NBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFWmhELFNBQVMsY0FBQUUsbUJBQWtCO0FBQzNCLFNBQVMsWUFBWSxrQkFBZ0M7QUFLckQsU0FBUyxXQUFXOzs7QUFOcEIsSUFZYTtBQVpiOztBQU9BO0FBS00sSUFBTyw0QkFBUCxNQUFPLDJCQUF5QjtNQUtkO01BSkgsMkJBQTJCO01BQzNCLGtDQUFrQztNQUMzQyxjQUFjO01BRXRCLFlBQW9CLE1BQWdCO0FBQWhCLGFBQUEsT0FBQTtNQUFtQjtNQUV2QyxlQUFlLFVBQWtCLFdBQXVCLGNBQXNCLFNBQVMsT0FBSztBQUN4RixZQUFJLFNBQVMsSUFBSSxXQUFVO0FBQzNCLFlBQUksUUFBUTtBQUNSLG1CQUFTLE9BQU8sSUFBSSxVQUFVLE1BQU07O0FBRXhDLGNBQU0sTUFBTSxHQUFHLEtBQUssV0FBVyx5QkFBeUIsWUFBWSxXQUFXLFFBQVE7QUFDdkYsZUFBTyxLQUFLLEtBQUssSUFBWSxLQUFLLFdBQVcsRUFBRSxPQUFNLENBQUUsRUFBRSxLQUFLLElBQUksQ0FBQyxRQUFnQixLQUFLLGNBQWMsR0FBRyxDQUFDLENBQUM7TUFDL0c7TUFFQSxzQkFBc0IsV0FBdUIscUJBQTJCO0FBQ3BFLGNBQU0sTUFBTSxHQUFHLEtBQUssV0FBVyx5QkFBeUIsbUJBQW1CO0FBQzNFLGVBQU8sS0FBSyxLQUFLLElBQVksS0FBSyxTQUFTLEVBQUUsS0FBSyxJQUFJLENBQUMsUUFBUSxLQUFLLGNBQWMsR0FBRyxDQUFDLENBQUM7TUFDM0Y7TUFFQSwrQkFBK0IsV0FBdUIsbUJBQXNDLGNBQW9CO0FBQzVHLGNBQU0sTUFBTSxHQUFHLEtBQUssV0FBVyx5QkFBeUIsWUFBWTtBQUNwRSxjQUFNLG1CQUFtQjtVQUNyQjtVQUNBOztBQUVKLGVBQU8sS0FBSyxLQUFLLElBQVksS0FBSyxrQkFBa0IsRUFBRSxTQUFTLFdBQVUsQ0FBRSxFQUFFLEtBQUssSUFBSSxDQUFDLFFBQTRCLEtBQUssMENBQTBDLEdBQUcsQ0FBQyxDQUFDO01BQzNLO01BRUEsY0FBYyxjQUFvQjtBQUM5QixlQUFPLEtBQUssS0FBSyxJQUFZLEdBQUcsS0FBSyxXQUFXLHlCQUF5QixZQUFZLFNBQVMsRUFBRSxLQUFLLElBQUksQ0FBQyxRQUFRLEtBQUssY0FBYyxHQUFHLENBQUMsQ0FBQztNQUM5STtNQUVBLHFCQUFxQixZQUFvQixjQUFvQjtBQUN6RCxjQUFNLE1BQU0sR0FBRyxLQUFLLFdBQVcsYUFBYSxVQUFVLHlCQUF5QixZQUFZO0FBQzNGLGVBQU8sS0FBSyxLQUFLLElBQVksR0FBRyxFQUFFLEtBQUssSUFBSSxDQUFDLFFBQVEsS0FBSyxjQUFjLEdBQUcsQ0FBQyxDQUFDO01BQ2hGO01BRUEsaUJBQWlCLGNBQW9CO0FBQ2pDLGVBQU8sS0FBSyxLQUFLLElBQVUsR0FBRyxLQUFLLFdBQVcseUJBQXlCLFlBQVksc0JBQXNCLElBQUk7TUFDakg7TUFRQSxpQkFBaUIsaUJBQXlCLGNBQXNCLFVBQWdCO0FBQzVFLGVBQU8sS0FBSyxLQUFLLE9BQWEsR0FBRyxLQUFLLFdBQVcsbUJBQW1CLGVBQWUseUJBQXlCLFlBQVksWUFBWSxRQUFRLEVBQUU7TUFDbEo7TUFFUSwwQ0FBMEMsS0FBdUI7QUFDckUsWUFBSSxTQUFTLDJCQUEwQixzQkFBc0IsSUFBSSxJQUFLO0FBQ3RFLGlCQUFTLEtBQUssY0FBYyxNQUFNO0FBQ2xDLGVBQU8saUJBQWlCLHNCQUFzQixPQUFPLGNBQWM7QUFFbkUsWUFBSSxPQUFPLFlBQVk7QUFDbkIsaUJBQU8sV0FBVyxpQkFBaUIsc0JBQXNCLE9BQU8sV0FBVyxjQUFjOztBQUU3RixZQUFJLE9BQU8sZUFBZTtBQUN0QixpQkFBTyxjQUFjLHFCQUFxQixzQkFBc0IsT0FBTyxjQUFjLGtCQUFrQjs7QUFHM0csZUFBTyxJQUFJLE1BQU0sRUFBRSxNQUFNLE9BQU0sQ0FBRTtNQUNyQztNQUVRLE9BQU8sc0JBQXNCLFFBQWM7QUFDL0MsZUFBTyxPQUFPLE9BQU8sQ0FBQSxHQUFJLE1BQU07TUFDbkM7TUFNQSxjQUFjLFFBQWM7QUFDeEIsWUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLFdBQVc7QUFDOUIsaUJBQU87O0FBRVgsbUJBQVcsWUFBWSxPQUFPLFdBQVc7QUFDckMsY0FBSSxTQUFTLFdBQVc7QUFDcEIscUJBQVMsZ0JBQWdCLFNBQVMsVUFBVSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ3hELHFCQUFTLGNBQWMsU0FBUyxVQUFVLE1BQU0sR0FBRyxFQUFFLENBQUM7OztBQUc5RCxlQUFPO01BQ1g7TUFNQSxvQkFBb0IsVUFBb0I7QUFDcEMsWUFBSSxDQUFDLFVBQVU7QUFDWCxpQkFBTzs7QUFFWCxlQUFPLFNBQVMsTUFDWixDQUFDLGtCQUNJLENBQUMsYUFBYSxRQUFRLGFBQWEsS0FBSyxVQUFVLEtBQUssOEJBQ3ZELENBQUMsYUFBYSxjQUFjLGFBQWEsV0FBVyxVQUFVLEtBQUssZ0NBQWdDO01BRWhIOzt5QkF0R1MsNEJBQXlCLHdCQUFBLGNBQUEsQ0FBQTtNQUFBO3FFQUF6Qiw0QkFBeUIsU0FBekIsMkJBQXlCLFdBQUEsWUFEWixPQUFNLENBQUE7Ozs7OztBQ1hoQyxTQUFTLGFBQUFDLGtCQUF5QjtBQUNsQyxTQUFTLGtCQUFBQyx1QkFBc0I7QUFDL0IsU0FBUyxZQUFBQyxpQkFBZ0I7QUFFekIsU0FBUyxvQkFBQUMseUJBQXdCO0FBV2pDLFNBQVMsT0FBTyxvQkFBb0I7QUFDcEMsU0FBUyxxQkFBcUI7Ozs7Ozs7OztBQ3dCTSxJQUFBLHNCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsc0JBQUEsQ0FBQTtBQUFxQyxJQUFBLDRCQUFBO0FBQy9DLElBQUEsc0JBQUEsR0FBQSxvQ0FBQTs7OztBQURVLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsSUFBQSxjQUFBLGFBQUEsT0FBQSxHQUFBOzs7OztBQU1GLElBQUEsc0JBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFjSSxJQUFBLHNCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQTZELElBQUEsc0JBQUEsQ0FBQTs7QUFHakUsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTs7Ozs7QUFqQlEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxjQUFBLCtCQUFBLEdBQUFDLE1BQUEsT0FBQSxVQUFBLGNBQUEsY0FBQSxTQUFBLElBQUEsY0FBQSxjQUFBLElBQUEsY0FBQSxFQUFBLENBQUE7QUFhUyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsT0FBQSxZQUFBLEVBQXFCLGNBQUEsSUFBQTtBQUErQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLFFBQUEsMkJBQUEsR0FBQSxHQUFBLDhDQUFBLEdBQUEsNENBQUE7Ozs7O0FBTWpFLElBQUEsc0JBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFZSSxJQUFBLHNCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQTZELElBQUEsc0JBQUEsQ0FBQTs7QUFHakUsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTs7Ozs7QUFmUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGNBQUEsK0JBQUEsR0FBQUMsTUFBQSxRQUFBLFVBQUEsY0FBQSxjQUFBLFNBQUEsT0FBQSxjQUFBLGNBQUEsY0FBQSxTQUFBLElBQUEsY0FBQSxFQUFBLENBQUE7QUFXUyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsUUFBQSxZQUFBLEVBQXFCLGNBQUEsSUFBQTtBQUErQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLFFBQUEsMkJBQUEsR0FBQSxHQUFBLDhDQUFBLEdBQUEsNENBQUE7Ozs7OztBQVFqRSxJQUFBLHNCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQVEsSUFBQSwwQkFBQSxTQUFBLFNBQUEsaUdBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLGdCQUFBLDZCQUFBLEVBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUEsQ0FBQTtBQUFBLGFBQVMsMkJBQUEsUUFBQSxpQkFBQSxhQUFBLENBQTRCO0lBQUEsQ0FBQTtBQUN6QyxJQUFBLHNCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQXNELElBQUEsc0JBQUEsQ0FBQTs7QUFDMUQsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTs7OztBQUZpQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsUUFBQSxLQUFBLEVBQWMsY0FBQSxJQUFBO0FBQStCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsUUFBQSwyQkFBQSxHQUFBLEdBQUEsZ0RBQUEsR0FBQSw0Q0FBQTs7Ozs7QUE3RDFFLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLENBQUE7QUFBbUIsSUFBQSw0QkFBQTtBQUN2QixJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxXQUFBLEVBQUE7O0FBS0osSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxFQUFBO0FBQXFELElBQUEsNEJBQUE7QUFDekQsSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLEVBQUE7O0FBQTBELElBQUEsNEJBQUE7QUFDOUQsSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLEVBQUE7QUFBOEYsSUFBQSw0QkFBQTtBQUNsRyxJQUFBLHNCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsMEJBQUEsSUFBQSx3RUFBQSxHQUFBLENBQUE7QUFHSixJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHNCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsTUFBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSx3Q0FBQTtBQUFBLElBQUEsMEJBQUEsSUFBQSx3RUFBQSxHQUFBLEVBQUEsRUFtQkMsSUFBQSx3RUFBQSxHQUFBLEVBQUE7QUFtQkwsSUFBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxNQUFBO0FBQ0ksSUFBQSxzQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSwwQkFBQSxJQUFBLHdFQUFBLEdBQUEsQ0FBQTtBQUtKLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSx3QkFBQTs7Ozs7QUFsRVksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxjQUFBLEVBQUE7QUFHSSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsT0FBQSxRQUFBLGNBQUEsY0FBQSxTQUFBLElBQUEsQ0FBQSxFQUEwRCxjQUFBLDJCQUFBLEdBQUEsSUFBQSxPQUFBLGVBQUEsY0FBQSxjQUFBLFNBQUEsSUFBQSxDQUFBLENBQUE7QUFLOUQsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxjQUFBLGNBQUEsU0FBQSxTQUFBLEVBQUE7QUFDQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDJCQUFBLElBQUEsSUFBQSxjQUFBLGdCQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsY0FBQSxjQUFBLGNBQUEsY0FBQSxjQUFBLFlBQUEsU0FBQSxDQUFBO0FBRUEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxLQUFBLGNBQUEsZ0JBQUEsT0FBQSxPQUFBLGNBQUEsYUFBQSxVQUFBLFNBQUEsS0FBQSxFQUFBO0FBTUksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLGNBQUEsY0FBQSxTQUFBLFNBQUEsT0FBQSxhQUFBLE9BQUEsS0FBQSxFQUFBO0FBb0JBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxjQUFBLGNBQUEsU0FBQSxTQUFBLE9BQUEsYUFBQSxPQUFBLEtBQUEsRUFBQTtBQW9CQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsQ0FBQSxjQUFBLGFBQUEsaUJBQUEsS0FBQSxFQUFBOzs7OztBQTNFaEMsSUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxTQUFBLENBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxzQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUFvQixJQUFBLHNCQUFBLElBQUEsSUFBQTtBQUFFLElBQUEsNEJBQUE7QUFDdEIsSUFBQSxzQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUFvRSxJQUFBLHNCQUFBLElBQUEsTUFBQTtBQUFJLElBQUEsNEJBQUE7QUFDeEUsSUFBQSxzQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUF3RSxJQUFBLHNCQUFBLElBQUEsVUFBQTtBQUFRLElBQUEsNEJBQUE7QUFDaEYsSUFBQSxzQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUEwRixJQUFBLHNCQUFBLElBQUEsaUJBQUE7QUFBZSxJQUFBLDRCQUFBO0FBQ3pHLElBQUEsc0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxNQUFBLENBQUE7QUFBMkYsSUFBQSxzQkFBQSxJQUFBLGtCQUFBO0FBQWdCLElBQUEsNEJBQUE7QUFDM0csSUFBQSxzQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFpRixJQUFBLHNCQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsNEJBQUE7QUFDdEYsSUFBQSxzQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFrRixJQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsNEJBQUE7QUFDNUYsSUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsT0FBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsZ0NBQUEsSUFBQSx5REFBQSxJQUFBLElBQUEsTUFBQSxNQUFBLHdDQUFBO0FBcUVKLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLElBQUE7Ozs7QUF6RW9CLElBQUEseUJBQUEsRUFBQTtBQUFBLElBQUEsMEJBQUEsT0FBQSxXQUFBOzs7OztBQTJFaEIsSUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQW9ELElBQUEsc0JBQUEsR0FBQSwrQkFBQTtBQUE2QixJQUFBLDRCQUFBO0FBQ3JGLElBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxJQUFBOzs7QUR2R0EsZ0JBc0JhO0FBdEJiOztBQUdBO0FBR0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUFRTSxJQUFPLDJCQUFQLE1BQU8sMEJBQXdCO01Bd0JyQjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFFQTtNQUNBO01BQ0E7TUFoQ1osdUJBQXVCLGFBQWE7TUFFM0IsZUFBZTtNQUV4QjtNQUNBO01BQ0E7TUFDQTtNQUNBLFVBQVU7TUFDVixZQUF3QixDQUFBO01BRXhCLGNBQTRCLENBQUE7TUFFcEI7TUFFUixVQUFVO01BQ1YsaUJBQWlCO01BR2pCLFFBQVE7TUFDUixlQUFlO01BRWYsWUFDWSxPQUNBLGNBQ0EsMkJBQ0EsdUJBQ0EsNkJBQ0EsOEJBQ1Isa0JBQ1EsVUFDQSxlQUNBLHVCQUE0QztBQVQ1QyxhQUFBLFFBQUE7QUFDQSxhQUFBLGVBQUE7QUFDQSxhQUFBLDRCQUFBO0FBQ0EsYUFBQSx3QkFBQTtBQUNBLGFBQUEsOEJBQUE7QUFDQSxhQUFBLCtCQUFBO0FBRUEsYUFBQSxXQUFBO0FBQ0EsYUFBQSxnQkFBQTtBQUNBLGFBQUEsd0JBQUE7QUFFUix5QkFBaUIsSUFBSSw4Q0FBOEMsRUFBRSxVQUFVLENBQUMsU0FBVSxLQUFLLHlCQUF5QixJQUFLO01BQ2pJO01BRU8sV0FBUTtBQUNYLHNCQUFjLENBQUMsS0FBSyxNQUFNLFFBQVEsS0FBSyxNQUFNLFdBQVcsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLFFBQVEsV0FBVyxNQUFLO0FBQzNGLGVBQUssV0FBVyxPQUFPLE9BQU8sVUFBVSxDQUFDO0FBQ3pDLGVBQUssU0FBUyxPQUFPLE9BQU8sUUFBUSxDQUFDO0FBQ3JDLGVBQUssVUFBVSxPQUFPLFlBQVksU0FBUyxDQUFDO0FBRTVDLGVBQUssd0JBQXVCO1FBQ2hDLENBQUM7TUFDTDtNQUtBLDBCQUF1QjtBQUNuQixZQUFJO0FBQ0osWUFBSSxLQUFLLFFBQVE7QUFDYix3Q0FBOEIsS0FBSyxzQkFBc0IsK0JBQStCLEtBQUssVUFBVSxLQUFLLE1BQU07QUFDbEgsZUFBSyxVQUFVO2VBQ1o7QUFDSCx3Q0FBOEIsS0FBSyxjQUFjLGlDQUFpQyxLQUFLLFFBQVE7O0FBRW5HLG9DQUE0QixVQUFVO1VBQ2xDLE1BQU0sQ0FBQyxhQUF3QztBQUMzQyxpQkFBSyxZQUFZLEtBQUssR0FBSSxTQUFTLFFBQVEsQ0FBQSxDQUFHO1VBQ2xEO1VBQ0EsT0FBTyxDQUFDLGFBQXFCLEtBQUssUUFBUSxRQUFRO1NBQ3JEO01BQ0w7TUFNQSxpQkFBaUIsb0JBQThCO0FBQzNDLGNBQU0sZ0JBQWdCLE9BQU8sUUFBUSxLQUFLLHNCQUFzQjtBQUNoRSxZQUFJLGVBQWU7QUFDZixrQkFBUSxtQkFBbUIsd0JBQXdCO1lBQy9DLEtBQUE7QUFDSSxtQkFBSywwQkFBMEIsaUJBQWlCLG1CQUFtQixFQUFHLEVBQUUsVUFBUztBQUNqRjtZQUNKLEtBQUE7QUFDSSxrQkFBSSxtQkFBbUIsZUFBZSxVQUFVLElBQUk7QUFDaEQscUJBQUssc0JBQXNCLGlCQUFpQixtQkFBbUIsY0FBYyxJQUFLLG1CQUFtQixFQUFHLEVBQUUsVUFBUzs7QUFFdkg7WUFDSixLQUFBO0FBQ0ksbUJBQUssNEJBQTRCLGlCQUFpQixtQkFBbUIsRUFBRyxFQUFFLFVBQVM7QUFDbkY7WUFDSixLQUFBO0FBQ0ksbUJBQUssNkJBQTZCLGlCQUFpQixtQkFBbUIsRUFBRyxFQUFFLFVBQVM7QUFDcEY7WUFDSjtBQUNJOztBQUVSLGVBQUssY0FBYyxLQUFLLFlBQVksT0FBTyxDQUFDLGVBQWUsZUFBZSxrQkFBa0I7O01BRXBHO01BTVEsUUFBUSxPQUFhO0FBQ3pCLGFBQUssYUFBYSxNQUFNLEtBQUs7TUFDakM7O3lCQXRHUywyQkFBd0IsaUNBQUEsa0JBQUEsR0FBQSxpQ0FBQSxZQUFBLEdBQUEsaUNBQUEseUJBQUEsR0FBQSxpQ0FBQSxxQkFBQSxHQUFBLGlDQUFBLDJCQUFBLEdBQUEsaUNBQUEsd0NBQUEsR0FBQSxpQ0FBQSxtQkFBQSxHQUFBLGlDQUFBLFdBQUEsR0FBQSxpQ0FBQSx1QkFBQSxHQUFBLGlDQUFBLHFCQUFBLENBQUE7TUFBQTtrRUFBeEIsMkJBQXdCLFdBQUEsQ0FBQSxDQUFBLHNCQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSx5QkFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsaUJBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsZ0JBQUEsb0NBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxnQkFBQSx3Q0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLGdCQUFBLDBEQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsZ0JBQUEsMkRBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxnQkFBQSxpREFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLGdCQUFBLGtEQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsYUFBQSxjQUFBLEdBQUEsUUFBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEseUJBQUEsVUFBQSxRQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSx5QkFBQSxVQUFBLFFBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsbUNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxrQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ3RCckMsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE1BQUE7QUFBTSxVQUFBLHNCQUFBLENBQUE7O0FBQXFGLFVBQUEsNEJBQUE7QUFDL0YsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwwQkFBQSxJQUFBLGtEQUFBLElBQUEsQ0FBQSxFQXlGQyxJQUFBLGtEQUFBLEdBQUEsQ0FBQTs7O0FBOUZxQixVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLDJCQUFBLElBQUEsR0FBQSx1Q0FBQSxJQUFBLFVBQUEsUUFBQSxHQUFBLENBQUE7QUFLdEIsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLElBQUEsWUFBQSxTQUFBLElBQUEsS0FBQSxFQUFBO0FBMEZBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLFlBQUEsV0FBQSxJQUFBLEtBQUEsRUFBQTs7Ozs7c0ZEN0VhLDBCQUF3QixFQUFBLFdBQUEsMkJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFbkJyQyxTQUFTLGNBQUFDLG1CQUFrQjtBQUMzQixTQUFxQixRQUFRLE9BQUFDLE1BQUssVUFBVTs7QUFKNUMsSUFRYTtBQVJiOzs7QUFDQTs7QUFPTSxJQUFPLDBCQUFQLE1BQU8seUJBQXVCO01BQ1o7TUFBcEIsWUFBb0IsU0FBZ0M7QUFBaEMsYUFBQSxVQUFBO01BQW1DO01BT3ZELFFBQVEsT0FBNkI7QUFDakMsWUFBSSxNQUFNLE9BQU8sVUFBVSxHQUFHO0FBQzFCLGlCQUFPLEtBQUssUUFBUSxLQUFLLE1BQU0sT0FBTyxVQUFVLENBQUMsRUFBRSxLQUMvQyxPQUFPLENBQUMsYUFBbUMsU0FBUyxFQUFFLEdBQ3REQSxLQUFJLENBQUMsV0FBaUMsT0FBTyxJQUFLLENBQUM7O0FBRzNELGVBQU8sR0FBRyxJQUFJLE9BQU0sQ0FBRTtNQUMxQjs7eUJBaEJTLDBCQUF1Qix3QkFBQSx1QkFBQSxDQUFBO01BQUE7cUVBQXZCLDBCQUF1QixTQUF2Qix5QkFBdUIsV0FBQSxZQURWLE9BQU0sQ0FBQTs7Ozs7O0FDTmhDLElBS2E7QUFMYjs7O0FBQ0E7QUFDQTtBQUNBO0FBRU8sSUFBTSx1QkFBK0I7TUFDeEM7UUFDSSxNQUFNO1FBQ04sV0FBVztRQUNYLFNBQVM7VUFDTCxRQUFROztRQUVaLE1BQU07VUFDRixhQUFhLENBQUMsVUFBVSxPQUFPLFVBQVUsWUFBWSxVQUFVLFFBQVEsVUFBVSxFQUFFO1VBQ25GLFdBQVc7O1FBRWYsYUFBYSxDQUFDLHNCQUFzQjs7TUFFeEM7UUFDSSxNQUFNO1FBQ04sV0FBVztRQUNYLFNBQVM7VUFDTCxRQUFROztRQUVaLE1BQU07VUFDRixhQUFhLENBQUMsVUFBVSxPQUFPLFVBQVUsWUFBWSxVQUFVLFFBQVEsVUFBVSxFQUFFO1VBQ25GLFdBQVc7O1FBRWYsYUFBYSxDQUFDLHNCQUFzQjs7Ozs7OztBQzdCNUMsU0FBUyxhQUFBQyxhQUFXLGdCQUFBQyxlQUFjLFNBQUFDLFFBQU8sVUFBQUMsZUFBYzs7OztBQ1F2QyxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxHQUFBO0FBQUcsSUFBQSxzQkFBQSxDQUFBOztBQUEwRixJQUFBLDRCQUFBO0FBQ2pHLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLGdCQUFBOzs7QUFIZSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDJCQUFBLEdBQUEsR0FBQSxpRUFBQSxDQUFBOzs7Ozs7QUFLWCxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLG9DQUFBLENBQUE7QUFFSSxJQUFBLDBCQUFBLG9CQUFBLFNBQUEsNkdBQUE7QUFBQSxZQUFBLGNBQUEsNkJBQUEsR0FBQTtBQUFBLFlBQUEsY0FBQSxZQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBO0FBQUEsYUFBb0IsMkJBQUEsT0FBQSxlQUFBLFdBQUEsQ0FBd0I7SUFBQSxDQUFBLEVBQUMsb0JBQUEsU0FBQSw2R0FBQTtBQUFBLFlBQUEsY0FBQSw2QkFBQSxHQUFBO0FBQUEsWUFBQSxjQUFBLFlBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUE7QUFBQSxhQUN6QiwyQkFBQSxRQUFBLGVBQUEsV0FBQSxDQUF3QjtJQUFBLENBQUE7QUFJL0MsSUFBQSw0QkFBQTtBQUNMLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7Ozs7O0FBUlksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxZQUFBLFdBQUEsRUFBcUIsWUFBQSxPQUFBLFFBQUEsRUFBQSx3QkFBQSxPQUFBLG9CQUFBLEVBQUEseUNBQUEsT0FBQSxxQ0FBQTs7Ozs7O0FBVTdCLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsb0NBQUEsQ0FBQTtBQUlJLElBQUEsMEJBQUEsc0JBQUEsU0FBQSw2R0FBQSxRQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBO0FBQUEsYUFBc0IsMkJBQUEsUUFBQSxpQkFBQSxNQUFBLENBQXdCO0lBQUEsQ0FBQSxFQUFDLHVCQUFBLFNBQUEsOEdBQUEsUUFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQTtBQUFBLGFBQ3hCLDJCQUFBLFFBQUEsa0JBQUEsTUFBQSxDQUF5QjtJQUFBLENBQUE7QUFFbkQsSUFBQSw0QkFBQTtBQUNMLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7Ozs7O0FBUlksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxZQUFBLGNBQUEsRUFBdUIsZ0JBQUEsSUFBQSxFQUFBLFlBQUEsSUFBQSxFQUFBLHlDQUFBLE9BQUEscUNBQUE7OztBRDdCL0MsSUFTYTtBQVRiOztBQUNBO0FBQ0E7Ozs7O0FBT00sSUFBTyxnQ0FBUCxNQUFPLCtCQUE2QjtNQXdCbEI7TUF2QnBCLGVBQWU7TUFFZix1QkFBbUMsQ0FBQTtNQUNuQztNQUVTO01BQ0E7TUFDQSx3Q0FBaUQ7TUFLakQscUNBQXFDO01BRTlDLElBQWEsVUFBVSxXQUFxQjtBQUN4QyxhQUFLLHVCQUF1QixDQUFDLEdBQUcsU0FBUztNQUM3QztNQUNTLHNCQUFrQyxDQUFBO01BRWpDLGtCQUFrQixJQUFJRixjQUFZO01BQ2xDLHFCQUFxQixJQUFJQSxjQUFZO01BQ3JDLHNCQUFzQixJQUFJQSxjQUFZO01BRWhELFlBQW9CLG1DQUFvRTtBQUFwRSxhQUFBLG9DQUFBO01BQXVFO01BRXBGLGVBQWUsa0JBQTBCO0FBQzVDLGNBQU0sZ0JBQWdCLEtBQUsscUJBQXFCLFFBQVEsZ0JBQWdCO0FBQ3hFLGFBQUsscUJBQXFCLE9BQU8sZUFBZSxDQUFDO0FBQ2pELGFBQUssZ0JBQWdCLEtBQUssS0FBSyxvQkFBb0I7QUFDbkQsYUFBSyxpQkFBZ0I7TUFDekI7TUFNQSxtQkFBZ0I7QUFDWixZQUFJLENBQUMsS0FBSyx3QkFBd0IsS0FBSyxxQkFBcUIsV0FBVyxHQUFHO0FBQ3RFLGVBQUssc0JBQXNCO0FBQzNCOztBQUVKLG1CQUFXLFlBQVksS0FBSyxzQkFBc0I7QUFDOUMsY0FBSSxTQUFTLFdBQVcsVUFBYSxNQUFNLFNBQVMsT0FBTyxHQUFHO0FBQzFELGlCQUFLLHNCQUFzQjtBQUMzQjs7O0FBR1IsYUFBSyxzQkFBc0I7TUFDL0I7TUFNQSxlQUFlLFVBQWtCO0FBQzdCLGNBQU0sZ0JBQWdCLEtBQUsscUJBQXFCLFFBQVEsUUFBUTtBQUNoRSxZQUFJLGdCQUFnQixHQUFHO0FBQ25CLGVBQUsscUJBQXFCLEtBQUssUUFBUTtlQUNwQztBQUNILGVBQUsscUJBQXFCLGFBQWEsSUFBSTs7QUFFL0MsYUFBSyxpQkFBZ0I7QUFDckIsYUFBSyxnQkFBZ0IsS0FBSyxLQUFLLG9CQUFvQjtNQUN2RDtNQUVPLDBCQUF1QjtBQUMxQixjQUFNLFdBQVcsSUFBSSxTQUFRO0FBQzdCLGlCQUFTLE9BQU8sYUFBYTtBQUc3QixZQUFJLEtBQUssb0NBQW9DO0FBQ3pDLG1CQUFTLFlBQVksS0FBSyx5Q0FBd0MsRUFBRyxTQUFROztBQUdqRixhQUFLLHFCQUFxQixLQUFLLFFBQVE7QUFDdkMsYUFBSyxpQkFBZ0I7QUFDckIsYUFBSyxnQkFBZ0IsS0FBSyxLQUFLLG9CQUFvQjtNQUN2RDtNQUtRLDJDQUF3QztBQUM1QyxZQUFJLEtBQUsscUJBQXFCLFdBQVcsR0FBRztBQUN4QyxpQkFBTzs7QUFHWCxjQUFNLGFBQWEsS0FBSyxxQkFBcUIsSUFBSSxDQUFDLGFBQVk7QUFDMUQsZ0JBQU0sS0FBSyxFQUFFLFNBQVMsYUFBYTtBQUNuQyxjQUFJLE1BQU0sRUFBRSxHQUFHO0FBQ1gsbUJBQU87O0FBRVgsaUJBQU87UUFDWCxDQUFDO0FBQ0QsZUFBTyxLQUFLLElBQUksR0FBRyxXQUFXLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO01BQ2pEO01BS0EsaUJBQWlCLFVBQWtCO0FBQy9CLGFBQUssc0JBQXNCLEtBQUssb0JBQW9CLE9BQU8sQ0FBQyxNQUFNLE1BQU0sUUFBUTtBQUdoRixpQkFBUyxPQUFPLGFBQWE7QUFFN0IsaUJBQVMsUUFBUSxTQUFTLFFBQVEsZ0NBQWdDLFFBQVEsZ0NBQWdDLHVDQUF1QztBQUNqSixhQUFLLGVBQWUsUUFBUTtBQUM1QixhQUFLLG1CQUFtQixLQUFLLFFBQVE7TUFDekM7TUFLQSxrQkFBa0IsVUFBa0I7QUFDaEMsYUFBSyxzQkFBc0IsS0FBSyxvQkFBb0IsT0FBTyxDQUFDLE1BQU0sTUFBTSxRQUFRO0FBQ2hGLGFBQUssb0JBQW9CLEtBQUssUUFBUTtNQUMxQztNQUVBLHVCQUF1QixPQUFZO0FBQy9CLGFBQUssd0JBQXVCO0FBQzVCLGNBQU0sY0FBb0MsS0FBSyxxQkFBcUIsS0FBSTtBQUN4RSxZQUFJLGFBQWE7QUFDYixlQUFLLGtDQUFrQyxvREFBb0QsYUFBYSxLQUFLO0FBQzdHLGVBQUssZUFBZSxXQUFXOztNQUV2Qzs7eUJBL0hTLGdDQUE2QixpQ0FBQSxpQ0FBQSxDQUFBO01BQUE7a0VBQTdCLGdDQUE2QixXQUFBLENBQUEsQ0FBQSwyQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFVBQUEsWUFBQSxzQkFBQSx3QkFBQSx1Q0FBQSx5Q0FBQSxvQ0FBQSxzQ0FBQSxXQUFBLGFBQUEscUJBQUEsc0JBQUEsR0FBQSxTQUFBLEVBQUEsaUJBQUEsbUJBQUEsb0JBQUEsc0JBQUEscUJBQUEsc0JBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsNkJBQUEsT0FBQSxlQUFBLFFBQUEsR0FBQSxZQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSx5Q0FBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxZQUFBLFVBQUEsR0FBQSxDQUFBLFFBQUEsU0FBQSxHQUFBLFNBQUEsbUJBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLFlBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFlBQUEsd0JBQUEseUNBQUEsb0JBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxnQkFBQSxZQUFBLHlDQUFBLHNCQUFBLHFCQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsdUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNUMUMsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUFLLFVBQUEsMEJBQUEsUUFBQSxTQUFBLDJEQUFBLFFBQUE7QUFBQSxtQkFBUSxJQUFBLHVCQUFBLE1BQUE7VUFBOEIsQ0FBQSxFQUFDLFlBQUEsU0FBQSwrREFBQSxRQUFBO0FBQUEsbUJBQWEsT0FBQSxlQUFBO1VBQXVCLENBQUE7QUFDNUUsVUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsVUFBQSxDQUFBO0FBQStELFVBQUEsMEJBQUEsU0FBQSxTQUFBLGlFQUFBO0FBQUEsbUJBQVMsSUFBQSx3QkFBQTtVQUF5QixDQUFBO0FBQzdGLFVBQUEsc0JBQUEsQ0FBQTs7QUFDSixVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUF3RSxVQUFBLHNCQUFBLElBQUEsVUFBQTtBQUFRLFVBQUEsNEJBQUE7QUFDaEYsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwwQkFBQSxJQUFBLHVEQUFBLElBQUEsQ0FBQTtBQU9BLFVBQUEsZ0NBQUEsSUFBQSwrQ0FBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHdDQUFBO0FBWUEsVUFBQSxnQ0FBQSxJQUFBLCtDQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsd0NBQUE7QUFZSixVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLElBQUE7OztBQXZDMkcsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxZQUFBLElBQUEsUUFBQTtBQUMvRixVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLGtDQUFBLGtCQUFBLDJCQUFBLEdBQUEsR0FBQSw2Q0FBQSxHQUFBLFlBQUE7QUFJQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsSUFBQSxxQkFBQSxTQUFBLElBQUEsb0JBQUEsV0FBQSxJQUFBLEtBQUEsRUFBQTtBQU9BLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsSUFBQSxvQkFBQTtBQVlBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsSUFBQSxtQkFBQTs7Ozs7c0ZEakJDLCtCQUE2QixFQUFBLFdBQUEsZ0NBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFVDFDLFNBQVMsWUFBQUcsaUJBQWdCO0FBVXpCLFNBQVMsb0JBQW9COztBQVY3QixJQWtCTSxlQStCTztBQWpEYjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxJQUFNLGdCQUFnQixDQUFDLEdBQUcsb0JBQW9CO0FBK0J4QyxJQUFPLGdDQUFQLE1BQU8sK0JBQTZCOzt5QkFBN0IsZ0NBQTZCO01BQUE7aUVBQTdCLCtCQUE2QixDQUFBOztRQTNCbEM7UUFDQTtRQUNBO1FBQ0EsYUFBYSxTQUFTLGFBQWE7UUFDbkM7UUFDQTtRQUNBO01BQXFCLEVBQUEsQ0FBQTs7OzsiLCJuYW1lcyI6WyJDb21wb25lbnQiLCJJbnB1dCIsIk5nTW9kdWxlIiwiVGV4dEFzc2Vzc21lbnRFdmVudFR5cGUiLCJMb2NhdGlvbiIsIkNvbXBvbmVudCIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwiQWN0aXZhdGVkUm91dGUiLCJfYzAiLCJDb21wb25lbnQiLCJJbnB1dCIsIkNvbXBvbmVudCIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwiQ29tcG9uZW50IiwiSW5wdXQiLCJfYzAiLCJJbmplY3RhYmxlIiwiQ29tcG9uZW50IiwiSW5wdXQiLCJfYzAiLCJfYzEiLCJDb21wb25lbnQiLCJFdmVudEVtaXR0ZXIiLCJJbnB1dCIsIk91dHB1dCIsImZhUXVlc3Rpb25DaXJjbGUiLCJmYVRyYXNoIiwiX2MwIiwiSW5qZWN0YWJsZSIsIkNvbXBvbmVudCIsIkFjdGl2YXRlZFJvdXRlIiwiTG9jYXRpb24iLCJUcmFuc2xhdGVTZXJ2aWNlIiwiX2MwIiwiX2MxIiwiSW5qZWN0YWJsZSIsIm1hcCIsIkNvbXBvbmVudCIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwiTmdNb2R1bGUiXX0=