import {
  ArtemisCoreModule,
  LoadingNotificationService,
  LoginService,
  SentryErrorHandler,
  init_core_module,
  init_loading_notification_service,
  init_login_service,
  init_sentry_error_handler
} from "/chunk-AR2U5IHX.js";
import {
  ApollonDiagramService,
  init_apollon_diagram_service
} from "/chunk-IBIEBAZF.js";
import {
  ArtemisCoursesModule,
  init_courses_module
} from "/chunk-ORFGDS2U.js";
import {
  AdminSystemNotificationService,
  SystemNotificationService,
  init_admin_system_notification_service,
  init_system_notification_service
} from "/chunk-5VDUCJJ6.js";
import {
  ExerciseHintService,
  init_exercise_hint_service
} from "/chunk-FM7Y5DDY.js";
import "/chunk-TQC3QNXR.js";
import {
  ArtemisComplaintsModule,
  init_complaints_module
} from "/chunk-YXA3WNWK.js";
import "/chunk-HPI3PUA5.js";
import {
  ExamExerciseUpdateService,
  init_exam_exercise_update_service
} from "/chunk-DYZ6VJ3M.js";
import "/chunk-DBGVWL5C.js";
import "/chunk-SE7ZOI4O.js";
import {
  ExamParticipationService,
  init_exam_participation_service
} from "/chunk-YSWFPBNG.js";
import {
  JhiLanguageHelper,
  init_language_helper
} from "/chunk-TAMMSE46.js";
import {
  LANGUAGES,
  init_language_constants
} from "/chunk-7UUXNRQV.js";
import "/chunk-6HPWWGFU.js";
import "/chunk-O2UXKYID.js";
import {
  ModalConfirmAutofocusComponent,
  init_modal_confirm_autofocus_component
} from "/chunk-ZVM6GU35.js";
import {
  OrionConnectorService,
  init_orion_connector_service
} from "/chunk-ELJG2GZQ.js";
import "/chunk-XIMSG2TX.js";
import {
  ArtemisHeaderExercisePageWithDetailsModule,
  init_exercise_headers_module
} from "/chunk-YH2LEYJ2.js";
import "/chunk-G2ISVTQO.js";
import "/chunk-KZDJAYFO.js";
import "/chunk-TNU7DPOK.js";
import {
  ArtemisNavigationUtilService,
  init_navigation_utils
} from "/chunk-QOKTVWNZ.js";
import {
  AboutIrisComponent,
  init_about_iris_component
} from "/chunk-2K363X3D.js";
import {
  UserService,
  init_user_service
} from "/chunk-L42QZYL5.js";
import {
  Theme,
  ThemeService,
  init_theme_service
} from "/chunk-PVIIR7SL.js";
import {
  ArtemisServerDateService,
  ArtemisSharedComponentModule,
  Direction,
  DocumentationButtonComponent,
  GuidedTourService,
  LIVE_EXAM_EXERCISE_UPDATE_NOTIFICATION_TITLE,
  MENTIONED_IN_MESSAGE_TITLE,
  MetisConversationService,
  NEW_ANNOUNCEMENT_POST_TITLE,
  NEW_COURSE_POST_TITLE,
  NEW_EXAM_POST_TITLE,
  NEW_EXERCISE_POST_TITLE,
  NEW_LECTURE_POST_TITLE,
  NEW_MESSAGE_TITLE,
  NEW_REPLY_FOR_COURSE_POST_TITLE,
  NEW_REPLY_FOR_EXAM_POST_TITLE,
  NEW_REPLY_FOR_EXERCISE_POST_TITLE,
  NEW_REPLY_FOR_LECTURE_POST_TITLE,
  NEW_REPLY_MESSAGE_TITLE,
  NotificationService,
  NotificationSettingsService,
  Orientation,
  OverlayPosition,
  ParticipationWebsocketService,
  QUIZ_EXERCISE_STARTED_TITLE,
  UserInteractionEvent,
  UserSettingsCategory,
  UserSettingsService,
  VideoTourStep,
  calculateLeftOffset,
  calculateTopOffset,
  cancelTour,
  completedTour,
  init_documentation_button_component,
  init_general_tour,
  init_guided_tour_constants,
  init_guided_tour_service,
  init_guided_tour_step_model,
  init_guided_tour_utils,
  init_metis_conversation_service,
  init_notification_model,
  init_notification_service,
  init_notification_settings_service,
  init_participation_websocket_service,
  init_server_date_service,
  init_shared_component_module,
  init_user_settings_constants,
  init_user_settings_service,
  isElementInViewPortHorizontally,
  reloadNotificationSideBarMessage
} from "/chunk-ORYTP7RT.js";
import "/chunk-HFO42WCR.js";
import {
  DEBUG_INFO_ENABLED,
  PASSWORD_MIN_LENGTH,
  PROFILE_LOCALCI,
  USERNAME_MIN_LENGTH,
  VERSION,
  init_app_constants
} from "/chunk-FM4KGV2V.js";
import "/chunk-H46RESQY.js";
import {
  StateStorageService,
  UserRouteAccessService,
  init_orion,
  init_state_storage_service,
  init_user_route_access_service,
  isOrion
} from "/chunk-KQ77WIWP.js";
import "/chunk-EI7VZDEV.js";
import {
  init_global_utils,
  onError
} from "/chunk-LW4WH7EZ.js";
import {
  AccountService,
  AlertOverlayComponent,
  AlertService,
  ArtemisDatePipe,
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  Authority,
  CourseManagementService,
  EntityTitleService,
  EntityType,
  EventManager,
  ExamManagementService,
  ExerciseService,
  FindLanguageFromKeyPipe,
  HasAnyAuthorityDirective,
  JhiConnectionWarningComponent,
  JhiWebsocketService,
  LectureService,
  LocaleConversionService,
  OrganizationManagementService,
  ProfileService,
  SafeResourceUrlPipe,
  TranslateDirective,
  __async,
  __commonJS,
  __esm,
  convertDateFromServer,
  init_account_service,
  init_alert_overlay_component,
  init_alert_service,
  init_artemis_date_pipe,
  init_artemis_translate_pipe,
  init_authority_constants,
  init_connection_warning_component,
  init_course_management_service,
  init_date_utils,
  init_entity_title_service,
  init_event_manager_service,
  init_exam_management_service,
  init_exercise_service,
  init_find_language_from_key_pipe,
  init_has_any_authority_directive,
  init_lecture_service,
  init_locale_conversion_service,
  init_organization_management_service,
  init_profile_service,
  init_safe_resource_url_pipe,
  init_saml2_config,
  init_shared_module,
  init_translate_directive,
  init_translation_config,
  init_websocket_service,
  translationNotFoundMessage
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/polyfills.ts
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/zone__js.js?v=1d0d9ead";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_localize_init.js?v=1d0d9ead";
import __vite__cjsImport37_process from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/process.js?v=1d0d9ead"; const process2 = __vite__cjsImport37_process;
var init_polyfills = __esm({
  "src/main/webapp/app/polyfills.ts"() {
    window.global = window;
    window["process"] = process2;
  }
});

// src/main/webapp/app/shared/util/array.extension.ts
var init_array_extension = __esm({
  "src/main/webapp/app/shared/util/array.extension.ts"() {
    if (!Array.prototype.last) {
      Array.prototype.last = function last() {
        if (!this.length) {
          return void 0;
        }
        return this[this.length - 1];
      };
    }
    if (!Array.prototype.first) {
      Array.prototype.first = function first() {
        if (!this.length) {
          return void 0;
        }
        return this[0];
      };
    }
    if (!Array.prototype.shuffle) {
      Array.prototype.shuffle = function shuffle() {
        if (this.length > 1) {
          for (let i = this.length - 1; i > 0; i--) {
            const randomIndex = Math.floor(Math.random() * (i + 1));
            const randomElement = this[randomIndex];
            this[randomIndex] = this[i];
            this[i] = randomElement;
          }
        }
      };
    }
  }
});

// src/main/webapp/app/shared/util/map.extension.ts
var init_map_extension = __esm({
  "src/main/webapp/app/shared/util/map.extension.ts"() {
    if (!Map.prototype.computeIfAbsent) {
      Map.prototype.computeIfAbsent = function(key, mappingFunction) {
        const value = this.get(key);
        if (value !== void 0) {
          return value;
        }
        const valueToAdd = mappingFunction(key);
        this.set(key, valueToAdd);
        return valueToAdd;
      };
    }
  }
});

// src/main/webapp/app/shared/util/string.extension.ts
var init_string_extension = __esm({
  "src/main/webapp/app/shared/util/string.extension.ts"() {
    if (!String.prototype.replaceAll) {
      String.prototype.replaceAll = function(search, replacement) {
        return this.replace(new RegExp(search, "g"), replacement);
      };
    }
  }
});

// src/main/webapp/app/core/config/prod.config.ts
import { enableProdMode } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function ProdConfig() {
  if (!DEBUG_INFO_ENABLED) {
    enableProdMode();
  }
}
var init_prod_config = __esm({
  "src/main/webapp/app/core/config/prod.config.ts"() {
    init_app_constants();
  }
});

// src/main/webapp/app/shared/notification/system-notification/system-notification.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisSystemNotificationModule;
var init_system_notification_module = __esm({
  "src/main/webapp/app/shared/notification/system-notification/system-notification.module.ts"() {
    init_shared_module();
    init_system_notification_service();
    init_admin_system_notification_service();
    ArtemisSystemNotificationModule = class _ArtemisSystemNotificationModule {
      static \u0275fac = function ArtemisSystemNotificationModule_Factory(t) {
        return new (t || _ArtemisSystemNotificationModule)();
      };
      static \u0275mod = i0.\u0275\u0275defineNgModule({ type: _ArtemisSystemNotificationModule });
      static \u0275inj = i0.\u0275\u0275defineInjector({ providers: [SystemNotificationService, AdminSystemNotificationService], imports: [ArtemisSharedModule] });
    };
  }
});

// src/main/webapp/app/guided-tour/guided-tour.component.ts
import { Component, ElementRef, HostListener, QueryList, Renderer2, ViewChild, ViewChildren, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { fromEvent } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { take, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { faArrowsAlt, faCheck, faChevronLeft, faChevronRight, faCircleNotch, faClipboardList, faEdit, faHandPointUp, faICursor, faInfoCircle, faPlayCircle, faVideo } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function GuidedTourComponent_Conditional_0_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                ");
    i02.\u0275\u0275elementStart(3, "div", 0);
    i02.\u0275\u0275listener("click", function GuidedTourComponent_Conditional_0_Conditional_3_Template_div_click_3_listener($event) {
      i02.\u0275\u0275restoreView(_r5);
      const ctx_r4 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r4.backdropClick($event));
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n        ");
  }
}
function GuidedTourComponent_Conditional_0_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275elementStart(1, "div", 1);
    i02.\u0275\u0275listener("click", function GuidedTourComponent_Conditional_0_Conditional_4_Template_div_click_1_listener($event) {
      i02.\u0275\u0275restoreView(_r7);
      const ctx_r6 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r6.backdropClick($event));
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(2, "\n            ");
    i02.\u0275\u0275elementStart(3, "div", 1);
    i02.\u0275\u0275listener("click", function GuidedTourComponent_Conditional_0_Conditional_4_Template_div_click_3_listener($event) {
      i02.\u0275\u0275restoreView(_r7);
      const ctx_r8 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r8.backdropClick($event));
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n            ");
    i02.\u0275\u0275elementStart(5, "div", 1);
    i02.\u0275\u0275listener("click", function GuidedTourComponent_Conditional_0_Conditional_4_Template_div_click_5_listener($event) {
      i02.\u0275\u0275restoreView(_r7);
      const ctx_r9 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r9.backdropClick($event));
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n            ");
    i02.\u0275\u0275elementStart(7, "div", 1);
    i02.\u0275\u0275listener("click", function GuidedTourComponent_Conditional_0_Conditional_4_Template_div_click_7_listener($event) {
      i02.\u0275\u0275restoreView(_r7);
      const ctx_r10 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r10.backdropClick($event));
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n            ");
    i02.\u0275\u0275elementStart(9, "div", 2);
    i02.\u0275\u0275listener("click", function GuidedTourComponent_Conditional_0_Conditional_4_Template_div_click_9_listener($event) {
      i02.\u0275\u0275restoreView(_r7);
      const ctx_r11 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r11.backdropClick($event));
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n        ");
  }
  if (rf & 2) {
    const ctx_r3 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("ngStyle", ctx_r3.getOverlayStyle(ctx_r3.OverlayPosition.TOP) || null);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("ngStyle", ctx_r3.getOverlayStyle(ctx_r3.OverlayPosition.LEFT) || null);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("ngStyle", ctx_r3.getOverlayStyle(ctx_r3.OverlayPosition.RIGHT) || null);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("ngStyle", ctx_r3.getOverlayStyle(ctx_r3.OverlayPosition.BOTTOM) || null);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275classProp("click-through", ctx_r3.currentTourStep.userInteractionEvent);
    i02.\u0275\u0275property("ngStyle", ctx_r3.getOverlayStyle(ctx_r3.OverlayPosition.ELEMENT) || null);
  }
}
function GuidedTourComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n    ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n        ");
    i02.\u0275\u0275template(3, GuidedTourComponent_Conditional_0_Conditional_3_Template, 6, 0)(4, GuidedTourComponent_Conditional_0_Conditional_4_Template, 11, 7);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, !ctx_r0.selectedElementRect ? 3 : 4);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275element(1, "div", 9);
    i02.\u0275\u0275text(2, "\n                ");
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_9_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r31 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("", i02.\u0275\u0275pipeBind2(3, 1, "tour.step", i02.\u0275\u0275pureFunction1(4, _c3, ctx_r31.guidedTourService.getCurrentStepString())), " ");
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "h3", 10);
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275template(3, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_9_Conditional_3_Template, 5, 6);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r15 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, !ctx_r15.guidedTourService.isOnResizeMessage && ctx_r15.guidedTourService.currentTour && ctx_r15.guidedTourService.currentTour.steps.length > 1 ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275textInterpolate1("\n                                ", i02.\u0275\u0275pipeBind1(5, 2, ctx_r15.currentTourStep.headlineTranslateKey), "\n                            ");
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r33 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div", 11);
    i02.\u0275\u0275listener("click", function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_10_Template_div_click_1_listener() {
      i02.\u0275\u0275restoreView(_r33);
      const ctx_r32 = i02.\u0275\u0275nextContext(3);
      return i02.\u0275\u0275resetView(ctx_r32.guidedTourService.isCurrentTour(ctx_r32.cancelTour) || ctx_r32.guidedTourService.isCurrentTour(ctx_r32.completedTour) ? ctx_r32.guidedTourService.resetTour() : ctx_r32.guidedTourService.skipTour());
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(2, "\n                        ");
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275element(1, "h5", 12);
    i02.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r17 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275propertyInterpolate("jhiTranslate", ctx_r17.currentTourStep.subHeadlineTranslateKey);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div", 13);
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275elementStart(3, "div", 14);
    i02.\u0275\u0275text(4, "\n                                    ");
    i02.\u0275\u0275element(5, "fa-icon", 15);
    i02.\u0275\u0275text(6, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                                ");
    i02.\u0275\u0275elementStart(8, "div", 16);
    i02.\u0275\u0275text(9, "\n                                    ");
    i02.\u0275\u0275element(10, "div", 7);
    i02.\u0275\u0275pipe(11, "artemisTranslate");
    i02.\u0275\u0275text(12, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(13, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(14, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r18 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275property("icon", ctx_r18.faInfoCircle);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275property("innerHTML", i02.\u0275\u0275pipeBind1(11, 2, ctx_r18.currentTourStep.hintTranslateKey), i02.\u0275\u0275sanitizeHtml);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div", 17);
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275elementStart(3, "div", 14);
    i02.\u0275\u0275text(4, "\n                                    ");
    i02.\u0275\u0275element(5, "fa-icon", 15);
    i02.\u0275\u0275text(6, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                                ");
    i02.\u0275\u0275elementStart(8, "div", 16);
    i02.\u0275\u0275text(9, "\n                                    ");
    i02.\u0275\u0275element(10, "div", 7);
    i02.\u0275\u0275pipe(11, "artemisTranslate");
    i02.\u0275\u0275text(12, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(13, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(14, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r19 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275property("icon", ctx_r19.faCheck);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275property("innerHTML", i02.\u0275\u0275pipeBind1(11, 2, ctx_r19.currentTourStep.alreadyExecutedTranslateKey), i02.\u0275\u0275sanitizeHtml);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275elementStart(1, "div", 14);
    i02.\u0275\u0275text(2, "\n                                        ");
    i02.\u0275\u0275element(3, "fa-icon", 15);
    i02.\u0275\u0275text(4, "\n                                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r34 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("icon", ctx_r34.faCheck);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_4_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                            ");
    i02.\u0275\u0275element(1, "fa-icon", 15);
    i02.\u0275\u0275text(2, "\n                                        ");
  }
  if (rf & 2) {
    const ctx_r41 = i02.\u0275\u0275nextContext(5);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("icon", ctx_r41.faHandPointUp);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_4_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                            ");
    i02.\u0275\u0275element(1, "fa-icon", 15);
    i02.\u0275\u0275text(2, "\n                                        ");
  }
  if (rf & 2) {
    const ctx_r42 = i02.\u0275\u0275nextContext(5);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("icon", ctx_r42.faICursor);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_4_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                            ");
    i02.\u0275\u0275element(1, "fa-icon", 19);
    i02.\u0275\u0275text(2, "\n                                        ");
  }
  if (rf & 2) {
    const ctx_r43 = i02.\u0275\u0275nextContext(5);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("spin", true)("icon", ctx_r43.faCircleNotch);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_4_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                            ");
    i02.\u0275\u0275element(1, "fa-icon", 15);
    i02.\u0275\u0275text(2, "\n                                        ");
  }
  if (rf & 2) {
    const ctx_r44 = i02.\u0275\u0275nextContext(5);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("icon", ctx_r44.faArrowsAlt);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_4_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                            ");
    i02.\u0275\u0275element(1, "fa-icon", 15);
    i02.\u0275\u0275text(2, "\n                                        ");
  }
  if (rf & 2) {
    const ctx_r45 = i02.\u0275\u0275nextContext(5);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("icon", ctx_r45.faEdit);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275elementStart(1, "div", 14);
    i02.\u0275\u0275text(2, "\n                                        ");
    i02.\u0275\u0275template(3, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_4_Conditional_3_Template, 3, 1)(4, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_4_Conditional_4_Template, 3, 1)(5, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_4_Conditional_5_Template, 3, 2)(6, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_4_Conditional_6_Template, 3, 1)(7, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_4_Conditional_7_Template, 3, 1);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r35 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, ctx_r35.currentTourStep.userInteractionEvent === ctx_r35.UserInteractionEvent.CLICK ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(4, ctx_r35.currentTourStep.userInteractionEvent === ctx_r35.UserInteractionEvent.ACE_EDITOR ? 4 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(5, ctx_r35.currentTourStep.userInteractionEvent === ctx_r35.UserInteractionEvent.WAIT_FOR_SELECTOR ? 5 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(6, ctx_r35.currentTourStep.userInteractionEvent === ctx_r35.UserInteractionEvent.MODELING && !ctx_r35.currentTourStep.modelingTask ? 6 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(7, ctx_r35.currentTourStep.userInteractionEvent === ctx_r35.UserInteractionEvent.ASSESS_SUBMISSION ? 7 : -1);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                        ");
    i02.\u0275\u0275element(1, "span", 20);
    i02.\u0275\u0275text(2, "\n                                    ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("jhiTranslate", "tour.clickHint.text");
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                        ");
    i02.\u0275\u0275element(1, "span", 20);
    i02.\u0275\u0275text(2, "\n                                    ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("jhiTranslate", "tour.typeHint.text");
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                        ");
    i02.\u0275\u0275element(1, "span", 20);
    i02.\u0275\u0275text(2, "\n                                    ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("jhiTranslate", "tour.waitHint.text");
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                        ");
    i02.\u0275\u0275element(1, "span", 20);
    i02.\u0275\u0275text(2, "\n                                    ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("jhiTranslate", "tour.modelingHint.text");
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                        ");
    i02.\u0275\u0275element(1, "span", 20);
    i02.\u0275\u0275text(2, "\n                                    ");
  }
  if (rf & 2) {
    const ctx_r40 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("jhiTranslate", ctx_r40.currentTourStep.assessmentTask.taskTranslateKey);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div", 18);
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275template(3, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_3_Template, 6, 1)(4, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_4_Template, 9, 5);
    i02.\u0275\u0275elementStart(5, "div", 16);
    i02.\u0275\u0275text(6, "\n                                    ");
    i02.\u0275\u0275template(7, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_7_Template, 3, 1)(8, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_8_Template, 3, 1)(9, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_9_Template, 3, 1)(10, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_10_Template, 3, 1)(11, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Conditional_11_Template, 3, 1);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(12, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(13, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r20 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275classProp("alert-success", ctx_r20.userInteractionFinished);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(3, ctx_r20.userInteractionFinished ? 3 : 4);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275conditional(7, ctx_r20.currentTourStep.userInteractionEvent === ctx_r20.UserInteractionEvent.CLICK ? 7 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(8, ctx_r20.currentTourStep.userInteractionEvent === ctx_r20.UserInteractionEvent.ACE_EDITOR ? 8 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(9, ctx_r20.currentTourStep.userInteractionEvent === ctx_r20.UserInteractionEvent.WAIT_FOR_SELECTOR ? 9 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(10, ctx_r20.currentTourStep.userInteractionEvent === ctx_r20.UserInteractionEvent.MODELING && !ctx_r20.currentTourStep.modelingTask ? 10 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(11, ctx_r20.currentTourStep.userInteractionEvent === ctx_r20.UserInteractionEvent.ASSESS_SUBMISSION ? 11 : -1);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_21_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275elementStart(1, "div", 14);
    i02.\u0275\u0275text(2, "\n                                        ");
    i02.\u0275\u0275element(3, "fa-icon", 15);
    i02.\u0275\u0275text(4, "\n                                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r46 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("icon", ctx_r46.faClipboardList);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_21_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275elementStart(1, "div", 14);
    i02.\u0275\u0275text(2, "\n                                        ");
    i02.\u0275\u0275element(3, "fa-icon", 15);
    i02.\u0275\u0275text(4, "\n                                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r47 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("icon", ctx_r47.faCheck);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div", 18);
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275template(3, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_21_Conditional_3_Template, 6, 1)(4, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_21_Conditional_4_Template, 6, 1);
    i02.\u0275\u0275elementStart(5, "div", 16);
    i02.\u0275\u0275text(6, "\n                                    ");
    i02.\u0275\u0275element(7, "div", 7);
    i02.\u0275\u0275pipe(8, "artemisTranslate");
    i02.\u0275\u0275text(9, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r21 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275classProp("alert-success", ctx_r21.userInteractionFinished);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(3, !ctx_r21.userInteractionFinished ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(4, ctx_r21.userInteractionFinished ? 4 : -1);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("innerHTML", i02.\u0275\u0275pipeBind1(8, 5, ctx_r21.currentTourStep.modelingTask.taskTranslateKey), i02.\u0275\u0275sanitizeHtml);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275element(3, "img", 21);
    i02.\u0275\u0275text(4, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r22 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275propertyInterpolate("src", ctx_r22.currentTourStep.imageUrl, i02.\u0275\u0275sanitizeUrl);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div", 18);
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275elementStart(3, "div", 14);
    i02.\u0275\u0275text(4, "\n                                    ");
    i02.\u0275\u0275element(5, "fa-icon", 15);
    i02.\u0275\u0275text(6, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                                ");
    i02.\u0275\u0275elementStart(8, "div", 16);
    i02.\u0275\u0275text(9, "\n                                    ");
    i02.\u0275\u0275element(10, "span", 22);
    i02.\u0275\u0275text(11, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(12, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(13, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r23 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275property("icon", ctx_r23.faVideo);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275element(3, "iframe", 23);
    i02.\u0275\u0275pipe(4, "safeResourceUrl");
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275text(6, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r24 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("src", i02.\u0275\u0275pipeBind1(4, 1, i02.\u0275\u0275pipeBind1(5, 3, ctx_r24.currentTourStep.videoUrl)), i02.\u0275\u0275sanitizeResourceUrl);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    const _r49 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "button", 24);
    i02.\u0275\u0275listener("click", function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_28_Template_button_click_1_listener() {
      i02.\u0275\u0275restoreView(_r49);
      const ctx_r48 = i02.\u0275\u0275nextContext(3);
      return i02.\u0275\u0275resetView(ctx_r48.guidedTourService.backStep());
    });
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275element(3, "fa-icon", 15);
    i02.\u0275\u0275text(4, "\n                                ");
    i02.\u0275\u0275element(5, "span", 25);
    i02.\u0275\u0275text(6, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r25 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("disabled", ctx_r25.guidedTourService.isOnFirstStep);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("icon", ctx_r25.faChevronLeft);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_29_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275element(1, "fa-icon", 15);
    i02.\u0275\u0275text(2, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r50 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("icon", ctx_r50.faPlayCircle);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_29_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275element(1, "fa-icon", 28);
    i02.\u0275\u0275text(2, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r51 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("icon", ctx_r51.faCircleNotch)("spin", true);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r53 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "button", 26);
    i02.\u0275\u0275listener("click", function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_29_Template_button_click_1_listener() {
      i02.\u0275\u0275restoreView(_r53);
      const ctx_r52 = i02.\u0275\u0275nextContext(3);
      return i02.\u0275\u0275resetView(ctx_r52.guidedTourService.restartTour());
    });
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275template(3, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_29_Conditional_3_Template, 3, 1)(4, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_29_Conditional_4_Template, 3, 2);
    i02.\u0275\u0275element(5, "span", 27);
    i02.\u0275\u0275text(6, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r26 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("disabled", ctx_r26.guidedTourService.isOnResizeMessage || ctx_r26.guidedTourService.restartIsLoading);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(3, !ctx_r26.guidedTourService.restartIsLoading ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(4, ctx_r26.guidedTourService.restartIsLoading ? 4 : -1);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_30_Conditional_3_For_5_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                            ");
    i02.\u0275\u0275elementStart(1, "li", null, 32);
    i02.\u0275\u0275text(3, "\n                                                ");
    i02.\u0275\u0275elementStart(4, "span");
    i02.\u0275\u0275text(5);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                                        ");
  }
  if (rf & 2) {
    const i_r57 = ctx.$implicit;
    const ctx_r56 = i02.\u0275\u0275nextContext(5);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275classMapInterpolate1("dot-index-", ctx_r56.guidedTourService.currentTour.steps.indexOf(i_r57), "");
    i02.\u0275\u0275classProp("current", ctx_r56.guidedTourService.isCurrentStep(i_r57))("n-small", ctx_r56.calculateNSmallDot(ctx_r56.guidedTourService.currentTour.steps.indexOf(i_r57) + 1))("p-small", ctx_r56.calculatePSmallDot(ctx_r56.guidedTourService.currentTour.steps.indexOf(i_r57) + 1));
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate(ctx_r56.guidedTourService.currentTour.steps.indexOf(i_r57));
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_30_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275elementStart(1, "ul", 30, 31);
    i02.\u0275\u0275text(3, "\n                                        ");
    i02.\u0275\u0275repeaterCreate(4, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_30_Conditional_3_For_5_Template, 8, 10, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r54 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("ngStyle", i02.\u0275\u0275pureFunction1(1, _c4, "translateX(" + ctx_r54.transformX + "px)"));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275repeater(ctx_r54.guidedTourService.currentTour.steps);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div", 29);
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275template(3, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_30_Conditional_3_Template, 7, 3);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r27 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, ctx_r27.guidedTourService.currentTour && ctx_r27.guidedTourService.currentTour.steps.length > 1 ? 3 : -1);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    const _r64 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "button", 33);
    i02.\u0275\u0275listener("click", function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_31_Template_button_click_1_listener() {
      i02.\u0275\u0275restoreView(_r64);
      const ctx_r63 = i02.\u0275\u0275nextContext(3);
      return i02.\u0275\u0275resetView(ctx_r63.guidedTourService.nextStep());
    });
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275element(3, "span", 34);
    i02.\u0275\u0275text(4, "\n                                ");
    i02.\u0275\u0275element(5, "fa-icon", 15);
    i02.\u0275\u0275text(6, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r28 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("disabled", ctx_r28.currentTourStep.userInteractionEvent && !ctx_r28.userInteractionFinished);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275property("icon", ctx_r28.faChevronRight);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    const _r66 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "button", 35);
    i02.\u0275\u0275listener("click", function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_32_Template_button_click_1_listener() {
      i02.\u0275\u0275restoreView(_r66);
      const ctx_r65 = i02.\u0275\u0275nextContext(3);
      return i02.\u0275\u0275resetView(ctx_r65.guidedTourService.nextStep());
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r29 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("disabled", ctx_r29.currentTourStep.userInteractionEvent && !ctx_r29.userInteractionFinished);
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r68 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "button", 36);
    i02.\u0275\u0275listener("click", function GuidedTourComponent_Conditional_1_Conditional_3_Conditional_33_Template_button_click_1_listener() {
      i02.\u0275\u0275restoreView(_r68);
      const ctx_r67 = i02.\u0275\u0275nextContext(3);
      return i02.\u0275\u0275resetView(ctx_r67.guidedTourService.resetTour());
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(2, "\n                        ");
  }
}
function GuidedTourComponent_Conditional_1_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275elementStart(1, "div", null, 3);
    i02.\u0275\u0275text(3, "\n                ");
    i02.\u0275\u0275template(4, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_4_Template, 3, 0);
    i02.\u0275\u0275elementStart(5, "div", 4);
    i02.\u0275\u0275text(6, "\n                    ");
    i02.\u0275\u0275elementStart(7, "div", 5);
    i02.\u0275\u0275text(8, "\n                        ");
    i02.\u0275\u0275template(9, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_9_Template, 7, 4)(10, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_10_Template, 3, 0);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n                    ");
    i02.\u0275\u0275elementStart(12, "div", 6);
    i02.\u0275\u0275text(13, "\n                        ");
    i02.\u0275\u0275template(14, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_14_Template, 3, 1);
    i02.\u0275\u0275element(15, "div", 7);
    i02.\u0275\u0275pipe(16, "artemisTranslate");
    i02.\u0275\u0275text(17, "\n                        ");
    i02.\u0275\u0275template(18, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_18_Template, 15, 4)(19, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_19_Template, 15, 4)(20, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_20_Template, 14, 8)(21, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_21_Template, 12, 7)(22, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_22_Template, 6, 1)(23, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_23_Template, 14, 1)(24, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_24_Template, 8, 5);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(25, "\n                    ");
    i02.\u0275\u0275elementStart(26, "div", 8);
    i02.\u0275\u0275text(27, "\n                        ");
    i02.\u0275\u0275template(28, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_28_Template, 8, 2)(29, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_29_Template, 8, 3)(30, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_30_Template, 5, 1)(31, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_31_Template, 8, 2)(32, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_32_Template, 3, 1)(33, GuidedTourComponent_Conditional_1_Conditional_3_Conditional_33_Template, 3, 0);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(34, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(35, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(36, "\n        ");
  }
  if (rf & 2) {
    const ctx_r12 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275classMapInterpolate1("tour-step tour-", ctx_r12.orientation, "");
    i02.\u0275\u0275styleProp("top", ctx_r12.topPosition, "px")("left", ctx_r12.leftPosition, "px")("width", ctx_r12.calculatedTourStepWidth, "px")("transform", ctx_r12.transform);
    i02.\u0275\u0275classProp("page-tour-step", !ctx_r12.currentTourStep.highlightSelector)("startFade", ctx_r12.startFade)("video-tour", ctx_r12.isVideoTourStep());
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(4, ctx_r12.currentTourStep.highlightSelector ? 4 : -1);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275conditional(9, ctx_r12.currentTourStep.headlineTranslateKey ? 9 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(10, ctx_r12.guidedTourService.currentTour ? 10 : -1);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275conditional(14, ctx_r12.currentTourStep.subHeadlineTranslateKey ? 14 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("innerHTML", i02.\u0275\u0275pipeBind1(16, 35, ctx_r12.currentTourStep.contentTranslateKey), i02.\u0275\u0275sanitizeHtml);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(18, ctx_r12.currentTourStep.hintTranslateKey ? 18 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(19, ctx_r12.currentTourStep.alreadyExecutedTranslateKey ? 19 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(20, ctx_r12.currentTourStep.userInteractionEvent && !ctx_r12.currentTourStep.modelingTask ? 20 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(21, ctx_r12.currentTourStep.modelingTask ? 21 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(22, ctx_r12.currentTourStep.imageUrl ? 22 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(23, ctx_r12.currentTourStep.videoUrl ? 23 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(24, ctx_r12.currentTourStep.videoUrl ? 24 : -1);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275conditional(28, !ctx_r12.guidedTourService.isCurrentTour(ctx_r12.cancelTour) && !ctx_r12.guidedTourService.isCurrentTour(ctx_r12.completedTour) && !ctx_r12.guidedTourService.isOnResizeMessage ? 28 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(29, ctx_r12.guidedTourService.isCurrentTour(ctx_r12.completedTour) ? 29 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(30, !ctx_r12.guidedTourService.isOnResizeMessage ? 30 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(31, !ctx_r12.guidedTourService.isOnLastStep && !ctx_r12.guidedTourService.isOnResizeMessage ? 31 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(32, ctx_r12.guidedTourService.isOnLastStep && !ctx_r12.guidedTourService.isCurrentTour(ctx_r12.cancelTour) && !ctx_r12.guidedTourService.isCurrentTour(ctx_r12.completedTour) && !ctx_r12.guidedTourService.isOnResizeMessage ? 32 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(33, ctx_r12.guidedTourService.isOnResizeMessage || ctx_r12.guidedTourService.isCurrentTour(ctx_r12.cancelTour) || ctx_r12.guidedTourService.isCurrentTour(ctx_r12.completedTour) ? 33 : -1);
  }
}
function GuidedTourComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n    ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n        ");
    i02.\u0275\u0275template(3, GuidedTourComponent_Conditional_1_Conditional_3_Template, 37, 37);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, ctx_r1.currentTourStep ? 3 : -1);
  }
}
var _c0, _c1, _c2, _c3, _c4, GuidedTourComponent;
var init_guided_tour_component = __esm({
  "src/main/webapp/app/guided-tour/guided-tour.component.ts"() {
    init_guided_tour_constants();
    init_guided_tour_service();
    init_account_service();
    init_guided_tour_step_model();
    init_general_tour();
    init_guided_tour_utils();
    init_guided_tour_service();
    init_account_service();
    init_translate_directive();
    init_artemis_translate_pipe();
    init_safe_resource_url_pipe();
    _c0 = ["tourStep"];
    _c1 = ["dotNavigation"];
    _c2 = ["dotElements"];
    _c3 = (a0) => ({ string: a0 });
    _c4 = (a0) => ({ transform: a0 });
    GuidedTourComponent = class _GuidedTourComponent {
      guidedTourService;
      accountService;
      renderer;
      tourStep;
      dotNavigation;
      dotElements;
      tourStepWidth = 550;
      minimalTourStepWidth = 500;
      orientation;
      transformX;
      currentTourStep;
      selectedElementRect;
      startFade = false;
      userInteractionFinished = false;
      resizeSubscription;
      scrollSubscription;
      clickSubscription;
      OverlayPosition = OverlayPosition;
      UserInteractionEvent = UserInteractionEvent;
      cancelTour = cancelTour;
      completedTour = completedTour;
      maxDots = 10;
      transformCount = 0;
      transformXIntervalNext = -26;
      transformXIntervalPrev = 26;
      dotArray;
      currentStepIndex;
      nextStepIndex;
      faEdit = faEdit;
      faCheck = faCheck;
      faVideo = faVideo;
      faChevronRight = faChevronRight;
      faChevronLeft = faChevronLeft;
      faCircleNotch = faCircleNotch;
      faInfoCircle = faInfoCircle;
      faArrowsAlt = faArrowsAlt;
      faClipboardList = faClipboardList;
      faICursor = faICursor;
      faHandPointUp = faHandPointUp;
      faPlayCircle = faPlayCircle;
      constructor(guidedTourService, accountService, renderer) {
        this.guidedTourService = guidedTourService;
        this.accountService = accountService;
        this.renderer = renderer;
      }
      handleKeyboardEvent(event) {
        if (this.guidedTourService.isOnResizeMessage) {
          return;
        }
        switch (event.code) {
          case "ArrowRight": {
            if (this.currentTourStep && this.guidedTourService.currentTourStepDisplay <= this.guidedTourService.currentTourStepCount) {
              if (!this.currentTourStep.userInteractionEvent || this.currentTourStep.userInteractionEvent && this.userInteractionFinished) {
                this.guidedTourService.nextStep();
              }
            }
            break;
          }
          case "ArrowLeft": {
            if (this.currentTourStep && this.guidedTourService.currentTourStepDisplay > 1) {
              this.guidedTourService.backStep();
            }
            break;
          }
          case "Escape": {
            if (this.currentTourStep && !this.guidedTourService.isCurrentTour(cancelTour) && !this.guidedTourService.isCurrentTour(completedTour)) {
              this.guidedTourService.skipTour();
            } else if (this.currentTourStep && this.guidedTourService.isOnLastStep) {
              this.guidedTourService.finishGuidedTour();
            }
            break;
          }
        }
      }
      ngAfterViewInit() {
        this.guidedTourService.init();
        this.subscribeToGuidedTourCurrentStepStream();
        this.subscribeToUserInteractionState();
        this.subscribeToResizeEvent();
        this.subscribeToScrollEvent();
        this.subscribeToClickEvent();
        this.subscribeToDotChanges();
      }
      ngOnDestroy() {
        if (this.resizeSubscription) {
          this.resizeSubscription.unsubscribe();
        }
        if (this.resizeSubscription) {
          this.scrollSubscription.unsubscribe();
        }
        if (this.clickSubscription) {
          this.clickSubscription.unsubscribe();
        }
      }
      subscribeToDotChanges() {
        this.dotElements.changes.subscribe((elements) => {
          this.dotArray = elements.toArray();
        });
        this.guidedTourService.currentDotSubject.pipe(tap((currentIndex) => this.currentStepIndex = currentIndex)).subscribe();
        this.guidedTourService.nextDotSubject.pipe(tap((currentIndex) => this.nextStepIndex = currentIndex)).subscribe();
      }
      subscribeToGuidedTourCurrentStepStream() {
        this.guidedTourService.getGuidedTourCurrentStepStream().subscribe((step) => {
          this.currentTourStep = step;
          if (!this.currentTourStep) {
            this.transformCount = 0;
            this.currentStepIndex = void 0;
            this.nextStepIndex = void 0;
            this.calculateTranslateValue();
            return;
          }
          if (this.currentTourStep.orientation) {
            this.orientation = this.currentTourStep.orientation;
          }
          if (this.hasUserPermissionForCurrentTourStep()) {
            this.scrollToAndSetElement();
            this.handleTransition();
            this.guidedTourService.isBackPageNavigation.next(false);
            if (this.currentStepIndex !== void 0 && this.nextStepIndex !== void 0) {
              setTimeout(() => {
                this.calculateAndDisplayDotNavigation(this.currentStepIndex, this.nextStepIndex);
              }, 0);
            } else {
              this.calculateTranslateValue();
            }
            return;
          }
          this.selectedElementRect = void 0;
        });
      }
      subscribeToUserInteractionState() {
        this.guidedTourService.userInteractionFinishedState().subscribe((isFinished) => {
          this.userInteractionFinished = isFinished;
        });
      }
      subscribeToResizeEvent() {
        this.resizeSubscription = fromEvent(window, "resize").subscribe(() => {
          if (this.getSelectedElement()) {
            this.selectedElementRect = this.updateStepLocation(this.getSelectedElement(), true);
          }
        });
      }
      subscribeToScrollEvent() {
        this.scrollSubscription = fromEvent(window, "scroll").subscribe(() => {
          if (this.getSelectedElement()) {
            this.selectedElementRect = this.updateStepLocation(this.getSelectedElement(), true);
          }
        });
      }
      subscribeToClickEvent() {
        this.clickSubscription = fromEvent(window, "click").subscribe(() => {
          if (this.getSelectedElement()) {
            this.selectedElementRect = this.updateStepLocation(this.getSelectedElement(), true);
          }
        });
      }
      hasUserPermissionForCurrentTourStep() {
        if (!this.currentTourStep) {
          return false;
        }
        return !this.currentTourStep.permission || this.accountService.hasAnyAuthorityDirect(this.currentTourStep.permission);
      }
      scrollToAndSetElement() {
        this.selectedElementRect = this.updateStepLocation(this.getSelectedElement(), false);
        this.observeSelectedRectPosition();
        setTimeout(() => {
          if (this.isTourOnScreen(Direction.VERTICAL) && this.isTourOnScreen(Direction.HORIZONTAL)) {
            return;
          }
          if (!this.isTourOnScreen(Direction.VERTICAL)) {
            const topPosition = this.getTopScrollingPosition();
            try {
              window.scrollTo({ left: 0, top: topPosition, behavior: "smooth" });
            } catch (err) {
              if (err instanceof TypeError) {
                window.scroll(0, topPosition);
              } else {
                throw err;
              }
            }
          }
          if (!this.isTourOnScreen(Direction.HORIZONTAL)) {
            this.flipOrientation();
          }
        }, 0);
      }
      isBottom() {
        if (this.currentTourStep && this.currentTourStep.orientation) {
          return this.currentTourStep.orientation === Orientation.BOTTOM || this.currentTourStep.orientation === Orientation.BOTTOMLEFT || this.currentTourStep.orientation === Orientation.BOTTOMRIGHT;
        }
        return false;
      }
      isTop() {
        if (this.currentTourStep && this.currentTourStep.orientation) {
          return this.currentTourStep.orientation === Orientation.TOP || this.currentTourStep.orientation === Orientation.TOPLEFT || this.currentTourStep.orientation === Orientation.TOPRIGHT;
        }
        return false;
      }
      isLeft() {
        if (this.currentTourStep && this.currentTourStep.orientation) {
          return this.currentTourStep.orientation === Orientation.LEFT || this.currentTourStep.orientation === Orientation.TOPLEFT || this.currentTourStep.orientation === Orientation.BOTTOMLEFT;
        }
        return false;
      }
      isRight() {
        if (this.currentTourStep && this.currentTourStep.orientation) {
          return this.currentTourStep.orientation === Orientation.RIGHT || this.currentTourStep.orientation === Orientation.TOPRIGHT || this.currentTourStep.orientation === Orientation.BOTTOMRIGHT;
        }
        return false;
      }
      isTourOnScreen(direction) {
        if (!this.currentTourStep) {
          return false;
        }
        return !this.currentTourStep.highlightSelector || this.elementInViewport(this.getSelectedElement(), direction);
      }
      elementInViewport(element, direction) {
        if (!element) {
          return false;
        }
        let elementInViewPort = true;
        switch (direction) {
          case Direction.HORIZONTAL: {
            const width = element.offsetWidth;
            const left = calculateLeftOffset(element);
            const tourStepWidth = this.tourStep.nativeElement.offsetWidth;
            elementInViewPort = isElementInViewPortHorizontally(this.currentTourStep.orientation, left, width, tourStepWidth);
            break;
          }
          case Direction.VERTICAL: {
            const stepScreenAdjustment = this.isBottom() ? this.getStepScreenAdjustment() : -this.getStepScreenAdjustment();
            const top = calculateTopOffset(element);
            const height = element.offsetHeight;
            const tourStep = this.tourStep.nativeElement.getBoundingClientRect();
            const tourStepPosition = tourStep.top + tourStep.height;
            const windowHeight = window.innerHeight + window.scrollY;
            elementInViewPort = top >= window.scrollY - stepScreenAdjustment && top + height + 10 <= windowHeight && tourStepPosition <= windowHeight;
            break;
          }
        }
        return elementInViewPort;
      }
      flipOrientation() {
        if (this.isLeft()) {
          switch (this.currentTourStep.orientation) {
            case Orientation.LEFT: {
              this.orientation = Orientation.RIGHT;
              break;
            }
            case Orientation.TOPLEFT: {
              this.orientation = Orientation.TOPRIGHT;
              break;
            }
            case Orientation.BOTTOMLEFT: {
              this.orientation = Orientation.BOTTOMRIGHT;
              break;
            }
          }
        } else if (this.isRight()) {
          switch (this.currentTourStep.orientation) {
            case Orientation.RIGHT: {
              this.orientation = Orientation.LEFT;
              break;
            }
            case Orientation.TOPRIGHT: {
              this.orientation = Orientation.TOPLEFT;
              break;
            }
            case Orientation.BOTTOMRIGHT: {
              this.orientation = Orientation.BOTTOMLEFT;
              break;
            }
          }
        }
      }
      isVideoTourStep() {
        return this.currentTourStep instanceof VideoTourStep;
      }
      backdropClick(event) {
        if (this.guidedTourService.preventBackdropFromAdvancing) {
          event.stopPropagation();
        } else {
          this.guidedTourService.nextStep();
        }
        if (this.guidedTourService.isCurrentTour(cancelTour)) {
          this.guidedTourService.finishGuidedTour();
        }
      }
      get calculatedTourStepWidth() {
        if (!this.currentTourStep || !this.selectedElementRect) {
          return void 0;
        }
        return this.tourStepWidth - this.widthAdjustmentForScreenBound;
      }
      get topPosition() {
        if (!this.currentTourStep || !this.selectedElementRect) {
          return void 0;
        }
        if (this.isBottom()) {
          const paddingAdjustment = this.getHighlightPadding();
          return this.selectedElementRect.top + this.selectedElementRect.height + paddingAdjustment;
        }
        return this.selectedElementRect.top - this.getHighlightPadding();
      }
      get leftPosition() {
        if (!this.currentTourStep || !this.selectedElementRect) {
          return void 0;
        }
        if (this.calculatedHighlightLeftPosition === 0) {
          return 5;
        }
        if (this.calculatedHighlightLeftPosition > 0) {
          return this.calculatedHighlightLeftPosition;
        }
        const adjustment = Math.max(0, -this.calculatedHighlightLeftPosition);
        const maxAdjustment = Math.min(this.maxWidthAdjustmentForTourStep, adjustment);
        return this.calculatedHighlightLeftPosition + maxAdjustment;
      }
      getTopScrollingPosition() {
        let topPosition = 0;
        let positionAdjustment = 0;
        if (this.selectedElementRect && this.currentTourStep) {
          const stepScreenAdjustment = this.getStepScreenAdjustment();
          const tourStep = this.tourStep.nativeElement.getBoundingClientRect();
          const totalStepHeight = this.selectedElementRect.height > tourStep.height ? this.selectedElementRect.height : tourStep.height;
          if (this.isBottom()) {
            positionAdjustment = stepScreenAdjustment;
          } else {
            positionAdjustment = totalStepHeight - window.innerHeight - stepScreenAdjustment;
          }
          if (this.isTop()) {
            topPosition = window.scrollY + tourStep.top - 15;
          } else {
            topPosition = window.scrollY + this.selectedElementRect.top + positionAdjustment;
            topPosition = topPosition < 15 ? 0 : topPosition + 15;
          }
        }
        return topPosition;
      }
      getHighlightPadding() {
        if (!this.currentTourStep) {
          return 0;
        }
        return this.currentTourStep.highlightPadding ? this.currentTourStep.highlightPadding : 0;
      }
      getOverlayStyle(position) {
        if (this.selectedElementRect) {
          const selectedElementTop = this.selectedElementRect.top - this.getHighlightPadding();
          const selectedElementLeft = this.selectedElementRect.left - this.getHighlightPadding();
          const selectedElementHeight = this.selectedElementRect.height + this.getHighlightPadding() * 2;
          const selectedElementWidth = this.selectedElementRect.width + this.getHighlightPadding() * 2;
          switch (position) {
            case OverlayPosition.TOP:
              return { "top.px": 0, "left.px": 0, "height.px": selectedElementTop > 0 ? selectedElementTop : 0 };
            case OverlayPosition.LEFT:
              return {
                "top.px": selectedElementTop,
                "left.px": selectedElementLeft < 0 ? selectedElementLeft : 0,
                "height.px": selectedElementHeight,
                "width.px": selectedElementLeft > 0 ? selectedElementLeft : 0
              };
            case OverlayPosition.RIGHT:
              return { "top.px": selectedElementTop, "left.px": selectedElementLeft + selectedElementWidth, "height.px": selectedElementHeight };
            case OverlayPosition.BOTTOM:
              return { "top.px": selectedElementTop + selectedElementHeight > 0 ? selectedElementTop + selectedElementHeight : 0 };
            case OverlayPosition.ELEMENT:
              return { "top.px": selectedElementTop, "left.px": selectedElementLeft, "height.px": selectedElementHeight, "width.px": selectedElementWidth };
          }
        }
        return void 0;
      }
      get transform() {
        if (this.currentTourStep && (!this.currentTourStep.orientation && this.currentTourStep.highlightSelector || this.currentTourStep.orientation === Orientation.TOP || this.currentTourStep.orientation === Orientation.TOPRIGHT || this.currentTourStep.orientation === Orientation.TOPLEFT)) {
          return "translateY(-100%)";
        }
        return "";
      }
      getSelectedElement() {
        if (!this.currentTourStep || !this.currentTourStep.highlightSelector) {
          return void 0;
        }
        const selectedElement = document.querySelector(this.currentTourStep.highlightSelector);
        const instructions = selectedElement ? selectedElement.closest(".instructions__content__markdown") : void 0;
        if (instructions && instructions.scrollHeight > window.innerHeight && instructions.querySelector(this.currentTourStep.highlightSelector)) {
          selectedElement.scrollIntoView({ block: "center" });
        }
        return selectedElement;
      }
      get maxWidthAdjustmentForTourStep() {
        return this.tourStepWidth - this.minimalTourStepWidth;
      }
      get calculatedHighlightLeftPosition() {
        if (!this.selectedElementRect || !this.currentTourStep) {
          return 0;
        }
        const paddingAdjustment = this.currentTourStep.highlightPadding ? this.currentTourStep.highlightPadding : 0;
        if (this.orientation === Orientation.TOPRIGHT || this.orientation === Orientation.BOTTOMRIGHT) {
          return this.selectedElementRect.right - this.tourStepWidth;
        }
        if (this.orientation === Orientation.TOPLEFT || this.orientation === Orientation.BOTTOMLEFT) {
          return this.selectedElementRect.left;
        }
        if (this.orientation === Orientation.LEFT) {
          return this.selectedElementRect.left - this.tourStepWidth - paddingAdjustment;
        }
        if (this.orientation === Orientation.RIGHT) {
          return this.selectedElementRect.left + this.selectedElementRect.width + paddingAdjustment;
        }
        return this.selectedElementRect.right - this.selectedElementRect.width / 2 - this.tourStepWidth / 2;
      }
      get widthAdjustmentForScreenBound() {
        let adjustment = 0;
        if (this.calculatedHighlightLeftPosition < 0) {
          adjustment = -this.calculatedHighlightLeftPosition;
        }
        if (this.calculatedHighlightLeftPosition > window.innerWidth - this.tourStepWidth) {
          adjustment = this.calculatedHighlightLeftPosition - (window.innerWidth - this.tourStepWidth);
        }
        return Math.min(this.maxWidthAdjustmentForTourStep, adjustment);
      }
      getStepScreenAdjustment() {
        if (!this.selectedElementRect || !this.currentTourStep) {
          return 0;
        }
        if (this.orientation === Orientation.LEFT || this.orientation === Orientation.RIGHT) {
          return 0;
        }
        const elementHeight = this.selectedElementRect.height + this.tourStep.nativeElement.getBoundingClientRect().height;
        if (window.innerHeight < elementHeight) {
          return elementHeight - window.innerHeight;
        }
        return 0;
      }
      updateStepLocation(selectedElement, isResizeOrScroll) {
        let selectedElementRect;
        if (selectedElement) {
          selectedElementRect = selectedElement.getBoundingClientRect();
          if (this.currentTourStep && this.currentTourStep.userInteractionEvent && !isResizeOrScroll) {
            if (this.currentTourStep.modelingTask) {
              this.guidedTourService.enableUserInteraction(selectedElement, this.currentTourStep.userInteractionEvent, this.currentTourStep.modelingTask.umlName);
            } else {
              this.guidedTourService.enableUserInteraction(selectedElement, this.currentTourStep.userInteractionEvent);
            }
          }
        }
        return selectedElementRect;
      }
      handleTransition() {
        this.startFade = true;
        setTimeout(() => {
          this.startFade = false;
        }, 1e3);
      }
      observeSelectedRectPosition() {
        const selectedElement = this.getSelectedElement();
        const alertElement = document.querySelector(".alerts");
        if (selectedElement && alertElement) {
          this.guidedTourService.observeMutations(alertElement, { childList: true }).pipe(take(1)).subscribe(() => {
            if (this.getSelectedElement()) {
              this.scrollToAndSetElement();
            }
          });
        }
      }
      calculateAndDisplayDotNavigation(currentIndex, nextIndex) {
        const isForwardNavigation = nextIndex > currentIndex;
        const nextPlusOneIndex = isForwardNavigation ? nextIndex + 1 : nextIndex - 1;
        const nextDot = this.dotArray[nextIndex];
        const nextPlusOneDot = this.dotArray[nextPlusOneIndex];
        if (!nextDot || !nextPlusOneDot) {
          return;
        }
        if (nextIndex < this.maxDots) {
          this.transformX = 0;
        }
        if (isForwardNavigation) {
          this.handleForwardNavigation(nextDot.nativeElement, nextPlusOneDot.nativeElement, nextIndex);
        } else {
          this.handleBackwardNavigation(nextDot.nativeElement, nextPlusOneDot.nativeElement, nextIndex);
        }
      }
      handleForwardNavigation(next, nextPlusOne, nextIndex) {
        const lastDot = this.dotElements.last.nativeElement;
        if (!lastDot.classList.contains("n-small")) {
          this.dotArray.forEach((node, index) => {
            node.nativeElement.classList.remove("p-small");
            if (index === nextIndex - (this.maxDots - 2)) {
              node.nativeElement.classList.add("p-small");
            }
          });
        }
        if (next && next.classList.contains("n-small") && lastDot && !lastDot.classList.contains("n-small")) {
          this.transformCount += this.transformXIntervalNext;
          this.renderer.setStyle(this.dotNavigation.nativeElement, "transform", "translateX(" + this.transformCount + "px)");
          next.classList.remove("n-small");
          nextPlusOne.classList.add("n-small");
        }
      }
      handleBackwardNavigation(next, nextPlusOne, nextIndex) {
        const firstDot = this.dotElements.first.nativeElement;
        this.dotArray.forEach((node, index) => {
          node.nativeElement.classList.remove("n-small");
          if (this.transformCount !== 0 && index === nextIndex + 1 || this.transformCount === 0 && index === this.maxDots - 1) {
            node.nativeElement.classList.add("n-small");
          }
        });
        if (next && firstDot && !firstDot.classList.contains("p-small") && nextIndex > this.maxDots - 2) {
          this.transformCount += this.transformXIntervalPrev;
          if (this.transformCount !== 0) {
            this.transformX = this.transformCount;
          }
          if (next.classList.contains("p-small")) {
            next.classList.remove("p-small");
            nextPlusOne.classList.add("p-small");
          }
        }
      }
      calculateTranslateValue() {
        const currentTourStep = this.guidedTourService.currentTourStepIndex + 1;
        if (currentTourStep >= this.maxDots) {
          this.transformCount = (currentTourStep % this.maxDots + 1) * this.transformXIntervalNext;
        }
        this.transformX = this.transformCount;
      }
      calculateNSmallDot(stepNumber) {
        if (this.guidedTourService.currentTourStepIndex < this.maxDots) {
          return stepNumber === this.maxDots;
        }
        if (this.nextStepIndex) {
          return stepNumber === this.nextStepIndex + 1;
        }
        return false;
      }
      calculatePSmallDot(stepNumber) {
        if (this.guidedTourService.currentTourStepIndex > this.maxDots && this.guidedTourService.currentTourStepIndex < this.guidedTourService.getFilteredTourSteps().length && this.nextStepIndex) {
          return this.nextStepIndex + 1 - stepNumber === 8;
        }
        return false;
      }
      static \u0275fac = function GuidedTourComponent_Factory(t) {
        return new (t || _GuidedTourComponent)(i02.\u0275\u0275directiveInject(GuidedTourService), i02.\u0275\u0275directiveInject(AccountService), i02.\u0275\u0275directiveInject(i02.Renderer2));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _GuidedTourComponent, selectors: [["jhi-guided-tour"]], viewQuery: function GuidedTourComponent_Query(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275viewQuery(_c0, 5);
          i02.\u0275\u0275viewQuery(_c1, 5);
          i02.\u0275\u0275viewQuery(_c2, 5);
        }
        if (rf & 2) {
          let _t;
          i02.\u0275\u0275queryRefresh(_t = i02.\u0275\u0275loadQuery()) && (ctx.tourStep = _t.first);
          i02.\u0275\u0275queryRefresh(_t = i02.\u0275\u0275loadQuery()) && (ctx.dotNavigation = _t.first);
          i02.\u0275\u0275queryRefresh(_t = i02.\u0275\u0275loadQuery()) && (ctx.dotElements = _t);
        }
      }, hostBindings: function GuidedTourComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275listener("keydown", function GuidedTourComponent_keydown_HostBindingHandler($event) {
            return ctx.handleKeyboardEvent($event);
          }, false, i02.\u0275\u0275resolveDocument);
        }
      }, decls: 2, vars: 2, consts: [[1, "guided-tour-overlay", 3, "click"], [1, "guided-tour-overlay", 3, "ngStyle", "click"], [1, "guided-tour-element-overlay", 3, "ngStyle", "click"], ["tourStep", ""], [1, "tour-block"], [1, "tour-block__header"], [1, "tour-block__content"], [3, "innerHTML"], [1, "tour-block__buttons"], [1, "tour-arrow"], [1, "headline"], [1, "btn-close", 3, "click"], [1, "sub-headline", 3, "jhiTranslate"], [1, "step-hint"], [1, "step-hint__icon"], [3, "icon"], [1, "step-hint__label"], [1, "step-hint", "interaction", "alert", "alert-success"], [1, "step-hint", "interaction", "alert"], [3, "spin", "icon"], [3, "jhiTranslate"], [3, "src"], ["jhiTranslate", "tour.videoHint.text"], ["frameborder", "0", "allowfullscreen", "", 3, "src"], [1, "back-button", 3, "disabled", "click"], ["jhiTranslate", "tour.navigation.back"], [1, "restart-button", 3, "disabled", "click"], ["jhiTranslate", "global.menu.restartTutorial"], ["size", "sm", 1, "jhi-btn__loading", 3, "icon", "spin"], [1, "dotstyle", "dotstyle--scaleup"], [3, "ngStyle"], ["dotNavigation", ""], ["dotElements", ""], [1, "next-button", 3, "disabled", "click"], ["jhiTranslate", "tour.navigation.next"], ["jhiTranslate", "tour.navigation.done", 1, "next-button", 3, "disabled", "click"], ["jhiTranslate", "tour.navigation.close", 1, "next-button", 3, "click"]], template: function GuidedTourComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275template(0, GuidedTourComponent_Conditional_0_Template, 6, 1)(1, GuidedTourComponent_Conditional_1_Template, 5, 1);
        }
        if (rf & 2) {
          i02.\u0275\u0275conditional(0, ctx.currentTourStep ? 0 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(1, ctx.currentTourStep ? 1 : -1);
        }
      }, dependencies: [i3.NgStyle, i4.FaIconComponent, TranslateDirective, ArtemisTranslatePipe, SafeResourceUrlPipe], styles: ['/* src/main/webapp/app/guided-tour/guided-tour.component.scss */\n.dotstyle {\n  width: 260px;\n  overflow: hidden;\n  display: block;\n  padding: 0;\n  position: relative;\n  text-align: center;\n}\n.dotstyle.dotstyle--scaleup li span {\n  -webkit-transition: -webkit-transform 0.3s ease, background-color 0.3s ease;\n  transition: transform 0.3s ease, background-color 0.3s ease;\n}\n.dotstyle.dotstyle--scaleup li.p-small span,\n.dotstyle.dotstyle--scaleup li.n-small span {\n  -webkit-transform: scale(0.8);\n  transform: scale(0.8);\n}\n.dotstyle.dotstyle--scaleup li.current span {\n  background-color: #17a2b8;\n  -webkit-transform: scale(1.3);\n  transform: scale(1.3);\n}\n.dotstyle ul {\n  position: relative;\n  display: inline-flex;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  cursor: default;\n  vertical-align: bottom;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none;\n  transform: translateX(0);\n}\n.dotstyle ul li {\n  display: block;\n  position: relative;\n  float: left;\n  margin: 8px;\n  width: 10px;\n  height: 10px;\n  cursor: default;\n}\n.dotstyle ul li span {\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  outline: none;\n  border-radius: 50%;\n  background-color: #17a2b8;\n  background-color: rgba(23, 162, 184, 0.3);\n  text-indent: -999em;\n  cursor: default;\n  position: absolute;\n}\n@keyframes fade {\n  0% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\nbody.tour-open {\n  overflow: hidden;\n}\n.guided-tour-button {\n  background-color: var(--gt-tour-next-button-color);\n  border-radius: 50%;\n  cursor: pointer;\n  float: right;\n  height: 50px;\n  width: 50px;\n  text-align: center;\n  padding: 11px;\n}\n.guided-tour-button:hover {\n  background-color: var(--gt-tour-next-button-hover);\n}\njhi-guided-tour .guided-tour-overlay {\n  background: var(--gt-overlay-background);\n  opacity: 0.5;\n  text-align: center;\n  display: block;\n  height: 100%;\n  width: 100%;\n  top: 0;\n  left: 0;\n  position: fixed;\n  z-index: 1081;\n}\njhi-guided-tour .guided-tour-element-overlay {\n  background: none;\n  border: 5px var(--gt-tour-border-color) solid;\n  display: block;\n  position: fixed;\n  z-index: 1081;\n}\njhi-guided-tour .guided-tour-element-overlay.click-through {\n  pointer-events: none;\n}\njhi-guided-tour .tour-step {\n  min-width: 400px;\n  max-width: 1000px;\n  position: fixed;\n  z-index: 1083;\n}\njhi-guided-tour .tour-step.startFade {\n  opacity: 1;\n  animation: fade 0.6s ease;\n}\njhi-guided-tour .tour-step.page-tour-step {\n  min-width: 500px;\n  width: 80vh;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n}\n@media (max-height: 600px) {\n  jhi-guided-tour .tour-step.page-tour-step {\n    width: 100vh;\n  }\n}\n@media (max-width: 650px) {\n  jhi-guided-tour .tour-step.page-tour-step {\n    min-width: initial;\n    width: 40vh;\n  }\n}\n@media (max-width: 992px) {\n  jhi-guided-tour .tour-step.page-tour-step.video-tour {\n    width: 100%;\n    height: 100%;\n    left: 0;\n    top: 0;\n    transform: none;\n  }\n}\n@media (min-width: 993px) and (max-width: 1200px) {\n  jhi-guided-tour .tour-step.page-tour-step.video-tour {\n    width: 60%;\n  }\n}\n@media (max-height: 600px) {\n  jhi-guided-tour .tour-step.page-tour-step.video-tour .tour-block__content {\n    max-height: 75vh;\n  }\n}\njhi-guided-tour .tour-step.page-tour-step.video-tour .tour-block__content iframe {\n  aspect-ratio: 16/9;\n  min-height: auto;\n}\njhi-guided-tour .tour-step .tour-block {\n  background-color: var(--gt-tour-step-bg-color);\n  box-shadow: 0 0.4rem 0.6rem var(--gt-tour-shadow-color);\n  color: var(--gt-tour-text-color);\n  padding: 20px;\n  border-radius: 5px;\n  -webkit-border-radius: 5px;\n  -moz-border-radius: 5px;\n}\n@media (max-width: 992px) {\n  jhi-guided-tour .tour-step .tour-block {\n    height: 100%;\n  }\n}\njhi-guided-tour .tour-step .tour-block__header {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n}\njhi-guided-tour .tour-step .tour-block__header .headline {\n  display: block;\n  font-size: 18px;\n  padding-bottom: 5px;\n}\njhi-guided-tour .tour-step .tour-block__header .close {\n  width: 20px;\n  height: 20px;\n  margin: 1px -10px;\n  opacity: 0.3;\n}\njhi-guided-tour .tour-step .tour-block__header .close:hover {\n  opacity: 1;\n}\njhi-guided-tour .tour-step .tour-block__header .close:before,\njhi-guided-tour .tour-step .tour-block__header .close:after {\n  background-color: var(--gt-tour-block-after-background);\n  content: " ";\n  height: 20px;\n  width: 2px;\n  position: absolute;\n}\njhi-guided-tour .tour-step .tour-block__header .close:before {\n  transform: rotate(45deg);\n}\njhi-guided-tour .tour-step .tour-block__header .close:after {\n  transform: rotate(-45deg);\n}\njhi-guided-tour .tour-step .tour-block__content {\n  font-size: 15px;\n  min-height: 40px;\n  max-height: 80vh;\n  overflow-y: auto;\n  margin-bottom: 20px;\n}\n@media (max-height: 600px) {\n  jhi-guided-tour .tour-step .tour-block__content {\n    max-height: 60vh;\n  }\n}\njhi-guided-tour .tour-step .tour-block__content p {\n  margin-bottom: 0;\n}\njhi-guided-tour .tour-step .tour-block__content tt {\n  background-color: var(--gt-tour-block-content-tt-background);\n  padding: 4px;\n}\njhi-guided-tour .tour-step .tour-block__content ul {\n  margin-right: 15px;\n}\njhi-guided-tour .tour-step .tour-block__content ul li {\n  padding: 4px;\n}\njhi-guided-tour .tour-step .tour-block__content .red {\n  color: var(--gt-tour-block-content-red);\n}\njhi-guided-tour .tour-step .tour-block__content div > .btn,\njhi-guided-tour .tour-step .tour-block__content .step-link a,\njhi-guided-tour .tour-step .tour-block__content iframe,\njhi-guided-tour .tour-step .tour-block__content img {\n  display: block;\n  margin-top: 10px;\n  margin-left: auto;\n  margin-right: auto;\n}\njhi-guided-tour .tour-step .tour-block__content .step-hint {\n  border-radius: 3px;\n  display: flex;\n  margin: 10px 0 0 0;\n  padding: 8px;\n}\njhi-guided-tour .tour-step .tour-block__content .step-hint:not(.interaction) {\n  background: var(--gt-tour-block-step-hint-not-interaction-background);\n}\njhi-guided-tour .tour-step .tour-block__content .step-hint.interaction:not(.alert-success) {\n  background: var(--gt-tour-block-step-hint-interaction-background);\n}\njhi-guided-tour .tour-step .tour-block__content .step-hint__icon {\n  display: inline-block;\n  margin: 0 10px 0 8px;\n}\njhi-guided-tour .tour-step .tour-block__content .step-hint__label {\n  display: inline-block;\n  font-size: 13px;\n  padding-top: 3px;\n  vertical-align: text-bottom;\n}\njhi-guided-tour .tour-step .tour-block__content .sub-headline {\n  padding-bottom: 10px;\n}\njhi-guided-tour .tour-step .tour-block__content img {\n  max-width: 100%;\n}\njhi-guided-tour .tour-step .tour-block__content iframe {\n  width: 100%;\n  min-height: 400px;\n}\njhi-guided-tour .tour-step .tour-block__buttons {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  overflow: hidden;\n}\njhi-guided-tour .tour-step .tour-block__buttons button {\n  cursor: pointer;\n  float: right;\n  font-size: 14px;\n  border: none;\n  outline: none;\n  padding: 8px 15px;\n  white-space: nowrap;\n}\njhi-guided-tour .tour-step .tour-block__buttons button:disabled {\n  color: var(--gt-tour-button-text-disabled) !important;\n  background-color: var(--gt-tour-button-color-disabled) !important;\n  cursor: default;\n}\njhi-guided-tour .tour-step .tour-block__buttons button:disabled fa-icon {\n  color: var(--gt-tour-button-text-disabled) !important;\n}\njhi-guided-tour .tour-step .tour-block__buttons button.back-button {\n  background-color: var(--gt-tour-back-button-color);\n  color: var(--gt-tour-button-text-color);\n}\njhi-guided-tour .tour-step .tour-block__buttons button.back-button:hover {\n  background-color: var(--gt-tour-back-button-hover);\n  color: var(--gt-tour-button-text-color);\n}\njhi-guided-tour .tour-step .tour-block__buttons button.back-button fa-icon {\n  padding-right: 10px;\n}\njhi-guided-tour .tour-step .tour-block__buttons button.next-button {\n  background-color: var(--gt-tour-next-button-color);\n  color: var(--gt-tour-button-text-color);\n}\njhi-guided-tour .tour-step .tour-block__buttons button.next-button:hover {\n  background-color: var(--gt-tour-next-button-hover);\n  color: var(--gt-tour-button-text-color);\n}\njhi-guided-tour .tour-step .tour-block__buttons button.next-button fa-icon {\n  padding-left: 10px;\n}\njhi-guided-tour .tour-step .tour-block__buttons button.restart-button {\n  background-color: var(--gt-tour-restart-button-color);\n  color: var(--gt-tour-button-text-color);\n}\njhi-guided-tour .tour-step .tour-block__buttons button.restart-button:hover {\n  background-color: var(--gt-tour-restart-button-hover);\n  color: var(--gt-tour-button-text-color);\n}\njhi-guided-tour .tour-step .tour-block__buttons button.restart-button fa-icon {\n  padding-right: 10px;\n}\njhi-guided-tour .tour-step.tour-bottom .tour-arrow::before,\njhi-guided-tour .tour-step.tour-bottom-right .tour-arrow::before,\njhi-guided-tour .tour-step.tour-bottom-left .tour-arrow::before {\n  width: 0;\n  height: 0;\n  content: "";\n  z-index: 2;\n  border-bottom: 1rem solid var(--gt-tour-step-bg-color);\n  border-left: 1rem solid transparent;\n  border-right: 1rem solid transparent;\n  position: absolute;\n}\njhi-guided-tour .tour-step.tour-bottom .tour-block,\njhi-guided-tour .tour-step.tour-bottom-right .tour-block,\njhi-guided-tour .tour-step.tour-bottom-left .tour-block {\n  margin-top: 15px;\n}\njhi-guided-tour .tour-step.tour-top .tour-arrow::before,\njhi-guided-tour .tour-step.tour-top-right .tour-arrow::before,\njhi-guided-tour .tour-step.tour-top-left .tour-arrow::before {\n  width: 0;\n  height: 0;\n  content: "";\n  z-index: 2;\n  border-top: 1rem solid var(--gt-tour-step-bg-color);\n  border-left: 1rem solid transparent;\n  border-right: 1rem solid transparent;\n  position: absolute;\n  bottom: 0;\n}\njhi-guided-tour .tour-step.tour-top .tour-block,\njhi-guided-tour .tour-step.tour-top-right .tour-block,\njhi-guided-tour .tour-step.tour-top-left .tour-block {\n  margin-bottom: 15px;\n}\njhi-guided-tour .tour-step.tour-bottom .tour-arrow::before,\njhi-guided-tour .tour-step.tour-top .tour-arrow::before {\n  transform: translateX(-50%);\n  left: 50%;\n}\njhi-guided-tour .tour-step.tour-bottom-right .tour-arrow::before,\njhi-guided-tour .tour-step.tour-top-right .tour-arrow::before {\n  transform: translateX(-100%);\n  left: calc(100% - 5px);\n}\njhi-guided-tour .tour-step.tour-bottom-left .tour-arrow::before,\njhi-guided-tour .tour-step.tour-top-left .tour-arrow::before {\n  left: 15px;\n}\njhi-guided-tour .tour-step.tour-left .tour-arrow::before {\n  width: 0;\n  height: 0;\n  content: "";\n  z-index: 2;\n  border-left: 1rem solid var(--gt-tour-step-bg-color);\n  border-bottom: 1rem solid transparent;\n  border-top: 1rem solid transparent;\n  position: absolute;\n  left: 100%;\n  transform: translateX(-100%);\n  top: 15px;\n}\njhi-guided-tour .tour-step.tour-left .tour-block {\n  margin-right: 15px;\n}\njhi-guided-tour .tour-step.tour-right .tour-arrow::before {\n  width: 0;\n  height: 0;\n  content: "";\n  z-index: 2;\n  border-right: 1rem solid var(--gt-tour-step-bg-color);\n  border-bottom: 1rem solid transparent;\n  border-top: 1rem solid transparent;\n  position: absolute;\n  left: 0;\n  top: 15px;\n}\njhi-guided-tour .tour-step.tour-right .tour-block {\n  margin-left: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9ndWlkZWQtdG91ci9kb3QtbmF2aWdhdGlvbi5zY3NzIiwgInNyYy9tYWluL3dlYmFwcC9hcHAvZ3VpZGVkLXRvdXIvZ3VpZGVkLXRvdXIuY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qIFN0eWxlIGZvciB0aGUgbmF2aWdhdGlvbiBidWJibGVzIGluIHRoZSBndWlkZWQgdG91ciAqL1xuXG4uZG90c3R5bGUge1xuICAgIHdpZHRoOiAyNjBweDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHBhZGRpbmc6IDA7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICAgICYuZG90c3R5bGUtLXNjYWxldXAge1xuICAgICAgICBsaSB7XG4gICAgICAgICAgICBzcGFuIHtcbiAgICAgICAgICAgICAgICAtd2Via2l0LXRyYW5zaXRpb246XG4gICAgICAgICAgICAgICAgICAgIC13ZWJraXQtdHJhbnNmb3JtIDAuM3MgZWFzZSxcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvciAwLjNzIGVhc2U7XG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbjpcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtIDAuM3MgZWFzZSxcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvciAwLjNzIGVhc2U7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICYucC1zbWFsbCxcbiAgICAgICAgICAgICYubi1zbWFsbCB7XG4gICAgICAgICAgICAgICAgc3BhbiB7XG4gICAgICAgICAgICAgICAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgwLjgpO1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDAuOCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAmLmN1cnJlbnQge1xuICAgICAgICAgICAgICAgIHNwYW4ge1xuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTdhMmI4O1xuICAgICAgICAgICAgICAgICAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoMS4zKTtcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIHVsIHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICBsaXN0LXN0eWxlOiBub25lO1xuICAgICAgICBjdXJzb3I6IGRlZmF1bHQ7XG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiBib3R0b207XG4gICAgICAgIC13ZWJraXQtdXNlci1zZWxlY3Q6IG5vbmU7XG4gICAgICAgIC1tb3otdXNlci1zZWxlY3Q6IG5vbmU7XG4gICAgICAgIC1tcy11c2VyLXNlbGVjdDogbm9uZTtcbiAgICAgICAgdXNlci1zZWxlY3Q6IG5vbmU7XG4gICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgwKTtcblxuICAgICAgICBsaSB7XG4gICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgICAgIGZsb2F0OiBsZWZ0O1xuICAgICAgICAgICAgbWFyZ2luOiA4cHg7XG4gICAgICAgICAgICB3aWR0aDogMTBweDtcbiAgICAgICAgICAgIGhlaWdodDogMTBweDtcbiAgICAgICAgICAgIGN1cnNvcjogZGVmYXVsdDtcblxuICAgICAgICAgICAgc3BhbiB7XG4gICAgICAgICAgICAgICAgdG9wOiAwO1xuICAgICAgICAgICAgICAgIGxlZnQ6IDA7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICAgICAgICAgIG91dGxpbmU6IG5vbmU7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMxN2EyYjg7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyMywgMTYyLCAxODQsIDAuMyk7XG4gICAgICAgICAgICAgICAgdGV4dC1pbmRlbnQ6IC05OTllbTsgLyogbWFrZSB0aGUgdGV4dCBhY2Nlc3NpYmxlIHRvIHNjcmVlbiByZWFkZXJzICovXG4gICAgICAgICAgICAgICAgY3Vyc29yOiBkZWZhdWx0O1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cbiIsICJAaW1wb3J0ICdkb3QtbmF2aWdhdGlvbic7XG5cbi8vIFZhcmlhYmxlc1xuJHRvdXItekluZGV4OiAxMDgxICFkZWZhdWx0O1xuXG4vLyBNaXhpbnNcbkBtaXhpbiB0b3VyLWJ1dHRvbigkYmFja2dyb3VuZC1jb2xvciwgJGhvdmVyLWJhY2tncm91bmQtY29sb3IsICRwb3NpdGlvbikge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICRiYWNrZ3JvdW5kLWNvbG9yO1xuICAgIGNvbG9yOiB2YXIoLS1ndC10b3VyLWJ1dHRvbi10ZXh0LWNvbG9yKTtcblxuICAgICRvcHBvc2l0ZS1wb3M6IGxlZnQ7XG4gICAgQGlmICRwb3NpdGlvbj09cmlnaHQge1xuICAgICAgICAkb3Bwb3NpdGUtcG9zOiBsZWZ0O1xuICAgIH1cbiAgICBAaWYgJHBvc2l0aW9uPT1sZWZ0IHtcbiAgICAgICAgJG9wcG9zaXRlLXBvczogcmlnaHQ7XG4gICAgfVxuXG4gICAgJjpob3ZlciB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRob3Zlci1iYWNrZ3JvdW5kLWNvbG9yO1xuICAgICAgICBjb2xvcjogdmFyKC0tZ3QtdG91ci1idXR0b24tdGV4dC1jb2xvcik7XG4gICAgfVxuXG4gICAgZmEtaWNvbiB7XG4gICAgICAgIHBhZGRpbmctI3skb3Bwb3NpdGUtcG9zfTogMTBweDtcbiAgICB9XG59XG5cbkBtaXhpbiB0b3VyLXRyaWFuZ2xlKCRkaXJlY3Rpb24sICRjb2xvcjogY3VycmVudENvbG9yLCAkc2l6ZTogMXJlbSkge1xuICAgIEBpZiBub3QgaW5kZXgodG9wIHJpZ2h0IGJvdHRvbSBsZWZ0LCAkZGlyZWN0aW9uKSB7XG4gICAgICAgIEBlcnJvciAnRGlyZWN0aW9uIG11c3QgYmUgZWl0aGVyIGB0b3BgLCBgcmlnaHRgLCBgYm90dG9tYCBvciBgbGVmdGAuJztcbiAgICB9XG5cbiAgICAkb3Bwb3NpdGUtZGlyZWN0aW9uOiB0b3A7XG4gICAgQGlmICRkaXJlY3Rpb249PXRvcCB7XG4gICAgICAgICRvcHBvc2l0ZS1kaXJlY3Rpb246IGJvdHRvbTtcbiAgICB9XG4gICAgQGlmICRkaXJlY3Rpb249PWJvdHRvbSB7XG4gICAgICAgICRvcHBvc2l0ZS1kaXJlY3Rpb246IHRvcDtcbiAgICB9XG4gICAgQGlmICRkaXJlY3Rpb249PXJpZ2h0IHtcbiAgICAgICAgJG9wcG9zaXRlLWRpcmVjdGlvbjogbGVmdDtcbiAgICB9XG4gICAgQGlmICRkaXJlY3Rpb249PWxlZnQge1xuICAgICAgICAkb3Bwb3NpdGUtZGlyZWN0aW9uOiByaWdodDtcbiAgICB9XG5cbiAgICB3aWR0aDogMDtcbiAgICBoZWlnaHQ6IDA7XG4gICAgY29udGVudDogJyc7XG4gICAgei1pbmRleDogMjtcbiAgICBib3JkZXItI3skb3Bwb3NpdGUtZGlyZWN0aW9ufTogJHNpemUgc29saWQgJGNvbG9yO1xuICAgICRwZXJwZW5kaWN1bGFyLWJvcmRlcnM6ICRzaXplIHNvbGlkIHRyYW5zcGFyZW50O1xuICAgIEBpZiAkZGlyZWN0aW9uPT10b3Agb3IgJGRpcmVjdGlvbj09Ym90dG9tIHtcbiAgICAgICAgYm9yZGVyLWxlZnQ6ICRwZXJwZW5kaWN1bGFyLWJvcmRlcnM7XG4gICAgICAgIGJvcmRlci1yaWdodDogJHBlcnBlbmRpY3VsYXItYm9yZGVycztcbiAgICB9IEBlbHNlIGlmICRkaXJlY3Rpb249PXJpZ2h0IG9yICRkaXJlY3Rpb249PWxlZnQge1xuICAgICAgICBib3JkZXItYm90dG9tOiAkcGVycGVuZGljdWxhci1ib3JkZXJzO1xuICAgICAgICBib3JkZXItdG9wOiAkcGVycGVuZGljdWxhci1ib3JkZXJzO1xuICAgIH1cbn1cblxuQGtleWZyYW1lcyBmYWRlIHtcbiAgICAwJSB7XG4gICAgICAgIG9wYWNpdHk6IDA7XG4gICAgfVxuICAgIDEwMCUge1xuICAgICAgICBvcGFjaXR5OiAxO1xuICAgIH1cbn1cblxuYm9keS50b3VyLW9wZW4ge1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi5ndWlkZWQtdG91ci1idXR0b24ge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWd0LXRvdXItbmV4dC1idXR0b24tY29sb3IpO1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIGhlaWdodDogNTBweDtcbiAgICB3aWR0aDogNTBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcGFkZGluZzogMTFweDtcblxuICAgICY6aG92ZXIge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1ndC10b3VyLW5leHQtYnV0dG9uLWhvdmVyKTtcbiAgICB9XG59XG5cbmpoaS1ndWlkZWQtdG91ciB7XG4gICAgLmd1aWRlZC10b3VyLW92ZXJsYXkge1xuICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1ndC1vdmVybGF5LWJhY2tncm91bmQpO1xuICAgICAgICBvcGFjaXR5OiAwLjU7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIHRvcDogMDtcbiAgICAgICAgbGVmdDogMDtcbiAgICAgICAgcG9zaXRpb246IGZpeGVkO1xuICAgICAgICB6LWluZGV4OiAkdG91ci16SW5kZXg7XG4gICAgfVxuXG4gICAgLmd1aWRlZC10b3VyLWVsZW1lbnQtb3ZlcmxheSB7XG4gICAgICAgIGJhY2tncm91bmQ6IG5vbmU7XG4gICAgICAgIGJvcmRlcjogNXB4IHZhcigtLWd0LXRvdXItYm9yZGVyLWNvbG9yKSBzb2xpZDtcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICAgICAgei1pbmRleDogJHRvdXItekluZGV4O1xuXG4gICAgICAgICYuY2xpY2stdGhyb3VnaCB7XG4gICAgICAgICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC50b3VyLXN0ZXAge1xuICAgICAgICBtaW4td2lkdGg6IDQwMHB4O1xuICAgICAgICBtYXgtd2lkdGg6IDEwMDBweDtcbiAgICAgICAgcG9zaXRpb246IGZpeGVkO1xuICAgICAgICB6LWluZGV4OiAkdG91ci16SW5kZXggKyAyO1xuXG4gICAgICAgICYuc3RhcnRGYWRlIHtcbiAgICAgICAgICAgIG9wYWNpdHk6IDE7XG4gICAgICAgICAgICBhbmltYXRpb246IGZhZGUgMC42cyBlYXNlO1xuICAgICAgICB9XG5cbiAgICAgICAgJi5wYWdlLXRvdXItc3RlcCB7XG4gICAgICAgICAgICBtaW4td2lkdGg6IDUwMHB4O1xuICAgICAgICAgICAgd2lkdGg6IDgwdmg7XG4gICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xuXG4gICAgICAgICAgICBAbWVkaWEgKG1heC1oZWlnaHQ6IDYwMHB4KSB7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMHZoO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNjUwcHgpIHtcbiAgICAgICAgICAgICAgICBtaW4td2lkdGg6IGluaXRpYWw7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDQwdmg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICYudmlkZW8tdG91ciB7XG4gICAgICAgICAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDk5MnB4KSB7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgICAgICAgICAgICAgIGxlZnQ6IDA7XG4gICAgICAgICAgICAgICAgICAgIHRvcDogMDtcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiBub25lO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogOTkzcHgpIGFuZCAobWF4LXdpZHRoOiAxMjAwcHgpIHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDYwJTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAudG91ci1ibG9ja19fY29udGVudCB7XG4gICAgICAgICAgICAgICAgICAgIEBtZWRpYSAobWF4LWhlaWdodDogNjAwcHgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heC1oZWlnaHQ6IDc1dmg7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpZnJhbWUge1xuICAgICAgICAgICAgICAgICAgICAgICAgYXNwZWN0LXJhdGlvOiAxNi85O1xuICAgICAgICAgICAgICAgICAgICAgICAgbWluLWhlaWdodDogYXV0bztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC50b3VyLWJsb2NrIHtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWd0LXRvdXItc3RlcC1iZy1jb2xvcik7XG4gICAgICAgICAgICBib3gtc2hhZG93OiAwIDAuNHJlbSAwLjZyZW0gdmFyKC0tZ3QtdG91ci1zaGFkb3ctY29sb3IpO1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLWd0LXRvdXItdGV4dC1jb2xvcik7XG4gICAgICAgICAgICBwYWRkaW5nOiAyMHB4O1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICAgICAgLXdlYmtpdC1ib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICAtbW96LWJvcmRlci1yYWRpdXM6IDVweDtcblxuICAgICAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDk5MnB4KSB7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAmX19oZWFkZXIge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5cbiAgICAgICAgICAgICAgICAuaGVhZGxpbmUge1xuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogNXB4O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC5jbG9zZSB7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAyMHB4O1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDIwcHg7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMXB4IC0xMHB4O1xuICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLjM7XG5cbiAgICAgICAgICAgICAgICAgICAgJjpob3ZlciB7XG4gICAgICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAxO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgJjpiZWZvcmUsXG4gICAgICAgICAgICAgICAgICAgICY6YWZ0ZXIge1xuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tZ3QtdG91ci1ibG9jay1hZnRlci1iYWNrZ3JvdW5kKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6ICcgJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogMjBweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAycHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAmOmJlZm9yZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgJjphZnRlciB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgtNDVkZWcpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAmX19jb250ZW50IHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgICAgICAgbWluLWhlaWdodDogNDBweDtcbiAgICAgICAgICAgICAgICBtYXgtaGVpZ2h0OiA4MHZoO1xuICAgICAgICAgICAgICAgIG92ZXJmbG93LXk6IGF1dG87XG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMjBweDtcblxuICAgICAgICAgICAgICAgIEBtZWRpYSAobWF4LWhlaWdodDogNjAwcHgpIHtcbiAgICAgICAgICAgICAgICAgICAgbWF4LWhlaWdodDogNjB2aDtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBwIHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB0dCB7XG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWd0LXRvdXItYmxvY2stY29udGVudC10dC1iYWNrZ3JvdW5kKTtcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogNHB4O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHVsIHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xuXG4gICAgICAgICAgICAgICAgICAgIGxpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDRweDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC5yZWQge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0tZ3QtdG91ci1ibG9jay1jb250ZW50LXJlZCk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgZGl2ID4gLmJ0bixcbiAgICAgICAgICAgICAgICAuc3RlcC1saW5rIGEsXG4gICAgICAgICAgICAgICAgaWZyYW1lLFxuICAgICAgICAgICAgICAgIGltZyB7XG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogYXV0bztcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC5zdGVwLWhpbnQge1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMTBweCAwIDAgMDtcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogOHB4O1xuXG4gICAgICAgICAgICAgICAgICAgICY6bm90KC5pbnRlcmFjdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tZ3QtdG91ci1ibG9jay1zdGVwLWhpbnQtbm90LWludGVyYWN0aW9uLWJhY2tncm91bmQpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgJi5pbnRlcmFjdGlvbjpub3QoLmFsZXJ0LXN1Y2Nlc3MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWd0LXRvdXItYmxvY2stc3RlcC1oaW50LWludGVyYWN0aW9uLWJhY2tncm91bmQpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgJl9faWNvbiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDAgMTBweCAwIDhweDtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICZfX2xhYmVsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmctdG9wOiAzcHg7XG4gICAgICAgICAgICAgICAgICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogdGV4dC1ib3R0b207XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAuc3ViLWhlYWRsaW5lIHtcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDEwcHg7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICAgICAgICAgbWF4LXdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmcmFtZSB7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBtaW4taGVpZ2h0OiA0MDBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICZfX2J1dHRvbnMge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcblxuICAgICAgICAgICAgICAgIGJ1dHRvbiB7XG4gICAgICAgICAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgICAgICAgICAgICAgZmxvYXQ6IHJpZ2h0O1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogbm9uZTtcbiAgICAgICAgICAgICAgICAgICAgb3V0bGluZTogbm9uZTtcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogOHB4IDE1cHg7XG4gICAgICAgICAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG5cbiAgICAgICAgICAgICAgICAgICAgJjpkaXNhYmxlZCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0tZ3QtdG91ci1idXR0b24tdGV4dC1kaXNhYmxlZCkgIWltcG9ydGFudDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWd0LXRvdXItYnV0dG9uLWNvbG9yLWRpc2FibGVkKSAhaW1wb3J0YW50O1xuICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yOiBkZWZhdWx0O1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBmYS1pY29uIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0tZ3QtdG91ci1idXR0b24tdGV4dC1kaXNhYmxlZCkgIWltcG9ydGFudDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICYuYmFjay1idXR0b24ge1xuICAgICAgICAgICAgICAgICAgICAgICAgQGluY2x1ZGUgdG91ci1idXR0b24odmFyKC0tZ3QtdG91ci1iYWNrLWJ1dHRvbi1jb2xvciksIHZhcigtLWd0LXRvdXItYmFjay1idXR0b24taG92ZXIpLCBsZWZ0KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICYubmV4dC1idXR0b24ge1xuICAgICAgICAgICAgICAgICAgICAgICAgQGluY2x1ZGUgdG91ci1idXR0b24odmFyKC0tZ3QtdG91ci1uZXh0LWJ1dHRvbi1jb2xvciksIHZhcigtLWd0LXRvdXItbmV4dC1idXR0b24taG92ZXIpLCByaWdodCk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAmLnJlc3RhcnQtYnV0dG9uIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIEBpbmNsdWRlIHRvdXItYnV0dG9uKHZhcigtLWd0LXRvdXItcmVzdGFydC1idXR0b24tY29sb3IpLCB2YXIoLS1ndC10b3VyLXJlc3RhcnQtYnV0dG9uLWhvdmVyKSwgbGVmdCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAmLnRvdXItYm90dG9tLFxuICAgICAgICAmLnRvdXItYm90dG9tLXJpZ2h0LFxuICAgICAgICAmLnRvdXItYm90dG9tLWxlZnQge1xuICAgICAgICAgICAgLnRvdXItYXJyb3c6OmJlZm9yZSB7XG4gICAgICAgICAgICAgICAgQGluY2x1ZGUgdG91ci10cmlhbmdsZSh0b3AsIHZhcigtLWd0LXRvdXItc3RlcC1iZy1jb2xvcikpO1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC50b3VyLWJsb2NrIHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxNXB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgJi50b3VyLXRvcCxcbiAgICAgICAgJi50b3VyLXRvcC1yaWdodCxcbiAgICAgICAgJi50b3VyLXRvcC1sZWZ0IHtcbiAgICAgICAgICAgIC50b3VyLWFycm93OjpiZWZvcmUge1xuICAgICAgICAgICAgICAgIEBpbmNsdWRlIHRvdXItdHJpYW5nbGUoYm90dG9tLCB2YXIoLS1ndC10b3VyLXN0ZXAtYmctY29sb3IpKTtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgYm90dG9tOiAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLnRvdXItYmxvY2sge1xuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAmLnRvdXItYm90dG9tLFxuICAgICAgICAmLnRvdXItdG9wIHtcbiAgICAgICAgICAgIC50b3VyLWFycm93OjpiZWZvcmUge1xuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcbiAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAmLnRvdXItYm90dG9tLXJpZ2h0LFxuICAgICAgICAmLnRvdXItdG9wLXJpZ2h0IHtcbiAgICAgICAgICAgIC50b3VyLWFycm93OjpiZWZvcmUge1xuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtMTAwJSk7XG4gICAgICAgICAgICAgICAgbGVmdDogY2FsYygxMDAlIC0gNXB4KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgICYudG91ci1ib3R0b20tbGVmdCxcbiAgICAgICAgJi50b3VyLXRvcC1sZWZ0IHtcbiAgICAgICAgICAgIC50b3VyLWFycm93OjpiZWZvcmUge1xuICAgICAgICAgICAgICAgIGxlZnQ6IDE1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAmLnRvdXItbGVmdCB7XG4gICAgICAgICAgICAudG91ci1hcnJvdzo6YmVmb3JlIHtcbiAgICAgICAgICAgICAgICBAaW5jbHVkZSB0b3VyLXRyaWFuZ2xlKHJpZ2h0LCB2YXIoLS1ndC10b3VyLXN0ZXAtYmctY29sb3IpKTtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgbGVmdDogMTAwJTtcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTEwMCUpO1xuICAgICAgICAgICAgICAgIHRvcDogMTVweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC50b3VyLWJsb2NrIHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDE1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAmLnRvdXItcmlnaHQge1xuICAgICAgICAgICAgLnRvdXItYXJyb3c6OmJlZm9yZSB7XG4gICAgICAgICAgICAgICAgQGluY2x1ZGUgdG91ci10cmlhbmdsZShsZWZ0LCB2YXIoLS1ndC10b3VyLXN0ZXAtYmctY29sb3IpKTtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgICAgICAgICB0b3A6IDE1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAudG91ci1ibG9jayB7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRUEsQ0FBQTtBQUNJLFNBQUE7QUFDQSxZQUFBO0FBQ0EsV0FBQTtBQUNBLFdBQUE7QUFDQSxZQUFBO0FBQ0EsY0FBQTs7QUFJUSxDQVZaLFFBVVksQ0FBQSxrQkFBQSxHQUFBO0FBQ0ksc0JBQ0ksa0JBQUEsS0FBQSxJQUFBLEVBQUEsaUJBQUEsS0FBQTtBQUVKLGNBQ0ksVUFBQSxLQUFBLElBQUEsRUFBQSxpQkFBQSxLQUFBOztBQU1KLENBckJoQixRQXFCZ0IsQ0FYSixrQkFXSSxFQUFBLENBQUEsUUFBQTtBQUFBLENBckJoQixRQXFCZ0IsQ0FYSixrQkFXSSxFQUFBLENBQUEsUUFBQTtBQUNJLHFCQUFBLE1BQUE7QUFDQSxhQUFBLE1BQUE7O0FBS0osQ0E1QmhCLFFBNEJnQixDQWxCSixrQkFrQkksRUFBQSxDQUFBLFFBQUE7QUFDSSxvQkFBQTtBQUNBLHFCQUFBLE1BQUE7QUFDQSxhQUFBLE1BQUE7O0FBTWhCLENBckNKLFNBcUNJO0FBQ0ksWUFBQTtBQUNBLFdBQUE7QUFDQSxVQUFBO0FBQ0EsV0FBQTtBQUNBLGNBQUE7QUFDQSxVQUFBO0FBQ0Esa0JBQUE7QUFDQSx1QkFBQTtBQUNBLG9CQUFBO0FBQ0EsbUJBQUE7QUFDQSxlQUFBO0FBQ0EsYUFBQSxXQUFBOztBQUVBLENBbkRSLFNBbURRLEdBQUE7QUFDSSxXQUFBO0FBQ0EsWUFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxVQUFBOztBQUVBLENBNURaLFNBNERZLEdBQUEsR0FBQTtBQUNJLE9BQUE7QUFDQSxRQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxXQUFBO0FBQ0EsaUJBQUE7QUFDQSxvQkFBQTtBQUNBLG9CQUFBLEtBQUEsRUFBQSxFQUFBLEdBQUEsRUFBQSxHQUFBLEVBQUE7QUFDQSxlQUFBO0FBQ0EsVUFBQTtBQUNBLFlBQUE7O0FDWGhCLFdBQUE7QUFDSTtBQUNJLGFBQUE7O0FBRUo7QUFDSSxhQUFBOzs7QUFJUixJQUFBLENBQUE7QUFDSSxZQUFBOztBQUdKLENBQUE7QUFDSSxvQkFBQSxJQUFBO0FBQ0EsaUJBQUE7QUFDQSxVQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxTQUFBO0FBQ0EsY0FBQTtBQUNBLFdBQUE7O0FBRUEsQ0FWSixrQkFVSTtBQUNJLG9CQUFBLElBQUE7O0FBS0osZ0JBQUEsQ0FBQTtBQUNJLGNBQUEsSUFBQTtBQUNBLFdBQUE7QUFDQSxjQUFBO0FBQ0EsV0FBQTtBQUNBLFVBQUE7QUFDQSxTQUFBO0FBQ0EsT0FBQTtBQUNBLFFBQUE7QUFDQSxZQUFBO0FBQ0EsV0FsR007O0FBcUdWLGdCQUFBLENBQUE7QUFDSSxjQUFBO0FBQ0EsVUFBQSxJQUFBLElBQUEsd0JBQUE7QUFDQSxXQUFBO0FBQ0EsWUFBQTtBQUNBLFdBMUdNOztBQTRHTixnQkFBQSxDQVBKLDJCQU9JLENBQUE7QUFDSSxrQkFBQTs7QUFJUixnQkFBQSxDQUFBO0FBQ0ksYUFBQTtBQUNBLGFBQUE7QUFDQSxZQUFBO0FBQ0EsV0FBQTs7QUFFQSxnQkFBQSxDQU5KLFNBTUksQ0FBQTtBQUNJLFdBQUE7QUFDQSxhQUFBLEtBQUEsS0FBQTs7QUFHSixnQkFBQSxDQVhKLFNBV0ksQ0FBQTtBQUNJLGFBQUE7QUFDQSxTQUFBO0FBQ0EsUUFBQTtBQUNBLE9BQUE7QUFDQSxhQUFBLFVBQUEsSUFBQSxFQUFBOztBQUVBLE9BQUEsQ0FBQSxVQUFBLEVBQUE7QUFQSixrQkFBQSxDQVhKLFNBV0ksQ0FBQTtBQVFRLFdBQUE7OztBQUdKLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFYSixrQkFBQSxDQVhKLFNBV0ksQ0FBQTtBQVlRLGVBQUE7QUFDQSxXQUFBOzs7QUFJQSxPQUFBLENBQUEsU0FBQSxFQUFBO0FBREosa0JBQUEsQ0EzQlIsU0EyQlEsQ0FoQkosY0FnQkksQ0FBQTtBQUVRLFdBQUE7QUFDQSxZQUFBO0FBQ0EsVUFBQTtBQUNBLFNBQUE7QUFDQSxlQUFBOzs7QUFFSixPQUFBLENBQUEsU0FBQSxFQUFBLE9BQUEsSUFBQSxDQUFBLFNBQUEsRUFBQTtBQVJKLGtCQUFBLENBM0JSLFNBMkJRLENBaEJKLGNBZ0JJLENBQUE7QUFTUSxXQUFBOzs7QUFJQSxPQUFBLENBQUEsVUFBQSxFQUFBO0FBREosa0JBQUEsQ0F2Q1osU0F1Q1ksQ0E1QlIsY0E0QlEsQ0FaSixXQVlJLENBQUE7QUFFUSxnQkFBQTs7O0FBR0osZ0JBQUEsQ0E1Q2hCLFNBNENnQixDQWpDWixjQWlDWSxDQWpCUixXQWlCUSxDQUxKLG9CQUtJO0FBQ0ksZ0JBQUEsRUFBQSxDQUFBO0FBQ0EsY0FBQTs7QUFNaEIsZ0JBQUEsQ0FwREosVUFvREksQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxjQUFBLEVBQUEsT0FBQSxPQUFBLElBQUE7QUFDQSxTQUFBLElBQUE7QUFDQSxXQUFBO0FBQ0EsaUJBQUE7QUFDQSx5QkFBQTtBQUNBLHNCQUFBOztBQUVBLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFUSixrQkFBQSxDQXBESixVQW9ESSxDQUFBO0FBVVEsWUFBQTs7O0FBR0osZ0JBQUEsQ0FqRVIsVUFpRVEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxrQkFBQTtBQUNBLG1CQUFBOztBQUVBLGdCQUFBLENBdEVaLFVBc0VZLENBTEosbUJBS0ksQ0FBQTtBQUNJLFdBQUE7QUFDQSxhQUFBO0FBQ0Esa0JBQUE7O0FBR0osZ0JBQUEsQ0E1RVosVUE0RVksQ0FYSixtQkFXSSxDQUFBO0FBQ0ksU0FBQTtBQUNBLFVBQUE7QUFDQSxVQUFBLElBQUE7QUFDQSxXQUFBOztBQUVBLGdCQUFBLENBbEZoQixVQWtGZ0IsQ0FqQlIsbUJBaUJRLENBTkosS0FNSTtBQUNJLFdBQUE7O0FBR0osZ0JBQUEsQ0F0RmhCLFVBc0ZnQixDQXJCUixtQkFxQlEsQ0FWSixLQVVJO0FBQUEsZ0JBQUEsQ0F0RmhCLFVBc0ZnQixDQXJCUixtQkFxQlEsQ0FWSixLQVVJO0FBRUksb0JBQUEsSUFBQTtBQUNBLFdBQUE7QUFDQSxVQUFBO0FBQ0EsU0FBQTtBQUNBLFlBQUE7O0FBR0osZ0JBQUEsQ0EvRmhCLFVBK0ZnQixDQTlCUixtQkE4QlEsQ0FuQkosS0FtQkk7QUFDSSxhQUFBLE9BQUE7O0FBRUosZ0JBQUEsQ0FsR2hCLFVBa0dnQixDQWpDUixtQkFpQ1EsQ0F0QkosS0FzQkk7QUFDSSxhQUFBLE9BQUE7O0FBS1osZ0JBQUEsQ0F4R1IsVUF3R1EsQ0FqRUk7QUFrRUEsYUFBQTtBQUNBLGNBQUE7QUFDQSxjQUFBO0FBQ0EsY0FBQTtBQUNBLGlCQUFBOztBQUVBLE9BQUEsQ0FBQSxVQUFBLEVBQUE7QUFQSixrQkFBQSxDQXhHUixVQXdHUSxDQWpFSTtBQXlFSSxnQkFBQTs7O0FBR0osZ0JBQUEsQ0FuSFosVUFtSFksQ0E1RUEsb0JBNEVBO0FBQ0ksaUJBQUE7O0FBR0osZ0JBQUEsQ0F2SFosVUF1SFksQ0FoRkEsb0JBZ0ZBO0FBQ0ksb0JBQUEsSUFBQTtBQUNBLFdBQUE7O0FBR0osZ0JBQUEsQ0E1SFosVUE0SFksQ0FyRkEsb0JBcUZBO0FBQ0ksZ0JBQUE7O0FBRUEsZ0JBQUEsQ0EvSGhCLFVBK0hnQixDQXhGSixvQkF3RkksR0FBQTtBQUNJLFdBQUE7O0FBSVIsZ0JBQUEsQ0FwSVosVUFvSVksQ0E3RkEsb0JBNkZBLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBR0osZ0JBQUEsQ0F4SVosVUF3SVksQ0FqR0Esb0JBaUdBLElBQUEsRUFBQSxDQUFBO0FBQUEsZ0JBQUEsQ0F4SVosVUF3SVksQ0FqR0Esb0JBaUdBLENBQUEsVUFBQTtBQUFBLGdCQUFBLENBeElaLFVBd0lZLENBakdBLG9CQWlHQTtBQUFBLGdCQUFBLENBeElaLFVBd0lZLENBakdBLG9CQWlHQTtBQUlJLFdBQUE7QUFDQSxjQUFBO0FBQ0EsZUFBQTtBQUNBLGdCQUFBOztBQUdKLGdCQUFBLENBbEpaLFVBa0pZLENBM0dBLG9CQTJHQSxDQUFBO0FBQ0ksaUJBQUE7QUFDQSxXQUFBO0FBQ0EsVUFBQSxLQUFBLEVBQUEsRUFBQTtBQUNBLFdBQUE7O0FBRUEsZ0JBQUEsQ0F4SmhCLFVBd0pnQixDQWpISixvQkFpSEksQ0FOSixTQU1JLEtBQUEsQ0FBQTtBQUNJLGNBQUEsSUFBQTs7QUFHSixnQkFBQSxDQTVKaEIsVUE0SmdCLENBckhKLG9CQXFISSxDQVZKLFNBVUksQ0FKQSxXQUlBLEtBQUEsQ0FBQTtBQUNJLGNBQUEsSUFBQTs7QUFHSixnQkFBQSxDQWhLaEIsVUFnS2dCLENBekhKLG9CQXlISSxDQUFBO0FBQ0ksV0FBQTtBQUNBLFVBQUEsRUFBQSxLQUFBLEVBQUE7O0FBR0osZ0JBQUEsQ0FyS2hCLFVBcUtnQixDQTlISixvQkE4SEksQ0FBQTtBQUNJLFdBQUE7QUFDQSxhQUFBO0FBQ0EsZUFBQTtBQUNBLGtCQUFBOztBQUlSLGdCQUFBLENBN0taLFVBNktZLENBdElBLG9CQXNJQSxDQUFBO0FBQ0ksa0JBQUE7O0FBR0osZ0JBQUEsQ0FqTFosVUFpTFksQ0ExSUEsb0JBMElBO0FBQ0ksYUFBQTs7QUFHSixnQkFBQSxDQXJMWixVQXFMWSxDQTlJQSxvQkE4SUE7QUFDSSxTQUFBO0FBQ0EsY0FBQTs7QUFJUixnQkFBQSxDQTNMUixVQTJMUSxDQUFBO0FBQ0ksV0FBQTtBQUNBLGtCQUFBO0FBQ0EsbUJBQUE7QUFDQSxZQUFBOztBQUVBLGdCQUFBLENBak1aLFVBaU1ZLENBTkosb0JBTUk7QUFDSSxVQUFBO0FBQ0EsU0FBQTtBQUNBLGFBQUE7QUFDQSxVQUFBO0FBQ0EsV0FBQTtBQUNBLFdBQUEsSUFBQTtBQUNBLGVBQUE7O0FBRUEsZ0JBQUEsQ0ExTWhCLFVBME1nQixDQWZSLG9CQWVRLE1BQUE7QUFDSSxTQUFBLElBQUE7QUFDQSxvQkFBQSxJQUFBO0FBQ0EsVUFBQTs7QUFFQSxnQkFBQSxDQS9NcEIsVUErTW9CLENBcEJaLG9CQW9CWSxNQUFBLFVBQUE7QUFDSSxTQUFBLElBQUE7O0FBSVIsZ0JBQUEsQ0FwTmhCLFVBb05nQixDQXpCUixvQkF5QlEsTUFBQSxDQUFBO0FBalVoQixvQkFrVXlDLElBQUE7QUFqVXpDLFNBQUEsSUFBQTs7QUFVQSxnQkFBQSxDQWtHQSxVQWxHQSxDQTZSUSxvQkE3UlIsTUFBQSxDQXNUZ0IsV0F0VGhCO0FBQ0ksb0JBc1R1RSxJQUFBO0FBclR2RSxTQUFBLElBQUE7O0FBR0osZ0JBQUEsQ0E2RkEsVUE3RkEsQ0F3UlEsb0JBeFJSLE1BQUEsQ0FpVGdCLFlBalRoQjtBQUNJLGlCQUFBOztBQW9UWSxnQkFBQSxDQXhOaEIsVUF3TmdCLENBN0JSLG9CQTZCUSxNQUFBLENBQUE7QUFyVWhCLG9CQXNVeUMsSUFBQTtBQXJVekMsU0FBQSxJQUFBOztBQVVBLGdCQUFBLENBa0dBLFVBbEdBLENBNlJRLG9CQTdSUixNQUFBLENBMFRnQixXQTFUaEI7QUFDSSxvQkEwVHVFLElBQUE7QUF6VHZFLFNBQUEsSUFBQTs7QUFHSixnQkFBQSxDQTZGQSxVQTdGQSxDQXdSUSxvQkF4UlIsTUFBQSxDQXFUZ0IsWUFyVGhCO0FBQ0ksZ0JBQUE7O0FBd1RZLGdCQUFBLENBNU5oQixVQTROZ0IsQ0FqQ1Isb0JBaUNRLE1BQUEsQ0FBQTtBQXpVaEIsb0JBMFV5QyxJQUFBO0FBelV6QyxTQUFBLElBQUE7O0FBVUEsZ0JBQUEsQ0FrR0EsVUFsR0EsQ0E2UlEsb0JBN1JSLE1BQUEsQ0E4VGdCLGNBOVRoQjtBQUNJLG9CQThUMEUsSUFBQTtBQTdUMUUsU0FBQSxJQUFBOztBQUdKLGdCQUFBLENBNkZBLFVBN0ZBLENBd1JRLG9CQXhSUixNQUFBLENBeVRnQixlQXpUaEI7QUFDSSxpQkFBQTs7QUFrVUksZ0JBQUEsQ0F0T1IsU0FzT1EsQ0FBQSxZQUFBLENBQUEsVUFBQTtBQUFBLGdCQUFBLENBdE9SLFNBc09RLENBQUEsa0JBQUEsQ0FBQSxVQUFBO0FBQUEsZ0JBQUEsQ0F0T1IsU0FzT1EsQ0FBQSxpQkFBQSxDQUFBLFVBQUE7QUEzU1IsU0FBQTtBQUNBLFVBQUE7QUFDQSxXQUFBO0FBQ0EsV0FBQTtBQUNBLGlCQUFBLEtBQUEsTUFBQSxJQUFBO0FBR0ksZUFGb0IsS0FBQSxNQUFBO0FBR3BCLGdCQUhvQixLQUFBLE1BQUE7QUF3U1osWUFBQTs7QUFFSixnQkFBQSxDQTFPUixTQTBPUSxDQUpBLFlBSUEsQ0F0TEo7QUFzTEksZ0JBQUEsQ0ExT1IsU0EwT1EsQ0FKQSxrQkFJQSxDQXRMSjtBQXNMSSxnQkFBQSxDQTFPUixTQTBPUSxDQUpBLGlCQUlBLENBdExKO0FBdUxRLGNBQUE7O0FBT0osZ0JBQUEsQ0FsUFIsU0FrUFEsQ0FBQSxTQUFBLENBWkEsVUFZQTtBQUFBLGdCQUFBLENBbFBSLFNBa1BRLENBQUEsZUFBQSxDQVpBLFVBWUE7QUFBQSxnQkFBQSxDQWxQUixTQWtQUSxDQUFBLGNBQUEsQ0FaQSxVQVlBO0FBdlRSLFNBQUE7QUFDQSxVQUFBO0FBQ0EsV0FBQTtBQUNBLFdBQUE7QUFDQSxjQUFBLEtBQUEsTUFBQSxJQUFBO0FBR0ksZUFGb0IsS0FBQSxNQUFBO0FBR3BCLGdCQUhvQixLQUFBLE1BQUE7QUFvVFosWUFBQTtBQUNBLFVBQUE7O0FBRUosZ0JBQUEsQ0F2UFIsU0F1UFEsQ0FMQSxTQUtBLENBbk1KO0FBbU1JLGdCQUFBLENBdlBSLFNBdVBRLENBTEEsZUFLQSxDQW5NSjtBQW1NSSxnQkFBQSxDQXZQUixTQXVQUSxDQUxBLGNBS0EsQ0FuTUo7QUFvTVEsaUJBQUE7O0FBTUosZ0JBQUEsQ0E5UFIsU0E4UFEsQ0F4QkEsWUF3QkEsQ0F4QkEsVUF3QkE7QUFBQSxnQkFBQSxDQTlQUixTQThQUSxDQVpBLFNBWUEsQ0F4QkEsVUF3QkE7QUFDSSxhQUFBLFdBQUE7QUFDQSxRQUFBOztBQU1KLGdCQUFBLENBdFFSLFNBc1FRLENBaENBLGtCQWdDQSxDQWhDQSxVQWdDQTtBQUFBLGdCQUFBLENBdFFSLFNBc1FRLENBcEJBLGVBb0JBLENBaENBLFVBZ0NBO0FBQ0ksYUFBQSxXQUFBO0FBQ0EsUUFBQSxLQUFBLEtBQUEsRUFBQTs7QUFNSixnQkFBQSxDQTlRUixTQThRUSxDQXhDQSxpQkF3Q0EsQ0F4Q0EsVUF3Q0E7QUFBQSxnQkFBQSxDQTlRUixTQThRUSxDQTVCQSxjQTRCQSxDQXhDQSxVQXdDQTtBQUNJLFFBQUE7O0FBS0osZ0JBQUEsQ0FwUlIsU0FvUlEsQ0FBQSxVQUFBLENBOUNBLFVBOENBO0FBelZSLFNBQUE7QUFDQSxVQUFBO0FBQ0EsV0FBQTtBQUNBLFdBQUE7QUFDQSxlQUFBLEtBQUEsTUFBQSxJQUFBO0FBTUksaUJBTG9CLEtBQUEsTUFBQTtBQU1wQixjQU5vQixLQUFBLE1BQUE7QUFzVlosWUFBQTtBQUNBLFFBQUE7QUFDQSxhQUFBLFdBQUE7QUFDQSxPQUFBOztBQUVKLGdCQUFBLENBM1JSLFNBMlJRLENBUEEsVUFPQSxDQXZPSjtBQXdPUSxnQkFBQTs7QUFLSixnQkFBQSxDQWpTUixTQWlTUSxDQUFBLFdBQUEsQ0EzREEsVUEyREE7QUF0V1IsU0FBQTtBQUNBLFVBQUE7QUFDQSxXQUFBO0FBQ0EsV0FBQTtBQUNBLGdCQUFBLEtBQUEsTUFBQSxJQUFBO0FBTUksaUJBTG9CLEtBQUEsTUFBQTtBQU1wQixjQU5vQixLQUFBLE1BQUE7QUFtV1osWUFBQTtBQUNBLFFBQUE7QUFDQSxPQUFBOztBQUVKLGdCQUFBLENBdlNSLFNBdVNRLENBTkEsV0FNQSxDQW5QSjtBQW9QUSxlQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */\n'], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(GuidedTourComponent, { className: "GuidedTourComponent" });
    })();
  }
});

// src/main/webapp/app/core/theme/theme-switch.component.ts
import { Component as Component2, Input, ViewChild as ViewChild2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgbPopover } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { fromEvent as fromEvent2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { faSync } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i42 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ThemeSwitchComponent_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n    ");
    i03.\u0275\u0275elementStart(1, "div", 19);
    i03.\u0275\u0275listener("mouseenter", function ThemeSwitchComponent_ng_template_0_Template_div_mouseenter_1_listener() {
      i03.\u0275\u0275restoreView(_r4);
      const ctx_r3 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r3.openPopover());
    });
    i03.\u0275\u0275text(2, "\n        ");
    i03.\u0275\u0275elementStart(3, "div", 20);
    i03.\u0275\u0275text(4, "\u263E ");
    i03.\u0275\u0275elementStart(5, "span", 21);
    i03.\u0275\u0275text(6, "Dark Mode");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(7, " \u263E");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n        ");
    i03.\u0275\u0275elementStart(9, "div", 22);
    i03.\u0275\u0275text(10, "\n            ");
    i03.\u0275\u0275elementStart(11, "div");
    i03.\u0275\u0275element(12, "fa-icon", 23);
    i03.\u0275\u0275text(13);
    i03.\u0275\u0275pipe(14, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(15, "\n            ");
    i03.\u0275\u0275elementStart(16, "div", 24);
    i03.\u0275\u0275text(17, "\n                ");
    i03.\u0275\u0275elementStart(18, "input", 25);
    i03.\u0275\u0275listener("click", function ThemeSwitchComponent_ng_template_0_Template_input_click_18_listener() {
      i03.\u0275\u0275restoreView(_r4);
      const ctx_r5 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r5.toggleSynced());
    });
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(19, "\n            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(20, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(21, "\n    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(22, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(12);
    i03.\u0275\u0275property("icon", ctx_r0.faSync);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275textInterpolate1(" ", i03.\u0275\u0275pipeBind1(14, 3, "artemisApp.theme.sync"), "");
    i03.\u0275\u0275advance(5);
    i03.\u0275\u0275property("checked", ctx_r0.isSynced);
  }
}
var _c02, _c12, ThemeSwitchComponent;
var init_theme_switch_component = __esm({
  "src/main/webapp/app/core/theme/theme-switch.component.ts"() {
    init_theme_service();
    init_theme_service();
    init_translate_directive();
    init_artemis_translate_pipe();
    _c02 = ["popover"];
    _c12 = (a0) => ({ dark: a0 });
    ThemeSwitchComponent = class _ThemeSwitchComponent {
      themeService;
      popover;
      popoverPlacement;
      isDark = false;
      isSynced = false;
      animate = true;
      openPopupAfterNextChange = false;
      closeTimeout;
      faSync = faSync;
      constructor(themeService) {
        this.themeService = themeService;
      }
      ngOnInit() {
        this.themeService.getCurrentThemeObservable().subscribe((theme) => {
          this.isDark = theme === Theme.DARK;
          this.animate = true;
          if (this.openPopupAfterNextChange) {
            this.openPopupAfterNextChange = false;
            setTimeout(() => this.openPopover(), 250);
          }
        });
        this.themeService.getPreferenceObservable().subscribe((themeOrUndefined) => {
          this.isSynced = !themeOrUndefined;
        });
        fromEvent2(window, "click").subscribe((e) => {
          const popoverContentElement = document.getElementById("theme-switch-popover-content");
          if (this.popover.isOpen() && !popoverContentElement?.contains(e.target)) {
            this.closePopover();
          }
        });
      }
      openPopover() {
        if (!window["Cypress"]) {
          this.popover?.open();
        }
        clearTimeout(this.closeTimeout);
      }
      closePopover() {
        clearTimeout(this.closeTimeout);
        this.popover?.close();
      }
      mouseLeave() {
        clearTimeout(this.closeTimeout);
        this.closeTimeout = setTimeout(() => this.closePopover(), 250);
      }
      toggleTheme() {
        this.animate = false;
        this.openPopupAfterNextChange = true;
        setTimeout(() => this.themeService.applyThemeExplicitly(this.isDark ? Theme.LIGHT : Theme.DARK));
      }
      toggleSynced() {
        this.themeService.applyThemeExplicitly(this.isSynced ? this.themeService.getCurrentTheme() : void 0);
      }
      static \u0275fac = function ThemeSwitchComponent_Factory(t) {
        return new (t || _ThemeSwitchComponent)(i03.\u0275\u0275directiveInject(ThemeService));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _ThemeSwitchComponent, selectors: [["jhi-theme-switch"]], viewQuery: function ThemeSwitchComponent_Query(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275viewQuery(_c02, 5);
        }
        if (rf & 2) {
          let _t;
          i03.\u0275\u0275queryRefresh(_t = i03.\u0275\u0275loadQuery()) && (ctx.popover = _t.first);
        }
      }, inputs: { popoverPlacement: "popoverPlacement" }, decls: 44, vars: 8, consts: [["popContent", ""], [1, "wrapper", 3, "mouseenter", "mouseleave"], [1, "toggle-popover-wrapper", 3, "ngbPopover", "triggers", "autoClose", "animation", "placement", "click"], ["popover", "ngbPopover"], ["id", "theme-toggle", 1, "theme-toggle", 3, "ngClass"], ["aria-hidden", "true", "width", "24", "height", "24", "viewBox", "0 0 24 24", 1, "sun-and-moon"], ["cx", "12", "cy", "12", "r", "6", "mask", "url(#moon-mask)", "fill", "currentColor", 1, "sun"], ["stroke", "currentColor", 1, "sun-beams"], ["x1", "12", "y1", "1", "x2", "12", "y2", "3"], ["x1", "12", "y1", "21", "x2", "12", "y2", "23"], ["x1", "4.22", "y1", "4.22", "x2", "5.64", "y2", "5.64"], ["x1", "18.36", "y1", "18.36", "x2", "19.78", "y2", "19.78"], ["x1", "1", "y1", "12", "x2", "3", "y2", "12"], ["x1", "21", "y1", "12", "x2", "23", "y2", "12"], ["x1", "4.22", "y1", "19.78", "x2", "5.64", "y2", "18.36"], ["x1", "18.36", "y1", "5.64", "x2", "19.78", "y2", "4.22"], ["id", "moon-mask", 1, "moon"], ["x", "0", "y", "0", "width", "100%", "height", "100%", "fill", "white"], ["cx", "24", "cy", "10", "r", "6", "fill", "black"], ["id", "theme-switch-popover-content", 1, "popover-content", 3, "mouseenter"], [1, "head"], ["jhiTranslate", "artemisApp.theme.darkMode"], [1, "switch-box"], [3, "icon"], [1, "form-switch"], ["type", "checkbox", 1, "form-check-input", 3, "checked", "click"]], template: function ThemeSwitchComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275template(0, ThemeSwitchComponent_ng_template_0_Template, 23, 5, "ng-template", null, 0, i03.\u0275\u0275templateRefExtractor);
          i03.\u0275\u0275text(2, "\n");
          i03.\u0275\u0275elementStart(3, "div", 1);
          i03.\u0275\u0275listener("mouseenter", function ThemeSwitchComponent_Template_div_mouseenter_3_listener() {
            return ctx.openPopover();
          })("mouseleave", function ThemeSwitchComponent_Template_div_mouseleave_3_listener() {
            return ctx.mouseLeave();
          });
          i03.\u0275\u0275text(4, "\n    ");
          i03.\u0275\u0275elementStart(5, "div", 2, 3);
          i03.\u0275\u0275listener("click", function ThemeSwitchComponent_Template_div_click_5_listener() {
            return ctx.toggleTheme();
          });
          i03.\u0275\u0275text(7, "\n        ");
          i03.\u0275\u0275elementStart(8, "div", 4);
          i03.\u0275\u0275text(9, "\n            ");
          i03.\u0275\u0275namespaceSVG();
          i03.\u0275\u0275elementStart(10, "svg", 5);
          i03.\u0275\u0275text(11, "\n                ");
          i03.\u0275\u0275element(12, "circle", 6);
          i03.\u0275\u0275text(13, "\n                ");
          i03.\u0275\u0275elementStart(14, "g", 7);
          i03.\u0275\u0275text(15, "\n                    ");
          i03.\u0275\u0275element(16, "line", 8);
          i03.\u0275\u0275text(17, "\n                    ");
          i03.\u0275\u0275element(18, "line", 9);
          i03.\u0275\u0275text(19, "\n                    ");
          i03.\u0275\u0275element(20, "line", 10);
          i03.\u0275\u0275text(21, "\n                    ");
          i03.\u0275\u0275element(22, "line", 11);
          i03.\u0275\u0275text(23, "\n                    ");
          i03.\u0275\u0275element(24, "line", 12);
          i03.\u0275\u0275text(25, "\n                    ");
          i03.\u0275\u0275element(26, "line", 13);
          i03.\u0275\u0275text(27, "\n                    ");
          i03.\u0275\u0275element(28, "line", 14);
          i03.\u0275\u0275text(29, "\n                    ");
          i03.\u0275\u0275element(30, "line", 15);
          i03.\u0275\u0275text(31, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(32, "\n                ");
          i03.\u0275\u0275elementStart(33, "mask", 16);
          i03.\u0275\u0275text(34, "\n                    ");
          i03.\u0275\u0275element(35, "rect", 17);
          i03.\u0275\u0275text(36, "\n                    ");
          i03.\u0275\u0275element(37, "circle", 18);
          i03.\u0275\u0275text(38, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(39, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(40, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(41, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(42, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(43, "\n");
        }
        if (rf & 2) {
          const _r1 = i03.\u0275\u0275reference(1);
          i03.\u0275\u0275advance(5);
          i03.\u0275\u0275property("ngbPopover", _r1)("triggers", "")("autoClose", false)("animation", ctx.animate)("placement", ctx.popoverPlacement);
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275property("ngClass", i03.\u0275\u0275pureFunction1(6, _c12, ctx.isDark));
        }
      }, dependencies: [i2.NgClass, i32.NgbPopover, i42.FaIconComponent, TranslateDirective, ArtemisTranslatePipe], styles: ["\n\n.wrapper[_ngcontent-%COMP%], .toggle-popover-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: flex-start;\n  height: 100%;\n}\n.wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  padding: 0;\n  inline-size: 1.5rem;\n  block-size: 1.5rem;\n  aspect-ratio: 1;\n  border-radius: 50%;\n  cursor: pointer;\n  touch-action: manipulation;\n  -webkit-tap-highlight-color: transparent;\n  outline-offset: 5px;\n  transform: translateY(-0.5px);\n}\n.wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle[_ngcontent-%COMP%]    > svg[_ngcontent-%COMP%] {\n  inline-size: 100%;\n  block-size: 100%;\n  stroke-linecap: round;\n}\n.wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle[_ngcontent-%COMP%]   .sun-and-moon[_ngcontent-%COMP%]    > [_ngcontent-%COMP%]:is(.moon, .sun[_ngcontent-%COMP%], .sun-beams)[_ngcontent-%COMP%] {\n  transform-origin: center center;\n}\n.wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle[_ngcontent-%COMP%]   .sun-and-moon[_ngcontent-%COMP%]    > [_ngcontent-%COMP%]:is(.moon, .sun)[_ngcontent-%COMP%] {\n  fill: var(--navbar-dark-color);\n}\n.wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle[_ngcontent-%COMP%]   .sun-and-moon[_ngcontent-%COMP%]    > .sun-beams[_ngcontent-%COMP%] {\n  stroke: var(--navbar-dark-color);\n  stroke-width: 2px;\n  transition: transform 1s cubic-bezier(0.25, 0, 0.3, 1), opacity 0.5s cubic-bezier(0.25, 0, 0.3, 1);\n}\n.wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle[_ngcontent-%COMP%]   .sun-and-moon[_ngcontent-%COMP%]    > .sun[_ngcontent-%COMP%] {\n  transition: transform 0.5s cubic-bezier(0.25, 0, 0.3, 1);\n}\n.wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle[_ngcontent-%COMP%]   .sun-and-moon[_ngcontent-%COMP%]    > .moon[_ngcontent-%COMP%]    > circle[_ngcontent-%COMP%] {\n  transition: transform 0.25s cubic-bezier(0.9, 0, 0.1, 1);\n}\n@supports (cx: 1) {\n  .wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle[_ngcontent-%COMP%]   .sun-and-moon[_ngcontent-%COMP%]    > .moon[_ngcontent-%COMP%]    > circle[_ngcontent-%COMP%] {\n    transition: cx 0.25s cubic-bezier(0.9, 0, 0.1, 1);\n  }\n}\n.wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle.dark[_ngcontent-%COMP%]   .sun-and-moon[_ngcontent-%COMP%]    > .sun-beams[_ngcontent-%COMP%] {\n  opacity: 0;\n  transform: rotateZ(-90deg);\n  transition-duration: 0.15s;\n}\n.wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle.dark[_ngcontent-%COMP%]   .sun-and-moon[_ngcontent-%COMP%]    > .moon[_ngcontent-%COMP%]    > circle[_ngcontent-%COMP%] {\n  transform: translateX(-7px);\n  transition-duration: 0.8s;\n}\n@supports (cx: 1) {\n  .wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle.dark[_ngcontent-%COMP%]   .sun-and-moon[_ngcontent-%COMP%]    > .moon[_ngcontent-%COMP%]    > circle[_ngcontent-%COMP%] {\n    transform: translateX(0);\n    cx: 17;\n  }\n}\n.wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle.dark[_ngcontent-%COMP%]   .sun-and-moon[_ngcontent-%COMP%]    > .sun[_ngcontent-%COMP%] {\n  transform: scale(1.5);\n  transition-timing-function: cubic-bezier(0.25, 0, 0.3, 1);\n  transition-duration: 0.25s;\n}\n.wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle[_ngcontent-%COMP%]:hover   .sun-and-moon[_ngcontent-%COMP%]    > [_ngcontent-%COMP%]:is(.moon, .sun)[_ngcontent-%COMP%] {\n  fill: var(--link-color);\n}\n.wrapper[_ngcontent-%COMP%]   .toggle-popover-wrapper[_ngcontent-%COMP%]   .theme-toggle[_ngcontent-%COMP%]:hover   .sun-and-moon[_ngcontent-%COMP%]    > .sun-beams[_ngcontent-%COMP%] {\n  stroke: var(--link-color);\n}\n.popover-content[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  max-width: 300px;\n  min-width: fit-content;\n  text-align: center;\n}\n.popover-content[_ngcontent-%COMP%]   .head[_ngcontent-%COMP%] {\n  font-size: 20px;\n  font-weight: bold;\n  color: var(--warning);\n}\n.popover-content[_ngcontent-%COMP%]   .head[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  padding: 0 5px;\n  color: var(--bs-body-color);\n}\n.popover-content[_ngcontent-%COMP%]   .switch-box[_ngcontent-%COMP%] {\n  border: 1px solid var(--theme-switch-box-border-color);\n  margin: 1rem 0.5em 0.5em;\n  padding: 0.3em 0.5em;\n  width: 100%;\n  min-width: fit-content;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  white-space: nowrap;\n}\n.popover-content[_ngcontent-%COMP%]   .switch-box[_ngcontent-%COMP%]   .form-switch[_ngcontent-%COMP%] {\n  font-size: 16px;\n  margin: 0;\n}\n.popover-content[_ngcontent-%COMP%]   .switch-box[_ngcontent-%COMP%]   .form-switch[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb3JlL3RoZW1lL3RoZW1lLXN3aXRjaC5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiJHNpemU6IDEuNXJlbTtcbiRlYXNlLWRlZmF1bHQ6IGN1YmljLWJlemllcigwLjI1LCAwLCAwLjMsIDEpO1xuJGVhc2Utb3V0OiBjdWJpYy1iZXppZXIoMC45LCAwLCAwLjEsIDEpO1xuXG4ud3JhcHBlcixcbi50b2dnbGUtcG9wb3Zlci13cmFwcGVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICAgIGhlaWdodDogMTAwJTtcbn1cblxuLndyYXBwZXIge1xuICAgIC50b2dnbGUtcG9wb3Zlci13cmFwcGVyIHtcbiAgICAgICAgLnRoZW1lLXRvZ2dsZSB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBub25lO1xuICAgICAgICAgICAgYm9yZGVyOiBub25lO1xuICAgICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgICAgIGlubGluZS1zaXplOiAkc2l6ZTtcbiAgICAgICAgICAgIGJsb2NrLXNpemU6ICRzaXplO1xuICAgICAgICAgICAgYXNwZWN0LXJhdGlvOiAxO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICAgICAgdG91Y2gtYWN0aW9uOiBtYW5pcHVsYXRpb247XG4gICAgICAgICAgICAtd2Via2l0LXRhcC1oaWdobGlnaHQtY29sb3I6IHRyYW5zcGFyZW50O1xuICAgICAgICAgICAgb3V0bGluZS1vZmZzZXQ6IDVweDtcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtMC41cHgpO1xuXG4gICAgICAgICAgICAmID4gc3ZnIHtcbiAgICAgICAgICAgICAgICBpbmxpbmUtc2l6ZTogMTAwJTtcbiAgICAgICAgICAgICAgICBibG9jay1zaXplOiAxMDAlO1xuICAgICAgICAgICAgICAgIHN0cm9rZS1saW5lY2FwOiByb3VuZDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLnN1bi1hbmQtbW9vbiB7XG4gICAgICAgICAgICAgICAgJiA+IDppcygubW9vbiwgLnN1biwgLnN1bi1iZWFtcykge1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm0tb3JpZ2luOiBjZW50ZXIgY2VudGVyO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICYgPiA6aXMoLm1vb24sIC5zdW4pIHtcbiAgICAgICAgICAgICAgICAgICAgZmlsbDogdmFyKC0tbmF2YmFyLWRhcmstY29sb3IpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICYgPiAuc3VuLWJlYW1zIHtcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlOiB2YXIoLS1uYXZiYXItZGFyay1jb2xvcik7XG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZS13aWR0aDogMnB4O1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOlxuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtIDFzICRlYXNlLWRlZmF1bHQsXG4gICAgICAgICAgICAgICAgICAgICAgICBvcGFjaXR5IDAuNXMgJGVhc2UtZGVmYXVsdDtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAmID4gLnN1biB7XG4gICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjVzICRlYXNlLWRlZmF1bHQ7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgJiA+IC5tb29uID4gY2lyY2xlIHtcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuMjVzICRlYXNlLW91dDtcblxuICAgICAgICAgICAgICAgICAgICBAc3VwcG9ydHMgKGN4OiAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBjeCAwLjI1cyAkZWFzZS1vdXQ7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICYuZGFyayB7XG4gICAgICAgICAgICAgICAgLnN1bi1hbmQtbW9vbiB7XG4gICAgICAgICAgICAgICAgICAgICYgPiAuc3VuLWJlYW1zIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZVooLTkwZGVnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb24tZHVyYXRpb246IDAuMTVzO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgJiA+IC5tb29uID4gY2lyY2xlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtN3B4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb24tZHVyYXRpb246IDAuOHM7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBzdXBwb3J0cyAoY3g6IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3g6IDE3O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgJiA+IC5zdW4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbi10aW1pbmctZnVuY3Rpb246ICRlYXNlLWRlZmF1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uLWR1cmF0aW9uOiAwLjI1cztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgJjpob3ZlciAuc3VuLWFuZC1tb29uIHtcbiAgICAgICAgICAgICAgICA+IDppcygubW9vbiwgLnN1bikge1xuICAgICAgICAgICAgICAgICAgICBmaWxsOiB2YXIoLS1saW5rLWNvbG9yKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAmID4gLnN1bi1iZWFtcyB7XG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZTogdmFyKC0tbGluay1jb2xvcik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG4ucG9wb3Zlci1jb250ZW50IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBtYXgtd2lkdGg6IDMwMHB4O1xuICAgIG1pbi13aWR0aDogZml0LWNvbnRlbnQ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuXG4gICAgLmhlYWQge1xuICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICBjb2xvcjogdmFyKC0td2FybmluZyk7XG5cbiAgICAgICAgc3BhbiB7XG4gICAgICAgICAgICBwYWRkaW5nOiAwIDVweDtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1icy1ib2R5LWNvbG9yKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5zd2l0Y2gtYm94IHtcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tdGhlbWUtc3dpdGNoLWJveC1ib3JkZXItY29sb3IpO1xuICAgICAgICBtYXJnaW46IDFyZW0gMC41ZW0gMC41ZW07XG4gICAgICAgIHBhZGRpbmc6IDAuM2VtIDAuNWVtO1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgbWluLXdpZHRoOiBmaXQtY29udGVudDtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuXG4gICAgICAgIC5mb3JtLXN3aXRjaCB7XG4gICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgICAgICBtYXJnaW46IDA7XG5cbiAgICAgICAgICAgID4gKiB7XG4gICAgICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUlBLENBQUE7QUFBQSxDQUFBO0FBRUksV0FBQTtBQUNBLGVBQUE7QUFDQSxtQkFBQTtBQUNBLFVBQUE7O0FBS0ksQ0FWUixRQVVRLENBVlIsdUJBVVEsQ0FBQTtBQUNJLGNBQUE7QUFDQSxVQUFBO0FBQ0EsV0FBQTtBQUNBLGVBbEJMO0FBbUJLLGNBbkJMO0FBb0JLLGdCQUFBO0FBQ0EsaUJBQUE7QUFDQSxVQUFBO0FBQ0EsZ0JBQUE7QUFDQSwrQkFBQTtBQUNBLGtCQUFBO0FBQ0EsYUFBQSxXQUFBOztBQUVBLENBeEJaLFFBd0JZLENBeEJaLHVCQXdCWSxDQWRKLGFBY0ksRUFBQTtBQUNJLGVBQUE7QUFDQSxjQUFBO0FBQ0Esa0JBQUE7O0FBSUEsQ0EvQmhCLFFBK0JnQixDQS9CaEIsdUJBK0JnQixDQXJCUixhQXFCUSxDQUFBLGFBQUEsRUFBQSxJQUFBLENBQUEsTUFBQSxDQUFBLEtBQUEsQ0FBQTtBQUNJLG9CQUFBLE9BQUE7O0FBR0osQ0FuQ2hCLFFBbUNnQixDQW5DaEIsdUJBbUNnQixDQXpCUixhQXlCUSxDQUpBLGFBSUEsRUFBQSxJQUFBLENBSkEsTUFJQSxDQUpBO0FBS0ksUUFBQSxJQUFBOztBQUdKLENBdkNoQixRQXVDZ0IsQ0F2Q2hCLHVCQXVDZ0IsQ0E3QlIsYUE2QlEsQ0FSQSxhQVFBLEVBQUEsQ0FSQTtBQVNJLFVBQUEsSUFBQTtBQUNBLGdCQUFBO0FBQ0EsY0FDSSxVQUFBLEdBQUEsYUFBQSxJQUFBLEVBQUEsQ0FBQSxFQUFBLEdBQUEsRUFBQSxFQUFBLEVBQUEsUUFBQSxLQUFBLGFBQUEsSUFBQSxFQUFBLENBQUEsRUFBQSxHQUFBLEVBQUE7O0FBSVIsQ0EvQ2hCLFFBK0NnQixDQS9DaEIsdUJBK0NnQixDQXJDUixhQXFDUSxDQWhCQSxhQWdCQSxFQUFBLENBaEJBO0FBaUJJLGNBQUEsVUFBQSxLQUFBLGFBQUEsSUFBQSxFQUFBLENBQUEsRUFBQSxHQUFBLEVBQUE7O0FBR0osQ0FuRGhCLFFBbURnQixDQW5EaEIsdUJBbURnQixDQXpDUixhQXlDUSxDQXBCQSxhQW9CQSxFQUFBLENBcEJBLEtBb0JBLEVBQUE7QUFDSSxjQUFBLFVBQUEsTUFBQSxhQUFBLEdBQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBOztBQUVBLFVBQUEsQ0FBQSxFQUFBLEVBQUE7QUFISixHQW5EaEIsUUFtRGdCLENBbkRoQix1QkFtRGdCLENBekNSLGFBeUNRLENBcEJBLGFBb0JBLEVBQUEsQ0FwQkEsS0FvQkEsRUFBQTtBQUlRLGdCQUFBLEdBQUEsTUFBQSxhQUFBLEdBQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBOzs7QUFPSixDQTlEcEIsUUE4RG9CLENBOURwQix1QkE4RG9CLENBcERaLFlBb0RZLENBQUEsS0FBQSxDQS9CSixhQStCSSxFQUFBLENBL0JKO0FBZ0NRLFdBQUE7QUFDQSxhQUFBLFFBQUE7QUFDQSx1QkFBQTs7QUFHSixDQXBFcEIsUUFvRW9CLENBcEVwQix1QkFvRW9CLENBMURaLFlBMERZLENBTkEsS0FNQSxDQXJDSixhQXFDSSxFQUFBLENBckNKLEtBcUNJLEVBQUE7QUFDSSxhQUFBLFdBQUE7QUFDQSx1QkFBQTs7QUFFQSxVQUFBLENBQUEsRUFBQSxFQUFBO0FBSkosR0FwRXBCLFFBb0VvQixDQXBFcEIsdUJBb0VvQixDQTFEWixZQTBEWSxDQU5BLEtBTUEsQ0FyQ0osYUFxQ0ksRUFBQSxDQXJDSixLQXFDSSxFQUFBO0FBS1EsZUFBQSxXQUFBO0FBQ0EsUUFBQTs7O0FBSVIsQ0E5RXBCLFFBOEVvQixDQTlFcEIsdUJBOEVvQixDQXBFWixZQW9FWSxDQWhCQSxLQWdCQSxDQS9DSixhQStDSSxFQUFBLENBL0NKO0FBZ0RRLGFBQUEsTUFBQTtBQUNBLDhCQW5GVCxhQUFBLElBQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBO0FBb0ZTLHVCQUFBOztBQU1SLENBdkZoQixRQXVGZ0IsQ0F2RmhCLHVCQXVGZ0IsQ0E3RVIsWUE2RVEsT0FBQSxDQXhEQSxhQXdEQSxFQUFBLElBQUEsQ0F4REEsTUF3REEsQ0F4REE7QUF5REksUUFBQSxJQUFBOztBQUdKLENBM0ZoQixRQTJGZ0IsQ0EzRmhCLHVCQTJGZ0IsQ0FqRlIsWUFpRlEsT0FBQSxDQTVEQSxhQTREQSxFQUFBLENBNURBO0FBNkRJLFVBQUEsSUFBQTs7QUFPcEIsQ0FBQTtBQUNJLFdBQUE7QUFDQSxrQkFBQTtBQUNBLG1CQUFBO0FBQ0EsZUFBQTtBQUNBLGFBQUE7QUFDQSxhQUFBO0FBQ0EsY0FBQTs7QUFFQSxDQVRKLGdCQVNJLENBQUE7QUFDSSxhQUFBO0FBQ0EsZUFBQTtBQUNBLFNBQUEsSUFBQTs7QUFFQSxDQWRSLGdCQWNRLENBTEosS0FLSTtBQUNJLFdBQUEsRUFBQTtBQUNBLFNBQUEsSUFBQTs7QUFJUixDQXBCSixnQkFvQkksQ0FBQTtBQUNJLFVBQUEsSUFBQSxNQUFBLElBQUE7QUFDQSxVQUFBLEtBQUEsTUFBQTtBQUNBLFdBQUEsTUFBQTtBQUNBLFNBQUE7QUFDQSxhQUFBO0FBQ0EsV0FBQTtBQUNBLG1CQUFBO0FBQ0EsZUFBQTtBQUNBLGVBQUE7O0FBRUEsQ0EvQlIsZ0JBK0JRLENBWEosV0FXSSxDQUFBO0FBQ0ksYUFBQTtBQUNBLFVBQUE7O0FBRUEsQ0FuQ1osZ0JBbUNZLENBZlIsV0FlUSxDQUpKLFlBSUksRUFBQTtBQUNJLFVBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(ThemeSwitchComponent, { className: "ThemeSwitchComponent" });
    })();
  }
});

// src/main/webapp/app/shared/layouts/navbar/active-menu.directive.ts
import { Directive, ElementRef as ElementRef2, Input as Input2, Renderer2 as Renderer23 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
var ActiveMenuDirective;
var init_active_menu_directive = __esm({
  "src/main/webapp/app/shared/layouts/navbar/active-menu.directive.ts"() {
    ActiveMenuDirective = class _ActiveMenuDirective {
      element;
      renderer;
      translateService;
      jhiActiveMenu;
      constructor(element, renderer, translateService) {
        this.element = element;
        this.renderer = renderer;
        this.translateService = translateService;
      }
      ngOnInit() {
        this.translateService.onLangChange.subscribe((event) => {
          this.updateActiveFlag(event.lang);
        });
        this.updateActiveFlag(this.translateService.currentLang);
      }
      updateActiveFlag(selectedLanguage) {
        if (this.jhiActiveMenu === selectedLanguage) {
          this.renderer.addClass(this.element.nativeElement, "active");
        } else {
          this.renderer.removeClass(this.element.nativeElement, "active");
        }
      }
      static \u0275fac = function ActiveMenuDirective_Factory(t) {
        return new (t || _ActiveMenuDirective)(i04.\u0275\u0275directiveInject(i04.ElementRef), i04.\u0275\u0275directiveInject(i04.Renderer2), i04.\u0275\u0275directiveInject(i1.TranslateService));
      };
      static \u0275dir = i04.\u0275\u0275defineDirective({ type: _ActiveMenuDirective, selectors: [["", "jhiActiveMenu", ""]], inputs: { jhiActiveMenu: "jhiActiveMenu" } });
    };
  }
});

// src/main/webapp/app/shared/notification/notification-sidebar/notification-sidebar.component.ts
import { ChangeDetectorRef, Component as Component3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import { faArchive, faBell, faCircleNotch as faCircleNotch2, faCog, faEye, faTimes } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { SessionStorageService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i43 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import * as i6 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i7 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i8 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i10 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function NotificationSidebarComponent_Conditional_6_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275elementStart(1, "span");
    i05.\u0275\u0275text(2, "+");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(3, "\n                ");
  }
}
function NotificationSidebarComponent_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n            ");
    i05.\u0275\u0275elementStart(1, "span", 18);
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275template(3, NotificationSidebarComponent_Conditional_6_Conditional_3_Template, 4, 0);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate1("\n                ", ctx_r0.recentNotificationCount, "\n                ");
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275conditional(3, ctx_r0.recentNotificationCount >= ctx_r0.sortedNotifications.length ? 3 : -1);
  }
}
function NotificationSidebarComponent_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                        ");
    i05.\u0275\u0275elementStart(1, "fa-icon", 19);
    i05.\u0275\u0275pipe(2, "artemisTranslate");
    i05.\u0275\u0275text(3, "\n                        ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r1 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("icon", ctx_r1.faArchive)("ngbTooltip", i05.\u0275\u0275pipeBind1(2, 2, "artemisApp.notification.hideAllCurrentlyDisplayedNotifications"));
  }
}
function NotificationSidebarComponent_Conditional_44_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                        ");
    i05.\u0275\u0275elementStart(1, "fa-icon", 19);
    i05.\u0275\u0275pipe(2, "artemisTranslate");
    i05.\u0275\u0275text(3, " ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r2 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("icon", ctx_r2.faEye)("ngbTooltip", i05.\u0275\u0275pipeBind1(2, 2, "artemisApp.notification.showAllSavedNotifications"));
  }
}
function NotificationSidebarComponent_Conditional_54_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                ");
    i05.\u0275\u0275elementStart(1, "div", 20);
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275pipe(3, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate1("\n                    ", i05.\u0275\u0275pipeBind1(3, 1, "artemisApp.notification.unexpectedError"), "\n                ");
  }
}
function NotificationSidebarComponent_For_56_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                ");
    i05.\u0275\u0275elementStart(1, "span", 25);
    i05.\u0275\u0275text(2, " new ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(3, "\n                            ");
  }
}
function NotificationSidebarComponent_For_56_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                ");
    i05.\u0275\u0275elementStart(1, "span");
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(3, "\n                            ");
  }
  if (rf & 2) {
    const notification_r9 = i05.\u0275\u0275nextContext().$implicit;
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate(notification_r9.author.name);
  }
}
function NotificationSidebarComponent_For_56_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                ");
    i05.\u0275\u0275element(1, "span", 26);
    i05.\u0275\u0275text(2, "\n                            ");
  }
}
function NotificationSidebarComponent_For_56_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n                ");
    i05.\u0275\u0275elementStart(1, "div", 21);
    i05.\u0275\u0275listener("click", function NotificationSidebarComponent_For_56_Template_div_click_1_listener() {
      const restoredCtx = i05.\u0275\u0275restoreView(_r19);
      const notification_r9 = restoredCtx.$implicit;
      const ctx_r18 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r18.startNotification(notification_r9));
    });
    i05.\u0275\u0275text(2, "\n                    ");
    i05.\u0275\u0275elementStart(3, "div");
    i05.\u0275\u0275text(4, "\n                        ");
    i05.\u0275\u0275elementStart(5, "h5", 22);
    i05.\u0275\u0275text(6);
    i05.\u0275\u0275template(7, NotificationSidebarComponent_For_56_Conditional_7_Template, 4, 0);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(8, "\n                        ");
    i05.\u0275\u0275element(9, "div", 23);
    i05.\u0275\u0275text(10, "\n                        ");
    i05.\u0275\u0275elementStart(11, "div", 24);
    i05.\u0275\u0275text(12);
    i05.\u0275\u0275pipe(13, "date");
    i05.\u0275\u0275pipe(14, "artemisTranslate");
    i05.\u0275\u0275template(15, NotificationSidebarComponent_For_56_Conditional_15_Template, 4, 1)(16, NotificationSidebarComponent_For_56_Conditional_16_Template, 3, 0);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(17, "\n                    ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(18, "\n                ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(19, "\n            ");
  }
  if (rf & 2) {
    const notification_r9 = ctx.$implicit;
    const ctx_r4 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(6);
    i05.\u0275\u0275textInterpolate1("\n                            ", ctx_r4.getNotificationTitleTranslation(notification_r9), "\n                            ");
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275conditional(7, ctx_r4.lastNotificationRead && (notification_r9.notificationDate == null ? null : notification_r9.notificationDate.isAfter(ctx_r4.lastNotificationRead)) ? 7 : -1);
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275property("innerHTML", ctx_r4.getNotificationTextTranslation(notification_r9), i05.\u0275\u0275sanitizeHtml);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275textInterpolate2("\n                            ", i05.\u0275\u0275pipeBind2(13, 6, notification_r9.notificationDate == null ? null : notification_r9.notificationDate.toDate(), "dd.MM.yy HH:mm"), "\n                            ", i05.\u0275\u0275pipeBind1(14, 9, "artemisApp.notification.by"), "\n                            ");
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275conditional(15, notification_r9.author ? 15 : 16);
  }
}
function NotificationSidebarComponent_Conditional_57_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                ");
    i05.\u0275\u0275elementStart(1, "div", 27);
    i05.\u0275\u0275text(2, "\n                    ");
    i05.\u0275\u0275element(3, "fa-icon", 28);
    i05.\u0275\u0275text(4, "\n                ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r5 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275property("icon", ctx_r5.faCircleNotch)("spin", true);
  }
}
function NotificationSidebarComponent_Conditional_58_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                ");
    i05.\u0275\u0275elementStart(1, "small", 29);
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275pipe(3, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate1("\n                    ", i05.\u0275\u0275pipeBind1(3, 1, "artemisApp.notification.allLoaded"), "\n                ");
  }
}
function NotificationSidebarComponent_Conditional_59_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                ");
    i05.\u0275\u0275elementStart(1, "span", 30);
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275pipe(3, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate1("\n                    ", i05.\u0275\u0275pipeBind1(3, 1, "artemisApp.notification.noNotifications"), "\n                ");
  }
}
var _c03, _c13, LAST_READ_STORAGE_KEY, IRRELEVANT_NOTIFICATION_TITLES, NotificationSidebarComponent;
var init_notification_sidebar_component = __esm({
  "src/main/webapp/app/shared/notification/notification-sidebar/notification-sidebar.component.ts"() {
    init_user_service();
    init_notification_model();
    init_account_service();
    init_notification_service();
    init_translation_config();
    init_artemis_translate_pipe();
    init_notification_service();
    init_user_service();
    init_account_service();
    init_artemis_translate_pipe();
    init_translate_directive();
    init_documentation_button_component();
    _c03 = () => ["/user-settings/notifications"];
    _c13 = (a0, a1) => ({ loaded: a0, total: a1 });
    LAST_READ_STORAGE_KEY = "lastNotificationRead";
    IRRELEVANT_NOTIFICATION_TITLES = [NEW_MESSAGE_TITLE, LIVE_EXAM_EXERCISE_UPDATE_NOTIFICATION_TITLE];
    NotificationSidebarComponent = class _NotificationSidebarComponent {
      notificationService;
      userService;
      accountService;
      sessionStorageService;
      changeDetector;
      artemisTranslatePipe;
      showSidebar = false;
      showButtonToHideCurrentlyDisplayedNotifications = true;
      sortedNotifications = [];
      recentNotificationCount = 0;
      lastNotificationRead;
      maxNotificationLength = 300;
      error;
      loading = false;
      totalNotifications = 0;
      documentationType = "Notifications";
      subscriptions = [];
      faTimes = faTimes;
      faCircleNotch = faCircleNotch2;
      faBell = faBell;
      faCog = faCog;
      faArchive = faArchive;
      faEye = faEye;
      constructor(notificationService, userService, accountService, sessionStorageService, changeDetector, artemisTranslatePipe) {
        this.notificationService = notificationService;
        this.userService = userService;
        this.accountService = accountService;
        this.sessionStorageService = sessionStorageService;
        this.changeDetector = changeDetector;
        this.artemisTranslatePipe = artemisTranslatePipe;
      }
      ngOnDestroy() {
        this.subscriptions.forEach((subscription) => subscription.unsubscribe());
      }
      ngOnInit() {
        this.accountService.getAuthenticationState().subscribe((user) => {
          if (user) {
            const sessionLastNotificationReadRaw = this.sessionStorageService.retrieve(LAST_READ_STORAGE_KEY);
            const sessionLastNotificationReadDayJs = sessionLastNotificationReadRaw ? dayjs(sessionLastNotificationReadRaw) : void 0;
            if (user.lastNotificationRead && !sessionLastNotificationReadDayJs) {
              this.lastNotificationRead = user.lastNotificationRead;
            } else if (!user.lastNotificationRead && sessionLastNotificationReadDayJs) {
              this.lastNotificationRead = sessionLastNotificationReadDayJs;
            } else if (user.lastNotificationRead && sessionLastNotificationReadDayJs) {
              if (sessionLastNotificationReadDayJs.isBefore(user.lastNotificationRead)) {
                this.lastNotificationRead = user.lastNotificationRead;
              } else {
                this.lastNotificationRead = sessionLastNotificationReadDayJs;
              }
            }
            this.subscribeToNotificationUpdates();
          } else {
            this.sessionStorageService.clear(LAST_READ_STORAGE_KEY);
          }
        });
      }
      startNotification(notification) {
        this.showSidebar = false;
        this.notificationService.interpretNotification(notification);
      }
      onScroll() {
        const container = document.getElementById("notification-sidebar-container");
        const threshold = 350;
        if (container) {
          const height = container.scrollHeight - container.offsetHeight;
          if (height > threshold && container.scrollTop > height - threshold) {
            this.notificationService.incrementPageAndLoad();
          }
        }
      }
      toggleSidebar() {
        this.showSidebar = !this.showSidebar;
      }
      toggleNotificationDisplay() {
        this.showButtonToHideCurrentlyDisplayedNotifications = !this.showButtonToHideCurrentlyDisplayedNotifications;
        this.userService.updateNotificationVisibility(this.showButtonToHideCurrentlyDisplayedNotifications).subscribe(() => {
          this.notificationService.resetAndLoad();
        });
      }
      updateLastNotificationRead() {
        this.userService.updateLastNotificationRead().subscribe(() => {
          const lastNotificationReadNow = dayjs();
          setTimeout(() => {
            this.lastNotificationRead = lastNotificationReadNow;
            this.sessionStorageService.store(LAST_READ_STORAGE_KEY, lastNotificationReadNow);
            this.updateRecentNotificationCount();
          }, 2e3);
        });
      }
      getNotificationTitleTranslation(notification) {
        const translation = this.artemisTranslatePipe.transform(notification.title);
        if (translation?.includes(translationNotFoundMessage)) {
          return notification.title ?? "No title found";
        }
        return translation;
      }
      getNotificationTextTranslation(notification) {
        return this.notificationService.getNotificationTextTranslation(notification, this.maxNotificationLength);
      }
      getParsedPlaceholderValues(notification) {
        if (notification.placeholderValues) {
          return JSON.parse(notification.placeholderValues);
        }
        return [];
      }
      subscribeToNotificationUpdates() {
        this.subscriptions.push(this.notificationService.subscribeToNotificationUpdates().subscribe((notifications) => {
          const filteredNotifications = this.filterLoadedNotifications(notifications);
          this.updateSortedNotifications(filteredNotifications);
        }));
        this.subscriptions.push(this.notificationService.subscribeToTotalNotificationCountUpdates().subscribe((count) => this.totalNotifications = count));
        this.subscriptions.push(this.notificationService.subscribeToLoadingStateUpdates().subscribe((loading) => this.loading = loading));
      }
      filterLoadedNotifications(notifications) {
        return notifications.filter((notification) => notification.title && !IRRELEVANT_NOTIFICATION_TITLES.includes(notification.title));
      }
      updateSortedNotifications(notifications) {
        this.sortedNotifications = notifications.sort((a, b) => {
          return dayjs(b.notificationDate).valueOf() - dayjs(a.notificationDate).valueOf();
        });
        this.updateRecentNotificationCount();
      }
      updateRecentNotificationCount() {
        if (!this.sortedNotifications) {
          this.recentNotificationCount = 0;
        } else if (this.lastNotificationRead) {
          this.recentNotificationCount = this.sortedNotifications.filter((notification) => {
            return notification.notificationDate && notification.notificationDate.isAfter(this.lastNotificationRead);
          }).length;
        } else {
          this.recentNotificationCount = this.sortedNotifications.length;
        }
        if (!this.sortedNotifications || this.sortedNotifications.length === 0) {
          this.showButtonToHideCurrentlyDisplayedNotifications = false;
        } else {
          this.showButtonToHideCurrentlyDisplayedNotifications = true;
        }
        this.changeDetector.detectChanges();
      }
      static \u0275fac = function NotificationSidebarComponent_Factory(t) {
        return new (t || _NotificationSidebarComponent)(i05.\u0275\u0275directiveInject(NotificationService), i05.\u0275\u0275directiveInject(UserService), i05.\u0275\u0275directiveInject(AccountService), i05.\u0275\u0275directiveInject(i43.SessionStorageService), i05.\u0275\u0275directiveInject(i05.ChangeDetectorRef), i05.\u0275\u0275directiveInject(ArtemisTranslatePipe));
      };
      static \u0275cmp = i05.\u0275\u0275defineComponent({ type: _NotificationSidebarComponent, selectors: [["jhi-notification-sidebar"]], decls: 63, vars: 24, consts: [[1, "pointer"], [1, "guided-tour-notification", "notification-button", "light-button", 3, "click"], [3, "icon"], [1, "notification-overlay", 3, "ngClass", "click"], ["id", "notification-sidebar", 1, "notification-sidebar", 3, "ngClass"], [1, "d-flex", "flex-column"], [1, "header", "pt-4", "px-3"], [1, "d-flex", "header-icon", "justify-content-between", "align-items-baseline"], [1, "d-flex"], [3, "type"], [1, "ps-2", 3, "routerLink", "click"], [1, "ng-fa-icon", 3, "icon"], [1, "mb-3", "text-center", "fw-medium"], [1, "close", "header-icon", "border-0", "bg-transparent", "pe-2", 3, "click"], [1, "text-end"], ["id", "hide-until-toggle", 1, "border-0", "bg-transparent", "pe-2", 3, "click"], [1, "text-body-secondary"], ["id", "notification-sidebar-container", 3, "scroll"], [1, "badge", "bg-danger", "rounded-pill"], [1, "ng-fa-icon", 3, "icon", "ngbTooltip"], ["role", "alert", 1, "alert", "alert-danger", "mx-3"], [1, "notification-item", "p-3", 3, "click"], [1, "notification-title", "fw-medium"], [1, "notification-text", "mb-1", "text-break", 3, "innerHTML"], [1, "info", "text-body-secondary", "text-end"], [1, "badge", "ms-1", "bg-primary"], ["jhiTranslate", "global.title"], [1, "loading-spinner", "text-center", "mx-3", "my-2", 2, "font-size", "large"], [3, "icon", "spin"], [1, "all-loaded", "text-center", "d-block", "mx-3", "my-2"], [1, "no-notifications"]], template: function NotificationSidebarComponent_Template(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275elementStart(0, "div", 0);
          i05.\u0275\u0275text(1, "\n    ");
          i05.\u0275\u0275elementStart(2, "button", 1);
          i05.\u0275\u0275listener("click", function NotificationSidebarComponent_Template_button_click_2_listener() {
            ctx.toggleSidebar();
            return ctx.updateLastNotificationRead();
          });
          i05.\u0275\u0275text(3, "\n        ");
          i05.\u0275\u0275element(4, "fa-icon", 2);
          i05.\u0275\u0275text(5, "\n        ");
          i05.\u0275\u0275template(6, NotificationSidebarComponent_Conditional_6_Template, 5, 2);
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(7, "\n");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(8, "\n");
          i05.\u0275\u0275elementStart(9, "div", 3);
          i05.\u0275\u0275listener("click", function NotificationSidebarComponent_Template_div_click_9_listener() {
            return ctx.toggleSidebar();
          });
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(10, "\n");
          i05.\u0275\u0275elementStart(11, "div", 4);
          i05.\u0275\u0275text(12, "\n    ");
          i05.\u0275\u0275elementStart(13, "div", 5);
          i05.\u0275\u0275text(14, "\n        ");
          i05.\u0275\u0275elementStart(15, "div", 6);
          i05.\u0275\u0275text(16, "\n            ");
          i05.\u0275\u0275elementStart(17, "div", 7);
          i05.\u0275\u0275text(18, "\n                ");
          i05.\u0275\u0275elementStart(19, "div", 8);
          i05.\u0275\u0275text(20, "\n                    ");
          i05.\u0275\u0275element(21, "jhi-documentation-button", 9);
          i05.\u0275\u0275text(22, "\n                    ");
          i05.\u0275\u0275elementStart(23, "a", 10);
          i05.\u0275\u0275listener("click", function NotificationSidebarComponent_Template_a_click_23_listener() {
            return ctx.toggleSidebar();
          });
          i05.\u0275\u0275text(24, "\n                        ");
          i05.\u0275\u0275element(25, "fa-icon", 11);
          i05.\u0275\u0275text(26, "\n                    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(27, "\n                ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(28, "\n                ");
          i05.\u0275\u0275elementStart(29, "h5", 12);
          i05.\u0275\u0275text(30);
          i05.\u0275\u0275pipe(31, "artemisTranslate");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(32, "\n                ");
          i05.\u0275\u0275elementStart(33, "button", 13);
          i05.\u0275\u0275listener("click", function NotificationSidebarComponent_Template_button_click_33_listener() {
            return ctx.toggleSidebar();
          });
          i05.\u0275\u0275text(34, "\n                    ");
          i05.\u0275\u0275element(35, "fa-icon", 11);
          i05.\u0275\u0275text(36, "\n                ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(37, "\n            ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(38, "\n            ");
          i05.\u0275\u0275elementStart(39, "div", 14);
          i05.\u0275\u0275text(40, "\n                ");
          i05.\u0275\u0275elementStart(41, "button", 15);
          i05.\u0275\u0275listener("click", function NotificationSidebarComponent_Template_button_click_41_listener() {
            return ctx.toggleNotificationDisplay();
          });
          i05.\u0275\u0275text(42, "\n                    ");
          i05.\u0275\u0275template(43, NotificationSidebarComponent_Conditional_43_Template, 5, 4)(44, NotificationSidebarComponent_Conditional_44_Template, 5, 4);
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(45, "\n                ");
          i05.\u0275\u0275elementStart(46, "small", 16);
          i05.\u0275\u0275text(47);
          i05.\u0275\u0275pipe(48, "artemisTranslate");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(49, "\n            ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(50, "\n        ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(51, "\n        ");
          i05.\u0275\u0275elementStart(52, "div", 17);
          i05.\u0275\u0275listener("scroll", function NotificationSidebarComponent_Template_div_scroll_52_listener() {
            return ctx.onScroll();
          });
          i05.\u0275\u0275text(53, "\n            ");
          i05.\u0275\u0275template(54, NotificationSidebarComponent_Conditional_54_Template, 5, 3);
          i05.\u0275\u0275repeaterCreate(55, NotificationSidebarComponent_For_56_Template, 20, 11, null, null, i05.\u0275\u0275repeaterTrackByIdentity);
          i05.\u0275\u0275template(57, NotificationSidebarComponent_Conditional_57_Template, 6, 2)(58, NotificationSidebarComponent_Conditional_58_Template, 5, 3)(59, NotificationSidebarComponent_Conditional_59_Template, 5, 3);
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(60, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(61, "\n");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(62, "\n");
        }
        if (rf & 2) {
          i05.\u0275\u0275advance(4);
          i05.\u0275\u0275property("icon", ctx.faBell);
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275conditional(6, ctx.recentNotificationCount > 0 ? 6 : -1);
          i05.\u0275\u0275advance(3);
          i05.\u0275\u0275property("ngClass", ctx.showSidebar ? "show" : "hide");
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275property("ngClass", ctx.showSidebar ? "show" : "hide");
          i05.\u0275\u0275advance(10);
          i05.\u0275\u0275property("type", ctx.documentationType);
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275property("routerLink", i05.\u0275\u0275pureFunction0(20, _c03));
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275property("icon", ctx.faCog);
          i05.\u0275\u0275advance(5);
          i05.\u0275\u0275textInterpolate1("\n                    ", i05.\u0275\u0275pipeBind1(31, 15, "artemisApp.notification.notifications"), "\n                ");
          i05.\u0275\u0275advance(5);
          i05.\u0275\u0275property("icon", ctx.faTimes);
          i05.\u0275\u0275advance(8);
          i05.\u0275\u0275conditional(43, ctx.showButtonToHideCurrentlyDisplayedNotifications ? 43 : 44);
          i05.\u0275\u0275advance(4);
          i05.\u0275\u0275textInterpolate1("\n                    ", i05.\u0275\u0275pipeBind2(48, 17, "artemisApp.notification.loadedNotificationCount", i05.\u0275\u0275pureFunction2(21, _c13, (ctx.sortedNotifications == null ? null : ctx.sortedNotifications.length) || "0", ctx.totalNotifications)), "\n                ");
          i05.\u0275\u0275advance(7);
          i05.\u0275\u0275conditional(54, ctx.error ? 54 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275repeater(ctx.sortedNotifications);
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275conditional(57, ctx.loading ? 57 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(58, ctx.sortedNotifications.length > 0 && ctx.sortedNotifications.length >= ctx.totalNotifications ? 58 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(59, ctx.sortedNotifications && ctx.sortedNotifications.length === 0 ? 59 : -1);
        }
      }, dependencies: [i6.NgClass, i7.NgbTooltip, i8.FaIconComponent, TranslateDirective, i10.RouterLink, DocumentationButtonComponent, i6.DatePipe, ArtemisTranslatePipe], styles: ["\n\n.light-button[_ngcontent-%COMP%] {\n  border: 0;\n  background-color: transparent;\n  color: var(--navbar-dark-color);\n  transition: color 0.2s;\n}\n.light-button[_ngcontent-%COMP%]:hover {\n  color: var(--link-color);\n}\n.notification-overlay[_ngcontent-%COMP%] {\n  display: none;\n  z-index: 998;\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background-color: var(--notification-sb-overlay-bg);\n}\n.notification-overlay.show[_ngcontent-%COMP%] {\n  display: block;\n}\n.notification-sidebar[_ngcontent-%COMP%] {\n  width: 300px;\n  position: fixed;\n  top: 0;\n  right: -305px;\n  bottom: 0;\n  z-index: 999;\n  transition: 0.3s;\n  overflow-y: hidden;\n  color: var(--bs-body-color);\n  background-color: var(--notification-sb-background);\n  box-shadow: 0 0 20px 0 var(--notification-sb-box-shadow);\n}\n.notification-sidebar[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%]:hover {\n  color: var(--bs-body-color);\n}\n.notification-sidebar.show[_ngcontent-%COMP%] {\n  right: 0;\n  transition: 0.3s;\n}\n.notification-sidebar[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%] {\n  height: 85px;\n}\n.notification-sidebar[_ngcontent-%COMP%]   #notification-sidebar-container[_ngcontent-%COMP%] {\n  height: calc(100vh - 85px);\n  overflow-y: auto;\n  overflow-x: hidden;\n}\n.notification-sidebar[_ngcontent-%COMP%]   #notification-sidebar-container[_ngcontent-%COMP%]   .notification-item[_ngcontent-%COMP%] {\n  cursor: pointer;\n  white-space: normal;\n}\n.notification-sidebar[_ngcontent-%COMP%]   #notification-sidebar-container[_ngcontent-%COMP%]   .notification-item[_ngcontent-%COMP%]:nth-child(even) {\n  background-color: var(--notification-sb-even-child-bg);\n}\n.notification-sidebar[_ngcontent-%COMP%]   #notification-sidebar-container[_ngcontent-%COMP%]   .notification-item[_ngcontent-%COMP%]:hover {\n  background-color: var(--notification-sb-hover-child-bg);\n}\n.notification-sidebar[_ngcontent-%COMP%]   #notification-sidebar-container[_ngcontent-%COMP%]   .notification-item[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  font-size: 1rem;\n}\n.notification-sidebar[_ngcontent-%COMP%]   #notification-sidebar-container[_ngcontent-%COMP%]   .notification-item[_ngcontent-%COMP%]   .info[_ngcontent-%COMP%] {\n  font-size: 0.8rem;\n}\n.notification-sidebar[_ngcontent-%COMP%]   .no-notifications[_ngcontent-%COMP%] {\n  display: block;\n  padding: 20px 16px;\n}\n.notification-sidebar[_ngcontent-%COMP%]   .ng-fa-icon[_ngcontent-%COMP%] {\n  color: var(--notification-sb-icon-color);\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL25vdGlmaWNhdGlvbi1zaWRlYmFyL25vdGlmaWNhdGlvbi1zaWRlYmFyLnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5saWdodC1idXR0b24ge1xuICAgIGJvcmRlcjogMDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICBjb2xvcjogdmFyKC0tbmF2YmFyLWRhcmstY29sb3IpO1xuICAgIHRyYW5zaXRpb246IGNvbG9yIDAuMnM7XG59XG5cbi5saWdodC1idXR0b246aG92ZXIge1xuICAgIGNvbG9yOiB2YXIoLS1saW5rLWNvbG9yKTtcbn1cblxuLm5vdGlmaWNhdGlvbi1vdmVybGF5IHtcbiAgICBkaXNwbGF5OiBub25lO1xuICAgIHotaW5kZXg6IDk5ODtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgcmlnaHQ6IDA7XG4gICAgYm90dG9tOiAwO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLW5vdGlmaWNhdGlvbi1zYi1vdmVybGF5LWJnKTtcblxuICAgICYuc2hvdyB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cbn1cblxuLm5vdGlmaWNhdGlvbi1zaWRlYmFyIHtcbiAgICB3aWR0aDogMzAwcHg7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIHRvcDogMDtcbiAgICByaWdodDogLTMwNXB4O1xuICAgIGJvdHRvbTogMDtcbiAgICB6LWluZGV4OiA5OTk7XG4gICAgdHJhbnNpdGlvbjogMC4zcztcbiAgICBvdmVyZmxvdy15OiBoaWRkZW47XG4gICAgY29sb3I6IHZhcigtLWJzLWJvZHktY29sb3IpO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLW5vdGlmaWNhdGlvbi1zYi1iYWNrZ3JvdW5kKTtcbiAgICBib3gtc2hhZG93OiAwIDAgMjBweCAwIHZhcigtLW5vdGlmaWNhdGlvbi1zYi1ib3gtc2hhZG93KTtcblxuICAgID4gKjpob3ZlciB7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1icy1ib2R5LWNvbG9yKTtcbiAgICB9XG5cbiAgICAmLnNob3cge1xuICAgICAgICByaWdodDogMDtcbiAgICAgICAgdHJhbnNpdGlvbjogMC4zcztcbiAgICB9XG5cbiAgICAuaGVhZGVyIHtcbiAgICAgICAgaGVpZ2h0OiA4NXB4O1xuICAgIH1cblxuICAgICNub3RpZmljYXRpb24tc2lkZWJhci1jb250YWluZXIge1xuICAgICAgICBoZWlnaHQ6IGNhbGMoMTAwdmggLSA4NXB4KTtcbiAgICAgICAgb3ZlcmZsb3cteTogYXV0bztcbiAgICAgICAgb3ZlcmZsb3cteDogaGlkZGVuO1xuXG4gICAgICAgIC5ub3RpZmljYXRpb24taXRlbSB7XG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgICAgICAgICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xuXG4gICAgICAgICAgICAmOm50aC1jaGlsZChldmVuKSB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbm90aWZpY2F0aW9uLXNiLWV2ZW4tY2hpbGQtYmcpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAmOmhvdmVyIHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1ub3RpZmljYXRpb24tc2ItaG92ZXItY2hpbGQtYmcpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBoNSB7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxcmVtO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuaW5mbyB7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAwLjhyZW07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAubm8tbm90aWZpY2F0aW9ucyB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICBwYWRkaW5nOiAyMHB4IDE2cHg7XG4gICAgfVxuXG4gICAgLm5nLWZhLWljb24ge1xuICAgICAgICBjb2xvcjogdmFyKC0tbm90aWZpY2F0aW9uLXNiLWljb24tY29sb3IpO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksVUFBQTtBQUNBLG9CQUFBO0FBQ0EsU0FBQSxJQUFBO0FBQ0EsY0FBQSxNQUFBOztBQUdKLENBUEEsWUFPQTtBQUNJLFNBQUEsSUFBQTs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLFdBQUE7QUFDQSxZQUFBO0FBQ0EsT0FBQTtBQUNBLFFBQUE7QUFDQSxTQUFBO0FBQ0EsVUFBQTtBQUNBLG9CQUFBLElBQUE7O0FBRUEsQ0FWSixvQkFVSSxDQUFBO0FBQ0ksV0FBQTs7QUFJUixDQUFBO0FBQ0ksU0FBQTtBQUNBLFlBQUE7QUFDQSxPQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxXQUFBO0FBQ0EsY0FBQTtBQUNBLGNBQUE7QUFDQSxTQUFBLElBQUE7QUFDQSxvQkFBQSxJQUFBO0FBQ0EsY0FBQSxFQUFBLEVBQUEsS0FBQSxFQUFBLElBQUE7O0FBRUEsQ0FiSixxQkFhSSxFQUFBLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBR0osQ0FqQkosb0JBaUJJLENBdEJBO0FBdUJJLFNBQUE7QUFDQSxjQUFBOztBQUdKLENBdEJKLHFCQXNCSSxDQUFBO0FBQ0ksVUFBQTs7QUFHSixDQTFCSixxQkEwQkksQ0FBQTtBQUNJLFVBQUEsS0FBQSxNQUFBLEVBQUE7QUFDQSxjQUFBO0FBQ0EsY0FBQTs7QUFFQSxDQS9CUixxQkErQlEsQ0FMSiwrQkFLSSxDQUFBO0FBQ0ksVUFBQTtBQUNBLGVBQUE7O0FBRUEsQ0FuQ1oscUJBbUNZLENBVFIsK0JBU1EsQ0FKSixpQkFJSTtBQUNJLG9CQUFBLElBQUE7O0FBR0osQ0F2Q1oscUJBdUNZLENBYlIsK0JBYVEsQ0FSSixpQkFRSTtBQUNJLG9CQUFBLElBQUE7O0FBR0osQ0EzQ1oscUJBMkNZLENBakJSLCtCQWlCUSxDQVpKLGtCQVlJO0FBQ0ksYUFBQTs7QUFHSixDQS9DWixxQkErQ1ksQ0FyQlIsK0JBcUJRLENBaEJKLGtCQWdCSSxDQUFBO0FBQ0ksYUFBQTs7QUFLWixDQXJESixxQkFxREksQ0FBQTtBQUNJLFdBQUE7QUFDQSxXQUFBLEtBQUE7O0FBR0osQ0ExREoscUJBMERJLENBQUE7QUFDSSxTQUFBLElBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(NotificationSidebarComponent, { className: "NotificationSidebarComponent" });
    })();
  }
});

// src/main/webapp/app/shared/notification/system-notification/system-notification.component.ts
import { Component as Component4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import dayjs2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import { faExclamationTriangle, faInfoCircle as faInfoCircle2, faTimes as faTimes2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { filter } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i62 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function SystemNotificationComponent_For_1_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                    ");
    i06.\u0275\u0275element(1, "fa-icon", 6);
    i06.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    const ctx_r6 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r6.faInfoCircle);
  }
}
function SystemNotificationComponent_For_1_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                    ");
    i06.\u0275\u0275element(1, "fa-icon", 6);
    i06.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    const ctx_r7 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r7.faExclamationTriangle);
  }
}
function SystemNotificationComponent_For_1_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                        ");
    i06.\u0275\u0275elementStart(1, "span");
    i06.\u0275\u0275text(2, ":");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n                    ");
  }
}
function SystemNotificationComponent_For_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n    ");
    i06.\u0275\u0275elementStart(1, "div", 0);
    i06.\u0275\u0275text(2, "\n        ");
    i06.\u0275\u0275elementStart(3, "div", 1);
    i06.\u0275\u0275text(4, "\n            ");
    i06.\u0275\u0275elementStart(5, "span", 2);
    i06.\u0275\u0275text(6, "\n                ");
    i06.\u0275\u0275template(7, SystemNotificationComponent_For_1_Conditional_7_Template, 3, 1)(8, SystemNotificationComponent_For_1_Conditional_8_Template, 3, 1);
    i06.\u0275\u0275elementStart(9, "span", 3);
    i06.\u0275\u0275text(10);
    i06.\u0275\u0275template(11, SystemNotificationComponent_For_1_Conditional_11_Template, 4, 0);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(12, "\n            ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(13, "\n            ");
    i06.\u0275\u0275elementStart(14, "span", 4);
    i06.\u0275\u0275text(15);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(16, "\n        ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(17, "\n        ");
    i06.\u0275\u0275elementStart(18, "fa-icon", 5);
    i06.\u0275\u0275listener("click", function SystemNotificationComponent_For_1_Template_fa_icon_click_18_listener() {
      const restoredCtx = i06.\u0275\u0275restoreView(_r10);
      const notification_r1 = restoredCtx.$implicit;
      const ctx_r9 = i06.\u0275\u0275nextContext();
      return i06.\u0275\u0275resetView(ctx_r9.close(notification_r1));
    });
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(19, "\n    ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(20, "\n");
  }
  if (rf & 2) {
    const notification_r1 = ctx.$implicit;
    const ctx_r0 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("ngClass", i06.\u0275\u0275pureFunction2(7, _c04, (notification_r1.type || ctx_r0.INFO) === ctx_r0.INFO, notification_r1.type === ctx_r0.WARNING));
    i06.\u0275\u0275advance(6);
    i06.\u0275\u0275conditional(7, (notification_r1.type || ctx_r0.INFO) === ctx_r0.INFO ? 7 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(8, notification_r1.type === ctx_r0.WARNING ? 8 : -1);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275textInterpolate1("", notification_r1.title, "\n                    ");
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(11, notification_r1.text ? 11 : -1);
    i06.\u0275\u0275advance(4);
    i06.\u0275\u0275textInterpolate(notification_r1.text);
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275property("icon", ctx_r0.faTimes);
  }
}
var _c04, WEBSOCKET_CHANNEL, SystemNotificationComponent;
var init_system_notification_component = __esm({
  "src/main/webapp/app/shared/notification/system-notification/system-notification.component.ts"() {
    init_account_service();
    init_websocket_service();
    init_system_notification_service();
    init_date_utils();
    init_account_service();
    init_websocket_service();
    init_system_notification_service();
    _c04 = (a0, a1) => ({ info: a0, warning: a1 });
    WEBSOCKET_CHANNEL = "/topic/system-notification";
    SystemNotificationComponent = class _SystemNotificationComponent {
      route;
      accountService;
      jhiWebsocketService;
      systemNotificationService;
      INFO = "INFO";
      WARNING = "WARNING";
      notifications = [];
      notificationsToDisplay = [];
      closedIds = [];
      websocketStatusSubscription;
      nextUpdateFuture;
      faExclamationTriangle = faExclamationTriangle;
      faInfoCircle = faInfoCircle2;
      faTimes = faTimes2;
      constructor(route, accountService, jhiWebsocketService, systemNotificationService) {
        this.route = route;
        this.accountService = accountService;
        this.jhiWebsocketService = jhiWebsocketService;
        this.systemNotificationService = systemNotificationService;
      }
      ngOnInit() {
        this.loadActiveNotification();
        this.accountService.getAuthenticationState().subscribe((user) => {
          if (user) {
            setTimeout(() => {
              this.websocketStatusSubscription = this.jhiWebsocketService.connectionState.pipe(filter((status) => status.connected)).subscribe(() => this.subscribeSocket());
            }, 500);
          } else {
            this.websocketStatusSubscription?.unsubscribe();
          }
        });
      }
      ngOnDestroy() {
        this.websocketStatusSubscription?.unsubscribe();
      }
      loadActiveNotification() {
        this.systemNotificationService.getActiveNotifications().subscribe((notifications) => {
          this.notifications = notifications;
          this.selectVisibleNotificationsAndScheduleUpdate();
        });
      }
      subscribeSocket() {
        this.jhiWebsocketService.subscribe(WEBSOCKET_CHANNEL);
        this.jhiWebsocketService.receive(WEBSOCKET_CHANNEL).subscribe((notifications) => {
          notifications.forEach((notification) => {
            notification.notificationDate = convertDateFromServer(notification.notificationDate);
            notification.expireDate = convertDateFromServer(notification.expireDate);
          });
          this.notifications = notifications;
          this.closedIds = [];
          this.selectVisibleNotificationsAndScheduleUpdate();
        });
      }
      selectVisibleNotificationsAndScheduleUpdate() {
        const now = dayjs2();
        this.notificationsToDisplay = this.notifications.filter((notification) => !this.closedIds.includes(notification.id)).filter((notification) => notification.notificationDate?.isSameOrBefore(now) && (notification.expireDate?.isAfter(now) ?? true));
        if (this.nextUpdateFuture) {
          clearTimeout(this.nextUpdateFuture);
          this.nextUpdateFuture = void 0;
        }
        const nextRelevantTimestamp = this.notifications.flatMap((notification) => [notification.expireDate, notification.notificationDate]).filter((date) => date?.isAfter(now)).map((date) => date).reduce((previous, current) => previous ? dayjs2.min(previous, current) : current, void 0);
        if (nextRelevantTimestamp) {
          this.nextUpdateFuture = setTimeout(() => {
            this.selectVisibleNotificationsAndScheduleUpdate();
          }, nextRelevantTimestamp.diff(now));
        }
      }
      close(notification) {
        this.closedIds.push(notification.id);
        this.selectVisibleNotificationsAndScheduleUpdate();
      }
      static \u0275fac = function SystemNotificationComponent_Factory(t) {
        return new (t || _SystemNotificationComponent)(i06.\u0275\u0275directiveInject(i12.ActivatedRoute), i06.\u0275\u0275directiveInject(AccountService), i06.\u0275\u0275directiveInject(JhiWebsocketService), i06.\u0275\u0275directiveInject(SystemNotificationService));
      };
      static \u0275cmp = i06.\u0275\u0275defineComponent({ type: _SystemNotificationComponent, selectors: [["jhi-system-notification"]], decls: 2, vars: 0, consts: [[1, "system-notification", 3, "ngClass"], [1, "notification-text"], [1, "notification-title"], [1, "left-slide-in"], [1, "notification-content", "left-slide-in"], [1, "notification-close", 3, "icon", "click"], [1, "left-slide-in", 3, "icon"]], template: function SystemNotificationComponent_Template(rf, ctx) {
        if (rf & 1) {
          i06.\u0275\u0275repeaterCreate(0, SystemNotificationComponent_For_1_Template, 21, 10, null, null, i06.\u0275\u0275repeaterTrackByIdentity);
        }
        if (rf & 2) {
          i06.\u0275\u0275repeater(ctx.notificationsToDisplay);
        }
      }, dependencies: [i5.NgClass, i62.FaIconComponent], styles: ["\n\n.system-notification[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 5px 20px 5px 10px;\n  display: flex;\n  gap: 10px;\n  align-items: center;\n  animation: 0.25s ease _ngcontent-%COMP%_init-max-height;\n  animation-fill-mode: both;\n  transform-origin: top;\n}\n.system-notification.info[_ngcontent-%COMP%] {\n  color: var(--artemis-alert-info-color);\n  background: var(--artemis-alert-info-background);\n}\n.system-notification.info[_ngcontent-%COMP%]   .ng-fa-icon[_ngcontent-%COMP%] {\n  color: var(--artemis-alert-info-border);\n}\n.system-notification.warning[_ngcontent-%COMP%] {\n  color: var(--artemis-alert-warning-color);\n  background: var(--artemis-alert-warning-background);\n}\n.system-notification.warning[_ngcontent-%COMP%]   .ng-fa-icon[_ngcontent-%COMP%] {\n  color: var(--artemis-alert-warning-border);\n}\n.system-notification[_ngcontent-%COMP%]   .notification-text[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  flex-wrap: wrap;\n}\n.system-notification[_ngcontent-%COMP%]   .notification-text[_ngcontent-%COMP%]   .notification-title[_ngcontent-%COMP%] {\n  font-weight: bold;\n  white-space: nowrap;\n  margin: 0 10px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  gap: 10px;\n}\n.system-notification[_ngcontent-%COMP%]   .notification-text[_ngcontent-%COMP%]   .notification-title[_ngcontent-%COMP%]   .ng-fa-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n  animation-delay: 0.2s;\n}\n.system-notification[_ngcontent-%COMP%]   .notification-text[_ngcontent-%COMP%]   .notification-title[_ngcontent-%COMP%]    > span[_ngcontent-%COMP%] {\n  animation-delay: 0.28s;\n}\n.system-notification[_ngcontent-%COMP%]   .notification-text[_ngcontent-%COMP%]   .notification-content[_ngcontent-%COMP%] {\n  animation-delay: 0.36s;\n}\n.system-notification[_ngcontent-%COMP%]   .left-slide-in[_ngcontent-%COMP%] {\n  animation: 0.5s cubic-bezier(0.16, 1, 0.3, 1) _ngcontent-%COMP%_left-slide-in;\n  animation-fill-mode: both;\n}\n.system-notification[_ngcontent-%COMP%]   .notification-close[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\n@keyframes _ngcontent-%COMP%_left-slide-in {\n  0% {\n    opacity: 0;\n    transform: translateX(-20px);\n  }\n  100% {\n    opacity: 1;\n    transform: translateX(0);\n  }\n}\n@keyframes _ngcontent-%COMP%_init-max-height {\n  0% {\n    opacity: 0;\n    transform: scaleY(0);\n  }\n  100% {\n    opacity: 1;\n    transform: scaleY(1);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL3N5c3RlbS1ub3RpZmljYXRpb24vc3lzdGVtLW5vdGlmaWNhdGlvbi5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuc3lzdGVtLW5vdGlmaWNhdGlvbiB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZzogNXB4IDIwcHggNXB4IDEwcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBnYXA6IDEwcHg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBhbmltYXRpb246IDAuMjVzIGVhc2UgaW5pdC1tYXgtaGVpZ2h0O1xuICAgIGFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XG4gICAgdHJhbnNmb3JtLW9yaWdpbjogdG9wO1xuXG4gICAgJi5pbmZvIHtcbiAgICAgICAgY29sb3I6IHZhcigtLWFydGVtaXMtYWxlcnQtaW5mby1jb2xvcik7XG4gICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWFydGVtaXMtYWxlcnQtaW5mby1iYWNrZ3JvdW5kKTtcblxuICAgICAgICAubmctZmEtaWNvbiB7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0tYXJ0ZW1pcy1hbGVydC1pbmZvLWJvcmRlcik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAmLndhcm5pbmcge1xuICAgICAgICBjb2xvcjogdmFyKC0tYXJ0ZW1pcy1hbGVydC13YXJuaW5nLWNvbG9yKTtcbiAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tYXJ0ZW1pcy1hbGVydC13YXJuaW5nLWJhY2tncm91bmQpO1xuXG4gICAgICAgIC5uZy1mYS1pY29uIHtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1hcnRlbWlzLWFsZXJ0LXdhcm5pbmctYm9yZGVyKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5ub3RpZmljYXRpb24tdGV4dCB7XG4gICAgICAgIGZsZXg6IDE7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBmbGV4LXdyYXA6IHdyYXA7XG5cbiAgICAgICAgLm5vdGlmaWNhdGlvbi10aXRsZSB7XG4gICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgICAgICAgICBtYXJnaW46IDAgMTBweDtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICBnYXA6IDEwcHg7XG5cbiAgICAgICAgICAgIC5uZy1mYS1pY29uIHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgICAgICAgICAgYW5pbWF0aW9uLWRlbGF5OiAwLjJzO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICA+IHNwYW4ge1xuICAgICAgICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4yOHM7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAubm90aWZpY2F0aW9uLWNvbnRlbnQge1xuICAgICAgICAgICAgYW5pbWF0aW9uLWRlbGF5OiAwLjM2cztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5sZWZ0LXNsaWRlLWluIHtcbiAgICAgICAgYW5pbWF0aW9uOiAwLjVzIGN1YmljLWJlemllcigwLjE2LCAxLCAwLjMsIDEpIGxlZnQtc2xpZGUtaW47XG4gICAgICAgIGFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XG4gICAgfVxuXG4gICAgLm5vdGlmaWNhdGlvbi1jbG9zZSB7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB9XG59XG5cbkBrZXlmcmFtZXMgbGVmdC1zbGlkZS1pbiB7XG4gICAgMCUge1xuICAgICAgICBvcGFjaXR5OiAwO1xuICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTIwcHgpO1xuICAgIH1cblxuICAgIDEwMCUge1xuICAgICAgICBvcGFjaXR5OiAxO1xuICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCk7XG4gICAgfVxufVxuXG5Aa2V5ZnJhbWVzIGluaXQtbWF4LWhlaWdodCB7XG4gICAgMCUge1xuICAgICAgICBvcGFjaXR5OiAwO1xuICAgICAgICB0cmFuc2Zvcm06IHNjYWxlWSgwKTtcbiAgICB9XG5cbiAgICAxMDAlIHtcbiAgICAgICAgb3BhY2l0eTogMTtcbiAgICAgICAgdHJhbnNmb3JtOiBzY2FsZVkoMSk7XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLENBQUE7QUFDSSxTQUFBO0FBQ0EsV0FBQSxJQUFBLEtBQUEsSUFBQTtBQUNBLFdBQUE7QUFDQSxPQUFBO0FBQ0EsZUFBQTtBQUNBLGFBQUEsTUFBQSxLQUFBO0FBQ0EsdUJBQUE7QUFDQSxvQkFBQTs7QUFFQSxDQVZKLG1CQVVJLENBQUE7QUFDSSxTQUFBLElBQUE7QUFDQSxjQUFBLElBQUE7O0FBRUEsQ0FkUixtQkFjUSxDQUpKLEtBSUksQ0FBQTtBQUNJLFNBQUEsSUFBQTs7QUFJUixDQW5CSixtQkFtQkksQ0FBQTtBQUNJLFNBQUEsSUFBQTtBQUNBLGNBQUEsSUFBQTs7QUFFQSxDQXZCUixtQkF1QlEsQ0FKSixRQUlJLENBVEE7QUFVSSxTQUFBLElBQUE7O0FBSVIsQ0E1Qkosb0JBNEJJLENBQUE7QUFDSSxRQUFBO0FBQ0EsV0FBQTtBQUNBLG1CQUFBO0FBQ0EsZUFBQTtBQUNBLGFBQUE7O0FBRUEsQ0FuQ1Isb0JBbUNRLENBUEosa0JBT0ksQ0FBQTtBQUNJLGVBQUE7QUFDQSxlQUFBO0FBQ0EsVUFBQSxFQUFBO0FBQ0EsV0FBQTtBQUNBLG1CQUFBO0FBQ0EsZUFBQTtBQUNBLE9BQUE7O0FBRUEsQ0E1Q1osb0JBNENZLENBaEJSLGtCQWdCUSxDQVRKLG1CQVNJLENBOUJKO0FBK0JRLGFBQUE7QUFDQSxtQkFBQTs7QUFHSixDQWpEWixvQkFpRFksQ0FyQlIsa0JBcUJRLENBZEosbUJBY0ksRUFBQTtBQUNJLG1CQUFBOztBQUlSLENBdERSLG9CQXNEUSxDQTFCSixrQkEwQkksQ0FBQTtBQUNJLG1CQUFBOztBQUlSLENBM0RKLG9CQTJESSxDQUFBO0FBQ0ksYUFBQSxLQUFBLGFBQUEsSUFBQSxFQUFBLENBQUEsRUFBQSxHQUFBLEVBQUEsR0FBQTtBQUNBLHVCQUFBOztBQUdKLENBaEVKLG9CQWdFSSxDQUFBO0FBQ0ksVUFBQTs7QUFJUixXQVZJO0FBV0E7QUFDSSxhQUFBO0FBQ0EsZUFBQSxXQUFBOztBQUdKO0FBQ0ksYUFBQTtBQUNBLGVBQUEsV0FBQTs7O0FBSVIsV0EzRUk7QUE0RUE7QUFDSSxhQUFBO0FBQ0EsZUFBQSxPQUFBOztBQUdKO0FBQ0ksYUFBQTtBQUNBLGVBQUEsT0FBQTs7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i06.\u0275setClassDebugInfo(SystemNotificationComponent, { className: "SystemNotificationComponent" });
    })();
  }
});

// src/main/webapp/app/shared/notification/loading-notification/loading-notification.component.ts
import { Component as Component5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { debounceTime } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function LoadingNotificationComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n            ");
    i07.\u0275\u0275element(1, "div", 0);
    i07.\u0275\u0275text(2, "\n        ");
  }
}
var LoadingNotificationComponent;
var init_loading_notification_component = __esm({
  "src/main/webapp/app/shared/notification/loading-notification/loading-notification.component.ts"() {
    init_loading_notification_service();
    init_loading_notification_service();
    LoadingNotificationComponent = class _LoadingNotificationComponent {
      loadingNotificationService;
      isLoading = false;
      loadingSubscription;
      constructor(loadingNotificationService) {
        this.loadingNotificationService = loadingNotificationService;
      }
      ngOnInit() {
        this.loadingSubscription = this.loadingNotificationService.loadingStatus.pipe(debounceTime(1e3)).subscribe((value) => {
          this.isLoading = value;
        });
      }
      ngOnDestroy() {
        this.loadingSubscription.unsubscribe();
      }
      static \u0275fac = function LoadingNotificationComponent_Factory(t) {
        return new (t || _LoadingNotificationComponent)(i07.\u0275\u0275directiveInject(LoadingNotificationService));
      };
      static \u0275cmp = i07.\u0275\u0275defineComponent({ type: _LoadingNotificationComponent, selectors: [["jhi-loading-notification"]], decls: 2, vars: 1, consts: [["role", "status", 1, "spinner-border", 2, "width", "18px", "height", "18px", "color", "white"]], template: function LoadingNotificationComponent_Template(rf, ctx) {
        if (rf & 1) {
          i07.\u0275\u0275text(0, "\n        ");
          i07.\u0275\u0275template(1, LoadingNotificationComponent_Conditional_1_Template, 3, 0);
        }
        if (rf & 2) {
          i07.\u0275\u0275advance(1);
          i07.\u0275\u0275conditional(1, ctx.isLoading ? 1 : -1);
        }
      }, encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i07.\u0275setClassDebugInfo(LoadingNotificationComponent, { className: "LoadingNotificationComponent" });
    })();
  }
});

// src/main/webapp/app/shared/layouts/navbar/navbar.component.ts
import { Component as Component6, HostListener as HostListener2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { filter as filter2, map, tap as tap2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { SessionStorageService as SessionStorageService3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute3, NavigationEnd, Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { TranslateService as TranslateService3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import { faBars, faBell as faBell2, faBook, faBookOpen, faCog as faCog2, faEye as faEye2, faFlag, faGears, faHeart, faList, faLock, faRobot, faSignOutAlt, faStamp, faTachometerAlt, faTasks, faThLarge, faThList, faToggleOn, faUniversity, faUser, faUserPlus, faWrench } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i08 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i52 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import * as i102 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i23 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i24 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i25 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function NavbarComponent_ng_template_0_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n            ");
    i08.\u0275\u0275element(1, "jhi-notification-sidebar");
    i08.\u0275\u0275text(2, "\n        ");
  }
}
function NavbarComponent_ng_template_0_Conditional_6_Conditional_5_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                                ");
    i08.\u0275\u0275elementStart(1, "span", 27);
    i08.\u0275\u0275text(2, "Account");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(3, "\n                            ");
  }
}
function NavbarComponent_ng_template_0_Conditional_6_Conditional_5_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                                ");
    i08.\u0275\u0275elementStart(1, "span");
    i08.\u0275\u0275text(2);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(3, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r21 = i08.\u0275\u0275nextContext(4);
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275textInterpolate(ctx_r21.currAccount.login);
  }
}
function NavbarComponent_ng_template_0_Conditional_6_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                        ");
    i08.\u0275\u0275elementStart(1, "span");
    i08.\u0275\u0275text(2, "\n                            ");
    i08.\u0275\u0275element(3, "fa-icon", 12);
    i08.\u0275\u0275text(4, "\n                            ");
    i08.\u0275\u0275template(5, NavbarComponent_ng_template_0_Conditional_6_Conditional_5_Conditional_5_Template, 4, 0)(6, NavbarComponent_ng_template_0_Conditional_6_Conditional_5_Conditional_6_Template, 4, 1);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r13 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275property("icon", ctx_r13.faUser);
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275conditional(5, !ctx_r13.currAccount ? 5 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275conditional(6, ctx_r13.currAccount ? 6 : -1);
  }
}
function NavbarComponent_ng_template_0_Conditional_6_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                        ");
    i08.\u0275\u0275elementStart(1, "span");
    i08.\u0275\u0275text(2, "\n                            ");
    i08.\u0275\u0275element(3, "img", 28);
    i08.\u0275\u0275text(4, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r14 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275property("src", ctx_r14.getImageUrl(), i08.\u0275\u0275sanitizeUrl);
  }
}
function NavbarComponent_ng_template_0_Conditional_6_Conditional_30_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r29 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                                ");
    i08.\u0275\u0275elementStart(1, "li");
    i08.\u0275\u0275text(2, "\n                                    ");
    i08.\u0275\u0275elementStart(3, "a", 29);
    i08.\u0275\u0275listener("click", function NavbarComponent_ng_template_0_Conditional_6_Conditional_30_For_4_Template_a_click_3_listener() {
      const restoredCtx = i08.\u0275\u0275restoreView(_r29);
      const language_r23 = restoredCtx.$implicit;
      const ctx_r28 = i08.\u0275\u0275nextContext(4);
      ctx_r28.changeLanguage(language_r23);
      return i08.\u0275\u0275resetView(ctx_r28.collapseNavbar());
    });
    i08.\u0275\u0275text(4);
    i08.\u0275\u0275pipe(5, "findLanguageFromKey");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(6, "\n                                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n                            ");
  }
  if (rf & 2) {
    const language_r23 = ctx.$implicit;
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275property("jhiActiveMenu", language_r23);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275textInterpolate(i08.\u0275\u0275pipeBind1(5, 2, language_r23));
  }
}
function NavbarComponent_ng_template_0_Conditional_6_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                        ");
    i08.\u0275\u0275elementStart(1, "div");
    i08.\u0275\u0275text(2, "\n                            ");
    i08.\u0275\u0275repeaterCreate(3, NavbarComponent_ng_template_0_Conditional_6_Conditional_30_For_4_Template, 8, 4, null, null, i08.\u0275\u0275repeaterTrackByIdentity);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r15 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275repeater(ctx_r15.languages);
  }
}
function NavbarComponent_ng_template_0_Conditional_6_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                        ");
    i08.\u0275\u0275element(1, "div", 25);
    i08.\u0275\u0275text(2, "\n                        ");
    i08.\u0275\u0275elementStart(3, "li");
    i08.\u0275\u0275text(4, "\n                            ");
    i08.\u0275\u0275elementStart(5, "h6", 30);
    i08.\u0275\u0275text(6, "Guided Tutorial");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(8, "\n                        ");
    i08.\u0275\u0275elementStart(9, "li");
    i08.\u0275\u0275text(10, "\n                            ");
    i08.\u0275\u0275elementStart(11, "a", 31);
    i08.\u0275\u0275listener("click", function NavbarComponent_ng_template_0_Conditional_6_Conditional_31_Template_a_click_11_listener() {
      i08.\u0275\u0275restoreView(_r31);
      const ctx_r30 = i08.\u0275\u0275nextContext(3);
      return i08.\u0275\u0275resetView(ctx_r30.guidedTourService.initGuidedTour());
    });
    i08.\u0275\u0275text(12, "Start tutorial");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(13, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(14, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r16 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("jhiTranslate", ctx_r16.guidedTourInitLabel());
  }
}
function NavbarComponent_ng_template_0_Conditional_6_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    const _r33 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                        ");
    i08.\u0275\u0275elementStart(1, "li");
    i08.\u0275\u0275text(2, "\n                            ");
    i08.\u0275\u0275elementStart(3, "a", 32);
    i08.\u0275\u0275listener("click", function NavbarComponent_ng_template_0_Conditional_6_Conditional_34_Template_a_click_3_listener() {
      i08.\u0275\u0275restoreView(_r33);
      const ctx_r32 = i08.\u0275\u0275nextContext(3);
      return i08.\u0275\u0275resetView(ctx_r32.collapseNavbar());
    });
    i08.\u0275\u0275text(4, "\n                                ");
    i08.\u0275\u0275element(5, "fa-icon", 24);
    i08.\u0275\u0275text(6, "\n                                ");
    i08.\u0275\u0275elementStart(7, "span", 33);
    i08.\u0275\u0275text(8, "Settings");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(9, "\n                            ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(10, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(11, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r17 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275property("icon", ctx_r17.faWrench)("fixedWidth", true);
  }
}
function NavbarComponent_ng_template_0_Conditional_6_Conditional_35_Template(rf, ctx) {
  if (rf & 1) {
    const _r35 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                        ");
    i08.\u0275\u0275elementStart(1, "li");
    i08.\u0275\u0275text(2, "\n                            ");
    i08.\u0275\u0275elementStart(3, "a", 34);
    i08.\u0275\u0275listener("click", function NavbarComponent_ng_template_0_Conditional_6_Conditional_35_Template_a_click_3_listener() {
      i08.\u0275\u0275restoreView(_r35);
      const ctx_r34 = i08.\u0275\u0275nextContext(3);
      return i08.\u0275\u0275resetView(ctx_r34.collapseNavbar());
    });
    i08.\u0275\u0275text(4, "\n                                ");
    i08.\u0275\u0275element(5, "fa-icon", 24);
    i08.\u0275\u0275text(6, "\n                                ");
    i08.\u0275\u0275elementStart(7, "span", 35);
    i08.\u0275\u0275text(8, "Password");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(9, "\n                            ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(10, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(11, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r18 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275property("icon", ctx_r18.faLock)("fixedWidth", true);
  }
}
function NavbarComponent_ng_template_0_Conditional_6_Conditional_38_Template(rf, ctx) {
  if (rf & 1) {
    const _r37 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                            ");
    i08.\u0275\u0275elementStart(1, "a", 36);
    i08.\u0275\u0275listener("click", function NavbarComponent_ng_template_0_Conditional_6_Conditional_38_Template_a_click_1_listener() {
      i08.\u0275\u0275restoreView(_r37);
      const ctx_r36 = i08.\u0275\u0275nextContext(3);
      return i08.\u0275\u0275resetView(ctx_r36.logout());
    });
    i08.\u0275\u0275text(2, "\n                                ");
    i08.\u0275\u0275element(3, "fa-icon", 24);
    i08.\u0275\u0275text(4, "\n                                ");
    i08.\u0275\u0275elementStart(5, "span", 37);
    i08.\u0275\u0275text(6, "Sign out");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n                            ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(8, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r19 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275property("icon", ctx_r19.faSignOutAlt)("fixedWidth", true);
  }
}
function NavbarComponent_ng_template_0_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r39 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n            ");
    i08.\u0275\u0275elementStart(1, "div", 20);
    i08.\u0275\u0275text(2, "\n                ");
    i08.\u0275\u0275elementStart(3, "a", 21);
    i08.\u0275\u0275text(4, "\n                    ");
    i08.\u0275\u0275template(5, NavbarComponent_ng_template_0_Conditional_6_Conditional_5_Template, 8, 3)(6, NavbarComponent_ng_template_0_Conditional_6_Conditional_6_Template, 6, 1);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n                ");
    i08.\u0275\u0275elementStart(8, "ul", 22);
    i08.\u0275\u0275text(9, "\n                    ");
    i08.\u0275\u0275elementStart(10, "li");
    i08.\u0275\u0275text(11, "\n                        ");
    i08.\u0275\u0275elementStart(12, "a", 23);
    i08.\u0275\u0275listener("click", function NavbarComponent_ng_template_0_Conditional_6_Template_a_click_12_listener() {
      i08.\u0275\u0275restoreView(_r39);
      const ctx_r38 = i08.\u0275\u0275nextContext(2);
      return i08.\u0275\u0275resetView(ctx_r38.collapseNavbar());
    });
    i08.\u0275\u0275text(13, "\n                            ");
    i08.\u0275\u0275element(14, "fa-icon", 24);
    i08.\u0275\u0275text(15, "\n                            ");
    i08.\u0275\u0275elementStart(16, "span");
    i08.\u0275\u0275text(17);
    i08.\u0275\u0275pipe(18, "artemisTranslate");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(19, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(20, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(21, "\n                    ");
    i08.\u0275\u0275element(22, "div", 25);
    i08.\u0275\u0275text(23, "\n                    ");
    i08.\u0275\u0275elementStart(24, "li");
    i08.\u0275\u0275text(25, "\n                        ");
    i08.\u0275\u0275elementStart(26, "h6", 26);
    i08.\u0275\u0275text(27, "Language");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(28, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(29, "\n                    ");
    i08.\u0275\u0275template(30, NavbarComponent_ng_template_0_Conditional_6_Conditional_30_Template, 6, 0)(31, NavbarComponent_ng_template_0_Conditional_6_Conditional_31_Template, 15, 1);
    i08.\u0275\u0275element(32, "div", 25);
    i08.\u0275\u0275text(33, "\n                    ");
    i08.\u0275\u0275template(34, NavbarComponent_ng_template_0_Conditional_6_Conditional_34_Template, 12, 2)(35, NavbarComponent_ng_template_0_Conditional_6_Conditional_35_Template, 12, 2);
    i08.\u0275\u0275elementStart(36, "li");
    i08.\u0275\u0275text(37, "\n                        ");
    i08.\u0275\u0275template(38, NavbarComponent_ng_template_0_Conditional_6_Conditional_38_Template, 9, 2);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(39, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(40, "\n            ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(41, "\n        ");
  }
  if (rf & 2) {
    const ctx_r12 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("placement", "bottom-right")("routerLinkActiveOptions", i08.\u0275\u0275pureFunction0(16, _c05))("autoClose", true);
    i08.\u0275\u0275advance(4);
    i08.\u0275\u0275conditional(5, !ctx_r12.getImageUrl() ? 5 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275conditional(6, ctx_r12.getImageUrl() ? 6 : -1);
    i08.\u0275\u0275advance(6);
    i08.\u0275\u0275property("routerLink", i08.\u0275\u0275pureFunction0(17, _c14));
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275property("icon", ctx_r12.faCog)("fixedWidth", true);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275textInterpolate(i08.\u0275\u0275pipeBind1(18, 14, "global.menu.settings"));
    i08.\u0275\u0275advance(13);
    i08.\u0275\u0275conditional(30, ctx_r12.languages && ctx_r12.languages.length > 1 ? 30 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275conditional(31, ctx_r12.isTourAvailable ? 31 : -1);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275conditional(34, ctx_r12.isRegistrationEnabled ? 34 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275conditional(35, ctx_r12.passwordResetEnabled ? 35 : -1);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275conditional(38, ctx_r12.currAccount ? 38 : -1);
  }
}
function NavbarComponent_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n    ");
    i08.\u0275\u0275elementStart(1, "div", 18);
    i08.\u0275\u0275text(2, "\n        ");
    i08.\u0275\u0275template(3, NavbarComponent_ng_template_0_Conditional_3_Template, 3, 0);
    i08.\u0275\u0275element(4, "jhi-theme-switch", 19);
    i08.\u0275\u0275text(5, "\n        ");
    i08.\u0275\u0275template(6, NavbarComponent_ng_template_0_Conditional_6_Template, 42, 18);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("ngClass", i08.\u0275\u0275pureFunction2(4, _c22, ctx_r0.isNavbarNavVertical, ctx_r0.iconsMovedToMenu));
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275conditional(3, ctx_r0.currAccount && !ctx_r0.isExamActive ? 3 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("popoverPlacement", ctx_r0.iconsMovedToMenu ? "bottom" : "bottom-right");
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275conditional(6, ctx_r0.isAuthenticated() ? 6 : -1);
  }
}
function NavbarComponent_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275elementStart(1, "div");
    i08.\u0275\u0275text(2);
    i08.\u0275\u0275pipe(3, "artemisTranslate");
    i08.\u0275\u0275element(4, "br");
    i08.\u0275\u0275text(5);
    i08.\u0275\u0275pipe(6, "artemisTranslate");
    i08.\u0275\u0275element(7, "br");
    i08.\u0275\u0275text(8);
    i08.\u0275\u0275pipe(9, "artemisTranslate");
    i08.\u0275\u0275element(10, "br");
    i08.\u0275\u0275text(11);
    i08.\u0275\u0275pipe(12, "artemisTranslate");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(13, "\n            ");
  }
  if (rf & 2) {
    const ctx_r2 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275textInterpolate2("\n                    ", i08.\u0275\u0275pipeBind1(3, 8, "artemisApp.git.branch"), ": ", ctx_r2.gitBranchName, " ");
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275textInterpolate2("\n                    ", i08.\u0275\u0275pipeBind1(6, 10, "artemisApp.git.commit"), ": ", ctx_r2.gitCommitId, " ");
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275textInterpolate2("\n                    ", i08.\u0275\u0275pipeBind1(9, 12, "artemisApp.git.timestamp"), ": ", ctx_r2.gitTimestamp, " ");
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275textInterpolate2("\n                    ", i08.\u0275\u0275pipeBind1(12, 14, "artemisApp.git.username"), ": ", ctx_r2.gitUsername, "\n                ");
  }
}
function NavbarComponent_Conditional_28_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementContainer(0);
  }
}
function NavbarComponent_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n            ");
    i08.\u0275\u0275template(1, NavbarComponent_Conditional_28_ng_container_1_Template, 1, 0, "ng-container", 38);
    i08.\u0275\u0275text(2, "\n        ");
  }
  if (rf & 2) {
    i08.\u0275\u0275nextContext();
    const _r1 = i08.\u0275\u0275reference(1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("ngTemplateOutlet", _r1);
  }
}
function NavbarComponent_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    const _r42 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275elementStart(1, "li", 39);
    i08.\u0275\u0275text(2, "\n                    ");
    i08.\u0275\u0275elementStart(3, "a", 40);
    i08.\u0275\u0275listener("click", function NavbarComponent_Conditional_42_Template_a_click_3_listener() {
      i08.\u0275\u0275restoreView(_r42);
      const ctx_r41 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r41.collapseNavbar());
    });
    i08.\u0275\u0275text(4, "\n                        ");
    i08.\u0275\u0275elementStart(5, "span");
    i08.\u0275\u0275text(6, "\n                            ");
    i08.\u0275\u0275element(7, "fa-icon", 12);
    i08.\u0275\u0275text(8, "\n                            ");
    i08.\u0275\u0275elementStart(9, "span", 41);
    i08.\u0275\u0275text(10, "Course Overview");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(11, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(12, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(13, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(14, "\n            ");
  }
  if (rf & 2) {
    const ctx_r5 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("routerLinkActiveOptions", i08.\u0275\u0275pureFunction0(2, _c05));
    i08.\u0275\u0275advance(6);
    i08.\u0275\u0275property("icon", ctx_r5.faThLarge);
  }
}
function NavbarComponent_li_43_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r45 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                    ");
    i08.\u0275\u0275elementStart(1, "a", 43);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_43_Conditional_2_Template_a_click_1_listener() {
      i08.\u0275\u0275restoreView(_r45);
      const ctx_r44 = i08.\u0275\u0275nextContext(2);
      return i08.\u0275\u0275resetView(ctx_r44.collapseNavbar());
    });
    i08.\u0275\u0275text(2, "\n                        ");
    i08.\u0275\u0275elementStart(3, "span");
    i08.\u0275\u0275text(4, "\n                            ");
    i08.\u0275\u0275element(5, "fa-icon", 12);
    i08.\u0275\u0275text(6, "\n                            ");
    i08.\u0275\u0275elementStart(7, "span", 44);
    i08.\u0275\u0275text(8, "Course Management");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(9, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(10, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(11, "\n                ");
  }
  if (rf & 2) {
    const ctx_r43 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275property("icon", ctx_r43.faThList);
  }
}
function NavbarComponent_li_43_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "li", 42);
    i08.\u0275\u0275text(1, "\n                ");
    i08.\u0275\u0275template(2, NavbarComponent_li_43_Conditional_2_Template, 12, 1);
    i08.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r6 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275property("routerLinkActiveOptions", i08.\u0275\u0275pureFunction0(2, _c05));
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275conditional(2, !ctx_r6.isExamActive ? 2 : -1);
  }
}
function NavbarComponent_li_45_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                    ");
    i08.\u0275\u0275elementStart(1, "a", 72);
    i08.\u0275\u0275text(2, "\n                        ");
    i08.\u0275\u0275elementStart(3, "span");
    i08.\u0275\u0275text(4, "\n                            ");
    i08.\u0275\u0275element(5, "fa-icon", 12);
    i08.\u0275\u0275text(6, "\n                            ");
    i08.\u0275\u0275elementStart(7, "span", 73);
    i08.\u0275\u0275text(8, "Server Administration");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(9, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(10, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(11, "\n                ");
  }
  if (rf & 2) {
    const ctx_r46 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275property("icon", ctx_r46.faUserPlus);
  }
}
function NavbarComponent_li_45_Conditional_148_Template(rf, ctx) {
  if (rf & 1) {
    const _r51 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                        ");
    i08.\u0275\u0275elementStart(1, "li");
    i08.\u0275\u0275text(2, "\n                            ");
    i08.\u0275\u0275elementStart(3, "a", 74);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Conditional_148_Template_a_click_3_listener() {
      i08.\u0275\u0275restoreView(_r51);
      const ctx_r50 = i08.\u0275\u0275nextContext(2);
      return i08.\u0275\u0275resetView(ctx_r50.collapseNavbar());
    });
    i08.\u0275\u0275text(4, "\n                                ");
    i08.\u0275\u0275element(5, "fa-icon", 24);
    i08.\u0275\u0275text(6, "\n                                ");
    i08.\u0275\u0275elementStart(7, "span", 75);
    i08.\u0275\u0275text(8, "Build Queue");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(9, "\n                            ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(10, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(11, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r47 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275property("icon", ctx_r47.faList)("fixedWidth", true);
  }
}
function NavbarComponent_li_45_Conditional_149_Template(rf, ctx) {
  if (rf & 1) {
    const _r53 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                        ");
    i08.\u0275\u0275elementStart(1, "li");
    i08.\u0275\u0275text(2, "\n                            ");
    i08.\u0275\u0275elementStart(3, "a", 76);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Conditional_149_Template_a_click_3_listener() {
      i08.\u0275\u0275restoreView(_r53);
      const ctx_r52 = i08.\u0275\u0275nextContext(2);
      return i08.\u0275\u0275resetView(ctx_r52.collapseNavbar());
    });
    i08.\u0275\u0275text(4, "\n                                ");
    i08.\u0275\u0275element(5, "fa-icon", 24);
    i08.\u0275\u0275text(6, "\n                                ");
    i08.\u0275\u0275elementStart(7, "span", 77);
    i08.\u0275\u0275text(8, "API");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(9, "\n                            ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(10, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(11, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r48 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275property("icon", ctx_r48.faBook)("fixedWidth", true);
  }
}
function NavbarComponent_li_45_Conditional_150_Template(rf, ctx) {
  if (rf & 1) {
    const _r55 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                        ");
    i08.\u0275\u0275elementStart(1, "li");
    i08.\u0275\u0275text(2, "\n                            ");
    i08.\u0275\u0275elementStart(3, "a", 78);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Conditional_150_Template_a_click_3_listener() {
      i08.\u0275\u0275restoreView(_r55);
      const ctx_r54 = i08.\u0275\u0275nextContext(2);
      return i08.\u0275\u0275resetView(ctx_r54.collapseNavbar());
    });
    i08.\u0275\u0275text(4, "\n                                ");
    i08.\u0275\u0275element(5, "fa-icon", 24);
    i08.\u0275\u0275text(6, "\n                                ");
    i08.\u0275\u0275elementStart(7, "span", 79);
    i08.\u0275\u0275text(8, "Iris Settings");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(9, "\n                            ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(10, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(11, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r49 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275property("icon", ctx_r49.faRobot)("fixedWidth", true);
  }
}
function NavbarComponent_li_45_Template(rf, ctx) {
  if (rf & 1) {
    const _r57 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementStart(0, "li", 45);
    i08.\u0275\u0275text(1, "\n                ");
    i08.\u0275\u0275template(2, NavbarComponent_li_45_Conditional_2_Template, 12, 1);
    i08.\u0275\u0275elementStart(3, "ul", 22);
    i08.\u0275\u0275text(4, "\n                    ");
    i08.\u0275\u0275elementStart(5, "li");
    i08.\u0275\u0275text(6, "\n                        ");
    i08.\u0275\u0275elementStart(7, "a", 46);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_7_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r56 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r56.collapseNavbar());
    });
    i08.\u0275\u0275text(8, "\n                            ");
    i08.\u0275\u0275element(9, "fa-icon", 24);
    i08.\u0275\u0275text(10, "\n                            ");
    i08.\u0275\u0275elementStart(11, "span", 47);
    i08.\u0275\u0275text(12, "Upcoming Exams & Exercises");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(13, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(14, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(15, "\n                    ");
    i08.\u0275\u0275elementStart(16, "li");
    i08.\u0275\u0275text(17, "\n                        ");
    i08.\u0275\u0275elementStart(18, "a", 48);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_18_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r58 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r58.collapseNavbar());
    });
    i08.\u0275\u0275text(19, "\n                            ");
    i08.\u0275\u0275element(20, "fa-icon", 24);
    i08.\u0275\u0275text(21, "\n                            ");
    i08.\u0275\u0275elementStart(22, "span", 49);
    i08.\u0275\u0275text(23, "User management");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(24, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(25, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(26, "\n                    ");
    i08.\u0275\u0275elementStart(27, "li");
    i08.\u0275\u0275text(28, "\n                        ");
    i08.\u0275\u0275elementStart(29, "a", 50);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_29_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r59 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r59.collapseNavbar());
    });
    i08.\u0275\u0275text(30, "\n                            ");
    i08.\u0275\u0275element(31, "fa-icon", 24);
    i08.\u0275\u0275text(32, "\n                            ");
    i08.\u0275\u0275elementStart(33, "span", 51);
    i08.\u0275\u0275text(34, "Organization management");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(35, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(36, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(37, "\n                    ");
    i08.\u0275\u0275elementStart(38, "li");
    i08.\u0275\u0275text(39, "\n                        ");
    i08.\u0275\u0275elementStart(40, "a", 52);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_40_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r60 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r60.collapseNavbar());
    });
    i08.\u0275\u0275text(41, "\n                            ");
    i08.\u0275\u0275element(42, "fa-icon", 24);
    i08.\u0275\u0275text(43, "\n                            ");
    i08.\u0275\u0275elementStart(44, "span", 53);
    i08.\u0275\u0275text(45, "System notifications");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(46, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(47, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(48, "\n                    ");
    i08.\u0275\u0275elementStart(49, "li");
    i08.\u0275\u0275text(50, "\n                        ");
    i08.\u0275\u0275elementStart(51, "a", 54);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_51_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r61 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r61.collapseNavbar());
    });
    i08.\u0275\u0275text(52, "\n                            ");
    i08.\u0275\u0275element(53, "fa-icon", 24);
    i08.\u0275\u0275text(54, "\n                            ");
    i08.\u0275\u0275elementStart(55, "span", 55);
    i08.\u0275\u0275text(56, "Feature Toggles");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(57, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(58, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(59, "\n                    ");
    i08.\u0275\u0275elementStart(60, "li");
    i08.\u0275\u0275text(61, "\n                        ");
    i08.\u0275\u0275elementStart(62, "a", 56);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_62_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r62 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r62.collapseNavbar());
    });
    i08.\u0275\u0275text(63, "\n                            ");
    i08.\u0275\u0275element(64, "fa-icon", 24);
    i08.\u0275\u0275text(65, "\n                            ");
    i08.\u0275\u0275elementStart(66, "span", 57);
    i08.\u0275\u0275text(67, "User statistics");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(68, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(69, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(70, "\n                    ");
    i08.\u0275\u0275elementStart(71, "li");
    i08.\u0275\u0275text(72, "\n                        ");
    i08.\u0275\u0275elementStart(73, "a", 58);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_73_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r63 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r63.collapseNavbar());
    });
    i08.\u0275\u0275text(74, "\n                            ");
    i08.\u0275\u0275element(75, "fa-icon", 24);
    i08.\u0275\u0275text(76, "\n                            ");
    i08.\u0275\u0275elementStart(77, "span", 59);
    i08.\u0275\u0275text(78, "Metrics");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(79, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(80, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(81, "\n                    ");
    i08.\u0275\u0275elementStart(82, "li");
    i08.\u0275\u0275text(83, "\n                        ");
    i08.\u0275\u0275elementStart(84, "a", 60);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_84_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r64 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r64.collapseNavbar());
    });
    i08.\u0275\u0275text(85, "\n                            ");
    i08.\u0275\u0275element(86, "fa-icon", 24);
    i08.\u0275\u0275text(87, "\n                            ");
    i08.\u0275\u0275elementStart(88, "span", 61);
    i08.\u0275\u0275text(89, "Privacy statement");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(90, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(91, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(92, "\n                    ");
    i08.\u0275\u0275elementStart(93, "li");
    i08.\u0275\u0275text(94, "\n                        ");
    i08.\u0275\u0275elementStart(95, "a", 62);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_95_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r65 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r65.collapseNavbar());
    });
    i08.\u0275\u0275text(96, "\n                            ");
    i08.\u0275\u0275element(97, "fa-icon", 24);
    i08.\u0275\u0275text(98, "\n                            ");
    i08.\u0275\u0275elementStart(99, "span", 63);
    i08.\u0275\u0275text(100, "Imprint");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(101, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(102, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(103, "\n                    ");
    i08.\u0275\u0275elementStart(104, "li");
    i08.\u0275\u0275text(105, "\n                        ");
    i08.\u0275\u0275elementStart(106, "a", 64);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_106_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r66 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r66.collapseNavbar());
    });
    i08.\u0275\u0275text(107, "\n                            ");
    i08.\u0275\u0275element(108, "fa-icon", 24);
    i08.\u0275\u0275text(109, "\n                            ");
    i08.\u0275\u0275elementStart(110, "span", 65);
    i08.\u0275\u0275text(111, "Health");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(112, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(113, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(114, "\n                    ");
    i08.\u0275\u0275elementStart(115, "li");
    i08.\u0275\u0275text(116, "\n                        ");
    i08.\u0275\u0275elementStart(117, "a", 66);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_117_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r67 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r67.collapseNavbar());
    });
    i08.\u0275\u0275text(118, "\n                            ");
    i08.\u0275\u0275element(119, "fa-icon", 24);
    i08.\u0275\u0275text(120, "\n                            ");
    i08.\u0275\u0275elementStart(121, "span", 67);
    i08.\u0275\u0275text(122, "Configuration");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(123, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(124, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(125, "\n                    ");
    i08.\u0275\u0275elementStart(126, "li");
    i08.\u0275\u0275text(127, "\n                        ");
    i08.\u0275\u0275elementStart(128, "a", 68);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_128_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r68 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r68.collapseNavbar());
    });
    i08.\u0275\u0275text(129, "\n                            ");
    i08.\u0275\u0275element(130, "fa-icon", 24);
    i08.\u0275\u0275text(131, "\n                            ");
    i08.\u0275\u0275elementStart(132, "span", 69);
    i08.\u0275\u0275text(133, "Audits");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(134, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(135, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(136, "\n                    ");
    i08.\u0275\u0275elementStart(137, "li");
    i08.\u0275\u0275text(138, "\n                        ");
    i08.\u0275\u0275elementStart(139, "a", 70);
    i08.\u0275\u0275listener("click", function NavbarComponent_li_45_Template_a_click_139_listener() {
      i08.\u0275\u0275restoreView(_r57);
      const ctx_r69 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r69.collapseNavbar());
    });
    i08.\u0275\u0275text(140, "\n                            ");
    i08.\u0275\u0275element(141, "fa-icon", 24);
    i08.\u0275\u0275text(142, "\n                            ");
    i08.\u0275\u0275elementStart(143, "span", 71);
    i08.\u0275\u0275text(144, "Logs");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(145, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(146, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(147, "\n                    ");
    i08.\u0275\u0275template(148, NavbarComponent_li_45_Conditional_148_Template, 12, 2)(149, NavbarComponent_li_45_Conditional_149_Template, 12, 2)(150, NavbarComponent_li_45_Conditional_150_Template, 12, 2);
    i08.\u0275\u0275text(151, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(152, "\n            ");
    i08.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r7 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275property("routerLinkActiveOptions", i08.\u0275\u0275pureFunction0(31, _c05));
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275conditional(2, !ctx_r7.isExamActive ? 2 : -1);
    i08.\u0275\u0275advance(7);
    i08.\u0275\u0275property("icon", ctx_r7.faBookOpen)("fixedWidth", true);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("icon", ctx_r7.faUser)("fixedWidth", true);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("icon", ctx_r7.faUniversity)("fixedWidth", true);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("icon", ctx_r7.faBell)("fixedWidth", true);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("icon", ctx_r7.faToggleOn)("fixedWidth", true);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("icon", ctx_r7.faEye)("fixedWidth", true);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("icon", ctx_r7.faTachometerAlt)("fixedWidth", true);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("icon", ctx_r7.faLock)("fixedWidth", true);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("icon", ctx_r7.faStamp)("fixedWidth", true);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("icon", ctx_r7.faHeart)("fixedWidth", true);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("icon", ctx_r7.faList)("fixedWidth", true);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("icon", ctx_r7.faBell)("fixedWidth", true);
    i08.\u0275\u0275advance(11);
    i08.\u0275\u0275property("icon", ctx_r7.faTasks)("fixedWidth", true);
    i08.\u0275\u0275advance(7);
    i08.\u0275\u0275conditional(148, ctx_r7.localCIActive ? 148 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275conditional(149, ctx_r7.openApiEnabled ? 149 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275conditional(150, ctx_r7.irisEnabled ? 150 : -1);
  }
}
function NavbarComponent_Conditional_47_For_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r77 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                            ");
    i08.\u0275\u0275elementStart(1, "li");
    i08.\u0275\u0275text(2, "\n                                ");
    i08.\u0275\u0275elementStart(3, "a", 29);
    i08.\u0275\u0275listener("click", function NavbarComponent_Conditional_47_For_17_Template_a_click_3_listener() {
      const restoredCtx = i08.\u0275\u0275restoreView(_r77);
      const language_r71 = restoredCtx.$implicit;
      const ctx_r76 = i08.\u0275\u0275nextContext(2);
      ctx_r76.changeLanguage(language_r71);
      return i08.\u0275\u0275resetView(ctx_r76.collapseNavbar());
    });
    i08.\u0275\u0275text(4);
    i08.\u0275\u0275pipe(5, "findLanguageFromKey");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(6, "\n                            ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n                        ");
  }
  if (rf & 2) {
    const language_r71 = ctx.$implicit;
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275property("jhiActiveMenu", language_r71);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275textInterpolate(i08.\u0275\u0275pipeBind1(5, 2, language_r71));
  }
}
function NavbarComponent_Conditional_47_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275elementStart(1, "li", 80);
    i08.\u0275\u0275text(2, "\n                    ");
    i08.\u0275\u0275elementStart(3, "a", 81);
    i08.\u0275\u0275text(4, "\n                        ");
    i08.\u0275\u0275elementStart(5, "span");
    i08.\u0275\u0275text(6, "\n                            ");
    i08.\u0275\u0275element(7, "fa-icon", 12);
    i08.\u0275\u0275text(8, "\n                            ");
    i08.\u0275\u0275elementStart(9, "span", 82);
    i08.\u0275\u0275text(10, "Language");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(11, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(12, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(13, "\n                    ");
    i08.\u0275\u0275elementStart(14, "ul", 83);
    i08.\u0275\u0275text(15, "\n                        ");
    i08.\u0275\u0275repeaterCreate(16, NavbarComponent_Conditional_47_For_17_Template, 8, 4, null, null, i08.\u0275\u0275repeaterTrackByIdentity);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(18, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(19, "\n            ");
  }
  if (rf & 2) {
    const ctx_r8 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(7);
    i08.\u0275\u0275property("icon", ctx_r8.faFlag);
    i08.\u0275\u0275advance(9);
    i08.\u0275\u0275repeater(ctx_r8.languages);
  }
}
function NavbarComponent_Conditional_49_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementContainer(0);
  }
}
function NavbarComponent_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n            ");
    i08.\u0275\u0275template(1, NavbarComponent_Conditional_49_ng_container_1_Template, 1, 0, "ng-container", 38);
    i08.\u0275\u0275text(2, "\n        ");
  }
  if (rf & 2) {
    i08.\u0275\u0275nextContext();
    const _r1 = i08.\u0275\u0275reference(1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("ngTemplateOutlet", _r1);
  }
}
function NavbarComponent_Conditional_56_For_6_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                            ");
    i08.\u0275\u0275elementStart(1, "a", 86);
    i08.\u0275\u0275text(2);
    i08.\u0275\u0275pipe(3, "artemisTranslate");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r87 = i08.\u0275\u0275nextContext();
    const i_r81 = ctx_r87.$index;
    const breadcrumb_r80 = ctx_r87.$implicit;
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275propertyInterpolate1("id", "bread-crumb-", i_r81, "");
    i08.\u0275\u0275property("routerLink", breadcrumb_r80.uri)("routerLinkActiveOptions", i08.\u0275\u0275pureFunction0(6, _c05));
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275textInterpolate(i08.\u0275\u0275pipeBind1(3, 4, breadcrumb_r80.label));
  }
}
function NavbarComponent_Conditional_56_For_6_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                            ");
    i08.\u0275\u0275elementStart(1, "a", 86);
    i08.\u0275\u0275text(2);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r88 = i08.\u0275\u0275nextContext();
    const i_r81 = ctx_r88.$index;
    const breadcrumb_r80 = ctx_r88.$implicit;
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275propertyInterpolate1("id", "bread-crumb-plain-", i_r81, "");
    i08.\u0275\u0275property("routerLink", breadcrumb_r80.uri)("routerLinkActiveOptions", i08.\u0275\u0275pureFunction0(4, _c05));
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275textInterpolate(breadcrumb_r80.label);
  }
}
function NavbarComponent_Conditional_56_For_6_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                    ");
    i08.\u0275\u0275elementStart(1, "li", 85);
    i08.\u0275\u0275text(2, "\n                        ");
    i08.\u0275\u0275template(3, NavbarComponent_Conditional_56_For_6_Conditional_3_Template, 5, 7)(4, NavbarComponent_Conditional_56_For_6_Conditional_4_Template, 4, 5);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const breadcrumb_r80 = ctx.$implicit;
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275conditional(3, breadcrumb_r80 && breadcrumb_r80.translate ? 3 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275conditional(4, breadcrumb_r80 && !breadcrumb_r80.translate ? 4 : -1);
  }
}
function NavbarComponent_Conditional_56_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n        ");
    i08.\u0275\u0275elementStart(1, "div");
    i08.\u0275\u0275text(2, "\n            ");
    i08.\u0275\u0275elementStart(3, "ol", 84);
    i08.\u0275\u0275text(4, "\n                ");
    i08.\u0275\u0275repeaterCreate(5, NavbarComponent_Conditional_56_For_6_Template, 6, 2, null, null, i08.\u0275\u0275repeaterTrackByIdentity);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(8, "\n    ");
  }
  if (rf & 2) {
    const ctx_r10 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275repeater(ctx_r10.breadcrumbs);
  }
}
var _c05, _c14, _c22, _c32, NavbarComponent, Breadcrumb;
var init_navbar_component = __esm({
  "src/main/webapp/app/shared/layouts/navbar/navbar.component.ts"() {
    init_language_helper();
    init_guided_tour_service();
    init_app_constants();
    init_participation_websocket_service();
    init_account_service();
    init_profile_service();
    init_login_service();
    init_exam_participation_service();
    init_server_date_service();
    init_locale_conversion_service();
    init_course_management_service();
    init_exercise_service();
    init_apollon_diagram_service();
    init_lecture_service();
    init_exam_management_service();
    init_authority_constants();
    init_alert_service();
    init_language_constants();
    init_organization_management_service();
    init_exercise_hint_service();
    init_theme_service();
    init_entity_title_service();
    init_global_utils();
    init_login_service();
    init_language_helper();
    init_locale_conversion_service();
    init_account_service();
    init_profile_service();
    init_participation_websocket_service();
    init_guided_tour_service();
    init_exam_participation_service();
    init_server_date_service();
    init_alert_service();
    init_course_management_service();
    init_exercise_service();
    init_exercise_hint_service();
    init_apollon_diagram_service();
    init_lecture_service();
    init_exam_management_service();
    init_organization_management_service();
    init_theme_service();
    init_entity_title_service();
    init_translate_directive();
    init_has_any_authority_directive();
    init_connection_warning_component();
    init_guided_tour_component();
    init_theme_switch_component();
    init_active_menu_directive();
    init_notification_sidebar_component();
    init_system_notification_component();
    init_loading_notification_component();
    init_find_language_from_key_pipe();
    init_artemis_translate_pipe();
    _c05 = () => ({ exact: true });
    _c14 = () => ["/user-settings"];
    _c22 = (a0, a1) => ({ evenly: a0, "in-menu": a1 });
    _c32 = () => ["ROLE_TA", "ROLE_EDITOR", "ROLE_INSTRUCTOR", "ROLE_ADMIN"];
    NavbarComponent = class _NavbarComponent {
      loginService;
      translateService;
      languageHelper;
      localeConversionService;
      sessionStorage;
      accountService;
      profileService;
      participationWebsocketService;
      guidedTourService;
      router;
      route;
      examParticipationService;
      serverDateService;
      alertService;
      courseManagementService;
      exerciseService;
      exerciseHintService;
      apollonDiagramService;
      lectureService;
      examService;
      organisationService;
      themeService;
      entityTitleService;
      inProduction;
      testServer;
      isNavbarCollapsed;
      isTourAvailable;
      gitCommitId;
      gitBranchName;
      gitTimestamp;
      gitUsername;
      languages = LANGUAGES;
      openApiEnabled;
      modalRef;
      version;
      currAccount;
      isRegistrationEnabled = false;
      passwordResetEnabled = false;
      breadcrumbs;
      breadcrumbSubscriptions;
      isCollapsed;
      iconsMovedToMenu;
      isNavbarNavVertical;
      isExamActive = false;
      examActiveCheckFuture;
      irisEnabled;
      localCIActive = false;
      faBars = faBars;
      faThLarge = faThLarge;
      faThList = faThList;
      faUser = faUser;
      faBell = faBell2;
      faUniversity = faUniversity;
      faEye = faEye2;
      faCog = faCog2;
      faWrench = faWrench;
      faLock = faLock;
      faStamp = faStamp;
      faFlag = faFlag;
      faBook = faBook;
      faTasks = faTasks;
      faList = faList;
      faRobot = faRobot;
      faHeart = faHeart;
      faTachometerAlt = faTachometerAlt;
      faToggleOn = faToggleOn;
      faBookOpen = faBookOpen;
      faUserPlus = faUserPlus;
      faSignOutAlt = faSignOutAlt;
      faGears = faGears;
      authStateSubscription;
      routerEventSubscription;
      studentExam;
      examId;
      routeExamId = 0;
      lastRouteUrlSegment;
      constructor(loginService, translateService, languageHelper, localeConversionService, sessionStorage, accountService, profileService, participationWebsocketService, guidedTourService, router, route, examParticipationService, serverDateService, alertService, courseManagementService, exerciseService, exerciseHintService, apollonDiagramService, lectureService, examService, organisationService, themeService, entityTitleService) {
        this.loginService = loginService;
        this.translateService = translateService;
        this.languageHelper = languageHelper;
        this.localeConversionService = localeConversionService;
        this.sessionStorage = sessionStorage;
        this.accountService = accountService;
        this.profileService = profileService;
        this.participationWebsocketService = participationWebsocketService;
        this.guidedTourService = guidedTourService;
        this.router = router;
        this.route = route;
        this.examParticipationService = examParticipationService;
        this.serverDateService = serverDateService;
        this.alertService = alertService;
        this.courseManagementService = courseManagementService;
        this.exerciseService = exerciseService;
        this.exerciseHintService = exerciseHintService;
        this.apollonDiagramService = apollonDiagramService;
        this.lectureService = lectureService;
        this.examService = examService;
        this.organisationService = organisationService;
        this.themeService = themeService;
        this.entityTitleService = entityTitleService;
        this.version = VERSION ? VERSION : "";
        this.isNavbarCollapsed = true;
        this.subscribeToNavigationEventsForExamId();
        this.onResize();
      }
      onResize() {
        let neededWidthToNotRequireCollapse;
        let neededWidthToDisplayCollapsedOptionsHorizontally = 150;
        let neededWidthForIconOptionsToBeInMainNavBar;
        if (this.currAccount) {
          const nameLength = (this.currAccount.login?.length ?? 0) * 8;
          neededWidthForIconOptionsToBeInMainNavBar = 580 + nameLength;
          neededWidthToNotRequireCollapse = 700 + nameLength;
          const hasServerAdminOption = this.accountService.hasAnyAuthorityDirect([Authority.ADMIN]);
          const hasCourseManageOption = this.accountService.hasAnyAuthorityDirect([Authority.TA, Authority.INSTRUCTOR, Authority.EDITOR, Authority.ADMIN]);
          if (hasCourseManageOption) {
            neededWidthToNotRequireCollapse += 200;
            neededWidthToDisplayCollapsedOptionsHorizontally += 200;
          }
          if (hasServerAdminOption) {
            neededWidthToNotRequireCollapse += 225;
            neededWidthToDisplayCollapsedOptionsHorizontally += 225;
          }
        } else {
          neededWidthToNotRequireCollapse = 510;
          neededWidthForIconOptionsToBeInMainNavBar = 430;
        }
        this.isCollapsed = window.innerWidth < neededWidthToNotRequireCollapse;
        this.isNavbarNavVertical = window.innerWidth < Math.max(neededWidthToDisplayCollapsedOptionsHorizontally, 480);
        this.iconsMovedToMenu = window.innerWidth < neededWidthForIconOptionsToBeInMainNavBar;
      }
      ngOnInit() {
        this.profileService.getProfileInfo().subscribe((profileInfo) => {
          if (profileInfo) {
            this.inProduction = profileInfo.inProduction;
            this.testServer = profileInfo.testServer ?? false;
            this.openApiEnabled = profileInfo.openApiEnabled;
            this.gitCommitId = profileInfo.git.commit.id.abbrev;
            this.gitBranchName = profileInfo.git.branch;
            this.gitTimestamp = new Date(profileInfo.git.commit.time).toUTCString();
            this.gitUsername = profileInfo.git.commit.user.name;
            this.irisEnabled = profileInfo.activeProfiles.includes("iris");
            this.localCIActive = profileInfo?.activeProfiles.includes(PROFILE_LOCALCI);
          }
        });
        this.subscribeForGuidedTourAvailability();
        this.authStateSubscription = this.accountService.getAuthenticationState().pipe(tap2((user) => {
          this.currAccount = user;
          this.passwordResetEnabled = user?.internal || false;
          this.onResize();
        })).subscribe();
        this.examParticipationService.currentlyLoadedStudentExam.subscribe((studentExam) => {
          this.studentExam = studentExam;
          this.checkExamActive();
        });
        this.buildBreadcrumbs(this.router.url);
        this.router.events.pipe(filter2((event) => event instanceof NavigationEnd)).subscribe((event) => this.buildBreadcrumbs(event.url));
      }
      ngOnDestroy() {
        if (this.authStateSubscription) {
          this.authStateSubscription.unsubscribe();
        }
        if (this.routerEventSubscription) {
          this.routerEventSubscription.unsubscribe();
        }
        if (this.examActiveCheckFuture) {
          clearTimeout(this.examActiveCheckFuture);
        }
      }
      breadcrumbTranslation = {
        new: "global.generic.create",
        process: "artemisApp.attachmentUnit.createAttachmentUnits.pageTitle",
        verify_attendance: "artemisApp.examManagement.examStudents.verifyChecks",
        create: "global.generic.create",
        start: "global.generic.start",
        edit: "global.generic.edit",
        audits: "audits.title",
        configuration: "configuration.title",
        feature_toggles: "featureToggles.title",
        health: "health.title",
        logs: "logs.title",
        docs: "global.menu.admin.apidocs",
        metrics: "metrics.title",
        user_statistics: "statistics.title",
        user_management: "artemisApp.userManagement.home.title",
        system_notification_management: "artemisApp.systemNotification.systemNotifications",
        upcoming_exams_and_exercises: "artemisApp.upcomingExamsAndExercises.upcomingExamsAndExercises",
        account: "global.menu.account.main",
        activate: "activate.title",
        password: "global.menu.account.password",
        reset: "global.menu.account.password",
        register: "register.title",
        settings: "global.menu.account.settings",
        course_management: "global.menu.course",
        exercises: "artemisApp.course.exercises",
        text_exercises: "artemisApp.course.exercises",
        programming_exercises: "artemisApp.course.exercises",
        modeling_exercises: "artemisApp.course.exercises",
        file_upload_exercises: "artemisApp.course.exercises",
        quiz_exercises: "artemisApp.course.exercises",
        participations: "artemisApp.participation.home.title",
        submissions: "artemisApp.exercise.submissions",
        complaints: "artemisApp.complaint.listOfComplaints.title",
        more_feedback_requests: "artemisApp.moreFeedback.list.title",
        instructor_dashboard: "entity.action.instructorDashboard",
        assessment_dashboard: "artemisApp.assessmentDashboard.home.title",
        test_run_exercise_assessment_dashboard: "artemisApp.exerciseAssessmentDashboard.home.title",
        lti_configuration: "artemisApp.lti.home.title",
        teams: "artemisApp.team.home.title",
        exercise_hints: "artemisApp.exerciseHint.home.title",
        ratings: "artemisApp.ratingList.pageTitle",
        competency_management: "artemisApp.competency.manageCompetencies.title",
        learning_path_management: "artemisApp.learningPath.manageLearningPaths.title",
        assessment_locks: "artemisApp.assessment.locks.home.title",
        apollon_diagrams: "artemisApp.apollonDiagram.home.title",
        communication: "artemisApp.metis.communication.label",
        scores: "entity.action.scores",
        assessment: "artemisApp.assessment.assessment",
        export: "artemisApp.quizExercise.export.export",
        re_evaluate: "entity.action.re-evaluate",
        solution: "artemisApp.quizExercise.solution",
        preview: "artemisApp.quizExercise.previewMode",
        quiz_statistic: "artemisApp.quizExercise.statistics",
        quiz_point_statistic: "artemisApp.quizExercise.statistics",
        import: "artemisApp.exercise.import.table.doImport",
        import_from_file: "artemisApp.programmingExercise.importFromFile.title",
        plagiarism: "artemisApp.plagiarism.plagiarismDetection",
        example_solution: "artemisApp.modelingExercise.exampleSolution",
        example_submissions: "artemisApp.exampleSubmission.home.title",
        example_submission_editor: "artemisApp.exampleSubmission.home.editor",
        grading: "artemisApp.programmingExercise.configureGrading.shortTitle",
        test: "artemisApp.editor.home.title",
        ide: "artemisApp.editor.home.title",
        lectures: "artemisApp.lecture.home.title",
        attachments: "artemisApp.lecture.attachments.title",
        unit_management: "artemisApp.lectureUnit.home.title",
        exams: "artemisApp.examManagement.title",
        exercise_groups: "artemisApp.examManagement.exerciseGroups",
        quiz_pool: "artemisApp.examManagement.quizPool",
        students: "artemisApp.course.students",
        tutors: "artemisApp.course.tutors",
        instructors: "artemisApp.course.instructors",
        test_runs: "artemisApp.examManagement.testRun.testRun",
        assess: "artemisApp.examManagement.assessmentDashboard",
        summary: "artemisApp.exam.summary",
        conduction: "artemisApp.exam.title",
        student_exams: "artemisApp.studentExams.title",
        test_assessment_dashboard: "artemisApp.examManagement.assessmentDashboard",
        tutor_exam_dashboard: "artemisApp.examManagement.assessmentDashboard",
        organization_management: "artemisApp.organizationManagement.title",
        participant_scores: "artemisApp.participantScores.pageTitle",
        course_statistics: "statistics.course_statistics_title",
        grading_system: "artemisApp.gradingSystem.title",
        grading_key: "artemisApp.gradingSystem.title",
        exercise_statistics: "exercise-statistics.title",
        tutor_effort_statistics: "artemisApp.textExercise.tutorEffortStatistics.title",
        user_settings: "artemisApp.userSettings.title",
        detailed: "artemisApp.gradingSystem.detailedTab.title",
        interval: "artemisApp.gradingSystem.intervalTab.title",
        plagiarism_cases: "artemisApp.plagiarism.cases.pageTitle",
        code_hint_management: "artemisApp.codeHint.management.title",
        tutorial_groups_management: "artemisApp.pages.tutorialGroupsManagement.title",
        tutorial_groups: "artemisApp.breadcrumb.title",
        registered_students: "artemisApp.pages.registeredStudents.title",
        sessions: "artemisApp.pages.tutorialGroupSessionManagement.title",
        tutorial_free_days: "artemisApp.pages.tutorialFreePeriodsManagement.title",
        tutorial_groups_checklist: "artemisApp.pages.checklist.title",
        create_tutorial_groups_configuration: "artemisApp.pages.createTutorialGroupsConfiguration.title",
        privacy_statement: "artemisApp.legal.privacyStatement.title",
        imprint: "artemisApp.legal.imprint.title",
        edit_build_plan: "artemisApp.programmingExercise.buildPlanEditor",
        suspicious_behavior: "artemisApp.examManagement.suspiciousBehavior.title",
        suspicious_sessions: "artemisApp.examManagement.suspiciousBehavior.suspiciousSessions.title",
        exam_timeline: "artemisApp.examTimeline.breadcrumb",
        iris_settings: "artemisApp.iris.settings.title.breadcrumb",
        build_queue: "artemisApp.buildQueue.title"
      };
      studentPathBreadcrumbTranslations = {
        exams: "artemisApp.courseOverview.menu.exams",
        test_exam: "artemisApp.courseOverview.menu.testExam",
        exercises: "artemisApp.courseOverview.menu.exercises",
        lectures: "artemisApp.courseOverview.menu.lectures",
        competencies: "artemisApp.courseOverview.menu.competencies",
        learning_path: "artemisApp.courseOverview.menu.learningPath",
        lecture_unit: "artemisApp.learningPath.breadcrumbs.lectureUnit",
        exercise: "artemisApp.learningPath.breadcrumbs.exercise",
        statistics: "artemisApp.courseOverview.menu.statistics",
        discussion: "artemisApp.metis.communication.label",
        messages: "artemisApp.conversationsLayout.breadCrumbLabel",
        code_editor: "artemisApp.editor.breadCrumbTitle",
        participate: "artemisApp.submission.detail.title",
        live: "artemisApp.submission.detail.title",
        courses: "artemisApp.course.home.title",
        enroll: "artemisApp.studentDashboard.enroll.title"
      };
      buildBreadcrumbs(fullURI) {
        this.breadcrumbs = [];
        this.breadcrumbSubscriptions?.forEach((subscription) => subscription.unsubscribe());
        this.breadcrumbSubscriptions = [];
        if (!fullURI) {
          return;
        }
        if (!fullURI.startsWith("/admin") && !fullURI.startsWith("/course-management") && !fullURI.startsWith("/courses")) {
          return;
        }
        try {
          let currentPath = "/";
          let uri = fullURI.substring(1);
          const questionMark = uri.indexOf("?");
          if (questionMark >= 0) {
            uri = uri.substring(0, questionMark);
          }
          for (const segment of uri.split("/")) {
            currentPath += segment + "/";
            if (!isNaN(Number(segment))) {
              this.addBreadcrumbForNumberSegment(currentPath, segment);
            } else {
              this.addBreadcrumbForUrlSegment(currentPath, segment);
              this.lastRouteUrlSegment = segment;
            }
          }
        } catch (e) {
        }
      }
      addBreadcrumbForNumberSegment(currentPath, segment) {
        const isStudentPath = currentPath.startsWith("/courses");
        if (isStudentPath) {
          switch (this.lastRouteUrlSegment) {
            case "code-editor":
            case "test-exam":
            case "participate":
              this.addTranslationAsCrumb(currentPath, this.lastRouteUrlSegment);
              return;
            case "exercises":
              this.addResolvedTitleAsCrumb(EntityType.EXERCISE, [Number(segment)], currentPath, segment);
              return;
            default:
              const exercisesMatcher = this.lastRouteUrlSegment?.match(/.+-exercises/);
              if (exercisesMatcher) {
                this.addResolvedTitleAsCrumb(EntityType.EXERCISE, [Number(segment)], currentPath.replace(exercisesMatcher[0], "exercises"), "exercises");
                return;
              }
              break;
          }
        }
        switch (this.lastRouteUrlSegment) {
          case "system-notification-management":
          case "teams":
          case "code-editor":
            this.addBreadcrumb(currentPath, segment, false);
            break;
          case "course-management":
          case "courses":
            this.addResolvedTitleAsCrumb(EntityType.COURSE, [Number(segment)], currentPath, segment);
            break;
          case "exercises":
            this.addExerciseCrumb(Number(segment), currentPath);
            break;
          case "text-exercises":
          case "modeling-exercises":
          case "file-upload-exercises":
          case "programming-exercises":
          case "quiz-exercises":
          case "assessment-dashboard":
            this.addResolvedTitleAsCrumb(EntityType.EXERCISE, [Number(segment)], currentPath, segment);
            break;
          case "exercise-hints":
            const exerciseId = currentPath.split("/")[4];
            this.addResolvedTitleAsCrumb(EntityType.HINT, [Number(segment), Number(exerciseId)], currentPath, segment);
            break;
          case "apollon-diagrams":
            this.addResolvedTitleAsCrumb(EntityType.DIAGRAM, [Number(segment)], currentPath, segment);
            break;
          case "lectures":
            this.addResolvedTitleAsCrumb(EntityType.LECTURE, [Number(segment)], currentPath, segment);
            break;
          case "competencies":
            this.addResolvedTitleAsCrumb(EntityType.COMPETENCY, [Number(segment)], currentPath, segment);
            break;
          case "exams":
            this.routeExamId = Number(segment);
            this.addResolvedTitleAsCrumb(EntityType.EXAM, [this.routeExamId], currentPath, segment);
            break;
          case "organization-management":
            this.addResolvedTitleAsCrumb(EntityType.ORGANIZATION, [Number(segment)], currentPath, segment);
            break;
          case "tutorial-groups":
            this.addResolvedTitleAsCrumb(EntityType.TUTORIAL_GROUP, [Number(segment)], currentPath, segment);
            break;
          case "import":
            this.addTranslationAsCrumb(currentPath, "import");
            break;
          case "import-from-file":
            this.addTranslationAsCrumb(currentPath, "import-from-file");
            break;
          case "suspicious-behavior":
            this.addTranslationAsCrumb(currentPath, "suspicious-behavior");
            break;
          case "suspicious-sessions":
            this.addTranslationAsCrumb(currentPath, "suspicious-sessions");
            break;
          case "example-submissions":
            this.addTranslationAsCrumb(currentPath, "example-submission-editor");
            break;
          case "competency-management":
          case "unit-management":
          case "exercise-groups":
          case "student-exams":
          case "test-runs":
          case "mc-question-statistic":
          case "dnd-question-statistic":
          case "sa-question-statistic":
          default:
            break;
        }
      }
      addBreadcrumbForUrlSegment(currentPath, segment) {
        const isStudentPath = currentPath.startsWith("/courses");
        if (isStudentPath) {
          const exercisesMatcher = segment?.match(/.+-exercises/);
          if (exercisesMatcher) {
            this.addTranslationAsCrumb(currentPath.replace(exercisesMatcher[0], "exercises"), "exercises");
            return;
          }
        }
        switch (segment) {
          case "reset":
          case "groups":
          case "code-editor":
          case "admin":
          case "ide":
          case "text-units":
          case "exercise-units":
          case "attachment-units":
          case "video-units":
          case "grading":
          case "mc-question-statistic":
          case "dnd-question-statistic":
          case "sa-question-statistic":
          case "test-exam":
          case "participate":
          case "overview":
            break;
          case "example-submissions":
            if (this.accountService.hasAnyAuthorityDirect([Authority.ADMIN, Authority.INSTRUCTOR, Authority.EDITOR])) {
              this.addTranslationAsCrumb(currentPath, segment);
            }
            break;
          case "submissions":
            const updatedLink = currentPath.replace("/submissions/", "/scores/");
            this.addTranslationAsCrumb(updatedLink, "submissions");
            break;
          default:
            if (this.lastRouteUrlSegment === "user-management") {
              this.addBreadcrumb(currentPath, segment, false);
              break;
            } else if (this.lastRouteUrlSegment === "example-submissions") {
              this.addTranslationAsCrumb(currentPath, "example-submission-editor");
              break;
            } else if (this.lastRouteUrlSegment === "grading") {
              this.addTranslationAsCrumb(currentPath, "grading");
              break;
            } else if (this.lastRouteUrlSegment === "code-editor" && segment === "new") {
              break;
            } else if (this.lastRouteUrlSegment?.endsWith("-exercises") && segment === "import") {
              break;
            } else if (this.lastRouteUrlSegment === "exercise-groups") {
              break;
            } else if (this.lastRouteUrlSegment === "exams" && segment === "import") {
              break;
            }
            this.addTranslationAsCrumb(currentPath, segment);
            break;
        }
      }
      addBreadcrumb(uri, label, translate) {
        return this.setBreadcrumb(uri, label, translate, this.breadcrumbs.length);
      }
      setBreadcrumb(uri, label, translate, index) {
        const crumb = new Breadcrumb();
        crumb.label = label;
        crumb.translate = translate;
        crumb.uri = uri;
        this.breadcrumbs[index] = crumb;
        return crumb;
      }
      addResolvedTitleAsCrumb(type, ids, uri, segment) {
        let crumb = this.addBreadcrumb(uri, segment, false);
        this.breadcrumbSubscriptions.push(this.entityTitleService.getTitle(type, ids).subscribe({
          next: (title) => {
            crumb = this.setBreadcrumb(uri, title, false, this.breadcrumbs.indexOf(crumb));
          }
        }));
      }
      addExerciseCrumb(exerciseId, currentPath) {
        const crumb = this.addBreadcrumb("", "", false);
        this.exerciseService.find(exerciseId).subscribe({
          next: (response) => {
            if (!response?.body?.title || !response?.body?.type) {
              this.breadcrumbs.splice(this.breadcrumbs.indexOf(crumb), 1);
            } else {
              this.setBreadcrumb(currentPath.replace("/exercises/", `/${response.body.type}-exercises/`), response.body.title, false, this.breadcrumbs.indexOf(crumb));
            }
          },
          error: () => this.breadcrumbs.splice(this.breadcrumbs.indexOf(crumb), 1)
        });
      }
      addTranslationAsCrumb(uri, translationKey) {
        const key = translationKey.split("-").join("_");
        if (uri.startsWith("/courses") && this.studentPathBreadcrumbTranslations[key]) {
          this.addBreadcrumb(uri, this.studentPathBreadcrumbTranslations[key], true);
        } else if (this.breadcrumbTranslation[key]) {
          this.addBreadcrumb(uri, this.breadcrumbTranslation[key], true);
        } else {
          this.addBreadcrumb(uri, translationKey, false);
        }
      }
      subscribeForGuidedTourAvailability() {
        this.guidedTourService.getGuidedTourAvailabilityStream().subscribe((isAvailable) => {
          this.isTourAvailable = isAvailable;
        });
      }
      changeLanguage(languageKey) {
        if (this.currAccount) {
          this.accountService.updateLanguage(languageKey).subscribe({
            next: () => {
              this.translateService.use(languageKey);
            },
            error: (error) => onError(this.alertService, error)
          });
        } else {
          this.translateService.use(languageKey);
        }
      }
      collapseNavbar() {
        this.isNavbarCollapsed = true;
      }
      isAuthenticated() {
        return this.accountService.isAuthenticated();
      }
      logout() {
        this.collapseNavbar();
        this.router.navigate(["/"]).then((res) => {
          if (res) {
            this.participationWebsocketService.resetLocalCache();
            this.loginService.logout(true);
          }
        });
      }
      toggleNavbar() {
        this.isNavbarCollapsed = !this.isNavbarCollapsed;
      }
      getImageUrl() {
        return this.accountService.getImageUrl();
      }
      guidedTourInitLabel() {
        switch (this.guidedTourService.getLastSeenTourStepForInit()) {
          case -1: {
            return "global.menu.restartTutorial";
          }
          case 0: {
            return "global.menu.startTutorial";
          }
          default: {
            return "global.menu.continueTutorial";
          }
        }
      }
      subscribeToNavigationEventsForExamId() {
        this.routerEventSubscription = this.router.events.pipe(filter2((event) => event instanceof NavigationEnd)).subscribe((event) => {
          if (event.url.includes("management")) {
            this.examId = void 0;
            return;
          }
          this.route.root.firstChild?.paramMap.pipe(map((params) => params.get("examId"))).subscribe((examId) => {
            this.examId = examId ? Number(examId) : void 0;
            this.checkExamActive();
          });
        });
      }
      checkExamActive() {
        if (this.examActiveCheckFuture) {
          clearTimeout(this.examActiveCheckFuture);
          this.examActiveCheckFuture = void 0;
        }
        if (this.studentExam?.exam && this.studentExam.exam.id === this.examId && !this.studentExam.exam.testExam && !this.studentExam.testRun && this.studentExam.exam.startDate && this.studentExam.exam.endDate && !this.studentExam.submitted) {
          const serverTime = this.serverDateService.now();
          const workingTime = this.studentExam.workingTime ?? this.studentExam.exam.workingTime;
          const examEndWithGracePeriod = (workingTime ? this.studentExam.exam.startDate.add(workingTime, "seconds") : this.studentExam.exam.endDate).add(this.studentExam.exam.gracePeriod ?? 0, "seconds");
          this.isExamActive = serverTime.isBetween(this.studentExam.exam.startDate, examEndWithGracePeriod);
          const timeUntilStart = this.studentExam.exam.startDate.diff(serverTime);
          const timeUntilEnd = examEndWithGracePeriod.diff(serverTime);
          const timeUntilNextChange = timeUntilStart >= 0 ? timeUntilStart : timeUntilEnd;
          if (timeUntilNextChange > 0) {
            this.examActiveCheckFuture = setTimeout(this.checkExamActive.bind(this), timeUntilNextChange + 100);
          }
        } else {
          this.isExamActive = false;
        }
      }
      static \u0275fac = function NavbarComponent_Factory(t) {
        return new (t || _NavbarComponent)(i08.\u0275\u0275directiveInject(LoginService), i08.\u0275\u0275directiveInject(i22.TranslateService), i08.\u0275\u0275directiveInject(JhiLanguageHelper), i08.\u0275\u0275directiveInject(LocaleConversionService), i08.\u0275\u0275directiveInject(i52.SessionStorageService), i08.\u0275\u0275directiveInject(AccountService), i08.\u0275\u0275directiveInject(ProfileService), i08.\u0275\u0275directiveInject(ParticipationWebsocketService), i08.\u0275\u0275directiveInject(GuidedTourService), i08.\u0275\u0275directiveInject(i102.Router), i08.\u0275\u0275directiveInject(i102.ActivatedRoute), i08.\u0275\u0275directiveInject(ExamParticipationService), i08.\u0275\u0275directiveInject(ArtemisServerDateService), i08.\u0275\u0275directiveInject(AlertService), i08.\u0275\u0275directiveInject(CourseManagementService), i08.\u0275\u0275directiveInject(ExerciseService), i08.\u0275\u0275directiveInject(ExerciseHintService), i08.\u0275\u0275directiveInject(ApollonDiagramService), i08.\u0275\u0275directiveInject(LectureService), i08.\u0275\u0275directiveInject(ExamManagementService), i08.\u0275\u0275directiveInject(OrganizationManagementService), i08.\u0275\u0275directiveInject(ThemeService), i08.\u0275\u0275directiveInject(EntityTitleService));
      };
      static \u0275cmp = i08.\u0275\u0275defineComponent({ type: _NavbarComponent, selectors: [["jhi-navbar"]], hostBindings: function NavbarComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          i08.\u0275\u0275listener("resize", function NavbarComponent_resize_HostBindingHandler() {
            return ctx.onResize();
          }, false, i08.\u0275\u0275resolveWindow);
        }
      }, decls: 60, vars: 18, consts: [["iconMenu", ""], [1, "navbar", "jh-navbar"], [1, "jh-logo-container"], ["routerLink", "/", 1, "navbar-brand", 3, "click"], ["height", "30", "alt", "", 3, "src"], ["jhiTranslate", "global.title", 1, "navbar-title"], ["gitInfo", ""], ["placement", "bottom", "tooltipClass", "git-info", 1, "navbar-version", 3, "ngbTooltip", "disableTooltip"], [1, "indicators"], [1, "align-self-center"], [1, "toggler-wrapper"], ["data-toggle", "collapse", "data-target", "#navbarResponsive", "aria-controls", "navbarResponsive", "aria-expanded", "false", "aria-label", "Toggle navigation", 1, "toggler", 3, "click"], [3, "icon"], ["id", "navbarResponsive", 1, "navbar-collapse", "collapse", 3, "ngbCollapse"], [1, "navbar-nav", "ms-auto"], ["ngbDropdown", "", "class", "nav-item dropdown pointer", "routerLinkActive", "active", 3, "routerLinkActiveOptions", 4, "jhiHasAnyAuthority"], ["ngbDropdown", "", "class", "nav-item dropdown pointer", "display", "dynamic", "routerLinkActive", "active", 3, "routerLinkActiveOptions", 4, "jhiHasAnyAuthority"], [1, "breadcrumb-container"], ["id", "navbar-icon-menu", 3, "ngClass"], [3, "popoverPlacement"], ["ngbDropdown", "", "display", "dynamic", "routerLinkActive", "active", 1, "dropdown", "pointer", 3, "placement", "routerLinkActiveOptions", "autoClose"], ["ngbDropdownToggle", "", "id", "account-menu", 1, "guided-tour-account", "nav-link", "dropdown-toggle"], ["ngbDropdownMenu", "", 1, "dropdown-menu", "dropdown-menu-index"], [1, "dropdown-item", 3, "routerLink", "click"], [3, "icon", "fixedWidth"], [1, "dropdown-divider"], ["jhiTranslate", "global.menu.language", 1, "dropdown-header", "fw-medium"], ["jhiTranslate", "global.menu.account.main"], ["alt", "Avatar", 1, "profile-image", "img-circle", 3, "src"], [1, "dropdown-item", 3, "jhiActiveMenu", "click"], ["jhiTranslate", "global.menu.guidedTutorial", 1, "dropdown-header", "fw-medium"], [1, "dropdown-item", "guided-tour", 3, "jhiTranslate", "click"], ["routerLink", "/account/settings", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.account.settings"], ["routerLink", "/account/password", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.account.password"], ["id", "logout", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.account.logout"], [4, "ngTemplateOutlet"], ["routerLinkActive", "active", 1, "nav-item", 3, "routerLinkActiveOptions"], ["routerLink", "/courses", "id", "overview-menu", 1, "guided-tour-overview", "nav-link", 3, "click"], ["jhiTranslate", "global.menu.overview"], ["ngbDropdown", "", "routerLinkActive", "active", 1, "nav-item", "dropdown", "pointer", 3, "routerLinkActiveOptions"], ["routerLink", "/course-management", "id", "course-admin-menu", 1, "guided-tour-course-admin", "nav-link", 3, "click"], ["jhiTranslate", "global.menu.course"], ["ngbDropdown", "", "display", "dynamic", "routerLinkActive", "active", 1, "nav-item", "dropdown", "pointer", 3, "routerLinkActiveOptions"], ["routerLink", "/admin/upcoming-exams-and-exercises", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.upcomingExamsAndExercises"], ["routerLink", "/admin/user-management", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.userManagement"], ["routerLink", "/admin/organization-management", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.organizationManagement"], ["routerLink", "/admin/system-notification-management", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.systemNotifications"], ["routerLink", "/admin/feature-toggles", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.featureToggles"], ["routerLink", "/admin/user-statistics", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.statistics"], ["routerLink", "/admin/metrics", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.metrics"], ["routerLink", "/admin/privacy-statement", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.privacyStatement"], ["routerLink", "/admin/imprint", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.imprint"], ["routerLink", "/admin/health", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.health"], ["routerLink", "/admin/configuration", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.configuration"], ["routerLink", "/admin/audits", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.audits"], ["routerLink", "/admin/logs", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.logs"], ["ngbDropdownToggle", "", "id", "admin-menu", 1, "guided-tour-admin", "nav-link", "dropdown-toggle"], ["jhiTranslate", "global.menu.admin.main"], ["routerLink", "/admin/build-queue", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "artemisApp.buildQueue.title"], ["href", "api.html", "target", "_blank", "rel", "noreferrer noopener", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.apidocs"], ["routerLink", "/admin/iris", "routerLinkActive", "active", 1, "dropdown-item", 3, "click"], ["jhiTranslate", "global.menu.admin.iris"], ["ngbDropdown", "", "display", "dynamic", 1, "nav-item", "dropdown", "pointer"], ["ngbDropdownToggle", "", "id", "languagesnavBarDropdown", 1, "nav-link", "dropdown-toggle"], ["jhiTranslate", "global.menu.language"], ["ngbDropdownMenu", "", 1, "dropdown-menu"], [1, "breadcrumb"], [1, "breadcrumb-item"], ["routerLinkActive", "active", 1, "breadcrumb-link", 3, "id", "routerLink", "routerLinkActiveOptions"]], template: function NavbarComponent_Template(rf, ctx) {
        if (rf & 1) {
          i08.\u0275\u0275template(0, NavbarComponent_ng_template_0_Template, 8, 7, "ng-template", null, 0, i08.\u0275\u0275templateRefExtractor);
          i08.\u0275\u0275text(2, "\n");
          i08.\u0275\u0275elementStart(3, "nav", 1);
          i08.\u0275\u0275text(4, "\n    ");
          i08.\u0275\u0275elementStart(5, "div", 2);
          i08.\u0275\u0275text(6, "\n        ");
          i08.\u0275\u0275elementStart(7, "a", 3);
          i08.\u0275\u0275listener("click", function NavbarComponent_Template_a_click_7_listener() {
            return ctx.collapseNavbar();
          });
          i08.\u0275\u0275text(8, "\n            ");
          i08.\u0275\u0275element(9, "img", 4);
          i08.\u0275\u0275text(10, "\n            ");
          i08.\u0275\u0275elementStart(11, "div", 5);
          i08.\u0275\u0275text(12, "Artemis");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(13, "\n            ");
          i08.\u0275\u0275template(14, NavbarComponent_ng_template_14_Template, 14, 16, "ng-template", null, 6, i08.\u0275\u0275templateRefExtractor);
          i08.\u0275\u0275text(16, "\n            ");
          i08.\u0275\u0275elementStart(17, "div", 7);
          i08.\u0275\u0275text(18);
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(19, "\n        ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(20, "\n        ");
          i08.\u0275\u0275elementStart(21, "div", 8);
          i08.\u0275\u0275text(22, "\n            ");
          i08.\u0275\u0275element(23, "jhi-connection-warning", 9);
          i08.\u0275\u0275text(24, "\n            ");
          i08.\u0275\u0275element(25, "jhi-loading-notification", 9);
          i08.\u0275\u0275text(26, "\n        ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(27, "\n        ");
          i08.\u0275\u0275template(28, NavbarComponent_Conditional_28_Template, 3, 1);
          i08.\u0275\u0275elementStart(29, "div", 10);
          i08.\u0275\u0275text(30, "\n            ");
          i08.\u0275\u0275elementStart(31, "a", 11);
          i08.\u0275\u0275listener("click", function NavbarComponent_Template_a_click_31_listener() {
            return ctx.toggleNavbar();
          });
          i08.\u0275\u0275text(32, "\n                ");
          i08.\u0275\u0275element(33, "fa-icon", 12);
          i08.\u0275\u0275text(34, "\n            ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(35, "\n        ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(36, "\n    ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(37, "\n    ");
          i08.\u0275\u0275elementStart(38, "div", 13);
          i08.\u0275\u0275text(39, "\n        ");
          i08.\u0275\u0275elementStart(40, "ul", 14);
          i08.\u0275\u0275text(41, "\n            ");
          i08.\u0275\u0275template(42, NavbarComponent_Conditional_42_Template, 15, 3)(43, NavbarComponent_li_43_Template, 3, 3, "li", 15);
          i08.\u0275\u0275text(44, "\n            ");
          i08.\u0275\u0275template(45, NavbarComponent_li_45_Template, 153, 32, "li", 16);
          i08.\u0275\u0275text(46, "\n            ");
          i08.\u0275\u0275template(47, NavbarComponent_Conditional_47_Template, 20, 1);
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(48, "\n        ");
          i08.\u0275\u0275template(49, NavbarComponent_Conditional_49_Template, 3, 1);
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(50, "\n");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(51, "\n");
          i08.\u0275\u0275element(52, "jhi-system-notification");
          i08.\u0275\u0275text(53, "\n");
          i08.\u0275\u0275elementStart(54, "div", 17);
          i08.\u0275\u0275text(55, "\n    ");
          i08.\u0275\u0275template(56, NavbarComponent_Conditional_56_Template, 9, 0);
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(57, "\n");
          i08.\u0275\u0275element(58, "jhi-guided-tour");
          i08.\u0275\u0275text(59, "\n");
        }
        if (rf & 2) {
          const _r3 = i08.\u0275\u0275reference(15);
          i08.\u0275\u0275advance(3);
          i08.\u0275\u0275classProp("expanded", !ctx.isCollapsed);
          i08.\u0275\u0275advance(6);
          i08.\u0275\u0275property("src", "public/images/logo.png", i08.\u0275\u0275sanitizeUrl);
          i08.\u0275\u0275advance(8);
          i08.\u0275\u0275property("ngbTooltip", _r3)("disableTooltip", ctx.inProduction && !ctx.testServer);
          i08.\u0275\u0275advance(1);
          i08.\u0275\u0275textInterpolate1("\n                ", ctx.version, "\n            ");
          i08.\u0275\u0275advance(10);
          i08.\u0275\u0275conditional(28, !ctx.iconsMovedToMenu && ctx.isCollapsed ? 28 : -1);
          i08.\u0275\u0275advance(5);
          i08.\u0275\u0275property("icon", ctx.faBars);
          i08.\u0275\u0275advance(5);
          i08.\u0275\u0275property("ngbCollapse", ctx.isNavbarCollapsed);
          i08.\u0275\u0275advance(2);
          i08.\u0275\u0275classProp("vertical", ctx.isNavbarNavVertical);
          i08.\u0275\u0275advance(2);
          i08.\u0275\u0275conditional(42, ctx.currAccount && !ctx.isExamActive ? 42 : -1);
          i08.\u0275\u0275advance(1);
          i08.\u0275\u0275property("jhiHasAnyAuthority", i08.\u0275\u0275pureFunction0(17, _c32));
          i08.\u0275\u0275advance(2);
          i08.\u0275\u0275property("jhiHasAnyAuthority", "ROLE_ADMIN");
          i08.\u0275\u0275advance(2);
          i08.\u0275\u0275conditional(47, !ctx.currAccount && ctx.languages && ctx.languages.length > 1 ? 47 : -1);
          i08.\u0275\u0275advance(2);
          i08.\u0275\u0275conditional(49, !ctx.isCollapsed || ctx.iconsMovedToMenu ? 49 : -1);
          i08.\u0275\u0275advance(7);
          i08.\u0275\u0275conditional(56, !ctx.isExamActive && ctx.breadcrumbs && ctx.breadcrumbs.length > 0 ? 56 : -1);
        }
      }, dependencies: [i23.NgClass, i23.NgTemplateOutlet, i24.NgbCollapse, i24.NgbDropdown, i24.NgbDropdownToggle, i24.NgbDropdownMenu, i24.NgbTooltip, i25.FaIconComponent, TranslateDirective, HasAnyAuthorityDirective, JhiConnectionWarningComponent, i102.RouterLink, i102.RouterLinkActive, GuidedTourComponent, ThemeSwitchComponent, ActiveMenuDirective, NotificationSidebarComponent, SystemNotificationComponent, LoadingNotificationComponent, FindLanguageFromKeyPipe, ArtemisTranslatePipe], styles: ['\n\na[_ngcontent-%COMP%]:not(.btn):hover {\n  text-decoration: none !important;\n}\n#navbar-icon-menu[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: row;\n  gap: 30px;\n  justify-content: flex-end;\n  color: var(--navbar-dark-color);\n  align-items: center;\n  transition: color 0.2s;\n  padding: 0 10px 0 20px;\n}\n#navbar-icon-menu[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%]:hover {\n  color: var(--bs-body-color);\n}\n#navbar-icon-menu.evenly[_ngcontent-%COMP%] {\n  justify-content: space-evenly;\n  gap: 5px;\n  padding-left: 10px;\n  padding-right: 10px;\n}\n#navbar-icon-menu.in-menu[_ngcontent-%COMP%] {\n  padding-top: 5px;\n  padding-bottom: 5px;\n}\n#account-menu[_ngcontent-%COMP%] {\n  padding: 0;\n}\n.jh-navbar[_ngcontent-%COMP%] {\n  background-color: var(--artemis-dark);\n  white-space: nowrap;\n  padding: 0.2em 1rem;\n  color: var(--navbar-dark-color);\n}\n.jh-navbar[_ngcontent-%COMP%]   .profile-image[_ngcontent-%COMP%] {\n  margin: -10px 0px;\n  height: 40px;\n  width: 40px;\n  border-radius: 50%;\n}\n.jh-navbar[_ngcontent-%COMP%]   .dropdown-item.active[_ngcontent-%COMP%], .jh-navbar[_ngcontent-%COMP%]   .dropdown-item.active[_ngcontent-%COMP%]:focus, .jh-navbar[_ngcontent-%COMP%]   .dropdown-item.active[_ngcontent-%COMP%]:hover {\n  background-color: var(--navbar-bg);\n}\n.jh-navbar[_ngcontent-%COMP%]   .dropdown-toggle[_ngcontent-%COMP%]::after {\n  margin-left: 0.15em;\n}\n.jh-navbar[_ngcontent-%COMP%]   ul.navbar-nav[_ngcontent-%COMP%] {\n  flex-direction: row;\n  padding-right: 10px;\n}\n.jh-navbar[_ngcontent-%COMP%]   ul.navbar-nav[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%] {\n  margin-left: 1.5rem;\n}\n.jh-navbar[_ngcontent-%COMP%]   ul.navbar-nav.vertical[_ngcontent-%COMP%] {\n  flex-direction: column;\n}\n@media screen and (min-width: 480px) {\n  .jh-navbar[_ngcontent-%COMP%]   ul.navbar-nav[_ngcontent-%COMP%]:not(.vertical) {\n    justify-content: flex-end;\n  }\n  .jh-navbar[_ngcontent-%COMP%]   ul.navbar-nav[_ngcontent-%COMP%]:not(.vertical)   .nav-item[_ngcontent-%COMP%]:first-child {\n    margin-left: 0;\n  }\n}\n.jh-navbar[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n  color: var(--navbar-dark-color);\n}\n.jh-navbar[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%]:hover {\n  color: var(--link-color);\n}\n.jh-navbar[_ngcontent-%COMP%]   a.nav-link[_ngcontent-%COMP%] {\n  font-weight: 400;\n}\n.jh-navbar[_ngcontent-%COMP%]   .jh-logo-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex: 1;\n  align-items: center;\n  flex-wrap: nowrap;\n  gap: 10px;\n  height: 50px;\n}\n.jh-navbar[_ngcontent-%COMP%]   .jh-logo-container[_ngcontent-%COMP%]   .navbar-brand[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  padding: 10px 15px;\n  align-items: center;\n  margin-right: 0;\n  height: 100%;\n}\n.jh-navbar[_ngcontent-%COMP%]   .jh-logo-container[_ngcontent-%COMP%]   .navbar-brand[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  height: 30px;\n  vertical-align: middle;\n  margin-right: 10px;\n}\n.jh-navbar[_ngcontent-%COMP%]   .jh-logo-container[_ngcontent-%COMP%]   .navbar-brand[_ngcontent-%COMP%]   .navbar-version[_ngcontent-%COMP%] {\n  padding-top: 3px;\n  font-size: 10px;\n  font-weight: 700;\n  color: var(--navbar-foreground);\n}\n.jh-navbar[_ngcontent-%COMP%]   .jh-logo-container[_ngcontent-%COMP%]   .navbar-brand[_ngcontent-%COMP%]   .navbar-title[_ngcontent-%COMP%] {\n  font-weight: 700;\n}\n.jh-navbar[_ngcontent-%COMP%]   .jh-logo-container[_ngcontent-%COMP%]   .navbar-brand[_ngcontent-%COMP%]:hover {\n  color: var(--navbar-foreground);\n}\n.jh-navbar[_ngcontent-%COMP%]   .jh-logo-container[_ngcontent-%COMP%]   .indicators[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  flex-wrap: nowrap;\n  font-size: 18px;\n  height: 50px;\n  gap: 10px;\n  justify-content: flex-start;\n  flex: 1;\n}\n.jh-navbar[_ngcontent-%COMP%]   .jh-logo-container[_ngcontent-%COMP%]   .toggler-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: flex-end;\n  align-items: center;\n}\n.jh-navbar[_ngcontent-%COMP%]   .jh-logo-container[_ngcontent-%COMP%]   .toggler-wrapper[_ngcontent-%COMP%]   .toggler[_ngcontent-%COMP%] {\n  color: var(--navbar-foreground);\n  font-size: 1.5em;\n  padding: 10px;\n}\n.jh-navbar[_ngcontent-%COMP%]   .jh-logo-container[_ngcontent-%COMP%]   .toggler-wrapper[_ngcontent-%COMP%]   .toggler[_ngcontent-%COMP%]:hover {\n  color: var(--navbar-foreground);\n}\n.jh-navbar.expanded[_ngcontent-%COMP%] {\n  flex-direction: row;\n  flex-wrap: nowrap;\n  justify-content: flex-start;\n}\n.jh-navbar.expanded[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%] {\n  flex-direction: row;\n}\n.jh-navbar.expanded[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n  padding-right: 0.5rem;\n  padding-left: 0.5rem;\n}\n.jh-navbar.expanded[_ngcontent-%COMP%]   .navbar-collapse[_ngcontent-%COMP%] {\n  display: flex !important;\n}\n.jh-navbar.expanded[_ngcontent-%COMP%]   .jh-logo-container[_ngcontent-%COMP%]   .toggler-wrapper[_ngcontent-%COMP%] {\n  display: none;\n}\n.dropdown-menu-index[_ngcontent-%COMP%] {\n  z-index: 2000;\n}\n.breadcrumb-container[_ngcontent-%COMP%] {\n  background-color: var(--navbar-breadcrumb-background);\n  overflow: auto;\n  margin-left: -15px;\n  min-height: 0.5rem;\n}\n.breadcrumb-container[_ngcontent-%COMP%]   .breadcrumb[_ngcontent-%COMP%] {\n  color: var(--navbar-breadcrumb-color);\n  background-color: var(--navbar-breadcrumb-background);\n  margin-left: 1rem;\n  margin-bottom: 0;\n  padding: 5px 16px 5px 16px;\n}\n.breadcrumb-container[_ngcontent-%COMP%]   .breadcrumb[_ngcontent-%COMP%]   .breadcrumb-link[_ngcontent-%COMP%] {\n  font-weight: 300;\n  display: inline;\n}\n.breadcrumb-container[_ngcontent-%COMP%]   .breadcrumb-item[_ngcontent-%COMP%]:not(:first-of-type)::before {\n  content: ">";\n}\n@media not all and (min-resolution: 0.001dpcm) {\n  @supports (-webkit-appearance: none) {\n    .breadcrumb-item[_ngcontent-%COMP%]:first-of-type   .breadcrumb-link[_ngcontent-%COMP%] {\n      display: block !important;\n    }\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbGF5b3V0cy9uYXZiYXIvbmF2YmFyLnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIkBpbXBvcnQgJ3NyYy9tYWluL3dlYmFwcC9jb250ZW50L3Njc3MvYXJ0ZW1pcy12YXJpYWJsZXMnO1xuXG4vKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuTmF2YmFyXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL1xuLyogRG9uJ3QgdW5kZXJsaW5lIHRoZSBtZW51IGl0ZW1zIG9uIGhvdmVyICovXG5hOm5vdCguYnRuKTpob3ZlciB7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lICFpbXBvcnRhbnQ7XG59XG5cbiNuYXZiYXItaWNvbi1tZW51IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgZ2FwOiAzMHB4O1xuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gICAgY29sb3I6IHZhcigtLW5hdmJhci1kYXJrLWNvbG9yKTtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIHRyYW5zaXRpb246IGNvbG9yIDAuMnM7XG4gICAgcGFkZGluZzogMCAxMHB4IDAgMjBweDtcblxuICAgID4gKjpob3ZlciB7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1icy1ib2R5LWNvbG9yKTtcbiAgICB9XG5cbiAgICAmLmV2ZW5seSB7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICAgICAgICBnYXA6IDVweDtcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgICAgICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xuICAgIH1cblxuICAgICYuaW4tbWVudSB7XG4gICAgICAgIHBhZGRpbmctdG9wOiA1cHg7XG4gICAgICAgIHBhZGRpbmctYm90dG9tOiA1cHg7XG4gICAgfVxufVxuXG4jYWNjb3VudC1tZW51IHtcbiAgICBwYWRkaW5nOiAwO1xufVxuXG4uamgtbmF2YmFyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hcnRlbWlzLWRhcmspO1xuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgcGFkZGluZzogMC4yZW0gMXJlbTtcbiAgICBjb2xvcjogdmFyKC0tbmF2YmFyLWRhcmstY29sb3IpO1xuXG4gICAgLnByb2ZpbGUtaW1hZ2Uge1xuICAgICAgICBtYXJnaW46IC0xMHB4IDBweDtcbiAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICB3aWR0aDogNDBweDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIH1cblxuICAgIC5kcm9wZG93bi1pdGVtLmFjdGl2ZSxcbiAgICAuZHJvcGRvd24taXRlbS5hY3RpdmU6Zm9jdXMsXG4gICAgLmRyb3Bkb3duLWl0ZW0uYWN0aXZlOmhvdmVyIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbmF2YmFyLWJnKTtcbiAgICB9XG5cbiAgICAuZHJvcGRvd24tdG9nZ2xlOjphZnRlciB7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAwLjE1ZW07XG4gICAgfVxuXG4gICAgdWwubmF2YmFyLW5hdiB7XG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG5cbiAgICAgICAgLm5hdi1pdGVtIHtcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxLjVyZW07XG4gICAgICAgIH1cblxuICAgICAgICAmLnZlcnRpY2FsIHtcbiAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBAbWVkaWEgc2NyZWVuIGFuZCAobWluLXdpZHRoOiA0ODBweCkge1xuICAgICAgICB1bC5uYXZiYXItbmF2Om5vdCgudmVydGljYWwpIHtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG5cbiAgICAgICAgICAgIC5uYXYtaXRlbTpmaXJzdC1jaGlsZCB7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAubmF2LWxpbmsge1xuICAgICAgICBjb2xvcjogdmFyKC0tbmF2YmFyLWRhcmstY29sb3IpO1xuXG4gICAgICAgICY6aG92ZXIge1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLWxpbmstY29sb3IpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgYS5uYXYtbGluayB7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgfVxuXG4gICAgLmpoLWxvZ28tY29udGFpbmVyIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgZmxleDogMTtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgZmxleC13cmFwOiBub3dyYXA7XG4gICAgICAgIGdhcDogMTBweDtcbiAgICAgICAgaGVpZ2h0OiA1MHB4O1xuXG4gICAgICAgIC5uYXZiYXItYnJhbmQge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGdhcDogMTBweDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDEwcHggMTVweDtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDA7XG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG5cbiAgICAgICAgICAgIGltZyB7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAzMHB4O1xuICAgICAgICAgICAgICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAubmF2YmFyLXZlcnNpb24ge1xuICAgICAgICAgICAgICAgIHBhZGRpbmctdG9wOiAzcHg7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMHB4O1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLW5hdmJhci1mb3JlZ3JvdW5kKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLm5hdmJhci10aXRsZSB7XG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgJjpob3ZlciB7XG4gICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLW5hdmJhci1mb3JlZ3JvdW5kKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5pbmRpY2F0b3JzIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgZmxleC13cmFwOiBub3dyYXA7XG4gICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgICAgICBnYXA6IDEwcHg7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XG4gICAgICAgICAgICBmbGV4OiAxO1xuICAgICAgICB9XG5cbiAgICAgICAgLnRvZ2dsZXItd3JhcHBlciB7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAgICAgICAgIC50b2dnbGVyIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0tbmF2YmFyLWZvcmVncm91bmQpO1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMS41ZW07XG4gICAgICAgICAgICAgICAgcGFkZGluZzogMTBweDtcblxuICAgICAgICAgICAgICAgICY6aG92ZXIge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0tbmF2YmFyLWZvcmVncm91bmQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cblxuLmpoLW5hdmJhci5leHBhbmRlZCB7XG4gICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICBmbGV4LXdyYXA6IG5vd3JhcDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XG5cbiAgICAubmF2YmFyLW5hdiB7XG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG5cbiAgICAgICAgLm5hdi1saW5rIHtcbiAgICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDAuNXJlbTtcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMC41cmVtO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLm5hdmJhci1jb2xsYXBzZSB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICAuamgtbG9nby1jb250YWluZXIgLnRvZ2dsZXItd3JhcHBlciB7XG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgfVxufVxuXG4uZHJvcGRvd24tbWVudS1pbmRleCB7XG4gICAgei1pbmRleDogMjAwMDtcbn1cblxuLmJyZWFkY3J1bWItY29udGFpbmVyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1uYXZiYXItYnJlYWRjcnVtYi1iYWNrZ3JvdW5kKTtcbiAgICBvdmVyZmxvdzogYXV0bztcbiAgICBtYXJnaW4tbGVmdDogLTE1cHg7XG4gICAgbWluLWhlaWdodDogMC41cmVtO1xuXG4gICAgLmJyZWFkY3J1bWIge1xuICAgICAgICBjb2xvcjogdmFyKC0tbmF2YmFyLWJyZWFkY3J1bWItY29sb3IpO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1uYXZiYXItYnJlYWRjcnVtYi1iYWNrZ3JvdW5kKTtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDFyZW07XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDA7XG4gICAgICAgIHBhZGRpbmc6IDVweCAxNnB4IDVweCAxNnB4O1xuXG4gICAgICAgIC5icmVhZGNydW1iLWxpbmsge1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5icmVhZGNydW1iLWl0ZW06bm90KDpmaXJzdC1vZi10eXBlKTo6YmVmb3JlIHtcbiAgICAgICAgY29udGVudDogJz4nO1xuICAgIH1cbn1cblxuQG1lZGlhIG5vdCBhbGwgYW5kIChtaW4tcmVzb2x1dGlvbjogMC4wMDFkcGNtKSB7XG4gICAgQHN1cHBvcnRzICgtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmUpIHtcbiAgICAgICAgLmJyZWFkY3J1bWItaXRlbTpmaXJzdC1vZi10eXBlIHtcbiAgICAgICAgICAgIC5icmVhZGNydW1iLWxpbmsge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBTUEsQ0FBQSxLQUFBLENBQUEsSUFBQTtBQUNJLG1CQUFBOztBQUdKLENBQUE7QUFDSSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxPQUFBO0FBQ0EsbUJBQUE7QUFDQSxTQUFBLElBQUE7QUFDQSxlQUFBO0FBQ0EsY0FBQSxNQUFBO0FBQ0EsV0FBQSxFQUFBLEtBQUEsRUFBQTs7QUFFQSxDQVZKLGlCQVVJLEVBQUEsQ0FBQTtBQUNJLFNBQUEsSUFBQTs7QUFHSixDQWRKLGdCQWNJLENBQUE7QUFDSSxtQkFBQTtBQUNBLE9BQUE7QUFDQSxnQkFBQTtBQUNBLGlCQUFBOztBQUdKLENBckJKLGdCQXFCSSxDQUFBO0FBQ0ksZUFBQTtBQUNBLGtCQUFBOztBQUlSLENBQUE7QUFDSSxXQUFBOztBQUdKLENBQUE7QUFDSSxvQkFBQSxJQUFBO0FBQ0EsZUFBQTtBQUNBLFdBQUEsTUFBQTtBQUNBLFNBQUEsSUFBQTs7QUFFQSxDQU5KLFVBTUksQ0FBQTtBQUNJLFVBQUEsTUFBQTtBQUNBLFVBQUE7QUFDQSxTQUFBO0FBQ0EsaUJBQUE7O0FBR0osQ0FiSixVQWFJLENBQUEsYUFBQSxDQUFBO0FBQUEsQ0FiSixVQWFJLENBQUEsYUFBQSxDQUFBLE1BQUE7QUFBQSxDQWJKLFVBYUksQ0FBQSxhQUFBLENBQUEsTUFBQTtBQUdJLG9CQUFBLElBQUE7O0FBR0osQ0FuQkosVUFtQkksQ0FBQSxlQUFBO0FBQ0ksZUFBQTs7QUFHSixDQXZCSixVQXVCSSxFQUFBLENBQUE7QUFDSSxrQkFBQTtBQUNBLGlCQUFBOztBQUVBLENBM0JSLFVBMkJRLEVBQUEsQ0FKSixXQUlJLENBQUE7QUFDSSxlQUFBOztBQUdKLENBL0JSLFVBK0JRLEVBQUEsQ0FSSixVQVFJLENBQUE7QUFDSSxrQkFBQTs7QUFJUixPQUFBLE9BQUEsSUFBQSxDQUFBLFNBQUEsRUFBQTtBQUNJLEdBckNSLFVBcUNRLEVBQUEsQ0FkSixVQWNJLEtBQUEsQ0FOQTtBQU9JLHFCQUFBOztBQUVBLEdBeENaLFVBd0NZLEVBQUEsQ0FqQlIsVUFpQlEsS0FBQSxDQVRKLFVBU0ksQ0FiSixRQWFJO0FBQ0ksaUJBQUE7OztBQUtaLENBOUNKLFVBOENJLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBRUEsQ0FqRFIsVUFpRFEsQ0FISixRQUdJO0FBQ0ksU0FBQSxJQUFBOztBQUlSLENBdERKLFVBc0RJLENBQUEsQ0FSQTtBQVNJLGVBQUE7O0FBR0osQ0ExREosVUEwREksQ0FBQTtBQUNJLFdBQUE7QUFDQSxRQUFBO0FBQ0EsZUFBQTtBQUNBLGFBQUE7QUFDQSxPQUFBO0FBQ0EsVUFBQTs7QUFFQSxDQWxFUixVQWtFUSxDQVJKLGtCQVFJLENBQUE7QUFDSSxXQUFBO0FBQ0EsT0FBQTtBQUNBLFdBQUEsS0FBQTtBQUNBLGVBQUE7QUFDQSxnQkFBQTtBQUNBLFVBQUE7O0FBRUEsQ0ExRVosVUEwRVksQ0FoQlIsa0JBZ0JRLENBUkosYUFRSTtBQUNJLFVBQUE7QUFDQSxrQkFBQTtBQUNBLGdCQUFBOztBQUdKLENBaEZaLFVBZ0ZZLENBdEJSLGtCQXNCUSxDQWRKLGFBY0ksQ0FBQTtBQUNJLGVBQUE7QUFDQSxhQUFBO0FBQ0EsZUFBQTtBQUNBLFNBQUEsSUFBQTs7QUFHSixDQXZGWixVQXVGWSxDQTdCUixrQkE2QlEsQ0FyQkosYUFxQkksQ0FBQTtBQUNJLGVBQUE7O0FBR0osQ0EzRlosVUEyRlksQ0FqQ1Isa0JBaUNRLENBekJKLFlBeUJJO0FBQ0ksU0FBQSxJQUFBOztBQUlSLENBaEdSLFVBZ0dRLENBdENKLGtCQXNDSSxDQUFBO0FBQ0ksV0FBQTtBQUNBLGVBQUE7QUFDQSxhQUFBO0FBQ0EsYUFBQTtBQUNBLFVBQUE7QUFDQSxPQUFBO0FBQ0EsbUJBQUE7QUFDQSxRQUFBOztBQUdKLENBM0dSLFVBMkdRLENBakRKLGtCQWlESSxDQUFBO0FBQ0ksV0FBQTtBQUNBLG1CQUFBO0FBQ0EsZUFBQTs7QUFFQSxDQWhIWixVQWdIWSxDQXREUixrQkFzRFEsQ0FMSixnQkFLSSxDQUFBO0FBQ0ksU0FBQSxJQUFBO0FBQ0EsYUFBQTtBQUNBLFdBQUE7O0FBRUEsQ0FySGhCLFVBcUhnQixDQTNEWixrQkEyRFksQ0FWUixnQkFVUSxDQUxKLE9BS0k7QUFDSSxTQUFBLElBQUE7O0FBT3BCLENBN0hBLFNBNkhBLENBQUE7QUFDSSxrQkFBQTtBQUNBLGFBQUE7QUFDQSxtQkFBQTs7QUFFQSxDQWxJSixTQWtJSSxDQUxKLFNBS0ksQ0EzR0E7QUE0R0ksa0JBQUE7O0FBRUEsQ0FySVIsU0FxSVEsQ0FSUixTQVFRLENBOUdKLFdBOEdJLENBdkZKO0FBd0ZRLGlCQUFBO0FBQ0EsZ0JBQUE7O0FBSVIsQ0EzSUosU0EySUksQ0FkSixTQWNJLENBQUE7QUFDSSxXQUFBOztBQUdKLENBL0lKLFNBK0lJLENBbEJKLFNBa0JJLENBckZBLGtCQXFGQSxDQXBDSTtBQXFDQSxXQUFBOztBQUlSLENBQUE7QUFDSSxXQUFBOztBQUdKLENBQUE7QUFDSSxvQkFBQSxJQUFBO0FBQ0EsWUFBQTtBQUNBLGVBQUE7QUFDQSxjQUFBOztBQUVBLENBTkoscUJBTUksQ0FBQTtBQUNJLFNBQUEsSUFBQTtBQUNBLG9CQUFBLElBQUE7QUFDQSxlQUFBO0FBQ0EsaUJBQUE7QUFDQSxXQUFBLElBQUEsS0FBQSxJQUFBOztBQUVBLENBYlIscUJBYVEsQ0FQSixXQU9JLENBQUE7QUFDSSxlQUFBO0FBQ0EsV0FBQTs7QUFJUixDQW5CSixxQkFtQkksQ0FBQSxlQUFBLEtBQUEsZUFBQTtBQUNJLFdBQUE7O0FBSVIsT0FBQSxJQUFBLElBQUEsSUFBQSxDQUFBLGNBQUEsRUFBQTtBQUNJLFlBQUEsQ0FBQSxrQkFBQSxFQUFBO0FBRVEsS0FSUixlQVFRLGVBQUEsQ0FkSjtBQWVRLGVBQUE7Ozs7IiwKICAibmFtZXMiOiBbXQp9Cg== */'] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassDebugInfo(NavbarComponent, { className: "NavbarComponent" });
    })();
    Breadcrumb = class {
      label;
      uri;
      translate;
    };
  }
});

// src/main/webapp/app/shared/layouts/profiles/page-ribbon.component.ts
import { Component as Component7 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i09 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function PageRibbonComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                ");
    i09.\u0275\u0275elementStart(1, "div", 1);
    i09.\u0275\u0275text(2, "\n                    ");
    i09.\u0275\u0275elementStart(3, "span", 2);
    i09.\u0275\u0275text(4);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(5, "\n                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(6, "\n            ");
  }
  if (rf & 2) {
    const ctx_r0 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275propertyInterpolate1("jhiTranslate", "global.ribbon.", ctx_r0.ribbonEnv, "");
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275textInterpolate(ctx_r0.ribbonEnv);
  }
}
var PageRibbonComponent;
var init_page_ribbon_component = __esm({
  "src/main/webapp/app/shared/layouts/profiles/page-ribbon.component.ts"() {
    init_profile_service();
    init_profile_service();
    init_translate_directive();
    PageRibbonComponent = class _PageRibbonComponent {
      profileService;
      profileInfo;
      ribbonEnv;
      constructor(profileService) {
        this.profileService = profileService;
      }
      ngOnInit() {
        this.profileService.getProfileInfo().subscribe((profileInfo) => {
          if (profileInfo) {
            this.profileInfo = profileInfo;
            this.ribbonEnv = profileInfo.ribbonEnv;
            if (profileInfo.inProduction && profileInfo.testServer) {
              this.ribbonEnv = "test";
            }
          }
        });
      }
      static \u0275fac = function PageRibbonComponent_Factory(t) {
        return new (t || _PageRibbonComponent)(i09.\u0275\u0275directiveInject(ProfileService));
      };
      static \u0275cmp = i09.\u0275\u0275defineComponent({ type: _PageRibbonComponent, selectors: [["jhi-page-ribbon"]], decls: 5, vars: 1, consts: [[1, "box"], [1, "ribbon", "ribbon-top-left"], [3, "jhiTranslate"]], template: function PageRibbonComponent_Template(rf, ctx) {
        if (rf & 1) {
          i09.\u0275\u0275text(0, "\n        ");
          i09.\u0275\u0275elementStart(1, "div", 0);
          i09.\u0275\u0275text(2, "\n            ");
          i09.\u0275\u0275template(3, PageRibbonComponent_Conditional_3_Template, 7, 2);
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(4, "\n    ");
        }
        if (rf & 2) {
          i09.\u0275\u0275advance(3);
          i09.\u0275\u0275conditional(3, ctx.ribbonEnv ? 3 : -1);
        }
      }, dependencies: [TranslateDirective], styles: ["\n\n.box[_ngcontent-%COMP%] {\n  position: relative;\n  max-width: 0;\n  width: 90%;\n  height: 0;\n  background: #fff;\n  box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);\n}\n.ribbon[_ngcontent-%COMP%] {\n  z-index: 9999;\n  width: 200px;\n  height: 200px;\n  overflow: hidden;\n  white-space: nowrap;\n  pointer-events: none;\n  position: absolute;\n  opacity: 0.75;\n}\n.ribbon[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  position: absolute;\n  display: block;\n  width: 300px;\n  padding: 10px 0;\n  background-color: rgba(170, 0, 0, 0.5);\n  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);\n  color: #fff;\n  text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n  text-align: center;\n}\n.ribbon-top-left[_ngcontent-%COMP%] {\n  top: -20px;\n  left: -20px;\n}\n.ribbon-top-left[_ngcontent-%COMP%]::before, .ribbon-top-left[_ngcontent-%COMP%]::after {\n  border-top-color: transparent;\n  border-left-color: transparent;\n}\n.ribbon-top-left[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  right: -25px;\n  top: 45px;\n  transform: rotate(-45deg);\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbGF5b3V0cy9wcm9maWxlcy9wYWdlLXJpYmJvbi5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuRGV2ZWxvcGVtZW50IFJpYmJvblxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi9cbi5ib3gge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBtYXgtd2lkdGg6IDA7XG4gICAgd2lkdGg6IDkwJTtcbiAgICBoZWlnaHQ6IDA7XG4gICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICBib3gtc2hhZG93OiAwIDAgMTVweCByZ2JhKDAsIDAsIDAsIDAuMSk7XG59XG5cbi8qIGNvbW1vbiAqL1xuLnJpYmJvbiB7XG4gICAgei1pbmRleDogOTk5OTtcbiAgICB3aWR0aDogMjAwcHg7XG4gICAgaGVpZ2h0OiAyMDBweDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIG9wYWNpdHk6IDAuNzU7XG5cbiAgICBzcGFuIHtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgd2lkdGg6IDMwMHB4O1xuICAgICAgICBwYWRkaW5nOiAxMHB4IDA7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMTcwLCAwLCAwLCAwLjUpO1xuICAgICAgICBib3gtc2hhZG93OiAwIDVweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgIHRleHQtc2hhZG93OiAwIDFweCAxcHggcmdiYSgwLCAwLCAwLCAwLjIpO1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgfVxufVxuXG4vKiB0b3AgbGVmdCAqL1xuLnJpYmJvbi10b3AtbGVmdCB7XG4gICAgdG9wOiAtMjBweDtcbiAgICBsZWZ0OiAtMjBweDtcbn1cblxuLnJpYmJvbi10b3AtbGVmdDo6YmVmb3JlLFxuLnJpYmJvbi10b3AtbGVmdDo6YWZ0ZXIge1xuICAgIGJvcmRlci10b3AtY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIGJvcmRlci1sZWZ0LWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuLnJpYmJvbi10b3AtbGVmdCBzcGFuIHtcbiAgICByaWdodDogLTI1cHg7XG4gICAgdG9wOiA0NXB4O1xuICAgIHRyYW5zZm9ybTogcm90YXRlKC00NWRlZyk7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBR0EsQ0FBQTtBQUNJLFlBQUE7QUFDQSxhQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxjQUFBO0FBQ0EsY0FBQSxFQUFBLEVBQUEsS0FBQSxLQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBOztBQUlKLENBQUE7QUFDSSxXQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxZQUFBO0FBQ0EsZUFBQTtBQUNBLGtCQUFBO0FBQ0EsWUFBQTtBQUNBLFdBQUE7O0FBRUEsQ0FWSixPQVVJO0FBQ0ksWUFBQTtBQUNBLFdBQUE7QUFDQSxTQUFBO0FBQ0EsV0FBQSxLQUFBO0FBQ0Esb0JBQUEsS0FBQSxHQUFBLEVBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQTtBQUNBLGNBQUEsRUFBQSxJQUFBLEtBQUEsS0FBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQTtBQUNBLFNBQUE7QUFDQSxlQUFBLEVBQUEsSUFBQSxJQUFBLEtBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLEVBQUE7QUFDQSxjQUFBOztBQUtSLENBQUE7QUFDSSxPQUFBO0FBQ0EsUUFBQTs7QUFHSixDQUxBLGVBS0E7QUFBQSxDQUxBLGVBS0E7QUFFSSxvQkFBQTtBQUNBLHFCQUFBOztBQUdKLENBWEEsZ0JBV0E7QUFDSSxTQUFBO0FBQ0EsT0FBQTtBQUNBLGFBQUEsT0FBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i09.\u0275setClassDebugInfo(PageRibbonComponent, { className: "PageRibbonComponent" });
    })();
  }
});

// src/main/webapp/app/shared/layouts/navbar/navbar.route.ts
var navbarRoute;
var init_navbar_route = __esm({
  "src/main/webapp/app/shared/layouts/navbar/navbar.route.ts"() {
    init_navbar_component();
    navbarRoute = {
      path: "",
      component: NavbarComponent,
      outlet: "navbar"
    };
  }
});

// src/main/webapp/app/shared/layouts/error/error.component.ts
import { Component as Component8 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i010 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
var ErrorComponent;
var init_error_component = __esm({
  "src/main/webapp/app/shared/layouts/error/error.component.ts"() {
    init_translate_directive();
    ErrorComponent = class _ErrorComponent {
      route;
      errorMessage;
      error403;
      error404;
      constructor(route) {
        this.route = route;
      }
      ngOnInit() {
        this.route.data.subscribe((routeData) => {
          if (routeData.error403) {
            this.error403 = routeData.error403;
          }
          if (routeData.error404) {
            this.error404 = routeData.error404;
          }
          if (routeData.errorMessage) {
            this.errorMessage = routeData.errorMessage;
          }
        });
      }
      static \u0275fac = function ErrorComponent_Factory(t) {
        return new (t || _ErrorComponent)(i010.\u0275\u0275directiveInject(i13.ActivatedRoute));
      };
      static \u0275cmp = i010.\u0275\u0275defineComponent({ type: _ErrorComponent, selectors: [["jhi-error"]], decls: 24, vars: 4, consts: [[1, "row"], [1, "col"], ["jhiTranslate", "error.title"], [3, "hidden"], [1, "alert", "alert-danger"], ["jhiTranslate", "error.http.403", 1, "alert", "alert-danger", 3, "hidden"], ["jhiTranslate", "error.http.404", 1, "alert", "alert-danger", 3, "hidden"]], template: function ErrorComponent_Template(rf, ctx) {
        if (rf & 1) {
          i010.\u0275\u0275elementStart(0, "div");
          i010.\u0275\u0275text(1, "\n    ");
          i010.\u0275\u0275elementStart(2, "div", 0);
          i010.\u0275\u0275text(3, "\n        ");
          i010.\u0275\u0275elementStart(4, "div", 1);
          i010.\u0275\u0275text(5, "\n            ");
          i010.\u0275\u0275elementStart(6, "h1", 2);
          i010.\u0275\u0275text(7, "Error Page!");
          i010.\u0275\u0275elementEnd();
          i010.\u0275\u0275text(8, "\n\n            ");
          i010.\u0275\u0275elementStart(9, "div", 3);
          i010.\u0275\u0275text(10, "\n                ");
          i010.\u0275\u0275elementStart(11, "div", 4);
          i010.\u0275\u0275text(12);
          i010.\u0275\u0275elementEnd();
          i010.\u0275\u0275text(13, "\n            ");
          i010.\u0275\u0275elementEnd();
          i010.\u0275\u0275text(14, "\n            ");
          i010.\u0275\u0275elementStart(15, "div", 5);
          i010.\u0275\u0275text(16, "You are not authorized to access this page.");
          i010.\u0275\u0275elementEnd();
          i010.\u0275\u0275text(17, "\n            ");
          i010.\u0275\u0275elementStart(18, "div", 6);
          i010.\u0275\u0275text(19, "The page does not exist.");
          i010.\u0275\u0275elementEnd();
          i010.\u0275\u0275text(20, "\n        ");
          i010.\u0275\u0275elementEnd();
          i010.\u0275\u0275text(21, "\n    ");
          i010.\u0275\u0275elementEnd();
          i010.\u0275\u0275text(22, "\n");
          i010.\u0275\u0275elementEnd();
          i010.\u0275\u0275text(23, "\n");
        }
        if (rf & 2) {
          i010.\u0275\u0275advance(9);
          i010.\u0275\u0275property("hidden", !ctx.errorMessage);
          i010.\u0275\u0275advance(3);
          i010.\u0275\u0275textInterpolate(ctx.errorMessage);
          i010.\u0275\u0275advance(3);
          i010.\u0275\u0275property("hidden", !ctx.error403);
          i010.\u0275\u0275advance(3);
          i010.\u0275\u0275property("hidden", !ctx.error404);
        }
      }, dependencies: [TranslateDirective], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i010.\u0275setClassDebugInfo(ErrorComponent, { className: "ErrorComponent" });
    })();
  }
});

// src/main/webapp/app/shared/orion/outdated-plugin-warning/orion-outdated.component.ts
import { Component as Component9 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute7 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i011 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i14 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
var OrionOutdatedComponent;
var init_orion_outdated_component = __esm({
  "src/main/webapp/app/shared/orion/outdated-plugin-warning/orion-outdated.component.ts"() {
    init_profile_service();
    init_profile_service();
    init_translate_directive();
    init_artemis_translate_pipe();
    OrionOutdatedComponent = class _OrionOutdatedComponent {
      activatedRoute;
      profileService;
      versionString;
      allowedMinimumVersion;
      constructor(activatedRoute, profileService) {
        this.activatedRoute = activatedRoute;
        this.profileService = profileService;
      }
      ngOnInit() {
        this.activatedRoute.queryParams.subscribe((params) => {
          this.versionString = params["versionString"];
          this.profileService.getProfileInfo().subscribe((profileInfo) => {
            this.allowedMinimumVersion = profileInfo.allowedMinimumOrionVersion;
          });
        });
      }
      static \u0275fac = function OrionOutdatedComponent_Factory(t) {
        return new (t || _OrionOutdatedComponent)(i011.\u0275\u0275directiveInject(i14.ActivatedRoute), i011.\u0275\u0275directiveInject(ProfileService));
      };
      static \u0275cmp = i011.\u0275\u0275defineComponent({ type: _OrionOutdatedComponent, selectors: [["jhi-orion-outdated"]], decls: 18, vars: 8, consts: [["jhiTranslate", "artemisApp.orion.version.outdated", 1, "text-danger", "font-weight-bold"], [1, "font-weight-bold"], [1, "badge", "bg-pill", "bg-danger"], [1, "badge", "bg-pill", "bg-info"]], template: function OrionOutdatedComponent_Template(rf, ctx) {
        if (rf & 1) {
          i011.\u0275\u0275text(0, "\n        ");
          i011.\u0275\u0275elementStart(1, "h2", 0);
          i011.\u0275\u0275text(2, "The version of Orion you are currently using is outdated!");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(3, "\n        ");
          i011.\u0275\u0275elementStart(4, "div", 1);
          i011.\u0275\u0275text(5);
          i011.\u0275\u0275pipe(6, "artemisTranslate");
          i011.\u0275\u0275elementStart(7, "span", 2);
          i011.\u0275\u0275text(8);
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(9, "!\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(10, "\n        ");
          i011.\u0275\u0275elementStart(11, "div");
          i011.\u0275\u0275text(12);
          i011.\u0275\u0275pipe(13, "artemisTranslate");
          i011.\u0275\u0275elementStart(14, "span", 3);
          i011.\u0275\u0275text(15);
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(16, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(17, "\n    ");
        }
        if (rf & 2) {
          i011.\u0275\u0275advance(5);
          i011.\u0275\u0275textInterpolate1("\n            ", i011.\u0275\u0275pipeBind1(6, 4, "artemisApp.orion.version.usedVersion"), "");
          i011.\u0275\u0275advance(3);
          i011.\u0275\u0275textInterpolate(ctx.versionString);
          i011.\u0275\u0275advance(4);
          i011.\u0275\u0275textInterpolate1("\n            ", i011.\u0275\u0275pipeBind1(13, 6, "artemisApp.orion.version.allowedVersion"), "");
          i011.\u0275\u0275advance(3);
          i011.\u0275\u0275textInterpolate(ctx.allowedMinimumVersion);
        }
      }, dependencies: [TranslateDirective, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i011.\u0275setClassDebugInfo(OrionOutdatedComponent, { className: "OrionOutdatedComponent" });
    })();
  }
});

// src/main/webapp/app/shared/layouts/error/error.route.ts
var errorRoute;
var init_error_route = __esm({
  "src/main/webapp/app/shared/layouts/error/error.route.ts"() {
    init_error_component();
    init_orion_outdated_component();
    errorRoute = [
      {
        path: "error",
        component: ErrorComponent,
        data: {
          authorities: [],
          pageTitle: "error.title"
        }
      },
      {
        path: "accessdenied",
        component: ErrorComponent,
        data: {
          authorities: [],
          pageTitle: "error.title",
          error403: true
        }
      },
      {
        path: "orion-outdated",
        component: OrionOutdatedComponent,
        data: {
          authorities: [],
          pageTitle: "Outdated Orion Version"
        }
      }
    ];
  }
});

// src/main/webapp/app/app-routing.module.ts
import { NgModule as NgModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { RouterModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i012 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var LAYOUT_ROUTES, ArtemisAppRoutingModule;
var init_app_routing_module = __esm({
  "src/main/webapp/app/app-routing.module.ts"() {
    init_navbar_route();
    init_error_route();
    init_navigation_utils();
    init_about_iris_component();
    init_navigation_utils();
    LAYOUT_ROUTES = [navbarRoute, ...errorRoute];
    ArtemisAppRoutingModule = class _ArtemisAppRoutingModule {
      _;
      constructor(_) {
        this._ = _;
      }
      static \u0275fac = function ArtemisAppRoutingModule_Factory(t) {
        return new (t || _ArtemisAppRoutingModule)(i012.\u0275\u0275inject(ArtemisNavigationUtilService));
      };
      static \u0275mod = i012.\u0275\u0275defineNgModule({ type: _ArtemisAppRoutingModule });
      static \u0275inj = i012.\u0275\u0275defineInjector({ imports: [RouterModule.forRoot([
        ...LAYOUT_ROUTES,
        {
          path: "admin",
          loadChildren: () => import("/admin.module-LI7ONKMA.js").then((m) => m.ArtemisAdminModule)
        },
        {
          path: "account",
          loadChildren: () => import("/account.module-S6A6R24I.js").then((m) => m.ArtemisAccountModule)
        },
        {
          path: "privacy",
          loadChildren: () => import("/privacy.module-7P4UMAPQ.js").then((m) => m.ArtemisPrivacyModule)
        },
        {
          path: "imprint",
          loadChildren: () => import("/imprint.module-HZGGEVDP.js").then((m) => m.ArtemisImprintModule)
        },
        {
          path: "about",
          loadChildren: () => import("/artemis-about-us.module-TCHD3A4B.js").then((module) => module.ArtemisAboutUsModule)
        },
        {
          path: "courses/:courseId/lectures/:lectureId",
          loadChildren: () => import("/course-lecture-details.module-XTY5V2FW.js").then((m) => m.ArtemisCourseLectureDetailsModule)
        },
        {
          path: "courses/:courseId/exercises/:exerciseId",
          loadChildren: () => import("/course-exercise-details.module-ZF2OGLLX.js").then((m) => m.CourseExerciseDetailsModule)
        },
        {
          path: "courses/:courseId/competencies/:competencyId",
          loadChildren: () => import("/course-competencies-details.module-RTFTDJAG.js").then((m) => m.ArtemisCourseCompetenciesDetailsModule)
        },
        {
          path: "courses/:courseId/tutorial-groups/:tutorialGroupId",
          loadChildren: () => import("/course-tutorial-group-details.module-6ZC3JJ56.js").then((m) => m.CourseTutorialGroupDetailsModule)
        },
        {
          path: "course-management/:courseId/exercises/:exerciseId/teams",
          loadChildren: () => import("/team.module-QA53A7AC.js").then((m) => m.ArtemisTeamModule)
        },
        {
          path: "courses/:courseId/exercises/:exerciseId/teams",
          loadChildren: () => import("/team.module-QA53A7AC.js").then((m) => m.ArtemisTeamModule)
        },
        {
          path: "course-management",
          loadChildren: () => import("/course-management.module-T25KOD6H.js").then((m) => m.ArtemisCourseManagementModule)
        },
        {
          path: "course-management/:courseId/programming-exercises/:exerciseId/code-editor",
          loadChildren: () => import("/code-editor-management.module-E5VCWNKQ.js").then((m) => m.ArtemisCodeEditorManagementModule)
        },
        {
          path: "course-management/:courseId/text-exercises/:exerciseId",
          loadChildren: () => import("/text-submission-assessment.module-MH2RC4MR.js").then((m) => m.ArtemisTextSubmissionAssessmentModule)
        },
        {
          path: "course-management/:courseId/text-exercises/:exerciseId/example-submissions/:exampleSubmissionId",
          loadChildren: () => import("/example-text-submission.module-Z4QHYPGG.js").then((m) => m.ArtemisExampleTextSubmissionModule)
        },
        {
          path: "courses/:courseId/programming-exercises/:exerciseId/code-editor",
          loadChildren: () => import("/programming-participation.module-HBTYBZ42.js").then((m) => m.ArtemisProgrammingParticipationModule)
        },
        {
          path: "courses/:courseId/modeling-exercises/:exerciseId",
          loadChildren: () => import("/modeling-participation.module-WJXH7AMW.js").then((m) => m.ArtemisModelingParticipationModule)
        },
        {
          path: "courses/:courseId/quiz-exercises/:exerciseId",
          loadChildren: () => import("/quiz-participation.module-5E4457N4.js").then((m) => m.ArtemisQuizParticipationModule)
        },
        {
          path: "courses/:courseId/text-exercises/:exerciseId",
          loadChildren: () => import("/text-participation.module-VGRVEMBP.js").then((m) => m.ArtemisTextParticipationModule)
        },
        {
          path: "courses/:courseId/file-upload-exercises/:exerciseId",
          loadChildren: () => import("/file-upload-participation.module-JYYYM2SW.js").then((m) => m.ArtemisFileUploadParticipationModule)
        },
        {
          path: "courses/:courseId/grading-system",
          loadChildren: () => import("/grading-system.module-LQG3YEFU.js").then((m) => m.GradingSystemModule)
        },
        {
          path: "courses/:courseId/exams/:examId",
          loadChildren: () => import("/exam-participation.module-TLLSEEHO.js").then((m) => m.ArtemisExamParticipationModule)
        },
        {
          path: "course-management/:courseId/exams",
          loadChildren: () => import("/exam-management.module-L5CLMYUO.js").then((m) => m.ArtemisExamManagementModule)
        },
        {
          path: "courses/:courseId/exams/:examId/grading-system",
          loadChildren: () => import("/grading-system.module-LQG3YEFU.js").then((m) => m.GradingSystemModule)
        },
        {
          path: "features",
          loadChildren: () => import("/feature-overview.module-2PQNZYAL.js").then((m) => m.FeatureOverviewModule)
        },
        {
          path: "lti",
          loadChildren: () => import("/lti.module-OB4U6MNS.js").then((m) => m.ArtemisLtiModule)
        },
        {
          path: "about-iris",
          component: AboutIrisComponent,
          pathMatch: "full"
        }
      ], { enableTracing: false, onSameUrlNavigation: "reload" }), RouterModule] });
    };
  }
});

// src/main/webapp/app/shared/layouts/footer/footer.component.ts
import { Component as Component10 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i013 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i33 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function FooterComponent_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i013.\u0275\u0275text(0, "\n        ");
    i013.\u0275\u0275elementStart(1, "div", 14);
    i013.\u0275\u0275text(2, "\n            ");
    i013.\u0275\u0275elementStart(3, "div", 15);
    i013.\u0275\u0275text(4);
    i013.\u0275\u0275pipe(5, "artemisTranslate");
    i013.\u0275\u0275elementEnd();
    i013.\u0275\u0275text(6, "\n            ");
    i013.\u0275\u0275elementStart(7, "div", 15);
    i013.\u0275\u0275text(8);
    i013.\u0275\u0275pipe(9, "artemisTranslate");
    i013.\u0275\u0275elementEnd();
    i013.\u0275\u0275text(10, "\n            ");
    i013.\u0275\u0275elementStart(11, "div", 15);
    i013.\u0275\u0275text(12);
    i013.\u0275\u0275pipe(13, "artemisTranslate");
    i013.\u0275\u0275elementEnd();
    i013.\u0275\u0275text(14, "\n            ");
    i013.\u0275\u0275elementStart(15, "div", 15);
    i013.\u0275\u0275text(16);
    i013.\u0275\u0275pipe(17, "artemisTranslate");
    i013.\u0275\u0275elementEnd();
    i013.\u0275\u0275text(18, "\n        ");
    i013.\u0275\u0275elementEnd();
    i013.\u0275\u0275text(19, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i013.\u0275\u0275nextContext();
    i013.\u0275\u0275advance(4);
    i013.\u0275\u0275textInterpolate2("", i013.\u0275\u0275pipeBind1(5, 8, "artemisApp.git.branch"), ": ", ctx_r0.gitBranch, " \u2022");
    i013.\u0275\u0275advance(4);
    i013.\u0275\u0275textInterpolate2("", i013.\u0275\u0275pipeBind1(9, 10, "artemisApp.git.commit"), ": ", ctx_r0.gitCommitId, " \u2022");
    i013.\u0275\u0275advance(4);
    i013.\u0275\u0275textInterpolate2("", i013.\u0275\u0275pipeBind1(13, 12, "artemisApp.git.timestamp"), ": ", ctx_r0.gitTimestamp, " \u2022");
    i013.\u0275\u0275advance(4);
    i013.\u0275\u0275textInterpolate2("", i013.\u0275\u0275pipeBind1(17, 14, "artemisApp.git.username"), ": ", ctx_r0.gitCommitUser, "");
  }
}
var _c06, _c15, _c23, FooterComponent;
var init_footer_component = __esm({
  "src/main/webapp/app/shared/layouts/footer/footer.component.ts"() {
    init_app_constants();
    init_profile_service();
    init_profile_service();
    init_translate_directive();
    init_artemis_translate_pipe();
    _c06 = () => ["/about"];
    _c15 = () => ["/privacy"];
    _c23 = () => ["/imprint"];
    FooterComponent = class _FooterComponent {
      profileService;
      releaseNotesUrl = `https://github.com/ls1intum/Artemis/releases/tag/${VERSION}`;
      requestChangeUrl = "https://github.com/ls1intum/Artemis/issues/new/choose";
      email;
      gitBranch;
      gitCommitId;
      gitTimestamp;
      gitCommitUser;
      testServer;
      inProduction;
      constructor(profileService) {
        this.profileService = profileService;
      }
      ngOnInit() {
        this.profileService.getProfileInfo().subscribe((profileInfo) => {
          this.contact = profileInfo.contact;
          this.gitBranch = profileInfo.git.branch;
          this.gitCommitId = profileInfo.git.commit.id.abbrev;
          this.gitTimestamp = new Date(profileInfo.git.commit.time).toUTCString();
          this.gitCommitUser = profileInfo.git.commit.user.name;
          this.testServer = profileInfo.testServer ?? false;
          this.inProduction = profileInfo.inProduction;
        });
      }
      set contact(mail) {
        this.email = "mailto:" + mail + "?body=Note%3A%20Please%20send%20only%20support%2Ffeature%20request%20or%20bug%20reports%20regarding%20the%20Artemis%20Platform%20to%20this%20address.%20Please%20check%20our%20public%20bug%20tracker%20at%20https%3A%2F%2Fgithub.com%2Fls1intum%2FArtemis%20for%20known%20bugs.%0AFor%20questions%20regarding%20exercises%20and%20their%20content%2C%20please%20contact%20your%20instructors.";
      }
      static \u0275fac = function FooterComponent_Factory(t) {
        return new (t || _FooterComponent)(i013.\u0275\u0275directiveInject(ProfileService));
      };
      static \u0275cmp = i013.\u0275\u0275defineComponent({ type: _FooterComponent, selectors: [["jhi-footer"]], decls: 43, vars: 16, consts: [["id", "footer", 1, "d-none", "d-md-flex", "row"], [1, "guided-tour-footer-about", "col-sm-6"], ["id", "about", "jhiTranslate", "aboutUs", 1, "footer-text", 3, "routerLink"], [1, "col-sm-6", "text-md-end"], ["id", "request-change", "jhiTranslate", "requestChange", "target", "_blank", 1, "footer-text", 3, "href"], ["id", "release-notes", "jhiTranslate", "releaseNotes", "target", "_blank", 1, "footer-text", "ms-3", 3, "href"], ["id", "privacy", "jhiTranslate", "artemisApp.legal.privacyStatement.title", 1, "footer-text", "ms-3", 3, "routerLink"], ["id", "imprint", "jhiTranslate", "artemisApp.legal.imprint.title", 1, "footer-text", "ms-3", 3, "routerLink"], [1, "d-flex", "d-md-none", "justify-content-between", "mw-100"], [1, "col-auto", "px-0"], ["jhiTranslate", "aboutUs", 1, "footer-text", 3, "routerLink"], ["jhiTranslate", "requestChange", "target", "_blank", 1, "footer-text", 3, "href"], ["jhiTranslate", "artemisApp.legal.privacyStatement.title", 1, "footer-text", 3, "routerLink"], ["jhiTranslate", "artemisApp.legal.imprint.title", 1, "footer-text", 3, "routerLink"], [1, "col-sm-12", "footer-git-wrapper"], [1, "footer-git"]], template: function FooterComponent_Template(rf, ctx) {
        if (rf & 1) {
          i013.\u0275\u0275elementStart(0, "footer", 0);
          i013.\u0275\u0275text(1, "\n    ");
          i013.\u0275\u0275elementStart(2, "div", 1);
          i013.\u0275\u0275text(3, "\n        ");
          i013.\u0275\u0275element(4, "a", 2);
          i013.\u0275\u0275text(5, "\n    ");
          i013.\u0275\u0275elementEnd();
          i013.\u0275\u0275text(6, "\n    ");
          i013.\u0275\u0275elementStart(7, "div", 3);
          i013.\u0275\u0275text(8, "\n        ");
          i013.\u0275\u0275element(9, "a", 4);
          i013.\u0275\u0275text(10, "\n        ");
          i013.\u0275\u0275element(11, "a", 5);
          i013.\u0275\u0275text(12, "\n        ");
          i013.\u0275\u0275element(13, "a", 6);
          i013.\u0275\u0275text(14, "\n        ");
          i013.\u0275\u0275element(15, "a", 7);
          i013.\u0275\u0275text(16, "\n    ");
          i013.\u0275\u0275elementEnd();
          i013.\u0275\u0275text(17, "\n    ");
          i013.\u0275\u0275template(18, FooterComponent_Conditional_18_Template, 20, 16);
          i013.\u0275\u0275elementEnd();
          i013.\u0275\u0275text(19, "\n");
          i013.\u0275\u0275elementStart(20, "footer", 8);
          i013.\u0275\u0275text(21, "\n    ");
          i013.\u0275\u0275elementStart(22, "div", 9);
          i013.\u0275\u0275text(23, "\n        ");
          i013.\u0275\u0275element(24, "a", 10);
          i013.\u0275\u0275text(25, "\n    ");
          i013.\u0275\u0275elementEnd();
          i013.\u0275\u0275text(26, "\n    ");
          i013.\u0275\u0275elementStart(27, "div", 9);
          i013.\u0275\u0275text(28, "\n        ");
          i013.\u0275\u0275element(29, "a", 11);
          i013.\u0275\u0275text(30, "\n    ");
          i013.\u0275\u0275elementEnd();
          i013.\u0275\u0275text(31, "\n    ");
          i013.\u0275\u0275elementStart(32, "div", 9);
          i013.\u0275\u0275text(33, "\n        ");
          i013.\u0275\u0275element(34, "a", 12);
          i013.\u0275\u0275text(35, "\n    ");
          i013.\u0275\u0275elementEnd();
          i013.\u0275\u0275text(36, "\n    ");
          i013.\u0275\u0275elementStart(37, "div", 9);
          i013.\u0275\u0275text(38, "\n        ");
          i013.\u0275\u0275element(39, "a", 13);
          i013.\u0275\u0275text(40, "\n    ");
          i013.\u0275\u0275elementEnd();
          i013.\u0275\u0275text(41, "\n");
          i013.\u0275\u0275elementEnd();
          i013.\u0275\u0275text(42, "\n");
        }
        if (rf & 2) {
          i013.\u0275\u0275advance(4);
          i013.\u0275\u0275property("routerLink", i013.\u0275\u0275pureFunction0(10, _c06));
          i013.\u0275\u0275advance(5);
          i013.\u0275\u0275property("href", ctx.requestChangeUrl, i013.\u0275\u0275sanitizeUrl);
          i013.\u0275\u0275advance(2);
          i013.\u0275\u0275property("href", ctx.releaseNotesUrl, i013.\u0275\u0275sanitizeUrl);
          i013.\u0275\u0275advance(2);
          i013.\u0275\u0275property("routerLink", i013.\u0275\u0275pureFunction0(11, _c15));
          i013.\u0275\u0275advance(2);
          i013.\u0275\u0275property("routerLink", i013.\u0275\u0275pureFunction0(12, _c23));
          i013.\u0275\u0275advance(3);
          i013.\u0275\u0275conditional(18, !ctx.inProduction || ctx.testServer ? 18 : -1);
          i013.\u0275\u0275advance(6);
          i013.\u0275\u0275property("routerLink", i013.\u0275\u0275pureFunction0(13, _c06));
          i013.\u0275\u0275advance(5);
          i013.\u0275\u0275property("href", ctx.requestChangeUrl, i013.\u0275\u0275sanitizeUrl);
          i013.\u0275\u0275advance(5);
          i013.\u0275\u0275property("routerLink", i013.\u0275\u0275pureFunction0(14, _c15));
          i013.\u0275\u0275advance(5);
          i013.\u0275\u0275property("routerLink", i013.\u0275\u0275pureFunction0(15, _c23));
        }
      }, dependencies: [TranslateDirective, i33.RouterLink, ArtemisTranslatePipe], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  background-color: var(--footer-bg);\n  padding: 0.5rem 1rem;\n  width: 100%;\n}\n[_nghost-%COMP%]   .footer-text[_ngcontent-%COMP%] {\n  font-weight: normal;\n  font-size: small;\n}\n[_nghost-%COMP%]   .footer-git-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n}\n[_nghost-%COMP%]   .footer-git-wrapper[_ngcontent-%COMP%]   .footer-git[_ngcontent-%COMP%] {\n  font-size: 12px;\n  margin-right: 5px;\n  margin-bottom: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbGF5b3V0cy9mb290ZXIvZm9vdGVyLnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIjpob3N0IHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogMDtcbiAgICBib3R0b206IDA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tZm9vdGVyLWJnKTtcbiAgICBwYWRkaW5nOiAwLjVyZW0gMXJlbTtcbiAgICB3aWR0aDogMTAwJTtcblxuICAgIC5mb290ZXItdGV4dCB7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgICAgIGZvbnQtc2l6ZTogc21hbGw7XG4gICAgfVxuXG4gICAgLmZvb3Rlci1naXQtd3JhcHBlciB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG5cbiAgICAgICAgLmZvb3Rlci1naXQge1xuICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUE7QUFDSSxXQUFBO0FBQ0EsWUFBQTtBQUNBLFFBQUE7QUFDQSxVQUFBO0FBQ0Esb0JBQUEsSUFBQTtBQUNBLFdBQUEsT0FBQTtBQUNBLFNBQUE7O0FBRUEsTUFBQSxDQUFBO0FBQ0ksZUFBQTtBQUNBLGFBQUE7O0FBR0osTUFBQSxDQUFBO0FBQ0ksV0FBQTs7QUFFQSxNQUFBLENBSEosbUJBR0ksQ0FBQTtBQUNJLGFBQUE7QUFDQSxnQkFBQTtBQUNBLGlCQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i013.\u0275setClassDebugInfo(FooterComponent, { className: "FooterComponent" });
    })();
  }
});

// src/main/webapp/app/shared/notification/notification-popup/notification-popup.component.ts
import { Component as Component11, ElementRef as ElementRef4, ViewChild as ViewChild3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute9, Router as Router3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { faCheckDouble, faExclamationTriangle as faExclamationTriangle2, faMessage, faTimes as faTimes3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i014 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i26 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i82 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function NotificationPopupComponent_For_4_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n                    ");
    i014.\u0275\u0275elementStart(1, "div");
    i014.\u0275\u0275text(2, "\n                        ");
    i014.\u0275\u0275element(3, "fa-icon", 6);
    i014.\u0275\u0275text(4, "\n                    ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r7 = i014.\u0275\u0275nextContext(2);
    i014.\u0275\u0275advance(3);
    i014.\u0275\u0275property("icon", ctx_r7.faExclamationTriangle);
  }
}
function NotificationPopupComponent_For_4_Conditional_6_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n                        ");
    i014.\u0275\u0275element(1, "fa-icon", 6);
    i014.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r13 = i014.\u0275\u0275nextContext(3);
    i014.\u0275\u0275advance(1);
    i014.\u0275\u0275property("icon", ctx_r13.faCheckDouble);
  }
}
function NotificationPopupComponent_For_4_Conditional_6_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n                        ");
    i014.\u0275\u0275element(1, "fa-icon", 9);
    i014.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r14 = i014.\u0275\u0275nextContext(3);
    i014.\u0275\u0275advance(1);
    i014.\u0275\u0275property("icon", ctx_r14.faMessage);
  }
}
function NotificationPopupComponent_For_4_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n                    ");
    i014.\u0275\u0275template(1, NotificationPopupComponent_For_4_Conditional_6_Conditional_1_Template, 3, 1)(2, NotificationPopupComponent_For_4_Conditional_6_Conditional_2_Template, 3, 1);
  }
  if (rf & 2) {
    const notification_r2 = i014.\u0275\u0275nextContext().$implicit;
    const ctx_r8 = i014.\u0275\u0275nextContext();
    i014.\u0275\u0275advance(1);
    i014.\u0275\u0275conditional(1, notification_r2.title === ctx_r8.QuizNotificationTitleHtmlConst ? 1 : 2);
  }
}
function NotificationPopupComponent_For_4_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n                    ");
    i014.\u0275\u0275elementStart(1, "div");
    i014.\u0275\u0275text(2, "\n                        ");
    i014.\u0275\u0275elementStart(3, "h5", 10);
    i014.\u0275\u0275text(4);
    i014.\u0275\u0275pipe(5, "artemisTranslate");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(6, "\n                    ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(7, "\n                ");
  }
  if (rf & 2) {
    i014.\u0275\u0275advance(4);
    i014.\u0275\u0275textInterpolate(i014.\u0275\u0275pipeBind1(5, 1, "artemisApp.notification.liveExamExerciseUpdateNotification"));
  }
}
function NotificationPopupComponent_For_4_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n                    ");
    i014.\u0275\u0275elementStart(1, "h5", 10);
    i014.\u0275\u0275text(2);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(3, "\n                ");
  }
  if (rf & 2) {
    const notification_r2 = i014.\u0275\u0275nextContext().$implicit;
    const ctx_r10 = i014.\u0275\u0275nextContext();
    i014.\u0275\u0275advance(2);
    i014.\u0275\u0275textInterpolate1("\n                        ", ctx_r10.getNotificationTitleTranslation(notification_r2), "\n                    ");
  }
}
function NotificationPopupComponent_For_4_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n                        ");
    i014.\u0275\u0275elementStart(1, "span");
    i014.\u0275\u0275text(2);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const notification_r2 = i014.\u0275\u0275nextContext().$implicit;
    i014.\u0275\u0275advance(2);
    i014.\u0275\u0275textInterpolate(notification_r2.author.name);
  }
}
function NotificationPopupComponent_For_4_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    i014.\u0275\u0275text(0, "\n                        ");
    i014.\u0275\u0275element(1, "span", 11);
    i014.\u0275\u0275text(2, "\n                    ");
  }
}
function NotificationPopupComponent_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = i014.\u0275\u0275getCurrentView();
    i014.\u0275\u0275text(0, "\n        ");
    i014.\u0275\u0275elementStart(1, "div", 2);
    i014.\u0275\u0275listener("click", function NotificationPopupComponent_For_4_Template_div_click_1_listener() {
      const restoredCtx = i014.\u0275\u0275restoreView(_r19);
      const i_r3 = restoredCtx.$index;
      const notification_r2 = restoredCtx.$implicit;
      const ctx_r18 = i014.\u0275\u0275nextContext();
      ctx_r18.removeNotification(i_r3);
      return i014.\u0275\u0275resetView(ctx_r18.navigateToTarget(notification_r2));
    });
    i014.\u0275\u0275text(2, "\n            ");
    i014.\u0275\u0275elementStart(3, "div", 3);
    i014.\u0275\u0275text(4, "\n                ");
    i014.\u0275\u0275template(5, NotificationPopupComponent_For_4_Conditional_5_Template, 6, 1)(6, NotificationPopupComponent_For_4_Conditional_6_Template, 3, 1);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(7, "\n            ");
    i014.\u0275\u0275elementStart(8, "div", 4);
    i014.\u0275\u0275text(9, "\n                ");
    i014.\u0275\u0275elementStart(10, "button", 5);
    i014.\u0275\u0275listener("click", function NotificationPopupComponent_For_4_Template_button_click_10_listener() {
      const restoredCtx = i014.\u0275\u0275restoreView(_r19);
      const i_r3 = restoredCtx.$index;
      const ctx_r20 = i014.\u0275\u0275nextContext();
      return i014.\u0275\u0275resetView(ctx_r20.removeNotification(i_r3));
    });
    i014.\u0275\u0275text(11, "\n                    ");
    i014.\u0275\u0275element(12, "fa-icon", 6);
    i014.\u0275\u0275text(13, "\n                ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(14, "\n                ");
    i014.\u0275\u0275template(15, NotificationPopupComponent_For_4_Conditional_15_Template, 8, 3)(16, NotificationPopupComponent_For_4_Conditional_16_Template, 4, 1);
    i014.\u0275\u0275elementStart(17, "div", 7);
    i014.\u0275\u0275text(18);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(19, "\n                ");
    i014.\u0275\u0275elementStart(20, "div", 8);
    i014.\u0275\u0275text(21);
    i014.\u0275\u0275pipe(22, "artemisTranslate");
    i014.\u0275\u0275template(23, NotificationPopupComponent_For_4_Conditional_23_Template, 4, 1)(24, NotificationPopupComponent_For_4_Conditional_24_Template, 3, 0);
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(25, "\n            ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(26, "\n        ");
    i014.\u0275\u0275elementEnd();
    i014.\u0275\u0275text(27, "\n    ");
  }
  if (rf & 2) {
    const notification_r2 = ctx.$implicit;
    const ctx_r1 = i014.\u0275\u0275nextContext();
    i014.\u0275\u0275advance(5);
    i014.\u0275\u0275conditional(5, notification_r2.title === ctx_r1.LiveExamExerciseUpdateNotificationTitleHtmlConst ? 5 : 6);
    i014.\u0275\u0275advance(7);
    i014.\u0275\u0275property("icon", ctx_r1.faTimes);
    i014.\u0275\u0275advance(3);
    i014.\u0275\u0275conditional(15, notification_r2.title === ctx_r1.LiveExamExerciseUpdateNotificationTitleHtmlConst ? 15 : 16);
    i014.\u0275\u0275advance(3);
    i014.\u0275\u0275textInterpolate1("\n                    ", ctx_r1.getNotificationTextTranslation(notification_r2), "\n                ");
    i014.\u0275\u0275advance(3);
    i014.\u0275\u0275textInterpolate1("\n                    ", i014.\u0275\u0275pipeBind1(22, 6, "artemisApp.notification.by"), "\n                    ");
    i014.\u0275\u0275advance(2);
    i014.\u0275\u0275conditional(23, notification_r2.author ? 23 : 24);
  }
}
var _c07, conversationMessageNotificationTitles, NotificationPopupComponent;
var init_notification_popup_component = __esm({
  "src/main/webapp/app/shared/notification/notification-popup/notification-popup.component.ts"() {
    init_notification_service();
    init_notification_model();
    init_exam_exercise_update_service();
    init_alert_service();
    init_exam_participation_service();
    init_metis_conversation_service();
    init_notification_settings_service();
    init_translation_config();
    init_artemis_translate_pipe();
    init_notification_service();
    init_notification_settings_service();
    init_exam_exercise_update_service();
    init_alert_service();
    init_exam_participation_service();
    init_artemis_translate_pipe();
    init_translate_directive();
    _c07 = ["scrollContainer"];
    conversationMessageNotificationTitles = [
      MENTIONED_IN_MESSAGE_TITLE,
      NEW_ANNOUNCEMENT_POST_TITLE,
      NEW_MESSAGE_TITLE,
      NEW_REPLY_MESSAGE_TITLE,
      NEW_EXERCISE_POST_TITLE,
      NEW_LECTURE_POST_TITLE,
      NEW_EXAM_POST_TITLE,
      NEW_COURSE_POST_TITLE,
      NEW_REPLY_FOR_EXERCISE_POST_TITLE,
      NEW_REPLY_FOR_LECTURE_POST_TITLE,
      NEW_REPLY_FOR_EXAM_POST_TITLE,
      NEW_REPLY_FOR_COURSE_POST_TITLE
    ];
    NotificationPopupComponent = class _NotificationPopupComponent {
      notificationService;
      router;
      activatedRoute;
      notificationSettingsService;
      examExerciseUpdateService;
      alertService;
      examParticipationService;
      artemisTranslatePipe;
      notifications = [];
      LiveExamExerciseUpdateNotificationTitleHtmlConst = LIVE_EXAM_EXERCISE_UPDATE_NOTIFICATION_TITLE;
      QuizNotificationTitleHtmlConst = "Quiz started";
      scrollContainer;
      studentExamExerciseIds;
      maxNotificationLength = 150;
      faTimes = faTimes3;
      faMessage = faMessage;
      faCheckDouble = faCheckDouble;
      faExclamationTriangle = faExclamationTriangle2;
      constructor(notificationService, router, activatedRoute, notificationSettingsService, examExerciseUpdateService, alertService, examParticipationService, artemisTranslatePipe) {
        this.notificationService = notificationService;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.notificationSettingsService = notificationSettingsService;
        this.examExerciseUpdateService = examExerciseUpdateService;
        this.alertService = alertService;
        this.examParticipationService = examParticipationService;
        this.artemisTranslatePipe = artemisTranslatePipe;
      }
      ngOnInit() {
        this.notificationService.subscribeToSingleIncomingNotifications().subscribe((notification) => {
          this.addNotification(notification);
        });
      }
      removeNotification(index) {
        this.notifications.splice(index, 1);
      }
      navigateToTarget(notification) {
        const currentCourseId = this.activatedRoute.snapshot.queryParams["courseId"];
        const target = JSON.parse(notification.target);
        const targetCourseId = target.course;
        const targetConversationId = target.conversation;
        if (notification.title === LIVE_EXAM_EXERCISE_UPDATE_NOTIFICATION_TITLE) {
          this.examExerciseUpdateService.navigateToExamExercise(target.exercise);
        } else if (notification.title && conversationMessageNotificationTitles.includes(notification.title)) {
          const queryParams = MetisConversationService.getQueryParamsForConversation(targetConversationId);
          queryParams.messageId = target.id;
          const routeComponents = MetisConversationService.getLinkForConversation(targetCourseId);
          if (currentCourseId === void 0 || currentCourseId !== targetCourseId || this.isUnderMessagesTabOfSpecificCourse(targetCourseId)) {
            this.notificationService.forceComponentReload(routeComponents, queryParams);
          } else {
            this.router.navigate(routeComponents, { queryParams });
          }
        } else {
          this.router.navigateByUrl(this.notificationTargetRoute(notification));
        }
      }
      getNotificationTitleTranslation(notification) {
        const translation = this.artemisTranslatePipe.transform(notification.title);
        if (translation?.includes(translationNotFoundMessage)) {
          return notification.title ?? "No title found";
        }
        return translation;
      }
      getNotificationTextTranslation(notification) {
        return this.notificationService.getNotificationTextTranslation(notification, this.maxNotificationLength);
      }
      notificationTargetRoute(notification) {
        if (notification.target) {
          const target = JSON.parse(notification.target);
          if (notification.title === LIVE_EXAM_EXERCISE_UPDATE_NOTIFICATION_TITLE) {
            return this.router.createUrlTree([target.mainPage, target.course, target.entity, target.exam]);
          } else if (notification.title === QUIZ_EXERCISE_STARTED_TITLE && target.status) {
            return this.router.createUrlTree([target.mainPage, target.course, target.entity, target.id, target.status]);
          } else {
            return this.router.createUrlTree([target.mainPage, target.course, target.entity, target.id]);
          }
        }
        return this.router.url;
      }
      addNotification(notification) {
        if (notification && !this.notifications.some(({ id }) => notification.id && id === notification.id)) {
          if (notification.title === QUIZ_EXERCISE_STARTED_TITLE) {
            this.addQuizNotification(notification);
            this.setRemovalTimeout(notification);
          }
          if (notification.title === LIVE_EXAM_EXERCISE_UPDATE_NOTIFICATION_TITLE) {
            this.checkIfNotificationAffectsCurrentStudentExamExercises(notification);
          }
          if (notification.title && conversationMessageNotificationTitles.includes(notification.title)) {
            if (this.notificationSettingsService.isNotificationAllowedBySettings(notification)) {
              this.addMessageNotification(notification);
              this.setRemovalTimeout(notification, 15);
            }
          }
        }
      }
      addMessageNotification(notification) {
        if (notification.target) {
          const target = JSON.parse(notification.target);
          if (!this.isUnderMessagesTabOfSpecificCourse(target.course)) {
            this.displayNotification(notification);
          }
        }
      }
      displayNotification(notification) {
        this.notifications.push(notification);
        setTimeout(() => {
          if (this.scrollContainer?.nativeElement) {
            this.scrollContainer.nativeElement.scrollTop = this.scrollContainer.nativeElement.scrollHeight;
          }
        });
      }
      isUnderMessagesTabOfSpecificCourse(targetCourseId) {
        return this.router.url.includes(`courses/${targetCourseId}/messages`);
      }
      addQuizNotification(notification) {
        if (notification.target) {
          const target = JSON.parse(notification.target);
          target.entity = "quiz-exercises";
          target.status = "live";
          const notificationWithLiveQuizTarget = {
            target: JSON.stringify(target)
          };
          const matchOptions = { paths: "exact", queryParams: "exact", fragment: "ignored", matrixParams: "ignored" };
          if (!this.router.isActive(this.notificationTargetRoute(notification), matchOptions) && !this.router.isActive(this.notificationTargetRoute(notificationWithLiveQuizTarget) + "/live", matchOptions)) {
            notification.target = notificationWithLiveQuizTarget.target;
            this.displayNotification(notification);
          }
        }
      }
      addExamUpdateNotification(notification) {
        try {
          const target = JSON.parse(notification.target);
          this.examExerciseUpdateService.updateLiveExamExercise(target.exercise, target.problemStatement);
        } catch (error) {
          this.alertService.error(error);
        }
        const matchOptions = { paths: "exact", queryParams: "exact", fragment: "ignored", matrixParams: "ignored" };
        if (notification.text != void 0 && this.router.isActive(this.notificationTargetRoute(notification), matchOptions)) {
          this.displayNotification(notification);
        }
      }
      checkIfNotificationAffectsCurrentStudentExamExercises(notification) {
        if (!notification.target) {
          return;
        }
        const target = JSON.parse(notification.target);
        const exerciseId = target.exercise;
        if (!this.studentExamExerciseIds) {
          this.studentExamExerciseIds = this.examParticipationService.getExamExerciseIds();
          if (!this.studentExamExerciseIds) {
            return;
          }
        }
        const updatedExerciseIsPartOfStudentExam = this.studentExamExerciseIds?.find((exerciseIdentifier) => exerciseIdentifier === exerciseId);
        if (updatedExerciseIsPartOfStudentExam) {
          this.addExamUpdateNotification(notification);
          this.setRemovalTimeout(notification);
        }
      }
      setRemovalTimeout(notification, timeoutInSec = 30) {
        setTimeout(() => {
          this.notifications = this.notifications.filter(({ id }) => id !== notification.id);
        }, timeoutInSec * 1e3);
      }
      static \u0275fac = function NotificationPopupComponent_Factory(t) {
        return new (t || _NotificationPopupComponent)(i014.\u0275\u0275directiveInject(NotificationService), i014.\u0275\u0275directiveInject(i26.Router), i014.\u0275\u0275directiveInject(i26.ActivatedRoute), i014.\u0275\u0275directiveInject(NotificationSettingsService), i014.\u0275\u0275directiveInject(ExamExerciseUpdateService), i014.\u0275\u0275directiveInject(AlertService), i014.\u0275\u0275directiveInject(ExamParticipationService), i014.\u0275\u0275directiveInject(ArtemisTranslatePipe));
      };
      static \u0275cmp = i014.\u0275\u0275defineComponent({ type: _NotificationPopupComponent, selectors: [["jhi-notification-popup"]], viewQuery: function NotificationPopupComponent_Query(rf, ctx) {
        if (rf & 1) {
          i014.\u0275\u0275viewQuery(_c07, 5);
        }
        if (rf & 2) {
          let _t;
          i014.\u0275\u0275queryRefresh(_t = i014.\u0275\u0275loadQuery()) && (ctx.scrollContainer = _t.first);
        }
      }, decls: 6, vars: 0, consts: [[1, "notification-popup-container"], ["scrollContainer", ""], [3, "click"], [1, "icon-container", "d-flex", "flex-column", "justify-content-center", "p-4"], [1, "pe-4", "py-3"], [1, "m-0", "px-1", "py-0", 3, "click"], [3, "icon"], [1, "text-break"], [1, "text-end"], [1, "text-info", 3, "icon"], [1, "pe-4"], ["jhiTranslate", "global.title"]], template: function NotificationPopupComponent_Template(rf, ctx) {
        if (rf & 1) {
          i014.\u0275\u0275elementStart(0, "div", 0, 1);
          i014.\u0275\u0275text(2, "\n    ");
          i014.\u0275\u0275repeaterCreate(3, NotificationPopupComponent_For_4_Template, 28, 8, null, null, i014.\u0275\u0275repeaterTrackByIdentity);
          i014.\u0275\u0275elementEnd();
          i014.\u0275\u0275text(5, "\n");
        }
        if (rf & 2) {
          i014.\u0275\u0275advance(3);
          i014.\u0275\u0275repeater(ctx.notifications);
        }
      }, dependencies: [i82.FaIconComponent, TranslateDirective, ArtemisTranslatePipe], styles: ["\n\n.notification-popup-container[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 20px;\n  right: 0;\n  z-index: 998;\n  overflow-y: auto;\n  max-height: calc(100vh - 20px);\n}\n.notification-popup-container[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%] {\n  cursor: pointer;\n  position: relative;\n  color: #aaa;\n  display: flex;\n  max-width: 360px;\n  margin-bottom: 10px;\n  background-color: #292929;\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n  box-shadow: 0 3px 5px 0 rgba(0, 0, 0, 0.5);\n}\n.notification-popup-container[_ngcontent-%COMP%]    > div.hide[_ngcontent-%COMP%] {\n  display: none;\n}\n.icon-container[_ngcontent-%COMP%] {\n  font-size: 1.75rem;\n  color: #3e8acc;\n}\nh5[_ngcontent-%COMP%] {\n  color: #eaeaea;\n}\nbutton[_ngcontent-%COMP%] {\n  font-size: 1.15rem;\n  color: #aaa;\n  position: absolute;\n  top: 14px;\n  right: 24px;\n  border: 0;\n  background-color: transparent;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL25vdGlmaWNhdGlvbi1wb3B1cC9ub3RpZmljYXRpb24tcG9wdXAuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLm5vdGlmaWNhdGlvbi1wb3B1cC1jb250YWluZXIge1xuICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICBib3R0b206IDIwcHg7XG4gICAgcmlnaHQ6IDA7XG4gICAgei1pbmRleDogOTk4O1xuICAgIG92ZXJmbG93LXk6IGF1dG87XG4gICAgbWF4LWhlaWdodDogY2FsYygxMDB2aCAtIDIwcHgpO1xufVxuXG4ubm90aWZpY2F0aW9uLXBvcHVwLWNvbnRhaW5lciA+IGRpdiB7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBjb2xvcjogI2FhYTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIG1heC13aWR0aDogMzYwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjkyOTI5O1xuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1cHg7XG4gICAgYm94LXNoYWRvdzogMCAzcHggNXB4IDAgcmdiYSgwLCAwLCAwLCAwLjUpO1xufVxuXG4ubm90aWZpY2F0aW9uLXBvcHVwLWNvbnRhaW5lciA+IGRpdi5oaWRlIHtcbiAgICBkaXNwbGF5OiBub25lO1xufVxuXG4uaWNvbi1jb250YWluZXIge1xuICAgIGZvbnQtc2l6ZTogMS43NXJlbTtcbiAgICBjb2xvcjogIzNlOGFjYztcbn1cblxuaDUge1xuICAgIGNvbG9yOiAjZWFlYWVhO1xufVxuXG5idXR0b24ge1xuICAgIGZvbnQtc2l6ZTogMS4xNXJlbTtcbiAgICBjb2xvcjogI2FhYTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAxNHB4O1xuICAgIHJpZ2h0OiAyNHB4O1xuICAgIGJvcmRlcjogMDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksWUFBQTtBQUNBLFVBQUE7QUFDQSxTQUFBO0FBQ0EsV0FBQTtBQUNBLGNBQUE7QUFDQSxjQUFBLEtBQUEsTUFBQSxFQUFBOztBQUdKLENBVEEsNkJBU0EsRUFBQTtBQUNJLFVBQUE7QUFDQSxZQUFBO0FBQ0EsU0FBQTtBQUNBLFdBQUE7QUFDQSxhQUFBO0FBQ0EsaUJBQUE7QUFDQSxvQkFBQTtBQUNBLDBCQUFBO0FBQ0EsNkJBQUE7QUFDQSxjQUFBLEVBQUEsSUFBQSxJQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQTs7QUFHSixDQXRCQSw2QkFzQkEsRUFBQSxHQUFBLENBQUE7QUFDSSxXQUFBOztBQUdKLENBQUE7QUFDSSxhQUFBO0FBQ0EsU0FBQTs7QUFHSjtBQUNJLFNBQUE7O0FBR0o7QUFDSSxhQUFBO0FBQ0EsU0FBQTtBQUNBLFlBQUE7QUFDQSxPQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxvQkFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i014.\u0275setClassDebugInfo(NotificationPopupComponent, { className: "NotificationPopupComponent" });
    })();
  }
});

// src/main/webapp/app/shared/layouts/main/main.component.ts
import { Component as Component12, Inject, Renderer2 as Renderer25 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NavigationEnd as NavigationEnd2, NavigationError, NavigationStart, Router as Router5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { DOCUMENT } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i015 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i27 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function JhiMainComponent_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i015.\u0275\u0275text(0, "\n        ");
    i015.\u0275\u0275elementStart(1, "div");
    i015.\u0275\u0275text(2, "\n            ");
    i015.\u0275\u0275element(3, "router-outlet", 1);
    i015.\u0275\u0275text(4, "\n        ");
    i015.\u0275\u0275elementEnd();
    i015.\u0275\u0275text(5, "\n    ");
  }
}
function JhiMainComponent_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i015.\u0275\u0275text(0, "\n        ");
    i015.\u0275\u0275elementStart(1, "div", 2);
    i015.\u0275\u0275text(2, "\n            ");
    i015.\u0275\u0275elementStart(3, "div", 3);
    i015.\u0275\u0275text(4, "\n                ");
    i015.\u0275\u0275element(5, "router-outlet");
    i015.\u0275\u0275text(6, "\n            ");
    i015.\u0275\u0275elementEnd();
    i015.\u0275\u0275text(7, "\n        ");
    i015.\u0275\u0275elementEnd();
    i015.\u0275\u0275text(8, "\n    ");
  }
}
function JhiMainComponent_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i015.\u0275\u0275text(0, "\n        ");
    i015.\u0275\u0275element(1, "router-outlet");
    i015.\u0275\u0275text(2, "\n    ");
  }
}
function JhiMainComponent_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i015.\u0275\u0275text(0, "\n        ");
    i015.\u0275\u0275elementStart(1, "div");
    i015.\u0275\u0275text(2, "\n            ");
    i015.\u0275\u0275element(3, "jhi-footer");
    i015.\u0275\u0275text(4, "\n        ");
    i015.\u0275\u0275elementEnd();
    i015.\u0275\u0275text(5, "\n    ");
  }
}
var JhiMainComponent;
var init_main_component = __esm({
  "src/main/webapp/app/shared/layouts/main/main.component.ts"() {
    init_language_helper();
    init_profile_service();
    init_sentry_error_handler();
    init_theme_service();
    init_language_helper();
    init_profile_service();
    init_sentry_error_handler();
    init_theme_service();
    init_alert_overlay_component();
    init_page_ribbon_component();
    init_footer_component();
    init_notification_popup_component();
    JhiMainComponent = class _JhiMainComponent {
      jhiLanguageHelper;
      router;
      profileService;
      sentryErrorHandler;
      themeService;
      document;
      renderer;
      showSkeleton = true;
      constructor(jhiLanguageHelper, router, profileService, sentryErrorHandler, themeService, document2, renderer) {
        this.jhiLanguageHelper = jhiLanguageHelper;
        this.router = router;
        this.profileService = profileService;
        this.sentryErrorHandler = sentryErrorHandler;
        this.themeService = themeService;
        this.document = document2;
        this.renderer = renderer;
        this.setupErrorHandling().then(null);
      }
      setupErrorHandling() {
        return __async(this, null, function* () {
          this.profileService.getProfileInfo().subscribe((profileInfo) => {
            this.sentryErrorHandler.initSentry(profileInfo);
          });
        });
      }
      getPageTitle(routeSnapshot) {
        const title = routeSnapshot.data["pageTitle"] ?? "artemisApp";
        if (routeSnapshot.firstChild) {
          return this.getPageTitle(routeSnapshot.firstChild) || title;
        }
        return title;
      }
      ngOnInit() {
        this.router.events.subscribe((event) => {
          if (event instanceof NavigationStart) {
            const shouldShowSkeletonNow = this.shouldShowSkeleton(event.url);
            if (!shouldShowSkeletonNow && this.showSkeleton) {
              this.renderer.addClass(this.document.body, "transparent-background");
            } else if (shouldShowSkeletonNow && !this.showSkeleton) {
              this.renderer.removeClass(this.document.body, "transparent-background");
            }
            this.showSkeleton = shouldShowSkeletonNow;
          }
          if (event instanceof NavigationEnd2) {
            this.jhiLanguageHelper.updateTitle(this.getPageTitle(this.router.routerState.snapshot.root));
          }
          if (event instanceof NavigationError && event.error.status === 404) {
            this.router.navigate(["/404"]);
          }
        });
        this.themeService.initialize();
      }
      shouldShowSkeleton(url) {
        const isStandaloneProblemStatement = url.match("\\/courses\\/\\d+\\/exercises\\/\\d+\\/problem-statement(\\/\\d*)?(\\/)?");
        const isStandaloneFeedback = url.match("\\/courses\\/\\d+\\/exercises\\/\\d+\\/participations\\/\\d+\\/results\\/\\d+\\/feedback(\\/)?");
        return !isStandaloneProblemStatement && !isStandaloneFeedback;
      }
      static \u0275fac = function JhiMainComponent_Factory(t) {
        return new (t || _JhiMainComponent)(i015.\u0275\u0275directiveInject(JhiLanguageHelper), i015.\u0275\u0275directiveInject(i27.Router), i015.\u0275\u0275directiveInject(ProfileService), i015.\u0275\u0275directiveInject(SentryErrorHandler), i015.\u0275\u0275directiveInject(ThemeService), i015.\u0275\u0275directiveInject(DOCUMENT), i015.\u0275\u0275directiveInject(i015.Renderer2));
      };
      static \u0275cmp = i015.\u0275\u0275defineComponent({ type: _JhiMainComponent, selectors: [["jhi-main"]], decls: 13, vars: 4, consts: [[1, "page-wrapper"], ["name", "navbar"], [1, "card", 2, "border-style", "none"], [1, "card-body"]], template: function JhiMainComponent_Template(rf, ctx) {
        if (rf & 1) {
          i015.\u0275\u0275element(0, "jhi-alert-overlay");
          i015.\u0275\u0275text(1, "\n");
          i015.\u0275\u0275elementStart(2, "div", 0);
          i015.\u0275\u0275text(3, "\n    ");
          i015.\u0275\u0275element(4, "jhi-page-ribbon");
          i015.\u0275\u0275text(5, "\n    ");
          i015.\u0275\u0275template(6, JhiMainComponent_Conditional_6_Template, 6, 0)(7, JhiMainComponent_Conditional_7_Template, 9, 0)(8, JhiMainComponent_Conditional_8_Template, 3, 0);
          i015.\u0275\u0275element(9, "jhi-notification-popup");
          i015.\u0275\u0275text(10, "\n    ");
          i015.\u0275\u0275template(11, JhiMainComponent_Conditional_11_Template, 6, 0);
          i015.\u0275\u0275elementEnd();
          i015.\u0275\u0275text(12, "\n");
        }
        if (rf & 2) {
          i015.\u0275\u0275advance(6);
          i015.\u0275\u0275conditional(6, ctx.showSkeleton ? 6 : -1);
          i015.\u0275\u0275advance(1);
          i015.\u0275\u0275conditional(7, ctx.showSkeleton ? 7 : -1);
          i015.\u0275\u0275advance(1);
          i015.\u0275\u0275conditional(8, !ctx.showSkeleton ? 8 : -1);
          i015.\u0275\u0275advance(3);
          i015.\u0275\u0275conditional(11, ctx.showSkeleton ? 11 : -1);
        }
      }, dependencies: [AlertOverlayComponent, i27.RouterOutlet, PageRibbonComponent, FooterComponent, NotificationPopupComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i015.\u0275setClassDebugInfo(JhiMainComponent, { className: "JhiMainComponent" });
    })();
  }
});

// src/main/webapp/app/guided-tour/guided-tour.module.ts
import { NgModule as NgModule3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i016 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var GuidedTourModule;
var init_guided_tour_module = __esm({
  "src/main/webapp/app/guided-tour/guided-tour.module.ts"() {
    init_shared_module();
    init_guided_tour_component();
    GuidedTourModule = class _GuidedTourModule {
      static \u0275fac = function GuidedTourModule_Factory(t) {
        return new (t || _GuidedTourModule)();
      };
      static \u0275mod = i016.\u0275\u0275defineNgModule({ type: _GuidedTourModule });
      static \u0275inj = i016.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule] });
    };
  }
});

// src/main/webapp/app/home/saml2-login/saml2-login.component.ts
import { Component as Component13, Input as Input3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i017 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var Saml2LoginComponent;
var init_saml2_login_component = __esm({
  "src/main/webapp/app/home/saml2-login/saml2-login.component.ts"() {
    init_login_service();
    init_saml2_config();
    init_event_manager_service();
    init_alert_service();
    init_login_service();
    init_event_manager_service();
    init_alert_service();
    Saml2LoginComponent = class _Saml2LoginComponent {
      loginService;
      eventManager;
      alertService;
      rememberMe = true;
      acceptedTerms = false;
      saml2Profile;
      constructor(loginService, eventManager, alertService) {
        this.loginService = loginService;
        this.eventManager = eventManager;
        this.alertService = alertService;
      }
      ngOnInit() {
        if (document.cookie.indexOf("SAML2flow=") >= 0) {
          document.cookie = "SAML2flow=; expires=Thu, 01 Jan 1970 00:00:00 UTC; ; SameSite=Lax;";
          this.loginSAML2();
        }
      }
      loginSAML2() {
        this.loginService.loginSAML2(this.rememberMe).then(() => {
          this.eventManager.broadcast({
            name: "authenticationSuccess",
            content: "Sending Authentication Success"
          });
        }).catch((error) => {
          if (error.status === 401) {
            document.cookie = "SAML2flow=true; max-age=120; SameSite=Lax;";
            window.location.replace("/saml2/authenticate");
          } else if (error.status === 403) {
            let message = "Forbidden";
            const details = error.headers.get("X-artemisApp-error");
            if (details) {
              message += ": " + details;
            }
            this.alertService.warning(message);
          }
        });
      }
      static \u0275fac = function Saml2LoginComponent_Factory(t) {
        return new (t || _Saml2LoginComponent)(i017.\u0275\u0275directiveInject(LoginService), i017.\u0275\u0275directiveInject(EventManager), i017.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i017.\u0275\u0275defineComponent({ type: _Saml2LoginComponent, selectors: [["jhi-saml2-login"]], inputs: { rememberMe: "rememberMe", acceptedTerms: "acceptedTerms", saml2Profile: "saml2Profile" }, decls: 6, vars: 2, consts: [["type", "button", "id", "saml2Button", 1, "btn", "btn-primary", "btn-lg", 3, "disabled", "click"]], template: function Saml2LoginComponent_Template(rf, ctx) {
        if (rf & 1) {
          i017.\u0275\u0275elementStart(0, "button", 0);
          i017.\u0275\u0275listener("click", function Saml2LoginComponent_Template_button_click_0_listener() {
            return ctx.loginSAML2();
          });
          i017.\u0275\u0275text(1, "\n    ");
          i017.\u0275\u0275elementStart(2, "span");
          i017.\u0275\u0275text(3);
          i017.\u0275\u0275elementEnd();
          i017.\u0275\u0275text(4, "\n");
          i017.\u0275\u0275elementEnd();
          i017.\u0275\u0275text(5, "\n");
        }
        if (rf & 2) {
          i017.\u0275\u0275property("disabled", !ctx.acceptedTerms);
          i017.\u0275\u0275advance(3);
          i017.\u0275\u0275textInterpolate(ctx.saml2Profile.buttonLabel || "SAML2 Login");
        }
      }, encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i017.\u0275setClassDebugInfo(Saml2LoginComponent, { className: "Saml2LoginComponent" });
    })();
  }
});

// src/main/webapp/app/home/home.component.ts
import { Component as Component14, ElementRef as ElementRef5, Renderer2 as Renderer27 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgbModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute11, Router as Router7 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { faCircleNotch as faCircleNotch3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i018 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i15 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i83 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i11 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i122 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function HomeComponent_Conditional_16_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275text(0, "\n                    ");
    i018.\u0275\u0275elementStart(1, "div", 24);
    i018.\u0275\u0275text(2, "Please sign in with your account.");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(3, "\n                ");
  }
  if (rf & 2) {
    i018.\u0275\u0275advance(1);
    i018.\u0275\u0275property("jhiTranslate", "home.login.traditional.pleaseSignIn");
  }
}
function HomeComponent_Conditional_16_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275text(0, "\n                    ");
    i018.\u0275\u0275elementStart(1, "div", 25);
    i018.\u0275\u0275text(2, "\n                        Please sign in with your account.\n                    ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(3, "\n                ");
  }
  if (rf & 2) {
    const ctx_r4 = i018.\u0275\u0275nextContext(2);
    i018.\u0275\u0275advance(1);
    i018.\u0275\u0275property("jhiTranslate", "home.login.traditional.pleaseSignInAccount")("translateValues", i018.\u0275\u0275pureFunction1(2, _c08, ctx_r4.accountName));
  }
}
function HomeComponent_Conditional_16_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275text(0, "\n                                ");
    i018.\u0275\u0275elementStart(1, "div", 26);
    i018.\u0275\u0275text(2, "\n                                    ");
    i018.\u0275\u0275elementStart(3, "span", 27);
    i018.\u0275\u0275text(4, "Failed to sign in!");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(5, " Please check your username and password and try again.\n                                ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(6, "\n                            ");
  }
}
function HomeComponent_Conditional_16_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275text(0, "\n                                ");
    i018.\u0275\u0275elementStart(1, "div", 28);
    i018.\u0275\u0275text(2, "\n                                    ");
    i018.\u0275\u0275element(3, "span", 29);
    i018.\u0275\u0275pipe(4, "artemisTranslate");
    i018.\u0275\u0275text(5, "\n                                ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(6, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r6 = i018.\u0275\u0275nextContext(2);
    i018.\u0275\u0275advance(3);
    i018.\u0275\u0275property("innerHTML", i018.\u0275\u0275pipeBind2(4, 1, "home.errors.loginWarning", i018.\u0275\u0275pureFunction2(4, _c16, ctx_r6.externalUserManagementUrl, ctx_r6.externalUserManagementName)), i018.\u0275\u0275sanitizeHtml);
  }
}
function HomeComponent_Conditional_16_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275text(0, "\n                                ");
    i018.\u0275\u0275elementStart(1, "div", 30);
    i018.\u0275\u0275text(2, "\n                                    ");
    i018.\u0275\u0275element(3, "span", 29);
    i018.\u0275\u0275pipe(4, "artemisTranslate");
    i018.\u0275\u0275text(5, "\n                                ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(6, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r7 = i018.\u0275\u0275nextContext(2);
    i018.\u0275\u0275advance(3);
    i018.\u0275\u0275property("innerHTML", i018.\u0275\u0275pipeBind2(4, 1, "home.errors.externalUserManagementWarning", i018.\u0275\u0275pureFunction2(4, _c16, ctx_r7.externalUserManagementUrl, ctx_r7.externalUserManagementName)), i018.\u0275\u0275sanitizeHtml);
  }
}
function HomeComponent_Conditional_16_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275text(0, "\n                                ");
    i018.\u0275\u0275elementStart(1, "div", 31);
    i018.\u0275\u0275text(2, "\n                                    ");
    i018.\u0275\u0275elementStart(3, "p", 32);
    i018.\u0275\u0275text(4, "Invalid username");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(5, "\n                                ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(6, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r9 = i018.\u0275\u0275nextContext(2);
    i018.\u0275\u0275advance(1);
    i018.\u0275\u0275property("jhiTranslate", ctx_r9.errorMessageUsername);
  }
}
function HomeComponent_Conditional_16_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = i018.\u0275\u0275getCurrentView();
    i018.\u0275\u0275text(0, "\n                                ");
    i018.\u0275\u0275elementStart(1, "div", 15);
    i018.\u0275\u0275text(2, "\n                                    ");
    i018.\u0275\u0275elementStart(3, "label", 33);
    i018.\u0275\u0275text(4, "\n                                        ");
    i018.\u0275\u0275elementStart(5, "input", 34);
    i018.\u0275\u0275listener("ngModelChange", function HomeComponent_Conditional_16_Conditional_49_Template_input_ngModelChange_5_listener($event) {
      i018.\u0275\u0275restoreView(_r14);
      const ctx_r13 = i018.\u0275\u0275nextContext(2);
      return i018.\u0275\u0275resetView(ctx_r13.userAcceptedTerms = $event);
    });
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(6, "\n                                        ");
    i018.\u0275\u0275elementStart(7, "a", 35);
    i018.\u0275\u0275text(8, "Accept terms");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(9, "\n                                    ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(10, "\n                                ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(11, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r10 = i018.\u0275\u0275nextContext(2);
    i018.\u0275\u0275advance(5);
    i018.\u0275\u0275property("ngModel", ctx_r10.userAcceptedTerms);
    i018.\u0275\u0275advance(2);
    i018.\u0275\u0275property("routerLink", i018.\u0275\u0275pureFunction0(2, _c24));
  }
}
function HomeComponent_Conditional_16_Conditional_55_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275text(0, "\n                                    ");
    i018.\u0275\u0275elementStart(1, "span", 36);
    i018.\u0275\u0275element(2, "fa-icon", 37);
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(3, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r11 = i018.\u0275\u0275nextContext(2);
    i018.\u0275\u0275advance(2);
    i018.\u0275\u0275property("icon", ctx_r11.faCircleNotch)("spin", true);
  }
}
function HomeComponent_Conditional_16_Conditional_64_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275text(0, "\n                            ");
    i018.\u0275\u0275elementStart(1, "div");
    i018.\u0275\u0275text(2, "\n                                ");
    i018.\u0275\u0275elementStart(3, "span", 38);
    i018.\u0275\u0275text(4, "You don't have an account yet?");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(5, "\xA0\n                                ");
    i018.\u0275\u0275elementStart(6, "a", 39);
    i018.\u0275\u0275text(7, "Register a new account");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(8, "\n                            ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(9, "\n                        ");
  }
}
function HomeComponent_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = i018.\u0275\u0275getCurrentView();
    i018.\u0275\u0275text(0, "\n            ");
    i018.\u0275\u0275elementStart(1, "div", 6);
    i018.\u0275\u0275text(2, "\n                ");
    i018.\u0275\u0275text(3, "\n                ");
    i018.\u0275\u0275template(4, HomeComponent_Conditional_16_Conditional_4_Template, 4, 1)(5, HomeComponent_Conditional_16_Conditional_5_Template, 4, 4);
    i018.\u0275\u0275elementStart(6, "div", 7);
    i018.\u0275\u0275text(7, "\n                    ");
    i018.\u0275\u0275elementStart(8, "form", 8);
    i018.\u0275\u0275listener("change", function HomeComponent_Conditional_16_Template_form_change_8_listener($event) {
      i018.\u0275\u0275restoreView(_r16);
      const ctx_r15 = i018.\u0275\u0275nextContext();
      return i018.\u0275\u0275resetView(ctx_r15.inputChange($event));
    })("ngSubmit", function HomeComponent_Conditional_16_Template_form_ngSubmit_8_listener() {
      i018.\u0275\u0275restoreView(_r16);
      const ctx_r17 = i018.\u0275\u0275nextContext();
      return i018.\u0275\u0275resetView(ctx_r17.login());
    });
    i018.\u0275\u0275text(9, "\n                        ");
    i018.\u0275\u0275elementStart(10, "div", 9);
    i018.\u0275\u0275text(11, "\n                            ");
    i018.\u0275\u0275template(12, HomeComponent_Conditional_16_Conditional_12_Template, 7, 0)(13, HomeComponent_Conditional_16_Conditional_13_Template, 7, 7)(14, HomeComponent_Conditional_16_Conditional_14_Template, 7, 7);
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(15, "\n                        ");
    i018.\u0275\u0275elementStart(16, "div", 9);
    i018.\u0275\u0275text(17, "\n                            ");
    i018.\u0275\u0275elementStart(18, "label", 10);
    i018.\u0275\u0275text(19, "Login");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(20, "\n                            ");
    i018.\u0275\u0275elementStart(21, "input", 11, 12);
    i018.\u0275\u0275listener("ngModelChange", function HomeComponent_Conditional_16_Template_input_ngModelChange_21_listener($event) {
      i018.\u0275\u0275restoreView(_r16);
      const ctx_r18 = i018.\u0275\u0275nextContext();
      return i018.\u0275\u0275resetView(ctx_r18.username = $event);
    });
    i018.\u0275\u0275pipe(23, "artemisTranslate");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(24, "\n                            ");
    i018.\u0275\u0275template(25, HomeComponent_Conditional_16_Conditional_25_Template, 7, 1);
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(26, "\n                        ");
    i018.\u0275\u0275elementStart(27, "div", 9);
    i018.\u0275\u0275text(28, "\n                            ");
    i018.\u0275\u0275elementStart(29, "label", 13);
    i018.\u0275\u0275text(30, "Password");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(31, "\n                            ");
    i018.\u0275\u0275elementStart(32, "input", 14);
    i018.\u0275\u0275listener("ngModelChange", function HomeComponent_Conditional_16_Template_input_ngModelChange_32_listener($event) {
      i018.\u0275\u0275restoreView(_r16);
      const ctx_r19 = i018.\u0275\u0275nextContext();
      return i018.\u0275\u0275resetView(ctx_r19.password = $event);
    });
    i018.\u0275\u0275pipe(33, "artemisTranslate");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(34, "\n                        ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(35, "\n                        ");
    i018.\u0275\u0275elementStart(36, "div", 9);
    i018.\u0275\u0275text(37, "\n                            ");
    i018.\u0275\u0275elementStart(38, "div", 15);
    i018.\u0275\u0275text(39, "\n                                ");
    i018.\u0275\u0275elementStart(40, "label", 16);
    i018.\u0275\u0275text(41, "\n                                    ");
    i018.\u0275\u0275elementStart(42, "input", 17);
    i018.\u0275\u0275listener("ngModelChange", function HomeComponent_Conditional_16_Template_input_ngModelChange_42_listener($event) {
      i018.\u0275\u0275restoreView(_r16);
      const ctx_r20 = i018.\u0275\u0275nextContext();
      return i018.\u0275\u0275resetView(ctx_r20.rememberMe = $event);
    });
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(43, "\n                                    ");
    i018.\u0275\u0275elementStart(44, "span", 18);
    i018.\u0275\u0275text(45, "Remember me");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(46, "\n                                ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(47, "\n                            ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(48, "\n                            ");
    i018.\u0275\u0275template(49, HomeComponent_Conditional_16_Conditional_49_Template, 12, 3);
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(50, "\n                        ");
    i018.\u0275\u0275elementStart(51, "div", 19);
    i018.\u0275\u0275text(52, "\n                            ");
    i018.\u0275\u0275elementStart(53, "button", 20);
    i018.\u0275\u0275text(54, "\n                                ");
    i018.\u0275\u0275template(55, HomeComponent_Conditional_16_Conditional_55_Template, 4, 2);
    i018.\u0275\u0275elementStart(56, "span", 21);
    i018.\u0275\u0275text(57, " Sign in ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(58, "\n                            ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(59, "\n                        ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(60, "\n                    ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(61, "\n                    ");
    i018.\u0275\u0275elementStart(62, "div", 22);
    i018.\u0275\u0275text(63, "\n                        ");
    i018.\u0275\u0275template(64, HomeComponent_Conditional_16_Conditional_64_Template, 10, 0);
    i018.\u0275\u0275elementStart(65, "a", 23);
    i018.\u0275\u0275text(66, "Did you forget your password?");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(67, "\n                    ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(68, "\n                ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(69, "\n            ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(70, "\n        ");
  }
  if (rf & 2) {
    const _r8 = i018.\u0275\u0275reference(22);
    const ctx_r0 = i018.\u0275\u0275nextContext();
    i018.\u0275\u0275advance(4);
    i018.\u0275\u0275conditional(4, !ctx_r0.accountName ? 4 : -1);
    i018.\u0275\u0275advance(1);
    i018.\u0275\u0275conditional(5, ctx_r0.accountName ? 5 : -1);
    i018.\u0275\u0275advance(7);
    i018.\u0275\u0275conditional(12, ctx_r0.authenticationError && !ctx_r0.captchaRequired ? 12 : -1);
    i018.\u0275\u0275advance(1);
    i018.\u0275\u0275conditional(13, ctx_r0.externalUserManagementActive && ctx_r0.authenticationAttempts >= 3 && !ctx_r0.captchaRequired ? 13 : -1);
    i018.\u0275\u0275advance(1);
    i018.\u0275\u0275conditional(14, ctx_r0.externalUserManagementActive && ctx_r0.captchaRequired ? 14 : -1);
    i018.\u0275\u0275advance(7);
    i018.\u0275\u0275propertyInterpolate("placeholder", i018.\u0275\u0275pipeBind1(23, 17, "global.form.username.placeholder"));
    i018.\u0275\u0275property("ngModel", ctx_r0.username)("ngModelOptions", i018.\u0275\u0275pureFunction0(21, _c33))("pattern", ctx_r0.usernameRegexPattern);
    i018.\u0275\u0275advance(4);
    i018.\u0275\u0275conditional(25, _r8.errors && (_r8.dirty || _r8.touched) ? 25 : -1);
    i018.\u0275\u0275advance(7);
    i018.\u0275\u0275propertyInterpolate("placeholder", i018.\u0275\u0275pipeBind1(33, 19, "login.form.password.placeholder"));
    i018.\u0275\u0275property("ngModel", ctx_r0.password);
    i018.\u0275\u0275advance(10);
    i018.\u0275\u0275property("ngModel", ctx_r0.rememberMe);
    i018.\u0275\u0275advance(7);
    i018.\u0275\u0275conditional(49, ctx_r0.needsToAcceptTerms ? 49 : -1);
    i018.\u0275\u0275advance(4);
    i018.\u0275\u0275property("disabled", ctx_r0.isSubmittingLogin || !ctx_r0.userAcceptedTerms && ctx_r0.needsToAcceptTerms || !ctx_r0.password || ctx_r0.password.length < ctx_r0.PASSWORD_MIN_LENGTH || !ctx_r0.username || ctx_r0.username.length < ctx_r0.USERNAME_MIN_LENGTH);
    i018.\u0275\u0275advance(2);
    i018.\u0275\u0275conditional(55, ctx_r0.isSubmittingLogin ? 55 : -1);
    i018.\u0275\u0275advance(9);
    i018.\u0275\u0275conditional(64, ctx_r0.isRegistrationEnabled ? 64 : -1);
  }
}
function HomeComponent_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275text(0, "\n            ");
    i018.\u0275\u0275elementStart(1, "div", 40);
    i018.\u0275\u0275text(2, "\n                ");
    i018.\u0275\u0275elementStart(3, "div", 41);
    i018.\u0275\u0275text(4, "or");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(5, "\n                ");
    i018.\u0275\u0275elementStart(6, "div", 42);
    i018.\u0275\u0275text(7, "or");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(8, "\n            ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(9, "\n        ");
  }
}
function HomeComponent_Conditional_18_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275text(0, "\n                        ");
    i018.\u0275\u0275elementStart(1, "div", 24);
    i018.\u0275\u0275text(2, "Please sign in via Single Sign-on.");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    i018.\u0275\u0275advance(1);
    i018.\u0275\u0275property("jhiTranslate", "home.login.saml2.pleaseSignIn");
  }
}
function HomeComponent_Conditional_18_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275text(0, "\n                        ");
    i018.\u0275\u0275elementStart(1, "div", 25);
    i018.\u0275\u0275text(2, "\n                            Please sign in.\n                        ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r22 = i018.\u0275\u0275nextContext(2);
    i018.\u0275\u0275advance(1);
    i018.\u0275\u0275property("jhiTranslate", "home.login.saml2.pleaseSignInProvider")("translateValues", i018.\u0275\u0275pureFunction1(2, _c42, ctx_r22.profileInfo.saml2.identityProviderName));
  }
}
function HomeComponent_Conditional_18_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r25 = i018.\u0275\u0275getCurrentView();
    i018.\u0275\u0275text(0, "\n                                ");
    i018.\u0275\u0275elementStart(1, "div", 15);
    i018.\u0275\u0275text(2, "\n                                    ");
    i018.\u0275\u0275elementStart(3, "label", 33);
    i018.\u0275\u0275text(4, "\n                                        ");
    i018.\u0275\u0275elementStart(5, "input", 47);
    i018.\u0275\u0275listener("ngModelChange", function HomeComponent_Conditional_18_Conditional_12_Template_input_ngModelChange_5_listener($event) {
      i018.\u0275\u0275restoreView(_r25);
      const ctx_r24 = i018.\u0275\u0275nextContext(2);
      return i018.\u0275\u0275resetView(ctx_r24.userAcceptedTerms = $event);
    });
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(6, "\n                                        ");
    i018.\u0275\u0275elementStart(7, "a", 35);
    i018.\u0275\u0275text(8, "Accept terms");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(9, "\n                                    ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(10, "\n                                ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(11, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r23 = i018.\u0275\u0275nextContext(2);
    i018.\u0275\u0275advance(5);
    i018.\u0275\u0275property("ngModel", ctx_r23.userAcceptedTerms);
    i018.\u0275\u0275advance(2);
    i018.\u0275\u0275property("routerLink", i018.\u0275\u0275pureFunction0(2, _c24));
  }
}
function HomeComponent_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i018.\u0275\u0275text(0, "\n            ");
    i018.\u0275\u0275elementStart(1, "div", 43);
    i018.\u0275\u0275text(2, "\n                ");
    i018.\u0275\u0275text(3, "\n                ");
    i018.\u0275\u0275elementStart(4, "div", 44);
    i018.\u0275\u0275text(5, "\n                    ");
    i018.\u0275\u0275template(6, HomeComponent_Conditional_18_Conditional_6_Template, 4, 1)(7, HomeComponent_Conditional_18_Conditional_7_Template, 4, 4);
    i018.\u0275\u0275elementStart(8, "div", 45);
    i018.\u0275\u0275text(9, "\n                        ");
    i018.\u0275\u0275elementStart(10, "div", 9);
    i018.\u0275\u0275text(11, "\n                            ");
    i018.\u0275\u0275template(12, HomeComponent_Conditional_18_Conditional_12_Template, 12, 3);
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(13, "\n                        ");
    i018.\u0275\u0275element(14, "jhi-saml2-login", 46);
    i018.\u0275\u0275text(15, "\n                    ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(16, "\n                ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(17, "\n            ");
    i018.\u0275\u0275elementEnd();
    i018.\u0275\u0275text(18, "\n        ");
  }
  if (rf & 2) {
    const ctx_r2 = i018.\u0275\u0275nextContext();
    i018.\u0275\u0275advance(6);
    i018.\u0275\u0275conditional(6, !ctx_r2.profileInfo.saml2.identityProviderName ? 6 : -1);
    i018.\u0275\u0275advance(1);
    i018.\u0275\u0275conditional(7, ctx_r2.profileInfo.saml2.identityProviderName ? 7 : -1);
    i018.\u0275\u0275advance(5);
    i018.\u0275\u0275conditional(12, ctx_r2.needsToAcceptTerms ? 12 : -1);
    i018.\u0275\u0275advance(2);
    i018.\u0275\u0275property("acceptedTerms", !ctx_r2.needsToAcceptTerms || ctx_r2.userAcceptedTerms)("rememberMe", ctx_r2.rememberMe)("saml2Profile", ctx_r2.profileInfo.saml2);
  }
}
var _c08, _c16, _c24, _c33, _c42, HomeComponent;
var init_home_component = __esm({
  "src/main/webapp/app/home/home.component.ts"() {
    init_guided_tour_service();
    init_orion_connector_service();
    init_orion();
    init_modal_confirm_autofocus_component();
    init_account_service();
    init_login_service();
    init_profile_service();
    init_state_storage_service();
    init_app_constants();
    init_event_manager_service();
    init_alert_service();
    init_account_service();
    init_login_service();
    init_state_storage_service();
    init_event_manager_service();
    init_guided_tour_service();
    init_orion_connector_service();
    init_profile_service();
    init_alert_service();
    init_translate_directive();
    init_saml2_login_component();
    init_artemis_translate_pipe();
    _c08 = (a0) => ({ account: a0 });
    _c16 = (a0, a1) => ({ url: a0, name: a1 });
    _c24 = () => ["privacy"];
    _c33 = () => ({ updateOn: "blur" });
    _c42 = (a0) => ({ provider: a0 });
    HomeComponent = class _HomeComponent {
      router;
      activatedRoute;
      accountService;
      loginService;
      stateStorageService;
      elementRef;
      renderer;
      eventManager;
      guidedTourService;
      orionConnectorService;
      modalService;
      profileService;
      alertService;
      USERNAME_MIN_LENGTH = USERNAME_MIN_LENGTH;
      PASSWORD_MIN_LENGTH = PASSWORD_MIN_LENGTH;
      authenticationError = false;
      authenticationAttempts = 0;
      account;
      modalRef;
      password;
      rememberMe = true;
      needsToAcceptTerms = false;
      userAcceptedTerms = false;
      username;
      captchaRequired = false;
      credentials;
      isRegistrationEnabled = false;
      isPasswordLoginDisabled = false;
      loading = true;
      mainElementFocused = false;
      usernameRegexPattern = /^[a-z0-9_-]{3,50}$/;
      errorMessageUsername = "home.errors.usernameIncorrect";
      accountName;
      externalUserManagementActive = true;
      externalUserManagementUrl;
      externalUserManagementName;
      isSubmittingLogin = false;
      profileInfo = void 0;
      faCircleNotch = faCircleNotch3;
      constructor(router, activatedRoute, accountService, loginService, stateStorageService, elementRef, renderer, eventManager, guidedTourService, orionConnectorService, modalService, profileService, alertService) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.accountService = accountService;
        this.loginService = loginService;
        this.stateStorageService = stateStorageService;
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.eventManager = eventManager;
        this.guidedTourService = guidedTourService;
        this.orionConnectorService = orionConnectorService;
        this.modalService = modalService;
        this.profileService = profileService;
        this.alertService = alertService;
      }
      ngOnInit() {
        this.profileService.getProfileInfo().subscribe((profileInfo) => {
          if (profileInfo) {
            this.initializeWithProfileInfo(profileInfo);
          }
        });
        this.accountService.identity().then((user) => {
          this.currentUserCallback(user);
          if (!user) {
            this.loading = false;
          }
        });
        this.registerAuthenticationSuccess();
        const prefilledUsername = this.accountService.getAndClearPrefilledUsername();
        if (prefilledUsername) {
          this.username = prefilledUsername;
        }
      }
      initializeWithProfileInfo(profileInfo) {
        this.profileInfo = profileInfo;
        if (profileInfo.activeProfiles.includes("jira")) {
          this.externalUserManagementUrl = profileInfo.externalUserManagementURL;
          this.externalUserManagementName = profileInfo.externalUserManagementName;
          if (profileInfo.allowedLdapUsernamePattern) {
            this.usernameRegexPattern = new RegExp(profileInfo.allowedLdapUsernamePattern);
          }
        } else {
          this.externalUserManagementActive = false;
        }
        this.accountName = profileInfo.accountName;
        if (this.accountName === "TUM") {
          this.errorMessageUsername = "home.errors.tumWarning";
        }
        this.isRegistrationEnabled = !!profileInfo.registrationEnabled;
        this.needsToAcceptTerms = !!profileInfo.needsToAcceptTerms;
        this.activatedRoute.queryParams.subscribe((params) => {
          const loginFormOverride = params.hasOwnProperty("showLoginForm");
          this.isPasswordLoginDisabled = !!this.profileInfo?.saml2 && this.profileInfo.saml2.passwordLoginDisabled && !loginFormOverride;
        });
      }
      registerAuthenticationSuccess() {
        const subscription = this.eventManager.subscribe("authenticationSuccess", () => {
          this.eventManager.destroy(subscription);
          this.accountService.identity().then((user) => {
            this.currentUserCallback(user);
          });
        });
      }
      ngAfterViewChecked() {
        if (this.mainElementFocused || this.loading) {
          return;
        }
        const mainElement = this.renderer.selectRootElement(this.isPasswordLoginDisabled ? "#saml2Button" : "#username", true);
        if (mainElement) {
          mainElement.focus();
          this.mainElementFocused = true;
        }
        if (this.loginService.lastLogoutWasForceful()) {
          this.alertService.error("home.errors.sessionExpired");
        }
      }
      login() {
        this.isSubmittingLogin = true;
        this.loginService.login({
          username: this.username,
          password: this.password,
          rememberMe: this.rememberMe
        }).then(() => this.handleLoginSuccess()).catch((error) => {
          this.captchaRequired = error.headers.get("X-artemisApp-error") === "CAPTCHA required";
          this.authenticationError = true;
          this.authenticationAttempts++;
        }).finally(() => this.isSubmittingLogin = false);
      }
      handleLoginSuccess() {
        this.authenticationError = false;
        this.authenticationAttempts = 0;
        this.captchaRequired = false;
        if (this.router.url === "/register" || /^\/activate\//.test(this.router.url) || /^\/reset\//.test(this.router.url)) {
          this.router.navigate([""]);
        }
        this.eventManager.broadcast({
          name: "authenticationSuccess",
          content: "Sending Authentication Success"
        });
        this.handleOrionLogin();
      }
      handleOrionLogin() {
        if (!isOrion) {
          return;
        }
        const modalRef = this.modalService.open(ModalConfirmAutofocusComponent, { size: "lg", backdrop: "static" });
        modalRef.componentInstance.text = "login.ide.confirmation";
        modalRef.componentInstance.title = "login.ide.title";
        modalRef.result.then(() => this.orionConnectorService.login(this.username, this.password), () => {
        });
      }
      currentUserCallback(account) {
        this.account = account;
        if (account) {
          const redirect = this.stateStorageService.getUrl();
          if (redirect && redirect !== "") {
            this.stateStorageService.storeUrl("");
            this.router.navigateByUrl(redirect);
          } else {
            this.router.navigate(["courses"]);
          }
        }
      }
      isAuthenticated() {
        return this.accountService.isAuthenticated();
      }
      inputChange(event) {
        if (event.target && event.target.name === "username") {
          this.username = event.target.value;
        }
        if (event.target && event.target.name === "password") {
          this.password = event.target.value;
        }
      }
      static \u0275fac = function HomeComponent_Factory(t) {
        return new (t || _HomeComponent)(i018.\u0275\u0275directiveInject(i15.Router), i018.\u0275\u0275directiveInject(i15.ActivatedRoute), i018.\u0275\u0275directiveInject(AccountService), i018.\u0275\u0275directiveInject(LoginService), i018.\u0275\u0275directiveInject(StateStorageService), i018.\u0275\u0275directiveInject(i018.ElementRef), i018.\u0275\u0275directiveInject(i018.Renderer2), i018.\u0275\u0275directiveInject(EventManager), i018.\u0275\u0275directiveInject(GuidedTourService), i018.\u0275\u0275directiveInject(OrionConnectorService), i018.\u0275\u0275directiveInject(i83.NgbModal), i018.\u0275\u0275directiveInject(ProfileService), i018.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i018.\u0275\u0275defineComponent({ type: _HomeComponent, selectors: [["jhi-home"]], decls: 21, vars: 4, consts: [[1, "container-fluid", 3, "hidden"], [1, "row"], [1, "col-md-8", "offset-md-2", "text-center"], ["jhiTranslate", "home.title"], ["jhiTranslate", "home.subtitle", 1, "lead"], [1, "row", "row-divided", "my-4", "justify-content-center"], [1, "login-col", "col-12", "col-xl-5", "h-100"], [1, "login-form"], ["name", "loginForm", "role", "form", 1, "mb-5", 3, "change", "ngSubmit"], [1, "form-group"], ["for", "username", "jhiTranslate", "global.form.username", 1, "font-weight-bold"], ["autocomplete", "username", "id", "username", "name", "username", "type", "text", 1, "form-control", 3, "ngModel", "ngModelOptions", "pattern", "placeholder", "ngModelChange"], ["usernameForm", "ngModel"], ["for", "password", "jhiTranslate", "login.form.password", 1, "font-weight-bold"], ["autocomplete", "current-password", "id", "password", "name", "password", "type", "password", 1, "form-control", 3, "ngModel", "placeholder", "ngModelChange"], [1, "form-check"], ["for", "rememberMe", 1, "form-check-label"], ["checked", "", "id", "rememberMe", "name", "rememberMe", "type", "checkbox", 1, "form-check-input", 3, "ngModel", "ngModelChange"], ["jhiTranslate", "login.form.rememberme"], [1, "btn-toolbar"], ["id", "login-button", "type", "submit", 1, "btn", "btn-primary", 3, "disabled"], ["jhiTranslate", "login.form.button"], [1, "text-center"], ["jhiTranslate", "login.password.forgot", "routerLink", "account/reset/request", 1, "alert-link"], [1, "lead", "text-center", 3, "jhiTranslate"], [1, "lead", "text-center", 3, "jhiTranslate", "translateValues"], ["jhiTranslate", "home.errors.failedToLogin", 1, "alert", "alert-danger", "my-3"], [1, "bold"], [1, "alert", "alert-info", "my-3"], [3, "innerHTML"], [1, "alert", "alert-danger", "my-3"], [1, "help-block", 3, "jhiTranslate"], [1, "text-primary", "small"], ["for", "acceptTerms", 1, "form-check-label"], ["checked", "", "id", "acceptTerms", "name", "acceptTerms", "type", "checkbox", 1, "form-check-input", 3, "ngModel", "ngModelChange"], ["jhiTranslate", "login.form.acceptTerms", 3, "routerLink"], [1, "me-1"], [3, "icon", "spin"], ["jhiTranslate", "global.messages.info.register.noaccount"], ["jhiTranslate", "global.messages.info.register.link", "routerLink", "account/register", 1, "alert-link"], [1, "col-12", "col-xl-2", "py-5", "h-100"], ["jhiTranslate", "login.divider", 1, "d-none", "d-xl-block", "vertical-divider"], ["jhiTranslate", "login.divider", 1, "d-xl-none", "horizontal-divider"], [1, "login-col", "col-12", "col-xl-5"], [1, "h-100", "d-flex", "flex-column", "align-items-center", "justify-content-center"], [1, "saml2-center", "d-flex", "flex-column", "align-items-center", "justify-content-center", "flex-grow-1"], [1, "d-block", "text-center", 3, "acceptedTerms", "rememberMe", "saml2Profile"], ["type", "checkbox", 1, "form-check-input", 3, "ngModel", "ngModelChange"]], template: function HomeComponent_Template(rf, ctx) {
        if (rf & 1) {
          i018.\u0275\u0275elementStart(0, "div", 0);
          i018.\u0275\u0275text(1, "\n    ");
          i018.\u0275\u0275elementStart(2, "div", 1);
          i018.\u0275\u0275text(3, "\n        ");
          i018.\u0275\u0275elementStart(4, "div", 2);
          i018.\u0275\u0275text(5, "\n            ");
          i018.\u0275\u0275elementStart(6, "h1", 3);
          i018.\u0275\u0275text(7, "Welcome to Artemis!");
          i018.\u0275\u0275elementEnd();
          i018.\u0275\u0275text(8, "\n            ");
          i018.\u0275\u0275elementStart(9, "p", 4);
          i018.\u0275\u0275text(10, "Interactive Learning with Individual Feedback");
          i018.\u0275\u0275elementEnd();
          i018.\u0275\u0275text(11, "\n        ");
          i018.\u0275\u0275elementEnd();
          i018.\u0275\u0275text(12, "\n    ");
          i018.\u0275\u0275elementEnd();
          i018.\u0275\u0275text(13, "\n    ");
          i018.\u0275\u0275elementStart(14, "div", 5);
          i018.\u0275\u0275text(15, "\n        ");
          i018.\u0275\u0275template(16, HomeComponent_Conditional_16_Template, 71, 22)(17, HomeComponent_Conditional_17_Template, 10, 0)(18, HomeComponent_Conditional_18_Template, 19, 6);
          i018.\u0275\u0275elementEnd();
          i018.\u0275\u0275text(19, "\n");
          i018.\u0275\u0275elementEnd();
          i018.\u0275\u0275text(20, "\n");
        }
        if (rf & 2) {
          i018.\u0275\u0275property("hidden", ctx.loading || ctx.account);
          i018.\u0275\u0275advance(16);
          i018.\u0275\u0275conditional(16, !ctx.isPasswordLoginDisabled ? 16 : -1);
          i018.\u0275\u0275advance(1);
          i018.\u0275\u0275conditional(17, !ctx.isPasswordLoginDisabled && !!(ctx.profileInfo == null ? null : ctx.profileInfo.saml2) ? 17 : -1);
          i018.\u0275\u0275advance(1);
          i018.\u0275\u0275conditional(18, !!(ctx.profileInfo == null ? null : ctx.profileInfo.saml2) ? 18 : -1);
        }
      }, dependencies: [i11.\u0275NgNoValidate, i11.DefaultValueAccessor, i11.CheckboxControlValueAccessor, i11.NgControlStatus, i11.NgControlStatusGroup, i11.PatternValidator, i11.NgModel, i11.NgForm, i122.FaIconComponent, TranslateDirective, i15.RouterLink, Saml2LoginComponent, ArtemisTranslatePipe], styles: ['\n\n.login-col[_ngcontent-%COMP%] {\n  min-height: 150px;\n  width: 455px;\n  min-width: 455px;\n}\n.login-col[_ngcontent-%COMP%]   .login-form[_ngcontent-%COMP%] {\n  max-width: 360px;\n  margin: auto;\n}\n.row-divided[_ngcontent-%COMP%] {\n  position: relative;\n}\n.vertical-divider[_ngcontent-%COMP%] {\n  position: absolute;\n  height: calc(50% - 0.5rem);\n  width: auto;\n  top: 50%;\n  left: 50%;\n  margin: 0;\n  padding: 0;\n  line-height: 0;\n  text-align: center;\n  text-transform: uppercase;\n  transform: translateX(-50%);\n}\n.vertical-divider[_ngcontent-%COMP%]::before, .vertical-divider[_ngcontent-%COMP%]::after {\n  content: "";\n  position: absolute;\n  left: 50%;\n  z-index: -1;\n  border-left: 1px solid var(--border-color);\n  border-right: 1px solid var(--border-color);\n  width: 0;\n  height: calc(100% - 1rem);\n}\n.vertical-divider[_ngcontent-%COMP%]::before {\n  top: -100%;\n}\n.vertical-divider[_ngcontent-%COMP%]::after {\n  top: auto;\n  bottom: 0;\n}\n.horizontal-divider[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  text-align: center;\n  margin: 0;\n  padding: 0;\n  line-height: 0;\n  text-transform: uppercase;\n}\n.horizontal-divider[_ngcontent-%COMP%]::before, .horizontal-divider[_ngcontent-%COMP%]::after {\n  content: "";\n  flex: 1;\n  border-bottom: 2px solid var(--border-color);\n}\n.horizontal-divider[_ngcontent-%COMP%]::before {\n  margin-right: 1rem;\n  margin-left: 15%;\n}\n.horizontal-divider[_ngcontent-%COMP%]::after {\n  margin-left: 1rem;\n  margin-right: 15%;\n}\n@media (min-width: 1200px) {\n  .saml2-center[_ngcontent-%COMP%] {\n    margin-top: -40px;\n  }\n}\n@media (max-width: 576px) {\n  h1[_ngcontent-%COMP%] {\n    font-size: 1.6rem;\n  }\n  .lead[_ngcontent-%COMP%] {\n    font-size: 0.85rem;\n  }\n  .login-col[_ngcontent-%COMP%] {\n    width: 385px;\n    min-width: 385px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9ob21lL2hvbWUuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbk1haW4gcGFnZSBzdHlsZXNcbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovXG5cbi5sb2dpbi1jb2wge1xuICAgIG1pbi1oZWlnaHQ6IDE1MHB4O1xuICAgIHdpZHRoOiA0NTVweDtcbiAgICBtaW4td2lkdGg6IDQ1NXB4O1xuXG4gICAgLmxvZ2luLWZvcm0ge1xuICAgICAgICBtYXgtd2lkdGg6IDM2MHB4O1xuICAgICAgICBtYXJnaW46IGF1dG87XG4gICAgfVxufVxuXG4ucm93LWRpdmlkZWQge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLyogSW5zcGlyZWQgYnkgaHR0cHM6Ly9ib290c25pcHAuY29tL3NuaXBwZXRzL0FWYnp4ICovXG4udmVydGljYWwtZGl2aWRlciB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGhlaWdodDogY2FsYyg1MCUgLSAwLjVyZW0pO1xuICAgIHdpZHRoOiBhdXRvO1xuICAgIHRvcDogNTAlO1xuICAgIGxlZnQ6IDUwJTtcbiAgICBtYXJnaW46IDA7XG4gICAgcGFkZGluZzogMDtcbiAgICBsaW5lLWhlaWdodDogMDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSk7XG5cbiAgICAmOjpiZWZvcmUsXG4gICAgJjo6YWZ0ZXIge1xuICAgICAgICBjb250ZW50OiAnJztcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgIHotaW5kZXg6IC0xO1xuICAgICAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkIHZhcigtLWJvcmRlci1jb2xvcik7XG4gICAgICAgIGJvcmRlci1yaWdodDogMXB4IHNvbGlkIHZhcigtLWJvcmRlci1jb2xvcik7XG4gICAgICAgIHdpZHRoOiAwO1xuICAgICAgICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDFyZW0pO1xuICAgIH1cblxuICAgICY6OmJlZm9yZSB7XG4gICAgICAgIHRvcDogLTEwMCU7XG4gICAgfVxuXG4gICAgJjo6YWZ0ZXIge1xuICAgICAgICB0b3A6IGF1dG87XG4gICAgICAgIGJvdHRvbTogMDtcbiAgICB9XG59XG5cbi8qIEluc3BpcmVkIGJ5IGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vYS8yNjYzNDIyNCAqL1xuLmhvcml6b250YWwtZGl2aWRlciB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBtYXJnaW46IDA7XG4gICAgcGFkZGluZzogMDtcbiAgICBsaW5lLWhlaWdodDogMDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuXG4gICAgJjo6YmVmb3JlLFxuICAgICY6OmFmdGVyIHtcbiAgICAgICAgY29udGVudDogJyc7XG4gICAgICAgIGZsZXg6IDE7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCB2YXIoLS1ib3JkZXItY29sb3IpO1xuICAgIH1cblxuICAgICY6OmJlZm9yZSB7XG4gICAgICAgIG1hcmdpbi1yaWdodDogMXJlbTtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDE1JTtcbiAgICB9XG5cbiAgICAmOjphZnRlciB7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxcmVtO1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDE1JTtcbiAgICB9XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiAxMjAwcHgpIHtcbiAgICAuc2FtbDItY2VudGVyIHtcbiAgICAgICAgbWFyZ2luLXRvcDogLTQwcHg7XG4gICAgfVxufVxuXG5AbWVkaWEgKG1heC13aWR0aDogNTc2cHgpIHtcbiAgICBoMSB7XG4gICAgICAgIGZvbnQtc2l6ZTogMS42cmVtO1xuICAgIH1cblxuICAgIC5sZWFkIHtcbiAgICAgICAgZm9udC1zaXplOiAwLjg1cmVtO1xuICAgIH1cblxuICAgIC5sb2dpbi1jb2wge1xuICAgICAgICB3aWR0aDogMzg1cHg7XG4gICAgICAgIG1pbi13aWR0aDogMzg1cHg7XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUlBLENBQUE7QUFDSSxjQUFBO0FBQ0EsU0FBQTtBQUNBLGFBQUE7O0FBRUEsQ0FMSixVQUtJLENBQUE7QUFDSSxhQUFBO0FBQ0EsVUFBQTs7QUFJUixDQUFBO0FBQ0ksWUFBQTs7QUFJSixDQUFBO0FBQ0ksWUFBQTtBQUNBLFVBQUEsS0FBQSxJQUFBLEVBQUE7QUFDQSxTQUFBO0FBQ0EsT0FBQTtBQUNBLFFBQUE7QUFDQSxVQUFBO0FBQ0EsV0FBQTtBQUNBLGVBQUE7QUFDQSxjQUFBO0FBQ0Esa0JBQUE7QUFDQSxhQUFBLFdBQUE7O0FBRUEsQ0FiSixnQkFhSTtBQUFBLENBYkosZ0JBYUk7QUFFSSxXQUFBO0FBQ0EsWUFBQTtBQUNBLFFBQUE7QUFDQSxXQUFBO0FBQ0EsZUFBQSxJQUFBLE1BQUEsSUFBQTtBQUNBLGdCQUFBLElBQUEsTUFBQSxJQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUEsS0FBQSxLQUFBLEVBQUE7O0FBR0osQ0F6QkosZ0JBeUJJO0FBQ0ksT0FBQTs7QUFHSixDQTdCSixnQkE2Qkk7QUFDSSxPQUFBO0FBQ0EsVUFBQTs7QUFLUixDQUFBO0FBQ0ksV0FBQTtBQUNBLGVBQUE7QUFDQSxjQUFBO0FBQ0EsVUFBQTtBQUNBLFdBQUE7QUFDQSxlQUFBO0FBQ0Esa0JBQUE7O0FBRUEsQ0FUSixrQkFTSTtBQUFBLENBVEosa0JBU0k7QUFFSSxXQUFBO0FBQ0EsUUFBQTtBQUNBLGlCQUFBLElBQUEsTUFBQSxJQUFBOztBQUdKLENBaEJKLGtCQWdCSTtBQUNJLGdCQUFBO0FBQ0EsZUFBQTs7QUFHSixDQXJCSixrQkFxQkk7QUFDSSxlQUFBO0FBQ0EsZ0JBQUE7O0FBSVIsT0FBQSxDQUFBLFNBQUEsRUFBQTtBQUNJLEdBQUE7QUFDSSxnQkFBQTs7O0FBSVIsT0FBQSxDQUFBLFNBQUEsRUFBQTtBQUNJO0FBQ0ksZUFBQTs7QUFHSixHQUFBO0FBQ0ksZUFBQTs7QUFHSixHQTlGSjtBQStGUSxXQUFBO0FBQ0EsZUFBQTs7OyIsCiAgIm5hbWVzIjogW10KfQo= */'] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i018.\u0275setClassDebugInfo(HomeComponent, { className: "HomeComponent" });
    })();
  }
});

// src/main/webapp/app/home/home.route.ts
var HOME_ROUTE;
var init_home_route = __esm({
  "src/main/webapp/app/home/home.route.ts"() {
    init_home_component();
    HOME_ROUTE = {
      path: "",
      component: HomeComponent,
      data: {
        authorities: [],
        pageTitle: "home.title"
      }
    };
  }
});

// src/main/webapp/app/home/home.module.ts
import { NgModule as NgModule4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { RouterModule as RouterModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i019 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisHomeModule;
var init_home_module = __esm({
  "src/main/webapp/app/home/home.module.ts"() {
    init_home_route();
    init_shared_module();
    init_home_component();
    init_saml2_login_component();
    ArtemisHomeModule = class _ArtemisHomeModule {
      static \u0275fac = function ArtemisHomeModule_Factory(t) {
        return new (t || _ArtemisHomeModule)();
      };
      static \u0275mod = i019.\u0275\u0275defineNgModule({ type: _ArtemisHomeModule });
      static \u0275inj = i019.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, RouterModule2.forChild([HOME_ROUTE])] });
    };
  }
});

// src/main/webapp/app/shared/user-settings/account-information/account-information.component.ts
import { Component as Component15 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { tap as tap3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i020 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function AccountInformationComponent_Conditional_5_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i020.\u0275\u0275text(0, "\n            ");
    i020.\u0275\u0275elementStart(1, "div", 1);
    i020.\u0275\u0275text(2, "\n                ");
    i020.\u0275\u0275elementStart(3, "dt");
    i020.\u0275\u0275text(4, "\n                    ");
    i020.\u0275\u0275text(5);
    i020.\u0275\u0275pipe(6, "artemisTranslate");
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(7, "\n                ");
    i020.\u0275\u0275elementStart(8, "dd");
    i020.\u0275\u0275text(9);
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(10, "\n            ");
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(11, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = i020.\u0275\u0275nextContext(2);
    i020.\u0275\u0275advance(5);
    i020.\u0275\u0275textInterpolate1("\n                    ", i020.\u0275\u0275pipeBind1(6, 2, "artemisApp.userSettings.accountInformationPage.fullName"), "\n                ");
    i020.\u0275\u0275advance(4);
    i020.\u0275\u0275textInterpolate(ctx_r1.currentUser.name);
  }
}
function AccountInformationComponent_Conditional_5_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i020.\u0275\u0275text(0, "\n            ");
    i020.\u0275\u0275elementStart(1, "div", 1);
    i020.\u0275\u0275text(2, "\n                ");
    i020.\u0275\u0275elementStart(3, "dt");
    i020.\u0275\u0275text(4, "\n                    ");
    i020.\u0275\u0275text(5);
    i020.\u0275\u0275pipe(6, "artemisTranslate");
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(7, "\n                ");
    i020.\u0275\u0275elementStart(8, "dd");
    i020.\u0275\u0275text(9);
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(10, "\n            ");
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(11, "\n        ");
  }
  if (rf & 2) {
    const ctx_r2 = i020.\u0275\u0275nextContext(2);
    i020.\u0275\u0275advance(5);
    i020.\u0275\u0275textInterpolate1("\n                    ", i020.\u0275\u0275pipeBind1(6, 2, "artemisApp.userSettings.accountInformationPage.login"), "\n                ");
    i020.\u0275\u0275advance(4);
    i020.\u0275\u0275textInterpolate(ctx_r2.currentUser.login);
  }
}
function AccountInformationComponent_Conditional_5_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i020.\u0275\u0275text(0, "\n            ");
    i020.\u0275\u0275elementStart(1, "div", 1);
    i020.\u0275\u0275text(2, "\n                ");
    i020.\u0275\u0275elementStart(3, "dt");
    i020.\u0275\u0275text(4, "\n                    ");
    i020.\u0275\u0275text(5);
    i020.\u0275\u0275pipe(6, "artemisTranslate");
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(7, "\n                ");
    i020.\u0275\u0275elementStart(8, "dd");
    i020.\u0275\u0275text(9);
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(10, "\n            ");
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(11, "\n        ");
  }
  if (rf & 2) {
    const ctx_r3 = i020.\u0275\u0275nextContext(2);
    i020.\u0275\u0275advance(5);
    i020.\u0275\u0275textInterpolate1("\n                    ", i020.\u0275\u0275pipeBind1(6, 2, "artemisApp.userSettings.accountInformationPage.email"), "\n                ");
    i020.\u0275\u0275advance(4);
    i020.\u0275\u0275textInterpolate(ctx_r3.currentUser.email);
  }
}
function AccountInformationComponent_Conditional_5_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i020.\u0275\u0275text(0, "\n            ");
    i020.\u0275\u0275elementStart(1, "div", 1);
    i020.\u0275\u0275text(2, "\n                ");
    i020.\u0275\u0275elementStart(3, "dt");
    i020.\u0275\u0275text(4, "\n                    ");
    i020.\u0275\u0275text(5);
    i020.\u0275\u0275pipe(6, "artemisTranslate");
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(7, "\n                ");
    i020.\u0275\u0275elementStart(8, "dd");
    i020.\u0275\u0275text(9);
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(10, "\n            ");
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(11, "\n        ");
  }
  if (rf & 2) {
    const ctx_r4 = i020.\u0275\u0275nextContext(2);
    i020.\u0275\u0275advance(5);
    i020.\u0275\u0275textInterpolate1("\n                    ", i020.\u0275\u0275pipeBind1(6, 2, "artemisApp.userSettings.accountInformationPage.registrationNumber"), "\n                ");
    i020.\u0275\u0275advance(4);
    i020.\u0275\u0275textInterpolate(ctx_r4.currentUser.visibleRegistrationNumber);
  }
}
function AccountInformationComponent_Conditional_5_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i020.\u0275\u0275text(0, "\n            ");
    i020.\u0275\u0275elementStart(1, "div", 1);
    i020.\u0275\u0275text(2, "\n                ");
    i020.\u0275\u0275elementStart(3, "dt");
    i020.\u0275\u0275text(4, "\n                    ");
    i020.\u0275\u0275text(5);
    i020.\u0275\u0275pipe(6, "artemisTranslate");
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(7, "\n                ");
    i020.\u0275\u0275elementStart(8, "dd");
    i020.\u0275\u0275text(9);
    i020.\u0275\u0275pipe(10, "artemisDate");
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(11, "\n            ");
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(12, "\n        ");
  }
  if (rf & 2) {
    const ctx_r5 = i020.\u0275\u0275nextContext(2);
    i020.\u0275\u0275advance(5);
    i020.\u0275\u0275textInterpolate1("\n                    ", i020.\u0275\u0275pipeBind1(6, 2, "artemisApp.userSettings.accountInformationPage.joinedArtemis"), "\n                ");
    i020.\u0275\u0275advance(4);
    i020.\u0275\u0275textInterpolate(i020.\u0275\u0275pipeBind1(10, 4, ctx_r5.currentUser.createdDate));
  }
}
function AccountInformationComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i020.\u0275\u0275text(0, "\n    ");
    i020.\u0275\u0275elementStart(1, "div", 0);
    i020.\u0275\u0275text(2, "\n        ");
    i020.\u0275\u0275template(3, AccountInformationComponent_Conditional_5_Conditional_3_Template, 12, 4)(4, AccountInformationComponent_Conditional_5_Conditional_4_Template, 12, 4)(5, AccountInformationComponent_Conditional_5_Conditional_5_Template, 12, 4)(6, AccountInformationComponent_Conditional_5_Conditional_6_Template, 12, 4)(7, AccountInformationComponent_Conditional_5_Conditional_7_Template, 13, 6);
    i020.\u0275\u0275elementEnd();
    i020.\u0275\u0275text(8, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i020.\u0275\u0275nextContext();
    i020.\u0275\u0275advance(3);
    i020.\u0275\u0275conditional(3, ctx_r0.currentUser.name ? 3 : -1);
    i020.\u0275\u0275advance(1);
    i020.\u0275\u0275conditional(4, ctx_r0.currentUser.login ? 4 : -1);
    i020.\u0275\u0275advance(1);
    i020.\u0275\u0275conditional(5, ctx_r0.currentUser.email ? 5 : -1);
    i020.\u0275\u0275advance(1);
    i020.\u0275\u0275conditional(6, ctx_r0.currentUser.visibleRegistrationNumber ? 6 : -1);
    i020.\u0275\u0275advance(1);
    i020.\u0275\u0275conditional(7, ctx_r0.currentUser.createdDate ? 7 : -1);
  }
}
var AccountInformationComponent;
var init_account_information_component = __esm({
  "src/main/webapp/app/shared/user-settings/account-information/account-information.component.ts"() {
    init_account_service();
    init_account_service();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    AccountInformationComponent = class _AccountInformationComponent {
      accountService;
      currentUser;
      authStateSubscription;
      constructor(accountService) {
        this.accountService = accountService;
      }
      ngOnInit() {
        this.authStateSubscription = this.accountService.getAuthenticationState().pipe(tap3((user) => this.currentUser = user)).subscribe();
      }
      static \u0275fac = function AccountInformationComponent_Factory(t) {
        return new (t || _AccountInformationComponent)(i020.\u0275\u0275directiveInject(AccountService));
      };
      static \u0275cmp = i020.\u0275\u0275defineComponent({ type: _AccountInformationComponent, selectors: [["jhi-account-information"]], decls: 6, vars: 4, consts: [[1, "list-group", "d-block"], [1, "list-group-item"]], template: function AccountInformationComponent_Template(rf, ctx) {
        if (rf & 1) {
          i020.\u0275\u0275elementStart(0, "h1");
          i020.\u0275\u0275text(1, "\n    ");
          i020.\u0275\u0275text(2);
          i020.\u0275\u0275pipe(3, "artemisTranslate");
          i020.\u0275\u0275elementEnd();
          i020.\u0275\u0275text(4, "\n");
          i020.\u0275\u0275template(5, AccountInformationComponent_Conditional_5_Template, 9, 5);
        }
        if (rf & 2) {
          i020.\u0275\u0275advance(2);
          i020.\u0275\u0275textInterpolate1("\n    ", i020.\u0275\u0275pipeBind1(3, 2, "artemisApp.userSettings.accountInformation"), "\n");
          i020.\u0275\u0275advance(3);
          i020.\u0275\u0275conditional(5, ctx.currentUser ? 5 : -1);
        }
      }, dependencies: [ArtemisDatePipe, ArtemisTranslatePipe], styles: ["\n\n#apply-changes-button[_ngcontent-%COMP%] {\n  width: 250px;\n  height: 40px;\n  font-size: large;\n  border: 0;\n}\nh3[_ngcontent-%COMP%] {\n  font-weight: bold;\n  text-underline-offset: 3px;\n}\ndt[_ngcontent-%COMP%] {\n  font-size: large;\n  font-weight: 500;\n}\ndd[_ngcontent-%COMP%] {\n  font-size: larger;\n}\nspan[_ngcontent-%COMP%] {\n  color: gray;\n  font-size: smaller;\n}\n.userSettings-info[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-style: italic;\n  color: gray;\n  font-size: large;\n  font-weight: bolder;\n}\n.userSettings-info[_ngcontent-%COMP%]   .ng-fa-icon[_ngcontent-%COMP%] {\n  color: gray;\n}\n.form-check[_ngcontent-%COMP%] {\n  padding-top: 5px;\n  padding-bottom: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvdXNlci1zZXR0aW5ncy91c2VyLXNldHRpbmdzLnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIiNhcHBseS1jaGFuZ2VzLWJ1dHRvbiB7XG4gICAgd2lkdGg6IDI1MHB4O1xuICAgIGhlaWdodDogNDBweDtcbiAgICBmb250LXNpemU6IGxhcmdlO1xuICAgIGJvcmRlcjogMDtcbn1cblxuaDMge1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIHRleHQtdW5kZXJsaW5lLW9mZnNldDogM3B4O1xufVxuXG5kdCB7XG4gICAgZm9udC1zaXplOiBsYXJnZTtcbiAgICBmb250LXdlaWdodDogNTAwO1xufVxuXG5kZCB7XG4gICAgZm9udC1zaXplOiBsYXJnZXI7XG59XG5cbnNwYW4ge1xuICAgIGNvbG9yOiBncmF5O1xuICAgIGZvbnQtc2l6ZTogc21hbGxlcjtcbn1cblxuLnVzZXJTZXR0aW5ncy1pbmZvIHtcbiAgICBzcGFuIHtcbiAgICAgICAgZm9udC1zdHlsZTogaXRhbGljO1xuICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgZm9udC1zaXplOiBsYXJnZTtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcbiAgICB9XG5cbiAgICAubmctZmEtaWNvbiB7XG4gICAgICAgIGNvbG9yOiBncmF5O1xuICAgIH1cbn1cblxuLmZvcm0tY2hlY2sge1xuICAgIHBhZGRpbmctdG9wOiA1cHg7XG4gICAgcGFkZGluZy1ib3R0b206IDVweDtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksU0FBQTtBQUNBLFVBQUE7QUFDQSxhQUFBO0FBQ0EsVUFBQTs7QUFHSjtBQUNJLGVBQUE7QUFDQSx5QkFBQTs7QUFHSjtBQUNJLGFBQUE7QUFDQSxlQUFBOztBQUdKO0FBQ0ksYUFBQTs7QUFHSjtBQUNJLFNBQUE7QUFDQSxhQUFBOztBQUlBLENBQUEsa0JBQUE7QUFDSSxjQUFBO0FBQ0EsU0FBQTtBQUNBLGFBQUE7QUFDQSxlQUFBOztBQUdKLENBUEEsa0JBT0EsQ0FBQTtBQUNJLFNBQUE7O0FBSVIsQ0FBQTtBQUNJLGVBQUE7QUFDQSxrQkFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i020.\u0275setClassDebugInfo(AccountInformationComponent, { className: "AccountInformationComponent" });
    })();
  }
});

// src/main/webapp/app/shared/user-settings/user-settings-container/user-settings-container.component.ts
import { Component as Component16 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faUser as faUser2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i021 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i28 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i34 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function UserSettingsContainerComponent_Conditional_11_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                            ");
    i021.\u0275\u0275elementStart(1, "span", 12);
    i021.\u0275\u0275text(2);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r1 = i021.\u0275\u0275nextContext(2);
    i021.\u0275\u0275advance(2);
    i021.\u0275\u0275textInterpolate(ctx_r1.currentUser.name);
  }
}
function UserSettingsContainerComponent_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                    ");
    i021.\u0275\u0275elementStart(1, "div");
    i021.\u0275\u0275text(2, "\n                        ");
    i021.\u0275\u0275template(3, UserSettingsContainerComponent_Conditional_11_Conditional_3_Template, 4, 1);
    i021.\u0275\u0275element(4, "br");
    i021.\u0275\u0275text(5, "\n                        ");
    i021.\u0275\u0275elementStart(6, "span", 11);
    i021.\u0275\u0275text(7);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(8, "\n                    ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(9, "\n                ");
  }
  if (rf & 2) {
    const ctx_r0 = i021.\u0275\u0275nextContext();
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275conditional(3, ctx_r0.currentUser.name ? 3 : -1);
    i021.\u0275\u0275advance(4);
    i021.\u0275\u0275textInterpolate(ctx_r0.currentUser.login);
  }
}
var UserSettingsContainerComponent;
var init_user_settings_container_component = __esm({
  "src/main/webapp/app/shared/user-settings/user-settings-container/user-settings-container.component.ts"() {
    init_account_service();
    init_account_information_component();
    init_account_service();
    init_artemis_translate_pipe();
    UserSettingsContainerComponent = class _UserSettingsContainerComponent extends AccountInformationComponent {
      faUser = faUser2;
      constructor(accountService) {
        super(accountService);
      }
      static \u0275fac = function UserSettingsContainerComponent_Factory(t) {
        return new (t || _UserSettingsContainerComponent)(i021.\u0275\u0275directiveInject(AccountService));
      };
      static \u0275cmp = i021.\u0275\u0275defineComponent({ type: _UserSettingsContainerComponent, selectors: [["jhi-user-settings"]], features: [i021.\u0275\u0275InheritDefinitionFeature], decls: 44, vars: 11, consts: [[1, "container"], [1, "row"], [1, "col-lg-3", "col-sm-12"], [1, "d-flex"], ["id", "avatar", "size", "3x", 3, "icon"], ["id", "navigation-bar", 1, "list-group", "d-block", "pt-2"], [1, "list-group-item", "disabled", "fw-bold"], ["routerLink", "account", "routerLinkActive", "active", 1, "list-group-item", "btn", "btn-outline-primary"], ["routerLink", "notifications", "routerLinkActive", "active", 1, "list-group-item", "btn", "btn-outline-primary"], [1, "col-lg-8", "col-sm-12"], ["id", "current-settings"], ["id", "login"], ["id", "user-header"]], template: function UserSettingsContainerComponent_Template(rf, ctx) {
        if (rf & 1) {
          i021.\u0275\u0275elementStart(0, "div", 0);
          i021.\u0275\u0275text(1, "\n    ");
          i021.\u0275\u0275elementStart(2, "div", 1);
          i021.\u0275\u0275text(3, "\n        ");
          i021.\u0275\u0275elementStart(4, "div", 2);
          i021.\u0275\u0275text(5, "\n            ");
          i021.\u0275\u0275text(6, "\n            ");
          i021.\u0275\u0275elementStart(7, "div", 3);
          i021.\u0275\u0275text(8, "\n                ");
          i021.\u0275\u0275element(9, "fa-icon", 4);
          i021.\u0275\u0275text(10, "\n                ");
          i021.\u0275\u0275template(11, UserSettingsContainerComponent_Conditional_11_Template, 10, 2);
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(12, "\n            ");
          i021.\u0275\u0275text(13, "\n            ");
          i021.\u0275\u0275elementStart(14, "section", 5);
          i021.\u0275\u0275text(15, "\n                ");
          i021.\u0275\u0275elementStart(16, "span", 6);
          i021.\u0275\u0275text(17, "\n                    ");
          i021.\u0275\u0275text(18);
          i021.\u0275\u0275pipe(19, "artemisTranslate");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(20, "\n                ");
          i021.\u0275\u0275elementStart(21, "a", 7);
          i021.\u0275\u0275text(22, "\n                    ");
          i021.\u0275\u0275text(23);
          i021.\u0275\u0275pipe(24, "artemisTranslate");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(25, "\n                ");
          i021.\u0275\u0275elementStart(26, "a", 8);
          i021.\u0275\u0275text(27, "\n                    ");
          i021.\u0275\u0275text(28);
          i021.\u0275\u0275pipe(29, "artemisTranslate");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(30, "\n            ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(31, "\n        ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(32, "\n        ");
          i021.\u0275\u0275text(33, "\n        ");
          i021.\u0275\u0275elementStart(34, "div", 9);
          i021.\u0275\u0275text(35, "\n            ");
          i021.\u0275\u0275elementStart(36, "section", 10);
          i021.\u0275\u0275text(37, "\n                ");
          i021.\u0275\u0275element(38, "router-outlet");
          i021.\u0275\u0275text(39, "\n            ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(40, "\n        ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(41, "\n    ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(42, "\n");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(43, "\n");
        }
        if (rf & 2) {
          i021.\u0275\u0275advance(9);
          i021.\u0275\u0275property("icon", ctx.faUser);
          i021.\u0275\u0275advance(2);
          i021.\u0275\u0275conditional(11, ctx.currentUser ? 11 : -1);
          i021.\u0275\u0275advance(7);
          i021.\u0275\u0275textInterpolate1("\n                    ", i021.\u0275\u0275pipeBind1(19, 5, "artemisApp.userSettings.userSettings"), "\n                ");
          i021.\u0275\u0275advance(5);
          i021.\u0275\u0275textInterpolate1("\n                    ", i021.\u0275\u0275pipeBind1(24, 7, "artemisApp.userSettings.accountInformation"), "\n                ");
          i021.\u0275\u0275advance(5);
          i021.\u0275\u0275textInterpolate1("\n                    ", i021.\u0275\u0275pipeBind1(29, 9, "artemisApp.userSettings.notificationSettings"), "\n                ");
        }
      }, dependencies: [i28.RouterOutlet, i28.RouterLink, i28.RouterLinkActive, i34.FaIconComponent, ArtemisTranslatePipe], styles: ["\n\n#avatar[_ngcontent-%COMP%] {\n  padding-top: 8px;\n  padding-right: 15px;\n}\n#user-header[_ngcontent-%COMP%] {\n  font-size: x-large;\n  font-weight: 600;\n  color: var(--bs-body-color);\n}\n#login[_ngcontent-%COMP%] {\n  color: var(--bs-secondary);\n  font-size: medium;\n  font-weight: normal;\n}\n#navigation-bar[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\n  font-size: medium;\n  text-align: left;\n}\n.section[_ngcontent-%COMP%] {\n  padding-top: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvdXNlci1zZXR0aW5ncy91c2VyLXNldHRpbmdzLWNvbnRhaW5lci91c2VyLXNldHRpbmdzLWNvbnRhaW5lci5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiI2F2YXRhciB7XG4gICAgcGFkZGluZy10b3A6IDhweDtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxNXB4O1xufVxuXG4jdXNlci1oZWFkZXIge1xuICAgIGZvbnQtc2l6ZTogeC1sYXJnZTtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGNvbG9yOiB2YXIoLS1icy1ib2R5LWNvbG9yKTtcbn1cblxuI2xvZ2luIHtcbiAgICBjb2xvcjogdmFyKC0tYnMtc2Vjb25kYXJ5KTtcbiAgICBmb250LXNpemU6IG1lZGl1bTtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xufVxuXG4jbmF2aWdhdGlvbi1iYXIge1xuICAgIC5idG4ge1xuICAgICAgICBmb250LXNpemU6IG1lZGl1bTtcbiAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICB9XG59XG5cbi5zZWN0aW9uIHtcbiAgICBwYWRkaW5nLXRvcDogMjBweDtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksZUFBQTtBQUNBLGlCQUFBOztBQUdKLENBQUE7QUFDSSxhQUFBO0FBQ0EsZUFBQTtBQUNBLFNBQUEsSUFBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQSxJQUFBO0FBQ0EsYUFBQTtBQUNBLGVBQUE7O0FBSUEsQ0FBQSxlQUFBLENBQUE7QUFDSSxhQUFBO0FBQ0EsY0FBQTs7QUFJUixDQUFBO0FBQ0ksZUFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i021.\u0275setClassDebugInfo(UserSettingsContainerComponent, { className: "UserSettingsContainerComponent" });
    })();
  }
});

// src/main/webapp/app/shared/user-settings/user-settings.directive.ts
import { ChangeDetectorRef as ChangeDetectorRef3, Directive as Directive2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i022 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var UserSettingsDirective;
var init_user_settings_directive = __esm({
  "src/main/webapp/app/shared/user-settings/user-settings.directive.ts"() {
    init_user_settings_service();
    init_alert_service();
    init_user_settings_service();
    init_alert_service();
    UserSettingsDirective = class _UserSettingsDirective {
      userSettingsService;
      alertService;
      changeDetector;
      settingsChanged = false;
      currentUser;
      userSettingsCategory;
      changeEventMessage;
      userSettings;
      settings;
      page = 0;
      error;
      constructor(userSettingsService, alertService, changeDetector) {
        this.userSettingsService = userSettingsService;
        this.alertService = alertService;
        this.changeDetector = changeDetector;
      }
      ngOnInit() {
        this.alertService.closeAll();
        this.loadSetting();
      }
      loadSetting() {
        this.userSettingsService.loadSettings(this.userSettingsCategory).subscribe({
          next: (res) => {
            this.userSettings = this.userSettingsService.loadSettingsSuccessAsSettingsStructure(res.body, this.userSettingsCategory);
            this.settings = this.userSettingsService.extractIndividualSettingsFromSettingsStructure(this.userSettings);
            this.changeDetector.detectChanges();
            this.alertService.closeAll();
          },
          error: (res) => this.onError(res)
        });
      }
      saveSettings() {
        this.userSettingsService.saveSettings(this.settings, this.userSettingsCategory).subscribe({
          next: (res) => {
            this.userSettings = this.userSettingsService.saveSettingsSuccess(this.userSettings, res.body);
            this.settings = this.userSettingsService.extractIndividualSettingsFromSettingsStructure(this.userSettings);
            this.finishSaving();
          },
          error: (res) => this.onError(res)
        });
      }
      finishSaving() {
        this.createApplyChangesEvent();
        this.settingsChanged = false;
        this.alertService.closeAll();
        this.alertService.success("artemisApp.userSettings.saveSettingsSuccessAlert");
      }
      createApplyChangesEvent() {
        this.userSettingsService.sendApplyChangesEvent(this.changeEventMessage);
      }
      onError(httpErrorResponse) {
        const error = httpErrorResponse.error;
        if (error) {
          this.alertService.error(error.message, error.params);
        } else {
          this.alertService.error("error.unexpectedError", {
            error: httpErrorResponse.message
          });
        }
      }
      static \u0275fac = function UserSettingsDirective_Factory(t) {
        return new (t || _UserSettingsDirective)(i022.\u0275\u0275directiveInject(UserSettingsService), i022.\u0275\u0275directiveInject(AlertService), i022.\u0275\u0275directiveInject(i022.ChangeDetectorRef));
      };
      static \u0275dir = i022.\u0275\u0275defineDirective({ type: _UserSettingsDirective });
    };
  }
});

// src/main/webapp/app/shared/user-settings/notification-settings/notification-settings.component.ts
import { ChangeDetectorRef as ChangeDetectorRef5, Component as Component17 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faInfoCircle as faInfoCircle3, faSave } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i023 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i44 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function NotificationSettingsComponent_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i023.\u0275\u0275getCurrentView();
    i023.\u0275\u0275text(0, "\n        ");
    i023.\u0275\u0275elementStart(1, "button", 4);
    i023.\u0275\u0275listener("click", function NotificationSettingsComponent_Conditional_20_Template_button_click_1_listener() {
      i023.\u0275\u0275restoreView(_r3);
      const ctx_r2 = i023.\u0275\u0275nextContext();
      return i023.\u0275\u0275resetView(ctx_r2.saveSettings());
    });
    i023.\u0275\u0275text(2, "\n            ");
    i023.\u0275\u0275element(3, "fa-icon", 5);
    i023.\u0275\u0275text(4);
    i023.\u0275\u0275pipe(5, "artemisTranslate");
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(6, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i023.\u0275\u0275nextContext();
    i023.\u0275\u0275advance(3);
    i023.\u0275\u0275property("icon", ctx_r0.faSave);
    i023.\u0275\u0275advance(1);
    i023.\u0275\u0275textInterpolate1("\n            ", i023.\u0275\u0275pipeBind1(5, 2, "artemisApp.userSettings.saveChanges"), "\n        ");
  }
}
function NotificationSettingsComponent_Conditional_22_For_4_div_3_For_9_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = i023.\u0275\u0275getCurrentView();
    i023.\u0275\u0275text(0, "\n                                    ");
    i023.\u0275\u0275elementStart(1, "div", 10);
    i023.\u0275\u0275text(2, "\n                                        ");
    i023.\u0275\u0275elementStart(3, "input", 11);
    i023.\u0275\u0275listener("click", function NotificationSettingsComponent_Conditional_22_For_4_div_3_For_9_Conditional_16_Template_input_click_3_listener($event) {
      i023.\u0275\u0275restoreView(_r20);
      const ctx_r19 = i023.\u0275\u0275nextContext(5);
      return i023.\u0275\u0275resetView(ctx_r19.toggleSetting($event, ctx_r19.communicationChannel.WEBAPP));
    });
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(4, "\n                                        ");
    i023.\u0275\u0275elementStart(5, "label", 12);
    i023.\u0275\u0275text(6, "WebApp");
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(7, "\n                                    ");
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(8, "\n                                ");
  }
  if (rf & 2) {
    const setting_r12 = i023.\u0275\u0275nextContext().$implicit;
    i023.\u0275\u0275advance(3);
    i023.\u0275\u0275propertyInterpolate("id", setting_r12.settingId);
    i023.\u0275\u0275propertyInterpolate("value", setting_r12.webapp);
    i023.\u0275\u0275property("checked", setting_r12.webapp);
    i023.\u0275\u0275advance(2);
    i023.\u0275\u0275propertyInterpolate("for", setting_r12.settingId);
  }
}
function NotificationSettingsComponent_Conditional_22_For_4_div_3_For_9_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = i023.\u0275\u0275getCurrentView();
    i023.\u0275\u0275text(0, "\n                                    ");
    i023.\u0275\u0275elementStart(1, "div", 13);
    i023.\u0275\u0275text(2, "\n                                        ");
    i023.\u0275\u0275elementStart(3, "input", 11);
    i023.\u0275\u0275listener("click", function NotificationSettingsComponent_Conditional_22_For_4_div_3_For_9_Conditional_17_Template_input_click_3_listener($event) {
      i023.\u0275\u0275restoreView(_r23);
      const ctx_r22 = i023.\u0275\u0275nextContext(5);
      return i023.\u0275\u0275resetView(ctx_r22.toggleSetting($event, ctx_r22.communicationChannel.EMAIL));
    });
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(4, "\n                                        ");
    i023.\u0275\u0275elementStart(5, "label", 12);
    i023.\u0275\u0275text(6, "Email");
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(7, "\n                                    ");
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(8, "\n                                ");
  }
  if (rf & 2) {
    const setting_r12 = i023.\u0275\u0275nextContext().$implicit;
    i023.\u0275\u0275advance(3);
    i023.\u0275\u0275propertyInterpolate1("id", "", setting_r12.settingId, " email");
    i023.\u0275\u0275propertyInterpolate("value", setting_r12.email);
    i023.\u0275\u0275property("checked", setting_r12.email);
    i023.\u0275\u0275advance(2);
    i023.\u0275\u0275propertyInterpolate1("for", "", setting_r12.settingId, " email");
  }
}
function NotificationSettingsComponent_Conditional_22_For_4_div_3_For_9_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275text(0, "\n                        ");
    i023.\u0275\u0275elementStart(1, "div");
    i023.\u0275\u0275text(2, "\n                            ");
    i023.\u0275\u0275elementStart(3, "dt");
    i023.\u0275\u0275text(4, "\n                                ");
    i023.\u0275\u0275text(5);
    i023.\u0275\u0275pipe(6, "artemisTranslate");
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(7, "\n                            ");
    i023.\u0275\u0275elementStart(8, "span");
    i023.\u0275\u0275text(9, "\n                                ");
    i023.\u0275\u0275text(10);
    i023.\u0275\u0275pipe(11, "artemisTranslate");
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(12, "\n                            ");
    i023.\u0275\u0275text(13, "\n                            ");
    i023.\u0275\u0275elementStart(14, "div", 9);
    i023.\u0275\u0275text(15, "\n                                ");
    i023.\u0275\u0275template(16, NotificationSettingsComponent_Conditional_22_For_4_div_3_For_9_Conditional_16_Template, 9, 4)(17, NotificationSettingsComponent_Conditional_22_For_4_div_3_For_9_Conditional_17_Template, 9, 4);
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(18, "\n                        ");
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(19, "\n                    ");
  }
  if (rf & 2) {
    const setting_r12 = ctx.$implicit;
    i023.\u0275\u0275advance(5);
    i023.\u0275\u0275textInterpolate1("\n                                ", i023.\u0275\u0275pipeBind1(6, 4, "artemisApp.userSettings.settingNames." + setting_r12.key), "\n                            ");
    i023.\u0275\u0275advance(5);
    i023.\u0275\u0275textInterpolate1("\n                                ", i023.\u0275\u0275pipeBind1(11, 6, "artemisApp.userSettings.settingDescriptions." + setting_r12.descriptionKey), "\n                            ");
    i023.\u0275\u0275advance(6);
    i023.\u0275\u0275conditional(16, setting_r12.webapp != void 0 && (setting_r12.webappSupport == void 0 || setting_r12.webappSupport) ? 16 : -1);
    i023.\u0275\u0275advance(1);
    i023.\u0275\u0275conditional(17, setting_r12.email != void 0 && setting_r12.emailSupport ? 17 : -1);
  }
}
function NotificationSettingsComponent_Conditional_22_For_4_div_3_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275elementStart(0, "div", 8);
    i023.\u0275\u0275text(1, "\n                    ");
    i023.\u0275\u0275elementStart(2, "h3");
    i023.\u0275\u0275text(3, "\n                        ");
    i023.\u0275\u0275text(4, "\n                        ");
    i023.\u0275\u0275text(5);
    i023.\u0275\u0275pipe(6, "artemisTranslate");
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(7, "\n                    ");
    i023.\u0275\u0275repeaterCreate(8, NotificationSettingsComponent_Conditional_22_For_4_div_3_For_9_Template, 20, 8, null, null, i023.\u0275\u0275repeaterTrackByIdentity);
    i023.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const settingGroup_r5 = i023.\u0275\u0275nextContext().$implicit;
    i023.\u0275\u0275advance(5);
    i023.\u0275\u0275textInterpolate1("\n                        ", i023.\u0275\u0275pipeBind1(6, 1, "artemisApp.userSettings.settingGroupNames." + settingGroup_r5.key), "\n                    ");
    i023.\u0275\u0275advance(3);
    i023.\u0275\u0275repeater(settingGroup_r5.settings);
  }
}
function NotificationSettingsComponent_Conditional_22_For_4_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275text(0, "\n            ");
    i023.\u0275\u0275elementStart(1, "div");
    i023.\u0275\u0275text(2, "\n                ");
    i023.\u0275\u0275template(3, NotificationSettingsComponent_Conditional_22_For_4_div_3_Template, 10, 3, "div", 7);
    i023.\u0275\u0275text(4, "\n            ");
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const settingGroup_r5 = ctx.$implicit;
    i023.\u0275\u0275advance(3);
    i023.\u0275\u0275property("jhiHasAnyAuthority", settingGroup_r5.restrictionLevels);
  }
}
function NotificationSettingsComponent_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    i023.\u0275\u0275text(0, "\n    ");
    i023.\u0275\u0275elementStart(1, "div", 6);
    i023.\u0275\u0275text(2, "\n        ");
    i023.\u0275\u0275repeaterCreate(3, NotificationSettingsComponent_Conditional_22_For_4_Template, 6, 1, null, null, i023.\u0275\u0275repeaterTrackByIdentity);
    i023.\u0275\u0275elementEnd();
    i023.\u0275\u0275text(5, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i023.\u0275\u0275nextContext();
    i023.\u0275\u0275advance(3);
    i023.\u0275\u0275repeater(ctx_r1.userSettings.groups);
  }
}
var NotificationSettingsCommunicationChannel, NotificationSettingsComponent;
var init_notification_settings_component = __esm({
  "src/main/webapp/app/shared/user-settings/notification-settings/notification-settings.component.ts"() {
    init_user_settings_directive();
    init_user_settings_constants();
    init_user_settings_service();
    init_alert_service();
    init_notification_settings_service();
    init_user_settings_service();
    init_alert_service();
    init_notification_settings_service();
    init_has_any_authority_directive();
    init_artemis_translate_pipe();
    (function(NotificationSettingsCommunicationChannel2) {
      NotificationSettingsCommunicationChannel2[NotificationSettingsCommunicationChannel2["WEBAPP"] = 0] = "WEBAPP";
      NotificationSettingsCommunicationChannel2[NotificationSettingsCommunicationChannel2["EMAIL"] = 1] = "EMAIL";
    })(NotificationSettingsCommunicationChannel || (NotificationSettingsCommunicationChannel = {}));
    NotificationSettingsComponent = class _NotificationSettingsComponent extends UserSettingsDirective {
      notificationSettingsService;
      faSave = faSave;
      faInfoCircle = faInfoCircle3;
      constructor(userSettingsService, changeDetector, alertService, notificationSettingsService) {
        super(userSettingsService, alertService, changeDetector);
        this.notificationSettingsService = notificationSettingsService;
      }
      userSettings;
      settings;
      communicationChannel = NotificationSettingsCommunicationChannel;
      ngOnInit() {
        this.userSettingsCategory = UserSettingsCategory.NOTIFICATION_SETTINGS;
        this.changeEventMessage = reloadNotificationSideBarMessage;
        const newestNotificationSettings = this.notificationSettingsService.getNotificationSettings();
        if (newestNotificationSettings.length === 0) {
          super.ngOnInit();
        } else {
          this.userSettings = this.userSettingsService.loadSettingsSuccessAsSettingsStructure(newestNotificationSettings, this.userSettingsCategory);
          this.settings = this.userSettingsService.extractIndividualSettingsFromSettingsStructure(this.userSettings);
          this.changeDetector.detectChanges();
        }
      }
      toggleSetting(event, communicationChannel) {
        this.settingsChanged = true;
        let settingId = event.currentTarget.id;
        if (settingId.indexOf(" ") !== -1) {
          settingId = settingId.slice(0, settingId.indexOf(" "));
        }
        const settingToUpdate = this.settings.find((setting) => setting.settingId === settingId);
        if (!settingToUpdate) {
          return;
        }
        switch (communicationChannel) {
          case NotificationSettingsCommunicationChannel.WEBAPP: {
            settingToUpdate.webapp = !settingToUpdate.webapp;
            break;
          }
          case NotificationSettingsCommunicationChannel.EMAIL: {
            settingToUpdate.email = !settingToUpdate.email;
            break;
          }
        }
        settingToUpdate.changed = true;
      }
      static \u0275fac = function NotificationSettingsComponent_Factory(t) {
        return new (t || _NotificationSettingsComponent)(i023.\u0275\u0275directiveInject(UserSettingsService), i023.\u0275\u0275directiveInject(i023.ChangeDetectorRef), i023.\u0275\u0275directiveInject(AlertService), i023.\u0275\u0275directiveInject(NotificationSettingsService));
      };
      static \u0275cmp = i023.\u0275\u0275defineComponent({ type: _NotificationSettingsComponent, selectors: [["jhi-notification-settings"]], features: [i023.\u0275\u0275InheritDefinitionFeature], decls: 23, vars: 9, consts: [[1, "d-flex", "justify-content-between"], [1, "d-inline-flex", "userSettings-info"], [1, "ng-fa-icon", 3, "icon"], [1, "ps-1"], ["type", "button", "id", "apply-changes-button", 1, "btn", "btn-primary", 3, "click"], [1, "ng", 3, "icon"], [1, "list-group", "d-block"], ["class", "list-group-item", 4, "jhiHasAnyAuthority"], [1, "list-group-item"], [1, "d-flex"], [1, "form-check", "pe-3"], ["type", "checkbox", 1, "form-check-input", 3, "checked", "id", "value", "click"], [1, "form-check-label", 3, "for"], [1, "form-check"]], template: function NotificationSettingsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i023.\u0275\u0275elementStart(0, "div", 0);
          i023.\u0275\u0275text(1, "\n    ");
          i023.\u0275\u0275elementStart(2, "div");
          i023.\u0275\u0275text(3, "\n        ");
          i023.\u0275\u0275elementStart(4, "h1");
          i023.\u0275\u0275text(5, "\n            ");
          i023.\u0275\u0275text(6);
          i023.\u0275\u0275pipe(7, "artemisTranslate");
          i023.\u0275\u0275elementEnd();
          i023.\u0275\u0275text(8, "\n        ");
          i023.\u0275\u0275elementStart(9, "div", 1);
          i023.\u0275\u0275text(10, "\n            ");
          i023.\u0275\u0275element(11, "fa-icon", 2);
          i023.\u0275\u0275text(12, "\n            ");
          i023.\u0275\u0275elementStart(13, "span", 3);
          i023.\u0275\u0275text(14, "\n                ");
          i023.\u0275\u0275text(15);
          i023.\u0275\u0275pipe(16, "artemisTranslate");
          i023.\u0275\u0275elementEnd();
          i023.\u0275\u0275text(17, "\n        ");
          i023.\u0275\u0275elementEnd();
          i023.\u0275\u0275text(18, "\n    ");
          i023.\u0275\u0275elementEnd();
          i023.\u0275\u0275text(19, "\n    ");
          i023.\u0275\u0275template(20, NotificationSettingsComponent_Conditional_20_Template, 7, 4);
          i023.\u0275\u0275elementEnd();
          i023.\u0275\u0275text(21, "\n");
          i023.\u0275\u0275template(22, NotificationSettingsComponent_Conditional_22_Template, 6, 0);
        }
        if (rf & 2) {
          i023.\u0275\u0275advance(6);
          i023.\u0275\u0275textInterpolate1("\n            ", i023.\u0275\u0275pipeBind1(7, 5, "artemisApp.userSettings.categories." + ctx.userSettingsCategory), "\n        ");
          i023.\u0275\u0275advance(5);
          i023.\u0275\u0275property("icon", ctx.faInfoCircle);
          i023.\u0275\u0275advance(4);
          i023.\u0275\u0275textInterpolate1("\n                ", i023.\u0275\u0275pipeBind1(16, 7, "artemisApp.userSettings.notificationSettingsFilterInfo"), "\n            ");
          i023.\u0275\u0275advance(5);
          i023.\u0275\u0275conditional(20, ctx.settingsChanged ? 20 : -1);
          i023.\u0275\u0275advance(2);
          i023.\u0275\u0275conditional(22, ctx.userSettings ? 22 : -1);
        }
      }, dependencies: [i44.FaIconComponent, HasAnyAuthorityDirective, ArtemisTranslatePipe], styles: ["\n\n#apply-changes-button[_ngcontent-%COMP%] {\n  width: 250px;\n  height: 40px;\n  font-size: large;\n  border: 0;\n}\nh3[_ngcontent-%COMP%] {\n  font-weight: bold;\n  text-underline-offset: 3px;\n}\ndt[_ngcontent-%COMP%] {\n  font-size: large;\n  font-weight: 500;\n}\ndd[_ngcontent-%COMP%] {\n  font-size: larger;\n}\nspan[_ngcontent-%COMP%] {\n  color: gray;\n  font-size: smaller;\n}\n.userSettings-info[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-style: italic;\n  color: gray;\n  font-size: large;\n  font-weight: bolder;\n}\n.userSettings-info[_ngcontent-%COMP%]   .ng-fa-icon[_ngcontent-%COMP%] {\n  color: gray;\n}\n.form-check[_ngcontent-%COMP%] {\n  padding-top: 5px;\n  padding-bottom: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvdXNlci1zZXR0aW5ncy91c2VyLXNldHRpbmdzLnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIiNhcHBseS1jaGFuZ2VzLWJ1dHRvbiB7XG4gICAgd2lkdGg6IDI1MHB4O1xuICAgIGhlaWdodDogNDBweDtcbiAgICBmb250LXNpemU6IGxhcmdlO1xuICAgIGJvcmRlcjogMDtcbn1cblxuaDMge1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIHRleHQtdW5kZXJsaW5lLW9mZnNldDogM3B4O1xufVxuXG5kdCB7XG4gICAgZm9udC1zaXplOiBsYXJnZTtcbiAgICBmb250LXdlaWdodDogNTAwO1xufVxuXG5kZCB7XG4gICAgZm9udC1zaXplOiBsYXJnZXI7XG59XG5cbnNwYW4ge1xuICAgIGNvbG9yOiBncmF5O1xuICAgIGZvbnQtc2l6ZTogc21hbGxlcjtcbn1cblxuLnVzZXJTZXR0aW5ncy1pbmZvIHtcbiAgICBzcGFuIHtcbiAgICAgICAgZm9udC1zdHlsZTogaXRhbGljO1xuICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgZm9udC1zaXplOiBsYXJnZTtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcbiAgICB9XG5cbiAgICAubmctZmEtaWNvbiB7XG4gICAgICAgIGNvbG9yOiBncmF5O1xuICAgIH1cbn1cblxuLmZvcm0tY2hlY2sge1xuICAgIHBhZGRpbmctdG9wOiA1cHg7XG4gICAgcGFkZGluZy1ib3R0b206IDVweDtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksU0FBQTtBQUNBLFVBQUE7QUFDQSxhQUFBO0FBQ0EsVUFBQTs7QUFHSjtBQUNJLGVBQUE7QUFDQSx5QkFBQTs7QUFHSjtBQUNJLGFBQUE7QUFDQSxlQUFBOztBQUdKO0FBQ0ksYUFBQTs7QUFHSjtBQUNJLFNBQUE7QUFDQSxhQUFBOztBQUlBLENBQUEsa0JBQUE7QUFDSSxjQUFBO0FBQ0EsU0FBQTtBQUNBLGFBQUE7QUFDQSxlQUFBOztBQUdKLENBUEEsa0JBT0EsQ0FBQTtBQUNJLFNBQUE7O0FBSVIsQ0FBQTtBQUNJLGVBQUE7QUFDQSxrQkFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i023.\u0275setClassDebugInfo(NotificationSettingsComponent, { className: "NotificationSettingsComponent" });
    })();
  }
});

// src/main/webapp/app/shared/user-settings/user-settings.route.ts
var userSettingsState;
var init_user_settings_route = __esm({
  "src/main/webapp/app/shared/user-settings/user-settings.route.ts"() {
    init_user_settings_container_component();
    init_account_information_component();
    init_notification_settings_component();
    init_user_route_access_service();
    init_authority_constants();
    userSettingsState = [
      {
        path: "user-settings",
        component: UserSettingsContainerComponent,
        canActivate: [UserRouteAccessService],
        data: {
          authorities: [Authority.USER]
        },
        children: [
          {
            path: "",
            pathMatch: "full",
            redirectTo: "account"
          },
          {
            path: "account",
            component: AccountInformationComponent,
            data: {
              pageTitle: "artemisApp.userSettings.accountInformation"
            }
          },
          {
            path: "notifications",
            component: NotificationSettingsComponent,
            data: {
              pageTitle: "artemisApp.userSettings.categories.NOTIFICATION_SETTINGS"
            }
          }
        ]
      }
    ];
  }
});

// src/main/webapp/app/shared/user-settings/user-settings.module.ts
import { NgModule as NgModule5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { RouterModule as RouterModule3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i024 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var UserSettingsModule;
var init_user_settings_module = __esm({
  "src/main/webapp/app/shared/user-settings/user-settings.module.ts"() {
    init_user_settings_container_component();
    init_account_information_component();
    init_notification_settings_component();
    init_shared_module();
    init_user_settings_route();
    UserSettingsModule = class _UserSettingsModule {
      static \u0275fac = function UserSettingsModule_Factory(t) {
        return new (t || _UserSettingsModule)();
      };
      static \u0275mod = i024.\u0275\u0275defineNgModule({ type: _UserSettingsModule });
      static \u0275inj = i024.\u0275\u0275defineInjector({ imports: [RouterModule3.forChild(userSettingsState), ArtemisSharedModule] });
    };
  }
});

// src/main/webapp/app/core/theme/theme.module.ts
import { NgModule as NgModule6 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { CommonModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import { TranslateModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i025 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ThemeModule;
var init_theme_module = __esm({
  "src/main/webapp/app/core/theme/theme.module.ts"() {
    init_shared_module();
    init_theme_switch_component();
    ThemeModule = class _ThemeModule {
      static \u0275fac = function ThemeModule_Factory(t) {
        return new (t || _ThemeModule)();
      };
      static \u0275mod = i025.\u0275\u0275defineNgModule({ type: _ThemeModule });
      static \u0275inj = i025.\u0275\u0275defineInjector({ imports: [TranslateModule, CommonModule, ArtemisSharedModule] });
    };
  }
});

// src/main/webapp/app/app.module.ts
import { NgModule as NgModule7 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { BrowserModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_platform-browser.js?v=1d0d9ead";
import { ServiceWorkerModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_service-worker.js?v=1d0d9ead";
import { BrowserAnimationsModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_platform-browser_animations.js?v=1d0d9ead";
import * as i026 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisAppModule;
var init_app_module = __esm({
  "src/main/webapp/app/app.module.ts"() {
    init_system_notification_module();
    init_navbar_component();
    init_notification_sidebar_component();
    init_page_ribbon_component();
    init_exercise_headers_module();
    init_system_notification_component();
    init_app_routing_module();
    init_main_component();
    init_shared_module();
    init_courses_module();
    init_footer_component();
    init_active_menu_directive();
    init_error_component();
    init_core_module();
    init_guided_tour_module();
    init_complaints_module();
    init_home_module();
    init_orion_outdated_component();
    init_loading_notification_component();
    init_notification_popup_component();
    init_user_settings_module();
    init_theme_module();
    init_shared_component_module();
    ArtemisAppModule = class _ArtemisAppModule {
      static \u0275fac = function ArtemisAppModule_Factory(t) {
        return new (t || _ArtemisAppModule)();
      };
      static \u0275mod = i026.\u0275\u0275defineNgModule({ type: _ArtemisAppModule, bootstrap: [JhiMainComponent] });
      static \u0275inj = i026.\u0275\u0275defineInjector({ imports: [
        BrowserModule,
        BrowserAnimationsModule,
        ServiceWorkerModule.register("ngsw-worker.js", { enabled: true }),
        ArtemisSharedModule,
        ArtemisCoreModule,
        ArtemisHomeModule,
        ArtemisAppRoutingModule,
        GuidedTourModule,
        ArtemisCoursesModule,
        ArtemisSystemNotificationModule,
        ArtemisComplaintsModule,
        ArtemisHeaderExercisePageWithDetailsModule,
        UserSettingsModule,
        ThemeModule,
        ArtemisSharedComponentModule
      ] });
    };
  }
});

// src/main/webapp/app/app.main.ts
import * as __NgCli_bootstrap_1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_platform-browser.js?v=1d0d9ead";
var require_app_main = __commonJS({
  "src/main/webapp/app/app.main.ts"(exports, module) {
    init_polyfills();
    init_array_extension();
    init_map_extension();
    init_string_extension();
    init_prod_config();
    init_app_module();
    ProdConfig();
    if (module["hot"]) {
      module["hot"].accept();
      if (true) {
        console.clear();
      }
    }
    __NgCli_bootstrap_1.platformBrowser().bootstrapModule(ArtemisAppModule, { preserveWhitespaces: true }).then(() => {
    }).catch((err) => console.error(err));
  }
});
export default require_app_main();


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvcG9seWZpbGxzLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvdXRpbC9hcnJheS5leHRlbnNpb24udHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC91dGlsL21hcC5leHRlbnNpb24udHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC91dGlsL3N0cmluZy5leHRlbnNpb24udHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvcmUvY29uZmlnL3Byb2QuY29uZmlnLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL3N5c3RlbS1ub3RpZmljYXRpb24vc3lzdGVtLW5vdGlmaWNhdGlvbi5tb2R1bGUudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2d1aWRlZC10b3VyL2d1aWRlZC10b3VyLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZ3VpZGVkLXRvdXIvZ3VpZGVkLXRvdXIuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvcmUvdGhlbWUvdGhlbWUtc3dpdGNoLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvY29yZS90aGVtZS90aGVtZS1zd2l0Y2guY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9sYXlvdXRzL25hdmJhci9hY3RpdmUtbWVudS5kaXJlY3RpdmUudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vbm90aWZpY2F0aW9uLXNpZGViYXIvbm90aWZpY2F0aW9uLXNpZGViYXIuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL25vdGlmaWNhdGlvbi1zaWRlYmFyL25vdGlmaWNhdGlvbi1zaWRlYmFyLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL3N5c3RlbS1ub3RpZmljYXRpb24vc3lzdGVtLW5vdGlmaWNhdGlvbi5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vc3lzdGVtLW5vdGlmaWNhdGlvbi9zeXN0ZW0tbm90aWZpY2F0aW9uLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL2xvYWRpbmctbm90aWZpY2F0aW9uL2xvYWRpbmctbm90aWZpY2F0aW9uLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2xheW91dHMvbmF2YmFyL25hdmJhci5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9sYXlvdXRzL25hdmJhci9uYXZiYXIuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9sYXlvdXRzL3Byb2ZpbGVzL3BhZ2UtcmliYm9uLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2xheW91dHMvbmF2YmFyL25hdmJhci5yb3V0ZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2xheW91dHMvZXJyb3IvZXJyb3IuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbGF5b3V0cy9lcnJvci9lcnJvci5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL29yaW9uL291dGRhdGVkLXBsdWdpbi13YXJuaW5nL29yaW9uLW91dGRhdGVkLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2xheW91dHMvZXJyb3IvZXJyb3Iucm91dGUudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2FwcC1yb3V0aW5nLm1vZHVsZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2xheW91dHMvZm9vdGVyL2Zvb3Rlci5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9sYXlvdXRzL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vbm90aWZpY2F0aW9uLXBvcHVwL25vdGlmaWNhdGlvbi1wb3B1cC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vbm90aWZpY2F0aW9uLXBvcHVwL25vdGlmaWNhdGlvbi1wb3B1cC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2xheW91dHMvbWFpbi9tYWluLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2xheW91dHMvbWFpbi9tYWluLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9ndWlkZWQtdG91ci9ndWlkZWQtdG91ci5tb2R1bGUudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2hvbWUvc2FtbDItbG9naW4vc2FtbDItbG9naW4uY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9ob21lL3NhbWwyLWxvZ2luL3NhbWwyLWxvZ2luLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9ob21lL2hvbWUuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9ob21lL2hvbWUuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2hvbWUvaG9tZS5yb3V0ZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaG9tZS9ob21lLm1vZHVsZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3VzZXItc2V0dGluZ3MvYWNjb3VudC1pbmZvcm1hdGlvbi9hY2NvdW50LWluZm9ybWF0aW9uLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3VzZXItc2V0dGluZ3MvYWNjb3VudC1pbmZvcm1hdGlvbi9hY2NvdW50LWluZm9ybWF0aW9uLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvdXNlci1zZXR0aW5ncy91c2VyLXNldHRpbmdzLWNvbnRhaW5lci91c2VyLXNldHRpbmdzLWNvbnRhaW5lci5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC91c2VyLXNldHRpbmdzL3VzZXItc2V0dGluZ3MtY29udGFpbmVyL3VzZXItc2V0dGluZ3MtY29udGFpbmVyLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvdXNlci1zZXR0aW5ncy91c2VyLXNldHRpbmdzLmRpcmVjdGl2ZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3VzZXItc2V0dGluZ3Mvbm90aWZpY2F0aW9uLXNldHRpbmdzL25vdGlmaWNhdGlvbi1zZXR0aW5ncy5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC91c2VyLXNldHRpbmdzL25vdGlmaWNhdGlvbi1zZXR0aW5ncy9ub3RpZmljYXRpb24tc2V0dGluZ3MuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC91c2VyLXNldHRpbmdzL3VzZXItc2V0dGluZ3Mucm91dGUudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC91c2VyLXNldHRpbmdzL3VzZXItc2V0dGluZ3MubW9kdWxlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3JlL3RoZW1lL3RoZW1lLm1vZHVsZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXBwLm1vZHVsZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXBwLm1haW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICd6b25lLmpzJztcbmltcG9ydCAnQGFuZ3VsYXIvbG9jYWxpemUvaW5pdCc7XG5pbXBvcnQgKiBhcyBwcm9jZXNzIGZyb20gJ3Byb2Nlc3MnO1xuXG4vLyBGaXggbmVlZGVkIGZvciBTb2NrSlMsIHNlZSBodHRwczovL2dpdGh1Yi5jb20vc29ja2pzL3NvY2tqcy1jbGllbnQvaXNzdWVzLzQzOVxuKHdpbmRvdyBhcyBhbnkpLmdsb2JhbCA9IHdpbmRvdztcblxud2luZG93Wydwcm9jZXNzJ10gPSBwcm9jZXNzO1xuIiwiZXhwb3J0IHt9O1xuXG5kZWNsYXJlIGdsb2JhbCB7XG4gICAgaW50ZXJmYWNlIEFycmF5PFQ+IHtcbiAgICAgICAgbGFzdCgpOiBUIHwgdW5kZWZpbmVkO1xuICAgICAgICBmaXJzdCgpOiBUIHwgdW5kZWZpbmVkO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBTaHVmZmxlcyBhcnJheSBpbiBwbGFjZS5cbiAgICAgICAgICovXG4gICAgICAgIHNodWZmbGUoKTogdm9pZDtcbiAgICB9XG59XG5cbmlmICghQXJyYXkucHJvdG90eXBlLmxhc3QpIHtcbiAgICBBcnJheS5wcm90b3R5cGUubGFzdCA9IGZ1bmN0aW9uIGxhc3Q8VD4oKTogVCB8IHVuZGVmaW5lZCB7XG4gICAgICAgIGlmICghdGhpcy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXNbdGhpcy5sZW5ndGggLSAxXTtcbiAgICB9O1xufVxuXG5pZiAoIUFycmF5LnByb3RvdHlwZS5maXJzdCkge1xuICAgIEFycmF5LnByb3RvdHlwZS5maXJzdCA9IGZ1bmN0aW9uIGZpcnN0PFQ+KCk6IFQgfCB1bmRlZmluZWQge1xuICAgICAgICBpZiAoIXRoaXMubGVuZ3RoKSB7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzWzBdO1xuICAgIH07XG59XG5cbmlmICghQXJyYXkucHJvdG90eXBlLnNodWZmbGUpIHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVudXNlZC12YXJzXG4gICAgQXJyYXkucHJvdG90eXBlLnNodWZmbGUgPSBmdW5jdGlvbiBzaHVmZmxlPFQ+KCk6IHZvaWQge1xuICAgICAgICBpZiAodGhpcy5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gdGhpcy5sZW5ndGggLSAxOyBpID4gMDsgaS0tKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmFuZG9tSW5kZXggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAoaSArIDEpKTtcbiAgICAgICAgICAgICAgICBjb25zdCByYW5kb21FbGVtZW50ID0gdGhpc1tyYW5kb21JbmRleF07XG4gICAgICAgICAgICAgICAgdGhpc1tyYW5kb21JbmRleF0gPSB0aGlzW2ldO1xuICAgICAgICAgICAgICAgIHRoaXNbaV0gPSByYW5kb21FbGVtZW50O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbn1cbiIsImV4cG9ydCB7fTtcblxuZGVjbGFyZSBnbG9iYWwge1xuICAgIGV4cG9ydCBpbnRlcmZhY2UgTWFwPEssIFY+IHtcbiAgICAgICAgY29tcHV0ZUlmQWJzZW50KGtleTogSywgbWFwcGluZ0Z1bmN0aW9uOiAoa2V5OiBLKSA9PiBWKTogVjtcbiAgICB9XG59XG5cbmlmICghTWFwLnByb3RvdHlwZS5jb21wdXRlSWZBYnNlbnQpIHtcbiAgICBNYXAucHJvdG90eXBlLmNvbXB1dGVJZkFic2VudCA9IGZ1bmN0aW9uIChrZXksIG1hcHBpbmdGdW5jdGlvbikge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IHRoaXMuZ2V0KGtleSk7XG4gICAgICAgIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdmFsdWVUb0FkZCA9IG1hcHBpbmdGdW5jdGlvbihrZXkpO1xuICAgICAgICB0aGlzLnNldChrZXksIHZhbHVlVG9BZGQpO1xuICAgICAgICByZXR1cm4gdmFsdWVUb0FkZDtcbiAgICB9O1xufVxuIiwiZXhwb3J0IHt9O1xuXG5kZWNsYXJlIGdsb2JhbCB7XG4gICAgZXhwb3J0IGludGVyZmFjZSBTdHJpbmcge1xuICAgICAgICByZXBsYWNlQWxsKHNlYXJjaDogc3RyaW5nLCByZXBsYWNlbWVudDogc3RyaW5nKTogc3RyaW5nO1xuICAgIH1cbn1cblxuaWYgKCFTdHJpbmcucHJvdG90eXBlLnJlcGxhY2VBbGwpIHtcbiAgICBTdHJpbmcucHJvdG90eXBlLnJlcGxhY2VBbGwgPSBmdW5jdGlvbiAoc2VhcmNoLCByZXBsYWNlbWVudCkge1xuICAgICAgICByZXR1cm4gdGhpcy5yZXBsYWNlKG5ldyBSZWdFeHAoc2VhcmNoLCAnZycpLCByZXBsYWNlbWVudCk7XG4gICAgfTtcbn1cbiIsImltcG9ydCB7IGVuYWJsZVByb2RNb2RlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBERUJVR19JTkZPX0VOQUJMRUQgfSBmcm9tICdhcHAvYXBwLmNvbnN0YW50cyc7XG5cbi8qKlxuICogRGlzYWJsZSBkZWJ1ZyBkYXRhIG9uIHByb2QgcHJvZmlsZSB0byBpbXByb3ZlIHBlcmZvcm1hbmNlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBQcm9kQ29uZmlnKCkge1xuICAgIGlmICghREVCVUdfSU5GT19FTkFCTEVEKSB7XG4gICAgICAgIGVuYWJsZVByb2RNb2RlKCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgU3lzdGVtTm90aWZpY2F0aW9uU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL3N5c3RlbS1ub3RpZmljYXRpb24vc3lzdGVtLW5vdGlmaWNhdGlvbi5zZXJ2aWNlJztcbmltcG9ydCB7IEFkbWluU3lzdGVtTm90aWZpY2F0aW9uU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL3N5c3RlbS1ub3RpZmljYXRpb24vYWRtaW4tc3lzdGVtLW5vdGlmaWNhdGlvbi5zZXJ2aWNlJztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZV0sXG4gICAgcHJvdmlkZXJzOiBbU3lzdGVtTm90aWZpY2F0aW9uU2VydmljZSwgQWRtaW5TeXN0ZW1Ob3RpZmljYXRpb25TZXJ2aWNlXSxcbn0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc1N5c3RlbU5vdGlmaWNhdGlvbk1vZHVsZSB7fVxuIiwiaW1wb3J0IHsgQWZ0ZXJWaWV3SW5pdCwgQ29tcG9uZW50LCBFbGVtZW50UmVmLCBIb3N0TGlzdGVuZXIsIE9uRGVzdHJveSwgUXVlcnlMaXN0LCBSZW5kZXJlcjIsIFZpZXdDaGlsZCwgVmlld0NoaWxkcmVuLCBWaWV3RW5jYXBzdWxhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uLCBmcm9tRXZlbnQgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IHRha2UsIHRhcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IERpcmVjdGlvbiwgT3JpZW50YXRpb24sIE92ZXJsYXlQb3NpdGlvbiwgVXNlckludGVyYWN0aW9uRXZlbnQgfSBmcm9tICcuL2d1aWRlZC10b3VyLmNvbnN0YW50cyc7XG5pbXBvcnQgeyBHdWlkZWRUb3VyU2VydmljZSB9IGZyb20gJy4vZ3VpZGVkLXRvdXIuc2VydmljZSc7XG5pbXBvcnQgeyBBY2NvdW50U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL2F1dGgvYWNjb3VudC5zZXJ2aWNlJztcbmltcG9ydCB7IEltYWdlVG91clN0ZXAsIFRleHRUb3VyU3RlcCwgVmlkZW9Ub3VyU3RlcCB9IGZyb20gJ2FwcC9ndWlkZWQtdG91ci9ndWlkZWQtdG91ci1zdGVwLm1vZGVsJztcbmltcG9ydCB7IGNhbmNlbFRvdXIsIGNvbXBsZXRlZFRvdXIgfSBmcm9tICdhcHAvZ3VpZGVkLXRvdXIvdG91cnMvZ2VuZXJhbC10b3VyJztcbmltcG9ydCB7IGNhbGN1bGF0ZUxlZnRPZmZzZXQsIGNhbGN1bGF0ZVRvcE9mZnNldCwgaXNFbGVtZW50SW5WaWV3UG9ydEhvcml6b250YWxseSB9IGZyb20gJ2FwcC9ndWlkZWQtdG91ci9ndWlkZWQtdG91ci51dGlscyc7XG5pbXBvcnQge1xuICAgIGZhQXJyb3dzQWx0LFxuICAgIGZhQ2hlY2ssXG4gICAgZmFDaGV2cm9uTGVmdCxcbiAgICBmYUNoZXZyb25SaWdodCxcbiAgICBmYUNpcmNsZU5vdGNoLFxuICAgIGZhQ2xpcGJvYXJkTGlzdCxcbiAgICBmYUVkaXQsXG4gICAgZmFIYW5kUG9pbnRVcCxcbiAgICBmYUlDdXJzb3IsXG4gICAgZmFJbmZvQ2lyY2xlLFxuICAgIGZhUGxheUNpcmNsZSxcbiAgICBmYVZpZGVvLFxufSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1ndWlkZWQtdG91cicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2d1aWRlZC10b3VyLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9ndWlkZWQtdG91ci5jb21wb25lbnQuc2NzcyddLFxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXG59KVxuZXhwb3J0IGNsYXNzIEd1aWRlZFRvdXJDb21wb25lbnQgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xuICAgIEBWaWV3Q2hpbGQoJ3RvdXJTdGVwJywgeyBzdGF0aWM6IGZhbHNlIH0pIHByaXZhdGUgdG91clN0ZXA6IEVsZW1lbnRSZWY7XG4gICAgQFZpZXdDaGlsZCgnZG90TmF2aWdhdGlvbicsIHsgc3RhdGljOiBmYWxzZSB9KSBwcml2YXRlIGRvdE5hdmlnYXRpb246IEVsZW1lbnRSZWY7XG4gICAgQFZpZXdDaGlsZHJlbignZG90RWxlbWVudHMnKSBwcml2YXRlIGRvdEVsZW1lbnRzOiBRdWVyeUxpc3Q8RWxlbWVudFJlZj47XG5cbiAgICAvLyBUT0RPIGF1dG9tYXRpY2FsbHkgZGV0ZXJtaW5lIG9wdGltYWwgd2lkdGggb2YgdG91ciBzdGVwXG4gICAgLy8gU2V0cyB0aGUgd2lkdGggb2YgYWxsIHRvdXIgc3RlcCBlbGVtZW50cy5cbiAgICBwdWJsaWMgdG91clN0ZXBXaWR0aCA9IDU1MDtcbiAgICAvLyBTZXRzIHRoZSBtaW5pbWFsIHdpZHRoIG9mIGFsbCB0b3VyIHN0ZXAgZWxlbWVudHMuXG4gICAgcHVibGljIG1pbmltYWxUb3VyU3RlcFdpZHRoID0gNTAwO1xuICAgIHB1YmxpYyBvcmllbnRhdGlvbjogT3JpZW50YXRpb247XG4gICAgcHVibGljIHRyYW5zZm9ybVg6IG51bWJlcjtcbiAgICAvKipcbiAgICAgKiBUaGUgY3VycmVudCB0b3VyIHN0ZXAgc2hvdWxkIGJlIG9mIHR5cGUgdGhlIFRvdXJTdGVwIHN1YmNsYXNzZXMgb3IgdW5kZWZpbmVkIGJ1dCBoYXZlIHRvIGJlIGRlY2xhcmVkIGFzIGFueSBpbiB0aGlzIGNhc2VcbiAgICAgKiBzaW5jZSB0aGUgYnVpbGQgd291bGQgZmFpbCB3aXRoIFByb3BlcnR5ICd4JyBkb2VzIG5vdCBleGlzdCBvbiB0eXBlICd5JyB3aGVuIGFjY2Vzc2luZyBwcm9wZXJ0aWVzIG9mIHN1YmNsYXNzZXMgaW4gdGhlIGh0bWwgdGVtcGxhdGVcbiAgICAgKiB0aGF0IGFyZSBub3QgYXZhaWxhYmxlIGZvciBhbGwgc3ViY2xhc3Nlc1xuICAgICAqL1xuICAgIHB1YmxpYyBjdXJyZW50VG91clN0ZXA6IGFueTtcbiAgICBwdWJsaWMgc2VsZWN0ZWRFbGVtZW50UmVjdD86IERPTVJlY3Q7XG4gICAgcHVibGljIHN0YXJ0RmFkZSA9IGZhbHNlO1xuICAgIHB1YmxpYyB1c2VySW50ZXJhY3Rpb25GaW5pc2hlZCA9IGZhbHNlO1xuXG4gICAgcHJpdmF0ZSByZXNpemVTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcbiAgICBwcml2YXRlIHNjcm9sbFN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xuICAgIHByaXZhdGUgY2xpY2tTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcblxuICAgIHJlYWRvbmx5IE92ZXJsYXlQb3NpdGlvbiA9IE92ZXJsYXlQb3NpdGlvbjtcbiAgICByZWFkb25seSBVc2VySW50ZXJhY3Rpb25FdmVudCA9IFVzZXJJbnRlcmFjdGlvbkV2ZW50O1xuICAgIHJlYWRvbmx5IGNhbmNlbFRvdXIgPSBjYW5jZWxUb3VyO1xuICAgIHJlYWRvbmx5IGNvbXBsZXRlZFRvdXIgPSBjb21wbGV0ZWRUb3VyO1xuXG4gICAgLyoqIFZhcmlhYmxlcyBmb3IgdGhlIGRvdCBuYXZpZ2F0aW9uICovXG4gICAgcHVibGljIG1heERvdHMgPSAxMDtcbiAgICBwcml2YXRlIHRyYW5zZm9ybUNvdW50ID0gMDtcbiAgICBwcml2YXRlIHRyYW5zZm9ybVhJbnRlcnZhbE5leHQgPSAtMjY7XG4gICAgcHJpdmF0ZSB0cmFuc2Zvcm1YSW50ZXJ2YWxQcmV2ID0gMjY7XG4gICAgcHJpdmF0ZSBkb3RBcnJheTogQXJyYXk8RWxlbWVudFJlZj47XG4gICAgcHVibGljIGN1cnJlbnRTdGVwSW5kZXg/OiBudW1iZXI7XG4gICAgcHVibGljIG5leHRTdGVwSW5kZXg/OiBudW1iZXI7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhRWRpdCA9IGZhRWRpdDtcbiAgICBmYUNoZWNrID0gZmFDaGVjaztcbiAgICBmYVZpZGVvID0gZmFWaWRlbztcbiAgICBmYUNoZXZyb25SaWdodCA9IGZhQ2hldnJvblJpZ2h0O1xuICAgIGZhQ2hldnJvbkxlZnQgPSBmYUNoZXZyb25MZWZ0O1xuICAgIGZhQ2lyY2xlTm90Y2ggPSBmYUNpcmNsZU5vdGNoO1xuICAgIGZhSW5mb0NpcmNsZSA9IGZhSW5mb0NpcmNsZTtcbiAgICBmYUFycm93c0FsdCA9IGZhQXJyb3dzQWx0O1xuICAgIGZhQ2xpcGJvYXJkTGlzdCA9IGZhQ2xpcGJvYXJkTGlzdDtcbiAgICBmYUlDdXJzb3IgPSBmYUlDdXJzb3I7XG4gICAgZmFIYW5kUG9pbnRVcCA9IGZhSGFuZFBvaW50VXA7XG4gICAgZmFQbGF5Q2lyY2xlID0gZmFQbGF5Q2lyY2xlO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHB1YmxpYyBndWlkZWRUb3VyU2VydmljZTogR3VpZGVkVG91clNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgYWNjb3VudFNlcnZpY2U6IEFjY291bnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjIsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogRW5hYmxlIHRvdXIgbmF2aWdhdGlvbiB3aXRoIGxlZnQgYW5kIHJpZ2h0IGtleWJvYXJkIGFycm93cyBhbmQgZXNjYXBlIGtleVxuICAgICAqIEBwYXJhbSBldmVudDoga2V5Ym9hcmQga2V5ZG93biBldmVudFxuICAgICAqL1xuICAgIEBIb3N0TGlzdGVuZXIoJ2RvY3VtZW50OmtleWRvd24nLCBbJyRldmVudCddKVxuICAgIGhhbmRsZUtleWJvYXJkRXZlbnQoZXZlbnQ6IEtleWJvYXJkRXZlbnQpIHtcbiAgICAgICAgaWYgKHRoaXMuZ3VpZGVkVG91clNlcnZpY2UuaXNPblJlc2l6ZU1lc3NhZ2UpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBzd2l0Y2ggKGV2ZW50LmNvZGUpIHtcbiAgICAgICAgICAgIGNhc2UgJ0Fycm93UmlnaHQnOiB7XG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogQ2hlY2sgaWYgdGhlIGN1cnJlbnRUb3VyU3RlcCBpcyBkZWZpbmVkIHNvIHRoYXQgdGhlIGd1aWRlZCB0b3VyIGNhbm5vdCBiZSBzdGFydGVkIGJ5IHByZXNzaW5nIHRoZSByaWdodCBhcnJvd1xuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLmN1cnJlbnRUb3VyU3RlcCAmJiB0aGlzLmd1aWRlZFRvdXJTZXJ2aWNlLmN1cnJlbnRUb3VyU3RlcERpc3BsYXkgPD0gdGhpcy5ndWlkZWRUb3VyU2VydmljZS5jdXJyZW50VG91clN0ZXBDb3VudCkge1xuICAgICAgICAgICAgICAgICAgICAvKiogSWYgdGhlIHVzZXIgaW50ZXJhY3Rpb24gaXMgZW5hYmxlZCwgdGhlbiB0aGUgdXNlciBoYXMgY2FuIG9ubHkgbW92ZSB0byB0aGUgbmV4dCBzdGVwIGFmdGVyIGZpbmlzaGluZyB0aGUgaW50ZXJhY3Rpb24gKi9cbiAgICAgICAgICAgICAgICAgICAgaWYgKCF0aGlzLmN1cnJlbnRUb3VyU3RlcC51c2VySW50ZXJhY3Rpb25FdmVudCB8fCAodGhpcy5jdXJyZW50VG91clN0ZXAudXNlckludGVyYWN0aW9uRXZlbnQgJiYgdGhpcy51c2VySW50ZXJhY3Rpb25GaW5pc2hlZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ3VpZGVkVG91clNlcnZpY2UubmV4dFN0ZXAoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ0Fycm93TGVmdCc6IHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jdXJyZW50VG91clN0ZXAgJiYgdGhpcy5ndWlkZWRUb3VyU2VydmljZS5jdXJyZW50VG91clN0ZXBEaXNwbGF5ID4gMSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmd1aWRlZFRvdXJTZXJ2aWNlLmJhY2tTdGVwKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnRXNjYXBlJzoge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLmN1cnJlbnRUb3VyU3RlcCAmJiAhdGhpcy5ndWlkZWRUb3VyU2VydmljZS5pc0N1cnJlbnRUb3VyKGNhbmNlbFRvdXIpICYmICF0aGlzLmd1aWRlZFRvdXJTZXJ2aWNlLmlzQ3VycmVudFRvdXIoY29tcGxldGVkVG91cikpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ndWlkZWRUb3VyU2VydmljZS5za2lwVG91cigpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5jdXJyZW50VG91clN0ZXAgJiYgdGhpcy5ndWlkZWRUb3VyU2VydmljZS5pc09uTGFzdFN0ZXApIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gVGhlIGVzY2FwZSBrZXkgZXZlbnQgZmluaXNoZXMgdGhlIHRvdXIgd2hlbiB0aGUgdXNlciBpcyBzZWVpbmcgdGhlIGNhbmNlbCB0b3VyIHN0ZXAgb3IgbGFzdCB0b3VyIHN0ZXBcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ndWlkZWRUb3VyU2VydmljZS5maW5pc2hHdWlkZWRUb3VyKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSW5pdGlhbCBzdWJzY3JpcHRpb25zIGZvciBHdWlkZWRUb3VyQ3VycmVudFN0ZXBTdHJlYW0sIHJlc2l6ZSBldmVudCBhbmQgc2Nyb2xsIGV2ZW50XG4gICAgICovXG4gICAgcHVibGljIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5ndWlkZWRUb3VyU2VydmljZS5pbml0KCk7XG4gICAgICAgIHRoaXMuc3Vic2NyaWJlVG9HdWlkZWRUb3VyQ3VycmVudFN0ZXBTdHJlYW0oKTtcbiAgICAgICAgdGhpcy5zdWJzY3JpYmVUb1VzZXJJbnRlcmFjdGlvblN0YXRlKCk7XG4gICAgICAgIHRoaXMuc3Vic2NyaWJlVG9SZXNpemVFdmVudCgpO1xuICAgICAgICB0aGlzLnN1YnNjcmliZVRvU2Nyb2xsRXZlbnQoKTtcbiAgICAgICAgdGhpcy5zdWJzY3JpYmVUb0NsaWNrRXZlbnQoKTtcbiAgICAgICAgdGhpcy5zdWJzY3JpYmVUb0RvdENoYW5nZXMoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZW1vdmUgc3Vic2NyaXB0aW9ucyBvbiBkZXN0cm95XG4gICAgICovXG4gICAgcHVibGljIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgICAgICBpZiAodGhpcy5yZXNpemVTdWJzY3JpcHRpb24pIHtcbiAgICAgICAgICAgIHRoaXMucmVzaXplU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMucmVzaXplU3Vic2NyaXB0aW9uKSB7XG4gICAgICAgICAgICB0aGlzLnNjcm9sbFN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmNsaWNrU3Vic2NyaXB0aW9uKSB7XG4gICAgICAgICAgICB0aGlzLmNsaWNrU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIHN1YnNjcmliZVRvRG90Q2hhbmdlcygpIHtcbiAgICAgICAgdGhpcy5kb3RFbGVtZW50cy5jaGFuZ2VzLnN1YnNjcmliZSgoZWxlbWVudHM6IFF1ZXJ5TGlzdDxFbGVtZW50UmVmPikgPT4ge1xuICAgICAgICAgICAgdGhpcy5kb3RBcnJheSA9IGVsZW1lbnRzLnRvQXJyYXkoKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5ndWlkZWRUb3VyU2VydmljZS5jdXJyZW50RG90U3ViamVjdC5waXBlKHRhcCgoY3VycmVudEluZGV4KSA9PiAodGhpcy5jdXJyZW50U3RlcEluZGV4ID0gY3VycmVudEluZGV4KSkpLnN1YnNjcmliZSgpO1xuICAgICAgICB0aGlzLmd1aWRlZFRvdXJTZXJ2aWNlLm5leHREb3RTdWJqZWN0LnBpcGUodGFwKChjdXJyZW50SW5kZXgpID0+ICh0aGlzLm5leHRTdGVwSW5kZXggPSBjdXJyZW50SW5kZXgpKSkuc3Vic2NyaWJlKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU3Vic2NyaWJlIHRvIGd1aWRlZFRvdXJDdXJyZW50U3RlcFN0cmVhbSBhbmQgc2Nyb2xsIHRvIHNldCBlbGVtZW50IGlmIHRoZSB1c2VyIGhhcyB0aGUgcmlnaHQgcGVybWlzc2lvblxuICAgICAqL1xuICAgIHByaXZhdGUgc3Vic2NyaWJlVG9HdWlkZWRUb3VyQ3VycmVudFN0ZXBTdHJlYW0oKSB7XG4gICAgICAgIHRoaXMuZ3VpZGVkVG91clNlcnZpY2UuZ2V0R3VpZGVkVG91ckN1cnJlbnRTdGVwU3RyZWFtKCkuc3Vic2NyaWJlKChzdGVwOiBUZXh0VG91clN0ZXAgfCBJbWFnZVRvdXJTdGVwIHwgVmlkZW9Ub3VyU3RlcCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50VG91clN0ZXAgPSBzdGVwO1xuICAgICAgICAgICAgaWYgKCF0aGlzLmN1cnJlbnRUb3VyU3RlcCkge1xuICAgICAgICAgICAgICAgIHRoaXMudHJhbnNmb3JtQ291bnQgPSAwO1xuICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFN0ZXBJbmRleCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICB0aGlzLm5leHRTdGVwSW5kZXggPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5jYWxjdWxhdGVUcmFuc2xhdGVWYWx1ZSgpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuY3VycmVudFRvdXJTdGVwLm9yaWVudGF0aW9uKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5vcmllbnRhdGlvbiA9IHRoaXMuY3VycmVudFRvdXJTdGVwLm9yaWVudGF0aW9uO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5oYXNVc2VyUGVybWlzc2lvbkZvckN1cnJlbnRUb3VyU3RlcCgpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zY3JvbGxUb0FuZFNldEVsZW1lbnQoKTtcbiAgICAgICAgICAgICAgICB0aGlzLmhhbmRsZVRyYW5zaXRpb24oKTtcbiAgICAgICAgICAgICAgICB0aGlzLmd1aWRlZFRvdXJTZXJ2aWNlLmlzQmFja1BhZ2VOYXZpZ2F0aW9uLm5leHQoZmFsc2UpO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLmN1cnJlbnRTdGVwSW5kZXggIT09IHVuZGVmaW5lZCAmJiB0aGlzLm5leHRTdGVwSW5kZXggIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2FsY3VsYXRlQW5kRGlzcGxheURvdE5hdmlnYXRpb24odGhpcy5jdXJyZW50U3RlcEluZGV4ISwgdGhpcy5uZXh0U3RlcEluZGV4ISk7XG4gICAgICAgICAgICAgICAgICAgIH0sIDApO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2FsY3VsYXRlVHJhbnNsYXRlVmFsdWUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0ID0gdW5kZWZpbmVkO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTdWJzY3JpYmUgdG8gdXNlckludGVyYWN0aW9uRmluaXNoZWQgdG8gZGV0ZXJtaW5lIGlmIHRoZSB1c2VyIGludGVyYWN0aW9uIGhhcyBiZWVuIGV4ZWN1dGVkXG4gICAgICovXG4gICAgcHJpdmF0ZSBzdWJzY3JpYmVUb1VzZXJJbnRlcmFjdGlvblN0YXRlKCk6IHZvaWQge1xuICAgICAgICAvLyBDaGVjayBhdmFpbGFiaWxpdHkgYWZ0ZXIgZmlyc3Qgc3Vic2NyaWJlIGNhbGwgc2luY2UgdGhlIHJvdXRlciBldmVudCBiZWVuIHRyaWdnZXJlZCBhbHJlYWR5XG4gICAgICAgIHRoaXMuZ3VpZGVkVG91clNlcnZpY2UudXNlckludGVyYWN0aW9uRmluaXNoZWRTdGF0ZSgpLnN1YnNjcmliZSgoaXNGaW5pc2hlZCkgPT4ge1xuICAgICAgICAgICAgdGhpcy51c2VySW50ZXJhY3Rpb25GaW5pc2hlZCA9IGlzRmluaXNoZWQ7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFN1YnNjcmliZSB0byByZXNpemUgZXZlbnQgYW5kIHVwZGF0ZSBzdGVwIGxvY2F0aW9uIG9mIHRoZSBzZWxlY3RlZCBlbGVtZW50IGluIHRoZSB0b3VyIHN0ZXBcbiAgICAgKi9cbiAgICBwcml2YXRlIHN1YnNjcmliZVRvUmVzaXplRXZlbnQoKSB7XG4gICAgICAgIHRoaXMucmVzaXplU3Vic2NyaXB0aW9uID0gZnJvbUV2ZW50KHdpbmRvdywgJ3Jlc2l6ZScpLnN1YnNjcmliZSgoKSA9PiB7XG4gICAgICAgICAgICBpZiAodGhpcy5nZXRTZWxlY3RlZEVsZW1lbnQoKSkge1xuICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRFbGVtZW50UmVjdCA9IHRoaXMudXBkYXRlU3RlcExvY2F0aW9uKHRoaXMuZ2V0U2VsZWN0ZWRFbGVtZW50KCksIHRydWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTdWJzY3JpYmUgdG8gc2Nyb2xsIGV2ZW50IGFuZCB1cGRhdGUgc3RlcCBsb2NhdGlvbiBvZiB0aGUgc2VsZWN0ZWQgZWxlbWVudCBpbiB0aGUgdG91ciBzdGVwXG4gICAgICovXG4gICAgcHJpdmF0ZSBzdWJzY3JpYmVUb1Njcm9sbEV2ZW50KCkge1xuICAgICAgICB0aGlzLnNjcm9sbFN1YnNjcmlwdGlvbiA9IGZyb21FdmVudCh3aW5kb3csICdzY3JvbGwnKS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICAgICAgaWYgKHRoaXMuZ2V0U2VsZWN0ZWRFbGVtZW50KCkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdGVkRWxlbWVudFJlY3QgPSB0aGlzLnVwZGF0ZVN0ZXBMb2NhdGlvbih0aGlzLmdldFNlbGVjdGVkRWxlbWVudCgpLCB0cnVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU3Vic2NyaWJlIHRvIGNsaWNrIGV2ZW50IGFuZCB1cGRhdGUgc3RlcCBsb2NhdGlvbiBvZiB0aGUgc2VsZWN0ZWQgZWxlbWVudCBpbiB0aGUgdG91ciBzdGVwXG4gICAgICovXG4gICAgcHJpdmF0ZSBzdWJzY3JpYmVUb0NsaWNrRXZlbnQoKSB7XG4gICAgICAgIHRoaXMuY2xpY2tTdWJzY3JpcHRpb24gPSBmcm9tRXZlbnQod2luZG93LCAnY2xpY2snKS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICAgICAgaWYgKHRoaXMuZ2V0U2VsZWN0ZWRFbGVtZW50KCkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdGVkRWxlbWVudFJlY3QgPSB0aGlzLnVwZGF0ZVN0ZXBMb2NhdGlvbih0aGlzLmdldFNlbGVjdGVkRWxlbWVudCgpLCB0cnVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgdGhlIGN1cnJlbnQgdXNlciBoYXMgdGhlIHBlcm1pc3Npb24gdG8gdmlldyB0aGUgdG91ciBzdGVwXG4gICAgICogQHJldHVybiB0cnVlIGlmIHRoZSBjdXJyZW50IHVzZXIgaGFzIHRoZSBwZXJtaXNzaW9uIHRvIHZpZXcgdGhlIHRvdXIgc3RlcCwgb3RoZXJ3aXNlIGZhbHNlXG4gICAgICovXG4gICAgcHJpdmF0ZSBoYXNVc2VyUGVybWlzc2lvbkZvckN1cnJlbnRUb3VyU3RlcCgpOiBib29sZWFuIHtcbiAgICAgICAgaWYgKCF0aGlzLmN1cnJlbnRUb3VyU3RlcCkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAhdGhpcy5jdXJyZW50VG91clN0ZXAucGVybWlzc2lvbiB8fCB0aGlzLmFjY291bnRTZXJ2aWNlLmhhc0FueUF1dGhvcml0eURpcmVjdCh0aGlzLmN1cnJlbnRUb3VyU3RlcC5wZXJtaXNzaW9uKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTY3JvbGwgdG8gYW5kIHNldCBoaWdobGlnaHRlZCBlbGVtZW50XG4gICAgICovXG4gICAgcHJpdmF0ZSBzY3JvbGxUb0FuZFNldEVsZW1lbnQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuc2VsZWN0ZWRFbGVtZW50UmVjdCA9IHRoaXMudXBkYXRlU3RlcExvY2F0aW9uKHRoaXMuZ2V0U2VsZWN0ZWRFbGVtZW50KCksIGZhbHNlKTtcbiAgICAgICAgdGhpcy5vYnNlcnZlU2VsZWN0ZWRSZWN0UG9zaXRpb24oKTtcblxuICAgICAgICAvLyBTZXQgdGltZW91dCB0byBhbGxvdyB0aGluZ3MgdG8gcmVuZGVyIGluIG9yZGVyIHRvIHNjcm9sbCB0byB0aGUgY29ycmVjdCBsb2NhdGlvblxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIGlmICh0aGlzLmlzVG91ck9uU2NyZWVuKERpcmVjdGlvbi5WRVJUSUNBTCkgJiYgdGhpcy5pc1RvdXJPblNjcmVlbihEaXJlY3Rpb24uSE9SSVpPTlRBTCkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIXRoaXMuaXNUb3VyT25TY3JlZW4oRGlyZWN0aW9uLlZFUlRJQ0FMKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRvcFBvc2l0aW9uID0gdGhpcy5nZXRUb3BTY3JvbGxpbmdQb3NpdGlvbigpO1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5zY3JvbGxUbyh7IGxlZnQ6IDAsIHRvcDogdG9wUG9zaXRpb24sIGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIFR5cGVFcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93LnNjcm9sbCgwLCB0b3BQb3NpdGlvbik7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIXRoaXMuaXNUb3VyT25TY3JlZW4oRGlyZWN0aW9uLkhPUklaT05UQUwpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5mbGlwT3JpZW50YXRpb24oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgMCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgdGhlIGN1cnJlbnQgdG91ciBzdGVwIGhhcyBhIGJvdHRvbSBvcmllbnRhdGlvblxuICAgICAqIEByZXR1cm4gdHJ1ZSBpZiB0aGUgY3VycmVudCB0b3VyIHN0ZXAgb3JpZW50YXRpb24gaXMgYm90dG9tLCBvdGhlcndpc2UgZmFsc2VcbiAgICAgKi9cbiAgICBwcml2YXRlIGlzQm90dG9tKCk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAodGhpcy5jdXJyZW50VG91clN0ZXAgJiYgdGhpcy5jdXJyZW50VG91clN0ZXAub3JpZW50YXRpb24pIHtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VG91clN0ZXAub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLkJPVFRPTSB8fFxuICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFRvdXJTdGVwLm9yaWVudGF0aW9uID09PSBPcmllbnRhdGlvbi5CT1RUT01MRUZUIHx8XG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VG91clN0ZXAub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLkJPVFRPTVJJR0hUXG4gICAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiB0aGUgY3VycmVudCB0b3VyIHN0ZXAgaGFzIGEgdG9wIG9yaWVudGF0aW9uXG4gICAgICogQHJldHVybiB0cnVlIGlmIHRoZSBjdXJyZW50IHRvdXIgc3RlcCBvcmllbnRhdGlvbiBpcyBib3R0b20sIG90aGVyd2lzZSBmYWxzZVxuICAgICAqL1xuICAgIHByaXZhdGUgaXNUb3AoKTogYm9vbGVhbiB7XG4gICAgICAgIGlmICh0aGlzLmN1cnJlbnRUb3VyU3RlcCAmJiB0aGlzLmN1cnJlbnRUb3VyU3RlcC5vcmllbnRhdGlvbikge1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRUb3VyU3RlcC5vcmllbnRhdGlvbiA9PT0gT3JpZW50YXRpb24uVE9QIHx8XG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VG91clN0ZXAub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLlRPUExFRlQgfHxcbiAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRUb3VyU3RlcC5vcmllbnRhdGlvbiA9PT0gT3JpZW50YXRpb24uVE9QUklHSFRcbiAgICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIHRoZSBjdXJyZW50IHRvdXIgc3RlcCBoYXMgYSBsZWZ0IG9yaWVudGF0aW9uXG4gICAgICogQHJldHVybiB0cnVlIGlmIHRoZSBjdXJyZW50IHRvdXIgc3RlcCBvcmllbnRhdGlvbiBpcyBsZWZ0LCBvdGhlcndpc2UgZmFsc2VcbiAgICAgKi9cbiAgICBwcml2YXRlIGlzTGVmdCgpOiBib29sZWFuIHtcbiAgICAgICAgaWYgKHRoaXMuY3VycmVudFRvdXJTdGVwICYmIHRoaXMuY3VycmVudFRvdXJTdGVwLm9yaWVudGF0aW9uKSB7XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFRvdXJTdGVwLm9yaWVudGF0aW9uID09PSBPcmllbnRhdGlvbi5MRUZUIHx8XG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VG91clN0ZXAub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLlRPUExFRlQgfHxcbiAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRUb3VyU3RlcC5vcmllbnRhdGlvbiA9PT0gT3JpZW50YXRpb24uQk9UVE9NTEVGVFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgdGhlIGN1cnJlbnQgdG91ciBzdGVwIGhhcyBhIHJpZ2h0IG9yaWVudGF0aW9uXG4gICAgICogQHJldHVybiB0cnVlIGlmIHRoZSBjdXJyZW50IHRvdXIgc3RlcCBvcmllbnRhdGlvbiBpcyByaWdodCwgb3RoZXJ3aXNlIGZhbHNlXG4gICAgICovXG4gICAgcHJpdmF0ZSBpc1JpZ2h0KCk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAodGhpcy5jdXJyZW50VG91clN0ZXAgJiYgdGhpcy5jdXJyZW50VG91clN0ZXAub3JpZW50YXRpb24pIHtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VG91clN0ZXAub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLlJJR0hUIHx8XG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VG91clN0ZXAub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLlRPUFJJR0hUIHx8XG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VG91clN0ZXAub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLkJPVFRPTVJJR0hUXG4gICAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiB0aGUgdG91ciBzdGVwIGVsZW1lbnQgd291bGQgYmUgdmlzaWJsZSBvbiBzY3JlZW5cbiAgICAgKiBAcmV0dXJuIHRydWUgaWYgdG91ciBzdGVwIGlzIHZpc2libGUgb24gc2NyZWVuLCBvdGhlcndpc2UgZmFsc2VcbiAgICAgKi9cbiAgICBwcml2YXRlIGlzVG91ck9uU2NyZWVuKGRpcmVjdGlvbjogRGlyZWN0aW9uKTogYm9vbGVhbiB7XG4gICAgICAgIGlmICghdGhpcy5jdXJyZW50VG91clN0ZXApIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gIXRoaXMuY3VycmVudFRvdXJTdGVwLmhpZ2hsaWdodFNlbGVjdG9yIHx8IHRoaXMuZWxlbWVudEluVmlld3BvcnQodGhpcy5nZXRTZWxlY3RlZEVsZW1lbnQoKSwgZGlyZWN0aW9uKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEZWZpbmUgaWYgSFRNTEVsZW1lbnQgaXMgdmlzaWJsZSBpbiBjdXJyZW50IHZpZXdwb3J0XG4gICAgICogTW9kaWZpZWQgZnJvbSBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL3F1ZXN0aW9ucy8xMjM5OTkvaG93LXRvLXRlbGwtaWYtYS1kb20tZWxlbWVudC1pcy12aXNpYmxlLWluLXRoZS1jdXJyZW50LXZpZXdwb3J0XG4gICAgICogQHBhcmFtIGVsZW1lbnQgdGhhdCBzaG91bGQgYmUgY2hlY2tlZFxuICAgICAqIEBwYXJhbSBkaXJlY3Rpb24gaXQgc2hvdWxkIGJlIGNoZWNrZWQgaWYgdGhlIHRvdXIgc3RlcCBpcyBob3Jpem9udGFsbHkgb3IgdmVydGljYWxseSBpbiB0aGUgdmlld3BvcnRcbiAgICAgKiBAcmV0dXJuIHRydWUgaWYgZWxlbWVudCBpcyBpbiB2aWV3cG9ydCwgb3RoZXJ3aXNlIGZhbHNlXG4gICAgICovXG4gICAgcHJpdmF0ZSBlbGVtZW50SW5WaWV3cG9ydChlbGVtZW50OiBIVE1MRWxlbWVudCB8IHVuZGVmaW5lZCwgZGlyZWN0aW9uOiBEaXJlY3Rpb24pOiBib29sZWFuIHtcbiAgICAgICAgaWYgKCFlbGVtZW50KSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgZWxlbWVudEluVmlld1BvcnQgPSB0cnVlO1xuXG4gICAgICAgIHN3aXRjaCAoZGlyZWN0aW9uKSB7XG4gICAgICAgICAgICBjYXNlIERpcmVjdGlvbi5IT1JJWk9OVEFMOiB7XG4gICAgICAgICAgICAgICAgY29uc3Qgd2lkdGggPSBlbGVtZW50Lm9mZnNldFdpZHRoO1xuICAgICAgICAgICAgICAgIGNvbnN0IGxlZnQgPSBjYWxjdWxhdGVMZWZ0T2Zmc2V0KGVsZW1lbnQpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHRvdXJTdGVwV2lkdGggPSB0aGlzLnRvdXJTdGVwLm5hdGl2ZUVsZW1lbnQub2Zmc2V0V2lkdGg7XG4gICAgICAgICAgICAgICAgZWxlbWVudEluVmlld1BvcnQgPSBpc0VsZW1lbnRJblZpZXdQb3J0SG9yaXpvbnRhbGx5KHRoaXMuY3VycmVudFRvdXJTdGVwLm9yaWVudGF0aW9uLCBsZWZ0LCB3aWR0aCwgdG91clN0ZXBXaWR0aCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIERpcmVjdGlvbi5WRVJUSUNBTDoge1xuICAgICAgICAgICAgICAgIGNvbnN0IHN0ZXBTY3JlZW5BZGp1c3RtZW50ID0gdGhpcy5pc0JvdHRvbSgpID8gdGhpcy5nZXRTdGVwU2NyZWVuQWRqdXN0bWVudCgpIDogLXRoaXMuZ2V0U3RlcFNjcmVlbkFkanVzdG1lbnQoKTtcbiAgICAgICAgICAgICAgICBjb25zdCB0b3AgPSBjYWxjdWxhdGVUb3BPZmZzZXQoZWxlbWVudCk7XG4gICAgICAgICAgICAgICAgY29uc3QgaGVpZ2h0ID0gZWxlbWVudC5vZmZzZXRIZWlnaHQ7XG4gICAgICAgICAgICAgICAgY29uc3QgdG91clN0ZXAgPSB0aGlzLnRvdXJTdGVwLm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgICAgICAgICAgY29uc3QgdG91clN0ZXBQb3NpdGlvbiA9IHRvdXJTdGVwLnRvcCArIHRvdXJTdGVwLmhlaWdodDtcbiAgICAgICAgICAgICAgICBjb25zdCB3aW5kb3dIZWlnaHQgPSB3aW5kb3cuaW5uZXJIZWlnaHQgKyB3aW5kb3cuc2Nyb2xsWTtcbiAgICAgICAgICAgICAgICBlbGVtZW50SW5WaWV3UG9ydCA9IHRvcCA+PSB3aW5kb3cuc2Nyb2xsWSAtIHN0ZXBTY3JlZW5BZGp1c3RtZW50ICYmIHRvcCArIGhlaWdodCArIDEwIDw9IHdpbmRvd0hlaWdodCAmJiB0b3VyU3RlcFBvc2l0aW9uIDw9IHdpbmRvd0hlaWdodDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZWxlbWVudEluVmlld1BvcnQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRmxpcHMgdGhlIG9yaWVudGF0aW9uIG9mIHRoZSBjdXJyZW50IHRvdXIgc3RlcCBob3Jpem9udGFsbHlcbiAgICAgKi9cbiAgICBwcml2YXRlIGZsaXBPcmllbnRhdGlvbigpOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMuaXNMZWZ0KCkpIHtcbiAgICAgICAgICAgIHN3aXRjaCAodGhpcy5jdXJyZW50VG91clN0ZXAub3JpZW50YXRpb24pIHtcbiAgICAgICAgICAgICAgICBjYXNlIE9yaWVudGF0aW9uLkxFRlQ6IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vcmllbnRhdGlvbiA9IE9yaWVudGF0aW9uLlJJR0hUO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2FzZSBPcmllbnRhdGlvbi5UT1BMRUZUOiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub3JpZW50YXRpb24gPSBPcmllbnRhdGlvbi5UT1BSSUdIVDtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhc2UgT3JpZW50YXRpb24uQk9UVE9NTEVGVDoge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9yaWVudGF0aW9uID0gT3JpZW50YXRpb24uQk9UVE9NUklHSFQ7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmlzUmlnaHQoKSkge1xuICAgICAgICAgICAgc3dpdGNoICh0aGlzLmN1cnJlbnRUb3VyU3RlcC5vcmllbnRhdGlvbikge1xuICAgICAgICAgICAgICAgIGNhc2UgT3JpZW50YXRpb24uUklHSFQ6IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vcmllbnRhdGlvbiA9IE9yaWVudGF0aW9uLkxFRlQ7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXNlIE9yaWVudGF0aW9uLlRPUFJJR0hUOiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub3JpZW50YXRpb24gPSBPcmllbnRhdGlvbi5UT1BMRUZUO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2FzZSBPcmllbnRhdGlvbi5CT1RUT01SSUdIVDoge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9yaWVudGF0aW9uID0gT3JpZW50YXRpb24uQk9UVE9NTEVGVDtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSBjdXJyZW50IHRvdXIgc3RlcCBpcyBhbiBpbnN0YW5jZSBvZiBWaWRlb1RvdXJTdGVwXG4gICAgICovXG4gICAgcHVibGljIGlzVmlkZW9Ub3VyU3RlcCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY3VycmVudFRvdXJTdGVwIGluc3RhbmNlb2YgVmlkZW9Ub3VyU3RlcDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIYW5kbGUgYmFja2Ryb3AgY2xpY2tpbmcgZXZlbnQgb2YgdGhlIHVzZXJcbiAgICAgKiBAcGFyYW0gZXZlbnQ6IGV2ZW50IHBheWxvYWRcbiAgICAgKi9cbiAgICBwdWJsaWMgYmFja2Ryb3BDbGljayhldmVudDogRXZlbnQpOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMuZ3VpZGVkVG91clNlcnZpY2UucHJldmVudEJhY2tkcm9wRnJvbUFkdmFuY2luZykge1xuICAgICAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmd1aWRlZFRvdXJTZXJ2aWNlLm5leHRTdGVwKCk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gV2hlbiB0aGUgdXNlciBjbGlja3Mgb24gdGhlIGJhY2tkcm9wIG9yIHRvdXIgc3RlcCB3aGlsZSBzZWVpbmcgdGhlIGNhbmNlbCB0b3VyIHN0ZXAsIHRoZSBjYW5jZWwgdG91ciB3aWxsIGJlIGZpbmlzaGVkIGF1dG9tYXRpY2FsbHlcbiAgICAgICAgaWYgKHRoaXMuZ3VpZGVkVG91clNlcnZpY2UuaXNDdXJyZW50VG91cihjYW5jZWxUb3VyKSkge1xuICAgICAgICAgICAgdGhpcy5ndWlkZWRUb3VyU2VydmljZS5maW5pc2hHdWlkZWRUb3VyKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKiA9PT09PT09PT09ICAgICBUb3VyIHN0ZXAgY2FsY3VsYXRpb24gbWV0aG9kcyAgICAgPT09PT09PT09PSAqL1xuXG4gICAgLyoqXG4gICAgICogQ2FsY3VsYXRlIHRvdXIgc3RlcCB3aWR0aCBmb3IgdG91ciBzdGVwIGVsZW1lbnRcbiAgICAgKiBAcmV0dXJuIHRvdXIgc3RlcCB3aWR0aCBmb3IgdG91ci1zdGVwIGRpdlxuICAgICAqL1xuICAgIHB1YmxpYyBnZXQgY2FsY3VsYXRlZFRvdXJTdGVwV2lkdGgoKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgaWYgKCF0aGlzLmN1cnJlbnRUb3VyU3RlcCB8fCAhdGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0KSB7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLnRvdXJTdGVwV2lkdGggLSB0aGlzLndpZHRoQWRqdXN0bWVudEZvclNjcmVlbkJvdW5kO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEByZXR1cm4gdG9wIHBvc2l0aW9uIGZvciBjdXJyZW50IHRvdXIgc3RlcFxuICAgICAqL1xuICAgIHB1YmxpYyBnZXQgdG9wUG9zaXRpb24oKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgaWYgKCF0aGlzLmN1cnJlbnRUb3VyU3RlcCB8fCAhdGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0KSB7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmlzQm90dG9tKCkpIHtcbiAgICAgICAgICAgIGNvbnN0IHBhZGRpbmdBZGp1c3RtZW50ID0gdGhpcy5nZXRIaWdobGlnaHRQYWRkaW5nKCk7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0LnRvcCArIHRoaXMuc2VsZWN0ZWRFbGVtZW50UmVjdC5oZWlnaHQgKyBwYWRkaW5nQWRqdXN0bWVudDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0LnRvcCAtIHRoaXMuZ2V0SGlnaGxpZ2h0UGFkZGluZygpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEByZXR1cm4gbGVmdCBwb3NpdGlvbiBmb3IgY3VycmVudCB0b3VyIHN0ZXBcbiAgICAgKi9cbiAgICBwdWJsaWMgZ2V0IGxlZnRQb3NpdGlvbigpOiBudW1iZXIgfCB1bmRlZmluZWQge1xuICAgICAgICBpZiAoIXRoaXMuY3VycmVudFRvdXJTdGVwIHx8ICF0aGlzLnNlbGVjdGVkRWxlbWVudFJlY3QpIHtcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuY2FsY3VsYXRlZEhpZ2hsaWdodExlZnRQb3NpdGlvbiA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIDU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuY2FsY3VsYXRlZEhpZ2hsaWdodExlZnRQb3NpdGlvbiA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNhbGN1bGF0ZWRIaWdobGlnaHRMZWZ0UG9zaXRpb247XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYWRqdXN0bWVudCA9IE1hdGgubWF4KDAsIC10aGlzLmNhbGN1bGF0ZWRIaWdobGlnaHRMZWZ0UG9zaXRpb24pO1xuICAgICAgICBjb25zdCBtYXhBZGp1c3RtZW50ID0gTWF0aC5taW4odGhpcy5tYXhXaWR0aEFkanVzdG1lbnRGb3JUb3VyU3RlcCwgYWRqdXN0bWVudCk7XG4gICAgICAgIHJldHVybiB0aGlzLmNhbGN1bGF0ZWRIaWdobGlnaHRMZWZ0UG9zaXRpb24gKyBtYXhBZGp1c3RtZW50O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCB0b3AgcG9zaXRpb24gZm9yIHNlbGVjdGVkIGVsZW1lbnQgZm9yIHNjcm9sbGluZ1xuICAgICAqL1xuICAgIHByaXZhdGUgZ2V0VG9wU2Nyb2xsaW5nUG9zaXRpb24oKTogbnVtYmVyIHtcbiAgICAgICAgbGV0IHRvcFBvc2l0aW9uID0gMDtcbiAgICAgICAgbGV0IHBvc2l0aW9uQWRqdXN0bWVudCA9IDA7XG4gICAgICAgIGlmICh0aGlzLnNlbGVjdGVkRWxlbWVudFJlY3QgJiYgdGhpcy5jdXJyZW50VG91clN0ZXApIHtcbiAgICAgICAgICAgIGNvbnN0IHN0ZXBTY3JlZW5BZGp1c3RtZW50ID0gdGhpcy5nZXRTdGVwU2NyZWVuQWRqdXN0bWVudCgpO1xuICAgICAgICAgICAgY29uc3QgdG91clN0ZXAgPSB0aGlzLnRvdXJTdGVwLm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgICAgICBjb25zdCB0b3RhbFN0ZXBIZWlnaHQgPSB0aGlzLnNlbGVjdGVkRWxlbWVudFJlY3QuaGVpZ2h0ID4gdG91clN0ZXAuaGVpZ2h0ID8gdGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0LmhlaWdodCA6IHRvdXJTdGVwLmhlaWdodDtcblxuICAgICAgICAgICAgaWYgKHRoaXMuaXNCb3R0b20oKSkge1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uQWRqdXN0bWVudCA9IHN0ZXBTY3JlZW5BZGp1c3RtZW50O1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbkFkanVzdG1lbnQgPSB0b3RhbFN0ZXBIZWlnaHQgLSB3aW5kb3cuaW5uZXJIZWlnaHQgLSBzdGVwU2NyZWVuQWRqdXN0bWVudDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuaXNUb3AoKSkge1xuICAgICAgICAgICAgICAgIC8vIFNjcm9sbCB0byAxNXB4IGFib3ZlIHRoZSB0b3VyIHN0ZXBcbiAgICAgICAgICAgICAgICB0b3BQb3NpdGlvbiA9IHdpbmRvdy5zY3JvbGxZICsgdG91clN0ZXAudG9wIC0gMTU7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvcFBvc2l0aW9uID0gd2luZG93LnNjcm9sbFkgKyB0aGlzLnNlbGVjdGVkRWxlbWVudFJlY3QudG9wICsgcG9zaXRpb25BZGp1c3RtZW50O1xuICAgICAgICAgICAgICAgIHRvcFBvc2l0aW9uID0gdG9wUG9zaXRpb24gPCAxNSA/IDAgOiB0b3BQb3NpdGlvbiArIDE1O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0b3BQb3NpdGlvbjtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXRzIGRlZmluZWQgcGFkZGluZyBhcm91bmQgdGhlIGhpZ2hsaWdodGVkIHJlY3RhbmdsZVxuICAgICAqIEByZXR1cm4gaGlnaGxpZ2h0IHBhZGRpbmcgZm9yIGN1cnJlbnQgdG91ciBzdGVwXG4gICAgICovXG4gICAgcHJpdmF0ZSBnZXRIaWdobGlnaHRQYWRkaW5nKCk6IG51bWJlciB7XG4gICAgICAgIGlmICghdGhpcy5jdXJyZW50VG91clN0ZXApIHtcbiAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLmN1cnJlbnRUb3VyU3RlcC5oaWdobGlnaHRQYWRkaW5nID8gdGhpcy5jdXJyZW50VG91clN0ZXAuaGlnaGxpZ2h0UGFkZGluZyA6IDA7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IG92ZXJsYXkgc3R5bGUgZm9yIHRoZSByZWN0YW5nbGVzIGJlc2lkZSB0aGUgaGlnaGxpZ2h0ZWQgZWxlbWVudFxuICAgICAqIEByZXR1cm4gc3R5bGUgb2JqZWN0IGZvciB0aGUgcmVjdGFuZ2xlIGJlc2lkZSB0aGUgaGlnaGxpZ2h0ZWQgZWxlbWVudFxuICAgICAqL1xuICAgIHB1YmxpYyBnZXRPdmVybGF5U3R5bGUocG9zaXRpb246IE92ZXJsYXlQb3NpdGlvbikge1xuICAgICAgICBpZiAodGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0KSB7XG4gICAgICAgICAgICBjb25zdCBzZWxlY3RlZEVsZW1lbnRUb3AgPSB0aGlzLnNlbGVjdGVkRWxlbWVudFJlY3QudG9wIC0gdGhpcy5nZXRIaWdobGlnaHRQYWRkaW5nKCk7XG4gICAgICAgICAgICBjb25zdCBzZWxlY3RlZEVsZW1lbnRMZWZ0ID0gdGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0LmxlZnQgLSB0aGlzLmdldEhpZ2hsaWdodFBhZGRpbmcoKTtcbiAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkRWxlbWVudEhlaWdodCA9IHRoaXMuc2VsZWN0ZWRFbGVtZW50UmVjdC5oZWlnaHQgKyB0aGlzLmdldEhpZ2hsaWdodFBhZGRpbmcoKSAqIDI7XG4gICAgICAgICAgICBjb25zdCBzZWxlY3RlZEVsZW1lbnRXaWR0aCA9IHRoaXMuc2VsZWN0ZWRFbGVtZW50UmVjdC53aWR0aCArIHRoaXMuZ2V0SGlnaGxpZ2h0UGFkZGluZygpICogMjtcblxuICAgICAgICAgICAgc3dpdGNoIChwb3NpdGlvbikge1xuICAgICAgICAgICAgICAgIGNhc2UgT3ZlcmxheVBvc2l0aW9uLlRPUDpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgJ3RvcC5weCc6IDAsICdsZWZ0LnB4JzogMCwgJ2hlaWdodC5weCc6IHNlbGVjdGVkRWxlbWVudFRvcCA+IDAgPyBzZWxlY3RlZEVsZW1lbnRUb3AgOiAwIH07XG4gICAgICAgICAgICAgICAgY2FzZSBPdmVybGF5UG9zaXRpb24uTEVGVDpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICd0b3AucHgnOiBzZWxlY3RlZEVsZW1lbnRUb3AsXG4gICAgICAgICAgICAgICAgICAgICAgICAnbGVmdC5weCc6IHNlbGVjdGVkRWxlbWVudExlZnQgPCAwID8gc2VsZWN0ZWRFbGVtZW50TGVmdCA6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAnaGVpZ2h0LnB4Jzogc2VsZWN0ZWRFbGVtZW50SGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgJ3dpZHRoLnB4Jzogc2VsZWN0ZWRFbGVtZW50TGVmdCA+IDAgPyBzZWxlY3RlZEVsZW1lbnRMZWZ0IDogMCxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBjYXNlIE92ZXJsYXlQb3NpdGlvbi5SSUdIVDpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgJ3RvcC5weCc6IHNlbGVjdGVkRWxlbWVudFRvcCwgJ2xlZnQucHgnOiBzZWxlY3RlZEVsZW1lbnRMZWZ0ICsgc2VsZWN0ZWRFbGVtZW50V2lkdGgsICdoZWlnaHQucHgnOiBzZWxlY3RlZEVsZW1lbnRIZWlnaHQgfTtcbiAgICAgICAgICAgICAgICBjYXNlIE92ZXJsYXlQb3NpdGlvbi5CT1RUT006XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7ICd0b3AucHgnOiBzZWxlY3RlZEVsZW1lbnRUb3AgKyBzZWxlY3RlZEVsZW1lbnRIZWlnaHQgPiAwID8gc2VsZWN0ZWRFbGVtZW50VG9wICsgc2VsZWN0ZWRFbGVtZW50SGVpZ2h0IDogMCB9O1xuICAgICAgICAgICAgICAgIGNhc2UgT3ZlcmxheVBvc2l0aW9uLkVMRU1FTlQ6XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7ICd0b3AucHgnOiBzZWxlY3RlZEVsZW1lbnRUb3AsICdsZWZ0LnB4Jzogc2VsZWN0ZWRFbGVtZW50TGVmdCwgJ2hlaWdodC5weCc6IHNlbGVjdGVkRWxlbWVudEhlaWdodCwgJ3dpZHRoLnB4Jzogc2VsZWN0ZWRFbGVtZW50V2lkdGggfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFRyYW5zZm9ybSBwb3NpdGlvbiBvZiB0b3VyIHN0ZXBzIHdoaWNoIGFyZSBzaG93biBvbiB0b3Agb2YgdGhlIGhpZ2hsaWdodGVkIGVsZW1lbnRcbiAgICAgKiBAcmV0dXJuIHtzdHJpbmd9ICcnIG9yICd0cmFuc2xhdGVZKC0xMDAlKSdcbiAgICAgKi9cbiAgICBwdWJsaWMgZ2V0IHRyYW5zZm9ybSgpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICBpZiAoXG4gICAgICAgICAgICB0aGlzLmN1cnJlbnRUb3VyU3RlcCAmJlxuICAgICAgICAgICAgKCghdGhpcy5jdXJyZW50VG91clN0ZXAub3JpZW50YXRpb24gJiYgdGhpcy5jdXJyZW50VG91clN0ZXAuaGlnaGxpZ2h0U2VsZWN0b3IpIHx8XG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VG91clN0ZXAub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLlRPUCB8fFxuICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFRvdXJTdGVwLm9yaWVudGF0aW9uID09PSBPcmllbnRhdGlvbi5UT1BSSUdIVCB8fFxuICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFRvdXJTdGVwLm9yaWVudGF0aW9uID09PSBPcmllbnRhdGlvbi5UT1BMRUZUKVxuICAgICAgICApIHtcbiAgICAgICAgICAgIHJldHVybiAndHJhbnNsYXRlWSgtMTAwJSknO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAnJztcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgZWxlbWVudCBmb3IgdGhlIGN1cnJlbnQgdG91ciBzdGVwIGhpZ2hsaWdodCBzZWxlY3RvclxuICAgICAqIEByZXR1cm4gY3VycmVudCBzZWxlY3RlZCBlbGVtZW50IGZvciB0aGUgdG91ciBzdGVwIG9yIHVuZGVmaW5lZFxuICAgICAqL1xuICAgIHByaXZhdGUgZ2V0U2VsZWN0ZWRFbGVtZW50KCk6IEhUTUxFbGVtZW50IHwgdW5kZWZpbmVkIHtcbiAgICAgICAgaWYgKCF0aGlzLmN1cnJlbnRUb3VyU3RlcCB8fCAhdGhpcy5jdXJyZW50VG91clN0ZXAuaGlnaGxpZ2h0U2VsZWN0b3IpIHtcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc2VsZWN0ZWRFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3Rvcih0aGlzLmN1cnJlbnRUb3VyU3RlcC5oaWdobGlnaHRTZWxlY3RvcikgYXMgSFRNTEVsZW1lbnQ7XG5cbiAgICAgICAgLy8gV29ya2Fyb3VuZCBmb3IgaW5zdHJ1Y3Rpb24gZWxlbWVudHMgaW4gdGhlIGNvZGUtZWRpdG9yIHZpZXcsIHNpbmNlIHRoZSBlbGVtZW50IGNhbiBiZSBpbiB0aGUgdmlld3BvcnQgYnV0IGhpZGRlbiBieSB0aGUgYnVpbGQgb3V0cHV0IGRpdlxuICAgICAgICBjb25zdCBpbnN0cnVjdGlvbnMgPSBzZWxlY3RlZEVsZW1lbnQgPyBzZWxlY3RlZEVsZW1lbnQuY2xvc2VzdCgnLmluc3RydWN0aW9uc19fY29udGVudF9fbWFya2Rvd24nKSA6IHVuZGVmaW5lZDtcbiAgICAgICAgaWYgKGluc3RydWN0aW9ucyAmJiBpbnN0cnVjdGlvbnMuc2Nyb2xsSGVpZ2h0ID4gd2luZG93LmlubmVySGVpZ2h0ICYmIGluc3RydWN0aW9ucy5xdWVyeVNlbGVjdG9yKHRoaXMuY3VycmVudFRvdXJTdGVwLmhpZ2hsaWdodFNlbGVjdG9yKSkge1xuICAgICAgICAgICAgc2VsZWN0ZWRFbGVtZW50LnNjcm9sbEludG9WaWV3KHsgYmxvY2s6ICdjZW50ZXInIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzZWxlY3RlZEVsZW1lbnQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2FsY3VsYXRlIG1heCB3aWR0aCBhZGp1c3RtZW50IGZvciB0b3VyIHN0ZXBcbiAgICAgKiBAcmV0dXJuIHtudW1iZXJ9IG1heFdpZHRoQWRqdXN0bWVudEZvclRvdXJTdGVwXG4gICAgICovXG4gICAgcHJpdmF0ZSBnZXQgbWF4V2lkdGhBZGp1c3RtZW50Rm9yVG91clN0ZXAoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudG91clN0ZXBXaWR0aCAtIHRoaXMubWluaW1hbFRvdXJTdGVwV2lkdGg7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2FsY3VsYXRlIHRoZSBsZWZ0IHBvc2l0aW9uIG9mIHRoZSBoaWdobGlnaHRlZCByZWN0YW5nbGVcbiAgICAgKiBAcmV0dXJuIGxlZnQgcG9zaXRpb24gb2YgY3VycmVudCB0b3VyIHN0ZXAgLyBoaWdobGlnaHRlZCBlbGVtZW50XG4gICAgICovXG4gICAgcHJpdmF0ZSBnZXQgY2FsY3VsYXRlZEhpZ2hsaWdodExlZnRQb3NpdGlvbigpOiBudW1iZXIge1xuICAgICAgICBpZiAoIXRoaXMuc2VsZWN0ZWRFbGVtZW50UmVjdCB8fCAhdGhpcy5jdXJyZW50VG91clN0ZXApIHtcbiAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcGFkZGluZ0FkanVzdG1lbnQgPSB0aGlzLmN1cnJlbnRUb3VyU3RlcC5oaWdobGlnaHRQYWRkaW5nID8gdGhpcy5jdXJyZW50VG91clN0ZXAuaGlnaGxpZ2h0UGFkZGluZyA6IDA7XG5cbiAgICAgICAgaWYgKHRoaXMub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLlRPUFJJR0hUIHx8IHRoaXMub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLkJPVFRPTVJJR0hUKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0LnJpZ2h0IC0gdGhpcy50b3VyU3RlcFdpZHRoO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLlRPUExFRlQgfHwgdGhpcy5vcmllbnRhdGlvbiA9PT0gT3JpZW50YXRpb24uQk9UVE9NTEVGVCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc2VsZWN0ZWRFbGVtZW50UmVjdC5sZWZ0O1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLkxFRlQpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnNlbGVjdGVkRWxlbWVudFJlY3QubGVmdCAtIHRoaXMudG91clN0ZXBXaWR0aCAtIHBhZGRpbmdBZGp1c3RtZW50O1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMub3JpZW50YXRpb24gPT09IE9yaWVudGF0aW9uLlJJR0hUKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0LmxlZnQgKyB0aGlzLnNlbGVjdGVkRWxlbWVudFJlY3Qud2lkdGggKyBwYWRkaW5nQWRqdXN0bWVudDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0LnJpZ2h0IC0gdGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0LndpZHRoIC8gMiAtIHRoaXMudG91clN0ZXBXaWR0aCAvIDI7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2FsY3VsYXRlIHdpZHRoIGFkanVzdG1lbnQgZm9yIHNjcmVlbiBib3VuZFxuICAgICAqIEByZXR1cm4gd2lkdGggYWRqdXN0bWVudCBmb3Igc2NyZWVuIGJvdW5kXG4gICAgICovXG4gICAgcHJpdmF0ZSBnZXQgd2lkdGhBZGp1c3RtZW50Rm9yU2NyZWVuQm91bmQoKTogbnVtYmVyIHtcbiAgICAgICAgbGV0IGFkanVzdG1lbnQgPSAwO1xuXG4gICAgICAgIGlmICh0aGlzLmNhbGN1bGF0ZWRIaWdobGlnaHRMZWZ0UG9zaXRpb24gPCAwKSB7XG4gICAgICAgICAgICBhZGp1c3RtZW50ID0gLXRoaXMuY2FsY3VsYXRlZEhpZ2hsaWdodExlZnRQb3NpdGlvbjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5jYWxjdWxhdGVkSGlnaGxpZ2h0TGVmdFBvc2l0aW9uID4gd2luZG93LmlubmVyV2lkdGggLSB0aGlzLnRvdXJTdGVwV2lkdGgpIHtcbiAgICAgICAgICAgIGFkanVzdG1lbnQgPSB0aGlzLmNhbGN1bGF0ZWRIaWdobGlnaHRMZWZ0UG9zaXRpb24gLSAod2luZG93LmlubmVyV2lkdGggLSB0aGlzLnRvdXJTdGVwV2lkdGgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBNYXRoLm1pbih0aGlzLm1heFdpZHRoQWRqdXN0bWVudEZvclRvdXJTdGVwLCBhZGp1c3RtZW50KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDYWxjdWxhdGUgYSB2YWx1ZSB0byBhZGQgb3Igc3VidHJhY3Qgc28gdGhlIHN0ZXAgc2hvdWxkIG5vdCBiZSBvZmYgc2NyZWVuLlxuICAgICAqIEByZXR1cm4gc3RlcCBzY3JlZW4gYWRqdXN0bWVudFxuICAgICAqL1xuICAgIHByaXZhdGUgZ2V0U3RlcFNjcmVlbkFkanVzdG1lbnQoKTogbnVtYmVyIHtcbiAgICAgICAgaWYgKCF0aGlzLnNlbGVjdGVkRWxlbWVudFJlY3QgfHwgIXRoaXMuY3VycmVudFRvdXJTdGVwKSB7XG4gICAgICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5vcmllbnRhdGlvbiA9PT0gT3JpZW50YXRpb24uTEVGVCB8fCB0aGlzLm9yaWVudGF0aW9uID09PSBPcmllbnRhdGlvbi5SSUdIVCkge1xuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBlbGVtZW50SGVpZ2h0ID0gdGhpcy5zZWxlY3RlZEVsZW1lbnRSZWN0LmhlaWdodCArIHRoaXMudG91clN0ZXAubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XG5cbiAgICAgICAgaWYgKHdpbmRvdy5pbm5lckhlaWdodCA8IGVsZW1lbnRIZWlnaHQpIHtcbiAgICAgICAgICAgIHJldHVybiBlbGVtZW50SGVpZ2h0IC0gd2luZG93LmlubmVySGVpZ2h0O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAwO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZSB0b3VyIHN0ZXAgbG9jYXRpb24gYW5kIHJldHVybiBzZWxlY3RlZCBlbGVtZW50IGFzIERPTVJlY3RcbiAgICAgKiBAcGFyYW0gc2VsZWN0ZWRFbGVtZW50OiBzZWxlY3RlZCBlbGVtZW50IGluIERPTVxuICAgICAqIEBwYXJhbSBpc1Jlc2l6ZU9yU2Nyb2xsOiB0cnVlIGlmIHRoaXMgbWV0aG9kIGlzIGNhbGxlZCBieSBhIHJlc2l6ZSBvciBzY3JvbGwgZXZlbnQgbGlzdGVuZXI6XG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMgbWV0aG9kIHNob3VsZCBub3QgbGlzdGVuIHRvIHVzZXIgaW50ZXJhY3Rpb25zIHdoZW4gaXQgaXMgY2FsbGVkIHRocm91Z2ggcmVzaXppbmcgb3Igc2Nyb2xsaW5nIGV2ZW50c1xuICAgICAqIEByZXR1cm4gc2VsZWN0ZWQgZWxlbWVudCBhcyBET01SZWN0IG9yIHVuZGVmaW5lZFxuICAgICAqL1xuICAgIHByaXZhdGUgdXBkYXRlU3RlcExvY2F0aW9uKHNlbGVjdGVkRWxlbWVudDogSFRNTEVsZW1lbnQgfCB1bmRlZmluZWQsIGlzUmVzaXplT3JTY3JvbGw6IGJvb2xlYW4pOiBET01SZWN0IHwgdW5kZWZpbmVkIHtcbiAgICAgICAgbGV0IHNlbGVjdGVkRWxlbWVudFJlY3Q6IERPTVJlY3QgfCB1bmRlZmluZWQ7XG4gICAgICAgIGlmIChzZWxlY3RlZEVsZW1lbnQpIHtcbiAgICAgICAgICAgIHNlbGVjdGVkRWxlbWVudFJlY3QgPSBzZWxlY3RlZEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkgYXMgRE9NUmVjdDtcbiAgICAgICAgICAgIGlmICh0aGlzLmN1cnJlbnRUb3VyU3RlcCAmJiB0aGlzLmN1cnJlbnRUb3VyU3RlcC51c2VySW50ZXJhY3Rpb25FdmVudCAmJiAhaXNSZXNpemVPclNjcm9sbCkge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLmN1cnJlbnRUb3VyU3RlcC5tb2RlbGluZ1Rhc2spIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ndWlkZWRUb3VyU2VydmljZS5lbmFibGVVc2VySW50ZXJhY3Rpb24oc2VsZWN0ZWRFbGVtZW50LCB0aGlzLmN1cnJlbnRUb3VyU3RlcC51c2VySW50ZXJhY3Rpb25FdmVudCwgdGhpcy5jdXJyZW50VG91clN0ZXAubW9kZWxpbmdUYXNrLnVtbE5hbWUpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ3VpZGVkVG91clNlcnZpY2UuZW5hYmxlVXNlckludGVyYWN0aW9uKHNlbGVjdGVkRWxlbWVudCwgdGhpcy5jdXJyZW50VG91clN0ZXAudXNlckludGVyYWN0aW9uRXZlbnQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc2VsZWN0ZWRFbGVtZW50UmVjdDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXRzIHRoZSBzdGFydEZhZGUgY2xhc3MgZm9yIHRoZSB0b3VyIHN0ZXAgZGl2IHRvIGVhc2UgdGhlIHRyYW5zaXRpb24gYmV0d2VlbiB0b3VyIHN0ZXBzXG4gICAgICovXG4gICAgcHJpdmF0ZSBoYW5kbGVUcmFuc2l0aW9uKCkge1xuICAgICAgICB0aGlzLnN0YXJ0RmFkZSA9IHRydWU7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5zdGFydEZhZGUgPSBmYWxzZTtcbiAgICAgICAgfSwgMTAwMCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogT2JzZXJ2ZSBhbmQgY2hhbmdlIHBvc2l0aW9uIG9mIGhpZ2hsaWdodCBlbGVtZW50XG4gICAgICovXG4gICAgcHJpdmF0ZSBvYnNlcnZlU2VsZWN0ZWRSZWN0UG9zaXRpb24oKSB7XG4gICAgICAgIGNvbnN0IHNlbGVjdGVkRWxlbWVudCA9IHRoaXMuZ2V0U2VsZWN0ZWRFbGVtZW50KCk7XG4gICAgICAgIGNvbnN0IGFsZXJ0RWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5hbGVydHMnKTtcblxuICAgICAgICAvLyBPYnNlcnZlIGFsZXJ0cyBhbmQgdXBkYXRlIHRoZSBoaWdobGlnaHQgZWxlbWVudCBwb3NpdGlvbiBpZiBuZWNlc3NhcnlcbiAgICAgICAgaWYgKHNlbGVjdGVkRWxlbWVudCAmJiBhbGVydEVsZW1lbnQpIHtcbiAgICAgICAgICAgIHRoaXMuZ3VpZGVkVG91clNlcnZpY2VcbiAgICAgICAgICAgICAgICAub2JzZXJ2ZU11dGF0aW9ucyhhbGVydEVsZW1lbnQsIHsgY2hpbGRMaXN0OiB0cnVlIH0pXG4gICAgICAgICAgICAgICAgLnBpcGUodGFrZSgxKSlcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuZ2V0U2VsZWN0ZWRFbGVtZW50KCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2Nyb2xsVG9BbmRTZXRFbGVtZW50KCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERpc3BsYXkgb25seSBhcyBtYW55IGRvdHMgYXMgZGVmaW5lZCBpbiBHdWlkZWRUb3VyQ29tcG9uZW50Lm1heERvdHNcbiAgICAgKiBAcGFyYW0gY3VycmVudEluZGV4IGluZGV4IG9mIHRoZSBjdXJyZW50IHN0ZXBcbiAgICAgKiBAcGFyYW0gbmV4dEluZGV4IGluZGV4IG9mIHRoZSBuZXh0IHN0ZXAsIHRoaXMgc2hvdWxkIChjdXJyZW50IHN0ZXAgLS8rIDEpIGRlcGVuZGluZyBvbiB3aGV0aGVyIHRoZSB1c2VyIG5hdmlnYXRlcyBmb3J3YXJkcyBvciBiYWNrd2FyZHNcbiAgICAgKi9cbiAgICBwcml2YXRlIGNhbGN1bGF0ZUFuZERpc3BsYXlEb3ROYXZpZ2F0aW9uKGN1cnJlbnRJbmRleDogbnVtYmVyLCBuZXh0SW5kZXg6IG51bWJlcikge1xuICAgICAgICBjb25zdCBpc0ZvcndhcmROYXZpZ2F0aW9uID0gbmV4dEluZGV4ID4gY3VycmVudEluZGV4O1xuICAgICAgICBjb25zdCBuZXh0UGx1c09uZUluZGV4ID0gaXNGb3J3YXJkTmF2aWdhdGlvbiA/IG5leHRJbmRleCArIDEgOiBuZXh0SW5kZXggLSAxO1xuICAgICAgICBjb25zdCBuZXh0RG90ID0gdGhpcy5kb3RBcnJheVtuZXh0SW5kZXhdO1xuICAgICAgICBjb25zdCBuZXh0UGx1c09uZURvdCA9IHRoaXMuZG90QXJyYXlbbmV4dFBsdXNPbmVJbmRleF07XG5cbiAgICAgICAgaWYgKCFuZXh0RG90IHx8ICFuZXh0UGx1c09uZURvdCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKG5leHRJbmRleCA8IHRoaXMubWF4RG90cykge1xuICAgICAgICAgICAgdGhpcy50cmFuc2Zvcm1YID0gMDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpc0ZvcndhcmROYXZpZ2F0aW9uKSB7XG4gICAgICAgICAgICB0aGlzLmhhbmRsZUZvcndhcmROYXZpZ2F0aW9uKG5leHREb3QubmF0aXZlRWxlbWVudCwgbmV4dFBsdXNPbmVEb3QubmF0aXZlRWxlbWVudCwgbmV4dEluZGV4KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuaGFuZGxlQmFja3dhcmROYXZpZ2F0aW9uKG5leHREb3QubmF0aXZlRWxlbWVudCwgbmV4dFBsdXNPbmVEb3QubmF0aXZlRWxlbWVudCwgbmV4dEluZGV4KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgaGFuZGxlRm9yd2FyZE5hdmlnYXRpb24obmV4dDogSFRNTEVsZW1lbnQsIG5leHRQbHVzT25lOiBIVE1MRWxlbWVudCwgbmV4dEluZGV4OiBudW1iZXIpIHtcbiAgICAgICAgLy8gTW92ZXMgdGhlIG4tc21hbGwgYW5kIHAtc21hbGwgY2xhc3Mgb25lIGRvdCBmdXJ0aGVyXG4gICAgICAgIGNvbnN0IGxhc3REb3QgPSB0aGlzLmRvdEVsZW1lbnRzLmxhc3QubmF0aXZlRWxlbWVudDtcbiAgICAgICAgaWYgKCFsYXN0RG90LmNsYXNzTGlzdC5jb250YWlucygnbi1zbWFsbCcpKSB7XG4gICAgICAgICAgICB0aGlzLmRvdEFycmF5LmZvckVhY2goKG5vZGU6IEVsZW1lbnRSZWYsIGluZGV4OiBudW1iZXIpID0+IHtcbiAgICAgICAgICAgICAgICBub2RlLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgncC1zbWFsbCcpO1xuICAgICAgICAgICAgICAgIGlmIChpbmRleCA9PT0gbmV4dEluZGV4IC0gKHRoaXMubWF4RG90cyAtIDIpKSB7XG4gICAgICAgICAgICAgICAgICAgIG5vZGUubmF0aXZlRWxlbWVudC5jbGFzc0xpc3QuYWRkKCdwLXNtYWxsJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG5leHQgJiYgbmV4dC5jbGFzc0xpc3QuY29udGFpbnMoJ24tc21hbGwnKSAmJiBsYXN0RG90ICYmICFsYXN0RG90LmNsYXNzTGlzdC5jb250YWlucygnbi1zbWFsbCcpKSB7XG4gICAgICAgICAgICB0aGlzLnRyYW5zZm9ybUNvdW50ICs9IHRoaXMudHJhbnNmb3JtWEludGVydmFsTmV4dDtcbiAgICAgICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUodGhpcy5kb3ROYXZpZ2F0aW9uLm5hdGl2ZUVsZW1lbnQsICd0cmFuc2Zvcm0nLCAndHJhbnNsYXRlWCgnICsgdGhpcy50cmFuc2Zvcm1Db3VudCArICdweCknKTtcbiAgICAgICAgICAgIG5leHQuY2xhc3NMaXN0LnJlbW92ZSgnbi1zbWFsbCcpO1xuICAgICAgICAgICAgbmV4dFBsdXNPbmUuY2xhc3NMaXN0LmFkZCgnbi1zbWFsbCcpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBoYW5kbGVCYWNrd2FyZE5hdmlnYXRpb24obmV4dDogSFRNTEVsZW1lbnQsIG5leHRQbHVzT25lOiBIVE1MRWxlbWVudCwgbmV4dEluZGV4OiBudW1iZXIpIHtcbiAgICAgICAgLy8gSGFuZGxlcyBiYWNrd2FyZHMgbmF2aWdhdGlvblxuICAgICAgICBjb25zdCBmaXJzdERvdCA9IHRoaXMuZG90RWxlbWVudHMuZmlyc3QubmF0aXZlRWxlbWVudDtcbiAgICAgICAgdGhpcy5kb3RBcnJheS5mb3JFYWNoKChub2RlOiBFbGVtZW50UmVmLCBpbmRleDogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgICBub2RlLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbi1zbWFsbCcpO1xuICAgICAgICAgICAgaWYgKCh0aGlzLnRyYW5zZm9ybUNvdW50ICE9PSAwICYmIGluZGV4ID09PSBuZXh0SW5kZXggKyAxKSB8fCAodGhpcy50cmFuc2Zvcm1Db3VudCA9PT0gMCAmJiBpbmRleCA9PT0gdGhpcy5tYXhEb3RzIC0gMSkpIHtcbiAgICAgICAgICAgICAgICBub2RlLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbi1zbWFsbCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKG5leHQgJiYgZmlyc3REb3QgJiYgIWZpcnN0RG90LmNsYXNzTGlzdC5jb250YWlucygncC1zbWFsbCcpICYmIG5leHRJbmRleCA+IHRoaXMubWF4RG90cyAtIDIpIHtcbiAgICAgICAgICAgIHRoaXMudHJhbnNmb3JtQ291bnQgKz0gdGhpcy50cmFuc2Zvcm1YSW50ZXJ2YWxQcmV2O1xuICAgICAgICAgICAgaWYgKHRoaXMudHJhbnNmb3JtQ291bnQgIT09IDApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRyYW5zZm9ybVggPSB0aGlzLnRyYW5zZm9ybUNvdW50O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG5leHQuY2xhc3NMaXN0LmNvbnRhaW5zKCdwLXNtYWxsJykpIHtcbiAgICAgICAgICAgICAgICBuZXh0LmNsYXNzTGlzdC5yZW1vdmUoJ3Atc21hbGwnKTtcbiAgICAgICAgICAgICAgICBuZXh0UGx1c09uZS5jbGFzc0xpc3QuYWRkKCdwLXNtYWxsJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEZWZpbmVzIHRoZSB0cmFuc2xhdGVYIHZhbHVlIGZvciB0aGUgPHVsPiB0cmFuc2Zvcm0gc3R5bGVcbiAgICAgKi9cbiAgICBwcml2YXRlIGNhbGN1bGF0ZVRyYW5zbGF0ZVZhbHVlKCk6IHZvaWQge1xuICAgICAgICBjb25zdCBjdXJyZW50VG91clN0ZXAgPSB0aGlzLmd1aWRlZFRvdXJTZXJ2aWNlLmN1cnJlbnRUb3VyU3RlcEluZGV4ICsgMTtcbiAgICAgICAgaWYgKGN1cnJlbnRUb3VyU3RlcCA+PSB0aGlzLm1heERvdHMpIHtcbiAgICAgICAgICAgIHRoaXMudHJhbnNmb3JtQ291bnQgPSAoKGN1cnJlbnRUb3VyU3RlcCAlIHRoaXMubWF4RG90cykgKyAxKSAqIHRoaXMudHJhbnNmb3JtWEludGVydmFsTmV4dDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnRyYW5zZm9ybVggPSB0aGlzLnRyYW5zZm9ybUNvdW50O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERlZmluZXMgaWYgYW4gPGxpPiBpdGVtIHNob3VsZCBoYXZlIHRoZSAnbi1zbWFsbCcgY2xhc3NcbiAgICAgKiBAcGFyYW0gc3RlcE51bWJlciB0b3VyIHN0ZXAgbnVtYmVyIG9mIHRoZSA8bGk+IGl0ZW1cbiAgICAgKi9cbiAgICBwdWJsaWMgY2FsY3VsYXRlTlNtYWxsRG90KHN0ZXBOdW1iZXI6IG51bWJlcik6IGJvb2xlYW4ge1xuICAgICAgICBpZiAodGhpcy5ndWlkZWRUb3VyU2VydmljZS5jdXJyZW50VG91clN0ZXBJbmRleCA8IHRoaXMubWF4RG90cykge1xuICAgICAgICAgICAgcmV0dXJuIHN0ZXBOdW1iZXIgPT09IHRoaXMubWF4RG90cztcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5uZXh0U3RlcEluZGV4KSB7XG4gICAgICAgICAgICByZXR1cm4gc3RlcE51bWJlciA9PT0gdGhpcy5uZXh0U3RlcEluZGV4ICsgMTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGVmaW5lcyBpZiBhbiA8bGk+IGl0ZW0gc2hvdWxkIGhhdmUgdGhlICdwLXNtYWxsJyBjbGFzc1xuICAgICAqIEBwYXJhbSBzdGVwTnVtYmVyIHRvdXIgc3RlcCBudW1iZXIgb2YgdGhlIDxsaT4gaXRlbVxuICAgICAqL1xuICAgIHB1YmxpYyBjYWxjdWxhdGVQU21hbGxEb3Qoc3RlcE51bWJlcjogbnVtYmVyKTogYm9vbGVhbiB7XG4gICAgICAgIGlmIChcbiAgICAgICAgICAgIHRoaXMuZ3VpZGVkVG91clNlcnZpY2UuY3VycmVudFRvdXJTdGVwSW5kZXggPiB0aGlzLm1heERvdHMgJiZcbiAgICAgICAgICAgIHRoaXMuZ3VpZGVkVG91clNlcnZpY2UuY3VycmVudFRvdXJTdGVwSW5kZXggPCB0aGlzLmd1aWRlZFRvdXJTZXJ2aWNlLmdldEZpbHRlcmVkVG91clN0ZXBzKCkubGVuZ3RoICYmXG4gICAgICAgICAgICB0aGlzLm5leHRTdGVwSW5kZXhcbiAgICAgICAgKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5uZXh0U3RlcEluZGV4ICsgMSAtIHN0ZXBOdW1iZXIgPT09IDg7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbn1cbiIsIkBpZiAoY3VycmVudFRvdXJTdGVwKSB7XG4gICAgPGRpdj5cbiAgICAgICAgQGlmICghc2VsZWN0ZWRFbGVtZW50UmVjdCkge1xuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZ3VpZGVkLXRvdXItb3ZlcmxheVwiIChjbGljayk9XCJiYWNrZHJvcENsaWNrKCRldmVudClcIj48L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJndWlkZWQtdG91ci1vdmVybGF5XCIgW25nU3R5bGVdPVwiZ2V0T3ZlcmxheVN0eWxlKE92ZXJsYXlQb3NpdGlvbi5UT1ApIHx8IG51bGxcIiAoY2xpY2spPVwiYmFja2Ryb3BDbGljaygkZXZlbnQpXCI+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZ3VpZGVkLXRvdXItb3ZlcmxheVwiIFtuZ1N0eWxlXT1cImdldE92ZXJsYXlTdHlsZShPdmVybGF5UG9zaXRpb24uTEVGVCkgfHwgbnVsbFwiIChjbGljayk9XCJiYWNrZHJvcENsaWNrKCRldmVudClcIj48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJndWlkZWQtdG91ci1vdmVybGF5XCIgW25nU3R5bGVdPVwiZ2V0T3ZlcmxheVN0eWxlKE92ZXJsYXlQb3NpdGlvbi5SSUdIVCkgfHwgbnVsbFwiIChjbGljayk9XCJiYWNrZHJvcENsaWNrKCRldmVudClcIj48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJndWlkZWQtdG91ci1vdmVybGF5XCIgW25nU3R5bGVdPVwiZ2V0T3ZlcmxheVN0eWxlKE92ZXJsYXlQb3NpdGlvbi5CT1RUT00pIHx8IG51bGxcIiAoY2xpY2spPVwiYmFja2Ryb3BDbGljaygkZXZlbnQpXCI+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgY2xhc3M9XCJndWlkZWQtdG91ci1lbGVtZW50LW92ZXJsYXlcIlxuICAgICAgICAgICAgICAgIFtjbGFzcy5jbGljay10aHJvdWdoXT1cImN1cnJlbnRUb3VyU3RlcC51c2VySW50ZXJhY3Rpb25FdmVudFwiXG4gICAgICAgICAgICAgICAgW25nU3R5bGVdPVwiZ2V0T3ZlcmxheVN0eWxlKE92ZXJsYXlQb3NpdGlvbi5FTEVNRU5UKSB8fCBudWxsXCJcbiAgICAgICAgICAgICAgICAoY2xpY2spPVwiYmFja2Ryb3BDbGljaygkZXZlbnQpXCJcbiAgICAgICAgICAgID48L2Rpdj5cbiAgICAgICAgfVxuICAgIDwvZGl2PlxufVxuQGlmIChjdXJyZW50VG91clN0ZXApIHtcbiAgICA8ZGl2PlxuICAgICAgICBAaWYgKGN1cnJlbnRUb3VyU3RlcCkge1xuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICN0b3VyU3RlcFxuICAgICAgICAgICAgICAgIGNsYXNzPVwidG91ci1zdGVwIHRvdXIte3sgb3JpZW50YXRpb24gfX1cIlxuICAgICAgICAgICAgICAgIFtjbGFzcy5wYWdlLXRvdXItc3RlcF09XCIhY3VycmVudFRvdXJTdGVwLmhpZ2hsaWdodFNlbGVjdG9yXCJcbiAgICAgICAgICAgICAgICBbY2xhc3Muc3RhcnRGYWRlXT1cInN0YXJ0RmFkZVwiXG4gICAgICAgICAgICAgICAgW2NsYXNzLnZpZGVvLXRvdXJdPVwiaXNWaWRlb1RvdXJTdGVwKClcIlxuICAgICAgICAgICAgICAgIFtzdHlsZS50b3AucHhdPVwidG9wUG9zaXRpb25cIlxuICAgICAgICAgICAgICAgIFtzdHlsZS5sZWZ0LnB4XT1cImxlZnRQb3NpdGlvblwiXG4gICAgICAgICAgICAgICAgW3N0eWxlLndpZHRoLnB4XT1cImNhbGN1bGF0ZWRUb3VyU3RlcFdpZHRoXCJcbiAgICAgICAgICAgICAgICBbc3R5bGUudHJhbnNmb3JtXT1cInRyYW5zZm9ybVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQGlmIChjdXJyZW50VG91clN0ZXAuaGlnaGxpZ2h0U2VsZWN0b3IpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRvdXItYXJyb3dcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRvdXItYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRvdXItYmxvY2tfX2hlYWRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjdXJyZW50VG91clN0ZXAuaGVhZGxpbmVUcmFuc2xhdGVLZXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3M9XCJoZWFkbGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKCFndWlkZWRUb3VyU2VydmljZS5pc09uUmVzaXplTWVzc2FnZSAmJiBndWlkZWRUb3VyU2VydmljZS5jdXJyZW50VG91ciAmJiBndWlkZWRUb3VyU2VydmljZS5jdXJyZW50VG91ci5zdGVwcy5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAndG91ci5zdGVwJyB8IGFydGVtaXNUcmFuc2xhdGU6IHsgc3RyaW5nOiBndWlkZWRUb3VyU2VydmljZS5nZXRDdXJyZW50U3RlcFN0cmluZygpIH0gfX0gPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGN1cnJlbnRUb3VyU3RlcC5oZWFkbGluZVRyYW5zbGF0ZUtleSB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChndWlkZWRUb3VyU2VydmljZS5jdXJyZW50VG91cikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4tY2xvc2VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBndWlkZWRUb3VyU2VydmljZS5pc0N1cnJlbnRUb3VyKGNhbmNlbFRvdXIpIHx8IGd1aWRlZFRvdXJTZXJ2aWNlLmlzQ3VycmVudFRvdXIoY29tcGxldGVkVG91cilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGd1aWRlZFRvdXJTZXJ2aWNlLnJlc2V0VG91cigpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBndWlkZWRUb3VyU2VydmljZS5za2lwVG91cigpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRvdXItYmxvY2tfX2NvbnRlbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY3VycmVudFRvdXJTdGVwLnN1YkhlYWRsaW5lVHJhbnNsYXRlS2V5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg1IGpoaVRyYW5zbGF0ZT1cInt7IGN1cnJlbnRUb3VyU3RlcC5zdWJIZWFkbGluZVRyYW5zbGF0ZUtleSB9fVwiIGNsYXNzPVwic3ViLWhlYWRsaW5lXCI+PC9oNT5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgW2lubmVySFRNTF09XCJjdXJyZW50VG91clN0ZXAuY29udGVudFRyYW5zbGF0ZUtleSB8IGFydGVtaXNUcmFuc2xhdGVcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY3VycmVudFRvdXJTdGVwLmhpbnRUcmFuc2xhdGVLZXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3RlcC1oaW50XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGVwLWhpbnRfX2ljb25cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhSW5mb0NpcmNsZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGVwLWhpbnRfX2xhYmVsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IFtpbm5lckhUTUxdPVwiY3VycmVudFRvdXJTdGVwLmhpbnRUcmFuc2xhdGVLZXkgfCBhcnRlbWlzVHJhbnNsYXRlXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjdXJyZW50VG91clN0ZXAuYWxyZWFkeUV4ZWN1dGVkVHJhbnNsYXRlS2V5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN0ZXAtaGludCBpbnRlcmFjdGlvbiBhbGVydCBhbGVydC1zdWNjZXNzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGVwLWhpbnRfX2ljb25cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQ2hlY2tcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3RlcC1oaW50X19sYWJlbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBbaW5uZXJIVE1MXT1cImN1cnJlbnRUb3VyU3RlcC5hbHJlYWR5RXhlY3V0ZWRUcmFuc2xhdGVLZXkgfCBhcnRlbWlzVHJhbnNsYXRlXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjdXJyZW50VG91clN0ZXAudXNlckludGVyYWN0aW9uRXZlbnQgJiYgIWN1cnJlbnRUb3VyU3RlcC5tb2RlbGluZ1Rhc2spIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3RlcC1oaW50IGludGVyYWN0aW9uIGFsZXJ0XCIgW2NsYXNzLmFsZXJ0LXN1Y2Nlc3NdPVwidXNlckludGVyYWN0aW9uRmluaXNoZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICh0aGlzLnVzZXJJbnRlcmFjdGlvbkZpbmlzaGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3RlcC1oaW50X19pY29uXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFDaGVja1wiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGVwLWhpbnRfX2ljb25cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGN1cnJlbnRUb3VyU3RlcC51c2VySW50ZXJhY3Rpb25FdmVudCA9PT0gVXNlckludGVyYWN0aW9uRXZlbnQuQ0xJQ0spIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFIYW5kUG9pbnRVcFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjdXJyZW50VG91clN0ZXAudXNlckludGVyYWN0aW9uRXZlbnQgPT09IFVzZXJJbnRlcmFjdGlvbkV2ZW50LkFDRV9FRElUT1IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFJQ3Vyc29yXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGN1cnJlbnRUb3VyU3RlcC51c2VySW50ZXJhY3Rpb25FdmVudCA9PT0gVXNlckludGVyYWN0aW9uRXZlbnQuV0FJVF9GT1JfU0VMRUNUT1IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW3NwaW5dPVwidHJ1ZVwiIFtpY29uXT1cImZhQ2lyY2xlTm90Y2hcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY3VycmVudFRvdXJTdGVwLnVzZXJJbnRlcmFjdGlvbkV2ZW50ID09PSBVc2VySW50ZXJhY3Rpb25FdmVudC5NT0RFTElORyAmJiAhY3VycmVudFRvdXJTdGVwLm1vZGVsaW5nVGFzaykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUFycm93c0FsdFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjdXJyZW50VG91clN0ZXAudXNlckludGVyYWN0aW9uRXZlbnQgPT09IFVzZXJJbnRlcmFjdGlvbkV2ZW50LkFTU0VTU19TVUJNSVNTSU9OKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhRWRpdFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3RlcC1oaW50X19sYWJlbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjdXJyZW50VG91clN0ZXAudXNlckludGVyYWN0aW9uRXZlbnQgPT09IFVzZXJJbnRlcmFjdGlvbkV2ZW50LkNMSUNLKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gW2poaVRyYW5zbGF0ZV09XCIndG91ci5jbGlja0hpbnQudGV4dCdcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGN1cnJlbnRUb3VyU3RlcC51c2VySW50ZXJhY3Rpb25FdmVudCA9PT0gVXNlckludGVyYWN0aW9uRXZlbnQuQUNFX0VESVRPUikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIFtqaGlUcmFuc2xhdGVdPVwiJ3RvdXIudHlwZUhpbnQudGV4dCdcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGN1cnJlbnRUb3VyU3RlcC51c2VySW50ZXJhY3Rpb25FdmVudCA9PT0gVXNlckludGVyYWN0aW9uRXZlbnQuV0FJVF9GT1JfU0VMRUNUT1IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBbamhpVHJhbnNsYXRlXT1cIid0b3VyLndhaXRIaW50LnRleHQnXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjdXJyZW50VG91clN0ZXAudXNlckludGVyYWN0aW9uRXZlbnQgPT09IFVzZXJJbnRlcmFjdGlvbkV2ZW50Lk1PREVMSU5HICYmICFjdXJyZW50VG91clN0ZXAubW9kZWxpbmdUYXNrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gW2poaVRyYW5zbGF0ZV09XCIndG91ci5tb2RlbGluZ0hpbnQudGV4dCdcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGN1cnJlbnRUb3VyU3RlcC51c2VySW50ZXJhY3Rpb25FdmVudCA9PT0gVXNlckludGVyYWN0aW9uRXZlbnQuQVNTRVNTX1NVQk1JU1NJT04pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBbamhpVHJhbnNsYXRlXT1cImN1cnJlbnRUb3VyU3RlcC5hc3Nlc3NtZW50VGFzay50YXNrVHJhbnNsYXRlS2V5XCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY3VycmVudFRvdXJTdGVwLm1vZGVsaW5nVGFzaykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGVwLWhpbnQgaW50ZXJhY3Rpb24gYWxlcnRcIiBbY2xhc3MuYWxlcnQtc3VjY2Vzc109XCJ1c2VySW50ZXJhY3Rpb25GaW5pc2hlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKCF1c2VySW50ZXJhY3Rpb25GaW5pc2hlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN0ZXAtaGludF9faWNvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQ2xpcGJvYXJkTGlzdFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAodXNlckludGVyYWN0aW9uRmluaXNoZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGVwLWhpbnRfX2ljb25cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUNoZWNrXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN0ZXAtaGludF9fbGFiZWxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgW2lubmVySFRNTF09XCJjdXJyZW50VG91clN0ZXAubW9kZWxpbmdUYXNrLnRhc2tUcmFuc2xhdGVLZXkgfCBhcnRlbWlzVHJhbnNsYXRlXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjdXJyZW50VG91clN0ZXAuaW1hZ2VVcmwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz1cInt7IGN1cnJlbnRUb3VyU3RlcC5pbWFnZVVybCB9fVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGN1cnJlbnRUb3VyU3RlcC52aWRlb1VybCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGVwLWhpbnQgaW50ZXJhY3Rpb24gYWxlcnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN0ZXAtaGludF9faWNvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFWaWRlb1wiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGVwLWhpbnRfX2xhYmVsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJ0b3VyLnZpZGVvSGludC50ZXh0XCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY3VycmVudFRvdXJTdGVwLnZpZGVvVXJsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlmcmFtZSBbc3JjXT1cImN1cnJlbnRUb3VyU3RlcC52aWRlb1VybCB8IGFydGVtaXNUcmFuc2xhdGUgfCBzYWZlUmVzb3VyY2VVcmxcIiBmcmFtZWJvcmRlcj1cIjBcIiBhbGxvd2Z1bGxzY3JlZW4+PC9pZnJhbWU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidG91ci1ibG9ja19fYnV0dG9uc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghZ3VpZGVkVG91clNlcnZpY2UuaXNDdXJyZW50VG91cihjYW5jZWxUb3VyKSAmJiAhZ3VpZGVkVG91clNlcnZpY2UuaXNDdXJyZW50VG91cihjb21wbGV0ZWRUb3VyKSAmJiAhZ3VpZGVkVG91clNlcnZpY2UuaXNPblJlc2l6ZU1lc3NhZ2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYmFjay1idXR0b25cIiBbZGlzYWJsZWRdPVwiZ3VpZGVkVG91clNlcnZpY2UuaXNPbkZpcnN0U3RlcFwiIChjbGljayk9XCJndWlkZWRUb3VyU2VydmljZS5iYWNrU3RlcCgpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQ2hldnJvbkxlZnRcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cInRvdXIubmF2aWdhdGlvbi5iYWNrXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChndWlkZWRUb3VyU2VydmljZS5pc0N1cnJlbnRUb3VyKGNvbXBsZXRlZFRvdXIpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInJlc3RhcnQtYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2Rpc2FibGVkXT1cImd1aWRlZFRvdXJTZXJ2aWNlLmlzT25SZXNpemVNZXNzYWdlIHx8IGd1aWRlZFRvdXJTZXJ2aWNlLnJlc3RhcnRJc0xvYWRpbmdcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwiZ3VpZGVkVG91clNlcnZpY2UucmVzdGFydFRvdXIoKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKCFndWlkZWRUb3VyU2VydmljZS5yZXN0YXJ0SXNMb2FkaW5nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVBsYXlDaXJjbGVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChndWlkZWRUb3VyU2VydmljZS5yZXN0YXJ0SXNMb2FkaW5nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBjbGFzcz1cImpoaS1idG5fX2xvYWRpbmdcIiBbaWNvbl09XCJmYUNpcmNsZU5vdGNoXCIgW3NwaW5dPVwidHJ1ZVwiIHNpemU9XCJzbVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJnbG9iYWwubWVudS5yZXN0YXJ0VHV0b3JpYWxcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKCFndWlkZWRUb3VyU2VydmljZS5pc09uUmVzaXplTWVzc2FnZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkb3RzdHlsZSBkb3RzdHlsZS0tc2NhbGV1cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGd1aWRlZFRvdXJTZXJ2aWNlLmN1cnJlbnRUb3VyICYmIGd1aWRlZFRvdXJTZXJ2aWNlLmN1cnJlbnRUb3VyLnN0ZXBzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx1bCAjZG90TmF2aWdhdGlvbiBbbmdTdHlsZV09XCJ7IHRyYW5zZm9ybTogJ3RyYW5zbGF0ZVgoJyArIHRyYW5zZm9ybVggKyAncHgpJyB9XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAoaSBvZiBndWlkZWRUb3VyU2VydmljZS5jdXJyZW50VG91ci5zdGVwczsgdHJhY2sgaSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICNkb3RFbGVtZW50c1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJkb3QtaW5kZXgte3sgZ3VpZGVkVG91clNlcnZpY2UuY3VycmVudFRvdXIuc3RlcHMuaW5kZXhPZihpKSB9fVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuY3VycmVudF09XCJndWlkZWRUb3VyU2VydmljZS5pc0N1cnJlbnRTdGVwKGkpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5uLXNtYWxsXT1cImNhbGN1bGF0ZU5TbWFsbERvdChndWlkZWRUb3VyU2VydmljZS5jdXJyZW50VG91ci5zdGVwcy5pbmRleE9mKGkpICsgMSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnAtc21hbGxdPVwiY2FsY3VsYXRlUFNtYWxsRG90KGd1aWRlZFRvdXJTZXJ2aWNlLmN1cnJlbnRUb3VyLnN0ZXBzLmluZGV4T2YoaSkgKyAxKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGd1aWRlZFRvdXJTZXJ2aWNlLmN1cnJlbnRUb3VyLnN0ZXBzLmluZGV4T2YoaSkgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghZ3VpZGVkVG91clNlcnZpY2UuaXNPbkxhc3RTdGVwICYmICFndWlkZWRUb3VyU2VydmljZS5pc09uUmVzaXplTWVzc2FnZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJuZXh0LWJ1dHRvblwiIFtkaXNhYmxlZF09XCJjdXJyZW50VG91clN0ZXAudXNlckludGVyYWN0aW9uRXZlbnQgJiYgIXVzZXJJbnRlcmFjdGlvbkZpbmlzaGVkXCIgKGNsaWNrKT1cImd1aWRlZFRvdXJTZXJ2aWNlLm5leHRTdGVwKClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwidG91ci5uYXZpZ2F0aW9uLm5leHRcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQ2hldnJvblJpZ2h0XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBndWlkZWRUb3VyU2VydmljZS5pc09uTGFzdFN0ZXAgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAhZ3VpZGVkVG91clNlcnZpY2UuaXNDdXJyZW50VG91cihjYW5jZWxUb3VyKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICFndWlkZWRUb3VyU2VydmljZS5pc0N1cnJlbnRUb3VyKGNvbXBsZXRlZFRvdXIpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIWd1aWRlZFRvdXJTZXJ2aWNlLmlzT25SZXNpemVNZXNzYWdlXG4gICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwibmV4dC1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJ0b3VyLm5hdmlnYXRpb24uZG9uZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtkaXNhYmxlZF09XCJjdXJyZW50VG91clN0ZXAudXNlckludGVyYWN0aW9uRXZlbnQgJiYgIXVzZXJJbnRlcmFjdGlvbkZpbmlzaGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cImd1aWRlZFRvdXJTZXJ2aWNlLm5leHRTdGVwKClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZ3VpZGVkVG91clNlcnZpY2UuaXNPblJlc2l6ZU1lc3NhZ2UgfHwgZ3VpZGVkVG91clNlcnZpY2UuaXNDdXJyZW50VG91cihjYW5jZWxUb3VyKSB8fCBndWlkZWRUb3VyU2VydmljZS5pc0N1cnJlbnRUb3VyKGNvbXBsZXRlZFRvdXIpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cIm5leHQtYnV0dG9uXCIgamhpVHJhbnNsYXRlPVwidG91ci5uYXZpZ2F0aW9uLmNsb3NlXCIgKGNsaWNrKT1cImd1aWRlZFRvdXJTZXJ2aWNlLnJlc2V0VG91cigpXCI+PC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICA8L2Rpdj5cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOZ2JQb3BvdmVyIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xuaW1wb3J0IHsgVGhlbWUsIFRoZW1lU2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3RoZW1lL3RoZW1lLnNlcnZpY2UnO1xuaW1wb3J0IHsgZnJvbUV2ZW50IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBmYVN5bmMgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuXG4vKipcbiAqIERpc3BsYXlzIGEgc3VuIG9yIGEgbW9vbiBpbiB0aGUgbmF2YmFyLCBkZXBlbmRpbmcgb24gdGhlIGN1cnJlbnQgdGhlbWUuXG4gKiBBZGRpdGlvbmFsbHksIGFsbG93cyB0byBzd2l0Y2ggdGhlbWVzIGJ5IGNsaWNraW5nIGl0LlxuICogU2hvd3MgYSBwb3BvdmVyIHdpdGggYWRkaXRpb25hbCBvcHRpb25zLlxuICovXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS10aGVtZS1zd2l0Y2gnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi90aGVtZS1zd2l0Y2guY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWyd0aGVtZS1zd2l0Y2guY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgVGhlbWVTd2l0Y2hDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEBWaWV3Q2hpbGQoJ3BvcG92ZXInKSBwb3BvdmVyOiBOZ2JQb3BvdmVyO1xuXG4gICAgQElucHV0KCkgcG9wb3ZlclBsYWNlbWVudDogc3RyaW5nO1xuXG4gICAgaXNEYXJrID0gZmFsc2U7XG4gICAgaXNTeW5jZWQgPSBmYWxzZTtcbiAgICBhbmltYXRlID0gdHJ1ZTtcbiAgICBvcGVuUG9wdXBBZnRlck5leHRDaGFuZ2UgPSBmYWxzZTtcbiAgICBjbG9zZVRpbWVvdXQ6IGFueTtcblxuICAgIC8vIEljb25zXG4gICAgZmFTeW5jID0gZmFTeW5jO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSB0aGVtZVNlcnZpY2U6IFRoZW1lU2VydmljZSkge31cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICAvLyBMaXN0ZW4gdG8gdGhlbWUgY2hhbmdlcyB0byBjaGFuZ2Ugb3VyIG93biBzdGF0ZSBhY2NvcmRpbmdseVxuICAgICAgICB0aGlzLnRoZW1lU2VydmljZS5nZXRDdXJyZW50VGhlbWVPYnNlcnZhYmxlKCkuc3Vic2NyaWJlKCh0aGVtZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5pc0RhcmsgPSB0aGVtZSA9PT0gVGhlbWUuREFSSztcbiAgICAgICAgICAgIHRoaXMuYW5pbWF0ZSA9IHRydWU7XG4gICAgICAgICAgICBpZiAodGhpcy5vcGVuUG9wdXBBZnRlck5leHRDaGFuZ2UpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm9wZW5Qb3B1cEFmdGVyTmV4dENoYW5nZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gdGhpcy5vcGVuUG9wb3ZlcigpLCAyNTApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICAvLyBMaXN0ZW4gdG8gcHJlZmVyZW5jZSBjaGFuZ2VzXG4gICAgICAgIHRoaXMudGhlbWVTZXJ2aWNlLmdldFByZWZlcmVuY2VPYnNlcnZhYmxlKCkuc3Vic2NyaWJlKCh0aGVtZU9yVW5kZWZpbmVkKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmlzU3luY2VkID0gIXRoZW1lT3JVbmRlZmluZWQ7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIFdvcmthcm91bmQgYXMgd2UgY2FuJ3QgZHluYW1pY2FsbHkgY2hhbmdlIHRoZSBcImF1dG9DbG9zZVwiIHByb3BlcnR5IG9uIHBvcG92ZXJzXG4gICAgICAgIGZyb21FdmVudCh3aW5kb3csICdjbGljaycpLnN1YnNjcmliZSgoZSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcG9wb3ZlckNvbnRlbnRFbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RoZW1lLXN3aXRjaC1wb3BvdmVyLWNvbnRlbnQnKTtcbiAgICAgICAgICAgIGlmICh0aGlzLnBvcG92ZXIuaXNPcGVuKCkgJiYgIXBvcG92ZXJDb250ZW50RWxlbWVudD8uY29udGFpbnMoZS50YXJnZXQgYXMgTm9kZSkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNsb3NlUG9wb3ZlcigpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBPcGVuIHRoZSBwb3BvdmVyIGlmIHRoaXMgaXMgbm90IGEgY3lwcmVzcyB0ZXN0XG4gICAgICovXG4gICAgb3BlblBvcG92ZXIoKSB7XG4gICAgICAgIGlmICghd2luZG93WydDeXByZXNzJ10pIHtcbiAgICAgICAgICAgIHRoaXMucG9wb3Zlcj8ub3BlbigpO1xuICAgICAgICB9XG4gICAgICAgIGNsZWFyVGltZW91dCh0aGlzLmNsb3NlVGltZW91dCk7XG4gICAgfVxuXG4gICAgY2xvc2VQb3BvdmVyKCkge1xuICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5jbG9zZVRpbWVvdXQpO1xuICAgICAgICB0aGlzLnBvcG92ZXI/LmNsb3NlKCk7XG4gICAgfVxuXG4gICAgbW91c2VMZWF2ZSgpIHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuY2xvc2VUaW1lb3V0KTtcbiAgICAgICAgdGhpcy5jbG9zZVRpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHRoaXMuY2xvc2VQb3BvdmVyKCksIDI1MCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hhbmdlcyB0aGUgdGhlbWUgdG8gdGhlIGN1cnJlbnRseSBub3QgYWN0aXZlIHRoZW1lLlxuICAgICAqL1xuICAgIHRvZ2dsZVRoZW1lKCkge1xuICAgICAgICB0aGlzLmFuaW1hdGUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5vcGVuUG9wdXBBZnRlck5leHRDaGFuZ2UgPSB0cnVlO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHRoaXMudGhlbWVTZXJ2aWNlLmFwcGx5VGhlbWVFeHBsaWNpdGx5KHRoaXMuaXNEYXJrID8gVGhlbWUuTElHSFQgOiBUaGVtZS5EQVJLKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVG9nZ2xlcyB0aGUgc3luY2VkIHdpdGggT1Mgc3RhdGU6XG4gICAgICogLSBpZiBpdCdzIGN1cnJlbnRseSBzeW5jZWQsIHdlIGV4cGxpY2l0bHkgc3RvcmUgdGhlIGN1cnJlbnQgdGhlbWUgYXMgcHJlZmVyZW5jZVxuICAgICAqIC0gaWYgaXQncyBjdXJyZW50bHkgbm90IHN5bmNlZCwgd2UgcmVtb3ZlIHRoZSBwcmVmZXJlbmNlIHRvIGFwcGx5IHRoZSBzeXN0ZW0gdGhlbWVcbiAgICAgKi9cbiAgICB0b2dnbGVTeW5jZWQoKSB7XG4gICAgICAgIHRoaXMudGhlbWVTZXJ2aWNlLmFwcGx5VGhlbWVFeHBsaWNpdGx5KHRoaXMuaXNTeW5jZWQgPyB0aGlzLnRoZW1lU2VydmljZS5nZXRDdXJyZW50VGhlbWUoKSA6IHVuZGVmaW5lZCk7XG4gICAgfVxufVxuIiwiPG5nLXRlbXBsYXRlICNwb3BDb250ZW50PlxuICAgIDxkaXYgY2xhc3M9XCJwb3BvdmVyLWNvbnRlbnRcIiAobW91c2VlbnRlcik9XCJvcGVuUG9wb3ZlcigpXCIgaWQ9XCJ0aGVtZS1zd2l0Y2gtcG9wb3Zlci1jb250ZW50XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJoZWFkXCI+4pi+IDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGhlbWUuZGFya01vZGVcIj5EYXJrIE1vZGU8L3NwYW4+IOKYvjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3dpdGNoLWJveFwiPlxuICAgICAgICAgICAgPGRpdj48ZmEtaWNvbiBbaWNvbl09XCJmYVN5bmNcIj48L2ZhLWljb24+IHt7ICdhcnRlbWlzQXBwLnRoZW1lLnN5bmMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tc3dpdGNoXCI+XG4gICAgICAgICAgICAgICAgPGlucHV0IGNsYXNzPVwiZm9ybS1jaGVjay1pbnB1dFwiIHR5cGU9XCJjaGVja2JveFwiIChjbGljayk9XCJ0b2dnbGVTeW5jZWQoKVwiIFtjaGVja2VkXT1cImlzU3luY2VkXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbjwvbmctdGVtcGxhdGU+XG48ZGl2IChtb3VzZWVudGVyKT1cIm9wZW5Qb3BvdmVyKClcIiAobW91c2VsZWF2ZSk9XCJtb3VzZUxlYXZlKClcIiBjbGFzcz1cIndyYXBwZXJcIj5cbiAgICA8ZGl2XG4gICAgICAgIGNsYXNzPVwidG9nZ2xlLXBvcG92ZXItd3JhcHBlclwiXG4gICAgICAgIChjbGljayk9XCJ0b2dnbGVUaGVtZSgpXCJcbiAgICAgICAgW25nYlBvcG92ZXJdPVwicG9wQ29udGVudFwiXG4gICAgICAgIFt0cmlnZ2Vyc109XCInJ1wiXG4gICAgICAgICNwb3BvdmVyPVwibmdiUG9wb3ZlclwiXG4gICAgICAgIFthdXRvQ2xvc2VdPVwiZmFsc2VcIlxuICAgICAgICBbYW5pbWF0aW9uXT1cImFuaW1hdGVcIlxuICAgICAgICBbcGxhY2VtZW50XT1cInBvcG92ZXJQbGFjZW1lbnRcIlxuICAgID5cbiAgICAgICAgPGRpdiBjbGFzcz1cInRoZW1lLXRvZ2dsZVwiIFtuZ0NsYXNzXT1cInsgZGFyazogaXNEYXJrIH1cIiBpZD1cInRoZW1lLXRvZ2dsZVwiPlxuICAgICAgICAgICAgPHN2ZyBjbGFzcz1cInN1bi1hbmQtbW9vblwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgICAgICAgICAgICA8Y2lyY2xlIGNsYXNzPVwic3VuXCIgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiNlwiIG1hc2s9XCJ1cmwoI21vb24tbWFzaylcIiBmaWxsPVwiY3VycmVudENvbG9yXCIgLz5cbiAgICAgICAgICAgICAgICA8ZyBjbGFzcz1cInN1bi1iZWFtc1wiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiPlxuICAgICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjEyXCIgeTE9XCIxXCIgeDI9XCIxMlwiIHkyPVwiM1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxsaW5lIHgxPVwiMTJcIiB5MT1cIjIxXCIgeDI9XCIxMlwiIHkyPVwiMjNcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjQuMjJcIiB5MT1cIjQuMjJcIiB4Mj1cIjUuNjRcIiB5Mj1cIjUuNjRcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjE4LjM2XCIgeTE9XCIxOC4zNlwiIHgyPVwiMTkuNzhcIiB5Mj1cIjE5Ljc4XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGxpbmUgeDE9XCIxXCIgeTE9XCIxMlwiIHgyPVwiM1wiIHkyPVwiMTJcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjIxXCIgeTE9XCIxMlwiIHgyPVwiMjNcIiB5Mj1cIjEyXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGxpbmUgeDE9XCI0LjIyXCIgeTE9XCIxOS43OFwiIHgyPVwiNS42NFwiIHkyPVwiMTguMzZcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjE4LjM2XCIgeTE9XCI1LjY0XCIgeDI9XCIxOS43OFwiIHkyPVwiNC4yMlwiIC8+XG4gICAgICAgICAgICAgICAgPC9nPlxuICAgICAgICAgICAgICAgIDxtYXNrIGNsYXNzPVwibW9vblwiIGlkPVwibW9vbi1tYXNrXCI+XG4gICAgICAgICAgICAgICAgICAgIDxyZWN0IHg9XCIwXCIgeT1cIjBcIiB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCIgZmlsbD1cIndoaXRlXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjI0XCIgY3k9XCIxMFwiIHI9XCI2XCIgZmlsbD1cImJsYWNrXCIgLz5cbiAgICAgICAgICAgICAgICA8L21hc2s+XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IERpcmVjdGl2ZSwgRWxlbWVudFJlZiwgSW5wdXQsIE9uSW5pdCwgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBMYW5nQ2hhbmdlRXZlbnQsIFRyYW5zbGF0ZVNlcnZpY2UgfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcblxuQERpcmVjdGl2ZSh7XG4gICAgc2VsZWN0b3I6ICdbamhpQWN0aXZlTWVudV0nLFxufSlcbmV4cG9ydCBjbGFzcyBBY3RpdmVNZW51RGlyZWN0aXZlIGltcGxlbWVudHMgT25Jbml0IHtcbiAgICBASW5wdXQoKSBqaGlBY3RpdmVNZW51OiBzdHJpbmc7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBlbGVtZW50OiBFbGVtZW50UmVmLFxuICAgICAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjIsXG4gICAgICAgIHByaXZhdGUgdHJhbnNsYXRlU2VydmljZTogVHJhbnNsYXRlU2VydmljZSxcbiAgICApIHt9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy50cmFuc2xhdGVTZXJ2aWNlLm9uTGFuZ0NoYW5nZS5zdWJzY3JpYmUoKGV2ZW50OiBMYW5nQ2hhbmdlRXZlbnQpID0+IHtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlQWN0aXZlRmxhZyhldmVudC5sYW5nKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMudXBkYXRlQWN0aXZlRmxhZyh0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuY3VycmVudExhbmcpO1xuICAgIH1cblxuICAgIHVwZGF0ZUFjdGl2ZUZsYWcoc2VsZWN0ZWRMYW5ndWFnZTogc3RyaW5nKSB7XG4gICAgICAgIGlmICh0aGlzLmpoaUFjdGl2ZU1lbnUgPT09IHNlbGVjdGVkTGFuZ3VhZ2UpIHtcbiAgICAgICAgICAgIHRoaXMucmVuZGVyZXIuYWRkQ2xhc3ModGhpcy5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICdhY3RpdmUnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMucmVuZGVyZXIucmVtb3ZlQ2xhc3ModGhpcy5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICdhY3RpdmUnKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImltcG9ydCB7IENoYW5nZURldGVjdG9yUmVmLCBDb21wb25lbnQsIE9uRGVzdHJveSwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBVc2VyIH0gZnJvbSAnYXBwL2NvcmUvdXNlci91c2VyLm1vZGVsJztcbmltcG9ydCB7IFVzZXJTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvdXNlci91c2VyLnNlcnZpY2UnO1xuaW1wb3J0IGRheWpzIGZyb20gJ2RheWpzL2VzbSc7XG5pbXBvcnQgeyBHcm91cE5vdGlmaWNhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9ncm91cC1ub3RpZmljYXRpb24ubW9kZWwnO1xuaW1wb3J0IHsgTElWRV9FWEFNX0VYRVJDSVNFX1VQREFURV9OT1RJRklDQVRJT05fVElUTEUsIE5FV19NRVNTQUdFX1RJVExFLCBOb3RpZmljYXRpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvbm90aWZpY2F0aW9uLm1vZGVsJztcbmltcG9ydCB7IEFjY291bnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvYXV0aC9hY2NvdW50LnNlcnZpY2UnO1xuaW1wb3J0IHsgTm90aWZpY2F0aW9uU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL25vdGlmaWNhdGlvbi5zZXJ2aWNlJztcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgZmFBcmNoaXZlLCBmYUJlbGwsIGZhQ2lyY2xlTm90Y2gsIGZhQ29nLCBmYUV5ZSwgZmFUaW1lcyB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBTZXNzaW9uU3RvcmFnZVNlcnZpY2UgfSBmcm9tICduZ3gtd2Vic3RvcmFnZSc7XG5pbXBvcnQgeyBEb2N1bWVudGF0aW9uVHlwZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9kb2N1bWVudGF0aW9uLWJ1dHRvbi9kb2N1bWVudGF0aW9uLWJ1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgdHJhbnNsYXRpb25Ob3RGb3VuZE1lc3NhZ2UgfSBmcm9tICdhcHAvY29yZS9jb25maWcvdHJhbnNsYXRpb24uY29uZmlnJztcbmltcG9ydCB7IEFydGVtaXNUcmFuc2xhdGVQaXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9waXBlcy9hcnRlbWlzLXRyYW5zbGF0ZS5waXBlJztcblxuZXhwb3J0IGNvbnN0IExBU1RfUkVBRF9TVE9SQUdFX0tFWSA9ICdsYXN0Tm90aWZpY2F0aW9uUmVhZCc7XG5jb25zdCBJUlJFTEVWQU5UX05PVElGSUNBVElPTl9USVRMRVMgPSBbTkVXX01FU1NBR0VfVElUTEUsIExJVkVfRVhBTV9FWEVSQ0lTRV9VUERBVEVfTk9USUZJQ0FUSU9OX1RJVExFXTtcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbm90aWZpY2F0aW9uLXNpZGViYXInLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9ub3RpZmljYXRpb24tc2lkZWJhci5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vbm90aWZpY2F0aW9uLXNpZGViYXIuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBOb3RpZmljYXRpb25TaWRlYmFyQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xuICAgIC8vIEhUTUwgdGVtcGxhdGUgcmVsYXRlZFxuICAgIHNob3dTaWRlYmFyID0gZmFsc2U7XG4gICAgc2hvd0J1dHRvblRvSGlkZUN1cnJlbnRseURpc3BsYXllZE5vdGlmaWNhdGlvbnMgPSB0cnVlO1xuXG4gICAgLy8gbm90aWZpY2F0aW9uIGxvZ2ljIHJlbGF0ZWRcbiAgICBzb3J0ZWROb3RpZmljYXRpb25zOiBOb3RpZmljYXRpb25bXSA9IFtdO1xuICAgIHJlY2VudE5vdGlmaWNhdGlvbkNvdW50ID0gMDtcbiAgICBsYXN0Tm90aWZpY2F0aW9uUmVhZD86IGRheWpzLkRheWpzO1xuICAgIG1heE5vdGlmaWNhdGlvbkxlbmd0aCA9IDMwMDtcbiAgICBlcnJvcj86IHN0cmluZztcbiAgICBsb2FkaW5nID0gZmFsc2U7XG4gICAgdG90YWxOb3RpZmljYXRpb25zID0gMDtcblxuICAgIHJlYWRvbmx5IGRvY3VtZW50YXRpb25UeXBlOiBEb2N1bWVudGF0aW9uVHlwZSA9ICdOb3RpZmljYXRpb25zJztcblxuICAgIHN1YnNjcmlwdGlvbnM6IFN1YnNjcmlwdGlvbltdID0gW107XG5cbiAgICAvLyBJY29uc1xuICAgIGZhVGltZXMgPSBmYVRpbWVzO1xuICAgIGZhQ2lyY2xlTm90Y2ggPSBmYUNpcmNsZU5vdGNoO1xuICAgIGZhQmVsbCA9IGZhQmVsbDtcbiAgICBmYUNvZyA9IGZhQ29nO1xuICAgIGZhQXJjaGl2ZSA9IGZhQXJjaGl2ZTtcbiAgICBmYUV5ZSA9IGZhRXllO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgbm90aWZpY2F0aW9uU2VydmljZTogTm90aWZpY2F0aW9uU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSB1c2VyU2VydmljZTogVXNlclNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgYWNjb3VudFNlcnZpY2U6IEFjY291bnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHNlc3Npb25TdG9yYWdlU2VydmljZTogU2Vzc2lvblN0b3JhZ2VTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGNoYW5nZURldGVjdG9yOiBDaGFuZ2VEZXRlY3RvclJlZixcbiAgICAgICAgcHJpdmF0ZSBhcnRlbWlzVHJhbnNsYXRlUGlwZTogQXJ0ZW1pc1RyYW5zbGF0ZVBpcGUsXG4gICAgKSB7fVxuXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgICAgIHRoaXMuc3Vic2NyaXB0aW9ucy5mb3JFYWNoKChzdWJzY3JpcHRpb24pID0+IHN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBMb2FkIG5vdGlmaWNhdGlvbnMgd2hlbiB1c2VyIGlzIGF1dGhlbnRpY2F0ZWQgb24gY29tcG9uZW50IGluaXRpYWxpemF0aW9uLlxuICAgICAqL1xuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICB0aGlzLmFjY291bnRTZXJ2aWNlLmdldEF1dGhlbnRpY2F0aW9uU3RhdGUoKS5zdWJzY3JpYmUoKHVzZXI6IFVzZXIgfCB1bmRlZmluZWQpID0+IHtcbiAgICAgICAgICAgIGlmICh1c2VyKSB7XG4gICAgICAgICAgICAgICAgLy8gQ2hlY2sgaWYgd2UgaGF2ZSBhIG5ld2VyIG5vdGlmaWNhdGlvbiByZWFkIGRhdGUgaW4gc2Vzc2lvbiBzdG9yYWdlIHRvIHByZXZlbnQgbWFya2luZyBvbGQgbm90aWZpY2F0aW9ucyBhcyBuZXcgb24gYSByZXJlbmRlclxuICAgICAgICAgICAgICAgIC8vIElmIHdlIGhhdmUgaXQsIHVzZSB0aGUgbGF0ZXN0IG9mIGJvdGggZGF0ZXNcblxuICAgICAgICAgICAgICAgIGNvbnN0IHNlc3Npb25MYXN0Tm90aWZpY2F0aW9uUmVhZFJhdyA9IHRoaXMuc2Vzc2lvblN0b3JhZ2VTZXJ2aWNlLnJldHJpZXZlKExBU1RfUkVBRF9TVE9SQUdFX0tFWSk7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2Vzc2lvbkxhc3ROb3RpZmljYXRpb25SZWFkRGF5SnMgPSBzZXNzaW9uTGFzdE5vdGlmaWNhdGlvblJlYWRSYXcgPyBkYXlqcyhzZXNzaW9uTGFzdE5vdGlmaWNhdGlvblJlYWRSYXcpIDogdW5kZWZpbmVkO1xuXG4gICAgICAgICAgICAgICAgaWYgKHVzZXIubGFzdE5vdGlmaWNhdGlvblJlYWQgJiYgIXNlc3Npb25MYXN0Tm90aWZpY2F0aW9uUmVhZERheUpzKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGFzdE5vdGlmaWNhdGlvblJlYWQgPSB1c2VyLmxhc3ROb3RpZmljYXRpb25SZWFkO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoIXVzZXIubGFzdE5vdGlmaWNhdGlvblJlYWQgJiYgc2Vzc2lvbkxhc3ROb3RpZmljYXRpb25SZWFkRGF5SnMpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sYXN0Tm90aWZpY2F0aW9uUmVhZCA9IHNlc3Npb25MYXN0Tm90aWZpY2F0aW9uUmVhZERheUpzO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodXNlci5sYXN0Tm90aWZpY2F0aW9uUmVhZCAmJiBzZXNzaW9uTGFzdE5vdGlmaWNhdGlvblJlYWREYXlKcykge1xuICAgICAgICAgICAgICAgICAgICBpZiAoc2Vzc2lvbkxhc3ROb3RpZmljYXRpb25SZWFkRGF5SnMuaXNCZWZvcmUodXNlci5sYXN0Tm90aWZpY2F0aW9uUmVhZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubGFzdE5vdGlmaWNhdGlvblJlYWQgPSB1c2VyLmxhc3ROb3RpZmljYXRpb25SZWFkO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sYXN0Tm90aWZpY2F0aW9uUmVhZCA9IHNlc3Npb25MYXN0Tm90aWZpY2F0aW9uUmVhZERheUpzO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdGhpcy5zdWJzY3JpYmVUb05vdGlmaWNhdGlvblVwZGF0ZXMoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU3RvcmFnZVNlcnZpY2UuY2xlYXIoTEFTVF9SRUFEX1NUT1JBR0VfS0VZKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gSFRNTCB0ZW1wbGF0ZSByZWxhdGVkIG1ldGhvZHNcblxuICAgIC8qKlxuICAgICAqIFdpbGwgYmUgZXhlY3V0ZWQgd2hlbiBhIG5vdGlmaWNhdGlvbiB3YXMgY2xpY2tlZC4gVGhlIG5vdGlmaWNhdGlvbiBzaWRlYmFyIHdpbGwgYmUgY2xvc2VkIGFuZCB0aGUgYWN0dWFsIGludGVycHJldGF0aW9uXG4gICAgICogb2Ygd2hhdCBzaG91bGQgaGFwcGVuIGFmdGVyIHRoZSBub3RpZmljYXRpb24gd2FzIGNsaWNrZWQgd2lsbCBiZSBoYW5kbGVkIGluIHRoZSBub3RpZmljYXRpb24gc2VydmljZS5cbiAgICAgKiBAcGFyYW0gbm90aWZpY2F0aW9uIHRoYXQgd2lsbCBiZSBpbnRlcnByZXRlZCBvZiB0eXBlIHtOb3RpZmljYXRpb259XG4gICAgICovXG4gICAgc3RhcnROb3RpZmljYXRpb24obm90aWZpY2F0aW9uOiBOb3RpZmljYXRpb24pOiB2b2lkIHtcbiAgICAgICAgdGhpcy5zaG93U2lkZWJhciA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5vdGlmaWNhdGlvblNlcnZpY2UuaW50ZXJwcmV0Tm90aWZpY2F0aW9uKG5vdGlmaWNhdGlvbiBhcyBHcm91cE5vdGlmaWNhdGlvbik7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgc2Nyb2xsIHBvc2l0aW9uIGFuZCBsb2FkIG1vcmUgbm90aWZpY2F0aW9ucyBpZiB0aGUgdXNlciBzY3JvbGxlZCB0byB0aGUgZW5kLlxuICAgICAqL1xuICAgIG9uU2Nyb2xsKCk6IHZvaWQge1xuICAgICAgICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbm90aWZpY2F0aW9uLXNpZGViYXItY29udGFpbmVyJyk7XG4gICAgICAgIGNvbnN0IHRocmVzaG9sZCA9IDM1MDtcbiAgICAgICAgaWYgKGNvbnRhaW5lcikge1xuICAgICAgICAgICAgY29uc3QgaGVpZ2h0ID0gY29udGFpbmVyLnNjcm9sbEhlaWdodCAtIGNvbnRhaW5lci5vZmZzZXRIZWlnaHQ7XG4gICAgICAgICAgICBpZiAoaGVpZ2h0ID4gdGhyZXNob2xkICYmIGNvbnRhaW5lci5zY3JvbGxUb3AgPiBoZWlnaHQgLSB0aHJlc2hvbGQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm5vdGlmaWNhdGlvblNlcnZpY2UuaW5jcmVtZW50UGFnZUFuZExvYWQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNob3cgdGhlIHNpZGViYXIgd2hlbiBpdCBpcyBub3QgdmlzaWJsZSBhbmQgaGlkZSB0aGUgc2lkZWJhciB3aGVuIGl0IGlzIHZpc2libGUuXG4gICAgICovXG4gICAgdG9nZ2xlU2lkZWJhcigpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5zaG93U2lkZWJhciA9ICF0aGlzLnNob3dTaWRlYmFyO1xuICAgIH1cblxuICAgIC8vIG5vdGlmaWNhdGlvbiBsb2dpYyByZWxhdGVkIG1ldGhvZHNcblxuICAgIC8qKlxuICAgICAqIFN0YXJ0cyB0aGUgcHJvY2VzcyB0byBzaG93IG9yIGhpZGUgYWxsIG5vdGlmaWNhdGlvbnMgaW4gdGhlIHNpZGViYXJcbiAgICAgKi9cbiAgICB0b2dnbGVOb3RpZmljYXRpb25EaXNwbGF5KCk6IHZvaWQge1xuICAgICAgICB0aGlzLnNob3dCdXR0b25Ub0hpZGVDdXJyZW50bHlEaXNwbGF5ZWROb3RpZmljYXRpb25zID0gIXRoaXMuc2hvd0J1dHRvblRvSGlkZUN1cnJlbnRseURpc3BsYXllZE5vdGlmaWNhdGlvbnM7XG4gICAgICAgIHRoaXMudXNlclNlcnZpY2UudXBkYXRlTm90aWZpY2F0aW9uVmlzaWJpbGl0eSh0aGlzLnNob3dCdXR0b25Ub0hpZGVDdXJyZW50bHlEaXNwbGF5ZWROb3RpZmljYXRpb25zKS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5ub3RpZmljYXRpb25TZXJ2aWNlLnJlc2V0QW5kTG9hZCgpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVcGRhdGUgdGhlIHVzZXIncyBsYXN0Tm90aWZpY2F0aW9uUmVhZCBzZXR0aW5nLiBBcyB0aGlzIG1ldGhvZCB3aWxsIGJlIGV4ZWN1dGVkIHdoZW4gdGhlIHVzZXIgb3BlbnMgdGhlIHNpZGViYXIsIHRoZVxuICAgICAqIGNvbXBvbmVudCdzIGxhc3ROb3RpZmljYXRpb25SZWFkIGF0dHJpYnV0ZSB3aWxsIGJlIHVwZGF0ZWQgb25seSBhZnRlciB0d28gc2Vjb25kcyBzbyB0aGF0IHRoZSBub3RpZmljYXRpb24gYG5ld2AgYmFkZ2VzXG4gICAgICogd29uJ3QgZGlzYXBwZWFyIGltbWVkaWF0ZWx5LlxuICAgICAqL1xuICAgIHVwZGF0ZUxhc3ROb3RpZmljYXRpb25SZWFkKCk6IHZvaWQge1xuICAgICAgICB0aGlzLnVzZXJTZXJ2aWNlLnVwZGF0ZUxhc3ROb3RpZmljYXRpb25SZWFkKCkuc3Vic2NyaWJlKCgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGxhc3ROb3RpZmljYXRpb25SZWFkTm93ID0gZGF5anMoKTtcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMubGFzdE5vdGlmaWNhdGlvblJlYWQgPSBsYXN0Tm90aWZpY2F0aW9uUmVhZE5vdztcbiAgICAgICAgICAgICAgICB0aGlzLnNlc3Npb25TdG9yYWdlU2VydmljZS5zdG9yZShMQVNUX1JFQURfU1RPUkFHRV9LRVksIGxhc3ROb3RpZmljYXRpb25SZWFkTm93KTtcbiAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZVJlY2VudE5vdGlmaWNhdGlvbkNvdW50KCk7XG4gICAgICAgICAgICB9LCAyMDAwKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgdHJhbnNsYXRlZCB0ZXh0IGZvciB0aGUgcGxhY2Vob2xkZXIgb2YgdGhlIG5vdGlmaWNhdGlvbiB0ZXh0IG9mIHRoZSBwcm92aWRlZCBub3RpZmljYXRpb24uXG4gICAgICogSWYgdGhlIG5vdGlmaWNhdGlvbiBpcyBhIGxlZ2FjeSBub3RpZmljYXRpb24gYW5kIHRoZXJlZm9yIHRoZSB0ZXh0IGlzIG5vdCBhIHBsYWNlaG9sZGVyXG4gICAgICogaXQganVzdCByZXR1cm5zIHRoZSBwcm92aWRlZCB0ZXh0IGZvciB0aGUgbm90aWZpY2F0aW9uIHRleHRcbiAgICAgKiBAcGFyYW0gbm90aWZpY2F0aW9uIHtOb3RpZmljYXRpb259XG4gICAgICovXG4gICAgZ2V0Tm90aWZpY2F0aW9uVGl0bGVUcmFuc2xhdGlvbihub3RpZmljYXRpb246IE5vdGlmaWNhdGlvbik6IHN0cmluZyB7XG4gICAgICAgIGNvbnN0IHRyYW5zbGF0aW9uID0gdGhpcy5hcnRlbWlzVHJhbnNsYXRlUGlwZS50cmFuc2Zvcm0obm90aWZpY2F0aW9uLnRpdGxlKTtcbiAgICAgICAgaWYgKHRyYW5zbGF0aW9uPy5pbmNsdWRlcyh0cmFuc2xhdGlvbk5vdEZvdW5kTWVzc2FnZSkpIHtcbiAgICAgICAgICAgIHJldHVybiBub3RpZmljYXRpb24udGl0bGUgPz8gJ05vIHRpdGxlIGZvdW5kJztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJhbnNsYXRpb247XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgdHJhbnNsYXRlZCB0ZXh0IGZvciB0aGUgcGxhY2Vob2xkZXIgb2YgdGhlIG5vdGlmaWNhdGlvbiB0ZXh0IG9mIHRoZSBwcm92aWRlZCBub3RpZmljYXRpb24uXG4gICAgICogSWYgdGhlIG5vdGlmaWNhdGlvbiBpcyBhIGxlZ2FjeSBub3RpZmljYXRpb24gYW5kIHRoZXJlZm9yIHRoZSB0ZXh0IGlzIG5vdCBhIHBsYWNlaG9sZGVyXG4gICAgICogaXQganVzdCByZXR1cm5zIHRoZSBwcm92aWRlZCB0ZXh0IGZvciB0aGUgbm90aWZpY2F0aW9uIHRleHRcbiAgICAgKiBAcGFyYW0gbm90aWZpY2F0aW9uIHtOb3RpZmljYXRpb259XG4gICAgICovXG4gICAgZ2V0Tm90aWZpY2F0aW9uVGV4dFRyYW5zbGF0aW9uKG5vdGlmaWNhdGlvbjogTm90aWZpY2F0aW9uKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMubm90aWZpY2F0aW9uU2VydmljZS5nZXROb3RpZmljYXRpb25UZXh0VHJhbnNsYXRpb24obm90aWZpY2F0aW9uLCB0aGlzLm1heE5vdGlmaWNhdGlvbkxlbmd0aCk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBnZXRQYXJzZWRQbGFjZWhvbGRlclZhbHVlcyhub3RpZmljYXRpb246IE5vdGlmaWNhdGlvbik6IHN0cmluZ1tdIHtcbiAgICAgICAgaWYgKG5vdGlmaWNhdGlvbi5wbGFjZWhvbGRlclZhbHVlcykge1xuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2Uobm90aWZpY2F0aW9uLnBsYWNlaG9sZGVyVmFsdWVzKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gW107XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzdWJzY3JpYmVUb05vdGlmaWNhdGlvblVwZGF0ZXMoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuc3Vic2NyaXB0aW9ucy5wdXNoKFxuICAgICAgICAgICAgdGhpcy5ub3RpZmljYXRpb25TZXJ2aWNlLnN1YnNjcmliZVRvTm90aWZpY2F0aW9uVXBkYXRlcygpLnN1YnNjcmliZSgobm90aWZpY2F0aW9uczogTm90aWZpY2F0aW9uW10pID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBmaWx0ZXJlZE5vdGlmaWNhdGlvbnMgPSB0aGlzLmZpbHRlckxvYWRlZE5vdGlmaWNhdGlvbnMobm90aWZpY2F0aW9ucyk7XG4gICAgICAgICAgICAgICAgdGhpcy51cGRhdGVTb3J0ZWROb3RpZmljYXRpb25zKGZpbHRlcmVkTm90aWZpY2F0aW9ucyk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5zdWJzY3JpcHRpb25zLnB1c2godGhpcy5ub3RpZmljYXRpb25TZXJ2aWNlLnN1YnNjcmliZVRvVG90YWxOb3RpZmljYXRpb25Db3VudFVwZGF0ZXMoKS5zdWJzY3JpYmUoKGNvdW50OiBudW1iZXIpID0+ICh0aGlzLnRvdGFsTm90aWZpY2F0aW9ucyA9IGNvdW50KSkpO1xuICAgICAgICB0aGlzLnN1YnNjcmlwdGlvbnMucHVzaCh0aGlzLm5vdGlmaWNhdGlvblNlcnZpY2Uuc3Vic2NyaWJlVG9Mb2FkaW5nU3RhdGVVcGRhdGVzKCkuc3Vic2NyaWJlKChsb2FkaW5nOiBib29sZWFuKSA9PiAodGhpcy5sb2FkaW5nID0gbG9hZGluZykpKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGZpbHRlckxvYWRlZE5vdGlmaWNhdGlvbnMobm90aWZpY2F0aW9uczogTm90aWZpY2F0aW9uW10pOiBOb3RpZmljYXRpb25bXSB7XG4gICAgICAgIHJldHVybiBub3RpZmljYXRpb25zLmZpbHRlcigobm90aWZpY2F0aW9uKSA9PiBub3RpZmljYXRpb24udGl0bGUgJiYgIUlSUkVMRVZBTlRfTk9USUZJQ0FUSU9OX1RJVExFUy5pbmNsdWRlcyhub3RpZmljYXRpb24udGl0bGUpKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHVwZGF0ZVNvcnRlZE5vdGlmaWNhdGlvbnMobm90aWZpY2F0aW9uczogTm90aWZpY2F0aW9uW10pOiB2b2lkIHtcbiAgICAgICAgdGhpcy5zb3J0ZWROb3RpZmljYXRpb25zID0gbm90aWZpY2F0aW9ucy5zb3J0KChhOiBOb3RpZmljYXRpb24sIGI6IE5vdGlmaWNhdGlvbikgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIGRheWpzKGIubm90aWZpY2F0aW9uRGF0ZSEpLnZhbHVlT2YoKSAtIGRheWpzKGEubm90aWZpY2F0aW9uRGF0ZSEpLnZhbHVlT2YoKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMudXBkYXRlUmVjZW50Tm90aWZpY2F0aW9uQ291bnQoKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHVwZGF0ZVJlY2VudE5vdGlmaWNhdGlvbkNvdW50KCk6IHZvaWQge1xuICAgICAgICBpZiAoIXRoaXMuc29ydGVkTm90aWZpY2F0aW9ucykge1xuICAgICAgICAgICAgdGhpcy5yZWNlbnROb3RpZmljYXRpb25Db3VudCA9IDA7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5sYXN0Tm90aWZpY2F0aW9uUmVhZCkge1xuICAgICAgICAgICAgdGhpcy5yZWNlbnROb3RpZmljYXRpb25Db3VudCA9IHRoaXMuc29ydGVkTm90aWZpY2F0aW9ucy5maWx0ZXIoKG5vdGlmaWNhdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiBub3RpZmljYXRpb24ubm90aWZpY2F0aW9uRGF0ZSAmJiBub3RpZmljYXRpb24ubm90aWZpY2F0aW9uRGF0ZS5pc0FmdGVyKHRoaXMubGFzdE5vdGlmaWNhdGlvblJlYWQhKTtcbiAgICAgICAgICAgIH0pLmxlbmd0aDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMucmVjZW50Tm90aWZpY2F0aW9uQ291bnQgPSB0aGlzLnNvcnRlZE5vdGlmaWNhdGlvbnMubGVuZ3RoO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCF0aGlzLnNvcnRlZE5vdGlmaWNhdGlvbnMgfHwgdGhpcy5zb3J0ZWROb3RpZmljYXRpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgLy8gaWYgbm8gbm90aWZpY2F0aW9ucyBhcmUgY3VycmVudGx5IGxvYWRlZCBzaG93IHRoZSBidXR0b24gdG8gZGlzcGxheSBhbGwgc2F2ZWQvYXJjaGl2ZWQgb25lc1xuICAgICAgICAgICAgdGhpcy5zaG93QnV0dG9uVG9IaWRlQ3VycmVudGx5RGlzcGxheWVkTm90aWZpY2F0aW9ucyA9IGZhbHNlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gc29tZSBub3RpZmljYXRpb25zIGFyZSBjdXJyZW50bHkgbG9hZGVkLCB0aHVzIHNob3cgdGhlIGJ1dHRvbiB0byBoaWRlIGN1cnJlbnRseSBkaXNwbGF5ZWQgb25lc1xuICAgICAgICAgICAgdGhpcy5zaG93QnV0dG9uVG9IaWRlQ3VycmVudGx5RGlzcGxheWVkTm90aWZpY2F0aW9ucyA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jaGFuZ2VEZXRlY3Rvci5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInBvaW50ZXJcIj5cbiAgICA8YnV0dG9uIGNsYXNzPVwiZ3VpZGVkLXRvdXItbm90aWZpY2F0aW9uIG5vdGlmaWNhdGlvbi1idXR0b24gbGlnaHQtYnV0dG9uXCIgKGNsaWNrKT1cInRvZ2dsZVNpZGViYXIoKTsgdXBkYXRlTGFzdE5vdGlmaWNhdGlvblJlYWQoKVwiPlxuICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUJlbGxcIj48L2ZhLWljb24+XG4gICAgICAgIEBpZiAocmVjZW50Tm90aWZpY2F0aW9uQ291bnQgPiAwKSB7XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLWRhbmdlciByb3VuZGVkLXBpbGxcIj5cbiAgICAgICAgICAgICAgICB7eyByZWNlbnROb3RpZmljYXRpb25Db3VudCB9fVxuICAgICAgICAgICAgICAgIEBpZiAocmVjZW50Tm90aWZpY2F0aW9uQ291bnQgPj0gc29ydGVkTm90aWZpY2F0aW9ucy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+Kzwvc3Bhbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIH1cbiAgICA8L2J1dHRvbj5cbjwvZGl2PlxuPGRpdiBjbGFzcz1cIm5vdGlmaWNhdGlvbi1vdmVybGF5XCIgKGNsaWNrKT1cInRvZ2dsZVNpZGViYXIoKVwiIFtuZ0NsYXNzXT1cInNob3dTaWRlYmFyID8gJ3Nob3cnIDogJ2hpZGUnXCI+PC9kaXY+XG48ZGl2IGNsYXNzPVwibm90aWZpY2F0aW9uLXNpZGViYXJcIiBbbmdDbGFzc109XCJzaG93U2lkZWJhciA/ICdzaG93JyA6ICdoaWRlJ1wiIGlkPVwibm90aWZpY2F0aW9uLXNpZGViYXJcIj5cbiAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGZsZXgtY29sdW1uXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJoZWFkZXIgcHQtNCBweC0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGhlYWRlci1pY29uIGp1c3RpZnktY29udGVudC1iZXR3ZWVuIGFsaWduLWl0ZW1zLWJhc2VsaW5lXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleFwiPlxuICAgICAgICAgICAgICAgICAgICA8amhpLWRvY3VtZW50YXRpb24tYnV0dG9uIFt0eXBlXT1cImRvY3VtZW50YXRpb25UeXBlXCI+PC9qaGktZG9jdW1lbnRhdGlvbi1idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwicHMtMlwiIFtyb3V0ZXJMaW5rXT1cIlsnL3VzZXItc2V0dGluZ3Mvbm90aWZpY2F0aW9ucyddXCIgKGNsaWNrKT1cInRvZ2dsZVNpZGViYXIoKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gY2xhc3M9XCJuZy1mYS1pY29uXCIgW2ljb25dPVwiZmFDb2dcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aDUgY2xhc3M9XCJtYi0zIHRleHQtY2VudGVyIGZ3LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5ub3RpZmljYXRpb24ubm90aWZpY2F0aW9ucycgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgPC9oNT5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiY2xvc2UgaGVhZGVyLWljb24gYm9yZGVyLTAgYmctdHJhbnNwYXJlbnQgcGUtMlwiIChjbGljayk9XCJ0b2dnbGVTaWRlYmFyKClcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gY2xhc3M9XCJuZy1mYS1pY29uXCIgW2ljb25dPVwiZmFUaW1lc1wiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtZW5kXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImhpZGUtdW50aWwtdG9nZ2xlXCIgY2xhc3M9XCJib3JkZXItMCBiZy10cmFuc3BhcmVudCBwZS0yXCIgKGNsaWNrKT1cInRvZ2dsZU5vdGlmaWNhdGlvbkRpc3BsYXkoKVwiPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKHNob3dCdXR0b25Ub0hpZGVDdXJyZW50bHlEaXNwbGF5ZWROb3RpZmljYXRpb25zKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBjbGFzcz1cIm5nLWZhLWljb25cIiBbaWNvbl09XCJmYUFyY2hpdmVcIiBbbmdiVG9vbHRpcF09XCInYXJ0ZW1pc0FwcC5ub3RpZmljYXRpb24uaGlkZUFsbEN1cnJlbnRseURpc3BsYXllZE5vdGlmaWNhdGlvbnMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIGNsYXNzPVwibmctZmEtaWNvblwiIFtpY29uXT1cImZhRXllXCIgW25nYlRvb2x0aXBdPVwiJ2FydGVtaXNBcHAubm90aWZpY2F0aW9uLnNob3dBbGxTYXZlZE5vdGlmaWNhdGlvbnMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiPiA8L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8c21hbGwgY2xhc3M9XCJ0ZXh0LWJvZHktc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLm5vdGlmaWNhdGlvbi5sb2FkZWROb3RpZmljYXRpb25Db3VudCcgfCBhcnRlbWlzVHJhbnNsYXRlOiB7IGxvYWRlZDogc29ydGVkTm90aWZpY2F0aW9ucz8ubGVuZ3RoIHx8ICcwJywgdG90YWw6IHRvdGFsTm90aWZpY2F0aW9ucyB9IH19XG4gICAgICAgICAgICAgICAgPC9zbWFsbD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBpZD1cIm5vdGlmaWNhdGlvbi1zaWRlYmFyLWNvbnRhaW5lclwiIChzY3JvbGwpPVwib25TY3JvbGwoKVwiPlxuICAgICAgICAgICAgQGlmIChlcnJvcikge1xuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhbGVydCBhbGVydC1kYW5nZXIgbXgtM1wiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5ub3RpZmljYXRpb24udW5leHBlY3RlZEVycm9yJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBmb3IgKG5vdGlmaWNhdGlvbiBvZiBzb3J0ZWROb3RpZmljYXRpb25zOyB0cmFjayBub3RpZmljYXRpb24pIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibm90aWZpY2F0aW9uLWl0ZW0gcC0zXCIgKGNsaWNrKT1cInN0YXJ0Tm90aWZpY2F0aW9uKG5vdGlmaWNhdGlvbilcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzcz1cIm5vdGlmaWNhdGlvbi10aXRsZSBmdy1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBnZXROb3RpZmljYXRpb25UaXRsZVRyYW5zbGF0aW9uKG5vdGlmaWNhdGlvbikgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGxhc3ROb3RpZmljYXRpb25SZWFkICYmIG5vdGlmaWNhdGlvbi5ub3RpZmljYXRpb25EYXRlPy5pc0FmdGVyKGxhc3ROb3RpZmljYXRpb25SZWFkKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIG1zLTEgYmctcHJpbWFyeVwiPiBuZXcgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibm90aWZpY2F0aW9uLXRleHQgbWItMSB0ZXh0LWJyZWFrXCIgW2lubmVySFRNTF09XCJnZXROb3RpZmljYXRpb25UZXh0VHJhbnNsYXRpb24obm90aWZpY2F0aW9uKVwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8gdGV4dC1ib2R5LXNlY29uZGFyeSB0ZXh0LWVuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IG5vdGlmaWNhdGlvbi5ub3RpZmljYXRpb25EYXRlPy50b0RhdGUoKSB8IGRhdGU6ICdkZC5NTS55eSBISDptbScgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5ub3RpZmljYXRpb24uYnknIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAobm90aWZpY2F0aW9uLmF1dGhvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyBub3RpZmljYXRpb24uYXV0aG9yLm5hbWUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC50aXRsZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKGxvYWRpbmcpIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibG9hZGluZy1zcGlubmVyIHRleHQtY2VudGVyIG14LTMgbXktMlwiIHN0eWxlPVwiZm9udC1zaXplOiBsYXJnZVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUNpcmNsZU5vdGNoXCIgW3NwaW5dPVwidHJ1ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAoc29ydGVkTm90aWZpY2F0aW9ucy5sZW5ndGggPiAwICYmIHNvcnRlZE5vdGlmaWNhdGlvbnMubGVuZ3RoID49IHRvdGFsTm90aWZpY2F0aW9ucykge1xuICAgICAgICAgICAgICAgIDxzbWFsbCBjbGFzcz1cImFsbC1sb2FkZWQgdGV4dC1jZW50ZXIgZC1ibG9jayBteC0zIG15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAubm90aWZpY2F0aW9uLmFsbExvYWRlZCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgPC9zbWFsbD5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAoc29ydGVkTm90aWZpY2F0aW9ucyAmJiBzb3J0ZWROb3RpZmljYXRpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibm8tbm90aWZpY2F0aW9uc1wiPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5ub3RpZmljYXRpb24ubm9Ob3RpZmljYXRpb25zJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uRGVzdHJveSwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgZGF5anMgZnJvbSAnZGF5anMvZXNtJztcbmltcG9ydCB7IFN5c3RlbU5vdGlmaWNhdGlvbiwgU3lzdGVtTm90aWZpY2F0aW9uVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9zeXN0ZW0tbm90aWZpY2F0aW9uLm1vZGVsJztcbmltcG9ydCB7IEFjY291bnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvYXV0aC9hY2NvdW50LnNlcnZpY2UnO1xuaW1wb3J0IHsgSmhpV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3dlYnNvY2tldC93ZWJzb2NrZXQuc2VydmljZSc7XG5pbXBvcnQgeyBVc2VyIH0gZnJvbSAnYXBwL2NvcmUvdXNlci91c2VyLm1vZGVsJztcbmltcG9ydCB7IFN5c3RlbU5vdGlmaWNhdGlvblNlcnZpY2UgfSBmcm9tICdhcHAvc2hhcmVkL25vdGlmaWNhdGlvbi9zeXN0ZW0tbm90aWZpY2F0aW9uL3N5c3RlbS1ub3RpZmljYXRpb24uc2VydmljZSc7XG5pbXBvcnQgeyBmYUV4Y2xhbWF0aW9uVHJpYW5nbGUsIGZhSW5mb0NpcmNsZSwgZmFUaW1lcyB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24sIGZpbHRlciB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgY29udmVydERhdGVGcm9tU2VydmVyIH0gZnJvbSAnYXBwL3V0aWxzL2RhdGUudXRpbHMnO1xuXG5leHBvcnQgY29uc3QgV0VCU09DS0VUX0NIQU5ORUwgPSAnL3RvcGljL3N5c3RlbS1ub3RpZmljYXRpb24nO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1zeXN0ZW0tbm90aWZpY2F0aW9uJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vc3lzdGVtLW5vdGlmaWNhdGlvbi5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJ3N5c3RlbS1ub3RpZmljYXRpb24uc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBTeXN0ZW1Ob3RpZmljYXRpb25Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gICAgcmVhZG9ubHkgSU5GTyA9IFN5c3RlbU5vdGlmaWNhdGlvblR5cGUuSU5GTztcbiAgICByZWFkb25seSBXQVJOSU5HID0gU3lzdGVtTm90aWZpY2F0aW9uVHlwZS5XQVJOSU5HO1xuXG4gICAgbm90aWZpY2F0aW9uczogU3lzdGVtTm90aWZpY2F0aW9uW10gPSBbXTtcbiAgICBub3RpZmljYXRpb25zVG9EaXNwbGF5OiBTeXN0ZW1Ob3RpZmljYXRpb25bXSA9IFtdO1xuICAgIGNsb3NlZElkczogbnVtYmVyW10gPSBbXTtcbiAgICB3ZWJzb2NrZXRTdGF0dXNTdWJzY3JpcHRpb24/OiBTdWJzY3JpcHRpb247XG5cbiAgICBuZXh0VXBkYXRlRnV0dXJlPzogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD47XG5cbiAgICAvLyBJY29uc1xuICAgIGZhRXhjbGFtYXRpb25UcmlhbmdsZSA9IGZhRXhjbGFtYXRpb25UcmlhbmdsZTtcbiAgICBmYUluZm9DaXJjbGUgPSBmYUluZm9DaXJjbGU7XG4gICAgZmFUaW1lcyA9IGZhVGltZXM7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSByb3V0ZTogQWN0aXZhdGVkUm91dGUsXG4gICAgICAgIHByaXZhdGUgYWNjb3VudFNlcnZpY2U6IEFjY291bnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGpoaVdlYnNvY2tldFNlcnZpY2U6IEpoaVdlYnNvY2tldFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgc3lzdGVtTm90aWZpY2F0aW9uU2VydmljZTogU3lzdGVtTm90aWZpY2F0aW9uU2VydmljZSxcbiAgICApIHt9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5sb2FkQWN0aXZlTm90aWZpY2F0aW9uKCk7XG4gICAgICAgIHRoaXMuYWNjb3VudFNlcnZpY2UuZ2V0QXV0aGVudGljYXRpb25TdGF0ZSgpLnN1YnNjcmliZSgodXNlcjogVXNlciB8IHVuZGVmaW5lZCkgPT4ge1xuICAgICAgICAgICAgaWYgKHVzZXIpIHtcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy53ZWJzb2NrZXRTdGF0dXNTdWJzY3JpcHRpb24gPSB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2UuY29ubmVjdGlvblN0YXRlLnBpcGUoZmlsdGVyKChzdGF0dXMpID0+IHN0YXR1cy5jb25uZWN0ZWQpKS5zdWJzY3JpYmUoKCkgPT4gdGhpcy5zdWJzY3JpYmVTb2NrZXQoKSk7XG4gICAgICAgICAgICAgICAgfSwgNTAwKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy53ZWJzb2NrZXRTdGF0dXNTdWJzY3JpcHRpb24/LnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLndlYnNvY2tldFN0YXR1c1N1YnNjcmlwdGlvbj8udW5zdWJzY3JpYmUoKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGxvYWRBY3RpdmVOb3RpZmljYXRpb24oKSB7XG4gICAgICAgIHRoaXMuc3lzdGVtTm90aWZpY2F0aW9uU2VydmljZS5nZXRBY3RpdmVOb3RpZmljYXRpb25zKCkuc3Vic2NyaWJlKChub3RpZmljYXRpb25zOiBTeXN0ZW1Ob3RpZmljYXRpb25bXSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5ub3RpZmljYXRpb25zID0gbm90aWZpY2F0aW9ucztcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0VmlzaWJsZU5vdGlmaWNhdGlvbnNBbmRTY2hlZHVsZVVwZGF0ZSgpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBMaXN0ZW5zIHRvIHVwZGF0ZXMgb2YgdGhlIHN5c3RlbSBub3RpZmljYXRpb24gYXJyYXkgb24gdGhlIHdlYnNvY2tldC5cbiAgICAgKiBUaGUgc2VydmVyIHN1Ym1pdHMgdGhlIGVudGlyZSBsaXN0IG9mIHJlbGV2YW50IHN5c3RlbSBub3RpZmljYXRpb25zIGlmIHRoZXkgYXJlIHVwZGF0ZWRcbiAgICAgKi9cbiAgICBwcml2YXRlIHN1YnNjcmliZVNvY2tldCgpIHtcbiAgICAgICAgdGhpcy5qaGlXZWJzb2NrZXRTZXJ2aWNlLnN1YnNjcmliZShXRUJTT0NLRVRfQ0hBTk5FTCk7XG4gICAgICAgIHRoaXMuamhpV2Vic29ja2V0U2VydmljZS5yZWNlaXZlKFdFQlNPQ0tFVF9DSEFOTkVMKS5zdWJzY3JpYmUoKG5vdGlmaWNhdGlvbnM6IFN5c3RlbU5vdGlmaWNhdGlvbltdKSA9PiB7XG4gICAgICAgICAgICBub3RpZmljYXRpb25zLmZvckVhY2goKG5vdGlmaWNhdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgIG5vdGlmaWNhdGlvbi5ub3RpZmljYXRpb25EYXRlID0gY29udmVydERhdGVGcm9tU2VydmVyKG5vdGlmaWNhdGlvbi5ub3RpZmljYXRpb25EYXRlKTtcbiAgICAgICAgICAgICAgICBub3RpZmljYXRpb24uZXhwaXJlRGF0ZSA9IGNvbnZlcnREYXRlRnJvbVNlcnZlcihub3RpZmljYXRpb24uZXhwaXJlRGF0ZSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMubm90aWZpY2F0aW9ucyA9IG5vdGlmaWNhdGlvbnM7XG4gICAgICAgICAgICB0aGlzLmNsb3NlZElkcyA9IFtdO1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RWaXNpYmxlTm90aWZpY2F0aW9uc0FuZFNjaGVkdWxlVXBkYXRlKCk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNjaGVkdWxlIGEgY2hhbmdlIGRldGVjdGlvbiBjeWNsZSBvZiB0aGlzIGNvbXBvbmVudCBhdCB0aGUgbmV4dCBkYXRlIHRoYXQgY2hhbmdlc1xuICAgICAqL1xuICAgIHByaXZhdGUgc2VsZWN0VmlzaWJsZU5vdGlmaWNhdGlvbnNBbmRTY2hlZHVsZVVwZGF0ZSgpIHtcbiAgICAgICAgY29uc3Qgbm93ID0gZGF5anMoKTtcbiAgICAgICAgdGhpcy5ub3RpZmljYXRpb25zVG9EaXNwbGF5ID0gdGhpcy5ub3RpZmljYXRpb25zXG4gICAgICAgICAgICAuZmlsdGVyKChub3RpZmljYXRpb24pID0+ICF0aGlzLmNsb3NlZElkcy5pbmNsdWRlcyhub3RpZmljYXRpb24uaWQhKSlcbiAgICAgICAgICAgIC5maWx0ZXIoKG5vdGlmaWNhdGlvbikgPT4gbm90aWZpY2F0aW9uLm5vdGlmaWNhdGlvbkRhdGU/LmlzU2FtZU9yQmVmb3JlKG5vdykgJiYgKG5vdGlmaWNhdGlvbi5leHBpcmVEYXRlPy5pc0FmdGVyKG5vdykgPz8gdHJ1ZSkpO1xuXG4gICAgICAgIGlmICh0aGlzLm5leHRVcGRhdGVGdXR1cmUpIHtcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLm5leHRVcGRhdGVGdXR1cmUpO1xuICAgICAgICAgICAgdGhpcy5uZXh0VXBkYXRlRnV0dXJlID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgbmV4dFJlbGV2YW50VGltZXN0YW1wID0gdGhpcy5ub3RpZmljYXRpb25zXG4gICAgICAgICAgICAuZmxhdE1hcCgobm90aWZpY2F0aW9uKSA9PiBbbm90aWZpY2F0aW9uLmV4cGlyZURhdGUsIG5vdGlmaWNhdGlvbi5ub3RpZmljYXRpb25EYXRlXSlcbiAgICAgICAgICAgIC5maWx0ZXIoKGRhdGUpID0+IGRhdGU/LmlzQWZ0ZXIobm93KSlcbiAgICAgICAgICAgIC5tYXAoKGRhdGUpID0+IGRhdGUhKVxuICAgICAgICAgICAgLnJlZHVjZSgocHJldmlvdXMsIGN1cnJlbnQpID0+IChwcmV2aW91cyA/IGRheWpzLm1pbihwcmV2aW91cywgY3VycmVudCkgOiBjdXJyZW50KSwgdW5kZWZpbmVkKTtcblxuICAgICAgICBpZiAobmV4dFJlbGV2YW50VGltZXN0YW1wKSB7XG4gICAgICAgICAgICB0aGlzLm5leHRVcGRhdGVGdXR1cmUgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdFZpc2libGVOb3RpZmljYXRpb25zQW5kU2NoZWR1bGVVcGRhdGUoKTtcbiAgICAgICAgICAgIH0sIG5leHRSZWxldmFudFRpbWVzdGFtcC5kaWZmKG5vdykpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgY2xvc2Uobm90aWZpY2F0aW9uOiBTeXN0ZW1Ob3RpZmljYXRpb24pIHtcbiAgICAgICAgdGhpcy5jbG9zZWRJZHMucHVzaChub3RpZmljYXRpb24uaWQhKTtcbiAgICAgICAgdGhpcy5zZWxlY3RWaXNpYmxlTm90aWZpY2F0aW9uc0FuZFNjaGVkdWxlVXBkYXRlKCk7XG4gICAgfVxufVxuIiwiQGZvciAobm90aWZpY2F0aW9uIG9mIG5vdGlmaWNhdGlvbnNUb0Rpc3BsYXk7IHRyYWNrIG5vdGlmaWNhdGlvbikge1xuICAgIDxkaXYgY2xhc3M9XCJzeXN0ZW0tbm90aWZpY2F0aW9uXCIgW25nQ2xhc3NdPVwieyBpbmZvOiAobm90aWZpY2F0aW9uLnR5cGUgfHwgSU5GTykgPT09IElORk8sIHdhcm5pbmc6IG5vdGlmaWNhdGlvbi50eXBlID09PSBXQVJOSU5HIH1cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cIm5vdGlmaWNhdGlvbi10ZXh0XCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cIm5vdGlmaWNhdGlvbi10aXRsZVwiPlxuICAgICAgICAgICAgICAgIEBpZiAoKG5vdGlmaWNhdGlvbi50eXBlIHx8IElORk8pID09PSBJTkZPKSB7XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhSW5mb0NpcmNsZVwiIGNsYXNzPVwibGVmdC1zbGlkZS1pblwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmIChub3RpZmljYXRpb24udHlwZSA9PT0gV0FSTklORykge1xuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUV4Y2xhbWF0aW9uVHJpYW5nbGVcIiBjbGFzcz1cImxlZnQtc2xpZGUtaW5cIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibGVmdC1zbGlkZS1pblwiXG4gICAgICAgICAgICAgICAgICAgID57eyBub3RpZmljYXRpb24udGl0bGUgfX1cbiAgICAgICAgICAgICAgICAgICAgQGlmIChub3RpZmljYXRpb24udGV4dCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibm90aWZpY2F0aW9uLWNvbnRlbnQgbGVmdC1zbGlkZS1pblwiPnt7IG5vdGlmaWNhdGlvbi50ZXh0IH19PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGZhLWljb24gY2xhc3M9XCJub3RpZmljYXRpb24tY2xvc2VcIiBbaWNvbl09XCJmYVRpbWVzXCIgKGNsaWNrKT1cImNsb3NlKG5vdGlmaWNhdGlvbilcIj48L2ZhLWljb24+XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uRGVzdHJveSwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IExvYWRpbmdOb3RpZmljYXRpb25TZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vbG9hZGluZy1ub3RpZmljYXRpb24vbG9hZGluZy1ub3RpZmljYXRpb24uc2VydmljZSc7XG5pbXBvcnQgeyBkZWJvdW5jZVRpbWUgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWxvYWRpbmctbm90aWZpY2F0aW9uJyxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICBAaWYgKGlzTG9hZGluZykge1xuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNwaW5uZXItYm9yZGVyXCIgcm9sZT1cInN0YXR1c1wiIHN0eWxlPVwid2lkdGg6IDE4cHg7IGhlaWdodDogMThweDsgY29sb3I6IHdoaXRlXCI+PC9kaXY+XG4gICAgICAgIH1cbiAgICBgLFxufSlcbmV4cG9ydCBjbGFzcyBMb2FkaW5nTm90aWZpY2F0aW9uQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xuICAgIGlzTG9hZGluZyA9IGZhbHNlO1xuICAgIGxvYWRpbmdTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgbG9hZGluZ05vdGlmaWNhdGlvblNlcnZpY2U6IExvYWRpbmdOb3RpZmljYXRpb25TZXJ2aWNlKSB7fVxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiB3YWl0IDEwMDAgbXMgYmVmb3JlIHVwZGF0aW5nIGlzTG9hZGluZyB2YWx1ZSB0byBlbnN1cmUgdGhlIGxvYWRpbmcgc2NyZWVuIHdpbGwgbm90IGJlIHZpc2libGUgZm9yIGZhc3QgSHR0cFJlcXVlc3RzXG4gICAgICAgICAqICovXG4gICAgICAgIHRoaXMubG9hZGluZ1N1YnNjcmlwdGlvbiA9IHRoaXMubG9hZGluZ05vdGlmaWNhdGlvblNlcnZpY2UubG9hZGluZ1N0YXR1cy5waXBlKGRlYm91bmNlVGltZSgxMDAwKSkuc3Vic2NyaWJlKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5pc0xvYWRpbmcgPSB2YWx1ZTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMubG9hZGluZ1N1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSG9zdExpc3RlbmVyLCBPbkRlc3Ryb3ksIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBmaWx0ZXIsIG1hcCwgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgTmdiTW9kYWxSZWYgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgeyBTZXNzaW9uU3RvcmFnZVNlcnZpY2UgfSBmcm9tICduZ3gtd2Vic3RvcmFnZSc7XG5pbXBvcnQgeyBVc2VyIH0gZnJvbSAnYXBwL2NvcmUvdXNlci91c2VyLm1vZGVsJztcbmltcG9ydCB7IEpoaUxhbmd1YWdlSGVscGVyIH0gZnJvbSAnYXBwL2NvcmUvbGFuZ3VhZ2UvbGFuZ3VhZ2UuaGVscGVyJztcbmltcG9ydCB7IEd1aWRlZFRvdXJTZXJ2aWNlIH0gZnJvbSAnYXBwL2d1aWRlZC10b3VyL2d1aWRlZC10b3VyLnNlcnZpY2UnO1xuaW1wb3J0IHsgUFJPRklMRV9MT0NBTENJLCBWRVJTSU9OIH0gZnJvbSAnYXBwL2FwcC5jb25zdGFudHMnO1xuaW1wb3J0IHsgUGFydGljaXBhdGlvbldlYnNvY2tldFNlcnZpY2UgfSBmcm9tICdhcHAvb3ZlcnZpZXcvcGFydGljaXBhdGlvbi13ZWJzb2NrZXQuc2VydmljZSc7XG5pbXBvcnQgeyBBY2NvdW50U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL2F1dGgvYWNjb3VudC5zZXJ2aWNlJztcbmltcG9ydCB7IFByb2ZpbGVTZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9sYXlvdXRzL3Byb2ZpbGVzL3Byb2ZpbGUuc2VydmljZSc7XG5pbXBvcnQgeyBMb2dpblNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS9sb2dpbi9sb2dpbi5zZXJ2aWNlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlLCBFdmVudCwgTmF2aWdhdGlvbkVuZCwgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IEV4YW1QYXJ0aWNpcGF0aW9uU2VydmljZSB9IGZyb20gJ2FwcC9leGFtL3BhcnRpY2lwYXRlL2V4YW0tcGFydGljaXBhdGlvbi5zZXJ2aWNlJztcbmltcG9ydCB7IEFydGVtaXNTZXJ2ZXJEYXRlU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2VydmVyLWRhdGUuc2VydmljZSc7XG5pbXBvcnQgeyBMb2NhbGVDb252ZXJzaW9uU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2VydmljZS9sb2NhbGUtY29udmVyc2lvbi5zZXJ2aWNlJztcbmltcG9ydCB7IENvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvdXJzZS9tYW5hZ2UvY291cnNlLW1hbmFnZW1lbnQuc2VydmljZSc7XG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgRXhlcmNpc2VTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhlcmNpc2UvZXhlcmNpc2Uuc2VydmljZSc7XG5pbXBvcnQgeyBBcG9sbG9uRGlhZ3JhbVNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3F1aXovbWFuYWdlL2Fwb2xsb24tZGlhZ3JhbXMvYXBvbGxvbi1kaWFncmFtLnNlcnZpY2UnO1xuaW1wb3J0IHsgTGVjdHVyZVNlcnZpY2UgfSBmcm9tICdhcHAvbGVjdHVyZS9sZWN0dXJlLnNlcnZpY2UnO1xuaW1wb3J0IHsgRXhhbU1hbmFnZW1lbnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4YW0vbWFuYWdlL2V4YW0tbWFuYWdlbWVudC5zZXJ2aWNlJztcbmltcG9ydCB7IEF1dGhvcml0eSB9IGZyb20gJ2FwcC9zaGFyZWQvY29uc3RhbnRzL2F1dGhvcml0eS5jb25zdGFudHMnO1xuaW1wb3J0IHsgVHJhbnNsYXRlU2VydmljZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xuaW1wb3J0IHsgQWxlcnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvdXRpbC9hbGVydC5zZXJ2aWNlJztcbmltcG9ydCB7IExBTkdVQUdFUyB9IGZyb20gJ2FwcC9jb3JlL2xhbmd1YWdlL2xhbmd1YWdlLmNvbnN0YW50cyc7XG5pbXBvcnQgeyBPcmdhbml6YXRpb25NYW5hZ2VtZW50U2VydmljZSB9IGZyb20gJ2FwcC9hZG1pbi9vcmdhbml6YXRpb24tbWFuYWdlbWVudC9vcmdhbml6YXRpb24tbWFuYWdlbWVudC5zZXJ2aWNlJztcbmltcG9ydCB7XG4gICAgZmFCYXJzLFxuICAgIGZhQmVsbCxcbiAgICBmYUJvb2ssXG4gICAgZmFCb29rT3BlbixcbiAgICBmYUNvZyxcbiAgICBmYUV5ZSxcbiAgICBmYUZsYWcsXG4gICAgZmFHZWFycyxcbiAgICBmYUhlYXJ0LFxuICAgIGZhTGlzdCxcbiAgICBmYUxvY2ssXG4gICAgZmFSb2JvdCxcbiAgICBmYVNpZ25PdXRBbHQsXG4gICAgZmFTdGFtcCxcbiAgICBmYVRhY2hvbWV0ZXJBbHQsXG4gICAgZmFUYXNrcyxcbiAgICBmYVRoTGFyZ2UsXG4gICAgZmFUaExpc3QsXG4gICAgZmFUb2dnbGVPbixcbiAgICBmYVVuaXZlcnNpdHksXG4gICAgZmFVc2VyLFxuICAgIGZhVXNlclBsdXMsXG4gICAgZmFXcmVuY2gsXG59IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBFeGVyY2lzZUhpbnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhlcmNpc2UtaGludC9zaGFyZWQvZXhlcmNpc2UtaGludC5zZXJ2aWNlJztcbmltcG9ydCB7IEV4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IFRoZW1lU2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3RoZW1lL3RoZW1lLnNlcnZpY2UnO1xuaW1wb3J0IHsgRW50aXR5VGl0bGVTZXJ2aWNlLCBFbnRpdHlUeXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9sYXlvdXRzL25hdmJhci9lbnRpdHktdGl0bGUuc2VydmljZSc7XG5pbXBvcnQgeyBvbkVycm9yIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2dsb2JhbC51dGlscyc7XG5pbXBvcnQgeyBTdHVkZW50RXhhbSB9IGZyb20gJ2FwcC9lbnRpdGllcy9zdHVkZW50LWV4YW0ubW9kZWwnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1uYXZiYXInLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9uYXZiYXIuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWyduYXZiYXIuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBOYXZiYXJDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gICAgaW5Qcm9kdWN0aW9uOiBib29sZWFuO1xuICAgIHRlc3RTZXJ2ZXI6IGJvb2xlYW47XG4gICAgaXNOYXZiYXJDb2xsYXBzZWQ6IGJvb2xlYW47XG4gICAgaXNUb3VyQXZhaWxhYmxlOiBib29sZWFuO1xuICAgIGdpdENvbW1pdElkOiBzdHJpbmc7XG4gICAgZ2l0QnJhbmNoTmFtZTogc3RyaW5nO1xuICAgIGdpdFRpbWVzdGFtcDogc3RyaW5nO1xuICAgIGdpdFVzZXJuYW1lOiBzdHJpbmc7XG4gICAgbGFuZ3VhZ2VzID0gTEFOR1VBR0VTO1xuICAgIG9wZW5BcGlFbmFibGVkPzogYm9vbGVhbjtcbiAgICBtb2RhbFJlZjogTmdiTW9kYWxSZWY7XG4gICAgdmVyc2lvbjogc3RyaW5nO1xuICAgIGN1cnJBY2NvdW50PzogVXNlcjtcbiAgICBpc1JlZ2lzdHJhdGlvbkVuYWJsZWQgPSBmYWxzZTtcbiAgICBwYXNzd29yZFJlc2V0RW5hYmxlZCA9IGZhbHNlO1xuICAgIGJyZWFkY3J1bWJzOiBCcmVhZGNydW1iW107XG4gICAgYnJlYWRjcnVtYlN1YnNjcmlwdGlvbnM6IFN1YnNjcmlwdGlvbltdO1xuICAgIGlzQ29sbGFwc2VkOiBib29sZWFuO1xuICAgIGljb25zTW92ZWRUb01lbnU6IGJvb2xlYW47XG4gICAgaXNOYXZiYXJOYXZWZXJ0aWNhbDogYm9vbGVhbjtcbiAgICBpc0V4YW1BY3RpdmUgPSBmYWxzZTtcbiAgICBleGFtQWN0aXZlQ2hlY2tGdXR1cmU/OiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PjtcbiAgICBpcmlzRW5hYmxlZDogYm9vbGVhbjtcbiAgICBsb2NhbENJQWN0aXZlOiBib29sZWFuID0gZmFsc2U7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhQmFycyA9IGZhQmFycztcbiAgICBmYVRoTGFyZ2UgPSBmYVRoTGFyZ2U7XG4gICAgZmFUaExpc3QgPSBmYVRoTGlzdDtcbiAgICBmYVVzZXIgPSBmYVVzZXI7XG4gICAgZmFCZWxsID0gZmFCZWxsO1xuICAgIGZhVW5pdmVyc2l0eSA9IGZhVW5pdmVyc2l0eTtcbiAgICBmYUV5ZSA9IGZhRXllO1xuICAgIGZhQ29nID0gZmFDb2c7XG4gICAgZmFXcmVuY2ggPSBmYVdyZW5jaDtcbiAgICBmYUxvY2sgPSBmYUxvY2s7XG4gICAgZmFTdGFtcCA9IGZhU3RhbXA7XG4gICAgZmFGbGFnID0gZmFGbGFnO1xuICAgIGZhQm9vayA9IGZhQm9vaztcbiAgICBmYVRhc2tzID0gZmFUYXNrcztcbiAgICBmYUxpc3QgPSBmYUxpc3Q7XG4gICAgZmFSb2JvdCA9IGZhUm9ib3Q7XG4gICAgZmFIZWFydCA9IGZhSGVhcnQ7XG4gICAgZmFUYWNob21ldGVyQWx0ID0gZmFUYWNob21ldGVyQWx0O1xuICAgIGZhVG9nZ2xlT24gPSBmYVRvZ2dsZU9uO1xuICAgIGZhQm9va09wZW4gPSBmYUJvb2tPcGVuO1xuICAgIGZhVXNlclBsdXMgPSBmYVVzZXJQbHVzO1xuICAgIGZhU2lnbk91dEFsdCA9IGZhU2lnbk91dEFsdDtcbiAgICBmYUdlYXJzID0gZmFHZWFycztcblxuICAgIHByaXZhdGUgYXV0aFN0YXRlU3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb247XG4gICAgcHJpdmF0ZSByb3V0ZXJFdmVudFN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xuICAgIHByaXZhdGUgc3R1ZGVudEV4YW0/OiBTdHVkZW50RXhhbTtcbiAgICBwcml2YXRlIGV4YW1JZD86IG51bWJlcjtcbiAgICBwcml2YXRlIHJvdXRlRXhhbUlkID0gMDtcbiAgICBwcml2YXRlIGxhc3RSb3V0ZVVybFNlZ21lbnQ/OiBzdHJpbmc7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBsb2dpblNlcnZpY2U6IExvZ2luU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSB0cmFuc2xhdGVTZXJ2aWNlOiBUcmFuc2xhdGVTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGxhbmd1YWdlSGVscGVyOiBKaGlMYW5ndWFnZUhlbHBlcixcbiAgICAgICAgcHJpdmF0ZSBsb2NhbGVDb252ZXJzaW9uU2VydmljZTogTG9jYWxlQ29udmVyc2lvblNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgc2Vzc2lvblN0b3JhZ2U6IFNlc3Npb25TdG9yYWdlU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBhY2NvdW50U2VydmljZTogQWNjb3VudFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgcHJvZmlsZVNlcnZpY2U6IFByb2ZpbGVTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHBhcnRpY2lwYXRpb25XZWJzb2NrZXRTZXJ2aWNlOiBQYXJ0aWNpcGF0aW9uV2Vic29ja2V0U2VydmljZSxcbiAgICAgICAgcHVibGljIGd1aWRlZFRvdXJTZXJ2aWNlOiBHdWlkZWRUb3VyU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcbiAgICAgICAgcHJpdmF0ZSByb3V0ZTogQWN0aXZhdGVkUm91dGUsXG4gICAgICAgIHByaXZhdGUgZXhhbVBhcnRpY2lwYXRpb25TZXJ2aWNlOiBFeGFtUGFydGljaXBhdGlvblNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgc2VydmVyRGF0ZVNlcnZpY2U6IEFydGVtaXNTZXJ2ZXJEYXRlU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBhbGVydFNlcnZpY2U6IEFsZXJ0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBjb3Vyc2VNYW5hZ2VtZW50U2VydmljZTogQ291cnNlTWFuYWdlbWVudFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgZXhlcmNpc2VTZXJ2aWNlOiBFeGVyY2lzZVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgZXhlcmNpc2VIaW50U2VydmljZTogRXhlcmNpc2VIaW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBhcG9sbG9uRGlhZ3JhbVNlcnZpY2U6IEFwb2xsb25EaWFncmFtU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBsZWN0dXJlU2VydmljZTogTGVjdHVyZVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgZXhhbVNlcnZpY2U6IEV4YW1NYW5hZ2VtZW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBvcmdhbmlzYXRpb25TZXJ2aWNlOiBPcmdhbml6YXRpb25NYW5hZ2VtZW50U2VydmljZSxcbiAgICAgICAgcHVibGljIHRoZW1lU2VydmljZTogVGhlbWVTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGVudGl0eVRpdGxlU2VydmljZTogRW50aXR5VGl0bGVTZXJ2aWNlLFxuICAgICkge1xuICAgICAgICB0aGlzLnZlcnNpb24gPSBWRVJTSU9OID8gVkVSU0lPTiA6ICcnO1xuICAgICAgICB0aGlzLmlzTmF2YmFyQ29sbGFwc2VkID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5zdWJzY3JpYmVUb05hdmlnYXRpb25FdmVudHNGb3JFeGFtSWQoKTtcbiAgICAgICAgdGhpcy5vblJlc2l6ZSgpO1xuICAgIH1cblxuICAgIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzpyZXNpemUnKVxuICAgIG9uUmVzaXplKCkge1xuICAgICAgICAvLyBGaWd1cmUgb3V0IGJyZWFrcG9pbnRzIGRlcGVuZGluZyBvbiBhdmFpbGFibGUgbWVudSBvcHRpb25zIGFuZCBsZW5ndGggb2YgbG9naW5cbiAgICAgICAgbGV0IG5lZWRlZFdpZHRoVG9Ob3RSZXF1aXJlQ29sbGFwc2U6IG51bWJlcjtcbiAgICAgICAgbGV0IG5lZWRlZFdpZHRoVG9EaXNwbGF5Q29sbGFwc2VkT3B0aW9uc0hvcml6b250YWxseSA9IDE1MDtcbiAgICAgICAgbGV0IG5lZWRlZFdpZHRoRm9ySWNvbk9wdGlvbnNUb0JlSW5NYWluTmF2QmFyOiBudW1iZXI7XG4gICAgICAgIGlmICh0aGlzLmN1cnJBY2NvdW50KSB7XG4gICAgICAgICAgICBjb25zdCBuYW1lTGVuZ3RoID0gKHRoaXMuY3VyckFjY291bnQubG9naW4/Lmxlbmd0aCA/PyAwKSAqIDg7XG4gICAgICAgICAgICBuZWVkZWRXaWR0aEZvckljb25PcHRpb25zVG9CZUluTWFpbk5hdkJhciA9IDU4MCArIG5hbWVMZW5ndGg7XG4gICAgICAgICAgICBuZWVkZWRXaWR0aFRvTm90UmVxdWlyZUNvbGxhcHNlID0gNzAwICsgbmFtZUxlbmd0aDtcblxuICAgICAgICAgICAgY29uc3QgaGFzU2VydmVyQWRtaW5PcHRpb24gPSB0aGlzLmFjY291bnRTZXJ2aWNlLmhhc0FueUF1dGhvcml0eURpcmVjdChbQXV0aG9yaXR5LkFETUlOXSk7XG4gICAgICAgICAgICBjb25zdCBoYXNDb3Vyc2VNYW5hZ2VPcHRpb24gPSB0aGlzLmFjY291bnRTZXJ2aWNlLmhhc0FueUF1dGhvcml0eURpcmVjdChbQXV0aG9yaXR5LlRBLCBBdXRob3JpdHkuSU5TVFJVQ1RPUiwgQXV0aG9yaXR5LkVESVRPUiwgQXV0aG9yaXR5LkFETUlOXSk7XG4gICAgICAgICAgICBpZiAoaGFzQ291cnNlTWFuYWdlT3B0aW9uKSB7XG4gICAgICAgICAgICAgICAgbmVlZGVkV2lkdGhUb05vdFJlcXVpcmVDb2xsYXBzZSArPSAyMDA7XG4gICAgICAgICAgICAgICAgbmVlZGVkV2lkdGhUb0Rpc3BsYXlDb2xsYXBzZWRPcHRpb25zSG9yaXpvbnRhbGx5ICs9IDIwMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChoYXNTZXJ2ZXJBZG1pbk9wdGlvbikge1xuICAgICAgICAgICAgICAgIG5lZWRlZFdpZHRoVG9Ob3RSZXF1aXJlQ29sbGFwc2UgKz0gMjI1O1xuICAgICAgICAgICAgICAgIG5lZWRlZFdpZHRoVG9EaXNwbGF5Q29sbGFwc2VkT3B0aW9uc0hvcml6b250YWxseSArPSAyMjU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBGb3IgbG9naW4gc2NyZWVuLCB3ZSBvbmx5IHNlZSBsYW5ndWFnZSBhbmQgdGhlbWUgc2VsZWN0b3JzIHdoaWNoIGFyZSBzbWFsbGVyXG4gICAgICAgICAgICBuZWVkZWRXaWR0aFRvTm90UmVxdWlyZUNvbGxhcHNlID0gNTEwO1xuICAgICAgICAgICAgbmVlZGVkV2lkdGhGb3JJY29uT3B0aW9uc1RvQmVJbk1haW5OYXZCYXIgPSA0MzA7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmlzQ29sbGFwc2VkID0gd2luZG93LmlubmVyV2lkdGggPCBuZWVkZWRXaWR0aFRvTm90UmVxdWlyZUNvbGxhcHNlO1xuICAgICAgICB0aGlzLmlzTmF2YmFyTmF2VmVydGljYWwgPSB3aW5kb3cuaW5uZXJXaWR0aCA8IE1hdGgubWF4KG5lZWRlZFdpZHRoVG9EaXNwbGF5Q29sbGFwc2VkT3B0aW9uc0hvcml6b250YWxseSwgNDgwKTtcbiAgICAgICAgdGhpcy5pY29uc01vdmVkVG9NZW51ID0gd2luZG93LmlubmVyV2lkdGggPCBuZWVkZWRXaWR0aEZvckljb25PcHRpb25zVG9CZUluTWFpbk5hdkJhcjtcbiAgICB9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5wcm9maWxlU2VydmljZS5nZXRQcm9maWxlSW5mbygpLnN1YnNjcmliZSgocHJvZmlsZUluZm8pID0+IHtcbiAgICAgICAgICAgIGlmIChwcm9maWxlSW5mbykge1xuICAgICAgICAgICAgICAgIHRoaXMuaW5Qcm9kdWN0aW9uID0gcHJvZmlsZUluZm8uaW5Qcm9kdWN0aW9uO1xuICAgICAgICAgICAgICAgIHRoaXMudGVzdFNlcnZlciA9IHByb2ZpbGVJbmZvLnRlc3RTZXJ2ZXIgPz8gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhpcy5vcGVuQXBpRW5hYmxlZCA9IHByb2ZpbGVJbmZvLm9wZW5BcGlFbmFibGVkO1xuICAgICAgICAgICAgICAgIHRoaXMuZ2l0Q29tbWl0SWQgPSBwcm9maWxlSW5mby5naXQuY29tbWl0LmlkLmFiYnJldjtcbiAgICAgICAgICAgICAgICB0aGlzLmdpdEJyYW5jaE5hbWUgPSBwcm9maWxlSW5mby5naXQuYnJhbmNoO1xuICAgICAgICAgICAgICAgIHRoaXMuZ2l0VGltZXN0YW1wID0gbmV3IERhdGUocHJvZmlsZUluZm8uZ2l0LmNvbW1pdC50aW1lKS50b1VUQ1N0cmluZygpO1xuICAgICAgICAgICAgICAgIHRoaXMuZ2l0VXNlcm5hbWUgPSBwcm9maWxlSW5mby5naXQuY29tbWl0LnVzZXIubmFtZTtcbiAgICAgICAgICAgICAgICB0aGlzLmlyaXNFbmFibGVkID0gcHJvZmlsZUluZm8uYWN0aXZlUHJvZmlsZXMuaW5jbHVkZXMoJ2lyaXMnKTtcbiAgICAgICAgICAgICAgICB0aGlzLmxvY2FsQ0lBY3RpdmUgPSBwcm9maWxlSW5mbz8uYWN0aXZlUHJvZmlsZXMuaW5jbHVkZXMoUFJPRklMRV9MT0NBTENJKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5zdWJzY3JpYmVGb3JHdWlkZWRUb3VyQXZhaWxhYmlsaXR5KCk7XG5cbiAgICAgICAgLy8gVGhlIGN1cnJlbnQgdXNlciBpcyBuZWVkZWQgdG8gaGlkZSBtZW51IGl0ZW1zIGZvciBub3QgbG9nZ2VkLWluIHVzZXJzLlxuICAgICAgICB0aGlzLmF1dGhTdGF0ZVN1YnNjcmlwdGlvbiA9IHRoaXMuYWNjb3VudFNlcnZpY2VcbiAgICAgICAgICAgIC5nZXRBdXRoZW50aWNhdGlvblN0YXRlKClcbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIHRhcCgodXNlcjogVXNlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmN1cnJBY2NvdW50ID0gdXNlcjtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wYXNzd29yZFJlc2V0RW5hYmxlZCA9IHVzZXI/LmludGVybmFsIHx8IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uUmVzaXplKCk7XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAuc3Vic2NyaWJlKCk7XG5cbiAgICAgICAgdGhpcy5leGFtUGFydGljaXBhdGlvblNlcnZpY2UuY3VycmVudGx5TG9hZGVkU3R1ZGVudEV4YW0uc3Vic2NyaWJlKChzdHVkZW50RXhhbSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5zdHVkZW50RXhhbSA9IHN0dWRlbnRFeGFtO1xuICAgICAgICAgICAgdGhpcy5jaGVja0V4YW1BY3RpdmUoKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5idWlsZEJyZWFkY3J1bWJzKHRoaXMucm91dGVyLnVybCk7XG4gICAgICAgIHRoaXMucm91dGVyLmV2ZW50cy5waXBlKGZpbHRlcigoZXZlbnQpID0+IGV2ZW50IGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCkpLnN1YnNjcmliZSgoZXZlbnQ6IE5hdmlnYXRpb25FbmQpID0+IHRoaXMuYnVpbGRCcmVhZGNydW1icyhldmVudC51cmwpKTtcbiAgICB9XG5cbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMuYXV0aFN0YXRlU3Vic2NyaXB0aW9uKSB7XG4gICAgICAgICAgICB0aGlzLmF1dGhTdGF0ZVN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLnJvdXRlckV2ZW50U3Vic2NyaXB0aW9uKSB7XG4gICAgICAgICAgICB0aGlzLnJvdXRlckV2ZW50U3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuZXhhbUFjdGl2ZUNoZWNrRnV0dXJlKSB7XG4gICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5leGFtQWN0aXZlQ2hlY2tGdXR1cmUpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgYnJlYWRjcnVtYlRyYW5zbGF0aW9uID0ge1xuICAgICAgICBuZXc6ICdnbG9iYWwuZ2VuZXJpYy5jcmVhdGUnLFxuICAgICAgICBwcm9jZXNzOiAnYXJ0ZW1pc0FwcC5hdHRhY2htZW50VW5pdC5jcmVhdGVBdHRhY2htZW50VW5pdHMucGFnZVRpdGxlJyxcbiAgICAgICAgdmVyaWZ5X2F0dGVuZGFuY2U6ICdhcnRlbWlzQXBwLmV4YW1NYW5hZ2VtZW50LmV4YW1TdHVkZW50cy52ZXJpZnlDaGVja3MnLFxuICAgICAgICBjcmVhdGU6ICdnbG9iYWwuZ2VuZXJpYy5jcmVhdGUnLFxuICAgICAgICBzdGFydDogJ2dsb2JhbC5nZW5lcmljLnN0YXJ0JyxcbiAgICAgICAgZWRpdDogJ2dsb2JhbC5nZW5lcmljLmVkaXQnLFxuICAgICAgICBhdWRpdHM6ICdhdWRpdHMudGl0bGUnLFxuICAgICAgICBjb25maWd1cmF0aW9uOiAnY29uZmlndXJhdGlvbi50aXRsZScsXG4gICAgICAgIGZlYXR1cmVfdG9nZ2xlczogJ2ZlYXR1cmVUb2dnbGVzLnRpdGxlJyxcbiAgICAgICAgaGVhbHRoOiAnaGVhbHRoLnRpdGxlJyxcbiAgICAgICAgbG9nczogJ2xvZ3MudGl0bGUnLFxuICAgICAgICBkb2NzOiAnZ2xvYmFsLm1lbnUuYWRtaW4uYXBpZG9jcycsXG4gICAgICAgIG1ldHJpY3M6ICdtZXRyaWNzLnRpdGxlJyxcbiAgICAgICAgdXNlcl9zdGF0aXN0aWNzOiAnc3RhdGlzdGljcy50aXRsZScsXG4gICAgICAgIHVzZXJfbWFuYWdlbWVudDogJ2FydGVtaXNBcHAudXNlck1hbmFnZW1lbnQuaG9tZS50aXRsZScsXG4gICAgICAgIHN5c3RlbV9ub3RpZmljYXRpb25fbWFuYWdlbWVudDogJ2FydGVtaXNBcHAuc3lzdGVtTm90aWZpY2F0aW9uLnN5c3RlbU5vdGlmaWNhdGlvbnMnLFxuICAgICAgICB1cGNvbWluZ19leGFtc19hbmRfZXhlcmNpc2VzOiAnYXJ0ZW1pc0FwcC51cGNvbWluZ0V4YW1zQW5kRXhlcmNpc2VzLnVwY29taW5nRXhhbXNBbmRFeGVyY2lzZXMnLFxuICAgICAgICBhY2NvdW50OiAnZ2xvYmFsLm1lbnUuYWNjb3VudC5tYWluJyxcbiAgICAgICAgYWN0aXZhdGU6ICdhY3RpdmF0ZS50aXRsZScsXG4gICAgICAgIHBhc3N3b3JkOiAnZ2xvYmFsLm1lbnUuYWNjb3VudC5wYXNzd29yZCcsXG4gICAgICAgIHJlc2V0OiAnZ2xvYmFsLm1lbnUuYWNjb3VudC5wYXNzd29yZCcsXG4gICAgICAgIHJlZ2lzdGVyOiAncmVnaXN0ZXIudGl0bGUnLFxuICAgICAgICBzZXR0aW5nczogJ2dsb2JhbC5tZW51LmFjY291bnQuc2V0dGluZ3MnLFxuICAgICAgICBjb3Vyc2VfbWFuYWdlbWVudDogJ2dsb2JhbC5tZW51LmNvdXJzZScsXG4gICAgICAgIGV4ZXJjaXNlczogJ2FydGVtaXNBcHAuY291cnNlLmV4ZXJjaXNlcycsXG4gICAgICAgIHRleHRfZXhlcmNpc2VzOiAnYXJ0ZW1pc0FwcC5jb3Vyc2UuZXhlcmNpc2VzJyxcbiAgICAgICAgcHJvZ3JhbW1pbmdfZXhlcmNpc2VzOiAnYXJ0ZW1pc0FwcC5jb3Vyc2UuZXhlcmNpc2VzJyxcbiAgICAgICAgbW9kZWxpbmdfZXhlcmNpc2VzOiAnYXJ0ZW1pc0FwcC5jb3Vyc2UuZXhlcmNpc2VzJyxcbiAgICAgICAgZmlsZV91cGxvYWRfZXhlcmNpc2VzOiAnYXJ0ZW1pc0FwcC5jb3Vyc2UuZXhlcmNpc2VzJyxcbiAgICAgICAgcXVpel9leGVyY2lzZXM6ICdhcnRlbWlzQXBwLmNvdXJzZS5leGVyY2lzZXMnLFxuICAgICAgICBwYXJ0aWNpcGF0aW9uczogJ2FydGVtaXNBcHAucGFydGljaXBhdGlvbi5ob21lLnRpdGxlJyxcbiAgICAgICAgc3VibWlzc2lvbnM6ICdhcnRlbWlzQXBwLmV4ZXJjaXNlLnN1Ym1pc3Npb25zJyxcbiAgICAgICAgY29tcGxhaW50czogJ2FydGVtaXNBcHAuY29tcGxhaW50Lmxpc3RPZkNvbXBsYWludHMudGl0bGUnLFxuICAgICAgICBtb3JlX2ZlZWRiYWNrX3JlcXVlc3RzOiAnYXJ0ZW1pc0FwcC5tb3JlRmVlZGJhY2subGlzdC50aXRsZScsXG4gICAgICAgIGluc3RydWN0b3JfZGFzaGJvYXJkOiAnZW50aXR5LmFjdGlvbi5pbnN0cnVjdG9yRGFzaGJvYXJkJyxcbiAgICAgICAgYXNzZXNzbWVudF9kYXNoYm9hcmQ6ICdhcnRlbWlzQXBwLmFzc2Vzc21lbnREYXNoYm9hcmQuaG9tZS50aXRsZScsXG4gICAgICAgIHRlc3RfcnVuX2V4ZXJjaXNlX2Fzc2Vzc21lbnRfZGFzaGJvYXJkOiAnYXJ0ZW1pc0FwcC5leGVyY2lzZUFzc2Vzc21lbnREYXNoYm9hcmQuaG9tZS50aXRsZScsXG4gICAgICAgIGx0aV9jb25maWd1cmF0aW9uOiAnYXJ0ZW1pc0FwcC5sdGkuaG9tZS50aXRsZScsXG4gICAgICAgIHRlYW1zOiAnYXJ0ZW1pc0FwcC50ZWFtLmhvbWUudGl0bGUnLFxuICAgICAgICBleGVyY2lzZV9oaW50czogJ2FydGVtaXNBcHAuZXhlcmNpc2VIaW50LmhvbWUudGl0bGUnLFxuICAgICAgICByYXRpbmdzOiAnYXJ0ZW1pc0FwcC5yYXRpbmdMaXN0LnBhZ2VUaXRsZScsXG4gICAgICAgIGNvbXBldGVuY3lfbWFuYWdlbWVudDogJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5tYW5hZ2VDb21wZXRlbmNpZXMudGl0bGUnLFxuICAgICAgICBsZWFybmluZ19wYXRoX21hbmFnZW1lbnQ6ICdhcnRlbWlzQXBwLmxlYXJuaW5nUGF0aC5tYW5hZ2VMZWFybmluZ1BhdGhzLnRpdGxlJyxcbiAgICAgICAgYXNzZXNzbWVudF9sb2NrczogJ2FydGVtaXNBcHAuYXNzZXNzbWVudC5sb2Nrcy5ob21lLnRpdGxlJyxcbiAgICAgICAgYXBvbGxvbl9kaWFncmFtczogJ2FydGVtaXNBcHAuYXBvbGxvbkRpYWdyYW0uaG9tZS50aXRsZScsXG4gICAgICAgIGNvbW11bmljYXRpb246ICdhcnRlbWlzQXBwLm1ldGlzLmNvbW11bmljYXRpb24ubGFiZWwnLFxuICAgICAgICBzY29yZXM6ICdlbnRpdHkuYWN0aW9uLnNjb3JlcycsXG4gICAgICAgIGFzc2Vzc21lbnQ6ICdhcnRlbWlzQXBwLmFzc2Vzc21lbnQuYXNzZXNzbWVudCcsXG4gICAgICAgIGV4cG9ydDogJ2FydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cG9ydC5leHBvcnQnLFxuICAgICAgICByZV9ldmFsdWF0ZTogJ2VudGl0eS5hY3Rpb24ucmUtZXZhbHVhdGUnLFxuICAgICAgICBzb2x1dGlvbjogJ2FydGVtaXNBcHAucXVpekV4ZXJjaXNlLnNvbHV0aW9uJyxcbiAgICAgICAgcHJldmlldzogJ2FydGVtaXNBcHAucXVpekV4ZXJjaXNlLnByZXZpZXdNb2RlJyxcbiAgICAgICAgcXVpel9zdGF0aXN0aWM6ICdhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5zdGF0aXN0aWNzJyxcbiAgICAgICAgcXVpel9wb2ludF9zdGF0aXN0aWM6ICdhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5zdGF0aXN0aWNzJyxcbiAgICAgICAgaW1wb3J0OiAnYXJ0ZW1pc0FwcC5leGVyY2lzZS5pbXBvcnQudGFibGUuZG9JbXBvcnQnLFxuICAgICAgICBpbXBvcnRfZnJvbV9maWxlOiAnYXJ0ZW1pc0FwcC5wcm9ncmFtbWluZ0V4ZXJjaXNlLmltcG9ydEZyb21GaWxlLnRpdGxlJyxcbiAgICAgICAgcGxhZ2lhcmlzbTogJ2FydGVtaXNBcHAucGxhZ2lhcmlzbS5wbGFnaWFyaXNtRGV0ZWN0aW9uJyxcbiAgICAgICAgZXhhbXBsZV9zb2x1dGlvbjogJ2FydGVtaXNBcHAubW9kZWxpbmdFeGVyY2lzZS5leGFtcGxlU29sdXRpb24nLFxuICAgICAgICBleGFtcGxlX3N1Ym1pc3Npb25zOiAnYXJ0ZW1pc0FwcC5leGFtcGxlU3VibWlzc2lvbi5ob21lLnRpdGxlJyxcbiAgICAgICAgZXhhbXBsZV9zdWJtaXNzaW9uX2VkaXRvcjogJ2FydGVtaXNBcHAuZXhhbXBsZVN1Ym1pc3Npb24uaG9tZS5lZGl0b3InLFxuICAgICAgICBncmFkaW5nOiAnYXJ0ZW1pc0FwcC5wcm9ncmFtbWluZ0V4ZXJjaXNlLmNvbmZpZ3VyZUdyYWRpbmcuc2hvcnRUaXRsZScsXG4gICAgICAgIHRlc3Q6ICdhcnRlbWlzQXBwLmVkaXRvci5ob21lLnRpdGxlJyxcbiAgICAgICAgaWRlOiAnYXJ0ZW1pc0FwcC5lZGl0b3IuaG9tZS50aXRsZScsXG4gICAgICAgIGxlY3R1cmVzOiAnYXJ0ZW1pc0FwcC5sZWN0dXJlLmhvbWUudGl0bGUnLFxuICAgICAgICBhdHRhY2htZW50czogJ2FydGVtaXNBcHAubGVjdHVyZS5hdHRhY2htZW50cy50aXRsZScsXG4gICAgICAgIHVuaXRfbWFuYWdlbWVudDogJ2FydGVtaXNBcHAubGVjdHVyZVVuaXQuaG9tZS50aXRsZScsXG4gICAgICAgIGV4YW1zOiAnYXJ0ZW1pc0FwcC5leGFtTWFuYWdlbWVudC50aXRsZScsXG4gICAgICAgIGV4ZXJjaXNlX2dyb3VwczogJ2FydGVtaXNBcHAuZXhhbU1hbmFnZW1lbnQuZXhlcmNpc2VHcm91cHMnLFxuICAgICAgICBxdWl6X3Bvb2w6ICdhcnRlbWlzQXBwLmV4YW1NYW5hZ2VtZW50LnF1aXpQb29sJyxcbiAgICAgICAgc3R1ZGVudHM6ICdhcnRlbWlzQXBwLmNvdXJzZS5zdHVkZW50cycsXG4gICAgICAgIHR1dG9yczogJ2FydGVtaXNBcHAuY291cnNlLnR1dG9ycycsXG4gICAgICAgIGluc3RydWN0b3JzOiAnYXJ0ZW1pc0FwcC5jb3Vyc2UuaW5zdHJ1Y3RvcnMnLFxuICAgICAgICB0ZXN0X3J1bnM6ICdhcnRlbWlzQXBwLmV4YW1NYW5hZ2VtZW50LnRlc3RSdW4udGVzdFJ1bicsXG4gICAgICAgIGFzc2VzczogJ2FydGVtaXNBcHAuZXhhbU1hbmFnZW1lbnQuYXNzZXNzbWVudERhc2hib2FyZCcsXG4gICAgICAgIHN1bW1hcnk6ICdhcnRlbWlzQXBwLmV4YW0uc3VtbWFyeScsXG4gICAgICAgIGNvbmR1Y3Rpb246ICdhcnRlbWlzQXBwLmV4YW0udGl0bGUnLFxuICAgICAgICBzdHVkZW50X2V4YW1zOiAnYXJ0ZW1pc0FwcC5zdHVkZW50RXhhbXMudGl0bGUnLFxuICAgICAgICB0ZXN0X2Fzc2Vzc21lbnRfZGFzaGJvYXJkOiAnYXJ0ZW1pc0FwcC5leGFtTWFuYWdlbWVudC5hc3Nlc3NtZW50RGFzaGJvYXJkJyxcbiAgICAgICAgdHV0b3JfZXhhbV9kYXNoYm9hcmQ6ICdhcnRlbWlzQXBwLmV4YW1NYW5hZ2VtZW50LmFzc2Vzc21lbnREYXNoYm9hcmQnLFxuICAgICAgICBvcmdhbml6YXRpb25fbWFuYWdlbWVudDogJ2FydGVtaXNBcHAub3JnYW5pemF0aW9uTWFuYWdlbWVudC50aXRsZScsXG4gICAgICAgIHBhcnRpY2lwYW50X3Njb3JlczogJ2FydGVtaXNBcHAucGFydGljaXBhbnRTY29yZXMucGFnZVRpdGxlJyxcbiAgICAgICAgY291cnNlX3N0YXRpc3RpY3M6ICdzdGF0aXN0aWNzLmNvdXJzZV9zdGF0aXN0aWNzX3RpdGxlJyxcbiAgICAgICAgZ3JhZGluZ19zeXN0ZW06ICdhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0udGl0bGUnLFxuICAgICAgICBncmFkaW5nX2tleTogJ2FydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS50aXRsZScsXG4gICAgICAgIGV4ZXJjaXNlX3N0YXRpc3RpY3M6ICdleGVyY2lzZS1zdGF0aXN0aWNzLnRpdGxlJyxcbiAgICAgICAgdHV0b3JfZWZmb3J0X3N0YXRpc3RpY3M6ICdhcnRlbWlzQXBwLnRleHRFeGVyY2lzZS50dXRvckVmZm9ydFN0YXRpc3RpY3MudGl0bGUnLFxuICAgICAgICB1c2VyX3NldHRpbmdzOiAnYXJ0ZW1pc0FwcC51c2VyU2V0dGluZ3MudGl0bGUnLFxuICAgICAgICBkZXRhaWxlZDogJ2FydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5kZXRhaWxlZFRhYi50aXRsZScsXG4gICAgICAgIGludGVydmFsOiAnYXJ0ZW1pc0FwcC5ncmFkaW5nU3lzdGVtLmludGVydmFsVGFiLnRpdGxlJyxcbiAgICAgICAgcGxhZ2lhcmlzbV9jYXNlczogJ2FydGVtaXNBcHAucGxhZ2lhcmlzbS5jYXNlcy5wYWdlVGl0bGUnLFxuICAgICAgICBjb2RlX2hpbnRfbWFuYWdlbWVudDogJ2FydGVtaXNBcHAuY29kZUhpbnQubWFuYWdlbWVudC50aXRsZScsXG4gICAgICAgIHR1dG9yaWFsX2dyb3Vwc19tYW5hZ2VtZW50OiAnYXJ0ZW1pc0FwcC5wYWdlcy50dXRvcmlhbEdyb3Vwc01hbmFnZW1lbnQudGl0bGUnLFxuICAgICAgICB0dXRvcmlhbF9ncm91cHM6ICdhcnRlbWlzQXBwLmJyZWFkY3J1bWIudGl0bGUnLFxuICAgICAgICByZWdpc3RlcmVkX3N0dWRlbnRzOiAnYXJ0ZW1pc0FwcC5wYWdlcy5yZWdpc3RlcmVkU3R1ZGVudHMudGl0bGUnLFxuICAgICAgICBzZXNzaW9uczogJ2FydGVtaXNBcHAucGFnZXMudHV0b3JpYWxHcm91cFNlc3Npb25NYW5hZ2VtZW50LnRpdGxlJyxcbiAgICAgICAgdHV0b3JpYWxfZnJlZV9kYXlzOiAnYXJ0ZW1pc0FwcC5wYWdlcy50dXRvcmlhbEZyZWVQZXJpb2RzTWFuYWdlbWVudC50aXRsZScsXG4gICAgICAgIHR1dG9yaWFsX2dyb3Vwc19jaGVja2xpc3Q6ICdhcnRlbWlzQXBwLnBhZ2VzLmNoZWNrbGlzdC50aXRsZScsXG4gICAgICAgIGNyZWF0ZV90dXRvcmlhbF9ncm91cHNfY29uZmlndXJhdGlvbjogJ2FydGVtaXNBcHAucGFnZXMuY3JlYXRlVHV0b3JpYWxHcm91cHNDb25maWd1cmF0aW9uLnRpdGxlJyxcbiAgICAgICAgcHJpdmFjeV9zdGF0ZW1lbnQ6ICdhcnRlbWlzQXBwLmxlZ2FsLnByaXZhY3lTdGF0ZW1lbnQudGl0bGUnLFxuICAgICAgICBpbXByaW50OiAnYXJ0ZW1pc0FwcC5sZWdhbC5pbXByaW50LnRpdGxlJyxcbiAgICAgICAgZWRpdF9idWlsZF9wbGFuOiAnYXJ0ZW1pc0FwcC5wcm9ncmFtbWluZ0V4ZXJjaXNlLmJ1aWxkUGxhbkVkaXRvcicsXG4gICAgICAgIHN1c3BpY2lvdXNfYmVoYXZpb3I6ICdhcnRlbWlzQXBwLmV4YW1NYW5hZ2VtZW50LnN1c3BpY2lvdXNCZWhhdmlvci50aXRsZScsXG4gICAgICAgIHN1c3BpY2lvdXNfc2Vzc2lvbnM6ICdhcnRlbWlzQXBwLmV4YW1NYW5hZ2VtZW50LnN1c3BpY2lvdXNCZWhhdmlvci5zdXNwaWNpb3VzU2Vzc2lvbnMudGl0bGUnLFxuICAgICAgICBleGFtX3RpbWVsaW5lOiAnYXJ0ZW1pc0FwcC5leGFtVGltZWxpbmUuYnJlYWRjcnVtYicsXG4gICAgICAgIGlyaXNfc2V0dGluZ3M6ICdhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3MudGl0bGUuYnJlYWRjcnVtYicsXG4gICAgICAgIGJ1aWxkX3F1ZXVlOiAnYXJ0ZW1pc0FwcC5idWlsZFF1ZXVlLnRpdGxlJyxcbiAgICB9O1xuXG4gICAgc3R1ZGVudFBhdGhCcmVhZGNydW1iVHJhbnNsYXRpb25zID0ge1xuICAgICAgICBleGFtczogJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcubWVudS5leGFtcycsXG4gICAgICAgIHRlc3RfZXhhbTogJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcubWVudS50ZXN0RXhhbScsXG4gICAgICAgIGV4ZXJjaXNlczogJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcubWVudS5leGVyY2lzZXMnLFxuICAgICAgICBsZWN0dXJlczogJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcubWVudS5sZWN0dXJlcycsXG4gICAgICAgIGNvbXBldGVuY2llczogJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcubWVudS5jb21wZXRlbmNpZXMnLFxuICAgICAgICBsZWFybmluZ19wYXRoOiAnYXJ0ZW1pc0FwcC5jb3Vyc2VPdmVydmlldy5tZW51LmxlYXJuaW5nUGF0aCcsXG4gICAgICAgIGxlY3R1cmVfdW5pdDogJ2FydGVtaXNBcHAubGVhcm5pbmdQYXRoLmJyZWFkY3J1bWJzLmxlY3R1cmVVbml0JyxcbiAgICAgICAgZXhlcmNpc2U6ICdhcnRlbWlzQXBwLmxlYXJuaW5nUGF0aC5icmVhZGNydW1icy5leGVyY2lzZScsXG4gICAgICAgIHN0YXRpc3RpY3M6ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3Lm1lbnUuc3RhdGlzdGljcycsXG4gICAgICAgIGRpc2N1c3Npb246ICdhcnRlbWlzQXBwLm1ldGlzLmNvbW11bmljYXRpb24ubGFiZWwnLFxuICAgICAgICBtZXNzYWdlczogJ2FydGVtaXNBcHAuY29udmVyc2F0aW9uc0xheW91dC5icmVhZENydW1iTGFiZWwnLFxuICAgICAgICBjb2RlX2VkaXRvcjogJ2FydGVtaXNBcHAuZWRpdG9yLmJyZWFkQ3J1bWJUaXRsZScsXG4gICAgICAgIHBhcnRpY2lwYXRlOiAnYXJ0ZW1pc0FwcC5zdWJtaXNzaW9uLmRldGFpbC50aXRsZScsXG4gICAgICAgIGxpdmU6ICdhcnRlbWlzQXBwLnN1Ym1pc3Npb24uZGV0YWlsLnRpdGxlJyxcbiAgICAgICAgY291cnNlczogJ2FydGVtaXNBcHAuY291cnNlLmhvbWUudGl0bGUnLFxuICAgICAgICBlbnJvbGw6ICdhcnRlbWlzQXBwLnN0dWRlbnREYXNoYm9hcmQuZW5yb2xsLnRpdGxlJyxcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogRmlsbHMgdGhlIGJyZWFkY3J1bWJzIGFycmF5IHdpdGggZW50cmllcyBmb3IgYWRtaW4gYW5kIGNvdXJzZS1tYW5hZ2VtZW50IHJvdXRlc1xuICAgICAqL1xuICAgIHByaXZhdGUgYnVpbGRCcmVhZGNydW1icyhmdWxsVVJJOiBzdHJpbmcpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5icmVhZGNydW1icyA9IFtdO1xuICAgICAgICB0aGlzLmJyZWFkY3J1bWJTdWJzY3JpcHRpb25zPy5mb3JFYWNoKChzdWJzY3JpcHRpb24pID0+IHN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpKTtcbiAgICAgICAgdGhpcy5icmVhZGNydW1iU3Vic2NyaXB0aW9ucyA9IFtdO1xuXG4gICAgICAgIGlmICghZnVsbFVSSSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVGVtcG9yYXJpbHkgcmVzdHJpY3Qgcm91dGVzXG4gICAgICAgIGlmICghZnVsbFVSSS5zdGFydHNXaXRoKCcvYWRtaW4nKSAmJiAhZnVsbFVSSS5zdGFydHNXaXRoKCcvY291cnNlLW1hbmFnZW1lbnQnKSAmJiAhZnVsbFVSSS5zdGFydHNXaXRoKCcvY291cnNlcycpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyB0cnkgY2F0Y2ggZm9yIGV4dHJhIHNhZmV0eSBtZWFzdXJlc1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgbGV0IGN1cnJlbnRQYXRoID0gJy8nO1xuXG4gICAgICAgICAgICAvLyBSZW1vdmUgdGhlIGxlYWRpbmcgc2xhc2hcbiAgICAgICAgICAgIGxldCB1cmkgPSBmdWxsVVJJLnN1YnN0cmluZygxKTtcblxuICAgICAgICAgICAgLy8gUmVtb3ZlIGFueSBxdWVyeSBwYXJhbWV0ZXJzXG4gICAgICAgICAgICBjb25zdCBxdWVzdGlvbk1hcmsgPSB1cmkuaW5kZXhPZignPycpO1xuICAgICAgICAgICAgaWYgKHF1ZXN0aW9uTWFyayA+PSAwKSB7XG4gICAgICAgICAgICAgICAgdXJpID0gdXJpLnN1YnN0cmluZygwLCBxdWVzdGlvbk1hcmspO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBHbyB0aHJvdWdoIGFsbCBzZWdtZW50cyBvZiB0aGUgcm91dGUgc3RhcnRpbmcgZnJvbSB0aGUgcm9vdFxuICAgICAgICAgICAgZm9yIChjb25zdCBzZWdtZW50IG9mIHVyaS5zcGxpdCgnLycpKSB7XG4gICAgICAgICAgICAgICAgY3VycmVudFBhdGggKz0gc2VnbWVudCArICcvJztcblxuICAgICAgICAgICAgICAgIC8vIElmIHdlIHBhcnNlIGFuIGVudGl0eSBJRCB3ZSBuZWVkIHRvIGNoZWNrIHRoZSBwcmV2aW91cyBzZWdtZW50IHdoaWNoIGVudGl0eSB0aGUgSUQgcmVmZXJzIHRvXG4gICAgICAgICAgICAgICAgaWYgKCFpc05hTihOdW1iZXIoc2VnbWVudCkpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkQnJlYWRjcnVtYkZvck51bWJlclNlZ21lbnQoY3VycmVudFBhdGgsIHNlZ21lbnQpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkQnJlYWRjcnVtYkZvclVybFNlZ21lbnQoY3VycmVudFBhdGgsIHNlZ21lbnQpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmxhc3RSb3V0ZVVybFNlZ21lbnQgPSBzZWdtZW50O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgLyogZW1wdHkgKi9cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEFkZHMgYSBicmVhZGNydW1iIGRlcGVuZGluZyBvbiB0aGUgZ2l2ZW4gZW50aXR5SUQgYXMgc3RyaW5nXG4gICAgICpcbiAgICAgKiBAcGFyYW0gY3VycmVudFBhdGggdGhlIGNvbXBsZXRlIHBhdGggdXAgdW50aWwgdGhlIGJyZWFkY3J1bWIgdG8gYWRkXG4gICAgICogQHBhcmFtIHNlZ21lbnQgdGhlIGN1cnJlbnQgdXJsIHNlZ21lbnQgKHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiBhbiBlbnRpdHlJRCkgdG8gYWRkIGEgY3J1bWIgZm9yXG4gICAgICovXG4gICAgcHJpdmF0ZSBhZGRCcmVhZGNydW1iRm9yTnVtYmVyU2VnbWVudChjdXJyZW50UGF0aDogc3RyaW5nLCBzZWdtZW50OiBzdHJpbmcpOiB2b2lkIHtcbiAgICAgICAgY29uc3QgaXNTdHVkZW50UGF0aCA9IGN1cnJlbnRQYXRoLnN0YXJ0c1dpdGgoJy9jb3Vyc2VzJyk7XG4gICAgICAgIGlmIChpc1N0dWRlbnRQYXRoKSB7XG4gICAgICAgICAgICBzd2l0Y2ggKHRoaXMubGFzdFJvdXRlVXJsU2VnbWVudCkge1xuICAgICAgICAgICAgICAgIGNhc2UgJ2NvZGUtZWRpdG9yJzpcbiAgICAgICAgICAgICAgICBjYXNlICd0ZXN0LWV4YW0nOlxuICAgICAgICAgICAgICAgIGNhc2UgJ3BhcnRpY2lwYXRlJzpcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRUcmFuc2xhdGlvbkFzQ3J1bWIoY3VycmVudFBhdGgsIHRoaXMubGFzdFJvdXRlVXJsU2VnbWVudCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICBjYXNlICdleGVyY2lzZXMnOlxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZFJlc29sdmVkVGl0bGVBc0NydW1iKEVudGl0eVR5cGUuRVhFUkNJU0UsIFtOdW1iZXIoc2VnbWVudCldLCBjdXJyZW50UGF0aCwgc2VnbWVudCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICBjb25zdCBleGVyY2lzZXNNYXRjaGVyID0gdGhpcy5sYXN0Um91dGVVcmxTZWdtZW50Py5tYXRjaCgvListZXhlcmNpc2VzLyk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChleGVyY2lzZXNNYXRjaGVyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZFJlc29sdmVkVGl0bGVBc0NydW1iKEVudGl0eVR5cGUuRVhFUkNJU0UsIFtOdW1iZXIoc2VnbWVudCldLCBjdXJyZW50UGF0aC5yZXBsYWNlKGV4ZXJjaXNlc01hdGNoZXJbMF0sICdleGVyY2lzZXMnKSwgJ2V4ZXJjaXNlcycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgc3dpdGNoICh0aGlzLmxhc3RSb3V0ZVVybFNlZ21lbnQpIHtcbiAgICAgICAgICAgIC8vIERpc3BsYXlzIHRoZSBwYXRoIHNlZ21lbnQgYXMgYnJlYWRjcnVtYiAobm8gb3RoZXIgdGl0bGUgZXhpc3RzKVxuICAgICAgICAgICAgY2FzZSAnc3lzdGVtLW5vdGlmaWNhdGlvbi1tYW5hZ2VtZW50JzpcbiAgICAgICAgICAgIGNhc2UgJ3RlYW1zJzpcbiAgICAgICAgICAgIGNhc2UgJ2NvZGUtZWRpdG9yJzpcbiAgICAgICAgICAgICAgICB0aGlzLmFkZEJyZWFkY3J1bWIoY3VycmVudFBhdGgsIHNlZ21lbnQsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2NvdXJzZS1tYW5hZ2VtZW50JzpcbiAgICAgICAgICAgIGNhc2UgJ2NvdXJzZXMnOlxuICAgICAgICAgICAgICAgIHRoaXMuYWRkUmVzb2x2ZWRUaXRsZUFzQ3J1bWIoRW50aXR5VHlwZS5DT1VSU0UsIFtOdW1iZXIoc2VnbWVudCldLCBjdXJyZW50UGF0aCwgc2VnbWVudCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdleGVyY2lzZXMnOlxuICAgICAgICAgICAgICAgIC8vIFNwZWNpYWwgY2FzZTogQSByYXcgL2NvdXJzZS1tYW5hZ2VtZW50L1hYWC9leGVyY2lzZXMvWFhYIGRvZXNuJ3Qgd29yaywgd2UgbmVlZCB0byBhZGQgdGhlIGV4ZXJjaXNlIHR5cGVcbiAgICAgICAgICAgICAgICAvLyBGb3IgZXhhbXBsZSAvY291cnNlLW1hbmFnZW1lbnQvWFhYL3Byb2dyYW1taW5nLWV4ZXJjaXNlcy9YWFhcbiAgICAgICAgICAgICAgICB0aGlzLmFkZEV4ZXJjaXNlQ3J1bWIoTnVtYmVyKHNlZ21lbnQpLCBjdXJyZW50UGF0aCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICd0ZXh0LWV4ZXJjaXNlcyc6XG4gICAgICAgICAgICBjYXNlICdtb2RlbGluZy1leGVyY2lzZXMnOlxuICAgICAgICAgICAgY2FzZSAnZmlsZS11cGxvYWQtZXhlcmNpc2VzJzpcbiAgICAgICAgICAgIGNhc2UgJ3Byb2dyYW1taW5nLWV4ZXJjaXNlcyc6XG4gICAgICAgICAgICBjYXNlICdxdWl6LWV4ZXJjaXNlcyc6XG4gICAgICAgICAgICBjYXNlICdhc3Nlc3NtZW50LWRhc2hib2FyZCc6XG4gICAgICAgICAgICAgICAgdGhpcy5hZGRSZXNvbHZlZFRpdGxlQXNDcnVtYihFbnRpdHlUeXBlLkVYRVJDSVNFLCBbTnVtYmVyKHNlZ21lbnQpXSwgY3VycmVudFBhdGgsIHNlZ21lbnQpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnZXhlcmNpc2UtaGludHMnOlxuICAgICAgICAgICAgICAgIC8vIG9idGFpbiB0aGUgZXhlcmNpc2VJZCBvZiB0aGUgY3VycmVudCBwYXRoXG4gICAgICAgICAgICAgICAgLy8gY3VycmVudCBwYXRoIG9mIGZvcm0gJy9jb3Vyc2UtbWFuYWdlbWVudC86Y291cnNlSWQvZXhlcmNpc2VzLzpleGVyY2lzZUlkLy4uLlxuXG4gICAgICAgICAgICAgICAgY29uc3QgZXhlcmNpc2VJZCA9IGN1cnJlbnRQYXRoLnNwbGl0KCcvJylbNF07XG4gICAgICAgICAgICAgICAgdGhpcy5hZGRSZXNvbHZlZFRpdGxlQXNDcnVtYihFbnRpdHlUeXBlLkhJTlQsIFtOdW1iZXIoc2VnbWVudCksIE51bWJlcihleGVyY2lzZUlkKV0sIGN1cnJlbnRQYXRoLCBzZWdtZW50KTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2Fwb2xsb24tZGlhZ3JhbXMnOlxuICAgICAgICAgICAgICAgIHRoaXMuYWRkUmVzb2x2ZWRUaXRsZUFzQ3J1bWIoRW50aXR5VHlwZS5ESUFHUkFNLCBbTnVtYmVyKHNlZ21lbnQpXSwgY3VycmVudFBhdGgsIHNlZ21lbnQpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnbGVjdHVyZXMnOlxuICAgICAgICAgICAgICAgIHRoaXMuYWRkUmVzb2x2ZWRUaXRsZUFzQ3J1bWIoRW50aXR5VHlwZS5MRUNUVVJFLCBbTnVtYmVyKHNlZ21lbnQpXSwgY3VycmVudFBhdGgsIHNlZ21lbnQpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnY29tcGV0ZW5jaWVzJzpcbiAgICAgICAgICAgICAgICB0aGlzLmFkZFJlc29sdmVkVGl0bGVBc0NydW1iKEVudGl0eVR5cGUuQ09NUEVURU5DWSwgW051bWJlcihzZWdtZW50KV0sIGN1cnJlbnRQYXRoLCBzZWdtZW50KTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2V4YW1zJzpcbiAgICAgICAgICAgICAgICB0aGlzLnJvdXRlRXhhbUlkID0gTnVtYmVyKHNlZ21lbnQpO1xuICAgICAgICAgICAgICAgIHRoaXMuYWRkUmVzb2x2ZWRUaXRsZUFzQ3J1bWIoRW50aXR5VHlwZS5FWEFNLCBbdGhpcy5yb3V0ZUV4YW1JZF0sIGN1cnJlbnRQYXRoLCBzZWdtZW50KTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ29yZ2FuaXphdGlvbi1tYW5hZ2VtZW50JzpcbiAgICAgICAgICAgICAgICB0aGlzLmFkZFJlc29sdmVkVGl0bGVBc0NydW1iKEVudGl0eVR5cGUuT1JHQU5JWkFUSU9OLCBbTnVtYmVyKHNlZ21lbnQpXSwgY3VycmVudFBhdGgsIHNlZ21lbnQpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAndHV0b3JpYWwtZ3JvdXBzJzpcbiAgICAgICAgICAgICAgICB0aGlzLmFkZFJlc29sdmVkVGl0bGVBc0NydW1iKEVudGl0eVR5cGUuVFVUT1JJQUxfR1JPVVAsIFtOdW1iZXIoc2VnbWVudCldLCBjdXJyZW50UGF0aCwgc2VnbWVudCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdpbXBvcnQnOlxuICAgICAgICAgICAgICAgIC8vIFNwZWNpYWwgY2FzZTogRG9uJ3QgZGlzcGxheSB0aGUgSUQgaGVyZSBidXQgdGhlIG5hbWUgZGlyZWN0bHkgKGNsaWNraW5nIHRoZSBJRCB3b3VsZG4ndCB3b3JrKVxuICAgICAgICAgICAgICAgIC8vIFRoaXMgaGFzIHRvIGdvIGluIHRoZSBmdXR1cmVcbiAgICAgICAgICAgICAgICB0aGlzLmFkZFRyYW5zbGF0aW9uQXNDcnVtYihjdXJyZW50UGF0aCwgJ2ltcG9ydCcpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnaW1wb3J0LWZyb20tZmlsZSc6XG4gICAgICAgICAgICAgICAgdGhpcy5hZGRUcmFuc2xhdGlvbkFzQ3J1bWIoY3VycmVudFBhdGgsICdpbXBvcnQtZnJvbS1maWxlJyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdzdXNwaWNpb3VzLWJlaGF2aW9yJzpcbiAgICAgICAgICAgICAgICB0aGlzLmFkZFRyYW5zbGF0aW9uQXNDcnVtYihjdXJyZW50UGF0aCwgJ3N1c3BpY2lvdXMtYmVoYXZpb3InKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3N1c3BpY2lvdXMtc2Vzc2lvbnMnOlxuICAgICAgICAgICAgICAgIHRoaXMuYWRkVHJhbnNsYXRpb25Bc0NydW1iKGN1cnJlbnRQYXRoLCAnc3VzcGljaW91cy1zZXNzaW9ucycpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnZXhhbXBsZS1zdWJtaXNzaW9ucyc6XG4gICAgICAgICAgICAgICAgLy8gU3BlY2lhbCBjYXNlOiBEb24ndCBkaXNwbGF5IHRoZSBJRCBoZXJlIGJ1dCB0aGUgbmFtZSBkaXJlY3RseSAoY2xpY2tpbmcgdGhlIElEIHdvdWxkbid0IHdvcmspXG4gICAgICAgICAgICAgICAgdGhpcy5hZGRUcmFuc2xhdGlvbkFzQ3J1bWIoY3VycmVudFBhdGgsICdleGFtcGxlLXN1Ym1pc3Npb24tZWRpdG9yJyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAvLyBObyBicmVhZGNydW1icyBmb3IgdGhvc2Ugc2VnbWVudHNcbiAgICAgICAgICAgIGNhc2UgJ2NvbXBldGVuY3ktbWFuYWdlbWVudCc6XG4gICAgICAgICAgICBjYXNlICd1bml0LW1hbmFnZW1lbnQnOlxuICAgICAgICAgICAgY2FzZSAnZXhlcmNpc2UtZ3JvdXBzJzpcbiAgICAgICAgICAgIGNhc2UgJ3N0dWRlbnQtZXhhbXMnOlxuICAgICAgICAgICAgY2FzZSAndGVzdC1ydW5zJzpcbiAgICAgICAgICAgIGNhc2UgJ21jLXF1ZXN0aW9uLXN0YXRpc3RpYyc6XG4gICAgICAgICAgICBjYXNlICdkbmQtcXVlc3Rpb24tc3RhdGlzdGljJzpcbiAgICAgICAgICAgIGNhc2UgJ3NhLXF1ZXN0aW9uLXN0YXRpc3RpYyc6XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQWRkcyBhIGJyZWFkY3J1bWIgZm9yIHRoZSBnaXZlbiB1cmwgc2VnbWVudFxuICAgICAqXG4gICAgICogQHBhcmFtIGN1cnJlbnRQYXRoIHRoZSBjb21wbGV0ZSBwYXRoIHVwIHVudGlsIHRoZSBicmVhZGNydW1iIHRvIGFkZFxuICAgICAqIEBwYXJhbSBzZWdtZW50IHRoZSBjdXJyZW50IHVybCBzZWdtZW50IHRvIGFkZCBhICh0cmFuc2xhdGVkKSBjcnVtYiBmb3JcbiAgICAgKi9cbiAgICBwcml2YXRlIGFkZEJyZWFkY3J1bWJGb3JVcmxTZWdtZW50KGN1cnJlbnRQYXRoOiBzdHJpbmcsIHNlZ21lbnQ6IHN0cmluZyk6IHZvaWQge1xuICAgICAgICBjb25zdCBpc1N0dWRlbnRQYXRoID0gY3VycmVudFBhdGguc3RhcnRzV2l0aCgnL2NvdXJzZXMnKTtcblxuICAgICAgICBpZiAoaXNTdHVkZW50UGF0aCkge1xuICAgICAgICAgICAgY29uc3QgZXhlcmNpc2VzTWF0Y2hlciA9IHNlZ21lbnQ/Lm1hdGNoKC8uKy1leGVyY2lzZXMvKTtcbiAgICAgICAgICAgIGlmIChleGVyY2lzZXNNYXRjaGVyKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5hZGRUcmFuc2xhdGlvbkFzQ3J1bWIoY3VycmVudFBhdGgucmVwbGFjZShleGVyY2lzZXNNYXRjaGVyWzBdLCAnZXhlcmNpc2VzJyksICdleGVyY2lzZXMnKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBXaGVuIHdlJ3JlIG5vdCBkZWFsaW5nIHdpdGggYW4gSUQgd2UgbmVlZCB0byB0cmFuc2xhdGUgdGhlIGN1cnJlbnQgcGFydFxuICAgICAgICAvLyBUaGUgdHJhbnNsYXRpb24gbWlnaHQgc3RpbGwgZGVwZW5kIG9uIHRoZSBwcmV2aW91cyBwYXJ0c1xuICAgICAgICBzd2l0Y2ggKHNlZ21lbnQpIHtcbiAgICAgICAgICAgIC8vIE5vIGJyZWFkY3J1bWJzIGZvciB0aG9zZSBzZWdtZW50c1xuICAgICAgICAgICAgY2FzZSAncmVzZXQnOlxuICAgICAgICAgICAgY2FzZSAnZ3JvdXBzJzpcbiAgICAgICAgICAgIGNhc2UgJ2NvZGUtZWRpdG9yJzpcbiAgICAgICAgICAgIGNhc2UgJ2FkbWluJzpcbiAgICAgICAgICAgIGNhc2UgJ2lkZSc6XG4gICAgICAgICAgICBjYXNlICd0ZXh0LXVuaXRzJzpcbiAgICAgICAgICAgIGNhc2UgJ2V4ZXJjaXNlLXVuaXRzJzpcbiAgICAgICAgICAgIGNhc2UgJ2F0dGFjaG1lbnQtdW5pdHMnOlxuICAgICAgICAgICAgY2FzZSAndmlkZW8tdW5pdHMnOlxuICAgICAgICAgICAgY2FzZSAnZ3JhZGluZyc6XG4gICAgICAgICAgICBjYXNlICdtYy1xdWVzdGlvbi1zdGF0aXN0aWMnOlxuICAgICAgICAgICAgY2FzZSAnZG5kLXF1ZXN0aW9uLXN0YXRpc3RpYyc6XG4gICAgICAgICAgICBjYXNlICdzYS1xdWVzdGlvbi1zdGF0aXN0aWMnOlxuICAgICAgICAgICAgY2FzZSAndGVzdC1leGFtJzpcbiAgICAgICAgICAgIGNhc2UgJ3BhcnRpY2lwYXRlJzpcbiAgICAgICAgICAgIGNhc2UgJ292ZXJ2aWV3JzpcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2V4YW1wbGUtc3VibWlzc2lvbnMnOlxuICAgICAgICAgICAgICAgIC8vIEhpZGUgZXhhbXBsZSBzdWJtaXNzaW9uIGRhc2hib2FyZCBmb3Igbm9uIGluc3RydWN0b3IgdXNlcnNcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5hY2NvdW50U2VydmljZS5oYXNBbnlBdXRob3JpdHlEaXJlY3QoW0F1dGhvcml0eS5BRE1JTiwgQXV0aG9yaXR5LklOU1RSVUNUT1IsIEF1dGhvcml0eS5FRElUT1JdKSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZFRyYW5zbGF0aW9uQXNDcnVtYihjdXJyZW50UGF0aCwgc2VnbWVudCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnc3VibWlzc2lvbnMnOlxuICAgICAgICAgICAgICAgIC8vIG9ubHkgYSBzY29yZXMgbGlzdCBleGlzdHMsIG5vIHNwZWNpYWwgb25lIGZvciBzdWJtaXNzaW9uc1xuICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRMaW5rID0gY3VycmVudFBhdGgucmVwbGFjZSgnL3N1Ym1pc3Npb25zLycsICcvc2NvcmVzLycpO1xuICAgICAgICAgICAgICAgIHRoaXMuYWRkVHJhbnNsYXRpb25Bc0NydW1iKHVwZGF0ZWRMaW5rLCAnc3VibWlzc2lvbnMnKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgLy8gU3BlY2lhbCBjYXNlczpcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5sYXN0Um91dGVVcmxTZWdtZW50ID09PSAndXNlci1tYW5hZ2VtZW50Jykge1xuICAgICAgICAgICAgICAgICAgICAvLyAtIFVzZXJzIGRpc3BsYXkgdGhlaXIgbG9naW4gbmFtZSBkaXJlY3RseSBhcyBjcnVtYlxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEJyZWFkY3J1bWIoY3VycmVudFBhdGgsIHNlZ21lbnQsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmxhc3RSb3V0ZVVybFNlZ21lbnQgPT09ICdleGFtcGxlLXN1Ym1pc3Npb25zJykge1xuICAgICAgICAgICAgICAgICAgICAvLyAtIENyZWF0aW5nIGEgbmV3IGV4YW1wbGUgc3VibWlzc2lvbiBzaG91bGQgZGlzcGxheSB0aGUgdGV4dCBmb3IgZXhhbXBsZSBzdWJtaXNzaW9uc1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZFRyYW5zbGF0aW9uQXNDcnVtYihjdXJyZW50UGF0aCwgJ2V4YW1wbGUtc3VibWlzc2lvbi1lZGl0b3InKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmxhc3RSb3V0ZVVybFNlZ21lbnQgPT09ICdncmFkaW5nJykge1xuICAgICAgICAgICAgICAgICAgICAvLyAtIE9wZW5pbmcgYSBncmFkaW5nIHRhYiBzaG91bGQgb25seSBkaXNwbGF5IHRoZSB0ZXh0IGZvciBncmFkaW5nXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkVHJhbnNsYXRpb25Bc0NydW1iKGN1cnJlbnRQYXRoLCAnZ3JhZGluZycpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMubGFzdFJvdXRlVXJsU2VnbWVudCA9PT0gJ2NvZGUtZWRpdG9yJyAmJiBzZWdtZW50ID09PSAnbmV3Jykge1xuICAgICAgICAgICAgICAgICAgICAvLyAtIFRoaXMgcm91dGUgaXMgYm9ndXMgYW5kIG5lZWRzIHRvIGJlIHJlcGxhY2VkIGluIHRoZSBmdXR1cmUsIGRpc3BsYXkgbm8gY3J1bWJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmxhc3RSb3V0ZVVybFNlZ21lbnQ/LmVuZHNXaXRoKCctZXhlcmNpc2VzJykgJiYgc2VnbWVudCA9PT0gJ2ltcG9ydCcpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gLSBUaGlzIHJvdXRlIGlzIGJvZ3VzIGFuZCBuZWVkcyB0byBiZSByZXBsYWNlZCBpbiB0aGUgZnV0dXJlLCBkaXNwbGF5IG5vIGNydW1iXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5sYXN0Um91dGVVcmxTZWdtZW50ID09PSAnZXhlcmNpc2UtZ3JvdXBzJykge1xuICAgICAgICAgICAgICAgICAgICAvLyAtIERvbid0IGRpc3BsYXkgJzx0eXBlPi1leGVyY2lzZXMnIGJlY2F1c2UgaXQgaGFzIG5vIGFzc29jaWF0ZWQgcm91dGVcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmxhc3RSb3V0ZVVybFNlZ21lbnQgPT09ICdleGFtcycgJiYgc2VnbWVudCA9PT0gJ2ltcG9ydCcpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gVGhpcyByb3V0ZSBpcyBvbmx5IHVzZWQgaW50ZXJuYWxseSB3aGVuIG9wZW5pbmcgdGhlIGV4YW0gaW1wb3J0IG1vZGFsIGFuZCB0aGVyZWZvcmUgc2hvdWxkbid0IGJlIGRpc3BsYXllZC5cbiAgICAgICAgICAgICAgICAgICAgLy8gV2hlbiBvcGVuaW5nIHRoZSBleGFtLXVwZGF0ZS5jb21wb25lbnQsIHRoZSBpZCBvZiB0aGUgdG8gYmUgaW1wb3J0ZWQgZXhhbSBpcyBhcHBlbmRlZCAoLT4gY2FzZSBgaW1wb3J0YCkuXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHRoaXMuYWRkVHJhbnNsYXRpb25Bc0NydW1iKGN1cnJlbnRQYXRoLCBzZWdtZW50KTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEFwcGVuZHMgYSBicmVhZGNydW1iIHRvIHRoZSBsaXN0IG9mIGJyZWFkY3J1bWJzXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdXJpIHRoZSB1cmkvcGF0aCBmb3IgdGhlIGJyZWFkY3J1bWJcbiAgICAgKiBAcGFyYW0gbGFiZWwgdGhlIGRpc3BsYXllZCBsYWJlbCBmb3IgdGhlIGJyZWFkY3J1bWJcbiAgICAgKiBAcGFyYW0gdHJhbnNsYXRlIGlmIHRoZSBsYWJlbCBzaG91bGQgYmUgdHJhbnNsYXRlZFxuICAgICAqIEByZXR1cm4gdGhlIGNyZWF0ZWQgYnJlYWRjcnVtYiBvYmplY3RcbiAgICAgKi9cbiAgICBwcml2YXRlIGFkZEJyZWFkY3J1bWIodXJpOiBzdHJpbmcsIGxhYmVsOiBzdHJpbmcsIHRyYW5zbGF0ZTogYm9vbGVhbik6IEJyZWFkY3J1bWIge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXRCcmVhZGNydW1iKHVyaSwgbGFiZWwsIHRyYW5zbGF0ZSwgdGhpcy5icmVhZGNydW1icy5sZW5ndGgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNldHMgYSBicmVhZGNydW1iIGluIHRoZSBsaXN0IG9mIGJyZWFkY3J1bWJzIGF0IHRoZSBnaXZlbiBpbmRleFxuICAgICAqXG4gICAgICogQHBhcmFtIHVyaSB0aGUgdXJpL3BhdGggZm9yIHRoZSBicmVhZGNydW1iXG4gICAgICogQHBhcmFtIGxhYmVsIHRoZSBkaXNwbGF5ZWQgbGFiZWwgZm9yIHRoZSBicmVhZGNydW1iXG4gICAgICogQHBhcmFtIHRyYW5zbGF0ZSBpZiB0aGUgbGFiZWwgc2hvdWxkIGJlIHRyYW5zbGF0ZWRcbiAgICAgKiBAcGFyYW0gaW5kZXggdGhlIGluZGV4IG9mIHRoZSBicmVhZGNydW1icyBhcnJheSB0byBzZXQgdGhlIGJyZWFkY3J1bWIgYXRcbiAgICAgKiBAcmV0dXJuIHRoZSBjcmVhdGVkIGJyZWFkY3J1bWIgb2JqZWN0XG4gICAgICovXG4gICAgcHJpdmF0ZSBzZXRCcmVhZGNydW1iKHVyaTogc3RyaW5nLCBsYWJlbDogc3RyaW5nLCB0cmFuc2xhdGU6IGJvb2xlYW4sIGluZGV4OiBudW1iZXIpOiBCcmVhZGNydW1iIHtcbiAgICAgICAgY29uc3QgY3J1bWIgPSBuZXcgQnJlYWRjcnVtYigpO1xuICAgICAgICBjcnVtYi5sYWJlbCA9IGxhYmVsO1xuICAgICAgICBjcnVtYi50cmFuc2xhdGUgPSB0cmFuc2xhdGU7XG4gICAgICAgIGNydW1iLnVyaSA9IHVyaTtcbiAgICAgICAgdGhpcy5icmVhZGNydW1ic1tpbmRleF0gPSBjcnVtYjtcbiAgICAgICAgcmV0dXJuIGNydW1iO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVzZXMgdGhlIHNlcnZlciByZXNwb25zZSB0byBhZGQgYSB0aXRsZSBmb3IgYSBicmVhZGNydW1iXG4gICAgICogV2hpbGUgd2FpdGluZyBmb3IgdGhlIHJlc3BvbnNlIG9yIGluIGNhc2Ugb2YgYW4gZXJyb3IgdGhlIHNlZ21lbnQgaXMgZGlzcGxheWVkIGRpcmVjdGx5IGFzIGZhbGxiYWNrXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdHlwZSB0aGUgdHlwZSBvZiB0aGUgZW50aXR5XG4gICAgICogQHBhcmFtIGlkcyB0aGUgaWRzIG9mIHRoZSBlbnRpdHlcbiAgICAgKiBAcGFyYW0gdXJpIHRoZSB1cmkvcGF0aCBmb3IgdGhlIGJyZWFkY3J1bWJcbiAgICAgKiBAcGFyYW0gc2VnbWVudCB0aGUgY3VycmVudCB1cmwgc2VnbWVudCB0byBhZGQgYSBicmVhZGNydW1iIGZvclxuICAgICAqL1xuICAgIHByaXZhdGUgYWRkUmVzb2x2ZWRUaXRsZUFzQ3J1bWIodHlwZTogRW50aXR5VHlwZSwgaWRzOiBudW1iZXJbXSwgdXJpOiBzdHJpbmcsIHNlZ21lbnQ6IHN0cmluZyk6IHZvaWQge1xuICAgICAgICAvLyBJbnNlcnQgdGhlIHNlZ21lbnQgdW50aWwgd2UgZmV0Y2hlZCBhIHRpdGxlIGZyb20gdGhlIHNlcnZlciB0byBpbnNlcnQgYXQgdGhlIGNvcnJlY3QgaW5kZXhcbiAgICAgICAgbGV0IGNydW1iID0gdGhpcy5hZGRCcmVhZGNydW1iKHVyaSwgc2VnbWVudCwgZmFsc2UpO1xuXG4gICAgICAgIHRoaXMuYnJlYWRjcnVtYlN1YnNjcmlwdGlvbnMucHVzaChcbiAgICAgICAgICAgIHRoaXMuZW50aXR5VGl0bGVTZXJ2aWNlLmdldFRpdGxlKHR5cGUsIGlkcykuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAodGl0bGU6IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjcnVtYiA9IHRoaXMuc2V0QnJlYWRjcnVtYih1cmksIHRpdGxlLCBmYWxzZSwgdGhpcy5icmVhZGNydW1icy5pbmRleE9mKGNydW1iKSk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEFkZHMgYSBsaW5rIHRvIGFuIGV4ZXJjaXNlIHRvIHRoZSBicmVhZGNydW1icyBhcnJheS4gVGhlIGxpbmsgZGVwZW5kcyBvbiB0aGUgdHlwZSBvZiB0aGUgZXhlcmNpc2UsIHNvIHdlIG5lZWQgdG8gZmV0Y2ggaXQgZmlyc3RcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCB0aGUgaWQgb2YgdGhlIGV4ZXJjaXNlXG4gICAgICogQHBhcmFtIGN1cnJlbnRQYXRoIHRoZSBpbml0aWFsIHBhdGggZm9yIHRoZSBicmVhZGNydW1iXG4gICAgICovXG4gICAgcHJpdmF0ZSBhZGRFeGVyY2lzZUNydW1iKGV4ZXJjaXNlSWQ6IG51bWJlciwgY3VycmVudFBhdGg6IHN0cmluZyk6IHZvaWQge1xuICAgICAgICAvLyBBZGQgZHVtbXkgYnJlYWRjcnVtYlxuICAgICAgICBjb25zdCBjcnVtYiA9IHRoaXMuYWRkQnJlYWRjcnVtYignJywgJycsIGZhbHNlKTtcblxuICAgICAgICB0aGlzLmV4ZXJjaXNlU2VydmljZS5maW5kKGV4ZXJjaXNlSWQpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAocmVzcG9uc2U6IEh0dHBSZXNwb25zZTxFeGVyY2lzZT4pID0+IHtcbiAgICAgICAgICAgICAgICAvLyBJZiB0aGUgcmVzcG9uc2UgZG9lc24ndCBjb250YWluIHRoZSBuZWVkZWQgZGF0YSwgcmVtb3ZlIHRoZSBicmVhZGNydW1iIGFzIHdlIGNhbiBub3Qgc3VjY2Vzc2Z1bGx5IGxpbmsgdG8gaXRcbiAgICAgICAgICAgICAgICBpZiAoIXJlc3BvbnNlPy5ib2R5Py50aXRsZSB8fCAhcmVzcG9uc2U/LmJvZHk/LnR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5icmVhZGNydW1icy5zcGxpY2UodGhpcy5icmVhZGNydW1icy5pbmRleE9mKGNydW1iKSwgMSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gSWYgYWxsIGRhdGEgaXMgdGhlcmUsIG92ZXJ3cml0ZSB0aGUgYnJlYWRjcnVtYiB3aXRoIHRoZSBjb3JyZWN0IGxpbmtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRCcmVhZGNydW1iKGN1cnJlbnRQYXRoLnJlcGxhY2UoJy9leGVyY2lzZXMvJywgYC8ke3Jlc3BvbnNlLmJvZHkudHlwZX0tZXhlcmNpc2VzL2ApLCByZXNwb25zZS5ib2R5LnRpdGxlLCBmYWxzZSwgdGhpcy5icmVhZGNydW1icy5pbmRleE9mKGNydW1iKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIC8vIFNhbWUgYXMgaWYgZGF0YSBpc24ndCBhdmFpbGFibGVcbiAgICAgICAgICAgIGVycm9yOiAoKSA9PiB0aGlzLmJyZWFkY3J1bWJzLnNwbGljZSh0aGlzLmJyZWFkY3J1bWJzLmluZGV4T2YoY3J1bWIpLCAxKSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQWRkcyBhIGJyZWFkY3J1bWIgd2l0aCBhIHRyYW5zbGF0ZWQgbGFiZWxcbiAgICAgKiBJZiBubyB0cmFuc2xhdGlvbiBjYW4gYmUgZm91bmQgdGhlIGtleSBpcyBkaXNwbGF5ZWRcbiAgICAgKlxuICAgICAqIEBwYXJhbSB1cmkgdGhlIHVyaS9wYXRoIGZvciB0aGUgYnJlYWRjcnVtYlxuICAgICAqIEBwYXJhbSB0cmFuc2xhdGlvbktleSB0aGUgc3RyaW5nIHRvIGluZGV4IHRoZSBicmVhZGNydW1iVHJhbnNsYXRpb24gdGFibGUgd2l0aFxuICAgICAqL1xuICAgIHByaXZhdGUgYWRkVHJhbnNsYXRpb25Bc0NydW1iKHVyaTogc3RyaW5nLCB0cmFuc2xhdGlvbktleTogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIGNvbnN0IGtleSA9IHRyYW5zbGF0aW9uS2V5LnNwbGl0KCctJykuam9pbignXycpO1xuICAgICAgICBpZiAodXJpLnN0YXJ0c1dpdGgoJy9jb3Vyc2VzJykgJiYgdGhpcy5zdHVkZW50UGF0aEJyZWFkY3J1bWJUcmFuc2xhdGlvbnNba2V5XSkge1xuICAgICAgICAgICAgdGhpcy5hZGRCcmVhZGNydW1iKHVyaSwgdGhpcy5zdHVkZW50UGF0aEJyZWFkY3J1bWJUcmFuc2xhdGlvbnNba2V5XSwgdHJ1ZSk7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5icmVhZGNydW1iVHJhbnNsYXRpb25ba2V5XSkge1xuICAgICAgICAgICAgdGhpcy5hZGRCcmVhZGNydW1iKHVyaSwgdGhpcy5icmVhZGNydW1iVHJhbnNsYXRpb25ba2V5XSwgdHJ1ZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBJZiB0aGVyZSBpcyBubyB2YWxpZCBlbnRyeSBpbiB0aGUgbWFwcGluZyBkaXNwbGF5IHRoZSByYXcga2V5IGluc3RlYWQgb2YgYSBcIm5vdCBmb3VuZFwiXG4gICAgICAgICAgICB0aGlzLmFkZEJyZWFkY3J1bWIodXJpLCB0cmFuc2xhdGlvbktleSwgZmFsc2UpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgYSBndWlkZWQgdG91ciBpcyBhdmFpbGFibGUgZm9yIHRoZSBjdXJyZW50IHJvdXRlIHRvIGRpc3BsYXkgdGhlIHN0YXJ0IHRvdXIgYnV0dG9uIGluIHRoZSBhY2NvdW50IG1lbnVcbiAgICAgKi9cbiAgICBzdWJzY3JpYmVGb3JHdWlkZWRUb3VyQXZhaWxhYmlsaXR5KCk6IHZvaWQge1xuICAgICAgICAvLyBDaGVjayBhdmFpbGFiaWxpdHkgYWZ0ZXIgZmlyc3Qgc3Vic2NyaWJlIGNhbGwgc2luY2UgdGhlIHJvdXRlciBldmVudCBiZWVuIHRyaWdnZXJlZCBhbHJlYWR5XG4gICAgICAgIHRoaXMuZ3VpZGVkVG91clNlcnZpY2UuZ2V0R3VpZGVkVG91ckF2YWlsYWJpbGl0eVN0cmVhbSgpLnN1YnNjcmliZSgoaXNBdmFpbGFibGUpID0+IHtcbiAgICAgICAgICAgIHRoaXMuaXNUb3VyQXZhaWxhYmxlID0gaXNBdmFpbGFibGU7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGNoYW5nZUxhbmd1YWdlKGxhbmd1YWdlS2V5OiBzdHJpbmcpIHtcbiAgICAgICAgaWYgKHRoaXMuY3VyckFjY291bnQpIHtcbiAgICAgICAgICAgIHRoaXMuYWNjb3VudFNlcnZpY2UudXBkYXRlTGFuZ3VhZ2UobGFuZ3VhZ2VLZXkpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UudXNlKGxhbmd1YWdlS2V5KTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGVycm9yOiAoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiBvbkVycm9yKHRoaXMuYWxlcnRTZXJ2aWNlLCBlcnJvciksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMudHJhbnNsYXRlU2VydmljZS51c2UobGFuZ3VhZ2VLZXkpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgY29sbGFwc2VOYXZiYXIoKSB7XG4gICAgICAgIHRoaXMuaXNOYXZiYXJDb2xsYXBzZWQgPSB0cnVlO1xuICAgIH1cblxuICAgIGlzQXV0aGVudGljYXRlZCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuYWNjb3VudFNlcnZpY2UuaXNBdXRoZW50aWNhdGVkKCk7XG4gICAgfVxuXG4gICAgbG9nb3V0KCkge1xuICAgICAgICB0aGlzLmNvbGxhcHNlTmF2YmFyKCk7XG4gICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFsnLyddKS50aGVuKChyZXMpID0+IHtcbiAgICAgICAgICAgIGlmIChyZXMpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnBhcnRpY2lwYXRpb25XZWJzb2NrZXRTZXJ2aWNlLnJlc2V0TG9jYWxDYWNoZSgpO1xuICAgICAgICAgICAgICAgIHRoaXMubG9naW5TZXJ2aWNlLmxvZ291dCh0cnVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgdG9nZ2xlTmF2YmFyKCkge1xuICAgICAgICB0aGlzLmlzTmF2YmFyQ29sbGFwc2VkID0gIXRoaXMuaXNOYXZiYXJDb2xsYXBzZWQ7XG4gICAgfVxuXG4gICAgZ2V0SW1hZ2VVcmwoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmFjY291bnRTZXJ2aWNlLmdldEltYWdlVXJsKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGV0ZXJtaW5lIHRoZSBsYWJlbCBmb3IgaW5pdGlhdGluZyB0aGUgZ3VpZGVkIHRvdXIgYmFzZWQgb24gdGhlIGxhc3Qgc2VlbiB0b3VyIHN0ZXBcbiAgICAgKi9cbiAgICBndWlkZWRUb3VySW5pdExhYmVsKCk6IHN0cmluZyB7XG4gICAgICAgIHN3aXRjaCAodGhpcy5ndWlkZWRUb3VyU2VydmljZS5nZXRMYXN0U2VlblRvdXJTdGVwRm9ySW5pdCgpKSB7XG4gICAgICAgICAgICBjYXNlIC0xOiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICdnbG9iYWwubWVudS5yZXN0YXJ0VHV0b3JpYWwnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAwOiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICdnbG9iYWwubWVudS5zdGFydFR1dG9yaWFsJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRlZmF1bHQ6IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2dsb2JhbC5tZW51LmNvbnRpbnVlVHV0b3JpYWwnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU3Vic2NyaWJlcyB0byBuYXZpZ2F0aW9uIGVuZCBldmVudHMgdG8gbG9vayBmb3IgYW4gZXhhbSBpZCBpbiB0aGUgVVJMIHdoaWNoIGluZGljYXRlcyB0aGF0IHdlJ3JlIGluIHRoZSBzdHVkZW50IHZpZXcgb2YgYW4gZXhhbS5cbiAgICAgKi9cbiAgICBzdWJzY3JpYmVUb05hdmlnYXRpb25FdmVudHNGb3JFeGFtSWQoKSB7XG4gICAgICAgIHRoaXMucm91dGVyRXZlbnRTdWJzY3JpcHRpb24gPSB0aGlzLnJvdXRlci5ldmVudHMucGlwZShmaWx0ZXIoKGV2ZW50OiBFdmVudCkgPT4gZXZlbnQgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uRW5kKSkuc3Vic2NyaWJlKChldmVudDogTmF2aWdhdGlvbkVuZCkgPT4ge1xuICAgICAgICAgICAgaWYgKGV2ZW50LnVybC5pbmNsdWRlcygnbWFuYWdlbWVudCcpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5leGFtSWQgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLnJvdXRlLnJvb3QuZmlyc3RDaGlsZD8ucGFyYW1NYXAucGlwZShtYXAoKHBhcmFtcykgPT4gcGFyYW1zLmdldCgnZXhhbUlkJykpKS5zdWJzY3JpYmUoKGV4YW1JZCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuZXhhbUlkID0gZXhhbUlkID8gTnVtYmVyKGV4YW1JZCkgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0V4YW1BY3RpdmUoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiB0aGUgc3R1ZGVudCBpcyBjdXJyZW50bHkgd29ya2luZyBvbiBhbiBhY3RpdmUgZXhhbS5cbiAgICAgKiBJZiB5ZXMsIGhpZGUgc29tZSBlbGVtZW50cyBsaWtlIG5vdGlmaWNhdGlvbnMgYW5kIGJyZWFkY3J1bWJzLlxuICAgICAqIFNjaGVkdWxlcyBhIGNoZWNrIGZvciB0aGlzIGF0IHRoZSBuZXh0IHJlbGV2YW50IHRpbWVzdGFtcCAoZXhhbSBzdGFydCBvciBleGFtIGVuZCwgd2hpY2hldmVyIGNvbWVzIG5leHQpXG4gICAgICovXG4gICAgY2hlY2tFeGFtQWN0aXZlKCkge1xuICAgICAgICBpZiAodGhpcy5leGFtQWN0aXZlQ2hlY2tGdXR1cmUpIHtcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLmV4YW1BY3RpdmVDaGVja0Z1dHVyZSk7XG4gICAgICAgICAgICB0aGlzLmV4YW1BY3RpdmVDaGVja0Z1dHVyZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChcbiAgICAgICAgICAgIHRoaXMuc3R1ZGVudEV4YW0/LmV4YW0gJiZcbiAgICAgICAgICAgIHRoaXMuc3R1ZGVudEV4YW0uZXhhbS5pZCA9PT0gdGhpcy5leGFtSWQgJiZcbiAgICAgICAgICAgICF0aGlzLnN0dWRlbnRFeGFtLmV4YW0udGVzdEV4YW0gJiZcbiAgICAgICAgICAgICF0aGlzLnN0dWRlbnRFeGFtLnRlc3RSdW4gJiZcbiAgICAgICAgICAgIHRoaXMuc3R1ZGVudEV4YW0uZXhhbS5zdGFydERhdGUgJiZcbiAgICAgICAgICAgIHRoaXMuc3R1ZGVudEV4YW0uZXhhbS5lbmREYXRlICYmXG4gICAgICAgICAgICAhdGhpcy5zdHVkZW50RXhhbS5zdWJtaXR0ZWRcbiAgICAgICAgKSB7XG4gICAgICAgICAgICBjb25zdCBzZXJ2ZXJUaW1lID0gdGhpcy5zZXJ2ZXJEYXRlU2VydmljZS5ub3coKTtcbiAgICAgICAgICAgIC8vIEFzIGVuZCBkYXRlLCB3ZSB1c2UgdGhlIHdvcmtpbmcgdGltZSBvZiB0aGlzIHN0dWRlbnQgcGx1cyB0aGUgZ3JhY2UgcGVyaW9kXG4gICAgICAgICAgICBjb25zdCB3b3JraW5nVGltZSA9IHRoaXMuc3R1ZGVudEV4YW0ud29ya2luZ1RpbWUgPz8gdGhpcy5zdHVkZW50RXhhbS5leGFtLndvcmtpbmdUaW1lO1xuICAgICAgICAgICAgY29uc3QgZXhhbUVuZFdpdGhHcmFjZVBlcmlvZCA9ICh3b3JraW5nVGltZSA/IHRoaXMuc3R1ZGVudEV4YW0uZXhhbS5zdGFydERhdGUuYWRkKHdvcmtpbmdUaW1lLCAnc2Vjb25kcycpIDogdGhpcy5zdHVkZW50RXhhbS5leGFtLmVuZERhdGUpLmFkZChcbiAgICAgICAgICAgICAgICB0aGlzLnN0dWRlbnRFeGFtLmV4YW0uZ3JhY2VQZXJpb2QgPz8gMCxcbiAgICAgICAgICAgICAgICAnc2Vjb25kcycsXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgdGhpcy5pc0V4YW1BY3RpdmUgPSBzZXJ2ZXJUaW1lLmlzQmV0d2Vlbih0aGlzLnN0dWRlbnRFeGFtLmV4YW0uc3RhcnREYXRlLCBleGFtRW5kV2l0aEdyYWNlUGVyaW9kKTtcblxuICAgICAgICAgICAgY29uc3QgdGltZVVudGlsU3RhcnQgPSB0aGlzLnN0dWRlbnRFeGFtLmV4YW0uc3RhcnREYXRlLmRpZmYoc2VydmVyVGltZSk7XG4gICAgICAgICAgICBjb25zdCB0aW1lVW50aWxFbmQgPSBleGFtRW5kV2l0aEdyYWNlUGVyaW9kLmRpZmYoc2VydmVyVGltZSk7XG4gICAgICAgICAgICBjb25zdCB0aW1lVW50aWxOZXh0Q2hhbmdlID0gdGltZVVudGlsU3RhcnQgPj0gMCA/IHRpbWVVbnRpbFN0YXJ0IDogdGltZVVudGlsRW5kO1xuICAgICAgICAgICAgaWYgKHRpbWVVbnRpbE5leHRDaGFuZ2UgPiAwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5leGFtQWN0aXZlQ2hlY2tGdXR1cmUgPSBzZXRUaW1lb3V0KHRoaXMuY2hlY2tFeGFtQWN0aXZlLmJpbmQodGhpcyksIHRpbWVVbnRpbE5leHRDaGFuZ2UgKyAxMDApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5pc0V4YW1BY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuY2xhc3MgQnJlYWRjcnVtYiB7XG4gICAgbGFiZWw6IHN0cmluZztcbiAgICB1cmk6IHN0cmluZztcbiAgICB0cmFuc2xhdGU6IGJvb2xlYW47XG59XG4iLCI8bmctdGVtcGxhdGUgI2ljb25NZW51PlxuICAgIDxkaXYgaWQ9XCJuYXZiYXItaWNvbi1tZW51XCIgW25nQ2xhc3NdPVwieyBldmVubHk6IGlzTmF2YmFyTmF2VmVydGljYWwsICdpbi1tZW51JzogaWNvbnNNb3ZlZFRvTWVudSB9XCI+XG4gICAgICAgIEBpZiAoY3VyckFjY291bnQgJiYgIWlzRXhhbUFjdGl2ZSkge1xuICAgICAgICAgICAgPGpoaS1ub3RpZmljYXRpb24tc2lkZWJhcj48L2poaS1ub3RpZmljYXRpb24tc2lkZWJhcj5cbiAgICAgICAgfVxuICAgICAgICA8amhpLXRoZW1lLXN3aXRjaCBbcG9wb3ZlclBsYWNlbWVudF09XCJpY29uc01vdmVkVG9NZW51ID8gJ2JvdHRvbScgOiAnYm90dG9tLXJpZ2h0J1wiPjwvamhpLXRoZW1lLXN3aXRjaD5cbiAgICAgICAgQGlmIChpc0F1dGhlbnRpY2F0ZWQoKSkge1xuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIG5nYkRyb3Bkb3duXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJkcm9wZG93biBwb2ludGVyXCJcbiAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZHluYW1pY1wiXG4gICAgICAgICAgICAgICAgW3BsYWNlbWVudF09XCInYm90dG9tLXJpZ2h0J1wiXG4gICAgICAgICAgICAgICAgcm91dGVyTGlua0FjdGl2ZT1cImFjdGl2ZVwiXG4gICAgICAgICAgICAgICAgW3JvdXRlckxpbmtBY3RpdmVPcHRpb25zXT1cInsgZXhhY3Q6IHRydWUgfVwiXG4gICAgICAgICAgICAgICAgW2F1dG9DbG9zZV09XCJ0cnVlXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImd1aWRlZC10b3VyLWFjY291bnQgbmF2LWxpbmsgZHJvcGRvd24tdG9nZ2xlXCIgbmdiRHJvcGRvd25Ub2dnbGUgaWQ9XCJhY2NvdW50LW1lbnVcIj5cbiAgICAgICAgICAgICAgICAgICAgQGlmICghZ2V0SW1hZ2VVcmwoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFVc2VyXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWN1cnJBY2NvdW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5tZW51LmFjY291bnQubWFpblwiPkFjY291bnQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY3VyckFjY291bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgY3VyckFjY291bnQubG9naW4gfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoZ2V0SW1hZ2VVcmwoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBbc3JjXT1cImdldEltYWdlVXJsKClcIiBjbGFzcz1cInByb2ZpbGUtaW1hZ2UgaW1nLWNpcmNsZVwiIGFsdD1cIkF2YXRhclwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzPVwiZHJvcGRvd24tbWVudSBkcm9wZG93bi1tZW51LWluZGV4XCIgbmdiRHJvcGRvd25NZW51PlxuICAgICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImRyb3Bkb3duLWl0ZW1cIiBbcm91dGVyTGlua109XCJbJy91c2VyLXNldHRpbmdzJ11cIiAoY2xpY2spPVwiY29sbGFwc2VOYXZiYXIoKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQ29nXCIgW2ZpeGVkV2lkdGhdPVwidHJ1ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAnZ2xvYmFsLm1lbnUuc2V0dGluZ3MnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImRyb3Bkb3duLWRpdmlkZXJcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzPVwiZHJvcGRvd24taGVhZGVyIGZ3LW1lZGl1bVwiIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5tZW51Lmxhbmd1YWdlXCI+TGFuZ3VhZ2U8L2g2PlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKGxhbmd1YWdlcyAmJiBsYW5ndWFnZXMubGVuZ3RoID4gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAZm9yIChsYW5ndWFnZSBvZiBsYW5ndWFnZXM7IHRyYWNrIGxhbmd1YWdlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIFtqaGlBY3RpdmVNZW51XT1cImxhbmd1YWdlXCIgKGNsaWNrKT1cImNoYW5nZUxhbmd1YWdlKGxhbmd1YWdlKTsgY29sbGFwc2VOYXZiYXIoKVwiPnt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFuZ3VhZ2UgfCBmaW5kTGFuZ3VhZ2VGcm9tS2V5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fTwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKGlzVG91ckF2YWlsYWJsZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImRyb3Bkb3duLWRpdmlkZXJcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDYgY2xhc3M9XCJkcm9wZG93bi1oZWFkZXIgZnctbWVkaXVtXCIgamhpVHJhbnNsYXRlPVwiZ2xvYmFsLm1lbnUuZ3VpZGVkVHV0b3JpYWxcIj5HdWlkZWQgVHV0b3JpYWw8L2g2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImRyb3Bkb3duLWl0ZW0gZ3VpZGVkLXRvdXJcIiBbamhpVHJhbnNsYXRlXT1cInRoaXMuZ3VpZGVkVG91ckluaXRMYWJlbCgpXCIgKGNsaWNrKT1cInRoaXMuZ3VpZGVkVG91clNlcnZpY2UuaW5pdEd1aWRlZFRvdXIoKVwiPlN0YXJ0IHR1dG9yaWFsPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZHJvcGRvd24tZGl2aWRlclwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICBAaWYgKGlzUmVnaXN0cmF0aW9uRW5hYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIHJvdXRlckxpbms9XCIvYWNjb3VudC9zZXR0aW5nc1wiIHJvdXRlckxpbmtBY3RpdmU9XCJhY3RpdmVcIiAoY2xpY2spPVwiY29sbGFwc2VOYXZiYXIoKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVdyZW5jaFwiIFtmaXhlZFdpZHRoXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5tZW51LmFjY291bnQuc2V0dGluZ3NcIj5TZXR0aW5nczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAocGFzc3dvcmRSZXNldEVuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImRyb3Bkb3duLWl0ZW1cIiByb3V0ZXJMaW5rPVwiL2FjY291bnQvcGFzc3dvcmRcIiByb3V0ZXJMaW5rQWN0aXZlPVwiYWN0aXZlXCIgKGNsaWNrKT1cImNvbGxhcHNlTmF2YmFyKClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFMb2NrXCIgW2ZpeGVkV2lkdGhdPVwidHJ1ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZ2xvYmFsLm1lbnUuYWNjb3VudC5wYXNzd29yZFwiPlBhc3N3b3JkPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjdXJyQWNjb3VudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIChjbGljayk9XCJsb2dvdXQoKVwiIGlkPVwibG9nb3V0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhU2lnbk91dEFsdFwiIFtmaXhlZFdpZHRoXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5tZW51LmFjY291bnQubG9nb3V0XCI+U2lnbiBvdXQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgIDwvZGl2PlxuPC9uZy10ZW1wbGF0ZT5cbjxuYXYgY2xhc3M9XCJuYXZiYXIgamgtbmF2YmFyXCIgW2NsYXNzLmV4cGFuZGVkXT1cIiFpc0NvbGxhcHNlZFwiPlxuICAgIDxkaXYgY2xhc3M9XCJqaC1sb2dvLWNvbnRhaW5lclwiPlxuICAgICAgICA8YSBjbGFzcz1cIm5hdmJhci1icmFuZFwiIHJvdXRlckxpbms9XCIvXCIgKGNsaWNrKT1cImNvbGxhcHNlTmF2YmFyKClcIj5cbiAgICAgICAgICAgIDxpbWcgW3NyY109XCIncHVibGljL2ltYWdlcy9sb2dvLnBuZydcIiBoZWlnaHQ9XCIzMFwiIGFsdD1cIlwiIC8+XG4gICAgICAgICAgICA8ZGl2IGpoaVRyYW5zbGF0ZT1cImdsb2JhbC50aXRsZVwiIGNsYXNzPVwibmF2YmFyLXRpdGxlXCI+QXJ0ZW1pczwvZGl2PlxuICAgICAgICAgICAgPG5nLXRlbXBsYXRlICNnaXRJbmZvPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmdpdC5icmFuY2gnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fToge3sgZ2l0QnJhbmNoTmFtZSB9fSA8YnIgLz5cbiAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuZ2l0LmNvbW1pdCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19OiB7eyBnaXRDb21taXRJZCB9fSA8YnIgLz5cbiAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuZ2l0LnRpbWVzdGFtcCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19OiB7eyBnaXRUaW1lc3RhbXAgfX0gPGJyIC8+XG4gICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmdpdC51c2VybmFtZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19OiB7eyBnaXRVc2VybmFtZSB9fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJuYXZiYXItdmVyc2lvblwiIHBsYWNlbWVudD1cImJvdHRvbVwiIFtuZ2JUb29sdGlwXT1cImdpdEluZm9cIiB0b29sdGlwQ2xhc3M9XCJnaXQtaW5mb1wiIFtkaXNhYmxlVG9vbHRpcF09XCJpblByb2R1Y3Rpb24gJiYgIXRlc3RTZXJ2ZXJcIj5cbiAgICAgICAgICAgICAgICB7eyB2ZXJzaW9uIH19XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9hPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiaW5kaWNhdG9yc1wiPlxuICAgICAgICAgICAgPGpoaS1jb25uZWN0aW9uLXdhcm5pbmcgY2xhc3M9XCJhbGlnbi1zZWxmLWNlbnRlclwiPjwvamhpLWNvbm5lY3Rpb24td2FybmluZz5cbiAgICAgICAgICAgIDxqaGktbG9hZGluZy1ub3RpZmljYXRpb24gY2xhc3M9XCJhbGlnbi1zZWxmLWNlbnRlclwiPjwvamhpLWxvYWRpbmctbm90aWZpY2F0aW9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgQGlmICghaWNvbnNNb3ZlZFRvTWVudSAmJiBpc0NvbGxhcHNlZCkge1xuICAgICAgICAgICAgPG5nLWNvbnRhaW5lciAqbmdUZW1wbGF0ZU91dGxldD1cImljb25NZW51XCI+PC9uZy1jb250YWluZXI+XG4gICAgICAgIH1cbiAgICAgICAgPGRpdiBjbGFzcz1cInRvZ2dsZXItd3JhcHBlclwiPlxuICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICBjbGFzcz1cInRvZ2dsZXJcIlxuICAgICAgICAgICAgICAgIGRhdGEtdG9nZ2xlPVwiY29sbGFwc2VcIlxuICAgICAgICAgICAgICAgIGRhdGEtdGFyZ2V0PVwiI25hdmJhclJlc3BvbnNpdmVcIlxuICAgICAgICAgICAgICAgIGFyaWEtY29udHJvbHM9XCJuYXZiYXJSZXNwb25zaXZlXCJcbiAgICAgICAgICAgICAgICBhcmlhLWV4cGFuZGVkPVwiZmFsc2VcIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJUb2dnbGUgbmF2aWdhdGlvblwiXG4gICAgICAgICAgICAgICAgKGNsaWNrKT1cInRvZ2dsZU5hdmJhcigpXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUJhcnNcIj48L2ZhLWljb24+XG4gICAgICAgICAgICA8L2E+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJuYXZiYXItY29sbGFwc2UgY29sbGFwc2VcIiBpZD1cIm5hdmJhclJlc3BvbnNpdmVcIiBbbmdiQ29sbGFwc2VdPVwiaXNOYXZiYXJDb2xsYXBzZWRcIj5cbiAgICAgICAgPHVsIGNsYXNzPVwibmF2YmFyLW5hdiBtcy1hdXRvXCIgW2NsYXNzLnZlcnRpY2FsXT1cImlzTmF2YmFyTmF2VmVydGljYWxcIj5cbiAgICAgICAgICAgIEBpZiAoY3VyckFjY291bnQgJiYgIWlzRXhhbUFjdGl2ZSkge1xuICAgICAgICAgICAgICAgIDxsaSBjbGFzcz1cIm5hdi1pdGVtXCIgcm91dGVyTGlua0FjdGl2ZT1cImFjdGl2ZVwiIFtyb3V0ZXJMaW5rQWN0aXZlT3B0aW9uc109XCJ7IGV4YWN0OiB0cnVlIH1cIj5cbiAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJndWlkZWQtdG91ci1vdmVydmlldyBuYXYtbGlua1wiIHJvdXRlckxpbms9XCIvY291cnNlc1wiIChjbGljayk9XCJjb2xsYXBzZU5hdmJhcigpXCIgaWQ9XCJvdmVydmlldy1tZW51XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVRoTGFyZ2VcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZ2xvYmFsLm1lbnUub3ZlcnZpZXdcIj5Db3Vyc2UgT3ZlcnZpZXc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgPGxpXG4gICAgICAgICAgICAgICAgKmpoaUhhc0FueUF1dGhvcml0eT1cIlsnUk9MRV9UQScsICdST0xFX0VESVRPUicsICdST0xFX0lOU1RSVUNUT1InLCAnUk9MRV9BRE1JTiddXCJcbiAgICAgICAgICAgICAgICBuZ2JEcm9wZG93blxuICAgICAgICAgICAgICAgIGNsYXNzPVwibmF2LWl0ZW0gZHJvcGRvd24gcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgcm91dGVyTGlua0FjdGl2ZT1cImFjdGl2ZVwiXG4gICAgICAgICAgICAgICAgW3JvdXRlckxpbmtBY3RpdmVPcHRpb25zXT1cInsgZXhhY3Q6IHRydWUgfVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQGlmICghaXNFeGFtQWN0aXZlKSB7XG4gICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiZ3VpZGVkLXRvdXItY291cnNlLWFkbWluIG5hdi1saW5rXCIgcm91dGVyTGluaz1cIi9jb3Vyc2UtbWFuYWdlbWVudFwiIChjbGljayk9XCJjb2xsYXBzZU5hdmJhcigpXCIgaWQ9XCJjb3Vyc2UtYWRtaW4tbWVudVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFUaExpc3RcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZ2xvYmFsLm1lbnUuY291cnNlXCI+Q291cnNlIE1hbmFnZW1lbnQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgPGxpXG4gICAgICAgICAgICAgICAgKmpoaUhhc0FueUF1dGhvcml0eT1cIidST0xFX0FETUlOJ1wiXG4gICAgICAgICAgICAgICAgbmdiRHJvcGRvd25cbiAgICAgICAgICAgICAgICBjbGFzcz1cIm5hdi1pdGVtIGRyb3Bkb3duIHBvaW50ZXJcIlxuICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJkeW5hbWljXCJcbiAgICAgICAgICAgICAgICByb3V0ZXJMaW5rQWN0aXZlPVwiYWN0aXZlXCJcbiAgICAgICAgICAgICAgICBbcm91dGVyTGlua0FjdGl2ZU9wdGlvbnNdPVwieyBleGFjdDogdHJ1ZSB9XCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBAaWYgKCFpc0V4YW1BY3RpdmUpIHtcbiAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJndWlkZWQtdG91ci1hZG1pbiBuYXYtbGluayBkcm9wZG93bi10b2dnbGVcIiBuZ2JEcm9wZG93blRvZ2dsZSBpZD1cImFkbWluLW1lbnVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhVXNlclBsdXNcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZ2xvYmFsLm1lbnUuYWRtaW4ubWFpblwiPlNlcnZlciBBZG1pbmlzdHJhdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8dWwgY2xhc3M9XCJkcm9wZG93bi1tZW51IGRyb3Bkb3duLW1lbnUtaW5kZXhcIiBuZ2JEcm9wZG93bk1lbnU+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIHJvdXRlckxpbms9XCIvYWRtaW4vdXBjb21pbmctZXhhbXMtYW5kLWV4ZXJjaXNlc1wiIHJvdXRlckxpbmtBY3RpdmU9XCJhY3RpdmVcIiAoY2xpY2spPVwiY29sbGFwc2VOYXZiYXIoKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQm9va09wZW5cIiBbZml4ZWRXaWR0aF09XCJ0cnVlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5tZW51LmFkbWluLnVwY29taW5nRXhhbXNBbmRFeGVyY2lzZXNcIj5VcGNvbWluZyBFeGFtcyAmIEV4ZXJjaXNlczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJkcm9wZG93bi1pdGVtXCIgcm91dGVyTGluaz1cIi9hZG1pbi91c2VyLW1hbmFnZW1lbnRcIiByb3V0ZXJMaW5rQWN0aXZlPVwiYWN0aXZlXCIgKGNsaWNrKT1cImNvbGxhcHNlTmF2YmFyKClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVVzZXJcIiBbZml4ZWRXaWR0aF09XCJ0cnVlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5tZW51LmFkbWluLnVzZXJNYW5hZ2VtZW50XCI+VXNlciBtYW5hZ2VtZW50PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImRyb3Bkb3duLWl0ZW1cIiByb3V0ZXJMaW5rPVwiL2FkbWluL29yZ2FuaXphdGlvbi1tYW5hZ2VtZW50XCIgcm91dGVyTGlua0FjdGl2ZT1cImFjdGl2ZVwiIChjbGljayk9XCJjb2xsYXBzZU5hdmJhcigpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFVbml2ZXJzaXR5XCIgW2ZpeGVkV2lkdGhdPVwidHJ1ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJnbG9iYWwubWVudS5hZG1pbi5vcmdhbml6YXRpb25NYW5hZ2VtZW50XCI+T3JnYW5pemF0aW9uIG1hbmFnZW1lbnQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIHJvdXRlckxpbms9XCIvYWRtaW4vc3lzdGVtLW5vdGlmaWNhdGlvbi1tYW5hZ2VtZW50XCIgcm91dGVyTGlua0FjdGl2ZT1cImFjdGl2ZVwiIChjbGljayk9XCJjb2xsYXBzZU5hdmJhcigpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFCZWxsXCIgW2ZpeGVkV2lkdGhdPVwidHJ1ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJnbG9iYWwubWVudS5hZG1pbi5zeXN0ZW1Ob3RpZmljYXRpb25zXCI+U3lzdGVtIG5vdGlmaWNhdGlvbnM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIHJvdXRlckxpbms9XCIvYWRtaW4vZmVhdHVyZS10b2dnbGVzXCIgcm91dGVyTGlua0FjdGl2ZT1cImFjdGl2ZVwiIChjbGljayk9XCJjb2xsYXBzZU5hdmJhcigpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFUb2dnbGVPblwiIFtmaXhlZFdpZHRoXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZ2xvYmFsLm1lbnUuYWRtaW4uZmVhdHVyZVRvZ2dsZXNcIj5GZWF0dXJlIFRvZ2dsZXM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIHJvdXRlckxpbms9XCIvYWRtaW4vdXNlci1zdGF0aXN0aWNzXCIgcm91dGVyTGlua0FjdGl2ZT1cImFjdGl2ZVwiIChjbGljayk9XCJjb2xsYXBzZU5hdmJhcigpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFFeWVcIiBbZml4ZWRXaWR0aF09XCJ0cnVlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5tZW51LmFkbWluLnN0YXRpc3RpY3NcIj5Vc2VyIHN0YXRpc3RpY3M8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIHJvdXRlckxpbms9XCIvYWRtaW4vbWV0cmljc1wiIHJvdXRlckxpbmtBY3RpdmU9XCJhY3RpdmVcIiAoY2xpY2spPVwiY29sbGFwc2VOYXZiYXIoKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhVGFjaG9tZXRlckFsdFwiIFtmaXhlZFdpZHRoXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZ2xvYmFsLm1lbnUuYWRtaW4ubWV0cmljc1wiPk1ldHJpY3M8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIHJvdXRlckxpbms9XCIvYWRtaW4vcHJpdmFjeS1zdGF0ZW1lbnRcIiByb3V0ZXJMaW5rQWN0aXZlPVwiYWN0aXZlXCIgKGNsaWNrKT1cImNvbGxhcHNlTmF2YmFyKClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUxvY2tcIiBbZml4ZWRXaWR0aF09XCJ0cnVlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5tZW51LmFkbWluLnByaXZhY3lTdGF0ZW1lbnRcIj5Qcml2YWN5IHN0YXRlbWVudDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJkcm9wZG93bi1pdGVtXCIgcm91dGVyTGluaz1cIi9hZG1pbi9pbXByaW50XCIgcm91dGVyTGlua0FjdGl2ZT1cImFjdGl2ZVwiIChjbGljayk9XCJjb2xsYXBzZU5hdmJhcigpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFTdGFtcFwiIFtmaXhlZFdpZHRoXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZ2xvYmFsLm1lbnUuYWRtaW4uaW1wcmludFwiPkltcHJpbnQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIHJvdXRlckxpbms9XCIvYWRtaW4vaGVhbHRoXCIgcm91dGVyTGlua0FjdGl2ZT1cImFjdGl2ZVwiIChjbGljayk9XCJjb2xsYXBzZU5hdmJhcigpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFIZWFydFwiIFtmaXhlZFdpZHRoXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZ2xvYmFsLm1lbnUuYWRtaW4uaGVhbHRoXCI+SGVhbHRoPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImRyb3Bkb3duLWl0ZW1cIiByb3V0ZXJMaW5rPVwiL2FkbWluL2NvbmZpZ3VyYXRpb25cIiByb3V0ZXJMaW5rQWN0aXZlPVwiYWN0aXZlXCIgKGNsaWNrKT1cImNvbGxhcHNlTmF2YmFyKClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUxpc3RcIiBbZml4ZWRXaWR0aF09XCJ0cnVlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5tZW51LmFkbWluLmNvbmZpZ3VyYXRpb25cIj5Db25maWd1cmF0aW9uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImRyb3Bkb3duLWl0ZW1cIiByb3V0ZXJMaW5rPVwiL2FkbWluL2F1ZGl0c1wiIHJvdXRlckxpbmtBY3RpdmU9XCJhY3RpdmVcIiAoY2xpY2spPVwiY29sbGFwc2VOYXZiYXIoKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQmVsbFwiIFtmaXhlZFdpZHRoXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZ2xvYmFsLm1lbnUuYWRtaW4uYXVkaXRzXCI+QXVkaXRzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImRyb3Bkb3duLWl0ZW1cIiByb3V0ZXJMaW5rPVwiL2FkbWluL2xvZ3NcIiByb3V0ZXJMaW5rQWN0aXZlPVwiYWN0aXZlXCIgKGNsaWNrKT1cImNvbGxhcHNlTmF2YmFyKClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVRhc2tzXCIgW2ZpeGVkV2lkdGhdPVwidHJ1ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJnbG9iYWwubWVudS5hZG1pbi5sb2dzXCI+TG9nczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgQGlmIChsb2NhbENJQWN0aXZlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJkcm9wZG93bi1pdGVtXCIgcm91dGVyTGluaz1cIi9hZG1pbi9idWlsZC1xdWV1ZVwiIHJvdXRlckxpbmtBY3RpdmU9XCJhY3RpdmVcIiAoY2xpY2spPVwiY29sbGFwc2VOYXZiYXIoKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUxpc3RcIiBbZml4ZWRXaWR0aF09XCJ0cnVlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmJ1aWxkUXVldWUudGl0bGVcIj5CdWlsZCBRdWV1ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAob3BlbkFwaUVuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImRyb3Bkb3duLWl0ZW1cIiBocmVmPVwiYXBpLmh0bWxcIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub3JlZmVycmVyIG5vb3BlbmVyXCIgKGNsaWNrKT1cImNvbGxhcHNlTmF2YmFyKClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFCb29rXCIgW2ZpeGVkV2lkdGhdPVwidHJ1ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZ2xvYmFsLm1lbnUuYWRtaW4uYXBpZG9jc1wiPkFQSTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoaXJpc0VuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImRyb3Bkb3duLWl0ZW1cIiByb3V0ZXJMaW5rPVwiL2FkbWluL2lyaXNcIiByb3V0ZXJMaW5rQWN0aXZlPVwiYWN0aXZlXCIgKGNsaWNrKT1cImNvbGxhcHNlTmF2YmFyKClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFSb2JvdFwiIFtmaXhlZFdpZHRoXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5tZW51LmFkbWluLmlyaXNcIj5JcmlzIFNldHRpbmdzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPCEtLSBqaGlwc3Rlci1uZWVkbGUtYWRkLWVsZW1lbnQtdG8tYWRtaW4tbWVudSAtIEpIaXBzdGVyIHdpbGwgYWRkIGVudGl0aWVzIHRvIHRoZSBhZG1pbiBtZW51IGhlcmUgLS0+XG4gICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICBAaWYgKCFjdXJyQWNjb3VudCAmJiBsYW5ndWFnZXMgJiYgbGFuZ3VhZ2VzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICAgICAgICA8bGkgbmdiRHJvcGRvd24gY2xhc3M9XCJuYXYtaXRlbSBkcm9wZG93biBwb2ludGVyXCIgZGlzcGxheT1cImR5bmFtaWNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJuYXYtbGluayBkcm9wZG93bi10b2dnbGVcIiBuZ2JEcm9wZG93blRvZ2dsZSBpZD1cImxhbmd1YWdlc25hdkJhckRyb3Bkb3duXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUZsYWdcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZ2xvYmFsLm1lbnUubGFuZ3VhZ2VcIj5MYW5ndWFnZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3M9XCJkcm9wZG93bi1tZW51XCIgbmdiRHJvcGRvd25NZW51PlxuICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAobGFuZ3VhZ2Ugb2YgbGFuZ3VhZ2VzOyB0cmFjayBsYW5ndWFnZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJkcm9wZG93bi1pdGVtXCIgW2poaUFjdGl2ZU1lbnVdPVwibGFuZ3VhZ2VcIiAoY2xpY2spPVwiY2hhbmdlTGFuZ3VhZ2UobGFuZ3VhZ2UpOyBjb2xsYXBzZU5hdmJhcigpXCI+e3sgbGFuZ3VhZ2UgfCBmaW5kTGFuZ3VhZ2VGcm9tS2V5IH19PC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC91bD5cbiAgICAgICAgQGlmICghaXNDb2xsYXBzZWQgfHwgaWNvbnNNb3ZlZFRvTWVudSkge1xuICAgICAgICAgICAgPG5nLWNvbnRhaW5lciAqbmdUZW1wbGF0ZU91dGxldD1cImljb25NZW51XCI+PC9uZy1jb250YWluZXI+XG4gICAgICAgIH1cbiAgICA8L2Rpdj5cbjwvbmF2PlxuPGpoaS1zeXN0ZW0tbm90aWZpY2F0aW9uPjwvamhpLXN5c3RlbS1ub3RpZmljYXRpb24+XG48ZGl2IGNsYXNzPVwiYnJlYWRjcnVtYi1jb250YWluZXJcIj5cbiAgICBAaWYgKCFpc0V4YW1BY3RpdmUgJiYgYnJlYWRjcnVtYnMgJiYgYnJlYWRjcnVtYnMubGVuZ3RoID4gMCkge1xuICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPG9sIGNsYXNzPVwiYnJlYWRjcnVtYlwiPlxuICAgICAgICAgICAgICAgIEBmb3IgKGJyZWFkY3J1bWIgb2YgYnJlYWRjcnVtYnM7IHRyYWNrIGJyZWFkY3J1bWI7IGxldCBpID0gJGluZGV4KSB7XG4gICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzcz1cImJyZWFkY3J1bWItaXRlbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChicmVhZGNydW1iICYmIGJyZWFkY3J1bWIudHJhbnNsYXRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJicmVhZGNydW1iLWxpbmtcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImJyZWFkLWNydW1iLXt7IGkgfX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbcm91dGVyTGlua109XCJicmVhZGNydW1iLnVyaVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdXRlckxpbmtBY3RpdmU9XCJhY3RpdmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbcm91dGVyTGlua0FjdGl2ZU9wdGlvbnNdPVwieyBleGFjdDogdHJ1ZSB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPnt7IGJyZWFkY3J1bWIubGFiZWwgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9hXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChicmVhZGNydW1iICYmICFicmVhZGNydW1iLnRyYW5zbGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYnJlYWRjcnVtYi1saW5rXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJicmVhZC1jcnVtYi1wbGFpbi17eyBpIH19XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3JvdXRlckxpbmtdPVwiYnJlYWRjcnVtYi51cmlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3V0ZXJMaW5rQWN0aXZlPVwiYWN0aXZlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3JvdXRlckxpbmtBY3RpdmVPcHRpb25zXT1cInsgZXhhY3Q6IHRydWUgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID57eyBicmVhZGNydW1iLmxhYmVsIH19PC9hXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvb2w+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbjwvZGl2PlxuPGpoaS1ndWlkZWQtdG91cj48L2poaS1ndWlkZWQtdG91cj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBQcm9maWxlU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvbGF5b3V0cy9wcm9maWxlcy9wcm9maWxlLnNlcnZpY2UnO1xuaW1wb3J0IHsgUHJvZmlsZUluZm8gfSBmcm9tICcuL3Byb2ZpbGUtaW5mby5tb2RlbCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXBhZ2UtcmliYm9uJyxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICA8ZGl2IGNsYXNzPVwiYm94XCI+XG4gICAgICAgICAgICBAaWYgKHJpYmJvbkVudikge1xuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyaWJib24gcmliYm9uLXRvcC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5yaWJib24ue3sgcmliYm9uRW52IH19XCI+e3sgcmliYm9uRW52IH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICBgLFxuICAgIHN0eWxlVXJsczogWydwYWdlLXJpYmJvbi5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIFBhZ2VSaWJib25Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIHByb2ZpbGVJbmZvOiBQcm9maWxlSW5mbztcbiAgICByaWJib25FbnY6IHN0cmluZztcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgcHJvZmlsZVNlcnZpY2U6IFByb2ZpbGVTZXJ2aWNlKSB7fVxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMucHJvZmlsZVNlcnZpY2UuZ2V0UHJvZmlsZUluZm8oKS5zdWJzY3JpYmUoKHByb2ZpbGVJbmZvKSA9PiB7XG4gICAgICAgICAgICBpZiAocHJvZmlsZUluZm8pIHtcbiAgICAgICAgICAgICAgICB0aGlzLnByb2ZpbGVJbmZvID0gcHJvZmlsZUluZm87XG4gICAgICAgICAgICAgICAgdGhpcy5yaWJib25FbnYgPSBwcm9maWxlSW5mby5yaWJib25FbnY7XG4gICAgICAgICAgICAgICAgaWYgKHByb2ZpbGVJbmZvLmluUHJvZHVjdGlvbiAmJiBwcm9maWxlSW5mby50ZXN0U2VydmVyKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmliYm9uRW52ID0gJ3Rlc3QnO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgUm91dGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuXG5pbXBvcnQgeyBOYXZiYXJDb21wb25lbnQgfSBmcm9tICcuL25hdmJhci5jb21wb25lbnQnO1xuXG5leHBvcnQgY29uc3QgbmF2YmFyUm91dGU6IFJvdXRlID0ge1xuICAgIHBhdGg6ICcnLFxuICAgIGNvbXBvbmVudDogTmF2YmFyQ29tcG9uZW50LFxuICAgIG91dGxldDogJ25hdmJhcicsXG59O1xuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktZXJyb3InLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9lcnJvci5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIEVycm9yQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICBlcnJvck1lc3NhZ2U6IHN0cmluZztcbiAgICBlcnJvcjQwMzogYm9vbGVhbjtcbiAgICBlcnJvcjQwNDogYm9vbGVhbjtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlKSB7fVxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMucm91dGUuZGF0YS5zdWJzY3JpYmUoKHJvdXRlRGF0YSkgPT4ge1xuICAgICAgICAgICAgaWYgKHJvdXRlRGF0YS5lcnJvcjQwMykge1xuICAgICAgICAgICAgICAgIHRoaXMuZXJyb3I0MDMgPSByb3V0ZURhdGEuZXJyb3I0MDM7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocm91dGVEYXRhLmVycm9yNDA0KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5lcnJvcjQwNCA9IHJvdXRlRGF0YS5lcnJvcjQwNDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyb3V0ZURhdGEuZXJyb3JNZXNzYWdlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5lcnJvck1lc3NhZ2UgPSByb3V0ZURhdGEuZXJyb3JNZXNzYWdlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG59XG4iLCI8ZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNvbFwiPlxuICAgICAgICAgICAgPGgxIGpoaVRyYW5zbGF0ZT1cImVycm9yLnRpdGxlXCI+RXJyb3IgUGFnZSE8L2gxPlxuXG4gICAgICAgICAgICA8ZGl2IFtoaWRkZW5dPVwiIWVycm9yTWVzc2FnZVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhbGVydCBhbGVydC1kYW5nZXJcIj57eyBlcnJvck1lc3NhZ2UgfX08L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBbaGlkZGVuXT1cIiFlcnJvcjQwM1wiIGNsYXNzPVwiYWxlcnQgYWxlcnQtZGFuZ2VyXCIgamhpVHJhbnNsYXRlPVwiZXJyb3IuaHR0cC40MDNcIj5Zb3UgYXJlIG5vdCBhdXRob3JpemVkIHRvIGFjY2VzcyB0aGlzIHBhZ2UuPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IFtoaWRkZW5dPVwiIWVycm9yNDA0XCIgY2xhc3M9XCJhbGVydCBhbGVydC1kYW5nZXJcIiBqaGlUcmFuc2xhdGU9XCJlcnJvci5odHRwLjQwNFwiPlRoZSBwYWdlIGRvZXMgbm90IGV4aXN0LjwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IFByb2ZpbGVTZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9sYXlvdXRzL3Byb2ZpbGVzL3Byb2ZpbGUuc2VydmljZSc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLW9yaW9uLW91dGRhdGVkJyxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICA8aDIgY2xhc3M9XCJ0ZXh0LWRhbmdlciBmb250LXdlaWdodC1ib2xkXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5vcmlvbi52ZXJzaW9uLm91dGRhdGVkXCI+VGhlIHZlcnNpb24gb2YgT3Jpb24geW91IGFyZSBjdXJyZW50bHkgdXNpbmcgaXMgb3V0ZGF0ZWQhPC9oMj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZvbnQtd2VpZ2h0LWJvbGQgXCI+XG4gICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5vcmlvbi52ZXJzaW9uLnVzZWRWZXJzaW9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08c3BhbiBjbGFzcz1cImJhZGdlIGJnLXBpbGwgYmctZGFuZ2VyXCI+e3sgdmVyc2lvblN0cmluZyB9fTwvc3BhblxuICAgICAgICAgICAgPiFcbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5vcmlvbi52ZXJzaW9uLmFsbG93ZWRWZXJzaW9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08c3BhbiBjbGFzcz1cImJhZGdlIGJnLXBpbGwgYmctaW5mb1wiPnt7IGFsbG93ZWRNaW5pbXVtVmVyc2lvbiB9fTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgYCxcbn0pXG5leHBvcnQgY2xhc3MgT3Jpb25PdXRkYXRlZENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgdmVyc2lvblN0cmluZzogc3RyaW5nO1xuICAgIGFsbG93ZWRNaW5pbXVtVmVyc2lvbjogc3RyaW5nO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgYWN0aXZhdGVkUm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgICAgICBwcml2YXRlIHByb2ZpbGVTZXJ2aWNlOiBQcm9maWxlU2VydmljZSxcbiAgICApIHt9XG5cbiAgICAvKipcbiAgICAgKiBPbiBpbml0aWFsaXphdGlvbiwgc2V0cyB0aGUgdmFsdWVzIG9mIHRoZSB1c2VkIHZlcnNpb24gYW5kIHRoZSBtaW5pbXVtIGFsbG93ZWQgdmVyc2lvbiBvZiBvcmlvbi5cbiAgICAgKi9cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5hY3RpdmF0ZWRSb3V0ZS5xdWVyeVBhcmFtcy5zdWJzY3JpYmUoKHBhcmFtcykgPT4ge1xuICAgICAgICAgICAgdGhpcy52ZXJzaW9uU3RyaW5nID0gcGFyYW1zWyd2ZXJzaW9uU3RyaW5nJ107XG4gICAgICAgICAgICB0aGlzLnByb2ZpbGVTZXJ2aWNlLmdldFByb2ZpbGVJbmZvKCkuc3Vic2NyaWJlKChwcm9maWxlSW5mbykgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuYWxsb3dlZE1pbmltdW1WZXJzaW9uID0gcHJvZmlsZUluZm8uYWxsb3dlZE1pbmltdW1PcmlvblZlcnNpb247XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgUm91dGVzIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcblxuaW1wb3J0IHsgRXJyb3JDb21wb25lbnQgfSBmcm9tICcuL2Vycm9yLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBPcmlvbk91dGRhdGVkQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC9vcmlvbi9vdXRkYXRlZC1wbHVnaW4td2FybmluZy9vcmlvbi1vdXRkYXRlZC5jb21wb25lbnQnO1xuXG5leHBvcnQgY29uc3QgZXJyb3JSb3V0ZTogUm91dGVzID0gW1xuICAgIHtcbiAgICAgICAgcGF0aDogJ2Vycm9yJyxcbiAgICAgICAgY29tcG9uZW50OiBFcnJvckNvbXBvbmVudCxcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgYXV0aG9yaXRpZXM6IFtdLFxuICAgICAgICAgICAgcGFnZVRpdGxlOiAnZXJyb3IudGl0bGUnLFxuICAgICAgICB9LFxuICAgIH0sXG4gICAge1xuICAgICAgICBwYXRoOiAnYWNjZXNzZGVuaWVkJyxcbiAgICAgICAgY29tcG9uZW50OiBFcnJvckNvbXBvbmVudCxcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgYXV0aG9yaXRpZXM6IFtdLFxuICAgICAgICAgICAgcGFnZVRpdGxlOiAnZXJyb3IudGl0bGUnLFxuICAgICAgICAgICAgZXJyb3I0MDM6IHRydWUsXG4gICAgICAgIH0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIHBhdGg6ICdvcmlvbi1vdXRkYXRlZCcsXG4gICAgICAgIGNvbXBvbmVudDogT3Jpb25PdXRkYXRlZENvbXBvbmVudCxcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgYXV0aG9yaXRpZXM6IFtdLFxuICAgICAgICAgICAgcGFnZVRpdGxlOiAnT3V0ZGF0ZWQgT3Jpb24gVmVyc2lvbicsXG4gICAgICAgIH0sXG4gICAgfSxcbl07XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUm91dGVyTW9kdWxlLCBSb3V0ZXMgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgbmF2YmFyUm91dGUgfSBmcm9tICdhcHAvc2hhcmVkL2xheW91dHMvbmF2YmFyL25hdmJhci5yb3V0ZSc7XG5pbXBvcnQgeyBlcnJvclJvdXRlIH0gZnJvbSAnYXBwL3NoYXJlZC9sYXlvdXRzL2Vycm9yL2Vycm9yLnJvdXRlJztcbmltcG9ydCB7IEFydGVtaXNOYXZpZ2F0aW9uVXRpbFNlcnZpY2UgfSBmcm9tICdhcHAvdXRpbHMvbmF2aWdhdGlvbi51dGlscyc7XG5pbXBvcnQgeyBBYm91dElyaXNDb21wb25lbnQgfSBmcm9tICdhcHAvaXJpcy9hYm91dC1pcmlzL2Fib3V0LWlyaXMuY29tcG9uZW50JztcblxuY29uc3QgTEFZT1VUX1JPVVRFUzogUm91dGVzID0gW25hdmJhclJvdXRlLCAuLi5lcnJvclJvdXRlXTtcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbXG4gICAgICAgIFJvdXRlck1vZHVsZS5mb3JSb290KFxuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgIC4uLkxBWU9VVF9ST1VURVMsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBwYXRoOiAnYWRtaW4nLFxuICAgICAgICAgICAgICAgICAgICBsb2FkQ2hpbGRyZW46ICgpID0+IGltcG9ydCgnLi9hZG1pbi9hZG1pbi5tb2R1bGUnKS50aGVuKChtKSA9PiBtLkFydGVtaXNBZG1pbk1vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdhY2NvdW50JyxcbiAgICAgICAgICAgICAgICAgICAgbG9hZENoaWxkcmVuOiAoKSA9PiBpbXBvcnQoJy4vYWNjb3VudC9hY2NvdW50Lm1vZHVsZScpLnRoZW4oKG0pID0+IG0uQXJ0ZW1pc0FjY291bnRNb2R1bGUpLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBwYXRoOiAncHJpdmFjeScsXG4gICAgICAgICAgICAgICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KCcuL2NvcmUvbGVnYWwvcHJpdmFjeS5tb2R1bGUnKS50aGVuKChtKSA9PiBtLkFydGVtaXNQcml2YWN5TW9kdWxlKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2ltcHJpbnQnLFxuICAgICAgICAgICAgICAgICAgICBsb2FkQ2hpbGRyZW46ICgpID0+IGltcG9ydCgnLi9jb3JlL2xlZ2FsL2ltcHJpbnQubW9kdWxlJykudGhlbigobSkgPT4gbS5BcnRlbWlzSW1wcmludE1vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdhYm91dCcsXG4gICAgICAgICAgICAgICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KCcuL2NvcmUvYWJvdXQtdXMvYXJ0ZW1pcy1hYm91dC11cy5tb2R1bGUnKS50aGVuKChtb2R1bGUpID0+IG1vZHVsZS5BcnRlbWlzQWJvdXRVc01vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb3Vyc2VzLzpjb3Vyc2VJZC9sZWN0dXJlcy86bGVjdHVyZUlkJyxcbiAgICAgICAgICAgICAgICAgICAgbG9hZENoaWxkcmVuOiAoKSA9PiBpbXBvcnQoJy4vb3ZlcnZpZXcvY291cnNlLWxlY3R1cmVzL2NvdXJzZS1sZWN0dXJlLWRldGFpbHMubW9kdWxlJykudGhlbigobSkgPT4gbS5BcnRlbWlzQ291cnNlTGVjdHVyZURldGFpbHNNb2R1bGUpLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAvLyBUT0RPOiBjaGVjayB0aGF0IHRoZSBMVEkgaW50ZWdyYXRpb24gc3RpbGwgd29ya3MgY29ycmVjdGx5IChpZiBub3QsIHdlIHNob3VsZCBpbXBsZW1lbnQgaXQgZGlmZmVyZW50bHkpXG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb3Vyc2VzLzpjb3Vyc2VJZC9leGVyY2lzZXMvOmV4ZXJjaXNlSWQnLFxuICAgICAgICAgICAgICAgICAgICBsb2FkQ2hpbGRyZW46ICgpID0+IGltcG9ydCgnLi9vdmVydmlldy9leGVyY2lzZS1kZXRhaWxzL2NvdXJzZS1leGVyY2lzZS1kZXRhaWxzLm1vZHVsZScpLnRoZW4oKG0pID0+IG0uQ291cnNlRXhlcmNpc2VEZXRhaWxzTW9kdWxlKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2NvdXJzZXMvOmNvdXJzZUlkL2NvbXBldGVuY2llcy86Y29tcGV0ZW5jeUlkJyxcbiAgICAgICAgICAgICAgICAgICAgbG9hZENoaWxkcmVuOiAoKSA9PiBpbXBvcnQoJy4vb3ZlcnZpZXcvY291cnNlLWNvbXBldGVuY2llcy9jb3Vyc2UtY29tcGV0ZW5jaWVzLWRldGFpbHMubW9kdWxlJykudGhlbigobSkgPT4gbS5BcnRlbWlzQ291cnNlQ29tcGV0ZW5jaWVzRGV0YWlsc01vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb3Vyc2VzLzpjb3Vyc2VJZC90dXRvcmlhbC1ncm91cHMvOnR1dG9yaWFsR3JvdXBJZCcsXG4gICAgICAgICAgICAgICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KCcuL292ZXJ2aWV3L3R1dG9yaWFsLWdyb3VwLWRldGFpbHMvY291cnNlLXR1dG9yaWFsLWdyb3VwLWRldGFpbHMubW9kdWxlJykudGhlbigobSkgPT4gbS5Db3Vyc2VUdXRvcmlhbEdyb3VwRGV0YWlsc01vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAvLyA9PT09PSBURUFNID09PT1cbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb3Vyc2UtbWFuYWdlbWVudC86Y291cnNlSWQvZXhlcmNpc2VzLzpleGVyY2lzZUlkL3RlYW1zJyxcbiAgICAgICAgICAgICAgICAgICAgbG9hZENoaWxkcmVuOiAoKSA9PiBpbXBvcnQoJy4vZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0ubW9kdWxlJykudGhlbigobSkgPT4gbS5BcnRlbWlzVGVhbU1vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb3Vyc2VzLzpjb3Vyc2VJZC9leGVyY2lzZXMvOmV4ZXJjaXNlSWQvdGVhbXMnLFxuICAgICAgICAgICAgICAgICAgICBsb2FkQ2hpbGRyZW46ICgpID0+IGltcG9ydCgnLi9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbS5tb2R1bGUnKS50aGVuKChtKSA9PiBtLkFydGVtaXNUZWFtTW9kdWxlKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIC8vID09PT09IENPVVJTRSBNQU5BR0VNRU5UID09PT09XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBwYXRoOiAnY291cnNlLW1hbmFnZW1lbnQnLFxuICAgICAgICAgICAgICAgICAgICBsb2FkQ2hpbGRyZW46ICgpID0+IGltcG9ydCgnLi9jb3Vyc2UvbWFuYWdlL2NvdXJzZS1tYW5hZ2VtZW50Lm1vZHVsZScpLnRoZW4oKG0pID0+IG0uQXJ0ZW1pc0NvdXJzZU1hbmFnZW1lbnRNb2R1bGUpLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBwYXRoOiAnY291cnNlLW1hbmFnZW1lbnQvOmNvdXJzZUlkL3Byb2dyYW1taW5nLWV4ZXJjaXNlcy86ZXhlcmNpc2VJZC9jb2RlLWVkaXRvcicsXG4gICAgICAgICAgICAgICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KCcuL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9tYW5hZ2UvY29kZS1lZGl0b3IvY29kZS1lZGl0b3ItbWFuYWdlbWVudC5tb2R1bGUnKS50aGVuKChtKSA9PiBtLkFydGVtaXNDb2RlRWRpdG9yTWFuYWdlbWVudE1vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb3Vyc2UtbWFuYWdlbWVudC86Y291cnNlSWQvdGV4dC1leGVyY2lzZXMvOmV4ZXJjaXNlSWQnLFxuICAgICAgICAgICAgICAgICAgICBsb2FkQ2hpbGRyZW46ICgpID0+IGltcG9ydCgnLi9leGVyY2lzZXMvdGV4dC9hc3Nlc3MvdGV4dC1zdWJtaXNzaW9uLWFzc2Vzc21lbnQubW9kdWxlJykudGhlbigobSkgPT4gbS5BcnRlbWlzVGV4dFN1Ym1pc3Npb25Bc3Nlc3NtZW50TW9kdWxlKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2NvdXJzZS1tYW5hZ2VtZW50Lzpjb3Vyc2VJZC90ZXh0LWV4ZXJjaXNlcy86ZXhlcmNpc2VJZC9leGFtcGxlLXN1Ym1pc3Npb25zLzpleGFtcGxlU3VibWlzc2lvbklkJyxcbiAgICAgICAgICAgICAgICAgICAgbG9hZENoaWxkcmVuOiAoKSA9PiBpbXBvcnQoJy4vZXhlcmNpc2VzL3RleHQvbWFuYWdlL2V4YW1wbGUtdGV4dC1zdWJtaXNzaW9uL2V4YW1wbGUtdGV4dC1zdWJtaXNzaW9uLm1vZHVsZScpLnRoZW4oKG0pID0+IG0uQXJ0ZW1pc0V4YW1wbGVUZXh0U3VibWlzc2lvbk1vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAvLyA9PT09PSBDT1VSU0VTID09PT09XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBwYXRoOiAnY291cnNlcy86Y291cnNlSWQvcHJvZ3JhbW1pbmctZXhlcmNpc2VzLzpleGVyY2lzZUlkL2NvZGUtZWRpdG9yJyxcbiAgICAgICAgICAgICAgICAgICAgbG9hZENoaWxkcmVuOiAoKSA9PiBpbXBvcnQoJy4vZXhlcmNpc2VzL3Byb2dyYW1taW5nL3BhcnRpY2lwYXRlL3Byb2dyYW1taW5nLXBhcnRpY2lwYXRpb24ubW9kdWxlJykudGhlbigobSkgPT4gbS5BcnRlbWlzUHJvZ3JhbW1pbmdQYXJ0aWNpcGF0aW9uTW9kdWxlKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2NvdXJzZXMvOmNvdXJzZUlkL21vZGVsaW5nLWV4ZXJjaXNlcy86ZXhlcmNpc2VJZCcsXG4gICAgICAgICAgICAgICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KCcuL2V4ZXJjaXNlcy9tb2RlbGluZy9wYXJ0aWNpcGF0ZS9tb2RlbGluZy1wYXJ0aWNpcGF0aW9uLm1vZHVsZScpLnRoZW4oKG0pID0+IG0uQXJ0ZW1pc01vZGVsaW5nUGFydGljaXBhdGlvbk1vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb3Vyc2VzLzpjb3Vyc2VJZC9xdWl6LWV4ZXJjaXNlcy86ZXhlcmNpc2VJZCcsXG4gICAgICAgICAgICAgICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KCcuL2V4ZXJjaXNlcy9xdWl6L3BhcnRpY2lwYXRlL3F1aXotcGFydGljaXBhdGlvbi5tb2R1bGUnKS50aGVuKChtKSA9PiBtLkFydGVtaXNRdWl6UGFydGljaXBhdGlvbk1vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb3Vyc2VzLzpjb3Vyc2VJZC90ZXh0LWV4ZXJjaXNlcy86ZXhlcmNpc2VJZCcsXG4gICAgICAgICAgICAgICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KCcuL2V4ZXJjaXNlcy90ZXh0L3BhcnRpY2lwYXRlL3RleHQtcGFydGljaXBhdGlvbi5tb2R1bGUnKS50aGVuKChtKSA9PiBtLkFydGVtaXNUZXh0UGFydGljaXBhdGlvbk1vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb3Vyc2VzLzpjb3Vyc2VJZC9maWxlLXVwbG9hZC1leGVyY2lzZXMvOmV4ZXJjaXNlSWQnLFxuICAgICAgICAgICAgICAgICAgICBsb2FkQ2hpbGRyZW46ICgpID0+IGltcG9ydCgnLi9leGVyY2lzZXMvZmlsZS11cGxvYWQvcGFydGljaXBhdGUvZmlsZS11cGxvYWQtcGFydGljaXBhdGlvbi5tb2R1bGUnKS50aGVuKChtKSA9PiBtLkFydGVtaXNGaWxlVXBsb2FkUGFydGljaXBhdGlvbk1vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb3Vyc2VzLzpjb3Vyc2VJZC9ncmFkaW5nLXN5c3RlbScsXG4gICAgICAgICAgICAgICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KCcuL2dyYWRpbmctc3lzdGVtL2dyYWRpbmctc3lzdGVtLm1vZHVsZScpLnRoZW4oKG0pID0+IG0uR3JhZGluZ1N5c3RlbU1vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAvLyA9PT09PSBFWEFNID09PT09XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBwYXRoOiAnY291cnNlcy86Y291cnNlSWQvZXhhbXMvOmV4YW1JZCcsXG4gICAgICAgICAgICAgICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KCcuL2V4YW0vcGFydGljaXBhdGUvZXhhbS1wYXJ0aWNpcGF0aW9uLm1vZHVsZScpLnRoZW4oKG0pID0+IG0uQXJ0ZW1pc0V4YW1QYXJ0aWNpcGF0aW9uTW9kdWxlKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2NvdXJzZS1tYW5hZ2VtZW50Lzpjb3Vyc2VJZC9leGFtcycsXG4gICAgICAgICAgICAgICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KCcuL2V4YW0vbWFuYWdlL2V4YW0tbWFuYWdlbWVudC5tb2R1bGUnKS50aGVuKChtKSA9PiBtLkFydGVtaXNFeGFtTWFuYWdlbWVudE1vZHVsZSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb3Vyc2VzLzpjb3Vyc2VJZC9leGFtcy86ZXhhbUlkL2dyYWRpbmctc3lzdGVtJyxcbiAgICAgICAgICAgICAgICAgICAgbG9hZENoaWxkcmVuOiAoKSA9PiBpbXBvcnQoJy4vZ3JhZGluZy1zeXN0ZW0vZ3JhZGluZy1zeXN0ZW0ubW9kdWxlJykudGhlbigobSkgPT4gbS5HcmFkaW5nU3lzdGVtTW9kdWxlKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2ZlYXR1cmVzJyxcbiAgICAgICAgICAgICAgICAgICAgbG9hZENoaWxkcmVuOiAoKSA9PiBpbXBvcnQoJy4vZmVhdHVyZS1vdmVydmlldy9mZWF0dXJlLW92ZXJ2aWV3Lm1vZHVsZScpLnRoZW4oKG0pID0+IG0uRmVhdHVyZU92ZXJ2aWV3TW9kdWxlKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2x0aScsXG4gICAgICAgICAgICAgICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KCcuL2x0aS9sdGkubW9kdWxlJykudGhlbigobSkgPT4gbS5BcnRlbWlzTHRpTW9kdWxlKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2Fib3V0LWlyaXMnLFxuICAgICAgICAgICAgICAgICAgICBjb21wb25lbnQ6IEFib3V0SXJpc0NvbXBvbmVudCxcbiAgICAgICAgICAgICAgICAgICAgcGF0aE1hdGNoOiAnZnVsbCcsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB7IGVuYWJsZVRyYWNpbmc6IGZhbHNlLCBvblNhbWVVcmxOYXZpZ2F0aW9uOiAncmVsb2FkJyB9LFxuICAgICAgICApLFxuICAgIF0sXG4gICAgZXhwb3J0czogW1JvdXRlck1vZHVsZV0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNBcHBSb3V0aW5nTW9kdWxlIHtcbiAgICAvLyBFbnN1cmUgdGhlIHNlcnZpY2UgaXMgaW5pdGlhbGl6ZWQgYmVmb3JlIGFueSByb3V0aW5nIGhhcHBlbnNcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF86IEFydGVtaXNOYXZpZ2F0aW9uVXRpbFNlcnZpY2UpIHt9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgVkVSU0lPTiB9IGZyb20gJ2FwcC9hcHAuY29uc3RhbnRzJztcbmltcG9ydCB7IFByb2ZpbGVTZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9sYXlvdXRzL3Byb2ZpbGVzL3Byb2ZpbGUuc2VydmljZSc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWZvb3RlcicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2Zvb3Rlci5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vZm9vdGVyLnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgRm9vdGVyQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICByZWFkb25seSByZWxlYXNlTm90ZXNVcmwgPSBgaHR0cHM6Ly9naXRodWIuY29tL2xzMWludHVtL0FydGVtaXMvcmVsZWFzZXMvdGFnLyR7VkVSU0lPTn1gO1xuICAgIHJlYWRvbmx5IHJlcXVlc3RDaGFuZ2VVcmwgPSAnaHR0cHM6Ly9naXRodWIuY29tL2xzMWludHVtL0FydGVtaXMvaXNzdWVzL25ldy9jaG9vc2UnO1xuXG4gICAgZW1haWw6IHN0cmluZztcbiAgICBnaXRCcmFuY2g6IHN0cmluZztcbiAgICBnaXRDb21taXRJZDogc3RyaW5nO1xuICAgIGdpdFRpbWVzdGFtcDogc3RyaW5nO1xuICAgIGdpdENvbW1pdFVzZXI6IHN0cmluZztcbiAgICB0ZXN0U2VydmVyOiBib29sZWFuO1xuICAgIGluUHJvZHVjdGlvbjogYm9vbGVhbjtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgcHJvZmlsZVNlcnZpY2U6IFByb2ZpbGVTZXJ2aWNlKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMucHJvZmlsZVNlcnZpY2UuZ2V0UHJvZmlsZUluZm8oKS5zdWJzY3JpYmUoKHByb2ZpbGVJbmZvKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmNvbnRhY3QgPSBwcm9maWxlSW5mby5jb250YWN0O1xuICAgICAgICAgICAgdGhpcy5naXRCcmFuY2ggPSBwcm9maWxlSW5mby5naXQuYnJhbmNoO1xuICAgICAgICAgICAgdGhpcy5naXRDb21taXRJZCA9IHByb2ZpbGVJbmZvLmdpdC5jb21taXQuaWQuYWJicmV2O1xuICAgICAgICAgICAgdGhpcy5naXRUaW1lc3RhbXAgPSBuZXcgRGF0ZShwcm9maWxlSW5mby5naXQuY29tbWl0LnRpbWUpLnRvVVRDU3RyaW5nKCk7XG4gICAgICAgICAgICB0aGlzLmdpdENvbW1pdFVzZXIgPSBwcm9maWxlSW5mby5naXQuY29tbWl0LnVzZXIubmFtZTtcbiAgICAgICAgICAgIHRoaXMudGVzdFNlcnZlciA9IHByb2ZpbGVJbmZvLnRlc3RTZXJ2ZXIgPz8gZmFsc2U7XG4gICAgICAgICAgICB0aGlzLmluUHJvZHVjdGlvbiA9IHByb2ZpbGVJbmZvLmluUHJvZHVjdGlvbjtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgc2V0IGNvbnRhY3QobWFpbDogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuZW1haWwgPVxuICAgICAgICAgICAgJ21haWx0bzonICtcbiAgICAgICAgICAgIG1haWwgK1xuICAgICAgICAgICAgJz9ib2R5PU5vdGUlM0ElMjBQbGVhc2UlMjBzZW5kJTIwb25seSUyMHN1cHBvcnQlMkZmZWF0dXJlJyArXG4gICAgICAgICAgICAnJTIwcmVxdWVzdCUyMG9yJTIwYnVnJTIwcmVwb3J0cyUyMHJlZ2FyZGluZyUyMHRoZSUyMEFydGVtaXMnICtcbiAgICAgICAgICAgICclMjBQbGF0Zm9ybSUyMHRvJTIwdGhpcyUyMGFkZHJlc3MuJTIwUGxlYXNlJTIwY2hlY2snICtcbiAgICAgICAgICAgICclMjBvdXIlMjBwdWJsaWMlMjBidWclMjB0cmFja2VyJTIwYXQlMjBodHRwcyUzQSUyRiUyRmdpdGh1Yi5jb20nICtcbiAgICAgICAgICAgICclMkZsczFpbnR1bSUyRkFydGVtaXMlMjBmb3IlMjBrbm93biUyMGJ1Z3MuJTBBRm9yJTIwcXVlc3Rpb25zJyArXG4gICAgICAgICAgICAnJTIwcmVnYXJkaW5nJTIwZXhlcmNpc2VzJTIwYW5kJTIwdGhlaXIlMjBjb250ZW50JTJDJTIwcGxlYXNlJTIwY29udGFjdCUyMHlvdXIlMjBpbnN0cnVjdG9ycy4nO1xuICAgIH1cbn1cbiIsIjxmb290ZXIgY2xhc3M9XCJkLW5vbmUgZC1tZC1mbGV4IHJvd1wiIGlkPVwiZm9vdGVyXCI+XG4gICAgPGRpdiBjbGFzcz1cImd1aWRlZC10b3VyLWZvb3Rlci1hYm91dCBjb2wtc20tNlwiPlxuICAgICAgICA8YSBbcm91dGVyTGlua109XCJbJy9hYm91dCddXCIgaWQ9XCJhYm91dFwiIGpoaVRyYW5zbGF0ZT1cImFib3V0VXNcIiBjbGFzcz1cImZvb3Rlci10ZXh0XCI+PC9hPlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJjb2wtc20tNiB0ZXh0LW1kLWVuZFwiPlxuICAgICAgICA8YSBbaHJlZl09XCJyZXF1ZXN0Q2hhbmdlVXJsXCIgaWQ9XCJyZXF1ZXN0LWNoYW5nZVwiIGpoaVRyYW5zbGF0ZT1cInJlcXVlc3RDaGFuZ2VcIiBjbGFzcz1cImZvb3Rlci10ZXh0XCIgdGFyZ2V0PVwiX2JsYW5rXCI+PC9hPlxuICAgICAgICA8YSBbaHJlZl09XCJyZWxlYXNlTm90ZXNVcmxcIiBpZD1cInJlbGVhc2Utbm90ZXNcIiBqaGlUcmFuc2xhdGU9XCJyZWxlYXNlTm90ZXNcIiBjbGFzcz1cImZvb3Rlci10ZXh0IG1zLTNcIiB0YXJnZXQ9XCJfYmxhbmtcIj48L2E+XG4gICAgICAgIDxhIFtyb3V0ZXJMaW5rXT1cIlsnL3ByaXZhY3knXVwiIGlkPVwicHJpdmFjeVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAubGVnYWwucHJpdmFjeVN0YXRlbWVudC50aXRsZVwiIGNsYXNzPVwiZm9vdGVyLXRleHQgbXMtM1wiPjwvYT5cbiAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWycvaW1wcmludCddXCIgaWQ9XCJpbXByaW50XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5sZWdhbC5pbXByaW50LnRpdGxlXCIgY2xhc3M9XCJmb290ZXItdGV4dCBtcy0zXCI+PC9hPlxuICAgIDwvZGl2PlxuICAgIEBpZiAoIWluUHJvZHVjdGlvbiB8fCB0ZXN0U2VydmVyKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtc20tMTIgZm9vdGVyLWdpdC13cmFwcGVyXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9vdGVyLWdpdFwiPnt7ICdhcnRlbWlzQXBwLmdpdC5icmFuY2gnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fToge3sgZ2l0QnJhbmNoIH19IOKAojwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvb3Rlci1naXRcIj57eyAnYXJ0ZW1pc0FwcC5naXQuY29tbWl0JyB8IGFydGVtaXNUcmFuc2xhdGUgfX06IHt7IGdpdENvbW1pdElkIH19IOKAojwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvb3Rlci1naXRcIj57eyAnYXJ0ZW1pc0FwcC5naXQudGltZXN0YW1wJyB8IGFydGVtaXNUcmFuc2xhdGUgfX06IHt7IGdpdFRpbWVzdGFtcCB9fSDigKI8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb290ZXItZ2l0XCI+e3sgJ2FydGVtaXNBcHAuZ2l0LnVzZXJuYW1lJyB8IGFydGVtaXNUcmFuc2xhdGUgfX06IHt7IGdpdENvbW1pdFVzZXIgfX08L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuPC9mb290ZXI+XG48Zm9vdGVyIGNsYXNzPVwiZC1mbGV4IGQtbWQtbm9uZSBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBtdy0xMDBcIj5cbiAgICA8ZGl2IGNsYXNzPVwiY29sLWF1dG8gcHgtMFwiPlxuICAgICAgICA8YSBbcm91dGVyTGlua109XCJbJy9hYm91dCddXCIgamhpVHJhbnNsYXRlPVwiYWJvdXRVc1wiIGNsYXNzPVwiZm9vdGVyLXRleHRcIj48L2E+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImNvbC1hdXRvIHB4LTBcIj5cbiAgICAgICAgPGEgW2hyZWZdPVwicmVxdWVzdENoYW5nZVVybFwiIGpoaVRyYW5zbGF0ZT1cInJlcXVlc3RDaGFuZ2VcIiBjbGFzcz1cImZvb3Rlci10ZXh0XCIgdGFyZ2V0PVwiX2JsYW5rXCI+PC9hPlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0byBweC0wXCI+XG4gICAgICAgIDxhIFtyb3V0ZXJMaW5rXT1cIlsnL3ByaXZhY3knXVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAubGVnYWwucHJpdmFjeVN0YXRlbWVudC50aXRsZVwiIGNsYXNzPVwiZm9vdGVyLXRleHRcIj48L2E+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImNvbC1hdXRvIHB4LTBcIj5cbiAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWycvaW1wcmludCddXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5sZWdhbC5pbXByaW50LnRpdGxlXCIgY2xhc3M9XCJmb290ZXItdGV4dFwiPjwvYT5cbiAgICA8L2Rpdj5cbjwvZm9vdGVyPlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBFbGVtZW50UmVmLCBPbkluaXQsIFZpZXdDaGlsZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUsIElzQWN0aXZlTWF0Y2hPcHRpb25zLCBQYXJhbXMsIFJvdXRlciwgVXJsVHJlZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBOb3RpZmljYXRpb25TZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vbm90aWZpY2F0aW9uLnNlcnZpY2UnO1xuaW1wb3J0IHtcbiAgICBMSVZFX0VYQU1fRVhFUkNJU0VfVVBEQVRFX05PVElGSUNBVElPTl9USVRMRSxcbiAgICBNRU5USU9ORURfSU5fTUVTU0FHRV9USVRMRSxcbiAgICBORVdfQU5OT1VOQ0VNRU5UX1BPU1RfVElUTEUsXG4gICAgTkVXX0NPVVJTRV9QT1NUX1RJVExFLFxuICAgIE5FV19FWEFNX1BPU1RfVElUTEUsXG4gICAgTkVXX0VYRVJDSVNFX1BPU1RfVElUTEUsXG4gICAgTkVXX0xFQ1RVUkVfUE9TVF9USVRMRSxcbiAgICBORVdfTUVTU0FHRV9USVRMRSxcbiAgICBORVdfUkVQTFlfRk9SX0NPVVJTRV9QT1NUX1RJVExFLFxuICAgIE5FV19SRVBMWV9GT1JfRVhBTV9QT1NUX1RJVExFLFxuICAgIE5FV19SRVBMWV9GT1JfRVhFUkNJU0VfUE9TVF9USVRMRSxcbiAgICBORVdfUkVQTFlfRk9SX0xFQ1RVUkVfUE9TVF9USVRMRSxcbiAgICBORVdfUkVQTFlfTUVTU0FHRV9USVRMRSxcbiAgICBOb3RpZmljYXRpb24sXG4gICAgUVVJWl9FWEVSQ0lTRV9TVEFSVEVEX1RJVExFLFxufSBmcm9tICdhcHAvZW50aXRpZXMvbm90aWZpY2F0aW9uLm1vZGVsJztcbmltcG9ydCB7IEdyb3VwTm90aWZpY2F0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL2dyb3VwLW5vdGlmaWNhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBFeGFtRXhlcmNpc2VVcGRhdGVTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4YW0vbWFuYWdlL2V4YW0tZXhlcmNpc2UtdXBkYXRlLnNlcnZpY2UnO1xuaW1wb3J0IHsgQWxlcnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvdXRpbC9hbGVydC5zZXJ2aWNlJztcbmltcG9ydCB7IEV4YW1QYXJ0aWNpcGF0aW9uU2VydmljZSB9IGZyb20gJ2FwcC9leGFtL3BhcnRpY2lwYXRlL2V4YW0tcGFydGljaXBhdGlvbi5zZXJ2aWNlJztcbmltcG9ydCB7IGZhQ2hlY2tEb3VibGUsIGZhRXhjbGFtYXRpb25UcmlhbmdsZSwgZmFNZXNzYWdlLCBmYVRpbWVzIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IE1ldGlzQ29udmVyc2F0aW9uU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvbWV0aXMvbWV0aXMtY29udmVyc2F0aW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgUm91dGVDb21wb25lbnRzIH0gZnJvbSAnYXBwL3NoYXJlZC9tZXRpcy9tZXRpcy51dGlsJztcbmltcG9ydCB7IE5vdGlmaWNhdGlvblNldHRpbmdzU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvdXNlci1zZXR0aW5ncy9ub3RpZmljYXRpb24tc2V0dGluZ3Mvbm90aWZpY2F0aW9uLXNldHRpbmdzLnNlcnZpY2UnO1xuaW1wb3J0IHsgdHJhbnNsYXRpb25Ob3RGb3VuZE1lc3NhZ2UgfSBmcm9tICdhcHAvY29yZS9jb25maWcvdHJhbnNsYXRpb24uY29uZmlnJztcbmltcG9ydCB7IEFydGVtaXNUcmFuc2xhdGVQaXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9waXBlcy9hcnRlbWlzLXRyYW5zbGF0ZS5waXBlJztcblxuY29uc3QgY29udmVyc2F0aW9uTWVzc2FnZU5vdGlmaWNhdGlvblRpdGxlcyA9IFtcbiAgICBNRU5USU9ORURfSU5fTUVTU0FHRV9USVRMRSxcbiAgICBORVdfQU5OT1VOQ0VNRU5UX1BPU1RfVElUTEUsXG4gICAgTkVXX01FU1NBR0VfVElUTEUsXG4gICAgTkVXX1JFUExZX01FU1NBR0VfVElUTEUsXG4gICAgTkVXX0VYRVJDSVNFX1BPU1RfVElUTEUsXG4gICAgTkVXX0xFQ1RVUkVfUE9TVF9USVRMRSxcbiAgICBORVdfRVhBTV9QT1NUX1RJVExFLFxuICAgIE5FV19DT1VSU0VfUE9TVF9USVRMRSxcbiAgICBORVdfUkVQTFlfRk9SX0VYRVJDSVNFX1BPU1RfVElUTEUsXG4gICAgTkVXX1JFUExZX0ZPUl9MRUNUVVJFX1BPU1RfVElUTEUsXG4gICAgTkVXX1JFUExZX0ZPUl9FWEFNX1BPU1RfVElUTEUsXG4gICAgTkVXX1JFUExZX0ZPUl9DT1VSU0VfUE9TVF9USVRMRSxcbl07XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLW5vdGlmaWNhdGlvbi1wb3B1cCcsXG4gICAgdGVtcGxhdGVVcmw6ICcuL25vdGlmaWNhdGlvbi1wb3B1cC5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vbm90aWZpY2F0aW9uLXBvcHVwLnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgTm90aWZpY2F0aW9uUG9wdXBDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIG5vdGlmaWNhdGlvbnM6IE5vdGlmaWNhdGlvbltdID0gW107XG5cbiAgICBMaXZlRXhhbUV4ZXJjaXNlVXBkYXRlTm90aWZpY2F0aW9uVGl0bGVIdG1sQ29uc3QgPSBMSVZFX0VYQU1fRVhFUkNJU0VfVVBEQVRFX05PVElGSUNBVElPTl9USVRMRTtcbiAgICBRdWl6Tm90aWZpY2F0aW9uVGl0bGVIdG1sQ29uc3QgPSAnUXVpeiBzdGFydGVkJztcblxuICAgIEBWaWV3Q2hpbGQoJ3Njcm9sbENvbnRhaW5lcicpXG4gICAgcHJpdmF0ZSBzY3JvbGxDb250YWluZXI6IEVsZW1lbnRSZWY7XG5cbiAgICBwcml2YXRlIHN0dWRlbnRFeGFtRXhlcmNpc2VJZHM6IG51bWJlcltdO1xuXG4gICAgcHJpdmF0ZSByZWFkb25seSBtYXhOb3RpZmljYXRpb25MZW5ndGggPSAxNTA7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhVGltZXMgPSBmYVRpbWVzO1xuICAgIGZhTWVzc2FnZSA9IGZhTWVzc2FnZTtcbiAgICBmYUNoZWNrRG91YmxlID0gZmFDaGVja0RvdWJsZTtcbiAgICBmYUV4Y2xhbWF0aW9uVHJpYW5nbGUgPSBmYUV4Y2xhbWF0aW9uVHJpYW5nbGU7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBub3RpZmljYXRpb25TZXJ2aWNlOiBOb3RpZmljYXRpb25TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgICAgICBwcml2YXRlIGFjdGl2YXRlZFJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSxcbiAgICAgICAgcHJpdmF0ZSBub3RpZmljYXRpb25TZXR0aW5nc1NlcnZpY2U6IE5vdGlmaWNhdGlvblNldHRpbmdzU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBleGFtRXhlcmNpc2VVcGRhdGVTZXJ2aWNlOiBFeGFtRXhlcmNpc2VVcGRhdGVTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFsZXJ0U2VydmljZTogQWxlcnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGV4YW1QYXJ0aWNpcGF0aW9uU2VydmljZTogRXhhbVBhcnRpY2lwYXRpb25TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFydGVtaXNUcmFuc2xhdGVQaXBlOiBBcnRlbWlzVHJhbnNsYXRlUGlwZSxcbiAgICApIHt9XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5ub3RpZmljYXRpb25TZXJ2aWNlLnN1YnNjcmliZVRvU2luZ2xlSW5jb21pbmdOb3RpZmljYXRpb25zKCkuc3Vic2NyaWJlKChub3RpZmljYXRpb246IE5vdGlmaWNhdGlvbikgPT4ge1xuICAgICAgICAgICAgdGhpcy5hZGROb3RpZmljYXRpb24obm90aWZpY2F0aW9uKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmVtb3ZlcyB0aGUgbm90aWZpY2F0aW9uIGF0IHRoZSBzcGVjaWZpZWQgaW5kZXggZnJvbSB0aGUgbm90aWZpY2F0aW9ucyBhcnJheS5cbiAgICAgKiBAcGFyYW0gaW5kZXgge251bWJlcn1cbiAgICAgKi9cbiAgICByZW1vdmVOb3RpZmljYXRpb24oaW5kZXg6IG51bWJlcik6IHZvaWQge1xuICAgICAgICB0aGlzLm5vdGlmaWNhdGlvbnMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBOYXZpZ2F0ZSB0byB0aGUgdGFyZ2V0ICh2aWV3KSBvZiB0aGUgbm90aWZpY2F0aW9uIHRoYXQgdGhlIHVzZXIgY2xpY2tlZC5cbiAgICAgKiBAcGFyYW0gbm90aWZpY2F0aW9uIHtOb3RpZmljYXRpb259XG4gICAgICovXG4gICAgbmF2aWdhdGVUb1RhcmdldChub3RpZmljYXRpb246IE5vdGlmaWNhdGlvbik6IHZvaWQge1xuICAgICAgICBjb25zdCBjdXJyZW50Q291cnNlSWQgPSB0aGlzLmFjdGl2YXRlZFJvdXRlLnNuYXBzaG90LnF1ZXJ5UGFyYW1zWydjb3Vyc2VJZCddO1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBKU09OLnBhcnNlKG5vdGlmaWNhdGlvbi50YXJnZXQhKTtcbiAgICAgICAgY29uc3QgdGFyZ2V0Q291cnNlSWQgPSB0YXJnZXQuY291cnNlO1xuICAgICAgICBjb25zdCB0YXJnZXRDb252ZXJzYXRpb25JZCA9IHRhcmdldC5jb252ZXJzYXRpb247XG5cbiAgICAgICAgaWYgKG5vdGlmaWNhdGlvbi50aXRsZSA9PT0gTElWRV9FWEFNX0VYRVJDSVNFX1VQREFURV9OT1RJRklDQVRJT05fVElUTEUpIHtcbiAgICAgICAgICAgIHRoaXMuZXhhbUV4ZXJjaXNlVXBkYXRlU2VydmljZS5uYXZpZ2F0ZVRvRXhhbUV4ZXJjaXNlKHRhcmdldC5leGVyY2lzZSk7XG4gICAgICAgIH0gZWxzZSBpZiAobm90aWZpY2F0aW9uLnRpdGxlICYmIGNvbnZlcnNhdGlvbk1lc3NhZ2VOb3RpZmljYXRpb25UaXRsZXMuaW5jbHVkZXMobm90aWZpY2F0aW9uLnRpdGxlKSkge1xuICAgICAgICAgICAgY29uc3QgcXVlcnlQYXJhbXM6IFBhcmFtcyA9IE1ldGlzQ29udmVyc2F0aW9uU2VydmljZS5nZXRRdWVyeVBhcmFtc0ZvckNvbnZlcnNhdGlvbih0YXJnZXRDb252ZXJzYXRpb25JZCk7XG4gICAgICAgICAgICBxdWVyeVBhcmFtcy5tZXNzYWdlSWQgPSB0YXJnZXQuaWQ7XG5cbiAgICAgICAgICAgIGNvbnN0IHJvdXRlQ29tcG9uZW50czogUm91dGVDb21wb25lbnRzID0gTWV0aXNDb252ZXJzYXRpb25TZXJ2aWNlLmdldExpbmtGb3JDb252ZXJzYXRpb24odGFyZ2V0Q291cnNlSWQpO1xuICAgICAgICAgICAgLy8gY2hlY2sgaWYgY29tcG9uZW50IHJlbG9hZCBpcyBuZWVkZWRcbiAgICAgICAgICAgIGlmIChjdXJyZW50Q291cnNlSWQgPT09IHVuZGVmaW5lZCB8fCBjdXJyZW50Q291cnNlSWQgIT09IHRhcmdldENvdXJzZUlkIHx8IHRoaXMuaXNVbmRlck1lc3NhZ2VzVGFiT2ZTcGVjaWZpY0NvdXJzZSh0YXJnZXRDb3Vyc2VJZCkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm5vdGlmaWNhdGlvblNlcnZpY2UuZm9yY2VDb21wb25lbnRSZWxvYWQocm91dGVDb21wb25lbnRzLCBxdWVyeVBhcmFtcyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKHJvdXRlQ29tcG9uZW50cywgeyBxdWVyeVBhcmFtcyB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlQnlVcmwodGhpcy5ub3RpZmljYXRpb25UYXJnZXRSb3V0ZShub3RpZmljYXRpb24pKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIHRyYW5zbGF0ZWQgdGV4dCBmb3IgdGhlIHBsYWNlaG9sZGVyIG9mIHRoZSB0aXRsZSBvZiB0aGUgcHJvdmlkZWQgbm90aWZpY2F0aW9uLlxuICAgICAqIElmIHRoZSBub3RpZmljYXRpb24gaXMgYSBsZWdhY3kgbm90aWZpY2F0aW9uIGFuZCB0aGVyZWZvciB0aGUgdGl0bGUgaXMgbm90IGEgcGxhY2Vob2xkZXJcbiAgICAgKiBpdCBqdXN0IHJldHVybnMgdGhlIHByb3ZpZGVkIHRleHQgZm9yIHRoZSB0aXRsZVxuICAgICAqIEBwYXJhbSBub3RpZmljYXRpb24ge05vdGlmaWNhdGlvbn1cbiAgICAgKi9cbiAgICBnZXROb3RpZmljYXRpb25UaXRsZVRyYW5zbGF0aW9uKG5vdGlmaWNhdGlvbjogTm90aWZpY2F0aW9uKTogc3RyaW5nIHtcbiAgICAgICAgY29uc3QgdHJhbnNsYXRpb24gPSB0aGlzLmFydGVtaXNUcmFuc2xhdGVQaXBlLnRyYW5zZm9ybShub3RpZmljYXRpb24udGl0bGUpO1xuICAgICAgICBpZiAodHJhbnNsYXRpb24/LmluY2x1ZGVzKHRyYW5zbGF0aW9uTm90Rm91bmRNZXNzYWdlKSkge1xuICAgICAgICAgICAgcmV0dXJuIG5vdGlmaWNhdGlvbi50aXRsZSA/PyAnTm8gdGl0bGUgZm91bmQnO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cmFuc2xhdGlvbjtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSB0cmFuc2xhdGVkIHRleHQgZm9yIHRoZSBwbGFjZWhvbGRlciBvZiB0aGUgbm90aWZpY2F0aW9uIHRleHQgb2YgdGhlIHByb3ZpZGVkIG5vdGlmaWNhdGlvbi5cbiAgICAgKiBJZiB0aGUgbm90aWZpY2F0aW9uIGlzIGEgbGVnYWN5IG5vdGlmaWNhdGlvbiBhbmQgdGhlcmVmb3IgdGhlIHRleHQgaXMgbm90IGEgcGxhY2Vob2xkZXJcbiAgICAgKiBpdCBqdXN0IHJldHVybnMgdGhlIHByb3ZpZGVkIHRleHQgZm9yIHRoZSBub3RpZmljYXRpb24gdGV4dFxuICAgICAqIEBwYXJhbSBub3RpZmljYXRpb24ge05vdGlmaWNhdGlvbn1cbiAgICAgKi9cbiAgICBnZXROb3RpZmljYXRpb25UZXh0VHJhbnNsYXRpb24obm90aWZpY2F0aW9uOiBOb3RpZmljYXRpb24pOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5ub3RpZmljYXRpb25TZXJ2aWNlLmdldE5vdGlmaWNhdGlvblRleHRUcmFuc2xhdGlvbihub3RpZmljYXRpb24sIHRoaXMubWF4Tm90aWZpY2F0aW9uTGVuZ3RoKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIG5vdGlmaWNhdGlvblRhcmdldFJvdXRlKG5vdGlmaWNhdGlvbjogTm90aWZpY2F0aW9uKTogVXJsVHJlZSB8IHN0cmluZyB7XG4gICAgICAgIGlmIChub3RpZmljYXRpb24udGFyZ2V0KSB7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBKU09OLnBhcnNlKG5vdGlmaWNhdGlvbi50YXJnZXQpO1xuICAgICAgICAgICAgaWYgKG5vdGlmaWNhdGlvbi50aXRsZSA9PT0gTElWRV9FWEFNX0VYRVJDSVNFX1VQREFURV9OT1RJRklDQVRJT05fVElUTEUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5yb3V0ZXIuY3JlYXRlVXJsVHJlZShbdGFyZ2V0Lm1haW5QYWdlLCB0YXJnZXQuY291cnNlLCB0YXJnZXQuZW50aXR5LCB0YXJnZXQuZXhhbV0pO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChub3RpZmljYXRpb24udGl0bGUgPT09IFFVSVpfRVhFUkNJU0VfU1RBUlRFRF9USVRMRSAmJiB0YXJnZXQuc3RhdHVzKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucm91dGVyLmNyZWF0ZVVybFRyZWUoW3RhcmdldC5tYWluUGFnZSwgdGFyZ2V0LmNvdXJzZSwgdGFyZ2V0LmVudGl0eSwgdGFyZ2V0LmlkLCB0YXJnZXQuc3RhdHVzXSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnJvdXRlci5jcmVhdGVVcmxUcmVlKFt0YXJnZXQubWFpblBhZ2UsIHRhcmdldC5jb3Vyc2UsIHRhcmdldC5lbnRpdHksIHRhcmdldC5pZF0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLnJvdXRlci51cmw7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBhZGROb3RpZmljYXRpb24obm90aWZpY2F0aW9uOiBOb3RpZmljYXRpb24pOiB2b2lkIHtcbiAgICAgICAgLy8gT25seSBhZGQgYSBub3RpZmljYXRpb24gaWYgaXQgZG9lcyBub3QgYWxyZWFkeSBleGlzdC5cbiAgICAgICAgaWYgKG5vdGlmaWNhdGlvbiAmJiAhdGhpcy5ub3RpZmljYXRpb25zLnNvbWUoKHsgaWQgfSkgPT4gbm90aWZpY2F0aW9uLmlkICYmIGlkID09PSBub3RpZmljYXRpb24uaWQpKSB7XG4gICAgICAgICAgICBpZiAobm90aWZpY2F0aW9uLnRpdGxlID09PSBRVUlaX0VYRVJDSVNFX1NUQVJURURfVElUTEUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmFkZFF1aXpOb3RpZmljYXRpb24obm90aWZpY2F0aW9uKTtcbiAgICAgICAgICAgICAgICB0aGlzLnNldFJlbW92YWxUaW1lb3V0KG5vdGlmaWNhdGlvbik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobm90aWZpY2F0aW9uLnRpdGxlID09PSBMSVZFX0VYQU1fRVhFUkNJU0VfVVBEQVRFX05PVElGSUNBVElPTl9USVRMRSkge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tJZk5vdGlmaWNhdGlvbkFmZmVjdHNDdXJyZW50U3R1ZGVudEV4YW1FeGVyY2lzZXMobm90aWZpY2F0aW9uKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChub3RpZmljYXRpb24udGl0bGUgJiYgY29udmVyc2F0aW9uTWVzc2FnZU5vdGlmaWNhdGlvblRpdGxlcy5pbmNsdWRlcyhub3RpZmljYXRpb24udGl0bGUpKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubm90aWZpY2F0aW9uU2V0dGluZ3NTZXJ2aWNlLmlzTm90aWZpY2F0aW9uQWxsb3dlZEJ5U2V0dGluZ3Mobm90aWZpY2F0aW9uKSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZE1lc3NhZ2VOb3RpZmljYXRpb24obm90aWZpY2F0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRSZW1vdmFsVGltZW91dChub3RpZmljYXRpb24sIDE1KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBXaWxsIGFkZCBhIG5vdGlmaWNhdGlvbiBhYm91dCBhIG5ldyBtZXNzYWdlIG9yIHJlcGx5IHRvIHRoZSBjb21wb25lbnQncyBzdGF0ZS5cbiAgICAgKiBAcGFyYW0gbm90aWZpY2F0aW9uIHtOb3RpZmljYXRpb259XG4gICAgICovXG4gICAgcHJpdmF0ZSBhZGRNZXNzYWdlTm90aWZpY2F0aW9uKG5vdGlmaWNhdGlvbjogTm90aWZpY2F0aW9uKTogdm9pZCB7XG4gICAgICAgIGlmIChub3RpZmljYXRpb24udGFyZ2V0KSB7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBKU09OLnBhcnNlKG5vdGlmaWNhdGlvbi50YXJnZXQpO1xuICAgICAgICAgICAgaWYgKCF0aGlzLmlzVW5kZXJNZXNzYWdlc1RhYk9mU3BlY2lmaWNDb3Vyc2UodGFyZ2V0LmNvdXJzZSkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmRpc3BsYXlOb3RpZmljYXRpb24obm90aWZpY2F0aW9uKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEFwcGVuZHMgdGhlIG5ldyBub3RpZmljYXRpb24gdG8gdGhlIGV4aXN0aW5nIGxpc3Qgb2Ygbm90aWZpY2F0aW9uLiBJdCBhbHNvIHNjcm9sbHMgdG8gdGhlIGJvdHRvbSBvZiB0aGUgbm90aWZpY2F0aW9uIGxpc3QgaW4gdGhlIHZpZXdwb3J0LlxuICAgICAqIEBwYXJhbSBub3RpZmljYXRpb24gdGhlIG5ldyBub3RpZmljYXRpb25cbiAgICAgKi9cbiAgICBwcml2YXRlIGRpc3BsYXlOb3RpZmljYXRpb24obm90aWZpY2F0aW9uOiBOb3RpZmljYXRpb24pIHtcbiAgICAgICAgdGhpcy5ub3RpZmljYXRpb25zLnB1c2gobm90aWZpY2F0aW9uKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICBpZiAodGhpcy5zY3JvbGxDb250YWluZXI/Lm5hdGl2ZUVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNjcm9sbENvbnRhaW5lci5uYXRpdmVFbGVtZW50LnNjcm9sbFRvcCA9IHRoaXMuc2Nyb2xsQ29udGFpbmVyLm5hdGl2ZUVsZW1lbnQuc2Nyb2xsSGVpZ2h0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiB1c2VyIGlzIHVuZGVyIG1lc3NhZ2VzIHRhYi5cbiAgICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gdHJ1ZSBpZiB1c2VyIGlzIHVuZGVyIG1lc3NhZ2VzIHRhYiwgZmFsc2Ugb3RoZXJ3aXNlXG4gICAgICovXG4gICAgcHJpdmF0ZSBpc1VuZGVyTWVzc2FnZXNUYWJPZlNwZWNpZmljQ291cnNlKHRhcmdldENvdXJzZUlkOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucm91dGVyLnVybC5pbmNsdWRlcyhgY291cnNlcy8ke3RhcmdldENvdXJzZUlkfS9tZXNzYWdlc2ApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFdpbGwgYWRkIGEgbm90aWZpY2F0aW9uIGFib3V0IGEgc3RhcnRlZCBxdWl6IHRvIHRoZSBjb21wb25lbnQncyBzdGF0ZS4gVGhlIG5vdGlmaWNhdGlvbiB3aWxsXG4gICAgICogb25seSBiZSBhZGRlZCBpZiB0aGUgdXNlciBpcyBub3QgYWxyZWFkeSBvbiB0aGUgdGFyZ2V0IHBhZ2UgKG9yIHRoZSBsaXZlIHBhcnRpY2lwYXRpb24gcGFnZSkuXG4gICAgICogQHBhcmFtIG5vdGlmaWNhdGlvbiB7Tm90aWZpY2F0aW9ufVxuICAgICAqL1xuICAgIHByaXZhdGUgYWRkUXVpek5vdGlmaWNhdGlvbihub3RpZmljYXRpb246IE5vdGlmaWNhdGlvbik6IHZvaWQge1xuICAgICAgICBpZiAobm90aWZpY2F0aW9uLnRhcmdldCkge1xuICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gSlNPTi5wYXJzZShub3RpZmljYXRpb24udGFyZ2V0KTtcbiAgICAgICAgICAgIHRhcmdldC5lbnRpdHkgPSAncXVpei1leGVyY2lzZXMnO1xuICAgICAgICAgICAgdGFyZ2V0LnN0YXR1cyA9ICdsaXZlJztcbiAgICAgICAgICAgIGNvbnN0IG5vdGlmaWNhdGlvbldpdGhMaXZlUXVpelRhcmdldCA9IHtcbiAgICAgICAgICAgICAgICB0YXJnZXQ6IEpTT04uc3RyaW5naWZ5KHRhcmdldCksXG4gICAgICAgICAgICB9IGFzIEdyb3VwTm90aWZpY2F0aW9uO1xuICAgICAgICAgICAgY29uc3QgbWF0Y2hPcHRpb25zID0geyBwYXRoczogJ2V4YWN0JywgcXVlcnlQYXJhbXM6ICdleGFjdCcsIGZyYWdtZW50OiAnaWdub3JlZCcsIG1hdHJpeFBhcmFtczogJ2lnbm9yZWQnIH0gYXMgSXNBY3RpdmVNYXRjaE9wdGlvbnM7IC8vIGNvcnJlc3BvbmRzIHRvIGV4YWN0ID0gdHJ1ZVxuICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgICF0aGlzLnJvdXRlci5pc0FjdGl2ZSh0aGlzLm5vdGlmaWNhdGlvblRhcmdldFJvdXRlKG5vdGlmaWNhdGlvbiksIG1hdGNoT3B0aW9ucykgJiZcbiAgICAgICAgICAgICAgICAhdGhpcy5yb3V0ZXIuaXNBY3RpdmUodGhpcy5ub3RpZmljYXRpb25UYXJnZXRSb3V0ZShub3RpZmljYXRpb25XaXRoTGl2ZVF1aXpUYXJnZXQpICsgJy9saXZlJywgbWF0Y2hPcHRpb25zKVxuICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgbm90aWZpY2F0aW9uLnRhcmdldCA9IG5vdGlmaWNhdGlvbldpdGhMaXZlUXVpelRhcmdldC50YXJnZXQ7XG4gICAgICAgICAgICAgICAgdGhpcy5kaXNwbGF5Tm90aWZpY2F0aW9uKG5vdGlmaWNhdGlvbik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBBZGRzIGEgbm90aWZpY2F0aW9uIGFib3V0IGFuIHVwZGF0ZWQgZXhlcmNpc2UgZHVyaW5nIGEgbGl2ZSBleGFtIHRvIHRoZSBjb21wb25lbnQncyBzdGF0ZVxuICAgICAqIGFuZCBwdXNoZXMgdXBkYXRlZCBwcm9ibGVtU3RhdGVtZW50IHRvIHN0dWRlbnQgZXhhbSBleGVyY2lzZSB2aWEgQmVoYXZpb3JTdWJqZWN0c1xuICAgICAqXG4gICAgICogQHBhcmFtIG5vdGlmaWNhdGlvbiB7Tm90aWZpY2F0aW9ufVxuICAgICAqL1xuICAgIHByaXZhdGUgYWRkRXhhbVVwZGF0ZU5vdGlmaWNhdGlvbihub3RpZmljYXRpb246IE5vdGlmaWNhdGlvbik6IHZvaWQge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gSlNPTi5wYXJzZShub3RpZmljYXRpb24udGFyZ2V0ISk7XG4gICAgICAgICAgICB0aGlzLmV4YW1FeGVyY2lzZVVwZGF0ZVNlcnZpY2UudXBkYXRlTGl2ZUV4YW1FeGVyY2lzZSh0YXJnZXQuZXhlcmNpc2UsIHRhcmdldC5wcm9ibGVtU3RhdGVtZW50KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLmVycm9yKGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBvbmx5IHNob3cgcG9wLXVwIGlmIGV4cGxpY2l0IG5vdGlmaWNhdGlvbiB0ZXh0IHdhcyBzZXQgYW5kIG9ubHkgaW5zaWRlIGV4YW0gbW9kZVxuICAgICAgICBjb25zdCBtYXRjaE9wdGlvbnMgPSB7IHBhdGhzOiAnZXhhY3QnLCBxdWVyeVBhcmFtczogJ2V4YWN0JywgZnJhZ21lbnQ6ICdpZ25vcmVkJywgbWF0cml4UGFyYW1zOiAnaWdub3JlZCcgfSBhcyBJc0FjdGl2ZU1hdGNoT3B0aW9uczsgLy8gY29ycmVzcG9uZHMgdG8gZXhhY3QgPSB0cnVlXG4gICAgICAgIGlmIChub3RpZmljYXRpb24udGV4dCAhPSB1bmRlZmluZWQgJiYgdGhpcy5yb3V0ZXIuaXNBY3RpdmUodGhpcy5ub3RpZmljYXRpb25UYXJnZXRSb3V0ZShub3RpZmljYXRpb24pLCBtYXRjaE9wdGlvbnMpKSB7XG4gICAgICAgICAgICB0aGlzLmRpc3BsYXlOb3RpZmljYXRpb24obm90aWZpY2F0aW9uKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGNoZWNrcyBpZiB0aGUgdXBkYXRlZCBleGVyY2lzZSwgd2hpY2ggbm90aWZpY2F0aW9uIGlzIGJhc2VkIG9uLCBpcyBwYXJ0IG9mIHRoZSBzdHVkZW50IGV4YW0gb2YgdGhpcyBjbGllbnRcbiAgICAgKiB0aGlzIG1pZ2h0IG5vdCBiZSB0aGUgY2FzZSBkdWUgdG8gZGlmZmVyZW50L29wdGlvbmFsIGV4ZXJjaXNlR3JvdXBzXG4gICAgICogQHBhcmFtIG5vdGlmaWNhdGlvbiB0aGF0IGhvbGQgaW5mb3JtYXRpb24gYWJvdXQgdGhlIGV4ZXJjaXNlIGxpa2UgcHJvYmxlbVN0YXRlbWVudCBvciBkaWZmZXJlbnQgaWRzXG4gICAgICovXG4gICAgcHJpdmF0ZSBjaGVja0lmTm90aWZpY2F0aW9uQWZmZWN0c0N1cnJlbnRTdHVkZW50RXhhbUV4ZXJjaXNlcyhub3RpZmljYXRpb246IE5vdGlmaWNhdGlvbik6IHZvaWQge1xuICAgICAgICBpZiAoIW5vdGlmaWNhdGlvbi50YXJnZXQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB0YXJnZXQgPSBKU09OLnBhcnNlKG5vdGlmaWNhdGlvbi50YXJnZXQpO1xuICAgICAgICBjb25zdCBleGVyY2lzZUlkID0gdGFyZ2V0LmV4ZXJjaXNlO1xuXG4gICAgICAgIGlmICghdGhpcy5zdHVkZW50RXhhbUV4ZXJjaXNlSWRzKSB7XG4gICAgICAgICAgICB0aGlzLnN0dWRlbnRFeGFtRXhlcmNpc2VJZHMgPSB0aGlzLmV4YW1QYXJ0aWNpcGF0aW9uU2VydmljZS5nZXRFeGFtRXhlcmNpc2VJZHMoKTtcbiAgICAgICAgICAgIGlmICghdGhpcy5zdHVkZW50RXhhbUV4ZXJjaXNlSWRzKSB7XG4gICAgICAgICAgICAgICAgLy8gZXhlcmNpc2VzIHdlcmUgbm90IGxvYWRlZCB5ZXQgZm9yIGN1cnJlbnQgdXNlciAtPiBleGFtIHVwZGF0ZSB3aWxsIGJlIGxvYWRlZCB3aGVuIHVzZXIgc3RhcnRzL2xvYWRzIHRoZSBleGFtXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdXBkYXRlZEV4ZXJjaXNlSXNQYXJ0T2ZTdHVkZW50RXhhbSA9IHRoaXMuc3R1ZGVudEV4YW1FeGVyY2lzZUlkcz8uZmluZCgoZXhlcmNpc2VJZGVudGlmaWVyKSA9PiBleGVyY2lzZUlkZW50aWZpZXIgPT09IGV4ZXJjaXNlSWQpO1xuICAgICAgICBpZiAodXBkYXRlZEV4ZXJjaXNlSXNQYXJ0T2ZTdHVkZW50RXhhbSkge1xuICAgICAgICAgICAgdGhpcy5hZGRFeGFtVXBkYXRlTm90aWZpY2F0aW9uKG5vdGlmaWNhdGlvbik7XG4gICAgICAgICAgICB0aGlzLnNldFJlbW92YWxUaW1lb3V0KG5vdGlmaWNhdGlvbik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXRzIHRoZSByZW1vdmFsIHRpbWVvdXQgZm9yIGEgZGlzcGxheWVkIG5vdGlmaWNhdGlvblxuICAgICAqXG4gICAgICogQHBhcmFtIG5vdGlmaWNhdGlvbiAgdGhlIG5vdGlmaWNhdGlvbiB0byByZW1vdmVcbiAgICAgKiBAcGFyYW0gdGltZW91dEluU2VjICB0aW1lIHNwYW4gYWZ0ZXIgd2hpY2ggdGhlIG5vdGlmaWNhdGlvbiBzaG91bGQgYmUgcmVtb3ZlZCwgMzAgc2VjIGJ5IGRlZmF1bHRcbiAgICAgKi9cbiAgICBwcml2YXRlIHNldFJlbW92YWxUaW1lb3V0KG5vdGlmaWNhdGlvbjogTm90aWZpY2F0aW9uLCB0aW1lb3V0SW5TZWMgPSAzMCk6IHZvaWQge1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMubm90aWZpY2F0aW9ucyA9IHRoaXMubm90aWZpY2F0aW9ucy5maWx0ZXIoKHsgaWQgfSkgPT4gaWQgIT09IG5vdGlmaWNhdGlvbi5pZCk7XG4gICAgICAgIH0sIHRpbWVvdXRJblNlYyAqIDEwMDApO1xuICAgIH1cbn1cbiIsIjxkaXYgI3Njcm9sbENvbnRhaW5lciBjbGFzcz1cIm5vdGlmaWNhdGlvbi1wb3B1cC1jb250YWluZXJcIj5cbiAgICBAZm9yIChub3RpZmljYXRpb24gb2Ygbm90aWZpY2F0aW9uczsgdHJhY2sgbm90aWZpY2F0aW9uOyBsZXQgaSA9ICRpbmRleCkge1xuICAgICAgICA8ZGl2IChjbGljayk9XCJyZW1vdmVOb3RpZmljYXRpb24oaSk7IG5hdmlnYXRlVG9UYXJnZXQobm90aWZpY2F0aW9uKVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImljb24tY29udGFpbmVyIGQtZmxleCBmbGV4LWNvbHVtbiBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIHAtNFwiPlxuICAgICAgICAgICAgICAgIEBpZiAobm90aWZpY2F0aW9uLnRpdGxlID09PSBMaXZlRXhhbUV4ZXJjaXNlVXBkYXRlTm90aWZpY2F0aW9uVGl0bGVIdG1sQ29uc3QpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhRXhjbGFtYXRpb25UcmlhbmdsZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfSBAZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIEBpZiAobm90aWZpY2F0aW9uLnRpdGxlID09PSBRdWl6Tm90aWZpY2F0aW9uVGl0bGVIdG1sQ29uc3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQ2hlY2tEb3VibGVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFNZXNzYWdlXCIgY2xhc3M9XCJ0ZXh0LWluZm9cIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwZS00IHB5LTNcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwibS0wIHB4LTEgcHktMFwiIChjbGljayk9XCJyZW1vdmVOb3RpZmljYXRpb24oaSlcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFUaW1lc1wiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICBAaWYgKG5vdGlmaWNhdGlvbi50aXRsZSA9PT0gTGl2ZUV4YW1FeGVyY2lzZVVwZGF0ZU5vdGlmaWNhdGlvblRpdGxlSHRtbENvbnN0KSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDUgY2xhc3M9XCJwZS00XCI+e3sgJ2FydGVtaXNBcHAubm90aWZpY2F0aW9uLmxpdmVFeGFtRXhlcmNpc2VVcGRhdGVOb3RpZmljYXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvaDU+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICA8aDUgY2xhc3M9XCJwZS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7eyBnZXROb3RpZmljYXRpb25UaXRsZVRyYW5zbGF0aW9uKG5vdGlmaWNhdGlvbikgfX1cbiAgICAgICAgICAgICAgICAgICAgPC9oNT5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtYnJlYWtcIj5cbiAgICAgICAgICAgICAgICAgICAge3sgZ2V0Tm90aWZpY2F0aW9uVGV4dFRyYW5zbGF0aW9uKG5vdGlmaWNhdGlvbikgfX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1lbmRcIj5cbiAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAubm90aWZpY2F0aW9uLmJ5JyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgQGlmIChub3RpZmljYXRpb24uYXV0aG9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyBub3RpZmljYXRpb24uYXV0aG9yLm5hbWUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZ2xvYmFsLnRpdGxlXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuPC9kaXY+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEluamVjdCwgT25Jbml0LCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlU25hcHNob3QsIE5hdmlnYXRpb25FbmQsIE5hdmlnYXRpb25FcnJvciwgTmF2aWdhdGlvblN0YXJ0LCBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgSmhpTGFuZ3VhZ2VIZWxwZXIgfSBmcm9tICdhcHAvY29yZS9sYW5ndWFnZS9sYW5ndWFnZS5oZWxwZXInO1xuaW1wb3J0IHsgUHJvZmlsZVNlcnZpY2UgfSBmcm9tICdhcHAvc2hhcmVkL2xheW91dHMvcHJvZmlsZXMvcHJvZmlsZS5zZXJ2aWNlJztcbmltcG9ydCB7IFNlbnRyeUVycm9ySGFuZGxlciB9IGZyb20gJ2FwcC9jb3JlL3NlbnRyeS9zZW50cnkuZXJyb3ItaGFuZGxlcic7XG5pbXBvcnQgeyBUaGVtZVNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS90aGVtZS90aGVtZS5zZXJ2aWNlJztcbmltcG9ydCB7IERPQ1VNRU5UIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbWFpbicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL21haW4uY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBKaGlNYWluQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICAvKipcbiAgICAgKiBJZiB0aGUgZm9vdGVyIGFuZCBoZWFkZXIgc2hvdWxkIGJlIHNob3duLlxuICAgICAqIE9ubHkgc2V0IHRvIGZhbHNlIG9uIHNwZWNpZmljIHBhZ2VzIGRlc2lnbmVkIGZvciB0aGUgbmF0aXZlIEFuZHJvaWQgYW5kIGlPUyBhcHBsaWNhdGlvbnMgd2hlcmUgdGhlIGZvb3RlciBhbmQgaGVhZGVyIGFyZSBub3Qgd2FudGVkLlxuICAgICAqIFRoZSBkZWNpc2lvbiBvbiB3aGV0aGVyIHRvIHNob3cgdGhlIHNrZWxldG9uIG9yIG5vdCBmb3IgYSBzcGVjaWZpYyByb3V0ZSBpcyBkZWZpbmVkIGluIHNob3VsZFNob3dTa2VsZXRvbi5cbiAgICAgKi9cbiAgICBwdWJsaWMgc2hvd1NrZWxldG9uID0gdHJ1ZTtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGpoaUxhbmd1YWdlSGVscGVyOiBKaGlMYW5ndWFnZUhlbHBlcixcbiAgICAgICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcbiAgICAgICAgcHJpdmF0ZSBwcm9maWxlU2VydmljZTogUHJvZmlsZVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgc2VudHJ5RXJyb3JIYW5kbGVyOiBTZW50cnlFcnJvckhhbmRsZXIsXG4gICAgICAgIHByaXZhdGUgdGhlbWVTZXJ2aWNlOiBUaGVtZVNlcnZpY2UsXG4gICAgICAgIEBJbmplY3QoRE9DVU1FTlQpXG4gICAgICAgIHByaXZhdGUgZG9jdW1lbnQ6IERvY3VtZW50LFxuICAgICAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjIsXG4gICAgKSB7XG4gICAgICAgIHRoaXMuc2V0dXBFcnJvckhhbmRsaW5nKCkudGhlbihudWxsKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGFzeW5jIHNldHVwRXJyb3JIYW5kbGluZygpIHtcbiAgICAgICAgdGhpcy5wcm9maWxlU2VydmljZS5nZXRQcm9maWxlSW5mbygpLnN1YnNjcmliZSgocHJvZmlsZUluZm8pID0+IHtcbiAgICAgICAgICAgIC8vIHNlbnRyeSBpcyBvbmx5IGFjdGl2YXRlZCBpZiBpdCB3YXMgc3BlY2lmaWVkIGluIHRoZSBhcHBsaWNhdGlvbi55bWwgZmlsZVxuICAgICAgICAgICAgdGhpcy5zZW50cnlFcnJvckhhbmRsZXIuaW5pdFNlbnRyeShwcm9maWxlSW5mbyk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHByaXZhdGUgZ2V0UGFnZVRpdGxlKHJvdXRlU25hcHNob3Q6IEFjdGl2YXRlZFJvdXRlU25hcHNob3QpOiBzdHJpbmcge1xuICAgICAgICBjb25zdCB0aXRsZTogc3RyaW5nID0gcm91dGVTbmFwc2hvdC5kYXRhWydwYWdlVGl0bGUnXSA/PyAnYXJ0ZW1pc0FwcCc7XG4gICAgICAgIGlmIChyb3V0ZVNuYXBzaG90LmZpcnN0Q2hpbGQpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmdldFBhZ2VUaXRsZShyb3V0ZVNuYXBzaG90LmZpcnN0Q2hpbGQpIHx8IHRpdGxlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aXRsZTtcbiAgICB9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5yb3V0ZXIuZXZlbnRzLnN1YnNjcmliZSgoZXZlbnQpID0+IHtcbiAgICAgICAgICAgIGlmIChldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25TdGFydCkge1xuICAgICAgICAgICAgICAgIC8qXG4gICAgICAgICAgICAgICAgSW4gdGhlIGNhc2Ugd2hlcmUgd2UgZG8gbm90IHdhbnQgdG8gc2hvdyB0aGUgc2tlbGV0b24sIHdlIGFsc28gd2FudCB0byBzZXQgdGhlIGJhY2tncm91bmQgdG8gdHJhbnNwYXJlbnRcbiAgICAgICAgICAgICAgICBzdWNoIHRoYXQgdGhlIG1vYmlsZSBuYXRpdmUgYXBwbGljYXRpb25zIGNhbiBkaXNwbGF5IHRoZWlyIGJhY2tncm91bmQgaW4gdGhlIHdlYiB2aWV3LlxuXG4gICAgICAgICAgICAgICAgSG93ZXZlciwgYXMgdGhlIGRlZmF1bHQgYmFja2dyb3VuZCBhdHRyaWJ1dGUgaXMgZGVmaW5lZCBpbiB0aGUgYm9keSBodG1sIHRhZyBpdCBpcyBvdXRzaWRlIG9mIEFuZ3VsYXIncyByZWFjaC5cbiAgICAgICAgICAgICAgICBXZSBzZXQgdGhlIGJhY2tncm91bmQgb3Vyc2VsdmVzIGJ5IGFkZGluZyB0aGUgdHJhbnNwYXJlbnQtYmFja2dyb3VuZCBjc3MgY2xhc3Mgb24gdGhlIGJvZHkgZWxlbWVudCwgdGh1c1xuICAgICAgICAgICAgICAgIG92ZXJ3cml0aW5nIHRoZSBkZWZhdWx0IGJhY2tncm91bmQuIFdlIGNhbm5vdCBkbyB0aGlzIGluIGFueSBvdGhlciB3YXksIGFzIEFuZ3VsYXIgY2Fubm90IG1vZGlmeSB0aGUgYm9keVxuICAgICAgICAgICAgICAgIGl0c2VsZi5cbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBjb25zdCBzaG91bGRTaG93U2tlbGV0b25Ob3cgPSB0aGlzLnNob3VsZFNob3dTa2VsZXRvbihldmVudC51cmwpO1xuICAgICAgICAgICAgICAgIGlmICghc2hvdWxkU2hvd1NrZWxldG9uTm93ICYmIHRoaXMuc2hvd1NrZWxldG9uKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIElmIHdlIGFscmVhZHkgc2hvdyB0aGUgc2tlbGV0b24gYnV0IGRvIG5vdCB3YW50IHRvIHNob3cgdGhlIHNrZWxldG9uIGFueW1vcmUsIHdlIG5lZWQgdG8gcmVtb3ZlIHRoZSBiYWNrZ3JvdW5kXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVuZGVyZXIuYWRkQ2xhc3ModGhpcy5kb2N1bWVudC5ib2R5LCAndHJhbnNwYXJlbnQtYmFja2dyb3VuZCcpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoc2hvdWxkU2hvd1NrZWxldG9uTm93ICYmICF0aGlzLnNob3dTa2VsZXRvbikge1xuICAgICAgICAgICAgICAgICAgICAvLyBJZiB3ZSB3YW50IHRvIHNob3cgdGhlIHNrZWxldG9uIGJ1dCB3ZXJlbid0IHNob3dpbmcgaXQgcHJldmlvdXNseSB3ZSBuZWVkIHRvIHJlbW92ZSB0aGUgY2xhc3MgdG8gc2hvdyB0aGUgc2tlbGV0b24gYWdhaW5cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW5kZXJlci5yZW1vdmVDbGFzcyh0aGlzLmRvY3VtZW50LmJvZHksICd0cmFuc3BhcmVudC1iYWNrZ3JvdW5kJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIERvIG5vdyBzaG93IHNrZWxldG9uIHdoZW4gdGhlIHVybCBsaW5rcyB0byBhIHByb2JsZW0gc3RhdGVtZW50IHdoaWNoIGlzIGRpc3BsYXllZCBvbiB0aGUgbmF0aXZlIGNsaWVudHNcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dTa2VsZXRvbiA9IHNob3VsZFNob3dTa2VsZXRvbk5vdztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmpoaUxhbmd1YWdlSGVscGVyLnVwZGF0ZVRpdGxlKHRoaXMuZ2V0UGFnZVRpdGxlKHRoaXMucm91dGVyLnJvdXRlclN0YXRlLnNuYXBzaG90LnJvb3QpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FcnJvciAmJiBldmVudC5lcnJvci5zdGF0dXMgPT09IDQwNCkge1xuICAgICAgICAgICAgICAgIC8vIG5vaW5zcGVjdGlvbiBKU0lnbm9yZWRQcm9taXNlRnJvbUNhbGxcbiAgICAgICAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy80MDQnXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMudGhlbWVTZXJ2aWNlLmluaXRpYWxpemUoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUaGUgc2tlbGV0b24gc2hvdWxkIG5vdCBiZSBzaG93biBmb3IgdGhlIHByb2JsZW0gc3RhdGVtZW50IGNvbXBvbmVudCBpZiBpdCBpcyBkaXJlY3RseSBhY2Nlc3NlZCBhbmRcbiAgICAgKiBmb3IgdGhlIHN0YW5kYWxvbmUgZmVlZGJhY2sgY29tcG9uZW50LlxuICAgICAqL1xuICAgIHByaXZhdGUgc2hvdWxkU2hvd1NrZWxldG9uKHVybDogc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgICAgIGNvbnN0IGlzU3RhbmRhbG9uZVByb2JsZW1TdGF0ZW1lbnQgPSB1cmwubWF0Y2goJ1xcXFwvY291cnNlc1xcXFwvXFxcXGQrXFxcXC9leGVyY2lzZXNcXFxcL1xcXFxkK1xcXFwvcHJvYmxlbS1zdGF0ZW1lbnQoXFxcXC9cXFxcZCopPyhcXFxcLyk/Jyk7XG4gICAgICAgIGNvbnN0IGlzU3RhbmRhbG9uZUZlZWRiYWNrID0gdXJsLm1hdGNoKCdcXFxcL2NvdXJzZXNcXFxcL1xcXFxkK1xcXFwvZXhlcmNpc2VzXFxcXC9cXFxcZCtcXFxcL3BhcnRpY2lwYXRpb25zXFxcXC9cXFxcZCtcXFxcL3Jlc3VsdHNcXFxcL1xcXFxkK1xcXFwvZmVlZGJhY2soXFxcXC8pPycpO1xuICAgICAgICByZXR1cm4gIWlzU3RhbmRhbG9uZVByb2JsZW1TdGF0ZW1lbnQgJiYgIWlzU3RhbmRhbG9uZUZlZWRiYWNrO1xuICAgIH1cbn1cbiIsIjxqaGktYWxlcnQtb3ZlcmxheT48L2poaS1hbGVydC1vdmVybGF5PlxuPGRpdiBjbGFzcz1cInBhZ2Utd3JhcHBlclwiPlxuICAgIDxqaGktcGFnZS1yaWJib24+PC9qaGktcGFnZS1yaWJib24+XG4gICAgQGlmIChzaG93U2tlbGV0b24pIHtcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxyb3V0ZXItb3V0bGV0IG5hbWU9XCJuYXZiYXJcIj48L3JvdXRlci1vdXRsZXQ+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICBAaWYgKHNob3dTa2VsZXRvbikge1xuICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZFwiIHN0eWxlPVwiYm9yZGVyLXN0eWxlOiBub25lXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1ib2R5XCI+XG4gICAgICAgICAgICAgICAgPHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICBAaWYgKCFzaG93U2tlbGV0b24pIHtcbiAgICAgICAgPHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0PlxuICAgIH1cbiAgICA8amhpLW5vdGlmaWNhdGlvbi1wb3B1cD48L2poaS1ub3RpZmljYXRpb24tcG9wdXA+XG4gICAgQGlmIChzaG93U2tlbGV0b24pIHtcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxqaGktZm9vdGVyPjwvamhpLWZvb3Rlcj5cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuPC9kaXY+XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBHdWlkZWRUb3VyQ29tcG9uZW50IH0gZnJvbSAnLi9ndWlkZWQtdG91ci5jb21wb25lbnQnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGRlY2xhcmF0aW9uczogW0d1aWRlZFRvdXJDb21wb25lbnRdLFxuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlXSxcbiAgICBleHBvcnRzOiBbR3VpZGVkVG91ckNvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIEd1aWRlZFRvdXJNb2R1bGUge31cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBMb2dpblNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS9sb2dpbi9sb2dpbi5zZXJ2aWNlJztcbmltcG9ydCB7IFNhbWwyQ29uZmlnIH0gZnJvbSAnYXBwL2hvbWUvc2FtbDItbG9naW4vc2FtbDIuY29uZmlnJztcbmltcG9ydCB7IEV2ZW50TWFuYWdlciB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvZXZlbnQtbWFuYWdlci5zZXJ2aWNlJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXNhbWwyLWxvZ2luJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vc2FtbDItbG9naW4uY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlczogW10sXG59KVxuZXhwb3J0IGNsYXNzIFNhbWwyTG9naW5Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEBJbnB1dCgpXG4gICAgcmVtZW1iZXJNZSA9IHRydWU7XG4gICAgQElucHV0KClcbiAgICBhY2NlcHRlZFRlcm1zID0gZmFsc2U7XG4gICAgQElucHV0KClcbiAgICBzYW1sMlByb2ZpbGU6IFNhbWwyQ29uZmlnO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgbG9naW5TZXJ2aWNlOiBMb2dpblNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgZXZlbnRNYW5hZ2VyOiBFdmVudE1hbmFnZXIsXG4gICAgICAgIHByaXZhdGUgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIC8vIElmIFNBTUwyIGZsb3cgd2FzIHN0YXJ0ZWQsIHJldHJ5IGxvZ2luLlxuICAgICAgICBpZiAoZG9jdW1lbnQuY29va2llLmluZGV4T2YoJ1NBTUwyZmxvdz0nKSA+PSAwKSB7XG4gICAgICAgICAgICAvLyByZW1vdmUgY29va2llXG4gICAgICAgICAgICBkb2N1bWVudC5jb29raWUgPSAnU0FNTDJmbG93PTsgZXhwaXJlcz1UaHUsIDAxIEphbiAxOTcwIDAwOjAwOjAwIFVUQzsgOyBTYW1lU2l0ZT1MYXg7JztcbiAgICAgICAgICAgIHRoaXMubG9naW5TQU1MMigpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbG9naW5TQU1MMigpIHtcbiAgICAgICAgdGhpcy5sb2dpblNlcnZpY2VcbiAgICAgICAgICAgIC5sb2dpblNBTUwyKHRoaXMucmVtZW1iZXJNZSlcbiAgICAgICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmV2ZW50TWFuYWdlci5icm9hZGNhc3Qoe1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiAnYXV0aGVudGljYXRpb25TdWNjZXNzJyxcbiAgICAgICAgICAgICAgICAgICAgY29udGVudDogJ1NlbmRpbmcgQXV0aGVudGljYXRpb24gU3VjY2VzcycsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmNhdGNoKChlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MDEpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gKHJlKXNldCBjb29raWVcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuY29va2llID0gJ1NBTUwyZmxvdz10cnVlOyBtYXgtYWdlPTEyMDsgU2FtZVNpdGU9TGF4Oyc7XG4gICAgICAgICAgICAgICAgICAgIC8vIGFyYml0cmFyeSBieSBTQU1MMiBIVFRQIEZpbHRlciBDaGFpbiBzZWN1cmVkIFVSTFxuICAgICAgICAgICAgICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVwbGFjZSgnL3NhbWwyL2F1dGhlbnRpY2F0ZScpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MDMpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gZm9yIGV4YW1wbGUgaWYgdXNlciB3YXMgZGlzYWJsZWRcbiAgICAgICAgICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSAnRm9yYmlkZGVuJztcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZGV0YWlscyA9IGVycm9yLmhlYWRlcnMuZ2V0KCdYLWFydGVtaXNBcHAtZXJyb3InKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRldGFpbHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UgKz0gJzogJyArIGRldGFpbHM7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGVydFNlcnZpY2Uud2FybmluZyhtZXNzYWdlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICB9XG59XG4iLCI8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBpZD1cInNhbWwyQnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgYnRuLWxnXCIgW2Rpc2FibGVkXT1cIiFhY2NlcHRlZFRlcm1zXCIgKGNsaWNrKT1cImxvZ2luU0FNTDIoKVwiPlxuICAgIDxzcGFuPnt7IHNhbWwyUHJvZmlsZS5idXR0b25MYWJlbCB8fCAnU0FNTDIgTG9naW4nIH19PC9zcGFuPlxuPC9idXR0b24+XG4iLCJpbXBvcnQgeyBBZnRlclZpZXdDaGVja2VkLCBDb21wb25lbnQsIEVsZW1lbnRSZWYsIE9uSW5pdCwgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOZ2JNb2RhbCwgTmdiTW9kYWxSZWYgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSwgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IFVzZXIgfSBmcm9tICdhcHAvY29yZS91c2VyL3VzZXIubW9kZWwnO1xuaW1wb3J0IHsgQ3JlZGVudGlhbHMgfSBmcm9tICdhcHAvY29yZS9hdXRoL2F1dGgtand0LnNlcnZpY2UnO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBHdWlkZWRUb3VyU2VydmljZSB9IGZyb20gJ2FwcC9ndWlkZWQtdG91ci9ndWlkZWQtdG91ci5zZXJ2aWNlJztcbmltcG9ydCB7IE9yaW9uQ29ubmVjdG9yU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvb3Jpb24vb3Jpb24tY29ubmVjdG9yLnNlcnZpY2UnO1xuaW1wb3J0IHsgaXNPcmlvbiB9IGZyb20gJ2FwcC9zaGFyZWQvb3Jpb24vb3Jpb24nO1xuaW1wb3J0IHsgTW9kYWxDb25maXJtQXV0b2ZvY3VzQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC9vcmlvbi9tb2RhbC1jb25maXJtLWF1dG9mb2N1cy9tb2RhbC1jb25maXJtLWF1dG9mb2N1cy5jb21wb25lbnQnO1xuaW1wb3J0IHsgQWNjb3VudFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS9hdXRoL2FjY291bnQuc2VydmljZSc7XG5pbXBvcnQgeyBMb2dpblNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS9sb2dpbi9sb2dpbi5zZXJ2aWNlJztcbmltcG9ydCB7IFByb2ZpbGVTZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9sYXlvdXRzL3Byb2ZpbGVzL3Byb2ZpbGUuc2VydmljZSc7XG5pbXBvcnQgeyBTdGF0ZVN0b3JhZ2VTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvYXV0aC9zdGF0ZS1zdG9yYWdlLnNlcnZpY2UnO1xuaW1wb3J0IHsgUHJvZmlsZUluZm8gfSBmcm9tICdhcHAvc2hhcmVkL2xheW91dHMvcHJvZmlsZXMvcHJvZmlsZS1pbmZvLm1vZGVsJztcbmltcG9ydCB7IFBBU1NXT1JEX01JTl9MRU5HVEgsIFVTRVJOQU1FX01JTl9MRU5HVEggfSBmcm9tICdhcHAvYXBwLmNvbnN0YW50cyc7XG5pbXBvcnQgeyBFdmVudE1hbmFnZXIgfSBmcm9tICdhcHAvY29yZS91dGlsL2V2ZW50LW1hbmFnZXIuc2VydmljZSc7XG5pbXBvcnQgeyBBbGVydFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuaW1wb3J0IHsgZmFDaXJjbGVOb3RjaCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWhvbWUnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9ob21lLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnaG9tZS5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIEhvbWVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0NoZWNrZWQge1xuICAgIFVTRVJOQU1FX01JTl9MRU5HVEggPSBVU0VSTkFNRV9NSU5fTEVOR1RIO1xuICAgIFBBU1NXT1JEX01JTl9MRU5HVEggPSBQQVNTV09SRF9NSU5fTEVOR1RIO1xuICAgIGF1dGhlbnRpY2F0aW9uRXJyb3IgPSBmYWxzZTtcbiAgICBhdXRoZW50aWNhdGlvbkF0dGVtcHRzID0gMDtcbiAgICBhY2NvdW50OiBVc2VyO1xuICAgIG1vZGFsUmVmOiBOZ2JNb2RhbFJlZjtcbiAgICBwYXNzd29yZDogc3RyaW5nO1xuICAgIHJlbWVtYmVyTWUgPSB0cnVlO1xuICAgIC8vIGluIGNhc2UgdGhpcyBpcyBhY3RpdmF0ZWQgKHNlZSBhcHBsaWNhdGlvbi1hcnRlbWlzLnltbCksIHVzZXJzIGhhdmUgdG8gYWN0aXZlbHkgY2xpY2sgaW50byBpdFxuICAgIG5lZWRzVG9BY2NlcHRUZXJtcyA9IGZhbHNlO1xuICAgIHVzZXJBY2NlcHRlZFRlcm1zID0gZmFsc2U7XG4gICAgdXNlcm5hbWU6IHN0cmluZztcbiAgICBjYXB0Y2hhUmVxdWlyZWQgPSBmYWxzZTtcbiAgICBjcmVkZW50aWFsczogQ3JlZGVudGlhbHM7XG4gICAgaXNSZWdpc3RyYXRpb25FbmFibGVkID0gZmFsc2U7XG4gICAgaXNQYXNzd29yZExvZ2luRGlzYWJsZWQgPSBmYWxzZTtcbiAgICBsb2FkaW5nID0gdHJ1ZTtcbiAgICBtYWluRWxlbWVudEZvY3VzZWQgPSBmYWxzZTtcblxuICAgIC8vIGlmIHRoZSBzZXJ2ZXIgaXMgbm90IGNvbm5lY3RlZCB0byBhbiBleHRlcm5hbCB1c2VyIG1hbmFnZW1lbnQgc3VjaCBhcyBKSVJBLCB3ZSBhY2NlcHQgYWxsIHZhbGlkIHVzZXJuYW1lIHBhdHRlcm5zXG4gICAgdXNlcm5hbWVSZWdleFBhdHRlcm4gPSAvXlthLXowLTlfLV17Myw1MH0kLzsgLy8gZGVmYXVsdCwgbWlnaHQgYmUgb3ZlcnJpZGRlbiBpbiBuZ09uSW5pdFxuICAgIGVycm9yTWVzc2FnZVVzZXJuYW1lID0gJ2hvbWUuZXJyb3JzLnVzZXJuYW1lSW5jb3JyZWN0JzsgLy8gZGVmYXVsdCwgbWlnaHQgYmUgb3ZlcnJpZGRlbiBpbiBuZ09uSW5pdFxuICAgIGFjY291bnROYW1lPzogc3RyaW5nOyAvLyBhZGRpdGlvbmFsIGluZm9ybWF0aW9uIGluIHRoZSB3ZWxjb21lIG1lc3NhZ2VcblxuICAgIGV4dGVybmFsVXNlck1hbmFnZW1lbnRBY3RpdmUgPSB0cnVlO1xuICAgIGV4dGVybmFsVXNlck1hbmFnZW1lbnRVcmw6IHN0cmluZztcbiAgICBleHRlcm5hbFVzZXJNYW5hZ2VtZW50TmFtZTogc3RyaW5nO1xuXG4gICAgaXNTdWJtaXR0aW5nTG9naW4gPSBmYWxzZTtcblxuICAgIHByb2ZpbGVJbmZvOiBQcm9maWxlSW5mbyB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcblxuICAgIC8vIEljb25zXG4gICAgZmFDaXJjbGVOb3RjaCA9IGZhQ2lyY2xlTm90Y2g7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcbiAgICAgICAgcHJpdmF0ZSBhY3RpdmF0ZWRSb3V0ZTogQWN0aXZhdGVkUm91dGUsXG4gICAgICAgIHByaXZhdGUgYWNjb3VudFNlcnZpY2U6IEFjY291bnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGxvZ2luU2VydmljZTogTG9naW5TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHN0YXRlU3RvcmFnZVNlcnZpY2U6IFN0YXRlU3RvcmFnZVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgZWxlbWVudFJlZjogRWxlbWVudFJlZixcbiAgICAgICAgcHJpdmF0ZSByZW5kZXJlcjogUmVuZGVyZXIyLFxuICAgICAgICBwcml2YXRlIGV2ZW50TWFuYWdlcjogRXZlbnRNYW5hZ2VyLFxuICAgICAgICBwcml2YXRlIGd1aWRlZFRvdXJTZXJ2aWNlOiBHdWlkZWRUb3VyU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBvcmlvbkNvbm5lY3RvclNlcnZpY2U6IE9yaW9uQ29ubmVjdG9yU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBtb2RhbFNlcnZpY2U6IE5nYk1vZGFsLFxuICAgICAgICBwcml2YXRlIHByb2ZpbGVTZXJ2aWNlOiBQcm9maWxlU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBhbGVydFNlcnZpY2U6IEFsZXJ0U2VydmljZSxcbiAgICApIHt9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5wcm9maWxlU2VydmljZS5nZXRQcm9maWxlSW5mbygpLnN1YnNjcmliZSgocHJvZmlsZUluZm8pID0+IHtcbiAgICAgICAgICAgIGlmIChwcm9maWxlSW5mbykge1xuICAgICAgICAgICAgICAgIHRoaXMuaW5pdGlhbGl6ZVdpdGhQcm9maWxlSW5mbyhwcm9maWxlSW5mbyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmFjY291bnRTZXJ2aWNlLmlkZW50aXR5KCkudGhlbigodXNlcikgPT4ge1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50VXNlckNhbGxiYWNrKHVzZXIhKTtcblxuICAgICAgICAgICAgLy8gT25jZSB0aGlzIGhhcyBsb2FkZWQgYW5kIHRoZSB1c2VyIGlzIG5vdCBkZWZpbmVkLCB3ZSBrbm93IHdlIG5lZWQgdGhlIHVzZXIgdG8gbG9nIGluXG4gICAgICAgICAgICBpZiAoIXVzZXIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMucmVnaXN0ZXJBdXRoZW50aWNhdGlvblN1Y2Nlc3MoKTtcblxuICAgICAgICBjb25zdCBwcmVmaWxsZWRVc2VybmFtZSA9IHRoaXMuYWNjb3VudFNlcnZpY2UuZ2V0QW5kQ2xlYXJQcmVmaWxsZWRVc2VybmFtZSgpO1xuICAgICAgICBpZiAocHJlZmlsbGVkVXNlcm5hbWUpIHtcbiAgICAgICAgICAgIHRoaXMudXNlcm5hbWUgPSBwcmVmaWxsZWRVc2VybmFtZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEluaXRpYWxpemVzIHRoZSBjb21wb25lbnQgd2l0aCB0aGUgcmVxdWlyZWQgaW5mb3JtYXRpb24gcmVjZWl2ZWQgZnJvbSB0aGUgc2VydmVyLlxuICAgICAqIEBwYXJhbSBwcm9maWxlSW5mbyBUaGUgaW5mb3JtYXRpb24gZnJvbSB0aGUgc2VydmVyIGhvdyBsb2dpbnMgc2hvdWxkIGJlIGhhbmRsZWQuXG4gICAgICovXG4gICAgcHJpdmF0ZSBpbml0aWFsaXplV2l0aFByb2ZpbGVJbmZvKHByb2ZpbGVJbmZvOiBQcm9maWxlSW5mbykge1xuICAgICAgICB0aGlzLnByb2ZpbGVJbmZvID0gcHJvZmlsZUluZm87XG5cbiAgICAgICAgaWYgKHByb2ZpbGVJbmZvLmFjdGl2ZVByb2ZpbGVzLmluY2x1ZGVzKCdqaXJhJykpIHtcbiAgICAgICAgICAgIHRoaXMuZXh0ZXJuYWxVc2VyTWFuYWdlbWVudFVybCA9IHByb2ZpbGVJbmZvLmV4dGVybmFsVXNlck1hbmFnZW1lbnRVUkw7XG4gICAgICAgICAgICB0aGlzLmV4dGVybmFsVXNlck1hbmFnZW1lbnROYW1lID0gcHJvZmlsZUluZm8uZXh0ZXJuYWxVc2VyTWFuYWdlbWVudE5hbWU7XG4gICAgICAgICAgICBpZiAocHJvZmlsZUluZm8uYWxsb3dlZExkYXBVc2VybmFtZVBhdHRlcm4pIHtcbiAgICAgICAgICAgICAgICB0aGlzLnVzZXJuYW1lUmVnZXhQYXR0ZXJuID0gbmV3IFJlZ0V4cChwcm9maWxlSW5mby5hbGxvd2VkTGRhcFVzZXJuYW1lUGF0dGVybik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBUT0RPOiBpbiB0aGUgZnV0dXJlIHdlIG1pZ2h0IGFsc28gYWxsb3cgZXh0ZXJuYWwgdXNlciBtYW5hZ2VtZW50IGZvciBub24gamlyYSBwcm9maWxlc1xuICAgICAgICAgICAgdGhpcy5leHRlcm5hbFVzZXJNYW5hZ2VtZW50QWN0aXZlID0gZmFsc2U7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmFjY291bnROYW1lID0gcHJvZmlsZUluZm8uYWNjb3VudE5hbWU7XG4gICAgICAgIGlmICh0aGlzLmFjY291bnROYW1lID09PSAnVFVNJykge1xuICAgICAgICAgICAgdGhpcy5lcnJvck1lc3NhZ2VVc2VybmFtZSA9ICdob21lLmVycm9ycy50dW1XYXJuaW5nJztcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuaXNSZWdpc3RyYXRpb25FbmFibGVkID0gISFwcm9maWxlSW5mby5yZWdpc3RyYXRpb25FbmFibGVkO1xuICAgICAgICB0aGlzLm5lZWRzVG9BY2NlcHRUZXJtcyA9ICEhcHJvZmlsZUluZm8ubmVlZHNUb0FjY2VwdFRlcm1zO1xuICAgICAgICB0aGlzLmFjdGl2YXRlZFJvdXRlLnF1ZXJ5UGFyYW1zLnN1YnNjcmliZSgocGFyYW1zKSA9PiB7XG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcHJvdG90eXBlLWJ1aWx0aW5zXG4gICAgICAgICAgICBjb25zdCBsb2dpbkZvcm1PdmVycmlkZSA9IHBhcmFtcy5oYXNPd25Qcm9wZXJ0eSgnc2hvd0xvZ2luRm9ybScpO1xuICAgICAgICAgICAgdGhpcy5pc1Bhc3N3b3JkTG9naW5EaXNhYmxlZCA9ICEhdGhpcy5wcm9maWxlSW5mbz8uc2FtbDIgJiYgdGhpcy5wcm9maWxlSW5mby5zYW1sMi5wYXNzd29yZExvZ2luRGlzYWJsZWQgJiYgIWxvZ2luRm9ybU92ZXJyaWRlO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICByZWdpc3RlckF1dGhlbnRpY2F0aW9uU3VjY2VzcygpIHtcbiAgICAgICAgY29uc3Qgc3Vic2NyaXB0aW9uID0gdGhpcy5ldmVudE1hbmFnZXIuc3Vic2NyaWJlKCdhdXRoZW50aWNhdGlvblN1Y2Nlc3MnLCAoKSA9PiB7XG4gICAgICAgICAgICAvLyBXZSBvbmx5IG5lZWQgdG8gYXV0aGVudGljYXRlIG9uY2UsIG1ha2Ugc3VyZSB3ZSBkb24ndCBydW4gdGhpcyBzdWJzY3JpcHRpb24gbXVsdGlwbGUgdGltZXNcbiAgICAgICAgICAgIHRoaXMuZXZlbnRNYW5hZ2VyLmRlc3Ryb3koc3Vic2NyaXB0aW9uKTtcblxuICAgICAgICAgICAgdGhpcy5hY2NvdW50U2VydmljZS5pZGVudGl0eSgpLnRoZW4oKHVzZXIpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRVc2VyQ2FsbGJhY2sodXNlciEpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIG5nQWZ0ZXJWaWV3Q2hlY2tlZCgpIHtcbiAgICAgICAgLy8gT25seSBmb2N1cyB0aGUgdXNlcm5hbWUgaW5wdXQgb25jZSwgbm90IG9uIGV2ZXJ5IHVwZGF0ZVxuICAgICAgICBpZiAodGhpcy5tYWluRWxlbWVudEZvY3VzZWQgfHwgdGhpcy5sb2FkaW5nKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBGb2N1cyBvbiB0aGUgbWFpbiBlbGVtZW50IGFzIHNvb24gYXMgaXQgaXMgdmlzaWJsZVxuICAgICAgICBjb25zdCBtYWluRWxlbWVudCA9IHRoaXMucmVuZGVyZXIuc2VsZWN0Um9vdEVsZW1lbnQodGhpcy5pc1Bhc3N3b3JkTG9naW5EaXNhYmxlZCA/ICcjc2FtbDJCdXR0b24nIDogJyN1c2VybmFtZScsIHRydWUpO1xuICAgICAgICBpZiAobWFpbkVsZW1lbnQpIHtcbiAgICAgICAgICAgIG1haW5FbGVtZW50LmZvY3VzKCk7XG4gICAgICAgICAgICB0aGlzLm1haW5FbGVtZW50Rm9jdXNlZCA9IHRydWU7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJZiB0aGUgc2Vzc2lvbiBleHBpcmVkIG9yIHNpbWlsYXIgZGlzcGxheSBhIHdhcm5pbmdcbiAgICAgICAgaWYgKHRoaXMubG9naW5TZXJ2aWNlLmxhc3RMb2dvdXRXYXNGb3JjZWZ1bCgpKSB7XG4gICAgICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5lcnJvcignaG9tZS5lcnJvcnMuc2Vzc2lvbkV4cGlyZWQnKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGxvZ2luKCkge1xuICAgICAgICB0aGlzLmlzU3VibWl0dGluZ0xvZ2luID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5sb2dpblNlcnZpY2VcbiAgICAgICAgICAgIC5sb2dpbih7XG4gICAgICAgICAgICAgICAgdXNlcm5hbWU6IHRoaXMudXNlcm5hbWUsXG4gICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHRoaXMucGFzc3dvcmQsXG4gICAgICAgICAgICAgICAgcmVtZW1iZXJNZTogdGhpcy5yZW1lbWJlck1lLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC50aGVuKCgpID0+IHRoaXMuaGFuZGxlTG9naW5TdWNjZXNzKCkpXG4gICAgICAgICAgICAuY2F0Y2goKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIC8vIFRPRE86IGlmIHJlZ2lzdHJhdGlvbiBpcyBlbmFibGVkLCBoYW5kbGUgdGhlIGNhc2UgXCJVc2VyIHdhcyBub3QgYWN0aXZhdGVkXCJcbiAgICAgICAgICAgICAgICB0aGlzLmNhcHRjaGFSZXF1aXJlZCA9IGVycm9yLmhlYWRlcnMuZ2V0KCdYLWFydGVtaXNBcHAtZXJyb3InKSA9PT0gJ0NBUFRDSEEgcmVxdWlyZWQnO1xuICAgICAgICAgICAgICAgIHRoaXMuYXV0aGVudGljYXRpb25FcnJvciA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGhpcy5hdXRoZW50aWNhdGlvbkF0dGVtcHRzKys7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmZpbmFsbHkoKCkgPT4gKHRoaXMuaXNTdWJtaXR0aW5nTG9naW4gPSBmYWxzZSkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEhhbmRsZSBhIHN1Y2Nlc3NmdWwgdXNlciBsb2dpbi5cbiAgICAgKi9cbiAgICBwcml2YXRlIGhhbmRsZUxvZ2luU3VjY2VzcygpIHtcbiAgICAgICAgdGhpcy5hdXRoZW50aWNhdGlvbkVycm9yID0gZmFsc2U7XG4gICAgICAgIHRoaXMuYXV0aGVudGljYXRpb25BdHRlbXB0cyA9IDA7XG4gICAgICAgIHRoaXMuY2FwdGNoYVJlcXVpcmVkID0gZmFsc2U7XG5cbiAgICAgICAgaWYgKHRoaXMucm91dGVyLnVybCA9PT0gJy9yZWdpc3RlcicgfHwgL15cXC9hY3RpdmF0ZVxcLy8udGVzdCh0aGlzLnJvdXRlci51cmwpIHx8IC9eXFwvcmVzZXRcXC8vLnRlc3QodGhpcy5yb3V0ZXIudXJsKSkge1xuICAgICAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycnXSk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmV2ZW50TWFuYWdlci5icm9hZGNhc3Qoe1xuICAgICAgICAgICAgbmFtZTogJ2F1dGhlbnRpY2F0aW9uU3VjY2VzcycsXG4gICAgICAgICAgICBjb250ZW50OiAnU2VuZGluZyBBdXRoZW50aWNhdGlvbiBTdWNjZXNzJyxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5oYW5kbGVPcmlvbkxvZ2luKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSGFuZGxlIHNwZWNpYWwgbG9naW4gcHJvY2VkdXJlcyB3aGVuIGluc2lkZSB0aGUgT3Jpb24gcGx1Z2luLlxuICAgICAqL1xuICAgIHByaXZhdGUgaGFuZGxlT3Jpb25Mb2dpbigpIHtcbiAgICAgICAgaWYgKCFpc09yaW9uKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBtb2RhbFJlZjogTmdiTW9kYWxSZWYgPSB0aGlzLm1vZGFsU2VydmljZS5vcGVuKE1vZGFsQ29uZmlybUF1dG9mb2N1c0NvbXBvbmVudCBhcyBDb21wb25lbnQsIHsgc2l6ZTogJ2xnJywgYmFja2Ryb3A6ICdzdGF0aWMnIH0pO1xuICAgICAgICBtb2RhbFJlZi5jb21wb25lbnRJbnN0YW5jZS50ZXh0ID0gJ2xvZ2luLmlkZS5jb25maXJtYXRpb24nO1xuICAgICAgICBtb2RhbFJlZi5jb21wb25lbnRJbnN0YW5jZS50aXRsZSA9ICdsb2dpbi5pZGUudGl0bGUnO1xuICAgICAgICBtb2RhbFJlZi5yZXN1bHQudGhlbihcbiAgICAgICAgICAgICgpID0+IHRoaXMub3Jpb25Db25uZWN0b3JTZXJ2aWNlLmxvZ2luKHRoaXMudXNlcm5hbWUsIHRoaXMucGFzc3dvcmQpLFxuICAgICAgICAgICAgKCkgPT4ge30sXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgY3VycmVudFVzZXJDYWxsYmFjayhhY2NvdW50OiBVc2VyKSB7XG4gICAgICAgIHRoaXMuYWNjb3VudCA9IGFjY291bnQ7XG4gICAgICAgIGlmIChhY2NvdW50KSB7XG4gICAgICAgICAgICAvLyBwcmV2aW91c1N0YXRlIHdhcyBzZXQgaW4gdGhlIGF1dGhFeHBpcmVkSW50ZXJjZXB0b3IgYmVmb3JlIGJlaW5nIHJlZGlyZWN0ZWQgdG8gdGhlIGxvZ2luIG1vZGFsLlxuICAgICAgICAgICAgLy8gc2luY2UgbG9naW4gaXMgc3VjY2Vzc2Z1bCwgZ28gdG8gc3RvcmVkIHByZXZpb3VzU3RhdGUgYW5kIGNsZWFyIHByZXZpb3VzU3RhdGVcbiAgICAgICAgICAgIGNvbnN0IHJlZGlyZWN0ID0gdGhpcy5zdGF0ZVN0b3JhZ2VTZXJ2aWNlLmdldFVybCgpO1xuICAgICAgICAgICAgaWYgKHJlZGlyZWN0ICYmIHJlZGlyZWN0ICE9PSAnJykge1xuICAgICAgICAgICAgICAgIHRoaXMuc3RhdGVTdG9yYWdlU2VydmljZS5zdG9yZVVybCgnJyk7XG4gICAgICAgICAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGVCeVVybChyZWRpcmVjdCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFsnY291cnNlcyddKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIGlzQXV0aGVudGljYXRlZCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuYWNjb3VudFNlcnZpY2UuaXNBdXRoZW50aWNhdGVkKCk7XG4gICAgfVxuXG4gICAgaW5wdXRDaGFuZ2UoZXZlbnQ6IGFueSkge1xuICAgICAgICBpZiAoZXZlbnQudGFyZ2V0ICYmIGV2ZW50LnRhcmdldC5uYW1lID09PSAndXNlcm5hbWUnKSB7XG4gICAgICAgICAgICB0aGlzLnVzZXJuYW1lID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChldmVudC50YXJnZXQgJiYgZXZlbnQudGFyZ2V0Lm5hbWUgPT09ICdwYXNzd29yZCcpIHtcbiAgICAgICAgICAgIHRoaXMucGFzc3dvcmQgPSBldmVudC50YXJnZXQudmFsdWU7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCI8ZGl2IFtoaWRkZW5dPVwibG9hZGluZyB8fCBhY2NvdW50XCIgY2xhc3M9XCJjb250YWluZXItZmx1aWRcIj5cbiAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtbWQtOCBvZmZzZXQtbWQtMiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgPGgxIGpoaVRyYW5zbGF0ZT1cImhvbWUudGl0bGVcIj5XZWxjb21lIHRvIEFydGVtaXMhPC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzPVwibGVhZFwiIGpoaVRyYW5zbGF0ZT1cImhvbWUuc3VidGl0bGVcIj5JbnRlcmFjdGl2ZSBMZWFybmluZyB3aXRoIEluZGl2aWR1YWwgRmVlZGJhY2s8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJyb3cgcm93LWRpdmlkZWQgbXktNCBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyXCI+XG4gICAgICAgIEBpZiAoIWlzUGFzc3dvcmRMb2dpbkRpc2FibGVkKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibG9naW4tY29sIGNvbC0xMiBjb2wteGwtNSBoLTEwMFwiPlxuICAgICAgICAgICAgICAgIDwhLS0gVHJhZGl0aW9uYWwgQXV0aGVudGljYXRpb24gLS0+XG4gICAgICAgICAgICAgICAgQGlmICghYWNjb3VudE5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBbamhpVHJhbnNsYXRlXT1cIidob21lLmxvZ2luLnRyYWRpdGlvbmFsLnBsZWFzZVNpZ25JbidcIiBjbGFzcz1cImxlYWQgdGV4dC1jZW50ZXJcIj5QbGVhc2Ugc2lnbiBpbiB3aXRoIHlvdXIgYWNjb3VudC48L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmIChhY2NvdW50TmFtZSkge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2IFtqaGlUcmFuc2xhdGVdPVwiJ2hvbWUubG9naW4udHJhZGl0aW9uYWwucGxlYXNlU2lnbkluQWNjb3VudCdcIiBbdHJhbnNsYXRlVmFsdWVzXT1cInsgYWNjb3VudDogYWNjb3VudE5hbWUgfVwiIGNsYXNzPVwibGVhZCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgUGxlYXNlIHNpZ24gaW4gd2l0aCB5b3VyIGFjY291bnQuXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibG9naW4tZm9ybVwiPlxuICAgICAgICAgICAgICAgICAgICA8Zm9ybSAoY2hhbmdlKT1cImlucHV0Q2hhbmdlKCRldmVudClcIiAobmdTdWJtaXQpPVwibG9naW4oKVwiIGNsYXNzPVwibWItNVwiIG5hbWU9XCJsb2dpbkZvcm1cIiByb2xlPVwiZm9ybVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGF1dGhlbnRpY2F0aW9uRXJyb3IgJiYgIWNhcHRjaGFSZXF1aXJlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWxlcnQgYWxlcnQtZGFuZ2VyIG15LTNcIiBqaGlUcmFuc2xhdGU9XCJob21lLmVycm9ycy5mYWlsZWRUb0xvZ2luXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJvbGRcIj5GYWlsZWQgdG8gc2lnbiBpbiE8L3NwYW4+IFBsZWFzZSBjaGVjayB5b3VyIHVzZXJuYW1lIGFuZCBwYXNzd29yZCBhbmQgdHJ5IGFnYWluLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChleHRlcm5hbFVzZXJNYW5hZ2VtZW50QWN0aXZlICYmIGF1dGhlbnRpY2F0aW9uQXR0ZW1wdHMgPj0gMyAmJiAhY2FwdGNoYVJlcXVpcmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhbGVydCBhbGVydC1pbmZvIG15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIFtpbm5lckhUTUxdPVwiJ2hvbWUuZXJyb3JzLmxvZ2luV2FybmluZycgfCBhcnRlbWlzVHJhbnNsYXRlOiB7IHVybDogZXh0ZXJuYWxVc2VyTWFuYWdlbWVudFVybCwgbmFtZTogZXh0ZXJuYWxVc2VyTWFuYWdlbWVudE5hbWUgfVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZXh0ZXJuYWxVc2VyTWFuYWdlbWVudEFjdGl2ZSAmJiBjYXB0Y2hhUmVxdWlyZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFsZXJ0IGFsZXJ0LWRhbmdlciBteS0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtpbm5lckhUTUxdPVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdob21lLmVycm9ycy5leHRlcm5hbFVzZXJNYW5hZ2VtZW50V2FybmluZycgfCBhcnRlbWlzVHJhbnNsYXRlOiB7IHVybDogZXh0ZXJuYWxVc2VyTWFuYWdlbWVudFVybCwgbmFtZTogZXh0ZXJuYWxVc2VyTWFuYWdlbWVudE5hbWUgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiZm9udC13ZWlnaHQtYm9sZFwiIGZvcj1cInVzZXJuYW1lXCIgamhpVHJhbnNsYXRlPVwiZ2xvYmFsLmZvcm0udXNlcm5hbWVcIj5Mb2dpbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICN1c2VybmFtZUZvcm09XCJuZ01vZGVsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJ1c2VybmFtZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ01vZGVsT3B0aW9uc109XCJ7IHVwZGF0ZU9uOiAnYmx1cicgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtwYXR0ZXJuXT1cInVzZXJuYW1lUmVnZXhQYXR0ZXJuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b2NvbXBsZXRlPVwidXNlcm5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwidXNlcm5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidXNlcm5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInt7ICdnbG9iYWwuZm9ybS51c2VybmFtZS5wbGFjZWhvbGRlcicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICh1c2VybmFtZUZvcm0uZXJyb3JzICYmICh1c2VybmFtZUZvcm0uZGlydHkgfHwgdXNlcm5hbWVGb3JtLnRvdWNoZWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgW2poaVRyYW5zbGF0ZV09XCJlcnJvck1lc3NhZ2VVc2VybmFtZVwiIGNsYXNzPVwiaGVscC1ibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXByaW1hcnkgc21hbGxcIj5JbnZhbGlkIHVzZXJuYW1lPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiZm9udC13ZWlnaHQtYm9sZFwiIGZvcj1cInBhc3N3b3JkXCIgamhpVHJhbnNsYXRlPVwibG9naW4uZm9ybS5wYXNzd29yZFwiPlBhc3N3b3JkPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9jb21wbGV0ZT1cImN1cnJlbnQtcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInt7ICdsb2dpbi5mb3JtLnBhc3N3b3JkLnBsYWNlaG9sZGVyJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tY2hlY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1jaGVjay1sYWJlbFwiIGZvcj1cInJlbWVtYmVyTWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBbKG5nTW9kZWwpXT1cInJlbWVtYmVyTWVcIiBjaGVja2VkIGNsYXNzPVwiZm9ybS1jaGVjay1pbnB1dFwiIGlkPVwicmVtZW1iZXJNZVwiIG5hbWU9XCJyZW1lbWJlck1lXCIgdHlwZT1cImNoZWNrYm94XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImxvZ2luLmZvcm0ucmVtZW1iZXJtZVwiPlJlbWVtYmVyIG1lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAobmVlZHNUb0FjY2VwdFRlcm1zKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWNoZWNrXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJmb3JtLWNoZWNrLWxhYmVsXCIgZm9yPVwiYWNjZXB0VGVybXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgWyhuZ01vZGVsKV09XCJ1c2VyQWNjZXB0ZWRUZXJtc1wiIGNoZWNrZWQgY2xhc3M9XCJmb3JtLWNoZWNrLWlucHV0XCIgaWQ9XCJhY2NlcHRUZXJtc1wiIG5hbWU9XCJhY2NlcHRUZXJtc1wiIHR5cGU9XCJjaGVja2JveFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWydwcml2YWN5J11cIiBqaGlUcmFuc2xhdGU9XCJsb2dpbi5mb3JtLmFjY2VwdFRlcm1zXCI+QWNjZXB0IHRlcm1zPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYnRuLXRvb2xiYXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtkaXNhYmxlZF09XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzU3VibWl0dGluZ0xvZ2luIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoIXVzZXJBY2NlcHRlZFRlcm1zICYmIG5lZWRzVG9BY2NlcHRUZXJtcykgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFwYXNzd29yZCB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQubGVuZ3RoIDwgUEFTU1dPUkRfTUlOX0xFTkdUSCB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIXVzZXJuYW1lIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VybmFtZS5sZW5ndGggPCBVU0VSTkFNRV9NSU5fTEVOR1RIXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJsb2dpbi1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoaXNTdWJtaXR0aW5nTG9naW4pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibWUtMVwiPjxmYS1pY29uIFtpY29uXT1cImZhQ2lyY2xlTm90Y2hcIiBbc3Bpbl09XCJ0cnVlXCI+PC9mYS1pY29uPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJsb2dpbi5mb3JtLmJ1dHRvblwiPiBTaWduIGluIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChpc1JlZ2lzdHJhdGlvbkVuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJnbG9iYWwubWVzc2FnZXMuaW5mby5yZWdpc3Rlci5ub2FjY291bnRcIj5Zb3UgZG9uJ3QgaGF2ZSBhbiBhY2NvdW50IHlldD88L3NwYW4+Jm5ic3A7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiYWxlcnQtbGlua1wiIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5tZXNzYWdlcy5pbmZvLnJlZ2lzdGVyLmxpbmtcIiByb3V0ZXJMaW5rPVwiYWNjb3VudC9yZWdpc3RlclwiPlJlZ2lzdGVyIGEgbmV3IGFjY291bnQ8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImFsZXJ0LWxpbmtcIiBqaGlUcmFuc2xhdGU9XCJsb2dpbi5wYXNzd29yZC5mb3Jnb3RcIiByb3V0ZXJMaW5rPVwiYWNjb3VudC9yZXNldC9yZXF1ZXN0XCI+RGlkIHlvdSBmb3JnZXQgeW91ciBwYXNzd29yZD88L2E+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgQGlmICghaXNQYXNzd29yZExvZ2luRGlzYWJsZWQgJiYgISFwcm9maWxlSW5mbz8uc2FtbDIpIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtMTIgY29sLXhsLTIgcHktNSBoLTEwMFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLW5vbmUgZC14bC1ibG9jayB2ZXJ0aWNhbC1kaXZpZGVyXCIgamhpVHJhbnNsYXRlPVwibG9naW4uZGl2aWRlclwiPm9yPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQteGwtbm9uZSBob3Jpem9udGFsLWRpdmlkZXJcIiBqaGlUcmFuc2xhdGU9XCJsb2dpbi5kaXZpZGVyXCI+b3I8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICAgIEBpZiAoISFwcm9maWxlSW5mbz8uc2FtbDIpIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsb2dpbi1jb2wgY29sLTEyIGNvbC14bC01XCI+XG4gICAgICAgICAgICAgICAgPCEtLSBTQU1MMiBBdXRoZW50aWNhdGlvbiAtLT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaC0xMDAgZC1mbGV4IGZsZXgtY29sdW1uIGFsaWduLWl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoIXByb2ZpbGVJbmZvIS5zYW1sMiEuaWRlbnRpdHlQcm92aWRlck5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgW2poaVRyYW5zbGF0ZV09XCInaG9tZS5sb2dpbi5zYW1sMi5wbGVhc2VTaWduSW4nXCIgY2xhc3M9XCJsZWFkIHRleHQtY2VudGVyXCI+UGxlYXNlIHNpZ24gaW4gdmlhIFNpbmdsZSBTaWduLW9uLjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAocHJvZmlsZUluZm8hLnNhbWwyIS5pZGVudGl0eVByb3ZpZGVyTmFtZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtqaGlUcmFuc2xhdGVdPVwiJ2hvbWUubG9naW4uc2FtbDIucGxlYXNlU2lnbkluUHJvdmlkZXInXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdHJhbnNsYXRlVmFsdWVzXT1cInsgcHJvdmlkZXI6IHByb2ZpbGVJbmZvIS5zYW1sMiEuaWRlbnRpdHlQcm92aWRlck5hbWUgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJsZWFkIHRleHQtY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQbGVhc2Ugc2lnbiBpbi5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzYW1sMi1jZW50ZXIgZC1mbGV4IGZsZXgtY29sdW1uIGFsaWduLWl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIGZsZXgtZ3Jvdy0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAobmVlZHNUb0FjY2VwdFRlcm1zKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWNoZWNrXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJmb3JtLWNoZWNrLWxhYmVsXCIgZm9yPVwiYWNjZXB0VGVybXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgWyhuZ01vZGVsKV09XCJ1c2VyQWNjZXB0ZWRUZXJtc1wiIGNsYXNzPVwiZm9ybS1jaGVjay1pbnB1dFwiIHR5cGU9XCJjaGVja2JveFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWydwcml2YWN5J11cIiBqaGlUcmFuc2xhdGU9XCJsb2dpbi5mb3JtLmFjY2VwdFRlcm1zXCI+QWNjZXB0IHRlcm1zPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8amhpLXNhbWwyLWxvZ2luXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2FjY2VwdGVkVGVybXNdPVwiIW5lZWRzVG9BY2NlcHRUZXJtcyB8fCB1c2VyQWNjZXB0ZWRUZXJtc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW3JlbWVtYmVyTWVdPVwicmVtZW1iZXJNZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW3NhbWwyUHJvZmlsZV09XCJwcm9maWxlSW5mbyEuc2FtbDIhXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImQtYmxvY2sgdGV4dC1jZW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvamhpLXNhbWwyLWxvZ2luPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgPC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IEhvbWVDb21wb25lbnQgfSBmcm9tICdhcHAvaG9tZS9ob21lLmNvbXBvbmVudCc7XG5cbmV4cG9ydCBjb25zdCBIT01FX1JPVVRFOiBSb3V0ZSA9IHtcbiAgICBwYXRoOiAnJyxcbiAgICBjb21wb25lbnQ6IEhvbWVDb21wb25lbnQsXG4gICAgZGF0YToge1xuICAgICAgICBhdXRob3JpdGllczogW10sXG4gICAgICAgIHBhZ2VUaXRsZTogJ2hvbWUudGl0bGUnLFxuICAgIH0sXG59O1xuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJvdXRlck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBIT01FX1JPVVRFIH0gZnJvbSAnLi9ob21lLnJvdXRlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgSG9tZUNvbXBvbmVudCB9IGZyb20gJ2FwcC9ob21lL2hvbWUuY29tcG9uZW50JztcbmltcG9ydCB7IFNhbWwyTG9naW5Db21wb25lbnQgfSBmcm9tICcuL3NhbWwyLWxvZ2luL3NhbWwyLWxvZ2luLmNvbXBvbmVudCc7XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW0FydGVtaXNTaGFyZWRNb2R1bGUsIFJvdXRlck1vZHVsZS5mb3JDaGlsZChbSE9NRV9ST1VURV0pXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtIb21lQ29tcG9uZW50LCBTYW1sMkxvZ2luQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc0hvbWVNb2R1bGUge31cbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBVc2VyIH0gZnJvbSAnYXBwL2NvcmUvdXNlci91c2VyLm1vZGVsJztcbmltcG9ydCB7IEFjY291bnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvYXV0aC9hY2NvdW50LnNlcnZpY2UnO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uLCB0YXAgfSBmcm9tICdyeGpzJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktYWNjb3VudC1pbmZvcm1hdGlvbicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2FjY291bnQtaW5mb3JtYXRpb24uY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuLi91c2VyLXNldHRpbmdzLnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgQWNjb3VudEluZm9ybWF0aW9uQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICBjdXJyZW50VXNlcj86IFVzZXI7XG5cbiAgICBwcml2YXRlIGF1dGhTdGF0ZVN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBhY2NvdW50U2VydmljZTogQWNjb3VudFNlcnZpY2UpIHt9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5hdXRoU3RhdGVTdWJzY3JpcHRpb24gPSB0aGlzLmFjY291bnRTZXJ2aWNlXG4gICAgICAgICAgICAuZ2V0QXV0aGVudGljYXRpb25TdGF0ZSgpXG4gICAgICAgICAgICAucGlwZSh0YXAoKHVzZXI6IFVzZXIpID0+ICh0aGlzLmN1cnJlbnRVc2VyID0gdXNlcikpKVxuICAgICAgICAgICAgLnN1YnNjcmliZSgpO1xuICAgIH1cbn1cbiIsIjxoMT5cbiAgICA8IS0tQWNjb3VudCBJbmZvcm1hdGlvbi0tPlxuICAgIHt7ICdhcnRlbWlzQXBwLnVzZXJTZXR0aW5ncy5hY2NvdW50SW5mb3JtYXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuPC9oMT5cbkBpZiAoY3VycmVudFVzZXIpIHtcbiAgICA8ZGl2IGNsYXNzPVwibGlzdC1ncm91cCBkLWJsb2NrXCI+XG4gICAgICAgIEBpZiAoY3VycmVudFVzZXIubmFtZSkge1xuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxpc3QtZ3JvdXAtaXRlbVwiPlxuICAgICAgICAgICAgICAgIDxkdD5cbiAgICAgICAgICAgICAgICAgICAgPCEtLUZ1bGwgTmFtZS0tPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC51c2VyU2V0dGluZ3MuYWNjb3VudEluZm9ybWF0aW9uUGFnZS5mdWxsTmFtZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgPC9kdD5cbiAgICAgICAgICAgICAgICA8ZGQ+e3sgY3VycmVudFVzZXIubmFtZSB9fTwvZGQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgICBAaWYgKGN1cnJlbnRVc2VyLmxvZ2luKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGlzdC1ncm91cC1pdGVtXCI+XG4gICAgICAgICAgICAgICAgPGR0PlxuICAgICAgICAgICAgICAgICAgICA8IS0tTG9naW4tLT5cbiAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAudXNlclNldHRpbmdzLmFjY291bnRJbmZvcm1hdGlvblBhZ2UubG9naW4nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgIDwvZHQ+XG4gICAgICAgICAgICAgICAgPGRkPnt7IGN1cnJlbnRVc2VyLmxvZ2luIH19PC9kZD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICAgIEBpZiAoY3VycmVudFVzZXIuZW1haWwpIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsaXN0LWdyb3VwLWl0ZW1cIj5cbiAgICAgICAgICAgICAgICA8ZHQ+XG4gICAgICAgICAgICAgICAgICAgIDwhLS1FbWFpbC0tPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC51c2VyU2V0dGluZ3MuYWNjb3VudEluZm9ybWF0aW9uUGFnZS5lbWFpbCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgPC9kdD5cbiAgICAgICAgICAgICAgICA8ZGQ+e3sgY3VycmVudFVzZXIuZW1haWwgfX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChjdXJyZW50VXNlci52aXNpYmxlUmVnaXN0cmF0aW9uTnVtYmVyKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGlzdC1ncm91cC1pdGVtXCI+XG4gICAgICAgICAgICAgICAgPGR0PlxuICAgICAgICAgICAgICAgICAgICA8IS0tUmVnaXN0cmF0aW9uIE51bWJlci0tPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC51c2VyU2V0dGluZ3MuYWNjb3VudEluZm9ybWF0aW9uUGFnZS5yZWdpc3RyYXRpb25OdW1iZXInIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgIDwvZHQ+XG4gICAgICAgICAgICAgICAgPGRkPnt7IGN1cnJlbnRVc2VyLnZpc2libGVSZWdpc3RyYXRpb25OdW1iZXIgfX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChjdXJyZW50VXNlci5jcmVhdGVkRGF0ZSkge1xuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxpc3QtZ3JvdXAtaXRlbVwiPlxuICAgICAgICAgICAgICAgIDxkdD5cbiAgICAgICAgICAgICAgICAgICAgPCEtLUpvaW5lZCBBcnRlbWlzIG9uLS0+XG4gICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLnVzZXJTZXR0aW5ncy5hY2NvdW50SW5mb3JtYXRpb25QYWdlLmpvaW5lZEFydGVtaXMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgIDwvZHQ+XG4gICAgICAgICAgICAgICAgPGRkPnt7IGN1cnJlbnRVc2VyLmNyZWF0ZWREYXRlIHwgYXJ0ZW1pc0RhdGUgfX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICA8L2Rpdj5cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZmFVc2VyIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IEFjY291bnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvYXV0aC9hY2NvdW50LnNlcnZpY2UnO1xuaW1wb3J0IHsgQWNjb3VudEluZm9ybWF0aW9uQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC91c2VyLXNldHRpbmdzL2FjY291bnQtaW5mb3JtYXRpb24vYWNjb3VudC1pbmZvcm1hdGlvbi5jb21wb25lbnQnO1xuXG4vKipcbiAqIFVzZXJTZXR0aW5nc0NvbnRhaW5lckNvbXBvbmVudCBzZXJ2ZXMgYXMgdGhlIGNvbW1vbiBncm91bmQgZm9yIGRpZmZlcmVudCBzZXR0aW5nc1xuICovXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS11c2VyLXNldHRpbmdzJyxcbiAgICB0ZW1wbGF0ZVVybDogJ3VzZXItc2V0dGluZ3MtY29udGFpbmVyLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsndXNlci1zZXR0aW5ncy1jb250YWluZXIuY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgVXNlclNldHRpbmdzQ29udGFpbmVyQ29tcG9uZW50IGV4dGVuZHMgQWNjb3VudEluZm9ybWF0aW9uQ29tcG9uZW50IHtcbiAgICAvLyBJY29uc1xuICAgIGZhVXNlciA9IGZhVXNlcjtcblxuICAgIGNvbnN0cnVjdG9yKGFjY291bnRTZXJ2aWNlOiBBY2NvdW50U2VydmljZSkge1xuICAgICAgICBzdXBlcihhY2NvdW50U2VydmljZSk7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cImNvbnRhaW5lclwiPlxuICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1sZy0zIGNvbC1zbS0xMlwiPlxuICAgICAgICAgICAgPCEtLSBwcm9maWxlIGhlYWRlciAtLT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXhcIj5cbiAgICAgICAgICAgICAgICA8ZmEtaWNvbiBpZD1cImF2YXRhclwiIHNpemU9XCIzeFwiIFtpY29uXT1cImZhVXNlclwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICBAaWYgKGN1cnJlbnRVc2VyKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGN1cnJlbnRVc2VyLm5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBpZD1cInVzZXItaGVhZGVyXCI+e3sgY3VycmVudFVzZXIubmFtZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gaWQ9XCJsb2dpblwiPnt7IGN1cnJlbnRVc2VyLmxvZ2luIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwhLS0gbGlua3MgdG8gdGhlIGRpZmZlcmVudCBzZXR0aW5ncyAtLT5cbiAgICAgICAgICAgIDxzZWN0aW9uIGlkPVwibmF2aWdhdGlvbi1iYXJcIiBjbGFzcz1cImxpc3QtZ3JvdXAgZC1ibG9jayBwdC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsaXN0LWdyb3VwLWl0ZW0gZGlzYWJsZWQgZnctYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICA8IS0tVXNlciBTZXR0aW5ncyBNZW51IFRpdGxlLS0+XG4gICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLnVzZXJTZXR0aW5ncy51c2VyU2V0dGluZ3MnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImxpc3QtZ3JvdXAtaXRlbSBidG4gYnRuLW91dGxpbmUtcHJpbWFyeVwiIHJvdXRlckxpbms9XCJhY2NvdW50XCIgcm91dGVyTGlua0FjdGl2ZT1cImFjdGl2ZVwiPlxuICAgICAgICAgICAgICAgICAgICA8IS0tQWNjb3VudCBJbmZvcm1hdGlvbi0tPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC51c2VyU2V0dGluZ3MuYWNjb3VudEluZm9ybWF0aW9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJsaXN0LWdyb3VwLWl0ZW0gYnRuIGJ0bi1vdXRsaW5lLXByaW1hcnlcIiByb3V0ZXJMaW5rPVwibm90aWZpY2F0aW9uc1wiIHJvdXRlckxpbmtBY3RpdmU9XCJhY3RpdmVcIj5cbiAgICAgICAgICAgICAgICAgICAgPCEtLU5vdGlmaWNhdGlvbiBTZXR0aW5ncy0tPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC51c2VyU2V0dGluZ3Mubm90aWZpY2F0aW9uU2V0dGluZ3MnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDwhLS0gdGhlIGN1cnJlbnRseSBvcGVuZWQgc2V0dGluZ3MgLS0+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtbGctOCBjb2wtc20tMTJcIj5cbiAgICAgICAgICAgIDxzZWN0aW9uIGlkPVwiY3VycmVudC1zZXR0aW5nc1wiPlxuICAgICAgICAgICAgICAgIDxyb3V0ZXItb3V0bGV0Pjwvcm91dGVyLW91dGxldD5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IEh0dHBFcnJvclJlc3BvbnNlLCBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBDaGFuZ2VEZXRlY3RvclJlZiwgRGlyZWN0aXZlLCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFVzZXIgfSBmcm9tICdhcHAvY29yZS91c2VyL3VzZXIubW9kZWwnO1xuaW1wb3J0IHsgVXNlclNldHRpbmdzQ2F0ZWdvcnkgfSBmcm9tICdhcHAvc2hhcmVkL2NvbnN0YW50cy91c2VyLXNldHRpbmdzLmNvbnN0YW50cyc7XG5pbXBvcnQgeyBTZXR0aW5nLCBVc2VyU2V0dGluZ3NTdHJ1Y3R1cmUgfSBmcm9tICdhcHAvc2hhcmVkL3VzZXItc2V0dGluZ3MvdXNlci1zZXR0aW5ncy5tb2RlbCc7XG5pbXBvcnQgeyBVc2VyU2V0dGluZ3NTZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC91c2VyLXNldHRpbmdzL3VzZXItc2V0dGluZ3Muc2VydmljZSc7XG5pbXBvcnQgeyBBbGVydFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuXG4vKipcbiAqIElzIHVzZWQgYXMgdGhlIGFic3RyYWN0IHVzZXItc2V0dGluZ3MgXCJwYXJlbnRcIiB3aXRoIGFsbCB0aGUgbmVjZXNzYXJ5IGJhc2ljIGxvZ2ljIGZvciBvdGhlciBcImNoaWxkXCIgY29tcG9uZW50cyB0byBpbXBsZW1lbnQvaW5oZXJpdCBmcm9tLlxuICovXG5ARGlyZWN0aXZlKClcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBVc2VyU2V0dGluZ3NEaXJlY3RpdmUgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIC8vIEhUTUwgdGVtcGxhdGUgcmVsYXRlZFxuICAgIHNldHRpbmdzQ2hhbmdlZCA9IGZhbHNlO1xuICAgIGN1cnJlbnRVc2VyOiBVc2VyO1xuXG4gICAgLy8gdXNlclNldHRpbmdzIGxvZ2ljIHJlbGF0ZWRcbiAgICB1c2VyU2V0dGluZ3NDYXRlZ29yeTogVXNlclNldHRpbmdzQ2F0ZWdvcnk7XG4gICAgY2hhbmdlRXZlbnRNZXNzYWdlOiBzdHJpbmc7XG4gICAgdXNlclNldHRpbmdzOiBVc2VyU2V0dGluZ3NTdHJ1Y3R1cmU8U2V0dGluZz47XG4gICAgc2V0dGluZ3M6IEFycmF5PFNldHRpbmc+O1xuICAgIHBhZ2UgPSAwO1xuICAgIGVycm9yPzogc3RyaW5nO1xuXG4gICAgcHJvdGVjdGVkIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcm90ZWN0ZWQgdXNlclNldHRpbmdzU2VydmljZTogVXNlclNldHRpbmdzU2VydmljZSxcbiAgICAgICAgcHJvdGVjdGVkIGFsZXJ0U2VydmljZTogQWxlcnRTZXJ2aWNlLFxuICAgICAgICBwcm90ZWN0ZWQgY2hhbmdlRGV0ZWN0b3I6IENoYW5nZURldGVjdG9yUmVmLFxuICAgICkge31cblxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5jbG9zZUFsbCgpO1xuICAgICAgICB0aGlzLmxvYWRTZXR0aW5nKCk7XG4gICAgfVxuXG4gICAgLy8gbWV0aG9kcyByZWxhdGVkIHRvIGxvYWRpbmdcblxuICAgIC8qKlxuICAgICAqIEZldGNoZXMgdGhlIHNldHRpbmdzIGJhc2VkIG9uIHRoZSBzZXR0aW5ncyBjYXRlZ29yeSwgdXBkYXRlcyB0aGUgY3VycmVudGx5IGxvYWRlZCB1c2VyU2V0dGluZ3NTdHJ1Y3R1cmUsIGluZGl2aWR1YWwgc2V0dGluZ3MsIGFuZCBIVE1MIHRlbXBsYXRlXG4gICAgICovXG4gICAgcHJvdGVjdGVkIGxvYWRTZXR0aW5nKCk6IHZvaWQge1xuICAgICAgICB0aGlzLnVzZXJTZXR0aW5nc1NlcnZpY2UubG9hZFNldHRpbmdzKHRoaXMudXNlclNldHRpbmdzQ2F0ZWdvcnkpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAocmVzOiBIdHRwUmVzcG9uc2U8U2V0dGluZ1tdPikgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMudXNlclNldHRpbmdzID0gdGhpcy51c2VyU2V0dGluZ3NTZXJ2aWNlLmxvYWRTZXR0aW5nc1N1Y2Nlc3NBc1NldHRpbmdzU3RydWN0dXJlKHJlcy5ib2R5ISwgdGhpcy51c2VyU2V0dGluZ3NDYXRlZ29yeSk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHRoaXMudXNlclNldHRpbmdzU2VydmljZS5leHRyYWN0SW5kaXZpZHVhbFNldHRpbmdzRnJvbVNldHRpbmdzU3RydWN0dXJlKHRoaXMudXNlclNldHRpbmdzKTtcbiAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZURldGVjdG9yLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5jbG9zZUFsbCgpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yOiAocmVzOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4gdGhpcy5vbkVycm9yKHJlcyksXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8vIG1ldGhvZHMgcmVsYXRlZCB0byBzYXZpbmdcblxuICAgIC8qKlxuICAgICAqIElzIGludm9rZWQgYnkgY2xpY2tpbmcgdGhlIHNhdmUgYnV0dG9uXG4gICAgICogU2VuZHMgYWxsIHNldHRpbmdzIHdoaWNoIHdlcmUgY2hhbmdlZCBieSB0aGUgdXNlciB0byB0aGUgc2VydmVyIGZvciBzYXZpbmdcbiAgICAgKi9cbiAgICBwdWJsaWMgc2F2ZVNldHRpbmdzKCkge1xuICAgICAgICB0aGlzLnVzZXJTZXR0aW5nc1NlcnZpY2Uuc2F2ZVNldHRpbmdzKHRoaXMuc2V0dGluZ3MsIHRoaXMudXNlclNldHRpbmdzQ2F0ZWdvcnkpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAocmVzOiBIdHRwUmVzcG9uc2U8U2V0dGluZ1tdPikgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMudXNlclNldHRpbmdzID0gdGhpcy51c2VyU2V0dGluZ3NTZXJ2aWNlLnNhdmVTZXR0aW5nc1N1Y2Nlc3ModGhpcy51c2VyU2V0dGluZ3MsIHJlcy5ib2R5ISk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHRoaXMudXNlclNldHRpbmdzU2VydmljZS5leHRyYWN0SW5kaXZpZHVhbFNldHRpbmdzRnJvbVNldHRpbmdzU3RydWN0dXJlKHRoaXMudXNlclNldHRpbmdzKTtcbiAgICAgICAgICAgICAgICB0aGlzLmZpbmlzaFNhdmluZygpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yOiAocmVzOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4gdGhpcy5vbkVycm9yKHJlcyksXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEZpbmFsaXplcyB0aGUgc2F2aW5nIHByb2Nlc3MgYnkgc2V0dGluZyB0aGUgSFRNTCB0ZW1wbGF0ZSBiYWNrIHRvIGFuIHVuY2hhbmdlZCBzdGF0ZSAoZS5nLiBoaWRlcyBzYXZlLWJ1dHRvbiksXG4gICAgICogaW5mb3JtaW5nIHRoZSB1c2VyIGJ5IHNlbmRpbmcgb3V0IGFuIGFsZXJ0IHRoYXQgdGhlIG5ldyBzZXR0aW5ncyB3ZXJlIHN1Y2Nlc3NmdWxseSBzYXZlZCxcbiAgICAgKiBhbmQgcHJvcGFnYXRlcyB0aGlzIGNoYW5nZSB0byBvdGhlciBjb21wb25lbnRzIGFuZCBzZXJ2aWNlcyB3aGljaCBhcmUgYWZmZWN0ZWQgYnkgdGhlc2UgY2hhbmdlZCBzZXR0aW5nc1xuICAgICAqL1xuICAgIHByb3RlY3RlZCBmaW5pc2hTYXZpbmcoKSB7XG4gICAgICAgIHRoaXMuY3JlYXRlQXBwbHlDaGFuZ2VzRXZlbnQoKTtcbiAgICAgICAgdGhpcy5zZXR0aW5nc0NoYW5nZWQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5hbGVydFNlcnZpY2UuY2xvc2VBbGwoKTtcbiAgICAgICAgdGhpcy5hbGVydFNlcnZpY2Uuc3VjY2VzcygnYXJ0ZW1pc0FwcC51c2VyU2V0dGluZ3Muc2F2ZVNldHRpbmdzU3VjY2Vzc0FsZXJ0Jyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSW52b2tlcyB0aGUgc2VuZEFwcGx5Q2hhbmdlc0V2ZW50IG1ldGhvZCBpbiB1c2VyU2V0dGluZ3NTZXJ2aWNlIGFuZCBpbnNlcnRzIHRoZSBjdXN0b20gY2hhbmdlRXZlbnRNZXNzYWdlXG4gICAgICogVGhpcyBtZXNzYWdlIGlzIHNldCBpbiB0aGUgbmdPbkluaXQoKSBvZiBhIFwiY2hpbGRcIi1zZXR0aW5ncy5jb21wb25lbnRcbiAgICAgKi9cbiAgICBwcm90ZWN0ZWQgY3JlYXRlQXBwbHlDaGFuZ2VzRXZlbnQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMudXNlclNldHRpbmdzU2VydmljZS5zZW5kQXBwbHlDaGFuZ2VzRXZlbnQodGhpcy5jaGFuZ2VFdmVudE1lc3NhZ2UpO1xuICAgIH1cblxuICAgIC8vIGF1eGlsaWFyeSBtZXRob2RzXG5cbiAgICAvKipcbiAgICAgKiBTZW5kIG91dCBhbiBlcnJvciBhbGVydCBpZiBhbiBlcnJvciBvY2N1cnJlZFxuICAgICAqIEBwYXJhbSBodHRwRXJyb3JSZXNwb25zZSB3aGljaCBjb250YWlucyB0aGUgZXJyb3IgaW5mb3JtYXRpb25cbiAgICAgKi9cbiAgICBwcm90ZWN0ZWQgb25FcnJvcihodHRwRXJyb3JSZXNwb25zZTogSHR0cEVycm9yUmVzcG9uc2UpIHtcbiAgICAgICAgY29uc3QgZXJyb3IgPSBodHRwRXJyb3JSZXNwb25zZS5lcnJvcjtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5lcnJvcihlcnJvci5tZXNzYWdlLCBlcnJvci5wYXJhbXMpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5hbGVydFNlcnZpY2UuZXJyb3IoJ2Vycm9yLnVuZXhwZWN0ZWRFcnJvcicsIHtcbiAgICAgICAgICAgICAgICBlcnJvcjogaHR0cEVycm9yUmVzcG9uc2UubWVzc2FnZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0b3JSZWYsIENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBVc2VyU2V0dGluZ3NEaXJlY3RpdmUgfSBmcm9tICdhcHAvc2hhcmVkL3VzZXItc2V0dGluZ3MvdXNlci1zZXR0aW5ncy5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgVXNlclNldHRpbmdzQ2F0ZWdvcnkgfSBmcm9tICdhcHAvc2hhcmVkL2NvbnN0YW50cy91c2VyLXNldHRpbmdzLmNvbnN0YW50cyc7XG5pbXBvcnQgeyBOb3RpZmljYXRpb25TZXR0aW5nIH0gZnJvbSAnYXBwL3NoYXJlZC91c2VyLXNldHRpbmdzL25vdGlmaWNhdGlvbi1zZXR0aW5ncy9ub3RpZmljYXRpb24tc2V0dGluZ3Mtc3RydWN0dXJlJztcbmltcG9ydCB7IFVzZXJTZXR0aW5nc1NlcnZpY2UgfSBmcm9tICdhcHAvc2hhcmVkL3VzZXItc2V0dGluZ3MvdXNlci1zZXR0aW5ncy5zZXJ2aWNlJztcbmltcG9ydCB7IFVzZXJTZXR0aW5nc1N0cnVjdHVyZSB9IGZyb20gJ2FwcC9zaGFyZWQvdXNlci1zZXR0aW5ncy91c2VyLXNldHRpbmdzLm1vZGVsJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5pbXBvcnQgeyBmYUluZm9DaXJjbGUsIGZhU2F2ZSB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBOb3RpZmljYXRpb25TZXR0aW5nc1NlcnZpY2UsIHJlbG9hZE5vdGlmaWNhdGlvblNpZGVCYXJNZXNzYWdlIH0gZnJvbSAnYXBwL3NoYXJlZC91c2VyLXNldHRpbmdzL25vdGlmaWNhdGlvbi1zZXR0aW5ncy9ub3RpZmljYXRpb24tc2V0dGluZ3Muc2VydmljZSc7XG5cbmV4cG9ydCBlbnVtIE5vdGlmaWNhdGlvblNldHRpbmdzQ29tbXVuaWNhdGlvbkNoYW5uZWwge1xuICAgIFdFQkFQUCxcbiAgICBFTUFJTCxcbn1cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbm90aWZpY2F0aW9uLXNldHRpbmdzJyxcbiAgICB0ZW1wbGF0ZVVybDogJ25vdGlmaWNhdGlvbi1zZXR0aW5ncy5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4uL3VzZXItc2V0dGluZ3Muc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBOb3RpZmljYXRpb25TZXR0aW5nc0NvbXBvbmVudCBleHRlbmRzIFVzZXJTZXR0aW5nc0RpcmVjdGl2ZSBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgLy8gSWNvbnNcbiAgICBmYVNhdmUgPSBmYVNhdmU7XG4gICAgZmFJbmZvQ2lyY2xlID0gZmFJbmZvQ2lyY2xlO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHVzZXJTZXR0aW5nc1NlcnZpY2U6IFVzZXJTZXR0aW5nc1NlcnZpY2UsXG4gICAgICAgIGNoYW5nZURldGVjdG9yOiBDaGFuZ2VEZXRlY3RvclJlZixcbiAgICAgICAgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgbm90aWZpY2F0aW9uU2V0dGluZ3NTZXJ2aWNlOiBOb3RpZmljYXRpb25TZXR0aW5nc1NlcnZpY2UsXG4gICAgKSB7XG4gICAgICAgIHN1cGVyKHVzZXJTZXR0aW5nc1NlcnZpY2UsIGFsZXJ0U2VydmljZSwgY2hhbmdlRGV0ZWN0b3IpO1xuICAgIH1cblxuICAgIGRlY2xhcmUgdXNlclNldHRpbmdzOiBVc2VyU2V0dGluZ3NTdHJ1Y3R1cmU8Tm90aWZpY2F0aW9uU2V0dGluZz47XG4gICAgZGVjbGFyZSBzZXR0aW5nczogQXJyYXk8Tm90aWZpY2F0aW9uU2V0dGluZz47XG5cbiAgICAvLyBuZWVkZWQgZm9yIEhUTUwgYWNjZXNzXG4gICAgcmVhZG9ubHkgY29tbXVuaWNhdGlvbkNoYW5uZWwgPSBOb3RpZmljYXRpb25TZXR0aW5nc0NvbW11bmljYXRpb25DaGFubmVsO1xuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMudXNlclNldHRpbmdzQ2F0ZWdvcnkgPSBVc2VyU2V0dGluZ3NDYXRlZ29yeS5OT1RJRklDQVRJT05fU0VUVElOR1M7XG4gICAgICAgIHRoaXMuY2hhbmdlRXZlbnRNZXNzYWdlID0gcmVsb2FkTm90aWZpY2F0aW9uU2lkZUJhck1lc3NhZ2U7XG5cbiAgICAgICAgLy8gY2hlY2sgaWYgc2V0dGluZ3MgYXJlIGFscmVhZHkgbG9hZGVkXG4gICAgICAgIGNvbnN0IG5ld2VzdE5vdGlmaWNhdGlvblNldHRpbmdzOiBOb3RpZmljYXRpb25TZXR0aW5nW10gPSB0aGlzLm5vdGlmaWNhdGlvblNldHRpbmdzU2VydmljZS5nZXROb3RpZmljYXRpb25TZXR0aW5ncygpO1xuICAgICAgICBpZiAobmV3ZXN0Tm90aWZpY2F0aW9uU2V0dGluZ3MubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAvLyBpZiBubyBzZXR0aW5ncyBhcmUgYWxyZWFkeSBhdmFpbGFibGUgbG9hZCB0aGVtIGZyb20gdGhlIHNlcnZlclxuICAgICAgICAgICAgc3VwZXIubmdPbkluaXQoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIGVsc2UgcmV1c2UgdGhlIGFscmVhZHkgYXZhaWxhYmxlL2xvYWRlZCBvbmVzXG4gICAgICAgICAgICB0aGlzLnVzZXJTZXR0aW5ncyA9IHRoaXMudXNlclNldHRpbmdzU2VydmljZS5sb2FkU2V0dGluZ3NTdWNjZXNzQXNTZXR0aW5nc1N0cnVjdHVyZShuZXdlc3ROb3RpZmljYXRpb25TZXR0aW5ncywgdGhpcy51c2VyU2V0dGluZ3NDYXRlZ29yeSk7XG4gICAgICAgICAgICB0aGlzLnNldHRpbmdzID0gdGhpcy51c2VyU2V0dGluZ3NTZXJ2aWNlLmV4dHJhY3RJbmRpdmlkdWFsU2V0dGluZ3NGcm9tU2V0dGluZ3NTdHJ1Y3R1cmUodGhpcy51c2VyU2V0dGluZ3MpO1xuICAgICAgICAgICAgdGhpcy5jaGFuZ2VEZXRlY3Rvci5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDYXRjaGVzIHRoZSB0b2dnbGUgZXZlbnQgZnJvbSBhIHVzZXIgY2xpY2tcbiAgICAgKiBUb2dnbGVzIHRoZSByZXNwZWN0aXZlIHNldHRpbmcgYW5kIG1hcmsgaXQgYXMgY2hhbmdlZCAob25seSBjaGFuZ2VkIHNldHRpbmdzIHdpbGwgYmUgc2VuZCB0byB0aGUgc2VydmVyIGZvciBzYXZpbmcpXG4gICAgICovXG4gICAgdG9nZ2xlU2V0dGluZyhldmVudDogYW55LCBjb21tdW5pY2F0aW9uQ2hhbm5lbDogTm90aWZpY2F0aW9uU2V0dGluZ3NDb21tdW5pY2F0aW9uQ2hhbm5lbCkge1xuICAgICAgICB0aGlzLnNldHRpbmdzQ2hhbmdlZCA9IHRydWU7XG4gICAgICAgIGxldCBzZXR0aW5nSWQgPSBldmVudC5jdXJyZW50VGFyZ2V0LmlkO1xuICAgICAgICAvLyBvcHRpb25JZCBTdHJpbmcgY291bGQgaGF2ZSBhbiBhcHBlbmRlZCAoZS5nLiggXCIgZW1haWxcIiBvciBcIiB3ZWJhcHBcIiB0byBzcGVjaWZ5IHdoaWNoIG9wdGlvbiB0byB0b2dnbGVcbiAgICAgICAgaWYgKHNldHRpbmdJZC5pbmRleE9mKCcgJykgIT09IC0xKSB7XG4gICAgICAgICAgICBzZXR0aW5nSWQgPSBzZXR0aW5nSWQuc2xpY2UoMCwgc2V0dGluZ0lkLmluZGV4T2YoJyAnKSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc2V0dGluZ1RvVXBkYXRlID0gdGhpcy5zZXR0aW5ncy5maW5kKChzZXR0aW5nKSA9PiBzZXR0aW5nLnNldHRpbmdJZCA9PT0gc2V0dGluZ0lkKTtcbiAgICAgICAgaWYgKCFzZXR0aW5nVG9VcGRhdGUpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyB0b2dnbGUvaW52ZXJ0cyBwcmV2aW91cyBzZXR0aW5nXG4gICAgICAgIHN3aXRjaCAoY29tbXVuaWNhdGlvbkNoYW5uZWwpIHtcbiAgICAgICAgICAgIGNhc2UgTm90aWZpY2F0aW9uU2V0dGluZ3NDb21tdW5pY2F0aW9uQ2hhbm5lbC5XRUJBUFA6IHtcbiAgICAgICAgICAgICAgICBzZXR0aW5nVG9VcGRhdGUhLndlYmFwcCA9ICFzZXR0aW5nVG9VcGRhdGUhLndlYmFwcDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgTm90aWZpY2F0aW9uU2V0dGluZ3NDb21tdW5pY2F0aW9uQ2hhbm5lbC5FTUFJTDoge1xuICAgICAgICAgICAgICAgIHNldHRpbmdUb1VwZGF0ZSEuZW1haWwgPSAhc2V0dGluZ1RvVXBkYXRlIS5lbWFpbDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBzZXR0aW5nVG9VcGRhdGUuY2hhbmdlZCA9IHRydWU7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblwiPlxuICAgIDxkaXY+XG4gICAgICAgIDxoMT5cbiAgICAgICAgICAgIDwhLS1Vc2VyU2V0dGluZ3NDYXRlZ29yeS0tPlxuICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAudXNlclNldHRpbmdzLmNhdGVnb3JpZXMuJyArIHVzZXJTZXR0aW5nc0NhdGVnb3J5IHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICA8L2gxPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZC1pbmxpbmUtZmxleCB1c2VyU2V0dGluZ3MtaW5mb1wiPlxuICAgICAgICAgICAgPGZhLWljb24gY2xhc3M9XCJuZy1mYS1pY29uXCIgW2ljb25dPVwiZmFJbmZvQ2lyY2xlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJwcy0xXCI+XG4gICAgICAgICAgICAgICAgPCEtLSBJbmZvIHRleHQgZXhwbGFpbmluZyB0aGF0IHRoZXNlIHNldHRpbmdzIGFsc28gZmlsdGVyIHRoZSBub3RpZmljYXRpb24gc2lkZWJhciAtLT5cbiAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC51c2VyU2V0dGluZ3Mubm90aWZpY2F0aW9uU2V0dGluZ3NGaWx0ZXJJbmZvJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgQGlmIChzZXR0aW5nc0NoYW5nZWQpIHtcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIiBpZD1cImFwcGx5LWNoYW5nZXMtYnV0dG9uXCIgKGNsaWNrKT1cInRoaXMuc2F2ZVNldHRpbmdzKClcIj5cbiAgICAgICAgICAgIDxmYS1pY29uIGNsYXNzPVwibmdcIiBbaWNvbl09XCJmYVNhdmVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC51c2VyU2V0dGluZ3Muc2F2ZUNoYW5nZXMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICA8L2J1dHRvbj5cbiAgICB9XG48L2Rpdj5cbkBpZiAodXNlclNldHRpbmdzKSB7XG4gICAgPGRpdiBjbGFzcz1cImxpc3QtZ3JvdXAgZC1ibG9ja1wiPlxuICAgICAgICBAZm9yIChzZXR0aW5nR3JvdXAgb2YgdXNlclNldHRpbmdzLmdyb3VwczsgdHJhY2sgc2V0dGluZ0dyb3VwKSB7XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgKmpoaUhhc0FueUF1dGhvcml0eT1cInNldHRpbmdHcm91cC5yZXN0cmljdGlvbkxldmVsc1wiIGNsYXNzPVwibGlzdC1ncm91cC1pdGVtXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwhLS1Hcm91cE5hbWUtLT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gcGxlYXNlIGxvb2sgYXQgdGhlIFJFQURNRS5tZCBmaWxlIHRvIHVuZGVyc3RhbmQgaG93IHRoZSB0cmFuc2xhdGlvbiB3b3JrcyAtLT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLnVzZXJTZXR0aW5ncy5zZXR0aW5nR3JvdXBOYW1lcy4nICsgc2V0dGluZ0dyb3VwLmtleSB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgQGZvciAoc2V0dGluZyBvZiBzZXR0aW5nR3JvdXAuc2V0dGluZ3M7IHRyYWNrIHNldHRpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGR0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8IS0tU2V0dGluZ05hbWUtLT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAudXNlclNldHRpbmdzLnNldHRpbmdOYW1lcy4nICsgc2V0dGluZy5rZXkgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPCEtLVNldHRpbmdEZXNjcmlwdGlvbi0tPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC51c2VyU2V0dGluZ3Muc2V0dGluZ0Rlc2NyaXB0aW9ucy4nICsgc2V0dGluZy5kZXNjcmlwdGlvbktleSB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPCEtLVNldHRpbmcgU3BlY2lmaWMgUHJvcGVydGllcy0tPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXhcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChzZXR0aW5nLndlYmFwcCAhPSB1bmRlZmluZWQgJiYgKHNldHRpbmcud2ViYXBwU3VwcG9ydCA9PSB1bmRlZmluZWQgfHwgc2V0dGluZy53ZWJhcHBTdXBwb3J0KSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tY2hlY2sgcGUtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY2hlY2staW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2hlY2tlZF09XCJzZXR0aW5nLndlYmFwcFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwie3sgc2V0dGluZy5zZXR0aW5nSWQgfX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT1cInt7IHNldHRpbmcud2ViYXBwIH19XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cInRvZ2dsZVNldHRpbmcoJGV2ZW50LCBjb21tdW5pY2F0aW9uQ2hhbm5lbC5XRUJBUFApXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImZvcm0tY2hlY2stbGFiZWxcIiBmb3I9XCJ7eyBzZXR0aW5nLnNldHRpbmdJZCB9fVwiPldlYkFwcDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHNldHRpbmcuZW1haWwgIT0gdW5kZWZpbmVkICYmIHNldHRpbmcuZW1haWxTdXBwb3J0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1jaGVja1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY2hlY2staW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2hlY2tlZF09XCJzZXR0aW5nLmVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ7eyBzZXR0aW5nLnNldHRpbmdJZCB9fSBlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPVwie3sgc2V0dGluZy5lbWFpbCB9fVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJ0b2dnbGVTZXR0aW5nKCRldmVudCwgY29tbXVuaWNhdGlvbkNoYW5uZWwuRU1BSUwpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImZvcm0tY2hlY2stbGFiZWxcIiBmb3I9XCJ7eyBzZXR0aW5nLnNldHRpbmdJZCB9fSBlbWFpbFwiPkVtYWlsPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICA8L2Rpdj5cbn1cbiIsImltcG9ydCB7IFJvdXRlcyB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBVc2VyU2V0dGluZ3NDb250YWluZXJDb21wb25lbnQgfSBmcm9tICdhcHAvc2hhcmVkL3VzZXItc2V0dGluZ3MvdXNlci1zZXR0aW5ncy1jb250YWluZXIvdXNlci1zZXR0aW5ncy1jb250YWluZXIuY29tcG9uZW50JztcbmltcG9ydCB7IEFjY291bnRJbmZvcm1hdGlvbkNvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvdXNlci1zZXR0aW5ncy9hY2NvdW50LWluZm9ybWF0aW9uL2FjY291bnQtaW5mb3JtYXRpb24uY29tcG9uZW50JztcbmltcG9ydCB7IE5vdGlmaWNhdGlvblNldHRpbmdzQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC91c2VyLXNldHRpbmdzL25vdGlmaWNhdGlvbi1zZXR0aW5ncy9ub3RpZmljYXRpb24tc2V0dGluZ3MuY29tcG9uZW50JztcbmltcG9ydCB7IFVzZXJSb3V0ZUFjY2Vzc1NlcnZpY2UgfSBmcm9tICdhcHAvY29yZS9hdXRoL3VzZXItcm91dGUtYWNjZXNzLXNlcnZpY2UnO1xuaW1wb3J0IHsgQXV0aG9yaXR5IH0gZnJvbSAnYXBwL3NoYXJlZC9jb25zdGFudHMvYXV0aG9yaXR5LmNvbnN0YW50cyc7XG5cbmV4cG9ydCBjb25zdCB1c2VyU2V0dGluZ3NTdGF0ZTogUm91dGVzID0gW1xuICAgIHtcbiAgICAgICAgcGF0aDogJ3VzZXItc2V0dGluZ3MnLFxuICAgICAgICBjb21wb25lbnQ6IFVzZXJTZXR0aW5nc0NvbnRhaW5lckNvbXBvbmVudCxcbiAgICAgICAgY2FuQWN0aXZhdGU6IFtVc2VyUm91dGVBY2Nlc3NTZXJ2aWNlXSxcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgYXV0aG9yaXRpZXM6IFtBdXRob3JpdHkuVVNFUl0sXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgLy8gcmVkaXJlY3RzIHRvIGFjY291bnQgaW5mb3JtYXRpb24gd2hlbiB1c2VyLXNldHRpbmdzIGFyZSBvcGVuZWRcbiAgICAgICAgICAgICAgICBwYXRoOiAnJyxcbiAgICAgICAgICAgICAgICBwYXRoTWF0Y2g6ICdmdWxsJyxcbiAgICAgICAgICAgICAgICByZWRpcmVjdFRvOiAnYWNjb3VudCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHBhdGg6ICdhY2NvdW50JyxcbiAgICAgICAgICAgICAgICBjb21wb25lbnQ6IEFjY291bnRJbmZvcm1hdGlvbkNvbXBvbmVudCxcbiAgICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgICAgIHBhZ2VUaXRsZTogJ2FydGVtaXNBcHAudXNlclNldHRpbmdzLmFjY291bnRJbmZvcm1hdGlvbicsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcGF0aDogJ25vdGlmaWNhdGlvbnMnLFxuICAgICAgICAgICAgICAgIGNvbXBvbmVudDogTm90aWZpY2F0aW9uU2V0dGluZ3NDb21wb25lbnQsXG4gICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgICBwYWdlVGl0bGU6ICdhcnRlbWlzQXBwLnVzZXJTZXR0aW5ncy5jYXRlZ29yaWVzLk5PVElGSUNBVElPTl9TRVRUSU5HUycsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbl07XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgVXNlclNldHRpbmdzQ29udGFpbmVyQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC91c2VyLXNldHRpbmdzL3VzZXItc2V0dGluZ3MtY29udGFpbmVyL3VzZXItc2V0dGluZ3MtY29udGFpbmVyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBY2NvdW50SW5mb3JtYXRpb25Db21wb25lbnQgfSBmcm9tICdhcHAvc2hhcmVkL3VzZXItc2V0dGluZ3MvYWNjb3VudC1pbmZvcm1hdGlvbi9hY2NvdW50LWluZm9ybWF0aW9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBOb3RpZmljYXRpb25TZXR0aW5nc0NvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvdXNlci1zZXR0aW5ncy9ub3RpZmljYXRpb24tc2V0dGluZ3Mvbm90aWZpY2F0aW9uLXNldHRpbmdzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IFJvdXRlck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyB1c2VyU2V0dGluZ3NTdGF0ZSB9IGZyb20gJ2FwcC9zaGFyZWQvdXNlci1zZXR0aW5ncy91c2VyLXNldHRpbmdzLnJvdXRlJztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbUm91dGVyTW9kdWxlLmZvckNoaWxkKHVzZXJTZXR0aW5nc1N0YXRlKSwgQXJ0ZW1pc1NoYXJlZE1vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbVXNlclNldHRpbmdzQ29udGFpbmVyQ29tcG9uZW50LCBBY2NvdW50SW5mb3JtYXRpb25Db21wb25lbnQsIE5vdGlmaWNhdGlvblNldHRpbmdzQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgVXNlclNldHRpbmdzTW9kdWxlIHt9XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgVHJhbnNsYXRlTW9kdWxlIH0gZnJvbSAnQG5neC10cmFuc2xhdGUvY29yZSc7XG5pbXBvcnQgeyBUaGVtZVN3aXRjaENvbXBvbmVudCB9IGZyb20gJ2FwcC9jb3JlL3RoZW1lL3RoZW1lLXN3aXRjaC5jb21wb25lbnQnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGRlY2xhcmF0aW9uczogW1RoZW1lU3dpdGNoQ29tcG9uZW50XSxcbiAgICBpbXBvcnRzOiBbVHJhbnNsYXRlTW9kdWxlLCBDb21tb25Nb2R1bGUsIEFydGVtaXNTaGFyZWRNb2R1bGVdLFxuICAgIGV4cG9ydHM6IFtUaGVtZVN3aXRjaENvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIFRoZW1lTW9kdWxlIHt9XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQnJvd3Nlck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xuaW1wb3J0IHsgU2VydmljZVdvcmtlck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL3NlcnZpY2Utd29ya2VyJztcbmltcG9ydCB7IEJyb3dzZXJBbmltYXRpb25zTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlci9hbmltYXRpb25zJztcbmltcG9ydCB7IEFydGVtaXNTeXN0ZW1Ob3RpZmljYXRpb25Nb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL25vdGlmaWNhdGlvbi9zeXN0ZW0tbm90aWZpY2F0aW9uL3N5c3RlbS1ub3RpZmljYXRpb24ubW9kdWxlJztcbmltcG9ydCB7IE5hdmJhckNvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvbGF5b3V0cy9uYXZiYXIvbmF2YmFyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBOb3RpZmljYXRpb25TaWRlYmFyQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vbm90aWZpY2F0aW9uLXNpZGViYXIvbm90aWZpY2F0aW9uLXNpZGViYXIuY29tcG9uZW50JztcbmltcG9ydCB7IFBhZ2VSaWJib25Db21wb25lbnQgfSBmcm9tICdhcHAvc2hhcmVkL2xheW91dHMvcHJvZmlsZXMvcGFnZS1yaWJib24uY29tcG9uZW50JztcbmltcG9ydCB7IEFydGVtaXNIZWFkZXJFeGVyY2lzZVBhZ2VXaXRoRGV0YWlsc01vZHVsZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlLWhlYWRlcnMvZXhlcmNpc2UtaGVhZGVycy5tb2R1bGUnO1xuaW1wb3J0IHsgU3lzdGVtTm90aWZpY2F0aW9uQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vc3lzdGVtLW5vdGlmaWNhdGlvbi9zeXN0ZW0tbm90aWZpY2F0aW9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBcnRlbWlzQXBwUm91dGluZ01vZHVsZSB9IGZyb20gJ2FwcC9hcHAtcm91dGluZy5tb2R1bGUnO1xuaW1wb3J0IHsgSmhpTWFpbkNvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvbGF5b3V0cy9tYWluL21haW4uY29tcG9uZW50JztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc0NvdXJzZXNNb2R1bGUgfSBmcm9tICdhcHAvb3ZlcnZpZXcvY291cnNlcy5tb2R1bGUnO1xuaW1wb3J0IHsgRm9vdGVyQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC9sYXlvdXRzL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50JztcbmltcG9ydCB7IEFjdGl2ZU1lbnVEaXJlY3RpdmUgfSBmcm9tICdhcHAvc2hhcmVkL2xheW91dHMvbmF2YmFyL2FjdGl2ZS1tZW51LmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBFcnJvckNvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvbGF5b3V0cy9lcnJvci9lcnJvci5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc0NvcmVNb2R1bGUgfSBmcm9tICdhcHAvY29yZS9jb3JlLm1vZHVsZSc7XG5pbXBvcnQgeyBHdWlkZWRUb3VyTW9kdWxlIH0gZnJvbSAnYXBwL2d1aWRlZC10b3VyL2d1aWRlZC10b3VyLm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzQ29tcGxhaW50c01vZHVsZSB9IGZyb20gJ2FwcC9jb21wbGFpbnRzL2NvbXBsYWludHMubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNIb21lTW9kdWxlIH0gZnJvbSAnYXBwL2hvbWUvaG9tZS5tb2R1bGUnO1xuaW1wb3J0IHsgT3Jpb25PdXRkYXRlZENvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvb3Jpb24vb3V0ZGF0ZWQtcGx1Z2luLXdhcm5pbmcvb3Jpb24tb3V0ZGF0ZWQuY29tcG9uZW50JztcbmltcG9ydCB7IExvYWRpbmdOb3RpZmljYXRpb25Db21wb25lbnQgfSBmcm9tICdhcHAvc2hhcmVkL25vdGlmaWNhdGlvbi9sb2FkaW5nLW5vdGlmaWNhdGlvbi9sb2FkaW5nLW5vdGlmaWNhdGlvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgTm90aWZpY2F0aW9uUG9wdXBDb21wb25lbnQgfSBmcm9tICdhcHAvc2hhcmVkL25vdGlmaWNhdGlvbi9ub3RpZmljYXRpb24tcG9wdXAvbm90aWZpY2F0aW9uLXBvcHVwLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBVc2VyU2V0dGluZ3NNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3VzZXItc2V0dGluZ3MvdXNlci1zZXR0aW5ncy5tb2R1bGUnO1xuaW1wb3J0IHsgVGhlbWVNb2R1bGUgfSBmcm9tICdhcHAvY29yZS90aGVtZS90aGVtZS5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9zaGFyZWQtY29tcG9uZW50Lm1vZHVsZSc7XG5cbi8vIE5PVEU6IHRoaXMgbW9kdWxlIHNob3VsZCBvbmx5IGluY2x1ZGUgdGhlIG1vc3QgaW1wb3J0YW50IG1vZHVsZXMgZm9yIG5vcm1hbCB1c2VycywgYWxsIGNvdXJzZSBtYW5hZ2VtZW50LCBhZG1pbiBhbmQgYWNjb3VudCBmdW5jdGlvbmFsaXR5IHNob3VsZCBiZSBsYXp5IGxvYWRlZCBpZiBwb3NzaWJsZVxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbXG4gICAgICAgIEJyb3dzZXJNb2R1bGUsXG4gICAgICAgIEJyb3dzZXJBbmltYXRpb25zTW9kdWxlLFxuICAgICAgICAvLyBUaGlzIGVuYWJsZXMgc2VydmljZSB3b3JrZXIgKFBXQSlcbiAgICAgICAgU2VydmljZVdvcmtlck1vZHVsZS5yZWdpc3Rlcignbmdzdy13b3JrZXIuanMnLCB7IGVuYWJsZWQ6IHRydWUgfSksXG4gICAgICAgIEFydGVtaXNTaGFyZWRNb2R1bGUsXG4gICAgICAgIEFydGVtaXNDb3JlTW9kdWxlLFxuICAgICAgICBBcnRlbWlzSG9tZU1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc0FwcFJvdXRpbmdNb2R1bGUsXG4gICAgICAgIEd1aWRlZFRvdXJNb2R1bGUsXG4gICAgICAgIEFydGVtaXNDb3Vyc2VzTW9kdWxlLFxuICAgICAgICBBcnRlbWlzU3lzdGVtTm90aWZpY2F0aW9uTW9kdWxlLFxuICAgICAgICBBcnRlbWlzQ29tcGxhaW50c01vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc0hlYWRlckV4ZXJjaXNlUGFnZVdpdGhEZXRhaWxzTW9kdWxlLFxuICAgICAgICBVc2VyU2V0dGluZ3NNb2R1bGUsXG4gICAgICAgIFRoZW1lTW9kdWxlLFxuICAgICAgICBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlLFxuICAgIF0sXG4gICAgZGVjbGFyYXRpb25zOiBbXG4gICAgICAgIEpoaU1haW5Db21wb25lbnQsXG4gICAgICAgIE5hdmJhckNvbXBvbmVudCxcbiAgICAgICAgRXJyb3JDb21wb25lbnQsXG4gICAgICAgIE9yaW9uT3V0ZGF0ZWRDb21wb25lbnQsXG4gICAgICAgIFBhZ2VSaWJib25Db21wb25lbnQsXG4gICAgICAgIEFjdGl2ZU1lbnVEaXJlY3RpdmUsXG4gICAgICAgIEZvb3RlckNvbXBvbmVudCxcbiAgICAgICAgTm90aWZpY2F0aW9uUG9wdXBDb21wb25lbnQsXG4gICAgICAgIE5vdGlmaWNhdGlvblNpZGViYXJDb21wb25lbnQsXG4gICAgICAgIFN5c3RlbU5vdGlmaWNhdGlvbkNvbXBvbmVudCxcbiAgICAgICAgTG9hZGluZ05vdGlmaWNhdGlvbkNvbXBvbmVudCxcbiAgICBdLFxuICAgIGJvb3RzdHJhcDogW0poaU1haW5Db21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBBcnRlbWlzQXBwTW9kdWxlIHt9XG4iLCJpbXBvcnQgJy4vcG9seWZpbGxzJztcbmltcG9ydCAnYXBwL3NoYXJlZC91dGlsL2FycmF5LmV4dGVuc2lvbic7XG5pbXBvcnQgJ2FwcC9zaGFyZWQvdXRpbC9tYXAuZXh0ZW5zaW9uJztcbmltcG9ydCAnYXBwL3NoYXJlZC91dGlsL3N0cmluZy5leHRlbnNpb24nO1xuaW1wb3J0IHsgcGxhdGZvcm1Ccm93c2VyRHluYW1pYyB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXItZHluYW1pYyc7XG5pbXBvcnQgeyBQcm9kQ29uZmlnIH0gZnJvbSAnLi9jb3JlL2NvbmZpZy9wcm9kLmNvbmZpZyc7XG5pbXBvcnQgeyBBcnRlbWlzQXBwTW9kdWxlIH0gZnJvbSAnLi9hcHAubW9kdWxlJztcblxuUHJvZENvbmZpZygpO1xuXG5pZiAobW9kdWxlWydob3QnXSkge1xuICAgIG1vZHVsZVsnaG90J10uYWNjZXB0KCk7XG4gICAgaWYgKCdwcm9kdWN0aW9uJyAhPT0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYpIHtcbiAgICAgICAgY29uc29sZS5jbGVhcigpO1xuICAgIH1cbn1cblxucGxhdGZvcm1Ccm93c2VyRHluYW1pYygpXG4gICAgLmJvb3RzdHJhcE1vZHVsZShBcnRlbWlzQXBwTW9kdWxlLCB7IHByZXNlcnZlV2hpdGVzcGFjZXM6IHRydWUgfSlcbiAgICAudGhlbigoKSA9PiB7fSlcbiAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5lcnJvcihlcnIpKTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBTztBQUNQLE9BQU87QUFDUCxZQUFZQSxjQUFhO0FBRnpCOztBQUtDLFdBQWUsU0FBUztBQUV6QixXQUFPLFNBQVMsSUFBSUE7Ozs7O0FDT3BCOztRQUFJLENBQUMsTUFBTSxVQUFVLE1BQU07QUFDdkIsWUFBTSxVQUFVLE9BQU8sU0FBUyxPQUFJO0FBQ2hDLFlBQUksQ0FBQyxLQUFLLFFBQVE7QUFDZCxpQkFBTzs7QUFFWCxlQUFPLEtBQUssS0FBSyxTQUFTLENBQUM7TUFDL0I7O0FBR0osUUFBSSxDQUFDLE1BQU0sVUFBVSxPQUFPO0FBQ3hCLFlBQU0sVUFBVSxRQUFRLFNBQVMsUUFBSztBQUNsQyxZQUFJLENBQUMsS0FBSyxRQUFRO0FBQ2QsaUJBQU87O0FBRVgsZUFBTyxLQUFLLENBQUM7TUFDakI7O0FBR0osUUFBSSxDQUFDLE1BQU0sVUFBVSxTQUFTO0FBRTFCLFlBQU0sVUFBVSxVQUFVLFNBQVMsVUFBTztBQUN0QyxZQUFJLEtBQUssU0FBUyxHQUFHO0FBQ2pCLG1CQUFTLElBQUksS0FBSyxTQUFTLEdBQUcsSUFBSSxHQUFHLEtBQUs7QUFDdEMsa0JBQU0sY0FBYyxLQUFLLE1BQU0sS0FBSyxPQUFNLEtBQU0sSUFBSSxFQUFFO0FBQ3RELGtCQUFNLGdCQUFnQixLQUFLLFdBQVc7QUFDdEMsaUJBQUssV0FBVyxJQUFJLEtBQUssQ0FBQztBQUMxQixpQkFBSyxDQUFDLElBQUk7OztNQUd0Qjs7Ozs7O0FDbkNKOztRQUFJLENBQUMsSUFBSSxVQUFVLGlCQUFpQjtBQUNoQyxVQUFJLFVBQVUsa0JBQWtCLFNBQVUsS0FBSyxpQkFBZTtBQUMxRCxjQUFNLFFBQVEsS0FBSyxJQUFJLEdBQUc7QUFDMUIsWUFBSSxVQUFVLFFBQVc7QUFDckIsaUJBQU87O0FBRVgsY0FBTSxhQUFhLGdCQUFnQixHQUFHO0FBQ3RDLGFBQUssSUFBSSxLQUFLLFVBQVU7QUFDeEIsZUFBTztNQUNYOzs7Ozs7QUNUSjs7UUFBSSxDQUFDLE9BQU8sVUFBVSxZQUFZO0FBQzlCLGFBQU8sVUFBVSxhQUFhLFNBQVUsUUFBUSxhQUFXO0FBQ3ZELGVBQU8sS0FBSyxRQUFRLElBQUksT0FBTyxRQUFRLEdBQUcsR0FBRyxXQUFXO01BQzVEOzs7Ozs7QUNYSixTQUFTLHNCQUFzQjtBQU16QixTQUFVLGFBQVU7QUFDdEIsTUFBSSxDQUFDLG9CQUFvQjtBQUNyQixtQkFBYzs7QUFFdEI7QUFWQTs7QUFDQTs7Ozs7QUNEQSxTQUFTLGdCQUFnQjs7QUFBekIsSUFTYTtBQVRiOztBQUNBO0FBQ0E7QUFDQTtBQU1NLElBQU8sa0NBQVAsTUFBTyxpQ0FBK0I7O3lCQUEvQixrQ0FBK0I7TUFBQTsrREFBL0IsaUNBQStCLENBQUE7b0VBRjdCLENBQUMsMkJBQTJCLDhCQUE4QixHQUFDLFNBQUEsQ0FENUQsbUJBQW1CLEVBQUEsQ0FBQTs7Ozs7O0FDTmpDLFNBQXdCLFdBQVcsWUFBWSxjQUF5QixXQUFXLFdBQVcsV0FBVyxjQUFjLHlCQUF5QjtBQUNoSixTQUF1QixpQkFBaUI7QUFDeEMsU0FBUyxNQUFNLFdBQVc7QUFPMUIsU0FDSSxhQUNBLFNBQ0EsZUFDQSxnQkFDQSxlQUNBLGlCQUNBLFFBQ0EsZUFDQSxXQUNBLGNBQ0EsY0FDQSxlQUNHOzs7Ozs7O0FDbkJLLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUFpQyxJQUFBLHlCQUFBLFNBQUEsU0FBQSw4RUFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLE9BQUEsY0FBQSxNQUFBLENBQXFCO0lBQUEsQ0FBQTtBQUFFLElBQUEsMkJBQUE7QUFDckUsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxZQUFBOzs7Ozs7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQTBGLElBQUEseUJBQUEsU0FBQSxTQUFBLDhFQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsT0FBQSxjQUFBLE1BQUEsQ0FBcUI7SUFBQSxDQUFBO0FBQUUsSUFBQSwyQkFBQTtBQUMxSCxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQTJGLElBQUEseUJBQUEsU0FBQSxTQUFBLDhFQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsT0FBQSxjQUFBLE1BQUEsQ0FBcUI7SUFBQSxDQUFBO0FBQUUsSUFBQSwyQkFBQTtBQUMzSCxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQTRGLElBQUEseUJBQUEsU0FBQSxTQUFBLDhFQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsT0FBQSxjQUFBLE1BQUEsQ0FBcUI7SUFBQSxDQUFBO0FBQUUsSUFBQSwyQkFBQTtBQUM1SCxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQTZGLElBQUEseUJBQUEsU0FBQSxTQUFBLDhFQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxjQUFBLE1BQUEsQ0FBcUI7SUFBQSxDQUFBO0FBQUUsSUFBQSwyQkFBQTtBQUM3SCxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBSUksSUFBQSx5QkFBQSxTQUFBLFNBQUEsOEVBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLGNBQUEsTUFBQSxDQUFxQjtJQUFBLENBQUE7QUFDakMsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsSUFBQSxZQUFBOzs7O0FBVnFDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxPQUFBLGdCQUFBLE9BQUEsZ0JBQUEsR0FBQSxLQUFBLElBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsT0FBQSxnQkFBQSxPQUFBLGdCQUFBLElBQUEsS0FBQSxJQUFBO0FBQ0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLE9BQUEsZ0JBQUEsT0FBQSxnQkFBQSxLQUFBLEtBQUEsSUFBQTtBQUNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxPQUFBLGdCQUFBLE9BQUEsZ0JBQUEsTUFBQSxLQUFBLElBQUE7QUFHN0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxpQkFBQSxPQUFBLGdCQUFBLG9CQUFBO0FBQ0EsSUFBQSx5QkFBQSxXQUFBLE9BQUEsZ0JBQUEsT0FBQSxnQkFBQSxPQUFBLEtBQUEsSUFBQTs7Ozs7QUFiWixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsMERBQUEsR0FBQSxDQUFBLEVBSUMsR0FBQSwwREFBQSxJQUFBLENBQUE7QUFZTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLElBQUE7Ozs7QUFqQlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsT0FBQSxzQkFBQSxJQUFBLENBQUE7Ozs7O0FBaUNZLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxPQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7O0FBTW9CLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBOztBQUEyRixJQUFBLDJCQUFBO0FBQ3JHLElBQUEscUJBQUEsR0FBQSxvQ0FBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsSUFBQSwwQkFBQSxHQUFBLEdBQUEsYUFBQSw4QkFBQSxHQUFBLEtBQUEsUUFBQSxrQkFBQSxxQkFBQSxDQUFBLENBQUEsR0FBQSxHQUFBOzs7OztBQUZkLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsc0ZBQUEsR0FBQSxDQUFBO0FBR0EsSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7QUFMUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxRQUFBLGtCQUFBLHFCQUFBLFFBQUEsa0JBQUEsZUFBQSxRQUFBLGtCQUFBLFlBQUEsTUFBQSxTQUFBLElBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxzQ0FBQSwwQkFBQSxHQUFBLEdBQUEsUUFBQSxnQkFBQSxvQkFBQSxHQUFBLGdDQUFBOzs7Ozs7QUFJSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBRUksSUFBQSx5QkFBQSxTQUFBLFNBQUEsK0ZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQ3lDLDBCQUFBLFFBQUEsa0JBQUEsY0FBQSxRQUFBLFVBQUEsS0FBK0MsUUFBQSxrQkFBQSxjQUFBLFFBQUEsYUFBQSxJQUVqSCxRQUFBLGtCQUFBLFVBQUEsSUFDQyxRQUFBLGtCQUFBLFNBQUEsQ0FDTjtJQUFBLENBQUE7QUFBMkIsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7Ozs7QUFJSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBRFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxnQkFBQSxRQUFBLGdCQUFBLHVCQUFBOzs7OztBQUlKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLE9BQUEsQ0FBQTs7QUFDSixJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTs7OztBQU5xQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxZQUFBO0FBR0osSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLDBCQUFBLElBQUEsR0FBQSxRQUFBLGdCQUFBLGdCQUFBLEdBQUEsNEJBQUE7Ozs7O0FBS2IsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsT0FBQSxDQUFBOztBQUNKLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRCQUFBOzs7O0FBTnFCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLE9BQUE7QUFHSixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGFBQUEsMEJBQUEsSUFBQSxHQUFBLFFBQUEsZ0JBQUEsMkJBQUEsR0FBQSw0QkFBQTs7Ozs7QUFPTCxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7Ozs7QUFGaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsT0FBQTs7Ozs7QUFLTCxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRDQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsYUFBQTs7Ozs7QUFHVCxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRDQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsU0FBQTs7Ozs7QUFHVCxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRDQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLElBQUEsRUFBYSxRQUFBLFFBQUEsYUFBQTs7Ozs7QUFHdEIsSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0Q0FBQTs7OztBQURhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLFdBQUE7Ozs7O0FBR1QsSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0Q0FBQTs7OztBQURhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLE1BQUE7Ozs7O0FBZGpCLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEscUdBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSxxR0FBQSxHQUFBLENBQUEsRUFBQSxHQUFBLHFHQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEscUdBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSxxR0FBQSxHQUFBLENBQUE7QUFhTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9DQUFBOzs7O0FBaEJRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLGdCQUFBLHlCQUFBLFFBQUEscUJBQUEsUUFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxnQkFBQSx5QkFBQSxRQUFBLHFCQUFBLGFBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsZ0JBQUEseUJBQUEsUUFBQSxxQkFBQSxvQkFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxnQkFBQSx5QkFBQSxRQUFBLHFCQUFBLFlBQUEsQ0FBQSxRQUFBLGdCQUFBLGVBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsZ0JBQUEseUJBQUEsUUFBQSxxQkFBQSxvQkFBQSxJQUFBLEVBQUE7Ozs7O0FBT0EsSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3Q0FBQTs7O0FBRFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxnQkFBQSxxQkFBQTs7Ozs7QUFHTixJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdDQUFBOzs7QUFEVSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGdCQUFBLG9CQUFBOzs7OztBQUdOLElBQUEscUJBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0NBQUE7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsZ0JBQUEsb0JBQUE7Ozs7O0FBR04sSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3Q0FBQTs7O0FBRFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxnQkFBQSx3QkFBQTs7Ozs7QUFHTixJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdDQUFBOzs7O0FBRFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxnQkFBQSxRQUFBLGdCQUFBLGVBQUEsZ0JBQUE7Ozs7O0FBdENsQixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLHVGQUFBLEdBQUEsQ0FBQSxFQUlDLEdBQUEsdUZBQUEsR0FBQSxDQUFBO0FBbUJELElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsdUZBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSx1RkFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLHVGQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsd0ZBQUEsR0FBQSxDQUFBLEVBQUEsSUFBQSx3RkFBQSxHQUFBLENBQUE7QUFhTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTs7OztBQTFDNkMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxpQkFBQSxRQUFBLHVCQUFBO0FBQ3JDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLDBCQUFBLElBQUEsQ0FBQTtBQXdCSSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxnQkFBQSx5QkFBQSxRQUFBLHFCQUFBLFFBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsZ0JBQUEseUJBQUEsUUFBQSxxQkFBQSxhQUFBLElBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLGdCQUFBLHlCQUFBLFFBQUEscUJBQUEsb0JBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsZ0JBQUEseUJBQUEsUUFBQSxxQkFBQSxZQUFBLENBQUEsUUFBQSxnQkFBQSxlQUFBLEtBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLGdCQUFBLHlCQUFBLFFBQUEscUJBQUEsb0JBQUEsS0FBQSxFQUFBOzs7OztBQVNBLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxlQUFBOzs7OztBQUliLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxPQUFBOzs7OztBQVJyQixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLHVGQUFBLEdBQUEsQ0FBQSxFQUlDLEdBQUEsdUZBQUEsR0FBQSxDQUFBO0FBTUQsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxPQUFBLENBQUE7O0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsNEJBQUE7Ozs7QUFmNkMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxpQkFBQSxRQUFBLHVCQUFBO0FBQ3JDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxDQUFBLFFBQUEsMEJBQUEsSUFBQSxFQUFBO0FBS0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsMEJBQUEsSUFBQSxFQUFBO0FBTVMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLDBCQUFBLEdBQUEsR0FBQSxRQUFBLGdCQUFBLGFBQUEsZ0JBQUEsR0FBQSw0QkFBQTs7Ozs7QUFLYixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBRmEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxPQUFBLFFBQUEsZ0JBQUEsVUFBQSwyQkFBQTs7Ozs7QUFJVCxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTs7OztBQU5xQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxPQUFBOzs7OztBQVFqQixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxVQUFBLEVBQUE7OztBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7QUFGZ0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxPQUFBLDBCQUFBLEdBQUEsR0FBQSwwQkFBQSxHQUFBLEdBQUEsUUFBQSxnQkFBQSxRQUFBLENBQUEsR0FBQSxtQ0FBQTs7Ozs7O0FBTVosSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUF5RSxJQUFBLHlCQUFBLFNBQUEsU0FBQSxrR0FBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLGtCQUFBLFNBQUEsQ0FBNEI7SUFBQSxDQUFBO0FBQzFHLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQUpnQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsUUFBQSxrQkFBQSxhQUFBO0FBQ2YsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsYUFBQTs7Ozs7QUFXTCxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9DQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsWUFBQTs7Ozs7QUFHVCxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9DQUFBOzs7O0FBRHNDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLGFBQUEsRUFBc0IsUUFBQSxJQUFBOzs7Ozs7QUFUaEUsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUdJLElBQUEseUJBQUEsU0FBQSxTQUFBLGtHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsa0JBQUEsWUFBQSxDQUErQjtJQUFBLENBQUE7QUFFeEMsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLHVGQUFBLEdBQUEsQ0FBQSxFQUVDLEdBQUEsdUZBQUEsR0FBQSxDQUFBO0FBSUQsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7QUFYUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsUUFBQSxrQkFBQSxxQkFBQSxRQUFBLGtCQUFBLGdCQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsUUFBQSxrQkFBQSxtQkFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxrQkFBQSxtQkFBQSxJQUFBLEVBQUE7Ozs7O0FBV1ksSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsTUFBQSxFQUFBO0FBT0ksSUFBQSxxQkFBQSxHQUFBLG9EQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBb0QsSUFBQSwyQkFBQTtBQUM5RCxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRDQUFBOzs7OztBQVBRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEscUNBQUEsY0FBQSxRQUFBLGtCQUFBLFlBQUEsTUFBQSxRQUFBLEtBQUEsR0FBQSxFQUFBO0FBQ0EsSUFBQSwwQkFBQSxXQUFBLFFBQUEsa0JBQUEsY0FBQSxLQUFBLENBQUEsRUFBb0QsV0FBQSxRQUFBLG1CQUFBLFFBQUEsa0JBQUEsWUFBQSxNQUFBLFFBQUEsS0FBQSxJQUFBLENBQUEsQ0FBQSxFQUFBLFdBQUEsUUFBQSxtQkFBQSxRQUFBLGtCQUFBLFlBQUEsTUFBQSxRQUFBLEtBQUEsSUFBQSxDQUFBLENBQUE7QUFJOUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxRQUFBLGtCQUFBLFlBQUEsTUFBQSxRQUFBLEtBQUEsQ0FBQTs7Ozs7QUFUbEIsSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsSUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSwrQkFBQSxHQUFBLDZGQUFBLEdBQUEsSUFBQSxNQUFBLE1BQUEsdUNBQUE7QUFXSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9DQUFBOzs7O0FBYnVCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSw4QkFBQSxHQUFBLEtBQUEsZ0JBQUEsUUFBQSxhQUFBLEtBQUEsQ0FBQTtBQUNmLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxrQkFBQSxZQUFBLEtBQUE7Ozs7O0FBSFosSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx1RkFBQSxHQUFBLENBQUE7QUFlSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBaEJRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLGtCQUFBLGVBQUEsUUFBQSxrQkFBQSxZQUFBLE1BQUEsU0FBQSxJQUFBLElBQUEsRUFBQTs7Ozs7O0FBa0JKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBMEcsSUFBQSx5QkFBQSxTQUFBLFNBQUEsa0dBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxrQkFBQSxTQUFBLENBQTRCO0lBQUEsQ0FBQTtBQUMzSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7QUFKZ0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLFFBQUEsZ0JBQUEsd0JBQUEsQ0FBQSxRQUFBLHVCQUFBO0FBRWYsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsY0FBQTs7Ozs7O0FBU2IsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUlJLElBQUEseUJBQUEsU0FBQSxTQUFBLGtHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsa0JBQUEsU0FBQSxDQUE0QjtJQUFBLENBQUE7QUFDeEMsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQUhRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxRQUFBLGdCQUFBLHdCQUFBLENBQUEsUUFBQSx1QkFBQTs7Ozs7O0FBS0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFpRSxJQUFBLHlCQUFBLFNBQUEsU0FBQSxrR0FBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLGtCQUFBLFVBQUEsQ0FBNkI7SUFBQSxDQUFBO0FBQUUsSUFBQSwyQkFBQTtBQUM3RyxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7O0FBNU1aLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLE1BQUEsQ0FBQTtBQVdJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx3RUFBQSxHQUFBLENBQUE7QUFHQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx3RUFBQSxHQUFBLENBQUEsRUFPQyxJQUFBLHlFQUFBLEdBQUEsQ0FBQTtBQVdMLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLHlFQUFBLEdBQUEsQ0FBQTtBQUdBLElBQUEsd0JBQUEsSUFBQSxPQUFBLENBQUE7O0FBQ0EsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLHlFQUFBLElBQUEsQ0FBQSxFQVNDLElBQUEseUVBQUEsSUFBQSxDQUFBLEVBQUEsSUFBQSx5RUFBQSxJQUFBLENBQUEsRUFBQSxJQUFBLHlFQUFBLElBQUEsQ0FBQSxFQUFBLElBQUEseUVBQUEsR0FBQSxDQUFBLEVBQUEsSUFBQSx5RUFBQSxJQUFBLENBQUEsRUFBQSxJQUFBLHlFQUFBLEdBQUEsQ0FBQTtBQTRGTCxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSx5RUFBQSxHQUFBLENBQUEsRUFLQyxJQUFBLHlFQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEseUVBQUEsR0FBQSxDQUFBLEVBQUEsSUFBQSx5RUFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLHlFQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEseUVBQUEsR0FBQSxDQUFBO0FBeURMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBOzs7O0FBOU1RLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEscUNBQUEsbUJBQUEsUUFBQSxhQUFBLEVBQUE7QUFJQSxJQUFBLDBCQUFBLE9BQUEsUUFBQSxhQUFBLElBQUEsRUFBNEIsUUFBQSxRQUFBLGNBQUEsSUFBQSxFQUFBLFNBQUEsUUFBQSx5QkFBQSxJQUFBLEVBQUEsYUFBQSxRQUFBLFNBQUE7QUFINUIsSUFBQSwwQkFBQSxrQkFBQSxDQUFBLFFBQUEsZ0JBQUEsaUJBQUEsRUFBMkQsYUFBQSxRQUFBLFNBQUEsRUFBQSxjQUFBLFFBQUEsZ0JBQUEsQ0FBQTtBQVEzRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxnQkFBQSxvQkFBQSxJQUFBLEVBQUE7QUFLUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxnQkFBQSx1QkFBQSxJQUFBLEVBQUE7QUFRQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsUUFBQSxrQkFBQSxjQUFBLEtBQUEsRUFBQTtBQVlBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLGdCQUFBLDBCQUFBLEtBQUEsRUFBQTtBQUdLLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSwwQkFBQSxJQUFBLElBQUEsUUFBQSxnQkFBQSxtQkFBQSxHQUFBLDRCQUFBO0FBQ0wsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsZ0JBQUEsbUJBQUEsS0FBQSxFQUFBO0FBVUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsZ0JBQUEsOEJBQUEsS0FBQSxFQUFBO0FBVUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsZ0JBQUEsd0JBQUEsQ0FBQSxRQUFBLGdCQUFBLGVBQUEsS0FBQSxFQUFBO0FBNENBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLGdCQUFBLGVBQUEsS0FBQSxFQUFBO0FBaUJBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLGdCQUFBLFdBQUEsS0FBQSxFQUFBO0FBS0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsZ0JBQUEsV0FBQSxLQUFBLEVBQUE7QUFVQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsUUFBQSxnQkFBQSxXQUFBLEtBQUEsRUFBQTtBQU9BLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxDQUFBLFFBQUEsa0JBQUEsY0FBQSxRQUFBLFVBQUEsS0FBQSxDQUFBLFFBQUEsa0JBQUEsY0FBQSxRQUFBLGFBQUEsS0FBQSxDQUFBLFFBQUEsa0JBQUEsb0JBQUEsS0FBQSxFQUFBO0FBTUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsa0JBQUEsY0FBQSxRQUFBLGFBQUEsSUFBQSxLQUFBLEVBQUE7QUFlQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsQ0FBQSxRQUFBLGtCQUFBLG9CQUFBLEtBQUEsRUFBQTtBQW1CQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsQ0FBQSxRQUFBLGtCQUFBLGdCQUFBLENBQUEsUUFBQSxrQkFBQSxvQkFBQSxLQUFBLEVBQUE7QUFNQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsUUFBQSxrQkFBQSxnQkFBQSxDQUFBLFFBQUEsa0JBQUEsY0FBQSxRQUFBLFVBQUEsS0FBQSxDQUFBLFFBQUEsa0JBQUEsY0FBQSxRQUFBLGFBQUEsS0FBQSxDQUFBLFFBQUEsa0JBQUEsb0JBQUEsS0FBQSxFQUFBO0FBYUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsa0JBQUEscUJBQUEsUUFBQSxrQkFBQSxjQUFBLFFBQUEsVUFBQSxLQUFBLFFBQUEsa0JBQUEsY0FBQSxRQUFBLGFBQUEsSUFBQSxLQUFBLEVBQUE7Ozs7O0FBNU1wQixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsMERBQUEsSUFBQSxFQUFBO0FBa05KLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsSUFBQTs7OztBQW5OUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxrQkFBQSxJQUFBLEVBQUE7OztBRHRCUiw2QkE4QmE7QUE5QmI7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQXNCTSxJQUFPLHNCQUFQLE1BQU8scUJBQW1CO01BdURqQjtNQUNDO01BQ0E7TUF4RHNDO01BQ0s7TUFDbEI7TUFJOUIsZ0JBQWdCO01BRWhCLHVCQUF1QjtNQUN2QjtNQUNBO01BTUE7TUFDQTtNQUNBLFlBQVk7TUFDWiwwQkFBMEI7TUFFekI7TUFDQTtNQUNBO01BRUMsa0JBQWtCO01BQ2xCLHVCQUF1QjtNQUN2QixhQUFhO01BQ2IsZ0JBQWdCO01BR2xCLFVBQVU7TUFDVCxpQkFBaUI7TUFDakIseUJBQXlCO01BQ3pCLHlCQUF5QjtNQUN6QjtNQUNEO01BQ0E7TUFHUCxTQUFTO01BQ1QsVUFBVTtNQUNWLFVBQVU7TUFDVixpQkFBaUI7TUFDakIsZ0JBQWdCO01BQ2hCLGdCQUFnQjtNQUNoQixlQUFlO01BQ2YsY0FBYztNQUNkLGtCQUFrQjtNQUNsQixZQUFZO01BQ1osZ0JBQWdCO01BQ2hCLGVBQWU7TUFFZixZQUNXLG1CQUNDLGdCQUNBLFVBQW1CO0FBRnBCLGFBQUEsb0JBQUE7QUFDQyxhQUFBLGlCQUFBO0FBQ0EsYUFBQSxXQUFBO01BQ1Q7TUFPSCxvQkFBb0IsT0FBb0I7QUFDcEMsWUFBSSxLQUFLLGtCQUFrQixtQkFBbUI7QUFDMUM7O0FBRUosZ0JBQVEsTUFBTSxNQUFNO1VBQ2hCLEtBQUssY0FBYztBQUlmLGdCQUFJLEtBQUssbUJBQW1CLEtBQUssa0JBQWtCLDBCQUEwQixLQUFLLGtCQUFrQixzQkFBc0I7QUFFdEgsa0JBQUksQ0FBQyxLQUFLLGdCQUFnQix3QkFBeUIsS0FBSyxnQkFBZ0Isd0JBQXdCLEtBQUsseUJBQTBCO0FBQzNILHFCQUFLLGtCQUFrQixTQUFROzs7QUFHdkM7O1VBRUosS0FBSyxhQUFhO0FBQ2QsZ0JBQUksS0FBSyxtQkFBbUIsS0FBSyxrQkFBa0IseUJBQXlCLEdBQUc7QUFDM0UsbUJBQUssa0JBQWtCLFNBQVE7O0FBRW5DOztVQUVKLEtBQUssVUFBVTtBQUNYLGdCQUFJLEtBQUssbUJBQW1CLENBQUMsS0FBSyxrQkFBa0IsY0FBYyxVQUFVLEtBQUssQ0FBQyxLQUFLLGtCQUFrQixjQUFjLGFBQWEsR0FBRztBQUNuSSxtQkFBSyxrQkFBa0IsU0FBUTt1QkFDeEIsS0FBSyxtQkFBbUIsS0FBSyxrQkFBa0IsY0FBYztBQUVwRSxtQkFBSyxrQkFBa0IsaUJBQWdCOztBQUUzQzs7O01BR1o7TUFLTyxrQkFBZTtBQUNsQixhQUFLLGtCQUFrQixLQUFJO0FBQzNCLGFBQUssdUNBQXNDO0FBQzNDLGFBQUssZ0NBQStCO0FBQ3BDLGFBQUssdUJBQXNCO0FBQzNCLGFBQUssdUJBQXNCO0FBQzNCLGFBQUssc0JBQXFCO0FBQzFCLGFBQUssc0JBQXFCO01BQzlCO01BS08sY0FBVztBQUNkLFlBQUksS0FBSyxvQkFBb0I7QUFDekIsZUFBSyxtQkFBbUIsWUFBVzs7QUFFdkMsWUFBSSxLQUFLLG9CQUFvQjtBQUN6QixlQUFLLG1CQUFtQixZQUFXOztBQUV2QyxZQUFJLEtBQUssbUJBQW1CO0FBQ3hCLGVBQUssa0JBQWtCLFlBQVc7O01BRTFDO01BRVEsd0JBQXFCO0FBQ3pCLGFBQUssWUFBWSxRQUFRLFVBQVUsQ0FBQyxhQUFtQztBQUNuRSxlQUFLLFdBQVcsU0FBUyxRQUFPO1FBQ3BDLENBQUM7QUFFRCxhQUFLLGtCQUFrQixrQkFBa0IsS0FBSyxJQUFJLENBQUMsaUJBQWtCLEtBQUssbUJBQW1CLFlBQWEsQ0FBQyxFQUFFLFVBQVM7QUFDdEgsYUFBSyxrQkFBa0IsZUFBZSxLQUFLLElBQUksQ0FBQyxpQkFBa0IsS0FBSyxnQkFBZ0IsWUFBYSxDQUFDLEVBQUUsVUFBUztNQUNwSDtNQUtRLHlDQUFzQztBQUMxQyxhQUFLLGtCQUFrQiwrQkFBOEIsRUFBRyxVQUFVLENBQUMsU0FBc0Q7QUFDckgsZUFBSyxrQkFBa0I7QUFDdkIsY0FBSSxDQUFDLEtBQUssaUJBQWlCO0FBQ3ZCLGlCQUFLLGlCQUFpQjtBQUN0QixpQkFBSyxtQkFBbUI7QUFDeEIsaUJBQUssZ0JBQWdCO0FBQ3JCLGlCQUFLLHdCQUF1QjtBQUM1Qjs7QUFHSixjQUFJLEtBQUssZ0JBQWdCLGFBQWE7QUFDbEMsaUJBQUssY0FBYyxLQUFLLGdCQUFnQjs7QUFHNUMsY0FBSSxLQUFLLG9DQUFtQyxHQUFJO0FBQzVDLGlCQUFLLHNCQUFxQjtBQUMxQixpQkFBSyxpQkFBZ0I7QUFDckIsaUJBQUssa0JBQWtCLHFCQUFxQixLQUFLLEtBQUs7QUFDdEQsZ0JBQUksS0FBSyxxQkFBcUIsVUFBYSxLQUFLLGtCQUFrQixRQUFXO0FBQ3pFLHlCQUFXLE1BQUs7QUFDWixxQkFBSyxpQ0FBaUMsS0FBSyxrQkFBbUIsS0FBSyxhQUFjO2NBQ3JGLEdBQUcsQ0FBQzttQkFDRDtBQUNILG1CQUFLLHdCQUF1Qjs7QUFFaEM7O0FBRUosZUFBSyxzQkFBc0I7UUFDL0IsQ0FBQztNQUNMO01BS1Esa0NBQStCO0FBRW5DLGFBQUssa0JBQWtCLDZCQUE0QixFQUFHLFVBQVUsQ0FBQyxlQUFjO0FBQzNFLGVBQUssMEJBQTBCO1FBQ25DLENBQUM7TUFDTDtNQUtRLHlCQUFzQjtBQUMxQixhQUFLLHFCQUFxQixVQUFVLFFBQVEsUUFBUSxFQUFFLFVBQVUsTUFBSztBQUNqRSxjQUFJLEtBQUssbUJBQWtCLEdBQUk7QUFDM0IsaUJBQUssc0JBQXNCLEtBQUssbUJBQW1CLEtBQUssbUJBQWtCLEdBQUksSUFBSTs7UUFFMUYsQ0FBQztNQUNMO01BS1EseUJBQXNCO0FBQzFCLGFBQUsscUJBQXFCLFVBQVUsUUFBUSxRQUFRLEVBQUUsVUFBVSxNQUFLO0FBQ2pFLGNBQUksS0FBSyxtQkFBa0IsR0FBSTtBQUMzQixpQkFBSyxzQkFBc0IsS0FBSyxtQkFBbUIsS0FBSyxtQkFBa0IsR0FBSSxJQUFJOztRQUUxRixDQUFDO01BQ0w7TUFLUSx3QkFBcUI7QUFDekIsYUFBSyxvQkFBb0IsVUFBVSxRQUFRLE9BQU8sRUFBRSxVQUFVLE1BQUs7QUFDL0QsY0FBSSxLQUFLLG1CQUFrQixHQUFJO0FBQzNCLGlCQUFLLHNCQUFzQixLQUFLLG1CQUFtQixLQUFLLG1CQUFrQixHQUFJLElBQUk7O1FBRTFGLENBQUM7TUFDTDtNQU1RLHNDQUFtQztBQUN2QyxZQUFJLENBQUMsS0FBSyxpQkFBaUI7QUFDdkIsaUJBQU87O0FBRVgsZUFBTyxDQUFDLEtBQUssZ0JBQWdCLGNBQWMsS0FBSyxlQUFlLHNCQUFzQixLQUFLLGdCQUFnQixVQUFVO01BQ3hIO01BS1Esd0JBQXFCO0FBQ3pCLGFBQUssc0JBQXNCLEtBQUssbUJBQW1CLEtBQUssbUJBQWtCLEdBQUksS0FBSztBQUNuRixhQUFLLDRCQUEyQjtBQUdoQyxtQkFBVyxNQUFLO0FBQ1osY0FBSSxLQUFLLGVBQWUsVUFBVSxRQUFRLEtBQUssS0FBSyxlQUFlLFVBQVUsVUFBVSxHQUFHO0FBQ3RGOztBQUVKLGNBQUksQ0FBQyxLQUFLLGVBQWUsVUFBVSxRQUFRLEdBQUc7QUFDMUMsa0JBQU0sY0FBYyxLQUFLLHdCQUF1QjtBQUNoRCxnQkFBSTtBQUNBLHFCQUFPLFNBQVMsRUFBRSxNQUFNLEdBQUcsS0FBSyxhQUFhLFVBQVUsU0FBUSxDQUFFO3FCQUM1RCxLQUFLO0FBQ1Ysa0JBQUksZUFBZSxXQUFXO0FBQzFCLHVCQUFPLE9BQU8sR0FBRyxXQUFXO3FCQUN6QjtBQUNILHNCQUFNOzs7O0FBSWxCLGNBQUksQ0FBQyxLQUFLLGVBQWUsVUFBVSxVQUFVLEdBQUc7QUFDNUMsaUJBQUssZ0JBQWU7O1FBRTVCLEdBQUcsQ0FBQztNQUNSO01BTVEsV0FBUTtBQUNaLFlBQUksS0FBSyxtQkFBbUIsS0FBSyxnQkFBZ0IsYUFBYTtBQUMxRCxpQkFDSSxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWSxVQUNqRCxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWSxjQUNqRCxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWTs7QUFHekQsZUFBTztNQUNYO01BTVEsUUFBSztBQUNULFlBQUksS0FBSyxtQkFBbUIsS0FBSyxnQkFBZ0IsYUFBYTtBQUMxRCxpQkFDSSxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWSxPQUNqRCxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWSxXQUNqRCxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWTs7QUFHekQsZUFBTztNQUNYO01BTVEsU0FBTTtBQUNWLFlBQUksS0FBSyxtQkFBbUIsS0FBSyxnQkFBZ0IsYUFBYTtBQUMxRCxpQkFDSSxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWSxRQUNqRCxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWSxXQUNqRCxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWTs7QUFHekQsZUFBTztNQUNYO01BTVEsVUFBTztBQUNYLFlBQUksS0FBSyxtQkFBbUIsS0FBSyxnQkFBZ0IsYUFBYTtBQUMxRCxpQkFDSSxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWSxTQUNqRCxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWSxZQUNqRCxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWTs7QUFHekQsZUFBTztNQUNYO01BTVEsZUFBZSxXQUFvQjtBQUN2QyxZQUFJLENBQUMsS0FBSyxpQkFBaUI7QUFDdkIsaUJBQU87O0FBRVgsZUFBTyxDQUFDLEtBQUssZ0JBQWdCLHFCQUFxQixLQUFLLGtCQUFrQixLQUFLLG1CQUFrQixHQUFJLFNBQVM7TUFDakg7TUFTUSxrQkFBa0IsU0FBa0MsV0FBb0I7QUFDNUUsWUFBSSxDQUFDLFNBQVM7QUFDVixpQkFBTzs7QUFHWCxZQUFJLG9CQUFvQjtBQUV4QixnQkFBUSxXQUFXO1VBQ2YsS0FBSyxVQUFVLFlBQVk7QUFDdkIsa0JBQU0sUUFBUSxRQUFRO0FBQ3RCLGtCQUFNLE9BQU8sb0JBQW9CLE9BQU87QUFDeEMsa0JBQU0sZ0JBQWdCLEtBQUssU0FBUyxjQUFjO0FBQ2xELGdDQUFvQixnQ0FBZ0MsS0FBSyxnQkFBZ0IsYUFBYSxNQUFNLE9BQU8sYUFBYTtBQUNoSDs7VUFFSixLQUFLLFVBQVUsVUFBVTtBQUNyQixrQkFBTSx1QkFBdUIsS0FBSyxTQUFRLElBQUssS0FBSyx3QkFBdUIsSUFBSyxDQUFDLEtBQUssd0JBQXVCO0FBQzdHLGtCQUFNLE1BQU0sbUJBQW1CLE9BQU87QUFDdEMsa0JBQU0sU0FBUyxRQUFRO0FBQ3ZCLGtCQUFNLFdBQVcsS0FBSyxTQUFTLGNBQWMsc0JBQXFCO0FBQ2xFLGtCQUFNLG1CQUFtQixTQUFTLE1BQU0sU0FBUztBQUNqRCxrQkFBTSxlQUFlLE9BQU8sY0FBYyxPQUFPO0FBQ2pELGdDQUFvQixPQUFPLE9BQU8sVUFBVSx3QkFBd0IsTUFBTSxTQUFTLE1BQU0sZ0JBQWdCLG9CQUFvQjtBQUM3SDs7O0FBR1IsZUFBTztNQUNYO01BS1Esa0JBQWU7QUFDbkIsWUFBSSxLQUFLLE9BQU0sR0FBSTtBQUNmLGtCQUFRLEtBQUssZ0JBQWdCLGFBQWE7WUFDdEMsS0FBSyxZQUFZLE1BQU07QUFDbkIsbUJBQUssY0FBYyxZQUFZO0FBQy9COztZQUVKLEtBQUssWUFBWSxTQUFTO0FBQ3RCLG1CQUFLLGNBQWMsWUFBWTtBQUMvQjs7WUFFSixLQUFLLFlBQVksWUFBWTtBQUN6QixtQkFBSyxjQUFjLFlBQVk7QUFDL0I7OzttQkFHRCxLQUFLLFFBQU8sR0FBSTtBQUN2QixrQkFBUSxLQUFLLGdCQUFnQixhQUFhO1lBQ3RDLEtBQUssWUFBWSxPQUFPO0FBQ3BCLG1CQUFLLGNBQWMsWUFBWTtBQUMvQjs7WUFFSixLQUFLLFlBQVksVUFBVTtBQUN2QixtQkFBSyxjQUFjLFlBQVk7QUFDL0I7O1lBRUosS0FBSyxZQUFZLGFBQWE7QUFDMUIsbUJBQUssY0FBYyxZQUFZO0FBQy9COzs7O01BSWhCO01BS08sa0JBQWU7QUFDbEIsZUFBTyxLQUFLLDJCQUEyQjtNQUMzQztNQU1PLGNBQWMsT0FBWTtBQUM3QixZQUFJLEtBQUssa0JBQWtCLDhCQUE4QjtBQUNyRCxnQkFBTSxnQkFBZTtlQUNsQjtBQUNILGVBQUssa0JBQWtCLFNBQVE7O0FBR25DLFlBQUksS0FBSyxrQkFBa0IsY0FBYyxVQUFVLEdBQUc7QUFDbEQsZUFBSyxrQkFBa0IsaUJBQWdCOztNQUUvQztNQVFBLElBQVcsMEJBQXVCO0FBQzlCLFlBQUksQ0FBQyxLQUFLLG1CQUFtQixDQUFDLEtBQUsscUJBQXFCO0FBQ3BELGlCQUFPOztBQUVYLGVBQU8sS0FBSyxnQkFBZ0IsS0FBSztNQUNyQztNQUtBLElBQVcsY0FBVztBQUNsQixZQUFJLENBQUMsS0FBSyxtQkFBbUIsQ0FBQyxLQUFLLHFCQUFxQjtBQUNwRCxpQkFBTzs7QUFFWCxZQUFJLEtBQUssU0FBUSxHQUFJO0FBQ2pCLGdCQUFNLG9CQUFvQixLQUFLLG9CQUFtQjtBQUNsRCxpQkFBTyxLQUFLLG9CQUFvQixNQUFNLEtBQUssb0JBQW9CLFNBQVM7O0FBRTVFLGVBQU8sS0FBSyxvQkFBb0IsTUFBTSxLQUFLLG9CQUFtQjtNQUNsRTtNQUtBLElBQVcsZUFBWTtBQUNuQixZQUFJLENBQUMsS0FBSyxtQkFBbUIsQ0FBQyxLQUFLLHFCQUFxQjtBQUNwRCxpQkFBTzs7QUFFWCxZQUFJLEtBQUssb0NBQW9DLEdBQUc7QUFDNUMsaUJBQU87O0FBRVgsWUFBSSxLQUFLLGtDQUFrQyxHQUFHO0FBQzFDLGlCQUFPLEtBQUs7O0FBRWhCLGNBQU0sYUFBYSxLQUFLLElBQUksR0FBRyxDQUFDLEtBQUssK0JBQStCO0FBQ3BFLGNBQU0sZ0JBQWdCLEtBQUssSUFBSSxLQUFLLCtCQUErQixVQUFVO0FBQzdFLGVBQU8sS0FBSyxrQ0FBa0M7TUFDbEQ7TUFLUSwwQkFBdUI7QUFDM0IsWUFBSSxjQUFjO0FBQ2xCLFlBQUkscUJBQXFCO0FBQ3pCLFlBQUksS0FBSyx1QkFBdUIsS0FBSyxpQkFBaUI7QUFDbEQsZ0JBQU0sdUJBQXVCLEtBQUssd0JBQXVCO0FBQ3pELGdCQUFNLFdBQVcsS0FBSyxTQUFTLGNBQWMsc0JBQXFCO0FBQ2xFLGdCQUFNLGtCQUFrQixLQUFLLG9CQUFvQixTQUFTLFNBQVMsU0FBUyxLQUFLLG9CQUFvQixTQUFTLFNBQVM7QUFFdkgsY0FBSSxLQUFLLFNBQVEsR0FBSTtBQUNqQixpQ0FBcUI7aUJBQ2xCO0FBQ0gsaUNBQXFCLGtCQUFrQixPQUFPLGNBQWM7O0FBR2hFLGNBQUksS0FBSyxNQUFLLEdBQUk7QUFFZCwwQkFBYyxPQUFPLFVBQVUsU0FBUyxNQUFNO2lCQUMzQztBQUNILDBCQUFjLE9BQU8sVUFBVSxLQUFLLG9CQUFvQixNQUFNO0FBQzlELDBCQUFjLGNBQWMsS0FBSyxJQUFJLGNBQWM7OztBQUczRCxlQUFPO01BQ1g7TUFNUSxzQkFBbUI7QUFDdkIsWUFBSSxDQUFDLEtBQUssaUJBQWlCO0FBQ3ZCLGlCQUFPOztBQUVYLGVBQU8sS0FBSyxnQkFBZ0IsbUJBQW1CLEtBQUssZ0JBQWdCLG1CQUFtQjtNQUMzRjtNQU1PLGdCQUFnQixVQUF5QjtBQUM1QyxZQUFJLEtBQUsscUJBQXFCO0FBQzFCLGdCQUFNLHFCQUFxQixLQUFLLG9CQUFvQixNQUFNLEtBQUssb0JBQW1CO0FBQ2xGLGdCQUFNLHNCQUFzQixLQUFLLG9CQUFvQixPQUFPLEtBQUssb0JBQW1CO0FBQ3BGLGdCQUFNLHdCQUF3QixLQUFLLG9CQUFvQixTQUFTLEtBQUssb0JBQW1CLElBQUs7QUFDN0YsZ0JBQU0sdUJBQXVCLEtBQUssb0JBQW9CLFFBQVEsS0FBSyxvQkFBbUIsSUFBSztBQUUzRixrQkFBUSxVQUFVO1lBQ2QsS0FBSyxnQkFBZ0I7QUFDakIscUJBQU8sRUFBRSxVQUFVLEdBQUcsV0FBVyxHQUFHLGFBQWEscUJBQXFCLElBQUkscUJBQXFCLEVBQUM7WUFDcEcsS0FBSyxnQkFBZ0I7QUFDakIscUJBQU87Z0JBQ0gsVUFBVTtnQkFDVixXQUFXLHNCQUFzQixJQUFJLHNCQUFzQjtnQkFDM0QsYUFBYTtnQkFDYixZQUFZLHNCQUFzQixJQUFJLHNCQUFzQjs7WUFFcEUsS0FBSyxnQkFBZ0I7QUFDakIscUJBQU8sRUFBRSxVQUFVLG9CQUFvQixXQUFXLHNCQUFzQixzQkFBc0IsYUFBYSxzQkFBcUI7WUFDcEksS0FBSyxnQkFBZ0I7QUFDakIscUJBQU8sRUFBRSxVQUFVLHFCQUFxQix3QkFBd0IsSUFBSSxxQkFBcUIsd0JBQXdCLEVBQUM7WUFDdEgsS0FBSyxnQkFBZ0I7QUFDakIscUJBQU8sRUFBRSxVQUFVLG9CQUFvQixXQUFXLHFCQUFxQixhQUFhLHVCQUF1QixZQUFZLHFCQUFvQjs7O0FBR3ZKLGVBQU87TUFDWDtNQU1BLElBQVcsWUFBUztBQUNoQixZQUNJLEtBQUssb0JBQ0gsQ0FBQyxLQUFLLGdCQUFnQixlQUFlLEtBQUssZ0JBQWdCLHFCQUN4RCxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWSxPQUNqRCxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWSxZQUNqRCxLQUFLLGdCQUFnQixnQkFBZ0IsWUFBWSxVQUN2RDtBQUNFLGlCQUFPOztBQUVYLGVBQU87TUFDWDtNQU1RLHFCQUFrQjtBQUN0QixZQUFJLENBQUMsS0FBSyxtQkFBbUIsQ0FBQyxLQUFLLGdCQUFnQixtQkFBbUI7QUFDbEUsaUJBQU87O0FBRVgsY0FBTSxrQkFBa0IsU0FBUyxjQUFjLEtBQUssZ0JBQWdCLGlCQUFpQjtBQUdyRixjQUFNLGVBQWUsa0JBQWtCLGdCQUFnQixRQUFRLGtDQUFrQyxJQUFJO0FBQ3JHLFlBQUksZ0JBQWdCLGFBQWEsZUFBZSxPQUFPLGVBQWUsYUFBYSxjQUFjLEtBQUssZ0JBQWdCLGlCQUFpQixHQUFHO0FBQ3RJLDBCQUFnQixlQUFlLEVBQUUsT0FBTyxTQUFRLENBQUU7O0FBRXRELGVBQU87TUFDWDtNQU1BLElBQVksZ0NBQTZCO0FBQ3JDLGVBQU8sS0FBSyxnQkFBZ0IsS0FBSztNQUNyQztNQU1BLElBQVksa0NBQStCO0FBQ3ZDLFlBQUksQ0FBQyxLQUFLLHVCQUF1QixDQUFDLEtBQUssaUJBQWlCO0FBQ3BELGlCQUFPOztBQUdYLGNBQU0sb0JBQW9CLEtBQUssZ0JBQWdCLG1CQUFtQixLQUFLLGdCQUFnQixtQkFBbUI7QUFFMUcsWUFBSSxLQUFLLGdCQUFnQixZQUFZLFlBQVksS0FBSyxnQkFBZ0IsWUFBWSxhQUFhO0FBQzNGLGlCQUFPLEtBQUssb0JBQW9CLFFBQVEsS0FBSzs7QUFHakQsWUFBSSxLQUFLLGdCQUFnQixZQUFZLFdBQVcsS0FBSyxnQkFBZ0IsWUFBWSxZQUFZO0FBQ3pGLGlCQUFPLEtBQUssb0JBQW9COztBQUdwQyxZQUFJLEtBQUssZ0JBQWdCLFlBQVksTUFBTTtBQUN2QyxpQkFBTyxLQUFLLG9CQUFvQixPQUFPLEtBQUssZ0JBQWdCOztBQUdoRSxZQUFJLEtBQUssZ0JBQWdCLFlBQVksT0FBTztBQUN4QyxpQkFBTyxLQUFLLG9CQUFvQixPQUFPLEtBQUssb0JBQW9CLFFBQVE7O0FBRTVFLGVBQU8sS0FBSyxvQkFBb0IsUUFBUSxLQUFLLG9CQUFvQixRQUFRLElBQUksS0FBSyxnQkFBZ0I7TUFDdEc7TUFNQSxJQUFZLGdDQUE2QjtBQUNyQyxZQUFJLGFBQWE7QUFFakIsWUFBSSxLQUFLLGtDQUFrQyxHQUFHO0FBQzFDLHVCQUFhLENBQUMsS0FBSzs7QUFFdkIsWUFBSSxLQUFLLGtDQUFrQyxPQUFPLGFBQWEsS0FBSyxlQUFlO0FBQy9FLHVCQUFhLEtBQUssbUNBQW1DLE9BQU8sYUFBYSxLQUFLOztBQUVsRixlQUFPLEtBQUssSUFBSSxLQUFLLCtCQUErQixVQUFVO01BQ2xFO01BTVEsMEJBQXVCO0FBQzNCLFlBQUksQ0FBQyxLQUFLLHVCQUF1QixDQUFDLEtBQUssaUJBQWlCO0FBQ3BELGlCQUFPOztBQUVYLFlBQUksS0FBSyxnQkFBZ0IsWUFBWSxRQUFRLEtBQUssZ0JBQWdCLFlBQVksT0FBTztBQUNqRixpQkFBTzs7QUFHWCxjQUFNLGdCQUFnQixLQUFLLG9CQUFvQixTQUFTLEtBQUssU0FBUyxjQUFjLHNCQUFxQixFQUFHO0FBRTVHLFlBQUksT0FBTyxjQUFjLGVBQWU7QUFDcEMsaUJBQU8sZ0JBQWdCLE9BQU87O0FBRWxDLGVBQU87TUFDWDtNQVNRLG1CQUFtQixpQkFBMEMsa0JBQXlCO0FBQzFGLFlBQUk7QUFDSixZQUFJLGlCQUFpQjtBQUNqQixnQ0FBc0IsZ0JBQWdCLHNCQUFxQjtBQUMzRCxjQUFJLEtBQUssbUJBQW1CLEtBQUssZ0JBQWdCLHdCQUF3QixDQUFDLGtCQUFrQjtBQUN4RixnQkFBSSxLQUFLLGdCQUFnQixjQUFjO0FBQ25DLG1CQUFLLGtCQUFrQixzQkFBc0IsaUJBQWlCLEtBQUssZ0JBQWdCLHNCQUFzQixLQUFLLGdCQUFnQixhQUFhLE9BQU87bUJBQy9JO0FBQ0gsbUJBQUssa0JBQWtCLHNCQUFzQixpQkFBaUIsS0FBSyxnQkFBZ0Isb0JBQW9COzs7O0FBSW5ILGVBQU87TUFDWDtNQUtRLG1CQUFnQjtBQUNwQixhQUFLLFlBQVk7QUFDakIsbUJBQVcsTUFBSztBQUNaLGVBQUssWUFBWTtRQUNyQixHQUFHLEdBQUk7TUFDWDtNQUtRLDhCQUEyQjtBQUMvQixjQUFNLGtCQUFrQixLQUFLLG1CQUFrQjtBQUMvQyxjQUFNLGVBQWUsU0FBUyxjQUFjLFNBQVM7QUFHckQsWUFBSSxtQkFBbUIsY0FBYztBQUNqQyxlQUFLLGtCQUNBLGlCQUFpQixjQUFjLEVBQUUsV0FBVyxLQUFJLENBQUUsRUFDbEQsS0FBSyxLQUFLLENBQUMsQ0FBQyxFQUNaLFVBQVUsTUFBSztBQUNaLGdCQUFJLEtBQUssbUJBQWtCLEdBQUk7QUFDM0IsbUJBQUssc0JBQXFCOztVQUVsQyxDQUFDOztNQUViO01BT1EsaUNBQWlDLGNBQXNCLFdBQWlCO0FBQzVFLGNBQU0sc0JBQXNCLFlBQVk7QUFDeEMsY0FBTSxtQkFBbUIsc0JBQXNCLFlBQVksSUFBSSxZQUFZO0FBQzNFLGNBQU0sVUFBVSxLQUFLLFNBQVMsU0FBUztBQUN2QyxjQUFNLGlCQUFpQixLQUFLLFNBQVMsZ0JBQWdCO0FBRXJELFlBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCO0FBQzdCOztBQUdKLFlBQUksWUFBWSxLQUFLLFNBQVM7QUFDMUIsZUFBSyxhQUFhOztBQUd0QixZQUFJLHFCQUFxQjtBQUNyQixlQUFLLHdCQUF3QixRQUFRLGVBQWUsZUFBZSxlQUFlLFNBQVM7ZUFDeEY7QUFDSCxlQUFLLHlCQUF5QixRQUFRLGVBQWUsZUFBZSxlQUFlLFNBQVM7O01BRXBHO01BRVEsd0JBQXdCLE1BQW1CLGFBQTBCLFdBQWlCO0FBRTFGLGNBQU0sVUFBVSxLQUFLLFlBQVksS0FBSztBQUN0QyxZQUFJLENBQUMsUUFBUSxVQUFVLFNBQVMsU0FBUyxHQUFHO0FBQ3hDLGVBQUssU0FBUyxRQUFRLENBQUMsTUFBa0IsVUFBaUI7QUFDdEQsaUJBQUssY0FBYyxVQUFVLE9BQU8sU0FBUztBQUM3QyxnQkFBSSxVQUFVLGFBQWEsS0FBSyxVQUFVLElBQUk7QUFDMUMsbUJBQUssY0FBYyxVQUFVLElBQUksU0FBUzs7VUFFbEQsQ0FBQzs7QUFFTCxZQUFJLFFBQVEsS0FBSyxVQUFVLFNBQVMsU0FBUyxLQUFLLFdBQVcsQ0FBQyxRQUFRLFVBQVUsU0FBUyxTQUFTLEdBQUc7QUFDakcsZUFBSyxrQkFBa0IsS0FBSztBQUM1QixlQUFLLFNBQVMsU0FBUyxLQUFLLGNBQWMsZUFBZSxhQUFhLGdCQUFnQixLQUFLLGlCQUFpQixLQUFLO0FBQ2pILGVBQUssVUFBVSxPQUFPLFNBQVM7QUFDL0Isc0JBQVksVUFBVSxJQUFJLFNBQVM7O01BRTNDO01BRVEseUJBQXlCLE1BQW1CLGFBQTBCLFdBQWlCO0FBRTNGLGNBQU0sV0FBVyxLQUFLLFlBQVksTUFBTTtBQUN4QyxhQUFLLFNBQVMsUUFBUSxDQUFDLE1BQWtCLFVBQWlCO0FBQ3RELGVBQUssY0FBYyxVQUFVLE9BQU8sU0FBUztBQUM3QyxjQUFLLEtBQUssbUJBQW1CLEtBQUssVUFBVSxZQUFZLEtBQU8sS0FBSyxtQkFBbUIsS0FBSyxVQUFVLEtBQUssVUFBVSxHQUFJO0FBQ3JILGlCQUFLLGNBQWMsVUFBVSxJQUFJLFNBQVM7O1FBRWxELENBQUM7QUFDRCxZQUFJLFFBQVEsWUFBWSxDQUFDLFNBQVMsVUFBVSxTQUFTLFNBQVMsS0FBSyxZQUFZLEtBQUssVUFBVSxHQUFHO0FBQzdGLGVBQUssa0JBQWtCLEtBQUs7QUFDNUIsY0FBSSxLQUFLLG1CQUFtQixHQUFHO0FBQzNCLGlCQUFLLGFBQWEsS0FBSzs7QUFFM0IsY0FBSSxLQUFLLFVBQVUsU0FBUyxTQUFTLEdBQUc7QUFDcEMsaUJBQUssVUFBVSxPQUFPLFNBQVM7QUFDL0Isd0JBQVksVUFBVSxJQUFJLFNBQVM7OztNQUcvQztNQUtRLDBCQUF1QjtBQUMzQixjQUFNLGtCQUFrQixLQUFLLGtCQUFrQix1QkFBdUI7QUFDdEUsWUFBSSxtQkFBbUIsS0FBSyxTQUFTO0FBQ2pDLGVBQUssa0JBQW1CLGtCQUFrQixLQUFLLFVBQVcsS0FBSyxLQUFLOztBQUV4RSxhQUFLLGFBQWEsS0FBSztNQUMzQjtNQU1PLG1CQUFtQixZQUFrQjtBQUN4QyxZQUFJLEtBQUssa0JBQWtCLHVCQUF1QixLQUFLLFNBQVM7QUFDNUQsaUJBQU8sZUFBZSxLQUFLOztBQUUvQixZQUFJLEtBQUssZUFBZTtBQUNwQixpQkFBTyxlQUFlLEtBQUssZ0JBQWdCOztBQUUvQyxlQUFPO01BQ1g7TUFNTyxtQkFBbUIsWUFBa0I7QUFDeEMsWUFDSSxLQUFLLGtCQUFrQix1QkFBdUIsS0FBSyxXQUNuRCxLQUFLLGtCQUFrQix1QkFBdUIsS0FBSyxrQkFBa0IscUJBQW9CLEVBQUcsVUFDNUYsS0FBSyxlQUNQO0FBQ0UsaUJBQU8sS0FBSyxnQkFBZ0IsSUFBSSxlQUFlOztBQUVuRCxlQUFPO01BQ1g7O3lCQW55QlMsc0JBQW1CLGdDQUFBLGlCQUFBLEdBQUEsZ0NBQUEsY0FBQSxHQUFBLGdDQUFBLGFBQUEsQ0FBQTtNQUFBO2lFQUFuQixzQkFBbUIsV0FBQSxDQUFBLENBQUEsaUJBQUEsQ0FBQSxHQUFBLFdBQUEsU0FBQSwwQkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7Ozs7Ozs7Ozs7Ozs7bUJBQW5CLElBQUEsb0JBQUEsTUFBQTtVQUEyQixHQUFBLE9BQUEsK0JBQUE7Ozs7QUM5QnhDLFVBQUEseUJBQUEsR0FBQSw0Q0FBQSxHQUFBLENBQUEsRUFtQkMsR0FBQSw0Q0FBQSxHQUFBLENBQUE7OztBQW5CRCxVQUFBLDRCQUFBLEdBQUEsSUFBQSxrQkFBQSxJQUFBLEVBQUE7QUFvQkEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsa0JBQUEsSUFBQSxFQUFBOzs7OztxRkRVYSxxQkFBbUIsRUFBQSxXQUFBLHNCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRTlCaEMsU0FBUyxhQUFBQyxZQUFXLE9BQWUsYUFBQUMsa0JBQWlCO0FBQ3BELFNBQVMsa0JBQWtCO0FBRTNCLFNBQVMsYUFBQUMsa0JBQWlCO0FBQzFCLFNBQVMsY0FBYzs7Ozs7Ozs7QUNIbkIsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQTZCLElBQUEseUJBQUEsY0FBQSxTQUFBLHdFQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBYywwQkFBQSxPQUFBLFlBQUEsQ0FBYTtJQUFBLENBQUE7QUFDcEQsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQWtCLElBQUEscUJBQUEsR0FBQSxTQUFBO0FBQUUsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUErQyxJQUFBLHFCQUFBLEdBQUEsV0FBQTtBQUFTLElBQUEsMkJBQUE7QUFBUSxJQUFBLHFCQUFBLEdBQUEsU0FBQTtBQUFDLElBQUEsMkJBQUE7QUFDckYsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLEtBQUE7QUFBSyxJQUFBLHdCQUFBLElBQUEsV0FBQSxFQUFBO0FBQW9DLElBQUEscUJBQUEsRUFBQTs7QUFBZ0QsSUFBQSwyQkFBQTtBQUN6RixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFnRCxJQUFBLHlCQUFBLFNBQUEsU0FBQSxzRUFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsT0FBQSxhQUFBLENBQWM7SUFBQSxDQUFBO0FBQXZFLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLElBQUE7Ozs7QUFOMEIsSUFBQSx3QkFBQSxFQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsTUFBQTtBQUEyQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsMEJBQUEsSUFBQSxHQUFBLHVCQUFBLEdBQUEsRUFBQTtBQUVvQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsT0FBQSxRQUFBOzs7QUROekYsZ0JBZ0JhO0FBaEJiOztBQUVBOzs7Ozs7QUFjTSxJQUFPLHVCQUFQLE1BQU8sc0JBQW9CO01BY1Q7TUFiRTtNQUViO01BRVQsU0FBUztNQUNULFdBQVc7TUFDWCxVQUFVO01BQ1YsMkJBQTJCO01BQzNCO01BR0EsU0FBUztNQUVULFlBQW9CLGNBQTBCO0FBQTFCLGFBQUEsZUFBQTtNQUE2QjtNQUVqRCxXQUFRO0FBRUosYUFBSyxhQUFhLDBCQUF5QixFQUFHLFVBQVUsQ0FBQyxVQUFTO0FBQzlELGVBQUssU0FBUyxVQUFVLE1BQU07QUFDOUIsZUFBSyxVQUFVO0FBQ2YsY0FBSSxLQUFLLDBCQUEwQjtBQUMvQixpQkFBSywyQkFBMkI7QUFDaEMsdUJBQVcsTUFBTSxLQUFLLFlBQVcsR0FBSSxHQUFHOztRQUVoRCxDQUFDO0FBR0QsYUFBSyxhQUFhLHdCQUF1QixFQUFHLFVBQVUsQ0FBQyxxQkFBb0I7QUFDdkUsZUFBSyxXQUFXLENBQUM7UUFDckIsQ0FBQztBQUdELFFBQUFBLFdBQVUsUUFBUSxPQUFPLEVBQUUsVUFBVSxDQUFDLE1BQUs7QUFDdkMsZ0JBQU0sd0JBQXdCLFNBQVMsZUFBZSw4QkFBOEI7QUFDcEYsY0FBSSxLQUFLLFFBQVEsT0FBTSxLQUFNLENBQUMsdUJBQXVCLFNBQVMsRUFBRSxNQUFjLEdBQUc7QUFDN0UsaUJBQUssYUFBWTs7UUFFekIsQ0FBQztNQUNMO01BS0EsY0FBVztBQUNQLFlBQUksQ0FBQyxPQUFPLFNBQVMsR0FBRztBQUNwQixlQUFLLFNBQVMsS0FBSTs7QUFFdEIscUJBQWEsS0FBSyxZQUFZO01BQ2xDO01BRUEsZUFBWTtBQUNSLHFCQUFhLEtBQUssWUFBWTtBQUM5QixhQUFLLFNBQVMsTUFBSztNQUN2QjtNQUVBLGFBQVU7QUFDTixxQkFBYSxLQUFLLFlBQVk7QUFDOUIsYUFBSyxlQUFlLFdBQVcsTUFBTSxLQUFLLGFBQVksR0FBSSxHQUFHO01BQ2pFO01BS0EsY0FBVztBQUNQLGFBQUssVUFBVTtBQUNmLGFBQUssMkJBQTJCO0FBQ2hDLG1CQUFXLE1BQU0sS0FBSyxhQUFhLHFCQUFxQixLQUFLLFNBQVMsTUFBTSxRQUFRLE1BQU0sSUFBSSxDQUFDO01BQ25HO01BT0EsZUFBWTtBQUNSLGFBQUssYUFBYSxxQkFBcUIsS0FBSyxXQUFXLEtBQUssYUFBYSxnQkFBZSxJQUFLLE1BQVM7TUFDMUc7O3lCQTdFUyx1QkFBb0IsZ0NBQUEsWUFBQSxDQUFBO01BQUE7aUVBQXBCLHVCQUFvQixXQUFBLENBQUEsQ0FBQSxrQkFBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLDJCQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBOzs7Ozs7Ozs7QUNoQmpDLFVBQUEseUJBQUEsR0FBQSw2Q0FBQSxJQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUE7QUFXQSxVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFBSyxVQUFBLHlCQUFBLGNBQUEsU0FBQSwwREFBQTtBQUFBLG1CQUFjLElBQUEsWUFBQTtVQUFhLENBQUEsRUFBQyxjQUFBLFNBQUEsMERBQUE7QUFBQSxtQkFBZSxJQUFBLFdBQUE7VUFBWSxDQUFBO0FBQ3hELFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBO0FBRUksVUFBQSx5QkFBQSxTQUFBLFNBQUEscURBQUE7QUFBQSxtQkFBUyxJQUFBLFlBQUE7VUFBYSxDQUFBO0FBUXRCLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsUUFBQSxDQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxRQUFBLEVBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsUUFBQSxFQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxRQUFBLEVBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsUUFBQSxFQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxVQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7O0FBNUJRLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsY0FBQSxHQUFBLEVBQXlCLFlBQUEsRUFBQSxFQUFBLGFBQUEsS0FBQSxFQUFBLGFBQUEsSUFBQSxPQUFBLEVBQUEsYUFBQSxJQUFBLGdCQUFBO0FBT0MsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxXQUFBLDhCQUFBLEdBQUFDLE1BQUEsSUFBQSxNQUFBLENBQUE7Ozs7O3FGRE5yQixzQkFBb0IsRUFBQSxXQUFBLHVCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRWhCakMsU0FBUyxXQUFXLGNBQUFDLGFBQVksU0FBQUMsUUFBZSxhQUFBQyxrQkFBaUI7QUFDaEUsU0FBMEIsd0JBQXdCOzs7QUFEbEQsSUFNYTtBQU5iOztBQU1NLElBQU8sc0JBQVAsTUFBTyxxQkFBbUI7TUFJaEI7TUFDQTtNQUNBO01BTEg7TUFFVCxZQUNZLFNBQ0EsVUFDQSxrQkFBa0M7QUFGbEMsYUFBQSxVQUFBO0FBQ0EsYUFBQSxXQUFBO0FBQ0EsYUFBQSxtQkFBQTtNQUNUO01BRUgsV0FBUTtBQUNKLGFBQUssaUJBQWlCLGFBQWEsVUFBVSxDQUFDLFVBQTBCO0FBQ3BFLGVBQUssaUJBQWlCLE1BQU0sSUFBSTtRQUNwQyxDQUFDO0FBQ0QsYUFBSyxpQkFBaUIsS0FBSyxpQkFBaUIsV0FBVztNQUMzRDtNQUVBLGlCQUFpQixrQkFBd0I7QUFDckMsWUFBSSxLQUFLLGtCQUFrQixrQkFBa0I7QUFDekMsZUFBSyxTQUFTLFNBQVMsS0FBSyxRQUFRLGVBQWUsUUFBUTtlQUN4RDtBQUNILGVBQUssU0FBUyxZQUFZLEtBQUssUUFBUSxlQUFlLFFBQVE7O01BRXRFOzt5QkF0QlMsc0JBQW1CLGdDQUFBLGNBQUEsR0FBQSxnQ0FBQSxhQUFBLEdBQUEsZ0NBQUEsbUJBQUEsQ0FBQTtNQUFBO2lFQUFuQixzQkFBbUIsV0FBQSxDQUFBLENBQUEsSUFBQSxpQkFBQSxFQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsZUFBQSxnQkFBQSxFQUFBLENBQUE7Ozs7OztBQ05oQyxTQUFTLG1CQUFtQixhQUFBQyxrQkFBb0M7QUFHaEUsT0FBTyxXQUFXO0FBTWxCLFNBQVMsV0FBVyxRQUFRLGlCQUFBQyxnQkFBZSxPQUFPLE9BQU8sZUFBZTtBQUN4RSxTQUFTLDZCQUE2Qjs7Ozs7Ozs7O0FDSGxCLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxHQUFBLEdBQUE7QUFBQyxJQUFBLDJCQUFBO0FBQ1gsSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7OztBQUpKLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7QUFDQSxJQUFBLHlCQUFBLEdBQUEsbUVBQUEsR0FBQSxDQUFBO0FBR0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxZQUFBOzs7O0FBTFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxzQkFBQSxPQUFBLHlCQUFBLG9CQUFBO0FBQ0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsMkJBQUEsT0FBQSxvQkFBQSxTQUFBLElBQUEsRUFBQTs7Ozs7QUE0QlEsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFdBQUEsRUFBQTs7QUFDQSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRmdDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLFNBQUEsRUFBa0IsY0FBQSwwQkFBQSxHQUFBLEdBQUEsZ0VBQUEsQ0FBQTs7Ozs7QUFHOUMsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFdBQUEsRUFBQTs7QUFBa0ksSUFBQSxxQkFBQSxHQUFBLEdBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ3RJLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQURnQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxLQUFBLEVBQWMsY0FBQSwwQkFBQSxHQUFBLEdBQUEsbURBQUEsQ0FBQTs7Ozs7QUFVbEQsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDBCQUFBLDBCQUFBLEdBQUEsR0FBQSx5Q0FBQSxHQUFBLG9CQUFBOzs7OztBQVNZLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBcUMsSUFBQSxxQkFBQSxHQUFBLE9BQUE7QUFBSSxJQUFBLDJCQUFBO0FBQzdDLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7Ozs7QUFPSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUE4QixJQUFBLDJCQUFBO0FBQ3hDLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsZ0JBQUEsT0FBQSxJQUFBOzs7OztBQUVOLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7OztBQWhCWixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQW1DLElBQUEseUJBQUEsU0FBQSxTQUFBLG9FQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGtCQUFBLFlBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsa0JBQUEsZUFBQSxDQUErQjtJQUFBLENBQUE7QUFDdkUsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBO0FBQ0EsSUFBQSx5QkFBQSxHQUFBLDREQUFBLEdBQUEsQ0FBQTtBQUdKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsRUFBQTs7O0FBRUEsSUFBQSx5QkFBQSxJQUFBLDZEQUFBLEdBQUEsQ0FBQSxFQUVDLElBQUEsNkRBQUEsR0FBQSxDQUFBO0FBR0wsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBOzs7OztBQWpCZ0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxrQ0FBQSxPQUFBLGdDQUFBLGVBQUEsR0FBQSxnQ0FBQTtBQUNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLHlCQUFBLGdCQUFBLG9CQUFBLE9BQUEsT0FBQSxnQkFBQSxpQkFBQSxRQUFBLE9BQUEsb0JBQUEsS0FBQSxJQUFBLEVBQUE7QUFJMkMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLE9BQUEsK0JBQUEsZUFBQSxHQUFBLDRCQUFBO0FBRTNDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsa0NBQUEsMEJBQUEsSUFBQSxHQUFBLGdCQUFBLG9CQUFBLE9BQUEsT0FBQSxnQkFBQSxpQkFBQSxPQUFBLEdBQUEsZ0JBQUEsR0FBQSxrQ0FBQSwwQkFBQSxJQUFBLEdBQUEsNEJBQUEsR0FBQSxnQ0FBQTtBQUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxnQkFBQSxTQUFBLEtBQUEsRUFBQTs7Ozs7QUFVWixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFGaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsYUFBQSxFQUFzQixRQUFBLElBQUE7Ozs7O0FBSW5DLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxTQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7O0FBRlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQkFBQSwwQkFBQSxHQUFBLEdBQUEsbUNBQUEsR0FBQSxvQkFBQTs7Ozs7QUFJSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7OztBQUZRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMEJBQUEsMEJBQUEsR0FBQSxHQUFBLHlDQUFBLEdBQUEsb0JBQUE7OztBRHJGcEIsZ0JBZWEsdUJBQ1AsZ0NBT087QUF2QmI7O0FBRUE7QUFHQTtBQUNBO0FBQ0E7QUFLQTtBQUNBOzs7Ozs7Ozs7QUFFTyxJQUFNLHdCQUF3QjtBQUNyQyxJQUFNLGlDQUFpQyxDQUFDLG1CQUFtQiw0Q0FBNEM7QUFPakcsSUFBTywrQkFBUCxNQUFPLDhCQUE0QjtNQTJCekI7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BOUJaLGNBQWM7TUFDZCxrREFBa0Q7TUFHbEQsc0JBQXNDLENBQUE7TUFDdEMsMEJBQTBCO01BQzFCO01BQ0Esd0JBQXdCO01BQ3hCO01BQ0EsVUFBVTtNQUNWLHFCQUFxQjtNQUVaLG9CQUF1QztNQUVoRCxnQkFBZ0MsQ0FBQTtNQUdoQyxVQUFVO01BQ1YsZ0JBQWdCQTtNQUNoQixTQUFTO01BQ1QsUUFBUTtNQUNSLFlBQVk7TUFDWixRQUFRO01BRVIsWUFDWSxxQkFDQSxhQUNBLGdCQUNBLHVCQUNBLGdCQUNBLHNCQUEwQztBQUwxQyxhQUFBLHNCQUFBO0FBQ0EsYUFBQSxjQUFBO0FBQ0EsYUFBQSxpQkFBQTtBQUNBLGFBQUEsd0JBQUE7QUFDQSxhQUFBLGlCQUFBO0FBQ0EsYUFBQSx1QkFBQTtNQUNUO01BRUgsY0FBVztBQUNQLGFBQUssY0FBYyxRQUFRLENBQUMsaUJBQWlCLGFBQWEsWUFBVyxDQUFFO01BQzNFO01BS0EsV0FBUTtBQUNKLGFBQUssZUFBZSx1QkFBc0IsRUFBRyxVQUFVLENBQUMsU0FBMEI7QUFDOUUsY0FBSSxNQUFNO0FBSU4sa0JBQU0saUNBQWlDLEtBQUssc0JBQXNCLFNBQVMscUJBQXFCO0FBQ2hHLGtCQUFNLG1DQUFtQyxpQ0FBaUMsTUFBTSw4QkFBOEIsSUFBSTtBQUVsSCxnQkFBSSxLQUFLLHdCQUF3QixDQUFDLGtDQUFrQztBQUNoRSxtQkFBSyx1QkFBdUIsS0FBSzt1QkFDMUIsQ0FBQyxLQUFLLHdCQUF3QixrQ0FBa0M7QUFDdkUsbUJBQUssdUJBQXVCO3VCQUNyQixLQUFLLHdCQUF3QixrQ0FBa0M7QUFDdEUsa0JBQUksaUNBQWlDLFNBQVMsS0FBSyxvQkFBb0IsR0FBRztBQUN0RSxxQkFBSyx1QkFBdUIsS0FBSztxQkFDOUI7QUFDSCxxQkFBSyx1QkFBdUI7OztBQUlwQyxpQkFBSywrQkFBOEI7aUJBQ2hDO0FBQ0gsaUJBQUssc0JBQXNCLE1BQU0scUJBQXFCOztRQUU5RCxDQUFDO01BQ0w7TUFTQSxrQkFBa0IsY0FBMEI7QUFDeEMsYUFBSyxjQUFjO0FBQ25CLGFBQUssb0JBQW9CLHNCQUFzQixZQUFpQztNQUNwRjtNQUtBLFdBQVE7QUFDSixjQUFNLFlBQVksU0FBUyxlQUFlLGdDQUFnQztBQUMxRSxjQUFNLFlBQVk7QUFDbEIsWUFBSSxXQUFXO0FBQ1gsZ0JBQU0sU0FBUyxVQUFVLGVBQWUsVUFBVTtBQUNsRCxjQUFJLFNBQVMsYUFBYSxVQUFVLFlBQVksU0FBUyxXQUFXO0FBQ2hFLGlCQUFLLG9CQUFvQixxQkFBb0I7OztNQUd6RDtNQUtBLGdCQUFhO0FBQ1QsYUFBSyxjQUFjLENBQUMsS0FBSztNQUM3QjtNQU9BLDRCQUF5QjtBQUNyQixhQUFLLGtEQUFrRCxDQUFDLEtBQUs7QUFDN0QsYUFBSyxZQUFZLDZCQUE2QixLQUFLLCtDQUErQyxFQUFFLFVBQVUsTUFBSztBQUMvRyxlQUFLLG9CQUFvQixhQUFZO1FBQ3pDLENBQUM7TUFDTDtNQU9BLDZCQUEwQjtBQUN0QixhQUFLLFlBQVksMkJBQTBCLEVBQUcsVUFBVSxNQUFLO0FBQ3pELGdCQUFNLDBCQUEwQixNQUFLO0FBQ3JDLHFCQUFXLE1BQUs7QUFDWixpQkFBSyx1QkFBdUI7QUFDNUIsaUJBQUssc0JBQXNCLE1BQU0sdUJBQXVCLHVCQUF1QjtBQUMvRSxpQkFBSyw4QkFBNkI7VUFDdEMsR0FBRyxHQUFJO1FBQ1gsQ0FBQztNQUNMO01BUUEsZ0NBQWdDLGNBQTBCO0FBQ3RELGNBQU0sY0FBYyxLQUFLLHFCQUFxQixVQUFVLGFBQWEsS0FBSztBQUMxRSxZQUFJLGFBQWEsU0FBUywwQkFBMEIsR0FBRztBQUNuRCxpQkFBTyxhQUFhLFNBQVM7O0FBRWpDLGVBQU87TUFDWDtNQVFBLCtCQUErQixjQUEwQjtBQUNyRCxlQUFPLEtBQUssb0JBQW9CLCtCQUErQixjQUFjLEtBQUsscUJBQXFCO01BQzNHO01BRVEsMkJBQTJCLGNBQTBCO0FBQ3pELFlBQUksYUFBYSxtQkFBbUI7QUFDaEMsaUJBQU8sS0FBSyxNQUFNLGFBQWEsaUJBQWlCOztBQUVwRCxlQUFPLENBQUE7TUFDWDtNQUVRLGlDQUE4QjtBQUNsQyxhQUFLLGNBQWMsS0FDZixLQUFLLG9CQUFvQiwrQkFBOEIsRUFBRyxVQUFVLENBQUMsa0JBQWlDO0FBQ2xHLGdCQUFNLHdCQUF3QixLQUFLLDBCQUEwQixhQUFhO0FBQzFFLGVBQUssMEJBQTBCLHFCQUFxQjtRQUN4RCxDQUFDLENBQUM7QUFFTixhQUFLLGNBQWMsS0FBSyxLQUFLLG9CQUFvQix5Q0FBd0MsRUFBRyxVQUFVLENBQUMsVUFBbUIsS0FBSyxxQkFBcUIsS0FBTSxDQUFDO0FBQzNKLGFBQUssY0FBYyxLQUFLLEtBQUssb0JBQW9CLCtCQUE4QixFQUFHLFVBQVUsQ0FBQyxZQUFzQixLQUFLLFVBQVUsT0FBUSxDQUFDO01BQy9JO01BRVEsMEJBQTBCLGVBQTZCO0FBQzNELGVBQU8sY0FBYyxPQUFPLENBQUMsaUJBQWlCLGFBQWEsU0FBUyxDQUFDLCtCQUErQixTQUFTLGFBQWEsS0FBSyxDQUFDO01BQ3BJO01BRVEsMEJBQTBCLGVBQTZCO0FBQzNELGFBQUssc0JBQXNCLGNBQWMsS0FBSyxDQUFDLEdBQWlCLE1BQW1CO0FBQy9FLGlCQUFPLE1BQU0sRUFBRSxnQkFBaUIsRUFBRSxRQUFPLElBQUssTUFBTSxFQUFFLGdCQUFpQixFQUFFLFFBQU87UUFDcEYsQ0FBQztBQUNELGFBQUssOEJBQTZCO01BQ3RDO01BRVEsZ0NBQTZCO0FBQ2pDLFlBQUksQ0FBQyxLQUFLLHFCQUFxQjtBQUMzQixlQUFLLDBCQUEwQjttQkFDeEIsS0FBSyxzQkFBc0I7QUFDbEMsZUFBSywwQkFBMEIsS0FBSyxvQkFBb0IsT0FBTyxDQUFDLGlCQUFnQjtBQUM1RSxtQkFBTyxhQUFhLG9CQUFvQixhQUFhLGlCQUFpQixRQUFRLEtBQUssb0JBQXFCO1VBQzVHLENBQUMsRUFBRTtlQUNBO0FBQ0gsZUFBSywwQkFBMEIsS0FBSyxvQkFBb0I7O0FBRzVELFlBQUksQ0FBQyxLQUFLLHVCQUF1QixLQUFLLG9CQUFvQixXQUFXLEdBQUc7QUFFcEUsZUFBSyxrREFBa0Q7ZUFDcEQ7QUFFSCxlQUFLLGtEQUFrRDs7QUFFM0QsYUFBSyxlQUFlLGNBQWE7TUFDckM7O3lCQTNNUywrQkFBNEIsZ0NBQUEsbUJBQUEsR0FBQSxnQ0FBQSxXQUFBLEdBQUEsZ0NBQUEsY0FBQSxHQUFBLGdDQUFBLHlCQUFBLEdBQUEsZ0NBQUEscUJBQUEsR0FBQSxnQ0FBQSxvQkFBQSxDQUFBO01BQUE7aUVBQTVCLCtCQUE0QixXQUFBLENBQUEsQ0FBQSwwQkFBQSxDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsNEJBQUEsdUJBQUEsZ0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsd0JBQUEsR0FBQSxXQUFBLE9BQUEsR0FBQSxDQUFBLE1BQUEsd0JBQUEsR0FBQSx3QkFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsUUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsZUFBQSwyQkFBQSxzQkFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLGNBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGVBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLGVBQUEsWUFBQSxrQkFBQSxRQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxNQUFBLHFCQUFBLEdBQUEsWUFBQSxrQkFBQSxRQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxxQkFBQSxHQUFBLENBQUEsTUFBQSxrQ0FBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxhQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLFFBQUEsWUFBQSxHQUFBLENBQUEsUUFBQSxTQUFBLEdBQUEsU0FBQSxnQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLHFCQUFBLE9BQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLHNCQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEscUJBQUEsUUFBQSxjQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLHVCQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxRQUFBLFlBQUEsR0FBQSxDQUFBLGdCQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsZUFBQSxRQUFBLFFBQUEsR0FBQSxhQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsZUFBQSxXQUFBLFFBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHNDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDdkJ6QyxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsVUFBQSxDQUFBO0FBQTBFLFVBQUEseUJBQUEsU0FBQSxTQUFBLGdFQUFBO0FBQVMsZ0JBQUEsY0FBQTtBQUFlLG1CQUFFLElBQUEsMkJBQUE7VUFBNEIsQ0FBQTtBQUM1SCxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxxREFBQSxHQUFBLENBQUE7QUFRSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQWtDLFVBQUEseUJBQUEsU0FBQSxTQUFBLDZEQUFBO0FBQUEsbUJBQVMsSUFBQSxjQUFBO1VBQWUsQ0FBQTtBQUE0QyxVQUFBLDJCQUFBO0FBQ3RHLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLDRCQUFBLENBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsS0FBQSxFQUFBO0FBQWdFLFVBQUEseUJBQUEsU0FBQSxTQUFBLDREQUFBO0FBQUEsbUJBQVMsSUFBQSxjQUFBO1VBQWUsQ0FBQTtBQUNwRixVQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsV0FBQSxFQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxFQUFBOztBQUNKLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQStELFVBQUEseUJBQUEsU0FBQSxTQUFBLGlFQUFBO0FBQUEsbUJBQVMsSUFBQSxjQUFBO1VBQWUsQ0FBQTtBQUNuRixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsV0FBQSxFQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUFvRSxVQUFBLHlCQUFBLFNBQUEsU0FBQSxpRUFBQTtBQUFBLG1CQUFTLElBQUEsMEJBQUE7VUFBMkIsQ0FBQTtBQUNwRyxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsc0RBQUEsR0FBQSxDQUFBLEVBR0MsSUFBQSxzREFBQSxHQUFBLENBQUE7QUFHTCxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsRUFBQTs7QUFDSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUF5QyxVQUFBLHlCQUFBLFVBQUEsU0FBQSwrREFBQTtBQUFBLG1CQUFVLElBQUEsU0FBQTtVQUFVLENBQUE7QUFDekQsVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLHNEQUFBLEdBQUEsQ0FBQTtBQUtBLFVBQUEsK0JBQUEsSUFBQSw4Q0FBQSxJQUFBLElBQUEsTUFBQSxNQUFBLHVDQUFBO0FBc0JBLFVBQUEseUJBQUEsSUFBQSxzREFBQSxHQUFBLENBQUEsRUFJQyxJQUFBLHNEQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsc0RBQUEsR0FBQSxDQUFBO0FBV0wsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUF6RmlCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLE1BQUE7QUFDVCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSwwQkFBQSxJQUFBLElBQUEsRUFBQTtBQVVvRCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsSUFBQSxjQUFBLFNBQUEsTUFBQTtBQUMxQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsSUFBQSxjQUFBLFNBQUEsTUFBQTtBQUtZLFVBQUEsd0JBQUEsRUFBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLGlCQUFBO0FBQ1YsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxjQUFBLDhCQUFBLElBQUFDLElBQUEsQ0FBQTtBQUNnQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxLQUFBO0FBSWhDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsaUNBQUEsMEJBQUEsMEJBQUEsSUFBQSxJQUFBLHVDQUFBLEdBQUEsb0JBQUE7QUFHNEIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsT0FBQTtBQUs1QixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxrREFBQSxLQUFBLEVBQUE7QUFRQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLDBCQUFBLDBCQUFBLElBQUEsSUFBQSxtREFBQSw4QkFBQSxJQUFBQyxPQUFBLElBQUEsdUJBQUEsT0FBQSxPQUFBLElBQUEsb0JBQUEsV0FBQSxLQUFBLElBQUEsa0JBQUEsQ0FBQSxHQUFBLG9CQUFBO0FBS1IsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsUUFBQSxLQUFBLEVBQUE7QUFLQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsbUJBQUE7QUFzQkEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsVUFBQSxLQUFBLEVBQUE7QUFLQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxvQkFBQSxTQUFBLEtBQUEsSUFBQSxvQkFBQSxVQUFBLElBQUEscUJBQUEsS0FBQSxFQUFBO0FBS0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsdUJBQUEsSUFBQSxvQkFBQSxXQUFBLElBQUEsS0FBQSxFQUFBOzs7OztxRkQ1REMsOEJBQTRCLEVBQUEsV0FBQSwrQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUV2QnpDLFNBQVMsYUFBQUMsa0JBQW9DO0FBQzdDLFNBQVMsc0JBQXNCO0FBQy9CLE9BQU9DLFlBQVc7QUFNbEIsU0FBUyx1QkFBdUIsZ0JBQUFDLGVBQWMsV0FBQUMsZ0JBQWU7QUFDN0QsU0FBdUIsY0FBYzs7Ozs7OztBQ0pqQixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsWUFBQTs7Ozs7QUFHVCxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEscUJBQUE7Ozs7O0FBS0wsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEdBQUEsR0FBQTtBQUFDLElBQUEsMkJBQUE7QUFDWCxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7OztBQWJoQixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDBEQUFBLEdBQUEsQ0FBQSxFQUVDLEdBQUEsMERBQUEsR0FBQSxDQUFBO0FBSUQsSUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUNLLElBQUEscUJBQUEsRUFBQTtBQUNELElBQUEseUJBQUEsSUFBQSwyREFBQSxHQUFBLENBQUE7QUFHSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxRQUFBLENBQUE7QUFBaUQsSUFBQSxxQkFBQSxFQUFBO0FBQXVCLElBQUEsMkJBQUE7QUFDNUUsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsV0FBQSxDQUFBO0FBQXFELElBQUEseUJBQUEsU0FBQSxTQUFBLHVFQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGtCQUFBLFlBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFTLDBCQUFBLE9BQUEsTUFBQSxlQUFBLENBQW1CO0lBQUEsQ0FBQTtBQUFFLElBQUEsMkJBQUE7QUFDdkYsSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLElBQUE7Ozs7O0FBcEJxQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsOEJBQUEsR0FBQUMsT0FBQSxnQkFBQSxRQUFBLE9BQUEsVUFBQSxPQUFBLE1BQUEsZ0JBQUEsU0FBQSxPQUFBLE9BQUEsQ0FBQTtBQUdyQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsZ0JBQUEsUUFBQSxPQUFBLFVBQUEsT0FBQSxPQUFBLElBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxnQkFBQSxTQUFBLE9BQUEsVUFBQSxJQUFBLEVBQUE7QUFJSyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLElBQUEsZ0JBQUEsT0FBQSx3QkFBQTtBQUNELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxnQkFBQSxPQUFBLEtBQUEsRUFBQTtBQUt5QyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLGdCQUFBLElBQUE7QUFFakIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsT0FBQTs7O0FEbkI1QyxVQVlhLG1CQU9BO0FBbkJiOztBQUlBO0FBQ0E7QUFFQTtBQUdBOzs7OztBQUVPLElBQU0sb0JBQW9CO0FBTzNCLElBQU8sOEJBQVAsTUFBTyw2QkFBMkI7TUFpQnhCO01BQ0E7TUFDQTtNQUNBO01BbkJILE9BQUk7TUFDSixVQUFPO01BRWhCLGdCQUFzQyxDQUFBO01BQ3RDLHlCQUErQyxDQUFBO01BQy9DLFlBQXNCLENBQUE7TUFDdEI7TUFFQTtNQUdBLHdCQUF3QjtNQUN4QixlQUFlRjtNQUNmLFVBQVVDO01BRVYsWUFDWSxPQUNBLGdCQUNBLHFCQUNBLDJCQUFvRDtBQUhwRCxhQUFBLFFBQUE7QUFDQSxhQUFBLGlCQUFBO0FBQ0EsYUFBQSxzQkFBQTtBQUNBLGFBQUEsNEJBQUE7TUFDVDtNQUVILFdBQVE7QUFDSixhQUFLLHVCQUFzQjtBQUMzQixhQUFLLGVBQWUsdUJBQXNCLEVBQUcsVUFBVSxDQUFDLFNBQTBCO0FBQzlFLGNBQUksTUFBTTtBQUNOLHVCQUFXLE1BQUs7QUFDWixtQkFBSyw4QkFBOEIsS0FBSyxvQkFBb0IsZ0JBQWdCLEtBQUssT0FBTyxDQUFDLFdBQVcsT0FBTyxTQUFTLENBQUMsRUFBRSxVQUFVLE1BQU0sS0FBSyxnQkFBZSxDQUFFO1lBQ2pLLEdBQUcsR0FBRztpQkFDSDtBQUNILGlCQUFLLDZCQUE2QixZQUFXOztRQUVyRCxDQUFDO01BQ0w7TUFFQSxjQUFXO0FBQ1AsYUFBSyw2QkFBNkIsWUFBVztNQUNqRDtNQUVRLHlCQUFzQjtBQUMxQixhQUFLLDBCQUEwQix1QkFBc0IsRUFBRyxVQUFVLENBQUMsa0JBQXVDO0FBQ3RHLGVBQUssZ0JBQWdCO0FBQ3JCLGVBQUssNENBQTJDO1FBQ3BELENBQUM7TUFDTDtNQU1RLGtCQUFlO0FBQ25CLGFBQUssb0JBQW9CLFVBQVUsaUJBQWlCO0FBQ3BELGFBQUssb0JBQW9CLFFBQVEsaUJBQWlCLEVBQUUsVUFBVSxDQUFDLGtCQUF1QztBQUNsRyx3QkFBYyxRQUFRLENBQUMsaUJBQWdCO0FBQ25DLHlCQUFhLG1CQUFtQixzQkFBc0IsYUFBYSxnQkFBZ0I7QUFDbkYseUJBQWEsYUFBYSxzQkFBc0IsYUFBYSxVQUFVO1VBQzNFLENBQUM7QUFDRCxlQUFLLGdCQUFnQjtBQUNyQixlQUFLLFlBQVksQ0FBQTtBQUNqQixlQUFLLDRDQUEyQztRQUNwRCxDQUFDO01BQ0w7TUFLUSw4Q0FBMkM7QUFDL0MsY0FBTSxNQUFNRixPQUFLO0FBQ2pCLGFBQUsseUJBQXlCLEtBQUssY0FDOUIsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEtBQUssVUFBVSxTQUFTLGFBQWEsRUFBRyxDQUFDLEVBQ25FLE9BQU8sQ0FBQyxpQkFBaUIsYUFBYSxrQkFBa0IsZUFBZSxHQUFHLE1BQU0sYUFBYSxZQUFZLFFBQVEsR0FBRyxLQUFLLEtBQUs7QUFFbkksWUFBSSxLQUFLLGtCQUFrQjtBQUN2Qix1QkFBYSxLQUFLLGdCQUFnQjtBQUNsQyxlQUFLLG1CQUFtQjs7QUFHNUIsY0FBTSx3QkFBd0IsS0FBSyxjQUM5QixRQUFRLENBQUMsaUJBQWlCLENBQUMsYUFBYSxZQUFZLGFBQWEsZ0JBQWdCLENBQUMsRUFDbEYsT0FBTyxDQUFDLFNBQVMsTUFBTSxRQUFRLEdBQUcsQ0FBQyxFQUNuQyxJQUFJLENBQUMsU0FBUyxJQUFLLEVBQ25CLE9BQU8sQ0FBQyxVQUFVLFlBQWEsV0FBV0EsT0FBTSxJQUFJLFVBQVUsT0FBTyxJQUFJLFNBQVUsTUFBUztBQUVqRyxZQUFJLHVCQUF1QjtBQUN2QixlQUFLLG1CQUFtQixXQUFXLE1BQUs7QUFDcEMsaUJBQUssNENBQTJDO1VBQ3BELEdBQUcsc0JBQXNCLEtBQUssR0FBRyxDQUFDOztNQUUxQztNQUVBLE1BQU0sY0FBZ0M7QUFDbEMsYUFBSyxVQUFVLEtBQUssYUFBYSxFQUFHO0FBQ3BDLGFBQUssNENBQTJDO01BQ3BEOzt5QkE5RlMsOEJBQTJCLGdDQUFBLGtCQUFBLEdBQUEsZ0NBQUEsY0FBQSxHQUFBLGdDQUFBLG1CQUFBLEdBQUEsZ0NBQUEseUJBQUEsQ0FBQTtNQUFBO2lFQUEzQiw4QkFBMkIsV0FBQSxDQUFBLENBQUEseUJBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSx1QkFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsR0FBQSxDQUFBLEdBQUEsb0JBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSx3QkFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLHNCQUFBLEdBQUEsUUFBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsTUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHFDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDbkJ4QyxVQUFBLCtCQUFBLEdBQUEsNENBQUEsSUFBQSxJQUFBLE1BQUEsTUFBQSx1Q0FBQTs7O0FBQUEsVUFBQSx5QkFBQSxJQUFBLHNCQUFBOzs7OztxRkRtQmEsNkJBQTJCLEVBQUEsV0FBQSw4QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVuQnhDLFNBQVMsYUFBQUksa0JBQW9DO0FBRzdDLFNBQVMsb0JBQW9COzs7O0FBTWpCLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxPQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7O0FBVlIsSUFhYTtBQWJiOztBQUVBOztBQVdNLElBQU8sK0JBQVAsTUFBTyw4QkFBNEI7TUFJakI7TUFIcEIsWUFBWTtNQUNaO01BRUEsWUFBb0IsNEJBQXNEO0FBQXRELGFBQUEsNkJBQUE7TUFBeUQ7TUFFN0UsV0FBUTtBQUlKLGFBQUssc0JBQXNCLEtBQUssMkJBQTJCLGNBQWMsS0FBSyxhQUFhLEdBQUksQ0FBQyxFQUFFLFVBQVUsQ0FBQyxVQUFTO0FBQ2xILGVBQUssWUFBWTtRQUNyQixDQUFDO01BQ0w7TUFFQSxjQUFXO0FBQ1AsYUFBSyxvQkFBb0IsWUFBVztNQUN4Qzs7eUJBakJTLCtCQUE0QixnQ0FBQSwwQkFBQSxDQUFBO01BQUE7aUVBQTVCLCtCQUE0QixXQUFBLENBQUEsQ0FBQSwwQkFBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxrQkFBQSxHQUFBLFNBQUEsUUFBQSxVQUFBLFFBQUEsU0FBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsc0NBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUFMakMsVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLEdBQUEscURBQUEsR0FBQSxDQUFBOzs7QUFBQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxZQUFBLElBQUEsRUFBQTs7Ozs7cUZBS0ssOEJBQTRCLEVBQUEsV0FBQSwrQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUNiekMsU0FBUyxhQUFBQyxZQUFXLGdCQUFBQyxxQkFBdUM7QUFFM0QsU0FBUyxVQUFBQyxTQUFRLEtBQUssT0FBQUMsWUFBVztBQUVqQyxTQUFTLHlCQUFBQyw4QkFBNkI7QUFTdEMsU0FBUyxrQkFBQUMsaUJBQXVCLGVBQWUsY0FBYztBQVc3RCxTQUFTLG9CQUFBQyx5QkFBd0I7QUFJakMsU0FDSSxRQUNBLFVBQUFDLFNBQ0EsUUFDQSxZQUNBLFNBQUFDLFFBQ0EsU0FBQUMsUUFDQSxRQUNBLFNBQ0EsU0FDQSxRQUNBLFFBQ0EsU0FDQSxjQUNBLFNBQ0EsaUJBQ0EsU0FDQSxXQUNBLFVBQ0EsWUFDQSxjQUNBLFFBQ0EsWUFDQSxnQkFDRzs7Ozs7Ozs7OztBQ2pESyxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsMEJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7Ozs7QUFpQndCLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBOEMsSUFBQSxxQkFBQSxHQUFBLFNBQUE7QUFBTyxJQUFBLDJCQUFBO0FBQ3pELElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7Ozs7QUFFSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUF1QixJQUFBLDJCQUFBO0FBQ2pDLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsUUFBQSxZQUFBLEtBQUE7Ozs7O0FBTmQsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLGtGQUFBLEdBQUEsQ0FBQSxFQUVDLEdBQUEsa0ZBQUEsR0FBQSxDQUFBO0FBSUwsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQVJpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxNQUFBO0FBQ1QsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsUUFBQSxjQUFBLElBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLGNBQUEsSUFBQSxFQUFBOzs7OztBQU1KLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFGYSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsUUFBQSxZQUFBLEdBQUEsMkJBQUE7Ozs7OztBQWtCRCxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBb0QsSUFBQSx5QkFBQSxTQUFBLFNBQUEsK0ZBQUE7QUFBQSxZQUFBLGNBQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsZUFBQSxZQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBUyxjQUFBLGVBQUEsWUFBQTtBQUF3QixhQUFFLDBCQUFBLFFBQUEsZUFBQSxDQUFnQjtJQUFBLENBQUE7QUFBRSxJQUFBLHFCQUFBLENBQUE7O0FBRXZHLElBQUEsMkJBQUE7QUFDTixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7O0FBSmlDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsaUJBQUEsWUFBQTtBQUFnRixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsR0FBQSxZQUFBLENBQUE7Ozs7O0FBSHJILElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSwrQkFBQSxHQUFBLDJFQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7QUFPSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBUlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFNBQUE7Ozs7OztBQVVKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxPQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFBZ0YsSUFBQSxxQkFBQSxHQUFBLGlCQUFBO0FBQWUsSUFBQSwyQkFBQTtBQUNuRyxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsS0FBQSxFQUFBO0FBQWlGLElBQUEseUJBQUEsU0FBQSxTQUFBLDBGQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsa0JBQUEsZUFBQSxDQUF1QztJQUFBLENBQUE7QUFBRSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBYyxJQUFBLDJCQUFBO0FBQ3JKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFGNkMsSUFBQSx3QkFBQSxFQUFBO0FBQUEsSUFBQSx5QkFBQSxnQkFBQSxRQUFBLG9CQUFBLENBQUE7Ozs7OztBQUt6QyxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBa0YsSUFBQSx5QkFBQSxTQUFBLFNBQUEseUZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUN2RyxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFrRCxJQUFBLHFCQUFBLEdBQUEsVUFBQTtBQUFRLElBQUEsMkJBQUE7QUFDOUQsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFKcUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsUUFBQSxFQUFpQixjQUFBLElBQUE7Ozs7OztBQU1sQyxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBa0YsSUFBQSx5QkFBQSxTQUFBLFNBQUEseUZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUN2RyxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFrRCxJQUFBLHFCQUFBLEdBQUEsVUFBQTtBQUFRLElBQUEsMkJBQUE7QUFDOUQsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFKcUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsTUFBQSxFQUFlLGNBQUEsSUFBQTs7Ozs7O0FBTzVCLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBeUIsSUFBQSx5QkFBQSxTQUFBLFNBQUEseUZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxPQUFBLENBQVE7SUFBQSxDQUFBO0FBQ3RDLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQWdELElBQUEscUJBQUEsR0FBQSxVQUFBO0FBQVEsSUFBQSwyQkFBQTtBQUM1RCxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBSGlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLFlBQUEsRUFBcUIsY0FBQSxJQUFBOzs7Ozs7QUE5RWxELElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFTSSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLG9FQUFBLEdBQUEsQ0FBQSxFQVVDLEdBQUEsb0VBQUEsR0FBQSxDQUFBO0FBTUwsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxLQUFBLEVBQUE7QUFBMkQsSUFBQSx5QkFBQSxTQUFBLFNBQUEsMkVBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUNoRixJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEVBQUE7O0FBQStDLElBQUEsMkJBQUE7QUFDekQsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQTBFLElBQUEscUJBQUEsSUFBQSxVQUFBO0FBQVEsSUFBQSwyQkFBQTtBQUN0RixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLHFFQUFBLEdBQUEsQ0FBQSxFQVVDLElBQUEscUVBQUEsSUFBQSxDQUFBO0FBVUQsSUFBQSx3QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxxRUFBQSxJQUFBLENBQUEsRUFPQyxJQUFBLHFFQUFBLElBQUEsQ0FBQTtBQVNELElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLHFFQUFBLEdBQUEsQ0FBQTtBQU1KLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBOzs7O0FBakZRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxjQUFBLEVBQTRCLDJCQUFBLDhCQUFBLElBQUFDLElBQUEsQ0FBQSxFQUFBLGFBQUEsSUFBQTtBQU14QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxRQUFBLFlBQUEsSUFBQSxJQUFBLEVBQUE7QUFXQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxZQUFBLElBQUEsSUFBQSxFQUFBO0FBUTZCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSw4QkFBQSxJQUFBQyxJQUFBLENBQUE7QUFDWixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxLQUFBLEVBQWMsY0FBQSxJQUFBO0FBQ2pCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLHNCQUFBLENBQUE7QUFPZCxJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsUUFBQSxhQUFBLFFBQUEsVUFBQSxTQUFBLElBQUEsS0FBQSxFQUFBO0FBV0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsa0JBQUEsS0FBQSxFQUFBO0FBVUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsd0JBQUEsS0FBQSxFQUFBO0FBUUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsdUJBQUEsS0FBQSxFQUFBO0FBU0ksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsY0FBQSxLQUFBLEVBQUE7Ozs7O0FBbEZwQixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxzREFBQSxHQUFBLENBQUE7QUFHQSxJQUFBLHdCQUFBLEdBQUEsb0JBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLHNEQUFBLElBQUEsRUFBQTtBQXVGSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLElBQUE7Ozs7QUE3RitCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSw4QkFBQSxHQUFBQyxNQUFBLE9BQUEscUJBQUEsT0FBQSxnQkFBQSxDQUFBO0FBQ3ZCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLGVBQUEsQ0FBQSxPQUFBLGVBQUEsSUFBQSxFQUFBO0FBR2tCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsb0JBQUEsT0FBQSxtQkFBQSxXQUFBLGNBQUE7QUFDbEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsZ0JBQUEsSUFBQSxJQUFBLEVBQUE7Ozs7O0FBK0ZRLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOztBQUFzRSxJQUFBLHdCQUFBLEdBQUEsSUFBQTtBQUN0RSxJQUFBLHFCQUFBLENBQUE7O0FBQW9FLElBQUEsd0JBQUEsR0FBQSxJQUFBO0FBQ3BFLElBQUEscUJBQUEsQ0FBQTs7QUFBd0UsSUFBQSx3QkFBQSxJQUFBLElBQUE7QUFDeEUsSUFBQSxxQkFBQSxFQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7Ozs7QUFMUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDBCQUFBLDBCQUFBLEdBQUEsR0FBQSx1QkFBQSxHQUFBLE1BQUEsT0FBQSxlQUFBLEdBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDBCQUFBLDBCQUFBLEdBQUEsSUFBQSx1QkFBQSxHQUFBLE1BQUEsT0FBQSxhQUFBLEdBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDBCQUFBLDBCQUFBLEdBQUEsSUFBQSwwQkFBQSxHQUFBLE1BQUEsT0FBQSxjQUFBLEdBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDBCQUFBLDBCQUFBLElBQUEsSUFBQSx5QkFBQSxHQUFBLE1BQUEsT0FBQSxhQUFBLG9CQUFBOzs7OztBQVlSLElBQUEsaUNBQUEsQ0FBQTs7Ozs7QUFBQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsd0RBQUEsR0FBQSxHQUFBLGdCQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7Ozs7QUFEbUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxvQkFBQSxHQUFBOzs7Ozs7QUFtQlgsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBK0QsSUFBQSx5QkFBQSxTQUFBLFNBQUEsNkRBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsZUFBQSxDQUFnQjtJQUFBLENBQUE7QUFDcEYsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUEwQyxJQUFBLHFCQUFBLElBQUEsaUJBQUE7QUFBZSxJQUFBLDJCQUFBO0FBQzdELElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTs7OztBQVJtRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLDJCQUFBLDhCQUFBLEdBQUFGLElBQUEsQ0FBQTtBQUcxQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxTQUFBOzs7Ozs7QUFjakIsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUE2RSxJQUFBLHlCQUFBLFNBQUEsU0FBQSxrRUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLGVBQUEsQ0FBZ0I7SUFBQSxDQUFBO0FBQ2xHLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBd0MsSUFBQSxxQkFBQSxHQUFBLG1CQUFBO0FBQWlCLElBQUEsMkJBQUE7QUFDN0QsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7Ozs7QUFKcUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsUUFBQTs7Ozs7QUFWekIsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQU9JLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSw4Q0FBQSxJQUFBLENBQUE7QUFRSixJQUFBLDJCQUFBOzs7O0FBVkksSUFBQSx5QkFBQSwyQkFBQSw4QkFBQSxHQUFBQSxJQUFBLENBQUE7QUFFQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxPQUFBLGVBQUEsSUFBQSxFQUFBOzs7OztBQWtCSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE0QyxJQUFBLHFCQUFBLEdBQUEsdUJBQUE7QUFBcUIsSUFBQSwyQkFBQTtBQUNyRSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTs7OztBQUpxQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxVQUFBOzs7Ozs7QUFxRmIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQW1GLElBQUEseUJBQUEsU0FBQSxTQUFBLG9FQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsZUFBQSxDQUFnQjtJQUFBLENBQUE7QUFDeEcsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBaUQsSUFBQSxxQkFBQSxHQUFBLGFBQUE7QUFBVyxJQUFBLDJCQUFBO0FBQ2hFLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBOzs7O0FBSnFCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLE1BQUEsRUFBZSxjQUFBLElBQUE7Ozs7OztBQU1oQyxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBbUYsSUFBQSx5QkFBQSxTQUFBLFNBQUEsb0VBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUN4RyxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUErQyxJQUFBLHFCQUFBLEdBQUEsS0FBQTtBQUFHLElBQUEsMkJBQUE7QUFDdEQsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFKcUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsTUFBQSxFQUFlLGNBQUEsSUFBQTs7Ozs7O0FBTWhDLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUE0RSxJQUFBLHlCQUFBLFNBQUEsU0FBQSxvRUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLGVBQUEsQ0FBZ0I7SUFBQSxDQUFBO0FBQ2pHLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTRDLElBQUEscUJBQUEsR0FBQSxlQUFBO0FBQWEsSUFBQSwyQkFBQTtBQUM3RCxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTs7OztBQUpxQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxPQUFBLEVBQWdCLGNBQUEsSUFBQTs7Ozs7O0FBbEg3QyxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBUUksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDhDQUFBLElBQUEsQ0FBQTtBQVFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBb0csSUFBQSx5QkFBQSxTQUFBLFNBQUEsb0RBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsZUFBQSxDQUFnQjtJQUFBLENBQUE7QUFDekgsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBaUUsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQTBCLElBQUEsMkJBQUE7QUFDL0YsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxLQUFBLEVBQUE7QUFBdUYsSUFBQSx5QkFBQSxTQUFBLFNBQUEscURBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsZUFBQSxDQUFnQjtJQUFBLENBQUE7QUFDNUcsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBc0QsSUFBQSxxQkFBQSxJQUFBLGlCQUFBO0FBQWUsSUFBQSwyQkFBQTtBQUN6RSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUErRixJQUFBLHlCQUFBLFNBQUEsU0FBQSxxREFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUNwSCxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUE4RCxJQUFBLHFCQUFBLElBQUEseUJBQUE7QUFBdUIsSUFBQSwyQkFBQTtBQUN6RixJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUFzRyxJQUFBLHlCQUFBLFNBQUEsU0FBQSxxREFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUMzSCxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUEyRCxJQUFBLHFCQUFBLElBQUEsc0JBQUE7QUFBb0IsSUFBQSwyQkFBQTtBQUNuRixJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUF1RixJQUFBLHlCQUFBLFNBQUEsU0FBQSxxREFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUM1RyxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUFzRCxJQUFBLHFCQUFBLElBQUEsaUJBQUE7QUFBZSxJQUFBLDJCQUFBO0FBQ3pFLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsS0FBQSxFQUFBO0FBQXVGLElBQUEseUJBQUEsU0FBQSxTQUFBLHFEQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLGVBQUEsQ0FBZ0I7SUFBQSxDQUFBO0FBQzVHLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQWtELElBQUEscUJBQUEsSUFBQSxpQkFBQTtBQUFlLElBQUEsMkJBQUE7QUFDckUsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxLQUFBLEVBQUE7QUFBK0UsSUFBQSx5QkFBQSxTQUFBLFNBQUEscURBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsZUFBQSxDQUFnQjtJQUFBLENBQUE7QUFDcEcsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBK0MsSUFBQSxxQkFBQSxJQUFBLFNBQUE7QUFBTyxJQUFBLDJCQUFBO0FBQzFELElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsS0FBQSxFQUFBO0FBQXlGLElBQUEseUJBQUEsU0FBQSxTQUFBLHFEQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLGVBQUEsQ0FBZ0I7SUFBQSxDQUFBO0FBQzlHLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQXdELElBQUEscUJBQUEsSUFBQSxtQkFBQTtBQUFpQixJQUFBLDJCQUFBO0FBQzdFLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsS0FBQSxFQUFBO0FBQStFLElBQUEseUJBQUEsU0FBQSxTQUFBLHFEQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLGVBQUEsQ0FBZ0I7SUFBQSxDQUFBO0FBQ3BHLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQStDLElBQUEscUJBQUEsS0FBQSxTQUFBO0FBQU8sSUFBQSwyQkFBQTtBQUMxRCxJQUFBLHFCQUFBLEtBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxLQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsS0FBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxLQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxLQUFBLEtBQUEsRUFBQTtBQUE4RSxJQUFBLHlCQUFBLFNBQUEsU0FBQSxzREFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUNuRyxJQUFBLHFCQUFBLEtBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEtBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxLQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxLQUFBLFFBQUEsRUFBQTtBQUE4QyxJQUFBLHFCQUFBLEtBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUE7QUFDeEQsSUFBQSxxQkFBQSxLQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEtBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEtBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsS0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsS0FBQSxLQUFBLEVBQUE7QUFBcUYsSUFBQSx5QkFBQSxTQUFBLFNBQUEsc0RBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsZUFBQSxDQUFnQjtJQUFBLENBQUE7QUFDMUcsSUFBQSxxQkFBQSxLQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxLQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsS0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsS0FBQSxRQUFBLEVBQUE7QUFBcUQsSUFBQSxxQkFBQSxLQUFBLGVBQUE7QUFBYSxJQUFBLDJCQUFBO0FBQ3RFLElBQUEscUJBQUEsS0FBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEtBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxLQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxLQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEtBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEtBQUEsS0FBQSxFQUFBO0FBQThFLElBQUEseUJBQUEsU0FBQSxTQUFBLHNEQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLGVBQUEsQ0FBZ0I7SUFBQSxDQUFBO0FBQ25HLElBQUEscUJBQUEsS0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsS0FBQSxXQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEtBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEtBQUEsUUFBQSxFQUFBO0FBQThDLElBQUEscUJBQUEsS0FBQSxRQUFBO0FBQU0sSUFBQSwyQkFBQTtBQUN4RCxJQUFBLHFCQUFBLEtBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxLQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsS0FBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxLQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxLQUFBLEtBQUEsRUFBQTtBQUE0RSxJQUFBLHlCQUFBLFNBQUEsU0FBQSxzREFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUNqRyxJQUFBLHFCQUFBLEtBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEtBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxLQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxLQUFBLFFBQUEsRUFBQTtBQUE0QyxJQUFBLHFCQUFBLEtBQUEsTUFBQTtBQUFJLElBQUEsMkJBQUE7QUFDcEQsSUFBQSxxQkFBQSxLQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEtBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLEtBQUEsZ0RBQUEsSUFBQSxDQUFBLEVBT0MsS0FBQSxnREFBQSxJQUFBLENBQUEsRUFBQSxLQUFBLGdEQUFBLElBQUEsQ0FBQTtBQWtCTCxJQUFBLHFCQUFBLEtBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxLQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTs7OztBQW5ISSxJQUFBLHlCQUFBLDJCQUFBLDhCQUFBLElBQUFBLElBQUEsQ0FBQTtBQUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxDQUFBLE9BQUEsZUFBQSxJQUFBLEVBQUE7QUFXcUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsVUFBQSxFQUFtQixjQUFBLElBQUE7QUFNbkIsSUFBQSx3QkFBQSxFQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsTUFBQSxFQUFlLGNBQUEsSUFBQTtBQU1mLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLFlBQUEsRUFBcUIsY0FBQSxJQUFBO0FBTXJCLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLE1BQUEsRUFBZSxjQUFBLElBQUE7QUFNZixJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxVQUFBLEVBQW1CLGNBQUEsSUFBQTtBQU1uQixJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxLQUFBLEVBQWMsY0FBQSxJQUFBO0FBTWQsSUFBQSx3QkFBQSxFQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsZUFBQSxFQUF3QixjQUFBLElBQUE7QUFNeEIsSUFBQSx3QkFBQSxFQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsTUFBQSxFQUFlLGNBQUEsSUFBQTtBQU1mLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLE9BQUEsRUFBZ0IsY0FBQSxJQUFBO0FBTWhCLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLE9BQUEsRUFBZ0IsY0FBQSxJQUFBO0FBTWhCLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLE1BQUEsRUFBZSxjQUFBLElBQUE7QUFNZixJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxNQUFBLEVBQWUsY0FBQSxJQUFBO0FBTWYsSUFBQSx3QkFBQSxFQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsT0FBQSxFQUFnQixjQUFBLElBQUE7QUFJakMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxLQUFBLE9BQUEsZ0JBQUEsTUFBQSxFQUFBO0FBUUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxLQUFBLE9BQUEsaUJBQUEsTUFBQSxFQUFBO0FBUUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxLQUFBLE9BQUEsY0FBQSxNQUFBLEVBQUE7Ozs7OztBQXFCUSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBb0QsSUFBQSx5QkFBQSxTQUFBLFNBQUEsb0VBQUE7QUFBQSxZQUFBLGNBQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsZUFBQSxZQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBUyxjQUFBLGVBQUEsWUFBQTtBQUF3QixhQUFFLDBCQUFBLFFBQUEsZUFBQSxDQUFnQjtJQUFBLENBQUE7QUFBRSxJQUFBLHFCQUFBLENBQUE7O0FBQW9DLElBQUEsMkJBQUE7QUFDakosSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQUZpQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGlCQUFBLFlBQUE7QUFBZ0YsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsWUFBQSxDQUFBOzs7OztBQVZ6SCxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBMEMsSUFBQSxxQkFBQSxJQUFBLFVBQUE7QUFBUSxJQUFBLDJCQUFBO0FBQ3RELElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsK0JBQUEsSUFBQSxnREFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBO0FBS0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7Ozs7QUFaeUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsTUFBQTtBQUtiLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsT0FBQSxTQUFBOzs7OztBQVVaLElBQUEsaUNBQUEsQ0FBQTs7Ozs7QUFBQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsd0RBQUEsR0FBQSxHQUFBLGdCQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7Ozs7QUFEbUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxvQkFBQSxHQUFBOzs7OztBQVlDLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFNSyxJQUFBLHFCQUFBLENBQUE7O0FBQXlDLElBQUEsMkJBQUE7QUFFbEQsSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7Ozs7QUFOUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHFDQUFBLE1BQUEsZ0JBQUEsT0FBQSxFQUFBO0FBQ0EsSUFBQSx5QkFBQSxjQUFBLGVBQUEsR0FBQSxFQUE2QiwyQkFBQSw4QkFBQSxHQUFBQSxJQUFBLENBQUE7QUFHNUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsZUFBQSxLQUFBLENBQUE7Ozs7O0FBSUwsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBQTtBQU1LLElBQUEscUJBQUEsQ0FBQTtBQUFzQixJQUFBLDJCQUFBO0FBRS9CLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7Ozs7O0FBTlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxxQ0FBQSxNQUFBLHNCQUFBLE9BQUEsRUFBQTtBQUNBLElBQUEseUJBQUEsY0FBQSxlQUFBLEdBQUEsRUFBNkIsMkJBQUEsOEJBQUEsR0FBQUEsSUFBQSxDQUFBO0FBRzVCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsZUFBQSxLQUFBOzs7OztBQWxCYixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDZEQUFBLEdBQUEsQ0FBQSxFQVNDLEdBQUEsNkRBQUEsR0FBQSxDQUFBO0FBV0wsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQXJCUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsa0JBQUEsZUFBQSxZQUFBLElBQUEsRUFBQTtBQVVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxrQkFBQSxDQUFBLGVBQUEsWUFBQSxJQUFBLEVBQUE7Ozs7O0FBZGhCLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwrQkFBQSxHQUFBLCtDQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7QUF3QkosSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBMUJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxXQUFBOzs7QUR2VGhCLDRCQWlFYSxpQkFzdkJQO0FBdnpCTjs7QUFNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQTBCQTtBQUVBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFRTSxJQUFPLGtCQUFQLE1BQU8saUJBQWU7TUEyRFo7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNEO01BQ0M7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0Q7TUFDQztNQWhGWjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0EsWUFBWTtNQUNaO01BQ0E7TUFDQTtNQUNBO01BQ0Esd0JBQXdCO01BQ3hCLHVCQUF1QjtNQUN2QjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0EsZUFBZTtNQUNmO01BQ0E7TUFDQSxnQkFBeUI7TUFHekIsU0FBUztNQUNULFlBQVk7TUFDWixXQUFXO01BQ1gsU0FBUztNQUNULFNBQVNIO01BQ1QsZUFBZTtNQUNmLFFBQVFFO01BQ1IsUUFBUUQ7TUFDUixXQUFXO01BQ1gsU0FBUztNQUNULFVBQVU7TUFDVixTQUFTO01BQ1QsU0FBUztNQUNULFVBQVU7TUFDVixTQUFTO01BQ1QsVUFBVTtNQUNWLFVBQVU7TUFDVixrQkFBa0I7TUFDbEIsYUFBYTtNQUNiLGFBQWE7TUFDYixhQUFhO01BQ2IsZUFBZTtNQUNmLFVBQVU7TUFFRjtNQUNBO01BQ0E7TUFDQTtNQUNBLGNBQWM7TUFDZDtNQUVSLFlBQ1ksY0FDQSxrQkFDQSxnQkFDQSx5QkFDQSxnQkFDQSxnQkFDQSxnQkFDQSwrQkFDRCxtQkFDQyxRQUNBLE9BQ0EsMEJBQ0EsbUJBQ0EsY0FDQSx5QkFDQSxpQkFDQSxxQkFDQSx1QkFDQSxnQkFDQSxhQUNBLHFCQUNELGNBQ0Msb0JBQXNDO0FBdEJ0QyxhQUFBLGVBQUE7QUFDQSxhQUFBLG1CQUFBO0FBQ0EsYUFBQSxpQkFBQTtBQUNBLGFBQUEsMEJBQUE7QUFDQSxhQUFBLGlCQUFBO0FBQ0EsYUFBQSxpQkFBQTtBQUNBLGFBQUEsaUJBQUE7QUFDQSxhQUFBLGdDQUFBO0FBQ0QsYUFBQSxvQkFBQTtBQUNDLGFBQUEsU0FBQTtBQUNBLGFBQUEsUUFBQTtBQUNBLGFBQUEsMkJBQUE7QUFDQSxhQUFBLG9CQUFBO0FBQ0EsYUFBQSxlQUFBO0FBQ0EsYUFBQSwwQkFBQTtBQUNBLGFBQUEsa0JBQUE7QUFDQSxhQUFBLHNCQUFBO0FBQ0EsYUFBQSx3QkFBQTtBQUNBLGFBQUEsaUJBQUE7QUFDQSxhQUFBLGNBQUE7QUFDQSxhQUFBLHNCQUFBO0FBQ0QsYUFBQSxlQUFBO0FBQ0MsYUFBQSxxQkFBQTtBQUVSLGFBQUssVUFBVSxVQUFVLFVBQVU7QUFDbkMsYUFBSyxvQkFBb0I7QUFDekIsYUFBSyxxQ0FBb0M7QUFDekMsYUFBSyxTQUFRO01BQ2pCO01BR0EsV0FBUTtBQUVKLFlBQUk7QUFDSixZQUFJLG1EQUFtRDtBQUN2RCxZQUFJO0FBQ0osWUFBSSxLQUFLLGFBQWE7QUFDbEIsZ0JBQU0sY0FBYyxLQUFLLFlBQVksT0FBTyxVQUFVLEtBQUs7QUFDM0Qsc0RBQTRDLE1BQU07QUFDbEQsNENBQWtDLE1BQU07QUFFeEMsZ0JBQU0sdUJBQXVCLEtBQUssZUFBZSxzQkFBc0IsQ0FBQyxVQUFVLEtBQUssQ0FBQztBQUN4RixnQkFBTSx3QkFBd0IsS0FBSyxlQUFlLHNCQUFzQixDQUFDLFVBQVUsSUFBSSxVQUFVLFlBQVksVUFBVSxRQUFRLFVBQVUsS0FBSyxDQUFDO0FBQy9JLGNBQUksdUJBQXVCO0FBQ3ZCLCtDQUFtQztBQUNuQyxnRUFBb0Q7O0FBRXhELGNBQUksc0JBQXNCO0FBQ3RCLCtDQUFtQztBQUNuQyxnRUFBb0Q7O2VBRXJEO0FBRUgsNENBQWtDO0FBQ2xDLHNEQUE0Qzs7QUFHaEQsYUFBSyxjQUFjLE9BQU8sYUFBYTtBQUN2QyxhQUFLLHNCQUFzQixPQUFPLGFBQWEsS0FBSyxJQUFJLGtEQUFrRCxHQUFHO0FBQzdHLGFBQUssbUJBQW1CLE9BQU8sYUFBYTtNQUNoRDtNQUVBLFdBQVE7QUFDSixhQUFLLGVBQWUsZUFBYyxFQUFHLFVBQVUsQ0FBQyxnQkFBZTtBQUMzRCxjQUFJLGFBQWE7QUFDYixpQkFBSyxlQUFlLFlBQVk7QUFDaEMsaUJBQUssYUFBYSxZQUFZLGNBQWM7QUFDNUMsaUJBQUssaUJBQWlCLFlBQVk7QUFDbEMsaUJBQUssY0FBYyxZQUFZLElBQUksT0FBTyxHQUFHO0FBQzdDLGlCQUFLLGdCQUFnQixZQUFZLElBQUk7QUFDckMsaUJBQUssZUFBZSxJQUFJLEtBQUssWUFBWSxJQUFJLE9BQU8sSUFBSSxFQUFFLFlBQVc7QUFDckUsaUJBQUssY0FBYyxZQUFZLElBQUksT0FBTyxLQUFLO0FBQy9DLGlCQUFLLGNBQWMsWUFBWSxlQUFlLFNBQVMsTUFBTTtBQUM3RCxpQkFBSyxnQkFBZ0IsYUFBYSxlQUFlLFNBQVMsZUFBZTs7UUFFakYsQ0FBQztBQUVELGFBQUssbUNBQWtDO0FBR3ZDLGFBQUssd0JBQXdCLEtBQUssZUFDN0IsdUJBQXNCLEVBQ3RCLEtBQ0dMLEtBQUksQ0FBQyxTQUFjO0FBQ2YsZUFBSyxjQUFjO0FBQ25CLGVBQUssdUJBQXVCLE1BQU0sWUFBWTtBQUM5QyxlQUFLLFNBQVE7UUFDakIsQ0FBQyxDQUFDLEVBRUwsVUFBUztBQUVkLGFBQUsseUJBQXlCLDJCQUEyQixVQUFVLENBQUMsZ0JBQWU7QUFDL0UsZUFBSyxjQUFjO0FBQ25CLGVBQUssZ0JBQWU7UUFDeEIsQ0FBQztBQUVELGFBQUssaUJBQWlCLEtBQUssT0FBTyxHQUFHO0FBQ3JDLGFBQUssT0FBTyxPQUFPLEtBQUtELFFBQU8sQ0FBQyxVQUFVLGlCQUFpQixhQUFhLENBQUMsRUFBRSxVQUFVLENBQUMsVUFBeUIsS0FBSyxpQkFBaUIsTUFBTSxHQUFHLENBQUM7TUFDbko7TUFFQSxjQUFXO0FBQ1AsWUFBSSxLQUFLLHVCQUF1QjtBQUM1QixlQUFLLHNCQUFzQixZQUFXOztBQUUxQyxZQUFJLEtBQUsseUJBQXlCO0FBQzlCLGVBQUssd0JBQXdCLFlBQVc7O0FBRTVDLFlBQUksS0FBSyx1QkFBdUI7QUFDNUIsdUJBQWEsS0FBSyxxQkFBcUI7O01BRS9DO01BRUEsd0JBQXdCO1FBQ3BCLEtBQUs7UUFDTCxTQUFTO1FBQ1QsbUJBQW1CO1FBQ25CLFFBQVE7UUFDUixPQUFPO1FBQ1AsTUFBTTtRQUNOLFFBQVE7UUFDUixlQUFlO1FBQ2YsaUJBQWlCO1FBQ2pCLFFBQVE7UUFDUixNQUFNO1FBQ04sTUFBTTtRQUNOLFNBQVM7UUFDVCxpQkFBaUI7UUFDakIsaUJBQWlCO1FBQ2pCLGdDQUFnQztRQUNoQyw4QkFBOEI7UUFDOUIsU0FBUztRQUNULFVBQVU7UUFDVixVQUFVO1FBQ1YsT0FBTztRQUNQLFVBQVU7UUFDVixVQUFVO1FBQ1YsbUJBQW1CO1FBQ25CLFdBQVc7UUFDWCxnQkFBZ0I7UUFDaEIsdUJBQXVCO1FBQ3ZCLG9CQUFvQjtRQUNwQix1QkFBdUI7UUFDdkIsZ0JBQWdCO1FBQ2hCLGdCQUFnQjtRQUNoQixhQUFhO1FBQ2IsWUFBWTtRQUNaLHdCQUF3QjtRQUN4QixzQkFBc0I7UUFDdEIsc0JBQXNCO1FBQ3RCLHdDQUF3QztRQUN4QyxtQkFBbUI7UUFDbkIsT0FBTztRQUNQLGdCQUFnQjtRQUNoQixTQUFTO1FBQ1QsdUJBQXVCO1FBQ3ZCLDBCQUEwQjtRQUMxQixrQkFBa0I7UUFDbEIsa0JBQWtCO1FBQ2xCLGVBQWU7UUFDZixRQUFRO1FBQ1IsWUFBWTtRQUNaLFFBQVE7UUFDUixhQUFhO1FBQ2IsVUFBVTtRQUNWLFNBQVM7UUFDVCxnQkFBZ0I7UUFDaEIsc0JBQXNCO1FBQ3RCLFFBQVE7UUFDUixrQkFBa0I7UUFDbEIsWUFBWTtRQUNaLGtCQUFrQjtRQUNsQixxQkFBcUI7UUFDckIsMkJBQTJCO1FBQzNCLFNBQVM7UUFDVCxNQUFNO1FBQ04sS0FBSztRQUNMLFVBQVU7UUFDVixhQUFhO1FBQ2IsaUJBQWlCO1FBQ2pCLE9BQU87UUFDUCxpQkFBaUI7UUFDakIsV0FBVztRQUNYLFVBQVU7UUFDVixRQUFRO1FBQ1IsYUFBYTtRQUNiLFdBQVc7UUFDWCxRQUFRO1FBQ1IsU0FBUztRQUNULFlBQVk7UUFDWixlQUFlO1FBQ2YsMkJBQTJCO1FBQzNCLHNCQUFzQjtRQUN0Qix5QkFBeUI7UUFDekIsb0JBQW9CO1FBQ3BCLG1CQUFtQjtRQUNuQixnQkFBZ0I7UUFDaEIsYUFBYTtRQUNiLHFCQUFxQjtRQUNyQix5QkFBeUI7UUFDekIsZUFBZTtRQUNmLFVBQVU7UUFDVixVQUFVO1FBQ1Ysa0JBQWtCO1FBQ2xCLHNCQUFzQjtRQUN0Qiw0QkFBNEI7UUFDNUIsaUJBQWlCO1FBQ2pCLHFCQUFxQjtRQUNyQixVQUFVO1FBQ1Ysb0JBQW9CO1FBQ3BCLDJCQUEyQjtRQUMzQixzQ0FBc0M7UUFDdEMsbUJBQW1CO1FBQ25CLFNBQVM7UUFDVCxpQkFBaUI7UUFDakIscUJBQXFCO1FBQ3JCLHFCQUFxQjtRQUNyQixlQUFlO1FBQ2YsZUFBZTtRQUNmLGFBQWE7O01BR2pCLG9DQUFvQztRQUNoQyxPQUFPO1FBQ1AsV0FBVztRQUNYLFdBQVc7UUFDWCxVQUFVO1FBQ1YsY0FBYztRQUNkLGVBQWU7UUFDZixjQUFjO1FBQ2QsVUFBVTtRQUNWLFlBQVk7UUFDWixZQUFZO1FBQ1osVUFBVTtRQUNWLGFBQWE7UUFDYixhQUFhO1FBQ2IsTUFBTTtRQUNOLFNBQVM7UUFDVCxRQUFROztNQU1KLGlCQUFpQixTQUFlO0FBQ3BDLGFBQUssY0FBYyxDQUFBO0FBQ25CLGFBQUsseUJBQXlCLFFBQVEsQ0FBQyxpQkFBaUIsYUFBYSxZQUFXLENBQUU7QUFDbEYsYUFBSywwQkFBMEIsQ0FBQTtBQUUvQixZQUFJLENBQUMsU0FBUztBQUNWOztBQUlKLFlBQUksQ0FBQyxRQUFRLFdBQVcsUUFBUSxLQUFLLENBQUMsUUFBUSxXQUFXLG9CQUFvQixLQUFLLENBQUMsUUFBUSxXQUFXLFVBQVUsR0FBRztBQUMvRzs7QUFJSixZQUFJO0FBQ0EsY0FBSSxjQUFjO0FBR2xCLGNBQUksTUFBTSxRQUFRLFVBQVUsQ0FBQztBQUc3QixnQkFBTSxlQUFlLElBQUksUUFBUSxHQUFHO0FBQ3BDLGNBQUksZ0JBQWdCLEdBQUc7QUFDbkIsa0JBQU0sSUFBSSxVQUFVLEdBQUcsWUFBWTs7QUFJdkMscUJBQVcsV0FBVyxJQUFJLE1BQU0sR0FBRyxHQUFHO0FBQ2xDLDJCQUFlLFVBQVU7QUFHekIsZ0JBQUksQ0FBQyxNQUFNLE9BQU8sT0FBTyxDQUFDLEdBQUc7QUFDekIsbUJBQUssOEJBQThCLGFBQWEsT0FBTzttQkFDcEQ7QUFDSCxtQkFBSywyQkFBMkIsYUFBYSxPQUFPO0FBQ3BELG1CQUFLLHNCQUFzQjs7O2lCQUc5QixHQUFHOztNQUdoQjtNQVFRLDhCQUE4QixhQUFxQixTQUFlO0FBQ3RFLGNBQU0sZ0JBQWdCLFlBQVksV0FBVyxVQUFVO0FBQ3ZELFlBQUksZUFBZTtBQUNmLGtCQUFRLEtBQUsscUJBQXFCO1lBQzlCLEtBQUs7WUFDTCxLQUFLO1lBQ0wsS0FBSztBQUNELG1CQUFLLHNCQUFzQixhQUFhLEtBQUssbUJBQW1CO0FBQ2hFO1lBQ0osS0FBSztBQUNELG1CQUFLLHdCQUF3QixXQUFXLFVBQVUsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxHQUFHLGFBQWEsT0FBTztBQUN6RjtZQUNKO0FBQ0ksb0JBQU0sbUJBQW1CLEtBQUsscUJBQXFCLE1BQU0sY0FBYztBQUN2RSxrQkFBSSxrQkFBa0I7QUFDbEIscUJBQUssd0JBQXdCLFdBQVcsVUFBVSxDQUFDLE9BQU8sT0FBTyxDQUFDLEdBQUcsWUFBWSxRQUFRLGlCQUFpQixDQUFDLEdBQUcsV0FBVyxHQUFHLFdBQVc7QUFDdkk7O0FBRUo7OztBQUlaLGdCQUFRLEtBQUsscUJBQXFCO1VBRTlCLEtBQUs7VUFDTCxLQUFLO1VBQ0wsS0FBSztBQUNELGlCQUFLLGNBQWMsYUFBYSxTQUFTLEtBQUs7QUFDOUM7VUFDSixLQUFLO1VBQ0wsS0FBSztBQUNELGlCQUFLLHdCQUF3QixXQUFXLFFBQVEsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxHQUFHLGFBQWEsT0FBTztBQUN2RjtVQUNKLEtBQUs7QUFHRCxpQkFBSyxpQkFBaUIsT0FBTyxPQUFPLEdBQUcsV0FBVztBQUNsRDtVQUNKLEtBQUs7VUFDTCxLQUFLO1VBQ0wsS0FBSztVQUNMLEtBQUs7VUFDTCxLQUFLO1VBQ0wsS0FBSztBQUNELGlCQUFLLHdCQUF3QixXQUFXLFVBQVUsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxHQUFHLGFBQWEsT0FBTztBQUN6RjtVQUNKLEtBQUs7QUFJRCxrQkFBTSxhQUFhLFlBQVksTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMzQyxpQkFBSyx3QkFBd0IsV0FBVyxNQUFNLENBQUMsT0FBTyxPQUFPLEdBQUcsT0FBTyxVQUFVLENBQUMsR0FBRyxhQUFhLE9BQU87QUFDekc7VUFDSixLQUFLO0FBQ0QsaUJBQUssd0JBQXdCLFdBQVcsU0FBUyxDQUFDLE9BQU8sT0FBTyxDQUFDLEdBQUcsYUFBYSxPQUFPO0FBQ3hGO1VBQ0osS0FBSztBQUNELGlCQUFLLHdCQUF3QixXQUFXLFNBQVMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxHQUFHLGFBQWEsT0FBTztBQUN4RjtVQUNKLEtBQUs7QUFDRCxpQkFBSyx3QkFBd0IsV0FBVyxZQUFZLENBQUMsT0FBTyxPQUFPLENBQUMsR0FBRyxhQUFhLE9BQU87QUFDM0Y7VUFDSixLQUFLO0FBQ0QsaUJBQUssY0FBYyxPQUFPLE9BQU87QUFDakMsaUJBQUssd0JBQXdCLFdBQVcsTUFBTSxDQUFDLEtBQUssV0FBVyxHQUFHLGFBQWEsT0FBTztBQUN0RjtVQUNKLEtBQUs7QUFDRCxpQkFBSyx3QkFBd0IsV0FBVyxjQUFjLENBQUMsT0FBTyxPQUFPLENBQUMsR0FBRyxhQUFhLE9BQU87QUFDN0Y7VUFDSixLQUFLO0FBQ0QsaUJBQUssd0JBQXdCLFdBQVcsZ0JBQWdCLENBQUMsT0FBTyxPQUFPLENBQUMsR0FBRyxhQUFhLE9BQU87QUFDL0Y7VUFDSixLQUFLO0FBR0QsaUJBQUssc0JBQXNCLGFBQWEsUUFBUTtBQUNoRDtVQUNKLEtBQUs7QUFDRCxpQkFBSyxzQkFBc0IsYUFBYSxrQkFBa0I7QUFDMUQ7VUFDSixLQUFLO0FBQ0QsaUJBQUssc0JBQXNCLGFBQWEscUJBQXFCO0FBQzdEO1VBQ0osS0FBSztBQUNELGlCQUFLLHNCQUFzQixhQUFhLHFCQUFxQjtBQUM3RDtVQUNKLEtBQUs7QUFFRCxpQkFBSyxzQkFBc0IsYUFBYSwyQkFBMkI7QUFDbkU7VUFFSixLQUFLO1VBQ0wsS0FBSztVQUNMLEtBQUs7VUFDTCxLQUFLO1VBQ0wsS0FBSztVQUNMLEtBQUs7VUFDTCxLQUFLO1VBQ0wsS0FBSztVQUNMO0FBQ0k7O01BRVo7TUFRUSwyQkFBMkIsYUFBcUIsU0FBZTtBQUNuRSxjQUFNLGdCQUFnQixZQUFZLFdBQVcsVUFBVTtBQUV2RCxZQUFJLGVBQWU7QUFDZixnQkFBTSxtQkFBbUIsU0FBUyxNQUFNLGNBQWM7QUFDdEQsY0FBSSxrQkFBa0I7QUFDbEIsaUJBQUssc0JBQXNCLFlBQVksUUFBUSxpQkFBaUIsQ0FBQyxHQUFHLFdBQVcsR0FBRyxXQUFXO0FBQzdGOzs7QUFNUixnQkFBUSxTQUFTO1VBRWIsS0FBSztVQUNMLEtBQUs7VUFDTCxLQUFLO1VBQ0wsS0FBSztVQUNMLEtBQUs7VUFDTCxLQUFLO1VBQ0wsS0FBSztVQUNMLEtBQUs7VUFDTCxLQUFLO1VBQ0wsS0FBSztVQUNMLEtBQUs7VUFDTCxLQUFLO1VBQ0wsS0FBSztVQUNMLEtBQUs7VUFDTCxLQUFLO1VBQ0wsS0FBSztBQUNEO1VBQ0osS0FBSztBQUVELGdCQUFJLEtBQUssZUFBZSxzQkFBc0IsQ0FBQyxVQUFVLE9BQU8sVUFBVSxZQUFZLFVBQVUsTUFBTSxDQUFDLEdBQUc7QUFDdEcsbUJBQUssc0JBQXNCLGFBQWEsT0FBTzs7QUFFbkQ7VUFDSixLQUFLO0FBRUQsa0JBQU0sY0FBYyxZQUFZLFFBQVEsaUJBQWlCLFVBQVU7QUFDbkUsaUJBQUssc0JBQXNCLGFBQWEsYUFBYTtBQUNyRDtVQUNKO0FBRUksZ0JBQUksS0FBSyx3QkFBd0IsbUJBQW1CO0FBRWhELG1CQUFLLGNBQWMsYUFBYSxTQUFTLEtBQUs7QUFDOUM7dUJBQ08sS0FBSyx3QkFBd0IsdUJBQXVCO0FBRTNELG1CQUFLLHNCQUFzQixhQUFhLDJCQUEyQjtBQUNuRTt1QkFDTyxLQUFLLHdCQUF3QixXQUFXO0FBRS9DLG1CQUFLLHNCQUFzQixhQUFhLFNBQVM7QUFDakQ7dUJBQ08sS0FBSyx3QkFBd0IsaUJBQWlCLFlBQVksT0FBTztBQUV4RTt1QkFDTyxLQUFLLHFCQUFxQixTQUFTLFlBQVksS0FBSyxZQUFZLFVBQVU7QUFFakY7dUJBQ08sS0FBSyx3QkFBd0IsbUJBQW1CO0FBRXZEO3VCQUNPLEtBQUssd0JBQXdCLFdBQVcsWUFBWSxVQUFVO0FBR3JFOztBQUdKLGlCQUFLLHNCQUFzQixhQUFhLE9BQU87QUFDL0M7O01BRVo7TUFVUSxjQUFjLEtBQWEsT0FBZSxXQUFrQjtBQUNoRSxlQUFPLEtBQUssY0FBYyxLQUFLLE9BQU8sV0FBVyxLQUFLLFlBQVksTUFBTTtNQUM1RTtNQVdRLGNBQWMsS0FBYSxPQUFlLFdBQW9CLE9BQWE7QUFDL0UsY0FBTSxRQUFRLElBQUksV0FBVTtBQUM1QixjQUFNLFFBQVE7QUFDZCxjQUFNLFlBQVk7QUFDbEIsY0FBTSxNQUFNO0FBQ1osYUFBSyxZQUFZLEtBQUssSUFBSTtBQUMxQixlQUFPO01BQ1g7TUFXUSx3QkFBd0IsTUFBa0IsS0FBZSxLQUFhLFNBQWU7QUFFekYsWUFBSSxRQUFRLEtBQUssY0FBYyxLQUFLLFNBQVMsS0FBSztBQUVsRCxhQUFLLHdCQUF3QixLQUN6QixLQUFLLG1CQUFtQixTQUFTLE1BQU0sR0FBRyxFQUFFLFVBQVU7VUFDbEQsTUFBTSxDQUFDLFVBQWlCO0FBQ3BCLG9CQUFRLEtBQUssY0FBYyxLQUFLLE9BQU8sT0FBTyxLQUFLLFlBQVksUUFBUSxLQUFLLENBQUM7VUFDakY7U0FDSCxDQUFDO01BRVY7TUFPUSxpQkFBaUIsWUFBb0IsYUFBbUI7QUFFNUQsY0FBTSxRQUFRLEtBQUssY0FBYyxJQUFJLElBQUksS0FBSztBQUU5QyxhQUFLLGdCQUFnQixLQUFLLFVBQVUsRUFBRSxVQUFVO1VBQzVDLE1BQU0sQ0FBQyxhQUFvQztBQUV2QyxnQkFBSSxDQUFDLFVBQVUsTUFBTSxTQUFTLENBQUMsVUFBVSxNQUFNLE1BQU07QUFDakQsbUJBQUssWUFBWSxPQUFPLEtBQUssWUFBWSxRQUFRLEtBQUssR0FBRyxDQUFDO21CQUN2RDtBQUVILG1CQUFLLGNBQWMsWUFBWSxRQUFRLGVBQWUsSUFBSSxTQUFTLEtBQUssSUFBSSxhQUFhLEdBQUcsU0FBUyxLQUFLLE9BQU8sT0FBTyxLQUFLLFlBQVksUUFBUSxLQUFLLENBQUM7O1VBRS9KO1VBRUEsT0FBTyxNQUFNLEtBQUssWUFBWSxPQUFPLEtBQUssWUFBWSxRQUFRLEtBQUssR0FBRyxDQUFDO1NBQzFFO01BQ0w7TUFTUSxzQkFBc0IsS0FBYSxnQkFBc0I7QUFDN0QsY0FBTSxNQUFNLGVBQWUsTUFBTSxHQUFHLEVBQUUsS0FBSyxHQUFHO0FBQzlDLFlBQUksSUFBSSxXQUFXLFVBQVUsS0FBSyxLQUFLLGtDQUFrQyxHQUFHLEdBQUc7QUFDM0UsZUFBSyxjQUFjLEtBQUssS0FBSyxrQ0FBa0MsR0FBRyxHQUFHLElBQUk7bUJBQ2xFLEtBQUssc0JBQXNCLEdBQUcsR0FBRztBQUN4QyxlQUFLLGNBQWMsS0FBSyxLQUFLLHNCQUFzQixHQUFHLEdBQUcsSUFBSTtlQUMxRDtBQUVILGVBQUssY0FBYyxLQUFLLGdCQUFnQixLQUFLOztNQUVyRDtNQUtBLHFDQUFrQztBQUU5QixhQUFLLGtCQUFrQixnQ0FBK0IsRUFBRyxVQUFVLENBQUMsZ0JBQWU7QUFDL0UsZUFBSyxrQkFBa0I7UUFDM0IsQ0FBQztNQUNMO01BRUEsZUFBZSxhQUFtQjtBQUM5QixZQUFJLEtBQUssYUFBYTtBQUNsQixlQUFLLGVBQWUsZUFBZSxXQUFXLEVBQUUsVUFBVTtZQUN0RCxNQUFNLE1BQUs7QUFDUCxtQkFBSyxpQkFBaUIsSUFBSSxXQUFXO1lBQ3pDO1lBQ0EsT0FBTyxDQUFDLFVBQTZCLFFBQVEsS0FBSyxjQUFjLEtBQUs7V0FDeEU7ZUFDRTtBQUNILGVBQUssaUJBQWlCLElBQUksV0FBVzs7TUFFN0M7TUFFQSxpQkFBYztBQUNWLGFBQUssb0JBQW9CO01BQzdCO01BRUEsa0JBQWU7QUFDWCxlQUFPLEtBQUssZUFBZSxnQkFBZTtNQUM5QztNQUVBLFNBQU07QUFDRixhQUFLLGVBQWM7QUFDbkIsYUFBSyxPQUFPLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLENBQUMsUUFBTztBQUNyQyxjQUFJLEtBQUs7QUFDTCxpQkFBSyw4QkFBOEIsZ0JBQWU7QUFDbEQsaUJBQUssYUFBYSxPQUFPLElBQUk7O1FBRXJDLENBQUM7TUFDTDtNQUVBLGVBQVk7QUFDUixhQUFLLG9CQUFvQixDQUFDLEtBQUs7TUFDbkM7TUFFQSxjQUFXO0FBQ1AsZUFBTyxLQUFLLGVBQWUsWUFBVztNQUMxQztNQUtBLHNCQUFtQjtBQUNmLGdCQUFRLEtBQUssa0JBQWtCLDJCQUEwQixHQUFJO1VBQ3pELEtBQUssSUFBSTtBQUNMLG1CQUFPOztVQUVYLEtBQUssR0FBRztBQUNKLG1CQUFPOztVQUVYLFNBQVM7QUFDTCxtQkFBTzs7O01BR25CO01BS0EsdUNBQW9DO0FBQ2hDLGFBQUssMEJBQTBCLEtBQUssT0FBTyxPQUFPLEtBQUtBLFFBQU8sQ0FBQyxVQUFpQixpQkFBaUIsYUFBYSxDQUFDLEVBQUUsVUFBVSxDQUFDLFVBQXdCO0FBQ2hKLGNBQUksTUFBTSxJQUFJLFNBQVMsWUFBWSxHQUFHO0FBQ2xDLGlCQUFLLFNBQVM7QUFDZDs7QUFHSixlQUFLLE1BQU0sS0FBSyxZQUFZLFNBQVMsS0FBSyxJQUFJLENBQUMsV0FBVyxPQUFPLElBQUksUUFBUSxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsV0FBVTtBQUNsRyxpQkFBSyxTQUFTLFNBQVMsT0FBTyxNQUFNLElBQUk7QUFDeEMsaUJBQUssZ0JBQWU7VUFDeEIsQ0FBQztRQUNMLENBQUM7TUFDTDtNQU9BLGtCQUFlO0FBQ1gsWUFBSSxLQUFLLHVCQUF1QjtBQUM1Qix1QkFBYSxLQUFLLHFCQUFxQjtBQUN2QyxlQUFLLHdCQUF3Qjs7QUFHakMsWUFDSSxLQUFLLGFBQWEsUUFDbEIsS0FBSyxZQUFZLEtBQUssT0FBTyxLQUFLLFVBQ2xDLENBQUMsS0FBSyxZQUFZLEtBQUssWUFDdkIsQ0FBQyxLQUFLLFlBQVksV0FDbEIsS0FBSyxZQUFZLEtBQUssYUFDdEIsS0FBSyxZQUFZLEtBQUssV0FDdEIsQ0FBQyxLQUFLLFlBQVksV0FDcEI7QUFDRSxnQkFBTSxhQUFhLEtBQUssa0JBQWtCLElBQUc7QUFFN0MsZ0JBQU0sY0FBYyxLQUFLLFlBQVksZUFBZSxLQUFLLFlBQVksS0FBSztBQUMxRSxnQkFBTSwwQkFBMEIsY0FBYyxLQUFLLFlBQVksS0FBSyxVQUFVLElBQUksYUFBYSxTQUFTLElBQUksS0FBSyxZQUFZLEtBQUssU0FBUyxJQUN2SSxLQUFLLFlBQVksS0FBSyxlQUFlLEdBQ3JDLFNBQVM7QUFFYixlQUFLLGVBQWUsV0FBVyxVQUFVLEtBQUssWUFBWSxLQUFLLFdBQVcsc0JBQXNCO0FBRWhHLGdCQUFNLGlCQUFpQixLQUFLLFlBQVksS0FBSyxVQUFVLEtBQUssVUFBVTtBQUN0RSxnQkFBTSxlQUFlLHVCQUF1QixLQUFLLFVBQVU7QUFDM0QsZ0JBQU0sc0JBQXNCLGtCQUFrQixJQUFJLGlCQUFpQjtBQUNuRSxjQUFJLHNCQUFzQixHQUFHO0FBQ3pCLGlCQUFLLHdCQUF3QixXQUFXLEtBQUssZ0JBQWdCLEtBQUssSUFBSSxHQUFHLHNCQUFzQixHQUFHOztlQUVuRztBQUNILGVBQUssZUFBZTs7TUFFNUI7O3lCQW52QlMsa0JBQWUsZ0NBQUEsWUFBQSxHQUFBLGdDQUFBLG9CQUFBLEdBQUEsZ0NBQUEsaUJBQUEsR0FBQSxnQ0FBQSx1QkFBQSxHQUFBLGdDQUFBLHlCQUFBLEdBQUEsZ0NBQUEsY0FBQSxHQUFBLGdDQUFBLGNBQUEsR0FBQSxnQ0FBQSw2QkFBQSxHQUFBLGdDQUFBLGlCQUFBLEdBQUEsZ0NBQUEsV0FBQSxHQUFBLGdDQUFBLG1CQUFBLEdBQUEsZ0NBQUEsd0JBQUEsR0FBQSxnQ0FBQSx3QkFBQSxHQUFBLGdDQUFBLFlBQUEsR0FBQSxnQ0FBQSx1QkFBQSxHQUFBLGdDQUFBLGVBQUEsR0FBQSxnQ0FBQSxtQkFBQSxHQUFBLGdDQUFBLHFCQUFBLEdBQUEsZ0NBQUEsY0FBQSxHQUFBLGdDQUFBLHFCQUFBLEdBQUEsZ0NBQUEsNkJBQUEsR0FBQSxnQ0FBQSxZQUFBLEdBQUEsZ0NBQUEsa0JBQUEsQ0FBQTtNQUFBO2lFQUFmLGtCQUFlLFdBQUEsQ0FBQSxDQUFBLFlBQUEsQ0FBQSxHQUFBLGNBQUEsU0FBQSw2QkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7bUJBQWYsSUFBQSxTQUFBO1VBQVUsR0FBQSxPQUFBLDZCQUFBOzs7O0FDakV2QixVQUFBLHlCQUFBLEdBQUEsd0NBQUEsR0FBQSxHQUFBLGVBQUEsTUFBQSxHQUFBLG9DQUFBO0FBK0ZBLFVBQUEscUJBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUF1QyxVQUFBLHlCQUFBLFNBQUEsU0FBQSw4Q0FBQTtBQUFBLG1CQUFTLElBQUEsZUFBQTtVQUFnQixDQUFBO0FBQzVELFVBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsd0JBQUEsR0FBQSxPQUFBLENBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQXNELFVBQUEscUJBQUEsSUFBQSxTQUFBO0FBQU8sVUFBQSwyQkFBQTtBQUM3RCxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEseUNBQUEsSUFBQSxJQUFBLGVBQUEsTUFBQSxHQUFBLG9DQUFBO0FBUUEsVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsRUFBQTtBQUNKLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsMEJBQUEsQ0FBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSw0QkFBQSxDQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEseUNBQUEsR0FBQSxDQUFBO0FBR0EsVUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBLEVBQUE7QUFPSSxVQUFBLHlCQUFBLFNBQUEsU0FBQSwrQ0FBQTtBQUFBLG1CQUFTLElBQUEsYUFBQTtVQUFjLENBQUE7QUFFdkIsVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEseUNBQUEsSUFBQSxDQUFBLEVBU0MsSUFBQSxnQ0FBQSxHQUFBLEdBQUEsTUFBQSxFQUFBO0FBaUJELFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxnQ0FBQSxLQUFBLElBQUEsTUFBQSxFQUFBO0FBMEhBLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSx5Q0FBQSxJQUFBLENBQUE7QUFpQkosVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLHlDQUFBLEdBQUEsQ0FBQTtBQUdKLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSx5QkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLHlDQUFBLEdBQUEsQ0FBQTtBQThCSixVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsaUJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTs7OztBQXJQOEIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxZQUFBLENBQUEsSUFBQSxXQUFBO0FBR2IsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxPQUFBLDBCQUFBLDJCQUFBO0FBVTBDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsY0FBQSxHQUFBLEVBQXNCLGtCQUFBLElBQUEsZ0JBQUEsQ0FBQSxJQUFBLFVBQUE7QUFDakUsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSxzQkFBQSxJQUFBLFNBQUEsZ0JBQUE7QUFPUixVQUFBLHdCQUFBLEVBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLG9CQUFBLElBQUEsY0FBQSxLQUFBLEVBQUE7QUFhaUIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsTUFBQTtBQUl1QyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLGVBQUEsSUFBQSxpQkFBQTtBQUN6QixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLFlBQUEsSUFBQSxtQkFBQTtBQUMzQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxlQUFBLENBQUEsSUFBQSxlQUFBLEtBQUEsRUFBQTtBQVdLLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsc0JBQUEsOEJBQUEsSUFBQVcsSUFBQSxDQUFBO0FBZ0JBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsc0JBQUEsWUFBQTtBQXlITCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLGVBQUEsSUFBQSxhQUFBLElBQUEsVUFBQSxTQUFBLElBQUEsS0FBQSxFQUFBO0FBa0JKLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxDQUFBLElBQUEsZUFBQSxJQUFBLG1CQUFBLEtBQUEsRUFBQTtBQU9KLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxDQUFBLElBQUEsZ0JBQUEsSUFBQSxlQUFBLElBQUEsWUFBQSxTQUFBLElBQUEsS0FBQSxFQUFBOzs7OztxRkRuUFMsaUJBQWUsRUFBQSxXQUFBLGtCQUFBLENBQUE7SUFBQSxHQUFBO0FBc3ZCNUIsSUFBTSxhQUFOLE1BQWdCO01BQ1o7TUFDQTtNQUNBOzs7Ozs7QUUxekJKLFNBQVMsYUFBQUMsa0JBQXlCOzs7O0FBU2xCLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQW1ELElBQUEscUJBQUEsQ0FBQTtBQUFlLElBQUEsMkJBQUE7QUFDdEUsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQUZjLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEscUNBQUEsZ0JBQUEsa0JBQUEsT0FBQSxXQUFBLEVBQUE7QUFBNkMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxPQUFBLFNBQUE7OztBQVZ2RSxJQWlCYTtBQWpCYjs7QUFDQTs7O0FBZ0JNLElBQU8sc0JBQVAsTUFBTyxxQkFBbUI7TUFJUjtNQUhwQjtNQUNBO01BRUEsWUFBb0IsZ0JBQThCO0FBQTlCLGFBQUEsaUJBQUE7TUFBaUM7TUFFckQsV0FBUTtBQUNKLGFBQUssZUFBZSxlQUFjLEVBQUcsVUFBVSxDQUFDLGdCQUFlO0FBQzNELGNBQUksYUFBYTtBQUNiLGlCQUFLLGNBQWM7QUFDbkIsaUJBQUssWUFBWSxZQUFZO0FBQzdCLGdCQUFJLFlBQVksZ0JBQWdCLFlBQVksWUFBWTtBQUNwRCxtQkFBSyxZQUFZOzs7UUFHN0IsQ0FBQztNQUNMOzt5QkFoQlMsc0JBQW1CLGdDQUFBLGNBQUEsQ0FBQTtNQUFBO2lFQUFuQixzQkFBbUIsV0FBQSxDQUFBLENBQUEsaUJBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDZCQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FBVnhCLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSw0Q0FBQSxHQUFBLENBQUE7QUFLSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxHQUFBLFFBQUE7OztBQU5RLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLFlBQUEsSUFBQSxFQUFBOzs7OztxRkFTQyxxQkFBbUIsRUFBQSxXQUFBLHNCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBQ2ZoQyxJQUVhO0FBRmI7OztBQUVPLElBQU0sY0FBcUI7TUFDOUIsTUFBTTtNQUNOLFdBQVc7TUFDWCxRQUFROzs7Ozs7QUNQWixTQUFTLGFBQUFDLGtCQUF5QjtBQUNsQyxTQUFTLGtCQUFBQyx1QkFBc0I7OztBQUQvQixJQU9hO0FBUGI7OztBQU9NLElBQU8saUJBQVAsTUFBTyxnQkFBYztNQUtIO01BSnBCO01BQ0E7TUFDQTtNQUVBLFlBQW9CLE9BQXFCO0FBQXJCLGFBQUEsUUFBQTtNQUF3QjtNQUU1QyxXQUFRO0FBQ0osYUFBSyxNQUFNLEtBQUssVUFBVSxDQUFDLGNBQWE7QUFDcEMsY0FBSSxVQUFVLFVBQVU7QUFDcEIsaUJBQUssV0FBVyxVQUFVOztBQUU5QixjQUFJLFVBQVUsVUFBVTtBQUNwQixpQkFBSyxXQUFXLFVBQVU7O0FBRTlCLGNBQUksVUFBVSxjQUFjO0FBQ3hCLGlCQUFLLGVBQWUsVUFBVTs7UUFFdEMsQ0FBQztNQUNMOzt5QkFuQlMsaUJBQWMsaUNBQUEsa0JBQUEsQ0FBQTtNQUFBO2tFQUFkLGlCQUFjLFdBQUEsQ0FBQSxDQUFBLFdBQUEsQ0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLGdCQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLGNBQUEsR0FBQSxDQUFBLGdCQUFBLGtCQUFBLEdBQUEsU0FBQSxnQkFBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLGdCQUFBLGtCQUFBLEdBQUEsU0FBQSxnQkFBQSxHQUFBLFFBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSx3QkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1AzQixVQUFBLDhCQUFBLEdBQUEsS0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxNQUFBLENBQUE7QUFBK0IsVUFBQSxzQkFBQSxHQUFBLGFBQUE7QUFBVyxVQUFBLDRCQUFBO0FBRTFDLFVBQUEsc0JBQUEsR0FBQSxrQkFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQWdDLFVBQUEsc0JBQUEsRUFBQTtBQUFrQixVQUFBLDRCQUFBO0FBQ3RELFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQW1GLFVBQUEsc0JBQUEsSUFBQSw2Q0FBQTtBQUEyQyxVQUFBLDRCQUFBO0FBQzlILFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFBbUYsVUFBQSxzQkFBQSxJQUFBLDBCQUFBO0FBQXdCLFVBQUEsNEJBQUE7QUFDL0csVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLElBQUE7OztBQVJpQixVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLFVBQUEsQ0FBQSxJQUFBLFlBQUE7QUFDK0IsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSxJQUFBLFlBQUE7QUFFL0IsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxVQUFBLENBQUEsSUFBQSxRQUFBO0FBQ0EsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxVQUFBLENBQUEsSUFBQSxRQUFBOzs7OztzRkRGSixnQkFBYyxFQUFBLFdBQUEsaUJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFUDNCLFNBQVMsYUFBQUMsa0JBQXlCO0FBQ2xDLFNBQVMsa0JBQUFDLHVCQUFzQjs7O0FBRC9CLElBaUJhO0FBakJiOztBQUVBOzs7O0FBZU0sSUFBTyx5QkFBUCxNQUFPLHdCQUFzQjtNQUtuQjtNQUNBO01BTFo7TUFDQTtNQUVBLFlBQ1ksZ0JBQ0EsZ0JBQThCO0FBRDlCLGFBQUEsaUJBQUE7QUFDQSxhQUFBLGlCQUFBO01BQ1Q7TUFLSCxXQUFRO0FBQ0osYUFBSyxlQUFlLFlBQVksVUFBVSxDQUFDLFdBQVU7QUFDakQsZUFBSyxnQkFBZ0IsT0FBTyxlQUFlO0FBQzNDLGVBQUssZUFBZSxlQUFjLEVBQUcsVUFBVSxDQUFDLGdCQUFlO0FBQzNELGlCQUFLLHdCQUF3QixZQUFZO1VBQzdDLENBQUM7UUFDTCxDQUFDO01BQ0w7O3lCQW5CUyx5QkFBc0IsaUNBQUEsa0JBQUEsR0FBQSxpQ0FBQSxjQUFBLENBQUE7TUFBQTtrRUFBdEIseUJBQXNCLFdBQUEsQ0FBQSxDQUFBLG9CQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLGdCQUFBLHFDQUFBLEdBQUEsZUFBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLFdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLFdBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGdDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FBVjNCLFVBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUEwRixVQUFBLHNCQUFBLEdBQUEsMkRBQUE7QUFBeUQsVUFBQSw0QkFBQTtBQUNuSixVQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLENBQUE7O0FBQStELFVBQUEsOEJBQUEsR0FBQSxRQUFBLENBQUE7QUFBc0MsVUFBQSxzQkFBQSxDQUFBO0FBQW1CLFVBQUEsNEJBQUE7QUFDdkgsVUFBQSxzQkFBQSxHQUFBLGFBQUE7QUFDTCxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsS0FBQTtBQUNJLFVBQUEsc0JBQUEsRUFBQTs7QUFBa0UsVUFBQSw4QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUFvQyxVQUFBLHNCQUFBLEVBQUE7QUFBMkIsVUFBQSw0QkFBQTtBQUNySSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsUUFBQTs7O0FBTlEsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxrQ0FBQSxrQkFBQSwyQkFBQSxHQUFBLEdBQUEsc0NBQUEsR0FBQSxFQUFBO0FBQXFHLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsaUNBQUEsSUFBQSxhQUFBO0FBSXJHLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsa0NBQUEsa0JBQUEsMkJBQUEsSUFBQSxHQUFBLHlDQUFBLEdBQUEsRUFBQTtBQUFzRyxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLElBQUEscUJBQUE7Ozs7O3NGQUlyRyx3QkFBc0IsRUFBQSxXQUFBLHlCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBQ2ZuQyxJQUdhO0FBSGI7OztBQUNBO0FBRU8sSUFBTSxhQUFxQjtNQUM5QjtRQUNJLE1BQU07UUFDTixXQUFXO1FBQ1gsTUFBTTtVQUNGLGFBQWEsQ0FBQTtVQUNiLFdBQVc7OztNQUduQjtRQUNJLE1BQU07UUFDTixXQUFXO1FBQ1gsTUFBTTtVQUNGLGFBQWEsQ0FBQTtVQUNiLFdBQVc7VUFDWCxVQUFVOzs7TUFHbEI7UUFDSSxNQUFNO1FBQ04sV0FBVztRQUNYLE1BQU07VUFDRixhQUFhLENBQUE7VUFDYixXQUFXOzs7Ozs7OztBQzVCdkIsU0FBUyxZQUFBQyxpQkFBZ0I7QUFDekIsU0FBUyxvQkFBNEI7O0FBRHJDLElBT00sZUErSE87QUF0SWI7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsSUFBTSxnQkFBd0IsQ0FBQyxhQUFhLEdBQUcsVUFBVTtBQStIbkQsSUFBTywwQkFBUCxNQUFPLHlCQUF1QjtNQUVaO01BQXBCLFlBQW9CLEdBQStCO0FBQS9CLGFBQUEsSUFBQTtNQUFrQzs7eUJBRjdDLDBCQUF1Qix3QkFBQSw0QkFBQSxDQUFBO01BQUE7aUVBQXZCLHlCQUF1QixDQUFBO3FFQTNINUIsYUFBYSxRQUNUO1FBQ0ksR0FBRztRQUNIO1VBQ0ksTUFBTTtVQUNOLGNBQWMsTUFBTSxPQUFPLDRCQUFzQixFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsa0JBQWtCOztRQUV2RjtVQUNJLE1BQU07VUFDTixjQUFjLE1BQU0sT0FBTyw4QkFBMEIsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLG9CQUFvQjs7UUFFN0Y7VUFDSSxNQUFNO1VBQ04sY0FBYyxNQUFNLE9BQU8sOEJBQTZCLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxvQkFBb0I7O1FBRWhHO1VBQ0ksTUFBTTtVQUNOLGNBQWMsTUFBTSxPQUFPLDhCQUE2QixFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsb0JBQW9COztRQUVoRztVQUNJLE1BQU07VUFDTixjQUFjLE1BQU0sT0FBTyx1Q0FBeUMsRUFBRSxLQUFLLENBQUMsV0FBVyxPQUFPLG9CQUFvQjs7UUFFdEg7VUFDSSxNQUFNO1VBQ04sY0FBYyxNQUFNLE9BQU8sNkNBQTBELEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxpQ0FBaUM7O1FBRTFJO1VBRUksTUFBTTtVQUNOLGNBQWMsTUFBTSxPQUFPLDhDQUE0RCxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsMkJBQTJCOztRQUV0STtVQUNJLE1BQU07VUFDTixjQUFjLE1BQU0sT0FBTyxrREFBbUUsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLHNDQUFzQzs7UUFFeEo7VUFDSSxNQUFNO1VBQ04sY0FBYyxNQUFNLE9BQU8sb0RBQXdFLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxnQ0FBZ0M7O1FBR3ZKO1VBQ0ksTUFBTTtVQUNOLGNBQWMsTUFBTSxPQUFPLDJCQUFxQyxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsaUJBQWlCOztRQUVyRztVQUNJLE1BQU07VUFDTixjQUFjLE1BQU0sT0FBTywyQkFBcUMsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLGlCQUFpQjs7UUFHckc7VUFDSSxNQUFNO1VBQ04sY0FBYyxNQUFNLE9BQU8sd0NBQTBDLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSw2QkFBNkI7O1FBRXRIO1VBQ0ksTUFBTTtVQUNOLGNBQWMsTUFBTSxPQUFPLDZDQUEwRSxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsaUNBQWlDOztRQUUxSjtVQUNJLE1BQU07VUFDTixjQUFjLE1BQU0sT0FBTyxpREFBMkQsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLHFDQUFxQzs7UUFFL0k7VUFDSSxNQUFNO1VBQ04sY0FBYyxNQUFNLE9BQU8sOENBQWdGLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxrQ0FBa0M7O1FBR2pLO1VBQ0ksTUFBTTtVQUNOLGNBQWMsTUFBTSxPQUFPLGdEQUFzRSxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUscUNBQXFDOztRQUUxSjtVQUNJLE1BQU07VUFDTixjQUFjLE1BQU0sT0FBTyw2Q0FBZ0UsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLGtDQUFrQzs7UUFFako7VUFDSSxNQUFNO1VBQ04sY0FBYyxNQUFNLE9BQU8seUNBQXdELEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSw4QkFBOEI7O1FBRXJJO1VBQ0ksTUFBTTtVQUNOLGNBQWMsTUFBTSxPQUFPLHlDQUF3RCxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsOEJBQThCOztRQUVySTtVQUNJLE1BQU07VUFDTixjQUFjLE1BQU0sT0FBTyxnREFBc0UsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLG9DQUFvQzs7UUFFeko7VUFDSSxNQUFNO1VBQ04sY0FBYyxNQUFNLE9BQU8scUNBQXdDLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxtQkFBbUI7O1FBRzFHO1VBQ0ksTUFBTTtVQUNOLGNBQWMsTUFBTSxPQUFPLHlDQUE4QyxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsOEJBQThCOztRQUUzSDtVQUNJLE1BQU07VUFDTixjQUFjLE1BQU0sT0FBTyxzQ0FBc0MsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLDJCQUEyQjs7UUFFaEg7VUFDSSxNQUFNO1VBQ04sY0FBYyxNQUFNLE9BQU8scUNBQXdDLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxtQkFBbUI7O1FBRTFHO1VBQ0ksTUFBTTtVQUNOLGNBQWMsTUFBTSxPQUFPLHVDQUE0QyxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUscUJBQXFCOztRQUVoSDtVQUNJLE1BQU07VUFDTixjQUFjLE1BQU0sT0FBTywwQkFBa0IsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLGdCQUFnQjs7UUFFakY7VUFDSSxNQUFNO1VBQ04sV0FBVztVQUNYLFdBQVc7O1NBR25CLEVBQUUsZUFBZSxPQUFPLHFCQUFxQixTQUFRLENBQUUsR0FHckQsWUFBWSxFQUFBLENBQUE7Ozs7OztBQ3BJMUIsU0FBUyxhQUFBQyxtQkFBeUI7Ozs7O0FDVzFCLElBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBd0IsSUFBQSxzQkFBQSxDQUFBOztBQUFtRSxJQUFBLDRCQUFBO0FBQzNGLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBd0IsSUFBQSxzQkFBQSxDQUFBOztBQUFxRSxJQUFBLDRCQUFBO0FBQzdGLElBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFBd0IsSUFBQSxzQkFBQSxFQUFBOztBQUF5RSxJQUFBLDRCQUFBO0FBQ2pHLElBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFBd0IsSUFBQSxzQkFBQSxFQUFBOztBQUF1RSxJQUFBLDRCQUFBO0FBQ25HLElBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxRQUFBOzs7O0FBTGdDLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsSUFBQSwyQkFBQSxHQUFBLEdBQUEsdUJBQUEsR0FBQSxNQUFBLE9BQUEsV0FBQSxTQUFBO0FBQ0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSxJQUFBLDJCQUFBLEdBQUEsSUFBQSx1QkFBQSxHQUFBLE1BQUEsT0FBQSxhQUFBLFNBQUE7QUFDQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLElBQUEsMkJBQUEsSUFBQSxJQUFBLDBCQUFBLEdBQUEsTUFBQSxPQUFBLGNBQUEsU0FBQTtBQUNBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsSUFBQSwyQkFBQSxJQUFBLElBQUEseUJBQUEsR0FBQSxNQUFBLE9BQUEsZUFBQSxFQUFBOzs7QURmcEMsc0JBU2E7QUFUYjs7QUFDQTtBQUNBOzs7Ozs7O0FBT00sSUFBTyxrQkFBUCxNQUFPLGlCQUFlO01BWUo7TUFYWCxrQkFBa0Isb0RBQW9ELE9BQU87TUFDN0UsbUJBQW1CO01BRTVCO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BRUEsWUFBb0IsZ0JBQThCO0FBQTlCLGFBQUEsaUJBQUE7TUFBaUM7TUFFckQsV0FBUTtBQUNKLGFBQUssZUFBZSxlQUFjLEVBQUcsVUFBVSxDQUFDLGdCQUFlO0FBQzNELGVBQUssVUFBVSxZQUFZO0FBQzNCLGVBQUssWUFBWSxZQUFZLElBQUk7QUFDakMsZUFBSyxjQUFjLFlBQVksSUFBSSxPQUFPLEdBQUc7QUFDN0MsZUFBSyxlQUFlLElBQUksS0FBSyxZQUFZLElBQUksT0FBTyxJQUFJLEVBQUUsWUFBVztBQUNyRSxlQUFLLGdCQUFnQixZQUFZLElBQUksT0FBTyxLQUFLO0FBQ2pELGVBQUssYUFBYSxZQUFZLGNBQWM7QUFDNUMsZUFBSyxlQUFlLFlBQVk7UUFDcEMsQ0FBQztNQUNMO01BRUEsSUFBSSxRQUFRLE1BQVk7QUFDcEIsYUFBSyxRQUNELFlBQ0EsT0FDQTtNQU1SOzt5QkFwQ1Msa0JBQWUsaUNBQUEsY0FBQSxDQUFBO01BQUE7a0VBQWYsa0JBQWUsV0FBQSxDQUFBLENBQUEsWUFBQSxDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxNQUFBLFVBQUEsR0FBQSxVQUFBLGFBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSw0QkFBQSxVQUFBLEdBQUEsQ0FBQSxNQUFBLFNBQUEsZ0JBQUEsV0FBQSxHQUFBLGVBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsYUFBQSxHQUFBLENBQUEsTUFBQSxrQkFBQSxnQkFBQSxpQkFBQSxVQUFBLFVBQUEsR0FBQSxlQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsTUFBQSxpQkFBQSxnQkFBQSxnQkFBQSxVQUFBLFVBQUEsR0FBQSxlQUFBLFFBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxNQUFBLFdBQUEsZ0JBQUEsMkNBQUEsR0FBQSxlQUFBLFFBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxNQUFBLFdBQUEsZ0JBQUEsa0NBQUEsR0FBQSxlQUFBLFFBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsYUFBQSwyQkFBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsV0FBQSxHQUFBLGVBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxnQkFBQSxpQkFBQSxVQUFBLFVBQUEsR0FBQSxlQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsMkNBQUEsR0FBQSxlQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsZ0JBQUEsa0NBQUEsR0FBQSxlQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSx5QkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1Q1QixVQUFBLDhCQUFBLEdBQUEsVUFBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQ0osVUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsS0FBQSxDQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsS0FBQSxDQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsS0FBQSxDQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDBCQUFBLElBQUEseUNBQUEsSUFBQSxFQUFBO0FBUUosVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxJQUFBOzs7QUEvQlcsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxjQUFBLCtCQUFBLElBQUFDLElBQUEsQ0FBQTtBQUdBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsUUFBQSxJQUFBLGtCQUFBLDRCQUFBO0FBQ0EsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxRQUFBLElBQUEsaUJBQUEsNEJBQUE7QUFDQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLGNBQUEsK0JBQUEsSUFBQUMsSUFBQSxDQUFBO0FBQ0EsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxjQUFBLCtCQUFBLElBQUFDLElBQUEsQ0FBQTtBQUVQLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxDQUFBLElBQUEsZ0JBQUEsSUFBQSxhQUFBLEtBQUEsRUFBQTtBQVdPLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsY0FBQSwrQkFBQSxJQUFBRixJQUFBLENBQUE7QUFHQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLFFBQUEsSUFBQSxrQkFBQSw0QkFBQTtBQUdBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsY0FBQSwrQkFBQSxJQUFBQyxJQUFBLENBQUE7QUFHQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLGNBQUEsK0JBQUEsSUFBQUMsSUFBQSxDQUFBOzs7OztzRkRyQkUsaUJBQWUsRUFBQSxXQUFBLGtCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVQ1QixTQUFTLGFBQUFDLGFBQVcsY0FBQUMsYUFBb0IsYUFBQUMsa0JBQWlCO0FBQ3pELFNBQVMsa0JBQUFDLGlCQUE4QyxVQUFBQyxlQUF1QjtBQXVCOUUsU0FBUyxlQUFlLHlCQUFBQyx3QkFBdUIsV0FBVyxXQUFBQyxnQkFBZTs7Ozs7O0FDbkJyRCxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLG9CQUFBOzs7O0FBRmlCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxPQUFBLHFCQUFBOzs7OztBQUlULElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7Ozs7QUFEYSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsUUFBQSxhQUFBOzs7OztBQUVULElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7Ozs7QUFEYSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsUUFBQSxTQUFBOzs7OztBQUhiLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUEsR0FBQSx1RUFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLHVFQUFBLEdBQUEsQ0FBQTs7Ozs7QUFGRCxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsZ0JBQUEsVUFBQSxPQUFBLGlDQUFBLElBQUEsQ0FBQTs7Ozs7QUFZQSxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxNQUFBLEVBQUE7QUFBaUIsSUFBQSxzQkFBQSxDQUFBOztBQUFxRixJQUFBLDRCQUFBO0FBQzFHLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsb0JBQUE7OztBQUZ5QixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDJCQUFBLEdBQUEsR0FBQSw0REFBQSxDQUFBOzs7OztBQUdyQixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxDQUFBO0FBQ0osSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxvQkFBQTs7Ozs7QUFGUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLDhCQUFBLFFBQUEsZ0NBQUEsZUFBQSxHQUFBLHdCQUFBOzs7OztBQVNBLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxzQkFBQSxDQUFBO0FBQThCLElBQUEsNEJBQUE7QUFDeEMsSUFBQSxzQkFBQSxHQUFBLHdCQUFBOzs7O0FBRFUsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxnQkFBQSxPQUFBLElBQUE7Ozs7O0FBRU4sSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSx3QkFBQTs7Ozs7O0FBcENaLElBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUFLLElBQUEsMEJBQUEsU0FBQSxTQUFBLGlFQUFBO0FBQUEsWUFBQSxjQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLE9BQUEsWUFBQTtBQUFBLFlBQUEsa0JBQUEsWUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQTtBQUFTLGNBQUEsbUJBQUEsSUFBQTtBQUFxQixhQUFFLDJCQUFBLFFBQUEsaUJBQUEsZUFBQSxDQUE4QjtJQUFBLENBQUE7QUFDL0QsSUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMEJBQUEsR0FBQSx5REFBQSxHQUFBLENBQUEsRUFJQyxHQUFBLHlEQUFBLEdBQUEsQ0FBQTtBQU9MLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUE4QixJQUFBLDBCQUFBLFNBQUEsU0FBQSxxRUFBQTtBQUFBLFlBQUEsY0FBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxPQUFBLFlBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUE7QUFBQSxhQUFTLDJCQUFBLFFBQUEsbUJBQUEsSUFBQSxDQUFxQjtJQUFBLENBQUE7QUFDeEQsSUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDBCQUFBLElBQUEsMERBQUEsR0FBQSxDQUFBLEVBSUMsSUFBQSwwREFBQSxHQUFBLENBQUE7QUFLRCxJQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxFQUFBO0FBQ0osSUFBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHNCQUFBLEVBQUE7O0FBQ0EsSUFBQSwwQkFBQSxJQUFBLDBEQUFBLEdBQUEsQ0FBQSxFQUVDLElBQUEsMERBQUEsR0FBQSxDQUFBO0FBR0wsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsUUFBQTs7Ozs7QUF0Q1ksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLGdCQUFBLFVBQUEsT0FBQSxtREFBQSxJQUFBLENBQUE7QUFjYSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsT0FBQSxPQUFBO0FBRWIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLGdCQUFBLFVBQUEsT0FBQSxtREFBQSxLQUFBLEVBQUE7QUFVSSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLDBCQUFBLE9BQUEsK0JBQUEsZUFBQSxHQUFBLG9CQUFBO0FBR0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSwwQkFBQSwyQkFBQSxJQUFBLEdBQUEsNEJBQUEsR0FBQSx3QkFBQTtBQUNBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxnQkFBQSxTQUFBLEtBQUEsRUFBQTs7O0FEbENwQixVQStCTSx1Q0FvQk87QUFuRGI7O0FBRUE7QUFDQTtBQWtCQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FBRUEsSUFBTSx3Q0FBd0M7TUFDMUM7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBOztBQVFFLElBQU8sNkJBQVAsTUFBTyw0QkFBMEI7TUFvQnZCO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUExQlosZ0JBQWdDLENBQUE7TUFFaEMsbURBQW1EO01BQ25ELGlDQUFpQztNQUd6QjtNQUVBO01BRVMsd0JBQXdCO01BR3pDLFVBQVVBO01BQ1YsWUFBWTtNQUNaLGdCQUFnQjtNQUNoQix3QkFBd0JEO01BRXhCLFlBQ1kscUJBQ0EsUUFDQSxnQkFDQSw2QkFDQSwyQkFDQSxjQUNBLDBCQUNBLHNCQUEwQztBQVAxQyxhQUFBLHNCQUFBO0FBQ0EsYUFBQSxTQUFBO0FBQ0EsYUFBQSxpQkFBQTtBQUNBLGFBQUEsOEJBQUE7QUFDQSxhQUFBLDRCQUFBO0FBQ0EsYUFBQSxlQUFBO0FBQ0EsYUFBQSwyQkFBQTtBQUNBLGFBQUEsdUJBQUE7TUFDVDtNQUVILFdBQVE7QUFDSixhQUFLLG9CQUFvQix1Q0FBc0MsRUFBRyxVQUFVLENBQUMsaUJBQThCO0FBQ3ZHLGVBQUssZ0JBQWdCLFlBQVk7UUFDckMsQ0FBQztNQUNMO01BTUEsbUJBQW1CLE9BQWE7QUFDNUIsYUFBSyxjQUFjLE9BQU8sT0FBTyxDQUFDO01BQ3RDO01BTUEsaUJBQWlCLGNBQTBCO0FBQ3ZDLGNBQU0sa0JBQWtCLEtBQUssZUFBZSxTQUFTLFlBQVksVUFBVTtBQUMzRSxjQUFNLFNBQVMsS0FBSyxNQUFNLGFBQWEsTUFBTztBQUM5QyxjQUFNLGlCQUFpQixPQUFPO0FBQzlCLGNBQU0sdUJBQXVCLE9BQU87QUFFcEMsWUFBSSxhQUFhLFVBQVUsOENBQThDO0FBQ3JFLGVBQUssMEJBQTBCLHVCQUF1QixPQUFPLFFBQVE7bUJBQzlELGFBQWEsU0FBUyxzQ0FBc0MsU0FBUyxhQUFhLEtBQUssR0FBRztBQUNqRyxnQkFBTSxjQUFzQix5QkFBeUIsOEJBQThCLG9CQUFvQjtBQUN2RyxzQkFBWSxZQUFZLE9BQU87QUFFL0IsZ0JBQU0sa0JBQW1DLHlCQUF5Qix1QkFBdUIsY0FBYztBQUV2RyxjQUFJLG9CQUFvQixVQUFhLG9CQUFvQixrQkFBa0IsS0FBSyxtQ0FBbUMsY0FBYyxHQUFHO0FBQ2hJLGlCQUFLLG9CQUFvQixxQkFBcUIsaUJBQWlCLFdBQVc7aUJBQ3ZFO0FBQ0gsaUJBQUssT0FBTyxTQUFTLGlCQUFpQixFQUFFLFlBQVcsQ0FBRTs7ZUFFdEQ7QUFDSCxlQUFLLE9BQU8sY0FBYyxLQUFLLHdCQUF3QixZQUFZLENBQUM7O01BRTVFO01BUUEsZ0NBQWdDLGNBQTBCO0FBQ3RELGNBQU0sY0FBYyxLQUFLLHFCQUFxQixVQUFVLGFBQWEsS0FBSztBQUMxRSxZQUFJLGFBQWEsU0FBUywwQkFBMEIsR0FBRztBQUNuRCxpQkFBTyxhQUFhLFNBQVM7O0FBRWpDLGVBQU87TUFDWDtNQVFBLCtCQUErQixjQUEwQjtBQUNyRCxlQUFPLEtBQUssb0JBQW9CLCtCQUErQixjQUFjLEtBQUsscUJBQXFCO01BQzNHO01BRVEsd0JBQXdCLGNBQTBCO0FBQ3RELFlBQUksYUFBYSxRQUFRO0FBQ3JCLGdCQUFNLFNBQVMsS0FBSyxNQUFNLGFBQWEsTUFBTTtBQUM3QyxjQUFJLGFBQWEsVUFBVSw4Q0FBOEM7QUFDckUsbUJBQU8sS0FBSyxPQUFPLGNBQWMsQ0FBQyxPQUFPLFVBQVUsT0FBTyxRQUFRLE9BQU8sUUFBUSxPQUFPLElBQUksQ0FBQztxQkFDdEYsYUFBYSxVQUFVLCtCQUErQixPQUFPLFFBQVE7QUFDNUUsbUJBQU8sS0FBSyxPQUFPLGNBQWMsQ0FBQyxPQUFPLFVBQVUsT0FBTyxRQUFRLE9BQU8sUUFBUSxPQUFPLElBQUksT0FBTyxNQUFNLENBQUM7aUJBQ3ZHO0FBQ0gsbUJBQU8sS0FBSyxPQUFPLGNBQWMsQ0FBQyxPQUFPLFVBQVUsT0FBTyxRQUFRLE9BQU8sUUFBUSxPQUFPLEVBQUUsQ0FBQzs7O0FBR25HLGVBQU8sS0FBSyxPQUFPO01BQ3ZCO01BRVEsZ0JBQWdCLGNBQTBCO0FBRTlDLFlBQUksZ0JBQWdCLENBQUMsS0FBSyxjQUFjLEtBQUssQ0FBQyxFQUFFLEdBQUUsTUFBTyxhQUFhLE1BQU0sT0FBTyxhQUFhLEVBQUUsR0FBRztBQUNqRyxjQUFJLGFBQWEsVUFBVSw2QkFBNkI7QUFDcEQsaUJBQUssb0JBQW9CLFlBQVk7QUFDckMsaUJBQUssa0JBQWtCLFlBQVk7O0FBRXZDLGNBQUksYUFBYSxVQUFVLDhDQUE4QztBQUNyRSxpQkFBSyxzREFBc0QsWUFBWTs7QUFFM0UsY0FBSSxhQUFhLFNBQVMsc0NBQXNDLFNBQVMsYUFBYSxLQUFLLEdBQUc7QUFDMUYsZ0JBQUksS0FBSyw0QkFBNEIsZ0NBQWdDLFlBQVksR0FBRztBQUNoRixtQkFBSyx1QkFBdUIsWUFBWTtBQUN4QyxtQkFBSyxrQkFBa0IsY0FBYyxFQUFFOzs7O01BSXZEO01BTVEsdUJBQXVCLGNBQTBCO0FBQ3JELFlBQUksYUFBYSxRQUFRO0FBQ3JCLGdCQUFNLFNBQVMsS0FBSyxNQUFNLGFBQWEsTUFBTTtBQUM3QyxjQUFJLENBQUMsS0FBSyxtQ0FBbUMsT0FBTyxNQUFNLEdBQUc7QUFDekQsaUJBQUssb0JBQW9CLFlBQVk7OztNQUdqRDtNQU1RLG9CQUFvQixjQUEwQjtBQUNsRCxhQUFLLGNBQWMsS0FBSyxZQUFZO0FBQ3BDLG1CQUFXLE1BQUs7QUFDWixjQUFJLEtBQUssaUJBQWlCLGVBQWU7QUFDckMsaUJBQUssZ0JBQWdCLGNBQWMsWUFBWSxLQUFLLGdCQUFnQixjQUFjOztRQUUxRixDQUFDO01BQ0w7TUFNUSxtQ0FBbUMsZ0JBQXNCO0FBQzdELGVBQU8sS0FBSyxPQUFPLElBQUksU0FBUyxXQUFXLGNBQWMsV0FBVztNQUN4RTtNQU9RLG9CQUFvQixjQUEwQjtBQUNsRCxZQUFJLGFBQWEsUUFBUTtBQUNyQixnQkFBTSxTQUFTLEtBQUssTUFBTSxhQUFhLE1BQU07QUFDN0MsaUJBQU8sU0FBUztBQUNoQixpQkFBTyxTQUFTO0FBQ2hCLGdCQUFNLGlDQUFpQztZQUNuQyxRQUFRLEtBQUssVUFBVSxNQUFNOztBQUVqQyxnQkFBTSxlQUFlLEVBQUUsT0FBTyxTQUFTLGFBQWEsU0FBUyxVQUFVLFdBQVcsY0FBYyxVQUFTO0FBQ3pHLGNBQ0ksQ0FBQyxLQUFLLE9BQU8sU0FBUyxLQUFLLHdCQUF3QixZQUFZLEdBQUcsWUFBWSxLQUM5RSxDQUFDLEtBQUssT0FBTyxTQUFTLEtBQUssd0JBQXdCLDhCQUE4QixJQUFJLFNBQVMsWUFBWSxHQUM1RztBQUNFLHlCQUFhLFNBQVMsK0JBQStCO0FBQ3JELGlCQUFLLG9CQUFvQixZQUFZOzs7TUFHakQ7TUFRUSwwQkFBMEIsY0FBMEI7QUFDeEQsWUFBSTtBQUNBLGdCQUFNLFNBQVMsS0FBSyxNQUFNLGFBQWEsTUFBTztBQUM5QyxlQUFLLDBCQUEwQix1QkFBdUIsT0FBTyxVQUFVLE9BQU8sZ0JBQWdCO2lCQUN6RixPQUFPO0FBQ1osZUFBSyxhQUFhLE1BQU0sS0FBSzs7QUFHakMsY0FBTSxlQUFlLEVBQUUsT0FBTyxTQUFTLGFBQWEsU0FBUyxVQUFVLFdBQVcsY0FBYyxVQUFTO0FBQ3pHLFlBQUksYUFBYSxRQUFRLFVBQWEsS0FBSyxPQUFPLFNBQVMsS0FBSyx3QkFBd0IsWUFBWSxHQUFHLFlBQVksR0FBRztBQUNsSCxlQUFLLG9CQUFvQixZQUFZOztNQUU3QztNQU9RLHNEQUFzRCxjQUEwQjtBQUNwRixZQUFJLENBQUMsYUFBYSxRQUFRO0FBQ3RCOztBQUVKLGNBQU0sU0FBUyxLQUFLLE1BQU0sYUFBYSxNQUFNO0FBQzdDLGNBQU0sYUFBYSxPQUFPO0FBRTFCLFlBQUksQ0FBQyxLQUFLLHdCQUF3QjtBQUM5QixlQUFLLHlCQUF5QixLQUFLLHlCQUF5QixtQkFBa0I7QUFDOUUsY0FBSSxDQUFDLEtBQUssd0JBQXdCO0FBRTlCOzs7QUFJUixjQUFNLHFDQUFxQyxLQUFLLHdCQUF3QixLQUFLLENBQUMsdUJBQXVCLHVCQUF1QixVQUFVO0FBQ3RJLFlBQUksb0NBQW9DO0FBQ3BDLGVBQUssMEJBQTBCLFlBQVk7QUFDM0MsZUFBSyxrQkFBa0IsWUFBWTs7TUFFM0M7TUFRUSxrQkFBa0IsY0FBNEIsZUFBZSxJQUFFO0FBQ25FLG1CQUFXLE1BQUs7QUFDWixlQUFLLGdCQUFnQixLQUFLLGNBQWMsT0FBTyxDQUFDLEVBQUUsR0FBRSxNQUFPLE9BQU8sYUFBYSxFQUFFO1FBQ3JGLEdBQUcsZUFBZSxHQUFJO01BQzFCOzt5QkFwUFMsNkJBQTBCLGlDQUFBLG1CQUFBLEdBQUEsaUNBQUEsVUFBQSxHQUFBLGlDQUFBLGtCQUFBLEdBQUEsaUNBQUEsMkJBQUEsR0FBQSxpQ0FBQSx5QkFBQSxHQUFBLGlDQUFBLFlBQUEsR0FBQSxpQ0FBQSx3QkFBQSxHQUFBLGlDQUFBLG9CQUFBLENBQUE7TUFBQTtrRUFBMUIsNkJBQTBCLFdBQUEsQ0FBQSxDQUFBLHdCQUFBLENBQUEsR0FBQSxXQUFBLFNBQUEsaUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7Ozs7Ozs7OztBQ25EdkMsVUFBQSw4QkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLGdDQUFBLEdBQUEsMkNBQUEsSUFBQSxHQUFBLE1BQUEsTUFBQSx3Q0FBQTtBQTBDSixVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxHQUFBLElBQUE7OztBQTNDSSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLElBQUEsYUFBQTs7Ozs7c0ZEa0RTLDRCQUEwQixFQUFBLFdBQUEsNkJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFbkR2QyxTQUFTLGFBQUFFLGFBQVcsUUFBZ0IsYUFBQUMsa0JBQWlCO0FBQ3JELFNBQWlDLGlCQUFBQyxnQkFBZSxpQkFBaUIsaUJBQWlCLFVBQUFDLGVBQWM7QUFLaEcsU0FBUyxnQkFBZ0I7Ozs7O0FDRmpCLElBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsaUJBQUEsQ0FBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxRQUFBOzs7OztBQUVJLElBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsZUFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsUUFBQTs7Ozs7QUFFSSxJQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxlQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLFFBQUE7Ozs7O0FBR0ksSUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxZQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLFFBQUE7OztBRHZCSixJQVlhO0FBWmI7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQU9NLElBQU8sbUJBQVAsTUFBTyxrQkFBZ0I7TUFTYjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BRUE7TUFDQTtNQVZMLGVBQWU7TUFFdEIsWUFDWSxtQkFDQSxRQUNBLGdCQUNBLG9CQUNBLGNBRUFDLFdBQ0EsVUFBbUI7QUFQbkIsYUFBQSxvQkFBQTtBQUNBLGFBQUEsU0FBQTtBQUNBLGFBQUEsaUJBQUE7QUFDQSxhQUFBLHFCQUFBO0FBQ0EsYUFBQSxlQUFBO0FBRUEsYUFBQSxXQUFBQTtBQUNBLGFBQUEsV0FBQTtBQUVSLGFBQUssbUJBQWtCLEVBQUcsS0FBSyxJQUFJO01BQ3ZDO01BRWMscUJBQWtCOztBQUM1QixlQUFLLGVBQWUsZUFBYyxFQUFHLFVBQVUsQ0FBQyxnQkFBZTtBQUUzRCxpQkFBSyxtQkFBbUIsV0FBVyxXQUFXO1VBQ2xELENBQUM7UUFDTDs7TUFFUSxhQUFhLGVBQXFDO0FBQ3RELGNBQU0sUUFBZ0IsY0FBYyxLQUFLLFdBQVcsS0FBSztBQUN6RCxZQUFJLGNBQWMsWUFBWTtBQUMxQixpQkFBTyxLQUFLLGFBQWEsY0FBYyxVQUFVLEtBQUs7O0FBRTFELGVBQU87TUFDWDtNQUVBLFdBQVE7QUFDSixhQUFLLE9BQU8sT0FBTyxVQUFVLENBQUMsVUFBUztBQUNuQyxjQUFJLGlCQUFpQixpQkFBaUI7QUFVbEMsa0JBQU0sd0JBQXdCLEtBQUssbUJBQW1CLE1BQU0sR0FBRztBQUMvRCxnQkFBSSxDQUFDLHlCQUF5QixLQUFLLGNBQWM7QUFFN0MsbUJBQUssU0FBUyxTQUFTLEtBQUssU0FBUyxNQUFNLHdCQUF3Qjt1QkFDNUQseUJBQXlCLENBQUMsS0FBSyxjQUFjO0FBRXBELG1CQUFLLFNBQVMsWUFBWSxLQUFLLFNBQVMsTUFBTSx3QkFBd0I7O0FBRzFFLGlCQUFLLGVBQWU7O0FBRXhCLGNBQUksaUJBQWlCRixnQkFBZTtBQUNoQyxpQkFBSyxrQkFBa0IsWUFBWSxLQUFLLGFBQWEsS0FBSyxPQUFPLFlBQVksU0FBUyxJQUFJLENBQUM7O0FBRS9GLGNBQUksaUJBQWlCLG1CQUFtQixNQUFNLE1BQU0sV0FBVyxLQUFLO0FBRWhFLGlCQUFLLE9BQU8sU0FBUyxDQUFDLE1BQU0sQ0FBQzs7UUFFckMsQ0FBQztBQUVELGFBQUssYUFBYSxXQUFVO01BQ2hDO01BTVEsbUJBQW1CLEtBQVc7QUFDbEMsY0FBTSwrQkFBK0IsSUFBSSxNQUFNLDBFQUEwRTtBQUN6SCxjQUFNLHVCQUF1QixJQUFJLE1BQU0sZ0dBQWdHO0FBQ3ZJLGVBQU8sQ0FBQyxnQ0FBZ0MsQ0FBQztNQUM3Qzs7eUJBL0VTLG1CQUFnQixpQ0FBQSxpQkFBQSxHQUFBLGlDQUFBLFVBQUEsR0FBQSxpQ0FBQSxjQUFBLEdBQUEsaUNBQUEsa0JBQUEsR0FBQSxpQ0FBQSxZQUFBLEdBQUEsaUNBY2IsUUFBUSxHQUFBLGlDQUFBLGNBQUEsQ0FBQTtNQUFBO2tFQWRYLG1CQUFnQixXQUFBLENBQUEsQ0FBQSxVQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsUUFBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsR0FBQSxnQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSwwQkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1o3QixVQUFBLHlCQUFBLEdBQUEsbUJBQUE7QUFDQSxVQUFBLHNCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxpQkFBQTtBQUNBLFVBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSwwQkFBQSxHQUFBLHlDQUFBLEdBQUEsQ0FBQSxFQUlDLEdBQUEseUNBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSx5Q0FBQSxHQUFBLENBQUE7QUFXRCxVQUFBLHlCQUFBLEdBQUEsd0JBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMEJBQUEsSUFBQSwwQ0FBQSxHQUFBLENBQUE7QUFLSixVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLElBQUE7OztBQXRCSSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsSUFBQSxlQUFBLElBQUEsRUFBQTtBQUtBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxJQUFBLGVBQUEsSUFBQSxFQUFBO0FBT0EsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLENBQUEsSUFBQSxlQUFBLElBQUEsRUFBQTtBQUlBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLGVBQUEsS0FBQSxFQUFBOzs7OztzRkRQUyxrQkFBZ0IsRUFBQSxXQUFBLG1CQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVo3QixTQUFTLFlBQUFHLGlCQUFnQjs7QUFBekIsSUFTYTtBQVRiOztBQUNBO0FBQ0E7QUFPTSxJQUFPLG1CQUFQLE1BQU8sa0JBQWdCOzt5QkFBaEIsbUJBQWdCO01BQUE7aUVBQWhCLGtCQUFnQixDQUFBO3FFQUhmLG1CQUFtQixFQUFBLENBQUE7Ozs7OztBQ05qQyxTQUFTLGFBQUFDLGFBQVcsU0FBQUMsY0FBcUI7O0FBQXpDLElBWWE7QUFaYjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7OztBQU9NLElBQU8sc0JBQVAsTUFBTyxxQkFBbUI7TUFTaEI7TUFDQTtNQUNBO01BVFosYUFBYTtNQUViLGdCQUFnQjtNQUVoQjtNQUVBLFlBQ1ksY0FDQSxjQUNBLGNBQTBCO0FBRjFCLGFBQUEsZUFBQTtBQUNBLGFBQUEsZUFBQTtBQUNBLGFBQUEsZUFBQTtNQUNUO01BRUgsV0FBUTtBQUVKLFlBQUksU0FBUyxPQUFPLFFBQVEsWUFBWSxLQUFLLEdBQUc7QUFFNUMsbUJBQVMsU0FBUztBQUNsQixlQUFLLFdBQVU7O01BRXZCO01BRUEsYUFBVTtBQUNOLGFBQUssYUFDQSxXQUFXLEtBQUssVUFBVSxFQUMxQixLQUFLLE1BQUs7QUFDUCxlQUFLLGFBQWEsVUFBVTtZQUN4QixNQUFNO1lBQ04sU0FBUztXQUNaO1FBQ0wsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxVQUE0QjtBQUNoQyxjQUFJLE1BQU0sV0FBVyxLQUFLO0FBRXRCLHFCQUFTLFNBQVM7QUFFbEIsbUJBQU8sU0FBUyxRQUFRLHFCQUFxQjtxQkFDdEMsTUFBTSxXQUFXLEtBQUs7QUFFN0IsZ0JBQUksVUFBVTtBQUNkLGtCQUFNLFVBQVUsTUFBTSxRQUFRLElBQUksb0JBQW9CO0FBQ3RELGdCQUFJLFNBQVM7QUFDVCx5QkFBVyxPQUFPOztBQUV0QixpQkFBSyxhQUFhLFFBQVEsT0FBTzs7UUFFekMsQ0FBQztNQUNUOzt5QkFoRFMsc0JBQW1CLGlDQUFBLFlBQUEsR0FBQSxpQ0FBQSxZQUFBLEdBQUEsaUNBQUEsWUFBQSxDQUFBO01BQUE7a0VBQW5CLHNCQUFtQixXQUFBLENBQUEsQ0FBQSxpQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFlBQUEsY0FBQSxlQUFBLGlCQUFBLGNBQUEsZUFBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsUUFBQSxVQUFBLE1BQUEsZUFBQSxHQUFBLE9BQUEsZUFBQSxVQUFBLEdBQUEsWUFBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsNkJBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNaaEMsVUFBQSw4QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUFrRyxVQUFBLDBCQUFBLFNBQUEsU0FBQSx1REFBQTtBQUFBLG1CQUFTLElBQUEsV0FBQTtVQUFZLENBQUE7QUFDbkgsVUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsTUFBQTtBQUFNLFVBQUEsc0JBQUEsQ0FBQTtBQUErQyxVQUFBLDRCQUFBO0FBQ3pELFVBQUEsc0JBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsR0FBQSxJQUFBOzs7QUFIc0UsVUFBQSwwQkFBQSxZQUFBLENBQUEsSUFBQSxhQUFBO0FBQzVELFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsaUNBQUEsSUFBQSxhQUFBLGVBQUEsYUFBQTs7Ozs7c0ZEV0cscUJBQW1CLEVBQUEsV0FBQSxzQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVaaEMsU0FBMkIsYUFBQUMsYUFBVyxjQUFBQyxhQUFvQixhQUFBQyxrQkFBaUI7QUFDM0UsU0FBUyxnQkFBNkI7QUFDdEMsU0FBUyxrQkFBQUMsa0JBQWdCLFVBQUFDLGVBQWM7QUFnQnZDLFNBQVMsaUJBQUFDLHNCQUFxQjs7Ozs7Ozs7QUNOVixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQXFGLElBQUEsc0JBQUEsR0FBQSxtQ0FBQTtBQUFpQyxJQUFBLDRCQUFBO0FBQzFILElBQUEsc0JBQUEsR0FBQSxvQkFBQTs7O0FBRFMsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxnQkFBQSxxQ0FBQTs7Ozs7QUFHTCxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLG1GQUFBO0FBQ0osSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxvQkFBQTs7OztBQUhTLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsZ0JBQUEsNENBQUEsRUFBNkQsbUJBQUEsK0JBQUEsR0FBQUMsTUFBQSxPQUFBLFdBQUEsQ0FBQTs7Ozs7QUFRdEQsSUFBQSxzQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBbUIsSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQWtCLElBQUEsNEJBQUE7QUFBUSxJQUFBLHNCQUFBLEdBQUEsMkZBQUE7QUFDakQsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTs7Ozs7QUFFSSxJQUFBLHNCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLFFBQUEsRUFBQTs7QUFDSixJQUFBLHNCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLGdDQUFBOzs7O0FBRmMsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxhQUFBLDJCQUFBLEdBQUEsR0FBQSw0QkFBQSwrQkFBQSxHQUFBQyxNQUFBLE9BQUEsMkJBQUEsT0FBQSwwQkFBQSxDQUFBLEdBQUEsNkJBQUE7Ozs7O0FBSVYsSUFBQSxzQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxRQUFBLEVBQUE7O0FBS0osSUFBQSxzQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTs7OztBQUxZLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsYUFBQSwyQkFBQSxHQUFBLEdBQUEsNkNBQUEsK0JBQUEsR0FBQUEsTUFBQSxPQUFBLDJCQUFBLE9BQUEsMEJBQUEsQ0FBQSxHQUFBLDZCQUFBOzs7OztBQXNCUixJQUFBLHNCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUE4QixJQUFBLHNCQUFBLEdBQUEsa0JBQUE7QUFBZ0IsSUFBQSw0QkFBQTtBQUNsRCxJQUFBLHNCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLGdDQUFBOzs7O0FBSFMsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxnQkFBQSxPQUFBLG9CQUFBOzs7Ozs7QUF5QkwsSUFBQSxzQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxTQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQU8sSUFBQSwwQkFBQSxpQkFBQSxTQUFBLG9GQUFBLFFBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUEsQ0FBQTtBQUFBLGFBQUEsMkJBQUEsUUFBQSxvQkFBQSxNQUFBO0lBQUEsQ0FBQTtBQUFQLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQW9FLElBQUEsc0JBQUEsR0FBQSxjQUFBO0FBQVksSUFBQSw0QkFBQTtBQUNwRixJQUFBLHNCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxnQ0FBQTs7OztBQUptQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFdBQUEsUUFBQSxpQkFBQTtBQUNKLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsY0FBQSwrQkFBQSxHQUFBQyxJQUFBLENBQUE7Ozs7O0FBb0JQLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBbUIsSUFBQSx5QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUF3RCxJQUFBLDRCQUFBO0FBQy9FLElBQUEsc0JBQUEsR0FBQSxvQ0FBQTs7OztBQURnQyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsUUFBQSxhQUFBLEVBQXNCLFFBQUEsSUFBQTs7Ozs7QUFRMUQsSUFBQSxzQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTZELElBQUEsc0JBQUEsR0FBQSxnQ0FBQTtBQUE4QixJQUFBLDRCQUFBO0FBQU8sSUFBQSxzQkFBQSxHQUFBLHdDQUFBO0FBQ2xHLElBQUEsOEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBc0csSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQXNCLElBQUEsNEJBQUE7QUFDaEksSUFBQSxzQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSw0QkFBQTs7Ozs7O0FBNUdaLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFDQSxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDBCQUFBLEdBQUEscURBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSxxREFBQSxHQUFBLENBQUE7QUFNRCxJQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUFNLElBQUEsMEJBQUEsVUFBQSxTQUFBLDZEQUFBLFFBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUE7QUFBQSxhQUFVLDJCQUFBLFFBQUEsWUFBQSxNQUFBLENBQW1CO0lBQUEsQ0FBQSxFQUFDLFlBQUEsU0FBQSxpRUFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQTtBQUFBLGFBQWEsMkJBQUEsUUFBQSxNQUFBLENBQU87SUFBQSxDQUFBO0FBQ3BELElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHNCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDBCQUFBLElBQUEsc0RBQUEsR0FBQSxDQUFBLEVBSUMsSUFBQSxzREFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLHNEQUFBLEdBQUEsQ0FBQTtBQWVMLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFtRixJQUFBLHNCQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsNEJBQUE7QUFDeEYsSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLFNBQUEsSUFBQSxFQUFBO0FBRUksSUFBQSwwQkFBQSxpQkFBQSxTQUFBLHNFQUFBLFFBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUE7QUFBQSxhQUFBLDJCQUFBLFFBQUEsV0FBQSxNQUFBO0lBQUEsQ0FBQTs7QUFGSixJQUFBLDRCQUFBO0FBWUEsSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwwQkFBQSxJQUFBLHNEQUFBLEdBQUEsQ0FBQTtBQUtKLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFrRixJQUFBLHNCQUFBLElBQUEsVUFBQTtBQUFRLElBQUEsNEJBQUE7QUFDMUYsSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUNJLElBQUEsMEJBQUEsaUJBQUEsU0FBQSxzRUFBQSxRQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBO0FBQUEsYUFBQSwyQkFBQSxRQUFBLFdBQUEsTUFBQTtJQUFBLENBQUE7O0FBREosSUFBQSw0QkFBQTtBQVNKLElBQUEsc0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxTQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsU0FBQSxFQUFBO0FBQU8sSUFBQSwwQkFBQSxpQkFBQSxTQUFBLHNFQUFBLFFBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUE7QUFBQSxhQUFBLDJCQUFBLFFBQUEsYUFBQSxNQUFBO0lBQUEsQ0FBQTtBQUFQLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsUUFBQSxFQUFBO0FBQTJDLElBQUEsc0JBQUEsSUFBQSxhQUFBO0FBQVcsSUFBQSw0QkFBQTtBQUMxRCxJQUFBLHNCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsMEJBQUEsSUFBQSxzREFBQSxJQUFBLENBQUE7QUFRSixJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFhSSxJQUFBLHNCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDBCQUFBLElBQUEsc0RBQUEsR0FBQSxDQUFBO0FBR0EsSUFBQSw4QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUF3QyxJQUFBLHNCQUFBLElBQUEsV0FBQTtBQUFRLElBQUEsNEJBQUE7QUFDcEQsSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMEJBQUEsSUFBQSxzREFBQSxJQUFBLENBQUE7QUFNQSxJQUFBLDhCQUFBLElBQUEsS0FBQSxFQUFBO0FBQThGLElBQUEsc0JBQUEsSUFBQSwrQkFBQTtBQUE2QixJQUFBLDRCQUFBO0FBQy9ILElBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxZQUFBOzs7OztBQS9HUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsQ0FBQSxPQUFBLGNBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsY0FBQSxJQUFBLEVBQUE7QUFRWSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSx1QkFBQSxDQUFBLE9BQUEsa0JBQUEsS0FBQSxFQUFBO0FBS0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsZ0NBQUEsT0FBQSwwQkFBQSxLQUFBLENBQUEsT0FBQSxrQkFBQSxLQUFBLEVBQUE7QUFLQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxnQ0FBQSxPQUFBLGtCQUFBLEtBQUEsRUFBQTtBQXFCSSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLHFDQUFBLGVBQUEsMkJBQUEsSUFBQSxJQUFBLGtDQUFBLENBQUE7QUFQQSxJQUFBLDBCQUFBLFdBQUEsT0FBQSxRQUFBLEVBQXNCLGtCQUFBLCtCQUFBLElBQUFDLElBQUEsQ0FBQSxFQUFBLFdBQUEsT0FBQSxvQkFBQTtBQVUxQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQSxXQUFBLElBQUEsU0FBQSxJQUFBLFdBQUEsS0FBQSxFQUFBO0FBY0ksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxxQ0FBQSxlQUFBLDJCQUFBLElBQUEsSUFBQSxpQ0FBQSxDQUFBO0FBTEEsSUFBQSwwQkFBQSxXQUFBLE9BQUEsUUFBQTtBQVlXLElBQUEseUJBQUEsRUFBQTtBQUFBLElBQUEsMEJBQUEsV0FBQSxPQUFBLFVBQUE7QUFJZixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxxQkFBQSxLQUFBLEVBQUE7QUFXSSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFlBQUEsT0FBQSxxQkFBQSxDQUFBLE9BQUEscUJBQUEsT0FBQSxzQkFBQSxDQUFBLE9BQUEsWUFBQSxPQUFBLFNBQUEsU0FBQSxPQUFBLHVCQUFBLENBQUEsT0FBQSxZQUFBLE9BQUEsU0FBQSxTQUFBLE9BQUEsbUJBQUE7QUFZQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxvQkFBQSxLQUFBLEVBQUE7QUFRUixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSx3QkFBQSxLQUFBLEVBQUE7Ozs7O0FBWVosSUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBNkUsSUFBQSxzQkFBQSxHQUFBLElBQUE7QUFBRSxJQUFBLDRCQUFBO0FBQy9FLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBdUUsSUFBQSxzQkFBQSxHQUFBLElBQUE7QUFBRSxJQUFBLDRCQUFBO0FBQzdFLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsWUFBQTs7Ozs7QUFNZ0IsSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUErRSxJQUFBLHNCQUFBLEdBQUEsb0NBQUE7QUFBa0MsSUFBQSw0QkFBQTtBQUNySCxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7OztBQURTLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsZ0JBQUEsK0JBQUE7Ozs7O0FBR0wsSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUtJLElBQUEsc0JBQUEsR0FBQSx5RUFBQTtBQUNKLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7Ozs7QUFOUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGdCQUFBLHVDQUFBLEVBQXdELG1CQUFBLCtCQUFBLEdBQUFDLE1BQUEsUUFBQSxZQUFBLE1BQUEsb0JBQUEsQ0FBQTs7Ozs7O0FBVXBELElBQUEsc0JBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUFPLElBQUEsMEJBQUEsaUJBQUEsU0FBQSxvRkFBQSxRQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBLENBQUE7QUFBQSxhQUFBLDJCQUFBLFFBQUEsb0JBQUEsTUFBQTtJQUFBLENBQUE7QUFBUCxJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUFvRSxJQUFBLHNCQUFBLEdBQUEsY0FBQTtBQUFZLElBQUEsNEJBQUE7QUFDcEYsSUFBQSxzQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsZ0NBQUE7Ozs7QUFKbUIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxXQUFBLFFBQUEsaUJBQUE7QUFDSixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGNBQUEsK0JBQUEsR0FBQUYsSUFBQSxDQUFBOzs7OztBQXJCL0IsSUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUNBLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBLEdBQUEscURBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSxxREFBQSxHQUFBLENBQUE7QUFVRCxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsMEJBQUEsSUFBQSxzREFBQSxJQUFBLENBQUE7QUFRSixJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLG1CQUFBLEVBQUE7QUFNSixJQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsWUFBQTs7OztBQWhDWSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsQ0FBQSxPQUFBLFlBQUEsTUFBQSx1QkFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxZQUFBLE1BQUEsdUJBQUEsSUFBQSxFQUFBO0FBV1EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEscUJBQUEsS0FBQSxFQUFBO0FBVUEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxpQkFBQSxDQUFBLE9BQUEsc0JBQUEsT0FBQSxpQkFBQSxFQUEwRCxjQUFBLE9BQUEsVUFBQSxFQUFBLGdCQUFBLE9BQUEsWUFBQSxLQUFBOzs7QUQ3SnRGLGtDQXlCYTtBQXpCYjs7QUFNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7OztBQVFNLElBQU8sZ0JBQVAsTUFBTyxlQUFhO01BcUNWO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BaERaLHNCQUFzQjtNQUN0QixzQkFBc0I7TUFDdEIsc0JBQXNCO01BQ3RCLHlCQUF5QjtNQUN6QjtNQUNBO01BQ0E7TUFDQSxhQUFhO01BRWIscUJBQXFCO01BQ3JCLG9CQUFvQjtNQUNwQjtNQUNBLGtCQUFrQjtNQUNsQjtNQUNBLHdCQUF3QjtNQUN4QiwwQkFBMEI7TUFDMUIsVUFBVTtNQUNWLHFCQUFxQjtNQUdyQix1QkFBdUI7TUFDdkIsdUJBQXVCO01BQ3ZCO01BRUEsK0JBQStCO01BQy9CO01BQ0E7TUFFQSxvQkFBb0I7TUFFcEIsY0FBdUM7TUFHdkMsZ0JBQWdCSDtNQUVoQixZQUNZLFFBQ0EsZ0JBQ0EsZ0JBQ0EsY0FDQSxxQkFDQSxZQUNBLFVBQ0EsY0FDQSxtQkFDQSx1QkFDQSxjQUNBLGdCQUNBLGNBQTBCO0FBWjFCLGFBQUEsU0FBQTtBQUNBLGFBQUEsaUJBQUE7QUFDQSxhQUFBLGlCQUFBO0FBQ0EsYUFBQSxlQUFBO0FBQ0EsYUFBQSxzQkFBQTtBQUNBLGFBQUEsYUFBQTtBQUNBLGFBQUEsV0FBQTtBQUNBLGFBQUEsZUFBQTtBQUNBLGFBQUEsb0JBQUE7QUFDQSxhQUFBLHdCQUFBO0FBQ0EsYUFBQSxlQUFBO0FBQ0EsYUFBQSxpQkFBQTtBQUNBLGFBQUEsZUFBQTtNQUNUO01BRUgsV0FBUTtBQUNKLGFBQUssZUFBZSxlQUFjLEVBQUcsVUFBVSxDQUFDLGdCQUFlO0FBQzNELGNBQUksYUFBYTtBQUNiLGlCQUFLLDBCQUEwQixXQUFXOztRQUVsRCxDQUFDO0FBQ0QsYUFBSyxlQUFlLFNBQVEsRUFBRyxLQUFLLENBQUMsU0FBUTtBQUN6QyxlQUFLLG9CQUFvQixJQUFLO0FBRzlCLGNBQUksQ0FBQyxNQUFNO0FBQ1AsaUJBQUssVUFBVTs7UUFFdkIsQ0FBQztBQUNELGFBQUssOEJBQTZCO0FBRWxDLGNBQU0sb0JBQW9CLEtBQUssZUFBZSw2QkFBNEI7QUFDMUUsWUFBSSxtQkFBbUI7QUFDbkIsZUFBSyxXQUFXOztNQUV4QjtNQU1RLDBCQUEwQixhQUF3QjtBQUN0RCxhQUFLLGNBQWM7QUFFbkIsWUFBSSxZQUFZLGVBQWUsU0FBUyxNQUFNLEdBQUc7QUFDN0MsZUFBSyw0QkFBNEIsWUFBWTtBQUM3QyxlQUFLLDZCQUE2QixZQUFZO0FBQzlDLGNBQUksWUFBWSw0QkFBNEI7QUFDeEMsaUJBQUssdUJBQXVCLElBQUksT0FBTyxZQUFZLDBCQUEwQjs7ZUFFOUU7QUFFSCxlQUFLLCtCQUErQjs7QUFHeEMsYUFBSyxjQUFjLFlBQVk7QUFDL0IsWUFBSSxLQUFLLGdCQUFnQixPQUFPO0FBQzVCLGVBQUssdUJBQXVCOztBQUdoQyxhQUFLLHdCQUF3QixDQUFDLENBQUMsWUFBWTtBQUMzQyxhQUFLLHFCQUFxQixDQUFDLENBQUMsWUFBWTtBQUN4QyxhQUFLLGVBQWUsWUFBWSxVQUFVLENBQUMsV0FBVTtBQUVqRCxnQkFBTSxvQkFBb0IsT0FBTyxlQUFlLGVBQWU7QUFDL0QsZUFBSywwQkFBMEIsQ0FBQyxDQUFDLEtBQUssYUFBYSxTQUFTLEtBQUssWUFBWSxNQUFNLHlCQUF5QixDQUFDO1FBQ2pILENBQUM7TUFDTDtNQUVBLGdDQUE2QjtBQUN6QixjQUFNLGVBQWUsS0FBSyxhQUFhLFVBQVUseUJBQXlCLE1BQUs7QUFFM0UsZUFBSyxhQUFhLFFBQVEsWUFBWTtBQUV0QyxlQUFLLGVBQWUsU0FBUSxFQUFHLEtBQUssQ0FBQyxTQUFRO0FBQ3pDLGlCQUFLLG9CQUFvQixJQUFLO1VBQ2xDLENBQUM7UUFDTCxDQUFDO01BQ0w7TUFFQSxxQkFBa0I7QUFFZCxZQUFJLEtBQUssc0JBQXNCLEtBQUssU0FBUztBQUN6Qzs7QUFJSixjQUFNLGNBQWMsS0FBSyxTQUFTLGtCQUFrQixLQUFLLDBCQUEwQixpQkFBaUIsYUFBYSxJQUFJO0FBQ3JILFlBQUksYUFBYTtBQUNiLHNCQUFZLE1BQUs7QUFDakIsZUFBSyxxQkFBcUI7O0FBSTlCLFlBQUksS0FBSyxhQUFhLHNCQUFxQixHQUFJO0FBQzNDLGVBQUssYUFBYSxNQUFNLDRCQUE0Qjs7TUFFNUQ7TUFFQSxRQUFLO0FBQ0QsYUFBSyxvQkFBb0I7QUFDekIsYUFBSyxhQUNBLE1BQU07VUFDSCxVQUFVLEtBQUs7VUFDZixVQUFVLEtBQUs7VUFDZixZQUFZLEtBQUs7U0FDcEIsRUFDQSxLQUFLLE1BQU0sS0FBSyxtQkFBa0IsQ0FBRSxFQUNwQyxNQUFNLENBQUMsVUFBNEI7QUFFaEMsZUFBSyxrQkFBa0IsTUFBTSxRQUFRLElBQUksb0JBQW9CLE1BQU07QUFDbkUsZUFBSyxzQkFBc0I7QUFDM0IsZUFBSztRQUNULENBQUMsRUFDQSxRQUFRLE1BQU8sS0FBSyxvQkFBb0IsS0FBTTtNQUN2RDtNQUtRLHFCQUFrQjtBQUN0QixhQUFLLHNCQUFzQjtBQUMzQixhQUFLLHlCQUF5QjtBQUM5QixhQUFLLGtCQUFrQjtBQUV2QixZQUFJLEtBQUssT0FBTyxRQUFRLGVBQWUsZ0JBQWdCLEtBQUssS0FBSyxPQUFPLEdBQUcsS0FBSyxhQUFhLEtBQUssS0FBSyxPQUFPLEdBQUcsR0FBRztBQUNoSCxlQUFLLE9BQU8sU0FBUyxDQUFDLEVBQUUsQ0FBQzs7QUFHN0IsYUFBSyxhQUFhLFVBQVU7VUFDeEIsTUFBTTtVQUNOLFNBQVM7U0FDWjtBQUVELGFBQUssaUJBQWdCO01BQ3pCO01BS1EsbUJBQWdCO0FBQ3BCLFlBQUksQ0FBQyxTQUFTO0FBQ1Y7O0FBR0osY0FBTSxXQUF3QixLQUFLLGFBQWEsS0FBSyxnQ0FBNkMsRUFBRSxNQUFNLE1BQU0sVUFBVSxTQUFRLENBQUU7QUFDcEksaUJBQVMsa0JBQWtCLE9BQU87QUFDbEMsaUJBQVMsa0JBQWtCLFFBQVE7QUFDbkMsaUJBQVMsT0FBTyxLQUNaLE1BQU0sS0FBSyxzQkFBc0IsTUFBTSxLQUFLLFVBQVUsS0FBSyxRQUFRLEdBQ25FLE1BQUs7UUFBRSxDQUFDO01BRWhCO01BRUEsb0JBQW9CLFNBQWE7QUFDN0IsYUFBSyxVQUFVO0FBQ2YsWUFBSSxTQUFTO0FBR1QsZ0JBQU0sV0FBVyxLQUFLLG9CQUFvQixPQUFNO0FBQ2hELGNBQUksWUFBWSxhQUFhLElBQUk7QUFDN0IsaUJBQUssb0JBQW9CLFNBQVMsRUFBRTtBQUNwQyxpQkFBSyxPQUFPLGNBQWMsUUFBUTtpQkFDL0I7QUFDSCxpQkFBSyxPQUFPLFNBQVMsQ0FBQyxTQUFTLENBQUM7OztNQUc1QztNQUVBLGtCQUFlO0FBQ1gsZUFBTyxLQUFLLGVBQWUsZ0JBQWU7TUFDOUM7TUFFQSxZQUFZLE9BQVU7QUFDbEIsWUFBSSxNQUFNLFVBQVUsTUFBTSxPQUFPLFNBQVMsWUFBWTtBQUNsRCxlQUFLLFdBQVcsTUFBTSxPQUFPOztBQUVqQyxZQUFJLE1BQU0sVUFBVSxNQUFNLE9BQU8sU0FBUyxZQUFZO0FBQ2xELGVBQUssV0FBVyxNQUFNLE9BQU87O01BRXJDOzt5QkF6TlMsZ0JBQWEsaUNBQUEsVUFBQSxHQUFBLGlDQUFBLGtCQUFBLEdBQUEsaUNBQUEsY0FBQSxHQUFBLGlDQUFBLFlBQUEsR0FBQSxpQ0FBQSxtQkFBQSxHQUFBLGlDQUFBLGVBQUEsR0FBQSxpQ0FBQSxjQUFBLEdBQUEsaUNBQUEsWUFBQSxHQUFBLGlDQUFBLGlCQUFBLEdBQUEsaUNBQUEscUJBQUEsR0FBQSxpQ0FBQSxZQUFBLEdBQUEsaUNBQUEsY0FBQSxHQUFBLGlDQUFBLFlBQUEsQ0FBQTtNQUFBO2tFQUFiLGdCQUFhLFdBQUEsQ0FBQSxDQUFBLFVBQUEsQ0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxtQkFBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGVBQUEsYUFBQSxHQUFBLENBQUEsZ0JBQUEsWUFBQSxHQUFBLENBQUEsZ0JBQUEsaUJBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsZUFBQSxRQUFBLHdCQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsVUFBQSxZQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsUUFBQSxhQUFBLFFBQUEsUUFBQSxHQUFBLFFBQUEsR0FBQSxVQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsT0FBQSxZQUFBLGdCQUFBLHdCQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLGdCQUFBLFlBQUEsTUFBQSxZQUFBLFFBQUEsWUFBQSxRQUFBLFFBQUEsR0FBQSxnQkFBQSxHQUFBLFdBQUEsa0JBQUEsV0FBQSxlQUFBLGVBQUEsR0FBQSxDQUFBLGdCQUFBLFNBQUEsR0FBQSxDQUFBLE9BQUEsWUFBQSxnQkFBQSx1QkFBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxnQkFBQSxvQkFBQSxNQUFBLFlBQUEsUUFBQSxZQUFBLFFBQUEsWUFBQSxHQUFBLGdCQUFBLEdBQUEsV0FBQSxlQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsT0FBQSxjQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLFdBQUEsSUFBQSxNQUFBLGNBQUEsUUFBQSxjQUFBLFFBQUEsWUFBQSxHQUFBLG9CQUFBLEdBQUEsV0FBQSxlQUFBLEdBQUEsQ0FBQSxnQkFBQSx1QkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxNQUFBLGdCQUFBLFFBQUEsVUFBQSxHQUFBLE9BQUEsZUFBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLGdCQUFBLG1CQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLGdCQUFBLHlCQUFBLGNBQUEseUJBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZUFBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxlQUFBLEdBQUEsZ0JBQUEsaUJBQUEsR0FBQSxDQUFBLGdCQUFBLDZCQUFBLEdBQUEsU0FBQSxnQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxjQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLGdCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsT0FBQSxHQUFBLENBQUEsT0FBQSxlQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLFdBQUEsSUFBQSxNQUFBLGVBQUEsUUFBQSxlQUFBLFFBQUEsWUFBQSxHQUFBLG9CQUFBLEdBQUEsV0FBQSxlQUFBLEdBQUEsQ0FBQSxnQkFBQSwwQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLE1BQUEsR0FBQSxDQUFBLGdCQUFBLHlDQUFBLEdBQUEsQ0FBQSxnQkFBQSxzQ0FBQSxjQUFBLG9CQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLFlBQUEsUUFBQSxPQUFBLEdBQUEsQ0FBQSxnQkFBQSxpQkFBQSxHQUFBLFVBQUEsY0FBQSxrQkFBQSxHQUFBLENBQUEsZ0JBQUEsaUJBQUEsR0FBQSxhQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsVUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsVUFBQSxlQUFBLHNCQUFBLHdCQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLFVBQUEsZUFBQSxzQkFBQSwwQkFBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsZUFBQSxHQUFBLGlCQUFBLGNBQUEsY0FBQSxHQUFBLENBQUEsUUFBQSxZQUFBLEdBQUEsb0JBQUEsR0FBQSxXQUFBLGVBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSx1QkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ3pCMUIsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxNQUFBLENBQUE7QUFBOEIsVUFBQSxzQkFBQSxHQUFBLHFCQUFBO0FBQW1CLFVBQUEsNEJBQUE7QUFDakQsVUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUE2QyxVQUFBLHNCQUFBLElBQUEsK0NBQUE7QUFBNkMsVUFBQSw0QkFBQTtBQUM5RixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMEJBQUEsSUFBQSx1Q0FBQSxJQUFBLEVBQUEsRUFrSEMsSUFBQSx1Q0FBQSxJQUFBLENBQUEsRUFBQSxJQUFBLHVDQUFBLElBQUEsQ0FBQTtBQTRDTCxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLElBQUE7OztBQXhLSyxVQUFBLDBCQUFBLFVBQUEsSUFBQSxXQUFBLElBQUEsT0FBQTtBQVFHLFVBQUEseUJBQUEsRUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxDQUFBLElBQUEsMEJBQUEsS0FBQSxFQUFBO0FBbUhBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxDQUFBLElBQUEsMkJBQUEsQ0FBQSxFQUFBLElBQUEsZUFBQSxPQUFBLE9BQUEsSUFBQSxZQUFBLFNBQUEsS0FBQSxFQUFBO0FBTUEsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLENBQUEsRUFBQSxJQUFBLGVBQUEsT0FBQSxPQUFBLElBQUEsWUFBQSxTQUFBLEtBQUEsRUFBQTs7Ozs7c0ZEeEdLLGVBQWEsRUFBQSxXQUFBLGdCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRXhCMUIsSUFFYTtBQUZiOzs7QUFFTyxJQUFNLGFBQW9CO01BQzdCLE1BQU07TUFDTixXQUFXO01BQ1gsTUFBTTtRQUNGLGFBQWEsQ0FBQTtRQUNiLFdBQVc7Ozs7Ozs7QUNSbkIsU0FBUyxZQUFBTSxpQkFBZ0I7QUFDekIsU0FBUyxnQkFBQUMscUJBQW9COztBQUQ3QixJQVdhO0FBWGI7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFNTSxJQUFPLG9CQUFQLE1BQU8sbUJBQWlCOzt5QkFBakIsb0JBQWlCO01BQUE7aUVBQWpCLG1CQUFpQixDQUFBO3FFQUhoQixxQkFBcUJBLGNBQWEsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUEsQ0FBQTs7Ozs7O0FDUnRFLFNBQVMsYUFBQUMsbUJBQXlCO0FBR2xDLFNBQXVCLE9BQUFDLFlBQVc7Ozs7QUNJdEIsSUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQ0EsSUFBQSxzQkFBQSxDQUFBOztBQUNKLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsQ0FBQTtBQUFzQixJQUFBLDRCQUFBO0FBQzlCLElBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsWUFBQTs7OztBQUpZLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsMEJBQUEsMkJBQUEsR0FBQSxHQUFBLHlEQUFBLEdBQUEsb0JBQUE7QUFFQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLE9BQUEsWUFBQSxJQUFBOzs7OztBQUlSLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUNBLElBQUEsc0JBQUEsQ0FBQTs7QUFDSixJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLENBQUE7QUFBdUIsSUFBQSw0QkFBQTtBQUMvQixJQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLFlBQUE7Ozs7QUFKWSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLDBCQUFBLDJCQUFBLEdBQUEsR0FBQSxzREFBQSxHQUFBLG9CQUFBO0FBRUEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxPQUFBLFlBQUEsS0FBQTs7Ozs7QUFJUixJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFDQSxJQUFBLHNCQUFBLENBQUE7O0FBQ0osSUFBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxDQUFBO0FBQXVCLElBQUEsNEJBQUE7QUFDL0IsSUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxZQUFBOzs7O0FBSlksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSwwQkFBQSwyQkFBQSxHQUFBLEdBQUEsc0RBQUEsR0FBQSxvQkFBQTtBQUVBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsT0FBQSxZQUFBLEtBQUE7Ozs7O0FBSVIsSUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQ0EsSUFBQSxzQkFBQSxDQUFBOztBQUNKLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsQ0FBQTtBQUEyQyxJQUFBLDRCQUFBO0FBQ25ELElBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsWUFBQTs7OztBQUpZLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsMEJBQUEsMkJBQUEsR0FBQSxHQUFBLG1FQUFBLEdBQUEsb0JBQUE7QUFFQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLE9BQUEsWUFBQSx5QkFBQTs7Ozs7QUFJUixJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFDQSxJQUFBLHNCQUFBLENBQUE7O0FBQ0osSUFBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxDQUFBOztBQUEyQyxJQUFBLDRCQUFBO0FBQ25ELElBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsWUFBQTs7OztBQUpZLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsMEJBQUEsMkJBQUEsR0FBQSxHQUFBLDhEQUFBLEdBQUEsb0JBQUE7QUFFQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDJCQUFBLElBQUEsR0FBQSxPQUFBLFlBQUEsV0FBQSxDQUFBOzs7OztBQTNDaEIsSUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDBCQUFBLEdBQUEsa0VBQUEsSUFBQSxDQUFBLEVBUUMsR0FBQSxrRUFBQSxJQUFBLENBQUEsRUFBQSxHQUFBLGtFQUFBLElBQUEsQ0FBQSxFQUFBLEdBQUEsa0VBQUEsSUFBQSxDQUFBLEVBQUEsR0FBQSxrRUFBQSxJQUFBLENBQUE7QUFxQ0wsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxJQUFBOzs7O0FBOUNRLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLFlBQUEsT0FBQSxJQUFBLEVBQUE7QUFTQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxZQUFBLFFBQUEsSUFBQSxFQUFBO0FBU0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsWUFBQSxRQUFBLElBQUEsRUFBQTtBQVNBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLFlBQUEsNEJBQUEsSUFBQSxFQUFBO0FBU0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsWUFBQSxjQUFBLElBQUEsRUFBQTs7O0FEMUNSLElBVWE7QUFWYjs7QUFFQTs7OztBQVFNLElBQU8sOEJBQVAsTUFBTyw2QkFBMkI7TUFLaEI7TUFKcEI7TUFFUTtNQUVSLFlBQW9CLGdCQUE4QjtBQUE5QixhQUFBLGlCQUFBO01BQWlDO01BRXJELFdBQVE7QUFDSixhQUFLLHdCQUF3QixLQUFLLGVBQzdCLHVCQUFzQixFQUN0QixLQUFLQSxLQUFJLENBQUMsU0FBZ0IsS0FBSyxjQUFjLElBQUssQ0FBQyxFQUNuRCxVQUFTO01BQ2xCOzt5QkFaUyw4QkFBMkIsaUNBQUEsY0FBQSxDQUFBO01BQUE7a0VBQTNCLDhCQUEyQixXQUFBLENBQUEsQ0FBQSx5QkFBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLGNBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHFDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDVnhDLFVBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFDQSxVQUFBLHNCQUFBLENBQUE7O0FBQ0osVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSwwQkFBQSxHQUFBLG9EQUFBLEdBQUEsQ0FBQTs7O0FBRkksVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxrQ0FBQSxVQUFBLDJCQUFBLEdBQUEsR0FBQSw0Q0FBQSxHQUFBLElBQUE7QUFFSixVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsSUFBQSxjQUFBLElBQUEsRUFBQTs7Ozs7c0ZETWEsNkJBQTJCLEVBQUEsV0FBQSw4QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVWeEMsU0FBUyxhQUFBQyxtQkFBaUI7QUFDMUIsU0FBUyxVQUFBQyxlQUFjOzs7Ozs7QUNRSyxJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXVCLElBQUEsc0JBQUEsQ0FBQTtBQUFzQixJQUFBLDRCQUFBO0FBQ2pELElBQUEsc0JBQUEsR0FBQSw0QkFBQTs7OztBQUQyQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLE9BQUEsWUFBQSxJQUFBOzs7OztBQUYvQixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMEJBQUEsR0FBQSxzRUFBQSxHQUFBLENBQUE7QUFHQSxJQUFBLHlCQUFBLEdBQUEsSUFBQTtBQUNBLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBaUIsSUFBQSxzQkFBQSxDQUFBO0FBQXVCLElBQUEsNEJBQUE7QUFDNUMsSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxvQkFBQTs7OztBQU5RLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLFlBQUEsT0FBQSxJQUFBLEVBQUE7QUFJaUIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxPQUFBLFlBQUEsS0FBQTs7O0FEWnpDLElBYWE7QUFiYjs7QUFFQTtBQUNBOzs7QUFVTSxJQUFPLGlDQUFQLE1BQU8sd0NBQXVDLDRCQUEyQjtNQUUzRSxTQUFTQTtNQUVULFlBQVksZ0JBQThCO0FBQ3RDLGNBQU0sY0FBYztNQUN4Qjs7eUJBTlMsaUNBQThCLGlDQUFBLGNBQUEsQ0FBQTtNQUFBO2tFQUE5QixpQ0FBOEIsV0FBQSxDQUFBLENBQUEsbUJBQUEsQ0FBQSxHQUFBLFVBQUEsQ0FBQSx5Q0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLE1BQUEsVUFBQSxRQUFBLE1BQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxNQUFBLGtCQUFBLEdBQUEsY0FBQSxXQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsWUFBQSxTQUFBLEdBQUEsQ0FBQSxjQUFBLFdBQUEsb0JBQUEsVUFBQSxHQUFBLG1CQUFBLE9BQUEscUJBQUEsR0FBQSxDQUFBLGNBQUEsaUJBQUEsb0JBQUEsVUFBQSxHQUFBLG1CQUFBLE9BQUEscUJBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxXQUFBLEdBQUEsQ0FBQSxNQUFBLGtCQUFBLEdBQUEsQ0FBQSxNQUFBLE9BQUEsR0FBQSxDQUFBLE1BQUEsYUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHdDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDYjNDLFVBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFDQSxVQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMEJBQUEsSUFBQSx3REFBQSxJQUFBLENBQUE7QUFTSixVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxRQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFDQSxVQUFBLHNCQUFBLEVBQUE7O0FBQ0osVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxLQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFDQSxVQUFBLHNCQUFBLEVBQUE7O0FBQ0osVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxLQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFDQSxVQUFBLHNCQUFBLEVBQUE7O0FBQ0osVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsZUFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsSUFBQTs7O0FBbkMrQyxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLFFBQUEsSUFBQSxNQUFBO0FBQy9CLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLGNBQUEsS0FBQSxFQUFBO0FBY0ksVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxrQ0FBQSwwQkFBQSwyQkFBQSxJQUFBLEdBQUEsc0NBQUEsR0FBQSxvQkFBQTtBQUlBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsa0NBQUEsMEJBQUEsMkJBQUEsSUFBQSxHQUFBLDRDQUFBLEdBQUEsb0JBQUE7QUFJQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLGtDQUFBLDBCQUFBLDJCQUFBLElBQUEsR0FBQSw4Q0FBQSxHQUFBLG9CQUFBOzs7OztzRkRmUCxnQ0FBOEIsRUFBQSxXQUFBLGlDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVozQyxTQUFTLHFCQUFBQyxvQkFBbUIsYUFBQUMsa0JBQXlCOztBQUFyRCxJQVdzQjtBQVh0Qjs7QUFJQTtBQUNBOzs7QUFNTSxJQUFnQix3QkFBaEIsTUFBZ0IsdUJBQXFCO01BY3pCO01BQ0E7TUFDQTtNQWRkLGtCQUFrQjtNQUNsQjtNQUdBO01BQ0E7TUFDQTtNQUNBO01BQ0EsT0FBTztNQUNQO01BRUEsWUFDYyxxQkFDQSxjQUNBLGdCQUFpQztBQUZqQyxhQUFBLHNCQUFBO0FBQ0EsYUFBQSxlQUFBO0FBQ0EsYUFBQSxpQkFBQTtNQUNYO01BRUgsV0FBUTtBQUNKLGFBQUssYUFBYSxTQUFRO0FBQzFCLGFBQUssWUFBVztNQUNwQjtNQU9VLGNBQVc7QUFDakIsYUFBSyxvQkFBb0IsYUFBYSxLQUFLLG9CQUFvQixFQUFFLFVBQVU7VUFDdkUsTUFBTSxDQUFDLFFBQWdDO0FBQ25DLGlCQUFLLGVBQWUsS0FBSyxvQkFBb0IsdUNBQXVDLElBQUksTUFBTyxLQUFLLG9CQUFvQjtBQUN4SCxpQkFBSyxXQUFXLEtBQUssb0JBQW9CLCtDQUErQyxLQUFLLFlBQVk7QUFDekcsaUJBQUssZUFBZSxjQUFhO0FBQ2pDLGlCQUFLLGFBQWEsU0FBUTtVQUM5QjtVQUNBLE9BQU8sQ0FBQyxRQUEyQixLQUFLLFFBQVEsR0FBRztTQUN0RDtNQUNMO01BUU8sZUFBWTtBQUNmLGFBQUssb0JBQW9CLGFBQWEsS0FBSyxVQUFVLEtBQUssb0JBQW9CLEVBQUUsVUFBVTtVQUN0RixNQUFNLENBQUMsUUFBZ0M7QUFDbkMsaUJBQUssZUFBZSxLQUFLLG9CQUFvQixvQkFBb0IsS0FBSyxjQUFjLElBQUksSUFBSztBQUM3RixpQkFBSyxXQUFXLEtBQUssb0JBQW9CLCtDQUErQyxLQUFLLFlBQVk7QUFDekcsaUJBQUssYUFBWTtVQUNyQjtVQUNBLE9BQU8sQ0FBQyxRQUEyQixLQUFLLFFBQVEsR0FBRztTQUN0RDtNQUNMO01BT1UsZUFBWTtBQUNsQixhQUFLLHdCQUF1QjtBQUM1QixhQUFLLGtCQUFrQjtBQUN2QixhQUFLLGFBQWEsU0FBUTtBQUMxQixhQUFLLGFBQWEsUUFBUSxrREFBa0Q7TUFDaEY7TUFNVSwwQkFBdUI7QUFDN0IsYUFBSyxvQkFBb0Isc0JBQXNCLEtBQUssa0JBQWtCO01BQzFFO01BUVUsUUFBUSxtQkFBb0M7QUFDbEQsY0FBTSxRQUFRLGtCQUFrQjtBQUNoQyxZQUFJLE9BQU87QUFDUCxlQUFLLGFBQWEsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNO2VBQ2hEO0FBQ0gsZUFBSyxhQUFhLE1BQU0seUJBQXlCO1lBQzdDLE9BQU8sa0JBQWtCO1dBQzVCOztNQUVUOzt5QkE3RmtCLHdCQUFxQixpQ0FBQSxtQkFBQSxHQUFBLGlDQUFBLFlBQUEsR0FBQSxpQ0FBQSxzQkFBQSxDQUFBO01BQUE7a0VBQXJCLHVCQUFxQixDQUFBOzs7Ozs7QUNaM0MsU0FBUyxxQkFBQUMsb0JBQW1CLGFBQUFDLG1CQUF5QjtBQU9yRCxTQUFTLGdCQUFBQyxlQUFjLGNBQWM7Ozs7OztBQ1E3QixJQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxVQUFBLENBQUE7QUFBd0UsSUFBQSwwQkFBQSxTQUFBLFNBQUEsZ0ZBQUE7QUFBQSxNQUFBLDZCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUE7QUFBQSxhQUFTLDJCQUFBLE9BQUEsYUFBQSxDQUFtQjtJQUFBLENBQUE7QUFDaEcsSUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEsc0JBQUEsQ0FBQTs7QUFDSixJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLFFBQUE7Ozs7QUFINEIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsTUFBQTtBQUNwQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLGtCQUFBLDJCQUFBLEdBQUEsR0FBQSxxQ0FBQSxHQUFBLFlBQUE7Ozs7OztBQTJCd0IsSUFBQSxzQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxTQUFBLEVBQUE7QUFNSSxJQUFBLDBCQUFBLFNBQUEsU0FBQSw4R0FBQSxRQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBLENBQUE7QUFBQSxhQUFTLDJCQUFBLFFBQUEsY0FBQSxRQUFBLFFBQUEscUJBQUEsTUFBQSxDQUFrRDtJQUFBLENBQUE7QUFOL0QsSUFBQSw0QkFBQTtBQVFBLElBQUEsc0JBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxTQUFBLEVBQUE7QUFBOEQsSUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBTSxJQUFBLDRCQUFBO0FBQ3hFLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsb0NBQUE7Ozs7QUFOWSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLHFDQUFBLE1BQUEsWUFBQSxTQUFBO0FBQ0EsSUFBQSxxQ0FBQSxTQUFBLFlBQUEsTUFBQTtBQUZBLElBQUEsMEJBQUEsV0FBQSxZQUFBLE1BQUE7QUFLNEIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxxQ0FBQSxPQUFBLFlBQUEsU0FBQTs7Ozs7O0FBSXBDLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsU0FBQSxFQUFBO0FBTUksSUFBQSwwQkFBQSxTQUFBLFNBQUEsOEdBQUEsUUFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQSxDQUFBO0FBQUEsYUFBUywyQkFBQSxRQUFBLGNBQUEsUUFBQSxRQUFBLHFCQUFBLEtBQUEsQ0FBaUQ7SUFBQSxDQUFBO0FBTjlELElBQUEsNEJBQUE7QUFRQSxJQUFBLHNCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQW9FLElBQUEsc0JBQUEsR0FBQSxPQUFBO0FBQUssSUFBQSw0QkFBQTtBQUM3RSxJQUFBLHNCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLG9DQUFBOzs7O0FBTlksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxzQ0FBQSxNQUFBLElBQUEsWUFBQSxXQUFBLFFBQUE7QUFDQSxJQUFBLHFDQUFBLFNBQUEsWUFBQSxLQUFBO0FBRkEsSUFBQSwwQkFBQSxXQUFBLFlBQUEsS0FBQTtBQUs0QixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLHNDQUFBLE9BQUEsSUFBQSxZQUFBLFdBQUEsUUFBQTs7Ozs7QUFsQ2hELElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsb0NBQUE7QUFDQSxJQUFBLHNCQUFBLENBQUE7O0FBQ0osSUFBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLG9DQUFBO0FBQ0EsSUFBQSxzQkFBQSxFQUFBOztBQUNKLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLElBQUEsZ0NBQUE7QUFDQSxJQUFBLHNCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSwwQkFBQSxJQUFBLHdGQUFBLEdBQUEsQ0FBQSxFQVlDLElBQUEsd0ZBQUEsR0FBQSxDQUFBO0FBY0wsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsd0JBQUE7Ozs7QUFwQ1ksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSxzQ0FBQSwyQkFBQSxHQUFBLEdBQUEsMENBQUEsWUFBQSxHQUFBLEdBQUEsZ0NBQUE7QUFJQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLHNDQUFBLDJCQUFBLElBQUEsR0FBQSxpREFBQSxZQUFBLGNBQUEsR0FBQSxnQ0FBQTtBQUlBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxZQUFBLFVBQUEsV0FBQSxZQUFBLGlCQUFBLFVBQUEsWUFBQSxpQkFBQSxLQUFBLEVBQUE7QUFhQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsWUFBQSxTQUFBLFVBQUEsWUFBQSxlQUFBLEtBQUEsRUFBQTs7Ozs7QUEvQmhCLElBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsQ0FBQTs7QUFDSixJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSxnQ0FBQSxHQUFBLHlFQUFBLElBQUEsR0FBQSxNQUFBLE1BQUEsd0NBQUE7QUF5Q0osSUFBQSw0QkFBQTs7OztBQTNDUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLDhCQUFBLDJCQUFBLEdBQUEsR0FBQSwrQ0FBQSxnQkFBQSxHQUFBLEdBQUEsd0JBQUE7QUFFSixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGdCQUFBLFFBQUE7Ozs7O0FBUFIsSUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDBCQUFBLEdBQUEsbUVBQUEsSUFBQSxHQUFBLE9BQUEsQ0FBQTtBQWdESixJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLFlBQUE7Ozs7QUFqRGMsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxzQkFBQSxnQkFBQSxpQkFBQTs7Ozs7QUFIbEIsSUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLGdDQUFBLEdBQUEsNkRBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx3Q0FBQTtBQW9ESixJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLElBQUE7Ozs7QUFyRFEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxPQUFBLGFBQUEsTUFBQTs7O0FEdkJSLElBVVksMENBVUM7QUFwQmI7O0FBQ0E7QUFDQTtBQUVBO0FBRUE7QUFFQTs7Ozs7O0FBRUEsS0FBQSxTQUFZQywyQ0FBd0M7QUFDaEQsTUFBQUEsMENBQUFBLDBDQUFBLFFBQUEsSUFBQSxDQUFBLElBQUE7QUFDQSxNQUFBQSwwQ0FBQUEsMENBQUEsT0FBQSxJQUFBLENBQUEsSUFBQTtJQUNKLEdBSFksNkNBQUEsMkNBQXdDLENBQUEsRUFBQTtBQVU5QyxJQUFPLGdDQUFQLE1BQU8sdUNBQXNDLHNCQUFxQjtNQVN4RDtNQVBaLFNBQVM7TUFDVCxlQUFlRDtNQUVmLFlBQ0kscUJBQ0EsZ0JBQ0EsY0FDUSw2QkFBd0Q7QUFFaEUsY0FBTSxxQkFBcUIsY0FBYyxjQUFjO0FBRi9DLGFBQUEsOEJBQUE7TUFHWjtNQUVRO01BQ0E7TUFHQyx1QkFBdUI7TUFFaEMsV0FBUTtBQUNKLGFBQUssdUJBQXVCLHFCQUFxQjtBQUNqRCxhQUFLLHFCQUFxQjtBQUcxQixjQUFNLDZCQUFvRCxLQUFLLDRCQUE0Qix3QkFBdUI7QUFDbEgsWUFBSSwyQkFBMkIsV0FBVyxHQUFHO0FBRXpDLGdCQUFNLFNBQVE7ZUFDWDtBQUVILGVBQUssZUFBZSxLQUFLLG9CQUFvQix1Q0FBdUMsNEJBQTRCLEtBQUssb0JBQW9CO0FBQ3pJLGVBQUssV0FBVyxLQUFLLG9CQUFvQiwrQ0FBK0MsS0FBSyxZQUFZO0FBQ3pHLGVBQUssZUFBZSxjQUFhOztNQUV6QztNQU1BLGNBQWMsT0FBWSxzQkFBOEQ7QUFDcEYsYUFBSyxrQkFBa0I7QUFDdkIsWUFBSSxZQUFZLE1BQU0sY0FBYztBQUVwQyxZQUFJLFVBQVUsUUFBUSxHQUFHLE1BQU0sSUFBSTtBQUMvQixzQkFBWSxVQUFVLE1BQU0sR0FBRyxVQUFVLFFBQVEsR0FBRyxDQUFDOztBQUV6RCxjQUFNLGtCQUFrQixLQUFLLFNBQVMsS0FBSyxDQUFDLFlBQVksUUFBUSxjQUFjLFNBQVM7QUFDdkYsWUFBSSxDQUFDLGlCQUFpQjtBQUNsQjs7QUFHSixnQkFBUSxzQkFBc0I7VUFDMUIsS0FBSyx5Q0FBeUMsUUFBUTtBQUNsRCw0QkFBaUIsU0FBUyxDQUFDLGdCQUFpQjtBQUM1Qzs7VUFFSixLQUFLLHlDQUF5QyxPQUFPO0FBQ2pELDRCQUFpQixRQUFRLENBQUMsZ0JBQWlCO0FBQzNDOzs7QUFHUix3QkFBZ0IsVUFBVTtNQUM5Qjs7eUJBaEVTLGdDQUE2QixpQ0FBQSxtQkFBQSxHQUFBLGlDQUFBLHNCQUFBLEdBQUEsaUNBQUEsWUFBQSxHQUFBLGlDQUFBLDJCQUFBLENBQUE7TUFBQTtrRUFBN0IsZ0NBQTZCLFdBQUEsQ0FBQSxDQUFBLDJCQUFBLENBQUEsR0FBQSxVQUFBLENBQUEseUNBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsVUFBQSx5QkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsTUFBQSx3QkFBQSxHQUFBLE9BQUEsZUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxTQUFBLEdBQUEsQ0FBQSxTQUFBLG1CQUFBLEdBQUEsb0JBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLE1BQUEsR0FBQSxDQUFBLFFBQUEsWUFBQSxHQUFBLG9CQUFBLEdBQUEsV0FBQSxNQUFBLFNBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxvQkFBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHVDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDcEIxQyxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsS0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLElBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFDQSxVQUFBLHNCQUFBLENBQUE7O0FBQ0osVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxXQUFBLENBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsUUFBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQ0EsVUFBQSxzQkFBQSxFQUFBOztBQUNKLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMEJBQUEsSUFBQSx1REFBQSxHQUFBLENBQUE7QUFNSixVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDBCQUFBLElBQUEsdURBQUEsR0FBQSxDQUFBOzs7QUFqQlksVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxrQ0FBQSxrQkFBQSwyQkFBQSxHQUFBLEdBQUEsd0NBQUEsSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFHNEIsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxRQUFBLElBQUEsWUFBQTtBQUd4QixVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLGtDQUFBLHNCQUFBLDJCQUFBLElBQUEsR0FBQSx3REFBQSxHQUFBLGdCQUFBO0FBSVosVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLElBQUEsa0JBQUEsS0FBQSxFQUFBO0FBT0osVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLElBQUEsZUFBQSxLQUFBLEVBQUE7Ozs7O3NGRERhLCtCQUE2QixFQUFBLFdBQUEsZ0NBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFbkIxQyxJQU1hO0FBTmI7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRU8sSUFBTSxvQkFBNEI7TUFDckM7UUFDSSxNQUFNO1FBQ04sV0FBVztRQUNYLGFBQWEsQ0FBQyxzQkFBc0I7UUFDcEMsTUFBTTtVQUNGLGFBQWEsQ0FBQyxVQUFVLElBQUk7O1FBRWhDLFVBQVU7VUFDTjtZQUVJLE1BQU07WUFDTixXQUFXO1lBQ1gsWUFBWTs7VUFFaEI7WUFDSSxNQUFNO1lBQ04sV0FBVztZQUNYLE1BQU07Y0FDRixXQUFXOzs7VUFHbkI7WUFDSSxNQUFNO1lBQ04sV0FBVztZQUNYLE1BQU07Y0FDRixXQUFXOzs7Ozs7Ozs7O0FDakMvQixTQUFTLFlBQUFFLGlCQUFnQjtBQUt6QixTQUFTLGdCQUFBQyxxQkFBb0I7O0FBTDdCLElBWWE7QUFaYjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBTU0sSUFBTyxxQkFBUCxNQUFPLG9CQUFrQjs7eUJBQWxCLHFCQUFrQjtNQUFBO2lFQUFsQixvQkFBa0IsQ0FBQTtxRUFIakJBLGNBQWEsU0FBUyxpQkFBaUIsR0FBRyxtQkFBbUIsRUFBQSxDQUFBOzs7Ozs7QUNUM0UsU0FBUyxZQUFBQyxpQkFBZ0I7QUFDekIsU0FBUyxvQkFBb0I7QUFFN0IsU0FBUyx1QkFBdUI7O0FBSGhDLElBV2E7QUFYYjs7QUFFQTtBQUVBO0FBT00sSUFBTyxjQUFQLE1BQU8sYUFBVzs7eUJBQVgsY0FBVztNQUFBO2lFQUFYLGFBQVcsQ0FBQTtxRUFIVixpQkFBaUIsY0FBYyxtQkFBbUIsRUFBQSxDQUFBOzs7Ozs7QUNSaEUsU0FBUyxZQUFBQyxpQkFBZ0I7QUFDekIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUywyQkFBMkI7QUFDcEMsU0FBUywrQkFBK0I7O0FBSHhDLElBK0RhO0FBL0RiOztBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFxQ00sSUFBTyxtQkFBUCxNQUFPLGtCQUFnQjs7eUJBQWhCLG1CQUFnQjtNQUFBO2lFQUFoQixtQkFBZ0IsV0FBQSxDQUZiLGdCQUFnQixFQUFBLENBQUE7O1FBOUJ4QjtRQUNBO1FBRUEsb0JBQW9CLFNBQVMsa0JBQWtCLEVBQUUsU0FBUyxLQUFJLENBQUU7UUFDaEU7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO01BQTRCLEVBQUEsQ0FBQTs7Ozs7Ozs7O0FDOUNwQztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQSxlQUFVO0FBRVYsUUFBSSxPQUFPLEtBQUssR0FBRztBQUNmLGFBQU8sS0FBSyxFQUFFLE9BQU07QUFDcEIsVUFBSSxNQUF1QztBQUN2QyxnQkFBUSxNQUFLOzs7QUFJckIsSUFBQSxvQ0FBQSxFQUNLLGdCQUFnQixrQkFBa0IsRUFBRSxxQkFBcUIsS0FBSSxDQUFFLEVBQy9ELEtBQUssTUFBSztJQUFFLENBQUMsRUFDYixNQUFNLENBQUMsUUFBUSxRQUFRLE1BQU0sR0FBRyxDQUFDOzs7IiwibmFtZXMiOlsicHJvY2VzcyIsIkNvbXBvbmVudCIsIlZpZXdDaGlsZCIsImZyb21FdmVudCIsIl9jMSIsIkVsZW1lbnRSZWYiLCJJbnB1dCIsIlJlbmRlcmVyMiIsIkNvbXBvbmVudCIsImZhQ2lyY2xlTm90Y2giLCJfYzAiLCJfYzEiLCJDb21wb25lbnQiLCJkYXlqcyIsImZhSW5mb0NpcmNsZSIsImZhVGltZXMiLCJfYzAiLCJDb21wb25lbnQiLCJDb21wb25lbnQiLCJIb3N0TGlzdGVuZXIiLCJmaWx0ZXIiLCJ0YXAiLCJTZXNzaW9uU3RvcmFnZVNlcnZpY2UiLCJBY3RpdmF0ZWRSb3V0ZSIsIlRyYW5zbGF0ZVNlcnZpY2UiLCJmYUJlbGwiLCJmYUNvZyIsImZhRXllIiwiX2MwIiwiX2MxIiwiX2MyIiwiX2MzIiwiQ29tcG9uZW50IiwiQ29tcG9uZW50IiwiQWN0aXZhdGVkUm91dGUiLCJDb21wb25lbnQiLCJBY3RpdmF0ZWRSb3V0ZSIsIk5nTW9kdWxlIiwiQ29tcG9uZW50IiwiX2MwIiwiX2MxIiwiX2MyIiwiQ29tcG9uZW50IiwiRWxlbWVudFJlZiIsIlZpZXdDaGlsZCIsIkFjdGl2YXRlZFJvdXRlIiwiUm91dGVyIiwiZmFFeGNsYW1hdGlvblRyaWFuZ2xlIiwiZmFUaW1lcyIsIkNvbXBvbmVudCIsIlJlbmRlcmVyMiIsIk5hdmlnYXRpb25FbmQiLCJSb3V0ZXIiLCJkb2N1bWVudCIsIk5nTW9kdWxlIiwiQ29tcG9uZW50IiwiSW5wdXQiLCJDb21wb25lbnQiLCJFbGVtZW50UmVmIiwiUmVuZGVyZXIyIiwiQWN0aXZhdGVkUm91dGUiLCJSb3V0ZXIiLCJmYUNpcmNsZU5vdGNoIiwiX2MwIiwiX2MxIiwiX2MyIiwiX2MzIiwiX2M0IiwiTmdNb2R1bGUiLCJSb3V0ZXJNb2R1bGUiLCJDb21wb25lbnQiLCJ0YXAiLCJDb21wb25lbnQiLCJmYVVzZXIiLCJDaGFuZ2VEZXRlY3RvclJlZiIsIkRpcmVjdGl2ZSIsIkNoYW5nZURldGVjdG9yUmVmIiwiQ29tcG9uZW50IiwiZmFJbmZvQ2lyY2xlIiwiTm90aWZpY2F0aW9uU2V0dGluZ3NDb21tdW5pY2F0aW9uQ2hhbm5lbCIsIk5nTW9kdWxlIiwiUm91dGVyTW9kdWxlIiwiTmdNb2R1bGUiLCJOZ01vZHVsZSJdfQ==