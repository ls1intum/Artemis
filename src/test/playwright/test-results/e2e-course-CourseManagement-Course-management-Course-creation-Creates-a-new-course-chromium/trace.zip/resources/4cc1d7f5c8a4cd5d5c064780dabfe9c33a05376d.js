import {
  AccountService,
  ArtemisSharedModule,
  JhiConnectionStatusComponent,
  JhiWebsocketService,
  __esm,
  __spreadProps,
  __spreadValues,
  init_account_service,
  init_connection_status_component,
  init_exercise_model,
  init_shared_module,
  init_student_participation_model,
  init_websocket_service
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/shared/team/team-participate/team-students-online-list.component.ts
import { Component, Input, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { orderBy } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import { Observable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { map, throttleTime } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import { faCircle, faHistory } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function TeamStudentsOnlineListComponent_For_8_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "div", 5);
    i0.\u0275\u0275text(2, "\n                            ");
    i0.\u0275\u0275element(3, "div", 6);
    i0.\u0275\u0275text(4, "\n                            ");
    i0.\u0275\u0275element(5, "div", 7);
    i0.\u0275\u0275text(6, "\n                            ");
    i0.\u0275\u0275element(7, "div", 8);
    i0.\u0275\u0275text(8, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                    ");
  }
}
function TeamStudentsOnlineListComponent_For_8_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275element(1, "fa-icon", 9);
    i0.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r7 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("icon", ctx_r7.faCircle);
  }
}
function TeamStudentsOnlineListComponent_For_8_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "span", 10);
    i0.\u0275\u0275text(2, "(you)");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(3, "\n                    ");
  }
}
function TeamStudentsOnlineListComponent_For_8_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "span", 11);
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275elementStart(3, "button", 12);
    i0.\u0275\u0275text(4, "\n                            ");
    i0.\u0275\u0275element(5, "fa-icon", 13);
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                ");
  }
  if (rf & 2) {
    const student_r1 = i0.\u0275\u0275nextContext().$implicit;
    const ctx_r9 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275propertyInterpolate("ngbTooltip", ctx_r9.lastActionDate(student_r1).fromNow());
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275property("icon", ctx_r9.faHistory);
  }
}
function TeamStudentsOnlineListComponent_For_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275elementStart(1, "li", 2);
    i0.\u0275\u0275text(2, "\n                ");
    i0.\u0275\u0275elementStart(3, "div", 3);
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275template(5, TeamStudentsOnlineListComponent_For_8_Conditional_5_Template, 10, 0)(6, TeamStudentsOnlineListComponent_For_8_Conditional_6_Template, 3, 1);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                ");
    i0.\u0275\u0275elementStart(8, "span", 4);
    i0.\u0275\u0275text(9);
    i0.\u0275\u0275template(10, TeamStudentsOnlineListComponent_For_8_Conditional_10_Template, 4, 0);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                ");
    i0.\u0275\u0275template(12, TeamStudentsOnlineListComponent_For_8_Conditional_12_Template, 9, 2);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(13, "\n        ");
  }
  if (rf & 2) {
    const student_r1 = ctx.$implicit;
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("ngClass", i0.\u0275\u0275pureFunction1(5, _c0, ctx_r0.isOnline(student_r1)));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275conditional(5, ctx_r0.isOther(student_r1) && ctx_r0.isTyping(student_r1) ? 5 : 6);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate1("", student_r1.name, "\n                    ");
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(10, ctx_r0.isSelf(student_r1) ? 10 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(12, ctx_r0.isOther(student_r1) && ctx_r0.lastActionDate(student_r1) ? 12 : -1);
  }
}
var _c0, TeamStudentsOnlineListComponent;
var init_team_students_online_list_component = __esm({
  "src/main/webapp/app/exercises/shared/team/team-participate/team-students-online-list.component.ts"() {
    init_account_service();
    init_websocket_service();
    init_student_participation_model();
    init_account_service();
    init_websocket_service();
    _c0 = (a0) => ({ online: a0 });
    TeamStudentsOnlineListComponent = class _TeamStudentsOnlineListComponent {
      accountService;
      jhiWebsocketService;
      showTypingDuration = 2e3;
      sendTypingInterval = this.showTypingDuration / 1.5;
      typing$;
      participation;
      currentUser;
      onlineTeamStudents = [];
      typingTeamStudents = [];
      websocketTopic;
      faCircle = faCircle;
      faHistory = faHistory;
      constructor(accountService, jhiWebsocketService) {
        this.accountService = accountService;
        this.jhiWebsocketService = jhiWebsocketService;
      }
      ngOnInit() {
        this.accountService.identity().then((user) => {
          this.currentUser = user;
          this.setupOnlineTeamStudentsReceiver();
          this.setupTypingIndicatorSender();
        });
      }
      setupOnlineTeamStudentsReceiver() {
        this.websocketTopic = this.buildWebsocketTopic();
        this.jhiWebsocketService.subscribe(this.websocketTopic);
        this.jhiWebsocketService.receive(this.websocketTopic).pipe(map(this.convertOnlineTeamStudentsFromServer)).subscribe({
          next: (students) => {
            this.onlineTeamStudents = students;
            this.computeTypingTeamStudents();
          },
          error: (error) => console.error(error)
        });
        setTimeout(() => {
          this.jhiWebsocketService.send(this.buildWebsocketTopic("/trigger"), {});
        }, 700);
      }
      setupTypingIndicatorSender() {
        if (this.typing$) {
          this.typing$.pipe(throttleTime(this.sendTypingInterval)).subscribe({
            next: () => this.jhiWebsocketService.send(this.buildWebsocketTopic("/typing"), {}),
            error: (error) => console.error(error)
          });
        }
      }
      ngOnDestroy() {
        this.jhiWebsocketService.unsubscribe(this.websocketTopic);
      }
      get team() {
        return this.participation.team;
      }
      get studentList() {
        return [...this.self ? [this.self] : [], ...orderBy(this.otherStudents, ["name"])];
      }
      get self() {
        return this.team.students?.find(this.isSelf);
      }
      get otherStudents() {
        return this.team.students?.filter(this.isOther) || [];
      }
      isSelf = (user) => {
        return user.id === this.currentUser?.id;
      };
      isOther = (user) => {
        return !this.isSelf(user);
      };
      isOnline = (user) => {
        return this.onlineTeamStudents.map((student) => student.login).includes(user.login);
      };
      lastActionDate = (user) => {
        return this.onlineTeamStudents.find((student) => student.login === user.login)?.lastActionDate;
      };
      isTyping = (user) => {
        return this.typingTeamStudents.map((student) => student.login).includes(user.login);
      };
      computeTypingTeamStudents() {
        this.typingTeamStudents = this.onlineTeamStudents.filter((student) => {
          return Boolean(student.lastTypingDate?.isAfter(dayjs().subtract(this.showTypingDuration, "ms")));
        });
        if (this.typingTeamStudents.length > 0) {
          const lastTypingDates = this.typingTeamStudents.map((student) => student.lastTypingDate).filter(Boolean);
          const minTypingDate = dayjs.min(lastTypingDates);
          if (minTypingDate) {
            const earliestExpiration = minTypingDate.add(this.showTypingDuration, "ms");
            const timeToExpirationInMilliseconds = earliestExpiration.diff(dayjs());
            setTimeout(() => this.computeTypingTeamStudents(), timeToExpirationInMilliseconds);
          }
        }
      }
      convertOnlineTeamStudentsFromServer(students) {
        return students.map((student) => {
          return __spreadProps(__spreadValues({}, student), {
            lastTypingDate: student.lastTypingDate !== null ? dayjs(student.lastTypingDate) : null,
            lastActionDate: student.lastActionDate !== null ? dayjs(student.lastActionDate) : null
          });
        });
      }
      buildWebsocketTopic(path = "") {
        return `/topic/participations/${this.participation.id}/team${path}`;
      }
      static \u0275fac = function TeamStudentsOnlineListComponent_Factory(t) {
        return new (t || _TeamStudentsOnlineListComponent)(i0.\u0275\u0275directiveInject(AccountService), i0.\u0275\u0275directiveInject(JhiWebsocketService));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _TeamStudentsOnlineListComponent, selectors: [["jhi-team-students-online-list"]], inputs: { typing$: "typing$", participation: "participation" }, decls: 11, vars: 0, consts: [[1, "fw-medium"], [1, "team-students-online-list"], [1, "student-item", 3, "ngClass"], [1, "indicator"], [1, "student-name"], [1, "typing-indicator"], [1, "bounce1"], [1, "bounce2"], [1, "bounce3"], ["size", "sm", 1, "student-status", 3, "icon"], [1, "text-body-secondary"], ["triggers", "click:blur", "position", "top", "tooltipClass", "student-last-action-tooltip", 3, "ngbTooltip"], [1, "student-last-action-trigger", "ms-1"], [3, "icon"]], template: function TeamStudentsOnlineListComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "div");
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275elementStart(2, "h5", 0);
          i0.\u0275\u0275text(3, "Team");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(4, "\n    ");
          i0.\u0275\u0275elementStart(5, "ul", 1);
          i0.\u0275\u0275text(6, "\n        ");
          i0.\u0275\u0275repeaterCreate(7, TeamStudentsOnlineListComponent_For_8_Template, 14, 7, null, null, i0.\u0275\u0275repeaterTrackByIdentity);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(9, "\n");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(10, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275advance(7);
          i0.\u0275\u0275repeater(ctx.studentList);
        }
      }, dependencies: [i3.NgClass, i4.NgbTooltip, i5.FaIconComponent], styles: ["/* src/main/webapp/app/exercises/shared/team/team-participate/team-students-online-list.component.scss */\n:host {\n  display: block;\n}\n.team-students-online-list {\n  list-style: none;\n  padding: 0;\n  margin: 0;\n}\n.team-students-online-list .student-item {\n  display: flex;\n  align-items: center;\n  font-size: 14px;\n  font-weight: 400;\n}\n.team-students-online-list .student-item:not(:first-of-type) {\n  margin-top: 5px;\n}\n.team-students-online-list .indicator {\n  margin-right: 5px;\n  display: flex;\n  align-items: center;\n}\n.team-students-online-list .student-status {\n  transition: 0.1s color ease-out;\n  display: inline-flex;\n  color: var(--secondary);\n}\n.online .team-students-online-list .student-status {\n  transition: 0.05s color ease-in;\n}\n.team-students-online-list .student-name {\n  transition: 0.1s color ease-out;\n  max-width: 190px;\n  text-overflow: ellipsis;\n  overflow: hidden;\n  white-space: nowrap;\n  color: var(--secondary);\n}\n.online .team-students-online-list .student-name {\n  transition: 0.05s color ease-in;\n}\n.team-students-online-list .online .student-status {\n  color: var(--success);\n}\n.team-students-online-list .online .student-name {\n  color: var(--bs-body-color);\n}\n.team-students-online-list .student-last-action-trigger {\n  margin: -1px 0;\n  opacity: 0.25;\n  background: none;\n  border: none;\n}\n.team-students-online-list .student-last-action-trigger:hover {\n  opacity: 0.75;\n}\n.team-students-online-list .student-last-action-trigger:focus {\n  opacity: 1;\n  outline: none;\n}\n.team-students-online-list .student-last-action-tooltip {\n  width: unset !important;\n}\n.team-students-online-list .student-last-action-tooltip .tooltip-inner {\n  min-width: unset !important;\n}\n.typing-indicator {\n  display: flex;\n  width: 18px;\n  opacity: 0.6;\n}\n.typing-indicator > div {\n  width: 6px;\n  height: 6px;\n  border-radius: 100%;\n  -webkit-animation: bounce-delay 1.4s infinite ease-in-out both;\n  animation: bounce-delay 1.4s infinite ease-in-out both;\n  background: var(--bs-body-color);\n}\n.typing-indicator .bounce1 {\n  animation-delay: -0.32s;\n}\n.typing-indicator .bounce2 {\n  animation-delay: -0.16s;\n}\n@keyframes bounce-delay {\n  0%, 80%, 100% {\n    transform: scale(0);\n  }\n  40% {\n    transform: scale(1);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbS1wYXJ0aWNpcGF0ZS90ZWFtLXN0dWRlbnRzLW9ubGluZS1saXN0LmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJAaW1wb3J0ICdzcmMvbWFpbi93ZWJhcHAvY29udGVudC9zY3NzL2FydGVtaXMtdmFyaWFibGVzJztcblxuQG1peGluIHN0YXR1cy1jaGFuZ2UtdHJhbnNpdGlvbigpIHtcbiAgICB0cmFuc2l0aW9uOiAwLjFzIGNvbG9yIGVhc2Utb3V0O1xuXG4gICAgLm9ubGluZSAmIHtcbiAgICAgICAgdHJhbnNpdGlvbjogMC4wNXMgY29sb3IgZWFzZS1pbjtcbiAgICB9XG59XG5cbjpob3N0IHtcbiAgICBkaXNwbGF5OiBibG9jaztcbn1cblxuLnRlYW0tc3R1ZGVudHMtb25saW5lLWxpc3Qge1xuICAgIGxpc3Qtc3R5bGU6IG5vbmU7XG4gICAgcGFkZGluZzogMDtcbiAgICBtYXJnaW46IDA7XG5cbiAgICAuc3R1ZGVudC1pdGVtIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICBmb250LXdlaWdodDogNDAwO1xuXG4gICAgICAgICY6bm90KDpmaXJzdC1vZi10eXBlKSB7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuaW5kaWNhdG9yIHtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgfVxuXG4gICAgLnN0dWRlbnQtc3RhdHVzIHtcbiAgICAgICAgQGluY2x1ZGUgc3RhdHVzLWNoYW5nZS10cmFuc2l0aW9uO1xuXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICAgICAgICBjb2xvcjogdmFyKC0tc2Vjb25kYXJ5KTtcbiAgICB9XG5cbiAgICAuc3R1ZGVudC1uYW1lIHtcbiAgICAgICAgQGluY2x1ZGUgc3RhdHVzLWNoYW5nZS10cmFuc2l0aW9uO1xuXG4gICAgICAgIG1heC13aWR0aDogMTkwcHg7XG4gICAgICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgICAgICBjb2xvcjogdmFyKC0tc2Vjb25kYXJ5KTtcbiAgICB9XG5cbiAgICAub25saW5lIHtcbiAgICAgICAgLnN0dWRlbnQtc3RhdHVzIHtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1zdWNjZXNzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC5zdHVkZW50LW5hbWUge1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLWJzLWJvZHktY29sb3IpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnN0dWRlbnQtbGFzdC1hY3Rpb24tdHJpZ2dlciB7XG4gICAgICAgIG1hcmdpbjogLTFweCAwO1xuICAgICAgICBvcGFjaXR5OiAwLjI1O1xuICAgICAgICBiYWNrZ3JvdW5kOiBub25lO1xuICAgICAgICBib3JkZXI6IG5vbmU7XG5cbiAgICAgICAgJjpob3ZlciB7XG4gICAgICAgICAgICBvcGFjaXR5OiAwLjc1O1xuICAgICAgICB9XG5cbiAgICAgICAgJjpmb2N1cyB7XG4gICAgICAgICAgICBvcGFjaXR5OiAxO1xuICAgICAgICAgICAgb3V0bGluZTogbm9uZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5zdHVkZW50LWxhc3QtYWN0aW9uLXRvb2x0aXAge1xuICAgICAgICB3aWR0aDogdW5zZXQgIWltcG9ydGFudDtcblxuICAgICAgICAudG9vbHRpcC1pbm5lciB7XG4gICAgICAgICAgICBtaW4td2lkdGg6IHVuc2V0ICFpbXBvcnRhbnQ7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi50eXBpbmctaW5kaWNhdG9yIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHdpZHRoOiAxOHB4O1xuICAgIG9wYWNpdHk6IDAuNjtcblxuICAgICYgPiBkaXYge1xuICAgICAgICAkc2l6ZTogNnB4O1xuICAgICAgICB3aWR0aDogJHNpemU7XG4gICAgICAgIGhlaWdodDogJHNpemU7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgICAgIC13ZWJraXQtYW5pbWF0aW9uOiBib3VuY2UtZGVsYXkgMS40cyBpbmZpbml0ZSBlYXNlLWluLW91dCBib3RoO1xuICAgICAgICBhbmltYXRpb246IGJvdW5jZS1kZWxheSAxLjRzIGluZmluaXRlIGVhc2UtaW4tb3V0IGJvdGg7XG4gICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWJzLWJvZHktY29sb3IpO1xuICAgIH1cblxuICAgIC5ib3VuY2UxIHtcbiAgICAgICAgYW5pbWF0aW9uLWRlbGF5OiAtMC4zMnM7XG4gICAgfVxuXG4gICAgLmJvdW5jZTIge1xuICAgICAgICBhbmltYXRpb24tZGVsYXk6IC0wLjE2cztcbiAgICB9XG5cbiAgICBAa2V5ZnJhbWVzIGJvdW5jZS1kZWxheSB7XG4gICAgICAgIDAlLFxuICAgICAgICA4MCUsXG4gICAgICAgIDEwMCUge1xuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwKTtcbiAgICAgICAgfVxuICAgICAgICA0MCUge1xuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFVQTtBQUNJLFdBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUE7QUFDQSxXQUFBO0FBQ0EsVUFBQTs7QUFFQSxDQUxKLDBCQUtJLENBQUE7QUFDSSxXQUFBO0FBQ0EsZUFBQTtBQUNBLGFBQUE7QUFDQSxlQUFBOztBQUVBLENBWFIsMEJBV1EsQ0FOSixZQU1JLEtBQUE7QUFDSSxjQUFBOztBQUlSLENBaEJKLDBCQWdCSSxDQUFBO0FBQ0ksZ0JBQUE7QUFDQSxXQUFBO0FBQ0EsZUFBQTs7QUFHSixDQXRCSiwwQkFzQkksQ0FBQTtBQWpDQSxjQUFBLEtBQUEsTUFBQTtBQW9DSSxXQUFBO0FBQ0EsU0FBQSxJQUFBOztBQW5DSixDQUFBLE9BQUEsQ0FTSiwwQkFUSSxDQStCQTtBQTlCSSxjQUFBLE1BQUEsTUFBQTs7QUFxQ0osQ0E3QkosMEJBNkJJLENBQUE7QUF4Q0EsY0FBQSxLQUFBLE1BQUE7QUEyQ0ksYUFBQTtBQUNBLGlCQUFBO0FBQ0EsWUFBQTtBQUNBLGVBQUE7QUFDQSxTQUFBLElBQUE7O0FBN0NKLENBQUEsT0FBQSxDQVNKLDBCQVRJLENBc0NBO0FBckNJLGNBQUEsTUFBQSxNQUFBOztBQWdEQSxDQXhDUiwwQkF3Q1EsQ0FqREosT0FpREksQ0FsQko7QUFtQlEsU0FBQSxJQUFBOztBQUdKLENBNUNSLDBCQTRDUSxDQXJESixPQXFESSxDQWZKO0FBZ0JRLFNBQUEsSUFBQTs7QUFJUixDQWpESiwwQkFpREksQ0FBQTtBQUNJLFVBQUEsS0FBQTtBQUNBLFdBQUE7QUFDQSxjQUFBO0FBQ0EsVUFBQTs7QUFFQSxDQXZEUiwwQkF1RFEsQ0FOSiwyQkFNSTtBQUNJLFdBQUE7O0FBR0osQ0EzRFIsMEJBMkRRLENBVkosMkJBVUk7QUFDSSxXQUFBO0FBQ0EsV0FBQTs7QUFJUixDQWpFSiwwQkFpRUksQ0FBQTtBQUNJLFNBQUE7O0FBRUEsQ0FwRVIsMEJBb0VRLENBSEosNEJBR0ksQ0FBQTtBQUNJLGFBQUE7O0FBS1osQ0FBQTtBQUNJLFdBQUE7QUFDQSxTQUFBO0FBQ0EsV0FBQTs7QUFFQSxDQUxKLGlCQUtJLEVBQUE7QUFFSSxTQURPO0FBRVAsVUFGTztBQUdQLGlCQUFBO0FBQ0EscUJBQUEsYUFBQSxLQUFBLFNBQUEsWUFBQTtBQUNBLGFBQUEsYUFBQSxLQUFBLFNBQUEsWUFBQTtBQUNBLGNBQUEsSUFBQTs7QUFHSixDQWZKLGlCQWVJLENBQUE7QUFDSSxtQkFBQTs7QUFHSixDQW5CSixpQkFtQkksQ0FBQTtBQUNJLG1CQUFBOztBQUdKLFdBWkk7QUFhQTtBQUdJLGVBQUEsTUFBQTs7QUFFSjtBQUNJLGVBQUEsTUFBQTs7OyIsCiAgIm5hbWVzIjogW10KfQo= */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(TeamStudentsOnlineListComponent, { className: "TeamStudentsOnlineListComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/team-participate/team-participate-info-box.component.ts
import { Component as Component2, Input as Input2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Observable as Observable2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var TeamParticipateInfoBoxComponent;
var init_team_participate_info_box_component = __esm({
  "src/main/webapp/app/exercises/shared/team/team-participate/team-participate-info-box.component.ts"() {
    init_exercise_model();
    init_student_participation_model();
    init_connection_status_component();
    init_team_students_online_list_component();
    TeamParticipateInfoBoxComponent = class _TeamParticipateInfoBoxComponent {
      exercise;
      participation;
      stickyEnabled = true;
      dockedToLeftSide = false;
      dockedToRightSide = false;
      typing$;
      static \u0275fac = function TeamParticipateInfoBoxComponent_Factory(t) {
        return new (t || _TeamParticipateInfoBoxComponent)();
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _TeamParticipateInfoBoxComponent, selectors: [["jhi-team-participate-info-box"]], inputs: { exercise: "exercise", participation: "participation", stickyEnabled: "stickyEnabled", dockedToLeftSide: "dockedToLeftSide", dockedToRightSide: "dockedToRightSide", typing$: "typing$" }, decls: 13, vars: 8, consts: [[1, "team-participate-info-box"], [1, "sticky-box", "bg-light"], [1, "d-flex", "justify-content-end"], [1, "text-end"], [1, "mt-3", 3, "participation", "typing$"]], template: function TeamParticipateInfoBoxComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div", 0);
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275elementStart(2, "div", 1);
          i02.\u0275\u0275text(3, "\n        ");
          i02.\u0275\u0275elementStart(4, "div", 2);
          i02.\u0275\u0275text(5, "\n            ");
          i02.\u0275\u0275element(6, "jhi-connection-status", 3);
          i02.\u0275\u0275text(7, "\n        ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(8, "\n        ");
          i02.\u0275\u0275element(9, "jhi-team-students-online-list", 4);
          i02.\u0275\u0275text(10, "\n    ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(11, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(12, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275classProp("sticky-enabled", ctx.stickyEnabled);
          i02.\u0275\u0275advance(2);
          i02.\u0275\u0275classProp("docked-to-left-side", ctx.dockedToLeftSide)("docked-to-right-side", ctx.dockedToRightSide);
          i02.\u0275\u0275advance(7);
          i02.\u0275\u0275property("participation", ctx.participation)("typing$", ctx.typing$);
        }
      }, dependencies: [JhiConnectionStatusComponent, TeamStudentsOnlineListComponent], styles: ["\n\n.team-participate-info-box[_ngcontent-%COMP%] {\n  position: relative;\n  right: -20px;\n  min-width: 250px;\n}\n.team-participate-info-box.sticky-enabled[_ngcontent-%COMP%] {\n  height: 100%;\n}\n.team-participate-info-box.sticky-enabled[_ngcontent-%COMP%]   .sticky-box[_ngcontent-%COMP%] {\n  position: sticky;\n  top: 25px;\n}\n.team-participate-info-box[_ngcontent-%COMP%]   .sticky-box[_ngcontent-%COMP%] {\n  margin-top: 2px;\n  padding: 18px 24px 20px;\n  transition: 0.2s box-shadow;\n  box-shadow: 0 0 3px rgba(0, 0, 0, 0.08), 0 0 14px rgba(0, 0, 0, 0.05);\n  border-radius: 10px;\n}\n.team-participate-info-box[_ngcontent-%COMP%]   .sticky-box.docked-to-left-side[_ngcontent-%COMP%] {\n  border-top-left-radius: 0;\n  border-bottom-left-radius: 0;\n}\n.team-participate-info-box[_ngcontent-%COMP%]   .sticky-box.docked-to-right-side[_ngcontent-%COMP%] {\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbS1wYXJ0aWNpcGF0ZS90ZWFtLXBhcnRpY2lwYXRlLWluZm8tYm94LmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIudGVhbS1wYXJ0aWNpcGF0ZS1pbmZvLWJveCB7XG4gICAgJHNpZGUtcGFkZGluZzogMjRweDtcblxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICByaWdodDogLTIwcHg7XG4gICAgbWluLXdpZHRoOiAyNTBweDtcblxuICAgICYuc3RpY2t5LWVuYWJsZWQge1xuICAgICAgICBoZWlnaHQ6IDEwMCU7XG5cbiAgICAgICAgLnN0aWNreS1ib3gge1xuICAgICAgICAgICAgcG9zaXRpb246IHN0aWNreTtcbiAgICAgICAgICAgIHRvcDogMjVweDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5zdGlja3ktYm94IHtcbiAgICAgICAgbWFyZ2luLXRvcDogMnB4O1xuICAgICAgICBwYWRkaW5nOiAxOHB4ICRzaWRlLXBhZGRpbmcgMjBweDtcbiAgICAgICAgdHJhbnNpdGlvbjogMC4ycyBib3gtc2hhZG93O1xuXG4gICAgICAgIGJveC1zaGFkb3c6XG4gICAgICAgICAgICAwIDAgM3B4IHJnYmEoMCwgMCwgMCwgMC4wOCksXG4gICAgICAgICAgICAwIDAgMTRweCByZ2JhKDAsIDAsIDAsIDAuMDUpO1xuICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuXG4gICAgICAgICYuZG9ja2VkLXRvLWxlZnQtc2lkZSB7XG4gICAgICAgICAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAwO1xuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMDtcbiAgICAgICAgfVxuXG4gICAgICAgICYuZG9ja2VkLXRvLXJpZ2h0LXNpZGUge1xuICAgICAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDA7XG4gICAgICAgICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMDtcbiAgICAgICAgfVxuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBR0ksWUFBQTtBQUNBLFNBQUE7QUFDQSxhQUFBOztBQUVBLENBUEoseUJBT0ksQ0FBQTtBQUNJLFVBQUE7O0FBRUEsQ0FWUix5QkFVUSxDQUhKLGVBR0ksQ0FBQTtBQUNJLFlBQUE7QUFDQSxPQUFBOztBQUlSLENBaEJKLDBCQWdCSSxDQU5JO0FBT0EsY0FBQTtBQUNBLFdBQUEsS0FBQSxLQUFBO0FBQ0EsY0FBQSxLQUFBO0FBRUEsY0FDSSxFQUFBLEVBQUEsSUFBQSxLQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLEtBQUEsRUFBQSxFQUFBLEVBQUEsS0FBQSxLQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBO0FBRUosaUJBQUE7O0FBRUEsQ0ExQlIsMEJBMEJRLENBaEJBLFVBZ0JBLENBQUE7QUFDSSwwQkFBQTtBQUNBLDZCQUFBOztBQUdKLENBL0JSLDBCQStCUSxDQXJCQSxVQXFCQSxDQUFBO0FBQ0ksMkJBQUE7QUFDQSw4QkFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(TeamParticipateInfoBoxComponent, { className: "TeamParticipateInfoBoxComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/team-participate/team-students-list.component.ts
import { Component as Component3, Input as Input3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function TeamStudentsListComponent_For_3_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275elementStart(1, "a", 2);
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n            ");
  }
  if (rf & 2) {
    const student_r1 = i03.\u0275\u0275nextContext().$implicit;
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("routerLink", i03.\u0275\u0275pureFunction1(2, _c02, student_r1.login));
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275textInterpolate1("", student_r1.name, " ");
  }
}
function TeamStudentsListComponent_For_3_Conditional_4_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                        ");
    i03.\u0275\u0275elementStart(1, "span");
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const student_r1 = i03.\u0275\u0275nextContext(2).$implicit;
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275textInterpolate1("(", student_r1.login, ")");
  }
}
function TeamStudentsListComponent_For_3_Conditional_4_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                        ");
    i03.\u0275\u0275elementStart(1, "span");
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const student_r1 = i03.\u0275\u0275nextContext(2).$implicit;
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275textInterpolate1("(", student_r1.visibleRegistrationNumber, ")");
  }
}
function TeamStudentsListComponent_For_3_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275elementStart(1, "span");
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275template(3, TeamStudentsListComponent_For_3_Conditional_4_Conditional_3_Template, 4, 1)(4, TeamStudentsListComponent_For_3_Conditional_4_Conditional_4_Template, 4, 1);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const student_r1 = i03.\u0275\u0275nextContext().$implicit;
    const ctx_r7 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275textInterpolate1("", student_r1.name, "\n                    ");
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(3, student_r1.login ? 3 : -1);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(4, ctx_r7.withRegistrationNumber && student_r1.visibleRegistrationNumber ? 4 : -1);
  }
}
function TeamStudentsListComponent_For_3_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275elementStart(1, "li", 1);
    i03.\u0275\u0275text(2, "\n            ");
    i03.\u0275\u0275template(3, TeamStudentsListComponent_For_3_Conditional_3_Template, 4, 4)(4, TeamStudentsListComponent_For_3_Conditional_4_Template, 6, 3);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const student_r1 = ctx.$implicit;
    const ctx_r0 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275classProp("has-error", ctx_r0.hasError(student_r1));
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275conditional(3, ctx_r0.renderLinks ? 3 : -1);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(4, !ctx_r0.renderLinks ? 4 : -1);
  }
}
var _c02, TeamStudentsListComponent;
var init_team_students_list_component = __esm({
  "src/main/webapp/app/exercises/shared/team/team-participate/team-students-list.component.ts"() {
    _c02 = (a2) => ["/admin", "user-management", a2];
    TeamStudentsListComponent = class _TeamStudentsListComponent {
      students;
      errorStudentLogins = [];
      renderLinks = false;
      withRegistrationNumber = false;
      errorStudentRegistrationNumbers = [];
      hasError(student) {
        return student.login && this.errorStudentLogins.includes(student.login) || this.withRegistrationNumber && student.visibleRegistrationNumber && this.errorStudentRegistrationNumbers.includes(student.visibleRegistrationNumber);
      }
      static \u0275fac = function TeamStudentsListComponent_Factory(t) {
        return new (t || _TeamStudentsListComponent)();
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _TeamStudentsListComponent, selectors: [["jhi-team-students-list"]], inputs: { students: "students", errorStudentLogins: "errorStudentLogins", renderLinks: "renderLinks", withRegistrationNumber: "withRegistrationNumber", errorStudentRegistrationNumbers: "errorStudentRegistrationNumbers" }, decls: 5, vars: 0, consts: [[1, "list-group", "list-group-horizontal", "student-group"], [1, "list-group-item", "student-group-item"], [3, "routerLink"]], template: function TeamStudentsListComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "ul", 0);
          i03.\u0275\u0275text(1, "\n    ");
          i03.\u0275\u0275repeaterCreate(2, TeamStudentsListComponent_For_3_Template, 6, 4, null, null, i03.\u0275\u0275repeaterTrackByIdentity);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(4, "\n");
        }
        if (rf & 2) {
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275repeater(ctx.students);
        }
      }, dependencies: [i1.RouterLink], styles: ["\n\n[_nghost-%COMP%] {\n  max-width: 100%;\n}\n.list-group-horizontal.student-group[_ngcontent-%COMP%] {\n  padding: 3px 0;\n  overflow-x: auto;\n  max-width: 100%;\n}\n.list-group-horizontal.student-group[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  border-radius: 4px;\n  -webkit-box-shadow: inset 0 0 4px rgba(0, 0, 0, 0.15);\n}\n.list-group-horizontal.student-group[_ngcontent-%COMP%]::-webkit-scrollbar {\n  height: 4px;\n}\n.list-group-horizontal.student-group[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 4px;\n  background-color: #bbbbbb;\n}\n.list-group-item.student-group-item[_ngcontent-%COMP%] {\n  padding: 0.175rem 0.75rem;\n  white-space: nowrap;\n}\n.list-group-item.student-group-item.has-error[_ngcontent-%COMP%] {\n  color: var(--artemis-alert-danger-color);\n  background-color: var(--artemis-alert-danger-background);\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbS1wYXJ0aWNpcGF0ZS90ZWFtLXN0dWRlbnRzLWxpc3QuY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIjpob3N0IHtcbiAgICBtYXgtd2lkdGg6IDEwMCU7XG59XG5cbi5saXN0LWdyb3VwLWhvcml6b250YWwuc3R1ZGVudC1ncm91cCB7XG4gICAgcGFkZGluZzogM3B4IDA7XG4gICAgb3ZlcmZsb3cteDogYXV0bztcbiAgICBtYXgtd2lkdGg6IDEwMCU7XG5cbiAgICAvLyBzaG93IGN1c3RvbSB0aGlubmVyIHNjcm9sbGJhciBmb3IgV2Via2l0LWJhc2VkIGJyb3dzZXJzXG4gICAgJHNpemU6IDRweDtcbiAgICAkdGh1bWItY29sb3I6ICNiYmJiYmI7XG5cbiAgICAmOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6ICRzaXplO1xuICAgICAgICAtd2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCAkc2l6ZSByZ2JhKDAsIDAsIDAsIDAuMTUpO1xuICAgIH1cblxuICAgICY6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgICAgICAgaGVpZ2h0OiAkc2l6ZTtcbiAgICB9XG5cbiAgICAmOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6ICRzaXplO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkdGh1bWItY29sb3I7XG4gICAgfVxufVxuXG4ubGlzdC1ncm91cC1pdGVtLnN0dWRlbnQtZ3JvdXAtaXRlbSB7XG4gICAgcGFkZGluZzogMC4xNzVyZW0gMC43NXJlbTtcbiAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuXG4gICAgJi5oYXMtZXJyb3Ige1xuICAgICAgICBjb2xvcjogdmFyKC0tYXJ0ZW1pcy1hbGVydC1kYW5nZXItY29sb3IpO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hcnRlbWlzLWFsZXJ0LWRhbmdlci1iYWNrZ3JvdW5kKTtcbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUE7QUFDSSxhQUFBOztBQUdKLENBQUEscUJBQUEsQ0FBQTtBQUNJLFdBQUEsSUFBQTtBQUNBLGNBQUE7QUFDQSxhQUFBOztBQU1BLENBVEoscUJBU0ksQ0FUSixhQVNJO0FBQ0ksaUJBSkc7QUFLSCxzQkFBQSxNQUFBLEVBQUEsRUFBQSxJQUFBLEtBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLEVBQUE7O0FBR0osQ0FkSixxQkFjSSxDQWRKLGFBY0k7QUFDSSxVQVRHOztBQVlQLENBbEJKLHFCQWtCSSxDQWxCSixhQWtCSTtBQUNJLGlCQWJHO0FBY0gsb0JBYlU7O0FBaUJsQixDQUFBLGVBQUEsQ0FBQTtBQUNJLFdBQUEsU0FBQTtBQUNBLGVBQUE7O0FBRUEsQ0FKSixlQUlJLENBSkosa0JBSUksQ0FBQTtBQUNJLFNBQUEsSUFBQTtBQUNBLG9CQUFBLElBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(TeamStudentsListComponent, { className: "TeamStudentsListComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/team-participate/team-participate.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { RouterModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisTeamParticipeModule;
var init_team_participate_module = __esm({
  "src/main/webapp/app/exercises/shared/team/team-participate/team-participate.module.ts"() {
    init_team_participate_info_box_component();
    init_team_students_online_list_component();
    init_shared_module();
    init_team_students_list_component();
    ArtemisTeamParticipeModule = class _ArtemisTeamParticipeModule {
      static \u0275fac = function ArtemisTeamParticipeModule_Factory(t) {
        return new (t || _ArtemisTeamParticipeModule)();
      };
      static \u0275mod = i04.\u0275\u0275defineNgModule({ type: _ArtemisTeamParticipeModule });
      static \u0275inj = i04.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, RouterModule] });
    };
  }
});

export {
  TeamStudentsListComponent,
  init_team_students_list_component,
  TeamParticipateInfoBoxComponent,
  init_team_participate_info_box_component,
  ArtemisTeamParticipeModule,
  init_team_participate_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0tcGFydGljaXBhdGUvdGVhbS1zdHVkZW50cy1vbmxpbmUtbGlzdC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtLXBhcnRpY2lwYXRlL3RlYW0tc3R1ZGVudHMtb25saW5lLWxpc3QuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtLXBhcnRpY2lwYXRlL3RlYW0tcGFydGljaXBhdGUtaW5mby1ib3guY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbS1wYXJ0aWNpcGF0ZS90ZWFtLXBhcnRpY2lwYXRlLWluZm8tYm94LmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbS1wYXJ0aWNpcGF0ZS90ZWFtLXN0dWRlbnRzLWxpc3QuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbS1wYXJ0aWNpcGF0ZS90ZWFtLXN0dWRlbnRzLWxpc3QuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtLXBhcnRpY2lwYXRlL3RlYW0tcGFydGljaXBhdGUubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uRGVzdHJveSwgT25Jbml0LCBWaWV3RW5jYXBzdWxhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgT25saW5lVGVhbVN0dWRlbnQsIFRlYW0gfSBmcm9tICdhcHAvZW50aXRpZXMvdGVhbS5tb2RlbCc7XG5pbXBvcnQgeyBBY2NvdW50U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL2F1dGgvYWNjb3VudC5zZXJ2aWNlJztcbmltcG9ydCB7IFVzZXIgfSBmcm9tICdhcHAvY29yZS91c2VyL3VzZXIubW9kZWwnO1xuaW1wb3J0IHsgb3JkZXJCeSB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBtYXAsIHRocm90dGxlVGltZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCBkYXlqcyBmcm9tICdkYXlqcy9lc20nO1xuaW1wb3J0IHsgSmhpV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3dlYnNvY2tldC93ZWJzb2NrZXQuc2VydmljZSc7XG5pbXBvcnQgeyBTdHVkZW50UGFydGljaXBhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9wYXJ0aWNpcGF0aW9uL3N0dWRlbnQtcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBmYUNpcmNsZSwgZmFIaXN0b3J5IH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktdGVhbS1zdHVkZW50cy1vbmxpbmUtbGlzdCcsXG4gICAgdGVtcGxhdGVVcmw6ICcuL3RlYW0tc3R1ZGVudHMtb25saW5lLWxpc3QuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL3RlYW0tc3R1ZGVudHMtb25saW5lLWxpc3QuY29tcG9uZW50LnNjc3MnXSxcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxufSlcbmV4cG9ydCBjbGFzcyBUZWFtU3R1ZGVudHNPbmxpbmVMaXN0Q29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xuICAgIHJlYWRvbmx5IHNob3dUeXBpbmdEdXJhdGlvbiA9IDIwMDA7IC8vIG1zXG4gICAgcmVhZG9ubHkgc2VuZFR5cGluZ0ludGVydmFsID0gdGhpcy5zaG93VHlwaW5nRHVyYXRpb24gLyAxLjU7XG5cbiAgICBASW5wdXQoKSB0eXBpbmckOiBPYnNlcnZhYmxlPGFueT47XG4gICAgQElucHV0KCkgcGFydGljaXBhdGlvbjogU3R1ZGVudFBhcnRpY2lwYXRpb247XG5cbiAgICBjdXJyZW50VXNlcjogVXNlcjtcbiAgICBvbmxpbmVUZWFtU3R1ZGVudHM6IE9ubGluZVRlYW1TdHVkZW50W10gPSBbXTtcbiAgICB0eXBpbmdUZWFtU3R1ZGVudHM6IE9ubGluZVRlYW1TdHVkZW50W10gPSBbXTtcbiAgICB3ZWJzb2NrZXRUb3BpYzogc3RyaW5nO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUNpcmNsZSA9IGZhQ2lyY2xlO1xuICAgIGZhSGlzdG9yeSA9IGZhSGlzdG9yeTtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGFjY291bnRTZXJ2aWNlOiBBY2NvdW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBqaGlXZWJzb2NrZXRTZXJ2aWNlOiBKaGlXZWJzb2NrZXRTZXJ2aWNlLFxuICAgICkge31cblxuICAgIC8qKlxuICAgICAqIFN1YnNjcmliZXMgdG8gdGhlIHdlYnNvY2tldCB0b3BpYyBcInRlYW1cIiBmb3IgdGhlIGdpdmVuIHBhcnRpY2lwYXRpb25cbiAgICAgKlxuICAgICAqIFRoZSBjdXJyZW50IGxpc3Qgb2Ygb25saW5lIHRlYW0gbWVtYmVycyBpcyBzZW50IHVwb24gc3Vic2NyaWJpbmcsIGhvd2V2ZXIsIHRoaXMgbWVzc2FnZSBjYW5ub3QgYmUgcmVjZWl2ZWQgeWV0IGJ5IHRoZVxuICAgICAqIGNsaWVudCBzb21ldGltZXMgYW5kIHRodXMgdGhlIGxpc3QgaXMgZXhwbGljaXRseSByZXF1ZXN0ZWQgb25jZSBtb3JlIGFmdGVyIGEgc2hvcnQgdGltZW91dCB0byBjb3ZlciB0aG9zZSBjYXNlcy5cbiAgICAgKi9cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5hY2NvdW50U2VydmljZS5pZGVudGl0eSgpLnRoZW4oKHVzZXI6IFVzZXIpID0+IHtcbiAgICAgICAgICAgIHRoaXMuY3VycmVudFVzZXIgPSB1c2VyO1xuICAgICAgICAgICAgdGhpcy5zZXR1cE9ubGluZVRlYW1TdHVkZW50c1JlY2VpdmVyKCk7XG4gICAgICAgICAgICB0aGlzLnNldHVwVHlwaW5nSW5kaWNhdG9yU2VuZGVyKCk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHByaXZhdGUgc2V0dXBPbmxpbmVUZWFtU3R1ZGVudHNSZWNlaXZlcigpIHtcbiAgICAgICAgdGhpcy53ZWJzb2NrZXRUb3BpYyA9IHRoaXMuYnVpbGRXZWJzb2NrZXRUb3BpYygpO1xuICAgICAgICB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2Uuc3Vic2NyaWJlKHRoaXMud2Vic29ja2V0VG9waWMpO1xuICAgICAgICB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2VcbiAgICAgICAgICAgIC5yZWNlaXZlKHRoaXMud2Vic29ja2V0VG9waWMpXG4gICAgICAgICAgICAucGlwZShtYXAodGhpcy5jb252ZXJ0T25saW5lVGVhbVN0dWRlbnRzRnJvbVNlcnZlcikpXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAoc3R1ZGVudHM6IE9ubGluZVRlYW1TdHVkZW50W10pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vbmxpbmVUZWFtU3R1ZGVudHMgPSBzdHVkZW50cztcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb21wdXRlVHlwaW5nVGVhbVN0dWRlbnRzKCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKGVycm9yKSA9PiBjb25zb2xlLmVycm9yKGVycm9yKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuamhpV2Vic29ja2V0U2VydmljZS5zZW5kKHRoaXMuYnVpbGRXZWJzb2NrZXRUb3BpYygnL3RyaWdnZXInKSwge30pO1xuICAgICAgICB9LCA3MDApO1xuICAgIH1cblxuICAgIHByaXZhdGUgc2V0dXBUeXBpbmdJbmRpY2F0b3JTZW5kZXIoKSB7XG4gICAgICAgIGlmICh0aGlzLnR5cGluZyQpIHtcbiAgICAgICAgICAgIHRoaXMudHlwaW5nJC5waXBlKHRocm90dGxlVGltZSh0aGlzLnNlbmRUeXBpbmdJbnRlcnZhbCkpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKCkgPT4gdGhpcy5qaGlXZWJzb2NrZXRTZXJ2aWNlLnNlbmQodGhpcy5idWlsZFdlYnNvY2tldFRvcGljKCcvdHlwaW5nJyksIHt9KSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKGVycm9yKSA9PiBjb25zb2xlLmVycm9yKGVycm9yKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTGlmZSBjeWNsZSBob29rIHRvIGluZGljYXRlIGNvbXBvbmVudCBkZXN0cnVjdGlvbiBpcyBkb25lXG4gICAgICovXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgICAgIHRoaXMuamhpV2Vic29ja2V0U2VydmljZS51bnN1YnNjcmliZSh0aGlzLndlYnNvY2tldFRvcGljKTtcbiAgICB9XG5cbiAgICBnZXQgdGVhbSgpOiBUZWFtIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucGFydGljaXBhdGlvbi50ZWFtITtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBAcmV0dXJuIGxpc3Qgb2YgdGVhbSBtZW1iZXJzICgxLiBjdXJyZW50IHVzZXIsIHguIG90aGVyIHVzZXJzIHNvcnRlZCBhbHBoYWJldGljYWxseSBieSBmdWxsIG5hbWUpXG4gICAgICovXG4gICAgZ2V0IHN0dWRlbnRMaXN0KCk6IFVzZXJbXSB7XG4gICAgICAgIHJldHVybiBbLi4uKHRoaXMuc2VsZiA/IFt0aGlzLnNlbGZdIDogW10pLCAuLi5vcmRlckJ5KHRoaXMub3RoZXJTdHVkZW50cywgWyduYW1lJ10pXTtcbiAgICB9XG5cbiAgICBnZXQgc2VsZigpOiBVc2VyIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudGVhbS5zdHVkZW50cz8uZmluZCh0aGlzLmlzU2VsZik7XG4gICAgfVxuXG4gICAgZ2V0IG90aGVyU3R1ZGVudHMoKTogVXNlcltdIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudGVhbS5zdHVkZW50cz8uZmlsdGVyKHRoaXMuaXNPdGhlcikgfHwgW107XG4gICAgfVxuXG4gICAgaXNTZWxmID0gKHVzZXI6IFVzZXIpOiBib29sZWFuID0+IHtcbiAgICAgICAgcmV0dXJuIHVzZXIuaWQgPT09IHRoaXMuY3VycmVudFVzZXI/LmlkO1xuICAgIH07XG5cbiAgICBpc090aGVyID0gKHVzZXI6IFVzZXIpOiBib29sZWFuID0+IHtcbiAgICAgICAgcmV0dXJuICF0aGlzLmlzU2VsZih1c2VyKTtcbiAgICB9O1xuXG4gICAgaXNPbmxpbmUgPSAodXNlcjogVXNlcik6IGJvb2xlYW4gPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5vbmxpbmVUZWFtU3R1ZGVudHMubWFwKChzdHVkZW50OiBPbmxpbmVUZWFtU3R1ZGVudCkgPT4gc3R1ZGVudC5sb2dpbikuaW5jbHVkZXModXNlci5sb2dpbiEpO1xuICAgIH07XG5cbiAgICBsYXN0QWN0aW9uRGF0ZSA9ICh1c2VyOiBVc2VyKTogZGF5anMuRGF5anMgfCB1bmRlZmluZWQgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5vbmxpbmVUZWFtU3R1ZGVudHMuZmluZCgoc3R1ZGVudDogT25saW5lVGVhbVN0dWRlbnQpID0+IHN0dWRlbnQubG9naW4gPT09IHVzZXIubG9naW4hKT8ubGFzdEFjdGlvbkRhdGU7XG4gICAgfTtcblxuICAgIGlzVHlwaW5nID0gKHVzZXI6IFVzZXIpOiBib29sZWFuID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMudHlwaW5nVGVhbVN0dWRlbnRzLm1hcCgoc3R1ZGVudDogT25saW5lVGVhbVN0dWRlbnQpID0+IHN0dWRlbnQubG9naW4pLmluY2x1ZGVzKHVzZXIubG9naW4hKTtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogQ29tcHV0ZXMgd2hpY2ggb2YgdGhlIG9ubGluZSB0ZWFtIG1lbWJlcnMgYXJlIGN1cnJlbnRseSB0eXBpbmdcbiAgICAgKlxuICAgICAqIFR5cGluZyBzdHVkZW50cyBhcmUgdGhvc2Ugb25saW5lIHN0dWRlbnRzIHdob3NlIHtsYXN0VHlwaW5nRGF0ZX0gaXMgbW9yZSByZWNlbnQgdGhhbiB7c2hvd1R5cGluZ0R1cmF0aW9ufSBtcyBhZ28uXG4gICAgICogSWYgdGhlcmUgYXJlIGFueSB0eXBpbmcgc3R1ZGVudHMsIGZpbmQgdGhlIHRpbWVzdGFtcCBvZiB0aGUgZWFybGllc3QgZXhwaXJhdGlvbiBvZiB0aGUgdHlwaW5nIHN0YXRlIGFtb25nIHRoZW0uXG4gICAgICogVGhlbiwgc2NoZWR1bGUgYW5vdGhlciBjb21wdXRhdGlvbiBmb3IgdGhhdCB0aW1lc3RhbXAuXG4gICAgICovXG4gICAgcHJpdmF0ZSBjb21wdXRlVHlwaW5nVGVhbVN0dWRlbnRzKCkge1xuICAgICAgICB0aGlzLnR5cGluZ1RlYW1TdHVkZW50cyA9IHRoaXMub25saW5lVGVhbVN0dWRlbnRzLmZpbHRlcigoc3R1ZGVudDogT25saW5lVGVhbVN0dWRlbnQpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBCb29sZWFuKHN0dWRlbnQubGFzdFR5cGluZ0RhdGU/LmlzQWZ0ZXIoZGF5anMoKS5zdWJ0cmFjdCh0aGlzLnNob3dUeXBpbmdEdXJhdGlvbiwgJ21zJykpKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGlmICh0aGlzLnR5cGluZ1RlYW1TdHVkZW50cy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBjb25zdCBsYXN0VHlwaW5nRGF0ZXMgPSB0aGlzLnR5cGluZ1RlYW1TdHVkZW50cy5tYXAoKHN0dWRlbnQ6IE9ubGluZVRlYW1TdHVkZW50KSA9PiBzdHVkZW50Lmxhc3RUeXBpbmdEYXRlKS5maWx0ZXIoQm9vbGVhbik7XG4gICAgICAgICAgICBjb25zdCBtaW5UeXBpbmdEYXRlID0gZGF5anMubWluKGxhc3RUeXBpbmdEYXRlcyk7XG4gICAgICAgICAgICBpZiAobWluVHlwaW5nRGF0ZSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVhcmxpZXN0RXhwaXJhdGlvbiA9IG1pblR5cGluZ0RhdGUuYWRkKHRoaXMuc2hvd1R5cGluZ0R1cmF0aW9uLCAnbXMnKTtcbiAgICAgICAgICAgICAgICBjb25zdCB0aW1lVG9FeHBpcmF0aW9uSW5NaWxsaXNlY29uZHMgPSBlYXJsaWVzdEV4cGlyYXRpb24uZGlmZihkYXlqcygpKTtcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHRoaXMuY29tcHV0ZVR5cGluZ1RlYW1TdHVkZW50cygpLCB0aW1lVG9FeHBpcmF0aW9uSW5NaWxsaXNlY29uZHMpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBjb252ZXJ0T25saW5lVGVhbVN0dWRlbnRzRnJvbVNlcnZlcihzdHVkZW50czogT25saW5lVGVhbVN0dWRlbnRbXSkge1xuICAgICAgICByZXR1cm4gc3R1ZGVudHMubWFwKChzdHVkZW50KSA9PiB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIC4uLnN0dWRlbnQsXG4gICAgICAgICAgICAgICAgbGFzdFR5cGluZ0RhdGU6IHN0dWRlbnQubGFzdFR5cGluZ0RhdGUgIT09IG51bGwgPyBkYXlqcyhzdHVkZW50Lmxhc3RUeXBpbmdEYXRlKSA6IG51bGwsXG4gICAgICAgICAgICAgICAgbGFzdEFjdGlvbkRhdGU6IHN0dWRlbnQubGFzdEFjdGlvbkRhdGUgIT09IG51bGwgPyBkYXlqcyhzdHVkZW50Lmxhc3RBY3Rpb25EYXRlKSA6IG51bGwsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUb3BpYyBmb3IgdXBkYXRlcyBvbiBvbmxpbmUgc3RhdHVzIG9mIHRlYW0gbWVtYmVycyAobmVlZHMgdG8gbWF0Y2ggcm91dGUgaW4gUGFydGljaXBhdGlvblRlYW1XZWJzb2NrZXRTZXJ2aWNlLmphdmEpXG4gICAgICovXG4gICAgcHJpdmF0ZSBidWlsZFdlYnNvY2tldFRvcGljKHBhdGggPSAnJyk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiBgL3RvcGljL3BhcnRpY2lwYXRpb25zLyR7dGhpcy5wYXJ0aWNpcGF0aW9uLmlkfS90ZWFtJHtwYXRofWA7XG4gICAgfVxufVxuIiwiPGRpdj5cbiAgICA8aDUgY2xhc3M9XCJmdy1tZWRpdW1cIj5UZWFtPC9oNT5cbiAgICA8dWwgY2xhc3M9XCJ0ZWFtLXN0dWRlbnRzLW9ubGluZS1saXN0XCI+XG4gICAgICAgIEBmb3IgKHN0dWRlbnQgb2Ygc3R1ZGVudExpc3Q7IHRyYWNrIHN0dWRlbnQpIHtcbiAgICAgICAgICAgIDxsaSBjbGFzcz1cInN0dWRlbnQtaXRlbVwiIFtuZ0NsYXNzXT1cInsgb25saW5lOiBpc09ubGluZShzdHVkZW50KSB9XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImluZGljYXRvclwiPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKGlzT3RoZXIoc3R1ZGVudCkgJiYgaXNUeXBpbmcoc3R1ZGVudCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0eXBpbmctaW5kaWNhdG9yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJvdW5jZTFcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYm91bmNlMlwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJib3VuY2UzXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBjbGFzcz1cInN0dWRlbnQtc3RhdHVzXCIgW2ljb25dPVwiZmFDaXJjbGVcIiBzaXplPVwic21cIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInN0dWRlbnQtbmFtZVwiXG4gICAgICAgICAgICAgICAgICAgID57eyBzdHVkZW50Lm5hbWUgfX1cbiAgICAgICAgICAgICAgICAgICAgQGlmIChpc1NlbGYoc3R1ZGVudCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1ib2R5LXNlY29uZGFyeVwiPih5b3UpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIEBpZiAoaXNPdGhlcihzdHVkZW50KSAmJiBsYXN0QWN0aW9uRGF0ZShzdHVkZW50KSkge1xuICAgICAgICAgICAgICAgICAgICA8c3BhbiBuZ2JUb29sdGlwPVwie3sgbGFzdEFjdGlvbkRhdGUoc3R1ZGVudCkhLmZyb21Ob3coKSB9fVwiIHRyaWdnZXJzPVwiY2xpY2s6Ymx1clwiIHBvc2l0aW9uPVwidG9wXCIgdG9vbHRpcENsYXNzPVwic3R1ZGVudC1sYXN0LWFjdGlvbi10b29sdGlwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwic3R1ZGVudC1sYXN0LWFjdGlvbi10cmlnZ2VyIG1zLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUhpc3RvcnlcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgIH1cbiAgICA8L3VsPlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBTdHVkZW50UGFydGljaXBhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9wYXJ0aWNpcGF0aW9uL3N0dWRlbnQtcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXRlYW0tcGFydGljaXBhdGUtaW5mby1ib3gnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi90ZWFtLXBhcnRpY2lwYXRlLWluZm8tYm94LmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi90ZWFtLXBhcnRpY2lwYXRlLWluZm8tYm94LmNvbXBvbmVudC5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIFRlYW1QYXJ0aWNpcGF0ZUluZm9Cb3hDb21wb25lbnQge1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlOiBFeGVyY2lzZTtcbiAgICBASW5wdXQoKSBwYXJ0aWNpcGF0aW9uOiBTdHVkZW50UGFydGljaXBhdGlvbjtcbiAgICBASW5wdXQoKSBzdGlja3lFbmFibGVkID0gdHJ1ZTtcbiAgICBASW5wdXQoKSBkb2NrZWRUb0xlZnRTaWRlID0gZmFsc2U7XG4gICAgQElucHV0KCkgZG9ja2VkVG9SaWdodFNpZGUgPSBmYWxzZTtcbiAgICBASW5wdXQoKSB0eXBpbmckOiBPYnNlcnZhYmxlPGFueT47XG59XG4iLCI8ZGl2IGNsYXNzPVwidGVhbS1wYXJ0aWNpcGF0ZS1pbmZvLWJveFwiIFtjbGFzcy5zdGlja3ktZW5hYmxlZF09XCJzdGlja3lFbmFibGVkXCI+XG4gICAgPGRpdiBjbGFzcz1cInN0aWNreS1ib3ggYmctbGlnaHRcIiBbY2xhc3MuZG9ja2VkLXRvLWxlZnQtc2lkZV09XCJkb2NrZWRUb0xlZnRTaWRlXCIgW2NsYXNzLmRvY2tlZC10by1yaWdodC1zaWRlXT1cImRvY2tlZFRvUmlnaHRTaWRlXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWVuZFwiPlxuICAgICAgICAgICAgPGpoaS1jb25uZWN0aW9uLXN0YXR1cyBjbGFzcz1cInRleHQtZW5kXCI+PC9qaGktY29ubmVjdGlvbi1zdGF0dXM+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8amhpLXRlYW0tc3R1ZGVudHMtb25saW5lLWxpc3QgY2xhc3M9XCJtdC0zXCIgW3BhcnRpY2lwYXRpb25dPVwicGFydGljaXBhdGlvblwiIFt0eXBpbmckXT1cInR5cGluZyRcIj48L2poaS10ZWFtLXN0dWRlbnRzLW9ubGluZS1saXN0PlxuICAgIDwvZGl2PlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBVc2VyIH0gZnJvbSAnYXBwL2NvcmUvdXNlci91c2VyLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktdGVhbS1zdHVkZW50cy1saXN0JyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vdGVhbS1zdHVkZW50cy1saXN0LmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi90ZWFtLXN0dWRlbnRzLWxpc3QuY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgVGVhbVN0dWRlbnRzTGlzdENvbXBvbmVudCB7XG4gICAgQElucHV0KCkgc3R1ZGVudHM6IFVzZXJbXTtcbiAgICBASW5wdXQoKSBlcnJvclN0dWRlbnRMb2dpbnM6IHN0cmluZ1tdID0gW107XG4gICAgQElucHV0KCkgcmVuZGVyTGlua3MgPSBmYWxzZTtcbiAgICBASW5wdXQoKSB3aXRoUmVnaXN0cmF0aW9uTnVtYmVyID0gZmFsc2U7XG4gICAgQElucHV0KCkgZXJyb3JTdHVkZW50UmVnaXN0cmF0aW9uTnVtYmVyczogc3RyaW5nW10gPSBbXTtcblxuICAgIGhhc0Vycm9yKHN0dWRlbnQ6IFVzZXIpIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIChzdHVkZW50LmxvZ2luICYmIHRoaXMuZXJyb3JTdHVkZW50TG9naW5zLmluY2x1ZGVzKHN0dWRlbnQubG9naW4pKSB8fFxuICAgICAgICAgICAgKHRoaXMud2l0aFJlZ2lzdHJhdGlvbk51bWJlciAmJiBzdHVkZW50LnZpc2libGVSZWdpc3RyYXRpb25OdW1iZXIgJiYgdGhpcy5lcnJvclN0dWRlbnRSZWdpc3RyYXRpb25OdW1iZXJzLmluY2x1ZGVzKHN0dWRlbnQudmlzaWJsZVJlZ2lzdHJhdGlvbk51bWJlcikpXG4gICAgICAgICk7XG4gICAgfVxufVxuIiwiPHVsIGNsYXNzPVwibGlzdC1ncm91cCBsaXN0LWdyb3VwLWhvcml6b250YWwgc3R1ZGVudC1ncm91cFwiPlxuICAgIEBmb3IgKHN0dWRlbnQgb2Ygc3R1ZGVudHM7IHRyYWNrIHN0dWRlbnQpIHtcbiAgICAgICAgPGxpIGNsYXNzPVwibGlzdC1ncm91cC1pdGVtIHN0dWRlbnQtZ3JvdXAtaXRlbVwiIFtjbGFzcy5oYXMtZXJyb3JdPVwiaGFzRXJyb3Ioc3R1ZGVudClcIj5cbiAgICAgICAgICAgIEBpZiAocmVuZGVyTGlua3MpIHtcbiAgICAgICAgICAgICAgICA8YSBbcm91dGVyTGlua109XCJbJy9hZG1pbicsICd1c2VyLW1hbmFnZW1lbnQnLCBzdHVkZW50LmxvZ2luXVwiPnt7IHN0dWRlbnQubmFtZSB9fSA8L2E+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKCFyZW5kZXJMaW5rcykge1xuICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgID57eyBzdHVkZW50Lm5hbWUgfX1cbiAgICAgICAgICAgICAgICAgICAgQGlmIChzdHVkZW50LmxvZ2luKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4oe3sgc3R1ZGVudC5sb2dpbiB9fSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQGlmICh3aXRoUmVnaXN0cmF0aW9uTnVtYmVyICYmIHN0dWRlbnQudmlzaWJsZVJlZ2lzdHJhdGlvbk51bWJlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+KHt7IHN0dWRlbnQudmlzaWJsZVJlZ2lzdHJhdGlvbk51bWJlciB9fSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvbGk+XG4gICAgfVxuPC91bD5cbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBUZWFtUGFydGljaXBhdGVJbmZvQm94Q29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtLXBhcnRpY2lwYXRlL3RlYW0tcGFydGljaXBhdGUtaW5mby1ib3guY29tcG9uZW50JztcbmltcG9ydCB7IFRlYW1TdHVkZW50c09ubGluZUxpc3RDb21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0tcGFydGljaXBhdGUvdGVhbS1zdHVkZW50cy1vbmxpbmUtbGlzdC5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBUZWFtU3R1ZGVudHNMaXN0Q29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtLXBhcnRpY2lwYXRlL3RlYW0tc3R1ZGVudHMtbGlzdC5jb21wb25lbnQnO1xuaW1wb3J0IHsgUm91dGVyTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZSwgUm91dGVyTW9kdWxlXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtUZWFtUGFydGljaXBhdGVJbmZvQm94Q29tcG9uZW50LCBUZWFtU3R1ZGVudHNPbmxpbmVMaXN0Q29tcG9uZW50LCBUZWFtU3R1ZGVudHNMaXN0Q29tcG9uZW50XSxcbiAgICBleHBvcnRzOiBbVGVhbVBhcnRpY2lwYXRlSW5mb0JveENvbXBvbmVudCwgVGVhbVN0dWRlbnRzT25saW5lTGlzdENvbXBvbmVudCwgVGVhbVN0dWRlbnRzTGlzdENvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNUZWFtUGFydGljaXBlTW9kdWxlIHt9XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsU0FBUyxXQUFXLE9BQTBCLHlCQUF5QjtBQUl2RSxTQUFTLGVBQWU7QUFDeEIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxLQUFLLG9CQUFvQjtBQUNsQyxPQUFPLFdBQVc7QUFHbEIsU0FBUyxVQUFVLGlCQUFpQjs7Ozs7OztBQ0haLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0EsSUFBQSxvQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx1QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsdUJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLHdCQUFBOzs7OztBQUNJLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsdUJBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7Ozs7QUFEb0MsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxRQUFBLE9BQUEsUUFBQTs7Ozs7QUFNaEMsSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFrQyxJQUFBLG9CQUFBLEdBQUEsT0FBQTtBQUFLLElBQUEsMEJBQUE7QUFDM0MsSUFBQSxvQkFBQSxHQUFBLHdCQUFBOzs7OztBQUdBLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx1QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLG9CQUFBOzs7OztBQUxVLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsbUNBQUEsY0FBQSxPQUFBLGVBQUEsVUFBQSxFQUFBLFFBQUEsQ0FBQTtBQUVXLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsUUFBQSxPQUFBLFNBQUE7Ozs7O0FBckJ6QixJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSw4REFBQSxJQUFBLENBQUEsRUFNQyxHQUFBLDhEQUFBLEdBQUEsQ0FBQTtBQUdMLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQ0ssSUFBQSxvQkFBQSxDQUFBO0FBQ0QsSUFBQSx3QkFBQSxJQUFBLCtEQUFBLEdBQUEsQ0FBQTtBQUdKLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsK0RBQUEsR0FBQSxDQUFBO0FBT0osSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxZQUFBOzs7OztBQTFCNkIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxXQUFBLDZCQUFBLEdBQUEsS0FBQSxPQUFBLFNBQUEsVUFBQSxDQUFBLENBQUE7QUFFakIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLE9BQUEsUUFBQSxVQUFBLEtBQUEsT0FBQSxTQUFBLFVBQUEsSUFBQSxJQUFBLENBQUE7QUFXQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLElBQUEsV0FBQSxNQUFBLHdCQUFBO0FBQ0QsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxJQUFBLE9BQUEsT0FBQSxVQUFBLElBQUEsS0FBQSxFQUFBO0FBSUosSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxJQUFBLE9BQUEsUUFBQSxVQUFBLEtBQUEsT0FBQSxlQUFBLFVBQUEsSUFBQSxLQUFBLEVBQUE7OztBRHRCaEIsU0FrQmE7QUFsQmI7O0FBRUE7QUFNQTtBQUNBOzs7O0FBU00sSUFBTyxrQ0FBUCxNQUFPLGlDQUErQjtNQWlCNUI7TUFDQTtNQWpCSCxxQkFBcUI7TUFDckIscUJBQXFCLEtBQUsscUJBQXFCO01BRS9DO01BQ0E7TUFFVDtNQUNBLHFCQUEwQyxDQUFBO01BQzFDLHFCQUEwQyxDQUFBO01BQzFDO01BR0EsV0FBVztNQUNYLFlBQVk7TUFFWixZQUNZLGdCQUNBLHFCQUF3QztBQUR4QyxhQUFBLGlCQUFBO0FBQ0EsYUFBQSxzQkFBQTtNQUNUO01BUUgsV0FBUTtBQUNKLGFBQUssZUFBZSxTQUFRLEVBQUcsS0FBSyxDQUFDLFNBQWM7QUFDL0MsZUFBSyxjQUFjO0FBQ25CLGVBQUssZ0NBQStCO0FBQ3BDLGVBQUssMkJBQTBCO1FBQ25DLENBQUM7TUFDTDtNQUVRLGtDQUErQjtBQUNuQyxhQUFLLGlCQUFpQixLQUFLLG9CQUFtQjtBQUM5QyxhQUFLLG9CQUFvQixVQUFVLEtBQUssY0FBYztBQUN0RCxhQUFLLG9CQUNBLFFBQVEsS0FBSyxjQUFjLEVBQzNCLEtBQUssSUFBSSxLQUFLLG1DQUFtQyxDQUFDLEVBQ2xELFVBQVU7VUFDUCxNQUFNLENBQUMsYUFBaUM7QUFDcEMsaUJBQUsscUJBQXFCO0FBQzFCLGlCQUFLLDBCQUF5QjtVQUNsQztVQUNBLE9BQU8sQ0FBQyxVQUFVLFFBQVEsTUFBTSxLQUFLO1NBQ3hDO0FBQ0wsbUJBQVcsTUFBSztBQUNaLGVBQUssb0JBQW9CLEtBQUssS0FBSyxvQkFBb0IsVUFBVSxHQUFHLENBQUEsQ0FBRTtRQUMxRSxHQUFHLEdBQUc7TUFDVjtNQUVRLDZCQUEwQjtBQUM5QixZQUFJLEtBQUssU0FBUztBQUNkLGVBQUssUUFBUSxLQUFLLGFBQWEsS0FBSyxrQkFBa0IsQ0FBQyxFQUFFLFVBQVU7WUFDL0QsTUFBTSxNQUFNLEtBQUssb0JBQW9CLEtBQUssS0FBSyxvQkFBb0IsU0FBUyxHQUFHLENBQUEsQ0FBRTtZQUNqRixPQUFPLENBQUMsVUFBVSxRQUFRLE1BQU0sS0FBSztXQUN4Qzs7TUFFVDtNQUtBLGNBQVc7QUFDUCxhQUFLLG9CQUFvQixZQUFZLEtBQUssY0FBYztNQUM1RDtNQUVBLElBQUksT0FBSTtBQUNKLGVBQU8sS0FBSyxjQUFjO01BQzlCO01BS0EsSUFBSSxjQUFXO0FBQ1gsZUFBTyxDQUFDLEdBQUksS0FBSyxPQUFPLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQSxHQUFLLEdBQUcsUUFBUSxLQUFLLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQztNQUN2RjtNQUVBLElBQUksT0FBSTtBQUNKLGVBQU8sS0FBSyxLQUFLLFVBQVUsS0FBSyxLQUFLLE1BQU07TUFDL0M7TUFFQSxJQUFJLGdCQUFhO0FBQ2IsZUFBTyxLQUFLLEtBQUssVUFBVSxPQUFPLEtBQUssT0FBTyxLQUFLLENBQUE7TUFDdkQ7TUFFQSxTQUFTLENBQUMsU0FBdUI7QUFDN0IsZUFBTyxLQUFLLE9BQU8sS0FBSyxhQUFhO01BQ3pDO01BRUEsVUFBVSxDQUFDLFNBQXVCO0FBQzlCLGVBQU8sQ0FBQyxLQUFLLE9BQU8sSUFBSTtNQUM1QjtNQUVBLFdBQVcsQ0FBQyxTQUF1QjtBQUMvQixlQUFPLEtBQUssbUJBQW1CLElBQUksQ0FBQyxZQUErQixRQUFRLEtBQUssRUFBRSxTQUFTLEtBQUssS0FBTTtNQUMxRztNQUVBLGlCQUFpQixDQUFDLFNBQXVDO0FBQ3JELGVBQU8sS0FBSyxtQkFBbUIsS0FBSyxDQUFDLFlBQStCLFFBQVEsVUFBVSxLQUFLLEtBQU0sR0FBRztNQUN4RztNQUVBLFdBQVcsQ0FBQyxTQUF1QjtBQUMvQixlQUFPLEtBQUssbUJBQW1CLElBQUksQ0FBQyxZQUErQixRQUFRLEtBQUssRUFBRSxTQUFTLEtBQUssS0FBTTtNQUMxRztNQVNRLDRCQUF5QjtBQUM3QixhQUFLLHFCQUFxQixLQUFLLG1CQUFtQixPQUFPLENBQUMsWUFBOEI7QUFDcEYsaUJBQU8sUUFBUSxRQUFRLGdCQUFnQixRQUFRLE1BQUssRUFBRyxTQUFTLEtBQUssb0JBQW9CLElBQUksQ0FBQyxDQUFDO1FBQ25HLENBQUM7QUFDRCxZQUFJLEtBQUssbUJBQW1CLFNBQVMsR0FBRztBQUNwQyxnQkFBTSxrQkFBa0IsS0FBSyxtQkFBbUIsSUFBSSxDQUFDLFlBQStCLFFBQVEsY0FBYyxFQUFFLE9BQU8sT0FBTztBQUMxSCxnQkFBTSxnQkFBZ0IsTUFBTSxJQUFJLGVBQWU7QUFDL0MsY0FBSSxlQUFlO0FBQ2Ysa0JBQU0scUJBQXFCLGNBQWMsSUFBSSxLQUFLLG9CQUFvQixJQUFJO0FBQzFFLGtCQUFNLGlDQUFpQyxtQkFBbUIsS0FBSyxNQUFLLENBQUU7QUFDdEUsdUJBQVcsTUFBTSxLQUFLLDBCQUF5QixHQUFJLDhCQUE4Qjs7O01BRzdGO01BRVEsb0NBQW9DLFVBQTZCO0FBQ3JFLGVBQU8sU0FBUyxJQUFJLENBQUMsWUFBVztBQUM1QixpQkFBTyxpQ0FDQSxVQURBO1lBRUgsZ0JBQWdCLFFBQVEsbUJBQW1CLE9BQU8sTUFBTSxRQUFRLGNBQWMsSUFBSTtZQUNsRixnQkFBZ0IsUUFBUSxtQkFBbUIsT0FBTyxNQUFNLFFBQVEsY0FBYyxJQUFJOztRQUUxRixDQUFDO01BQ0w7TUFLUSxvQkFBb0IsT0FBTyxJQUFFO0FBQ2pDLGVBQU8seUJBQXlCLEtBQUssY0FBYyxFQUFFLFFBQVEsSUFBSTtNQUNyRTs7eUJBakpTLGtDQUErQiwrQkFBQSxjQUFBLEdBQUEsK0JBQUEsbUJBQUEsQ0FBQTtNQUFBO2dFQUEvQixrQ0FBK0IsV0FBQSxDQUFBLENBQUEsK0JBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxTQUFBLFdBQUEsZUFBQSxnQkFBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLDJCQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxHQUFBLGtCQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxxQkFBQSxHQUFBLENBQUEsWUFBQSxjQUFBLFlBQUEsT0FBQSxnQkFBQSwrQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsK0JBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEseUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNsQjVDLFVBQUEsNEJBQUEsR0FBQSxLQUFBO0FBQ0ksVUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQXNCLFVBQUEsb0JBQUEsR0FBQSxNQUFBO0FBQUksVUFBQSwwQkFBQTtBQUMxQixVQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxNQUFBLENBQUE7QUFDSSxVQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxnREFBQSxJQUFBLEdBQUEsTUFBQSxNQUFBLHNDQUFBO0FBNEJKLFVBQUEsMEJBQUE7QUFDSixVQUFBLG9CQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsMEJBQUE7QUFDQSxVQUFBLG9CQUFBLElBQUEsSUFBQTs7O0FBOUJRLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBOzs7OztvRkRlSyxpQ0FBK0IsRUFBQSxXQUFBLGtDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRWxCNUMsU0FBUyxhQUFBQSxZQUFXLFNBQUFDLGNBQWE7QUFHakMsU0FBUyxjQUFBQyxtQkFBa0I7O0FBSDNCLElBVWE7QUFWYjs7QUFDQTtBQUNBOzs7QUFRTSxJQUFPLGtDQUFQLE1BQU8saUNBQStCO01BQy9CO01BQ0E7TUFDQSxnQkFBZ0I7TUFDaEIsbUJBQW1CO01BQ25CLG9CQUFvQjtNQUNwQjs7eUJBTkEsa0NBQStCO01BQUE7aUVBQS9CLGtDQUErQixXQUFBLENBQUEsQ0FBQSwrQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFVBQUEsWUFBQSxlQUFBLGlCQUFBLGVBQUEsaUJBQUEsa0JBQUEsb0JBQUEsbUJBQUEscUJBQUEsU0FBQSxVQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLDJCQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLHFCQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLGlCQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSx5Q0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1Y1QyxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsVUFBQSx3QkFBQSxHQUFBLHlCQUFBLENBQUE7QUFDSixVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsd0JBQUEsR0FBQSxpQ0FBQSxDQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQVJ1QyxVQUFBLDBCQUFBLGtCQUFBLElBQUEsYUFBQTtBQUNGLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsdUJBQUEsSUFBQSxnQkFBQSxFQUE4Qyx3QkFBQSxJQUFBLGlCQUFBO0FBSS9CLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsaUJBQUEsSUFBQSxhQUFBLEVBQStCLFdBQUEsSUFBQSxPQUFBOzs7OztxRkRLdEUsaUNBQStCLEVBQUEsV0FBQSxrQ0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVWNUMsU0FBUyxhQUFBQyxZQUFXLFNBQUFDLGNBQWE7Ozs7O0FDSWpCLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLENBQUE7QUFBK0QsSUFBQSxxQkFBQSxDQUFBO0FBQW1CLElBQUEsMkJBQUE7QUFDdEYsSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBRE8sSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLDhCQUFBLEdBQUFDLE1BQUEsV0FBQSxLQUFBLENBQUE7QUFBNEQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxJQUFBLFdBQUEsTUFBQSxHQUFBOzs7OztBQU12RCxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUFxQixJQUFBLDJCQUFBO0FBQy9CLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSxXQUFBLE9BQUEsR0FBQTs7Ozs7QUFHTixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUF5QyxJQUFBLDJCQUFBO0FBQ25ELElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSxXQUFBLDJCQUFBLEdBQUE7Ozs7O0FBTmQsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSyxJQUFBLHFCQUFBLENBQUE7QUFDRCxJQUFBLHlCQUFBLEdBQUEsc0VBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSxzRUFBQSxHQUFBLENBQUE7QUFJTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7OztBQVJTLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsSUFBQSxXQUFBLE1BQUEsd0JBQUE7QUFDRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsV0FBQSxRQUFBLElBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLDBCQUFBLFdBQUEsNEJBQUEsSUFBQSxFQUFBOzs7OztBQVZaLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx3REFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLHdEQUFBLEdBQUEsQ0FBQTtBQVlMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7Ozs7QUFoQm1ELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsYUFBQSxPQUFBLFNBQUEsVUFBQSxDQUFBO0FBQzNDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLGNBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsT0FBQSxjQUFBLElBQUEsRUFBQTs7O0FETlosVUFRYTtBQVJiOzs7QUFRTSxJQUFPLDRCQUFQLE1BQU8sMkJBQXlCO01BQ3pCO01BQ0EscUJBQStCLENBQUE7TUFDL0IsY0FBYztNQUNkLHlCQUF5QjtNQUN6QixrQ0FBNEMsQ0FBQTtNQUVyRCxTQUFTLFNBQWE7QUFDbEIsZUFDSyxRQUFRLFNBQVMsS0FBSyxtQkFBbUIsU0FBUyxRQUFRLEtBQUssS0FDL0QsS0FBSywwQkFBMEIsUUFBUSw2QkFBNkIsS0FBSyxnQ0FBZ0MsU0FBUyxRQUFRLHlCQUF5QjtNQUU1Sjs7eUJBWlMsNEJBQXlCO01BQUE7aUVBQXpCLDRCQUF5QixXQUFBLENBQUEsQ0FBQSx3QkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFVBQUEsWUFBQSxvQkFBQSxzQkFBQSxhQUFBLGVBQUEsd0JBQUEsMEJBQUEsaUNBQUEsa0NBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsY0FBQSx5QkFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLG1CQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxtQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1J0QyxVQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLCtCQUFBLEdBQUEsMENBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQWtCSixVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLElBQUE7OztBQW5CSSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsUUFBQTs7Ozs7cUZET1MsMkJBQXlCLEVBQUEsV0FBQSw0QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVSdEMsU0FBUyxnQkFBZ0I7QUFLekIsU0FBUyxvQkFBb0I7O0FBTDdCLElBWWE7QUFaYjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVFNLElBQU8sNkJBQVAsTUFBTyw0QkFBMEI7O3lCQUExQiw2QkFBMEI7TUFBQTtnRUFBMUIsNEJBQTBCLENBQUE7b0VBSnpCLHFCQUFxQixZQUFZLEVBQUEsQ0FBQTs7OzsiLCJuYW1lcyI6WyJDb21wb25lbnQiLCJJbnB1dCIsIk9ic2VydmFibGUiLCJDb21wb25lbnQiLCJJbnB1dCIsIl9jMCJdfQ==