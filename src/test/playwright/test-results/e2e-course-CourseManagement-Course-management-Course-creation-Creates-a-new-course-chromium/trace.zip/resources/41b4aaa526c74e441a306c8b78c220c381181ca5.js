import {
  Exercise,
  ExerciseType,
  SubmissionService,
  __esm,
  createRequestOption,
  init_exercise_model,
  init_request_util,
  init_submission_service,
  init_utils,
  stringifyCircular
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/entities/file-upload-exercise.model.ts
var FileUploadExercise;
var init_file_upload_exercise_model = __esm({
  "src/main/webapp/app/entities/file-upload-exercise.model.ts"() {
    init_exercise_model();
    FileUploadExercise = class extends Exercise {
      filePattern;
      exampleSolution;
      constructor(course, exerciseGroup) {
        super(ExerciseType.FILE_UPLOAD);
        this.course = course;
        this.exerciseGroup = exerciseGroup;
      }
    };
  }
});

// src/main/webapp/app/exercises/file-upload/participate/file-upload-submission.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient, HttpParams } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var FileUploadSubmissionService;
var init_file_upload_submission_service = __esm({
  "src/main/webapp/app/exercises/file-upload/participate/file-upload-submission.service.ts"() {
    init_request_util();
    init_utils();
    init_submission_service();
    init_submission_service();
    FileUploadSubmissionService = class _FileUploadSubmissionService {
      http;
      submissionService;
      constructor(http, submissionService) {
        this.http = http;
        this.submissionService = submissionService;
      }
      update(fileUploadSubmission, exerciseId, submissionFile) {
        const copy = this.submissionService.convert(fileUploadSubmission);
        const formData = new FormData();
        const submissionBlob = new Blob([stringifyCircular(copy)], { type: "application/json" });
        formData.append("file", submissionFile);
        formData.append("submission", submissionBlob);
        return this.http.post(`api/exercises/${exerciseId}/file-upload-submissions`, formData, {
          observe: "response"
        }).pipe(map((res) => this.submissionService.convertSubmissionResponseFromServer(res)));
      }
      get(fileUploadSubmissionId, correctionRound = 0, resultId) {
        const url = `api/file-upload-submissions/${fileUploadSubmissionId}`;
        let params = new HttpParams();
        if (resultId && resultId > 0) {
          params = params.set("resultId", resultId.toString());
        } else {
          params = params.set("correction-round", correctionRound.toString());
        }
        return this.http.get(url, { params, observe: "response" }).pipe(map((res) => this.submissionService.convertSubmissionResponseFromServer(res)));
      }
      getSubmissions(exerciseId, req, correctionRound = 0) {
        const url = `api/exercises/${exerciseId}/file-upload-submissions`;
        let params = createRequestOption(req);
        if (correctionRound !== 0) {
          params = params.set("correction-round", correctionRound.toString());
        }
        return this.http.get(url, {
          params,
          observe: "response"
        }).pipe(map((res) => this.submissionService.convertArrayResponse(res)));
      }
      getSubmissionWithoutAssessment(exerciseId, lock, correctionRound = 0) {
        const url = `api/exercises/${exerciseId}/file-upload-submission-without-assessment`;
        let params = new HttpParams();
        if (correctionRound !== 0) {
          params = params.set("correction-round", correctionRound.toString());
        }
        if (lock) {
          params = params.set("lock", "true");
        }
        return this.http.get(url, { params }).pipe(map((res) => {
          if (!res) {
            return void 0;
          }
          return this.submissionService.convertSubmissionFromServer(res);
        }));
      }
      getDataForFileUploadEditor(participationId) {
        return this.http.get(`api/participations/${participationId}/file-upload-editor`, { responseType: "json" }).pipe(map((res) => this.submissionService.convertSubmissionFromServer(res)));
      }
      static \u0275fac = function FileUploadSubmissionService_Factory(t) {
        return new (t || _FileUploadSubmissionService)(i0.\u0275\u0275inject(i1.HttpClient), i0.\u0275\u0275inject(SubmissionService));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _FileUploadSubmissionService, factory: _FileUploadSubmissionService.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  FileUploadExercise,
  init_file_upload_exercise_model,
  FileUploadSubmissionService,
  init_file_upload_submission_service
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvZmlsZS11cGxvYWQtZXhlcmNpc2UubW9kZWwudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9maWxlLXVwbG9hZC9wYXJ0aWNpcGF0ZS9maWxlLXVwbG9hZC1zdWJtaXNzaW9uLnNlcnZpY2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRXhlcmNpc2UsIEV4ZXJjaXNlVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBDb3Vyc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvY291cnNlLm1vZGVsJztcbmltcG9ydCB7IEV4ZXJjaXNlR3JvdXAgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UtZ3JvdXAubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgRmlsZVVwbG9hZEV4ZXJjaXNlIGV4dGVuZHMgRXhlcmNpc2Uge1xuICAgIHB1YmxpYyBmaWxlUGF0dGVybj86IHN0cmluZztcbiAgICBwdWJsaWMgZXhhbXBsZVNvbHV0aW9uPzogc3RyaW5nO1xuXG4gICAgY29uc3RydWN0b3IoY291cnNlOiBDb3Vyc2UgfCB1bmRlZmluZWQsIGV4ZXJjaXNlR3JvdXA6IEV4ZXJjaXNlR3JvdXAgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgc3VwZXIoRXhlcmNpc2VUeXBlLkZJTEVfVVBMT0FEKTtcbiAgICAgICAgdGhpcy5jb3Vyc2UgPSBjb3Vyc2U7XG4gICAgICAgIHRoaXMuZXhlcmNpc2VHcm91cCA9IGV4ZXJjaXNlR3JvdXA7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cFBhcmFtcywgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuXG5pbXBvcnQgeyBGaWxlVXBsb2FkU3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9maWxlLXVwbG9hZC1zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IGNyZWF0ZVJlcXVlc3RPcHRpb24gfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvcmVxdWVzdC51dGlsJztcbmltcG9ydCB7IHN0cmluZ2lmeUNpcmN1bGFyIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL3V0aWxzJztcbmltcG9ydCB7IFN1Ym1pc3Npb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvc3VibWlzc2lvbi9zdWJtaXNzaW9uLnNlcnZpY2UnO1xuXG5leHBvcnQgdHlwZSBFbnRpdHlSZXNwb25zZVR5cGUgPSBIdHRwUmVzcG9uc2U8RmlsZVVwbG9hZFN1Ym1pc3Npb24+O1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIEZpbGVVcGxvYWRTdWJtaXNzaW9uU2VydmljZSB7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgaHR0cDogSHR0cENsaWVudCxcbiAgICAgICAgcHJpdmF0ZSBzdWJtaXNzaW9uU2VydmljZTogU3VibWlzc2lvblNlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlcyBGaWxlIFVwbG9hZCBzdWJtaXNzaW9uIG9uIHRoZSBzZXJ2ZXJcbiAgICAgKiBAcGFyYW0gZmlsZVVwbG9hZFN1Ym1pc3Npb24gdGhhdCB3aWxsIGJlIHVwZGF0ZWQgb24gdGhlIHNlcnZlclxuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkIGlkIG9mIHRoZSBleGVyY2lzZVxuICAgICAqIEBwYXJhbSBzdWJtaXNzaW9uRmlsZSB0aGUgZmlsZSBzdWJtaXR0ZWQgdGhhdCB3aWxsIGZvciB0aGUgZXhlcmNpc2VcbiAgICAgKi9cbiAgICB1cGRhdGUoZmlsZVVwbG9hZFN1Ym1pc3Npb246IEZpbGVVcGxvYWRTdWJtaXNzaW9uLCBleGVyY2lzZUlkOiBudW1iZXIsIHN1Ym1pc3Npb25GaWxlOiBGaWxlKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8RmlsZVVwbG9hZFN1Ym1pc3Npb24+PiB7XG4gICAgICAgIGNvbnN0IGNvcHkgPSB0aGlzLnN1Ym1pc3Npb25TZXJ2aWNlLmNvbnZlcnQoZmlsZVVwbG9hZFN1Ym1pc3Npb24pO1xuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xuICAgICAgICBjb25zdCBzdWJtaXNzaW9uQmxvYiA9IG5ldyBCbG9iKFtzdHJpbmdpZnlDaXJjdWxhcihjb3B5KV0sIHsgdHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nIH0pO1xuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ZpbGUnLCBzdWJtaXNzaW9uRmlsZSk7XG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnc3VibWlzc2lvbicsIHN1Ym1pc3Npb25CbG9iKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLnBvc3Q8RmlsZVVwbG9hZFN1Ym1pc3Npb24+KGBhcGkvZXhlcmNpc2VzLyR7ZXhlcmNpc2VJZH0vZmlsZS11cGxvYWQtc3VibWlzc2lvbnNgLCBmb3JtRGF0YSwge1xuICAgICAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEVudGl0eVJlc3BvbnNlVHlwZSkgPT4gdGhpcy5zdWJtaXNzaW9uU2VydmljZS5jb252ZXJ0U3VibWlzc2lvblJlc3BvbnNlRnJvbVNlcnZlcihyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBGaWxlIFVwbG9hZCBzdWJtaXNzaW9uIGZyb20gdGhlIHNlcnZlclxuICAgICAqIEBwYXJhbSBmaWxlVXBsb2FkU3VibWlzc2lvbklkIHRoZSBpZCBvZiB0aGUgRmlsZSBVcGxvYWQgc3VibWlzc2lvblxuICAgICAqIEBwYXJhbSBjb3JyZWN0aW9uUm91bmRcbiAgICAgKiBAcGFyYW0gcmVzdWx0SWRcbiAgICAgKi9cbiAgICBnZXQoZmlsZVVwbG9hZFN1Ym1pc3Npb25JZDogbnVtYmVyLCBjb3JyZWN0aW9uUm91bmQgPSAwLCByZXN1bHRJZD86IG51bWJlcik6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPEZpbGVVcGxvYWRTdWJtaXNzaW9uPj4ge1xuICAgICAgICBjb25zdCB1cmwgPSBgYXBpL2ZpbGUtdXBsb2FkLXN1Ym1pc3Npb25zLyR7ZmlsZVVwbG9hZFN1Ym1pc3Npb25JZH1gO1xuICAgICAgICBsZXQgcGFyYW1zID0gbmV3IEh0dHBQYXJhbXMoKTtcbiAgICAgICAgaWYgKHJlc3VsdElkICYmIHJlc3VsdElkID4gMCkge1xuICAgICAgICAgICAgLy8gaW4gY2FzZSByZXN1bHRJZCBpcyBzZXQsIHdlIGRvIG5vdCBuZWVkIHRoZSBjb3JyZWN0aW9uIHJvdW5kXG4gICAgICAgICAgICBwYXJhbXMgPSBwYXJhbXMuc2V0KCdyZXN1bHRJZCcsIHJlc3VsdElkIS50b1N0cmluZygpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHBhcmFtcyA9IHBhcmFtcy5zZXQoJ2NvcnJlY3Rpb24tcm91bmQnLCBjb3JyZWN0aW9uUm91bmQudG9TdHJpbmcoKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLmdldDxGaWxlVXBsb2FkU3VibWlzc2lvbj4odXJsLCB7IHBhcmFtcywgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEh0dHBSZXNwb25zZTxGaWxlVXBsb2FkU3VibWlzc2lvbj4pID0+IHRoaXMuc3VibWlzc2lvblNlcnZpY2UuY29udmVydFN1Ym1pc3Npb25SZXNwb25zZUZyb21TZXJ2ZXIocmVzKSkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgRmlsZSBVcGxvYWQgc3VibWlzc2lvbnMgZm9yIGV4ZXJjaXNlIGZyb20gdGhlIHNlcnZlclxuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkIHRoZSBpZCBvZiB0aGUgZXhlcmNpc2VcbiAgICAgKiBAcGFyYW0gcmVxIHJlcXVlc3QgcGFyYW1ldGVyc1xuICAgICAqIEBwYXJhbSBjb3JyZWN0aW9uUm91bmQgZm9yIHdoaWNoIHRvIGdldCB0aGUgU3VibWlzc2lvbnNcbiAgICAgKi9cbiAgICBnZXRTdWJtaXNzaW9ucyhleGVyY2lzZUlkOiBudW1iZXIsIHJlcTogeyBzdWJtaXR0ZWRPbmx5PzogYm9vbGVhbjsgYXNzZXNzZWRCeVR1dG9yPzogYm9vbGVhbiB9LCBjb3JyZWN0aW9uUm91bmQgPSAwKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8RmlsZVVwbG9hZFN1Ym1pc3Npb25bXT4+IHtcbiAgICAgICAgY29uc3QgdXJsID0gYGFwaS9leGVyY2lzZXMvJHtleGVyY2lzZUlkfS9maWxlLXVwbG9hZC1zdWJtaXNzaW9uc2A7XG4gICAgICAgIGxldCBwYXJhbXMgPSBjcmVhdGVSZXF1ZXN0T3B0aW9uKHJlcSk7XG4gICAgICAgIGlmIChjb3JyZWN0aW9uUm91bmQgIT09IDApIHtcbiAgICAgICAgICAgIHBhcmFtcyA9IHBhcmFtcy5zZXQoJ2NvcnJlY3Rpb24tcm91bmQnLCBjb3JyZWN0aW9uUm91bmQudG9TdHJpbmcoKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLmdldDxGaWxlVXBsb2FkU3VibWlzc2lvbltdPih1cmwsIHtcbiAgICAgICAgICAgICAgICBwYXJhbXMsXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlczogSHR0cFJlc3BvbnNlPEZpbGVVcGxvYWRTdWJtaXNzaW9uW10+KSA9PiB0aGlzLnN1Ym1pc3Npb25TZXJ2aWNlLmNvbnZlcnRBcnJheVJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIG5leHQgRmlsZSBVcGxvYWQgc3VibWlzc2lvbiB3aXRob3V0IGFzc2Vzc21lbnQgZnJvbSB0aGUgc2VydmVyXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlSWQgdGhlIGlkIG9mIHRoZSBleGVyY2lzZVxuICAgICAqIEBwYXJhbSBsb2NrXG4gICAgICogQHBhcmFtIGNvcnJlY3Rpb25Sb3VuZCBmb3Igd2hpY2ggdG8gZ2V0IHRoZSBTdWJtaXNzaW9uc1xuICAgICAqL1xuICAgIGdldFN1Ym1pc3Npb25XaXRob3V0QXNzZXNzbWVudChleGVyY2lzZUlkOiBudW1iZXIsIGxvY2s/OiBib29sZWFuLCBjb3JyZWN0aW9uUm91bmQgPSAwKTogT2JzZXJ2YWJsZTxGaWxlVXBsb2FkU3VibWlzc2lvbiB8IHVuZGVmaW5lZD4ge1xuICAgICAgICBjb25zdCB1cmwgPSBgYXBpL2V4ZXJjaXNlcy8ke2V4ZXJjaXNlSWR9L2ZpbGUtdXBsb2FkLXN1Ym1pc3Npb24td2l0aG91dC1hc3Nlc3NtZW50YDtcbiAgICAgICAgbGV0IHBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKCk7XG4gICAgICAgIGlmIChjb3JyZWN0aW9uUm91bmQgIT09IDApIHtcbiAgICAgICAgICAgIHBhcmFtcyA9IHBhcmFtcy5zZXQoJ2NvcnJlY3Rpb24tcm91bmQnLCBjb3JyZWN0aW9uUm91bmQudG9TdHJpbmcoKSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGxvY2spIHtcbiAgICAgICAgICAgIHBhcmFtcyA9IHBhcmFtcy5zZXQoJ2xvY2snLCAndHJ1ZScpO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8RmlsZVVwbG9hZFN1Ym1pc3Npb24gfCB1bmRlZmluZWQ+KHVybCwgeyBwYXJhbXMgfSkucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzPzogRmlsZVVwbG9hZFN1Ym1pc3Npb24pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIXJlcykge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5zdWJtaXNzaW9uU2VydmljZS5jb252ZXJ0U3VibWlzc2lvbkZyb21TZXJ2ZXIocmVzKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgZGF0YSBmb3IgRmlsZSBVcGxvYWQgZWRpdG9yIGZyb20gdGhlIHNlcnZlclxuICAgICAqIEBwYXJhbSBwYXJ0aWNpcGF0aW9uSWQgdGhlIGlkIG9mIHRoZSBwYXJ0aWNpcGF0aW9uXG4gICAgICovXG4gICAgZ2V0RGF0YUZvckZpbGVVcGxvYWRFZGl0b3IocGFydGljaXBhdGlvbklkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEZpbGVVcGxvYWRTdWJtaXNzaW9uPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5nZXQ8RmlsZVVwbG9hZFN1Ym1pc3Npb24+KGBhcGkvcGFydGljaXBhdGlvbnMvJHtwYXJ0aWNpcGF0aW9uSWR9L2ZpbGUtdXBsb2FkLWVkaXRvcmAsIHsgcmVzcG9uc2VUeXBlOiAnanNvbicgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBGaWxlVXBsb2FkU3VibWlzc2lvbikgPT4gdGhpcy5zdWJtaXNzaW9uU2VydmljZS5jb252ZXJ0U3VibWlzc2lvbkZyb21TZXJ2ZXIocmVzKSkpO1xuICAgIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUlhO0FBSmI7OztBQUlNLElBQU8scUJBQVAsY0FBa0MsU0FBUTtNQUNyQztNQUNBO01BRVAsWUFBWSxRQUE0QixlQUF3QztBQUM1RSxjQUFNLGFBQWEsV0FBVztBQUM5QixhQUFLLFNBQVM7QUFDZCxhQUFLLGdCQUFnQjtNQUN6Qjs7Ozs7O0FDWkosU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxZQUFZLGtCQUFnQztBQUVyRCxTQUFTLFdBQVc7OztBQUhwQixJQWFhO0FBYmI7O0FBTUE7QUFDQTtBQUNBOztBQUtNLElBQU8sOEJBQVAsTUFBTyw2QkFBMkI7TUFFeEI7TUFDQTtNQUZaLFlBQ1ksTUFDQSxtQkFBb0M7QUFEcEMsYUFBQSxPQUFBO0FBQ0EsYUFBQSxvQkFBQTtNQUNUO01BUUgsT0FBTyxzQkFBNEMsWUFBb0IsZ0JBQW9CO0FBQ3ZGLGNBQU0sT0FBTyxLQUFLLGtCQUFrQixRQUFRLG9CQUFvQjtBQUNoRSxjQUFNLFdBQVcsSUFBSSxTQUFRO0FBQzdCLGNBQU0saUJBQWlCLElBQUksS0FBSyxDQUFDLGtCQUFrQixJQUFJLENBQUMsR0FBRyxFQUFFLE1BQU0sbUJBQWtCLENBQUU7QUFDdkYsaUJBQVMsT0FBTyxRQUFRLGNBQWM7QUFDdEMsaUJBQVMsT0FBTyxjQUFjLGNBQWM7QUFDNUMsZUFBTyxLQUFLLEtBQ1AsS0FBMkIsaUJBQWlCLFVBQVUsNEJBQTRCLFVBQVU7VUFDekYsU0FBUztTQUNaLEVBQ0EsS0FBSyxJQUFJLENBQUMsUUFBNEIsS0FBSyxrQkFBa0Isb0NBQW9DLEdBQUcsQ0FBQyxDQUFDO01BQy9HO01BUUEsSUFBSSx3QkFBZ0Msa0JBQWtCLEdBQUcsVUFBaUI7QUFDdEUsY0FBTSxNQUFNLCtCQUErQixzQkFBc0I7QUFDakUsWUFBSSxTQUFTLElBQUksV0FBVTtBQUMzQixZQUFJLFlBQVksV0FBVyxHQUFHO0FBRTFCLG1CQUFTLE9BQU8sSUFBSSxZQUFZLFNBQVUsU0FBUSxDQUFFO2VBQ2pEO0FBQ0gsbUJBQVMsT0FBTyxJQUFJLG9CQUFvQixnQkFBZ0IsU0FBUSxDQUFFOztBQUV0RSxlQUFPLEtBQUssS0FDUCxJQUEwQixLQUFLLEVBQUUsUUFBUSxTQUFTLFdBQVUsQ0FBRSxFQUM5RCxLQUFLLElBQUksQ0FBQyxRQUE0QyxLQUFLLGtCQUFrQixvQ0FBb0MsR0FBRyxDQUFDLENBQUM7TUFDL0g7TUFRQSxlQUFlLFlBQW9CLEtBQTZELGtCQUFrQixHQUFDO0FBQy9HLGNBQU0sTUFBTSxpQkFBaUIsVUFBVTtBQUN2QyxZQUFJLFNBQVMsb0JBQW9CLEdBQUc7QUFDcEMsWUFBSSxvQkFBb0IsR0FBRztBQUN2QixtQkFBUyxPQUFPLElBQUksb0JBQW9CLGdCQUFnQixTQUFRLENBQUU7O0FBRXRFLGVBQU8sS0FBSyxLQUNQLElBQTRCLEtBQUs7VUFDOUI7VUFDQSxTQUFTO1NBQ1osRUFDQSxLQUFLLElBQUksQ0FBQyxRQUE4QyxLQUFLLGtCQUFrQixxQkFBcUIsR0FBRyxDQUFDLENBQUM7TUFDbEg7TUFRQSwrQkFBK0IsWUFBb0IsTUFBZ0Isa0JBQWtCLEdBQUM7QUFDbEYsY0FBTSxNQUFNLGlCQUFpQixVQUFVO0FBQ3ZDLFlBQUksU0FBUyxJQUFJLFdBQVU7QUFDM0IsWUFBSSxvQkFBb0IsR0FBRztBQUN2QixtQkFBUyxPQUFPLElBQUksb0JBQW9CLGdCQUFnQixTQUFRLENBQUU7O0FBRXRFLFlBQUksTUFBTTtBQUNOLG1CQUFTLE9BQU8sSUFBSSxRQUFRLE1BQU07O0FBR3RDLGVBQU8sS0FBSyxLQUFLLElBQXNDLEtBQUssRUFBRSxPQUFNLENBQUUsRUFBRSxLQUNwRSxJQUFJLENBQUMsUUFBOEI7QUFDL0IsY0FBSSxDQUFDLEtBQUs7QUFDTixtQkFBTzs7QUFFWCxpQkFBTyxLQUFLLGtCQUFrQiw0QkFBNEIsR0FBRztRQUNqRSxDQUFDLENBQUM7TUFFVjtNQU1BLDJCQUEyQixpQkFBdUI7QUFDOUMsZUFBTyxLQUFLLEtBQ1AsSUFBMEIsc0JBQXNCLGVBQWUsdUJBQXVCLEVBQUUsY0FBYyxPQUFNLENBQUUsRUFDOUcsS0FBSyxJQUFJLENBQUMsUUFBOEIsS0FBSyxrQkFBa0IsNEJBQTRCLEdBQUcsQ0FBQyxDQUFDO01BQ3pHOzt5QkFuR1MsOEJBQTJCLHNCQUFBLGFBQUEsR0FBQSxzQkFBQSxpQkFBQSxDQUFBO01BQUE7bUVBQTNCLDhCQUEyQixTQUEzQiw2QkFBMkIsV0FBQSxZQURkLE9BQU0sQ0FBQTs7OzsiLCJuYW1lcyI6W119