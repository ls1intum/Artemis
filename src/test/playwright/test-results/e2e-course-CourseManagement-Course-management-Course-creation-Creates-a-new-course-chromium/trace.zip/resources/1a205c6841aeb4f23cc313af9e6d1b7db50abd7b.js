import {
  init_iris_enabled_component
} from "/chunk-SAQIJY4A.js";
import {
  IrisChatSubSettings,
  IrisCodeEditorSubSettings,
  IrisHestiaSubSettings,
  IrisSettingsService,
  init_iris_settings_service,
  init_iris_sub_settings_model
} from "/chunk-VUYHOQDW.js";
import {
  IrisLogoComponent,
  IrisLogoLookDirection,
  IrisLogoSize,
  init_about_iris_component,
  init_iris_logo_component
} from "/chunk-2K363X3D.js";
import {
  UserService,
  init_user_service
} from "/chunk-L42QZYL5.js";
import {
  ArtemisMarkdownModule,
  HtmlForMarkdownPipe,
  init_html_for_markdown_pipe,
  init_markdown_module
} from "/chunk-UF4UUZTK.js";
import {
  ArtemisSharedComponentModule,
  init_shared_component_module
} from "/chunk-ORYTP7RT.js";
import {
  AccountService,
  AlertService,
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  ButtonComponent,
  ButtonType,
  CustomMaxDirective,
  CustomMinDirective,
  HelpIconComponent,
  JhiWebsocketService,
  TranslateDirective,
  __async,
  __esm,
  __spreadProps,
  __spreadValues,
  convertDateFromClient,
  convertDateFromServer,
  init_account_service,
  init_alert_service,
  init_artemis_translate_pipe,
  init_button_component,
  init_custom_max_validator_directive,
  init_custom_min_validator_directive,
  init_date_utils,
  init_help_icon_component,
  init_shared_module,
  init_translate_directive,
  init_websocket_service
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/entities/iris/settings/iris-settings.model.ts
var IrisSettingsType;
var init_iris_settings_model = __esm({
  "src/main/webapp/app/entities/iris/settings/iris-settings.model.ts"() {
    (function(IrisSettingsType2) {
      IrisSettingsType2["GLOBAL"] = "global";
      IrisSettingsType2["COURSE"] = "course";
      IrisSettingsType2["EXERCISE"] = "exercise";
    })(IrisSettingsType || (IrisSettingsType = {}));
  }
});

// src/main/webapp/app/iris/settings/iris-settings-update/iris-common-sub-settings-update/iris-common-sub-settings-update.component.ts
import { Component, EventEmitter, Input, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faTrash } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
function IrisCommonSubSettingsUpdateComponent_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "div", 0);
    i0.\u0275\u0275text(2, "\n        ");
    i0.\u0275\u0275elementStart(3, "input", 12);
    i0.\u0275\u0275listener("ngModelChange", function IrisCommonSubSettingsUpdateComponent_Conditional_16_Template_input_ngModelChange_3_listener($event) {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r5 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r5.inheritAllowedModels = $event);
    })("change", function IrisCommonSubSettingsUpdateComponent_Conditional_16_Template_input_change_3_listener() {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r7 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r7.onInheritAllowedModelsChange());
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n        ");
    i0.\u0275\u0275elementStart(5, "label", 13);
    i0.\u0275\u0275text(6, " Inherit ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("disabled", !ctx_r0.isAdmin)("ngModel", ctx_r0.inheritAllowedModels);
  }
}
function IrisCommonSubSettingsUpdateComponent_For_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "div", 14);
    i0.\u0275\u0275text(2, "\n            ");
    i0.\u0275\u0275elementStart(3, "input", 15);
    i0.\u0275\u0275listener("ngModelChange", function IrisCommonSubSettingsUpdateComponent_For_20_Template_input_ngModelChange_3_listener() {
      const restoredCtx = i0.\u0275\u0275restoreView(_r14);
      const model_r8 = restoredCtx.$implicit;
      const ctx_r13 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r13.onAllowedIrisModelsSelectionChange(model_r8));
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n            ");
    i0.\u0275\u0275elementStart(5, "label", 16);
    i0.\u0275\u0275text(6);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n    ");
  }
  if (rf & 2) {
    const model_r8 = ctx.$implicit;
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275propertyInterpolate("id", model_r8.id);
    i0.\u0275\u0275property("disabled", !ctx_r1.isAdmin || ctx_r1.inheritAllowedModels)("ngModel", ctx_r1.allowedIrisModels.includes(model_r8));
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275propertyInterpolate("for", model_r8.id);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate1("\n                ", model_r8.name, "\n            ");
  }
}
function IrisCommonSubSettingsUpdateComponent_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                ");
    i0.\u0275\u0275elementStart(1, "button", 17);
    i0.\u0275\u0275listener("click", function IrisCommonSubSettingsUpdateComponent_Conditional_37_Template_button_click_1_listener() {
      i0.\u0275\u0275restoreView(_r16);
      const ctx_r15 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r15.setModel(void 0));
    });
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    const ctx_r2 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275classProp("selected", (ctx_r2.subSettings == null ? null : ctx_r2.subSettings.preferredModel) === void 0);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate1("\n                    ", i0.\u0275\u0275pipeBind1(3, 3, "artemisApp.iris.settings.subSettings.models.preferredModel.inherit"), "\n                ");
  }
}
function IrisCommonSubSettingsUpdateComponent_For_39_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                ");
    i0.\u0275\u0275elementStart(1, "button", 18);
    i0.\u0275\u0275listener("click", function IrisCommonSubSettingsUpdateComponent_For_39_Template_button_click_1_listener() {
      const restoredCtx = i0.\u0275\u0275restoreView(_r23);
      const model_r17 = restoredCtx.$implicit;
      const ctx_r22 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r22.setModel(model_r17));
    });
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(3, "\n            ");
  }
  if (rf & 2) {
    const model_r17 = ctx.$implicit;
    const ctx_r3 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275classProp("selected", model_r17.id === (ctx_r3.subSettings == null ? null : ctx_r3.subSettings.preferredModel));
    i0.\u0275\u0275property("ngbTooltip", model_r17.description);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate1("\n                    ", model_r17.name, "\n                ");
  }
}
function IrisCommonSubSettingsUpdateComponent_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "span", 19);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(3, "\n    ");
  }
  if (rf & 2) {
    const ctx_r4 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(ctx_r4.getPreferredModelNameParent());
  }
}
var IrisCommonSubSettingsUpdateComponent;
var init_iris_common_sub_settings_update_component = __esm({
  "src/main/webapp/app/iris/settings/iris-settings-update/iris-common-sub-settings-update/iris-common-sub-settings-update.component.ts"() {
    init_iris_sub_settings_model();
    init_account_service();
    init_button_component();
    init_iris_settings_model();
    init_account_service();
    init_translate_directive();
    init_artemis_translate_pipe();
    IrisCommonSubSettingsUpdateComponent = class _IrisCommonSubSettingsUpdateComponent {
      subSettings;
      parentSubSettings;
      allIrisModels;
      settingsType;
      onChanges = new EventEmitter();
      isAdmin;
      inheritAllowedModels;
      allowedIrisModels;
      enabled;
      EXERCISE = IrisSettingsType.EXERCISE;
      WARNING = ButtonType.WARNING;
      faTrash = faTrash;
      constructor(accountService) {
        this.isAdmin = accountService.isAdmin();
      }
      ngOnInit() {
        this.enabled = this.subSettings?.enabled ?? false;
        this.allowedIrisModels = this.getAvailableModels();
        this.inheritAllowedModels = !!(!this.subSettings?.allowedModels && this.parentSubSettings);
      }
      ngOnChanges(changes) {
        if (changes.allIrisModels) {
          this.allowedIrisModels = this.getAvailableModels();
        }
        if (changes.subSettings) {
          this.enabled = this.subSettings?.enabled ?? false;
        }
      }
      getAvailableModels() {
        return this.allIrisModels.filter((model) => (this.subSettings?.allowedModels ?? this.parentSubSettings?.allowedModels ?? []).includes(model.id));
      }
      getPreferredModelName() {
        return this.allIrisModels.find((model) => model.id === this.subSettings?.preferredModel)?.name ?? this.subSettings?.preferredModel;
      }
      getPreferredModelNameParent() {
        return this.allIrisModels.find((model) => model.id === this.parentSubSettings?.preferredModel)?.name ?? this.parentSubSettings?.preferredModel;
      }
      onAllowedIrisModelsSelectionChange(model) {
        this.inheritAllowedModels = false;
        if (this.allowedIrisModels.includes(model)) {
          this.allowedIrisModels = this.allowedIrisModels.filter((m) => m !== model);
        } else {
          this.allowedIrisModels.push(model);
        }
        this.subSettings.allowedModels = this.allowedIrisModels.map((model2) => model2.id);
      }
      setModel(model) {
        this.subSettings.preferredModel = model?.id;
      }
      onEnabledChange() {
        this.subSettings.enabled = this.enabled;
      }
      onInheritAllowedModelsChange() {
        if (this.inheritAllowedModels) {
          this.subSettings.allowedModels = void 0;
          this.allowedIrisModels = this.getAvailableModels();
        } else {
          this.subSettings.allowedModels = this.allowedIrisModels.map((model) => model.id);
        }
      }
      static \u0275fac = function IrisCommonSubSettingsUpdateComponent_Factory(t) {
        return new (t || _IrisCommonSubSettingsUpdateComponent)(i0.\u0275\u0275directiveInject(AccountService));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _IrisCommonSubSettingsUpdateComponent, selectors: [["jhi-iris-common-sub-settings-update"]], inputs: { subSettings: "subSettings", parentSubSettings: "parentSubSettings", allIrisModels: "allIrisModels", settingsType: "settingsType" }, outputs: { onChanges: "onChanges" }, features: [i0.\u0275\u0275NgOnChangesFeature], decls: 44, vars: 8, consts: [[1, "form-check", "form-switch"], ["type", "checkbox", "id", "enabledDisabledSwitch", 1, "form-check-input", 3, "disabled", "ngModel", "ngModelChange", "change"], ["for", "enabledDisabledSwitch", "jhiTranslate", "artemisApp.iris.settings.subSettings.enabled-disabled", 1, "form-check-label"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.models.title", 1, "form-label", "mt-3"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.models.allowedModels.title", 1, "fw-bold", "fs-5"], [1, "form-group"], [1, "mt-3"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.models.preferredModel.title", 1, "fw-bold"], [1, "d-flex", "align-items-center"], ["ngbDropdown", "", 1, "d-inline-block"], ["id", "dropdownBasic1", "ngbDropdownToggle", "", 1, "btn", "btn-outline-primary", "w-100"], ["ngbDropdownMenu", "", "aria-labelledby", "dropdownBasic1"], ["type", "checkbox", "id", "inheritAllowedModelsSwitch", 1, "form-check-input", 3, "disabled", "ngModel", "ngModelChange", "change"], ["for", "inheritAllowedModelsSwitch", "jhiTranslate", "artemisApp.iris.settings.subSettings.models.allowedModels.inheritSwitch", 1, "form-check-label"], [1, "form-check"], ["type", "checkbox", 1, "form-check-input", 3, "id", "disabled", "ngModel", "ngModelChange"], [1, "form-check-label", 3, "for"], ["ngbDropdownItem", "", 3, "click"], ["ngbDropdownItem", "", 3, "ngbTooltip", "click"], [1, "ps-2", "text-secondary"]], template: function IrisCommonSubSettingsUpdateComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "div", 0);
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275elementStart(2, "input", 1);
          i0.\u0275\u0275listener("ngModelChange", function IrisCommonSubSettingsUpdateComponent_Template_input_ngModelChange_2_listener($event) {
            return ctx.enabled = $event;
          })("change", function IrisCommonSubSettingsUpdateComponent_Template_input_change_2_listener() {
            return ctx.onEnabledChange();
          });
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(3, "\n    ");
          i0.\u0275\u0275elementStart(4, "label", 2);
          i0.\u0275\u0275text(5, " Enabled/Disabled ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(6, "\n");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(7, "\n");
          i0.\u0275\u0275elementStart(8, "h4", 3);
          i0.\u0275\u0275text(9, "Models");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(10, "\n");
          i0.\u0275\u0275elementStart(11, "span")(12, "span", 4);
          i0.\u0275\u0275text(13, "Allowed Models");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(14, ": ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(15, "\n");
          i0.\u0275\u0275template(16, IrisCommonSubSettingsUpdateComponent_Conditional_16_Template, 9, 2);
          i0.\u0275\u0275elementStart(17, "div", 5);
          i0.\u0275\u0275text(18, "\n    ");
          i0.\u0275\u0275repeaterCreate(19, IrisCommonSubSettingsUpdateComponent_For_20_Template, 9, 5, null, null, i0.\u0275\u0275repeaterTrackByIdentity);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(21, "\n");
          i0.\u0275\u0275elementStart(22, "h5", 6)(23, "span", 7);
          i0.\u0275\u0275text(24, "Preferred Model");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(25, ":");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(26, "\n");
          i0.\u0275\u0275elementStart(27, "div", 8);
          i0.\u0275\u0275text(28, "\n    ");
          i0.\u0275\u0275elementStart(29, "div", 9);
          i0.\u0275\u0275text(30, "\n        ");
          i0.\u0275\u0275elementStart(31, "button", 10);
          i0.\u0275\u0275text(32);
          i0.\u0275\u0275pipe(33, "artemisTranslate");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(34, "\n        ");
          i0.\u0275\u0275elementStart(35, "div", 11);
          i0.\u0275\u0275text(36, "\n            ");
          i0.\u0275\u0275template(37, IrisCommonSubSettingsUpdateComponent_Conditional_37_Template, 5, 5);
          i0.\u0275\u0275repeaterCreate(38, IrisCommonSubSettingsUpdateComponent_For_39_Template, 4, 4, null, null, i0.\u0275\u0275repeaterTrackByIdentity);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(40, "\n    ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(41, "\n    ");
          i0.\u0275\u0275template(42, IrisCommonSubSettingsUpdateComponent_Conditional_42_Template, 4, 1);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(43, "\n");
        }
        if (rf & 2) {
          let tmp_4_0;
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275property("disabled", !ctx.isAdmin && ctx.settingsType !== ctx.EXERCISE)("ngModel", ctx.enabled);
          i0.\u0275\u0275advance(14);
          i0.\u0275\u0275conditional(16, ctx.parentSubSettings ? 16 : -1);
          i0.\u0275\u0275advance(3);
          i0.\u0275\u0275repeater(ctx.allIrisModels);
          i0.\u0275\u0275advance(13);
          i0.\u0275\u0275textInterpolate1("\n            ", (tmp_4_0 = ctx.getPreferredModelName()) !== null && tmp_4_0 !== void 0 ? tmp_4_0 : i0.\u0275\u0275pipeBind1(33, 6, "artemisApp.iris.settings.subSettings.models.preferredModel.inherit"), "\n        ");
          i0.\u0275\u0275advance(5);
          i0.\u0275\u0275conditional(37, ctx.parentSubSettings ? 37 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275repeater(ctx.allowedIrisModels);
          i0.\u0275\u0275advance(4);
          i0.\u0275\u0275conditional(42, !(ctx.subSettings == null ? null : ctx.subSettings.preferredModel) ? 42 : -1);
        }
      }, dependencies: [i2.CheckboxControlValueAccessor, i2.NgControlStatus, i2.NgModel, i3.NgbDropdown, i3.NgbDropdownToggle, i3.NgbDropdownMenu, i3.NgbDropdownItem, i3.NgbDropdownButtonItem, i3.NgbTooltip, TranslateDirective, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(IrisCommonSubSettingsUpdateComponent, { className: "IrisCommonSubSettingsUpdateComponent" });
    })();
  }
});

// src/main/webapp/app/entities/iris/settings/iris-template.ts
var IrisTemplate;
var init_iris_template = __esm({
  "src/main/webapp/app/entities/iris/settings/iris-template.ts"() {
    IrisTemplate = class {
      id;
      content = "";
    };
  }
});

// src/main/webapp/app/iris/settings/iris-settings-update/iris-chat-sub-settings-update/iris-chat-sub-settings-update.component.ts
import { Component as Component2, EventEmitter as EventEmitter2, Input as Input2, Output as Output2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
function IrisChatSubSettingsUpdateComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n    ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n        ");
    i02.\u0275\u0275elementStart(3, "label", 3);
    i02.\u0275\u0275text(4, "Rate Limit");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n        ");
    i02.\u0275\u0275element(6, "jhi-help-icon", 4);
    i02.\u0275\u0275text(7, "\n        ");
    i02.\u0275\u0275elementStart(8, "input", 5);
    i02.\u0275\u0275listener("ngModelChange", function IrisChatSubSettingsUpdateComponent_Conditional_0_Template_input_ngModelChange_8_listener($event) {
      i02.\u0275\u0275restoreView(_r4);
      const ctx_r3 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r3.subSettings.rateLimit = $event);
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("text", "artemisApp.iris.settings.subSettings.rateLimitTooltip");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("customMin", -1)("customMax", 1e6)("ngModel", ctx_r0.subSettings.rateLimit);
  }
}
function IrisChatSubSettingsUpdateComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n    ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n        ");
    i02.\u0275\u0275elementStart(3, "label", 6);
    i02.\u0275\u0275text(4, "Rate Limit Timeframe (Hours)");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n        ");
    i02.\u0275\u0275element(6, "jhi-help-icon", 4);
    i02.\u0275\u0275text(7, "\n        ");
    i02.\u0275\u0275elementStart(8, "input", 7);
    i02.\u0275\u0275listener("ngModelChange", function IrisChatSubSettingsUpdateComponent_Conditional_1_Template_input_ngModelChange_8_listener($event) {
      i02.\u0275\u0275restoreView(_r6);
      const ctx_r5 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r5.subSettings.rateLimitTimeframeHours = $event);
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("text", "artemisApp.iris.settings.subSettings.rateLimitTimeframeHoursTooltip");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("customMin", 0)("customMax", 1e6)("ngModel", ctx_r1.subSettings.rateLimitTimeframeHours);
  }
}
function IrisChatSubSettingsUpdateComponent_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n        ");
    i02.\u0275\u0275elementStart(1, "div", 8);
    i02.\u0275\u0275text(2, "\n            ");
    i02.\u0275\u0275elementStart(3, "input", 9);
    i02.\u0275\u0275listener("change", function IrisChatSubSettingsUpdateComponent_Conditional_7_Template_input_change_3_listener() {
      i02.\u0275\u0275restoreView(_r8);
      const ctx_r7 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r7.onInheritTemplateChanged());
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n            ");
    i02.\u0275\u0275elementStart(5, "label", 10);
    i02.\u0275\u0275text(6, "Inherit");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n    ");
  }
  if (rf & 2) {
    const ctx_r2 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("checked", !(ctx_r2.subSettings == null ? null : ctx_r2.subSettings.template));
  }
}
var IrisChatSubSettingsUpdateComponent;
var init_iris_chat_sub_settings_update_component = __esm({
  "src/main/webapp/app/iris/settings/iris-settings-update/iris-chat-sub-settings-update/iris-chat-sub-settings-update.component.ts"() {
    init_iris_template();
    init_iris_sub_settings_model();
    init_translate_directive();
    init_custom_min_validator_directive();
    init_custom_max_validator_directive();
    init_help_icon_component();
    IrisChatSubSettingsUpdateComponent = class _IrisChatSubSettingsUpdateComponent {
      subSettings;
      parentSubSettings;
      rateLimitSettable = false;
      onChanges = new EventEmitter2();
      previousTemplate;
      isAdmin;
      templateContent;
      ngOnInit() {
        this.templateContent = this.subSettings?.template?.content ?? this.parentSubSettings?.template?.content ?? "";
      }
      ngOnChanges(changes) {
        if (changes.subSettings || changes.parentSubSettings) {
          this.templateContent = this.subSettings?.template?.content ?? this.parentSubSettings?.template?.content ?? "";
        }
      }
      onInheritTemplateChanged() {
        if (this.subSettings?.template) {
          this.previousTemplate = this.subSettings?.template;
          this.subSettings.template = void 0;
          this.templateContent = this.parentSubSettings?.template?.content ?? "";
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = "";
          this.subSettings.template = this.previousTemplate ?? irisTemplate;
        }
      }
      onTemplateChanged() {
        if (this.subSettings?.template) {
          this.subSettings.template.content = this.templateContent;
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = this.templateContent;
          this.subSettings.template = irisTemplate;
        }
      }
      static \u0275fac = function IrisChatSubSettingsUpdateComponent_Factory(t) {
        return new (t || _IrisChatSubSettingsUpdateComponent)();
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _IrisChatSubSettingsUpdateComponent, selectors: [["jhi-iris-chat-sub-settings-update"]], inputs: { subSettings: "subSettings", parentSubSettings: "parentSubSettings", rateLimitSettable: "rateLimitSettable" }, outputs: { onChanges: "onChanges" }, features: [i02.\u0275\u0275NgOnChangesFeature], decls: 11, vars: 5, consts: [[1, "mb-3", "mt-3"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.template.title"], ["id", "template-editor", "rows", "25", 1, "form-control", 3, "ngModel", "disabled", "ngModelChange", "change"], ["for", "rateLimit", "jhiTranslate", "artemisApp.iris.settings.subSettings.rateLimit", 1, "form-check-label"], [3, "text"], ["id", "rateLimit", "name", "rateLimit", "type", "number", 1, "form-control", 3, "customMin", "customMax", "ngModel", "ngModelChange"], ["for", "rateLimitTimeframeHours", "jhiTranslate", "artemisApp.iris.settings.subSettings.rateLimitTimeframeHours", 1, "form-check-label"], ["id", "rateLimitTimeframeHours", "name", "rateLimitTimeframeHours", "type", "number", 1, "form-control", 3, "customMin", "customMax", "ngModel", "ngModelChange"], [1, "form-check", "form-switch"], ["type", "checkbox", "id", "inheritTemplate", 1, "form-check-input", 3, "checked", "change"], ["for", "inheritTemplate", "jhiTranslate", "artemisApp.iris.settings.subSettings.template.inherit", 1, "form-check-label"]], template: function IrisChatSubSettingsUpdateComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275template(0, IrisChatSubSettingsUpdateComponent_Conditional_0_Template, 11, 4)(1, IrisChatSubSettingsUpdateComponent_Conditional_1_Template, 11, 4);
          i02.\u0275\u0275elementStart(2, "div", 0);
          i02.\u0275\u0275text(3, "\n    ");
          i02.\u0275\u0275elementStart(4, "h4", 1);
          i02.\u0275\u0275text(5, "Template");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(6, "\n    ");
          i02.\u0275\u0275template(7, IrisChatSubSettingsUpdateComponent_Conditional_7_Template, 9, 1);
          i02.\u0275\u0275elementStart(8, "textarea", 2);
          i02.\u0275\u0275listener("ngModelChange", function IrisChatSubSettingsUpdateComponent_Template_textarea_ngModelChange_8_listener($event) {
            return ctx.templateContent = $event;
          })("change", function IrisChatSubSettingsUpdateComponent_Template_textarea_change_8_listener() {
            return ctx.onTemplateChanged();
          });
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(9, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(10, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275conditional(0, ctx.rateLimitSettable ? 0 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(1, ctx.rateLimitSettable ? 1 : -1);
          i02.\u0275\u0275advance(6);
          i02.\u0275\u0275conditional(7, ctx.parentSubSettings ? 7 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275property("ngModel", ctx.templateContent)("disabled", !(ctx.subSettings == null ? null : ctx.subSettings.template));
        }
      }, dependencies: [i1.DefaultValueAccessor, i1.NumberValueAccessor, i1.NgControlStatus, i1.NgModel, TranslateDirective, CustomMinDirective, CustomMaxDirective, HelpIconComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(IrisChatSubSettingsUpdateComponent, { className: "IrisChatSubSettingsUpdateComponent" });
    })();
  }
});

// src/main/webapp/app/iris/settings/iris-settings-update/iris-hestia-sub-settings-update/iris-hestia-sub-settings-update.component.ts
import { Component as Component3, EventEmitter as EventEmitter3, Input as Input3, Output as Output3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
function IrisHestiaSubSettingsUpdateComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275elementStart(1, "div", 3);
    i03.\u0275\u0275text(2, "\n            ");
    i03.\u0275\u0275elementStart(3, "input", 4);
    i03.\u0275\u0275listener("change", function IrisHestiaSubSettingsUpdateComponent_Conditional_5_Template_input_change_3_listener() {
      i03.\u0275\u0275restoreView(_r2);
      const ctx_r1 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r1.onInheritTemplateChanged());
    });
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(4, "\n            ");
    i03.\u0275\u0275elementStart(5, "label", 5);
    i03.\u0275\u0275text(6, "Inherit");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(7, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("checked", !(ctx_r0.subSettings == null ? null : ctx_r0.subSettings.template));
  }
}
var IrisHestiaSubSettingsUpdateComponent;
var init_iris_hestia_sub_settings_update_component = __esm({
  "src/main/webapp/app/iris/settings/iris-settings-update/iris-hestia-sub-settings-update/iris-hestia-sub-settings-update.component.ts"() {
    init_iris_template();
    init_iris_sub_settings_model();
    init_translate_directive();
    IrisHestiaSubSettingsUpdateComponent = class _IrisHestiaSubSettingsUpdateComponent {
      subSettings;
      parentSubSettings;
      onChanges = new EventEmitter3();
      previousTemplate;
      isAdmin;
      templateContent;
      ngOnInit() {
        this.templateContent = this.subSettings.template?.content ?? this.parentSubSettings?.template?.content ?? "";
      }
      ngOnChanges(changes) {
        if (changes.subSettings || changes.parentSubSettings) {
          this.templateContent = this.subSettings?.template?.content ?? this.parentSubSettings?.template?.content ?? "";
        }
      }
      onInheritTemplateChanged() {
        if (this.subSettings.template) {
          this.previousTemplate = this.subSettings.template;
          this.subSettings.template = void 0;
          this.templateContent = this.parentSubSettings?.template?.content ?? "";
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = "";
          this.subSettings.template = this.previousTemplate ?? irisTemplate;
        }
      }
      onTemplateChanged() {
        if (this.subSettings.template) {
          this.subSettings.template.content = this.templateContent;
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = this.templateContent;
          this.subSettings.template = irisTemplate;
        }
      }
      static \u0275fac = function IrisHestiaSubSettingsUpdateComponent_Factory(t) {
        return new (t || _IrisHestiaSubSettingsUpdateComponent)();
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _IrisHestiaSubSettingsUpdateComponent, selectors: [["jhi-iris-hestia-sub-settings-update"]], inputs: { subSettings: "subSettings", parentSubSettings: "parentSubSettings" }, outputs: { onChanges: "onChanges" }, features: [i03.\u0275\u0275NgOnChangesFeature], decls: 9, vars: 3, consts: [[1, "mb-3", "mt-3"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.template.title"], ["id", "template-editor", "rows", "25", 1, "form-control", 3, "ngModel", "disabled", "ngModelChange", "change"], [1, "form-check", "form-switch"], ["type", "checkbox", "id", "inheritTemplate", 1, "form-check-input", 3, "checked", "change"], ["for", "inheritTemplate", "jhiTranslate", "artemisApp.iris.settings.subSettings.template.inherit", 1, "form-check-label"]], template: function IrisHestiaSubSettingsUpdateComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "div", 0);
          i03.\u0275\u0275text(1, "\n    ");
          i03.\u0275\u0275elementStart(2, "h4", 1);
          i03.\u0275\u0275text(3, "Template");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(4, "\n    ");
          i03.\u0275\u0275template(5, IrisHestiaSubSettingsUpdateComponent_Conditional_5_Template, 9, 1);
          i03.\u0275\u0275elementStart(6, "textarea", 2);
          i03.\u0275\u0275listener("ngModelChange", function IrisHestiaSubSettingsUpdateComponent_Template_textarea_ngModelChange_6_listener($event) {
            return ctx.templateContent = $event;
          })("change", function IrisHestiaSubSettingsUpdateComponent_Template_textarea_change_6_listener() {
            return ctx.onTemplateChanged();
          });
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(7, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(8, "\n");
        }
        if (rf & 2) {
          i03.\u0275\u0275advance(5);
          i03.\u0275\u0275conditional(5, ctx.parentSubSettings ? 5 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275property("ngModel", ctx.templateContent)("disabled", !(ctx.subSettings == null ? null : ctx.subSettings.template));
        }
      }, dependencies: [i12.DefaultValueAccessor, i12.NgControlStatus, i12.NgModel, TranslateDirective], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(IrisHestiaSubSettingsUpdateComponent, { className: "IrisHestiaSubSettingsUpdateComponent" });
    })();
  }
});

// src/main/webapp/app/iris/settings/iris-settings-update/iris-global-autoupdate-settings-update/iris-global-autoupdate-settings-update.component.ts
import { Component as Component4, EventEmitter as EventEmitter4, Input as Input4, Output as Output4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
function IrisGlobalAutoupdateSettingsUpdateComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n    ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n        ");
    i04.\u0275\u0275elementStart(3, "div", 0);
    i04.\u0275\u0275text(4, "\n            ");
    i04.\u0275\u0275elementStart(5, "input", 1);
    i04.\u0275\u0275listener("ngModelChange", function IrisGlobalAutoupdateSettingsUpdateComponent_Conditional_0_Template_input_ngModelChange_5_listener($event) {
      i04.\u0275\u0275restoreView(_r2);
      const ctx_r1 = i04.\u0275\u0275nextContext();
      return i04.\u0275\u0275resetView(ctx_r1.irisSettings.enableAutoUpdateChat = $event);
    });
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(6, "\n            ");
    i04.\u0275\u0275elementStart(7, "label", 2);
    i04.\u0275\u0275text(8, " Auto-update Chat Settings ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(9, "\n        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n        ");
    i04.\u0275\u0275elementStart(11, "div", 0);
    i04.\u0275\u0275text(12, "\n            ");
    i04.\u0275\u0275elementStart(13, "input", 3);
    i04.\u0275\u0275listener("ngModelChange", function IrisGlobalAutoupdateSettingsUpdateComponent_Conditional_0_Template_input_ngModelChange_13_listener($event) {
      i04.\u0275\u0275restoreView(_r2);
      const ctx_r3 = i04.\u0275\u0275nextContext();
      return i04.\u0275\u0275resetView(ctx_r3.irisSettings.enableAutoUpdateHestia = $event);
    });
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(14, "\n            ");
    i04.\u0275\u0275elementStart(15, "label", 4);
    i04.\u0275\u0275text(16, " Auto-update Hestia Settings ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(17, "\n        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(18, "\n        ");
    i04.\u0275\u0275elementStart(19, "div", 0);
    i04.\u0275\u0275text(20, "\n            ");
    i04.\u0275\u0275elementStart(21, "input", 5);
    i04.\u0275\u0275listener("ngModelChange", function IrisGlobalAutoupdateSettingsUpdateComponent_Conditional_0_Template_input_ngModelChange_21_listener($event) {
      i04.\u0275\u0275restoreView(_r2);
      const ctx_r4 = i04.\u0275\u0275nextContext();
      return i04.\u0275\u0275resetView(ctx_r4.irisSettings.enableAutoUpdateCodeEditor = $event);
    });
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(22, "\n            ");
    i04.\u0275\u0275elementStart(23, "label", 6);
    i04.\u0275\u0275text(24, " Auto-update Code Editor Settings ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(25, "\n        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(26, "\n    ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(27, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(5);
    i04.\u0275\u0275property("ngModel", ctx_r0.irisSettings.enableAutoUpdateChat);
    i04.\u0275\u0275advance(8);
    i04.\u0275\u0275property("ngModel", ctx_r0.irisSettings.enableAutoUpdateHestia);
    i04.\u0275\u0275advance(8);
    i04.\u0275\u0275property("ngModel", ctx_r0.irisSettings.enableAutoUpdateCodeEditor);
  }
}
var IrisGlobalAutoupdateSettingsUpdateComponent;
var init_iris_global_autoupdate_settings_update_component = __esm({
  "src/main/webapp/app/iris/settings/iris-settings-update/iris-global-autoupdate-settings-update/iris-global-autoupdate-settings-update.component.ts"() {
    init_iris_settings_model();
    init_translate_directive();
    IrisGlobalAutoupdateSettingsUpdateComponent = class _IrisGlobalAutoupdateSettingsUpdateComponent {
      irisSettings;
      onChanges = new EventEmitter4();
      static \u0275fac = function IrisGlobalAutoupdateSettingsUpdateComponent_Factory(t) {
        return new (t || _IrisGlobalAutoupdateSettingsUpdateComponent)();
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _IrisGlobalAutoupdateSettingsUpdateComponent, selectors: [["jhi-iris-global-autoupdate-settings-update"]], inputs: { irisSettings: "irisSettings" }, outputs: { onChanges: "onChanges" }, decls: 1, vars: 1, consts: [[1, "form-check", "form-switch"], ["type", "checkbox", "id", "autoUpdateChat", 1, "form-check-input", 3, "ngModel", "ngModelChange"], ["for", "autoUpdateChat", "jhiTranslate", "artemisApp.iris.settings.autoUpdate.chatLabel", 1, "form-check-label"], ["type", "checkbox", "id", "autoUpdateHestia", 1, "form-check-input", 3, "ngModel", "ngModelChange"], ["for", "autoUpdateHestia", "jhiTranslate", "artemisApp.iris.settings.autoUpdate.hestiaLabel", 1, "form-check-label"], ["type", "checkbox", "id", "autoUpdateCodeEditor", 1, "form-check-input", 3, "ngModel", "ngModelChange"], ["for", "autoUpdateCodeEditor", "jhiTranslate", "artemisApp.iris.settings.autoUpdate.codeEditorLabel", 1, "form-check-label"]], template: function IrisGlobalAutoupdateSettingsUpdateComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275template(0, IrisGlobalAutoupdateSettingsUpdateComponent_Conditional_0_Template, 28, 3);
        }
        if (rf & 2) {
          i04.\u0275\u0275conditional(0, ctx.irisSettings ? 0 : -1);
        }
      }, dependencies: [i13.CheckboxControlValueAccessor, i13.NgControlStatus, i13.NgModel, TranslateDirective], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(IrisGlobalAutoupdateSettingsUpdateComponent, { className: "IrisGlobalAutoupdateSettingsUpdateComponent" });
    })();
  }
});

// src/main/webapp/app/iris/settings/iris-settings-update/iris-code-editor-sub-settings-update/iris-code-editor-sub-settings-update.component.ts
import { Component as Component5, EventEmitter as EventEmitter5, Input as Input5, Output as Output5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i14 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
function IrisCodeEditorSubSettingsUpdateComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n        ");
    i05.\u0275\u0275elementStart(1, "div", 12);
    i05.\u0275\u0275text(2, "\n            ");
    i05.\u0275\u0275elementStart(3, "input", 13);
    i05.\u0275\u0275listener("change", function IrisCodeEditorSubSettingsUpdateComponent_Conditional_5_Template_input_change_3_listener() {
      i05.\u0275\u0275restoreView(_r2);
      const ctx_r1 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r1.onInheritTemplateChanged());
    });
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n            ");
    i05.\u0275\u0275elementStart(5, "label", 14);
    i05.\u0275\u0275text(6, "Inherit");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(7, "\n        ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(8, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275property("checked", !(ctx_r0.subSettings == null ? null : ctx_r0.subSettings.chatTemplate));
  }
}
var IrisCodeEditorSubSettingsUpdateComponent;
var init_iris_code_editor_sub_settings_update_component = __esm({
  "src/main/webapp/app/iris/settings/iris-settings-update/iris-code-editor-sub-settings-update/iris-code-editor-sub-settings-update.component.ts"() {
    init_iris_template();
    init_iris_sub_settings_model();
    init_translate_directive();
    IrisCodeEditorSubSettingsUpdateComponent = class _IrisCodeEditorSubSettingsUpdateComponent {
      subSettings;
      parentSubSettings;
      onChanges = new EventEmitter5();
      previousChatTemplate;
      previousProblemStatementGenerationTemplate;
      previousTemplateRepoGenerationTemplate;
      previousSolutionRepoGenerationTemplate;
      previousTestRepoGenerationTemplate;
      chatTemplateContent;
      problemStatementGenerationTemplateContent;
      templateRepoGenerationTemplateContent;
      solutionRepoGenerationTemplateContent;
      testRepoGenerationTemplateContent;
      ngOnInit() {
        this.resetTemplates();
      }
      ngOnChanges(changes) {
        if (changes.subSettings || changes.parentSubSettings) {
          this.resetTemplates();
        }
      }
      resetTemplates() {
        this.chatTemplateContent = this.subSettings?.chatTemplate?.content ?? this.parentSubSettings?.chatTemplate?.content ?? "";
        this.problemStatementGenerationTemplateContent = this.subSettings?.problemStatementGenerationTemplate?.content ?? this.parentSubSettings?.problemStatementGenerationTemplate?.content ?? "";
        this.templateRepoGenerationTemplateContent = this.subSettings?.templateRepoGenerationTemplate?.content ?? this.parentSubSettings?.templateRepoGenerationTemplate?.content ?? "";
        this.solutionRepoGenerationTemplateContent = this.subSettings?.solutionRepoGenerationTemplate?.content ?? this.parentSubSettings?.solutionRepoGenerationTemplate?.content ?? "";
        this.testRepoGenerationTemplateContent = this.subSettings?.testRepoGenerationTemplate?.content ?? this.parentSubSettings?.testRepoGenerationTemplate?.content ?? "";
      }
      onInheritTemplateChanged() {
        if (this.subSettings?.chatTemplate) {
          this.previousChatTemplate = this.subSettings?.chatTemplate;
          this.subSettings.chatTemplate = void 0;
          this.chatTemplateContent = this.parentSubSettings?.chatTemplate?.content ?? "";
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = "";
          this.subSettings.chatTemplate = this.previousChatTemplate ?? irisTemplate;
        }
        if (this.subSettings?.problemStatementGenerationTemplate) {
          this.previousProblemStatementGenerationTemplate = this.subSettings?.problemStatementGenerationTemplate;
          this.subSettings.problemStatementGenerationTemplate = void 0;
          this.problemStatementGenerationTemplateContent = this.parentSubSettings?.problemStatementGenerationTemplate?.content ?? "";
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = "";
          this.subSettings.problemStatementGenerationTemplate = this.previousProblemStatementGenerationTemplate ?? irisTemplate;
        }
        if (this.subSettings?.templateRepoGenerationTemplate) {
          this.previousTemplateRepoGenerationTemplate = this.subSettings?.templateRepoGenerationTemplate;
          this.subSettings.templateRepoGenerationTemplate = void 0;
          this.templateRepoGenerationTemplateContent = this.parentSubSettings?.templateRepoGenerationTemplate?.content ?? "";
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = "";
          this.subSettings.templateRepoGenerationTemplate = this.previousTemplateRepoGenerationTemplate ?? irisTemplate;
        }
        if (this.subSettings?.solutionRepoGenerationTemplate) {
          this.previousSolutionRepoGenerationTemplate = this.subSettings?.solutionRepoGenerationTemplate;
          this.subSettings.solutionRepoGenerationTemplate = void 0;
          this.solutionRepoGenerationTemplateContent = this.parentSubSettings?.solutionRepoGenerationTemplate?.content ?? "";
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = "";
          this.subSettings.solutionRepoGenerationTemplate = this.previousSolutionRepoGenerationTemplate ?? irisTemplate;
        }
        if (this.subSettings?.testRepoGenerationTemplate) {
          this.previousTestRepoGenerationTemplate = this.subSettings?.testRepoGenerationTemplate;
          this.subSettings.testRepoGenerationTemplate = void 0;
          this.testRepoGenerationTemplateContent = this.parentSubSettings?.testRepoGenerationTemplate?.content ?? "";
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = "";
          this.subSettings.testRepoGenerationTemplate = this.previousTestRepoGenerationTemplate ?? irisTemplate;
        }
      }
      onTemplateChanged() {
        if (this.subSettings?.chatTemplate) {
          this.subSettings.chatTemplate.content = this.chatTemplateContent;
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = this.chatTemplateContent;
          this.subSettings.chatTemplate = irisTemplate;
        }
        if (this.subSettings?.problemStatementGenerationTemplate) {
          this.subSettings.problemStatementGenerationTemplate.content = this.problemStatementGenerationTemplateContent;
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = this.problemStatementGenerationTemplateContent;
          this.subSettings.problemStatementGenerationTemplate = irisTemplate;
        }
        if (this.subSettings?.templateRepoGenerationTemplate) {
          this.subSettings.templateRepoGenerationTemplate.content = this.templateRepoGenerationTemplateContent;
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = this.templateRepoGenerationTemplateContent;
          this.subSettings.templateRepoGenerationTemplate = irisTemplate;
        }
        if (this.subSettings?.solutionRepoGenerationTemplate) {
          this.subSettings.solutionRepoGenerationTemplate.content = this.solutionRepoGenerationTemplateContent;
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = this.solutionRepoGenerationTemplateContent;
          this.subSettings.solutionRepoGenerationTemplate = irisTemplate;
        }
        if (this.subSettings?.testRepoGenerationTemplate) {
          this.subSettings.testRepoGenerationTemplate.content = this.testRepoGenerationTemplateContent;
        } else {
          const irisTemplate = new IrisTemplate();
          irisTemplate.content = this.testRepoGenerationTemplateContent;
          this.subSettings.testRepoGenerationTemplate = irisTemplate;
        }
      }
      static \u0275fac = function IrisCodeEditorSubSettingsUpdateComponent_Factory(t) {
        return new (t || _IrisCodeEditorSubSettingsUpdateComponent)();
      };
      static \u0275cmp = i05.\u0275\u0275defineComponent({ type: _IrisCodeEditorSubSettingsUpdateComponent, selectors: [["jhi-iris-code-editor-sub-settings-update"]], inputs: { subSettings: "subSettings", parentSubSettings: "parentSubSettings" }, outputs: { onChanges: "onChanges" }, features: [i05.\u0275\u0275NgOnChangesFeature], decls: 47, vars: 11, consts: [[1, "mb-3", "mt-3"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.codeEditor.templates"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.codeEditor.chatTemplate"], ["id", "chat-template-editor", "rows", "25", 1, "form-control", 3, "ngModel", "disabled", "ngModelChange", "change"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.codeEditor.problemStatementTemplate"], ["id", "problem-statement-template-editor", "rows", "25", 1, "form-control", 3, "ngModel", "disabled", "ngModelChange", "change"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.codeEditor.templateRepoTemplate"], ["id", "template-repo-template-editor", "rows", "25", 1, "form-control", 3, "ngModel", "disabled", "ngModelChange", "change"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.codeEditor.solutionRepoTemplate"], ["id", "solution-repo-template-editor", "rows", "25", 1, "form-control", 3, "ngModel", "disabled", "ngModelChange", "change"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.codeEditor.testRepoTemplate"], ["id", "test-repo-template-editor", "rows", "25", 1, "form-control", 3, "ngModel", "disabled", "ngModelChange", "change"], [1, "form-check", "form-switch"], ["type", "checkbox", "id", "inheritTemplate", 1, "form-check-input", 3, "checked", "change"], ["for", "inheritTemplate", "jhiTranslate", "artemisApp.iris.settings.subSettings.codeEditor.templatesInheritSwitch", 1, "form-check-label"]], template: function IrisCodeEditorSubSettingsUpdateComponent_Template(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275elementStart(0, "div", 0);
          i05.\u0275\u0275text(1, "\n    ");
          i05.\u0275\u0275elementStart(2, "h4", 1);
          i05.\u0275\u0275text(3, "Templates");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(4, "\n    ");
          i05.\u0275\u0275template(5, IrisCodeEditorSubSettingsUpdateComponent_Conditional_5_Template, 9, 1);
          i05.\u0275\u0275elementStart(6, "div");
          i05.\u0275\u0275text(7, "\n        ");
          i05.\u0275\u0275elementStart(8, "h3", 2);
          i05.\u0275\u0275text(9, "Chat Template");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(10, "\n        ");
          i05.\u0275\u0275elementStart(11, "textarea", 3);
          i05.\u0275\u0275listener("ngModelChange", function IrisCodeEditorSubSettingsUpdateComponent_Template_textarea_ngModelChange_11_listener($event) {
            return ctx.chatTemplateContent = $event;
          })("change", function IrisCodeEditorSubSettingsUpdateComponent_Template_textarea_change_11_listener() {
            return ctx.onTemplateChanged();
          });
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(12, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(13, "\n    ");
          i05.\u0275\u0275elementStart(14, "div");
          i05.\u0275\u0275text(15, "\n        ");
          i05.\u0275\u0275elementStart(16, "h3", 4);
          i05.\u0275\u0275text(17, "Problem Statement Generation Template");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(18, "\n        ");
          i05.\u0275\u0275elementStart(19, "textarea", 5);
          i05.\u0275\u0275listener("ngModelChange", function IrisCodeEditorSubSettingsUpdateComponent_Template_textarea_ngModelChange_19_listener($event) {
            return ctx.problemStatementGenerationTemplateContent = $event;
          })("change", function IrisCodeEditorSubSettingsUpdateComponent_Template_textarea_change_19_listener() {
            return ctx.onTemplateChanged();
          });
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(20, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(21, "\n    ");
          i05.\u0275\u0275elementStart(22, "div");
          i05.\u0275\u0275text(23, "\n        ");
          i05.\u0275\u0275elementStart(24, "h3", 6);
          i05.\u0275\u0275text(25, "Template Repo Generation Template");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(26, "\n        ");
          i05.\u0275\u0275elementStart(27, "textarea", 7);
          i05.\u0275\u0275listener("ngModelChange", function IrisCodeEditorSubSettingsUpdateComponent_Template_textarea_ngModelChange_27_listener($event) {
            return ctx.templateRepoGenerationTemplateContent = $event;
          })("change", function IrisCodeEditorSubSettingsUpdateComponent_Template_textarea_change_27_listener() {
            return ctx.onTemplateChanged();
          });
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(28, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(29, "\n    ");
          i05.\u0275\u0275elementStart(30, "div");
          i05.\u0275\u0275text(31, "\n        ");
          i05.\u0275\u0275elementStart(32, "h3", 8);
          i05.\u0275\u0275text(33, "Solution Repo Generation Template");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(34, "\n        ");
          i05.\u0275\u0275elementStart(35, "textarea", 9);
          i05.\u0275\u0275listener("ngModelChange", function IrisCodeEditorSubSettingsUpdateComponent_Template_textarea_ngModelChange_35_listener($event) {
            return ctx.solutionRepoGenerationTemplateContent = $event;
          })("change", function IrisCodeEditorSubSettingsUpdateComponent_Template_textarea_change_35_listener() {
            return ctx.onTemplateChanged();
          });
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(36, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(37, "\n    ");
          i05.\u0275\u0275elementStart(38, "div");
          i05.\u0275\u0275text(39, "\n        ");
          i05.\u0275\u0275elementStart(40, "h3", 10);
          i05.\u0275\u0275text(41, "Test Repo Generation Template");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(42, "\n        ");
          i05.\u0275\u0275elementStart(43, "textarea", 11);
          i05.\u0275\u0275listener("ngModelChange", function IrisCodeEditorSubSettingsUpdateComponent_Template_textarea_ngModelChange_43_listener($event) {
            return ctx.testRepoGenerationTemplateContent = $event;
          })("change", function IrisCodeEditorSubSettingsUpdateComponent_Template_textarea_change_43_listener() {
            return ctx.onTemplateChanged();
          });
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(44, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(45, "\n");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(46, "\n");
        }
        if (rf & 2) {
          i05.\u0275\u0275advance(5);
          i05.\u0275\u0275conditional(5, ctx.parentSubSettings ? 5 : -1);
          i05.\u0275\u0275advance(6);
          i05.\u0275\u0275property("ngModel", ctx.chatTemplateContent)("disabled", !(ctx.subSettings == null ? null : ctx.subSettings.chatTemplate));
          i05.\u0275\u0275advance(8);
          i05.\u0275\u0275property("ngModel", ctx.problemStatementGenerationTemplateContent)("disabled", !(ctx.subSettings == null ? null : ctx.subSettings.problemStatementGenerationTemplate));
          i05.\u0275\u0275advance(8);
          i05.\u0275\u0275property("ngModel", ctx.templateRepoGenerationTemplateContent)("disabled", !(ctx.subSettings == null ? null : ctx.subSettings.templateRepoGenerationTemplate));
          i05.\u0275\u0275advance(8);
          i05.\u0275\u0275property("ngModel", ctx.solutionRepoGenerationTemplateContent)("disabled", !(ctx.subSettings == null ? null : ctx.subSettings.solutionRepoGenerationTemplate));
          i05.\u0275\u0275advance(8);
          i05.\u0275\u0275property("ngModel", ctx.testRepoGenerationTemplateContent)("disabled", !(ctx.subSettings == null ? null : ctx.subSettings.testRepoGenerationTemplate));
        }
      }, dependencies: [i14.DefaultValueAccessor, i14.NgControlStatus, i14.NgModel, TranslateDirective], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(IrisCodeEditorSubSettingsUpdateComponent, { className: "IrisCodeEditorSubSettingsUpdateComponent" });
    })();
  }
});

// src/main/webapp/app/iris/settings/iris-settings-update/iris-settings-update.component.ts
import { Component as Component6, Input as Input6 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Observable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { faRotate, faSave } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { cloneDeep, isEqual } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function IrisSettingsUpdateComponent_Conditional_8_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n            ");
    i06.\u0275\u0275elementStart(1, "div");
    i06.\u0275\u0275text(2, "\n                ");
    i06.\u0275\u0275elementStart(3, "h3", 5);
    i06.\u0275\u0275text(4, "Auto-Update Settings");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(5, "\n                ");
    i06.\u0275\u0275elementStart(6, "jhi-iris-global-autoupdate-settings-update", 6);
    i06.\u0275\u0275listener("onChanges", function IrisSettingsUpdateComponent_Conditional_8_Conditional_3_Template_jhi_iris_global_autoupdate_settings_update_onChanges_6_listener() {
      i06.\u0275\u0275restoreView(_r5);
      const ctx_r4 = i06.\u0275\u0275nextContext(2);
      return i06.\u0275\u0275resetView(ctx_r4.isDirty = true);
    });
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n            ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(8, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(6);
    i06.\u0275\u0275property("irisSettings", ctx_r1.irisSettings);
  }
}
function IrisSettingsUpdateComponent_Conditional_8_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n            ");
    i06.\u0275\u0275elementStart(1, "div");
    i06.\u0275\u0275text(2, "\n                ");
    i06.\u0275\u0275element(3, "hr", 7);
    i06.\u0275\u0275text(4, "\n                ");
    i06.\u0275\u0275elementStart(5, "h3", 8);
    i06.\u0275\u0275text(6, "Hestia Settings");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n                ");
    i06.\u0275\u0275elementStart(8, "jhi-iris-common-sub-settings-update", 3);
    i06.\u0275\u0275listener("onChanges", function IrisSettingsUpdateComponent_Conditional_8_Conditional_14_Template_jhi_iris_common_sub_settings_update_onChanges_8_listener() {
      i06.\u0275\u0275restoreView(_r7);
      const ctx_r6 = i06.\u0275\u0275nextContext(2);
      return i06.\u0275\u0275resetView(ctx_r6.isDirty = true);
    });
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(9, "\n                ");
    i06.\u0275\u0275elementStart(10, "jhi-iris-hestia-sub-settings-update", 9);
    i06.\u0275\u0275listener("onChanges", function IrisSettingsUpdateComponent_Conditional_8_Conditional_14_Template_jhi_iris_hestia_sub_settings_update_onChanges_10_listener() {
      i06.\u0275\u0275restoreView(_r7);
      const ctx_r8 = i06.\u0275\u0275nextContext(2);
      return i06.\u0275\u0275resetView(ctx_r8.isDirty = true);
    });
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(11, "\n            ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(12, "\n        ");
  }
  if (rf & 2) {
    const ctx_r2 = i06.\u0275\u0275nextContext(2);
    let tmp_2_0;
    i06.\u0275\u0275advance(8);
    i06.\u0275\u0275property("subSettings", ctx_r2.irisSettings == null ? null : ctx_r2.irisSettings.irisHestiaSettings)("parentSubSettings", ctx_r2.parentIrisSettings == null ? null : ctx_r2.parentIrisSettings.irisHestiaSettings)("allIrisModels", (tmp_2_0 = ctx_r2.allIrisModels) !== null && tmp_2_0 !== void 0 ? tmp_2_0 : i06.\u0275\u0275pureFunction0(6, _c0))("settingsType", ctx_r2.settingsType);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275property("subSettings", ctx_r2.irisSettings == null ? null : ctx_r2.irisSettings.irisHestiaSettings)("parentSubSettings", ctx_r2.parentIrisSettings == null ? null : ctx_r2.parentIrisSettings.irisHestiaSettings);
  }
}
function IrisSettingsUpdateComponent_Conditional_8_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n            ");
    i06.\u0275\u0275elementStart(1, "div");
    i06.\u0275\u0275text(2, "\n                ");
    i06.\u0275\u0275element(3, "hr", 7);
    i06.\u0275\u0275text(4, "\n                ");
    i06.\u0275\u0275elementStart(5, "h3", 10);
    i06.\u0275\u0275text(6, "Code Editor Settings");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n                ");
    i06.\u0275\u0275elementStart(8, "jhi-iris-common-sub-settings-update", 3);
    i06.\u0275\u0275listener("onChanges", function IrisSettingsUpdateComponent_Conditional_8_Conditional_15_Template_jhi_iris_common_sub_settings_update_onChanges_8_listener() {
      i06.\u0275\u0275restoreView(_r10);
      const ctx_r9 = i06.\u0275\u0275nextContext(2);
      return i06.\u0275\u0275resetView(ctx_r9.isDirty = true);
    });
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(9, "\n                ");
    i06.\u0275\u0275elementStart(10, "jhi-iris-code-editor-sub-settings-update", 9);
    i06.\u0275\u0275listener("onChanges", function IrisSettingsUpdateComponent_Conditional_8_Conditional_15_Template_jhi_iris_code_editor_sub_settings_update_onChanges_10_listener() {
      i06.\u0275\u0275restoreView(_r10);
      const ctx_r11 = i06.\u0275\u0275nextContext(2);
      return i06.\u0275\u0275resetView(ctx_r11.isDirty = true);
    });
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(11, "\n            ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(12, "\n        ");
  }
  if (rf & 2) {
    const ctx_r3 = i06.\u0275\u0275nextContext(2);
    let tmp_2_0;
    i06.\u0275\u0275advance(8);
    i06.\u0275\u0275property("subSettings", ctx_r3.irisSettings == null ? null : ctx_r3.irisSettings.irisCodeEditorSettings)("parentSubSettings", ctx_r3.parentIrisSettings == null ? null : ctx_r3.parentIrisSettings.irisCodeEditorSettings)("allIrisModels", (tmp_2_0 = ctx_r3.allIrisModels) !== null && tmp_2_0 !== void 0 ? tmp_2_0 : i06.\u0275\u0275pureFunction0(6, _c0))("settingsType", ctx_r3.settingsType);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275property("subSettings", ctx_r3.irisSettings == null ? null : ctx_r3.irisSettings.irisCodeEditorSettings)("parentSubSettings", ctx_r3.parentIrisSettings == null ? null : ctx_r3.parentIrisSettings.irisCodeEditorSettings);
  }
}
function IrisSettingsUpdateComponent_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n    ");
    i06.\u0275\u0275elementStart(1, "div");
    i06.\u0275\u0275text(2, "\n        ");
    i06.\u0275\u0275template(3, IrisSettingsUpdateComponent_Conditional_8_Conditional_3_Template, 9, 1);
    i06.\u0275\u0275elementStart(4, "h3", 2);
    i06.\u0275\u0275text(5, "Chat Settings");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(6, "\n        ");
    i06.\u0275\u0275elementStart(7, "div");
    i06.\u0275\u0275text(8, "\n            ");
    i06.\u0275\u0275elementStart(9, "jhi-iris-common-sub-settings-update", 3);
    i06.\u0275\u0275listener("onChanges", function IrisSettingsUpdateComponent_Conditional_8_Template_jhi_iris_common_sub_settings_update_onChanges_9_listener() {
      i06.\u0275\u0275restoreView(_r13);
      const ctx_r12 = i06.\u0275\u0275nextContext();
      return i06.\u0275\u0275resetView(ctx_r12.isDirty = true);
    });
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(10, "\n            ");
    i06.\u0275\u0275elementStart(11, "jhi-iris-chat-sub-settings-update", 4);
    i06.\u0275\u0275listener("onChanges", function IrisSettingsUpdateComponent_Conditional_8_Template_jhi_iris_chat_sub_settings_update_onChanges_11_listener() {
      i06.\u0275\u0275restoreView(_r13);
      const ctx_r14 = i06.\u0275\u0275nextContext();
      return i06.\u0275\u0275resetView(ctx_r14.isDirty = true);
    });
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(12, "\n        ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(13, "\n        ");
    i06.\u0275\u0275template(14, IrisSettingsUpdateComponent_Conditional_8_Conditional_14_Template, 13, 7)(15, IrisSettingsUpdateComponent_Conditional_8_Conditional_15_Template, 13, 7);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(16, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i06.\u0275\u0275nextContext();
    let tmp_3_0;
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275conditional(3, ctx_r0.settingsType === ctx_r0.GLOBAL ? 3 : -1);
    i06.\u0275\u0275advance(6);
    i06.\u0275\u0275property("subSettings", ctx_r0.irisSettings == null ? null : ctx_r0.irisSettings.irisChatSettings)("parentSubSettings", ctx_r0.parentIrisSettings == null ? null : ctx_r0.parentIrisSettings.irisChatSettings)("allIrisModels", (tmp_3_0 = ctx_r0.allIrisModels) !== null && tmp_3_0 !== void 0 ? tmp_3_0 : i06.\u0275\u0275pureFunction0(10, _c0))("settingsType", ctx_r0.settingsType);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275property("subSettings", ctx_r0.irisSettings == null ? null : ctx_r0.irisSettings.irisChatSettings)("parentSubSettings", ctx_r0.parentIrisSettings == null ? null : ctx_r0.parentIrisSettings.irisChatSettings)("rateLimitSettable", ctx_r0.settingsType === ctx_r0.GLOBAL);
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275conditional(14, ctx_r0.settingsType !== ctx_r0.EXERCISE ? 14 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(15, ctx_r0.settingsType !== ctx_r0.EXERCISE ? 15 : -1);
  }
}
var _c0, IrisSettingsUpdateComponent;
var init_iris_settings_update_component = __esm({
  "src/main/webapp/app/iris/settings/iris-settings-update/iris-settings-update.component.ts"() {
    init_iris_settings_model();
    init_iris_settings_service();
    init_alert_service();
    init_button_component();
    init_iris_sub_settings_model();
    init_iris_settings_service();
    init_alert_service();
    init_translate_directive();
    init_button_component();
    init_iris_common_sub_settings_update_component();
    init_iris_chat_sub_settings_update_component();
    init_iris_hestia_sub_settings_update_component();
    init_iris_global_autoupdate_settings_update_component();
    init_iris_code_editor_sub_settings_update_component();
    _c0 = () => [];
    IrisSettingsUpdateComponent = class _IrisSettingsUpdateComponent {
      irisSettingsService;
      alertService;
      settingsType;
      courseId;
      exerciseId;
      irisSettings;
      parentIrisSettings;
      allIrisModels;
      originalIrisSettings;
      isLoading = false;
      isSaving = false;
      isDirty = false;
      PRIMARY = ButtonType.PRIMARY;
      WARNING = ButtonType.WARNING;
      SUCCESS = ButtonType.SUCCESS;
      faSave = faSave;
      faRotate = faRotate;
      GLOBAL = IrisSettingsType.GLOBAL;
      COURSE = IrisSettingsType.COURSE;
      EXERCISE = IrisSettingsType.EXERCISE;
      constructor(irisSettingsService, alertService) {
        this.irisSettingsService = irisSettingsService;
        this.alertService = alertService;
      }
      ngOnInit() {
        this.loadIrisSettings();
      }
      ngDoCheck() {
        if (!isEqual(this.irisSettings, this.originalIrisSettings)) {
          this.isDirty = true;
        }
      }
      canDeactivateWarning;
      canDeactivate() {
        return !this.isDirty;
      }
      loadIrisModels() {
        this.irisSettingsService.getIrisModels().subscribe((models) => {
          this.allIrisModels = models;
          this.isLoading = false;
        });
      }
      loadIrisSettings() {
        this.isLoading = true;
        this.loadIrisSettingsObservable().subscribe((settings) => {
          this.loadIrisModels();
          if (!settings) {
            this.alertService.error("artemisApp.iris.settings.error.noSettings");
          }
          this.irisSettings = settings;
          this.fillEmptyIrisSubSettings();
          this.originalIrisSettings = cloneDeep(settings);
          this.isDirty = false;
        });
        this.loadParentIrisSettingsObservable().subscribe((settings) => {
          if (!settings) {
            this.alertService.error("artemisApp.iris.settings.error.noParentSettings");
          }
          this.parentIrisSettings = settings;
        });
      }
      fillEmptyIrisSubSettings() {
        if (!this.irisSettings) {
          return;
        }
        if (!this.irisSettings.irisChatSettings) {
          this.irisSettings.irisChatSettings = new IrisChatSubSettings();
        }
        if (!this.irisSettings.irisHestiaSettings) {
          this.irisSettings.irisHestiaSettings = new IrisHestiaSubSettings();
        }
        if (!this.irisSettings.irisCodeEditorSettings) {
          this.irisSettings.irisCodeEditorSettings = new IrisCodeEditorSubSettings();
        }
      }
      saveIrisSettings() {
        this.isSaving = true;
        this.saveIrisSettingsObservable().subscribe((response) => {
          this.isSaving = false;
          this.isDirty = false;
          this.irisSettings = response.body ?? void 0;
          this.fillEmptyIrisSubSettings();
          this.originalIrisSettings = cloneDeep(this.irisSettings);
          this.alertService.success("artemisApp.iris.settings.success");
        }, () => {
          this.isSaving = false;
          this.alertService.error("artemisApp.iris.settings.error.save");
        });
      }
      loadParentIrisSettingsObservable() {
        switch (this.settingsType) {
          case IrisSettingsType.GLOBAL:
            return new Observable();
          case IrisSettingsType.COURSE:
            return this.irisSettingsService.getGlobalSettings();
          case IrisSettingsType.EXERCISE:
            return this.irisSettingsService.getCombinedCourseSettings(this.courseId);
        }
      }
      loadIrisSettingsObservable() {
        switch (this.settingsType) {
          case IrisSettingsType.GLOBAL:
            return this.irisSettingsService.getGlobalSettings();
          case IrisSettingsType.COURSE:
            return this.irisSettingsService.getUncombinedCourseSettings(this.courseId);
          case IrisSettingsType.EXERCISE:
            return this.irisSettingsService.getUncombinedProgrammingExerciseSettings(this.exerciseId);
        }
      }
      saveIrisSettingsObservable() {
        switch (this.settingsType) {
          case IrisSettingsType.GLOBAL:
            return this.irisSettingsService.setGlobalSettings(this.irisSettings);
          case IrisSettingsType.COURSE:
            return this.irisSettingsService.setCourseSettings(this.courseId, this.irisSettings);
          case IrisSettingsType.EXERCISE:
            return this.irisSettingsService.setProgrammingExerciseSettings(this.exerciseId, this.irisSettings);
        }
      }
      static \u0275fac = function IrisSettingsUpdateComponent_Factory(t) {
        return new (t || _IrisSettingsUpdateComponent)(i06.\u0275\u0275directiveInject(IrisSettingsService), i06.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i06.\u0275\u0275defineComponent({ type: _IrisSettingsUpdateComponent, selectors: [["jhi-iris-settings-update"]], inputs: { settingsType: "settingsType", courseId: "courseId", exerciseId: "exerciseId" }, decls: 9, vars: 9, consts: [["id", "reload", 3, "btnType", "isLoading", "icon", "title", "onClick"], ["id", "save", 3, "btnType", "isLoading", "icon", "title", "onClick"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.chatSettings"], [3, "subSettings", "parentSubSettings", "allIrisModels", "settingsType", "onChanges"], [3, "subSettings", "parentSubSettings", "rateLimitSettable", "onChanges"], ["jhiTranslate", "artemisApp.iris.settings.autoUpdate.title"], [3, "irisSettings", "onChanges"], [1, "hr"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.hestiaSettings"], [3, "subSettings", "parentSubSettings", "onChanges"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.codeEditorSettings"]], template: function IrisSettingsUpdateComponent_Template(rf, ctx) {
        if (rf & 1) {
          i06.\u0275\u0275elementStart(0, "div");
          i06.\u0275\u0275text(1, "\n    ");
          i06.\u0275\u0275elementStart(2, "jhi-button", 0);
          i06.\u0275\u0275listener("onClick", function IrisSettingsUpdateComponent_Template_jhi_button_onClick_2_listener() {
            return ctx.loadIrisSettings();
          });
          i06.\u0275\u0275text(3, "\n    ");
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(4, "\n    ");
          i06.\u0275\u0275elementStart(5, "jhi-button", 1);
          i06.\u0275\u0275listener("onClick", function IrisSettingsUpdateComponent_Template_jhi_button_onClick_5_listener() {
            return ctx.saveIrisSettings();
          });
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(6, "\n");
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(7, "\n");
          i06.\u0275\u0275template(8, IrisSettingsUpdateComponent_Conditional_8_Template, 17, 11);
        }
        if (rf & 2) {
          i06.\u0275\u0275advance(2);
          i06.\u0275\u0275property("btnType", ctx.isDirty ? ctx.WARNING : ctx.PRIMARY)("isLoading", ctx.isLoading)("icon", ctx.faRotate)("title", "artemisApp.iris.settings.button.reload");
          i06.\u0275\u0275advance(3);
          i06.\u0275\u0275property("btnType", ctx.SUCCESS)("isLoading", ctx.isSaving)("icon", ctx.faSave)("title", "artemisApp.iris.settings.button.save");
          i06.\u0275\u0275advance(3);
          i06.\u0275\u0275conditional(8, ctx.irisSettings ? 8 : -1);
        }
      }, dependencies: [TranslateDirective, ButtonComponent, IrisCommonSubSettingsUpdateComponent, IrisChatSubSettingsUpdateComponent, IrisHestiaSubSettingsUpdateComponent, IrisGlobalAutoupdateSettingsUpdateComponent, IrisCodeEditorSubSettingsUpdateComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i06.\u0275setClassDebugInfo(IrisSettingsUpdateComponent, { className: "IrisSettingsUpdateComponent" });
    })();
  }
});

// src/main/webapp/app/iris/settings/iris-global-settings-update/iris-global-settings-update.component.ts
import { Component as Component7, ViewChild } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisGlobalSettingsUpdateComponent;
var init_iris_global_settings_update_component = __esm({
  "src/main/webapp/app/iris/settings/iris-global-settings-update/iris-global-settings-update.component.ts"() {
    init_iris_settings_model();
    init_iris_settings_update_component();
    init_translate_directive();
    init_iris_settings_update_component();
    IrisGlobalSettingsUpdateComponent = class _IrisGlobalSettingsUpdateComponent {
      settingsUpdateComponent;
      GLOBAL = IrisSettingsType.GLOBAL;
      canDeactivate() {
        return this.settingsUpdateComponent?.canDeactivate() ?? true;
      }
      get canDeactivateWarning() {
        return this.settingsUpdateComponent?.canDeactivateWarning;
      }
      static \u0275fac = function IrisGlobalSettingsUpdateComponent_Factory(t) {
        return new (t || _IrisGlobalSettingsUpdateComponent)();
      };
      static \u0275cmp = i07.\u0275\u0275defineComponent({ type: _IrisGlobalSettingsUpdateComponent, selectors: [["jhi-iris-global-settings-update"]], viewQuery: function IrisGlobalSettingsUpdateComponent_Query(rf, ctx) {
        if (rf & 1) {
          i07.\u0275\u0275viewQuery(IrisSettingsUpdateComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i07.\u0275\u0275queryRefresh(_t = i07.\u0275\u0275loadQuery()) && (ctx.settingsUpdateComponent = _t.first);
        }
      }, decls: 8, vars: 1, consts: [[1, "container"], ["jhiTranslate", "artemisApp.iris.settings.title.global"], [3, "settingsType"]], template: function IrisGlobalSettingsUpdateComponent_Template(rf, ctx) {
        if (rf & 1) {
          i07.\u0275\u0275elementStart(0, "div", 0);
          i07.\u0275\u0275text(1, "\n    ");
          i07.\u0275\u0275elementStart(2, "h2", 1);
          i07.\u0275\u0275text(3, "Global Iris Settings");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(4, "\n    ");
          i07.\u0275\u0275element(5, "jhi-iris-settings-update", 2);
          i07.\u0275\u0275text(6, "\n");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(7, "\n");
        }
        if (rf & 2) {
          i07.\u0275\u0275advance(5);
          i07.\u0275\u0275property("settingsType", ctx.GLOBAL);
        }
      }, dependencies: [TranslateDirective, IrisSettingsUpdateComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i07.\u0275setClassDebugInfo(IrisGlobalSettingsUpdateComponent, { className: "IrisGlobalSettingsUpdateComponent" });
    })();
  }
});

// src/main/webapp/app/iris/settings/iris-course-settings-update/iris-course-settings-update.component.ts
import { Component as Component8, Input as Input7, ViewChild as ViewChild2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i08 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i15 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function IrisCourseSettingsUpdateComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n        ");
    i08.\u0275\u0275element(1, "jhi-iris-settings-update", 2);
    i08.\u0275\u0275text(2, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("settingsType", ctx_r0.COURSE)("courseId", ctx_r0.courseId);
  }
}
var IrisCourseSettingsUpdateComponent;
var init_iris_course_settings_update_component = __esm({
  "src/main/webapp/app/iris/settings/iris-course-settings-update/iris-course-settings-update.component.ts"() {
    init_iris_settings_model();
    init_iris_settings_update_component();
    init_translate_directive();
    init_iris_settings_update_component();
    IrisCourseSettingsUpdateComponent = class _IrisCourseSettingsUpdateComponent {
      route;
      settingsUpdateComponent;
      courseId;
      COURSE = IrisSettingsType.COURSE;
      constructor(route) {
        this.route = route;
      }
      ngOnInit() {
        this.route.parent?.params.subscribe((params) => {
          this.courseId = Number(params["courseId"]);
        });
      }
      canDeactivate() {
        return this.settingsUpdateComponent?.canDeactivate() ?? true;
      }
      get canDeactivateWarning() {
        return this.settingsUpdateComponent?.canDeactivateWarning;
      }
      static \u0275fac = function IrisCourseSettingsUpdateComponent_Factory(t) {
        return new (t || _IrisCourseSettingsUpdateComponent)(i08.\u0275\u0275directiveInject(i15.ActivatedRoute));
      };
      static \u0275cmp = i08.\u0275\u0275defineComponent({ type: _IrisCourseSettingsUpdateComponent, selectors: [["jhi-iris-course-settings-update"]], viewQuery: function IrisCourseSettingsUpdateComponent_Query(rf, ctx) {
        if (rf & 1) {
          i08.\u0275\u0275viewQuery(IrisSettingsUpdateComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i08.\u0275\u0275queryRefresh(_t = i08.\u0275\u0275loadQuery()) && (ctx.settingsUpdateComponent = _t.first);
        }
      }, inputs: { courseId: "courseId" }, decls: 7, vars: 1, consts: [[1, "container"], ["jhiTranslate", "artemisApp.iris.settings.title.course"], [3, "settingsType", "courseId"]], template: function IrisCourseSettingsUpdateComponent_Template(rf, ctx) {
        if (rf & 1) {
          i08.\u0275\u0275elementStart(0, "div", 0);
          i08.\u0275\u0275text(1, "\n    ");
          i08.\u0275\u0275elementStart(2, "h2", 1);
          i08.\u0275\u0275text(3, "Course Iris Settings");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(4, "\n    ");
          i08.\u0275\u0275template(5, IrisCourseSettingsUpdateComponent_Conditional_5_Template, 3, 2);
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(6, "\n");
        }
        if (rf & 2) {
          i08.\u0275\u0275advance(5);
          i08.\u0275\u0275conditional(5, ctx.courseId ? 5 : -1);
        }
      }, dependencies: [TranslateDirective, IrisSettingsUpdateComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassDebugInfo(IrisCourseSettingsUpdateComponent, { className: "IrisCourseSettingsUpdateComponent" });
    })();
  }
});

// src/main/webapp/app/iris/settings/iris-exercise-settings-update/iris-exercise-settings-update.component.ts
import { Component as Component9, Input as Input8, ViewChild as ViewChild3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i09 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i16 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function IrisExerciseSettingsUpdateComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n        ");
    i09.\u0275\u0275element(1, "jhi-iris-settings-update", 2);
    i09.\u0275\u0275text(2, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275property("settingsType", ctx_r0.EXERCISE)("courseId", ctx_r0.courseId)("exerciseId", ctx_r0.exerciseId);
  }
}
var IrisExerciseSettingsUpdateComponent;
var init_iris_exercise_settings_update_component = __esm({
  "src/main/webapp/app/iris/settings/iris-exercise-settings-update/iris-exercise-settings-update.component.ts"() {
    init_iris_settings_model();
    init_iris_settings_update_component();
    init_translate_directive();
    init_iris_settings_update_component();
    IrisExerciseSettingsUpdateComponent = class _IrisExerciseSettingsUpdateComponent {
      route;
      settingsUpdateComponent;
      courseId;
      exerciseId;
      EXERCISE = IrisSettingsType.EXERCISE;
      constructor(route) {
        this.route = route;
      }
      ngOnInit() {
        this.route.parent?.params.subscribe((params) => {
          this.courseId = Number(params["courseId"]);
          this.exerciseId = Number(params["exerciseId"]);
        });
      }
      canDeactivate() {
        return this.settingsUpdateComponent?.canDeactivate() ?? true;
      }
      get canDeactivateWarning() {
        return this.settingsUpdateComponent?.canDeactivateWarning;
      }
      static \u0275fac = function IrisExerciseSettingsUpdateComponent_Factory(t) {
        return new (t || _IrisExerciseSettingsUpdateComponent)(i09.\u0275\u0275directiveInject(i16.ActivatedRoute));
      };
      static \u0275cmp = i09.\u0275\u0275defineComponent({ type: _IrisExerciseSettingsUpdateComponent, selectors: [["jhi-iris-exercise-settings-update"]], viewQuery: function IrisExerciseSettingsUpdateComponent_Query(rf, ctx) {
        if (rf & 1) {
          i09.\u0275\u0275viewQuery(IrisSettingsUpdateComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i09.\u0275\u0275queryRefresh(_t = i09.\u0275\u0275loadQuery()) && (ctx.settingsUpdateComponent = _t.first);
        }
      }, inputs: { courseId: "courseId", exerciseId: "exerciseId" }, decls: 7, vars: 1, consts: [[1, "container"], ["jhiTranslate", "artemisApp.iris.settings.title.exercise"], [3, "settingsType", "courseId", "exerciseId"]], template: function IrisExerciseSettingsUpdateComponent_Template(rf, ctx) {
        if (rf & 1) {
          i09.\u0275\u0275elementStart(0, "div", 0);
          i09.\u0275\u0275text(1, "\n    ");
          i09.\u0275\u0275elementStart(2, "h2", 1);
          i09.\u0275\u0275text(3, "Exercise Iris Settings");
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(4, "\n    ");
          i09.\u0275\u0275template(5, IrisExerciseSettingsUpdateComponent_Conditional_5_Template, 3, 3);
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(6, "\n");
        }
        if (rf & 2) {
          i09.\u0275\u0275advance(5);
          i09.\u0275\u0275conditional(5, ctx.courseId && ctx.exerciseId ? 5 : -1);
        }
      }, dependencies: [TranslateDirective, IrisSettingsUpdateComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i09.\u0275setClassDebugInfo(IrisExerciseSettingsUpdateComponent, { className: "IrisExerciseSettingsUpdateComponent" });
    })();
  }
});

// src/main/webapp/app/entities/iris/iris-errors.model.ts
var IrisErrorMessageKey, IrisErrors, errorMessages;
var init_iris_errors_model = __esm({
  "src/main/webapp/app/entities/iris/iris-errors.model.ts"() {
    (function(IrisErrorMessageKey2) {
      IrisErrorMessageKey2["SESSION_LOAD_FAILED"] = "artemisApp.exerciseChatbot.errors.sessionLoadFailed";
      IrisErrorMessageKey2["SEND_MESSAGE_FAILED"] = "artemisApp.exerciseChatbot.errors.sendMessageFailed";
      IrisErrorMessageKey2["HISTORY_LOAD_FAILED"] = "artemisApp.exerciseChatbot.errors.historyLoadFailed";
      IrisErrorMessageKey2["INVALID_SESSION_STATE"] = "artemisApp.exerciseChatbot.errors.invalidSessionState";
      IrisErrorMessageKey2["SESSION_CREATION_FAILED"] = "artemisApp.exerciseChatbot.errors.sessionCreationFailed";
      IrisErrorMessageKey2["RATE_MESSAGE_FAILED"] = "artemisApp.exerciseChatbot.errors.rateMessageFailed";
      IrisErrorMessageKey2["IRIS_DISABLED"] = "artemisApp.exerciseChatbot.errors.irisDisabled";
      IrisErrorMessageKey2["IRIS_SERVER_RESPONSE_TIMEOUT"] = "artemisApp.exerciseChatbot.errors.timeout";
      IrisErrorMessageKey2["EMPTY_MESSAGE"] = "artemisApp.exerciseChatbot.errors.emptyMessage";
      IrisErrorMessageKey2["FORBIDDEN"] = "artemisApp.exerciseChatbot.errors.forbidden";
      IrisErrorMessageKey2["INTERNAL_PYRIS_ERROR"] = "artemisApp.exerciseChatbot.errors.internalPyrisError";
      IrisErrorMessageKey2["INVALID_TEMPLATE"] = "artemisApp.exerciseChatbot.errors.invalidTemplate";
      IrisErrorMessageKey2["NO_MODEL_AVAILABLE"] = "artemisApp.exerciseChatbot.errors.noModelAvailable";
      IrisErrorMessageKey2["NO_RESPONSE"] = "artemisApp.exerciseChatbot.errors.noResponse";
      IrisErrorMessageKey2["PARSE_RESPONSE"] = "artemisApp.exerciseChatbot.errors.parseResponse";
      IrisErrorMessageKey2["TECHNICAL_ERROR_RESPONSE"] = "artemisApp.exerciseChatbot.errors.technicalError";
      IrisErrorMessageKey2["IRIS_NOT_AVAILABLE"] = "artemisApp.exerciseChatbot.errors.irisNotAvailable";
      IrisErrorMessageKey2["RATE_LIMIT_EXCEEDED"] = "artemisApp.exerciseChatbot.errors.rateLimitExceeded";
    })(IrisErrorMessageKey || (IrisErrorMessageKey = {}));
    IrisErrors = [
      { key: IrisErrorMessageKey.SESSION_LOAD_FAILED, fatal: true },
      { key: IrisErrorMessageKey.SEND_MESSAGE_FAILED, fatal: false },
      { key: IrisErrorMessageKey.HISTORY_LOAD_FAILED, fatal: true },
      { key: IrisErrorMessageKey.INVALID_SESSION_STATE, fatal: true },
      { key: IrisErrorMessageKey.SESSION_CREATION_FAILED, fatal: true },
      { key: IrisErrorMessageKey.RATE_MESSAGE_FAILED, fatal: false },
      { key: IrisErrorMessageKey.IRIS_DISABLED, fatal: true },
      { key: IrisErrorMessageKey.IRIS_SERVER_RESPONSE_TIMEOUT, fatal: false },
      { key: IrisErrorMessageKey.EMPTY_MESSAGE, fatal: false },
      { key: IrisErrorMessageKey.INTERNAL_PYRIS_ERROR, fatal: true },
      { key: IrisErrorMessageKey.INVALID_TEMPLATE, fatal: true },
      { key: IrisErrorMessageKey.NO_MODEL_AVAILABLE, fatal: true },
      { key: IrisErrorMessageKey.NO_RESPONSE, fatal: true },
      { key: IrisErrorMessageKey.PARSE_RESPONSE, fatal: true },
      { key: IrisErrorMessageKey.FORBIDDEN, fatal: true },
      { key: IrisErrorMessageKey.TECHNICAL_ERROR_RESPONSE, fatal: true },
      { key: IrisErrorMessageKey.IRIS_NOT_AVAILABLE, fatal: true },
      { key: IrisErrorMessageKey.RATE_LIMIT_EXCEEDED, fatal: true }
    ];
    errorMessages = Object.freeze(IrisErrors.reduce((map3, obj) => {
      map3[obj.key] = obj;
      return map3;
    }, {}));
  }
});

// src/main/webapp/app/iris/state-store.model.ts
function isNumNewMessagesResetAction(action) {
  return action.type === ActionType.NUM_NEW_MESSAGES_RESET;
}
function isHistoryMessageLoadedAction(action) {
  return action.type === ActionType.HISTORY_MESSAGE_LOADED;
}
function isActiveConversationMessageLoadedAction(action) {
  return action.type === ActionType.ACTIVE_CONVERSATION_MESSAGE_LOADED;
}
function isConversationErrorOccurredAction(action) {
  return action.type === ActionType.CONVERSATION_ERROR_OCCURRED;
}
function isStudentMessageSentAction(action) {
  return action.type === ActionType.STUDENT_MESSAGE_SENT;
}
function isSessionReceivedAction(action) {
  return action.type === ActionType.SESSION_CHANGED;
}
function isRateMessageSuccessAction(action) {
  return action.type === ActionType.RATE_MESSAGE_SUCCESS;
}
function isRateLimitUpdatedAction(action) {
  return action.type === ActionType.RATE_LIMIT_UPDATED;
}
var ActionType, NumNewMessagesResetAction, ActiveConversationMessageLoadedAction, ConversationErrorOccurredAction, StudentMessageSentAction, SessionReceivedAction, RateMessageSuccessAction, RateLimitUpdatedAction;
var init_state_store_model = __esm({
  "src/main/webapp/app/iris/state-store.model.ts"() {
    init_iris_errors_model();
    (function(ActionType2) {
      ActionType2["NUM_NEW_MESSAGES_RESET"] = "num-new-messages-reset";
      ActionType2["HISTORY_MESSAGE_LOADED"] = "history-message-loaded";
      ActionType2["ACTIVE_CONVERSATION_MESSAGE_LOADED"] = "active-conversation-message-loaded";
      ActionType2["CONVERSATION_ERROR_OCCURRED"] = "conversation-error-occurred";
      ActionType2["STUDENT_MESSAGE_SENT"] = "student-message-sent";
      ActionType2["SESSION_CHANGED"] = "session-changed";
      ActionType2["RATE_MESSAGE_SUCCESS"] = "rate-message-success";
      ActionType2["RATE_LIMIT_UPDATED"] = "rate-limit-updated";
    })(ActionType || (ActionType = {}));
    NumNewMessagesResetAction = class {
      type;
      constructor() {
        this.type = ActionType.NUM_NEW_MESSAGES_RESET;
      }
    };
    ActiveConversationMessageLoadedAction = class {
      message;
      type;
      constructor(message) {
        this.message = message;
        this.type = ActionType.ACTIVE_CONVERSATION_MESSAGE_LOADED;
      }
    };
    ConversationErrorOccurredAction = class _ConversationErrorOccurredAction {
      type;
      errorObject;
      constructor(errorType, paramsMap = void 0) {
        this.type = ActionType.CONVERSATION_ERROR_OCCURRED;
        this.errorObject = _ConversationErrorOccurredAction.buildErrorObject(errorType, paramsMap);
      }
      static buildErrorObject(errorType, paramsMap) {
        if (!errorType)
          return null;
        const errorObject = errorMessages[errorType];
        errorObject.paramsMap = paramsMap;
        return errorObject;
      }
    };
    StudentMessageSentAction = class {
      message;
      timeoutId;
      type;
      constructor(message, timeoutId = null) {
        this.message = message;
        this.timeoutId = timeoutId;
        this.type = ActionType.STUDENT_MESSAGE_SENT;
      }
    };
    SessionReceivedAction = class {
      sessionId;
      messages;
      type;
      constructor(sessionId, messages) {
        this.sessionId = sessionId;
        this.messages = messages;
        this.type = ActionType.SESSION_CHANGED;
      }
    };
    RateMessageSuccessAction = class {
      index;
      helpful;
      type;
      constructor(index, helpful) {
        this.index = index;
        this.helpful = helpful;
        this.type = ActionType.RATE_MESSAGE_SUCCESS;
      }
    };
    RateLimitUpdatedAction = class {
      rateLimitInfo;
      type;
      constructor(rateLimitInfo) {
        this.rateLimitInfo = rateLimitInfo;
        this.type = ActionType.RATE_LIMIT_UPDATED;
      }
    };
  }
});

// src/main/webapp/app/entities/iris/iris-message.model.ts
function isServerSentMessage(message) {
  return message.sender === IrisSender.ARTEMIS_SERVER || message.sender === IrisSender.LLM;
}
function isArtemisClientSentMessage(message) {
  return message.sender === IrisSender.ARTEMIS_CLIENT;
}
function isStudentSentMessage(message) {
  return message.sender === IrisSender.USER;
}
var IrisSender;
var init_iris_message_model = __esm({
  "src/main/webapp/app/entities/iris/iris-message.model.ts"() {
    (function(IrisSender2) {
      IrisSender2["LLM"] = "LLM";
      IrisSender2["USER"] = "USER";
      IrisSender2["ARTEMIS_SERVER"] = "ARTEMIS_SERVER";
      IrisSender2["ARTEMIS_CLIENT"] = "ARTEMIS_CLIENT";
    })(IrisSender || (IrisSender = {}));
  }
});

// src/main/webapp/app/iris/state-store.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { BehaviorSubject, Subject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { map, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i010 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisStateStore;
var init_state_store_service = __esm({
  "src/main/webapp/app/iris/state-store.service.ts"() {
    init_state_store_model();
    init_iris_message_model();
    init_iris_errors_model();
    IrisStateStore = class _IrisStateStore {
      initialState = {
        messages: [],
        sessionId: null,
        isLoading: false,
        numNewMessages: 0,
        error: null,
        serverResponseTimeout: null,
        currentMessageCount: -1,
        rateLimit: -1,
        rateLimitTimeframeHours: -1
      };
      action = new Subject();
      state = new BehaviorSubject(this.initialState);
      subscription;
      constructor() {
        this.subscription = this.action.pipe(tap((resolvableAction) => {
          const newState = _IrisStateStore.storeReducer(this.state.getValue(), resolvableAction.action);
          this.state.next(newState);
          if (newState.error) {
            resolvableAction.reject(newState.error);
          } else {
            resolvableAction.resolve();
          }
        })).subscribe();
      }
      ngOnDestroy() {
        this.subscription.unsubscribe();
        this.state.complete();
        this.action.complete();
      }
      dispatchAndThen(action) {
        return new Promise((resolve, reject) => {
          this.action.next({
            action,
            resolve,
            reject
          });
        });
      }
      dispatch(action) {
        this.action.next({
          action,
          resolve: () => {
          },
          reject: () => {
          }
        });
      }
      getState() {
        return this.state.asObservable();
      }
      getActionObservable() {
        return this.action.asObservable().pipe(map((resolvableAction) => resolvableAction.action));
      }
      static exhaustiveCheck(_) {
      }
      static storeReducer(state2, action) {
        const defaultError = state2.error != null && state2.error.fatal ? state2.error : null;
        if (state2.sessionId == null && !(isSessionReceivedAction(action) || isConversationErrorOccurredAction(action))) {
          return __spreadProps(__spreadValues({}, state2), {
            isLoading: false,
            error: errorMessages[IrisErrorMessageKey.INVALID_SESSION_STATE],
            serverResponseTimeout: null
          });
        }
        if (isNumNewMessagesResetAction(action)) {
          return __spreadProps(__spreadValues({}, state2), {
            numNewMessages: 0
          });
        }
        if (isHistoryMessageLoadedAction(action)) {
          const castedAction = action;
          return __spreadProps(__spreadValues({}, state2), {
            messages: [...state2.messages, castedAction.message],
            isLoading: false,
            error: defaultError,
            serverResponseTimeout: null
          });
        }
        if (isActiveConversationMessageLoadedAction(action)) {
          const castedAction = action;
          if (state2.serverResponseTimeout !== null) {
            clearTimeout(state2.serverResponseTimeout);
          }
          return {
            messages: [...state2.messages, castedAction.message],
            sessionId: state2.sessionId,
            isLoading: false,
            numNewMessages: state2.numNewMessages + 1,
            error: defaultError,
            serverResponseTimeout: null,
            currentMessageCount: state2.currentMessageCount,
            rateLimit: state2.rateLimit,
            rateLimitTimeframeHours: state2.rateLimitTimeframeHours
          };
        }
        if (isConversationErrorOccurredAction(action)) {
          const castedAction = action;
          if (state2.serverResponseTimeout !== null && (castedAction.errorObject?.fatal || castedAction.errorObject?.key === IrisErrorMessageKey.SEND_MESSAGE_FAILED)) {
            clearTimeout(state2.serverResponseTimeout);
            state2.serverResponseTimeout = null;
          }
          return __spreadProps(__spreadValues({}, state2), {
            isLoading: false,
            error: castedAction.errorObject
          });
        }
        if (isSessionReceivedAction(action)) {
          const castedAction = action;
          return __spreadProps(__spreadValues({}, state2), {
            messages: castedAction.messages,
            sessionId: castedAction.sessionId,
            error: defaultError,
            serverResponseTimeout: null
          });
        }
        if (isStudentMessageSentAction(action)) {
          const castedAction = action;
          let newMessage = true;
          if (castedAction.message.messageDifferentiator !== void 0) {
            for (let i = state2.messages.length - 1; i >= 0; i--) {
              const message = state2.messages[i];
              if (!isStudentSentMessage(message))
                continue;
              if (message.messageDifferentiator === void 0)
                continue;
              if (message.messageDifferentiator === castedAction.message.messageDifferentiator) {
                newMessage = false;
              }
            }
          }
          if (!newMessage) {
            if (castedAction.timeoutId !== null) {
              clearTimeout(castedAction.timeoutId);
            }
            return __spreadProps(__spreadValues({}, state2), {
              isLoading: true,
              error: castedAction.message.id === void 0 ? defaultError : null
            });
          }
          return __spreadProps(__spreadValues({}, state2), {
            messages: [...state2.messages, castedAction.message],
            isLoading: true,
            error: defaultError,
            serverResponseTimeout: castedAction.timeoutId
          });
        }
        if (isRateMessageSuccessAction(action)) {
          const castedAction = action;
          const newMessages = state2.messages;
          if (castedAction.index < state2.messages.length) {
            newMessages[castedAction.index].helpful = castedAction.helpful;
            return __spreadProps(__spreadValues({}, state2), {
              messages: newMessages
            });
          }
          return state2;
        }
        if (isRateLimitUpdatedAction(action)) {
          const castedAction = action;
          const rateLimitInfo = castedAction.rateLimitInfo;
          let errorMessage = null;
          if (rateLimitInfo.rateLimit >= 0 && rateLimitInfo.currentMessageCount >= rateLimitInfo.rateLimit) {
            errorMessage = errorMessages[IrisErrorMessageKey.RATE_LIMIT_EXCEEDED];
            errorMessage.paramsMap = /* @__PURE__ */ new Map();
            errorMessage.paramsMap.set("hours", rateLimitInfo.rateLimitTimeframeHours);
          }
          return __spreadProps(__spreadValues({}, state2), {
            error: errorMessage,
            currentMessageCount: rateLimitInfo.currentMessageCount,
            rateLimit: rateLimitInfo.rateLimit,
            rateLimitTimeframeHours: rateLimitInfo.rateLimitTimeframeHours
          });
        }
        _IrisStateStore.exhaustiveCheck(action);
        return state2;
      }
      static \u0275fac = function IrisStateStore_Factory(t) {
        return new (t || _IrisStateStore)();
      };
      static \u0275prov = i010.\u0275\u0275defineInjectable({ token: _IrisStateStore, factory: _IrisStateStore.\u0275fac });
    };
  }
});

// src/main/webapp/app/iris/shared.service.ts
import { Injectable as Injectable2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { BehaviorSubject as BehaviorSubject2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i011 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var SharedService;
var init_shared_service = __esm({
  "src/main/webapp/app/iris/shared.service.ts"() {
    SharedService = class _SharedService {
      chatOpenSource = new BehaviorSubject2(false);
      chatOpen = this.chatOpenSource.asObservable();
      changeChatOpenStatus(status) {
        this.chatOpenSource.next(status);
      }
      static \u0275fac = function SharedService_Factory(t) {
        return new (t || _SharedService)();
      };
      static \u0275prov = i011.\u0275\u0275defineInjectable({ token: _SharedService, factory: _SharedService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/entities/iris/iris-content-type.model.ts
function isNotExecuted(step) {
  return step.executionStage === ExecutionStage.NOT_EXECUTED;
}
function isInProgress(step) {
  return step.executionStage === ExecutionStage.IN_PROGRESS;
}
function isFailed(step) {
  return step.executionStage === ExecutionStage.FAILED;
}
function isComplete(step) {
  return step.executionStage === ExecutionStage.COMPLETE;
}
function hideOrUnhide(step) {
  step.hidden = !isHidden(step);
}
function isHidden(step) {
  if (step.hidden === void 0) {
    step.hidden = true;
  }
  return step.hidden;
}
function isTextContent(content) {
  return content.type === IrisMessageContentType.TEXT;
}
function getTextContent(content) {
  if (isTextContent(content)) {
    const irisMessageTextContent = content;
    return irisMessageTextContent.textContent;
  }
}
function isExercisePlan(content) {
  return content.type === IrisMessageContentType.EXERCISE_PLAN;
}
var IrisMessageContentType, IrisMessageContent, IrisTextMessageContent, ExerciseComponent, ExecutionStage;
var init_iris_content_type_model = __esm({
  "src/main/webapp/app/entities/iris/iris-content-type.model.ts"() {
    (function(IrisMessageContentType2) {
      IrisMessageContentType2["TEXT"] = "text";
      IrisMessageContentType2["EXERCISE_PLAN"] = "exercise_plan";
    })(IrisMessageContentType || (IrisMessageContentType = {}));
    IrisMessageContent = class {
      type;
      id;
      messageId;
      constructor(type) {
        this.type = type;
      }
    };
    IrisTextMessageContent = class extends IrisMessageContent {
      textContent;
      constructor(textContent) {
        super(IrisMessageContentType.TEXT);
        this.textContent = textContent;
      }
    };
    (function(ExerciseComponent2) {
      ExerciseComponent2["PROBLEM_STATEMENT"] = "PROBLEM_STATEMENT";
      ExerciseComponent2["SOLUTION_REPOSITORY"] = "SOLUTION_REPOSITORY";
      ExerciseComponent2["TEMPLATE_REPOSITORY"] = "TEMPLATE_REPOSITORY";
      ExerciseComponent2["TEST_REPOSITORY"] = "TEST_REPOSITORY";
    })(ExerciseComponent || (ExerciseComponent = {}));
    (function(ExecutionStage2) {
      ExecutionStage2["NOT_EXECUTED"] = "NOT_EXECUTED";
      ExecutionStage2["IN_PROGRESS"] = "IN_PROGRESS";
      ExecutionStage2["FAILED"] = "FAILED";
      ExecutionStage2["COMPLETE"] = "COMPLETE";
    })(ExecutionStage || (ExecutionStage = {}));
  }
});

// src/main/webapp/app/iris/http-session.service.ts
import { Injectable as Injectable3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import * as i012 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisHttpSessionService;
var init_http_session_service = __esm({
  "src/main/webapp/app/iris/http-session.service.ts"() {
    IrisHttpSessionService = class _IrisHttpSessionService {
      http;
      sessionType;
      apiPrefix = "api/iris";
      constructor(http, sessionType) {
        this.http = http;
        this.sessionType = sessionType;
      }
      getCurrentSession(exerciseId) {
        return this.http.get(`${this.apiPrefix}/programming-exercises/${exerciseId}/${this.sessionType}/current`, { observe: "response" });
      }
      createSession(exerciseId) {
        return this.http.post(`${this.apiPrefix}/programming-exercises/${exerciseId}/${this.sessionType}`, {});
      }
      static \u0275fac = function IrisHttpSessionService_Factory(t) {
        i012.\u0275\u0275invalidFactory();
      };
      static \u0275prov = i012.\u0275\u0275defineInjectable({ token: _IrisHttpSessionService, factory: _IrisHttpSessionService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/iris/http-message.service.ts
import { Injectable as Injectable4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient as HttpClient2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map as map2, tap as tap2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i013 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i17 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var IrisHttpMessageService;
var init_http_message_service = __esm({
  "src/main/webapp/app/iris/http-message.service.ts"() {
    init_date_utils();
    IrisHttpMessageService = class _IrisHttpMessageService {
      httpClient;
      apiPrefix = "api/iris";
      constructor(httpClient) {
        this.httpClient = httpClient;
      }
      randomInt() {
        const maxIntJava = 2147483647;
        return Math.floor(Math.random() * maxIntJava);
      }
      getMessages(sessionId) {
        return this.httpClient.get(`${this.apiPrefix}/sessions/${sessionId}/messages`, { observe: "response" }).pipe(map2((response) => {
          const messages = response.body;
          if (!messages)
            return response;
          const modifiedMessages = messages.map((message) => {
            return Object.assign({}, message, {
              sentAt: convertDateFromServer(message.sentAt)
            });
          });
          return Object.assign({}, response, {
            body: modifiedMessages
          });
        }));
      }
      createMessage(sessionId, message) {
        message.messageDifferentiator = this.randomInt();
        return this.httpClient.post(`${this.apiPrefix}/sessions/${sessionId}/messages`, Object.assign({}, message, {
          sentAt: convertDateFromClient(message.sentAt)
        }), { observe: "response" }).pipe(tap2((response) => {
          if (response.body && response.body.id) {
            message.id = response.body.id;
          }
        }));
      }
      resendMessage(sessionId, message) {
        message.messageDifferentiator = message.messageDifferentiator ?? this.randomInt();
        return this.httpClient.post(`${this.apiPrefix}/sessions/${sessionId}/messages/${message.id}/resend`, null, { observe: "response" }).pipe(tap2((response) => {
          if (response.body && response.body.id) {
            message.id = response.body.id;
          }
        }));
      }
      rateMessage(sessionId, messageId, helpful) {
        return this.httpClient.put(`${this.apiPrefix}/sessions/${sessionId}/messages/${messageId}/helpful/${helpful}`, null, { observe: "response" });
      }
      static \u0275fac = function IrisHttpMessageService_Factory(t) {
        return new (t || _IrisHttpMessageService)(i013.\u0275\u0275inject(i17.HttpClient));
      };
      static \u0275prov = i013.\u0275\u0275defineInjectable({ token: _IrisHttpMessageService, factory: _IrisHttpMessageService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/iris/session.service.ts
import { Injectable as Injectable5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { firstValueFrom } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i014 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisSessionService;
var init_session_service = __esm({
  "src/main/webapp/app/iris/session.service.ts"() {
    init_state_store_service();
    init_state_store_model();
    init_http_session_service();
    init_http_message_service();
    init_iris_errors_model();
    init_state_store_service();
    init_http_session_service();
    init_http_message_service();
    IrisSessionService = class _IrisSessionService {
      stateStore;
      httpSessionService;
      httpMessageService;
      constructor(stateStore, httpSessionService, httpMessageService) {
        this.stateStore = stateStore;
        this.httpSessionService = httpSessionService;
        this.httpMessageService = httpMessageService;
      }
      getCurrentSessionOrCreate(exerciseId) {
        let sessionId;
        firstValueFrom(this.httpSessionService.getCurrentSession(exerciseId)).then((irisSessionResponse) => {
          sessionId = irisSessionResponse.body.id;
          return firstValueFrom(this.httpMessageService.getMessages(sessionId)).then((messagesResponse) => {
            const messages = messagesResponse.body;
            messages.sort((a, b) => {
              if (a.sentAt && b.sentAt) {
                if (a.sentAt === b.sentAt)
                  return 0;
                return a.sentAt.isBefore(b.sentAt) ? -1 : 1;
              }
              return 0;
            });
            this.dispatchSuccess(sessionId, messages);
          }).catch(() => {
            this.dispatchError(IrisErrorMessageKey.HISTORY_LOAD_FAILED);
          });
        }).catch((error) => {
          if (error.status == 404) {
            return this.createNewSession(exerciseId);
          } else {
            this.dispatchError(IrisErrorMessageKey.SESSION_LOAD_FAILED);
          }
        });
      }
      createNewSession(exerciseId) {
        this.httpSessionService.createSession(exerciseId).subscribe({
          next: (irisSessionResponse) => {
            this.dispatchSuccess(irisSessionResponse.id, []);
          },
          error: () => this.dispatchError(IrisErrorMessageKey.SESSION_CREATION_FAILED)
        });
      }
      sendMessage(sessionId, message) {
        return __async(this, null, function* () {
          const response = yield firstValueFrom(this.httpMessageService.createMessage(sessionId, message));
          return response.body;
        });
      }
      resendMessage(sessionId, message) {
        return __async(this, null, function* () {
          const response = yield firstValueFrom(this.httpMessageService.resendMessage(sessionId, message));
          return response.body;
        });
      }
      rateMessage(sessionId, messageId, helpful) {
        return __async(this, null, function* () {
          const response = yield firstValueFrom(this.httpMessageService.rateMessage(sessionId, messageId, helpful));
          return response.body;
        });
      }
      dispatchSuccess(sessionId, messages) {
        this.stateStore.dispatch(new SessionReceivedAction(sessionId, messages));
      }
      dispatchError(error) {
        this.stateStore.dispatch(new ConversationErrorOccurredAction(error));
      }
      static \u0275fac = function IrisSessionService_Factory(t) {
        return new (t || _IrisSessionService)(i014.\u0275\u0275inject(IrisStateStore), i014.\u0275\u0275inject(IrisHttpSessionService), i014.\u0275\u0275inject(IrisHttpMessageService));
      };
      static \u0275prov = i014.\u0275\u0275defineInjectable({ token: _IrisSessionService, factory: _IrisSessionService.\u0275fac });
    };
  }
});

// src/main/webapp/app/iris/http-chat-message.service.ts
import { Injectable as Injectable6 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i015 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisHttpChatMessageService;
var init_http_chat_message_service = __esm({
  "src/main/webapp/app/iris/http-chat-message.service.ts"() {
    init_http_message_service();
    IrisHttpChatMessageService = class _IrisHttpChatMessageService extends IrisHttpMessageService {
      static \u0275fac = (() => {
        let \u0275IrisHttpChatMessageService_BaseFactory;
        return function IrisHttpChatMessageService_Factory(t) {
          return (\u0275IrisHttpChatMessageService_BaseFactory || (\u0275IrisHttpChatMessageService_BaseFactory = i015.\u0275\u0275getInheritedFactory(_IrisHttpChatMessageService)))(t || _IrisHttpChatMessageService);
        };
      })();
      static \u0275prov = i015.\u0275\u0275defineInjectable({ token: _IrisHttpChatMessageService, factory: _IrisHttpChatMessageService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/iris/http-chat-session.service.ts
import { Injectable as Injectable7 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient as HttpClient4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import * as i016 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i18 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var IrisHttpChatSessionService;
var init_http_chat_session_service = __esm({
  "src/main/webapp/app/iris/http-chat-session.service.ts"() {
    init_http_session_service();
    IrisHttpChatSessionService = class _IrisHttpChatSessionService extends IrisHttpSessionService {
      constructor(http) {
        super(http, "sessions");
      }
      getHeartbeat(sessionId) {
        return this.http.get(`${this.apiPrefix}/${this.sessionType}/${sessionId}/active`, { observe: "response" });
      }
      static \u0275fac = function IrisHttpChatSessionService_Factory(t) {
        return new (t || _IrisHttpChatSessionService)(i016.\u0275\u0275inject(i18.HttpClient));
      };
      static \u0275prov = i016.\u0275\u0275defineInjectable({ token: _IrisHttpChatSessionService, factory: _IrisHttpChatSessionService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/iris/chat-session.service.ts
import { Injectable as Injectable8 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i017 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisChatSessionService;
var init_chat_session_service = __esm({
  "src/main/webapp/app/iris/chat-session.service.ts"() {
    init_state_store_service();
    init_session_service();
    init_http_chat_message_service();
    init_http_chat_session_service();
    init_state_store_service();
    init_http_chat_session_service();
    init_http_chat_message_service();
    IrisChatSessionService = class _IrisChatSessionService extends IrisSessionService {
      constructor(stateStore, irisSessionService, irisHttpChatMessageService) {
        super(stateStore, irisSessionService, irisHttpChatMessageService);
      }
      static \u0275fac = function IrisChatSessionService_Factory(t) {
        return new (t || _IrisChatSessionService)(i017.\u0275\u0275inject(IrisStateStore), i017.\u0275\u0275inject(IrisHttpChatSessionService), i017.\u0275\u0275inject(IrisHttpChatMessageService));
      };
      static \u0275prov = i017.\u0275\u0275defineInjectable({ token: _IrisChatSessionService, factory: _IrisChatSessionService.\u0275fac });
    };
  }
});

// src/main/webapp/app/iris/http-code-editor-session.service.ts
import { Injectable as Injectable9 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient as HttpClient6 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import * as i018 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i19 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var IrisHttpCodeEditorSessionService;
var init_http_code_editor_session_service = __esm({
  "src/main/webapp/app/iris/http-code-editor-session.service.ts"() {
    init_http_session_service();
    IrisHttpCodeEditorSessionService = class _IrisHttpCodeEditorSessionService extends IrisHttpSessionService {
      http;
      constructor(http) {
        super(http, "code-editor-sessions");
        this.http = http;
      }
      static \u0275fac = function IrisHttpCodeEditorSessionService_Factory(t) {
        return new (t || _IrisHttpCodeEditorSessionService)(i018.\u0275\u0275inject(i19.HttpClient));
      };
      static \u0275prov = i018.\u0275\u0275defineInjectable({ token: _IrisHttpCodeEditorSessionService, factory: _IrisHttpCodeEditorSessionService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/iris/http-code-editor-message.service.ts
import { Injectable as Injectable10 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i019 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisHttpCodeEditorMessageService;
var init_http_code_editor_message_service = __esm({
  "src/main/webapp/app/iris/http-code-editor-message.service.ts"() {
    init_http_message_service();
    IrisHttpCodeEditorMessageService = class _IrisHttpCodeEditorMessageService extends IrisHttpMessageService {
      sessionType = "code-editor-sessions";
      executePlanStep(sessionId, messageId, planId, stepId) {
        return this.httpClient.post(`${this.apiPrefix}/${this.sessionType}/${sessionId}/messages/${messageId}/contents/${planId}/steps/${stepId}/execute`, null, {
          observe: "response"
        });
      }
      updateExercisePlanStepInstructions(sessionId, messageId, planId, stepId, updatedStep) {
        return this.httpClient.put(`${this.apiPrefix}/${this.sessionType}/${sessionId}/messages/${messageId}/contents/${planId}/steps/${stepId}`, updatedStep, { observe: "response" });
      }
      static \u0275fac = (() => {
        let \u0275IrisHttpCodeEditorMessageService_BaseFactory;
        return function IrisHttpCodeEditorMessageService_Factory(t) {
          return (\u0275IrisHttpCodeEditorMessageService_BaseFactory || (\u0275IrisHttpCodeEditorMessageService_BaseFactory = i019.\u0275\u0275getInheritedFactory(_IrisHttpCodeEditorMessageService)))(t || _IrisHttpCodeEditorMessageService);
        };
      })();
      static \u0275prov = i019.\u0275\u0275defineInjectable({ token: _IrisHttpCodeEditorMessageService, factory: _IrisHttpCodeEditorMessageService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/iris/code-editor-session.service.ts
import { Injectable as Injectable11 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { firstValueFrom as firstValueFrom2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i020 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisCodeEditorSessionService;
var init_code_editor_session_service = __esm({
  "src/main/webapp/app/iris/code-editor-session.service.ts"() {
    init_state_store_service();
    init_session_service();
    init_http_code_editor_session_service();
    init_http_code_editor_message_service();
    init_state_store_service();
    init_http_code_editor_session_service();
    init_http_code_editor_message_service();
    IrisCodeEditorSessionService = class _IrisCodeEditorSessionService extends IrisSessionService {
      irisHttpCodeEditorMessageService;
      constructor(stateStore, irisSessionService, irisHttpCodeEditorMessageService) {
        super(stateStore, irisSessionService, irisHttpCodeEditorMessageService);
        this.irisHttpCodeEditorMessageService = irisHttpCodeEditorMessageService;
      }
      executePlanStep(sessionId, messageId, planId, stepId) {
        return __async(this, null, function* () {
          yield firstValueFrom2(this.irisHttpCodeEditorMessageService.executePlanStep(sessionId, messageId, planId, stepId));
        });
      }
      updatePlanStepInstructions(sessionId, messageId, planId, stepId, step) {
        return __async(this, null, function* () {
          const response = yield firstValueFrom2(this.irisHttpCodeEditorMessageService.updateExercisePlanStepInstructions(sessionId, messageId, planId, stepId, step));
          return response.body;
        });
      }
      static \u0275fac = function IrisCodeEditorSessionService_Factory(t) {
        return new (t || _IrisCodeEditorSessionService)(i020.\u0275\u0275inject(IrisStateStore), i020.\u0275\u0275inject(IrisHttpCodeEditorSessionService), i020.\u0275\u0275inject(IrisHttpCodeEditorMessageService));
      };
      static \u0275prov = i020.\u0275\u0275defineInjectable({ token: _IrisCodeEditorSessionService, factory: _IrisCodeEditorSessionService.\u0275fac });
    };
  }
});

// src/main/webapp/app/iris/exercise-chatbot/widget/chatbot-widget.component.ts
import { faArrowDown, faCircle, faCircleInfo, faCompress, faExpand, faPaperPlane, faRedo, faRobot, faThumbsDown, faThumbsUp, faTrash as faTrash2, faXmark } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { NavigationStart, Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { NgbModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { Component as Component10, ElementRef, Inject, ViewChild as ViewChild4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { MAT_DIALOG_DATA, MatDialog } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_dialog.js?v=1d0d9ead";
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import { animate, state, style, transition, trigger } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_animations.js?v=1d0d9ead";
import __vite__cjsImport81_interactjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/interactjs.js?v=1d0d9ead"; const interact = __vite__cjsImport81_interactjs.__esModule ? __vite__cjsImport81_interactjs.default : __vite__cjsImport81_interactjs;
import { DOCUMENT } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i021 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i110 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_dialog.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i6 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i7 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i8 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i9 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function IrisChatbotWidgetComponent_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                            ");
    i021.\u0275\u0275elementStart(1, "span", 20);
    i021.\u0275\u0275pipe(2, "artemisTranslate");
    i021.\u0275\u0275text(3);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r0 = i021.\u0275\u0275nextContext();
    i021.\u0275\u0275advance(1);
    i021.\u0275\u0275property("ngbTooltip", i021.\u0275\u0275pipeBind2(2, 3, "artemisApp.exerciseChatbot.rateLimitTooltip", i021.\u0275\u0275pureFunction1(6, _c4, ctx_r0.rateLimitTimeframeHours)));
    i021.\u0275\u0275advance(2);
    i021.\u0275\u0275textInterpolate2("", ctx_r0.currentMessageCount, "/", ctx_r0.rateLimit, "");
  }
}
function IrisChatbotWidgetComponent_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = i021.\u0275\u0275getCurrentView();
    i021.\u0275\u0275text(0, "\n                            ");
    i021.\u0275\u0275elementStart(1, "button", 21);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_Conditional_25_Template_button_click_1_listener() {
      i021.\u0275\u0275restoreView(_r15);
      const ctx_r14 = i021.\u0275\u0275nextContext();
      const _r5 = i021.\u0275\u0275reference(38);
      return i021.\u0275\u0275resetView(ctx_r14.onClearSession(_r5));
    });
    i021.\u0275\u0275text(2, "\n                                ");
    i021.\u0275\u0275element(3, "fa-icon", 10);
    i021.\u0275\u0275text(4, "\n                            ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(5, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r1 = i021.\u0275\u0275nextContext();
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275property("icon", ctx_r1.faTrash);
  }
}
function IrisChatbotWidgetComponent_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = i021.\u0275\u0275getCurrentView();
    i021.\u0275\u0275text(0, "\n                            ");
    i021.\u0275\u0275elementStart(1, "button", 9);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_Conditional_26_Template_button_click_1_listener() {
      i021.\u0275\u0275restoreView(_r17);
      const ctx_r16 = i021.\u0275\u0275nextContext();
      return i021.\u0275\u0275resetView(ctx_r16.maximizeScreen());
    });
    i021.\u0275\u0275text(2, "\n                                ");
    i021.\u0275\u0275element(3, "fa-icon", 10);
    i021.\u0275\u0275text(4, "\n                            ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(5, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r2 = i021.\u0275\u0275nextContext();
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275property("icon", ctx_r2.faExpand);
  }
}
function IrisChatbotWidgetComponent_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = i021.\u0275\u0275getCurrentView();
    i021.\u0275\u0275text(0, "\n                            ");
    i021.\u0275\u0275elementStart(1, "button", 9);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_Conditional_27_Template_button_click_1_listener() {
      i021.\u0275\u0275restoreView(_r19);
      const ctx_r18 = i021.\u0275\u0275nextContext();
      return i021.\u0275\u0275resetView(ctx_r18.minimizeScreen());
    });
    i021.\u0275\u0275text(2, "\n                                ");
    i021.\u0275\u0275element(3, "fa-icon", 10);
    i021.\u0275\u0275text(4, "\n                            ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(5, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r3 = i021.\u0275\u0275nextContext();
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275property("icon", ctx_r3.faCompress);
  }
}
function IrisChatbotWidgetComponent_ng_template_37_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = i021.\u0275\u0275getCurrentView();
    i021.\u0275\u0275text(0, "\n            ");
    i021.\u0275\u0275elementStart(1, "div", 22);
    i021.\u0275\u0275text(2, "\n                ");
    i021.\u0275\u0275elementStart(3, "h4", 23);
    i021.\u0275\u0275text(4, "\n                    ");
    i021.\u0275\u0275elementStart(5, "span");
    i021.\u0275\u0275text(6);
    i021.\u0275\u0275pipe(7, "artemisTranslate");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(8, "\n                ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(9, "\n                ");
    i021.\u0275\u0275elementStart(10, "button", 24);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_ng_template_37_Template_button_click_10_listener() {
      const restoredCtx = i021.\u0275\u0275restoreView(_r22);
      const modal_r20 = restoredCtx.$implicit;
      return i021.\u0275\u0275resetView(modal_r20.dismiss());
    });
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(11, "\n            ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(12, "\n            ");
    i021.\u0275\u0275elementStart(13, "div", 25);
    i021.\u0275\u0275text(14, "\n                ");
    i021.\u0275\u0275elementStart(15, "p");
    i021.\u0275\u0275text(16);
    i021.\u0275\u0275pipe(17, "artemisTranslate");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(18, "\n            ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(19, "\n            ");
    i021.\u0275\u0275elementStart(20, "div", 26);
    i021.\u0275\u0275text(21, "\n                ");
    i021.\u0275\u0275elementStart(22, "button", 27);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_ng_template_37_Template_button_click_22_listener() {
      const restoredCtx = i021.\u0275\u0275restoreView(_r22);
      const modal_r20 = restoredCtx.$implicit;
      return i021.\u0275\u0275resetView(modal_r20.close("confirm"));
    });
    i021.\u0275\u0275text(23, "\n                    ");
    i021.\u0275\u0275elementStart(24, "span");
    i021.\u0275\u0275text(25);
    i021.\u0275\u0275pipe(26, "artemisTranslate");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(27, "\n                ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(28, "\n            ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(29, "\n        ");
  }
  if (rf & 2) {
    i021.\u0275\u0275advance(6);
    i021.\u0275\u0275textInterpolate(i021.\u0275\u0275pipeBind1(7, 3, "artemisApp.exerciseChatbot.clearSession.title"));
    i021.\u0275\u0275advance(10);
    i021.\u0275\u0275textInterpolate(i021.\u0275\u0275pipeBind1(17, 5, "artemisApp.exerciseChatbot.clearSession.text"));
    i021.\u0275\u0275advance(9);
    i021.\u0275\u0275textInterpolate(i021.\u0275\u0275pipeBind1(26, 7, "artemisApp.exerciseChatbot.clearSession.submit"));
  }
}
function IrisChatbotWidgetComponent_For_45_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                        ");
    i021.\u0275\u0275elementStart(1, "span", 28, 29);
    i021.\u0275\u0275text(3);
    i021.\u0275\u0275pipe(4, "artemisTranslate");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275textInterpolate(i021.\u0275\u0275pipeBind1(4, 1, "artemisApp.exerciseChatbot.unreadMessages"));
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_3_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r44 = i021.\u0275\u0275getCurrentView();
    i021.\u0275\u0275text(0, "\n                                            ");
    i021.\u0275\u0275elementStart(1, "button", 32);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_For_45_For_5_Conditional_3_Conditional_5_Template_button_click_1_listener() {
      i021.\u0275\u0275restoreView(_r44);
      const message_r24 = i021.\u0275\u0275nextContext(3).$implicit;
      const ctx_r42 = i021.\u0275\u0275nextContext();
      return i021.\u0275\u0275resetView(ctx_r42.resendMessage(message_r24));
    });
    i021.\u0275\u0275text(2, "\n                                                ");
    i021.\u0275\u0275element(3, "fa-icon", 33);
    i021.\u0275\u0275text(4, "\n                                            ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(5, "\n                                        ");
  }
  if (rf & 2) {
    const ctx_r40 = i021.\u0275\u0275nextContext(4);
    i021.\u0275\u0275advance(1);
    i021.\u0275\u0275property("disabled", ctx_r40.resendAnimationActive);
    i021.\u0275\u0275advance(2);
    i021.\u0275\u0275property("icon", ctx_r40.faRedo)("ngClass", ctx_r40.resendAnimationActive ? "fa-pulse" : "");
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_3_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                                        ");
    i021.\u0275\u0275elementStart(1, "div", 30);
    i021.\u0275\u0275text(2, "\n                                            ");
    i021.\u0275\u0275elementStart(3, "pre");
    i021.\u0275\u0275element(4, "span", 34);
    i021.\u0275\u0275pipe(5, "htmlForMarkdown");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(6, "\n                                        ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(7, "\n                                    ");
  }
  if (rf & 2) {
    const content_r32 = i021.\u0275\u0275nextContext(2).$implicit;
    const ctx_r41 = i021.\u0275\u0275nextContext(2);
    i021.\u0275\u0275advance(4);
    i021.\u0275\u0275property("innerHTML", i021.\u0275\u0275pipeBind1(5, 1, ctx_r41.getTextContent(content_r32)), i021.\u0275\u0275sanitizeHtml);
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                                ");
    i021.\u0275\u0275elementStart(1, "div", 30);
    i021.\u0275\u0275text(2, "\n                                    ");
    i021.\u0275\u0275elementStart(3, "div", 31);
    i021.\u0275\u0275text(4, "\n                                        ");
    i021.\u0275\u0275template(5, IrisChatbotWidgetComponent_For_45_For_5_Conditional_3_Conditional_5_Template, 6, 3);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(6, "\n                                    ");
    i021.\u0275\u0275template(7, IrisChatbotWidgetComponent_For_45_For_5_Conditional_3_Conditional_7_Template, 8, 3);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(8, "\n                            ");
  }
  if (rf & 2) {
    const content_r32 = i021.\u0275\u0275nextContext().$implicit;
    const ctx_r46 = i021.\u0275\u0275nextContext();
    const i_r25 = ctx_r46.$index;
    const message_r24 = ctx_r46.$implicit;
    const ctx_r37 = i021.\u0275\u0275nextContext();
    i021.\u0275\u0275advance(5);
    i021.\u0275\u0275conditional(5, i_r25 === ctx_r37.messages.length - 1 && message_r24.sender === ctx_r37.IrisSender.USER && !ctx_r37.isLoading && !(ctx_r37.rateLimit >= 0 && ctx_r37.currentMessageCount >= ctx_r37.rateLimit) ? 5 : -1);
    i021.\u0275\u0275advance(2);
    i021.\u0275\u0275conditional(7, ctx_r37.isTextContent(content_r32) ? 7 : -1);
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                                        ");
    i021.\u0275\u0275elementStart(1, "div", 36);
    i021.\u0275\u0275text(2, "\n                                            ");
    i021.\u0275\u0275element(3, "span", 37);
    i021.\u0275\u0275pipe(4, "htmlForMarkdown");
    i021.\u0275\u0275text(5, "\n                                        ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(6, "\n                                    ");
  }
  if (rf & 2) {
    const content_r32 = i021.\u0275\u0275nextContext(2).$implicit;
    const ctx_r48 = i021.\u0275\u0275nextContext(2);
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275property("innerHTML", i021.\u0275\u0275pipeBind1(4, 1, ctx_r48.getTextContent(content_r32)), i021.\u0275\u0275sanitizeHtml);
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r54 = i021.\u0275\u0275getCurrentView();
    i021.\u0275\u0275text(0, "\n                                        ");
    i021.\u0275\u0275elementStart(1, "div", 38);
    i021.\u0275\u0275text(2, "\n                                            ");
    i021.\u0275\u0275elementStart(3, "button", 39);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_4_Template_button_click_3_listener() {
      i021.\u0275\u0275restoreView(_r54);
      const ctx_r53 = i021.\u0275\u0275nextContext(3);
      const message_r24 = ctx_r53.$implicit;
      const i_r25 = ctx_r53.$index;
      const ctx_r52 = i021.\u0275\u0275nextContext();
      return i021.\u0275\u0275resetView(ctx_r52.rateMessage(message_r24.id, i_r25, true));
    });
    i021.\u0275\u0275text(4, "\n                                                ");
    i021.\u0275\u0275element(5, "fa-icon", 40);
    i021.\u0275\u0275text(6, "\n                                            ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(7, "\n                                            ");
    i021.\u0275\u0275elementStart(8, "button", 39);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_4_Template_button_click_8_listener() {
      i021.\u0275\u0275restoreView(_r54);
      const ctx_r56 = i021.\u0275\u0275nextContext(3);
      const message_r24 = ctx_r56.$implicit;
      const i_r25 = ctx_r56.$index;
      const ctx_r55 = i021.\u0275\u0275nextContext();
      return i021.\u0275\u0275resetView(ctx_r55.rateMessage(message_r24.id, i_r25, false));
    });
    i021.\u0275\u0275text(9, "\n                                                ");
    i021.\u0275\u0275element(10, "fa-icon", 41);
    i021.\u0275\u0275text(11, "\n                                            ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(12, "\n                                        ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(13, "\n                                    ");
  }
  if (rf & 2) {
    const message_r24 = i021.\u0275\u0275nextContext(3).$implicit;
    const ctx_r49 = i021.\u0275\u0275nextContext();
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275property("disabled", message_r24.helpful);
    i021.\u0275\u0275advance(2);
    i021.\u0275\u0275classMap(message_r24.helpful ? "thumbs-up-clicked" : "clickable rate-button-not-clicked");
    i021.\u0275\u0275property("icon", ctx_r49.faThumbsUp);
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275property("disabled", !message_r24.helpful);
    i021.\u0275\u0275advance(2);
    i021.\u0275\u0275classMap(message_r24.helpful === false ? "thumbs-down-clicked" : "clickable rate-button-not-clicked");
    i021.\u0275\u0275property("icon", ctx_r49.faThumbsDown);
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_For_4_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                                                        ");
    i021.\u0275\u0275elementStart(1, "div", 47);
    i021.\u0275\u0275text(2, "\n                                                            ");
    i021.\u0275\u0275element(3, "span", 37);
    i021.\u0275\u0275pipe(4, "htmlForMarkdown");
    i021.\u0275\u0275text(5, "\n                                                        ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(6, "\n                                                    ");
  }
  if (rf & 2) {
    const step_r61 = i021.\u0275\u0275nextContext().$implicit;
    const ctx_r66 = i021.\u0275\u0275nextContext(5);
    i021.\u0275\u0275advance(1);
    i021.\u0275\u0275attribute("contenteditable", ctx_r66.isNotExecuted(step_r61));
    i021.\u0275\u0275advance(2);
    i021.\u0275\u0275property("innerHTML", i021.\u0275\u0275pipeBind1(4, 2, step_r61.instructions), i021.\u0275\u0275sanitizeHtml);
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_For_4_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                                                        ");
    i021.\u0275\u0275elementStart(1, "div");
    i021.\u0275\u0275text(2, "\n                                                            ");
    i021.\u0275\u0275element(3, "i", 48);
    i021.\u0275\u0275text(4, "\n                                                        ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(5, "\n                                                    ");
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r70 = i021.\u0275\u0275getCurrentView();
    i021.\u0275\u0275text(0, "\n                                                ");
    i021.\u0275\u0275elementStart(1, "div");
    i021.\u0275\u0275text(2, "\n                                                    ");
    i021.\u0275\u0275text(3, "\n                                                    ");
    i021.\u0275\u0275elementStart(4, "div", 43);
    i021.\u0275\u0275text(5, "\n                                                        ");
    i021.\u0275\u0275elementStart(6, "div", 44);
    i021.\u0275\u0275text(7, "\n                                                            ");
    i021.\u0275\u0275element(8, "span", 37);
    i021.\u0275\u0275pipe(9, "htmlForMarkdown");
    i021.\u0275\u0275text(10, "\n                                                            ");
    i021.\u0275\u0275elementStart(11, "button", 45);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_For_4_Template_button_click_11_listener() {
      const restoredCtx = i021.\u0275\u0275restoreView(_r70);
      const step_r61 = restoredCtx.$implicit;
      const ctx_r69 = i021.\u0275\u0275nextContext(5);
      return i021.\u0275\u0275resetView(ctx_r69.hideOrUnhide(step_r61));
    });
    i021.\u0275\u0275text(12);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(13, "\n                                                        ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(14, "\n                                                        ");
    i021.\u0275\u0275element(15, "span", 46);
    i021.\u0275\u0275pipe(16, "htmlForMarkdown");
    i021.\u0275\u0275text(17, "\n                                                    ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(18, "\n                                                    ");
    i021.\u0275\u0275text(19, "\n                                                    ");
    i021.\u0275\u0275template(20, IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_For_4_Conditional_20_Template, 7, 4);
    i021.\u0275\u0275text(21, "\n                                                    ");
    i021.\u0275\u0275template(22, IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_For_4_Conditional_22_Template, 6, 0);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(23, "\n                                            ");
  }
  if (rf & 2) {
    const step_r61 = ctx.$implicit;
    const ctx_r58 = i021.\u0275\u0275nextContext(5);
    i021.\u0275\u0275advance(4);
    i021.\u0275\u0275property("ngStyle", i021.\u0275\u0275pureFunction1(11, _c5, ctx_r58.getStepColor(step_r61)))("ngClass", ctx_r58.isHidden(step_r61) ? "show-details" : "hide-details");
    i021.\u0275\u0275advance(4);
    i021.\u0275\u0275property("innerHTML", i021.\u0275\u0275pipeBind1(9, 7, ctx_r58.getStepName(step_r61)), i021.\u0275\u0275sanitizeHtml);
    i021.\u0275\u0275advance(4);
    i021.\u0275\u0275textInterpolate1("\n                                                                ", ctx_r58.isHidden(step_r61) ? "Show Details" : "Hide Details", "\n                                                            ");
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275property("innerHTML", i021.\u0275\u0275pipeBind1(16, 9, ctx_r58.getStepStatus(step_r61)), i021.\u0275\u0275sanitizeHtml);
    i021.\u0275\u0275advance(5);
    i021.\u0275\u0275conditional(20, !ctx_r58.isHidden(step_r61) ? 20 : -1);
    i021.\u0275\u0275advance(2);
    i021.\u0275\u0275conditional(22, ctx_r58.isInProgress(step_r61) ? 22 : -1);
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r73 = i021.\u0275\u0275getCurrentView();
    i021.\u0275\u0275text(0, "\n                                                    ");
    i021.\u0275\u0275elementStart(1, "div");
    i021.\u0275\u0275text(2, "\n                                                        ");
    i021.\u0275\u0275elementStart(3, "button", 49);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_Conditional_8_Template_button_click_3_listener() {
      i021.\u0275\u0275restoreView(_r73);
      const content_r32 = i021.\u0275\u0275nextContext(3).$implicit;
      const message_r24 = i021.\u0275\u0275nextContext().$implicit;
      const ctx_r71 = i021.\u0275\u0275nextContext();
      return i021.\u0275\u0275resetView(ctx_r71.setExecuting(message_r24.id, content_r32));
    });
    i021.\u0275\u0275text(4);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(5, "\n                                                    ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(6, "\n                                                ");
  }
  if (rf & 2) {
    const content_r32 = i021.\u0275\u0275nextContext(3).$implicit;
    const ctx_r59 = i021.\u0275\u0275nextContext(2);
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275property("disabled", !ctx_r59.canExecute(content_r32));
    i021.\u0275\u0275advance(1);
    i021.\u0275\u0275textInterpolate1("\n                                                            ", ctx_r59.getPlanButtonTitle(content_r32), "\n                                                        ");
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r78 = i021.\u0275\u0275getCurrentView();
    i021.\u0275\u0275text(0, "\n                                                    ");
    i021.\u0275\u0275elementStart(1, "div");
    i021.\u0275\u0275text(2, "\n                                                        ");
    i021.\u0275\u0275elementStart(3, "button", 50);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_Conditional_9_Template_button_click_3_listener() {
      i021.\u0275\u0275restoreView(_r78);
      const content_r32 = i021.\u0275\u0275nextContext(3).$implicit;
      const ctx_r76 = i021.\u0275\u0275nextContext(2);
      return i021.\u0275\u0275resetView(ctx_r76.pausePlan(content_r32));
    });
    i021.\u0275\u0275text(4, "Pause");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(5, "\n                                                    ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(6, "\n                                                ");
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                                        ");
    i021.\u0275\u0275elementStart(1, "div", 36);
    i021.\u0275\u0275text(2, "\n                                            ");
    i021.\u0275\u0275repeaterCreate(3, IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_For_4_Template, 24, 13, null, null, i021.\u0275\u0275repeaterTrackByIdentity);
    i021.\u0275\u0275text(5, "\n                                            ");
    i021.\u0275\u0275elementStart(6, "div", 42);
    i021.\u0275\u0275text(7, "\n                                                ");
    i021.\u0275\u0275template(8, IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_Conditional_8_Template, 7, 2)(9, IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_Conditional_9_Template, 7, 0);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(10, "\n                                        ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(11, "\n                                    ");
  }
  if (rf & 2) {
    const content_r32 = i021.\u0275\u0275nextContext(2).$implicit;
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275repeater(content_r32.steps);
    i021.\u0275\u0275advance(5);
    i021.\u0275\u0275conditional(8, !content_r32.executing ? 8 : -1);
    i021.\u0275\u0275advance(1);
    i021.\u0275\u0275conditional(9, content_r32.executing ? 9 : -1);
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                                ");
    i021.\u0275\u0275elementStart(1, "div", 35);
    i021.\u0275\u0275text(2, "\n                                    ");
    i021.\u0275\u0275template(3, IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_3_Template, 7, 3)(4, IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_4_Template, 14, 8)(5, IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Conditional_5_Template, 12, 2);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(6, "\n                            ");
  }
  if (rf & 2) {
    const content_r32 = i021.\u0275\u0275nextContext().$implicit;
    const ctx_r38 = i021.\u0275\u0275nextContext(2);
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275conditional(3, ctx_r38.isTextContent(content_r32) ? 3 : -1);
    i021.\u0275\u0275advance(1);
    i021.\u0275\u0275conditional(4, ctx_r38.isTextContent(content_r32) ? 4 : -1);
    i021.\u0275\u0275advance(1);
    i021.\u0275\u0275conditional(5, ctx_r38.isExercisePlan(content_r32) ? 5 : -1);
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_5_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                                        ");
    i021.\u0275\u0275elementStart(1, "div", 36);
    i021.\u0275\u0275text(2, "\n                                            ");
    i021.\u0275\u0275element(3, "span", 37);
    i021.\u0275\u0275text(4, "\n                                        ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(5, "\n                                    ");
  }
  if (rf & 2) {
    const content_r32 = i021.\u0275\u0275nextContext(2).$implicit;
    const ctx_r81 = i021.\u0275\u0275nextContext(2);
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275property("innerHTML", ctx_r81.getTextContent(content_r32), i021.\u0275\u0275sanitizeHtml);
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                                ");
    i021.\u0275\u0275elementStart(1, "div", 35);
    i021.\u0275\u0275text(2, "\n                                    ");
    i021.\u0275\u0275template(3, IrisChatbotWidgetComponent_For_45_For_5_Conditional_5_Conditional_3_Template, 6, 1);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    const content_r32 = i021.\u0275\u0275nextContext().$implicit;
    const ctx_r39 = i021.\u0275\u0275nextContext(2);
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275conditional(3, ctx_r39.isTextContent(content_r32) ? 3 : -1);
  }
}
function IrisChatbotWidgetComponent_For_45_For_5_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                        ");
    i021.\u0275\u0275elementStart(1, "div");
    i021.\u0275\u0275text(2, "\n                            ");
    i021.\u0275\u0275template(3, IrisChatbotWidgetComponent_For_45_For_5_Conditional_3_Template, 9, 2)(4, IrisChatbotWidgetComponent_For_45_For_5_Conditional_4_Template, 7, 3)(5, IrisChatbotWidgetComponent_For_45_For_5_Conditional_5_Template, 5, 1);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(6, "\n                    ");
  }
  if (rf & 2) {
    const message_r24 = i021.\u0275\u0275nextContext().$implicit;
    const ctx_r30 = i021.\u0275\u0275nextContext();
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275conditional(3, ctx_r30.isStudentSentMessage(message_r24) ? 3 : -1);
    i021.\u0275\u0275advance(1);
    i021.\u0275\u0275conditional(4, ctx_r30.isServerSentMessage(message_r24) ? 4 : -1);
    i021.\u0275\u0275advance(1);
    i021.\u0275\u0275conditional(5, ctx_r30.isArtemisClientSentMessage(message_r24) ? 5 : -1);
  }
}
function IrisChatbotWidgetComponent_For_45_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                ");
    i021.\u0275\u0275elementStart(1, "div");
    i021.\u0275\u0275text(2, "\n                    ");
    i021.\u0275\u0275template(3, IrisChatbotWidgetComponent_For_45_Conditional_3_Template, 6, 3);
    i021.\u0275\u0275repeaterCreate(4, IrisChatbotWidgetComponent_For_45_For_5_Template, 7, 3, null, null, i021.\u0275\u0275repeaterTrackByIdentity);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(6, "\n            ");
  }
  if (rf & 2) {
    const message_r24 = ctx.$implicit;
    const i_r25 = ctx.$index;
    const ctx_r7 = i021.\u0275\u0275nextContext();
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275conditional(3, i_r25 === ctx_r7.unreadMessageIndex ? 3 : -1);
    i021.\u0275\u0275advance(1);
    i021.\u0275\u0275repeater(message_r24.content);
  }
}
function IrisChatbotWidgetComponent_Conditional_46_For_6_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                            ");
    i021.\u0275\u0275elementStart(1, "div", 52);
    i021.\u0275\u0275text(2, "\n                                ");
    i021.\u0275\u0275element(3, "fa-icon", 53);
    i021.\u0275\u0275text(4, "\n                            ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(5, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r85 = i021.\u0275\u0275nextContext(2);
    i021.\u0275\u0275advance(3);
    i021.\u0275\u0275property("icon", ctx_r85.faCircle);
  }
}
function IrisChatbotWidgetComponent_Conditional_46_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                ");
    i021.\u0275\u0275elementStart(1, "div", 36);
    i021.\u0275\u0275text(2, "\n                    ");
    i021.\u0275\u0275elementStart(3, "div", 51);
    i021.\u0275\u0275text(4, "\n                        ");
    i021.\u0275\u0275repeaterCreate(5, IrisChatbotWidgetComponent_Conditional_46_For_6_Template, 6, 1, null, null, i021.\u0275\u0275repeaterTrackByIdentity);
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(7, "\n                ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(8, "\n            ");
  }
  if (rf & 2) {
    const ctx_r8 = i021.\u0275\u0275nextContext();
    i021.\u0275\u0275advance(5);
    i021.\u0275\u0275repeater(i021.\u0275\u0275pureFunction0(0, _c6).constructor(ctx_r8.dots));
  }
}
function IrisChatbotWidgetComponent_Conditional_47_Template(rf, ctx) {
  if (rf & 1) {
    const _r92 = i021.\u0275\u0275getCurrentView();
    i021.\u0275\u0275text(0, "\n                ");
    i021.\u0275\u0275elementStart(1, "div", 54);
    i021.\u0275\u0275text(2, "\n                    ");
    i021.\u0275\u0275elementStart(3, "div", 55);
    i021.\u0275\u0275text(4);
    i021.\u0275\u0275pipe(5, "artemisTranslate");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(6, "\n                    ");
    i021.\u0275\u0275elementStart(7, "div", 8);
    i021.\u0275\u0275text(8, "\n                        ");
    i021.\u0275\u0275elementStart(9, "button", 56);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_Conditional_47_Template_button_click_9_listener() {
      i021.\u0275\u0275restoreView(_r92);
      const ctx_r91 = i021.\u0275\u0275nextContext();
      return i021.\u0275\u0275resetView(ctx_r91.acceptPermission());
    });
    i021.\u0275\u0275text(10);
    i021.\u0275\u0275pipe(11, "artemisTranslate");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(12, "\n                        ");
    i021.\u0275\u0275elementStart(13, "button", 56);
    i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_Conditional_47_Template_button_click_13_listener() {
      i021.\u0275\u0275restoreView(_r92);
      const ctx_r93 = i021.\u0275\u0275nextContext();
      return i021.\u0275\u0275resetView(ctx_r93.closeChat());
    });
    i021.\u0275\u0275text(14);
    i021.\u0275\u0275pipe(15, "artemisTranslate");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(16, "\n                    ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(17, "\n                ");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(18, "\n            ");
  }
  if (rf & 2) {
    i021.\u0275\u0275advance(4);
    i021.\u0275\u0275textInterpolate(i021.\u0275\u0275pipeBind1(5, 3, "artemisApp.exerciseChatbot.popUpMessage"));
    i021.\u0275\u0275advance(6);
    i021.\u0275\u0275textInterpolate(i021.\u0275\u0275pipeBind1(11, 5, "artemisApp.exerciseChatbot.accept"));
    i021.\u0275\u0275advance(4);
    i021.\u0275\u0275textInterpolate(i021.\u0275\u0275pipeBind1(15, 7, "artemisApp.exerciseChatbot.decline"));
  }
}
function IrisChatbotWidgetComponent_Conditional_54_Template(rf, ctx) {
  if (rf & 1) {
    const _r95 = i021.\u0275\u0275getCurrentView();
    i021.\u0275\u0275text(0, "\n                ");
    i021.\u0275\u0275elementStart(1, "div", 57);
    i021.\u0275\u0275listener("@fadeAnimation.done", function IrisChatbotWidgetComponent_Conditional_54_Template_div_animation_fadeAnimation_done_1_listener($event) {
      i021.\u0275\u0275restoreView(_r95);
      const ctx_r94 = i021.\u0275\u0275nextContext();
      return i021.\u0275\u0275resetView(ctx_r94.onFadeAnimationPhaseEnd($event));
    });
    i021.\u0275\u0275text(2);
    i021.\u0275\u0275pipe(3, "artemisTranslate");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    const ctx_r11 = i021.\u0275\u0275nextContext();
    i021.\u0275\u0275advance(1);
    i021.\u0275\u0275property("@fadeAnimation", ctx_r11.fadeState);
    i021.\u0275\u0275advance(1);
    i021.\u0275\u0275textInterpolate1("\n                    ", i021.\u0275\u0275pipeBind1(3, 2, ctx_r11.error.key), "\n                ");
  }
}
function IrisChatbotWidgetComponent_Conditional_55_Template(rf, ctx) {
  if (rf & 1) {
    i021.\u0275\u0275text(0, "\n                ");
    i021.\u0275\u0275elementStart(1, "div", 57);
    i021.\u0275\u0275text(2);
    i021.\u0275\u0275pipe(3, "artemisTranslate");
    i021.\u0275\u0275elementEnd();
    i021.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    const ctx_r12 = i021.\u0275\u0275nextContext();
    i021.\u0275\u0275advance(2);
    i021.\u0275\u0275textInterpolate1("\n                    ", i021.\u0275\u0275pipeBind2(3, 1, ctx_r12.error.key, ctx_r12.getConvertedErrorMap()), "\n                ");
  }
}
var _c02, _c1, _c2, _c3, _c4, _c5, _c6, IrisChatbotWidgetComponent;
var init_chatbot_widget_component = __esm({
  "src/main/webapp/app/iris/exercise-chatbot/widget/chatbot-widget.component.ts"() {
    init_button_component();
    init_state_store_model();
    init_iris_message_model();
    init_iris_content_type_model();
    init_shared_service();
    init_iris_errors_model();
    init_user_service();
    init_iris_logo_component();
    init_chat_session_service();
    init_code_editor_session_service();
    init_user_service();
    init_shared_service();
    init_button_component();
    init_iris_logo_component();
    init_artemis_translate_pipe();
    init_html_for_markdown_pipe();
    _c02 = ["chatBody"];
    _c1 = ["scrollArrow"];
    _c2 = ["messageTextarea"];
    _c3 = ["unreadMessage"];
    _c4 = (a0) => ({ hours: a0 });
    _c5 = (a0) => ({ "background-color": a0 });
    _c6 = () => [];
    IrisChatbotWidgetComponent = class _IrisChatbotWidgetComponent {
      dialog;
      data;
      userService;
      router;
      sharedService;
      modalService;
      document;
      translateService;
      faTrash = faTrash2;
      faCircle = faCircle;
      faPaperPlane = faPaperPlane;
      faExpand = faExpand;
      faXmark = faXmark;
      faArrowDown = faArrowDown;
      faRobot = faRobot;
      faCircleInfo = faCircleInfo;
      faCompress = faCompress;
      faThumbsUp = faThumbsUp;
      faThumbsDown = faThumbsDown;
      faRedo = faRedo;
      chatBody;
      scrollArrow;
      messageTextarea;
      unreadMessage;
      stateStore;
      stateSubscription;
      messages = [];
      content;
      newMessageTextContent = "";
      isLoading;
      sessionId;
      numNewMessages = 0;
      unreadMessageIndex;
      error;
      dots = 1;
      resendAnimationActive = false;
      shakeErrorField = false;
      shouldLoadGreetingMessage = true;
      fadeState = "";
      courseId;
      exerciseId;
      sessionService;
      shouldShowEmptyMessageError = false;
      currentMessageCount;
      rateLimit;
      rateLimitTimeframeHours;
      importExerciseUrl;
      userAccepted;
      isScrolledToBottom = true;
      rows = 1;
      initialWidth = 330;
      initialHeight = 430;
      fullWidthFactor = 0.93;
      fullHeightFactor = 0.85;
      fullSize = false;
      ButtonType = ButtonType;
      IrisLogoSize = IrisLogoSize;
      navigationSubscription;
      MAX_INT_JAVA = 2147483647;
      constructor(dialog, data, userService, router, sharedService, modalService, document2, translateService) {
        this.dialog = dialog;
        this.data = data;
        this.userService = userService;
        this.router = router;
        this.sharedService = sharedService;
        this.modalService = modalService;
        this.document = document2;
        this.translateService = translateService;
        this.stateStore = data.stateStore;
        this.courseId = data.courseId;
        this.exerciseId = data.exerciseId;
        this.sessionService = data.sessionService;
        this.navigationSubscription = this.router.events.subscribe((event) => {
          if (event instanceof NavigationStart) {
            this.dialog.closeAll();
          }
        });
        this.fullSize = data.fullSize ?? false;
      }
      ngOnInit() {
        this.userService.getIrisAcceptedAt().subscribe((res) => {
          this.userAccepted = !!res;
          if (this.userAccepted) {
            this.loadFirstMessage();
          }
        });
        this.animateDots();
        this.stateSubscription = this.stateStore.getState().subscribe((state2) => {
          this.messages = state2.messages;
          this.isLoading = state2.isLoading;
          this.error = state2.error;
          this.sessionId = Number(state2.sessionId);
          this.numNewMessages = state2.numNewMessages;
          if (state2.error?.key == IrisErrorMessageKey.EMPTY_MESSAGE) {
            this.shouldShowEmptyMessageError = true;
            this.fadeState = "start";
          }
          if (this.error) {
            this.getConvertedErrorMap();
          }
          this.currentMessageCount = state2.currentMessageCount;
          this.rateLimit = state2.rateLimit;
          this.rateLimitTimeframeHours = state2.rateLimitTimeframeHours;
        });
        setTimeout(() => {
          this.messageTextarea.nativeElement.focus();
        }, 150);
      }
      ngAfterViewInit() {
        this.unreadMessageIndex = this.messages.length <= 1 || this.numNewMessages === 0 ? -1 : this.messages.length - this.numNewMessages;
        if (this.numNewMessages > 0) {
          this.scrollToUnread();
        } else {
          this.scrollToBottom("auto");
        }
        interact(".chat-widget").resizable({
          edges: { left: true, right: true, bottom: true, top: true },
          listeners: {
            move: (event) => {
              const target = event.target;
              let x = parseFloat(target.getAttribute("data-x")) || 0;
              let y = parseFloat(target.getAttribute("data-y")) || 0;
              target.style.width = event.rect.width + "px";
              target.style.height = event.rect.height + "px";
              const cntRect = this.document.querySelector(".cdk-overlay-container").getBoundingClientRect();
              this.fullSize = !(event.rect.width < cntRect.width * this.fullWidthFactor || event.rect.height < cntRect.height * this.fullHeightFactor);
              x += event.deltaRect.left;
              y += event.deltaRect.top;
              target.style.transform = "translate(" + x + "px," + y + "px)";
              target.setAttribute("data-x", x);
              target.setAttribute("data-y", y);
            }
          },
          modifiers: [
            interact.modifiers.restrictEdges({
              outer: ".cdk-overlay-container"
            }),
            interact.modifiers.restrictSize({
              min: { width: this.initialWidth, height: this.initialHeight }
            })
          ],
          inertia: true
        }).draggable({
          listeners: {
            move: (event) => {
              const target = event.target, x = (parseFloat(target.getAttribute("data-x")) || 0) + event.dx, y = (parseFloat(target.getAttribute("data-y")) || 0) + event.dy;
              target.style.transform = "translate(" + x + "px, " + y + "px)";
              target.setAttribute("data-x", x);
              target.setAttribute("data-y", y);
            }
          },
          inertia: true,
          modifiers: [
            interact.modifiers.restrictRect({
              restriction: ".cdk-overlay-container",
              endOnly: true
            })
          ]
        });
        this.setPositionAndScale();
      }
      setPositionAndScale() {
        const cntRect = this.document.querySelector(".cdk-overlay-container")?.getBoundingClientRect();
        if (!cntRect) {
          return;
        }
        const initX = this.fullSize ? cntRect.width * (1 - this.fullWidthFactor) / 2 : cntRect.width - this.initialWidth - 20;
        const initY = this.fullSize ? cntRect.height * (1 - this.fullHeightFactor) / 2 : cntRect.height - this.initialHeight - 20;
        const nE = this.document.querySelector(".chat-widget");
        nE.style.transform = `translate(${initX}px, ${initY}px)`;
        nE.setAttribute("data-x", String(initX));
        nE.setAttribute("data-y", String(initY));
        if (this.fullSize) {
          nE.style.width = `${cntRect.width * this.fullWidthFactor}px`;
          nE.style.height = `${cntRect.height * this.fullHeightFactor}px`;
        } else {
          nE.style.width = `${this.initialWidth}px`;
          nE.style.height = `${this.initialHeight}px`;
        }
      }
      ngOnDestroy() {
        this.stateSubscription.unsubscribe();
        this.navigationSubscription.unsubscribe();
        this.toggleScrollLock(false);
      }
      getFirstMessageContent() {
        if (this.isChatSession()) {
          return this.translateService.instant("artemisApp.exerciseChatbot.tutorFirstMessage");
        }
        this.importExerciseUrl = `/course-management/${this.courseId}/programming-exercises/import/${this.exerciseId}`;
        return this.translateService.instant("artemisApp.exerciseChatbot.codeEditorFirstMessage").replace(/{link:(.*)}/, '<a href="' + this.importExerciseUrl + '" target="_blank">$1</a>');
      }
      loadFirstMessage() {
        const firstMessageContent = {
          type: IrisMessageContentType.TEXT,
          textContent: this.getFirstMessageContent()
        };
        const firstMessage = {
          sender: IrisSender.ARTEMIS_CLIENT,
          content: [firstMessageContent],
          sentAt: dayjs()
        };
        if (this.messages.length === 0) {
          this.stateStore.dispatch(new ActiveConversationMessageLoadedAction(firstMessage));
        }
      }
      onSend() {
        if (this.error?.fatal) {
          return;
        }
        if (this.newMessageTextContent.trim() === "") {
          this.stateStore.dispatchAndThen(new ConversationErrorOccurredAction(IrisErrorMessageKey.EMPTY_MESSAGE)).catch(() => this.scrollToBottom("smooth"));
          return;
        }
        if (this.newMessageTextContent) {
          const message = this.newUserMessage(this.newMessageTextContent);
          const timeoutId = setTimeout(() => {
            this.stateStore.dispatch(new ConversationErrorOccurredAction(IrisErrorMessageKey.IRIS_SERVER_RESPONSE_TIMEOUT));
            this.scrollToBottom("smooth");
          }, 2e4);
          this.stateStore.dispatchAndThen(new StudentMessageSentAction(message, timeoutId)).then(() => this.sessionService.sendMessage(this.sessionId, message)).then(() => this.scrollToBottom("smooth")).catch((error) => this.handleIrisError(error));
          this.newMessageTextContent = "";
        }
        this.scrollToBottom("smooth");
        this.resetChatBodyHeight();
      }
      resendMessage(message) {
        this.resendAnimationActive = true;
        message.messageDifferentiator = message.id ?? Math.floor(Math.random() * this.MAX_INT_JAVA);
        const timeoutId = setTimeout(() => {
          this.stateStore.dispatch(new ConversationErrorOccurredAction(IrisErrorMessageKey.IRIS_SERVER_RESPONSE_TIMEOUT));
          this.scrollToBottom("smooth");
        }, 2e6);
        this.stateStore.dispatchAndThen(new StudentMessageSentAction(message, timeoutId)).then(() => {
          if (message.id) {
            return this.sessionService.resendMessage(this.sessionId, message);
          } else {
            return this.sessionService.sendMessage(this.sessionId, message);
          }
        }).then(() => {
          this.scrollToBottom("smooth");
        }).catch((error) => this.handleIrisError(error)).finally(() => {
          this.resendAnimationActive = false;
          this.scrollToBottom("smooth");
        });
      }
      handleIrisError(error) {
        if (error.status === 403) {
          this.stateStore.dispatch(new ConversationErrorOccurredAction(IrisErrorMessageKey.IRIS_DISABLED));
        } else if (error.status === 429) {
          const map3 = /* @__PURE__ */ new Map();
          map3.set("hours", this.rateLimitTimeframeHours);
          this.stateStore.dispatch(new ConversationErrorOccurredAction(IrisErrorMessageKey.RATE_LIMIT_EXCEEDED, map3));
        } else {
          this.stateStore.dispatch(new ConversationErrorOccurredAction(IrisErrorMessageKey.SEND_MESSAGE_FAILED));
        }
      }
      rateMessage(messageId, index, helpful) {
        this.sessionService.rateMessage(this.sessionId, messageId, helpful).then(() => this.stateStore.dispatch(new RateMessageSuccessAction(index, helpful))).catch(() => {
          this.stateStore.dispatch(new ConversationErrorOccurredAction(IrisErrorMessageKey.RATE_MESSAGE_FAILED));
          this.scrollToBottom("smooth");
        });
      }
      closeChat() {
        this.stateStore.dispatch(new NumNewMessagesResetAction());
        this.sharedService.changeChatOpenStatus(false);
        this.dialog.closeAll();
      }
      animateDots() {
        setInterval(() => {
          this.dots = this.dots < 3 ? this.dots += 1 : this.dots = 1;
        }, 500);
      }
      scrollToUnread() {
        setTimeout(() => {
          const unreadMessageElement = this.unreadMessage?.nativeElement;
          if (unreadMessageElement) {
            unreadMessageElement.scrollIntoView({ behavior: "auto" });
          }
        });
      }
      scrollToBottom(behavior) {
        setTimeout(() => {
          const chatBodyElement = this.chatBody.nativeElement;
          chatBodyElement.scrollTo({
            top: chatBodyElement.scrollHeight,
            behavior
          });
        });
      }
      checkChatScroll() {
        const chatBody = this.chatBody.nativeElement;
        const scrollHeight = chatBody.scrollHeight;
        const scrollTop = chatBody.scrollTop;
        const clientHeight = chatBody.clientHeight;
        this.isScrolledToBottom = scrollHeight - scrollTop - clientHeight < 50;
      }
      onClearSession(content) {
        this.modalService.open(content).result.then((result) => {
          if (result === "confirm") {
            this.isLoading = false;
            this.createNewSession();
          }
        });
      }
      acceptPermission() {
        this.userService.acceptIris().subscribe(() => {
          this.userAccepted = true;
        });
        this.loadFirstMessage();
      }
      maximizeScreen() {
        this.fullSize = true;
        this.setPositionAndScale();
      }
      minimizeScreen() {
        this.fullSize = false;
        this.setPositionAndScale();
      }
      handleKey(event) {
        if (event.key === "Enter") {
          if (!this.deactivateSubmitButton()) {
            if (!event.shiftKey) {
              event.preventDefault();
              this.onSend();
            } else {
              const textArea = event.target;
              const { selectionStart, selectionEnd } = textArea;
              const value = textArea.value;
              textArea.value = value.slice(0, selectionStart) + value.slice(selectionEnd);
              textArea.selectionStart = textArea.selectionEnd = selectionStart + 1;
            }
          } else {
            event.preventDefault();
          }
        }
      }
      onInput() {
        this.adjustTextareaRows();
      }
      onPaste() {
        setTimeout(() => {
          this.adjustTextareaRows();
        }, 0);
      }
      adjustTextareaRows() {
        const textarea = this.messageTextarea.nativeElement;
        textarea.style.height = "auto";
        const lineHeight = parseInt(getComputedStyle(textarea).lineHeight, 10);
        const maxRows = 3;
        const maxHeight = lineHeight * maxRows;
        textarea.style.height = `${Math.min(textarea.scrollHeight, maxHeight)}px`;
        this.adjustChatBodyHeight(Math.min(textarea.scrollHeight, maxHeight) / lineHeight);
      }
      onRowChange() {
        const textarea = this.messageTextarea.nativeElement;
        const newRows = textarea.value.split("\n").length;
        if (newRows != this.rows) {
          if (newRows <= 3) {
            textarea.rows = newRows;
            this.adjustChatBodyHeight(newRows);
            this.rows = newRows;
          }
        }
      }
      adjustChatBodyHeight(newRows) {
        const textarea = this.messageTextarea.nativeElement;
        const chatBody = this.chatBody.nativeElement;
        const scrollArrow = this.scrollArrow.nativeElement;
        const lineHeight = parseInt(window.getComputedStyle(textarea).lineHeight);
        const rowHeight = lineHeight * newRows;
        setTimeout(() => {
          scrollArrow.style.bottom = `calc(11% + ${rowHeight}px)`;
        }, 10);
        setTimeout(() => {
          chatBody.style.height = `calc(100% - ${rowHeight}px - 64px)`;
        }, 10);
      }
      resetChatBodyHeight() {
        const chatBody = this.chatBody.nativeElement;
        const textarea = this.messageTextarea.nativeElement;
        const scrollArrow = this.scrollArrow.nativeElement;
        textarea.rows = 1;
        textarea.style.height = "";
        scrollArrow.style.bottom = "";
        chatBody.style.height = "";
        this.stateStore.dispatch(new NumNewMessagesResetAction());
      }
      getPlanButtonTitle(plan) {
        if (plan.executing) {
          return "Pause";
        }
        const nextStepIndex = this.getNextStepIndex(plan);
        if (nextStepIndex >= plan.steps.length) {
          return "Completed";
        }
        const nextStep = plan.steps[nextStepIndex];
        if (isFailed(nextStep)) {
          return "Retry";
        }
        if (nextStepIndex === 0) {
          return "Execute";
        }
        return "Resume";
      }
      pausePlan(plan) {
        plan.executing = false;
      }
      getNextStepIndex(plan) {
        for (let i = plan.steps.length - 1; i >= 0; i--) {
          const step = plan.steps[i];
          if (isComplete(step)) {
            return i + 1;
          }
        }
        return 0;
      }
      canExecute(plan) {
        return this.getNextStepIndex(plan) < plan.steps.length;
      }
      setExecuting(messageId, plan) {
        const nextStepIndex = this.getNextStepIndex(plan);
        if (nextStepIndex >= plan.steps.length) {
          console.error("Tried to execute plan that is already complete.");
          return;
        }
        const step = plan.steps[nextStepIndex];
        if (!step) {
          console.error("Could not find next step to execute.");
          return;
        }
        plan.executing = true;
        if (isInProgress(step)) {
          console.log("Step already in progress, awaiting response.");
          return;
        }
        this.executePlanStep(messageId, step);
      }
      executePlanStep(messageId, step) {
        if (!(this.sessionService instanceof IrisCodeEditorSessionService)) {
          return;
        }
        if (!step.id || !step.plan) {
          console.error("Could not execute plan step, one of the required ids is null: " + step.id + " " + step.plan);
          return;
        }
        step.executionStage = ExecutionStage.IN_PROGRESS;
        this.sessionService.executePlanStep(this.sessionId, messageId, step.plan, step.id).catch(() => {
          step.executionStage = ExecutionStage.FAILED;
          this.scrollToBottom("smooth");
        });
      }
      notifyStepCompleted(messageId, planId, stepId) {
        const [plan, step] = this.findPlanStep(messageId, planId, stepId);
        if (!plan || !step) {
          return;
        }
        step.executionStage = ExecutionStage.COMPLETE;
        if (plan.executing) {
          const nextStepIndex = this.getNextStepIndex(plan);
          if (nextStepIndex < plan.steps.length) {
            this.executePlanStep(messageId, plan.steps[nextStepIndex]);
          } else {
            plan.executing = false;
          }
        }
      }
      notifyStepFailed(messageId, planId, stepId, errorTranslationKey, translationParams) {
        const [plan, step] = this.findPlanStep(messageId, planId, stepId);
        if (!plan || !step) {
          return;
        }
        plan.executing = false;
        step.executionStage = ExecutionStage.FAILED;
        if (!errorTranslationKey) {
          this.stateStore.dispatch(new ConversationErrorOccurredAction(IrisErrorMessageKey.TECHNICAL_ERROR_RESPONSE));
        } else {
          this.stateStore.dispatch(new ConversationErrorOccurredAction(errorTranslationKey, translationParams));
        }
      }
      findPlanStep(messageId, planId, stepId) {
        const message = this.messages.find((m) => m.id === messageId);
        if (!message) {
          console.error("Could not find message with id " + messageId);
          return [void 0, void 0];
        }
        const plan = message.content.find((c) => c.id === planId);
        if (!plan) {
          console.error("Could not find plan with id " + planId);
          return [void 0, void 0];
        }
        const step = plan.steps.find((s) => s.id === stepId);
        if (!step) {
          console.error("Could not find exercise step with id " + stepId);
          return [plan, void 0];
        }
        return [plan, step];
      }
      getStepColor(step) {
        switch (step.executionStage) {
          case ExecutionStage.NOT_EXECUTED:
            return "var(--iris-chat-widget-background)";
          case ExecutionStage.IN_PROGRESS:
            return "#ffc107";
          case ExecutionStage.COMPLETE:
            return "#28a745";
          case ExecutionStage.FAILED:
            return "#dc3545";
        }
      }
      getStepName(step) {
        switch (step.component) {
          case ExerciseComponent.PROBLEM_STATEMENT:
            return "Problem Statement";
          case ExerciseComponent.SOLUTION_REPOSITORY:
            return "Solution Repository";
          case ExerciseComponent.TEMPLATE_REPOSITORY:
            return "Template Repository";
          case ExerciseComponent.TEST_REPOSITORY:
            return "Test Repository";
        }
      }
      getStepStatus(step) {
        switch (step.executionStage) {
          case ExecutionStage.NOT_EXECUTED:
            return "";
          case ExecutionStage.IN_PROGRESS:
            return "Generating changes, please be patient...";
          case ExecutionStage.COMPLETE:
            return "Changes applied.";
          case ExecutionStage.FAILED:
            return "Encountered an error.";
        }
      }
      newUserMessage(message) {
        const content = new IrisTextMessageContent(message);
        return {
          sender: IrisSender.USER,
          content: [content]
        };
      }
      isSendMessageFailedError() {
        return this.error?.key == IrisErrorMessageKey.SEND_MESSAGE_FAILED || this.error?.key == IrisErrorMessageKey.IRIS_SERVER_RESPONSE_TIMEOUT;
      }
      toggleScrollLock(lockParent) {
        if (lockParent) {
          document.body.classList.add("cdk-global-scroll");
        } else {
          document.body.classList.remove("cdk-global-scroll");
        }
      }
      deactivateSubmitButton() {
        return !this.userAccepted || this.isLoading || !!this.error && this.error.fatal;
      }
      isEmptyMessageError() {
        return !!this.error && this.error.key == IrisErrorMessageKey.EMPTY_MESSAGE;
      }
      onFadeAnimationPhaseEnd(event) {
        if (event.fromState === "void" && event.toState === "start") {
          this.fadeState = "end";
        }
        if (event.fromState === "start" && event.toState === "end") {
          this.shouldShowEmptyMessageError = false;
        }
      }
      getConvertedErrorMap() {
        if (this.error?.paramsMap) {
          if (typeof this.error?.paramsMap[Symbol.iterator] === "function") {
            return Object.fromEntries(this.error.paramsMap);
          }
          return this.error.paramsMap;
        }
        return null;
      }
      isClearChatButtonEnabled() {
        return this.messages.length > 1 || this.messages.length === 1 && !isArtemisClientSentMessage(this.messages[0]);
      }
      createNewSession() {
        this.sessionService.createNewSession(this.exerciseId);
      }
      isChatSession() {
        return this.sessionService instanceof IrisChatSessionService;
      }
      IrisSender = IrisSender;
      isInProgress = isInProgress;
      getTextContent = getTextContent;
      isTextContent = isTextContent;
      isNotExecuted = isNotExecuted;
      isExercisePlan = isExercisePlan;
      isHidden = isHidden;
      hideOrUnhide = hideOrUnhide;
      isStudentSentMessage = isStudentSentMessage;
      isServerSentMessage = isServerSentMessage;
      isArtemisClientSentMessage = isArtemisClientSentMessage;
      static \u0275fac = function IrisChatbotWidgetComponent_Factory(t) {
        return new (t || _IrisChatbotWidgetComponent)(i021.\u0275\u0275directiveInject(i110.MatDialog), i021.\u0275\u0275directiveInject(MAT_DIALOG_DATA), i021.\u0275\u0275directiveInject(UserService), i021.\u0275\u0275directiveInject(i32.Router), i021.\u0275\u0275directiveInject(SharedService), i021.\u0275\u0275directiveInject(i5.NgbModal), i021.\u0275\u0275directiveInject(DOCUMENT), i021.\u0275\u0275directiveInject(i6.TranslateService));
      };
      static \u0275cmp = i021.\u0275\u0275defineComponent({ type: _IrisChatbotWidgetComponent, selectors: [["jhi-chatbot-widget"]], viewQuery: function IrisChatbotWidgetComponent_Query(rf, ctx) {
        if (rf & 1) {
          i021.\u0275\u0275viewQuery(_c02, 5);
          i021.\u0275\u0275viewQuery(_c1, 5);
          i021.\u0275\u0275viewQuery(_c2, 5);
          i021.\u0275\u0275viewQuery(_c3, 5);
        }
        if (rf & 2) {
          let _t;
          i021.\u0275\u0275queryRefresh(_t = i021.\u0275\u0275loadQuery()) && (ctx.chatBody = _t.first);
          i021.\u0275\u0275queryRefresh(_t = i021.\u0275\u0275loadQuery()) && (ctx.scrollArrow = _t.first);
          i021.\u0275\u0275queryRefresh(_t = i021.\u0275\u0275loadQuery()) && (ctx.messageTextarea = _t.first);
          i021.\u0275\u0275queryRefresh(_t = i021.\u0275\u0275loadQuery()) && (ctx.unreadMessage = _t.first);
        }
      }, decls: 70, vars: 21, consts: [[1, "container", 3, "mouseenter", "mouseleave"], [1, "chat-widget"], [1, "client"], [1, "chat-header"], [1, "header-start"], [3, "size"], ["target", "_blank", 3, "routerLink"], [1, "info-button", 3, "icon"], [1, "button-container"], [1, "header-icon", 3, "click"], [3, "icon"], ["clearConfirmModal", ""], [1, "chat-body", 3, "scroll"], ["chatBody", ""], [1, "scroll-to-bottom", 3, "hidden", "click"], ["scrollArrow", ""], [1, "chat-input"], ["rows", "1", "type", "text", 1, "form-control", 3, "ngModel", "placeholder", "ngModelChange", "input", "paste", "keydown"], ["messageTextarea", ""], ["id", "sendButton", 2, "margin-bottom", "auto", 3, "btnType", "icon", "disabled", "onClick"], [1, "rate-limit", 3, "ngbTooltip"], ["id", "clear-chat-button", 1, "header-icon", 3, "click"], [1, "modal-header"], [1, "modal-title"], ["type", "button", "aria-label", "Close", 1, "btn-close", 3, "click"], [1, "modal-body"], [1, "modal-footer"], ["type", "button", 1, "btn", "btn-danger", 3, "click"], [1, "unread-message"], ["unreadMessage", ""], [2, "display", "flex"], [2, "display", "flex", "margin-left", "auto", "margin-right", "0", "padding-right", "5px"], ["id", "resendButton", 2, "all", "unset", "display", "flex", "align-items", "flex-start", "justify-content", "space-between", "cursor", "pointer", 3, "disabled", "click"], ["size", "sm", 3, "icon", "ngClass"], [1, "bubble-right", 3, "innerHTML"], [2, "width", "fit-content"], [1, "bubble-left"], [3, "innerHTML"], [1, "rate-message-buttons"], [2, "all", "unset", 3, "disabled", "click"], ["size", "sm", 2, "margin-right", "15px", 3, "icon"], ["size", "sm", 3, "icon"], [1, "execute-button"], [3, "ngStyle", "ngClass"], [1, "step-component"], [1, "detail-btn", "step-title", 3, "click"], [1, "step-status", 3, "innerHTML"], [1, "step-detail"], [1, "fa", "fa-spinner", "fa-spin"], [1, "btn", "btn-primary", 3, "disabled", "click"], [1, "btn", "btn-danger", 3, "click"], [1, "blinking-dots"], [1, "d-inline"], ["size", "xs", 3, "icon"], [1, "p-chat"], [1, "message-text"], [1, "button", 3, "click"], [1, "client-chat-error"]], template: function IrisChatbotWidgetComponent_Template(rf, ctx) {
        if (rf & 1) {
          i021.\u0275\u0275elementStart(0, "div", 0);
          i021.\u0275\u0275listener("mouseenter", function IrisChatbotWidgetComponent_Template_div_mouseenter_0_listener() {
            return ctx.toggleScrollLock(true);
          })("mouseleave", function IrisChatbotWidgetComponent_Template_div_mouseleave_0_listener() {
            return ctx.toggleScrollLock(false);
          });
          i021.\u0275\u0275text(1, "\n    ");
          i021.\u0275\u0275text(2, "\n    ");
          i021.\u0275\u0275elementStart(3, "div", 1);
          i021.\u0275\u0275text(4, "\n        ");
          i021.\u0275\u0275text(5, "\n        ");
          i021.\u0275\u0275elementStart(6, "div", 2);
          i021.\u0275\u0275text(7, "\n            ");
          i021.\u0275\u0275elementStart(8, "div", 3);
          i021.\u0275\u0275text(9, "\n                ");
          i021.\u0275\u0275elementStart(10, "h3", 4);
          i021.\u0275\u0275text(11, "\n                    ");
          i021.\u0275\u0275element(12, "jhi-iris-logo", 5);
          i021.\u0275\u0275text(13, "\n                    Iris\n                    ");
          i021.\u0275\u0275elementStart(14, "a", 6);
          i021.\u0275\u0275text(15, "\n                        ");
          i021.\u0275\u0275element(16, "fa-icon", 7);
          i021.\u0275\u0275text(17, "\n                    ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(18, "\n                ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(19, "\n                ");
          i021.\u0275\u0275elementStart(20, "div");
          i021.\u0275\u0275text(21, "\n                    ");
          i021.\u0275\u0275elementStart(22, "div", 8);
          i021.\u0275\u0275text(23, "\n                        ");
          i021.\u0275\u0275template(24, IrisChatbotWidgetComponent_Conditional_24_Template, 5, 8)(25, IrisChatbotWidgetComponent_Conditional_25_Template, 6, 1)(26, IrisChatbotWidgetComponent_Conditional_26_Template, 6, 1)(27, IrisChatbotWidgetComponent_Conditional_27_Template, 6, 1);
          i021.\u0275\u0275elementStart(28, "button", 9);
          i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_Template_button_click_28_listener() {
            return ctx.closeChat();
          });
          i021.\u0275\u0275text(29, "\n                            ");
          i021.\u0275\u0275element(30, "fa-icon", 10);
          i021.\u0275\u0275text(31, "\n                        ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(32, "\n                    ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(33, "\n                ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(34, "\n            ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(35, "\n        ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(36, "\n        ");
          i021.\u0275\u0275template(37, IrisChatbotWidgetComponent_ng_template_37_Template, 30, 9, "ng-template", null, 11, i021.\u0275\u0275templateRefExtractor);
          i021.\u0275\u0275text(39, "\n        ");
          i021.\u0275\u0275text(40, "\n        ");
          i021.\u0275\u0275elementStart(41, "div", 12, 13);
          i021.\u0275\u0275listener("scroll", function IrisChatbotWidgetComponent_Template_div_scroll_41_listener() {
            return ctx.checkChatScroll();
          });
          i021.\u0275\u0275text(43, "\n            ");
          i021.\u0275\u0275repeaterCreate(44, IrisChatbotWidgetComponent_For_45_Template, 7, 1, null, null, i021.\u0275\u0275repeaterTrackByIdentity);
          i021.\u0275\u0275template(46, IrisChatbotWidgetComponent_Conditional_46_Template, 9, 1)(47, IrisChatbotWidgetComponent_Conditional_47_Template, 19, 9);
          i021.\u0275\u0275elementStart(48, "div", 14, 15);
          i021.\u0275\u0275listener("click", function IrisChatbotWidgetComponent_Template_div_click_48_listener() {
            return ctx.scrollToBottom("smooth");
          });
          i021.\u0275\u0275text(50, "\n                ");
          i021.\u0275\u0275element(51, "fa-icon", 10);
          i021.\u0275\u0275text(52, "\n            ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(53, "\n            ");
          i021.\u0275\u0275template(54, IrisChatbotWidgetComponent_Conditional_54_Template, 5, 4)(55, IrisChatbotWidgetComponent_Conditional_55_Template, 5, 4);
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(56, "\n        ");
          i021.\u0275\u0275text(57, "\n        ");
          i021.\u0275\u0275elementStart(58, "div", 16);
          i021.\u0275\u0275text(59, "\n            ");
          i021.\u0275\u0275elementStart(60, "textarea", 17, 18);
          i021.\u0275\u0275listener("ngModelChange", function IrisChatbotWidgetComponent_Template_textarea_ngModelChange_60_listener($event) {
            return ctx.newMessageTextContent = $event;
          })("ngModelChange", function IrisChatbotWidgetComponent_Template_textarea_ngModelChange_60_listener() {
            return ctx.onRowChange();
          })("input", function IrisChatbotWidgetComponent_Template_textarea_input_60_listener() {
            return ctx.onInput();
          })("paste", function IrisChatbotWidgetComponent_Template_textarea_paste_60_listener() {
            return ctx.onPaste();
          })("keydown", function IrisChatbotWidgetComponent_Template_textarea_keydown_60_listener($event) {
            return ctx.handleKey($event);
          });
          i021.\u0275\u0275pipe(62, "artemisTranslate");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(63, "\n            ");
          i021.\u0275\u0275elementStart(64, "jhi-button", 19);
          i021.\u0275\u0275listener("onClick", function IrisChatbotWidgetComponent_Template_jhi_button_onClick_64_listener() {
            return ctx.onSend();
          });
          i021.\u0275\u0275text(65, "\n            ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(66, "\n        ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(67, "\n    ");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(68, "\n");
          i021.\u0275\u0275elementEnd();
          i021.\u0275\u0275text(69, "\n");
        }
        if (rf & 2) {
          i021.\u0275\u0275advance(12);
          i021.\u0275\u0275property("size", ctx.IrisLogoSize.SMALL);
          i021.\u0275\u0275advance(2);
          i021.\u0275\u0275property("routerLink", "/about-iris");
          i021.\u0275\u0275advance(2);
          i021.\u0275\u0275property("icon", ctx.faCircleInfo);
          i021.\u0275\u0275advance(8);
          i021.\u0275\u0275conditional(24, ctx.rateLimit >= 0 ? 24 : -1);
          i021.\u0275\u0275advance(1);
          i021.\u0275\u0275conditional(25, ctx.isClearChatButtonEnabled() ? 25 : -1);
          i021.\u0275\u0275advance(1);
          i021.\u0275\u0275conditional(26, !ctx.fullSize ? 26 : -1);
          i021.\u0275\u0275advance(1);
          i021.\u0275\u0275conditional(27, ctx.fullSize ? 27 : -1);
          i021.\u0275\u0275advance(3);
          i021.\u0275\u0275property("icon", ctx.faXmark);
          i021.\u0275\u0275advance(14);
          i021.\u0275\u0275repeater(ctx.messages);
          i021.\u0275\u0275advance(2);
          i021.\u0275\u0275conditional(46, ctx.isLoading ? 46 : -1);
          i021.\u0275\u0275advance(1);
          i021.\u0275\u0275conditional(47, !ctx.userAccepted ? 47 : -1);
          i021.\u0275\u0275advance(1);
          i021.\u0275\u0275property("hidden", ctx.isScrolledToBottom);
          i021.\u0275\u0275advance(3);
          i021.\u0275\u0275property("icon", ctx.faArrowDown);
          i021.\u0275\u0275advance(3);
          i021.\u0275\u0275conditional(54, ctx.shouldShowEmptyMessageError && ctx.error && ctx.isEmptyMessageError() ? 54 : -1);
          i021.\u0275\u0275advance(1);
          i021.\u0275\u0275conditional(55, ctx.error && !ctx.isEmptyMessageError() ? 55 : -1);
          i021.\u0275\u0275advance(5);
          i021.\u0275\u0275propertyInterpolate("placeholder", i021.\u0275\u0275pipeBind1(62, 19, "artemisApp.exerciseChatbot.inputMessage"));
          i021.\u0275\u0275property("ngModel", ctx.newMessageTextContent);
          i021.\u0275\u0275advance(4);
          i021.\u0275\u0275property("btnType", ctx.ButtonType.SUCCESS)("icon", ctx.faPaperPlane)("disabled", ctx.deactivateSubmitButton());
        }
      }, dependencies: [i7.NgClass, i7.NgStyle, i8.DefaultValueAccessor, i8.NgControlStatus, i8.NgModel, i9.FaIconComponent, i5.NgbTooltip, ButtonComponent, i32.RouterLink, IrisLogoComponent, ArtemisTranslatePipe, HtmlForMarkdownPipe], styles: ["\n\n.container[_ngcontent-%COMP%] {\n  position: relative;\n}\n.header-start[_ngcontent-%COMP%] {\n  text-align: start;\n  padding-left: 5px;\n}\n.button-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  color: var(--secondary);\n  font-size: 16px;\n}\n.chat-widget[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 330px;\n  height: 430px;\n  background-color: var(--iris-chat-widget-background);\n  box-shadow: 0 0 50px rgba(0, 0, 0, 0.4);\n}\n.ng-draggable[_ngcontent-%COMP%] {\n  cursor: grab;\n}\n.ng-dragging[_ngcontent-%COMP%] {\n  cursor: grabbing;\n}\n.chat-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  height: 50px;\n  background-color: var(--artemis-dark);\n  color: white;\n  font-weight: bold;\n  padding: 10px;\n}\n.header-icon[_ngcontent-%COMP%] {\n  border: none;\n  background: transparent;\n  color: var(--secondary);\n  font-size: 16px;\n}\n.rate-limit[_ngcontent-%COMP%] {\n  padding-right: 6px;\n  margin-right: 3px;\n  border-right-color: var(--secondary);\n  border-right-style: solid;\n  border-right-width: 2px;\n}\n.info-button[_ngcontent-%COMP%] {\n  cursor: pointer;\n  vertical-align: middle;\n  padding-left: 3px;\n  font-size: 13px;\n  color: var(--blue);\n}\n.chat-body[_ngcontent-%COMP%] {\n  height: calc(100% - 100px);\n  overflow-y: scroll;\n  padding: 10px;\n  display: flex;\n  flex-direction: column;\n}\n.bubble-left[_ngcontent-%COMP%], .bubble-right[_ngcontent-%COMP%] {\n  --r: 13px;\n  --t: 10px;\n  max-width: 100%;\n  margin-bottom: 5px;\n  color: var(--bs-body-color);\n  padding: 10px;\n  -webkit-mask:\n    radial-gradient(var(--t) at var(--_d) 0, rgba(0, 0, 0, 0) 98%, #000 102%) var(--_d) 100%/calc(100% - var(--r)) var(--t) no-repeat,\n    conic-gradient(at var(--r) var(--r), #000 75%, rgba(0, 0, 0, 0) 0) calc(var(--r) / -2) calc(var(--r) / -2) padding-box,\n    radial-gradient(50% 50%, #000 98%, rgba(0, 0, 0, 0) 101%) 0 0/var(--r) var(--r) space padding-box;\n  overflow-wrap: break-word;\n  word-wrap: break-word;\n  word-break: break-word;\n}\n.bubble-left[_ngcontent-%COMP%]     p, .bubble-right[_ngcontent-%COMP%]     p {\n  margin-bottom: 0;\n}\n.bubble-left[_ngcontent-%COMP%] {\n  --_d: 0%;\n  border-left: var(--t) solid rgba(0, 0, 0, 0);\n  background-color: var(--iris-client-chat-background);\n  margin-right: var(--t);\n  place-self: start;\n}\n.bubble-right[_ngcontent-%COMP%] {\n  --_d: 100%;\n  border-right: var(--t) solid rgba(0, 0, 0, 0);\n  margin-left: var(--t);\n  place-self: end;\n  float: right;\n  background-color: var(--iris-my-chat-background);\n}\n.client-chat-error[_ngcontent-%COMP%] {\n  background-color: var(--artemis-alert-danger-background);\n  color: var(--bs-body-color);\n  padding: 10px;\n  border: 1px solid var(--artemis-alert-danger-border);\n  border-radius: 10px;\n  margin-top: 10px;\n}\npre[_ngcontent-%COMP%] {\n  background: transparent;\n  white-space: pre-wrap;\n  padding: 0;\n  margin: 0;\n  border: transparent;\n  font-family: inherit;\n  font-size: inherit;\n}\n.chat-input[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 7px;\n  background-color: var(--iris-client-chat-input);\n}\n.chat-input[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {\n  flex: 1;\n  padding: 5px 13px;\n  margin-right: 5px;\n  resize: none;\n}\n@keyframes _ngcontent-%COMP%_blink {\n  0% {\n    opacity: 1;\n  }\n  50% {\n    opacity: 0;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n.blinking-dots[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_blink 1s infinite;\n}\n.unread-message[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  color: var(--gray-600);\n  padding-top: 8px;\n  padding-bottom: 8px;\n}\n.p-chat[_ngcontent-%COMP%] {\n  background-color: var(--iris-client-chat-background);\n  color: var(--bs-body-color);\n  padding: 0;\n  border-radius: 10px;\n  margin-bottom: 10px;\n  display: flex;\n  flex-direction: column;\n  align-items: stretch;\n  border: 1.5px solid var(--iris-client-chat-background);\n}\n.message-text[_ngcontent-%COMP%] {\n  padding: 10px;\n  border-top-left-radius: 10px;\n  border-top-right-radius: 10px;\n  border-bottom: 1px solid var(--iris-client-chat-background);\n}\n.button[_ngcontent-%COMP%] {\n  flex: 1;\n  padding: 10px 0;\n  background-color: #fff;\n  border: none;\n  cursor: pointer;\n}\n.button[_ngcontent-%COMP%]:first-child {\n  border-right: 1px solid var(--iris-client-chat-background);\n}\n.button[_ngcontent-%COMP%]:hover {\n  background-color: #f5f5f5;\n}\n.scroll-to-bottom[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 60px;\n  right: 20px;\n  width: 30px;\n  height: 30px;\n  border-radius: 50%;\n  background-color: var(--secondary);\n  color: white;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  cursor: pointer;\n  box-shadow: 0 0 50px rgba(0, 0, 0, 0.4);\n}\n.rate-message-buttons[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n  display: flex;\n  justify-content: flex-end;\n}\n.thumbs-up-clicked[_ngcontent-%COMP%] {\n  color: var(--green);\n}\n.thumbs-down-clicked[_ngcontent-%COMP%] {\n  color: var(--red);\n}\n.rate-button-not-clicked[_ngcontent-%COMP%] {\n  color: var(--secondary);\n}\n.execute-button[_ngcontent-%COMP%] {\n  text-align: right;\n}\n@keyframes _ngcontent-%COMP%_shake {\n  0% {\n    transform: translateX(0);\n  }\n  10%, 30%, 50%, 70%, 90% {\n    transform: translateX(-10px);\n  }\n  20%, 40%, 60%, 80% {\n    transform: translateX(10px);\n  }\n  100% {\n    transform: translateX(0);\n  }\n}\n.shake-animation[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_shake 0.3s cubic-bezier(0.36, 0.07, 0.19, 0.97);\n}\n  ngb-modal-backdrop {\n  z-index: 9999 !important;\n}\n  ngb-modal-window {\n  z-index: 9999 !important;\n}\n.step-title[_ngcontent-%COMP%] {\n  margin: auto 0 auto 10px;\n}\n.step-component[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n}\n.step-status[_ngcontent-%COMP%] {\n  font-size: 0.6rem;\n}\n.detail-btn[_ngcontent-%COMP%] {\n  border: 1px solid;\n  color: var(--bs-body-color);\n  font-size: 0.7rem;\n  background-color: transparent;\n  white-space: nowrap;\n  padding: 5px;\n  border-radius: var(--bs-border-radius);\n  width: 80px;\n  min-width: 80px;\n}\n.show-details[_ngcontent-%COMP%] {\n  border: 1px solid transparent;\n  border-radius: 15px;\n  padding: 15px;\n  margin: 10px;\n}\n.hide-details[_ngcontent-%COMP%] {\n  border: 1px solid transparent;\n  border-top-left-radius: 15px;\n  border-top-right-radius: 15px;\n  padding: 15px;\n  margin: 0 10px;\n}\n.step-detail[_ngcontent-%COMP%] {\n  border: 1px solid var(--bs-body-color);\n  background-color: var(--iris-client-chat-background);\n  border-bottom-left-radius: 15px;\n  border-bottom-right-radius: 15px;\n  padding: 0 15px;\n  margin: 0 10px 10px;\n}\ncdk-global-scrollblock[_ngcontent-%COMP%] {\n  position: fixed;\n  width: 100%;\n  overflow-y: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL2V4ZXJjaXNlLWNoYXRib3Qvd2lkZ2V0L2NoYXRib3Qtd2lkZ2V0LmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuY29udGFpbmVyIHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi5oZWFkZXItc3RhcnQge1xuICAgIHRleHQtYWxpZ246IHN0YXJ0O1xuICAgIHBhZGRpbmctbGVmdDogNXB4O1xufVxuXG4uYnV0dG9uLWNvbnRhaW5lciB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGNvbG9yOiB2YXIoLS1zZWNvbmRhcnkpO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbn1cblxuLmNoYXQtd2lkZ2V0IHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgd2lkdGg6IDMzMHB4O1xuICAgIGhlaWdodDogNDMwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taXJpcy1jaGF0LXdpZGdldC1iYWNrZ3JvdW5kKTtcbiAgICBib3gtc2hhZG93OiAwIDAgNTBweCByZ2JhKDAsIDAsIDAsIDAuNCk7XG59XG5cbi5uZy1kcmFnZ2FibGUge1xuICAgIGN1cnNvcjogZ3JhYjtcbn1cblxuLm5nLWRyYWdnaW5nIHtcbiAgICBjdXJzb3I6IGdyYWJiaW5nO1xufVxuXG4uY2hhdC1oZWFkZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIGhlaWdodDogNTBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hcnRlbWlzLWRhcmspO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBwYWRkaW5nOiAxMHB4O1xufVxuXG4uaGVhZGVyLWljb24ge1xuICAgIGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICBjb2xvcjogdmFyKC0tc2Vjb25kYXJ5KTtcbiAgICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5yYXRlLWxpbWl0IHtcbiAgICBwYWRkaW5nLXJpZ2h0OiA2cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAzcHg7XG4gICAgYm9yZGVyLXJpZ2h0LWNvbG9yOiB2YXIoLS1zZWNvbmRhcnkpO1xuICAgIGJvcmRlci1yaWdodC1zdHlsZTogc29saWQ7XG4gICAgYm9yZGVyLXJpZ2h0LXdpZHRoOiAycHg7XG59XG5cbi5pbmZvLWJ1dHRvbiB7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgcGFkZGluZy1sZWZ0OiAzcHg7XG4gICAgZm9udC1zaXplOiAxM3B4O1xuICAgIGNvbG9yOiB2YXIoLS1ibHVlKTtcbn1cblxuLmNoYXQtYm9keSB7XG4gICAgaGVpZ2h0OiBjYWxjKDEwMCUgLSAxMDBweCk7XG4gICAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuXG4uYnViYmxlLWxlZnQsXG4uYnViYmxlLXJpZ2h0IHtcbiAgICAtLXI6IDEzcHg7IC8qIHRoZSByYWRpdXMgKi9cbiAgICAtLXQ6IDEwcHg7IC8qIHRoZSBzaXplIG9mIHRoZSB0YWlsICovXG5cbiAgICBtYXgtd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgIGNvbG9yOiB2YXIoLS1icy1ib2R5LWNvbG9yKTtcbiAgICBwYWRkaW5nOiAxMHB4O1xuICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgIC13ZWJraXQtbWFzazpcbiAgICAgICAgcmFkaWFsLWdyYWRpZW50KHZhcigtLXQpIGF0IHZhcigtLV9kKSAwLCAjMDAwMCA5OCUsICMwMDAgMTAyJSkgdmFyKC0tX2QpIDEwMCUgLyBjYWxjKDEwMCUgLSB2YXIoLS1yKSkgdmFyKC0tdCkgbm8tcmVwZWF0LFxuICAgICAgICBjb25pYy1ncmFkaWVudChhdCB2YXIoLS1yKSB2YXIoLS1yKSwgIzAwMCA3NSUsICMwMDAwIDApIGNhbGModmFyKC0tcikgLyAtMikgY2FsYyh2YXIoLS1yKSAvIC0yKSBwYWRkaW5nLWJveCxcbiAgICAgICAgcmFkaWFsLWdyYWRpZW50KDUwJSA1MCUsICMwMDAgOTglLCAjMDAwMCAxMDElKSAwIDAgLyB2YXIoLS1yKSB2YXIoLS1yKSBzcGFjZSBwYWRkaW5nLWJveDtcbiAgICBvdmVyZmxvdy13cmFwOiBicmVhay13b3JkO1xuICAgIHdvcmQtd3JhcDogYnJlYWstd29yZDtcbiAgICB3b3JkLWJyZWFrOiBicmVhay13b3JkO1xuICAgIDo6bmctZGVlcCBwIHtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcbiAgICB9XG59XG5cbi5idWJibGUtbGVmdCB7XG4gICAgLS1fZDogMCU7XG4gICAgYm9yZGVyLWxlZnQ6IHZhcigtLXQpIHNvbGlkICMwMDAwO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlyaXMtY2xpZW50LWNoYXQtYmFja2dyb3VuZCk7XG4gICAgbWFyZ2luLXJpZ2h0OiB2YXIoLS10KTtcbiAgICBwbGFjZS1zZWxmOiBzdGFydDtcbn1cblxuLmJ1YmJsZS1yaWdodCB7XG4gICAgLS1fZDogMTAwJTtcbiAgICBib3JkZXItcmlnaHQ6IHZhcigtLXQpIHNvbGlkICMwMDAwO1xuICAgIG1hcmdpbi1sZWZ0OiB2YXIoLS10KTtcbiAgICBwbGFjZS1zZWxmOiBlbmQ7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlyaXMtbXktY2hhdC1iYWNrZ3JvdW5kKTtcbn1cblxuLmNsaWVudC1jaGF0LWVycm9yIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hcnRlbWlzLWFsZXJ0LWRhbmdlci1iYWNrZ3JvdW5kKTtcbiAgICBjb2xvcjogdmFyKC0tYnMtYm9keS1jb2xvcik7XG4gICAgcGFkZGluZzogMTBweDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1hcnRlbWlzLWFsZXJ0LWRhbmdlci1ib3JkZXIpO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxucHJlIHtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICB3aGl0ZS1zcGFjZTogcHJlLXdyYXA7XG4gICAgcGFkZGluZzogMDtcbiAgICBtYXJnaW46IDA7XG4gICAgYm9yZGVyOiB0cmFuc3BhcmVudDtcbiAgICBmb250LWZhbWlseTogaW5oZXJpdDtcbiAgICBmb250LXNpemU6IGluaGVyaXQ7XG59XG5cbi5jaGF0LWlucHV0IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIHBhZGRpbmc6IDdweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pcmlzLWNsaWVudC1jaGF0LWlucHV0KTtcbn1cblxuLmNoYXQtaW5wdXQgdGV4dGFyZWEge1xuICAgIGZsZXg6IDE7XG4gICAgcGFkZGluZzogNXB4IDEzcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgcmVzaXplOiBub25lO1xufVxuXG5Aa2V5ZnJhbWVzIGJsaW5rIHtcbiAgICAwJSB7XG4gICAgICAgIG9wYWNpdHk6IDE7XG4gICAgfVxuXG4gICAgNTAlIHtcbiAgICAgICAgb3BhY2l0eTogMDtcbiAgICB9XG5cbiAgICAxMDAlIHtcbiAgICAgICAgb3BhY2l0eTogMTtcbiAgICB9XG59XG5cbi5ibGlua2luZy1kb3RzIHtcbiAgICBhbmltYXRpb246IGJsaW5rIDFzIGluZmluaXRlO1xufVxuXG4udW5yZWFkLW1lc3NhZ2Uge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgY29sb3I6IHZhcigtLWdyYXktNjAwKTtcbiAgICBwYWRkaW5nLXRvcDogOHB4O1xuICAgIHBhZGRpbmctYm90dG9tOiA4cHg7XG59XG5cbi5wLWNoYXQge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlyaXMtY2xpZW50LWNoYXQtYmFja2dyb3VuZCk7XG4gICAgY29sb3I6IHZhcigtLWJzLWJvZHktY29sb3IpO1xuICAgIHBhZGRpbmc6IDA7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBhbGlnbi1pdGVtczogc3RyZXRjaDtcbiAgICBib3JkZXI6IDEuNXB4IHNvbGlkIHZhcigtLWlyaXMtY2xpZW50LWNoYXQtYmFja2dyb3VuZCk7XG59XG5cbi5tZXNzYWdlLXRleHQge1xuICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMTBweDtcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMTBweDtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0taXJpcy1jbGllbnQtY2hhdC1iYWNrZ3JvdW5kKTtcbn1cblxuLmJ1dHRvbiB7XG4gICAgZmxleDogMTtcbiAgICBwYWRkaW5nOiAxMHB4IDA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4uYnV0dG9uOmZpcnN0LWNoaWxkIHtcbiAgICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCB2YXIoLS1pcmlzLWNsaWVudC1jaGF0LWJhY2tncm91bmQpO1xufVxuXG4uYnV0dG9uOmhvdmVyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNWY1O1xufVxuXG4uc2Nyb2xsLXRvLWJvdHRvbSB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJvdHRvbTogNjBweDtcbiAgICByaWdodDogMjBweDtcbiAgICB3aWR0aDogMzBweDtcbiAgICBoZWlnaHQ6IDMwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXNlY29uZGFyeSk7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgYm94LXNoYWRvdzogMCAwIDUwcHggcmdiYSgwLCAwLCAwLCAwLjQpO1xufVxuXG4ucmF0ZS1tZXNzYWdlLWJ1dHRvbnMge1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xufVxuXG4udGh1bWJzLXVwLWNsaWNrZWQge1xuICAgIGNvbG9yOiB2YXIoLS1ncmVlbik7XG59XG5cbi50aHVtYnMtZG93bi1jbGlja2VkIHtcbiAgICBjb2xvcjogdmFyKC0tcmVkKTtcbn1cblxuLnJhdGUtYnV0dG9uLW5vdC1jbGlja2VkIHtcbiAgICBjb2xvcjogdmFyKC0tc2Vjb25kYXJ5KTtcbn1cblxuLmV4ZWN1dGUtYnV0dG9uIHtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbn1cblxuQGtleWZyYW1lcyBzaGFrZSB7XG4gICAgMCUge1xuICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCk7XG4gICAgfVxuXG4gICAgMTAlLFxuICAgIDMwJSxcbiAgICA1MCUsXG4gICAgNzAlLFxuICAgIDkwJSB7XG4gICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtMTBweCk7XG4gICAgfVxuXG4gICAgMjAlLFxuICAgIDQwJSxcbiAgICA2MCUsXG4gICAgODAlIHtcbiAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDEwcHgpO1xuICAgIH1cblxuICAgIDEwMCUge1xuICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCk7XG4gICAgfVxufVxuXG4uc2hha2UtYW5pbWF0aW9uIHtcbiAgICBhbmltYXRpb246IHNoYWtlIDAuM3MgY3ViaWMtYmV6aWVyKDAuMzYsIDAuMDcsIDAuMTksIDAuOTcpO1xufVxuXG46Om5nLWRlZXAgbmdiLW1vZGFsLWJhY2tkcm9wIHtcbiAgICB6LWluZGV4OiA5OTk5ICFpbXBvcnRhbnQ7XG59XG5cbjo6bmctZGVlcCBuZ2ItbW9kYWwtd2luZG93IHtcbiAgICB6LWluZGV4OiA5OTk5ICFpbXBvcnRhbnQ7XG59XG5cbi5zdGVwLXRpdGxlIHtcbiAgICBtYXJnaW46IGF1dG8gMCBhdXRvIDEwcHg7XG59XG5cbi5zdGVwLWNvbXBvbmVudCB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG59XG5cbi5zdGVwLXN0YXR1cyB7XG4gICAgZm9udC1zaXplOiAwLjZyZW07XG59XG5cbi5kZXRhaWwtYnRuIHtcbiAgICBib3JkZXI6IDFweCBzb2xpZDtcbiAgICBjb2xvcjogdmFyKC0tYnMtYm9keS1jb2xvcik7XG4gICAgZm9udC1zaXplOiAwLjdyZW07XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICBwYWRkaW5nOiA1cHg7XG4gICAgYm9yZGVyLXJhZGl1czogdmFyKC0tYnMtYm9yZGVyLXJhZGl1cyk7XG4gICAgd2lkdGg6IDgwcHg7XG4gICAgbWluLXdpZHRoOiA4MHB4O1xufVxuXG4uc2hvdy1kZXRhaWxzIHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDtcbiAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xuICAgIHBhZGRpbmc6IDE1cHg7XG4gICAgbWFyZ2luOiAxMHB4O1xufVxuLmhpZGUtZGV0YWlscyB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgdHJhbnNwYXJlbnQ7XG4gICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMTVweDtcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMTVweDtcbiAgICBwYWRkaW5nOiAxNXB4O1xuICAgIG1hcmdpbjogMCAxMHB4O1xufVxuLnN0ZXAtZGV0YWlsIHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1icy1ib2R5LWNvbG9yKTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pcmlzLWNsaWVudC1jaGF0LWJhY2tncm91bmQpO1xuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDE1cHg7XG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDE1cHg7XG4gICAgcGFkZGluZzogMCAxNXB4O1xuICAgIG1hcmdpbjogMCAxMHB4IDEwcHg7XG59XG5jZGstZ2xvYmFsLXNjcm9sbGJsb2NrIHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgb3ZlcmZsb3cteTogYXV0bztcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksWUFBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQTtBQUNBLGdCQUFBOztBQUdKLENBQUE7QUFDSSxXQUFBO0FBQ0EsZUFBQTtBQUNBLFNBQUEsSUFBQTtBQUNBLGFBQUE7O0FBR0osQ0FBQTtBQUNJLFlBQUE7QUFDQSxPQUFBO0FBQ0EsUUFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBO0FBQ0Esb0JBQUEsSUFBQTtBQUNBLGNBQUEsRUFBQSxFQUFBLEtBQUEsS0FBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQTs7QUFHSixDQUFBO0FBQ0ksVUFBQTs7QUFHSixDQUFBO0FBQ0ksVUFBQTs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLG1CQUFBO0FBQ0EsVUFBQTtBQUNBLG9CQUFBLElBQUE7QUFDQSxTQUFBO0FBQ0EsZUFBQTtBQUNBLFdBQUE7O0FBR0osQ0FBQTtBQUNJLFVBQUE7QUFDQSxjQUFBO0FBQ0EsU0FBQSxJQUFBO0FBQ0EsYUFBQTs7QUFHSixDQUFBO0FBQ0ksaUJBQUE7QUFDQSxnQkFBQTtBQUNBLHNCQUFBLElBQUE7QUFDQSxzQkFBQTtBQUNBLHNCQUFBOztBQUdKLENBQUE7QUFDSSxVQUFBO0FBQ0Esa0JBQUE7QUFDQSxnQkFBQTtBQUNBLGFBQUE7QUFDQSxTQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLFVBQUEsS0FBQSxLQUFBLEVBQUE7QUFDQSxjQUFBO0FBQ0EsV0FBQTtBQUNBLFdBQUE7QUFDQSxrQkFBQTs7QUFHSixDQUFBO0FBQUEsQ0FBQTtBQUVJLE9BQUE7QUFDQSxPQUFBO0FBRUEsYUFBQTtBQUNBLGlCQUFBO0FBQ0EsU0FBQSxJQUFBO0FBQ0EsV0FBQTtBQUVBO0lBQ0ksZ0JBQUEsSUFBQSxLQUFBLEdBQUEsSUFBQSxNQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLEdBQUEsR0FBQSxFQUFBLEtBQUEsTUFBQSxJQUFBLE1BQUEsSUFBQSxDQUFBLEtBQUEsS0FBQSxFQUFBLElBQUEsTUFBQSxJQUFBLEtBQUEsU0FBQTtJQUFBLGVBQUEsR0FBQSxJQUFBLEtBQUEsSUFBQSxJQUFBLEVBQUEsS0FBQSxHQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxHQUFBLEdBQUEsS0FBQSxJQUFBLEtBQUEsRUFBQSxJQUFBLEtBQUEsSUFBQSxLQUFBLEVBQUEsSUFBQSxXQUFBO0lBQUEsZ0JBQUEsSUFBQSxHQUFBLEVBQUEsS0FBQSxHQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxHQUFBLE1BQUEsRUFBQSxDQUFBLENBQUEsSUFBQSxLQUFBLElBQUEsS0FBQSxNQUFBO0FBR0osaUJBQUE7QUFDQSxhQUFBO0FBQ0EsY0FBQTs7QUFDQSxDQWpCSixZQWlCSSxVQUFBO0FBQUEsQ0FqQkosYUFpQkksVUFBQTtBQUNJLGlCQUFBOztBQUlSLENBdEJBO0FBdUJJLFFBQUE7QUFDQSxlQUFBLElBQUEsS0FBQSxNQUFBLEtBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLEVBQUE7QUFDQSxvQkFBQSxJQUFBO0FBQ0EsZ0JBQUEsSUFBQTtBQUNBLGNBQUE7O0FBR0osQ0E5QkE7QUErQkksUUFBQTtBQUNBLGdCQUFBLElBQUEsS0FBQSxNQUFBLEtBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLEVBQUE7QUFDQSxlQUFBLElBQUE7QUFDQSxjQUFBO0FBQ0EsU0FBQTtBQUNBLG9CQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxTQUFBLElBQUE7QUFDQSxXQUFBO0FBQ0EsVUFBQSxJQUFBLE1BQUEsSUFBQTtBQUNBLGlCQUFBO0FBQ0EsY0FBQTs7QUFHSjtBQUNJLGNBQUE7QUFDQSxlQUFBO0FBQ0EsV0FBQTtBQUNBLFVBQUE7QUFDQSxVQUFBO0FBQ0EsZUFBQTtBQUNBLGFBQUE7O0FBR0osQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBO0FBQ0EsbUJBQUE7QUFDQSxXQUFBO0FBQ0Esb0JBQUEsSUFBQTs7QUFHSixDQVJBLFdBUUE7QUFDSSxRQUFBO0FBQ0EsV0FBQSxJQUFBO0FBQ0EsZ0JBQUE7QUFDQSxVQUFBOztBQUdKLFdBQUE7QUFDSTtBQUNJLGFBQUE7O0FBR0o7QUFDSSxhQUFBOztBQUdKO0FBQ0ksYUFBQTs7O0FBSVIsQ0FBQTtBQUNJLGFBQUEsTUFBQSxHQUFBOztBQUdKLENBQUE7QUFDSSxXQUFBO0FBQ0EsbUJBQUE7QUFDQSxTQUFBLElBQUE7QUFDQSxlQUFBO0FBQ0Esa0JBQUE7O0FBR0osQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxTQUFBLElBQUE7QUFDQSxXQUFBO0FBQ0EsaUJBQUE7QUFDQSxpQkFBQTtBQUNBLFdBQUE7QUFDQSxrQkFBQTtBQUNBLGVBQUE7QUFDQSxVQUFBLE1BQUEsTUFBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxXQUFBO0FBQ0EsMEJBQUE7QUFDQSwyQkFBQTtBQUNBLGlCQUFBLElBQUEsTUFBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxRQUFBO0FBQ0EsV0FBQSxLQUFBO0FBQ0Esb0JBQUE7QUFDQSxVQUFBO0FBQ0EsVUFBQTs7QUFHSixDQVJBLE1BUUE7QUFDSSxnQkFBQSxJQUFBLE1BQUEsSUFBQTs7QUFHSixDQVpBLE1BWUE7QUFDSSxvQkFBQTs7QUFHSixDQUFBO0FBQ0ksWUFBQTtBQUNBLFVBQUE7QUFDQSxTQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxpQkFBQTtBQUNBLG9CQUFBLElBQUE7QUFDQSxTQUFBO0FBQ0EsV0FBQTtBQUNBLG1CQUFBO0FBQ0EsZUFBQTtBQUNBLFVBQUE7QUFDQSxjQUFBLEVBQUEsRUFBQSxLQUFBLEtBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLEVBQUE7O0FBR0osQ0FBQTtBQUNJLGlCQUFBO0FBQ0EsV0FBQTtBQUNBLG1CQUFBOztBQUdKLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLFNBQUEsSUFBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBOztBQUdKLFdBQUE7QUFDSTtBQUNJLGVBQUEsV0FBQTs7QUFHSjtBQUtJLGVBQUEsV0FBQTs7QUFHSjtBQUlJLGVBQUEsV0FBQTs7QUFHSjtBQUNJLGVBQUEsV0FBQTs7O0FBSVIsQ0FBQTtBQUNJLGFBQUEsTUFBQSxLQUFBLGFBQUEsSUFBQSxFQUFBLElBQUEsRUFBQSxJQUFBLEVBQUE7O0FBR0osVUFBQTtBQUNJLFdBQUE7O0FBR0osVUFBQTtBQUNJLFdBQUE7O0FBR0osQ0FBQTtBQUNJLFVBQUEsS0FBQSxFQUFBLEtBQUE7O0FBR0osQ0FBQTtBQUNJLFdBQUE7QUFDQSxtQkFBQTs7QUFHSixDQUFBO0FBQ0ksYUFBQTs7QUFHSixDQUFBO0FBQ0ksVUFBQSxJQUFBO0FBQ0EsU0FBQSxJQUFBO0FBQ0EsYUFBQTtBQUNBLG9CQUFBO0FBQ0EsZUFBQTtBQUNBLFdBQUE7QUFDQSxpQkFBQSxJQUFBO0FBQ0EsU0FBQTtBQUNBLGFBQUE7O0FBR0osQ0FBQTtBQUNJLFVBQUEsSUFBQSxNQUFBO0FBQ0EsaUJBQUE7QUFDQSxXQUFBO0FBQ0EsVUFBQTs7QUFFSixDQUFBO0FBQ0ksVUFBQSxJQUFBLE1BQUE7QUFDQSwwQkFBQTtBQUNBLDJCQUFBO0FBQ0EsV0FBQTtBQUNBLFVBQUEsRUFBQTs7QUFFSixDQUFBO0FBQ0ksVUFBQSxJQUFBLE1BQUEsSUFBQTtBQUNBLG9CQUFBLElBQUE7QUFDQSw2QkFBQTtBQUNBLDhCQUFBO0FBQ0EsV0FBQSxFQUFBO0FBQ0EsVUFBQSxFQUFBLEtBQUE7O0FBRUo7QUFDSSxZQUFBO0FBQ0EsU0FBQTtBQUNBLGNBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"], data: { animation: [
        trigger("fadeAnimation", [
          state("start", style({
            opacity: 1
          })),
          state("end", style({
            opacity: 0
          })),
          transition("start => end", [animate("2s ease")])
        ])
      ] } });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i021.\u0275setClassDebugInfo(IrisChatbotWidgetComponent, { className: "IrisChatbotWidgetComponent" });
    })();
  }
});

// src/main/webapp/app/iris/exercise-chatbot/chatbot-button.component.ts
import { faChevronDown, faCircle as faCircle2, faCommentDots } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { Component as Component11 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { MatDialog as MatDialog3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_dialog.js?v=1d0d9ead";
import { Overlay } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_cdk_overlay.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i022 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i111 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_dialog.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_cdk_overlay.js?v=1d0d9ead";
import * as i52 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
var IrisChatbotButtonComponent;
var init_chatbot_button_component = __esm({
  "src/main/webapp/app/iris/exercise-chatbot/chatbot-button.component.ts"() {
    init_chatbot_widget_component();
    init_state_store_service();
    init_state_store_model();
    init_shared_service();
    init_session_service();
    init_session_service();
    init_state_store_service();
    init_shared_service();
    IrisChatbotButtonComponent = class _IrisChatbotButtonComponent {
      dialog;
      overlay;
      sessionService;
      stateStore;
      route;
      sharedService;
      dialogRef = null;
      chatOpen = false;
      hasNewMessages = false;
      courseId;
      exerciseId;
      stateSubscription;
      chatOpenSubscription;
      faCircle = faCircle2;
      faCommentDots = faCommentDots;
      faChevronDown = faChevronDown;
      constructor(dialog, overlay, sessionService, stateStore, route, sharedService) {
        this.dialog = dialog;
        this.overlay = overlay;
        this.sessionService = sessionService;
        this.stateStore = stateStore;
        this.route = route;
        this.sharedService = sharedService;
      }
      ngOnInit() {
        this.route.params.subscribe((params) => {
          this.courseId = parseInt(params["courseId"], 10);
          this.exerciseId = parseInt(params["exerciseId"], 10);
          if (this.exerciseId != null) {
            this.sessionService.getCurrentSessionOrCreate(this.exerciseId);
          }
        });
        this.stateSubscription = this.stateStore.getState().subscribe((state2) => {
          this.hasNewMessages = state2.numNewMessages > 0;
        });
        this.chatOpenSubscription = this.sharedService.chatOpen.subscribe((open) => this.chatOpen = open);
      }
      ngOnDestroy() {
        if (this.dialogRef) {
          this.dialogRef.close();
        }
        this.stateSubscription.unsubscribe();
        this.chatOpenSubscription.unsubscribe();
      }
      handleButtonClick() {
        if (this.chatOpen && this.dialogRef) {
          this.stateStore.dispatch(new NumNewMessagesResetAction());
          this.dialog.closeAll();
          this.chatOpen = false;
        } else {
          this.openChat();
          this.chatOpen = true;
        }
      }
      openChat() {
        this.chatOpen = true;
        this.dialogRef = this.dialog.open(IrisChatbotWidgetComponent, {
          hasBackdrop: false,
          scrollStrategy: this.overlay.scrollStrategies.noop(),
          position: { bottom: "0px", right: "0px" },
          disableClose: true,
          data: {
            stateStore: this.stateStore,
            courseId: this.courseId,
            exerciseId: this.exerciseId,
            sessionService: this.sessionService
          }
        });
      }
      static \u0275fac = function IrisChatbotButtonComponent_Factory(t) {
        return new (t || _IrisChatbotButtonComponent)(i022.\u0275\u0275directiveInject(i111.MatDialog), i022.\u0275\u0275directiveInject(i22.Overlay), i022.\u0275\u0275directiveInject(IrisSessionService), i022.\u0275\u0275directiveInject(IrisStateStore), i022.\u0275\u0275directiveInject(i52.ActivatedRoute), i022.\u0275\u0275directiveInject(SharedService));
      };
      static \u0275cmp = i022.\u0275\u0275defineComponent({ type: _IrisChatbotButtonComponent, selectors: [["ng-component"]], decls: 0, vars: 0, template: function IrisChatbotButtonComponent_Template(rf, ctx) {
      }, encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i022.\u0275setClassDebugInfo(IrisChatbotButtonComponent, { className: "IrisChatbotButtonComponent" });
    })();
  }
});

// src/main/webapp/app/iris/websocket.service.ts
import { Injectable as Injectable12 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i023 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisWebsocketService;
var init_websocket_service2 = __esm({
  "src/main/webapp/app/iris/websocket.service.ts"() {
    init_websocket_service();
    init_state_store_service();
    init_state_store_model();
    init_iris_message_model();
    init_iris_errors_model();
    IrisWebsocketService = class _IrisWebsocketService {
      jhiWebsocketService;
      stateStore;
      sessionType;
      subscriptionChannel;
      sessionIdChangedSub;
      constructor(jhiWebsocketService, stateStore, sessionType) {
        this.jhiWebsocketService = jhiWebsocketService;
        this.stateStore = stateStore;
        this.sessionType = sessionType;
        this.sessionIdChangedSub = this.stateStore.getActionObservable().subscribe((newAction) => {
          if (!isSessionReceivedAction(newAction))
            return;
          this.changeWebsocketSubscription(newAction.sessionId);
        });
      }
      ngOnDestroy() {
        if (this.subscriptionChannel) {
          this.jhiWebsocketService.unsubscribe(this.subscriptionChannel);
        }
        this.sessionIdChangedSub.unsubscribe();
      }
      changeWebsocketSubscription(sessionId) {
        const channel = "/user/topic/iris/" + this.sessionType + "/" + sessionId;
        if (sessionId != null && this.subscriptionChannel === channel) {
          return;
        }
        if (this.subscriptionChannel) {
          this.jhiWebsocketService.unsubscribe(this.subscriptionChannel);
        }
        if (sessionId == null)
          return;
        this.subscriptionChannel = channel;
        this.jhiWebsocketService.subscribe(this.subscriptionChannel);
        this.jhiWebsocketService.receive(this.subscriptionChannel).subscribe((response) => {
          this.handleWebsocketResponse(response);
        });
      }
      handleMessage(message) {
        if (!message)
          return;
        if (isStudentSentMessage(message)) {
          this.stateStore.dispatch(new StudentMessageSentAction(message, setTimeout(() => {
            this.stateStore.dispatch(new ConversationErrorOccurredAction(IrisErrorMessageKey.IRIS_SERVER_RESPONSE_TIMEOUT));
          }, 2e4)));
        } else if (isServerSentMessage(message)) {
          this.stateStore.dispatch(new ActiveConversationMessageLoadedAction(message));
        }
      }
      handleError(errorTranslationKey, translationParams) {
        if (!errorTranslationKey) {
          this.stateStore.dispatch(new ConversationErrorOccurredAction(IrisErrorMessageKey.TECHNICAL_ERROR_RESPONSE));
        } else {
          this.stateStore.dispatch(new ConversationErrorOccurredAction(errorTranslationKey, translationParams));
        }
      }
      handleRateLimitInfo(rateLimitInfo) {
        this.stateStore.dispatch(new RateLimitUpdatedAction(rateLimitInfo));
      }
      static \u0275fac = function IrisWebsocketService_Factory(t) {
        i023.\u0275\u0275invalidFactory();
      };
      static \u0275prov = i023.\u0275\u0275defineInjectable({ token: _IrisWebsocketService, factory: _IrisWebsocketService.\u0275fac });
    };
  }
});

// src/main/webapp/app/iris/code-editor-websocket.service.ts
import { Injectable as Injectable13 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject as Subject2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i024 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisCodeEditorWebsocketMessageType, IrisCodeEditorWebsocketService;
var init_code_editor_websocket_service = __esm({
  "src/main/webapp/app/iris/code-editor-websocket.service.ts"() {
    init_websocket_service();
    init_state_store_service();
    init_websocket_service2();
    init_websocket_service();
    init_state_store_service();
    (function(IrisCodeEditorWebsocketMessageType2) {
      IrisCodeEditorWebsocketMessageType2["MESSAGE"] = "MESSAGE";
      IrisCodeEditorWebsocketMessageType2["STEP_SUCCESS"] = "STEP_SUCCESS";
      IrisCodeEditorWebsocketMessageType2["STEP_EXCEPTION"] = "STEP_EXCEPTION";
      IrisCodeEditorWebsocketMessageType2["ERROR"] = "ERROR";
    })(IrisCodeEditorWebsocketMessageType || (IrisCodeEditorWebsocketMessageType = {}));
    IrisCodeEditorWebsocketService = class _IrisCodeEditorWebsocketService extends IrisWebsocketService {
      stepSuccess = new Subject2();
      stepException = new Subject2();
      constructor(jhiWebsocketService, stateStore) {
        super(jhiWebsocketService, stateStore, "code-editor-sessions");
      }
      handleWebsocketResponse(response) {
        if (response.rateLimitInfo) {
          super.handleRateLimitInfo(response.rateLimitInfo);
        }
        switch (response.type) {
          case IrisCodeEditorWebsocketMessageType.MESSAGE:
            super.handleMessage(response.message);
            break;
          case IrisCodeEditorWebsocketMessageType.STEP_SUCCESS:
            this.handleStepSuccess(response.stepExecutionSuccess);
            break;
          case IrisCodeEditorWebsocketMessageType.STEP_EXCEPTION:
            this.handleStepException(response.executionException);
            break;
          case IrisCodeEditorWebsocketMessageType.ERROR:
            super.handleError(response.errorTranslationKey, response.translationParams);
            break;
        }
      }
      handleStepSuccess(response) {
        this.stepSuccess.next(response);
      }
      handleStepException(response) {
        this.stepException.next(response);
      }
      onStepSuccess() {
        return this.stepSuccess.asObservable();
      }
      onStepException() {
        return this.stepException.asObservable();
      }
      static \u0275fac = function IrisCodeEditorWebsocketService_Factory(t) {
        return new (t || _IrisCodeEditorWebsocketService)(i024.\u0275\u0275inject(JhiWebsocketService), i024.\u0275\u0275inject(IrisStateStore));
      };
      static \u0275prov = i024.\u0275\u0275defineInjectable({ token: _IrisCodeEditorWebsocketService, factory: _IrisCodeEditorWebsocketService.\u0275fac });
    };
  }
});

// src/main/webapp/app/iris/exercise-chatbot/code-editor-chatbot-button.component.ts
import { Component as Component12 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { MatDialog as MatDialog5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_dialog.js?v=1d0d9ead";
import { Overlay as Overlay3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_cdk_overlay.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute7 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i025 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i112 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_dialog.js?v=1d0d9ead";
import * as i23 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_cdk_overlay.js?v=1d0d9ead";
import * as i62 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
var IrisCodeEditorChatbotButtonComponent;
var init_code_editor_chatbot_button_component = __esm({
  "src/main/webapp/app/iris/exercise-chatbot/code-editor-chatbot-button.component.ts"() {
    init_state_store_service();
    init_shared_service();
    init_chatbot_button_component();
    init_code_editor_session_service();
    init_code_editor_websocket_service();
    init_iris_logo_component();
    init_code_editor_session_service();
    init_state_store_service();
    init_code_editor_websocket_service();
    init_shared_service();
    init_iris_logo_component();
    init_artemis_translate_pipe();
    IrisCodeEditorChatbotButtonComponent = class _IrisCodeEditorChatbotButtonComponent extends IrisChatbotButtonComponent {
      IrisLogoSize = IrisLogoSize;
      constructor(dialog, overlay, codeEditorSessionService, stateStore, websocketService, route, sharedService) {
        super(dialog, overlay, codeEditorSessionService, stateStore, route, sharedService);
      }
      static \u0275fac = function IrisCodeEditorChatbotButtonComponent_Factory(t) {
        return new (t || _IrisCodeEditorChatbotButtonComponent)(i025.\u0275\u0275directiveInject(i112.MatDialog), i025.\u0275\u0275directiveInject(i23.Overlay), i025.\u0275\u0275directiveInject(IrisCodeEditorSessionService), i025.\u0275\u0275directiveInject(IrisStateStore), i025.\u0275\u0275directiveInject(IrisCodeEditorWebsocketService), i025.\u0275\u0275directiveInject(i62.ActivatedRoute), i025.\u0275\u0275directiveInject(SharedService));
      };
      static \u0275cmp = i025.\u0275\u0275defineComponent({ type: _IrisCodeEditorChatbotButtonComponent, selectors: [["jhi-code-editor-chatbot-button"]], features: [i025.\u0275\u0275ProvidersFeature([IrisCodeEditorSessionService]), i025.\u0275\u0275InheritDefinitionFeature], decls: 6, vars: 4, consts: [[1, "btn", 3, "size", "title", "click"]], template: function IrisCodeEditorChatbotButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          i025.\u0275\u0275elementStart(0, "div");
          i025.\u0275\u0275text(1, "\n    ");
          i025.\u0275\u0275elementStart(2, "jhi-iris-logo", 0);
          i025.\u0275\u0275listener("click", function IrisCodeEditorChatbotButtonComponent_Template_jhi_iris_logo_click_2_listener() {
            return ctx.handleButtonClick();
          });
          i025.\u0275\u0275pipe(3, "artemisTranslate");
          i025.\u0275\u0275elementEnd();
          i025.\u0275\u0275text(4, "\n");
          i025.\u0275\u0275elementEnd();
          i025.\u0275\u0275text(5, "\n");
        }
        if (rf & 2) {
          i025.\u0275\u0275advance(2);
          i025.\u0275\u0275propertyInterpolate("title", i025.\u0275\u0275pipeBind1(3, 2, "artemisApp.exerciseChatbot.buttonTooltip"));
          i025.\u0275\u0275property("size", ctx.IrisLogoSize.SMALL);
        }
      }, dependencies: [IrisLogoComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i025.\u0275setClassDebugInfo(IrisCodeEditorChatbotButtonComponent, { className: "IrisCodeEditorChatbotButtonComponent" });
    })();
  }
});

// src/main/webapp/app/iris/chat-websocket.service.ts
import { Injectable as Injectable14 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i026 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisChatWebsocketMessageType, IrisChatWebsocketService;
var init_chat_websocket_service = __esm({
  "src/main/webapp/app/iris/chat-websocket.service.ts"() {
    init_websocket_service();
    init_state_store_service();
    init_websocket_service2();
    init_websocket_service();
    init_state_store_service();
    (function(IrisChatWebsocketMessageType2) {
      IrisChatWebsocketMessageType2["MESSAGE"] = "MESSAGE";
      IrisChatWebsocketMessageType2["ERROR"] = "ERROR";
    })(IrisChatWebsocketMessageType || (IrisChatWebsocketMessageType = {}));
    IrisChatWebsocketService = class _IrisChatWebsocketService extends IrisWebsocketService {
      constructor(jhiWebsocketService, stateStore) {
        super(jhiWebsocketService, stateStore, "sessions");
      }
      handleWebsocketResponse(response) {
        if (response.rateLimitInfo) {
          super.handleRateLimitInfo(response.rateLimitInfo);
        }
        switch (response.type) {
          case IrisChatWebsocketMessageType.MESSAGE:
            super.handleMessage(response.message);
            break;
          case IrisChatWebsocketMessageType.ERROR:
            super.handleError(response.errorTranslationKey, response.translationParams);
            break;
        }
      }
      static \u0275fac = function IrisChatWebsocketService_Factory(t) {
        return new (t || _IrisChatWebsocketService)(i026.\u0275\u0275inject(JhiWebsocketService), i026.\u0275\u0275inject(IrisStateStore));
      };
      static \u0275prov = i026.\u0275\u0275defineInjectable({ token: _IrisChatWebsocketService, factory: _IrisChatWebsocketService.\u0275fac });
    };
  }
});

// src/main/webapp/app/iris/heartbeat.service.ts
import { Injectable as Injectable15 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { firstValueFrom as firstValueFrom3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i027 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisHeartbeatService;
var init_heartbeat_service = __esm({
  "src/main/webapp/app/iris/heartbeat.service.ts"() {
    init_state_store_service();
    init_http_chat_session_service();
    init_state_store_model();
    init_iris_errors_model();
    init_websocket_service();
    init_websocket_service();
    init_state_store_service();
    init_http_chat_session_service();
    IrisHeartbeatService = class _IrisHeartbeatService {
      websocketService;
      stateStore;
      httpSessionService;
      intervalId;
      sessionIdChangedSub;
      websocketStatusSubscription;
      disconnected = false;
      constructor(websocketService, stateStore, httpSessionService) {
        this.websocketService = websocketService;
        this.stateStore = stateStore;
        this.httpSessionService = httpSessionService;
        this.sessionIdChangedSub = this.stateStore.getActionObservable().subscribe((newAction) => {
          if (!isSessionReceivedAction(newAction))
            return;
          if (this.intervalId !== void 0)
            clearInterval(this.intervalId);
          this.checkHeartbeat(newAction.sessionId);
          this.intervalId = setInterval(() => {
            this.checkHeartbeat(newAction.sessionId);
          }, 1e4);
        });
        this.websocketStatusSubscription = this.websocketService.connectionState.subscribe((status) => {
          this.disconnected = !status.connected && !status.intendedDisconnect && status.wasEverConnectedBefore;
        });
      }
      checkHeartbeat(sessionId) {
        if (this.disconnected)
          return;
        firstValueFrom3(this.httpSessionService.getHeartbeat(sessionId)).then((response) => {
          if (response.body) {
            if (!response.body.active) {
              this.stateStore.dispatch(new ConversationErrorOccurredAction(IrisErrorMessageKey.IRIS_NOT_AVAILABLE));
            }
            this.stateStore.dispatch(new RateLimitUpdatedAction(response.body.rateLimitInfo));
          } else {
            this.stateStore.dispatch(new ConversationErrorOccurredAction(IrisErrorMessageKey.IRIS_NOT_AVAILABLE));
          }
        });
      }
      ngOnDestroy() {
        if (this.intervalId !== void 0)
          clearInterval(this.intervalId);
        this.sessionIdChangedSub.unsubscribe();
        this.websocketStatusSubscription.unsubscribe();
      }
      static \u0275fac = function IrisHeartbeatService_Factory(t) {
        return new (t || _IrisHeartbeatService)(i027.\u0275\u0275inject(JhiWebsocketService), i027.\u0275\u0275inject(IrisStateStore), i027.\u0275\u0275inject(IrisHttpChatSessionService));
      };
      static \u0275prov = i027.\u0275\u0275defineInjectable({ token: _IrisHeartbeatService, factory: _IrisHeartbeatService.\u0275fac });
    };
  }
});

// src/main/webapp/app/iris/exercise-chatbot/tutor-chatbot-button.component.ts
import { Component as Component13 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { MatDialog as MatDialog7 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_dialog.js?v=1d0d9ead";
import { Overlay as Overlay5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_cdk_overlay.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute9 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i028 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i113 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_dialog.js?v=1d0d9ead";
import * as i24 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_cdk_overlay.js?v=1d0d9ead";
import * as i72 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i92 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function IrisTutorChatbotButtonComponent_Conditional_0_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i028.\u0275\u0275text(0, "\n            ");
    i028.\u0275\u0275element(1, "fa-icon", 2);
    i028.\u0275\u0275text(2, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = i028.\u0275\u0275nextContext(2);
    i028.\u0275\u0275advance(1);
    i028.\u0275\u0275property("icon", ctx_r1.faCircle);
  }
}
function IrisTutorChatbotButtonComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i028.\u0275\u0275getCurrentView();
    i028.\u0275\u0275text(0, "\n    ");
    i028.\u0275\u0275elementStart(1, "div", 0);
    i028.\u0275\u0275text(2, "\n        ");
    i028.\u0275\u0275elementStart(3, "jhi-iris-logo", 1);
    i028.\u0275\u0275listener("click", function IrisTutorChatbotButtonComponent_Conditional_0_Template_jhi_iris_logo_click_3_listener() {
      i028.\u0275\u0275restoreView(_r3);
      const ctx_r2 = i028.\u0275\u0275nextContext();
      return i028.\u0275\u0275resetView(ctx_r2.handleButtonClick());
    });
    i028.\u0275\u0275elementEnd();
    i028.\u0275\u0275text(4, "\n        ");
    i028.\u0275\u0275template(5, IrisTutorChatbotButtonComponent_Conditional_0_Conditional_5_Template, 3, 1);
    i028.\u0275\u0275elementEnd();
    i028.\u0275\u0275text(6, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i028.\u0275\u0275nextContext();
    i028.\u0275\u0275advance(3);
    i028.\u0275\u0275property("size", ctx_r0.IrisLogoSize.MEDIUM)("look", ctx_r0.IrisLogoLookDirection.LEFT);
    i028.\u0275\u0275advance(2);
    i028.\u0275\u0275conditional(5, ctx_r0.hasNewMessages ? 5 : -1);
  }
}
var IrisTutorChatbotButtonComponent;
var init_tutor_chatbot_button_component = __esm({
  "src/main/webapp/app/iris/exercise-chatbot/tutor-chatbot-button.component.ts"() {
    init_chat_websocket_service();
    init_state_store_service();
    init_shared_service();
    init_heartbeat_service();
    init_chat_session_service();
    init_chatbot_button_component();
    init_iris_logo_component();
    init_chat_session_service();
    init_state_store_service();
    init_chat_websocket_service();
    init_heartbeat_service();
    init_shared_service();
    init_iris_logo_component();
    IrisTutorChatbotButtonComponent = class _IrisTutorChatbotButtonComponent extends IrisChatbotButtonComponent {
      IrisLogoSize = IrisLogoSize;
      IrisLogoLookDirection = IrisLogoLookDirection;
      constructor(dialog, overlay, sessionService, stateStore, websocketService, heartbeatService, route, sharedService) {
        super(dialog, overlay, sessionService, stateStore, route, sharedService);
      }
      static \u0275fac = function IrisTutorChatbotButtonComponent_Factory(t) {
        return new (t || _IrisTutorChatbotButtonComponent)(i028.\u0275\u0275directiveInject(i113.MatDialog), i028.\u0275\u0275directiveInject(i24.Overlay), i028.\u0275\u0275directiveInject(IrisChatSessionService), i028.\u0275\u0275directiveInject(IrisStateStore), i028.\u0275\u0275directiveInject(IrisChatWebsocketService), i028.\u0275\u0275directiveInject(IrisHeartbeatService), i028.\u0275\u0275directiveInject(i72.ActivatedRoute), i028.\u0275\u0275directiveInject(SharedService));
      };
      static \u0275cmp = i028.\u0275\u0275defineComponent({ type: _IrisTutorChatbotButtonComponent, selectors: [["jhi-tutor-chatbot-button"]], features: [i028.\u0275\u0275ProvidersFeature([IrisChatWebsocketService, IrisChatSessionService, IrisHeartbeatService]), i028.\u0275\u0275InheritDefinitionFeature], decls: 1, vars: 1, consts: [[1, "chatbot-button"], [3, "size", "look", "click"], ["size", "xl", 1, "unread-indicator", 3, "icon"]], template: function IrisTutorChatbotButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          i028.\u0275\u0275template(0, IrisTutorChatbotButtonComponent_Conditional_0_Template, 7, 3);
        }
        if (rf & 2) {
          i028.\u0275\u0275conditional(0, !ctx.chatOpen ? 0 : -1);
        }
      }, dependencies: [i92.FaIconComponent, IrisLogoComponent], styles: ["\n\n.chatbot-button[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 20px;\n  right: 30px;\n  z-index: 9999;\n  cursor: pointer;\n  transition: all 0.1s ease-in-out;\n}\n.chatbot-button[_ngcontent-%COMP%]:hover {\n  transform: scale(1.1);\n}\n.btn-circle[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  padding: 0;\n  border-radius: 50%;\n}\n.unread-indicator[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -10px;\n  right: 10px;\n  width: 10px;\n  height: 10px;\n  color: var(--red);\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL2V4ZXJjaXNlLWNoYXRib3QvdHV0b3ItY2hhdGJvdC1idXR0b24uY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5jaGF0Ym90LWJ1dHRvbiB7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIGJvdHRvbTogMjBweDtcbiAgICByaWdodDogMzBweDtcbiAgICB6LWluZGV4OiA5OTk5O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4xcyBlYXNlLWluLW91dDtcblxuICAgICY6aG92ZXIge1xuICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEuMSk7XG4gICAgfVxufVxuXG4uYnRuLWNpcmNsZSB7XG4gICAgd2lkdGg6IDQwcHg7XG4gICAgaGVpZ2h0OiA0MHB4O1xuICAgIHBhZGRpbmc6IDA7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuXG4udW5yZWFkLWluZGljYXRvciB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogLTEwcHg7XG4gICAgcmlnaHQ6IDEwcHg7XG4gICAgd2lkdGg6IDEwcHg7XG4gICAgaGVpZ2h0OiAxMHB4O1xuICAgIGNvbG9yOiB2YXIoLS1yZWQpO1xufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLENBQUE7QUFDSSxZQUFBO0FBQ0EsVUFBQTtBQUNBLFNBQUE7QUFDQSxXQUFBO0FBQ0EsVUFBQTtBQUNBLGNBQUEsSUFBQSxLQUFBOztBQUVBLENBUkosY0FRSTtBQUNJLGFBQUEsTUFBQTs7QUFJUixDQUFBO0FBQ0ksU0FBQTtBQUNBLFVBQUE7QUFDQSxXQUFBO0FBQ0EsaUJBQUE7O0FBR0osQ0FBQTtBQUNJLFlBQUE7QUFDQSxPQUFBO0FBQ0EsU0FBQTtBQUNBLFNBQUE7QUFDQSxVQUFBO0FBQ0EsU0FBQSxJQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i028.\u0275setClassDebugInfo(IrisTutorChatbotButtonComponent, { className: "IrisTutorChatbotButtonComponent" });
    })();
  }
});

// src/main/webapp/app/iris/iris.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { MatDialogModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_dialog.js?v=1d0d9ead";
import { CommonModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import { FormsModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import { FontAwesomeModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import { RouterModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i029 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisModule;
var init_iris_module = __esm({
  "src/main/webapp/app/iris/iris.module.ts"() {
    init_shared_module();
    init_markdown_module();
    init_about_iris_component();
    init_shared_component_module();
    init_iris_settings_update_component();
    init_iris_global_settings_update_component();
    init_iris_common_sub_settings_update_component();
    init_iris_course_settings_update_component();
    init_iris_exercise_settings_update_component();
    init_iris_logo_component();
    init_iris_chat_sub_settings_update_component();
    init_iris_hestia_sub_settings_update_component();
    init_iris_global_autoupdate_settings_update_component();
    init_iris_code_editor_sub_settings_update_component();
    init_code_editor_chatbot_button_component();
    init_tutor_chatbot_button_component();
    init_code_editor_websocket_service();
    init_state_store_service();
    init_chatbot_widget_component();
    init_iris_enabled_component();
    IrisModule = class _IrisModule {
      static \u0275fac = function IrisModule_Factory(t) {
        return new (t || _IrisModule)();
      };
      static \u0275mod = i029.\u0275\u0275defineNgModule({ type: _IrisModule });
      static \u0275inj = i029.\u0275\u0275defineInjector({ providers: [IrisCodeEditorWebsocketService, IrisStateStore], imports: [CommonModule, MatDialogModule, FormsModule, FontAwesomeModule, ArtemisSharedModule, ArtemisMarkdownModule, ArtemisSharedComponentModule, RouterModule] });
    };
  }
});

export {
  ExerciseComponent,
  init_iris_content_type_model,
  IrisTutorChatbotButtonComponent,
  init_tutor_chatbot_button_component,
  IrisGlobalSettingsUpdateComponent,
  init_iris_global_settings_update_component,
  IrisCourseSettingsUpdateComponent,
  init_iris_course_settings_update_component,
  IrisExerciseSettingsUpdateComponent,
  init_iris_exercise_settings_update_component,
  IrisCodeEditorWebsocketService,
  init_code_editor_websocket_service,
  IrisCodeEditorChatbotButtonComponent,
  init_code_editor_chatbot_button_component,
  IrisModule,
  init_iris_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvaXJpcy9zZXR0aW5ncy9pcmlzLXNldHRpbmdzLm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL3NldHRpbmdzL2lyaXMtc2V0dGluZ3MtdXBkYXRlL2lyaXMtY29tbW9uLXN1Yi1zZXR0aW5ncy11cGRhdGUvaXJpcy1jb21tb24tc3ViLXNldHRpbmdzLXVwZGF0ZS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2lyaXMvc2V0dGluZ3MvaXJpcy1zZXR0aW5ncy11cGRhdGUvaXJpcy1jb21tb24tc3ViLXNldHRpbmdzLXVwZGF0ZS9pcmlzLWNvbW1vbi1zdWItc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9pcmlzL3NldHRpbmdzL2lyaXMtdGVtcGxhdGUudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2lyaXMvc2V0dGluZ3MvaXJpcy1zZXR0aW5ncy11cGRhdGUvaXJpcy1jaGF0LXN1Yi1zZXR0aW5ncy11cGRhdGUvaXJpcy1jaGF0LXN1Yi1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL3NldHRpbmdzL2lyaXMtc2V0dGluZ3MtdXBkYXRlL2lyaXMtY2hhdC1zdWItc2V0dGluZ3MtdXBkYXRlL2lyaXMtY2hhdC1zdWItc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL3NldHRpbmdzL2lyaXMtc2V0dGluZ3MtdXBkYXRlL2lyaXMtaGVzdGlhLXN1Yi1zZXR0aW5ncy11cGRhdGUvaXJpcy1oZXN0aWEtc3ViLXNldHRpbmdzLXVwZGF0ZS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2lyaXMvc2V0dGluZ3MvaXJpcy1zZXR0aW5ncy11cGRhdGUvaXJpcy1oZXN0aWEtc3ViLXNldHRpbmdzLXVwZGF0ZS9pcmlzLWhlc3RpYS1zdWItc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL3NldHRpbmdzL2lyaXMtc2V0dGluZ3MtdXBkYXRlL2lyaXMtZ2xvYmFsLWF1dG91cGRhdGUtc2V0dGluZ3MtdXBkYXRlL2lyaXMtZ2xvYmFsLWF1dG91cGRhdGUtc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9zZXR0aW5ncy9pcmlzLXNldHRpbmdzLXVwZGF0ZS9pcmlzLWdsb2JhbC1hdXRvdXBkYXRlLXNldHRpbmdzLXVwZGF0ZS9pcmlzLWdsb2JhbC1hdXRvdXBkYXRlLXNldHRpbmdzLXVwZGF0ZS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9zZXR0aW5ncy9pcmlzLXNldHRpbmdzLXVwZGF0ZS9pcmlzLWNvZGUtZWRpdG9yLXN1Yi1zZXR0aW5ncy11cGRhdGUvaXJpcy1jb2RlLWVkaXRvci1zdWItc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9zZXR0aW5ncy9pcmlzLXNldHRpbmdzLXVwZGF0ZS9pcmlzLWNvZGUtZWRpdG9yLXN1Yi1zZXR0aW5ncy11cGRhdGUvaXJpcy1jb2RlLWVkaXRvci1zdWItc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL3NldHRpbmdzL2lyaXMtc2V0dGluZ3MtdXBkYXRlL2lyaXMtc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9zZXR0aW5ncy9pcmlzLXNldHRpbmdzLXVwZGF0ZS9pcmlzLXNldHRpbmdzLXVwZGF0ZS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9zZXR0aW5ncy9pcmlzLWdsb2JhbC1zZXR0aW5ncy11cGRhdGUvaXJpcy1nbG9iYWwtc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9zZXR0aW5ncy9pcmlzLWdsb2JhbC1zZXR0aW5ncy11cGRhdGUvaXJpcy1nbG9iYWwtc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL3NldHRpbmdzL2lyaXMtY291cnNlLXNldHRpbmdzLXVwZGF0ZS9pcmlzLWNvdXJzZS1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL3NldHRpbmdzL2lyaXMtY291cnNlLXNldHRpbmdzLXVwZGF0ZS9pcmlzLWNvdXJzZS1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2lyaXMvc2V0dGluZ3MvaXJpcy1leGVyY2lzZS1zZXR0aW5ncy11cGRhdGUvaXJpcy1leGVyY2lzZS1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL3NldHRpbmdzL2lyaXMtZXhlcmNpc2Utc2V0dGluZ3MtdXBkYXRlL2lyaXMtZXhlcmNpc2Utc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9pcmlzL2lyaXMtZXJyb3JzLm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL3N0YXRlLXN0b3JlLm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9pcmlzL2lyaXMtbWVzc2FnZS5tb2RlbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9zdGF0ZS1zdG9yZS5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL3NoYXJlZC5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9pcmlzL2lyaXMtY29udGVudC10eXBlLm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL2h0dHAtc2Vzc2lvbi5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL2h0dHAtbWVzc2FnZS5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL3Nlc3Npb24uc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9odHRwLWNoYXQtbWVzc2FnZS5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL2h0dHAtY2hhdC1zZXNzaW9uLnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2lyaXMvY2hhdC1zZXNzaW9uLnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2lyaXMvaHR0cC1jb2RlLWVkaXRvci1zZXNzaW9uLnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2lyaXMvaHR0cC1jb2RlLWVkaXRvci1tZXNzYWdlLnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2lyaXMvY29kZS1lZGl0b3Itc2Vzc2lvbi5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL2V4ZXJjaXNlLWNoYXRib3Qvd2lkZ2V0L2NoYXRib3Qtd2lkZ2V0LmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9leGVyY2lzZS1jaGF0Ym90L3dpZGdldC9jaGF0Ym90LXdpZGdldC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9leGVyY2lzZS1jaGF0Ym90L2NoYXRib3QtYnV0dG9uLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy93ZWJzb2NrZXQuc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9jb2RlLWVkaXRvci13ZWJzb2NrZXQuc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9leGVyY2lzZS1jaGF0Ym90L2NvZGUtZWRpdG9yLWNoYXRib3QtYnV0dG9uLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9leGVyY2lzZS1jaGF0Ym90L2NvZGUtZWRpdG9yLWNoYXRib3QtYnV0dG9uLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL2NoYXQtd2Vic29ja2V0LnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2lyaXMvaGVhcnRiZWF0LnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2lyaXMvZXhlcmNpc2UtY2hhdGJvdC90dXRvci1jaGF0Ym90LWJ1dHRvbi5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2lyaXMvZXhlcmNpc2UtY2hhdGJvdC90dXRvci1jaGF0Ym90LWJ1dHRvbi5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9pcmlzLm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCYXNlRW50aXR5IH0gZnJvbSAnYXBwL3NoYXJlZC9tb2RlbC9iYXNlLWVudGl0eSc7XG5pbXBvcnQgeyBJcmlzQ2hhdFN1YlNldHRpbmdzLCBJcmlzQ29kZUVkaXRvclN1YlNldHRpbmdzLCBJcmlzSGVzdGlhU3ViU2V0dGluZ3MgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9zZXR0aW5ncy9pcmlzLXN1Yi1zZXR0aW5ncy5tb2RlbCc7XG5cbmV4cG9ydCBlbnVtIElyaXNTZXR0aW5nc1R5cGUge1xuICAgIEdMT0JBTCA9ICdnbG9iYWwnLFxuICAgIENPVVJTRSA9ICdjb3Vyc2UnLFxuICAgIEVYRVJDSVNFID0gJ2V4ZXJjaXNlJyxcbn1cblxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIElyaXNTZXR0aW5ncyBpbXBsZW1lbnRzIEJhc2VFbnRpdHkge1xuICAgIGlkPzogbnVtYmVyO1xuICAgIHR5cGU6IElyaXNTZXR0aW5nc1R5cGU7XG4gICAgaXJpc0NoYXRTZXR0aW5ncz86IElyaXNDaGF0U3ViU2V0dGluZ3M7XG4gICAgaXJpc0hlc3RpYVNldHRpbmdzPzogSXJpc0hlc3RpYVN1YlNldHRpbmdzO1xuICAgIGlyaXNDb2RlRWRpdG9yU2V0dGluZ3M/OiBJcmlzQ29kZUVkaXRvclN1YlNldHRpbmdzO1xufVxuXG5leHBvcnQgY2xhc3MgSXJpc0dsb2JhbFNldHRpbmdzIGltcGxlbWVudHMgSXJpc1NldHRpbmdzIHtcbiAgICBpZD86IG51bWJlcjtcbiAgICB0eXBlID0gSXJpc1NldHRpbmdzVHlwZS5HTE9CQUw7XG4gICAgY3VycmVudFZlcnNpb24/OiBudW1iZXI7XG4gICAgZW5hYmxlQXV0b1VwZGF0ZUNoYXQ/OiBib29sZWFuO1xuICAgIGVuYWJsZUF1dG9VcGRhdGVIZXN0aWE/OiBib29sZWFuO1xuICAgIGVuYWJsZUF1dG9VcGRhdGVDb2RlRWRpdG9yPzogYm9vbGVhbjtcbiAgICBpcmlzQ2hhdFNldHRpbmdzPzogSXJpc0NoYXRTdWJTZXR0aW5ncztcbiAgICBpcmlzSGVzdGlhU2V0dGluZ3M/OiBJcmlzSGVzdGlhU3ViU2V0dGluZ3M7XG4gICAgaXJpc0NvZGVFZGl0b3JTZXR0aW5ncz86IElyaXNDb2RlRWRpdG9yU3ViU2V0dGluZ3M7XG59XG5cbmV4cG9ydCBjbGFzcyBJcmlzQ291cnNlU2V0dGluZ3MgaW1wbGVtZW50cyBJcmlzU2V0dGluZ3Mge1xuICAgIGlkPzogbnVtYmVyO1xuICAgIHR5cGUgPSBJcmlzU2V0dGluZ3NUeXBlLkNPVVJTRTtcbiAgICBjb3Vyc2VJZD86IG51bWJlcjtcbiAgICBpcmlzQ2hhdFNldHRpbmdzPzogSXJpc0NoYXRTdWJTZXR0aW5ncztcbiAgICBpcmlzSGVzdGlhU2V0dGluZ3M/OiBJcmlzSGVzdGlhU3ViU2V0dGluZ3M7XG4gICAgaXJpc0NvZGVFZGl0b3JTZXR0aW5ncz86IElyaXNDb2RlRWRpdG9yU3ViU2V0dGluZ3M7XG59XG5cbmV4cG9ydCBjbGFzcyBJcmlzRXhlcmNpc2VTZXR0aW5ncyBpbXBsZW1lbnRzIElyaXNTZXR0aW5ncyB7XG4gICAgaWQ/OiBudW1iZXI7XG4gICAgdHlwZSA9IElyaXNTZXR0aW5nc1R5cGUuRVhFUkNJU0U7XG4gICAgZXhlcmNpc2VJZD86IG51bWJlcjtcbiAgICBpcmlzQ2hhdFNldHRpbmdzPzogSXJpc0NoYXRTdWJTZXR0aW5ncztcbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT25DaGFuZ2VzLCBPbkluaXQsIE91dHB1dCwgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSXJpc1N1YlNldHRpbmdzIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvc2V0dGluZ3MvaXJpcy1zdWItc2V0dGluZ3MubW9kZWwnO1xuaW1wb3J0IHsgSXJpc01vZGVsIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvc2V0dGluZ3MvaXJpcy1tb2RlbCc7XG5pbXBvcnQgeyBBY2NvdW50U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL2F1dGgvYWNjb3VudC5zZXJ2aWNlJztcbmltcG9ydCB7IEJ1dHRvblR5cGUgfSBmcm9tICdhcHAvc2hhcmVkL2NvbXBvbmVudHMvYnV0dG9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBmYVRyYXNoIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IElyaXNTZXR0aW5nc1R5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9zZXR0aW5ncy9pcmlzLXNldHRpbmdzLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktaXJpcy1jb21tb24tc3ViLXNldHRpbmdzLXVwZGF0ZScsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2lyaXMtY29tbW9uLXN1Yi1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBJcmlzQ29tbW9uU3ViU2V0dGluZ3NVcGRhdGVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcyB7XG4gICAgQElucHV0KClcbiAgICBzdWJTZXR0aW5ncz86IElyaXNTdWJTZXR0aW5ncztcblxuICAgIEBJbnB1dCgpXG4gICAgcGFyZW50U3ViU2V0dGluZ3M/OiBJcmlzU3ViU2V0dGluZ3M7XG5cbiAgICBASW5wdXQoKVxuICAgIGFsbElyaXNNb2RlbHM6IElyaXNNb2RlbFtdO1xuXG4gICAgQElucHV0KClcbiAgICBzZXR0aW5nc1R5cGU6IElyaXNTZXR0aW5nc1R5cGU7XG5cbiAgICBAT3V0cHV0KClcbiAgICBvbkNoYW5nZXMgPSBuZXcgRXZlbnRFbWl0dGVyPElyaXNTdWJTZXR0aW5ncz4oKTtcblxuICAgIGlzQWRtaW46IGJvb2xlYW47XG5cbiAgICBpbmhlcml0QWxsb3dlZE1vZGVsczogYm9vbGVhbjtcblxuICAgIGFsbG93ZWRJcmlzTW9kZWxzOiBJcmlzTW9kZWxbXTtcblxuICAgIGVuYWJsZWQ6IGJvb2xlYW47XG5cbiAgICAvLyBTZXR0aW5ncyB0eXBlc1xuICAgIEVYRVJDSVNFID0gSXJpc1NldHRpbmdzVHlwZS5FWEVSQ0lTRTtcbiAgICAvLyBCdXR0b24gdHlwZXNcbiAgICBXQVJOSU5HID0gQnV0dG9uVHlwZS5XQVJOSU5HO1xuICAgIC8vIEljb25zXG4gICAgZmFUcmFzaCA9IGZhVHJhc2g7XG5cbiAgICBjb25zdHJ1Y3RvcihhY2NvdW50U2VydmljZTogQWNjb3VudFNlcnZpY2UpIHtcbiAgICAgICAgdGhpcy5pc0FkbWluID0gYWNjb3VudFNlcnZpY2UuaXNBZG1pbigpO1xuICAgIH1cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICB0aGlzLmVuYWJsZWQgPSB0aGlzLnN1YlNldHRpbmdzPy5lbmFibGVkID8/IGZhbHNlO1xuICAgICAgICB0aGlzLmFsbG93ZWRJcmlzTW9kZWxzID0gdGhpcy5nZXRBdmFpbGFibGVNb2RlbHMoKTtcbiAgICAgICAgdGhpcy5pbmhlcml0QWxsb3dlZE1vZGVscyA9ICEhKCF0aGlzLnN1YlNldHRpbmdzPy5hbGxvd2VkTW9kZWxzICYmIHRoaXMucGFyZW50U3ViU2V0dGluZ3MpO1xuICAgIH1cblxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcbiAgICAgICAgaWYgKGNoYW5nZXMuYWxsSXJpc01vZGVscykge1xuICAgICAgICAgICAgdGhpcy5hbGxvd2VkSXJpc01vZGVscyA9IHRoaXMuZ2V0QXZhaWxhYmxlTW9kZWxzKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNoYW5nZXMuc3ViU2V0dGluZ3MpIHtcbiAgICAgICAgICAgIHRoaXMuZW5hYmxlZCA9IHRoaXMuc3ViU2V0dGluZ3M/LmVuYWJsZWQgPz8gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBnZXRBdmFpbGFibGVNb2RlbHMoKTogSXJpc01vZGVsW10ge1xuICAgICAgICByZXR1cm4gdGhpcy5hbGxJcmlzTW9kZWxzLmZpbHRlcigobW9kZWwpID0+ICh0aGlzLnN1YlNldHRpbmdzPy5hbGxvd2VkTW9kZWxzID8/IHRoaXMucGFyZW50U3ViU2V0dGluZ3M/LmFsbG93ZWRNb2RlbHMgPz8gW10pLmluY2x1ZGVzKG1vZGVsLmlkKSk7XG4gICAgfVxuXG4gICAgZ2V0UHJlZmVycmVkTW9kZWxOYW1lKCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLmFsbElyaXNNb2RlbHMuZmluZCgobW9kZWwpID0+IG1vZGVsLmlkID09PSB0aGlzLnN1YlNldHRpbmdzPy5wcmVmZXJyZWRNb2RlbCk/Lm5hbWUgPz8gdGhpcy5zdWJTZXR0aW5ncz8ucHJlZmVycmVkTW9kZWw7XG4gICAgfVxuXG4gICAgZ2V0UHJlZmVycmVkTW9kZWxOYW1lUGFyZW50KCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLmFsbElyaXNNb2RlbHMuZmluZCgobW9kZWwpID0+IG1vZGVsLmlkID09PSB0aGlzLnBhcmVudFN1YlNldHRpbmdzPy5wcmVmZXJyZWRNb2RlbCk/Lm5hbWUgPz8gdGhpcy5wYXJlbnRTdWJTZXR0aW5ncz8ucHJlZmVycmVkTW9kZWw7XG4gICAgfVxuXG4gICAgb25BbGxvd2VkSXJpc01vZGVsc1NlbGVjdGlvbkNoYW5nZShtb2RlbDogSXJpc01vZGVsKSB7XG4gICAgICAgIHRoaXMuaW5oZXJpdEFsbG93ZWRNb2RlbHMgPSBmYWxzZTtcbiAgICAgICAgaWYgKHRoaXMuYWxsb3dlZElyaXNNb2RlbHMuaW5jbHVkZXMobW9kZWwpKSB7XG4gICAgICAgICAgICB0aGlzLmFsbG93ZWRJcmlzTW9kZWxzID0gdGhpcy5hbGxvd2VkSXJpc01vZGVscy5maWx0ZXIoKG0pID0+IG0gIT09IG1vZGVsKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuYWxsb3dlZElyaXNNb2RlbHMucHVzaChtb2RlbCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zdWJTZXR0aW5ncyEuYWxsb3dlZE1vZGVscyA9IHRoaXMuYWxsb3dlZElyaXNNb2RlbHMubWFwKChtb2RlbCkgPT4gbW9kZWwuaWQpO1xuICAgIH1cblxuICAgIHNldE1vZGVsKG1vZGVsOiBJcmlzTW9kZWwgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5zdWJTZXR0aW5ncyEucHJlZmVycmVkTW9kZWwgPSBtb2RlbD8uaWQ7XG4gICAgfVxuXG4gICAgb25FbmFibGVkQ2hhbmdlKCkge1xuICAgICAgICB0aGlzLnN1YlNldHRpbmdzIS5lbmFibGVkID0gdGhpcy5lbmFibGVkO1xuICAgIH1cblxuICAgIG9uSW5oZXJpdEFsbG93ZWRNb2RlbHNDaGFuZ2UoKSB7XG4gICAgICAgIGlmICh0aGlzLmluaGVyaXRBbGxvd2VkTW9kZWxzKSB7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzIS5hbGxvd2VkTW9kZWxzID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgdGhpcy5hbGxvd2VkSXJpc01vZGVscyA9IHRoaXMuZ2V0QXZhaWxhYmxlTW9kZWxzKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzIS5hbGxvd2VkTW9kZWxzID0gdGhpcy5hbGxvd2VkSXJpc01vZGVscy5tYXAoKG1vZGVsKSA9PiBtb2RlbC5pZCk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwiZm9ybS1jaGVjayBmb3JtLXN3aXRjaFwiPlxuICAgIDxpbnB1dFxuICAgICAgICBjbGFzcz1cImZvcm0tY2hlY2staW5wdXRcIlxuICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICBpZD1cImVuYWJsZWREaXNhYmxlZFN3aXRjaFwiXG4gICAgICAgIFtkaXNhYmxlZF09XCIhaXNBZG1pbiAmJiBzZXR0aW5nc1R5cGUgIT09IEVYRVJDSVNFXCJcbiAgICAgICAgWyhuZ01vZGVsKV09XCJlbmFibGVkXCJcbiAgICAgICAgKGNoYW5nZSk9XCJvbkVuYWJsZWRDaGFuZ2UoKVwiXG4gICAgLz5cbiAgICA8bGFiZWwgY2xhc3M9XCJmb3JtLWNoZWNrLWxhYmVsXCIgZm9yPVwiZW5hYmxlZERpc2FibGVkU3dpdGNoXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLnN1YlNldHRpbmdzLmVuYWJsZWQtZGlzYWJsZWRcIj4gRW5hYmxlZC9EaXNhYmxlZCA8L2xhYmVsPlxuPC9kaXY+XG48aDQgY2xhc3M9XCJmb3JtLWxhYmVsIG10LTNcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3Muc3ViU2V0dGluZ3MubW9kZWxzLnRpdGxlXCI+TW9kZWxzPC9oND5cbjxzcGFuPjxzcGFuIGNsYXNzPVwiZnctYm9sZCBmcy01XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLnN1YlNldHRpbmdzLm1vZGVscy5hbGxvd2VkTW9kZWxzLnRpdGxlXCI+QWxsb3dlZCBNb2RlbHM8L3NwYW4+OiA8L3NwYW4+XG5AaWYgKHBhcmVudFN1YlNldHRpbmdzKSB7XG4gICAgPGRpdiBjbGFzcz1cImZvcm0tY2hlY2sgZm9ybS1zd2l0Y2hcIj5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgICBjbGFzcz1cImZvcm0tY2hlY2staW5wdXRcIlxuICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgIGlkPVwiaW5oZXJpdEFsbG93ZWRNb2RlbHNTd2l0Y2hcIlxuICAgICAgICAgICAgW2Rpc2FibGVkXT1cIiFpc0FkbWluXCJcbiAgICAgICAgICAgIFsobmdNb2RlbCldPVwiaW5oZXJpdEFsbG93ZWRNb2RlbHNcIlxuICAgICAgICAgICAgKGNoYW5nZSk9XCJvbkluaGVyaXRBbGxvd2VkTW9kZWxzQ2hhbmdlKClcIlxuICAgICAgICAvPlxuICAgICAgICA8bGFiZWwgY2xhc3M9XCJmb3JtLWNoZWNrLWxhYmVsXCIgZm9yPVwiaW5oZXJpdEFsbG93ZWRNb2RlbHNTd2l0Y2hcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3Muc3ViU2V0dGluZ3MubW9kZWxzLmFsbG93ZWRNb2RlbHMuaW5oZXJpdFN3aXRjaFwiPiBJbmhlcml0IDwvbGFiZWw+XG4gICAgPC9kaXY+XG59XG48ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgIEBmb3IgKG1vZGVsIG9mIGFsbElyaXNNb2RlbHM7IHRyYWNrIG1vZGVsKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWNoZWNrXCI+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY2hlY2staW5wdXRcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgaWQ9XCJ7eyBtb2RlbC5pZCB9fVwiXG4gICAgICAgICAgICAgICAgW2Rpc2FibGVkXT1cIiFpc0FkbWluIHx8IGluaGVyaXRBbGxvd2VkTW9kZWxzXCJcbiAgICAgICAgICAgICAgICBbbmdNb2RlbF09XCJhbGxvd2VkSXJpc01vZGVscy5pbmNsdWRlcyhtb2RlbClcIlxuICAgICAgICAgICAgICAgIChuZ01vZGVsQ2hhbmdlKT1cIm9uQWxsb3dlZElyaXNNb2RlbHNTZWxlY3Rpb25DaGFuZ2UobW9kZWwpXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJmb3JtLWNoZWNrLWxhYmVsXCIgZm9yPVwie3sgbW9kZWwuaWQgfX1cIj5cbiAgICAgICAgICAgICAgICB7eyBtb2RlbC5uYW1lIH19XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG48L2Rpdj5cbjxoNSBjbGFzcz1cIm10LTNcIj48c3BhbiBjbGFzcz1cImZ3LWJvbGRcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3Muc3ViU2V0dGluZ3MubW9kZWxzLnByZWZlcnJlZE1vZGVsLnRpdGxlXCI+UHJlZmVycmVkIE1vZGVsPC9zcGFuPjo8L2g1PlxuPGRpdiBjbGFzcz1cImQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICA8ZGl2IG5nYkRyb3Bkb3duIGNsYXNzPVwiZC1pbmxpbmUtYmxvY2tcIj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1wcmltYXJ5IHctMTAwXCIgaWQ9XCJkcm9wZG93bkJhc2ljMVwiIG5nYkRyb3Bkb3duVG9nZ2xlPlxuICAgICAgICAgICAge3sgZ2V0UHJlZmVycmVkTW9kZWxOYW1lKCkgPz8gKCdhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3Muc3ViU2V0dGluZ3MubW9kZWxzLnByZWZlcnJlZE1vZGVsLmluaGVyaXQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSkgfX1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxkaXYgbmdiRHJvcGRvd25NZW51IGFyaWEtbGFiZWxsZWRieT1cImRyb3Bkb3duQmFzaWMxXCI+XG4gICAgICAgICAgICBAaWYgKHBhcmVudFN1YlNldHRpbmdzKSB7XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwic2V0TW9kZWwodW5kZWZpbmVkKVwiIFtjbGFzcy5zZWxlY3RlZF09XCJzdWJTZXR0aW5ncz8ucHJlZmVycmVkTW9kZWwgPT09IHVuZGVmaW5lZFwiIG5nYkRyb3Bkb3duSXRlbT5cbiAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuaXJpcy5zZXR0aW5ncy5zdWJTZXR0aW5ncy5tb2RlbHMucHJlZmVycmVkTW9kZWwuaW5oZXJpdCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAZm9yIChtb2RlbCBvZiBhbGxvd2VkSXJpc01vZGVsczsgdHJhY2sgbW9kZWwpIHtcbiAgICAgICAgICAgICAgICA8YnV0dG9uIChjbGljayk9XCJzZXRNb2RlbChtb2RlbClcIiBbY2xhc3Muc2VsZWN0ZWRdPVwibW9kZWwuaWQgPT09IHN1YlNldHRpbmdzPy5wcmVmZXJyZWRNb2RlbFwiIFtuZ2JUb29sdGlwXT1cIm1vZGVsLmRlc2NyaXB0aW9uXCIgbmdiRHJvcGRvd25JdGVtPlxuICAgICAgICAgICAgICAgICAgICB7eyBtb2RlbC5uYW1lIH19XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIEBpZiAoIXN1YlNldHRpbmdzPy5wcmVmZXJyZWRNb2RlbCkge1xuICAgICAgICA8c3BhbiBjbGFzcz1cInBzLTIgdGV4dC1zZWNvbmRhcnlcIj57eyBnZXRQcmVmZXJyZWRNb2RlbE5hbWVQYXJlbnQoKSB9fTwvc3Bhbj5cbiAgICB9XG48L2Rpdj5cbiIsImltcG9ydCB7IEJhc2VFbnRpdHkgfSBmcm9tICdhcHAvc2hhcmVkL21vZGVsL2Jhc2UtZW50aXR5JztcblxuZXhwb3J0IGNsYXNzIElyaXNUZW1wbGF0ZSBpbXBsZW1lbnRzIEJhc2VFbnRpdHkge1xuICAgIGlkPzogbnVtYmVyO1xuICAgIGNvbnRlbnQgPSAnJztcbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT25DaGFuZ2VzLCBPbkluaXQsIE91dHB1dCwgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSXJpc1RlbXBsYXRlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvc2V0dGluZ3MvaXJpcy10ZW1wbGF0ZSc7XG5pbXBvcnQgeyBJcmlzQ2hhdFN1YlNldHRpbmdzLCBJcmlzU3ViU2V0dGluZ3MgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9zZXR0aW5ncy9pcmlzLXN1Yi1zZXR0aW5ncy5tb2RlbCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWlyaXMtY2hhdC1zdWItc2V0dGluZ3MtdXBkYXRlJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vaXJpcy1jaGF0LXN1Yi1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBJcmlzQ2hhdFN1YlNldHRpbmdzVXBkYXRlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xuICAgIEBJbnB1dCgpXG4gICAgc3ViU2V0dGluZ3M/OiBJcmlzQ2hhdFN1YlNldHRpbmdzO1xuXG4gICAgQElucHV0KClcbiAgICBwYXJlbnRTdWJTZXR0aW5ncz86IElyaXNDaGF0U3ViU2V0dGluZ3M7XG5cbiAgICBASW5wdXQoKVxuICAgIHJhdGVMaW1pdFNldHRhYmxlID0gZmFsc2U7XG5cbiAgICBAT3V0cHV0KClcbiAgICBvbkNoYW5nZXMgPSBuZXcgRXZlbnRFbWl0dGVyPElyaXNTdWJTZXR0aW5ncz4oKTtcblxuICAgIHByZXZpb3VzVGVtcGxhdGU/OiBJcmlzVGVtcGxhdGU7XG5cbiAgICBpc0FkbWluOiBib29sZWFuO1xuXG4gICAgdGVtcGxhdGVDb250ZW50OiBzdHJpbmc7XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZUNvbnRlbnQgPSB0aGlzLnN1YlNldHRpbmdzPy50ZW1wbGF0ZT8uY29udGVudCA/PyB0aGlzLnBhcmVudFN1YlNldHRpbmdzPy50ZW1wbGF0ZT8uY29udGVudCA/PyAnJztcbiAgICB9XG5cbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XG4gICAgICAgIGlmIChjaGFuZ2VzLnN1YlNldHRpbmdzIHx8IGNoYW5nZXMucGFyZW50U3ViU2V0dGluZ3MpIHtcbiAgICAgICAgICAgIHRoaXMudGVtcGxhdGVDb250ZW50ID0gdGhpcy5zdWJTZXR0aW5ncz8udGVtcGxhdGU/LmNvbnRlbnQgPz8gdGhpcy5wYXJlbnRTdWJTZXR0aW5ncz8udGVtcGxhdGU/LmNvbnRlbnQgPz8gJyc7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBvbkluaGVyaXRUZW1wbGF0ZUNoYW5nZWQoKSB7XG4gICAgICAgIGlmICh0aGlzLnN1YlNldHRpbmdzPy50ZW1wbGF0ZSkge1xuICAgICAgICAgICAgdGhpcy5wcmV2aW91c1RlbXBsYXRlID0gdGhpcy5zdWJTZXR0aW5ncz8udGVtcGxhdGU7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzLnRlbXBsYXRlID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgdGhpcy50ZW1wbGF0ZUNvbnRlbnQgPSB0aGlzLnBhcmVudFN1YlNldHRpbmdzPy50ZW1wbGF0ZT8uY29udGVudCA/PyAnJztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGlyaXNUZW1wbGF0ZSA9IG5ldyBJcmlzVGVtcGxhdGUoKTtcbiAgICAgICAgICAgIGlyaXNUZW1wbGF0ZS5jb250ZW50ID0gJyc7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzIS50ZW1wbGF0ZSA9IHRoaXMucHJldmlvdXNUZW1wbGF0ZSA/PyBpcmlzVGVtcGxhdGU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBvblRlbXBsYXRlQ2hhbmdlZCgpIHtcbiAgICAgICAgaWYgKHRoaXMuc3ViU2V0dGluZ3M/LnRlbXBsYXRlKSB7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzLnRlbXBsYXRlLmNvbnRlbnQgPSB0aGlzLnRlbXBsYXRlQ29udGVudDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGlyaXNUZW1wbGF0ZSA9IG5ldyBJcmlzVGVtcGxhdGUoKTtcbiAgICAgICAgICAgIGlyaXNUZW1wbGF0ZS5jb250ZW50ID0gdGhpcy50ZW1wbGF0ZUNvbnRlbnQ7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzIS50ZW1wbGF0ZSA9IGlyaXNUZW1wbGF0ZTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsIkBpZiAocmF0ZUxpbWl0U2V0dGFibGUpIHtcbiAgICA8ZGl2PlxuICAgICAgICA8bGFiZWwgY2xhc3M9XCJmb3JtLWNoZWNrLWxhYmVsXCIgZm9yPVwicmF0ZUxpbWl0XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLnN1YlNldHRpbmdzLnJhdGVMaW1pdFwiPlJhdGUgTGltaXQ8L2xhYmVsPlxuICAgICAgICA8amhpLWhlbHAtaWNvbiBbdGV4dF09XCInYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLnN1YlNldHRpbmdzLnJhdGVMaW1pdFRvb2x0aXAnXCI+PC9qaGktaGVscC1pY29uPlxuICAgICAgICA8aW5wdXQgaWQ9XCJyYXRlTGltaXRcIiBuYW1lPVwicmF0ZUxpbWl0XCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiB0eXBlPVwibnVtYmVyXCIgW2N1c3RvbU1pbl09XCItMVwiIFtjdXN0b21NYXhdPVwiMTAwMDAwMFwiIFsobmdNb2RlbCldPVwic3ViU2V0dGluZ3MhLnJhdGVMaW1pdFwiIC8+XG4gICAgPC9kaXY+XG59XG5AaWYgKHJhdGVMaW1pdFNldHRhYmxlKSB7XG4gICAgPGRpdj5cbiAgICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1jaGVjay1sYWJlbFwiIGZvcj1cInJhdGVMaW1pdFRpbWVmcmFtZUhvdXJzXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLnN1YlNldHRpbmdzLnJhdGVMaW1pdFRpbWVmcmFtZUhvdXJzXCJcbiAgICAgICAgICAgID5SYXRlIExpbWl0IFRpbWVmcmFtZSAoSG91cnMpPC9sYWJlbFxuICAgICAgICA+XG4gICAgICAgIDxqaGktaGVscC1pY29uIFt0ZXh0XT1cIidhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3Muc3ViU2V0dGluZ3MucmF0ZUxpbWl0VGltZWZyYW1lSG91cnNUb29sdGlwJ1wiPjwvamhpLWhlbHAtaWNvbj5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgICBpZD1cInJhdGVMaW1pdFRpbWVmcmFtZUhvdXJzXCJcbiAgICAgICAgICAgIG5hbWU9XCJyYXRlTGltaXRUaW1lZnJhbWVIb3Vyc1wiXG4gICAgICAgICAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiXG4gICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgIFtjdXN0b21NaW5dPVwiMFwiXG4gICAgICAgICAgICBbY3VzdG9tTWF4XT1cIjEwMDAwMDBcIlxuICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJzdWJTZXR0aW5ncyEucmF0ZUxpbWl0VGltZWZyYW1lSG91cnNcIlxuICAgICAgICAvPlxuICAgIDwvZGl2PlxufVxuPGRpdiBjbGFzcz1cIm1iLTMgbXQtM1wiPlxuICAgIDxoNCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3Muc3ViU2V0dGluZ3MudGVtcGxhdGUudGl0bGVcIj5UZW1wbGF0ZTwvaDQ+XG4gICAgQGlmIChwYXJlbnRTdWJTZXR0aW5ncykge1xuICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1jaGVjayBmb3JtLXN3aXRjaFwiPlxuICAgICAgICAgICAgPGlucHV0IGNsYXNzPVwiZm9ybS1jaGVjay1pbnB1dFwiIHR5cGU9XCJjaGVja2JveFwiIGlkPVwiaW5oZXJpdFRlbXBsYXRlXCIgW2NoZWNrZWRdPVwiIXN1YlNldHRpbmdzPy50ZW1wbGF0ZVwiIChjaGFuZ2UpPVwib25Jbmhlcml0VGVtcGxhdGVDaGFuZ2VkKClcIiAvPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1jaGVjay1sYWJlbFwiIGZvcj1cImluaGVyaXRUZW1wbGF0ZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuaXJpcy5zZXR0aW5ncy5zdWJTZXR0aW5ncy50ZW1wbGF0ZS5pbmhlcml0XCI+SW5oZXJpdDwvbGFiZWw+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICA8dGV4dGFyZWEgaWQ9XCJ0ZW1wbGF0ZS1lZGl0b3JcIiBjbGFzcz1cImZvcm0tY29udHJvbFwiIHJvd3M9XCIyNVwiIFsobmdNb2RlbCldPVwidGVtcGxhdGVDb250ZW50XCIgKGNoYW5nZSk9XCJvblRlbXBsYXRlQ2hhbmdlZCgpXCIgW2Rpc2FibGVkXT1cIiFzdWJTZXR0aW5ncz8udGVtcGxhdGVcIj48L3RleHRhcmVhPlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uQ2hhbmdlcywgT25Jbml0LCBPdXRwdXQsIFNpbXBsZUNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IElyaXNUZW1wbGF0ZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL3NldHRpbmdzL2lyaXMtdGVtcGxhdGUnO1xuaW1wb3J0IHsgSXJpc0hlc3RpYVN1YlNldHRpbmdzLCBJcmlzU3ViU2V0dGluZ3MgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9zZXR0aW5ncy9pcmlzLXN1Yi1zZXR0aW5ncy5tb2RlbCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWlyaXMtaGVzdGlhLXN1Yi1zZXR0aW5ncy11cGRhdGUnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9pcmlzLWhlc3RpYS1zdWItc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgSXJpc0hlc3RpYVN1YlNldHRpbmdzVXBkYXRlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xuICAgIEBJbnB1dCgpXG4gICAgc3ViU2V0dGluZ3M6IElyaXNIZXN0aWFTdWJTZXR0aW5ncztcblxuICAgIEBJbnB1dCgpXG4gICAgcGFyZW50U3ViU2V0dGluZ3M/OiBJcmlzSGVzdGlhU3ViU2V0dGluZ3M7XG5cbiAgICBAT3V0cHV0KClcbiAgICBvbkNoYW5nZXMgPSBuZXcgRXZlbnRFbWl0dGVyPElyaXNTdWJTZXR0aW5ncz4oKTtcblxuICAgIHByZXZpb3VzVGVtcGxhdGU/OiBJcmlzVGVtcGxhdGU7XG5cbiAgICBpc0FkbWluOiBib29sZWFuO1xuXG4gICAgdGVtcGxhdGVDb250ZW50OiBzdHJpbmc7XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZUNvbnRlbnQgPSB0aGlzLnN1YlNldHRpbmdzLnRlbXBsYXRlPy5jb250ZW50ID8/IHRoaXMucGFyZW50U3ViU2V0dGluZ3M/LnRlbXBsYXRlPy5jb250ZW50ID8/ICcnO1xuICAgIH1cblxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcbiAgICAgICAgaWYgKGNoYW5nZXMuc3ViU2V0dGluZ3MgfHwgY2hhbmdlcy5wYXJlbnRTdWJTZXR0aW5ncykge1xuICAgICAgICAgICAgdGhpcy50ZW1wbGF0ZUNvbnRlbnQgPSB0aGlzLnN1YlNldHRpbmdzPy50ZW1wbGF0ZT8uY29udGVudCA/PyB0aGlzLnBhcmVudFN1YlNldHRpbmdzPy50ZW1wbGF0ZT8uY29udGVudCA/PyAnJztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG9uSW5oZXJpdFRlbXBsYXRlQ2hhbmdlZCgpIHtcbiAgICAgICAgaWYgKHRoaXMuc3ViU2V0dGluZ3MudGVtcGxhdGUpIHtcbiAgICAgICAgICAgIHRoaXMucHJldmlvdXNUZW1wbGF0ZSA9IHRoaXMuc3ViU2V0dGluZ3MudGVtcGxhdGU7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzLnRlbXBsYXRlID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgdGhpcy50ZW1wbGF0ZUNvbnRlbnQgPSB0aGlzLnBhcmVudFN1YlNldHRpbmdzPy50ZW1wbGF0ZT8uY29udGVudCA/PyAnJztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGlyaXNUZW1wbGF0ZSA9IG5ldyBJcmlzVGVtcGxhdGUoKTtcbiAgICAgICAgICAgIGlyaXNUZW1wbGF0ZS5jb250ZW50ID0gJyc7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzLnRlbXBsYXRlID0gdGhpcy5wcmV2aW91c1RlbXBsYXRlID8/IGlyaXNUZW1wbGF0ZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG9uVGVtcGxhdGVDaGFuZ2VkKCkge1xuICAgICAgICBpZiAodGhpcy5zdWJTZXR0aW5ncy50ZW1wbGF0ZSkge1xuICAgICAgICAgICAgdGhpcy5zdWJTZXR0aW5ncy50ZW1wbGF0ZS5jb250ZW50ID0gdGhpcy50ZW1wbGF0ZUNvbnRlbnQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBpcmlzVGVtcGxhdGUgPSBuZXcgSXJpc1RlbXBsYXRlKCk7XG4gICAgICAgICAgICBpcmlzVGVtcGxhdGUuY29udGVudCA9IHRoaXMudGVtcGxhdGVDb250ZW50O1xuICAgICAgICAgICAgdGhpcy5zdWJTZXR0aW5ncy50ZW1wbGF0ZSA9IGlyaXNUZW1wbGF0ZTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJtYi0zIG10LTNcIj5cbiAgICA8aDQgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLnN1YlNldHRpbmdzLnRlbXBsYXRlLnRpdGxlXCI+VGVtcGxhdGU8L2g0PlxuICAgIEBpZiAocGFyZW50U3ViU2V0dGluZ3MpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tY2hlY2sgZm9ybS1zd2l0Y2hcIj5cbiAgICAgICAgICAgIDxpbnB1dCBjbGFzcz1cImZvcm0tY2hlY2staW5wdXRcIiB0eXBlPVwiY2hlY2tib3hcIiBpZD1cImluaGVyaXRUZW1wbGF0ZVwiIFtjaGVja2VkXT1cIiFzdWJTZXR0aW5ncz8udGVtcGxhdGVcIiAoY2hhbmdlKT1cIm9uSW5oZXJpdFRlbXBsYXRlQ2hhbmdlZCgpXCIgLz5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImZvcm0tY2hlY2stbGFiZWxcIiBmb3I9XCJpbmhlcml0VGVtcGxhdGVcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3Muc3ViU2V0dGluZ3MudGVtcGxhdGUuaW5oZXJpdFwiPkluaGVyaXQ8L2xhYmVsPlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgPHRleHRhcmVhIGlkPVwidGVtcGxhdGUtZWRpdG9yXCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiByb3dzPVwiMjVcIiBbKG5nTW9kZWwpXT1cInRlbXBsYXRlQ29udGVudFwiIChjaGFuZ2UpPVwib25UZW1wbGF0ZUNoYW5nZWQoKVwiIFtkaXNhYmxlZF09XCIhc3ViU2V0dGluZ3M/LnRlbXBsYXRlXCI+PC90ZXh0YXJlYT5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIElucHV0LCBPdXRwdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IElyaXNHbG9iYWxTZXR0aW5ncyB9IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL3NldHRpbmdzL2lyaXMtc2V0dGluZ3MubW9kZWwnO1xuaW1wb3J0IHsgSXJpc1N1YlNldHRpbmdzIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvc2V0dGluZ3MvaXJpcy1zdWItc2V0dGluZ3MubW9kZWwnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1pcmlzLWdsb2JhbC1hdXRvdXBkYXRlLXNldHRpbmdzLXVwZGF0ZScsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2lyaXMtZ2xvYmFsLWF1dG91cGRhdGUtc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgSXJpc0dsb2JhbEF1dG91cGRhdGVTZXR0aW5nc1VwZGF0ZUNvbXBvbmVudCB7XG4gICAgQElucHV0KClcbiAgICBpcmlzU2V0dGluZ3M/OiBJcmlzR2xvYmFsU2V0dGluZ3M7XG5cbiAgICBAT3V0cHV0KClcbiAgICBvbkNoYW5nZXMgPSBuZXcgRXZlbnRFbWl0dGVyPElyaXNTdWJTZXR0aW5ncz4oKTtcbn1cbiIsIkBpZiAoaXJpc1NldHRpbmdzKSB7XG4gICAgPGRpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tY2hlY2sgZm9ybS1zd2l0Y2hcIj5cbiAgICAgICAgICAgIDxpbnB1dCBjbGFzcz1cImZvcm0tY2hlY2staW5wdXRcIiB0eXBlPVwiY2hlY2tib3hcIiBpZD1cImF1dG9VcGRhdGVDaGF0XCIgWyhuZ01vZGVsKV09XCJpcmlzU2V0dGluZ3MhLmVuYWJsZUF1dG9VcGRhdGVDaGF0XCIgLz5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImZvcm0tY2hlY2stbGFiZWxcIiBmb3I9XCJhdXRvVXBkYXRlQ2hhdFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuaXJpcy5zZXR0aW5ncy5hdXRvVXBkYXRlLmNoYXRMYWJlbFwiPiBBdXRvLXVwZGF0ZSBDaGF0IFNldHRpbmdzIDwvbGFiZWw+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1jaGVjayBmb3JtLXN3aXRjaFwiPlxuICAgICAgICAgICAgPGlucHV0IGNsYXNzPVwiZm9ybS1jaGVjay1pbnB1dFwiIHR5cGU9XCJjaGVja2JveFwiIGlkPVwiYXV0b1VwZGF0ZUhlc3RpYVwiIFsobmdNb2RlbCldPVwiaXJpc1NldHRpbmdzIS5lbmFibGVBdXRvVXBkYXRlSGVzdGlhXCIgLz5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImZvcm0tY2hlY2stbGFiZWxcIiBmb3I9XCJhdXRvVXBkYXRlSGVzdGlhXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLmF1dG9VcGRhdGUuaGVzdGlhTGFiZWxcIj4gQXV0by11cGRhdGUgSGVzdGlhIFNldHRpbmdzIDwvbGFiZWw+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1jaGVjayBmb3JtLXN3aXRjaFwiPlxuICAgICAgICAgICAgPGlucHV0IGNsYXNzPVwiZm9ybS1jaGVjay1pbnB1dFwiIHR5cGU9XCJjaGVja2JveFwiIGlkPVwiYXV0b1VwZGF0ZUNvZGVFZGl0b3JcIiBbKG5nTW9kZWwpXT1cImlyaXNTZXR0aW5ncyEuZW5hYmxlQXV0b1VwZGF0ZUNvZGVFZGl0b3JcIiAvPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1jaGVjay1sYWJlbFwiIGZvcj1cImF1dG9VcGRhdGVDb2RlRWRpdG9yXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLmF1dG9VcGRhdGUuY29kZUVkaXRvckxhYmVsXCI+IEF1dG8tdXBkYXRlIENvZGUgRWRpdG9yIFNldHRpbmdzIDwvbGFiZWw+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIElucHV0LCBPbkNoYW5nZXMsIE9uSW5pdCwgT3V0cHV0LCBTaW1wbGVDaGFuZ2VzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJcmlzVGVtcGxhdGUgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9zZXR0aW5ncy9pcmlzLXRlbXBsYXRlJztcbmltcG9ydCB7IElyaXNDb2RlRWRpdG9yU3ViU2V0dGluZ3MsIElyaXNTdWJTZXR0aW5ncyB9IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL3NldHRpbmdzL2lyaXMtc3ViLXNldHRpbmdzLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktaXJpcy1jb2RlLWVkaXRvci1zdWItc2V0dGluZ3MtdXBkYXRlJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vaXJpcy1jb2RlLWVkaXRvci1zdWItc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgSXJpc0NvZGVFZGl0b3JTdWJTZXR0aW5nc1VwZGF0ZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcbiAgICBASW5wdXQoKVxuICAgIHN1YlNldHRpbmdzPzogSXJpc0NvZGVFZGl0b3JTdWJTZXR0aW5ncztcblxuICAgIEBJbnB1dCgpXG4gICAgcGFyZW50U3ViU2V0dGluZ3M/OiBJcmlzQ29kZUVkaXRvclN1YlNldHRpbmdzO1xuXG4gICAgQE91dHB1dCgpXG4gICAgb25DaGFuZ2VzID0gbmV3IEV2ZW50RW1pdHRlcjxJcmlzU3ViU2V0dGluZ3M+KCk7XG5cbiAgICBwcmV2aW91c0NoYXRUZW1wbGF0ZT86IElyaXNUZW1wbGF0ZTtcbiAgICBwcmV2aW91c1Byb2JsZW1TdGF0ZW1lbnRHZW5lcmF0aW9uVGVtcGxhdGU/OiBJcmlzVGVtcGxhdGU7XG4gICAgcHJldmlvdXNUZW1wbGF0ZVJlcG9HZW5lcmF0aW9uVGVtcGxhdGU/OiBJcmlzVGVtcGxhdGU7XG4gICAgcHJldmlvdXNTb2x1dGlvblJlcG9HZW5lcmF0aW9uVGVtcGxhdGU/OiBJcmlzVGVtcGxhdGU7XG4gICAgcHJldmlvdXNUZXN0UmVwb0dlbmVyYXRpb25UZW1wbGF0ZT86IElyaXNUZW1wbGF0ZTtcblxuICAgIGNoYXRUZW1wbGF0ZUNvbnRlbnQ6IHN0cmluZztcbiAgICBwcm9ibGVtU3RhdGVtZW50R2VuZXJhdGlvblRlbXBsYXRlQ29udGVudDogc3RyaW5nO1xuICAgIHRlbXBsYXRlUmVwb0dlbmVyYXRpb25UZW1wbGF0ZUNvbnRlbnQ6IHN0cmluZztcbiAgICBzb2x1dGlvblJlcG9HZW5lcmF0aW9uVGVtcGxhdGVDb250ZW50OiBzdHJpbmc7XG4gICAgdGVzdFJlcG9HZW5lcmF0aW9uVGVtcGxhdGVDb250ZW50OiBzdHJpbmc7XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5yZXNldFRlbXBsYXRlcygpO1xuICAgIH1cblxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcbiAgICAgICAgaWYgKGNoYW5nZXMuc3ViU2V0dGluZ3MgfHwgY2hhbmdlcy5wYXJlbnRTdWJTZXR0aW5ncykge1xuICAgICAgICAgICAgdGhpcy5yZXNldFRlbXBsYXRlcygpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSByZXNldFRlbXBsYXRlcygpIHtcbiAgICAgICAgdGhpcy5jaGF0VGVtcGxhdGVDb250ZW50ID0gdGhpcy5zdWJTZXR0aW5ncz8uY2hhdFRlbXBsYXRlPy5jb250ZW50ID8/IHRoaXMucGFyZW50U3ViU2V0dGluZ3M/LmNoYXRUZW1wbGF0ZT8uY29udGVudCA/PyAnJztcbiAgICAgICAgdGhpcy5wcm9ibGVtU3RhdGVtZW50R2VuZXJhdGlvblRlbXBsYXRlQ29udGVudCA9XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzPy5wcm9ibGVtU3RhdGVtZW50R2VuZXJhdGlvblRlbXBsYXRlPy5jb250ZW50ID8/IHRoaXMucGFyZW50U3ViU2V0dGluZ3M/LnByb2JsZW1TdGF0ZW1lbnRHZW5lcmF0aW9uVGVtcGxhdGU/LmNvbnRlbnQgPz8gJyc7XG4gICAgICAgIHRoaXMudGVtcGxhdGVSZXBvR2VuZXJhdGlvblRlbXBsYXRlQ29udGVudCA9XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzPy50ZW1wbGF0ZVJlcG9HZW5lcmF0aW9uVGVtcGxhdGU/LmNvbnRlbnQgPz8gdGhpcy5wYXJlbnRTdWJTZXR0aW5ncz8udGVtcGxhdGVSZXBvR2VuZXJhdGlvblRlbXBsYXRlPy5jb250ZW50ID8/ICcnO1xuICAgICAgICB0aGlzLnNvbHV0aW9uUmVwb0dlbmVyYXRpb25UZW1wbGF0ZUNvbnRlbnQgPVxuICAgICAgICAgICAgdGhpcy5zdWJTZXR0aW5ncz8uc29sdXRpb25SZXBvR2VuZXJhdGlvblRlbXBsYXRlPy5jb250ZW50ID8/IHRoaXMucGFyZW50U3ViU2V0dGluZ3M/LnNvbHV0aW9uUmVwb0dlbmVyYXRpb25UZW1wbGF0ZT8uY29udGVudCA/PyAnJztcbiAgICAgICAgdGhpcy50ZXN0UmVwb0dlbmVyYXRpb25UZW1wbGF0ZUNvbnRlbnQgPSB0aGlzLnN1YlNldHRpbmdzPy50ZXN0UmVwb0dlbmVyYXRpb25UZW1wbGF0ZT8uY29udGVudCA/PyB0aGlzLnBhcmVudFN1YlNldHRpbmdzPy50ZXN0UmVwb0dlbmVyYXRpb25UZW1wbGF0ZT8uY29udGVudCA/PyAnJztcbiAgICB9XG5cbiAgICBvbkluaGVyaXRUZW1wbGF0ZUNoYW5nZWQoKSB7XG4gICAgICAgIGlmICh0aGlzLnN1YlNldHRpbmdzPy5jaGF0VGVtcGxhdGUpIHtcbiAgICAgICAgICAgIHRoaXMucHJldmlvdXNDaGF0VGVtcGxhdGUgPSB0aGlzLnN1YlNldHRpbmdzPy5jaGF0VGVtcGxhdGU7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzLmNoYXRUZW1wbGF0ZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIHRoaXMuY2hhdFRlbXBsYXRlQ29udGVudCA9IHRoaXMucGFyZW50U3ViU2V0dGluZ3M/LmNoYXRUZW1wbGF0ZT8uY29udGVudCA/PyAnJztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGlyaXNUZW1wbGF0ZSA9IG5ldyBJcmlzVGVtcGxhdGUoKTtcbiAgICAgICAgICAgIGlyaXNUZW1wbGF0ZS5jb250ZW50ID0gJyc7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzIS5jaGF0VGVtcGxhdGUgPSB0aGlzLnByZXZpb3VzQ2hhdFRlbXBsYXRlID8/IGlyaXNUZW1wbGF0ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5zdWJTZXR0aW5ncz8ucHJvYmxlbVN0YXRlbWVudEdlbmVyYXRpb25UZW1wbGF0ZSkge1xuICAgICAgICAgICAgdGhpcy5wcmV2aW91c1Byb2JsZW1TdGF0ZW1lbnRHZW5lcmF0aW9uVGVtcGxhdGUgPSB0aGlzLnN1YlNldHRpbmdzPy5wcm9ibGVtU3RhdGVtZW50R2VuZXJhdGlvblRlbXBsYXRlO1xuICAgICAgICAgICAgdGhpcy5zdWJTZXR0aW5ncy5wcm9ibGVtU3RhdGVtZW50R2VuZXJhdGlvblRlbXBsYXRlID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgdGhpcy5wcm9ibGVtU3RhdGVtZW50R2VuZXJhdGlvblRlbXBsYXRlQ29udGVudCA9IHRoaXMucGFyZW50U3ViU2V0dGluZ3M/LnByb2JsZW1TdGF0ZW1lbnRHZW5lcmF0aW9uVGVtcGxhdGU/LmNvbnRlbnQgPz8gJyc7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBpcmlzVGVtcGxhdGUgPSBuZXcgSXJpc1RlbXBsYXRlKCk7XG4gICAgICAgICAgICBpcmlzVGVtcGxhdGUuY29udGVudCA9ICcnO1xuICAgICAgICAgICAgdGhpcy5zdWJTZXR0aW5ncyEucHJvYmxlbVN0YXRlbWVudEdlbmVyYXRpb25UZW1wbGF0ZSA9IHRoaXMucHJldmlvdXNQcm9ibGVtU3RhdGVtZW50R2VuZXJhdGlvblRlbXBsYXRlID8/IGlyaXNUZW1wbGF0ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5zdWJTZXR0aW5ncz8udGVtcGxhdGVSZXBvR2VuZXJhdGlvblRlbXBsYXRlKSB7XG4gICAgICAgICAgICB0aGlzLnByZXZpb3VzVGVtcGxhdGVSZXBvR2VuZXJhdGlvblRlbXBsYXRlID0gdGhpcy5zdWJTZXR0aW5ncz8udGVtcGxhdGVSZXBvR2VuZXJhdGlvblRlbXBsYXRlO1xuICAgICAgICAgICAgdGhpcy5zdWJTZXR0aW5ncy50ZW1wbGF0ZVJlcG9HZW5lcmF0aW9uVGVtcGxhdGUgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICB0aGlzLnRlbXBsYXRlUmVwb0dlbmVyYXRpb25UZW1wbGF0ZUNvbnRlbnQgPSB0aGlzLnBhcmVudFN1YlNldHRpbmdzPy50ZW1wbGF0ZVJlcG9HZW5lcmF0aW9uVGVtcGxhdGU/LmNvbnRlbnQgPz8gJyc7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBpcmlzVGVtcGxhdGUgPSBuZXcgSXJpc1RlbXBsYXRlKCk7XG4gICAgICAgICAgICBpcmlzVGVtcGxhdGUuY29udGVudCA9ICcnO1xuICAgICAgICAgICAgdGhpcy5zdWJTZXR0aW5ncyEudGVtcGxhdGVSZXBvR2VuZXJhdGlvblRlbXBsYXRlID0gdGhpcy5wcmV2aW91c1RlbXBsYXRlUmVwb0dlbmVyYXRpb25UZW1wbGF0ZSA/PyBpcmlzVGVtcGxhdGU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuc3ViU2V0dGluZ3M/LnNvbHV0aW9uUmVwb0dlbmVyYXRpb25UZW1wbGF0ZSkge1xuICAgICAgICAgICAgdGhpcy5wcmV2aW91c1NvbHV0aW9uUmVwb0dlbmVyYXRpb25UZW1wbGF0ZSA9IHRoaXMuc3ViU2V0dGluZ3M/LnNvbHV0aW9uUmVwb0dlbmVyYXRpb25UZW1wbGF0ZTtcbiAgICAgICAgICAgIHRoaXMuc3ViU2V0dGluZ3Muc29sdXRpb25SZXBvR2VuZXJhdGlvblRlbXBsYXRlID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgdGhpcy5zb2x1dGlvblJlcG9HZW5lcmF0aW9uVGVtcGxhdGVDb250ZW50ID0gdGhpcy5wYXJlbnRTdWJTZXR0aW5ncz8uc29sdXRpb25SZXBvR2VuZXJhdGlvblRlbXBsYXRlPy5jb250ZW50ID8/ICcnO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgaXJpc1RlbXBsYXRlID0gbmV3IElyaXNUZW1wbGF0ZSgpO1xuICAgICAgICAgICAgaXJpc1RlbXBsYXRlLmNvbnRlbnQgPSAnJztcbiAgICAgICAgICAgIHRoaXMuc3ViU2V0dGluZ3MhLnNvbHV0aW9uUmVwb0dlbmVyYXRpb25UZW1wbGF0ZSA9IHRoaXMucHJldmlvdXNTb2x1dGlvblJlcG9HZW5lcmF0aW9uVGVtcGxhdGUgPz8gaXJpc1RlbXBsYXRlO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLnN1YlNldHRpbmdzPy50ZXN0UmVwb0dlbmVyYXRpb25UZW1wbGF0ZSkge1xuICAgICAgICAgICAgdGhpcy5wcmV2aW91c1Rlc3RSZXBvR2VuZXJhdGlvblRlbXBsYXRlID0gdGhpcy5zdWJTZXR0aW5ncz8udGVzdFJlcG9HZW5lcmF0aW9uVGVtcGxhdGU7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzLnRlc3RSZXBvR2VuZXJhdGlvblRlbXBsYXRlID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgdGhpcy50ZXN0UmVwb0dlbmVyYXRpb25UZW1wbGF0ZUNvbnRlbnQgPSB0aGlzLnBhcmVudFN1YlNldHRpbmdzPy50ZXN0UmVwb0dlbmVyYXRpb25UZW1wbGF0ZT8uY29udGVudCA/PyAnJztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGlyaXNUZW1wbGF0ZSA9IG5ldyBJcmlzVGVtcGxhdGUoKTtcbiAgICAgICAgICAgIGlyaXNUZW1wbGF0ZS5jb250ZW50ID0gJyc7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzIS50ZXN0UmVwb0dlbmVyYXRpb25UZW1wbGF0ZSA9IHRoaXMucHJldmlvdXNUZXN0UmVwb0dlbmVyYXRpb25UZW1wbGF0ZSA/PyBpcmlzVGVtcGxhdGU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBvblRlbXBsYXRlQ2hhbmdlZCgpIHtcbiAgICAgICAgaWYgKHRoaXMuc3ViU2V0dGluZ3M/LmNoYXRUZW1wbGF0ZSkge1xuICAgICAgICAgICAgdGhpcy5zdWJTZXR0aW5ncy5jaGF0VGVtcGxhdGUuY29udGVudCA9IHRoaXMuY2hhdFRlbXBsYXRlQ29udGVudDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGlyaXNUZW1wbGF0ZSA9IG5ldyBJcmlzVGVtcGxhdGUoKTtcbiAgICAgICAgICAgIGlyaXNUZW1wbGF0ZS5jb250ZW50ID0gdGhpcy5jaGF0VGVtcGxhdGVDb250ZW50O1xuICAgICAgICAgICAgdGhpcy5zdWJTZXR0aW5ncyEuY2hhdFRlbXBsYXRlID0gaXJpc1RlbXBsYXRlO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLnN1YlNldHRpbmdzPy5wcm9ibGVtU3RhdGVtZW50R2VuZXJhdGlvblRlbXBsYXRlKSB7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzLnByb2JsZW1TdGF0ZW1lbnRHZW5lcmF0aW9uVGVtcGxhdGUuY29udGVudCA9IHRoaXMucHJvYmxlbVN0YXRlbWVudEdlbmVyYXRpb25UZW1wbGF0ZUNvbnRlbnQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBpcmlzVGVtcGxhdGUgPSBuZXcgSXJpc1RlbXBsYXRlKCk7XG4gICAgICAgICAgICBpcmlzVGVtcGxhdGUuY29udGVudCA9IHRoaXMucHJvYmxlbVN0YXRlbWVudEdlbmVyYXRpb25UZW1wbGF0ZUNvbnRlbnQ7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzIS5wcm9ibGVtU3RhdGVtZW50R2VuZXJhdGlvblRlbXBsYXRlID0gaXJpc1RlbXBsYXRlO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLnN1YlNldHRpbmdzPy50ZW1wbGF0ZVJlcG9HZW5lcmF0aW9uVGVtcGxhdGUpIHtcbiAgICAgICAgICAgIHRoaXMuc3ViU2V0dGluZ3MudGVtcGxhdGVSZXBvR2VuZXJhdGlvblRlbXBsYXRlLmNvbnRlbnQgPSB0aGlzLnRlbXBsYXRlUmVwb0dlbmVyYXRpb25UZW1wbGF0ZUNvbnRlbnQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBpcmlzVGVtcGxhdGUgPSBuZXcgSXJpc1RlbXBsYXRlKCk7XG4gICAgICAgICAgICBpcmlzVGVtcGxhdGUuY29udGVudCA9IHRoaXMudGVtcGxhdGVSZXBvR2VuZXJhdGlvblRlbXBsYXRlQ29udGVudDtcbiAgICAgICAgICAgIHRoaXMuc3ViU2V0dGluZ3MhLnRlbXBsYXRlUmVwb0dlbmVyYXRpb25UZW1wbGF0ZSA9IGlyaXNUZW1wbGF0ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5zdWJTZXR0aW5ncz8uc29sdXRpb25SZXBvR2VuZXJhdGlvblRlbXBsYXRlKSB7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzLnNvbHV0aW9uUmVwb0dlbmVyYXRpb25UZW1wbGF0ZS5jb250ZW50ID0gdGhpcy5zb2x1dGlvblJlcG9HZW5lcmF0aW9uVGVtcGxhdGVDb250ZW50O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgaXJpc1RlbXBsYXRlID0gbmV3IElyaXNUZW1wbGF0ZSgpO1xuICAgICAgICAgICAgaXJpc1RlbXBsYXRlLmNvbnRlbnQgPSB0aGlzLnNvbHV0aW9uUmVwb0dlbmVyYXRpb25UZW1wbGF0ZUNvbnRlbnQ7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzIS5zb2x1dGlvblJlcG9HZW5lcmF0aW9uVGVtcGxhdGUgPSBpcmlzVGVtcGxhdGU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuc3ViU2V0dGluZ3M/LnRlc3RSZXBvR2VuZXJhdGlvblRlbXBsYXRlKSB7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzLnRlc3RSZXBvR2VuZXJhdGlvblRlbXBsYXRlLmNvbnRlbnQgPSB0aGlzLnRlc3RSZXBvR2VuZXJhdGlvblRlbXBsYXRlQ29udGVudDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGlyaXNUZW1wbGF0ZSA9IG5ldyBJcmlzVGVtcGxhdGUoKTtcbiAgICAgICAgICAgIGlyaXNUZW1wbGF0ZS5jb250ZW50ID0gdGhpcy50ZXN0UmVwb0dlbmVyYXRpb25UZW1wbGF0ZUNvbnRlbnQ7XG4gICAgICAgICAgICB0aGlzLnN1YlNldHRpbmdzIS50ZXN0UmVwb0dlbmVyYXRpb25UZW1wbGF0ZSA9IGlyaXNUZW1wbGF0ZTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJtYi0zIG10LTNcIj5cbiAgICA8aDQgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLnN1YlNldHRpbmdzLmNvZGVFZGl0b3IudGVtcGxhdGVzXCI+VGVtcGxhdGVzPC9oND5cbiAgICBAaWYgKHBhcmVudFN1YlNldHRpbmdzKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWNoZWNrIGZvcm0tc3dpdGNoXCI+XG4gICAgICAgICAgICA8aW5wdXQgY2xhc3M9XCJmb3JtLWNoZWNrLWlucHV0XCIgdHlwZT1cImNoZWNrYm94XCIgaWQ9XCJpbmhlcml0VGVtcGxhdGVcIiBbY2hlY2tlZF09XCIhc3ViU2V0dGluZ3M/LmNoYXRUZW1wbGF0ZVwiIChjaGFuZ2UpPVwib25Jbmhlcml0VGVtcGxhdGVDaGFuZ2VkKClcIiAvPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1jaGVjay1sYWJlbFwiIGZvcj1cImluaGVyaXRUZW1wbGF0ZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuaXJpcy5zZXR0aW5ncy5zdWJTZXR0aW5ncy5jb2RlRWRpdG9yLnRlbXBsYXRlc0luaGVyaXRTd2l0Y2hcIj5Jbmhlcml0PC9sYWJlbD5cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuICAgIDxkaXY+XG4gICAgICAgIDxoMyBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3Muc3ViU2V0dGluZ3MuY29kZUVkaXRvci5jaGF0VGVtcGxhdGVcIj5DaGF0IFRlbXBsYXRlPC9oMz5cbiAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICBpZD1cImNoYXQtdGVtcGxhdGUtZWRpdG9yXCJcbiAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCJcbiAgICAgICAgICAgIHJvd3M9XCIyNVwiXG4gICAgICAgICAgICBbKG5nTW9kZWwpXT1cImNoYXRUZW1wbGF0ZUNvbnRlbnRcIlxuICAgICAgICAgICAgKGNoYW5nZSk9XCJvblRlbXBsYXRlQ2hhbmdlZCgpXCJcbiAgICAgICAgICAgIFtkaXNhYmxlZF09XCIhc3ViU2V0dGluZ3M/LmNoYXRUZW1wbGF0ZVwiXG4gICAgICAgID48L3RleHRhcmVhPlxuICAgIDwvZGl2PlxuICAgIDxkaXY+XG4gICAgICAgIDxoMyBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3Muc3ViU2V0dGluZ3MuY29kZUVkaXRvci5wcm9ibGVtU3RhdGVtZW50VGVtcGxhdGVcIj5Qcm9ibGVtIFN0YXRlbWVudCBHZW5lcmF0aW9uIFRlbXBsYXRlPC9oMz5cbiAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICBpZD1cInByb2JsZW0tc3RhdGVtZW50LXRlbXBsYXRlLWVkaXRvclwiXG4gICAgICAgICAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiXG4gICAgICAgICAgICByb3dzPVwiMjVcIlxuICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJwcm9ibGVtU3RhdGVtZW50R2VuZXJhdGlvblRlbXBsYXRlQ29udGVudFwiXG4gICAgICAgICAgICAoY2hhbmdlKT1cIm9uVGVtcGxhdGVDaGFuZ2VkKClcIlxuICAgICAgICAgICAgW2Rpc2FibGVkXT1cIiFzdWJTZXR0aW5ncz8ucHJvYmxlbVN0YXRlbWVudEdlbmVyYXRpb25UZW1wbGF0ZVwiXG4gICAgICAgID48L3RleHRhcmVhPlxuICAgIDwvZGl2PlxuICAgIDxkaXY+XG4gICAgICAgIDxoMyBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3Muc3ViU2V0dGluZ3MuY29kZUVkaXRvci50ZW1wbGF0ZVJlcG9UZW1wbGF0ZVwiPlRlbXBsYXRlIFJlcG8gR2VuZXJhdGlvbiBUZW1wbGF0ZTwvaDM+XG4gICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgaWQ9XCJ0ZW1wbGF0ZS1yZXBvLXRlbXBsYXRlLWVkaXRvclwiXG4gICAgICAgICAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiXG4gICAgICAgICAgICByb3dzPVwiMjVcIlxuICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJ0ZW1wbGF0ZVJlcG9HZW5lcmF0aW9uVGVtcGxhdGVDb250ZW50XCJcbiAgICAgICAgICAgIChjaGFuZ2UpPVwib25UZW1wbGF0ZUNoYW5nZWQoKVwiXG4gICAgICAgICAgICBbZGlzYWJsZWRdPVwiIXN1YlNldHRpbmdzPy50ZW1wbGF0ZVJlcG9HZW5lcmF0aW9uVGVtcGxhdGVcIlxuICAgICAgICA+PC90ZXh0YXJlYT5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2PlxuICAgICAgICA8aDMgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLnN1YlNldHRpbmdzLmNvZGVFZGl0b3Iuc29sdXRpb25SZXBvVGVtcGxhdGVcIj5Tb2x1dGlvbiBSZXBvIEdlbmVyYXRpb24gVGVtcGxhdGU8L2gzPlxuICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgIGlkPVwic29sdXRpb24tcmVwby10ZW1wbGF0ZS1lZGl0b3JcIlxuICAgICAgICAgICAgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIlxuICAgICAgICAgICAgcm93cz1cIjI1XCJcbiAgICAgICAgICAgIFsobmdNb2RlbCldPVwic29sdXRpb25SZXBvR2VuZXJhdGlvblRlbXBsYXRlQ29udGVudFwiXG4gICAgICAgICAgICAoY2hhbmdlKT1cIm9uVGVtcGxhdGVDaGFuZ2VkKClcIlxuICAgICAgICAgICAgW2Rpc2FibGVkXT1cIiFzdWJTZXR0aW5ncz8uc29sdXRpb25SZXBvR2VuZXJhdGlvblRlbXBsYXRlXCJcbiAgICAgICAgPjwvdGV4dGFyZWE+XG4gICAgPC9kaXY+XG4gICAgPGRpdj5cbiAgICAgICAgPGgzIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuaXJpcy5zZXR0aW5ncy5zdWJTZXR0aW5ncy5jb2RlRWRpdG9yLnRlc3RSZXBvVGVtcGxhdGVcIj5UZXN0IFJlcG8gR2VuZXJhdGlvbiBUZW1wbGF0ZTwvaDM+XG4gICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgaWQ9XCJ0ZXN0LXJlcG8tdGVtcGxhdGUtZWRpdG9yXCJcbiAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCJcbiAgICAgICAgICAgIHJvd3M9XCIyNVwiXG4gICAgICAgICAgICBbKG5nTW9kZWwpXT1cInRlc3RSZXBvR2VuZXJhdGlvblRlbXBsYXRlQ29udGVudFwiXG4gICAgICAgICAgICAoY2hhbmdlKT1cIm9uVGVtcGxhdGVDaGFuZ2VkKClcIlxuICAgICAgICAgICAgW2Rpc2FibGVkXT1cIiFzdWJTZXR0aW5ncz8udGVzdFJlcG9HZW5lcmF0aW9uVGVtcGxhdGVcIlxuICAgICAgICA+PC90ZXh0YXJlYT5cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBEb0NoZWNrLCBJbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJcmlzU2V0dGluZ3MsIElyaXNTZXR0aW5nc1R5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9zZXR0aW5ncy9pcmlzLXNldHRpbmdzLm1vZGVsJztcbmltcG9ydCB7IElyaXNTZXR0aW5nc1NlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9zZXR0aW5ncy9zaGFyZWQvaXJpcy1zZXR0aW5ncy5zZXJ2aWNlJztcbmltcG9ydCB7IEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5pbXBvcnQgeyBCdXR0b25UeXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL2J1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgZmFSb3RhdGUsIGZhU2F2ZSB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBJcmlzTW9kZWwgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9zZXR0aW5ncy9pcmlzLW1vZGVsJztcbmltcG9ydCB7IENvbXBvbmVudENhbkRlYWN0aXZhdGUgfSBmcm9tICdhcHAvc2hhcmVkL2d1YXJkL2Nhbi1kZWFjdGl2YXRlLm1vZGVsJztcbmltcG9ydCB7IGNsb25lRGVlcCwgaXNFcXVhbCB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBJcmlzQ2hhdFN1YlNldHRpbmdzLCBJcmlzQ29kZUVkaXRvclN1YlNldHRpbmdzLCBJcmlzSGVzdGlhU3ViU2V0dGluZ3MgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9zZXR0aW5ncy9pcmlzLXN1Yi1zZXR0aW5ncy5tb2RlbCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWlyaXMtc2V0dGluZ3MtdXBkYXRlJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vaXJpcy1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBJcmlzU2V0dGluZ3NVcGRhdGVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIERvQ2hlY2ssIENvbXBvbmVudENhbkRlYWN0aXZhdGUge1xuICAgIEBJbnB1dCgpXG4gICAgcHVibGljIHNldHRpbmdzVHlwZTogSXJpc1NldHRpbmdzVHlwZTtcbiAgICBASW5wdXQoKVxuICAgIHB1YmxpYyBjb3Vyc2VJZD86IG51bWJlcjtcbiAgICBASW5wdXQoKVxuICAgIHB1YmxpYyBleGVyY2lzZUlkPzogbnVtYmVyO1xuXG4gICAgcHVibGljIGlyaXNTZXR0aW5ncz86IElyaXNTZXR0aW5ncztcbiAgICBwdWJsaWMgcGFyZW50SXJpc1NldHRpbmdzPzogSXJpc1NldHRpbmdzO1xuICAgIHB1YmxpYyBhbGxJcmlzTW9kZWxzPzogSXJpc01vZGVsW107XG5cbiAgICBvcmlnaW5hbElyaXNTZXR0aW5ncz86IElyaXNTZXR0aW5ncztcblxuICAgIC8vIFN0YXR1cyBib29sc1xuICAgIGlzTG9hZGluZyA9IGZhbHNlO1xuICAgIGlzU2F2aW5nID0gZmFsc2U7XG4gICAgaXNEaXJ0eSA9IGZhbHNlO1xuICAgIC8vIEJ1dHRvbiB0eXBlc1xuICAgIFBSSU1BUlkgPSBCdXR0b25UeXBlLlBSSU1BUlk7XG4gICAgV0FSTklORyA9IEJ1dHRvblR5cGUuV0FSTklORztcbiAgICBTVUNDRVNTID0gQnV0dG9uVHlwZS5TVUNDRVNTO1xuICAgIC8vIEljb25zXG4gICAgZmFTYXZlID0gZmFTYXZlO1xuICAgIGZhUm90YXRlID0gZmFSb3RhdGU7XG4gICAgLy8gU2V0dGluZ3MgdHlwZXNcbiAgICBHTE9CQUwgPSBJcmlzU2V0dGluZ3NUeXBlLkdMT0JBTDtcbiAgICBDT1VSU0UgPSBJcmlzU2V0dGluZ3NUeXBlLkNPVVJTRTtcbiAgICBFWEVSQ0lTRSA9IElyaXNTZXR0aW5nc1R5cGUuRVhFUkNJU0U7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBpcmlzU2V0dGluZ3NTZXJ2aWNlOiBJcmlzU2V0dGluZ3NTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFsZXJ0U2VydmljZTogQWxlcnRTZXJ2aWNlLFxuICAgICkge31cblxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICB0aGlzLmxvYWRJcmlzU2V0dGluZ3MoKTtcbiAgICB9XG5cbiAgICBuZ0RvQ2hlY2soKTogdm9pZCB7XG4gICAgICAgIGlmICghaXNFcXVhbCh0aGlzLmlyaXNTZXR0aW5ncywgdGhpcy5vcmlnaW5hbElyaXNTZXR0aW5ncykpIHtcbiAgICAgICAgICAgIHRoaXMuaXNEaXJ0eSA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBjYW5EZWFjdGl2YXRlV2FybmluZz86IHN0cmluZztcblxuICAgIGNhbkRlYWN0aXZhdGUoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiAhdGhpcy5pc0RpcnR5O1xuICAgIH1cblxuICAgIGxvYWRJcmlzTW9kZWxzKCk6IHZvaWQge1xuICAgICAgICB0aGlzLmlyaXNTZXR0aW5nc1NlcnZpY2UuZ2V0SXJpc01vZGVscygpLnN1YnNjcmliZSgobW9kZWxzKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmFsbElyaXNNb2RlbHMgPSBtb2RlbHM7XG4gICAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBsb2FkSXJpc1NldHRpbmdzKCk6IHZvaWQge1xuICAgICAgICB0aGlzLmlzTG9hZGluZyA9IHRydWU7XG4gICAgICAgIHRoaXMubG9hZElyaXNTZXR0aW5nc09ic2VydmFibGUoKS5zdWJzY3JpYmUoKHNldHRpbmdzKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmxvYWRJcmlzTW9kZWxzKCk7XG4gICAgICAgICAgICBpZiAoIXNldHRpbmdzKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5hbGVydFNlcnZpY2UuZXJyb3IoJ2FydGVtaXNBcHAuaXJpcy5zZXR0aW5ncy5lcnJvci5ub1NldHRpbmdzJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmlyaXNTZXR0aW5ncyA9IHNldHRpbmdzO1xuICAgICAgICAgICAgdGhpcy5maWxsRW1wdHlJcmlzU3ViU2V0dGluZ3MoKTtcbiAgICAgICAgICAgIHRoaXMub3JpZ2luYWxJcmlzU2V0dGluZ3MgPSBjbG9uZURlZXAoc2V0dGluZ3MpO1xuICAgICAgICAgICAgdGhpcy5pc0RpcnR5ID0gZmFsc2U7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmxvYWRQYXJlbnRJcmlzU2V0dGluZ3NPYnNlcnZhYmxlKCkuc3Vic2NyaWJlKChzZXR0aW5ncykgPT4ge1xuICAgICAgICAgICAgaWYgKCFzZXR0aW5ncykge1xuICAgICAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLmVycm9yKCdhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3MuZXJyb3Iubm9QYXJlbnRTZXR0aW5ncycpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5wYXJlbnRJcmlzU2V0dGluZ3MgPSBzZXR0aW5ncztcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgZmlsbEVtcHR5SXJpc1N1YlNldHRpbmdzKCk6IHZvaWQge1xuICAgICAgICBpZiAoIXRoaXMuaXJpc1NldHRpbmdzKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLmlyaXNTZXR0aW5ncy5pcmlzQ2hhdFNldHRpbmdzKSB7XG4gICAgICAgICAgICB0aGlzLmlyaXNTZXR0aW5ncy5pcmlzQ2hhdFNldHRpbmdzID0gbmV3IElyaXNDaGF0U3ViU2V0dGluZ3MoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuaXJpc1NldHRpbmdzLmlyaXNIZXN0aWFTZXR0aW5ncykge1xuICAgICAgICAgICAgdGhpcy5pcmlzU2V0dGluZ3MuaXJpc0hlc3RpYVNldHRpbmdzID0gbmV3IElyaXNIZXN0aWFTdWJTZXR0aW5ncygpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5pcmlzU2V0dGluZ3MuaXJpc0NvZGVFZGl0b3JTZXR0aW5ncykge1xuICAgICAgICAgICAgdGhpcy5pcmlzU2V0dGluZ3MuaXJpc0NvZGVFZGl0b3JTZXR0aW5ncyA9IG5ldyBJcmlzQ29kZUVkaXRvclN1YlNldHRpbmdzKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBzYXZlSXJpc1NldHRpbmdzKCk6IHZvaWQge1xuICAgICAgICB0aGlzLmlzU2F2aW5nID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5zYXZlSXJpc1NldHRpbmdzT2JzZXJ2YWJsZSgpLnN1YnNjcmliZShcbiAgICAgICAgICAgIChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuaXNTYXZpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLmlzRGlydHkgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLmlyaXNTZXR0aW5ncyA9IHJlc3BvbnNlLmJvZHkgPz8gdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIHRoaXMuZmlsbEVtcHR5SXJpc1N1YlNldHRpbmdzKCk7XG4gICAgICAgICAgICAgICAgdGhpcy5vcmlnaW5hbElyaXNTZXR0aW5ncyA9IGNsb25lRGVlcCh0aGlzLmlyaXNTZXR0aW5ncyk7XG4gICAgICAgICAgICAgICAgdGhpcy5hbGVydFNlcnZpY2Uuc3VjY2VzcygnYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLnN1Y2Nlc3MnKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5pc1NhdmluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLmVycm9yKCdhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3MuZXJyb3Iuc2F2ZScpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBsb2FkUGFyZW50SXJpc1NldHRpbmdzT2JzZXJ2YWJsZSgpOiBPYnNlcnZhYmxlPElyaXNTZXR0aW5ncyB8IHVuZGVmaW5lZD4ge1xuICAgICAgICBzd2l0Y2ggKHRoaXMuc2V0dGluZ3NUeXBlKSB7XG4gICAgICAgICAgICBjYXNlIElyaXNTZXR0aW5nc1R5cGUuR0xPQkFMOlxuICAgICAgICAgICAgICAgIC8vIEdsb2JhbCBzZXR0aW5ncyBoYXZlIG5vIHBhcmVudFxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxJcmlzU2V0dGluZ3MgfCB1bmRlZmluZWQ+KCk7XG4gICAgICAgICAgICBjYXNlIElyaXNTZXR0aW5nc1R5cGUuQ09VUlNFOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmlyaXNTZXR0aW5nc1NlcnZpY2UuZ2V0R2xvYmFsU2V0dGluZ3MoKTtcbiAgICAgICAgICAgIGNhc2UgSXJpc1NldHRpbmdzVHlwZS5FWEVSQ0lTRTpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5pcmlzU2V0dGluZ3NTZXJ2aWNlLmdldENvbWJpbmVkQ291cnNlU2V0dGluZ3ModGhpcy5jb3Vyc2VJZCEpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbG9hZElyaXNTZXR0aW5nc09ic2VydmFibGUoKTogT2JzZXJ2YWJsZTxJcmlzU2V0dGluZ3MgfCB1bmRlZmluZWQ+IHtcbiAgICAgICAgc3dpdGNoICh0aGlzLnNldHRpbmdzVHlwZSkge1xuICAgICAgICAgICAgY2FzZSBJcmlzU2V0dGluZ3NUeXBlLkdMT0JBTDpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5pcmlzU2V0dGluZ3NTZXJ2aWNlLmdldEdsb2JhbFNldHRpbmdzKCk7XG4gICAgICAgICAgICBjYXNlIElyaXNTZXR0aW5nc1R5cGUuQ09VUlNFOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmlyaXNTZXR0aW5nc1NlcnZpY2UuZ2V0VW5jb21iaW5lZENvdXJzZVNldHRpbmdzKHRoaXMuY291cnNlSWQhKTtcbiAgICAgICAgICAgIGNhc2UgSXJpc1NldHRpbmdzVHlwZS5FWEVSQ0lTRTpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5pcmlzU2V0dGluZ3NTZXJ2aWNlLmdldFVuY29tYmluZWRQcm9ncmFtbWluZ0V4ZXJjaXNlU2V0dGluZ3ModGhpcy5leGVyY2lzZUlkISk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBzYXZlSXJpc1NldHRpbmdzT2JzZXJ2YWJsZSgpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxJcmlzU2V0dGluZ3MgfCB1bmRlZmluZWQ+PiB7XG4gICAgICAgIHN3aXRjaCAodGhpcy5zZXR0aW5nc1R5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgSXJpc1NldHRpbmdzVHlwZS5HTE9CQUw6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuaXJpc1NldHRpbmdzU2VydmljZS5zZXRHbG9iYWxTZXR0aW5ncyh0aGlzLmlyaXNTZXR0aW5ncyEpO1xuICAgICAgICAgICAgY2FzZSBJcmlzU2V0dGluZ3NUeXBlLkNPVVJTRTpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5pcmlzU2V0dGluZ3NTZXJ2aWNlLnNldENvdXJzZVNldHRpbmdzKHRoaXMuY291cnNlSWQhLCB0aGlzLmlyaXNTZXR0aW5ncyEpO1xuICAgICAgICAgICAgY2FzZSBJcmlzU2V0dGluZ3NUeXBlLkVYRVJDSVNFOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmlyaXNTZXR0aW5nc1NlcnZpY2Uuc2V0UHJvZ3JhbW1pbmdFeGVyY2lzZVNldHRpbmdzKHRoaXMuZXhlcmNpc2VJZCEsIHRoaXMuaXJpc1NldHRpbmdzISk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCI8ZGl2PlxuICAgIDxqaGktYnV0dG9uXG4gICAgICAgIGlkPVwicmVsb2FkXCJcbiAgICAgICAgW2J0blR5cGVdPVwiaXNEaXJ0eSA/IFdBUk5JTkcgOiBQUklNQVJZXCJcbiAgICAgICAgW2lzTG9hZGluZ109XCJpc0xvYWRpbmdcIlxuICAgICAgICBbaWNvbl09XCJmYVJvdGF0ZVwiXG4gICAgICAgIFt0aXRsZV09XCInYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLmJ1dHRvbi5yZWxvYWQnXCJcbiAgICAgICAgKG9uQ2xpY2spPVwibG9hZElyaXNTZXR0aW5ncygpXCJcbiAgICA+XG4gICAgPC9qaGktYnV0dG9uPlxuICAgIDxqaGktYnV0dG9uIGlkPVwic2F2ZVwiIFtidG5UeXBlXT1cIlNVQ0NFU1NcIiBbaXNMb2FkaW5nXT1cImlzU2F2aW5nXCIgW2ljb25dPVwiZmFTYXZlXCIgW3RpdGxlXT1cIidhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3MuYnV0dG9uLnNhdmUnXCIgKG9uQ2xpY2spPVwic2F2ZUlyaXNTZXR0aW5ncygpXCI+PC9qaGktYnV0dG9uPlxuPC9kaXY+XG5AaWYgKGlyaXNTZXR0aW5ncykge1xuICAgIDxkaXY+XG4gICAgICAgIEBpZiAoc2V0dGluZ3NUeXBlID09PSBHTE9CQUwpIHtcbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuaXJpcy5zZXR0aW5ncy5hdXRvVXBkYXRlLnRpdGxlXCI+QXV0by1VcGRhdGUgU2V0dGluZ3M8L2gzPlxuICAgICAgICAgICAgICAgIDxqaGktaXJpcy1nbG9iYWwtYXV0b3VwZGF0ZS1zZXR0aW5ncy11cGRhdGUgW2lyaXNTZXR0aW5nc109XCJpcmlzU2V0dGluZ3NcIiAob25DaGFuZ2VzKT1cImlzRGlydHkgPSB0cnVlXCI+PC9qaGktaXJpcy1nbG9iYWwtYXV0b3VwZGF0ZS1zZXR0aW5ncy11cGRhdGU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgICA8aDMgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLnN1YlNldHRpbmdzLmNoYXRTZXR0aW5nc1wiPkNoYXQgU2V0dGluZ3M8L2gzPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGpoaS1pcmlzLWNvbW1vbi1zdWItc2V0dGluZ3MtdXBkYXRlXG4gICAgICAgICAgICAgICAgW3N1YlNldHRpbmdzXT1cImlyaXNTZXR0aW5ncz8uaXJpc0NoYXRTZXR0aW5nc1wiXG4gICAgICAgICAgICAgICAgW3BhcmVudFN1YlNldHRpbmdzXT1cInBhcmVudElyaXNTZXR0aW5ncz8uaXJpc0NoYXRTZXR0aW5nc1wiXG4gICAgICAgICAgICAgICAgW2FsbElyaXNNb2RlbHNdPVwiYWxsSXJpc01vZGVscyA/PyBbXVwiXG4gICAgICAgICAgICAgICAgW3NldHRpbmdzVHlwZV09XCJzZXR0aW5nc1R5cGVcIlxuICAgICAgICAgICAgICAgIChvbkNoYW5nZXMpPVwiaXNEaXJ0eSA9IHRydWVcIlxuICAgICAgICAgICAgPjwvamhpLWlyaXMtY29tbW9uLXN1Yi1zZXR0aW5ncy11cGRhdGU+XG4gICAgICAgICAgICA8amhpLWlyaXMtY2hhdC1zdWItc2V0dGluZ3MtdXBkYXRlXG4gICAgICAgICAgICAgICAgW3N1YlNldHRpbmdzXT1cImlyaXNTZXR0aW5ncz8uaXJpc0NoYXRTZXR0aW5nc1wiXG4gICAgICAgICAgICAgICAgW3BhcmVudFN1YlNldHRpbmdzXT1cInBhcmVudElyaXNTZXR0aW5ncz8uaXJpc0NoYXRTZXR0aW5nc1wiXG4gICAgICAgICAgICAgICAgW3JhdGVMaW1pdFNldHRhYmxlXT1cInNldHRpbmdzVHlwZSA9PT0gR0xPQkFMXCJcbiAgICAgICAgICAgICAgICAob25DaGFuZ2VzKT1cImlzRGlydHkgPSB0cnVlXCJcbiAgICAgICAgICAgID48L2poaS1pcmlzLWNoYXQtc3ViLXNldHRpbmdzLXVwZGF0ZT5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIEBpZiAoc2V0dGluZ3NUeXBlICE9PSBFWEVSQ0lTRSkge1xuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aHIgY2xhc3M9XCJoclwiIC8+XG4gICAgICAgICAgICAgICAgPGgzIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuaXJpcy5zZXR0aW5ncy5zdWJTZXR0aW5ncy5oZXN0aWFTZXR0aW5nc1wiPkhlc3RpYSBTZXR0aW5nczwvaDM+XG4gICAgICAgICAgICAgICAgPGpoaS1pcmlzLWNvbW1vbi1zdWItc2V0dGluZ3MtdXBkYXRlXG4gICAgICAgICAgICAgICAgICAgIFtzdWJTZXR0aW5nc109XCJpcmlzU2V0dGluZ3M/LmlyaXNIZXN0aWFTZXR0aW5ncyFcIlxuICAgICAgICAgICAgICAgICAgICBbcGFyZW50U3ViU2V0dGluZ3NdPVwicGFyZW50SXJpc1NldHRpbmdzPy5pcmlzSGVzdGlhU2V0dGluZ3NcIlxuICAgICAgICAgICAgICAgICAgICBbYWxsSXJpc01vZGVsc109XCJhbGxJcmlzTW9kZWxzID8/IFtdXCJcbiAgICAgICAgICAgICAgICAgICAgW3NldHRpbmdzVHlwZV09XCJzZXR0aW5nc1R5cGVcIlxuICAgICAgICAgICAgICAgICAgICAob25DaGFuZ2VzKT1cImlzRGlydHkgPSB0cnVlXCJcbiAgICAgICAgICAgICAgICA+PC9qaGktaXJpcy1jb21tb24tc3ViLXNldHRpbmdzLXVwZGF0ZT5cbiAgICAgICAgICAgICAgICA8amhpLWlyaXMtaGVzdGlhLXN1Yi1zZXR0aW5ncy11cGRhdGVcbiAgICAgICAgICAgICAgICAgICAgW3N1YlNldHRpbmdzXT1cImlyaXNTZXR0aW5ncz8uaXJpc0hlc3RpYVNldHRpbmdzIVwiXG4gICAgICAgICAgICAgICAgICAgIFtwYXJlbnRTdWJTZXR0aW5nc109XCJwYXJlbnRJcmlzU2V0dGluZ3M/LmlyaXNIZXN0aWFTZXR0aW5nc1wiXG4gICAgICAgICAgICAgICAgICAgIChvbkNoYW5nZXMpPVwiaXNEaXJ0eSA9IHRydWVcIlxuICAgICAgICAgICAgICAgID48L2poaS1pcmlzLWhlc3RpYS1zdWItc2V0dGluZ3MtdXBkYXRlPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChzZXR0aW5nc1R5cGUgIT09IEVYRVJDSVNFKSB7XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxociBjbGFzcz1cImhyXCIgLz5cbiAgICAgICAgICAgICAgICA8aDMgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLnN1YlNldHRpbmdzLmNvZGVFZGl0b3JTZXR0aW5nc1wiPkNvZGUgRWRpdG9yIFNldHRpbmdzPC9oMz5cbiAgICAgICAgICAgICAgICA8amhpLWlyaXMtY29tbW9uLXN1Yi1zZXR0aW5ncy11cGRhdGVcbiAgICAgICAgICAgICAgICAgICAgW3N1YlNldHRpbmdzXT1cImlyaXNTZXR0aW5ncz8uaXJpc0NvZGVFZGl0b3JTZXR0aW5nc1wiXG4gICAgICAgICAgICAgICAgICAgIFtwYXJlbnRTdWJTZXR0aW5nc109XCJwYXJlbnRJcmlzU2V0dGluZ3M/LmlyaXNDb2RlRWRpdG9yU2V0dGluZ3NcIlxuICAgICAgICAgICAgICAgICAgICBbYWxsSXJpc01vZGVsc109XCJhbGxJcmlzTW9kZWxzID8/IFtdXCJcbiAgICAgICAgICAgICAgICAgICAgW3NldHRpbmdzVHlwZV09XCJzZXR0aW5nc1R5cGVcIlxuICAgICAgICAgICAgICAgICAgICAob25DaGFuZ2VzKT1cImlzRGlydHkgPSB0cnVlXCJcbiAgICAgICAgICAgICAgICA+PC9qaGktaXJpcy1jb21tb24tc3ViLXNldHRpbmdzLXVwZGF0ZT5cbiAgICAgICAgICAgICAgICA8amhpLWlyaXMtY29kZS1lZGl0b3Itc3ViLXNldHRpbmdzLXVwZGF0ZVxuICAgICAgICAgICAgICAgICAgICBbc3ViU2V0dGluZ3NdPVwiaXJpc1NldHRpbmdzPy5pcmlzQ29kZUVkaXRvclNldHRpbmdzXCJcbiAgICAgICAgICAgICAgICAgICAgW3BhcmVudFN1YlNldHRpbmdzXT1cInBhcmVudElyaXNTZXR0aW5ncz8uaXJpc0NvZGVFZGl0b3JTZXR0aW5nc1wiXG4gICAgICAgICAgICAgICAgICAgIChvbkNoYW5nZXMpPVwiaXNEaXJ0eSA9IHRydWVcIlxuICAgICAgICAgICAgICAgID48L2poaS1pcmlzLWNvZGUtZWRpdG9yLXN1Yi1zZXR0aW5ncy11cGRhdGU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgIDwvZGl2PlxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBWaWV3Q2hpbGQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IElyaXNTZXR0aW5nc1R5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9zZXR0aW5ncy9pcmlzLXNldHRpbmdzLm1vZGVsJztcbmltcG9ydCB7IENvbXBvbmVudENhbkRlYWN0aXZhdGUgfSBmcm9tICdhcHAvc2hhcmVkL2d1YXJkL2Nhbi1kZWFjdGl2YXRlLm1vZGVsJztcbmltcG9ydCB7IElyaXNTZXR0aW5nc1VwZGF0ZUNvbXBvbmVudCB9IGZyb20gJ2FwcC9pcmlzL3NldHRpbmdzL2lyaXMtc2V0dGluZ3MtdXBkYXRlL2lyaXMtc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWlyaXMtZ2xvYmFsLXNldHRpbmdzLXVwZGF0ZScsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2lyaXMtZ2xvYmFsLXNldHRpbmdzLXVwZGF0ZS5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIElyaXNHbG9iYWxTZXR0aW5nc1VwZGF0ZUNvbXBvbmVudCBpbXBsZW1lbnRzIENvbXBvbmVudENhbkRlYWN0aXZhdGUge1xuICAgIEBWaWV3Q2hpbGQoSXJpc1NldHRpbmdzVXBkYXRlQ29tcG9uZW50KVxuICAgIHNldHRpbmdzVXBkYXRlQ29tcG9uZW50PzogSXJpc1NldHRpbmdzVXBkYXRlQ29tcG9uZW50O1xuXG4gICAgR0xPQkFMID0gSXJpc1NldHRpbmdzVHlwZS5HTE9CQUw7XG5cbiAgICBjYW5EZWFjdGl2YXRlKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5nc1VwZGF0ZUNvbXBvbmVudD8uY2FuRGVhY3RpdmF0ZSgpID8/IHRydWU7XG4gICAgfVxuXG4gICAgZ2V0IGNhbkRlYWN0aXZhdGVXYXJuaW5nKCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzVXBkYXRlQ29tcG9uZW50Py5jYW5EZWFjdGl2YXRlV2FybmluZztcbiAgICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwiY29udGFpbmVyXCI+XG4gICAgPGgyIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuaXJpcy5zZXR0aW5ncy50aXRsZS5nbG9iYWxcIj5HbG9iYWwgSXJpcyBTZXR0aW5nczwvaDI+XG4gICAgPGpoaS1pcmlzLXNldHRpbmdzLXVwZGF0ZSBbc2V0dGluZ3NUeXBlXT1cIkdMT0JBTFwiPjwvamhpLWlyaXMtc2V0dGluZ3MtdXBkYXRlPlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQsIFZpZXdDaGlsZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgSXJpc1NldHRpbmdzVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL3NldHRpbmdzL2lyaXMtc2V0dGluZ3MubW9kZWwnO1xuaW1wb3J0IHsgQ29tcG9uZW50Q2FuRGVhY3RpdmF0ZSB9IGZyb20gJ2FwcC9zaGFyZWQvZ3VhcmQvY2FuLWRlYWN0aXZhdGUubW9kZWwnO1xuaW1wb3J0IHsgSXJpc1NldHRpbmdzVXBkYXRlQ29tcG9uZW50IH0gZnJvbSAnYXBwL2lyaXMvc2V0dGluZ3MvaXJpcy1zZXR0aW5ncy11cGRhdGUvaXJpcy1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktaXJpcy1jb3Vyc2Utc2V0dGluZ3MtdXBkYXRlJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vaXJpcy1jb3Vyc2Utc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgSXJpc0NvdXJzZVNldHRpbmdzVXBkYXRlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBDb21wb25lbnRDYW5EZWFjdGl2YXRlIHtcbiAgICBAVmlld0NoaWxkKElyaXNTZXR0aW5nc1VwZGF0ZUNvbXBvbmVudClcbiAgICBzZXR0aW5nc1VwZGF0ZUNvbXBvbmVudD86IElyaXNTZXR0aW5nc1VwZGF0ZUNvbXBvbmVudDtcblxuICAgIEBJbnB1dCgpXG4gICAgY291cnNlSWQ/OiBudW1iZXI7XG5cbiAgICBDT1VSU0UgPSBJcmlzU2V0dGluZ3NUeXBlLkNPVVJTRTtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMucm91dGUucGFyZW50Py5wYXJhbXMuc3Vic2NyaWJlKChwYXJhbXMpID0+IHtcbiAgICAgICAgICAgIHRoaXMuY291cnNlSWQgPSBOdW1iZXIocGFyYW1zWydjb3Vyc2VJZCddKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgY2FuRGVhY3RpdmF0ZSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3NVcGRhdGVDb21wb25lbnQ/LmNhbkRlYWN0aXZhdGUoKSA/PyB0cnVlO1xuICAgIH1cblxuICAgIGdldCBjYW5EZWFjdGl2YXRlV2FybmluZygpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5nc1VwZGF0ZUNvbXBvbmVudD8uY2FuRGVhY3RpdmF0ZVdhcm5pbmc7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cImNvbnRhaW5lclwiPlxuICAgIDxoMiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3MudGl0bGUuY291cnNlXCI+Q291cnNlIElyaXMgU2V0dGluZ3M8L2gyPlxuICAgIEBpZiAoY291cnNlSWQpIHtcbiAgICAgICAgPGpoaS1pcmlzLXNldHRpbmdzLXVwZGF0ZSBbc2V0dGluZ3NUeXBlXT1cIkNPVVJTRVwiIFtjb3Vyc2VJZF09XCJjb3Vyc2VJZCFcIj48L2poaS1pcmlzLXNldHRpbmdzLXVwZGF0ZT5cbiAgICB9XG48L2Rpdj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJcmlzU2V0dGluZ3NUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvc2V0dGluZ3MvaXJpcy1zZXR0aW5ncy5tb2RlbCc7XG5pbXBvcnQgeyBDb21wb25lbnRDYW5EZWFjdGl2YXRlIH0gZnJvbSAnYXBwL3NoYXJlZC9ndWFyZC9jYW4tZGVhY3RpdmF0ZS5tb2RlbCc7XG5pbXBvcnQgeyBJcmlzU2V0dGluZ3NVcGRhdGVDb21wb25lbnQgfSBmcm9tICdhcHAvaXJpcy9zZXR0aW5ncy9pcmlzLXNldHRpbmdzLXVwZGF0ZS9pcmlzLXNldHRpbmdzLXVwZGF0ZS5jb21wb25lbnQnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1pcmlzLWV4ZXJjaXNlLXNldHRpbmdzLXVwZGF0ZScsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2lyaXMtZXhlcmNpc2Utc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgSXJpc0V4ZXJjaXNlU2V0dGluZ3NVcGRhdGVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIENvbXBvbmVudENhbkRlYWN0aXZhdGUge1xuICAgIEBWaWV3Q2hpbGQoSXJpc1NldHRpbmdzVXBkYXRlQ29tcG9uZW50KVxuICAgIHNldHRpbmdzVXBkYXRlQ29tcG9uZW50PzogSXJpc1NldHRpbmdzVXBkYXRlQ29tcG9uZW50O1xuXG4gICAgQElucHV0KClcbiAgICBwdWJsaWMgY291cnNlSWQ/OiBudW1iZXI7XG4gICAgQElucHV0KClcbiAgICBwdWJsaWMgZXhlcmNpc2VJZD86IG51bWJlcjtcblxuICAgIEVYRVJDSVNFID0gSXJpc1NldHRpbmdzVHlwZS5FWEVSQ0lTRTtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMucm91dGUucGFyZW50Py5wYXJhbXMuc3Vic2NyaWJlKChwYXJhbXMpID0+IHtcbiAgICAgICAgICAgIHRoaXMuY291cnNlSWQgPSBOdW1iZXIocGFyYW1zWydjb3Vyc2VJZCddKTtcbiAgICAgICAgICAgIHRoaXMuZXhlcmNpc2VJZCA9IE51bWJlcihwYXJhbXNbJ2V4ZXJjaXNlSWQnXSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGNhbkRlYWN0aXZhdGUoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzVXBkYXRlQ29tcG9uZW50Py5jYW5EZWFjdGl2YXRlKCkgPz8gdHJ1ZTtcbiAgICB9XG5cbiAgICBnZXQgY2FuRGVhY3RpdmF0ZVdhcm5pbmcoKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3NVcGRhdGVDb21wb25lbnQ/LmNhbkRlYWN0aXZhdGVXYXJuaW5nO1xuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJjb250YWluZXJcIj5cbiAgICA8aDIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pcmlzLnNldHRpbmdzLnRpdGxlLmV4ZXJjaXNlXCI+RXhlcmNpc2UgSXJpcyBTZXR0aW5nczwvaDI+XG4gICAgQGlmIChjb3Vyc2VJZCAmJiBleGVyY2lzZUlkKSB7XG4gICAgICAgIDxqaGktaXJpcy1zZXR0aW5ncy11cGRhdGUgW3NldHRpbmdzVHlwZV09XCJFWEVSQ0lTRVwiIFtjb3Vyc2VJZF09XCJjb3Vyc2VJZFwiIFtleGVyY2lzZUlkXT1cImV4ZXJjaXNlSWQhXCI+PC9qaGktaXJpcy1zZXR0aW5ncy11cGRhdGU+XG4gICAgfVxuPC9kaXY+XG4iLCJleHBvcnQgZW51bSBJcmlzRXJyb3JNZXNzYWdlS2V5IHtcbiAgICBTRVNTSU9OX0xPQURfRkFJTEVEID0gJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LmVycm9ycy5zZXNzaW9uTG9hZEZhaWxlZCcsXG4gICAgU0VORF9NRVNTQUdFX0ZBSUxFRCA9ICdhcnRlbWlzQXBwLmV4ZXJjaXNlQ2hhdGJvdC5lcnJvcnMuc2VuZE1lc3NhZ2VGYWlsZWQnLFxuICAgIEhJU1RPUllfTE9BRF9GQUlMRUQgPSAnYXJ0ZW1pc0FwcC5leGVyY2lzZUNoYXRib3QuZXJyb3JzLmhpc3RvcnlMb2FkRmFpbGVkJyxcbiAgICBJTlZBTElEX1NFU1NJT05fU1RBVEUgPSAnYXJ0ZW1pc0FwcC5leGVyY2lzZUNoYXRib3QuZXJyb3JzLmludmFsaWRTZXNzaW9uU3RhdGUnLFxuICAgIFNFU1NJT05fQ1JFQVRJT05fRkFJTEVEID0gJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LmVycm9ycy5zZXNzaW9uQ3JlYXRpb25GYWlsZWQnLFxuICAgIFJBVEVfTUVTU0FHRV9GQUlMRUQgPSAnYXJ0ZW1pc0FwcC5leGVyY2lzZUNoYXRib3QuZXJyb3JzLnJhdGVNZXNzYWdlRmFpbGVkJyxcbiAgICBJUklTX0RJU0FCTEVEID0gJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LmVycm9ycy5pcmlzRGlzYWJsZWQnLFxuICAgIElSSVNfU0VSVkVSX1JFU1BPTlNFX1RJTUVPVVQgPSAnYXJ0ZW1pc0FwcC5leGVyY2lzZUNoYXRib3QuZXJyb3JzLnRpbWVvdXQnLFxuICAgIEVNUFRZX01FU1NBR0UgPSAnYXJ0ZW1pc0FwcC5leGVyY2lzZUNoYXRib3QuZXJyb3JzLmVtcHR5TWVzc2FnZScsXG4gICAgRk9SQklEREVOID0gJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LmVycm9ycy5mb3JiaWRkZW4nLFxuICAgIElOVEVSTkFMX1BZUklTX0VSUk9SID0gJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LmVycm9ycy5pbnRlcm5hbFB5cmlzRXJyb3InLFxuICAgIElOVkFMSURfVEVNUExBVEUgPSAnYXJ0ZW1pc0FwcC5leGVyY2lzZUNoYXRib3QuZXJyb3JzLmludmFsaWRUZW1wbGF0ZScsXG4gICAgTk9fTU9ERUxfQVZBSUxBQkxFID0gJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LmVycm9ycy5ub01vZGVsQXZhaWxhYmxlJyxcbiAgICBOT19SRVNQT05TRSA9ICdhcnRlbWlzQXBwLmV4ZXJjaXNlQ2hhdGJvdC5lcnJvcnMubm9SZXNwb25zZScsXG4gICAgUEFSU0VfUkVTUE9OU0UgPSAnYXJ0ZW1pc0FwcC5leGVyY2lzZUNoYXRib3QuZXJyb3JzLnBhcnNlUmVzcG9uc2UnLFxuICAgIFRFQ0hOSUNBTF9FUlJPUl9SRVNQT05TRSA9ICdhcnRlbWlzQXBwLmV4ZXJjaXNlQ2hhdGJvdC5lcnJvcnMudGVjaG5pY2FsRXJyb3InLFxuICAgIElSSVNfTk9UX0FWQUlMQUJMRSA9ICdhcnRlbWlzQXBwLmV4ZXJjaXNlQ2hhdGJvdC5lcnJvcnMuaXJpc05vdEF2YWlsYWJsZScsXG4gICAgUkFURV9MSU1JVF9FWENFRURFRCA9ICdhcnRlbWlzQXBwLmV4ZXJjaXNlQ2hhdGJvdC5lcnJvcnMucmF0ZUxpbWl0RXhjZWVkZWQnLFxufVxuXG5leHBvcnQgaW50ZXJmYWNlIElyaXNFcnJvclR5cGUge1xuICAgIGtleTogSXJpc0Vycm9yTWVzc2FnZUtleTtcbiAgICBmYXRhbDogYm9vbGVhbjtcbiAgICBwYXJhbXNNYXA/OiBNYXA8c3RyaW5nLCBhbnk+O1xufVxuXG5jb25zdCBJcmlzRXJyb3JzOiBJcmlzRXJyb3JUeXBlW10gPSBbXG4gICAgeyBrZXk6IElyaXNFcnJvck1lc3NhZ2VLZXkuU0VTU0lPTl9MT0FEX0ZBSUxFRCwgZmF0YWw6IHRydWUgfSxcbiAgICB7IGtleTogSXJpc0Vycm9yTWVzc2FnZUtleS5TRU5EX01FU1NBR0VfRkFJTEVELCBmYXRhbDogZmFsc2UgfSxcbiAgICB7IGtleTogSXJpc0Vycm9yTWVzc2FnZUtleS5ISVNUT1JZX0xPQURfRkFJTEVELCBmYXRhbDogdHJ1ZSB9LFxuICAgIHsga2V5OiBJcmlzRXJyb3JNZXNzYWdlS2V5LklOVkFMSURfU0VTU0lPTl9TVEFURSwgZmF0YWw6IHRydWUgfSxcbiAgICB7IGtleTogSXJpc0Vycm9yTWVzc2FnZUtleS5TRVNTSU9OX0NSRUFUSU9OX0ZBSUxFRCwgZmF0YWw6IHRydWUgfSxcbiAgICB7IGtleTogSXJpc0Vycm9yTWVzc2FnZUtleS5SQVRFX01FU1NBR0VfRkFJTEVELCBmYXRhbDogZmFsc2UgfSxcbiAgICB7IGtleTogSXJpc0Vycm9yTWVzc2FnZUtleS5JUklTX0RJU0FCTEVELCBmYXRhbDogdHJ1ZSB9LFxuICAgIHsga2V5OiBJcmlzRXJyb3JNZXNzYWdlS2V5LklSSVNfU0VSVkVSX1JFU1BPTlNFX1RJTUVPVVQsIGZhdGFsOiBmYWxzZSB9LFxuICAgIHsga2V5OiBJcmlzRXJyb3JNZXNzYWdlS2V5LkVNUFRZX01FU1NBR0UsIGZhdGFsOiBmYWxzZSB9LFxuICAgIHsga2V5OiBJcmlzRXJyb3JNZXNzYWdlS2V5LklOVEVSTkFMX1BZUklTX0VSUk9SLCBmYXRhbDogdHJ1ZSB9LFxuICAgIHsga2V5OiBJcmlzRXJyb3JNZXNzYWdlS2V5LklOVkFMSURfVEVNUExBVEUsIGZhdGFsOiB0cnVlIH0sXG4gICAgeyBrZXk6IElyaXNFcnJvck1lc3NhZ2VLZXkuTk9fTU9ERUxfQVZBSUxBQkxFLCBmYXRhbDogdHJ1ZSB9LFxuICAgIHsga2V5OiBJcmlzRXJyb3JNZXNzYWdlS2V5Lk5PX1JFU1BPTlNFLCBmYXRhbDogdHJ1ZSB9LFxuICAgIHsga2V5OiBJcmlzRXJyb3JNZXNzYWdlS2V5LlBBUlNFX1JFU1BPTlNFLCBmYXRhbDogdHJ1ZSB9LFxuICAgIHsga2V5OiBJcmlzRXJyb3JNZXNzYWdlS2V5LkZPUkJJRERFTiwgZmF0YWw6IHRydWUgfSxcbiAgICB7IGtleTogSXJpc0Vycm9yTWVzc2FnZUtleS5URUNITklDQUxfRVJST1JfUkVTUE9OU0UsIGZhdGFsOiB0cnVlIH0sXG4gICAgeyBrZXk6IElyaXNFcnJvck1lc3NhZ2VLZXkuSVJJU19OT1RfQVZBSUxBQkxFLCBmYXRhbDogdHJ1ZSB9LFxuICAgIHsga2V5OiBJcmlzRXJyb3JNZXNzYWdlS2V5LlJBVEVfTElNSVRfRVhDRUVERUQsIGZhdGFsOiB0cnVlIH0sXG5dO1xuXG5leHBvcnQgY29uc3QgZXJyb3JNZXNzYWdlczogUmVhZG9ubHk8eyBba2V5IGluIElyaXNFcnJvck1lc3NhZ2VLZXldOiBJcmlzRXJyb3JUeXBlIH0+ID0gT2JqZWN0LmZyZWV6ZShcbiAgICBJcmlzRXJyb3JzLnJlZHVjZShcbiAgICAgICAgKG1hcCwgb2JqKSA9PiB7XG4gICAgICAgICAgICBtYXBbb2JqLmtleV0gPSBvYmo7XG4gICAgICAgICAgICByZXR1cm4gbWFwO1xuICAgICAgICB9LFxuICAgICAgICB7fSBhcyB7IFtrZXkgaW4gSXJpc0Vycm9yTWVzc2FnZUtleV06IElyaXNFcnJvclR5cGUgfSxcbiAgICApLFxuKTtcbiIsImltcG9ydCB7IElyaXNNZXNzYWdlLCBJcmlzU2VydmVyTWVzc2FnZSwgSXJpc1VzZXJNZXNzYWdlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvaXJpcy1tZXNzYWdlLm1vZGVsJztcbmltcG9ydCB7IElyaXNFcnJvck1lc3NhZ2VLZXksIElyaXNFcnJvclR5cGUsIGVycm9yTWVzc2FnZXMgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9pcmlzLWVycm9ycy5tb2RlbCc7XG5pbXBvcnQgeyBJcmlzUmF0ZUxpbWl0SW5mb3JtYXRpb24gfSBmcm9tICdhcHAvaXJpcy93ZWJzb2NrZXQuc2VydmljZSc7XG5cbmV4cG9ydCBlbnVtIEFjdGlvblR5cGUge1xuICAgIE5VTV9ORVdfTUVTU0FHRVNfUkVTRVQgPSAnbnVtLW5ldy1tZXNzYWdlcy1yZXNldCcsXG4gICAgSElTVE9SWV9NRVNTQUdFX0xPQURFRCA9ICdoaXN0b3J5LW1lc3NhZ2UtbG9hZGVkJyxcbiAgICBBQ1RJVkVfQ09OVkVSU0FUSU9OX01FU1NBR0VfTE9BREVEID0gJ2FjdGl2ZS1jb252ZXJzYXRpb24tbWVzc2FnZS1sb2FkZWQnLFxuICAgIENPTlZFUlNBVElPTl9FUlJPUl9PQ0NVUlJFRCA9ICdjb252ZXJzYXRpb24tZXJyb3Itb2NjdXJyZWQnLFxuICAgIFNUVURFTlRfTUVTU0FHRV9TRU5UID0gJ3N0dWRlbnQtbWVzc2FnZS1zZW50JyxcbiAgICBTRVNTSU9OX0NIQU5HRUQgPSAnc2Vzc2lvbi1jaGFuZ2VkJyxcbiAgICBSQVRFX01FU1NBR0VfU1VDQ0VTUyA9ICdyYXRlLW1lc3NhZ2Utc3VjY2VzcycsXG4gICAgUkFURV9MSU1JVF9VUERBVEVEID0gJ3JhdGUtbGltaXQtdXBkYXRlZCcsXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWVzc2FnZVN0b3JlQWN0aW9uIHtcbiAgICB0eXBlOiBBY3Rpb25UeXBlO1xufVxuXG5leHBvcnQgY2xhc3MgTnVtTmV3TWVzc2FnZXNSZXNldEFjdGlvbiBpbXBsZW1lbnRzIE1lc3NhZ2VTdG9yZUFjdGlvbiB7XG4gICAgcmVhZG9ubHkgdHlwZTogQWN0aW9uVHlwZTtcblxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy50eXBlID0gQWN0aW9uVHlwZS5OVU1fTkVXX01FU1NBR0VTX1JFU0VUO1xuICAgIH1cbn1cblxuZXhwb3J0IGNsYXNzIEhpc3RvcnlNZXNzYWdlTG9hZGVkQWN0aW9uIGltcGxlbWVudHMgTWVzc2FnZVN0b3JlQWN0aW9uIHtcbiAgICByZWFkb25seSB0eXBlOiBBY3Rpb25UeXBlO1xuXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKHB1YmxpYyByZWFkb25seSBtZXNzYWdlOiBJcmlzU2VydmVyTWVzc2FnZSkge1xuICAgICAgICB0aGlzLnR5cGUgPSBBY3Rpb25UeXBlLkhJU1RPUllfTUVTU0FHRV9MT0FERUQ7XG4gICAgfVxufVxuXG5leHBvcnQgY2xhc3MgQWN0aXZlQ29udmVyc2F0aW9uTWVzc2FnZUxvYWRlZEFjdGlvbiBpbXBsZW1lbnRzIE1lc3NhZ2VTdG9yZUFjdGlvbiB7XG4gICAgcmVhZG9ubHkgdHlwZTogQWN0aW9uVHlwZTtcblxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihwdWJsaWMgcmVhZG9ubHkgbWVzc2FnZTogSXJpc01lc3NhZ2UpIHtcbiAgICAgICAgdGhpcy50eXBlID0gQWN0aW9uVHlwZS5BQ1RJVkVfQ09OVkVSU0FUSU9OX01FU1NBR0VfTE9BREVEO1xuICAgIH1cbn1cblxuZXhwb3J0IGNsYXNzIENvbnZlcnNhdGlvbkVycm9yT2NjdXJyZWRBY3Rpb24gaW1wbGVtZW50cyBNZXNzYWdlU3RvcmVBY3Rpb24ge1xuICAgIHJlYWRvbmx5IHR5cGU6IEFjdGlvblR5cGU7XG4gICAgcmVhZG9ubHkgZXJyb3JPYmplY3Q6IElyaXNFcnJvclR5cGUgfCBudWxsO1xuXG4gICAgY29uc3RydWN0b3IoZXJyb3JUeXBlOiBJcmlzRXJyb3JNZXNzYWdlS2V5IHwgbnVsbCwgcGFyYW1zTWFwOiBNYXA8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMudHlwZSA9IEFjdGlvblR5cGUuQ09OVkVSU0FUSU9OX0VSUk9SX09DQ1VSUkVEO1xuICAgICAgICB0aGlzLmVycm9yT2JqZWN0ID0gQ29udmVyc2F0aW9uRXJyb3JPY2N1cnJlZEFjdGlvbi5idWlsZEVycm9yT2JqZWN0KGVycm9yVHlwZSwgcGFyYW1zTWFwKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHN0YXRpYyBidWlsZEVycm9yT2JqZWN0KGVycm9yVHlwZTogSXJpc0Vycm9yTWVzc2FnZUtleSB8IG51bGwsIHBhcmFtc01hcD86IE1hcDxzdHJpbmcsIGFueT4pOiBJcmlzRXJyb3JUeXBlIHwgbnVsbCB7XG4gICAgICAgIGlmICghZXJyb3JUeXBlKSByZXR1cm4gbnVsbDtcbiAgICAgICAgY29uc3QgZXJyb3JPYmplY3QgPSBlcnJvck1lc3NhZ2VzW2Vycm9yVHlwZV07XG4gICAgICAgIGVycm9yT2JqZWN0LnBhcmFtc01hcCA9IHBhcmFtc01hcDtcbiAgICAgICAgcmV0dXJuIGVycm9yT2JqZWN0O1xuICAgIH1cbn1cblxuZXhwb3J0IGNsYXNzIFN0dWRlbnRNZXNzYWdlU2VudEFjdGlvbiBpbXBsZW1lbnRzIE1lc3NhZ2VTdG9yZUFjdGlvbiB7XG4gICAgcmVhZG9ubHkgdHlwZTogQWN0aW9uVHlwZTtcblxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHVibGljIHJlYWRvbmx5IG1lc3NhZ2U6IElyaXNVc2VyTWVzc2FnZSxcbiAgICAgICAgcHVibGljIHJlYWRvbmx5IHRpbWVvdXRJZDogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCBudWxsID0gbnVsbCxcbiAgICApIHtcbiAgICAgICAgdGhpcy50eXBlID0gQWN0aW9uVHlwZS5TVFVERU5UX01FU1NBR0VfU0VOVDtcbiAgICB9XG59XG5cbmV4cG9ydCBjbGFzcyBTZXNzaW9uUmVjZWl2ZWRBY3Rpb24gaW1wbGVtZW50cyBNZXNzYWdlU3RvcmVBY3Rpb24ge1xuICAgIHJlYWRvbmx5IHR5cGU6IEFjdGlvblR5cGU7XG5cbiAgICBwdWJsaWMgY29uc3RydWN0b3IoXG4gICAgICAgIHB1YmxpYyByZWFkb25seSBzZXNzaW9uSWQ6IG51bWJlcixcbiAgICAgICAgcHVibGljIHJlYWRvbmx5IG1lc3NhZ2VzOiBSZWFkb25seUFycmF5PElyaXNNZXNzYWdlPixcbiAgICApIHtcbiAgICAgICAgdGhpcy50eXBlID0gQWN0aW9uVHlwZS5TRVNTSU9OX0NIQU5HRUQ7XG4gICAgfVxufVxuXG5leHBvcnQgY2xhc3MgUmF0ZU1lc3NhZ2VTdWNjZXNzQWN0aW9uIGltcGxlbWVudHMgTWVzc2FnZVN0b3JlQWN0aW9uIHtcbiAgICByZWFkb25seSB0eXBlOiBBY3Rpb25UeXBlO1xuXG4gICAgcHVibGljIGNvbnN0cnVjdG9yKFxuICAgICAgICBwdWJsaWMgcmVhZG9ubHkgaW5kZXg6IG51bWJlcixcbiAgICAgICAgcHVibGljIHJlYWRvbmx5IGhlbHBmdWw6IGJvb2xlYW4sXG4gICAgKSB7XG4gICAgICAgIHRoaXMudHlwZSA9IEFjdGlvblR5cGUuUkFURV9NRVNTQUdFX1NVQ0NFU1M7XG4gICAgfVxufVxuXG5leHBvcnQgY2xhc3MgUmF0ZUxpbWl0VXBkYXRlZEFjdGlvbiBpbXBsZW1lbnRzIE1lc3NhZ2VTdG9yZUFjdGlvbiB7XG4gICAgcmVhZG9ubHkgdHlwZTogQWN0aW9uVHlwZTtcblxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihwdWJsaWMgcmVhZG9ubHkgcmF0ZUxpbWl0SW5mbzogSXJpc1JhdGVMaW1pdEluZm9ybWF0aW9uKSB7XG4gICAgICAgIHRoaXMudHlwZSA9IEFjdGlvblR5cGUuUkFURV9MSU1JVF9VUERBVEVEO1xuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzTnVtTmV3TWVzc2FnZXNSZXNldEFjdGlvbihhY3Rpb246IE1lc3NhZ2VTdG9yZUFjdGlvbik6IGFjdGlvbiBpcyBOdW1OZXdNZXNzYWdlc1Jlc2V0QWN0aW9uIHtcbiAgICByZXR1cm4gYWN0aW9uLnR5cGUgPT09IEFjdGlvblR5cGUuTlVNX05FV19NRVNTQUdFU19SRVNFVDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzSGlzdG9yeU1lc3NhZ2VMb2FkZWRBY3Rpb24oYWN0aW9uOiBNZXNzYWdlU3RvcmVBY3Rpb24pOiBhY3Rpb24gaXMgSGlzdG9yeU1lc3NhZ2VMb2FkZWRBY3Rpb24ge1xuICAgIHJldHVybiBhY3Rpb24udHlwZSA9PT0gQWN0aW9uVHlwZS5ISVNUT1JZX01FU1NBR0VfTE9BREVEO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNBY3RpdmVDb252ZXJzYXRpb25NZXNzYWdlTG9hZGVkQWN0aW9uKGFjdGlvbjogTWVzc2FnZVN0b3JlQWN0aW9uKTogYWN0aW9uIGlzIEFjdGl2ZUNvbnZlcnNhdGlvbk1lc3NhZ2VMb2FkZWRBY3Rpb24ge1xuICAgIHJldHVybiBhY3Rpb24udHlwZSA9PT0gQWN0aW9uVHlwZS5BQ1RJVkVfQ09OVkVSU0FUSU9OX01FU1NBR0VfTE9BREVEO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNDb252ZXJzYXRpb25FcnJvck9jY3VycmVkQWN0aW9uKGFjdGlvbjogTWVzc2FnZVN0b3JlQWN0aW9uKTogYWN0aW9uIGlzIENvbnZlcnNhdGlvbkVycm9yT2NjdXJyZWRBY3Rpb24ge1xuICAgIHJldHVybiBhY3Rpb24udHlwZSA9PT0gQWN0aW9uVHlwZS5DT05WRVJTQVRJT05fRVJST1JfT0NDVVJSRUQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc1N0dWRlbnRNZXNzYWdlU2VudEFjdGlvbihhY3Rpb246IE1lc3NhZ2VTdG9yZUFjdGlvbik6IGFjdGlvbiBpcyBTdHVkZW50TWVzc2FnZVNlbnRBY3Rpb24ge1xuICAgIHJldHVybiBhY3Rpb24udHlwZSA9PT0gQWN0aW9uVHlwZS5TVFVERU5UX01FU1NBR0VfU0VOVDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzU2Vzc2lvblJlY2VpdmVkQWN0aW9uKGFjdGlvbjogTWVzc2FnZVN0b3JlQWN0aW9uKTogYWN0aW9uIGlzIFNlc3Npb25SZWNlaXZlZEFjdGlvbiB7XG4gICAgcmV0dXJuIGFjdGlvbi50eXBlID09PSBBY3Rpb25UeXBlLlNFU1NJT05fQ0hBTkdFRDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzUmF0ZU1lc3NhZ2VTdWNjZXNzQWN0aW9uKGFjdGlvbjogTWVzc2FnZVN0b3JlQWN0aW9uKTogYWN0aW9uIGlzIFJhdGVNZXNzYWdlU3VjY2Vzc0FjdGlvbiB7XG4gICAgcmV0dXJuIGFjdGlvbi50eXBlID09PSBBY3Rpb25UeXBlLlJBVEVfTUVTU0FHRV9TVUNDRVNTO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNSYXRlTGltaXRVcGRhdGVkQWN0aW9uKGFjdGlvbjogTWVzc2FnZVN0b3JlQWN0aW9uKTogYWN0aW9uIGlzIFJhdGVMaW1pdFVwZGF0ZWRBY3Rpb24ge1xuICAgIHJldHVybiBhY3Rpb24udHlwZSA9PT0gQWN0aW9uVHlwZS5SQVRFX0xJTUlUX1VQREFURUQ7XG59XG5cbmV4cG9ydCBjbGFzcyBNZXNzYWdlU3RvcmVTdGF0ZSB7XG4gICAgcHVibGljIGNvbnN0cnVjdG9yKFxuICAgICAgICBwdWJsaWMgbWVzc2FnZXM6IFJlYWRvbmx5QXJyYXk8SXJpc01lc3NhZ2U+LFxuICAgICAgICBwdWJsaWMgc2Vzc2lvbklkOiBudW1iZXIgfCBudWxsLFxuICAgICAgICBwdWJsaWMgaXNMb2FkaW5nOiBib29sZWFuLFxuICAgICAgICBwdWJsaWMgbnVtTmV3TWVzc2FnZXM6IG51bWJlcixcbiAgICAgICAgcHVibGljIGVycm9yOiBJcmlzRXJyb3JUeXBlIHwgbnVsbCxcbiAgICAgICAgcHVibGljIHNlcnZlclJlc3BvbnNlVGltZW91dDogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCBudWxsLFxuICAgICAgICBwdWJsaWMgY3VycmVudE1lc3NhZ2VDb3VudDogbnVtYmVyLFxuICAgICAgICBwdWJsaWMgcmF0ZUxpbWl0OiBudW1iZXIsXG4gICAgICAgIHB1YmxpYyByYXRlTGltaXRUaW1lZnJhbWVIb3VyczogbnVtYmVyLFxuICAgICkge31cbn1cbiIsImltcG9ydCB7IEJhc2VFbnRpdHkgfSBmcm9tICdhcHAvc2hhcmVkL21vZGVsL2Jhc2UtZW50aXR5JztcbmltcG9ydCB7IElyaXNNZXNzYWdlQ29udGVudCwgSXJpc1RleHRNZXNzYWdlQ29udGVudCB9IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL2lyaXMtY29udGVudC10eXBlLm1vZGVsJztcbmltcG9ydCBkYXlqcyBmcm9tICdkYXlqcy9lc20nO1xuXG5leHBvcnQgZW51bSBJcmlzU2VuZGVyIHtcbiAgICBMTE0gPSAnTExNJyxcbiAgICBVU0VSID0gJ1VTRVInLFxuICAgIEFSVEVNSVNfU0VSVkVSID0gJ0FSVEVNSVNfU0VSVkVSJyxcbiAgICBBUlRFTUlTX0NMSUVOVCA9ICdBUlRFTUlTX0NMSUVOVCcsXG59XG5cbmV4cG9ydCBjbGFzcyBJcmlzQXJ0ZW1pc0NsaWVudE1lc3NhZ2UgaW1wbGVtZW50cyBCYXNlRW50aXR5IHtcbiAgICBpZD86IG51bWJlcjtcbiAgICBjb250ZW50OiBJcmlzVGV4dE1lc3NhZ2VDb250ZW50W107XG4gICAgc2VudEF0OiBkYXlqcy5EYXlqcztcbiAgICBzZW5kZXI6IElyaXNTZW5kZXIuQVJURU1JU19DTElFTlQ7XG59XG5cbmV4cG9ydCBjbGFzcyBJcmlzU2VydmVyTWVzc2FnZSBpbXBsZW1lbnRzIEJhc2VFbnRpdHkge1xuICAgIGlkOiBudW1iZXI7XG4gICAgY29udGVudDogSXJpc01lc3NhZ2VDb250ZW50W107XG4gICAgc2VudEF0OiBkYXlqcy5EYXlqcztcbiAgICBzZW5kZXI6IElyaXNTZW5kZXIuTExNIHwgSXJpc1NlbmRlci5BUlRFTUlTX1NFUlZFUjtcbiAgICBoZWxwZnVsPzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGNsYXNzIElyaXNVc2VyTWVzc2FnZSBpbXBsZW1lbnRzIEJhc2VFbnRpdHkge1xuICAgIGlkPzogbnVtYmVyO1xuICAgIGNvbnRlbnQ6IElyaXNUZXh0TWVzc2FnZUNvbnRlbnRbXTtcbiAgICBzZW50QXQ/OiBkYXlqcy5EYXlqcztcbiAgICBzZW5kZXI6IElyaXNTZW5kZXIuVVNFUjtcbiAgICBtZXNzYWdlRGlmZmVyZW50aWF0b3I/OiBudW1iZXI7XG59XG5cbmV4cG9ydCB0eXBlIElyaXNNZXNzYWdlID0gSXJpc1NlcnZlck1lc3NhZ2UgfCBJcmlzVXNlck1lc3NhZ2UgfCBJcmlzQXJ0ZW1pc0NsaWVudE1lc3NhZ2U7XG5cbi8qKlxuICogQ2hlY2tzIGlmIGEgbWVzc2FnZSBpcyBhIHNlcnZlci1zZW50IG1lc3NhZ2UuXG4gKiBAcGFyYW0gbWVzc2FnZSAtIFRoZSBtZXNzYWdlIHRvIGNoZWNrLlxuICogQHJldHVybnMgQSBib29sZWFuIGluZGljYXRpbmcgaWYgdGhlIG1lc3NhZ2UgaXMgYSBzZXJ2ZXItc2VudCBtZXNzYWdlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNTZXJ2ZXJTZW50TWVzc2FnZShtZXNzYWdlOiBJcmlzTWVzc2FnZSk6IG1lc3NhZ2UgaXMgSXJpc1NlcnZlck1lc3NhZ2Uge1xuICAgIHJldHVybiBtZXNzYWdlLnNlbmRlciA9PT0gSXJpc1NlbmRlci5BUlRFTUlTX1NFUlZFUiB8fCBtZXNzYWdlLnNlbmRlciA9PT0gSXJpc1NlbmRlci5MTE07XG59XG5cbi8qKlxuICogQ2hlY2tzIGlmIGEgbWVzc2FnZSBpcyBhIHdlbGNvbWUgbWVzc2FnZSBnZW5lcmF0ZWQgYnkgdGhlIGNsaWVudC5cbiAqIEBwYXJhbSBtZXNzYWdlIC0gVGhlIG1lc3NhZ2UgdG8gY2hlY2suXG4gKiBAcmV0dXJucyBBIGJvb2xlYW4gaW5kaWNhdGluZyBpZiB0aGUgbWVzc2FnZSBpcyBhIGNsaWVudC1zZW50IG1lc3NhZ2UuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc0FydGVtaXNDbGllbnRTZW50TWVzc2FnZShtZXNzYWdlOiBJcmlzTWVzc2FnZSk6IG1lc3NhZ2UgaXMgSXJpc1NlcnZlck1lc3NhZ2Uge1xuICAgIHJldHVybiBtZXNzYWdlLnNlbmRlciA9PT0gSXJpc1NlbmRlci5BUlRFTUlTX0NMSUVOVDtcbn1cblxuLyoqXG4gKiBDaGVja3MgaWYgYSBtZXNzYWdlIGlzIGEgc3R1ZGVudC1zZW50IG1lc3NhZ2UuXG4gKiBAcGFyYW0gbWVzc2FnZSAtIFRoZSBtZXNzYWdlIHRvIGNoZWNrLlxuICogQHJldHVybnMgQSBib29sZWFuIGluZGljYXRpbmcgaWYgdGhlIG1lc3NhZ2UgaXMgYSBzdHVkZW50LXNlbnQgbWVzc2FnZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzU3R1ZGVudFNlbnRNZXNzYWdlKG1lc3NhZ2U6IElyaXNNZXNzYWdlKTogbWVzc2FnZSBpcyBJcmlzVXNlck1lc3NhZ2Uge1xuICAgIHJldHVybiBtZXNzYWdlLnNlbmRlciA9PT0gSXJpc1NlbmRlci5VU0VSO1xufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgT25EZXN0cm95IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBCZWhhdmlvclN1YmplY3QsIE9ic2VydmFibGUsIFN1YmplY3QsIFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgbWFwLCB0YXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQge1xuICAgIEFjdGl2ZUNvbnZlcnNhdGlvbk1lc3NhZ2VMb2FkZWRBY3Rpb24sXG4gICAgQ29udmVyc2F0aW9uRXJyb3JPY2N1cnJlZEFjdGlvbixcbiAgICBIaXN0b3J5TWVzc2FnZUxvYWRlZEFjdGlvbixcbiAgICBNZXNzYWdlU3RvcmVBY3Rpb24sXG4gICAgTWVzc2FnZVN0b3JlU3RhdGUsXG4gICAgUmF0ZUxpbWl0VXBkYXRlZEFjdGlvbixcbiAgICBSYXRlTWVzc2FnZVN1Y2Nlc3NBY3Rpb24sXG4gICAgU2Vzc2lvblJlY2VpdmVkQWN0aW9uLFxuICAgIFN0dWRlbnRNZXNzYWdlU2VudEFjdGlvbixcbiAgICBpc0FjdGl2ZUNvbnZlcnNhdGlvbk1lc3NhZ2VMb2FkZWRBY3Rpb24sXG4gICAgaXNDb252ZXJzYXRpb25FcnJvck9jY3VycmVkQWN0aW9uLFxuICAgIGlzSGlzdG9yeU1lc3NhZ2VMb2FkZWRBY3Rpb24sXG4gICAgaXNOdW1OZXdNZXNzYWdlc1Jlc2V0QWN0aW9uLFxuICAgIGlzUmF0ZUxpbWl0VXBkYXRlZEFjdGlvbixcbiAgICBpc1JhdGVNZXNzYWdlU3VjY2Vzc0FjdGlvbixcbiAgICBpc1Nlc3Npb25SZWNlaXZlZEFjdGlvbixcbiAgICBpc1N0dWRlbnRNZXNzYWdlU2VudEFjdGlvbixcbn0gZnJvbSAnYXBwL2lyaXMvc3RhdGUtc3RvcmUubW9kZWwnO1xuaW1wb3J0IHsgSXJpc1NlcnZlck1lc3NhZ2UsIGlzU3R1ZGVudFNlbnRNZXNzYWdlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvaXJpcy1tZXNzYWdlLm1vZGVsJztcbmltcG9ydCB7IElyaXNFcnJvck1lc3NhZ2VLZXksIElyaXNFcnJvclR5cGUsIGVycm9yTWVzc2FnZXMgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9pcmlzLWVycm9ycy5tb2RlbCc7XG5cbnR5cGUgUmVzb2x2YWJsZUFjdGlvbiA9IHsgYWN0aW9uOiBNZXNzYWdlU3RvcmVBY3Rpb247IHJlc29sdmU6ICgpID0+IHZvaWQ7IHJlamVjdDogKGVycm9yOiBJcmlzRXJyb3JUeXBlKSA9PiB2b2lkIH07XG5cbi8qKlxuICogUHJvdmlkZXMgYSBzdG9yZSB0byBtYW5hZ2UgbWVzc2FnZS1yZWxhdGVkIHN0YXRlIGRhdGEgYW5kIGRpc3BhdGNoIGFjdGlvbnMuIElzIHZhbGlkIG9ubHkgaW5zaWRlIENvdXJzZUV4ZXJjaXNlRGV0YWlsc0NvbXBvbmVudFxuICovXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgSXJpc1N0YXRlU3RvcmUgaW1wbGVtZW50cyBPbkRlc3Ryb3kge1xuICAgIHByaXZhdGUgcmVhZG9ubHkgaW5pdGlhbFN0YXRlOiBNZXNzYWdlU3RvcmVTdGF0ZSA9IHtcbiAgICAgICAgbWVzc2FnZXM6IFtdLFxuICAgICAgICBzZXNzaW9uSWQ6IG51bGwsXG4gICAgICAgIGlzTG9hZGluZzogZmFsc2UsXG4gICAgICAgIG51bU5ld01lc3NhZ2VzOiAwLFxuICAgICAgICBlcnJvcjogbnVsbCxcbiAgICAgICAgc2VydmVyUmVzcG9uc2VUaW1lb3V0OiBudWxsLFxuICAgICAgICBjdXJyZW50TWVzc2FnZUNvdW50OiAtMSxcbiAgICAgICAgcmF0ZUxpbWl0OiAtMSxcbiAgICAgICAgcmF0ZUxpbWl0VGltZWZyYW1lSG91cnM6IC0xLFxuICAgIH07XG5cbiAgICBwcml2YXRlIHJlYWRvbmx5IGFjdGlvbiA9IG5ldyBTdWJqZWN0PFJlc29sdmFibGVBY3Rpb24+KCk7XG4gICAgcHJpdmF0ZSByZWFkb25seSBzdGF0ZSA9IG5ldyBCZWhhdmlvclN1YmplY3Q8TWVzc2FnZVN0b3JlU3RhdGU+KHRoaXMuaW5pdGlhbFN0YXRlKTtcbiAgICBwcml2YXRlIHJlYWRvbmx5IHN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xuXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMuc3Vic2NyaXB0aW9uID0gdGhpcy5hY3Rpb25cbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIHRhcCgocmVzb2x2YWJsZUFjdGlvbjogUmVzb2x2YWJsZUFjdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdTdGF0ZSA9IElyaXNTdGF0ZVN0b3JlLnN0b3JlUmVkdWNlcih0aGlzLnN0YXRlLmdldFZhbHVlKCksIHJlc29sdmFibGVBY3Rpb24uYWN0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGF0ZS5uZXh0KG5ld1N0YXRlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG5ld1N0YXRlLmVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZhYmxlQWN0aW9uLnJlamVjdChuZXdTdGF0ZS5lcnJvcik7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZhYmxlQWN0aW9uLnJlc29sdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSgpO1xuICAgIH1cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLnN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICB0aGlzLnN0YXRlLmNvbXBsZXRlKCk7XG4gICAgICAgIHRoaXMuYWN0aW9uLmNvbXBsZXRlKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGlzcGF0Y2hlcyBhbiBhY3Rpb24gdG8gdXBkYXRlIHRoZSBtZXNzYWdlIHN0b3JlIHN0YXRlLlxuICAgICAqIEBwYXJhbSBhY3Rpb24gVGhlIGFjdGlvbiB0byBkaXNwYXRjaC5cbiAgICAgKiBAcmV0dXJuIHByb21pc2UgUHJvbWlzZSB0byBoYW5kbGUgY29uc2VjdXRpdmUgY2FzZXNcbiAgICAgKi9cbiAgICBkaXNwYXRjaEFuZFRoZW4oYWN0aW9uOiBNZXNzYWdlU3RvcmVBY3Rpb24pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYWN0aW9uLm5leHQoe1xuICAgICAgICAgICAgICAgIGFjdGlvbjogYWN0aW9uLFxuICAgICAgICAgICAgICAgIHJlc29sdmU6IHJlc29sdmUsXG4gICAgICAgICAgICAgICAgcmVqZWN0OiByZWplY3QsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGlzcGF0Y2hlcyBhbiBhY3Rpb24gdG8gdXBkYXRlIHRoZSBtZXNzYWdlIHN0b3JlIHN0YXRlLlxuICAgICAqIEBwYXJhbSBhY3Rpb24gVGhlIGFjdGlvbiB0byBkaXNwYXRjaC5cbiAgICAgKiBAcmV0dXJuIHZvaWRcbiAgICAgKi9cbiAgICBkaXNwYXRjaChhY3Rpb246IE1lc3NhZ2VTdG9yZUFjdGlvbik6IHZvaWQge1xuICAgICAgICB0aGlzLmFjdGlvbi5uZXh0KHtcbiAgICAgICAgICAgIGFjdGlvbjogYWN0aW9uLFxuICAgICAgICAgICAgcmVzb2x2ZTogKCkgPT4ge30sXG4gICAgICAgICAgICByZWplY3Q6ICgpID0+IHt9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGFuIG9ic2VydmFibGUgb2YgdGhlIGN1cnJlbnQgbWVzc2FnZSBzdG9yZSBzdGF0ZS5cbiAgICAgKiBAcmV0dXJucyBBbiBvYnNlcnZhYmxlIG9mIHRoZSBjdXJyZW50IG1lc3NhZ2Ugc3RvcmUgc3RhdGUuXG4gICAgICovXG4gICAgZ2V0U3RhdGUoKTogT2JzZXJ2YWJsZTxNZXNzYWdlU3RvcmVTdGF0ZT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zdGF0ZS5hc09ic2VydmFibGUoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGFuIG9ic2VydmFibGUgb2YgdGhlIGFjdGlvbnMgZGlzcGF0Y2hlZCB0byB0aGUgbWVzc2FnZSBzdG9yZS5cbiAgICAgKiBAcmV0dXJucyBBbiBvYnNlcnZhYmxlIG9mIHRoZSBhY3Rpb25zIGRpc3BhdGNoZWQgdG8gdGhlIG1lc3NhZ2Ugc3RvcmUuXG4gICAgICovXG4gICAgZ2V0QWN0aW9uT2JzZXJ2YWJsZSgpOiBPYnNlcnZhYmxlPE1lc3NhZ2VTdG9yZUFjdGlvbj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5hY3Rpb24uYXNPYnNlcnZhYmxlKCkucGlwZShtYXAoKHJlc29sdmFibGVBY3Rpb246IFJlc29sdmFibGVBY3Rpb24pID0+IHJlc29sdmFibGVBY3Rpb24uYWN0aW9uKSk7XG4gICAgfVxuXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICAgIHByaXZhdGUgc3RhdGljIGV4aGF1c3RpdmVDaGVjayhfOiBuZXZlcik6IHZvaWQge1xuICAgICAgICAvLyB0eXBlc2NyaXB0IHdpbGwgZGV0ZWN0IGFueSBuZXcgdW5oYW5kbGVkIGFjdGlvbiB0eXBlcyB1c2luZyBpdHMgaW5mZXJlbmNlIHN5c3RlbSwgdGhpcyBtZXRob2Qgc2hvdWxkIG5ldmVyIGJlIGNhbGxlZFxuICAgIH1cblxuICAgIHByaXZhdGUgc3RhdGljIHN0b3JlUmVkdWNlcihzdGF0ZTogTWVzc2FnZVN0b3JlU3RhdGUsIGFjdGlvbjogTWVzc2FnZVN0b3JlQWN0aW9uKTogTWVzc2FnZVN0b3JlU3RhdGUge1xuICAgICAgICBjb25zdCBkZWZhdWx0RXJyb3I6IElyaXNFcnJvclR5cGUgfCBudWxsID0gc3RhdGUuZXJyb3IgIT0gbnVsbCAmJiBzdGF0ZS5lcnJvci5mYXRhbCA/IHN0YXRlLmVycm9yIDogbnVsbDtcblxuICAgICAgICBpZiAoc3RhdGUuc2Vzc2lvbklkID09IG51bGwgJiYgIShpc1Nlc3Npb25SZWNlaXZlZEFjdGlvbihhY3Rpb24pIHx8IGlzQ29udmVyc2F0aW9uRXJyb3JPY2N1cnJlZEFjdGlvbihhY3Rpb24pKSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGVycm9yOiBlcnJvck1lc3NhZ2VzW0lyaXNFcnJvck1lc3NhZ2VLZXkuSU5WQUxJRF9TRVNTSU9OX1NUQVRFXSxcbiAgICAgICAgICAgICAgICBzZXJ2ZXJSZXNwb25zZVRpbWVvdXQ6IG51bGwsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc051bU5ld01lc3NhZ2VzUmVzZXRBY3Rpb24oYWN0aW9uKSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICAgICBudW1OZXdNZXNzYWdlczogMCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzSGlzdG9yeU1lc3NhZ2VMb2FkZWRBY3Rpb24oYWN0aW9uKSkge1xuICAgICAgICAgICAgY29uc3QgY2FzdGVkQWN0aW9uID0gYWN0aW9uIGFzIEhpc3RvcnlNZXNzYWdlTG9hZGVkQWN0aW9uO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICAgICBtZXNzYWdlczogWy4uLnN0YXRlLm1lc3NhZ2VzLCBjYXN0ZWRBY3Rpb24ubWVzc2FnZV0sXG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBlcnJvcjogZGVmYXVsdEVycm9yLFxuICAgICAgICAgICAgICAgIHNlcnZlclJlc3BvbnNlVGltZW91dDogbnVsbCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzQWN0aXZlQ29udmVyc2F0aW9uTWVzc2FnZUxvYWRlZEFjdGlvbihhY3Rpb24pKSB7XG4gICAgICAgICAgICBjb25zdCBjYXN0ZWRBY3Rpb24gPSBhY3Rpb24gYXMgQWN0aXZlQ29udmVyc2F0aW9uTWVzc2FnZUxvYWRlZEFjdGlvbjtcbiAgICAgICAgICAgIGlmIChzdGF0ZS5zZXJ2ZXJSZXNwb25zZVRpbWVvdXQgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQoc3RhdGUuc2VydmVyUmVzcG9uc2VUaW1lb3V0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgbWVzc2FnZXM6IFsuLi5zdGF0ZS5tZXNzYWdlcywgY2FzdGVkQWN0aW9uLm1lc3NhZ2VdLFxuICAgICAgICAgICAgICAgIHNlc3Npb25JZDogc3RhdGUuc2Vzc2lvbklkLFxuICAgICAgICAgICAgICAgIGlzTG9hZGluZzogZmFsc2UsXG4gICAgICAgICAgICAgICAgbnVtTmV3TWVzc2FnZXM6IHN0YXRlLm51bU5ld01lc3NhZ2VzICsgMSxcbiAgICAgICAgICAgICAgICBlcnJvcjogZGVmYXVsdEVycm9yLFxuICAgICAgICAgICAgICAgIHNlcnZlclJlc3BvbnNlVGltZW91dDogbnVsbCxcbiAgICAgICAgICAgICAgICBjdXJyZW50TWVzc2FnZUNvdW50OiBzdGF0ZS5jdXJyZW50TWVzc2FnZUNvdW50LFxuICAgICAgICAgICAgICAgIHJhdGVMaW1pdDogc3RhdGUucmF0ZUxpbWl0LFxuICAgICAgICAgICAgICAgIHJhdGVMaW1pdFRpbWVmcmFtZUhvdXJzOiBzdGF0ZS5yYXRlTGltaXRUaW1lZnJhbWVIb3VycyxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzQ29udmVyc2F0aW9uRXJyb3JPY2N1cnJlZEFjdGlvbihhY3Rpb24pKSB7XG4gICAgICAgICAgICBjb25zdCBjYXN0ZWRBY3Rpb24gPSBhY3Rpb24gYXMgQ29udmVyc2F0aW9uRXJyb3JPY2N1cnJlZEFjdGlvbjtcbiAgICAgICAgICAgIGlmIChzdGF0ZS5zZXJ2ZXJSZXNwb25zZVRpbWVvdXQgIT09IG51bGwgJiYgKGNhc3RlZEFjdGlvbi5lcnJvck9iamVjdD8uZmF0YWwgfHwgY2FzdGVkQWN0aW9uLmVycm9yT2JqZWN0Py5rZXkgPT09IElyaXNFcnJvck1lc3NhZ2VLZXkuU0VORF9NRVNTQUdFX0ZBSUxFRCkpIHtcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQoc3RhdGUuc2VydmVyUmVzcG9uc2VUaW1lb3V0KTtcbiAgICAgICAgICAgICAgICBzdGF0ZS5zZXJ2ZXJSZXNwb25zZVRpbWVvdXQgPSBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGVycm9yOiBjYXN0ZWRBY3Rpb24uZXJyb3JPYmplY3QsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc1Nlc3Npb25SZWNlaXZlZEFjdGlvbihhY3Rpb24pKSB7XG4gICAgICAgICAgICBjb25zdCBjYXN0ZWRBY3Rpb24gPSBhY3Rpb24gYXMgU2Vzc2lvblJlY2VpdmVkQWN0aW9uO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICAgICBtZXNzYWdlczogY2FzdGVkQWN0aW9uLm1lc3NhZ2VzLFxuICAgICAgICAgICAgICAgIHNlc3Npb25JZDogY2FzdGVkQWN0aW9uLnNlc3Npb25JZCxcbiAgICAgICAgICAgICAgICBlcnJvcjogZGVmYXVsdEVycm9yLFxuICAgICAgICAgICAgICAgIHNlcnZlclJlc3BvbnNlVGltZW91dDogbnVsbCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzU3R1ZGVudE1lc3NhZ2VTZW50QWN0aW9uKGFjdGlvbikpIHtcbiAgICAgICAgICAgIGNvbnN0IGNhc3RlZEFjdGlvbiA9IGFjdGlvbiBhcyBTdHVkZW50TWVzc2FnZVNlbnRBY3Rpb247XG4gICAgICAgICAgICBsZXQgbmV3TWVzc2FnZSA9IHRydWU7XG4gICAgICAgICAgICBpZiAoY2FzdGVkQWN0aW9uLm1lc3NhZ2UubWVzc2FnZURpZmZlcmVudGlhdG9yICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gc3RhdGUubWVzc2FnZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbWVzc2FnZSA9IHN0YXRlLm1lc3NhZ2VzW2ldO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWlzU3R1ZGVudFNlbnRNZXNzYWdlKG1lc3NhZ2UpKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2UubWVzc2FnZURpZmZlcmVudGlhdG9yID09PSB1bmRlZmluZWQpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS5tZXNzYWdlRGlmZmVyZW50aWF0b3IgPT09IGNhc3RlZEFjdGlvbi5tZXNzYWdlLm1lc3NhZ2VEaWZmZXJlbnRpYXRvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmV3TWVzc2FnZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFuZXdNZXNzYWdlKSB7XG4gICAgICAgICAgICAgICAgaWYgKGNhc3RlZEFjdGlvbi50aW1lb3V0SWQgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KGNhc3RlZEFjdGlvbi50aW1lb3V0SWQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBlcnJvcjogY2FzdGVkQWN0aW9uLm1lc3NhZ2UuaWQgPT09IHVuZGVmaW5lZCA/IGRlZmF1bHRFcnJvciA6IG51bGwsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICAgICAgbWVzc2FnZXM6IFsuLi5zdGF0ZS5tZXNzYWdlcywgY2FzdGVkQWN0aW9uLm1lc3NhZ2VdLFxuICAgICAgICAgICAgICAgIGlzTG9hZGluZzogdHJ1ZSxcbiAgICAgICAgICAgICAgICBlcnJvcjogZGVmYXVsdEVycm9yLFxuICAgICAgICAgICAgICAgIHNlcnZlclJlc3BvbnNlVGltZW91dDogY2FzdGVkQWN0aW9uLnRpbWVvdXRJZCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzUmF0ZU1lc3NhZ2VTdWNjZXNzQWN0aW9uKGFjdGlvbikpIHtcbiAgICAgICAgICAgIGNvbnN0IGNhc3RlZEFjdGlvbiA9IGFjdGlvbiBhcyBSYXRlTWVzc2FnZVN1Y2Nlc3NBY3Rpb247XG4gICAgICAgICAgICBjb25zdCBuZXdNZXNzYWdlcyA9IHN0YXRlLm1lc3NhZ2VzO1xuICAgICAgICAgICAgaWYgKGNhc3RlZEFjdGlvbi5pbmRleCA8IHN0YXRlLm1lc3NhZ2VzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIChuZXdNZXNzYWdlc1tjYXN0ZWRBY3Rpb24uaW5kZXhdIGFzIElyaXNTZXJ2ZXJNZXNzYWdlKS5oZWxwZnVsID0gY2FzdGVkQWN0aW9uLmhlbHBmdWw7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2VzOiBuZXdNZXNzYWdlcyxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gc3RhdGU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzUmF0ZUxpbWl0VXBkYXRlZEFjdGlvbihhY3Rpb24pKSB7XG4gICAgICAgICAgICBjb25zdCBjYXN0ZWRBY3Rpb24gPSBhY3Rpb24gYXMgUmF0ZUxpbWl0VXBkYXRlZEFjdGlvbjtcbiAgICAgICAgICAgIGNvbnN0IHJhdGVMaW1pdEluZm8gPSBjYXN0ZWRBY3Rpb24ucmF0ZUxpbWl0SW5mbztcbiAgICAgICAgICAgIGxldCBlcnJvck1lc3NhZ2U6IElyaXNFcnJvclR5cGUgfCBudWxsID0gbnVsbDtcbiAgICAgICAgICAgIGlmIChyYXRlTGltaXRJbmZvLnJhdGVMaW1pdCA+PSAwICYmIHJhdGVMaW1pdEluZm8uY3VycmVudE1lc3NhZ2VDb3VudCA+PSByYXRlTGltaXRJbmZvLnJhdGVMaW1pdCkge1xuICAgICAgICAgICAgICAgIGVycm9yTWVzc2FnZSA9IGVycm9yTWVzc2FnZXNbSXJpc0Vycm9yTWVzc2FnZUtleS5SQVRFX0xJTUlUX0VYQ0VFREVEXTtcbiAgICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UucGFyYW1zTWFwID0gbmV3IE1hcDxzdHJpbmcsIGFueT4oKTtcbiAgICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UucGFyYW1zTWFwLnNldCgnaG91cnMnLCByYXRlTGltaXRJbmZvLnJhdGVMaW1pdFRpbWVmcmFtZUhvdXJzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICAgICAgZXJyb3I6IGVycm9yTWVzc2FnZSxcbiAgICAgICAgICAgICAgICBjdXJyZW50TWVzc2FnZUNvdW50OiByYXRlTGltaXRJbmZvLmN1cnJlbnRNZXNzYWdlQ291bnQsXG4gICAgICAgICAgICAgICAgcmF0ZUxpbWl0OiByYXRlTGltaXRJbmZvLnJhdGVMaW1pdCxcbiAgICAgICAgICAgICAgICByYXRlTGltaXRUaW1lZnJhbWVIb3VyczogcmF0ZUxpbWl0SW5mby5yYXRlTGltaXRUaW1lZnJhbWVIb3VycyxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cblxuICAgICAgICBJcmlzU3RhdGVTdG9yZS5leGhhdXN0aXZlQ2hlY2soYWN0aW9uKTtcbiAgICAgICAgcmV0dXJuIHN0YXRlO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEJlaGF2aW9yU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuXG5ASW5qZWN0YWJsZSh7XG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxufSlcbmV4cG9ydCBjbGFzcyBTaGFyZWRTZXJ2aWNlIHtcbiAgICBwcml2YXRlIGNoYXRPcGVuU291cmNlID0gbmV3IEJlaGF2aW9yU3ViamVjdDxib29sZWFuPihmYWxzZSk7XG4gICAgY2hhdE9wZW4gPSB0aGlzLmNoYXRPcGVuU291cmNlLmFzT2JzZXJ2YWJsZSgpO1xuXG4gICAgY2hhbmdlQ2hhdE9wZW5TdGF0dXMoc3RhdHVzOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuY2hhdE9wZW5Tb3VyY2UubmV4dChzdGF0dXMpO1xuICAgIH1cbn1cbiIsImV4cG9ydCBlbnVtIElyaXNNZXNzYWdlQ29udGVudFR5cGUge1xuICAgIFRFWFQgPSAndGV4dCcsXG4gICAgRVhFUkNJU0VfUExBTiA9ICdleGVyY2lzZV9wbGFuJyxcbn1cblxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIElyaXNNZXNzYWdlQ29udGVudCB7XG4gICAgaWQ/OiBudW1iZXI7XG4gICAgbWVzc2FnZUlkPzogbnVtYmVyO1xuXG4gICAgcHJvdGVjdGVkIGNvbnN0cnVjdG9yKHB1YmxpYyB0eXBlOiBJcmlzTWVzc2FnZUNvbnRlbnRUeXBlKSB7fVxufVxuXG5leHBvcnQgY2xhc3MgSXJpc1RleHRNZXNzYWdlQ29udGVudCBleHRlbmRzIElyaXNNZXNzYWdlQ29udGVudCB7XG4gICAgY29uc3RydWN0b3IocHVibGljIHRleHRDb250ZW50OiBzdHJpbmcpIHtcbiAgICAgICAgc3VwZXIoSXJpc01lc3NhZ2VDb250ZW50VHlwZS5URVhUKTtcbiAgICB9XG59XG5cbmV4cG9ydCBjbGFzcyBJcmlzRXhlcmNpc2VQbGFuIGV4dGVuZHMgSXJpc01lc3NhZ2VDb250ZW50IHtcbiAgICBleGVjdXRpbmc6IGJvb2xlYW47IC8vIENsaWVudC1zaWRlIG9ubHlcblxuICAgIGNvbnN0cnVjdG9yKHB1YmxpYyBzdGVwczogSXJpc0V4ZXJjaXNlUGxhblN0ZXBbXSkge1xuICAgICAgICBzdXBlcihJcmlzTWVzc2FnZUNvbnRlbnRUeXBlLkVYRVJDSVNFX1BMQU4pO1xuICAgIH1cbn1cblxuZXhwb3J0IGNsYXNzIElyaXNFeGVyY2lzZVBsYW5TdGVwIHtcbiAgICBpZDogbnVtYmVyO1xuICAgIHBsYW46IG51bWJlcjtcbiAgICBjb21wb25lbnQ6IEV4ZXJjaXNlQ29tcG9uZW50O1xuICAgIGluc3RydWN0aW9uczogc3RyaW5nO1xuICAgIGV4ZWN1dGlvblN0YWdlOiBFeGVjdXRpb25TdGFnZTtcbiAgICBoaWRkZW4/OiBib29sZWFuOyAvLyBDbGllbnQtc2lkZSBvbmx5XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc05vdEV4ZWN1dGVkKHN0ZXA6IElyaXNFeGVyY2lzZVBsYW5TdGVwKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHN0ZXAuZXhlY3V0aW9uU3RhZ2UgPT09IEV4ZWN1dGlvblN0YWdlLk5PVF9FWEVDVVRFRDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzSW5Qcm9ncmVzcyhzdGVwOiBJcmlzRXhlcmNpc2VQbGFuU3RlcCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiBzdGVwLmV4ZWN1dGlvblN0YWdlID09PSBFeGVjdXRpb25TdGFnZS5JTl9QUk9HUkVTUztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRmFpbGVkKHN0ZXA6IElyaXNFeGVyY2lzZVBsYW5TdGVwKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHN0ZXAuZXhlY3V0aW9uU3RhZ2UgPT09IEV4ZWN1dGlvblN0YWdlLkZBSUxFRDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzQ29tcGxldGUoc3RlcDogSXJpc0V4ZXJjaXNlUGxhblN0ZXApOiBib29sZWFuIHtcbiAgICByZXR1cm4gc3RlcC5leGVjdXRpb25TdGFnZSA9PT0gRXhlY3V0aW9uU3RhZ2UuQ09NUExFVEU7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBoaWRlT3JVbmhpZGUoc3RlcDogSXJpc0V4ZXJjaXNlUGxhblN0ZXApOiB2b2lkIHtcbiAgICBzdGVwLmhpZGRlbiA9ICFpc0hpZGRlbihzdGVwKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzSGlkZGVuKHN0ZXA6IElyaXNFeGVyY2lzZVBsYW5TdGVwKTogYm9vbGVhbiB7XG4gICAgaWYgKHN0ZXAuaGlkZGVuID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgLy8gV2hlbiBhIHBsYW4gaXMgZmlyc3QgbG9hZGVkLCBhbGwgc3RlcHMgYXJlIGhpZGRlbiBieSBkZWZhdWx0XG4gICAgICAgIHN0ZXAuaGlkZGVuID0gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIHN0ZXAuaGlkZGVuO1xufVxuXG5leHBvcnQgZW51bSBFeGVyY2lzZUNvbXBvbmVudCB7XG4gICAgUFJPQkxFTV9TVEFURU1FTlQgPSAnUFJPQkxFTV9TVEFURU1FTlQnLFxuICAgIFNPTFVUSU9OX1JFUE9TSVRPUlkgPSAnU09MVVRJT05fUkVQT1NJVE9SWScsXG4gICAgVEVNUExBVEVfUkVQT1NJVE9SWSA9ICdURU1QTEFURV9SRVBPU0lUT1JZJyxcbiAgICBURVNUX1JFUE9TSVRPUlkgPSAnVEVTVF9SRVBPU0lUT1JZJyxcbn1cblxuZXhwb3J0IGVudW0gRXhlY3V0aW9uU3RhZ2Uge1xuICAgIE5PVF9FWEVDVVRFRCA9ICdOT1RfRVhFQ1VURUQnLFxuICAgIElOX1BST0dSRVNTID0gJ0lOX1BST0dSRVNTJyxcbiAgICBGQUlMRUQgPSAnRkFJTEVEJyxcbiAgICBDT01QTEVURSA9ICdDT01QTEVURScsXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc1RleHRDb250ZW50KGNvbnRlbnQ6IElyaXNNZXNzYWdlQ29udGVudCk6IGNvbnRlbnQgaXMgSXJpc1RleHRNZXNzYWdlQ29udGVudCB7XG4gICAgcmV0dXJuIGNvbnRlbnQudHlwZSA9PT0gSXJpc01lc3NhZ2VDb250ZW50VHlwZS5URVhUO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0VGV4dENvbnRlbnQoY29udGVudDogSXJpc01lc3NhZ2VDb250ZW50KSB7XG4gICAgaWYgKGlzVGV4dENvbnRlbnQoY29udGVudCkpIHtcbiAgICAgICAgY29uc3QgaXJpc01lc3NhZ2VUZXh0Q29udGVudCA9IGNvbnRlbnQgYXMgSXJpc1RleHRNZXNzYWdlQ29udGVudDtcbiAgICAgICAgcmV0dXJuIGlyaXNNZXNzYWdlVGV4dENvbnRlbnQudGV4dENvbnRlbnQ7XG4gICAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNFeGVyY2lzZVBsYW4oY29udGVudDogSXJpc01lc3NhZ2VDb250ZW50KTogY29udGVudCBpcyBJcmlzRXhlcmNpc2VQbGFuIHtcbiAgICByZXR1cm4gY29udGVudC50eXBlID09PSBJcmlzTWVzc2FnZUNvbnRlbnRUeXBlLkVYRVJDSVNFX1BMQU47XG59XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50LCBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBJcmlzU2Vzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL2lyaXMtc2Vzc2lvbi5tb2RlbCc7XG5cbnR5cGUgRW50aXR5UmVzcG9uc2VUeXBlID0gSHR0cFJlc3BvbnNlPElyaXNTZXNzaW9uPjtcblxuLyoqXG4gKiBUaGUgYElyaXNIdHRwU2Vzc2lvblNlcnZpY2VgIHByb3ZpZGVzIG1ldGhvZHMgZm9yIHJldHJpZXZpbmcgZXhpc3Rpbmcgb3IgY3JlYXRpbmcgbmV3IElyaXMgc2Vzc2lvbnMuXG4gKiBJdCBpbnRlcmFjdHMgd2l0aCB0aGUgc2VydmVyLXNpZGUgQVBJIHRvIHBlcmZvcm0gc2Vzc2lvbi1yZWxhdGVkIG9wZXJhdGlvbnMuXG4gKi9cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgSXJpc0h0dHBTZXNzaW9uU2VydmljZSB7XG4gICAgcHJvdGVjdGVkIGFwaVByZWZpeCA9ICdhcGkvaXJpcyc7XG5cbiAgICBwcm90ZWN0ZWQgY29uc3RydWN0b3IoXG4gICAgICAgIHByb3RlY3RlZCBodHRwOiBIdHRwQ2xpZW50LFxuICAgICAgICBwcm90ZWN0ZWQgc2Vzc2lvblR5cGU6IHN0cmluZyxcbiAgICApIHt9XG5cbiAgICAvKipcbiAgICAgKiBnZXRzIHRoZSBjdXJyZW50IHNlc3Npb24gYnkgdGhlIGV4ZXJjaXNlSWRcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gZXhlcmNpc2VJZCBvZiB0aGUgZXhlcmNpc2VcbiAgICAgKiBAcmV0dXJuIHtPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT59IGFuIE9ic2VydmFibGUgb2YgdGhlIEhUVFAgcmVzcG9uc2VcbiAgICAgKi9cbiAgICBnZXRDdXJyZW50U2Vzc2lvbihleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxJcmlzU2Vzc2lvbj4oYCR7dGhpcy5hcGlQcmVmaXh9L3Byb2dyYW1taW5nLWV4ZXJjaXNlcy8ke2V4ZXJjaXNlSWR9LyR7dGhpcy5zZXNzaW9uVHlwZX0vY3VycmVudGAsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjcmVhdGVzIGEgc2Vzc2lvbiBmb3IgYSBwcm9ncmFtbWluZyBleGVyY2lzZVxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSBleGVyY2lzZUlkIG9mIHRoZSBzZXNzaW9uIGluIHdoaWNoIHRoZSBtZXNzYWdlIHNob3VsZCBiZSBjcmVhdGVkXG4gICAgICogQHJldHVybiB7T2JzZXJ2YWJsZTxFbnRpdHlSZXNwb25zZVR5cGU+fSBhbiBPYnNlcnZhYmxlIG9mIHRoZSBIVFRQIHJlc3BvbnNlc1xuICAgICAqL1xuICAgIGNyZWF0ZVNlc3Npb24oZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxJcmlzU2Vzc2lvbj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8bmV2ZXI+KGAke3RoaXMuYXBpUHJlZml4fS9wcm9ncmFtbWluZy1leGVyY2lzZXMvJHtleGVyY2lzZUlkfS8ke3RoaXMuc2Vzc2lvblR5cGV9YCwge30pO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IElyaXNNZXNzYWdlLCBJcmlzU2VydmVyTWVzc2FnZSwgSXJpc1VzZXJNZXNzYWdlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvaXJpcy1tZXNzYWdlLm1vZGVsJztcbmltcG9ydCB7IGNvbnZlcnREYXRlRnJvbUNsaWVudCwgY29udmVydERhdGVGcm9tU2VydmVyIH0gZnJvbSAnYXBwL3V0aWxzL2RhdGUudXRpbHMnO1xuaW1wb3J0IHsgbWFwLCB0YXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5cbmV4cG9ydCB0eXBlIFJlc3BvbnNlPFQ+ID0gT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+O1xuXG4vKipcbiAqIFByb3ZpZGVzIGEgc2V0IG9mIG1ldGhvZHMgdG8gcGVyZm9ybSBDUlVEIG9wZXJhdGlvbnMgb24gbWVzc2FnZXNcbiAqL1xuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBJcmlzSHR0cE1lc3NhZ2VTZXJ2aWNlIHtcbiAgICBwcm90ZWN0ZWQgYXBpUHJlZml4OiBzdHJpbmcgPSAnYXBpL2lyaXMnO1xuXG4gICAgcHJvdGVjdGVkIGNvbnN0cnVjdG9yKHByb3RlY3RlZCBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7fVxuXG4gICAgcHJvdGVjdGVkIHJhbmRvbUludCgpOiBudW1iZXIge1xuICAgICAgICBjb25zdCBtYXhJbnRKYXZhID0gMjE0NzQ4MzY0NztcbiAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIG1heEludEphdmEpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldHMgYWxsIG1lc3NhZ2VzIGZvciBhIHNlc3Npb24gYnkgaXRzIGlkXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IHNlc3Npb25JZFxuICAgICAqIEByZXR1cm4ge09ic2VydmFibGU8RW50aXR5QXJyYXlSZXNwb25zZVR5cGU+fVxuICAgICAqL1xuICAgIGdldE1lc3NhZ2VzKHNlc3Npb25JZDogbnVtYmVyKTogUmVzcG9uc2U8SXJpc01lc3NhZ2VbXT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwQ2xpZW50LmdldDxJcmlzTWVzc2FnZVtdPihgJHt0aGlzLmFwaVByZWZpeH0vc2Vzc2lvbnMvJHtzZXNzaW9uSWR9L21lc3NhZ2VzYCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgbWVzc2FnZXMgPSByZXNwb25zZS5ib2R5O1xuICAgICAgICAgICAgICAgIGlmICghbWVzc2FnZXMpIHJldHVybiByZXNwb25zZTtcblxuICAgICAgICAgICAgICAgIGNvbnN0IG1vZGlmaWVkTWVzc2FnZXMgPSBtZXNzYWdlcy5tYXAoKG1lc3NhZ2UpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oe30sIG1lc3NhZ2UsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbnRBdDogY29udmVydERhdGVGcm9tU2VydmVyKG1lc3NhZ2Uuc2VudEF0KSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7fSwgcmVzcG9uc2UsIHtcbiAgICAgICAgICAgICAgICAgICAgYm9keTogbW9kaWZpZWRNZXNzYWdlcyxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGNyZWF0ZXMgYSBuZXcgbWVzc2FnZSBpbiBhIHNlc3Npb25cbiAgICAgKiBAcGFyYW0gc2Vzc2lvbklkIG9mIHRoZSBzZXNzaW9uXG4gICAgICogQHBhcmFtIG1lc3NhZ2UgIHRvIGJlIGNyZWF0ZWRcbiAgICAgKi9cbiAgICBjcmVhdGVNZXNzYWdlKHNlc3Npb25JZDogbnVtYmVyLCBtZXNzYWdlOiBJcmlzVXNlck1lc3NhZ2UpOiBSZXNwb25zZTxJcmlzTWVzc2FnZT4ge1xuICAgICAgICBtZXNzYWdlLm1lc3NhZ2VEaWZmZXJlbnRpYXRvciA9IHRoaXMucmFuZG9tSW50KCk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBDbGllbnRcbiAgICAgICAgICAgIC5wb3N0PElyaXNTZXJ2ZXJNZXNzYWdlPihcbiAgICAgICAgICAgICAgICBgJHt0aGlzLmFwaVByZWZpeH0vc2Vzc2lvbnMvJHtzZXNzaW9uSWR9L21lc3NhZ2VzYCxcbiAgICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKHt9LCBtZXNzYWdlLCB7XG4gICAgICAgICAgICAgICAgICAgIHNlbnRBdDogY29udmVydERhdGVGcm9tQ2xpZW50KG1lc3NhZ2Uuc2VudEF0KSxcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICB7IG9ic2VydmU6ICdyZXNwb25zZScgfSxcbiAgICAgICAgICAgIClcbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmJvZHkgJiYgcmVzcG9uc2UuYm9keS5pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5pZCA9IHJlc3BvbnNlLmJvZHkuaWQ7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogcmVzZW5kcyBhIG1lc3NhZ2UgaW4gYSBzZXNzaW9uXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IHNlc3Npb25JZFxuICAgICAqIEBwYXJhbSB7SXJpc1VzZXJNZXNzYWdlfSBtZXNzYWdlXG4gICAgICogQHJldHVybiB7UmVzcG9uc2U8SXJpc01lc3NhZ2U+fVxuICAgICAqL1xuICAgIHJlc2VuZE1lc3NhZ2Uoc2Vzc2lvbklkOiBudW1iZXIsIG1lc3NhZ2U6IElyaXNVc2VyTWVzc2FnZSk6IFJlc3BvbnNlPElyaXNNZXNzYWdlPiB7XG4gICAgICAgIG1lc3NhZ2UubWVzc2FnZURpZmZlcmVudGlhdG9yID0gbWVzc2FnZS5tZXNzYWdlRGlmZmVyZW50aWF0b3IgPz8gdGhpcy5yYW5kb21JbnQoKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cENsaWVudC5wb3N0PElyaXNTZXJ2ZXJNZXNzYWdlPihgJHt0aGlzLmFwaVByZWZpeH0vc2Vzc2lvbnMvJHtzZXNzaW9uSWR9L21lc3NhZ2VzLyR7bWVzc2FnZS5pZH0vcmVzZW5kYCwgbnVsbCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmJvZHkgJiYgcmVzcG9uc2UuYm9keS5pZCkge1xuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmlkID0gcmVzcG9uc2UuYm9keS5pZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXRzIGEgaGVscGZ1bG5lc3MgcmF0aW5nIGZvciBhIG1lc3NhZ2VcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gc2Vzc2lvbklkIG9mIHRoZSBzZXNzaW9uIG9mIHRoZSBtZXNzYWdlIHRoYXQgc2hvdWxkIGJlIHJhdGVkXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IG1lc3NhZ2VJZCBvZiB0aGUgbWVzc2FnZSB0aGF0IHNob3VsZCBiZSByYXRlZFxuICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gaGVscGZ1bCByYXRpbmcgb2YgdGhlIG1lc3NhZ2VcbiAgICAgKiBAcmV0dXJuIHtPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT59IGFuIE9ic2VydmFibGUgb2YgdGhlIEhUVFAgcmVzcG9uc2VzXG4gICAgICovXG4gICAgcmF0ZU1lc3NhZ2Uoc2Vzc2lvbklkOiBudW1iZXIsIG1lc3NhZ2VJZDogbnVtYmVyLCBoZWxwZnVsOiBib29sZWFuKTogUmVzcG9uc2U8SXJpc01lc3NhZ2U+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cENsaWVudC5wdXQ8SXJpc01lc3NhZ2U+KGAke3RoaXMuYXBpUHJlZml4fS9zZXNzaW9ucy8ke3Nlc3Npb25JZH0vbWVzc2FnZXMvJHttZXNzYWdlSWR9L2hlbHBmdWwvJHtoZWxwZnVsfWAsIG51bGwsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJcmlzU3RhdGVTdG9yZSB9IGZyb20gJ2FwcC9pcmlzL3N0YXRlLXN0b3JlLnNlcnZpY2UnO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IENvbnZlcnNhdGlvbkVycm9yT2NjdXJyZWRBY3Rpb24sIFNlc3Npb25SZWNlaXZlZEFjdGlvbiB9IGZyb20gJ2FwcC9pcmlzL3N0YXRlLXN0b3JlLm1vZGVsJztcbmltcG9ydCB7IElyaXNIdHRwU2Vzc2lvblNlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9odHRwLXNlc3Npb24uc2VydmljZSc7XG5pbXBvcnQgeyBJcmlzU2Vzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL2lyaXMtc2Vzc2lvbi5tb2RlbCc7XG5pbXBvcnQgeyBJcmlzSHR0cE1lc3NhZ2VTZXJ2aWNlIH0gZnJvbSAnYXBwL2lyaXMvaHR0cC1tZXNzYWdlLnNlcnZpY2UnO1xuaW1wb3J0IHsgSXJpc01lc3NhZ2UsIElyaXNVc2VyTWVzc2FnZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL2lyaXMtbWVzc2FnZS5tb2RlbCc7XG5pbXBvcnQgeyBJcmlzRXJyb3JNZXNzYWdlS2V5IH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvaXJpcy1lcnJvcnMubW9kZWwnO1xuaW1wb3J0IHsgZmlyc3RWYWx1ZUZyb20gfSBmcm9tICdyeGpzJztcblxuLyoqXG4gKiBUaGUgSXJpc1Nlc3Npb25TZXJ2aWNlIGlzIHJlc3BvbnNpYmxlIGZvciBtYW5hZ2luZyBJcmlzIHNlc3Npb25zIGFuZCByZXRyaWV2aW5nIHRoZWlyIGFzc29jaWF0ZWQgbWVzc2FnZXMuXG4gKi9cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBJcmlzU2Vzc2lvblNlcnZpY2Uge1xuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYW4gaW5zdGFuY2Ugb2YgSXJpc1Nlc3Npb25TZXJ2aWNlLlxuICAgICAqIEBwYXJhbSBzdGF0ZVN0b3JlIFRoZSBJcmlzU3RhdGVTdG9yZSBmb3IgbWFuYWdpbmcgdGhlIHN0YXRlIG9mIHRoZSBhcHBsaWNhdGlvbi5cbiAgICAgKiBAcGFyYW0gaHR0cFNlc3Npb25TZXJ2aWNlIFRoZSBJcmlzSHR0cFNlc3Npb25TZXJ2aWNlIGZvciBIVFRQIG9wZXJhdGlvbnMgcmVsYXRlZCB0byBzZXNzaW9ucy5cbiAgICAgKiBAcGFyYW0gaHR0cE1lc3NhZ2VTZXJ2aWNlIFRoZSBJcmlzSHR0cE1lc3NhZ2VTZXJ2aWNlIGZvciBIVFRQIG9wZXJhdGlvbnMgcmVsYXRlZCB0byBtZXNzYWdlcy5cbiAgICAgKi9cbiAgICBwcm90ZWN0ZWQgY29uc3RydWN0b3IoXG4gICAgICAgIHByb3RlY3RlZCByZWFkb25seSBzdGF0ZVN0b3JlOiBJcmlzU3RhdGVTdG9yZSxcbiAgICAgICAgcHVibGljIGh0dHBTZXNzaW9uU2VydmljZTogSXJpc0h0dHBTZXNzaW9uU2VydmljZSxcbiAgICAgICAgcHVibGljIGh0dHBNZXNzYWdlU2VydmljZTogSXJpc0h0dHBNZXNzYWdlU2VydmljZSxcbiAgICApIHt9XG5cbiAgICAvKipcbiAgICAgKiBSZXRyaWV2ZXMgdGhlIGN1cnJlbnQgc2Vzc2lvbiBvciBjcmVhdGVzIGEgbmV3IG9uZSBpZiBpdCBkb2Vzbid0IGV4aXN0LlxuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkIFRoZSBleGVyY2lzZSBJRCB0byB3aGljaCB0aGUgc2Vzc2lvbiB3aWxsIGJlIGF0dGFjaGVkLlxuICAgICAqL1xuICAgIGdldEN1cnJlbnRTZXNzaW9uT3JDcmVhdGUoZXhlcmNpc2VJZDogbnVtYmVyKTogdm9pZCB7XG4gICAgICAgIGxldCBzZXNzaW9uSWQ6IG51bWJlcjtcblxuICAgICAgICBmaXJzdFZhbHVlRnJvbSh0aGlzLmh0dHBTZXNzaW9uU2VydmljZS5nZXRDdXJyZW50U2Vzc2lvbihleGVyY2lzZUlkKSlcbiAgICAgICAgICAgIC50aGVuKChpcmlzU2Vzc2lvblJlc3BvbnNlOiBIdHRwUmVzcG9uc2U8SXJpc1Nlc3Npb24+KSA9PiB7XG4gICAgICAgICAgICAgICAgc2Vzc2lvbklkID0gaXJpc1Nlc3Npb25SZXNwb25zZS5ib2R5IS5pZDtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmlyc3RWYWx1ZUZyb20odGhpcy5odHRwTWVzc2FnZVNlcnZpY2UuZ2V0TWVzc2FnZXMoc2Vzc2lvbklkKSlcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4oKG1lc3NhZ2VzUmVzcG9uc2U6IEh0dHBSZXNwb25zZTxJcmlzTWVzc2FnZVtdPikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbWVzc2FnZXMgPSBtZXNzYWdlc1Jlc3BvbnNlLmJvZHkhO1xuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZXMuc29ydCgoYSwgYikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhLnNlbnRBdCAmJiBiLnNlbnRBdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYS5zZW50QXQgPT09IGIuc2VudEF0KSByZXR1cm4gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGEuc2VudEF0LmlzQmVmb3JlKGIuc2VudEF0KSA/IC0xIDogMTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGlzcGF0Y2hTdWNjZXNzKHNlc3Npb25JZCwgbWVzc2FnZXMpO1xuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaXNwYXRjaEVycm9yKElyaXNFcnJvck1lc3NhZ2VLZXkuSElTVE9SWV9MT0FEX0ZBSUxFRCk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5jYXRjaCgoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGVycm9yLnN0YXR1cyA9PSA0MDQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY3JlYXRlTmV3U2Vzc2lvbihleGVyY2lzZUlkKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmRpc3BhdGNoRXJyb3IoSXJpc0Vycm9yTWVzc2FnZUtleS5TRVNTSU9OX0xPQURfRkFJTEVEKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGEgbmV3IHNlc3Npb24gZm9yIHRoZSBnaXZlbiBleGVyY2lzZSBJRC5cbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCBUaGUgZXhlcmNpc2UgSUQgZm9yIHdoaWNoIHRvIGNyZWF0ZSBhIG5ldyBzZXNzaW9uLlxuICAgICAqL1xuICAgIGNyZWF0ZU5ld1Nlc3Npb24oZXhlcmNpc2VJZDogbnVtYmVyKTogdm9pZCB7XG4gICAgICAgIHRoaXMuaHR0cFNlc3Npb25TZXJ2aWNlLmNyZWF0ZVNlc3Npb24oZXhlcmNpc2VJZCkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5leHQ6IChpcmlzU2Vzc2lvblJlc3BvbnNlOiBJcmlzU2Vzc2lvbikgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuZGlzcGF0Y2hTdWNjZXNzKGlyaXNTZXNzaW9uUmVzcG9uc2UuaWQsIFtdKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogKCkgPT4gdGhpcy5kaXNwYXRjaEVycm9yKElyaXNFcnJvck1lc3NhZ2VLZXkuU0VTU0lPTl9DUkVBVElPTl9GQUlMRUQpLFxuICAgICAgICAgICAgLy8gSWYgeW91IGhhdmUgYSBjb21wbGV0aW9uIGNhbGxiYWNrLCB5b3UgY2FuIGluY2x1ZGUgaXQgYXMgd2VsbFxuICAgICAgICAgICAgLy8gY29tcGxldGU6ICgpID0+IHsgLyogY29tcGxldGlvbiBsb2dpYyBoZXJlICovIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBzZXJ2ZXIgYW5kIHJldHVybnMgdGhlIGNyZWF0ZWQgbWVzc2FnZS5cbiAgICAgKiBAcGFyYW0gc2Vzc2lvbklkIG9mIHRoZSBzZXNzaW9uIGluIHdoaWNoIHRoZSBtZXNzYWdlIHNob3VsZCBiZSBjcmVhdGVkXG4gICAgICogQHBhcmFtIG1lc3NhZ2UgdG8gYmUgY3JlYXRlZFxuICAgICAqL1xuICAgIGFzeW5jIHNlbmRNZXNzYWdlKHNlc3Npb25JZDogbnVtYmVyLCBtZXNzYWdlOiBJcmlzVXNlck1lc3NhZ2UpOiBQcm9taXNlPElyaXNNZXNzYWdlPiB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmlyc3RWYWx1ZUZyb20odGhpcy5odHRwTWVzc2FnZVNlcnZpY2UuY3JlYXRlTWVzc2FnZShzZXNzaW9uSWQsIG1lc3NhZ2UpKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmJvZHkhO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlc2VuZHMgYSBtZXNzYWdlIHRvIHRoZSBzZXJ2ZXIgYW5kIHJldHVybnMgdGhlIGNyZWF0ZWQgbWVzc2FnZS5cbiAgICAgKiBAcGFyYW0gc2Vzc2lvbklkIG9mIHRoZSBzZXNzaW9uIGluIHdoaWNoIHRoZSBtZXNzYWdlIHNob3VsZCBiZSBjcmVhdGVkXG4gICAgICogQHBhcmFtIG1lc3NhZ2UgdG8gYmUgY3JlYXRlZFxuICAgICAqL1xuICAgIGFzeW5jIHJlc2VuZE1lc3NhZ2Uoc2Vzc2lvbklkOiBudW1iZXIsIG1lc3NhZ2U6IElyaXNVc2VyTWVzc2FnZSk6IFByb21pc2U8SXJpc01lc3NhZ2U+IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmaXJzdFZhbHVlRnJvbSh0aGlzLmh0dHBNZXNzYWdlU2VydmljZS5yZXNlbmRNZXNzYWdlKHNlc3Npb25JZCwgbWVzc2FnZSkpO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuYm9keSE7XG4gICAgfVxuXG4gICAgYXN5bmMgcmF0ZU1lc3NhZ2Uoc2Vzc2lvbklkOiBudW1iZXIsIG1lc3NhZ2VJZDogbnVtYmVyLCBoZWxwZnVsOiBib29sZWFuKTogUHJvbWlzZTxJcmlzTWVzc2FnZT4ge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZpcnN0VmFsdWVGcm9tKHRoaXMuaHR0cE1lc3NhZ2VTZXJ2aWNlLnJhdGVNZXNzYWdlKHNlc3Npb25JZCwgbWVzc2FnZUlkLCBoZWxwZnVsKSk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5ib2R5ITtcbiAgICB9XG5cbiAgICBwcml2YXRlIGRpc3BhdGNoU3VjY2VzcyhzZXNzaW9uSWQ6IG51bWJlciwgbWVzc2FnZXM6IElyaXNNZXNzYWdlW10pOiB2b2lkIHtcbiAgICAgICAgdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKG5ldyBTZXNzaW9uUmVjZWl2ZWRBY3Rpb24oc2Vzc2lvbklkLCBtZXNzYWdlcykpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERpc3BhdGNoZXMgYW4gZXJyb3IgYWN0aW9uIHdpdGggdGhlIHNwZWNpZmllZCBlcnJvciBtZXNzYWdlLlxuICAgICAqIEBwYXJhbSBlcnJvciBUaGUgZXJyb3IgbWVzc2FnZS5cbiAgICAgKi9cbiAgICBwcml2YXRlIGRpc3BhdGNoRXJyb3IoZXJyb3I6IElyaXNFcnJvck1lc3NhZ2VLZXkpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKG5ldyBDb252ZXJzYXRpb25FcnJvck9jY3VycmVkQWN0aW9uKGVycm9yKSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSXJpc0h0dHBNZXNzYWdlU2VydmljZSB9IGZyb20gJ2FwcC9pcmlzL2h0dHAtbWVzc2FnZS5zZXJ2aWNlJztcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBJcmlzSHR0cENoYXRNZXNzYWdlU2VydmljZSBleHRlbmRzIElyaXNIdHRwTWVzc2FnZVNlcnZpY2Uge31cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IElyaXNIdHRwU2Vzc2lvblNlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9odHRwLXNlc3Npb24uc2VydmljZSc7XG5pbXBvcnQgeyBJcmlzUmF0ZUxpbWl0SW5mb3JtYXRpb24gfSBmcm9tICdhcHAvaXJpcy93ZWJzb2NrZXQuc2VydmljZSc7XG5cbmV4cG9ydCBjbGFzcyBIZWFydGJlYXREVE8ge1xuICAgIGFjdGl2ZTogYm9vbGVhbjtcbiAgICByYXRlTGltaXRJbmZvOiBJcmlzUmF0ZUxpbWl0SW5mb3JtYXRpb247XG59XG4vKipcbiAqIFRoZSBgSXJpc0h0dHBDaGF0U2Vzc2lvblNlcnZpY2VgIHByb3ZpZGVzIG1ldGhvZHMgZm9yIHJldHJpZXZpbmcgZXhpc3Rpbmcgb3IgY3JlYXRpbmcgbmV3IElyaXMgY2hhdCBzZXNzaW9ucy5cbiAqIEl0IGludGVyYWN0cyB3aXRoIHRoZSBzZXJ2ZXItc2lkZSBBUEkgdG8gcGVyZm9ybSBzZXNzaW9uLXJlbGF0ZWQgb3BlcmF0aW9ucy5cbiAqL1xuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBJcmlzSHR0cENoYXRTZXNzaW9uU2VydmljZSBleHRlbmRzIElyaXNIdHRwU2Vzc2lvblNlcnZpY2Uge1xuICAgIHByb3RlY3RlZCBjb25zdHJ1Y3RvcihodHRwOiBIdHRwQ2xpZW50KSB7XG4gICAgICAgIHN1cGVyKGh0dHAsICdzZXNzaW9ucycpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHJpZXZlcyB0aGUgaGVhcnRiZWF0IHN0YXR1cyBvZiBhIHNlc3Npb24uXG4gICAgICogQHBhcmFtIHNlc3Npb25JZCBUaGUgSUQgb2YgdGhlIHNlc3Npb24gdG8gY2hlY2suXG4gICAgICogQHJldHVybiBBbiBPYnNlcnZhYmxlIG9mIHRoZSBIVFRQIHJlc3BvbnNlIGNvbnRhaW5pbmcgYSBib29sZWFuIHZhbHVlIGluZGljYXRpbmcgdGhlIHNlc3Npb24ncyBoZWFydGJlYXQgc3RhdHVzLlxuICAgICAqL1xuICAgIGdldEhlYXJ0YmVhdChzZXNzaW9uSWQ6IG51bWJlcik6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPEhlYXJ0YmVhdERUTz4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8SGVhcnRiZWF0RFRPPihgJHt0aGlzLmFwaVByZWZpeH0vJHt0aGlzLnNlc3Npb25UeXBlfS8ke3Nlc3Npb25JZH0vYWN0aXZlYCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IElyaXNTdGF0ZVN0b3JlIH0gZnJvbSAnYXBwL2lyaXMvc3RhdGUtc3RvcmUuc2VydmljZSc7XG5pbXBvcnQgeyBJcmlzU2Vzc2lvblNlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9zZXNzaW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgSXJpc0h0dHBDaGF0TWVzc2FnZVNlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9odHRwLWNoYXQtbWVzc2FnZS5zZXJ2aWNlJztcbmltcG9ydCB7IElyaXNIdHRwQ2hhdFNlc3Npb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2lyaXMvaHR0cC1jaGF0LXNlc3Npb24uc2VydmljZSc7XG5cbi8qKlxuICogVGhlIElyaXNDaGF0U2Vzc2lvblNlcnZpY2UgaXMgcmVzcG9uc2libGUgZm9yIG1hbmFnaW5nIElyaXMgY2hhdCBzZXNzaW9ucyBhbmQgcmV0cmlldmluZyB0aGVpciBhc3NvY2lhdGVkIG1lc3NhZ2VzLlxuICovXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgSXJpc0NoYXRTZXNzaW9uU2VydmljZSBleHRlbmRzIElyaXNTZXNzaW9uU2VydmljZSB7XG4gICAgLyoqXG4gICAgICogVXNlcyB0aGUgSXJpc0h0dHBDaGF0U2Vzc2lvblNlcnZpY2UgYW5kIElyaXNIdHRwQ2hhdE1lc3NhZ2VTZXJ2aWNlIHRvIHJldHJpZXZlIGFuZCBtYW5hZ2UgSXJpcyBjaGF0IHNlc3Npb25zLlxuICAgICAqL1xuICAgIGNvbnN0cnVjdG9yKHN0YXRlU3RvcmU6IElyaXNTdGF0ZVN0b3JlLCBpcmlzU2Vzc2lvblNlcnZpY2U6IElyaXNIdHRwQ2hhdFNlc3Npb25TZXJ2aWNlLCBpcmlzSHR0cENoYXRNZXNzYWdlU2VydmljZTogSXJpc0h0dHBDaGF0TWVzc2FnZVNlcnZpY2UpIHtcbiAgICAgICAgc3VwZXIoc3RhdGVTdG9yZSwgaXJpc1Nlc3Npb25TZXJ2aWNlLCBpcmlzSHR0cENoYXRNZXNzYWdlU2VydmljZSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IElyaXNIdHRwU2Vzc2lvblNlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9odHRwLXNlc3Npb24uc2VydmljZSc7XG5cbi8qKlxuICogVGhlIGBJcmlzSHR0cENvZGVFZGl0b3JTZXNzaW9uU2VydmljZWAgcHJvdmlkZXMgbWV0aG9kcyBmb3IgcmV0cmlldmluZyBleGlzdGluZyBvciBjcmVhdGluZyBuZXcgSXJpcyBzZXNzaW9ucy5cbiAqIEl0IGludGVyYWN0cyB3aXRoIHRoZSBzZXJ2ZXItc2lkZSBBUEkgdG8gcGVyZm9ybSBzZXNzaW9uLXJlbGF0ZWQgb3BlcmF0aW9ucy5cbiAqL1xuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBJcmlzSHR0cENvZGVFZGl0b3JTZXNzaW9uU2VydmljZSBleHRlbmRzIElyaXNIdHRwU2Vzc2lvblNlcnZpY2Uge1xuICAgIGNvbnN0cnVjdG9yKHByb3RlY3RlZCBodHRwOiBIdHRwQ2xpZW50KSB7XG4gICAgICAgIHN1cGVyKGh0dHAsICdjb2RlLWVkaXRvci1zZXNzaW9ucycpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IElyaXNFeGVyY2lzZVBsYW5TdGVwIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvaXJpcy1jb250ZW50LXR5cGUubW9kZWwnO1xuaW1wb3J0IHsgSXJpc0h0dHBNZXNzYWdlU2VydmljZSwgUmVzcG9uc2UgfSBmcm9tICdhcHAvaXJpcy9odHRwLW1lc3NhZ2Uuc2VydmljZSc7XG5cbi8qKlxuICogUHJvdmlkZXMgYW4gYWRkaXRpb25hbCBzZXQgb2YgbWV0aG9kcyBzcGVjaWZpYyB0byB0aGUgQ29kZSBFZGl0b3IgQ2hhdGJvdC5cbiAqL1xuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBJcmlzSHR0cENvZGVFZGl0b3JNZXNzYWdlU2VydmljZSBleHRlbmRzIElyaXNIdHRwTWVzc2FnZVNlcnZpY2Uge1xuICAgIHByaXZhdGUgcmVhZG9ubHkgc2Vzc2lvblR5cGUgPSAnY29kZS1lZGl0b3Itc2Vzc2lvbnMnO1xuXG4gICAgLyoqXG4gICAgICogRXhlY3V0ZSB0aGUgZXhlcmNpc2UgcGxhbiwgaS5lLiByZXF1ZXN0IHRoZSBjaGFuZ2VzIHRvIGJlIGFwcGxpZWQgdG8gdGhlIGNvZGUgZWRpdG9yLlxuICAgICAqXG4gICAgICogQHBhcmFtIHNlc3Npb25JZCBvZiB0aGUgc2Vzc2lvblxuICAgICAqIEBwYXJhbSBtZXNzYWdlSWQgb2YgdGhlIG1lc3NhZ2VcbiAgICAgKiBAcGFyYW0gcGxhbklkIG9mIHRoZSBleGVyY2lzZSBwbGFuXG4gICAgICogQHBhcmFtIHN0ZXBJZCBvZiB0aGUgZXhlcmNpc2UgcGxhbiBzdGVwXG4gICAgICovXG4gICAgZXhlY3V0ZVBsYW5TdGVwKHNlc3Npb25JZDogbnVtYmVyLCBtZXNzYWdlSWQ6IG51bWJlciwgcGxhbklkOiBudW1iZXIsIHN0ZXBJZDogbnVtYmVyKTogUmVzcG9uc2U8dm9pZD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwQ2xpZW50LnBvc3Q8dm9pZD4oYCR7dGhpcy5hcGlQcmVmaXh9LyR7dGhpcy5zZXNzaW9uVHlwZX0vJHtzZXNzaW9uSWR9L21lc3NhZ2VzLyR7bWVzc2FnZUlkfS9jb250ZW50cy8ke3BsYW5JZH0vc3RlcHMvJHtzdGVwSWR9L2V4ZWN1dGVgLCBudWxsLCB7XG4gICAgICAgICAgICBvYnNlcnZlOiAncmVzcG9uc2UnLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVcGRhdGUgYSBjb21wb25lbnQgb2YgYW4gZXhlcmNpc2UgcGxhblxuICAgICAqIEBwYXJhbSBzZXNzaW9uSWQgICAgIG9mIHRoZSBzZXNzaW9uXG4gICAgICogQHBhcmFtIG1lc3NhZ2VJZCAgICAgb2YgdGhlIG1lc3NhZ2VcbiAgICAgKiBAcGFyYW0gcGxhbklkICAgICAgICBvZiB0aGUgZXhlcmNpc2UgcGxhblxuICAgICAqIEBwYXJhbSBzdGVwSWQgICAgICAgIG9mIHRoZSBleGVyY2lzZSBwbGFuIHN0ZXBcbiAgICAgKiBAcGFyYW0gdXBkYXRlZFN0ZXAgICB0aGUgc3RlcCB3aXRoIHRoZSB1cGRhdGVkIGluc3RydWN0aW9uc1xuICAgICAqIEByZXR1cm4ge1Jlc3BvbnNlPElyaXNFeGVyY2lzZVBsYW5TdGVwPn0gYW4gT2JzZXJ2YWJsZSBvZiB0aGUgSFRUUCByZXNwb25zZXNcbiAgICAgKi9cbiAgICB1cGRhdGVFeGVyY2lzZVBsYW5TdGVwSW5zdHJ1Y3Rpb25zKHNlc3Npb25JZDogbnVtYmVyLCBtZXNzYWdlSWQ6IG51bWJlciwgcGxhbklkOiBudW1iZXIsIHN0ZXBJZDogbnVtYmVyLCB1cGRhdGVkU3RlcDogSXJpc0V4ZXJjaXNlUGxhblN0ZXApOiBSZXNwb25zZTxJcmlzRXhlcmNpc2VQbGFuU3RlcD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwQ2xpZW50LnB1dDxJcmlzRXhlcmNpc2VQbGFuU3RlcD4oXG4gICAgICAgICAgICBgJHt0aGlzLmFwaVByZWZpeH0vJHt0aGlzLnNlc3Npb25UeXBlfS8ke3Nlc3Npb25JZH0vbWVzc2FnZXMvJHttZXNzYWdlSWR9L2NvbnRlbnRzLyR7cGxhbklkfS9zdGVwcy8ke3N0ZXBJZH1gLFxuICAgICAgICAgICAgdXBkYXRlZFN0ZXAsXG4gICAgICAgICAgICB7IG9ic2VydmU6ICdyZXNwb25zZScgfSxcbiAgICAgICAgKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJcmlzU3RhdGVTdG9yZSB9IGZyb20gJ2FwcC9pcmlzL3N0YXRlLXN0b3JlLnNlcnZpY2UnO1xuaW1wb3J0IHsgSXJpc1Nlc3Npb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2lyaXMvc2Vzc2lvbi5zZXJ2aWNlJztcbmltcG9ydCB7IElyaXNIdHRwQ29kZUVkaXRvclNlc3Npb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2lyaXMvaHR0cC1jb2RlLWVkaXRvci1zZXNzaW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgSXJpc0h0dHBDb2RlRWRpdG9yTWVzc2FnZVNlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9odHRwLWNvZGUtZWRpdG9yLW1lc3NhZ2Uuc2VydmljZSc7XG5pbXBvcnQgeyBmaXJzdFZhbHVlRnJvbSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgSXJpc0V4ZXJjaXNlUGxhblN0ZXAgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9pcmlzLWNvbnRlbnQtdHlwZS5tb2RlbCc7XG5cbi8qKlxuICogVGhlIElyaXNDb2RlRWRpdG9yU2Vzc2lvblNlcnZpY2UgaXMgcmVzcG9uc2libGUgZm9yIG1hbmFnaW5nIElyaXMgY29kZSBlZGl0b3Igc2Vzc2lvbnMgYW5kIHJldHJpZXZpbmcgdGhlaXIgYXNzb2NpYXRlZCBtZXNzYWdlcy5cbiAqL1xuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIElyaXNDb2RlRWRpdG9yU2Vzc2lvblNlcnZpY2UgZXh0ZW5kcyBJcmlzU2Vzc2lvblNlcnZpY2Uge1xuICAgIC8qKlxuICAgICAqIFVzZXMgdGhlIElyaXNIdHRwQ29kZUVkaXRvclNlc3Npb25TZXJ2aWNlIGFuZCBJcmlzSHR0cENvZGVFZGl0b3JNZXNzYWdlU2VydmljZSB0byByZXRyaWV2ZSBhbmQgbWFuYWdlIElyaXMgY29kZSBlZGl0b3Igc2Vzc2lvbnMuXG4gICAgICovXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHN0YXRlU3RvcmU6IElyaXNTdGF0ZVN0b3JlLFxuICAgICAgICBpcmlzU2Vzc2lvblNlcnZpY2U6IElyaXNIdHRwQ29kZUVkaXRvclNlc3Npb25TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGlyaXNIdHRwQ29kZUVkaXRvck1lc3NhZ2VTZXJ2aWNlOiBJcmlzSHR0cENvZGVFZGl0b3JNZXNzYWdlU2VydmljZSxcbiAgICApIHtcbiAgICAgICAgc3VwZXIoc3RhdGVTdG9yZSwgaXJpc1Nlc3Npb25TZXJ2aWNlLCBpcmlzSHR0cENvZGVFZGl0b3JNZXNzYWdlU2VydmljZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRXhlY3V0ZXMgb25lIHN0ZXAgb2YgYW4gZXhlcmNpc2UgcGxhbi5cbiAgICAgKiBAcGFyYW0gc2Vzc2lvbklkIG9mIHRoZSBzZXNzaW9uIGluIHdoaWNoIHRoZSBleGVyY2lzZSBwbGFuIGV4aXN0c1xuICAgICAqIEBwYXJhbSBtZXNzYWdlSWQgb2YgdGhlIG1lc3NhZ2Ugd2hpY2ggY29udGFpbnMgdGhlIGV4ZXJjaXNlIHBsYW5cbiAgICAgKiBAcGFyYW0gcGxhbklkIG9mIHRoZSBleGVyY2lzZSBwbGFuXG4gICAgICogQHBhcmFtIHN0ZXBJZCBvZiB0aGUgc3RlcCB0byBiZSBleGVjdXRlZFxuICAgICAqL1xuICAgIGFzeW5jIGV4ZWN1dGVQbGFuU3RlcChzZXNzaW9uSWQ6IG51bWJlciwgbWVzc2FnZUlkOiBudW1iZXIsIHBsYW5JZDogbnVtYmVyLCBzdGVwSWQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICAgICAgICBhd2FpdCBmaXJzdFZhbHVlRnJvbSh0aGlzLmlyaXNIdHRwQ29kZUVkaXRvck1lc3NhZ2VTZXJ2aWNlLmV4ZWN1dGVQbGFuU3RlcChzZXNzaW9uSWQsIG1lc3NhZ2VJZCwgcGxhbklkLCBzdGVwSWQpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVcGRhdGVzIHRoZSBpbnN0cnVjdGlvbnMgb2YgYW4gZXhlcmNpc2UgcGxhbiBzdGVwIGFuZCByZXR1cm5zIHRoZSB1cGRhdGVkIHN0ZXAuXG4gICAgICogQHBhcmFtIHNlc3Npb25JZCBvZiB0aGUgc2Vzc2lvbiBpbiB3aGljaCB0aGUgZXhlcmNpc2UgcGxhbiBleGlzdHNcbiAgICAgKiBAcGFyYW0gbWVzc2FnZUlkIG9mIHRoZSBtZXNzYWdlIHdoaWNoIGNvbnRhaW5zIHRoZSBleGVyY2lzZSBwbGFuXG4gICAgICogQHBhcmFtIHBsYW5JZCBvZiB0aGUgZXhlcmNpc2UgcGxhblxuICAgICAqIEBwYXJhbSBzdGVwSWQgb2YgdGhlIHN0ZXAgdG8gYmUgdXBkYXRlZFxuICAgICAqIEBwYXJhbSBzdGVwIHdpdGggdGhlIHVwZGF0ZWQgaW5zdHJ1Y3Rpb25zXG4gICAgICovXG4gICAgYXN5bmMgdXBkYXRlUGxhblN0ZXBJbnN0cnVjdGlvbnMoc2Vzc2lvbklkOiBudW1iZXIsIG1lc3NhZ2VJZDogbnVtYmVyLCBwbGFuSWQ6IG51bWJlciwgc3RlcElkOiBudW1iZXIsIHN0ZXA6IElyaXNFeGVyY2lzZVBsYW5TdGVwKTogUHJvbWlzZTxJcmlzRXhlcmNpc2VQbGFuU3RlcD4ge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZpcnN0VmFsdWVGcm9tKHRoaXMuaXJpc0h0dHBDb2RlRWRpdG9yTWVzc2FnZVNlcnZpY2UudXBkYXRlRXhlcmNpc2VQbGFuU3RlcEluc3RydWN0aW9ucyhzZXNzaW9uSWQsIG1lc3NhZ2VJZCwgcGxhbklkLCBzdGVwSWQsIHN0ZXApKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmJvZHkhO1xuICAgIH1cbn1cbiIsImltcG9ydCB7XG4gICAgZmFBcnJvd0Rvd24sXG4gICAgZmFDaXJjbGUsXG4gICAgZmFDaXJjbGVJbmZvLFxuICAgIGZhQ29tcHJlc3MsXG4gICAgZmFFeHBhbmQsXG4gICAgZmFQYXBlclBsYW5lLFxuICAgIGZhUmVkbyxcbiAgICBmYVJvYm90LFxuICAgIGZhVGh1bWJzRG93bixcbiAgICBmYVRodW1ic1VwLFxuICAgIGZhVHJhc2gsXG4gICAgZmFYbWFyayxcbn0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IE5hdmlnYXRpb25TdGFydCwgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IE5nYk1vZGFsIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xuaW1wb3J0IHsgQnV0dG9uVHlwZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9idXR0b24uY29tcG9uZW50JztcbmltcG9ydCB7IEFmdGVyVmlld0luaXQsIENvbXBvbmVudCwgRWxlbWVudFJlZiwgSW5qZWN0LCBPbkRlc3Ryb3ksIE9uSW5pdCwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNQVRfRElBTE9HX0RBVEEsIE1hdERpYWxvZyB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2RpYWxvZyc7XG5pbXBvcnQgeyBJcmlzU3RhdGVTdG9yZSB9IGZyb20gJ2FwcC9pcmlzL3N0YXRlLXN0b3JlLnNlcnZpY2UnO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQge1xuICAgIEFjdGl2ZUNvbnZlcnNhdGlvbk1lc3NhZ2VMb2FkZWRBY3Rpb24sXG4gICAgQ29udmVyc2F0aW9uRXJyb3JPY2N1cnJlZEFjdGlvbixcbiAgICBOdW1OZXdNZXNzYWdlc1Jlc2V0QWN0aW9uLFxuICAgIFJhdGVNZXNzYWdlU3VjY2Vzc0FjdGlvbixcbiAgICBTdHVkZW50TWVzc2FnZVNlbnRBY3Rpb24sXG59IGZyb20gJ2FwcC9pcmlzL3N0YXRlLXN0b3JlLm1vZGVsJztcbmltcG9ydCB7XG4gICAgSXJpc0FydGVtaXNDbGllbnRNZXNzYWdlLFxuICAgIElyaXNNZXNzYWdlLFxuICAgIElyaXNTZW5kZXIsXG4gICAgSXJpc1VzZXJNZXNzYWdlLFxuICAgIGlzQXJ0ZW1pc0NsaWVudFNlbnRNZXNzYWdlLFxuICAgIGlzU2VydmVyU2VudE1lc3NhZ2UsXG4gICAgaXNTdHVkZW50U2VudE1lc3NhZ2UsXG59IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL2lyaXMtbWVzc2FnZS5tb2RlbCc7XG5pbXBvcnQge1xuICAgIEV4ZWN1dGlvblN0YWdlLFxuICAgIEV4ZXJjaXNlQ29tcG9uZW50LFxuICAgIElyaXNFeGVyY2lzZVBsYW4sXG4gICAgSXJpc0V4ZXJjaXNlUGxhblN0ZXAsXG4gICAgSXJpc01lc3NhZ2VDb250ZW50LFxuICAgIElyaXNNZXNzYWdlQ29udGVudFR5cGUsXG4gICAgSXJpc1RleHRNZXNzYWdlQ29udGVudCxcbiAgICBnZXRUZXh0Q29udGVudCxcbiAgICBoaWRlT3JVbmhpZGUsXG4gICAgaXNDb21wbGV0ZSxcbiAgICBpc0V4ZXJjaXNlUGxhbixcbiAgICBpc0ZhaWxlZCxcbiAgICBpc0hpZGRlbixcbiAgICBpc0luUHJvZ3Jlc3MsXG4gICAgaXNOb3RFeGVjdXRlZCxcbiAgICBpc1RleHRDb250ZW50LFxufSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9pcmlzLWNvbnRlbnQtdHlwZS5tb2RlbCc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IFNoYXJlZFNlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9zaGFyZWQuc2VydmljZSc7XG5pbXBvcnQgeyBJcmlzU2Vzc2lvblNlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9zZXNzaW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgSXJpc0Vycm9yTWVzc2FnZUtleSwgSXJpc0Vycm9yVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL2lyaXMtZXJyb3JzLm1vZGVsJztcbmltcG9ydCBkYXlqcyBmcm9tICdkYXlqcy9lc20nO1xuaW1wb3J0IHsgQW5pbWF0aW9uRXZlbnQsIGFuaW1hdGUsIHN0YXRlLCBzdHlsZSwgdHJhbnNpdGlvbiwgdHJpZ2dlciB9IGZyb20gJ0Bhbmd1bGFyL2FuaW1hdGlvbnMnO1xuaW1wb3J0IHsgVXNlclNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS91c2VyL3VzZXIuc2VydmljZSc7XG5pbXBvcnQgeyBJcmlzTG9nb1NpemUgfSBmcm9tICcuLi8uLi9pcmlzLWxvZ28vaXJpcy1sb2dvLmNvbXBvbmVudCc7XG5pbXBvcnQgaW50ZXJhY3QgZnJvbSAnaW50ZXJhY3Rqcyc7XG5pbXBvcnQgeyBET0NVTUVOVCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBJcmlzQ2hhdFNlc3Npb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2lyaXMvY2hhdC1zZXNzaW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgVHJhbnNsYXRlU2VydmljZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xuaW1wb3J0IHsgSXJpc0NvZGVFZGl0b3JTZXNzaW9uU2VydmljZSB9IGZyb20gJ2FwcC9pcmlzL2NvZGUtZWRpdG9yLXNlc3Npb24uc2VydmljZSc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWNoYXRib3Qtd2lkZ2V0JyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vY2hhdGJvdC13aWRnZXQuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL2NoYXRib3Qtd2lkZ2V0LmNvbXBvbmVudC5zY3NzJ10sXG4gICAgYW5pbWF0aW9uczogW1xuICAgICAgICB0cmlnZ2VyKCdmYWRlQW5pbWF0aW9uJywgW1xuICAgICAgICAgICAgc3RhdGUoXG4gICAgICAgICAgICAgICAgJ3N0YXJ0JyxcbiAgICAgICAgICAgICAgICBzdHlsZSh7XG4gICAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDEsXG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICApLFxuICAgICAgICAgICAgc3RhdGUoXG4gICAgICAgICAgICAgICAgJ2VuZCcsXG4gICAgICAgICAgICAgICAgc3R5bGUoe1xuICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLFxuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgKSxcbiAgICAgICAgICAgIHRyYW5zaXRpb24oJ3N0YXJ0ID0+IGVuZCcsIFthbmltYXRlKCcycyBlYXNlJyldKSxcbiAgICAgICAgXSksXG4gICAgXSxcbn0pXG5leHBvcnQgY2xhc3MgSXJpc0NoYXRib3RXaWRnZXRDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSwgQWZ0ZXJWaWV3SW5pdCB7XG4gICAgLy8gSWNvbnNcbiAgICBmYVRyYXNoID0gZmFUcmFzaDtcbiAgICBmYUNpcmNsZSA9IGZhQ2lyY2xlO1xuICAgIGZhUGFwZXJQbGFuZSA9IGZhUGFwZXJQbGFuZTtcbiAgICBmYUV4cGFuZCA9IGZhRXhwYW5kO1xuICAgIGZhWG1hcmsgPSBmYVhtYXJrO1xuICAgIGZhQXJyb3dEb3duID0gZmFBcnJvd0Rvd247XG4gICAgZmFSb2JvdCA9IGZhUm9ib3Q7XG4gICAgZmFDaXJjbGVJbmZvID0gZmFDaXJjbGVJbmZvO1xuICAgIGZhQ29tcHJlc3MgPSBmYUNvbXByZXNzO1xuICAgIGZhVGh1bWJzVXAgPSBmYVRodW1ic1VwO1xuICAgIGZhVGh1bWJzRG93biA9IGZhVGh1bWJzRG93bjtcbiAgICBmYVJlZG8gPSBmYVJlZG87XG5cbiAgICAvLyBWaWV3Q2hpbGRzXG4gICAgQFZpZXdDaGlsZCgnY2hhdEJvZHknKSBjaGF0Qm9keSE6IEVsZW1lbnRSZWY7XG4gICAgQFZpZXdDaGlsZCgnc2Nyb2xsQXJyb3cnKSBzY3JvbGxBcnJvdyE6IEVsZW1lbnRSZWY7XG4gICAgQFZpZXdDaGlsZCgnbWVzc2FnZVRleHRhcmVhJywgeyBzdGF0aWM6IGZhbHNlIH0pIG1lc3NhZ2VUZXh0YXJlYTogRWxlbWVudFJlZjxIVE1MVGV4dEFyZWFFbGVtZW50PjtcbiAgICBAVmlld0NoaWxkKCd1bnJlYWRNZXNzYWdlJywgeyBzdGF0aWM6IGZhbHNlIH0pIHVucmVhZE1lc3NhZ2UhOiBFbGVtZW50UmVmO1xuXG4gICAgLy8gU3RhdGUgdmFyaWFibGVzXG4gICAgc3RhdGVTdG9yZTogSXJpc1N0YXRlU3RvcmU7XG4gICAgc3RhdGVTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcbiAgICBtZXNzYWdlczogSXJpc01lc3NhZ2VbXSA9IFtdO1xuICAgIGNvbnRlbnQ6IElyaXNNZXNzYWdlQ29udGVudDtcbiAgICBuZXdNZXNzYWdlVGV4dENvbnRlbnQgPSAnJztcbiAgICBpc0xvYWRpbmc6IGJvb2xlYW47XG4gICAgc2Vzc2lvbklkOiBudW1iZXI7XG4gICAgbnVtTmV3TWVzc2FnZXMgPSAwO1xuICAgIHVucmVhZE1lc3NhZ2VJbmRleDogbnVtYmVyO1xuICAgIGVycm9yOiBJcmlzRXJyb3JUeXBlIHwgbnVsbDtcbiAgICBkb3RzID0gMTtcbiAgICByZXNlbmRBbmltYXRpb25BY3RpdmUgPSBmYWxzZTtcbiAgICBzaGFrZUVycm9yRmllbGQgPSBmYWxzZTtcbiAgICBzaG91bGRMb2FkR3JlZXRpbmdNZXNzYWdlID0gdHJ1ZTtcbiAgICBmYWRlU3RhdGUgPSAnJztcbiAgICBjb3Vyc2VJZDogbnVtYmVyO1xuICAgIGV4ZXJjaXNlSWQ6IG51bWJlcjtcbiAgICBzZXNzaW9uU2VydmljZTogSXJpc1Nlc3Npb25TZXJ2aWNlO1xuICAgIHNob3VsZFNob3dFbXB0eU1lc3NhZ2VFcnJvciA9IGZhbHNlO1xuICAgIGN1cnJlbnRNZXNzYWdlQ291bnQ6IG51bWJlcjtcbiAgICByYXRlTGltaXQ6IG51bWJlcjtcbiAgICByYXRlTGltaXRUaW1lZnJhbWVIb3VyczogbnVtYmVyO1xuICAgIGltcG9ydEV4ZXJjaXNlVXJsOiBzdHJpbmc7XG5cbiAgICAvLyBVc2VyIHByZWZlcmVuY2VzXG4gICAgdXNlckFjY2VwdGVkOiBib29sZWFuO1xuICAgIGlzU2Nyb2xsZWRUb0JvdHRvbSA9IHRydWU7XG4gICAgcm93cyA9IDE7XG4gICAgaW5pdGlhbFdpZHRoID0gMzMwO1xuICAgIGluaXRpYWxIZWlnaHQgPSA0MzA7XG4gICAgZnVsbFdpZHRoRmFjdG9yID0gMC45MztcbiAgICBmdWxsSGVpZ2h0RmFjdG9yID0gMC44NTtcbiAgICBmdWxsU2l6ZSA9IGZhbHNlO1xuICAgIHB1YmxpYyBCdXR0b25UeXBlID0gQnV0dG9uVHlwZTtcbiAgICByZWFkb25seSBJcmlzTG9nb1NpemUgPSBJcmlzTG9nb1NpemU7XG4gICAgcHJpdmF0ZSBuYXZpZ2F0aW9uU3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb247XG4gICAgcHJpdmF0ZSByZWFkb25seSBNQVhfSU5UX0pBVkEgPSAyMTQ3NDgzNjQ3O1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgZGlhbG9nOiBNYXREaWFsb2csXG4gICAgICAgIEBJbmplY3QoTUFUX0RJQUxPR19EQVRBKSBwdWJsaWMgZGF0YTogYW55LFxuICAgICAgICBwcml2YXRlIHVzZXJTZXJ2aWNlOiBVc2VyU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcbiAgICAgICAgcHJpdmF0ZSBzaGFyZWRTZXJ2aWNlOiBTaGFyZWRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIG1vZGFsU2VydmljZTogTmdiTW9kYWwsXG4gICAgICAgIEBJbmplY3QoRE9DVU1FTlQpIHByaXZhdGUgZG9jdW1lbnQ6IERvY3VtZW50LFxuICAgICAgICBwcml2YXRlIHRyYW5zbGF0ZVNlcnZpY2U6IFRyYW5zbGF0ZVNlcnZpY2UsXG4gICAgKSB7XG4gICAgICAgIHRoaXMuc3RhdGVTdG9yZSA9IGRhdGEuc3RhdGVTdG9yZTtcbiAgICAgICAgdGhpcy5jb3Vyc2VJZCA9IGRhdGEuY291cnNlSWQ7XG4gICAgICAgIHRoaXMuZXhlcmNpc2VJZCA9IGRhdGEuZXhlcmNpc2VJZDtcbiAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZSA9IGRhdGEuc2Vzc2lvblNlcnZpY2U7XG4gICAgICAgIHRoaXMubmF2aWdhdGlvblN1YnNjcmlwdGlvbiA9IHRoaXMucm91dGVyLmV2ZW50cy5zdWJzY3JpYmUoKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBpZiAoZXZlbnQgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uU3RhcnQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmRpYWxvZy5jbG9zZUFsbCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5mdWxsU2l6ZSA9IGRhdGEuZnVsbFNpemUgPz8gZmFsc2U7XG4gICAgfVxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMudXNlclNlcnZpY2UuZ2V0SXJpc0FjY2VwdGVkQXQoKS5zdWJzY3JpYmUoKHJlcykgPT4ge1xuICAgICAgICAgICAgdGhpcy51c2VyQWNjZXB0ZWQgPSAhIXJlcztcbiAgICAgICAgICAgIGlmICh0aGlzLnVzZXJBY2NlcHRlZCkge1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZEZpcnN0TWVzc2FnZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLmFuaW1hdGVEb3RzKCk7XG5cbiAgICAgICAgLy8gU3Vic2NyaWJlIHRvIHN0YXRlIGNoYW5nZXNcbiAgICAgICAgdGhpcy5zdGF0ZVN1YnNjcmlwdGlvbiA9IHRoaXMuc3RhdGVTdG9yZS5nZXRTdGF0ZSgpLnN1YnNjcmliZSgoc3RhdGUpID0+IHtcbiAgICAgICAgICAgIHRoaXMubWVzc2FnZXMgPSBzdGF0ZS5tZXNzYWdlcyBhcyBJcmlzTWVzc2FnZVtdO1xuICAgICAgICAgICAgdGhpcy5pc0xvYWRpbmcgPSBzdGF0ZS5pc0xvYWRpbmc7XG4gICAgICAgICAgICB0aGlzLmVycm9yID0gc3RhdGUuZXJyb3I7XG4gICAgICAgICAgICB0aGlzLnNlc3Npb25JZCA9IE51bWJlcihzdGF0ZS5zZXNzaW9uSWQpO1xuICAgICAgICAgICAgdGhpcy5udW1OZXdNZXNzYWdlcyA9IHN0YXRlLm51bU5ld01lc3NhZ2VzO1xuICAgICAgICAgICAgaWYgKHN0YXRlLmVycm9yPy5rZXkgPT0gSXJpc0Vycm9yTWVzc2FnZUtleS5FTVBUWV9NRVNTQUdFKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zaG91bGRTaG93RW1wdHlNZXNzYWdlRXJyb3IgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHRoaXMuZmFkZVN0YXRlID0gJ3N0YXJ0JztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0aGlzLmVycm9yKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5nZXRDb252ZXJ0ZWRFcnJvck1hcCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5jdXJyZW50TWVzc2FnZUNvdW50ID0gc3RhdGUuY3VycmVudE1lc3NhZ2VDb3VudDtcbiAgICAgICAgICAgIHRoaXMucmF0ZUxpbWl0ID0gc3RhdGUucmF0ZUxpbWl0O1xuICAgICAgICAgICAgdGhpcy5yYXRlTGltaXRUaW1lZnJhbWVIb3VycyA9IHN0YXRlLnJhdGVMaW1pdFRpbWVmcmFtZUhvdXJzO1xuICAgICAgICB9KTtcblxuICAgICAgICAvLyBGb2N1cyBvbiBtZXNzYWdlIHRleHRhcmVhXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5tZXNzYWdlVGV4dGFyZWEubmF0aXZlRWxlbWVudC5mb2N1cygpO1xuICAgICAgICB9LCAxNTApO1xuICAgIH1cblxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICAgICAgLy8gRGV0ZXJtaW5lIHRoZSB1bnJlYWQgbWVzc2FnZSBpbmRleCBhbmQgc2Nyb2xsIHRvIHRoZSB1bnJlYWQgbWVzc2FnZSBpZiBhcHBsaWNhYmxlXG4gICAgICAgIHRoaXMudW5yZWFkTWVzc2FnZUluZGV4ID0gdGhpcy5tZXNzYWdlcy5sZW5ndGggPD0gMSB8fCB0aGlzLm51bU5ld01lc3NhZ2VzID09PSAwID8gLTEgOiB0aGlzLm1lc3NhZ2VzLmxlbmd0aCAtIHRoaXMubnVtTmV3TWVzc2FnZXM7XG4gICAgICAgIGlmICh0aGlzLm51bU5ld01lc3NhZ2VzID4gMCkge1xuICAgICAgICAgICAgdGhpcy5zY3JvbGxUb1VucmVhZCgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5zY3JvbGxUb0JvdHRvbSgnYXV0bycpO1xuICAgICAgICB9XG5cbiAgICAgICAgaW50ZXJhY3QoJy5jaGF0LXdpZGdldCcpXG4gICAgICAgICAgICAucmVzaXphYmxlKHtcbiAgICAgICAgICAgICAgICAvLyByZXNpemUgZnJvbSBhbGwgZWRnZXMgYW5kIGNvcm5lcnNcbiAgICAgICAgICAgICAgICBlZGdlczogeyBsZWZ0OiB0cnVlLCByaWdodDogdHJ1ZSwgYm90dG9tOiB0cnVlLCB0b3A6IHRydWUgfSxcblxuICAgICAgICAgICAgICAgIGxpc3RlbmVyczoge1xuICAgICAgICAgICAgICAgICAgICBtb3ZlOiAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LnRhcmdldDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB4ID0gcGFyc2VGbG9hdCh0YXJnZXQuZ2V0QXR0cmlidXRlKCdkYXRhLXgnKSkgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB5ID0gcGFyc2VGbG9hdCh0YXJnZXQuZ2V0QXR0cmlidXRlKCdkYXRhLXknKSkgfHwgMDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdXBkYXRlIHRoZSBlbGVtZW50J3Mgc3R5bGVcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldC5zdHlsZS53aWR0aCA9IGV2ZW50LnJlY3Qud2lkdGggKyAncHgnO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LnN0eWxlLmhlaWdodCA9IGV2ZW50LnJlY3QuaGVpZ2h0ICsgJ3B4JztcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVzZXQgZnVsbHNpemUgaWYgd2lkZ2V0IHNtYWxsZXIgdGhhbiB0aGUgZnVsbCBzaXplIGZhY3RvcnMgdGltZXMgdGhlIG92ZXJsYXkgY29udGFpbmVyIHNpemVcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNudFJlY3QgPSAodGhpcy5kb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuY2RrLW92ZXJsYXktY29udGFpbmVyJykgYXMgSFRNTEVsZW1lbnQpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5mdWxsU2l6ZSA9ICEoZXZlbnQucmVjdC53aWR0aCA8IGNudFJlY3Qud2lkdGggKiB0aGlzLmZ1bGxXaWR0aEZhY3RvciB8fCBldmVudC5yZWN0LmhlaWdodCA8IGNudFJlY3QuaGVpZ2h0ICogdGhpcy5mdWxsSGVpZ2h0RmFjdG9yKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdHJhbnNsYXRlIHdoZW4gcmVzaXppbmcgZnJvbSB0b3Agb3IgbGVmdCBlZGdlc1xuICAgICAgICAgICAgICAgICAgICAgICAgeCArPSBldmVudC5kZWx0YVJlY3QubGVmdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHkgKz0gZXZlbnQuZGVsdGFSZWN0LnRvcDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LnN0eWxlLnRyYW5zZm9ybSA9ICd0cmFuc2xhdGUoJyArIHggKyAncHgsJyArIHkgKyAncHgpJztcblxuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LnNldEF0dHJpYnV0ZSgnZGF0YS14JywgeCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQuc2V0QXR0cmlidXRlKCdkYXRhLXknLCB5KTtcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIG1vZGlmaWVyczogW1xuICAgICAgICAgICAgICAgICAgICAvLyBrZWVwIHRoZSBlZGdlcyBpbnNpZGUgdGhlIHBhcmVudFxuICAgICAgICAgICAgICAgICAgICBpbnRlcmFjdC5tb2RpZmllcnMucmVzdHJpY3RFZGdlcyh7XG4gICAgICAgICAgICAgICAgICAgICAgICBvdXRlcjogJy5jZGstb3ZlcmxheS1jb250YWluZXInLFxuICAgICAgICAgICAgICAgICAgICB9KSxcblxuICAgICAgICAgICAgICAgICAgICAvLyBtaW5pbXVtIHNpemVcbiAgICAgICAgICAgICAgICAgICAgaW50ZXJhY3QubW9kaWZpZXJzLnJlc3RyaWN0U2l6ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICBtaW46IHsgd2lkdGg6IHRoaXMuaW5pdGlhbFdpZHRoLCBoZWlnaHQ6IHRoaXMuaW5pdGlhbEhlaWdodCB9LFxuICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICBdLFxuXG4gICAgICAgICAgICAgICAgaW5lcnRpYTogdHJ1ZSxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuZHJhZ2dhYmxlKHtcbiAgICAgICAgICAgICAgICBsaXN0ZW5lcnM6IHtcbiAgICAgICAgICAgICAgICAgICAgbW92ZTogKGV2ZW50OiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LnRhcmdldCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBrZWVwIHRoZSBkcmFnZ2VkIHBvc2l0aW9uIGluIHRoZSBkYXRhLXgvZGF0YS15IGF0dHJpYnV0ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB4ID0gKHBhcnNlRmxvYXQodGFyZ2V0LmdldEF0dHJpYnV0ZSgnZGF0YS14JykpIHx8IDApICsgZXZlbnQuZHgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeSA9IChwYXJzZUZsb2F0KHRhcmdldC5nZXRBdHRyaWJ1dGUoJ2RhdGEteScpKSB8fCAwKSArIGV2ZW50LmR5O1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB0cmFuc2xhdGUgdGhlIGVsZW1lbnRcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldC5zdHlsZS50cmFuc2Zvcm0gPSAndHJhbnNsYXRlKCcgKyB4ICsgJ3B4LCAnICsgeSArICdweCknO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB1cGRhdGUgdGhlIHBvc2lpb24gYXR0cmlidXRlc1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LnNldEF0dHJpYnV0ZSgnZGF0YS14JywgeCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQuc2V0QXR0cmlidXRlKCdkYXRhLXknLCB5KTtcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGluZXJ0aWE6IHRydWUsXG4gICAgICAgICAgICAgICAgbW9kaWZpZXJzOiBbXG4gICAgICAgICAgICAgICAgICAgIGludGVyYWN0Lm1vZGlmaWVycy5yZXN0cmljdFJlY3Qoe1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzdHJpY3Rpb246ICcuY2RrLW92ZXJsYXktY29udGFpbmVyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVuZE9ubHk6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5zZXRQb3NpdGlvbkFuZFNjYWxlKCk7XG4gICAgfVxuXG4gICAgc2V0UG9zaXRpb25BbmRTY2FsZSgpIHtcbiAgICAgICAgY29uc3QgY250UmVjdCA9ICh0aGlzLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5jZGstb3ZlcmxheS1jb250YWluZXInKSBhcyBIVE1MRWxlbWVudCk/LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICBpZiAoIWNudFJlY3QpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGluaXRYID0gdGhpcy5mdWxsU2l6ZSA/IChjbnRSZWN0LndpZHRoICogKDEgLSB0aGlzLmZ1bGxXaWR0aEZhY3RvcikpIC8gMi4wIDogY250UmVjdC53aWR0aCAtIHRoaXMuaW5pdGlhbFdpZHRoIC0gMjA7XG4gICAgICAgIGNvbnN0IGluaXRZID0gdGhpcy5mdWxsU2l6ZSA/IChjbnRSZWN0LmhlaWdodCAqICgxIC0gdGhpcy5mdWxsSGVpZ2h0RmFjdG9yKSkgLyAyLjAgOiBjbnRSZWN0LmhlaWdodCAtIHRoaXMuaW5pdGlhbEhlaWdodCAtIDIwO1xuXG4gICAgICAgIGNvbnN0IG5FID0gdGhpcy5kb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuY2hhdC13aWRnZXQnKSBhcyBIVE1MRWxlbWVudDtcbiAgICAgICAgbkUuc3R5bGUudHJhbnNmb3JtID0gYHRyYW5zbGF0ZSgke2luaXRYfXB4LCAke2luaXRZfXB4KWA7XG4gICAgICAgIG5FLnNldEF0dHJpYnV0ZSgnZGF0YS14JywgU3RyaW5nKGluaXRYKSk7XG4gICAgICAgIG5FLnNldEF0dHJpYnV0ZSgnZGF0YS15JywgU3RyaW5nKGluaXRZKSk7XG5cbiAgICAgICAgLy8gU2V0IHdpZHRoIGFuZCBoZWlnaHRcbiAgICAgICAgaWYgKHRoaXMuZnVsbFNpemUpIHtcbiAgICAgICAgICAgIG5FLnN0eWxlLndpZHRoID0gYCR7Y250UmVjdC53aWR0aCAqIHRoaXMuZnVsbFdpZHRoRmFjdG9yfXB4YDtcbiAgICAgICAgICAgIG5FLnN0eWxlLmhlaWdodCA9IGAke2NudFJlY3QuaGVpZ2h0ICogdGhpcy5mdWxsSGVpZ2h0RmFjdG9yfXB4YDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5FLnN0eWxlLndpZHRoID0gYCR7dGhpcy5pbml0aWFsV2lkdGh9cHhgO1xuICAgICAgICAgICAgbkUuc3R5bGUuaGVpZ2h0ID0gYCR7dGhpcy5pbml0aWFsSGVpZ2h0fXB4YDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICB0aGlzLnN0YXRlU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIHRoaXMubmF2aWdhdGlvblN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICB0aGlzLnRvZ2dsZVNjcm9sbExvY2soZmFsc2UpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEluc2VydHMgdGhlIGNvcnJlY3QgbGluayB0byBpbXBvcnQgdGhlIGN1cnJlbnQgcHJvZ3JhbW1pbmcgZXhlcmNpc2UgZm9yIGEgbmV3IHZhcmlhbnQgZ2VuZXJhdGlvbi5cbiAgICAgKi9cbiAgICBnZXRGaXJzdE1lc3NhZ2VDb250ZW50KCk6IHN0cmluZyB7XG4gICAgICAgIGlmICh0aGlzLmlzQ2hhdFNlc3Npb24oKSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KCdhcnRlbWlzQXBwLmV4ZXJjaXNlQ2hhdGJvdC50dXRvckZpcnN0TWVzc2FnZScpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuaW1wb3J0RXhlcmNpc2VVcmwgPSBgL2NvdXJzZS1tYW5hZ2VtZW50LyR7dGhpcy5jb3Vyc2VJZH0vcHJvZ3JhbW1pbmctZXhlcmNpc2VzL2ltcG9ydC8ke3RoaXMuZXhlcmNpc2VJZH1gO1xuICAgICAgICByZXR1cm4gdGhpcy50cmFuc2xhdGVTZXJ2aWNlXG4gICAgICAgICAgICAuaW5zdGFudCgnYXJ0ZW1pc0FwcC5leGVyY2lzZUNoYXRib3QuY29kZUVkaXRvckZpcnN0TWVzc2FnZScpXG4gICAgICAgICAgICAucmVwbGFjZSgve2xpbms6KC4qKX0vLCAnPGEgaHJlZj1cIicgKyB0aGlzLmltcG9ydEV4ZXJjaXNlVXJsICsgJ1wiIHRhcmdldD1cIl9ibGFua1wiPiQxPC9hPicpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIExvYWRzIHRoZSBmaXJzdCBtZXNzYWdlIGluIHRoZSBjb252ZXJzYXRpb24gaWYgaXQncyBub3QgYWxyZWFkeSBsb2FkZWQuXG4gICAgICovXG4gICAgbG9hZEZpcnN0TWVzc2FnZSgpOiB2b2lkIHtcbiAgICAgICAgY29uc3QgZmlyc3RNZXNzYWdlQ29udGVudCA9IHtcbiAgICAgICAgICAgIHR5cGU6IElyaXNNZXNzYWdlQ29udGVudFR5cGUuVEVYVCxcbiAgICAgICAgICAgIHRleHRDb250ZW50OiB0aGlzLmdldEZpcnN0TWVzc2FnZUNvbnRlbnQoKSxcbiAgICAgICAgfSBhcyBJcmlzVGV4dE1lc3NhZ2VDb250ZW50O1xuXG4gICAgICAgIGNvbnN0IGZpcnN0TWVzc2FnZSA9IHtcbiAgICAgICAgICAgIHNlbmRlcjogSXJpc1NlbmRlci5BUlRFTUlTX0NMSUVOVCxcbiAgICAgICAgICAgIGNvbnRlbnQ6IFtmaXJzdE1lc3NhZ2VDb250ZW50XSxcbiAgICAgICAgICAgIHNlbnRBdDogZGF5anMoKSxcbiAgICAgICAgfSBhcyBJcmlzQXJ0ZW1pc0NsaWVudE1lc3NhZ2U7XG5cbiAgICAgICAgaWYgKHRoaXMubWVzc2FnZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICB0aGlzLnN0YXRlU3RvcmUuZGlzcGF0Y2gobmV3IEFjdGl2ZUNvbnZlcnNhdGlvbk1lc3NhZ2VMb2FkZWRBY3Rpb24oZmlyc3RNZXNzYWdlKSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIYW5kbGVzIHRoZSBzZW5kIGJ1dHRvbiBjbGljayBldmVudCBhbmQgc2VuZHMgdGhlIHVzZXIncyBtZXNzYWdlLlxuICAgICAqL1xuICAgIG9uU2VuZCgpOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMuZXJyb3I/LmZhdGFsKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMubmV3TWVzc2FnZVRleHRDb250ZW50LnRyaW0oKSA9PT0gJycpIHtcbiAgICAgICAgICAgIHRoaXMuc3RhdGVTdG9yZS5kaXNwYXRjaEFuZFRoZW4obmV3IENvbnZlcnNhdGlvbkVycm9yT2NjdXJyZWRBY3Rpb24oSXJpc0Vycm9yTWVzc2FnZUtleS5FTVBUWV9NRVNTQUdFKSkuY2F0Y2goKCkgPT4gdGhpcy5zY3JvbGxUb0JvdHRvbSgnc21vb3RoJykpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLm5ld01lc3NhZ2VUZXh0Q29udGVudCkge1xuICAgICAgICAgICAgY29uc3QgbWVzc2FnZSA9IHRoaXMubmV3VXNlck1lc3NhZ2UodGhpcy5uZXdNZXNzYWdlVGV4dENvbnRlbnQpO1xuICAgICAgICAgICAgY29uc3QgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gd2lsbCBiZSBjbGVhcmVkIGJ5IHRoZSBzdG9yZSBhdXRvbWF0aWNhbGx5XG4gICAgICAgICAgICAgICAgdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKG5ldyBDb252ZXJzYXRpb25FcnJvck9jY3VycmVkQWN0aW9uKElyaXNFcnJvck1lc3NhZ2VLZXkuSVJJU19TRVJWRVJfUkVTUE9OU0VfVElNRU9VVCkpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2Nyb2xsVG9Cb3R0b20oJ3Ntb290aCcpO1xuICAgICAgICAgICAgfSwgMjAwMDApO1xuICAgICAgICAgICAgdGhpcy5zdGF0ZVN0b3JlXG4gICAgICAgICAgICAgICAgLmRpc3BhdGNoQW5kVGhlbihuZXcgU3R1ZGVudE1lc3NhZ2VTZW50QWN0aW9uKG1lc3NhZ2UsIHRpbWVvdXRJZCkpXG4gICAgICAgICAgICAgICAgLnRoZW4oKCkgPT4gdGhpcy5zZXNzaW9uU2VydmljZS5zZW5kTWVzc2FnZSh0aGlzLnNlc3Npb25JZCwgbWVzc2FnZSkpXG4gICAgICAgICAgICAgICAgLnRoZW4oKCkgPT4gdGhpcy5zY3JvbGxUb0JvdHRvbSgnc21vb3RoJykpXG4gICAgICAgICAgICAgICAgLmNhdGNoKChlcnJvcikgPT4gdGhpcy5oYW5kbGVJcmlzRXJyb3IoZXJyb3IpKTtcbiAgICAgICAgICAgIHRoaXMubmV3TWVzc2FnZVRleHRDb250ZW50ID0gJyc7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zY3JvbGxUb0JvdHRvbSgnc21vb3RoJyk7XG4gICAgICAgIHRoaXMucmVzZXRDaGF0Qm9keUhlaWdodCgpO1xuICAgIH1cblxuICAgIHJlc2VuZE1lc3NhZ2UobWVzc2FnZTogSXJpc1VzZXJNZXNzYWdlKSB7XG4gICAgICAgIHRoaXMucmVzZW5kQW5pbWF0aW9uQWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgbWVzc2FnZS5tZXNzYWdlRGlmZmVyZW50aWF0b3IgPSBtZXNzYWdlLmlkID8/IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIHRoaXMuTUFYX0lOVF9KQVZBKTtcblxuICAgICAgICBjb25zdCB0aW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIC8vIHdpbGwgYmUgY2xlYXJlZCBieSB0aGUgc3RvcmUgYXV0b21hdGljYWxseVxuICAgICAgICAgICAgdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKG5ldyBDb252ZXJzYXRpb25FcnJvck9jY3VycmVkQWN0aW9uKElyaXNFcnJvck1lc3NhZ2VLZXkuSVJJU19TRVJWRVJfUkVTUE9OU0VfVElNRU9VVCkpO1xuICAgICAgICAgICAgdGhpcy5zY3JvbGxUb0JvdHRvbSgnc21vb3RoJyk7XG4gICAgICAgIH0sIDIwMDAwMDApO1xuICAgICAgICB0aGlzLnN0YXRlU3RvcmVcbiAgICAgICAgICAgIC5kaXNwYXRjaEFuZFRoZW4obmV3IFN0dWRlbnRNZXNzYWdlU2VudEFjdGlvbihtZXNzYWdlLCB0aW1lb3V0SWQpKVxuICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnNlc3Npb25TZXJ2aWNlLnJlc2VuZE1lc3NhZ2UodGhpcy5zZXNzaW9uSWQsIG1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnNlc3Npb25TZXJ2aWNlLnNlbmRNZXNzYWdlKHRoaXMuc2Vzc2lvbklkLCBtZXNzYWdlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuc2Nyb2xsVG9Cb3R0b20oJ3Ntb290aCcpO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHRoaXMuaGFuZGxlSXJpc0Vycm9yKGVycm9yKSlcbiAgICAgICAgICAgIC5maW5hbGx5KCgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnJlc2VuZEFuaW1hdGlvbkFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHRoaXMuc2Nyb2xsVG9Cb3R0b20oJ3Ntb290aCcpO1xuICAgICAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBoYW5kbGVJcmlzRXJyb3IoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSB7XG4gICAgICAgIGlmIChlcnJvci5zdGF0dXMgPT09IDQwMykge1xuICAgICAgICAgICAgdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKG5ldyBDb252ZXJzYXRpb25FcnJvck9jY3VycmVkQWN0aW9uKElyaXNFcnJvck1lc3NhZ2VLZXkuSVJJU19ESVNBQkxFRCkpO1xuICAgICAgICB9IGVsc2UgaWYgKGVycm9yLnN0YXR1cyA9PT0gNDI5KSB7XG4gICAgICAgICAgICBjb25zdCBtYXAgPSBuZXcgTWFwPHN0cmluZywgYW55PigpO1xuICAgICAgICAgICAgbWFwLnNldCgnaG91cnMnLCB0aGlzLnJhdGVMaW1pdFRpbWVmcmFtZUhvdXJzKTtcbiAgICAgICAgICAgIHRoaXMuc3RhdGVTdG9yZS5kaXNwYXRjaChuZXcgQ29udmVyc2F0aW9uRXJyb3JPY2N1cnJlZEFjdGlvbihJcmlzRXJyb3JNZXNzYWdlS2V5LlJBVEVfTElNSVRfRVhDRUVERUQsIG1hcCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKG5ldyBDb252ZXJzYXRpb25FcnJvck9jY3VycmVkQWN0aW9uKElyaXNFcnJvck1lc3NhZ2VLZXkuU0VORF9NRVNTQUdFX0ZBSUxFRCkpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmF0ZXMgYSBtZXNzYWdlIGFzIGhlbHBmdWwgb3IgdW5oZWxwZnVsLlxuICAgICAqIEBwYXJhbSBtZXNzYWdlSWQgLSBUaGUgSUQgb2YgdGhlIG1lc3NhZ2UgdG8gcmF0ZS5cbiAgICAgKiBAcGFyYW0gaW5kZXggLSBUaGUgaW5kZXggb2YgdGhlIG1lc3NhZ2UgaW4gdGhlIG1lc3NhZ2VzIGFycmF5LlxuICAgICAqIEBwYXJhbSBoZWxwZnVsIC0gQSBib29sZWFuIGluZGljYXRpbmcgaWYgdGhlIG1lc3NhZ2UgaXMgaGVscGZ1bCBvciBub3QuXG4gICAgICovXG4gICAgcmF0ZU1lc3NhZ2UobWVzc2FnZUlkOiBudW1iZXIsIGluZGV4OiBudW1iZXIsIGhlbHBmdWw6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZVxuICAgICAgICAgICAgLnJhdGVNZXNzYWdlKHRoaXMuc2Vzc2lvbklkLCBtZXNzYWdlSWQsIGhlbHBmdWwpXG4gICAgICAgICAgICAudGhlbigoKSA9PiB0aGlzLnN0YXRlU3RvcmUuZGlzcGF0Y2gobmV3IFJhdGVNZXNzYWdlU3VjY2Vzc0FjdGlvbihpbmRleCwgaGVscGZ1bCkpKVxuICAgICAgICAgICAgLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnN0YXRlU3RvcmUuZGlzcGF0Y2gobmV3IENvbnZlcnNhdGlvbkVycm9yT2NjdXJyZWRBY3Rpb24oSXJpc0Vycm9yTWVzc2FnZUtleS5SQVRFX01FU1NBR0VfRkFJTEVEKSk7XG4gICAgICAgICAgICAgICAgdGhpcy5zY3JvbGxUb0JvdHRvbSgnc21vb3RoJyk7XG4gICAgICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDbG9zZXMgdGhlIGNoYXQgd2lkZ2V0LlxuICAgICAqL1xuICAgIGNsb3NlQ2hhdCgpIHtcbiAgICAgICAgdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKG5ldyBOdW1OZXdNZXNzYWdlc1Jlc2V0QWN0aW9uKCkpO1xuICAgICAgICB0aGlzLnNoYXJlZFNlcnZpY2UuY2hhbmdlQ2hhdE9wZW5TdGF0dXMoZmFsc2UpO1xuICAgICAgICB0aGlzLmRpYWxvZy5jbG9zZUFsbCgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEFuaW1hdGVzIHRoZSBkb3RzIHdoaWxlIGxvYWRpbmcgZWFjaCBJcmlzIG1lc3NhZ2UgaW4gdGhlIGNoYXQgd2lkZ2V0LlxuICAgICAqL1xuICAgIGFuaW1hdGVEb3RzKCkge1xuICAgICAgICBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmRvdHMgPSB0aGlzLmRvdHMgPCAzID8gKHRoaXMuZG90cyArPSAxKSA6ICh0aGlzLmRvdHMgPSAxKTtcbiAgICAgICAgfSwgNTAwKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTY3JvbGxzIHRvIHRoZSB1bnJlYWQgbWVzc2FnZS5cbiAgICAgKi9cbiAgICBzY3JvbGxUb1VucmVhZCgpIHtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB1bnJlYWRNZXNzYWdlRWxlbWVudDogSFRNTEVsZW1lbnQgPSB0aGlzLnVucmVhZE1lc3NhZ2U/Lm5hdGl2ZUVsZW1lbnQ7XG4gICAgICAgICAgICBpZiAodW5yZWFkTWVzc2FnZUVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICB1bnJlYWRNZXNzYWdlRWxlbWVudC5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnYXV0bycgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNjcm9sbHMgdGhlIGNoYXQgYm9keSB0byB0aGUgYm90dG9tLlxuICAgICAqIEBwYXJhbSBiZWhhdmlvciAtIFRoZSBzY3JvbGwgYmVoYXZpb3IuXG4gICAgICovXG4gICAgc2Nyb2xsVG9Cb3R0b20oYmVoYXZpb3I6IFNjcm9sbEJlaGF2aW9yKSB7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgY2hhdEJvZHlFbGVtZW50OiBIVE1MRWxlbWVudCA9IHRoaXMuY2hhdEJvZHkubmF0aXZlRWxlbWVudDtcbiAgICAgICAgICAgIGNoYXRCb2R5RWxlbWVudC5zY3JvbGxUbyh7XG4gICAgICAgICAgICAgICAgdG9wOiBjaGF0Qm9keUVsZW1lbnQuc2Nyb2xsSGVpZ2h0LFxuICAgICAgICAgICAgICAgIGJlaGF2aW9yOiBiZWhhdmlvcixcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVja3MgaWYgdGhlIGNoYXQgYm9keSBpcyBzY3JvbGxlZCB0byB0aGUgYm90dG9tLlxuICAgICAqL1xuICAgIGNoZWNrQ2hhdFNjcm9sbCgpIHtcbiAgICAgICAgY29uc3QgY2hhdEJvZHkgPSB0aGlzLmNoYXRCb2R5Lm5hdGl2ZUVsZW1lbnQ7XG4gICAgICAgIGNvbnN0IHNjcm9sbEhlaWdodCA9IGNoYXRCb2R5LnNjcm9sbEhlaWdodDtcbiAgICAgICAgY29uc3Qgc2Nyb2xsVG9wID0gY2hhdEJvZHkuc2Nyb2xsVG9wO1xuICAgICAgICBjb25zdCBjbGllbnRIZWlnaHQgPSBjaGF0Qm9keS5jbGllbnRIZWlnaHQ7XG4gICAgICAgIHRoaXMuaXNTY3JvbGxlZFRvQm90dG9tID0gc2Nyb2xsSGVpZ2h0IC0gc2Nyb2xsVG9wIC0gY2xpZW50SGVpZ2h0IDwgNTA7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2xlYXIgc2Vzc2lvbiBhbmQgc3RhcnQgYSBuZXcgY29udmVyc2F0aW9uLlxuICAgICAqL1xuICAgIG9uQ2xlYXJTZXNzaW9uKGNvbnRlbnQ6IGFueSkge1xuICAgICAgICB0aGlzLm1vZGFsU2VydmljZS5vcGVuKGNvbnRlbnQpLnJlc3VsdC50aGVuKChyZXN1bHQ6IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgaWYgKHJlc3VsdCA9PT0gJ2NvbmZpcm0nKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5pc0xvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLmNyZWF0ZU5ld1Nlc3Npb24oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQWNjZXB0cyB0aGUgcGVybWlzc2lvbiB0byB1c2UgdGhlIGNoYXQgd2lkZ2V0LlxuICAgICAqL1xuICAgIGFjY2VwdFBlcm1pc3Npb24oKSB7XG4gICAgICAgIHRoaXMudXNlclNlcnZpY2UuYWNjZXB0SXJpcygpLnN1YnNjcmliZSgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnVzZXJBY2NlcHRlZCA9IHRydWU7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmxvYWRGaXJzdE1lc3NhZ2UoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBNYXhpbWl6ZXMgdGhlIGNoYXQgd2lkZ2V0IHNjcmVlbi5cbiAgICAgKi9cbiAgICBtYXhpbWl6ZVNjcmVlbigpIHtcbiAgICAgICAgdGhpcy5mdWxsU2l6ZSA9IHRydWU7XG4gICAgICAgIHRoaXMuc2V0UG9zaXRpb25BbmRTY2FsZSgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE1pbmltaXplcyB0aGUgY2hhdCB3aWRnZXQgc2NyZWVuLlxuICAgICAqL1xuICAgIG1pbmltaXplU2NyZWVuKCkge1xuICAgICAgICB0aGlzLmZ1bGxTaXplID0gZmFsc2U7XG4gICAgICAgIHRoaXMuc2V0UG9zaXRpb25BbmRTY2FsZSgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEhhbmRsZXMgdGhlIGtleSBldmVudHMgaW4gdGhlIG1lc3NhZ2UgdGV4dGFyZWEuXG4gICAgICogQHBhcmFtIGV2ZW50IC0gVGhlIGtleWJvYXJkIGV2ZW50LlxuICAgICAqL1xuICAgIGhhbmRsZUtleShldmVudDogS2V5Ym9hcmRFdmVudCk6IHZvaWQge1xuICAgICAgICBpZiAoZXZlbnQua2V5ID09PSAnRW50ZXInKSB7XG4gICAgICAgICAgICBpZiAoIXRoaXMuZGVhY3RpdmF0ZVN1Ym1pdEJ1dHRvbigpKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFldmVudC5zaGlmdEtleSkge1xuICAgICAgICAgICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uU2VuZCgpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHRleHRBcmVhID0gZXZlbnQudGFyZ2V0IGFzIEhUTUxUZXh0QXJlYUVsZW1lbnQ7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHsgc2VsZWN0aW9uU3RhcnQsIHNlbGVjdGlvbkVuZCB9ID0gdGV4dEFyZWE7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gdGV4dEFyZWEudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIHRleHRBcmVhLnZhbHVlID0gdmFsdWUuc2xpY2UoMCwgc2VsZWN0aW9uU3RhcnQpICsgdmFsdWUuc2xpY2Uoc2VsZWN0aW9uRW5kKTtcbiAgICAgICAgICAgICAgICAgICAgdGV4dEFyZWEuc2VsZWN0aW9uU3RhcnQgPSB0ZXh0QXJlYS5zZWxlY3Rpb25FbmQgPSBzZWxlY3Rpb25TdGFydCArIDE7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSGFuZGxlcyB0aGUgaW5wdXQgZXZlbnQgaW4gdGhlIG1lc3NhZ2UgdGV4dGFyZWEuXG4gICAgICovXG4gICAgb25JbnB1dCgpIHtcbiAgICAgICAgdGhpcy5hZGp1c3RUZXh0YXJlYVJvd3MoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIYW5kbGVzIHRoZSBwYXN0ZSBldmVudCBpbiB0aGUgbWVzc2FnZSB0ZXh0YXJlYS5cbiAgICAgKi9cbiAgICBvblBhc3RlKCkge1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYWRqdXN0VGV4dGFyZWFSb3dzKCk7XG4gICAgICAgIH0sIDApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEFkanVzdHMgdGhlIGhlaWdodCBvZiB0aGUgbWVzc2FnZSB0ZXh0YXJlYSBiYXNlZCBvbiBpdHMgY29udGVudC5cbiAgICAgKi9cbiAgICBhZGp1c3RUZXh0YXJlYVJvd3MoKSB7XG4gICAgICAgIGNvbnN0IHRleHRhcmVhOiBIVE1MVGV4dEFyZWFFbGVtZW50ID0gdGhpcy5tZXNzYWdlVGV4dGFyZWEubmF0aXZlRWxlbWVudDtcbiAgICAgICAgdGV4dGFyZWEuc3R5bGUuaGVpZ2h0ID0gJ2F1dG8nOyAvLyBSZXNldCB0aGUgaGVpZ2h0IHRvIGF1dG9cbiAgICAgICAgY29uc3QgbGluZUhlaWdodCA9IHBhcnNlSW50KGdldENvbXB1dGVkU3R5bGUodGV4dGFyZWEpLmxpbmVIZWlnaHQsIDEwKTtcbiAgICAgICAgY29uc3QgbWF4Um93cyA9IDM7XG4gICAgICAgIGNvbnN0IG1heEhlaWdodCA9IGxpbmVIZWlnaHQgKiBtYXhSb3dzO1xuXG4gICAgICAgIHRleHRhcmVhLnN0eWxlLmhlaWdodCA9IGAke01hdGgubWluKHRleHRhcmVhLnNjcm9sbEhlaWdodCwgbWF4SGVpZ2h0KX1weGA7XG5cbiAgICAgICAgdGhpcy5hZGp1c3RDaGF0Qm9keUhlaWdodChNYXRoLm1pbih0ZXh0YXJlYS5zY3JvbGxIZWlnaHQsIG1heEhlaWdodCkgLyBsaW5lSGVpZ2h0KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIYW5kbGVzIHRoZSByb3cgY2hhbmdlIGV2ZW50IGluIHRoZSBtZXNzYWdlIHRleHRhcmVhLlxuICAgICAqL1xuICAgIG9uUm93Q2hhbmdlKCkge1xuICAgICAgICBjb25zdCB0ZXh0YXJlYTogSFRNTFRleHRBcmVhRWxlbWVudCA9IHRoaXMubWVzc2FnZVRleHRhcmVhLm5hdGl2ZUVsZW1lbnQ7XG4gICAgICAgIGNvbnN0IG5ld1Jvd3MgPSB0ZXh0YXJlYS52YWx1ZS5zcGxpdCgnXFxuJykubGVuZ3RoO1xuICAgICAgICBpZiAobmV3Um93cyAhPSB0aGlzLnJvd3MpIHtcbiAgICAgICAgICAgIGlmIChuZXdSb3dzIDw9IDMpIHtcbiAgICAgICAgICAgICAgICB0ZXh0YXJlYS5yb3dzID0gbmV3Um93cztcbiAgICAgICAgICAgICAgICB0aGlzLmFkanVzdENoYXRCb2R5SGVpZ2h0KG5ld1Jvd3MpO1xuICAgICAgICAgICAgICAgIHRoaXMucm93cyA9IG5ld1Jvd3M7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBBZGp1c3RzIHRoZSBoZWlnaHQgb2YgdGhlIGNoYXQgYm9keSBiYXNlZCBvbiB0aGUgbnVtYmVyIG9mIHJvd3MgaW4gdGhlIG1lc3NhZ2UgdGV4dGFyZWEuXG4gICAgICogQHBhcmFtIG5ld1Jvd3MgLSBUaGUgbmV3IG51bWJlciBvZiByb3dzLlxuICAgICAqL1xuICAgIGFkanVzdENoYXRCb2R5SGVpZ2h0KG5ld1Jvd3M6IG51bWJlcikge1xuICAgICAgICBjb25zdCB0ZXh0YXJlYTogSFRNTFRleHRBcmVhRWxlbWVudCA9IHRoaXMubWVzc2FnZVRleHRhcmVhLm5hdGl2ZUVsZW1lbnQ7XG4gICAgICAgIGNvbnN0IGNoYXRCb2R5OiBIVE1MRWxlbWVudCA9IHRoaXMuY2hhdEJvZHkubmF0aXZlRWxlbWVudDtcbiAgICAgICAgY29uc3Qgc2Nyb2xsQXJyb3c6IEhUTUxFbGVtZW50ID0gdGhpcy5zY3JvbGxBcnJvdy5uYXRpdmVFbGVtZW50O1xuICAgICAgICBjb25zdCBsaW5lSGVpZ2h0ID0gcGFyc2VJbnQod2luZG93LmdldENvbXB1dGVkU3R5bGUodGV4dGFyZWEpLmxpbmVIZWlnaHQpO1xuICAgICAgICBjb25zdCByb3dIZWlnaHQgPSBsaW5lSGVpZ2h0ICogbmV3Um93cztcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICBzY3JvbGxBcnJvdy5zdHlsZS5ib3R0b20gPSBgY2FsYygxMSUgKyAke3Jvd0hlaWdodH1weClgO1xuICAgICAgICB9LCAxMCk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgY2hhdEJvZHkuc3R5bGUuaGVpZ2h0ID0gYGNhbGMoMTAwJSAtICR7cm93SGVpZ2h0fXB4IC0gNjRweClgO1xuICAgICAgICB9LCAxMCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmVzZXRzIHRoZSBoZWlnaHQgb2YgdGhlIGNoYXQgYm9keS5cbiAgICAgKi9cbiAgICByZXNldENoYXRCb2R5SGVpZ2h0KCkge1xuICAgICAgICBjb25zdCBjaGF0Qm9keTogSFRNTEVsZW1lbnQgPSB0aGlzLmNoYXRCb2R5Lm5hdGl2ZUVsZW1lbnQ7XG4gICAgICAgIGNvbnN0IHRleHRhcmVhOiBIVE1MVGV4dEFyZWFFbGVtZW50ID0gdGhpcy5tZXNzYWdlVGV4dGFyZWEubmF0aXZlRWxlbWVudDtcbiAgICAgICAgY29uc3Qgc2Nyb2xsQXJyb3c6IEhUTUxFbGVtZW50ID0gdGhpcy5zY3JvbGxBcnJvdy5uYXRpdmVFbGVtZW50O1xuICAgICAgICB0ZXh0YXJlYS5yb3dzID0gMTtcbiAgICAgICAgdGV4dGFyZWEuc3R5bGUuaGVpZ2h0ID0gJyc7XG4gICAgICAgIHNjcm9sbEFycm93LnN0eWxlLmJvdHRvbSA9ICcnO1xuICAgICAgICBjaGF0Qm9keS5zdHlsZS5oZWlnaHQgPSAnJztcbiAgICAgICAgdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKG5ldyBOdW1OZXdNZXNzYWdlc1Jlc2V0QWN0aW9uKCkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldHMgdGhlIHRpdGxlIG9mIHRoZSBidXR0b24gd2hpY2ggdG9nZ2xlcyB0aGUgZXhlY3V0aW9uIG9mIGFuIElyaXNFeGVyY2lzZVBsYW4uXG4gICAgICogVGhpcyBkZXBlbmRzIG9uIHRoZSBzdGF0ZSBvZiB0aGUgc3RlcHMgaW4gdGhlIHBsYW4uXG4gICAgICogQ3VycmVudGx5IGV4ZWN1dGluZyAtPiAnUGF1c2UnXG4gICAgICogQWxsIHN0ZXBzIGNvbXBsZXRlIC0+ICdDb21wbGV0ZWQnXG4gICAgICogTmV4dCBzdGVwIGlzIGZhaWxlZCAtPiAnUmV0cnknXG4gICAgICogTmV4dCBzdGVwIGlzIGZpcnN0IHN0ZXAgLT4gJ0V4ZWN1dGUnXG4gICAgICogUGF1c2VkIHNvbWV3aGVyZSBpbiB0aGUgbWlkZGxlIG9mIHRoZSBwbGFuIC0+ICdSZXN1bWUnXG4gICAgICogQHBhcmFtIHBsYW4gLSBUaGUgcGxhbiB0byBnZXQgdGhlIGJ1dHRvbiB0aXRsZSBmb3IuXG4gICAgICovXG4gICAgZ2V0UGxhbkJ1dHRvblRpdGxlKHBsYW46IElyaXNFeGVyY2lzZVBsYW4pOiBzdHJpbmcge1xuICAgICAgICBpZiAocGxhbi5leGVjdXRpbmcpIHtcbiAgICAgICAgICAgIHJldHVybiAnUGF1c2UnO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5leHRTdGVwSW5kZXggPSB0aGlzLmdldE5leHRTdGVwSW5kZXgocGxhbik7XG4gICAgICAgIGlmIChuZXh0U3RlcEluZGV4ID49IHBsYW4uc3RlcHMubGVuZ3RoKSB7XG4gICAgICAgICAgICByZXR1cm4gJ0NvbXBsZXRlZCc7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbmV4dFN0ZXAgPSBwbGFuLnN0ZXBzW25leHRTdGVwSW5kZXhdO1xuICAgICAgICBpZiAoaXNGYWlsZWQobmV4dFN0ZXApKSB7XG4gICAgICAgICAgICByZXR1cm4gJ1JldHJ5JztcbiAgICAgICAgfVxuICAgICAgICBpZiAobmV4dFN0ZXBJbmRleCA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuICdFeGVjdXRlJztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gJ1Jlc3VtZSc7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUGF1c2VzIHRoZSBleGVjdXRpb24gb2YgYW4gZXhlcmNpc2UgcGxhbi5cbiAgICAgKiBAcGFyYW0gcGxhbiAtIFRoZSBwbGFuIHRvIHBhdXNlLlxuICAgICAqL1xuICAgIHBhdXNlUGxhbihwbGFuOiBJcmlzRXhlcmNpc2VQbGFuKSB7XG4gICAgICAgIHBsYW4uZXhlY3V0aW5nID0gZmFsc2U7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgaW5kZXggb2YgdGhlIG5leHQgc3RlcCB0byBleGVjdXRlIGluIGFuIElyaXNFeGVyY2lzZVBsYW4uXG4gICAgICogVGhpcyBpcyB0aGUgaW5kZXggb2YgdGhlIGxhc3Qgc3RlcCB0aGF0IGlzIGNvbXBsZXRlICsgMSwgb3IgMCBpZiBubyBzdGVwcyBhcmUgY29tcGxldGUuXG4gICAgICogUmFuZ2Ugd2lsbCBhbHdheXMgYmUgWzAsIHBsYW4uc3RlcHMubGVuZ3RoXS5cbiAgICAgKiBAcGFyYW0gcGxhbiAtIFRoZSBwbGFuIHRvIGdldCB0aGUgbmV4dCBzdGVwIGluZGV4IGZvci5cbiAgICAgKi9cbiAgICBnZXROZXh0U3RlcEluZGV4KHBsYW46IElyaXNFeGVyY2lzZVBsYW4pIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IHBsYW4uc3RlcHMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgICAgIGNvbnN0IHN0ZXAgPSBwbGFuLnN0ZXBzW2ldO1xuICAgICAgICAgICAgaWYgKGlzQ29tcGxldGUoc3RlcCkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gaSArIDE7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIDA7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB3aGV0aGVyIHRoaXMgcGxhbiBoYXMgbW9yZSBzdGVwcyB0byBleGVjdXRlLlxuICAgICAqIEBwYXJhbSBwbGFuIC0gVGhlIHBsYW4gdG8gY2hlY2suXG4gICAgICovXG4gICAgY2FuRXhlY3V0ZShwbGFuOiBJcmlzRXhlcmNpc2VQbGFuKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmdldE5leHRTdGVwSW5kZXgocGxhbikgPCBwbGFuLnN0ZXBzLmxlbmd0aDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUb2dnbGVzIGFuIElyaXNFeGVyY2lzZVBsYW4gdG8gYmUgZXhlY3V0aW5nLlxuICAgICAqIFdoZW4gYW4gZXhlcmNpc2UgcGxhbiBpcyBleGVjdXRpbmcsIHRoZSBuZXh0IHN0ZXAgd2lsbCBiZSBleGVjdXRlZCBhdXRvbWF0aWNhbGx5IHdoZW4gdGhlIHByZXZpb3VzIHN0ZXAgaXMgY29tcGxldGUuXG4gICAgICogVGhpcyB3aWxsIGFsc28gdHJpZ2dlciB0aGUgaW1tZWRpYXRlIGV4ZWN1dGlvbiBvZiB0aGUgbmV4dCBzdGVwIGlmIGl0IGlzIG5vdCBhbHJlYWR5IGluIHByb2dyZXNzLFxuICAgICAqIGFuZCB3ZSBhcmUgbm90IHN0aWxsIHdhaXRpbmcgZm9yIHRoZSBwcmV2aW91cyBzdGVwIHRvIGNvbXBsZXRlLlxuICAgICAqIEBwYXJhbSBtZXNzYWdlSWQgLSBUaGUgaWQgb2YgdGhlIG1lc3NhZ2Ugd2hpY2ggY29udGFpbnMgdGhlIHBsYW4uXG4gICAgICogQHBhcmFtIHBsYW4gLSBUaGUgcGxhbiB0byBleGVjdXRlLlxuICAgICAqL1xuICAgIHNldEV4ZWN1dGluZyhtZXNzYWdlSWQ6IG51bWJlciwgcGxhbjogSXJpc0V4ZXJjaXNlUGxhbikge1xuICAgICAgICBjb25zdCBuZXh0U3RlcEluZGV4ID0gdGhpcy5nZXROZXh0U3RlcEluZGV4KHBsYW4pO1xuICAgICAgICBpZiAobmV4dFN0ZXBJbmRleCA+PSBwbGFuLnN0ZXBzLmxlbmd0aCkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignVHJpZWQgdG8gZXhlY3V0ZSBwbGFuIHRoYXQgaXMgYWxyZWFkeSBjb21wbGV0ZS4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzdGVwID0gcGxhbi5zdGVwc1tuZXh0U3RlcEluZGV4XTtcbiAgICAgICAgaWYgKCFzdGVwKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdDb3VsZCBub3QgZmluZCBuZXh0IHN0ZXAgdG8gZXhlY3V0ZS4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBwbGFuLmV4ZWN1dGluZyA9IHRydWU7XG4gICAgICAgIGlmIChpc0luUHJvZ3Jlc3Moc3RlcCkpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdTdGVwIGFscmVhZHkgaW4gcHJvZ3Jlc3MsIGF3YWl0aW5nIHJlc3BvbnNlLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZXhlY3V0ZVBsYW5TdGVwKG1lc3NhZ2VJZCwgc3RlcCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRXhlY3V0ZSB0aGUgc3BlY2lmaWVkIHN0ZXAgb2YgYW4gZXhlcmNpc2UgcGxhbi5cbiAgICAgKiBUaGlzIHdpbGwgc2V0IHRoZSBleGVjdXRpb25TdGFnZSBvZiB0aGUgc3RlcCB0byBJTl9QUk9HUkVTUyBhbmQgc2VuZCBhIHJlcXVlc3QgdG8gdGhlIHNlcnZlci5cbiAgICAgKiBAcGFyYW0gbWVzc2FnZUlkIC0gVGhlIGlkIG9mIHRoZSBtZXNzYWdlIHdoaWNoIGNvbnRhaW5zIHRoZSBwbGFuLlxuICAgICAqIEBwYXJhbSBzdGVwIC0gVGhlIHN0ZXAgdG8gZXhlY3V0ZS5cbiAgICAgKi9cbiAgICBleGVjdXRlUGxhblN0ZXAobWVzc2FnZUlkOiBudW1iZXIsIHN0ZXA6IElyaXNFeGVyY2lzZVBsYW5TdGVwKSB7XG4gICAgICAgIGlmICghKHRoaXMuc2Vzc2lvblNlcnZpY2UgaW5zdGFuY2VvZiBJcmlzQ29kZUVkaXRvclNlc3Npb25TZXJ2aWNlKSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICghc3RlcC5pZCB8fCAhc3RlcC5wbGFuKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdDb3VsZCBub3QgZXhlY3V0ZSBwbGFuIHN0ZXAsIG9uZSBvZiB0aGUgcmVxdWlyZWQgaWRzIGlzIG51bGw6ICcgKyBzdGVwLmlkICsgJyAnICsgc3RlcC5wbGFuKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBzdGVwLmV4ZWN1dGlvblN0YWdlID0gRXhlY3V0aW9uU3RhZ2UuSU5fUFJPR1JFU1M7XG4gICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2VcbiAgICAgICAgICAgIC5leGVjdXRlUGxhblN0ZXAodGhpcy5zZXNzaW9uSWQsIG1lc3NhZ2VJZCwgc3RlcC5wbGFuLCBzdGVwLmlkKVxuICAgICAgICAgICAgLy8gLnRoZW4oKCkgPT4gdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKG5ldyBFeGVjdXRlUGxhblN1Y2Nlc3NBY3Rpb24ocGxhbklkKSkpXG4gICAgICAgICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICAgICAgICAgIC8vdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKG5ldyBDb252ZXJzYXRpb25FcnJvck9jY3VycmVkQWN0aW9uKElyaXNFcnJvck1lc3NhZ2VLZXkuRVhFQ1VURV9QTEFOX0ZBSUxFRCkpO1xuICAgICAgICAgICAgICAgIHN0ZXAuZXhlY3V0aW9uU3RhZ2UgPSBFeGVjdXRpb25TdGFnZS5GQUlMRUQ7XG4gICAgICAgICAgICAgICAgdGhpcy5zY3JvbGxUb0JvdHRvbSgnc21vb3RoJyk7XG4gICAgICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBOb3RpZmllcyB0aGUgY2hhdCB3aWRnZXQgdGhhdCBhIHN0ZXAgb2YgYW4gZXhlcmNpc2UgcGxhbiBoYXMgYmVlbiBjb21wbGV0ZWQuXG4gICAgICogVGhpcyBtZXRob2QgaXMgY2FsbGVkIGJ5IHRoZSBjb2RlIGVkaXRvciBzZXNzaW9uIHNlcnZpY2UuXG4gICAgICogQHBhcmFtIG1lc3NhZ2VJZCAtIFRoZSBpZCBvZiB0aGUgbWVzc2FnZSB3aGljaCBjb250YWlucyB0aGUgcGxhbi5cbiAgICAgKiBAcGFyYW0gcGxhbklkIC0gVGhlIGlkIG9mIHRoZSBwbGFuLlxuICAgICAqIEBwYXJhbSBzdGVwSWQgLSBUaGUgaWQgb2YgdGhlIHN0ZXAgdGhhdCB3YXMgY29tcGxldGVkLlxuICAgICAqL1xuICAgIG5vdGlmeVN0ZXBDb21wbGV0ZWQobWVzc2FnZUlkOiBudW1iZXIsIHBsYW5JZDogbnVtYmVyLCBzdGVwSWQ6IG51bWJlcikge1xuICAgICAgICBjb25zdCBbcGxhbiwgc3RlcF0gPSB0aGlzLmZpbmRQbGFuU3RlcChtZXNzYWdlSWQsIHBsYW5JZCwgc3RlcElkKTtcbiAgICAgICAgaWYgKCFwbGFuIHx8ICFzdGVwKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc3RlcC5leGVjdXRpb25TdGFnZSA9IEV4ZWN1dGlvblN0YWdlLkNPTVBMRVRFO1xuICAgICAgICBpZiAocGxhbi5leGVjdXRpbmcpIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHRTdGVwSW5kZXggPSB0aGlzLmdldE5leHRTdGVwSW5kZXgocGxhbik7XG4gICAgICAgICAgICBpZiAobmV4dFN0ZXBJbmRleCA8IHBsYW4uc3RlcHMubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgLy8gVGhlIHBsYW4gaXMgc3RpbGwgZXhlY3V0aW5nIGFuZCB0aGVyZSBhcmUgbW9yZSBzdGVwcyB0byBleGVjdXRlXG4gICAgICAgICAgICAgICAgdGhpcy5leGVjdXRlUGxhblN0ZXAobWVzc2FnZUlkLCBwbGFuLnN0ZXBzW25leHRTdGVwSW5kZXhdKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcGxhbi5leGVjdXRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIG5vdGlmeVN0ZXBGYWlsZWQobWVzc2FnZUlkOiBudW1iZXIsIHBsYW5JZDogbnVtYmVyLCBzdGVwSWQ6IG51bWJlciwgZXJyb3JUcmFuc2xhdGlvbktleT86IElyaXNFcnJvck1lc3NhZ2VLZXksIHRyYW5zbGF0aW9uUGFyYW1zPzogTWFwPHN0cmluZywgYW55Pikge1xuICAgICAgICBjb25zdCBbcGxhbiwgc3RlcF0gPSB0aGlzLmZpbmRQbGFuU3RlcChtZXNzYWdlSWQsIHBsYW5JZCwgc3RlcElkKTtcbiAgICAgICAgaWYgKCFwbGFuIHx8ICFzdGVwKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgcGxhbi5leGVjdXRpbmcgPSBmYWxzZTtcbiAgICAgICAgc3RlcC5leGVjdXRpb25TdGFnZSA9IEV4ZWN1dGlvblN0YWdlLkZBSUxFRDtcbiAgICAgICAgaWYgKCFlcnJvclRyYW5zbGF0aW9uS2V5KSB7XG4gICAgICAgICAgICB0aGlzLnN0YXRlU3RvcmUuZGlzcGF0Y2gobmV3IENvbnZlcnNhdGlvbkVycm9yT2NjdXJyZWRBY3Rpb24oSXJpc0Vycm9yTWVzc2FnZUtleS5URUNITklDQUxfRVJST1JfUkVTUE9OU0UpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuc3RhdGVTdG9yZS5kaXNwYXRjaChuZXcgQ29udmVyc2F0aW9uRXJyb3JPY2N1cnJlZEFjdGlvbihlcnJvclRyYW5zbGF0aW9uS2V5LCB0cmFuc2xhdGlvblBhcmFtcykpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBmaW5kUGxhblN0ZXAobWVzc2FnZUlkOiBudW1iZXIsIHBsYW5JZDogbnVtYmVyLCBzdGVwSWQ6IG51bWJlcik6IFtJcmlzRXhlcmNpc2VQbGFuPywgSXJpc0V4ZXJjaXNlUGxhblN0ZXA/XSB7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSB0aGlzLm1lc3NhZ2VzLmZpbmQoKG0pID0+IG0uaWQgPT09IG1lc3NhZ2VJZCk7XG4gICAgICAgIGlmICghbWVzc2FnZSkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignQ291bGQgbm90IGZpbmQgbWVzc2FnZSB3aXRoIGlkICcgKyBtZXNzYWdlSWQpO1xuICAgICAgICAgICAgcmV0dXJuIFt1bmRlZmluZWQsIHVuZGVmaW5lZF07XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcGxhbiA9IG1lc3NhZ2UuY29udGVudC5maW5kKChjKSA9PiBjLmlkID09PSBwbGFuSWQpIGFzIElyaXNFeGVyY2lzZVBsYW47XG4gICAgICAgIGlmICghcGxhbikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignQ291bGQgbm90IGZpbmQgcGxhbiB3aXRoIGlkICcgKyBwbGFuSWQpO1xuICAgICAgICAgICAgcmV0dXJuIFt1bmRlZmluZWQsIHVuZGVmaW5lZF07XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3RlcCA9IHBsYW4uc3RlcHMuZmluZCgocykgPT4gcy5pZCA9PT0gc3RlcElkKTtcbiAgICAgICAgaWYgKCFzdGVwKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdDb3VsZCBub3QgZmluZCBleGVyY2lzZSBzdGVwIHdpdGggaWQgJyArIHN0ZXBJZCk7XG4gICAgICAgICAgICByZXR1cm4gW3BsYW4sIHVuZGVmaW5lZF07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFtwbGFuLCBzdGVwXTtcbiAgICB9XG5cbiAgICBnZXRTdGVwQ29sb3Ioc3RlcDogSXJpc0V4ZXJjaXNlUGxhblN0ZXApIHtcbiAgICAgICAgc3dpdGNoIChzdGVwLmV4ZWN1dGlvblN0YWdlKSB7XG4gICAgICAgICAgICBjYXNlIEV4ZWN1dGlvblN0YWdlLk5PVF9FWEVDVVRFRDpcbiAgICAgICAgICAgICAgICByZXR1cm4gJ3ZhcigtLWlyaXMtY2hhdC13aWRnZXQtYmFja2dyb3VuZCknO1xuICAgICAgICAgICAgY2FzZSBFeGVjdXRpb25TdGFnZS5JTl9QUk9HUkVTUzpcbiAgICAgICAgICAgICAgICByZXR1cm4gJyNmZmMxMDcnO1xuICAgICAgICAgICAgY2FzZSBFeGVjdXRpb25TdGFnZS5DT01QTEVURTpcbiAgICAgICAgICAgICAgICByZXR1cm4gJyMyOGE3NDUnO1xuICAgICAgICAgICAgY2FzZSBFeGVjdXRpb25TdGFnZS5GQUlMRUQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuICcjZGMzNTQ1JztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGdldFN0ZXBOYW1lKHN0ZXA6IElyaXNFeGVyY2lzZVBsYW5TdGVwKSB7XG4gICAgICAgIHN3aXRjaCAoc3RlcC5jb21wb25lbnQpIHtcbiAgICAgICAgICAgIGNhc2UgRXhlcmNpc2VDb21wb25lbnQuUFJPQkxFTV9TVEFURU1FTlQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuICdQcm9ibGVtIFN0YXRlbWVudCc7XG4gICAgICAgICAgICBjYXNlIEV4ZXJjaXNlQ29tcG9uZW50LlNPTFVUSU9OX1JFUE9TSVRPUlk6XG4gICAgICAgICAgICAgICAgcmV0dXJuICdTb2x1dGlvbiBSZXBvc2l0b3J5JztcbiAgICAgICAgICAgIGNhc2UgRXhlcmNpc2VDb21wb25lbnQuVEVNUExBVEVfUkVQT1NJVE9SWTpcbiAgICAgICAgICAgICAgICByZXR1cm4gJ1RlbXBsYXRlIFJlcG9zaXRvcnknO1xuICAgICAgICAgICAgY2FzZSBFeGVyY2lzZUNvbXBvbmVudC5URVNUX1JFUE9TSVRPUlk6XG4gICAgICAgICAgICAgICAgcmV0dXJuICdUZXN0IFJlcG9zaXRvcnknO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZ2V0U3RlcFN0YXR1cyhzdGVwOiBJcmlzRXhlcmNpc2VQbGFuU3RlcCkge1xuICAgICAgICBzd2l0Y2ggKHN0ZXAuZXhlY3V0aW9uU3RhZ2UpIHtcbiAgICAgICAgICAgIGNhc2UgRXhlY3V0aW9uU3RhZ2UuTk9UX0VYRUNVVEVEOlxuICAgICAgICAgICAgICAgIHJldHVybiAnJztcbiAgICAgICAgICAgIGNhc2UgRXhlY3V0aW9uU3RhZ2UuSU5fUFJPR1JFU1M6XG4gICAgICAgICAgICAgICAgcmV0dXJuICdHZW5lcmF0aW5nIGNoYW5nZXMsIHBsZWFzZSBiZSBwYXRpZW50Li4uJztcbiAgICAgICAgICAgIGNhc2UgRXhlY3V0aW9uU3RhZ2UuQ09NUExFVEU6XG4gICAgICAgICAgICAgICAgcmV0dXJuICdDaGFuZ2VzIGFwcGxpZWQuJztcbiAgICAgICAgICAgIGNhc2UgRXhlY3V0aW9uU3RhZ2UuRkFJTEVEOlxuICAgICAgICAgICAgICAgIHJldHVybiAnRW5jb3VudGVyZWQgYW4gZXJyb3IuJztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYSBuZXcgdXNlciBtZXNzYWdlLlxuICAgICAqIEBwYXJhbSBtZXNzYWdlIC0gVGhlIGNvbnRlbnQgb2YgdGhlIG1lc3NhZ2UuXG4gICAgICogQHJldHVybnMgQSBuZXcgSXJpc0NsaWVudE1lc3NhZ2Ugb2JqZWN0IHJlcHJlc2VudGluZyB0aGUgdXNlciBtZXNzYWdlLlxuICAgICAqL1xuICAgIG5ld1VzZXJNZXNzYWdlKG1lc3NhZ2U6IHN0cmluZyk6IElyaXNVc2VyTWVzc2FnZSB7XG4gICAgICAgIGNvbnN0IGNvbnRlbnQgPSBuZXcgSXJpc1RleHRNZXNzYWdlQ29udGVudChtZXNzYWdlKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHNlbmRlcjogSXJpc1NlbmRlci5VU0VSLFxuICAgICAgICAgICAgY29udGVudDogW2NvbnRlbnRdLFxuICAgICAgICB9O1xuICAgIH1cblxuICAgIGlzU2VuZE1lc3NhZ2VGYWlsZWRFcnJvcigpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZXJyb3I/LmtleSA9PSBJcmlzRXJyb3JNZXNzYWdlS2V5LlNFTkRfTUVTU0FHRV9GQUlMRUQgfHwgdGhpcy5lcnJvcj8ua2V5ID09IElyaXNFcnJvck1lc3NhZ2VLZXkuSVJJU19TRVJWRVJfUkVTUE9OU0VfVElNRU9VVDtcbiAgICB9XG5cbiAgICB0b2dnbGVTY3JvbGxMb2NrKGxvY2tQYXJlbnQ6IGJvb2xlYW4pOiB2b2lkIHtcbiAgICAgICAgaWYgKGxvY2tQYXJlbnQpIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LmFkZCgnY2RrLWdsb2JhbC1zY3JvbGwnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnJlbW92ZSgnY2RrLWdsb2JhbC1zY3JvbGwnKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGRlYWN0aXZhdGVTdWJtaXRCdXR0b24oKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiAhdGhpcy51c2VyQWNjZXB0ZWQgfHwgdGhpcy5pc0xvYWRpbmcgfHwgKCEhdGhpcy5lcnJvciAmJiB0aGlzLmVycm9yLmZhdGFsKTtcbiAgICB9XG5cbiAgICBpc0VtcHR5TWVzc2FnZUVycm9yKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gISF0aGlzLmVycm9yICYmIHRoaXMuZXJyb3Iua2V5ID09IElyaXNFcnJvck1lc3NhZ2VLZXkuRU1QVFlfTUVTU0FHRTtcbiAgICB9XG5cbiAgICBvbkZhZGVBbmltYXRpb25QaGFzZUVuZChldmVudDogQW5pbWF0aW9uRXZlbnQpIHtcbiAgICAgICAgaWYgKGV2ZW50LmZyb21TdGF0ZSA9PT0gJ3ZvaWQnICYmIGV2ZW50LnRvU3RhdGUgPT09ICdzdGFydCcpIHtcbiAgICAgICAgICAgIHRoaXMuZmFkZVN0YXRlID0gJ2VuZCc7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGV2ZW50LmZyb21TdGF0ZSA9PT0gJ3N0YXJ0JyAmJiBldmVudC50b1N0YXRlID09PSAnZW5kJykge1xuICAgICAgICAgICAgdGhpcy5zaG91bGRTaG93RW1wdHlNZXNzYWdlRXJyb3IgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGdldENvbnZlcnRlZEVycm9yTWFwKCkge1xuICAgICAgICBpZiAodGhpcy5lcnJvcj8ucGFyYW1zTWFwKSB7XG4gICAgICAgICAgICAvLyBDaGVjayBpZiBwYXJhbXNNYXAgaXMgaXRlcmFibGUuXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuZXJyb3I/LnBhcmFtc01hcFtTeW1ib2wuaXRlcmF0b3JdID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyh0aGlzLmVycm9yLnBhcmFtc01hcCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5lcnJvci5wYXJhbXNNYXA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgaXNDbGVhckNoYXRCdXR0b25FbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5tZXNzYWdlcy5sZW5ndGggPiAxIHx8ICh0aGlzLm1lc3NhZ2VzLmxlbmd0aCA9PT0gMSAmJiAhaXNBcnRlbWlzQ2xpZW50U2VudE1lc3NhZ2UodGhpcy5tZXNzYWdlc1swXSkpO1xuICAgIH1cblxuICAgIGNyZWF0ZU5ld1Nlc3Npb24oKSB7XG4gICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuY3JlYXRlTmV3U2Vzc2lvbih0aGlzLmV4ZXJjaXNlSWQpO1xuICAgIH1cblxuICAgIGlzQ2hhdFNlc3Npb24oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlc3Npb25TZXJ2aWNlIGluc3RhbmNlb2YgSXJpc0NoYXRTZXNzaW9uU2VydmljZTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgcmVhZG9ubHkgSXJpc1NlbmRlciA9IElyaXNTZW5kZXI7XG4gICAgcHJvdGVjdGVkIHJlYWRvbmx5IGlzSW5Qcm9ncmVzcyA9IGlzSW5Qcm9ncmVzcztcbiAgICBwcm90ZWN0ZWQgcmVhZG9ubHkgZ2V0VGV4dENvbnRlbnQgPSBnZXRUZXh0Q29udGVudDtcbiAgICBwcm90ZWN0ZWQgcmVhZG9ubHkgaXNUZXh0Q29udGVudCA9IGlzVGV4dENvbnRlbnQ7XG4gICAgcHJvdGVjdGVkIHJlYWRvbmx5IGlzTm90RXhlY3V0ZWQgPSBpc05vdEV4ZWN1dGVkO1xuICAgIHByb3RlY3RlZCByZWFkb25seSBpc0V4ZXJjaXNlUGxhbiA9IGlzRXhlcmNpc2VQbGFuO1xuICAgIHByb3RlY3RlZCByZWFkb25seSBpc0hpZGRlbiA9IGlzSGlkZGVuO1xuICAgIHByb3RlY3RlZCByZWFkb25seSBoaWRlT3JVbmhpZGUgPSBoaWRlT3JVbmhpZGU7XG4gICAgcHJvdGVjdGVkIHJlYWRvbmx5IGlzU3R1ZGVudFNlbnRNZXNzYWdlID0gaXNTdHVkZW50U2VudE1lc3NhZ2U7XG4gICAgcHJvdGVjdGVkIHJlYWRvbmx5IGlzU2VydmVyU2VudE1lc3NhZ2UgPSBpc1NlcnZlclNlbnRNZXNzYWdlO1xuICAgIHByb3RlY3RlZCByZWFkb25seSBpc0FydGVtaXNDbGllbnRTZW50TWVzc2FnZSA9IGlzQXJ0ZW1pc0NsaWVudFNlbnRNZXNzYWdlO1xufVxuIiwiPGRpdiBjbGFzcz1cImNvbnRhaW5lclwiIChtb3VzZWVudGVyKT1cInRvZ2dsZVNjcm9sbExvY2sodHJ1ZSlcIiAobW91c2VsZWF2ZSk9XCJ0b2dnbGVTY3JvbGxMb2NrKGZhbHNlKVwiPlxuICAgIDwhLS0gY2hhdCBib3ggLS0+XG4gICAgPGRpdiBjbGFzcz1cImNoYXQtd2lkZ2V0XCI+XG4gICAgICAgIDwhLS0gY2xpZW50IC0tPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2xpZW50XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2hhdC1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3M9XCJoZWFkZXItc3RhcnRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGpoaS1pcmlzLWxvZ28gW3NpemVdPVwiSXJpc0xvZ29TaXplLlNNQUxMXCI+PC9qaGktaXJpcy1sb2dvPlxuICAgICAgICAgICAgICAgICAgICBJcmlzXG4gICAgICAgICAgICAgICAgICAgIDxhIFtyb3V0ZXJMaW5rXT1cIicvYWJvdXQtaXJpcydcIiB0YXJnZXQ9XCJfYmxhbmtcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQ2lyY2xlSW5mb1wiIGNsYXNzPVwiaW5mby1idXR0b25cIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJidXR0b24tY29udGFpbmVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHJhdGVMaW1pdCA+PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJyYXRlLWxpbWl0XCIgW25nYlRvb2x0aXBdPVwiJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LnJhdGVMaW1pdFRvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZTogeyBob3VyczogcmF0ZUxpbWl0VGltZWZyYW1lSG91cnMgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID57eyBjdXJyZW50TWVzc2FnZUNvdW50IH19L3t7IHJhdGVMaW1pdCB9fTwvc3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoaXNDbGVhckNoYXRCdXR0b25FbmFibGVkKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiY2xlYXItY2hhdC1idXR0b25cIiAoY2xpY2spPVwib25DbGVhclNlc3Npb24oY2xlYXJDb25maXJtTW9kYWwpXCIgY2xhc3M9XCJoZWFkZXItaWNvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVRyYXNoXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghZnVsbFNpemUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIChjbGljayk9XCJtYXhpbWl6ZVNjcmVlbigpXCIgY2xhc3M9XCJoZWFkZXItaWNvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUV4cGFuZFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZnVsbFNpemUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIChjbGljayk9XCJtaW5pbWl6ZVNjcmVlbigpXCIgY2xhc3M9XCJoZWFkZXItaWNvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUNvbXByZXNzXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwiY2xvc2VDaGF0KClcIiBjbGFzcz1cImhlYWRlci1pY29uXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFYbWFya1wiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPG5nLXRlbXBsYXRlICNjbGVhckNvbmZpcm1Nb2RhbCBsZXQtbW9kYWw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtaGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzPVwibW9kYWwtdGl0bGVcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LmNsZWFyU2Vzc2lvbi50aXRsZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tY2xvc2VcIiBhcmlhLWxhYmVsPVwiQ2xvc2VcIiAoY2xpY2spPVwibW9kYWwuZGlzbWlzcygpXCI+PC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1ib2R5XCI+XG4gICAgICAgICAgICAgICAgPHA+e3sgJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LmNsZWFyU2Vzc2lvbi50ZXh0JyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1mb290ZXJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0biBidG4tZGFuZ2VyXCIgKGNsaWNrKT1cIm1vZGFsLmNsb3NlKCdjb25maXJtJylcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LmNsZWFyU2Vzc2lvbi5zdWJtaXQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICA8IS0tIG1haW4gY2hhdCBzZWN0aW9uIC0tPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2hhdC1ib2R5XCIgI2NoYXRCb2R5IChzY3JvbGwpPVwiY2hlY2tDaGF0U2Nyb2xsKClcIj5cbiAgICAgICAgICAgIEBmb3IgKG1lc3NhZ2Ugb2YgbWVzc2FnZXM7IHRyYWNrIG1lc3NhZ2U7IGxldCBpID0gJGluZGV4KSB7XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgQGlmIChpID09PSB1bnJlYWRNZXNzYWdlSW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidW5yZWFkLW1lc3NhZ2VcIiAjdW5yZWFkTWVzc2FnZT57eyAnYXJ0ZW1pc0FwcC5leGVyY2lzZUNoYXRib3QudW5yZWFkTWVzc2FnZXMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAZm9yIChjb250ZW50IG9mIG1lc3NhZ2UuY29udGVudDsgdHJhY2sgY29udGVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGlzU3R1ZGVudFNlbnRNZXNzYWdlKG1lc3NhZ2UpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJkaXNwbGF5OiBmbGV4XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwiZGlzcGxheTogZmxleDsgbWFyZ2luLWxlZnQ6IGF1dG87IG1hcmdpbi1yaWdodDogMDsgcGFkZGluZy1yaWdodDogNXB4XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaSA9PT0gbWVzc2FnZXMubGVuZ3RoIC0gMSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnNlbmRlciA9PT0gSXJpc1NlbmRlci5VU0VSICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICF0aGlzLmlzTG9hZGluZyAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhKHJhdGVMaW1pdCA+PSAwICYmIGN1cnJlbnRNZXNzYWdlQ291bnQgPj0gcmF0ZUxpbWl0KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInJlc2VuZEJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT1cImFsbDogdW5zZXQ7IGRpc3BsYXk6IGZsZXg7IGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0OyBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47IGN1cnNvcjogcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwicmVzZW5kTWVzc2FnZShtZXNzYWdlKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbZGlzYWJsZWRdPVwicmVzZW5kQW5pbWF0aW9uQWN0aXZlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFSZWRvXCIgc2l6ZT1cInNtXCIgW25nQ2xhc3NdPVwicmVzZW5kQW5pbWF0aW9uQWN0aXZlID8gJ2ZhLXB1bHNlJyA6ICcnXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoaXNUZXh0Q29udGVudChjb250ZW50KSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJkaXNwbGF5OiBmbGV4XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwcmU+PHNwYW4gW2lubmVySFRNTF09XCJnZXRUZXh0Q29udGVudChjb250ZW50KSEgfCBodG1sRm9yTWFya2Rvd25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidWJibGUtcmlnaHRcIj48L3NwYW4+PC9wcmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGlzU2VydmVyU2VudE1lc3NhZ2UobWVzc2FnZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT1cIndpZHRoOiBmaXQtY29udGVudFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChpc1RleHRDb250ZW50KGNvbnRlbnQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJ1YmJsZS1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIFtpbm5lckhUTUxdPVwiZ2V0VGV4dENvbnRlbnQoY29udGVudCkhIHwgaHRtbEZvck1hcmtkb3duXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChpc1RleHRDb250ZW50KGNvbnRlbnQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJhdGUtbWVzc2FnZS1idXR0b25zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gc3R5bGU9XCJhbGw6IHVuc2V0XCIgKGNsaWNrKT1cInJhdGVNZXNzYWdlKG1lc3NhZ2UuaWQsIGksIHRydWUpXCIgW2Rpc2FibGVkXT1cIm1lc3NhZ2UuaGVscGZ1bFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3NdPVwibWVzc2FnZS5oZWxwZnVsID8gJ3RodW1icy11cC1jbGlja2VkJyA6ICdjbGlja2FibGUgcmF0ZS1idXR0b24tbm90LWNsaWNrZWQnXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT1cIm1hcmdpbi1yaWdodDogMTVweFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2ljb25dPVwiZmFUaHVtYnNVcFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHN0eWxlPVwiYWxsOiB1bnNldFwiIChjbGljayk9XCJyYXRlTWVzc2FnZShtZXNzYWdlLmlkLCBpLCBmYWxzZSlcIiBbZGlzYWJsZWRdPVwiIW1lc3NhZ2UuaGVscGZ1bFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3NdPVwibWVzc2FnZS5oZWxwZnVsID09PSBmYWxzZSA/ICd0aHVtYnMtZG93bi1jbGlja2VkJyA6ICdjbGlja2FibGUgcmF0ZS1idXR0b24tbm90LWNsaWNrZWQnXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbaWNvbl09XCJmYVRodW1ic0Rvd25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoaXNFeGVyY2lzZVBsYW4oY29udGVudCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYnViYmxlLWxlZnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAoc3RlcCBvZiBjb250ZW50LnN0ZXBzOyB0cmFjayBzdGVwOyBsZXQgaSA9ICRpbmRleCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8IS0tIHN0ZXAgY29tcG9uZW50IHdpdGggc2hvdy9oaWRlIGJ1dHRvbiAtLT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IFtuZ1N0eWxlXT1cInsgJ2JhY2tncm91bmQtY29sb3InOiBnZXRTdGVwQ29sb3Ioc3RlcCkgfVwiIFtuZ0NsYXNzXT1cImlzSGlkZGVuKHN0ZXApID8gJ3Nob3ctZGV0YWlscycgOiAnaGlkZS1kZXRhaWxzJ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3RlcC1jb21wb25lbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIFtpbm5lckhUTUxdPVwiZ2V0U3RlcE5hbWUoc3RlcCkgfCBodG1sRm9yTWFya2Rvd25cIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIChjbGljayk9XCJoaWRlT3JVbmhpZGUoc3RlcClcIiBjbGFzcz1cImRldGFpbC1idG4gc3RlcC10aXRsZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGlzSGlkZGVuKHN0ZXApID8gJ1Nob3cgRGV0YWlscycgOiAnSGlkZSBEZXRhaWxzJyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInN0ZXAtc3RhdHVzXCIgW2lubmVySFRNTF09XCJnZXRTdGVwU3RhdHVzKHN0ZXApIHwgaHRtbEZvck1hcmtkb3duXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gc3RlcCBpbnN0cnVjdGlvbnMgKGVkaXRhYmxlKSBpbiBhIHRleHQgYm94IC0tPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWlzSGlkZGVuKHN0ZXApKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgW2F0dHIuY29udGVudGVkaXRhYmxlXT1cImlzTm90RXhlY3V0ZWQoc3RlcClcIiBjbGFzcz1cInN0ZXAtZGV0YWlsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBbaW5uZXJIVE1MXT1cInN0ZXAuaW5zdHJ1Y3Rpb25zISB8IGh0bWxGb3JNYXJrZG93blwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gbG9hZGluZyBpY29uIC0tPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoaXNJblByb2dyZXNzKHN0ZXApKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImZhIGZhLXNwaW5uZXIgZmEtc3BpblwiPjwvaT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPCEtLSBleGVjdXRlL3BhdXNlIGJ1dHRvbiAtLT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImV4ZWN1dGUtYnV0dG9uXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKCFjb250ZW50LmV4ZWN1dGluZykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIiAoY2xpY2spPVwic2V0RXhlY3V0aW5nKG1lc3NhZ2UuaWQsIGNvbnRlbnQpXCIgW2Rpc2FibGVkXT1cIiFjYW5FeGVjdXRlKGNvbnRlbnQpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBnZXRQbGFuQnV0dG9uVGl0bGUoY29udGVudCkgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGNvbnRlbnQuZXhlY3V0aW5nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwicGF1c2VQbGFuKGNvbnRlbnQpXCIgY2xhc3M9XCJidG4gYnRuLWRhbmdlclwiPlBhdXNlPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChpc0FydGVtaXNDbGllbnRTZW50TWVzc2FnZShtZXNzYWdlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwid2lkdGg6IGZpdC1jb250ZW50XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGlzVGV4dENvbnRlbnQoY29udGVudCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYnViYmxlLWxlZnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gW2lubmVySFRNTF09XCJnZXRUZXh0Q29udGVudChjb250ZW50KSFcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKGlzTG9hZGluZykge1xuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJidWJibGUtbGVmdFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmxpbmtpbmctZG90c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAoXyBvZiBbXS5jb25zdHJ1Y3Rvcihkb3RzKTsgdHJhY2sgXykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWlubGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUNpcmNsZVwiIHNpemU9XCJ4c1wiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKCF1c2VyQWNjZXB0ZWQpIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicC1jaGF0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtZXNzYWdlLXRleHRcIj57eyAnYXJ0ZW1pc0FwcC5leGVyY2lzZUNoYXRib3QucG9wVXBNZXNzYWdlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJ1dHRvbi1jb250YWluZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidXR0b25cIiAoY2xpY2spPVwiYWNjZXB0UGVybWlzc2lvbigpXCI+e3sgJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LmFjY2VwdCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnV0dG9uXCIgKGNsaWNrKT1cImNsb3NlQ2hhdCgpXCI+e3sgJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LmRlY2xpbmUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzY3JvbGwtdG8tYm90dG9tXCIgW2hpZGRlbl09XCJpc1Njcm9sbGVkVG9Cb3R0b21cIiAoY2xpY2spPVwic2Nyb2xsVG9Cb3R0b20oJ3Ntb290aCcpXCIgI3Njcm9sbEFycm93PlxuICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQXJyb3dEb3duXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICBAaWYgKHNob3VsZFNob3dFbXB0eU1lc3NhZ2VFcnJvciAmJiBlcnJvciAmJiBpc0VtcHR5TWVzc2FnZUVycm9yKCkpIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2xpZW50LWNoYXQtZXJyb3JcIiBbQGZhZGVBbmltYXRpb25dPVwiZmFkZVN0YXRlXCIgKEBmYWRlQW5pbWF0aW9uLmRvbmUpPVwib25GYWRlQW5pbWF0aW9uUGhhc2VFbmQoJGV2ZW50KVwiPlxuICAgICAgICAgICAgICAgICAgICB7eyBlcnJvci5rZXkgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKGVycm9yICYmICFpc0VtcHR5TWVzc2FnZUVycm9yKCkpIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2xpZW50LWNoYXQtZXJyb3JcIj5cbiAgICAgICAgICAgICAgICAgICAge3sgZXJyb3Iua2V5IHwgYXJ0ZW1pc1RyYW5zbGF0ZTogZ2V0Q29udmVydGVkRXJyb3JNYXAoKSB9fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPCEtLSBpbnB1dCBmaWVsZCBzZWN0aW9uIC0tPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2hhdC1pbnB1dFwiPlxuICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJuZXdNZXNzYWdlVGV4dENvbnRlbnRcIlxuICAgICAgICAgICAgICAgIHJvd3M9XCIxXCJcbiAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiXG4gICAgICAgICAgICAgICAgKG5nTW9kZWxDaGFuZ2UpPVwib25Sb3dDaGFuZ2UoKVwiXG4gICAgICAgICAgICAgICAgKGlucHV0KT1cIm9uSW5wdXQoKVwiXG4gICAgICAgICAgICAgICAgKHBhc3RlKT1cIm9uUGFzdGUoKVwiXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIChrZXlkb3duKT1cImhhbmRsZUtleSgkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInt7ICdhcnRlbWlzQXBwLmV4ZXJjaXNlQ2hhdGJvdC5pbnB1dE1lc3NhZ2UnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVwiXG4gICAgICAgICAgICAgICAgI21lc3NhZ2VUZXh0YXJlYVxuICAgICAgICAgICAgPjwvdGV4dGFyZWE+XG4gICAgICAgICAgICA8amhpLWJ1dHRvbiBpZD1cInNlbmRCdXR0b25cIiAob25DbGljayk9XCJvblNlbmQoKVwiIFtidG5UeXBlXT1cIkJ1dHRvblR5cGUuU1VDQ0VTU1wiIFtpY29uXT1cImZhUGFwZXJQbGFuZVwiIHN0eWxlPVwibWFyZ2luLWJvdHRvbTogYXV0b1wiIFtkaXNhYmxlZF09XCJkZWFjdGl2YXRlU3VibWl0QnV0dG9uKClcIj5cbiAgICAgICAgICAgIDwvamhpLWJ1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IGZhQ2hldnJvbkRvd24sIGZhQ2lyY2xlLCBmYUNvbW1lbnREb3RzIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IENvbXBvbmVudCwgT25EZXN0cm95LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE1hdERpYWxvZywgTWF0RGlhbG9nUmVmIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvZGlhbG9nJztcbmltcG9ydCB7IElyaXNDaGF0Ym90V2lkZ2V0Q29tcG9uZW50IH0gZnJvbSAnYXBwL2lyaXMvZXhlcmNpc2UtY2hhdGJvdC93aWRnZXQvY2hhdGJvdC13aWRnZXQuY29tcG9uZW50JztcbmltcG9ydCB7IE92ZXJsYXkgfSBmcm9tICdAYW5ndWxhci9jZGsvb3ZlcmxheSc7XG5pbXBvcnQgeyBJcmlzU3RhdGVTdG9yZSB9IGZyb20gJ2FwcC9pcmlzL3N0YXRlLXN0b3JlLnNlcnZpY2UnO1xuaW1wb3J0IHsgTnVtTmV3TWVzc2FnZXNSZXNldEFjdGlvbiB9IGZyb20gJ2FwcC9pcmlzL3N0YXRlLXN0b3JlLm1vZGVsJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgU2hhcmVkU2VydmljZSB9IGZyb20gJ2FwcC9pcmlzL3NoYXJlZC5zZXJ2aWNlJztcbmltcG9ydCB7IElyaXNTZXNzaW9uU2VydmljZSB9IGZyb20gJ2FwcC9pcmlzL3Nlc3Npb24uc2VydmljZSc7XG5cbkBDb21wb25lbnQoeyB0ZW1wbGF0ZTogJycgfSlcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBJcmlzQ2hhdGJvdEJ1dHRvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcbiAgICBkaWFsb2dSZWY6IE1hdERpYWxvZ1JlZjxJcmlzQ2hhdGJvdFdpZGdldENvbXBvbmVudD4gfCBudWxsID0gbnVsbDtcbiAgICBjaGF0T3BlbiA9IGZhbHNlO1xuICAgIGhhc05ld01lc3NhZ2VzID0gZmFsc2U7XG4gICAgcHJvdGVjdGVkIGNvdXJzZUlkOiBudW1iZXI7XG4gICAgcHJvdGVjdGVkIGV4ZXJjaXNlSWQ6IG51bWJlcjtcbiAgICBwcml2YXRlIHN0YXRlU3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb247XG4gICAgcHJpdmF0ZSBjaGF0T3BlblN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUNpcmNsZSA9IGZhQ2lyY2xlO1xuICAgIGZhQ29tbWVudERvdHMgPSBmYUNvbW1lbnREb3RzO1xuICAgIGZhQ2hldnJvbkRvd24gPSBmYUNoZXZyb25Eb3duO1xuXG4gICAgcHJvdGVjdGVkIGNvbnN0cnVjdG9yKFxuICAgICAgICBwdWJsaWMgZGlhbG9nOiBNYXREaWFsb2csXG4gICAgICAgIHByb3RlY3RlZCBvdmVybGF5OiBPdmVybGF5LFxuICAgICAgICBwcm90ZWN0ZWQgcmVhZG9ubHkgc2Vzc2lvblNlcnZpY2U6IElyaXNTZXNzaW9uU2VydmljZSxcbiAgICAgICAgcHJvdGVjdGVkIHJlYWRvbmx5IHN0YXRlU3RvcmU6IElyaXNTdGF0ZVN0b3JlLFxuICAgICAgICBwcml2YXRlIHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSxcbiAgICAgICAgcHJpdmF0ZSBzaGFyZWRTZXJ2aWNlOiBTaGFyZWRTZXJ2aWNlLFxuICAgICkge31cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICAvLyBTdWJzY3JpYmVzIHRvIHJvdXRlIHBhcmFtcyBhbmQgZ2V0cyB0aGUgZXhlcmNpc2VJZCBmcm9tIHRoZSByb3V0ZVxuICAgICAgICB0aGlzLnJvdXRlLnBhcmFtcy5zdWJzY3JpYmUoKHBhcmFtcykgPT4ge1xuICAgICAgICAgICAgdGhpcy5jb3Vyc2VJZCA9IHBhcnNlSW50KHBhcmFtc1snY291cnNlSWQnXSwgMTApO1xuICAgICAgICAgICAgdGhpcy5leGVyY2lzZUlkID0gcGFyc2VJbnQocGFyYW1zWydleGVyY2lzZUlkJ10sIDEwKTtcbiAgICAgICAgICAgIGlmICh0aGlzLmV4ZXJjaXNlSWQgIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0Q3VycmVudFNlc3Npb25PckNyZWF0ZSh0aGlzLmV4ZXJjaXNlSWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICAvLyBTdWJzY3JpYmVzIHRvIHRoZSBzdGF0ZVN0b3JlIHRvIGNoZWNrIGZvciBuZXcgbWVzc2FnZXNcbiAgICAgICAgdGhpcy5zdGF0ZVN1YnNjcmlwdGlvbiA9IHRoaXMuc3RhdGVTdG9yZS5nZXRTdGF0ZSgpLnN1YnNjcmliZSgoc3RhdGUpID0+IHtcbiAgICAgICAgICAgIHRoaXMuaGFzTmV3TWVzc2FnZXMgPSBzdGF0ZS5udW1OZXdNZXNzYWdlcyA+IDA7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIFN1YnNjcmliZXMgdG8gdGhlIHNoYXJlZFNlcnZpY2UgdG8gZ2V0IHRoZSBzdGF0dXMgb2YgY2hhdE9wZW5cbiAgICAgICAgdGhpcy5jaGF0T3BlblN1YnNjcmlwdGlvbiA9IHRoaXMuc2hhcmVkU2VydmljZS5jaGF0T3Blbi5zdWJzY3JpYmUoKG9wZW4pID0+ICh0aGlzLmNoYXRPcGVuID0gb3BlbikpO1xuICAgIH1cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICAvLyBDbG9zZXMgdGhlIGRpYWxvZyBpZiBpdCBpcyBvcGVuXG4gICAgICAgIGlmICh0aGlzLmRpYWxvZ1JlZikge1xuICAgICAgICAgICAgdGhpcy5kaWFsb2dSZWYuY2xvc2UoKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBVbnN1YnNjcmliZXMgZnJvbSB0aGUgc3RhdGVTdWJzY3JpcHRpb25cbiAgICAgICAgdGhpcy5zdGF0ZVN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICB0aGlzLmNoYXRPcGVuU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSGFuZGxlcyB0aGUgY2xpY2sgZXZlbnQgb2YgdGhlIGJ1dHRvbi5cbiAgICAgKiBJZiB0aGUgY2hhdCBpcyBvcGVuLCBpdCByZXNldHMgdGhlIG51bWJlciBvZiBuZXcgbWVzc2FnZXMsIGNsb3NlcyB0aGUgZGlhbG9nLCBhbmQgc2V0cyBjaGF0T3BlbiB0byBmYWxzZS5cbiAgICAgKiBJZiB0aGUgY2hhdCBpcyBjbG9zZWQsIGl0IG9wZW5zIHRoZSBjaGF0IGRpYWxvZyBhbmQgc2V0cyBjaGF0T3BlbiB0byB0cnVlLlxuICAgICAqL1xuICAgIHB1YmxpYyBoYW5kbGVCdXR0b25DbGljaygpIHtcbiAgICAgICAgaWYgKHRoaXMuY2hhdE9wZW4gJiYgdGhpcy5kaWFsb2dSZWYpIHtcbiAgICAgICAgICAgIHRoaXMuc3RhdGVTdG9yZS5kaXNwYXRjaChuZXcgTnVtTmV3TWVzc2FnZXNSZXNldEFjdGlvbigpKTtcbiAgICAgICAgICAgIHRoaXMuZGlhbG9nLmNsb3NlQWxsKCk7XG4gICAgICAgICAgICB0aGlzLmNoYXRPcGVuID0gZmFsc2U7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLm9wZW5DaGF0KCk7XG4gICAgICAgICAgICB0aGlzLmNoYXRPcGVuID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE9wZW5zIHRoZSBjaGF0IGRpYWxvZyB1c2luZyBNYXREaWFsb2cuXG4gICAgICogU2V0cyB0aGUgY29uZmlndXJhdGlvbiBvcHRpb25zIGZvciB0aGUgZGlhbG9nLCBpbmNsdWRpbmcgcG9zaXRpb24sIHNpemUsIGFuZCBkYXRhLlxuICAgICAqL1xuICAgIG9wZW5DaGF0KCkge1xuICAgICAgICB0aGlzLmNoYXRPcGVuID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5kaWFsb2dSZWYgPSB0aGlzLmRpYWxvZy5vcGVuKElyaXNDaGF0Ym90V2lkZ2V0Q29tcG9uZW50LCB7XG4gICAgICAgICAgICBoYXNCYWNrZHJvcDogZmFsc2UsXG4gICAgICAgICAgICBzY3JvbGxTdHJhdGVneTogdGhpcy5vdmVybGF5LnNjcm9sbFN0cmF0ZWdpZXMubm9vcCgpLFxuICAgICAgICAgICAgcG9zaXRpb246IHsgYm90dG9tOiAnMHB4JywgcmlnaHQ6ICcwcHgnIH0sXG4gICAgICAgICAgICBkaXNhYmxlQ2xvc2U6IHRydWUsXG4gICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgc3RhdGVTdG9yZTogdGhpcy5zdGF0ZVN0b3JlLFxuICAgICAgICAgICAgICAgIGNvdXJzZUlkOiB0aGlzLmNvdXJzZUlkLFxuICAgICAgICAgICAgICAgIGV4ZXJjaXNlSWQ6IHRoaXMuZXhlcmNpc2VJZCxcbiAgICAgICAgICAgICAgICBzZXNzaW9uU2VydmljZTogdGhpcy5zZXNzaW9uU2VydmljZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgSW5qZWN0YWJsZSwgT25EZXN0cm95IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBKaGlXZWJzb2NrZXRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvd2Vic29ja2V0L3dlYnNvY2tldC5zZXJ2aWNlJztcbmltcG9ydCB7IElyaXNTdGF0ZVN0b3JlIH0gZnJvbSAnYXBwL2lyaXMvc3RhdGUtc3RvcmUuc2VydmljZSc7XG5pbXBvcnQge1xuICAgIEFjdGl2ZUNvbnZlcnNhdGlvbk1lc3NhZ2VMb2FkZWRBY3Rpb24sXG4gICAgQ29udmVyc2F0aW9uRXJyb3JPY2N1cnJlZEFjdGlvbixcbiAgICBNZXNzYWdlU3RvcmVBY3Rpb24sXG4gICAgUmF0ZUxpbWl0VXBkYXRlZEFjdGlvbixcbiAgICBTdHVkZW50TWVzc2FnZVNlbnRBY3Rpb24sXG4gICAgaXNTZXNzaW9uUmVjZWl2ZWRBY3Rpb24sXG59IGZyb20gJ2FwcC9pcmlzL3N0YXRlLXN0b3JlLm1vZGVsJztcbmltcG9ydCB7IElyaXNNZXNzYWdlLCBpc1NlcnZlclNlbnRNZXNzYWdlLCBpc1N0dWRlbnRTZW50TWVzc2FnZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL2lyaXMtbWVzc2FnZS5tb2RlbCc7XG5pbXBvcnQgeyBJcmlzRXJyb3JNZXNzYWdlS2V5IH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvaXJpcy1lcnJvcnMubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgSXJpc1JhdGVMaW1pdEluZm9ybWF0aW9uIHtcbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHVibGljIGN1cnJlbnRNZXNzYWdlQ291bnQ6IG51bWJlcixcbiAgICAgICAgcHVibGljIHJhdGVMaW1pdDogbnVtYmVyLFxuICAgICAgICBwdWJsaWMgcmF0ZUxpbWl0VGltZWZyYW1lSG91cnM6IG51bWJlcixcbiAgICApIHt9XG59XG5cbi8qKlxuICogVGhlIElyaXNXZWJzb2NrZXRTZXJ2aWNlIGhhbmRsZXMgdGhlIHdlYnNvY2tldCBjb21tdW5pY2F0aW9uIGZvciByZWNlaXZpbmcgbWVzc2FnZXMgaW4gZGVkaWNhdGVkIGNoYW5uZWxzLlxuICovXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgSXJpc1dlYnNvY2tldFNlcnZpY2UgaW1wbGVtZW50cyBPbkRlc3Ryb3kge1xuICAgIHByaXZhdGUgc3Vic2NyaXB0aW9uQ2hhbm5lbD86IHN0cmluZztcbiAgICBwcml2YXRlIHNlc3Npb25JZENoYW5nZWRTdWI6IFN1YnNjcmlwdGlvbjtcblxuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYW4gaW5zdGFuY2Ugb2YgSXJpc1dlYnNvY2tldFNlcnZpY2UuXG4gICAgICogQHBhcmFtIGpoaVdlYnNvY2tldFNlcnZpY2UgVGhlIEpoaVdlYnNvY2tldFNlcnZpY2UgZm9yIHdlYnNvY2tldCBjb21tdW5pY2F0aW9uLlxuICAgICAqIEBwYXJhbSBzdGF0ZVN0b3JlIFRoZSBJcmlzU3RhdGVTdG9yZSBmb3IgbWFuYWdpbmcgdGhlIHN0YXRlIG9mIHRoZSBhcHBsaWNhdGlvbi5cbiAgICAgKiBAcGFyYW0gc2Vzc2lvblR5cGUgVGhlIHNlc3Npb24gdHlwZSBvZiB0aGUgd2Vic29ja2V0IHN1YnNjcmlwdGlvbiBjaGFubmVsXG4gICAgICovXG4gICAgcHJvdGVjdGVkIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcm90ZWN0ZWQgamhpV2Vic29ja2V0U2VydmljZTogSmhpV2Vic29ja2V0U2VydmljZSxcbiAgICAgICAgcHJvdGVjdGVkIHN0YXRlU3RvcmU6IElyaXNTdGF0ZVN0b3JlLFxuICAgICAgICBwcm90ZWN0ZWQgc2Vzc2lvblR5cGU6IHN0cmluZyxcbiAgICApIHtcbiAgICAgICAgLy8gU3Vic2NyaWJlIHRvIGNoYW5nZXMgaW4gdGhlIHNlc3Npb24gSURcbiAgICAgICAgdGhpcy5zZXNzaW9uSWRDaGFuZ2VkU3ViID0gdGhpcy5zdGF0ZVN0b3JlLmdldEFjdGlvbk9ic2VydmFibGUoKS5zdWJzY3JpYmUoKG5ld0FjdGlvbjogTWVzc2FnZVN0b3JlQWN0aW9uKSA9PiB7XG4gICAgICAgICAgICBpZiAoIWlzU2Vzc2lvblJlY2VpdmVkQWN0aW9uKG5ld0FjdGlvbikpIHJldHVybjtcbiAgICAgICAgICAgIHRoaXMuY2hhbmdlV2Vic29ja2V0U3Vic2NyaXB0aW9uKG5ld0FjdGlvbi5zZXNzaW9uSWQpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDbGVhbnMgdXAgcmVzb3VyY2VzIGJlZm9yZSB0aGUgc2VydmljZSBpcyBkZXN0cm95ZWQuXG4gICAgICovXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgICAgIC8vIFVuc3Vic2NyaWJlIGZyb20gdGhlIHdlYnNvY2tldCBjaGFubmVsXG4gICAgICAgIGlmICh0aGlzLnN1YnNjcmlwdGlvbkNoYW5uZWwpIHtcbiAgICAgICAgICAgIHRoaXMuamhpV2Vic29ja2V0U2VydmljZS51bnN1YnNjcmliZSh0aGlzLnN1YnNjcmlwdGlvbkNoYW5uZWwpO1xuICAgICAgICB9XG4gICAgICAgIC8vIFVuc3Vic2NyaWJlIGZyb20gb2JzZXJ2YWJsZXNcbiAgICAgICAgdGhpcy5zZXNzaW9uSWRDaGFuZ2VkU3ViLnVuc3Vic2NyaWJlKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hhbmdlcyB0aGUgd2Vic29ja2V0IHN1YnNjcmlwdGlvbiB0byB0aGUgc3BlY2lmaWVkIHNlc3Npb24gSUQuXG4gICAgICogQHBhcmFtIHNlc3Npb25JZCBUaGUgc2Vzc2lvbiBJRCB0byBzdWJzY3JpYmUgdG8uXG4gICAgICovXG4gICAgcHJpdmF0ZSBjaGFuZ2VXZWJzb2NrZXRTdWJzY3JpcHRpb24oc2Vzc2lvbklkOiBudW1iZXIgfCBudWxsKTogdm9pZCB7XG4gICAgICAgIGNvbnN0IGNoYW5uZWwgPSAnL3VzZXIvdG9waWMvaXJpcy8nICsgdGhpcy5zZXNzaW9uVHlwZSArICcvJyArIHNlc3Npb25JZDtcblxuICAgICAgICBpZiAoc2Vzc2lvbklkICE9IG51bGwgJiYgdGhpcy5zdWJzY3JpcHRpb25DaGFubmVsID09PSBjaGFubmVsKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGhpcy5zdWJzY3JpcHRpb25DaGFubmVsKSB7XG4gICAgICAgICAgICB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2UudW5zdWJzY3JpYmUodGhpcy5zdWJzY3JpcHRpb25DaGFubmVsKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChzZXNzaW9uSWQgPT0gbnVsbCkgcmV0dXJuO1xuXG4gICAgICAgIHRoaXMuc3Vic2NyaXB0aW9uQ2hhbm5lbCA9IGNoYW5uZWw7XG4gICAgICAgIHRoaXMuamhpV2Vic29ja2V0U2VydmljZS5zdWJzY3JpYmUodGhpcy5zdWJzY3JpcHRpb25DaGFubmVsKTtcbiAgICAgICAgdGhpcy5qaGlXZWJzb2NrZXRTZXJ2aWNlLnJlY2VpdmUodGhpcy5zdWJzY3JpcHRpb25DaGFubmVsKS5zdWJzY3JpYmUoKHJlc3BvbnNlOiBhbnkpID0+IHtcbiAgICAgICAgICAgIHRoaXMuaGFuZGxlV2Vic29ja2V0UmVzcG9uc2UocmVzcG9uc2UpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgYWJzdHJhY3QgaGFuZGxlV2Vic29ja2V0UmVzcG9uc2UocmVzcG9uc2U6IGFueSk6IHZvaWQ7XG5cbiAgICBwcm90ZWN0ZWQgaGFuZGxlTWVzc2FnZShtZXNzYWdlPzogSXJpc01lc3NhZ2UpIHtcbiAgICAgICAgaWYgKCFtZXNzYWdlKSByZXR1cm47XG4gICAgICAgIGlmIChpc1N0dWRlbnRTZW50TWVzc2FnZShtZXNzYWdlKSkge1xuICAgICAgICAgICAgdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKFxuICAgICAgICAgICAgICAgIG5ldyBTdHVkZW50TWVzc2FnZVNlbnRBY3Rpb24oXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gd2lsbCBiZSBjbGVhcmVkIGJ5IHRoZSBzdG9yZSBhdXRvbWF0aWNhbGx5XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlU3RvcmUuZGlzcGF0Y2gobmV3IENvbnZlcnNhdGlvbkVycm9yT2NjdXJyZWRBY3Rpb24oSXJpc0Vycm9yTWVzc2FnZUtleS5JUklTX1NFUlZFUl9SRVNQT05TRV9USU1FT1VUKSk7XG4gICAgICAgICAgICAgICAgICAgIH0sIDIwMDAwKSxcbiAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIGlmIChpc1NlcnZlclNlbnRNZXNzYWdlKG1lc3NhZ2UpKSB7XG4gICAgICAgICAgICB0aGlzLnN0YXRlU3RvcmUuZGlzcGF0Y2gobmV3IEFjdGl2ZUNvbnZlcnNhdGlvbk1lc3NhZ2VMb2FkZWRBY3Rpb24obWVzc2FnZSkpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIGhhbmRsZUVycm9yKGVycm9yVHJhbnNsYXRpb25LZXk/OiBJcmlzRXJyb3JNZXNzYWdlS2V5LCB0cmFuc2xhdGlvblBhcmFtcz86IE1hcDxzdHJpbmcsIGFueT4pIHtcbiAgICAgICAgaWYgKCFlcnJvclRyYW5zbGF0aW9uS2V5KSB7XG4gICAgICAgICAgICB0aGlzLnN0YXRlU3RvcmUuZGlzcGF0Y2gobmV3IENvbnZlcnNhdGlvbkVycm9yT2NjdXJyZWRBY3Rpb24oSXJpc0Vycm9yTWVzc2FnZUtleS5URUNITklDQUxfRVJST1JfUkVTUE9OU0UpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuc3RhdGVTdG9yZS5kaXNwYXRjaChuZXcgQ29udmVyc2F0aW9uRXJyb3JPY2N1cnJlZEFjdGlvbihlcnJvclRyYW5zbGF0aW9uS2V5LCB0cmFuc2xhdGlvblBhcmFtcykpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIGhhbmRsZVJhdGVMaW1pdEluZm8ocmF0ZUxpbWl0SW5mbzogSXJpc1JhdGVMaW1pdEluZm9ybWF0aW9uKSB7XG4gICAgICAgIHRoaXMuc3RhdGVTdG9yZS5kaXNwYXRjaChuZXcgUmF0ZUxpbWl0VXBkYXRlZEFjdGlvbihyYXRlTGltaXRJbmZvKSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSmhpV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3dlYnNvY2tldC93ZWJzb2NrZXQuc2VydmljZSc7XG5pbXBvcnQgeyBJcmlzU3RhdGVTdG9yZSB9IGZyb20gJ2FwcC9pcmlzL3N0YXRlLXN0b3JlLnNlcnZpY2UnO1xuaW1wb3J0IHsgSXJpc1JhdGVMaW1pdEluZm9ybWF0aW9uLCBJcmlzV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9pcmlzL3dlYnNvY2tldC5zZXJ2aWNlJztcbmltcG9ydCB7IElyaXNNZXNzYWdlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvaXJpcy1tZXNzYWdlLm1vZGVsJztcbmltcG9ydCB7IElyaXNFcnJvck1lc3NhZ2VLZXkgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9pcmlzLWVycm9ycy5tb2RlbCc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBFeGVyY2lzZUNvbXBvbmVudCB9IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL2lyaXMtY29udGVudC10eXBlLm1vZGVsJztcblxuLyoqXG4gKiBUaGUgSXJpc0NvZGVFZGl0b3JXZWJzb2NrZXRNZXNzYWdlVHlwZSBkZWZpbmVzIHRoZSB0eXBlIG9mIG1lc3NhZ2Ugc2VudCBvdmVyIHRoZSBjb2RlIGVkaXRvciB3ZWJzb2NrZXQuXG4gKi9cbmV4cG9ydCBlbnVtIElyaXNDb2RlRWRpdG9yV2Vic29ja2V0TWVzc2FnZVR5cGUge1xuICAgIE1FU1NBR0UgPSAnTUVTU0FHRScsXG4gICAgU1RFUF9TVUNDRVNTID0gJ1NURVBfU1VDQ0VTUycsXG4gICAgU1RFUF9FWENFUFRJT04gPSAnU1RFUF9FWENFUFRJT04nLFxuICAgIEVSUk9SID0gJ0VSUk9SJyxcbn1cblxuY2xhc3MgRmlsZUNoYW5nZSB7XG4gICAgdHlwZTogc3RyaW5nO1xuICAgIHBhdGg6IHN0cmluZztcbiAgICBjb250ZW50Pzogc3RyaW5nO1xuICAgIG9yaWdpbmFsPzogc3RyaW5nO1xuICAgIHVwZGF0ZWQ/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjbGFzcyBTdGVwRXhlY3V0aW9uU3VjY2VzcyB7XG4gICAgbWVzc2FnZUlkOiBudW1iZXI7XG4gICAgcGxhbklkOiBudW1iZXI7XG4gICAgc3RlcElkOiBudW1iZXI7XG4gICAgY29tcG9uZW50OiBFeGVyY2lzZUNvbXBvbmVudDtcbiAgICBmaWxlQ2hhbmdlcz86IEZpbGVDaGFuZ2VbXTtcbiAgICB1cGRhdGVkUHJvYmxlbVN0YXRlbWVudD86IHN0cmluZztcbn1cblxuZXhwb3J0IGNsYXNzIFN0ZXBFeGVjdXRpb25FeGNlcHRpb24ge1xuICAgIG1lc3NhZ2VJZDogbnVtYmVyO1xuICAgIHBsYW5JZDogbnVtYmVyO1xuICAgIHN0ZXBJZDogbnVtYmVyO1xuICAgIGVycm9yTWVzc2FnZT86IHN0cmluZztcbiAgICBlcnJvclRyYW5zbGF0aW9uS2V5PzogSXJpc0Vycm9yTWVzc2FnZUtleTtcbiAgICB0cmFuc2xhdGlvblBhcmFtcz86IE1hcDxzdHJpbmcsIGFueT47XG59XG5cbi8qKlxuICogVGhlIElyaXNDb2RlRWRpdG9yV2Vic29ja2V0RFRPIGlzIHRoZSBkYXRhIHRyYW5zZmVyIG9iamVjdCBmb3IgbWVzc2FnZXMgc2VudCBvdmVyIHRoZSBjb2RlIGVkaXRvciB3ZWJzb2NrZXQuXG4gKiBJdCBlaXRoZXIgY29udGFpbnMgYW4gSXJpc01lc3NhZ2Ugb3IgYSBtYXAgb2YgY2hhbmdlcyBvciBhbiBlcnJvciBtZXNzYWdlLlxuICovXG5leHBvcnQgY2xhc3MgSXJpc0NvZGVFZGl0b3JXZWJzb2NrZXREVE8ge1xuICAgIHR5cGU6IElyaXNDb2RlRWRpdG9yV2Vic29ja2V0TWVzc2FnZVR5cGU7XG4gICAgbWVzc2FnZT86IElyaXNNZXNzYWdlO1xuICAgIHN0ZXBFeGVjdXRpb25TdWNjZXNzPzogU3RlcEV4ZWN1dGlvblN1Y2Nlc3M7XG4gICAgZXhlY3V0aW9uRXhjZXB0aW9uPzogU3RlcEV4ZWN1dGlvbkV4Y2VwdGlvbjtcbiAgICBlcnJvclRyYW5zbGF0aW9uS2V5PzogSXJpc0Vycm9yTWVzc2FnZUtleTtcbiAgICB0cmFuc2xhdGlvblBhcmFtcz86IE1hcDxzdHJpbmcsIGFueT47XG4gICAgcmF0ZUxpbWl0SW5mbz86IElyaXNSYXRlTGltaXRJbmZvcm1hdGlvbjtcbn1cblxuLyoqXG4gKiBUaGUgSXJpc0NvZGVFZGl0b3JXZWJzb2NrZXRTZXJ2aWNlIGhhbmRsZXMgdGhlIHdlYnNvY2tldCBjb21tdW5pY2F0aW9uIGZvciByZWNlaXZpbmcgbWVzc2FnZXMgaW4gdGhlIGNvZGUgZWRpdG9yIGNoYW5uZWxzLlxuICovXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgSXJpc0NvZGVFZGl0b3JXZWJzb2NrZXRTZXJ2aWNlIGV4dGVuZHMgSXJpc1dlYnNvY2tldFNlcnZpY2Uge1xuICAgIHByaXZhdGUgc3RlcFN1Y2Nlc3M6IFN1YmplY3Q8U3RlcEV4ZWN1dGlvblN1Y2Nlc3M+ID0gbmV3IFN1YmplY3Q8U3RlcEV4ZWN1dGlvblN1Y2Nlc3M+KCk7XG4gICAgcHJpdmF0ZSBzdGVwRXhjZXB0aW9uOiBTdWJqZWN0PFN0ZXBFeGVjdXRpb25FeGNlcHRpb24+ID0gbmV3IFN1YmplY3Q8U3RlcEV4ZWN1dGlvbkV4Y2VwdGlvbj4oKTtcblxuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYW4gaW5zdGFuY2Ugb2YgSXJpc0NvZGVFZGl0b3JXZWJzb2NrZXRTZXJ2aWNlLlxuICAgICAqIEBwYXJhbSBqaGlXZWJzb2NrZXRTZXJ2aWNlIFRoZSBKaGlXZWJzb2NrZXRTZXJ2aWNlIGZvciB3ZWJzb2NrZXQgY29tbXVuaWNhdGlvbi5cbiAgICAgKiBAcGFyYW0gc3RhdGVTdG9yZSBUaGUgSXJpc1N0YXRlU3RvcmUgZm9yIG1hbmFnaW5nIHRoZSBzdGF0ZSBvZiB0aGUgYXBwbGljYXRpb24uXG4gICAgICovXG4gICAgY29uc3RydWN0b3IoamhpV2Vic29ja2V0U2VydmljZTogSmhpV2Vic29ja2V0U2VydmljZSwgc3RhdGVTdG9yZTogSXJpc1N0YXRlU3RvcmUpIHtcbiAgICAgICAgc3VwZXIoamhpV2Vic29ja2V0U2VydmljZSwgc3RhdGVTdG9yZSwgJ2NvZGUtZWRpdG9yLXNlc3Npb25zJyk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIGhhbmRsZVdlYnNvY2tldFJlc3BvbnNlKHJlc3BvbnNlOiBJcmlzQ29kZUVkaXRvcldlYnNvY2tldERUTyk6IHZvaWQge1xuICAgICAgICBpZiAocmVzcG9uc2UucmF0ZUxpbWl0SW5mbykge1xuICAgICAgICAgICAgc3VwZXIuaGFuZGxlUmF0ZUxpbWl0SW5mbyhyZXNwb25zZS5yYXRlTGltaXRJbmZvKTtcbiAgICAgICAgfVxuICAgICAgICBzd2l0Y2ggKHJlc3BvbnNlLnR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgSXJpc0NvZGVFZGl0b3JXZWJzb2NrZXRNZXNzYWdlVHlwZS5NRVNTQUdFOlxuICAgICAgICAgICAgICAgIHN1cGVyLmhhbmRsZU1lc3NhZ2UocmVzcG9uc2UubWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIElyaXNDb2RlRWRpdG9yV2Vic29ja2V0TWVzc2FnZVR5cGUuU1RFUF9TVUNDRVNTOlxuICAgICAgICAgICAgICAgIHRoaXMuaGFuZGxlU3RlcFN1Y2Nlc3MocmVzcG9uc2Uuc3RlcEV4ZWN1dGlvblN1Y2Nlc3MhKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgSXJpc0NvZGVFZGl0b3JXZWJzb2NrZXRNZXNzYWdlVHlwZS5TVEVQX0VYQ0VQVElPTjpcbiAgICAgICAgICAgICAgICB0aGlzLmhhbmRsZVN0ZXBFeGNlcHRpb24ocmVzcG9uc2UuZXhlY3V0aW9uRXhjZXB0aW9uISk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIElyaXNDb2RlRWRpdG9yV2Vic29ja2V0TWVzc2FnZVR5cGUuRVJST1I6XG4gICAgICAgICAgICAgICAgc3VwZXIuaGFuZGxlRXJyb3IocmVzcG9uc2UuZXJyb3JUcmFuc2xhdGlvbktleSwgcmVzcG9uc2UudHJhbnNsYXRpb25QYXJhbXMpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBoYW5kbGVTdGVwU3VjY2VzcyhyZXNwb25zZTogU3RlcEV4ZWN1dGlvblN1Y2Nlc3MpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5zdGVwU3VjY2Vzcy5uZXh0KHJlc3BvbnNlKTsgLy8gbm90aWZ5IHN1YnNjcmliZXJzIG9mIGNoYW5nZXMgYXBwbGllZFxuICAgIH1cblxuICAgIHByaXZhdGUgaGFuZGxlU3RlcEV4Y2VwdGlvbihyZXNwb25zZTogU3RlcEV4ZWN1dGlvbkV4Y2VwdGlvbik6IHZvaWQge1xuICAgICAgICB0aGlzLnN0ZXBFeGNlcHRpb24ubmV4dChyZXNwb25zZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhIHN1YmplY3QgdGhhdCBub3RpZmllcyBzdWJzY3JpYmVycyB3aGVuIHRoZSBjb2RlIGVkaXRvciBzaG91bGQgYmUgcmVsb2FkZWQuXG4gICAgICogQHJldHVybnMge1N1YmplY3Q8U3RlcEV4ZWN1dGlvblN1Y2Nlc3M+fVxuICAgICAqL1xuICAgIHB1YmxpYyBvblN0ZXBTdWNjZXNzKCk6IE9ic2VydmFibGU8U3RlcEV4ZWN1dGlvblN1Y2Nlc3M+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc3RlcFN1Y2Nlc3MuYXNPYnNlcnZhYmxlKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhIHN1YmplY3QgdGhhdCBub3RpZmllcyBzdWJzY3JpYmVycyB3aGVuIHRoZSBzdGVwIGV4ZWN1dGlvbiBmYWlsZWQuXG4gICAgICogQHJldHVybnMge1N1YmplY3Q8U3RlcEV4ZWN1dGlvbkV4Y2VwdGlvbj59XG4gICAgICovXG4gICAgcHVibGljIG9uU3RlcEV4Y2VwdGlvbigpOiBPYnNlcnZhYmxlPFN0ZXBFeGVjdXRpb25FeGNlcHRpb24+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc3RlcEV4Y2VwdGlvbi5hc09ic2VydmFibGUoKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE1hdERpYWxvZyB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2RpYWxvZyc7XG5pbXBvcnQgeyBPdmVybGF5IH0gZnJvbSAnQGFuZ3VsYXIvY2RrL292ZXJsYXknO1xuaW1wb3J0IHsgSXJpc1N0YXRlU3RvcmUgfSBmcm9tICdhcHAvaXJpcy9zdGF0ZS1zdG9yZS5zZXJ2aWNlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IFNoYXJlZFNlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9zaGFyZWQuc2VydmljZSc7XG5pbXBvcnQgeyBJcmlzQ2hhdGJvdEJ1dHRvbkNvbXBvbmVudCB9IGZyb20gJ2FwcC9pcmlzL2V4ZXJjaXNlLWNoYXRib3QvY2hhdGJvdC1idXR0b24uY29tcG9uZW50JztcbmltcG9ydCB7IElyaXNDb2RlRWRpdG9yU2Vzc2lvblNlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9jb2RlLWVkaXRvci1zZXNzaW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgSXJpc0NvZGVFZGl0b3JXZWJzb2NrZXRTZXJ2aWNlIH0gZnJvbSAnYXBwL2lyaXMvY29kZS1lZGl0b3Itd2Vic29ja2V0LnNlcnZpY2UnO1xuaW1wb3J0IHsgSXJpc0xvZ29TaXplIH0gZnJvbSAnLi4vaXJpcy1sb2dvL2lyaXMtbG9nby5jb21wb25lbnQnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1jb2RlLWVkaXRvci1jaGF0Ym90LWJ1dHRvbicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2NvZGUtZWRpdG9yLWNoYXRib3QtYnV0dG9uLmNvbXBvbmVudC5odG1sJyxcbiAgICBwcm92aWRlcnM6IFtJcmlzQ29kZUVkaXRvclNlc3Npb25TZXJ2aWNlXSxcbn0pXG5leHBvcnQgY2xhc3MgSXJpc0NvZGVFZGl0b3JDaGF0Ym90QnV0dG9uQ29tcG9uZW50IGV4dGVuZHMgSXJpc0NoYXRib3RCdXR0b25Db21wb25lbnQge1xuICAgIHByb3RlY3RlZCByZWFkb25seSBJcmlzTG9nb1NpemUgPSBJcmlzTG9nb1NpemU7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgZGlhbG9nOiBNYXREaWFsb2csXG4gICAgICAgIG92ZXJsYXk6IE92ZXJsYXksXG4gICAgICAgIGNvZGVFZGl0b3JTZXNzaW9uU2VydmljZTogSXJpc0NvZGVFZGl0b3JTZXNzaW9uU2VydmljZSxcbiAgICAgICAgc3RhdGVTdG9yZTogSXJpc1N0YXRlU3RvcmUsXG4gICAgICAgIC8vIE5vdGU6IFRoaXMgdW51c2VkIHNlcnZpY2UgaXMgaW5qZWN0ZWQgdG8gZW5zdXJlIHRoYXQgaXQgaXMgaW5zdGFudGlhdGVkXG4gICAgICAgIHdlYnNvY2tldFNlcnZpY2U6IElyaXNDb2RlRWRpdG9yV2Vic29ja2V0U2VydmljZSxcbiAgICAgICAgcm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgICAgICBzaGFyZWRTZXJ2aWNlOiBTaGFyZWRTZXJ2aWNlLFxuICAgICkge1xuICAgICAgICBzdXBlcihkaWFsb2csIG92ZXJsYXksIGNvZGVFZGl0b3JTZXNzaW9uU2VydmljZSwgc3RhdGVTdG9yZSwgcm91dGUsIHNoYXJlZFNlcnZpY2UpO1xuICAgIH1cbn1cbiIsIjxkaXY+XG4gICAgPGpoaS1pcmlzLWxvZ29cbiAgICAgICAgW3NpemVdPVwiSXJpc0xvZ29TaXplLlNNQUxMXCJcbiAgICAgICAgY2xhc3M9XCJidG5cIlxuICAgICAgICB0aXRsZT1cInt7ICdhcnRlbWlzQXBwLmV4ZXJjaXNlQ2hhdGJvdC5idXR0b25Ub29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIlxuICAgICAgICAoY2xpY2spPVwiaGFuZGxlQnV0dG9uQ2xpY2soKVwiXG4gICAgPjwvamhpLWlyaXMtbG9nbz5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSmhpV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3dlYnNvY2tldC93ZWJzb2NrZXQuc2VydmljZSc7XG5pbXBvcnQgeyBJcmlzU3RhdGVTdG9yZSB9IGZyb20gJ2FwcC9pcmlzL3N0YXRlLXN0b3JlLnNlcnZpY2UnO1xuaW1wb3J0IHsgSXJpc1JhdGVMaW1pdEluZm9ybWF0aW9uLCBJcmlzV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9pcmlzL3dlYnNvY2tldC5zZXJ2aWNlJztcbmltcG9ydCB7IElyaXNNZXNzYWdlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvaXJpcy1tZXNzYWdlLm1vZGVsJztcbmltcG9ydCB7IElyaXNFcnJvck1lc3NhZ2VLZXkgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9pcmlzLWVycm9ycy5tb2RlbCc7XG5cbi8qKlxuICogVGhlIElyaXNXZWJzb2NrZXRNZXNzYWdlVHlwZSBkZWZpbmVzIHRoZSB0eXBlIG9mIG1lc3NhZ2Ugc2VudCBvdmVyIHRoZSB3ZWJzb2NrZXQuXG4gKi9cbmV4cG9ydCBlbnVtIElyaXNDaGF0V2Vic29ja2V0TWVzc2FnZVR5cGUge1xuICAgIE1FU1NBR0UgPSAnTUVTU0FHRScsXG4gICAgRVJST1IgPSAnRVJST1InLFxufVxuXG4vKipcbiAqIFRoZSBJcmlzQ2hhdFdlYnNvY2tldERUTyBpcyB0aGUgZGF0YSB0cmFuc2ZlciBvYmplY3QgZm9yIG1lc3NhZ2VzIHNlbnQgb3ZlciB0aGUgaXJpcyBjaGF0IHdlYnNvY2tldC5cbiAqIEl0IGVpdGhlciBjb250YWlucyBhbiBJcmlzTWVzc2FnZSBvciBhbiBlcnJvciBtZXNzYWdlLlxuICovXG5leHBvcnQgY2xhc3MgSXJpc0NoYXRXZWJzb2NrZXREVE8ge1xuICAgIHR5cGU6IElyaXNDaGF0V2Vic29ja2V0TWVzc2FnZVR5cGU7XG4gICAgbWVzc2FnZT86IElyaXNNZXNzYWdlO1xuICAgIGVycm9yVHJhbnNsYXRpb25LZXk/OiBJcmlzRXJyb3JNZXNzYWdlS2V5O1xuICAgIHRyYW5zbGF0aW9uUGFyYW1zPzogTWFwPHN0cmluZywgYW55PjtcbiAgICByYXRlTGltaXRJbmZvPzogSXJpc1JhdGVMaW1pdEluZm9ybWF0aW9uO1xufVxuXG4vKipcbiAqIFRoZSBJcmlzQ2hhdFdlYnNvY2tldFNlcnZpY2UgaGFuZGxlcyB0aGUgd2Vic29ja2V0IGNvbW11bmljYXRpb24gZm9yIHJlY2VpdmluZyBtZXNzYWdlcyBpbiBleGVyY2lzZSBjaGF0IGNoYW5uZWxzLlxuICovXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgSXJpc0NoYXRXZWJzb2NrZXRTZXJ2aWNlIGV4dGVuZHMgSXJpc1dlYnNvY2tldFNlcnZpY2Uge1xuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYW4gaW5zdGFuY2Ugb2YgSXJpc0NoYXRXZWJzb2NrZXRTZXJ2aWNlLlxuICAgICAqIEBwYXJhbSBqaGlXZWJzb2NrZXRTZXJ2aWNlIFRoZSBKaGlXZWJzb2NrZXRTZXJ2aWNlIGZvciB3ZWJzb2NrZXQgY29tbXVuaWNhdGlvbi5cbiAgICAgKiBAcGFyYW0gc3RhdGVTdG9yZSBUaGUgSXJpc1N0YXRlU3RvcmUgZm9yIG1hbmFnaW5nIHRoZSBzdGF0ZSBvZiB0aGUgYXBwbGljYXRpb24uXG4gICAgICovXG4gICAgY29uc3RydWN0b3IoamhpV2Vic29ja2V0U2VydmljZTogSmhpV2Vic29ja2V0U2VydmljZSwgc3RhdGVTdG9yZTogSXJpc1N0YXRlU3RvcmUpIHtcbiAgICAgICAgc3VwZXIoamhpV2Vic29ja2V0U2VydmljZSwgc3RhdGVTdG9yZSwgJ3Nlc3Npb25zJyk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIGhhbmRsZVdlYnNvY2tldFJlc3BvbnNlKHJlc3BvbnNlOiBJcmlzQ2hhdFdlYnNvY2tldERUTykge1xuICAgICAgICBpZiAocmVzcG9uc2UucmF0ZUxpbWl0SW5mbykge1xuICAgICAgICAgICAgc3VwZXIuaGFuZGxlUmF0ZUxpbWl0SW5mbyhyZXNwb25zZS5yYXRlTGltaXRJbmZvKTtcbiAgICAgICAgfVxuICAgICAgICBzd2l0Y2ggKHJlc3BvbnNlLnR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgSXJpc0NoYXRXZWJzb2NrZXRNZXNzYWdlVHlwZS5NRVNTQUdFOlxuICAgICAgICAgICAgICAgIHN1cGVyLmhhbmRsZU1lc3NhZ2UocmVzcG9uc2UubWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIElyaXNDaGF0V2Vic29ja2V0TWVzc2FnZVR5cGUuRVJST1I6XG4gICAgICAgICAgICAgICAgc3VwZXIuaGFuZGxlRXJyb3IocmVzcG9uc2UuZXJyb3JUcmFuc2xhdGlvbktleSwgcmVzcG9uc2UudHJhbnNsYXRpb25QYXJhbXMpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgT25EZXN0cm95IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJcmlzU3RhdGVTdG9yZSB9IGZyb20gJ2FwcC9pcmlzL3N0YXRlLXN0b3JlLnNlcnZpY2UnO1xuaW1wb3J0IHsgSGVhcnRiZWF0RFRPLCBJcmlzSHR0cENoYXRTZXNzaW9uU2VydmljZSB9IGZyb20gJ2FwcC9pcmlzL2h0dHAtY2hhdC1zZXNzaW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgQ29udmVyc2F0aW9uRXJyb3JPY2N1cnJlZEFjdGlvbiwgTWVzc2FnZVN0b3JlQWN0aW9uLCBSYXRlTGltaXRVcGRhdGVkQWN0aW9uLCBpc1Nlc3Npb25SZWNlaXZlZEFjdGlvbiB9IGZyb20gJ2FwcC9pcmlzL3N0YXRlLXN0b3JlLm1vZGVsJztcbmltcG9ydCB7IElyaXNFcnJvck1lc3NhZ2VLZXkgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9pcmlzLWVycm9ycy5tb2RlbCc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24sIGZpcnN0VmFsdWVGcm9tIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBKaGlXZWJzb2NrZXRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvd2Vic29ja2V0L3dlYnNvY2tldC5zZXJ2aWNlJztcblxuLyoqXG4gKiBUaGUgYElyaXNIZWFydGJlYXRTZXJ2aWNlYCBpcyByZXNwb25zaWJsZSBmb3IgbW9uaXRvcmluZyB0aGUgaGVhcnRiZWF0IG9mIGFuIElyaXMgc2Vzc2lvbi5cbiAqIEl0IHBlcmlvZGljYWxseSBzZW5kcyBIVFRQIHJlcXVlc3RzIHRvIGNoZWNrIGlmIHRoZSBzZXNzaW9uIGlzIHN0aWxsIGF2YWlsYWJsZS5cbiAqIElmIHRoZSBoZWFydGJlYXQgaXMgbm90IGF2YWlsYWJsZSwgaXQgZGlzcGF0Y2hlcyBhbiBlcnJvciBhY3Rpb24gdG8gdGhlIGBJcmlzU3RhdGVTdG9yZWAuXG4gKi9cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBJcmlzSGVhcnRiZWF0U2VydmljZSBpbXBsZW1lbnRzIE9uRGVzdHJveSB7XG4gICAgaW50ZXJ2YWxJZDogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgdW5kZWZpbmVkO1xuICAgIHByaXZhdGUgc2Vzc2lvbklkQ2hhbmdlZFN1YjogU3Vic2NyaXB0aW9uO1xuICAgIHdlYnNvY2tldFN0YXR1c1N1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xuICAgIGRpc2Nvbm5lY3RlZCA9IGZhbHNlO1xuXG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhbiBpbnN0YW5jZSBvZiBJcmlzSGVhcnRiZWF0U2VydmljZS5cbiAgICAgKiBAcGFyYW0gd2Vic29ja2V0U2VydmljZSBUaGUgSmhpV2Vic29ja2V0U2VydmljZSBmb3IgbWFuYWdpbmcgdGhlIHdlYnNvY2tldCBjb25uZWN0aW9uLlxuICAgICAqIEBwYXJhbSBzdGF0ZVN0b3JlIFRoZSBJcmlzU3RhdGVTdG9yZSBmb3IgbWFuYWdpbmcgdGhlIHN0YXRlIG9mIHRoZSBhcHBsaWNhdGlvbi5cbiAgICAgKiBAcGFyYW0gaHR0cFNlc3Npb25TZXJ2aWNlIFRoZSBJcmlzSHR0cENoYXRTZXNzaW9uU2VydmljZSBmb3IgSFRUUCBvcGVyYXRpb25zIHJlbGF0ZWQgdG8gc2Vzc2lvbnMuXG4gICAgICovXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgd2Vic29ja2V0U2VydmljZTogSmhpV2Vic29ja2V0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBzdGF0ZVN0b3JlOiBJcmlzU3RhdGVTdG9yZSxcbiAgICAgICAgcHJpdmF0ZSBodHRwU2Vzc2lvblNlcnZpY2U6IElyaXNIdHRwQ2hhdFNlc3Npb25TZXJ2aWNlLFxuICAgICkge1xuICAgICAgICAvLyBTdWJzY3JpYmUgdG8gY2hhbmdlcyBpbiB0aGUgc2Vzc2lvbiBJRFxuICAgICAgICB0aGlzLnNlc3Npb25JZENoYW5nZWRTdWIgPSB0aGlzLnN0YXRlU3RvcmUuZ2V0QWN0aW9uT2JzZXJ2YWJsZSgpLnN1YnNjcmliZSgobmV3QWN0aW9uOiBNZXNzYWdlU3RvcmVBY3Rpb24pID0+IHtcbiAgICAgICAgICAgIGlmICghaXNTZXNzaW9uUmVjZWl2ZWRBY3Rpb24obmV3QWN0aW9uKSkgcmV0dXJuO1xuICAgICAgICAgICAgaWYgKHRoaXMuaW50ZXJ2YWxJZCAhPT0gdW5kZWZpbmVkKSBjbGVhckludGVydmFsKHRoaXMuaW50ZXJ2YWxJZCk7XG4gICAgICAgICAgICB0aGlzLmNoZWNrSGVhcnRiZWF0KG5ld0FjdGlvbi5zZXNzaW9uSWQpO1xuICAgICAgICAgICAgdGhpcy5pbnRlcnZhbElkID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tIZWFydGJlYXQobmV3QWN0aW9uLnNlc3Npb25JZCk7XG4gICAgICAgICAgICB9LCAxMDAwMCk7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLndlYnNvY2tldFN0YXR1c1N1YnNjcmlwdGlvbiA9IHRoaXMud2Vic29ja2V0U2VydmljZS5jb25uZWN0aW9uU3RhdGUuc3Vic2NyaWJlKChzdGF0dXMpID0+IHtcbiAgICAgICAgICAgIHRoaXMuZGlzY29ubmVjdGVkID0gIXN0YXR1cy5jb25uZWN0ZWQgJiYgIXN0YXR1cy5pbnRlbmRlZERpc2Nvbm5lY3QgJiYgc3RhdHVzLndhc0V2ZXJDb25uZWN0ZWRCZWZvcmU7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENoZWNrcyB0aGUgaGVhcnRiZWF0IG9mIHRoZSBJcmlzIHNlc3Npb24gYnkgc2VuZGluZyBhbiBIVFRQIHJlcXVlc3QuXG4gICAgICogSWYgdGhlIGhlYXJ0YmVhdCBpcyBub3QgYXZhaWxhYmxlLCBpdCBkaXNwYXRjaGVzIGFuIGVycm9yIGFjdGlvbiB0byB0aGUgYElyaXNTdGF0ZVN0b3JlYC5cbiAgICAgKiBAcGFyYW0gc2Vzc2lvbklkIFRoZSBJRCBvZiB0aGUgSXJpcyBzZXNzaW9uIHRvIGNoZWNrLlxuICAgICAqL1xuICAgIHByaXZhdGUgY2hlY2tIZWFydGJlYXQoc2Vzc2lvbklkOiBudW1iZXIpOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMuZGlzY29ubmVjdGVkKSByZXR1cm47XG4gICAgICAgIGZpcnN0VmFsdWVGcm9tKHRoaXMuaHR0cFNlc3Npb25TZXJ2aWNlLmdldEhlYXJ0YmVhdChzZXNzaW9uSWQpKS50aGVuKChyZXNwb25zZTogSHR0cFJlc3BvbnNlPEhlYXJ0YmVhdERUTz4pID0+IHtcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5ib2R5KSB7XG4gICAgICAgICAgICAgICAgaWYgKCFyZXNwb25zZS5ib2R5LmFjdGl2ZSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlU3RvcmUuZGlzcGF0Y2gobmV3IENvbnZlcnNhdGlvbkVycm9yT2NjdXJyZWRBY3Rpb24oSXJpc0Vycm9yTWVzc2FnZUtleS5JUklTX05PVF9BVkFJTEFCTEUpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKG5ldyBSYXRlTGltaXRVcGRhdGVkQWN0aW9uKHJlc3BvbnNlLmJvZHkhLnJhdGVMaW1pdEluZm8pKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zdGF0ZVN0b3JlLmRpc3BhdGNoKG5ldyBDb252ZXJzYXRpb25FcnJvck9jY3VycmVkQWN0aW9uKElyaXNFcnJvck1lc3NhZ2VLZXkuSVJJU19OT1RfQVZBSUxBQkxFKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFBlcmZvcm1zIGNsZWFudXAgd2hlbiB0aGUgc2VydmljZSBpcyBkZXN0cm95ZWQuXG4gICAgICogQ2xlYXJzIHRoZSBpbnRlcnZhbCBhbmQgdW5zdWJzY3JpYmVzIGZyb20gb2JzZXJ2YWJsZXMuXG4gICAgICovXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgICAgIGlmICh0aGlzLmludGVydmFsSWQgIT09IHVuZGVmaW5lZCkgY2xlYXJJbnRlcnZhbCh0aGlzLmludGVydmFsSWQpO1xuICAgICAgICAvLyBVbnN1YnNjcmliZSBmcm9tIG9ic2VydmFibGVzXG4gICAgICAgIHRoaXMuc2Vzc2lvbklkQ2hhbmdlZFN1Yi51bnN1YnNjcmliZSgpO1xuICAgICAgICB0aGlzLndlYnNvY2tldFN0YXR1c1N1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTWF0RGlhbG9nIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvZGlhbG9nJztcbmltcG9ydCB7IE92ZXJsYXkgfSBmcm9tICdAYW5ndWxhci9jZGsvb3ZlcmxheSc7XG5pbXBvcnQgeyBJcmlzQ2hhdFdlYnNvY2tldFNlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9jaGF0LXdlYnNvY2tldC5zZXJ2aWNlJztcbmltcG9ydCB7IElyaXNTdGF0ZVN0b3JlIH0gZnJvbSAnYXBwL2lyaXMvc3RhdGUtc3RvcmUuc2VydmljZSc7XG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBTaGFyZWRTZXJ2aWNlIH0gZnJvbSAnYXBwL2lyaXMvc2hhcmVkLnNlcnZpY2UnO1xuaW1wb3J0IHsgSXJpc0hlYXJ0YmVhdFNlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9oZWFydGJlYXQuc2VydmljZSc7XG5pbXBvcnQgeyBJcmlzQ2hhdFNlc3Npb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2lyaXMvY2hhdC1zZXNzaW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgSXJpc0NoYXRib3RCdXR0b25Db21wb25lbnQgfSBmcm9tICdhcHAvaXJpcy9leGVyY2lzZS1jaGF0Ym90L2NoYXRib3QtYnV0dG9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBJcmlzTG9nb0xvb2tEaXJlY3Rpb24sIElyaXNMb2dvU2l6ZSB9IGZyb20gJ2FwcC9pcmlzL2lyaXMtbG9nby9pcmlzLWxvZ28uY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktdHV0b3ItY2hhdGJvdC1idXR0b24nLFxuICAgIHRlbXBsYXRlVXJsOiAnLi90dXRvci1jaGF0Ym90LWJ1dHRvbi5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vdHV0b3ItY2hhdGJvdC1idXR0b24uY29tcG9uZW50LnNjc3MnXSxcbiAgICBwcm92aWRlcnM6IFtJcmlzQ2hhdFdlYnNvY2tldFNlcnZpY2UsIElyaXNDaGF0U2Vzc2lvblNlcnZpY2UsIElyaXNIZWFydGJlYXRTZXJ2aWNlXSxcbn0pXG5leHBvcnQgY2xhc3MgSXJpc1R1dG9yQ2hhdGJvdEJ1dHRvbkNvbXBvbmVudCBleHRlbmRzIElyaXNDaGF0Ym90QnV0dG9uQ29tcG9uZW50IHtcbiAgICBwcm90ZWN0ZWQgcmVhZG9ubHkgSXJpc0xvZ29TaXplID0gSXJpc0xvZ29TaXplO1xuICAgIHByb3RlY3RlZCByZWFkb25seSBJcmlzTG9nb0xvb2tEaXJlY3Rpb24gPSBJcmlzTG9nb0xvb2tEaXJlY3Rpb247XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgZGlhbG9nOiBNYXREaWFsb2csXG4gICAgICAgIG92ZXJsYXk6IE92ZXJsYXksXG4gICAgICAgIHNlc3Npb25TZXJ2aWNlOiBJcmlzQ2hhdFNlc3Npb25TZXJ2aWNlLFxuICAgICAgICBzdGF0ZVN0b3JlOiBJcmlzU3RhdGVTdG9yZSxcbiAgICAgICAgLy8gTm90ZTogVGhlc2UgMiB1bnVzZWQgc2VydmljZXMgYXJlIGluamVjdGVkIHRvIGVuc3VyZSB0aGF0IHRoZXkgYXJlIGluc3RhbnRpYXRlZFxuICAgICAgICB3ZWJzb2NrZXRTZXJ2aWNlOiBJcmlzQ2hhdFdlYnNvY2tldFNlcnZpY2UsXG4gICAgICAgIGhlYXJ0YmVhdFNlcnZpY2U6IElyaXNIZWFydGJlYXRTZXJ2aWNlLFxuICAgICAgICByb3V0ZTogQWN0aXZhdGVkUm91dGUsXG4gICAgICAgIHNoYXJlZFNlcnZpY2U6IFNoYXJlZFNlcnZpY2UsXG4gICAgKSB7XG4gICAgICAgIHN1cGVyKGRpYWxvZywgb3ZlcmxheSwgc2Vzc2lvblNlcnZpY2UsIHN0YXRlU3RvcmUsIHJvdXRlLCBzaGFyZWRTZXJ2aWNlKTtcbiAgICB9XG59XG4iLCJAaWYgKCFjaGF0T3Blbikge1xuICAgIDxkaXYgY2xhc3M9XCJjaGF0Ym90LWJ1dHRvblwiPlxuICAgICAgICA8amhpLWlyaXMtbG9nbyBbc2l6ZV09XCJJcmlzTG9nb1NpemUuTUVESVVNXCIgW2xvb2tdPVwiSXJpc0xvZ29Mb29rRGlyZWN0aW9uLkxFRlRcIiAoY2xpY2spPVwiaGFuZGxlQnV0dG9uQ2xpY2soKVwiIC8+XG4gICAgICAgIEBpZiAoaGFzTmV3TWVzc2FnZXMpIHtcbiAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQ2lyY2xlXCIgc2l6ZT1cInhsXCIgY2xhc3M9XCJ1bnJlYWQtaW5kaWNhdG9yXCI+PC9mYS1pY29uPlxuICAgICAgICB9XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTWF0RGlhbG9nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvZGlhbG9nJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IEZvbnRBd2Vzb21lTW9kdWxlIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzTWFya2Rvd25Nb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLm1vZHVsZSc7XG5pbXBvcnQgeyBBYm91dElyaXNDb21wb25lbnQgfSBmcm9tICdhcHAvaXJpcy9hYm91dC1pcmlzL2Fib3V0LWlyaXMuY29tcG9uZW50JztcbmltcG9ydCB7IFJvdXRlck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL3NoYXJlZC1jb21wb25lbnQubW9kdWxlJztcbmltcG9ydCB7IElyaXNTZXR0aW5nc1VwZGF0ZUNvbXBvbmVudCB9IGZyb20gJy4vc2V0dGluZ3MvaXJpcy1zZXR0aW5ncy11cGRhdGUvaXJpcy1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50JztcbmltcG9ydCB7IElyaXNHbG9iYWxTZXR0aW5nc1VwZGF0ZUNvbXBvbmVudCB9IGZyb20gJy4vc2V0dGluZ3MvaXJpcy1nbG9iYWwtc2V0dGluZ3MtdXBkYXRlL2lyaXMtZ2xvYmFsLXNldHRpbmdzLXVwZGF0ZS5jb21wb25lbnQnO1xuaW1wb3J0IHsgSXJpc0NvbW1vblN1YlNldHRpbmdzVXBkYXRlQ29tcG9uZW50IH0gZnJvbSAnLi9zZXR0aW5ncy9pcmlzLXNldHRpbmdzLXVwZGF0ZS9pcmlzLWNvbW1vbi1zdWItc2V0dGluZ3MtdXBkYXRlL2lyaXMtY29tbW9uLXN1Yi1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50JztcbmltcG9ydCB7IElyaXNDb3Vyc2VTZXR0aW5nc1VwZGF0ZUNvbXBvbmVudCB9IGZyb20gJ2FwcC9pcmlzL3NldHRpbmdzL2lyaXMtY291cnNlLXNldHRpbmdzLXVwZGF0ZS9pcmlzLWNvdXJzZS1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50JztcbmltcG9ydCB7IElyaXNFeGVyY2lzZVNldHRpbmdzVXBkYXRlQ29tcG9uZW50IH0gZnJvbSAnYXBwL2lyaXMvc2V0dGluZ3MvaXJpcy1leGVyY2lzZS1zZXR0aW5ncy11cGRhdGUvaXJpcy1leGVyY2lzZS1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50JztcbmltcG9ydCB7IElyaXNMb2dvQ29tcG9uZW50IH0gZnJvbSAnLi9pcmlzLWxvZ28vaXJpcy1sb2dvLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBJcmlzQ2hhdFN1YlNldHRpbmdzVXBkYXRlQ29tcG9uZW50IH0gZnJvbSAnYXBwL2lyaXMvc2V0dGluZ3MvaXJpcy1zZXR0aW5ncy11cGRhdGUvaXJpcy1jaGF0LXN1Yi1zZXR0aW5ncy11cGRhdGUvaXJpcy1jaGF0LXN1Yi1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50JztcbmltcG9ydCB7IElyaXNIZXN0aWFTdWJTZXR0aW5nc1VwZGF0ZUNvbXBvbmVudCB9IGZyb20gJ2FwcC9pcmlzL3NldHRpbmdzL2lyaXMtc2V0dGluZ3MtdXBkYXRlL2lyaXMtaGVzdGlhLXN1Yi1zZXR0aW5ncy11cGRhdGUvaXJpcy1oZXN0aWEtc3ViLXNldHRpbmdzLXVwZGF0ZS5jb21wb25lbnQnO1xuaW1wb3J0IHsgSXJpc0dsb2JhbEF1dG91cGRhdGVTZXR0aW5nc1VwZGF0ZUNvbXBvbmVudCB9IGZyb20gJy4vc2V0dGluZ3MvaXJpcy1zZXR0aW5ncy11cGRhdGUvaXJpcy1nbG9iYWwtYXV0b3VwZGF0ZS1zZXR0aW5ncy11cGRhdGUvaXJpcy1nbG9iYWwtYXV0b3VwZGF0ZS1zZXR0aW5ncy11cGRhdGUuY29tcG9uZW50JztcbmltcG9ydCB7IElyaXNDb2RlRWRpdG9yU3ViU2V0dGluZ3NVcGRhdGVDb21wb25lbnQgfSBmcm9tICdhcHAvaXJpcy9zZXR0aW5ncy9pcmlzLXNldHRpbmdzLXVwZGF0ZS9pcmlzLWNvZGUtZWRpdG9yLXN1Yi1zZXR0aW5ncy11cGRhdGUvaXJpcy1jb2RlLWVkaXRvci1zdWItc2V0dGluZ3MtdXBkYXRlLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBJcmlzQ29kZUVkaXRvckNoYXRib3RCdXR0b25Db21wb25lbnQgfSBmcm9tICdhcHAvaXJpcy9leGVyY2lzZS1jaGF0Ym90L2NvZGUtZWRpdG9yLWNoYXRib3QtYnV0dG9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBJcmlzVHV0b3JDaGF0Ym90QnV0dG9uQ29tcG9uZW50IH0gZnJvbSAnYXBwL2lyaXMvZXhlcmNpc2UtY2hhdGJvdC90dXRvci1jaGF0Ym90LWJ1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgSXJpc0NvZGVFZGl0b3JXZWJzb2NrZXRTZXJ2aWNlIH0gZnJvbSAnYXBwL2lyaXMvY29kZS1lZGl0b3Itd2Vic29ja2V0LnNlcnZpY2UnO1xuaW1wb3J0IHsgSXJpc1N0YXRlU3RvcmUgfSBmcm9tICdhcHAvaXJpcy9zdGF0ZS1zdG9yZS5zZXJ2aWNlJztcbmltcG9ydCB7IElyaXNDaGF0Ym90V2lkZ2V0Q29tcG9uZW50IH0gZnJvbSAnYXBwL2lyaXMvZXhlcmNpc2UtY2hhdGJvdC93aWRnZXQvY2hhdGJvdC13aWRnZXQuY29tcG9uZW50JztcbmltcG9ydCB7IElyaXNFbmFibGVkQ29tcG9uZW50IH0gZnJvbSAnYXBwL2lyaXMvc2V0dGluZ3Mvc2hhcmVkL2lyaXMtZW5hYmxlZC5jb21wb25lbnQnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGRlY2xhcmF0aW9uczogW1xuICAgICAgICBJcmlzQ2hhdGJvdFdpZGdldENvbXBvbmVudCxcbiAgICAgICAgSXJpc0NvZGVFZGl0b3JDaGF0Ym90QnV0dG9uQ29tcG9uZW50LFxuICAgICAgICBJcmlzVHV0b3JDaGF0Ym90QnV0dG9uQ29tcG9uZW50LFxuICAgICAgICBBYm91dElyaXNDb21wb25lbnQsXG4gICAgICAgIElyaXNTZXR0aW5nc1VwZGF0ZUNvbXBvbmVudCxcbiAgICAgICAgSXJpc0dsb2JhbFNldHRpbmdzVXBkYXRlQ29tcG9uZW50LFxuICAgICAgICBJcmlzQ291cnNlU2V0dGluZ3NVcGRhdGVDb21wb25lbnQsXG4gICAgICAgIElyaXNFeGVyY2lzZVNldHRpbmdzVXBkYXRlQ29tcG9uZW50LFxuICAgICAgICBJcmlzQ29tbW9uU3ViU2V0dGluZ3NVcGRhdGVDb21wb25lbnQsXG4gICAgICAgIElyaXNMb2dvQ29tcG9uZW50LFxuICAgICAgICBJcmlzQ2hhdFN1YlNldHRpbmdzVXBkYXRlQ29tcG9uZW50LFxuICAgICAgICBJcmlzSGVzdGlhU3ViU2V0dGluZ3NVcGRhdGVDb21wb25lbnQsXG4gICAgICAgIElyaXNHbG9iYWxBdXRvdXBkYXRlU2V0dGluZ3NVcGRhdGVDb21wb25lbnQsXG4gICAgICAgIElyaXNDb2RlRWRpdG9yU3ViU2V0dGluZ3NVcGRhdGVDb21wb25lbnQsXG4gICAgICAgIElyaXNFbmFibGVkQ29tcG9uZW50LFxuICAgIF0sXG4gICAgaW1wb3J0czogW0NvbW1vbk1vZHVsZSwgTWF0RGlhbG9nTW9kdWxlLCBGb3Jtc01vZHVsZSwgRm9udEF3ZXNvbWVNb2R1bGUsIEFydGVtaXNTaGFyZWRNb2R1bGUsIEFydGVtaXNNYXJrZG93bk1vZHVsZSwgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSwgUm91dGVyTW9kdWxlXSxcbiAgICBwcm92aWRlcnM6IFtJcmlzQ29kZUVkaXRvcldlYnNvY2tldFNlcnZpY2UsIElyaXNTdGF0ZVN0b3JlXSxcbiAgICBleHBvcnRzOiBbSXJpc0NvZGVFZGl0b3JDaGF0Ym90QnV0dG9uQ29tcG9uZW50LCBJcmlzVHV0b3JDaGF0Ym90QnV0dG9uQ29tcG9uZW50LCBJcmlzRW5hYmxlZENvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIElyaXNNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUdBLElBQVk7QUFBWjs7QUFBQSxLQUFBLFNBQVlBLG1CQUFnQjtBQUN4QixNQUFBQSxrQkFBQSxRQUFBLElBQUE7QUFDQSxNQUFBQSxrQkFBQSxRQUFBLElBQUE7QUFDQSxNQUFBQSxrQkFBQSxVQUFBLElBQUE7SUFDSixHQUpZLHFCQUFBLG1CQUFnQixDQUFBLEVBQUE7Ozs7O0FDSDVCLFNBQVMsV0FBVyxjQUFjLE9BQTBCLGNBQTZCO0FBS3pGLFNBQVMsZUFBZTs7Ozs7OztBQ1NwQixJQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxTQUFBLEVBQUE7QUFLSSxJQUFBLHdCQUFBLGlCQUFBLFNBQUEsNEZBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQUEsT0FBQSx1QkFBQSxNQUFBO0lBQUEsQ0FBQSxFQUFrQyxVQUFBLFNBQUEsdUZBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUN4Qix5QkFBQSxPQUFBLDZCQUFBLENBQThCO0lBQUEsQ0FBQTtBQU41QyxJQUFBLDBCQUFBO0FBUUEsSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQXlKLElBQUEsb0JBQUEsR0FBQSxXQUFBO0FBQVEsSUFBQSwwQkFBQTtBQUNySyxJQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsSUFBQTs7OztBQU5ZLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsWUFBQSxDQUFBLE9BQUEsT0FBQSxFQUFxQixXQUFBLE9BQUEsb0JBQUE7Ozs7OztBQVN6QixJQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsU0FBQSxFQUFBO0FBTUksSUFBQSx3QkFBQSxpQkFBQSxTQUFBLHNGQUFBO0FBQUEsWUFBQSxjQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFdBQUEsWUFBQTtBQUFBLFlBQUEsVUFBQSwyQkFBQTtBQUFBLGFBQWlCLHlCQUFBLFFBQUEsbUNBQUEsUUFBQSxDQUF5QztJQUFBLENBQUE7QUFOOUQsSUFBQSwwQkFBQTtBQVFBLElBQUEsb0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxTQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLENBQUE7QUFDSixJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFFBQUE7Ozs7O0FBVFksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxtQ0FBQSxNQUFBLFNBQUEsRUFBQTtBQUNBLElBQUEsd0JBQUEsWUFBQSxDQUFBLE9BQUEsV0FBQSxPQUFBLG9CQUFBLEVBQTZDLFdBQUEsT0FBQSxrQkFBQSxTQUFBLFFBQUEsQ0FBQTtBQUlqQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLG1DQUFBLE9BQUEsU0FBQSxFQUFBO0FBQzVCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsc0JBQUEsU0FBQSxNQUFBLGdCQUFBOzs7Ozs7QUFhQSxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQVEsSUFBQSx3QkFBQSxTQUFBLFNBQUEsdUZBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsMkJBQUE7QUFBQSxhQUFTLHlCQUFBLFFBQUEsU0FBUyxNQUFTLENBQUM7SUFBQSxDQUFBO0FBQ2hDLElBQUEsb0JBQUEsQ0FBQTs7QUFDSixJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLGdCQUFBOzs7O0FBSDBDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxPQUFBLGVBQUEsT0FBQSxPQUFBLE9BQUEsWUFBQSxvQkFBQSxNQUFBO0FBQ2xDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEseUJBQUEsR0FBQSxHQUFBLG9FQUFBLEdBQUEsb0JBQUE7Ozs7OztBQUlKLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBUSxJQUFBLHdCQUFBLFNBQUEsU0FBQSwrRUFBQTtBQUFBLFlBQUEsY0FBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxZQUFBLFlBQUE7QUFBQSxZQUFBLFVBQUEsMkJBQUE7QUFBQSxhQUFTLHlCQUFBLFFBQUEsU0FBQSxTQUFBLENBQWU7SUFBQSxDQUFBO0FBQzVCLElBQUEsb0JBQUEsQ0FBQTtBQUNKLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7Ozs7O0FBSHNDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxVQUFBLFFBQUEsT0FBQSxlQUFBLE9BQUEsT0FBQSxPQUFBLFlBQUEsZUFBQTtBQUE0RCxJQUFBLHdCQUFBLGNBQUEsVUFBQSxXQUFBO0FBQzFGLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsVUFBQSxNQUFBLG9CQUFBOzs7OztBQU1aLElBQUEsb0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFrQyxJQUFBLG9CQUFBLENBQUE7QUFBbUMsSUFBQSwwQkFBQTtBQUN6RSxJQUFBLG9CQUFBLEdBQUEsUUFBQTs7OztBQURzQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsNEJBQUEsQ0FBQTs7O0FEL0QxQyxJQVlhO0FBWmI7O0FBQ0E7QUFFQTtBQUNBO0FBRUE7Ozs7QUFNTSxJQUFPLHVDQUFQLE1BQU8sc0NBQW9DO01BRTdDO01BR0E7TUFHQTtNQUdBO01BR0EsWUFBWSxJQUFJLGFBQVk7TUFFNUI7TUFFQTtNQUVBO01BRUE7TUFHQSxXQUFXLGlCQUFpQjtNQUU1QixVQUFVLFdBQVc7TUFFckIsVUFBVTtNQUVWLFlBQVksZ0JBQThCO0FBQ3RDLGFBQUssVUFBVSxlQUFlLFFBQU87TUFDekM7TUFFQSxXQUFRO0FBQ0osYUFBSyxVQUFVLEtBQUssYUFBYSxXQUFXO0FBQzVDLGFBQUssb0JBQW9CLEtBQUssbUJBQWtCO0FBQ2hELGFBQUssdUJBQXVCLENBQUMsRUFBRSxDQUFDLEtBQUssYUFBYSxpQkFBaUIsS0FBSztNQUM1RTtNQUVBLFlBQVksU0FBc0I7QUFDOUIsWUFBSSxRQUFRLGVBQWU7QUFDdkIsZUFBSyxvQkFBb0IsS0FBSyxtQkFBa0I7O0FBRXBELFlBQUksUUFBUSxhQUFhO0FBQ3JCLGVBQUssVUFBVSxLQUFLLGFBQWEsV0FBVzs7TUFFcEQ7TUFFQSxxQkFBa0I7QUFDZCxlQUFPLEtBQUssY0FBYyxPQUFPLENBQUMsV0FBVyxLQUFLLGFBQWEsaUJBQWlCLEtBQUssbUJBQW1CLGlCQUFpQixDQUFBLEdBQUksU0FBUyxNQUFNLEVBQUUsQ0FBQztNQUNuSjtNQUVBLHdCQUFxQjtBQUNqQixlQUFPLEtBQUssY0FBYyxLQUFLLENBQUMsVUFBVSxNQUFNLE9BQU8sS0FBSyxhQUFhLGNBQWMsR0FBRyxRQUFRLEtBQUssYUFBYTtNQUN4SDtNQUVBLDhCQUEyQjtBQUN2QixlQUFPLEtBQUssY0FBYyxLQUFLLENBQUMsVUFBVSxNQUFNLE9BQU8sS0FBSyxtQkFBbUIsY0FBYyxHQUFHLFFBQVEsS0FBSyxtQkFBbUI7TUFDcEk7TUFFQSxtQ0FBbUMsT0FBZ0I7QUFDL0MsYUFBSyx1QkFBdUI7QUFDNUIsWUFBSSxLQUFLLGtCQUFrQixTQUFTLEtBQUssR0FBRztBQUN4QyxlQUFLLG9CQUFvQixLQUFLLGtCQUFrQixPQUFPLENBQUMsTUFBTSxNQUFNLEtBQUs7ZUFDdEU7QUFDSCxlQUFLLGtCQUFrQixLQUFLLEtBQUs7O0FBRXJDLGFBQUssWUFBYSxnQkFBZ0IsS0FBSyxrQkFBa0IsSUFBSSxDQUFDQyxXQUFVQSxPQUFNLEVBQUU7TUFDcEY7TUFFQSxTQUFTLE9BQTRCO0FBQ2pDLGFBQUssWUFBYSxpQkFBaUIsT0FBTztNQUM5QztNQUVBLGtCQUFlO0FBQ1gsYUFBSyxZQUFhLFVBQVUsS0FBSztNQUNyQztNQUVBLCtCQUE0QjtBQUN4QixZQUFJLEtBQUssc0JBQXNCO0FBQzNCLGVBQUssWUFBYSxnQkFBZ0I7QUFDbEMsZUFBSyxvQkFBb0IsS0FBSyxtQkFBa0I7ZUFDN0M7QUFDSCxlQUFLLFlBQWEsZ0JBQWdCLEtBQUssa0JBQWtCLElBQUksQ0FBQyxVQUFVLE1BQU0sRUFBRTs7TUFFeEY7O3lCQXZGUyx1Q0FBb0MsK0JBQUEsY0FBQSxDQUFBO01BQUE7Z0VBQXBDLHVDQUFvQyxXQUFBLENBQUEsQ0FBQSxxQ0FBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLGFBQUEsZUFBQSxtQkFBQSxxQkFBQSxlQUFBLGlCQUFBLGNBQUEsZUFBQSxHQUFBLFNBQUEsRUFBQSxXQUFBLFlBQUEsR0FBQSxVQUFBLENBQUEsaUNBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsY0FBQSxhQUFBLEdBQUEsQ0FBQSxRQUFBLFlBQUEsTUFBQSx5QkFBQSxHQUFBLG9CQUFBLEdBQUEsWUFBQSxXQUFBLGlCQUFBLFFBQUEsR0FBQSxDQUFBLE9BQUEseUJBQUEsZ0JBQUEseURBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsZ0JBQUEscURBQUEsR0FBQSxjQUFBLE1BQUEsR0FBQSxDQUFBLGdCQUFBLG1FQUFBLEdBQUEsV0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsb0VBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsb0JBQUEsR0FBQSxDQUFBLGVBQUEsSUFBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxNQUFBLGtCQUFBLHFCQUFBLElBQUEsR0FBQSxPQUFBLHVCQUFBLE9BQUEsR0FBQSxDQUFBLG1CQUFBLElBQUEsbUJBQUEsZ0JBQUEsR0FBQSxDQUFBLFFBQUEsWUFBQSxNQUFBLDhCQUFBLEdBQUEsb0JBQUEsR0FBQSxZQUFBLFdBQUEsaUJBQUEsUUFBQSxHQUFBLENBQUEsT0FBQSw4QkFBQSxnQkFBQSwyRUFBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLFFBQUEsWUFBQSxHQUFBLG9CQUFBLEdBQUEsTUFBQSxZQUFBLFdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxvQkFBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLG1CQUFBLElBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxtQkFBQSxJQUFBLEdBQUEsY0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZ0JBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSw4Q0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1pqRCxVQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsU0FBQSxDQUFBO0FBS0ksVUFBQSx3QkFBQSxpQkFBQSxTQUFBLDZFQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLFVBQUE7VUFBQSxDQUFBLEVBQXFCLFVBQUEsU0FBQSx3RUFBQTtBQUFBLG1CQUNYLElBQUEsZ0JBQUE7VUFBaUIsQ0FBQTtBQU4vQixVQUFBLDBCQUFBO0FBUUEsVUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQWtJLFVBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFpQixVQUFBLDBCQUFBO0FBQ3ZKLFVBQUEsb0JBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUE2RixVQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFNLFVBQUEsMEJBQUE7QUFDbkcsVUFBQSxvQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsTUFBQSxFQUFNLElBQUEsUUFBQSxDQUFBO0FBQTBHLFVBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFjLFVBQUEsMEJBQUE7QUFBTyxVQUFBLG9CQUFBLElBQUEsSUFBQTtBQUFFLFVBQUEsMEJBQUE7QUFDdkksVUFBQSxvQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsOERBQUEsR0FBQSxDQUFBO0FBYUEsVUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLHNEQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsc0NBQUE7QUFlSixVQUFBLDBCQUFBO0FBQ0EsVUFBQSxvQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsTUFBQSxDQUFBLEVBQWlCLElBQUEsUUFBQSxDQUFBO0FBQXNHLFVBQUEsb0JBQUEsSUFBQSxpQkFBQTtBQUFlLFVBQUEsMEJBQUE7QUFBTyxVQUFBLG9CQUFBLElBQUEsR0FBQTtBQUFDLFVBQUEsMEJBQUE7QUFDOUksVUFBQSxvQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxvQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsVUFBQSxFQUFBO0FBQ0ksVUFBQSxvQkFBQSxFQUFBOztBQUNKLFVBQUEsMEJBQUE7QUFDQSxVQUFBLG9CQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxVQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsOERBQUEsR0FBQSxDQUFBO0FBS0EsVUFBQSw4QkFBQSxJQUFBLHNEQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsc0NBQUE7QUFLSixVQUFBLDBCQUFBO0FBQ0osVUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDBCQUFBO0FBQ0EsVUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsOERBQUEsR0FBQSxDQUFBO0FBR0osVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsSUFBQSxJQUFBOzs7O0FBN0RRLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsd0JBQUEsWUFBQSxDQUFBLElBQUEsV0FBQSxJQUFBLGlCQUFBLElBQUEsUUFBQSxFQUFrRCxXQUFBLElBQUEsT0FBQTtBQVExRCxVQUFBLHVCQUFBLEVBQUE7QUFBQSxVQUFBLDJCQUFBLElBQUEsSUFBQSxvQkFBQSxLQUFBLEVBQUE7QUFjSSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsYUFBQTtBQW9CUSxVQUFBLHVCQUFBLEVBQUE7QUFBQSxVQUFBLGdDQUFBLG1CQUFBLFVBQUEsSUFBQSxzQkFBQSxPQUFBLFFBQUEsWUFBQSxTQUFBLFVBQUEseUJBQUEsSUFBQSxHQUFBLG9FQUFBLEdBQUEsWUFBQTtBQUdBLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsMkJBQUEsSUFBQSxJQUFBLG9CQUFBLEtBQUEsRUFBQTtBQUtBLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxpQkFBQTtBQU9SLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsMkJBQUEsSUFBQSxFQUFBLElBQUEsZUFBQSxPQUFBLE9BQUEsSUFBQSxZQUFBLGtCQUFBLEtBQUEsRUFBQTs7Ozs7b0ZEbERTLHNDQUFvQyxFQUFBLFdBQUEsdUNBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFVmpELElBQWE7QUFBYjs7QUFBTSxJQUFPLGVBQVAsTUFBbUI7TUFDckI7TUFDQSxVQUFVOzs7Ozs7QUNKZCxTQUFTLGFBQUFDLFlBQVcsZ0JBQUFDLGVBQWMsU0FBQUMsUUFBMEIsVUFBQUMsZUFBNkI7Ozs7OztBQ0NyRixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQThHLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQVUsSUFBQSwyQkFBQTtBQUN4SCxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxpQkFBQSxDQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQWlILElBQUEseUJBQUEsaUJBQUEsU0FBQSx5RkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBYSwwQkFBQSxPQUFBLFlBQUEsWUFBQSxNQUFBO0lBQ25JLENBQUE7QUFESyxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLElBQUE7Ozs7QUFIdUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLHVEQUFBO0FBQzJELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxFQUFBLEVBQWdCLGFBQUEsR0FBQSxFQUFBLFdBQUEsT0FBQSxZQUFBLFNBQUE7Ozs7OztBQUk5RixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQ0ssSUFBQSxxQkFBQSxHQUFBLDhCQUFBO0FBQTRCLElBQUEsMkJBQUE7QUFFakMsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsaUJBQUEsQ0FBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQU9JLElBQUEseUJBQUEsaUJBQUEsU0FBQSx5RkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBYSwwQkFBQSxPQUFBLFlBQUEsMEJBQUEsTUFBQTtJQUNuQixDQUFBO0FBUkUsSUFBQSwyQkFBQTtBQVNKLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxJQUFBOzs7O0FBWHVCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxxRUFBQTtBQU1YLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxDQUFBLEVBQWUsYUFBQSxHQUFBLEVBQUEsV0FBQSxPQUFBLFlBQUEsdUJBQUE7Ozs7OztBQVNuQixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQXdHLElBQUEseUJBQUEsVUFBQSxTQUFBLG9GQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBVSwwQkFBQSxPQUFBLHlCQUFBLENBQTBCO0lBQUEsQ0FBQTtBQUE1SSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUEySCxJQUFBLHFCQUFBLEdBQUEsU0FBQTtBQUFPLElBQUEsMkJBQUE7QUFDdEksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7QUFINkUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLEVBQUEsT0FBQSxlQUFBLE9BQUEsT0FBQSxPQUFBLFlBQUEsU0FBQTs7O0FENUJqRixJQVFhO0FBUmI7O0FBQ0E7QUFDQTs7Ozs7QUFNTSxJQUFPLHFDQUFQLE1BQU8sb0NBQWtDO01BRTNDO01BR0E7TUFHQSxvQkFBb0I7TUFHcEIsWUFBWSxJQUFJRixjQUFZO01BRTVCO01BRUE7TUFFQTtNQUVBLFdBQVE7QUFDSixhQUFLLGtCQUFrQixLQUFLLGFBQWEsVUFBVSxXQUFXLEtBQUssbUJBQW1CLFVBQVUsV0FBVztNQUMvRztNQUVBLFlBQVksU0FBc0I7QUFDOUIsWUFBSSxRQUFRLGVBQWUsUUFBUSxtQkFBbUI7QUFDbEQsZUFBSyxrQkFBa0IsS0FBSyxhQUFhLFVBQVUsV0FBVyxLQUFLLG1CQUFtQixVQUFVLFdBQVc7O01BRW5IO01BRUEsMkJBQXdCO0FBQ3BCLFlBQUksS0FBSyxhQUFhLFVBQVU7QUFDNUIsZUFBSyxtQkFBbUIsS0FBSyxhQUFhO0FBQzFDLGVBQUssWUFBWSxXQUFXO0FBQzVCLGVBQUssa0JBQWtCLEtBQUssbUJBQW1CLFVBQVUsV0FBVztlQUNqRTtBQUNILGdCQUFNLGVBQWUsSUFBSSxhQUFZO0FBQ3JDLHVCQUFhLFVBQVU7QUFDdkIsZUFBSyxZQUFhLFdBQVcsS0FBSyxvQkFBb0I7O01BRTlEO01BRUEsb0JBQWlCO0FBQ2IsWUFBSSxLQUFLLGFBQWEsVUFBVTtBQUM1QixlQUFLLFlBQVksU0FBUyxVQUFVLEtBQUs7ZUFDdEM7QUFDSCxnQkFBTSxlQUFlLElBQUksYUFBWTtBQUNyQyx1QkFBYSxVQUFVLEtBQUs7QUFDNUIsZUFBSyxZQUFhLFdBQVc7O01BRXJDOzt5QkFqRFMscUNBQWtDO01BQUE7aUVBQWxDLHFDQUFrQyxXQUFBLENBQUEsQ0FBQSxtQ0FBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLGFBQUEsZUFBQSxtQkFBQSxxQkFBQSxtQkFBQSxvQkFBQSxHQUFBLFNBQUEsRUFBQSxXQUFBLFlBQUEsR0FBQSxVQUFBLENBQUEsa0NBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsUUFBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSxxREFBQSxHQUFBLENBQUEsTUFBQSxtQkFBQSxRQUFBLE1BQUEsR0FBQSxnQkFBQSxHQUFBLFdBQUEsWUFBQSxpQkFBQSxRQUFBLEdBQUEsQ0FBQSxPQUFBLGFBQUEsZ0JBQUEsa0RBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxNQUFBLGFBQUEsUUFBQSxhQUFBLFFBQUEsVUFBQSxHQUFBLGdCQUFBLEdBQUEsYUFBQSxhQUFBLFdBQUEsZUFBQSxHQUFBLENBQUEsT0FBQSwyQkFBQSxnQkFBQSxnRUFBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxNQUFBLDJCQUFBLFFBQUEsMkJBQUEsUUFBQSxVQUFBLEdBQUEsZ0JBQUEsR0FBQSxhQUFBLGFBQUEsV0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsYUFBQSxHQUFBLENBQUEsUUFBQSxZQUFBLE1BQUEsbUJBQUEsR0FBQSxvQkFBQSxHQUFBLFdBQUEsUUFBQSxHQUFBLENBQUEsT0FBQSxtQkFBQSxnQkFBQSx5REFBQSxHQUFBLGtCQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsNENBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNSL0MsVUFBQSx5QkFBQSxHQUFBLDJEQUFBLElBQUEsQ0FBQSxFQU1DLEdBQUEsMkRBQUEsSUFBQSxDQUFBO0FBa0JELFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFBdUUsVUFBQSxxQkFBQSxHQUFBLFVBQUE7QUFBUSxVQUFBLDJCQUFBO0FBQy9FLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLDJEQUFBLEdBQUEsQ0FBQTtBQU1BLFVBQUEsNkJBQUEsR0FBQSxZQUFBLENBQUE7QUFBOEQsVUFBQSx5QkFBQSxpQkFBQSxTQUFBLDhFQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLGtCQUFBO1VBQUEsQ0FBQSxFQUE2QixVQUFBLFNBQUEseUVBQUE7QUFBQSxtQkFBVyxJQUFBLGtCQUFBO1VBQW1CLENBQUE7QUFBc0MsVUFBQSwyQkFBQTtBQUNuSyxVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBbENBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLG9CQUFBLElBQUEsRUFBQTtBQU9BLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLG9CQUFBLElBQUEsRUFBQTtBQW1CSSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxvQkFBQSxJQUFBLEVBQUE7QUFNOEQsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxXQUFBLElBQUEsZUFBQSxFQUE2QixZQUFBLEVBQUEsSUFBQSxlQUFBLE9BQUEsT0FBQSxJQUFBLFlBQUEsU0FBQTs7Ozs7cUZEeEJsRixvQ0FBa0MsRUFBQSxXQUFBLHFDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVIvQyxTQUFTLGFBQUFHLFlBQVcsZ0JBQUFDLGVBQWMsU0FBQUMsUUFBMEIsVUFBQUMsZUFBNkI7Ozs7OztBQ0dqRixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQXdHLElBQUEseUJBQUEsVUFBQSxTQUFBLHNGQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBVSwwQkFBQSxPQUFBLHlCQUFBLENBQTBCO0lBQUEsQ0FBQTtBQUE1SSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQUEySCxJQUFBLHFCQUFBLEdBQUEsU0FBQTtBQUFPLElBQUEsMkJBQUE7QUFDdEksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7QUFINkUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLEVBQUEsT0FBQSxlQUFBLE9BQUEsT0FBQSxPQUFBLFlBQUEsU0FBQTs7O0FESmpGLElBUWE7QUFSYjs7QUFDQTtBQUNBOztBQU1NLElBQU8sdUNBQVAsTUFBTyxzQ0FBb0M7TUFFN0M7TUFHQTtNQUdBLFlBQVksSUFBSUYsY0FBWTtNQUU1QjtNQUVBO01BRUE7TUFFQSxXQUFRO0FBQ0osYUFBSyxrQkFBa0IsS0FBSyxZQUFZLFVBQVUsV0FBVyxLQUFLLG1CQUFtQixVQUFVLFdBQVc7TUFDOUc7TUFFQSxZQUFZLFNBQXNCO0FBQzlCLFlBQUksUUFBUSxlQUFlLFFBQVEsbUJBQW1CO0FBQ2xELGVBQUssa0JBQWtCLEtBQUssYUFBYSxVQUFVLFdBQVcsS0FBSyxtQkFBbUIsVUFBVSxXQUFXOztNQUVuSDtNQUVBLDJCQUF3QjtBQUNwQixZQUFJLEtBQUssWUFBWSxVQUFVO0FBQzNCLGVBQUssbUJBQW1CLEtBQUssWUFBWTtBQUN6QyxlQUFLLFlBQVksV0FBVztBQUM1QixlQUFLLGtCQUFrQixLQUFLLG1CQUFtQixVQUFVLFdBQVc7ZUFDakU7QUFDSCxnQkFBTSxlQUFlLElBQUksYUFBWTtBQUNyQyx1QkFBYSxVQUFVO0FBQ3ZCLGVBQUssWUFBWSxXQUFXLEtBQUssb0JBQW9COztNQUU3RDtNQUVBLG9CQUFpQjtBQUNiLFlBQUksS0FBSyxZQUFZLFVBQVU7QUFDM0IsZUFBSyxZQUFZLFNBQVMsVUFBVSxLQUFLO2VBQ3RDO0FBQ0gsZ0JBQU0sZUFBZSxJQUFJLGFBQVk7QUFDckMsdUJBQWEsVUFBVSxLQUFLO0FBQzVCLGVBQUssWUFBWSxXQUFXOztNQUVwQzs7eUJBOUNTLHVDQUFvQztNQUFBO2lFQUFwQyx1Q0FBb0MsV0FBQSxDQUFBLENBQUEscUNBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxhQUFBLGVBQUEsbUJBQUEsb0JBQUEsR0FBQSxTQUFBLEVBQUEsV0FBQSxZQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFFBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEscURBQUEsR0FBQSxDQUFBLE1BQUEsbUJBQUEsUUFBQSxNQUFBLEdBQUEsZ0JBQUEsR0FBQSxXQUFBLFlBQUEsaUJBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLGFBQUEsR0FBQSxDQUFBLFFBQUEsWUFBQSxNQUFBLG1CQUFBLEdBQUEsb0JBQUEsR0FBQSxXQUFBLFFBQUEsR0FBQSxDQUFBLE9BQUEsbUJBQUEsZ0JBQUEseURBQUEsR0FBQSxrQkFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDhDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDUmpELFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFBdUUsVUFBQSxxQkFBQSxHQUFBLFVBQUE7QUFBUSxVQUFBLDJCQUFBO0FBQy9FLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLDZEQUFBLEdBQUEsQ0FBQTtBQU1BLFVBQUEsNkJBQUEsR0FBQSxZQUFBLENBQUE7QUFBOEQsVUFBQSx5QkFBQSxpQkFBQSxTQUFBLGdGQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLGtCQUFBO1VBQUEsQ0FBQSxFQUE2QixVQUFBLFNBQUEsMkVBQUE7QUFBQSxtQkFBVyxJQUFBLGtCQUFBO1VBQW1CLENBQUE7QUFBc0MsVUFBQSwyQkFBQTtBQUNuSyxVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsSUFBQTs7O0FBUkksVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsb0JBQUEsSUFBQSxFQUFBO0FBTThELFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsV0FBQSxJQUFBLGVBQUEsRUFBNkIsWUFBQSxFQUFBLElBQUEsZUFBQSxPQUFBLE9BQUEsSUFBQSxZQUFBLFNBQUE7Ozs7O3FGREFsRixzQ0FBb0MsRUFBQSxXQUFBLHVDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVJqRCxTQUFTLGFBQUFHLFlBQVcsZ0JBQUFDLGVBQWMsU0FBQUMsUUFBTyxVQUFBQyxlQUFjOzs7Ozs7QUNDbkQsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxTQUFBLENBQUE7QUFBb0UsSUFBQSx5QkFBQSxpQkFBQSxTQUFBLGtHQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFhLDBCQUFBLE9BQUEsYUFBQSx1QkFBQSxNQUFBO0lBQzFGLENBQUE7QUFEUyxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQUFtSCxJQUFBLHFCQUFBLEdBQUEsNkJBQUE7QUFBMEIsSUFBQSwyQkFBQTtBQUNqSixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsU0FBQSxDQUFBO0FBQXNFLElBQUEseUJBQUEsaUJBQUEsU0FBQSxtR0FBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBYSwwQkFBQSxPQUFBLGFBQUEseUJBQUEsTUFBQTtJQUM1RixDQUFBO0FBRFMsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxTQUFBLENBQUE7QUFBdUgsSUFBQSxxQkFBQSxJQUFBLCtCQUFBO0FBQTRCLElBQUEsMkJBQUE7QUFDdkosSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUEwRSxJQUFBLHlCQUFBLGlCQUFBLFNBQUEsbUdBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQWEsMEJBQUEsT0FBQSxhQUFBLDZCQUFBLE1BQUE7SUFDaEcsQ0FBQTtBQURTLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsU0FBQSxDQUFBO0FBQStILElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFpQyxJQUFBLDJCQUFBO0FBQ3BLLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxJQUFBOzs7O0FBWmdGLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxPQUFBLGFBQUEsb0JBQUE7QUFJRSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsT0FBQSxhQUFBLHNCQUFBO0FBSUksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLE9BQUEsYUFBQSwwQkFBQTs7O0FEWHRGLElBUWE7QUFSYjs7QUFDQTs7QUFPTSxJQUFPLDhDQUFQLE1BQU8sNkNBQTJDO01BRXBEO01BR0EsWUFBWSxJQUFJRixjQUFZOzt5QkFMbkIsOENBQTJDO01BQUE7aUVBQTNDLDhDQUEyQyxXQUFBLENBQUEsQ0FBQSw0Q0FBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLGNBQUEsZUFBQSxHQUFBLFNBQUEsRUFBQSxXQUFBLFlBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsY0FBQSxhQUFBLEdBQUEsQ0FBQSxRQUFBLFlBQUEsTUFBQSxrQkFBQSxHQUFBLG9CQUFBLEdBQUEsV0FBQSxlQUFBLEdBQUEsQ0FBQSxPQUFBLGtCQUFBLGdCQUFBLGlEQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLFFBQUEsWUFBQSxNQUFBLG9CQUFBLEdBQUEsb0JBQUEsR0FBQSxXQUFBLGVBQUEsR0FBQSxDQUFBLE9BQUEsb0JBQUEsZ0JBQUEsbURBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsUUFBQSxZQUFBLE1BQUEsd0JBQUEsR0FBQSxvQkFBQSxHQUFBLFdBQUEsZUFBQSxHQUFBLENBQUEsT0FBQSx3QkFBQSxnQkFBQSx1REFBQSxHQUFBLGtCQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEscURBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNSeEQsVUFBQSx5QkFBQSxHQUFBLG9FQUFBLElBQUEsQ0FBQTs7O0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsZUFBQSxJQUFBLEVBQUE7Ozs7O3FGRFFhLDZDQUEyQyxFQUFBLFdBQUEsOENBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFUnhELFNBQVMsYUFBQUcsWUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUEwQixVQUFBQyxlQUE2Qjs7Ozs7O0FDR2pGLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxTQUFBLEVBQUE7QUFBNEcsSUFBQSx5QkFBQSxVQUFBLFNBQUEsMEZBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFVLDBCQUFBLE9BQUEseUJBQUEsQ0FBMEI7SUFBQSxDQUFBO0FBQWhKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQTRJLElBQUEscUJBQUEsR0FBQSxTQUFBO0FBQU8sSUFBQSwyQkFBQTtBQUN2SixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQUg2RSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsRUFBQSxPQUFBLGVBQUEsT0FBQSxPQUFBLE9BQUEsWUFBQSxhQUFBOzs7QURKakYsSUFRYTtBQVJiOztBQUNBO0FBQ0E7O0FBTU0sSUFBTywyQ0FBUCxNQUFPLDBDQUF3QztNQUVqRDtNQUdBO01BR0EsWUFBWSxJQUFJRixjQUFZO01BRTVCO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFFQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BRUEsV0FBUTtBQUNKLGFBQUssZUFBYztNQUN2QjtNQUVBLFlBQVksU0FBc0I7QUFDOUIsWUFBSSxRQUFRLGVBQWUsUUFBUSxtQkFBbUI7QUFDbEQsZUFBSyxlQUFjOztNQUUzQjtNQUVRLGlCQUFjO0FBQ2xCLGFBQUssc0JBQXNCLEtBQUssYUFBYSxjQUFjLFdBQVcsS0FBSyxtQkFBbUIsY0FBYyxXQUFXO0FBQ3ZILGFBQUssNENBQ0QsS0FBSyxhQUFhLG9DQUFvQyxXQUFXLEtBQUssbUJBQW1CLG9DQUFvQyxXQUFXO0FBQzVJLGFBQUssd0NBQ0QsS0FBSyxhQUFhLGdDQUFnQyxXQUFXLEtBQUssbUJBQW1CLGdDQUFnQyxXQUFXO0FBQ3BJLGFBQUssd0NBQ0QsS0FBSyxhQUFhLGdDQUFnQyxXQUFXLEtBQUssbUJBQW1CLGdDQUFnQyxXQUFXO0FBQ3BJLGFBQUssb0NBQW9DLEtBQUssYUFBYSw0QkFBNEIsV0FBVyxLQUFLLG1CQUFtQiw0QkFBNEIsV0FBVztNQUNySztNQUVBLDJCQUF3QjtBQUNwQixZQUFJLEtBQUssYUFBYSxjQUFjO0FBQ2hDLGVBQUssdUJBQXVCLEtBQUssYUFBYTtBQUM5QyxlQUFLLFlBQVksZUFBZTtBQUNoQyxlQUFLLHNCQUFzQixLQUFLLG1CQUFtQixjQUFjLFdBQVc7ZUFDekU7QUFDSCxnQkFBTSxlQUFlLElBQUksYUFBWTtBQUNyQyx1QkFBYSxVQUFVO0FBQ3ZCLGVBQUssWUFBYSxlQUFlLEtBQUssd0JBQXdCOztBQUVsRSxZQUFJLEtBQUssYUFBYSxvQ0FBb0M7QUFDdEQsZUFBSyw2Q0FBNkMsS0FBSyxhQUFhO0FBQ3BFLGVBQUssWUFBWSxxQ0FBcUM7QUFDdEQsZUFBSyw0Q0FBNEMsS0FBSyxtQkFBbUIsb0NBQW9DLFdBQVc7ZUFDckg7QUFDSCxnQkFBTSxlQUFlLElBQUksYUFBWTtBQUNyQyx1QkFBYSxVQUFVO0FBQ3ZCLGVBQUssWUFBYSxxQ0FBcUMsS0FBSyw4Q0FBOEM7O0FBRTlHLFlBQUksS0FBSyxhQUFhLGdDQUFnQztBQUNsRCxlQUFLLHlDQUF5QyxLQUFLLGFBQWE7QUFDaEUsZUFBSyxZQUFZLGlDQUFpQztBQUNsRCxlQUFLLHdDQUF3QyxLQUFLLG1CQUFtQixnQ0FBZ0MsV0FBVztlQUM3RztBQUNILGdCQUFNLGVBQWUsSUFBSSxhQUFZO0FBQ3JDLHVCQUFhLFVBQVU7QUFDdkIsZUFBSyxZQUFhLGlDQUFpQyxLQUFLLDBDQUEwQzs7QUFFdEcsWUFBSSxLQUFLLGFBQWEsZ0NBQWdDO0FBQ2xELGVBQUsseUNBQXlDLEtBQUssYUFBYTtBQUNoRSxlQUFLLFlBQVksaUNBQWlDO0FBQ2xELGVBQUssd0NBQXdDLEtBQUssbUJBQW1CLGdDQUFnQyxXQUFXO2VBQzdHO0FBQ0gsZ0JBQU0sZUFBZSxJQUFJLGFBQVk7QUFDckMsdUJBQWEsVUFBVTtBQUN2QixlQUFLLFlBQWEsaUNBQWlDLEtBQUssMENBQTBDOztBQUV0RyxZQUFJLEtBQUssYUFBYSw0QkFBNEI7QUFDOUMsZUFBSyxxQ0FBcUMsS0FBSyxhQUFhO0FBQzVELGVBQUssWUFBWSw2QkFBNkI7QUFDOUMsZUFBSyxvQ0FBb0MsS0FBSyxtQkFBbUIsNEJBQTRCLFdBQVc7ZUFDckc7QUFDSCxnQkFBTSxlQUFlLElBQUksYUFBWTtBQUNyQyx1QkFBYSxVQUFVO0FBQ3ZCLGVBQUssWUFBYSw2QkFBNkIsS0FBSyxzQ0FBc0M7O01BRWxHO01BRUEsb0JBQWlCO0FBQ2IsWUFBSSxLQUFLLGFBQWEsY0FBYztBQUNoQyxlQUFLLFlBQVksYUFBYSxVQUFVLEtBQUs7ZUFDMUM7QUFDSCxnQkFBTSxlQUFlLElBQUksYUFBWTtBQUNyQyx1QkFBYSxVQUFVLEtBQUs7QUFDNUIsZUFBSyxZQUFhLGVBQWU7O0FBRXJDLFlBQUksS0FBSyxhQUFhLG9DQUFvQztBQUN0RCxlQUFLLFlBQVksbUNBQW1DLFVBQVUsS0FBSztlQUNoRTtBQUNILGdCQUFNLGVBQWUsSUFBSSxhQUFZO0FBQ3JDLHVCQUFhLFVBQVUsS0FBSztBQUM1QixlQUFLLFlBQWEscUNBQXFDOztBQUUzRCxZQUFJLEtBQUssYUFBYSxnQ0FBZ0M7QUFDbEQsZUFBSyxZQUFZLCtCQUErQixVQUFVLEtBQUs7ZUFDNUQ7QUFDSCxnQkFBTSxlQUFlLElBQUksYUFBWTtBQUNyQyx1QkFBYSxVQUFVLEtBQUs7QUFDNUIsZUFBSyxZQUFhLGlDQUFpQzs7QUFFdkQsWUFBSSxLQUFLLGFBQWEsZ0NBQWdDO0FBQ2xELGVBQUssWUFBWSwrQkFBK0IsVUFBVSxLQUFLO2VBQzVEO0FBQ0gsZ0JBQU0sZUFBZSxJQUFJLGFBQVk7QUFDckMsdUJBQWEsVUFBVSxLQUFLO0FBQzVCLGVBQUssWUFBYSxpQ0FBaUM7O0FBRXZELFlBQUksS0FBSyxhQUFhLDRCQUE0QjtBQUM5QyxlQUFLLFlBQVksMkJBQTJCLFVBQVUsS0FBSztlQUN4RDtBQUNILGdCQUFNLGVBQWUsSUFBSSxhQUFZO0FBQ3JDLHVCQUFhLFVBQVUsS0FBSztBQUM1QixlQUFLLFlBQWEsNkJBQTZCOztNQUV2RDs7eUJBL0hTLDJDQUF3QztNQUFBO2lFQUF4QywyQ0FBd0MsV0FBQSxDQUFBLENBQUEsMENBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxhQUFBLGVBQUEsbUJBQUEsb0JBQUEsR0FBQSxTQUFBLEVBQUEsV0FBQSxZQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFFBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsMkRBQUEsR0FBQSxDQUFBLGdCQUFBLDhEQUFBLEdBQUEsQ0FBQSxNQUFBLHdCQUFBLFFBQUEsTUFBQSxHQUFBLGdCQUFBLEdBQUEsV0FBQSxZQUFBLGlCQUFBLFFBQUEsR0FBQSxDQUFBLGdCQUFBLDBFQUFBLEdBQUEsQ0FBQSxNQUFBLHFDQUFBLFFBQUEsTUFBQSxHQUFBLGdCQUFBLEdBQUEsV0FBQSxZQUFBLGlCQUFBLFFBQUEsR0FBQSxDQUFBLGdCQUFBLHNFQUFBLEdBQUEsQ0FBQSxNQUFBLGlDQUFBLFFBQUEsTUFBQSxHQUFBLGdCQUFBLEdBQUEsV0FBQSxZQUFBLGlCQUFBLFFBQUEsR0FBQSxDQUFBLGdCQUFBLHNFQUFBLEdBQUEsQ0FBQSxNQUFBLGlDQUFBLFFBQUEsTUFBQSxHQUFBLGdCQUFBLEdBQUEsV0FBQSxZQUFBLGlCQUFBLFFBQUEsR0FBQSxDQUFBLGdCQUFBLGtFQUFBLEdBQUEsQ0FBQSxNQUFBLDZCQUFBLFFBQUEsTUFBQSxHQUFBLGdCQUFBLEdBQUEsV0FBQSxZQUFBLGlCQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxhQUFBLEdBQUEsQ0FBQSxRQUFBLFlBQUEsTUFBQSxtQkFBQSxHQUFBLG9CQUFBLEdBQUEsV0FBQSxRQUFBLEdBQUEsQ0FBQSxPQUFBLG1CQUFBLGdCQUFBLDBFQUFBLEdBQUEsa0JBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxrREFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1JyRCxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQTZFLFVBQUEscUJBQUEsR0FBQSxXQUFBO0FBQVMsVUFBQSwyQkFBQTtBQUN0RixVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxpRUFBQSxHQUFBLENBQUE7QUFNQSxVQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUFnRixVQUFBLHFCQUFBLEdBQUEsZUFBQTtBQUFhLFVBQUEsMkJBQUE7QUFDN0YsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsWUFBQSxDQUFBO0FBSUksVUFBQSx5QkFBQSxpQkFBQSxTQUFBLHFGQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLHNCQUFBO1VBQUEsQ0FBQSxFQUFpQyxVQUFBLFNBQUEsZ0ZBQUE7QUFBQSxtQkFDdkIsSUFBQSxrQkFBQTtVQUFtQixDQUFBO0FBRWhDLFVBQUEsMkJBQUE7QUFDTCxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsTUFBQSxDQUFBO0FBQTRGLFVBQUEscUJBQUEsSUFBQSx1Q0FBQTtBQUFxQyxVQUFBLDJCQUFBO0FBQ2pJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFlBQUEsQ0FBQTtBQUlJLFVBQUEseUJBQUEsaUJBQUEsU0FBQSxxRkFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSw0Q0FBQTtVQUFBLENBQUEsRUFBdUQsVUFBQSxTQUFBLGdGQUFBO0FBQUEsbUJBQzdDLElBQUEsa0JBQUE7VUFBbUIsQ0FBQTtBQUVoQyxVQUFBLDJCQUFBO0FBQ0wsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsS0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUF3RixVQUFBLHFCQUFBLElBQUEsbUNBQUE7QUFBaUMsVUFBQSwyQkFBQTtBQUN6SCxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxZQUFBLENBQUE7QUFJSSxVQUFBLHlCQUFBLGlCQUFBLFNBQUEscUZBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsd0NBQUE7VUFBQSxDQUFBLEVBQW1ELFVBQUEsU0FBQSxnRkFBQTtBQUFBLG1CQUN6QyxJQUFBLGtCQUFBO1VBQW1CLENBQUE7QUFFaEMsVUFBQSwyQkFBQTtBQUNMLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLEtBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxNQUFBLENBQUE7QUFBd0YsVUFBQSxxQkFBQSxJQUFBLG1DQUFBO0FBQWlDLFVBQUEsMkJBQUE7QUFDekgsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsWUFBQSxDQUFBO0FBSUksVUFBQSx5QkFBQSxpQkFBQSxTQUFBLHFGQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLHdDQUFBO1VBQUEsQ0FBQSxFQUFtRCxVQUFBLFNBQUEsZ0ZBQUE7QUFBQSxtQkFDekMsSUFBQSxrQkFBQTtVQUFtQixDQUFBO0FBRWhDLFVBQUEsMkJBQUE7QUFDTCxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQW9GLFVBQUEscUJBQUEsSUFBQSwrQkFBQTtBQUE2QixVQUFBLDJCQUFBO0FBQ2pILFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFlBQUEsRUFBQTtBQUlJLFVBQUEseUJBQUEsaUJBQUEsU0FBQSxxRkFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSxvQ0FBQTtVQUFBLENBQUEsRUFBK0MsVUFBQSxTQUFBLGdGQUFBO0FBQUEsbUJBQ3JDLElBQUEsa0JBQUE7VUFBbUIsQ0FBQTtBQUVoQyxVQUFBLDJCQUFBO0FBQ0wsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQTlESSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxvQkFBQSxJQUFBLEVBQUE7QUFZUSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsSUFBQSxtQkFBQSxFQUFpQyxZQUFBLEVBQUEsSUFBQSxlQUFBLE9BQUEsT0FBQSxJQUFBLFlBQUEsYUFBQTtBQVdqQyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsSUFBQSx5Q0FBQSxFQUF1RCxZQUFBLEVBQUEsSUFBQSxlQUFBLE9BQUEsT0FBQSxJQUFBLFlBQUEsbUNBQUE7QUFXdkQsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxXQUFBLElBQUEscUNBQUEsRUFBbUQsWUFBQSxFQUFBLElBQUEsZUFBQSxPQUFBLE9BQUEsSUFBQSxZQUFBLCtCQUFBO0FBV25ELFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsV0FBQSxJQUFBLHFDQUFBLEVBQW1ELFlBQUEsRUFBQSxJQUFBLGVBQUEsT0FBQSxPQUFBLElBQUEsWUFBQSwrQkFBQTtBQVduRCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsSUFBQSxpQ0FBQSxFQUErQyxZQUFBLEVBQUEsSUFBQSxlQUFBLE9BQUEsT0FBQSxJQUFBLFlBQUEsMkJBQUE7Ozs7O3FGRGxEOUMsMENBQXdDLEVBQUEsV0FBQSwyQ0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVSckQsU0FBUyxhQUFBRyxZQUFvQixTQUFBQyxjQUFxQjtBQUlsRCxTQUFTLGtCQUFrQjtBQUczQixTQUFTLFVBQVUsY0FBYztBQUdqQyxTQUFTLFdBQVcsZUFBZTs7Ozs7QUNLdkIsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQTZELElBQUEscUJBQUEsR0FBQSxzQkFBQTtBQUFvQixJQUFBLDJCQUFBO0FBQ2pGLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSw4Q0FBQSxDQUFBO0FBQTBFLElBQUEseUJBQUEsYUFBQSxTQUFBLG1JQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFBLE9BQUEsVUFBdUIsSUFBSTtJQUFBLENBQUE7QUFBRSxJQUFBLDJCQUFBO0FBQzNHLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7OztBQUZvRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGdCQUFBLE9BQUEsWUFBQTs7Ozs7O0FBb0JoRCxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxNQUFBLENBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQXVFLElBQUEscUJBQUEsR0FBQSxpQkFBQTtBQUFlLElBQUEsMkJBQUE7QUFDdEYsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLHVDQUFBLENBQUE7QUFLSSxJQUFBLHlCQUFBLGFBQUEsU0FBQSw2SEFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQSxDQUFBO0FBQUEsYUFBQSwwQkFBQSxPQUFBLFVBQXVCLElBQUk7SUFBQSxDQUFBO0FBQzlCLElBQUEsMkJBQUE7QUFDRCxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsdUNBQUEsQ0FBQTtBQUdJLElBQUEseUJBQUEsYUFBQSxTQUFBLDhIQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFBLE9BQUEsVUFBdUIsSUFBSTtJQUFBLENBQUE7QUFDOUIsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsWUFBQTs7Ozs7QUFaWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGVBQUEsT0FBQSxnQkFBQSxPQUFBLE9BQUEsT0FBQSxhQUFBLGtCQUFBLEVBQWlELHFCQUFBLE9BQUEsc0JBQUEsT0FBQSxPQUFBLE9BQUEsbUJBQUEsa0JBQUEsRUFBQSxrQkFBQSxVQUFBLE9BQUEsbUJBQUEsUUFBQSxZQUFBLFNBQUEsVUFBQSw4QkFBQSxHQUFBLEdBQUEsQ0FBQSxFQUFBLGdCQUFBLE9BQUEsWUFBQTtBQU9qRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGVBQUEsT0FBQSxnQkFBQSxPQUFBLE9BQUEsT0FBQSxhQUFBLGtCQUFBLEVBQWlELHFCQUFBLE9BQUEsc0JBQUEsT0FBQSxPQUFBLE9BQUEsbUJBQUEsa0JBQUE7Ozs7OztBQU96RCxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxNQUFBLENBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQTJFLElBQUEscUJBQUEsR0FBQSxzQkFBQTtBQUFvQixJQUFBLDJCQUFBO0FBQy9GLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSx1Q0FBQSxDQUFBO0FBS0ksSUFBQSx5QkFBQSxhQUFBLFNBQUEsNkhBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQUEsMEJBQUEsT0FBQSxVQUF1QixJQUFJO0lBQUEsQ0FBQTtBQUM5QixJQUFBLDJCQUFBO0FBQ0QsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLDRDQUFBLENBQUE7QUFHSSxJQUFBLHlCQUFBLGFBQUEsU0FBQSxtSUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBQSwwQkFBQSxRQUFBLFVBQXVCLElBQUk7SUFBQSxDQUFBO0FBQzlCLElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7Ozs7O0FBWlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxlQUFBLE9BQUEsZ0JBQUEsT0FBQSxPQUFBLE9BQUEsYUFBQSxzQkFBQSxFQUFvRCxxQkFBQSxPQUFBLHNCQUFBLE9BQUEsT0FBQSxPQUFBLG1CQUFBLHNCQUFBLEVBQUEsa0JBQUEsVUFBQSxPQUFBLG1CQUFBLFFBQUEsWUFBQSxTQUFBLFVBQUEsOEJBQUEsR0FBQSxHQUFBLENBQUEsRUFBQSxnQkFBQSxPQUFBLFlBQUE7QUFPcEQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxlQUFBLE9BQUEsZ0JBQUEsT0FBQSxPQUFBLE9BQUEsYUFBQSxzQkFBQSxFQUFvRCxxQkFBQSxPQUFBLHNCQUFBLE9BQUEsT0FBQSxPQUFBLG1CQUFBLHNCQUFBOzs7Ozs7QUFyRHBFLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxrRUFBQSxHQUFBLENBQUE7QUFNQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQXFFLElBQUEscUJBQUEsR0FBQSxlQUFBO0FBQWEsSUFBQSwyQkFBQTtBQUNsRixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLHVDQUFBLENBQUE7QUFLSSxJQUFBLHlCQUFBLGFBQUEsU0FBQSw4R0FBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQUEsUUFBQSxVQUF1QixJQUFJO0lBQUEsQ0FBQTtBQUM5QixJQUFBLDJCQUFBO0FBQ0QsSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLHFDQUFBLENBQUE7QUFJSSxJQUFBLHlCQUFBLGFBQUEsU0FBQSw2R0FBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQUEsUUFBQSxVQUF1QixJQUFJO0lBQUEsQ0FBQTtBQUM5QixJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsbUVBQUEsSUFBQSxDQUFBLEVBaUJDLElBQUEsbUVBQUEsSUFBQSxDQUFBO0FBbUJMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsSUFBQTs7Ozs7QUEzRFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsaUJBQUEsT0FBQSxTQUFBLElBQUEsRUFBQTtBQVNRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsZUFBQSxPQUFBLGdCQUFBLE9BQUEsT0FBQSxPQUFBLGFBQUEsZ0JBQUEsRUFBOEMscUJBQUEsT0FBQSxzQkFBQSxPQUFBLE9BQUEsT0FBQSxtQkFBQSxnQkFBQSxFQUFBLGtCQUFBLFVBQUEsT0FBQSxtQkFBQSxRQUFBLFlBQUEsU0FBQSxVQUFBLDhCQUFBLElBQUEsR0FBQSxDQUFBLEVBQUEsZ0JBQUEsT0FBQSxZQUFBO0FBTzlDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsZUFBQSxPQUFBLGdCQUFBLE9BQUEsT0FBQSxPQUFBLGFBQUEsZ0JBQUEsRUFBOEMscUJBQUEsT0FBQSxzQkFBQSxPQUFBLE9BQUEsT0FBQSxtQkFBQSxnQkFBQSxFQUFBLHFCQUFBLE9BQUEsaUJBQUEsT0FBQSxNQUFBO0FBTXRELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLGlCQUFBLE9BQUEsV0FBQSxLQUFBLEVBQUE7QUFrQkEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsaUJBQUEsT0FBQSxXQUFBLEtBQUEsRUFBQTs7O0FEdERSLFNBaUJhO0FBakJiOztBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBS0E7Ozs7Ozs7Ozs7O0FBTU0sSUFBTyw4QkFBUCxNQUFPLDZCQUEyQjtNQStCeEI7TUFDQTtNQTlCTDtNQUVBO01BRUE7TUFFQTtNQUNBO01BQ0E7TUFFUDtNQUdBLFlBQVk7TUFDWixXQUFXO01BQ1gsVUFBVTtNQUVWLFVBQVUsV0FBVztNQUNyQixVQUFVLFdBQVc7TUFDckIsVUFBVSxXQUFXO01BRXJCLFNBQVM7TUFDVCxXQUFXO01BRVgsU0FBUyxpQkFBaUI7TUFDMUIsU0FBUyxpQkFBaUI7TUFDMUIsV0FBVyxpQkFBaUI7TUFFNUIsWUFDWSxxQkFDQSxjQUEwQjtBQUQxQixhQUFBLHNCQUFBO0FBQ0EsYUFBQSxlQUFBO01BQ1Q7TUFFSCxXQUFRO0FBQ0osYUFBSyxpQkFBZ0I7TUFDekI7TUFFQSxZQUFTO0FBQ0wsWUFBSSxDQUFDLFFBQVEsS0FBSyxjQUFjLEtBQUssb0JBQW9CLEdBQUc7QUFDeEQsZUFBSyxVQUFVOztNQUV2QjtNQUVBO01BRUEsZ0JBQWE7QUFDVCxlQUFPLENBQUMsS0FBSztNQUNqQjtNQUVBLGlCQUFjO0FBQ1YsYUFBSyxvQkFBb0IsY0FBYSxFQUFHLFVBQVUsQ0FBQyxXQUFVO0FBQzFELGVBQUssZ0JBQWdCO0FBQ3JCLGVBQUssWUFBWTtRQUNyQixDQUFDO01BQ0w7TUFFQSxtQkFBZ0I7QUFDWixhQUFLLFlBQVk7QUFDakIsYUFBSywyQkFBMEIsRUFBRyxVQUFVLENBQUMsYUFBWTtBQUNyRCxlQUFLLGVBQWM7QUFDbkIsY0FBSSxDQUFDLFVBQVU7QUFDWCxpQkFBSyxhQUFhLE1BQU0sMkNBQTJDOztBQUV2RSxlQUFLLGVBQWU7QUFDcEIsZUFBSyx5QkFBd0I7QUFDN0IsZUFBSyx1QkFBdUIsVUFBVSxRQUFRO0FBQzlDLGVBQUssVUFBVTtRQUNuQixDQUFDO0FBQ0QsYUFBSyxpQ0FBZ0MsRUFBRyxVQUFVLENBQUMsYUFBWTtBQUMzRCxjQUFJLENBQUMsVUFBVTtBQUNYLGlCQUFLLGFBQWEsTUFBTSxpREFBaUQ7O0FBRTdFLGVBQUsscUJBQXFCO1FBQzlCLENBQUM7TUFDTDtNQUVBLDJCQUF3QjtBQUNwQixZQUFJLENBQUMsS0FBSyxjQUFjO0FBQ3BCOztBQUVKLFlBQUksQ0FBQyxLQUFLLGFBQWEsa0JBQWtCO0FBQ3JDLGVBQUssYUFBYSxtQkFBbUIsSUFBSSxvQkFBbUI7O0FBRWhFLFlBQUksQ0FBQyxLQUFLLGFBQWEsb0JBQW9CO0FBQ3ZDLGVBQUssYUFBYSxxQkFBcUIsSUFBSSxzQkFBcUI7O0FBRXBFLFlBQUksQ0FBQyxLQUFLLGFBQWEsd0JBQXdCO0FBQzNDLGVBQUssYUFBYSx5QkFBeUIsSUFBSSwwQkFBeUI7O01BRWhGO01BRUEsbUJBQWdCO0FBQ1osYUFBSyxXQUFXO0FBQ2hCLGFBQUssMkJBQTBCLEVBQUcsVUFDOUIsQ0FBQyxhQUFZO0FBQ1QsZUFBSyxXQUFXO0FBQ2hCLGVBQUssVUFBVTtBQUNmLGVBQUssZUFBZSxTQUFTLFFBQVE7QUFDckMsZUFBSyx5QkFBd0I7QUFDN0IsZUFBSyx1QkFBdUIsVUFBVSxLQUFLLFlBQVk7QUFDdkQsZUFBSyxhQUFhLFFBQVEsa0NBQWtDO1FBQ2hFLEdBQ0EsTUFBSztBQUNELGVBQUssV0FBVztBQUNoQixlQUFLLGFBQWEsTUFBTSxxQ0FBcUM7UUFDakUsQ0FBQztNQUVUO01BRUEsbUNBQWdDO0FBQzVCLGdCQUFRLEtBQUssY0FBYztVQUN2QixLQUFLLGlCQUFpQjtBQUVsQixtQkFBTyxJQUFJLFdBQVU7VUFDekIsS0FBSyxpQkFBaUI7QUFDbEIsbUJBQU8sS0FBSyxvQkFBb0Isa0JBQWlCO1VBQ3JELEtBQUssaUJBQWlCO0FBQ2xCLG1CQUFPLEtBQUssb0JBQW9CLDBCQUEwQixLQUFLLFFBQVM7O01BRXBGO01BRUEsNkJBQTBCO0FBQ3RCLGdCQUFRLEtBQUssY0FBYztVQUN2QixLQUFLLGlCQUFpQjtBQUNsQixtQkFBTyxLQUFLLG9CQUFvQixrQkFBaUI7VUFDckQsS0FBSyxpQkFBaUI7QUFDbEIsbUJBQU8sS0FBSyxvQkFBb0IsNEJBQTRCLEtBQUssUUFBUztVQUM5RSxLQUFLLGlCQUFpQjtBQUNsQixtQkFBTyxLQUFLLG9CQUFvQix5Q0FBeUMsS0FBSyxVQUFXOztNQUVyRztNQUVBLDZCQUEwQjtBQUN0QixnQkFBUSxLQUFLLGNBQWM7VUFDdkIsS0FBSyxpQkFBaUI7QUFDbEIsbUJBQU8sS0FBSyxvQkFBb0Isa0JBQWtCLEtBQUssWUFBYTtVQUN4RSxLQUFLLGlCQUFpQjtBQUNsQixtQkFBTyxLQUFLLG9CQUFvQixrQkFBa0IsS0FBSyxVQUFXLEtBQUssWUFBYTtVQUN4RixLQUFLLGlCQUFpQjtBQUNsQixtQkFBTyxLQUFLLG9CQUFvQiwrQkFBK0IsS0FBSyxZQUFhLEtBQUssWUFBYTs7TUFFL0c7O3lCQS9JUyw4QkFBMkIsZ0NBQUEsbUJBQUEsR0FBQSxnQ0FBQSxZQUFBLENBQUE7TUFBQTtpRUFBM0IsOEJBQTJCLFdBQUEsQ0FBQSxDQUFBLDBCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsY0FBQSxnQkFBQSxVQUFBLFlBQUEsWUFBQSxhQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxNQUFBLFVBQUEsR0FBQSxXQUFBLGFBQUEsUUFBQSxTQUFBLFNBQUEsR0FBQSxDQUFBLE1BQUEsUUFBQSxHQUFBLFdBQUEsYUFBQSxRQUFBLFNBQUEsU0FBQSxHQUFBLENBQUEsZ0JBQUEsbURBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxxQkFBQSxpQkFBQSxnQkFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEscUJBQUEscUJBQUEsV0FBQSxHQUFBLENBQUEsZ0JBQUEsMkNBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxJQUFBLEdBQUEsQ0FBQSxnQkFBQSxxREFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLHFCQUFBLFdBQUEsR0FBQSxDQUFBLGdCQUFBLHlEQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEscUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNqQnhDLFVBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsY0FBQSxDQUFBO0FBTUksVUFBQSx5QkFBQSxXQUFBLFNBQUEscUVBQUE7QUFBQSxtQkFBVyxJQUFBLGlCQUFBO1VBQWtCLENBQUE7QUFFakMsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsY0FBQSxDQUFBO0FBQWtJLFVBQUEseUJBQUEsV0FBQSxTQUFBLHFFQUFBO0FBQUEsbUJBQVcsSUFBQSxpQkFBQTtVQUFrQixDQUFBO0FBQUUsVUFBQSwyQkFBQTtBQUNySyxVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxvREFBQSxJQUFBLEVBQUE7OztBQVRRLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsV0FBQSxJQUFBLFVBQUEsSUFBQSxVQUFBLElBQUEsT0FBQSxFQUF1QyxhQUFBLElBQUEsU0FBQSxFQUFBLFFBQUEsSUFBQSxRQUFBLEVBQUEsU0FBQSx3Q0FBQTtBQU9yQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsSUFBQSxPQUFBLEVBQW1CLGFBQUEsSUFBQSxRQUFBLEVBQUEsUUFBQSxJQUFBLE1BQUEsRUFBQSxTQUFBLHNDQUFBO0FBRTdDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLGVBQUEsSUFBQSxFQUFBOzs7OztxRkRLYSw2QkFBMkIsRUFBQSxXQUFBLDhCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRWpCeEMsU0FBUyxhQUFBQyxZQUFXLGlCQUFpQjs7QUFBckMsSUFTYTtBQVRiOztBQUNBO0FBRUE7OztBQU1NLElBQU8sb0NBQVAsTUFBTyxtQ0FBaUM7TUFFMUM7TUFFQSxTQUFTLGlCQUFpQjtNQUUxQixnQkFBYTtBQUNULGVBQU8sS0FBSyx5QkFBeUIsY0FBYSxLQUFNO01BQzVEO01BRUEsSUFBSSx1QkFBb0I7QUFDcEIsZUFBTyxLQUFLLHlCQUF5QjtNQUN6Qzs7eUJBWlMsb0NBQWlDO01BQUE7aUVBQWpDLG9DQUFpQyxXQUFBLENBQUEsQ0FBQSxpQ0FBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLHdDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO29DQUMvQiw2QkFBMkIsQ0FBQTs7Ozs7Ozs7QUNWMUMsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUF5RCxVQUFBLHFCQUFBLEdBQUEsc0JBQUE7QUFBb0IsVUFBQSwyQkFBQTtBQUM3RSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsd0JBQUEsR0FBQSw0QkFBQSxDQUFBO0FBQ0osVUFBQSxxQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLElBQUE7OztBQUY4QixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLGdCQUFBLElBQUEsTUFBQTs7Ozs7cUZET2pCLG1DQUFpQyxFQUFBLFdBQUEsb0NBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFVDlDLFNBQVMsYUFBQUMsWUFBVyxTQUFBQyxRQUFlLGFBQUFDLGtCQUFpQjtBQUNwRCxTQUFTLHNCQUFzQjs7Ozs7QUNFdkIsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsNEJBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBRDhCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsZ0JBQUEsT0FBQSxNQUFBLEVBQXVCLFlBQUEsT0FBQSxRQUFBOzs7QURIekQsSUFVYTtBQVZiOztBQUVBO0FBRUE7OztBQU1NLElBQU8sb0NBQVAsTUFBTyxtQ0FBaUM7TUFTdEI7TUFQcEI7TUFHQTtNQUVBLFNBQVMsaUJBQWlCO01BRTFCLFlBQW9CLE9BQXFCO0FBQXJCLGFBQUEsUUFBQTtNQUF3QjtNQUU1QyxXQUFRO0FBQ0osYUFBSyxNQUFNLFFBQVEsT0FBTyxVQUFVLENBQUMsV0FBVTtBQUMzQyxlQUFLLFdBQVcsT0FBTyxPQUFPLFVBQVUsQ0FBQztRQUM3QyxDQUFDO01BQ0w7TUFFQSxnQkFBYTtBQUNULGVBQU8sS0FBSyx5QkFBeUIsY0FBYSxLQUFNO01BQzVEO01BRUEsSUFBSSx1QkFBb0I7QUFDcEIsZUFBTyxLQUFLLHlCQUF5QjtNQUN6Qzs7eUJBdkJTLG9DQUFpQyxnQ0FBQSxrQkFBQSxDQUFBO01BQUE7aUVBQWpDLG9DQUFpQyxXQUFBLENBQUEsQ0FBQSxpQ0FBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLHdDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO29DQUMvQiw2QkFBMkIsQ0FBQTs7Ozs7Ozs7QUNYMUMsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUF5RCxVQUFBLHFCQUFBLEdBQUEsc0JBQUE7QUFBb0IsVUFBQSwyQkFBQTtBQUM3RSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSwwREFBQSxHQUFBLENBQUE7QUFHSixVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLElBQUE7OztBQUpJLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLFdBQUEsSUFBQSxFQUFBOzs7OztxRkRRUyxtQ0FBaUMsRUFBQSxXQUFBLG9DQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVY5QyxTQUFTLGFBQUFDLFlBQVcsU0FBQUMsUUFBZSxhQUFBQyxrQkFBaUI7QUFJcEQsU0FBUyxrQkFBQUMsdUJBQXNCOzs7OztBQ0R2QixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSw0QkFBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7QUFEOEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxnQkFBQSxPQUFBLFFBQUEsRUFBeUIsWUFBQSxPQUFBLFFBQUEsRUFBQSxjQUFBLE9BQUEsVUFBQTs7O0FESDNELElBVWE7QUFWYjs7QUFDQTtBQUVBOzs7QUFPTSxJQUFPLHNDQUFQLE1BQU8scUNBQW1DO01BV3hCO01BVHBCO01BR087TUFFQTtNQUVQLFdBQVcsaUJBQWlCO01BRTVCLFlBQW9CLE9BQXFCO0FBQXJCLGFBQUEsUUFBQTtNQUF3QjtNQUU1QyxXQUFRO0FBQ0osYUFBSyxNQUFNLFFBQVEsT0FBTyxVQUFVLENBQUMsV0FBVTtBQUMzQyxlQUFLLFdBQVcsT0FBTyxPQUFPLFVBQVUsQ0FBQztBQUN6QyxlQUFLLGFBQWEsT0FBTyxPQUFPLFlBQVksQ0FBQztRQUNqRCxDQUFDO01BQ0w7TUFFQSxnQkFBYTtBQUNULGVBQU8sS0FBSyx5QkFBeUIsY0FBYSxLQUFNO01BQzVEO01BRUEsSUFBSSx1QkFBb0I7QUFDcEIsZUFBTyxLQUFLLHlCQUF5QjtNQUN6Qzs7eUJBMUJTLHNDQUFtQyxnQ0FBQSxrQkFBQSxDQUFBO01BQUE7aUVBQW5DLHNDQUFtQyxXQUFBLENBQUEsQ0FBQSxtQ0FBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLDBDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO29DQUNqQyw2QkFBMkIsQ0FBQTs7Ozs7Ozs7QUNYMUMsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUEyRCxVQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBc0IsVUFBQSwyQkFBQTtBQUNqRixVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSw0REFBQSxHQUFBLENBQUE7QUFHSixVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLElBQUE7OztBQUpJLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLFlBQUEsSUFBQSxhQUFBLElBQUEsRUFBQTs7Ozs7cUZEUVMscUNBQW1DLEVBQUEsV0FBQSxzQ0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVWaEQsSUFBWSxxQkEyQk4sWUFxQk87QUFoRGI7O0FBQUEsS0FBQSxTQUFZQyxzQkFBbUI7QUFDM0IsTUFBQUEscUJBQUEscUJBQUEsSUFBQTtBQUNBLE1BQUFBLHFCQUFBLHFCQUFBLElBQUE7QUFDQSxNQUFBQSxxQkFBQSxxQkFBQSxJQUFBO0FBQ0EsTUFBQUEscUJBQUEsdUJBQUEsSUFBQTtBQUNBLE1BQUFBLHFCQUFBLHlCQUFBLElBQUE7QUFDQSxNQUFBQSxxQkFBQSxxQkFBQSxJQUFBO0FBQ0EsTUFBQUEscUJBQUEsZUFBQSxJQUFBO0FBQ0EsTUFBQUEscUJBQUEsOEJBQUEsSUFBQTtBQUNBLE1BQUFBLHFCQUFBLGVBQUEsSUFBQTtBQUNBLE1BQUFBLHFCQUFBLFdBQUEsSUFBQTtBQUNBLE1BQUFBLHFCQUFBLHNCQUFBLElBQUE7QUFDQSxNQUFBQSxxQkFBQSxrQkFBQSxJQUFBO0FBQ0EsTUFBQUEscUJBQUEsb0JBQUEsSUFBQTtBQUNBLE1BQUFBLHFCQUFBLGFBQUEsSUFBQTtBQUNBLE1BQUFBLHFCQUFBLGdCQUFBLElBQUE7QUFDQSxNQUFBQSxxQkFBQSwwQkFBQSxJQUFBO0FBQ0EsTUFBQUEscUJBQUEsb0JBQUEsSUFBQTtBQUNBLE1BQUFBLHFCQUFBLHFCQUFBLElBQUE7SUFDSixHQW5CWSx3QkFBQSxzQkFBbUIsQ0FBQSxFQUFBO0FBMkIvQixJQUFNLGFBQThCO01BQ2hDLEVBQUUsS0FBSyxvQkFBb0IscUJBQXFCLE9BQU8sS0FBSTtNQUMzRCxFQUFFLEtBQUssb0JBQW9CLHFCQUFxQixPQUFPLE1BQUs7TUFDNUQsRUFBRSxLQUFLLG9CQUFvQixxQkFBcUIsT0FBTyxLQUFJO01BQzNELEVBQUUsS0FBSyxvQkFBb0IsdUJBQXVCLE9BQU8sS0FBSTtNQUM3RCxFQUFFLEtBQUssb0JBQW9CLHlCQUF5QixPQUFPLEtBQUk7TUFDL0QsRUFBRSxLQUFLLG9CQUFvQixxQkFBcUIsT0FBTyxNQUFLO01BQzVELEVBQUUsS0FBSyxvQkFBb0IsZUFBZSxPQUFPLEtBQUk7TUFDckQsRUFBRSxLQUFLLG9CQUFvQiw4QkFBOEIsT0FBTyxNQUFLO01BQ3JFLEVBQUUsS0FBSyxvQkFBb0IsZUFBZSxPQUFPLE1BQUs7TUFDdEQsRUFBRSxLQUFLLG9CQUFvQixzQkFBc0IsT0FBTyxLQUFJO01BQzVELEVBQUUsS0FBSyxvQkFBb0Isa0JBQWtCLE9BQU8sS0FBSTtNQUN4RCxFQUFFLEtBQUssb0JBQW9CLG9CQUFvQixPQUFPLEtBQUk7TUFDMUQsRUFBRSxLQUFLLG9CQUFvQixhQUFhLE9BQU8sS0FBSTtNQUNuRCxFQUFFLEtBQUssb0JBQW9CLGdCQUFnQixPQUFPLEtBQUk7TUFDdEQsRUFBRSxLQUFLLG9CQUFvQixXQUFXLE9BQU8sS0FBSTtNQUNqRCxFQUFFLEtBQUssb0JBQW9CLDBCQUEwQixPQUFPLEtBQUk7TUFDaEUsRUFBRSxLQUFLLG9CQUFvQixvQkFBb0IsT0FBTyxLQUFJO01BQzFELEVBQUUsS0FBSyxvQkFBb0IscUJBQXFCLE9BQU8sS0FBSTs7QUFHeEQsSUFBTSxnQkFBMkUsT0FBTyxPQUMzRixXQUFXLE9BQ1AsQ0FBQ0MsTUFBSyxRQUFPO0FBQ1QsTUFBQUEsS0FBSSxJQUFJLEdBQUcsSUFBSTtBQUNmLGFBQU9BO0lBQ1gsR0FDQSxDQUFBLENBQXFELENBQ3hEOzs7OztBQzhDQyxTQUFVLDRCQUE0QixRQUEwQjtBQUNsRSxTQUFPLE9BQU8sU0FBUyxXQUFXO0FBQ3RDO0FBRU0sU0FBVSw2QkFBNkIsUUFBMEI7QUFDbkUsU0FBTyxPQUFPLFNBQVMsV0FBVztBQUN0QztBQUVNLFNBQVUsd0NBQXdDLFFBQTBCO0FBQzlFLFNBQU8sT0FBTyxTQUFTLFdBQVc7QUFDdEM7QUFFTSxTQUFVLGtDQUFrQyxRQUEwQjtBQUN4RSxTQUFPLE9BQU8sU0FBUyxXQUFXO0FBQ3RDO0FBRU0sU0FBVSwyQkFBMkIsUUFBMEI7QUFDakUsU0FBTyxPQUFPLFNBQVMsV0FBVztBQUN0QztBQUVNLFNBQVUsd0JBQXdCLFFBQTBCO0FBQzlELFNBQU8sT0FBTyxTQUFTLFdBQVc7QUFDdEM7QUFFTSxTQUFVLDJCQUEyQixRQUEwQjtBQUNqRSxTQUFPLE9BQU8sU0FBUyxXQUFXO0FBQ3RDO0FBRU0sU0FBVSx5QkFBeUIsUUFBMEI7QUFDL0QsU0FBTyxPQUFPLFNBQVMsV0FBVztBQUN0QztBQWxJQSxJQUdZLFlBZUMsMkJBZ0JBLHVDQVFBLGlDQWlCQSwwQkFXQSx1QkFXQSwwQkFXQTtBQTVGYjs7O0FBR0EsS0FBQSxTQUFZQyxhQUFVO0FBQ2xCLE1BQUFBLFlBQUEsd0JBQUEsSUFBQTtBQUNBLE1BQUFBLFlBQUEsd0JBQUEsSUFBQTtBQUNBLE1BQUFBLFlBQUEsb0NBQUEsSUFBQTtBQUNBLE1BQUFBLFlBQUEsNkJBQUEsSUFBQTtBQUNBLE1BQUFBLFlBQUEsc0JBQUEsSUFBQTtBQUNBLE1BQUFBLFlBQUEsaUJBQUEsSUFBQTtBQUNBLE1BQUFBLFlBQUEsc0JBQUEsSUFBQTtBQUNBLE1BQUFBLFlBQUEsb0JBQUEsSUFBQTtJQUNKLEdBVFksZUFBQSxhQUFVLENBQUEsRUFBQTtBQWVoQixJQUFPLDRCQUFQLE1BQWdDO01BQ3pCO01BRVQsY0FBQTtBQUNJLGFBQUssT0FBTyxXQUFXO01BQzNCOztBQVdFLElBQU8sd0NBQVAsTUFBNEM7TUFHWDtNQUYxQjtNQUVULFlBQW1DLFNBQW9CO0FBQXBCLGFBQUEsVUFBQTtBQUMvQixhQUFLLE9BQU8sV0FBVztNQUMzQjs7QUFHRSxJQUFPLGtDQUFQLE1BQU8saUNBQStCO01BQy9CO01BQ0E7TUFFVCxZQUFZLFdBQXVDLFlBQTBDLFFBQVM7QUFDbEcsYUFBSyxPQUFPLFdBQVc7QUFDdkIsYUFBSyxjQUFjLGlDQUFnQyxpQkFBaUIsV0FBVyxTQUFTO01BQzVGO01BRVEsT0FBTyxpQkFBaUIsV0FBdUMsV0FBNEI7QUFDL0YsWUFBSSxDQUFDO0FBQVcsaUJBQU87QUFDdkIsY0FBTSxjQUFjLGNBQWMsU0FBUztBQUMzQyxvQkFBWSxZQUFZO0FBQ3hCLGVBQU87TUFDWDs7QUFHRSxJQUFPLDJCQUFQLE1BQStCO01BSWI7TUFDQTtNQUpYO01BRVQsWUFDb0IsU0FDQSxZQUFrRCxNQUFJO0FBRHRELGFBQUEsVUFBQTtBQUNBLGFBQUEsWUFBQTtBQUVoQixhQUFLLE9BQU8sV0FBVztNQUMzQjs7QUFHRSxJQUFPLHdCQUFQLE1BQTRCO01BSVY7TUFDQTtNQUpYO01BRVQsWUFDb0IsV0FDQSxVQUFvQztBQURwQyxhQUFBLFlBQUE7QUFDQSxhQUFBLFdBQUE7QUFFaEIsYUFBSyxPQUFPLFdBQVc7TUFDM0I7O0FBR0UsSUFBTywyQkFBUCxNQUErQjtNQUliO01BQ0E7TUFKWDtNQUVULFlBQ29CLE9BQ0EsU0FBZ0I7QUFEaEIsYUFBQSxRQUFBO0FBQ0EsYUFBQSxVQUFBO0FBRWhCLGFBQUssT0FBTyxXQUFXO01BQzNCOztBQUdFLElBQU8seUJBQVAsTUFBNkI7TUFHSTtNQUYxQjtNQUVULFlBQW1DLGVBQXVDO0FBQXZDLGFBQUEsZ0JBQUE7QUFDL0IsYUFBSyxPQUFPLFdBQVc7TUFDM0I7Ozs7OztBQ3pERSxTQUFVLG9CQUFvQixTQUFvQjtBQUNwRCxTQUFPLFFBQVEsV0FBVyxXQUFXLGtCQUFrQixRQUFRLFdBQVcsV0FBVztBQUN6RjtBQU9NLFNBQVUsMkJBQTJCLFNBQW9CO0FBQzNELFNBQU8sUUFBUSxXQUFXLFdBQVc7QUFDekM7QUFPTSxTQUFVLHFCQUFxQixTQUFvQjtBQUNyRCxTQUFPLFFBQVEsV0FBVyxXQUFXO0FBQ3pDO0FBekRBLElBQVk7QUFBWjs7QUFBQSxLQUFBLFNBQVlDLGFBQVU7QUFDbEIsTUFBQUEsWUFBQSxLQUFBLElBQUE7QUFDQSxNQUFBQSxZQUFBLE1BQUEsSUFBQTtBQUNBLE1BQUFBLFlBQUEsZ0JBQUEsSUFBQTtBQUNBLE1BQUFBLFlBQUEsZ0JBQUEsSUFBQTtJQUNKLEdBTFksZUFBQSxhQUFVLENBQUEsRUFBQTs7Ozs7QUNKdEIsU0FBUyxrQkFBNkI7QUFDdEMsU0FBUyxpQkFBNkIsZUFBNkI7QUFDbkUsU0FBUyxLQUFLLFdBQVc7O0FBRnpCLElBK0JhO0FBL0JiOztBQUdBO0FBbUJBO0FBQ0E7QUFRTSxJQUFPLGlCQUFQLE1BQU8sZ0JBQWM7TUFDTixlQUFrQztRQUMvQyxVQUFVLENBQUE7UUFDVixXQUFXO1FBQ1gsV0FBVztRQUNYLGdCQUFnQjtRQUNoQixPQUFPO1FBQ1AsdUJBQXVCO1FBQ3ZCLHFCQUFxQjtRQUNyQixXQUFXO1FBQ1gseUJBQXlCOztNQUdaLFNBQVMsSUFBSSxRQUFPO01BQ3BCLFFBQVEsSUFBSSxnQkFBbUMsS0FBSyxZQUFZO01BQ2hFO01BRWpCLGNBQUE7QUFDSSxhQUFLLGVBQWUsS0FBSyxPQUNwQixLQUNHLElBQUksQ0FBQyxxQkFBc0M7QUFDdkMsZ0JBQU0sV0FBVyxnQkFBZSxhQUFhLEtBQUssTUFBTSxTQUFRLEdBQUksaUJBQWlCLE1BQU07QUFDM0YsZUFBSyxNQUFNLEtBQUssUUFBUTtBQUN4QixjQUFJLFNBQVMsT0FBTztBQUNoQiw2QkFBaUIsT0FBTyxTQUFTLEtBQUs7aUJBQ25DO0FBQ0gsNkJBQWlCLFFBQU87O1FBRWhDLENBQUMsQ0FBQyxFQUVMLFVBQVM7TUFDbEI7TUFFQSxjQUFXO0FBQ1AsYUFBSyxhQUFhLFlBQVc7QUFDN0IsYUFBSyxNQUFNLFNBQVE7QUFDbkIsYUFBSyxPQUFPLFNBQVE7TUFDeEI7TUFPQSxnQkFBZ0IsUUFBMEI7QUFDdEMsZUFBTyxJQUFJLFFBQWMsQ0FBQyxTQUFTLFdBQVU7QUFDekMsZUFBSyxPQUFPLEtBQUs7WUFDYjtZQUNBO1lBQ0E7V0FDSDtRQUNMLENBQUM7TUFDTDtNQU9BLFNBQVMsUUFBMEI7QUFDL0IsYUFBSyxPQUFPLEtBQUs7VUFDYjtVQUNBLFNBQVMsTUFBSztVQUFFO1VBQ2hCLFFBQVEsTUFBSztVQUFFO1NBQ2xCO01BQ0w7TUFNQSxXQUFRO0FBQ0osZUFBTyxLQUFLLE1BQU0sYUFBWTtNQUNsQztNQU1BLHNCQUFtQjtBQUNmLGVBQU8sS0FBSyxPQUFPLGFBQVksRUFBRyxLQUFLLElBQUksQ0FBQyxxQkFBdUMsaUJBQWlCLE1BQU0sQ0FBQztNQUMvRztNQUdRLE9BQU8sZ0JBQWdCLEdBQVE7TUFFdkM7TUFFUSxPQUFPLGFBQWFDLFFBQTBCLFFBQTBCO0FBQzVFLGNBQU0sZUFBcUNBLE9BQU0sU0FBUyxRQUFRQSxPQUFNLE1BQU0sUUFBUUEsT0FBTSxRQUFRO0FBRXBHLFlBQUlBLE9BQU0sYUFBYSxRQUFRLEVBQUUsd0JBQXdCLE1BQU0sS0FBSyxrQ0FBa0MsTUFBTSxJQUFJO0FBQzVHLGlCQUFPLGlDQUNBQSxTQURBO1lBRUgsV0FBVztZQUNYLE9BQU8sY0FBYyxvQkFBb0IscUJBQXFCO1lBQzlELHVCQUF1Qjs7O0FBRy9CLFlBQUksNEJBQTRCLE1BQU0sR0FBRztBQUNyQyxpQkFBTyxpQ0FDQUEsU0FEQTtZQUVILGdCQUFnQjs7O0FBR3hCLFlBQUksNkJBQTZCLE1BQU0sR0FBRztBQUN0QyxnQkFBTSxlQUFlO0FBQ3JCLGlCQUFPLGlDQUNBQSxTQURBO1lBRUgsVUFBVSxDQUFDLEdBQUdBLE9BQU0sVUFBVSxhQUFhLE9BQU87WUFDbEQsV0FBVztZQUNYLE9BQU87WUFDUCx1QkFBdUI7OztBQUcvQixZQUFJLHdDQUF3QyxNQUFNLEdBQUc7QUFDakQsZ0JBQU0sZUFBZTtBQUNyQixjQUFJQSxPQUFNLDBCQUEwQixNQUFNO0FBQ3RDLHlCQUFhQSxPQUFNLHFCQUFxQjs7QUFFNUMsaUJBQU87WUFDSCxVQUFVLENBQUMsR0FBR0EsT0FBTSxVQUFVLGFBQWEsT0FBTztZQUNsRCxXQUFXQSxPQUFNO1lBQ2pCLFdBQVc7WUFDWCxnQkFBZ0JBLE9BQU0saUJBQWlCO1lBQ3ZDLE9BQU87WUFDUCx1QkFBdUI7WUFDdkIscUJBQXFCQSxPQUFNO1lBQzNCLFdBQVdBLE9BQU07WUFDakIseUJBQXlCQSxPQUFNOzs7QUFHdkMsWUFBSSxrQ0FBa0MsTUFBTSxHQUFHO0FBQzNDLGdCQUFNLGVBQWU7QUFDckIsY0FBSUEsT0FBTSwwQkFBMEIsU0FBUyxhQUFhLGFBQWEsU0FBUyxhQUFhLGFBQWEsUUFBUSxvQkFBb0Isc0JBQXNCO0FBQ3hKLHlCQUFhQSxPQUFNLHFCQUFxQjtBQUN4QyxZQUFBQSxPQUFNLHdCQUF3Qjs7QUFFbEMsaUJBQU8saUNBQ0FBLFNBREE7WUFFSCxXQUFXO1lBQ1gsT0FBTyxhQUFhOzs7QUFHNUIsWUFBSSx3QkFBd0IsTUFBTSxHQUFHO0FBQ2pDLGdCQUFNLGVBQWU7QUFDckIsaUJBQU8saUNBQ0FBLFNBREE7WUFFSCxVQUFVLGFBQWE7WUFDdkIsV0FBVyxhQUFhO1lBQ3hCLE9BQU87WUFDUCx1QkFBdUI7OztBQUcvQixZQUFJLDJCQUEyQixNQUFNLEdBQUc7QUFDcEMsZ0JBQU0sZUFBZTtBQUNyQixjQUFJLGFBQWE7QUFDakIsY0FBSSxhQUFhLFFBQVEsMEJBQTBCLFFBQVc7QUFDMUQscUJBQVMsSUFBSUEsT0FBTSxTQUFTLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztBQUNqRCxvQkFBTSxVQUFVQSxPQUFNLFNBQVMsQ0FBQztBQUNoQyxrQkFBSSxDQUFDLHFCQUFxQixPQUFPO0FBQUc7QUFDcEMsa0JBQUksUUFBUSwwQkFBMEI7QUFBVztBQUNqRCxrQkFBSSxRQUFRLDBCQUEwQixhQUFhLFFBQVEsdUJBQXVCO0FBQzlFLDZCQUFhOzs7O0FBSXpCLGNBQUksQ0FBQyxZQUFZO0FBQ2IsZ0JBQUksYUFBYSxjQUFjLE1BQU07QUFDakMsMkJBQWEsYUFBYSxTQUFTOztBQUV2QyxtQkFBTyxpQ0FDQUEsU0FEQTtjQUVILFdBQVc7Y0FDWCxPQUFPLGFBQWEsUUFBUSxPQUFPLFNBQVksZUFBZTs7O0FBR3RFLGlCQUFPLGlDQUNBQSxTQURBO1lBRUgsVUFBVSxDQUFDLEdBQUdBLE9BQU0sVUFBVSxhQUFhLE9BQU87WUFDbEQsV0FBVztZQUNYLE9BQU87WUFDUCx1QkFBdUIsYUFBYTs7O0FBRzVDLFlBQUksMkJBQTJCLE1BQU0sR0FBRztBQUNwQyxnQkFBTSxlQUFlO0FBQ3JCLGdCQUFNLGNBQWNBLE9BQU07QUFDMUIsY0FBSSxhQUFhLFFBQVFBLE9BQU0sU0FBUyxRQUFRO0FBQzNDLHdCQUFZLGFBQWEsS0FBSyxFQUF3QixVQUFVLGFBQWE7QUFDOUUsbUJBQU8saUNBQ0FBLFNBREE7Y0FFSCxVQUFVOzs7QUFJbEIsaUJBQU9BOztBQUVYLFlBQUkseUJBQXlCLE1BQU0sR0FBRztBQUNsQyxnQkFBTSxlQUFlO0FBQ3JCLGdCQUFNLGdCQUFnQixhQUFhO0FBQ25DLGNBQUksZUFBcUM7QUFDekMsY0FBSSxjQUFjLGFBQWEsS0FBSyxjQUFjLHVCQUF1QixjQUFjLFdBQVc7QUFDOUYsMkJBQWUsY0FBYyxvQkFBb0IsbUJBQW1CO0FBQ3BFLHlCQUFhLFlBQVksb0JBQUksSUFBRztBQUNoQyx5QkFBYSxVQUFVLElBQUksU0FBUyxjQUFjLHVCQUF1Qjs7QUFFN0UsaUJBQU8saUNBQ0FBLFNBREE7WUFFSCxPQUFPO1lBQ1AscUJBQXFCLGNBQWM7WUFDbkMsV0FBVyxjQUFjO1lBQ3pCLHlCQUF5QixjQUFjOzs7QUFJL0Msd0JBQWUsZ0JBQWdCLE1BQU07QUFDckMsZUFBT0E7TUFDWDs7eUJBMU5TLGlCQUFjO01BQUE7cUVBQWQsaUJBQWMsU0FBZCxnQkFBYyxVQUFBLENBQUE7Ozs7OztBQy9CM0IsU0FBUyxjQUFBQyxtQkFBa0I7QUFDM0IsU0FBUyxtQkFBQUMsd0JBQXVCOztBQURoQyxJQU1hO0FBTmI7O0FBTU0sSUFBTyxnQkFBUCxNQUFPLGVBQWE7TUFDZCxpQkFBaUIsSUFBSUEsaUJBQXlCLEtBQUs7TUFDM0QsV0FBVyxLQUFLLGVBQWUsYUFBWTtNQUUzQyxxQkFBcUIsUUFBZTtBQUNoQyxhQUFLLGVBQWUsS0FBSyxNQUFNO01BQ25DOzt5QkFOUyxnQkFBYTtNQUFBO3FFQUFiLGdCQUFhLFNBQWIsZUFBYSxXQUFBLFlBRlYsT0FBTSxDQUFBOzs7Ozs7QUMrQmhCLFNBQVUsY0FBYyxNQUEwQjtBQUNwRCxTQUFPLEtBQUssbUJBQW1CLGVBQWU7QUFDbEQ7QUFFTSxTQUFVLGFBQWEsTUFBMEI7QUFDbkQsU0FBTyxLQUFLLG1CQUFtQixlQUFlO0FBQ2xEO0FBRU0sU0FBVSxTQUFTLE1BQTBCO0FBQy9DLFNBQU8sS0FBSyxtQkFBbUIsZUFBZTtBQUNsRDtBQUVNLFNBQVUsV0FBVyxNQUEwQjtBQUNqRCxTQUFPLEtBQUssbUJBQW1CLGVBQWU7QUFDbEQ7QUFFTSxTQUFVLGFBQWEsTUFBMEI7QUFDbkQsT0FBSyxTQUFTLENBQUMsU0FBUyxJQUFJO0FBQ2hDO0FBRU0sU0FBVSxTQUFTLE1BQTBCO0FBQy9DLE1BQUksS0FBSyxXQUFXLFFBQVc7QUFFM0IsU0FBSyxTQUFTOztBQUVsQixTQUFPLEtBQUs7QUFDaEI7QUFnQk0sU0FBVSxjQUFjLFNBQTJCO0FBQ3JELFNBQU8sUUFBUSxTQUFTLHVCQUF1QjtBQUNuRDtBQUVNLFNBQVUsZUFBZSxTQUEyQjtBQUN0RCxNQUFJLGNBQWMsT0FBTyxHQUFHO0FBQ3hCLFVBQU0seUJBQXlCO0FBQy9CLFdBQU8sdUJBQXVCOztBQUV0QztBQUVNLFNBQVUsZUFBZSxTQUEyQjtBQUN0RCxTQUFPLFFBQVEsU0FBUyx1QkFBdUI7QUFDbkQ7QUExRkEsSUFBWSx3QkFLVSxvQkFPVCx3QkFtREQsbUJBT0E7QUF0RVo7O0FBQUEsS0FBQSxTQUFZQyx5QkFBc0I7QUFDOUIsTUFBQUEsd0JBQUEsTUFBQSxJQUFBO0FBQ0EsTUFBQUEsd0JBQUEsZUFBQSxJQUFBO0lBQ0osR0FIWSwyQkFBQSx5QkFBc0IsQ0FBQSxFQUFBO0FBSzVCLElBQWdCLHFCQUFoQixNQUFrQztNQUlQO01BSDdCO01BQ0E7TUFFQSxZQUE2QixNQUE0QjtBQUE1QixhQUFBLE9BQUE7TUFBK0I7O0FBRzFELElBQU8seUJBQVAsY0FBc0MsbUJBQWtCO01BQ3ZDO01BQW5CLFlBQW1CLGFBQW1CO0FBQ2xDLGNBQU0sdUJBQXVCLElBQUk7QUFEbEIsYUFBQSxjQUFBO01BRW5COztBQWdESixLQUFBLFNBQVlDLG9CQUFpQjtBQUN6QixNQUFBQSxtQkFBQSxtQkFBQSxJQUFBO0FBQ0EsTUFBQUEsbUJBQUEscUJBQUEsSUFBQTtBQUNBLE1BQUFBLG1CQUFBLHFCQUFBLElBQUE7QUFDQSxNQUFBQSxtQkFBQSxpQkFBQSxJQUFBO0lBQ0osR0FMWSxzQkFBQSxvQkFBaUIsQ0FBQSxFQUFBO0FBTzdCLEtBQUEsU0FBWUMsaUJBQWM7QUFDdEIsTUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsTUFBQUEsZ0JBQUEsYUFBQSxJQUFBO0FBQ0EsTUFBQUEsZ0JBQUEsUUFBQSxJQUFBO0FBQ0EsTUFBQUEsZ0JBQUEsVUFBQSxJQUFBO0lBQ0osR0FMWSxtQkFBQSxpQkFBYyxDQUFBLEVBQUE7Ozs7O0FDdEUxQixTQUFTLGNBQUFDLG1CQUFrQjtBQUMzQixTQUFTLGtCQUFnQzs7QUFEekMsSUFZc0I7QUFadEI7O0FBWU0sSUFBZ0IseUJBQWhCLE1BQWdCLHdCQUFzQjtNQUkxQjtNQUNBO01BSkosWUFBWTtNQUV0QixZQUNjLE1BQ0EsYUFBbUI7QUFEbkIsYUFBQSxPQUFBO0FBQ0EsYUFBQSxjQUFBO01BQ1g7TUFPSCxrQkFBa0IsWUFBa0I7QUFDaEMsZUFBTyxLQUFLLEtBQUssSUFBaUIsR0FBRyxLQUFLLFNBQVMsMEJBQTBCLFVBQVUsSUFBSSxLQUFLLFdBQVcsWUFBWSxFQUFFLFNBQVMsV0FBVSxDQUFFO01BQ2xKO01BT0EsY0FBYyxZQUFrQjtBQUM1QixlQUFPLEtBQUssS0FBSyxLQUFZLEdBQUcsS0FBSyxTQUFTLDBCQUEwQixVQUFVLElBQUksS0FBSyxXQUFXLElBQUksQ0FBQSxDQUFFO01BQ2hIOzs7O3FFQXhCa0IseUJBQXNCLFNBQXRCLHdCQUFzQixXQUFBLFlBRGxCLE9BQU0sQ0FBQTs7Ozs7O0FDWGhDLFNBQVMsY0FBQUMsbUJBQWtCO0FBQzNCLFNBQVMsY0FBQUMsbUJBQWdDO0FBSXpDLFNBQVMsT0FBQUMsTUFBSyxPQUFBQyxZQUFXOzs7QUFMekIsSUFhc0I7QUFidEI7O0FBSUE7QUFTTSxJQUFnQix5QkFBaEIsTUFBZ0Isd0JBQXNCO01BR1I7TUFGdEIsWUFBb0I7TUFFOUIsWUFBZ0MsWUFBc0I7QUFBdEIsYUFBQSxhQUFBO01BQXlCO01BRS9DLFlBQVM7QUFDZixjQUFNLGFBQWE7QUFDbkIsZUFBTyxLQUFLLE1BQU0sS0FBSyxPQUFNLElBQUssVUFBVTtNQUNoRDtNQU9BLFlBQVksV0FBaUI7QUFDekIsZUFBTyxLQUFLLFdBQVcsSUFBbUIsR0FBRyxLQUFLLFNBQVMsYUFBYSxTQUFTLGFBQWEsRUFBRSxTQUFTLFdBQVUsQ0FBRSxFQUFFLEtBQ25IRCxLQUFJLENBQUMsYUFBWTtBQUNiLGdCQUFNLFdBQVcsU0FBUztBQUMxQixjQUFJLENBQUM7QUFBVSxtQkFBTztBQUV0QixnQkFBTSxtQkFBbUIsU0FBUyxJQUFJLENBQUMsWUFBVztBQUM5QyxtQkFBTyxPQUFPLE9BQU8sQ0FBQSxHQUFJLFNBQVM7Y0FDOUIsUUFBUSxzQkFBc0IsUUFBUSxNQUFNO2FBQy9DO1VBQ0wsQ0FBQztBQUVELGlCQUFPLE9BQU8sT0FBTyxDQUFBLEdBQUksVUFBVTtZQUMvQixNQUFNO1dBQ1Q7UUFDTCxDQUFDLENBQUM7TUFFVjtNQU9BLGNBQWMsV0FBbUIsU0FBd0I7QUFDckQsZ0JBQVEsd0JBQXdCLEtBQUssVUFBUztBQUM5QyxlQUFPLEtBQUssV0FDUCxLQUNHLEdBQUcsS0FBSyxTQUFTLGFBQWEsU0FBUyxhQUN2QyxPQUFPLE9BQU8sQ0FBQSxHQUFJLFNBQVM7VUFDdkIsUUFBUSxzQkFBc0IsUUFBUSxNQUFNO1NBQy9DLEdBQ0QsRUFBRSxTQUFTLFdBQVUsQ0FBRSxFQUUxQixLQUNHQyxLQUFJLENBQUMsYUFBWTtBQUNiLGNBQUksU0FBUyxRQUFRLFNBQVMsS0FBSyxJQUFJO0FBQ25DLG9CQUFRLEtBQUssU0FBUyxLQUFLOztRQUVuQyxDQUFDLENBQUM7TUFFZDtNQVFBLGNBQWMsV0FBbUIsU0FBd0I7QUFDckQsZ0JBQVEsd0JBQXdCLFFBQVEseUJBQXlCLEtBQUssVUFBUztBQUMvRSxlQUFPLEtBQUssV0FBVyxLQUF3QixHQUFHLEtBQUssU0FBUyxhQUFhLFNBQVMsYUFBYSxRQUFRLEVBQUUsV0FBVyxNQUFNLEVBQUUsU0FBUyxXQUFVLENBQUUsRUFBRSxLQUNuSkEsS0FBSSxDQUFDLGFBQVk7QUFDYixjQUFJLFNBQVMsUUFBUSxTQUFTLEtBQUssSUFBSTtBQUNuQyxvQkFBUSxLQUFLLFNBQVMsS0FBSzs7UUFFbkMsQ0FBQyxDQUFDO01BRVY7TUFTQSxZQUFZLFdBQW1CLFdBQW1CLFNBQWdCO0FBQzlELGVBQU8sS0FBSyxXQUFXLElBQWlCLEdBQUcsS0FBSyxTQUFTLGFBQWEsU0FBUyxhQUFhLFNBQVMsWUFBWSxPQUFPLElBQUksTUFBTSxFQUFFLFNBQVMsV0FBVSxDQUFFO01BQzdKOzt5QkFwRmtCLHlCQUFzQix3QkFBQSxjQUFBLENBQUE7TUFBQTtxRUFBdEIseUJBQXNCLFNBQXRCLHdCQUFzQixXQUFBLFlBRGxCLE9BQU0sQ0FBQTs7Ozs7O0FDWmhDLFNBQVMsY0FBQUMsbUJBQWtCO0FBUzNCLFNBQVMsc0JBQXNCOztBQVQvQixJQWVzQjtBQWZ0Qjs7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUVBOzs7O0FBT00sSUFBZ0IscUJBQWhCLE1BQWdCLG9CQUFrQjtNQVFiO01BQ1o7TUFDQTtNQUhYLFlBQ3VCLFlBQ1osb0JBQ0Esb0JBQTBDO0FBRjlCLGFBQUEsYUFBQTtBQUNaLGFBQUEscUJBQUE7QUFDQSxhQUFBLHFCQUFBO01BQ1I7TUFNSCwwQkFBMEIsWUFBa0I7QUFDeEMsWUFBSTtBQUVKLHVCQUFlLEtBQUssbUJBQW1CLGtCQUFrQixVQUFVLENBQUMsRUFDL0QsS0FBSyxDQUFDLHdCQUFrRDtBQUNyRCxzQkFBWSxvQkFBb0IsS0FBTTtBQUN0QyxpQkFBTyxlQUFlLEtBQUssbUJBQW1CLFlBQVksU0FBUyxDQUFDLEVBQy9ELEtBQUssQ0FBQyxxQkFBaUQ7QUFDcEQsa0JBQU0sV0FBVyxpQkFBaUI7QUFDbEMscUJBQVMsS0FBSyxDQUFDLEdBQUcsTUFBSztBQUNuQixrQkFBSSxFQUFFLFVBQVUsRUFBRSxRQUFRO0FBQ3RCLG9CQUFJLEVBQUUsV0FBVyxFQUFFO0FBQVEseUJBQU87QUFDbEMsdUJBQU8sRUFBRSxPQUFPLFNBQVMsRUFBRSxNQUFNLElBQUksS0FBSzs7QUFFOUMscUJBQU87WUFDWCxDQUFDO0FBQ0QsaUJBQUssZ0JBQWdCLFdBQVcsUUFBUTtVQUM1QyxDQUFDLEVBQ0EsTUFBTSxNQUFLO0FBQ1IsaUJBQUssY0FBYyxvQkFBb0IsbUJBQW1CO1VBQzlELENBQUM7UUFDVCxDQUFDLEVBQ0EsTUFBTSxDQUFDLFVBQTRCO0FBQ2hDLGNBQUksTUFBTSxVQUFVLEtBQUs7QUFDckIsbUJBQU8sS0FBSyxpQkFBaUIsVUFBVTtpQkFDcEM7QUFDSCxpQkFBSyxjQUFjLG9CQUFvQixtQkFBbUI7O1FBRWxFLENBQUM7TUFDVDtNQU1BLGlCQUFpQixZQUFrQjtBQUMvQixhQUFLLG1CQUFtQixjQUFjLFVBQVUsRUFBRSxVQUFVO1VBQ3hELE1BQU0sQ0FBQyx3QkFBb0M7QUFDdkMsaUJBQUssZ0JBQWdCLG9CQUFvQixJQUFJLENBQUEsQ0FBRTtVQUNuRDtVQUNBLE9BQU8sTUFBTSxLQUFLLGNBQWMsb0JBQW9CLHVCQUF1QjtTQUc5RTtNQUNMO01BT00sWUFBWSxXQUFtQixTQUF3Qjs7QUFDekQsZ0JBQU0sV0FBVyxNQUFNLGVBQWUsS0FBSyxtQkFBbUIsY0FBYyxXQUFXLE9BQU8sQ0FBQztBQUMvRixpQkFBTyxTQUFTO1FBQ3BCOztNQU9NLGNBQWMsV0FBbUIsU0FBd0I7O0FBQzNELGdCQUFNLFdBQVcsTUFBTSxlQUFlLEtBQUssbUJBQW1CLGNBQWMsV0FBVyxPQUFPLENBQUM7QUFDL0YsaUJBQU8sU0FBUztRQUNwQjs7TUFFTSxZQUFZLFdBQW1CLFdBQW1CLFNBQWdCOztBQUNwRSxnQkFBTSxXQUFXLE1BQU0sZUFBZSxLQUFLLG1CQUFtQixZQUFZLFdBQVcsV0FBVyxPQUFPLENBQUM7QUFDeEcsaUJBQU8sU0FBUztRQUNwQjs7TUFFUSxnQkFBZ0IsV0FBbUIsVUFBdUI7QUFDOUQsYUFBSyxXQUFXLFNBQVMsSUFBSSxzQkFBc0IsV0FBVyxRQUFRLENBQUM7TUFDM0U7TUFNUSxjQUFjLE9BQTBCO0FBQzVDLGFBQUssV0FBVyxTQUFTLElBQUksZ0NBQWdDLEtBQUssQ0FBQztNQUN2RTs7eUJBbEdrQixxQkFBa0Isd0JBQUEsY0FBQSxHQUFBLHdCQUFBLHNCQUFBLEdBQUEsd0JBQUEsc0JBQUEsQ0FBQTtNQUFBO3FFQUFsQixxQkFBa0IsU0FBbEIsb0JBQWtCLFVBQUEsQ0FBQTs7Ozs7O0FDZnhDLFNBQVMsY0FBQUMsbUJBQWtCOztBQUEzQixJQUlhO0FBSmI7O0FBQ0E7QUFHTSxJQUFPLDZCQUFQLE1BQU8sb0NBQW1DLHVCQUFzQjs7Ozt1SkFBekQsMkJBQTBCLElBQUEsS0FBMUIsMkJBQTBCO1FBQUE7TUFBQSxHQUFBO3FFQUExQiw2QkFBMEIsU0FBMUIsNEJBQTBCLFdBQUEsWUFEYixPQUFNLENBQUE7Ozs7OztBQ0hoQyxTQUFTLGNBQUFDLG1CQUFrQjtBQUMzQixTQUFTLGNBQUFDLG1CQUFnQzs7O0FBRHpDLElBZWE7QUFmYjs7QUFHQTtBQVlNLElBQU8sNkJBQVAsTUFBTyxvQ0FBbUMsdUJBQXNCO01BQ2xFLFlBQXNCLE1BQWdCO0FBQ2xDLGNBQU0sTUFBTSxVQUFVO01BQzFCO01BT0EsYUFBYSxXQUFpQjtBQUMxQixlQUFPLEtBQUssS0FBSyxJQUFrQixHQUFHLEtBQUssU0FBUyxJQUFJLEtBQUssV0FBVyxJQUFJLFNBQVMsV0FBVyxFQUFFLFNBQVMsV0FBVSxDQUFFO01BQzNIOzt5QkFaUyw2QkFBMEIsd0JBQUEsY0FBQSxDQUFBO01BQUE7cUVBQTFCLDZCQUEwQixTQUExQiw0QkFBMEIsV0FBQSxZQURiLE9BQU0sQ0FBQTs7Ozs7O0FDZGhDLFNBQVMsY0FBQUMsbUJBQWtCOztBQUEzQixJQVVhO0FBVmI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFNTSxJQUFPLHlCQUFQLE1BQU8sZ0NBQStCLG1CQUFrQjtNQUkxRCxZQUFZLFlBQTRCLG9CQUFnRCw0QkFBc0Q7QUFDMUksY0FBTSxZQUFZLG9CQUFvQiwwQkFBMEI7TUFDcEU7O3lCQU5TLHlCQUFzQix3QkFBQSxjQUFBLEdBQUEsd0JBQUEsMEJBQUEsR0FBQSx3QkFBQSwwQkFBQSxDQUFBO01BQUE7cUVBQXRCLHlCQUFzQixTQUF0Qix3QkFBc0IsVUFBQSxDQUFBOzs7Ozs7QUNWbkMsU0FBUyxjQUFBQyxtQkFBa0I7QUFDM0IsU0FBUyxjQUFBQyxtQkFBa0I7OztBQUQzQixJQVNhO0FBVGI7O0FBRUE7QUFPTSxJQUFPLG1DQUFQLE1BQU8sMENBQXlDLHVCQUFzQjtNQUNsRDtNQUF0QixZQUFzQixNQUFnQjtBQUNsQyxjQUFNLE1BQU0sc0JBQXNCO0FBRGhCLGFBQUEsT0FBQTtNQUV0Qjs7eUJBSFMsbUNBQWdDLHdCQUFBLGNBQUEsQ0FBQTtNQUFBO3FFQUFoQyxtQ0FBZ0MsU0FBaEMsa0NBQWdDLFdBQUEsWUFEbkIsT0FBTSxDQUFBOzs7Ozs7QUNSaEMsU0FBUyxjQUFBQyxvQkFBa0I7O0FBQTNCLElBUWE7QUFSYjs7QUFFQTtBQU1NLElBQU8sbUNBQVAsTUFBTywwQ0FBeUMsdUJBQXNCO01BQ3ZELGNBQWM7TUFVL0IsZ0JBQWdCLFdBQW1CLFdBQW1CLFFBQWdCLFFBQWM7QUFDaEYsZUFBTyxLQUFLLFdBQVcsS0FBVyxHQUFHLEtBQUssU0FBUyxJQUFJLEtBQUssV0FBVyxJQUFJLFNBQVMsYUFBYSxTQUFTLGFBQWEsTUFBTSxVQUFVLE1BQU0sWUFBWSxNQUFNO1VBQzNKLFNBQVM7U0FDWjtNQUNMO01BV0EsbUNBQW1DLFdBQW1CLFdBQW1CLFFBQWdCLFFBQWdCLGFBQWlDO0FBQ3RJLGVBQU8sS0FBSyxXQUFXLElBQ25CLEdBQUcsS0FBSyxTQUFTLElBQUksS0FBSyxXQUFXLElBQUksU0FBUyxhQUFhLFNBQVMsYUFBYSxNQUFNLFVBQVUsTUFBTSxJQUMzRyxhQUNBLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFFL0I7Ozs7bUtBaENTLGlDQUFnQyxJQUFBLEtBQWhDLGlDQUFnQztRQUFBO01BQUEsR0FBQTtxRUFBaEMsbUNBQWdDLFNBQWhDLGtDQUFnQyxXQUFBLFlBRG5CLE9BQU0sQ0FBQTs7Ozs7O0FDUGhDLFNBQVMsY0FBQUMsb0JBQWtCO0FBSzNCLFNBQVMsa0JBQUFDLHVCQUFzQjs7QUFML0IsSUFZYTtBQVpiOztBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7O0FBUU0sSUFBTywrQkFBUCxNQUFPLHNDQUFxQyxtQkFBa0I7TUFPcEQ7TUFIWixZQUNJLFlBQ0Esb0JBQ1Esa0NBQWtFO0FBRTFFLGNBQU0sWUFBWSxvQkFBb0IsZ0NBQWdDO0FBRjlELGFBQUEsbUNBQUE7TUFHWjtNQVNNLGdCQUFnQixXQUFtQixXQUFtQixRQUFnQixRQUFjOztBQUN0RixnQkFBTUEsZ0JBQWUsS0FBSyxpQ0FBaUMsZ0JBQWdCLFdBQVcsV0FBVyxRQUFRLE1BQU0sQ0FBQztRQUNwSDs7TUFVTSwyQkFBMkIsV0FBbUIsV0FBbUIsUUFBZ0IsUUFBZ0IsTUFBMEI7O0FBQzdILGdCQUFNLFdBQVcsTUFBTUEsZ0JBQWUsS0FBSyxpQ0FBaUMsbUNBQW1DLFdBQVcsV0FBVyxRQUFRLFFBQVEsSUFBSSxDQUFDO0FBQzFKLGlCQUFPLFNBQVM7UUFDcEI7Ozt5QkFsQ1MsK0JBQTRCLHdCQUFBLGNBQUEsR0FBQSx3QkFBQSxnQ0FBQSxHQUFBLHdCQUFBLGdDQUFBLENBQUE7TUFBQTtxRUFBNUIsK0JBQTRCLFNBQTVCLDhCQUE0QixVQUFBLENBQUE7Ozs7OztBQ1p6QyxTQUNJLGFBQ0EsVUFDQSxjQUNBLFlBQ0EsVUFDQSxjQUNBLFFBQ0EsU0FDQSxjQUNBLFlBQ0EsV0FBQUMsVUFDQSxlQUNHO0FBQ1AsU0FBUyxpQkFBaUIsY0FBYztBQUN4QyxTQUFTLGdCQUFnQjtBQUV6QixTQUF3QixhQUFBQyxhQUFXLFlBQVksUUFBMkIsYUFBQUMsa0JBQWlCO0FBQzNGLFNBQVMsaUJBQWlCLGlCQUFpQjtBQXlDM0MsT0FBTyxXQUFXO0FBQ2xCLFNBQXlCLFNBQVMsT0FBTyxPQUFPLFlBQVksZUFBZTtBQUczRSxPQUFPLGNBQWM7QUFDckIsU0FBUyxnQkFBZ0I7QUFFekIsU0FBUyx3QkFBd0I7Ozs7Ozs7Ozs7O0FDbERMLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7O0FBQ0ssSUFBQSxzQkFBQSxDQUFBO0FBQXlDLElBQUEsNEJBQUE7QUFFbEQsSUFBQSxzQkFBQSxHQUFBLDRCQUFBOzs7O0FBSDZCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsY0FBQSwyQkFBQSxHQUFBLEdBQUEsK0NBQUEsK0JBQUEsR0FBQSxLQUFBLE9BQUEsdUJBQUEsQ0FBQSxDQUFBO0FBQ3BCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsSUFBQSxPQUFBLHFCQUFBLEtBQUEsT0FBQSxXQUFBLEVBQUE7Ozs7OztBQUlMLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBK0IsSUFBQSwwQkFBQSxTQUFBLFNBQUEsNkVBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUE7QUFBQSxZQUFBLE1BQUEsMkJBQUEsRUFBQTtBQUFBLGFBQVMsMkJBQUEsUUFBQSxlQUFBLEdBQUEsQ0FBaUM7SUFBQSxDQUFBO0FBQ3JFLElBQUEsc0JBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLDRCQUFBOzs7O0FBRmlCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxPQUFBLE9BQUE7Ozs7OztBQUliLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxVQUFBLENBQUE7QUFBUSxJQUFBLDBCQUFBLFNBQUEsU0FBQSw2RUFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQTtBQUFBLGFBQVMsMkJBQUEsUUFBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUM3QixJQUFBLHNCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSw0QkFBQTs7OztBQUZpQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsT0FBQSxRQUFBOzs7Ozs7QUFJYixJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsVUFBQSxDQUFBO0FBQVEsSUFBQSwwQkFBQSxTQUFBLFNBQUEsNkVBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUE7QUFBQSxhQUFTLDJCQUFBLFFBQUEsZUFBQSxDQUFnQjtJQUFBLENBQUE7QUFDN0IsSUFBQSxzQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsNEJBQUE7Ozs7QUFGaUIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLE9BQUEsVUFBQTs7Ozs7O0FBVzdCLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHNCQUFBLENBQUE7O0FBQXdFLElBQUEsNEJBQUE7QUFDbEYsSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBMkQsSUFBQSwwQkFBQSxTQUFBLFNBQUEsOEVBQUE7QUFBQSxZQUFBLGNBQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsWUFBQSxZQUFBO0FBQUEsYUFBUywyQkFBQSxVQUFBLFFBQUEsQ0FBZTtJQUFBLENBQUE7QUFBRSxJQUFBLDRCQUFBO0FBQ3pGLElBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLEdBQUE7QUFBRyxJQUFBLHNCQUFBLEVBQUE7O0FBQXVFLElBQUEsNEJBQUE7QUFDOUUsSUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBO0FBQTZDLElBQUEsMEJBQUEsU0FBQSxTQUFBLDhFQUFBO0FBQUEsWUFBQSxjQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFlBQUEsWUFBQTtBQUFBLGFBQVMsMkJBQUEsVUFBQSxNQUFZLFNBQVMsQ0FBQztJQUFBLENBQUE7QUFDeEUsSUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLHNCQUFBLEVBQUE7O0FBQXlFLElBQUEsNEJBQUE7QUFDbkYsSUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsWUFBQTs7O0FBWmtCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMkJBQUEsR0FBQSxHQUFBLCtDQUFBLENBQUE7QUFLUCxJQUFBLHlCQUFBLEVBQUE7QUFBQSxJQUFBLGlDQUFBLDJCQUFBLElBQUEsR0FBQSw4Q0FBQSxDQUFBO0FBSU8sSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwyQkFBQSxJQUFBLEdBQUEsZ0RBQUEsQ0FBQTs7Ozs7QUFTRixJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsUUFBQSxJQUFBLEVBQUE7QUFBNEMsSUFBQSxzQkFBQSxDQUFBOztBQUFvRSxJQUFBLDRCQUFBO0FBQ3BILElBQUEsc0JBQUEsR0FBQSx3QkFBQTs7O0FBRGdELElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMkJBQUEsR0FBQSxHQUFBLDJDQUFBLENBQUE7Ozs7OztBQWF4QixJQUFBLHNCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsVUFBQSxFQUFBO0FBR0ksSUFBQSwwQkFBQSxTQUFBLFNBQUEsdUdBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLGNBQUEsNkJBQUEsQ0FBQSxFQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBO0FBQUEsYUFBUywyQkFBQSxRQUFBLGNBQUEsV0FBQSxDQUFzQjtJQUFBLENBQUE7QUFHL0IsSUFBQSxzQkFBQSxHQUFBLG9EQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsNENBQUE7Ozs7QUFKUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFlBQUEsUUFBQSxxQkFBQTtBQUVTLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxRQUFBLE1BQUEsRUFBZSxXQUFBLFFBQUEsd0JBQUEsYUFBQSxFQUFBOzs7OztBQUtoQyxJQUFBLHNCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUE7QUFBSyxJQUFBLHlCQUFBLEdBQUEsUUFBQSxFQUFBOztBQUNHLElBQUEsNEJBQUE7QUFDWixJQUFBLHNCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLHdDQUFBOzs7OztBQUhtQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGFBQUEsMkJBQUEsR0FBQSxHQUFBLFFBQUEsZUFBQSxXQUFBLENBQUEsR0FBQSw2QkFBQTs7Ozs7QUFwQnZCLElBQUEsc0JBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSwwQkFBQSxHQUFBLDhFQUFBLEdBQUEsQ0FBQTtBQWVKLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDBCQUFBLEdBQUEsOEVBQUEsR0FBQSxDQUFBO0FBTUosSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTs7Ozs7Ozs7QUF2QlksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsUUFBQSxTQUFBLFNBQUEsS0FBQSxZQUFBLFdBQUEsUUFBQSxXQUFBLFFBQUEsQ0FBQSxRQUFBLGFBQUEsRUFBQSxRQUFBLGFBQUEsS0FBQSxRQUFBLHVCQUFBLFFBQUEsYUFBQSxJQUFBLEVBQUE7QUFnQkosSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsY0FBQSxXQUFBLElBQUEsSUFBQSxFQUFBOzs7OztBQVdJLElBQUEsc0JBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsUUFBQSxFQUFBOztBQUNKLElBQUEsc0JBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsd0NBQUE7Ozs7O0FBRmMsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxhQUFBLDJCQUFBLEdBQUEsR0FBQSxRQUFBLGVBQUEsV0FBQSxDQUFBLEdBQUEsNkJBQUE7Ozs7OztBQUlWLElBQUEsc0JBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTJCLElBQUEsMEJBQUEsU0FBQSxTQUFBLHVHQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBLENBQUE7QUFBQSxZQUFBLGNBQUEsUUFBQTtBQUFBLFlBQUEsUUFBQSxRQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBO0FBQUEsYUFBUywyQkFBQSxRQUFBLFlBQUEsWUFBQSxJQUFBLE9BQTJCLElBQUksQ0FBQztJQUFBLENBQUE7QUFDaEUsSUFBQSxzQkFBQSxHQUFBLG9EQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLFdBQUEsRUFBQTtBQU1KLElBQUEsc0JBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTJCLElBQUEsMEJBQUEsU0FBQSxTQUFBLHVHQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBLENBQUE7QUFBQSxZQUFBLGNBQUEsUUFBQTtBQUFBLFlBQUEsUUFBQSxRQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBO0FBQUEsYUFBUywyQkFBQSxRQUFBLFlBQUEsWUFBQSxJQUFBLE9BQTJCLEtBQUssQ0FBQztJQUFBLENBQUE7QUFDakUsSUFBQSxzQkFBQSxHQUFBLG9EQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUtKLElBQUEsc0JBQUEsSUFBQSxnREFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsNENBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLHdDQUFBOzs7OztBQWhCOEUsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxZQUFBLFlBQUEsT0FBQTtBQUU5RCxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFlBQUEsVUFBQSxzQkFBQSxtQ0FBQTtBQUVBLElBQUEsMEJBQUEsUUFBQSxRQUFBLFVBQUE7QUFJK0QsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxZQUFBLENBQUEsWUFBQSxPQUFBO0FBRS9ELElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsWUFBQSxZQUFBLFFBQUEsd0JBQUEsbUNBQUE7QUFDQSxJQUFBLDBCQUFBLFFBQUEsUUFBQSxZQUFBOzs7OztBQXNCSSxJQUFBLHNCQUFBLEdBQUEsNERBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLGdFQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLFFBQUEsRUFBQTs7QUFDSixJQUFBLHNCQUFBLEdBQUEsNERBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLHdEQUFBOzs7OztBQUhTLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsbUJBQUEsUUFBQSxjQUFBLFFBQUEsQ0FBQTtBQUNLLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsYUFBQSwyQkFBQSxHQUFBLEdBQUEsU0FBQSxZQUFBLEdBQUEsNkJBQUE7Ozs7O0FBS1YsSUFBQSxzQkFBQSxHQUFBLDREQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0VBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLDREQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSx3REFBQTs7Ozs7O0FBdEJKLElBQUEsc0JBQUEsR0FBQSxvREFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHdEQUFBO0FBQ0EsSUFBQSxzQkFBQSxHQUFBLHdEQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSw0REFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0VBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsUUFBQSxFQUFBOztBQUNBLElBQUEsc0JBQUEsSUFBQSxnRUFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBUSxJQUFBLDBCQUFBLFNBQUEsU0FBQSw4R0FBQTtBQUFBLFlBQUEsY0FBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxXQUFBLFlBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUEsQ0FBQTtBQUFBLGFBQVMsMkJBQUEsUUFBQSxhQUFBLFFBQUEsQ0FBa0I7SUFBQSxDQUFBO0FBQy9CLElBQUEsc0JBQUEsRUFBQTtBQUNKLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsNERBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxJQUFBLDREQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLFFBQUEsRUFBQTs7QUFDSixJQUFBLHNCQUFBLElBQUEsd0RBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxJQUFBLHdEQUFBO0FBQ0EsSUFBQSxzQkFBQSxJQUFBLHdEQUFBO0FBQUEsSUFBQSwwQkFBQSxJQUFBLG1HQUFBLEdBQUEsQ0FBQTtBQU1BLElBQUEsc0JBQUEsSUFBQSx3REFBQTtBQUFBLElBQUEsMEJBQUEsSUFBQSxtR0FBQSxHQUFBLENBQUE7QUFLSixJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLGdEQUFBOzs7OztBQXRCYSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFdBQUEsK0JBQUEsSUFBQSxLQUFBLFFBQUEsYUFBQSxRQUFBLENBQUEsQ0FBQSxFQUFzRCxXQUFBLFFBQUEsU0FBQSxRQUFBLElBQUEsaUJBQUEsY0FBQTtBQUU3QyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGFBQUEsMkJBQUEsR0FBQSxHQUFBLFFBQUEsWUFBQSxRQUFBLENBQUEsR0FBQSw2QkFBQTtBQUVGLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsc0VBQUEsUUFBQSxTQUFBLFFBQUEsSUFBQSxpQkFBQSxnQkFBQSxnRUFBQTtBQUdrQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGFBQUEsMkJBQUEsSUFBQSxHQUFBLFFBQUEsY0FBQSxRQUFBLENBQUEsR0FBQSw2QkFBQTtBQUc5QixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsQ0FBQSxRQUFBLFNBQUEsUUFBQSxJQUFBLEtBQUEsRUFBQTtBQU1BLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxRQUFBLGFBQUEsUUFBQSxJQUFBLEtBQUEsRUFBQTs7Ozs7O0FBVUEsSUFBQSxzQkFBQSxHQUFBLHdEQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsNERBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQWdDLElBQUEsMEJBQUEsU0FBQSxTQUFBLHFIQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxjQUFBLDZCQUFBLENBQUEsRUFBQTtBQUFBLFlBQUEsY0FBQSw2QkFBQSxFQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBO0FBQUEsYUFBUywyQkFBQSxRQUFBLGFBQUEsWUFBQSxJQUFBLFdBQUEsQ0FBaUM7SUFBQSxDQUFBO0FBQ3RFLElBQUEsc0JBQUEsQ0FBQTtBQUNKLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsd0RBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLG9EQUFBOzs7OztBQUpvRixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFlBQUEsQ0FBQSxRQUFBLFdBQUEsV0FBQSxDQUFBO0FBQ3hFLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsa0VBQUEsUUFBQSxtQkFBQSxXQUFBLEdBQUEsNERBQUE7Ozs7OztBQUtSLElBQUEsc0JBQUEsR0FBQSx3REFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLDREQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFRLElBQUEsMEJBQUEsU0FBQSxTQUFBLHFIQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxjQUFBLDZCQUFBLENBQUEsRUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQSxDQUFBO0FBQUEsYUFBUywyQkFBQSxRQUFBLFVBQUEsV0FBQSxDQUFrQjtJQUFBLENBQUE7QUFBeUIsSUFBQSxzQkFBQSxHQUFBLE9BQUE7QUFBSyxJQUFBLDRCQUFBO0FBQ3JFLElBQUEsc0JBQUEsR0FBQSx3REFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsb0RBQUE7Ozs7O0FBeENSLElBQUEsc0JBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLGdDQUFBLEdBQUEsb0ZBQUEsSUFBQSxJQUFBLE1BQUEsTUFBQSx3Q0FBQTtBQTJCQSxJQUFBLHNCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLG9EQUFBO0FBQUEsSUFBQSwwQkFBQSxHQUFBLDRGQUFBLEdBQUEsQ0FBQSxFQU1DLEdBQUEsNEZBQUEsR0FBQSxDQUFBO0FBTUwsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSw0Q0FBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsd0NBQUE7Ozs7QUExQ1EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxZQUFBLEtBQUE7QUE0QkksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLENBQUEsWUFBQSxZQUFBLElBQUEsRUFBQTtBQU9BLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxZQUFBLFlBQUEsSUFBQSxFQUFBOzs7OztBQTlEaEIsSUFBQSxzQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsMEJBQUEsR0FBQSw4RUFBQSxHQUFBLENBQUEsRUFJQyxHQUFBLDhFQUFBLElBQUEsQ0FBQSxFQUFBLEdBQUEsOEVBQUEsSUFBQSxDQUFBO0FBaUVMLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7Ozs7O0FBdEVRLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLGNBQUEsV0FBQSxJQUFBLElBQUEsRUFBQTtBQUtBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLGNBQUEsV0FBQSxJQUFBLElBQUEsRUFBQTtBQW1CQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxlQUFBLFdBQUEsSUFBQSxJQUFBLEVBQUE7Ozs7O0FBa0RJLElBQUEsc0JBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTs7Ozs7QUFGYyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGFBQUEsUUFBQSxlQUFBLFdBQUEsR0FBQSw2QkFBQTs7Ozs7QUFIbEIsSUFBQSxzQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsMEJBQUEsR0FBQSw4RUFBQSxHQUFBLENBQUE7QUFLSixJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLGdDQUFBOzs7OztBQU5RLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLGNBQUEsV0FBQSxJQUFBLElBQUEsRUFBQTs7Ozs7QUF2R1osSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDBCQUFBLEdBQUEsZ0VBQUEsR0FBQSxDQUFBLEVBMEJDLEdBQUEsZ0VBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSxnRUFBQSxHQUFBLENBQUE7QUFtRkwsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSx3QkFBQTs7Ozs7QUE5R1EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEscUJBQUEsV0FBQSxJQUFBLElBQUEsRUFBQTtBQTJCQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxvQkFBQSxXQUFBLElBQUEsSUFBQSxFQUFBO0FBeUVBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLDJCQUFBLFdBQUEsSUFBQSxJQUFBLEVBQUE7Ozs7O0FBMUdaLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQSxHQUFBLDBEQUFBLEdBQUEsQ0FBQTtBQUdBLElBQUEsZ0NBQUEsR0FBQSxrREFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHdDQUFBO0FBaUhKLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7Ozs7OztBQXJIUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxPQUFBLHFCQUFBLElBQUEsRUFBQTtBQUdBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsWUFBQSxPQUFBOzs7OztBQXVIUSxJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsNEJBQUE7Ozs7QUFGaUIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLFFBQUEsUUFBQTs7Ozs7QUFKekIsSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLGdDQUFBLEdBQUEsMERBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx3Q0FBQTtBQUtKLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLGdCQUFBOzs7O0FBUFksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSwrQkFBQSxHQUFBLEdBQUEsRUFBQSxZQUFBLE9BQUEsSUFBQSxDQUFBOzs7Ozs7QUFTUixJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUEwQixJQUFBLHNCQUFBLENBQUE7O0FBQWtFLElBQUEsNEJBQUE7QUFDNUYsSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBdUIsSUFBQSwwQkFBQSxTQUFBLFNBQUEsNkVBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUE7QUFBQSxhQUFTLDJCQUFBLFFBQUEsaUJBQUEsQ0FBa0I7SUFBQSxDQUFBO0FBQUUsSUFBQSxzQkFBQSxFQUFBOztBQUE0RCxJQUFBLDRCQUFBO0FBQ2hILElBQUEsc0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBdUIsSUFBQSwwQkFBQSxTQUFBLFNBQUEsOEVBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUE7QUFBQSxhQUFTLDJCQUFBLFFBQUEsVUFBQSxDQUFXO0lBQUEsQ0FBQTtBQUFFLElBQUEsc0JBQUEsRUFBQTs7QUFBNkQsSUFBQSw0QkFBQTtBQUM5RyxJQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxnQkFBQTs7O0FBTmtDLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMkJBQUEsR0FBQSxHQUFBLHlDQUFBLENBQUE7QUFFOEIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwyQkFBQSxJQUFBLEdBQUEsbUNBQUEsQ0FBQTtBQUNQLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMkJBQUEsSUFBQSxHQUFBLG9DQUFBLENBQUE7Ozs7OztBQVFyRCxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQTRELElBQUEsMEJBQUEsdUJBQUEsU0FBQSwrRkFBQSxRQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBO0FBQUEsYUFBdUIsMkJBQUEsUUFBQSx3QkFBQSxNQUFBLENBQStCO0lBQUEsQ0FBQTtBQUM5RyxJQUFBLHNCQUFBLENBQUE7O0FBQ0osSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxnQkFBQTs7OztBQUhtQyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGtCQUFBLFFBQUEsU0FBQTtBQUMzQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLDBCQUFBLDJCQUFBLEdBQUEsR0FBQSxRQUFBLE1BQUEsR0FBQSxHQUFBLG9CQUFBOzs7OztBQUlKLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLENBQUE7O0FBQ0osSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxnQkFBQTs7OztBQUZRLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsMEJBQUEsMkJBQUEsR0FBQSxHQUFBLFFBQUEsTUFBQSxLQUFBLFFBQUEscUJBQUEsQ0FBQSxHQUFBLG9CQUFBOzs7QURsTnBCLHdDQTJGYTtBQTNGYjs7QUFnQkE7QUFLQTtBQU9BO0FBU0E7QUFtQkE7QUFFQTtBQUdBO0FBQ0E7QUFHQTtBQUVBOzs7Ozs7Ozs7Ozs7OztBQXdCTSxJQUFPLDZCQUFQLE1BQU8sNEJBQTBCO01BNkR2QjtNQUN3QjtNQUN4QjtNQUNBO01BQ0E7TUFDQTtNQUNrQjtNQUNsQjtNQWxFWixVQUFVRjtNQUNWLFdBQVc7TUFDWCxlQUFlO01BQ2YsV0FBVztNQUNYLFVBQVU7TUFDVixjQUFjO01BQ2QsVUFBVTtNQUNWLGVBQWU7TUFDZixhQUFhO01BQ2IsYUFBYTtNQUNiLGVBQWU7TUFDZixTQUFTO01BR2M7TUFDRztNQUN1QjtNQUNGO01BRy9DO01BQ0E7TUFDQSxXQUEwQixDQUFBO01BQzFCO01BQ0Esd0JBQXdCO01BQ3hCO01BQ0E7TUFDQSxpQkFBaUI7TUFDakI7TUFDQTtNQUNBLE9BQU87TUFDUCx3QkFBd0I7TUFDeEIsa0JBQWtCO01BQ2xCLDRCQUE0QjtNQUM1QixZQUFZO01BQ1o7TUFDQTtNQUNBO01BQ0EsOEJBQThCO01BQzlCO01BQ0E7TUFDQTtNQUNBO01BR0E7TUFDQSxxQkFBcUI7TUFDckIsT0FBTztNQUNQLGVBQWU7TUFDZixnQkFBZ0I7TUFDaEIsa0JBQWtCO01BQ2xCLG1CQUFtQjtNQUNuQixXQUFXO01BQ0osYUFBYTtNQUNYLGVBQWU7TUFDaEI7TUFDUyxlQUFlO01BRWhDLFlBQ1ksUUFDd0IsTUFDeEIsYUFDQSxRQUNBLGVBQ0EsY0FDa0JHLFdBQ2xCLGtCQUFrQztBQVBsQyxhQUFBLFNBQUE7QUFDd0IsYUFBQSxPQUFBO0FBQ3hCLGFBQUEsY0FBQTtBQUNBLGFBQUEsU0FBQTtBQUNBLGFBQUEsZ0JBQUE7QUFDQSxhQUFBLGVBQUE7QUFDa0IsYUFBQSxXQUFBQTtBQUNsQixhQUFBLG1CQUFBO0FBRVIsYUFBSyxhQUFhLEtBQUs7QUFDdkIsYUFBSyxXQUFXLEtBQUs7QUFDckIsYUFBSyxhQUFhLEtBQUs7QUFDdkIsYUFBSyxpQkFBaUIsS0FBSztBQUMzQixhQUFLLHlCQUF5QixLQUFLLE9BQU8sT0FBTyxVQUFVLENBQUMsVUFBUztBQUNqRSxjQUFJLGlCQUFpQixpQkFBaUI7QUFDbEMsaUJBQUssT0FBTyxTQUFROztRQUU1QixDQUFDO0FBQ0QsYUFBSyxXQUFXLEtBQUssWUFBWTtNQUNyQztNQUVBLFdBQVE7QUFDSixhQUFLLFlBQVksa0JBQWlCLEVBQUcsVUFBVSxDQUFDLFFBQU87QUFDbkQsZUFBSyxlQUFlLENBQUMsQ0FBQztBQUN0QixjQUFJLEtBQUssY0FBYztBQUNuQixpQkFBSyxpQkFBZ0I7O1FBRTdCLENBQUM7QUFFRCxhQUFLLFlBQVc7QUFHaEIsYUFBSyxvQkFBb0IsS0FBSyxXQUFXLFNBQVEsRUFBRyxVQUFVLENBQUNDLFdBQVM7QUFDcEUsZUFBSyxXQUFXQSxPQUFNO0FBQ3RCLGVBQUssWUFBWUEsT0FBTTtBQUN2QixlQUFLLFFBQVFBLE9BQU07QUFDbkIsZUFBSyxZQUFZLE9BQU9BLE9BQU0sU0FBUztBQUN2QyxlQUFLLGlCQUFpQkEsT0FBTTtBQUM1QixjQUFJQSxPQUFNLE9BQU8sT0FBTyxvQkFBb0IsZUFBZTtBQUN2RCxpQkFBSyw4QkFBOEI7QUFDbkMsaUJBQUssWUFBWTs7QUFFckIsY0FBSSxLQUFLLE9BQU87QUFDWixpQkFBSyxxQkFBb0I7O0FBRTdCLGVBQUssc0JBQXNCQSxPQUFNO0FBQ2pDLGVBQUssWUFBWUEsT0FBTTtBQUN2QixlQUFLLDBCQUEwQkEsT0FBTTtRQUN6QyxDQUFDO0FBR0QsbUJBQVcsTUFBSztBQUNaLGVBQUssZ0JBQWdCLGNBQWMsTUFBSztRQUM1QyxHQUFHLEdBQUc7TUFDVjtNQUVBLGtCQUFlO0FBRVgsYUFBSyxxQkFBcUIsS0FBSyxTQUFTLFVBQVUsS0FBSyxLQUFLLG1CQUFtQixJQUFJLEtBQUssS0FBSyxTQUFTLFNBQVMsS0FBSztBQUNwSCxZQUFJLEtBQUssaUJBQWlCLEdBQUc7QUFDekIsZUFBSyxlQUFjO2VBQ2hCO0FBQ0gsZUFBSyxlQUFlLE1BQU07O0FBRzlCLGlCQUFTLGNBQWMsRUFDbEIsVUFBVTtVQUVQLE9BQU8sRUFBRSxNQUFNLE1BQU0sT0FBTyxNQUFNLFFBQVEsTUFBTSxLQUFLLEtBQUk7VUFFekQsV0FBVztZQUNQLE1BQU0sQ0FBQyxVQUFTO0FBQ1osb0JBQU0sU0FBUyxNQUFNO0FBQ3JCLGtCQUFJLElBQUksV0FBVyxPQUFPLGFBQWEsUUFBUSxDQUFDLEtBQUs7QUFDckQsa0JBQUksSUFBSSxXQUFXLE9BQU8sYUFBYSxRQUFRLENBQUMsS0FBSztBQUdyRCxxQkFBTyxNQUFNLFFBQVEsTUFBTSxLQUFLLFFBQVE7QUFDeEMscUJBQU8sTUFBTSxTQUFTLE1BQU0sS0FBSyxTQUFTO0FBRzFDLG9CQUFNLFVBQVcsS0FBSyxTQUFTLGNBQWMsd0JBQXdCLEVBQWtCLHNCQUFxQjtBQUM1RyxtQkFBSyxXQUFXLEVBQUUsTUFBTSxLQUFLLFFBQVEsUUFBUSxRQUFRLEtBQUssbUJBQW1CLE1BQU0sS0FBSyxTQUFTLFFBQVEsU0FBUyxLQUFLO0FBR3ZILG1CQUFLLE1BQU0sVUFBVTtBQUNyQixtQkFBSyxNQUFNLFVBQVU7QUFFckIscUJBQU8sTUFBTSxZQUFZLGVBQWUsSUFBSSxRQUFRLElBQUk7QUFFeEQscUJBQU8sYUFBYSxVQUFVLENBQUM7QUFDL0IscUJBQU8sYUFBYSxVQUFVLENBQUM7WUFDbkM7O1VBRUosV0FBVztZQUVQLFNBQVMsVUFBVSxjQUFjO2NBQzdCLE9BQU87YUFDVjtZQUdELFNBQVMsVUFBVSxhQUFhO2NBQzVCLEtBQUssRUFBRSxPQUFPLEtBQUssY0FBYyxRQUFRLEtBQUssY0FBYTthQUM5RDs7VUFHTCxTQUFTO1NBQ1osRUFDQSxVQUFVO1VBQ1AsV0FBVztZQUNQLE1BQU0sQ0FBQyxVQUFjO0FBQ2pCLG9CQUFNLFNBQVMsTUFBTSxRQUVqQixLQUFLLFdBQVcsT0FBTyxhQUFhLFFBQVEsQ0FBQyxLQUFLLEtBQUssTUFBTSxJQUM3RCxLQUFLLFdBQVcsT0FBTyxhQUFhLFFBQVEsQ0FBQyxLQUFLLEtBQUssTUFBTTtBQUdqRSxxQkFBTyxNQUFNLFlBQVksZUFBZSxJQUFJLFNBQVMsSUFBSTtBQUd6RCxxQkFBTyxhQUFhLFVBQVUsQ0FBQztBQUMvQixxQkFBTyxhQUFhLFVBQVUsQ0FBQztZQUNuQzs7VUFFSixTQUFTO1VBQ1QsV0FBVztZQUNQLFNBQVMsVUFBVSxhQUFhO2NBQzVCLGFBQWE7Y0FDYixTQUFTO2FBQ1o7O1NBRVI7QUFDTCxhQUFLLG9CQUFtQjtNQUM1QjtNQUVBLHNCQUFtQjtBQUNmLGNBQU0sVUFBVyxLQUFLLFNBQVMsY0FBYyx3QkFBd0IsR0FBbUIsc0JBQXFCO0FBQzdHLFlBQUksQ0FBQyxTQUFTO0FBQ1Y7O0FBR0osY0FBTSxRQUFRLEtBQUssV0FBWSxRQUFRLFNBQVMsSUFBSSxLQUFLLG1CQUFvQixJQUFNLFFBQVEsUUFBUSxLQUFLLGVBQWU7QUFDdkgsY0FBTSxRQUFRLEtBQUssV0FBWSxRQUFRLFVBQVUsSUFBSSxLQUFLLG9CQUFxQixJQUFNLFFBQVEsU0FBUyxLQUFLLGdCQUFnQjtBQUUzSCxjQUFNLEtBQUssS0FBSyxTQUFTLGNBQWMsY0FBYztBQUNyRCxXQUFHLE1BQU0sWUFBWSxhQUFhLEtBQUssT0FBTyxLQUFLO0FBQ25ELFdBQUcsYUFBYSxVQUFVLE9BQU8sS0FBSyxDQUFDO0FBQ3ZDLFdBQUcsYUFBYSxVQUFVLE9BQU8sS0FBSyxDQUFDO0FBR3ZDLFlBQUksS0FBSyxVQUFVO0FBQ2YsYUFBRyxNQUFNLFFBQVEsR0FBRyxRQUFRLFFBQVEsS0FBSyxlQUFlO0FBQ3hELGFBQUcsTUFBTSxTQUFTLEdBQUcsUUFBUSxTQUFTLEtBQUssZ0JBQWdCO2VBQ3hEO0FBQ0gsYUFBRyxNQUFNLFFBQVEsR0FBRyxLQUFLLFlBQVk7QUFDckMsYUFBRyxNQUFNLFNBQVMsR0FBRyxLQUFLLGFBQWE7O01BRS9DO01BRUEsY0FBVztBQUNQLGFBQUssa0JBQWtCLFlBQVc7QUFDbEMsYUFBSyx1QkFBdUIsWUFBVztBQUN2QyxhQUFLLGlCQUFpQixLQUFLO01BQy9CO01BS0EseUJBQXNCO0FBQ2xCLFlBQUksS0FBSyxjQUFhLEdBQUk7QUFDdEIsaUJBQU8sS0FBSyxpQkFBaUIsUUFBUSw4Q0FBOEM7O0FBRXZGLGFBQUssb0JBQW9CLHNCQUFzQixLQUFLLFFBQVEsaUNBQWlDLEtBQUssVUFBVTtBQUM1RyxlQUFPLEtBQUssaUJBQ1AsUUFBUSxtREFBbUQsRUFDM0QsUUFBUSxlQUFlLGNBQWMsS0FBSyxvQkFBb0IsMEJBQTBCO01BQ2pHO01BS0EsbUJBQWdCO0FBQ1osY0FBTSxzQkFBc0I7VUFDeEIsTUFBTSx1QkFBdUI7VUFDN0IsYUFBYSxLQUFLLHVCQUFzQjs7QUFHNUMsY0FBTSxlQUFlO1VBQ2pCLFFBQVEsV0FBVztVQUNuQixTQUFTLENBQUMsbUJBQW1CO1VBQzdCLFFBQVEsTUFBSzs7QUFHakIsWUFBSSxLQUFLLFNBQVMsV0FBVyxHQUFHO0FBQzVCLGVBQUssV0FBVyxTQUFTLElBQUksc0NBQXNDLFlBQVksQ0FBQzs7TUFFeEY7TUFLQSxTQUFNO0FBQ0YsWUFBSSxLQUFLLE9BQU8sT0FBTztBQUNuQjs7QUFFSixZQUFJLEtBQUssc0JBQXNCLEtBQUksTUFBTyxJQUFJO0FBQzFDLGVBQUssV0FBVyxnQkFBZ0IsSUFBSSxnQ0FBZ0Msb0JBQW9CLGFBQWEsQ0FBQyxFQUFFLE1BQU0sTUFBTSxLQUFLLGVBQWUsUUFBUSxDQUFDO0FBQ2pKOztBQUVKLFlBQUksS0FBSyx1QkFBdUI7QUFDNUIsZ0JBQU0sVUFBVSxLQUFLLGVBQWUsS0FBSyxxQkFBcUI7QUFDOUQsZ0JBQU0sWUFBWSxXQUFXLE1BQUs7QUFFOUIsaUJBQUssV0FBVyxTQUFTLElBQUksZ0NBQWdDLG9CQUFvQiw0QkFBNEIsQ0FBQztBQUM5RyxpQkFBSyxlQUFlLFFBQVE7VUFDaEMsR0FBRyxHQUFLO0FBQ1IsZUFBSyxXQUNBLGdCQUFnQixJQUFJLHlCQUF5QixTQUFTLFNBQVMsQ0FBQyxFQUNoRSxLQUFLLE1BQU0sS0FBSyxlQUFlLFlBQVksS0FBSyxXQUFXLE9BQU8sQ0FBQyxFQUNuRSxLQUFLLE1BQU0sS0FBSyxlQUFlLFFBQVEsQ0FBQyxFQUN4QyxNQUFNLENBQUMsVUFBVSxLQUFLLGdCQUFnQixLQUFLLENBQUM7QUFDakQsZUFBSyx3QkFBd0I7O0FBRWpDLGFBQUssZUFBZSxRQUFRO0FBQzVCLGFBQUssb0JBQW1CO01BQzVCO01BRUEsY0FBYyxTQUF3QjtBQUNsQyxhQUFLLHdCQUF3QjtBQUM3QixnQkFBUSx3QkFBd0IsUUFBUSxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU0sSUFBSyxLQUFLLFlBQVk7QUFFMUYsY0FBTSxZQUFZLFdBQVcsTUFBSztBQUU5QixlQUFLLFdBQVcsU0FBUyxJQUFJLGdDQUFnQyxvQkFBb0IsNEJBQTRCLENBQUM7QUFDOUcsZUFBSyxlQUFlLFFBQVE7UUFDaEMsR0FBRyxHQUFPO0FBQ1YsYUFBSyxXQUNBLGdCQUFnQixJQUFJLHlCQUF5QixTQUFTLFNBQVMsQ0FBQyxFQUNoRSxLQUFLLE1BQUs7QUFDUCxjQUFJLFFBQVEsSUFBSTtBQUNaLG1CQUFPLEtBQUssZUFBZSxjQUFjLEtBQUssV0FBVyxPQUFPO2lCQUM3RDtBQUNILG1CQUFPLEtBQUssZUFBZSxZQUFZLEtBQUssV0FBVyxPQUFPOztRQUV0RSxDQUFDLEVBQ0EsS0FBSyxNQUFLO0FBQ1AsZUFBSyxlQUFlLFFBQVE7UUFDaEMsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxVQUFVLEtBQUssZ0JBQWdCLEtBQUssQ0FBQyxFQUM1QyxRQUFRLE1BQUs7QUFDVixlQUFLLHdCQUF3QjtBQUM3QixlQUFLLGVBQWUsUUFBUTtRQUNoQyxDQUFDO01BQ1Q7TUFFUSxnQkFBZ0IsT0FBd0I7QUFDNUMsWUFBSSxNQUFNLFdBQVcsS0FBSztBQUN0QixlQUFLLFdBQVcsU0FBUyxJQUFJLGdDQUFnQyxvQkFBb0IsYUFBYSxDQUFDO21CQUN4RixNQUFNLFdBQVcsS0FBSztBQUM3QixnQkFBTUMsT0FBTSxvQkFBSSxJQUFHO0FBQ25CLFVBQUFBLEtBQUksSUFBSSxTQUFTLEtBQUssdUJBQXVCO0FBQzdDLGVBQUssV0FBVyxTQUFTLElBQUksZ0NBQWdDLG9CQUFvQixxQkFBcUJBLElBQUcsQ0FBQztlQUN2RztBQUNILGVBQUssV0FBVyxTQUFTLElBQUksZ0NBQWdDLG9CQUFvQixtQkFBbUIsQ0FBQzs7TUFFN0c7TUFRQSxZQUFZLFdBQW1CLE9BQWUsU0FBZ0I7QUFDMUQsYUFBSyxlQUNBLFlBQVksS0FBSyxXQUFXLFdBQVcsT0FBTyxFQUM5QyxLQUFLLE1BQU0sS0FBSyxXQUFXLFNBQVMsSUFBSSx5QkFBeUIsT0FBTyxPQUFPLENBQUMsQ0FBQyxFQUNqRixNQUFNLE1BQUs7QUFDUixlQUFLLFdBQVcsU0FBUyxJQUFJLGdDQUFnQyxvQkFBb0IsbUJBQW1CLENBQUM7QUFDckcsZUFBSyxlQUFlLFFBQVE7UUFDaEMsQ0FBQztNQUNUO01BS0EsWUFBUztBQUNMLGFBQUssV0FBVyxTQUFTLElBQUksMEJBQXlCLENBQUU7QUFDeEQsYUFBSyxjQUFjLHFCQUFxQixLQUFLO0FBQzdDLGFBQUssT0FBTyxTQUFRO01BQ3hCO01BS0EsY0FBVztBQUNQLG9CQUFZLE1BQUs7QUFDYixlQUFLLE9BQU8sS0FBSyxPQUFPLElBQUssS0FBSyxRQUFRLElBQU0sS0FBSyxPQUFPO1FBQ2hFLEdBQUcsR0FBRztNQUNWO01BS0EsaUJBQWM7QUFDVixtQkFBVyxNQUFLO0FBQ1osZ0JBQU0sdUJBQW9DLEtBQUssZUFBZTtBQUM5RCxjQUFJLHNCQUFzQjtBQUN0QixpQ0FBcUIsZUFBZSxFQUFFLFVBQVUsT0FBTSxDQUFFOztRQUVoRSxDQUFDO01BQ0w7TUFNQSxlQUFlLFVBQXdCO0FBQ25DLG1CQUFXLE1BQUs7QUFDWixnQkFBTSxrQkFBK0IsS0FBSyxTQUFTO0FBQ25ELDBCQUFnQixTQUFTO1lBQ3JCLEtBQUssZ0JBQWdCO1lBQ3JCO1dBQ0g7UUFDTCxDQUFDO01BQ0w7TUFLQSxrQkFBZTtBQUNYLGNBQU0sV0FBVyxLQUFLLFNBQVM7QUFDL0IsY0FBTSxlQUFlLFNBQVM7QUFDOUIsY0FBTSxZQUFZLFNBQVM7QUFDM0IsY0FBTSxlQUFlLFNBQVM7QUFDOUIsYUFBSyxxQkFBcUIsZUFBZSxZQUFZLGVBQWU7TUFDeEU7TUFLQSxlQUFlLFNBQVk7QUFDdkIsYUFBSyxhQUFhLEtBQUssT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDLFdBQWtCO0FBQzNELGNBQUksV0FBVyxXQUFXO0FBQ3RCLGlCQUFLLFlBQVk7QUFDakIsaUJBQUssaUJBQWdCOztRQUU3QixDQUFDO01BQ0w7TUFLQSxtQkFBZ0I7QUFDWixhQUFLLFlBQVksV0FBVSxFQUFHLFVBQVUsTUFBSztBQUN6QyxlQUFLLGVBQWU7UUFDeEIsQ0FBQztBQUNELGFBQUssaUJBQWdCO01BQ3pCO01BS0EsaUJBQWM7QUFDVixhQUFLLFdBQVc7QUFDaEIsYUFBSyxvQkFBbUI7TUFDNUI7TUFLQSxpQkFBYztBQUNWLGFBQUssV0FBVztBQUNoQixhQUFLLG9CQUFtQjtNQUM1QjtNQU1BLFVBQVUsT0FBb0I7QUFDMUIsWUFBSSxNQUFNLFFBQVEsU0FBUztBQUN2QixjQUFJLENBQUMsS0FBSyx1QkFBc0IsR0FBSTtBQUNoQyxnQkFBSSxDQUFDLE1BQU0sVUFBVTtBQUNqQixvQkFBTSxlQUFjO0FBQ3BCLG1CQUFLLE9BQU07bUJBQ1I7QUFDSCxvQkFBTSxXQUFXLE1BQU07QUFDdkIsb0JBQU0sRUFBRSxnQkFBZ0IsYUFBWSxJQUFLO0FBQ3pDLG9CQUFNLFFBQVEsU0FBUztBQUN2Qix1QkFBUyxRQUFRLE1BQU0sTUFBTSxHQUFHLGNBQWMsSUFBSSxNQUFNLE1BQU0sWUFBWTtBQUMxRSx1QkFBUyxpQkFBaUIsU0FBUyxlQUFlLGlCQUFpQjs7aUJBRXBFO0FBQ0gsa0JBQU0sZUFBYzs7O01BR2hDO01BS0EsVUFBTztBQUNILGFBQUssbUJBQWtCO01BQzNCO01BS0EsVUFBTztBQUNILG1CQUFXLE1BQUs7QUFDWixlQUFLLG1CQUFrQjtRQUMzQixHQUFHLENBQUM7TUFDUjtNQUtBLHFCQUFrQjtBQUNkLGNBQU0sV0FBZ0MsS0FBSyxnQkFBZ0I7QUFDM0QsaUJBQVMsTUFBTSxTQUFTO0FBQ3hCLGNBQU0sYUFBYSxTQUFTLGlCQUFpQixRQUFRLEVBQUUsWUFBWSxFQUFFO0FBQ3JFLGNBQU0sVUFBVTtBQUNoQixjQUFNLFlBQVksYUFBYTtBQUUvQixpQkFBUyxNQUFNLFNBQVMsR0FBRyxLQUFLLElBQUksU0FBUyxjQUFjLFNBQVMsQ0FBQztBQUVyRSxhQUFLLHFCQUFxQixLQUFLLElBQUksU0FBUyxjQUFjLFNBQVMsSUFBSSxVQUFVO01BQ3JGO01BS0EsY0FBVztBQUNQLGNBQU0sV0FBZ0MsS0FBSyxnQkFBZ0I7QUFDM0QsY0FBTSxVQUFVLFNBQVMsTUFBTSxNQUFNLElBQUksRUFBRTtBQUMzQyxZQUFJLFdBQVcsS0FBSyxNQUFNO0FBQ3RCLGNBQUksV0FBVyxHQUFHO0FBQ2QscUJBQVMsT0FBTztBQUNoQixpQkFBSyxxQkFBcUIsT0FBTztBQUNqQyxpQkFBSyxPQUFPOzs7TUFHeEI7TUFNQSxxQkFBcUIsU0FBZTtBQUNoQyxjQUFNLFdBQWdDLEtBQUssZ0JBQWdCO0FBQzNELGNBQU0sV0FBd0IsS0FBSyxTQUFTO0FBQzVDLGNBQU0sY0FBMkIsS0FBSyxZQUFZO0FBQ2xELGNBQU0sYUFBYSxTQUFTLE9BQU8saUJBQWlCLFFBQVEsRUFBRSxVQUFVO0FBQ3hFLGNBQU0sWUFBWSxhQUFhO0FBQy9CLG1CQUFXLE1BQUs7QUFDWixzQkFBWSxNQUFNLFNBQVMsY0FBYyxTQUFTO1FBQ3RELEdBQUcsRUFBRTtBQUNMLG1CQUFXLE1BQUs7QUFDWixtQkFBUyxNQUFNLFNBQVMsZUFBZSxTQUFTO1FBQ3BELEdBQUcsRUFBRTtNQUNUO01BS0Esc0JBQW1CO0FBQ2YsY0FBTSxXQUF3QixLQUFLLFNBQVM7QUFDNUMsY0FBTSxXQUFnQyxLQUFLLGdCQUFnQjtBQUMzRCxjQUFNLGNBQTJCLEtBQUssWUFBWTtBQUNsRCxpQkFBUyxPQUFPO0FBQ2hCLGlCQUFTLE1BQU0sU0FBUztBQUN4QixvQkFBWSxNQUFNLFNBQVM7QUFDM0IsaUJBQVMsTUFBTSxTQUFTO0FBQ3hCLGFBQUssV0FBVyxTQUFTLElBQUksMEJBQXlCLENBQUU7TUFDNUQ7TUFZQSxtQkFBbUIsTUFBc0I7QUFDckMsWUFBSSxLQUFLLFdBQVc7QUFDaEIsaUJBQU87O0FBRVgsY0FBTSxnQkFBZ0IsS0FBSyxpQkFBaUIsSUFBSTtBQUNoRCxZQUFJLGlCQUFpQixLQUFLLE1BQU0sUUFBUTtBQUNwQyxpQkFBTzs7QUFFWCxjQUFNLFdBQVcsS0FBSyxNQUFNLGFBQWE7QUFDekMsWUFBSSxTQUFTLFFBQVEsR0FBRztBQUNwQixpQkFBTzs7QUFFWCxZQUFJLGtCQUFrQixHQUFHO0FBQ3JCLGlCQUFPOztBQUVYLGVBQU87TUFDWDtNQU1BLFVBQVUsTUFBc0I7QUFDNUIsYUFBSyxZQUFZO01BQ3JCO01BUUEsaUJBQWlCLE1BQXNCO0FBQ25DLGlCQUFTLElBQUksS0FBSyxNQUFNLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztBQUM3QyxnQkFBTSxPQUFPLEtBQUssTUFBTSxDQUFDO0FBQ3pCLGNBQUksV0FBVyxJQUFJLEdBQUc7QUFDbEIsbUJBQU8sSUFBSTs7O0FBR25CLGVBQU87TUFDWDtNQU1BLFdBQVcsTUFBc0I7QUFDN0IsZUFBTyxLQUFLLGlCQUFpQixJQUFJLElBQUksS0FBSyxNQUFNO01BQ3BEO01BVUEsYUFBYSxXQUFtQixNQUFzQjtBQUNsRCxjQUFNLGdCQUFnQixLQUFLLGlCQUFpQixJQUFJO0FBQ2hELFlBQUksaUJBQWlCLEtBQUssTUFBTSxRQUFRO0FBQ3BDLGtCQUFRLE1BQU0saURBQWlEO0FBQy9EOztBQUVKLGNBQU0sT0FBTyxLQUFLLE1BQU0sYUFBYTtBQUNyQyxZQUFJLENBQUMsTUFBTTtBQUNQLGtCQUFRLE1BQU0sc0NBQXNDO0FBQ3BEOztBQUVKLGFBQUssWUFBWTtBQUNqQixZQUFJLGFBQWEsSUFBSSxHQUFHO0FBQ3BCLGtCQUFRLElBQUksOENBQThDO0FBQzFEOztBQUVKLGFBQUssZ0JBQWdCLFdBQVcsSUFBSTtNQUN4QztNQVFBLGdCQUFnQixXQUFtQixNQUEwQjtBQUN6RCxZQUFJLEVBQUUsS0FBSywwQkFBMEIsK0JBQStCO0FBQ2hFOztBQUVKLFlBQUksQ0FBQyxLQUFLLE1BQU0sQ0FBQyxLQUFLLE1BQU07QUFDeEIsa0JBQVEsTUFBTSxtRUFBbUUsS0FBSyxLQUFLLE1BQU0sS0FBSyxJQUFJO0FBQzFHOztBQUVKLGFBQUssaUJBQWlCLGVBQWU7QUFDckMsYUFBSyxlQUNBLGdCQUFnQixLQUFLLFdBQVcsV0FBVyxLQUFLLE1BQU0sS0FBSyxFQUFFLEVBRTdELE1BQU0sTUFBSztBQUVSLGVBQUssaUJBQWlCLGVBQWU7QUFDckMsZUFBSyxlQUFlLFFBQVE7UUFDaEMsQ0FBQztNQUNUO01BU0Esb0JBQW9CLFdBQW1CLFFBQWdCLFFBQWM7QUFDakUsY0FBTSxDQUFDLE1BQU0sSUFBSSxJQUFJLEtBQUssYUFBYSxXQUFXLFFBQVEsTUFBTTtBQUNoRSxZQUFJLENBQUMsUUFBUSxDQUFDLE1BQU07QUFDaEI7O0FBRUosYUFBSyxpQkFBaUIsZUFBZTtBQUNyQyxZQUFJLEtBQUssV0FBVztBQUNoQixnQkFBTSxnQkFBZ0IsS0FBSyxpQkFBaUIsSUFBSTtBQUNoRCxjQUFJLGdCQUFnQixLQUFLLE1BQU0sUUFBUTtBQUVuQyxpQkFBSyxnQkFBZ0IsV0FBVyxLQUFLLE1BQU0sYUFBYSxDQUFDO2lCQUN0RDtBQUNILGlCQUFLLFlBQVk7OztNQUc3QjtNQUVBLGlCQUFpQixXQUFtQixRQUFnQixRQUFnQixxQkFBMkMsbUJBQW9DO0FBQy9JLGNBQU0sQ0FBQyxNQUFNLElBQUksSUFBSSxLQUFLLGFBQWEsV0FBVyxRQUFRLE1BQU07QUFDaEUsWUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNO0FBQ2hCOztBQUVKLGFBQUssWUFBWTtBQUNqQixhQUFLLGlCQUFpQixlQUFlO0FBQ3JDLFlBQUksQ0FBQyxxQkFBcUI7QUFDdEIsZUFBSyxXQUFXLFNBQVMsSUFBSSxnQ0FBZ0Msb0JBQW9CLHdCQUF3QixDQUFDO2VBQ3ZHO0FBQ0gsZUFBSyxXQUFXLFNBQVMsSUFBSSxnQ0FBZ0MscUJBQXFCLGlCQUFpQixDQUFDOztNQUU1RztNQUVRLGFBQWEsV0FBbUIsUUFBZ0IsUUFBYztBQUNsRSxjQUFNLFVBQVUsS0FBSyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxTQUFTO0FBQzVELFlBQUksQ0FBQyxTQUFTO0FBQ1Ysa0JBQVEsTUFBTSxvQ0FBb0MsU0FBUztBQUMzRCxpQkFBTyxDQUFDLFFBQVcsTUFBUzs7QUFFaEMsY0FBTSxPQUFPLFFBQVEsUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sTUFBTTtBQUN4RCxZQUFJLENBQUMsTUFBTTtBQUNQLGtCQUFRLE1BQU0saUNBQWlDLE1BQU07QUFDckQsaUJBQU8sQ0FBQyxRQUFXLE1BQVM7O0FBRWhDLGNBQU0sT0FBTyxLQUFLLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE1BQU07QUFDbkQsWUFBSSxDQUFDLE1BQU07QUFDUCxrQkFBUSxNQUFNLDBDQUEwQyxNQUFNO0FBQzlELGlCQUFPLENBQUMsTUFBTSxNQUFTOztBQUUzQixlQUFPLENBQUMsTUFBTSxJQUFJO01BQ3RCO01BRUEsYUFBYSxNQUEwQjtBQUNuQyxnQkFBUSxLQUFLLGdCQUFnQjtVQUN6QixLQUFLLGVBQWU7QUFDaEIsbUJBQU87VUFDWCxLQUFLLGVBQWU7QUFDaEIsbUJBQU87VUFDWCxLQUFLLGVBQWU7QUFDaEIsbUJBQU87VUFDWCxLQUFLLGVBQWU7QUFDaEIsbUJBQU87O01BRW5CO01BRUEsWUFBWSxNQUEwQjtBQUNsQyxnQkFBUSxLQUFLLFdBQVc7VUFDcEIsS0FBSyxrQkFBa0I7QUFDbkIsbUJBQU87VUFDWCxLQUFLLGtCQUFrQjtBQUNuQixtQkFBTztVQUNYLEtBQUssa0JBQWtCO0FBQ25CLG1CQUFPO1VBQ1gsS0FBSyxrQkFBa0I7QUFDbkIsbUJBQU87O01BRW5CO01BRUEsY0FBYyxNQUEwQjtBQUNwQyxnQkFBUSxLQUFLLGdCQUFnQjtVQUN6QixLQUFLLGVBQWU7QUFDaEIsbUJBQU87VUFDWCxLQUFLLGVBQWU7QUFDaEIsbUJBQU87VUFDWCxLQUFLLGVBQWU7QUFDaEIsbUJBQU87VUFDWCxLQUFLLGVBQWU7QUFDaEIsbUJBQU87O01BRW5CO01BT0EsZUFBZSxTQUFlO0FBQzFCLGNBQU0sVUFBVSxJQUFJLHVCQUF1QixPQUFPO0FBQ2xELGVBQU87VUFDSCxRQUFRLFdBQVc7VUFDbkIsU0FBUyxDQUFDLE9BQU87O01BRXpCO01BRUEsMkJBQXdCO0FBQ3BCLGVBQU8sS0FBSyxPQUFPLE9BQU8sb0JBQW9CLHVCQUF1QixLQUFLLE9BQU8sT0FBTyxvQkFBb0I7TUFDaEg7TUFFQSxpQkFBaUIsWUFBbUI7QUFDaEMsWUFBSSxZQUFZO0FBQ1osbUJBQVMsS0FBSyxVQUFVLElBQUksbUJBQW1CO2VBQzVDO0FBQ0gsbUJBQVMsS0FBSyxVQUFVLE9BQU8sbUJBQW1COztNQUUxRDtNQUVBLHlCQUFzQjtBQUNsQixlQUFPLENBQUMsS0FBSyxnQkFBZ0IsS0FBSyxhQUFjLENBQUMsQ0FBQyxLQUFLLFNBQVMsS0FBSyxNQUFNO01BQy9FO01BRUEsc0JBQW1CO0FBQ2YsZUFBTyxDQUFDLENBQUMsS0FBSyxTQUFTLEtBQUssTUFBTSxPQUFPLG9CQUFvQjtNQUNqRTtNQUVBLHdCQUF3QixPQUFxQjtBQUN6QyxZQUFJLE1BQU0sY0FBYyxVQUFVLE1BQU0sWUFBWSxTQUFTO0FBQ3pELGVBQUssWUFBWTs7QUFFckIsWUFBSSxNQUFNLGNBQWMsV0FBVyxNQUFNLFlBQVksT0FBTztBQUN4RCxlQUFLLDhCQUE4Qjs7TUFFM0M7TUFFQSx1QkFBb0I7QUFDaEIsWUFBSSxLQUFLLE9BQU8sV0FBVztBQUV2QixjQUFJLE9BQU8sS0FBSyxPQUFPLFVBQVUsT0FBTyxRQUFRLE1BQU0sWUFBWTtBQUM5RCxtQkFBTyxPQUFPLFlBQVksS0FBSyxNQUFNLFNBQVM7O0FBRWxELGlCQUFPLEtBQUssTUFBTTs7QUFFdEIsZUFBTztNQUNYO01BRUEsMkJBQXdCO0FBQ3BCLGVBQU8sS0FBSyxTQUFTLFNBQVMsS0FBTSxLQUFLLFNBQVMsV0FBVyxLQUFLLENBQUMsMkJBQTJCLEtBQUssU0FBUyxDQUFDLENBQUM7TUFDbEg7TUFFQSxtQkFBZ0I7QUFDWixhQUFLLGVBQWUsaUJBQWlCLEtBQUssVUFBVTtNQUN4RDtNQUVBLGdCQUFhO0FBQ1QsZUFBTyxLQUFLLDBCQUEwQjtNQUMxQztNQUVtQixhQUFhO01BQ2IsZUFBZTtNQUNmLGlCQUFpQjtNQUNqQixnQkFBZ0I7TUFDaEIsZ0JBQWdCO01BQ2hCLGlCQUFpQjtNQUNqQixXQUFXO01BQ1gsZUFBZTtNQUNmLHVCQUF1QjtNQUN2QixzQkFBc0I7TUFDdEIsNkJBQTZCOzt5QkFyekJ2Qyw2QkFBMEIsaUNBQUEsY0FBQSxHQUFBLGlDQThEdkIsZUFBZSxHQUFBLGlDQUFBLFdBQUEsR0FBQSxpQ0FBQSxVQUFBLEdBQUEsaUNBQUEsYUFBQSxHQUFBLGlDQUFBLFdBQUEsR0FBQSxpQ0FLZixRQUFRLEdBQUEsaUNBQUEsbUJBQUEsQ0FBQTtNQUFBO2tFQW5FWCw2QkFBMEIsV0FBQSxDQUFBLENBQUEsb0JBQUEsQ0FBQSxHQUFBLFdBQUEsU0FBQSxpQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7Ozs7Ozs7Ozs7Ozs7O0FDM0Z2QyxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQXVCLFVBQUEsMEJBQUEsY0FBQSxTQUFBLGdFQUFBO0FBQUEsbUJBQWMsSUFBQSxpQkFBaUIsSUFBSTtVQUFDLENBQUEsRUFBQyxjQUFBLFNBQUEsZ0VBQUE7QUFBQSxtQkFBZSxJQUFBLGlCQUFpQixLQUFLO1VBQUMsQ0FBQTtBQUM5RixVQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUNBLFVBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQ0EsVUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxNQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsaUJBQUEsQ0FBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxrREFBQTtBQUNBLFVBQUEsOEJBQUEsSUFBQSxLQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsNEJBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsV0FBQSxDQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsS0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsNEJBQUE7QUFBQSxVQUFBLDBCQUFBLElBQUEsb0RBQUEsR0FBQSxDQUFBLEVBSUMsSUFBQSxvREFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLG9EQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsb0RBQUEsR0FBQSxDQUFBO0FBZ0JELFVBQUEsOEJBQUEsSUFBQSxVQUFBLENBQUE7QUFBUSxVQUFBLDBCQUFBLFNBQUEsU0FBQSwrREFBQTtBQUFBLG1CQUFTLElBQUEsVUFBQTtVQUFXLENBQUE7QUFDeEIsVUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMEJBQUEsSUFBQSxvREFBQSxJQUFBLEdBQUEsZUFBQSxNQUFBLElBQUEscUNBQUE7QUFnQkEsVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLElBQUEsRUFBQTtBQUFpQyxVQUFBLDBCQUFBLFVBQUEsU0FBQSw2REFBQTtBQUFBLG1CQUFVLElBQUEsZ0JBQUE7VUFBaUIsQ0FBQTtBQUN4RCxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLGdDQUFBLElBQUEsNENBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx3Q0FBQTtBQXdIQSxVQUFBLDBCQUFBLElBQUEsb0RBQUEsR0FBQSxDQUFBLEVBVUMsSUFBQSxvREFBQSxJQUFBLENBQUE7QUFVRCxVQUFBLDhCQUFBLElBQUEsT0FBQSxJQUFBLEVBQUE7QUFBNEQsVUFBQSwwQkFBQSxTQUFBLFNBQUEsNERBQUE7QUFBQSxtQkFBUyxJQUFBLGVBQWUsUUFBUTtVQUFDLENBQUE7QUFDekYsVUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDBCQUFBLElBQUEsb0RBQUEsR0FBQSxDQUFBLEVBSUMsSUFBQSxvREFBQSxHQUFBLENBQUE7QUFNTCxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsWUFBQSxJQUFBLEVBQUE7QUFDSSxVQUFBLDBCQUFBLGlCQUFBLFNBQUEsdUVBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsd0JBQUE7VUFBQSxDQUFBLEVBQW1DLGlCQUFBLFNBQUEseUVBQUE7QUFBQSxtQkFHbEIsSUFBQSxZQUFBO1VBQWEsQ0FBQSxFQUhLLFNBQUEsU0FBQSxpRUFBQTtBQUFBLG1CQUkxQixJQUFBLFFBQUE7VUFBUyxDQUFBLEVBSmlCLFNBQUEsU0FBQSxpRUFBQTtBQUFBLG1CQUsxQixJQUFBLFFBQUE7VUFBUyxDQUFBLEVBTGlCLFdBQUEsU0FBQSxpRUFBQSxRQUFBO0FBQUEsbUJBT3hCLElBQUEsVUFBQSxNQUFBO1VBQWlCLENBQUE7O0FBRy9CLFVBQUEsNEJBQUE7QUFDRCxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsY0FBQSxFQUFBO0FBQTRCLFVBQUEsMEJBQUEsV0FBQSxTQUFBLHFFQUFBO0FBQUEsbUJBQVcsSUFBQSxPQUFBO1VBQVEsQ0FBQTtBQUMvQyxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLElBQUE7OztBQWxPbUMsVUFBQSx5QkFBQSxFQUFBO0FBQUEsVUFBQSwwQkFBQSxRQUFBLElBQUEsYUFBQSxLQUFBO0FBRVosVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxjQUFBLGFBQUE7QUFDVSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLFFBQUEsSUFBQSxZQUFBO0FBS1QsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLElBQUEsYUFBQSxJQUFBLEtBQUEsRUFBQTtBQUtBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLHlCQUFBLElBQUEsS0FBQSxFQUFBO0FBS0EsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLENBQUEsSUFBQSxXQUFBLEtBQUEsRUFBQTtBQUtBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLFdBQUEsS0FBQSxFQUFBO0FBTWEsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxRQUFBLElBQUEsT0FBQTtBQXdCekIsVUFBQSx5QkFBQSxFQUFBO0FBQUEsVUFBQSwwQkFBQSxJQUFBLFFBQUE7QUF3SEEsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLElBQUEsWUFBQSxLQUFBLEVBQUE7QUFXQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsQ0FBQSxJQUFBLGVBQUEsS0FBQSxFQUFBO0FBUzhCLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsVUFBQSxJQUFBLGtCQUFBO0FBQ2pCLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsUUFBQSxJQUFBLFdBQUE7QUFFYixVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsSUFBQSwrQkFBQSxJQUFBLFNBQUEsSUFBQSxvQkFBQSxJQUFBLEtBQUEsRUFBQTtBQUtBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLFNBQUEsQ0FBQSxJQUFBLG9CQUFBLElBQUEsS0FBQSxFQUFBO0FBaUJJLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEscUNBQUEsZUFBQSwyQkFBQSxJQUFBLElBQUEseUNBQUEsQ0FBQTtBQVJBLFVBQUEsMEJBQUEsV0FBQSxJQUFBLHFCQUFBO0FBVzZDLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsV0FBQSxJQUFBLFdBQUEsT0FBQSxFQUE4QixRQUFBLElBQUEsWUFBQSxFQUFBLFlBQUEsSUFBQSx1QkFBQSxDQUFBOztxMW9CRDNKM0U7UUFDUixRQUFRLGlCQUFpQjtVQUNyQixNQUNJLFNBQ0EsTUFBTTtZQUNGLFNBQVM7V0FDWixDQUFDO1VBRU4sTUFDSSxPQUNBLE1BQU07WUFDRixTQUFTO1dBQ1osQ0FBQztVQUVOLFdBQVcsZ0JBQWdCLENBQUMsUUFBUSxTQUFTLENBQUMsQ0FBQztTQUNsRDtRQUNKLEVBQUEsQ0FBQTs7O3NGQUVRLDRCQUEwQixFQUFBLFdBQUEsNkJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFM0Z2QyxTQUFTLGVBQWUsWUFBQUMsV0FBVSxxQkFBcUI7QUFDdkQsU0FBUyxhQUFBQyxtQkFBb0M7QUFDN0MsU0FBUyxhQUFBQyxrQkFBK0I7QUFFeEMsU0FBUyxlQUFlO0FBR3hCLFNBQVMsa0JBQUFDLHVCQUFzQjs7Ozs7QUFQL0IsSUFhc0I7QUFidEI7O0FBR0E7QUFFQTtBQUNBO0FBR0E7QUFDQTs7OztBQUdNLElBQWdCLDZCQUFoQixNQUFnQiw0QkFBMEI7TUFlakM7TUFDRztNQUNTO01BQ0E7TUFDWDtNQUNBO01BbkJaLFlBQTZEO01BQzdELFdBQVc7TUFDWCxpQkFBaUI7TUFDUDtNQUNBO01BQ0Y7TUFDQTtNQUdSLFdBQVdIO01BQ1gsZ0JBQWdCO01BQ2hCLGdCQUFnQjtNQUVoQixZQUNXLFFBQ0csU0FDUyxnQkFDQSxZQUNYLE9BQ0EsZUFBNEI7QUFMN0IsYUFBQSxTQUFBO0FBQ0csYUFBQSxVQUFBO0FBQ1MsYUFBQSxpQkFBQTtBQUNBLGFBQUEsYUFBQTtBQUNYLGFBQUEsUUFBQTtBQUNBLGFBQUEsZ0JBQUE7TUFDVDtNQUVILFdBQVE7QUFFSixhQUFLLE1BQU0sT0FBTyxVQUFVLENBQUMsV0FBVTtBQUNuQyxlQUFLLFdBQVcsU0FBUyxPQUFPLFVBQVUsR0FBRyxFQUFFO0FBQy9DLGVBQUssYUFBYSxTQUFTLE9BQU8sWUFBWSxHQUFHLEVBQUU7QUFDbkQsY0FBSSxLQUFLLGNBQWMsTUFBTTtBQUN6QixpQkFBSyxlQUFlLDBCQUEwQixLQUFLLFVBQVU7O1FBRXJFLENBQUM7QUFHRCxhQUFLLG9CQUFvQixLQUFLLFdBQVcsU0FBUSxFQUFHLFVBQVUsQ0FBQ0ksV0FBUztBQUNwRSxlQUFLLGlCQUFpQkEsT0FBTSxpQkFBaUI7UUFDakQsQ0FBQztBQUdELGFBQUssdUJBQXVCLEtBQUssY0FBYyxTQUFTLFVBQVUsQ0FBQyxTQUFVLEtBQUssV0FBVyxJQUFLO01BQ3RHO01BRUEsY0FBVztBQUVQLFlBQUksS0FBSyxXQUFXO0FBQ2hCLGVBQUssVUFBVSxNQUFLOztBQUd4QixhQUFLLGtCQUFrQixZQUFXO0FBQ2xDLGFBQUsscUJBQXFCLFlBQVc7TUFDekM7TUFPTyxvQkFBaUI7QUFDcEIsWUFBSSxLQUFLLFlBQVksS0FBSyxXQUFXO0FBQ2pDLGVBQUssV0FBVyxTQUFTLElBQUksMEJBQXlCLENBQUU7QUFDeEQsZUFBSyxPQUFPLFNBQVE7QUFDcEIsZUFBSyxXQUFXO2VBQ2I7QUFDSCxlQUFLLFNBQVE7QUFDYixlQUFLLFdBQVc7O01BRXhCO01BTUEsV0FBUTtBQUNKLGFBQUssV0FBVztBQUNoQixhQUFLLFlBQVksS0FBSyxPQUFPLEtBQUssNEJBQTRCO1VBQzFELGFBQWE7VUFDYixnQkFBZ0IsS0FBSyxRQUFRLGlCQUFpQixLQUFJO1VBQ2xELFVBQVUsRUFBRSxRQUFRLE9BQU8sT0FBTyxNQUFLO1VBQ3ZDLGNBQWM7VUFDZCxNQUFNO1lBQ0YsWUFBWSxLQUFLO1lBQ2pCLFVBQVUsS0FBSztZQUNmLFlBQVksS0FBSztZQUNqQixnQkFBZ0IsS0FBSzs7U0FFNUI7TUFDTDs7eUJBdEZrQiw2QkFBMEIsaUNBQUEsY0FBQSxHQUFBLGlDQUFBLFdBQUEsR0FBQSxpQ0FBQSxrQkFBQSxHQUFBLGlDQUFBLGNBQUEsR0FBQSxpQ0FBQSxrQkFBQSxHQUFBLGlDQUFBLGFBQUEsQ0FBQTtNQUFBO2tFQUExQiw2QkFBMEIsV0FBQSxDQUFBLENBQUEsY0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxVQUFBLFNBQUEsb0NBQUEsSUFBQSxLQUFBO01BQUEsR0FBQSxlQUFBLEVBQUEsQ0FBQTs7O3NGQUExQiw0QkFBMEIsRUFBQSxXQUFBLDZCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBQ1poRCxTQUFTLGNBQUFDLG9CQUE2Qjs7QUFBdEMsSUEwQnNCO0FBMUJ0QixJQUFBQywwQkFBQTs7QUFDQTtBQUNBO0FBQ0E7QUFRQTtBQUNBO0FBY00sSUFBZ0IsdUJBQWhCLE1BQWdCLHNCQUFvQjtNQVd4QjtNQUNBO01BQ0E7TUFaTjtNQUNBO01BUVIsWUFDYyxxQkFDQSxZQUNBLGFBQW1CO0FBRm5CLGFBQUEsc0JBQUE7QUFDQSxhQUFBLGFBQUE7QUFDQSxhQUFBLGNBQUE7QUFHVixhQUFLLHNCQUFzQixLQUFLLFdBQVcsb0JBQW1CLEVBQUcsVUFBVSxDQUFDLGNBQWlDO0FBQ3pHLGNBQUksQ0FBQyx3QkFBd0IsU0FBUztBQUFHO0FBQ3pDLGVBQUssNEJBQTRCLFVBQVUsU0FBUztRQUN4RCxDQUFDO01BQ0w7TUFLQSxjQUFXO0FBRVAsWUFBSSxLQUFLLHFCQUFxQjtBQUMxQixlQUFLLG9CQUFvQixZQUFZLEtBQUssbUJBQW1COztBQUdqRSxhQUFLLG9CQUFvQixZQUFXO01BQ3hDO01BTVEsNEJBQTRCLFdBQXdCO0FBQ3hELGNBQU0sVUFBVSxzQkFBc0IsS0FBSyxjQUFjLE1BQU07QUFFL0QsWUFBSSxhQUFhLFFBQVEsS0FBSyx3QkFBd0IsU0FBUztBQUMzRDs7QUFHSixZQUFJLEtBQUsscUJBQXFCO0FBQzFCLGVBQUssb0JBQW9CLFlBQVksS0FBSyxtQkFBbUI7O0FBR2pFLFlBQUksYUFBYTtBQUFNO0FBRXZCLGFBQUssc0JBQXNCO0FBQzNCLGFBQUssb0JBQW9CLFVBQVUsS0FBSyxtQkFBbUI7QUFDM0QsYUFBSyxvQkFBb0IsUUFBUSxLQUFLLG1CQUFtQixFQUFFLFVBQVUsQ0FBQyxhQUFpQjtBQUNuRixlQUFLLHdCQUF3QixRQUFRO1FBQ3pDLENBQUM7TUFDTDtNQUlVLGNBQWMsU0FBcUI7QUFDekMsWUFBSSxDQUFDO0FBQVM7QUFDZCxZQUFJLHFCQUFxQixPQUFPLEdBQUc7QUFDL0IsZUFBSyxXQUFXLFNBQ1osSUFBSSx5QkFDQSxTQUNBLFdBQVcsTUFBSztBQUVaLGlCQUFLLFdBQVcsU0FBUyxJQUFJLGdDQUFnQyxvQkFBb0IsNEJBQTRCLENBQUM7VUFDbEgsR0FBRyxHQUFLLENBQUMsQ0FDWjttQkFFRSxvQkFBb0IsT0FBTyxHQUFHO0FBQ3JDLGVBQUssV0FBVyxTQUFTLElBQUksc0NBQXNDLE9BQU8sQ0FBQzs7TUFFbkY7TUFFVSxZQUFZLHFCQUEyQyxtQkFBb0M7QUFDakcsWUFBSSxDQUFDLHFCQUFxQjtBQUN0QixlQUFLLFdBQVcsU0FBUyxJQUFJLGdDQUFnQyxvQkFBb0Isd0JBQXdCLENBQUM7ZUFDdkc7QUFDSCxlQUFLLFdBQVcsU0FBUyxJQUFJLGdDQUFnQyxxQkFBcUIsaUJBQWlCLENBQUM7O01BRTVHO01BRVUsb0JBQW9CLGVBQXVDO0FBQ2pFLGFBQUssV0FBVyxTQUFTLElBQUksdUJBQXVCLGFBQWEsQ0FBQztNQUN0RTs7OztxRUF2RmtCLHVCQUFvQixTQUFwQixzQkFBb0IsVUFBQSxDQUFBOzs7Ozs7QUMzQjFDLFNBQVMsY0FBQUMsb0JBQWtCO0FBTTNCLFNBQXFCLFdBQUFDLGdCQUFlOztBQU5wQyxJQVlZLG9DQW1EQztBQS9EYjs7QUFDQTtBQUNBO0FBQ0EsSUFBQUM7OztBQVNBLEtBQUEsU0FBWUMscUNBQWtDO0FBQzFDLE1BQUFBLG9DQUFBLFNBQUEsSUFBQTtBQUNBLE1BQUFBLG9DQUFBLGNBQUEsSUFBQTtBQUNBLE1BQUFBLG9DQUFBLGdCQUFBLElBQUE7QUFDQSxNQUFBQSxvQ0FBQSxPQUFBLElBQUE7SUFDSixHQUxZLHVDQUFBLHFDQUFrQyxDQUFBLEVBQUE7QUFtRHhDLElBQU8saUNBQVAsTUFBTyx3Q0FBdUMscUJBQW9CO01BQzVELGNBQTZDLElBQUlGLFNBQU87TUFDeEQsZ0JBQWlELElBQUlBLFNBQU87TUFPcEUsWUFBWSxxQkFBMEMsWUFBMEI7QUFDNUUsY0FBTSxxQkFBcUIsWUFBWSxzQkFBc0I7TUFDakU7TUFFVSx3QkFBd0IsVUFBb0M7QUFDbEUsWUFBSSxTQUFTLGVBQWU7QUFDeEIsZ0JBQU0sb0JBQW9CLFNBQVMsYUFBYTs7QUFFcEQsZ0JBQVEsU0FBUyxNQUFNO1VBQ25CLEtBQUssbUNBQW1DO0FBQ3BDLGtCQUFNLGNBQWMsU0FBUyxPQUFPO0FBQ3BDO1VBQ0osS0FBSyxtQ0FBbUM7QUFDcEMsaUJBQUssa0JBQWtCLFNBQVMsb0JBQXFCO0FBQ3JEO1VBQ0osS0FBSyxtQ0FBbUM7QUFDcEMsaUJBQUssb0JBQW9CLFNBQVMsa0JBQW1CO0FBQ3JEO1VBQ0osS0FBSyxtQ0FBbUM7QUFDcEMsa0JBQU0sWUFBWSxTQUFTLHFCQUFxQixTQUFTLGlCQUFpQjtBQUMxRTs7TUFFWjtNQUVRLGtCQUFrQixVQUE4QjtBQUNwRCxhQUFLLFlBQVksS0FBSyxRQUFRO01BQ2xDO01BRVEsb0JBQW9CLFVBQWdDO0FBQ3hELGFBQUssY0FBYyxLQUFLLFFBQVE7TUFDcEM7TUFNTyxnQkFBYTtBQUNoQixlQUFPLEtBQUssWUFBWSxhQUFZO01BQ3hDO01BTU8sa0JBQWU7QUFDbEIsZUFBTyxLQUFLLGNBQWMsYUFBWTtNQUMxQzs7eUJBdkRTLGlDQUE4Qix3QkFBQSxtQkFBQSxHQUFBLHdCQUFBLGNBQUEsQ0FBQTtNQUFBO3FFQUE5QixpQ0FBOEIsU0FBOUIsZ0NBQThCLFVBQUEsQ0FBQTs7Ozs7O0FDL0QzQyxTQUFTLGFBQUFHLG1CQUFpQjtBQUMxQixTQUFTLGFBQUFDLGtCQUFpQjtBQUMxQixTQUFTLFdBQUFDLGdCQUFlO0FBRXhCLFNBQVMsa0JBQUFDLHVCQUFzQjs7Ozs7QUFKL0IsSUFnQmE7QUFoQmI7O0FBR0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7O0FBT00sSUFBTyx1Q0FBUCxNQUFPLDhDQUE2QywyQkFBMEI7TUFDN0QsZUFBZTtNQUVsQyxZQUNJLFFBQ0EsU0FDQSwwQkFDQSxZQUVBLGtCQUNBLE9BQ0EsZUFBNEI7QUFFNUIsY0FBTSxRQUFRLFNBQVMsMEJBQTBCLFlBQVksT0FBTyxhQUFhO01BQ3JGOzt5QkFkUyx1Q0FBb0MsaUNBQUEsY0FBQSxHQUFBLGlDQUFBLFdBQUEsR0FBQSxpQ0FBQSw0QkFBQSxHQUFBLGlDQUFBLGNBQUEsR0FBQSxpQ0FBQSw4QkFBQSxHQUFBLGlDQUFBLGtCQUFBLEdBQUEsaUNBQUEsYUFBQSxDQUFBO01BQUE7a0VBQXBDLHVDQUFvQyxXQUFBLENBQUEsQ0FBQSxnQ0FBQSxDQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUZsQyxDQUFDLDRCQUE0QixDQUFDLEdBQUEseUNBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLFFBQUEsU0FBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsOENBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNkN0MsVUFBQSw4QkFBQSxHQUFBLEtBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxpQkFBQSxDQUFBO0FBSUksVUFBQSwwQkFBQSxTQUFBLFNBQUEsK0VBQUE7QUFBQSxtQkFBUyxJQUFBLGtCQUFBO1VBQW1CLENBQUE7O0FBQy9CLFVBQUEsNEJBQUE7QUFDTCxVQUFBLHNCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLEdBQUEsSUFBQTs7O0FBSlEsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxxQ0FBQSxTQUFBLDJCQUFBLEdBQUEsR0FBQSwwQ0FBQSxDQUFBO0FBRkEsVUFBQSwwQkFBQSxRQUFBLElBQUEsYUFBQSxLQUFBOzs7OztzRkRjSyxzQ0FBb0MsRUFBQSxXQUFBLHVDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRWhCakQsU0FBUyxjQUFBQyxvQkFBa0I7O0FBQTNCLElBVVksOEJBcUJDO0FBL0JiOztBQUNBO0FBQ0E7QUFDQSxJQUFBQzs7O0FBT0EsS0FBQSxTQUFZQywrQkFBNEI7QUFDcEMsTUFBQUEsOEJBQUEsU0FBQSxJQUFBO0FBQ0EsTUFBQUEsOEJBQUEsT0FBQSxJQUFBO0lBQ0osR0FIWSxpQ0FBQSwrQkFBNEIsQ0FBQSxFQUFBO0FBcUJsQyxJQUFPLDJCQUFQLE1BQU8sa0NBQWlDLHFCQUFvQjtNQU05RCxZQUFZLHFCQUEwQyxZQUEwQjtBQUM1RSxjQUFNLHFCQUFxQixZQUFZLFVBQVU7TUFDckQ7TUFFVSx3QkFBd0IsVUFBOEI7QUFDNUQsWUFBSSxTQUFTLGVBQWU7QUFDeEIsZ0JBQU0sb0JBQW9CLFNBQVMsYUFBYTs7QUFFcEQsZ0JBQVEsU0FBUyxNQUFNO1VBQ25CLEtBQUssNkJBQTZCO0FBQzlCLGtCQUFNLGNBQWMsU0FBUyxPQUFPO0FBQ3BDO1VBQ0osS0FBSyw2QkFBNkI7QUFDOUIsa0JBQU0sWUFBWSxTQUFTLHFCQUFxQixTQUFTLGlCQUFpQjtBQUMxRTs7TUFFWjs7eUJBdEJTLDJCQUF3Qix3QkFBQSxtQkFBQSxHQUFBLHdCQUFBLGNBQUEsQ0FBQTtNQUFBO3FFQUF4QiwyQkFBd0IsU0FBeEIsMEJBQXdCLFVBQUEsQ0FBQTs7Ozs7O0FDL0JyQyxTQUFTLGNBQUFDLG9CQUE2QjtBQU10QyxTQUF1QixrQkFBQUMsdUJBQXNCOztBQU43QyxJQWVhO0FBZmI7O0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTs7OztBQVFNLElBQU8sdUJBQVAsTUFBTyxzQkFBb0I7TUFhakI7TUFDQTtNQUNBO01BZFo7TUFDUTtNQUNSO01BQ0EsZUFBZTtNQVFmLFlBQ1ksa0JBQ0EsWUFDQSxvQkFBOEM7QUFGOUMsYUFBQSxtQkFBQTtBQUNBLGFBQUEsYUFBQTtBQUNBLGFBQUEscUJBQUE7QUFHUixhQUFLLHNCQUFzQixLQUFLLFdBQVcsb0JBQW1CLEVBQUcsVUFBVSxDQUFDLGNBQWlDO0FBQ3pHLGNBQUksQ0FBQyx3QkFBd0IsU0FBUztBQUFHO0FBQ3pDLGNBQUksS0FBSyxlQUFlO0FBQVcsMEJBQWMsS0FBSyxVQUFVO0FBQ2hFLGVBQUssZUFBZSxVQUFVLFNBQVM7QUFDdkMsZUFBSyxhQUFhLFlBQVksTUFBSztBQUMvQixpQkFBSyxlQUFlLFVBQVUsU0FBUztVQUMzQyxHQUFHLEdBQUs7UUFDWixDQUFDO0FBQ0QsYUFBSyw4QkFBOEIsS0FBSyxpQkFBaUIsZ0JBQWdCLFVBQVUsQ0FBQyxXQUFVO0FBQzFGLGVBQUssZUFBZSxDQUFDLE9BQU8sYUFBYSxDQUFDLE9BQU8sc0JBQXNCLE9BQU87UUFDbEYsQ0FBQztNQUNMO01BT1EsZUFBZSxXQUFpQjtBQUNwQyxZQUFJLEtBQUs7QUFBYztBQUN2QixRQUFBQSxnQkFBZSxLQUFLLG1CQUFtQixhQUFhLFNBQVMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxhQUF3QztBQUMxRyxjQUFJLFNBQVMsTUFBTTtBQUNmLGdCQUFJLENBQUMsU0FBUyxLQUFLLFFBQVE7QUFDdkIsbUJBQUssV0FBVyxTQUFTLElBQUksZ0NBQWdDLG9CQUFvQixrQkFBa0IsQ0FBQzs7QUFFeEcsaUJBQUssV0FBVyxTQUFTLElBQUksdUJBQXVCLFNBQVMsS0FBTSxhQUFhLENBQUM7aUJBQzlFO0FBQ0gsaUJBQUssV0FBVyxTQUFTLElBQUksZ0NBQWdDLG9CQUFvQixrQkFBa0IsQ0FBQzs7UUFFNUcsQ0FBQztNQUNMO01BTUEsY0FBVztBQUNQLFlBQUksS0FBSyxlQUFlO0FBQVcsd0JBQWMsS0FBSyxVQUFVO0FBRWhFLGFBQUssb0JBQW9CLFlBQVc7QUFDcEMsYUFBSyw0QkFBNEIsWUFBVztNQUNoRDs7eUJBM0RTLHVCQUFvQix3QkFBQSxtQkFBQSxHQUFBLHdCQUFBLGNBQUEsR0FBQSx3QkFBQSwwQkFBQSxDQUFBO01BQUE7cUVBQXBCLHVCQUFvQixTQUFwQixzQkFBb0IsVUFBQSxDQUFBOzs7Ozs7QUNmakMsU0FBUyxhQUFBQyxtQkFBaUI7QUFDMUIsU0FBUyxhQUFBQyxrQkFBaUI7QUFDMUIsU0FBUyxXQUFBQyxnQkFBZTtBQUd4QixTQUFTLGtCQUFBQyx1QkFBc0I7Ozs7Ozs7O0FDRG5CLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsWUFBQTs7OztBQURhLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxPQUFBLFFBQUE7Ozs7OztBQUhqQixJQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxpQkFBQSxDQUFBO0FBQWdGLElBQUEsMEJBQUEsU0FBQSxTQUFBLHdGQUFBO0FBQUEsTUFBQSw2QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBO0FBQUEsYUFBUywyQkFBQSxPQUFBLGtCQUFBLENBQW1CO0lBQUEsQ0FBQTtBQUE1RyxJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDBCQUFBLEdBQUEsc0VBQUEsR0FBQSxDQUFBO0FBR0osSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxJQUFBOzs7O0FBTHVCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxPQUFBLGFBQUEsTUFBQSxFQUE0QixRQUFBLE9BQUEsc0JBQUEsSUFBQTtBQUMzQyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxpQkFBQSxJQUFBLEVBQUE7OztBREhSLElBa0JhO0FBbEJiOztBQUdBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7O0FBUU0sSUFBTyxrQ0FBUCxNQUFPLHlDQUF3QywyQkFBMEI7TUFDeEQsZUFBZTtNQUNmLHdCQUF3QjtNQUUzQyxZQUNJLFFBQ0EsU0FDQSxnQkFDQSxZQUVBLGtCQUNBLGtCQUNBLE9BQ0EsZUFBNEI7QUFFNUIsY0FBTSxRQUFRLFNBQVMsZ0JBQWdCLFlBQVksT0FBTyxhQUFhO01BQzNFOzt5QkFoQlMsa0NBQStCLGlDQUFBLGNBQUEsR0FBQSxpQ0FBQSxXQUFBLEdBQUEsaUNBQUEsc0JBQUEsR0FBQSxpQ0FBQSxjQUFBLEdBQUEsaUNBQUEsd0JBQUEsR0FBQSxpQ0FBQSxvQkFBQSxHQUFBLGlDQUFBLGtCQUFBLEdBQUEsaUNBQUEsYUFBQSxDQUFBO01BQUE7a0VBQS9CLGtDQUErQixXQUFBLENBQUEsQ0FBQSwwQkFBQSxDQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUY3QixDQUFDLDBCQUEwQix3QkFBd0Isb0JBQW9CLENBQUMsR0FBQSx5Q0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFFBQUEsT0FBQSxHQUFBLENBQUEsUUFBQSxNQUFBLEdBQUEsb0JBQUEsR0FBQSxNQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEseUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNoQnZGLFVBQUEsMEJBQUEsR0FBQSx3REFBQSxHQUFBLENBQUE7OztBQUFBLFVBQUEsNkJBQUEsR0FBQSxDQUFBLElBQUEsV0FBQSxJQUFBLEVBQUE7Ozs7O3NGRGtCYSxpQ0FBK0IsRUFBQSxXQUFBLGtDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRWxCNUMsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyx5QkFBeUI7QUFJbEMsU0FBUyxvQkFBb0I7O0FBUjdCLElBaURhO0FBakRiOztBQUtBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUF3Qk0sSUFBTyxhQUFQLE1BQU8sWUFBVTs7eUJBQVYsYUFBVTtNQUFBO2lFQUFWLFlBQVUsQ0FBQTtzRUFIUixDQUFDLGdDQUFnQyxjQUFjLEdBQUMsU0FBQSxDQURqRCxjQUFjLGlCQUFpQixhQUFhLG1CQUFtQixxQkFBcUIsdUJBQXVCLDhCQUE4QixZQUFZLEVBQUEsQ0FBQTs7OzsiLCJuYW1lcyI6WyJJcmlzU2V0dGluZ3NUeXBlIiwibW9kZWwiLCJDb21wb25lbnQiLCJFdmVudEVtaXR0ZXIiLCJJbnB1dCIsIk91dHB1dCIsIkNvbXBvbmVudCIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwiQ29tcG9uZW50IiwiRXZlbnRFbWl0dGVyIiwiSW5wdXQiLCJPdXRwdXQiLCJDb21wb25lbnQiLCJFdmVudEVtaXR0ZXIiLCJJbnB1dCIsIk91dHB1dCIsIkNvbXBvbmVudCIsIklucHV0IiwiQ29tcG9uZW50IiwiQ29tcG9uZW50IiwiSW5wdXQiLCJWaWV3Q2hpbGQiLCJDb21wb25lbnQiLCJJbnB1dCIsIlZpZXdDaGlsZCIsIkFjdGl2YXRlZFJvdXRlIiwiSXJpc0Vycm9yTWVzc2FnZUtleSIsIm1hcCIsIkFjdGlvblR5cGUiLCJJcmlzU2VuZGVyIiwic3RhdGUiLCJJbmplY3RhYmxlIiwiQmVoYXZpb3JTdWJqZWN0IiwiSXJpc01lc3NhZ2VDb250ZW50VHlwZSIsIkV4ZXJjaXNlQ29tcG9uZW50IiwiRXhlY3V0aW9uU3RhZ2UiLCJJbmplY3RhYmxlIiwiSW5qZWN0YWJsZSIsIkh0dHBDbGllbnQiLCJtYXAiLCJ0YXAiLCJJbmplY3RhYmxlIiwiSW5qZWN0YWJsZSIsIkluamVjdGFibGUiLCJIdHRwQ2xpZW50IiwiSW5qZWN0YWJsZSIsIkluamVjdGFibGUiLCJIdHRwQ2xpZW50IiwiSW5qZWN0YWJsZSIsIkluamVjdGFibGUiLCJmaXJzdFZhbHVlRnJvbSIsImZhVHJhc2giLCJDb21wb25lbnQiLCJWaWV3Q2hpbGQiLCJkb2N1bWVudCIsInN0YXRlIiwibWFwIiwiZmFDaXJjbGUiLCJDb21wb25lbnQiLCJNYXREaWFsb2ciLCJBY3RpdmF0ZWRSb3V0ZSIsInN0YXRlIiwiSW5qZWN0YWJsZSIsImluaXRfd2Vic29ja2V0X3NlcnZpY2UiLCJJbmplY3RhYmxlIiwiU3ViamVjdCIsImluaXRfd2Vic29ja2V0X3NlcnZpY2UiLCJJcmlzQ29kZUVkaXRvcldlYnNvY2tldE1lc3NhZ2VUeXBlIiwiQ29tcG9uZW50IiwiTWF0RGlhbG9nIiwiT3ZlcmxheSIsIkFjdGl2YXRlZFJvdXRlIiwiSW5qZWN0YWJsZSIsImluaXRfd2Vic29ja2V0X3NlcnZpY2UiLCJJcmlzQ2hhdFdlYnNvY2tldE1lc3NhZ2VUeXBlIiwiSW5qZWN0YWJsZSIsImZpcnN0VmFsdWVGcm9tIiwiQ29tcG9uZW50IiwiTWF0RGlhbG9nIiwiT3ZlcmxheSIsIkFjdGl2YXRlZFJvdXRlIl19