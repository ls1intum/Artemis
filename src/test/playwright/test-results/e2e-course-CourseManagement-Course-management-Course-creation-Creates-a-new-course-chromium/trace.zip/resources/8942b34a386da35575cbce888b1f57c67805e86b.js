import {
  EntityTitleService,
  EntityType,
  __esm,
  createRequestOption,
  init_entity_title_service,
  init_request_util
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/quiz/manage/apollon-diagrams/apollon-diagram.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var ApollonDiagramService;
var init_apollon_diagram_service = __esm({
  "src/main/webapp/app/exercises/quiz/manage/apollon-diagrams/apollon-diagram.service.ts"() {
    init_request_util();
    init_entity_title_service();
    init_entity_title_service();
    ApollonDiagramService = class _ApollonDiagramService {
      http;
      entityTitleService;
      resourceUrl = "api";
      constructor(http, entityTitleService) {
        this.http = http;
        this.entityTitleService = entityTitleService;
      }
      create(apollonDiagram, courseId) {
        const copy = this.convert(apollonDiagram);
        return this.http.post(`${this.resourceUrl}/course/${courseId}/apollon-diagrams`, copy, { observe: "response" });
      }
      update(apollonDiagram, courseId) {
        const copy = this.convert(apollonDiagram);
        return this.http.put(`${this.resourceUrl}/course/${courseId}/apollon-diagrams`, copy, { observe: "response" });
      }
      find(diagramId, courseId) {
        return this.http.get(`${this.resourceUrl}/course/${courseId}/apollon-diagrams/${diagramId}`, { observe: "response" }).pipe(tap((res) => this.sendTitlesToEntityTitleService(res?.body)));
      }
      delete(diagramId, courseId) {
        return this.http.delete(`${this.resourceUrl}/course/${courseId}/apollon-diagrams/${diagramId}`, { observe: "response" });
      }
      getDiagramsByCourse(courseId) {
        const options = createRequestOption(courseId);
        return this.http.get(`${this.resourceUrl}/course/${courseId}/apollon-diagrams`, { params: options, observe: "response" }).pipe(tap((res) => res?.body?.forEach(this.sendTitlesToEntityTitleService.bind(this))));
      }
      convert(apollonDiagram) {
        return Object.assign({}, apollonDiagram);
      }
      sendTitlesToEntityTitleService(diagram) {
        this.entityTitleService.setTitle(EntityType.DIAGRAM, [diagram?.id], diagram?.title);
      }
      static \u0275fac = function ApollonDiagramService_Factory(t) {
        return new (t || _ApollonDiagramService)(i0.\u0275\u0275inject(i1.HttpClient), i0.\u0275\u0275inject(EntityTitleService));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _ApollonDiagramService, factory: _ApollonDiagramService.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  ApollonDiagramService,
  init_apollon_diagram_service
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3F1aXovbWFuYWdlL2Fwb2xsb24tZGlhZ3JhbXMvYXBvbGxvbi1kaWFncmFtLnNlcnZpY2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgdGFwIH0gZnJvbSAncnhqcyc7XG5cbmltcG9ydCB7IEFwb2xsb25EaWFncmFtIH0gZnJvbSAnYXBwL2VudGl0aWVzL2Fwb2xsb24tZGlhZ3JhbS5tb2RlbCc7XG5pbXBvcnQgeyBjcmVhdGVSZXF1ZXN0T3B0aW9uIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL3JlcXVlc3QudXRpbCc7XG5pbXBvcnQgeyBFbnRpdHlUaXRsZVNlcnZpY2UsIEVudGl0eVR5cGUgfSBmcm9tICdhcHAvc2hhcmVkL2xheW91dHMvbmF2YmFyL2VudGl0eS10aXRsZS5zZXJ2aWNlJztcblxuZXhwb3J0IHR5cGUgRW50aXR5UmVzcG9uc2VUeXBlID0gSHR0cFJlc3BvbnNlPEFwb2xsb25EaWFncmFtPjtcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBBcG9sbG9uRGlhZ3JhbVNlcnZpY2Uge1xuICAgIHByaXZhdGUgcmVzb3VyY2VVcmwgPSAnYXBpJztcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQsXG4gICAgICAgIHByaXZhdGUgZW50aXR5VGl0bGVTZXJ2aWNlOiBFbnRpdHlUaXRsZVNlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBkaWFncmFtLlxuICAgICAqIEBwYXJhbSBhcG9sbG9uRGlhZ3JhbSAtIGFwb2xsb25EaWFncmFtIHRvIGJlIGNyZWF0ZWQuXG4gICAgICogQHBhcmFtIGNvdXJzZUlkIC0gaWQgb2YgdGhlIGNvdXJzZS5cbiAgICAgKi9cbiAgICBjcmVhdGUoYXBvbGxvbkRpYWdyYW06IEFwb2xsb25EaWFncmFtLCBjb3Vyc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxFbnRpdHlSZXNwb25zZVR5cGU+IHtcbiAgICAgICAgY29uc3QgY29weSA9IHRoaXMuY29udmVydChhcG9sbG9uRGlhZ3JhbSk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxBcG9sbG9uRGlhZ3JhbT4oYCR7dGhpcy5yZXNvdXJjZVVybH0vY291cnNlLyR7Y291cnNlSWR9L2Fwb2xsb24tZGlhZ3JhbXNgLCBjb3B5LCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlcyBkaWFncmFtLlxuICAgICAqIEBwYXJhbSBhcG9sbG9uRGlhZ3JhbSAtIGFwb2xsb25EaWFncmFtIHRvIGJlIHVwZGF0ZWQuXG4gICAgICogQHBhcmFtIGNvdXJzZUlkIC0gaWQgb2YgdGhlIGNvdXJzZS5cbiAgICAgKi9cbiAgICB1cGRhdGUoYXBvbGxvbkRpYWdyYW06IEFwb2xsb25EaWFncmFtLCBjb3Vyc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxFbnRpdHlSZXNwb25zZVR5cGU+IHtcbiAgICAgICAgY29uc3QgY29weSA9IHRoaXMuY29udmVydChhcG9sbG9uRGlhZ3JhbSk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucHV0PEFwb2xsb25EaWFncmFtPihgJHt0aGlzLnJlc291cmNlVXJsfS9jb3Vyc2UvJHtjb3Vyc2VJZH0vYXBvbGxvbi1kaWFncmFtc2AsIGNvcHksIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBGaW5kcyBkaWFncmFtLlxuICAgICAqIEBwYXJhbSBkaWFncmFtSWQgLSBpZCBvZiBkaWFncmFtIHRvIGJlIGZvdW5kLlxuICAgICAqIEBwYXJhbSBjb3Vyc2VJZCAtIGlkIG9mIHRoZSBjb3Vyc2UuXG4gICAgICovXG4gICAgZmluZChkaWFncmFtSWQ6IG51bWJlciwgY291cnNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5nZXQ8QXBvbGxvbkRpYWdyYW0+KGAke3RoaXMucmVzb3VyY2VVcmx9L2NvdXJzZS8ke2NvdXJzZUlkfS9hcG9sbG9uLWRpYWdyYW1zLyR7ZGlhZ3JhbUlkfWAsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KVxuICAgICAgICAgICAgLnBpcGUodGFwKChyZXMpID0+IHRoaXMuc2VuZFRpdGxlc1RvRW50aXR5VGl0bGVTZXJ2aWNlKHJlcz8uYm9keSkpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEZWxldGVzIGRpYWdyYW0gd2l0aCB0aGF0IGlkLlxuICAgICAqIEBwYXJhbSBkaWFncmFtSWQgLSBpZCBvZiBkaWFncmFtIHRvIGJlIGRlbGV0ZWQuXG4gICAgICogQHBhcmFtIGNvdXJzZUlkIC0gaWQgb2YgdGhlIGNvdXJzZS5cbiAgICAgKi9cbiAgICBkZWxldGUoZGlhZ3JhbUlkOiBudW1iZXIsIGNvdXJzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTx2b2lkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmRlbGV0ZTx2b2lkPihgJHt0aGlzLnJlc291cmNlVXJsfS9jb3Vyc2UvJHtjb3Vyc2VJZH0vYXBvbGxvbi1kaWFncmFtcy8ke2RpYWdyYW1JZH1gLCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0cyBhbGwgYXBvbGxvbiBkaWFncmFtcyB0aGF0IGJlbG9uZyB0byB0aGUgY291cnNlIHdpdGggdGhlIGlkIGNvdXJzZUlkLlxuICAgICAqL1xuICAgIGdldERpYWdyYW1zQnlDb3Vyc2UoY291cnNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPEFwb2xsb25EaWFncmFtW10+PiB7XG4gICAgICAgIGNvbnN0IG9wdGlvbnMgPSBjcmVhdGVSZXF1ZXN0T3B0aW9uKGNvdXJzZUlkKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLmdldDxBcG9sbG9uRGlhZ3JhbVtdPihgJHt0aGlzLnJlc291cmNlVXJsfS9jb3Vyc2UvJHtjb3Vyc2VJZH0vYXBvbGxvbi1kaWFncmFtc2AsIHsgcGFyYW1zOiBvcHRpb25zLCBvYnNlcnZlOiAncmVzcG9uc2UnIH0pXG4gICAgICAgICAgICAucGlwZSh0YXAoKHJlcykgPT4gcmVzPy5ib2R5Py5mb3JFYWNoKHRoaXMuc2VuZFRpdGxlc1RvRW50aXR5VGl0bGVTZXJ2aWNlLmJpbmQodGhpcykpKSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBjb252ZXJ0KGFwb2xsb25EaWFncmFtOiBBcG9sbG9uRGlhZ3JhbSk6IEFwb2xsb25EaWFncmFtIHtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oe30sIGFwb2xsb25EaWFncmFtKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHNlbmRUaXRsZXNUb0VudGl0eVRpdGxlU2VydmljZShkaWFncmFtOiBBcG9sbG9uRGlhZ3JhbSB8IHVuZGVmaW5lZCB8IG51bGwpIHtcbiAgICAgICAgdGhpcy5lbnRpdHlUaXRsZVNlcnZpY2Uuc2V0VGl0bGUoRW50aXR5VHlwZS5ESUFHUkFNLCBbZGlhZ3JhbT8uaWRdLCBkaWFncmFtPy50aXRsZSk7XG4gICAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBZ0M7QUFDekMsU0FBcUIsV0FBVzs7O0FBRmhDLElBV2E7QUFYYjs7QUFLQTtBQUNBOztBQUtNLElBQU8sd0JBQVAsTUFBTyx1QkFBcUI7TUFJbEI7TUFDQTtNQUpKLGNBQWM7TUFFdEIsWUFDWSxNQUNBLG9CQUFzQztBQUR0QyxhQUFBLE9BQUE7QUFDQSxhQUFBLHFCQUFBO01BQ1Q7TUFPSCxPQUFPLGdCQUFnQyxVQUFnQjtBQUNuRCxjQUFNLE9BQU8sS0FBSyxRQUFRLGNBQWM7QUFDeEMsZUFBTyxLQUFLLEtBQUssS0FBcUIsR0FBRyxLQUFLLFdBQVcsV0FBVyxRQUFRLHFCQUFxQixNQUFNLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDbEk7TUFPQSxPQUFPLGdCQUFnQyxVQUFnQjtBQUNuRCxjQUFNLE9BQU8sS0FBSyxRQUFRLGNBQWM7QUFDeEMsZUFBTyxLQUFLLEtBQUssSUFBb0IsR0FBRyxLQUFLLFdBQVcsV0FBVyxRQUFRLHFCQUFxQixNQUFNLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDakk7TUFPQSxLQUFLLFdBQW1CLFVBQWdCO0FBQ3BDLGVBQU8sS0FBSyxLQUNQLElBQW9CLEdBQUcsS0FBSyxXQUFXLFdBQVcsUUFBUSxxQkFBcUIsU0FBUyxJQUFJLEVBQUUsU0FBUyxXQUFVLENBQUUsRUFDbkgsS0FBSyxJQUFJLENBQUMsUUFBUSxLQUFLLCtCQUErQixLQUFLLElBQUksQ0FBQyxDQUFDO01BQzFFO01BT0EsT0FBTyxXQUFtQixVQUFnQjtBQUN0QyxlQUFPLEtBQUssS0FBSyxPQUFhLEdBQUcsS0FBSyxXQUFXLFdBQVcsUUFBUSxxQkFBcUIsU0FBUyxJQUFJLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDakk7TUFLQSxvQkFBb0IsVUFBZ0I7QUFDaEMsY0FBTSxVQUFVLG9CQUFvQixRQUFRO0FBQzVDLGVBQU8sS0FBSyxLQUNQLElBQXNCLEdBQUcsS0FBSyxXQUFXLFdBQVcsUUFBUSxxQkFBcUIsRUFBRSxRQUFRLFNBQVMsU0FBUyxXQUFVLENBQUUsRUFDekgsS0FBSyxJQUFJLENBQUMsUUFBUSxLQUFLLE1BQU0sUUFBUSxLQUFLLCtCQUErQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7TUFDOUY7TUFFUSxRQUFRLGdCQUE4QjtBQUMxQyxlQUFPLE9BQU8sT0FBTyxDQUFBLEdBQUksY0FBYztNQUMzQztNQUVRLCtCQUErQixTQUEwQztBQUM3RSxhQUFLLG1CQUFtQixTQUFTLFdBQVcsU0FBUyxDQUFDLFNBQVMsRUFBRSxHQUFHLFNBQVMsS0FBSztNQUN0Rjs7eUJBaEVTLHdCQUFxQixzQkFBQSxhQUFBLEdBQUEsc0JBQUEsa0JBQUEsQ0FBQTtNQUFBO21FQUFyQix3QkFBcUIsU0FBckIsdUJBQXFCLFdBQUEsWUFEUixPQUFNLENBQUE7Ozs7IiwibmFtZXMiOltdfQ==