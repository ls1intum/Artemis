import {
  ArtemisProgrammingExerciseInstructionsRenderModule,
  ProgrammingExerciseInstructionComponent,
  init_programming_exercise_instruction_component,
  init_programming_exercise_instructions_render_module
} from "/chunk-JPY2QIBY.js";
import {
  ArtemisAssessmentSharedModule,
  init_assessment_shared_module
} from "/chunk-5224NT7T.js";
import {
  TextBlockRef,
  init_text_block_ref_model
} from "/chunk-DFLF6UGC.js";
import {
  TextBlock,
  init_text_block_model
} from "/chunk-MPUHQW6C.js";
import {
  ArtemisModelingEditorModule,
  ModelingEditorComponent,
  init_modeling_editor_component,
  init_modeling_editor_module
} from "/chunk-WTEGR6H3.js";
import {
  ArtemisMarkdownModule,
  HtmlForMarkdownPipe,
  init_html_for_markdown_pipe,
  init_markdown_module
} from "/chunk-UF4UUZTK.js";
import {
  ArtemisMarkdownService,
  init_markdown_service
} from "/chunk-7FP3FWGI.js";
import {
  ArtemisSharedComponentModule,
  init_shared_component_module
} from "/chunk-ORYTP7RT.js";
import {
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  ButtonComponent,
  ExerciseType,
  ExtensionPointDirective,
  FEEDBACK_SUGGESTION_ACCEPTED_IDENTIFIER,
  FEEDBACK_SUGGESTION_IDENTIFIER,
  Feedback,
  FeedbackType,
  HelpIconComponent,
  ProfileService,
  SecureLinkDirective,
  TranslateDirective,
  __esm,
  init_artemis_translate_pipe,
  init_button_component,
  init_exercise_model,
  init_extension_point_directive,
  init_feedback_model,
  init_help_icon_component,
  init_profile_service,
  init_programming_exercise_student_participation_model,
  init_secure_link_directive,
  init_shared_module,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/assessment/assessment-instructions/expandable-section/expandable-section.component.ts
import { Component, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faAngleDown, faAngleRight } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { LocalStorageService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ExpandableSectionComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "h5", 1);
    i0.\u0275\u0275listener("click", function ExpandableSectionComponent_Conditional_0_Template_h5_click_1_listener() {
      i0.\u0275\u0275restoreView(_r4);
      const ctx_r3 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r3.toggleCollapsed());
    });
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275element(3, "fa-icon", 2);
    i0.\u0275\u0275text(4, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n        ", ctx_r0.headerKey, "\n        ");
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("icon", ctx_r0.isCollapsed ? ctx_r0.faAngleRight : ctx_r0.faAngleDown);
  }
}
function ExpandableSectionComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "h5", 1);
    i0.\u0275\u0275listener("click", function ExpandableSectionComponent_Conditional_1_Template_h5_click_1_listener() {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r5 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r5.toggleCollapsed());
    });
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275element(4, "fa-icon", 2);
    i0.\u0275\u0275text(5, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n        ", i0.\u0275\u0275pipeBind1(3, 2, ctx_r1.headerKey), "\n        ");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r1.isCollapsed ? ctx_r1.faAngleRight : ctx_r1.faAngleDown);
  }
}
function ExpandableSectionComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "h6", 1);
    i0.\u0275\u0275listener("click", function ExpandableSectionComponent_Conditional_2_Template_h6_click_1_listener() {
      i0.\u0275\u0275restoreView(_r8);
      const ctx_r7 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r7.toggleCollapsed());
    });
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275element(3, "fa-icon", 2);
    i0.\u0275\u0275text(4, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n");
  }
  if (rf & 2) {
    const ctx_r2 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n        ", ctx_r2.headerKey, "\n        ");
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("icon", ctx_r2.isCollapsed ? ctx_r2.faAngleRight : ctx_r2.faAngleDown);
  }
}
var _c0, ExpandableSectionComponent;
var init_expandable_section_component = __esm({
  "src/main/webapp/app/assessment/assessment-instructions/expandable-section/expandable-section.component.ts"() {
    init_artemis_translate_pipe();
    _c0 = ["*"];
    ExpandableSectionComponent = class _ExpandableSectionComponent {
      localStorageService;
      headerKey;
      hasTranslation = true;
      isSubHeader = false;
      isCollapsed;
      faAngleRight = faAngleRight;
      faAngleDown = faAngleDown;
      prefix = "collapsed.";
      constructor(localStorageService) {
        this.localStorageService = localStorageService;
      }
      ngOnInit() {
        this.isCollapsed = !!this.localStorageService.retrieve(this.storageKey);
        this.localStorageService.store(this.storageKey, this.isCollapsed);
      }
      toggleCollapsed() {
        this.isCollapsed = !this.isCollapsed;
        this.localStorageService.store(this.storageKey, this.isCollapsed);
      }
      get storageKey() {
        return this.prefix + this.headerKey;
      }
      static \u0275fac = function ExpandableSectionComponent_Factory(t) {
        return new (t || _ExpandableSectionComponent)(i0.\u0275\u0275directiveInject(i1.LocalStorageService));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _ExpandableSectionComponent, selectors: [["jhi-expandable-section"]], inputs: { headerKey: "headerKey", hasTranslation: "hasTranslation", isSubHeader: "isSubHeader" }, ngContentSelectors: _c0, decls: 8, vars: 4, consts: [[3, "ngbCollapse"], [1, "expandable-header", 3, "click"], [3, "icon"]], template: function ExpandableSectionComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275projectionDef();
          i0.\u0275\u0275template(0, ExpandableSectionComponent_Conditional_0_Template, 6, 2)(1, ExpandableSectionComponent_Conditional_1_Template, 7, 4)(2, ExpandableSectionComponent_Conditional_2_Template, 6, 2);
          i0.\u0275\u0275elementStart(3, "div", 0);
          i0.\u0275\u0275text(4, "\n    ");
          i0.\u0275\u0275projection(5);
          i0.\u0275\u0275text(6, "\n");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(7, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275conditional(0, ctx.hasTranslation === false && ctx.headerKey !== null && ctx.isSubHeader === false ? 0 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275conditional(1, ctx.hasTranslation === true && ctx.headerKey !== null && ctx.isSubHeader === false ? 1 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275conditional(2, ctx.hasTranslation === false && ctx.headerKey !== null && ctx.isSubHeader === true ? 2 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275property("ngbCollapse", ctx.isCollapsed);
        }
      }, dependencies: [i2.NgbCollapse, i3.FaIconComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(ExpandableSectionComponent, { className: "ExpandableSectionComponent" });
    })();
  }
});

// src/main/webapp/app/assessment/structured-grading-instructions-assessment-layout/structured-grading-instructions-assessment-layout.component.ts
import { Component as Component2, Input as Input2, QueryList, ViewChildren } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faCompress, faExpand, faInfoCircle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { delay, startWith } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function StructuredGradingInstructionsAssessmentLayoutComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n    ");
    i02.\u0275\u0275elementStart(1, "div", 0);
    i02.\u0275\u0275text(2, "\n        ");
    i02.\u0275\u0275elementStart(3, "button", 1);
    i02.\u0275\u0275listener("click", function StructuredGradingInstructionsAssessmentLayoutComponent_Conditional_0_Template_button_click_3_listener() {
      i02.\u0275\u0275restoreView(_r4);
      const ctx_r3 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r3.expandAll());
    });
    i02.\u0275\u0275text(4, "\n            ");
    i02.\u0275\u0275element(5, "fa-icon", 2);
    i02.\u0275\u0275text(6, " ");
    i02.\u0275\u0275elementStart(7, "span");
    i02.\u0275\u0275text(8);
    i02.\u0275\u0275pipe(9, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n        ");
    i02.\u0275\u0275elementStart(12, "button", 1);
    i02.\u0275\u0275listener("click", function StructuredGradingInstructionsAssessmentLayoutComponent_Conditional_0_Template_button_click_12_listener() {
      i02.\u0275\u0275restoreView(_r4);
      const ctx_r5 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r5.collapseAll());
    });
    i02.\u0275\u0275text(13, "\n            ");
    i02.\u0275\u0275element(14, "fa-icon", 2);
    i02.\u0275\u0275text(15, " ");
    i02.\u0275\u0275elementStart(16, "span");
    i02.\u0275\u0275text(17);
    i02.\u0275\u0275pipe(18, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(19, "\n        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(20, "\n    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(21, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275property("icon", ctx_r0.faExpand);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(9, 4, "artemisApp.assessmentInstructions.expandAll"));
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", ctx_r0.faCompress);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(18, 6, "artemisApp.assessmentInstructions.collapseAll"));
  }
}
function StructuredGradingInstructionsAssessmentLayoutComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n    ");
    i02.\u0275\u0275elementStart(1, "div", 3);
    i02.\u0275\u0275text(2, "\n        ");
    i02.\u0275\u0275element(3, "fa-icon", 2);
    i02.\u0275\u0275text(4, "\n        ");
    i02.\u0275\u0275elementStart(5, "span");
    i02.\u0275\u0275text(6);
    i02.\u0275\u0275pipe(7, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("icon", ctx_r1.faInfoCircle);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(7, 2, "artemisApp.exercise.dragDropInstruction"));
  }
}
function StructuredGradingInstructionsAssessmentLayoutComponent_For_3_For_6_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                                    ");
  }
  if (rf & 2) {
    const instruction_r12 = i02.\u0275\u0275nextContext().$implicit;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(instruction_r12.usageCount);
  }
}
function StructuredGradingInstructionsAssessmentLayoutComponent_For_3_For_6_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                        \u221E\n                                    ");
  }
}
function StructuredGradingInstructionsAssessmentLayoutComponent_For_3_For_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275elementStart(1, "div", 5);
    i02.\u0275\u0275listener("dragstart", function StructuredGradingInstructionsAssessmentLayoutComponent_For_3_For_6_Template_div_dragstart_1_listener() {
      i02.\u0275\u0275restoreView(_r21);
      const ctx_r20 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r20.disableDrag());
    })("dragstart", function StructuredGradingInstructionsAssessmentLayoutComponent_For_3_For_6_Template_div_dragstart_1_listener($event) {
      const restoredCtx = i02.\u0275\u0275restoreView(_r21);
      const instruction_r12 = restoredCtx.$implicit;
      const ctx_r22 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r22.drag($event, instruction_r12));
    });
    i02.\u0275\u0275text(2, "\n                    ");
    i02.\u0275\u0275elementStart(3, "table", 6);
    i02.\u0275\u0275text(4, "\n                        ");
    i02.\u0275\u0275elementStart(5, "tbody");
    i02.\u0275\u0275text(6, "\n                            ");
    i02.\u0275\u0275elementStart(7, "tr");
    i02.\u0275\u0275text(8, "\n                                ");
    i02.\u0275\u0275element(9, "td", 7);
    i02.\u0275\u0275text(10, "\n                                ");
    i02.\u0275\u0275element(11, "td", 8);
    i02.\u0275\u0275pipe(12, "htmlForMarkdown");
    i02.\u0275\u0275text(13, "\n                                ");
    i02.\u0275\u0275element(14, "td", 9);
    i02.\u0275\u0275pipe(15, "htmlForMarkdown");
    i02.\u0275\u0275text(16, "\n                                ");
    i02.\u0275\u0275elementStart(17, "td", 10);
    i02.\u0275\u0275text(18, "\n                                    ");
    i02.\u0275\u0275template(19, StructuredGradingInstructionsAssessmentLayoutComponent_For_3_For_6_Conditional_19_Template, 4, 1)(20, StructuredGradingInstructionsAssessmentLayoutComponent_For_3_For_6_Conditional_20_Template, 1, 0);
    i02.\u0275\u0275element(21, "jhi-help-icon", 11);
    i02.\u0275\u0275text(22, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(23, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(24, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(25, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(26, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(27, "\n            ");
  }
  if (rf & 2) {
    const instruction_r12 = ctx.$implicit;
    const instructionIndex_r13 = ctx.$index;
    const criterionIndex_r7 = i02.\u0275\u0275nextContext().$index;
    const ctx_r11 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275styleProp("background-color", ctx_r11.setInstrColour(instruction_r12));
    i02.\u0275\u0275propertyInterpolate("draggable", ctx_r11.allowDrop);
    i02.\u0275\u0275propertyInterpolate2("id", "criterion-", criterionIndex_r7, "-instruction-", instructionIndex_r13, "");
    i02.\u0275\u0275advance(8);
    i02.\u0275\u0275property("innerHTML", ctx_r11.setScore(instruction_r12.credits), i02.\u0275\u0275sanitizeHtml);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("innerHTML", i02.\u0275\u0275pipeBind1(12, 10, instruction_r12.gradingScale), i02.\u0275\u0275sanitizeHtml);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("innerHTML", i02.\u0275\u0275pipeBind1(15, 12, instruction_r12.instructionDescription), i02.\u0275\u0275sanitizeHtml)("ngbTooltip", ctx_r11.setTooltip(instruction_r12));
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275conditional(19, instruction_r12.usageCount && instruction_r12.usageCount !== 0 ? 19 : 20);
  }
}
function StructuredGradingInstructionsAssessmentLayoutComponent_For_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n    ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n        ");
    i02.\u0275\u0275elementStart(3, "jhi-expandable-section", 4);
    i02.\u0275\u0275text(4, "\n            ");
    i02.\u0275\u0275repeaterCreate(5, StructuredGradingInstructionsAssessmentLayoutComponent_For_3_For_6_Template, 28, 14, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n        ");
    i02.\u0275\u0275element(8, "br");
    i02.\u0275\u0275text(9, "\n    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n");
  }
  if (rf & 2) {
    const criterion_r6 = ctx.$implicit;
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("hasTranslation", false)("headerKey", criterion_r6.title)("isSubHeader", true);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275repeater(criterion_r6.structuredGradingInstructions);
  }
}
var StructuredGradingInstructionsAssessmentLayoutComponent;
var init_structured_grading_instructions_assessment_layout_component = __esm({
  "src/main/webapp/app/assessment/structured-grading-instructions-assessment-layout/structured-grading-instructions-assessment-layout.component.ts"() {
    init_expandable_section_component();
    init_help_icon_component();
    init_expandable_section_component();
    init_artemis_translate_pipe();
    init_html_for_markdown_pipe();
    StructuredGradingInstructionsAssessmentLayoutComponent = class _StructuredGradingInstructionsAssessmentLayoutComponent {
      criteria;
      readonly;
      allowDrop;
      faInfoCircle = faInfoCircle;
      faExpand = faExpand;
      faCompress = faCompress;
      expandableSections;
      collapseToggles = [];
      ngOnInit() {
        this.allowDrop = !this.readonly;
      }
      ngAfterViewInit() {
        this.expandableSections.changes.pipe(startWith([void 0]), delay(0)).subscribe(() => {
          this.collectCollapsableSections();
        });
      }
      collapseAll() {
        this.collapseToggles.forEach((section) => {
          if (!section.isCollapsed) {
            section.toggleCollapsed();
          }
        });
      }
      expandAll() {
        this.collapseToggles.forEach((section) => {
          if (section.isCollapsed) {
            section.toggleCollapsed();
          }
        });
      }
      setTooltip(instr) {
        return "Feedback: " + instr.feedback;
      }
      setInstrColour(instr) {
        let colour;
        if (instr.credits === 0) {
          colour = "var(--sgi-assessment-layout-zero-background)";
        } else if (instr.credits < 0) {
          colour = "var(--sgi-assessment-layout-negative-background)";
        } else {
          colour = "var(--sgi-assessment-layout-positive-background)";
        }
        return colour;
      }
      setScore(nr) {
        return nr + "P";
      }
      drag(event, instruction) {
        event.dataTransfer.setData("text/plain", JSON.stringify(instruction));
      }
      disableDrag() {
        return this.allowDrop;
      }
      collectCollapsableSections() {
        if (this.expandableSections) {
          this.collapseToggles = this.expandableSections.toArray();
        }
      }
      static \u0275fac = function StructuredGradingInstructionsAssessmentLayoutComponent_Factory(t) {
        return new (t || _StructuredGradingInstructionsAssessmentLayoutComponent)();
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _StructuredGradingInstructionsAssessmentLayoutComponent, selectors: [["jhi-structured-grading-instructions-assessment-layout"]], viewQuery: function StructuredGradingInstructionsAssessmentLayoutComponent_Query(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275viewQuery(ExpandableSectionComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i02.\u0275\u0275queryRefresh(_t = i02.\u0275\u0275loadQuery()) && (ctx.expandableSections = _t);
        }
      }, inputs: { criteria: "criteria", readonly: "readonly" }, decls: 4, vars: 2, consts: [[1, "mb-2"], ["type", "button", "data-bs-toggle", "button", 1, "btn", "btn-sm", "btn-outline-secondary", 3, "click"], [3, "icon"], [1, "alert", "alert-info"], [3, "hasTranslation", "headerKey", "isSubHeader"], [1, "rounded", 3, "draggable", "id", "dragstart"], [1, "table", "layout-table"], [1, "td-score", 3, "innerHTML"], [3, "innerHTML"], [3, "innerHTML", "ngbTooltip"], [1, "td-usage-count"], ["text", "artemisApp.exercise.usageCountHint"]], template: function StructuredGradingInstructionsAssessmentLayoutComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275template(0, StructuredGradingInstructionsAssessmentLayoutComponent_Conditional_0_Template, 22, 8)(1, StructuredGradingInstructionsAssessmentLayoutComponent_Conditional_1_Template, 10, 4);
          i02.\u0275\u0275repeaterCreate(2, StructuredGradingInstructionsAssessmentLayoutComponent_For_3_Template, 11, 3, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
        }
        if (rf & 2) {
          i02.\u0275\u0275conditional(0, ctx.criteria ? 0 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(1, ctx.allowDrop ? 1 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275repeater(ctx.criteria);
        }
      }, dependencies: [i12.NgbTooltip, i22.FaIconComponent, HelpIconComponent, ExpandableSectionComponent, ArtemisTranslatePipe, HtmlForMarkdownPipe], styles: ["\n\n.layout-table[_ngcontent-%COMP%] {\n  margin: 1px;\n}\n.layout-table[_ngcontent-%COMP%]   .td-score[_ngcontent-%COMP%], .layout-table[_ngcontent-%COMP%]   .td-usage-count[_ngcontent-%COMP%] {\n  width: 4%;\n}\n.layout-table[_ngcontent-%COMP%]   .td-usage-count[_ngcontent-%COMP%] {\n  position: relative;\n  white-space: nowrap;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9hc3Nlc3NtZW50L3N0cnVjdHVyZWQtZ3JhZGluZy1pbnN0cnVjdGlvbnMtYXNzZXNzbWVudC1sYXlvdXQvc3RydWN0dXJlZC1ncmFkaW5nLWluc3RydWN0aW9ucy1hc3Nlc3NtZW50LWxheW91dC5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmxheW91dC10YWJsZSB7XG4gICAgbWFyZ2luOiAxcHg7XG5cbiAgICAudGQtc2NvcmUsXG4gICAgLnRkLXVzYWdlLWNvdW50IHtcbiAgICAgICAgd2lkdGg6IDQlO1xuICAgIH1cblxuICAgIC50ZC11c2FnZS1jb3VudCB7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFVBQUE7O0FBRUEsQ0FISixhQUdJLENBQUE7QUFBQSxDQUhKLGFBR0ksQ0FBQTtBQUVJLFNBQUE7O0FBR0osQ0FSSixhQVFJLENBTEE7QUFNSSxZQUFBO0FBQ0EsZUFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(StructuredGradingInstructionsAssessmentLayoutComponent, { className: "StructuredGradingInstructionsAssessmentLayoutComponent" });
    })();
  }
});

// src/main/webapp/app/assessment/assessment-instructions/assessment-instructions/assessment-instructions.component.ts
import { Component as Component3, ContentChild, Input as Input3, TemplateRef } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function AssessmentInstructionsComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n    ");
    i03.\u0275\u0275elementStart(1, "div", 3);
    i03.\u0275\u0275text(2, "\n        ");
    i03.\u0275\u0275elementStart(3, "jhi-expandable-section", 4);
    i03.\u0275\u0275text(4, "\n            ");
    i03.\u0275\u0275element(5, "p", 5);
    i03.\u0275\u0275text(6, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(7, "\n        ");
    i03.\u0275\u0275elementStart(8, "jhi-expandable-section", 6);
    i03.\u0275\u0275text(9, "\n            ");
    i03.\u0275\u0275element(10, "jhi-structured-grading-instructions-assessment-layout", 7);
    i03.\u0275\u0275text(11, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(12, "\n    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(13, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(5);
    i03.\u0275\u0275property("innerHTML", ctx_r0.gradingInstructions, i03.\u0275\u0275sanitizeHtml);
    i03.\u0275\u0275advance(5);
    i03.\u0275\u0275property("readonly", ctx_r0.readOnly)("criteria", ctx_r0.criteria);
  }
}
function AssessmentInstructionsComponent_h3_1_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275elementStart(0, "h3");
    i03.\u0275\u0275text(1);
    i03.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275textInterpolate(ctx_r1.exercise.title);
  }
}
function AssessmentInstructionsComponent_Case_5_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n            ");
    i03.\u0275\u0275element(1, "jhi-programming-exercise-instructions", 8);
    i03.\u0275\u0275text(2, "\n        ");
  }
  if (rf & 2) {
    const ctx_r2 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("exercise", ctx_r2.programmingExercise)("participation", ctx_r2.programmingParticipation ? ctx_r2.programmingParticipation : ctx_r2.programmingExercise.templateParticipation)("personalParticipation", false);
  }
}
function AssessmentInstructionsComponent_Case_6_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n            ");
    i03.\u0275\u0275element(1, "p", 5);
    i03.\u0275\u0275text(2, "\n        ");
  }
  if (rf & 2) {
    const ctx_r3 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("innerHTML", ctx_r3.problemStatement, i03.\u0275\u0275sanitizeHtml);
  }
}
function AssessmentInstructionsComponent_Case_11_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n            ");
    i03.\u0275\u0275elementStart(1, "div", 9);
    i03.\u0275\u0275text(2, "\n                ");
    i03.\u0275\u0275elementStart(3, "a", 10);
    i03.\u0275\u0275text(4, "\n                    ");
    i03.\u0275\u0275elementStart(5, "jhi-button", 11);
    i03.\u0275\u0275text(6, "Example solution repository");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(7, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(9, "\n        ");
  }
  if (rf & 2) {
    const ctx_r4 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("href", ctx_r4.programmingExercise == null ? null : ctx_r4.programmingExercise.solutionParticipation == null ? null : ctx_r4.programmingExercise.solutionParticipation.repositoryUri, i03.\u0275\u0275sanitizeUrl);
  }
}
function AssessmentInstructionsComponent_Case_12_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275element(1, "jhi-modeling-editor", 12);
    i03.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r7 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("readOnly", true)("diagramType", ctx_r7.sampleSolutionDiagramType)("umlModel", ctx_r7.sampleSolutionModel);
  }
}
function AssessmentInstructionsComponent_Case_12_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275element(1, "p", 5);
    i03.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r8 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("innerHTML", ctx_r8.sampleSolutionExplanation, i03.\u0275\u0275sanitizeHtml);
  }
}
function AssessmentInstructionsComponent_Case_12_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n            ");
    i03.\u0275\u0275template(1, AssessmentInstructionsComponent_Case_12_Conditional_1_Template, 3, 3)(2, AssessmentInstructionsComponent_Case_12_Conditional_2_Template, 3, 1);
  }
  if (rf & 2) {
    const ctx_r5 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(1, ctx_r5.sampleSolutionModel ? 1 : -1);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(2, ctx_r5.sampleSolutionExplanation ? 2 : -1);
  }
}
function AssessmentInstructionsComponent_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n    ");
    i03.\u0275\u0275elementStart(1, "jhi-expandable-section", 13);
    i03.\u0275\u0275text(2, "\n        ");
    i03.\u0275\u0275element(3, "p", 14);
    i03.\u0275\u0275text(4, "\n    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n");
  }
}
var _c02, AssessmentInstructionsComponent;
var init_assessment_instructions_component = __esm({
  "src/main/webapp/app/assessment/assessment-instructions/assessment-instructions/assessment-instructions.component.ts"() {
    init_markdown_service();
    init_exercise_model();
    init_programming_exercise_student_participation_model();
    init_markdown_service();
    init_translate_directive();
    init_extension_point_directive();
    init_secure_link_directive();
    init_modeling_editor_component();
    init_programming_exercise_instruction_component();
    init_button_component();
    init_expandable_section_component();
    init_structured_grading_instructions_assessment_layout_component();
    _c02 = ["overrideTitle"];
    AssessmentInstructionsComponent = class _AssessmentInstructionsComponent {
      markdownService;
      exercise;
      programmingExercise;
      problemStatement;
      gradingInstructions;
      sampleSolutionExplanation;
      sampleSolutionModel;
      sampleSolutionDiagramType;
      criteria;
      isAssessmentTraining = false;
      showAssessmentInstructions = true;
      readOnly;
      programmingParticipation;
      ExerciseType = ExerciseType;
      overrideTitle;
      constructor(markdownService) {
        this.markdownService = markdownService;
      }
      set exerciseInput(exercise) {
        this.exercise = exercise;
        this.problemStatement = this.markdownService.safeHtmlForMarkdown(exercise.problemStatement);
        this.gradingInstructions = this.markdownService.safeHtmlForMarkdown(exercise.gradingInstructions);
        this.criteria = exercise.gradingCriteria || [];
        let sampleSolutionMarkdown;
        switch (exercise.type) {
          case ExerciseType.MODELING:
            const modelingExercise = exercise;
            sampleSolutionMarkdown = modelingExercise.exampleSolutionExplanation;
            if (modelingExercise.exampleSolutionModel) {
              this.sampleSolutionModel = JSON.parse(modelingExercise.exampleSolutionModel);
            }
            this.sampleSolutionDiagramType = modelingExercise.diagramType;
            break;
          case ExerciseType.TEXT:
            const textExercise = exercise;
            sampleSolutionMarkdown = textExercise.exampleSolution;
            break;
          case ExerciseType.FILE_UPLOAD:
            const fileUploadExercise = exercise;
            sampleSolutionMarkdown = fileUploadExercise.exampleSolution;
            break;
          case ExerciseType.PROGRAMMING:
            this.programmingExercise = exercise;
        }
        if (sampleSolutionMarkdown) {
          this.sampleSolutionExplanation = this.markdownService.safeHtmlForMarkdown(sampleSolutionMarkdown);
        }
      }
      static \u0275fac = function AssessmentInstructionsComponent_Factory(t) {
        return new (t || _AssessmentInstructionsComponent)(i03.\u0275\u0275directiveInject(ArtemisMarkdownService));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _AssessmentInstructionsComponent, selectors: [["jhi-assessment-instructions"]], contentQueries: function AssessmentInstructionsComponent_ContentQueries(rf, ctx, dirIndex) {
        if (rf & 1) {
          i03.\u0275\u0275contentQuery(dirIndex, _c02, 5);
        }
        if (rf & 2) {
          let _t;
          i03.\u0275\u0275queryRefresh(_t = i03.\u0275\u0275loadQuery()) && (ctx.overrideTitle = _t.first);
        }
      }, inputs: { isAssessmentTraining: "isAssessmentTraining", showAssessmentInstructions: "showAssessmentInstructions", readOnly: "readOnly", programmingParticipation: "programmingParticipation", exerciseInput: ["exercise", "exerciseInput"] }, decls: 16, vars: 5, consts: [[4, "jhiExtensionPoint"], ["headerKey", "artemisApp.assessmentInstructions.problemStatement"], ["headerKey", "artemisApp.assessmentInstructions.sampleSolution"], [1, "border", "p-2"], ["headerKey", "artemisApp.assessmentInstructions.assessmentInstructions"], [1, "markdown-preview", 3, "innerHTML"], ["headerKey", "artemisApp.assessmentInstructions.structuredGradingInstructions"], [3, "readonly", "criteria"], [3, "exercise", "participation", "personalParticipation"], [1, "mb-3"], ["jhiSecureLink", "", 3, "href"], ["jhiTranslate", "artemisApp.exerciseAssessmentDashboard.programmingExercise.exampleSolution"], [3, "readOnly", "diagramType", "umlModel"], ["headerKey", "artemisApp.assessmentInstructions.trainingEvaluationCriteria.title"], ["jhiTranslate", "artemisApp.assessmentInstructions.trainingEvaluationCriteria.description"]], template: function AssessmentInstructionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275template(0, AssessmentInstructionsComponent_Conditional_0_Template, 14, 3)(1, AssessmentInstructionsComponent_h3_1_Template, 2, 1, "h3", 0);
          i03.\u0275\u0275text(2, "\n");
          i03.\u0275\u0275elementStart(3, "jhi-expandable-section", 1);
          i03.\u0275\u0275text(4, "\n    ");
          i03.\u0275\u0275template(5, AssessmentInstructionsComponent_Case_5_Template, 3, 3)(6, AssessmentInstructionsComponent_Case_6_Template, 3, 1);
          i03.\u0275\u0275text(7, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(8, "\n");
          i03.\u0275\u0275elementStart(9, "jhi-expandable-section", 2);
          i03.\u0275\u0275text(10, "\n    ");
          i03.\u0275\u0275template(11, AssessmentInstructionsComponent_Case_11_Template, 10, 1)(12, AssessmentInstructionsComponent_Case_12_Template, 3, 2);
          i03.\u0275\u0275text(13, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(14, "\n");
          i03.\u0275\u0275template(15, AssessmentInstructionsComponent_Conditional_15_Template, 6, 0);
        }
        if (rf & 2) {
          let AssessmentInstructionsComponent_contFlowTmp;
          i03.\u0275\u0275conditional(0, ctx.showAssessmentInstructions ? 0 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275property("jhiExtensionPoint", ctx.overrideTitle);
          i03.\u0275\u0275advance(4);
          i03.\u0275\u0275conditional(5, (AssessmentInstructionsComponent_contFlowTmp = ctx.exercise.type) === ctx.ExerciseType.PROGRAMMING ? 5 : 6);
          i03.\u0275\u0275advance(6);
          i03.\u0275\u0275conditional(11, (AssessmentInstructionsComponent_contFlowTmp = ctx.exercise.type) === ctx.ExerciseType.PROGRAMMING ? 11 : 12);
          i03.\u0275\u0275advance(4);
          i03.\u0275\u0275conditional(15, ctx.isAssessmentTraining ? 15 : -1);
        }
      }, dependencies: [TranslateDirective, ExtensionPointDirective, SecureLinkDirective, ModelingEditorComponent, ProgrammingExerciseInstructionComponent, ButtonComponent, ExpandableSectionComponent, StructuredGradingInstructionsAssessmentLayoutComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(AssessmentInstructionsComponent, { className: "AssessmentInstructionsComponent" });
    })();
  }
});

// src/main/webapp/app/assessment/assessment-instructions/collapsable-assessment-instructions/collapsable-assessment-instructions.component.ts
import { Component as Component4, Input as Input4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faListAlt } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import { faChevronLeft, faChevronRight, faGripLinesVertical } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import __vite__cjsImport27_interactjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/interactjs.js?v=1d0d9ead"; const interact = __vite__cjsImport27_interactjs.__esModule ? __vite__cjsImport27_interactjs.default : __vite__cjsImport27_interactjs;
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function CollapsableAssessmentInstructionsComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n    ");
    i04.\u0275\u0275elementStart(1, "div", 0);
    i04.\u0275\u0275text(2, "\n        ");
    i04.\u0275\u0275elementStart(3, "div", 1);
    i04.\u0275\u0275element(4, "fa-icon", 2);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n        ");
    i04.\u0275\u0275elementStart(6, "div", 3);
    i04.\u0275\u0275text(7, "\n            ");
    i04.\u0275\u0275elementStart(8, "div", 4);
    i04.\u0275\u0275listener("click", function CollapsableAssessmentInstructionsComponent_Conditional_0_Template_div_click_8_listener() {
      i04.\u0275\u0275restoreView(_r3);
      const ctx_r2 = i04.\u0275\u0275nextContext();
      return i04.\u0275\u0275resetView(ctx_r2.collapsed = !ctx_r2.collapsed);
    });
    i04.\u0275\u0275text(9, "\n                ");
    i04.\u0275\u0275elementStart(10, "h3", 5);
    i04.\u0275\u0275text(11, "\n                    ");
    i04.\u0275\u0275element(12, "fa-icon", 2);
    i04.\u0275\u0275text(13, "\xA0\n                    ");
    i04.\u0275\u0275elementStart(14, "span", 6);
    i04.\u0275\u0275text(15, " \xA0 Instructions \xA0 ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(16, "\n                ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(17, "\n                ");
    i04.\u0275\u0275element(18, "fa-icon", 2);
    i04.\u0275\u0275text(19, "\n            ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(20, "\n            ");
    i04.\u0275\u0275elementStart(21, "div", 7);
    i04.\u0275\u0275text(22, "\n                ");
    i04.\u0275\u0275element(23, "jhi-assessment-instructions", 8);
    i04.\u0275\u0275text(24, "\n            ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(25, "\n        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(26, "\n    ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(27, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(4);
    i04.\u0275\u0275property("icon", ctx_r0.faGripLinesVertical);
    i04.\u0275\u0275advance(8);
    i04.\u0275\u0275property("icon", ctx_r0.farListAlt);
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275property("icon", ctx_r0.faChevronRight);
    i04.\u0275\u0275advance(5);
    i04.\u0275\u0275property("readOnly", ctx_r0.readOnly)("exercise", ctx_r0.exercise)("isAssessmentTraining", ctx_r0.isAssessmentTraining)("showAssessmentInstructions", ctx_r0.showAssessmentInstructions);
  }
}
function CollapsableAssessmentInstructionsComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n    ");
    i04.\u0275\u0275elementStart(1, "div", 9);
    i04.\u0275\u0275listener("click", function CollapsableAssessmentInstructionsComponent_Conditional_1_Template_div_click_1_listener() {
      i04.\u0275\u0275restoreView(_r5);
      const ctx_r4 = i04.\u0275\u0275nextContext();
      return i04.\u0275\u0275resetView(ctx_r4.collapsed = !ctx_r4.collapsed);
    });
    i04.\u0275\u0275text(2, "\n        ");
    i04.\u0275\u0275element(3, "fa-icon", 2);
    i04.\u0275\u0275text(4, "\n        ");
    i04.\u0275\u0275elementStart(5, "span", 6);
    i04.\u0275\u0275text(6, " \xA0 Instructions \xA0 ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n        ");
    i04.\u0275\u0275element(8, "fa-icon", 2);
    i04.\u0275\u0275text(9, "\n    ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("icon", ctx_r1.faChevronLeft);
    i04.\u0275\u0275advance(5);
    i04.\u0275\u0275property("icon", ctx_r1.faChevronLeft);
  }
}
var CollapsableAssessmentInstructionsComponent;
var init_collapsable_assessment_instructions_component = __esm({
  "src/main/webapp/app/assessment/assessment-instructions/collapsable-assessment-instructions/collapsable-assessment-instructions.component.ts"() {
    init_exercise_model();
    init_translate_directive();
    init_assessment_instructions_component();
    CollapsableAssessmentInstructionsComponent = class _CollapsableAssessmentInstructionsComponent {
      isAssessmentTraining = false;
      showAssessmentInstructions = true;
      exercise;
      collapsed = false;
      readOnly;
      faChevronRight = faChevronRight;
      faChevronLeft = faChevronLeft;
      faGripLinesVertical = faGripLinesVertical;
      farListAlt = faListAlt;
      ngAfterViewInit() {
        interact(".expanded-instructions").resizable({
          edges: { left: ".draggable-left", right: false, bottom: false, top: false },
          modifiers: [
            interact.modifiers.restrictSize({
              min: { width: 215, height: 0 },
              max: { width: 1e3, height: 2e3 }
            })
          ],
          inertia: true
        }).on("resizestart", function(event) {
          event.target.classList.add("card-resizable");
        }).on("resizeend", function(event) {
          event.target.classList.remove("card-resizable");
        }).on("resizemove", function(event) {
          const target = event.target;
          target.style.width = event.rect.width + "px";
        });
      }
      static \u0275fac = function CollapsableAssessmentInstructionsComponent_Factory(t) {
        return new (t || _CollapsableAssessmentInstructionsComponent)();
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _CollapsableAssessmentInstructionsComponent, selectors: [["jhi-collapsable-assessment-instructions"]], inputs: { isAssessmentTraining: "isAssessmentTraining", showAssessmentInstructions: "showAssessmentInstructions", exercise: "exercise", collapsed: "collapsed", readOnly: "readOnly" }, decls: 2, vars: 1, consts: [[1, "expanded-instructions", "instructions-container"], [1, "draggable-left"], [3, "icon"], [1, "card"], [1, "card-header", "text-white", "bg-primary", 3, "click"], [1, "card-title"], ["jhiTranslate", "artemisApp.assessmentInstructions.instructions.instructions"], [1, "wrapper-scroll-y", "scrollbar", "vh-100"], [1, "card-body", "markdown-preview", 3, "readOnly", "exercise", "isAssessmentTraining", "showAssessmentInstructions"], [1, "collapsed-instructions", "instructions-container", "text-white", "bg-primary", 3, "click"]], template: function CollapsableAssessmentInstructionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275template(0, CollapsableAssessmentInstructionsComponent_Conditional_0_Template, 28, 7)(1, CollapsableAssessmentInstructionsComponent_Conditional_1_Template, 11, 2);
        }
        if (rf & 2) {
          i04.\u0275\u0275conditional(0, !ctx.collapsed ? 0 : 1);
        }
      }, dependencies: [i13.FaIconComponent, TranslateDirective, AssessmentInstructionsComponent], styles: ["\n\n.instructions-container[_ngcontent-%COMP%] {\n  display: flex;\n  height: 100vh;\n}\n.expanded-instructions[_ngcontent-%COMP%] {\n  width: 30vw;\n}\n.expanded-instructions[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%] {\n  width: 100%;\n  min-width: 200px;\n}\n.expanded-instructions[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  cursor: pointer;\n}\n.expanded-instructions[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%]   .card-title[_ngcontent-%COMP%] {\n  display: flex;\n}\n.expanded-instructions[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%] {\n  overflow-y: auto;\n}\n.expanded-instructions[_ngcontent-%COMP%]   .draggable-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  min-width: 15px;\n}\n.expanded-instructions[_ngcontent-%COMP%]   .scrollbar[_ngcontent-%COMP%] {\n  position: relative;\n  overflow: auto;\n}\n.expanded-instructions[_ngcontent-%COMP%]   .wrapper-scroll-y[_ngcontent-%COMP%] {\n  display: block;\n  padding: 0 0.5rem;\n}\n.collapsed-instructions[_ngcontent-%COMP%] {\n  width: 50px;\n  height: 170px;\n  justify-content: space-between;\n  flex-flow: column nowrap;\n  margin-left: 15px;\n  cursor: pointer;\n}\n.collapsed-instructions[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  writing-mode: vertical-rl;\n  margin: auto;\n}\n.collapsed-instructions[_ngcontent-%COMP%]   fa-icon[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  padding: 15px 0;\n}\n.expandable-header[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\n.expandable-header[_ngcontent-%COMP%]   fa-icon[_ngcontent-%COMP%] {\n  padding-left: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9hc3Nlc3NtZW50L2Fzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zL2NvbGxhcHNhYmxlLWFzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zL2NvbGxhcHNhYmxlLWFzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zLnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5pbnN0cnVjdGlvbnMtY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGhlaWdodDogMTAwdmg7XG59XG5cbi5leHBhbmRlZC1pbnN0cnVjdGlvbnMge1xuICAgIHdpZHRoOiAzMHZ3O1xuXG4gICAgLmNhcmQge1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgbWluLXdpZHRoOiAyMDBweDtcblxuICAgICAgICAuY2FyZC1oZWFkZXIge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG5cbiAgICAgICAgICAgIC5jYXJkLXRpdGxlIHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLmNhcmQtYm9keSB7XG4gICAgICAgICAgICBvdmVyZmxvdy15OiBhdXRvO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmRyYWdnYWJsZS1sZWZ0IHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIG1pbi13aWR0aDogMTVweDtcbiAgICB9XG5cbiAgICAuc2Nyb2xsYmFyIHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICBvdmVyZmxvdzogYXV0bztcbiAgICB9XG5cbiAgICAud3JhcHBlci1zY3JvbGwteSB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICBwYWRkaW5nOiAwIDAuNXJlbTtcbiAgICB9XG59XG5cbi5jb2xsYXBzZWQtaW5zdHJ1Y3Rpb25zIHtcbiAgICB3aWR0aDogNTBweDtcbiAgICBoZWlnaHQ6IDE3MHB4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBmbGV4LWZsb3c6IGNvbHVtbiBub3dyYXA7XG4gICAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHNwYW4ge1xuICAgICAgICB3cml0aW5nLW1vZGU6IHZlcnRpY2FsLXJsO1xuICAgICAgICBtYXJnaW46IGF1dG87XG4gICAgfVxuICAgIGZhLWljb24ge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgcGFkZGluZzogMTVweCAwO1xuICAgIH1cbn1cbi5leHBhbmRhYmxlLWhlYWRlciB7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIGZhLWljb24ge1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDVweDtcbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxVQUFBOztBQUdKLENBQUE7QUFDSSxTQUFBOztBQUVBLENBSEosc0JBR0ksQ0FBQTtBQUNJLFNBQUE7QUFDQSxhQUFBOztBQUVBLENBUFIsc0JBT1EsQ0FKSixLQUlJLENBQUE7QUFDSSxXQUFBO0FBQ0EsbUJBQUE7QUFDQSxlQUFBO0FBQ0EsVUFBQTs7QUFFQSxDQWJaLHNCQWFZLENBVlIsS0FVUSxDQU5KLFlBTUksQ0FBQTtBQUNJLFdBQUE7O0FBSVIsQ0FsQlIsc0JBa0JRLENBZkosS0FlSSxDQUFBO0FBQ0ksY0FBQTs7QUFJUixDQXZCSixzQkF1QkksQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBO0FBQ0EsbUJBQUE7QUFDQSxhQUFBOztBQUdKLENBOUJKLHNCQThCSSxDQUFBO0FBQ0ksWUFBQTtBQUNBLFlBQUE7O0FBR0osQ0FuQ0osc0JBbUNJLENBQUE7QUFDSSxXQUFBO0FBQ0EsV0FBQSxFQUFBOztBQUlSLENBQUE7QUFDSSxTQUFBO0FBQ0EsVUFBQTtBQUNBLG1CQUFBO0FBQ0EsYUFBQSxPQUFBO0FBQ0EsZUFBQTtBQUNBLFVBQUE7O0FBQ0EsQ0FQSix1QkFPSTtBQUNJLGdCQUFBO0FBQ0EsVUFBQTs7QUFFSixDQVhKLHVCQVdJO0FBQ0ksV0FBQTtBQUNBLG1CQUFBO0FBQ0EsV0FBQSxLQUFBOztBQUdSLENBQUE7QUFDSSxVQUFBOztBQUNBLENBRkosa0JBRUk7QUFDSSxnQkFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(CollapsableAssessmentInstructionsComponent, { className: "CollapsableAssessmentInstructionsComponent" });
    })();
  }
});

// src/main/webapp/app/orion/assessment/orion-assessment-instructions.component.ts
import { Component as Component5, Input as Input5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function OrionAssessmentInstructionsComponent_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                ");
    i05.\u0275\u0275text(1, "\n            ");
  }
}
var OrionAssessmentInstructionsComponent;
var init_orion_assessment_instructions_component = __esm({
  "src/main/webapp/app/orion/assessment/orion-assessment-instructions.component.ts"() {
    init_programming_exercise_student_participation_model();
    init_exercise_model();
    init_assessment_instructions_component();
    OrionAssessmentInstructionsComponent = class _OrionAssessmentInstructionsComponent {
      readOnly;
      programmingParticipation;
      exercise;
      static \u0275fac = function OrionAssessmentInstructionsComponent_Factory(t) {
        return new (t || _OrionAssessmentInstructionsComponent)();
      };
      static \u0275cmp = i05.\u0275\u0275defineComponent({ type: _OrionAssessmentInstructionsComponent, selectors: [["jhi-orion-assessment-instructions"]], inputs: { readOnly: "readOnly", programmingParticipation: "programmingParticipation", exercise: "exercise" }, decls: 7, vars: 3, consts: [[3, "exercise", "programmingParticipation", "readOnly"], ["overrideTitle", ""]], template: function OrionAssessmentInstructionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275text(0, "\n        ");
          i05.\u0275\u0275elementStart(1, "jhi-assessment-instructions", 0);
          i05.\u0275\u0275text(2, "\n            ");
          i05.\u0275\u0275template(3, OrionAssessmentInstructionsComponent_ng_template_3_Template, 2, 0, "ng-template", null, 1, i05.\u0275\u0275templateRefExtractor);
          i05.\u0275\u0275text(5, "\n        ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(6, "\n    ");
        }
        if (rf & 2) {
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275property("exercise", ctx.exercise)("programmingParticipation", ctx.programmingParticipation)("readOnly", ctx.readOnly);
        }
      }, dependencies: [AssessmentInstructionsComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(OrionAssessmentInstructionsComponent, { className: "OrionAssessmentInstructionsComponent" });
    })();
  }
});

// src/main/webapp/app/assessment/assessment-instructions/assessment-instructions.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { CommonModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import { NgbModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var AssessmentInstructionsModule;
var init_assessment_instructions_module = __esm({
  "src/main/webapp/app/assessment/assessment-instructions/assessment-instructions.module.ts"() {
    init_shared_module();
    init_modeling_editor_module();
    init_programming_exercise_instructions_render_module();
    init_expandable_section_component();
    init_collapsable_assessment_instructions_component();
    init_assessment_instructions_component();
    init_assessment_shared_module();
    init_structured_grading_instructions_assessment_layout_component();
    init_shared_component_module();
    init_markdown_module();
    init_orion_assessment_instructions_component();
    AssessmentInstructionsModule = class _AssessmentInstructionsModule {
      static \u0275fac = function AssessmentInstructionsModule_Factory(t) {
        return new (t || _AssessmentInstructionsModule)();
      };
      static \u0275mod = i06.\u0275\u0275defineNgModule({ type: _AssessmentInstructionsModule });
      static \u0275inj = i06.\u0275\u0275defineInjector({ imports: [
        CommonModule,
        NgbModule,
        ArtemisSharedModule,
        ArtemisModelingEditorModule,
        ArtemisProgrammingExerciseInstructionsRenderModule,
        ArtemisAssessmentSharedModule,
        ArtemisSharedComponentModule,
        ArtemisMarkdownModule
      ] });
    };
  }
});

// src/main/webapp/app/assessment/athena.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map, of, switchMap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i14 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var AthenaService;
var init_athena_service = __esm({
  "src/main/webapp/app/assessment/athena.service.ts"() {
    init_profile_service();
    init_feedback_model();
    init_text_block_model();
    init_text_block_ref_model();
    init_profile_service();
    AthenaService = class _AthenaService {
      http;
      profileService;
      resourceUrl = "api/athena";
      constructor(http, profileService) {
        this.http = http;
        this.profileService = profileService;
      }
      isEnabled() {
        return this.profileService.getProfileInfo().pipe(switchMap((profileInfo) => of(profileInfo.activeProfiles.includes("athena"))));
      }
      getFeedbackSuggestions(exercise, submissionId) {
        if (!exercise.feedbackSuggestionsEnabled) {
          return of([]);
        }
        return this.isEnabled().pipe(switchMap((isAthenaEnabled) => {
          if (!isAthenaEnabled) {
            return of([]);
          }
          return this.http.get(`${this.resourceUrl}/${exercise.type}-exercises/${exercise.id}/submissions/${submissionId}/feedback-suggestions`, { observe: "response" }).pipe(switchMap((res) => of(res.body)));
        }));
      }
      findGradingInstruction(exercise, id) {
        for (const criterium of exercise.gradingCriteria ?? []) {
          for (const instruction of criterium.structuredGradingInstructions) {
            if (instruction.id == id) {
              return instruction;
            }
          }
        }
        return void 0;
      }
      getTextFeedbackSuggestions(exercise, submission) {
        return this.getFeedbackSuggestions(exercise, submission.id).pipe(map((suggestions) => {
          return suggestions.map((suggestion) => {
            const feedback = new Feedback();
            feedback.credits = suggestion.credits;
            feedback.text = FEEDBACK_SUGGESTION_ACCEPTED_IDENTIFIER + suggestion.title;
            feedback.detailText = suggestion.description;
            if (suggestion.structuredGradingInstructionId != void 0) {
              feedback.gradingInstruction = this.findGradingInstruction(exercise, suggestion.structuredGradingInstructionId);
            }
            if (suggestion.indexStart == null) {
              feedback.type = FeedbackType.MANUAL_UNREFERENCED;
              return feedback;
            }
            feedback.type = FeedbackType.MANUAL;
            const textBlock = new TextBlock();
            textBlock.startIndex = suggestion.indexStart;
            textBlock.endIndex = suggestion.indexEnd;
            textBlock.setTextFromSubmission(submission);
            feedback.reference = textBlock.id;
            return new TextBlockRef(textBlock, feedback);
          });
        }));
      }
      getProgrammingFeedbackSuggestions(exercise, submissionId) {
        return this.getFeedbackSuggestions(exercise, submissionId).pipe(map((suggestions) => {
          return suggestions.map((suggestion) => {
            const feedback = new Feedback();
            feedback.credits = suggestion.credits;
            feedback.text = FEEDBACK_SUGGESTION_IDENTIFIER + suggestion.title;
            feedback.detailText = suggestion.description;
            if (suggestion.filePath != void 0 && (suggestion.lineEnd ?? suggestion.lineStart) != void 0) {
              feedback.type = FeedbackType.MANUAL;
              feedback.reference = `file:${suggestion.filePath}_line:${suggestion.lineEnd ?? suggestion.lineStart}`;
            } else {
              feedback.type = FeedbackType.MANUAL_UNREFERENCED;
              feedback.reference = void 0;
            }
            if (suggestion.structuredGradingInstructionId != void 0) {
              feedback.gradingInstruction = this.findGradingInstruction(exercise, suggestion.structuredGradingInstructionId);
            }
            return feedback;
          });
        }));
      }
      static \u0275fac = function AthenaService_Factory(t) {
        return new (t || _AthenaService)(i07.\u0275\u0275inject(i14.HttpClient), i07.\u0275\u0275inject(ProfileService));
      };
      static \u0275prov = i07.\u0275\u0275defineInjectable({ token: _AthenaService, factory: _AthenaService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/shared/structured-grading-criterion/grading-criterion.model.ts
var GradingCriterion;
var init_grading_criterion_model = __esm({
  "src/main/webapp/app/exercises/shared/structured-grading-criterion/grading-criterion.model.ts"() {
    GradingCriterion = class {
      id;
      title;
      structuredGradingInstructions;
    };
  }
});

export {
  StructuredGradingInstructionsAssessmentLayoutComponent,
  init_structured_grading_instructions_assessment_layout_component,
  AthenaService,
  init_athena_service,
  GradingCriterion,
  init_grading_criterion_model,
  AssessmentInstructionsComponent,
  init_assessment_instructions_component,
  OrionAssessmentInstructionsComponent,
  init_orion_assessment_instructions_component,
  CollapsableAssessmentInstructionsComponent,
  init_collapsable_assessment_instructions_component,
  AssessmentInstructionsModule,
  init_assessment_instructions_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvYXNzZXNzbWVudC9hc3Nlc3NtZW50LWluc3RydWN0aW9ucy9leHBhbmRhYmxlLXNlY3Rpb24vZXhwYW5kYWJsZS1zZWN0aW9uLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXNzZXNzbWVudC9hc3Nlc3NtZW50LWluc3RydWN0aW9ucy9leHBhbmRhYmxlLXNlY3Rpb24vZXhwYW5kYWJsZS1zZWN0aW9uLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9hc3Nlc3NtZW50L3N0cnVjdHVyZWQtZ3JhZGluZy1pbnN0cnVjdGlvbnMtYXNzZXNzbWVudC1sYXlvdXQvc3RydWN0dXJlZC1ncmFkaW5nLWluc3RydWN0aW9ucy1hc3Nlc3NtZW50LWxheW91dC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2Fzc2Vzc21lbnQvc3RydWN0dXJlZC1ncmFkaW5nLWluc3RydWN0aW9ucy1hc3Nlc3NtZW50LWxheW91dC9zdHJ1Y3R1cmVkLWdyYWRpbmctaW5zdHJ1Y3Rpb25zLWFzc2Vzc21lbnQtbGF5b3V0LmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9hc3Nlc3NtZW50L2Fzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zL2Fzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zL2Fzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXNzZXNzbWVudC9hc3Nlc3NtZW50LWluc3RydWN0aW9ucy9hc3Nlc3NtZW50LWluc3RydWN0aW9ucy9hc3Nlc3NtZW50LWluc3RydWN0aW9ucy5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXNzZXNzbWVudC9hc3Nlc3NtZW50LWluc3RydWN0aW9ucy9jb2xsYXBzYWJsZS1hc3Nlc3NtZW50LWluc3RydWN0aW9ucy9jb2xsYXBzYWJsZS1hc3Nlc3NtZW50LWluc3RydWN0aW9ucy5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2Fzc2Vzc21lbnQvYXNzZXNzbWVudC1pbnN0cnVjdGlvbnMvY29sbGFwc2FibGUtYXNzZXNzbWVudC1pbnN0cnVjdGlvbnMvY29sbGFwc2FibGUtYXNzZXNzbWVudC1pbnN0cnVjdGlvbnMuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL29yaW9uL2Fzc2Vzc21lbnQvb3Jpb24tYXNzZXNzbWVudC1pbnN0cnVjdGlvbnMuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9hc3Nlc3NtZW50L2Fzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zL2Fzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zLm1vZHVsZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvYXNzZXNzbWVudC9hdGhlbmEuc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9zdHJ1Y3R1cmVkLWdyYWRpbmctY3JpdGVyaW9uL2dyYWRpbmctY3JpdGVyaW9uLm1vZGVsLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZmFBbmdsZURvd24sIGZhQW5nbGVSaWdodCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBMb2NhbFN0b3JhZ2VTZXJ2aWNlIH0gZnJvbSAnbmd4LXdlYnN0b3JhZ2UnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1leHBhbmRhYmxlLXNlY3Rpb24nLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9leHBhbmRhYmxlLXNlY3Rpb24uY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBFeHBhbmRhYmxlU2VjdGlvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgQElucHV0KCkgaGVhZGVyS2V5OiBzdHJpbmc7XG4gICAgQElucHV0KCkgaGFzVHJhbnNsYXRpb24gPSB0cnVlO1xuICAgIEBJbnB1dCgpIGlzU3ViSGVhZGVyID0gZmFsc2U7XG5cbiAgICBpc0NvbGxhcHNlZDogYm9vbGVhbjtcbiAgICAvLyBJY29uc1xuICAgIGZhQW5nbGVSaWdodCA9IGZhQW5nbGVSaWdodDtcbiAgICBmYUFuZ2xlRG93biA9IGZhQW5nbGVEb3duO1xuXG4gICAgcmVhZG9ubHkgcHJlZml4ID0gJ2NvbGxhcHNlZC4nO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBsb2NhbFN0b3JhZ2VTZXJ2aWNlOiBMb2NhbFN0b3JhZ2VTZXJ2aWNlKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuaXNDb2xsYXBzZWQgPSAhIXRoaXMubG9jYWxTdG9yYWdlU2VydmljZS5yZXRyaWV2ZSh0aGlzLnN0b3JhZ2VLZXkpO1xuICAgICAgICB0aGlzLmxvY2FsU3RvcmFnZVNlcnZpY2Uuc3RvcmUodGhpcy5zdG9yYWdlS2V5LCB0aGlzLmlzQ29sbGFwc2VkKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUb2dnbGUgdGhlIHN0YXRlIG9mIHRoZSBpbnN0cnVjdGlvbiBibG9jayBhbmQgc3RvcmUgdGhlIHVwZGF0ZWQgc3RhdGUgaW4gdGhlIGxvY2FsIHN0b3JhZ2UuXG4gICAgICovXG4gICAgdG9nZ2xlQ29sbGFwc2VkKCkge1xuICAgICAgICB0aGlzLmlzQ29sbGFwc2VkID0gIXRoaXMuaXNDb2xsYXBzZWQ7XG4gICAgICAgIHRoaXMubG9jYWxTdG9yYWdlU2VydmljZS5zdG9yZSh0aGlzLnN0b3JhZ2VLZXksIHRoaXMuaXNDb2xsYXBzZWQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIGtleSB0byBpZGVudGlmeSB0aGUgdmFsdWUgaW4gdGhlIGxvY2FsIHN0b3JhZ2VcbiAgICAgKi9cbiAgICBnZXQgc3RvcmFnZUtleSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJlZml4ICsgdGhpcy5oZWFkZXJLZXk7XG4gICAgfVxufVxuIiwiQGlmIChoYXNUcmFuc2xhdGlvbiA9PT0gZmFsc2UgJiYgaGVhZGVyS2V5ICE9PSBudWxsICYmIGlzU3ViSGVhZGVyID09PSBmYWxzZSkge1xuICAgIDxoNSBjbGFzcz1cImV4cGFuZGFibGUtaGVhZGVyXCIgKGNsaWNrKT1cInRvZ2dsZUNvbGxhcHNlZCgpXCI+XG4gICAgICAgIHt7IGhlYWRlcktleSB9fVxuICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJpc0NvbGxhcHNlZCA/IGZhQW5nbGVSaWdodCA6IGZhQW5nbGVEb3duXCI+PC9mYS1pY29uPlxuICAgIDwvaDU+XG59XG5AaWYgKGhhc1RyYW5zbGF0aW9uID09PSB0cnVlICYmIGhlYWRlcktleSAhPT0gbnVsbCAmJiBpc1N1YkhlYWRlciA9PT0gZmFsc2UpIHtcbiAgICA8aDUgY2xhc3M9XCJleHBhbmRhYmxlLWhlYWRlclwiIChjbGljayk9XCJ0b2dnbGVDb2xsYXBzZWQoKVwiPlxuICAgICAgICB7eyBoZWFkZXJLZXkgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgIDxmYS1pY29uIFtpY29uXT1cImlzQ29sbGFwc2VkID8gZmFBbmdsZVJpZ2h0IDogZmFBbmdsZURvd25cIj48L2ZhLWljb24+XG4gICAgPC9oNT5cbn1cbkBpZiAoaGFzVHJhbnNsYXRpb24gPT09IGZhbHNlICYmIGhlYWRlcktleSAhPT0gbnVsbCAmJiBpc1N1YkhlYWRlciA9PT0gdHJ1ZSkge1xuICAgIDxoNiBjbGFzcz1cImV4cGFuZGFibGUtaGVhZGVyXCIgKGNsaWNrKT1cInRvZ2dsZUNvbGxhcHNlZCgpXCI+XG4gICAgICAgIHt7IGhlYWRlcktleSB9fVxuICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJpc0NvbGxhcHNlZCA/IGZhQW5nbGVSaWdodCA6IGZhQW5nbGVEb3duXCI+PC9mYS1pY29uPlxuICAgIDwvaDY+XG59XG48ZGl2IFtuZ2JDb2xsYXBzZV09XCJpc0NvbGxhcHNlZFwiPlxuICAgIDxuZy1jb250ZW50PjwvbmctY29udGVudD5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgR3JhZGluZ0luc3RydWN0aW9uIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvc3RydWN0dXJlZC1ncmFkaW5nLWNyaXRlcmlvbi9ncmFkaW5nLWluc3RydWN0aW9uLm1vZGVsJztcbmltcG9ydCB7IEdyYWRpbmdDcml0ZXJpb24gfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9zdHJ1Y3R1cmVkLWdyYWRpbmctY3JpdGVyaW9uL2dyYWRpbmctY3JpdGVyaW9uLm1vZGVsJztcbmltcG9ydCB7IEFmdGVyVmlld0luaXQsIENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCwgUXVlcnlMaXN0LCBWaWV3Q2hpbGRyZW4gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGZhQ29tcHJlc3MsIGZhRXhwYW5kLCBmYUluZm9DaXJjbGUgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgRXhwYW5kYWJsZVNlY3Rpb25Db21wb25lbnQgfSBmcm9tICdhcHAvYXNzZXNzbWVudC9hc3Nlc3NtZW50LWluc3RydWN0aW9ucy9leHBhbmRhYmxlLXNlY3Rpb24vZXhwYW5kYWJsZS1zZWN0aW9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBkZWxheSwgc3RhcnRXaXRoIH0gZnJvbSAncnhqcyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXN0cnVjdHVyZWQtZ3JhZGluZy1pbnN0cnVjdGlvbnMtYXNzZXNzbWVudC1sYXlvdXQnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9zdHJ1Y3R1cmVkLWdyYWRpbmctaW5zdHJ1Y3Rpb25zLWFzc2Vzc21lbnQtbGF5b3V0LmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9zdHJ1Y3R1cmVkLWdyYWRpbmctaW5zdHJ1Y3Rpb25zLWFzc2Vzc21lbnQtbGF5b3V0LmNvbXBvbmVudC5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIFN0cnVjdHVyZWRHcmFkaW5nSW5zdHJ1Y3Rpb25zQXNzZXNzbWVudExheW91dENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCB7XG4gICAgQElucHV0KCkgcHVibGljIGNyaXRlcmlhOiBHcmFkaW5nQ3JpdGVyaW9uW107XG4gICAgQElucHV0KCkgcmVhZG9ubHk6IGJvb2xlYW47XG4gICAgYWxsb3dEcm9wOiBib29sZWFuO1xuICAgIC8vIEljb25zXG4gICAgZmFJbmZvQ2lyY2xlID0gZmFJbmZvQ2lyY2xlO1xuICAgIGZhRXhwYW5kID0gZmFFeHBhbmQ7XG4gICAgZmFDb21wcmVzcyA9IGZhQ29tcHJlc3M7XG5cbiAgICBAVmlld0NoaWxkcmVuKEV4cGFuZGFibGVTZWN0aW9uQ29tcG9uZW50KSBleHBhbmRhYmxlU2VjdGlvbnM6IFF1ZXJ5TGlzdDxFeHBhbmRhYmxlU2VjdGlvbkNvbXBvbmVudD47XG4gICAgY29sbGFwc2VUb2dnbGVzOiBFeHBhbmRhYmxlU2VjdGlvbkNvbXBvbmVudFtdID0gW107XG5cbiAgICAvKipcbiAgICAgKiBPbkluaXQgc2V0IHRoZSBhbGxvd0Ryb3AgcHJvcGVydHkgdG8gYWxsb3cgZHJvcCBvZiBTR0kgaWYgbm90IGluIHJlYWRPbmx5IG1vZGVcbiAgICAgKi9cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5hbGxvd0Ryb3AgPSAhdGhpcy5yZWFkb25seTtcbiAgICB9XG5cbiAgICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgICAgIHRoaXMuZXhwYW5kYWJsZVNlY3Rpb25zLmNoYW5nZXNcbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIHN0YXJ0V2l0aChbdW5kZWZpbmVkXSksIC8vIHRvIGNhdGNoIHRoZSBpbml0aWFsIHZhbHVlXG4gICAgICAgICAgICAgICAgZGVsYXkoMCksIC8vIHdhaXQgZm9yIGFsbCBjdXJyZW50IGFzeW5jIHRhc2tzIHRvIGZpbmlzaCwgd2hpY2ggY291bGQgY2hhbmdlIHRoZSBxdWVyeSBsaXN0IHVzaW5nIG5nSWYgZXRjLlxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSgoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jb2xsZWN0Q29sbGFwc2FibGVTZWN0aW9ucygpO1xuICAgICAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgY29sbGFwc2VBbGwoKSB7XG4gICAgICAgIHRoaXMuY29sbGFwc2VUb2dnbGVzLmZvckVhY2goKHNlY3Rpb24pID0+IHtcbiAgICAgICAgICAgIGlmICghc2VjdGlvbi5pc0NvbGxhcHNlZCkge1xuICAgICAgICAgICAgICAgIHNlY3Rpb24udG9nZ2xlQ29sbGFwc2VkKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGV4cGFuZEFsbCgpIHtcbiAgICAgICAgdGhpcy5jb2xsYXBzZVRvZ2dsZXMuZm9yRWFjaCgoc2VjdGlvbikgPT4ge1xuICAgICAgICAgICAgaWYgKHNlY3Rpb24uaXNDb2xsYXBzZWQpIHtcbiAgICAgICAgICAgICAgICBzZWN0aW9uLnRvZ2dsZUNvbGxhcHNlZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXQgdGhlIHRvb2x0aXAgb2YgdGhlIGRyYWdnYWJsZSBncmFkaW5nIGluc3RydWN0aW9uIHRvIGJlIGVxdWFsIHRvIHRoZSBmZWVkYmFjayBkZXRhaWwgdGV4dFxuICAgICAqIEBwYXJhbSB7R3JhZGluZ0luc3RydWN0aW9ufSBpbnN0ciAtIHRoZSBpbnN0cnVjdGlvbiBvYmplY3QgZnJvbSB3aGljaCB0aGUgZmVlZGJhY2sgZGV0YWlsIHRleHQgaXMgcmV0cmlldmVkXG4gICAgICovXG4gICAgc2V0VG9vbHRpcChpbnN0cjogR3JhZGluZ0luc3RydWN0aW9uKSB7XG4gICAgICAgIHJldHVybiAnRmVlZGJhY2s6ICcgKyBpbnN0ci5mZWVkYmFjaztcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXQgdGhlIGNvbG9yIG9mIHRoZSBkcmFnZ2FibGUgZ3JhZGluZyBpbnN0cnVjdGlvbiBiYXNlZCBvbiB0aGUgY3JlZGl0cyBvZiB0aGUgaW5zdHJ1Y3Rpb25cbiAgICAgKiAgQHBhcmFtIHtHcmFkaW5nSW5zdHJ1Y3Rpb259IGluc3RyIC0gdGhlIGluc3RydWN0aW9uIG9iamVjdCB3ZSBzZXQgaXRzIGNvbG9yIGJhc2VkIG9uIGl0cyBjcmVkaXRzXG4gICAgICovXG4gICAgc2V0SW5zdHJDb2xvdXIoaW5zdHI6IEdyYWRpbmdJbnN0cnVjdGlvbikge1xuICAgICAgICBsZXQgY29sb3VyO1xuICAgICAgICBpZiAoaW5zdHIuY3JlZGl0cyA9PT0gMCkge1xuICAgICAgICAgICAgY29sb3VyID0gJ3ZhcigtLXNnaS1hc3Nlc3NtZW50LWxheW91dC16ZXJvLWJhY2tncm91bmQpJztcbiAgICAgICAgfSBlbHNlIGlmIChpbnN0ci5jcmVkaXRzIDwgMCkge1xuICAgICAgICAgICAgY29sb3VyID0gJ3ZhcigtLXNnaS1hc3Nlc3NtZW50LWxheW91dC1uZWdhdGl2ZS1iYWNrZ3JvdW5kKSc7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb2xvdXIgPSAndmFyKC0tc2dpLWFzc2Vzc21lbnQtbGF5b3V0LXBvc2l0aXZlLWJhY2tncm91bmQpJztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY29sb3VyO1xuICAgIH1cbiAgICBzZXRTY29yZShucjogbnVtYmVyKSB7XG4gICAgICAgIHJldHVybiBuciArICdQJztcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ29ubmVjdHMgdGhlIFNHSSB3aXRoIHRoZSBGZWVkYmFjayBvZiBhIFN1Ym1pc3Npb24gRWxlbWVudCBpbiBhc3Nlc3NtZW50IGRldGFpbFxuICAgICAqIEBwYXJhbSB7RXZlbnR9IGV2ZW50IC0gVGhlIGRyYWcgZXZlbnRcbiAgICAgKiBAcGFyYW0ge09iamVjdH0gaW5zdHJ1Y3Rpb24gLSBUaGUgU0dJIGVsZW1lbnQgdGhhdCBzaG91bGQgYmUgY29ubmVjdGVkIHdpdGggdGhlIGZlZWRiYWNrIG9uIGRyb3BcbiAgICAgKiB0aGUgY29ycmVzcG9uZGluZyBkcm9wIG1ldGhvZCBpcyBpbiBBc3Nlc3NtZW50RGV0YWlsQ29tcG9uZW50XG4gICAgICovXG4gICAgZHJhZyhldmVudDogYW55LCBpbnN0cnVjdGlvbjogR3JhZGluZ0luc3RydWN0aW9uKSB7XG4gICAgICAgIC8vIFRoZSBtaW1ldHlwZSBoYXMgdG8gYmUgdGV4dC9wbGFpbiB0byBlbmFibGUgZHJhZ2dpbmcgaW50byBhbiBleHRlcm5hbCBhcHBsaWNhdGlvbiwgZS5nLiBPcmlvbiwgQXBvbGxvblxuICAgICAgICBldmVudC5kYXRhVHJhbnNmZXIuc2V0RGF0YSgndGV4dC9wbGFpbicsIEpTT04uc3RyaW5naWZ5KGluc3RydWN0aW9uKSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIGRpc2FibGVzIGRyYWcgaWYgb24gcmVhZE9ubHkgbW9kZVxuICAgICAqL1xuICAgIGRpc2FibGVEcmFnKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5hbGxvd0Ryb3A7XG4gICAgfVxuXG4gICAgY29sbGVjdENvbGxhcHNhYmxlU2VjdGlvbnMoKSB7XG4gICAgICAgIGlmICh0aGlzLmV4cGFuZGFibGVTZWN0aW9ucykge1xuICAgICAgICAgICAgdGhpcy5jb2xsYXBzZVRvZ2dsZXMgPSB0aGlzLmV4cGFuZGFibGVTZWN0aW9ucy50b0FycmF5KCk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJAaWYgKGNyaXRlcmlhKSB7XG4gICAgPGRpdiBjbGFzcz1cIm1iLTJcIj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLXNtIGJ0bi1vdXRsaW5lLXNlY29uZGFyeVwiIGRhdGEtYnMtdG9nZ2xlPVwiYnV0dG9uXCIgKGNsaWNrKT1cImV4cGFuZEFsbCgpXCI+XG4gICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUV4cGFuZFwiPjwvZmEtaWNvbj4gPHNwYW4+e3sgJ2FydGVtaXNBcHAuYXNzZXNzbWVudEluc3RydWN0aW9ucy5leHBhbmRBbGwnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuIGJ0bi1zbSBidG4tb3V0bGluZS1zZWNvbmRhcnlcIiBkYXRhLWJzLXRvZ2dsZT1cImJ1dHRvblwiIChjbGljayk9XCJjb2xsYXBzZUFsbCgpXCI+XG4gICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUNvbXByZXNzXCI+PC9mYS1pY29uPiA8c3Bhbj57eyAnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50SW5zdHJ1Y3Rpb25zLmNvbGxhcHNlQWxsJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxufVxuQGlmIChhbGxvd0Ryb3ApIHtcbiAgICA8ZGl2IGNsYXNzPVwiYWxlcnQgYWxlcnQtaW5mb1wiPlxuICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUluZm9DaXJjbGVcIj48L2ZhLWljb24+XG4gICAgICAgIDxzcGFuPnt7ICdhcnRlbWlzQXBwLmV4ZXJjaXNlLmRyYWdEcm9wSW5zdHJ1Y3Rpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICA8L2Rpdj5cbn1cbkBmb3IgKGNyaXRlcmlvbiBvZiBjcml0ZXJpYTsgdHJhY2sgY3JpdGVyaW9uOyBsZXQgY3JpdGVyaW9uSW5kZXggPSAkaW5kZXgpIHtcbiAgICA8ZGl2PlxuICAgICAgICA8amhpLWV4cGFuZGFibGUtc2VjdGlvbiBbaGFzVHJhbnNsYXRpb25dPVwiZmFsc2VcIiBbaGVhZGVyS2V5XT1cImNyaXRlcmlvbi50aXRsZVwiIFtpc1N1YkhlYWRlcl09XCJ0cnVlXCI+XG4gICAgICAgICAgICBAZm9yIChpbnN0cnVjdGlvbiBvZiBjcml0ZXJpb24hLnN0cnVjdHVyZWRHcmFkaW5nSW5zdHJ1Y3Rpb25zOyB0cmFjayBpbnN0cnVjdGlvbjsgbGV0IGluc3RydWN0aW9uSW5kZXggPSAkaW5kZXgpIHtcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwicm91bmRlZFwiXG4gICAgICAgICAgICAgICAgICAgIGRyYWdnYWJsZT1cInt7IGFsbG93RHJvcCB9fVwiXG4gICAgICAgICAgICAgICAgICAgIChkcmFnc3RhcnQpPVwiZGlzYWJsZURyYWcoKVwiXG4gICAgICAgICAgICAgICAgICAgIChkcmFnc3RhcnQpPVwiZHJhZygkZXZlbnQsIGluc3RydWN0aW9uKVwiXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiY3JpdGVyaW9uLXt7IGNyaXRlcmlvbkluZGV4IH19LWluc3RydWN0aW9uLXt7IGluc3RydWN0aW9uSW5kZXggfX1cIlxuICAgICAgICAgICAgICAgICAgICBbc3R5bGUuYmFja2dyb3VuZC1jb2xvcl09XCJzZXRJbnN0ckNvbG91cihpbnN0cnVjdGlvbilcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzPVwidGFibGUgbGF5b3V0LXRhYmxlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgW2lubmVySFRNTF09XCJzZXRTY29yZShpbnN0cnVjdGlvbi5jcmVkaXRzKVwiIGNsYXNzPVwidGQtc2NvcmVcIj48L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgW2lubmVySFRNTF09XCJpbnN0cnVjdGlvbiEuZ3JhZGluZ1NjYWxlISB8IGh0bWxGb3JNYXJrZG93blwiPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBbaW5uZXJIVE1MXT1cImluc3RydWN0aW9uIS5pbnN0cnVjdGlvbkRlc2NyaXB0aW9uISB8IGh0bWxGb3JNYXJrZG93blwiIFtuZ2JUb29sdGlwXT1cInNldFRvb2x0aXAoaW5zdHJ1Y3Rpb24pXCI+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPVwidGQtdXNhZ2UtY291bnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoaW5zdHJ1Y3Rpb24hLnVzYWdlQ291bnQgJiYgaW5zdHJ1Y3Rpb24hLnVzYWdlQ291bnQgIT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyBpbnN0cnVjdGlvbi51c2FnZUNvdW50IH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJiM4NzM0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1oZWxwLWljb24gdGV4dD1cImFydGVtaXNBcHAuZXhlcmNpc2UudXNhZ2VDb3VudEhpbnRcIj48L2poaS1oZWxwLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvamhpLWV4cGFuZGFibGUtc2VjdGlvbj5cbiAgICAgICAgPGJyIC8+XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIENvbnRlbnRDaGlsZCwgSW5wdXQsIFRlbXBsYXRlUmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTYWZlSHRtbCB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xuaW1wb3J0IHsgVU1MRGlhZ3JhbVR5cGUsIFVNTE1vZGVsIH0gZnJvbSAnQGxzMWludHVtL2Fwb2xsb24nO1xuaW1wb3J0IHsgQXJ0ZW1pc01hcmtkb3duU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24uc2VydmljZSc7XG5pbXBvcnQgeyBFeGVyY2lzZSwgRXhlcmNpc2VUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IFRleHRFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy90ZXh0LWV4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IE1vZGVsaW5nRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvbW9kZWxpbmctZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgRmlsZVVwbG9hZEV4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2ZpbGUtdXBsb2FkLWV4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvcHJvZ3JhbW1pbmctZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgR3JhZGluZ0NyaXRlcmlvbiB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3N0cnVjdHVyZWQtZ3JhZGluZy1jcml0ZXJpb24vZ3JhZGluZy1jcml0ZXJpb24ubW9kZWwnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZVN0dWRlbnRQYXJ0aWNpcGF0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3BhcnRpY2lwYXRpb24vcHJvZ3JhbW1pbmctZXhlcmNpc2Utc3R1ZGVudC1wYXJ0aWNpcGF0aW9uLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktYXNzZXNzbWVudC1pbnN0cnVjdGlvbnMnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9hc3Nlc3NtZW50LWluc3RydWN0aW9ucy5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIEFzc2Vzc21lbnRJbnN0cnVjdGlvbnNDb21wb25lbnQge1xuICAgIGV4ZXJjaXNlOiBFeGVyY2lzZTtcbiAgICBwcm9ncmFtbWluZ0V4ZXJjaXNlPzogUHJvZ3JhbW1pbmdFeGVyY2lzZTtcbiAgICBwcm9ibGVtU3RhdGVtZW50OiBTYWZlSHRtbDtcbiAgICBncmFkaW5nSW5zdHJ1Y3Rpb25zOiBTYWZlSHRtbDtcbiAgICBzYW1wbGVTb2x1dGlvbkV4cGxhbmF0aW9uPzogU2FmZUh0bWw7XG4gICAgc2FtcGxlU29sdXRpb25Nb2RlbD86IFVNTE1vZGVsO1xuICAgIHNhbXBsZVNvbHV0aW9uRGlhZ3JhbVR5cGU/OiBVTUxEaWFncmFtVHlwZTtcbiAgICBjcml0ZXJpYTogR3JhZGluZ0NyaXRlcmlvbltdO1xuXG4gICAgQElucHV0KCkgaXNBc3Nlc3NtZW50VHJhaW5pbmcgPSBmYWxzZTtcbiAgICBASW5wdXQoKSBzaG93QXNzZXNzbWVudEluc3RydWN0aW9ucyA9IHRydWU7XG5cbiAgICBASW5wdXQoKSByZWFkT25seTogYm9vbGVhbjtcbiAgICAvLyBGb3IgcHJvZ3JhbW1pbmcgZXhlcmNpc2VzIHdlIGhhbmQgb3ZlciB0aGUgcGFydGljaXBhdGlvbiBvciB1c2UgdGhlIHRlbXBsYXRlIHBhcnRpY2lwYXRpb25cbiAgICBASW5wdXQoKSBwcm9ncmFtbWluZ1BhcnRpY2lwYXRpb24/OiBQcm9ncmFtbWluZ0V4ZXJjaXNlU3R1ZGVudFBhcnRpY2lwYXRpb247XG5cbiAgICByZWFkb25seSBFeGVyY2lzZVR5cGUgPSBFeGVyY2lzZVR5cGU7XG5cbiAgICAvLyBleHRlbnNpb24gcG9pbnRzLCBzZWUgc2hhcmVkL2V4dGVuc2lvbi1wb2ludFxuICAgIEBDb250ZW50Q2hpbGQoJ292ZXJyaWRlVGl0bGUnKSBvdmVycmlkZVRpdGxlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBtYXJrZG93blNlcnZpY2U6IEFydGVtaXNNYXJrZG93blNlcnZpY2UpIHt9XG5cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQGFuZ3VsYXItZXNsaW50L25vLWlucHV0LXJlbmFtZVxuICAgIEBJbnB1dCgnZXhlcmNpc2UnKSBzZXQgZXhlcmNpc2VJbnB1dChleGVyY2lzZTogRXhlcmNpc2UpIHtcbiAgICAgICAgdGhpcy5leGVyY2lzZSA9IGV4ZXJjaXNlO1xuICAgICAgICB0aGlzLnByb2JsZW1TdGF0ZW1lbnQgPSB0aGlzLm1hcmtkb3duU2VydmljZS5zYWZlSHRtbEZvck1hcmtkb3duKGV4ZXJjaXNlLnByb2JsZW1TdGF0ZW1lbnQpO1xuICAgICAgICB0aGlzLmdyYWRpbmdJbnN0cnVjdGlvbnMgPSB0aGlzLm1hcmtkb3duU2VydmljZS5zYWZlSHRtbEZvck1hcmtkb3duKGV4ZXJjaXNlLmdyYWRpbmdJbnN0cnVjdGlvbnMpO1xuICAgICAgICAvLyBtYWtlIHN1cmUgdGhlIGFycmF5IGlzIGluaXRpYWxpemVkXG4gICAgICAgIHRoaXMuY3JpdGVyaWEgPSBleGVyY2lzZS5ncmFkaW5nQ3JpdGVyaWEgfHwgW107XG5cbiAgICAgICAgbGV0IHNhbXBsZVNvbHV0aW9uTWFya2Rvd246IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgICAgICAgc3dpdGNoIChleGVyY2lzZS50eXBlKSB7XG4gICAgICAgICAgICBjYXNlIEV4ZXJjaXNlVHlwZS5NT0RFTElORzpcbiAgICAgICAgICAgICAgICBjb25zdCBtb2RlbGluZ0V4ZXJjaXNlID0gZXhlcmNpc2UgYXMgTW9kZWxpbmdFeGVyY2lzZTtcbiAgICAgICAgICAgICAgICBzYW1wbGVTb2x1dGlvbk1hcmtkb3duID0gbW9kZWxpbmdFeGVyY2lzZS5leGFtcGxlU29sdXRpb25FeHBsYW5hdGlvbjtcbiAgICAgICAgICAgICAgICBpZiAobW9kZWxpbmdFeGVyY2lzZS5leGFtcGxlU29sdXRpb25Nb2RlbCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNhbXBsZVNvbHV0aW9uTW9kZWwgPSBKU09OLnBhcnNlKG1vZGVsaW5nRXhlcmNpc2UuZXhhbXBsZVNvbHV0aW9uTW9kZWwpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0aGlzLnNhbXBsZVNvbHV0aW9uRGlhZ3JhbVR5cGUgPSBtb2RlbGluZ0V4ZXJjaXNlLmRpYWdyYW1UeXBlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBFeGVyY2lzZVR5cGUuVEVYVDpcbiAgICAgICAgICAgICAgICBjb25zdCB0ZXh0RXhlcmNpc2UgPSBleGVyY2lzZSBhcyBUZXh0RXhlcmNpc2U7XG4gICAgICAgICAgICAgICAgc2FtcGxlU29sdXRpb25NYXJrZG93biA9IHRleHRFeGVyY2lzZS5leGFtcGxlU29sdXRpb247XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIEV4ZXJjaXNlVHlwZS5GSUxFX1VQTE9BRDpcbiAgICAgICAgICAgICAgICBjb25zdCBmaWxlVXBsb2FkRXhlcmNpc2UgPSBleGVyY2lzZSBhcyBGaWxlVXBsb2FkRXhlcmNpc2U7XG4gICAgICAgICAgICAgICAgc2FtcGxlU29sdXRpb25NYXJrZG93biA9IGZpbGVVcGxvYWRFeGVyY2lzZS5leGFtcGxlU29sdXRpb247XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIEV4ZXJjaXNlVHlwZS5QUk9HUkFNTUlORzpcbiAgICAgICAgICAgICAgICB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2UgPSBleGVyY2lzZSBhcyBQcm9ncmFtbWluZ0V4ZXJjaXNlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzYW1wbGVTb2x1dGlvbk1hcmtkb3duKSB7XG4gICAgICAgICAgICB0aGlzLnNhbXBsZVNvbHV0aW9uRXhwbGFuYXRpb24gPSB0aGlzLm1hcmtkb3duU2VydmljZS5zYWZlSHRtbEZvck1hcmtkb3duKHNhbXBsZVNvbHV0aW9uTWFya2Rvd24pO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiQGlmIChzaG93QXNzZXNzbWVudEluc3RydWN0aW9ucykge1xuICAgIDxkaXYgY2xhc3M9XCJib3JkZXIgcC0yXCI+XG4gICAgICAgIDxqaGktZXhwYW5kYWJsZS1zZWN0aW9uIGhlYWRlcktleT1cImFydGVtaXNBcHAuYXNzZXNzbWVudEluc3RydWN0aW9ucy5hc3Nlc3NtZW50SW5zdHJ1Y3Rpb25zXCI+XG4gICAgICAgICAgICA8cCBjbGFzcz1cIm1hcmtkb3duLXByZXZpZXdcIiBbaW5uZXJIVE1MXT1cImdyYWRpbmdJbnN0cnVjdGlvbnNcIj48L3A+XG4gICAgICAgIDwvamhpLWV4cGFuZGFibGUtc2VjdGlvbj5cbiAgICAgICAgPGpoaS1leHBhbmRhYmxlLXNlY3Rpb24gaGVhZGVyS2V5PVwiYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50SW5zdHJ1Y3Rpb25zLnN0cnVjdHVyZWRHcmFkaW5nSW5zdHJ1Y3Rpb25zXCI+XG4gICAgICAgICAgICA8amhpLXN0cnVjdHVyZWQtZ3JhZGluZy1pbnN0cnVjdGlvbnMtYXNzZXNzbWVudC1sYXlvdXQgW3JlYWRvbmx5XT1cInJlYWRPbmx5XCIgW2NyaXRlcmlhXT1cImNyaXRlcmlhXCI+PC9qaGktc3RydWN0dXJlZC1ncmFkaW5nLWluc3RydWN0aW9ucy1hc3Nlc3NtZW50LWxheW91dD5cbiAgICAgICAgPC9qaGktZXhwYW5kYWJsZS1zZWN0aW9uPlxuICAgIDwvZGl2PlxufVxuPGgzICpqaGlFeHRlbnNpb25Qb2ludD1cIm92ZXJyaWRlVGl0bGVcIj57eyBleGVyY2lzZS50aXRsZSB9fTwvaDM+XG48amhpLWV4cGFuZGFibGUtc2VjdGlvbiBoZWFkZXJLZXk9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnRJbnN0cnVjdGlvbnMucHJvYmxlbVN0YXRlbWVudFwiPlxuICAgIEBzd2l0Y2ggKGV4ZXJjaXNlLnR5cGUpIHtcbiAgICAgICAgQGNhc2UgKEV4ZXJjaXNlVHlwZS5QUk9HUkFNTUlORykge1xuICAgICAgICAgICAgPGpoaS1wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbnNcbiAgICAgICAgICAgICAgICBbZXhlcmNpc2VdPVwicHJvZ3JhbW1pbmdFeGVyY2lzZSFcIlxuICAgICAgICAgICAgICAgIFtwYXJ0aWNpcGF0aW9uXT1cInByb2dyYW1taW5nUGFydGljaXBhdGlvbiA/IHByb2dyYW1taW5nUGFydGljaXBhdGlvbiA6IHByb2dyYW1taW5nRXhlcmNpc2UhLnRlbXBsYXRlUGFydGljaXBhdGlvbiFcIlxuICAgICAgICAgICAgICAgIFtwZXJzb25hbFBhcnRpY2lwYXRpb25dPVwiZmFsc2VcIlxuICAgICAgICAgICAgPjwvamhpLXByb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9ucz5cbiAgICAgICAgfVxuICAgICAgICBAZGVmYXVsdCB7XG4gICAgICAgICAgICA8cCBjbGFzcz1cIm1hcmtkb3duLXByZXZpZXdcIiBbaW5uZXJIVE1MXT1cInByb2JsZW1TdGF0ZW1lbnRcIj48L3A+XG4gICAgICAgIH1cbiAgICB9XG48L2poaS1leHBhbmRhYmxlLXNlY3Rpb24+XG48amhpLWV4cGFuZGFibGUtc2VjdGlvbiBoZWFkZXJLZXk9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnRJbnN0cnVjdGlvbnMuc2FtcGxlU29sdXRpb25cIj5cbiAgICBAc3dpdGNoIChleGVyY2lzZS50eXBlKSB7XG4gICAgICAgIEBjYXNlIChFeGVyY2lzZVR5cGUuUFJPR1JBTU1JTkcpIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtYi0zXCI+XG4gICAgICAgICAgICAgICAgPGEgamhpU2VjdXJlTGluayBbaHJlZl09XCJwcm9ncmFtbWluZ0V4ZXJjaXNlPy5zb2x1dGlvblBhcnRpY2lwYXRpb24/LnJlcG9zaXRvcnlVcmlcIj5cbiAgICAgICAgICAgICAgICAgICAgPGpoaS1idXR0b24gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5leGVyY2lzZUFzc2Vzc21lbnREYXNoYm9hcmQucHJvZ3JhbW1pbmdFeGVyY2lzZS5leGFtcGxlU29sdXRpb25cIj5FeGFtcGxlIHNvbHV0aW9uIHJlcG9zaXRvcnk8L2poaS1idXR0b24+XG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgQGRlZmF1bHQge1xuICAgICAgICAgICAgQGlmIChzYW1wbGVTb2x1dGlvbk1vZGVsKSB7XG4gICAgICAgICAgICAgICAgPGpoaS1tb2RlbGluZy1lZGl0b3IgW3JlYWRPbmx5XT1cInRydWVcIiBbZGlhZ3JhbVR5cGVdPVwic2FtcGxlU29sdXRpb25EaWFncmFtVHlwZSFcIiBbdW1sTW9kZWxdPVwic2FtcGxlU29sdXRpb25Nb2RlbCFcIiAvPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmIChzYW1wbGVTb2x1dGlvbkV4cGxhbmF0aW9uKSB7XG4gICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJtYXJrZG93bi1wcmV2aWV3XCIgW2lubmVySFRNTF09XCJzYW1wbGVTb2x1dGlvbkV4cGxhbmF0aW9uIVwiPjwvcD5cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbjwvamhpLWV4cGFuZGFibGUtc2VjdGlvbj5cbkBpZiAoaXNBc3Nlc3NtZW50VHJhaW5pbmcpIHtcbiAgICA8amhpLWV4cGFuZGFibGUtc2VjdGlvbiBoZWFkZXJLZXk9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnRJbnN0cnVjdGlvbnMudHJhaW5pbmdFdmFsdWF0aW9uQ3JpdGVyaWEudGl0bGVcIj5cbiAgICAgICAgPHAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50SW5zdHJ1Y3Rpb25zLnRyYWluaW5nRXZhbHVhdGlvbkNyaXRlcmlhLmRlc2NyaXB0aW9uXCI+PC9wPlxuICAgIDwvamhpLWV4cGFuZGFibGUtc2VjdGlvbj5cbn1cbiIsImltcG9ydCB7IEFmdGVyVmlld0luaXQsIENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGZhTGlzdEFsdCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXJlZ3VsYXItc3ZnLWljb25zJztcbmltcG9ydCB7IGZhQ2hldnJvbkxlZnQsIGZhQ2hldnJvblJpZ2h0LCBmYUdyaXBMaW5lc1ZlcnRpY2FsIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IEV4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCBpbnRlcmFjdCBmcm9tICdpbnRlcmFjdGpzJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktY29sbGFwc2FibGUtYXNzZXNzbWVudC1pbnN0cnVjdGlvbnMnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9jb2xsYXBzYWJsZS1hc3Nlc3NtZW50LWluc3RydWN0aW9ucy5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vY29sbGFwc2FibGUtYXNzZXNzbWVudC1pbnN0cnVjdGlvbnMuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBDb2xsYXBzYWJsZUFzc2Vzc21lbnRJbnN0cnVjdGlvbnNDb21wb25lbnQgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0IHtcbiAgICBASW5wdXQoKSBpc0Fzc2Vzc21lbnRUcmFpbmluZyA9IGZhbHNlO1xuICAgIEBJbnB1dCgpIHNob3dBc3Nlc3NtZW50SW5zdHJ1Y3Rpb25zID0gdHJ1ZTtcbiAgICBASW5wdXQoKSBleGVyY2lzZTogRXhlcmNpc2U7XG4gICAgQElucHV0KCkgY29sbGFwc2VkID0gZmFsc2U7XG4gICAgQElucHV0KCkgcmVhZE9ubHk6IGJvb2xlYW47XG5cbiAgICAvLyBJY29uc1xuICAgIGZhQ2hldnJvblJpZ2h0ID0gZmFDaGV2cm9uUmlnaHQ7XG4gICAgZmFDaGV2cm9uTGVmdCA9IGZhQ2hldnJvbkxlZnQ7XG4gICAgZmFHcmlwTGluZXNWZXJ0aWNhbCA9IGZhR3JpcExpbmVzVmVydGljYWw7XG4gICAgZmFyTGlzdEFsdCA9IGZhTGlzdEFsdDtcblxuICAgIC8qKlxuICAgICAqIENvbmZpZ3VyZXMgaW50ZXJhY3QgdG8gbWFrZSBpbnN0cnVjdGlvbnMgZXhwYW5kYWJsZVxuICAgICAqL1xuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcbiAgICAgICAgaW50ZXJhY3QoJy5leHBhbmRlZC1pbnN0cnVjdGlvbnMnKVxuICAgICAgICAgICAgLnJlc2l6YWJsZSh7XG4gICAgICAgICAgICAgICAgZWRnZXM6IHsgbGVmdDogJy5kcmFnZ2FibGUtbGVmdCcsIHJpZ2h0OiBmYWxzZSwgYm90dG9tOiBmYWxzZSwgdG9wOiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgIG1vZGlmaWVyczogW1xuICAgICAgICAgICAgICAgICAgICAvLyBTZXQgbWF4aW11bSB3aWR0aFxuICAgICAgICAgICAgICAgICAgICBpbnRlcmFjdC5tb2RpZmllcnMhLnJlc3RyaWN0U2l6ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICBtaW46IHsgd2lkdGg6IDIxNSwgaGVpZ2h0OiAwIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXg6IHsgd2lkdGg6IDEwMDAsIGhlaWdodDogMjAwMCB9LFxuICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgIGluZXJ0aWE6IHRydWUsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLm9uKCdyZXNpemVzdGFydCcsIGZ1bmN0aW9uIChldmVudDogYW55KSB7XG4gICAgICAgICAgICAgICAgZXZlbnQudGFyZ2V0LmNsYXNzTGlzdC5hZGQoJ2NhcmQtcmVzaXphYmxlJyk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLm9uKCdyZXNpemVlbmQnLCBmdW5jdGlvbiAoZXZlbnQ6IGFueSkge1xuICAgICAgICAgICAgICAgIGV2ZW50LnRhcmdldC5jbGFzc0xpc3QucmVtb3ZlKCdjYXJkLXJlc2l6YWJsZScpO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5vbigncmVzaXplbW92ZScsIGZ1bmN0aW9uIChldmVudDogYW55KSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQudGFyZ2V0O1xuICAgICAgICAgICAgICAgIHRhcmdldC5zdHlsZS53aWR0aCA9IGV2ZW50LnJlY3Qud2lkdGggKyAncHgnO1xuICAgICAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiQGlmICghY29sbGFwc2VkKSB7XG4gICAgPGRpdiBjbGFzcz1cImV4cGFuZGVkLWluc3RydWN0aW9ucyBpbnN0cnVjdGlvbnMtY29udGFpbmVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJkcmFnZ2FibGUtbGVmdFwiPjxmYS1pY29uIFtpY29uXT1cImZhR3JpcExpbmVzVmVydGljYWxcIj48L2ZhLWljb24+PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1oZWFkZXIgdGV4dC13aGl0ZSBiZy1wcmltYXJ5XCIgKGNsaWNrKT1cImNvbGxhcHNlZCA9ICFjb2xsYXBzZWRcIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3M9XCJjYXJkLXRpdGxlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhckxpc3RBbHRcIj48L2ZhLWljb24+Jm5ic3A7XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudEluc3RydWN0aW9ucy5pbnN0cnVjdGlvbnMuaW5zdHJ1Y3Rpb25zXCI+ICZuYnNwOyBJbnN0cnVjdGlvbnMgJm5ic3A7IDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQ2hldnJvblJpZ2h0XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwid3JhcHBlci1zY3JvbGwteSBzY3JvbGxiYXIgdmgtMTAwXCI+XG4gICAgICAgICAgICAgICAgPGpoaS1hc3Nlc3NtZW50LWluc3RydWN0aW9uc1xuICAgICAgICAgICAgICAgICAgICBbcmVhZE9ubHldPVwicmVhZE9ubHlcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImNhcmQtYm9keSBtYXJrZG93bi1wcmV2aWV3XCJcbiAgICAgICAgICAgICAgICAgICAgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCJcbiAgICAgICAgICAgICAgICAgICAgW2lzQXNzZXNzbWVudFRyYWluaW5nXT1cImlzQXNzZXNzbWVudFRyYWluaW5nXCJcbiAgICAgICAgICAgICAgICAgICAgW3Nob3dBc3Nlc3NtZW50SW5zdHJ1Y3Rpb25zXT1cInNob3dBc3Nlc3NtZW50SW5zdHJ1Y3Rpb25zXCJcbiAgICAgICAgICAgICAgICA+PC9qaGktYXNzZXNzbWVudC1pbnN0cnVjdGlvbnM+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG59IEBlbHNlIHtcbiAgICA8ZGl2IGNsYXNzPVwiY29sbGFwc2VkLWluc3RydWN0aW9ucyBpbnN0cnVjdGlvbnMtY29udGFpbmVyIHRleHQtd2hpdGUgYmctcHJpbWFyeVwiIChjbGljayk9XCJjb2xsYXBzZWQgPSAhY29sbGFwc2VkXCI+XG4gICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQ2hldnJvbkxlZnRcIj48L2ZhLWljb24+XG4gICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYXNzZXNzbWVudEluc3RydWN0aW9ucy5pbnN0cnVjdGlvbnMuaW5zdHJ1Y3Rpb25zXCI+ICZuYnNwOyBJbnN0cnVjdGlvbnMgJm5ic3A7IDwvc3Bhbj5cbiAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFDaGV2cm9uTGVmdFwiPjwvZmEtaWNvbj5cbiAgICA8L2Rpdj5cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2VTdHVkZW50UGFydGljaXBhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9wYXJ0aWNpcGF0aW9uL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXN0dWRlbnQtcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLW9yaW9uLWFzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zJyxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICA8amhpLWFzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zIFtleGVyY2lzZV09XCJleGVyY2lzZVwiIFtwcm9ncmFtbWluZ1BhcnRpY2lwYXRpb25dPVwicHJvZ3JhbW1pbmdQYXJ0aWNpcGF0aW9uXCIgW3JlYWRPbmx5XT1cInJlYWRPbmx5XCI+XG4gICAgICAgICAgICA8bmctdGVtcGxhdGUgI292ZXJyaWRlVGl0bGU+XG4gICAgICAgICAgICAgICAgPCEtLSBOb3RoaW5nLCB0aXRsZSBpcyBzdXBwcmVzc2VkIC0tPlxuICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgPC9qaGktYXNzZXNzbWVudC1pbnN0cnVjdGlvbnM+XG4gICAgYCxcbn0pXG5leHBvcnQgY2xhc3MgT3Jpb25Bc3Nlc3NtZW50SW5zdHJ1Y3Rpb25zQ29tcG9uZW50IHtcbiAgICBASW5wdXQoKSByZWFkT25seTogYm9vbGVhbjtcbiAgICBASW5wdXQoKSBwcm9ncmFtbWluZ1BhcnRpY2lwYXRpb24/OiBQcm9ncmFtbWluZ0V4ZXJjaXNlU3R1ZGVudFBhcnRpY2lwYXRpb247XG4gICAgQElucHV0KCkgZXhlcmNpc2U6IEV4ZXJjaXNlO1xufVxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBOZ2JNb2R1bGUgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNNb2RlbGluZ0VkaXRvck1vZHVsZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvbW9kZWxpbmcvc2hhcmVkL21vZGVsaW5nLWVkaXRvci5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1Byb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdGlvbnNSZW5kZXJNb2R1bGUgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9pbnN0cnVjdGlvbnMtcmVuZGVyL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9ucy1yZW5kZXIubW9kdWxlJztcbmltcG9ydCB7IEV4cGFuZGFibGVTZWN0aW9uQ29tcG9uZW50IH0gZnJvbSAnLi9leHBhbmRhYmxlLXNlY3Rpb24vZXhwYW5kYWJsZS1zZWN0aW9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDb2xsYXBzYWJsZUFzc2Vzc21lbnRJbnN0cnVjdGlvbnNDb21wb25lbnQgfSBmcm9tICcuL2NvbGxhcHNhYmxlLWFzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zL2NvbGxhcHNhYmxlLWFzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBc3Nlc3NtZW50SW5zdHJ1Y3Rpb25zQ29tcG9uZW50IH0gZnJvbSAnLi9hc3Nlc3NtZW50LWluc3RydWN0aW9ucy9hc3Nlc3NtZW50LWluc3RydWN0aW9ucy5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc0Fzc2Vzc21lbnRTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvYXNzZXNzbWVudC9hc3Nlc3NtZW50LXNoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgU3RydWN0dXJlZEdyYWRpbmdJbnN0cnVjdGlvbnNBc3Nlc3NtZW50TGF5b3V0Q29tcG9uZW50IH0gZnJvbSAnYXBwL2Fzc2Vzc21lbnQvc3RydWN0dXJlZC1ncmFkaW5nLWluc3RydWN0aW9ucy1hc3Nlc3NtZW50LWxheW91dC9zdHJ1Y3R1cmVkLWdyYWRpbmctaW5zdHJ1Y3Rpb25zLWFzc2Vzc21lbnQtbGF5b3V0LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL3NoYXJlZC1jb21wb25lbnQubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNNYXJrZG93bk1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24ubW9kdWxlJztcbmltcG9ydCB7IE9yaW9uQXNzZXNzbWVudEluc3RydWN0aW9uc0NvbXBvbmVudCB9IGZyb20gJ2FwcC9vcmlvbi9hc3Nlc3NtZW50L29yaW9uLWFzc2Vzc21lbnQtaW5zdHJ1Y3Rpb25zLmNvbXBvbmVudCc7XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW1xuICAgICAgICBDb21tb25Nb2R1bGUsXG4gICAgICAgIE5nYk1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc1NoYXJlZE1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc01vZGVsaW5nRWRpdG9yTW9kdWxlLFxuICAgICAgICBBcnRlbWlzUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0aW9uc1JlbmRlck1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc0Fzc2Vzc21lbnRTaGFyZWRNb2R1bGUsXG4gICAgICAgIEFydGVtaXNTaGFyZWRDb21wb25lbnRNb2R1bGUsXG4gICAgICAgIEFydGVtaXNNYXJrZG93bk1vZHVsZSxcbiAgICBdLFxuICAgIGRlY2xhcmF0aW9uczogW1xuICAgICAgICBFeHBhbmRhYmxlU2VjdGlvbkNvbXBvbmVudCxcbiAgICAgICAgQXNzZXNzbWVudEluc3RydWN0aW9uc0NvbXBvbmVudCxcbiAgICAgICAgT3Jpb25Bc3Nlc3NtZW50SW5zdHJ1Y3Rpb25zQ29tcG9uZW50LFxuICAgICAgICBDb2xsYXBzYWJsZUFzc2Vzc21lbnRJbnN0cnVjdGlvbnNDb21wb25lbnQsXG4gICAgICAgIFN0cnVjdHVyZWRHcmFkaW5nSW5zdHJ1Y3Rpb25zQXNzZXNzbWVudExheW91dENvbXBvbmVudCxcbiAgICBdLFxuICAgIGV4cG9ydHM6IFtcbiAgICAgICAgQ29sbGFwc2FibGVBc3Nlc3NtZW50SW5zdHJ1Y3Rpb25zQ29tcG9uZW50LFxuICAgICAgICBFeHBhbmRhYmxlU2VjdGlvbkNvbXBvbmVudCxcbiAgICAgICAgU3RydWN0dXJlZEdyYWRpbmdJbnN0cnVjdGlvbnNBc3Nlc3NtZW50TGF5b3V0Q29tcG9uZW50LFxuICAgICAgICBBc3Nlc3NtZW50SW5zdHJ1Y3Rpb25zQ29tcG9uZW50LFxuICAgICAgICBPcmlvbkFzc2Vzc21lbnRJbnN0cnVjdGlvbnNDb21wb25lbnQsXG4gICAgXSxcbn0pXG5leHBvcnQgY2xhc3MgQXNzZXNzbWVudEluc3RydWN0aW9uc01vZHVsZSB7fVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgbWFwLCBvZiwgc3dpdGNoTWFwIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBQcm9maWxlU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvbGF5b3V0cy9wcm9maWxlcy9wcm9maWxlLnNlcnZpY2UnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdGZWVkYmFja1N1Z2dlc3Rpb24sIFRleHRGZWVkYmFja1N1Z2dlc3Rpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvZmVlZGJhY2stc3VnZ2VzdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBGRUVEQkFDS19TVUdHRVNUSU9OX0FDQ0VQVEVEX0lERU5USUZJRVIsIEZFRURCQUNLX1NVR0dFU1RJT05fSURFTlRJRklFUiwgRmVlZGJhY2ssIEZlZWRiYWNrVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9mZWVkYmFjay5tb2RlbCc7XG5pbXBvcnQgeyBUZXh0QmxvY2sgfSBmcm9tICdhcHAvZW50aXRpZXMvdGV4dC1ibG9jay5tb2RlbCc7XG5pbXBvcnQgeyBUZXh0QmxvY2tSZWYgfSBmcm9tICdhcHAvZW50aXRpZXMvdGV4dC1ibG9jay1yZWYubW9kZWwnO1xuaW1wb3J0IHsgVGV4dFN1Ym1pc3Npb24gfSBmcm9tICdhcHAvZW50aXRpZXMvdGV4dC1zdWJtaXNzaW9uLm1vZGVsJztcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBBdGhlbmFTZXJ2aWNlIHtcbiAgICBwdWJsaWMgcmVzb3VyY2VVcmwgPSAnYXBpL2F0aGVuYSc7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJvdGVjdGVkIGh0dHA6IEh0dHBDbGllbnQsXG4gICAgICAgIHByaXZhdGUgcHJvZmlsZVNlcnZpY2U6IFByb2ZpbGVTZXJ2aWNlLFxuICAgICkge31cblxuICAgIHB1YmxpYyBpc0VuYWJsZWQoKTogT2JzZXJ2YWJsZTxib29sZWFuPiB7XG4gICAgICAgIHJldHVybiB0aGlzLnByb2ZpbGVTZXJ2aWNlLmdldFByb2ZpbGVJbmZvKCkucGlwZShzd2l0Y2hNYXAoKHByb2ZpbGVJbmZvKSA9PiBvZihwcm9maWxlSW5mby5hY3RpdmVQcm9maWxlcy5pbmNsdWRlcygnYXRoZW5hJykpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGZlZWRiYWNrIHN1Z2dlc3Rpb25zIGZvciB0aGUgZ2l2ZW4gc3VibWlzc2lvbiBmcm9tIEF0aGVuYSAtIGZvciBwcm9ncmFtbWluZyBleGVyY2lzZXNcbiAgICAgKiBDdXJyZW50bHksIHRoaXMgaXMgc2VwYXJhdGUgZm9yIHByb2dyYW1taW5nIGFuZCB0ZXh0IGV4ZXJjaXNlcyAod2lsbCBiZSBjaGFuZ2VkKVxuICAgICAqXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlXG4gICAgICogQHBhcmFtIHN1Ym1pc3Npb25JZCB0aGUgaWQgb2YgdGhlIHN1Ym1pc3Npb25cbiAgICAgKiBAcmV0dXJuIG9ic2VydmFibGUgdGhhdCBlbWl0cyB0aGUgZmVlZGJhY2sgc3VnZ2VzdGlvbnNcbiAgICAgKi9cbiAgICBwcml2YXRlIGdldEZlZWRiYWNrU3VnZ2VzdGlvbnM8VD4oZXhlcmNpc2U6IEV4ZXJjaXNlLCBzdWJtaXNzaW9uSWQ6IG51bWJlcik6IE9ic2VydmFibGU8VFtdPiB7XG4gICAgICAgIGlmICghZXhlcmNpc2UuZmVlZGJhY2tTdWdnZXN0aW9uc0VuYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybiBvZihbXSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuaXNFbmFibGVkKCkucGlwZShcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoaXNBdGhlbmFFbmFibGVkKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFpc0F0aGVuYUVuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9mKFtdIGFzIFRbXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgICAgICAgICAgLmdldDxUW10+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7ZXhlcmNpc2UudHlwZX0tZXhlcmNpc2VzLyR7ZXhlcmNpc2UuaWR9L3N1Ym1pc3Npb25zLyR7c3VibWlzc2lvbklkfS9mZWVkYmFjay1zdWdnZXN0aW9uc2AsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KVxuICAgICAgICAgICAgICAgICAgICAucGlwZShzd2l0Y2hNYXAoKHJlczogSHR0cFJlc3BvbnNlPFRbXT4pID0+IG9mKHJlcy5ib2R5ISkpKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEZpbmQgYSBncmFkaW5nIGluc3RydWN0aW9uIGJ5IGlkIGluIHRoZSBnaXZlbiBleGVyY2lzZVxuICAgICAqL1xuICAgIHByaXZhdGUgZmluZEdyYWRpbmdJbnN0cnVjdGlvbihleGVyY2lzZTogRXhlcmNpc2UsIGlkOiBudW1iZXIpOiBhbnkgfCB1bmRlZmluZWQge1xuICAgICAgICBmb3IgKGNvbnN0IGNyaXRlcml1bSBvZiBleGVyY2lzZS5ncmFkaW5nQ3JpdGVyaWEgPz8gW10pIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgaW5zdHJ1Y3Rpb24gb2YgY3JpdGVyaXVtLnN0cnVjdHVyZWRHcmFkaW5nSW5zdHJ1Y3Rpb25zKSB7XG4gICAgICAgICAgICAgICAgaWYgKGluc3RydWN0aW9uLmlkID09IGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnN0cnVjdGlvbjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgZmVlZGJhY2sgc3VnZ2VzdGlvbnMgZm9yIHRoZSBnaXZlbiB0ZXh0IHN1Ym1pc3Npb24gZnJvbSBBdGhlbmFcbiAgICAgKlxuICAgICAqIEBwYXJhbSBleGVyY2lzZVxuICAgICAqIEBwYXJhbSBzdWJtaXNzaW9uICB0aGUgc3VibWlzc2lvblxuICAgICAqIEByZXR1cm4gb2JzZXJ2YWJsZSB0aGF0IGVtaXRzIHRoZSByZWZlcmVuY2VkIGZlZWRiYWNrIHN1Z2dlc3Rpb25zIGFzIFRleHRCbG9ja1JlZiBvYmplY3RzXG4gICAgICogd2l0aCBUZXh0QmxvY2tzIGFuZCB0aGUgdW5yZWZlcmVuY2VkIGZlZWRiYWNrIHN1Z2dlc3Rpb25zIGFzIEZlZWRiYWNrIG9iamVjdHNcbiAgICAgKiB3aXRoIHRoZSBcIkZlZWRiYWNrU3VnZ2VzdGlvbjpcIiBwcmVmaXhcbiAgICAgKi9cbiAgICBwdWJsaWMgZ2V0VGV4dEZlZWRiYWNrU3VnZ2VzdGlvbnMoZXhlcmNpc2U6IEV4ZXJjaXNlLCBzdWJtaXNzaW9uOiBUZXh0U3VibWlzc2lvbik6IE9ic2VydmFibGU8KFRleHRCbG9ja1JlZiB8IEZlZWRiYWNrKVtdPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmdldEZlZWRiYWNrU3VnZ2VzdGlvbnM8VGV4dEZlZWRiYWNrU3VnZ2VzdGlvbj4oZXhlcmNpc2UsIHN1Ym1pc3Npb24uaWQhKS5waXBlKFxuICAgICAgICAgICAgbWFwKChzdWdnZXN0aW9ucykgPT4ge1xuICAgICAgICAgICAgICAgIC8vIENvbnZlcnQgcmVmZXJlbmNlZCBmZWVkYmFjayBzdWdnZXN0aW9ucyB0byBUZXh0QmxvY2tSZWZzIGZvciBlYXNpZXIgaGFuZGxpbmcgaW4gdGhlIGNvbXBvbmVudHNcbiAgICAgICAgICAgICAgICByZXR1cm4gc3VnZ2VzdGlvbnMubWFwKChzdWdnZXN0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZlZWRiYWNrID0gbmV3IEZlZWRiYWNrKCk7XG4gICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrLmNyZWRpdHMgPSBzdWdnZXN0aW9uLmNyZWRpdHM7XG4gICAgICAgICAgICAgICAgICAgIC8vIFRleHQgZmVlZGJhY2sgc3VnZ2VzdGlvbnMgYXJlIGF1dG9tYXRpY2FsbHkgYWNjZXB0ZWQsIHNvIHdlIGNhbiBzZXQgdGhlIHRleHQgZGlyZWN0bHk6XG4gICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrLnRleHQgPSBGRUVEQkFDS19TVUdHRVNUSU9OX0FDQ0VQVEVEX0lERU5USUZJRVIgKyBzdWdnZXN0aW9uLnRpdGxlO1xuICAgICAgICAgICAgICAgICAgICBmZWVkYmFjay5kZXRhaWxUZXh0ID0gc3VnZ2VzdGlvbi5kZXNjcmlwdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgLy8gTG9hZCBncmFkaW5nIGluc3RydWN0aW9uIGZyb20gZXhlcmNpc2UsIGlmIGF2YWlsYWJsZVxuICAgICAgICAgICAgICAgICAgICBpZiAoc3VnZ2VzdGlvbi5zdHJ1Y3R1cmVkR3JhZGluZ0luc3RydWN0aW9uSWQgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmZWVkYmFjay5ncmFkaW5nSW5zdHJ1Y3Rpb24gPSB0aGlzLmZpbmRHcmFkaW5nSW5zdHJ1Y3Rpb24oZXhlcmNpc2UsIHN1Z2dlc3Rpb24uc3RydWN0dXJlZEdyYWRpbmdJbnN0cnVjdGlvbklkKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoc3VnZ2VzdGlvbi5pbmRleFN0YXJ0ID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFVucmVmZXJlbmNlZCBmZWVkYmFjaywgcmV0dXJuIEZlZWRiYWNrIG9iamVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgZmVlZGJhY2sudHlwZSA9IEZlZWRiYWNrVHlwZS5NQU5VQUxfVU5SRUZFUkVOQ0VEO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZlZWRiYWNrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC8vIFJlZmVyZW5jZWQgZmVlZGJhY2ssIGNvbnZlcnQgdG8gVGV4dEJsb2NrUmVmXG4gICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrLnR5cGUgPSBGZWVkYmFja1R5cGUuTUFOVUFMO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB0ZXh0QmxvY2sgPSBuZXcgVGV4dEJsb2NrKCk7XG4gICAgICAgICAgICAgICAgICAgIHRleHRCbG9jay5zdGFydEluZGV4ID0gc3VnZ2VzdGlvbi5pbmRleFN0YXJ0O1xuICAgICAgICAgICAgICAgICAgICB0ZXh0QmxvY2suZW5kSW5kZXggPSBzdWdnZXN0aW9uLmluZGV4RW5kO1xuICAgICAgICAgICAgICAgICAgICB0ZXh0QmxvY2suc2V0VGV4dEZyb21TdWJtaXNzaW9uKHN1Ym1pc3Npb24pO1xuICAgICAgICAgICAgICAgICAgICBmZWVkYmFjay5yZWZlcmVuY2UgPSB0ZXh0QmxvY2suaWQ7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgVGV4dEJsb2NrUmVmKHRleHRCbG9jaywgZmVlZGJhY2spO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGZlZWRiYWNrIHN1Z2dlc3Rpb25zIGZvciB0aGUgZ2l2ZW4gcHJvZ3JhbW1pbmcgc3VibWlzc2lvbiBmcm9tIEF0aGVuYVxuICAgICAqXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlXG4gICAgICogQHBhcmFtIHN1Ym1pc3Npb25JZCB0aGUgaWQgb2YgdGhlIHN1Ym1pc3Npb25cbiAgICAgKiBAcmV0dXJuIG9ic2VydmFibGUgdGhhdCBlbWl0cyB0aGUgZmVlZGJhY2sgc3VnZ2VzdGlvbnMgYXMgRmVlZGJhY2sgb2JqZWN0cyB3aXRoIHRoZSBcIkZlZWRiYWNrU3VnZ2VzdGlvbjpcIiBwcmVmaXhcbiAgICAgKi9cbiAgICBwdWJsaWMgZ2V0UHJvZ3JhbW1pbmdGZWVkYmFja1N1Z2dlc3Rpb25zKGV4ZXJjaXNlOiBFeGVyY2lzZSwgc3VibWlzc2lvbklkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEZlZWRiYWNrW10+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0RmVlZGJhY2tTdWdnZXN0aW9uczxQcm9ncmFtbWluZ0ZlZWRiYWNrU3VnZ2VzdGlvbj4oZXhlcmNpc2UsIHN1Ym1pc3Npb25JZCkucGlwZShcbiAgICAgICAgICAgIG1hcCgoc3VnZ2VzdGlvbnMpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gc3VnZ2VzdGlvbnMubWFwKChzdWdnZXN0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZlZWRiYWNrID0gbmV3IEZlZWRiYWNrKCk7XG4gICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrLmNyZWRpdHMgPSBzdWdnZXN0aW9uLmNyZWRpdHM7XG4gICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrLnRleHQgPSBGRUVEQkFDS19TVUdHRVNUSU9OX0lERU5USUZJRVIgKyBzdWdnZXN0aW9uLnRpdGxlO1xuICAgICAgICAgICAgICAgICAgICBmZWVkYmFjay5kZXRhaWxUZXh0ID0gc3VnZ2VzdGlvbi5kZXNjcmlwdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHN1Z2dlc3Rpb24uZmlsZVBhdGggIT0gdW5kZWZpbmVkICYmIChzdWdnZXN0aW9uLmxpbmVFbmQgPz8gc3VnZ2VzdGlvbi5saW5lU3RhcnQpICE9IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVmZXJlbmNlZCBmZWVkYmFja1xuICAgICAgICAgICAgICAgICAgICAgICAgZmVlZGJhY2sudHlwZSA9IEZlZWRiYWNrVHlwZS5NQU5VQUw7XG4gICAgICAgICAgICAgICAgICAgICAgICBmZWVkYmFjay5yZWZlcmVuY2UgPSBgZmlsZToke3N1Z2dlc3Rpb24uZmlsZVBhdGh9X2xpbmU6JHtzdWdnZXN0aW9uLmxpbmVFbmQgPz8gc3VnZ2VzdGlvbi5saW5lU3RhcnR9YDsgLy8gT25seSB1c2UgYSBzaW5nbGUgbGluZSBmb3Igbm93IGJlY2F1c2UgQXJ0ZW1pcyBkb2VzIG5vdCBzdXBwb3J0IGxpbmUgcmFuZ2VzXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBVbnJlZmVyZW5jZWQgZmVlZGJhY2tcbiAgICAgICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrLnR5cGUgPSBGZWVkYmFja1R5cGUuTUFOVUFMX1VOUkVGRVJFTkNFRDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrLnJlZmVyZW5jZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAvLyBMb2FkIGdyYWRpbmcgaW5zdHJ1Y3Rpb24gZnJvbSBleGVyY2lzZSwgaWYgYXZhaWxhYmxlXG4gICAgICAgICAgICAgICAgICAgIGlmIChzdWdnZXN0aW9uLnN0cnVjdHVyZWRHcmFkaW5nSW5zdHJ1Y3Rpb25JZCAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrLmdyYWRpbmdJbnN0cnVjdGlvbiA9IHRoaXMuZmluZEdyYWRpbmdJbnN0cnVjdGlvbihleGVyY2lzZSwgc3VnZ2VzdGlvbi5zdHJ1Y3R1cmVkR3JhZGluZ0luc3RydWN0aW9uSWQpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmZWVkYmFjaztcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEJhc2VFbnRpdHkgfSBmcm9tICdhcHAvc2hhcmVkL21vZGVsL2Jhc2UtZW50aXR5JztcbmltcG9ydCB7IEdyYWRpbmdJbnN0cnVjdGlvbiB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3N0cnVjdHVyZWQtZ3JhZGluZy1jcml0ZXJpb24vZ3JhZGluZy1pbnN0cnVjdGlvbi5tb2RlbCc7XG5cbmV4cG9ydCBjbGFzcyBHcmFkaW5nQ3JpdGVyaW9uIGltcGxlbWVudHMgQmFzZUVudGl0eSB7XG4gICAgcHVibGljIGlkPzogbnVtYmVyO1xuICAgIHB1YmxpYyB0aXRsZTogc3RyaW5nO1xuICAgIHB1YmxpYyBzdHJ1Y3R1cmVkR3JhZGluZ0luc3RydWN0aW9uczogR3JhZGluZ0luc3RydWN0aW9uW107XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLFdBQVcsYUFBcUI7QUFDekMsU0FBUyxhQUFhLG9CQUFvQjtBQUMxQyxTQUFTLDJCQUEyQjs7Ozs7Ozs7QUNEaEMsSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQThCLElBQUEsd0JBQUEsU0FBQSxTQUFBLHdFQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBUyx5QkFBQSxPQUFBLGdCQUFBLENBQWlCO0lBQUEsQ0FBQTtBQUNwRCxJQUFBLG9CQUFBLENBQUE7QUFDQSxJQUFBLHVCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLElBQUE7Ozs7QUFIUSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLGNBQUEsT0FBQSxXQUFBLFlBQUE7QUFDUyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFFBQUEsT0FBQSxjQUFBLE9BQUEsZUFBQSxPQUFBLFdBQUE7Ozs7OztBQUliLElBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUE4QixJQUFBLHdCQUFBLFNBQUEsU0FBQSx3RUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQVMseUJBQUEsT0FBQSxnQkFBQSxDQUFpQjtJQUFBLENBQUE7QUFDcEQsSUFBQSxvQkFBQSxDQUFBOztBQUNBLElBQUEsdUJBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsSUFBQTs7OztBQUhRLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsY0FBQSx5QkFBQSxHQUFBLEdBQUEsT0FBQSxTQUFBLEdBQUEsWUFBQTtBQUNTLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsUUFBQSxPQUFBLGNBQUEsT0FBQSxlQUFBLE9BQUEsV0FBQTs7Ozs7O0FBSWIsSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQThCLElBQUEsd0JBQUEsU0FBQSxTQUFBLHdFQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBUyx5QkFBQSxPQUFBLGdCQUFBLENBQWlCO0lBQUEsQ0FBQTtBQUNwRCxJQUFBLG9CQUFBLENBQUE7QUFDQSxJQUFBLHVCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLElBQUE7Ozs7QUFIUSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLGNBQUEsT0FBQSxXQUFBLFlBQUE7QUFDUyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFFBQUEsT0FBQSxjQUFBLE9BQUEsZUFBQSxPQUFBLFdBQUE7OztBRGZqQixTQVFhO0FBUmI7Ozs7QUFRTSxJQUFPLDZCQUFQLE1BQU8sNEJBQTBCO01BWWY7TUFYWDtNQUNBLGlCQUFpQjtNQUNqQixjQUFjO01BRXZCO01BRUEsZUFBZTtNQUNmLGNBQWM7TUFFTCxTQUFTO01BRWxCLFlBQW9CLHFCQUF3QztBQUF4QyxhQUFBLHNCQUFBO01BQTJDO01BRS9ELFdBQVE7QUFDSixhQUFLLGNBQWMsQ0FBQyxDQUFDLEtBQUssb0JBQW9CLFNBQVMsS0FBSyxVQUFVO0FBQ3RFLGFBQUssb0JBQW9CLE1BQU0sS0FBSyxZQUFZLEtBQUssV0FBVztNQUNwRTtNQUtBLGtCQUFlO0FBQ1gsYUFBSyxjQUFjLENBQUMsS0FBSztBQUN6QixhQUFLLG9CQUFvQixNQUFNLEtBQUssWUFBWSxLQUFLLFdBQVc7TUFDcEU7TUFLQSxJQUFJLGFBQVU7QUFDVixlQUFPLEtBQUssU0FBUyxLQUFLO01BQzlCOzt5QkFoQ1MsNkJBQTBCLCtCQUFBLHNCQUFBLENBQUE7TUFBQTtnRUFBMUIsNkJBQTBCLFdBQUEsQ0FBQSxDQUFBLHdCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsV0FBQSxhQUFBLGdCQUFBLGtCQUFBLGFBQUEsY0FBQSxHQUFBLG9CQUFBLEtBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEscUJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxvQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7QUNSdkMsVUFBQSx3QkFBQSxHQUFBLG1EQUFBLEdBQUEsQ0FBQSxFQUtDLEdBQUEsbURBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSxtREFBQSxHQUFBLENBQUE7QUFhRCxVQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDBCQUFBLENBQUE7QUFDSixVQUFBLG9CQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsMEJBQUE7QUFDQSxVQUFBLG9CQUFBLEdBQUEsSUFBQTs7O0FBckJBLFVBQUEsMkJBQUEsR0FBQSxJQUFBLG1CQUFBLFNBQUEsSUFBQSxjQUFBLFFBQUEsSUFBQSxnQkFBQSxRQUFBLElBQUEsRUFBQTtBQU1BLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsMkJBQUEsR0FBQSxJQUFBLG1CQUFBLFFBQUEsSUFBQSxjQUFBLFFBQUEsSUFBQSxnQkFBQSxRQUFBLElBQUEsRUFBQTtBQU1BLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsMkJBQUEsR0FBQSxJQUFBLG1CQUFBLFNBQUEsSUFBQSxjQUFBLFFBQUEsSUFBQSxnQkFBQSxPQUFBLElBQUEsRUFBQTtBQU1LLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsd0JBQUEsZUFBQSxJQUFBLFdBQUE7Ozs7O29GRFZRLDRCQUEwQixFQUFBLFdBQUEsNkJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFTnZDLFNBQXdCLGFBQUFBLFlBQVcsU0FBQUMsUUFBZSxXQUFXLG9CQUFvQjtBQUNqRixTQUFTLFlBQVksVUFBVSxvQkFBb0I7QUFFbkQsU0FBUyxPQUFPLGlCQUFpQjs7Ozs7OztBQ0o3QixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLENBQUE7QUFBdUYsSUFBQSx5QkFBQSxTQUFBLFNBQUEsd0dBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFTLDBCQUFBLE9BQUEsVUFBQSxDQUFXO0lBQUEsQ0FBQTtBQUN2RyxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQXNDLElBQUEscUJBQUEsR0FBQSxHQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7O0FBQXNFLElBQUEsMkJBQUE7QUFDdEgsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsVUFBQSxDQUFBO0FBQXVGLElBQUEseUJBQUEsU0FBQSxTQUFBLHlHQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxPQUFBLFlBQUEsQ0FBYTtJQUFBLENBQUE7QUFDekcsSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUF3QyxJQUFBLHFCQUFBLElBQUEsR0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxFQUFBOztBQUF3RSxJQUFBLDJCQUFBO0FBQzFILElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxJQUFBOzs7O0FBTnFCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLFFBQUE7QUFBbUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsNkNBQUEsQ0FBQTtBQUduQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxVQUFBO0FBQXFDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxHQUFBLCtDQUFBLENBQUE7Ozs7O0FBS3RELElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7O0FBQWtFLElBQUEsMkJBQUE7QUFDNUUsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLElBQUE7Ozs7QUFIaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsWUFBQTtBQUNILElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLHlDQUFBLENBQUE7Ozs7O0FBdUIwQixJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUE0QixJQUFBLDJCQUFBO0FBQ3RDLElBQUEscUJBQUEsR0FBQSx3Q0FBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsZ0JBQUEsVUFBQTs7Ozs7QUFFTixJQUFBLHFCQUFBLEdBQUEsd0ZBQUE7Ozs7OztBQWxCeEIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUdJLElBQUEseUJBQUEsYUFBQSxTQUFBLHVHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFhLDBCQUFBLFFBQUEsWUFBQSxDQUFhO0lBQUEsQ0FBQSxFQUFDLGFBQUEsU0FBQSxxR0FBQSxRQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGtCQUFBLFlBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQ2QsMEJBQUEsUUFBQSxLQUFBLFFBQUEsZUFBQSxDQUF5QjtJQUFBLENBQUE7QUFJdEMsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLE1BQUEsQ0FBQTs7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsTUFBQSxDQUFBOztBQUNBLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsNEZBQUEsR0FBQSxDQUFBLEVBRUMsSUFBQSw0RkFBQSxHQUFBLENBQUE7QUFHRCxJQUFBLHdCQUFBLElBQUEsaUJBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBOzs7Ozs7O0FBcEJRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsb0JBQUEsUUFBQSxlQUFBLGVBQUEsQ0FBQTtBQUpBLElBQUEsb0NBQUEsYUFBQSxRQUFBLFNBQUE7QUFHQSxJQUFBLHFDQUFBLE1BQUEsY0FBQSxtQkFBQSxpQkFBQSxzQkFBQSxFQUFBO0FBTWdCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxRQUFBLFNBQUEsZ0JBQUEsT0FBQSxHQUFBLDRCQUFBO0FBQ0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLDBCQUFBLElBQUEsSUFBQSxnQkFBQSxZQUFBLEdBQUEsNEJBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGFBQUEsMEJBQUEsSUFBQSxJQUFBLGdCQUFBLHNCQUFBLEdBQUEsNEJBQUEsRUFBb0UsY0FBQSxRQUFBLFdBQUEsZUFBQSxDQUFBO0FBRXBFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxnQkFBQSxjQUFBLGdCQUFBLGVBQUEsSUFBQSxLQUFBLEVBQUE7Ozs7O0FBbEJoQyxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsMEJBQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsK0JBQUEsR0FBQSw2RUFBQSxJQUFBLElBQUEsTUFBQSxNQUFBLHVDQUFBO0FBNEJKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxJQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLElBQUE7Ozs7QUFoQ2dDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsa0JBQUEsS0FBQSxFQUF3QixhQUFBLGFBQUEsS0FBQSxFQUFBLGVBQUEsSUFBQTtBQUM1QyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGFBQUEsNkJBQUE7OztBRGpCWixJQVVhO0FBVmI7O0FBRUE7Ozs7O0FBUU0sSUFBTyx5REFBUCxNQUFPLHdEQUFzRDtNQUMvQztNQUNQO01BQ1Q7TUFFQSxlQUFlO01BQ2YsV0FBVztNQUNYLGFBQWE7TUFFNkI7TUFDMUMsa0JBQWdELENBQUE7TUFLaEQsV0FBUTtBQUNKLGFBQUssWUFBWSxDQUFDLEtBQUs7TUFDM0I7TUFFQSxrQkFBZTtBQUNYLGFBQUssbUJBQW1CLFFBQ25CLEtBQ0csVUFBVSxDQUFDLE1BQVMsQ0FBQyxHQUNyQixNQUFNLENBQUMsQ0FBQyxFQUVYLFVBQVUsTUFBSztBQUNaLGVBQUssMkJBQTBCO1FBQ25DLENBQUM7TUFDVDtNQUVBLGNBQVc7QUFDUCxhQUFLLGdCQUFnQixRQUFRLENBQUMsWUFBVztBQUNyQyxjQUFJLENBQUMsUUFBUSxhQUFhO0FBQ3RCLG9CQUFRLGdCQUFlOztRQUUvQixDQUFDO01BQ0w7TUFFQSxZQUFTO0FBQ0wsYUFBSyxnQkFBZ0IsUUFBUSxDQUFDLFlBQVc7QUFDckMsY0FBSSxRQUFRLGFBQWE7QUFDckIsb0JBQVEsZ0JBQWU7O1FBRS9CLENBQUM7TUFDTDtNQU1BLFdBQVcsT0FBeUI7QUFDaEMsZUFBTyxlQUFlLE1BQU07TUFDaEM7TUFNQSxlQUFlLE9BQXlCO0FBQ3BDLFlBQUk7QUFDSixZQUFJLE1BQU0sWUFBWSxHQUFHO0FBQ3JCLG1CQUFTO21CQUNGLE1BQU0sVUFBVSxHQUFHO0FBQzFCLG1CQUFTO2VBQ047QUFDSCxtQkFBUzs7QUFFYixlQUFPO01BQ1g7TUFDQSxTQUFTLElBQVU7QUFDZixlQUFPLEtBQUs7TUFDaEI7TUFPQSxLQUFLLE9BQVksYUFBK0I7QUFFNUMsY0FBTSxhQUFhLFFBQVEsY0FBYyxLQUFLLFVBQVUsV0FBVyxDQUFDO01BQ3hFO01BSUEsY0FBVztBQUNQLGVBQU8sS0FBSztNQUNoQjtNQUVBLDZCQUEwQjtBQUN0QixZQUFJLEtBQUssb0JBQW9CO0FBQ3pCLGVBQUssa0JBQWtCLEtBQUssbUJBQW1CLFFBQU87O01BRTlEOzt5QkE3RlMseURBQXNEO01BQUE7aUVBQXRELHlEQUFzRCxXQUFBLENBQUEsQ0FBQSx1REFBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLDZEQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO29DQVNqRCw0QkFBMEIsQ0FBQTs7Ozs7Ozs7QUNyQjVDLFVBQUEseUJBQUEsR0FBQSwrRUFBQSxJQUFBLENBQUEsRUFTQyxHQUFBLCtFQUFBLElBQUEsQ0FBQTtBQU9ELFVBQUEsK0JBQUEsR0FBQSx1RUFBQSxJQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBOzs7QUFoQkEsVUFBQSw0QkFBQSxHQUFBLElBQUEsV0FBQSxJQUFBLEVBQUE7QUFVQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxZQUFBLElBQUEsRUFBQTtBQU1BLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxRQUFBOzs7OztxRkRKYSx3REFBc0QsRUFBQSxXQUFBLHlEQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVpuRSxTQUFTLGFBQUFDLFlBQVcsY0FBYyxTQUFBQyxRQUFPLG1CQUFtQjs7OztBQ0N4RCxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSwwQkFBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLDBCQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEseURBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxJQUFBOzs7O0FBTndDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxPQUFBLHFCQUFBLDRCQUFBO0FBRzJCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxPQUFBLFFBQUEsRUFBcUIsWUFBQSxPQUFBLFFBQUE7Ozs7O0FBSXhGLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQXVDLElBQUEscUJBQUEsQ0FBQTtBQUFvQixJQUFBLDJCQUFBOzs7O0FBQXBCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsT0FBQSxTQUFBLEtBQUE7Ozs7O0FBSTNCLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSx5Q0FBQSxDQUFBO0FBS0osSUFBQSxxQkFBQSxHQUFBLFlBQUE7Ozs7QUFKUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsT0FBQSxtQkFBQSxFQUFpQyxpQkFBQSxPQUFBLDJCQUFBLE9BQUEsMkJBQUEsT0FBQSxvQkFBQSxxQkFBQSxFQUFBLHlCQUFBLEtBQUE7Ozs7O0FBTXJDLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxLQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7OztBQURnQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGFBQUEsT0FBQSxrQkFBQSw0QkFBQTs7Ozs7QUFPNUIsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsY0FBQSxFQUFBO0FBQXNHLElBQUEscUJBQUEsR0FBQSw2QkFBQTtBQUEyQixJQUFBLDJCQUFBO0FBQ3JJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFlBQUE7Ozs7QUFKeUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsdUJBQUEsT0FBQSxPQUFBLE9BQUEsb0JBQUEseUJBQUEsT0FBQSxPQUFBLE9BQUEsb0JBQUEsc0JBQUEsZUFBQSwyQkFBQTs7Ozs7QUFPakIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLHVCQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFEeUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLElBQUEsRUFBaUIsZUFBQSxPQUFBLHlCQUFBLEVBQUEsWUFBQSxPQUFBLG1CQUFBOzs7OztBQUd0QyxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBRGdDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxPQUFBLDJCQUFBLDRCQUFBOzs7OztBQUpoQyxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsZ0VBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSxnRUFBQSxHQUFBLENBQUE7Ozs7QUFGRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxzQkFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSw0QkFBQSxJQUFBLEVBQUE7Ozs7O0FBT1IsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsMEJBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxJQUFBOzs7QURoREEsVUFnQmE7QUFoQmI7O0FBR0E7QUFDQTtBQU1BOzs7Ozs7Ozs7OztBQU1NLElBQU8sa0NBQVAsTUFBTyxpQ0FBK0I7TUFzQnBCO01BckJwQjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BRVMsdUJBQXVCO01BQ3ZCLDZCQUE2QjtNQUU3QjtNQUVBO01BRUEsZUFBZTtNQUdPO01BRS9CLFlBQW9CLGlCQUF1QztBQUF2QyxhQUFBLGtCQUFBO01BQTBDO01BRzlELElBQXVCLGNBQWMsVUFBa0I7QUFDbkQsYUFBSyxXQUFXO0FBQ2hCLGFBQUssbUJBQW1CLEtBQUssZ0JBQWdCLG9CQUFvQixTQUFTLGdCQUFnQjtBQUMxRixhQUFLLHNCQUFzQixLQUFLLGdCQUFnQixvQkFBb0IsU0FBUyxtQkFBbUI7QUFFaEcsYUFBSyxXQUFXLFNBQVMsbUJBQW1CLENBQUE7QUFFNUMsWUFBSTtBQUNKLGdCQUFRLFNBQVMsTUFBTTtVQUNuQixLQUFLLGFBQWE7QUFDZCxrQkFBTSxtQkFBbUI7QUFDekIscUNBQXlCLGlCQUFpQjtBQUMxQyxnQkFBSSxpQkFBaUIsc0JBQXNCO0FBQ3ZDLG1CQUFLLHNCQUFzQixLQUFLLE1BQU0saUJBQWlCLG9CQUFvQjs7QUFFL0UsaUJBQUssNEJBQTRCLGlCQUFpQjtBQUNsRDtVQUNKLEtBQUssYUFBYTtBQUNkLGtCQUFNLGVBQWU7QUFDckIscUNBQXlCLGFBQWE7QUFDdEM7VUFDSixLQUFLLGFBQWE7QUFDZCxrQkFBTSxxQkFBcUI7QUFDM0IscUNBQXlCLG1CQUFtQjtBQUM1QztVQUNKLEtBQUssYUFBYTtBQUNkLGlCQUFLLHNCQUFzQjs7QUFFbkMsWUFBSSx3QkFBd0I7QUFDeEIsZUFBSyw0QkFBNEIsS0FBSyxnQkFBZ0Isb0JBQW9CLHNCQUFzQjs7TUFFeEc7O3lCQXhEUyxrQ0FBK0IsZ0NBQUEsc0JBQUEsQ0FBQTtNQUFBO2lFQUEvQixrQ0FBK0IsV0FBQSxDQUFBLENBQUEsNkJBQUEsQ0FBQSxHQUFBLGdCQUFBLFNBQUEsK0NBQUEsSUFBQSxLQUFBLFVBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7Ozs7Ozs7O0FDaEI1QyxVQUFBLHlCQUFBLEdBQUEsd0RBQUEsSUFBQSxDQUFBLEVBU0MsR0FBQSwrQ0FBQSxHQUFBLEdBQUEsTUFBQSxDQUFBO0FBRUQsVUFBQSxxQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsMEJBQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQ0ksVUFBQSx5QkFBQSxHQUFBLGlEQUFBLEdBQUEsQ0FBQSxFQU1DLEdBQUEsaURBQUEsR0FBQSxDQUFBO0FBS1QsVUFBQSxxQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsMEJBQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQ0ksVUFBQSx5QkFBQSxJQUFBLGtEQUFBLElBQUEsQ0FBQSxFQU1DLElBQUEsa0RBQUEsR0FBQSxDQUFBO0FBVVQsVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEseURBQUEsR0FBQSxDQUFBOzs7O0FBNUNBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLDZCQUFBLElBQUEsRUFBQTtBQVVLLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEscUJBQUEsSUFBQSxhQUFBO0FBRUQsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLDhDQUFBLElBQUEsU0FBQSxVQUFBLElBQUEsYUFBQSxjQUFBLElBQUEsQ0FBQTtBQWNBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsS0FBQSw4Q0FBQSxJQUFBLFNBQUEsVUFBQSxJQUFBLGFBQUEsY0FBQSxLQUFBLEVBQUE7QUFrQkosVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsdUJBQUEsS0FBQSxFQUFBOzs7OztxRkQ1QmEsaUNBQStCLEVBQUEsV0FBQSxrQ0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVoQjVDLFNBQXdCLGFBQUFDLFlBQVcsU0FBQUMsY0FBYTtBQUNoRCxTQUFTLGlCQUFpQjtBQUMxQixTQUFTLGVBQWUsZ0JBQWdCLDJCQUEyQjtBQUVuRSxPQUFPLGNBQWM7Ozs7OztBQ0hqQixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFBNEIsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUFnRCxJQUFBLDJCQUFBO0FBQzVFLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFBK0MsSUFBQSx5QkFBQSxTQUFBLFNBQUEseUZBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFBLDBCQUFBLE9BQUEsWUFBQSxDQUFBLE9BQUEsU0FBQTtJQUFBLENBQUE7QUFDM0MsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxXQUFBLENBQUE7QUFBdUMsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQ3ZDLElBQUEsNkJBQUEsSUFBQSxRQUFBLENBQUE7QUFBa0YsSUFBQSxxQkFBQSxJQUFBLDBCQUFBO0FBQTJCLElBQUEsMkJBQUE7QUFDakgsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxXQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSwrQkFBQSxDQUFBO0FBT0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxJQUFBOzs7O0FBcEI2QyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxtQkFBQTtBQUloQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxVQUFBO0FBR0osSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsY0FBQTtBQUlMLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxPQUFBLFFBQUEsRUFBcUIsWUFBQSxPQUFBLFFBQUEsRUFBQSx3QkFBQSxPQUFBLG9CQUFBLEVBQUEsOEJBQUEsT0FBQSwwQkFBQTs7Ozs7O0FBVXJDLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUFpRixJQUFBLHlCQUFBLFNBQUEsU0FBQSx5RkFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQUEsT0FBQSxZQUFBLENBQUEsT0FBQSxTQUFBO0lBQUEsQ0FBQTtBQUM3RSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFBa0YsSUFBQSxxQkFBQSxHQUFBLDBCQUFBO0FBQTJCLElBQUEsMkJBQUE7QUFDN0csSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLElBQUE7Ozs7QUFKaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsYUFBQTtBQUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLGFBQUE7OztBRDFCakIsSUFXYTtBQVhiOztBQUdBOzs7QUFRTSxJQUFPLDZDQUFQLE1BQU8sNENBQTBDO01BQzFDLHVCQUF1QjtNQUN2Qiw2QkFBNkI7TUFDN0I7TUFDQSxZQUFZO01BQ1o7TUFHVCxpQkFBaUI7TUFDakIsZ0JBQWdCO01BQ2hCLHNCQUFzQjtNQUN0QixhQUFhO01BS2Isa0JBQWU7QUFDWCxpQkFBUyx3QkFBd0IsRUFDNUIsVUFBVTtVQUNQLE9BQU8sRUFBRSxNQUFNLG1CQUFtQixPQUFPLE9BQU8sUUFBUSxPQUFPLEtBQUssTUFBSztVQUN6RSxXQUFXO1lBRVAsU0FBUyxVQUFXLGFBQWE7Y0FDN0IsS0FBSyxFQUFFLE9BQU8sS0FBSyxRQUFRLEVBQUM7Y0FDNUIsS0FBSyxFQUFFLE9BQU8sS0FBTSxRQUFRLElBQUk7YUFDbkM7O1VBRUwsU0FBUztTQUNaLEVBQ0EsR0FBRyxlQUFlLFNBQVUsT0FBVTtBQUNuQyxnQkFBTSxPQUFPLFVBQVUsSUFBSSxnQkFBZ0I7UUFDL0MsQ0FBQyxFQUNBLEdBQUcsYUFBYSxTQUFVLE9BQVU7QUFDakMsZ0JBQU0sT0FBTyxVQUFVLE9BQU8sZ0JBQWdCO1FBQ2xELENBQUMsRUFDQSxHQUFHLGNBQWMsU0FBVSxPQUFVO0FBQ2xDLGdCQUFNLFNBQVMsTUFBTTtBQUNyQixpQkFBTyxNQUFNLFFBQVEsTUFBTSxLQUFLLFFBQVE7UUFDNUMsQ0FBQztNQUNUOzt5QkF2Q1MsNkNBQTBDO01BQUE7aUVBQTFDLDZDQUEwQyxXQUFBLENBQUEsQ0FBQSx5Q0FBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLHNCQUFBLHdCQUFBLDRCQUFBLDhCQUFBLFVBQUEsWUFBQSxXQUFBLGFBQUEsVUFBQSxXQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLHlCQUFBLHdCQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLGNBQUEsY0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsZ0JBQUEsNkRBQUEsR0FBQSxDQUFBLEdBQUEsb0JBQUEsYUFBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsb0JBQUEsR0FBQSxZQUFBLFlBQUEsd0JBQUEsNEJBQUEsR0FBQSxDQUFBLEdBQUEsMEJBQUEsMEJBQUEsY0FBQSxjQUFBLEdBQUEsT0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLG9EQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDWHZELFVBQUEseUJBQUEsR0FBQSxtRUFBQSxJQUFBLENBQUEsRUFzQkMsR0FBQSxtRUFBQSxJQUFBLENBQUE7OztBQXRCRCxVQUFBLDRCQUFBLEdBQUEsQ0FBQSxJQUFBLFlBQUEsSUFBQSxDQUFBOzs7OztxRkRXYSw0Q0FBMEMsRUFBQSxXQUFBLDZDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVh2RCxTQUFTLGFBQUFDLFlBQVcsU0FBQUMsY0FBYTs7OztBQVNqQixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7OztBQVZaLElBY2E7QUFkYjs7QUFDQTtBQUNBOztBQVlNLElBQU8sdUNBQVAsTUFBTyxzQ0FBb0M7TUFDcEM7TUFDQTtNQUNBOzt5QkFIQSx1Q0FBb0M7TUFBQTtpRUFBcEMsdUNBQW9DLFdBQUEsQ0FBQSxDQUFBLG1DQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLDBCQUFBLDRCQUFBLFVBQUEsV0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxZQUFBLDRCQUFBLFVBQUEsR0FBQSxDQUFBLGlCQUFBLEVBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSw4Q0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQVB6QyxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSwrQkFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLDZEQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsR0FBQSxvQ0FBQTtBQUdKLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsR0FBQSxRQUFBOzs7QUFMaUMsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxZQUFBLElBQUEsUUFBQSxFQUFxQiw0QkFBQSxJQUFBLHdCQUFBLEVBQUEsWUFBQSxJQUFBLFFBQUE7Ozs7O3FGQU83QyxzQ0FBb0MsRUFBQSxXQUFBLHVDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBQ2RqRCxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGlCQUFpQjs7QUFGMUIsSUF5Q2E7QUF6Q2I7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQTRCTSxJQUFPLCtCQUFQLE1BQU8sOEJBQTRCOzt5QkFBNUIsK0JBQTRCO01BQUE7Z0VBQTVCLDhCQUE0QixDQUFBOztRQXhCakM7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtNQUFxQixFQUFBLENBQUE7Ozs7OztBQ3hCN0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBZ0M7QUFDekMsU0FBcUIsS0FBSyxJQUFJLGlCQUFpQjs7O0FBRi9DLElBWWE7QUFaYjs7QUFHQTtBQUdBO0FBQ0E7QUFDQTs7QUFJTSxJQUFPLGdCQUFQLE1BQU8sZUFBYTtNQUlSO01BQ0Y7TUFKTCxjQUFjO01BRXJCLFlBQ2MsTUFDRixnQkFBOEI7QUFENUIsYUFBQSxPQUFBO0FBQ0YsYUFBQSxpQkFBQTtNQUNUO01BRUksWUFBUztBQUNaLGVBQU8sS0FBSyxlQUFlLGVBQWMsRUFBRyxLQUFLLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxZQUFZLGVBQWUsU0FBUyxRQUFRLENBQUMsQ0FBQyxDQUFDO01BQ2xJO01BVVEsdUJBQTBCLFVBQW9CLGNBQW9CO0FBQ3RFLFlBQUksQ0FBQyxTQUFTLDRCQUE0QjtBQUN0QyxpQkFBTyxHQUFHLENBQUEsQ0FBRTs7QUFFaEIsZUFBTyxLQUFLLFVBQVMsRUFBRyxLQUNwQixVQUFVLENBQUMsb0JBQW1CO0FBQzFCLGNBQUksQ0FBQyxpQkFBaUI7QUFDbEIsbUJBQU8sR0FBRyxDQUFBLENBQVM7O0FBRXZCLGlCQUFPLEtBQUssS0FDUCxJQUFTLEdBQUcsS0FBSyxXQUFXLElBQUksU0FBUyxJQUFJLGNBQWMsU0FBUyxFQUFFLGdCQUFnQixZQUFZLHlCQUF5QixFQUFFLFNBQVMsV0FBVSxDQUFFLEVBQ2xKLEtBQUssVUFBVSxDQUFDLFFBQTJCLEdBQUcsSUFBSSxJQUFLLENBQUMsQ0FBQztRQUNsRSxDQUFDLENBQUM7TUFFVjtNQUtRLHVCQUF1QixVQUFvQixJQUFVO0FBQ3pELG1CQUFXLGFBQWEsU0FBUyxtQkFBbUIsQ0FBQSxHQUFJO0FBQ3BELHFCQUFXLGVBQWUsVUFBVSwrQkFBK0I7QUFDL0QsZ0JBQUksWUFBWSxNQUFNLElBQUk7QUFDdEIscUJBQU87Ozs7QUFJbkIsZUFBTztNQUNYO01BV08sMkJBQTJCLFVBQW9CLFlBQTBCO0FBQzVFLGVBQU8sS0FBSyx1QkFBK0MsVUFBVSxXQUFXLEVBQUcsRUFBRSxLQUNqRixJQUFJLENBQUMsZ0JBQWU7QUFFaEIsaUJBQU8sWUFBWSxJQUFJLENBQUMsZUFBYztBQUNsQyxrQkFBTSxXQUFXLElBQUksU0FBUTtBQUM3QixxQkFBUyxVQUFVLFdBQVc7QUFFOUIscUJBQVMsT0FBTywwQ0FBMEMsV0FBVztBQUNyRSxxQkFBUyxhQUFhLFdBQVc7QUFFakMsZ0JBQUksV0FBVyxrQ0FBa0MsUUFBVztBQUN4RCx1QkFBUyxxQkFBcUIsS0FBSyx1QkFBdUIsVUFBVSxXQUFXLDhCQUE4Qjs7QUFFakgsZ0JBQUksV0FBVyxjQUFjLE1BQU07QUFFL0IsdUJBQVMsT0FBTyxhQUFhO0FBQzdCLHFCQUFPOztBQUdYLHFCQUFTLE9BQU8sYUFBYTtBQUM3QixrQkFBTSxZQUFZLElBQUksVUFBUztBQUMvQixzQkFBVSxhQUFhLFdBQVc7QUFDbEMsc0JBQVUsV0FBVyxXQUFXO0FBQ2hDLHNCQUFVLHNCQUFzQixVQUFVO0FBQzFDLHFCQUFTLFlBQVksVUFBVTtBQUMvQixtQkFBTyxJQUFJLGFBQWEsV0FBVyxRQUFRO1VBQy9DLENBQUM7UUFDTCxDQUFDLENBQUM7TUFFVjtNQVNPLGtDQUFrQyxVQUFvQixjQUFvQjtBQUM3RSxlQUFPLEtBQUssdUJBQXNELFVBQVUsWUFBWSxFQUFFLEtBQ3RGLElBQUksQ0FBQyxnQkFBZTtBQUNoQixpQkFBTyxZQUFZLElBQUksQ0FBQyxlQUFjO0FBQ2xDLGtCQUFNLFdBQVcsSUFBSSxTQUFRO0FBQzdCLHFCQUFTLFVBQVUsV0FBVztBQUM5QixxQkFBUyxPQUFPLGlDQUFpQyxXQUFXO0FBQzVELHFCQUFTLGFBQWEsV0FBVztBQUNqQyxnQkFBSSxXQUFXLFlBQVksV0FBYyxXQUFXLFdBQVcsV0FBVyxjQUFjLFFBQVc7QUFFL0YsdUJBQVMsT0FBTyxhQUFhO0FBQzdCLHVCQUFTLFlBQVksUUFBUSxXQUFXLFFBQVEsU0FBUyxXQUFXLFdBQVcsV0FBVyxTQUFTO21CQUNoRztBQUVILHVCQUFTLE9BQU8sYUFBYTtBQUM3Qix1QkFBUyxZQUFZOztBQUd6QixnQkFBSSxXQUFXLGtDQUFrQyxRQUFXO0FBQ3hELHVCQUFTLHFCQUFxQixLQUFLLHVCQUF1QixVQUFVLFdBQVcsOEJBQThCOztBQUVqSCxtQkFBTztVQUNYLENBQUM7UUFDTCxDQUFDLENBQUM7TUFFVjs7eUJBM0hTLGdCQUFhLHVCQUFBLGNBQUEsR0FBQSx1QkFBQSxjQUFBLENBQUE7TUFBQTtvRUFBYixnQkFBYSxTQUFiLGVBQWEsV0FBQSxZQURBLE9BQU0sQ0FBQTs7Ozs7O0FDUmhDLElBQWE7QUFBYjs7QUFBTSxJQUFPLG1CQUFQLE1BQXVCO01BQ2xCO01BQ0E7TUFDQTs7OzsiLCJuYW1lcyI6WyJDb21wb25lbnQiLCJJbnB1dCIsIkNvbXBvbmVudCIsIklucHV0IiwiQ29tcG9uZW50IiwiSW5wdXQiLCJDb21wb25lbnQiLCJJbnB1dCJdfQ==