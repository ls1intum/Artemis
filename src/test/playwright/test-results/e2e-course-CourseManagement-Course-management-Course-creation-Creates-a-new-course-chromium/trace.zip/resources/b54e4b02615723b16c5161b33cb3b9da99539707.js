import {
  Complaint,
  ComplaintType,
  TextareaCounterComponent,
  TextareaModule,
  init_complaint_model,
  init_textarea_counter_component,
  init_textarea_module
} from "/chunk-DBGVWL5C.js";
import {
  ComplaintService,
  init_complaint_service
} from "/chunk-G2ISVTQO.js";
import {
  ArtemisServerDateService,
  Result,
  init_exam_model,
  init_result_model,
  init_server_date_service
} from "/chunk-ORYTP7RT.js";
import {
  init_global_utils,
  onError
} from "/chunk-LW4WH7EZ.js";
import {
  AccountService,
  AlertService,
  ArtemisDatePipe,
  ArtemisSharedModule,
  ArtemisTimeAgoPipe,
  ArtemisTranslatePipe,
  TranslateDirective,
  __esm,
  getCourseFromExercise,
  init_account_service,
  init_alert_service,
  init_artemis_date_pipe,
  init_artemis_time_ago_pipe,
  init_artemis_translate_pipe,
  init_exercise_model,
  init_shared_module,
  init_student_participation_model,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/complaints/form/complaints-form.component.ts
import { Component, EventEmitter, Input, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
function ComplaintsFormComponent_Conditional_0_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "p");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275pipe(4, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate2("\n                        ", i0.\u0275\u0275pipeBind1(3, 2, ctx_r1.exercise.teamMode ? "artemisApp.moreFeedback.descriptionTeam" : "artemisApp.moreFeedback.description"), "\n                        ", i0.\u0275\u0275pipeBind1(4, 4, "artemisApp.moreFeedback.info"), "\n                    ");
  }
}
function ComplaintsFormComponent_Conditional_0_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275pipe(4, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r2 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n                            ", ctx_r2.complaintType === ctx_r2.ComplaintType.MORE_FEEDBACK ? i0.\u0275\u0275pipeBind1(3, 1, "artemisApp.moreFeedback.beDescriptiveTeam") : i0.\u0275\u0275pipeBind1(4, 3, "artemisApp.complaint.beDescriptiveTeam"), "\n                        ");
  }
}
function ComplaintsFormComponent_Conditional_0_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275pipe(4, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r3 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n                            ", ctx_r3.complaintType === ctx_r3.ComplaintType.MORE_FEEDBACK ? i0.\u0275\u0275pipeBind1(3, 1, "artemisApp.moreFeedback.beDescriptive") : i0.\u0275\u0275pipeBind1(4, 3, "artemisApp.complaint.beDescriptive"), "\n                        ");
  }
}
function ComplaintsFormComponent_Conditional_0_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "p");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n                ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n                        ", i0.\u0275\u0275pipeBind1(3, 1, "artemisApp.complaint.exclusivityDisclaimer"), "\n                    ");
  }
}
function ComplaintsFormComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "div", 0);
    i0.\u0275\u0275text(2, "\n        ");
    i0.\u0275\u0275elementStart(3, "div", 1);
    i0.\u0275\u0275text(4, "\n            ");
    i0.\u0275\u0275elementStart(5, "div", 2);
    i0.\u0275\u0275text(6, "\n                ");
    i0.\u0275\u0275elementStart(7, "h3");
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275pipe(9, "artemisTranslate");
    i0.\u0275\u0275pipe(10, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                ");
    i0.\u0275\u0275template(12, ComplaintsFormComponent_Conditional_0_Conditional_12_Template, 6, 6);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(13, "\n        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(14, "\n        ");
    i0.\u0275\u0275elementStart(15, "div", 1);
    i0.\u0275\u0275text(16, "\n            ");
    i0.\u0275\u0275elementStart(17, "div", 2);
    i0.\u0275\u0275text(18, "\n                ");
    i0.\u0275\u0275elementStart(19, "p");
    i0.\u0275\u0275text(20, "\n                    ");
    i0.\u0275\u0275template(21, ComplaintsFormComponent_Conditional_0_Conditional_21_Template, 6, 5)(22, ComplaintsFormComponent_Conditional_0_Conditional_22_Template, 6, 5);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(23, "\n                ");
    i0.\u0275\u0275template(24, ComplaintsFormComponent_Conditional_0_Conditional_24_Template, 5, 3);
    i0.\u0275\u0275elementStart(25, "div", 3);
    i0.\u0275\u0275text(26, "\n                    ");
    i0.\u0275\u0275elementStart(27, "textarea", 4);
    i0.\u0275\u0275listener("ngModelChange", function ComplaintsFormComponent_Conditional_0_Template_textarea_ngModelChange_27_listener($event) {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r5 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r5.complaintText = $event);
    });
    i0.\u0275\u0275text(28, " ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(29, "\n                    ");
    i0.\u0275\u0275elementStart(30, "jhi-textarea-counter", 5);
    i0.\u0275\u0275text(31, " ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(32, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(33, "\n                ");
    i0.\u0275\u0275elementStart(34, "div", 1);
    i0.\u0275\u0275text(35, "\n                    ");
    i0.\u0275\u0275elementStart(36, "div", 6);
    i0.\u0275\u0275text(37, "\n                        ");
    i0.\u0275\u0275elementStart(38, "button", 7);
    i0.\u0275\u0275listener("click", function ComplaintsFormComponent_Conditional_0_Template_button_click_38_listener() {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r7 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r7.createComplaint());
    });
    i0.\u0275\u0275text(39);
    i0.\u0275\u0275pipe(40, "artemisTranslate");
    i0.\u0275\u0275pipe(41, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(42, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(43, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(44, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(45, "\n        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(46, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(47, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275textInterpolate(ctx_r0.complaintType === ctx_r0.ComplaintType.COMPLAINT ? i0.\u0275\u0275pipeBind1(9, 12, "artemisApp.complaint.title") : i0.\u0275\u0275pipeBind1(10, 14, "artemisApp.moreFeedback.title"));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275conditional(12, ctx_r0.complaintType !== ctx_r0.ComplaintType.COMPLAINT ? 12 : -1);
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275conditional(21, ctx_r0.exercise.teamMode ? 21 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(22, !ctx_r0.exercise.teamMode ? 22 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(24, !ctx_r0.examId ? 24 : -1);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("maxLength", ctx_r0.maxComplaintTextLimit)("ngModel", ctx_r0.complaintText);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("maxLength", ctx_r0.maxComplaintTextLimit)("content", ctx_r0.complaintText)("visible", true);
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275property("disabled", !ctx_r0.complaintText || ctx_r0.complaintTextLength() > ctx_r0.maxComplaintTextLimit);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate1("\n                            ", ctx_r0.complaintType === ctx_r0.ComplaintType.COMPLAINT ? i0.\u0275\u0275pipeBind1(40, 16, "artemisApp.complaint.submit") : i0.\u0275\u0275pipeBind1(41, 18, "artemisApp.moreFeedback.button"), "\n                        ");
  }
}
var ComplaintsFormComponent;
var init_complaints_form_component = __esm({
  "src/main/webapp/app/complaints/form/complaints-form.component.ts"() {
    init_complaint_service();
    init_alert_service();
    init_complaint_model();
    init_exercise_model();
    init_result_model();
    init_global_utils();
    init_complaint_service();
    init_alert_service();
    init_textarea_counter_component();
    init_artemis_translate_pipe();
    ComplaintsFormComponent = class _ComplaintsFormComponent {
      complaintService;
      alertService;
      exercise;
      resultId;
      examId;
      remainingNumberOfComplaints;
      complaintType;
      isCurrentUserSubmissionAuthor = false;
      submit = new EventEmitter();
      maxComplaintsPerCourse = 1;
      maxComplaintTextLimit;
      complaintText;
      course;
      ComplaintType = ComplaintType;
      constructor(complaintService, alertService) {
        this.complaintService = complaintService;
        this.alertService = alertService;
      }
      ngOnInit() {
        this.course = getCourseFromExercise(this.exercise);
        this.maxComplaintTextLimit = this.course?.maxComplaintTextLimit ?? 0;
        if (this.exercise.course) {
          this.maxComplaintsPerCourse = this.exercise.teamMode ? this.exercise.course.maxTeamComplaints : this.exercise.course.maxComplaints;
        } else {
          this.maxComplaintTextLimit = Math.max(2e3, this.maxComplaintTextLimit);
        }
      }
      createComplaint() {
        const complaint = new Complaint();
        complaint.complaintText = this.complaintText;
        complaint.result = new Result();
        complaint.result.id = this.resultId;
        complaint.complaintType = this.complaintType;
        if (complaint.complaintText !== void 0 && this.maxComplaintTextLimit < complaint.complaintText.length) {
          this.alertService.error("artemisApp.complaint.exceededComplaintTextLimit", { maxComplaintTextLimit: this.maxComplaintTextLimit });
          return;
        }
        this.complaintService.create(complaint, this.examId).subscribe({
          next: () => {
            this.submit.emit();
          },
          error: (err) => {
            if (err?.error?.errorKey === "tooManyComplaints") {
              this.alertService.error("artemisApp.complaint.tooManyComplaints", { maxComplaintNumber: this.maxComplaintsPerCourse });
            } else {
              onError(this.alertService, err);
            }
          }
        });
      }
      complaintTextLength() {
        const textArea = document.querySelector("#complainTextArea");
        return textArea.value.length;
      }
      static \u0275fac = function ComplaintsFormComponent_Factory(t) {
        return new (t || _ComplaintsFormComponent)(i0.\u0275\u0275directiveInject(ComplaintService), i0.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _ComplaintsFormComponent, selectors: [["jhi-complaint-form"]], inputs: { exercise: "exercise", resultId: "resultId", examId: "examId", remainingNumberOfComplaints: "remainingNumberOfComplaints", complaintType: "complaintType", isCurrentUserSubmissionAuthor: "isCurrentUserSubmissionAuthor" }, outputs: { submit: "submit" }, decls: 1, vars: 1, consts: [[1, "col-12", "mt-4"], [1, "row"], [1, "col-12", "col-md-6"], [1, "d-flex", "flex-column"], ["id", "complainTextArea", "rows", "4", 1, "col-12", "px-1", 3, "maxLength", "ngModel", "ngModelChange"], [3, "maxLength", "content", "visible"], [1, "col-6"], ["id", "submit-complaint", 1, "btn", "btn-primary", 3, "disabled", "click"]], template: function ComplaintsFormComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275template(0, ComplaintsFormComponent_Conditional_0_Template, 48, 20);
        }
        if (rf & 2) {
          i0.\u0275\u0275conditional(0, ctx.isCurrentUserSubmissionAuthor ? 0 : -1);
        }
      }, dependencies: [i3.DefaultValueAccessor, i3.NgControlStatus, i3.NgModel, TextareaCounterComponent, ArtemisTranslatePipe], styles: ["\n\n.info-icon[_ngcontent-%COMP%] {\n  color: #ffc107;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb21wbGFpbnRzL2NvbXBsYWludHMuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmluZm8taWNvbiB7XG4gICAgY29sb3I6ICNmZmMxMDc7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFNBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(ComplaintsFormComponent, { className: "ComplaintsFormComponent" });
    })();
  }
});

// src/main/webapp/app/complaints/request/complaint-request.component.ts
import { Component as Component2, Input as Input2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
function ComplaintRequestComponent_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275elementStart(1, "span", 3);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275pipe(4, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                ", ctx_r0.complaint.complaintType === ctx_r0.ComplaintType.COMPLAINT ? i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.complaint.acceptedLong") : i02.\u0275\u0275pipeBind1(4, 3, "artemisApp.moreFeedback.acceptedLong"), "\n            ");
  }
}
function ComplaintRequestComponent_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275elementStart(1, "span", 4);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n        ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                ", i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.complaint.rejectedLong"), "\n            ");
  }
}
var ComplaintRequestComponent;
var init_complaint_request_component = __esm({
  "src/main/webapp/app/complaints/request/complaint-request.component.ts"() {
    init_complaint_model();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    init_artemis_time_ago_pipe();
    ComplaintRequestComponent = class _ComplaintRequestComponent {
      complaint;
      maxComplaintTextLimit;
      ComplaintType = ComplaintType;
      static \u0275fac = function ComplaintRequestComponent_Factory(t) {
        return new (t || _ComplaintRequestComponent)();
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _ComplaintRequestComponent, selectors: [["jhi-complaint-request"]], inputs: { complaint: "complaint", maxComplaintTextLimit: "maxComplaintTextLimit" }, decls: 17, vars: 17, consts: [[1, "mt-4"], [3, "ngbTooltip"], ["id", "complainTextArea", "rows", "4", 1, "col-12", "px-1", 3, "maxLength", "ngModel", "readOnly", "disabled", "ngModelChange"], [1, "badge", "bg-success"], [1, "badge", "bg-danger"]], template: function ComplaintRequestComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div");
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275elementStart(2, "p", 0);
          i02.\u0275\u0275text(3);
          i02.\u0275\u0275pipe(4, "artemisTranslate");
          i02.\u0275\u0275pipe(5, "artemisTranslate");
          i02.\u0275\u0275elementStart(6, "span", 1);
          i02.\u0275\u0275pipe(7, "artemisDate");
          i02.\u0275\u0275text(8);
          i02.\u0275\u0275pipe(9, "artemisTimeAgo");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(10, "\n        ");
          i02.\u0275\u0275template(11, ComplaintRequestComponent_Conditional_11_Template, 6, 5)(12, ComplaintRequestComponent_Conditional_12_Template, 5, 3);
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(13, "\n    ");
          i02.\u0275\u0275elementStart(14, "textarea", 2);
          i02.\u0275\u0275listener("ngModelChange", function ComplaintRequestComponent_Template_textarea_ngModelChange_14_listener($event) {
            return ctx.complaint.complaintText = $event;
          });
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(15, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(16, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275textInterpolate1("\n        ", ctx.complaint.complaintType === ctx.ComplaintType.COMPLAINT ? i02.\u0275\u0275pipeBind1(4, 9, "artemisApp.complaint.alreadySubmittedSubmissionAuthor") : i02.\u0275\u0275pipeBind1(5, 11, "artemisApp.moreFeedback.alreadySubmittedSubmissionAuthor"), "\n        ");
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275property("ngbTooltip", i02.\u0275\u0275pipeBind1(7, 13, ctx.complaint.submittedTime));
          i02.\u0275\u0275advance(2);
          i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(9, 15, ctx.complaint.submittedTime));
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275conditional(11, ctx.complaint.accepted === true ? 11 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(12, ctx.complaint.accepted === false ? 12 : -1);
          i02.\u0275\u0275advance(2);
          i02.\u0275\u0275property("maxLength", ctx.maxComplaintTextLimit)("ngModel", ctx.complaint.complaintText)("readOnly", true)("disabled", true);
        }
      }, dependencies: [i1.DefaultValueAccessor, i1.NgControlStatus, i1.NgModel, i2.NgbTooltip, ArtemisDatePipe, ArtemisTranslatePipe, ArtemisTimeAgoPipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(ComplaintRequestComponent, { className: "ComplaintRequestComponent" });
    })();
  }
});

// src/main/webapp/app/complaints/response/complaint-response.component.ts
import { Component as Component3, Input as Input3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
function ComplaintResponseComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n    ");
    i03.\u0275\u0275elementStart(1, "div");
    i03.\u0275\u0275text(2, "\n        ");
    i03.\u0275\u0275elementStart(3, "p", 0);
    i03.\u0275\u0275text(4);
    i03.\u0275\u0275pipe(5, "artemisTranslate");
    i03.\u0275\u0275pipe(6, "artemisTranslate");
    i03.\u0275\u0275elementStart(7, "span", 1);
    i03.\u0275\u0275pipe(8, "artemisDate");
    i03.\u0275\u0275text(9);
    i03.\u0275\u0275pipe(10, "artemisTimeAgo");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(11, ":\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(12, "\n        ");
    i03.\u0275\u0275elementStart(13, "textarea", 2);
    i03.\u0275\u0275listener("ngModelChange", function ComplaintResponseComponent_Conditional_0_Template_textarea_ngModelChange_13_listener($event) {
      i03.\u0275\u0275restoreView(_r2);
      const ctx_r1 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r1.complaint.complaintResponse.responseText = $event);
    });
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(14, "\n    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(15, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(4);
    i03.\u0275\u0275textInterpolate1("\n            ", ctx_r0.complaint.complaintType === ctx_r0.ComplaintType.COMPLAINT ? i03.\u0275\u0275pipeBind1(5, 7, "artemisApp.complaint.responseExists") : i03.\u0275\u0275pipeBind1(6, 9, "artemisApp.moreFeedback.responseExists"), "\n            ");
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("ngbTooltip", i03.\u0275\u0275pipeBind1(8, 11, ctx_r0.complaint.complaintResponse.submittedTime));
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(10, 13, ctx_r0.complaint.complaintResponse.submittedTime));
    i03.\u0275\u0275advance(4);
    i03.\u0275\u0275property("ngModel", ctx_r0.complaint.complaintResponse.responseText)("readOnly", true)("disabled", true)("maxLength", ctx_r0.maxComplaintResponseTextLimit);
  }
}
var ComplaintResponseComponent;
var init_complaint_response_component = __esm({
  "src/main/webapp/app/complaints/response/complaint-response.component.ts"() {
    init_complaint_model();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    init_artemis_time_ago_pipe();
    ComplaintResponseComponent = class _ComplaintResponseComponent {
      complaint;
      maxComplaintResponseTextLimit;
      ComplaintType = ComplaintType;
      static \u0275fac = function ComplaintResponseComponent_Factory(t) {
        return new (t || _ComplaintResponseComponent)();
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _ComplaintResponseComponent, selectors: [["jhi-complaint-response"]], inputs: { complaint: "complaint", maxComplaintResponseTextLimit: "maxComplaintResponseTextLimit" }, decls: 1, vars: 1, consts: [[1, "col-12", "mt-4"], [3, "ngbTooltip"], ["id", "complainResponseTextArea", "rows", "4", 1, "col-12", "px-1", 3, "ngModel", "readOnly", "disabled", "maxLength", "ngModelChange"]], template: function ComplaintResponseComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275template(0, ComplaintResponseComponent_Conditional_0_Template, 16, 15);
        }
        if (rf & 2) {
          i03.\u0275\u0275conditional(0, ctx.complaint.accepted != void 0 && ctx.complaint.complaintResponse ? 0 : -1);
        }
      }, dependencies: [i12.DefaultValueAccessor, i12.NgControlStatus, i12.NgModel, i22.NgbTooltip, ArtemisDatePipe, ArtemisTranslatePipe, ArtemisTimeAgoPipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(ComplaintResponseComponent, { className: "ComplaintResponseComponent" });
    })();
  }
});

// src/main/webapp/app/complaints/complaints-for-students/complaints-student-view.component.ts
import { Component as Component4, Input as Input4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { filter } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import { faInfoCircle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i23 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ComplaintsStudentViewComponent_Conditional_0_Conditional_3_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275element(1, "span", 0);
    i04.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    const ctx_r5 = i04.\u0275\u0275nextContext(3);
    let tmp_1_0;
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("jhiTranslate", "artemisApp.complaint." + (ctx_r5.exercise.teamMode ? "descriptionTeam" : "description"))("translateValues", i04.\u0275\u0275pureFunction1(2, _c0, (tmp_1_0 = ctx_r5.course == null ? null : ctx_r5.course.maxComplaints) !== null && tmp_1_0 !== void 0 ? tmp_1_0 : 0));
  }
}
function ComplaintsStudentViewComponent_Conditional_0_Conditional_3_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275element(1, "span", 0);
    i04.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    const ctx_r6 = i04.\u0275\u0275nextContext(3);
    let tmp_1_0;
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("jhiTranslate", "artemisApp.complaint." + (ctx_r6.exercise.teamMode ? "descriptionTeamExtended" : "descriptionExtended"))("translateValues", i04.\u0275\u0275pureFunction2(2, _c1, (tmp_1_0 = ctx_r6.course == null ? null : ctx_r6.course.maxComplaints) !== null && tmp_1_0 !== void 0 ? tmp_1_0 : 0, ctx_r6.remainingNumberOfComplaints));
  }
}
function ComplaintsStudentViewComponent_Conditional_0_Conditional_3_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275element(1, "span", 1);
    i04.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("jhiTranslate", "artemisApp.complaint.descriptionExam");
  }
}
function ComplaintsStudentViewComponent_Conditional_0_Conditional_3_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275element(1, "fa-icon", 2);
    i04.\u0275\u0275pipe(2, "artemisTranslate");
    i04.\u0275\u0275text(3, "\n                ");
  }
  if (rf & 2) {
    const ctx_r8 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275propertyInterpolate("title", i04.\u0275\u0275pipeBind1(2, 2, "artemisApp.complaint.info"));
    i04.\u0275\u0275property("icon", ctx_r8.faInfoCircle);
  }
}
function ComplaintsStudentViewComponent_Conditional_0_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n            ");
    i04.\u0275\u0275elementStart(1, "p");
    i04.\u0275\u0275text(2, "\n                ");
    i04.\u0275\u0275template(3, ComplaintsStudentViewComponent_Conditional_0_Conditional_3_Conditional_3_Template, 3, 4)(4, ComplaintsStudentViewComponent_Conditional_0_Conditional_3_Conditional_4_Template, 3, 5)(5, ComplaintsStudentViewComponent_Conditional_0_Conditional_3_Conditional_5_Template, 3, 1)(6, ComplaintsStudentViewComponent_Conditional_0_Conditional_3_Conditional_6_Template, 4, 4);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, !ctx_r1.isExamMode && ctx_r1.remainingNumberOfComplaints == void 0 ? 3 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(4, !ctx_r1.isExamMode && ctx_r1.remainingNumberOfComplaints >= 0 ? 4 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(5, ctx_r1.isExamMode ? 5 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(6, !ctx_r1.isExamMode ? 6 : -1);
  }
}
function ComplaintsStudentViewComponent_Conditional_0_Conditional_4_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275elementStart(1, "button", 4);
    i04.\u0275\u0275listener("click", function ComplaintsStudentViewComponent_Conditional_0_Conditional_4_Conditional_3_Template_button_click_1_listener() {
      i04.\u0275\u0275restoreView(_r12);
      const ctx_r11 = i04.\u0275\u0275nextContext(3);
      return i04.\u0275\u0275resetView(ctx_r11.formComplaintType = ctx_r11.ComplaintType.COMPLAINT);
    });
    i04.\u0275\u0275pipe(2, "artemisTranslate");
    i04.\u0275\u0275text(3);
    i04.\u0275\u0275pipe(4, "artemisTranslate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r9 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275classProp("not-allowed", !ctx_r9.isExamMode && ctx_r9.remainingNumberOfComplaints === 0 || !ctx_r9.timeOfComplaintValid);
    i04.\u0275\u0275propertyInterpolate("title", !ctx_r9.isExamMode && ctx_r9.remainingNumberOfComplaints === 0 || !ctx_r9.timeOfComplaintValid ? i04.\u0275\u0275pipeBind1(2, 5, "artemisApp.complaint.complaintNotAllowedTooltip") : "");
    i04.\u0275\u0275property("disabled", !ctx_r9.isExamMode && ctx_r9.remainingNumberOfComplaints === 0 || !ctx_r9.timeOfComplaintValid);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate1("\n                        ", i04.\u0275\u0275pipeBind1(4, 7, "artemisApp.complaint.moreInfo"), "\n                    ");
  }
}
function ComplaintsStudentViewComponent_Conditional_0_Conditional_4_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275elementStart(1, "button", 5);
    i04.\u0275\u0275listener("click", function ComplaintsStudentViewComponent_Conditional_0_Conditional_4_Conditional_4_Template_button_click_1_listener() {
      i04.\u0275\u0275restoreView(_r14);
      const ctx_r13 = i04.\u0275\u0275nextContext(3);
      return i04.\u0275\u0275resetView(ctx_r13.formComplaintType = ctx_r13.ComplaintType.MORE_FEEDBACK);
    });
    i04.\u0275\u0275pipe(2, "artemisTranslate");
    i04.\u0275\u0275text(3);
    i04.\u0275\u0275pipe(4, "artemisTranslate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r10 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275classProp("not-allowed", !ctx_r10.timeOfFeedbackRequestValid);
    i04.\u0275\u0275propertyInterpolate("title", !ctx_r10.timeOfFeedbackRequestValid ? i04.\u0275\u0275pipeBind1(2, 5, "artemisApp.moreFeedback.notAllowedTooltip") : "");
    i04.\u0275\u0275property("disabled", !ctx_r10.timeOfFeedbackRequestValid);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate1("\n                        ", i04.\u0275\u0275pipeBind1(4, 7, "artemisApp.moreFeedback.button"), "\n                    ");
  }
}
function ComplaintsStudentViewComponent_Conditional_0_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n            ");
    i04.\u0275\u0275elementStart(1, "div", 3);
    i04.\u0275\u0275text(2, "\n                ");
    i04.\u0275\u0275template(3, ComplaintsStudentViewComponent_Conditional_0_Conditional_4_Conditional_3_Template, 6, 9)(4, ComplaintsStudentViewComponent_Conditional_0_Conditional_4_Conditional_4_Template, 6, 9);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r2 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, ctx_r2.isExamMode || (ctx_r2.course == null ? null : ctx_r2.course.maxComplaints) && ctx_r2.course.maxComplaints > 0 ? 3 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(4, !ctx_r2.isExamMode && (ctx_r2.course == null ? null : ctx_r2.course.requestMoreFeedbackEnabled) ? 4 : -1);
  }
}
function ComplaintsStudentViewComponent_Conditional_0_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n            ");
    i04.\u0275\u0275elementStart(1, "div", 6);
    i04.\u0275\u0275text(2, "\n                ");
    i04.\u0275\u0275elementStart(3, "jhi-complaint-form", 7);
    i04.\u0275\u0275listener("submit", function ComplaintsStudentViewComponent_Conditional_0_Conditional_5_Template_jhi_complaint_form_submit_3_listener() {
      i04.\u0275\u0275restoreView(_r16);
      const ctx_r15 = i04.\u0275\u0275nextContext(2);
      return i04.\u0275\u0275resetView(ctx_r15.loadPotentialComplaint());
    });
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n            ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r3 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("exercise", ctx_r3.exercise)("resultId", ctx_r3.result.id)("examId", ctx_r3.exam == null ? null : ctx_r3.exam.id)("remainingNumberOfComplaints", ctx_r3.remainingNumberOfComplaints)("complaintType", ctx_r3.formComplaintType)("isCurrentUserSubmissionAuthor", ctx_r3.isCorrectUserToFileAction);
  }
}
function ComplaintsStudentViewComponent_Conditional_0_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n            ");
    i04.\u0275\u0275elementStart(1, "div", 6);
    i04.\u0275\u0275text(2, "\n                ");
    i04.\u0275\u0275element(3, "jhi-complaint-request", 8);
    i04.\u0275\u0275text(4, "\n                ");
    i04.\u0275\u0275element(5, "jhi-complaint-response", 9);
    i04.\u0275\u0275text(6, "\n            ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n        ");
  }
  if (rf & 2) {
    const ctx_r4 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("complaint", ctx_r4.complaint)("maxComplaintTextLimit", ctx_r4.course == null ? null : ctx_r4.course.maxComplaintTextLimit);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275property("complaint", ctx_r4.complaint)("maxComplaintResponseTextLimit", ctx_r4.course == null ? null : ctx_r4.course.maxComplaintResponseTextLimit);
  }
}
function ComplaintsStudentViewComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n    ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n        ");
    i04.\u0275\u0275template(3, ComplaintsStudentViewComponent_Conditional_0_Conditional_3_Template, 8, 4)(4, ComplaintsStudentViewComponent_Conditional_0_Conditional_4_Template, 6, 2)(5, ComplaintsStudentViewComponent_Conditional_0_Conditional_5_Template, 6, 6)(6, ComplaintsStudentViewComponent_Conditional_0_Conditional_6_Template, 8, 4);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i04.\u0275\u0275nextContext();
    let tmp_0_0;
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, ((tmp_0_0 = ctx_r0.course == null ? null : ctx_r0.course.complaintsEnabled) !== null && tmp_0_0 !== void 0 ? tmp_0_0 : false) ? 3 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(4, ctx_r0.isCorrectUserToFileAction && !ctx_r0.complaint ? 4 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(5, !ctx_r0.complaint && ctx_r0.formComplaintType ? 5 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(6, ctx_r0.complaint ? 6 : -1);
  }
}
var _c0, _c1, ComplaintsStudentViewComponent;
var init_complaints_student_view_component = __esm({
  "src/main/webapp/app/complaints/complaints-for-students/complaints-student-view.component.ts"() {
    init_exercise_model();
    init_complaint_model();
    init_complaint_service();
    init_student_participation_model();
    init_result_model();
    init_server_date_service();
    init_exam_model();
    init_account_service();
    init_complaint_service();
    init_server_date_service();
    init_account_service();
    init_translate_directive();
    init_complaints_form_component();
    init_complaint_request_component();
    init_complaint_response_component();
    init_artemis_translate_pipe();
    _c0 = (a0) => ({ maxComplaintNumber: a0 });
    _c1 = (a0, a1) => ({ maxComplaintNumber: a0, allowedComplaints: a1 });
    ComplaintsStudentViewComponent = class _ComplaintsStudentViewComponent {
      complaintService;
      activatedRoute;
      serverDateService;
      accountService;
      exercise;
      participation;
      result;
      exam;
      testRun = false;
      submission;
      complaint;
      course;
      formComplaintType;
      remainingNumberOfComplaints = 0;
      isCorrectUserToFileAction = false;
      isExamMode;
      showSection = false;
      timeOfFeedbackRequestValid = false;
      timeOfComplaintValid = false;
      ComplaintType = ComplaintType;
      faInfoCircle = faInfoCircle;
      constructor(complaintService, activatedRoute, serverDateService, accountService) {
        this.complaintService = complaintService;
        this.activatedRoute = activatedRoute;
        this.serverDateService = serverDateService;
        this.accountService = accountService;
      }
      ngOnInit() {
        this.course = getCourseFromExercise(this.exercise);
        this.isExamMode = this.exam != void 0;
        if (this.participation && this.result?.completionDate) {
          this.result.participation = this.participation;
          if (this.participation.submissions && this.participation.submissions.length > 0) {
            this.submission = this.participation.submissions.sort((a, b) => b.id - a.id)[0];
          }
          if (this.course?.complaintsEnabled) {
            this.complaintService.getNumberOfAllowedComplaintsInCourse(this.course.id, this.exercise.teamMode).subscribe((allowedComplaints) => {
              this.remainingNumberOfComplaints = allowedComplaints;
            });
          }
          this.loadPotentialComplaint();
          this.accountService.identity().then((user) => {
            if (user?.id) {
              if (this.participation?.student) {
                this.isCorrectUserToFileAction = this.participation.student.id === user.id;
              } else if (this.participation.team?.students) {
                this.isCorrectUserToFileAction = !!this.participation.team.students.find((student) => student.id === user.id);
              }
            }
          });
          this.timeOfFeedbackRequestValid = this.isTimeOfFeedbackRequestValid();
          this.timeOfComplaintValid = this.isTimeOfComplaintValid();
          this.showSection = this.getSectionVisibility();
        }
      }
      loadPotentialComplaint() {
        this.complaintService.findBySubmissionId(this.submission.id).pipe(filter((res) => !!res.body)).subscribe((res) => {
          this.complaint = res.body;
        });
      }
      getSectionVisibility() {
        if (this.isExamMode) {
          return this.isWithinExamReviewPeriod();
        } else {
          return !!(this.course?.complaintsEnabled || this.course?.requestMoreFeedbackEnabled);
        }
      }
      isTimeOfComplaintValid() {
        if (!this.isExamMode) {
          if (this.course?.maxComplaintTimeDays) {
            const dueDate = ComplaintService.getIndividualComplaintDueDate(this.exercise, this.course.maxComplaintTimeDays, this.result, this.participation);
            return !!dueDate && dayjs().isBefore(dueDate);
          }
          return false;
        }
        return this.isWithinExamReviewPeriod();
      }
      isTimeOfFeedbackRequestValid() {
        if (!this.isExamMode && this.course?.maxRequestMoreFeedbackTimeDays) {
          const dueDate = ComplaintService.getIndividualComplaintDueDate(this.exercise, this.course.maxRequestMoreFeedbackTimeDays, this.result, this.participation);
          return !!dueDate && dayjs().isBefore(dueDate);
        }
        return false;
      }
      isWithinExamReviewPeriod() {
        if (this.testRun) {
          return true;
        } else if (this.exam.examStudentReviewStart && this.exam.examStudentReviewEnd) {
          return this.serverDateService.now().isBetween(dayjs(this.exam.examStudentReviewStart), dayjs(this.exam.examStudentReviewEnd));
        }
        return false;
      }
      static \u0275fac = function ComplaintsStudentViewComponent_Factory(t) {
        return new (t || _ComplaintsStudentViewComponent)(i04.\u0275\u0275directiveInject(ComplaintService), i04.\u0275\u0275directiveInject(i23.ActivatedRoute), i04.\u0275\u0275directiveInject(ArtemisServerDateService), i04.\u0275\u0275directiveInject(AccountService));
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _ComplaintsStudentViewComponent, selectors: [["jhi-complaint-student-view"]], inputs: { exercise: "exercise", participation: "participation", result: "result", exam: "exam", testRun: "testRun" }, decls: 1, vars: 1, consts: [[3, "jhiTranslate", "translateValues"], [3, "jhiTranslate"], [1, "info-icon", 3, "icon", "title"], [1, "mt-4"], ["id", "complain", 1, "btn", "btn-primary", 3, "disabled", "title", "click"], [1, "btn", "btn-primary", "ms-1", 3, "disabled", "title", "click"], [1, "row"], [1, "flex-grow-1", 3, "exercise", "resultId", "examId", "remainingNumberOfComplaints", "complaintType", "isCurrentUserSubmissionAuthor", "submit"], [1, "col-12", "col-md-6", 3, "complaint", "maxComplaintTextLimit"], [1, "col-12", "col-md-6", 3, "complaint", "maxComplaintResponseTextLimit"]], template: function ComplaintsStudentViewComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275template(0, ComplaintsStudentViewComponent_Conditional_0_Template, 8, 4);
        }
        if (rf & 2) {
          i04.\u0275\u0275conditional(0, ctx.complaint || ctx.showSection ? 0 : -1);
        }
      }, dependencies: [i5.FaIconComponent, TranslateDirective, ComplaintsFormComponent, ComplaintRequestComponent, ComplaintResponseComponent, ArtemisTranslatePipe], styles: ["\n\n.info-icon[_ngcontent-%COMP%] {\n  color: #ffc107;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb21wbGFpbnRzL2NvbXBsYWludHMuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmluZm8taWNvbiB7XG4gICAgY29sb3I6ICNmZmMxMDc7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFNBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(ComplaintsStudentViewComponent, { className: "ComplaintsStudentViewComponent" });
    })();
  }
});

// src/main/webapp/app/complaints/complaints.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisComplaintsModule;
var init_complaints_module = __esm({
  "src/main/webapp/app/complaints/complaints.module.ts"() {
    init_complaints_form_component();
    init_complaint_service();
    init_shared_module();
    init_complaints_student_view_component();
    init_complaint_request_component();
    init_complaint_response_component();
    init_textarea_module();
    ArtemisComplaintsModule = class _ArtemisComplaintsModule {
      static \u0275fac = function ArtemisComplaintsModule_Factory(t) {
        return new (t || _ArtemisComplaintsModule)();
      };
      static \u0275mod = i05.\u0275\u0275defineNgModule({ type: _ArtemisComplaintsModule });
      static \u0275inj = i05.\u0275\u0275defineInjector({ providers: [ComplaintService], imports: [ArtemisSharedModule, TextareaModule] });
    };
  }
});

export {
  ComplaintsStudentViewComponent,
  init_complaints_student_view_component,
  ArtemisComplaintsModule,
  init_complaints_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvY29tcGxhaW50cy9mb3JtL2NvbXBsYWludHMtZm9ybS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvbXBsYWludHMvZm9ybS9jb21wbGFpbnRzLWZvcm0uY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvbXBsYWludHMvcmVxdWVzdC9jb21wbGFpbnQtcmVxdWVzdC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvbXBsYWludHMvcmVxdWVzdC9jb21wbGFpbnQtcmVxdWVzdC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvY29tcGxhaW50cy9yZXNwb25zZS9jb21wbGFpbnQtcmVzcG9uc2UuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb21wbGFpbnRzL3Jlc3BvbnNlL2NvbXBsYWludC1yZXNwb25zZS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvY29tcGxhaW50cy9jb21wbGFpbnRzLWZvci1zdHVkZW50cy9jb21wbGFpbnRzLXN0dWRlbnQtdmlldy5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvbXBsYWludHMvY29tcGxhaW50cy1mb3Itc3R1ZGVudHMvY29tcGxhaW50cy1zdHVkZW50LXZpZXcuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvbXBsYWludHMvY29tcGxhaW50cy5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb21wbGFpbnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvbXBsYWludHMvY29tcGxhaW50LnNlcnZpY2UnO1xuaW1wb3J0IHsgQWxlcnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvdXRpbC9hbGVydC5zZXJ2aWNlJztcbmltcG9ydCB7IENvbXBsYWludCwgQ29tcGxhaW50VHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb21wbGFpbnQubW9kZWwnO1xuaW1wb3J0IHsgQ291cnNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvdXJzZS5tb2RlbCc7XG5pbXBvcnQgeyBFeGVyY2lzZSwgZ2V0Q291cnNlRnJvbUV4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IFJlc3VsdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9yZXN1bHQubW9kZWwnO1xuaW1wb3J0IHsgb25FcnJvciB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC9nbG9iYWwudXRpbHMnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1jb21wbGFpbnQtZm9ybScsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2NvbXBsYWludHMtZm9ybS5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4uL2NvbXBsYWludHMuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBDb21wbGFpbnRzRm9ybUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgQElucHV0KCkgZXhlcmNpc2U6IEV4ZXJjaXNlO1xuICAgIEBJbnB1dCgpIHJlc3VsdElkOiBudW1iZXI7XG4gICAgQElucHV0KCkgZXhhbUlkPzogbnVtYmVyO1xuICAgIEBJbnB1dCgpIHJlbWFpbmluZ051bWJlck9mQ29tcGxhaW50czogbnVtYmVyO1xuICAgIEBJbnB1dCgpIGNvbXBsYWludFR5cGU6IENvbXBsYWludFR5cGU7XG4gICAgQElucHV0KCkgaXNDdXJyZW50VXNlclN1Ym1pc3Npb25BdXRob3IgPSBmYWxzZTtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQGFuZ3VsYXItZXNsaW50L25vLW91dHB1dC1uYXRpdmVcbiAgICBAT3V0cHV0KCkgc3VibWl0OiBFdmVudEVtaXR0ZXI8dm9pZD4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gICAgbWF4Q29tcGxhaW50c1BlckNvdXJzZSA9IDE7XG4gICAgbWF4Q29tcGxhaW50VGV4dExpbWl0OiBudW1iZXI7XG4gICAgY29tcGxhaW50VGV4dD86IHN0cmluZztcbiAgICBjb3Vyc2U/OiBDb3Vyc2U7XG5cbiAgICByZWFkb25seSBDb21wbGFpbnRUeXBlID0gQ29tcGxhaW50VHlwZTtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGNvbXBsYWludFNlcnZpY2U6IENvbXBsYWludFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuY291cnNlID0gZ2V0Q291cnNlRnJvbUV4ZXJjaXNlKHRoaXMuZXhlcmNpc2UpO1xuICAgICAgICB0aGlzLm1heENvbXBsYWludFRleHRMaW1pdCA9IHRoaXMuY291cnNlPy5tYXhDb21wbGFpbnRUZXh0TGltaXQgPz8gMDtcbiAgICAgICAgaWYgKHRoaXMuZXhlcmNpc2UuY291cnNlKSB7XG4gICAgICAgICAgICAvLyBvbmx5IHNldCB0aGUgY29tcGxhaW50IGxpbWl0IGZvciBjb3Vyc2UgZXhlcmNpc2VzLCB0aGVyZSBhcmUgdW5saW1pdGVkIGNvbXBsYWludHMgZm9yIGV4YW1zXG4gICAgICAgICAgICB0aGlzLm1heENvbXBsYWludHNQZXJDb3Vyc2UgPSB0aGlzLmV4ZXJjaXNlLnRlYW1Nb2RlID8gdGhpcy5leGVyY2lzZS5jb3Vyc2UubWF4VGVhbUNvbXBsYWludHMhIDogdGhpcy5leGVyY2lzZS5jb3Vyc2UubWF4Q29tcGxhaW50cyE7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBDb21wbGFpbnRzIGZvciBleGFtcyBzaG91bGQgYWx3YXlzIGFsbG93IGF0IGxlYXN0IDIwMDAgY2hhcmFjdGVycy4gSWYgdGhlIGNvdXJzZSBsaW1pdCBpcyBoaWdoZXIsIHRoZSBjdXN0b20gbGltaXQgZ2V0cyB1c2VkLlxuICAgICAgICAgICAgdGhpcy5tYXhDb21wbGFpbnRUZXh0TGltaXQgPSBNYXRoLm1heCgyMDAwLCB0aGlzLm1heENvbXBsYWludFRleHRMaW1pdCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGEgbmV3IGNvbXBsYWludCBvbiB0aGUgcHJvdmlkZWQgcmVzdWx0IHdpdGggdGhlIGVudGVyZWQgdGV4dCBhbmQgbm90aWZpZXMgdGhlIG91dHB1dCBlbWl0dGVyIG9uIHN1Y2Nlc3MuXG4gICAgICovXG4gICAgY3JlYXRlQ29tcGxhaW50KCk6IHZvaWQge1xuICAgICAgICBjb25zdCBjb21wbGFpbnQgPSBuZXcgQ29tcGxhaW50KCk7XG4gICAgICAgIGNvbXBsYWludC5jb21wbGFpbnRUZXh0ID0gdGhpcy5jb21wbGFpbnRUZXh0O1xuICAgICAgICBjb21wbGFpbnQucmVzdWx0ID0gbmV3IFJlc3VsdCgpO1xuICAgICAgICBjb21wbGFpbnQucmVzdWx0LmlkID0gdGhpcy5yZXN1bHRJZDtcbiAgICAgICAgY29tcGxhaW50LmNvbXBsYWludFR5cGUgPSB0aGlzLmNvbXBsYWludFR5cGU7XG5cbiAgICAgICAgLy8gVE9ETzogUmV0aGluayBnbG9iYWwgY2xpZW50IGVycm9yIGhhbmRsaW5nIGFuZCBhZGFwdCB0aGlzIGxpbmUgYWNjb3JkaW5nbHlcbiAgICAgICAgaWYgKGNvbXBsYWludC5jb21wbGFpbnRUZXh0ICE9PSB1bmRlZmluZWQgJiYgdGhpcy5tYXhDb21wbGFpbnRUZXh0TGltaXQgPCBjb21wbGFpbnQuY29tcGxhaW50VGV4dCEubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5lcnJvcignYXJ0ZW1pc0FwcC5jb21wbGFpbnQuZXhjZWVkZWRDb21wbGFpbnRUZXh0TGltaXQnLCB7IG1heENvbXBsYWludFRleHRMaW1pdDogdGhpcy5tYXhDb21wbGFpbnRUZXh0TGltaXQhIH0pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5jb21wbGFpbnRTZXJ2aWNlLmNyZWF0ZShjb21wbGFpbnQsIHRoaXMuZXhhbUlkKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuc3VibWl0LmVtaXQoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogKGVycjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoZXJyPy5lcnJvcj8uZXJyb3JLZXkgPT09ICd0b29NYW55Q29tcGxhaW50cycpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGVydFNlcnZpY2UuZXJyb3IoJ2FydGVtaXNBcHAuY29tcGxhaW50LnRvb01hbnlDb21wbGFpbnRzJywgeyBtYXhDb21wbGFpbnROdW1iZXI6IHRoaXMubWF4Q29tcGxhaW50c1BlckNvdXJzZSB9KTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBvbkVycm9yKHRoaXMuYWxlcnRTZXJ2aWNlLCBlcnIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENhbGN1bGF0ZXMgYW5kIHJldHVybnMgdGhlIGxlbmd0aCBvZiB0aGUgZW50ZXJlZCB0ZXh0LlxuICAgICAqL1xuICAgIGNvbXBsYWludFRleHRMZW5ndGgoKTogbnVtYmVyIHtcbiAgICAgICAgY29uc3QgdGV4dEFyZWE6IEhUTUxUZXh0QXJlYUVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjY29tcGxhaW5UZXh0QXJlYScpIGFzIEhUTUxUZXh0QXJlYUVsZW1lbnQ7XG4gICAgICAgIHJldHVybiB0ZXh0QXJlYS52YWx1ZS5sZW5ndGg7XG4gICAgfVxufVxuIiwiQGlmIChpc0N1cnJlbnRVc2VyU3VibWlzc2lvbkF1dGhvcikge1xuICAgIDxkaXYgY2xhc3M9XCJjb2wtMTIgbXQtNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLTEyIGNvbC1tZC02XCI+XG4gICAgICAgICAgICAgICAgPGgzPnt7IGNvbXBsYWludFR5cGUgPT09IENvbXBsYWludFR5cGUuQ09NUExBSU5UID8gKCdhcnRlbWlzQXBwLmNvbXBsYWludC50aXRsZScgfCBhcnRlbWlzVHJhbnNsYXRlKSA6ICgnYXJ0ZW1pc0FwcC5tb3JlRmVlZGJhY2sudGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSkgfX08L2gzPlxuICAgICAgICAgICAgICAgIEBpZiAoY29tcGxhaW50VHlwZSAhPT0gQ29tcGxhaW50VHlwZS5DT01QTEFJTlQpIHtcbiAgICAgICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7eyAoZXhlcmNpc2UudGVhbU1vZGUgPyAnYXJ0ZW1pc0FwcC5tb3JlRmVlZGJhY2suZGVzY3JpcHRpb25UZWFtJyA6ICdhcnRlbWlzQXBwLm1vcmVGZWVkYmFjay5kZXNjcmlwdGlvbicpIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAubW9yZUZlZWRiYWNrLmluZm8nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLTEyIGNvbC1tZC02XCI+XG4gICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2UudGVhbU1vZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBsYWludFR5cGUgPT09IENvbXBsYWludFR5cGUuTU9SRV9GRUVEQkFDS1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAoJ2FydGVtaXNBcHAubW9yZUZlZWRiYWNrLmJlRGVzY3JpcHRpdmVUZWFtJyB8IGFydGVtaXNUcmFuc2xhdGUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICgnYXJ0ZW1pc0FwcC5jb21wbGFpbnQuYmVEZXNjcmlwdGl2ZVRlYW0nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoIWV4ZXJjaXNlLnRlYW1Nb2RlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb21wbGFpbnRUeXBlID09PSBDb21wbGFpbnRUeXBlLk1PUkVfRkVFREJBQ0tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gKCdhcnRlbWlzQXBwLm1vcmVGZWVkYmFjay5iZURlc2NyaXB0aXZlJyB8IGFydGVtaXNUcmFuc2xhdGUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICgnYXJ0ZW1pc0FwcC5jb21wbGFpbnQuYmVEZXNjcmlwdGl2ZScgfCBhcnRlbWlzVHJhbnNsYXRlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgQGlmICghZXhhbUlkKSB7XG4gICAgICAgICAgICAgICAgICAgIDxwPlxuICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY29tcGxhaW50LmV4Y2x1c2l2aXR5RGlzY2xhaW1lcicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBmbGV4LWNvbHVtblwiPlxuICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWEgaWQ9XCJjb21wbGFpblRleHRBcmVhXCIgY2xhc3M9XCJjb2wtMTIgcHgtMVwiIHJvd3M9XCI0XCIgW21heExlbmd0aF09XCJ0aGlzLm1heENvbXBsYWludFRleHRMaW1pdFwiIFsobmdNb2RlbCldPVwiY29tcGxhaW50VGV4dFwiPiA8L3RleHRhcmVhPlxuICAgICAgICAgICAgICAgICAgICA8amhpLXRleHRhcmVhLWNvdW50ZXIgW21heExlbmd0aF09XCJ0aGlzLm1heENvbXBsYWludFRleHRMaW1pdFwiIFtjb250ZW50XT1cImNvbXBsYWludFRleHRcIiBbdmlzaWJsZV09XCJ0cnVlXCI+IDwvamhpLXRleHRhcmVhLWNvdW50ZXI+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInN1Ym1pdC1jb21wbGFpbnRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbZGlzYWJsZWRdPVwiIWNvbXBsYWludFRleHQgfHwgY29tcGxhaW50VGV4dExlbmd0aCgpID4gdGhpcy5tYXhDb21wbGFpbnRUZXh0TGltaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJjcmVhdGVDb21wbGFpbnQoKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcGxhaW50VHlwZSA9PT0gQ29tcGxhaW50VHlwZS5DT01QTEFJTlRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gKCdhcnRlbWlzQXBwLmNvbXBsYWludC5zdWJtaXQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogKCdhcnRlbWlzQXBwLm1vcmVGZWVkYmFjay5idXR0b24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29tcGxhaW50LCBDb21wbGFpbnRUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvbXBsYWludC5tb2RlbCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWNvbXBsYWludC1yZXF1ZXN0JyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vY29tcGxhaW50LXJlcXVlc3QuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBDb21wbGFpbnRSZXF1ZXN0Q29tcG9uZW50IHtcbiAgICBASW5wdXQoKSBjb21wbGFpbnQ6IENvbXBsYWludDtcbiAgICBASW5wdXQoKSBtYXhDb21wbGFpbnRUZXh0TGltaXQ6IG51bWJlcjtcbiAgICByZWFkb25seSBDb21wbGFpbnRUeXBlID0gQ29tcGxhaW50VHlwZTtcbn1cbiIsIjxkaXY+XG4gICAgPHAgY2xhc3M9XCJtdC00XCI+XG4gICAgICAgIHt7XG4gICAgICAgICAgICBjb21wbGFpbnQuY29tcGxhaW50VHlwZSA9PT0gQ29tcGxhaW50VHlwZS5DT01QTEFJTlRcbiAgICAgICAgICAgICAgICA/ICgnYXJ0ZW1pc0FwcC5jb21wbGFpbnQuYWxyZWFkeVN1Ym1pdHRlZFN1Ym1pc3Npb25BdXRob3InIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcbiAgICAgICAgICAgICAgICA6ICgnYXJ0ZW1pc0FwcC5tb3JlRmVlZGJhY2suYWxyZWFkeVN1Ym1pdHRlZFN1Ym1pc3Npb25BdXRob3InIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcbiAgICAgICAgfX1cbiAgICAgICAgPHNwYW4gW25nYlRvb2x0aXBdPVwiY29tcGxhaW50LnN1Ym1pdHRlZFRpbWUgfCBhcnRlbWlzRGF0ZVwiPnt7IGNvbXBsYWludC5zdWJtaXR0ZWRUaW1lIHwgYXJ0ZW1pc1RpbWVBZ28gfX08L3NwYW4+XG4gICAgICAgIEBpZiAoY29tcGxhaW50LmFjY2VwdGVkID09PSB0cnVlKSB7XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLXN1Y2Nlc3NcIj5cbiAgICAgICAgICAgICAgICB7e1xuICAgICAgICAgICAgICAgICAgICBjb21wbGFpbnQuY29tcGxhaW50VHlwZSA9PT0gQ29tcGxhaW50VHlwZS5DT01QTEFJTlRcbiAgICAgICAgICAgICAgICAgICAgICAgID8gKCdhcnRlbWlzQXBwLmNvbXBsYWludC5hY2NlcHRlZExvbmcnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDogKCdhcnRlbWlzQXBwLm1vcmVGZWVkYmFjay5hY2NlcHRlZExvbmcnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICB9XG4gICAgICAgIEBpZiAoY29tcGxhaW50LmFjY2VwdGVkID09PSBmYWxzZSkge1xuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSBiZy1kYW5nZXJcIj5cbiAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5jb21wbGFpbnQucmVqZWN0ZWRMb25nJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgfVxuICAgIDwvcD5cbiAgICA8dGV4dGFyZWFcbiAgICAgICAgaWQ9XCJjb21wbGFpblRleHRBcmVhXCJcbiAgICAgICAgY2xhc3M9XCJjb2wtMTIgcHgtMVwiXG4gICAgICAgIHJvd3M9XCI0XCJcbiAgICAgICAgW21heExlbmd0aF09XCJtYXhDb21wbGFpbnRUZXh0TGltaXRcIlxuICAgICAgICBbKG5nTW9kZWwpXT1cImNvbXBsYWludC5jb21wbGFpbnRUZXh0XCJcbiAgICAgICAgW3JlYWRPbmx5XT1cInRydWVcIlxuICAgICAgICBbZGlzYWJsZWRdPVwidHJ1ZVwiXG4gICAgPjwvdGV4dGFyZWE+XG48L2Rpdj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbXBsYWludCwgQ29tcGxhaW50VHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb21wbGFpbnQubW9kZWwnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1jb21wbGFpbnQtcmVzcG9uc2UnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9jb21wbGFpbnQtcmVzcG9uc2UuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBDb21wbGFpbnRSZXNwb25zZUNvbXBvbmVudCB7XG4gICAgQElucHV0KCkgY29tcGxhaW50OiBDb21wbGFpbnQ7XG4gICAgQElucHV0KCkgbWF4Q29tcGxhaW50UmVzcG9uc2VUZXh0TGltaXQ6IG51bWJlcjtcbiAgICByZWFkb25seSBDb21wbGFpbnRUeXBlID0gQ29tcGxhaW50VHlwZTtcbn1cbiIsIkBpZiAoY29tcGxhaW50LmFjY2VwdGVkICE9IHVuZGVmaW5lZCAmJiBjb21wbGFpbnQuY29tcGxhaW50UmVzcG9uc2UpIHtcbiAgICA8ZGl2PlxuICAgICAgICA8cCBjbGFzcz1cImNvbC0xMiBtdC00XCI+XG4gICAgICAgICAgICB7e1xuICAgICAgICAgICAgICAgIGNvbXBsYWludC5jb21wbGFpbnRUeXBlID09PSBDb21wbGFpbnRUeXBlLkNPTVBMQUlOVFxuICAgICAgICAgICAgICAgICAgICA/ICgnYXJ0ZW1pc0FwcC5jb21wbGFpbnQucmVzcG9uc2VFeGlzdHMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcbiAgICAgICAgICAgICAgICAgICAgOiAoJ2FydGVtaXNBcHAubW9yZUZlZWRiYWNrLnJlc3BvbnNlRXhpc3RzJyB8IGFydGVtaXNUcmFuc2xhdGUpXG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgPHNwYW4gW25nYlRvb2x0aXBdPVwiY29tcGxhaW50LmNvbXBsYWludFJlc3BvbnNlLnN1Ym1pdHRlZFRpbWUgfCBhcnRlbWlzRGF0ZVwiPnt7IGNvbXBsYWludC5jb21wbGFpbnRSZXNwb25zZS5zdWJtaXR0ZWRUaW1lIHwgYXJ0ZW1pc1RpbWVBZ28gfX08L3NwYW5cbiAgICAgICAgICAgID46XG4gICAgICAgIDwvcD5cbiAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICBpZD1cImNvbXBsYWluUmVzcG9uc2VUZXh0QXJlYVwiXG4gICAgICAgICAgICBjbGFzcz1cImNvbC0xMiBweC0xXCJcbiAgICAgICAgICAgIHJvd3M9XCI0XCJcbiAgICAgICAgICAgIFsobmdNb2RlbCldPVwiY29tcGxhaW50LmNvbXBsYWludFJlc3BvbnNlLnJlc3BvbnNlVGV4dFwiXG4gICAgICAgICAgICBbcmVhZE9ubHldPVwidHJ1ZVwiXG4gICAgICAgICAgICBbZGlzYWJsZWRdPVwidHJ1ZVwiXG4gICAgICAgICAgICBbbWF4TGVuZ3RoXT1cIm1heENvbXBsYWludFJlc3BvbnNlVGV4dExpbWl0XCJcbiAgICAgICAgPjwvdGV4dGFyZWE+XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEV4ZXJjaXNlLCBnZXRDb3Vyc2VGcm9tRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgQ29tcGxhaW50LCBDb21wbGFpbnRUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvbXBsYWludC5tb2RlbCc7XG5pbXBvcnQgeyBDb21wbGFpbnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvbXBsYWludHMvY29tcGxhaW50LnNlcnZpY2UnO1xuaW1wb3J0IHsgU3R1ZGVudFBhcnRpY2lwYXRpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvcGFydGljaXBhdGlvbi9zdHVkZW50LXBhcnRpY2lwYXRpb24ubW9kZWwnO1xuaW1wb3J0IHsgUmVzdWx0IH0gZnJvbSAnYXBwL2VudGl0aWVzL3Jlc3VsdC5tb2RlbCc7XG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBDb3Vyc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvY291cnNlLm1vZGVsJztcbmltcG9ydCB7IEFydGVtaXNTZXJ2ZXJEYXRlU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2VydmVyLWRhdGUuc2VydmljZSc7XG5pbXBvcnQgeyBFeGFtIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4YW0ubW9kZWwnO1xuaW1wb3J0IHsgQWNjb3VudFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS9hdXRoL2FjY291bnQuc2VydmljZSc7XG5pbXBvcnQgeyBTdWJtaXNzaW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3N1Ym1pc3Npb24ubW9kZWwnO1xuaW1wb3J0IHsgZmlsdGVyIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IGRheWpzIGZyb20gJ2RheWpzL2VzbSc7XG5pbXBvcnQgeyBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBmYUluZm9DaXJjbGUgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1jb21wbGFpbnQtc3R1ZGVudC12aWV3JyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vY29tcGxhaW50cy1zdHVkZW50LXZpZXcuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuLi9jb21wbGFpbnRzLnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgQ29tcGxhaW50c1N0dWRlbnRWaWV3Q29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICBASW5wdXQoKSBleGVyY2lzZTogRXhlcmNpc2U7XG4gICAgQElucHV0KCkgcGFydGljaXBhdGlvbjogU3R1ZGVudFBhcnRpY2lwYXRpb247XG4gICAgQElucHV0KCkgcmVzdWx0PzogUmVzdWx0O1xuICAgIEBJbnB1dCgpIGV4YW06IEV4YW07XG4gICAgLy8gZmxhZyB0byBpbmRpY2F0ZSBleGFtIHRlc3QgcnVuLiBEZWZhdWx0IHNldCB0byBmYWxzZS5cbiAgICBASW5wdXQoKSB0ZXN0UnVuID0gZmFsc2U7XG5cbiAgICBzdWJtaXNzaW9uOiBTdWJtaXNzaW9uO1xuICAgIGNvbXBsYWludDogQ29tcGxhaW50O1xuICAgIGNvdXJzZT86IENvdXJzZTtcbiAgICAvLyBJbmRpY2F0ZXMgd2hhdCB0eXBlIG9mIGNvbXBsYWludCBpcyBjdXJyZW50bHkgY3JlYXRlZCBieSB0aGUgc3R1ZGVudC4gVW5kZWZpbmVkIGlmIHRoZSBzdHVkZW50IGRpZG4ndCBjbGljayBvbiBhIGJ1dHRvbiB5ZXQuXG4gICAgZm9ybUNvbXBsYWludFR5cGU/OiBDb21wbGFpbnRUeXBlO1xuICAgIC8vIFRoZSBudW1iZXIgb2YgY29tcGxhaW50cyB0aGF0IHRoZSBzdHVkZW50IGlzIHN0aWxsIGFsbG93ZWQgdG8gc3VibWl0IGluIHRoZSBjb3Vyc2UuXG4gICAgcmVtYWluaW5nTnVtYmVyT2ZDb21wbGFpbnRzID0gMDtcbiAgICBpc0NvcnJlY3RVc2VyVG9GaWxlQWN0aW9uID0gZmFsc2U7XG4gICAgaXNFeGFtTW9kZTogYm9vbGVhbjtcbiAgICBzaG93U2VjdGlvbiA9IGZhbHNlO1xuICAgIHRpbWVPZkZlZWRiYWNrUmVxdWVzdFZhbGlkID0gZmFsc2U7XG4gICAgdGltZU9mQ29tcGxhaW50VmFsaWQgPSBmYWxzZTtcblxuICAgIENvbXBsYWludFR5cGUgPSBDb21wbGFpbnRUeXBlO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUluZm9DaXJjbGUgPSBmYUluZm9DaXJjbGU7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBjb21wbGFpbnRTZXJ2aWNlOiBDb21wbGFpbnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFjdGl2YXRlZFJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSxcbiAgICAgICAgcHJpdmF0ZSBzZXJ2ZXJEYXRlU2VydmljZTogQXJ0ZW1pc1NlcnZlckRhdGVTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFjY291bnRTZXJ2aWNlOiBBY2NvdW50U2VydmljZSxcbiAgICApIHt9XG5cbiAgICAvKipcbiAgICAgKiBMb2FkcyB0aGUgbnVtYmVyIG9mIGFsbG93ZWQgY29tcGxhaW50cyBhbmQgZmVlZGJhY2sgcmVxdWVzdHNcbiAgICAgKi9cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5jb3Vyc2UgPSBnZXRDb3Vyc2VGcm9tRXhlcmNpc2UodGhpcy5leGVyY2lzZSk7XG4gICAgICAgIHRoaXMuaXNFeGFtTW9kZSA9IHRoaXMuZXhhbSAhPSB1bmRlZmluZWQ7XG4gICAgICAgIGlmICh0aGlzLnBhcnRpY2lwYXRpb24gJiYgdGhpcy5yZXN1bHQ/LmNvbXBsZXRpb25EYXRlKSB7XG4gICAgICAgICAgICAvLyBNYWtlIHN1cmUgcmVzdWx0cyBhbmQgcGFydGljaXBhdGlvbiBhcmUgY29ubmVjdGVkXG4gICAgICAgICAgICB0aGlzLnJlc3VsdC5wYXJ0aWNpcGF0aW9uID0gdGhpcy5wYXJ0aWNpcGF0aW9uO1xuXG4gICAgICAgICAgICBpZiAodGhpcy5wYXJ0aWNpcGF0aW9uLnN1Ym1pc3Npb25zICYmIHRoaXMucGFydGljaXBhdGlvbi5zdWJtaXNzaW9ucy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zdWJtaXNzaW9uID0gdGhpcy5wYXJ0aWNpcGF0aW9uLnN1Ym1pc3Npb25zLnNvcnQoKGEsIGIpID0+IGIuaWQhIC0gYS5pZCEpWzBdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gZm9yIGNvdXJzZSBleGVyY2lzZXMgd2UgdHJhY2sgdGhlIG51bWJlciBvZiBhbGxvd2VkIGNvbXBsYWludHNcbiAgICAgICAgICAgIGlmICh0aGlzLmNvdXJzZT8uY29tcGxhaW50c0VuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbXBsYWludFNlcnZpY2UuZ2V0TnVtYmVyT2ZBbGxvd2VkQ29tcGxhaW50c0luQ291cnNlKHRoaXMuY291cnNlIS5pZCEsIHRoaXMuZXhlcmNpc2UudGVhbU1vZGUpLnN1YnNjcmliZSgoYWxsb3dlZENvbXBsYWludHM6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbWFpbmluZ051bWJlck9mQ29tcGxhaW50cyA9IGFsbG93ZWRDb21wbGFpbnRzO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5sb2FkUG90ZW50aWFsQ29tcGxhaW50KCk7XG4gICAgICAgICAgICB0aGlzLmFjY291bnRTZXJ2aWNlLmlkZW50aXR5KCkudGhlbigodXNlcikgPT4ge1xuICAgICAgICAgICAgICAgIGlmICh1c2VyPy5pZCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5wYXJ0aWNpcGF0aW9uPy5zdHVkZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmlzQ29ycmVjdFVzZXJUb0ZpbGVBY3Rpb24gPSB0aGlzLnBhcnRpY2lwYXRpb24uc3R1ZGVudC5pZCA9PT0gdXNlci5pZDtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLnBhcnRpY2lwYXRpb24udGVhbT8uc3R1ZGVudHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaXNDb3JyZWN0VXNlclRvRmlsZUFjdGlvbiA9ICEhdGhpcy5wYXJ0aWNpcGF0aW9uLnRlYW0uc3R1ZGVudHMuZmluZCgoc3R1ZGVudCkgPT4gc3R1ZGVudC5pZCA9PT0gdXNlci5pZCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgdGhpcy50aW1lT2ZGZWVkYmFja1JlcXVlc3RWYWxpZCA9IHRoaXMuaXNUaW1lT2ZGZWVkYmFja1JlcXVlc3RWYWxpZCgpO1xuICAgICAgICAgICAgdGhpcy50aW1lT2ZDb21wbGFpbnRWYWxpZCA9IHRoaXMuaXNUaW1lT2ZDb21wbGFpbnRWYWxpZCgpO1xuICAgICAgICAgICAgdGhpcy5zaG93U2VjdGlvbiA9IHRoaXMuZ2V0U2VjdGlvblZpc2liaWxpdHkoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNldHMgdGhlIGNvbXBsYWludCBpZiBhIGNvbXBsYWludCBhbmQgYSB2YWxpZCByZXN1bHQgZXhpc3RzXG4gICAgICovXG4gICAgbG9hZFBvdGVudGlhbENvbXBsYWludCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5jb21wbGFpbnRTZXJ2aWNlXG4gICAgICAgICAgICAuZmluZEJ5U3VibWlzc2lvbklkKHRoaXMuc3VibWlzc2lvbi5pZCEpXG4gICAgICAgICAgICAucGlwZShmaWx0ZXIoKHJlcykgPT4gISFyZXMuYm9keSkpXG4gICAgICAgICAgICAuc3Vic2NyaWJlKChyZXM6IEh0dHBSZXNwb25zZTxDb21wbGFpbnQ+KSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jb21wbGFpbnQgPSByZXMuYm9keSE7XG4gICAgICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEZXRlcm1pbmVzIHdoZXRoZXIgdG8gc2hvdyB0aGUgc2VjdGlvblxuICAgICAqL1xuICAgIHByaXZhdGUgZ2V0U2VjdGlvblZpc2liaWxpdHkoKTogYm9vbGVhbiB7XG4gICAgICAgIGlmICh0aGlzLmlzRXhhbU1vZGUpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmlzV2l0aGluRXhhbVJldmlld1BlcmlvZCgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuICEhKHRoaXMuY291cnNlPy5jb21wbGFpbnRzRW5hYmxlZCB8fCB0aGlzLmNvdXJzZT8ucmVxdWVzdE1vcmVGZWVkYmFja0VuYWJsZWQpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2tzIHdoZXRoZXIgdGhlIHN0dWRlbnQgaXMgYWxsb3dlZCB0byBzdWJtaXQgYSBjb21wbGFpbnQgb3Igbm90IGZvciBleGFtIGFuZCBjb3Vyc2UgZXhlcmNpc2VzLlxuICAgICAqL1xuICAgIHByaXZhdGUgaXNUaW1lT2ZDb21wbGFpbnRWYWxpZCgpOiBib29sZWFuIHtcbiAgICAgICAgaWYgKCF0aGlzLmlzRXhhbU1vZGUpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmNvdXJzZT8ubWF4Q29tcGxhaW50VGltZURheXMpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBkdWVEYXRlID0gQ29tcGxhaW50U2VydmljZS5nZXRJbmRpdmlkdWFsQ29tcGxhaW50RHVlRGF0ZSh0aGlzLmV4ZXJjaXNlLCB0aGlzLmNvdXJzZS5tYXhDb21wbGFpbnRUaW1lRGF5cywgdGhpcy5yZXN1bHQsIHRoaXMucGFydGljaXBhdGlvbik7XG4gICAgICAgICAgICAgICAgcmV0dXJuICEhZHVlRGF0ZSAmJiBkYXlqcygpLmlzQmVmb3JlKGR1ZURhdGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLmlzV2l0aGluRXhhbVJldmlld1BlcmlvZCgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENoZWNrcyB3aGV0aGVyIHRoZSBzdHVkZW50IGlzIGFsbG93ZWQgdG8gc3VibWl0IGEgbW9yZSBmZWVkYmFjayByZXF1ZXN0LiBUaGlzIGlzIG9ubHkgcG9zc2libGUgZm9yIGNvdXJzZSBleGVyY2lzZXMuXG4gICAgICovXG4gICAgcHJpdmF0ZSBpc1RpbWVPZkZlZWRiYWNrUmVxdWVzdFZhbGlkKCk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAoIXRoaXMuaXNFeGFtTW9kZSAmJiB0aGlzLmNvdXJzZT8ubWF4UmVxdWVzdE1vcmVGZWVkYmFja1RpbWVEYXlzKSB7XG4gICAgICAgICAgICBjb25zdCBkdWVEYXRlID0gQ29tcGxhaW50U2VydmljZS5nZXRJbmRpdmlkdWFsQ29tcGxhaW50RHVlRGF0ZSh0aGlzLmV4ZXJjaXNlLCB0aGlzLmNvdXJzZS5tYXhSZXF1ZXN0TW9yZUZlZWRiYWNrVGltZURheXMsIHRoaXMucmVzdWx0LCB0aGlzLnBhcnRpY2lwYXRpb24pO1xuICAgICAgICAgICAgcmV0dXJuICEhZHVlRGF0ZSAmJiBkYXlqcygpLmlzQmVmb3JlKGR1ZURhdGUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBBIGd1YXJkIGZ1bmN0aW9uIHVzZWQgdG8gaW5kaWNhdGUgd2hldGhlciBjb21wbGFpbnQgc3VibWlzc2lvbnMgYXJlIHZhbGlkLlxuICAgICAqIFRoZXNlIGFyZSBvbmx5IGFsbG93ZWQgaWYgdGhleSBhcmUgc3VibWl0dGVkIHdpdGhpbiB0aGUgc3R1ZGVudCByZXZpZXcgcGVyaW9kLlxuICAgICAqL1xuICAgIHByaXZhdGUgaXNXaXRoaW5FeGFtUmV2aWV3UGVyaW9kKCk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAodGhpcy50ZXN0UnVuKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmV4YW0uZXhhbVN0dWRlbnRSZXZpZXdTdGFydCAmJiB0aGlzLmV4YW0uZXhhbVN0dWRlbnRSZXZpZXdFbmQpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnNlcnZlckRhdGVTZXJ2aWNlLm5vdygpLmlzQmV0d2VlbihkYXlqcyh0aGlzLmV4YW0uZXhhbVN0dWRlbnRSZXZpZXdTdGFydCksIGRheWpzKHRoaXMuZXhhbS5leGFtU3R1ZGVudFJldmlld0VuZCkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG59XG4iLCJAaWYgKGNvbXBsYWludCB8fCBzaG93U2VjdGlvbikge1xuICAgIDxkaXY+XG4gICAgICAgIEBpZiAoY291cnNlPy5jb21wbGFpbnRzRW5hYmxlZCA/PyBmYWxzZSkge1xuICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgQGlmICghaXNFeGFtTW9kZSAmJiByZW1haW5pbmdOdW1iZXJPZkNvbXBsYWludHMgPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICBbamhpVHJhbnNsYXRlXT1cIidhcnRlbWlzQXBwLmNvbXBsYWludC4nICsgKGV4ZXJjaXNlLnRlYW1Nb2RlID8gJ2Rlc2NyaXB0aW9uVGVhbScgOiAnZGVzY3JpcHRpb24nKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbdHJhbnNsYXRlVmFsdWVzXT1cInsgbWF4Q29tcGxhaW50TnVtYmVyOiBjb3Vyc2U/Lm1heENvbXBsYWludHMgPz8gMCB9XCJcbiAgICAgICAgICAgICAgICAgICAgPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmICghaXNFeGFtTW9kZSAmJiByZW1haW5pbmdOdW1iZXJPZkNvbXBsYWludHMgPj0gMCkge1xuICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgW2poaVRyYW5zbGF0ZV09XCInYXJ0ZW1pc0FwcC5jb21wbGFpbnQuJyArIChleGVyY2lzZS50ZWFtTW9kZSA/ICdkZXNjcmlwdGlvblRlYW1FeHRlbmRlZCcgOiAnZGVzY3JpcHRpb25FeHRlbmRlZCcpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFt0cmFuc2xhdGVWYWx1ZXNdPVwieyBtYXhDb21wbGFpbnROdW1iZXI6IGNvdXJzZT8ubWF4Q29tcGxhaW50cyA/PyAwLCBhbGxvd2VkQ29tcGxhaW50czogcmVtYWluaW5nTnVtYmVyT2ZDb21wbGFpbnRzIH1cIlxuICAgICAgICAgICAgICAgICAgICA+PC9zcGFuPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKGlzRXhhbU1vZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gW2poaVRyYW5zbGF0ZV09XCInYXJ0ZW1pc0FwcC5jb21wbGFpbnQuZGVzY3JpcHRpb25FeGFtJ1wiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmICghaXNFeGFtTW9kZSkge1xuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUluZm9DaXJjbGVcIiB0aXRsZT1cInt7ICdhcnRlbWlzQXBwLmNvbXBsYWludC5pbmZvJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIiBjbGFzcz1cImluZm8taWNvblwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChpc0NvcnJlY3RVc2VyVG9GaWxlQWN0aW9uICYmICFjb21wbGFpbnQpIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC00XCI+XG4gICAgICAgICAgICAgICAgQGlmIChpc0V4YW1Nb2RlIHx8IChjb3Vyc2U/Lm1heENvbXBsYWludHMgJiYgY291cnNlIS5tYXhDb21wbGFpbnRzISA+IDApKSB7XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY29tcGxhaW5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLm5vdC1hbGxvd2VkXT1cIighaXNFeGFtTW9kZSAmJiByZW1haW5pbmdOdW1iZXJPZkNvbXBsYWludHMgPT09IDApIHx8ICF0aW1lT2ZDb21wbGFpbnRWYWxpZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwiZm9ybUNvbXBsYWludFR5cGUgPSBDb21wbGFpbnRUeXBlLkNPTVBMQUlOVFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbZGlzYWJsZWRdPVwiKCFpc0V4YW1Nb2RlICYmIHJlbWFpbmluZ051bWJlck9mQ29tcGxhaW50cyA9PT0gMCkgfHwgIXRpbWVPZkNvbXBsYWludFZhbGlkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwie3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoIWlzRXhhbU1vZGUgJiYgcmVtYWluaW5nTnVtYmVyT2ZDb21wbGFpbnRzID09PSAwKSB8fCAhdGltZU9mQ29tcGxhaW50VmFsaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAoJ2FydGVtaXNBcHAuY29tcGxhaW50LmNvbXBsYWludE5vdEFsbG93ZWRUb29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJydcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY29tcGxhaW50Lm1vcmVJbmZvJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoIWlzRXhhbU1vZGUgJiYgY291cnNlPy5yZXF1ZXN0TW9yZUZlZWRiYWNrRW5hYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBtcy0xXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5ub3QtYWxsb3dlZF09XCIhdGltZU9mRmVlZGJhY2tSZXF1ZXN0VmFsaWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cImZvcm1Db21wbGFpbnRUeXBlID0gQ29tcGxhaW50VHlwZS5NT1JFX0ZFRURCQUNLXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtkaXNhYmxlZF09XCIhdGltZU9mRmVlZGJhY2tSZXF1ZXN0VmFsaWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJ7eyAhdGltZU9mRmVlZGJhY2tSZXF1ZXN0VmFsaWQgPyAoJ2FydGVtaXNBcHAubW9yZUZlZWRiYWNrLm5vdEFsbG93ZWRUb29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGUpIDogJycgfX1cIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5tb3JlRmVlZGJhY2suYnV0dG9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgQGlmICghY29tcGxhaW50ICYmIGZvcm1Db21wbGFpbnRUeXBlKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICAgICAgPGpoaS1jb21wbGFpbnQtZm9ybVxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZsZXgtZ3Jvdy0xXCJcbiAgICAgICAgICAgICAgICAgICAgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCJcbiAgICAgICAgICAgICAgICAgICAgW3Jlc3VsdElkXT1cInJlc3VsdCEuaWQhXCJcbiAgICAgICAgICAgICAgICAgICAgW2V4YW1JZF09XCJleGFtPy5pZCFcIlxuICAgICAgICAgICAgICAgICAgICBbcmVtYWluaW5nTnVtYmVyT2ZDb21wbGFpbnRzXT1cInJlbWFpbmluZ051bWJlck9mQ29tcGxhaW50c1wiXG4gICAgICAgICAgICAgICAgICAgIFtjb21wbGFpbnRUeXBlXT1cImZvcm1Db21wbGFpbnRUeXBlXCJcbiAgICAgICAgICAgICAgICAgICAgW2lzQ3VycmVudFVzZXJTdWJtaXNzaW9uQXV0aG9yXT1cImlzQ29ycmVjdFVzZXJUb0ZpbGVBY3Rpb25cIlxuICAgICAgICAgICAgICAgICAgICAoc3VibWl0KT1cImxvYWRQb3RlbnRpYWxDb21wbGFpbnQoKVwiXG4gICAgICAgICAgICAgICAgPjwvamhpLWNvbXBsYWludC1mb3JtPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChjb21wbGFpbnQpIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgICAgICAgICA8amhpLWNvbXBsYWludC1yZXF1ZXN0IGNsYXNzPVwiY29sLTEyIGNvbC1tZC02XCIgW2NvbXBsYWludF09XCJjb21wbGFpbnRcIiBbbWF4Q29tcGxhaW50VGV4dExpbWl0XT1cImNvdXJzZT8ubWF4Q29tcGxhaW50VGV4dExpbWl0IVwiPjwvamhpLWNvbXBsYWludC1yZXF1ZXN0PlxuICAgICAgICAgICAgICAgIDxqaGktY29tcGxhaW50LXJlc3BvbnNlXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiY29sLTEyIGNvbC1tZC02XCJcbiAgICAgICAgICAgICAgICAgICAgW2NvbXBsYWludF09XCJjb21wbGFpbnRcIlxuICAgICAgICAgICAgICAgICAgICBbbWF4Q29tcGxhaW50UmVzcG9uc2VUZXh0TGltaXRdPVwiY291cnNlPy5tYXhDb21wbGFpbnRSZXNwb25zZVRleHRMaW1pdCFcIlxuICAgICAgICAgICAgICAgID48L2poaS1jb21wbGFpbnQtcmVzcG9uc2U+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgIDwvZGl2PlxufVxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgQ29tcGxhaW50c0Zvcm1Db21wb25lbnQgfSBmcm9tICdhcHAvY29tcGxhaW50cy9mb3JtL2NvbXBsYWludHMtZm9ybS5jb21wb25lbnQnO1xuaW1wb3J0IHsgQ29tcGxhaW50U2VydmljZSB9IGZyb20gJ2FwcC9jb21wbGFpbnRzL2NvbXBsYWludC5zZXJ2aWNlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgQ29tcGxhaW50c1N0dWRlbnRWaWV3Q29tcG9uZW50IH0gZnJvbSAnYXBwL2NvbXBsYWludHMvY29tcGxhaW50cy1mb3Itc3R1ZGVudHMvY29tcGxhaW50cy1zdHVkZW50LXZpZXcuY29tcG9uZW50JztcbmltcG9ydCB7IENvbXBsYWludFJlcXVlc3RDb21wb25lbnQgfSBmcm9tICdhcHAvY29tcGxhaW50cy9yZXF1ZXN0L2NvbXBsYWludC1yZXF1ZXN0LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDb21wbGFpbnRSZXNwb25zZUNvbXBvbmVudCB9IGZyb20gJ2FwcC9jb21wbGFpbnRzL3Jlc3BvbnNlL2NvbXBsYWludC1yZXNwb25zZS5jb21wb25lbnQnO1xuaW1wb3J0IHsgVGV4dGFyZWFNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3RleHRhcmVhL3RleHRhcmVhLm1vZHVsZSc7XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW0FydGVtaXNTaGFyZWRNb2R1bGUsIFRleHRhcmVhTW9kdWxlXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtDb21wbGFpbnRzRm9ybUNvbXBvbmVudCwgQ29tcGxhaW50c1N0dWRlbnRWaWV3Q29tcG9uZW50LCBDb21wbGFpbnRSZXF1ZXN0Q29tcG9uZW50LCBDb21wbGFpbnRSZXNwb25zZUNvbXBvbmVudF0sXG4gICAgZXhwb3J0czogW0NvbXBsYWludHNTdHVkZW50Vmlld0NvbXBvbmVudF0sXG4gICAgcHJvdmlkZXJzOiBbQ29tcGxhaW50U2VydmljZV0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNDb21wbGFpbnRzTW9kdWxlIHt9XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxTQUFTLFdBQVcsY0FBYyxPQUFlLGNBQWM7Ozs7O0FDSzNDLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxHQUFBO0FBQ0ksSUFBQSxvQkFBQSxDQUFBOzs7QUFFSixJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLG9CQUFBOzs7O0FBSFEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSw4QkFBQSx5QkFBQSxHQUFBLEdBQUEsT0FBQSxTQUFBLFdBQUEsNENBQUEscUNBQUEsR0FBQSw4QkFBQSx5QkFBQSxHQUFBLEdBQUEsOEJBQUEsR0FBQSx3QkFBQTs7Ozs7QUFVQSxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUNJLElBQUEsb0JBQUEsQ0FBQTs7O0FBS0osSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSx3QkFBQTs7OztBQU5RLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsa0NBQUEsT0FBQSxrQkFBQSxPQUFBLGNBQUEsZ0JBQUEseUJBQUEsR0FBQSxHQUFBLDJDQUFBLElBQUEseUJBQUEsR0FBQSxHQUFBLHdDQUFBLEdBQUEsNEJBQUE7Ozs7O0FBUUosSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLG9CQUFBLENBQUE7OztBQUtKLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7Ozs7QUFOUSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLGtDQUFBLE9BQUEsa0JBQUEsT0FBQSxjQUFBLGdCQUFBLHlCQUFBLEdBQUEsR0FBQSx1Q0FBQSxJQUFBLHlCQUFBLEdBQUEsR0FBQSxvQ0FBQSxHQUFBLDRCQUFBOzs7OztBQVNSLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxHQUFBO0FBQ0ksSUFBQSxvQkFBQSxDQUFBOztBQUNKLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsb0JBQUE7OztBQUZRLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsOEJBQUEseUJBQUEsR0FBQSxHQUFBLDRDQUFBLEdBQUEsd0JBQUE7Ozs7OztBQXBDcEIsSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxvQkFBQSxDQUFBOzs7QUFBMEosSUFBQSwwQkFBQTtBQUM5SixJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsK0RBQUEsR0FBQSxDQUFBO0FBTUosSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsR0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSwrREFBQSxHQUFBLENBQUEsRUFRQyxJQUFBLCtEQUFBLEdBQUEsQ0FBQTtBQVVMLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsK0RBQUEsR0FBQSxDQUFBO0FBS0EsSUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxZQUFBLENBQUE7QUFBc0csSUFBQSx3QkFBQSxpQkFBQSxTQUFBLGtGQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFBLE9BQUEsZ0JBQUEsTUFBQTtJQUFBLENBQUE7QUFBNkIsSUFBQSxvQkFBQSxJQUFBLEdBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ25JLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSx3QkFBQSxDQUFBO0FBQTJHLElBQUEsb0JBQUEsSUFBQSxHQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUMvRyxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsVUFBQSxDQUFBO0FBSUksSUFBQSx3QkFBQSxTQUFBLFNBQUEsMEVBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFTLHlCQUFBLE9BQUEsZ0JBQUEsQ0FBaUI7SUFBQSxDQUFBO0FBRTFCLElBQUEsb0JBQUEsRUFBQTs7O0FBS0osSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxJQUFBOzs7O0FBM0RvQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsa0JBQUEsT0FBQSxjQUFBLFlBQUEseUJBQUEsR0FBQSxJQUFBLDRCQUFBLElBQUEseUJBQUEsSUFBQSxJQUFBLCtCQUFBLENBQUE7QUFDSixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLElBQUEsT0FBQSxrQkFBQSxPQUFBLGNBQUEsWUFBQSxLQUFBLEVBQUE7QUFXSSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLElBQUEsT0FBQSxTQUFBLFdBQUEsS0FBQSxFQUFBO0FBU0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxJQUFBLENBQUEsT0FBQSxTQUFBLFdBQUEsS0FBQSxFQUFBO0FBVUosSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxJQUFBLENBQUEsT0FBQSxTQUFBLEtBQUEsRUFBQTtBQU1pRSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGFBQUEsT0FBQSxxQkFBQSxFQUF3QyxXQUFBLE9BQUEsYUFBQTtBQUMvRSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGFBQUEsT0FBQSxxQkFBQSxFQUF3QyxXQUFBLE9BQUEsYUFBQSxFQUFBLFdBQUEsSUFBQTtBQU90RCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFlBQUEsQ0FBQSxPQUFBLGlCQUFBLE9BQUEsb0JBQUEsSUFBQSxPQUFBLHFCQUFBO0FBR0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxrQ0FBQSxPQUFBLGtCQUFBLE9BQUEsY0FBQSxZQUFBLHlCQUFBLElBQUEsSUFBQSw2QkFBQSxJQUFBLHlCQUFBLElBQUEsSUFBQSxnQ0FBQSxHQUFBLDRCQUFBOzs7QURuRDVCLElBY2E7QUFkYjs7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7Ozs7O0FBT00sSUFBTywwQkFBUCxNQUFPLHlCQUF1QjtNQWlCcEI7TUFDQTtNQWpCSDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0EsZ0NBQWdDO01BRS9CLFNBQTZCLElBQUksYUFBWTtNQUN2RCx5QkFBeUI7TUFDekI7TUFDQTtNQUNBO01BRVMsZ0JBQWdCO01BRXpCLFlBQ1ksa0JBQ0EsY0FBMEI7QUFEMUIsYUFBQSxtQkFBQTtBQUNBLGFBQUEsZUFBQTtNQUNUO01BRUgsV0FBUTtBQUNKLGFBQUssU0FBUyxzQkFBc0IsS0FBSyxRQUFRO0FBQ2pELGFBQUssd0JBQXdCLEtBQUssUUFBUSx5QkFBeUI7QUFDbkUsWUFBSSxLQUFLLFNBQVMsUUFBUTtBQUV0QixlQUFLLHlCQUF5QixLQUFLLFNBQVMsV0FBVyxLQUFLLFNBQVMsT0FBTyxvQkFBcUIsS0FBSyxTQUFTLE9BQU87ZUFDbkg7QUFFSCxlQUFLLHdCQUF3QixLQUFLLElBQUksS0FBTSxLQUFLLHFCQUFxQjs7TUFFOUU7TUFLQSxrQkFBZTtBQUNYLGNBQU0sWUFBWSxJQUFJLFVBQVM7QUFDL0Isa0JBQVUsZ0JBQWdCLEtBQUs7QUFDL0Isa0JBQVUsU0FBUyxJQUFJLE9BQU07QUFDN0Isa0JBQVUsT0FBTyxLQUFLLEtBQUs7QUFDM0Isa0JBQVUsZ0JBQWdCLEtBQUs7QUFHL0IsWUFBSSxVQUFVLGtCQUFrQixVQUFhLEtBQUssd0JBQXdCLFVBQVUsY0FBZSxRQUFRO0FBQ3ZHLGVBQUssYUFBYSxNQUFNLG1EQUFtRCxFQUFFLHVCQUF1QixLQUFLLHNCQUFzQixDQUFFO0FBQ2pJOztBQUdKLGFBQUssaUJBQWlCLE9BQU8sV0FBVyxLQUFLLE1BQU0sRUFBRSxVQUFVO1VBQzNELE1BQU0sTUFBSztBQUNQLGlCQUFLLE9BQU8sS0FBSTtVQUNwQjtVQUNBLE9BQU8sQ0FBQyxRQUEwQjtBQUM5QixnQkFBSSxLQUFLLE9BQU8sYUFBYSxxQkFBcUI7QUFDOUMsbUJBQUssYUFBYSxNQUFNLDBDQUEwQyxFQUFFLG9CQUFvQixLQUFLLHVCQUFzQixDQUFFO21CQUNsSDtBQUNILHNCQUFRLEtBQUssY0FBYyxHQUFHOztVQUV0QztTQUNIO01BQ0w7TUFLQSxzQkFBbUI7QUFDZixjQUFNLFdBQWdDLFNBQVMsY0FBYyxtQkFBbUI7QUFDaEYsZUFBTyxTQUFTLE1BQU07TUFDMUI7O3lCQXJFUywwQkFBdUIsK0JBQUEsZ0JBQUEsR0FBQSwrQkFBQSxZQUFBLENBQUE7TUFBQTtnRUFBdkIsMEJBQXVCLFdBQUEsQ0FBQSxDQUFBLG9CQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLFVBQUEsWUFBQSxRQUFBLFVBQUEsNkJBQUEsK0JBQUEsZUFBQSxpQkFBQSwrQkFBQSxnQ0FBQSxHQUFBLFNBQUEsRUFBQSxRQUFBLFNBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsVUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsYUFBQSxHQUFBLENBQUEsTUFBQSxvQkFBQSxRQUFBLEtBQUEsR0FBQSxVQUFBLFFBQUEsR0FBQSxhQUFBLFdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLFdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxNQUFBLG9CQUFBLEdBQUEsT0FBQSxlQUFBLEdBQUEsWUFBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsaUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNmcEMsVUFBQSx3QkFBQSxHQUFBLGdEQUFBLElBQUEsRUFBQTs7O0FBQUEsVUFBQSwyQkFBQSxHQUFBLElBQUEsZ0NBQUEsSUFBQSxFQUFBOzs7OztvRkRlYSx5QkFBdUIsRUFBQSxXQUFBLDBCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRWZwQyxTQUFTLGFBQUFBLFlBQVcsU0FBQUMsY0FBYTs7Ozs7O0FDU3JCLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7OztBQUtKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7OztBQU5RLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsc0JBQUEsT0FBQSxVQUFBLGtCQUFBLE9BQUEsY0FBQSxZQUFBLDBCQUFBLEdBQUEsR0FBQSxtQ0FBQSxJQUFBLDBCQUFBLEdBQUEsR0FBQSxzQ0FBQSxHQUFBLGdCQUFBOzs7OztBQVFKLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxZQUFBOzs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLHNCQUFBLDBCQUFBLEdBQUEsR0FBQSxtQ0FBQSxHQUFBLGdCQUFBOzs7QURuQmhCLElBT2E7QUFQYjs7QUFDQTs7OztBQU1NLElBQU8sNEJBQVAsTUFBTywyQkFBeUI7TUFDekI7TUFDQTtNQUNBLGdCQUFnQjs7eUJBSGhCLDRCQUF5QjtNQUFBO2lFQUF6Qiw0QkFBeUIsV0FBQSxDQUFBLENBQUEsdUJBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxXQUFBLGFBQUEsdUJBQUEsd0JBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxNQUFBLG9CQUFBLFFBQUEsS0FBQSxHQUFBLFVBQUEsUUFBQSxHQUFBLGFBQUEsV0FBQSxZQUFBLFlBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxXQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsbUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNQdEMsVUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxLQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLENBQUE7OztBQUtBLFVBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7O0FBQTJELFVBQUEscUJBQUEsQ0FBQTs7QUFBOEMsVUFBQSwyQkFBQTtBQUN6RyxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxtREFBQSxHQUFBLENBQUEsRUFRQyxJQUFBLG1EQUFBLEdBQUEsQ0FBQTtBQU1MLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxZQUFBLENBQUE7QUFLSSxVQUFBLHlCQUFBLGlCQUFBLFNBQUEsc0VBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsVUFBQSxnQkFBQTtVQUFBLENBQUE7QUFHSCxVQUFBLDJCQUFBO0FBQ0wsVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQS9CUSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLGNBQUEsSUFBQSxVQUFBLGtCQUFBLElBQUEsY0FBQSxZQUFBLDBCQUFBLEdBQUEsR0FBQSx1REFBQSxJQUFBLDBCQUFBLEdBQUEsSUFBQSwwREFBQSxHQUFBLFlBQUE7QUFLTSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLGNBQUEsMEJBQUEsR0FBQSxJQUFBLElBQUEsVUFBQSxhQUFBLENBQUE7QUFBcUQsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSwwQkFBQSxHQUFBLElBQUEsSUFBQSxVQUFBLGFBQUEsQ0FBQTtBQUMzRCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxVQUFBLGFBQUEsT0FBQSxLQUFBLEVBQUE7QUFTQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxVQUFBLGFBQUEsUUFBQSxLQUFBLEVBQUE7QUFVQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLGFBQUEsSUFBQSxxQkFBQSxFQUFtQyxXQUFBLElBQUEsVUFBQSxhQUFBLEVBQUEsWUFBQSxJQUFBLEVBQUEsWUFBQSxJQUFBOzs7OztxRkRwQjlCLDJCQUF5QixFQUFBLFdBQUEsNEJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFUHRDLFNBQVMsYUFBQUMsWUFBVyxTQUFBQyxjQUFhOzs7Ozs7O0FDQzdCLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7OztBQUtBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7O0FBQTZFLElBQUEscUJBQUEsQ0FBQTs7QUFBZ0UsSUFBQSwyQkFBQTtBQUM1SSxJQUFBLHFCQUFBLElBQUEsYUFBQTtBQUNMLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxZQUFBLENBQUE7QUFJSSxJQUFBLHlCQUFBLGlCQUFBLFNBQUEscUZBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQWEsMEJBQUEsT0FBQSxVQUFBLGtCQUFBLGVBQUEsTUFBQTtJQUNuQixDQUFBO0FBR0csSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxJQUFBOzs7O0FBbEJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsa0JBQUEsT0FBQSxVQUFBLGtCQUFBLE9BQUEsY0FBQSxZQUFBLDBCQUFBLEdBQUEsR0FBQSxxQ0FBQSxJQUFBLDBCQUFBLEdBQUEsR0FBQSx3Q0FBQSxHQUFBLGdCQUFBO0FBS00sSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLDBCQUFBLEdBQUEsSUFBQSxPQUFBLFVBQUEsa0JBQUEsYUFBQSxDQUFBO0FBQXVFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLE9BQUEsVUFBQSxrQkFBQSxhQUFBLENBQUE7QUFPN0UsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLE9BQUEsVUFBQSxrQkFBQSxZQUFBLEVBQXNELFlBQUEsSUFBQSxFQUFBLFlBQUEsSUFBQSxFQUFBLGFBQUEsT0FBQSw2QkFBQTs7O0FEZmxFLElBT2E7QUFQYjs7QUFDQTs7OztBQU1NLElBQU8sNkJBQVAsTUFBTyw0QkFBMEI7TUFDMUI7TUFDQTtNQUNBLGdCQUFnQjs7eUJBSGhCLDZCQUEwQjtNQUFBO2lFQUExQiw2QkFBMEIsV0FBQSxDQUFBLENBQUEsd0JBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxXQUFBLGFBQUEsK0JBQUEsZ0NBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsVUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLE1BQUEsNEJBQUEsUUFBQSxLQUFBLEdBQUEsVUFBQSxRQUFBLEdBQUEsV0FBQSxZQUFBLFlBQUEsYUFBQSxlQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsb0NBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNQdkMsVUFBQSx5QkFBQSxHQUFBLG1EQUFBLElBQUEsRUFBQTs7O0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsVUFBQSxZQUFBLFVBQUEsSUFBQSxVQUFBLG9CQUFBLElBQUEsRUFBQTs7Ozs7cUZET2EsNEJBQTBCLEVBQUEsV0FBQSw2QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVQdkMsU0FBUyxhQUFBQyxZQUFXLFNBQUFDLGNBQXFCO0FBTXpDLFNBQVMsc0JBQXNCO0FBTS9CLFNBQVMsY0FBYztBQUN2QixPQUFPLFdBQVc7QUFFbEIsU0FBUyxvQkFBb0I7Ozs7OztBQ1ZULElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLENBQUE7QUFJSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7O0FBSFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxnQkFBQSwyQkFBQSxPQUFBLFNBQUEsV0FBQSxvQkFBQSxjQUFBLEVBQWtHLG1CQUFBLDhCQUFBLEdBQUEsTUFBQSxVQUFBLE9BQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxPQUFBLG1CQUFBLFFBQUEsWUFBQSxTQUFBLFVBQUEsQ0FBQSxDQUFBOzs7OztBQUt0RyxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxDQUFBO0FBSUosSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7OztBQUhRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsZ0JBQUEsMkJBQUEsT0FBQSxTQUFBLFdBQUEsNEJBQUEsc0JBQUEsRUFBa0gsbUJBQUEsOEJBQUEsR0FBQSxNQUFBLFVBQUEsT0FBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLE9BQUEsbUJBQUEsUUFBQSxZQUFBLFNBQUEsVUFBQSxHQUFBLE9BQUEsMkJBQUEsQ0FBQTs7Ozs7QUFLdEgsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7O0FBRFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxnQkFBQSxzQ0FBQTs7Ozs7QUFHTixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBOztBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQURtQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLG9DQUFBLFNBQUEsMEJBQUEsR0FBQSxHQUFBLDJCQUFBLENBQUE7QUFBdEIsSUFBQSx5QkFBQSxRQUFBLE9BQUEsWUFBQTs7Ozs7QUFqQmpCLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxHQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLG1GQUFBLEdBQUEsQ0FBQSxFQUtDLEdBQUEsbUZBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSxtRkFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLG1GQUFBLEdBQUEsQ0FBQTtBQWFMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7OztBQW5CUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxPQUFBLGNBQUEsT0FBQSwrQkFBQSxTQUFBLElBQUEsRUFBQTtBQU1BLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxDQUFBLE9BQUEsY0FBQSxPQUFBLCtCQUFBLElBQUEsSUFBQSxFQUFBO0FBTUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsYUFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxPQUFBLGFBQUEsSUFBQSxFQUFBOzs7Ozs7QUFRSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxDQUFBO0FBSUksSUFBQSx5QkFBQSxTQUFBLFNBQUEsNEdBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQUEsMEJBQUEsUUFBQSxvQkFBQSxRQUFBLGNBQUEsU0FBQTtJQUFBLENBQUE7O0FBUUEsSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUFYUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGVBQUEsQ0FBQSxPQUFBLGNBQUEsT0FBQSxnQ0FBQSxLQUFBLENBQUEsT0FBQSxvQkFBQTtBQUdBLElBQUEsb0NBQUEsU0FBQSxDQUFBLE9BQUEsY0FBQSxPQUFBLGdDQUFBLEtBQUEsQ0FBQSxPQUFBLHVCQUFBLDBCQUFBLEdBQUEsR0FBQSxpREFBQSxJQUFBLEVBQUE7QUFEQSxJQUFBLHlCQUFBLFlBQUEsQ0FBQSxPQUFBLGNBQUEsT0FBQSxnQ0FBQSxLQUFBLENBQUEsT0FBQSxvQkFBQTtBQU9BLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsOEJBQUEsMEJBQUEsR0FBQSxHQUFBLCtCQUFBLEdBQUEsd0JBQUE7Ozs7OztBQUlKLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLENBQUE7QUFHSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSw0R0FBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBQSwwQkFBQSxRQUFBLG9CQUFBLFFBQUEsY0FBQSxhQUFBO0lBQUEsQ0FBQTs7QUFJQSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQVBRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsZUFBQSxDQUFBLFFBQUEsMEJBQUE7QUFHQSxJQUFBLG9DQUFBLFNBQUEsQ0FBQSxRQUFBLDZCQUFBLDBCQUFBLEdBQUEsR0FBQSwyQ0FBQSxJQUFBLEVBQUE7QUFEQSxJQUFBLHlCQUFBLFlBQUEsQ0FBQSxRQUFBLDBCQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSw4QkFBQSwwQkFBQSxHQUFBLEdBQUEsZ0NBQUEsR0FBQSx3QkFBQTs7Ozs7QUF6QlosSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxtRkFBQSxHQUFBLENBQUEsRUFlQyxHQUFBLG1GQUFBLEdBQUEsQ0FBQTtBQVlMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7OztBQTVCUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxlQUFBLE9BQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxPQUFBLGtCQUFBLE9BQUEsT0FBQSxnQkFBQSxJQUFBLElBQUEsRUFBQTtBQWdCQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxPQUFBLGVBQUEsT0FBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLE9BQUEsOEJBQUEsSUFBQSxFQUFBOzs7Ozs7QUFjSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLHNCQUFBLENBQUE7QUFRSSxJQUFBLHlCQUFBLFVBQUEsU0FBQSwyR0FBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBVSwwQkFBQSxRQUFBLHVCQUFBLENBQXdCO0lBQUEsQ0FBQTtBQUNyQyxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxZQUFBOzs7O0FBVFksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLE9BQUEsUUFBQSxFQUFxQixZQUFBLE9BQUEsT0FBQSxFQUFBLEVBQUEsVUFBQSxPQUFBLFFBQUEsT0FBQSxPQUFBLE9BQUEsS0FBQSxFQUFBLEVBQUEsK0JBQUEsT0FBQSwyQkFBQSxFQUFBLGlCQUFBLE9BQUEsaUJBQUEsRUFBQSxpQ0FBQSxPQUFBLHlCQUFBOzs7OztBQVc3QixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLHlCQUFBLENBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsMEJBQUEsQ0FBQTtBQUtKLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7OztBQVB1RCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGFBQUEsT0FBQSxTQUFBLEVBQXVCLHlCQUFBLE9BQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxPQUFBLHFCQUFBO0FBR2xFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxPQUFBLFNBQUEsRUFBdUIsaUNBQUEsT0FBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLE9BQUEsNkJBQUE7Ozs7O0FBekV2QyxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEscUVBQUEsR0FBQSxDQUFBLEVBcUJDLEdBQUEscUVBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSxxRUFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLHFFQUFBLEdBQUEsQ0FBQTtBQXdETCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLElBQUE7Ozs7O0FBOUVRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsS0FBQSxVQUFBLE9BQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxPQUFBLHVCQUFBLFFBQUEsWUFBQSxTQUFBLFVBQUEsU0FBQSxJQUFBLEVBQUE7QUFzQkEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsNkJBQUEsQ0FBQSxPQUFBLFlBQUEsSUFBQSxFQUFBO0FBK0JBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxDQUFBLE9BQUEsYUFBQSxPQUFBLG9CQUFBLElBQUEsRUFBQTtBQWNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLFlBQUEsSUFBQSxFQUFBOzs7QURyRVIsY0FzQmE7QUF0QmI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUFZTSxJQUFPLGlDQUFQLE1BQU8sZ0NBQThCO01BMkIzQjtNQUNBO01BQ0E7TUFDQTtNQTdCSDtNQUNBO01BQ0E7TUFDQTtNQUVBLFVBQVU7TUFFbkI7TUFDQTtNQUNBO01BRUE7TUFFQSw4QkFBOEI7TUFDOUIsNEJBQTRCO01BQzVCO01BQ0EsY0FBYztNQUNkLDZCQUE2QjtNQUM3Qix1QkFBdUI7TUFFdkIsZ0JBQWdCO01BR2hCLGVBQWU7TUFFZixZQUNZLGtCQUNBLGdCQUNBLG1CQUNBLGdCQUE4QjtBQUg5QixhQUFBLG1CQUFBO0FBQ0EsYUFBQSxpQkFBQTtBQUNBLGFBQUEsb0JBQUE7QUFDQSxhQUFBLGlCQUFBO01BQ1Q7TUFLSCxXQUFRO0FBQ0osYUFBSyxTQUFTLHNCQUFzQixLQUFLLFFBQVE7QUFDakQsYUFBSyxhQUFhLEtBQUssUUFBUTtBQUMvQixZQUFJLEtBQUssaUJBQWlCLEtBQUssUUFBUSxnQkFBZ0I7QUFFbkQsZUFBSyxPQUFPLGdCQUFnQixLQUFLO0FBRWpDLGNBQUksS0FBSyxjQUFjLGVBQWUsS0FBSyxjQUFjLFlBQVksU0FBUyxHQUFHO0FBQzdFLGlCQUFLLGFBQWEsS0FBSyxjQUFjLFlBQVksS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLEtBQU0sRUFBRSxFQUFHLEVBQUUsQ0FBQzs7QUFHcEYsY0FBSSxLQUFLLFFBQVEsbUJBQW1CO0FBQ2hDLGlCQUFLLGlCQUFpQixxQ0FBcUMsS0FBSyxPQUFRLElBQUssS0FBSyxTQUFTLFFBQVEsRUFBRSxVQUFVLENBQUMsc0JBQTZCO0FBQ3pJLG1CQUFLLDhCQUE4QjtZQUN2QyxDQUFDOztBQUVMLGVBQUssdUJBQXNCO0FBQzNCLGVBQUssZUFBZSxTQUFRLEVBQUcsS0FBSyxDQUFDLFNBQVE7QUFDekMsZ0JBQUksTUFBTSxJQUFJO0FBQ1Ysa0JBQUksS0FBSyxlQUFlLFNBQVM7QUFDN0IscUJBQUssNEJBQTRCLEtBQUssY0FBYyxRQUFRLE9BQU8sS0FBSzt5QkFDakUsS0FBSyxjQUFjLE1BQU0sVUFBVTtBQUMxQyxxQkFBSyw0QkFBNEIsQ0FBQyxDQUFDLEtBQUssY0FBYyxLQUFLLFNBQVMsS0FBSyxDQUFDLFlBQVksUUFBUSxPQUFPLEtBQUssRUFBRTs7O1VBR3hILENBQUM7QUFFRCxlQUFLLDZCQUE2QixLQUFLLDZCQUE0QjtBQUNuRSxlQUFLLHVCQUF1QixLQUFLLHVCQUFzQjtBQUN2RCxlQUFLLGNBQWMsS0FBSyxxQkFBb0I7O01BRXBEO01BS0EseUJBQXNCO0FBQ2xCLGFBQUssaUJBQ0EsbUJBQW1CLEtBQUssV0FBVyxFQUFHLEVBQ3RDLEtBQUssT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLEVBQ2hDLFVBQVUsQ0FBQyxRQUFnQztBQUN4QyxlQUFLLFlBQVksSUFBSTtRQUN6QixDQUFDO01BQ1Q7TUFLUSx1QkFBb0I7QUFDeEIsWUFBSSxLQUFLLFlBQVk7QUFDakIsaUJBQU8sS0FBSyx5QkFBd0I7ZUFDakM7QUFDSCxpQkFBTyxDQUFDLEVBQUUsS0FBSyxRQUFRLHFCQUFxQixLQUFLLFFBQVE7O01BRWpFO01BS1EseUJBQXNCO0FBQzFCLFlBQUksQ0FBQyxLQUFLLFlBQVk7QUFDbEIsY0FBSSxLQUFLLFFBQVEsc0JBQXNCO0FBQ25DLGtCQUFNLFVBQVUsaUJBQWlCLDhCQUE4QixLQUFLLFVBQVUsS0FBSyxPQUFPLHNCQUFzQixLQUFLLFFBQVEsS0FBSyxhQUFhO0FBQy9JLG1CQUFPLENBQUMsQ0FBQyxXQUFXLE1BQUssRUFBRyxTQUFTLE9BQU87O0FBRWhELGlCQUFPOztBQUVYLGVBQU8sS0FBSyx5QkFBd0I7TUFDeEM7TUFLUSwrQkFBNEI7QUFDaEMsWUFBSSxDQUFDLEtBQUssY0FBYyxLQUFLLFFBQVEsZ0NBQWdDO0FBQ2pFLGdCQUFNLFVBQVUsaUJBQWlCLDhCQUE4QixLQUFLLFVBQVUsS0FBSyxPQUFPLGdDQUFnQyxLQUFLLFFBQVEsS0FBSyxhQUFhO0FBQ3pKLGlCQUFPLENBQUMsQ0FBQyxXQUFXLE1BQUssRUFBRyxTQUFTLE9BQU87O0FBRWhELGVBQU87TUFDWDtNQU1RLDJCQUF3QjtBQUM1QixZQUFJLEtBQUssU0FBUztBQUNkLGlCQUFPO21CQUNBLEtBQUssS0FBSywwQkFBMEIsS0FBSyxLQUFLLHNCQUFzQjtBQUMzRSxpQkFBTyxLQUFLLGtCQUFrQixJQUFHLEVBQUcsVUFBVSxNQUFNLEtBQUssS0FBSyxzQkFBc0IsR0FBRyxNQUFNLEtBQUssS0FBSyxvQkFBb0IsQ0FBQzs7QUFFaEksZUFBTztNQUNYOzt5QkFoSVMsaUNBQThCLGdDQUFBLGdCQUFBLEdBQUEsZ0NBQUEsa0JBQUEsR0FBQSxnQ0FBQSx3QkFBQSxHQUFBLGdDQUFBLGNBQUEsQ0FBQTtNQUFBO2lFQUE5QixpQ0FBOEIsV0FBQSxDQUFBLENBQUEsNEJBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsZUFBQSxpQkFBQSxRQUFBLFVBQUEsTUFBQSxRQUFBLFNBQUEsVUFBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxnQkFBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxRQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsTUFBQSxZQUFBLEdBQUEsT0FBQSxlQUFBLEdBQUEsWUFBQSxTQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxlQUFBLFFBQUEsR0FBQSxZQUFBLFNBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsR0FBQSxZQUFBLFlBQUEsVUFBQSwrQkFBQSxpQkFBQSxpQ0FBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsWUFBQSxHQUFBLGFBQUEsdUJBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxZQUFBLEdBQUEsYUFBQSwrQkFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHdDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDdEIzQyxVQUFBLHlCQUFBLEdBQUEsdURBQUEsR0FBQSxDQUFBOzs7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxhQUFBLElBQUEsY0FBQSxJQUFBLEVBQUE7Ozs7O3FGRHNCYSxnQ0FBOEIsRUFBQSxXQUFBLGlDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRXRCM0MsU0FBUyxnQkFBZ0I7O0FBQXpCLElBZ0JhO0FBaEJiOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUU0sSUFBTywwQkFBUCxNQUFPLHlCQUF1Qjs7eUJBQXZCLDBCQUF1QjtNQUFBO2dFQUF2Qix5QkFBdUIsQ0FBQTtxRUFGckIsQ0FBQyxnQkFBZ0IsR0FBQyxTQUFBLENBSG5CLHFCQUFxQixjQUFjLEVBQUEsQ0FBQTs7OzsiLCJuYW1lcyI6WyJDb21wb25lbnQiLCJJbnB1dCIsIkNvbXBvbmVudCIsIklucHV0IiwiQ29tcG9uZW50IiwiSW5wdXQiXX0=