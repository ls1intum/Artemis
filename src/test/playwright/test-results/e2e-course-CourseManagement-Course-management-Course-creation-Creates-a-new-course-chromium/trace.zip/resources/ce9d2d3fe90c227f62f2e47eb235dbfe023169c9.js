import {
  init_doughnut_chart_component,
  init_statistics_graph_component,
  init_statistics_score_distribution_graph_component
} from "/chunk-STMAMLZE.js";
import {
  ChartCategoryFilter,
  ChartExerciseTypeFilter,
  init_chart_category_filter,
  init_chart_exercise_type_filter
} from "/chunk-AM4XLYEX.js";
import {
  ArtemisNavigationUtilService,
  init_navigation_utils
} from "/chunk-QOKTVWNZ.js";
import {
  ThemeService,
  init_theme_service
} from "/chunk-PVIIR7SL.js";
import {
  GraphColors,
  SpanType,
  axisTickFormattingWithPercentageSign,
  init_statistics_graph_utils,
  init_statistics_model
} from "/chunk-ORYTP7RT.js";
import {
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  ExerciseType,
  __esm,
  init_artemis_translate_pipe,
  init_exercise_model,
  init_shared_module
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/statistics-graph/statistics-average-score-graph.component.ts
import { Component, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faArrowLeft, faArrowRight, faFilter } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { ScaleType } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i6 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i7 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i8 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
function StatisticsAverageScoreGraphComponent_ng_template_22_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "b");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(3, " ");
    i0.\u0275\u0275element(4, "br");
    i0.\u0275\u0275text(5, "\n                    ");
    i0.\u0275\u0275elementStart(6, "span");
    i0.\u0275\u0275text(7);
    i0.\u0275\u0275pipe(8, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, " ");
    i0.\u0275\u0275element(10, "br");
    i0.\u0275\u0275text(11, "\n                    ");
    i0.\u0275\u0275elementStart(12, "b");
    i0.\u0275\u0275text(13);
    i0.\u0275\u0275pipe(14, "artemisTranslate");
    i0.\u0275\u0275pipe(15, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(16, "\n                ");
  }
  if (rf & 2) {
    const model_r7 = ctx.model;
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(model_r7.name);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate2("", i0.\u0275\u0275pipeBind1(8, 5, "artemisApp.courseStatistics.exerciseAverage"), ": ", model_r7.value, "%");
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275textInterpolate2("", i0.\u0275\u0275pipeBind1(14, 7, "artemisApp.courseStatistics.exerciseType"), ":\n                        ", i0.\u0275\u0275pipeBind1(15, 9, "artemisApp.courseStatistics." + ctx_r1.convertTypeForTooltip(model_r7.name, model_r7.value)), "");
  }
}
function StatisticsAverageScoreGraphComponent_ng_template_29_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275element(1, "div", 13);
    i0.\u0275\u0275text(2, "\n        ");
  }
}
function StatisticsAverageScoreGraphComponent_Conditional_34_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275elementStart(1, "li");
    i0.\u0275\u0275text(2, "\n                                ");
    i0.\u0275\u0275elementStart(3, "b", 19);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275pipe(5, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n                            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                        ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(5, 1, "artemisApp.exercise-scores-chart.includeType"));
  }
}
function StatisticsAverageScoreGraphComponent_Conditional_34_For_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275elementStart(1, "li");
    i0.\u0275\u0275text(2, "\n                                ");
    i0.\u0275\u0275elementStart(3, "label");
    i0.\u0275\u0275text(4, "\n                                    ");
    i0.\u0275\u0275elementStart(5, "input", 21);
    i0.\u0275\u0275listener("change", function StatisticsAverageScoreGraphComponent_Conditional_34_For_16_Template_input_change_5_listener() {
      const restoredCtx = i0.\u0275\u0275restoreView(_r18);
      const type_r12 = restoredCtx.$implicit;
      const ctx_r17 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r17.toggleType(type_r12));
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n                                    ");
    i0.\u0275\u0275elementStart(7, "span", 19);
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275pipe(9, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12, "\n                        ");
  }
  if (rf & 2) {
    const type_r12 = ctx.$implicit;
    const ctx_r9 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275property("checked", ctx_r9.exerciseTypeFilter.getCurrentFilterState(ctx_r9.convertToMapKey(type_r12)));
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(9, 2, "artemisApp.exercise-scores-chart." + type_r12.toLowerCase() + "Plural"));
  }
}
function StatisticsAverageScoreGraphComponent_Conditional_34_Conditional_36_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275elementStart(1, "li");
    i0.\u0275\u0275text(2, "\n                                ");
    i0.\u0275\u0275elementStart(3, "label");
    i0.\u0275\u0275text(4, "\n                                    ");
    i0.\u0275\u0275elementStart(5, "input", 21);
    i0.\u0275\u0275listener("change", function StatisticsAverageScoreGraphComponent_Conditional_34_Conditional_36_Template_input_change_5_listener() {
      i0.\u0275\u0275restoreView(_r20);
      const ctx_r19 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r19.toggleExercisesWithNoCategory());
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n                                    ");
    i0.\u0275\u0275elementStart(7, "span", 19);
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275pipe(9, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r10 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275property("checked", ctx_r10.chartCategoryFilter.includeExercisesWithNoCategory);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(9, 2, "artemisApp.courseOverview.statistics.exercisesWithNoCategories"));
  }
}
function StatisticsAverageScoreGraphComponent_Conditional_34_For_38_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275elementStart(1, "li");
    i0.\u0275\u0275text(2, "\n                                ");
    i0.\u0275\u0275elementStart(3, "label");
    i0.\u0275\u0275text(4, "\n                                    ");
    i0.\u0275\u0275elementStart(5, "input", 21);
    i0.\u0275\u0275listener("change", function StatisticsAverageScoreGraphComponent_Conditional_34_For_38_Template_input_change_5_listener() {
      const restoredCtx = i0.\u0275\u0275restoreView(_r27);
      const category_r21 = restoredCtx.$implicit;
      const ctx_r26 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r26.toggleCategory(category_r21));
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n                                    ");
    i0.\u0275\u0275elementStart(7, "span", 19);
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                        ");
  }
  if (rf & 2) {
    const category_r21 = ctx.$implicit;
    const ctx_r11 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275property("checked", ctx_r11.chartCategoryFilter.getCurrentFilterState(category_r21));
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(category_r21);
  }
}
function StatisticsAverageScoreGraphComponent_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    const _r29 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                ");
    i0.\u0275\u0275elementStart(1, "div", 14);
    i0.\u0275\u0275text(2, "\n                    ");
    i0.\u0275\u0275elementStart(3, "button", 15);
    i0.\u0275\u0275text(4, "\n                        ");
    i0.\u0275\u0275element(5, "fa-icon", 16);
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "span");
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275pipe(9, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                    ");
    i0.\u0275\u0275elementStart(12, "ul", 17);
    i0.\u0275\u0275text(13, "\n                        ");
    i0.\u0275\u0275template(14, StatisticsAverageScoreGraphComponent_Conditional_34_Conditional_14_Template, 8, 3);
    i0.\u0275\u0275repeaterCreate(15, StatisticsAverageScoreGraphComponent_Conditional_34_For_16_Template, 13, 4, null, null, i0.\u0275\u0275repeaterTrackByIdentity);
    i0.\u0275\u0275elementStart(17, "li", 18);
    i0.\u0275\u0275text(18, "\n                            ");
    i0.\u0275\u0275elementStart(19, "b", 19);
    i0.\u0275\u0275text(20);
    i0.\u0275\u0275pipe(21, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(22, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(23, "\n                        ");
    i0.\u0275\u0275elementStart(24, "li");
    i0.\u0275\u0275text(25, "\n                            ");
    i0.\u0275\u0275elementStart(26, "label", 20);
    i0.\u0275\u0275text(27, "\n                                ");
    i0.\u0275\u0275elementStart(28, "input", 21);
    i0.\u0275\u0275listener("change", function StatisticsAverageScoreGraphComponent_Conditional_34_Template_input_change_28_listener() {
      i0.\u0275\u0275restoreView(_r29);
      const ctx_r28 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r28.toggleAllCategories());
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(29, "\n                                ");
    i0.\u0275\u0275elementStart(30, "b", 19);
    i0.\u0275\u0275text(31);
    i0.\u0275\u0275pipe(32, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(33, "\n                            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(34, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(35, "\n                        ");
    i0.\u0275\u0275template(36, StatisticsAverageScoreGraphComponent_Conditional_34_Conditional_36_Template, 13, 4);
    i0.\u0275\u0275repeaterCreate(37, StatisticsAverageScoreGraphComponent_Conditional_34_For_38_Template, 12, 2, null, null, i0.\u0275\u0275repeaterTrackByIdentity);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(39, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(40, "\n            ");
  }
  if (rf & 2) {
    const ctx_r5 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275classProp("btn-secondary", !(ctx_r5.chartCategoryFilter.numberOfActiveFilters + ctx_r5.exerciseTypeFilter.numberOfActiveFilters))("btn-success", ctx_r5.chartCategoryFilter.numberOfActiveFilters + ctx_r5.exerciseTypeFilter.numberOfActiveFilters > 0);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r5.faFilter);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind2(9, 11, "artemisApp.courseOverview.exerciseList.filter", i0.\u0275\u0275pureFunction1(18, _c0, ctx_r5.exerciseTypeFilter.numberOfActiveFilters + ctx_r5.chartCategoryFilter.numberOfActiveFilters)));
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275conditional(14, ctx_r5.exerciseTypeFilter.typeSet.size ? 14 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275repeater(ctx_r5.exerciseTypeFilter.typeSet);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(21, 14, "artemisApp.courseOverview.statistics.includeIndividualCategories"));
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275property("checked", ctx_r5.chartCategoryFilter.allCategoriesSelected);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(32, 16, "artemisApp.courseOverview.statistics.includeAllCategories"));
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275conditional(36, ctx_r5.chartCategoryFilter.exercisesWithoutCategoriesPresent ? 36 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275repeater(ctx_r5.chartCategoryFilter.exerciseCategories);
  }
}
function StatisticsAverageScoreGraphComponent_For_40_Template(rf, ctx) {
  if (rf & 1) {
    const _r36 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "div", 22);
    i0.\u0275\u0275listener("click", function StatisticsAverageScoreGraphComponent_For_40_Template_div_click_1_listener() {
      const restoredCtx = i0.\u0275\u0275restoreView(_r36);
      const interval_r30 = restoredCtx.$implicit;
      const ctx_r35 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r35.togglePerformanceInterval(interval_r30));
    });
    i0.\u0275\u0275text(2, "\n                            ");
    i0.\u0275\u0275element(3, "div", 23);
    i0.\u0275\u0275text(4, "\n                            ");
    i0.\u0275\u0275elementStart(5, "span");
    i0.\u0275\u0275text(6);
    i0.\u0275\u0275pipe(7, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                    ");
  }
  if (rf & 2) {
    const interval_r30 = ctx.$implicit;
    const ctx_r6 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("ngClass", ctx_r6.displayColorMap.get(interval_r30));
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(7, 2, "artemisApp.courseStatistics.chartLegend." + interval_r30));
  }
}
var _c0, _c1, PerformanceInterval, StatisticsAverageScoreGraphComponent;
var init_statistics_average_score_graph_component = __esm({
  "src/main/webapp/app/shared/statistics-graph/statistics-average-score-graph.component.ts"() {
    init_statistics_model();
    init_exercise_model();
    init_statistics_graph_utils();
    init_chart_exercise_type_filter();
    init_navigation_utils();
    init_theme_service();
    init_chart_category_filter();
    init_theme_service();
    init_navigation_utils();
    init_chart_exercise_type_filter();
    init_chart_category_filter();
    init_artemis_translate_pipe();
    _c0 = (a0) => ({ num: a0 });
    _c1 = (a0) => [a0, 300];
    (function(PerformanceInterval2) {
      PerformanceInterval2["LOWEST"] = "lowest";
      PerformanceInterval2["AVERAGE"] = "average";
      PerformanceInterval2["BEST"] = "best";
    })(PerformanceInterval || (PerformanceInterval = {}));
    StatisticsAverageScoreGraphComponent = class _StatisticsAverageScoreGraphComponent {
      themeService;
      navigationUtilService;
      exerciseTypeFilter;
      chartCategoryFilter;
      exerciseAverageScores;
      courseAverage;
      courseId;
      LEFT = false;
      RIGHT = true;
      SpanType = SpanType;
      barChartLabels = [];
      ngxData = [];
      ngxColor = {
        name: "Course statistics",
        selectable: true,
        group: ScaleType.Ordinal,
        domain: []
      };
      exerciseScoresFilteredByPerformanceInterval;
      currentlyDisplayableExercises;
      displayColorMap = /* @__PURE__ */ new Map();
      numberOfSelectedIntervals = 3;
      yAxisTickFormatting = axisTickFormattingWithPercentageSign;
      performanceIntervals = [PerformanceInterval.LOWEST, PerformanceInterval.AVERAGE, PerformanceInterval.BEST];
      convertToMapKey = ChartExerciseTypeFilter.convertToMapKey;
      CRITICAL_CLASS = "critical-color";
      MEDIAN_CLASS = "median-color";
      BEST_CLASS = "best-color";
      maxSpanSize = 10;
      weakestThirdUpperBoundary;
      bestThirdLowerBoundary;
      currentPeriod = 0;
      currentSize = 0;
      faArrowLeft = faArrowLeft;
      faArrowRight = faArrowRight;
      faFilter = faFilter;
      constructor(themeService, navigationUtilService, exerciseTypeFilter, chartCategoryFilter) {
        this.themeService = themeService;
        this.navigationUtilService = navigationUtilService;
        this.exerciseTypeFilter = exerciseTypeFilter;
        this.chartCategoryFilter = chartCategoryFilter;
      }
      ngOnInit() {
        this.initializeChart();
      }
      initializeChart() {
        this.includeAllIntervals();
        this.exerciseAverageScores = this.orderAverageScores(this.exerciseAverageScores);
        this.setUpColorDistribution();
        this.exerciseTypeFilter.initializeFilterOptions(this.exerciseAverageScores);
        this.chartCategoryFilter.setupCategoryFilter(this.exerciseAverageScores);
        this.setupChart(this.exerciseAverageScores);
        this.currentlyDisplayableExercises = this.exerciseAverageScores;
        this.exerciseScoresFilteredByPerformanceInterval = this.exerciseAverageScores;
        this.currentSize = this.exerciseAverageScores.length;
      }
      switchTimeSpan(forward) {
        this.currentPeriod += forward ? 1 : -1;
        this.setupChart(this.currentlyDisplayableExercises);
      }
      determineColor(score) {
        if (score > this.bestThirdLowerBoundary) {
          return GraphColors.GREEN;
        } else if (score < this.weakestThirdUpperBoundary) {
          return GraphColors.RED;
        }
        return GraphColors.GREY;
      }
      onSelect(event) {
        const dataEntry = this.determineChartEntry(event.name, event.value);
        if (dataEntry) {
          const route = ["course-management", this.courseId, "", dataEntry.exerciseId, "exercise-statistics"];
          let type = dataEntry.exerciseType.toLowerCase();
          if (type === ExerciseType.QUIZ) {
            route[4] = "quiz-point-statistic";
          } else if (type === "file_upload") {
            type = "file-upload";
          }
          route[2] = type + "-exercises";
          this.navigationUtilService.routeInNewTab(route);
        }
      }
      determineChartEntry(name, value) {
        let counter = 0;
        let result;
        this.ngxData.forEach((exercise) => {
          if (exercise.name === name && exercise.value === value) {
            counter++;
            result = exercise;
          }
        });
        return counter === 1 ? result : void 0;
      }
      convertTypeForTooltip(name, value) {
        const entry = this.determineChartEntry(name, value);
        if (entry) {
          const type = entry.exerciseType.toLowerCase();
          if (type === "file_upload") {
            return "file-upload";
          }
          return type;
        } else {
          return "";
        }
      }
      setupChart(exerciseModels) {
        this.barChartLabels = exerciseModels.slice(this.currentPeriod, 10 + this.currentPeriod).map((exercise) => exercise.exerciseName);
        this.ngxData = exerciseModels.slice(this.currentPeriod, 10 + this.currentPeriod).map((exercise, index) => ({
          name: this.barChartLabels[index],
          value: exercise.averageScore,
          exerciseType: exercise.exerciseType,
          exerciseId: exercise.exerciseId
        }));
        this.ngxColor.domain = this.ngxData.map((exercise) => this.determineColor(exercise.value));
      }
      setUpColorDistribution() {
        if (!this.exerciseAverageScores || this.exerciseAverageScores.length === 0) {
          return;
        }
        const averageScores = this.exerciseAverageScores.map((exercise) => exercise.averageScore);
        const thirdSize = Math.floor(averageScores.length / 3);
        const highestScoreInLowestThird = averageScores[Math.max(thirdSize - 1, 0)];
        const allScoresAboveLowestThird = averageScores.filter((score) => score > highestScoreInLowestThird);
        this.weakestThirdUpperBoundary = allScoresAboveLowestThird.length > 0 ? Math.min(...allScoresAboveLowestThird) : highestScoreInLowestThird;
        const lowestScoreInBestThird = averageScores[Math.min(averageScores.length - thirdSize, averageScores.length - 1)];
        const allScoresBelowBestThird = averageScores.filter((score) => score < lowestScoreInBestThird);
        this.bestThirdLowerBoundary = allScoresBelowBestThird.length > 0 ? Math.max(...allScoresBelowBestThird) : lowestScoreInBestThird;
      }
      toggleType(type) {
        const filteredAgainstType = this.exerciseTypeFilter.toggleExerciseType(type, this.exerciseScoresFilteredByPerformanceInterval);
        const filteredAgainstCategory = this.chartCategoryFilter.applyCurrentFilter(this.exerciseScoresFilteredByPerformanceInterval);
        this.initializeChartWithFilter(filteredAgainstCategory, filteredAgainstType);
      }
      togglePerformanceInterval(interval) {
        const currentValue = this.displayColorMap.get(interval);
        this.currentPeriod = 0;
        let newValue = "";
        if (currentValue !== "") {
          if (this.numberOfSelectedIntervals === 1) {
            this.includeAllIntervals();
            this.exerciseScoresFilteredByPerformanceInterval = this.orderAverageScores(this.exerciseAverageScores);
          } else {
            this.deselectAllOtherIntervals(interval);
          }
          this.initializeFilterOptionsAndSetupChartWithCurrentVisibleScores();
          return;
        }
        switch (interval) {
          case PerformanceInterval.LOWEST: {
            newValue = this.CRITICAL_CLASS;
            break;
          }
          case PerformanceInterval.AVERAGE: {
            newValue = this.MEDIAN_CLASS;
            break;
          }
          case PerformanceInterval.BEST: {
            newValue = this.BEST_CLASS;
            break;
          }
        }
        this.displayColorMap.set(interval, newValue);
        this.numberOfSelectedIntervals += 1;
        const exercises = this.filterForPerformanceInterval(interval);
        this.exerciseScoresFilteredByPerformanceInterval = this.orderAverageScores(this.exerciseScoresFilteredByPerformanceInterval.concat(exercises));
        this.initializeFilterOptionsAndSetupChartWithCurrentVisibleScores();
      }
      filterForPerformanceInterval(interval) {
        let filterFunction;
        switch (interval) {
          case PerformanceInterval.LOWEST: {
            filterFunction = (model) => model.averageScore < this.weakestThirdUpperBoundary;
            break;
          }
          case PerformanceInterval.AVERAGE: {
            filterFunction = (model) => model.averageScore >= this.weakestThirdUpperBoundary && model.averageScore <= this.bestThirdLowerBoundary;
            break;
          }
          case PerformanceInterval.BEST: {
            filterFunction = (model) => model.averageScore > this.bestThirdLowerBoundary;
          }
        }
        return this.exerciseAverageScores.filter(filterFunction);
      }
      orderAverageScores(exerciseModels) {
        return exerciseModels.sort((exercise1, exercise2) => exercise1.averageScore - exercise2.averageScore);
      }
      initializeFilterOptionsAndSetupChartWithCurrentVisibleScores() {
        this.exerciseTypeFilter.initializeFilterOptions(this.exerciseScoresFilteredByPerformanceInterval);
        this.chartCategoryFilter.setupCategoryFilter(this.exerciseScoresFilteredByPerformanceInterval);
        this.setupChart(this.exerciseScoresFilteredByPerformanceInterval);
        this.currentlyDisplayableExercises = this.exerciseScoresFilteredByPerformanceInterval;
        this.currentSize = this.exerciseScoresFilteredByPerformanceInterval.length;
      }
      includeAllIntervals() {
        this.displayColorMap.set(PerformanceInterval.LOWEST, this.CRITICAL_CLASS);
        this.displayColorMap.set(PerformanceInterval.AVERAGE, this.MEDIAN_CLASS);
        this.displayColorMap.set(PerformanceInterval.BEST, this.BEST_CLASS);
        this.numberOfSelectedIntervals = 3;
      }
      deselectAllOtherIntervals(interval) {
        this.performanceIntervals.forEach((pi) => {
          if (pi !== interval) {
            this.displayColorMap.set(pi, "");
          }
        });
        this.numberOfSelectedIntervals = 1;
        this.exerciseScoresFilteredByPerformanceInterval = this.filterForPerformanceInterval(interval);
      }
      toggleCategory(category) {
        const filteredAgainstCategory = this.chartCategoryFilter.toggleCategory(this.exerciseScoresFilteredByPerformanceInterval, category);
        const filteredAgainstType = this.exerciseTypeFilter.applyCurrentFilter(this.exerciseScoresFilteredByPerformanceInterval);
        this.initializeChartWithFilter(filteredAgainstCategory, filteredAgainstType);
      }
      toggleAllCategories() {
        const filteredAgainstCategory = this.chartCategoryFilter.toggleAllCategories(this.exerciseScoresFilteredByPerformanceInterval);
        const filteredAgainstType = this.exerciseTypeFilter.applyCurrentFilter(this.exerciseScoresFilteredByPerformanceInterval);
        this.initializeChartWithFilter(filteredAgainstCategory, filteredAgainstType);
      }
      toggleExercisesWithNoCategory() {
        const filteredAgainstCategory = this.chartCategoryFilter.toggleExercisesWithNoCategory(this.exerciseScoresFilteredByPerformanceInterval);
        const filteredAgainstType = this.exerciseTypeFilter.applyCurrentFilter(this.exerciseScoresFilteredByPerformanceInterval);
        this.initializeChartWithFilter(filteredAgainstCategory, filteredAgainstType);
      }
      initializeChartWithFilter(filteredAgainstCategory, filteredAgainstType) {
        this.currentlyDisplayableExercises = this.orderAverageScores(filteredAgainstCategory.filter((score) => filteredAgainstType.includes(score)));
        this.currentPeriod = 0;
        this.setupChart(this.currentlyDisplayableExercises);
        this.currentSize = this.currentlyDisplayableExercises.length;
      }
      formatDataLabel(averageScore) {
        return averageScore + "%";
      }
      static \u0275fac = function StatisticsAverageScoreGraphComponent_Factory(t) {
        return new (t || _StatisticsAverageScoreGraphComponent)(i0.\u0275\u0275directiveInject(ThemeService), i0.\u0275\u0275directiveInject(ArtemisNavigationUtilService), i0.\u0275\u0275directiveInject(ChartExerciseTypeFilter), i0.\u0275\u0275directiveInject(ChartCategoryFilter));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _StatisticsAverageScoreGraphComponent, selectors: [["jhi-statistics-average-score-graph"]], inputs: { exerciseAverageScores: "exerciseAverageScores", courseAverage: "courseAverage", courseId: "courseId" }, decls: 46, vars: 26, consts: [[1, "row", "mb-3", "d-flex", "justify-content-center"], [1, "col-xl-1", "d-flex", "flex-column"], [1, "row", "col-xl-11", "chart-row"], ["size", "2x", "role", "button", 1, "col-1", "d-flex", "align-items-center", "justify-content-end", 3, "icon", "click"], [1, "col-lg-8", "ps-0", "chart-container"], ["containerRef", ""], [3, "roundEdges", "view", "results", "scheme", "yScaleMax", "xAxis", "yAxis", "yAxisTickFormatting", "dataLabelFormatting", "showDataLabel", "select"], ["tooltipTemplate", ""], ["size", "2x", "role", "button", 1, "col-1", "d-flex", "align-items-center", "switch-forward", 3, "icon", "click"], ["placeholder", ""], [1, "col-lg-2", "d-flex", "flex-column", "align-items-center", "justify-content-center"], [1, "d-flex", "align-items-center"], [1, "legend-container"], [1, "switch-forward-placeholder"], ["aria-label", "Filter Dropdown", "ngbDropdown", "", 1, "filter", "my-3"], ["ngbDropdownToggle", "", "id", "filter-dropdown-button", 1, "btn"], [3, "icon"], ["ngbDropdownMenu", "", "aria-labelledby", "filter-dropdown-button", 1, "checkbox-menu", "text-nowrap", "pe-2"], [1, "mt-1", "mb-1"], [1, "ms-2"], [1, "mb-1"], ["type", "checkbox", 1, "ms-2", "form-check-input", 3, "checked", "change"], [1, "legend-entry", 3, "click"], [1, "color-legend", 3, "ngClass"]], template: function StatisticsAverageScoreGraphComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "div", 0);
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275elementStart(2, "div", 1);
          i0.\u0275\u0275text(3, "\n        ");
          i0.\u0275\u0275elementStart(4, "h3");
          i0.\u0275\u0275text(5);
          i0.\u0275\u0275pipe(6, "artemisTranslate");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(7, "\n        ");
          i0.\u0275\u0275elementStart(8, "h4");
          i0.\u0275\u0275text(9);
          i0.\u0275\u0275pipe(10, "artemisTranslate");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(11, "\n    ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(12, "\n    ");
          i0.\u0275\u0275elementStart(13, "div", 2);
          i0.\u0275\u0275text(14, "\n        ");
          i0.\u0275\u0275elementStart(15, "fa-icon", 3);
          i0.\u0275\u0275listener("click", function StatisticsAverageScoreGraphComponent_Template_fa_icon_click_15_listener() {
            return ctx.switchTimeSpan(ctx.LEFT);
          });
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(16, "\n        ");
          i0.\u0275\u0275elementStart(17, "div", 4, 5);
          i0.\u0275\u0275text(19, "\n            ");
          i0.\u0275\u0275elementStart(20, "ngx-charts-bar-vertical", 6);
          i0.\u0275\u0275listener("select", function StatisticsAverageScoreGraphComponent_Template_ngx_charts_bar_vertical_select_20_listener($event) {
            return ctx.onSelect($event);
          });
          i0.\u0275\u0275text(21, "\n                ");
          i0.\u0275\u0275template(22, StatisticsAverageScoreGraphComponent_ng_template_22_Template, 17, 11, "ng-template", null, 7, i0.\u0275\u0275templateRefExtractor);
          i0.\u0275\u0275text(24, "\n            ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(25, "\n        ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(26, "\n        ");
          i0.\u0275\u0275elementStart(27, "fa-icon", 8);
          i0.\u0275\u0275listener("click", function StatisticsAverageScoreGraphComponent_Template_fa_icon_click_27_listener() {
            return ctx.switchTimeSpan(ctx.RIGHT);
          });
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(28, "\n        ");
          i0.\u0275\u0275template(29, StatisticsAverageScoreGraphComponent_ng_template_29_Template, 3, 0, "ng-template", null, 9, i0.\u0275\u0275templateRefExtractor);
          i0.\u0275\u0275text(31, "\n        ");
          i0.\u0275\u0275elementStart(32, "div", 10);
          i0.\u0275\u0275text(33, "\n            ");
          i0.\u0275\u0275template(34, StatisticsAverageScoreGraphComponent_Conditional_34_Template, 41, 20);
          i0.\u0275\u0275elementStart(35, "div", 11);
          i0.\u0275\u0275text(36, "\n                ");
          i0.\u0275\u0275elementStart(37, "div", 12);
          i0.\u0275\u0275text(38, "\n                    ");
          i0.\u0275\u0275repeaterCreate(39, StatisticsAverageScoreGraphComponent_For_40_Template, 10, 4, null, null, i0.\u0275\u0275repeaterTrackByIdentity);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(41, "\n            ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(42, "\n        ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(43, "\n    ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(44, "\n");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(45, "\n");
        }
        if (rf & 2) {
          const _r0 = i0.\u0275\u0275reference(18);
          i0.\u0275\u0275advance(5);
          i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(6, 20, "artemisApp.course.averageScore"));
          i0.\u0275\u0275advance(4);
          i0.\u0275\u0275textInterpolate2("", i0.\u0275\u0275pipeBind1(10, 22, "artemisApp.courseStatistics.courseAverage"), ": ", ctx.courseAverage, "%");
          i0.\u0275\u0275advance(6);
          i0.\u0275\u0275classProp("hidden", !(ctx.currentSize > ctx.maxSpanSize && ctx.currentPeriod > 0));
          i0.\u0275\u0275property("icon", ctx.faArrowLeft);
          i0.\u0275\u0275advance(5);
          i0.\u0275\u0275property("roundEdges", false)("view", i0.\u0275\u0275pureFunction1(24, _c1, _r0.offsetWidth))("results", ctx.ngxData)("scheme", ctx.ngxColor)("yScaleMax", 100)("xAxis", true)("yAxis", true)("yAxisTickFormatting", ctx.yAxisTickFormatting)("dataLabelFormatting", ctx.formatDataLabel)("showDataLabel", true);
          i0.\u0275\u0275advance(7);
          i0.\u0275\u0275classProp("hidden", !(ctx.currentSize > ctx.maxSpanSize + ctx.currentPeriod));
          i0.\u0275\u0275property("icon", ctx.faArrowRight);
          i0.\u0275\u0275advance(7);
          i0.\u0275\u0275conditional(34, ctx.exerciseTypeFilter.typeSet.size > 0 ? 34 : -1);
          i0.\u0275\u0275advance(5);
          i0.\u0275\u0275repeater(ctx.performanceIntervals);
        }
      }, dependencies: [i5.NgClass, i6.NgbDropdown, i6.NgbDropdownToggle, i6.NgbDropdownMenu, i7.FaIconComponent, i8.BarVerticalComponent, ArtemisTranslatePipe], styles: ["\n\n.color-legend[_ngcontent-%COMP%] {\n  width: 15px;\n  height: 15px;\n  border-radius: 3px;\n  border: 1px solid;\n  margin-right: 5px;\n}\n.legend-entry[_ngcontent-%COMP%] {\n  cursor: pointer;\n  display: inline-flex;\n  align-items: center;\n  width: 100%;\n}\n.legend-container[_ngcontent-%COMP%] {\n  background: var(--stat-av-sc-legend-background);\n  padding: 5px;\n  border-radius: 5px;\n  max-width: 300px;\n}\n.switch-forward[_ngcontent-%COMP%] {\n  max-width: 30px !important;\n}\n.switch-forward-placeholder[_ngcontent-%COMP%] {\n  width: 60px;\n  height: 300px;\n}\n.hidden[_ngcontent-%COMP%] {\n  visibility: hidden;\n}\n.critical-color[_ngcontent-%COMP%] {\n  background: var(--stat-av-sc-legend-critical);\n}\n.median-color[_ngcontent-%COMP%] {\n  background: var(--stat-av-sc-legend-median);\n}\n.best-color[_ngcontent-%COMP%] {\n  background: var(--stat-av-sc-legend-best);\n}\n.chart-container[_ngcontent-%COMP%] {\n  max-width: 83%;\n}\n.chart-row[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\n  padding-left: 0;\n  padding-right: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvc3RhdGlzdGljcy1ncmFwaC9zdGF0aXN0aWNzLWF2ZXJhZ2Utc2NvcmUtZ3JhcGguY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5jb2xvci1sZWdlbmQge1xuICAgIHdpZHRoOiAxNXB4O1xuICAgIGhlaWdodDogMTVweDtcbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgYm9yZGVyOiAxcHggc29saWQ7XG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG59XG5cbi5sZWdlbmQtZW50cnkge1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIHdpZHRoOiAxMDAlO1xufVxuXG4ubGVnZW5kLWNvbnRhaW5lciB7XG4gICAgYmFja2dyb3VuZDogdmFyKC0tc3RhdC1hdi1zYy1sZWdlbmQtYmFja2dyb3VuZCk7XG4gICAgcGFkZGluZzogNXB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICBtYXgtd2lkdGg6IDMwMHB4O1xufVxuXG4uc3dpdGNoLWZvcndhcmQge1xuICAgIG1heC13aWR0aDogMzBweCAhaW1wb3J0YW50O1xufVxuXG4uc3dpdGNoLWZvcndhcmQtcGxhY2Vob2xkZXIge1xuICAgIHdpZHRoOiA2MHB4O1xuICAgIGhlaWdodDogMzAwcHg7XG59XG5cbi5oaWRkZW4ge1xuICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcbn1cblxuLmNyaXRpY2FsLWNvbG9yIHtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1zdGF0LWF2LXNjLWxlZ2VuZC1jcml0aWNhbCk7XG59XG5cbi5tZWRpYW4tY29sb3Ige1xuICAgIGJhY2tncm91bmQ6IHZhcigtLXN0YXQtYXYtc2MtbGVnZW5kLW1lZGlhbik7XG59XG5cbi5iZXN0LWNvbG9yIHtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1zdGF0LWF2LXNjLWxlZ2VuZC1iZXN0KTtcbn1cblxuLmNoYXJ0LWNvbnRhaW5lciB7XG4gICAgbWF4LXdpZHRoOiA4MyU7XG59XG5cbi5jaGFydC1yb3cge1xuICAgID4gKiB7XG4gICAgICAgIHBhZGRpbmctbGVmdDogMDtcbiAgICAgICAgcGFkZGluZy1yaWdodDogMDtcbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFNBQUE7QUFDQSxVQUFBO0FBQ0EsaUJBQUE7QUFDQSxVQUFBLElBQUE7QUFDQSxnQkFBQTs7QUFHSixDQUFBO0FBQ0ksVUFBQTtBQUNBLFdBQUE7QUFDQSxlQUFBO0FBQ0EsU0FBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQSxJQUFBO0FBQ0EsV0FBQTtBQUNBLGlCQUFBO0FBQ0EsYUFBQTs7QUFHSixDQUFBO0FBQ0ksYUFBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQTtBQUNBLFVBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUEsSUFBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLGFBQUE7O0FBSUEsQ0FBQSxVQUFBLEVBQUE7QUFDSSxnQkFBQTtBQUNBLGlCQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */", "\n\n[_nghost-%COMP%]  .textDataLabel {\n  font-weight: bolder;\n  font-size: small !important;\n  alignment-baseline: middle;\n  text-anchor: start;\n}\n@media (min-width: 1420px) {\n  [_nghost-%COMP%]  .textDataLabel {\n    transform: rotate(0deg);\n    font-size: medium !important;\n    alignment-baseline: baseline;\n    text-anchor: middle;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvY2hhcnQvdmVydGljYWwtYmFyLWNoYXJ0LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIjpob3N0OjpuZy1kZWVwIC50ZXh0RGF0YUxhYmVsIHtcbiAgICBmb250LXdlaWdodDogYm9sZGVyO1xuICAgIGZvbnQtc2l6ZTogc21hbGwgIWltcG9ydGFudDtcbiAgICBhbGlnbm1lbnQtYmFzZWxpbmU6IG1pZGRsZTtcbiAgICB0ZXh0LWFuY2hvcjogc3RhcnQ7XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiAxNDIwcHgpIHtcbiAgICA6aG9zdDo6bmctZGVlcCAudGV4dERhdGFMYWJlbCB7XG4gICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xuICAgICAgICBmb250LXNpemU6IG1lZGl1bSAhaW1wb3J0YW50O1xuICAgICAgICBhbGlnbm1lbnQtYmFzZWxpbmU6IGJhc2VsaW5lO1xuICAgICAgICB0ZXh0LWFuY2hvcjogbWlkZGxlO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxLQUFBLFVBQUEsQ0FBQTtBQUNJLGVBQUE7QUFDQSxhQUFBO0FBQ0Esc0JBQUE7QUFDQSxlQUFBOztBQUdKLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFDSSxPQUFBLFVBQUEsQ0FSSjtBQVNRLGVBQUEsT0FBQTtBQUNBLGVBQUE7QUFDQSx3QkFBQTtBQUNBLGlCQUFBOzs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(StatisticsAverageScoreGraphComponent, { className: "StatisticsAverageScoreGraphComponent" });
    })();
  }
});

// src/main/webapp/app/shared/chart/artemis-charts.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { RouterModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { BarChartModule, LineChartModule, PieChartModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisChartsModule;
var init_artemis_charts_module = __esm({
  "src/main/webapp/app/shared/chart/artemis-charts.module.ts"() {
    init_doughnut_chart_component();
    init_statistics_average_score_graph_component();
    init_statistics_graph_component();
    init_statistics_score_distribution_graph_component();
    init_shared_module();
    ArtemisChartsModule = class _ArtemisChartsModule {
      static \u0275fac = function ArtemisChartsModule_Factory(t) {
        return new (t || _ArtemisChartsModule)();
      };
      static \u0275mod = i02.\u0275\u0275defineNgModule({ type: _ArtemisChartsModule });
      static \u0275inj = i02.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, RouterModule, BarChartModule, LineChartModule, PieChartModule] });
    };
  }
});

export {
  StatisticsAverageScoreGraphComponent,
  init_statistics_average_score_graph_component,
  ArtemisChartsModule,
  init_artemis_charts_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3N0YXRpc3RpY3MtZ3JhcGgvc3RhdGlzdGljcy1hdmVyYWdlLXNjb3JlLWdyYXBoLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3N0YXRpc3RpY3MtZ3JhcGgvc3RhdGlzdGljcy1hdmVyYWdlLXNjb3JlLWdyYXBoLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvY2hhcnQvYXJ0ZW1pcy1jaGFydHMubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgR3JhcGhDb2xvcnMsIFNwYW5UeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3N0YXRpc3RpY3MubW9kZWwnO1xuaW1wb3J0IHsgQ291cnNlTWFuYWdlbWVudFN0YXRpc3RpY3NNb2RlbCB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L2NvdXJzZS1tYW5hZ2VtZW50LXN0YXRpc3RpY3MtbW9kZWwnO1xuaW1wb3J0IHsgZmFBcnJvd0xlZnQsIGZhQXJyb3dSaWdodCwgZmFGaWx0ZXIgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgQ29sb3IsIFNjYWxlVHlwZSB9IGZyb20gJ0Bzd2ltbGFuZS9uZ3gtY2hhcnRzJztcbmltcG9ydCB7IEV4ZXJjaXNlVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBOZ3hDaGFydHNTaW5nbGVTZXJpZXNEYXRhRW50cnkgfSBmcm9tICdhcHAvc2hhcmVkL2NoYXJ0L25neC1jaGFydHMtZGF0YXR5cGVzJztcbmltcG9ydCB7IGF4aXNUaWNrRm9ybWF0dGluZ1dpdGhQZXJjZW50YWdlU2lnbiB9IGZyb20gJ2FwcC9zaGFyZWQvc3RhdGlzdGljcy1ncmFwaC9zdGF0aXN0aWNzLWdyYXBoLnV0aWxzJztcbmltcG9ydCB7IENoYXJ0RXhlcmNpc2VUeXBlRmlsdGVyIH0gZnJvbSAnYXBwL3NoYXJlZC9jaGFydC9jaGFydC1leGVyY2lzZS10eXBlLWZpbHRlcic7XG5pbXBvcnQgeyBBcnRlbWlzTmF2aWdhdGlvblV0aWxTZXJ2aWNlIH0gZnJvbSAnYXBwL3V0aWxzL25hdmlnYXRpb24udXRpbHMnO1xuaW1wb3J0IHsgVGhlbWVTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvdGhlbWUvdGhlbWUuc2VydmljZSc7XG5pbXBvcnQgeyBDaGFydENhdGVnb3J5RmlsdGVyIH0gZnJvbSAnYXBwL3NoYXJlZC9jaGFydC9jaGFydC1jYXRlZ29yeS1maWx0ZXInO1xuXG5pbnRlcmZhY2UgRXhlcmNpc2VTdGF0aXN0aWNzRW50cnkgZXh0ZW5kcyBOZ3hDaGFydHNTaW5nbGVTZXJpZXNEYXRhRW50cnkge1xuICAgIGV4ZXJjaXNlVHlwZTogRXhlcmNpc2VUeXBlO1xuICAgIGV4ZXJjaXNlSWQ6IG51bWJlcjtcbn1cblxuZXhwb3J0IGVudW0gUGVyZm9ybWFuY2VJbnRlcnZhbCB7XG4gICAgTE9XRVNUID0gJ2xvd2VzdCcsXG4gICAgQVZFUkFHRSA9ICdhdmVyYWdlJyxcbiAgICBCRVNUID0gJ2Jlc3QnLFxufVxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1zdGF0aXN0aWNzLWF2ZXJhZ2Utc2NvcmUtZ3JhcGgnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9zdGF0aXN0aWNzLWF2ZXJhZ2Utc2NvcmUtZ3JhcGguY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL3N0YXRpc3RpY3MtYXZlcmFnZS1zY29yZS1ncmFwaC5jb21wb25lbnQuc2NzcycsICcuLi9jaGFydC92ZXJ0aWNhbC1iYXItY2hhcnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBTdGF0aXN0aWNzQXZlcmFnZVNjb3JlR3JhcGhDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEBJbnB1dCgpXG4gICAgZXhlcmNpc2VBdmVyYWdlU2NvcmVzOiBDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc01vZGVsW107XG4gICAgQElucHV0KClcbiAgICBjb3Vyc2VBdmVyYWdlOiBudW1iZXI7XG4gICAgQElucHV0KClcbiAgICBjb3Vyc2VJZDogbnVtYmVyO1xuXG4gICAgLy8gSHRtbCBwcm9wZXJ0aWVzXG4gICAgTEVGVCA9IGZhbHNlO1xuICAgIFJJR0hUID0gdHJ1ZTtcbiAgICBTcGFuVHlwZSA9IFNwYW5UeXBlO1xuXG4gICAgLy8gRGF0YVxuICAgIGJhckNoYXJ0TGFiZWxzOiBzdHJpbmdbXSA9IFtdO1xuICAgIC8vIG5neFxuICAgIG5neERhdGE6IEV4ZXJjaXNlU3RhdGlzdGljc0VudHJ5W10gPSBbXTtcbiAgICBuZ3hDb2xvciA9IHtcbiAgICAgICAgbmFtZTogJ0NvdXJzZSBzdGF0aXN0aWNzJyxcbiAgICAgICAgc2VsZWN0YWJsZTogdHJ1ZSxcbiAgICAgICAgZ3JvdXA6IFNjYWxlVHlwZS5PcmRpbmFsLFxuICAgICAgICBkb21haW46IFtdLFxuICAgIH0gYXMgQ29sb3I7XG5cbiAgICAvLyBmb3IgZmlsdGVyaW5nXG4gICAgZXhlcmNpc2VTY29yZXNGaWx0ZXJlZEJ5UGVyZm9ybWFuY2VJbnRlcnZhbDogQ291cnNlTWFuYWdlbWVudFN0YXRpc3RpY3NNb2RlbFtdO1xuICAgIGN1cnJlbnRseURpc3BsYXlhYmxlRXhlcmNpc2VzOiBDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc01vZGVsW107XG4gICAgZGlzcGxheUNvbG9yTWFwID0gbmV3IE1hcDxQZXJmb3JtYW5jZUludGVydmFsLCBzdHJpbmc+KCk7XG4gICAgbnVtYmVyT2ZTZWxlY3RlZEludGVydmFscyA9IDM7XG5cbiAgICByZWFkb25seSB5QXhpc1RpY2tGb3JtYXR0aW5nID0gYXhpc1RpY2tGb3JtYXR0aW5nV2l0aFBlcmNlbnRhZ2VTaWduO1xuICAgIHJlYWRvbmx5IHBlcmZvcm1hbmNlSW50ZXJ2YWxzID0gW1BlcmZvcm1hbmNlSW50ZXJ2YWwuTE9XRVNULCBQZXJmb3JtYW5jZUludGVydmFsLkFWRVJBR0UsIFBlcmZvcm1hbmNlSW50ZXJ2YWwuQkVTVF07XG4gICAgcmVhZG9ubHkgY29udmVydFRvTWFwS2V5ID0gQ2hhcnRFeGVyY2lzZVR5cGVGaWx0ZXIuY29udmVydFRvTWFwS2V5O1xuICAgIHJlYWRvbmx5IENSSVRJQ0FMX0NMQVNTID0gJ2NyaXRpY2FsLWNvbG9yJztcbiAgICByZWFkb25seSBNRURJQU5fQ0xBU1MgPSAnbWVkaWFuLWNvbG9yJztcbiAgICByZWFkb25seSBCRVNUX0NMQVNTID0gJ2Jlc3QtY29sb3InO1xuICAgIHJlYWRvbmx5IG1heFNwYW5TaXplID0gMTA7IC8vIFRoZSBtYXhpbXVtIGFtb3VudCBvZiBleGVyY2lzZXMgZGlzcGxheWFibGUgaW4gb25lIHNjb3BlXG5cbiAgICB3ZWFrZXN0VGhpcmRVcHBlckJvdW5kYXJ5OiBudW1iZXI7XG4gICAgYmVzdFRoaXJkTG93ZXJCb3VuZGFyeTogbnVtYmVyO1xuXG4gICAgLy8gTGVmdCBhcnJvdyAtPiBkZWNyZWFzZSwgcmlnaHQgYXJyb3cgLT4gaW5jcmVhc2VcbiAgICBjdXJyZW50UGVyaW9kID0gMDtcbiAgICBjdXJyZW50U2l6ZSA9IDA7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhQXJyb3dMZWZ0ID0gZmFBcnJvd0xlZnQ7XG4gICAgZmFBcnJvd1JpZ2h0ID0gZmFBcnJvd1JpZ2h0O1xuICAgIGZhRmlsdGVyID0gZmFGaWx0ZXI7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSB0aGVtZVNlcnZpY2U6IFRoZW1lU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBuYXZpZ2F0aW9uVXRpbFNlcnZpY2U6IEFydGVtaXNOYXZpZ2F0aW9uVXRpbFNlcnZpY2UsXG4gICAgICAgIHJlYWRvbmx5IGV4ZXJjaXNlVHlwZUZpbHRlcjogQ2hhcnRFeGVyY2lzZVR5cGVGaWx0ZXIsXG4gICAgICAgIHJlYWRvbmx5IGNoYXJ0Q2F0ZWdvcnlGaWx0ZXI6IENoYXJ0Q2F0ZWdvcnlGaWx0ZXIsXG4gICAgKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuaW5pdGlhbGl6ZUNoYXJ0KCk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBpbml0aWFsaXplQ2hhcnQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuaW5jbHVkZUFsbEludGVydmFscygpO1xuICAgICAgICB0aGlzLmV4ZXJjaXNlQXZlcmFnZVNjb3JlcyA9IHRoaXMub3JkZXJBdmVyYWdlU2NvcmVzKHRoaXMuZXhlcmNpc2VBdmVyYWdlU2NvcmVzKTtcbiAgICAgICAgdGhpcy5zZXRVcENvbG9yRGlzdHJpYnV0aW9uKCk7XG4gICAgICAgIHRoaXMuZXhlcmNpc2VUeXBlRmlsdGVyLmluaXRpYWxpemVGaWx0ZXJPcHRpb25zKHRoaXMuZXhlcmNpc2VBdmVyYWdlU2NvcmVzKTtcbiAgICAgICAgdGhpcy5jaGFydENhdGVnb3J5RmlsdGVyLnNldHVwQ2F0ZWdvcnlGaWx0ZXIodGhpcy5leGVyY2lzZUF2ZXJhZ2VTY29yZXMpO1xuICAgICAgICB0aGlzLnNldHVwQ2hhcnQodGhpcy5leGVyY2lzZUF2ZXJhZ2VTY29yZXMpO1xuICAgICAgICB0aGlzLmN1cnJlbnRseURpc3BsYXlhYmxlRXhlcmNpc2VzID0gdGhpcy5leGVyY2lzZUF2ZXJhZ2VTY29yZXM7XG4gICAgICAgIHRoaXMuZXhlcmNpc2VTY29yZXNGaWx0ZXJlZEJ5UGVyZm9ybWFuY2VJbnRlcnZhbCA9IHRoaXMuZXhlcmNpc2VBdmVyYWdlU2NvcmVzO1xuICAgICAgICB0aGlzLmN1cnJlbnRTaXplID0gdGhpcy5leGVyY2lzZUF2ZXJhZ2VTY29yZXMubGVuZ3RoO1xuICAgIH1cblxuICAgIC8vIGhhbmRsZXMgYXJyb3cgY2xpY2tzIGFuZCB1cGRhdGVzIHRoZSBleGVyY2lzZXMgd2hpY2ggYXJlIHNob3duLCBmb3J3YXJkIGlzIGJvb2xlYW4gc2luY2UgaXQgaXMgZWl0aGVyIGZvcndhcmQgb3IgYmFja3dhcmRcbiAgICBwdWJsaWMgc3dpdGNoVGltZVNwYW4oZm9yd2FyZDogYm9vbGVhbik6IHZvaWQge1xuICAgICAgICB0aGlzLmN1cnJlbnRQZXJpb2QgKz0gZm9yd2FyZCA/IDEgOiAtMTtcbiAgICAgICAgdGhpcy5zZXR1cENoYXJ0KHRoaXMuY3VycmVudGx5RGlzcGxheWFibGVFeGVyY2lzZXMpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERldGVybWluZXMgdGhlIGNvbG9yIG9mIHRoZSBiYXIgZ2l2ZW4gdGhlIHNjb3JlXG4gICAgICogQHBhcmFtIHNjb3JlIHRoYXQgaXMgcmVwcmVzZW50ZWQgYnkgdGhlIGJhclxuICAgICAqIEByZXR1cm5zIHN0cmluZyByZ2JhIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBjb2xvclxuICAgICAqL1xuICAgIHByaXZhdGUgZGV0ZXJtaW5lQ29sb3Ioc2NvcmU6IG51bWJlcik6IHN0cmluZyB7XG4gICAgICAgIGlmIChzY29yZSA+IHRoaXMuYmVzdFRoaXJkTG93ZXJCb3VuZGFyeSkge1xuICAgICAgICAgICAgcmV0dXJuIEdyYXBoQ29sb3JzLkdSRUVOO1xuICAgICAgICB9IGVsc2UgaWYgKHNjb3JlIDwgdGhpcy53ZWFrZXN0VGhpcmRVcHBlckJvdW5kYXJ5KSB7XG4gICAgICAgICAgICByZXR1cm4gR3JhcGhDb2xvcnMuUkVEO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBHcmFwaENvbG9ycy5HUkVZO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEhhbmRsZXMgdGhlIGNsaWNrIGV2ZW50IG9uIG9uZSBvZiB0aGUgYmFycyBhbmQgbmF2aWdhdGVzIHRvIHRoZSBjb3JyZXNwb25kaW5nIGV4ZXJjaXNlIHN0YXRpc3RpY3MgcGFnZVxuICAgICAqIEBwYXJhbSBldmVudCB0aGUgZXZlbnQgdGhhdCBpcyBwYXNzZWQgYnkgdGhlIGZyYW1ld29ya1xuICAgICAqL1xuICAgIG9uU2VsZWN0KGV2ZW50OiBhbnkpOiB2b2lkIHtcbiAgICAgICAgY29uc3QgZGF0YUVudHJ5ID0gdGhpcy5kZXRlcm1pbmVDaGFydEVudHJ5KGV2ZW50Lm5hbWUsIGV2ZW50LnZhbHVlKTtcblxuICAgICAgICAvLyBhIHdvcmthcm91bmQgaW4gb3JkZXIgdG8gcHJldmVudCBmYWxzZSBuYXZpZ2F0aW9uLiBJZiBtb3JlIHRoYW4gb25lIGV4ZXJjaXNlIGlzIG1hdGNoaW5nLCBubyByb3V0aW5nIGlzIGRvbmVcbiAgICAgICAgaWYgKGRhdGFFbnRyeSkge1xuICAgICAgICAgICAgY29uc3Qgcm91dGUgPSBbJ2NvdXJzZS1tYW5hZ2VtZW50JywgdGhpcy5jb3Vyc2VJZCwgJycsIGRhdGFFbnRyeS5leGVyY2lzZUlkLCAnZXhlcmNpc2Utc3RhdGlzdGljcyddO1xuICAgICAgICAgICAgbGV0IHR5cGUgPSBkYXRhRW50cnkuZXhlcmNpc2VUeXBlLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgICBpZiAodHlwZSA9PT0gRXhlcmNpc2VUeXBlLlFVSVopIHtcbiAgICAgICAgICAgICAgICByb3V0ZVs0XSA9ICdxdWl6LXBvaW50LXN0YXRpc3RpYyc7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdmaWxlX3VwbG9hZCcpIHtcbiAgICAgICAgICAgICAgICB0eXBlID0gJ2ZpbGUtdXBsb2FkJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJvdXRlWzJdID0gdHlwZSArICctZXhlcmNpc2VzJztcbiAgICAgICAgICAgIHRoaXMubmF2aWdhdGlvblV0aWxTZXJ2aWNlLnJvdXRlSW5OZXdUYWIocm91dGUpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGV0ZXJtaW5lcyB0aGUgZW50cnkgaW4gdGhlIGNoYXJ0IGZvciBhIG1vdXNlIGV2ZW50XG4gICAgICogQHBhcmFtIG5hbWUgbmFtZSBvZiB0aGUgZXhlcmNpc2VcbiAgICAgKiBAcGFyYW0gdmFsdWUgYXZlcmFnZSBzY29yZSBvZiB0aGUgZXhlcmNpc2VcbiAgICAgKi9cbiAgICBwcml2YXRlIGRldGVybWluZUNoYXJ0RW50cnkobmFtZTogc3RyaW5nLCB2YWx1ZTogbnVtYmVyKTogRXhlcmNpc2VTdGF0aXN0aWNzRW50cnkgfCB1bmRlZmluZWQge1xuICAgICAgICBsZXQgY291bnRlciA9IDA7XG4gICAgICAgIGxldCByZXN1bHQ7XG4gICAgICAgIC8qXG4gICAgICAgICAqIFRoZSBlbWl0dGVkIGV2ZW50IG9ubHkgY29udGFpbnMgdGhlIG5hbWUgYW5kIHRoZSBhdmVyYWdlIHNjb3JlIG9mIHRoZSBleGVyY2lzZS4gVXNpbmcgdGhvc2UgdmFsdWVzIHRvIGRldGVybWluZSB0aGUgY2hhcnQgZW50cnlcbiAgICAgICAgICogaXMgbm90IGFuIGlkZWFsIHNvbHV0aW9uIGFzIHRoaXMgcGFpciBpcyBub3QgbmVjZXNzYXJpbHkgdW5pcXVlLlxuICAgICAgICAgKiBJbiBwcmFjdGljZSB0aGV5IG1vc3QgbGlrZWx5IGFyZSB1bmlxdWUsIHRob3VnaC4gTm90IGJlaW5nIGFibGUgdG8gZmluZCB0aGUgZW50cnkgaW4gdGhpcyBlZGdlIGNhc2UgdGhlcmVmb3JlIGhhcyBuZWdsaWdpYmxlIGltcGFjdC5cbiAgICAgICAgICovXG4gICAgICAgIHRoaXMubmd4RGF0YS5mb3JFYWNoKChleGVyY2lzZSkgPT4ge1xuICAgICAgICAgICAgaWYgKGV4ZXJjaXNlLm5hbWUgPT09IG5hbWUgJiYgZXhlcmNpc2UudmFsdWUgPT09IHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgY291bnRlcisrO1xuICAgICAgICAgICAgICAgIHJlc3VsdCA9IGV4ZXJjaXNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgLy8gaWYgbW9yZSB0aGFuIG9uZSBleGVyY2lzZSBtYXRjaCwgd2UgZG8gbm90IG5hdmlnYXRlXG4gICAgICAgIHJldHVybiBjb3VudGVyID09PSAxID8gcmVzdWx0IDogdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENvbnZlcnRzIHRoZSBleGVyY2lzZSB0eXBlIGNvbnRhaW5lZCBpbiB0aGUgRXhlcmNpc2VTdGF0aXN0aWNFbnRyaWVzIGZvciB0aGUgdG9vbHRpcCBpbiBvcmRlciB0byBtYWtlIGl0IHRyYW5zbGF0YWJsZVxuICAgICAqIEBwYXJhbSBuYW1lIHRoZSBuYW1lIG9mIHRoZSBleGVyY2lzZVxuICAgICAqIEBwYXJhbSB2YWx1ZSB0aGUgYXZlcmFnZSBzY29yZSBvZiB0aGUgZXhlcmNpc2VcbiAgICAgKi9cbiAgICBjb252ZXJ0VHlwZUZvclRvb2x0aXAobmFtZTogc3RyaW5nLCB2YWx1ZTogbnVtYmVyKTogc3RyaW5nIHtcbiAgICAgICAgY29uc3QgZW50cnkgPSB0aGlzLmRldGVybWluZUNoYXJ0RW50cnkobmFtZSwgdmFsdWUpO1xuICAgICAgICBpZiAoZW50cnkpIHtcbiAgICAgICAgICAgIGNvbnN0IHR5cGUgPSBlbnRyeS5leGVyY2lzZVR5cGUudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgIGlmICh0eXBlID09PSAnZmlsZV91cGxvYWQnKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICdmaWxlLXVwbG9hZCc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdHlwZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIGlmIHRoZSBuYW1lIGFuZCB2YWx1ZSBpcyBub3QgdW5pcXVlLCB3ZSBjYW5ub3QgZGV0ZXJtaW5lIHRoZSB0eXBlXG4gICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXRzIHVwIGNoYXJ0IGxhYmVscywgdGhlIGRlZGljYXRlZCBvYmplY3RzIGluIG9yZGVyIHRvIHJlcHJlc2VudCB0aGUgZXhlcmNpc2VzIGJ5IG5neC1jaGFydHMgYW5kIHRoZSBiYXIgY29sb3JpbmdcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VNb2RlbHMgdGhlIG1vZGVscyByZXByZXNlbnRpbmcgdGhlIGNvdXJzZSBleGVyY2lzZXNcbiAgICAgKi9cbiAgICBwcml2YXRlIHNldHVwQ2hhcnQoZXhlcmNpc2VNb2RlbHM6IENvdXJzZU1hbmFnZW1lbnRTdGF0aXN0aWNzTW9kZWxbXSk6IHZvaWQge1xuICAgICAgICB0aGlzLmJhckNoYXJ0TGFiZWxzID0gZXhlcmNpc2VNb2RlbHMuc2xpY2UodGhpcy5jdXJyZW50UGVyaW9kLCAxMCArIHRoaXMuY3VycmVudFBlcmlvZCkubWFwKChleGVyY2lzZSkgPT4gZXhlcmNpc2UuZXhlcmNpc2VOYW1lKTtcbiAgICAgICAgdGhpcy5uZ3hEYXRhID0gZXhlcmNpc2VNb2RlbHMuc2xpY2UodGhpcy5jdXJyZW50UGVyaW9kLCAxMCArIHRoaXMuY3VycmVudFBlcmlvZCkubWFwKFxuICAgICAgICAgICAgKGV4ZXJjaXNlLCBpbmRleCkgPT5cbiAgICAgICAgICAgICAgICAoe1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiB0aGlzLmJhckNoYXJ0TGFiZWxzW2luZGV4XSxcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGV4ZXJjaXNlLmF2ZXJhZ2VTY29yZSxcbiAgICAgICAgICAgICAgICAgICAgZXhlcmNpc2VUeXBlOiBleGVyY2lzZS5leGVyY2lzZVR5cGUsXG4gICAgICAgICAgICAgICAgICAgIGV4ZXJjaXNlSWQ6IGV4ZXJjaXNlLmV4ZXJjaXNlSWQsXG4gICAgICAgICAgICAgICAgfSkgYXMgRXhlcmNpc2VTdGF0aXN0aWNzRW50cnksXG4gICAgICAgICk7XG4gICAgICAgIHRoaXMubmd4Q29sb3IuZG9tYWluID0gdGhpcy5uZ3hEYXRhLm1hcCgoZXhlcmNpc2UpID0+IHRoaXMuZGV0ZXJtaW5lQ29sb3IoZXhlcmNpc2UudmFsdWUpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXRzIHVwIHRoZSBjb2xvciBkaXN0cmlidXRpb24gZm9yIHRoZSBjaGFydCB0aGF0IGlzIGxhdGVyIG9uIHVzZWQgdG8gZGV0ZXJtaW5lIHRoZSBjb2xvciBmb3IgZXZlcnkgYmFyXG4gICAgICogVGhlIDMzJSBsb3dlc3QgcGVyZm9ybWluZyBleGVyY2lzZXMgYXJlIGNvbG9yZWQgcmVkLlxuICAgICAqIFRoZSAzMyUgYXZlcmFnZSBwZXJmb3JtaW5nIGV4ZXJjaXNlcyBhcmUgY29sb3JlZCBncmV5LlxuICAgICAqIFRoZSAzMyUgYmVzdCBwZXJmb3JtaW5nIGV4ZXJjaXNlcyBhcmUgY29sb3JlZCBncmVlbi5cbiAgICAgKiBUaGlzIG1ldGhvZCBvbmx5IGlkZW50aWZpZXMgdGhlIHRocmVzaG9sZCBzY29yZXMgZm9yIHRoZSBsb3dlc3QgYW5kIGhpZ2hlc3QgcGVyZm9ybWluZyBleGVyY2lzZXMuXG4gICAgICogVGhlc2UgYXJlIGV4Y2x1c2l2ZSwgd2hpY2ggbWVhbnMgdGhhdCBib3RoIGJvdW5kYXJ5IHZhbHVlcyBhcmUgZXhjbHVkZWQgYnkgdGhlIGxvd2VzdCBhbmQgYmVzdCB0aGlyZCBhY2NvcmRpbmdseVxuICAgICAqL1xuICAgIHByaXZhdGUgc2V0VXBDb2xvckRpc3RyaWJ1dGlvbigpOiB2b2lkIHtcbiAgICAgICAgaWYgKCF0aGlzLmV4ZXJjaXNlQXZlcmFnZVNjb3JlcyB8fCB0aGlzLmV4ZXJjaXNlQXZlcmFnZVNjb3Jlcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBhdmVyYWdlU2NvcmVzID0gdGhpcy5leGVyY2lzZUF2ZXJhZ2VTY29yZXMubWFwKChleGVyY2lzZSkgPT4gZXhlcmNpc2UuYXZlcmFnZVNjb3JlKTtcbiAgICAgICAgY29uc3QgdGhpcmRTaXplID0gTWF0aC5mbG9vcihhdmVyYWdlU2NvcmVzLmxlbmd0aCAvIDMpO1xuICAgICAgICBjb25zdCBoaWdoZXN0U2NvcmVJbkxvd2VzdFRoaXJkID0gYXZlcmFnZVNjb3Jlc1tNYXRoLm1heCh0aGlyZFNpemUgLSAxLCAwKV07XG4gICAgICAgIGNvbnN0IGFsbFNjb3Jlc0Fib3ZlTG93ZXN0VGhpcmQgPSBhdmVyYWdlU2NvcmVzLmZpbHRlcigoc2NvcmUpID0+IHNjb3JlID4gaGlnaGVzdFNjb3JlSW5Mb3dlc3RUaGlyZCk7XG4gICAgICAgIHRoaXMud2Vha2VzdFRoaXJkVXBwZXJCb3VuZGFyeSA9IGFsbFNjb3Jlc0Fib3ZlTG93ZXN0VGhpcmQubGVuZ3RoID4gMCA/IE1hdGgubWluKC4uLmFsbFNjb3Jlc0Fib3ZlTG93ZXN0VGhpcmQpIDogaGlnaGVzdFNjb3JlSW5Mb3dlc3RUaGlyZDtcbiAgICAgICAgY29uc3QgbG93ZXN0U2NvcmVJbkJlc3RUaGlyZCA9IGF2ZXJhZ2VTY29yZXNbTWF0aC5taW4oYXZlcmFnZVNjb3Jlcy5sZW5ndGggLSB0aGlyZFNpemUsIGF2ZXJhZ2VTY29yZXMubGVuZ3RoIC0gMSldO1xuICAgICAgICBjb25zdCBhbGxTY29yZXNCZWxvd0Jlc3RUaGlyZCA9IGF2ZXJhZ2VTY29yZXMuZmlsdGVyKChzY29yZSkgPT4gc2NvcmUgPCBsb3dlc3RTY29yZUluQmVzdFRoaXJkKTtcbiAgICAgICAgdGhpcy5iZXN0VGhpcmRMb3dlckJvdW5kYXJ5ID0gYWxsU2NvcmVzQmVsb3dCZXN0VGhpcmQubGVuZ3RoID4gMCA/IE1hdGgubWF4KC4uLmFsbFNjb3Jlc0JlbG93QmVzdFRoaXJkKSA6IGxvd2VzdFNjb3JlSW5CZXN0VGhpcmQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogV3JhcHBlciBtZXRob2QgdGhhdCBoYW5kbGVzIHRoZSBmaWx0ZXJpbmcgcGVyIGV4ZXJjaXNlIHR5cGUgYW5kIHNldHMgdXAgdGhlIGNoYXJ0IGFjY29yZGluZ2x5XG4gICAgICogQHBhcmFtIHR5cGUgdGhlIGV4ZXJjaXNlIHR5cGUgdGhhdCBpcyBmaWx0ZXJlZCBhZ2FpbnN0XG4gICAgICovXG4gICAgdG9nZ2xlVHlwZSh0eXBlOiBFeGVyY2lzZVR5cGUpOiB2b2lkIHtcbiAgICAgICAgY29uc3QgZmlsdGVyZWRBZ2FpbnN0VHlwZSA9IHRoaXMuZXhlcmNpc2VUeXBlRmlsdGVyLnRvZ2dsZUV4ZXJjaXNlVHlwZTxDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc01vZGVsPih0eXBlLCB0aGlzLmV4ZXJjaXNlU2NvcmVzRmlsdGVyZWRCeVBlcmZvcm1hbmNlSW50ZXJ2YWwpO1xuICAgICAgICBjb25zdCBmaWx0ZXJlZEFnYWluc3RDYXRlZ29yeSA9IHRoaXMuY2hhcnRDYXRlZ29yeUZpbHRlci5hcHBseUN1cnJlbnRGaWx0ZXI8Q291cnNlTWFuYWdlbWVudFN0YXRpc3RpY3NNb2RlbD4odGhpcy5leGVyY2lzZVNjb3Jlc0ZpbHRlcmVkQnlQZXJmb3JtYW5jZUludGVydmFsKTtcbiAgICAgICAgdGhpcy5pbml0aWFsaXplQ2hhcnRXaXRoRmlsdGVyKGZpbHRlcmVkQWdhaW5zdENhdGVnb3J5LCBmaWx0ZXJlZEFnYWluc3RUeXBlKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBQZXJmb3JtcyBhIGZpbHRlcmluZyBmb3IgYSBwZXJmb3JtYW5jZSBpbnRlcnZhbCAobGVnZW5kIGVudHJ5KS5cbiAgICAgKiBJZiBhbGwgaW50ZXJ2YWxzIGFyZSBjdXJyZW50bHkgZGlzcGxheWVkIGFuZCBvbmUgaXMgY2xpY2tlZCwgZm9yIHRoaXMgaW50ZXJ2YWwgaXMgZmlsdGVyZWQuXG4gICAgICogSWYgYSBkaXNhYmxlZCBpbnRlcnZhbCBpcyBjbGlja2VkLCB0aGlzIGludGVydmFsIGlzIGFkZGVkIHRvIHRoZSBmaWx0ZXIuXG4gICAgICogQHBhcmFtIGludGVydmFsIHRoZSBpbnRlcnZhbCB0aGF0IGlzIHNlbGVjdGVkXG4gICAgICovXG4gICAgdG9nZ2xlUGVyZm9ybWFuY2VJbnRlcnZhbChpbnRlcnZhbDogUGVyZm9ybWFuY2VJbnRlcnZhbCk6IHZvaWQge1xuICAgICAgICBjb25zdCBjdXJyZW50VmFsdWUgPSB0aGlzLmRpc3BsYXlDb2xvck1hcC5nZXQoaW50ZXJ2YWwpO1xuICAgICAgICAvLyB3ZSByZXNldCB0aGUgdmlldyBvZiB0aGUgY2hhcnQgKGNoYW5nZWQgd2l0aCB0aGUgYXJyb3dzKSBiZWZvcmUgZGlzcGxheWluZyB0aGUgZmlsdGVyZWQgZXhlcmNpc2VzXG4gICAgICAgIHRoaXMuY3VycmVudFBlcmlvZCA9IDA7XG4gICAgICAgIGxldCBuZXdWYWx1ZSA9ICcnO1xuICAgICAgICAvLyBUaGlzIG1lYW5zIGFuIGludGVydmFsIGlzIHNlbGVjdGVkIHRoYXQgaXMgY3VycmVudGx5IGFscmVhZHkgZGlzcGxheWVkXG4gICAgICAgIGlmIChjdXJyZW50VmFsdWUgIT09ICcnKSB7XG4gICAgICAgICAgICAvLyBpZiBvbmx5IHRoaXMgaW50ZXJ2YWwgaXMgc2VsZWN0ZWQsIHJlc2VsZWN0aW5nIGl0IGxlYWRzIHRvIHNlbGVjdGluZyBhbGwgaW50ZXJ2YWxzXG4gICAgICAgICAgICBpZiAodGhpcy5udW1iZXJPZlNlbGVjdGVkSW50ZXJ2YWxzID09PSAxKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5pbmNsdWRlQWxsSW50ZXJ2YWxzKCk7XG4gICAgICAgICAgICAgICAgdGhpcy5leGVyY2lzZVNjb3Jlc0ZpbHRlcmVkQnlQZXJmb3JtYW5jZUludGVydmFsID0gdGhpcy5vcmRlckF2ZXJhZ2VTY29yZXModGhpcy5leGVyY2lzZUF2ZXJhZ2VTY29yZXMpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLmRlc2VsZWN0QWxsT3RoZXJJbnRlcnZhbHMoaW50ZXJ2YWwpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5pbml0aWFsaXplRmlsdGVyT3B0aW9uc0FuZFNldHVwQ2hhcnRXaXRoQ3VycmVudFZpc2libGVTY29yZXMoKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBzd2l0Y2ggKGludGVydmFsKSB7XG4gICAgICAgICAgICBjYXNlIFBlcmZvcm1hbmNlSW50ZXJ2YWwuTE9XRVNUOiB7XG4gICAgICAgICAgICAgICAgbmV3VmFsdWUgPSB0aGlzLkNSSVRJQ0FMX0NMQVNTO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBQZXJmb3JtYW5jZUludGVydmFsLkFWRVJBR0U6IHtcbiAgICAgICAgICAgICAgICBuZXdWYWx1ZSA9IHRoaXMuTUVESUFOX0NMQVNTO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBQZXJmb3JtYW5jZUludGVydmFsLkJFU1Q6IHtcbiAgICAgICAgICAgICAgICBuZXdWYWx1ZSA9IHRoaXMuQkVTVF9DTEFTUztcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBUaGlzIG1hcCBkZXRlcm1pbmVzIHdoZXRoZXIgdGhlIGNvbG9yIGxlZ2VuZCBuZXh0IHRvIGEgY2hhcnQgZW50cnkgaXMgY29sb3JlZCBvciBub3QgcmVwcmVzZW50aW5nIHdoZXRoZXIgdGhpcyBlbnRyeSBpcyBjdXJyZW50bHkgdmlzaWJsZSBpbiB0aGUgY2hhcnQgb3Igbm90XG4gICAgICAgIHRoaXMuZGlzcGxheUNvbG9yTWFwLnNldChpbnRlcnZhbCwgbmV3VmFsdWUpO1xuICAgICAgICB0aGlzLm51bWJlck9mU2VsZWN0ZWRJbnRlcnZhbHMgKz0gMTtcbiAgICAgICAgY29uc3QgZXhlcmNpc2VzID0gdGhpcy5maWx0ZXJGb3JQZXJmb3JtYW5jZUludGVydmFsKGludGVydmFsKTtcbiAgICAgICAgdGhpcy5leGVyY2lzZVNjb3Jlc0ZpbHRlcmVkQnlQZXJmb3JtYW5jZUludGVydmFsID0gdGhpcy5vcmRlckF2ZXJhZ2VTY29yZXModGhpcy5leGVyY2lzZVNjb3Jlc0ZpbHRlcmVkQnlQZXJmb3JtYW5jZUludGVydmFsLmNvbmNhdChleGVyY2lzZXMpKTtcbiAgICAgICAgdGhpcy5pbml0aWFsaXplRmlsdGVyT3B0aW9uc0FuZFNldHVwQ2hhcnRXaXRoQ3VycmVudFZpc2libGVTY29yZXMoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBBdXhpbGlhcnkgbWV0aG9kIHRoYXQgaWRlbnRpZmllcyB0aGUgZXhlcmNpc2VzIGNvbnRhaW5lZCBieSB0aGUgcGFzc2VkIGludGVydmFsXG4gICAgICogQHBhcmFtIGludGVydmFsIHRoZSBpbnRlcnZhbCB0aGUgZXhlcmNpc2VzIHNob3VsZCBiZSBmaWx0ZXJlZCBhZ2FpbnN0XG4gICAgICovXG4gICAgcHJpdmF0ZSBmaWx0ZXJGb3JQZXJmb3JtYW5jZUludGVydmFsKGludGVydmFsOiBQZXJmb3JtYW5jZUludGVydmFsKSB7XG4gICAgICAgIGxldCBmaWx0ZXJGdW5jdGlvbjtcbiAgICAgICAgc3dpdGNoIChpbnRlcnZhbCkge1xuICAgICAgICAgICAgY2FzZSBQZXJmb3JtYW5jZUludGVydmFsLkxPV0VTVDoge1xuICAgICAgICAgICAgICAgIGZpbHRlckZ1bmN0aW9uID0gKG1vZGVsOiBDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc01vZGVsKSA9PiBtb2RlbC5hdmVyYWdlU2NvcmUgPCB0aGlzLndlYWtlc3RUaGlyZFVwcGVyQm91bmRhcnk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIFBlcmZvcm1hbmNlSW50ZXJ2YWwuQVZFUkFHRToge1xuICAgICAgICAgICAgICAgIGZpbHRlckZ1bmN0aW9uID0gKG1vZGVsOiBDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc01vZGVsKSA9PlxuICAgICAgICAgICAgICAgICAgICBtb2RlbC5hdmVyYWdlU2NvcmUgPj0gdGhpcy53ZWFrZXN0VGhpcmRVcHBlckJvdW5kYXJ5ICYmIG1vZGVsLmF2ZXJhZ2VTY29yZSA8PSB0aGlzLmJlc3RUaGlyZExvd2VyQm91bmRhcnk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIFBlcmZvcm1hbmNlSW50ZXJ2YWwuQkVTVDoge1xuICAgICAgICAgICAgICAgIGZpbHRlckZ1bmN0aW9uID0gKG1vZGVsOiBDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc01vZGVsKSA9PiBtb2RlbC5hdmVyYWdlU2NvcmUgPiB0aGlzLmJlc3RUaGlyZExvd2VyQm91bmRhcnk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuZXhlcmNpc2VBdmVyYWdlU2NvcmVzLmZpbHRlcihmaWx0ZXJGdW5jdGlvbik7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQXV4aWxpYXJ5IG1ldGhvZCByZWR1Y2luZyBjb2RlIGR1cGxpY2F0aW9uIGZvciBzb3J0aW5nIHRoZSBtb2RlbCBhcnJheSBhc2NlbmRpbmcgaW4gaXRzIGF2ZXJhZ2VTY29yZXNcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VNb2RlbHMgdGhlIGFycmF5IHRoYXQgc2hvdWxkIGJlIG9yZGVyZWRcbiAgICAgKi9cbiAgICBwcml2YXRlIG9yZGVyQXZlcmFnZVNjb3JlcyhleGVyY2lzZU1vZGVsczogQ291cnNlTWFuYWdlbWVudFN0YXRpc3RpY3NNb2RlbFtdKTogQ291cnNlTWFuYWdlbWVudFN0YXRpc3RpY3NNb2RlbFtdIHtcbiAgICAgICAgcmV0dXJuIGV4ZXJjaXNlTW9kZWxzLnNvcnQoKGV4ZXJjaXNlMSwgZXhlcmNpc2UyKSA9PiBleGVyY2lzZTEuYXZlcmFnZVNjb3JlIC0gZXhlcmNpc2UyLmF2ZXJhZ2VTY29yZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQXV4aWxpYXJ5IG1ldGhvZCByZWR1Y2luZyBjb2RlIGR1cGxpY2F0aW9uIGZvciBpbml0aWFsaXppbmcgdGhlIGNoYXJ0IGFmdGVyIGEgcGVyZm9ybWFuY2UgaW50ZXJ2YWwgaGFzIGJlZW4gc2VsZWN0ZWRcbiAgICAgKi9cbiAgICBwcml2YXRlIGluaXRpYWxpemVGaWx0ZXJPcHRpb25zQW5kU2V0dXBDaGFydFdpdGhDdXJyZW50VmlzaWJsZVNjb3JlcygpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5leGVyY2lzZVR5cGVGaWx0ZXIuaW5pdGlhbGl6ZUZpbHRlck9wdGlvbnModGhpcy5leGVyY2lzZVNjb3Jlc0ZpbHRlcmVkQnlQZXJmb3JtYW5jZUludGVydmFsKTtcbiAgICAgICAgdGhpcy5jaGFydENhdGVnb3J5RmlsdGVyLnNldHVwQ2F0ZWdvcnlGaWx0ZXIodGhpcy5leGVyY2lzZVNjb3Jlc0ZpbHRlcmVkQnlQZXJmb3JtYW5jZUludGVydmFsKTtcbiAgICAgICAgdGhpcy5zZXR1cENoYXJ0KHRoaXMuZXhlcmNpc2VTY29yZXNGaWx0ZXJlZEJ5UGVyZm9ybWFuY2VJbnRlcnZhbCk7XG4gICAgICAgIHRoaXMuY3VycmVudGx5RGlzcGxheWFibGVFeGVyY2lzZXMgPSB0aGlzLmV4ZXJjaXNlU2NvcmVzRmlsdGVyZWRCeVBlcmZvcm1hbmNlSW50ZXJ2YWw7XG4gICAgICAgIHRoaXMuY3VycmVudFNpemUgPSB0aGlzLmV4ZXJjaXNlU2NvcmVzRmlsdGVyZWRCeVBlcmZvcm1hbmNlSW50ZXJ2YWwubGVuZ3RoO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNldHMgYWxsIHBlcmZvcm1hbmNlIGludGVydmFscyB0byB2aXNpYmxlXG4gICAgICovXG4gICAgcHJpdmF0ZSBpbmNsdWRlQWxsSW50ZXJ2YWxzKCk6IHZvaWQge1xuICAgICAgICB0aGlzLmRpc3BsYXlDb2xvck1hcC5zZXQoUGVyZm9ybWFuY2VJbnRlcnZhbC5MT1dFU1QsIHRoaXMuQ1JJVElDQUxfQ0xBU1MpO1xuICAgICAgICB0aGlzLmRpc3BsYXlDb2xvck1hcC5zZXQoUGVyZm9ybWFuY2VJbnRlcnZhbC5BVkVSQUdFLCB0aGlzLk1FRElBTl9DTEFTUyk7XG4gICAgICAgIHRoaXMuZGlzcGxheUNvbG9yTWFwLnNldChQZXJmb3JtYW5jZUludGVydmFsLkJFU1QsIHRoaXMuQkVTVF9DTEFTUyk7XG4gICAgICAgIHRoaXMubnVtYmVyT2ZTZWxlY3RlZEludGVydmFscyA9IDM7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGVzZWxlY3RzIGFsbCBwZXJmb3JtYW5jZSBpbnRlcnZhbHMgZXhjZXB0IHRoZSBwYXNzZWQgb25lXG4gICAgICogQHBhcmFtIGludGVydmFsIHRoZSBpbnRlcnZhbCB0aGF0IHNob3VsZCBub3QgYmUgZGVzZWxlY3RlZFxuICAgICAqL1xuICAgIHByaXZhdGUgZGVzZWxlY3RBbGxPdGhlckludGVydmFscyhpbnRlcnZhbDogUGVyZm9ybWFuY2VJbnRlcnZhbCk6IHZvaWQge1xuICAgICAgICB0aGlzLnBlcmZvcm1hbmNlSW50ZXJ2YWxzLmZvckVhY2goKHBpKSA9PiB7XG4gICAgICAgICAgICBpZiAocGkgIT09IGludGVydmFsKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5kaXNwbGF5Q29sb3JNYXAuc2V0KHBpLCAnJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLm51bWJlck9mU2VsZWN0ZWRJbnRlcnZhbHMgPSAxO1xuICAgICAgICB0aGlzLmV4ZXJjaXNlU2NvcmVzRmlsdGVyZWRCeVBlcmZvcm1hbmNlSW50ZXJ2YWwgPSB0aGlzLmZpbHRlckZvclBlcmZvcm1hbmNlSW50ZXJ2YWwoaW50ZXJ2YWwpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFdyYXBwZXIgbWV0aG9kIHRoYXQgaGFuZGxlcyB0aGUgdG9nZ2xpbmcgb2YgYSBjYXRlZ29yeSBhbmQgc2V0cyB1cCB0aGUgY2hhcnQgYWNjb3JkaW5nbHlcbiAgICAgKiBAcGFyYW0gY2F0ZWdvcnkgdGhlIGNhdGVnb3J5IHRoZSB1c2VyIHNlbGVjdHMgb3IgZGVzZWxlY3RzXG4gICAgICovXG4gICAgdG9nZ2xlQ2F0ZWdvcnkoY2F0ZWdvcnk6IHN0cmluZyk6IHZvaWQge1xuICAgICAgICBjb25zdCBmaWx0ZXJlZEFnYWluc3RDYXRlZ29yeSA9IHRoaXMuY2hhcnRDYXRlZ29yeUZpbHRlci50b2dnbGVDYXRlZ29yeTxDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc01vZGVsPih0aGlzLmV4ZXJjaXNlU2NvcmVzRmlsdGVyZWRCeVBlcmZvcm1hbmNlSW50ZXJ2YWwsIGNhdGVnb3J5KTtcbiAgICAgICAgY29uc3QgZmlsdGVyZWRBZ2FpbnN0VHlwZSA9IHRoaXMuZXhlcmNpc2VUeXBlRmlsdGVyLmFwcGx5Q3VycmVudEZpbHRlcjxDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc01vZGVsPih0aGlzLmV4ZXJjaXNlU2NvcmVzRmlsdGVyZWRCeVBlcmZvcm1hbmNlSW50ZXJ2YWwpO1xuICAgICAgICB0aGlzLmluaXRpYWxpemVDaGFydFdpdGhGaWx0ZXIoZmlsdGVyZWRBZ2FpbnN0Q2F0ZWdvcnksIGZpbHRlcmVkQWdhaW5zdFR5cGUpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFdyYXBwZXIgbWV0aG9kIHRoYXQgaGFuZGxlcyB0aGUgdG9nZ2xpbmcgb2YgYWxsIGNhdGVnb3JpZXMgYW5kIHNldHMgdXAgdGhlIGNoYXJ0IGFjY29yZGluZ2x5XG4gICAgICovXG4gICAgdG9nZ2xlQWxsQ2F0ZWdvcmllcygpOiB2b2lkIHtcbiAgICAgICAgY29uc3QgZmlsdGVyZWRBZ2FpbnN0Q2F0ZWdvcnkgPSB0aGlzLmNoYXJ0Q2F0ZWdvcnlGaWx0ZXIudG9nZ2xlQWxsQ2F0ZWdvcmllczxDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc01vZGVsPih0aGlzLmV4ZXJjaXNlU2NvcmVzRmlsdGVyZWRCeVBlcmZvcm1hbmNlSW50ZXJ2YWwpO1xuICAgICAgICBjb25zdCBmaWx0ZXJlZEFnYWluc3RUeXBlID0gdGhpcy5leGVyY2lzZVR5cGVGaWx0ZXIuYXBwbHlDdXJyZW50RmlsdGVyPENvdXJzZU1hbmFnZW1lbnRTdGF0aXN0aWNzTW9kZWw+KHRoaXMuZXhlcmNpc2VTY29yZXNGaWx0ZXJlZEJ5UGVyZm9ybWFuY2VJbnRlcnZhbCk7XG4gICAgICAgIHRoaXMuaW5pdGlhbGl6ZUNoYXJ0V2l0aEZpbHRlcihmaWx0ZXJlZEFnYWluc3RDYXRlZ29yeSwgZmlsdGVyZWRBZ2FpbnN0VHlwZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogV3JhcHBlciBtZXRob2QgdGhhdCBoYW5kbGVzIHRoZSB0b2dnbGluZyBvZiBleGVyY2lzZXMgd2l0aCBubyBjYXRlZ29yaWVzIGFuZCBzZXRzIHVwIHRoZSBjaGFydCBhY2NvcmRpbmdseVxuICAgICAqL1xuICAgIHRvZ2dsZUV4ZXJjaXNlc1dpdGhOb0NhdGVnb3J5KCk6IHZvaWQge1xuICAgICAgICBjb25zdCBmaWx0ZXJlZEFnYWluc3RDYXRlZ29yeSA9IHRoaXMuY2hhcnRDYXRlZ29yeUZpbHRlci50b2dnbGVFeGVyY2lzZXNXaXRoTm9DYXRlZ29yeTxDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc01vZGVsPih0aGlzLmV4ZXJjaXNlU2NvcmVzRmlsdGVyZWRCeVBlcmZvcm1hbmNlSW50ZXJ2YWwpO1xuICAgICAgICBjb25zdCBmaWx0ZXJlZEFnYWluc3RUeXBlID0gdGhpcy5leGVyY2lzZVR5cGVGaWx0ZXIuYXBwbHlDdXJyZW50RmlsdGVyPENvdXJzZU1hbmFnZW1lbnRTdGF0aXN0aWNzTW9kZWw+KHRoaXMuZXhlcmNpc2VTY29yZXNGaWx0ZXJlZEJ5UGVyZm9ybWFuY2VJbnRlcnZhbCk7XG4gICAgICAgIHRoaXMuaW5pdGlhbGl6ZUNoYXJ0V2l0aEZpbHRlcihmaWx0ZXJlZEFnYWluc3RDYXRlZ29yeSwgZmlsdGVyZWRBZ2FpbnN0VHlwZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQXV4aWxpYXJ5IG1ldGhvZCB0byByZWR1Y2UgY29kZSBkdXBsaWNhdGlvbi5cbiAgICAgKiBTZXRzIHRoZSBjdXJyZW50UGVyaW9kIHRvIHplcm8sIGRldGVybWluZXMgdGhlIG51bWJlciBvZiBkaXNwbGF5YWJsZSBiYXJzIGFuZCB1cGRhdGVzIHRoZSBjaGFydC5cbiAgICAgKiBAcGFyYW0gZmlsdGVyZWRBZ2FpbnN0Q2F0ZWdvcnkgdGhlIHNjb3JlcyBmaWx0ZXJlZCBhZ2FpbnN0IHRoZSBjdXJyZW50IGNhdGVnb3J5IGZpbHRlciBzZXR0aW5nXG4gICAgICogQHBhcmFtIGZpbHRlcmVkQWdhaW5zdFR5cGUgdGhlIHNjb3JlcyBmaWx0ZXJlZCBhZ2FpbnN0IHRoZSBjdXJyZW50IHR5cGUgZmlsdGVyIHNldHRpbmdcbiAgICAgKi9cbiAgICBwcml2YXRlIGluaXRpYWxpemVDaGFydFdpdGhGaWx0ZXIoZmlsdGVyZWRBZ2FpbnN0Q2F0ZWdvcnk6IENvdXJzZU1hbmFnZW1lbnRTdGF0aXN0aWNzTW9kZWxbXSwgZmlsdGVyZWRBZ2FpbnN0VHlwZTogQ291cnNlTWFuYWdlbWVudFN0YXRpc3RpY3NNb2RlbFtdKTogdm9pZCB7XG4gICAgICAgIHRoaXMuY3VycmVudGx5RGlzcGxheWFibGVFeGVyY2lzZXMgPSB0aGlzLm9yZGVyQXZlcmFnZVNjb3JlcyhmaWx0ZXJlZEFnYWluc3RDYXRlZ29yeS5maWx0ZXIoKHNjb3JlKSA9PiBmaWx0ZXJlZEFnYWluc3RUeXBlLmluY2x1ZGVzKHNjb3JlKSkpO1xuICAgICAgICB0aGlzLmN1cnJlbnRQZXJpb2QgPSAwO1xuICAgICAgICB0aGlzLnNldHVwQ2hhcnQodGhpcy5jdXJyZW50bHlEaXNwbGF5YWJsZUV4ZXJjaXNlcyk7XG4gICAgICAgIHRoaXMuY3VycmVudFNpemUgPSB0aGlzLmN1cnJlbnRseURpc3BsYXlhYmxlRXhlcmNpc2VzLmxlbmd0aDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBBcHBlbmRzIGEgcGVyY2VudGFnZSBzaWduIHRvIGV2ZXJ5IGRhdGEgbGFiZWwgb2YgdGhlIGNoYXJ0XG4gICAgICogQHBhcmFtIGF2ZXJhZ2VTY29yZSB0aGUgc2NvcmUgdGhhdCBpcyBkaXNwbGF5ZWQgYnkgdGhlIGRhdGEgbGFiZWxcbiAgICAgKi9cbiAgICBmb3JtYXREYXRhTGFiZWwoYXZlcmFnZVNjb3JlOiBudW1iZXIpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gYXZlcmFnZVNjb3JlICsgJyUnO1xuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJyb3cgbWItMyBkLWZsZXgganVzdGlmeS1jb250ZW50LWNlbnRlclwiPlxuICAgIDxkaXYgY2xhc3M9XCJjb2wteGwtMSBkLWZsZXggZmxleC1jb2x1bW5cIj5cbiAgICAgICAgPGgzPnt7ICdhcnRlbWlzQXBwLmNvdXJzZS5hdmVyYWdlU2NvcmUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvaDM+XG4gICAgICAgIDxoND57eyAnYXJ0ZW1pc0FwcC5jb3Vyc2VTdGF0aXN0aWNzLmNvdXJzZUF2ZXJhZ2UnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fToge3sgY291cnNlQXZlcmFnZSB9fSU8L2g0PlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJyb3cgY29sLXhsLTExIGNoYXJ0LXJvd1wiPlxuICAgICAgICA8ZmEtaWNvblxuICAgICAgICAgICAgW2ljb25dPVwiZmFBcnJvd0xlZnRcIlxuICAgICAgICAgICAgc2l6ZT1cIjJ4XCJcbiAgICAgICAgICAgIGNsYXNzPVwiY29sLTEgZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNvbnRlbnQtZW5kXCJcbiAgICAgICAgICAgIHJvbGU9XCJidXR0b25cIlxuICAgICAgICAgICAgKGNsaWNrKT1cInN3aXRjaFRpbWVTcGFuKExFRlQpXCJcbiAgICAgICAgICAgIFtjbGFzcy5oaWRkZW5dPVwiIShjdXJyZW50U2l6ZSA+IG1heFNwYW5TaXplICYmIGN1cnJlbnRQZXJpb2QgPiAwKVwiXG4gICAgICAgID48L2ZhLWljb24+XG4gICAgICAgIDxkaXYgI2NvbnRhaW5lclJlZiBjbGFzcz1cImNvbC1sZy04IHBzLTAgY2hhcnQtY29udGFpbmVyXCI+XG4gICAgICAgICAgICA8bmd4LWNoYXJ0cy1iYXItdmVydGljYWxcbiAgICAgICAgICAgICAgICBbcm91bmRFZGdlc109XCJmYWxzZVwiXG4gICAgICAgICAgICAgICAgW3ZpZXddPVwiW2NvbnRhaW5lclJlZi5vZmZzZXRXaWR0aCwgMzAwXVwiXG4gICAgICAgICAgICAgICAgW3Jlc3VsdHNdPVwibmd4RGF0YVwiXG4gICAgICAgICAgICAgICAgW3NjaGVtZV09XCJuZ3hDb2xvclwiXG4gICAgICAgICAgICAgICAgW3lTY2FsZU1heF09XCIxMDBcIlxuICAgICAgICAgICAgICAgIFt4QXhpc109XCJ0cnVlXCJcbiAgICAgICAgICAgICAgICBbeUF4aXNdPVwidHJ1ZVwiXG4gICAgICAgICAgICAgICAgW3lBeGlzVGlja0Zvcm1hdHRpbmddPVwieUF4aXNUaWNrRm9ybWF0dGluZ1wiXG4gICAgICAgICAgICAgICAgW2RhdGFMYWJlbEZvcm1hdHRpbmddPVwiZm9ybWF0RGF0YUxhYmVsXCJcbiAgICAgICAgICAgICAgICBbc2hvd0RhdGFMYWJlbF09XCJ0cnVlXCJcbiAgICAgICAgICAgICAgICAoc2VsZWN0KT1cIm9uU2VsZWN0KCRldmVudClcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSAjdG9vbHRpcFRlbXBsYXRlIGxldC1tb2RlbD1cIm1vZGVsXCI+XG4gICAgICAgICAgICAgICAgICAgIDxiPnt7IG1vZGVsLm5hbWUgfX08L2I+IDxiciAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAnYXJ0ZW1pc0FwcC5jb3Vyc2VTdGF0aXN0aWNzLmV4ZXJjaXNlQXZlcmFnZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19OiB7eyBtb2RlbC52YWx1ZSB9fSU8L3NwYW4+IDxiciAvPlxuICAgICAgICAgICAgICAgICAgICA8YlxuICAgICAgICAgICAgICAgICAgICAgICAgPnt7ICdhcnRlbWlzQXBwLmNvdXJzZVN0YXRpc3RpY3MuZXhlcmNpc2VUeXBlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX06XG4gICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5jb3Vyc2VTdGF0aXN0aWNzLicgKyBjb252ZXJ0VHlwZUZvclRvb2x0aXAobW9kZWwubmFtZSwgbW9kZWwudmFsdWUpIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvYlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgIDwvbmd4LWNoYXJ0cy1iYXItdmVydGljYWw+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZmEtaWNvblxuICAgICAgICAgICAgW2ljb25dPVwiZmFBcnJvd1JpZ2h0XCJcbiAgICAgICAgICAgIHNpemU9XCIyeFwiXG4gICAgICAgICAgICBjbGFzcz1cImNvbC0xIGQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIgc3dpdGNoLWZvcndhcmRcIlxuICAgICAgICAgICAgcm9sZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAoY2xpY2spPVwic3dpdGNoVGltZVNwYW4oUklHSFQpXCJcbiAgICAgICAgICAgIFtjbGFzcy5oaWRkZW5dPVwiIShjdXJyZW50U2l6ZSA+IG1heFNwYW5TaXplICsgY3VycmVudFBlcmlvZClcIlxuICAgICAgICA+PC9mYS1pY29uPlxuICAgICAgICA8bmctdGVtcGxhdGUgI3BsYWNlaG9sZGVyPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN3aXRjaC1mb3J3YXJkLXBsYWNlaG9sZGVyXCI+PC9kaXY+XG4gICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtbGctMiBkLWZsZXggZmxleC1jb2x1bW4gYWxpZ24taXRlbXMtY2VudGVyIGp1c3RpZnktY29udGVudC1jZW50ZXJcIj5cbiAgICAgICAgICAgIEBpZiAoZXhlcmNpc2VUeXBlRmlsdGVyLnR5cGVTZXQuc2l6ZSA+IDApIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmlsdGVyIG15LTNcIiBhcmlhLWxhYmVsPVwiRmlsdGVyIERyb3Bkb3duXCIgbmdiRHJvcGRvd24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYnRuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5idG4tc2Vjb25kYXJ5XT1cIiEoY2hhcnRDYXRlZ29yeUZpbHRlci5udW1iZXJPZkFjdGl2ZUZpbHRlcnMgKyBleGVyY2lzZVR5cGVGaWx0ZXIubnVtYmVyT2ZBY3RpdmVGaWx0ZXJzKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYnRuLXN1Y2Nlc3NdPVwiY2hhcnRDYXRlZ29yeUZpbHRlci5udW1iZXJPZkFjdGl2ZUZpbHRlcnMgKyBleGVyY2lzZVR5cGVGaWx0ZXIubnVtYmVyT2ZBY3RpdmVGaWx0ZXJzID4gMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBuZ2JEcm9wZG93blRvZ2dsZVxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJmaWx0ZXItZHJvcGRvd24tYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFGaWx0ZXJcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlTGlzdC5maWx0ZXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHwgYXJ0ZW1pc1RyYW5zbGF0ZTogeyBudW06IGV4ZXJjaXNlVHlwZUZpbHRlci5udW1iZXJPZkFjdGl2ZUZpbHRlcnMgKyBjaGFydENhdGVnb3J5RmlsdGVyLm51bWJlck9mQWN0aXZlRmlsdGVycyB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDx1bCBuZ2JEcm9wZG93bk1lbnUgY2xhc3M9XCJjaGVja2JveC1tZW51IHRleHQtbm93cmFwIHBlLTJcIiBhcmlhLWxhYmVsbGVkYnk9XCJmaWx0ZXItZHJvcGRvd24tYnV0dG9uXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGV4ZXJjaXNlVHlwZUZpbHRlci50eXBlU2V0LnNpemUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiIGNsYXNzPVwibXMtMlwiPnt7ICdhcnRlbWlzQXBwLmV4ZXJjaXNlLXNjb3Jlcy1jaGFydC5pbmNsdWRlVHlwZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9iPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBAZm9yICh0eXBlIG9mIGV4ZXJjaXNlVHlwZUZpbHRlci50eXBlU2V0OyB0cmFjayB0eXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cIm1zLTIgZm9ybS1jaGVjay1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNoYW5nZSk9XCJ0b2dnbGVUeXBlKHR5cGUpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2hlY2tlZF09XCJleGVyY2lzZVR5cGVGaWx0ZXIuZ2V0Q3VycmVudEZpbHRlclN0YXRlKGNvbnZlcnRUb01hcEtleSh0eXBlKSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJtcy0yXCI+e3sgJ2FydGVtaXNBcHAuZXhlcmNpc2Utc2NvcmVzLWNoYXJ0LicgKyB0eXBlLnRvTG93ZXJDYXNlKCkgKyAnUGx1cmFsJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzcz1cIm10LTEgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiIGNsYXNzPVwibXMtMlwiPnt7ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LnN0YXRpc3RpY3MuaW5jbHVkZUluZGl2aWR1YWxDYXRlZ29yaWVzJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2I+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cIm1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IGNsYXNzPVwibXMtMiBmb3JtLWNoZWNrLWlucHV0XCIgKGNoYW5nZSk9XCJ0b2dnbGVBbGxDYXRlZ29yaWVzKClcIiBbY2hlY2tlZF09XCJjaGFydENhdGVnb3J5RmlsdGVyLmFsbENhdGVnb3JpZXNTZWxlY3RlZFwiIHR5cGU9XCJjaGVja2JveFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiIGNsYXNzPVwibXMtMlwiPnt7ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LnN0YXRpc3RpY3MuaW5jbHVkZUFsbENhdGVnb3JpZXMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvYj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY2hhcnRDYXRlZ29yeUZpbHRlci5leGVyY2lzZXNXaXRob3V0Q2F0ZWdvcmllc1ByZXNlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwibXMtMiBmb3JtLWNoZWNrLWlucHV0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2hhbmdlKT1cInRvZ2dsZUV4ZXJjaXNlc1dpdGhOb0NhdGVnb3J5KClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjaGVja2VkXT1cImNoYXJ0Q2F0ZWdvcnlGaWx0ZXIuaW5jbHVkZUV4ZXJjaXNlc1dpdGhOb0NhdGVnb3J5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibXMtMlwiPnt7ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LnN0YXRpc3RpY3MuZXhlcmNpc2VzV2l0aE5vQ2F0ZWdvcmllcycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBAZm9yIChjYXRlZ29yeSBvZiBjaGFydENhdGVnb3J5RmlsdGVyLmV4ZXJjaXNlQ2F0ZWdvcmllczsgdHJhY2sgY2F0ZWdvcnkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwibXMtMiBmb3JtLWNoZWNrLWlucHV0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2hhbmdlKT1cInRvZ2dsZUNhdGVnb3J5KGNhdGVnb3J5KVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NoZWNrZWRdPVwiY2hhcnRDYXRlZ29yeUZpbHRlci5nZXRDdXJyZW50RmlsdGVyU3RhdGUoY2F0ZWdvcnkpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibXMtMlwiPnt7IGNhdGVnb3J5IH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsZWdlbmQtY29udGFpbmVyXCI+XG4gICAgICAgICAgICAgICAgICAgIEBmb3IgKGludGVydmFsIG9mIHBlcmZvcm1hbmNlSW50ZXJ2YWxzOyB0cmFjayBpbnRlcnZhbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxlZ2VuZC1lbnRyeVwiIChjbGljayk9XCJ0b2dnbGVQZXJmb3JtYW5jZUludGVydmFsKGludGVydmFsKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2xvci1sZWdlbmRcIiBbbmdDbGFzc109XCJkaXNwbGF5Q29sb3JNYXAuZ2V0KGludGVydmFsKSFcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAnYXJ0ZW1pc0FwcC5jb3Vyc2VTdGF0aXN0aWNzLmNoYXJ0TGVnZW5kLicgKyBpbnRlcnZhbCB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRG91Z2hudXRDaGFydENvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3N0YXRpc3RpY3MvZG91Z2hudXQtY2hhcnQuY29tcG9uZW50JztcbmltcG9ydCB7IFN0YXRpc3RpY3NBdmVyYWdlU2NvcmVHcmFwaENvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvc3RhdGlzdGljcy1ncmFwaC9zdGF0aXN0aWNzLWF2ZXJhZ2Utc2NvcmUtZ3JhcGguY29tcG9uZW50JztcbmltcG9ydCB7IFN0YXRpc3RpY3NHcmFwaENvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvc3RhdGlzdGljcy1ncmFwaC9zdGF0aXN0aWNzLWdyYXBoLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBTdGF0aXN0aWNzU2NvcmVEaXN0cmlidXRpb25HcmFwaENvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvc3RhdGlzdGljcy1ncmFwaC9zdGF0aXN0aWNzLXNjb3JlLWRpc3RyaWJ1dGlvbi1ncmFwaC5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBSb3V0ZXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgQmFyQ2hhcnRNb2R1bGUsIExpbmVDaGFydE1vZHVsZSwgUGllQ2hhcnRNb2R1bGUgfSBmcm9tICdAc3dpbWxhbmUvbmd4LWNoYXJ0cyc7XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW0FydGVtaXNTaGFyZWRNb2R1bGUsIFJvdXRlck1vZHVsZSwgQmFyQ2hhcnRNb2R1bGUsIExpbmVDaGFydE1vZHVsZSwgUGllQ2hhcnRNb2R1bGVdLFxuICAgIGRlY2xhcmF0aW9uczogW0RvdWdobnV0Q2hhcnRDb21wb25lbnQsIFN0YXRpc3RpY3NBdmVyYWdlU2NvcmVHcmFwaENvbXBvbmVudCwgU3RhdGlzdGljc0dyYXBoQ29tcG9uZW50LCBTdGF0aXN0aWNzU2NvcmVEaXN0cmlidXRpb25HcmFwaENvbXBvbmVudF0sXG4gICAgZXhwb3J0czogW0RvdWdobnV0Q2hhcnRDb21wb25lbnQsIFN0YXRpc3RpY3NBdmVyYWdlU2NvcmVHcmFwaENvbXBvbmVudCwgU3RhdGlzdGljc0dyYXBoQ29tcG9uZW50LCBTdGF0aXN0aWNzU2NvcmVEaXN0cmlidXRpb25HcmFwaENvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNDaGFydHNNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsV0FBVyxhQUFxQjtBQUd6QyxTQUFTLGFBQWEsY0FBYyxnQkFBZ0I7QUFDcEQsU0FBZ0IsaUJBQWlCOzs7Ozs7OztBQ3lCYixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsR0FBQTtBQUFHLElBQUEsb0JBQUEsQ0FBQTtBQUFnQixJQUFBLDBCQUFBO0FBQUssSUFBQSxvQkFBQSxHQUFBLEdBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsSUFBQTtBQUN4QixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsQ0FBQTs7QUFBMEYsSUFBQSwwQkFBQTtBQUFRLElBQUEsb0JBQUEsR0FBQSxHQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLElBQUE7QUFDeEcsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLEdBQUE7QUFDSyxJQUFBLG9CQUFBLEVBQUE7OztBQUN1RyxJQUFBLDBCQUFBO0FBRWhILElBQUEsb0JBQUEsSUFBQSxvQkFBQTs7Ozs7QUFOTyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFNBQUEsSUFBQTtBQUNHLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsSUFBQSx5QkFBQSxHQUFBLEdBQUEsNkNBQUEsR0FBQSxNQUFBLFNBQUEsT0FBQSxHQUFBO0FBRUQsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxJQUFBLHlCQUFBLElBQUEsR0FBQSwwQ0FBQSxHQUFBLCtCQUFBLHlCQUFBLElBQUEsR0FBQSxpQ0FBQSxPQUFBLHNCQUFBLFNBQUEsTUFBQSxTQUFBLEtBQUEsQ0FBQSxHQUFBLEVBQUE7Ozs7O0FBZWIsSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx1QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxZQUFBOzs7OztBQW1Cb0IsSUFBQSxvQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQWdCLElBQUEsb0JBQUEsQ0FBQTs7QUFBdUUsSUFBQSwwQkFBQTtBQUMzRixJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLDRCQUFBOzs7QUFGd0IsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxHQUFBLEdBQUEsOENBQUEsQ0FBQTs7Ozs7O0FBSXBCLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsU0FBQSxFQUFBO0FBRUksSUFBQSx3QkFBQSxVQUFBLFNBQUEsOEZBQUE7QUFBQSxZQUFBLGNBQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsV0FBQSxZQUFBO0FBQUEsWUFBQSxVQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFVLHlCQUFBLFFBQUEsV0FBQSxRQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUY5QixJQUFBLDBCQUFBO0FBTUEsSUFBQSxvQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFtQixJQUFBLG9CQUFBLENBQUE7O0FBQTRGLElBQUEsMEJBQUE7QUFDbkgsSUFBQSxvQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsNEJBQUE7Ozs7O0FBTmdCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsV0FBQSxPQUFBLG1CQUFBLHNCQUFBLE9BQUEsZ0JBQUEsUUFBQSxDQUFBLENBQUE7QUFHZSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLEdBQUEsR0FBQSxzQ0FBQSxTQUFBLFlBQUEsSUFBQSxRQUFBLENBQUE7Ozs7OztBQWMzQixJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUVJLElBQUEsd0JBQUEsVUFBQSxTQUFBLHNHQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFVLHlCQUFBLFFBQUEsOEJBQUEsQ0FBK0I7SUFBQSxDQUFBO0FBRjdDLElBQUEsMEJBQUE7QUFNQSxJQUFBLG9CQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQW1CLElBQUEsb0JBQUEsQ0FBQTs7QUFBeUYsSUFBQSwwQkFBQTtBQUNoSCxJQUFBLG9CQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSw0QkFBQTs7OztBQU5nQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFdBQUEsUUFBQSxvQkFBQSw4QkFBQTtBQUdlLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsR0FBQSxHQUFBLGdFQUFBLENBQUE7Ozs7OztBQUszQixJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUVJLElBQUEsd0JBQUEsVUFBQSxTQUFBLDhGQUFBO0FBQUEsWUFBQSxjQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLGVBQUEsWUFBQTtBQUFBLFlBQUEsVUFBQSwyQkFBQSxDQUFBO0FBQUEsYUFBVSx5QkFBQSxRQUFBLGVBQUEsWUFBQSxDQUF3QjtJQUFBLENBQUE7QUFGdEMsSUFBQSwwQkFBQTtBQU1BLElBQUEsb0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBbUIsSUFBQSxvQkFBQSxDQUFBO0FBQWMsSUFBQSwwQkFBQTtBQUNyQyxJQUFBLG9CQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSw0QkFBQTs7Ozs7QUFOZ0IsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxXQUFBLFFBQUEsb0JBQUEsc0JBQUEsWUFBQSxDQUFBO0FBR2UsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxZQUFBOzs7Ozs7QUFoRXZDLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsVUFBQSxFQUFBO0FBT0ksSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx1QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxDQUFBOztBQUdKLElBQUEsMEJBQUE7QUFDTixJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSw2RUFBQSxHQUFBLENBQUE7QUFLQSxJQUFBLDhCQUFBLElBQUEscUVBQUEsSUFBQSxHQUFBLE1BQUEsTUFBQSxzQ0FBQTtBQWFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsS0FBQSxFQUFBO0FBQWdCLElBQUEsb0JBQUEsRUFBQTs7QUFBMkYsSUFBQSwwQkFBQTtBQUMvRyxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFxQyxJQUFBLHdCQUFBLFVBQUEsU0FBQSx3RkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSwyQkFBQTtBQUFBLGFBQVUseUJBQUEsUUFBQSxvQkFBQSxDQUFxQjtJQUFBLENBQUE7QUFBcEUsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxLQUFBLEVBQUE7QUFBZ0IsSUFBQSxvQkFBQSxFQUFBOztBQUFvRixJQUFBLDBCQUFBO0FBQ3hHLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLDZFQUFBLElBQUEsQ0FBQTtBQWFBLElBQUEsOEJBQUEsSUFBQSxxRUFBQSxJQUFBLEdBQUEsTUFBQSxNQUFBLHNDQUFBO0FBYUosSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsZ0JBQUE7Ozs7QUFuRVksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxpQkFBQSxFQUFBLE9BQUEsb0JBQUEsd0JBQUEsT0FBQSxtQkFBQSxzQkFBQSxFQUErRyxlQUFBLE9BQUEsb0JBQUEsd0JBQUEsT0FBQSxtQkFBQSx3QkFBQSxDQUFBO0FBS3RHLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsUUFBQSxPQUFBLFFBQUE7QUFDSCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLEdBQUEsSUFBQSxpREFBQSw2QkFBQSxJQUFBLEtBQUEsT0FBQSxtQkFBQSx3QkFBQSxPQUFBLG9CQUFBLHFCQUFBLENBQUEsQ0FBQTtBQU1OLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsSUFBQSxPQUFBLG1CQUFBLFFBQUEsT0FBQSxLQUFBLEVBQUE7QUFLQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLE9BQUEsbUJBQUEsT0FBQTtBQWNvQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLElBQUEsSUFBQSxrRUFBQSxDQUFBO0FBSTBELElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsV0FBQSxPQUFBLG9CQUFBLHFCQUFBO0FBQ3RELElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsSUFBQSxJQUFBLDJEQUFBLENBQUE7QUFHeEIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxJQUFBLE9BQUEsb0JBQUEsb0NBQUEsS0FBQSxFQUFBO0FBYUEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxPQUFBLG9CQUFBLGtCQUFBOzs7Ozs7QUFtQkEsSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUEwQixJQUFBLHdCQUFBLFNBQUEsU0FBQSw0RUFBQTtBQUFBLFlBQUEsY0FBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxlQUFBLFlBQUE7QUFBQSxZQUFBLFVBQUEsMkJBQUE7QUFBQSxhQUFTLHlCQUFBLFFBQUEsMEJBQUEsWUFBQSxDQUFtQztJQUFBLENBQUE7QUFDbEUsSUFBQSxvQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx1QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxDQUFBOztBQUE4RSxJQUFBLDBCQUFBO0FBQ3hGLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7Ozs7O0FBSGtDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsV0FBQSxPQUFBLGdCQUFBLElBQUEsWUFBQSxDQUFBO0FBQ3BCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsR0FBQSxHQUFBLDZDQUFBLFlBQUEsQ0FBQTs7O0FEL0hsQyxjQWtCWSxxQkFXQztBQTdCYjs7QUFDQTtBQUlBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUFPQSxLQUFBLFNBQVlBLHNCQUFtQjtBQUMzQixNQUFBQSxxQkFBQSxRQUFBLElBQUE7QUFDQSxNQUFBQSxxQkFBQSxTQUFBLElBQUE7QUFDQSxNQUFBQSxxQkFBQSxNQUFBLElBQUE7SUFDSixHQUpZLHdCQUFBLHNCQUFtQixDQUFBLEVBQUE7QUFXekIsSUFBTyx1Q0FBUCxNQUFPLHNDQUFvQztNQW1EakM7TUFDQTtNQUNDO01BQ0E7TUFwRGI7TUFFQTtNQUVBO01BR0EsT0FBTztNQUNQLFFBQVE7TUFDUixXQUFXO01BR1gsaUJBQTJCLENBQUE7TUFFM0IsVUFBcUMsQ0FBQTtNQUNyQyxXQUFXO1FBQ1AsTUFBTTtRQUNOLFlBQVk7UUFDWixPQUFPLFVBQVU7UUFDakIsUUFBUSxDQUFBOztNQUlaO01BQ0E7TUFDQSxrQkFBa0Isb0JBQUksSUFBRztNQUN6Qiw0QkFBNEI7TUFFbkIsc0JBQXNCO01BQ3RCLHVCQUF1QixDQUFDLG9CQUFvQixRQUFRLG9CQUFvQixTQUFTLG9CQUFvQixJQUFJO01BQ3pHLGtCQUFrQix3QkFBd0I7TUFDMUMsaUJBQWlCO01BQ2pCLGVBQWU7TUFDZixhQUFhO01BQ2IsY0FBYztNQUV2QjtNQUNBO01BR0EsZ0JBQWdCO01BQ2hCLGNBQWM7TUFHZCxjQUFjO01BQ2QsZUFBZTtNQUNmLFdBQVc7TUFFWCxZQUNZLGNBQ0EsdUJBQ0Msb0JBQ0EscUJBQXdDO0FBSHpDLGFBQUEsZUFBQTtBQUNBLGFBQUEsd0JBQUE7QUFDQyxhQUFBLHFCQUFBO0FBQ0EsYUFBQSxzQkFBQTtNQUNWO01BRUgsV0FBUTtBQUNKLGFBQUssZ0JBQWU7TUFDeEI7TUFFUSxrQkFBZTtBQUNuQixhQUFLLG9CQUFtQjtBQUN4QixhQUFLLHdCQUF3QixLQUFLLG1CQUFtQixLQUFLLHFCQUFxQjtBQUMvRSxhQUFLLHVCQUFzQjtBQUMzQixhQUFLLG1CQUFtQix3QkFBd0IsS0FBSyxxQkFBcUI7QUFDMUUsYUFBSyxvQkFBb0Isb0JBQW9CLEtBQUsscUJBQXFCO0FBQ3ZFLGFBQUssV0FBVyxLQUFLLHFCQUFxQjtBQUMxQyxhQUFLLGdDQUFnQyxLQUFLO0FBQzFDLGFBQUssOENBQThDLEtBQUs7QUFDeEQsYUFBSyxjQUFjLEtBQUssc0JBQXNCO01BQ2xEO01BR08sZUFBZSxTQUFnQjtBQUNsQyxhQUFLLGlCQUFpQixVQUFVLElBQUk7QUFDcEMsYUFBSyxXQUFXLEtBQUssNkJBQTZCO01BQ3REO01BT1EsZUFBZSxPQUFhO0FBQ2hDLFlBQUksUUFBUSxLQUFLLHdCQUF3QjtBQUNyQyxpQkFBTyxZQUFZO21CQUNaLFFBQVEsS0FBSywyQkFBMkI7QUFDL0MsaUJBQU8sWUFBWTs7QUFFdkIsZUFBTyxZQUFZO01BQ3ZCO01BTUEsU0FBUyxPQUFVO0FBQ2YsY0FBTSxZQUFZLEtBQUssb0JBQW9CLE1BQU0sTUFBTSxNQUFNLEtBQUs7QUFHbEUsWUFBSSxXQUFXO0FBQ1gsZ0JBQU0sUUFBUSxDQUFDLHFCQUFxQixLQUFLLFVBQVUsSUFBSSxVQUFVLFlBQVkscUJBQXFCO0FBQ2xHLGNBQUksT0FBTyxVQUFVLGFBQWEsWUFBVztBQUM3QyxjQUFJLFNBQVMsYUFBYSxNQUFNO0FBQzVCLGtCQUFNLENBQUMsSUFBSTtxQkFDSixTQUFTLGVBQWU7QUFDL0IsbUJBQU87O0FBRVgsZ0JBQU0sQ0FBQyxJQUFJLE9BQU87QUFDbEIsZUFBSyxzQkFBc0IsY0FBYyxLQUFLOztNQUV0RDtNQU9RLG9CQUFvQixNQUFjLE9BQWE7QUFDbkQsWUFBSSxVQUFVO0FBQ2QsWUFBSTtBQU1KLGFBQUssUUFBUSxRQUFRLENBQUMsYUFBWTtBQUM5QixjQUFJLFNBQVMsU0FBUyxRQUFRLFNBQVMsVUFBVSxPQUFPO0FBQ3BEO0FBQ0EscUJBQVM7O1FBRWpCLENBQUM7QUFFRCxlQUFPLFlBQVksSUFBSSxTQUFTO01BQ3BDO01BT0Esc0JBQXNCLE1BQWMsT0FBYTtBQUM3QyxjQUFNLFFBQVEsS0FBSyxvQkFBb0IsTUFBTSxLQUFLO0FBQ2xELFlBQUksT0FBTztBQUNQLGdCQUFNLE9BQU8sTUFBTSxhQUFhLFlBQVc7QUFDM0MsY0FBSSxTQUFTLGVBQWU7QUFDeEIsbUJBQU87O0FBRVgsaUJBQU87ZUFDSjtBQUVILGlCQUFPOztNQUVmO01BTVEsV0FBVyxnQkFBaUQ7QUFDaEUsYUFBSyxpQkFBaUIsZUFBZSxNQUFNLEtBQUssZUFBZSxLQUFLLEtBQUssYUFBYSxFQUFFLElBQUksQ0FBQyxhQUFhLFNBQVMsWUFBWTtBQUMvSCxhQUFLLFVBQVUsZUFBZSxNQUFNLEtBQUssZUFBZSxLQUFLLEtBQUssYUFBYSxFQUFFLElBQzdFLENBQUMsVUFBVSxXQUNOO1VBQ0csTUFBTSxLQUFLLGVBQWUsS0FBSztVQUMvQixPQUFPLFNBQVM7VUFDaEIsY0FBYyxTQUFTO1VBQ3ZCLFlBQVksU0FBUztVQUNJO0FBRXJDLGFBQUssU0FBUyxTQUFTLEtBQUssUUFBUSxJQUFJLENBQUMsYUFBYSxLQUFLLGVBQWUsU0FBUyxLQUFLLENBQUM7TUFDN0Y7TUFVUSx5QkFBc0I7QUFDMUIsWUFBSSxDQUFDLEtBQUsseUJBQXlCLEtBQUssc0JBQXNCLFdBQVcsR0FBRztBQUN4RTs7QUFFSixjQUFNLGdCQUFnQixLQUFLLHNCQUFzQixJQUFJLENBQUMsYUFBYSxTQUFTLFlBQVk7QUFDeEYsY0FBTSxZQUFZLEtBQUssTUFBTSxjQUFjLFNBQVMsQ0FBQztBQUNyRCxjQUFNLDRCQUE0QixjQUFjLEtBQUssSUFBSSxZQUFZLEdBQUcsQ0FBQyxDQUFDO0FBQzFFLGNBQU0sNEJBQTRCLGNBQWMsT0FBTyxDQUFDLFVBQVUsUUFBUSx5QkFBeUI7QUFDbkcsYUFBSyw0QkFBNEIsMEJBQTBCLFNBQVMsSUFBSSxLQUFLLElBQUksR0FBRyx5QkFBeUIsSUFBSTtBQUNqSCxjQUFNLHlCQUF5QixjQUFjLEtBQUssSUFBSSxjQUFjLFNBQVMsV0FBVyxjQUFjLFNBQVMsQ0FBQyxDQUFDO0FBQ2pILGNBQU0sMEJBQTBCLGNBQWMsT0FBTyxDQUFDLFVBQVUsUUFBUSxzQkFBc0I7QUFDOUYsYUFBSyx5QkFBeUIsd0JBQXdCLFNBQVMsSUFBSSxLQUFLLElBQUksR0FBRyx1QkFBdUIsSUFBSTtNQUM5RztNQU1BLFdBQVcsTUFBa0I7QUFDekIsY0FBTSxzQkFBc0IsS0FBSyxtQkFBbUIsbUJBQW9ELE1BQU0sS0FBSywyQ0FBMkM7QUFDOUosY0FBTSwwQkFBMEIsS0FBSyxvQkFBb0IsbUJBQW9ELEtBQUssMkNBQTJDO0FBQzdKLGFBQUssMEJBQTBCLHlCQUF5QixtQkFBbUI7TUFDL0U7TUFRQSwwQkFBMEIsVUFBNkI7QUFDbkQsY0FBTSxlQUFlLEtBQUssZ0JBQWdCLElBQUksUUFBUTtBQUV0RCxhQUFLLGdCQUFnQjtBQUNyQixZQUFJLFdBQVc7QUFFZixZQUFJLGlCQUFpQixJQUFJO0FBRXJCLGNBQUksS0FBSyw4QkFBOEIsR0FBRztBQUN0QyxpQkFBSyxvQkFBbUI7QUFDeEIsaUJBQUssOENBQThDLEtBQUssbUJBQW1CLEtBQUsscUJBQXFCO2lCQUNsRztBQUNILGlCQUFLLDBCQUEwQixRQUFROztBQUUzQyxlQUFLLDZEQUE0RDtBQUNqRTs7QUFFSixnQkFBUSxVQUFVO1VBQ2QsS0FBSyxvQkFBb0IsUUFBUTtBQUM3Qix1QkFBVyxLQUFLO0FBQ2hCOztVQUVKLEtBQUssb0JBQW9CLFNBQVM7QUFDOUIsdUJBQVcsS0FBSztBQUNoQjs7VUFFSixLQUFLLG9CQUFvQixNQUFNO0FBQzNCLHVCQUFXLEtBQUs7QUFDaEI7OztBQUlSLGFBQUssZ0JBQWdCLElBQUksVUFBVSxRQUFRO0FBQzNDLGFBQUssNkJBQTZCO0FBQ2xDLGNBQU0sWUFBWSxLQUFLLDZCQUE2QixRQUFRO0FBQzVELGFBQUssOENBQThDLEtBQUssbUJBQW1CLEtBQUssNENBQTRDLE9BQU8sU0FBUyxDQUFDO0FBQzdJLGFBQUssNkRBQTREO01BQ3JFO01BTVEsNkJBQTZCLFVBQTZCO0FBQzlELFlBQUk7QUFDSixnQkFBUSxVQUFVO1VBQ2QsS0FBSyxvQkFBb0IsUUFBUTtBQUM3Qiw2QkFBaUIsQ0FBQyxVQUEyQyxNQUFNLGVBQWUsS0FBSztBQUN2Rjs7VUFFSixLQUFLLG9CQUFvQixTQUFTO0FBQzlCLDZCQUFpQixDQUFDLFVBQ2QsTUFBTSxnQkFBZ0IsS0FBSyw2QkFBNkIsTUFBTSxnQkFBZ0IsS0FBSztBQUN2Rjs7VUFFSixLQUFLLG9CQUFvQixNQUFNO0FBQzNCLDZCQUFpQixDQUFDLFVBQTJDLE1BQU0sZUFBZSxLQUFLOzs7QUFHL0YsZUFBTyxLQUFLLHNCQUFzQixPQUFPLGNBQWM7TUFDM0Q7TUFNUSxtQkFBbUIsZ0JBQWlEO0FBQ3hFLGVBQU8sZUFBZSxLQUFLLENBQUMsV0FBVyxjQUFjLFVBQVUsZUFBZSxVQUFVLFlBQVk7TUFDeEc7TUFLUSwrREFBNEQ7QUFDaEUsYUFBSyxtQkFBbUIsd0JBQXdCLEtBQUssMkNBQTJDO0FBQ2hHLGFBQUssb0JBQW9CLG9CQUFvQixLQUFLLDJDQUEyQztBQUM3RixhQUFLLFdBQVcsS0FBSywyQ0FBMkM7QUFDaEUsYUFBSyxnQ0FBZ0MsS0FBSztBQUMxQyxhQUFLLGNBQWMsS0FBSyw0Q0FBNEM7TUFDeEU7TUFLUSxzQkFBbUI7QUFDdkIsYUFBSyxnQkFBZ0IsSUFBSSxvQkFBb0IsUUFBUSxLQUFLLGNBQWM7QUFDeEUsYUFBSyxnQkFBZ0IsSUFBSSxvQkFBb0IsU0FBUyxLQUFLLFlBQVk7QUFDdkUsYUFBSyxnQkFBZ0IsSUFBSSxvQkFBb0IsTUFBTSxLQUFLLFVBQVU7QUFDbEUsYUFBSyw0QkFBNEI7TUFDckM7TUFNUSwwQkFBMEIsVUFBNkI7QUFDM0QsYUFBSyxxQkFBcUIsUUFBUSxDQUFDLE9BQU07QUFDckMsY0FBSSxPQUFPLFVBQVU7QUFDakIsaUJBQUssZ0JBQWdCLElBQUksSUFBSSxFQUFFOztRQUV2QyxDQUFDO0FBQ0QsYUFBSyw0QkFBNEI7QUFDakMsYUFBSyw4Q0FBOEMsS0FBSyw2QkFBNkIsUUFBUTtNQUNqRztNQU1BLGVBQWUsVUFBZ0I7QUFDM0IsY0FBTSwwQkFBMEIsS0FBSyxvQkFBb0IsZUFBZ0QsS0FBSyw2Q0FBNkMsUUFBUTtBQUNuSyxjQUFNLHNCQUFzQixLQUFLLG1CQUFtQixtQkFBb0QsS0FBSywyQ0FBMkM7QUFDeEosYUFBSywwQkFBMEIseUJBQXlCLG1CQUFtQjtNQUMvRTtNQUtBLHNCQUFtQjtBQUNmLGNBQU0sMEJBQTBCLEtBQUssb0JBQW9CLG9CQUFxRCxLQUFLLDJDQUEyQztBQUM5SixjQUFNLHNCQUFzQixLQUFLLG1CQUFtQixtQkFBb0QsS0FBSywyQ0FBMkM7QUFDeEosYUFBSywwQkFBMEIseUJBQXlCLG1CQUFtQjtNQUMvRTtNQUtBLGdDQUE2QjtBQUN6QixjQUFNLDBCQUEwQixLQUFLLG9CQUFvQiw4QkFBK0QsS0FBSywyQ0FBMkM7QUFDeEssY0FBTSxzQkFBc0IsS0FBSyxtQkFBbUIsbUJBQW9ELEtBQUssMkNBQTJDO0FBQ3hKLGFBQUssMEJBQTBCLHlCQUF5QixtQkFBbUI7TUFDL0U7TUFRUSwwQkFBMEIseUJBQTRELHFCQUFzRDtBQUNoSixhQUFLLGdDQUFnQyxLQUFLLG1CQUFtQix3QkFBd0IsT0FBTyxDQUFDLFVBQVUsb0JBQW9CLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFDM0ksYUFBSyxnQkFBZ0I7QUFDckIsYUFBSyxXQUFXLEtBQUssNkJBQTZCO0FBQ2xELGFBQUssY0FBYyxLQUFLLDhCQUE4QjtNQUMxRDtNQU1BLGdCQUFnQixjQUFvQjtBQUNoQyxlQUFPLGVBQWU7TUFDMUI7O3lCQTVXUyx1Q0FBb0MsK0JBQUEsWUFBQSxHQUFBLCtCQUFBLDRCQUFBLEdBQUEsK0JBQUEsdUJBQUEsR0FBQSwrQkFBQSxtQkFBQSxDQUFBO01BQUE7Z0VBQXBDLHVDQUFvQyxXQUFBLENBQUEsQ0FBQSxvQ0FBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLHVCQUFBLHlCQUFBLGVBQUEsaUJBQUEsVUFBQSxXQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLE9BQUEsUUFBQSxVQUFBLHdCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsVUFBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsYUFBQSxXQUFBLEdBQUEsQ0FBQSxRQUFBLE1BQUEsUUFBQSxVQUFBLEdBQUEsU0FBQSxVQUFBLHNCQUFBLHVCQUFBLEdBQUEsUUFBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsUUFBQSxpQkFBQSxHQUFBLENBQUEsZ0JBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLFFBQUEsV0FBQSxVQUFBLGFBQUEsU0FBQSxTQUFBLHVCQUFBLHVCQUFBLGlCQUFBLFFBQUEsR0FBQSxDQUFBLG1CQUFBLEVBQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxRQUFBLFVBQUEsR0FBQSxTQUFBLFVBQUEsc0JBQUEsa0JBQUEsR0FBQSxRQUFBLE9BQUEsR0FBQSxDQUFBLGVBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFVBQUEsZUFBQSxzQkFBQSx3QkFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLDRCQUFBLEdBQUEsQ0FBQSxjQUFBLG1CQUFBLGVBQUEsSUFBQSxHQUFBLFVBQUEsTUFBQSxHQUFBLENBQUEscUJBQUEsSUFBQSxNQUFBLDBCQUFBLEdBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxtQkFBQSxJQUFBLG1CQUFBLDBCQUFBLEdBQUEsaUJBQUEsZUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLFFBQUEsWUFBQSxHQUFBLFFBQUEsb0JBQUEsR0FBQSxXQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDhDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDN0JqRCxVQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUFJLFVBQUEsb0JBQUEsQ0FBQTs7QUFBeUQsVUFBQSwwQkFBQTtBQUM3RCxVQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBO0FBQUksVUFBQSxvQkFBQSxDQUFBOztBQUEwRixVQUFBLDBCQUFBO0FBQ2xHLFVBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUtJLFVBQUEsd0JBQUEsU0FBQSxTQUFBLDBFQUFBO0FBQUEsbUJBQVMsSUFBQSxlQUFBLElBQUEsSUFBQTtVQUFvQixDQUFBO0FBRWhDLFVBQUEsMEJBQUE7QUFDRCxVQUFBLG9CQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxPQUFBLEdBQUEsQ0FBQTtBQUNJLFVBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSwyQkFBQSxDQUFBO0FBV0ksVUFBQSx3QkFBQSxVQUFBLFNBQUEseUZBQUEsUUFBQTtBQUFBLG1CQUFVLElBQUEsU0FBQSxNQUFBO1VBQWdCLENBQUE7QUFFMUIsVUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLDhEQUFBLElBQUEsSUFBQSxlQUFBLE1BQUEsR0FBQSxtQ0FBQTtBQVFKLFVBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMEJBQUE7QUFDSixVQUFBLG9CQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMEJBQUE7QUFDQSxVQUFBLG9CQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxXQUFBLENBQUE7QUFLSSxVQUFBLHdCQUFBLFNBQUEsU0FBQSwwRUFBQTtBQUFBLG1CQUFTLElBQUEsZUFBQSxJQUFBLEtBQUE7VUFBcUIsQ0FBQTtBQUVqQyxVQUFBLDBCQUFBO0FBQ0QsVUFBQSxvQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsOERBQUEsR0FBQSxHQUFBLGVBQUEsTUFBQSxHQUFBLG1DQUFBO0FBR0EsVUFBQSxvQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLDhEQUFBLElBQUEsRUFBQTtBQXdFQSxVQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLFVBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxzREFBQSxJQUFBLEdBQUEsTUFBQSxNQUFBLHNDQUFBO0FBTUosVUFBQSwwQkFBQTtBQUNKLFVBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMEJBQUE7QUFDSixVQUFBLG9CQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMEJBQUE7QUFDSixVQUFBLG9CQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMEJBQUE7QUFDSixVQUFBLG9CQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsMEJBQUE7QUFDQSxVQUFBLG9CQUFBLElBQUEsSUFBQTs7OztBQXJJWSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLCtCQUFBLHlCQUFBLEdBQUEsSUFBQSxnQ0FBQSxDQUFBO0FBQ0EsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSxJQUFBLHlCQUFBLElBQUEsSUFBQSwyQ0FBQSxHQUFBLE1BQUEsSUFBQSxlQUFBLEdBQUE7QUFTQSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFVBQUEsRUFBQSxJQUFBLGNBQUEsSUFBQSxlQUFBLElBQUEsZ0JBQUEsRUFBQTtBQUxBLFVBQUEsd0JBQUEsUUFBQSxJQUFBLFdBQUE7QUFTSSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLHdCQUFBLGNBQUEsS0FBQSxFQUFvQixRQUFBLDZCQUFBLElBQUEsS0FBQSxJQUFBLFdBQUEsQ0FBQSxFQUFBLFdBQUEsSUFBQSxPQUFBLEVBQUEsVUFBQSxJQUFBLFFBQUEsRUFBQSxhQUFBLEdBQUEsRUFBQSxTQUFBLElBQUEsRUFBQSxTQUFBLElBQUEsRUFBQSx1QkFBQSxJQUFBLG1CQUFBLEVBQUEsdUJBQUEsSUFBQSxlQUFBLEVBQUEsaUJBQUEsSUFBQTtBQTRCeEIsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxVQUFBLEVBQUEsSUFBQSxjQUFBLElBQUEsY0FBQSxJQUFBLGNBQUE7QUFMQSxVQUFBLHdCQUFBLFFBQUEsSUFBQSxZQUFBO0FBV0EsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSwyQkFBQSxJQUFBLElBQUEsbUJBQUEsUUFBQSxPQUFBLElBQUEsS0FBQSxFQUFBO0FBMEVRLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxvQkFBQTs7Ozs7b0ZEL0ZQLHNDQUFvQyxFQUFBLFdBQUEsdUNBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFN0JqRCxTQUFTLGdCQUFnQjtBQU16QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGdCQUFnQixpQkFBaUIsc0JBQXNCOztBQVBoRSxJQWNhO0FBZGI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVNNLElBQU8sc0JBQVAsTUFBTyxxQkFBbUI7O3lCQUFuQixzQkFBbUI7TUFBQTtnRUFBbkIscUJBQW1CLENBQUE7b0VBSmxCLHFCQUFxQixjQUFjLGdCQUFnQixpQkFBaUIsY0FBYyxFQUFBLENBQUE7Ozs7IiwibmFtZXMiOlsiUGVyZm9ybWFuY2VJbnRlcnZhbCJdfQ==