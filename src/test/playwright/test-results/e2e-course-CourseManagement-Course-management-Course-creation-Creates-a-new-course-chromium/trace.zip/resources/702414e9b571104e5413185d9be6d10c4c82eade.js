import {
  init_side_panel_component
} from "/chunk-H46RESQY.js";
import {
  ArtemisSharedModule,
  __esm,
  init_shared_module
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/side-panel/side-panel.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisSidePanelModule;
var init_side_panel_module = __esm({
  "src/main/webapp/app/shared/side-panel/side-panel.module.ts"() {
    init_shared_module();
    init_side_panel_component();
    ArtemisSidePanelModule = class _ArtemisSidePanelModule {
      static \u0275fac = function ArtemisSidePanelModule_Factory(t) {
        return new (t || _ArtemisSidePanelModule)();
      };
      static \u0275mod = i0.\u0275\u0275defineNgModule({ type: _ArtemisSidePanelModule });
      static \u0275inj = i0.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule] });
    };
  }
});

export {
  ArtemisSidePanelModule,
  init_side_panel_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3NpZGUtcGFuZWwvc2lkZS1wYW5lbC5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBTaWRlUGFuZWxDb21wb25lbnQgfSBmcm9tICcuL3NpZGUtcGFuZWwuY29tcG9uZW50JztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbU2lkZVBhbmVsQ29tcG9uZW50XSxcbiAgICBleHBvcnRzOiBbU2lkZVBhbmVsQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc1NpZGVQYW5lbE1vZHVsZSB7fVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsU0FBUyxnQkFBZ0I7O0FBQXpCLElBVWE7QUFWYjs7QUFFQTtBQUNBO0FBT00sSUFBTyx5QkFBUCxNQUFPLHdCQUFzQjs7eUJBQXRCLHlCQUFzQjtNQUFBOytEQUF0Qix3QkFBc0IsQ0FBQTttRUFKckIsbUJBQW1CLEVBQUEsQ0FBQTs7OzsiLCJuYW1lcyI6W119