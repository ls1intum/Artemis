var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/process/browser.js
var require_browser = __commonJS({
  "node_modules/process/browser.js"(exports, module) {
    var process2 = module.exports = {};
    var cachedSetTimeout;
    var cachedClearTimeout;
    function defaultSetTimout() {
      throw new Error("setTimeout has not been defined");
    }
    function defaultClearTimeout() {
      throw new Error("clearTimeout has not been defined");
    }
    (function() {
      try {
        if (typeof setTimeout === "function") {
          cachedSetTimeout = setTimeout;
        } else {
          cachedSetTimeout = defaultSetTimout;
        }
      } catch (e) {
        cachedSetTimeout = defaultSetTimout;
      }
      try {
        if (typeof clearTimeout === "function") {
          cachedClearTimeout = clearTimeout;
        } else {
          cachedClearTimeout = defaultClearTimeout;
        }
      } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
      }
    })();
    function runTimeout(fun) {
      if (cachedSetTimeout === setTimeout) {
        return setTimeout(fun, 0);
      }
      if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
      }
      try {
        return cachedSetTimeout(fun, 0);
      } catch (e) {
        try {
          return cachedSetTimeout.call(null, fun, 0);
        } catch (e2) {
          return cachedSetTimeout.call(this, fun, 0);
        }
      }
    }
    function runClearTimeout(marker) {
      if (cachedClearTimeout === clearTimeout) {
        return clearTimeout(marker);
      }
      if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
      }
      try {
        return cachedClearTimeout(marker);
      } catch (e) {
        try {
          return cachedClearTimeout.call(null, marker);
        } catch (e2) {
          return cachedClearTimeout.call(this, marker);
        }
      }
    }
    var queue = [];
    var draining = false;
    var currentQueue;
    var queueIndex = -1;
    function cleanUpNextTick() {
      if (!draining || !currentQueue) {
        return;
      }
      draining = false;
      if (currentQueue.length) {
        queue = currentQueue.concat(queue);
      } else {
        queueIndex = -1;
      }
      if (queue.length) {
        drainQueue();
      }
    }
    function drainQueue() {
      if (draining) {
        return;
      }
      var timeout = runTimeout(cleanUpNextTick);
      draining = true;
      var len = queue.length;
      while (len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
          if (currentQueue) {
            currentQueue[queueIndex].run();
          }
        }
        queueIndex = -1;
        len = queue.length;
      }
      currentQueue = null;
      draining = false;
      runClearTimeout(timeout);
    }
    process2.nextTick = function(fun) {
      var args = new Array(arguments.length - 1);
      if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
          args[i - 1] = arguments[i];
        }
      }
      queue.push(new Item(fun, args));
      if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
      }
    };
    function Item(fun, array) {
      this.fun = fun;
      this.array = array;
    }
    Item.prototype.run = function() {
      this.fun.apply(null, this.array);
    };
    process2.title = "browser";
    process2.browser = true;
    process2.env = {};
    process2.argv = [];
    process2.version = "";
    process2.versions = {};
    function noop() {
    }
    process2.on = noop;
    process2.addListener = noop;
    process2.once = noop;
    process2.off = noop;
    process2.removeListener = noop;
    process2.removeAllListeners = noop;
    process2.emit = noop;
    process2.prependListener = noop;
    process2.prependOnceListener = noop;
    process2.listeners = function(name) {
      return [];
    };
    process2.binding = function(name) {
      throw new Error("process.binding is not supported");
    };
    process2.cwd = function() {
      return "/";
    };
    process2.chdir = function(dir) {
      throw new Error("process.chdir is not supported");
    };
    process2.umask = function() {
      return 0;
    };
  }
});

// node_modules/zone.js/fesm2015/zone.js
(function(global) {
  const performance = global["performance"];
  function mark(name) {
    performance && performance["mark"] && performance["mark"](name);
  }
  function performanceMeasure(name, label) {
    performance && performance["measure"] && performance["measure"](name, label);
  }
  mark("Zone");
  const symbolPrefix = global["__Zone_symbol_prefix"] || "__zone_symbol__";
  function __symbol__(name) {
    return symbolPrefix + name;
  }
  const checkDuplicate = global[__symbol__("forceDuplicateZoneCheck")] === true;
  if (global["Zone"]) {
    if (checkDuplicate || typeof global["Zone"].__symbol__ !== "function") {
      throw new Error("Zone already loaded.");
    } else {
      return global["Zone"];
    }
  }
  const _Zone = class _Zone {
    static assertZonePatched() {
      if (global["Promise"] !== patches["ZoneAwarePromise"]) {
        throw new Error("Zone.js has detected that ZoneAwarePromise `(window|global).Promise` has been overwritten.\nMost likely cause is that a Promise polyfill has been loaded after Zone.js (Polyfilling Promise api is not necessary when zone.js is loaded. If you must load one, do so before loading zone.js.)");
      }
    }
    static get root() {
      let zone = _Zone.current;
      while (zone.parent) {
        zone = zone.parent;
      }
      return zone;
    }
    static get current() {
      return _currentZoneFrame.zone;
    }
    static get currentTask() {
      return _currentTask;
    }
    // tslint:disable-next-line:require-internal-with-underscore
    static __load_patch(name, fn, ignoreDuplicate = false) {
      if (patches.hasOwnProperty(name)) {
        if (!ignoreDuplicate && checkDuplicate) {
          throw Error("Already loaded patch: " + name);
        }
      } else if (!global["__Zone_disable_" + name]) {
        const perfName = "Zone:" + name;
        mark(perfName);
        patches[name] = fn(global, _Zone, _api);
        performanceMeasure(perfName, perfName);
      }
    }
    get parent() {
      return this._parent;
    }
    get name() {
      return this._name;
    }
    constructor(parent, zoneSpec) {
      this._parent = parent;
      this._name = zoneSpec ? zoneSpec.name || "unnamed" : "<root>";
      this._properties = zoneSpec && zoneSpec.properties || {};
      this._zoneDelegate = new _ZoneDelegate(this, this._parent && this._parent._zoneDelegate, zoneSpec);
    }
    get(key) {
      const zone = this.getZoneWith(key);
      if (zone)
        return zone._properties[key];
    }
    getZoneWith(key) {
      let current = this;
      while (current) {
        if (current._properties.hasOwnProperty(key)) {
          return current;
        }
        current = current._parent;
      }
      return null;
    }
    fork(zoneSpec) {
      if (!zoneSpec)
        throw new Error("ZoneSpec required!");
      return this._zoneDelegate.fork(this, zoneSpec);
    }
    wrap(callback, source) {
      if (typeof callback !== "function") {
        throw new Error("Expecting function got: " + callback);
      }
      const _callback = this._zoneDelegate.intercept(this, callback, source);
      const zone = this;
      return function() {
        return zone.runGuarded(_callback, this, arguments, source);
      };
    }
    run(callback, applyThis, applyArgs, source) {
      _currentZoneFrame = { parent: _currentZoneFrame, zone: this };
      try {
        return this._zoneDelegate.invoke(this, callback, applyThis, applyArgs, source);
      } finally {
        _currentZoneFrame = _currentZoneFrame.parent;
      }
    }
    runGuarded(callback, applyThis = null, applyArgs, source) {
      _currentZoneFrame = { parent: _currentZoneFrame, zone: this };
      try {
        try {
          return this._zoneDelegate.invoke(this, callback, applyThis, applyArgs, source);
        } catch (error) {
          if (this._zoneDelegate.handleError(this, error)) {
            throw error;
          }
        }
      } finally {
        _currentZoneFrame = _currentZoneFrame.parent;
      }
    }
    runTask(task, applyThis, applyArgs) {
      if (task.zone != this) {
        throw new Error("A task can only be run in the zone of creation! (Creation: " + (task.zone || NO_ZONE).name + "; Execution: " + this.name + ")");
      }
      if (task.state === notScheduled && (task.type === eventTask || task.type === macroTask)) {
        return;
      }
      const reEntryGuard = task.state != running;
      reEntryGuard && task._transitionTo(running, scheduled);
      task.runCount++;
      const previousTask = _currentTask;
      _currentTask = task;
      _currentZoneFrame = { parent: _currentZoneFrame, zone: this };
      try {
        if (task.type == macroTask && task.data && !task.data.isPeriodic) {
          task.cancelFn = void 0;
        }
        try {
          return this._zoneDelegate.invokeTask(this, task, applyThis, applyArgs);
        } catch (error) {
          if (this._zoneDelegate.handleError(this, error)) {
            throw error;
          }
        }
      } finally {
        if (task.state !== notScheduled && task.state !== unknown) {
          if (task.type == eventTask || task.data && task.data.isPeriodic) {
            reEntryGuard && task._transitionTo(scheduled, running);
          } else {
            task.runCount = 0;
            this._updateTaskCount(task, -1);
            reEntryGuard && task._transitionTo(notScheduled, running, notScheduled);
          }
        }
        _currentZoneFrame = _currentZoneFrame.parent;
        _currentTask = previousTask;
      }
    }
    scheduleTask(task) {
      if (task.zone && task.zone !== this) {
        let newZone = this;
        while (newZone) {
          if (newZone === task.zone) {
            throw Error(`can not reschedule task to ${this.name} which is descendants of the original zone ${task.zone.name}`);
          }
          newZone = newZone.parent;
        }
      }
      task._transitionTo(scheduling, notScheduled);
      const zoneDelegates = [];
      task._zoneDelegates = zoneDelegates;
      task._zone = this;
      try {
        task = this._zoneDelegate.scheduleTask(this, task);
      } catch (err) {
        task._transitionTo(unknown, scheduling, notScheduled);
        this._zoneDelegate.handleError(this, err);
        throw err;
      }
      if (task._zoneDelegates === zoneDelegates) {
        this._updateTaskCount(task, 1);
      }
      if (task.state == scheduling) {
        task._transitionTo(scheduled, scheduling);
      }
      return task;
    }
    scheduleMicroTask(source, callback, data, customSchedule) {
      return this.scheduleTask(new ZoneTask(microTask, source, callback, data, customSchedule, void 0));
    }
    scheduleMacroTask(source, callback, data, customSchedule, customCancel) {
      return this.scheduleTask(new ZoneTask(macroTask, source, callback, data, customSchedule, customCancel));
    }
    scheduleEventTask(source, callback, data, customSchedule, customCancel) {
      return this.scheduleTask(new ZoneTask(eventTask, source, callback, data, customSchedule, customCancel));
    }
    cancelTask(task) {
      if (task.zone != this)
        throw new Error("A task can only be cancelled in the zone of creation! (Creation: " + (task.zone || NO_ZONE).name + "; Execution: " + this.name + ")");
      if (task.state !== scheduled && task.state !== running) {
        return;
      }
      task._transitionTo(canceling, scheduled, running);
      try {
        this._zoneDelegate.cancelTask(this, task);
      } catch (err) {
        task._transitionTo(unknown, canceling);
        this._zoneDelegate.handleError(this, err);
        throw err;
      }
      this._updateTaskCount(task, -1);
      task._transitionTo(notScheduled, canceling);
      task.runCount = 0;
      return task;
    }
    _updateTaskCount(task, count) {
      const zoneDelegates = task._zoneDelegates;
      if (count == -1) {
        task._zoneDelegates = null;
      }
      for (let i = 0; i < zoneDelegates.length; i++) {
        zoneDelegates[i]._updateTaskCount(task.type, count);
      }
    }
  };
  _Zone.__symbol__ = __symbol__;
  let Zone2 = _Zone;
  const DELEGATE_ZS = {
    name: "",
    onHasTask: (delegate, _, target, hasTaskState) => delegate.hasTask(target, hasTaskState),
    onScheduleTask: (delegate, _, target, task) => delegate.scheduleTask(target, task),
    onInvokeTask: (delegate, _, target, task, applyThis, applyArgs) => delegate.invokeTask(target, task, applyThis, applyArgs),
    onCancelTask: (delegate, _, target, task) => delegate.cancelTask(target, task)
  };
  class _ZoneDelegate {
    constructor(zone, parentDelegate, zoneSpec) {
      this._taskCounts = { "microTask": 0, "macroTask": 0, "eventTask": 0 };
      this.zone = zone;
      this._parentDelegate = parentDelegate;
      this._forkZS = zoneSpec && (zoneSpec && zoneSpec.onFork ? zoneSpec : parentDelegate._forkZS);
      this._forkDlgt = zoneSpec && (zoneSpec.onFork ? parentDelegate : parentDelegate._forkDlgt);
      this._forkCurrZone = zoneSpec && (zoneSpec.onFork ? this.zone : parentDelegate._forkCurrZone);
      this._interceptZS = zoneSpec && (zoneSpec.onIntercept ? zoneSpec : parentDelegate._interceptZS);
      this._interceptDlgt = zoneSpec && (zoneSpec.onIntercept ? parentDelegate : parentDelegate._interceptDlgt);
      this._interceptCurrZone = zoneSpec && (zoneSpec.onIntercept ? this.zone : parentDelegate._interceptCurrZone);
      this._invokeZS = zoneSpec && (zoneSpec.onInvoke ? zoneSpec : parentDelegate._invokeZS);
      this._invokeDlgt = zoneSpec && (zoneSpec.onInvoke ? parentDelegate : parentDelegate._invokeDlgt);
      this._invokeCurrZone = zoneSpec && (zoneSpec.onInvoke ? this.zone : parentDelegate._invokeCurrZone);
      this._handleErrorZS = zoneSpec && (zoneSpec.onHandleError ? zoneSpec : parentDelegate._handleErrorZS);
      this._handleErrorDlgt = zoneSpec && (zoneSpec.onHandleError ? parentDelegate : parentDelegate._handleErrorDlgt);
      this._handleErrorCurrZone = zoneSpec && (zoneSpec.onHandleError ? this.zone : parentDelegate._handleErrorCurrZone);
      this._scheduleTaskZS = zoneSpec && (zoneSpec.onScheduleTask ? zoneSpec : parentDelegate._scheduleTaskZS);
      this._scheduleTaskDlgt = zoneSpec && (zoneSpec.onScheduleTask ? parentDelegate : parentDelegate._scheduleTaskDlgt);
      this._scheduleTaskCurrZone = zoneSpec && (zoneSpec.onScheduleTask ? this.zone : parentDelegate._scheduleTaskCurrZone);
      this._invokeTaskZS = zoneSpec && (zoneSpec.onInvokeTask ? zoneSpec : parentDelegate._invokeTaskZS);
      this._invokeTaskDlgt = zoneSpec && (zoneSpec.onInvokeTask ? parentDelegate : parentDelegate._invokeTaskDlgt);
      this._invokeTaskCurrZone = zoneSpec && (zoneSpec.onInvokeTask ? this.zone : parentDelegate._invokeTaskCurrZone);
      this._cancelTaskZS = zoneSpec && (zoneSpec.onCancelTask ? zoneSpec : parentDelegate._cancelTaskZS);
      this._cancelTaskDlgt = zoneSpec && (zoneSpec.onCancelTask ? parentDelegate : parentDelegate._cancelTaskDlgt);
      this._cancelTaskCurrZone = zoneSpec && (zoneSpec.onCancelTask ? this.zone : parentDelegate._cancelTaskCurrZone);
      this._hasTaskZS = null;
      this._hasTaskDlgt = null;
      this._hasTaskDlgtOwner = null;
      this._hasTaskCurrZone = null;
      const zoneSpecHasTask = zoneSpec && zoneSpec.onHasTask;
      const parentHasTask = parentDelegate && parentDelegate._hasTaskZS;
      if (zoneSpecHasTask || parentHasTask) {
        this._hasTaskZS = zoneSpecHasTask ? zoneSpec : DELEGATE_ZS;
        this._hasTaskDlgt = parentDelegate;
        this._hasTaskDlgtOwner = this;
        this._hasTaskCurrZone = zone;
        if (!zoneSpec.onScheduleTask) {
          this._scheduleTaskZS = DELEGATE_ZS;
          this._scheduleTaskDlgt = parentDelegate;
          this._scheduleTaskCurrZone = this.zone;
        }
        if (!zoneSpec.onInvokeTask) {
          this._invokeTaskZS = DELEGATE_ZS;
          this._invokeTaskDlgt = parentDelegate;
          this._invokeTaskCurrZone = this.zone;
        }
        if (!zoneSpec.onCancelTask) {
          this._cancelTaskZS = DELEGATE_ZS;
          this._cancelTaskDlgt = parentDelegate;
          this._cancelTaskCurrZone = this.zone;
        }
      }
    }
    fork(targetZone, zoneSpec) {
      return this._forkZS ? this._forkZS.onFork(this._forkDlgt, this.zone, targetZone, zoneSpec) : new Zone2(targetZone, zoneSpec);
    }
    intercept(targetZone, callback, source) {
      return this._interceptZS ? this._interceptZS.onIntercept(this._interceptDlgt, this._interceptCurrZone, targetZone, callback, source) : callback;
    }
    invoke(targetZone, callback, applyThis, applyArgs, source) {
      return this._invokeZS ? this._invokeZS.onInvoke(this._invokeDlgt, this._invokeCurrZone, targetZone, callback, applyThis, applyArgs, source) : callback.apply(applyThis, applyArgs);
    }
    handleError(targetZone, error) {
      return this._handleErrorZS ? this._handleErrorZS.onHandleError(this._handleErrorDlgt, this._handleErrorCurrZone, targetZone, error) : true;
    }
    scheduleTask(targetZone, task) {
      let returnTask = task;
      if (this._scheduleTaskZS) {
        if (this._hasTaskZS) {
          returnTask._zoneDelegates.push(this._hasTaskDlgtOwner);
        }
        returnTask = this._scheduleTaskZS.onScheduleTask(this._scheduleTaskDlgt, this._scheduleTaskCurrZone, targetZone, task);
        if (!returnTask)
          returnTask = task;
      } else {
        if (task.scheduleFn) {
          task.scheduleFn(task);
        } else if (task.type == microTask) {
          scheduleMicroTask(task);
        } else {
          throw new Error("Task is missing scheduleFn.");
        }
      }
      return returnTask;
    }
    invokeTask(targetZone, task, applyThis, applyArgs) {
      return this._invokeTaskZS ? this._invokeTaskZS.onInvokeTask(this._invokeTaskDlgt, this._invokeTaskCurrZone, targetZone, task, applyThis, applyArgs) : task.callback.apply(applyThis, applyArgs);
    }
    cancelTask(targetZone, task) {
      let value;
      if (this._cancelTaskZS) {
        value = this._cancelTaskZS.onCancelTask(this._cancelTaskDlgt, this._cancelTaskCurrZone, targetZone, task);
      } else {
        if (!task.cancelFn) {
          throw Error("Task is not cancelable");
        }
        value = task.cancelFn(task);
      }
      return value;
    }
    hasTask(targetZone, isEmpty) {
      try {
        this._hasTaskZS && this._hasTaskZS.onHasTask(this._hasTaskDlgt, this._hasTaskCurrZone, targetZone, isEmpty);
      } catch (err) {
        this.handleError(targetZone, err);
      }
    }
    // tslint:disable-next-line:require-internal-with-underscore
    _updateTaskCount(type, count) {
      const counts = this._taskCounts;
      const prev = counts[type];
      const next = counts[type] = prev + count;
      if (next < 0) {
        throw new Error("More tasks executed then were scheduled.");
      }
      if (prev == 0 || next == 0) {
        const isEmpty = {
          microTask: counts["microTask"] > 0,
          macroTask: counts["macroTask"] > 0,
          eventTask: counts["eventTask"] > 0,
          change: type
        };
        this.hasTask(this.zone, isEmpty);
      }
    }
  }
  class ZoneTask {
    constructor(type, source, callback, options, scheduleFn, cancelFn) {
      this._zone = null;
      this.runCount = 0;
      this._zoneDelegates = null;
      this._state = "notScheduled";
      this.type = type;
      this.source = source;
      this.data = options;
      this.scheduleFn = scheduleFn;
      this.cancelFn = cancelFn;
      if (!callback) {
        throw new Error("callback is not defined");
      }
      this.callback = callback;
      const self2 = this;
      if (type === eventTask && options && options.useG) {
        this.invoke = ZoneTask.invokeTask;
      } else {
        this.invoke = function() {
          return ZoneTask.invokeTask.call(global, self2, this, arguments);
        };
      }
    }
    static invokeTask(task, target, args) {
      if (!task) {
        task = this;
      }
      _numberOfNestedTaskFrames++;
      try {
        task.runCount++;
        return task.zone.runTask(task, target, args);
      } finally {
        if (_numberOfNestedTaskFrames == 1) {
          drainMicroTaskQueue();
        }
        _numberOfNestedTaskFrames--;
      }
    }
    get zone() {
      return this._zone;
    }
    get state() {
      return this._state;
    }
    cancelScheduleRequest() {
      this._transitionTo(notScheduled, scheduling);
    }
    // tslint:disable-next-line:require-internal-with-underscore
    _transitionTo(toState, fromState1, fromState2) {
      if (this._state === fromState1 || this._state === fromState2) {
        this._state = toState;
        if (toState == notScheduled) {
          this._zoneDelegates = null;
        }
      } else {
        throw new Error(`${this.type} '${this.source}': can not transition to '${toState}', expecting state '${fromState1}'${fromState2 ? " or '" + fromState2 + "'" : ""}, was '${this._state}'.`);
      }
    }
    toString() {
      if (this.data && typeof this.data.handleId !== "undefined") {
        return this.data.handleId.toString();
      } else {
        return Object.prototype.toString.call(this);
      }
    }
    // add toJSON method to prevent cyclic error when
    // call JSON.stringify(zoneTask)
    toJSON() {
      return {
        type: this.type,
        state: this.state,
        source: this.source,
        zone: this.zone.name,
        runCount: this.runCount
      };
    }
  }
  const symbolSetTimeout = __symbol__("setTimeout");
  const symbolPromise = __symbol__("Promise");
  const symbolThen = __symbol__("then");
  let _microTaskQueue = [];
  let _isDrainingMicrotaskQueue = false;
  let nativeMicroTaskQueuePromise;
  function nativeScheduleMicroTask(func) {
    if (!nativeMicroTaskQueuePromise) {
      if (global[symbolPromise]) {
        nativeMicroTaskQueuePromise = global[symbolPromise].resolve(0);
      }
    }
    if (nativeMicroTaskQueuePromise) {
      let nativeThen = nativeMicroTaskQueuePromise[symbolThen];
      if (!nativeThen) {
        nativeThen = nativeMicroTaskQueuePromise["then"];
      }
      nativeThen.call(nativeMicroTaskQueuePromise, func);
    } else {
      global[symbolSetTimeout](func, 0);
    }
  }
  function scheduleMicroTask(task) {
    if (_numberOfNestedTaskFrames === 0 && _microTaskQueue.length === 0) {
      nativeScheduleMicroTask(drainMicroTaskQueue);
    }
    task && _microTaskQueue.push(task);
  }
  function drainMicroTaskQueue() {
    if (!_isDrainingMicrotaskQueue) {
      _isDrainingMicrotaskQueue = true;
      while (_microTaskQueue.length) {
        const queue = _microTaskQueue;
        _microTaskQueue = [];
        for (let i = 0; i < queue.length; i++) {
          const task = queue[i];
          try {
            task.zone.runTask(task, null, null);
          } catch (error) {
            _api.onUnhandledError(error);
          }
        }
      }
      _api.microtaskDrainDone();
      _isDrainingMicrotaskQueue = false;
    }
  }
  const NO_ZONE = { name: "NO ZONE" };
  const notScheduled = "notScheduled", scheduling = "scheduling", scheduled = "scheduled", running = "running", canceling = "canceling", unknown = "unknown";
  const microTask = "microTask", macroTask = "macroTask", eventTask = "eventTask";
  const patches = {};
  const _api = {
    symbol: __symbol__,
    currentZoneFrame: () => _currentZoneFrame,
    onUnhandledError: noop,
    microtaskDrainDone: noop,
    scheduleMicroTask,
    showUncaughtError: () => !Zone2[__symbol__("ignoreConsoleErrorUncaughtError")],
    patchEventTarget: () => [],
    patchOnProperties: noop,
    patchMethod: () => noop,
    bindArguments: () => [],
    patchThen: () => noop,
    patchMacroTask: () => noop,
    patchEventPrototype: () => noop,
    isIEOrEdge: () => false,
    getGlobalObjects: () => void 0,
    ObjectDefineProperty: () => noop,
    ObjectGetOwnPropertyDescriptor: () => void 0,
    ObjectCreate: () => void 0,
    ArraySlice: () => [],
    patchClass: () => noop,
    wrapWithCurrentZone: () => noop,
    filterProperties: () => [],
    attachOriginToPatched: () => noop,
    _redefineProperty: () => noop,
    patchCallbacks: () => noop,
    nativeScheduleMicroTask
  };
  let _currentZoneFrame = { parent: null, zone: new Zone2(null, null) };
  let _currentTask = null;
  let _numberOfNestedTaskFrames = 0;
  function noop() {
  }
  performanceMeasure("Zone", "Zone");
  return global["Zone"] = Zone2;
})(globalThis);
var ObjectGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var ObjectDefineProperty = Object.defineProperty;
var ObjectGetPrototypeOf = Object.getPrototypeOf;
var ObjectCreate = Object.create;
var ArraySlice = Array.prototype.slice;
var ADD_EVENT_LISTENER_STR = "addEventListener";
var REMOVE_EVENT_LISTENER_STR = "removeEventListener";
var ZONE_SYMBOL_ADD_EVENT_LISTENER = Zone.__symbol__(ADD_EVENT_LISTENER_STR);
var ZONE_SYMBOL_REMOVE_EVENT_LISTENER = Zone.__symbol__(REMOVE_EVENT_LISTENER_STR);
var TRUE_STR = "true";
var FALSE_STR = "false";
var ZONE_SYMBOL_PREFIX = Zone.__symbol__("");
function wrapWithCurrentZone(callback, source) {
  return Zone.current.wrap(callback, source);
}
function scheduleMacroTaskWithCurrentZone(source, callback, data, customSchedule, customCancel) {
  return Zone.current.scheduleMacroTask(source, callback, data, customSchedule, customCancel);
}
var zoneSymbol = Zone.__symbol__;
var isWindowExists = typeof window !== "undefined";
var internalWindow = isWindowExists ? window : void 0;
var _global = isWindowExists && internalWindow || globalThis;
var REMOVE_ATTRIBUTE = "removeAttribute";
function bindArguments(args, source) {
  for (let i = args.length - 1; i >= 0; i--) {
    if (typeof args[i] === "function") {
      args[i] = wrapWithCurrentZone(args[i], source + "_" + i);
    }
  }
  return args;
}
function patchPrototype(prototype, fnNames) {
  const source = prototype.constructor["name"];
  for (let i = 0; i < fnNames.length; i++) {
    const name = fnNames[i];
    const delegate = prototype[name];
    if (delegate) {
      const prototypeDesc = ObjectGetOwnPropertyDescriptor(prototype, name);
      if (!isPropertyWritable(prototypeDesc)) {
        continue;
      }
      prototype[name] = ((delegate2) => {
        const patched = function() {
          return delegate2.apply(this, bindArguments(arguments, source + "." + name));
        };
        attachOriginToPatched(patched, delegate2);
        return patched;
      })(delegate);
    }
  }
}
function isPropertyWritable(propertyDesc) {
  if (!propertyDesc) {
    return true;
  }
  if (propertyDesc.writable === false) {
    return false;
  }
  return !(typeof propertyDesc.get === "function" && typeof propertyDesc.set === "undefined");
}
var isWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
var isNode = !("nw" in _global) && typeof _global.process !== "undefined" && {}.toString.call(_global.process) === "[object process]";
var isBrowser = !isNode && !isWebWorker && !!(isWindowExists && internalWindow["HTMLElement"]);
var isMix = typeof _global.process !== "undefined" && {}.toString.call(_global.process) === "[object process]" && !isWebWorker && !!(isWindowExists && internalWindow["HTMLElement"]);
var zoneSymbolEventNames$1 = {};
var wrapFn = function(event) {
  event = event || _global.event;
  if (!event) {
    return;
  }
  let eventNameSymbol = zoneSymbolEventNames$1[event.type];
  if (!eventNameSymbol) {
    eventNameSymbol = zoneSymbolEventNames$1[event.type] = zoneSymbol("ON_PROPERTY" + event.type);
  }
  const target = this || event.target || _global;
  const listener = target[eventNameSymbol];
  let result;
  if (isBrowser && target === internalWindow && event.type === "error") {
    const errorEvent = event;
    result = listener && listener.call(this, errorEvent.message, errorEvent.filename, errorEvent.lineno, errorEvent.colno, errorEvent.error);
    if (result === true) {
      event.preventDefault();
    }
  } else {
    result = listener && listener.apply(this, arguments);
    if (result != void 0 && !result) {
      event.preventDefault();
    }
  }
  return result;
};
function patchProperty(obj, prop, prototype) {
  let desc = ObjectGetOwnPropertyDescriptor(obj, prop);
  if (!desc && prototype) {
    const prototypeDesc = ObjectGetOwnPropertyDescriptor(prototype, prop);
    if (prototypeDesc) {
      desc = { enumerable: true, configurable: true };
    }
  }
  if (!desc || !desc.configurable) {
    return;
  }
  const onPropPatchedSymbol = zoneSymbol("on" + prop + "patched");
  if (obj.hasOwnProperty(onPropPatchedSymbol) && obj[onPropPatchedSymbol]) {
    return;
  }
  delete desc.writable;
  delete desc.value;
  const originalDescGet = desc.get;
  const originalDescSet = desc.set;
  const eventName = prop.slice(2);
  let eventNameSymbol = zoneSymbolEventNames$1[eventName];
  if (!eventNameSymbol) {
    eventNameSymbol = zoneSymbolEventNames$1[eventName] = zoneSymbol("ON_PROPERTY" + eventName);
  }
  desc.set = function(newValue) {
    let target = this;
    if (!target && obj === _global) {
      target = _global;
    }
    if (!target) {
      return;
    }
    const previousValue = target[eventNameSymbol];
    if (typeof previousValue === "function") {
      target.removeEventListener(eventName, wrapFn);
    }
    originalDescSet && originalDescSet.call(target, null);
    target[eventNameSymbol] = newValue;
    if (typeof newValue === "function") {
      target.addEventListener(eventName, wrapFn, false);
    }
  };
  desc.get = function() {
    let target = this;
    if (!target && obj === _global) {
      target = _global;
    }
    if (!target) {
      return null;
    }
    const listener = target[eventNameSymbol];
    if (listener) {
      return listener;
    } else if (originalDescGet) {
      let value = originalDescGet.call(this);
      if (value) {
        desc.set.call(this, value);
        if (typeof target[REMOVE_ATTRIBUTE] === "function") {
          target.removeAttribute(prop);
        }
        return value;
      }
    }
    return null;
  };
  ObjectDefineProperty(obj, prop, desc);
  obj[onPropPatchedSymbol] = true;
}
function patchOnProperties(obj, properties, prototype) {
  if (properties) {
    for (let i = 0; i < properties.length; i++) {
      patchProperty(obj, "on" + properties[i], prototype);
    }
  } else {
    const onProperties = [];
    for (const prop in obj) {
      if (prop.slice(0, 2) == "on") {
        onProperties.push(prop);
      }
    }
    for (let j = 0; j < onProperties.length; j++) {
      patchProperty(obj, onProperties[j], prototype);
    }
  }
}
var originalInstanceKey = zoneSymbol("originalInstance");
function patchClass(className) {
  const OriginalClass = _global[className];
  if (!OriginalClass)
    return;
  _global[zoneSymbol(className)] = OriginalClass;
  _global[className] = function() {
    const a = bindArguments(arguments, className);
    switch (a.length) {
      case 0:
        this[originalInstanceKey] = new OriginalClass();
        break;
      case 1:
        this[originalInstanceKey] = new OriginalClass(a[0]);
        break;
      case 2:
        this[originalInstanceKey] = new OriginalClass(a[0], a[1]);
        break;
      case 3:
        this[originalInstanceKey] = new OriginalClass(a[0], a[1], a[2]);
        break;
      case 4:
        this[originalInstanceKey] = new OriginalClass(a[0], a[1], a[2], a[3]);
        break;
      default:
        throw new Error("Arg list too long.");
    }
  };
  attachOriginToPatched(_global[className], OriginalClass);
  const instance = new OriginalClass(function() {
  });
  let prop;
  for (prop in instance) {
    if (className === "XMLHttpRequest" && prop === "responseBlob")
      continue;
    (function(prop2) {
      if (typeof instance[prop2] === "function") {
        _global[className].prototype[prop2] = function() {
          return this[originalInstanceKey][prop2].apply(this[originalInstanceKey], arguments);
        };
      } else {
        ObjectDefineProperty(_global[className].prototype, prop2, {
          set: function(fn) {
            if (typeof fn === "function") {
              this[originalInstanceKey][prop2] = wrapWithCurrentZone(fn, className + "." + prop2);
              attachOriginToPatched(this[originalInstanceKey][prop2], fn);
            } else {
              this[originalInstanceKey][prop2] = fn;
            }
          },
          get: function() {
            return this[originalInstanceKey][prop2];
          }
        });
      }
    })(prop);
  }
  for (prop in OriginalClass) {
    if (prop !== "prototype" && OriginalClass.hasOwnProperty(prop)) {
      _global[className][prop] = OriginalClass[prop];
    }
  }
}
function patchMethod(target, name, patchFn) {
  let proto = target;
  while (proto && !proto.hasOwnProperty(name)) {
    proto = ObjectGetPrototypeOf(proto);
  }
  if (!proto && target[name]) {
    proto = target;
  }
  const delegateName = zoneSymbol(name);
  let delegate = null;
  if (proto && (!(delegate = proto[delegateName]) || !proto.hasOwnProperty(delegateName))) {
    delegate = proto[delegateName] = proto[name];
    const desc = proto && ObjectGetOwnPropertyDescriptor(proto, name);
    if (isPropertyWritable(desc)) {
      const patchDelegate = patchFn(delegate, delegateName, name);
      proto[name] = function() {
        return patchDelegate(this, arguments);
      };
      attachOriginToPatched(proto[name], delegate);
    }
  }
  return delegate;
}
function patchMacroTask(obj, funcName, metaCreator) {
  let setNative = null;
  function scheduleTask(task) {
    const data = task.data;
    data.args[data.cbIdx] = function() {
      task.invoke.apply(this, arguments);
    };
    setNative.apply(data.target, data.args);
    return task;
  }
  setNative = patchMethod(obj, funcName, (delegate) => function(self2, args) {
    const meta = metaCreator(self2, args);
    if (meta.cbIdx >= 0 && typeof args[meta.cbIdx] === "function") {
      return scheduleMacroTaskWithCurrentZone(meta.name, args[meta.cbIdx], meta, scheduleTask);
    } else {
      return delegate.apply(self2, args);
    }
  });
}
function attachOriginToPatched(patched, original) {
  patched[zoneSymbol("OriginalDelegate")] = original;
}
var isDetectedIEOrEdge = false;
var ieOrEdge = false;
function isIE() {
  try {
    const ua = internalWindow.navigator.userAgent;
    if (ua.indexOf("MSIE ") !== -1 || ua.indexOf("Trident/") !== -1) {
      return true;
    }
  } catch (error) {
  }
  return false;
}
function isIEOrEdge() {
  if (isDetectedIEOrEdge) {
    return ieOrEdge;
  }
  isDetectedIEOrEdge = true;
  try {
    const ua = internalWindow.navigator.userAgent;
    if (ua.indexOf("MSIE ") !== -1 || ua.indexOf("Trident/") !== -1 || ua.indexOf("Edge/") !== -1) {
      ieOrEdge = true;
    }
  } catch (error) {
  }
  return ieOrEdge;
}
Zone.__load_patch("ZoneAwarePromise", (global, Zone2, api) => {
  const ObjectGetOwnPropertyDescriptor2 = Object.getOwnPropertyDescriptor;
  const ObjectDefineProperty2 = Object.defineProperty;
  function readableObjectToString(obj) {
    if (obj && obj.toString === Object.prototype.toString) {
      const className = obj.constructor && obj.constructor.name;
      return (className ? className : "") + ": " + JSON.stringify(obj);
    }
    return obj ? obj.toString() : Object.prototype.toString.call(obj);
  }
  const __symbol__ = api.symbol;
  const _uncaughtPromiseErrors = [];
  const isDisableWrappingUncaughtPromiseRejection = global[__symbol__("DISABLE_WRAPPING_UNCAUGHT_PROMISE_REJECTION")] !== false;
  const symbolPromise = __symbol__("Promise");
  const symbolThen = __symbol__("then");
  const creationTrace = "__creationTrace__";
  api.onUnhandledError = (e) => {
    if (api.showUncaughtError()) {
      const rejection = e && e.rejection;
      if (rejection) {
        console.error("Unhandled Promise rejection:", rejection instanceof Error ? rejection.message : rejection, "; Zone:", e.zone.name, "; Task:", e.task && e.task.source, "; Value:", rejection, rejection instanceof Error ? rejection.stack : void 0);
      } else {
        console.error(e);
      }
    }
  };
  api.microtaskDrainDone = () => {
    while (_uncaughtPromiseErrors.length) {
      const uncaughtPromiseError = _uncaughtPromiseErrors.shift();
      try {
        uncaughtPromiseError.zone.runGuarded(() => {
          if (uncaughtPromiseError.throwOriginal) {
            throw uncaughtPromiseError.rejection;
          }
          throw uncaughtPromiseError;
        });
      } catch (error) {
        handleUnhandledRejection(error);
      }
    }
  };
  const UNHANDLED_PROMISE_REJECTION_HANDLER_SYMBOL = __symbol__("unhandledPromiseRejectionHandler");
  function handleUnhandledRejection(e) {
    api.onUnhandledError(e);
    try {
      const handler = Zone2[UNHANDLED_PROMISE_REJECTION_HANDLER_SYMBOL];
      if (typeof handler === "function") {
        handler.call(this, e);
      }
    } catch (err) {
    }
  }
  function isThenable(value) {
    return value && value.then;
  }
  function forwardResolution(value) {
    return value;
  }
  function forwardRejection(rejection) {
    return ZoneAwarePromise.reject(rejection);
  }
  const symbolState = __symbol__("state");
  const symbolValue = __symbol__("value");
  const symbolFinally = __symbol__("finally");
  const symbolParentPromiseValue = __symbol__("parentPromiseValue");
  const symbolParentPromiseState = __symbol__("parentPromiseState");
  const source = "Promise.then";
  const UNRESOLVED = null;
  const RESOLVED = true;
  const REJECTED = false;
  const REJECTED_NO_CATCH = 0;
  function makeResolver(promise, state) {
    return (v) => {
      try {
        resolvePromise(promise, state, v);
      } catch (err) {
        resolvePromise(promise, false, err);
      }
    };
  }
  const once = function() {
    let wasCalled = false;
    return function wrapper(wrappedFunction) {
      return function() {
        if (wasCalled) {
          return;
        }
        wasCalled = true;
        wrappedFunction.apply(null, arguments);
      };
    };
  };
  const TYPE_ERROR = "Promise resolved with itself";
  const CURRENT_TASK_TRACE_SYMBOL = __symbol__("currentTaskTrace");
  function resolvePromise(promise, state, value) {
    const onceWrapper = once();
    if (promise === value) {
      throw new TypeError(TYPE_ERROR);
    }
    if (promise[symbolState] === UNRESOLVED) {
      let then = null;
      try {
        if (typeof value === "object" || typeof value === "function") {
          then = value && value.then;
        }
      } catch (err) {
        onceWrapper(() => {
          resolvePromise(promise, false, err);
        })();
        return promise;
      }
      if (state !== REJECTED && value instanceof ZoneAwarePromise && value.hasOwnProperty(symbolState) && value.hasOwnProperty(symbolValue) && value[symbolState] !== UNRESOLVED) {
        clearRejectedNoCatch(value);
        resolvePromise(promise, value[symbolState], value[symbolValue]);
      } else if (state !== REJECTED && typeof then === "function") {
        try {
          then.call(value, onceWrapper(makeResolver(promise, state)), onceWrapper(makeResolver(promise, false)));
        } catch (err) {
          onceWrapper(() => {
            resolvePromise(promise, false, err);
          })();
        }
      } else {
        promise[symbolState] = state;
        const queue = promise[symbolValue];
        promise[symbolValue] = value;
        if (promise[symbolFinally] === symbolFinally) {
          if (state === RESOLVED) {
            promise[symbolState] = promise[symbolParentPromiseState];
            promise[symbolValue] = promise[symbolParentPromiseValue];
          }
        }
        if (state === REJECTED && value instanceof Error) {
          const trace = Zone2.currentTask && Zone2.currentTask.data && Zone2.currentTask.data[creationTrace];
          if (trace) {
            ObjectDefineProperty2(value, CURRENT_TASK_TRACE_SYMBOL, { configurable: true, enumerable: false, writable: true, value: trace });
          }
        }
        for (let i = 0; i < queue.length; ) {
          scheduleResolveOrReject(promise, queue[i++], queue[i++], queue[i++], queue[i++]);
        }
        if (queue.length == 0 && state == REJECTED) {
          promise[symbolState] = REJECTED_NO_CATCH;
          let uncaughtPromiseError = value;
          try {
            throw new Error("Uncaught (in promise): " + readableObjectToString(value) + (value && value.stack ? "\n" + value.stack : ""));
          } catch (err) {
            uncaughtPromiseError = err;
          }
          if (isDisableWrappingUncaughtPromiseRejection) {
            uncaughtPromiseError.throwOriginal = true;
          }
          uncaughtPromiseError.rejection = value;
          uncaughtPromiseError.promise = promise;
          uncaughtPromiseError.zone = Zone2.current;
          uncaughtPromiseError.task = Zone2.currentTask;
          _uncaughtPromiseErrors.push(uncaughtPromiseError);
          api.scheduleMicroTask();
        }
      }
    }
    return promise;
  }
  const REJECTION_HANDLED_HANDLER = __symbol__("rejectionHandledHandler");
  function clearRejectedNoCatch(promise) {
    if (promise[symbolState] === REJECTED_NO_CATCH) {
      try {
        const handler = Zone2[REJECTION_HANDLED_HANDLER];
        if (handler && typeof handler === "function") {
          handler.call(this, { rejection: promise[symbolValue], promise });
        }
      } catch (err) {
      }
      promise[symbolState] = REJECTED;
      for (let i = 0; i < _uncaughtPromiseErrors.length; i++) {
        if (promise === _uncaughtPromiseErrors[i].promise) {
          _uncaughtPromiseErrors.splice(i, 1);
        }
      }
    }
  }
  function scheduleResolveOrReject(promise, zone, chainPromise, onFulfilled, onRejected) {
    clearRejectedNoCatch(promise);
    const promiseState = promise[symbolState];
    const delegate = promiseState ? typeof onFulfilled === "function" ? onFulfilled : forwardResolution : typeof onRejected === "function" ? onRejected : forwardRejection;
    zone.scheduleMicroTask(source, () => {
      try {
        const parentPromiseValue = promise[symbolValue];
        const isFinallyPromise = !!chainPromise && symbolFinally === chainPromise[symbolFinally];
        if (isFinallyPromise) {
          chainPromise[symbolParentPromiseValue] = parentPromiseValue;
          chainPromise[symbolParentPromiseState] = promiseState;
        }
        const value = zone.run(delegate, void 0, isFinallyPromise && delegate !== forwardRejection && delegate !== forwardResolution ? [] : [parentPromiseValue]);
        resolvePromise(chainPromise, true, value);
      } catch (error) {
        resolvePromise(chainPromise, false, error);
      }
    }, chainPromise);
  }
  const ZONE_AWARE_PROMISE_TO_STRING = "function ZoneAwarePromise() { [native code] }";
  const noop = function() {
  };
  const AggregateError = global.AggregateError;
  class ZoneAwarePromise {
    static toString() {
      return ZONE_AWARE_PROMISE_TO_STRING;
    }
    static resolve(value) {
      return resolvePromise(new this(null), RESOLVED, value);
    }
    static reject(error) {
      return resolvePromise(new this(null), REJECTED, error);
    }
    static any(values) {
      if (!values || typeof values[Symbol.iterator] !== "function") {
        return Promise.reject(new AggregateError([], "All promises were rejected"));
      }
      const promises = [];
      let count = 0;
      try {
        for (let v of values) {
          count++;
          promises.push(ZoneAwarePromise.resolve(v));
        }
      } catch (err) {
        return Promise.reject(new AggregateError([], "All promises were rejected"));
      }
      if (count === 0) {
        return Promise.reject(new AggregateError([], "All promises were rejected"));
      }
      let finished = false;
      const errors = [];
      return new ZoneAwarePromise((resolve, reject) => {
        for (let i = 0; i < promises.length; i++) {
          promises[i].then((v) => {
            if (finished) {
              return;
            }
            finished = true;
            resolve(v);
          }, (err) => {
            errors.push(err);
            count--;
            if (count === 0) {
              finished = true;
              reject(new AggregateError(errors, "All promises were rejected"));
            }
          });
        }
      });
    }
    static race(values) {
      let resolve;
      let reject;
      let promise = new this((res, rej) => {
        resolve = res;
        reject = rej;
      });
      function onResolve(value) {
        resolve(value);
      }
      function onReject(error) {
        reject(error);
      }
      for (let value of values) {
        if (!isThenable(value)) {
          value = this.resolve(value);
        }
        value.then(onResolve, onReject);
      }
      return promise;
    }
    static all(values) {
      return ZoneAwarePromise.allWithCallback(values);
    }
    static allSettled(values) {
      const P = this && this.prototype instanceof ZoneAwarePromise ? this : ZoneAwarePromise;
      return P.allWithCallback(values, {
        thenCallback: (value) => ({ status: "fulfilled", value }),
        errorCallback: (err) => ({ status: "rejected", reason: err })
      });
    }
    static allWithCallback(values, callback) {
      let resolve;
      let reject;
      let promise = new this((res, rej) => {
        resolve = res;
        reject = rej;
      });
      let unresolvedCount = 2;
      let valueIndex = 0;
      const resolvedValues = [];
      for (let value of values) {
        if (!isThenable(value)) {
          value = this.resolve(value);
        }
        const curValueIndex = valueIndex;
        try {
          value.then((value2) => {
            resolvedValues[curValueIndex] = callback ? callback.thenCallback(value2) : value2;
            unresolvedCount--;
            if (unresolvedCount === 0) {
              resolve(resolvedValues);
            }
          }, (err) => {
            if (!callback) {
              reject(err);
            } else {
              resolvedValues[curValueIndex] = callback.errorCallback(err);
              unresolvedCount--;
              if (unresolvedCount === 0) {
                resolve(resolvedValues);
              }
            }
          });
        } catch (thenErr) {
          reject(thenErr);
        }
        unresolvedCount++;
        valueIndex++;
      }
      unresolvedCount -= 2;
      if (unresolvedCount === 0) {
        resolve(resolvedValues);
      }
      return promise;
    }
    constructor(executor) {
      const promise = this;
      if (!(promise instanceof ZoneAwarePromise)) {
        throw new Error("Must be an instanceof Promise.");
      }
      promise[symbolState] = UNRESOLVED;
      promise[symbolValue] = [];
      try {
        const onceWrapper = once();
        executor && executor(onceWrapper(makeResolver(promise, RESOLVED)), onceWrapper(makeResolver(promise, REJECTED)));
      } catch (error) {
        resolvePromise(promise, false, error);
      }
    }
    get [Symbol.toStringTag]() {
      return "Promise";
    }
    get [Symbol.species]() {
      return ZoneAwarePromise;
    }
    then(onFulfilled, onRejected) {
      let C = this.constructor?.[Symbol.species];
      if (!C || typeof C !== "function") {
        C = this.constructor || ZoneAwarePromise;
      }
      const chainPromise = new C(noop);
      const zone = Zone2.current;
      if (this[symbolState] == UNRESOLVED) {
        this[symbolValue].push(zone, chainPromise, onFulfilled, onRejected);
      } else {
        scheduleResolveOrReject(this, zone, chainPromise, onFulfilled, onRejected);
      }
      return chainPromise;
    }
    catch(onRejected) {
      return this.then(null, onRejected);
    }
    finally(onFinally) {
      let C = this.constructor?.[Symbol.species];
      if (!C || typeof C !== "function") {
        C = ZoneAwarePromise;
      }
      const chainPromise = new C(noop);
      chainPromise[symbolFinally] = symbolFinally;
      const zone = Zone2.current;
      if (this[symbolState] == UNRESOLVED) {
        this[symbolValue].push(zone, chainPromise, onFinally, onFinally);
      } else {
        scheduleResolveOrReject(this, zone, chainPromise, onFinally, onFinally);
      }
      return chainPromise;
    }
  }
  ZoneAwarePromise["resolve"] = ZoneAwarePromise.resolve;
  ZoneAwarePromise["reject"] = ZoneAwarePromise.reject;
  ZoneAwarePromise["race"] = ZoneAwarePromise.race;
  ZoneAwarePromise["all"] = ZoneAwarePromise.all;
  const NativePromise = global[symbolPromise] = global["Promise"];
  global["Promise"] = ZoneAwarePromise;
  const symbolThenPatched = __symbol__("thenPatched");
  function patchThen(Ctor) {
    const proto = Ctor.prototype;
    const prop = ObjectGetOwnPropertyDescriptor2(proto, "then");
    if (prop && (prop.writable === false || !prop.configurable)) {
      return;
    }
    const originalThen = proto.then;
    proto[symbolThen] = originalThen;
    Ctor.prototype.then = function(onResolve, onReject) {
      const wrapped = new ZoneAwarePromise((resolve, reject) => {
        originalThen.call(this, resolve, reject);
      });
      return wrapped.then(onResolve, onReject);
    };
    Ctor[symbolThenPatched] = true;
  }
  api.patchThen = patchThen;
  function zoneify(fn) {
    return function(self2, args) {
      let resultPromise = fn.apply(self2, args);
      if (resultPromise instanceof ZoneAwarePromise) {
        return resultPromise;
      }
      let ctor = resultPromise.constructor;
      if (!ctor[symbolThenPatched]) {
        patchThen(ctor);
      }
      return resultPromise;
    };
  }
  if (NativePromise) {
    patchThen(NativePromise);
    patchMethod(global, "fetch", (delegate) => zoneify(delegate));
  }
  Promise[Zone2.__symbol__("uncaughtPromiseErrors")] = _uncaughtPromiseErrors;
  return ZoneAwarePromise;
});
Zone.__load_patch("toString", (global) => {
  const originalFunctionToString = Function.prototype.toString;
  const ORIGINAL_DELEGATE_SYMBOL = zoneSymbol("OriginalDelegate");
  const PROMISE_SYMBOL = zoneSymbol("Promise");
  const ERROR_SYMBOL = zoneSymbol("Error");
  const newFunctionToString = function toString() {
    if (typeof this === "function") {
      const originalDelegate = this[ORIGINAL_DELEGATE_SYMBOL];
      if (originalDelegate) {
        if (typeof originalDelegate === "function") {
          return originalFunctionToString.call(originalDelegate);
        } else {
          return Object.prototype.toString.call(originalDelegate);
        }
      }
      if (this === Promise) {
        const nativePromise = global[PROMISE_SYMBOL];
        if (nativePromise) {
          return originalFunctionToString.call(nativePromise);
        }
      }
      if (this === Error) {
        const nativeError = global[ERROR_SYMBOL];
        if (nativeError) {
          return originalFunctionToString.call(nativeError);
        }
      }
    }
    return originalFunctionToString.call(this);
  };
  newFunctionToString[ORIGINAL_DELEGATE_SYMBOL] = originalFunctionToString;
  Function.prototype.toString = newFunctionToString;
  const originalObjectToString = Object.prototype.toString;
  const PROMISE_OBJECT_TO_STRING = "[object Promise]";
  Object.prototype.toString = function() {
    if (typeof Promise === "function" && this instanceof Promise) {
      return PROMISE_OBJECT_TO_STRING;
    }
    return originalObjectToString.call(this);
  };
});
var passiveSupported = false;
if (typeof window !== "undefined") {
  try {
    const options = Object.defineProperty({}, "passive", {
      get: function() {
        passiveSupported = true;
      }
    });
    window.addEventListener("test", options, options);
    window.removeEventListener("test", options, options);
  } catch (err) {
    passiveSupported = false;
  }
}
var OPTIMIZED_ZONE_EVENT_TASK_DATA = {
  useG: true
};
var zoneSymbolEventNames = {};
var globalSources = {};
var EVENT_NAME_SYMBOL_REGX = new RegExp("^" + ZONE_SYMBOL_PREFIX + "(\\w+)(true|false)$");
var IMMEDIATE_PROPAGATION_SYMBOL = zoneSymbol("propagationStopped");
function prepareEventNames(eventName, eventNameToString) {
  const falseEventName = (eventNameToString ? eventNameToString(eventName) : eventName) + FALSE_STR;
  const trueEventName = (eventNameToString ? eventNameToString(eventName) : eventName) + TRUE_STR;
  const symbol = ZONE_SYMBOL_PREFIX + falseEventName;
  const symbolCapture = ZONE_SYMBOL_PREFIX + trueEventName;
  zoneSymbolEventNames[eventName] = {};
  zoneSymbolEventNames[eventName][FALSE_STR] = symbol;
  zoneSymbolEventNames[eventName][TRUE_STR] = symbolCapture;
}
function patchEventTarget(_global2, api, apis, patchOptions) {
  const ADD_EVENT_LISTENER = patchOptions && patchOptions.add || ADD_EVENT_LISTENER_STR;
  const REMOVE_EVENT_LISTENER = patchOptions && patchOptions.rm || REMOVE_EVENT_LISTENER_STR;
  const LISTENERS_EVENT_LISTENER = patchOptions && patchOptions.listeners || "eventListeners";
  const REMOVE_ALL_LISTENERS_EVENT_LISTENER = patchOptions && patchOptions.rmAll || "removeAllListeners";
  const zoneSymbolAddEventListener = zoneSymbol(ADD_EVENT_LISTENER);
  const ADD_EVENT_LISTENER_SOURCE = "." + ADD_EVENT_LISTENER + ":";
  const PREPEND_EVENT_LISTENER = "prependListener";
  const PREPEND_EVENT_LISTENER_SOURCE = "." + PREPEND_EVENT_LISTENER + ":";
  const invokeTask = function(task, target, event) {
    if (task.isRemoved) {
      return;
    }
    const delegate = task.callback;
    if (typeof delegate === "object" && delegate.handleEvent) {
      task.callback = (event2) => delegate.handleEvent(event2);
      task.originalDelegate = delegate;
    }
    let error;
    try {
      task.invoke(task, target, [event]);
    } catch (err) {
      error = err;
    }
    const options = task.options;
    if (options && typeof options === "object" && options.once) {
      const delegate2 = task.originalDelegate ? task.originalDelegate : task.callback;
      target[REMOVE_EVENT_LISTENER].call(target, event.type, delegate2, options);
    }
    return error;
  };
  function globalCallback(context, event, isCapture) {
    event = event || _global2.event;
    if (!event) {
      return;
    }
    const target = context || event.target || _global2;
    const tasks = target[zoneSymbolEventNames[event.type][isCapture ? TRUE_STR : FALSE_STR]];
    if (tasks) {
      const errors = [];
      if (tasks.length === 1) {
        const err = invokeTask(tasks[0], target, event);
        err && errors.push(err);
      } else {
        const copyTasks = tasks.slice();
        for (let i = 0; i < copyTasks.length; i++) {
          if (event && event[IMMEDIATE_PROPAGATION_SYMBOL] === true) {
            break;
          }
          const err = invokeTask(copyTasks[i], target, event);
          err && errors.push(err);
        }
      }
      if (errors.length === 1) {
        throw errors[0];
      } else {
        for (let i = 0; i < errors.length; i++) {
          const err = errors[i];
          api.nativeScheduleMicroTask(() => {
            throw err;
          });
        }
      }
    }
  }
  const globalZoneAwareCallback = function(event) {
    return globalCallback(this, event, false);
  };
  const globalZoneAwareCaptureCallback = function(event) {
    return globalCallback(this, event, true);
  };
  function patchEventTargetMethods(obj, patchOptions2) {
    if (!obj) {
      return false;
    }
    let useGlobalCallback = true;
    if (patchOptions2 && patchOptions2.useG !== void 0) {
      useGlobalCallback = patchOptions2.useG;
    }
    const validateHandler = patchOptions2 && patchOptions2.vh;
    let checkDuplicate = true;
    if (patchOptions2 && patchOptions2.chkDup !== void 0) {
      checkDuplicate = patchOptions2.chkDup;
    }
    let returnTarget = false;
    if (patchOptions2 && patchOptions2.rt !== void 0) {
      returnTarget = patchOptions2.rt;
    }
    let proto = obj;
    while (proto && !proto.hasOwnProperty(ADD_EVENT_LISTENER)) {
      proto = ObjectGetPrototypeOf(proto);
    }
    if (!proto && obj[ADD_EVENT_LISTENER]) {
      proto = obj;
    }
    if (!proto) {
      return false;
    }
    if (proto[zoneSymbolAddEventListener]) {
      return false;
    }
    const eventNameToString = patchOptions2 && patchOptions2.eventNameToString;
    const taskData = {};
    const nativeAddEventListener = proto[zoneSymbolAddEventListener] = proto[ADD_EVENT_LISTENER];
    const nativeRemoveEventListener = proto[zoneSymbol(REMOVE_EVENT_LISTENER)] = proto[REMOVE_EVENT_LISTENER];
    const nativeListeners = proto[zoneSymbol(LISTENERS_EVENT_LISTENER)] = proto[LISTENERS_EVENT_LISTENER];
    const nativeRemoveAllListeners = proto[zoneSymbol(REMOVE_ALL_LISTENERS_EVENT_LISTENER)] = proto[REMOVE_ALL_LISTENERS_EVENT_LISTENER];
    let nativePrependEventListener;
    if (patchOptions2 && patchOptions2.prepend) {
      nativePrependEventListener = proto[zoneSymbol(patchOptions2.prepend)] = proto[patchOptions2.prepend];
    }
    function buildEventListenerOptions(options, passive) {
      if (!passiveSupported && typeof options === "object" && options) {
        return !!options.capture;
      }
      if (!passiveSupported || !passive) {
        return options;
      }
      if (typeof options === "boolean") {
        return { capture: options, passive: true };
      }
      if (!options) {
        return { passive: true };
      }
      if (typeof options === "object" && options.passive !== false) {
        return { ...options, passive: true };
      }
      return options;
    }
    const customScheduleGlobal = function(task) {
      if (taskData.isExisting) {
        return;
      }
      return nativeAddEventListener.call(taskData.target, taskData.eventName, taskData.capture ? globalZoneAwareCaptureCallback : globalZoneAwareCallback, taskData.options);
    };
    const customCancelGlobal = function(task) {
      if (!task.isRemoved) {
        const symbolEventNames = zoneSymbolEventNames[task.eventName];
        let symbolEventName;
        if (symbolEventNames) {
          symbolEventName = symbolEventNames[task.capture ? TRUE_STR : FALSE_STR];
        }
        const existingTasks = symbolEventName && task.target[symbolEventName];
        if (existingTasks) {
          for (let i = 0; i < existingTasks.length; i++) {
            const existingTask = existingTasks[i];
            if (existingTask === task) {
              existingTasks.splice(i, 1);
              task.isRemoved = true;
              if (existingTasks.length === 0) {
                task.allRemoved = true;
                task.target[symbolEventName] = null;
              }
              break;
            }
          }
        }
      }
      if (!task.allRemoved) {
        return;
      }
      return nativeRemoveEventListener.call(task.target, task.eventName, task.capture ? globalZoneAwareCaptureCallback : globalZoneAwareCallback, task.options);
    };
    const customScheduleNonGlobal = function(task) {
      return nativeAddEventListener.call(taskData.target, taskData.eventName, task.invoke, taskData.options);
    };
    const customSchedulePrepend = function(task) {
      return nativePrependEventListener.call(taskData.target, taskData.eventName, task.invoke, taskData.options);
    };
    const customCancelNonGlobal = function(task) {
      return nativeRemoveEventListener.call(task.target, task.eventName, task.invoke, task.options);
    };
    const customSchedule = useGlobalCallback ? customScheduleGlobal : customScheduleNonGlobal;
    const customCancel = useGlobalCallback ? customCancelGlobal : customCancelNonGlobal;
    const compareTaskCallbackVsDelegate = function(task, delegate) {
      const typeOfDelegate = typeof delegate;
      return typeOfDelegate === "function" && task.callback === delegate || typeOfDelegate === "object" && task.originalDelegate === delegate;
    };
    const compare = patchOptions2 && patchOptions2.diff ? patchOptions2.diff : compareTaskCallbackVsDelegate;
    const unpatchedEvents = Zone[zoneSymbol("UNPATCHED_EVENTS")];
    const passiveEvents = _global2[zoneSymbol("PASSIVE_EVENTS")];
    const makeAddListener = function(nativeListener, addSource, customScheduleFn, customCancelFn, returnTarget2 = false, prepend = false) {
      return function() {
        const target = this || _global2;
        let eventName = arguments[0];
        if (patchOptions2 && patchOptions2.transferEventName) {
          eventName = patchOptions2.transferEventName(eventName);
        }
        let delegate = arguments[1];
        if (!delegate) {
          return nativeListener.apply(this, arguments);
        }
        if (isNode && eventName === "uncaughtException") {
          return nativeListener.apply(this, arguments);
        }
        let isHandleEvent = false;
        if (typeof delegate !== "function") {
          if (!delegate.handleEvent) {
            return nativeListener.apply(this, arguments);
          }
          isHandleEvent = true;
        }
        if (validateHandler && !validateHandler(nativeListener, delegate, target, arguments)) {
          return;
        }
        const passive = passiveSupported && !!passiveEvents && passiveEvents.indexOf(eventName) !== -1;
        const options = buildEventListenerOptions(arguments[2], passive);
        if (unpatchedEvents) {
          for (let i = 0; i < unpatchedEvents.length; i++) {
            if (eventName === unpatchedEvents[i]) {
              if (passive) {
                return nativeListener.call(target, eventName, delegate, options);
              } else {
                return nativeListener.apply(this, arguments);
              }
            }
          }
        }
        const capture = !options ? false : typeof options === "boolean" ? true : options.capture;
        const once = options && typeof options === "object" ? options.once : false;
        const zone = Zone.current;
        let symbolEventNames = zoneSymbolEventNames[eventName];
        if (!symbolEventNames) {
          prepareEventNames(eventName, eventNameToString);
          symbolEventNames = zoneSymbolEventNames[eventName];
        }
        const symbolEventName = symbolEventNames[capture ? TRUE_STR : FALSE_STR];
        let existingTasks = target[symbolEventName];
        let isExisting = false;
        if (existingTasks) {
          isExisting = true;
          if (checkDuplicate) {
            for (let i = 0; i < existingTasks.length; i++) {
              if (compare(existingTasks[i], delegate)) {
                return;
              }
            }
          }
        } else {
          existingTasks = target[symbolEventName] = [];
        }
        let source;
        const constructorName = target.constructor["name"];
        const targetSource = globalSources[constructorName];
        if (targetSource) {
          source = targetSource[eventName];
        }
        if (!source) {
          source = constructorName + addSource + (eventNameToString ? eventNameToString(eventName) : eventName);
        }
        taskData.options = options;
        if (once) {
          taskData.options.once = false;
        }
        taskData.target = target;
        taskData.capture = capture;
        taskData.eventName = eventName;
        taskData.isExisting = isExisting;
        const data = useGlobalCallback ? OPTIMIZED_ZONE_EVENT_TASK_DATA : void 0;
        if (data) {
          data.taskData = taskData;
        }
        const task = zone.scheduleEventTask(source, delegate, data, customScheduleFn, customCancelFn);
        taskData.target = null;
        if (data) {
          data.taskData = null;
        }
        if (once) {
          options.once = true;
        }
        if (!(!passiveSupported && typeof task.options === "boolean")) {
          task.options = options;
        }
        task.target = target;
        task.capture = capture;
        task.eventName = eventName;
        if (isHandleEvent) {
          task.originalDelegate = delegate;
        }
        if (!prepend) {
          existingTasks.push(task);
        } else {
          existingTasks.unshift(task);
        }
        if (returnTarget2) {
          return target;
        }
      };
    };
    proto[ADD_EVENT_LISTENER] = makeAddListener(nativeAddEventListener, ADD_EVENT_LISTENER_SOURCE, customSchedule, customCancel, returnTarget);
    if (nativePrependEventListener) {
      proto[PREPEND_EVENT_LISTENER] = makeAddListener(nativePrependEventListener, PREPEND_EVENT_LISTENER_SOURCE, customSchedulePrepend, customCancel, returnTarget, true);
    }
    proto[REMOVE_EVENT_LISTENER] = function() {
      const target = this || _global2;
      let eventName = arguments[0];
      if (patchOptions2 && patchOptions2.transferEventName) {
        eventName = patchOptions2.transferEventName(eventName);
      }
      const options = arguments[2];
      const capture = !options ? false : typeof options === "boolean" ? true : options.capture;
      const delegate = arguments[1];
      if (!delegate) {
        return nativeRemoveEventListener.apply(this, arguments);
      }
      if (validateHandler && !validateHandler(nativeRemoveEventListener, delegate, target, arguments)) {
        return;
      }
      const symbolEventNames = zoneSymbolEventNames[eventName];
      let symbolEventName;
      if (symbolEventNames) {
        symbolEventName = symbolEventNames[capture ? TRUE_STR : FALSE_STR];
      }
      const existingTasks = symbolEventName && target[symbolEventName];
      if (existingTasks) {
        for (let i = 0; i < existingTasks.length; i++) {
          const existingTask = existingTasks[i];
          if (compare(existingTask, delegate)) {
            existingTasks.splice(i, 1);
            existingTask.isRemoved = true;
            if (existingTasks.length === 0) {
              existingTask.allRemoved = true;
              target[symbolEventName] = null;
              if (typeof eventName === "string") {
                const onPropertySymbol = ZONE_SYMBOL_PREFIX + "ON_PROPERTY" + eventName;
                target[onPropertySymbol] = null;
              }
            }
            existingTask.zone.cancelTask(existingTask);
            if (returnTarget) {
              return target;
            }
            return;
          }
        }
      }
      return nativeRemoveEventListener.apply(this, arguments);
    };
    proto[LISTENERS_EVENT_LISTENER] = function() {
      const target = this || _global2;
      let eventName = arguments[0];
      if (patchOptions2 && patchOptions2.transferEventName) {
        eventName = patchOptions2.transferEventName(eventName);
      }
      const listeners = [];
      const tasks = findEventTasks(target, eventNameToString ? eventNameToString(eventName) : eventName);
      for (let i = 0; i < tasks.length; i++) {
        const task = tasks[i];
        let delegate = task.originalDelegate ? task.originalDelegate : task.callback;
        listeners.push(delegate);
      }
      return listeners;
    };
    proto[REMOVE_ALL_LISTENERS_EVENT_LISTENER] = function() {
      const target = this || _global2;
      let eventName = arguments[0];
      if (!eventName) {
        const keys = Object.keys(target);
        for (let i = 0; i < keys.length; i++) {
          const prop = keys[i];
          const match = EVENT_NAME_SYMBOL_REGX.exec(prop);
          let evtName = match && match[1];
          if (evtName && evtName !== "removeListener") {
            this[REMOVE_ALL_LISTENERS_EVENT_LISTENER].call(this, evtName);
          }
        }
        this[REMOVE_ALL_LISTENERS_EVENT_LISTENER].call(this, "removeListener");
      } else {
        if (patchOptions2 && patchOptions2.transferEventName) {
          eventName = patchOptions2.transferEventName(eventName);
        }
        const symbolEventNames = zoneSymbolEventNames[eventName];
        if (symbolEventNames) {
          const symbolEventName = symbolEventNames[FALSE_STR];
          const symbolCaptureEventName = symbolEventNames[TRUE_STR];
          const tasks = target[symbolEventName];
          const captureTasks = target[symbolCaptureEventName];
          if (tasks) {
            const removeTasks = tasks.slice();
            for (let i = 0; i < removeTasks.length; i++) {
              const task = removeTasks[i];
              let delegate = task.originalDelegate ? task.originalDelegate : task.callback;
              this[REMOVE_EVENT_LISTENER].call(this, eventName, delegate, task.options);
            }
          }
          if (captureTasks) {
            const removeTasks = captureTasks.slice();
            for (let i = 0; i < removeTasks.length; i++) {
              const task = removeTasks[i];
              let delegate = task.originalDelegate ? task.originalDelegate : task.callback;
              this[REMOVE_EVENT_LISTENER].call(this, eventName, delegate, task.options);
            }
          }
        }
      }
      if (returnTarget) {
        return this;
      }
    };
    attachOriginToPatched(proto[ADD_EVENT_LISTENER], nativeAddEventListener);
    attachOriginToPatched(proto[REMOVE_EVENT_LISTENER], nativeRemoveEventListener);
    if (nativeRemoveAllListeners) {
      attachOriginToPatched(proto[REMOVE_ALL_LISTENERS_EVENT_LISTENER], nativeRemoveAllListeners);
    }
    if (nativeListeners) {
      attachOriginToPatched(proto[LISTENERS_EVENT_LISTENER], nativeListeners);
    }
    return true;
  }
  let results = [];
  for (let i = 0; i < apis.length; i++) {
    results[i] = patchEventTargetMethods(apis[i], patchOptions);
  }
  return results;
}
function findEventTasks(target, eventName) {
  if (!eventName) {
    const foundTasks = [];
    for (let prop in target) {
      const match = EVENT_NAME_SYMBOL_REGX.exec(prop);
      let evtName = match && match[1];
      if (evtName && (!eventName || evtName === eventName)) {
        const tasks = target[prop];
        if (tasks) {
          for (let i = 0; i < tasks.length; i++) {
            foundTasks.push(tasks[i]);
          }
        }
      }
    }
    return foundTasks;
  }
  let symbolEventName = zoneSymbolEventNames[eventName];
  if (!symbolEventName) {
    prepareEventNames(eventName);
    symbolEventName = zoneSymbolEventNames[eventName];
  }
  const captureFalseTasks = target[symbolEventName[FALSE_STR]];
  const captureTrueTasks = target[symbolEventName[TRUE_STR]];
  if (!captureFalseTasks) {
    return captureTrueTasks ? captureTrueTasks.slice() : [];
  } else {
    return captureTrueTasks ? captureFalseTasks.concat(captureTrueTasks) : captureFalseTasks.slice();
  }
}
function patchEventPrototype(global, api) {
  const Event = global["Event"];
  if (Event && Event.prototype) {
    api.patchMethod(Event.prototype, "stopImmediatePropagation", (delegate) => function(self2, args) {
      self2[IMMEDIATE_PROPAGATION_SYMBOL] = true;
      delegate && delegate.apply(self2, args);
    });
  }
}
function patchCallbacks(api, target, targetName, method, callbacks) {
  const symbol = Zone.__symbol__(method);
  if (target[symbol]) {
    return;
  }
  const nativeDelegate = target[symbol] = target[method];
  target[method] = function(name, opts, options) {
    if (opts && opts.prototype) {
      callbacks.forEach(function(callback) {
        const source = `${targetName}.${method}::` + callback;
        const prototype = opts.prototype;
        try {
          if (prototype.hasOwnProperty(callback)) {
            const descriptor = api.ObjectGetOwnPropertyDescriptor(prototype, callback);
            if (descriptor && descriptor.value) {
              descriptor.value = api.wrapWithCurrentZone(descriptor.value, source);
              api._redefineProperty(opts.prototype, callback, descriptor);
            } else if (prototype[callback]) {
              prototype[callback] = api.wrapWithCurrentZone(prototype[callback], source);
            }
          } else if (prototype[callback]) {
            prototype[callback] = api.wrapWithCurrentZone(prototype[callback], source);
          }
        } catch {
        }
      });
    }
    return nativeDelegate.call(target, name, opts, options);
  };
  api.attachOriginToPatched(target[method], nativeDelegate);
}
function filterProperties(target, onProperties, ignoreProperties) {
  if (!ignoreProperties || ignoreProperties.length === 0) {
    return onProperties;
  }
  const tip = ignoreProperties.filter((ip) => ip.target === target);
  if (!tip || tip.length === 0) {
    return onProperties;
  }
  const targetIgnoreProperties = tip[0].ignoreProperties;
  return onProperties.filter((op) => targetIgnoreProperties.indexOf(op) === -1);
}
function patchFilteredProperties(target, onProperties, ignoreProperties, prototype) {
  if (!target) {
    return;
  }
  const filteredProperties = filterProperties(target, onProperties, ignoreProperties);
  patchOnProperties(target, filteredProperties, prototype);
}
function getOnEventNames(target) {
  return Object.getOwnPropertyNames(target).filter((name) => name.startsWith("on") && name.length > 2).map((name) => name.substring(2));
}
function propertyDescriptorPatch(api, _global2) {
  if (isNode && !isMix) {
    return;
  }
  if (Zone[api.symbol("patchEvents")]) {
    return;
  }
  const ignoreProperties = _global2["__Zone_ignore_on_properties"];
  let patchTargets = [];
  if (isBrowser) {
    const internalWindow2 = window;
    patchTargets = patchTargets.concat([
      "Document",
      "SVGElement",
      "Element",
      "HTMLElement",
      "HTMLBodyElement",
      "HTMLMediaElement",
      "HTMLFrameSetElement",
      "HTMLFrameElement",
      "HTMLIFrameElement",
      "HTMLMarqueeElement",
      "Worker"
    ]);
    const ignoreErrorProperties = isIE() ? [{ target: internalWindow2, ignoreProperties: ["error"] }] : [];
    patchFilteredProperties(internalWindow2, getOnEventNames(internalWindow2), ignoreProperties ? ignoreProperties.concat(ignoreErrorProperties) : ignoreProperties, ObjectGetPrototypeOf(internalWindow2));
  }
  patchTargets = patchTargets.concat([
    "XMLHttpRequest",
    "XMLHttpRequestEventTarget",
    "IDBIndex",
    "IDBRequest",
    "IDBOpenDBRequest",
    "IDBDatabase",
    "IDBTransaction",
    "IDBCursor",
    "WebSocket"
  ]);
  for (let i = 0; i < patchTargets.length; i++) {
    const target = _global2[patchTargets[i]];
    target && target.prototype && patchFilteredProperties(target.prototype, getOnEventNames(target.prototype), ignoreProperties);
  }
}
Zone.__load_patch("util", (global, Zone2, api) => {
  const eventNames = getOnEventNames(global);
  api.patchOnProperties = patchOnProperties;
  api.patchMethod = patchMethod;
  api.bindArguments = bindArguments;
  api.patchMacroTask = patchMacroTask;
  const SYMBOL_BLACK_LISTED_EVENTS = Zone2.__symbol__("BLACK_LISTED_EVENTS");
  const SYMBOL_UNPATCHED_EVENTS = Zone2.__symbol__("UNPATCHED_EVENTS");
  if (global[SYMBOL_UNPATCHED_EVENTS]) {
    global[SYMBOL_BLACK_LISTED_EVENTS] = global[SYMBOL_UNPATCHED_EVENTS];
  }
  if (global[SYMBOL_BLACK_LISTED_EVENTS]) {
    Zone2[SYMBOL_BLACK_LISTED_EVENTS] = Zone2[SYMBOL_UNPATCHED_EVENTS] = global[SYMBOL_BLACK_LISTED_EVENTS];
  }
  api.patchEventPrototype = patchEventPrototype;
  api.patchEventTarget = patchEventTarget;
  api.isIEOrEdge = isIEOrEdge;
  api.ObjectDefineProperty = ObjectDefineProperty;
  api.ObjectGetOwnPropertyDescriptor = ObjectGetOwnPropertyDescriptor;
  api.ObjectCreate = ObjectCreate;
  api.ArraySlice = ArraySlice;
  api.patchClass = patchClass;
  api.wrapWithCurrentZone = wrapWithCurrentZone;
  api.filterProperties = filterProperties;
  api.attachOriginToPatched = attachOriginToPatched;
  api._redefineProperty = Object.defineProperty;
  api.patchCallbacks = patchCallbacks;
  api.getGlobalObjects = () => ({
    globalSources,
    zoneSymbolEventNames,
    eventNames,
    isBrowser,
    isMix,
    isNode,
    TRUE_STR,
    FALSE_STR,
    ZONE_SYMBOL_PREFIX,
    ADD_EVENT_LISTENER_STR,
    REMOVE_EVENT_LISTENER_STR
  });
});
function patchQueueMicrotask(global, api) {
  api.patchMethod(global, "queueMicrotask", (delegate) => {
    return function(self2, args) {
      Zone.current.scheduleMicroTask("queueMicrotask", args[0]);
    };
  });
}
var taskSymbol = zoneSymbol("zoneTask");
function patchTimer(window2, setName, cancelName, nameSuffix) {
  let setNative = null;
  let clearNative = null;
  setName += nameSuffix;
  cancelName += nameSuffix;
  const tasksByHandleId = {};
  function scheduleTask(task) {
    const data = task.data;
    data.args[0] = function() {
      return task.invoke.apply(this, arguments);
    };
    data.handleId = setNative.apply(window2, data.args);
    return task;
  }
  function clearTask(task) {
    return clearNative.call(window2, task.data.handleId);
  }
  setNative = patchMethod(window2, setName, (delegate) => function(self2, args) {
    if (typeof args[0] === "function") {
      const options = {
        isPeriodic: nameSuffix === "Interval",
        delay: nameSuffix === "Timeout" || nameSuffix === "Interval" ? args[1] || 0 : void 0,
        args
      };
      const callback = args[0];
      args[0] = function timer() {
        try {
          return callback.apply(this, arguments);
        } finally {
          if (!options.isPeriodic) {
            if (typeof options.handleId === "number") {
              delete tasksByHandleId[options.handleId];
            } else if (options.handleId) {
              options.handleId[taskSymbol] = null;
            }
          }
        }
      };
      const task = scheduleMacroTaskWithCurrentZone(setName, args[0], options, scheduleTask, clearTask);
      if (!task) {
        return task;
      }
      const handle = task.data.handleId;
      if (typeof handle === "number") {
        tasksByHandleId[handle] = task;
      } else if (handle) {
        handle[taskSymbol] = task;
      }
      if (handle && handle.ref && handle.unref && typeof handle.ref === "function" && typeof handle.unref === "function") {
        task.ref = handle.ref.bind(handle);
        task.unref = handle.unref.bind(handle);
      }
      if (typeof handle === "number" || handle) {
        return handle;
      }
      return task;
    } else {
      return delegate.apply(window2, args);
    }
  });
  clearNative = patchMethod(window2, cancelName, (delegate) => function(self2, args) {
    const id = args[0];
    let task;
    if (typeof id === "number") {
      task = tasksByHandleId[id];
    } else {
      task = id && id[taskSymbol];
      if (!task) {
        task = id;
      }
    }
    if (task && typeof task.type === "string") {
      if (task.state !== "notScheduled" && (task.cancelFn && task.data.isPeriodic || task.runCount === 0)) {
        if (typeof id === "number") {
          delete tasksByHandleId[id];
        } else if (id) {
          id[taskSymbol] = null;
        }
        task.zone.cancelTask(task);
      }
    } else {
      delegate.apply(window2, args);
    }
  });
}
function patchCustomElements(_global2, api) {
  const { isBrowser: isBrowser2, isMix: isMix2 } = api.getGlobalObjects();
  if (!isBrowser2 && !isMix2 || !_global2["customElements"] || !("customElements" in _global2)) {
    return;
  }
  const callbacks = ["connectedCallback", "disconnectedCallback", "adoptedCallback", "attributeChangedCallback"];
  api.patchCallbacks(api, _global2.customElements, "customElements", "define", callbacks);
}
function eventTargetPatch(_global2, api) {
  if (Zone[api.symbol("patchEventTarget")]) {
    return;
  }
  const { eventNames, zoneSymbolEventNames: zoneSymbolEventNames2, TRUE_STR: TRUE_STR2, FALSE_STR: FALSE_STR2, ZONE_SYMBOL_PREFIX: ZONE_SYMBOL_PREFIX2 } = api.getGlobalObjects();
  for (let i = 0; i < eventNames.length; i++) {
    const eventName = eventNames[i];
    const falseEventName = eventName + FALSE_STR2;
    const trueEventName = eventName + TRUE_STR2;
    const symbol = ZONE_SYMBOL_PREFIX2 + falseEventName;
    const symbolCapture = ZONE_SYMBOL_PREFIX2 + trueEventName;
    zoneSymbolEventNames2[eventName] = {};
    zoneSymbolEventNames2[eventName][FALSE_STR2] = symbol;
    zoneSymbolEventNames2[eventName][TRUE_STR2] = symbolCapture;
  }
  const EVENT_TARGET = _global2["EventTarget"];
  if (!EVENT_TARGET || !EVENT_TARGET.prototype) {
    return;
  }
  api.patchEventTarget(_global2, api, [EVENT_TARGET && EVENT_TARGET.prototype]);
  return true;
}
function patchEvent(global, api) {
  api.patchEventPrototype(global, api);
}
Zone.__load_patch("legacy", (global) => {
  const legacyPatch = global[Zone.__symbol__("legacyPatch")];
  if (legacyPatch) {
    legacyPatch();
  }
});
Zone.__load_patch("timers", (global) => {
  const set = "set";
  const clear = "clear";
  patchTimer(global, set, clear, "Timeout");
  patchTimer(global, set, clear, "Interval");
  patchTimer(global, set, clear, "Immediate");
});
Zone.__load_patch("requestAnimationFrame", (global) => {
  patchTimer(global, "request", "cancel", "AnimationFrame");
  patchTimer(global, "mozRequest", "mozCancel", "AnimationFrame");
  patchTimer(global, "webkitRequest", "webkitCancel", "AnimationFrame");
});
Zone.__load_patch("blocking", (global, Zone2) => {
  const blockingMethods = ["alert", "prompt", "confirm"];
  for (let i = 0; i < blockingMethods.length; i++) {
    const name = blockingMethods[i];
    patchMethod(global, name, (delegate, symbol, name2) => {
      return function(s, args) {
        return Zone2.current.run(delegate, global, args, name2);
      };
    });
  }
});
Zone.__load_patch("EventTarget", (global, Zone2, api) => {
  patchEvent(global, api);
  eventTargetPatch(global, api);
  const XMLHttpRequestEventTarget = global["XMLHttpRequestEventTarget"];
  if (XMLHttpRequestEventTarget && XMLHttpRequestEventTarget.prototype) {
    api.patchEventTarget(global, api, [XMLHttpRequestEventTarget.prototype]);
  }
});
Zone.__load_patch("MutationObserver", (global, Zone2, api) => {
  patchClass("MutationObserver");
  patchClass("WebKitMutationObserver");
});
Zone.__load_patch("IntersectionObserver", (global, Zone2, api) => {
  patchClass("IntersectionObserver");
});
Zone.__load_patch("FileReader", (global, Zone2, api) => {
  patchClass("FileReader");
});
Zone.__load_patch("on_property", (global, Zone2, api) => {
  propertyDescriptorPatch(api, global);
});
Zone.__load_patch("customElements", (global, Zone2, api) => {
  patchCustomElements(global, api);
});
Zone.__load_patch("XHR", (global, Zone2) => {
  patchXHR(global);
  const XHR_TASK = zoneSymbol("xhrTask");
  const XHR_SYNC = zoneSymbol("xhrSync");
  const XHR_LISTENER = zoneSymbol("xhrListener");
  const XHR_SCHEDULED = zoneSymbol("xhrScheduled");
  const XHR_URL = zoneSymbol("xhrURL");
  const XHR_ERROR_BEFORE_SCHEDULED = zoneSymbol("xhrErrorBeforeScheduled");
  function patchXHR(window2) {
    const XMLHttpRequest = window2["XMLHttpRequest"];
    if (!XMLHttpRequest) {
      return;
    }
    const XMLHttpRequestPrototype = XMLHttpRequest.prototype;
    function findPendingTask(target) {
      return target[XHR_TASK];
    }
    let oriAddListener = XMLHttpRequestPrototype[ZONE_SYMBOL_ADD_EVENT_LISTENER];
    let oriRemoveListener = XMLHttpRequestPrototype[ZONE_SYMBOL_REMOVE_EVENT_LISTENER];
    if (!oriAddListener) {
      const XMLHttpRequestEventTarget = window2["XMLHttpRequestEventTarget"];
      if (XMLHttpRequestEventTarget) {
        const XMLHttpRequestEventTargetPrototype = XMLHttpRequestEventTarget.prototype;
        oriAddListener = XMLHttpRequestEventTargetPrototype[ZONE_SYMBOL_ADD_EVENT_LISTENER];
        oriRemoveListener = XMLHttpRequestEventTargetPrototype[ZONE_SYMBOL_REMOVE_EVENT_LISTENER];
      }
    }
    const READY_STATE_CHANGE = "readystatechange";
    const SCHEDULED = "scheduled";
    function scheduleTask(task) {
      const data = task.data;
      const target = data.target;
      target[XHR_SCHEDULED] = false;
      target[XHR_ERROR_BEFORE_SCHEDULED] = false;
      const listener = target[XHR_LISTENER];
      if (!oriAddListener) {
        oriAddListener = target[ZONE_SYMBOL_ADD_EVENT_LISTENER];
        oriRemoveListener = target[ZONE_SYMBOL_REMOVE_EVENT_LISTENER];
      }
      if (listener) {
        oriRemoveListener.call(target, READY_STATE_CHANGE, listener);
      }
      const newListener = target[XHR_LISTENER] = () => {
        if (target.readyState === target.DONE) {
          if (!data.aborted && target[XHR_SCHEDULED] && task.state === SCHEDULED) {
            const loadTasks = target[Zone2.__symbol__("loadfalse")];
            if (target.status !== 0 && loadTasks && loadTasks.length > 0) {
              const oriInvoke = task.invoke;
              task.invoke = function() {
                const loadTasks2 = target[Zone2.__symbol__("loadfalse")];
                for (let i = 0; i < loadTasks2.length; i++) {
                  if (loadTasks2[i] === task) {
                    loadTasks2.splice(i, 1);
                  }
                }
                if (!data.aborted && task.state === SCHEDULED) {
                  oriInvoke.call(task);
                }
              };
              loadTasks.push(task);
            } else {
              task.invoke();
            }
          } else if (!data.aborted && target[XHR_SCHEDULED] === false) {
            target[XHR_ERROR_BEFORE_SCHEDULED] = true;
          }
        }
      };
      oriAddListener.call(target, READY_STATE_CHANGE, newListener);
      const storedTask = target[XHR_TASK];
      if (!storedTask) {
        target[XHR_TASK] = task;
      }
      sendNative.apply(target, data.args);
      target[XHR_SCHEDULED] = true;
      return task;
    }
    function placeholderCallback() {
    }
    function clearTask(task) {
      const data = task.data;
      data.aborted = true;
      return abortNative.apply(data.target, data.args);
    }
    const openNative = patchMethod(XMLHttpRequestPrototype, "open", () => function(self2, args) {
      self2[XHR_SYNC] = args[2] == false;
      self2[XHR_URL] = args[1];
      return openNative.apply(self2, args);
    });
    const XMLHTTPREQUEST_SOURCE = "XMLHttpRequest.send";
    const fetchTaskAborting = zoneSymbol("fetchTaskAborting");
    const fetchTaskScheduling = zoneSymbol("fetchTaskScheduling");
    const sendNative = patchMethod(XMLHttpRequestPrototype, "send", () => function(self2, args) {
      if (Zone2.current[fetchTaskScheduling] === true) {
        return sendNative.apply(self2, args);
      }
      if (self2[XHR_SYNC]) {
        return sendNative.apply(self2, args);
      } else {
        const options = { target: self2, url: self2[XHR_URL], isPeriodic: false, args, aborted: false };
        const task = scheduleMacroTaskWithCurrentZone(XMLHTTPREQUEST_SOURCE, placeholderCallback, options, scheduleTask, clearTask);
        if (self2 && self2[XHR_ERROR_BEFORE_SCHEDULED] === true && !options.aborted && task.state === SCHEDULED) {
          task.invoke();
        }
      }
    });
    const abortNative = patchMethod(XMLHttpRequestPrototype, "abort", () => function(self2, args) {
      const task = findPendingTask(self2);
      if (task && typeof task.type == "string") {
        if (task.cancelFn == null || task.data && task.data.aborted) {
          return;
        }
        task.zone.cancelTask(task);
      } else if (Zone2.current[fetchTaskAborting] === true) {
        return abortNative.apply(self2, args);
      }
    });
  }
});
Zone.__load_patch("geolocation", (global) => {
  if (global["navigator"] && global["navigator"].geolocation) {
    patchPrototype(global["navigator"].geolocation, ["getCurrentPosition", "watchPosition"]);
  }
});
Zone.__load_patch("PromiseRejectionEvent", (global, Zone2) => {
  function findPromiseRejectionHandler(evtName) {
    return function(e) {
      const eventTasks = findEventTasks(global, evtName);
      eventTasks.forEach((eventTask) => {
        const PromiseRejectionEvent = global["PromiseRejectionEvent"];
        if (PromiseRejectionEvent) {
          const evt = new PromiseRejectionEvent(evtName, { promise: e.promise, reason: e.rejection });
          eventTask.invoke(evt);
        }
      });
    };
  }
  if (global["PromiseRejectionEvent"]) {
    Zone2[zoneSymbol("unhandledPromiseRejectionHandler")] = findPromiseRejectionHandler("unhandledrejection");
    Zone2[zoneSymbol("rejectionHandledHandler")] = findPromiseRejectionHandler("rejectionhandled");
  }
});
Zone.__load_patch("queueMicrotask", (global, Zone2, api) => {
  patchQueueMicrotask(global, api);
});

// node_modules/@angular/localize/fesm2022/localize.mjs
var BLOCK_MARKER$1 = ":";
var _SerializerVisitor = class {
  visitText(text, context) {
    return text.value;
  }
  visitContainer(container, context) {
    return `[${container.children.map((child) => child.visit(this)).join(", ")}]`;
  }
  visitIcu(icu, context) {
    const strCases = Object.keys(icu.cases).map((k) => `${k} {${icu.cases[k].visit(this)}}`);
    return `{${icu.expression}, ${icu.type}, ${strCases.join(", ")}}`;
  }
  visitTagPlaceholder(ph, context) {
    return ph.isVoid ? `<ph tag name="${ph.startName}"/>` : `<ph tag name="${ph.startName}">${ph.children.map((child) => child.visit(this)).join(", ")}</ph name="${ph.closeName}">`;
  }
  visitPlaceholder(ph, context) {
    return ph.value ? `<ph name="${ph.name}">${ph.value}</ph>` : `<ph name="${ph.name}"/>`;
  }
  visitIcuPlaceholder(ph, context) {
    return `<ph icu name="${ph.name}">${ph.value.visit(this)}</ph>`;
  }
  visitBlockPlaceholder(ph, context) {
    return `<ph block name="${ph.startName}">${ph.children.map((child) => child.visit(this)).join(", ")}</ph name="${ph.closeName}">`;
  }
};
var serializerVisitor = new _SerializerVisitor();
var Endian;
(function(Endian2) {
  Endian2[Endian2["Little"] = 0] = "Little";
  Endian2[Endian2["Big"] = 1] = "Big";
})(Endian || (Endian = {}));
function findEndOfBlock(cooked, raw) {
  for (let cookedIndex = 1, rawIndex = 1; cookedIndex < cooked.length; cookedIndex++, rawIndex++) {
    if (raw[rawIndex] === "\\") {
      rawIndex++;
    } else if (cooked[cookedIndex] === BLOCK_MARKER$1) {
      return cookedIndex;
    }
  }
  throw new Error(`Unterminated $localize metadata block in "${raw}".`);
}
var $localize$1 = function(messageParts, ...expressions) {
  if ($localize$1.translate) {
    const translation = $localize$1.translate(messageParts, expressions);
    messageParts = translation[0];
    expressions = translation[1];
  }
  let message = stripBlock(messageParts[0], messageParts.raw[0]);
  for (let i = 1; i < messageParts.length; i++) {
    message += expressions[i - 1] + stripBlock(messageParts[i], messageParts.raw[i]);
  }
  return message;
};
var BLOCK_MARKER = ":";
function stripBlock(messagePart, rawMessagePart) {
  return rawMessagePart.charAt(0) === BLOCK_MARKER ? messagePart.substring(findEndOfBlock(messagePart, rawMessagePart) + 1) : messagePart;
}

// node_modules/@angular/localize/fesm2022/init.mjs
globalThis.$localize = $localize$1;

// src/main/webapp/app/polyfills.ts
var process = __toESM(require_browser());
window.global = window;
window["process"] = process;
/*! Bundled license information:

zone.js/fesm2015/zone.js:
  (**
   * @license Angular v<unknown>
   * (c) 2010-2022 Google LLC. https://angular.io/
   * License: MIT
   *)

@angular/localize/fesm2022/localize.mjs:
  (**
   * @license Angular v17.0.8
   * (c) 2010-2022 Google LLC. https://angular.io/
   * License: MIT
   *)

@angular/localize/fesm2022/init.mjs:
  (**
   * @license Angular v17.0.8
   * (c) 2010-2022 Google LLC. https://angular.io/
   * License: MIT
   *)
*/


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9wcm9jZXNzL2Jyb3dzZXIuanMiLCJub2RlX21vZHVsZXMvem9uZS5qcy9mZXNtMjAxNS96b25lLmpzIiwibm9kZV9tb2R1bGVzL0Bhbmd1bGFyL2xvY2FsaXplL2Zlc20yMDIyL2xvY2FsaXplLm1qcyIsIm5vZGVfbW9kdWxlcy9AYW5ndWxhci9sb2NhbGl6ZS9mZXNtMjAyMi9pbml0Lm1qcyIsInNyYy9tYWluL3dlYmFwcC9hcHAvcG9seWZpbGxzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNoaW0gZm9yIHVzaW5nIHByb2Nlc3MgaW4gYnJvd3NlclxudmFyIHByb2Nlc3MgPSBtb2R1bGUuZXhwb3J0cyA9IHt9O1xuXG4vLyBjYWNoZWQgZnJvbSB3aGF0ZXZlciBnbG9iYWwgaXMgcHJlc2VudCBzbyB0aGF0IHRlc3QgcnVubmVycyB0aGF0IHN0dWIgaXRcbi8vIGRvbid0IGJyZWFrIHRoaW5ncy4gIEJ1dCB3ZSBuZWVkIHRvIHdyYXAgaXQgaW4gYSB0cnkgY2F0Y2ggaW4gY2FzZSBpdCBpc1xuLy8gd3JhcHBlZCBpbiBzdHJpY3QgbW9kZSBjb2RlIHdoaWNoIGRvZXNuJ3QgZGVmaW5lIGFueSBnbG9iYWxzLiAgSXQncyBpbnNpZGUgYVxuLy8gZnVuY3Rpb24gYmVjYXVzZSB0cnkvY2F0Y2hlcyBkZW9wdGltaXplIGluIGNlcnRhaW4gZW5naW5lcy5cblxudmFyIGNhY2hlZFNldFRpbWVvdXQ7XG52YXIgY2FjaGVkQ2xlYXJUaW1lb3V0O1xuXG5mdW5jdGlvbiBkZWZhdWx0U2V0VGltb3V0KCkge1xuICAgIHRocm93IG5ldyBFcnJvcignc2V0VGltZW91dCBoYXMgbm90IGJlZW4gZGVmaW5lZCcpO1xufVxuZnVuY3Rpb24gZGVmYXVsdENsZWFyVGltZW91dCAoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdjbGVhclRpbWVvdXQgaGFzIG5vdCBiZWVuIGRlZmluZWQnKTtcbn1cbihmdW5jdGlvbiAoKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgaWYgKHR5cGVvZiBzZXRUaW1lb3V0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBjYWNoZWRTZXRUaW1lb3V0ID0gc2V0VGltZW91dDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNhY2hlZFNldFRpbWVvdXQgPSBkZWZhdWx0U2V0VGltb3V0O1xuICAgICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjYWNoZWRTZXRUaW1lb3V0ID0gZGVmYXVsdFNldFRpbW91dDtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgaWYgKHR5cGVvZiBjbGVhclRpbWVvdXQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIGNhY2hlZENsZWFyVGltZW91dCA9IGNsZWFyVGltZW91dDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNhY2hlZENsZWFyVGltZW91dCA9IGRlZmF1bHRDbGVhclRpbWVvdXQ7XG4gICAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNhY2hlZENsZWFyVGltZW91dCA9IGRlZmF1bHRDbGVhclRpbWVvdXQ7XG4gICAgfVxufSAoKSlcbmZ1bmN0aW9uIHJ1blRpbWVvdXQoZnVuKSB7XG4gICAgaWYgKGNhY2hlZFNldFRpbWVvdXQgPT09IHNldFRpbWVvdXQpIHtcbiAgICAgICAgLy9ub3JtYWwgZW52aXJvbWVudHMgaW4gc2FuZSBzaXR1YXRpb25zXG4gICAgICAgIHJldHVybiBzZXRUaW1lb3V0KGZ1biwgMCk7XG4gICAgfVxuICAgIC8vIGlmIHNldFRpbWVvdXQgd2Fzbid0IGF2YWlsYWJsZSBidXQgd2FzIGxhdHRlciBkZWZpbmVkXG4gICAgaWYgKChjYWNoZWRTZXRUaW1lb3V0ID09PSBkZWZhdWx0U2V0VGltb3V0IHx8ICFjYWNoZWRTZXRUaW1lb3V0KSAmJiBzZXRUaW1lb3V0KSB7XG4gICAgICAgIGNhY2hlZFNldFRpbWVvdXQgPSBzZXRUaW1lb3V0O1xuICAgICAgICByZXR1cm4gc2V0VGltZW91dChmdW4sIDApO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgICAvLyB3aGVuIHdoZW4gc29tZWJvZHkgaGFzIHNjcmV3ZWQgd2l0aCBzZXRUaW1lb3V0IGJ1dCBubyBJLkUuIG1hZGRuZXNzXG4gICAgICAgIHJldHVybiBjYWNoZWRTZXRUaW1lb3V0KGZ1biwgMCk7XG4gICAgfSBjYXRjaChlKXtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIFdoZW4gd2UgYXJlIGluIEkuRS4gYnV0IHRoZSBzY3JpcHQgaGFzIGJlZW4gZXZhbGVkIHNvIEkuRS4gZG9lc24ndCB0cnVzdCB0aGUgZ2xvYmFsIG9iamVjdCB3aGVuIGNhbGxlZCBub3JtYWxseVxuICAgICAgICAgICAgcmV0dXJuIGNhY2hlZFNldFRpbWVvdXQuY2FsbChudWxsLCBmdW4sIDApO1xuICAgICAgICB9IGNhdGNoKGUpe1xuICAgICAgICAgICAgLy8gc2FtZSBhcyBhYm92ZSBidXQgd2hlbiBpdCdzIGEgdmVyc2lvbiBvZiBJLkUuIHRoYXQgbXVzdCBoYXZlIHRoZSBnbG9iYWwgb2JqZWN0IGZvciAndGhpcycsIGhvcGZ1bGx5IG91ciBjb250ZXh0IGNvcnJlY3Qgb3RoZXJ3aXNlIGl0IHdpbGwgdGhyb3cgYSBnbG9iYWwgZXJyb3JcbiAgICAgICAgICAgIHJldHVybiBjYWNoZWRTZXRUaW1lb3V0LmNhbGwodGhpcywgZnVuLCAwKTtcbiAgICAgICAgfVxuICAgIH1cblxuXG59XG5mdW5jdGlvbiBydW5DbGVhclRpbWVvdXQobWFya2VyKSB7XG4gICAgaWYgKGNhY2hlZENsZWFyVGltZW91dCA9PT0gY2xlYXJUaW1lb3V0KSB7XG4gICAgICAgIC8vbm9ybWFsIGVudmlyb21lbnRzIGluIHNhbmUgc2l0dWF0aW9uc1xuICAgICAgICByZXR1cm4gY2xlYXJUaW1lb3V0KG1hcmtlcik7XG4gICAgfVxuICAgIC8vIGlmIGNsZWFyVGltZW91dCB3YXNuJ3QgYXZhaWxhYmxlIGJ1dCB3YXMgbGF0dGVyIGRlZmluZWRcbiAgICBpZiAoKGNhY2hlZENsZWFyVGltZW91dCA9PT0gZGVmYXVsdENsZWFyVGltZW91dCB8fCAhY2FjaGVkQ2xlYXJUaW1lb3V0KSAmJiBjbGVhclRpbWVvdXQpIHtcbiAgICAgICAgY2FjaGVkQ2xlYXJUaW1lb3V0ID0gY2xlYXJUaW1lb3V0O1xuICAgICAgICByZXR1cm4gY2xlYXJUaW1lb3V0KG1hcmtlcik7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIC8vIHdoZW4gd2hlbiBzb21lYm9keSBoYXMgc2NyZXdlZCB3aXRoIHNldFRpbWVvdXQgYnV0IG5vIEkuRS4gbWFkZG5lc3NcbiAgICAgICAgcmV0dXJuIGNhY2hlZENsZWFyVGltZW91dChtYXJrZXIpO1xuICAgIH0gY2F0Y2ggKGUpe1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gV2hlbiB3ZSBhcmUgaW4gSS5FLiBidXQgdGhlIHNjcmlwdCBoYXMgYmVlbiBldmFsZWQgc28gSS5FLiBkb2Vzbid0ICB0cnVzdCB0aGUgZ2xvYmFsIG9iamVjdCB3aGVuIGNhbGxlZCBub3JtYWxseVxuICAgICAgICAgICAgcmV0dXJuIGNhY2hlZENsZWFyVGltZW91dC5jYWxsKG51bGwsIG1hcmtlcik7XG4gICAgICAgIH0gY2F0Y2ggKGUpe1xuICAgICAgICAgICAgLy8gc2FtZSBhcyBhYm92ZSBidXQgd2hlbiBpdCdzIGEgdmVyc2lvbiBvZiBJLkUuIHRoYXQgbXVzdCBoYXZlIHRoZSBnbG9iYWwgb2JqZWN0IGZvciAndGhpcycsIGhvcGZ1bGx5IG91ciBjb250ZXh0IGNvcnJlY3Qgb3RoZXJ3aXNlIGl0IHdpbGwgdGhyb3cgYSBnbG9iYWwgZXJyb3IuXG4gICAgICAgICAgICAvLyBTb21lIHZlcnNpb25zIG9mIEkuRS4gaGF2ZSBkaWZmZXJlbnQgcnVsZXMgZm9yIGNsZWFyVGltZW91dCB2cyBzZXRUaW1lb3V0XG4gICAgICAgICAgICByZXR1cm4gY2FjaGVkQ2xlYXJUaW1lb3V0LmNhbGwodGhpcywgbWFya2VyKTtcbiAgICAgICAgfVxuICAgIH1cblxuXG5cbn1cbnZhciBxdWV1ZSA9IFtdO1xudmFyIGRyYWluaW5nID0gZmFsc2U7XG52YXIgY3VycmVudFF1ZXVlO1xudmFyIHF1ZXVlSW5kZXggPSAtMTtcblxuZnVuY3Rpb24gY2xlYW5VcE5leHRUaWNrKCkge1xuICAgIGlmICghZHJhaW5pbmcgfHwgIWN1cnJlbnRRdWV1ZSkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGRyYWluaW5nID0gZmFsc2U7XG4gICAgaWYgKGN1cnJlbnRRdWV1ZS5sZW5ndGgpIHtcbiAgICAgICAgcXVldWUgPSBjdXJyZW50UXVldWUuY29uY2F0KHF1ZXVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBxdWV1ZUluZGV4ID0gLTE7XG4gICAgfVxuICAgIGlmIChxdWV1ZS5sZW5ndGgpIHtcbiAgICAgICAgZHJhaW5RdWV1ZSgpO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gZHJhaW5RdWV1ZSgpIHtcbiAgICBpZiAoZHJhaW5pbmcpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2YXIgdGltZW91dCA9IHJ1blRpbWVvdXQoY2xlYW5VcE5leHRUaWNrKTtcbiAgICBkcmFpbmluZyA9IHRydWU7XG5cbiAgICB2YXIgbGVuID0gcXVldWUubGVuZ3RoO1xuICAgIHdoaWxlKGxlbikge1xuICAgICAgICBjdXJyZW50UXVldWUgPSBxdWV1ZTtcbiAgICAgICAgcXVldWUgPSBbXTtcbiAgICAgICAgd2hpbGUgKCsrcXVldWVJbmRleCA8IGxlbikge1xuICAgICAgICAgICAgaWYgKGN1cnJlbnRRdWV1ZSkge1xuICAgICAgICAgICAgICAgIGN1cnJlbnRRdWV1ZVtxdWV1ZUluZGV4XS5ydW4oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBxdWV1ZUluZGV4ID0gLTE7XG4gICAgICAgIGxlbiA9IHF1ZXVlLmxlbmd0aDtcbiAgICB9XG4gICAgY3VycmVudFF1ZXVlID0gbnVsbDtcbiAgICBkcmFpbmluZyA9IGZhbHNlO1xuICAgIHJ1bkNsZWFyVGltZW91dCh0aW1lb3V0KTtcbn1cblxucHJvY2Vzcy5uZXh0VGljayA9IGZ1bmN0aW9uIChmdW4pIHtcbiAgICB2YXIgYXJncyA9IG5ldyBBcnJheShhcmd1bWVudHMubGVuZ3RoIC0gMSk7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPiAxKSB7XG4gICAgICAgIGZvciAodmFyIGkgPSAxOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBhcmdzW2kgLSAxXSA9IGFyZ3VtZW50c1tpXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBxdWV1ZS5wdXNoKG5ldyBJdGVtKGZ1biwgYXJncykpO1xuICAgIGlmIChxdWV1ZS5sZW5ndGggPT09IDEgJiYgIWRyYWluaW5nKSB7XG4gICAgICAgIHJ1blRpbWVvdXQoZHJhaW5RdWV1ZSk7XG4gICAgfVxufTtcblxuLy8gdjggbGlrZXMgcHJlZGljdGlibGUgb2JqZWN0c1xuZnVuY3Rpb24gSXRlbShmdW4sIGFycmF5KSB7XG4gICAgdGhpcy5mdW4gPSBmdW47XG4gICAgdGhpcy5hcnJheSA9IGFycmF5O1xufVxuSXRlbS5wcm90b3R5cGUucnVuID0gZnVuY3Rpb24gKCkge1xuICAgIHRoaXMuZnVuLmFwcGx5KG51bGwsIHRoaXMuYXJyYXkpO1xufTtcbnByb2Nlc3MudGl0bGUgPSAnYnJvd3Nlcic7XG5wcm9jZXNzLmJyb3dzZXIgPSB0cnVlO1xucHJvY2Vzcy5lbnYgPSB7fTtcbnByb2Nlc3MuYXJndiA9IFtdO1xucHJvY2Vzcy52ZXJzaW9uID0gJyc7IC8vIGVtcHR5IHN0cmluZyB0byBhdm9pZCByZWdleHAgaXNzdWVzXG5wcm9jZXNzLnZlcnNpb25zID0ge307XG5cbmZ1bmN0aW9uIG5vb3AoKSB7fVxuXG5wcm9jZXNzLm9uID0gbm9vcDtcbnByb2Nlc3MuYWRkTGlzdGVuZXIgPSBub29wO1xucHJvY2Vzcy5vbmNlID0gbm9vcDtcbnByb2Nlc3Mub2ZmID0gbm9vcDtcbnByb2Nlc3MucmVtb3ZlTGlzdGVuZXIgPSBub29wO1xucHJvY2Vzcy5yZW1vdmVBbGxMaXN0ZW5lcnMgPSBub29wO1xucHJvY2Vzcy5lbWl0ID0gbm9vcDtcbnByb2Nlc3MucHJlcGVuZExpc3RlbmVyID0gbm9vcDtcbnByb2Nlc3MucHJlcGVuZE9uY2VMaXN0ZW5lciA9IG5vb3A7XG5cbnByb2Nlc3MubGlzdGVuZXJzID0gZnVuY3Rpb24gKG5hbWUpIHsgcmV0dXJuIFtdIH1cblxucHJvY2Vzcy5iaW5kaW5nID0gZnVuY3Rpb24gKG5hbWUpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3Byb2Nlc3MuYmluZGluZyBpcyBub3Qgc3VwcG9ydGVkJyk7XG59O1xuXG5wcm9jZXNzLmN3ZCA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuICcvJyB9O1xucHJvY2Vzcy5jaGRpciA9IGZ1bmN0aW9uIChkaXIpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3Byb2Nlc3MuY2hkaXIgaXMgbm90IHN1cHBvcnRlZCcpO1xufTtcbnByb2Nlc3MudW1hc2sgPSBmdW5jdGlvbigpIHsgcmV0dXJuIDA7IH07XG4iLCIndXNlIHN0cmljdCc7XG4vKipcbiAqIEBsaWNlbnNlIEFuZ3VsYXIgdjx1bmtub3duPlxuICogKGMpIDIwMTAtMjAyMiBHb29nbGUgTExDLiBodHRwczovL2FuZ3VsYXIuaW8vXG4gKiBMaWNlbnNlOiBNSVRcbiAqL1xuKChmdW5jdGlvbiAoZ2xvYmFsKSB7XG4gICAgY29uc3QgcGVyZm9ybWFuY2UgPSBnbG9iYWxbJ3BlcmZvcm1hbmNlJ107XG4gICAgZnVuY3Rpb24gbWFyayhuYW1lKSB7XG4gICAgICAgIHBlcmZvcm1hbmNlICYmIHBlcmZvcm1hbmNlWydtYXJrJ10gJiYgcGVyZm9ybWFuY2VbJ21hcmsnXShuYW1lKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcGVyZm9ybWFuY2VNZWFzdXJlKG5hbWUsIGxhYmVsKSB7XG4gICAgICAgIHBlcmZvcm1hbmNlICYmIHBlcmZvcm1hbmNlWydtZWFzdXJlJ10gJiYgcGVyZm9ybWFuY2VbJ21lYXN1cmUnXShuYW1lLCBsYWJlbCk7XG4gICAgfVxuICAgIG1hcmsoJ1pvbmUnKTtcbiAgICAvLyBJbml0aWFsaXplIGJlZm9yZSBpdCdzIGFjY2Vzc2VkIGJlbG93LlxuICAgIC8vIF9fWm9uZV9zeW1ib2xfcHJlZml4IGdsb2JhbCBjYW4gYmUgdXNlZCB0byBvdmVycmlkZSB0aGUgZGVmYXVsdCB6b25lXG4gICAgLy8gc3ltYm9sIHByZWZpeCB3aXRoIGEgY3VzdG9tIG9uZSBpZiBuZWVkZWQuXG4gICAgY29uc3Qgc3ltYm9sUHJlZml4ID0gZ2xvYmFsWydfX1pvbmVfc3ltYm9sX3ByZWZpeCddIHx8ICdfX3pvbmVfc3ltYm9sX18nO1xuICAgIGZ1bmN0aW9uIF9fc3ltYm9sX18obmFtZSkge1xuICAgICAgICByZXR1cm4gc3ltYm9sUHJlZml4ICsgbmFtZTtcbiAgICB9XG4gICAgY29uc3QgY2hlY2tEdXBsaWNhdGUgPSBnbG9iYWxbX19zeW1ib2xfXygnZm9yY2VEdXBsaWNhdGVab25lQ2hlY2snKV0gPT09IHRydWU7XG4gICAgaWYgKGdsb2JhbFsnWm9uZSddKSB7XG4gICAgICAgIC8vIGlmIGdsb2JhbFsnWm9uZSddIGFscmVhZHkgZXhpc3RzIChtYXliZSB6b25lLmpzIHdhcyBhbHJlYWR5IGxvYWRlZCBvclxuICAgICAgICAvLyBzb21lIG90aGVyIGxpYiBhbHNvIHJlZ2lzdGVyZWQgYSBnbG9iYWwgb2JqZWN0IG5hbWVkIFpvbmUpLCB3ZSBtYXkgbmVlZFxuICAgICAgICAvLyB0byB0aHJvdyBhbiBlcnJvciwgYnV0IHNvbWV0aW1lcyB1c2VyIG1heSBub3Qgd2FudCB0aGlzIGVycm9yLlxuICAgICAgICAvLyBGb3IgZXhhbXBsZSxcbiAgICAgICAgLy8gd2UgaGF2ZSB0d28gd2ViIHBhZ2VzLCBwYWdlMSBpbmNsdWRlcyB6b25lLmpzLCBwYWdlMiBkb2Vzbid0LlxuICAgICAgICAvLyBhbmQgdGhlIDFzdCB0aW1lIHVzZXIgbG9hZCBwYWdlMSBhbmQgcGFnZTIsIGV2ZXJ5dGhpbmcgd29yayBmaW5lLFxuICAgICAgICAvLyBidXQgd2hlbiB1c2VyIGxvYWQgcGFnZTIgYWdhaW4sIGVycm9yIG9jY3VycyBiZWNhdXNlIGdsb2JhbFsnWm9uZSddIGFscmVhZHkgZXhpc3RzLlxuICAgICAgICAvLyBzbyB3ZSBhZGQgYSBmbGFnIHRvIGxldCB1c2VyIGNob29zZSB3aGV0aGVyIHRvIHRocm93IHRoaXMgZXJyb3Igb3Igbm90LlxuICAgICAgICAvLyBCeSBkZWZhdWx0LCBpZiBleGlzdGluZyBab25lIGlzIGZyb20gem9uZS5qcywgd2Ugd2lsbCBub3QgdGhyb3cgdGhlIGVycm9yLlxuICAgICAgICBpZiAoY2hlY2tEdXBsaWNhdGUgfHwgdHlwZW9mIGdsb2JhbFsnWm9uZSddLl9fc3ltYm9sX18gIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignWm9uZSBhbHJlYWR5IGxvYWRlZC4nKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBnbG9iYWxbJ1pvbmUnXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjbGFzcyBab25lIHtcbiAgICAgICAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOnJlcXVpcmUtaW50ZXJuYWwtd2l0aC11bmRlcnNjb3JlXG4gICAgICAgIHN0YXRpYyB7IHRoaXMuX19zeW1ib2xfXyA9IF9fc3ltYm9sX187IH1cbiAgICAgICAgc3RhdGljIGFzc2VydFpvbmVQYXRjaGVkKCkge1xuICAgICAgICAgICAgaWYgKGdsb2JhbFsnUHJvbWlzZSddICE9PSBwYXRjaGVzWydab25lQXdhcmVQcm9taXNlJ10pIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1pvbmUuanMgaGFzIGRldGVjdGVkIHRoYXQgWm9uZUF3YXJlUHJvbWlzZSBgKHdpbmRvd3xnbG9iYWwpLlByb21pc2VgICcgK1xuICAgICAgICAgICAgICAgICAgICAnaGFzIGJlZW4gb3ZlcndyaXR0ZW4uXFxuJyArXG4gICAgICAgICAgICAgICAgICAgICdNb3N0IGxpa2VseSBjYXVzZSBpcyB0aGF0IGEgUHJvbWlzZSBwb2x5ZmlsbCBoYXMgYmVlbiBsb2FkZWQgJyArXG4gICAgICAgICAgICAgICAgICAgICdhZnRlciBab25lLmpzIChQb2x5ZmlsbGluZyBQcm9taXNlIGFwaSBpcyBub3QgbmVjZXNzYXJ5IHdoZW4gem9uZS5qcyBpcyBsb2FkZWQuICcgK1xuICAgICAgICAgICAgICAgICAgICAnSWYgeW91IG11c3QgbG9hZCBvbmUsIGRvIHNvIGJlZm9yZSBsb2FkaW5nIHpvbmUuanMuKScpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHN0YXRpYyBnZXQgcm9vdCgpIHtcbiAgICAgICAgICAgIGxldCB6b25lID0gWm9uZS5jdXJyZW50O1xuICAgICAgICAgICAgd2hpbGUgKHpvbmUucGFyZW50KSB7XG4gICAgICAgICAgICAgICAgem9uZSA9IHpvbmUucGFyZW50O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHpvbmU7XG4gICAgICAgIH1cbiAgICAgICAgc3RhdGljIGdldCBjdXJyZW50KCkge1xuICAgICAgICAgICAgcmV0dXJuIF9jdXJyZW50Wm9uZUZyYW1lLnpvbmU7XG4gICAgICAgIH1cbiAgICAgICAgc3RhdGljIGdldCBjdXJyZW50VGFzaygpIHtcbiAgICAgICAgICAgIHJldHVybiBfY3VycmVudFRhc2s7XG4gICAgICAgIH1cbiAgICAgICAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOnJlcXVpcmUtaW50ZXJuYWwtd2l0aC11bmRlcnNjb3JlXG4gICAgICAgIHN0YXRpYyBfX2xvYWRfcGF0Y2gobmFtZSwgZm4sIGlnbm9yZUR1cGxpY2F0ZSA9IGZhbHNlKSB7XG4gICAgICAgICAgICBpZiAocGF0Y2hlcy5oYXNPd25Qcm9wZXJ0eShuYW1lKSkge1xuICAgICAgICAgICAgICAgIC8vIGBjaGVja0R1cGxpY2F0ZWAgb3B0aW9uIGlzIGRlZmluZWQgZnJvbSBnbG9iYWwgdmFyaWFibGVcbiAgICAgICAgICAgICAgICAvLyBzbyBpdCB3b3JrcyBmb3IgYWxsIG1vZHVsZXMuXG4gICAgICAgICAgICAgICAgLy8gYGlnbm9yZUR1cGxpY2F0ZWAgY2FuIHdvcmsgZm9yIHRoZSBzcGVjaWZpZWQgbW9kdWxlXG4gICAgICAgICAgICAgICAgaWYgKCFpZ25vcmVEdXBsaWNhdGUgJiYgY2hlY2tEdXBsaWNhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgRXJyb3IoJ0FscmVhZHkgbG9hZGVkIHBhdGNoOiAnICsgbmFtZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoIWdsb2JhbFsnX19ab25lX2Rpc2FibGVfJyArIG5hbWVdKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcGVyZk5hbWUgPSAnWm9uZTonICsgbmFtZTtcbiAgICAgICAgICAgICAgICBtYXJrKHBlcmZOYW1lKTtcbiAgICAgICAgICAgICAgICBwYXRjaGVzW25hbWVdID0gZm4oZ2xvYmFsLCBab25lLCBfYXBpKTtcbiAgICAgICAgICAgICAgICBwZXJmb3JtYW5jZU1lYXN1cmUocGVyZk5hbWUsIHBlcmZOYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBnZXQgcGFyZW50KCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3BhcmVudDtcbiAgICAgICAgfVxuICAgICAgICBnZXQgbmFtZSgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9uYW1lO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0cnVjdG9yKHBhcmVudCwgem9uZVNwZWMpIHtcbiAgICAgICAgICAgIHRoaXMuX3BhcmVudCA9IHBhcmVudDtcbiAgICAgICAgICAgIHRoaXMuX25hbWUgPSB6b25lU3BlYyA/IHpvbmVTcGVjLm5hbWUgfHwgJ3VubmFtZWQnIDogJzxyb290Pic7XG4gICAgICAgICAgICB0aGlzLl9wcm9wZXJ0aWVzID0gem9uZVNwZWMgJiYgem9uZVNwZWMucHJvcGVydGllcyB8fCB7fTtcbiAgICAgICAgICAgIHRoaXMuX3pvbmVEZWxlZ2F0ZSA9XG4gICAgICAgICAgICAgICAgbmV3IF9ab25lRGVsZWdhdGUodGhpcywgdGhpcy5fcGFyZW50ICYmIHRoaXMuX3BhcmVudC5fem9uZURlbGVnYXRlLCB6b25lU3BlYyk7XG4gICAgICAgIH1cbiAgICAgICAgZ2V0KGtleSkge1xuICAgICAgICAgICAgY29uc3Qgem9uZSA9IHRoaXMuZ2V0Wm9uZVdpdGgoa2V5KTtcbiAgICAgICAgICAgIGlmICh6b25lKVxuICAgICAgICAgICAgICAgIHJldHVybiB6b25lLl9wcm9wZXJ0aWVzW2tleV07XG4gICAgICAgIH1cbiAgICAgICAgZ2V0Wm9uZVdpdGgoa2V5KSB7XG4gICAgICAgICAgICBsZXQgY3VycmVudCA9IHRoaXM7XG4gICAgICAgICAgICB3aGlsZSAoY3VycmVudCkge1xuICAgICAgICAgICAgICAgIGlmIChjdXJyZW50Ll9wcm9wZXJ0aWVzLmhhc093blByb3BlcnR5KGtleSkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGN1cnJlbnQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGN1cnJlbnQgPSBjdXJyZW50Ll9wYXJlbnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBmb3JrKHpvbmVTcGVjKSB7XG4gICAgICAgICAgICBpZiAoIXpvbmVTcGVjKVxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignWm9uZVNwZWMgcmVxdWlyZWQhJyk7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fem9uZURlbGVnYXRlLmZvcmsodGhpcywgem9uZVNwZWMpO1xuICAgICAgICB9XG4gICAgICAgIHdyYXAoY2FsbGJhY2ssIHNvdXJjZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBjYWxsYmFjayAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRXhwZWN0aW5nIGZ1bmN0aW9uIGdvdDogJyArIGNhbGxiYWNrKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IF9jYWxsYmFjayA9IHRoaXMuX3pvbmVEZWxlZ2F0ZS5pbnRlcmNlcHQodGhpcywgY2FsbGJhY2ssIHNvdXJjZSk7XG4gICAgICAgICAgICBjb25zdCB6b25lID0gdGhpcztcbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHpvbmUucnVuR3VhcmRlZChfY2FsbGJhY2ssIHRoaXMsIGFyZ3VtZW50cywgc291cmNlKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcnVuKGNhbGxiYWNrLCBhcHBseVRoaXMsIGFwcGx5QXJncywgc291cmNlKSB7XG4gICAgICAgICAgICBfY3VycmVudFpvbmVGcmFtZSA9IHsgcGFyZW50OiBfY3VycmVudFpvbmVGcmFtZSwgem9uZTogdGhpcyB9O1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fem9uZURlbGVnYXRlLmludm9rZSh0aGlzLCBjYWxsYmFjaywgYXBwbHlUaGlzLCBhcHBseUFyZ3MsIHNvdXJjZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICBfY3VycmVudFpvbmVGcmFtZSA9IF9jdXJyZW50Wm9uZUZyYW1lLnBhcmVudDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBydW5HdWFyZGVkKGNhbGxiYWNrLCBhcHBseVRoaXMgPSBudWxsLCBhcHBseUFyZ3MsIHNvdXJjZSkge1xuICAgICAgICAgICAgX2N1cnJlbnRab25lRnJhbWUgPSB7IHBhcmVudDogX2N1cnJlbnRab25lRnJhbWUsIHpvbmU6IHRoaXMgfTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3pvbmVEZWxlZ2F0ZS5pbnZva2UodGhpcywgY2FsbGJhY2ssIGFwcGx5VGhpcywgYXBwbHlBcmdzLCBzb3VyY2UpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3pvbmVEZWxlZ2F0ZS5oYW5kbGVFcnJvcih0aGlzLCBlcnJvcikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICAgICAgX2N1cnJlbnRab25lRnJhbWUgPSBfY3VycmVudFpvbmVGcmFtZS5wYXJlbnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcnVuVGFzayh0YXNrLCBhcHBseVRoaXMsIGFwcGx5QXJncykge1xuICAgICAgICAgICAgaWYgKHRhc2suem9uZSAhPSB0aGlzKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdBIHRhc2sgY2FuIG9ubHkgYmUgcnVuIGluIHRoZSB6b25lIG9mIGNyZWF0aW9uISAoQ3JlYXRpb246ICcgK1xuICAgICAgICAgICAgICAgICAgICAodGFzay56b25lIHx8IE5PX1pPTkUpLm5hbWUgKyAnOyBFeGVjdXRpb246ICcgKyB0aGlzLm5hbWUgKyAnKScpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2FuZ3VsYXIvem9uZS5qcy9pc3N1ZXMvNzc4LCBzb21ldGltZXMgZXZlbnRUYXNrXG4gICAgICAgICAgICAvLyB3aWxsIHJ1biBpbiBub3RTY2hlZHVsZWQoY2FuY2VsZWQpIHN0YXRlLCB3ZSBzaG91bGQgbm90IHRyeSB0b1xuICAgICAgICAgICAgLy8gcnVuIHN1Y2gga2luZCBvZiB0YXNrIGJ1dCBqdXN0IHJldHVyblxuICAgICAgICAgICAgaWYgKHRhc2suc3RhdGUgPT09IG5vdFNjaGVkdWxlZCAmJiAodGFzay50eXBlID09PSBldmVudFRhc2sgfHwgdGFzay50eXBlID09PSBtYWNyb1Rhc2spKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgcmVFbnRyeUd1YXJkID0gdGFzay5zdGF0ZSAhPSBydW5uaW5nO1xuICAgICAgICAgICAgcmVFbnRyeUd1YXJkICYmIHRhc2suX3RyYW5zaXRpb25UbyhydW5uaW5nLCBzY2hlZHVsZWQpO1xuICAgICAgICAgICAgdGFzay5ydW5Db3VudCsrO1xuICAgICAgICAgICAgY29uc3QgcHJldmlvdXNUYXNrID0gX2N1cnJlbnRUYXNrO1xuICAgICAgICAgICAgX2N1cnJlbnRUYXNrID0gdGFzaztcbiAgICAgICAgICAgIF9jdXJyZW50Wm9uZUZyYW1lID0geyBwYXJlbnQ6IF9jdXJyZW50Wm9uZUZyYW1lLCB6b25lOiB0aGlzIH07XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGlmICh0YXNrLnR5cGUgPT0gbWFjcm9UYXNrICYmIHRhc2suZGF0YSAmJiAhdGFzay5kYXRhLmlzUGVyaW9kaWMpIHtcbiAgICAgICAgICAgICAgICAgICAgdGFzay5jYW5jZWxGbiA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3pvbmVEZWxlZ2F0ZS5pbnZva2VUYXNrKHRoaXMsIHRhc2ssIGFwcGx5VGhpcywgYXBwbHlBcmdzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl96b25lRGVsZWdhdGUuaGFuZGxlRXJyb3IodGhpcywgZXJyb3IpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIC8vIGlmIHRoZSB0YXNrJ3Mgc3RhdGUgaXMgbm90U2NoZWR1bGVkIG9yIHVua25vd24sIHRoZW4gaXQgaGFzIGFscmVhZHkgYmVlbiBjYW5jZWxsZWRcbiAgICAgICAgICAgICAgICAvLyB3ZSBzaG91bGQgbm90IHJlc2V0IHRoZSBzdGF0ZSB0byBzY2hlZHVsZWRcbiAgICAgICAgICAgICAgICBpZiAodGFzay5zdGF0ZSAhPT0gbm90U2NoZWR1bGVkICYmIHRhc2suc3RhdGUgIT09IHVua25vd24pIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRhc2sudHlwZSA9PSBldmVudFRhc2sgfHwgKHRhc2suZGF0YSAmJiB0YXNrLmRhdGEuaXNQZXJpb2RpYykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlRW50cnlHdWFyZCAmJiB0YXNrLl90cmFuc2l0aW9uVG8oc2NoZWR1bGVkLCBydW5uaW5nKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhc2sucnVuQ291bnQgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlVGFza0NvdW50KHRhc2ssIC0xKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlRW50cnlHdWFyZCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhc2suX3RyYW5zaXRpb25Ubyhub3RTY2hlZHVsZWQsIHJ1bm5pbmcsIG5vdFNjaGVkdWxlZCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgX2N1cnJlbnRab25lRnJhbWUgPSBfY3VycmVudFpvbmVGcmFtZS5wYXJlbnQ7XG4gICAgICAgICAgICAgICAgX2N1cnJlbnRUYXNrID0gcHJldmlvdXNUYXNrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHNjaGVkdWxlVGFzayh0YXNrKSB7XG4gICAgICAgICAgICBpZiAodGFzay56b25lICYmIHRhc2suem9uZSAhPT0gdGhpcykge1xuICAgICAgICAgICAgICAgIC8vIGNoZWNrIGlmIHRoZSB0YXNrIHdhcyByZXNjaGVkdWxlZCwgdGhlIG5ld1pvbmVcbiAgICAgICAgICAgICAgICAvLyBzaG91bGQgbm90IGJlIHRoZSBjaGlsZHJlbiBvZiB0aGUgb3JpZ2luYWwgem9uZVxuICAgICAgICAgICAgICAgIGxldCBuZXdab25lID0gdGhpcztcbiAgICAgICAgICAgICAgICB3aGlsZSAobmV3Wm9uZSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAobmV3Wm9uZSA9PT0gdGFzay56b25lKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBFcnJvcihgY2FuIG5vdCByZXNjaGVkdWxlIHRhc2sgdG8gJHt0aGlzLm5hbWV9IHdoaWNoIGlzIGRlc2NlbmRhbnRzIG9mIHRoZSBvcmlnaW5hbCB6b25lICR7dGFzay56b25lLm5hbWV9YCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbmV3Wm9uZSA9IG5ld1pvbmUucGFyZW50O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRhc2suX3RyYW5zaXRpb25UbyhzY2hlZHVsaW5nLCBub3RTY2hlZHVsZWQpO1xuICAgICAgICAgICAgY29uc3Qgem9uZURlbGVnYXRlcyA9IFtdO1xuICAgICAgICAgICAgdGFzay5fem9uZURlbGVnYXRlcyA9IHpvbmVEZWxlZ2F0ZXM7XG4gICAgICAgICAgICB0YXNrLl96b25lID0gdGhpcztcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgdGFzayA9IHRoaXMuX3pvbmVEZWxlZ2F0ZS5zY2hlZHVsZVRhc2sodGhpcywgdGFzayk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgLy8gc2hvdWxkIHNldCB0YXNrJ3Mgc3RhdGUgdG8gdW5rbm93biB3aGVuIHNjaGVkdWxlVGFzayB0aHJvdyBlcnJvclxuICAgICAgICAgICAgICAgIC8vIGJlY2F1c2UgdGhlIGVyciBtYXkgZnJvbSByZXNjaGVkdWxlLCBzbyB0aGUgZnJvbVN0YXRlIG1heWJlIG5vdFNjaGVkdWxlZFxuICAgICAgICAgICAgICAgIHRhc2suX3RyYW5zaXRpb25Ubyh1bmtub3duLCBzY2hlZHVsaW5nLCBub3RTY2hlZHVsZWQpO1xuICAgICAgICAgICAgICAgIC8vIFRPRE86IEBKaWFMaVBhc3Npb24sIHNob3VsZCB3ZSBjaGVjayB0aGUgcmVzdWx0IGZyb20gaGFuZGxlRXJyb3I/XG4gICAgICAgICAgICAgICAgdGhpcy5fem9uZURlbGVnYXRlLmhhbmRsZUVycm9yKHRoaXMsIGVycik7XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRhc2suX3pvbmVEZWxlZ2F0ZXMgPT09IHpvbmVEZWxlZ2F0ZXMpIHtcbiAgICAgICAgICAgICAgICAvLyB3ZSBoYXZlIHRvIGNoZWNrIGJlY2F1c2UgaW50ZXJuYWxseSB0aGUgZGVsZWdhdGUgY2FuIHJlc2NoZWR1bGUgdGhlIHRhc2suXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlVGFza0NvdW50KHRhc2ssIDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRhc2suc3RhdGUgPT0gc2NoZWR1bGluZykge1xuICAgICAgICAgICAgICAgIHRhc2suX3RyYW5zaXRpb25UbyhzY2hlZHVsZWQsIHNjaGVkdWxpbmcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRhc2s7XG4gICAgICAgIH1cbiAgICAgICAgc2NoZWR1bGVNaWNyb1Rhc2soc291cmNlLCBjYWxsYmFjaywgZGF0YSwgY3VzdG9tU2NoZWR1bGUpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnNjaGVkdWxlVGFzayhuZXcgWm9uZVRhc2sobWljcm9UYXNrLCBzb3VyY2UsIGNhbGxiYWNrLCBkYXRhLCBjdXN0b21TY2hlZHVsZSwgdW5kZWZpbmVkKSk7XG4gICAgICAgIH1cbiAgICAgICAgc2NoZWR1bGVNYWNyb1Rhc2soc291cmNlLCBjYWxsYmFjaywgZGF0YSwgY3VzdG9tU2NoZWR1bGUsIGN1c3RvbUNhbmNlbCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc2NoZWR1bGVUYXNrKG5ldyBab25lVGFzayhtYWNyb1Rhc2ssIHNvdXJjZSwgY2FsbGJhY2ssIGRhdGEsIGN1c3RvbVNjaGVkdWxlLCBjdXN0b21DYW5jZWwpKTtcbiAgICAgICAgfVxuICAgICAgICBzY2hlZHVsZUV2ZW50VGFzayhzb3VyY2UsIGNhbGxiYWNrLCBkYXRhLCBjdXN0b21TY2hlZHVsZSwgY3VzdG9tQ2FuY2VsKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zY2hlZHVsZVRhc2sobmV3IFpvbmVUYXNrKGV2ZW50VGFzaywgc291cmNlLCBjYWxsYmFjaywgZGF0YSwgY3VzdG9tU2NoZWR1bGUsIGN1c3RvbUNhbmNlbCkpO1xuICAgICAgICB9XG4gICAgICAgIGNhbmNlbFRhc2sodGFzaykge1xuICAgICAgICAgICAgaWYgKHRhc2suem9uZSAhPSB0aGlzKVxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQSB0YXNrIGNhbiBvbmx5IGJlIGNhbmNlbGxlZCBpbiB0aGUgem9uZSBvZiBjcmVhdGlvbiEgKENyZWF0aW9uOiAnICtcbiAgICAgICAgICAgICAgICAgICAgKHRhc2suem9uZSB8fCBOT19aT05FKS5uYW1lICsgJzsgRXhlY3V0aW9uOiAnICsgdGhpcy5uYW1lICsgJyknKTtcbiAgICAgICAgICAgIGlmICh0YXNrLnN0YXRlICE9PSBzY2hlZHVsZWQgJiYgdGFzay5zdGF0ZSAhPT0gcnVubmluZykge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRhc2suX3RyYW5zaXRpb25UbyhjYW5jZWxpbmcsIHNjaGVkdWxlZCwgcnVubmluZyk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHRoaXMuX3pvbmVEZWxlZ2F0ZS5jYW5jZWxUYXNrKHRoaXMsIHRhc2spO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgIC8vIGlmIGVycm9yIG9jY3VycyB3aGVuIGNhbmNlbFRhc2ssIHRyYW5zaXQgdGhlIHN0YXRlIHRvIHVua25vd25cbiAgICAgICAgICAgICAgICB0YXNrLl90cmFuc2l0aW9uVG8odW5rbm93biwgY2FuY2VsaW5nKTtcbiAgICAgICAgICAgICAgICB0aGlzLl96b25lRGVsZWdhdGUuaGFuZGxlRXJyb3IodGhpcywgZXJyKTtcbiAgICAgICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLl91cGRhdGVUYXNrQ291bnQodGFzaywgLTEpO1xuICAgICAgICAgICAgdGFzay5fdHJhbnNpdGlvblRvKG5vdFNjaGVkdWxlZCwgY2FuY2VsaW5nKTtcbiAgICAgICAgICAgIHRhc2sucnVuQ291bnQgPSAwO1xuICAgICAgICAgICAgcmV0dXJuIHRhc2s7XG4gICAgICAgIH1cbiAgICAgICAgX3VwZGF0ZVRhc2tDb3VudCh0YXNrLCBjb3VudCkge1xuICAgICAgICAgICAgY29uc3Qgem9uZURlbGVnYXRlcyA9IHRhc2suX3pvbmVEZWxlZ2F0ZXM7XG4gICAgICAgICAgICBpZiAoY291bnQgPT0gLTEpIHtcbiAgICAgICAgICAgICAgICB0YXNrLl96b25lRGVsZWdhdGVzID0gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgem9uZURlbGVnYXRlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIHpvbmVEZWxlZ2F0ZXNbaV0uX3VwZGF0ZVRhc2tDb3VudCh0YXNrLnR5cGUsIGNvdW50KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBERUxFR0FURV9aUyA9IHtcbiAgICAgICAgbmFtZTogJycsXG4gICAgICAgIG9uSGFzVGFzazogKGRlbGVnYXRlLCBfLCB0YXJnZXQsIGhhc1Rhc2tTdGF0ZSkgPT4gZGVsZWdhdGUuaGFzVGFzayh0YXJnZXQsIGhhc1Rhc2tTdGF0ZSksXG4gICAgICAgIG9uU2NoZWR1bGVUYXNrOiAoZGVsZWdhdGUsIF8sIHRhcmdldCwgdGFzaykgPT4gZGVsZWdhdGUuc2NoZWR1bGVUYXNrKHRhcmdldCwgdGFzayksXG4gICAgICAgIG9uSW52b2tlVGFzazogKGRlbGVnYXRlLCBfLCB0YXJnZXQsIHRhc2ssIGFwcGx5VGhpcywgYXBwbHlBcmdzKSA9PiBkZWxlZ2F0ZS5pbnZva2VUYXNrKHRhcmdldCwgdGFzaywgYXBwbHlUaGlzLCBhcHBseUFyZ3MpLFxuICAgICAgICBvbkNhbmNlbFRhc2s6IChkZWxlZ2F0ZSwgXywgdGFyZ2V0LCB0YXNrKSA9PiBkZWxlZ2F0ZS5jYW5jZWxUYXNrKHRhcmdldCwgdGFzaylcbiAgICB9O1xuICAgIGNsYXNzIF9ab25lRGVsZWdhdGUge1xuICAgICAgICBjb25zdHJ1Y3Rvcih6b25lLCBwYXJlbnREZWxlZ2F0ZSwgem9uZVNwZWMpIHtcbiAgICAgICAgICAgIHRoaXMuX3Rhc2tDb3VudHMgPSB7ICdtaWNyb1Rhc2snOiAwLCAnbWFjcm9UYXNrJzogMCwgJ2V2ZW50VGFzayc6IDAgfTtcbiAgICAgICAgICAgIHRoaXMuem9uZSA9IHpvbmU7XG4gICAgICAgICAgICB0aGlzLl9wYXJlbnREZWxlZ2F0ZSA9IHBhcmVudERlbGVnYXRlO1xuICAgICAgICAgICAgdGhpcy5fZm9ya1pTID0gem9uZVNwZWMgJiYgKHpvbmVTcGVjICYmIHpvbmVTcGVjLm9uRm9yayA/IHpvbmVTcGVjIDogcGFyZW50RGVsZWdhdGUuX2ZvcmtaUyk7XG4gICAgICAgICAgICB0aGlzLl9mb3JrRGxndCA9IHpvbmVTcGVjICYmICh6b25lU3BlYy5vbkZvcmsgPyBwYXJlbnREZWxlZ2F0ZSA6IHBhcmVudERlbGVnYXRlLl9mb3JrRGxndCk7XG4gICAgICAgICAgICB0aGlzLl9mb3JrQ3VyclpvbmUgPVxuICAgICAgICAgICAgICAgIHpvbmVTcGVjICYmICh6b25lU3BlYy5vbkZvcmsgPyB0aGlzLnpvbmUgOiBwYXJlbnREZWxlZ2F0ZS5fZm9ya0N1cnJab25lKTtcbiAgICAgICAgICAgIHRoaXMuX2ludGVyY2VwdFpTID1cbiAgICAgICAgICAgICAgICB6b25lU3BlYyAmJiAoem9uZVNwZWMub25JbnRlcmNlcHQgPyB6b25lU3BlYyA6IHBhcmVudERlbGVnYXRlLl9pbnRlcmNlcHRaUyk7XG4gICAgICAgICAgICB0aGlzLl9pbnRlcmNlcHREbGd0ID1cbiAgICAgICAgICAgICAgICB6b25lU3BlYyAmJiAoem9uZVNwZWMub25JbnRlcmNlcHQgPyBwYXJlbnREZWxlZ2F0ZSA6IHBhcmVudERlbGVnYXRlLl9pbnRlcmNlcHREbGd0KTtcbiAgICAgICAgICAgIHRoaXMuX2ludGVyY2VwdEN1cnJab25lID1cbiAgICAgICAgICAgICAgICB6b25lU3BlYyAmJiAoem9uZVNwZWMub25JbnRlcmNlcHQgPyB0aGlzLnpvbmUgOiBwYXJlbnREZWxlZ2F0ZS5faW50ZXJjZXB0Q3VyclpvbmUpO1xuICAgICAgICAgICAgdGhpcy5faW52b2tlWlMgPSB6b25lU3BlYyAmJiAoem9uZVNwZWMub25JbnZva2UgPyB6b25lU3BlYyA6IHBhcmVudERlbGVnYXRlLl9pbnZva2VaUyk7XG4gICAgICAgICAgICB0aGlzLl9pbnZva2VEbGd0ID1cbiAgICAgICAgICAgICAgICB6b25lU3BlYyAmJiAoem9uZVNwZWMub25JbnZva2UgPyBwYXJlbnREZWxlZ2F0ZSA6IHBhcmVudERlbGVnYXRlLl9pbnZva2VEbGd0KTtcbiAgICAgICAgICAgIHRoaXMuX2ludm9rZUN1cnJab25lID1cbiAgICAgICAgICAgICAgICB6b25lU3BlYyAmJiAoem9uZVNwZWMub25JbnZva2UgPyB0aGlzLnpvbmUgOiBwYXJlbnREZWxlZ2F0ZS5faW52b2tlQ3VyclpvbmUpO1xuICAgICAgICAgICAgdGhpcy5faGFuZGxlRXJyb3JaUyA9XG4gICAgICAgICAgICAgICAgem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uSGFuZGxlRXJyb3IgPyB6b25lU3BlYyA6IHBhcmVudERlbGVnYXRlLl9oYW5kbGVFcnJvclpTKTtcbiAgICAgICAgICAgIHRoaXMuX2hhbmRsZUVycm9yRGxndCA9XG4gICAgICAgICAgICAgICAgem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uSGFuZGxlRXJyb3IgPyBwYXJlbnREZWxlZ2F0ZSA6IHBhcmVudERlbGVnYXRlLl9oYW5kbGVFcnJvckRsZ3QpO1xuICAgICAgICAgICAgdGhpcy5faGFuZGxlRXJyb3JDdXJyWm9uZSA9XG4gICAgICAgICAgICAgICAgem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uSGFuZGxlRXJyb3IgPyB0aGlzLnpvbmUgOiBwYXJlbnREZWxlZ2F0ZS5faGFuZGxlRXJyb3JDdXJyWm9uZSk7XG4gICAgICAgICAgICB0aGlzLl9zY2hlZHVsZVRhc2taUyA9XG4gICAgICAgICAgICAgICAgem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uU2NoZWR1bGVUYXNrID8gem9uZVNwZWMgOiBwYXJlbnREZWxlZ2F0ZS5fc2NoZWR1bGVUYXNrWlMpO1xuICAgICAgICAgICAgdGhpcy5fc2NoZWR1bGVUYXNrRGxndCA9IHpvbmVTcGVjICYmXG4gICAgICAgICAgICAgICAgKHpvbmVTcGVjLm9uU2NoZWR1bGVUYXNrID8gcGFyZW50RGVsZWdhdGUgOiBwYXJlbnREZWxlZ2F0ZS5fc2NoZWR1bGVUYXNrRGxndCk7XG4gICAgICAgICAgICB0aGlzLl9zY2hlZHVsZVRhc2tDdXJyWm9uZSA9XG4gICAgICAgICAgICAgICAgem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uU2NoZWR1bGVUYXNrID8gdGhpcy56b25lIDogcGFyZW50RGVsZWdhdGUuX3NjaGVkdWxlVGFza0N1cnJab25lKTtcbiAgICAgICAgICAgIHRoaXMuX2ludm9rZVRhc2taUyA9XG4gICAgICAgICAgICAgICAgem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uSW52b2tlVGFzayA/IHpvbmVTcGVjIDogcGFyZW50RGVsZWdhdGUuX2ludm9rZVRhc2taUyk7XG4gICAgICAgICAgICB0aGlzLl9pbnZva2VUYXNrRGxndCA9XG4gICAgICAgICAgICAgICAgem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uSW52b2tlVGFzayA/IHBhcmVudERlbGVnYXRlIDogcGFyZW50RGVsZWdhdGUuX2ludm9rZVRhc2tEbGd0KTtcbiAgICAgICAgICAgIHRoaXMuX2ludm9rZVRhc2tDdXJyWm9uZSA9XG4gICAgICAgICAgICAgICAgem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uSW52b2tlVGFzayA/IHRoaXMuem9uZSA6IHBhcmVudERlbGVnYXRlLl9pbnZva2VUYXNrQ3VyclpvbmUpO1xuICAgICAgICAgICAgdGhpcy5fY2FuY2VsVGFza1pTID1cbiAgICAgICAgICAgICAgICB6b25lU3BlYyAmJiAoem9uZVNwZWMub25DYW5jZWxUYXNrID8gem9uZVNwZWMgOiBwYXJlbnREZWxlZ2F0ZS5fY2FuY2VsVGFza1pTKTtcbiAgICAgICAgICAgIHRoaXMuX2NhbmNlbFRhc2tEbGd0ID1cbiAgICAgICAgICAgICAgICB6b25lU3BlYyAmJiAoem9uZVNwZWMub25DYW5jZWxUYXNrID8gcGFyZW50RGVsZWdhdGUgOiBwYXJlbnREZWxlZ2F0ZS5fY2FuY2VsVGFza0RsZ3QpO1xuICAgICAgICAgICAgdGhpcy5fY2FuY2VsVGFza0N1cnJab25lID1cbiAgICAgICAgICAgICAgICB6b25lU3BlYyAmJiAoem9uZVNwZWMub25DYW5jZWxUYXNrID8gdGhpcy56b25lIDogcGFyZW50RGVsZWdhdGUuX2NhbmNlbFRhc2tDdXJyWm9uZSk7XG4gICAgICAgICAgICB0aGlzLl9oYXNUYXNrWlMgPSBudWxsO1xuICAgICAgICAgICAgdGhpcy5faGFzVGFza0RsZ3QgPSBudWxsO1xuICAgICAgICAgICAgdGhpcy5faGFzVGFza0RsZ3RPd25lciA9IG51bGw7XG4gICAgICAgICAgICB0aGlzLl9oYXNUYXNrQ3VyclpvbmUgPSBudWxsO1xuICAgICAgICAgICAgY29uc3Qgem9uZVNwZWNIYXNUYXNrID0gem9uZVNwZWMgJiYgem9uZVNwZWMub25IYXNUYXNrO1xuICAgICAgICAgICAgY29uc3QgcGFyZW50SGFzVGFzayA9IHBhcmVudERlbGVnYXRlICYmIHBhcmVudERlbGVnYXRlLl9oYXNUYXNrWlM7XG4gICAgICAgICAgICBpZiAoem9uZVNwZWNIYXNUYXNrIHx8IHBhcmVudEhhc1Rhc2spIHtcbiAgICAgICAgICAgICAgICAvLyBJZiB3ZSBuZWVkIHRvIHJlcG9ydCBoYXNUYXNrLCB0aGFuIHRoaXMgWlMgbmVlZHMgdG8gZG8gcmVmIGNvdW50aW5nIG9uIHRhc2tzLiBJbiBzdWNoXG4gICAgICAgICAgICAgICAgLy8gYSBjYXNlIGFsbCB0YXNrIHJlbGF0ZWQgaW50ZXJjZXB0b3JzIG11c3QgZ28gdGhyb3VnaCB0aGlzIFpELiBXZSBjYW4ndCBzaG9ydCBjaXJjdWl0IGl0LlxuICAgICAgICAgICAgICAgIHRoaXMuX2hhc1Rhc2taUyA9IHpvbmVTcGVjSGFzVGFzayA/IHpvbmVTcGVjIDogREVMRUdBVEVfWlM7XG4gICAgICAgICAgICAgICAgdGhpcy5faGFzVGFza0RsZ3QgPSBwYXJlbnREZWxlZ2F0ZTtcbiAgICAgICAgICAgICAgICB0aGlzLl9oYXNUYXNrRGxndE93bmVyID0gdGhpcztcbiAgICAgICAgICAgICAgICB0aGlzLl9oYXNUYXNrQ3VyclpvbmUgPSB6b25lO1xuICAgICAgICAgICAgICAgIGlmICghem9uZVNwZWMub25TY2hlZHVsZVRhc2spIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2NoZWR1bGVUYXNrWlMgPSBERUxFR0FURV9aUztcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2NoZWR1bGVUYXNrRGxndCA9IHBhcmVudERlbGVnYXRlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zY2hlZHVsZVRhc2tDdXJyWm9uZSA9IHRoaXMuem9uZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKCF6b25lU3BlYy5vbkludm9rZVRhc2spIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5faW52b2tlVGFza1pTID0gREVMRUdBVEVfWlM7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2ludm9rZVRhc2tEbGd0ID0gcGFyZW50RGVsZWdhdGU7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2ludm9rZVRhc2tDdXJyWm9uZSA9IHRoaXMuem9uZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKCF6b25lU3BlYy5vbkNhbmNlbFRhc2spIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY2FuY2VsVGFza1pTID0gREVMRUdBVEVfWlM7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2NhbmNlbFRhc2tEbGd0ID0gcGFyZW50RGVsZWdhdGU7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2NhbmNlbFRhc2tDdXJyWm9uZSA9IHRoaXMuem9uZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yayh0YXJnZXRab25lLCB6b25lU3BlYykge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2ZvcmtaUyA/IHRoaXMuX2ZvcmtaUy5vbkZvcmsodGhpcy5fZm9ya0RsZ3QsIHRoaXMuem9uZSwgdGFyZ2V0Wm9uZSwgem9uZVNwZWMpIDpcbiAgICAgICAgICAgICAgICBuZXcgWm9uZSh0YXJnZXRab25lLCB6b25lU3BlYyk7XG4gICAgICAgIH1cbiAgICAgICAgaW50ZXJjZXB0KHRhcmdldFpvbmUsIGNhbGxiYWNrLCBzb3VyY2UpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9pbnRlcmNlcHRaUyA/XG4gICAgICAgICAgICAgICAgdGhpcy5faW50ZXJjZXB0WlMub25JbnRlcmNlcHQodGhpcy5faW50ZXJjZXB0RGxndCwgdGhpcy5faW50ZXJjZXB0Q3VyclpvbmUsIHRhcmdldFpvbmUsIGNhbGxiYWNrLCBzb3VyY2UpIDpcbiAgICAgICAgICAgICAgICBjYWxsYmFjaztcbiAgICAgICAgfVxuICAgICAgICBpbnZva2UodGFyZ2V0Wm9uZSwgY2FsbGJhY2ssIGFwcGx5VGhpcywgYXBwbHlBcmdzLCBzb3VyY2UpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9pbnZva2VaUyA/IHRoaXMuX2ludm9rZVpTLm9uSW52b2tlKHRoaXMuX2ludm9rZURsZ3QsIHRoaXMuX2ludm9rZUN1cnJab25lLCB0YXJnZXRab25lLCBjYWxsYmFjaywgYXBwbHlUaGlzLCBhcHBseUFyZ3MsIHNvdXJjZSkgOlxuICAgICAgICAgICAgICAgIGNhbGxiYWNrLmFwcGx5KGFwcGx5VGhpcywgYXBwbHlBcmdzKTtcbiAgICAgICAgfVxuICAgICAgICBoYW5kbGVFcnJvcih0YXJnZXRab25lLCBlcnJvcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2hhbmRsZUVycm9yWlMgP1xuICAgICAgICAgICAgICAgIHRoaXMuX2hhbmRsZUVycm9yWlMub25IYW5kbGVFcnJvcih0aGlzLl9oYW5kbGVFcnJvckRsZ3QsIHRoaXMuX2hhbmRsZUVycm9yQ3VyclpvbmUsIHRhcmdldFpvbmUsIGVycm9yKSA6XG4gICAgICAgICAgICAgICAgdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBzY2hlZHVsZVRhc2sodGFyZ2V0Wm9uZSwgdGFzaykge1xuICAgICAgICAgICAgbGV0IHJldHVyblRhc2sgPSB0YXNrO1xuICAgICAgICAgICAgaWYgKHRoaXMuX3NjaGVkdWxlVGFza1pTKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2hhc1Rhc2taUykge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm5UYXNrLl96b25lRGVsZWdhdGVzLnB1c2godGhpcy5faGFzVGFza0RsZ3RPd25lcik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIGNsYW5nLWZvcm1hdCBvZmZcbiAgICAgICAgICAgICAgICByZXR1cm5UYXNrID0gdGhpcy5fc2NoZWR1bGVUYXNrWlMub25TY2hlZHVsZVRhc2sodGhpcy5fc2NoZWR1bGVUYXNrRGxndCwgdGhpcy5fc2NoZWR1bGVUYXNrQ3VyclpvbmUsIHRhcmdldFpvbmUsIHRhc2spO1xuICAgICAgICAgICAgICAgIC8vIGNsYW5nLWZvcm1hdCBvblxuICAgICAgICAgICAgICAgIGlmICghcmV0dXJuVGFzaylcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuVGFzayA9IHRhc2s7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAodGFzay5zY2hlZHVsZUZuKSB7XG4gICAgICAgICAgICAgICAgICAgIHRhc2suc2NoZWR1bGVGbih0YXNrKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAodGFzay50eXBlID09IG1pY3JvVGFzaykge1xuICAgICAgICAgICAgICAgICAgICBzY2hlZHVsZU1pY3JvVGFzayh0YXNrKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVGFzayBpcyBtaXNzaW5nIHNjaGVkdWxlRm4uJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJldHVyblRhc2s7XG4gICAgICAgIH1cbiAgICAgICAgaW52b2tlVGFzayh0YXJnZXRab25lLCB0YXNrLCBhcHBseVRoaXMsIGFwcGx5QXJncykge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2ludm9rZVRhc2taUyA/IHRoaXMuX2ludm9rZVRhc2taUy5vbkludm9rZVRhc2sodGhpcy5faW52b2tlVGFza0RsZ3QsIHRoaXMuX2ludm9rZVRhc2tDdXJyWm9uZSwgdGFyZ2V0Wm9uZSwgdGFzaywgYXBwbHlUaGlzLCBhcHBseUFyZ3MpIDpcbiAgICAgICAgICAgICAgICB0YXNrLmNhbGxiYWNrLmFwcGx5KGFwcGx5VGhpcywgYXBwbHlBcmdzKTtcbiAgICAgICAgfVxuICAgICAgICBjYW5jZWxUYXNrKHRhcmdldFpvbmUsIHRhc2spIHtcbiAgICAgICAgICAgIGxldCB2YWx1ZTtcbiAgICAgICAgICAgIGlmICh0aGlzLl9jYW5jZWxUYXNrWlMpIHtcbiAgICAgICAgICAgICAgICB2YWx1ZSA9IHRoaXMuX2NhbmNlbFRhc2taUy5vbkNhbmNlbFRhc2sodGhpcy5fY2FuY2VsVGFza0RsZ3QsIHRoaXMuX2NhbmNlbFRhc2tDdXJyWm9uZSwgdGFyZ2V0Wm9uZSwgdGFzayk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAoIXRhc2suY2FuY2VsRm4pIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgRXJyb3IoJ1Rhc2sgaXMgbm90IGNhbmNlbGFibGUnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdmFsdWUgPSB0YXNrLmNhbmNlbEZuKHRhc2spO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIGhhc1Rhc2sodGFyZ2V0Wm9uZSwgaXNFbXB0eSkge1xuICAgICAgICAgICAgLy8gaGFzVGFzayBzaG91bGQgbm90IHRocm93IGVycm9yIHNvIG90aGVyIFpvbmVEZWxlZ2F0ZVxuICAgICAgICAgICAgLy8gY2FuIHN0aWxsIHRyaWdnZXIgaGFzVGFzayBjYWxsYmFja1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICB0aGlzLl9oYXNUYXNrWlMgJiZcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5faGFzVGFza1pTLm9uSGFzVGFzayh0aGlzLl9oYXNUYXNrRGxndCwgdGhpcy5faGFzVGFza0N1cnJab25lLCB0YXJnZXRab25lLCBpc0VtcHR5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmhhbmRsZUVycm9yKHRhcmdldFpvbmUsIGVycik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOnJlcXVpcmUtaW50ZXJuYWwtd2l0aC11bmRlcnNjb3JlXG4gICAgICAgIF91cGRhdGVUYXNrQ291bnQodHlwZSwgY291bnQpIHtcbiAgICAgICAgICAgIGNvbnN0IGNvdW50cyA9IHRoaXMuX3Rhc2tDb3VudHM7XG4gICAgICAgICAgICBjb25zdCBwcmV2ID0gY291bnRzW3R5cGVdO1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IGNvdW50c1t0eXBlXSA9IHByZXYgKyBjb3VudDtcbiAgICAgICAgICAgIGlmIChuZXh0IDwgMCkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignTW9yZSB0YXNrcyBleGVjdXRlZCB0aGVuIHdlcmUgc2NoZWR1bGVkLicpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHByZXYgPT0gMCB8fCBuZXh0ID09IDApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBpc0VtcHR5ID0ge1xuICAgICAgICAgICAgICAgICAgICBtaWNyb1Rhc2s6IGNvdW50c1snbWljcm9UYXNrJ10gPiAwLFxuICAgICAgICAgICAgICAgICAgICBtYWNyb1Rhc2s6IGNvdW50c1snbWFjcm9UYXNrJ10gPiAwLFxuICAgICAgICAgICAgICAgICAgICBldmVudFRhc2s6IGNvdW50c1snZXZlbnRUYXNrJ10gPiAwLFxuICAgICAgICAgICAgICAgICAgICBjaGFuZ2U6IHR5cGVcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIHRoaXMuaGFzVGFzayh0aGlzLnpvbmUsIGlzRW1wdHkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGNsYXNzIFpvbmVUYXNrIHtcbiAgICAgICAgY29uc3RydWN0b3IodHlwZSwgc291cmNlLCBjYWxsYmFjaywgb3B0aW9ucywgc2NoZWR1bGVGbiwgY2FuY2VsRm4pIHtcbiAgICAgICAgICAgIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpyZXF1aXJlLWludGVybmFsLXdpdGgtdW5kZXJzY29yZVxuICAgICAgICAgICAgdGhpcy5fem9uZSA9IG51bGw7XG4gICAgICAgICAgICB0aGlzLnJ1bkNvdW50ID0gMDtcbiAgICAgICAgICAgIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpyZXF1aXJlLWludGVybmFsLXdpdGgtdW5kZXJzY29yZVxuICAgICAgICAgICAgdGhpcy5fem9uZURlbGVnYXRlcyA9IG51bGw7XG4gICAgICAgICAgICAvLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmU6cmVxdWlyZS1pbnRlcm5hbC13aXRoLXVuZGVyc2NvcmVcbiAgICAgICAgICAgIHRoaXMuX3N0YXRlID0gJ25vdFNjaGVkdWxlZCc7XG4gICAgICAgICAgICB0aGlzLnR5cGUgPSB0eXBlO1xuICAgICAgICAgICAgdGhpcy5zb3VyY2UgPSBzb3VyY2U7XG4gICAgICAgICAgICB0aGlzLmRhdGEgPSBvcHRpb25zO1xuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZUZuID0gc2NoZWR1bGVGbjtcbiAgICAgICAgICAgIHRoaXMuY2FuY2VsRm4gPSBjYW5jZWxGbjtcbiAgICAgICAgICAgIGlmICghY2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2NhbGxiYWNrIGlzIG5vdCBkZWZpbmVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmNhbGxiYWNrID0gY2FsbGJhY2s7XG4gICAgICAgICAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICAgICAgICAgIC8vIFRPRE86IEBKaWFMaVBhc3Npb24gb3B0aW9ucyBzaG91bGQgaGF2ZSBpbnRlcmZhY2VcbiAgICAgICAgICAgIGlmICh0eXBlID09PSBldmVudFRhc2sgJiYgb3B0aW9ucyAmJiBvcHRpb25zLnVzZUcpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmludm9rZSA9IFpvbmVUYXNrLmludm9rZVRhc2s7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLmludm9rZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFpvbmVUYXNrLmludm9rZVRhc2suY2FsbChnbG9iYWwsIHNlbGYsIHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBzdGF0aWMgaW52b2tlVGFzayh0YXNrLCB0YXJnZXQsIGFyZ3MpIHtcbiAgICAgICAgICAgIGlmICghdGFzaykge1xuICAgICAgICAgICAgICAgIHRhc2sgPSB0aGlzO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX251bWJlck9mTmVzdGVkVGFza0ZyYW1lcysrO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICB0YXNrLnJ1bkNvdW50Kys7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRhc2suem9uZS5ydW5UYXNrKHRhc2ssIHRhcmdldCwgYXJncyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICBpZiAoX251bWJlck9mTmVzdGVkVGFza0ZyYW1lcyA9PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgIGRyYWluTWljcm9UYXNrUXVldWUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgX251bWJlck9mTmVzdGVkVGFza0ZyYW1lcy0tO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGdldCB6b25lKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3pvbmU7XG4gICAgICAgIH1cbiAgICAgICAgZ2V0IHN0YXRlKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3N0YXRlO1xuICAgICAgICB9XG4gICAgICAgIGNhbmNlbFNjaGVkdWxlUmVxdWVzdCgpIHtcbiAgICAgICAgICAgIHRoaXMuX3RyYW5zaXRpb25Ubyhub3RTY2hlZHVsZWQsIHNjaGVkdWxpbmcpO1xuICAgICAgICB9XG4gICAgICAgIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpyZXF1aXJlLWludGVybmFsLXdpdGgtdW5kZXJzY29yZVxuICAgICAgICBfdHJhbnNpdGlvblRvKHRvU3RhdGUsIGZyb21TdGF0ZTEsIGZyb21TdGF0ZTIpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLl9zdGF0ZSA9PT0gZnJvbVN0YXRlMSB8fCB0aGlzLl9zdGF0ZSA9PT0gZnJvbVN0YXRlMikge1xuICAgICAgICAgICAgICAgIHRoaXMuX3N0YXRlID0gdG9TdGF0ZTtcbiAgICAgICAgICAgICAgICBpZiAodG9TdGF0ZSA9PSBub3RTY2hlZHVsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fem9uZURlbGVnYXRlcyA9IG51bGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMudHlwZX0gJyR7dGhpcy5zb3VyY2V9JzogY2FuIG5vdCB0cmFuc2l0aW9uIHRvICcke3RvU3RhdGV9JywgZXhwZWN0aW5nIHN0YXRlICcke2Zyb21TdGF0ZTF9JyR7ZnJvbVN0YXRlMiA/ICcgb3IgXFwnJyArIGZyb21TdGF0ZTIgKyAnXFwnJyA6ICcnfSwgd2FzICcke3RoaXMuX3N0YXRlfScuYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdG9TdHJpbmcoKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5kYXRhICYmIHR5cGVvZiB0aGlzLmRhdGEuaGFuZGxlSWQgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGF0YS5oYW5kbGVJZC50b1N0cmluZygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh0aGlzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBhZGQgdG9KU09OIG1ldGhvZCB0byBwcmV2ZW50IGN5Y2xpYyBlcnJvciB3aGVuXG4gICAgICAgIC8vIGNhbGwgSlNPTi5zdHJpbmdpZnkoem9uZVRhc2spXG4gICAgICAgIHRvSlNPTigpIHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgdHlwZTogdGhpcy50eXBlLFxuICAgICAgICAgICAgICAgIHN0YXRlOiB0aGlzLnN0YXRlLFxuICAgICAgICAgICAgICAgIHNvdXJjZTogdGhpcy5zb3VyY2UsXG4gICAgICAgICAgICAgICAgem9uZTogdGhpcy56b25lLm5hbWUsXG4gICAgICAgICAgICAgICAgcnVuQ291bnQ6IHRoaXMucnVuQ291bnRcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gICAgLy8vICBNSUNST1RBU0sgUVVFVUVcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgICBjb25zdCBzeW1ib2xTZXRUaW1lb3V0ID0gX19zeW1ib2xfXygnc2V0VGltZW91dCcpO1xuICAgIGNvbnN0IHN5bWJvbFByb21pc2UgPSBfX3N5bWJvbF9fKCdQcm9taXNlJyk7XG4gICAgY29uc3Qgc3ltYm9sVGhlbiA9IF9fc3ltYm9sX18oJ3RoZW4nKTtcbiAgICBsZXQgX21pY3JvVGFza1F1ZXVlID0gW107XG4gICAgbGV0IF9pc0RyYWluaW5nTWljcm90YXNrUXVldWUgPSBmYWxzZTtcbiAgICBsZXQgbmF0aXZlTWljcm9UYXNrUXVldWVQcm9taXNlO1xuICAgIGZ1bmN0aW9uIG5hdGl2ZVNjaGVkdWxlTWljcm9UYXNrKGZ1bmMpIHtcbiAgICAgICAgaWYgKCFuYXRpdmVNaWNyb1Rhc2tRdWV1ZVByb21pc2UpIHtcbiAgICAgICAgICAgIGlmIChnbG9iYWxbc3ltYm9sUHJvbWlzZV0pIHtcbiAgICAgICAgICAgICAgICBuYXRpdmVNaWNyb1Rhc2tRdWV1ZVByb21pc2UgPSBnbG9iYWxbc3ltYm9sUHJvbWlzZV0ucmVzb2x2ZSgwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAobmF0aXZlTWljcm9UYXNrUXVldWVQcm9taXNlKSB7XG4gICAgICAgICAgICBsZXQgbmF0aXZlVGhlbiA9IG5hdGl2ZU1pY3JvVGFza1F1ZXVlUHJvbWlzZVtzeW1ib2xUaGVuXTtcbiAgICAgICAgICAgIGlmICghbmF0aXZlVGhlbikge1xuICAgICAgICAgICAgICAgIC8vIG5hdGl2ZSBQcm9taXNlIGlzIG5vdCBwYXRjaGFibGUsIHdlIG5lZWQgdG8gdXNlIGB0aGVuYCBkaXJlY3RseVxuICAgICAgICAgICAgICAgIC8vIGlzc3VlIDEwNzhcbiAgICAgICAgICAgICAgICBuYXRpdmVUaGVuID0gbmF0aXZlTWljcm9UYXNrUXVldWVQcm9taXNlWyd0aGVuJ107XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBuYXRpdmVUaGVuLmNhbGwobmF0aXZlTWljcm9UYXNrUXVldWVQcm9taXNlLCBmdW5jKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGdsb2JhbFtzeW1ib2xTZXRUaW1lb3V0XShmdW5jLCAwKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBzY2hlZHVsZU1pY3JvVGFzayh0YXNrKSB7XG4gICAgICAgIC8vIGlmIHdlIGFyZSBub3QgcnVubmluZyBpbiBhbnkgdGFzaywgYW5kIHRoZXJlIGhhcyBub3QgYmVlbiBhbnl0aGluZyBzY2hlZHVsZWRcbiAgICAgICAgLy8gd2UgbXVzdCBib290c3RyYXAgdGhlIGluaXRpYWwgdGFzayBjcmVhdGlvbiBieSBtYW51YWxseSBzY2hlZHVsaW5nIHRoZSBkcmFpblxuICAgICAgICBpZiAoX251bWJlck9mTmVzdGVkVGFza0ZyYW1lcyA9PT0gMCAmJiBfbWljcm9UYXNrUXVldWUubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAvLyBXZSBhcmUgbm90IHJ1bm5pbmcgaW4gVGFzaywgc28gd2UgbmVlZCB0byBraWNrc3RhcnQgdGhlIG1pY3JvdGFzayBxdWV1ZS5cbiAgICAgICAgICAgIG5hdGl2ZVNjaGVkdWxlTWljcm9UYXNrKGRyYWluTWljcm9UYXNrUXVldWUpO1xuICAgICAgICB9XG4gICAgICAgIHRhc2sgJiYgX21pY3JvVGFza1F1ZXVlLnB1c2godGFzayk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGRyYWluTWljcm9UYXNrUXVldWUoKSB7XG4gICAgICAgIGlmICghX2lzRHJhaW5pbmdNaWNyb3Rhc2tRdWV1ZSkge1xuICAgICAgICAgICAgX2lzRHJhaW5pbmdNaWNyb3Rhc2tRdWV1ZSA9IHRydWU7XG4gICAgICAgICAgICB3aGlsZSAoX21pY3JvVGFza1F1ZXVlLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHF1ZXVlID0gX21pY3JvVGFza1F1ZXVlO1xuICAgICAgICAgICAgICAgIF9taWNyb1Rhc2tRdWV1ZSA9IFtdO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcXVldWUubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdGFzayA9IHF1ZXVlW2ldO1xuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFzay56b25lLnJ1blRhc2sodGFzaywgbnVsbCwgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfYXBpLm9uVW5oYW5kbGVkRXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX2FwaS5taWNyb3Rhc2tEcmFpbkRvbmUoKTtcbiAgICAgICAgICAgIF9pc0RyYWluaW5nTWljcm90YXNrUXVldWUgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgICAvLy8gIEJPT1RTVFJBUFxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAgIGNvbnN0IE5PX1pPTkUgPSB7IG5hbWU6ICdOTyBaT05FJyB9O1xuICAgIGNvbnN0IG5vdFNjaGVkdWxlZCA9ICdub3RTY2hlZHVsZWQnLCBzY2hlZHVsaW5nID0gJ3NjaGVkdWxpbmcnLCBzY2hlZHVsZWQgPSAnc2NoZWR1bGVkJywgcnVubmluZyA9ICdydW5uaW5nJywgY2FuY2VsaW5nID0gJ2NhbmNlbGluZycsIHVua25vd24gPSAndW5rbm93bic7XG4gICAgY29uc3QgbWljcm9UYXNrID0gJ21pY3JvVGFzaycsIG1hY3JvVGFzayA9ICdtYWNyb1Rhc2snLCBldmVudFRhc2sgPSAnZXZlbnRUYXNrJztcbiAgICBjb25zdCBwYXRjaGVzID0ge307XG4gICAgY29uc3QgX2FwaSA9IHtcbiAgICAgICAgc3ltYm9sOiBfX3N5bWJvbF9fLFxuICAgICAgICBjdXJyZW50Wm9uZUZyYW1lOiAoKSA9PiBfY3VycmVudFpvbmVGcmFtZSxcbiAgICAgICAgb25VbmhhbmRsZWRFcnJvcjogbm9vcCxcbiAgICAgICAgbWljcm90YXNrRHJhaW5Eb25lOiBub29wLFxuICAgICAgICBzY2hlZHVsZU1pY3JvVGFzazogc2NoZWR1bGVNaWNyb1Rhc2ssXG4gICAgICAgIHNob3dVbmNhdWdodEVycm9yOiAoKSA9PiAhWm9uZVtfX3N5bWJvbF9fKCdpZ25vcmVDb25zb2xlRXJyb3JVbmNhdWdodEVycm9yJyldLFxuICAgICAgICBwYXRjaEV2ZW50VGFyZ2V0OiAoKSA9PiBbXSxcbiAgICAgICAgcGF0Y2hPblByb3BlcnRpZXM6IG5vb3AsXG4gICAgICAgIHBhdGNoTWV0aG9kOiAoKSA9PiBub29wLFxuICAgICAgICBiaW5kQXJndW1lbnRzOiAoKSA9PiBbXSxcbiAgICAgICAgcGF0Y2hUaGVuOiAoKSA9PiBub29wLFxuICAgICAgICBwYXRjaE1hY3JvVGFzazogKCkgPT4gbm9vcCxcbiAgICAgICAgcGF0Y2hFdmVudFByb3RvdHlwZTogKCkgPT4gbm9vcCxcbiAgICAgICAgaXNJRU9yRWRnZTogKCkgPT4gZmFsc2UsXG4gICAgICAgIGdldEdsb2JhbE9iamVjdHM6ICgpID0+IHVuZGVmaW5lZCxcbiAgICAgICAgT2JqZWN0RGVmaW5lUHJvcGVydHk6ICgpID0+IG5vb3AsXG4gICAgICAgIE9iamVjdEdldE93blByb3BlcnR5RGVzY3JpcHRvcjogKCkgPT4gdW5kZWZpbmVkLFxuICAgICAgICBPYmplY3RDcmVhdGU6ICgpID0+IHVuZGVmaW5lZCxcbiAgICAgICAgQXJyYXlTbGljZTogKCkgPT4gW10sXG4gICAgICAgIHBhdGNoQ2xhc3M6ICgpID0+IG5vb3AsXG4gICAgICAgIHdyYXBXaXRoQ3VycmVudFpvbmU6ICgpID0+IG5vb3AsXG4gICAgICAgIGZpbHRlclByb3BlcnRpZXM6ICgpID0+IFtdLFxuICAgICAgICBhdHRhY2hPcmlnaW5Ub1BhdGNoZWQ6ICgpID0+IG5vb3AsXG4gICAgICAgIF9yZWRlZmluZVByb3BlcnR5OiAoKSA9PiBub29wLFxuICAgICAgICBwYXRjaENhbGxiYWNrczogKCkgPT4gbm9vcCxcbiAgICAgICAgbmF0aXZlU2NoZWR1bGVNaWNyb1Rhc2s6IG5hdGl2ZVNjaGVkdWxlTWljcm9UYXNrXG4gICAgfTtcbiAgICBsZXQgX2N1cnJlbnRab25lRnJhbWUgPSB7IHBhcmVudDogbnVsbCwgem9uZTogbmV3IFpvbmUobnVsbCwgbnVsbCkgfTtcbiAgICBsZXQgX2N1cnJlbnRUYXNrID0gbnVsbDtcbiAgICBsZXQgX251bWJlck9mTmVzdGVkVGFza0ZyYW1lcyA9IDA7XG4gICAgZnVuY3Rpb24gbm9vcCgpIHsgfVxuICAgIHBlcmZvcm1hbmNlTWVhc3VyZSgnWm9uZScsICdab25lJyk7XG4gICAgcmV0dXJuIGdsb2JhbFsnWm9uZSddID0gWm9uZTtcbn0pKShnbG9iYWxUaGlzKTtcblxuLyoqXG4gKiBTdXBwcmVzcyBjbG9zdXJlIGNvbXBpbGVyIGVycm9ycyBhYm91dCB1bmtub3duICdab25lJyB2YXJpYWJsZVxuICogQGZpbGVvdmVydmlld1xuICogQHN1cHByZXNzIHt1bmRlZmluZWRWYXJzLGdsb2JhbFRoaXMsbWlzc2luZ1JlcXVpcmV9XG4gKi9cbi8vLyA8cmVmZXJlbmNlIHR5cGVzPVwibm9kZVwiLz5cbi8vIGlzc3VlICM5ODksIHRvIHJlZHVjZSBidW5kbGUgc2l6ZSwgdXNlIHNob3J0IG5hbWVcbi8qKiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yICovXG5jb25zdCBPYmplY3RHZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xuLyoqIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSAqL1xuY29uc3QgT2JqZWN0RGVmaW5lUHJvcGVydHkgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG4vKiogT2JqZWN0LmdldFByb3RvdHlwZU9mICovXG5jb25zdCBPYmplY3RHZXRQcm90b3R5cGVPZiA9IE9iamVjdC5nZXRQcm90b3R5cGVPZjtcbi8qKiBPYmplY3QuY3JlYXRlICovXG5jb25zdCBPYmplY3RDcmVhdGUgPSBPYmplY3QuY3JlYXRlO1xuLyoqIEFycmF5LnByb3RvdHlwZS5zbGljZSAqL1xuY29uc3QgQXJyYXlTbGljZSA9IEFycmF5LnByb3RvdHlwZS5zbGljZTtcbi8qKiBhZGRFdmVudExpc3RlbmVyIHN0cmluZyBjb25zdCAqL1xuY29uc3QgQUREX0VWRU5UX0xJU1RFTkVSX1NUUiA9ICdhZGRFdmVudExpc3RlbmVyJztcbi8qKiByZW1vdmVFdmVudExpc3RlbmVyIHN0cmluZyBjb25zdCAqL1xuY29uc3QgUkVNT1ZFX0VWRU5UX0xJU1RFTkVSX1NUUiA9ICdyZW1vdmVFdmVudExpc3RlbmVyJztcbi8qKiB6b25lU3ltYm9sIGFkZEV2ZW50TGlzdGVuZXIgKi9cbmNvbnN0IFpPTkVfU1lNQk9MX0FERF9FVkVOVF9MSVNURU5FUiA9IFpvbmUuX19zeW1ib2xfXyhBRERfRVZFTlRfTElTVEVORVJfU1RSKTtcbi8qKiB6b25lU3ltYm9sIHJlbW92ZUV2ZW50TGlzdGVuZXIgKi9cbmNvbnN0IFpPTkVfU1lNQk9MX1JFTU9WRV9FVkVOVF9MSVNURU5FUiA9IFpvbmUuX19zeW1ib2xfXyhSRU1PVkVfRVZFTlRfTElTVEVORVJfU1RSKTtcbi8qKiB0cnVlIHN0cmluZyBjb25zdCAqL1xuY29uc3QgVFJVRV9TVFIgPSAndHJ1ZSc7XG4vKiogZmFsc2Ugc3RyaW5nIGNvbnN0ICovXG5jb25zdCBGQUxTRV9TVFIgPSAnZmFsc2UnO1xuLyoqIFpvbmUgc3ltYm9sIHByZWZpeCBzdHJpbmcgY29uc3QuICovXG5jb25zdCBaT05FX1NZTUJPTF9QUkVGSVggPSBab25lLl9fc3ltYm9sX18oJycpO1xuZnVuY3Rpb24gd3JhcFdpdGhDdXJyZW50Wm9uZShjYWxsYmFjaywgc291cmNlKSB7XG4gICAgcmV0dXJuIFpvbmUuY3VycmVudC53cmFwKGNhbGxiYWNrLCBzb3VyY2UpO1xufVxuZnVuY3Rpb24gc2NoZWR1bGVNYWNyb1Rhc2tXaXRoQ3VycmVudFpvbmUoc291cmNlLCBjYWxsYmFjaywgZGF0YSwgY3VzdG9tU2NoZWR1bGUsIGN1c3RvbUNhbmNlbCkge1xuICAgIHJldHVybiBab25lLmN1cnJlbnQuc2NoZWR1bGVNYWNyb1Rhc2soc291cmNlLCBjYWxsYmFjaywgZGF0YSwgY3VzdG9tU2NoZWR1bGUsIGN1c3RvbUNhbmNlbCk7XG59XG5jb25zdCB6b25lU3ltYm9sID0gWm9uZS5fX3N5bWJvbF9fO1xuY29uc3QgaXNXaW5kb3dFeGlzdHMgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJztcbmNvbnN0IGludGVybmFsV2luZG93ID0gaXNXaW5kb3dFeGlzdHMgPyB3aW5kb3cgOiB1bmRlZmluZWQ7XG5jb25zdCBfZ2xvYmFsID0gaXNXaW5kb3dFeGlzdHMgJiYgaW50ZXJuYWxXaW5kb3cgfHwgZ2xvYmFsVGhpcztcbmNvbnN0IFJFTU9WRV9BVFRSSUJVVEUgPSAncmVtb3ZlQXR0cmlidXRlJztcbmZ1bmN0aW9uIGJpbmRBcmd1bWVudHMoYXJncywgc291cmNlKSB7XG4gICAgZm9yIChsZXQgaSA9IGFyZ3MubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgaWYgKHR5cGVvZiBhcmdzW2ldID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBhcmdzW2ldID0gd3JhcFdpdGhDdXJyZW50Wm9uZShhcmdzW2ldLCBzb3VyY2UgKyAnXycgKyBpKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gYXJncztcbn1cbmZ1bmN0aW9uIHBhdGNoUHJvdG90eXBlKHByb3RvdHlwZSwgZm5OYW1lcykge1xuICAgIGNvbnN0IHNvdXJjZSA9IHByb3RvdHlwZS5jb25zdHJ1Y3RvclsnbmFtZSddO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm5OYW1lcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBuYW1lID0gZm5OYW1lc1tpXTtcbiAgICAgICAgY29uc3QgZGVsZWdhdGUgPSBwcm90b3R5cGVbbmFtZV07XG4gICAgICAgIGlmIChkZWxlZ2F0ZSkge1xuICAgICAgICAgICAgY29uc3QgcHJvdG90eXBlRGVzYyA9IE9iamVjdEdldE93blByb3BlcnR5RGVzY3JpcHRvcihwcm90b3R5cGUsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKCFpc1Byb3BlcnR5V3JpdGFibGUocHJvdG90eXBlRGVzYykpIHtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHByb3RvdHlwZVtuYW1lXSA9ICgoZGVsZWdhdGUpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBwYXRjaGVkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZGVsZWdhdGUuYXBwbHkodGhpcywgYmluZEFyZ3VtZW50cyhhcmd1bWVudHMsIHNvdXJjZSArICcuJyArIG5hbWUpKTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGF0dGFjaE9yaWdpblRvUGF0Y2hlZChwYXRjaGVkLCBkZWxlZ2F0ZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHBhdGNoZWQ7XG4gICAgICAgICAgICB9KShkZWxlZ2F0ZSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5mdW5jdGlvbiBpc1Byb3BlcnR5V3JpdGFibGUocHJvcGVydHlEZXNjKSB7XG4gICAgaWYgKCFwcm9wZXJ0eURlc2MpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmIChwcm9wZXJ0eURlc2Mud3JpdGFibGUgPT09IGZhbHNlKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuICEodHlwZW9mIHByb3BlcnR5RGVzYy5nZXQgPT09ICdmdW5jdGlvbicgJiYgdHlwZW9mIHByb3BlcnR5RGVzYy5zZXQgPT09ICd1bmRlZmluZWQnKTtcbn1cbmNvbnN0IGlzV2ViV29ya2VyID0gKHR5cGVvZiBXb3JrZXJHbG9iYWxTY29wZSAhPT0gJ3VuZGVmaW5lZCcgJiYgc2VsZiBpbnN0YW5jZW9mIFdvcmtlckdsb2JhbFNjb3BlKTtcbi8vIE1ha2Ugc3VyZSB0byBhY2Nlc3MgYHByb2Nlc3NgIHRocm91Z2ggYF9nbG9iYWxgIHNvIHRoYXQgV2ViUGFjayBkb2VzIG5vdCBhY2NpZGVudGFsbHkgYnJvd3NlcmlmeVxuLy8gdGhpcyBjb2RlLlxuY29uc3QgaXNOb2RlID0gKCEoJ253JyBpbiBfZ2xvYmFsKSAmJiB0eXBlb2YgX2dsb2JhbC5wcm9jZXNzICE9PSAndW5kZWZpbmVkJyAmJlxuICAgIHt9LnRvU3RyaW5nLmNhbGwoX2dsb2JhbC5wcm9jZXNzKSA9PT0gJ1tvYmplY3QgcHJvY2Vzc10nKTtcbmNvbnN0IGlzQnJvd3NlciA9ICFpc05vZGUgJiYgIWlzV2ViV29ya2VyICYmICEhKGlzV2luZG93RXhpc3RzICYmIGludGVybmFsV2luZG93WydIVE1MRWxlbWVudCddKTtcbi8vIHdlIGFyZSBpbiBlbGVjdHJvbiBvZiBudywgc28gd2UgYXJlIGJvdGggYnJvd3NlciBhbmQgbm9kZWpzXG4vLyBNYWtlIHN1cmUgdG8gYWNjZXNzIGBwcm9jZXNzYCB0aHJvdWdoIGBfZ2xvYmFsYCBzbyB0aGF0IFdlYlBhY2sgZG9lcyBub3QgYWNjaWRlbnRhbGx5IGJyb3dzZXJpZnlcbi8vIHRoaXMgY29kZS5cbmNvbnN0IGlzTWl4ID0gdHlwZW9mIF9nbG9iYWwucHJvY2VzcyAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICB7fS50b1N0cmluZy5jYWxsKF9nbG9iYWwucHJvY2VzcykgPT09ICdbb2JqZWN0IHByb2Nlc3NdJyAmJiAhaXNXZWJXb3JrZXIgJiZcbiAgICAhIShpc1dpbmRvd0V4aXN0cyAmJiBpbnRlcm5hbFdpbmRvd1snSFRNTEVsZW1lbnQnXSk7XG5jb25zdCB6b25lU3ltYm9sRXZlbnROYW1lcyQxID0ge307XG5jb25zdCB3cmFwRm4gPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci96b25lLmpzL2lzc3Vlcy85MTEsIGluIElFLCBzb21ldGltZXNcbiAgICAvLyBldmVudCB3aWxsIGJlIHVuZGVmaW5lZCwgc28gd2UgbmVlZCB0byB1c2Ugd2luZG93LmV2ZW50XG4gICAgZXZlbnQgPSBldmVudCB8fCBfZ2xvYmFsLmV2ZW50O1xuICAgIGlmICghZXZlbnQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsZXQgZXZlbnROYW1lU3ltYm9sID0gem9uZVN5bWJvbEV2ZW50TmFtZXMkMVtldmVudC50eXBlXTtcbiAgICBpZiAoIWV2ZW50TmFtZVN5bWJvbCkge1xuICAgICAgICBldmVudE5hbWVTeW1ib2wgPSB6b25lU3ltYm9sRXZlbnROYW1lcyQxW2V2ZW50LnR5cGVdID0gem9uZVN5bWJvbCgnT05fUFJPUEVSVFknICsgZXZlbnQudHlwZSk7XG4gICAgfVxuICAgIGNvbnN0IHRhcmdldCA9IHRoaXMgfHwgZXZlbnQudGFyZ2V0IHx8IF9nbG9iYWw7XG4gICAgY29uc3QgbGlzdGVuZXIgPSB0YXJnZXRbZXZlbnROYW1lU3ltYm9sXTtcbiAgICBsZXQgcmVzdWx0O1xuICAgIGlmIChpc0Jyb3dzZXIgJiYgdGFyZ2V0ID09PSBpbnRlcm5hbFdpbmRvdyAmJiBldmVudC50eXBlID09PSAnZXJyb3InKSB7XG4gICAgICAgIC8vIHdpbmRvdy5vbmVycm9yIGhhdmUgZGlmZmVyZW50IHNpZ25hdHVyZVxuICAgICAgICAvLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvR2xvYmFsRXZlbnRIYW5kbGVycy9vbmVycm9yI3dpbmRvdy5vbmVycm9yXG4gICAgICAgIC8vIGFuZCBvbmVycm9yIGNhbGxiYWNrIHdpbGwgcHJldmVudCBkZWZhdWx0IHdoZW4gY2FsbGJhY2sgcmV0dXJuIHRydWVcbiAgICAgICAgY29uc3QgZXJyb3JFdmVudCA9IGV2ZW50O1xuICAgICAgICByZXN1bHQgPSBsaXN0ZW5lciAmJlxuICAgICAgICAgICAgbGlzdGVuZXIuY2FsbCh0aGlzLCBlcnJvckV2ZW50Lm1lc3NhZ2UsIGVycm9yRXZlbnQuZmlsZW5hbWUsIGVycm9yRXZlbnQubGluZW5vLCBlcnJvckV2ZW50LmNvbG5vLCBlcnJvckV2ZW50LmVycm9yKTtcbiAgICAgICAgaWYgKHJlc3VsdCA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgcmVzdWx0ID0gbGlzdGVuZXIgJiYgbGlzdGVuZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgaWYgKHJlc3VsdCAhPSB1bmRlZmluZWQgJiYgIXJlc3VsdCkge1xuICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufTtcbmZ1bmN0aW9uIHBhdGNoUHJvcGVydHkob2JqLCBwcm9wLCBwcm90b3R5cGUpIHtcbiAgICBsZXQgZGVzYyA9IE9iamVjdEdldE93blByb3BlcnR5RGVzY3JpcHRvcihvYmosIHByb3ApO1xuICAgIGlmICghZGVzYyAmJiBwcm90b3R5cGUpIHtcbiAgICAgICAgLy8gd2hlbiBwYXRjaCB3aW5kb3cgb2JqZWN0LCB1c2UgcHJvdG90eXBlIHRvIGNoZWNrIHByb3AgZXhpc3Qgb3Igbm90XG4gICAgICAgIGNvbnN0IHByb3RvdHlwZURlc2MgPSBPYmplY3RHZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IocHJvdG90eXBlLCBwcm9wKTtcbiAgICAgICAgaWYgKHByb3RvdHlwZURlc2MpIHtcbiAgICAgICAgICAgIGRlc2MgPSB7IGVudW1lcmFibGU6IHRydWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSB9O1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIGlmIHRoZSBkZXNjcmlwdG9yIG5vdCBleGlzdHMgb3IgaXMgbm90IGNvbmZpZ3VyYWJsZVxuICAgIC8vIGp1c3QgcmV0dXJuXG4gICAgaWYgKCFkZXNjIHx8ICFkZXNjLmNvbmZpZ3VyYWJsZSkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG9uUHJvcFBhdGNoZWRTeW1ib2wgPSB6b25lU3ltYm9sKCdvbicgKyBwcm9wICsgJ3BhdGNoZWQnKTtcbiAgICBpZiAob2JqLmhhc093blByb3BlcnR5KG9uUHJvcFBhdGNoZWRTeW1ib2wpICYmIG9ialtvblByb3BQYXRjaGVkU3ltYm9sXSkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIEEgcHJvcGVydHkgZGVzY3JpcHRvciBjYW5ub3QgaGF2ZSBnZXR0ZXIvc2V0dGVyIGFuZCBiZSB3cml0YWJsZVxuICAgIC8vIGRlbGV0aW5nIHRoZSB3cml0YWJsZSBhbmQgdmFsdWUgcHJvcGVydGllcyBhdm9pZHMgdGhpcyBlcnJvcjpcbiAgICAvL1xuICAgIC8vIFR5cGVFcnJvcjogcHJvcGVydHkgZGVzY3JpcHRvcnMgbXVzdCBub3Qgc3BlY2lmeSBhIHZhbHVlIG9yIGJlIHdyaXRhYmxlIHdoZW4gYVxuICAgIC8vIGdldHRlciBvciBzZXR0ZXIgaGFzIGJlZW4gc3BlY2lmaWVkXG4gICAgZGVsZXRlIGRlc2Mud3JpdGFibGU7XG4gICAgZGVsZXRlIGRlc2MudmFsdWU7XG4gICAgY29uc3Qgb3JpZ2luYWxEZXNjR2V0ID0gZGVzYy5nZXQ7XG4gICAgY29uc3Qgb3JpZ2luYWxEZXNjU2V0ID0gZGVzYy5zZXQ7XG4gICAgLy8gc2xpY2UoMikgY3V6ICdvbmNsaWNrJyAtPiAnY2xpY2snLCBldGNcbiAgICBjb25zdCBldmVudE5hbWUgPSBwcm9wLnNsaWNlKDIpO1xuICAgIGxldCBldmVudE5hbWVTeW1ib2wgPSB6b25lU3ltYm9sRXZlbnROYW1lcyQxW2V2ZW50TmFtZV07XG4gICAgaWYgKCFldmVudE5hbWVTeW1ib2wpIHtcbiAgICAgICAgZXZlbnROYW1lU3ltYm9sID0gem9uZVN5bWJvbEV2ZW50TmFtZXMkMVtldmVudE5hbWVdID0gem9uZVN5bWJvbCgnT05fUFJPUEVSVFknICsgZXZlbnROYW1lKTtcbiAgICB9XG4gICAgZGVzYy5zZXQgPSBmdW5jdGlvbiAobmV3VmFsdWUpIHtcbiAgICAgICAgLy8gaW4gc29tZSBvZiB3aW5kb3dzJ3Mgb25wcm9wZXJ0eSBjYWxsYmFjaywgdGhpcyBpcyB1bmRlZmluZWRcbiAgICAgICAgLy8gc28gd2UgbmVlZCB0byBjaGVjayBpdFxuICAgICAgICBsZXQgdGFyZ2V0ID0gdGhpcztcbiAgICAgICAgaWYgKCF0YXJnZXQgJiYgb2JqID09PSBfZ2xvYmFsKSB7XG4gICAgICAgICAgICB0YXJnZXQgPSBfZ2xvYmFsO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGFyZ2V0KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcHJldmlvdXNWYWx1ZSA9IHRhcmdldFtldmVudE5hbWVTeW1ib2xdO1xuICAgICAgICBpZiAodHlwZW9mIHByZXZpb3VzVmFsdWUgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHRhcmdldC5yZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50TmFtZSwgd3JhcEZuKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBpc3N1ZSAjOTc4LCB3aGVuIG9ubG9hZCBoYW5kbGVyIHdhcyBhZGRlZCBiZWZvcmUgbG9hZGluZyB6b25lLmpzXG4gICAgICAgIC8vIHdlIHNob3VsZCByZW1vdmUgaXQgd2l0aCBvcmlnaW5hbERlc2NTZXRcbiAgICAgICAgb3JpZ2luYWxEZXNjU2V0ICYmIG9yaWdpbmFsRGVzY1NldC5jYWxsKHRhcmdldCwgbnVsbCk7XG4gICAgICAgIHRhcmdldFtldmVudE5hbWVTeW1ib2xdID0gbmV3VmFsdWU7XG4gICAgICAgIGlmICh0eXBlb2YgbmV3VmFsdWUgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHRhcmdldC5hZGRFdmVudExpc3RlbmVyKGV2ZW50TmFtZSwgd3JhcEZuLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8vIFRoZSBnZXR0ZXIgd291bGQgcmV0dXJuIHVuZGVmaW5lZCBmb3IgdW5hc3NpZ25lZCBwcm9wZXJ0aWVzIGJ1dCB0aGUgZGVmYXVsdCB2YWx1ZSBvZiBhblxuICAgIC8vIHVuYXNzaWduZWQgcHJvcGVydHkgaXMgbnVsbFxuICAgIGRlc2MuZ2V0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAvLyBpbiBzb21lIG9mIHdpbmRvd3MncyBvbnByb3BlcnR5IGNhbGxiYWNrLCB0aGlzIGlzIHVuZGVmaW5lZFxuICAgICAgICAvLyBzbyB3ZSBuZWVkIHRvIGNoZWNrIGl0XG4gICAgICAgIGxldCB0YXJnZXQgPSB0aGlzO1xuICAgICAgICBpZiAoIXRhcmdldCAmJiBvYmogPT09IF9nbG9iYWwpIHtcbiAgICAgICAgICAgIHRhcmdldCA9IF9nbG9iYWw7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0YXJnZXQpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGxpc3RlbmVyID0gdGFyZ2V0W2V2ZW50TmFtZVN5bWJvbF07XG4gICAgICAgIGlmIChsaXN0ZW5lcikge1xuICAgICAgICAgICAgcmV0dXJuIGxpc3RlbmVyO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG9yaWdpbmFsRGVzY0dldCkge1xuICAgICAgICAgICAgLy8gcmVzdWx0IHdpbGwgYmUgbnVsbCB3aGVuIHVzZSBpbmxpbmUgZXZlbnQgYXR0cmlidXRlLFxuICAgICAgICAgICAgLy8gc3VjaCBhcyA8YnV0dG9uIG9uY2xpY2s9XCJmdW5jKCk7XCI+T0s8L2J1dHRvbj5cbiAgICAgICAgICAgIC8vIGJlY2F1c2UgdGhlIG9uY2xpY2sgZnVuY3Rpb24gaXMgaW50ZXJuYWwgcmF3IHVuY29tcGlsZWQgaGFuZGxlclxuICAgICAgICAgICAgLy8gdGhlIG9uY2xpY2sgd2lsbCBiZSBldmFsdWF0ZWQgd2hlbiBmaXJzdCB0aW1lIGV2ZW50IHdhcyB0cmlnZ2VyZWQgb3JcbiAgICAgICAgICAgIC8vIHRoZSBwcm9wZXJ0eSBpcyBhY2Nlc3NlZCwgaHR0cHM6Ly9naXRodWIuY29tL2FuZ3VsYXIvem9uZS5qcy9pc3N1ZXMvNTI1XG4gICAgICAgICAgICAvLyBzbyB3ZSBzaG91bGQgdXNlIG9yaWdpbmFsIG5hdGl2ZSBnZXQgdG8gcmV0cmlldmUgdGhlIGhhbmRsZXJcbiAgICAgICAgICAgIGxldCB2YWx1ZSA9IG9yaWdpbmFsRGVzY0dldC5jYWxsKHRoaXMpO1xuICAgICAgICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgZGVzYy5zZXQuY2FsbCh0aGlzLCB2YWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0YXJnZXRbUkVNT1ZFX0FUVFJJQlVURV0gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LnJlbW92ZUF0dHJpYnV0ZShwcm9wKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH07XG4gICAgT2JqZWN0RGVmaW5lUHJvcGVydHkob2JqLCBwcm9wLCBkZXNjKTtcbiAgICBvYmpbb25Qcm9wUGF0Y2hlZFN5bWJvbF0gPSB0cnVlO1xufVxuZnVuY3Rpb24gcGF0Y2hPblByb3BlcnRpZXMob2JqLCBwcm9wZXJ0aWVzLCBwcm90b3R5cGUpIHtcbiAgICBpZiAocHJvcGVydGllcykge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHByb3BlcnRpZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHBhdGNoUHJvcGVydHkob2JqLCAnb24nICsgcHJvcGVydGllc1tpXSwgcHJvdG90eXBlKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc3Qgb25Qcm9wZXJ0aWVzID0gW107XG4gICAgICAgIGZvciAoY29uc3QgcHJvcCBpbiBvYmopIHtcbiAgICAgICAgICAgIGlmIChwcm9wLnNsaWNlKDAsIDIpID09ICdvbicpIHtcbiAgICAgICAgICAgICAgICBvblByb3BlcnRpZXMucHVzaChwcm9wKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IG9uUHJvcGVydGllcy5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgcGF0Y2hQcm9wZXJ0eShvYmosIG9uUHJvcGVydGllc1tqXSwgcHJvdG90eXBlKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbmNvbnN0IG9yaWdpbmFsSW5zdGFuY2VLZXkgPSB6b25lU3ltYm9sKCdvcmlnaW5hbEluc3RhbmNlJyk7XG4vLyB3cmFwIHNvbWUgbmF0aXZlIEFQSSBvbiBgd2luZG93YFxuZnVuY3Rpb24gcGF0Y2hDbGFzcyhjbGFzc05hbWUpIHtcbiAgICBjb25zdCBPcmlnaW5hbENsYXNzID0gX2dsb2JhbFtjbGFzc05hbWVdO1xuICAgIGlmICghT3JpZ2luYWxDbGFzcylcbiAgICAgICAgcmV0dXJuO1xuICAgIC8vIGtlZXAgb3JpZ2luYWwgY2xhc3MgaW4gZ2xvYmFsXG4gICAgX2dsb2JhbFt6b25lU3ltYm9sKGNsYXNzTmFtZSldID0gT3JpZ2luYWxDbGFzcztcbiAgICBfZ2xvYmFsW2NsYXNzTmFtZV0gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGNvbnN0IGEgPSBiaW5kQXJndW1lbnRzKGFyZ3VtZW50cywgY2xhc3NOYW1lKTtcbiAgICAgICAgc3dpdGNoIChhLmxlbmd0aCkge1xuICAgICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgICAgIHRoaXNbb3JpZ2luYWxJbnN0YW5jZUtleV0gPSBuZXcgT3JpZ2luYWxDbGFzcygpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgIHRoaXNbb3JpZ2luYWxJbnN0YW5jZUtleV0gPSBuZXcgT3JpZ2luYWxDbGFzcyhhWzBdKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgICAgICB0aGlzW29yaWdpbmFsSW5zdGFuY2VLZXldID0gbmV3IE9yaWdpbmFsQ2xhc3MoYVswXSwgYVsxXSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDM6XG4gICAgICAgICAgICAgICAgdGhpc1tvcmlnaW5hbEluc3RhbmNlS2V5XSA9IG5ldyBPcmlnaW5hbENsYXNzKGFbMF0sIGFbMV0sIGFbMl0pO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSA0OlxuICAgICAgICAgICAgICAgIHRoaXNbb3JpZ2luYWxJbnN0YW5jZUtleV0gPSBuZXcgT3JpZ2luYWxDbGFzcyhhWzBdLCBhWzFdLCBhWzJdLCBhWzNdKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdBcmcgbGlzdCB0b28gbG9uZy4nKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLy8gYXR0YWNoIG9yaWdpbmFsIGRlbGVnYXRlIHRvIHBhdGNoZWQgZnVuY3Rpb25cbiAgICBhdHRhY2hPcmlnaW5Ub1BhdGNoZWQoX2dsb2JhbFtjbGFzc05hbWVdLCBPcmlnaW5hbENsYXNzKTtcbiAgICBjb25zdCBpbnN0YW5jZSA9IG5ldyBPcmlnaW5hbENsYXNzKGZ1bmN0aW9uICgpIHsgfSk7XG4gICAgbGV0IHByb3A7XG4gICAgZm9yIChwcm9wIGluIGluc3RhbmNlKSB7XG4gICAgICAgIC8vIGh0dHBzOi8vYnVncy53ZWJraXQub3JnL3Nob3dfYnVnLmNnaT9pZD00NDcyMVxuICAgICAgICBpZiAoY2xhc3NOYW1lID09PSAnWE1MSHR0cFJlcXVlc3QnICYmIHByb3AgPT09ICdyZXNwb25zZUJsb2InKVxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIChmdW5jdGlvbiAocHJvcCkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBpbnN0YW5jZVtwcm9wXSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgIF9nbG9iYWxbY2xhc3NOYW1lXS5wcm90b3R5cGVbcHJvcF0gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzW29yaWdpbmFsSW5zdGFuY2VLZXldW3Byb3BdLmFwcGx5KHRoaXNbb3JpZ2luYWxJbnN0YW5jZUtleV0sIGFyZ3VtZW50cyk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIE9iamVjdERlZmluZVByb3BlcnR5KF9nbG9iYWxbY2xhc3NOYW1lXS5wcm90b3R5cGUsIHByb3AsIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0OiBmdW5jdGlvbiAoZm4pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgZm4gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW29yaWdpbmFsSW5zdGFuY2VLZXldW3Byb3BdID0gd3JhcFdpdGhDdXJyZW50Wm9uZShmbiwgY2xhc3NOYW1lICsgJy4nICsgcHJvcCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8ga2VlcCBjYWxsYmFjayBpbiB3cmFwcGVkIGZ1bmN0aW9uIHNvIHdlIGNhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHVzZSBpdCBpbiBGdW5jdGlvbi5wcm90b3R5cGUudG9TdHJpbmcgdG8gcmV0dXJuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdGhlIG5hdGl2ZSBvbmUuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0YWNoT3JpZ2luVG9QYXRjaGVkKHRoaXNbb3JpZ2luYWxJbnN0YW5jZUtleV1bcHJvcF0sIGZuKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNbb3JpZ2luYWxJbnN0YW5jZUtleV1bcHJvcF0gPSBmbjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpc1tvcmlnaW5hbEluc3RhbmNlS2V5XVtwcm9wXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KHByb3ApKTtcbiAgICB9XG4gICAgZm9yIChwcm9wIGluIE9yaWdpbmFsQ2xhc3MpIHtcbiAgICAgICAgaWYgKHByb3AgIT09ICdwcm90b3R5cGUnICYmIE9yaWdpbmFsQ2xhc3MuaGFzT3duUHJvcGVydHkocHJvcCkpIHtcbiAgICAgICAgICAgIF9nbG9iYWxbY2xhc3NOYW1lXVtwcm9wXSA9IE9yaWdpbmFsQ2xhc3NbcHJvcF07XG4gICAgICAgIH1cbiAgICB9XG59XG5mdW5jdGlvbiBwYXRjaE1ldGhvZCh0YXJnZXQsIG5hbWUsIHBhdGNoRm4pIHtcbiAgICBsZXQgcHJvdG8gPSB0YXJnZXQ7XG4gICAgd2hpbGUgKHByb3RvICYmICFwcm90by5oYXNPd25Qcm9wZXJ0eShuYW1lKSkge1xuICAgICAgICBwcm90byA9IE9iamVjdEdldFByb3RvdHlwZU9mKHByb3RvKTtcbiAgICB9XG4gICAgaWYgKCFwcm90byAmJiB0YXJnZXRbbmFtZV0pIHtcbiAgICAgICAgLy8gc29tZWhvdyB3ZSBkaWQgbm90IGZpbmQgaXQsIGJ1dCB3ZSBjYW4gc2VlIGl0LiBUaGlzIGhhcHBlbnMgb24gSUUgZm9yIFdpbmRvdyBwcm9wZXJ0aWVzLlxuICAgICAgICBwcm90byA9IHRhcmdldDtcbiAgICB9XG4gICAgY29uc3QgZGVsZWdhdGVOYW1lID0gem9uZVN5bWJvbChuYW1lKTtcbiAgICBsZXQgZGVsZWdhdGUgPSBudWxsO1xuICAgIGlmIChwcm90byAmJiAoIShkZWxlZ2F0ZSA9IHByb3RvW2RlbGVnYXRlTmFtZV0pIHx8ICFwcm90by5oYXNPd25Qcm9wZXJ0eShkZWxlZ2F0ZU5hbWUpKSkge1xuICAgICAgICBkZWxlZ2F0ZSA9IHByb3RvW2RlbGVnYXRlTmFtZV0gPSBwcm90b1tuYW1lXTtcbiAgICAgICAgLy8gY2hlY2sgd2hldGhlciBwcm90b1tuYW1lXSBpcyB3cml0YWJsZVxuICAgICAgICAvLyBzb21lIHByb3BlcnR5IGlzIHJlYWRvbmx5IGluIHNhZmFyaSwgc3VjaCBhcyBIdG1sQ2FudmFzRWxlbWVudC5wcm90b3R5cGUudG9CbG9iXG4gICAgICAgIGNvbnN0IGRlc2MgPSBwcm90byAmJiBPYmplY3RHZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IocHJvdG8sIG5hbWUpO1xuICAgICAgICBpZiAoaXNQcm9wZXJ0eVdyaXRhYmxlKGRlc2MpKSB7XG4gICAgICAgICAgICBjb25zdCBwYXRjaERlbGVnYXRlID0gcGF0Y2hGbihkZWxlZ2F0ZSwgZGVsZWdhdGVOYW1lLCBuYW1lKTtcbiAgICAgICAgICAgIHByb3RvW25hbWVdID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBwYXRjaERlbGVnYXRlKHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgYXR0YWNoT3JpZ2luVG9QYXRjaGVkKHByb3RvW25hbWVdLCBkZWxlZ2F0ZSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGRlbGVnYXRlO1xufVxuLy8gVE9ETzogQEppYUxpUGFzc2lvbiwgc3VwcG9ydCBjYW5jZWwgdGFzayBsYXRlciBpZiBuZWNlc3NhcnlcbmZ1bmN0aW9uIHBhdGNoTWFjcm9UYXNrKG9iaiwgZnVuY05hbWUsIG1ldGFDcmVhdG9yKSB7XG4gICAgbGV0IHNldE5hdGl2ZSA9IG51bGw7XG4gICAgZnVuY3Rpb24gc2NoZWR1bGVUYXNrKHRhc2spIHtcbiAgICAgICAgY29uc3QgZGF0YSA9IHRhc2suZGF0YTtcbiAgICAgICAgZGF0YS5hcmdzW2RhdGEuY2JJZHhdID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdGFzay5pbnZva2UuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgfTtcbiAgICAgICAgc2V0TmF0aXZlLmFwcGx5KGRhdGEudGFyZ2V0LCBkYXRhLmFyZ3MpO1xuICAgICAgICByZXR1cm4gdGFzaztcbiAgICB9XG4gICAgc2V0TmF0aXZlID0gcGF0Y2hNZXRob2Qob2JqLCBmdW5jTmFtZSwgKGRlbGVnYXRlKSA9PiBmdW5jdGlvbiAoc2VsZiwgYXJncykge1xuICAgICAgICBjb25zdCBtZXRhID0gbWV0YUNyZWF0b3Ioc2VsZiwgYXJncyk7XG4gICAgICAgIGlmIChtZXRhLmNiSWR4ID49IDAgJiYgdHlwZW9mIGFyZ3NbbWV0YS5jYklkeF0gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHJldHVybiBzY2hlZHVsZU1hY3JvVGFza1dpdGhDdXJyZW50Wm9uZShtZXRhLm5hbWUsIGFyZ3NbbWV0YS5jYklkeF0sIG1ldGEsIHNjaGVkdWxlVGFzayk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAvLyBjYXVzZSBhbiBlcnJvciBieSBjYWxsaW5nIGl0IGRpcmVjdGx5LlxuICAgICAgICAgICAgcmV0dXJuIGRlbGVnYXRlLmFwcGx5KHNlbGYsIGFyZ3MpO1xuICAgICAgICB9XG4gICAgfSk7XG59XG5mdW5jdGlvbiBhdHRhY2hPcmlnaW5Ub1BhdGNoZWQocGF0Y2hlZCwgb3JpZ2luYWwpIHtcbiAgICBwYXRjaGVkW3pvbmVTeW1ib2woJ09yaWdpbmFsRGVsZWdhdGUnKV0gPSBvcmlnaW5hbDtcbn1cbmxldCBpc0RldGVjdGVkSUVPckVkZ2UgPSBmYWxzZTtcbmxldCBpZU9yRWRnZSA9IGZhbHNlO1xuZnVuY3Rpb24gaXNJRSgpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCB1YSA9IGludGVybmFsV2luZG93Lm5hdmlnYXRvci51c2VyQWdlbnQ7XG4gICAgICAgIGlmICh1YS5pbmRleE9mKCdNU0lFICcpICE9PSAtMSB8fCB1YS5pbmRleE9mKCdUcmlkZW50LycpICE9PSAtMSkge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGlzSUVPckVkZ2UoKSB7XG4gICAgaWYgKGlzRGV0ZWN0ZWRJRU9yRWRnZSkge1xuICAgICAgICByZXR1cm4gaWVPckVkZ2U7XG4gICAgfVxuICAgIGlzRGV0ZWN0ZWRJRU9yRWRnZSA9IHRydWU7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdWEgPSBpbnRlcm5hbFdpbmRvdy5uYXZpZ2F0b3IudXNlckFnZW50O1xuICAgICAgICBpZiAodWEuaW5kZXhPZignTVNJRSAnKSAhPT0gLTEgfHwgdWEuaW5kZXhPZignVHJpZGVudC8nKSAhPT0gLTEgfHwgdWEuaW5kZXhPZignRWRnZS8nKSAhPT0gLTEpIHtcbiAgICAgICAgICAgIGllT3JFZGdlID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICB9XG4gICAgcmV0dXJuIGllT3JFZGdlO1xufVxuXG5ab25lLl9fbG9hZF9wYXRjaCgnWm9uZUF3YXJlUHJvbWlzZScsIChnbG9iYWwsIFpvbmUsIGFwaSkgPT4ge1xuICAgIGNvbnN0IE9iamVjdEdldE93blByb3BlcnR5RGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG4gICAgY29uc3QgT2JqZWN0RGVmaW5lUHJvcGVydHkgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG4gICAgZnVuY3Rpb24gcmVhZGFibGVPYmplY3RUb1N0cmluZyhvYmopIHtcbiAgICAgICAgaWYgKG9iaiAmJiBvYmoudG9TdHJpbmcgPT09IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcpIHtcbiAgICAgICAgICAgIGNvbnN0IGNsYXNzTmFtZSA9IG9iai5jb25zdHJ1Y3RvciAmJiBvYmouY29uc3RydWN0b3IubmFtZTtcbiAgICAgICAgICAgIHJldHVybiAoY2xhc3NOYW1lID8gY2xhc3NOYW1lIDogJycpICsgJzogJyArIEpTT04uc3RyaW5naWZ5KG9iaik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG9iaiA/IG9iai50b1N0cmluZygpIDogT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9iaik7XG4gICAgfVxuICAgIGNvbnN0IF9fc3ltYm9sX18gPSBhcGkuc3ltYm9sO1xuICAgIGNvbnN0IF91bmNhdWdodFByb21pc2VFcnJvcnMgPSBbXTtcbiAgICBjb25zdCBpc0Rpc2FibGVXcmFwcGluZ1VuY2F1Z2h0UHJvbWlzZVJlamVjdGlvbiA9IGdsb2JhbFtfX3N5bWJvbF9fKCdESVNBQkxFX1dSQVBQSU5HX1VOQ0FVR0hUX1BST01JU0VfUkVKRUNUSU9OJyldICE9PSBmYWxzZTtcbiAgICBjb25zdCBzeW1ib2xQcm9taXNlID0gX19zeW1ib2xfXygnUHJvbWlzZScpO1xuICAgIGNvbnN0IHN5bWJvbFRoZW4gPSBfX3N5bWJvbF9fKCd0aGVuJyk7XG4gICAgY29uc3QgY3JlYXRpb25UcmFjZSA9ICdfX2NyZWF0aW9uVHJhY2VfXyc7XG4gICAgYXBpLm9uVW5oYW5kbGVkRXJyb3IgPSAoZSkgPT4ge1xuICAgICAgICBpZiAoYXBpLnNob3dVbmNhdWdodEVycm9yKCkpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlamVjdGlvbiA9IGUgJiYgZS5yZWplY3Rpb247XG4gICAgICAgICAgICBpZiAocmVqZWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignVW5oYW5kbGVkIFByb21pc2UgcmVqZWN0aW9uOicsIHJlamVjdGlvbiBpbnN0YW5jZW9mIEVycm9yID8gcmVqZWN0aW9uLm1lc3NhZ2UgOiByZWplY3Rpb24sICc7IFpvbmU6JywgZS56b25lLm5hbWUsICc7IFRhc2s6JywgZS50YXNrICYmIGUudGFzay5zb3VyY2UsICc7IFZhbHVlOicsIHJlamVjdGlvbiwgcmVqZWN0aW9uIGluc3RhbmNlb2YgRXJyb3IgPyByZWplY3Rpb24uc3RhY2sgOiB1bmRlZmluZWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgYXBpLm1pY3JvdGFza0RyYWluRG9uZSA9ICgpID0+IHtcbiAgICAgICAgd2hpbGUgKF91bmNhdWdodFByb21pc2VFcnJvcnMubGVuZ3RoKSB7XG4gICAgICAgICAgICBjb25zdCB1bmNhdWdodFByb21pc2VFcnJvciA9IF91bmNhdWdodFByb21pc2VFcnJvcnMuc2hpZnQoKTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgdW5jYXVnaHRQcm9taXNlRXJyb3Iuem9uZS5ydW5HdWFyZGVkKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHVuY2F1Z2h0UHJvbWlzZUVycm9yLnRocm93T3JpZ2luYWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IHVuY2F1Z2h0UHJvbWlzZUVycm9yLnJlamVjdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB0aHJvdyB1bmNhdWdodFByb21pc2VFcnJvcjtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGhhbmRsZVVuaGFuZGxlZFJlamVjdGlvbihlcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IFVOSEFORExFRF9QUk9NSVNFX1JFSkVDVElPTl9IQU5ETEVSX1NZTUJPTCA9IF9fc3ltYm9sX18oJ3VuaGFuZGxlZFByb21pc2VSZWplY3Rpb25IYW5kbGVyJyk7XG4gICAgZnVuY3Rpb24gaGFuZGxlVW5oYW5kbGVkUmVqZWN0aW9uKGUpIHtcbiAgICAgICAgYXBpLm9uVW5oYW5kbGVkRXJyb3IoZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBoYW5kbGVyID0gWm9uZVtVTkhBTkRMRURfUFJPTUlTRV9SRUpFQ1RJT05fSEFORExFUl9TWU1CT0xdO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBoYW5kbGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgaGFuZGxlci5jYWxsKHRoaXMsIGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBpc1RoZW5hYmxlKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSAmJiB2YWx1ZS50aGVuO1xuICAgIH1cbiAgICBmdW5jdGlvbiBmb3J3YXJkUmVzb2x1dGlvbih2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGZvcndhcmRSZWplY3Rpb24ocmVqZWN0aW9uKSB7XG4gICAgICAgIHJldHVybiBab25lQXdhcmVQcm9taXNlLnJlamVjdChyZWplY3Rpb24pO1xuICAgIH1cbiAgICBjb25zdCBzeW1ib2xTdGF0ZSA9IF9fc3ltYm9sX18oJ3N0YXRlJyk7XG4gICAgY29uc3Qgc3ltYm9sVmFsdWUgPSBfX3N5bWJvbF9fKCd2YWx1ZScpO1xuICAgIGNvbnN0IHN5bWJvbEZpbmFsbHkgPSBfX3N5bWJvbF9fKCdmaW5hbGx5Jyk7XG4gICAgY29uc3Qgc3ltYm9sUGFyZW50UHJvbWlzZVZhbHVlID0gX19zeW1ib2xfXygncGFyZW50UHJvbWlzZVZhbHVlJyk7XG4gICAgY29uc3Qgc3ltYm9sUGFyZW50UHJvbWlzZVN0YXRlID0gX19zeW1ib2xfXygncGFyZW50UHJvbWlzZVN0YXRlJyk7XG4gICAgY29uc3Qgc291cmNlID0gJ1Byb21pc2UudGhlbic7XG4gICAgY29uc3QgVU5SRVNPTFZFRCA9IG51bGw7XG4gICAgY29uc3QgUkVTT0xWRUQgPSB0cnVlO1xuICAgIGNvbnN0IFJFSkVDVEVEID0gZmFsc2U7XG4gICAgY29uc3QgUkVKRUNURURfTk9fQ0FUQ0ggPSAwO1xuICAgIGZ1bmN0aW9uIG1ha2VSZXNvbHZlcihwcm9taXNlLCBzdGF0ZSkge1xuICAgICAgICByZXR1cm4gKHYpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZVByb21pc2UocHJvbWlzZSwgc3RhdGUsIHYpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgIHJlc29sdmVQcm9taXNlKHByb21pc2UsIGZhbHNlLCBlcnIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gRG8gbm90IHJldHVybiB2YWx1ZSBvciB5b3Ugd2lsbCBicmVhayB0aGUgUHJvbWlzZSBzcGVjLlxuICAgICAgICB9O1xuICAgIH1cbiAgICBjb25zdCBvbmNlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBsZXQgd2FzQ2FsbGVkID0gZmFsc2U7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiB3cmFwcGVyKHdyYXBwZWRGdW5jdGlvbikge1xuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBpZiAod2FzQ2FsbGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgd2FzQ2FsbGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB3cmFwcGVkRnVuY3Rpb24uYXBwbHkobnVsbCwgYXJndW1lbnRzKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH07XG4gICAgfTtcbiAgICBjb25zdCBUWVBFX0VSUk9SID0gJ1Byb21pc2UgcmVzb2x2ZWQgd2l0aCBpdHNlbGYnO1xuICAgIGNvbnN0IENVUlJFTlRfVEFTS19UUkFDRV9TWU1CT0wgPSBfX3N5bWJvbF9fKCdjdXJyZW50VGFza1RyYWNlJyk7XG4gICAgLy8gUHJvbWlzZSBSZXNvbHV0aW9uXG4gICAgZnVuY3Rpb24gcmVzb2x2ZVByb21pc2UocHJvbWlzZSwgc3RhdGUsIHZhbHVlKSB7XG4gICAgICAgIGNvbnN0IG9uY2VXcmFwcGVyID0gb25jZSgpO1xuICAgICAgICBpZiAocHJvbWlzZSA9PT0gdmFsdWUpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoVFlQRV9FUlJPUik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHByb21pc2Vbc3ltYm9sU3RhdGVdID09PSBVTlJFU09MVkVEKSB7XG4gICAgICAgICAgICAvLyBzaG91bGQgb25seSBnZXQgdmFsdWUudGhlbiBvbmNlIGJhc2VkIG9uIHByb21pc2Ugc3BlYy5cbiAgICAgICAgICAgIGxldCB0aGVuID0gbnVsbDtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgfHwgdHlwZW9mIHZhbHVlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoZW4gPSB2YWx1ZSAmJiB2YWx1ZS50aGVuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICBvbmNlV3JhcHBlcigoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmVQcm9taXNlKHByb21pc2UsIGZhbHNlLCBlcnIpO1xuICAgICAgICAgICAgICAgIH0pKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBpZiAodmFsdWUgaW5zdGFuY2VvZiBab25lQXdhcmVQcm9taXNlKSB7XG4gICAgICAgICAgICBpZiAoc3RhdGUgIT09IFJFSkVDVEVEICYmIHZhbHVlIGluc3RhbmNlb2YgWm9uZUF3YXJlUHJvbWlzZSAmJlxuICAgICAgICAgICAgICAgIHZhbHVlLmhhc093blByb3BlcnR5KHN5bWJvbFN0YXRlKSAmJiB2YWx1ZS5oYXNPd25Qcm9wZXJ0eShzeW1ib2xWYWx1ZSkgJiZcbiAgICAgICAgICAgICAgICB2YWx1ZVtzeW1ib2xTdGF0ZV0gIT09IFVOUkVTT0xWRUQpIHtcbiAgICAgICAgICAgICAgICBjbGVhclJlamVjdGVkTm9DYXRjaCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZVByb21pc2UocHJvbWlzZSwgdmFsdWVbc3ltYm9sU3RhdGVdLCB2YWx1ZVtzeW1ib2xWYWx1ZV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoc3RhdGUgIT09IFJFSkVDVEVEICYmIHR5cGVvZiB0aGVuID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgdGhlbi5jYWxsKHZhbHVlLCBvbmNlV3JhcHBlcihtYWtlUmVzb2x2ZXIocHJvbWlzZSwgc3RhdGUpKSwgb25jZVdyYXBwZXIobWFrZVJlc29sdmVyKHByb21pc2UsIGZhbHNlKSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIG9uY2VXcmFwcGVyKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmVQcm9taXNlKHByb21pc2UsIGZhbHNlLCBlcnIpO1xuICAgICAgICAgICAgICAgICAgICB9KSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHByb21pc2Vbc3ltYm9sU3RhdGVdID0gc3RhdGU7XG4gICAgICAgICAgICAgICAgY29uc3QgcXVldWUgPSBwcm9taXNlW3N5bWJvbFZhbHVlXTtcbiAgICAgICAgICAgICAgICBwcm9taXNlW3N5bWJvbFZhbHVlXSA9IHZhbHVlO1xuICAgICAgICAgICAgICAgIGlmIChwcm9taXNlW3N5bWJvbEZpbmFsbHldID09PSBzeW1ib2xGaW5hbGx5KSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIHRoZSBwcm9taXNlIGlzIGdlbmVyYXRlZCBieSBQcm9taXNlLnByb3RvdHlwZS5maW5hbGx5XG4gICAgICAgICAgICAgICAgICAgIGlmIChzdGF0ZSA9PT0gUkVTT0xWRUQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRoZSBzdGF0ZSBpcyByZXNvbHZlZCwgc2hvdWxkIGlnbm9yZSB0aGUgdmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGFuZCB1c2UgcGFyZW50IHByb21pc2UgdmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb21pc2Vbc3ltYm9sU3RhdGVdID0gcHJvbWlzZVtzeW1ib2xQYXJlbnRQcm9taXNlU3RhdGVdO1xuICAgICAgICAgICAgICAgICAgICAgICAgcHJvbWlzZVtzeW1ib2xWYWx1ZV0gPSBwcm9taXNlW3N5bWJvbFBhcmVudFByb21pc2VWYWx1ZV07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gcmVjb3JkIHRhc2sgaW5mb3JtYXRpb24gaW4gdmFsdWUgd2hlbiBlcnJvciBvY2N1cnMsIHNvIHdlIGNhblxuICAgICAgICAgICAgICAgIC8vIGRvIHNvbWUgYWRkaXRpb25hbCB3b3JrIHN1Y2ggYXMgcmVuZGVyIGxvbmdTdGFja1RyYWNlXG4gICAgICAgICAgICAgICAgaWYgKHN0YXRlID09PSBSRUpFQ1RFRCAmJiB2YWx1ZSBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNoZWNrIGlmIGxvbmdTdGFja1RyYWNlWm9uZSBpcyBoZXJlXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHRyYWNlID0gWm9uZS5jdXJyZW50VGFzayAmJiBab25lLmN1cnJlbnRUYXNrLmRhdGEgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIFpvbmUuY3VycmVudFRhc2suZGF0YVtjcmVhdGlvblRyYWNlXTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRyYWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBvbmx5IGtlZXAgdGhlIGxvbmcgc3RhY2sgdHJhY2UgaW50byBlcnJvciB3aGVuIGluIGxvbmdTdGFja1RyYWNlWm9uZVxuICAgICAgICAgICAgICAgICAgICAgICAgT2JqZWN0RGVmaW5lUHJvcGVydHkodmFsdWUsIENVUlJFTlRfVEFTS19UUkFDRV9TWU1CT0wsIHsgY29uZmlndXJhYmxlOiB0cnVlLCBlbnVtZXJhYmxlOiBmYWxzZSwgd3JpdGFibGU6IHRydWUsIHZhbHVlOiB0cmFjZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHF1ZXVlLmxlbmd0aDspIHtcbiAgICAgICAgICAgICAgICAgICAgc2NoZWR1bGVSZXNvbHZlT3JSZWplY3QocHJvbWlzZSwgcXVldWVbaSsrXSwgcXVldWVbaSsrXSwgcXVldWVbaSsrXSwgcXVldWVbaSsrXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChxdWV1ZS5sZW5ndGggPT0gMCAmJiBzdGF0ZSA9PSBSRUpFQ1RFRCkge1xuICAgICAgICAgICAgICAgICAgICBwcm9taXNlW3N5bWJvbFN0YXRlXSA9IFJFSkVDVEVEX05PX0NBVENIO1xuICAgICAgICAgICAgICAgICAgICBsZXQgdW5jYXVnaHRQcm9taXNlRXJyb3IgPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEhlcmUgd2UgdGhyb3dzIGEgbmV3IEVycm9yIHRvIHByaW50IG1vcmUgcmVhZGFibGUgZXJyb3IgbG9nXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBhbmQgaWYgdGhlIHZhbHVlIGlzIG5vdCBhbiBlcnJvciwgem9uZS5qcyBidWlsZHMgYW4gYEVycm9yYFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gT2JqZWN0IGhlcmUgdG8gYXR0YWNoIHRoZSBzdGFjayBpbmZvcm1hdGlvbi5cbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVW5jYXVnaHQgKGluIHByb21pc2UpOiAnICsgcmVhZGFibGVPYmplY3RUb1N0cmluZyh2YWx1ZSkgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICh2YWx1ZSAmJiB2YWx1ZS5zdGFjayA/ICdcXG4nICsgdmFsdWUuc3RhY2sgOiAnJykpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVuY2F1Z2h0UHJvbWlzZUVycm9yID0gZXJyO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc0Rpc2FibGVXcmFwcGluZ1VuY2F1Z2h0UHJvbWlzZVJlamVjdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gSWYgZGlzYWJsZSB3cmFwcGluZyB1bmNhdWdodCBwcm9taXNlIHJlamVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdXNlIHRoZSB2YWx1ZSBpbnN0ZWFkIG9mIHdyYXBwaW5nIGl0LlxuICAgICAgICAgICAgICAgICAgICAgICAgdW5jYXVnaHRQcm9taXNlRXJyb3IudGhyb3dPcmlnaW5hbCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdW5jYXVnaHRQcm9taXNlRXJyb3IucmVqZWN0aW9uID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIHVuY2F1Z2h0UHJvbWlzZUVycm9yLnByb21pc2UgPSBwcm9taXNlO1xuICAgICAgICAgICAgICAgICAgICB1bmNhdWdodFByb21pc2VFcnJvci56b25lID0gWm9uZS5jdXJyZW50O1xuICAgICAgICAgICAgICAgICAgICB1bmNhdWdodFByb21pc2VFcnJvci50YXNrID0gWm9uZS5jdXJyZW50VGFzaztcbiAgICAgICAgICAgICAgICAgICAgX3VuY2F1Z2h0UHJvbWlzZUVycm9ycy5wdXNoKHVuY2F1Z2h0UHJvbWlzZUVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgYXBpLnNjaGVkdWxlTWljcm9UYXNrKCk7IC8vIHRvIG1ha2Ugc3VyZSB0aGF0IGl0IGlzIHJ1bm5pbmdcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmVzb2x2aW5nIGFuIGFscmVhZHkgcmVzb2x2ZWQgcHJvbWlzZSBpcyBhIG5vb3AuXG4gICAgICAgIHJldHVybiBwcm9taXNlO1xuICAgIH1cbiAgICBjb25zdCBSRUpFQ1RJT05fSEFORExFRF9IQU5ETEVSID0gX19zeW1ib2xfXygncmVqZWN0aW9uSGFuZGxlZEhhbmRsZXInKTtcbiAgICBmdW5jdGlvbiBjbGVhclJlamVjdGVkTm9DYXRjaChwcm9taXNlKSB7XG4gICAgICAgIGlmIChwcm9taXNlW3N5bWJvbFN0YXRlXSA9PT0gUkVKRUNURURfTk9fQ0FUQ0gpIHtcbiAgICAgICAgICAgIC8vIGlmIHRoZSBwcm9taXNlIGlzIHJlamVjdGVkIG5vIGNhdGNoIHN0YXR1c1xuICAgICAgICAgICAgLy8gYW5kIHF1ZXVlLmxlbmd0aCA+IDAsIG1lYW5zIHRoZXJlIGlzIGEgZXJyb3IgaGFuZGxlclxuICAgICAgICAgICAgLy8gaGVyZSB0byBoYW5kbGUgdGhlIHJlamVjdGVkIHByb21pc2UsIHdlIHNob3VsZCB0cmlnZ2VyXG4gICAgICAgICAgICAvLyB3aW5kb3dzLnJlamVjdGlvbmhhbmRsZWQgZXZlbnRIYW5kbGVyIG9yIG5vZGVqcyByZWplY3Rpb25IYW5kbGVkXG4gICAgICAgICAgICAvLyBldmVudEhhbmRsZXJcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaGFuZGxlciA9IFpvbmVbUkVKRUNUSU9OX0hBTkRMRURfSEFORExFUl07XG4gICAgICAgICAgICAgICAgaWYgKGhhbmRsZXIgJiYgdHlwZW9mIGhhbmRsZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlci5jYWxsKHRoaXMsIHsgcmVqZWN0aW9uOiBwcm9taXNlW3N5bWJvbFZhbHVlXSwgcHJvbWlzZTogcHJvbWlzZSB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBwcm9taXNlW3N5bWJvbFN0YXRlXSA9IFJFSkVDVEVEO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfdW5jYXVnaHRQcm9taXNlRXJyb3JzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb21pc2UgPT09IF91bmNhdWdodFByb21pc2VFcnJvcnNbaV0ucHJvbWlzZSkge1xuICAgICAgICAgICAgICAgICAgICBfdW5jYXVnaHRQcm9taXNlRXJyb3JzLnNwbGljZShpLCAxKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gc2NoZWR1bGVSZXNvbHZlT3JSZWplY3QocHJvbWlzZSwgem9uZSwgY2hhaW5Qcm9taXNlLCBvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCkge1xuICAgICAgICBjbGVhclJlamVjdGVkTm9DYXRjaChwcm9taXNlKTtcbiAgICAgICAgY29uc3QgcHJvbWlzZVN0YXRlID0gcHJvbWlzZVtzeW1ib2xTdGF0ZV07XG4gICAgICAgIGNvbnN0IGRlbGVnYXRlID0gcHJvbWlzZVN0YXRlID9cbiAgICAgICAgICAgICh0eXBlb2Ygb25GdWxmaWxsZWQgPT09ICdmdW5jdGlvbicpID8gb25GdWxmaWxsZWQgOiBmb3J3YXJkUmVzb2x1dGlvbiA6XG4gICAgICAgICAgICAodHlwZW9mIG9uUmVqZWN0ZWQgPT09ICdmdW5jdGlvbicpID8gb25SZWplY3RlZCA6XG4gICAgICAgICAgICAgICAgZm9yd2FyZFJlamVjdGlvbjtcbiAgICAgICAgem9uZS5zY2hlZHVsZU1pY3JvVGFzayhzb3VyY2UsICgpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcGFyZW50UHJvbWlzZVZhbHVlID0gcHJvbWlzZVtzeW1ib2xWYWx1ZV07XG4gICAgICAgICAgICAgICAgY29uc3QgaXNGaW5hbGx5UHJvbWlzZSA9ICEhY2hhaW5Qcm9taXNlICYmIHN5bWJvbEZpbmFsbHkgPT09IGNoYWluUHJvbWlzZVtzeW1ib2xGaW5hbGx5XTtcbiAgICAgICAgICAgICAgICBpZiAoaXNGaW5hbGx5UHJvbWlzZSkge1xuICAgICAgICAgICAgICAgICAgICAvLyBpZiB0aGUgcHJvbWlzZSBpcyBnZW5lcmF0ZWQgZnJvbSBmaW5hbGx5IGNhbGwsIGtlZXAgcGFyZW50IHByb21pc2UncyBzdGF0ZSBhbmQgdmFsdWVcbiAgICAgICAgICAgICAgICAgICAgY2hhaW5Qcm9taXNlW3N5bWJvbFBhcmVudFByb21pc2VWYWx1ZV0gPSBwYXJlbnRQcm9taXNlVmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIGNoYWluUHJvbWlzZVtzeW1ib2xQYXJlbnRQcm9taXNlU3RhdGVdID0gcHJvbWlzZVN0YXRlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBzaG91bGQgbm90IHBhc3MgdmFsdWUgdG8gZmluYWxseSBjYWxsYmFja1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gem9uZS5ydW4oZGVsZWdhdGUsIHVuZGVmaW5lZCwgaXNGaW5hbGx5UHJvbWlzZSAmJiBkZWxlZ2F0ZSAhPT0gZm9yd2FyZFJlamVjdGlvbiAmJiBkZWxlZ2F0ZSAhPT0gZm9yd2FyZFJlc29sdXRpb24gP1xuICAgICAgICAgICAgICAgICAgICBbXSA6XG4gICAgICAgICAgICAgICAgICAgIFtwYXJlbnRQcm9taXNlVmFsdWVdKTtcbiAgICAgICAgICAgICAgICByZXNvbHZlUHJvbWlzZShjaGFpblByb21pc2UsIHRydWUsIHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIC8vIGlmIGVycm9yIG9jY3Vycywgc2hvdWxkIGFsd2F5cyByZXR1cm4gdGhpcyBlcnJvclxuICAgICAgICAgICAgICAgIHJlc29sdmVQcm9taXNlKGNoYWluUHJvbWlzZSwgZmFsc2UsIGVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgY2hhaW5Qcm9taXNlKTtcbiAgICB9XG4gICAgY29uc3QgWk9ORV9BV0FSRV9QUk9NSVNFX1RPX1NUUklORyA9ICdmdW5jdGlvbiBab25lQXdhcmVQcm9taXNlKCkgeyBbbmF0aXZlIGNvZGVdIH0nO1xuICAgIGNvbnN0IG5vb3AgPSBmdW5jdGlvbiAoKSB7IH07XG4gICAgY29uc3QgQWdncmVnYXRlRXJyb3IgPSBnbG9iYWwuQWdncmVnYXRlRXJyb3I7XG4gICAgY2xhc3MgWm9uZUF3YXJlUHJvbWlzZSB7XG4gICAgICAgIHN0YXRpYyB0b1N0cmluZygpIHtcbiAgICAgICAgICAgIHJldHVybiBaT05FX0FXQVJFX1BST01JU0VfVE9fU1RSSU5HO1xuICAgICAgICB9XG4gICAgICAgIHN0YXRpYyByZXNvbHZlKHZhbHVlKSB7XG4gICAgICAgICAgICByZXR1cm4gcmVzb2x2ZVByb21pc2UobmV3IHRoaXMobnVsbCksIFJFU09MVkVELCB2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgc3RhdGljIHJlamVjdChlcnJvcikge1xuICAgICAgICAgICAgcmV0dXJuIHJlc29sdmVQcm9taXNlKG5ldyB0aGlzKG51bGwpLCBSRUpFQ1RFRCwgZXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIHN0YXRpYyBhbnkodmFsdWVzKSB7XG4gICAgICAgICAgICBpZiAoIXZhbHVlcyB8fCB0eXBlb2YgdmFsdWVzW1N5bWJvbC5pdGVyYXRvcl0gIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEFnZ3JlZ2F0ZUVycm9yKFtdLCAnQWxsIHByb21pc2VzIHdlcmUgcmVqZWN0ZWQnKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBwcm9taXNlcyA9IFtdO1xuICAgICAgICAgICAgbGV0IGNvdW50ID0gMDtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgdiBvZiB2YWx1ZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgY291bnQrKztcbiAgICAgICAgICAgICAgICAgICAgcHJvbWlzZXMucHVzaChab25lQXdhcmVQcm9taXNlLnJlc29sdmUodikpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEFnZ3JlZ2F0ZUVycm9yKFtdLCAnQWxsIHByb21pc2VzIHdlcmUgcmVqZWN0ZWQnKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY291bnQgPT09IDApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEFnZ3JlZ2F0ZUVycm9yKFtdLCAnQWxsIHByb21pc2VzIHdlcmUgcmVqZWN0ZWQnKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgZmluaXNoZWQgPSBmYWxzZTtcbiAgICAgICAgICAgIGNvbnN0IGVycm9ycyA9IFtdO1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBab25lQXdhcmVQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHByb21pc2VzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIHByb21pc2VzW2ldLnRoZW4odiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmluaXNoZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBmaW5pc2hlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHYpO1xuICAgICAgICAgICAgICAgICAgICB9LCBlcnIgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JzLnB1c2goZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50LS07XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoY291bnQgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaW5pc2hlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KG5ldyBBZ2dyZWdhdGVFcnJvcihlcnJvcnMsICdBbGwgcHJvbWlzZXMgd2VyZSByZWplY3RlZCcpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgO1xuICAgICAgICBzdGF0aWMgcmFjZSh2YWx1ZXMpIHtcbiAgICAgICAgICAgIGxldCByZXNvbHZlO1xuICAgICAgICAgICAgbGV0IHJlamVjdDtcbiAgICAgICAgICAgIGxldCBwcm9taXNlID0gbmV3IHRoaXMoKHJlcywgcmVqKSA9PiB7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSA9IHJlcztcbiAgICAgICAgICAgICAgICByZWplY3QgPSByZWo7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGZ1bmN0aW9uIG9uUmVzb2x2ZSh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIHJlc29sdmUodmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZnVuY3Rpb24gb25SZWplY3QoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICByZWplY3QoZXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChsZXQgdmFsdWUgb2YgdmFsdWVzKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFpc1RoZW5hYmxlKHZhbHVlKSkge1xuICAgICAgICAgICAgICAgICAgICB2YWx1ZSA9IHRoaXMucmVzb2x2ZSh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHZhbHVlLnRoZW4ob25SZXNvbHZlLCBvblJlamVjdCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcHJvbWlzZTtcbiAgICAgICAgfVxuICAgICAgICBzdGF0aWMgYWxsKHZhbHVlcykge1xuICAgICAgICAgICAgcmV0dXJuIFpvbmVBd2FyZVByb21pc2UuYWxsV2l0aENhbGxiYWNrKHZhbHVlcyk7XG4gICAgICAgIH1cbiAgICAgICAgc3RhdGljIGFsbFNldHRsZWQodmFsdWVzKSB7XG4gICAgICAgICAgICBjb25zdCBQID0gdGhpcyAmJiB0aGlzLnByb3RvdHlwZSBpbnN0YW5jZW9mIFpvbmVBd2FyZVByb21pc2UgPyB0aGlzIDogWm9uZUF3YXJlUHJvbWlzZTtcbiAgICAgICAgICAgIHJldHVybiBQLmFsbFdpdGhDYWxsYmFjayh2YWx1ZXMsIHtcbiAgICAgICAgICAgICAgICB0aGVuQ2FsbGJhY2s6ICh2YWx1ZSkgPT4gKHsgc3RhdHVzOiAnZnVsZmlsbGVkJywgdmFsdWUgfSksXG4gICAgICAgICAgICAgICAgZXJyb3JDYWxsYmFjazogKGVycikgPT4gKHsgc3RhdHVzOiAncmVqZWN0ZWQnLCByZWFzb246IGVyciB9KVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgc3RhdGljIGFsbFdpdGhDYWxsYmFjayh2YWx1ZXMsIGNhbGxiYWNrKSB7XG4gICAgICAgICAgICBsZXQgcmVzb2x2ZTtcbiAgICAgICAgICAgIGxldCByZWplY3Q7XG4gICAgICAgICAgICBsZXQgcHJvbWlzZSA9IG5ldyB0aGlzKChyZXMsIHJlaikgPT4ge1xuICAgICAgICAgICAgICAgIHJlc29sdmUgPSByZXM7XG4gICAgICAgICAgICAgICAgcmVqZWN0ID0gcmVqO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAvLyBTdGFydCBhdCAyIHRvIHByZXZlbnQgcHJlbWF0dXJlbHkgcmVzb2x2aW5nIGlmIC50aGVuIGlzIGNhbGxlZCBpbW1lZGlhdGVseS5cbiAgICAgICAgICAgIGxldCB1bnJlc29sdmVkQ291bnQgPSAyO1xuICAgICAgICAgICAgbGV0IHZhbHVlSW5kZXggPSAwO1xuICAgICAgICAgICAgY29uc3QgcmVzb2x2ZWRWYWx1ZXMgPSBbXTtcbiAgICAgICAgICAgIGZvciAobGV0IHZhbHVlIG9mIHZhbHVlcykge1xuICAgICAgICAgICAgICAgIGlmICghaXNUaGVuYWJsZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFsdWUgPSB0aGlzLnJlc29sdmUodmFsdWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBjdXJWYWx1ZUluZGV4ID0gdmFsdWVJbmRleDtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICB2YWx1ZS50aGVuKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZWRWYWx1ZXNbY3VyVmFsdWVJbmRleF0gPSBjYWxsYmFjayA/IGNhbGxiYWNrLnRoZW5DYWxsYmFjayh2YWx1ZSkgOiB2YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVucmVzb2x2ZWRDb3VudC0tO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHVucmVzb2x2ZWRDb3VudCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzb2x2ZWRWYWx1ZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9LCAoZXJyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWNhbGxiYWNrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlZFZhbHVlc1tjdXJWYWx1ZUluZGV4XSA9IGNhbGxiYWNrLmVycm9yQ2FsbGJhY2soZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1bnJlc29sdmVkQ291bnQtLTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodW5yZXNvbHZlZENvdW50ID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzb2x2ZWRWYWx1ZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoICh0aGVuRXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlamVjdCh0aGVuRXJyKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdW5yZXNvbHZlZENvdW50Kys7XG4gICAgICAgICAgICAgICAgdmFsdWVJbmRleCsrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gTWFrZSB0aGUgdW5yZXNvbHZlZENvdW50IHplcm8tYmFzZWQgYWdhaW4uXG4gICAgICAgICAgICB1bnJlc29sdmVkQ291bnQgLT0gMjtcbiAgICAgICAgICAgIGlmICh1bnJlc29sdmVkQ291bnQgPT09IDApIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHJlc29sdmVkVmFsdWVzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBwcm9taXNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0cnVjdG9yKGV4ZWN1dG9yKSB7XG4gICAgICAgICAgICBjb25zdCBwcm9taXNlID0gdGhpcztcbiAgICAgICAgICAgIGlmICghKHByb21pc2UgaW5zdGFuY2VvZiBab25lQXdhcmVQcm9taXNlKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignTXVzdCBiZSBhbiBpbnN0YW5jZW9mIFByb21pc2UuJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBwcm9taXNlW3N5bWJvbFN0YXRlXSA9IFVOUkVTT0xWRUQ7XG4gICAgICAgICAgICBwcm9taXNlW3N5bWJvbFZhbHVlXSA9IFtdOyAvLyBxdWV1ZTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgb25jZVdyYXBwZXIgPSBvbmNlKCk7XG4gICAgICAgICAgICAgICAgZXhlY3V0b3IgJiZcbiAgICAgICAgICAgICAgICAgICAgZXhlY3V0b3Iob25jZVdyYXBwZXIobWFrZVJlc29sdmVyKHByb21pc2UsIFJFU09MVkVEKSksIG9uY2VXcmFwcGVyKG1ha2VSZXNvbHZlcihwcm9taXNlLCBSRUpFQ1RFRCkpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIHJlc29sdmVQcm9taXNlKHByb21pc2UsIGZhbHNlLCBlcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZ2V0IFtTeW1ib2wudG9TdHJpbmdUYWddKCkge1xuICAgICAgICAgICAgcmV0dXJuICdQcm9taXNlJztcbiAgICAgICAgfVxuICAgICAgICBnZXQgW1N5bWJvbC5zcGVjaWVzXSgpIHtcbiAgICAgICAgICAgIHJldHVybiBab25lQXdhcmVQcm9taXNlO1xuICAgICAgICB9XG4gICAgICAgIHRoZW4ob25GdWxmaWxsZWQsIG9uUmVqZWN0ZWQpIHtcbiAgICAgICAgICAgIC8vIFdlIG11c3QgcmVhZCBgU3ltYm9sLnNwZWNpZXNgIHNhZmVseSBiZWNhdXNlIGB0aGlzYCBtYXkgYmUgYW55dGhpbmcuIEZvciBpbnN0YW5jZSwgYHRoaXNgXG4gICAgICAgICAgICAvLyBtYXkgYmUgYW4gb2JqZWN0IHdpdGhvdXQgYSBwcm90b3R5cGUgKGNyZWF0ZWQgdGhyb3VnaCBgT2JqZWN0LmNyZWF0ZShudWxsKWApOyB0aHVzXG4gICAgICAgICAgICAvLyBgdGhpcy5jb25zdHJ1Y3RvcmAgd2lsbCBiZSB1bmRlZmluZWQuIE9uZSBvZiB0aGUgdXNlIGNhc2VzIGlzIFN5c3RlbUpTIGNyZWF0aW5nXG4gICAgICAgICAgICAvLyBwcm90b3R5cGUtbGVzcyBvYmplY3RzIChtb2R1bGVzKSB2aWEgYE9iamVjdC5jcmVhdGUobnVsbClgLiBUaGUgU3lzdGVtSlMgY3JlYXRlcyBhbiBlbXB0eVxuICAgICAgICAgICAgLy8gb2JqZWN0IGFuZCBjb3BpZXMgcHJvbWlzZSBwcm9wZXJ0aWVzIGludG8gdGhhdCBvYmplY3QgKHdpdGhpbiB0aGUgYGdldE9yQ3JlYXRlTG9hZGBcbiAgICAgICAgICAgIC8vIGZ1bmN0aW9uKS4gVGhlIHpvbmUuanMgdGhlbiBjaGVja3MgaWYgdGhlIHJlc29sdmVkIHZhbHVlIGhhcyB0aGUgYHRoZW5gIG1ldGhvZCBhbmQgaW52b2tlc1xuICAgICAgICAgICAgLy8gaXQgd2l0aCB0aGUgYHZhbHVlYCBjb250ZXh0LiBPdGhlcndpc2UsIHRoaXMgd2lsbCB0aHJvdyBhbiBlcnJvcjogYFR5cGVFcnJvcjogQ2Fubm90IHJlYWRcbiAgICAgICAgICAgIC8vIHByb3BlcnRpZXMgb2YgdW5kZWZpbmVkIChyZWFkaW5nICdTeW1ib2woU3ltYm9sLnNwZWNpZXMpJylgLlxuICAgICAgICAgICAgbGV0IEMgPSB0aGlzLmNvbnN0cnVjdG9yPy5bU3ltYm9sLnNwZWNpZXNdO1xuICAgICAgICAgICAgaWYgKCFDIHx8IHR5cGVvZiBDICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgQyA9IHRoaXMuY29uc3RydWN0b3IgfHwgWm9uZUF3YXJlUHJvbWlzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGNoYWluUHJvbWlzZSA9IG5ldyBDKG5vb3ApO1xuICAgICAgICAgICAgY29uc3Qgem9uZSA9IFpvbmUuY3VycmVudDtcbiAgICAgICAgICAgIGlmICh0aGlzW3N5bWJvbFN0YXRlXSA9PSBVTlJFU09MVkVEKSB7XG4gICAgICAgICAgICAgICAgdGhpc1tzeW1ib2xWYWx1ZV0ucHVzaCh6b25lLCBjaGFpblByb21pc2UsIG9uRnVsZmlsbGVkLCBvblJlamVjdGVkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHNjaGVkdWxlUmVzb2x2ZU9yUmVqZWN0KHRoaXMsIHpvbmUsIGNoYWluUHJvbWlzZSwgb25GdWxmaWxsZWQsIG9uUmVqZWN0ZWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGNoYWluUHJvbWlzZTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaChvblJlamVjdGVkKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy50aGVuKG51bGwsIG9uUmVqZWN0ZWQpO1xuICAgICAgICB9XG4gICAgICAgIGZpbmFsbHkob25GaW5hbGx5KSB7XG4gICAgICAgICAgICAvLyBTZWUgY29tbWVudCBvbiB0aGUgY2FsbCB0byBgdGhlbmAgYWJvdXQgd2h5IHRoZWUgYFN5bWJvbC5zcGVjaWVzYCBpcyBzYWZlbHkgYWNjZXNzZWQuXG4gICAgICAgICAgICBsZXQgQyA9IHRoaXMuY29uc3RydWN0b3I/LltTeW1ib2wuc3BlY2llc107XG4gICAgICAgICAgICBpZiAoIUMgfHwgdHlwZW9mIEMgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICBDID0gWm9uZUF3YXJlUHJvbWlzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGNoYWluUHJvbWlzZSA9IG5ldyBDKG5vb3ApO1xuICAgICAgICAgICAgY2hhaW5Qcm9taXNlW3N5bWJvbEZpbmFsbHldID0gc3ltYm9sRmluYWxseTtcbiAgICAgICAgICAgIGNvbnN0IHpvbmUgPSBab25lLmN1cnJlbnQ7XG4gICAgICAgICAgICBpZiAodGhpc1tzeW1ib2xTdGF0ZV0gPT0gVU5SRVNPTFZFRCkge1xuICAgICAgICAgICAgICAgIHRoaXNbc3ltYm9sVmFsdWVdLnB1c2goem9uZSwgY2hhaW5Qcm9taXNlLCBvbkZpbmFsbHksIG9uRmluYWxseSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzY2hlZHVsZVJlc29sdmVPclJlamVjdCh0aGlzLCB6b25lLCBjaGFpblByb21pc2UsIG9uRmluYWxseSwgb25GaW5hbGx5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBjaGFpblByb21pc2U7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gUHJvdGVjdCBhZ2FpbnN0IGFnZ3Jlc3NpdmUgb3B0aW1pemVycyBkcm9wcGluZyBzZWVtaW5nbHkgdW51c2VkIHByb3BlcnRpZXMuXG4gICAgLy8gRS5nLiBDbG9zdXJlIENvbXBpbGVyIGluIGFkdmFuY2VkIG1vZGUuXG4gICAgWm9uZUF3YXJlUHJvbWlzZVsncmVzb2x2ZSddID0gWm9uZUF3YXJlUHJvbWlzZS5yZXNvbHZlO1xuICAgIFpvbmVBd2FyZVByb21pc2VbJ3JlamVjdCddID0gWm9uZUF3YXJlUHJvbWlzZS5yZWplY3Q7XG4gICAgWm9uZUF3YXJlUHJvbWlzZVsncmFjZSddID0gWm9uZUF3YXJlUHJvbWlzZS5yYWNlO1xuICAgIFpvbmVBd2FyZVByb21pc2VbJ2FsbCddID0gWm9uZUF3YXJlUHJvbWlzZS5hbGw7XG4gICAgY29uc3QgTmF0aXZlUHJvbWlzZSA9IGdsb2JhbFtzeW1ib2xQcm9taXNlXSA9IGdsb2JhbFsnUHJvbWlzZSddO1xuICAgIGdsb2JhbFsnUHJvbWlzZSddID0gWm9uZUF3YXJlUHJvbWlzZTtcbiAgICBjb25zdCBzeW1ib2xUaGVuUGF0Y2hlZCA9IF9fc3ltYm9sX18oJ3RoZW5QYXRjaGVkJyk7XG4gICAgZnVuY3Rpb24gcGF0Y2hUaGVuKEN0b3IpIHtcbiAgICAgICAgY29uc3QgcHJvdG8gPSBDdG9yLnByb3RvdHlwZTtcbiAgICAgICAgY29uc3QgcHJvcCA9IE9iamVjdEdldE93blByb3BlcnR5RGVzY3JpcHRvcihwcm90bywgJ3RoZW4nKTtcbiAgICAgICAgaWYgKHByb3AgJiYgKHByb3Aud3JpdGFibGUgPT09IGZhbHNlIHx8ICFwcm9wLmNvbmZpZ3VyYWJsZSkpIHtcbiAgICAgICAgICAgIC8vIGNoZWNrIEN0b3IucHJvdG90eXBlLnRoZW4gcHJvcGVydHlEZXNjcmlwdG9yIGlzIHdyaXRhYmxlIG9yIG5vdFxuICAgICAgICAgICAgLy8gaW4gbWV0ZW9yIGVudiwgd3JpdGFibGUgaXMgZmFsc2UsIHdlIHNob3VsZCBpZ25vcmUgc3VjaCBjYXNlXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgb3JpZ2luYWxUaGVuID0gcHJvdG8udGhlbjtcbiAgICAgICAgLy8gS2VlcCBhIHJlZmVyZW5jZSB0byB0aGUgb3JpZ2luYWwgbWV0aG9kLlxuICAgICAgICBwcm90b1tzeW1ib2xUaGVuXSA9IG9yaWdpbmFsVGhlbjtcbiAgICAgICAgQ3Rvci5wcm90b3R5cGUudGhlbiA9IGZ1bmN0aW9uIChvblJlc29sdmUsIG9uUmVqZWN0KSB7XG4gICAgICAgICAgICBjb25zdCB3cmFwcGVkID0gbmV3IFpvbmVBd2FyZVByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgICAgICAgIG9yaWdpbmFsVGhlbi5jYWxsKHRoaXMsIHJlc29sdmUsIHJlamVjdCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiB3cmFwcGVkLnRoZW4ob25SZXNvbHZlLCBvblJlamVjdCk7XG4gICAgICAgIH07XG4gICAgICAgIEN0b3Jbc3ltYm9sVGhlblBhdGNoZWRdID0gdHJ1ZTtcbiAgICB9XG4gICAgYXBpLnBhdGNoVGhlbiA9IHBhdGNoVGhlbjtcbiAgICBmdW5jdGlvbiB6b25laWZ5KGZuKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoc2VsZiwgYXJncykge1xuICAgICAgICAgICAgbGV0IHJlc3VsdFByb21pc2UgPSBmbi5hcHBseShzZWxmLCBhcmdzKTtcbiAgICAgICAgICAgIGlmIChyZXN1bHRQcm9taXNlIGluc3RhbmNlb2YgWm9uZUF3YXJlUHJvbWlzZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHRQcm9taXNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IGN0b3IgPSByZXN1bHRQcm9taXNlLmNvbnN0cnVjdG9yO1xuICAgICAgICAgICAgaWYgKCFjdG9yW3N5bWJvbFRoZW5QYXRjaGVkXSkge1xuICAgICAgICAgICAgICAgIHBhdGNoVGhlbihjdG9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXN1bHRQcm9taXNlO1xuICAgICAgICB9O1xuICAgIH1cbiAgICBpZiAoTmF0aXZlUHJvbWlzZSkge1xuICAgICAgICBwYXRjaFRoZW4oTmF0aXZlUHJvbWlzZSk7XG4gICAgICAgIHBhdGNoTWV0aG9kKGdsb2JhbCwgJ2ZldGNoJywgZGVsZWdhdGUgPT4gem9uZWlmeShkZWxlZ2F0ZSkpO1xuICAgIH1cbiAgICAvLyBUaGlzIGlzIG5vdCBwYXJ0IG9mIHB1YmxpYyBBUEksIGJ1dCBpdCBpcyB1c2VmdWwgZm9yIHRlc3RzLCBzbyB3ZSBleHBvc2UgaXQuXG4gICAgUHJvbWlzZVtab25lLl9fc3ltYm9sX18oJ3VuY2F1Z2h0UHJvbWlzZUVycm9ycycpXSA9IF91bmNhdWdodFByb21pc2VFcnJvcnM7XG4gICAgcmV0dXJuIFpvbmVBd2FyZVByb21pc2U7XG59KTtcblxuLy8gb3ZlcnJpZGUgRnVuY3Rpb24ucHJvdG90eXBlLnRvU3RyaW5nIHRvIG1ha2Ugem9uZS5qcyBwYXRjaGVkIGZ1bmN0aW9uXG4vLyBsb29rIGxpa2UgbmF0aXZlIGZ1bmN0aW9uXG5ab25lLl9fbG9hZF9wYXRjaCgndG9TdHJpbmcnLCAoZ2xvYmFsKSA9PiB7XG4gICAgLy8gcGF0Y2ggRnVuYy5wcm90b3R5cGUudG9TdHJpbmcgdG8gbGV0IHRoZW0gbG9vayBsaWtlIG5hdGl2ZVxuICAgIGNvbnN0IG9yaWdpbmFsRnVuY3Rpb25Ub1N0cmluZyA9IEZ1bmN0aW9uLnByb3RvdHlwZS50b1N0cmluZztcbiAgICBjb25zdCBPUklHSU5BTF9ERUxFR0FURV9TWU1CT0wgPSB6b25lU3ltYm9sKCdPcmlnaW5hbERlbGVnYXRlJyk7XG4gICAgY29uc3QgUFJPTUlTRV9TWU1CT0wgPSB6b25lU3ltYm9sKCdQcm9taXNlJyk7XG4gICAgY29uc3QgRVJST1JfU1lNQk9MID0gem9uZVN5bWJvbCgnRXJyb3InKTtcbiAgICBjb25zdCBuZXdGdW5jdGlvblRvU3RyaW5nID0gZnVuY3Rpb24gdG9TdHJpbmcoKSB7XG4gICAgICAgIGlmICh0eXBlb2YgdGhpcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgY29uc3Qgb3JpZ2luYWxEZWxlZ2F0ZSA9IHRoaXNbT1JJR0lOQUxfREVMRUdBVEVfU1lNQk9MXTtcbiAgICAgICAgICAgIGlmIChvcmlnaW5hbERlbGVnYXRlKSB7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBvcmlnaW5hbERlbGVnYXRlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBvcmlnaW5hbEZ1bmN0aW9uVG9TdHJpbmcuY2FsbChvcmlnaW5hbERlbGVnYXRlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwob3JpZ2luYWxEZWxlZ2F0ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMgPT09IFByb21pc2UpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBuYXRpdmVQcm9taXNlID0gZ2xvYmFsW1BST01JU0VfU1lNQk9MXTtcbiAgICAgICAgICAgICAgICBpZiAobmF0aXZlUHJvbWlzZSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gb3JpZ2luYWxGdW5jdGlvblRvU3RyaW5nLmNhbGwobmF0aXZlUHJvbWlzZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMgPT09IEVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbmF0aXZlRXJyb3IgPSBnbG9iYWxbRVJST1JfU1lNQk9MXTtcbiAgICAgICAgICAgICAgICBpZiAobmF0aXZlRXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9yaWdpbmFsRnVuY3Rpb25Ub1N0cmluZy5jYWxsKG5hdGl2ZUVycm9yKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG9yaWdpbmFsRnVuY3Rpb25Ub1N0cmluZy5jYWxsKHRoaXMpO1xuICAgIH07XG4gICAgbmV3RnVuY3Rpb25Ub1N0cmluZ1tPUklHSU5BTF9ERUxFR0FURV9TWU1CT0xdID0gb3JpZ2luYWxGdW5jdGlvblRvU3RyaW5nO1xuICAgIEZ1bmN0aW9uLnByb3RvdHlwZS50b1N0cmluZyA9IG5ld0Z1bmN0aW9uVG9TdHJpbmc7XG4gICAgLy8gcGF0Y2ggT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZyB0byBsZXQgdGhlbSBsb29rIGxpa2UgbmF0aXZlXG4gICAgY29uc3Qgb3JpZ2luYWxPYmplY3RUb1N0cmluZyA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmc7XG4gICAgY29uc3QgUFJPTUlTRV9PQkpFQ1RfVE9fU1RSSU5HID0gJ1tvYmplY3QgUHJvbWlzZV0nO1xuICAgIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmICh0eXBlb2YgUHJvbWlzZSA9PT0gJ2Z1bmN0aW9uJyAmJiB0aGlzIGluc3RhbmNlb2YgUHJvbWlzZSkge1xuICAgICAgICAgICAgcmV0dXJuIFBST01JU0VfT0JKRUNUX1RPX1NUUklORztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb3JpZ2luYWxPYmplY3RUb1N0cmluZy5jYWxsKHRoaXMpO1xuICAgIH07XG59KTtcblxuLyoqXG4gKiBAZmlsZW92ZXJ2aWV3XG4gKiBAc3VwcHJlc3Mge21pc3NpbmdSZXF1aXJlfVxuICovXG5sZXQgcGFzc2l2ZVN1cHBvcnRlZCA9IGZhbHNlO1xuaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3Qgb3B0aW9ucyA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh7fSwgJ3Bhc3NpdmUnLCB7XG4gICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBwYXNzaXZlU3VwcG9ydGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIC8vIE5vdGU6IFdlIHBhc3MgdGhlIGBvcHRpb25zYCBvYmplY3QgYXMgdGhlIGV2ZW50IGhhbmRsZXIgdG9vLiBUaGlzIGlzIG5vdCBjb21wYXRpYmxlIHdpdGggdGhlXG4gICAgICAgIC8vIHNpZ25hdHVyZSBvZiBgYWRkRXZlbnRMaXN0ZW5lcmAgb3IgYHJlbW92ZUV2ZW50TGlzdGVuZXJgIGJ1dCBlbmFibGVzIHVzIHRvIHJlbW92ZSB0aGUgaGFuZGxlclxuICAgICAgICAvLyB3aXRob3V0IGFuIGFjdHVhbCBoYW5kbGVyLlxuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigndGVzdCcsIG9wdGlvbnMsIG9wdGlvbnMpO1xuICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigndGVzdCcsIG9wdGlvbnMsIG9wdGlvbnMpO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHBhc3NpdmVTdXBwb3J0ZWQgPSBmYWxzZTtcbiAgICB9XG59XG4vLyBhbiBpZGVudGlmaWVyIHRvIHRlbGwgWm9uZVRhc2sgZG8gbm90IGNyZWF0ZSBhIG5ldyBpbnZva2UgY2xvc3VyZVxuY29uc3QgT1BUSU1JWkVEX1pPTkVfRVZFTlRfVEFTS19EQVRBID0ge1xuICAgIHVzZUc6IHRydWVcbn07XG5jb25zdCB6b25lU3ltYm9sRXZlbnROYW1lcyA9IHt9O1xuY29uc3QgZ2xvYmFsU291cmNlcyA9IHt9O1xuY29uc3QgRVZFTlRfTkFNRV9TWU1CT0xfUkVHWCA9IG5ldyBSZWdFeHAoJ14nICsgWk9ORV9TWU1CT0xfUFJFRklYICsgJyhcXFxcdyspKHRydWV8ZmFsc2UpJCcpO1xuY29uc3QgSU1NRURJQVRFX1BST1BBR0FUSU9OX1NZTUJPTCA9IHpvbmVTeW1ib2woJ3Byb3BhZ2F0aW9uU3RvcHBlZCcpO1xuZnVuY3Rpb24gcHJlcGFyZUV2ZW50TmFtZXMoZXZlbnROYW1lLCBldmVudE5hbWVUb1N0cmluZykge1xuICAgIGNvbnN0IGZhbHNlRXZlbnROYW1lID0gKGV2ZW50TmFtZVRvU3RyaW5nID8gZXZlbnROYW1lVG9TdHJpbmcoZXZlbnROYW1lKSA6IGV2ZW50TmFtZSkgKyBGQUxTRV9TVFI7XG4gICAgY29uc3QgdHJ1ZUV2ZW50TmFtZSA9IChldmVudE5hbWVUb1N0cmluZyA/IGV2ZW50TmFtZVRvU3RyaW5nKGV2ZW50TmFtZSkgOiBldmVudE5hbWUpICsgVFJVRV9TVFI7XG4gICAgY29uc3Qgc3ltYm9sID0gWk9ORV9TWU1CT0xfUFJFRklYICsgZmFsc2VFdmVudE5hbWU7XG4gICAgY29uc3Qgc3ltYm9sQ2FwdHVyZSA9IFpPTkVfU1lNQk9MX1BSRUZJWCArIHRydWVFdmVudE5hbWU7XG4gICAgem9uZVN5bWJvbEV2ZW50TmFtZXNbZXZlbnROYW1lXSA9IHt9O1xuICAgIHpvbmVTeW1ib2xFdmVudE5hbWVzW2V2ZW50TmFtZV1bRkFMU0VfU1RSXSA9IHN5bWJvbDtcbiAgICB6b25lU3ltYm9sRXZlbnROYW1lc1tldmVudE5hbWVdW1RSVUVfU1RSXSA9IHN5bWJvbENhcHR1cmU7XG59XG5mdW5jdGlvbiBwYXRjaEV2ZW50VGFyZ2V0KF9nbG9iYWwsIGFwaSwgYXBpcywgcGF0Y2hPcHRpb25zKSB7XG4gICAgY29uc3QgQUREX0VWRU5UX0xJU1RFTkVSID0gKHBhdGNoT3B0aW9ucyAmJiBwYXRjaE9wdGlvbnMuYWRkKSB8fCBBRERfRVZFTlRfTElTVEVORVJfU1RSO1xuICAgIGNvbnN0IFJFTU9WRV9FVkVOVF9MSVNURU5FUiA9IChwYXRjaE9wdGlvbnMgJiYgcGF0Y2hPcHRpb25zLnJtKSB8fCBSRU1PVkVfRVZFTlRfTElTVEVORVJfU1RSO1xuICAgIGNvbnN0IExJU1RFTkVSU19FVkVOVF9MSVNURU5FUiA9IChwYXRjaE9wdGlvbnMgJiYgcGF0Y2hPcHRpb25zLmxpc3RlbmVycykgfHwgJ2V2ZW50TGlzdGVuZXJzJztcbiAgICBjb25zdCBSRU1PVkVfQUxMX0xJU1RFTkVSU19FVkVOVF9MSVNURU5FUiA9IChwYXRjaE9wdGlvbnMgJiYgcGF0Y2hPcHRpb25zLnJtQWxsKSB8fCAncmVtb3ZlQWxsTGlzdGVuZXJzJztcbiAgICBjb25zdCB6b25lU3ltYm9sQWRkRXZlbnRMaXN0ZW5lciA9IHpvbmVTeW1ib2woQUREX0VWRU5UX0xJU1RFTkVSKTtcbiAgICBjb25zdCBBRERfRVZFTlRfTElTVEVORVJfU09VUkNFID0gJy4nICsgQUREX0VWRU5UX0xJU1RFTkVSICsgJzonO1xuICAgIGNvbnN0IFBSRVBFTkRfRVZFTlRfTElTVEVORVIgPSAncHJlcGVuZExpc3RlbmVyJztcbiAgICBjb25zdCBQUkVQRU5EX0VWRU5UX0xJU1RFTkVSX1NPVVJDRSA9ICcuJyArIFBSRVBFTkRfRVZFTlRfTElTVEVORVIgKyAnOic7XG4gICAgY29uc3QgaW52b2tlVGFzayA9IGZ1bmN0aW9uICh0YXNrLCB0YXJnZXQsIGV2ZW50KSB7XG4gICAgICAgIC8vIGZvciBiZXR0ZXIgcGVyZm9ybWFuY2UsIGNoZWNrIGlzUmVtb3ZlZCB3aGljaCBpcyBzZXRcbiAgICAgICAgLy8gYnkgcmVtb3ZlRXZlbnRMaXN0ZW5lclxuICAgICAgICBpZiAodGFzay5pc1JlbW92ZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBkZWxlZ2F0ZSA9IHRhc2suY2FsbGJhY2s7XG4gICAgICAgIGlmICh0eXBlb2YgZGVsZWdhdGUgPT09ICdvYmplY3QnICYmIGRlbGVnYXRlLmhhbmRsZUV2ZW50KSB7XG4gICAgICAgICAgICAvLyBjcmVhdGUgdGhlIGJpbmQgdmVyc2lvbiBvZiBoYW5kbGVFdmVudCB3aGVuIGludm9rZVxuICAgICAgICAgICAgdGFzay5jYWxsYmFjayA9IChldmVudCkgPT4gZGVsZWdhdGUuaGFuZGxlRXZlbnQoZXZlbnQpO1xuICAgICAgICAgICAgdGFzay5vcmlnaW5hbERlbGVnYXRlID0gZGVsZWdhdGU7XG4gICAgICAgIH1cbiAgICAgICAgLy8gaW52b2tlIHN0YXRpYyB0YXNrLmludm9rZVxuICAgICAgICAvLyBuZWVkIHRvIHRyeS9jYXRjaCBlcnJvciBoZXJlLCBvdGhlcndpc2UsIHRoZSBlcnJvciBpbiBvbmUgZXZlbnQgbGlzdGVuZXJcbiAgICAgICAgLy8gd2lsbCBicmVhayB0aGUgZXhlY3V0aW9ucyBvZiB0aGUgb3RoZXIgZXZlbnQgbGlzdGVuZXJzLiBBbHNvIGVycm9yIHdpbGxcbiAgICAgICAgLy8gbm90IHJlbW92ZSB0aGUgZXZlbnQgbGlzdGVuZXIgd2hlbiBgb25jZWAgb3B0aW9ucyBpcyB0cnVlLlxuICAgICAgICBsZXQgZXJyb3I7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB0YXNrLmludm9rZSh0YXNrLCB0YXJnZXQsIFtldmVudF0pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGVycm9yID0gZXJyO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG9wdGlvbnMgPSB0YXNrLm9wdGlvbnM7XG4gICAgICAgIGlmIChvcHRpb25zICYmIHR5cGVvZiBvcHRpb25zID09PSAnb2JqZWN0JyAmJiBvcHRpb25zLm9uY2UpIHtcbiAgICAgICAgICAgIC8vIGlmIG9wdGlvbnMub25jZSBpcyB0cnVlLCBhZnRlciBpbnZva2Ugb25jZSByZW1vdmUgbGlzdGVuZXIgaGVyZVxuICAgICAgICAgICAgLy8gb25seSBicm93c2VyIG5lZWQgdG8gZG8gdGhpcywgbm9kZWpzIGV2ZW50RW1pdHRlciB3aWxsIGNhbCByZW1vdmVMaXN0ZW5lclxuICAgICAgICAgICAgLy8gaW5zaWRlIEV2ZW50RW1pdHRlci5vbmNlXG4gICAgICAgICAgICBjb25zdCBkZWxlZ2F0ZSA9IHRhc2sub3JpZ2luYWxEZWxlZ2F0ZSA/IHRhc2sub3JpZ2luYWxEZWxlZ2F0ZSA6IHRhc2suY2FsbGJhY2s7XG4gICAgICAgICAgICB0YXJnZXRbUkVNT1ZFX0VWRU5UX0xJU1RFTkVSXS5jYWxsKHRhcmdldCwgZXZlbnQudHlwZSwgZGVsZWdhdGUsIG9wdGlvbnMpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBlcnJvcjtcbiAgICB9O1xuICAgIGZ1bmN0aW9uIGdsb2JhbENhbGxiYWNrKGNvbnRleHQsIGV2ZW50LCBpc0NhcHR1cmUpIHtcbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2FuZ3VsYXIvem9uZS5qcy9pc3N1ZXMvOTExLCBpbiBJRSwgc29tZXRpbWVzXG4gICAgICAgIC8vIGV2ZW50IHdpbGwgYmUgdW5kZWZpbmVkLCBzbyB3ZSBuZWVkIHRvIHVzZSB3aW5kb3cuZXZlbnRcbiAgICAgICAgZXZlbnQgPSBldmVudCB8fCBfZ2xvYmFsLmV2ZW50O1xuICAgICAgICBpZiAoIWV2ZW50KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gZXZlbnQudGFyZ2V0IGlzIG5lZWRlZCBmb3IgU2Ftc3VuZyBUViBhbmQgU291cmNlQnVmZmVyXG4gICAgICAgIC8vIHx8IGdsb2JhbCBpcyBuZWVkZWQgaHR0cHM6Ly9naXRodWIuY29tL2FuZ3VsYXIvem9uZS5qcy9pc3N1ZXMvMTkwXG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGNvbnRleHQgfHwgZXZlbnQudGFyZ2V0IHx8IF9nbG9iYWw7XG4gICAgICAgIGNvbnN0IHRhc2tzID0gdGFyZ2V0W3pvbmVTeW1ib2xFdmVudE5hbWVzW2V2ZW50LnR5cGVdW2lzQ2FwdHVyZSA/IFRSVUVfU1RSIDogRkFMU0VfU1RSXV07XG4gICAgICAgIGlmICh0YXNrcykge1xuICAgICAgICAgICAgY29uc3QgZXJyb3JzID0gW107XG4gICAgICAgICAgICAvLyBpbnZva2UgYWxsIHRhc2tzIHdoaWNoIGF0dGFjaGVkIHRvIGN1cnJlbnQgdGFyZ2V0IHdpdGggZ2l2ZW4gZXZlbnQudHlwZSBhbmQgY2FwdHVyZSA9IGZhbHNlXG4gICAgICAgICAgICAvLyBmb3IgcGVyZm9ybWFuY2UgY29uY2VybiwgaWYgdGFzay5sZW5ndGggPT09IDEsIGp1c3QgaW52b2tlXG4gICAgICAgICAgICBpZiAodGFza3MubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyID0gaW52b2tlVGFzayh0YXNrc1swXSwgdGFyZ2V0LCBldmVudCk7XG4gICAgICAgICAgICAgICAgZXJyICYmIGVycm9ycy5wdXNoKGVycik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci96b25lLmpzL2lzc3Vlcy84MzZcbiAgICAgICAgICAgICAgICAvLyBjb3B5IHRoZSB0YXNrcyBhcnJheSBiZWZvcmUgaW52b2tlLCB0byBhdm9pZFxuICAgICAgICAgICAgICAgIC8vIHRoZSBjYWxsYmFjayB3aWxsIHJlbW92ZSBpdHNlbGYgb3Igb3RoZXIgbGlzdGVuZXJcbiAgICAgICAgICAgICAgICBjb25zdCBjb3B5VGFza3MgPSB0YXNrcy5zbGljZSgpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY29weVRhc2tzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChldmVudCAmJiBldmVudFtJTU1FRElBVEVfUFJPUEFHQVRJT05fU1lNQk9MXSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXJyID0gaW52b2tlVGFzayhjb3B5VGFza3NbaV0sIHRhcmdldCwgZXZlbnQpO1xuICAgICAgICAgICAgICAgICAgICBlcnIgJiYgZXJyb3JzLnB1c2goZXJyKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBTaW5jZSB0aGVyZSBpcyBvbmx5IG9uZSBlcnJvciwgd2UgZG9uJ3QgbmVlZCB0byBzY2hlZHVsZSBtaWNyb1Rhc2tcbiAgICAgICAgICAgIC8vIHRvIHRocm93IHRoZSBlcnJvci5cbiAgICAgICAgICAgIGlmIChlcnJvcnMubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyb3JzWzBdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBlcnJvcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXJyID0gZXJyb3JzW2ldO1xuICAgICAgICAgICAgICAgICAgICBhcGkubmF0aXZlU2NoZWR1bGVNaWNyb1Rhc2soKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gZ2xvYmFsIHNoYXJlZCB6b25lQXdhcmVDYWxsYmFjayB0byBoYW5kbGUgYWxsIGV2ZW50IGNhbGxiYWNrIHdpdGggY2FwdHVyZSA9IGZhbHNlXG4gICAgY29uc3QgZ2xvYmFsWm9uZUF3YXJlQ2FsbGJhY2sgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgcmV0dXJuIGdsb2JhbENhbGxiYWNrKHRoaXMsIGV2ZW50LCBmYWxzZSk7XG4gICAgfTtcbiAgICAvLyBnbG9iYWwgc2hhcmVkIHpvbmVBd2FyZUNhbGxiYWNrIHRvIGhhbmRsZSBhbGwgZXZlbnQgY2FsbGJhY2sgd2l0aCBjYXB0dXJlID0gdHJ1ZVxuICAgIGNvbnN0IGdsb2JhbFpvbmVBd2FyZUNhcHR1cmVDYWxsYmFjayA9IGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICByZXR1cm4gZ2xvYmFsQ2FsbGJhY2sodGhpcywgZXZlbnQsIHRydWUpO1xuICAgIH07XG4gICAgZnVuY3Rpb24gcGF0Y2hFdmVudFRhcmdldE1ldGhvZHMob2JqLCBwYXRjaE9wdGlvbnMpIHtcbiAgICAgICAgaWYgKCFvYmopIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgdXNlR2xvYmFsQ2FsbGJhY2sgPSB0cnVlO1xuICAgICAgICBpZiAocGF0Y2hPcHRpb25zICYmIHBhdGNoT3B0aW9ucy51c2VHICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHVzZUdsb2JhbENhbGxiYWNrID0gcGF0Y2hPcHRpb25zLnVzZUc7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdmFsaWRhdGVIYW5kbGVyID0gcGF0Y2hPcHRpb25zICYmIHBhdGNoT3B0aW9ucy52aDtcbiAgICAgICAgbGV0IGNoZWNrRHVwbGljYXRlID0gdHJ1ZTtcbiAgICAgICAgaWYgKHBhdGNoT3B0aW9ucyAmJiBwYXRjaE9wdGlvbnMuY2hrRHVwICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGNoZWNrRHVwbGljYXRlID0gcGF0Y2hPcHRpb25zLmNoa0R1cDtcbiAgICAgICAgfVxuICAgICAgICBsZXQgcmV0dXJuVGFyZ2V0ID0gZmFsc2U7XG4gICAgICAgIGlmIChwYXRjaE9wdGlvbnMgJiYgcGF0Y2hPcHRpb25zLnJ0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHJldHVyblRhcmdldCA9IHBhdGNoT3B0aW9ucy5ydDtcbiAgICAgICAgfVxuICAgICAgICBsZXQgcHJvdG8gPSBvYmo7XG4gICAgICAgIHdoaWxlIChwcm90byAmJiAhcHJvdG8uaGFzT3duUHJvcGVydHkoQUREX0VWRU5UX0xJU1RFTkVSKSkge1xuICAgICAgICAgICAgcHJvdG8gPSBPYmplY3RHZXRQcm90b3R5cGVPZihwcm90byk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFwcm90byAmJiBvYmpbQUREX0VWRU5UX0xJU1RFTkVSXSkge1xuICAgICAgICAgICAgLy8gc29tZWhvdyB3ZSBkaWQgbm90IGZpbmQgaXQsIGJ1dCB3ZSBjYW4gc2VlIGl0LiBUaGlzIGhhcHBlbnMgb24gSUUgZm9yIFdpbmRvdyBwcm9wZXJ0aWVzLlxuICAgICAgICAgICAgcHJvdG8gPSBvYmo7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFwcm90bykge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwcm90b1t6b25lU3ltYm9sQWRkRXZlbnRMaXN0ZW5lcl0pIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBldmVudE5hbWVUb1N0cmluZyA9IHBhdGNoT3B0aW9ucyAmJiBwYXRjaE9wdGlvbnMuZXZlbnROYW1lVG9TdHJpbmc7XG4gICAgICAgIC8vIGEgc2hhcmVkIGdsb2JhbCB0YXNrRGF0YSB0byBwYXNzIGRhdGEgZm9yIHNjaGVkdWxlRXZlbnRUYXNrXG4gICAgICAgIC8vIHNvIHdlIGRvIG5vdCBuZWVkIHRvIGNyZWF0ZSBhIG5ldyBvYmplY3QganVzdCBmb3IgcGFzcyBzb21lIGRhdGFcbiAgICAgICAgY29uc3QgdGFza0RhdGEgPSB7fTtcbiAgICAgICAgY29uc3QgbmF0aXZlQWRkRXZlbnRMaXN0ZW5lciA9IHByb3RvW3pvbmVTeW1ib2xBZGRFdmVudExpc3RlbmVyXSA9IHByb3RvW0FERF9FVkVOVF9MSVNURU5FUl07XG4gICAgICAgIGNvbnN0IG5hdGl2ZVJlbW92ZUV2ZW50TGlzdGVuZXIgPSBwcm90b1t6b25lU3ltYm9sKFJFTU9WRV9FVkVOVF9MSVNURU5FUildID1cbiAgICAgICAgICAgIHByb3RvW1JFTU9WRV9FVkVOVF9MSVNURU5FUl07XG4gICAgICAgIGNvbnN0IG5hdGl2ZUxpc3RlbmVycyA9IHByb3RvW3pvbmVTeW1ib2woTElTVEVORVJTX0VWRU5UX0xJU1RFTkVSKV0gPVxuICAgICAgICAgICAgcHJvdG9bTElTVEVORVJTX0VWRU5UX0xJU1RFTkVSXTtcbiAgICAgICAgY29uc3QgbmF0aXZlUmVtb3ZlQWxsTGlzdGVuZXJzID0gcHJvdG9bem9uZVN5bWJvbChSRU1PVkVfQUxMX0xJU1RFTkVSU19FVkVOVF9MSVNURU5FUildID1cbiAgICAgICAgICAgIHByb3RvW1JFTU9WRV9BTExfTElTVEVORVJTX0VWRU5UX0xJU1RFTkVSXTtcbiAgICAgICAgbGV0IG5hdGl2ZVByZXBlbmRFdmVudExpc3RlbmVyO1xuICAgICAgICBpZiAocGF0Y2hPcHRpb25zICYmIHBhdGNoT3B0aW9ucy5wcmVwZW5kKSB7XG4gICAgICAgICAgICBuYXRpdmVQcmVwZW5kRXZlbnRMaXN0ZW5lciA9IHByb3RvW3pvbmVTeW1ib2wocGF0Y2hPcHRpb25zLnByZXBlbmQpXSA9XG4gICAgICAgICAgICAgICAgcHJvdG9bcGF0Y2hPcHRpb25zLnByZXBlbmRdO1xuICAgICAgICB9XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBUaGlzIHV0aWwgZnVuY3Rpb24gd2lsbCBidWlsZCBhbiBvcHRpb24gb2JqZWN0IHdpdGggcGFzc2l2ZSBvcHRpb25cbiAgICAgICAgICogdG8gaGFuZGxlIGFsbCBwb3NzaWJsZSBpbnB1dCBmcm9tIHRoZSB1c2VyLlxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gYnVpbGRFdmVudExpc3RlbmVyT3B0aW9ucyhvcHRpb25zLCBwYXNzaXZlKSB7XG4gICAgICAgICAgICBpZiAoIXBhc3NpdmVTdXBwb3J0ZWQgJiYgdHlwZW9mIG9wdGlvbnMgPT09ICdvYmplY3QnICYmIG9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAvLyBkb2Vzbid0IHN1cHBvcnQgcGFzc2l2ZSBidXQgdXNlciB3YW50IHRvIHBhc3MgYW4gb2JqZWN0IGFzIG9wdGlvbnMuXG4gICAgICAgICAgICAgICAgLy8gdGhpcyB3aWxsIG5vdCB3b3JrIG9uIHNvbWUgb2xkIGJyb3dzZXIsIHNvIHdlIGp1c3QgcGFzcyBhIGJvb2xlYW5cbiAgICAgICAgICAgICAgICAvLyBhcyB1c2VDYXB0dXJlIHBhcmFtZXRlclxuICAgICAgICAgICAgICAgIHJldHVybiAhIW9wdGlvbnMuY2FwdHVyZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghcGFzc2l2ZVN1cHBvcnRlZCB8fCAhcGFzc2l2ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBvcHRpb25zO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHR5cGVvZiBvcHRpb25zID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4geyBjYXB0dXJlOiBvcHRpb25zLCBwYXNzaXZlOiB0cnVlIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4geyBwYXNzaXZlOiB0cnVlIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodHlwZW9mIG9wdGlvbnMgPT09ICdvYmplY3QnICYmIG9wdGlvbnMucGFzc2l2ZSAhPT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5vcHRpb25zLCBwYXNzaXZlOiB0cnVlIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gb3B0aW9ucztcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjdXN0b21TY2hlZHVsZUdsb2JhbCA9IGZ1bmN0aW9uICh0YXNrKSB7XG4gICAgICAgICAgICAvLyBpZiB0aGVyZSBpcyBhbHJlYWR5IGEgdGFzayBmb3IgdGhlIGV2ZW50TmFtZSArIGNhcHR1cmUsXG4gICAgICAgICAgICAvLyBqdXN0IHJldHVybiwgYmVjYXVzZSB3ZSB1c2UgdGhlIHNoYXJlZCBnbG9iYWxab25lQXdhcmVDYWxsYmFjayBoZXJlLlxuICAgICAgICAgICAgaWYgKHRhc2tEYXRhLmlzRXhpc3RpbmcpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gbmF0aXZlQWRkRXZlbnRMaXN0ZW5lci5jYWxsKHRhc2tEYXRhLnRhcmdldCwgdGFza0RhdGEuZXZlbnROYW1lLCB0YXNrRGF0YS5jYXB0dXJlID8gZ2xvYmFsWm9uZUF3YXJlQ2FwdHVyZUNhbGxiYWNrIDogZ2xvYmFsWm9uZUF3YXJlQ2FsbGJhY2ssIHRhc2tEYXRhLm9wdGlvbnMpO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBjdXN0b21DYW5jZWxHbG9iYWwgPSBmdW5jdGlvbiAodGFzaykge1xuICAgICAgICAgICAgLy8gaWYgdGFzayBpcyBub3QgbWFya2VkIGFzIGlzUmVtb3ZlZCwgdGhpcyBjYWxsIGlzIGRpcmVjdGx5XG4gICAgICAgICAgICAvLyBmcm9tIFpvbmUucHJvdG90eXBlLmNhbmNlbFRhc2ssIHdlIHNob3VsZCByZW1vdmUgdGhlIHRhc2tcbiAgICAgICAgICAgIC8vIGZyb20gdGFza3NMaXN0IG9mIHRhcmdldCBmaXJzdFxuICAgICAgICAgICAgaWYgKCF0YXNrLmlzUmVtb3ZlZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHN5bWJvbEV2ZW50TmFtZXMgPSB6b25lU3ltYm9sRXZlbnROYW1lc1t0YXNrLmV2ZW50TmFtZV07XG4gICAgICAgICAgICAgICAgbGV0IHN5bWJvbEV2ZW50TmFtZTtcbiAgICAgICAgICAgICAgICBpZiAoc3ltYm9sRXZlbnROYW1lcykge1xuICAgICAgICAgICAgICAgICAgICBzeW1ib2xFdmVudE5hbWUgPSBzeW1ib2xFdmVudE5hbWVzW3Rhc2suY2FwdHVyZSA/IFRSVUVfU1RSIDogRkFMU0VfU1RSXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdUYXNrcyA9IHN5bWJvbEV2ZW50TmFtZSAmJiB0YXNrLnRhcmdldFtzeW1ib2xFdmVudE5hbWVdO1xuICAgICAgICAgICAgICAgIGlmIChleGlzdGluZ1Rhc2tzKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZXhpc3RpbmdUYXNrcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdUYXNrID0gZXhpc3RpbmdUYXNrc1tpXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChleGlzdGluZ1Rhc2sgPT09IHRhc2spIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1Rhc2tzLnNwbGljZShpLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBzZXQgaXNSZW1vdmVkIHRvIGRhdGEgZm9yIGZhc3RlciBpbnZva2VUYXNrIGNoZWNrXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFzay5pc1JlbW92ZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChleGlzdGluZ1Rhc2tzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBhbGwgdGFza3MgZm9yIHRoZSBldmVudE5hbWUgKyBjYXB0dXJlIGhhdmUgZ29uZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gcmVtb3ZlIGdsb2JhbFpvbmVBd2FyZUNhbGxiYWNrIGFuZCByZW1vdmUgdGhlIHRhc2sgY2FjaGUgZnJvbSB0YXJnZXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFzay5hbGxSZW1vdmVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFzay50YXJnZXRbc3ltYm9sRXZlbnROYW1lXSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gaWYgYWxsIHRhc2tzIGZvciB0aGUgZXZlbnROYW1lICsgY2FwdHVyZSBoYXZlIGdvbmUsXG4gICAgICAgICAgICAvLyB3ZSB3aWxsIHJlYWxseSByZW1vdmUgdGhlIGdsb2JhbCBldmVudCBjYWxsYmFjayxcbiAgICAgICAgICAgIC8vIGlmIG5vdCwgcmV0dXJuXG4gICAgICAgICAgICBpZiAoIXRhc2suYWxsUmVtb3ZlZCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBuYXRpdmVSZW1vdmVFdmVudExpc3RlbmVyLmNhbGwodGFzay50YXJnZXQsIHRhc2suZXZlbnROYW1lLCB0YXNrLmNhcHR1cmUgPyBnbG9iYWxab25lQXdhcmVDYXB0dXJlQ2FsbGJhY2sgOiBnbG9iYWxab25lQXdhcmVDYWxsYmFjaywgdGFzay5vcHRpb25zKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgY3VzdG9tU2NoZWR1bGVOb25HbG9iYWwgPSBmdW5jdGlvbiAodGFzaykge1xuICAgICAgICAgICAgcmV0dXJuIG5hdGl2ZUFkZEV2ZW50TGlzdGVuZXIuY2FsbCh0YXNrRGF0YS50YXJnZXQsIHRhc2tEYXRhLmV2ZW50TmFtZSwgdGFzay5pbnZva2UsIHRhc2tEYXRhLm9wdGlvbnMpO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBjdXN0b21TY2hlZHVsZVByZXBlbmQgPSBmdW5jdGlvbiAodGFzaykge1xuICAgICAgICAgICAgcmV0dXJuIG5hdGl2ZVByZXBlbmRFdmVudExpc3RlbmVyLmNhbGwodGFza0RhdGEudGFyZ2V0LCB0YXNrRGF0YS5ldmVudE5hbWUsIHRhc2suaW52b2tlLCB0YXNrRGF0YS5vcHRpb25zKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgY3VzdG9tQ2FuY2VsTm9uR2xvYmFsID0gZnVuY3Rpb24gKHRhc2spIHtcbiAgICAgICAgICAgIHJldHVybiBuYXRpdmVSZW1vdmVFdmVudExpc3RlbmVyLmNhbGwodGFzay50YXJnZXQsIHRhc2suZXZlbnROYW1lLCB0YXNrLmludm9rZSwgdGFzay5vcHRpb25zKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgY3VzdG9tU2NoZWR1bGUgPSB1c2VHbG9iYWxDYWxsYmFjayA/IGN1c3RvbVNjaGVkdWxlR2xvYmFsIDogY3VzdG9tU2NoZWR1bGVOb25HbG9iYWw7XG4gICAgICAgIGNvbnN0IGN1c3RvbUNhbmNlbCA9IHVzZUdsb2JhbENhbGxiYWNrID8gY3VzdG9tQ2FuY2VsR2xvYmFsIDogY3VzdG9tQ2FuY2VsTm9uR2xvYmFsO1xuICAgICAgICBjb25zdCBjb21wYXJlVGFza0NhbGxiYWNrVnNEZWxlZ2F0ZSA9IGZ1bmN0aW9uICh0YXNrLCBkZWxlZ2F0ZSkge1xuICAgICAgICAgICAgY29uc3QgdHlwZU9mRGVsZWdhdGUgPSB0eXBlb2YgZGVsZWdhdGU7XG4gICAgICAgICAgICByZXR1cm4gKHR5cGVPZkRlbGVnYXRlID09PSAnZnVuY3Rpb24nICYmIHRhc2suY2FsbGJhY2sgPT09IGRlbGVnYXRlKSB8fFxuICAgICAgICAgICAgICAgICh0eXBlT2ZEZWxlZ2F0ZSA9PT0gJ29iamVjdCcgJiYgdGFzay5vcmlnaW5hbERlbGVnYXRlID09PSBkZWxlZ2F0ZSk7XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGNvbXBhcmUgPSAocGF0Y2hPcHRpb25zICYmIHBhdGNoT3B0aW9ucy5kaWZmKSA/IHBhdGNoT3B0aW9ucy5kaWZmIDogY29tcGFyZVRhc2tDYWxsYmFja1ZzRGVsZWdhdGU7XG4gICAgICAgIGNvbnN0IHVucGF0Y2hlZEV2ZW50cyA9IFpvbmVbem9uZVN5bWJvbCgnVU5QQVRDSEVEX0VWRU5UUycpXTtcbiAgICAgICAgY29uc3QgcGFzc2l2ZUV2ZW50cyA9IF9nbG9iYWxbem9uZVN5bWJvbCgnUEFTU0lWRV9FVkVOVFMnKV07XG4gICAgICAgIGNvbnN0IG1ha2VBZGRMaXN0ZW5lciA9IGZ1bmN0aW9uIChuYXRpdmVMaXN0ZW5lciwgYWRkU291cmNlLCBjdXN0b21TY2hlZHVsZUZuLCBjdXN0b21DYW5jZWxGbiwgcmV0dXJuVGFyZ2V0ID0gZmFsc2UsIHByZXBlbmQgPSBmYWxzZSkge1xuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXQgPSB0aGlzIHx8IF9nbG9iYWw7XG4gICAgICAgICAgICAgICAgbGV0IGV2ZW50TmFtZSA9IGFyZ3VtZW50c1swXTtcbiAgICAgICAgICAgICAgICBpZiAocGF0Y2hPcHRpb25zICYmIHBhdGNoT3B0aW9ucy50cmFuc2ZlckV2ZW50TmFtZSkge1xuICAgICAgICAgICAgICAgICAgICBldmVudE5hbWUgPSBwYXRjaE9wdGlvbnMudHJhbnNmZXJFdmVudE5hbWUoZXZlbnROYW1lKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbGV0IGRlbGVnYXRlID0gYXJndW1lbnRzWzFdO1xuICAgICAgICAgICAgICAgIGlmICghZGVsZWdhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5hdGl2ZUxpc3RlbmVyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChpc05vZGUgJiYgZXZlbnROYW1lID09PSAndW5jYXVnaHRFeGNlcHRpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGRvbid0IHBhdGNoIHVuY2F1Z2h0RXhjZXB0aW9uIG9mIG5vZGVqcyB0byBwcmV2ZW50IGVuZGxlc3MgbG9vcFxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmF0aXZlTGlzdGVuZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gZG9uJ3QgY3JlYXRlIHRoZSBiaW5kIGRlbGVnYXRlIGZ1bmN0aW9uIGZvciBoYW5kbGVFdmVudFxuICAgICAgICAgICAgICAgIC8vIGNhc2UgaGVyZSB0byBpbXByb3ZlIGFkZEV2ZW50TGlzdGVuZXIgcGVyZm9ybWFuY2VcbiAgICAgICAgICAgICAgICAvLyB3ZSB3aWxsIGNyZWF0ZSB0aGUgYmluZCBkZWxlZ2F0ZSB3aGVuIGludm9rZVxuICAgICAgICAgICAgICAgIGxldCBpc0hhbmRsZUV2ZW50ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBkZWxlZ2F0ZSAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWRlbGVnYXRlLmhhbmRsZUV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmF0aXZlTGlzdGVuZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpc0hhbmRsZUV2ZW50ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRlSGFuZGxlciAmJiAhdmFsaWRhdGVIYW5kbGVyKG5hdGl2ZUxpc3RlbmVyLCBkZWxlZ2F0ZSwgdGFyZ2V0LCBhcmd1bWVudHMpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgcGFzc2l2ZSA9IHBhc3NpdmVTdXBwb3J0ZWQgJiYgISFwYXNzaXZlRXZlbnRzICYmIHBhc3NpdmVFdmVudHMuaW5kZXhPZihldmVudE5hbWUpICE9PSAtMTtcbiAgICAgICAgICAgICAgICBjb25zdCBvcHRpb25zID0gYnVpbGRFdmVudExpc3RlbmVyT3B0aW9ucyhhcmd1bWVudHNbMl0sIHBhc3NpdmUpO1xuICAgICAgICAgICAgICAgIGlmICh1bnBhdGNoZWRFdmVudHMpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gY2hlY2sgdW5wYXRjaGVkIGxpc3RcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB1bnBhdGNoZWRFdmVudHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChldmVudE5hbWUgPT09IHVucGF0Y2hlZEV2ZW50c1tpXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwYXNzaXZlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBuYXRpdmVMaXN0ZW5lci5jYWxsKHRhcmdldCwgZXZlbnROYW1lLCBkZWxlZ2F0ZSwgb3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmF0aXZlTGlzdGVuZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgY2FwdHVyZSA9ICFvcHRpb25zID8gZmFsc2UgOiB0eXBlb2Ygb3B0aW9ucyA9PT0gJ2Jvb2xlYW4nID8gdHJ1ZSA6IG9wdGlvbnMuY2FwdHVyZTtcbiAgICAgICAgICAgICAgICBjb25zdCBvbmNlID0gb3B0aW9ucyAmJiB0eXBlb2Ygb3B0aW9ucyA9PT0gJ29iamVjdCcgPyBvcHRpb25zLm9uY2UgOiBmYWxzZTtcbiAgICAgICAgICAgICAgICBjb25zdCB6b25lID0gWm9uZS5jdXJyZW50O1xuICAgICAgICAgICAgICAgIGxldCBzeW1ib2xFdmVudE5hbWVzID0gem9uZVN5bWJvbEV2ZW50TmFtZXNbZXZlbnROYW1lXTtcbiAgICAgICAgICAgICAgICBpZiAoIXN5bWJvbEV2ZW50TmFtZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgcHJlcGFyZUV2ZW50TmFtZXMoZXZlbnROYW1lLCBldmVudE5hbWVUb1N0cmluZyk7XG4gICAgICAgICAgICAgICAgICAgIHN5bWJvbEV2ZW50TmFtZXMgPSB6b25lU3ltYm9sRXZlbnROYW1lc1tldmVudE5hbWVdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBzeW1ib2xFdmVudE5hbWUgPSBzeW1ib2xFdmVudE5hbWVzW2NhcHR1cmUgPyBUUlVFX1NUUiA6IEZBTFNFX1NUUl07XG4gICAgICAgICAgICAgICAgbGV0IGV4aXN0aW5nVGFza3MgPSB0YXJnZXRbc3ltYm9sRXZlbnROYW1lXTtcbiAgICAgICAgICAgICAgICBsZXQgaXNFeGlzdGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGlmIChleGlzdGluZ1Rhc2tzKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGFscmVhZHkgaGF2ZSB0YXNrIHJlZ2lzdGVyZWRcbiAgICAgICAgICAgICAgICAgICAgaXNFeGlzdGluZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjaGVja0R1cGxpY2F0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBleGlzdGluZ1Rhc2tzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbXBhcmUoZXhpc3RpbmdUYXNrc1tpXSwgZGVsZWdhdGUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNhbWUgY2FsbGJhY2ssIHNhbWUgY2FwdHVyZSwgc2FtZSBldmVudCBuYW1lLCBqdXN0IHJldHVyblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1Rhc2tzID0gdGFyZ2V0W3N5bWJvbEV2ZW50TmFtZV0gPSBbXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbGV0IHNvdXJjZTtcbiAgICAgICAgICAgICAgICBjb25zdCBjb25zdHJ1Y3Rvck5hbWUgPSB0YXJnZXQuY29uc3RydWN0b3JbJ25hbWUnXTtcbiAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXRTb3VyY2UgPSBnbG9iYWxTb3VyY2VzW2NvbnN0cnVjdG9yTmFtZV07XG4gICAgICAgICAgICAgICAgaWYgKHRhcmdldFNvdXJjZSkge1xuICAgICAgICAgICAgICAgICAgICBzb3VyY2UgPSB0YXJnZXRTb3VyY2VbZXZlbnROYW1lXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKCFzb3VyY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgc291cmNlID0gY29uc3RydWN0b3JOYW1lICsgYWRkU291cmNlICtcbiAgICAgICAgICAgICAgICAgICAgICAgIChldmVudE5hbWVUb1N0cmluZyA/IGV2ZW50TmFtZVRvU3RyaW5nKGV2ZW50TmFtZSkgOiBldmVudE5hbWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBkbyBub3QgY3JlYXRlIGEgbmV3IG9iamVjdCBhcyB0YXNrLmRhdGEgdG8gcGFzcyB0aG9zZSB0aGluZ3NcbiAgICAgICAgICAgICAgICAvLyBqdXN0IHVzZSB0aGUgZ2xvYmFsIHNoYXJlZCBvbmVcbiAgICAgICAgICAgICAgICB0YXNrRGF0YS5vcHRpb25zID0gb3B0aW9ucztcbiAgICAgICAgICAgICAgICBpZiAob25jZSkge1xuICAgICAgICAgICAgICAgICAgICAvLyBpZiBhZGRFdmVudExpc3RlbmVyIHdpdGggb25jZSBvcHRpb25zLCB3ZSBkb24ndCBwYXNzIGl0IHRvXG4gICAgICAgICAgICAgICAgICAgIC8vIG5hdGl2ZSBhZGRFdmVudExpc3RlbmVyLCBpbnN0ZWFkIHdlIGtlZXAgdGhlIG9uY2Ugc2V0dGluZ1xuICAgICAgICAgICAgICAgICAgICAvLyBhbmQgaGFuZGxlIG91cnNlbHZlcy5cbiAgICAgICAgICAgICAgICAgICAgdGFza0RhdGEub3B0aW9ucy5vbmNlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRhc2tEYXRhLnRhcmdldCA9IHRhcmdldDtcbiAgICAgICAgICAgICAgICB0YXNrRGF0YS5jYXB0dXJlID0gY2FwdHVyZTtcbiAgICAgICAgICAgICAgICB0YXNrRGF0YS5ldmVudE5hbWUgPSBldmVudE5hbWU7XG4gICAgICAgICAgICAgICAgdGFza0RhdGEuaXNFeGlzdGluZyA9IGlzRXhpc3Rpbmc7XG4gICAgICAgICAgICAgICAgY29uc3QgZGF0YSA9IHVzZUdsb2JhbENhbGxiYWNrID8gT1BUSU1JWkVEX1pPTkVfRVZFTlRfVEFTS19EQVRBIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIC8vIGtlZXAgdGFza0RhdGEgaW50byBkYXRhIHRvIGFsbG93IG9uU2NoZWR1bGVFdmVudFRhc2sgdG8gYWNjZXNzIHRoZSB0YXNrIGluZm9ybWF0aW9uXG4gICAgICAgICAgICAgICAgaWYgKGRhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgZGF0YS50YXNrRGF0YSA9IHRhc2tEYXRhO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCB0YXNrID0gem9uZS5zY2hlZHVsZUV2ZW50VGFzayhzb3VyY2UsIGRlbGVnYXRlLCBkYXRhLCBjdXN0b21TY2hlZHVsZUZuLCBjdXN0b21DYW5jZWxGbik7XG4gICAgICAgICAgICAgICAgLy8gc2hvdWxkIGNsZWFyIHRhc2tEYXRhLnRhcmdldCB0byBhdm9pZCBtZW1vcnkgbGVha1xuICAgICAgICAgICAgICAgIC8vIGlzc3VlLCBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2lzc3Vlcy8yMDQ0MlxuICAgICAgICAgICAgICAgIHRhc2tEYXRhLnRhcmdldCA9IG51bGw7XG4gICAgICAgICAgICAgICAgLy8gbmVlZCB0byBjbGVhciB1cCB0YXNrRGF0YSBiZWNhdXNlIGl0IGlzIGEgZ2xvYmFsIG9iamVjdFxuICAgICAgICAgICAgICAgIGlmIChkYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgIGRhdGEudGFza0RhdGEgPSBudWxsO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBoYXZlIHRvIHNhdmUgdGhvc2UgaW5mb3JtYXRpb24gdG8gdGFzayBpbiBjYXNlXG4gICAgICAgICAgICAgICAgLy8gYXBwbGljYXRpb24gbWF5IGNhbGwgdGFzay56b25lLmNhbmNlbFRhc2soKSBkaXJlY3RseVxuICAgICAgICAgICAgICAgIGlmIChvbmNlKSB7XG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnMub25jZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICghKCFwYXNzaXZlU3VwcG9ydGVkICYmIHR5cGVvZiB0YXNrLm9wdGlvbnMgPT09ICdib29sZWFuJykpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gaWYgbm90IHN1cHBvcnQgcGFzc2l2ZSwgYW5kIHdlIHBhc3MgYW4gb3B0aW9uIG9iamVjdFxuICAgICAgICAgICAgICAgICAgICAvLyB0byBhZGRFdmVudExpc3RlbmVyLCB3ZSBzaG91bGQgc2F2ZSB0aGUgb3B0aW9ucyB0byB0YXNrXG4gICAgICAgICAgICAgICAgICAgIHRhc2sub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRhc2sudGFyZ2V0ID0gdGFyZ2V0O1xuICAgICAgICAgICAgICAgIHRhc2suY2FwdHVyZSA9IGNhcHR1cmU7XG4gICAgICAgICAgICAgICAgdGFzay5ldmVudE5hbWUgPSBldmVudE5hbWU7XG4gICAgICAgICAgICAgICAgaWYgKGlzSGFuZGxlRXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gc2F2ZSBvcmlnaW5hbCBkZWxlZ2F0ZSBmb3IgY29tcGFyZSB0byBjaGVjayBkdXBsaWNhdGVcbiAgICAgICAgICAgICAgICAgICAgdGFzay5vcmlnaW5hbERlbGVnYXRlID0gZGVsZWdhdGU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICghcHJlcGVuZCkge1xuICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1Rhc2tzLnB1c2godGFzayk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1Rhc2tzLnVuc2hpZnQodGFzayk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChyZXR1cm5UYXJnZXQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICB9O1xuICAgICAgICBwcm90b1tBRERfRVZFTlRfTElTVEVORVJdID0gbWFrZUFkZExpc3RlbmVyKG5hdGl2ZUFkZEV2ZW50TGlzdGVuZXIsIEFERF9FVkVOVF9MSVNURU5FUl9TT1VSQ0UsIGN1c3RvbVNjaGVkdWxlLCBjdXN0b21DYW5jZWwsIHJldHVyblRhcmdldCk7XG4gICAgICAgIGlmIChuYXRpdmVQcmVwZW5kRXZlbnRMaXN0ZW5lcikge1xuICAgICAgICAgICAgcHJvdG9bUFJFUEVORF9FVkVOVF9MSVNURU5FUl0gPSBtYWtlQWRkTGlzdGVuZXIobmF0aXZlUHJlcGVuZEV2ZW50TGlzdGVuZXIsIFBSRVBFTkRfRVZFTlRfTElTVEVORVJfU09VUkNFLCBjdXN0b21TY2hlZHVsZVByZXBlbmQsIGN1c3RvbUNhbmNlbCwgcmV0dXJuVGFyZ2V0LCB0cnVlKTtcbiAgICAgICAgfVxuICAgICAgICBwcm90b1tSRU1PVkVfRVZFTlRfTElTVEVORVJdID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gdGhpcyB8fCBfZ2xvYmFsO1xuICAgICAgICAgICAgbGV0IGV2ZW50TmFtZSA9IGFyZ3VtZW50c1swXTtcbiAgICAgICAgICAgIGlmIChwYXRjaE9wdGlvbnMgJiYgcGF0Y2hPcHRpb25zLnRyYW5zZmVyRXZlbnROYW1lKSB7XG4gICAgICAgICAgICAgICAgZXZlbnROYW1lID0gcGF0Y2hPcHRpb25zLnRyYW5zZmVyRXZlbnROYW1lKGV2ZW50TmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBvcHRpb25zID0gYXJndW1lbnRzWzJdO1xuICAgICAgICAgICAgY29uc3QgY2FwdHVyZSA9ICFvcHRpb25zID8gZmFsc2UgOiB0eXBlb2Ygb3B0aW9ucyA9PT0gJ2Jvb2xlYW4nID8gdHJ1ZSA6IG9wdGlvbnMuY2FwdHVyZTtcbiAgICAgICAgICAgIGNvbnN0IGRlbGVnYXRlID0gYXJndW1lbnRzWzFdO1xuICAgICAgICAgICAgaWYgKCFkZWxlZ2F0ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBuYXRpdmVSZW1vdmVFdmVudExpc3RlbmVyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodmFsaWRhdGVIYW5kbGVyICYmXG4gICAgICAgICAgICAgICAgIXZhbGlkYXRlSGFuZGxlcihuYXRpdmVSZW1vdmVFdmVudExpc3RlbmVyLCBkZWxlZ2F0ZSwgdGFyZ2V0LCBhcmd1bWVudHMpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3Qgc3ltYm9sRXZlbnROYW1lcyA9IHpvbmVTeW1ib2xFdmVudE5hbWVzW2V2ZW50TmFtZV07XG4gICAgICAgICAgICBsZXQgc3ltYm9sRXZlbnROYW1lO1xuICAgICAgICAgICAgaWYgKHN5bWJvbEV2ZW50TmFtZXMpIHtcbiAgICAgICAgICAgICAgICBzeW1ib2xFdmVudE5hbWUgPSBzeW1ib2xFdmVudE5hbWVzW2NhcHR1cmUgPyBUUlVFX1NUUiA6IEZBTFNFX1NUUl07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBleGlzdGluZ1Rhc2tzID0gc3ltYm9sRXZlbnROYW1lICYmIHRhcmdldFtzeW1ib2xFdmVudE5hbWVdO1xuICAgICAgICAgICAgaWYgKGV4aXN0aW5nVGFza3MpIHtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGV4aXN0aW5nVGFza3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdUYXNrID0gZXhpc3RpbmdUYXNrc1tpXTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbXBhcmUoZXhpc3RpbmdUYXNrLCBkZWxlZ2F0ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nVGFza3Muc3BsaWNlKGksIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc2V0IGlzUmVtb3ZlZCB0byBkYXRhIGZvciBmYXN0ZXIgaW52b2tlVGFzayBjaGVja1xuICAgICAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdUYXNrLmlzUmVtb3ZlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdUYXNrcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBhbGwgdGFza3MgZm9yIHRoZSBldmVudE5hbWUgKyBjYXB0dXJlIGhhdmUgZ29uZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyByZW1vdmUgZ2xvYmFsWm9uZUF3YXJlQ2FsbGJhY2sgYW5kIHJlbW92ZSB0aGUgdGFzayBjYWNoZSBmcm9tIHRhcmdldFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nVGFzay5hbGxSZW1vdmVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXRbc3ltYm9sRXZlbnROYW1lXSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaW4gdGhlIHRhcmdldCwgd2UgaGF2ZSBhbiBldmVudCBsaXN0ZW5lciB3aGljaCBpcyBhZGRlZCBieSBvbl9wcm9wZXJ0eVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHN1Y2ggYXMgdGFyZ2V0Lm9uY2xpY2sgPSBmdW5jdGlvbigpIHt9LCBzbyB3ZSBuZWVkIHRvIGNsZWFyIHRoaXMgaW50ZXJuYWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBwcm9wZXJ0eSB0b28gaWYgYWxsIGRlbGVnYXRlcyBhbGwgcmVtb3ZlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgZXZlbnROYW1lID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBvblByb3BlcnR5U3ltYm9sID0gWk9ORV9TWU1CT0xfUFJFRklYICsgJ09OX1BST1BFUlRZJyArIGV2ZW50TmFtZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0W29uUHJvcGVydHlTeW1ib2xdID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1Rhc2suem9uZS5jYW5jZWxUYXNrKGV4aXN0aW5nVGFzayk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmV0dXJuVGFyZ2V0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIGlzc3VlIDkzMCwgZGlkbid0IGZpbmQgdGhlIGV2ZW50IG5hbWUgb3IgY2FsbGJhY2tcbiAgICAgICAgICAgIC8vIGZyb20gem9uZSBrZXB0IGV4aXN0aW5nVGFza3MsIHRoZSBjYWxsYmFjayBtYXliZVxuICAgICAgICAgICAgLy8gYWRkZWQgb3V0c2lkZSBvZiB6b25lLCB3ZSBuZWVkIHRvIGNhbGwgbmF0aXZlIHJlbW92ZUV2ZW50TGlzdGVuZXJcbiAgICAgICAgICAgIC8vIHRvIHRyeSB0byByZW1vdmUgaXQuXG4gICAgICAgICAgICByZXR1cm4gbmF0aXZlUmVtb3ZlRXZlbnRMaXN0ZW5lci5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICB9O1xuICAgICAgICBwcm90b1tMSVNURU5FUlNfRVZFTlRfTElTVEVORVJdID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gdGhpcyB8fCBfZ2xvYmFsO1xuICAgICAgICAgICAgbGV0IGV2ZW50TmFtZSA9IGFyZ3VtZW50c1swXTtcbiAgICAgICAgICAgIGlmIChwYXRjaE9wdGlvbnMgJiYgcGF0Y2hPcHRpb25zLnRyYW5zZmVyRXZlbnROYW1lKSB7XG4gICAgICAgICAgICAgICAgZXZlbnROYW1lID0gcGF0Y2hPcHRpb25zLnRyYW5zZmVyRXZlbnROYW1lKGV2ZW50TmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBsaXN0ZW5lcnMgPSBbXTtcbiAgICAgICAgICAgIGNvbnN0IHRhc2tzID0gZmluZEV2ZW50VGFza3ModGFyZ2V0LCBldmVudE5hbWVUb1N0cmluZyA/IGV2ZW50TmFtZVRvU3RyaW5nKGV2ZW50TmFtZSkgOiBldmVudE5hbWUpO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0YXNrcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRhc2sgPSB0YXNrc1tpXTtcbiAgICAgICAgICAgICAgICBsZXQgZGVsZWdhdGUgPSB0YXNrLm9yaWdpbmFsRGVsZWdhdGUgPyB0YXNrLm9yaWdpbmFsRGVsZWdhdGUgOiB0YXNrLmNhbGxiYWNrO1xuICAgICAgICAgICAgICAgIGxpc3RlbmVycy5wdXNoKGRlbGVnYXRlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBsaXN0ZW5lcnM7XG4gICAgICAgIH07XG4gICAgICAgIHByb3RvW1JFTU9WRV9BTExfTElTVEVORVJTX0VWRU5UX0xJU1RFTkVSXSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IHRoaXMgfHwgX2dsb2JhbDtcbiAgICAgICAgICAgIGxldCBldmVudE5hbWUgPSBhcmd1bWVudHNbMF07XG4gICAgICAgICAgICBpZiAoIWV2ZW50TmFtZSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyh0YXJnZXQpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwcm9wID0ga2V5c1tpXTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbWF0Y2ggPSBFVkVOVF9OQU1FX1NZTUJPTF9SRUdYLmV4ZWMocHJvcCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBldnROYW1lID0gbWF0Y2ggJiYgbWF0Y2hbMV07XG4gICAgICAgICAgICAgICAgICAgIC8vIGluIG5vZGVqcyBFdmVudEVtaXR0ZXIsIHJlbW92ZUxpc3RlbmVyIGV2ZW50IGlzXG4gICAgICAgICAgICAgICAgICAgIC8vIHVzZWQgZm9yIG1vbml0b3JpbmcgdGhlIHJlbW92ZUxpc3RlbmVyIGNhbGwsXG4gICAgICAgICAgICAgICAgICAgIC8vIHNvIGp1c3Qga2VlcCByZW1vdmVMaXN0ZW5lciBldmVudExpc3RlbmVyIHVudGlsXG4gICAgICAgICAgICAgICAgICAgIC8vIGFsbCBvdGhlciBldmVudExpc3RlbmVycyBhcmUgcmVtb3ZlZFxuICAgICAgICAgICAgICAgICAgICBpZiAoZXZ0TmFtZSAmJiBldnROYW1lICE9PSAncmVtb3ZlTGlzdGVuZXInKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW1JFTU9WRV9BTExfTElTVEVORVJTX0VWRU5UX0xJU1RFTkVSXS5jYWxsKHRoaXMsIGV2dE5hbWUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIHJlbW92ZSByZW1vdmVMaXN0ZW5lciBsaXN0ZW5lciBmaW5hbGx5XG4gICAgICAgICAgICAgICAgdGhpc1tSRU1PVkVfQUxMX0xJU1RFTkVSU19FVkVOVF9MSVNURU5FUl0uY2FsbCh0aGlzLCAncmVtb3ZlTGlzdGVuZXInKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmIChwYXRjaE9wdGlvbnMgJiYgcGF0Y2hPcHRpb25zLnRyYW5zZmVyRXZlbnROYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIGV2ZW50TmFtZSA9IHBhdGNoT3B0aW9ucy50cmFuc2ZlckV2ZW50TmFtZShldmVudE5hbWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBzeW1ib2xFdmVudE5hbWVzID0gem9uZVN5bWJvbEV2ZW50TmFtZXNbZXZlbnROYW1lXTtcbiAgICAgICAgICAgICAgICBpZiAoc3ltYm9sRXZlbnROYW1lcykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzeW1ib2xFdmVudE5hbWUgPSBzeW1ib2xFdmVudE5hbWVzW0ZBTFNFX1NUUl07XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHN5bWJvbENhcHR1cmVFdmVudE5hbWUgPSBzeW1ib2xFdmVudE5hbWVzW1RSVUVfU1RSXTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdGFza3MgPSB0YXJnZXRbc3ltYm9sRXZlbnROYW1lXTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2FwdHVyZVRhc2tzID0gdGFyZ2V0W3N5bWJvbENhcHR1cmVFdmVudE5hbWVdO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGFza3MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlbW92ZVRhc2tzID0gdGFza3Muc2xpY2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVtb3ZlVGFza3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0YXNrID0gcmVtb3ZlVGFza3NbaV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRlbGVnYXRlID0gdGFzay5vcmlnaW5hbERlbGVnYXRlID8gdGFzay5vcmlnaW5hbERlbGVnYXRlIDogdGFzay5jYWxsYmFjaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW1JFTU9WRV9FVkVOVF9MSVNURU5FUl0uY2FsbCh0aGlzLCBldmVudE5hbWUsIGRlbGVnYXRlLCB0YXNrLm9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChjYXB0dXJlVGFza3MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlbW92ZVRhc2tzID0gY2FwdHVyZVRhc2tzLnNsaWNlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlbW92ZVRhc2tzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGFzayA9IHJlbW92ZVRhc2tzW2ldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkZWxlZ2F0ZSA9IHRhc2sub3JpZ2luYWxEZWxlZ2F0ZSA/IHRhc2sub3JpZ2luYWxEZWxlZ2F0ZSA6IHRhc2suY2FsbGJhY2s7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpc1tSRU1PVkVfRVZFTlRfTElTVEVORVJdLmNhbGwodGhpcywgZXZlbnROYW1lLCBkZWxlZ2F0ZSwgdGFzay5vcHRpb25zKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyZXR1cm5UYXJnZXQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgLy8gZm9yIG5hdGl2ZSB0b1N0cmluZyBwYXRjaFxuICAgICAgICBhdHRhY2hPcmlnaW5Ub1BhdGNoZWQocHJvdG9bQUREX0VWRU5UX0xJU1RFTkVSXSwgbmF0aXZlQWRkRXZlbnRMaXN0ZW5lcik7XG4gICAgICAgIGF0dGFjaE9yaWdpblRvUGF0Y2hlZChwcm90b1tSRU1PVkVfRVZFTlRfTElTVEVORVJdLCBuYXRpdmVSZW1vdmVFdmVudExpc3RlbmVyKTtcbiAgICAgICAgaWYgKG5hdGl2ZVJlbW92ZUFsbExpc3RlbmVycykge1xuICAgICAgICAgICAgYXR0YWNoT3JpZ2luVG9QYXRjaGVkKHByb3RvW1JFTU9WRV9BTExfTElTVEVORVJTX0VWRU5UX0xJU1RFTkVSXSwgbmF0aXZlUmVtb3ZlQWxsTGlzdGVuZXJzKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobmF0aXZlTGlzdGVuZXJzKSB7XG4gICAgICAgICAgICBhdHRhY2hPcmlnaW5Ub1BhdGNoZWQocHJvdG9bTElTVEVORVJTX0VWRU5UX0xJU1RFTkVSXSwgbmF0aXZlTGlzdGVuZXJzKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgbGV0IHJlc3VsdHMgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFwaXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcmVzdWx0c1tpXSA9IHBhdGNoRXZlbnRUYXJnZXRNZXRob2RzKGFwaXNbaV0sIHBhdGNoT3B0aW9ucyk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHRzO1xufVxuZnVuY3Rpb24gZmluZEV2ZW50VGFza3ModGFyZ2V0LCBldmVudE5hbWUpIHtcbiAgICBpZiAoIWV2ZW50TmFtZSkge1xuICAgICAgICBjb25zdCBmb3VuZFRhc2tzID0gW107XG4gICAgICAgIGZvciAobGV0IHByb3AgaW4gdGFyZ2V0KSB7XG4gICAgICAgICAgICBjb25zdCBtYXRjaCA9IEVWRU5UX05BTUVfU1lNQk9MX1JFR1guZXhlYyhwcm9wKTtcbiAgICAgICAgICAgIGxldCBldnROYW1lID0gbWF0Y2ggJiYgbWF0Y2hbMV07XG4gICAgICAgICAgICBpZiAoZXZ0TmFtZSAmJiAoIWV2ZW50TmFtZSB8fCBldnROYW1lID09PSBldmVudE5hbWUpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdGFza3MgPSB0YXJnZXRbcHJvcF07XG4gICAgICAgICAgICAgICAgaWYgKHRhc2tzKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGFza3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvdW5kVGFza3MucHVzaCh0YXNrc1tpXSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZvdW5kVGFza3M7XG4gICAgfVxuICAgIGxldCBzeW1ib2xFdmVudE5hbWUgPSB6b25lU3ltYm9sRXZlbnROYW1lc1tldmVudE5hbWVdO1xuICAgIGlmICghc3ltYm9sRXZlbnROYW1lKSB7XG4gICAgICAgIHByZXBhcmVFdmVudE5hbWVzKGV2ZW50TmFtZSk7XG4gICAgICAgIHN5bWJvbEV2ZW50TmFtZSA9IHpvbmVTeW1ib2xFdmVudE5hbWVzW2V2ZW50TmFtZV07XG4gICAgfVxuICAgIGNvbnN0IGNhcHR1cmVGYWxzZVRhc2tzID0gdGFyZ2V0W3N5bWJvbEV2ZW50TmFtZVtGQUxTRV9TVFJdXTtcbiAgICBjb25zdCBjYXB0dXJlVHJ1ZVRhc2tzID0gdGFyZ2V0W3N5bWJvbEV2ZW50TmFtZVtUUlVFX1NUUl1dO1xuICAgIGlmICghY2FwdHVyZUZhbHNlVGFza3MpIHtcbiAgICAgICAgcmV0dXJuIGNhcHR1cmVUcnVlVGFza3MgPyBjYXB0dXJlVHJ1ZVRhc2tzLnNsaWNlKCkgOiBbXTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHJldHVybiBjYXB0dXJlVHJ1ZVRhc2tzID8gY2FwdHVyZUZhbHNlVGFza3MuY29uY2F0KGNhcHR1cmVUcnVlVGFza3MpIDpcbiAgICAgICAgICAgIGNhcHR1cmVGYWxzZVRhc2tzLnNsaWNlKCk7XG4gICAgfVxufVxuZnVuY3Rpb24gcGF0Y2hFdmVudFByb3RvdHlwZShnbG9iYWwsIGFwaSkge1xuICAgIGNvbnN0IEV2ZW50ID0gZ2xvYmFsWydFdmVudCddO1xuICAgIGlmIChFdmVudCAmJiBFdmVudC5wcm90b3R5cGUpIHtcbiAgICAgICAgYXBpLnBhdGNoTWV0aG9kKEV2ZW50LnByb3RvdHlwZSwgJ3N0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbicsIChkZWxlZ2F0ZSkgPT4gZnVuY3Rpb24gKHNlbGYsIGFyZ3MpIHtcbiAgICAgICAgICAgIHNlbGZbSU1NRURJQVRFX1BST1BBR0FUSU9OX1NZTUJPTF0gPSB0cnVlO1xuICAgICAgICAgICAgLy8gd2UgbmVlZCB0byBjYWxsIHRoZSBuYXRpdmUgc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uXG4gICAgICAgICAgICAvLyBpbiBjYXNlIGluIHNvbWUgaHlicmlkIGFwcGxpY2F0aW9uLCBzb21lIHBhcnQgb2ZcbiAgICAgICAgICAgIC8vIGFwcGxpY2F0aW9uIHdpbGwgYmUgY29udHJvbGxlZCBieSB6b25lLCBzb21lIGFyZSBub3RcbiAgICAgICAgICAgIGRlbGVnYXRlICYmIGRlbGVnYXRlLmFwcGx5KHNlbGYsIGFyZ3MpO1xuICAgICAgICB9KTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIHBhdGNoQ2FsbGJhY2tzKGFwaSwgdGFyZ2V0LCB0YXJnZXROYW1lLCBtZXRob2QsIGNhbGxiYWNrcykge1xuICAgIGNvbnN0IHN5bWJvbCA9IFpvbmUuX19zeW1ib2xfXyhtZXRob2QpO1xuICAgIGlmICh0YXJnZXRbc3ltYm9sXSkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG5hdGl2ZURlbGVnYXRlID0gdGFyZ2V0W3N5bWJvbF0gPSB0YXJnZXRbbWV0aG9kXTtcbiAgICB0YXJnZXRbbWV0aG9kXSA9IGZ1bmN0aW9uIChuYW1lLCBvcHRzLCBvcHRpb25zKSB7XG4gICAgICAgIGlmIChvcHRzICYmIG9wdHMucHJvdG90eXBlKSB7XG4gICAgICAgICAgICBjYWxsYmFja3MuZm9yRWFjaChmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgICBjb25zdCBzb3VyY2UgPSBgJHt0YXJnZXROYW1lfS4ke21ldGhvZH06OmAgKyBjYWxsYmFjaztcbiAgICAgICAgICAgICAgICBjb25zdCBwcm90b3R5cGUgPSBvcHRzLnByb3RvdHlwZTtcbiAgICAgICAgICAgICAgICAvLyBOb3RlOiB0aGUgYHBhdGNoQ2FsbGJhY2tzYCBpcyB1c2VkIGZvciBwYXRjaGluZyB0aGUgYGRvY3VtZW50LnJlZ2lzdGVyRWxlbWVudGAgYW5kXG4gICAgICAgICAgICAgICAgLy8gYGN1c3RvbUVsZW1lbnRzLmRlZmluZWAuIFdlIGV4cGxpY2l0bHkgd3JhcCB0aGUgcGF0Y2hpbmcgY29kZSBpbnRvIHRyeS1jYXRjaCBzaW5jZVxuICAgICAgICAgICAgICAgIC8vIGNhbGxiYWNrcyBtYXkgYmUgYWxyZWFkeSBwYXRjaGVkIGJ5IG90aGVyIHdlYiBjb21wb25lbnRzIGZyYW1ld29ya3MgKGUuZy4gTFdDKSwgYW5kIHRoZXlcbiAgICAgICAgICAgICAgICAvLyBtYWtlIHRob3NlIHByb3BlcnRpZXMgbm9uLXdyaXRhYmxlLiBUaGlzIG1lYW5zIHRoYXQgcGF0Y2hpbmcgY2FsbGJhY2sgd2lsbCB0aHJvdyBhbiBlcnJvclxuICAgICAgICAgICAgICAgIC8vIGBjYW5ub3QgYXNzaWduIHRvIHJlYWQtb25seSBwcm9wZXJ0eWAuIFNlZSB0aGlzIGNvZGUgYXMgYW4gZXhhbXBsZTpcbiAgICAgICAgICAgICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vc2FsZXNmb3JjZS9sd2MvYmxvYi9tYXN0ZXIvcGFja2FnZXMvQGx3Yy9lbmdpbmUtY29yZS9zcmMvZnJhbWV3b3JrL2Jhc2UtYnJpZGdlLWVsZW1lbnQudHMjTDE4MC1MMTg2XG4gICAgICAgICAgICAgICAgLy8gV2UgZG9uJ3Qgd2FudCB0byBzdG9wIHRoZSBhcHBsaWNhdGlvbiByZW5kZXJpbmcgaWYgd2UgY291bGRuJ3QgcGF0Y2ggc29tZVxuICAgICAgICAgICAgICAgIC8vIGNhbGxiYWNrLCBlLmcuIGBhdHRyaWJ1dGVDaGFuZ2VkQ2FsbGJhY2tgLlxuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm90b3R5cGUuaGFzT3duUHJvcGVydHkoY2FsbGJhY2spKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkZXNjcmlwdG9yID0gYXBpLk9iamVjdEdldE93blByb3BlcnR5RGVzY3JpcHRvcihwcm90b3R5cGUsIGNhbGxiYWNrKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkZXNjcmlwdG9yICYmIGRlc2NyaXB0b3IudmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdG9yLnZhbHVlID0gYXBpLndyYXBXaXRoQ3VycmVudFpvbmUoZGVzY3JpcHRvci52YWx1ZSwgc291cmNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcGkuX3JlZGVmaW5lUHJvcGVydHkob3B0cy5wcm90b3R5cGUsIGNhbGxiYWNrLCBkZXNjcmlwdG9yKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKHByb3RvdHlwZVtjYWxsYmFja10pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm90b3R5cGVbY2FsbGJhY2tdID0gYXBpLndyYXBXaXRoQ3VycmVudFpvbmUocHJvdG90eXBlW2NhbGxiYWNrXSwgc291cmNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChwcm90b3R5cGVbY2FsbGJhY2tdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwcm90b3R5cGVbY2FsbGJhY2tdID0gYXBpLndyYXBXaXRoQ3VycmVudFpvbmUocHJvdG90eXBlW2NhbGxiYWNrXSwgc291cmNlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCB7XG4gICAgICAgICAgICAgICAgICAgIC8vIE5vdGU6IHdlIGxlYXZlIHRoZSBjYXRjaCBibG9jayBlbXB0eSBzaW5jZSB0aGVyZSdzIG5vIHdheSB0byBoYW5kbGUgdGhlIGVycm9yIHJlbGF0ZWRcbiAgICAgICAgICAgICAgICAgICAgLy8gdG8gbm9uLXdyaXRhYmxlIHByb3BlcnR5LlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuYXRpdmVEZWxlZ2F0ZS5jYWxsKHRhcmdldCwgbmFtZSwgb3B0cywgb3B0aW9ucyk7XG4gICAgfTtcbiAgICBhcGkuYXR0YWNoT3JpZ2luVG9QYXRjaGVkKHRhcmdldFttZXRob2RdLCBuYXRpdmVEZWxlZ2F0ZSk7XG59XG5cbi8qKlxuICogQGZpbGVvdmVydmlld1xuICogQHN1cHByZXNzIHtnbG9iYWxUaGlzfVxuICovXG5mdW5jdGlvbiBmaWx0ZXJQcm9wZXJ0aWVzKHRhcmdldCwgb25Qcm9wZXJ0aWVzLCBpZ25vcmVQcm9wZXJ0aWVzKSB7XG4gICAgaWYgKCFpZ25vcmVQcm9wZXJ0aWVzIHx8IGlnbm9yZVByb3BlcnRpZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiBvblByb3BlcnRpZXM7XG4gICAgfVxuICAgIGNvbnN0IHRpcCA9IGlnbm9yZVByb3BlcnRpZXMuZmlsdGVyKGlwID0+IGlwLnRhcmdldCA9PT0gdGFyZ2V0KTtcbiAgICBpZiAoIXRpcCB8fCB0aXAubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiBvblByb3BlcnRpZXM7XG4gICAgfVxuICAgIGNvbnN0IHRhcmdldElnbm9yZVByb3BlcnRpZXMgPSB0aXBbMF0uaWdub3JlUHJvcGVydGllcztcbiAgICByZXR1cm4gb25Qcm9wZXJ0aWVzLmZpbHRlcihvcCA9PiB0YXJnZXRJZ25vcmVQcm9wZXJ0aWVzLmluZGV4T2Yob3ApID09PSAtMSk7XG59XG5mdW5jdGlvbiBwYXRjaEZpbHRlcmVkUHJvcGVydGllcyh0YXJnZXQsIG9uUHJvcGVydGllcywgaWdub3JlUHJvcGVydGllcywgcHJvdG90eXBlKSB7XG4gICAgLy8gY2hlY2sgd2hldGhlciB0YXJnZXQgaXMgYXZhaWxhYmxlLCBzb21ldGltZXMgdGFyZ2V0IHdpbGwgYmUgdW5kZWZpbmVkXG4gICAgLy8gYmVjYXVzZSBkaWZmZXJlbnQgYnJvd3NlciBvciBzb21lIDNyZCBwYXJ0eSBwbHVnaW4uXG4gICAgaWYgKCF0YXJnZXQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBmaWx0ZXJlZFByb3BlcnRpZXMgPSBmaWx0ZXJQcm9wZXJ0aWVzKHRhcmdldCwgb25Qcm9wZXJ0aWVzLCBpZ25vcmVQcm9wZXJ0aWVzKTtcbiAgICBwYXRjaE9uUHJvcGVydGllcyh0YXJnZXQsIGZpbHRlcmVkUHJvcGVydGllcywgcHJvdG90eXBlKTtcbn1cbi8qKlxuICogR2V0IGFsbCBldmVudCBuYW1lIHByb3BlcnRpZXMgd2hpY2ggdGhlIGV2ZW50IG5hbWUgc3RhcnRzV2l0aCBgb25gXG4gKiBmcm9tIHRoZSB0YXJnZXQgb2JqZWN0IGl0c2VsZiwgaW5oZXJpdGVkIHByb3BlcnRpZXMgYXJlIG5vdCBjb25zaWRlcmVkLlxuICovXG5mdW5jdGlvbiBnZXRPbkV2ZW50TmFtZXModGFyZ2V0KSB7XG4gICAgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHRhcmdldClcbiAgICAgICAgLmZpbHRlcihuYW1lID0+IG5hbWUuc3RhcnRzV2l0aCgnb24nKSAmJiBuYW1lLmxlbmd0aCA+IDIpXG4gICAgICAgIC5tYXAobmFtZSA9PiBuYW1lLnN1YnN0cmluZygyKSk7XG59XG5mdW5jdGlvbiBwcm9wZXJ0eURlc2NyaXB0b3JQYXRjaChhcGksIF9nbG9iYWwpIHtcbiAgICBpZiAoaXNOb2RlICYmICFpc01peCkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChab25lW2FwaS5zeW1ib2woJ3BhdGNoRXZlbnRzJyldKSB7XG4gICAgICAgIC8vIGV2ZW50cyBhcmUgYWxyZWFkeSBiZWVuIHBhdGNoZWQgYnkgbGVnYWN5IHBhdGNoLlxuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGlnbm9yZVByb3BlcnRpZXMgPSBfZ2xvYmFsWydfX1pvbmVfaWdub3JlX29uX3Byb3BlcnRpZXMnXTtcbiAgICAvLyBmb3IgYnJvd3NlcnMgdGhhdCB3ZSBjYW4gcGF0Y2ggdGhlIGRlc2NyaXB0b3I6ICBDaHJvbWUgJiBGaXJlZm94XG4gICAgbGV0IHBhdGNoVGFyZ2V0cyA9IFtdO1xuICAgIGlmIChpc0Jyb3dzZXIpIHtcbiAgICAgICAgY29uc3QgaW50ZXJuYWxXaW5kb3cgPSB3aW5kb3c7XG4gICAgICAgIHBhdGNoVGFyZ2V0cyA9IHBhdGNoVGFyZ2V0cy5jb25jYXQoW1xuICAgICAgICAgICAgJ0RvY3VtZW50JywgJ1NWR0VsZW1lbnQnLCAnRWxlbWVudCcsICdIVE1MRWxlbWVudCcsICdIVE1MQm9keUVsZW1lbnQnLCAnSFRNTE1lZGlhRWxlbWVudCcsXG4gICAgICAgICAgICAnSFRNTEZyYW1lU2V0RWxlbWVudCcsICdIVE1MRnJhbWVFbGVtZW50JywgJ0hUTUxJRnJhbWVFbGVtZW50JywgJ0hUTUxNYXJxdWVlRWxlbWVudCcsICdXb3JrZXInXG4gICAgICAgIF0pO1xuICAgICAgICBjb25zdCBpZ25vcmVFcnJvclByb3BlcnRpZXMgPSBpc0lFKCkgPyBbeyB0YXJnZXQ6IGludGVybmFsV2luZG93LCBpZ25vcmVQcm9wZXJ0aWVzOiBbJ2Vycm9yJ10gfV0gOiBbXTtcbiAgICAgICAgLy8gaW4gSUUvRWRnZSwgb25Qcm9wIG5vdCBleGlzdCBpbiB3aW5kb3cgb2JqZWN0LCBidXQgaW4gV2luZG93UHJvdG90eXBlXG4gICAgICAgIC8vIHNvIHdlIG5lZWQgdG8gcGFzcyBXaW5kb3dQcm90b3R5cGUgdG8gY2hlY2sgb25Qcm9wIGV4aXN0IG9yIG5vdFxuICAgICAgICBwYXRjaEZpbHRlcmVkUHJvcGVydGllcyhpbnRlcm5hbFdpbmRvdywgZ2V0T25FdmVudE5hbWVzKGludGVybmFsV2luZG93KSwgaWdub3JlUHJvcGVydGllcyA/IGlnbm9yZVByb3BlcnRpZXMuY29uY2F0KGlnbm9yZUVycm9yUHJvcGVydGllcykgOiBpZ25vcmVQcm9wZXJ0aWVzLCBPYmplY3RHZXRQcm90b3R5cGVPZihpbnRlcm5hbFdpbmRvdykpO1xuICAgIH1cbiAgICBwYXRjaFRhcmdldHMgPSBwYXRjaFRhcmdldHMuY29uY2F0KFtcbiAgICAgICAgJ1hNTEh0dHBSZXF1ZXN0JywgJ1hNTEh0dHBSZXF1ZXN0RXZlbnRUYXJnZXQnLCAnSURCSW5kZXgnLCAnSURCUmVxdWVzdCcsICdJREJPcGVuREJSZXF1ZXN0JyxcbiAgICAgICAgJ0lEQkRhdGFiYXNlJywgJ0lEQlRyYW5zYWN0aW9uJywgJ0lEQkN1cnNvcicsICdXZWJTb2NrZXQnXG4gICAgXSk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwYXRjaFRhcmdldHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gX2dsb2JhbFtwYXRjaFRhcmdldHNbaV1dO1xuICAgICAgICB0YXJnZXQgJiYgdGFyZ2V0LnByb3RvdHlwZSAmJlxuICAgICAgICAgICAgcGF0Y2hGaWx0ZXJlZFByb3BlcnRpZXModGFyZ2V0LnByb3RvdHlwZSwgZ2V0T25FdmVudE5hbWVzKHRhcmdldC5wcm90b3R5cGUpLCBpZ25vcmVQcm9wZXJ0aWVzKTtcbiAgICB9XG59XG5cblpvbmUuX19sb2FkX3BhdGNoKCd1dGlsJywgKGdsb2JhbCwgWm9uZSwgYXBpKSA9PiB7XG4gICAgLy8gQ29sbGVjdCBuYXRpdmUgZXZlbnQgbmFtZXMgYnkgbG9va2luZyBhdCBwcm9wZXJ0aWVzXG4gICAgLy8gb24gdGhlIGdsb2JhbCBuYW1lc3BhY2UsIGUuZy4gJ29uY2xpY2snLlxuICAgIGNvbnN0IGV2ZW50TmFtZXMgPSBnZXRPbkV2ZW50TmFtZXMoZ2xvYmFsKTtcbiAgICBhcGkucGF0Y2hPblByb3BlcnRpZXMgPSBwYXRjaE9uUHJvcGVydGllcztcbiAgICBhcGkucGF0Y2hNZXRob2QgPSBwYXRjaE1ldGhvZDtcbiAgICBhcGkuYmluZEFyZ3VtZW50cyA9IGJpbmRBcmd1bWVudHM7XG4gICAgYXBpLnBhdGNoTWFjcm9UYXNrID0gcGF0Y2hNYWNyb1Rhc2s7XG4gICAgLy8gSW4gZWFybGllciB2ZXJzaW9uIG9mIHpvbmUuanMgKDwwLjkuMCksIHdlIHVzZSBlbnYgbmFtZSBgX196b25lX3N5bWJvbF9fQkxBQ0tfTElTVEVEX0VWRU5UU2AgdG9cbiAgICAvLyBkZWZpbmUgd2hpY2ggZXZlbnRzIHdpbGwgbm90IGJlIHBhdGNoZWQgYnkgYFpvbmUuanNgLlxuICAgIC8vIEluIG5ld2VyIHZlcnNpb24gKD49MC45LjApLCB3ZSBjaGFuZ2UgdGhlIGVudiBuYW1lIHRvIGBfX3pvbmVfc3ltYm9sX19VTlBBVENIRURfRVZFTlRTYCB0byBrZWVwXG4gICAgLy8gdGhlIG5hbWUgY29uc2lzdGVudCB3aXRoIGFuZ3VsYXIgcmVwby5cbiAgICAvLyBUaGUgIGBfX3pvbmVfc3ltYm9sX19CTEFDS19MSVNURURfRVZFTlRTYCBpcyBkZXByZWNhdGVkLCBidXQgaXQgaXMgc3RpbGwgYmUgc3VwcG9ydGVkIGZvclxuICAgIC8vIGJhY2t3YXJkcyBjb21wYXRpYmlsaXR5LlxuICAgIGNvbnN0IFNZTUJPTF9CTEFDS19MSVNURURfRVZFTlRTID0gWm9uZS5fX3N5bWJvbF9fKCdCTEFDS19MSVNURURfRVZFTlRTJyk7XG4gICAgY29uc3QgU1lNQk9MX1VOUEFUQ0hFRF9FVkVOVFMgPSBab25lLl9fc3ltYm9sX18oJ1VOUEFUQ0hFRF9FVkVOVFMnKTtcbiAgICBpZiAoZ2xvYmFsW1NZTUJPTF9VTlBBVENIRURfRVZFTlRTXSkge1xuICAgICAgICBnbG9iYWxbU1lNQk9MX0JMQUNLX0xJU1RFRF9FVkVOVFNdID0gZ2xvYmFsW1NZTUJPTF9VTlBBVENIRURfRVZFTlRTXTtcbiAgICB9XG4gICAgaWYgKGdsb2JhbFtTWU1CT0xfQkxBQ0tfTElTVEVEX0VWRU5UU10pIHtcbiAgICAgICAgWm9uZVtTWU1CT0xfQkxBQ0tfTElTVEVEX0VWRU5UU10gPSBab25lW1NZTUJPTF9VTlBBVENIRURfRVZFTlRTXSA9XG4gICAgICAgICAgICBnbG9iYWxbU1lNQk9MX0JMQUNLX0xJU1RFRF9FVkVOVFNdO1xuICAgIH1cbiAgICBhcGkucGF0Y2hFdmVudFByb3RvdHlwZSA9IHBhdGNoRXZlbnRQcm90b3R5cGU7XG4gICAgYXBpLnBhdGNoRXZlbnRUYXJnZXQgPSBwYXRjaEV2ZW50VGFyZ2V0O1xuICAgIGFwaS5pc0lFT3JFZGdlID0gaXNJRU9yRWRnZTtcbiAgICBhcGkuT2JqZWN0RGVmaW5lUHJvcGVydHkgPSBPYmplY3REZWZpbmVQcm9wZXJ0eTtcbiAgICBhcGkuT2JqZWN0R2V0T3duUHJvcGVydHlEZXNjcmlwdG9yID0gT2JqZWN0R2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xuICAgIGFwaS5PYmplY3RDcmVhdGUgPSBPYmplY3RDcmVhdGU7XG4gICAgYXBpLkFycmF5U2xpY2UgPSBBcnJheVNsaWNlO1xuICAgIGFwaS5wYXRjaENsYXNzID0gcGF0Y2hDbGFzcztcbiAgICBhcGkud3JhcFdpdGhDdXJyZW50Wm9uZSA9IHdyYXBXaXRoQ3VycmVudFpvbmU7XG4gICAgYXBpLmZpbHRlclByb3BlcnRpZXMgPSBmaWx0ZXJQcm9wZXJ0aWVzO1xuICAgIGFwaS5hdHRhY2hPcmlnaW5Ub1BhdGNoZWQgPSBhdHRhY2hPcmlnaW5Ub1BhdGNoZWQ7XG4gICAgYXBpLl9yZWRlZmluZVByb3BlcnR5ID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xuICAgIGFwaS5wYXRjaENhbGxiYWNrcyA9IHBhdGNoQ2FsbGJhY2tzO1xuICAgIGFwaS5nZXRHbG9iYWxPYmplY3RzID0gKCkgPT4gKHtcbiAgICAgICAgZ2xvYmFsU291cmNlcyxcbiAgICAgICAgem9uZVN5bWJvbEV2ZW50TmFtZXMsXG4gICAgICAgIGV2ZW50TmFtZXMsXG4gICAgICAgIGlzQnJvd3NlcixcbiAgICAgICAgaXNNaXgsXG4gICAgICAgIGlzTm9kZSxcbiAgICAgICAgVFJVRV9TVFIsXG4gICAgICAgIEZBTFNFX1NUUixcbiAgICAgICAgWk9ORV9TWU1CT0xfUFJFRklYLFxuICAgICAgICBBRERfRVZFTlRfTElTVEVORVJfU1RSLFxuICAgICAgICBSRU1PVkVfRVZFTlRfTElTVEVORVJfU1RSXG4gICAgfSk7XG59KTtcblxuLyoqXG4gKiBAZmlsZW92ZXJ2aWV3XG4gKiBAc3VwcHJlc3Mge21pc3NpbmdSZXF1aXJlfVxuICovXG5mdW5jdGlvbiBwYXRjaFF1ZXVlTWljcm90YXNrKGdsb2JhbCwgYXBpKSB7XG4gICAgYXBpLnBhdGNoTWV0aG9kKGdsb2JhbCwgJ3F1ZXVlTWljcm90YXNrJywgKGRlbGVnYXRlKSA9PiB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoc2VsZiwgYXJncykge1xuICAgICAgICAgICAgWm9uZS5jdXJyZW50LnNjaGVkdWxlTWljcm9UYXNrKCdxdWV1ZU1pY3JvdGFzaycsIGFyZ3NbMF0pO1xuICAgICAgICB9O1xuICAgIH0pO1xufVxuXG4vKipcbiAqIEBmaWxlb3ZlcnZpZXdcbiAqIEBzdXBwcmVzcyB7bWlzc2luZ1JlcXVpcmV9XG4gKi9cbmNvbnN0IHRhc2tTeW1ib2wgPSB6b25lU3ltYm9sKCd6b25lVGFzaycpO1xuZnVuY3Rpb24gcGF0Y2hUaW1lcih3aW5kb3csIHNldE5hbWUsIGNhbmNlbE5hbWUsIG5hbWVTdWZmaXgpIHtcbiAgICBsZXQgc2V0TmF0aXZlID0gbnVsbDtcbiAgICBsZXQgY2xlYXJOYXRpdmUgPSBudWxsO1xuICAgIHNldE5hbWUgKz0gbmFtZVN1ZmZpeDtcbiAgICBjYW5jZWxOYW1lICs9IG5hbWVTdWZmaXg7XG4gICAgY29uc3QgdGFza3NCeUhhbmRsZUlkID0ge307XG4gICAgZnVuY3Rpb24gc2NoZWR1bGVUYXNrKHRhc2spIHtcbiAgICAgICAgY29uc3QgZGF0YSA9IHRhc2suZGF0YTtcbiAgICAgICAgZGF0YS5hcmdzWzBdID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRhc2suaW52b2tlLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgIH07XG4gICAgICAgIGRhdGEuaGFuZGxlSWQgPSBzZXROYXRpdmUuYXBwbHkod2luZG93LCBkYXRhLmFyZ3MpO1xuICAgICAgICByZXR1cm4gdGFzaztcbiAgICB9XG4gICAgZnVuY3Rpb24gY2xlYXJUYXNrKHRhc2spIHtcbiAgICAgICAgcmV0dXJuIGNsZWFyTmF0aXZlLmNhbGwod2luZG93LCB0YXNrLmRhdGEuaGFuZGxlSWQpO1xuICAgIH1cbiAgICBzZXROYXRpdmUgPVxuICAgICAgICBwYXRjaE1ldGhvZCh3aW5kb3csIHNldE5hbWUsIChkZWxlZ2F0ZSkgPT4gZnVuY3Rpb24gKHNlbGYsIGFyZ3MpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgYXJnc1swXSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICAgICAgICAgICAgICAgIGlzUGVyaW9kaWM6IG5hbWVTdWZmaXggPT09ICdJbnRlcnZhbCcsXG4gICAgICAgICAgICAgICAgICAgIGRlbGF5OiAobmFtZVN1ZmZpeCA9PT0gJ1RpbWVvdXQnIHx8IG5hbWVTdWZmaXggPT09ICdJbnRlcnZhbCcpID8gYXJnc1sxXSB8fCAwIDpcbiAgICAgICAgICAgICAgICAgICAgICAgIHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgYXJnczogYXJnc1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgY29uc3QgY2FsbGJhY2sgPSBhcmdzWzBdO1xuICAgICAgICAgICAgICAgIGFyZ3NbMF0gPSBmdW5jdGlvbiB0aW1lcigpIHtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjYWxsYmFjay5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaXNzdWUtOTM0LCB0YXNrIHdpbGwgYmUgY2FuY2VsbGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBldmVuIGl0IGlzIGEgcGVyaW9kaWMgdGFzayBzdWNoIGFzXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzZXRJbnRlcnZhbFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2FuZ3VsYXIvYW5ndWxhci9pc3N1ZXMvNDAzODdcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIENsZWFudXAgdGFza3NCeUhhbmRsZUlkIHNob3VsZCBiZSBoYW5kbGVkIGJlZm9yZSBzY2hlZHVsZVRhc2tcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNpbmNlIHNvbWUgem9uZVNwZWMgbWF5IGludGVyY2VwdCBhbmQgZG9lc24ndCB0cmlnZ2VyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzY2hlZHVsZUZuKHNjaGVkdWxlVGFzaykgcHJvdmlkZWQgaGVyZS5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghKG9wdGlvbnMuaXNQZXJpb2RpYykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG9wdGlvbnMuaGFuZGxlSWQgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGluIG5vbi1ub2RlanMgZW52LCB3ZSByZW1vdmUgdGltZXJJZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBmcm9tIGxvY2FsIGNhY2hlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZSB0YXNrc0J5SGFuZGxlSWRbb3B0aW9ucy5oYW5kbGVJZF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKG9wdGlvbnMuaGFuZGxlSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTm9kZSByZXR1cm5zIGNvbXBsZXggb2JqZWN0cyBhcyBoYW5kbGVJZHNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gd2UgcmVtb3ZlIHRhc2sgcmVmZXJlbmNlIGZyb20gdGltZXIgb2JqZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnMuaGFuZGxlSWRbdGFza1N5bWJvbF0gPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgY29uc3QgdGFzayA9IHNjaGVkdWxlTWFjcm9UYXNrV2l0aEN1cnJlbnRab25lKHNldE5hbWUsIGFyZ3NbMF0sIG9wdGlvbnMsIHNjaGVkdWxlVGFzaywgY2xlYXJUYXNrKTtcbiAgICAgICAgICAgICAgICBpZiAoIXRhc2spIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhc2s7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIE5vZGUuanMgbXVzdCBhZGRpdGlvbmFsbHkgc3VwcG9ydCB0aGUgcmVmIGFuZCB1bnJlZiBmdW5jdGlvbnMuXG4gICAgICAgICAgICAgICAgY29uc3QgaGFuZGxlID0gdGFzay5kYXRhLmhhbmRsZUlkO1xuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgaGFuZGxlID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgICAgICAgICAvLyBmb3Igbm9uIG5vZGVqcyBlbnYsIHdlIHNhdmUgaGFuZGxlSWQ6IHRhc2tcbiAgICAgICAgICAgICAgICAgICAgLy8gbWFwcGluZyBpbiBsb2NhbCBjYWNoZSBmb3IgY2xlYXJUaW1lb3V0XG4gICAgICAgICAgICAgICAgICAgIHRhc2tzQnlIYW5kbGVJZFtoYW5kbGVdID0gdGFzaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoaGFuZGxlKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGZvciBub2RlanMgZW52LCB3ZSBzYXZlIHRhc2tcbiAgICAgICAgICAgICAgICAgICAgLy8gcmVmZXJlbmNlIGluIHRpbWVySWQgT2JqZWN0IGZvciBjbGVhclRpbWVvdXRcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlW3Rhc2tTeW1ib2xdID0gdGFzaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gY2hlY2sgd2hldGhlciBoYW5kbGUgaXMgbnVsbCwgYmVjYXVzZSBzb21lIHBvbHlmaWxsIG9yIGJyb3dzZXJcbiAgICAgICAgICAgICAgICAvLyBtYXkgcmV0dXJuIHVuZGVmaW5lZCBmcm9tIHNldFRpbWVvdXQvc2V0SW50ZXJ2YWwvc2V0SW1tZWRpYXRlL3JlcXVlc3RBbmltYXRpb25GcmFtZVxuICAgICAgICAgICAgICAgIGlmIChoYW5kbGUgJiYgaGFuZGxlLnJlZiAmJiBoYW5kbGUudW5yZWYgJiYgdHlwZW9mIGhhbmRsZS5yZWYgPT09ICdmdW5jdGlvbicgJiZcbiAgICAgICAgICAgICAgICAgICAgdHlwZW9mIGhhbmRsZS51bnJlZiA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgICB0YXNrLnJlZiA9IGhhbmRsZS5yZWYuYmluZChoYW5kbGUpO1xuICAgICAgICAgICAgICAgICAgICB0YXNrLnVucmVmID0gaGFuZGxlLnVucmVmLmJpbmQoaGFuZGxlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBoYW5kbGUgPT09ICdudW1iZXInIHx8IGhhbmRsZSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaGFuZGxlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdGFzaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIGNhdXNlIGFuIGVycm9yIGJ5IGNhbGxpbmcgaXQgZGlyZWN0bHkuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGRlbGVnYXRlLmFwcGx5KHdpbmRvdywgYXJncyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIGNsZWFyTmF0aXZlID1cbiAgICAgICAgcGF0Y2hNZXRob2Qod2luZG93LCBjYW5jZWxOYW1lLCAoZGVsZWdhdGUpID0+IGZ1bmN0aW9uIChzZWxmLCBhcmdzKSB7XG4gICAgICAgICAgICBjb25zdCBpZCA9IGFyZ3NbMF07XG4gICAgICAgICAgICBsZXQgdGFzaztcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaWQgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICAgICAgLy8gbm9uIG5vZGVqcyBlbnYuXG4gICAgICAgICAgICAgICAgdGFzayA9IHRhc2tzQnlIYW5kbGVJZFtpZF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBub2RlanMgZW52LlxuICAgICAgICAgICAgICAgIHRhc2sgPSBpZCAmJiBpZFt0YXNrU3ltYm9sXTtcbiAgICAgICAgICAgICAgICAvLyBvdGhlciBlbnZpcm9ubWVudHMuXG4gICAgICAgICAgICAgICAgaWYgKCF0YXNrKSB7XG4gICAgICAgICAgICAgICAgICAgIHRhc2sgPSBpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodGFzayAmJiB0eXBlb2YgdGFzay50eXBlID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICAgIGlmICh0YXNrLnN0YXRlICE9PSAnbm90U2NoZWR1bGVkJyAmJlxuICAgICAgICAgICAgICAgICAgICAodGFzay5jYW5jZWxGbiAmJiB0YXNrLmRhdGEuaXNQZXJpb2RpYyB8fCB0YXNrLnJ1bkNvdW50ID09PSAwKSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGlkID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlIHRhc2tzQnlIYW5kbGVJZFtpZF07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkW3Rhc2tTeW1ib2xdID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAvLyBEbyBub3QgY2FuY2VsIGFscmVhZHkgY2FuY2VsZWQgZnVuY3Rpb25zXG4gICAgICAgICAgICAgICAgICAgIHRhc2suem9uZS5jYW5jZWxUYXNrKHRhc2spO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIGNhdXNlIGFuIGVycm9yIGJ5IGNhbGxpbmcgaXQgZGlyZWN0bHkuXG4gICAgICAgICAgICAgICAgZGVsZWdhdGUuYXBwbHkod2luZG93LCBhcmdzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG59XG5cbmZ1bmN0aW9uIHBhdGNoQ3VzdG9tRWxlbWVudHMoX2dsb2JhbCwgYXBpKSB7XG4gICAgY29uc3QgeyBpc0Jyb3dzZXIsIGlzTWl4IH0gPSBhcGkuZ2V0R2xvYmFsT2JqZWN0cygpO1xuICAgIGlmICgoIWlzQnJvd3NlciAmJiAhaXNNaXgpIHx8ICFfZ2xvYmFsWydjdXN0b21FbGVtZW50cyddIHx8ICEoJ2N1c3RvbUVsZW1lbnRzJyBpbiBfZ2xvYmFsKSkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGNhbGxiYWNrcyA9IFsnY29ubmVjdGVkQ2FsbGJhY2snLCAnZGlzY29ubmVjdGVkQ2FsbGJhY2snLCAnYWRvcHRlZENhbGxiYWNrJywgJ2F0dHJpYnV0ZUNoYW5nZWRDYWxsYmFjayddO1xuICAgIGFwaS5wYXRjaENhbGxiYWNrcyhhcGksIF9nbG9iYWwuY3VzdG9tRWxlbWVudHMsICdjdXN0b21FbGVtZW50cycsICdkZWZpbmUnLCBjYWxsYmFja3MpO1xufVxuXG5mdW5jdGlvbiBldmVudFRhcmdldFBhdGNoKF9nbG9iYWwsIGFwaSkge1xuICAgIGlmIChab25lW2FwaS5zeW1ib2woJ3BhdGNoRXZlbnRUYXJnZXQnKV0pIHtcbiAgICAgICAgLy8gRXZlbnRUYXJnZXQgaXMgYWxyZWFkeSBwYXRjaGVkLlxuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHsgZXZlbnROYW1lcywgem9uZVN5bWJvbEV2ZW50TmFtZXMsIFRSVUVfU1RSLCBGQUxTRV9TVFIsIFpPTkVfU1lNQk9MX1BSRUZJWCB9ID0gYXBpLmdldEdsb2JhbE9iamVjdHMoKTtcbiAgICAvLyAgcHJlZGVmaW5lIGFsbCBfX3pvbmVfc3ltYm9sX18gKyBldmVudE5hbWUgKyB0cnVlL2ZhbHNlIHN0cmluZ1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZXZlbnROYW1lcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBldmVudE5hbWUgPSBldmVudE5hbWVzW2ldO1xuICAgICAgICBjb25zdCBmYWxzZUV2ZW50TmFtZSA9IGV2ZW50TmFtZSArIEZBTFNFX1NUUjtcbiAgICAgICAgY29uc3QgdHJ1ZUV2ZW50TmFtZSA9IGV2ZW50TmFtZSArIFRSVUVfU1RSO1xuICAgICAgICBjb25zdCBzeW1ib2wgPSBaT05FX1NZTUJPTF9QUkVGSVggKyBmYWxzZUV2ZW50TmFtZTtcbiAgICAgICAgY29uc3Qgc3ltYm9sQ2FwdHVyZSA9IFpPTkVfU1lNQk9MX1BSRUZJWCArIHRydWVFdmVudE5hbWU7XG4gICAgICAgIHpvbmVTeW1ib2xFdmVudE5hbWVzW2V2ZW50TmFtZV0gPSB7fTtcbiAgICAgICAgem9uZVN5bWJvbEV2ZW50TmFtZXNbZXZlbnROYW1lXVtGQUxTRV9TVFJdID0gc3ltYm9sO1xuICAgICAgICB6b25lU3ltYm9sRXZlbnROYW1lc1tldmVudE5hbWVdW1RSVUVfU1RSXSA9IHN5bWJvbENhcHR1cmU7XG4gICAgfVxuICAgIGNvbnN0IEVWRU5UX1RBUkdFVCA9IF9nbG9iYWxbJ0V2ZW50VGFyZ2V0J107XG4gICAgaWYgKCFFVkVOVF9UQVJHRVQgfHwgIUVWRU5UX1RBUkdFVC5wcm90b3R5cGUpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBhcGkucGF0Y2hFdmVudFRhcmdldChfZ2xvYmFsLCBhcGksIFtFVkVOVF9UQVJHRVQgJiYgRVZFTlRfVEFSR0VULnByb3RvdHlwZV0pO1xuICAgIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gcGF0Y2hFdmVudChnbG9iYWwsIGFwaSkge1xuICAgIGFwaS5wYXRjaEV2ZW50UHJvdG90eXBlKGdsb2JhbCwgYXBpKTtcbn1cblxuLyoqXG4gKiBAZmlsZW92ZXJ2aWV3XG4gKiBAc3VwcHJlc3Mge21pc3NpbmdSZXF1aXJlfVxuICovXG5ab25lLl9fbG9hZF9wYXRjaCgnbGVnYWN5JywgKGdsb2JhbCkgPT4ge1xuICAgIGNvbnN0IGxlZ2FjeVBhdGNoID0gZ2xvYmFsW1pvbmUuX19zeW1ib2xfXygnbGVnYWN5UGF0Y2gnKV07XG4gICAgaWYgKGxlZ2FjeVBhdGNoKSB7XG4gICAgICAgIGxlZ2FjeVBhdGNoKCk7XG4gICAgfVxufSk7XG5ab25lLl9fbG9hZF9wYXRjaCgndGltZXJzJywgKGdsb2JhbCkgPT4ge1xuICAgIGNvbnN0IHNldCA9ICdzZXQnO1xuICAgIGNvbnN0IGNsZWFyID0gJ2NsZWFyJztcbiAgICBwYXRjaFRpbWVyKGdsb2JhbCwgc2V0LCBjbGVhciwgJ1RpbWVvdXQnKTtcbiAgICBwYXRjaFRpbWVyKGdsb2JhbCwgc2V0LCBjbGVhciwgJ0ludGVydmFsJyk7XG4gICAgcGF0Y2hUaW1lcihnbG9iYWwsIHNldCwgY2xlYXIsICdJbW1lZGlhdGUnKTtcbn0pO1xuWm9uZS5fX2xvYWRfcGF0Y2goJ3JlcXVlc3RBbmltYXRpb25GcmFtZScsIChnbG9iYWwpID0+IHtcbiAgICBwYXRjaFRpbWVyKGdsb2JhbCwgJ3JlcXVlc3QnLCAnY2FuY2VsJywgJ0FuaW1hdGlvbkZyYW1lJyk7XG4gICAgcGF0Y2hUaW1lcihnbG9iYWwsICdtb3pSZXF1ZXN0JywgJ21vekNhbmNlbCcsICdBbmltYXRpb25GcmFtZScpO1xuICAgIHBhdGNoVGltZXIoZ2xvYmFsLCAnd2Via2l0UmVxdWVzdCcsICd3ZWJraXRDYW5jZWwnLCAnQW5pbWF0aW9uRnJhbWUnKTtcbn0pO1xuWm9uZS5fX2xvYWRfcGF0Y2goJ2Jsb2NraW5nJywgKGdsb2JhbCwgWm9uZSkgPT4ge1xuICAgIGNvbnN0IGJsb2NraW5nTWV0aG9kcyA9IFsnYWxlcnQnLCAncHJvbXB0JywgJ2NvbmZpcm0nXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGJsb2NraW5nTWV0aG9kcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBuYW1lID0gYmxvY2tpbmdNZXRob2RzW2ldO1xuICAgICAgICBwYXRjaE1ldGhvZChnbG9iYWwsIG5hbWUsIChkZWxlZ2F0ZSwgc3ltYm9sLCBuYW1lKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKHMsIGFyZ3MpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gWm9uZS5jdXJyZW50LnJ1bihkZWxlZ2F0ZSwgZ2xvYmFsLCBhcmdzLCBuYW1lKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0pO1xuICAgIH1cbn0pO1xuWm9uZS5fX2xvYWRfcGF0Y2goJ0V2ZW50VGFyZ2V0JywgKGdsb2JhbCwgWm9uZSwgYXBpKSA9PiB7XG4gICAgcGF0Y2hFdmVudChnbG9iYWwsIGFwaSk7XG4gICAgZXZlbnRUYXJnZXRQYXRjaChnbG9iYWwsIGFwaSk7XG4gICAgLy8gcGF0Y2ggWE1MSHR0cFJlcXVlc3RFdmVudFRhcmdldCdzIGFkZEV2ZW50TGlzdGVuZXIvcmVtb3ZlRXZlbnRMaXN0ZW5lclxuICAgIGNvbnN0IFhNTEh0dHBSZXF1ZXN0RXZlbnRUYXJnZXQgPSBnbG9iYWxbJ1hNTEh0dHBSZXF1ZXN0RXZlbnRUYXJnZXQnXTtcbiAgICBpZiAoWE1MSHR0cFJlcXVlc3RFdmVudFRhcmdldCAmJiBYTUxIdHRwUmVxdWVzdEV2ZW50VGFyZ2V0LnByb3RvdHlwZSkge1xuICAgICAgICBhcGkucGF0Y2hFdmVudFRhcmdldChnbG9iYWwsIGFwaSwgW1hNTEh0dHBSZXF1ZXN0RXZlbnRUYXJnZXQucHJvdG90eXBlXSk7XG4gICAgfVxufSk7XG5ab25lLl9fbG9hZF9wYXRjaCgnTXV0YXRpb25PYnNlcnZlcicsIChnbG9iYWwsIFpvbmUsIGFwaSkgPT4ge1xuICAgIHBhdGNoQ2xhc3MoJ011dGF0aW9uT2JzZXJ2ZXInKTtcbiAgICBwYXRjaENsYXNzKCdXZWJLaXRNdXRhdGlvbk9ic2VydmVyJyk7XG59KTtcblpvbmUuX19sb2FkX3BhdGNoKCdJbnRlcnNlY3Rpb25PYnNlcnZlcicsIChnbG9iYWwsIFpvbmUsIGFwaSkgPT4ge1xuICAgIHBhdGNoQ2xhc3MoJ0ludGVyc2VjdGlvbk9ic2VydmVyJyk7XG59KTtcblpvbmUuX19sb2FkX3BhdGNoKCdGaWxlUmVhZGVyJywgKGdsb2JhbCwgWm9uZSwgYXBpKSA9PiB7XG4gICAgcGF0Y2hDbGFzcygnRmlsZVJlYWRlcicpO1xufSk7XG5ab25lLl9fbG9hZF9wYXRjaCgnb25fcHJvcGVydHknLCAoZ2xvYmFsLCBab25lLCBhcGkpID0+IHtcbiAgICBwcm9wZXJ0eURlc2NyaXB0b3JQYXRjaChhcGksIGdsb2JhbCk7XG59KTtcblpvbmUuX19sb2FkX3BhdGNoKCdjdXN0b21FbGVtZW50cycsIChnbG9iYWwsIFpvbmUsIGFwaSkgPT4ge1xuICAgIHBhdGNoQ3VzdG9tRWxlbWVudHMoZ2xvYmFsLCBhcGkpO1xufSk7XG5ab25lLl9fbG9hZF9wYXRjaCgnWEhSJywgKGdsb2JhbCwgWm9uZSkgPT4ge1xuICAgIC8vIFRyZWF0IFhNTEh0dHBSZXF1ZXN0IGFzIGEgbWFjcm90YXNrLlxuICAgIHBhdGNoWEhSKGdsb2JhbCk7XG4gICAgY29uc3QgWEhSX1RBU0sgPSB6b25lU3ltYm9sKCd4aHJUYXNrJyk7XG4gICAgY29uc3QgWEhSX1NZTkMgPSB6b25lU3ltYm9sKCd4aHJTeW5jJyk7XG4gICAgY29uc3QgWEhSX0xJU1RFTkVSID0gem9uZVN5bWJvbCgneGhyTGlzdGVuZXInKTtcbiAgICBjb25zdCBYSFJfU0NIRURVTEVEID0gem9uZVN5bWJvbCgneGhyU2NoZWR1bGVkJyk7XG4gICAgY29uc3QgWEhSX1VSTCA9IHpvbmVTeW1ib2woJ3hoclVSTCcpO1xuICAgIGNvbnN0IFhIUl9FUlJPUl9CRUZPUkVfU0NIRURVTEVEID0gem9uZVN5bWJvbCgneGhyRXJyb3JCZWZvcmVTY2hlZHVsZWQnKTtcbiAgICBmdW5jdGlvbiBwYXRjaFhIUih3aW5kb3cpIHtcbiAgICAgICAgY29uc3QgWE1MSHR0cFJlcXVlc3QgPSB3aW5kb3dbJ1hNTEh0dHBSZXF1ZXN0J107XG4gICAgICAgIGlmICghWE1MSHR0cFJlcXVlc3QpIHtcbiAgICAgICAgICAgIC8vIFhNTEh0dHBSZXF1ZXN0IGlzIG5vdCBhdmFpbGFibGUgaW4gc2VydmljZSB3b3JrZXJcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBYTUxIdHRwUmVxdWVzdFByb3RvdHlwZSA9IFhNTEh0dHBSZXF1ZXN0LnByb3RvdHlwZTtcbiAgICAgICAgZnVuY3Rpb24gZmluZFBlbmRpbmdUYXNrKHRhcmdldCkge1xuICAgICAgICAgICAgcmV0dXJuIHRhcmdldFtYSFJfVEFTS107XG4gICAgICAgIH1cbiAgICAgICAgbGV0IG9yaUFkZExpc3RlbmVyID0gWE1MSHR0cFJlcXVlc3RQcm90b3R5cGVbWk9ORV9TWU1CT0xfQUREX0VWRU5UX0xJU1RFTkVSXTtcbiAgICAgICAgbGV0IG9yaVJlbW92ZUxpc3RlbmVyID0gWE1MSHR0cFJlcXVlc3RQcm90b3R5cGVbWk9ORV9TWU1CT0xfUkVNT1ZFX0VWRU5UX0xJU1RFTkVSXTtcbiAgICAgICAgaWYgKCFvcmlBZGRMaXN0ZW5lcikge1xuICAgICAgICAgICAgY29uc3QgWE1MSHR0cFJlcXVlc3RFdmVudFRhcmdldCA9IHdpbmRvd1snWE1MSHR0cFJlcXVlc3RFdmVudFRhcmdldCddO1xuICAgICAgICAgICAgaWYgKFhNTEh0dHBSZXF1ZXN0RXZlbnRUYXJnZXQpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBYTUxIdHRwUmVxdWVzdEV2ZW50VGFyZ2V0UHJvdG90eXBlID0gWE1MSHR0cFJlcXVlc3RFdmVudFRhcmdldC5wcm90b3R5cGU7XG4gICAgICAgICAgICAgICAgb3JpQWRkTGlzdGVuZXIgPSBYTUxIdHRwUmVxdWVzdEV2ZW50VGFyZ2V0UHJvdG90eXBlW1pPTkVfU1lNQk9MX0FERF9FVkVOVF9MSVNURU5FUl07XG4gICAgICAgICAgICAgICAgb3JpUmVtb3ZlTGlzdGVuZXIgPSBYTUxIdHRwUmVxdWVzdEV2ZW50VGFyZ2V0UHJvdG90eXBlW1pPTkVfU1lNQk9MX1JFTU9WRV9FVkVOVF9MSVNURU5FUl07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgUkVBRFlfU1RBVEVfQ0hBTkdFID0gJ3JlYWR5c3RhdGVjaGFuZ2UnO1xuICAgICAgICBjb25zdCBTQ0hFRFVMRUQgPSAnc2NoZWR1bGVkJztcbiAgICAgICAgZnVuY3Rpb24gc2NoZWR1bGVUYXNrKHRhc2spIHtcbiAgICAgICAgICAgIGNvbnN0IGRhdGEgPSB0YXNrLmRhdGE7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBkYXRhLnRhcmdldDtcbiAgICAgICAgICAgIHRhcmdldFtYSFJfU0NIRURVTEVEXSA9IGZhbHNlO1xuICAgICAgICAgICAgdGFyZ2V0W1hIUl9FUlJPUl9CRUZPUkVfU0NIRURVTEVEXSA9IGZhbHNlO1xuICAgICAgICAgICAgLy8gcmVtb3ZlIGV4aXN0aW5nIGV2ZW50IGxpc3RlbmVyXG4gICAgICAgICAgICBjb25zdCBsaXN0ZW5lciA9IHRhcmdldFtYSFJfTElTVEVORVJdO1xuICAgICAgICAgICAgaWYgKCFvcmlBZGRMaXN0ZW5lcikge1xuICAgICAgICAgICAgICAgIG9yaUFkZExpc3RlbmVyID0gdGFyZ2V0W1pPTkVfU1lNQk9MX0FERF9FVkVOVF9MSVNURU5FUl07XG4gICAgICAgICAgICAgICAgb3JpUmVtb3ZlTGlzdGVuZXIgPSB0YXJnZXRbWk9ORV9TWU1CT0xfUkVNT1ZFX0VWRU5UX0xJU1RFTkVSXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChsaXN0ZW5lcikge1xuICAgICAgICAgICAgICAgIG9yaVJlbW92ZUxpc3RlbmVyLmNhbGwodGFyZ2V0LCBSRUFEWV9TVEFURV9DSEFOR0UsIGxpc3RlbmVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IG5ld0xpc3RlbmVyID0gdGFyZ2V0W1hIUl9MSVNURU5FUl0gPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHRhcmdldC5yZWFkeVN0YXRlID09PSB0YXJnZXQuRE9ORSkge1xuICAgICAgICAgICAgICAgICAgICAvLyBzb21ldGltZXMgb24gc29tZSBicm93c2VycyBYTUxIdHRwUmVxdWVzdCB3aWxsIGZpcmUgb25yZWFkeXN0YXRlY2hhbmdlIHdpdGhcbiAgICAgICAgICAgICAgICAgICAgLy8gcmVhZHlTdGF0ZT00IG11bHRpcGxlIHRpbWVzLCBzbyB3ZSBuZWVkIHRvIGNoZWNrIHRhc2sgc3RhdGUgaGVyZVxuICAgICAgICAgICAgICAgICAgICBpZiAoIWRhdGEuYWJvcnRlZCAmJiB0YXJnZXRbWEhSX1NDSEVEVUxFRF0gJiYgdGFzay5zdGF0ZSA9PT0gU0NIRURVTEVEKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjaGVjayB3aGV0aGVyIHRoZSB4aHIgaGFzIHJlZ2lzdGVyZWQgb25sb2FkIGxpc3RlbmVyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBpZiB0aGF0IGlzIHRoZSBjYXNlLCB0aGUgdGFzayBzaG91bGQgaW52b2tlIGFmdGVyIGFsbFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gb25sb2FkIGxpc3RlbmVycyBmaW5pc2guXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBBbHNvIGlmIHRoZSByZXF1ZXN0IGZhaWxlZCB3aXRob3V0IHJlc3BvbnNlIChzdGF0dXMgPSAwKSwgdGhlIGxvYWQgZXZlbnQgaGFuZGxlclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gd2lsbCBub3QgYmUgdHJpZ2dlcmVkLCBpbiB0aGF0IGNhc2UsIHdlIHNob3VsZCBhbHNvIGludm9rZSB0aGUgcGxhY2Vob2xkZXIgY2FsbGJhY2tcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGNsb3NlIHRoZSBYTUxIdHRwUmVxdWVzdDo6c2VuZCBtYWNyb1Rhc2suXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2lzc3Vlcy8zODc5NVxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbG9hZFRhc2tzID0gdGFyZ2V0W1pvbmUuX19zeW1ib2xfXygnbG9hZGZhbHNlJyldO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRhcmdldC5zdGF0dXMgIT09IDAgJiYgbG9hZFRhc2tzICYmIGxvYWRUYXNrcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgb3JpSW52b2tlID0gdGFzay5pbnZva2U7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFzay5pbnZva2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG5lZWQgdG8gbG9hZCB0aGUgdGFza3MgYWdhaW4sIGJlY2F1c2UgaW4gb3RoZXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbG9hZCBsaXN0ZW5lciwgdGhleSBtYXkgcmVtb3ZlIHRoZW1zZWx2ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbG9hZFRhc2tzID0gdGFyZ2V0W1pvbmUuX19zeW1ib2xfXygnbG9hZGZhbHNlJyldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxvYWRUYXNrcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGxvYWRUYXNrc1tpXSA9PT0gdGFzaykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRUYXNrcy5zcGxpY2UoaSwgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFkYXRhLmFib3J0ZWQgJiYgdGFzay5zdGF0ZSA9PT0gU0NIRURVTEVEKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcmlJbnZva2UuY2FsbCh0YXNrKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZFRhc2tzLnB1c2godGFzayk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXNrLmludm9rZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKCFkYXRhLmFib3J0ZWQgJiYgdGFyZ2V0W1hIUl9TQ0hFRFVMRURdID09PSBmYWxzZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXJyb3Igb2NjdXJzIHdoZW4geGhyLnNlbmQoKVxuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0W1hIUl9FUlJPUl9CRUZPUkVfU0NIRURVTEVEXSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgb3JpQWRkTGlzdGVuZXIuY2FsbCh0YXJnZXQsIFJFQURZX1NUQVRFX0NIQU5HRSwgbmV3TGlzdGVuZXIpO1xuICAgICAgICAgICAgY29uc3Qgc3RvcmVkVGFzayA9IHRhcmdldFtYSFJfVEFTS107XG4gICAgICAgICAgICBpZiAoIXN0b3JlZFRhc2spIHtcbiAgICAgICAgICAgICAgICB0YXJnZXRbWEhSX1RBU0tdID0gdGFzaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNlbmROYXRpdmUuYXBwbHkodGFyZ2V0LCBkYXRhLmFyZ3MpO1xuICAgICAgICAgICAgdGFyZ2V0W1hIUl9TQ0hFRFVMRURdID0gdHJ1ZTtcbiAgICAgICAgICAgIHJldHVybiB0YXNrO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIHBsYWNlaG9sZGVyQ2FsbGJhY2soKSB7IH1cbiAgICAgICAgZnVuY3Rpb24gY2xlYXJUYXNrKHRhc2spIHtcbiAgICAgICAgICAgIGNvbnN0IGRhdGEgPSB0YXNrLmRhdGE7XG4gICAgICAgICAgICAvLyBOb3RlIC0gaWRlYWxseSwgd2Ugd291bGQgY2FsbCBkYXRhLnRhcmdldC5yZW1vdmVFdmVudExpc3RlbmVyIGhlcmUsIGJ1dCBpdCdzIHRvbyBsYXRlXG4gICAgICAgICAgICAvLyB0byBwcmV2ZW50IGl0IGZyb20gZmlyaW5nLiBTbyBpbnN0ZWFkLCB3ZSBzdG9yZSBpbmZvIGZvciB0aGUgZXZlbnQgbGlzdGVuZXIuXG4gICAgICAgICAgICBkYXRhLmFib3J0ZWQgPSB0cnVlO1xuICAgICAgICAgICAgcmV0dXJuIGFib3J0TmF0aXZlLmFwcGx5KGRhdGEudGFyZ2V0LCBkYXRhLmFyZ3MpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG9wZW5OYXRpdmUgPSBwYXRjaE1ldGhvZChYTUxIdHRwUmVxdWVzdFByb3RvdHlwZSwgJ29wZW4nLCAoKSA9PiBmdW5jdGlvbiAoc2VsZiwgYXJncykge1xuICAgICAgICAgICAgc2VsZltYSFJfU1lOQ10gPSBhcmdzWzJdID09IGZhbHNlO1xuICAgICAgICAgICAgc2VsZltYSFJfVVJMXSA9IGFyZ3NbMV07XG4gICAgICAgICAgICByZXR1cm4gb3Blbk5hdGl2ZS5hcHBseShzZWxmLCBhcmdzKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IFhNTEhUVFBSRVFVRVNUX1NPVVJDRSA9ICdYTUxIdHRwUmVxdWVzdC5zZW5kJztcbiAgICAgICAgY29uc3QgZmV0Y2hUYXNrQWJvcnRpbmcgPSB6b25lU3ltYm9sKCdmZXRjaFRhc2tBYm9ydGluZycpO1xuICAgICAgICBjb25zdCBmZXRjaFRhc2tTY2hlZHVsaW5nID0gem9uZVN5bWJvbCgnZmV0Y2hUYXNrU2NoZWR1bGluZycpO1xuICAgICAgICBjb25zdCBzZW5kTmF0aXZlID0gcGF0Y2hNZXRob2QoWE1MSHR0cFJlcXVlc3RQcm90b3R5cGUsICdzZW5kJywgKCkgPT4gZnVuY3Rpb24gKHNlbGYsIGFyZ3MpIHtcbiAgICAgICAgICAgIGlmIChab25lLmN1cnJlbnRbZmV0Y2hUYXNrU2NoZWR1bGluZ10gPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICAvLyBhIGZldGNoIGlzIHNjaGVkdWxpbmcsIHNvIHdlIGFyZSB1c2luZyB4aHIgdG8gcG9seWZpbGwgZmV0Y2hcbiAgICAgICAgICAgICAgICAvLyBhbmQgYmVjYXVzZSB3ZSBhbHJlYWR5IHNjaGVkdWxlIG1hY3JvVGFzayBmb3IgZmV0Y2gsIHdlIHNob3VsZFxuICAgICAgICAgICAgICAgIC8vIG5vdCBzY2hlZHVsZSBhIG1hY3JvVGFzayBmb3IgeGhyIGFnYWluXG4gICAgICAgICAgICAgICAgcmV0dXJuIHNlbmROYXRpdmUuYXBwbHkoc2VsZiwgYXJncyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoc2VsZltYSFJfU1lOQ10pIHtcbiAgICAgICAgICAgICAgICAvLyBpZiB0aGUgWEhSIGlzIHN5bmMgdGhlcmUgaXMgbm8gdGFzayB0byBzY2hlZHVsZSwganVzdCBleGVjdXRlIHRoZSBjb2RlLlxuICAgICAgICAgICAgICAgIHJldHVybiBzZW5kTmF0aXZlLmFwcGx5KHNlbGYsIGFyZ3MpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgb3B0aW9ucyA9IHsgdGFyZ2V0OiBzZWxmLCB1cmw6IHNlbGZbWEhSX1VSTF0sIGlzUGVyaW9kaWM6IGZhbHNlLCBhcmdzOiBhcmdzLCBhYm9ydGVkOiBmYWxzZSB9O1xuICAgICAgICAgICAgICAgIGNvbnN0IHRhc2sgPSBzY2hlZHVsZU1hY3JvVGFza1dpdGhDdXJyZW50Wm9uZShYTUxIVFRQUkVRVUVTVF9TT1VSQ0UsIHBsYWNlaG9sZGVyQ2FsbGJhY2ssIG9wdGlvbnMsIHNjaGVkdWxlVGFzaywgY2xlYXJUYXNrKTtcbiAgICAgICAgICAgICAgICBpZiAoc2VsZiAmJiBzZWxmW1hIUl9FUlJPUl9CRUZPUkVfU0NIRURVTEVEXSA9PT0gdHJ1ZSAmJiAhb3B0aW9ucy5hYm9ydGVkICYmXG4gICAgICAgICAgICAgICAgICAgIHRhc2suc3RhdGUgPT09IFNDSEVEVUxFRCkge1xuICAgICAgICAgICAgICAgICAgICAvLyB4aHIgcmVxdWVzdCB0aHJvdyBlcnJvciB3aGVuIHNlbmRcbiAgICAgICAgICAgICAgICAgICAgLy8gd2Ugc2hvdWxkIGludm9rZSB0YXNrIGluc3RlYWQgb2YgbGVhdmluZyBhIHNjaGVkdWxlZFxuICAgICAgICAgICAgICAgICAgICAvLyBwZW5kaW5nIG1hY3JvVGFza1xuICAgICAgICAgICAgICAgICAgICB0YXNrLmludm9rZSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGFib3J0TmF0aXZlID0gcGF0Y2hNZXRob2QoWE1MSHR0cFJlcXVlc3RQcm90b3R5cGUsICdhYm9ydCcsICgpID0+IGZ1bmN0aW9uIChzZWxmLCBhcmdzKSB7XG4gICAgICAgICAgICBjb25zdCB0YXNrID0gZmluZFBlbmRpbmdUYXNrKHNlbGYpO1xuICAgICAgICAgICAgaWYgKHRhc2sgJiYgdHlwZW9mIHRhc2sudHlwZSA9PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICAgIC8vIElmIHRoZSBYSFIgaGFzIGFscmVhZHkgY29tcGxldGVkLCBkbyBub3RoaW5nLlxuICAgICAgICAgICAgICAgIC8vIElmIHRoZSBYSFIgaGFzIGFscmVhZHkgYmVlbiBhYm9ydGVkLCBkbyBub3RoaW5nLlxuICAgICAgICAgICAgICAgIC8vIEZpeCAjNTY5LCBjYWxsIGFib3J0IG11bHRpcGxlIHRpbWVzIGJlZm9yZSBkb25lIHdpbGwgY2F1c2VcbiAgICAgICAgICAgICAgICAvLyBtYWNyb1Rhc2sgdGFzayBjb3VudCBiZSBuZWdhdGl2ZSBudW1iZXJcbiAgICAgICAgICAgICAgICBpZiAodGFzay5jYW5jZWxGbiA9PSBudWxsIHx8ICh0YXNrLmRhdGEgJiYgdGFzay5kYXRhLmFib3J0ZWQpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGFzay56b25lLmNhbmNlbFRhc2sodGFzayk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChab25lLmN1cnJlbnRbZmV0Y2hUYXNrQWJvcnRpbmddID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgLy8gdGhlIGFib3J0IGlzIGNhbGxlZCBmcm9tIGZldGNoIHBvbHlmaWxsLCB3ZSBuZWVkIHRvIGNhbGwgbmF0aXZlIGFib3J0IG9mIFhIUi5cbiAgICAgICAgICAgICAgICByZXR1cm4gYWJvcnROYXRpdmUuYXBwbHkoc2VsZiwgYXJncyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBPdGhlcndpc2UsIHdlIGFyZSB0cnlpbmcgdG8gYWJvcnQgYW4gWEhSIHdoaWNoIGhhcyBub3QgeWV0IGJlZW4gc2VudCwgc28gdGhlcmUgaXMgbm9cbiAgICAgICAgICAgIC8vIHRhc2tcbiAgICAgICAgICAgIC8vIHRvIGNhbmNlbC4gRG8gbm90aGluZy5cbiAgICAgICAgfSk7XG4gICAgfVxufSk7XG5ab25lLl9fbG9hZF9wYXRjaCgnZ2VvbG9jYXRpb24nLCAoZ2xvYmFsKSA9PiB7XG4gICAgLy8vIEdFT19MT0NBVElPTlxuICAgIGlmIChnbG9iYWxbJ25hdmlnYXRvciddICYmIGdsb2JhbFsnbmF2aWdhdG9yJ10uZ2VvbG9jYXRpb24pIHtcbiAgICAgICAgcGF0Y2hQcm90b3R5cGUoZ2xvYmFsWyduYXZpZ2F0b3InXS5nZW9sb2NhdGlvbiwgWydnZXRDdXJyZW50UG9zaXRpb24nLCAnd2F0Y2hQb3NpdGlvbiddKTtcbiAgICB9XG59KTtcblpvbmUuX19sb2FkX3BhdGNoKCdQcm9taXNlUmVqZWN0aW9uRXZlbnQnLCAoZ2xvYmFsLCBab25lKSA9PiB7XG4gICAgLy8gaGFuZGxlIHVuaGFuZGxlZCBwcm9taXNlIHJlamVjdGlvblxuICAgIGZ1bmN0aW9uIGZpbmRQcm9taXNlUmVqZWN0aW9uSGFuZGxlcihldnROYW1lKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoZSkge1xuICAgICAgICAgICAgY29uc3QgZXZlbnRUYXNrcyA9IGZpbmRFdmVudFRhc2tzKGdsb2JhbCwgZXZ0TmFtZSk7XG4gICAgICAgICAgICBldmVudFRhc2tzLmZvckVhY2goZXZlbnRUYXNrID0+IHtcbiAgICAgICAgICAgICAgICAvLyB3aW5kb3dzIGhhcyBhZGRlZCB1bmhhbmRsZWRyZWplY3Rpb24gZXZlbnQgbGlzdGVuZXJcbiAgICAgICAgICAgICAgICAvLyB0cmlnZ2VyIHRoZSBldmVudCBsaXN0ZW5lclxuICAgICAgICAgICAgICAgIGNvbnN0IFByb21pc2VSZWplY3Rpb25FdmVudCA9IGdsb2JhbFsnUHJvbWlzZVJlamVjdGlvbkV2ZW50J107XG4gICAgICAgICAgICAgICAgaWYgKFByb21pc2VSZWplY3Rpb25FdmVudCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBldnQgPSBuZXcgUHJvbWlzZVJlamVjdGlvbkV2ZW50KGV2dE5hbWUsIHsgcHJvbWlzZTogZS5wcm9taXNlLCByZWFzb246IGUucmVqZWN0aW9uIH0pO1xuICAgICAgICAgICAgICAgICAgICBldmVudFRhc2suaW52b2tlKGV2dCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH07XG4gICAgfVxuICAgIGlmIChnbG9iYWxbJ1Byb21pc2VSZWplY3Rpb25FdmVudCddKSB7XG4gICAgICAgIFpvbmVbem9uZVN5bWJvbCgndW5oYW5kbGVkUHJvbWlzZVJlamVjdGlvbkhhbmRsZXInKV0gPVxuICAgICAgICAgICAgZmluZFByb21pc2VSZWplY3Rpb25IYW5kbGVyKCd1bmhhbmRsZWRyZWplY3Rpb24nKTtcbiAgICAgICAgWm9uZVt6b25lU3ltYm9sKCdyZWplY3Rpb25IYW5kbGVkSGFuZGxlcicpXSA9XG4gICAgICAgICAgICBmaW5kUHJvbWlzZVJlamVjdGlvbkhhbmRsZXIoJ3JlamVjdGlvbmhhbmRsZWQnKTtcbiAgICB9XG59KTtcblpvbmUuX19sb2FkX3BhdGNoKCdxdWV1ZU1pY3JvdGFzaycsIChnbG9iYWwsIFpvbmUsIGFwaSkgPT4ge1xuICAgIHBhdGNoUXVldWVNaWNyb3Rhc2soZ2xvYmFsLCBhcGkpO1xufSk7XG4iLCIvKipcbiAqIEBsaWNlbnNlIEFuZ3VsYXIgdjE3LjAuOFxuICogKGMpIDIwMTAtMjAyMiBHb29nbGUgTExDLiBodHRwczovL2FuZ3VsYXIuaW8vXG4gKiBMaWNlbnNlOiBNSVRcbiAqL1xuXG4vKipcbiAqIFRoZSBjaGFyYWN0ZXIgdXNlZCB0byBtYXJrIHRoZSBzdGFydCBhbmQgZW5kIG9mIGEgXCJibG9ja1wiIGluIGEgYCRsb2NhbGl6ZWAgdGFnZ2VkIHN0cmluZy5cbiAqIEEgYmxvY2sgY2FuIGluZGljYXRlIG1ldGFkYXRhIGFib3V0IHRoZSBtZXNzYWdlIG9yIHNwZWNpZnkgYSBuYW1lIG9mIGEgcGxhY2Vob2xkZXIgZm9yIGFcbiAqIHN1YnN0aXR1dGlvbiBleHByZXNzaW9ucy5cbiAqXG4gKiBGb3IgZXhhbXBsZTpcbiAqXG4gKiBgYGB0c1xuICogJGxvY2FsaXplYEhlbGxvLCAke3RpdGxlfTp0aXRsZTohYDtcbiAqICRsb2NhbGl6ZWA6bWVhbmluZ3xkZXNjcmlwdGlvbkBAaWQ6c291cmNlIG1lc3NhZ2UgdGV4dGA7XG4gKiBgYGBcbiAqL1xuY29uc3QgQkxPQ0tfTUFSS0VSJDEgPSAnOic7XG4vKipcbiAqIFRoZSBtYXJrZXIgdXNlZCB0byBzZXBhcmF0ZSBhIG1lc3NhZ2UncyBcIm1lYW5pbmdcIiBmcm9tIGl0cyBcImRlc2NyaXB0aW9uXCIgaW4gYSBtZXRhZGF0YSBibG9jay5cbiAqXG4gKiBGb3IgZXhhbXBsZTpcbiAqXG4gKiBgYGB0c1xuICogJGxvY2FsaXplIGA6Y29ycmVjdHxJbmRpY2F0ZXMgdGhhdCB0aGUgdXNlciBnb3QgdGhlIGFuc3dlciBjb3JyZWN0OiBSaWdodCFgO1xuICogJGxvY2FsaXplIGA6bW92ZW1lbnR8QnV0dG9uIGxhYmVsIGZvciBtb3ZpbmcgdG8gdGhlIHJpZ2h0OiBSaWdodCFgO1xuICogYGBgXG4gKi9cbmNvbnN0IE1FQU5JTkdfU0VQQVJBVE9SID0gJ3wnO1xuLyoqXG4gKiBUaGUgbWFya2VyIHVzZWQgdG8gc2VwYXJhdGUgYSBtZXNzYWdlJ3MgY3VzdG9tIFwiaWRcIiBmcm9tIGl0cyBcImRlc2NyaXB0aW9uXCIgaW4gYSBtZXRhZGF0YSBibG9jay5cbiAqXG4gKiBGb3IgZXhhbXBsZTpcbiAqXG4gKiBgYGB0c1xuICogJGxvY2FsaXplIGA6QSB3ZWxjb21lIG1lc3NhZ2Ugb24gdGhlIGhvbWUgcGFnZUBAbXlBcHAtaG9tZXBhZ2Utd2VsY29tZTogV2VsY29tZSFgO1xuICogYGBgXG4gKi9cbmNvbnN0IElEX1NFUEFSQVRPUiA9ICdAQCc7XG4vKipcbiAqIFRoZSBtYXJrZXIgdXNlZCB0byBzZXBhcmF0ZSBsZWdhY3kgbWVzc2FnZSBpZHMgZnJvbSB0aGUgcmVzdCBvZiBhIG1ldGFkYXRhIGJsb2NrLlxuICpcbiAqIEZvciBleGFtcGxlOlxuICpcbiAqIGBgYHRzXG4gKiAkbG9jYWxpemUgYDpAQGN1c3RvbS1pZOKQnzJkZjY0NzY3Y2Q4OTVhOGZhYmUzZTE4Yjk0YjViNmI2ZjllMmUzZjA6IFdlbGNvbWUhYDtcbiAqIGBgYFxuICpcbiAqIE5vdGUgdGhhdCB0aGlzIGNoYXJhY3RlciBpcyB0aGUgXCJzeW1ib2wgZm9yIHRoZSB1bml0IHNlcGFyYXRvclwiICjikJ8pIG5vdCB0aGUgXCJ1bml0IHNlcGFyYXRvclxuICogY2hhcmFjdGVyXCIgaXRzZWxmLCBzaW5jZSB0aGF0IGhhcyBubyB2aXN1YWwgcmVwcmVzZW50YXRpb24uIFNlZSBodHRwczovL2dyYXBoZW1pY2EuY29tLyVFMiU5MCU5Ri5cbiAqXG4gKiBIZXJlIGlzIHNvbWUgYmFja2dyb3VuZCBmb3IgdGhlIG9yaWdpbmFsIFwidW5pdCBzZXBhcmF0b3IgY2hhcmFjdGVyXCI6XG4gKiBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL3F1ZXN0aW9ucy84Njk1MTE4L3doYXRzLXRoZS1maWxlLWdyb3VwLXJlY29yZC11bml0LXNlcGFyYXRvci1jb250cm9sLWNoYXJhY3RlcnMtYW5kLWl0cy11c2FnZVxuICovXG5jb25zdCBMRUdBQ1lfSURfSU5ESUNBVE9SID0gJ1xcdTI0MUYnO1xuXG4vKipcbiAqIEEgbGF6aWx5IGNyZWF0ZWQgVGV4dEVuY29kZXIgaW5zdGFuY2UgZm9yIGNvbnZlcnRpbmcgc3RyaW5ncyBpbnRvIFVURi04IGJ5dGVzXG4gKi9cbmxldCB0ZXh0RW5jb2Rlcjtcbi8qKlxuICogUmV0dXJuIHRoZSBtZXNzYWdlIGlkIG9yIGNvbXB1dGUgaXQgdXNpbmcgdGhlIFhMSUZGMSBkaWdlc3QuXG4gKi9cbmZ1bmN0aW9uIGRpZ2VzdChtZXNzYWdlKSB7XG4gICAgcmV0dXJuIG1lc3NhZ2UuaWQgfHwgY29tcHV0ZURpZ2VzdChtZXNzYWdlKTtcbn1cbi8qKlxuICogQ29tcHV0ZSB0aGUgbWVzc2FnZSBpZCB1c2luZyB0aGUgWExJRkYxIGRpZ2VzdC5cbiAqL1xuZnVuY3Rpb24gY29tcHV0ZURpZ2VzdChtZXNzYWdlKSB7XG4gICAgcmV0dXJuIHNoYTEoc2VyaWFsaXplTm9kZXMobWVzc2FnZS5ub2Rlcykuam9pbignJykgKyBgWyR7bWVzc2FnZS5tZWFuaW5nfV1gKTtcbn1cbi8qKlxuICogUmV0dXJuIHRoZSBtZXNzYWdlIGlkIG9yIGNvbXB1dGUgaXQgdXNpbmcgdGhlIFhMSUZGMi9YTUIvJGxvY2FsaXplIGRpZ2VzdC5cbiAqL1xuZnVuY3Rpb24gZGVjaW1hbERpZ2VzdChtZXNzYWdlKSB7XG4gICAgcmV0dXJuIG1lc3NhZ2UuaWQgfHwgY29tcHV0ZURlY2ltYWxEaWdlc3QobWVzc2FnZSk7XG59XG4vKipcbiAqIENvbXB1dGUgdGhlIG1lc3NhZ2UgaWQgdXNpbmcgdGhlIFhMSUZGMi9YTUIvJGxvY2FsaXplIGRpZ2VzdC5cbiAqL1xuZnVuY3Rpb24gY29tcHV0ZURlY2ltYWxEaWdlc3QobWVzc2FnZSkge1xuICAgIGNvbnN0IHZpc2l0b3IgPSBuZXcgX1NlcmlhbGl6ZXJJZ25vcmVJY3VFeHBWaXNpdG9yKCk7XG4gICAgY29uc3QgcGFydHMgPSBtZXNzYWdlLm5vZGVzLm1hcChhID0+IGEudmlzaXQodmlzaXRvciwgbnVsbCkpO1xuICAgIHJldHVybiBjb21wdXRlTXNnSWQocGFydHMuam9pbignJyksIG1lc3NhZ2UubWVhbmluZyk7XG59XG4vKipcbiAqIFNlcmlhbGl6ZSB0aGUgaTE4biBhc3QgdG8gc29tZXRoaW5nIHhtbC1saWtlIGluIG9yZGVyIHRvIGdlbmVyYXRlIGFuIFVJRC5cbiAqXG4gKiBUaGUgdmlzaXRvciBpcyBhbHNvIHVzZWQgaW4gdGhlIGkxOG4gcGFyc2VyIHRlc3RzXG4gKlxuICogQGludGVybmFsXG4gKi9cbmNsYXNzIF9TZXJpYWxpemVyVmlzaXRvciB7XG4gICAgdmlzaXRUZXh0KHRleHQsIGNvbnRleHQpIHtcbiAgICAgICAgcmV0dXJuIHRleHQudmFsdWU7XG4gICAgfVxuICAgIHZpc2l0Q29udGFpbmVyKGNvbnRhaW5lciwgY29udGV4dCkge1xuICAgICAgICByZXR1cm4gYFske2NvbnRhaW5lci5jaGlsZHJlbi5tYXAoY2hpbGQgPT4gY2hpbGQudmlzaXQodGhpcykpLmpvaW4oJywgJyl9XWA7XG4gICAgfVxuICAgIHZpc2l0SWN1KGljdSwgY29udGV4dCkge1xuICAgICAgICBjb25zdCBzdHJDYXNlcyA9IE9iamVjdC5rZXlzKGljdS5jYXNlcykubWFwKChrKSA9PiBgJHtrfSB7JHtpY3UuY2FzZXNba10udmlzaXQodGhpcyl9fWApO1xuICAgICAgICByZXR1cm4gYHske2ljdS5leHByZXNzaW9ufSwgJHtpY3UudHlwZX0sICR7c3RyQ2FzZXMuam9pbignLCAnKX19YDtcbiAgICB9XG4gICAgdmlzaXRUYWdQbGFjZWhvbGRlcihwaCwgY29udGV4dCkge1xuICAgICAgICByZXR1cm4gcGguaXNWb2lkID9cbiAgICAgICAgICAgIGA8cGggdGFnIG5hbWU9XCIke3BoLnN0YXJ0TmFtZX1cIi8+YCA6XG4gICAgICAgICAgICBgPHBoIHRhZyBuYW1lPVwiJHtwaC5zdGFydE5hbWV9XCI+JHtwaC5jaGlsZHJlbi5tYXAoY2hpbGQgPT4gY2hpbGQudmlzaXQodGhpcykpLmpvaW4oJywgJyl9PC9waCBuYW1lPVwiJHtwaC5jbG9zZU5hbWV9XCI+YDtcbiAgICB9XG4gICAgdmlzaXRQbGFjZWhvbGRlcihwaCwgY29udGV4dCkge1xuICAgICAgICByZXR1cm4gcGgudmFsdWUgPyBgPHBoIG5hbWU9XCIke3BoLm5hbWV9XCI+JHtwaC52YWx1ZX08L3BoPmAgOiBgPHBoIG5hbWU9XCIke3BoLm5hbWV9XCIvPmA7XG4gICAgfVxuICAgIHZpc2l0SWN1UGxhY2Vob2xkZXIocGgsIGNvbnRleHQpIHtcbiAgICAgICAgcmV0dXJuIGA8cGggaWN1IG5hbWU9XCIke3BoLm5hbWV9XCI+JHtwaC52YWx1ZS52aXNpdCh0aGlzKX08L3BoPmA7XG4gICAgfVxuICAgIHZpc2l0QmxvY2tQbGFjZWhvbGRlcihwaCwgY29udGV4dCkge1xuICAgICAgICByZXR1cm4gYDxwaCBibG9jayBuYW1lPVwiJHtwaC5zdGFydE5hbWV9XCI+JHtwaC5jaGlsZHJlbi5tYXAoY2hpbGQgPT4gY2hpbGQudmlzaXQodGhpcykpLmpvaW4oJywgJyl9PC9waCBuYW1lPVwiJHtwaC5jbG9zZU5hbWV9XCI+YDtcbiAgICB9XG59XG5jb25zdCBzZXJpYWxpemVyVmlzaXRvciA9IG5ldyBfU2VyaWFsaXplclZpc2l0b3IoKTtcbmZ1bmN0aW9uIHNlcmlhbGl6ZU5vZGVzKG5vZGVzKSB7XG4gICAgcmV0dXJuIG5vZGVzLm1hcChhID0+IGEudmlzaXQoc2VyaWFsaXplclZpc2l0b3IsIG51bGwpKTtcbn1cbi8qKlxuICogU2VyaWFsaXplIHRoZSBpMThuIGFzdCB0byBzb21ldGhpbmcgeG1sLWxpa2UgaW4gb3JkZXIgdG8gZ2VuZXJhdGUgYW4gVUlELlxuICpcbiAqIElnbm9yZSB0aGUgSUNVIGV4cHJlc3Npb25zIHNvIHRoYXQgbWVzc2FnZSBJRHMgc3RheXMgaWRlbnRpY2FsIGlmIG9ubHkgdGhlIGV4cHJlc3Npb24gY2hhbmdlcy5cbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuY2xhc3MgX1NlcmlhbGl6ZXJJZ25vcmVJY3VFeHBWaXNpdG9yIGV4dGVuZHMgX1NlcmlhbGl6ZXJWaXNpdG9yIHtcbiAgICB2aXNpdEljdShpY3UsIGNvbnRleHQpIHtcbiAgICAgICAgbGV0IHN0ckNhc2VzID0gT2JqZWN0LmtleXMoaWN1LmNhc2VzKS5tYXAoKGspID0+IGAke2t9IHske2ljdS5jYXNlc1trXS52aXNpdCh0aGlzKX19YCk7XG4gICAgICAgIC8vIERvIG5vdCB0YWtlIHRoZSBleHByZXNzaW9uIGludG8gYWNjb3VudFxuICAgICAgICByZXR1cm4gYHske2ljdS50eXBlfSwgJHtzdHJDYXNlcy5qb2luKCcsICcpfX1gO1xuICAgIH1cbn1cbi8qKlxuICogQ29tcHV0ZSB0aGUgU0hBMSBvZiB0aGUgZ2l2ZW4gc3RyaW5nXG4gKlxuICogc2VlIGh0dHBzOi8vY3NyYy5uaXN0Lmdvdi9wdWJsaWNhdGlvbnMvZmlwcy9maXBzMTgwLTQvZmlwcy0xODAtNC5wZGZcbiAqXG4gKiBXQVJOSU5HOiB0aGlzIGZ1bmN0aW9uIGhhcyBub3QgYmVlbiBkZXNpZ25lZCBub3QgdGVzdGVkIHdpdGggc2VjdXJpdHkgaW4gbWluZC5cbiAqICAgICAgICAgIERPIE5PVCBVU0UgSVQgSU4gQSBTRUNVUklUWSBTRU5TSVRJVkUgQ09OVEVYVC5cbiAqL1xuZnVuY3Rpb24gc2hhMShzdHIpIHtcbiAgICB0ZXh0RW5jb2RlciA/Pz0gbmV3IFRleHRFbmNvZGVyKCk7XG4gICAgY29uc3QgdXRmOCA9IFsuLi50ZXh0RW5jb2Rlci5lbmNvZGUoc3RyKV07XG4gICAgY29uc3Qgd29yZHMzMiA9IGJ5dGVzVG9Xb3JkczMyKHV0ZjgsIEVuZGlhbi5CaWcpO1xuICAgIGNvbnN0IGxlbiA9IHV0ZjgubGVuZ3RoICogODtcbiAgICBjb25zdCB3ID0gbmV3IFVpbnQzMkFycmF5KDgwKTtcbiAgICBsZXQgYSA9IDB4Njc0NTIzMDEsIGIgPSAweGVmY2RhYjg5LCBjID0gMHg5OGJhZGNmZSwgZCA9IDB4MTAzMjU0NzYsIGUgPSAweGMzZDJlMWYwO1xuICAgIHdvcmRzMzJbbGVuID4+IDVdIHw9IDB4ODAgPDwgKDI0IC0gbGVuICUgMzIpO1xuICAgIHdvcmRzMzJbKChsZW4gKyA2NCA+PiA5KSA8PCA0KSArIDE1XSA9IGxlbjtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHdvcmRzMzIubGVuZ3RoOyBpICs9IDE2KSB7XG4gICAgICAgIGNvbnN0IGgwID0gYSwgaDEgPSBiLCBoMiA9IGMsIGgzID0gZCwgaDQgPSBlO1xuICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IDgwOyBqKyspIHtcbiAgICAgICAgICAgIGlmIChqIDwgMTYpIHtcbiAgICAgICAgICAgICAgICB3W2pdID0gd29yZHMzMltpICsgal07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB3W2pdID0gcm9sMzIod1tqIC0gM10gXiB3W2ogLSA4XSBeIHdbaiAtIDE0XSBeIHdbaiAtIDE2XSwgMSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBma1ZhbCA9IGZrKGosIGIsIGMsIGQpO1xuICAgICAgICAgICAgY29uc3QgZiA9IGZrVmFsWzBdO1xuICAgICAgICAgICAgY29uc3QgayA9IGZrVmFsWzFdO1xuICAgICAgICAgICAgY29uc3QgdGVtcCA9IFtyb2wzMihhLCA1KSwgZiwgZSwgaywgd1tqXV0ucmVkdWNlKGFkZDMyKTtcbiAgICAgICAgICAgIGUgPSBkO1xuICAgICAgICAgICAgZCA9IGM7XG4gICAgICAgICAgICBjID0gcm9sMzIoYiwgMzApO1xuICAgICAgICAgICAgYiA9IGE7XG4gICAgICAgICAgICBhID0gdGVtcDtcbiAgICAgICAgfVxuICAgICAgICBhID0gYWRkMzIoYSwgaDApO1xuICAgICAgICBiID0gYWRkMzIoYiwgaDEpO1xuICAgICAgICBjID0gYWRkMzIoYywgaDIpO1xuICAgICAgICBkID0gYWRkMzIoZCwgaDMpO1xuICAgICAgICBlID0gYWRkMzIoZSwgaDQpO1xuICAgIH1cbiAgICAvLyBDb252ZXJ0IHRoZSBvdXRwdXQgcGFydHMgdG8gYSAxNjAtYml0IGhleGFkZWNpbWFsIHN0cmluZ1xuICAgIHJldHVybiB0b0hleFUzMihhKSArIHRvSGV4VTMyKGIpICsgdG9IZXhVMzIoYykgKyB0b0hleFUzMihkKSArIHRvSGV4VTMyKGUpO1xufVxuLyoqXG4gKiBDb252ZXJ0IGFuZCBmb3JtYXQgYSBudW1iZXIgYXMgYSBzdHJpbmcgcmVwcmVzZW50aW5nIGEgMzItYml0IHVuc2lnbmVkIGhleGFkZWNpbWFsIG51bWJlci5cbiAqIEBwYXJhbSB2YWx1ZSBUaGUgdmFsdWUgdG8gZm9ybWF0IGFzIGEgc3RyaW5nLlxuICogQHJldHVybnMgQSBoZXhhZGVjaW1hbCBzdHJpbmcgcmVwcmVzZW50aW5nIHRoZSB2YWx1ZS5cbiAqL1xuZnVuY3Rpb24gdG9IZXhVMzIodmFsdWUpIHtcbiAgICAvLyB1bnNpZ25lZCByaWdodCBzaGlmdCBvZiB6ZXJvIGVuc3VyZXMgYW4gdW5zaWduZWQgMzItYml0IG51bWJlclxuICAgIHJldHVybiAodmFsdWUgPj4+IDApLnRvU3RyaW5nKDE2KS5wYWRTdGFydCg4LCAnMCcpO1xufVxuZnVuY3Rpb24gZmsoaW5kZXgsIGIsIGMsIGQpIHtcbiAgICBpZiAoaW5kZXggPCAyMCkge1xuICAgICAgICByZXR1cm4gWyhiICYgYykgfCAofmIgJiBkKSwgMHg1YTgyNzk5OV07XG4gICAgfVxuICAgIGlmIChpbmRleCA8IDQwKSB7XG4gICAgICAgIHJldHVybiBbYiBeIGMgXiBkLCAweDZlZDllYmExXTtcbiAgICB9XG4gICAgaWYgKGluZGV4IDwgNjApIHtcbiAgICAgICAgcmV0dXJuIFsoYiAmIGMpIHwgKGIgJiBkKSB8IChjICYgZCksIDB4OGYxYmJjZGNdO1xuICAgIH1cbiAgICByZXR1cm4gW2IgXiBjIF4gZCwgMHhjYTYyYzFkNl07XG59XG4vKipcbiAqIENvbXB1dGUgdGhlIGZpbmdlcnByaW50IG9mIHRoZSBnaXZlbiBzdHJpbmdcbiAqXG4gKiBUaGUgb3V0cHV0IGlzIDY0IGJpdCBudW1iZXIgZW5jb2RlZCBhcyBhIGRlY2ltYWwgc3RyaW5nXG4gKlxuICogYmFzZWQgb246XG4gKiBodHRwczovL2dpdGh1Yi5jb20vZ29vZ2xlL2Nsb3N1cmUtY29tcGlsZXIvYmxvYi9tYXN0ZXIvc3JjL2NvbS9nb29nbGUvamF2YXNjcmlwdC9qc2NvbXAvR29vZ2xlSnNNZXNzYWdlSWRHZW5lcmF0b3IuamF2YVxuICovXG5mdW5jdGlvbiBmaW5nZXJwcmludChzdHIpIHtcbiAgICB0ZXh0RW5jb2RlciA/Pz0gbmV3IFRleHRFbmNvZGVyKCk7XG4gICAgY29uc3QgdXRmOCA9IHRleHRFbmNvZGVyLmVuY29kZShzdHIpO1xuICAgIGNvbnN0IHZpZXcgPSBuZXcgRGF0YVZpZXcodXRmOC5idWZmZXIsIHV0ZjguYnl0ZU9mZnNldCwgdXRmOC5ieXRlTGVuZ3RoKTtcbiAgICBsZXQgaGkgPSBoYXNoMzIodmlldywgdXRmOC5sZW5ndGgsIDApO1xuICAgIGxldCBsbyA9IGhhc2gzMih2aWV3LCB1dGY4Lmxlbmd0aCwgMTAyMDcyKTtcbiAgICBpZiAoaGkgPT0gMCAmJiAobG8gPT0gMCB8fCBsbyA9PSAxKSkge1xuICAgICAgICBoaSA9IGhpIF4gMHgxMzBmOWJlZjtcbiAgICAgICAgbG8gPSBsbyBeIC0weDZiNWY1NmQ4O1xuICAgIH1cbiAgICByZXR1cm4gKEJpZ0ludC5hc1VpbnROKDMyLCBCaWdJbnQoaGkpKSA8PCBCaWdJbnQoMzIpKSB8IEJpZ0ludC5hc1VpbnROKDMyLCBCaWdJbnQobG8pKTtcbn1cbmZ1bmN0aW9uIGNvbXB1dGVNc2dJZChtc2csIG1lYW5pbmcgPSAnJykge1xuICAgIGxldCBtc2dGaW5nZXJwcmludCA9IGZpbmdlcnByaW50KG1zZyk7XG4gICAgaWYgKG1lYW5pbmcpIHtcbiAgICAgICAgLy8gUm90YXRlIHRoZSA2NC1iaXQgbWVzc2FnZSBmaW5nZXJwcmludCBvbmUgYml0IHRvIHRoZSBsZWZ0IGFuZCB0aGVuIGFkZCB0aGUgbWVhbmluZ1xuICAgICAgICAvLyBmaW5nZXJwcmludC5cbiAgICAgICAgbXNnRmluZ2VycHJpbnQgPSBCaWdJbnQuYXNVaW50Tig2NCwgbXNnRmluZ2VycHJpbnQgPDwgQmlnSW50KDEpKSB8XG4gICAgICAgICAgICAoKG1zZ0ZpbmdlcnByaW50ID4+IEJpZ0ludCg2MykpICYgQmlnSW50KDEpKTtcbiAgICAgICAgbXNnRmluZ2VycHJpbnQgKz0gZmluZ2VycHJpbnQobWVhbmluZyk7XG4gICAgfVxuICAgIHJldHVybiBCaWdJbnQuYXNVaW50Tig2MywgbXNnRmluZ2VycHJpbnQpLnRvU3RyaW5nKCk7XG59XG5mdW5jdGlvbiBoYXNoMzIodmlldywgbGVuZ3RoLCBjKSB7XG4gICAgbGV0IGEgPSAweDllMzc3OWI5LCBiID0gMHg5ZTM3NzliOTtcbiAgICBsZXQgaW5kZXggPSAwO1xuICAgIGNvbnN0IGVuZCA9IGxlbmd0aCAtIDEyO1xuICAgIGZvciAoOyBpbmRleCA8PSBlbmQ7IGluZGV4ICs9IDEyKSB7XG4gICAgICAgIGEgKz0gdmlldy5nZXRVaW50MzIoaW5kZXgsIHRydWUpO1xuICAgICAgICBiICs9IHZpZXcuZ2V0VWludDMyKGluZGV4ICsgNCwgdHJ1ZSk7XG4gICAgICAgIGMgKz0gdmlldy5nZXRVaW50MzIoaW5kZXggKyA4LCB0cnVlKTtcbiAgICAgICAgY29uc3QgcmVzID0gbWl4KGEsIGIsIGMpO1xuICAgICAgICBhID0gcmVzWzBdLCBiID0gcmVzWzFdLCBjID0gcmVzWzJdO1xuICAgIH1cbiAgICBjb25zdCByZW1haW5kZXIgPSBsZW5ndGggLSBpbmRleDtcbiAgICAvLyB0aGUgZmlyc3QgYnl0ZSBvZiBjIGlzIHJlc2VydmVkIGZvciB0aGUgbGVuZ3RoXG4gICAgYyArPSBsZW5ndGg7XG4gICAgaWYgKHJlbWFpbmRlciA+PSA0KSB7XG4gICAgICAgIGEgKz0gdmlldy5nZXRVaW50MzIoaW5kZXgsIHRydWUpO1xuICAgICAgICBpbmRleCArPSA0O1xuICAgICAgICBpZiAocmVtYWluZGVyID49IDgpIHtcbiAgICAgICAgICAgIGIgKz0gdmlldy5nZXRVaW50MzIoaW5kZXgsIHRydWUpO1xuICAgICAgICAgICAgaW5kZXggKz0gNDtcbiAgICAgICAgICAgIC8vIFBhcnRpYWwgMzItYml0IHdvcmQgZm9yIGNcbiAgICAgICAgICAgIGlmIChyZW1haW5kZXIgPj0gOSkge1xuICAgICAgICAgICAgICAgIGMgKz0gdmlldy5nZXRVaW50OChpbmRleCsrKSA8PCA4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHJlbWFpbmRlciA+PSAxMCkge1xuICAgICAgICAgICAgICAgIGMgKz0gdmlldy5nZXRVaW50OChpbmRleCsrKSA8PCAxNjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyZW1haW5kZXIgPT09IDExKSB7XG4gICAgICAgICAgICAgICAgYyArPSB2aWV3LmdldFVpbnQ4KGluZGV4KyspIDw8IDI0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgLy8gUGFydGlhbCAzMi1iaXQgd29yZCBmb3IgYlxuICAgICAgICAgICAgaWYgKHJlbWFpbmRlciA+PSA1KSB7XG4gICAgICAgICAgICAgICAgYiArPSB2aWV3LmdldFVpbnQ4KGluZGV4KyspO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHJlbWFpbmRlciA+PSA2KSB7XG4gICAgICAgICAgICAgICAgYiArPSB2aWV3LmdldFVpbnQ4KGluZGV4KyspIDw8IDg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocmVtYWluZGVyID09PSA3KSB7XG4gICAgICAgICAgICAgICAgYiArPSB2aWV3LmdldFVpbnQ4KGluZGV4KyspIDw8IDE2O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICAvLyBQYXJ0aWFsIDMyLWJpdCB3b3JkIGZvciBhXG4gICAgICAgIGlmIChyZW1haW5kZXIgPj0gMSkge1xuICAgICAgICAgICAgYSArPSB2aWV3LmdldFVpbnQ4KGluZGV4KyspO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZW1haW5kZXIgPj0gMikge1xuICAgICAgICAgICAgYSArPSB2aWV3LmdldFVpbnQ4KGluZGV4KyspIDw8IDg7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlbWFpbmRlciA9PT0gMykge1xuICAgICAgICAgICAgYSArPSB2aWV3LmdldFVpbnQ4KGluZGV4KyspIDw8IDE2O1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBtaXgoYSwgYiwgYylbMl07XG59XG4vLyBjbGFuZy1mb3JtYXQgb2ZmXG5mdW5jdGlvbiBtaXgoYSwgYiwgYykge1xuICAgIGEgLT0gYjtcbiAgICBhIC09IGM7XG4gICAgYSBePSBjID4+PiAxMztcbiAgICBiIC09IGM7XG4gICAgYiAtPSBhO1xuICAgIGIgXj0gYSA8PCA4O1xuICAgIGMgLT0gYTtcbiAgICBjIC09IGI7XG4gICAgYyBePSBiID4+PiAxMztcbiAgICBhIC09IGI7XG4gICAgYSAtPSBjO1xuICAgIGEgXj0gYyA+Pj4gMTI7XG4gICAgYiAtPSBjO1xuICAgIGIgLT0gYTtcbiAgICBiIF49IGEgPDwgMTY7XG4gICAgYyAtPSBhO1xuICAgIGMgLT0gYjtcbiAgICBjIF49IGIgPj4+IDU7XG4gICAgYSAtPSBiO1xuICAgIGEgLT0gYztcbiAgICBhIF49IGMgPj4+IDM7XG4gICAgYiAtPSBjO1xuICAgIGIgLT0gYTtcbiAgICBiIF49IGEgPDwgMTA7XG4gICAgYyAtPSBhO1xuICAgIGMgLT0gYjtcbiAgICBjIF49IGIgPj4+IDE1O1xuICAgIHJldHVybiBbYSwgYiwgY107XG59XG4vLyBjbGFuZy1mb3JtYXQgb25cbi8vIFV0aWxzXG52YXIgRW5kaWFuO1xuKGZ1bmN0aW9uIChFbmRpYW4pIHtcbiAgICBFbmRpYW5bRW5kaWFuW1wiTGl0dGxlXCJdID0gMF0gPSBcIkxpdHRsZVwiO1xuICAgIEVuZGlhbltFbmRpYW5bXCJCaWdcIl0gPSAxXSA9IFwiQmlnXCI7XG59KShFbmRpYW4gfHwgKEVuZGlhbiA9IHt9KSk7XG5mdW5jdGlvbiBhZGQzMihhLCBiKSB7XG4gICAgcmV0dXJuIGFkZDMydG82NChhLCBiKVsxXTtcbn1cbmZ1bmN0aW9uIGFkZDMydG82NChhLCBiKSB7XG4gICAgY29uc3QgbG93ID0gKGEgJiAweGZmZmYpICsgKGIgJiAweGZmZmYpO1xuICAgIGNvbnN0IGhpZ2ggPSAoYSA+Pj4gMTYpICsgKGIgPj4+IDE2KSArIChsb3cgPj4+IDE2KTtcbiAgICByZXR1cm4gW2hpZ2ggPj4+IDE2LCAoaGlnaCA8PCAxNikgfCAobG93ICYgMHhmZmZmKV07XG59XG4vLyBSb3RhdGUgYSAzMmIgbnVtYmVyIGxlZnQgYGNvdW50YCBwb3NpdGlvblxuZnVuY3Rpb24gcm9sMzIoYSwgY291bnQpIHtcbiAgICByZXR1cm4gKGEgPDwgY291bnQpIHwgKGEgPj4+ICgzMiAtIGNvdW50KSk7XG59XG5mdW5jdGlvbiBieXRlc1RvV29yZHMzMihieXRlcywgZW5kaWFuKSB7XG4gICAgY29uc3Qgc2l6ZSA9IChieXRlcy5sZW5ndGggKyAzKSA+Pj4gMjtcbiAgICBjb25zdCB3b3JkczMyID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzaXplOyBpKyspIHtcbiAgICAgICAgd29yZHMzMltpXSA9IHdvcmRBdChieXRlcywgaSAqIDQsIGVuZGlhbik7XG4gICAgfVxuICAgIHJldHVybiB3b3JkczMyO1xufVxuZnVuY3Rpb24gYnl0ZUF0KGJ5dGVzLCBpbmRleCkge1xuICAgIHJldHVybiBpbmRleCA+PSBieXRlcy5sZW5ndGggPyAwIDogYnl0ZXNbaW5kZXhdO1xufVxuZnVuY3Rpb24gd29yZEF0KGJ5dGVzLCBpbmRleCwgZW5kaWFuKSB7XG4gICAgbGV0IHdvcmQgPSAwO1xuICAgIGlmIChlbmRpYW4gPT09IEVuZGlhbi5CaWcpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA0OyBpKyspIHtcbiAgICAgICAgICAgIHdvcmQgKz0gYnl0ZUF0KGJ5dGVzLCBpbmRleCArIGkpIDw8ICgyNCAtIDggKiBpKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA0OyBpKyspIHtcbiAgICAgICAgICAgIHdvcmQgKz0gYnl0ZUF0KGJ5dGVzLCBpbmRleCArIGkpIDw8IDggKiBpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB3b3JkO1xufVxuXG4vLyBUaGlzIG1vZHVsZSBzcGVjaWZpZXIgaXMgaW50ZW50aW9uYWxseSBhIHJlbGF0aXZlIHBhdGggdG8gYWxsb3cgYnVuZGxpbmcgdGhlIGNvZGUgZGlyZWN0bHlcbi8qKlxuICogUGFyc2UgYSBgJGxvY2FsaXplYCB0YWdnZWQgc3RyaW5nIGludG8gYSBzdHJ1Y3R1cmUgdGhhdCBjYW4gYmUgdXNlZCBmb3IgdHJhbnNsYXRpb24gb3JcbiAqIGV4dHJhY3Rpb24uXG4gKlxuICogU2VlIGBQYXJzZWRNZXNzYWdlYCBmb3IgYW4gZXhhbXBsZS5cbiAqL1xuZnVuY3Rpb24gcGFyc2VNZXNzYWdlKG1lc3NhZ2VQYXJ0cywgZXhwcmVzc2lvbnMsIGxvY2F0aW9uLCBtZXNzYWdlUGFydExvY2F0aW9ucywgZXhwcmVzc2lvbkxvY2F0aW9ucyA9IFtdKSB7XG4gICAgY29uc3Qgc3Vic3RpdHV0aW9ucyA9IHt9O1xuICAgIGNvbnN0IHN1YnN0aXR1dGlvbkxvY2F0aW9ucyA9IHt9O1xuICAgIGNvbnN0IGFzc29jaWF0ZWRNZXNzYWdlSWRzID0ge307XG4gICAgY29uc3QgbWV0YWRhdGEgPSBwYXJzZU1ldGFkYXRhKG1lc3NhZ2VQYXJ0c1swXSwgbWVzc2FnZVBhcnRzLnJhd1swXSk7XG4gICAgY29uc3QgY2xlYW5lZE1lc3NhZ2VQYXJ0cyA9IFttZXRhZGF0YS50ZXh0XTtcbiAgICBjb25zdCBwbGFjZWhvbGRlck5hbWVzID0gW107XG4gICAgbGV0IG1lc3NhZ2VTdHJpbmcgPSBtZXRhZGF0YS50ZXh0O1xuICAgIGZvciAobGV0IGkgPSAxOyBpIDwgbWVzc2FnZVBhcnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IHsgbWVzc2FnZVBhcnQsIHBsYWNlaG9sZGVyTmFtZSA9IGNvbXB1dGVQbGFjZWhvbGRlck5hbWUoaSksIGFzc29jaWF0ZWRNZXNzYWdlSWQgfSA9IHBhcnNlUGxhY2Vob2xkZXIobWVzc2FnZVBhcnRzW2ldLCBtZXNzYWdlUGFydHMucmF3W2ldKTtcbiAgICAgICAgbWVzc2FnZVN0cmluZyArPSBgeyQke3BsYWNlaG9sZGVyTmFtZX19JHttZXNzYWdlUGFydH1gO1xuICAgICAgICBpZiAoZXhwcmVzc2lvbnMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgc3Vic3RpdHV0aW9uc1twbGFjZWhvbGRlck5hbWVdID0gZXhwcmVzc2lvbnNbaSAtIDFdO1xuICAgICAgICAgICAgc3Vic3RpdHV0aW9uTG9jYXRpb25zW3BsYWNlaG9sZGVyTmFtZV0gPSBleHByZXNzaW9uTG9jYXRpb25zW2kgLSAxXTtcbiAgICAgICAgfVxuICAgICAgICBwbGFjZWhvbGRlck5hbWVzLnB1c2gocGxhY2Vob2xkZXJOYW1lKTtcbiAgICAgICAgaWYgKGFzc29jaWF0ZWRNZXNzYWdlSWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgYXNzb2NpYXRlZE1lc3NhZ2VJZHNbcGxhY2Vob2xkZXJOYW1lXSA9IGFzc29jaWF0ZWRNZXNzYWdlSWQ7XG4gICAgICAgIH1cbiAgICAgICAgY2xlYW5lZE1lc3NhZ2VQYXJ0cy5wdXNoKG1lc3NhZ2VQYXJ0KTtcbiAgICB9XG4gICAgY29uc3QgbWVzc2FnZUlkID0gbWV0YWRhdGEuY3VzdG9tSWQgfHwgY29tcHV0ZU1zZ0lkKG1lc3NhZ2VTdHJpbmcsIG1ldGFkYXRhLm1lYW5pbmcgfHwgJycpO1xuICAgIGNvbnN0IGxlZ2FjeUlkcyA9IG1ldGFkYXRhLmxlZ2FjeUlkcyA/IG1ldGFkYXRhLmxlZ2FjeUlkcy5maWx0ZXIoaWQgPT4gaWQgIT09IG1lc3NhZ2VJZCkgOiBbXTtcbiAgICByZXR1cm4ge1xuICAgICAgICBpZDogbWVzc2FnZUlkLFxuICAgICAgICBsZWdhY3lJZHMsXG4gICAgICAgIHN1YnN0aXR1dGlvbnMsXG4gICAgICAgIHN1YnN0aXR1dGlvbkxvY2F0aW9ucyxcbiAgICAgICAgdGV4dDogbWVzc2FnZVN0cmluZyxcbiAgICAgICAgY3VzdG9tSWQ6IG1ldGFkYXRhLmN1c3RvbUlkLFxuICAgICAgICBtZWFuaW5nOiBtZXRhZGF0YS5tZWFuaW5nIHx8ICcnLFxuICAgICAgICBkZXNjcmlwdGlvbjogbWV0YWRhdGEuZGVzY3JpcHRpb24gfHwgJycsXG4gICAgICAgIG1lc3NhZ2VQYXJ0czogY2xlYW5lZE1lc3NhZ2VQYXJ0cyxcbiAgICAgICAgbWVzc2FnZVBhcnRMb2NhdGlvbnMsXG4gICAgICAgIHBsYWNlaG9sZGVyTmFtZXMsXG4gICAgICAgIGFzc29jaWF0ZWRNZXNzYWdlSWRzLFxuICAgICAgICBsb2NhdGlvbixcbiAgICB9O1xufVxuLyoqXG4gKiBQYXJzZSB0aGUgZ2l2ZW4gbWVzc2FnZSBwYXJ0IChgY29va2VkYCArIGByYXdgKSB0byBleHRyYWN0IHRoZSBtZXNzYWdlIG1ldGFkYXRhIGZyb20gdGhlIHRleHQuXG4gKlxuICogSWYgdGhlIG1lc3NhZ2UgcGFydCBoYXMgYSBtZXRhZGF0YSBibG9jayB0aGlzIGZ1bmN0aW9uIHdpbGwgZXh0cmFjdCB0aGUgYG1lYW5pbmdgLFxuICogYGRlc2NyaXB0aW9uYCwgYGN1c3RvbUlkYCBhbmQgYGxlZ2FjeUlkYCAoaWYgcHJvdmlkZWQpIGZyb20gdGhlIGJsb2NrLiBUaGVzZSBtZXRhZGF0YSBwcm9wZXJ0aWVzXG4gKiBhcmUgc2VyaWFsaXplZCBpbiB0aGUgc3RyaW5nIGRlbGltaXRlZCBieSBgfGAsIGBAQGAgYW5kIGDikJ9gIHJlc3BlY3RpdmVseS5cbiAqXG4gKiAoTm90ZSB0aGF0IGDikJ9gIGlzIHRoZSBgTEVHQUNZX0lEX0lORElDQVRPUmAgLSBzZWUgYGNvbnN0YW50cy50c2AuKVxuICpcbiAqIEZvciBleGFtcGxlOlxuICpcbiAqIGBgYHRzXG4gKiBgOm1lYW5pbmd8ZGVzY3JpcHRpb25AQGN1c3RvbS1pZDpgXG4gKiBgOm1lYW5pbmd8QEBjdXN0b20taWQ6YFxuICogYDptZWFuaW5nfGRlc2NyaXB0aW9uOmBcbiAqIGA6ZGVzY3JpcHRpb25AQGN1c3RvbS1pZDpgXG4gKiBgOm1lYW5pbmd8OmBcbiAqIGA6ZGVzY3JpcHRpb246YFxuICogYDpAQGN1c3RvbS1pZDpgXG4gKiBgOm1lYW5pbmd8ZGVzY3JpcHRpb25AQGN1c3RvbS1pZOKQn2xlZ2FjeS1pZC0x4pCfbGVnYWN5LWlkLTI6YFxuICogYGBgXG4gKlxuICogQHBhcmFtIGNvb2tlZCBUaGUgY29va2VkIHZlcnNpb24gb2YgdGhlIG1lc3NhZ2UgcGFydCB0byBwYXJzZS5cbiAqIEBwYXJhbSByYXcgVGhlIHJhdyB2ZXJzaW9uIG9mIHRoZSBtZXNzYWdlIHBhcnQgdG8gcGFyc2UuXG4gKiBAcmV0dXJucyBBIG9iamVjdCBjb250YWluaW5nIGFueSBtZXRhZGF0YSB0aGF0IHdhcyBwYXJzZWQgZnJvbSB0aGUgbWVzc2FnZSBwYXJ0LlxuICovXG5mdW5jdGlvbiBwYXJzZU1ldGFkYXRhKGNvb2tlZCwgcmF3KSB7XG4gICAgY29uc3QgeyB0ZXh0OiBtZXNzYWdlU3RyaW5nLCBibG9jayB9ID0gc3BsaXRCbG9jayhjb29rZWQsIHJhdyk7XG4gICAgaWYgKGJsb2NrID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuIHsgdGV4dDogbWVzc2FnZVN0cmluZyB9O1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc3QgW21lYW5pbmdEZXNjQW5kSWQsIC4uLmxlZ2FjeUlkc10gPSBibG9jay5zcGxpdChMRUdBQ1lfSURfSU5ESUNBVE9SKTtcbiAgICAgICAgY29uc3QgW21lYW5pbmdBbmREZXNjLCBjdXN0b21JZF0gPSBtZWFuaW5nRGVzY0FuZElkLnNwbGl0KElEX1NFUEFSQVRPUiwgMik7XG4gICAgICAgIGxldCBbbWVhbmluZywgZGVzY3JpcHRpb25dID0gbWVhbmluZ0FuZERlc2Muc3BsaXQoTUVBTklOR19TRVBBUkFUT1IsIDIpO1xuICAgICAgICBpZiAoZGVzY3JpcHRpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgZGVzY3JpcHRpb24gPSBtZWFuaW5nO1xuICAgICAgICAgICAgbWVhbmluZyA9IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZGVzY3JpcHRpb24gPT09ICcnKSB7XG4gICAgICAgICAgICBkZXNjcmlwdGlvbiA9IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4geyB0ZXh0OiBtZXNzYWdlU3RyaW5nLCBtZWFuaW5nLCBkZXNjcmlwdGlvbiwgY3VzdG9tSWQsIGxlZ2FjeUlkcyB9O1xuICAgIH1cbn1cbi8qKlxuICogUGFyc2UgdGhlIGdpdmVuIG1lc3NhZ2UgcGFydCAoYGNvb2tlZGAgKyBgcmF3YCkgdG8gZXh0cmFjdCBhbnkgcGxhY2Vob2xkZXIgbWV0YWRhdGEgZnJvbSB0aGVcbiAqIHRleHQuXG4gKlxuICogSWYgdGhlIG1lc3NhZ2UgcGFydCBoYXMgYSBtZXRhZGF0YSBibG9jayB0aGlzIGZ1bmN0aW9uIHdpbGwgZXh0cmFjdCB0aGUgYHBsYWNlaG9sZGVyTmFtZWAgYW5kXG4gKiBgYXNzb2NpYXRlZE1lc3NhZ2VJZGAgKGlmIHByb3ZpZGVkKSBmcm9tIHRoZSBibG9jay5cbiAqXG4gKiBUaGVzZSBtZXRhZGF0YSBwcm9wZXJ0aWVzIGFyZSBzZXJpYWxpemVkIGluIHRoZSBzdHJpbmcgZGVsaW1pdGVkIGJ5IGBAQGAuXG4gKlxuICogRm9yIGV4YW1wbGU6XG4gKlxuICogYGBgdHNcbiAqIGA6cGxhY2Vob2xkZXItbmFtZUBAYXNzb2NpYXRlZC1pZDpgXG4gKiBgYGBcbiAqXG4gKiBAcGFyYW0gY29va2VkIFRoZSBjb29rZWQgdmVyc2lvbiBvZiB0aGUgbWVzc2FnZSBwYXJ0IHRvIHBhcnNlLlxuICogQHBhcmFtIHJhdyBUaGUgcmF3IHZlcnNpb24gb2YgdGhlIG1lc3NhZ2UgcGFydCB0byBwYXJzZS5cbiAqIEByZXR1cm5zIEEgb2JqZWN0IGNvbnRhaW5pbmcgdGhlIG1ldGFkYXRhIChgcGxhY2Vob2xkZXJOYW1lYCBhbmQgYGFzc29jaWF0ZWRNZXNzYWdlSWRgKSBvZiB0aGVcbiAqICAgICBwcmVjZWRpbmcgcGxhY2Vob2xkZXIsIGFsb25nIHdpdGggdGhlIHN0YXRpYyB0ZXh0IHRoYXQgZm9sbG93cy5cbiAqL1xuZnVuY3Rpb24gcGFyc2VQbGFjZWhvbGRlcihjb29rZWQsIHJhdykge1xuICAgIGNvbnN0IHsgdGV4dDogbWVzc2FnZVBhcnQsIGJsb2NrIH0gPSBzcGxpdEJsb2NrKGNvb2tlZCwgcmF3KTtcbiAgICBpZiAoYmxvY2sgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4geyBtZXNzYWdlUGFydCB9O1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc3QgW3BsYWNlaG9sZGVyTmFtZSwgYXNzb2NpYXRlZE1lc3NhZ2VJZF0gPSBibG9jay5zcGxpdChJRF9TRVBBUkFUT1IpO1xuICAgICAgICByZXR1cm4geyBtZXNzYWdlUGFydCwgcGxhY2Vob2xkZXJOYW1lLCBhc3NvY2lhdGVkTWVzc2FnZUlkIH07XG4gICAgfVxufVxuLyoqXG4gKiBTcGxpdCBhIG1lc3NhZ2UgcGFydCAoYGNvb2tlZGAgKyBgcmF3YCkgaW50byBhbiBvcHRpb25hbCBkZWxpbWl0ZWQgXCJibG9ja1wiIG9mZiB0aGUgZnJvbnQgYW5kIHRoZVxuICogcmVzdCBvZiB0aGUgdGV4dCBvZiB0aGUgbWVzc2FnZSBwYXJ0LlxuICpcbiAqIEJsb2NrcyBhcHBlYXIgYXQgdGhlIHN0YXJ0IG9mIG1lc3NhZ2UgcGFydHMuIFRoZXkgYXJlIGRlbGltaXRlZCBieSBhIGNvbG9uIGA6YCBjaGFyYWN0ZXIgYXQgdGhlXG4gKiBzdGFydCBhbmQgZW5kIG9mIHRoZSBibG9jay5cbiAqXG4gKiBJZiB0aGUgYmxvY2sgaXMgaW4gdGhlIGZpcnN0IG1lc3NhZ2UgcGFydCB0aGVuIGl0IHdpbGwgYmUgbWV0YWRhdGEgYWJvdXQgdGhlIHdob2xlIG1lc3NhZ2U6XG4gKiBtZWFuaW5nLCBkZXNjcmlwdGlvbiwgaWQuICBPdGhlcndpc2UgaXQgd2lsbCBiZSBtZXRhZGF0YSBhYm91dCB0aGUgaW1tZWRpYXRlbHkgcHJlY2VkaW5nXG4gKiBzdWJzdGl0dXRpb246IHBsYWNlaG9sZGVyIG5hbWUuXG4gKlxuICogU2luY2UgYmxvY2tzIGFyZSBvcHRpb25hbCwgaXQgaXMgcG9zc2libGUgdGhhdCB0aGUgY29udGVudCBvZiBhIG1lc3NhZ2UgYmxvY2sgYWN0dWFsbHkgc3RhcnRzXG4gKiB3aXRoIGEgYmxvY2sgbWFya2VyLiBJbiB0aGlzIGNhc2UgdGhlIG1hcmtlciBtdXN0IGJlIGVzY2FwZWQgYFxcOmAuXG4gKlxuICogQHBhcmFtIGNvb2tlZCBUaGUgY29va2VkIHZlcnNpb24gb2YgdGhlIG1lc3NhZ2UgcGFydCB0byBwYXJzZS5cbiAqIEBwYXJhbSByYXcgVGhlIHJhdyB2ZXJzaW9uIG9mIHRoZSBtZXNzYWdlIHBhcnQgdG8gcGFyc2UuXG4gKiBAcmV0dXJucyBBbiBvYmplY3QgY29udGFpbmluZyB0aGUgYHRleHRgIG9mIHRoZSBtZXNzYWdlIHBhcnQgYW5kIHRoZSB0ZXh0IG9mIHRoZSBgYmxvY2tgLCBpZiBpdFxuICogZXhpc3RzLlxuICogQHRocm93cyBhbiBlcnJvciBpZiB0aGUgYGJsb2NrYCBpcyB1bnRlcm1pbmF0ZWRcbiAqL1xuZnVuY3Rpb24gc3BsaXRCbG9jayhjb29rZWQsIHJhdykge1xuICAgIGlmIChyYXcuY2hhckF0KDApICE9PSBCTE9DS19NQVJLRVIkMSkge1xuICAgICAgICByZXR1cm4geyB0ZXh0OiBjb29rZWQgfTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnN0IGVuZE9mQmxvY2sgPSBmaW5kRW5kT2ZCbG9jayhjb29rZWQsIHJhdyk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBibG9jazogY29va2VkLnN1YnN0cmluZygxLCBlbmRPZkJsb2NrKSxcbiAgICAgICAgICAgIHRleHQ6IGNvb2tlZC5zdWJzdHJpbmcoZW5kT2ZCbG9jayArIDEpLFxuICAgICAgICB9O1xuICAgIH1cbn1cbmZ1bmN0aW9uIGNvbXB1dGVQbGFjZWhvbGRlck5hbWUoaW5kZXgpIHtcbiAgICByZXR1cm4gaW5kZXggPT09IDEgPyAnUEgnIDogYFBIXyR7aW5kZXggLSAxfWA7XG59XG4vKipcbiAqIEZpbmQgdGhlIGVuZCBvZiBhIFwibWFya2VkIGJsb2NrXCIgaW5kaWNhdGVkIGJ5IHRoZSBmaXJzdCBub24tZXNjYXBlZCBjb2xvbi5cbiAqXG4gKiBAcGFyYW0gY29va2VkIFRoZSBjb29rZWQgc3RyaW5nICh3aGVyZSBlc2NhcGVkIGNoYXJzIGhhdmUgYmVlbiBwcm9jZXNzZWQpXG4gKiBAcGFyYW0gcmF3IFRoZSByYXcgc3RyaW5nICh3aGVyZSBlc2NhcGUgc2VxdWVuY2VzIGFyZSBzdGlsbCBpbiBwbGFjZSlcbiAqXG4gKiBAcmV0dXJucyB0aGUgaW5kZXggb2YgdGhlIGVuZCBvZiBibG9jayBtYXJrZXJcbiAqIEB0aHJvd3MgYW4gZXJyb3IgaWYgdGhlIGJsb2NrIGlzIHVudGVybWluYXRlZFxuICovXG5mdW5jdGlvbiBmaW5kRW5kT2ZCbG9jayhjb29rZWQsIHJhdykge1xuICAgIGZvciAobGV0IGNvb2tlZEluZGV4ID0gMSwgcmF3SW5kZXggPSAxOyBjb29rZWRJbmRleCA8IGNvb2tlZC5sZW5ndGg7IGNvb2tlZEluZGV4KyssIHJhd0luZGV4KyspIHtcbiAgICAgICAgaWYgKHJhd1tyYXdJbmRleF0gPT09ICdcXFxcJykge1xuICAgICAgICAgICAgcmF3SW5kZXgrKztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChjb29rZWRbY29va2VkSW5kZXhdID09PSBCTE9DS19NQVJLRVIkMSkge1xuICAgICAgICAgICAgcmV0dXJuIGNvb2tlZEluZGV4O1xuICAgICAgICB9XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcihgVW50ZXJtaW5hdGVkICRsb2NhbGl6ZSBtZXRhZGF0YSBibG9jayBpbiBcIiR7cmF3fVwiLmApO1xufVxuXG5jbGFzcyBNaXNzaW5nVHJhbnNsYXRpb25FcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcihwYXJzZWRNZXNzYWdlKSB7XG4gICAgICAgIHN1cGVyKGBObyB0cmFuc2xhdGlvbiBmb3VuZCBmb3IgJHtkZXNjcmliZU1lc3NhZ2UocGFyc2VkTWVzc2FnZSl9LmApO1xuICAgICAgICB0aGlzLnBhcnNlZE1lc3NhZ2UgPSBwYXJzZWRNZXNzYWdlO1xuICAgICAgICB0aGlzLnR5cGUgPSAnTWlzc2luZ1RyYW5zbGF0aW9uRXJyb3InO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGlzTWlzc2luZ1RyYW5zbGF0aW9uRXJyb3IoZSkge1xuICAgIHJldHVybiBlLnR5cGUgPT09ICdNaXNzaW5nVHJhbnNsYXRpb25FcnJvcic7XG59XG4vKipcbiAqIFRyYW5zbGF0ZSB0aGUgdGV4dCBvZiB0aGUgYCRsb2NhbGl6ZWAgdGFnZ2VkLXN0cmluZyAoaS5lLiBgbWVzc2FnZVBhcnRzYCBhbmRcbiAqIGBzdWJzdGl0dXRpb25zYCkgdXNpbmcgdGhlIGdpdmVuIGB0cmFuc2xhdGlvbnNgLlxuICpcbiAqIFRoZSB0YWdnZWQtc3RyaW5nIGlzIHBhcnNlZCB0byBleHRyYWN0IGl0cyBgbWVzc2FnZUlkYCB3aGljaCBpcyB1c2VkIHRvIGZpbmQgYW4gYXBwcm9wcmlhdGVcbiAqIGBQYXJzZWRUcmFuc2xhdGlvbmAuIElmIHRoaXMgZG9lc24ndCBtYXRjaCBhbmQgdGhlcmUgYXJlIGxlZ2FjeSBpZHMgdGhlbiB0cnkgbWF0Y2hpbmcgYVxuICogdHJhbnNsYXRpb24gdXNpbmcgdGhvc2UuXG4gKlxuICogSWYgb25lIGlzIGZvdW5kIHRoZW4gaXQgaXMgdXNlZCB0byB0cmFuc2xhdGUgdGhlIG1lc3NhZ2UgaW50byBhIG5ldyBzZXQgb2YgYG1lc3NhZ2VQYXJ0c2AgYW5kXG4gKiBgc3Vic3RpdHV0aW9uc2AuXG4gKiBUaGUgdHJhbnNsYXRpb24gbWF5IHJlb3JkZXIgKG9yIHJlbW92ZSkgc3Vic3RpdHV0aW9ucyBhcyBhcHByb3ByaWF0ZS5cbiAqXG4gKiBJZiB0aGVyZSBpcyBubyB0cmFuc2xhdGlvbiB3aXRoIGEgbWF0Y2hpbmcgbWVzc2FnZSBpZCB0aGVuIGFuIGVycm9yIGlzIHRocm93bi5cbiAqIElmIGEgdHJhbnNsYXRpb24gY29udGFpbnMgYSBwbGFjZWhvbGRlciB0aGF0IGlzIG5vdCBmb3VuZCBpbiB0aGUgbWVzc2FnZSBiZWluZyB0cmFuc2xhdGVkIHRoZW4gYW5cbiAqIGVycm9yIGlzIHRocm93bi5cbiAqL1xuZnVuY3Rpb24gdHJhbnNsYXRlJDEodHJhbnNsYXRpb25zLCBtZXNzYWdlUGFydHMsIHN1YnN0aXR1dGlvbnMpIHtcbiAgICBjb25zdCBtZXNzYWdlID0gcGFyc2VNZXNzYWdlKG1lc3NhZ2VQYXJ0cywgc3Vic3RpdHV0aW9ucyk7XG4gICAgLy8gTG9vayB1cCB0aGUgdHJhbnNsYXRpb24gdXNpbmcgdGhlIG1lc3NhZ2VJZCwgYW5kIHRoZW4gdGhlIGxlZ2FjeUlkIGlmIGF2YWlsYWJsZS5cbiAgICBsZXQgdHJhbnNsYXRpb24gPSB0cmFuc2xhdGlvbnNbbWVzc2FnZS5pZF07XG4gICAgLy8gSWYgdGhlIG1lc3NhZ2VJZCBkaWQgbm90IG1hdGNoIGEgdHJhbnNsYXRpb24sIHRyeSBtYXRjaGluZyB0aGUgbGVnYWN5IGlkcyBpbnN0ZWFkXG4gICAgaWYgKG1lc3NhZ2UubGVnYWN5SWRzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtZXNzYWdlLmxlZ2FjeUlkcy5sZW5ndGggJiYgdHJhbnNsYXRpb24gPT09IHVuZGVmaW5lZDsgaSsrKSB7XG4gICAgICAgICAgICB0cmFuc2xhdGlvbiA9IHRyYW5zbGF0aW9uc1ttZXNzYWdlLmxlZ2FjeUlkc1tpXV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKHRyYW5zbGF0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IE1pc3NpbmdUcmFuc2xhdGlvbkVycm9yKG1lc3NhZ2UpO1xuICAgIH1cbiAgICByZXR1cm4gW1xuICAgICAgICB0cmFuc2xhdGlvbi5tZXNzYWdlUGFydHMsIHRyYW5zbGF0aW9uLnBsYWNlaG9sZGVyTmFtZXMubWFwKHBsYWNlaG9sZGVyID0+IHtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnN1YnN0aXR1dGlvbnMuaGFzT3duUHJvcGVydHkocGxhY2Vob2xkZXIpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2Uuc3Vic3RpdHV0aW9uc1twbGFjZWhvbGRlcl07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFRoZXJlIGlzIGEgcGxhY2Vob2xkZXIgbmFtZSBtaXNtYXRjaCB3aXRoIHRoZSB0cmFuc2xhdGlvbiBwcm92aWRlZCBmb3IgdGhlIG1lc3NhZ2UgJHtkZXNjcmliZU1lc3NhZ2UobWVzc2FnZSl9LlxcbmAgK1xuICAgICAgICAgICAgICAgICAgICBgVGhlIHRyYW5zbGF0aW9uIGNvbnRhaW5zIGEgcGxhY2Vob2xkZXIgd2l0aCBuYW1lICR7cGxhY2Vob2xkZXJ9LCB3aGljaCBkb2VzIG5vdCBleGlzdCBpbiB0aGUgbWVzc2FnZS5gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICBdO1xufVxuLyoqXG4gKiBQYXJzZSB0aGUgYG1lc3NhZ2VQYXJ0c2AgYW5kIGBwbGFjZWhvbGRlck5hbWVzYCBvdXQgb2YgYSB0YXJnZXQgYG1lc3NhZ2VgLlxuICpcbiAqIFVzZWQgYnkgYGxvYWRUcmFuc2xhdGlvbnMoKWAgdG8gY29udmVydCB0YXJnZXQgbWVzc2FnZSBzdHJpbmdzIGludG8gYSBzdHJ1Y3R1cmUgdGhhdCBpcyBtb3JlXG4gKiBhcHByb3ByaWF0ZSBmb3IgZG9pbmcgdHJhbnNsYXRpb24uXG4gKlxuICogQHBhcmFtIG1lc3NhZ2UgdGhlIG1lc3NhZ2UgdG8gYmUgcGFyc2VkLlxuICovXG5mdW5jdGlvbiBwYXJzZVRyYW5zbGF0aW9uKG1lc3NhZ2VTdHJpbmcpIHtcbiAgICBjb25zdCBwYXJ0cyA9IG1lc3NhZ2VTdHJpbmcuc3BsaXQoL3tcXCQoW159XSopfS8pO1xuICAgIGNvbnN0IG1lc3NhZ2VQYXJ0cyA9IFtwYXJ0c1swXV07XG4gICAgY29uc3QgcGxhY2Vob2xkZXJOYW1lcyA9IFtdO1xuICAgIGZvciAobGV0IGkgPSAxOyBpIDwgcGFydHMubGVuZ3RoIC0gMTsgaSArPSAyKSB7XG4gICAgICAgIHBsYWNlaG9sZGVyTmFtZXMucHVzaChwYXJ0c1tpXSk7XG4gICAgICAgIG1lc3NhZ2VQYXJ0cy5wdXNoKGAke3BhcnRzW2kgKyAxXX1gKTtcbiAgICB9XG4gICAgY29uc3QgcmF3TWVzc2FnZVBhcnRzID0gbWVzc2FnZVBhcnRzLm1hcChwYXJ0ID0+IHBhcnQuY2hhckF0KDApID09PSBCTE9DS19NQVJLRVIkMSA/ICdcXFxcJyArIHBhcnQgOiBwYXJ0KTtcbiAgICByZXR1cm4ge1xuICAgICAgICB0ZXh0OiBtZXNzYWdlU3RyaW5nLFxuICAgICAgICBtZXNzYWdlUGFydHM6IG1ha2VUZW1wbGF0ZU9iamVjdChtZXNzYWdlUGFydHMsIHJhd01lc3NhZ2VQYXJ0cyksXG4gICAgICAgIHBsYWNlaG9sZGVyTmFtZXMsXG4gICAgfTtcbn1cbi8qKlxuICogQ3JlYXRlIGEgYFBhcnNlZFRyYW5zbGF0aW9uYCBmcm9tIGEgc2V0IG9mIGBtZXNzYWdlUGFydHNgIGFuZCBgcGxhY2Vob2xkZXJOYW1lc2AuXG4gKlxuICogQHBhcmFtIG1lc3NhZ2VQYXJ0cyBUaGUgbWVzc2FnZSBwYXJ0cyB0byBhcHBlYXIgaW4gdGhlIFBhcnNlZFRyYW5zbGF0aW9uLlxuICogQHBhcmFtIHBsYWNlaG9sZGVyTmFtZXMgVGhlIG5hbWVzIG9mIHRoZSBwbGFjZWhvbGRlcnMgdG8gaW50ZXJzcGVyc2UgYmV0d2VlbiB0aGUgYG1lc3NhZ2VQYXJ0c2AuXG4gKi9cbmZ1bmN0aW9uIG1ha2VQYXJzZWRUcmFuc2xhdGlvbihtZXNzYWdlUGFydHMsIHBsYWNlaG9sZGVyTmFtZXMgPSBbXSkge1xuICAgIGxldCBtZXNzYWdlU3RyaW5nID0gbWVzc2FnZVBhcnRzWzBdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcGxhY2Vob2xkZXJOYW1lcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBtZXNzYWdlU3RyaW5nICs9IGB7JCR7cGxhY2Vob2xkZXJOYW1lc1tpXX19JHttZXNzYWdlUGFydHNbaSArIDFdfWA7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIHRleHQ6IG1lc3NhZ2VTdHJpbmcsXG4gICAgICAgIG1lc3NhZ2VQYXJ0czogbWFrZVRlbXBsYXRlT2JqZWN0KG1lc3NhZ2VQYXJ0cywgbWVzc2FnZVBhcnRzKSxcbiAgICAgICAgcGxhY2Vob2xkZXJOYW1lc1xuICAgIH07XG59XG4vKipcbiAqIENyZWF0ZSB0aGUgc3BlY2lhbGl6ZWQgYXJyYXkgdGhhdCBpcyBwYXNzZWQgdG8gdGFnZ2VkLXN0cmluZyB0YWcgZnVuY3Rpb25zLlxuICpcbiAqIEBwYXJhbSBjb29rZWQgVGhlIG1lc3NhZ2UgcGFydHMgd2l0aCB0aGVpciBlc2NhcGUgY29kZXMgcHJvY2Vzc2VkLlxuICogQHBhcmFtIHJhdyBUaGUgbWVzc2FnZSBwYXJ0cyB3aXRoIHRoZWlyIGVzY2FwZWQgY29kZXMgYXMtaXMuXG4gKi9cbmZ1bmN0aW9uIG1ha2VUZW1wbGF0ZU9iamVjdChjb29rZWQsIHJhdykge1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjb29rZWQsICdyYXcnLCB7IHZhbHVlOiByYXcgfSk7XG4gICAgcmV0dXJuIGNvb2tlZDtcbn1cbmZ1bmN0aW9uIGRlc2NyaWJlTWVzc2FnZShtZXNzYWdlKSB7XG4gICAgY29uc3QgbWVhbmluZ1N0cmluZyA9IG1lc3NhZ2UubWVhbmluZyAmJiBgIC0gXCIke21lc3NhZ2UubWVhbmluZ31cImA7XG4gICAgY29uc3QgbGVnYWN5ID0gbWVzc2FnZS5sZWdhY3lJZHMgJiYgbWVzc2FnZS5sZWdhY3lJZHMubGVuZ3RoID4gMCA/XG4gICAgICAgIGAgWyR7bWVzc2FnZS5sZWdhY3lJZHMubWFwKGwgPT4gYFwiJHtsfVwiYCkuam9pbignLCAnKX1dYCA6XG4gICAgICAgICcnO1xuICAgIHJldHVybiBgXCIke21lc3NhZ2UuaWR9XCIke2xlZ2FjeX0gKFwiJHttZXNzYWdlLnRleHR9XCIke21lYW5pbmdTdHJpbmd9KWA7XG59XG5cbi8qKlxuICogTG9hZCB0cmFuc2xhdGlvbnMgZm9yIHVzZSBieSBgJGxvY2FsaXplYCwgaWYgZG9pbmcgcnVudGltZSB0cmFuc2xhdGlvbi5cbiAqXG4gKiBJZiB0aGUgYCRsb2NhbGl6ZWAgdGFnZ2VkIHN0cmluZ3MgYXJlIG5vdCBnb2luZyB0byBiZSByZXBsYWNlZCBhdCBjb21waWxlZCB0aW1lLCBpdCBpcyBwb3NzaWJsZVxuICogdG8gbG9hZCBhIHNldCBvZiB0cmFuc2xhdGlvbnMgdGhhdCB3aWxsIGJlIGFwcGxpZWQgdG8gdGhlIGAkbG9jYWxpemVgIHRhZ2dlZCBzdHJpbmdzIGF0IHJ1bnRpbWUsXG4gKiBpbiB0aGUgYnJvd3Nlci5cbiAqXG4gKiBMb2FkaW5nIGEgbmV3IHRyYW5zbGF0aW9uIHdpbGwgb3ZlcndyaXRlIGEgcHJldmlvdXMgdHJhbnNsYXRpb24gaWYgaXQgaGFzIHRoZSBzYW1lIGBNZXNzYWdlSWRgLlxuICpcbiAqIE5vdGUgdGhhdCBgJGxvY2FsaXplYCBtZXNzYWdlcyBhcmUgb25seSBwcm9jZXNzZWQgb25jZSwgd2hlbiB0aGUgdGFnZ2VkIHN0cmluZyBpcyBmaXJzdFxuICogZW5jb3VudGVyZWQsIGFuZCBkb2VzIG5vdCBwcm92aWRlIGR5bmFtaWMgbGFuZ3VhZ2UgY2hhbmdpbmcgd2l0aG91dCByZWZyZXNoaW5nIHRoZSBicm93c2VyLlxuICogTG9hZGluZyBuZXcgdHJhbnNsYXRpb25zIGxhdGVyIGluIHRoZSBhcHBsaWNhdGlvbiBsaWZlLWN5Y2xlIHdpbGwgbm90IGNoYW5nZSB0aGUgdHJhbnNsYXRlZCB0ZXh0XG4gKiBvZiBtZXNzYWdlcyB0aGF0IGhhdmUgYWxyZWFkeSBiZWVuIHRyYW5zbGF0ZWQuXG4gKlxuICogVGhlIG1lc3NhZ2UgSURzIGFuZCB0cmFuc2xhdGlvbnMgYXJlIGluIHRoZSBzYW1lIGZvcm1hdCBhcyB0aGF0IHJlbmRlcmVkIHRvIFwic2ltcGxlIEpTT05cIlxuICogdHJhbnNsYXRpb24gZmlsZXMgd2hlbiBleHRyYWN0aW5nIG1lc3NhZ2VzLiBJbiBwYXJ0aWN1bGFyLCBwbGFjZWhvbGRlcnMgaW4gbWVzc2FnZXMgYXJlIHJlbmRlcmVkXG4gKiB1c2luZyB0aGUgYHskUExBQ0VIT0xERVJfTkFNRX1gIHN5bnRheC4gRm9yIGV4YW1wbGUgdGhlIG1lc3NhZ2UgZnJvbSB0aGUgZm9sbG93aW5nIHRlbXBsYXRlOlxuICpcbiAqIGBgYGh0bWxcbiAqIDxkaXYgaTE4bj5wcmU8c3Bhbj5pbm5lci1wcmU8Yj5ib2xkPC9iPmlubmVyLXBvc3Q8L3NwYW4+cG9zdDwvZGl2PlxuICogYGBgXG4gKlxuICogd291bGQgaGF2ZSB0aGUgZm9sbG93aW5nIGZvcm0gaW4gdGhlIGB0cmFuc2xhdGlvbnNgIG1hcDpcbiAqXG4gKiBgYGB0c1xuICoge1xuICogICBcIjI5MzI5MDE0OTE5NzYyMjQ3NTdcIjpcbiAqICAgICAgXCJwcmV7JFNUQVJUX1RBR19TUEFOfWlubmVyLXByZXskU1RBUlRfQk9MRF9URVhUfWJvbGR7JENMT1NFX0JPTERfVEVYVH1pbm5lci1wb3N0eyRDTE9TRV9UQUdfU1BBTn1wb3N0XCJcbiAqIH1cbiAqIGBgYFxuICpcbiAqIEBwYXJhbSB0cmFuc2xhdGlvbnMgQSBtYXAgZnJvbSBtZXNzYWdlIElEIHRvIHRyYW5zbGF0ZWQgbWVzc2FnZS5cbiAqXG4gKiBUaGVzZSBtZXNzYWdlcyBhcmUgcHJvY2Vzc2VkIGFuZCBhZGRlZCB0byBhIGxvb2t1cCBiYXNlZCBvbiB0aGVpciBgTWVzc2FnZUlkYC5cbiAqXG4gKiBAc2VlIHtAbGluayBjbGVhclRyYW5zbGF0aW9uc30gZm9yIHJlbW92aW5nIHRyYW5zbGF0aW9ucyBsb2FkZWQgdXNpbmcgdGhpcyBmdW5jdGlvbi5cbiAqIEBzZWUge0BsaW5rICRsb2NhbGl6ZX0gZm9yIHRhZ2dpbmcgbWVzc2FnZXMgYXMgbmVlZGluZyB0byBiZSB0cmFuc2xhdGVkLlxuICogQHB1YmxpY0FwaVxuICovXG5mdW5jdGlvbiBsb2FkVHJhbnNsYXRpb25zKHRyYW5zbGF0aW9ucykge1xuICAgIC8vIEVuc3VyZSB0aGUgdHJhbnNsYXRlIGZ1bmN0aW9uIGV4aXN0c1xuICAgIGlmICghJGxvY2FsaXplLnRyYW5zbGF0ZSkge1xuICAgICAgICAkbG9jYWxpemUudHJhbnNsYXRlID0gdHJhbnNsYXRlO1xuICAgIH1cbiAgICBpZiAoISRsb2NhbGl6ZS5UUkFOU0xBVElPTlMpIHtcbiAgICAgICAgJGxvY2FsaXplLlRSQU5TTEFUSU9OUyA9IHt9O1xuICAgIH1cbiAgICBPYmplY3Qua2V5cyh0cmFuc2xhdGlvbnMpLmZvckVhY2goa2V5ID0+IHtcbiAgICAgICAgJGxvY2FsaXplLlRSQU5TTEFUSU9OU1trZXldID0gcGFyc2VUcmFuc2xhdGlvbih0cmFuc2xhdGlvbnNba2V5XSk7XG4gICAgfSk7XG59XG4vKipcbiAqIFJlbW92ZSBhbGwgdHJhbnNsYXRpb25zIGZvciBgJGxvY2FsaXplYCwgaWYgZG9pbmcgcnVudGltZSB0cmFuc2xhdGlvbi5cbiAqXG4gKiBBbGwgdHJhbnNsYXRpb25zIHRoYXQgaGFkIGJlZW4gbG9hZGluZyBpbnRvIG1lbW9yeSB1c2luZyBgbG9hZFRyYW5zbGF0aW9ucygpYCB3aWxsIGJlIHJlbW92ZWQuXG4gKlxuICogQHNlZSB7QGxpbmsgbG9hZFRyYW5zbGF0aW9uc30gZm9yIGxvYWRpbmcgdHJhbnNsYXRpb25zIGF0IHJ1bnRpbWUuXG4gKiBAc2VlIHtAbGluayAkbG9jYWxpemV9IGZvciB0YWdnaW5nIG1lc3NhZ2VzIGFzIG5lZWRpbmcgdG8gYmUgdHJhbnNsYXRlZC5cbiAqXG4gKiBAcHVibGljQXBpXG4gKi9cbmZ1bmN0aW9uIGNsZWFyVHJhbnNsYXRpb25zKCkge1xuICAgICRsb2NhbGl6ZS50cmFuc2xhdGUgPSB1bmRlZmluZWQ7XG4gICAgJGxvY2FsaXplLlRSQU5TTEFUSU9OUyA9IHt9O1xufVxuLyoqXG4gKiBUcmFuc2xhdGUgdGhlIHRleHQgb2YgdGhlIGdpdmVuIG1lc3NhZ2UsIHVzaW5nIHRoZSBsb2FkZWQgdHJhbnNsYXRpb25zLlxuICpcbiAqIFRoaXMgZnVuY3Rpb24gbWF5IHJlb3JkZXIgKG9yIHJlbW92ZSkgc3Vic3RpdHV0aW9ucyBhcyBpbmRpY2F0ZWQgaW4gdGhlIG1hdGNoaW5nIHRyYW5zbGF0aW9uLlxuICovXG5mdW5jdGlvbiB0cmFuc2xhdGUobWVzc2FnZVBhcnRzLCBzdWJzdGl0dXRpb25zKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIHRyYW5zbGF0ZSQxKCRsb2NhbGl6ZS5UUkFOU0xBVElPTlMsIG1lc3NhZ2VQYXJ0cywgc3Vic3RpdHV0aW9ucyk7XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihlLm1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4gW21lc3NhZ2VQYXJ0cywgc3Vic3RpdHV0aW9uc107XG4gICAgfVxufVxuXG4vKipcbiAqIFRhZyBhIHRlbXBsYXRlIGxpdGVyYWwgc3RyaW5nIGZvciBsb2NhbGl6YXRpb24uXG4gKlxuICogRm9yIGV4YW1wbGU6XG4gKlxuICogYGBgdHNcbiAqICRsb2NhbGl6ZSBgc29tZSBzdHJpbmcgdG8gbG9jYWxpemVgXG4gKiBgYGBcbiAqXG4gKiAqKlByb3ZpZGluZyBtZWFuaW5nLCBkZXNjcmlwdGlvbiBhbmQgaWQqKlxuICpcbiAqIFlvdSBjYW4gb3B0aW9uYWxseSBzcGVjaWZ5IG9uZSBvciBtb3JlIG9mIGBtZWFuaW5nYCwgYGRlc2NyaXB0aW9uYCBhbmQgYGlkYCBmb3IgYSBsb2NhbGl6ZWRcbiAqIHN0cmluZyBieSBwcmUtcGVuZGluZyBpdCB3aXRoIGEgY29sb24gZGVsaW1pdGVkIGJsb2NrIG9mIHRoZSBmb3JtOlxuICpcbiAqIGBgYHRzXG4gKiAkbG9jYWxpemVgOm1lYW5pbmd8ZGVzY3JpcHRpb25AQGlkOnNvdXJjZSBtZXNzYWdlIHRleHRgO1xuICpcbiAqICRsb2NhbGl6ZWA6bWVhbmluZ3w6c291cmNlIG1lc3NhZ2UgdGV4dGA7XG4gKiAkbG9jYWxpemVgOmRlc2NyaXB0aW9uOnNvdXJjZSBtZXNzYWdlIHRleHRgO1xuICogJGxvY2FsaXplYDpAQGlkOnNvdXJjZSBtZXNzYWdlIHRleHRgO1xuICogYGBgXG4gKlxuICogVGhpcyBmb3JtYXQgaXMgdGhlIHNhbWUgYXMgdGhhdCB1c2VkIGZvciBgaTE4bmAgbWFya2VycyBpbiBBbmd1bGFyIHRlbXBsYXRlcy4gU2VlIHRoZVxuICogW0FuZ3VsYXIgaTE4biBndWlkZV0oZ3VpZGUvaTE4bi1jb21tb24tcHJlcGFyZSNtYXJrLXRleHQtaW4tY29tcG9uZW50LXRlbXBsYXRlKS5cbiAqXG4gKiAqKk5hbWluZyBwbGFjZWhvbGRlcnMqKlxuICpcbiAqIElmIHRoZSB0ZW1wbGF0ZSBsaXRlcmFsIHN0cmluZyBjb250YWlucyBleHByZXNzaW9ucywgdGhlbiB0aGUgZXhwcmVzc2lvbnMgd2lsbCBiZSBhdXRvbWF0aWNhbGx5XG4gKiBhc3NvY2lhdGVkIHdpdGggcGxhY2Vob2xkZXIgbmFtZXMgZm9yIHlvdS5cbiAqXG4gKiBGb3IgZXhhbXBsZTpcbiAqXG4gKiBgYGB0c1xuICogJGxvY2FsaXplIGBIaSAke25hbWV9ISBUaGVyZSBhcmUgJHtpdGVtcy5sZW5ndGh9IGl0ZW1zLmA7XG4gKiBgYGBcbiAqXG4gKiB3aWxsIGdlbmVyYXRlIGEgbWVzc2FnZS1zb3VyY2Ugb2YgYEhpIHskUEh9ISBUaGVyZSBhcmUgeyRQSF8xfSBpdGVtc2AuXG4gKlxuICogVGhlIHJlY29tbWVuZGVkIHByYWN0aWNlIGlzIHRvIG5hbWUgdGhlIHBsYWNlaG9sZGVyIGFzc29jaWF0ZWQgd2l0aCBlYWNoIGV4cHJlc3Npb24gdGhvdWdoLlxuICpcbiAqIERvIHRoaXMgYnkgcHJvdmlkaW5nIHRoZSBwbGFjZWhvbGRlciBuYW1lIHdyYXBwZWQgaW4gYDpgIGNoYXJhY3RlcnMgZGlyZWN0bHkgYWZ0ZXIgdGhlXG4gKiBleHByZXNzaW9uLiBUaGVzZSBwbGFjZWhvbGRlciBuYW1lcyBhcmUgc3RyaXBwZWQgb3V0IG9mIHRoZSByZW5kZXJlZCBsb2NhbGl6ZWQgc3RyaW5nLlxuICpcbiAqIEZvciBleGFtcGxlLCB0byBuYW1lIHRoZSBgaXRlbXMubGVuZ3RoYCBleHByZXNzaW9uIHBsYWNlaG9sZGVyIGBpdGVtQ291bnRgIHlvdSB3cml0ZTpcbiAqXG4gKiBgYGB0c1xuICogJGxvY2FsaXplIGBUaGVyZSBhcmUgJHtpdGVtcy5sZW5ndGh9Oml0ZW1Db3VudDogaXRlbXNgO1xuICogYGBgXG4gKlxuICogKipFc2NhcGluZyBjb2xvbiBtYXJrZXJzKipcbiAqXG4gKiBJZiB5b3UgbmVlZCB0byB1c2UgYSBgOmAgY2hhcmFjdGVyIGRpcmVjdGx5IGF0IHRoZSBzdGFydCBvZiBhIHRhZ2dlZCBzdHJpbmcgdGhhdCBoYXMgbm9cbiAqIG1ldGFkYXRhIGJsb2NrLCBvciBkaXJlY3RseSBhZnRlciBhIHN1YnN0aXR1dGlvbiBleHByZXNzaW9uIHRoYXQgaGFzIG5vIG5hbWUgeW91IG11c3QgZXNjYXBlXG4gKiB0aGUgYDpgIGJ5IHByZWNlZGluZyBpdCB3aXRoIGEgYmFja3NsYXNoOlxuICpcbiAqIEZvciBleGFtcGxlOlxuICpcbiAqIGBgYHRzXG4gKiAvLyBtZXNzYWdlIGhhcyBhIG1ldGFkYXRhIGJsb2NrIHNvIG5vIG5lZWQgdG8gZXNjYXBlIGNvbG9uXG4gKiAkbG9jYWxpemUgYDpzb21lIGRlc2NyaXB0aW9uOjp0aGlzIG1lc3NhZ2Ugc3RhcnRzIHdpdGggYSBjb2xvbiAoOilgO1xuICogLy8gbm8gbWV0YWRhdGEgYmxvY2sgc28gdGhlIGNvbG9uIG11c3QgYmUgZXNjYXBlZFxuICogJGxvY2FsaXplIGBcXDp0aGlzIG1lc3NhZ2Ugc3RhcnRzIHdpdGggYSBjb2xvbiAoOilgO1xuICogYGBgXG4gKlxuICogYGBgdHNcbiAqIC8vIG5hbWVkIHN1YnN0aXR1dGlvbiBzbyBubyBuZWVkIHRvIGVzY2FwZSBjb2xvblxuICogJGxvY2FsaXplIGAke2xhYmVsfTpsYWJlbDo6ICR7fWBcbiAqIC8vIGFub255bW91cyBzdWJzdGl0dXRpb24gc28gY29sb24gbXVzdCBiZSBlc2NhcGVkXG4gKiAkbG9jYWxpemUgYCR7bGFiZWx9XFw6ICR7fWBcbiAqIGBgYFxuICpcbiAqICoqUHJvY2Vzc2luZyBsb2NhbGl6ZWQgc3RyaW5nczoqKlxuICpcbiAqIFRoZXJlIGFyZSB0aHJlZSBzY2VuYXJpb3M6XG4gKlxuICogKiAqKmNvbXBpbGUtdGltZSBpbmxpbmluZyoqOiB0aGUgYCRsb2NhbGl6ZWAgdGFnIGlzIHRyYW5zZm9ybWVkIGF0IGNvbXBpbGUgdGltZSBieSBhXG4gKiB0cmFuc3BpbGVyLCByZW1vdmluZyB0aGUgdGFnIGFuZCByZXBsYWNpbmcgdGhlIHRlbXBsYXRlIGxpdGVyYWwgc3RyaW5nIHdpdGggYSB0cmFuc2xhdGVkXG4gKiBsaXRlcmFsIHN0cmluZyBmcm9tIGEgY29sbGVjdGlvbiBvZiB0cmFuc2xhdGlvbnMgcHJvdmlkZWQgdG8gdGhlIHRyYW5zcGlsYXRpb24gdG9vbC5cbiAqXG4gKiAqICoqcnVuLXRpbWUgZXZhbHVhdGlvbioqOiB0aGUgYCRsb2NhbGl6ZWAgdGFnIGlzIGEgcnVuLXRpbWUgZnVuY3Rpb24gdGhhdCByZXBsYWNlcyBhbmRcbiAqIHJlb3JkZXJzIHRoZSBwYXJ0cyAoc3RhdGljIHN0cmluZ3MgYW5kIGV4cHJlc3Npb25zKSBvZiB0aGUgdGVtcGxhdGUgbGl0ZXJhbCBzdHJpbmcgd2l0aCBzdHJpbmdzXG4gKiBmcm9tIGEgY29sbGVjdGlvbiBvZiB0cmFuc2xhdGlvbnMgbG9hZGVkIGF0IHJ1bi10aW1lLlxuICpcbiAqICogKipwYXNzLXRocm91Z2ggZXZhbHVhdGlvbioqOiB0aGUgYCRsb2NhbGl6ZWAgdGFnIGlzIGEgcnVuLXRpbWUgZnVuY3Rpb24gdGhhdCBzaW1wbHkgZXZhbHVhdGVzXG4gKiB0aGUgb3JpZ2luYWwgdGVtcGxhdGUgbGl0ZXJhbCBzdHJpbmcgd2l0aG91dCBhcHBseWluZyBhbnkgdHJhbnNsYXRpb25zIHRvIHRoZSBwYXJ0cy4gVGhpc1xuICogdmVyc2lvbiBpcyB1c2VkIGR1cmluZyBkZXZlbG9wbWVudCBvciB3aGVyZSB0aGVyZSBpcyBubyBuZWVkIHRvIHRyYW5zbGF0ZSB0aGUgbG9jYWxpemVkXG4gKiB0ZW1wbGF0ZSBsaXRlcmFscy5cbiAqXG4gKiBAcGFyYW0gbWVzc2FnZVBhcnRzIGEgY29sbGVjdGlvbiBvZiB0aGUgc3RhdGljIHBhcnRzIG9mIHRoZSB0ZW1wbGF0ZSBzdHJpbmcuXG4gKiBAcGFyYW0gZXhwcmVzc2lvbnMgYSBjb2xsZWN0aW9uIG9mIHRoZSB2YWx1ZXMgb2YgZWFjaCBwbGFjZWhvbGRlciBpbiB0aGUgdGVtcGxhdGUgc3RyaW5nLlxuICogQHJldHVybnMgdGhlIHRyYW5zbGF0ZWQgc3RyaW5nLCB3aXRoIHRoZSBgbWVzc2FnZVBhcnRzYCBhbmQgYGV4cHJlc3Npb25zYCBpbnRlcmxlYXZlZCB0b2dldGhlci5cbiAqXG4gKiBAZ2xvYmFsQXBpXG4gKiBAcHVibGljQXBpXG4gKi9cbmNvbnN0ICRsb2NhbGl6ZSQxID0gZnVuY3Rpb24gKG1lc3NhZ2VQYXJ0cywgLi4uZXhwcmVzc2lvbnMpIHtcbiAgICBpZiAoJGxvY2FsaXplJDEudHJhbnNsYXRlKSB7XG4gICAgICAgIC8vIERvbid0IHVzZSBhcnJheSBleHBhbnNpb24gaGVyZSB0byBhdm9pZCB0aGUgY29tcGlsZXIgYWRkaW5nIGBfX3JlYWQoKWAgaGVscGVyIHVubmVjZXNzYXJpbHkuXG4gICAgICAgIGNvbnN0IHRyYW5zbGF0aW9uID0gJGxvY2FsaXplJDEudHJhbnNsYXRlKG1lc3NhZ2VQYXJ0cywgZXhwcmVzc2lvbnMpO1xuICAgICAgICBtZXNzYWdlUGFydHMgPSB0cmFuc2xhdGlvblswXTtcbiAgICAgICAgZXhwcmVzc2lvbnMgPSB0cmFuc2xhdGlvblsxXTtcbiAgICB9XG4gICAgbGV0IG1lc3NhZ2UgPSBzdHJpcEJsb2NrKG1lc3NhZ2VQYXJ0c1swXSwgbWVzc2FnZVBhcnRzLnJhd1swXSk7XG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBtZXNzYWdlUGFydHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgbWVzc2FnZSArPSBleHByZXNzaW9uc1tpIC0gMV0gKyBzdHJpcEJsb2NrKG1lc3NhZ2VQYXJ0c1tpXSwgbWVzc2FnZVBhcnRzLnJhd1tpXSk7XG4gICAgfVxuICAgIHJldHVybiBtZXNzYWdlO1xufTtcbmNvbnN0IEJMT0NLX01BUktFUiA9ICc6Jztcbi8qKlxuICogU3RyaXAgYSBkZWxpbWl0ZWQgXCJibG9ja1wiIGZyb20gdGhlIHN0YXJ0IG9mIHRoZSBgbWVzc2FnZVBhcnRgLCBpZiBpdCBpcyBmb3VuZC5cbiAqXG4gKiBJZiBhIG1hcmtlciBjaGFyYWN0ZXIgKDopIGFjdHVhbGx5IGFwcGVhcnMgaW4gdGhlIGNvbnRlbnQgYXQgdGhlIHN0YXJ0IG9mIGEgdGFnZ2VkIHN0cmluZyBvclxuICogYWZ0ZXIgYSBzdWJzdGl0dXRpb24gZXhwcmVzc2lvbiwgd2hlcmUgYSBibG9jayBoYXMgbm90IGJlZW4gcHJvdmlkZWQgdGhlIGNoYXJhY3RlciBtdXN0IGJlXG4gKiBlc2NhcGVkIHdpdGggYSBiYWNrc2xhc2gsIGBcXDpgLiBUaGlzIGZ1bmN0aW9uIGNoZWNrcyBmb3IgdGhpcyBieSBsb29raW5nIGF0IHRoZSBgcmF3YFxuICogbWVzc2FnZVBhcnQsIHdoaWNoIHNob3VsZCBzdGlsbCBjb250YWluIHRoZSBiYWNrc2xhc2guXG4gKlxuICogQHBhcmFtIG1lc3NhZ2VQYXJ0IFRoZSBjb29rZWQgbWVzc2FnZSBwYXJ0IHRvIHByb2Nlc3MuXG4gKiBAcGFyYW0gcmF3TWVzc2FnZVBhcnQgVGhlIHJhdyBtZXNzYWdlIHBhcnQgdG8gY2hlY2suXG4gKiBAcmV0dXJucyB0aGUgbWVzc2FnZSBwYXJ0IHdpdGggdGhlIHBsYWNlaG9sZGVyIG5hbWUgc3RyaXBwZWQsIGlmIGZvdW5kLlxuICogQHRocm93cyBhbiBlcnJvciBpZiB0aGUgYmxvY2sgaXMgdW50ZXJtaW5hdGVkXG4gKi9cbmZ1bmN0aW9uIHN0cmlwQmxvY2sobWVzc2FnZVBhcnQsIHJhd01lc3NhZ2VQYXJ0KSB7XG4gICAgcmV0dXJuIHJhd01lc3NhZ2VQYXJ0LmNoYXJBdCgwKSA9PT0gQkxPQ0tfTUFSS0VSID9cbiAgICAgICAgbWVzc2FnZVBhcnQuc3Vic3RyaW5nKGZpbmRFbmRPZkJsb2NrKG1lc3NhZ2VQYXJ0LCByYXdNZXNzYWdlUGFydCkgKyAxKSA6XG4gICAgICAgIG1lc3NhZ2VQYXJ0O1xufVxuXG4vLyBUaGlzIGZpbGUgZXhwb3J0cyBhbGwgdGhlIGB1dGlsc2AgYXMgcHJpdmF0ZSBleHBvcnRzIHNvIHRoYXQgb3RoZXIgcGFydHMgb2YgYEBhbmd1bGFyL2xvY2FsaXplYFxuXG4vLyBUaGlzIGZpbGUgY29udGFpbnMgdGhlIHB1YmxpYyBBUEkgb2YgdGhlIGBAYW5ndWxhci9sb2NhbGl6ZWAgZW50cnktcG9pbnRcblxuLy8gRE8gTk9UIEFERCBwdWJsaWMgZXhwb3J0cyB0byB0aGlzIGZpbGUuXG5cbmV4cG9ydCB7IGNsZWFyVHJhbnNsYXRpb25zLCBsb2FkVHJhbnNsYXRpb25zLCAkbG9jYWxpemUkMSBhcyDJtSRsb2NhbGl6ZSwgTWlzc2luZ1RyYW5zbGF0aW9uRXJyb3IgYXMgybVNaXNzaW5nVHJhbnNsYXRpb25FcnJvciwgY29tcHV0ZU1zZ0lkIGFzIMm1Y29tcHV0ZU1zZ0lkLCBmaW5kRW5kT2ZCbG9jayBhcyDJtWZpbmRFbmRPZkJsb2NrLCBpc01pc3NpbmdUcmFuc2xhdGlvbkVycm9yIGFzIMm1aXNNaXNzaW5nVHJhbnNsYXRpb25FcnJvciwgbWFrZVBhcnNlZFRyYW5zbGF0aW9uIGFzIMm1bWFrZVBhcnNlZFRyYW5zbGF0aW9uLCBtYWtlVGVtcGxhdGVPYmplY3QgYXMgybVtYWtlVGVtcGxhdGVPYmplY3QsIHBhcnNlTWVzc2FnZSBhcyDJtXBhcnNlTWVzc2FnZSwgcGFyc2VNZXRhZGF0YSBhcyDJtXBhcnNlTWV0YWRhdGEsIHBhcnNlVHJhbnNsYXRpb24gYXMgybVwYXJzZVRyYW5zbGF0aW9uLCBzcGxpdEJsb2NrIGFzIMm1c3BsaXRCbG9jaywgdHJhbnNsYXRlJDEgYXMgybV0cmFuc2xhdGUgfTtcblxuIiwiLyoqXG4gKiBAbGljZW5zZSBBbmd1bGFyIHYxNy4wLjhcbiAqIChjKSAyMDEwLTIwMjIgR29vZ2xlIExMQy4gaHR0cHM6Ly9hbmd1bGFyLmlvL1xuICogTGljZW5zZTogTUlUXG4gKi9cblxuaW1wb3J0IHsgybUkbG9jYWxpemUgfSBmcm9tICdAYW5ndWxhci9sb2NhbGl6ZSc7XG5leHBvcnQgeyDJtSRsb2NhbGl6ZSBhcyAkbG9jYWxpemUgfSBmcm9tICdAYW5ndWxhci9sb2NhbGl6ZSc7XG5cbi8vIEF0dGFjaCAkbG9jYWxpemUgdG8gdGhlIGdsb2JhbCBjb250ZXh0LCBhcyBhIHNpZGUtZWZmZWN0IG9mIHRoaXMgbW9kdWxlLlxuZ2xvYmFsVGhpcy4kbG9jYWxpemUgPSDJtSRsb2NhbGl6ZTtcblxuIiwiaW1wb3J0ICd6b25lLmpzJztcbmltcG9ydCAnQGFuZ3VsYXIvbG9jYWxpemUvaW5pdCc7XG5pbXBvcnQgKiBhcyBwcm9jZXNzIGZyb20gJ3Byb2Nlc3MnO1xuXG4vLyBGaXggbmVlZGVkIGZvciBTb2NrSlMsIHNlZSBodHRwczovL2dpdGh1Yi5jb20vc29ja2pzL3NvY2tqcy1jbGllbnQvaXNzdWVzLzQzOVxuKHdpbmRvdyBhcyBhbnkpLmdsb2JhbCA9IHdpbmRvdztcblxud2luZG93Wydwcm9jZXNzJ10gPSBwcm9jZXNzO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUFBO0FBQ0EsUUFBSUEsV0FBVSxPQUFPLFVBQVUsQ0FBQztBQU9oQyxRQUFJO0FBQ0osUUFBSTtBQUVKLGFBQVMsbUJBQW1CO0FBQ3hCLFlBQU0sSUFBSSxNQUFNLGlDQUFpQztBQUFBLElBQ3JEO0FBQ0EsYUFBUyxzQkFBdUI7QUFDNUIsWUFBTSxJQUFJLE1BQU0sbUNBQW1DO0FBQUEsSUFDdkQ7QUFDQSxLQUFDLFdBQVk7QUFDVCxVQUFJO0FBQ0EsWUFBSSxPQUFPLGVBQWUsWUFBWTtBQUNsQyw2QkFBbUI7QUFBQSxRQUN2QixPQUFPO0FBQ0gsNkJBQW1CO0FBQUEsUUFDdkI7QUFBQSxNQUNKLFNBQVMsR0FBRztBQUNSLDJCQUFtQjtBQUFBLE1BQ3ZCO0FBQ0EsVUFBSTtBQUNBLFlBQUksT0FBTyxpQkFBaUIsWUFBWTtBQUNwQywrQkFBcUI7QUFBQSxRQUN6QixPQUFPO0FBQ0gsK0JBQXFCO0FBQUEsUUFDekI7QUFBQSxNQUNKLFNBQVMsR0FBRztBQUNSLDZCQUFxQjtBQUFBLE1BQ3pCO0FBQUEsSUFDSixHQUFHO0FBQ0gsYUFBUyxXQUFXLEtBQUs7QUFDckIsVUFBSSxxQkFBcUIsWUFBWTtBQUVqQyxlQUFPLFdBQVcsS0FBSyxDQUFDO0FBQUEsTUFDNUI7QUFFQSxXQUFLLHFCQUFxQixvQkFBb0IsQ0FBQyxxQkFBcUIsWUFBWTtBQUM1RSwyQkFBbUI7QUFDbkIsZUFBTyxXQUFXLEtBQUssQ0FBQztBQUFBLE1BQzVCO0FBQ0EsVUFBSTtBQUVBLGVBQU8saUJBQWlCLEtBQUssQ0FBQztBQUFBLE1BQ2xDLFNBQVEsR0FBRTtBQUNOLFlBQUk7QUFFQSxpQkFBTyxpQkFBaUIsS0FBSyxNQUFNLEtBQUssQ0FBQztBQUFBLFFBQzdDLFNBQVFDLElBQUU7QUFFTixpQkFBTyxpQkFBaUIsS0FBSyxNQUFNLEtBQUssQ0FBQztBQUFBLFFBQzdDO0FBQUEsTUFDSjtBQUFBLElBR0o7QUFDQSxhQUFTLGdCQUFnQixRQUFRO0FBQzdCLFVBQUksdUJBQXVCLGNBQWM7QUFFckMsZUFBTyxhQUFhLE1BQU07QUFBQSxNQUM5QjtBQUVBLFdBQUssdUJBQXVCLHVCQUF1QixDQUFDLHVCQUF1QixjQUFjO0FBQ3JGLDZCQUFxQjtBQUNyQixlQUFPLGFBQWEsTUFBTTtBQUFBLE1BQzlCO0FBQ0EsVUFBSTtBQUVBLGVBQU8sbUJBQW1CLE1BQU07QUFBQSxNQUNwQyxTQUFTLEdBQUU7QUFDUCxZQUFJO0FBRUEsaUJBQU8sbUJBQW1CLEtBQUssTUFBTSxNQUFNO0FBQUEsUUFDL0MsU0FBU0EsSUFBRTtBQUdQLGlCQUFPLG1CQUFtQixLQUFLLE1BQU0sTUFBTTtBQUFBLFFBQy9DO0FBQUEsTUFDSjtBQUFBLElBSUo7QUFDQSxRQUFJLFFBQVEsQ0FBQztBQUNiLFFBQUksV0FBVztBQUNmLFFBQUk7QUFDSixRQUFJLGFBQWE7QUFFakIsYUFBUyxrQkFBa0I7QUFDdkIsVUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjO0FBQzVCO0FBQUEsTUFDSjtBQUNBLGlCQUFXO0FBQ1gsVUFBSSxhQUFhLFFBQVE7QUFDckIsZ0JBQVEsYUFBYSxPQUFPLEtBQUs7QUFBQSxNQUNyQyxPQUFPO0FBQ0gscUJBQWE7QUFBQSxNQUNqQjtBQUNBLFVBQUksTUFBTSxRQUFRO0FBQ2QsbUJBQVc7QUFBQSxNQUNmO0FBQUEsSUFDSjtBQUVBLGFBQVMsYUFBYTtBQUNsQixVQUFJLFVBQVU7QUFDVjtBQUFBLE1BQ0o7QUFDQSxVQUFJLFVBQVUsV0FBVyxlQUFlO0FBQ3hDLGlCQUFXO0FBRVgsVUFBSSxNQUFNLE1BQU07QUFDaEIsYUFBTSxLQUFLO0FBQ1AsdUJBQWU7QUFDZixnQkFBUSxDQUFDO0FBQ1QsZUFBTyxFQUFFLGFBQWEsS0FBSztBQUN2QixjQUFJLGNBQWM7QUFDZCx5QkFBYSxVQUFVLEVBQUUsSUFBSTtBQUFBLFVBQ2pDO0FBQUEsUUFDSjtBQUNBLHFCQUFhO0FBQ2IsY0FBTSxNQUFNO0FBQUEsTUFDaEI7QUFDQSxxQkFBZTtBQUNmLGlCQUFXO0FBQ1gsc0JBQWdCLE9BQU87QUFBQSxJQUMzQjtBQUVBLElBQUFELFNBQVEsV0FBVyxTQUFVLEtBQUs7QUFDOUIsVUFBSSxPQUFPLElBQUksTUFBTSxVQUFVLFNBQVMsQ0FBQztBQUN6QyxVQUFJLFVBQVUsU0FBUyxHQUFHO0FBQ3RCLGlCQUFTLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLO0FBQ3ZDLGVBQUssSUFBSSxDQUFDLElBQUksVUFBVSxDQUFDO0FBQUEsUUFDN0I7QUFBQSxNQUNKO0FBQ0EsWUFBTSxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksQ0FBQztBQUM5QixVQUFJLE1BQU0sV0FBVyxLQUFLLENBQUMsVUFBVTtBQUNqQyxtQkFBVyxVQUFVO0FBQUEsTUFDekI7QUFBQSxJQUNKO0FBR0EsYUFBUyxLQUFLLEtBQUssT0FBTztBQUN0QixXQUFLLE1BQU07QUFDWCxXQUFLLFFBQVE7QUFBQSxJQUNqQjtBQUNBLFNBQUssVUFBVSxNQUFNLFdBQVk7QUFDN0IsV0FBSyxJQUFJLE1BQU0sTUFBTSxLQUFLLEtBQUs7QUFBQSxJQUNuQztBQUNBLElBQUFBLFNBQVEsUUFBUTtBQUNoQixJQUFBQSxTQUFRLFVBQVU7QUFDbEIsSUFBQUEsU0FBUSxNQUFNLENBQUM7QUFDZixJQUFBQSxTQUFRLE9BQU8sQ0FBQztBQUNoQixJQUFBQSxTQUFRLFVBQVU7QUFDbEIsSUFBQUEsU0FBUSxXQUFXLENBQUM7QUFFcEIsYUFBUyxPQUFPO0FBQUEsSUFBQztBQUVqQixJQUFBQSxTQUFRLEtBQUs7QUFDYixJQUFBQSxTQUFRLGNBQWM7QUFDdEIsSUFBQUEsU0FBUSxPQUFPO0FBQ2YsSUFBQUEsU0FBUSxNQUFNO0FBQ2QsSUFBQUEsU0FBUSxpQkFBaUI7QUFDekIsSUFBQUEsU0FBUSxxQkFBcUI7QUFDN0IsSUFBQUEsU0FBUSxPQUFPO0FBQ2YsSUFBQUEsU0FBUSxrQkFBa0I7QUFDMUIsSUFBQUEsU0FBUSxzQkFBc0I7QUFFOUIsSUFBQUEsU0FBUSxZQUFZLFNBQVUsTUFBTTtBQUFFLGFBQU8sQ0FBQztBQUFBLElBQUU7QUFFaEQsSUFBQUEsU0FBUSxVQUFVLFNBQVUsTUFBTTtBQUM5QixZQUFNLElBQUksTUFBTSxrQ0FBa0M7QUFBQSxJQUN0RDtBQUVBLElBQUFBLFNBQVEsTUFBTSxXQUFZO0FBQUUsYUFBTztBQUFBLElBQUk7QUFDdkMsSUFBQUEsU0FBUSxRQUFRLFNBQVUsS0FBSztBQUMzQixZQUFNLElBQUksTUFBTSxnQ0FBZ0M7QUFBQSxJQUNwRDtBQUNBLElBQUFBLFNBQVEsUUFBUSxXQUFXO0FBQUUsYUFBTztBQUFBLElBQUc7QUFBQTtBQUFBOzs7Q0NqTHJDLFNBQVUsUUFBUTtBQUNoQixRQUFNLGNBQWMsT0FBTyxhQUFhO0FBQ3hDLFdBQVMsS0FBSyxNQUFNO0FBQ2hCLG1CQUFlLFlBQVksTUFBTSxLQUFLLFlBQVksTUFBTSxFQUFFLElBQUk7QUFBQSxFQUNsRTtBQUNBLFdBQVMsbUJBQW1CLE1BQU0sT0FBTztBQUNyQyxtQkFBZSxZQUFZLFNBQVMsS0FBSyxZQUFZLFNBQVMsRUFBRSxNQUFNLEtBQUs7QUFBQSxFQUMvRTtBQUNBLE9BQUssTUFBTTtBQUlYLFFBQU0sZUFBZSxPQUFPLHNCQUFzQixLQUFLO0FBQ3ZELFdBQVMsV0FBVyxNQUFNO0FBQ3RCLFdBQU8sZUFBZTtBQUFBLEVBQzFCO0FBQ0EsUUFBTSxpQkFBaUIsT0FBTyxXQUFXLHlCQUF5QixDQUFDLE1BQU07QUFDekUsTUFBSSxPQUFPLE1BQU0sR0FBRztBQVVoQixRQUFJLGtCQUFrQixPQUFPLE9BQU8sTUFBTSxFQUFFLGVBQWUsWUFBWTtBQUNuRSxZQUFNLElBQUksTUFBTSxzQkFBc0I7QUFBQSxJQUMxQyxPQUNLO0FBQ0QsYUFBTyxPQUFPLE1BQU07QUFBQSxJQUN4QjtBQUFBLEVBQ0o7QUFDQSxRQUFNLFFBQU4sTUFBTSxNQUFLO0FBQUEsSUFHUCxPQUFPLG9CQUFvQjtBQUN2QixVQUFJLE9BQU8sU0FBUyxNQUFNLFFBQVEsa0JBQWtCLEdBQUc7QUFDbkQsY0FBTSxJQUFJLE1BQU0sK1JBSTBDO0FBQUEsTUFDOUQ7QUFBQSxJQUNKO0FBQUEsSUFDQSxXQUFXLE9BQU87QUFDZCxVQUFJLE9BQU8sTUFBSztBQUNoQixhQUFPLEtBQUssUUFBUTtBQUNoQixlQUFPLEtBQUs7QUFBQSxNQUNoQjtBQUNBLGFBQU87QUFBQSxJQUNYO0FBQUEsSUFDQSxXQUFXLFVBQVU7QUFDakIsYUFBTyxrQkFBa0I7QUFBQSxJQUM3QjtBQUFBLElBQ0EsV0FBVyxjQUFjO0FBQ3JCLGFBQU87QUFBQSxJQUNYO0FBQUE7QUFBQSxJQUVBLE9BQU8sYUFBYSxNQUFNLElBQUksa0JBQWtCLE9BQU87QUFDbkQsVUFBSSxRQUFRLGVBQWUsSUFBSSxHQUFHO0FBSTlCLFlBQUksQ0FBQyxtQkFBbUIsZ0JBQWdCO0FBQ3BDLGdCQUFNLE1BQU0sMkJBQTJCLElBQUk7QUFBQSxRQUMvQztBQUFBLE1BQ0osV0FDUyxDQUFDLE9BQU8sb0JBQW9CLElBQUksR0FBRztBQUN4QyxjQUFNLFdBQVcsVUFBVTtBQUMzQixhQUFLLFFBQVE7QUFDYixnQkFBUSxJQUFJLElBQUksR0FBRyxRQUFRLE9BQU0sSUFBSTtBQUNyQywyQkFBbUIsVUFBVSxRQUFRO0FBQUEsTUFDekM7QUFBQSxJQUNKO0FBQUEsSUFDQSxJQUFJLFNBQVM7QUFDVCxhQUFPLEtBQUs7QUFBQSxJQUNoQjtBQUFBLElBQ0EsSUFBSSxPQUFPO0FBQ1AsYUFBTyxLQUFLO0FBQUEsSUFDaEI7QUFBQSxJQUNBLFlBQVksUUFBUSxVQUFVO0FBQzFCLFdBQUssVUFBVTtBQUNmLFdBQUssUUFBUSxXQUFXLFNBQVMsUUFBUSxZQUFZO0FBQ3JELFdBQUssY0FBYyxZQUFZLFNBQVMsY0FBYyxDQUFDO0FBQ3ZELFdBQUssZ0JBQ0QsSUFBSSxjQUFjLE1BQU0sS0FBSyxXQUFXLEtBQUssUUFBUSxlQUFlLFFBQVE7QUFBQSxJQUNwRjtBQUFBLElBQ0EsSUFBSSxLQUFLO0FBQ0wsWUFBTSxPQUFPLEtBQUssWUFBWSxHQUFHO0FBQ2pDLFVBQUk7QUFDQSxlQUFPLEtBQUssWUFBWSxHQUFHO0FBQUEsSUFDbkM7QUFBQSxJQUNBLFlBQVksS0FBSztBQUNiLFVBQUksVUFBVTtBQUNkLGFBQU8sU0FBUztBQUNaLFlBQUksUUFBUSxZQUFZLGVBQWUsR0FBRyxHQUFHO0FBQ3pDLGlCQUFPO0FBQUEsUUFDWDtBQUNBLGtCQUFVLFFBQVE7QUFBQSxNQUN0QjtBQUNBLGFBQU87QUFBQSxJQUNYO0FBQUEsSUFDQSxLQUFLLFVBQVU7QUFDWCxVQUFJLENBQUM7QUFDRCxjQUFNLElBQUksTUFBTSxvQkFBb0I7QUFDeEMsYUFBTyxLQUFLLGNBQWMsS0FBSyxNQUFNLFFBQVE7QUFBQSxJQUNqRDtBQUFBLElBQ0EsS0FBSyxVQUFVLFFBQVE7QUFDbkIsVUFBSSxPQUFPLGFBQWEsWUFBWTtBQUNoQyxjQUFNLElBQUksTUFBTSw2QkFBNkIsUUFBUTtBQUFBLE1BQ3pEO0FBQ0EsWUFBTSxZQUFZLEtBQUssY0FBYyxVQUFVLE1BQU0sVUFBVSxNQUFNO0FBQ3JFLFlBQU0sT0FBTztBQUNiLGFBQU8sV0FBWTtBQUNmLGVBQU8sS0FBSyxXQUFXLFdBQVcsTUFBTSxXQUFXLE1BQU07QUFBQSxNQUM3RDtBQUFBLElBQ0o7QUFBQSxJQUNBLElBQUksVUFBVSxXQUFXLFdBQVcsUUFBUTtBQUN4QywwQkFBb0IsRUFBRSxRQUFRLG1CQUFtQixNQUFNLEtBQUs7QUFDNUQsVUFBSTtBQUNBLGVBQU8sS0FBSyxjQUFjLE9BQU8sTUFBTSxVQUFVLFdBQVcsV0FBVyxNQUFNO0FBQUEsTUFDakYsVUFDQTtBQUNJLDRCQUFvQixrQkFBa0I7QUFBQSxNQUMxQztBQUFBLElBQ0o7QUFBQSxJQUNBLFdBQVcsVUFBVSxZQUFZLE1BQU0sV0FBVyxRQUFRO0FBQ3RELDBCQUFvQixFQUFFLFFBQVEsbUJBQW1CLE1BQU0sS0FBSztBQUM1RCxVQUFJO0FBQ0EsWUFBSTtBQUNBLGlCQUFPLEtBQUssY0FBYyxPQUFPLE1BQU0sVUFBVSxXQUFXLFdBQVcsTUFBTTtBQUFBLFFBQ2pGLFNBQ08sT0FBTztBQUNWLGNBQUksS0FBSyxjQUFjLFlBQVksTUFBTSxLQUFLLEdBQUc7QUFDN0Msa0JBQU07QUFBQSxVQUNWO0FBQUEsUUFDSjtBQUFBLE1BQ0osVUFDQTtBQUNJLDRCQUFvQixrQkFBa0I7QUFBQSxNQUMxQztBQUFBLElBQ0o7QUFBQSxJQUNBLFFBQVEsTUFBTSxXQUFXLFdBQVc7QUFDaEMsVUFBSSxLQUFLLFFBQVEsTUFBTTtBQUNuQixjQUFNLElBQUksTUFBTSxpRUFDWCxLQUFLLFFBQVEsU0FBUyxPQUFPLGtCQUFrQixLQUFLLE9BQU8sR0FBRztBQUFBLE1BQ3ZFO0FBSUEsVUFBSSxLQUFLLFVBQVUsaUJBQWlCLEtBQUssU0FBUyxhQUFhLEtBQUssU0FBUyxZQUFZO0FBQ3JGO0FBQUEsTUFDSjtBQUNBLFlBQU0sZUFBZSxLQUFLLFNBQVM7QUFDbkMsc0JBQWdCLEtBQUssY0FBYyxTQUFTLFNBQVM7QUFDckQsV0FBSztBQUNMLFlBQU0sZUFBZTtBQUNyQixxQkFBZTtBQUNmLDBCQUFvQixFQUFFLFFBQVEsbUJBQW1CLE1BQU0sS0FBSztBQUM1RCxVQUFJO0FBQ0EsWUFBSSxLQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEsQ0FBQyxLQUFLLEtBQUssWUFBWTtBQUM5RCxlQUFLLFdBQVc7QUFBQSxRQUNwQjtBQUNBLFlBQUk7QUFDQSxpQkFBTyxLQUFLLGNBQWMsV0FBVyxNQUFNLE1BQU0sV0FBVyxTQUFTO0FBQUEsUUFDekUsU0FDTyxPQUFPO0FBQ1YsY0FBSSxLQUFLLGNBQWMsWUFBWSxNQUFNLEtBQUssR0FBRztBQUM3QyxrQkFBTTtBQUFBLFVBQ1Y7QUFBQSxRQUNKO0FBQUEsTUFDSixVQUNBO0FBR0ksWUFBSSxLQUFLLFVBQVUsZ0JBQWdCLEtBQUssVUFBVSxTQUFTO0FBQ3ZELGNBQUksS0FBSyxRQUFRLGFBQWMsS0FBSyxRQUFRLEtBQUssS0FBSyxZQUFhO0FBQy9ELDRCQUFnQixLQUFLLGNBQWMsV0FBVyxPQUFPO0FBQUEsVUFDekQsT0FDSztBQUNELGlCQUFLLFdBQVc7QUFDaEIsaUJBQUssaUJBQWlCLE1BQU0sRUFBRTtBQUM5Qiw0QkFDSSxLQUFLLGNBQWMsY0FBYyxTQUFTLFlBQVk7QUFBQSxVQUM5RDtBQUFBLFFBQ0o7QUFDQSw0QkFBb0Isa0JBQWtCO0FBQ3RDLHVCQUFlO0FBQUEsTUFDbkI7QUFBQSxJQUNKO0FBQUEsSUFDQSxhQUFhLE1BQU07QUFDZixVQUFJLEtBQUssUUFBUSxLQUFLLFNBQVMsTUFBTTtBQUdqQyxZQUFJLFVBQVU7QUFDZCxlQUFPLFNBQVM7QUFDWixjQUFJLFlBQVksS0FBSyxNQUFNO0FBQ3ZCLGtCQUFNLE1BQU0sOEJBQThCLEtBQUssSUFBSSw4Q0FBOEMsS0FBSyxLQUFLLElBQUksRUFBRTtBQUFBLFVBQ3JIO0FBQ0Esb0JBQVUsUUFBUTtBQUFBLFFBQ3RCO0FBQUEsTUFDSjtBQUNBLFdBQUssY0FBYyxZQUFZLFlBQVk7QUFDM0MsWUFBTSxnQkFBZ0IsQ0FBQztBQUN2QixXQUFLLGlCQUFpQjtBQUN0QixXQUFLLFFBQVE7QUFDYixVQUFJO0FBQ0EsZUFBTyxLQUFLLGNBQWMsYUFBYSxNQUFNLElBQUk7QUFBQSxNQUNyRCxTQUNPLEtBQUs7QUFHUixhQUFLLGNBQWMsU0FBUyxZQUFZLFlBQVk7QUFFcEQsYUFBSyxjQUFjLFlBQVksTUFBTSxHQUFHO0FBQ3hDLGNBQU07QUFBQSxNQUNWO0FBQ0EsVUFBSSxLQUFLLG1CQUFtQixlQUFlO0FBRXZDLGFBQUssaUJBQWlCLE1BQU0sQ0FBQztBQUFBLE1BQ2pDO0FBQ0EsVUFBSSxLQUFLLFNBQVMsWUFBWTtBQUMxQixhQUFLLGNBQWMsV0FBVyxVQUFVO0FBQUEsTUFDNUM7QUFDQSxhQUFPO0FBQUEsSUFDWDtBQUFBLElBQ0Esa0JBQWtCLFFBQVEsVUFBVSxNQUFNLGdCQUFnQjtBQUN0RCxhQUFPLEtBQUssYUFBYSxJQUFJLFNBQVMsV0FBVyxRQUFRLFVBQVUsTUFBTSxnQkFBZ0IsTUFBUyxDQUFDO0FBQUEsSUFDdkc7QUFBQSxJQUNBLGtCQUFrQixRQUFRLFVBQVUsTUFBTSxnQkFBZ0IsY0FBYztBQUNwRSxhQUFPLEtBQUssYUFBYSxJQUFJLFNBQVMsV0FBVyxRQUFRLFVBQVUsTUFBTSxnQkFBZ0IsWUFBWSxDQUFDO0FBQUEsSUFDMUc7QUFBQSxJQUNBLGtCQUFrQixRQUFRLFVBQVUsTUFBTSxnQkFBZ0IsY0FBYztBQUNwRSxhQUFPLEtBQUssYUFBYSxJQUFJLFNBQVMsV0FBVyxRQUFRLFVBQVUsTUFBTSxnQkFBZ0IsWUFBWSxDQUFDO0FBQUEsSUFDMUc7QUFBQSxJQUNBLFdBQVcsTUFBTTtBQUNiLFVBQUksS0FBSyxRQUFRO0FBQ2IsY0FBTSxJQUFJLE1BQU0sdUVBQ1gsS0FBSyxRQUFRLFNBQVMsT0FBTyxrQkFBa0IsS0FBSyxPQUFPLEdBQUc7QUFDdkUsVUFBSSxLQUFLLFVBQVUsYUFBYSxLQUFLLFVBQVUsU0FBUztBQUNwRDtBQUFBLE1BQ0o7QUFDQSxXQUFLLGNBQWMsV0FBVyxXQUFXLE9BQU87QUFDaEQsVUFBSTtBQUNBLGFBQUssY0FBYyxXQUFXLE1BQU0sSUFBSTtBQUFBLE1BQzVDLFNBQ08sS0FBSztBQUVSLGFBQUssY0FBYyxTQUFTLFNBQVM7QUFDckMsYUFBSyxjQUFjLFlBQVksTUFBTSxHQUFHO0FBQ3hDLGNBQU07QUFBQSxNQUNWO0FBQ0EsV0FBSyxpQkFBaUIsTUFBTSxFQUFFO0FBQzlCLFdBQUssY0FBYyxjQUFjLFNBQVM7QUFDMUMsV0FBSyxXQUFXO0FBQ2hCLGFBQU87QUFBQSxJQUNYO0FBQUEsSUFDQSxpQkFBaUIsTUFBTSxPQUFPO0FBQzFCLFlBQU0sZ0JBQWdCLEtBQUs7QUFDM0IsVUFBSSxTQUFTLElBQUk7QUFDYixhQUFLLGlCQUFpQjtBQUFBLE1BQzFCO0FBQ0EsZUFBUyxJQUFJLEdBQUcsSUFBSSxjQUFjLFFBQVEsS0FBSztBQUMzQyxzQkFBYyxDQUFDLEVBQUUsaUJBQWlCLEtBQUssTUFBTSxLQUFLO0FBQUEsTUFDdEQ7QUFBQSxJQUNKO0FBQUEsRUFDSjtBQXhPYSxRQUFLLGFBQWE7QUFGL0IsTUFBTUUsUUFBTjtBQTJPQSxRQUFNLGNBQWM7QUFBQSxJQUNoQixNQUFNO0FBQUEsSUFDTixXQUFXLENBQUMsVUFBVSxHQUFHLFFBQVEsaUJBQWlCLFNBQVMsUUFBUSxRQUFRLFlBQVk7QUFBQSxJQUN2RixnQkFBZ0IsQ0FBQyxVQUFVLEdBQUcsUUFBUSxTQUFTLFNBQVMsYUFBYSxRQUFRLElBQUk7QUFBQSxJQUNqRixjQUFjLENBQUMsVUFBVSxHQUFHLFFBQVEsTUFBTSxXQUFXLGNBQWMsU0FBUyxXQUFXLFFBQVEsTUFBTSxXQUFXLFNBQVM7QUFBQSxJQUN6SCxjQUFjLENBQUMsVUFBVSxHQUFHLFFBQVEsU0FBUyxTQUFTLFdBQVcsUUFBUSxJQUFJO0FBQUEsRUFDakY7QUFBQSxFQUNBLE1BQU0sY0FBYztBQUFBLElBQ2hCLFlBQVksTUFBTSxnQkFBZ0IsVUFBVTtBQUN4QyxXQUFLLGNBQWMsRUFBRSxhQUFhLEdBQUcsYUFBYSxHQUFHLGFBQWEsRUFBRTtBQUNwRSxXQUFLLE9BQU87QUFDWixXQUFLLGtCQUFrQjtBQUN2QixXQUFLLFVBQVUsYUFBYSxZQUFZLFNBQVMsU0FBUyxXQUFXLGVBQWU7QUFDcEYsV0FBSyxZQUFZLGFBQWEsU0FBUyxTQUFTLGlCQUFpQixlQUFlO0FBQ2hGLFdBQUssZ0JBQ0QsYUFBYSxTQUFTLFNBQVMsS0FBSyxPQUFPLGVBQWU7QUFDOUQsV0FBSyxlQUNELGFBQWEsU0FBUyxjQUFjLFdBQVcsZUFBZTtBQUNsRSxXQUFLLGlCQUNELGFBQWEsU0FBUyxjQUFjLGlCQUFpQixlQUFlO0FBQ3hFLFdBQUsscUJBQ0QsYUFBYSxTQUFTLGNBQWMsS0FBSyxPQUFPLGVBQWU7QUFDbkUsV0FBSyxZQUFZLGFBQWEsU0FBUyxXQUFXLFdBQVcsZUFBZTtBQUM1RSxXQUFLLGNBQ0QsYUFBYSxTQUFTLFdBQVcsaUJBQWlCLGVBQWU7QUFDckUsV0FBSyxrQkFDRCxhQUFhLFNBQVMsV0FBVyxLQUFLLE9BQU8sZUFBZTtBQUNoRSxXQUFLLGlCQUNELGFBQWEsU0FBUyxnQkFBZ0IsV0FBVyxlQUFlO0FBQ3BFLFdBQUssbUJBQ0QsYUFBYSxTQUFTLGdCQUFnQixpQkFBaUIsZUFBZTtBQUMxRSxXQUFLLHVCQUNELGFBQWEsU0FBUyxnQkFBZ0IsS0FBSyxPQUFPLGVBQWU7QUFDckUsV0FBSyxrQkFDRCxhQUFhLFNBQVMsaUJBQWlCLFdBQVcsZUFBZTtBQUNyRSxXQUFLLG9CQUFvQixhQUNwQixTQUFTLGlCQUFpQixpQkFBaUIsZUFBZTtBQUMvRCxXQUFLLHdCQUNELGFBQWEsU0FBUyxpQkFBaUIsS0FBSyxPQUFPLGVBQWU7QUFDdEUsV0FBSyxnQkFDRCxhQUFhLFNBQVMsZUFBZSxXQUFXLGVBQWU7QUFDbkUsV0FBSyxrQkFDRCxhQUFhLFNBQVMsZUFBZSxpQkFBaUIsZUFBZTtBQUN6RSxXQUFLLHNCQUNELGFBQWEsU0FBUyxlQUFlLEtBQUssT0FBTyxlQUFlO0FBQ3BFLFdBQUssZ0JBQ0QsYUFBYSxTQUFTLGVBQWUsV0FBVyxlQUFlO0FBQ25FLFdBQUssa0JBQ0QsYUFBYSxTQUFTLGVBQWUsaUJBQWlCLGVBQWU7QUFDekUsV0FBSyxzQkFDRCxhQUFhLFNBQVMsZUFBZSxLQUFLLE9BQU8sZUFBZTtBQUNwRSxXQUFLLGFBQWE7QUFDbEIsV0FBSyxlQUFlO0FBQ3BCLFdBQUssb0JBQW9CO0FBQ3pCLFdBQUssbUJBQW1CO0FBQ3hCLFlBQU0sa0JBQWtCLFlBQVksU0FBUztBQUM3QyxZQUFNLGdCQUFnQixrQkFBa0IsZUFBZTtBQUN2RCxVQUFJLG1CQUFtQixlQUFlO0FBR2xDLGFBQUssYUFBYSxrQkFBa0IsV0FBVztBQUMvQyxhQUFLLGVBQWU7QUFDcEIsYUFBSyxvQkFBb0I7QUFDekIsYUFBSyxtQkFBbUI7QUFDeEIsWUFBSSxDQUFDLFNBQVMsZ0JBQWdCO0FBQzFCLGVBQUssa0JBQWtCO0FBQ3ZCLGVBQUssb0JBQW9CO0FBQ3pCLGVBQUssd0JBQXdCLEtBQUs7QUFBQSxRQUN0QztBQUNBLFlBQUksQ0FBQyxTQUFTLGNBQWM7QUFDeEIsZUFBSyxnQkFBZ0I7QUFDckIsZUFBSyxrQkFBa0I7QUFDdkIsZUFBSyxzQkFBc0IsS0FBSztBQUFBLFFBQ3BDO0FBQ0EsWUFBSSxDQUFDLFNBQVMsY0FBYztBQUN4QixlQUFLLGdCQUFnQjtBQUNyQixlQUFLLGtCQUFrQjtBQUN2QixlQUFLLHNCQUFzQixLQUFLO0FBQUEsUUFDcEM7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUFBLElBQ0EsS0FBSyxZQUFZLFVBQVU7QUFDdkIsYUFBTyxLQUFLLFVBQVUsS0FBSyxRQUFRLE9BQU8sS0FBSyxXQUFXLEtBQUssTUFBTSxZQUFZLFFBQVEsSUFDckYsSUFBSUEsTUFBSyxZQUFZLFFBQVE7QUFBQSxJQUNyQztBQUFBLElBQ0EsVUFBVSxZQUFZLFVBQVUsUUFBUTtBQUNwQyxhQUFPLEtBQUssZUFDUixLQUFLLGFBQWEsWUFBWSxLQUFLLGdCQUFnQixLQUFLLG9CQUFvQixZQUFZLFVBQVUsTUFBTSxJQUN4RztBQUFBLElBQ1I7QUFBQSxJQUNBLE9BQU8sWUFBWSxVQUFVLFdBQVcsV0FBVyxRQUFRO0FBQ3ZELGFBQU8sS0FBSyxZQUFZLEtBQUssVUFBVSxTQUFTLEtBQUssYUFBYSxLQUFLLGlCQUFpQixZQUFZLFVBQVUsV0FBVyxXQUFXLE1BQU0sSUFDdEksU0FBUyxNQUFNLFdBQVcsU0FBUztBQUFBLElBQzNDO0FBQUEsSUFDQSxZQUFZLFlBQVksT0FBTztBQUMzQixhQUFPLEtBQUssaUJBQ1IsS0FBSyxlQUFlLGNBQWMsS0FBSyxrQkFBa0IsS0FBSyxzQkFBc0IsWUFBWSxLQUFLLElBQ3JHO0FBQUEsSUFDUjtBQUFBLElBQ0EsYUFBYSxZQUFZLE1BQU07QUFDM0IsVUFBSSxhQUFhO0FBQ2pCLFVBQUksS0FBSyxpQkFBaUI7QUFDdEIsWUFBSSxLQUFLLFlBQVk7QUFDakIscUJBQVcsZUFBZSxLQUFLLEtBQUssaUJBQWlCO0FBQUEsUUFDekQ7QUFFQSxxQkFBYSxLQUFLLGdCQUFnQixlQUFlLEtBQUssbUJBQW1CLEtBQUssdUJBQXVCLFlBQVksSUFBSTtBQUVySCxZQUFJLENBQUM7QUFDRCx1QkFBYTtBQUFBLE1BQ3JCLE9BQ0s7QUFDRCxZQUFJLEtBQUssWUFBWTtBQUNqQixlQUFLLFdBQVcsSUFBSTtBQUFBLFFBQ3hCLFdBQ1MsS0FBSyxRQUFRLFdBQVc7QUFDN0IsNEJBQWtCLElBQUk7QUFBQSxRQUMxQixPQUNLO0FBQ0QsZ0JBQU0sSUFBSSxNQUFNLDZCQUE2QjtBQUFBLFFBQ2pEO0FBQUEsTUFDSjtBQUNBLGFBQU87QUFBQSxJQUNYO0FBQUEsSUFDQSxXQUFXLFlBQVksTUFBTSxXQUFXLFdBQVc7QUFDL0MsYUFBTyxLQUFLLGdCQUFnQixLQUFLLGNBQWMsYUFBYSxLQUFLLGlCQUFpQixLQUFLLHFCQUFxQixZQUFZLE1BQU0sV0FBVyxTQUFTLElBQzlJLEtBQUssU0FBUyxNQUFNLFdBQVcsU0FBUztBQUFBLElBQ2hEO0FBQUEsSUFDQSxXQUFXLFlBQVksTUFBTTtBQUN6QixVQUFJO0FBQ0osVUFBSSxLQUFLLGVBQWU7QUFDcEIsZ0JBQVEsS0FBSyxjQUFjLGFBQWEsS0FBSyxpQkFBaUIsS0FBSyxxQkFBcUIsWUFBWSxJQUFJO0FBQUEsTUFDNUcsT0FDSztBQUNELFlBQUksQ0FBQyxLQUFLLFVBQVU7QUFDaEIsZ0JBQU0sTUFBTSx3QkFBd0I7QUFBQSxRQUN4QztBQUNBLGdCQUFRLEtBQUssU0FBUyxJQUFJO0FBQUEsTUFDOUI7QUFDQSxhQUFPO0FBQUEsSUFDWDtBQUFBLElBQ0EsUUFBUSxZQUFZLFNBQVM7QUFHekIsVUFBSTtBQUNBLGFBQUssY0FDRCxLQUFLLFdBQVcsVUFBVSxLQUFLLGNBQWMsS0FBSyxrQkFBa0IsWUFBWSxPQUFPO0FBQUEsTUFDL0YsU0FDTyxLQUFLO0FBQ1IsYUFBSyxZQUFZLFlBQVksR0FBRztBQUFBLE1BQ3BDO0FBQUEsSUFDSjtBQUFBO0FBQUEsSUFFQSxpQkFBaUIsTUFBTSxPQUFPO0FBQzFCLFlBQU0sU0FBUyxLQUFLO0FBQ3BCLFlBQU0sT0FBTyxPQUFPLElBQUk7QUFDeEIsWUFBTSxPQUFPLE9BQU8sSUFBSSxJQUFJLE9BQU87QUFDbkMsVUFBSSxPQUFPLEdBQUc7QUFDVixjQUFNLElBQUksTUFBTSwwQ0FBMEM7QUFBQSxNQUM5RDtBQUNBLFVBQUksUUFBUSxLQUFLLFFBQVEsR0FBRztBQUN4QixjQUFNLFVBQVU7QUFBQSxVQUNaLFdBQVcsT0FBTyxXQUFXLElBQUk7QUFBQSxVQUNqQyxXQUFXLE9BQU8sV0FBVyxJQUFJO0FBQUEsVUFDakMsV0FBVyxPQUFPLFdBQVcsSUFBSTtBQUFBLFVBQ2pDLFFBQVE7QUFBQSxRQUNaO0FBQ0EsYUFBSyxRQUFRLEtBQUssTUFBTSxPQUFPO0FBQUEsTUFDbkM7QUFBQSxJQUNKO0FBQUEsRUFDSjtBQUFBLEVBQ0EsTUFBTSxTQUFTO0FBQUEsSUFDWCxZQUFZLE1BQU0sUUFBUSxVQUFVLFNBQVMsWUFBWSxVQUFVO0FBRS9ELFdBQUssUUFBUTtBQUNiLFdBQUssV0FBVztBQUVoQixXQUFLLGlCQUFpQjtBQUV0QixXQUFLLFNBQVM7QUFDZCxXQUFLLE9BQU87QUFDWixXQUFLLFNBQVM7QUFDZCxXQUFLLE9BQU87QUFDWixXQUFLLGFBQWE7QUFDbEIsV0FBSyxXQUFXO0FBQ2hCLFVBQUksQ0FBQyxVQUFVO0FBQ1gsY0FBTSxJQUFJLE1BQU0seUJBQXlCO0FBQUEsTUFDN0M7QUFDQSxXQUFLLFdBQVc7QUFDaEIsWUFBTUMsUUFBTztBQUViLFVBQUksU0FBUyxhQUFhLFdBQVcsUUFBUSxNQUFNO0FBQy9DLGFBQUssU0FBUyxTQUFTO0FBQUEsTUFDM0IsT0FDSztBQUNELGFBQUssU0FBUyxXQUFZO0FBQ3RCLGlCQUFPLFNBQVMsV0FBVyxLQUFLLFFBQVFBLE9BQU0sTUFBTSxTQUFTO0FBQUEsUUFDakU7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUFBLElBQ0EsT0FBTyxXQUFXLE1BQU0sUUFBUSxNQUFNO0FBQ2xDLFVBQUksQ0FBQyxNQUFNO0FBQ1AsZUFBTztBQUFBLE1BQ1g7QUFDQTtBQUNBLFVBQUk7QUFDQSxhQUFLO0FBQ0wsZUFBTyxLQUFLLEtBQUssUUFBUSxNQUFNLFFBQVEsSUFBSTtBQUFBLE1BQy9DLFVBQ0E7QUFDSSxZQUFJLDZCQUE2QixHQUFHO0FBQ2hDLDhCQUFvQjtBQUFBLFFBQ3hCO0FBQ0E7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUFBLElBQ0EsSUFBSSxPQUFPO0FBQ1AsYUFBTyxLQUFLO0FBQUEsSUFDaEI7QUFBQSxJQUNBLElBQUksUUFBUTtBQUNSLGFBQU8sS0FBSztBQUFBLElBQ2hCO0FBQUEsSUFDQSx3QkFBd0I7QUFDcEIsV0FBSyxjQUFjLGNBQWMsVUFBVTtBQUFBLElBQy9DO0FBQUE7QUFBQSxJQUVBLGNBQWMsU0FBUyxZQUFZLFlBQVk7QUFDM0MsVUFBSSxLQUFLLFdBQVcsY0FBYyxLQUFLLFdBQVcsWUFBWTtBQUMxRCxhQUFLLFNBQVM7QUFDZCxZQUFJLFdBQVcsY0FBYztBQUN6QixlQUFLLGlCQUFpQjtBQUFBLFFBQzFCO0FBQUEsTUFDSixPQUNLO0FBQ0QsY0FBTSxJQUFJLE1BQU0sR0FBRyxLQUFLLElBQUksS0FBSyxLQUFLLE1BQU0sNkJBQTZCLE9BQU8sdUJBQXVCLFVBQVUsSUFBSSxhQUFhLFVBQVcsYUFBYSxNQUFPLEVBQUUsVUFBVSxLQUFLLE1BQU0sSUFBSTtBQUFBLE1BQ2hNO0FBQUEsSUFDSjtBQUFBLElBQ0EsV0FBVztBQUNQLFVBQUksS0FBSyxRQUFRLE9BQU8sS0FBSyxLQUFLLGFBQWEsYUFBYTtBQUN4RCxlQUFPLEtBQUssS0FBSyxTQUFTLFNBQVM7QUFBQSxNQUN2QyxPQUNLO0FBQ0QsZUFBTyxPQUFPLFVBQVUsU0FBUyxLQUFLLElBQUk7QUFBQSxNQUM5QztBQUFBLElBQ0o7QUFBQTtBQUFBO0FBQUEsSUFHQSxTQUFTO0FBQ0wsYUFBTztBQUFBLFFBQ0gsTUFBTSxLQUFLO0FBQUEsUUFDWCxPQUFPLEtBQUs7QUFBQSxRQUNaLFFBQVEsS0FBSztBQUFBLFFBQ2IsTUFBTSxLQUFLLEtBQUs7QUFBQSxRQUNoQixVQUFVLEtBQUs7QUFBQSxNQUNuQjtBQUFBLElBQ0o7QUFBQSxFQUNKO0FBTUEsUUFBTSxtQkFBbUIsV0FBVyxZQUFZO0FBQ2hELFFBQU0sZ0JBQWdCLFdBQVcsU0FBUztBQUMxQyxRQUFNLGFBQWEsV0FBVyxNQUFNO0FBQ3BDLE1BQUksa0JBQWtCLENBQUM7QUFDdkIsTUFBSSw0QkFBNEI7QUFDaEMsTUFBSTtBQUNKLFdBQVMsd0JBQXdCLE1BQU07QUFDbkMsUUFBSSxDQUFDLDZCQUE2QjtBQUM5QixVQUFJLE9BQU8sYUFBYSxHQUFHO0FBQ3ZCLHNDQUE4QixPQUFPLGFBQWEsRUFBRSxRQUFRLENBQUM7QUFBQSxNQUNqRTtBQUFBLElBQ0o7QUFDQSxRQUFJLDZCQUE2QjtBQUM3QixVQUFJLGFBQWEsNEJBQTRCLFVBQVU7QUFDdkQsVUFBSSxDQUFDLFlBQVk7QUFHYixxQkFBYSw0QkFBNEIsTUFBTTtBQUFBLE1BQ25EO0FBQ0EsaUJBQVcsS0FBSyw2QkFBNkIsSUFBSTtBQUFBLElBQ3JELE9BQ0s7QUFDRCxhQUFPLGdCQUFnQixFQUFFLE1BQU0sQ0FBQztBQUFBLElBQ3BDO0FBQUEsRUFDSjtBQUNBLFdBQVMsa0JBQWtCLE1BQU07QUFHN0IsUUFBSSw4QkFBOEIsS0FBSyxnQkFBZ0IsV0FBVyxHQUFHO0FBRWpFLDhCQUF3QixtQkFBbUI7QUFBQSxJQUMvQztBQUNBLFlBQVEsZ0JBQWdCLEtBQUssSUFBSTtBQUFBLEVBQ3JDO0FBQ0EsV0FBUyxzQkFBc0I7QUFDM0IsUUFBSSxDQUFDLDJCQUEyQjtBQUM1QixrQ0FBNEI7QUFDNUIsYUFBTyxnQkFBZ0IsUUFBUTtBQUMzQixjQUFNLFFBQVE7QUFDZCwwQkFBa0IsQ0FBQztBQUNuQixpQkFBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUNuQyxnQkFBTSxPQUFPLE1BQU0sQ0FBQztBQUNwQixjQUFJO0FBQ0EsaUJBQUssS0FBSyxRQUFRLE1BQU0sTUFBTSxJQUFJO0FBQUEsVUFDdEMsU0FDTyxPQUFPO0FBQ1YsaUJBQUssaUJBQWlCLEtBQUs7QUFBQSxVQUMvQjtBQUFBLFFBQ0o7QUFBQSxNQUNKO0FBQ0EsV0FBSyxtQkFBbUI7QUFDeEIsa0NBQTRCO0FBQUEsSUFDaEM7QUFBQSxFQUNKO0FBTUEsUUFBTSxVQUFVLEVBQUUsTUFBTSxVQUFVO0FBQ2xDLFFBQU0sZUFBZSxnQkFBZ0IsYUFBYSxjQUFjLFlBQVksYUFBYSxVQUFVLFdBQVcsWUFBWSxhQUFhLFVBQVU7QUFDakosUUFBTSxZQUFZLGFBQWEsWUFBWSxhQUFhLFlBQVk7QUFDcEUsUUFBTSxVQUFVLENBQUM7QUFDakIsUUFBTSxPQUFPO0FBQUEsSUFDVCxRQUFRO0FBQUEsSUFDUixrQkFBa0IsTUFBTTtBQUFBLElBQ3hCLGtCQUFrQjtBQUFBLElBQ2xCLG9CQUFvQjtBQUFBLElBQ3BCO0FBQUEsSUFDQSxtQkFBbUIsTUFBTSxDQUFDRCxNQUFLLFdBQVcsaUNBQWlDLENBQUM7QUFBQSxJQUM1RSxrQkFBa0IsTUFBTSxDQUFDO0FBQUEsSUFDekIsbUJBQW1CO0FBQUEsSUFDbkIsYUFBYSxNQUFNO0FBQUEsSUFDbkIsZUFBZSxNQUFNLENBQUM7QUFBQSxJQUN0QixXQUFXLE1BQU07QUFBQSxJQUNqQixnQkFBZ0IsTUFBTTtBQUFBLElBQ3RCLHFCQUFxQixNQUFNO0FBQUEsSUFDM0IsWUFBWSxNQUFNO0FBQUEsSUFDbEIsa0JBQWtCLE1BQU07QUFBQSxJQUN4QixzQkFBc0IsTUFBTTtBQUFBLElBQzVCLGdDQUFnQyxNQUFNO0FBQUEsSUFDdEMsY0FBYyxNQUFNO0FBQUEsSUFDcEIsWUFBWSxNQUFNLENBQUM7QUFBQSxJQUNuQixZQUFZLE1BQU07QUFBQSxJQUNsQixxQkFBcUIsTUFBTTtBQUFBLElBQzNCLGtCQUFrQixNQUFNLENBQUM7QUFBQSxJQUN6Qix1QkFBdUIsTUFBTTtBQUFBLElBQzdCLG1CQUFtQixNQUFNO0FBQUEsSUFDekIsZ0JBQWdCLE1BQU07QUFBQSxJQUN0QjtBQUFBLEVBQ0o7QUFDQSxNQUFJLG9CQUFvQixFQUFFLFFBQVEsTUFBTSxNQUFNLElBQUlBLE1BQUssTUFBTSxJQUFJLEVBQUU7QUFDbkUsTUFBSSxlQUFlO0FBQ25CLE1BQUksNEJBQTRCO0FBQ2hDLFdBQVMsT0FBTztBQUFBLEVBQUU7QUFDbEIscUJBQW1CLFFBQVEsTUFBTTtBQUNqQyxTQUFPLE9BQU8sTUFBTSxJQUFJQTtBQUM1QixHQUFJLFVBQVU7QUFVZCxJQUFNLGlDQUFpQyxPQUFPO0FBRTlDLElBQU0sdUJBQXVCLE9BQU87QUFFcEMsSUFBTSx1QkFBdUIsT0FBTztBQUVwQyxJQUFNLGVBQWUsT0FBTztBQUU1QixJQUFNLGFBQWEsTUFBTSxVQUFVO0FBRW5DLElBQU0seUJBQXlCO0FBRS9CLElBQU0sNEJBQTRCO0FBRWxDLElBQU0saUNBQWlDLEtBQUssV0FBVyxzQkFBc0I7QUFFN0UsSUFBTSxvQ0FBb0MsS0FBSyxXQUFXLHlCQUF5QjtBQUVuRixJQUFNLFdBQVc7QUFFakIsSUFBTSxZQUFZO0FBRWxCLElBQU0scUJBQXFCLEtBQUssV0FBVyxFQUFFO0FBQzdDLFNBQVMsb0JBQW9CLFVBQVUsUUFBUTtBQUMzQyxTQUFPLEtBQUssUUFBUSxLQUFLLFVBQVUsTUFBTTtBQUM3QztBQUNBLFNBQVMsaUNBQWlDLFFBQVEsVUFBVSxNQUFNLGdCQUFnQixjQUFjO0FBQzVGLFNBQU8sS0FBSyxRQUFRLGtCQUFrQixRQUFRLFVBQVUsTUFBTSxnQkFBZ0IsWUFBWTtBQUM5RjtBQUNBLElBQU0sYUFBYSxLQUFLO0FBQ3hCLElBQU0saUJBQWlCLE9BQU8sV0FBVztBQUN6QyxJQUFNLGlCQUFpQixpQkFBaUIsU0FBUztBQUNqRCxJQUFNLFVBQVUsa0JBQWtCLGtCQUFrQjtBQUNwRCxJQUFNLG1CQUFtQjtBQUN6QixTQUFTLGNBQWMsTUFBTSxRQUFRO0FBQ2pDLFdBQVMsSUFBSSxLQUFLLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztBQUN2QyxRQUFJLE9BQU8sS0FBSyxDQUFDLE1BQU0sWUFBWTtBQUMvQixXQUFLLENBQUMsSUFBSSxvQkFBb0IsS0FBSyxDQUFDLEdBQUcsU0FBUyxNQUFNLENBQUM7QUFBQSxJQUMzRDtBQUFBLEVBQ0o7QUFDQSxTQUFPO0FBQ1g7QUFDQSxTQUFTLGVBQWUsV0FBVyxTQUFTO0FBQ3hDLFFBQU0sU0FBUyxVQUFVLFlBQVksTUFBTTtBQUMzQyxXQUFTLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO0FBQ3JDLFVBQU0sT0FBTyxRQUFRLENBQUM7QUFDdEIsVUFBTSxXQUFXLFVBQVUsSUFBSTtBQUMvQixRQUFJLFVBQVU7QUFDVixZQUFNLGdCQUFnQiwrQkFBK0IsV0FBVyxJQUFJO0FBQ3BFLFVBQUksQ0FBQyxtQkFBbUIsYUFBYSxHQUFHO0FBQ3BDO0FBQUEsTUFDSjtBQUNBLGdCQUFVLElBQUksS0FBSyxDQUFDRSxjQUFhO0FBQzdCLGNBQU0sVUFBVSxXQUFZO0FBQ3hCLGlCQUFPQSxVQUFTLE1BQU0sTUFBTSxjQUFjLFdBQVcsU0FBUyxNQUFNLElBQUksQ0FBQztBQUFBLFFBQzdFO0FBQ0EsOEJBQXNCLFNBQVNBLFNBQVE7QUFDdkMsZUFBTztBQUFBLE1BQ1gsR0FBRyxRQUFRO0FBQUEsSUFDZjtBQUFBLEVBQ0o7QUFDSjtBQUNBLFNBQVMsbUJBQW1CLGNBQWM7QUFDdEMsTUFBSSxDQUFDLGNBQWM7QUFDZixXQUFPO0FBQUEsRUFDWDtBQUNBLE1BQUksYUFBYSxhQUFhLE9BQU87QUFDakMsV0FBTztBQUFBLEVBQ1g7QUFDQSxTQUFPLEVBQUUsT0FBTyxhQUFhLFFBQVEsY0FBYyxPQUFPLGFBQWEsUUFBUTtBQUNuRjtBQUNBLElBQU0sY0FBZSxPQUFPLHNCQUFzQixlQUFlLGdCQUFnQjtBQUdqRixJQUFNLFNBQVUsRUFBRSxRQUFRLFlBQVksT0FBTyxRQUFRLFlBQVksZUFDN0QsQ0FBQyxFQUFFLFNBQVMsS0FBSyxRQUFRLE9BQU8sTUFBTTtBQUMxQyxJQUFNLFlBQVksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLEVBQUUsa0JBQWtCLGVBQWUsYUFBYTtBQUk5RixJQUFNLFFBQVEsT0FBTyxRQUFRLFlBQVksZUFDckMsQ0FBQyxFQUFFLFNBQVMsS0FBSyxRQUFRLE9BQU8sTUFBTSxzQkFBc0IsQ0FBQyxlQUM3RCxDQUFDLEVBQUUsa0JBQWtCLGVBQWUsYUFBYTtBQUNyRCxJQUFNLHlCQUF5QixDQUFDO0FBQ2hDLElBQU0sU0FBUyxTQUFVLE9BQU87QUFHNUIsVUFBUSxTQUFTLFFBQVE7QUFDekIsTUFBSSxDQUFDLE9BQU87QUFDUjtBQUFBLEVBQ0o7QUFDQSxNQUFJLGtCQUFrQix1QkFBdUIsTUFBTSxJQUFJO0FBQ3ZELE1BQUksQ0FBQyxpQkFBaUI7QUFDbEIsc0JBQWtCLHVCQUF1QixNQUFNLElBQUksSUFBSSxXQUFXLGdCQUFnQixNQUFNLElBQUk7QUFBQSxFQUNoRztBQUNBLFFBQU0sU0FBUyxRQUFRLE1BQU0sVUFBVTtBQUN2QyxRQUFNLFdBQVcsT0FBTyxlQUFlO0FBQ3ZDLE1BQUk7QUFDSixNQUFJLGFBQWEsV0FBVyxrQkFBa0IsTUFBTSxTQUFTLFNBQVM7QUFJbEUsVUFBTSxhQUFhO0FBQ25CLGFBQVMsWUFDTCxTQUFTLEtBQUssTUFBTSxXQUFXLFNBQVMsV0FBVyxVQUFVLFdBQVcsUUFBUSxXQUFXLE9BQU8sV0FBVyxLQUFLO0FBQ3RILFFBQUksV0FBVyxNQUFNO0FBQ2pCLFlBQU0sZUFBZTtBQUFBLElBQ3pCO0FBQUEsRUFDSixPQUNLO0FBQ0QsYUFBUyxZQUFZLFNBQVMsTUFBTSxNQUFNLFNBQVM7QUFDbkQsUUFBSSxVQUFVLFVBQWEsQ0FBQyxRQUFRO0FBQ2hDLFlBQU0sZUFBZTtBQUFBLElBQ3pCO0FBQUEsRUFDSjtBQUNBLFNBQU87QUFDWDtBQUNBLFNBQVMsY0FBYyxLQUFLLE1BQU0sV0FBVztBQUN6QyxNQUFJLE9BQU8sK0JBQStCLEtBQUssSUFBSTtBQUNuRCxNQUFJLENBQUMsUUFBUSxXQUFXO0FBRXBCLFVBQU0sZ0JBQWdCLCtCQUErQixXQUFXLElBQUk7QUFDcEUsUUFBSSxlQUFlO0FBQ2YsYUFBTyxFQUFFLFlBQVksTUFBTSxjQUFjLEtBQUs7QUFBQSxJQUNsRDtBQUFBLEVBQ0o7QUFHQSxNQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssY0FBYztBQUM3QjtBQUFBLEVBQ0o7QUFDQSxRQUFNLHNCQUFzQixXQUFXLE9BQU8sT0FBTyxTQUFTO0FBQzlELE1BQUksSUFBSSxlQUFlLG1CQUFtQixLQUFLLElBQUksbUJBQW1CLEdBQUc7QUFDckU7QUFBQSxFQUNKO0FBTUEsU0FBTyxLQUFLO0FBQ1osU0FBTyxLQUFLO0FBQ1osUUFBTSxrQkFBa0IsS0FBSztBQUM3QixRQUFNLGtCQUFrQixLQUFLO0FBRTdCLFFBQU0sWUFBWSxLQUFLLE1BQU0sQ0FBQztBQUM5QixNQUFJLGtCQUFrQix1QkFBdUIsU0FBUztBQUN0RCxNQUFJLENBQUMsaUJBQWlCO0FBQ2xCLHNCQUFrQix1QkFBdUIsU0FBUyxJQUFJLFdBQVcsZ0JBQWdCLFNBQVM7QUFBQSxFQUM5RjtBQUNBLE9BQUssTUFBTSxTQUFVLFVBQVU7QUFHM0IsUUFBSSxTQUFTO0FBQ2IsUUFBSSxDQUFDLFVBQVUsUUFBUSxTQUFTO0FBQzVCLGVBQVM7QUFBQSxJQUNiO0FBQ0EsUUFBSSxDQUFDLFFBQVE7QUFDVDtBQUFBLElBQ0o7QUFDQSxVQUFNLGdCQUFnQixPQUFPLGVBQWU7QUFDNUMsUUFBSSxPQUFPLGtCQUFrQixZQUFZO0FBQ3JDLGFBQU8sb0JBQW9CLFdBQVcsTUFBTTtBQUFBLElBQ2hEO0FBR0EsdUJBQW1CLGdCQUFnQixLQUFLLFFBQVEsSUFBSTtBQUNwRCxXQUFPLGVBQWUsSUFBSTtBQUMxQixRQUFJLE9BQU8sYUFBYSxZQUFZO0FBQ2hDLGFBQU8saUJBQWlCLFdBQVcsUUFBUSxLQUFLO0FBQUEsSUFDcEQ7QUFBQSxFQUNKO0FBR0EsT0FBSyxNQUFNLFdBQVk7QUFHbkIsUUFBSSxTQUFTO0FBQ2IsUUFBSSxDQUFDLFVBQVUsUUFBUSxTQUFTO0FBQzVCLGVBQVM7QUFBQSxJQUNiO0FBQ0EsUUFBSSxDQUFDLFFBQVE7QUFDVCxhQUFPO0FBQUEsSUFDWDtBQUNBLFVBQU0sV0FBVyxPQUFPLGVBQWU7QUFDdkMsUUFBSSxVQUFVO0FBQ1YsYUFBTztBQUFBLElBQ1gsV0FDUyxpQkFBaUI7QUFPdEIsVUFBSSxRQUFRLGdCQUFnQixLQUFLLElBQUk7QUFDckMsVUFBSSxPQUFPO0FBQ1AsYUFBSyxJQUFJLEtBQUssTUFBTSxLQUFLO0FBQ3pCLFlBQUksT0FBTyxPQUFPLGdCQUFnQixNQUFNLFlBQVk7QUFDaEQsaUJBQU8sZ0JBQWdCLElBQUk7QUFBQSxRQUMvQjtBQUNBLGVBQU87QUFBQSxNQUNYO0FBQUEsSUFDSjtBQUNBLFdBQU87QUFBQSxFQUNYO0FBQ0EsdUJBQXFCLEtBQUssTUFBTSxJQUFJO0FBQ3BDLE1BQUksbUJBQW1CLElBQUk7QUFDL0I7QUFDQSxTQUFTLGtCQUFrQixLQUFLLFlBQVksV0FBVztBQUNuRCxNQUFJLFlBQVk7QUFDWixhQUFTLElBQUksR0FBRyxJQUFJLFdBQVcsUUFBUSxLQUFLO0FBQ3hDLG9CQUFjLEtBQUssT0FBTyxXQUFXLENBQUMsR0FBRyxTQUFTO0FBQUEsSUFDdEQ7QUFBQSxFQUNKLE9BQ0s7QUFDRCxVQUFNLGVBQWUsQ0FBQztBQUN0QixlQUFXLFFBQVEsS0FBSztBQUNwQixVQUFJLEtBQUssTUFBTSxHQUFHLENBQUMsS0FBSyxNQUFNO0FBQzFCLHFCQUFhLEtBQUssSUFBSTtBQUFBLE1BQzFCO0FBQUEsSUFDSjtBQUNBLGFBQVMsSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEtBQUs7QUFDMUMsb0JBQWMsS0FBSyxhQUFhLENBQUMsR0FBRyxTQUFTO0FBQUEsSUFDakQ7QUFBQSxFQUNKO0FBQ0o7QUFDQSxJQUFNLHNCQUFzQixXQUFXLGtCQUFrQjtBQUV6RCxTQUFTLFdBQVcsV0FBVztBQUMzQixRQUFNLGdCQUFnQixRQUFRLFNBQVM7QUFDdkMsTUFBSSxDQUFDO0FBQ0Q7QUFFSixVQUFRLFdBQVcsU0FBUyxDQUFDLElBQUk7QUFDakMsVUFBUSxTQUFTLElBQUksV0FBWTtBQUM3QixVQUFNLElBQUksY0FBYyxXQUFXLFNBQVM7QUFDNUMsWUFBUSxFQUFFLFFBQVE7QUFBQSxNQUNkLEtBQUs7QUFDRCxhQUFLLG1CQUFtQixJQUFJLElBQUksY0FBYztBQUM5QztBQUFBLE1BQ0osS0FBSztBQUNELGFBQUssbUJBQW1CLElBQUksSUFBSSxjQUFjLEVBQUUsQ0FBQyxDQUFDO0FBQ2xEO0FBQUEsTUFDSixLQUFLO0FBQ0QsYUFBSyxtQkFBbUIsSUFBSSxJQUFJLGNBQWMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDeEQ7QUFBQSxNQUNKLEtBQUs7QUFDRCxhQUFLLG1CQUFtQixJQUFJLElBQUksY0FBYyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUM5RDtBQUFBLE1BQ0osS0FBSztBQUNELGFBQUssbUJBQW1CLElBQUksSUFBSSxjQUFjLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ3BFO0FBQUEsTUFDSjtBQUNJLGNBQU0sSUFBSSxNQUFNLG9CQUFvQjtBQUFBLElBQzVDO0FBQUEsRUFDSjtBQUVBLHdCQUFzQixRQUFRLFNBQVMsR0FBRyxhQUFhO0FBQ3ZELFFBQU0sV0FBVyxJQUFJLGNBQWMsV0FBWTtBQUFBLEVBQUUsQ0FBQztBQUNsRCxNQUFJO0FBQ0osT0FBSyxRQUFRLFVBQVU7QUFFbkIsUUFBSSxjQUFjLG9CQUFvQixTQUFTO0FBQzNDO0FBQ0osS0FBQyxTQUFVQyxPQUFNO0FBQ2IsVUFBSSxPQUFPLFNBQVNBLEtBQUksTUFBTSxZQUFZO0FBQ3RDLGdCQUFRLFNBQVMsRUFBRSxVQUFVQSxLQUFJLElBQUksV0FBWTtBQUM3QyxpQkFBTyxLQUFLLG1CQUFtQixFQUFFQSxLQUFJLEVBQUUsTUFBTSxLQUFLLG1CQUFtQixHQUFHLFNBQVM7QUFBQSxRQUNyRjtBQUFBLE1BQ0osT0FDSztBQUNELDZCQUFxQixRQUFRLFNBQVMsRUFBRSxXQUFXQSxPQUFNO0FBQUEsVUFDckQsS0FBSyxTQUFVLElBQUk7QUFDZixnQkFBSSxPQUFPLE9BQU8sWUFBWTtBQUMxQixtQkFBSyxtQkFBbUIsRUFBRUEsS0FBSSxJQUFJLG9CQUFvQixJQUFJLFlBQVksTUFBTUEsS0FBSTtBQUloRixvQ0FBc0IsS0FBSyxtQkFBbUIsRUFBRUEsS0FBSSxHQUFHLEVBQUU7QUFBQSxZQUM3RCxPQUNLO0FBQ0QsbUJBQUssbUJBQW1CLEVBQUVBLEtBQUksSUFBSTtBQUFBLFlBQ3RDO0FBQUEsVUFDSjtBQUFBLFVBQ0EsS0FBSyxXQUFZO0FBQ2IsbUJBQU8sS0FBSyxtQkFBbUIsRUFBRUEsS0FBSTtBQUFBLFVBQ3pDO0FBQUEsUUFDSixDQUFDO0FBQUEsTUFDTDtBQUFBLElBQ0osR0FBRSxJQUFJO0FBQUEsRUFDVjtBQUNBLE9BQUssUUFBUSxlQUFlO0FBQ3hCLFFBQUksU0FBUyxlQUFlLGNBQWMsZUFBZSxJQUFJLEdBQUc7QUFDNUQsY0FBUSxTQUFTLEVBQUUsSUFBSSxJQUFJLGNBQWMsSUFBSTtBQUFBLElBQ2pEO0FBQUEsRUFDSjtBQUNKO0FBQ0EsU0FBUyxZQUFZLFFBQVEsTUFBTSxTQUFTO0FBQ3hDLE1BQUksUUFBUTtBQUNaLFNBQU8sU0FBUyxDQUFDLE1BQU0sZUFBZSxJQUFJLEdBQUc7QUFDekMsWUFBUSxxQkFBcUIsS0FBSztBQUFBLEVBQ3RDO0FBQ0EsTUFBSSxDQUFDLFNBQVMsT0FBTyxJQUFJLEdBQUc7QUFFeEIsWUFBUTtBQUFBLEVBQ1o7QUFDQSxRQUFNLGVBQWUsV0FBVyxJQUFJO0FBQ3BDLE1BQUksV0FBVztBQUNmLE1BQUksVUFBVSxFQUFFLFdBQVcsTUFBTSxZQUFZLE1BQU0sQ0FBQyxNQUFNLGVBQWUsWUFBWSxJQUFJO0FBQ3JGLGVBQVcsTUFBTSxZQUFZLElBQUksTUFBTSxJQUFJO0FBRzNDLFVBQU0sT0FBTyxTQUFTLCtCQUErQixPQUFPLElBQUk7QUFDaEUsUUFBSSxtQkFBbUIsSUFBSSxHQUFHO0FBQzFCLFlBQU0sZ0JBQWdCLFFBQVEsVUFBVSxjQUFjLElBQUk7QUFDMUQsWUFBTSxJQUFJLElBQUksV0FBWTtBQUN0QixlQUFPLGNBQWMsTUFBTSxTQUFTO0FBQUEsTUFDeEM7QUFDQSw0QkFBc0IsTUFBTSxJQUFJLEdBQUcsUUFBUTtBQUFBLElBQy9DO0FBQUEsRUFDSjtBQUNBLFNBQU87QUFDWDtBQUVBLFNBQVMsZUFBZSxLQUFLLFVBQVUsYUFBYTtBQUNoRCxNQUFJLFlBQVk7QUFDaEIsV0FBUyxhQUFhLE1BQU07QUFDeEIsVUFBTSxPQUFPLEtBQUs7QUFDbEIsU0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLFdBQVk7QUFDaEMsV0FBSyxPQUFPLE1BQU0sTUFBTSxTQUFTO0FBQUEsSUFDckM7QUFDQSxjQUFVLE1BQU0sS0FBSyxRQUFRLEtBQUssSUFBSTtBQUN0QyxXQUFPO0FBQUEsRUFDWDtBQUNBLGNBQVksWUFBWSxLQUFLLFVBQVUsQ0FBQyxhQUFhLFNBQVVGLE9BQU0sTUFBTTtBQUN2RSxVQUFNLE9BQU8sWUFBWUEsT0FBTSxJQUFJO0FBQ25DLFFBQUksS0FBSyxTQUFTLEtBQUssT0FBTyxLQUFLLEtBQUssS0FBSyxNQUFNLFlBQVk7QUFDM0QsYUFBTyxpQ0FBaUMsS0FBSyxNQUFNLEtBQUssS0FBSyxLQUFLLEdBQUcsTUFBTSxZQUFZO0FBQUEsSUFDM0YsT0FDSztBQUVELGFBQU8sU0FBUyxNQUFNQSxPQUFNLElBQUk7QUFBQSxJQUNwQztBQUFBLEVBQ0osQ0FBQztBQUNMO0FBQ0EsU0FBUyxzQkFBc0IsU0FBUyxVQUFVO0FBQzlDLFVBQVEsV0FBVyxrQkFBa0IsQ0FBQyxJQUFJO0FBQzlDO0FBQ0EsSUFBSSxxQkFBcUI7QUFDekIsSUFBSSxXQUFXO0FBQ2YsU0FBUyxPQUFPO0FBQ1osTUFBSTtBQUNBLFVBQU0sS0FBSyxlQUFlLFVBQVU7QUFDcEMsUUFBSSxHQUFHLFFBQVEsT0FBTyxNQUFNLE1BQU0sR0FBRyxRQUFRLFVBQVUsTUFBTSxJQUFJO0FBQzdELGFBQU87QUFBQSxJQUNYO0FBQUEsRUFDSixTQUNPLE9BQU87QUFBQSxFQUNkO0FBQ0EsU0FBTztBQUNYO0FBQ0EsU0FBUyxhQUFhO0FBQ2xCLE1BQUksb0JBQW9CO0FBQ3BCLFdBQU87QUFBQSxFQUNYO0FBQ0EsdUJBQXFCO0FBQ3JCLE1BQUk7QUFDQSxVQUFNLEtBQUssZUFBZSxVQUFVO0FBQ3BDLFFBQUksR0FBRyxRQUFRLE9BQU8sTUFBTSxNQUFNLEdBQUcsUUFBUSxVQUFVLE1BQU0sTUFBTSxHQUFHLFFBQVEsT0FBTyxNQUFNLElBQUk7QUFDM0YsaUJBQVc7QUFBQSxJQUNmO0FBQUEsRUFDSixTQUNPLE9BQU87QUFBQSxFQUNkO0FBQ0EsU0FBTztBQUNYO0FBRUEsS0FBSyxhQUFhLG9CQUFvQixDQUFDLFFBQVFELE9BQU0sUUFBUTtBQUN6RCxRQUFNSSxrQ0FBaUMsT0FBTztBQUM5QyxRQUFNQyx3QkFBdUIsT0FBTztBQUNwQyxXQUFTLHVCQUF1QixLQUFLO0FBQ2pDLFFBQUksT0FBTyxJQUFJLGFBQWEsT0FBTyxVQUFVLFVBQVU7QUFDbkQsWUFBTSxZQUFZLElBQUksZUFBZSxJQUFJLFlBQVk7QUFDckQsY0FBUSxZQUFZLFlBQVksTUFBTSxPQUFPLEtBQUssVUFBVSxHQUFHO0FBQUEsSUFDbkU7QUFDQSxXQUFPLE1BQU0sSUFBSSxTQUFTLElBQUksT0FBTyxVQUFVLFNBQVMsS0FBSyxHQUFHO0FBQUEsRUFDcEU7QUFDQSxRQUFNLGFBQWEsSUFBSTtBQUN2QixRQUFNLHlCQUF5QixDQUFDO0FBQ2hDLFFBQU0sNENBQTRDLE9BQU8sV0FBVyw2Q0FBNkMsQ0FBQyxNQUFNO0FBQ3hILFFBQU0sZ0JBQWdCLFdBQVcsU0FBUztBQUMxQyxRQUFNLGFBQWEsV0FBVyxNQUFNO0FBQ3BDLFFBQU0sZ0JBQWdCO0FBQ3RCLE1BQUksbUJBQW1CLENBQUMsTUFBTTtBQUMxQixRQUFJLElBQUksa0JBQWtCLEdBQUc7QUFDekIsWUFBTSxZQUFZLEtBQUssRUFBRTtBQUN6QixVQUFJLFdBQVc7QUFDWCxnQkFBUSxNQUFNLGdDQUFnQyxxQkFBcUIsUUFBUSxVQUFVLFVBQVUsV0FBVyxXQUFXLEVBQUUsS0FBSyxNQUFNLFdBQVcsRUFBRSxRQUFRLEVBQUUsS0FBSyxRQUFRLFlBQVksV0FBVyxxQkFBcUIsUUFBUSxVQUFVLFFBQVEsTUFBUztBQUFBLE1BQ3pQLE9BQ0s7QUFDRCxnQkFBUSxNQUFNLENBQUM7QUFBQSxNQUNuQjtBQUFBLElBQ0o7QUFBQSxFQUNKO0FBQ0EsTUFBSSxxQkFBcUIsTUFBTTtBQUMzQixXQUFPLHVCQUF1QixRQUFRO0FBQ2xDLFlBQU0sdUJBQXVCLHVCQUF1QixNQUFNO0FBQzFELFVBQUk7QUFDQSw2QkFBcUIsS0FBSyxXQUFXLE1BQU07QUFDdkMsY0FBSSxxQkFBcUIsZUFBZTtBQUNwQyxrQkFBTSxxQkFBcUI7QUFBQSxVQUMvQjtBQUNBLGdCQUFNO0FBQUEsUUFDVixDQUFDO0FBQUEsTUFDTCxTQUNPLE9BQU87QUFDVixpQ0FBeUIsS0FBSztBQUFBLE1BQ2xDO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFDQSxRQUFNLDZDQUE2QyxXQUFXLGtDQUFrQztBQUNoRyxXQUFTLHlCQUF5QixHQUFHO0FBQ2pDLFFBQUksaUJBQWlCLENBQUM7QUFDdEIsUUFBSTtBQUNBLFlBQU0sVUFBVUwsTUFBSywwQ0FBMEM7QUFDL0QsVUFBSSxPQUFPLFlBQVksWUFBWTtBQUMvQixnQkFBUSxLQUFLLE1BQU0sQ0FBQztBQUFBLE1BQ3hCO0FBQUEsSUFDSixTQUNPLEtBQUs7QUFBQSxJQUNaO0FBQUEsRUFDSjtBQUNBLFdBQVMsV0FBVyxPQUFPO0FBQ3ZCLFdBQU8sU0FBUyxNQUFNO0FBQUEsRUFDMUI7QUFDQSxXQUFTLGtCQUFrQixPQUFPO0FBQzlCLFdBQU87QUFBQSxFQUNYO0FBQ0EsV0FBUyxpQkFBaUIsV0FBVztBQUNqQyxXQUFPLGlCQUFpQixPQUFPLFNBQVM7QUFBQSxFQUM1QztBQUNBLFFBQU0sY0FBYyxXQUFXLE9BQU87QUFDdEMsUUFBTSxjQUFjLFdBQVcsT0FBTztBQUN0QyxRQUFNLGdCQUFnQixXQUFXLFNBQVM7QUFDMUMsUUFBTSwyQkFBMkIsV0FBVyxvQkFBb0I7QUFDaEUsUUFBTSwyQkFBMkIsV0FBVyxvQkFBb0I7QUFDaEUsUUFBTSxTQUFTO0FBQ2YsUUFBTSxhQUFhO0FBQ25CLFFBQU0sV0FBVztBQUNqQixRQUFNLFdBQVc7QUFDakIsUUFBTSxvQkFBb0I7QUFDMUIsV0FBUyxhQUFhLFNBQVMsT0FBTztBQUNsQyxXQUFPLENBQUMsTUFBTTtBQUNWLFVBQUk7QUFDQSx1QkFBZSxTQUFTLE9BQU8sQ0FBQztBQUFBLE1BQ3BDLFNBQ08sS0FBSztBQUNSLHVCQUFlLFNBQVMsT0FBTyxHQUFHO0FBQUEsTUFDdEM7QUFBQSxJQUVKO0FBQUEsRUFDSjtBQUNBLFFBQU0sT0FBTyxXQUFZO0FBQ3JCLFFBQUksWUFBWTtBQUNoQixXQUFPLFNBQVMsUUFBUSxpQkFBaUI7QUFDckMsYUFBTyxXQUFZO0FBQ2YsWUFBSSxXQUFXO0FBQ1g7QUFBQSxRQUNKO0FBQ0Esb0JBQVk7QUFDWix3QkFBZ0IsTUFBTSxNQUFNLFNBQVM7QUFBQSxNQUN6QztBQUFBLElBQ0o7QUFBQSxFQUNKO0FBQ0EsUUFBTSxhQUFhO0FBQ25CLFFBQU0sNEJBQTRCLFdBQVcsa0JBQWtCO0FBRS9ELFdBQVMsZUFBZSxTQUFTLE9BQU8sT0FBTztBQUMzQyxVQUFNLGNBQWMsS0FBSztBQUN6QixRQUFJLFlBQVksT0FBTztBQUNuQixZQUFNLElBQUksVUFBVSxVQUFVO0FBQUEsSUFDbEM7QUFDQSxRQUFJLFFBQVEsV0FBVyxNQUFNLFlBQVk7QUFFckMsVUFBSSxPQUFPO0FBQ1gsVUFBSTtBQUNBLFlBQUksT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVLFlBQVk7QUFDMUQsaUJBQU8sU0FBUyxNQUFNO0FBQUEsUUFDMUI7QUFBQSxNQUNKLFNBQ08sS0FBSztBQUNSLG9CQUFZLE1BQU07QUFDZCx5QkFBZSxTQUFTLE9BQU8sR0FBRztBQUFBLFFBQ3RDLENBQUMsRUFBRTtBQUNILGVBQU87QUFBQSxNQUNYO0FBRUEsVUFBSSxVQUFVLFlBQVksaUJBQWlCLG9CQUN2QyxNQUFNLGVBQWUsV0FBVyxLQUFLLE1BQU0sZUFBZSxXQUFXLEtBQ3JFLE1BQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsNkJBQXFCLEtBQUs7QUFDMUIsdUJBQWUsU0FBUyxNQUFNLFdBQVcsR0FBRyxNQUFNLFdBQVcsQ0FBQztBQUFBLE1BQ2xFLFdBQ1MsVUFBVSxZQUFZLE9BQU8sU0FBUyxZQUFZO0FBQ3ZELFlBQUk7QUFDQSxlQUFLLEtBQUssT0FBTyxZQUFZLGFBQWEsU0FBUyxLQUFLLENBQUMsR0FBRyxZQUFZLGFBQWEsU0FBUyxLQUFLLENBQUMsQ0FBQztBQUFBLFFBQ3pHLFNBQ08sS0FBSztBQUNSLHNCQUFZLE1BQU07QUFDZCwyQkFBZSxTQUFTLE9BQU8sR0FBRztBQUFBLFVBQ3RDLENBQUMsRUFBRTtBQUFBLFFBQ1A7QUFBQSxNQUNKLE9BQ0s7QUFDRCxnQkFBUSxXQUFXLElBQUk7QUFDdkIsY0FBTSxRQUFRLFFBQVEsV0FBVztBQUNqQyxnQkFBUSxXQUFXLElBQUk7QUFDdkIsWUFBSSxRQUFRLGFBQWEsTUFBTSxlQUFlO0FBRTFDLGNBQUksVUFBVSxVQUFVO0FBR3BCLG9CQUFRLFdBQVcsSUFBSSxRQUFRLHdCQUF3QjtBQUN2RCxvQkFBUSxXQUFXLElBQUksUUFBUSx3QkFBd0I7QUFBQSxVQUMzRDtBQUFBLFFBQ0o7QUFHQSxZQUFJLFVBQVUsWUFBWSxpQkFBaUIsT0FBTztBQUU5QyxnQkFBTSxRQUFRQSxNQUFLLGVBQWVBLE1BQUssWUFBWSxRQUMvQ0EsTUFBSyxZQUFZLEtBQUssYUFBYTtBQUN2QyxjQUFJLE9BQU87QUFFUCxZQUFBSyxzQkFBcUIsT0FBTywyQkFBMkIsRUFBRSxjQUFjLE1BQU0sWUFBWSxPQUFPLFVBQVUsTUFBTSxPQUFPLE1BQU0sQ0FBQztBQUFBLFVBQ2xJO0FBQUEsUUFDSjtBQUNBLGlCQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sVUFBUztBQUMvQixrQ0FBd0IsU0FBUyxNQUFNLEdBQUcsR0FBRyxNQUFNLEdBQUcsR0FBRyxNQUFNLEdBQUcsR0FBRyxNQUFNLEdBQUcsQ0FBQztBQUFBLFFBQ25GO0FBQ0EsWUFBSSxNQUFNLFVBQVUsS0FBSyxTQUFTLFVBQVU7QUFDeEMsa0JBQVEsV0FBVyxJQUFJO0FBQ3ZCLGNBQUksdUJBQXVCO0FBQzNCLGNBQUk7QUFJQSxrQkFBTSxJQUFJLE1BQU0sNEJBQTRCLHVCQUF1QixLQUFLLEtBQ25FLFNBQVMsTUFBTSxRQUFRLE9BQU8sTUFBTSxRQUFRLEdBQUc7QUFBQSxVQUN4RCxTQUNPLEtBQUs7QUFDUixtQ0FBdUI7QUFBQSxVQUMzQjtBQUNBLGNBQUksMkNBQTJDO0FBRzNDLGlDQUFxQixnQkFBZ0I7QUFBQSxVQUN6QztBQUNBLCtCQUFxQixZQUFZO0FBQ2pDLCtCQUFxQixVQUFVO0FBQy9CLCtCQUFxQixPQUFPTCxNQUFLO0FBQ2pDLCtCQUFxQixPQUFPQSxNQUFLO0FBQ2pDLGlDQUF1QixLQUFLLG9CQUFvQjtBQUNoRCxjQUFJLGtCQUFrQjtBQUFBLFFBQzFCO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFFQSxXQUFPO0FBQUEsRUFDWDtBQUNBLFFBQU0sNEJBQTRCLFdBQVcseUJBQXlCO0FBQ3RFLFdBQVMscUJBQXFCLFNBQVM7QUFDbkMsUUFBSSxRQUFRLFdBQVcsTUFBTSxtQkFBbUI7QUFNNUMsVUFBSTtBQUNBLGNBQU0sVUFBVUEsTUFBSyx5QkFBeUI7QUFDOUMsWUFBSSxXQUFXLE9BQU8sWUFBWSxZQUFZO0FBQzFDLGtCQUFRLEtBQUssTUFBTSxFQUFFLFdBQVcsUUFBUSxXQUFXLEdBQUcsUUFBaUIsQ0FBQztBQUFBLFFBQzVFO0FBQUEsTUFDSixTQUNPLEtBQUs7QUFBQSxNQUNaO0FBQ0EsY0FBUSxXQUFXLElBQUk7QUFDdkIsZUFBUyxJQUFJLEdBQUcsSUFBSSx1QkFBdUIsUUFBUSxLQUFLO0FBQ3BELFlBQUksWUFBWSx1QkFBdUIsQ0FBQyxFQUFFLFNBQVM7QUFDL0MsaUNBQXVCLE9BQU8sR0FBRyxDQUFDO0FBQUEsUUFDdEM7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFDQSxXQUFTLHdCQUF3QixTQUFTLE1BQU0sY0FBYyxhQUFhLFlBQVk7QUFDbkYseUJBQXFCLE9BQU87QUFDNUIsVUFBTSxlQUFlLFFBQVEsV0FBVztBQUN4QyxVQUFNLFdBQVcsZUFDWixPQUFPLGdCQUFnQixhQUFjLGNBQWMsb0JBQ25ELE9BQU8sZUFBZSxhQUFjLGFBQ2pDO0FBQ1IsU0FBSyxrQkFBa0IsUUFBUSxNQUFNO0FBQ2pDLFVBQUk7QUFDQSxjQUFNLHFCQUFxQixRQUFRLFdBQVc7QUFDOUMsY0FBTSxtQkFBbUIsQ0FBQyxDQUFDLGdCQUFnQixrQkFBa0IsYUFBYSxhQUFhO0FBQ3ZGLFlBQUksa0JBQWtCO0FBRWxCLHVCQUFhLHdCQUF3QixJQUFJO0FBQ3pDLHVCQUFhLHdCQUF3QixJQUFJO0FBQUEsUUFDN0M7QUFFQSxjQUFNLFFBQVEsS0FBSyxJQUFJLFVBQVUsUUFBVyxvQkFBb0IsYUFBYSxvQkFBb0IsYUFBYSxvQkFDMUcsQ0FBQyxJQUNELENBQUMsa0JBQWtCLENBQUM7QUFDeEIsdUJBQWUsY0FBYyxNQUFNLEtBQUs7QUFBQSxNQUM1QyxTQUNPLE9BQU87QUFFVix1QkFBZSxjQUFjLE9BQU8sS0FBSztBQUFBLE1BQzdDO0FBQUEsSUFDSixHQUFHLFlBQVk7QUFBQSxFQUNuQjtBQUNBLFFBQU0sK0JBQStCO0FBQ3JDLFFBQU0sT0FBTyxXQUFZO0FBQUEsRUFBRTtBQUMzQixRQUFNLGlCQUFpQixPQUFPO0FBQUEsRUFDOUIsTUFBTSxpQkFBaUI7QUFBQSxJQUNuQixPQUFPLFdBQVc7QUFDZCxhQUFPO0FBQUEsSUFDWDtBQUFBLElBQ0EsT0FBTyxRQUFRLE9BQU87QUFDbEIsYUFBTyxlQUFlLElBQUksS0FBSyxJQUFJLEdBQUcsVUFBVSxLQUFLO0FBQUEsSUFDekQ7QUFBQSxJQUNBLE9BQU8sT0FBTyxPQUFPO0FBQ2pCLGFBQU8sZUFBZSxJQUFJLEtBQUssSUFBSSxHQUFHLFVBQVUsS0FBSztBQUFBLElBQ3pEO0FBQUEsSUFDQSxPQUFPLElBQUksUUFBUTtBQUNmLFVBQUksQ0FBQyxVQUFVLE9BQU8sT0FBTyxPQUFPLFFBQVEsTUFBTSxZQUFZO0FBQzFELGVBQU8sUUFBUSxPQUFPLElBQUksZUFBZSxDQUFDLEdBQUcsNEJBQTRCLENBQUM7QUFBQSxNQUM5RTtBQUNBLFlBQU0sV0FBVyxDQUFDO0FBQ2xCLFVBQUksUUFBUTtBQUNaLFVBQUk7QUFDQSxpQkFBUyxLQUFLLFFBQVE7QUFDbEI7QUFDQSxtQkFBUyxLQUFLLGlCQUFpQixRQUFRLENBQUMsQ0FBQztBQUFBLFFBQzdDO0FBQUEsTUFDSixTQUNPLEtBQUs7QUFDUixlQUFPLFFBQVEsT0FBTyxJQUFJLGVBQWUsQ0FBQyxHQUFHLDRCQUE0QixDQUFDO0FBQUEsTUFDOUU7QUFDQSxVQUFJLFVBQVUsR0FBRztBQUNiLGVBQU8sUUFBUSxPQUFPLElBQUksZUFBZSxDQUFDLEdBQUcsNEJBQTRCLENBQUM7QUFBQSxNQUM5RTtBQUNBLFVBQUksV0FBVztBQUNmLFlBQU0sU0FBUyxDQUFDO0FBQ2hCLGFBQU8sSUFBSSxpQkFBaUIsQ0FBQyxTQUFTLFdBQVc7QUFDN0MsaUJBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7QUFDdEMsbUJBQVMsQ0FBQyxFQUFFLEtBQUssT0FBSztBQUNsQixnQkFBSSxVQUFVO0FBQ1Y7QUFBQSxZQUNKO0FBQ0EsdUJBQVc7QUFDWCxvQkFBUSxDQUFDO0FBQUEsVUFDYixHQUFHLFNBQU87QUFDTixtQkFBTyxLQUFLLEdBQUc7QUFDZjtBQUNBLGdCQUFJLFVBQVUsR0FBRztBQUNiLHlCQUFXO0FBQ1gscUJBQU8sSUFBSSxlQUFlLFFBQVEsNEJBQTRCLENBQUM7QUFBQSxZQUNuRTtBQUFBLFVBQ0osQ0FBQztBQUFBLFFBQ0w7QUFBQSxNQUNKLENBQUM7QUFBQSxJQUNMO0FBQUEsSUFFQSxPQUFPLEtBQUssUUFBUTtBQUNoQixVQUFJO0FBQ0osVUFBSTtBQUNKLFVBQUksVUFBVSxJQUFJLEtBQUssQ0FBQyxLQUFLLFFBQVE7QUFDakMsa0JBQVU7QUFDVixpQkFBUztBQUFBLE1BQ2IsQ0FBQztBQUNELGVBQVMsVUFBVSxPQUFPO0FBQ3RCLGdCQUFRLEtBQUs7QUFBQSxNQUNqQjtBQUNBLGVBQVMsU0FBUyxPQUFPO0FBQ3JCLGVBQU8sS0FBSztBQUFBLE1BQ2hCO0FBQ0EsZUFBUyxTQUFTLFFBQVE7QUFDdEIsWUFBSSxDQUFDLFdBQVcsS0FBSyxHQUFHO0FBQ3BCLGtCQUFRLEtBQUssUUFBUSxLQUFLO0FBQUEsUUFDOUI7QUFDQSxjQUFNLEtBQUssV0FBVyxRQUFRO0FBQUEsTUFDbEM7QUFDQSxhQUFPO0FBQUEsSUFDWDtBQUFBLElBQ0EsT0FBTyxJQUFJLFFBQVE7QUFDZixhQUFPLGlCQUFpQixnQkFBZ0IsTUFBTTtBQUFBLElBQ2xEO0FBQUEsSUFDQSxPQUFPLFdBQVcsUUFBUTtBQUN0QixZQUFNLElBQUksUUFBUSxLQUFLLHFCQUFxQixtQkFBbUIsT0FBTztBQUN0RSxhQUFPLEVBQUUsZ0JBQWdCLFFBQVE7QUFBQSxRQUM3QixjQUFjLENBQUMsV0FBVyxFQUFFLFFBQVEsYUFBYSxNQUFNO0FBQUEsUUFDdkQsZUFBZSxDQUFDLFNBQVMsRUFBRSxRQUFRLFlBQVksUUFBUSxJQUFJO0FBQUEsTUFDL0QsQ0FBQztBQUFBLElBQ0w7QUFBQSxJQUNBLE9BQU8sZ0JBQWdCLFFBQVEsVUFBVTtBQUNyQyxVQUFJO0FBQ0osVUFBSTtBQUNKLFVBQUksVUFBVSxJQUFJLEtBQUssQ0FBQyxLQUFLLFFBQVE7QUFDakMsa0JBQVU7QUFDVixpQkFBUztBQUFBLE1BQ2IsQ0FBQztBQUVELFVBQUksa0JBQWtCO0FBQ3RCLFVBQUksYUFBYTtBQUNqQixZQUFNLGlCQUFpQixDQUFDO0FBQ3hCLGVBQVMsU0FBUyxRQUFRO0FBQ3RCLFlBQUksQ0FBQyxXQUFXLEtBQUssR0FBRztBQUNwQixrQkFBUSxLQUFLLFFBQVEsS0FBSztBQUFBLFFBQzlCO0FBQ0EsY0FBTSxnQkFBZ0I7QUFDdEIsWUFBSTtBQUNBLGdCQUFNLEtBQUssQ0FBQ00sV0FBVTtBQUNsQiwyQkFBZSxhQUFhLElBQUksV0FBVyxTQUFTLGFBQWFBLE1BQUssSUFBSUE7QUFDMUU7QUFDQSxnQkFBSSxvQkFBb0IsR0FBRztBQUN2QixzQkFBUSxjQUFjO0FBQUEsWUFDMUI7QUFBQSxVQUNKLEdBQUcsQ0FBQyxRQUFRO0FBQ1IsZ0JBQUksQ0FBQyxVQUFVO0FBQ1gscUJBQU8sR0FBRztBQUFBLFlBQ2QsT0FDSztBQUNELDZCQUFlLGFBQWEsSUFBSSxTQUFTLGNBQWMsR0FBRztBQUMxRDtBQUNBLGtCQUFJLG9CQUFvQixHQUFHO0FBQ3ZCLHdCQUFRLGNBQWM7QUFBQSxjQUMxQjtBQUFBLFlBQ0o7QUFBQSxVQUNKLENBQUM7QUFBQSxRQUNMLFNBQ08sU0FBUztBQUNaLGlCQUFPLE9BQU87QUFBQSxRQUNsQjtBQUNBO0FBQ0E7QUFBQSxNQUNKO0FBRUEseUJBQW1CO0FBQ25CLFVBQUksb0JBQW9CLEdBQUc7QUFDdkIsZ0JBQVEsY0FBYztBQUFBLE1BQzFCO0FBQ0EsYUFBTztBQUFBLElBQ1g7QUFBQSxJQUNBLFlBQVksVUFBVTtBQUNsQixZQUFNLFVBQVU7QUFDaEIsVUFBSSxFQUFFLG1CQUFtQixtQkFBbUI7QUFDeEMsY0FBTSxJQUFJLE1BQU0sZ0NBQWdDO0FBQUEsTUFDcEQ7QUFDQSxjQUFRLFdBQVcsSUFBSTtBQUN2QixjQUFRLFdBQVcsSUFBSSxDQUFDO0FBQ3hCLFVBQUk7QUFDQSxjQUFNLGNBQWMsS0FBSztBQUN6QixvQkFDSSxTQUFTLFlBQVksYUFBYSxTQUFTLFFBQVEsQ0FBQyxHQUFHLFlBQVksYUFBYSxTQUFTLFFBQVEsQ0FBQyxDQUFDO0FBQUEsTUFDM0csU0FDTyxPQUFPO0FBQ1YsdUJBQWUsU0FBUyxPQUFPLEtBQUs7QUFBQSxNQUN4QztBQUFBLElBQ0o7QUFBQSxJQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDdkIsYUFBTztBQUFBLElBQ1g7QUFBQSxJQUNBLEtBQUssT0FBTyxPQUFPLElBQUk7QUFDbkIsYUFBTztBQUFBLElBQ1g7QUFBQSxJQUNBLEtBQUssYUFBYSxZQUFZO0FBUzFCLFVBQUksSUFBSSxLQUFLLGNBQWMsT0FBTyxPQUFPO0FBQ3pDLFVBQUksQ0FBQyxLQUFLLE9BQU8sTUFBTSxZQUFZO0FBQy9CLFlBQUksS0FBSyxlQUFlO0FBQUEsTUFDNUI7QUFDQSxZQUFNLGVBQWUsSUFBSSxFQUFFLElBQUk7QUFDL0IsWUFBTSxPQUFPTixNQUFLO0FBQ2xCLFVBQUksS0FBSyxXQUFXLEtBQUssWUFBWTtBQUNqQyxhQUFLLFdBQVcsRUFBRSxLQUFLLE1BQU0sY0FBYyxhQUFhLFVBQVU7QUFBQSxNQUN0RSxPQUNLO0FBQ0QsZ0NBQXdCLE1BQU0sTUFBTSxjQUFjLGFBQWEsVUFBVTtBQUFBLE1BQzdFO0FBQ0EsYUFBTztBQUFBLElBQ1g7QUFBQSxJQUNBLE1BQU0sWUFBWTtBQUNkLGFBQU8sS0FBSyxLQUFLLE1BQU0sVUFBVTtBQUFBLElBQ3JDO0FBQUEsSUFDQSxRQUFRLFdBQVc7QUFFZixVQUFJLElBQUksS0FBSyxjQUFjLE9BQU8sT0FBTztBQUN6QyxVQUFJLENBQUMsS0FBSyxPQUFPLE1BQU0sWUFBWTtBQUMvQixZQUFJO0FBQUEsTUFDUjtBQUNBLFlBQU0sZUFBZSxJQUFJLEVBQUUsSUFBSTtBQUMvQixtQkFBYSxhQUFhLElBQUk7QUFDOUIsWUFBTSxPQUFPQSxNQUFLO0FBQ2xCLFVBQUksS0FBSyxXQUFXLEtBQUssWUFBWTtBQUNqQyxhQUFLLFdBQVcsRUFBRSxLQUFLLE1BQU0sY0FBYyxXQUFXLFNBQVM7QUFBQSxNQUNuRSxPQUNLO0FBQ0QsZ0NBQXdCLE1BQU0sTUFBTSxjQUFjLFdBQVcsU0FBUztBQUFBLE1BQzFFO0FBQ0EsYUFBTztBQUFBLElBQ1g7QUFBQSxFQUNKO0FBR0EsbUJBQWlCLFNBQVMsSUFBSSxpQkFBaUI7QUFDL0MsbUJBQWlCLFFBQVEsSUFBSSxpQkFBaUI7QUFDOUMsbUJBQWlCLE1BQU0sSUFBSSxpQkFBaUI7QUFDNUMsbUJBQWlCLEtBQUssSUFBSSxpQkFBaUI7QUFDM0MsUUFBTSxnQkFBZ0IsT0FBTyxhQUFhLElBQUksT0FBTyxTQUFTO0FBQzlELFNBQU8sU0FBUyxJQUFJO0FBQ3BCLFFBQU0sb0JBQW9CLFdBQVcsYUFBYTtBQUNsRCxXQUFTLFVBQVUsTUFBTTtBQUNyQixVQUFNLFFBQVEsS0FBSztBQUNuQixVQUFNLE9BQU9JLGdDQUErQixPQUFPLE1BQU07QUFDekQsUUFBSSxTQUFTLEtBQUssYUFBYSxTQUFTLENBQUMsS0FBSyxlQUFlO0FBR3pEO0FBQUEsSUFDSjtBQUNBLFVBQU0sZUFBZSxNQUFNO0FBRTNCLFVBQU0sVUFBVSxJQUFJO0FBQ3BCLFNBQUssVUFBVSxPQUFPLFNBQVUsV0FBVyxVQUFVO0FBQ2pELFlBQU0sVUFBVSxJQUFJLGlCQUFpQixDQUFDLFNBQVMsV0FBVztBQUN0RCxxQkFBYSxLQUFLLE1BQU0sU0FBUyxNQUFNO0FBQUEsTUFDM0MsQ0FBQztBQUNELGFBQU8sUUFBUSxLQUFLLFdBQVcsUUFBUTtBQUFBLElBQzNDO0FBQ0EsU0FBSyxpQkFBaUIsSUFBSTtBQUFBLEVBQzlCO0FBQ0EsTUFBSSxZQUFZO0FBQ2hCLFdBQVMsUUFBUSxJQUFJO0FBQ2pCLFdBQU8sU0FBVUgsT0FBTSxNQUFNO0FBQ3pCLFVBQUksZ0JBQWdCLEdBQUcsTUFBTUEsT0FBTSxJQUFJO0FBQ3ZDLFVBQUkseUJBQXlCLGtCQUFrQjtBQUMzQyxlQUFPO0FBQUEsTUFDWDtBQUNBLFVBQUksT0FBTyxjQUFjO0FBQ3pCLFVBQUksQ0FBQyxLQUFLLGlCQUFpQixHQUFHO0FBQzFCLGtCQUFVLElBQUk7QUFBQSxNQUNsQjtBQUNBLGFBQU87QUFBQSxJQUNYO0FBQUEsRUFDSjtBQUNBLE1BQUksZUFBZTtBQUNmLGNBQVUsYUFBYTtBQUN2QixnQkFBWSxRQUFRLFNBQVMsY0FBWSxRQUFRLFFBQVEsQ0FBQztBQUFBLEVBQzlEO0FBRUEsVUFBUUQsTUFBSyxXQUFXLHVCQUF1QixDQUFDLElBQUk7QUFDcEQsU0FBTztBQUNYLENBQUM7QUFJRCxLQUFLLGFBQWEsWUFBWSxDQUFDLFdBQVc7QUFFdEMsUUFBTSwyQkFBMkIsU0FBUyxVQUFVO0FBQ3BELFFBQU0sMkJBQTJCLFdBQVcsa0JBQWtCO0FBQzlELFFBQU0saUJBQWlCLFdBQVcsU0FBUztBQUMzQyxRQUFNLGVBQWUsV0FBVyxPQUFPO0FBQ3ZDLFFBQU0sc0JBQXNCLFNBQVMsV0FBVztBQUM1QyxRQUFJLE9BQU8sU0FBUyxZQUFZO0FBQzVCLFlBQU0sbUJBQW1CLEtBQUssd0JBQXdCO0FBQ3RELFVBQUksa0JBQWtCO0FBQ2xCLFlBQUksT0FBTyxxQkFBcUIsWUFBWTtBQUN4QyxpQkFBTyx5QkFBeUIsS0FBSyxnQkFBZ0I7QUFBQSxRQUN6RCxPQUNLO0FBQ0QsaUJBQU8sT0FBTyxVQUFVLFNBQVMsS0FBSyxnQkFBZ0I7QUFBQSxRQUMxRDtBQUFBLE1BQ0o7QUFDQSxVQUFJLFNBQVMsU0FBUztBQUNsQixjQUFNLGdCQUFnQixPQUFPLGNBQWM7QUFDM0MsWUFBSSxlQUFlO0FBQ2YsaUJBQU8seUJBQXlCLEtBQUssYUFBYTtBQUFBLFFBQ3REO0FBQUEsTUFDSjtBQUNBLFVBQUksU0FBUyxPQUFPO0FBQ2hCLGNBQU0sY0FBYyxPQUFPLFlBQVk7QUFDdkMsWUFBSSxhQUFhO0FBQ2IsaUJBQU8seUJBQXlCLEtBQUssV0FBVztBQUFBLFFBQ3BEO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFDQSxXQUFPLHlCQUF5QixLQUFLLElBQUk7QUFBQSxFQUM3QztBQUNBLHNCQUFvQix3QkFBd0IsSUFBSTtBQUNoRCxXQUFTLFVBQVUsV0FBVztBQUU5QixRQUFNLHlCQUF5QixPQUFPLFVBQVU7QUFDaEQsUUFBTSwyQkFBMkI7QUFDakMsU0FBTyxVQUFVLFdBQVcsV0FBWTtBQUNwQyxRQUFJLE9BQU8sWUFBWSxjQUFjLGdCQUFnQixTQUFTO0FBQzFELGFBQU87QUFBQSxJQUNYO0FBQ0EsV0FBTyx1QkFBdUIsS0FBSyxJQUFJO0FBQUEsRUFDM0M7QUFDSixDQUFDO0FBTUQsSUFBSSxtQkFBbUI7QUFDdkIsSUFBSSxPQUFPLFdBQVcsYUFBYTtBQUMvQixNQUFJO0FBQ0EsVUFBTSxVQUFVLE9BQU8sZUFBZSxDQUFDLEdBQUcsV0FBVztBQUFBLE1BQ2pELEtBQUssV0FBWTtBQUNiLDJCQUFtQjtBQUFBLE1BQ3ZCO0FBQUEsSUFDSixDQUFDO0FBSUQsV0FBTyxpQkFBaUIsUUFBUSxTQUFTLE9BQU87QUFDaEQsV0FBTyxvQkFBb0IsUUFBUSxTQUFTLE9BQU87QUFBQSxFQUN2RCxTQUNPLEtBQUs7QUFDUix1QkFBbUI7QUFBQSxFQUN2QjtBQUNKO0FBRUEsSUFBTSxpQ0FBaUM7QUFBQSxFQUNuQyxNQUFNO0FBQ1Y7QUFDQSxJQUFNLHVCQUF1QixDQUFDO0FBQzlCLElBQU0sZ0JBQWdCLENBQUM7QUFDdkIsSUFBTSx5QkFBeUIsSUFBSSxPQUFPLE1BQU0scUJBQXFCLHFCQUFxQjtBQUMxRixJQUFNLCtCQUErQixXQUFXLG9CQUFvQjtBQUNwRSxTQUFTLGtCQUFrQixXQUFXLG1CQUFtQjtBQUNyRCxRQUFNLGtCQUFrQixvQkFBb0Isa0JBQWtCLFNBQVMsSUFBSSxhQUFhO0FBQ3hGLFFBQU0saUJBQWlCLG9CQUFvQixrQkFBa0IsU0FBUyxJQUFJLGFBQWE7QUFDdkYsUUFBTSxTQUFTLHFCQUFxQjtBQUNwQyxRQUFNLGdCQUFnQixxQkFBcUI7QUFDM0MsdUJBQXFCLFNBQVMsSUFBSSxDQUFDO0FBQ25DLHVCQUFxQixTQUFTLEVBQUUsU0FBUyxJQUFJO0FBQzdDLHVCQUFxQixTQUFTLEVBQUUsUUFBUSxJQUFJO0FBQ2hEO0FBQ0EsU0FBUyxpQkFBaUJPLFVBQVMsS0FBSyxNQUFNLGNBQWM7QUFDeEQsUUFBTSxxQkFBc0IsZ0JBQWdCLGFBQWEsT0FBUTtBQUNqRSxRQUFNLHdCQUF5QixnQkFBZ0IsYUFBYSxNQUFPO0FBQ25FLFFBQU0sMkJBQTRCLGdCQUFnQixhQUFhLGFBQWM7QUFDN0UsUUFBTSxzQ0FBdUMsZ0JBQWdCLGFBQWEsU0FBVTtBQUNwRixRQUFNLDZCQUE2QixXQUFXLGtCQUFrQjtBQUNoRSxRQUFNLDRCQUE0QixNQUFNLHFCQUFxQjtBQUM3RCxRQUFNLHlCQUF5QjtBQUMvQixRQUFNLGdDQUFnQyxNQUFNLHlCQUF5QjtBQUNyRSxRQUFNLGFBQWEsU0FBVSxNQUFNLFFBQVEsT0FBTztBQUc5QyxRQUFJLEtBQUssV0FBVztBQUNoQjtBQUFBLElBQ0o7QUFDQSxVQUFNLFdBQVcsS0FBSztBQUN0QixRQUFJLE9BQU8sYUFBYSxZQUFZLFNBQVMsYUFBYTtBQUV0RCxXQUFLLFdBQVcsQ0FBQ0MsV0FBVSxTQUFTLFlBQVlBLE1BQUs7QUFDckQsV0FBSyxtQkFBbUI7QUFBQSxJQUM1QjtBQUtBLFFBQUk7QUFDSixRQUFJO0FBQ0EsV0FBSyxPQUFPLE1BQU0sUUFBUSxDQUFDLEtBQUssQ0FBQztBQUFBLElBQ3JDLFNBQ08sS0FBSztBQUNSLGNBQVE7QUFBQSxJQUNaO0FBQ0EsVUFBTSxVQUFVLEtBQUs7QUFDckIsUUFBSSxXQUFXLE9BQU8sWUFBWSxZQUFZLFFBQVEsTUFBTTtBQUl4RCxZQUFNTixZQUFXLEtBQUssbUJBQW1CLEtBQUssbUJBQW1CLEtBQUs7QUFDdEUsYUFBTyxxQkFBcUIsRUFBRSxLQUFLLFFBQVEsTUFBTSxNQUFNQSxXQUFVLE9BQU87QUFBQSxJQUM1RTtBQUNBLFdBQU87QUFBQSxFQUNYO0FBQ0EsV0FBUyxlQUFlLFNBQVMsT0FBTyxXQUFXO0FBRy9DLFlBQVEsU0FBU0ssU0FBUTtBQUN6QixRQUFJLENBQUMsT0FBTztBQUNSO0FBQUEsSUFDSjtBQUdBLFVBQU0sU0FBUyxXQUFXLE1BQU0sVUFBVUE7QUFDMUMsVUFBTSxRQUFRLE9BQU8scUJBQXFCLE1BQU0sSUFBSSxFQUFFLFlBQVksV0FBVyxTQUFTLENBQUM7QUFDdkYsUUFBSSxPQUFPO0FBQ1AsWUFBTSxTQUFTLENBQUM7QUFHaEIsVUFBSSxNQUFNLFdBQVcsR0FBRztBQUNwQixjQUFNLE1BQU0sV0FBVyxNQUFNLENBQUMsR0FBRyxRQUFRLEtBQUs7QUFDOUMsZUFBTyxPQUFPLEtBQUssR0FBRztBQUFBLE1BQzFCLE9BQ0s7QUFJRCxjQUFNLFlBQVksTUFBTSxNQUFNO0FBQzlCLGlCQUFTLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLO0FBQ3ZDLGNBQUksU0FBUyxNQUFNLDRCQUE0QixNQUFNLE1BQU07QUFDdkQ7QUFBQSxVQUNKO0FBQ0EsZ0JBQU0sTUFBTSxXQUFXLFVBQVUsQ0FBQyxHQUFHLFFBQVEsS0FBSztBQUNsRCxpQkFBTyxPQUFPLEtBQUssR0FBRztBQUFBLFFBQzFCO0FBQUEsTUFDSjtBQUdBLFVBQUksT0FBTyxXQUFXLEdBQUc7QUFDckIsY0FBTSxPQUFPLENBQUM7QUFBQSxNQUNsQixPQUNLO0FBQ0QsaUJBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7QUFDcEMsZ0JBQU0sTUFBTSxPQUFPLENBQUM7QUFDcEIsY0FBSSx3QkFBd0IsTUFBTTtBQUM5QixrQkFBTTtBQUFBLFVBQ1YsQ0FBQztBQUFBLFFBQ0w7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFFQSxRQUFNLDBCQUEwQixTQUFVLE9BQU87QUFDN0MsV0FBTyxlQUFlLE1BQU0sT0FBTyxLQUFLO0FBQUEsRUFDNUM7QUFFQSxRQUFNLGlDQUFpQyxTQUFVLE9BQU87QUFDcEQsV0FBTyxlQUFlLE1BQU0sT0FBTyxJQUFJO0FBQUEsRUFDM0M7QUFDQSxXQUFTLHdCQUF3QixLQUFLRSxlQUFjO0FBQ2hELFFBQUksQ0FBQyxLQUFLO0FBQ04sYUFBTztBQUFBLElBQ1g7QUFDQSxRQUFJLG9CQUFvQjtBQUN4QixRQUFJQSxpQkFBZ0JBLGNBQWEsU0FBUyxRQUFXO0FBQ2pELDBCQUFvQkEsY0FBYTtBQUFBLElBQ3JDO0FBQ0EsVUFBTSxrQkFBa0JBLGlCQUFnQkEsY0FBYTtBQUNyRCxRQUFJLGlCQUFpQjtBQUNyQixRQUFJQSxpQkFBZ0JBLGNBQWEsV0FBVyxRQUFXO0FBQ25ELHVCQUFpQkEsY0FBYTtBQUFBLElBQ2xDO0FBQ0EsUUFBSSxlQUFlO0FBQ25CLFFBQUlBLGlCQUFnQkEsY0FBYSxPQUFPLFFBQVc7QUFDL0MscUJBQWVBLGNBQWE7QUFBQSxJQUNoQztBQUNBLFFBQUksUUFBUTtBQUNaLFdBQU8sU0FBUyxDQUFDLE1BQU0sZUFBZSxrQkFBa0IsR0FBRztBQUN2RCxjQUFRLHFCQUFxQixLQUFLO0FBQUEsSUFDdEM7QUFDQSxRQUFJLENBQUMsU0FBUyxJQUFJLGtCQUFrQixHQUFHO0FBRW5DLGNBQVE7QUFBQSxJQUNaO0FBQ0EsUUFBSSxDQUFDLE9BQU87QUFDUixhQUFPO0FBQUEsSUFDWDtBQUNBLFFBQUksTUFBTSwwQkFBMEIsR0FBRztBQUNuQyxhQUFPO0FBQUEsSUFDWDtBQUNBLFVBQU0sb0JBQW9CQSxpQkFBZ0JBLGNBQWE7QUFHdkQsVUFBTSxXQUFXLENBQUM7QUFDbEIsVUFBTSx5QkFBeUIsTUFBTSwwQkFBMEIsSUFBSSxNQUFNLGtCQUFrQjtBQUMzRixVQUFNLDRCQUE0QixNQUFNLFdBQVcscUJBQXFCLENBQUMsSUFDckUsTUFBTSxxQkFBcUI7QUFDL0IsVUFBTSxrQkFBa0IsTUFBTSxXQUFXLHdCQUF3QixDQUFDLElBQzlELE1BQU0sd0JBQXdCO0FBQ2xDLFVBQU0sMkJBQTJCLE1BQU0sV0FBVyxtQ0FBbUMsQ0FBQyxJQUNsRixNQUFNLG1DQUFtQztBQUM3QyxRQUFJO0FBQ0osUUFBSUEsaUJBQWdCQSxjQUFhLFNBQVM7QUFDdEMsbUNBQTZCLE1BQU0sV0FBV0EsY0FBYSxPQUFPLENBQUMsSUFDL0QsTUFBTUEsY0FBYSxPQUFPO0FBQUEsSUFDbEM7QUFLQSxhQUFTLDBCQUEwQixTQUFTLFNBQVM7QUFDakQsVUFBSSxDQUFDLG9CQUFvQixPQUFPLFlBQVksWUFBWSxTQUFTO0FBSTdELGVBQU8sQ0FBQyxDQUFDLFFBQVE7QUFBQSxNQUNyQjtBQUNBLFVBQUksQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTO0FBQy9CLGVBQU87QUFBQSxNQUNYO0FBQ0EsVUFBSSxPQUFPLFlBQVksV0FBVztBQUM5QixlQUFPLEVBQUUsU0FBUyxTQUFTLFNBQVMsS0FBSztBQUFBLE1BQzdDO0FBQ0EsVUFBSSxDQUFDLFNBQVM7QUFDVixlQUFPLEVBQUUsU0FBUyxLQUFLO0FBQUEsTUFDM0I7QUFDQSxVQUFJLE9BQU8sWUFBWSxZQUFZLFFBQVEsWUFBWSxPQUFPO0FBQzFELGVBQU8sRUFBRSxHQUFHLFNBQVMsU0FBUyxLQUFLO0FBQUEsTUFDdkM7QUFDQSxhQUFPO0FBQUEsSUFDWDtBQUNBLFVBQU0sdUJBQXVCLFNBQVUsTUFBTTtBQUd6QyxVQUFJLFNBQVMsWUFBWTtBQUNyQjtBQUFBLE1BQ0o7QUFDQSxhQUFPLHVCQUF1QixLQUFLLFNBQVMsUUFBUSxTQUFTLFdBQVcsU0FBUyxVQUFVLGlDQUFpQyx5QkFBeUIsU0FBUyxPQUFPO0FBQUEsSUFDeks7QUFDQSxVQUFNLHFCQUFxQixTQUFVLE1BQU07QUFJdkMsVUFBSSxDQUFDLEtBQUssV0FBVztBQUNqQixjQUFNLG1CQUFtQixxQkFBcUIsS0FBSyxTQUFTO0FBQzVELFlBQUk7QUFDSixZQUFJLGtCQUFrQjtBQUNsQiw0QkFBa0IsaUJBQWlCLEtBQUssVUFBVSxXQUFXLFNBQVM7QUFBQSxRQUMxRTtBQUNBLGNBQU0sZ0JBQWdCLG1CQUFtQixLQUFLLE9BQU8sZUFBZTtBQUNwRSxZQUFJLGVBQWU7QUFDZixtQkFBUyxJQUFJLEdBQUcsSUFBSSxjQUFjLFFBQVEsS0FBSztBQUMzQyxrQkFBTSxlQUFlLGNBQWMsQ0FBQztBQUNwQyxnQkFBSSxpQkFBaUIsTUFBTTtBQUN2Qiw0QkFBYyxPQUFPLEdBQUcsQ0FBQztBQUV6QixtQkFBSyxZQUFZO0FBQ2pCLGtCQUFJLGNBQWMsV0FBVyxHQUFHO0FBRzVCLHFCQUFLLGFBQWE7QUFDbEIscUJBQUssT0FBTyxlQUFlLElBQUk7QUFBQSxjQUNuQztBQUNBO0FBQUEsWUFDSjtBQUFBLFVBQ0o7QUFBQSxRQUNKO0FBQUEsTUFDSjtBQUlBLFVBQUksQ0FBQyxLQUFLLFlBQVk7QUFDbEI7QUFBQSxNQUNKO0FBQ0EsYUFBTywwQkFBMEIsS0FBSyxLQUFLLFFBQVEsS0FBSyxXQUFXLEtBQUssVUFBVSxpQ0FBaUMseUJBQXlCLEtBQUssT0FBTztBQUFBLElBQzVKO0FBQ0EsVUFBTSwwQkFBMEIsU0FBVSxNQUFNO0FBQzVDLGFBQU8sdUJBQXVCLEtBQUssU0FBUyxRQUFRLFNBQVMsV0FBVyxLQUFLLFFBQVEsU0FBUyxPQUFPO0FBQUEsSUFDekc7QUFDQSxVQUFNLHdCQUF3QixTQUFVLE1BQU07QUFDMUMsYUFBTywyQkFBMkIsS0FBSyxTQUFTLFFBQVEsU0FBUyxXQUFXLEtBQUssUUFBUSxTQUFTLE9BQU87QUFBQSxJQUM3RztBQUNBLFVBQU0sd0JBQXdCLFNBQVUsTUFBTTtBQUMxQyxhQUFPLDBCQUEwQixLQUFLLEtBQUssUUFBUSxLQUFLLFdBQVcsS0FBSyxRQUFRLEtBQUssT0FBTztBQUFBLElBQ2hHO0FBQ0EsVUFBTSxpQkFBaUIsb0JBQW9CLHVCQUF1QjtBQUNsRSxVQUFNLGVBQWUsb0JBQW9CLHFCQUFxQjtBQUM5RCxVQUFNLGdDQUFnQyxTQUFVLE1BQU0sVUFBVTtBQUM1RCxZQUFNLGlCQUFpQixPQUFPO0FBQzlCLGFBQVEsbUJBQW1CLGNBQWMsS0FBSyxhQUFhLFlBQ3RELG1CQUFtQixZQUFZLEtBQUsscUJBQXFCO0FBQUEsSUFDbEU7QUFDQSxVQUFNLFVBQVdBLGlCQUFnQkEsY0FBYSxPQUFRQSxjQUFhLE9BQU87QUFDMUUsVUFBTSxrQkFBa0IsS0FBSyxXQUFXLGtCQUFrQixDQUFDO0FBQzNELFVBQU0sZ0JBQWdCRixTQUFRLFdBQVcsZ0JBQWdCLENBQUM7QUFDMUQsVUFBTSxrQkFBa0IsU0FBVSxnQkFBZ0IsV0FBVyxrQkFBa0IsZ0JBQWdCRyxnQkFBZSxPQUFPLFVBQVUsT0FBTztBQUNsSSxhQUFPLFdBQVk7QUFDZixjQUFNLFNBQVMsUUFBUUg7QUFDdkIsWUFBSSxZQUFZLFVBQVUsQ0FBQztBQUMzQixZQUFJRSxpQkFBZ0JBLGNBQWEsbUJBQW1CO0FBQ2hELHNCQUFZQSxjQUFhLGtCQUFrQixTQUFTO0FBQUEsUUFDeEQ7QUFDQSxZQUFJLFdBQVcsVUFBVSxDQUFDO0FBQzFCLFlBQUksQ0FBQyxVQUFVO0FBQ1gsaUJBQU8sZUFBZSxNQUFNLE1BQU0sU0FBUztBQUFBLFFBQy9DO0FBQ0EsWUFBSSxVQUFVLGNBQWMscUJBQXFCO0FBRTdDLGlCQUFPLGVBQWUsTUFBTSxNQUFNLFNBQVM7QUFBQSxRQUMvQztBQUlBLFlBQUksZ0JBQWdCO0FBQ3BCLFlBQUksT0FBTyxhQUFhLFlBQVk7QUFDaEMsY0FBSSxDQUFDLFNBQVMsYUFBYTtBQUN2QixtQkFBTyxlQUFlLE1BQU0sTUFBTSxTQUFTO0FBQUEsVUFDL0M7QUFDQSwwQkFBZ0I7QUFBQSxRQUNwQjtBQUNBLFlBQUksbUJBQW1CLENBQUMsZ0JBQWdCLGdCQUFnQixVQUFVLFFBQVEsU0FBUyxHQUFHO0FBQ2xGO0FBQUEsUUFDSjtBQUNBLGNBQU0sVUFBVSxvQkFBb0IsQ0FBQyxDQUFDLGlCQUFpQixjQUFjLFFBQVEsU0FBUyxNQUFNO0FBQzVGLGNBQU0sVUFBVSwwQkFBMEIsVUFBVSxDQUFDLEdBQUcsT0FBTztBQUMvRCxZQUFJLGlCQUFpQjtBQUVqQixtQkFBUyxJQUFJLEdBQUcsSUFBSSxnQkFBZ0IsUUFBUSxLQUFLO0FBQzdDLGdCQUFJLGNBQWMsZ0JBQWdCLENBQUMsR0FBRztBQUNsQyxrQkFBSSxTQUFTO0FBQ1QsdUJBQU8sZUFBZSxLQUFLLFFBQVEsV0FBVyxVQUFVLE9BQU87QUFBQSxjQUNuRSxPQUNLO0FBQ0QsdUJBQU8sZUFBZSxNQUFNLE1BQU0sU0FBUztBQUFBLGNBQy9DO0FBQUEsWUFDSjtBQUFBLFVBQ0o7QUFBQSxRQUNKO0FBQ0EsY0FBTSxVQUFVLENBQUMsVUFBVSxRQUFRLE9BQU8sWUFBWSxZQUFZLE9BQU8sUUFBUTtBQUNqRixjQUFNLE9BQU8sV0FBVyxPQUFPLFlBQVksV0FBVyxRQUFRLE9BQU87QUFDckUsY0FBTSxPQUFPLEtBQUs7QUFDbEIsWUFBSSxtQkFBbUIscUJBQXFCLFNBQVM7QUFDckQsWUFBSSxDQUFDLGtCQUFrQjtBQUNuQiw0QkFBa0IsV0FBVyxpQkFBaUI7QUFDOUMsNkJBQW1CLHFCQUFxQixTQUFTO0FBQUEsUUFDckQ7QUFDQSxjQUFNLGtCQUFrQixpQkFBaUIsVUFBVSxXQUFXLFNBQVM7QUFDdkUsWUFBSSxnQkFBZ0IsT0FBTyxlQUFlO0FBQzFDLFlBQUksYUFBYTtBQUNqQixZQUFJLGVBQWU7QUFFZix1QkFBYTtBQUNiLGNBQUksZ0JBQWdCO0FBQ2hCLHFCQUFTLElBQUksR0FBRyxJQUFJLGNBQWMsUUFBUSxLQUFLO0FBQzNDLGtCQUFJLFFBQVEsY0FBYyxDQUFDLEdBQUcsUUFBUSxHQUFHO0FBRXJDO0FBQUEsY0FDSjtBQUFBLFlBQ0o7QUFBQSxVQUNKO0FBQUEsUUFDSixPQUNLO0FBQ0QsMEJBQWdCLE9BQU8sZUFBZSxJQUFJLENBQUM7QUFBQSxRQUMvQztBQUNBLFlBQUk7QUFDSixjQUFNLGtCQUFrQixPQUFPLFlBQVksTUFBTTtBQUNqRCxjQUFNLGVBQWUsY0FBYyxlQUFlO0FBQ2xELFlBQUksY0FBYztBQUNkLG1CQUFTLGFBQWEsU0FBUztBQUFBLFFBQ25DO0FBQ0EsWUFBSSxDQUFDLFFBQVE7QUFDVCxtQkFBUyxrQkFBa0IsYUFDdEIsb0JBQW9CLGtCQUFrQixTQUFTLElBQUk7QUFBQSxRQUM1RDtBQUdBLGlCQUFTLFVBQVU7QUFDbkIsWUFBSSxNQUFNO0FBSU4sbUJBQVMsUUFBUSxPQUFPO0FBQUEsUUFDNUI7QUFDQSxpQkFBUyxTQUFTO0FBQ2xCLGlCQUFTLFVBQVU7QUFDbkIsaUJBQVMsWUFBWTtBQUNyQixpQkFBUyxhQUFhO0FBQ3RCLGNBQU0sT0FBTyxvQkFBb0IsaUNBQWlDO0FBRWxFLFlBQUksTUFBTTtBQUNOLGVBQUssV0FBVztBQUFBLFFBQ3BCO0FBQ0EsY0FBTSxPQUFPLEtBQUssa0JBQWtCLFFBQVEsVUFBVSxNQUFNLGtCQUFrQixjQUFjO0FBRzVGLGlCQUFTLFNBQVM7QUFFbEIsWUFBSSxNQUFNO0FBQ04sZUFBSyxXQUFXO0FBQUEsUUFDcEI7QUFHQSxZQUFJLE1BQU07QUFDTixrQkFBUSxPQUFPO0FBQUEsUUFDbkI7QUFDQSxZQUFJLEVBQUUsQ0FBQyxvQkFBb0IsT0FBTyxLQUFLLFlBQVksWUFBWTtBQUczRCxlQUFLLFVBQVU7QUFBQSxRQUNuQjtBQUNBLGFBQUssU0FBUztBQUNkLGFBQUssVUFBVTtBQUNmLGFBQUssWUFBWTtBQUNqQixZQUFJLGVBQWU7QUFFZixlQUFLLG1CQUFtQjtBQUFBLFFBQzVCO0FBQ0EsWUFBSSxDQUFDLFNBQVM7QUFDVix3QkFBYyxLQUFLLElBQUk7QUFBQSxRQUMzQixPQUNLO0FBQ0Qsd0JBQWMsUUFBUSxJQUFJO0FBQUEsUUFDOUI7QUFDQSxZQUFJQyxlQUFjO0FBQ2QsaUJBQU87QUFBQSxRQUNYO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFDQSxVQUFNLGtCQUFrQixJQUFJLGdCQUFnQix3QkFBd0IsMkJBQTJCLGdCQUFnQixjQUFjLFlBQVk7QUFDekksUUFBSSw0QkFBNEI7QUFDNUIsWUFBTSxzQkFBc0IsSUFBSSxnQkFBZ0IsNEJBQTRCLCtCQUErQix1QkFBdUIsY0FBYyxjQUFjLElBQUk7QUFBQSxJQUN0SztBQUNBLFVBQU0scUJBQXFCLElBQUksV0FBWTtBQUN2QyxZQUFNLFNBQVMsUUFBUUg7QUFDdkIsVUFBSSxZQUFZLFVBQVUsQ0FBQztBQUMzQixVQUFJRSxpQkFBZ0JBLGNBQWEsbUJBQW1CO0FBQ2hELG9CQUFZQSxjQUFhLGtCQUFrQixTQUFTO0FBQUEsTUFDeEQ7QUFDQSxZQUFNLFVBQVUsVUFBVSxDQUFDO0FBQzNCLFlBQU0sVUFBVSxDQUFDLFVBQVUsUUFBUSxPQUFPLFlBQVksWUFBWSxPQUFPLFFBQVE7QUFDakYsWUFBTSxXQUFXLFVBQVUsQ0FBQztBQUM1QixVQUFJLENBQUMsVUFBVTtBQUNYLGVBQU8sMEJBQTBCLE1BQU0sTUFBTSxTQUFTO0FBQUEsTUFDMUQ7QUFDQSxVQUFJLG1CQUNBLENBQUMsZ0JBQWdCLDJCQUEyQixVQUFVLFFBQVEsU0FBUyxHQUFHO0FBQzFFO0FBQUEsTUFDSjtBQUNBLFlBQU0sbUJBQW1CLHFCQUFxQixTQUFTO0FBQ3ZELFVBQUk7QUFDSixVQUFJLGtCQUFrQjtBQUNsQiwwQkFBa0IsaUJBQWlCLFVBQVUsV0FBVyxTQUFTO0FBQUEsTUFDckU7QUFDQSxZQUFNLGdCQUFnQixtQkFBbUIsT0FBTyxlQUFlO0FBQy9ELFVBQUksZUFBZTtBQUNmLGlCQUFTLElBQUksR0FBRyxJQUFJLGNBQWMsUUFBUSxLQUFLO0FBQzNDLGdCQUFNLGVBQWUsY0FBYyxDQUFDO0FBQ3BDLGNBQUksUUFBUSxjQUFjLFFBQVEsR0FBRztBQUNqQywwQkFBYyxPQUFPLEdBQUcsQ0FBQztBQUV6Qix5QkFBYSxZQUFZO0FBQ3pCLGdCQUFJLGNBQWMsV0FBVyxHQUFHO0FBRzVCLDJCQUFhLGFBQWE7QUFDMUIscUJBQU8sZUFBZSxJQUFJO0FBSTFCLGtCQUFJLE9BQU8sY0FBYyxVQUFVO0FBQy9CLHNCQUFNLG1CQUFtQixxQkFBcUIsZ0JBQWdCO0FBQzlELHVCQUFPLGdCQUFnQixJQUFJO0FBQUEsY0FDL0I7QUFBQSxZQUNKO0FBQ0EseUJBQWEsS0FBSyxXQUFXLFlBQVk7QUFDekMsZ0JBQUksY0FBYztBQUNkLHFCQUFPO0FBQUEsWUFDWDtBQUNBO0FBQUEsVUFDSjtBQUFBLFFBQ0o7QUFBQSxNQUNKO0FBS0EsYUFBTywwQkFBMEIsTUFBTSxNQUFNLFNBQVM7QUFBQSxJQUMxRDtBQUNBLFVBQU0sd0JBQXdCLElBQUksV0FBWTtBQUMxQyxZQUFNLFNBQVMsUUFBUUY7QUFDdkIsVUFBSSxZQUFZLFVBQVUsQ0FBQztBQUMzQixVQUFJRSxpQkFBZ0JBLGNBQWEsbUJBQW1CO0FBQ2hELG9CQUFZQSxjQUFhLGtCQUFrQixTQUFTO0FBQUEsTUFDeEQ7QUFDQSxZQUFNLFlBQVksQ0FBQztBQUNuQixZQUFNLFFBQVEsZUFBZSxRQUFRLG9CQUFvQixrQkFBa0IsU0FBUyxJQUFJLFNBQVM7QUFDakcsZUFBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUNuQyxjQUFNLE9BQU8sTUFBTSxDQUFDO0FBQ3BCLFlBQUksV0FBVyxLQUFLLG1CQUFtQixLQUFLLG1CQUFtQixLQUFLO0FBQ3BFLGtCQUFVLEtBQUssUUFBUTtBQUFBLE1BQzNCO0FBQ0EsYUFBTztBQUFBLElBQ1g7QUFDQSxVQUFNLG1DQUFtQyxJQUFJLFdBQVk7QUFDckQsWUFBTSxTQUFTLFFBQVFGO0FBQ3ZCLFVBQUksWUFBWSxVQUFVLENBQUM7QUFDM0IsVUFBSSxDQUFDLFdBQVc7QUFDWixjQUFNLE9BQU8sT0FBTyxLQUFLLE1BQU07QUFDL0IsaUJBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUs7QUFDbEMsZ0JBQU0sT0FBTyxLQUFLLENBQUM7QUFDbkIsZ0JBQU0sUUFBUSx1QkFBdUIsS0FBSyxJQUFJO0FBQzlDLGNBQUksVUFBVSxTQUFTLE1BQU0sQ0FBQztBQUs5QixjQUFJLFdBQVcsWUFBWSxrQkFBa0I7QUFDekMsaUJBQUssbUNBQW1DLEVBQUUsS0FBSyxNQUFNLE9BQU87QUFBQSxVQUNoRTtBQUFBLFFBQ0o7QUFFQSxhQUFLLG1DQUFtQyxFQUFFLEtBQUssTUFBTSxnQkFBZ0I7QUFBQSxNQUN6RSxPQUNLO0FBQ0QsWUFBSUUsaUJBQWdCQSxjQUFhLG1CQUFtQjtBQUNoRCxzQkFBWUEsY0FBYSxrQkFBa0IsU0FBUztBQUFBLFFBQ3hEO0FBQ0EsY0FBTSxtQkFBbUIscUJBQXFCLFNBQVM7QUFDdkQsWUFBSSxrQkFBa0I7QUFDbEIsZ0JBQU0sa0JBQWtCLGlCQUFpQixTQUFTO0FBQ2xELGdCQUFNLHlCQUF5QixpQkFBaUIsUUFBUTtBQUN4RCxnQkFBTSxRQUFRLE9BQU8sZUFBZTtBQUNwQyxnQkFBTSxlQUFlLE9BQU8sc0JBQXNCO0FBQ2xELGNBQUksT0FBTztBQUNQLGtCQUFNLGNBQWMsTUFBTSxNQUFNO0FBQ2hDLHFCQUFTLElBQUksR0FBRyxJQUFJLFlBQVksUUFBUSxLQUFLO0FBQ3pDLG9CQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzFCLGtCQUFJLFdBQVcsS0FBSyxtQkFBbUIsS0FBSyxtQkFBbUIsS0FBSztBQUNwRSxtQkFBSyxxQkFBcUIsRUFBRSxLQUFLLE1BQU0sV0FBVyxVQUFVLEtBQUssT0FBTztBQUFBLFlBQzVFO0FBQUEsVUFDSjtBQUNBLGNBQUksY0FBYztBQUNkLGtCQUFNLGNBQWMsYUFBYSxNQUFNO0FBQ3ZDLHFCQUFTLElBQUksR0FBRyxJQUFJLFlBQVksUUFBUSxLQUFLO0FBQ3pDLG9CQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzFCLGtCQUFJLFdBQVcsS0FBSyxtQkFBbUIsS0FBSyxtQkFBbUIsS0FBSztBQUNwRSxtQkFBSyxxQkFBcUIsRUFBRSxLQUFLLE1BQU0sV0FBVyxVQUFVLEtBQUssT0FBTztBQUFBLFlBQzVFO0FBQUEsVUFDSjtBQUFBLFFBQ0o7QUFBQSxNQUNKO0FBQ0EsVUFBSSxjQUFjO0FBQ2QsZUFBTztBQUFBLE1BQ1g7QUFBQSxJQUNKO0FBRUEsMEJBQXNCLE1BQU0sa0JBQWtCLEdBQUcsc0JBQXNCO0FBQ3ZFLDBCQUFzQixNQUFNLHFCQUFxQixHQUFHLHlCQUF5QjtBQUM3RSxRQUFJLDBCQUEwQjtBQUMxQiw0QkFBc0IsTUFBTSxtQ0FBbUMsR0FBRyx3QkFBd0I7QUFBQSxJQUM5RjtBQUNBLFFBQUksaUJBQWlCO0FBQ2pCLDRCQUFzQixNQUFNLHdCQUF3QixHQUFHLGVBQWU7QUFBQSxJQUMxRTtBQUNBLFdBQU87QUFBQSxFQUNYO0FBQ0EsTUFBSSxVQUFVLENBQUM7QUFDZixXQUFTLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0FBQ2xDLFlBQVEsQ0FBQyxJQUFJLHdCQUF3QixLQUFLLENBQUMsR0FBRyxZQUFZO0FBQUEsRUFDOUQ7QUFDQSxTQUFPO0FBQ1g7QUFDQSxTQUFTLGVBQWUsUUFBUSxXQUFXO0FBQ3ZDLE1BQUksQ0FBQyxXQUFXO0FBQ1osVUFBTSxhQUFhLENBQUM7QUFDcEIsYUFBUyxRQUFRLFFBQVE7QUFDckIsWUFBTSxRQUFRLHVCQUF1QixLQUFLLElBQUk7QUFDOUMsVUFBSSxVQUFVLFNBQVMsTUFBTSxDQUFDO0FBQzlCLFVBQUksWUFBWSxDQUFDLGFBQWEsWUFBWSxZQUFZO0FBQ2xELGNBQU0sUUFBUSxPQUFPLElBQUk7QUFDekIsWUFBSSxPQUFPO0FBQ1AsbUJBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7QUFDbkMsdUJBQVcsS0FBSyxNQUFNLENBQUMsQ0FBQztBQUFBLFVBQzVCO0FBQUEsUUFDSjtBQUFBLE1BQ0o7QUFBQSxJQUNKO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFDQSxNQUFJLGtCQUFrQixxQkFBcUIsU0FBUztBQUNwRCxNQUFJLENBQUMsaUJBQWlCO0FBQ2xCLHNCQUFrQixTQUFTO0FBQzNCLHNCQUFrQixxQkFBcUIsU0FBUztBQUFBLEVBQ3BEO0FBQ0EsUUFBTSxvQkFBb0IsT0FBTyxnQkFBZ0IsU0FBUyxDQUFDO0FBQzNELFFBQU0sbUJBQW1CLE9BQU8sZ0JBQWdCLFFBQVEsQ0FBQztBQUN6RCxNQUFJLENBQUMsbUJBQW1CO0FBQ3BCLFdBQU8sbUJBQW1CLGlCQUFpQixNQUFNLElBQUksQ0FBQztBQUFBLEVBQzFELE9BQ0s7QUFDRCxXQUFPLG1CQUFtQixrQkFBa0IsT0FBTyxnQkFBZ0IsSUFDL0Qsa0JBQWtCLE1BQU07QUFBQSxFQUNoQztBQUNKO0FBQ0EsU0FBUyxvQkFBb0IsUUFBUSxLQUFLO0FBQ3RDLFFBQU0sUUFBUSxPQUFPLE9BQU87QUFDNUIsTUFBSSxTQUFTLE1BQU0sV0FBVztBQUMxQixRQUFJLFlBQVksTUFBTSxXQUFXLDRCQUE0QixDQUFDLGFBQWEsU0FBVVIsT0FBTSxNQUFNO0FBQzdGLE1BQUFBLE1BQUssNEJBQTRCLElBQUk7QUFJckMsa0JBQVksU0FBUyxNQUFNQSxPQUFNLElBQUk7QUFBQSxJQUN6QyxDQUFDO0FBQUEsRUFDTDtBQUNKO0FBRUEsU0FBUyxlQUFlLEtBQUssUUFBUSxZQUFZLFFBQVEsV0FBVztBQUNoRSxRQUFNLFNBQVMsS0FBSyxXQUFXLE1BQU07QUFDckMsTUFBSSxPQUFPLE1BQU0sR0FBRztBQUNoQjtBQUFBLEVBQ0o7QUFDQSxRQUFNLGlCQUFpQixPQUFPLE1BQU0sSUFBSSxPQUFPLE1BQU07QUFDckQsU0FBTyxNQUFNLElBQUksU0FBVSxNQUFNLE1BQU0sU0FBUztBQUM1QyxRQUFJLFFBQVEsS0FBSyxXQUFXO0FBQ3hCLGdCQUFVLFFBQVEsU0FBVSxVQUFVO0FBQ2xDLGNBQU0sU0FBUyxHQUFHLFVBQVUsSUFBSSxNQUFNLE9BQU87QUFDN0MsY0FBTSxZQUFZLEtBQUs7QUFTdkIsWUFBSTtBQUNBLGNBQUksVUFBVSxlQUFlLFFBQVEsR0FBRztBQUNwQyxrQkFBTSxhQUFhLElBQUksK0JBQStCLFdBQVcsUUFBUTtBQUN6RSxnQkFBSSxjQUFjLFdBQVcsT0FBTztBQUNoQyx5QkFBVyxRQUFRLElBQUksb0JBQW9CLFdBQVcsT0FBTyxNQUFNO0FBQ25FLGtCQUFJLGtCQUFrQixLQUFLLFdBQVcsVUFBVSxVQUFVO0FBQUEsWUFDOUQsV0FDUyxVQUFVLFFBQVEsR0FBRztBQUMxQix3QkFBVSxRQUFRLElBQUksSUFBSSxvQkFBb0IsVUFBVSxRQUFRLEdBQUcsTUFBTTtBQUFBLFlBQzdFO0FBQUEsVUFDSixXQUNTLFVBQVUsUUFBUSxHQUFHO0FBQzFCLHNCQUFVLFFBQVEsSUFBSSxJQUFJLG9CQUFvQixVQUFVLFFBQVEsR0FBRyxNQUFNO0FBQUEsVUFDN0U7QUFBQSxRQUNKLFFBQ007QUFBQSxRQUdOO0FBQUEsTUFDSixDQUFDO0FBQUEsSUFDTDtBQUNBLFdBQU8sZUFBZSxLQUFLLFFBQVEsTUFBTSxNQUFNLE9BQU87QUFBQSxFQUMxRDtBQUNBLE1BQUksc0JBQXNCLE9BQU8sTUFBTSxHQUFHLGNBQWM7QUFDNUQ7QUFNQSxTQUFTLGlCQUFpQixRQUFRLGNBQWMsa0JBQWtCO0FBQzlELE1BQUksQ0FBQyxvQkFBb0IsaUJBQWlCLFdBQVcsR0FBRztBQUNwRCxXQUFPO0FBQUEsRUFDWDtBQUNBLFFBQU0sTUFBTSxpQkFBaUIsT0FBTyxRQUFNLEdBQUcsV0FBVyxNQUFNO0FBQzlELE1BQUksQ0FBQyxPQUFPLElBQUksV0FBVyxHQUFHO0FBQzFCLFdBQU87QUFBQSxFQUNYO0FBQ0EsUUFBTSx5QkFBeUIsSUFBSSxDQUFDLEVBQUU7QUFDdEMsU0FBTyxhQUFhLE9BQU8sUUFBTSx1QkFBdUIsUUFBUSxFQUFFLE1BQU0sRUFBRTtBQUM5RTtBQUNBLFNBQVMsd0JBQXdCLFFBQVEsY0FBYyxrQkFBa0IsV0FBVztBQUdoRixNQUFJLENBQUMsUUFBUTtBQUNUO0FBQUEsRUFDSjtBQUNBLFFBQU0scUJBQXFCLGlCQUFpQixRQUFRLGNBQWMsZ0JBQWdCO0FBQ2xGLG9CQUFrQixRQUFRLG9CQUFvQixTQUFTO0FBQzNEO0FBS0EsU0FBUyxnQkFBZ0IsUUFBUTtBQUM3QixTQUFPLE9BQU8sb0JBQW9CLE1BQU0sRUFDbkMsT0FBTyxVQUFRLEtBQUssV0FBVyxJQUFJLEtBQUssS0FBSyxTQUFTLENBQUMsRUFDdkQsSUFBSSxVQUFRLEtBQUssVUFBVSxDQUFDLENBQUM7QUFDdEM7QUFDQSxTQUFTLHdCQUF3QixLQUFLTSxVQUFTO0FBQzNDLE1BQUksVUFBVSxDQUFDLE9BQU87QUFDbEI7QUFBQSxFQUNKO0FBQ0EsTUFBSSxLQUFLLElBQUksT0FBTyxhQUFhLENBQUMsR0FBRztBQUVqQztBQUFBLEVBQ0o7QUFDQSxRQUFNLG1CQUFtQkEsU0FBUSw2QkFBNkI7QUFFOUQsTUFBSSxlQUFlLENBQUM7QUFDcEIsTUFBSSxXQUFXO0FBQ1gsVUFBTUksa0JBQWlCO0FBQ3ZCLG1CQUFlLGFBQWEsT0FBTztBQUFBLE1BQy9CO0FBQUEsTUFBWTtBQUFBLE1BQWM7QUFBQSxNQUFXO0FBQUEsTUFBZTtBQUFBLE1BQW1CO0FBQUEsTUFDdkU7QUFBQSxNQUF1QjtBQUFBLE1BQW9CO0FBQUEsTUFBcUI7QUFBQSxNQUFzQjtBQUFBLElBQzFGLENBQUM7QUFDRCxVQUFNLHdCQUF3QixLQUFLLElBQUksQ0FBQyxFQUFFLFFBQVFBLGlCQUFnQixrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUM7QUFHcEcsNEJBQXdCQSxpQkFBZ0IsZ0JBQWdCQSxlQUFjLEdBQUcsbUJBQW1CLGlCQUFpQixPQUFPLHFCQUFxQixJQUFJLGtCQUFrQixxQkFBcUJBLGVBQWMsQ0FBQztBQUFBLEVBQ3ZNO0FBQ0EsaUJBQWUsYUFBYSxPQUFPO0FBQUEsSUFDL0I7QUFBQSxJQUFrQjtBQUFBLElBQTZCO0FBQUEsSUFBWTtBQUFBLElBQWM7QUFBQSxJQUN6RTtBQUFBLElBQWU7QUFBQSxJQUFrQjtBQUFBLElBQWE7QUFBQSxFQUNsRCxDQUFDO0FBQ0QsV0FBUyxJQUFJLEdBQUcsSUFBSSxhQUFhLFFBQVEsS0FBSztBQUMxQyxVQUFNLFNBQVNKLFNBQVEsYUFBYSxDQUFDLENBQUM7QUFDdEMsY0FBVSxPQUFPLGFBQ2Isd0JBQXdCLE9BQU8sV0FBVyxnQkFBZ0IsT0FBTyxTQUFTLEdBQUcsZ0JBQWdCO0FBQUEsRUFDckc7QUFDSjtBQUVBLEtBQUssYUFBYSxRQUFRLENBQUMsUUFBUVAsT0FBTSxRQUFRO0FBRzdDLFFBQU0sYUFBYSxnQkFBZ0IsTUFBTTtBQUN6QyxNQUFJLG9CQUFvQjtBQUN4QixNQUFJLGNBQWM7QUFDbEIsTUFBSSxnQkFBZ0I7QUFDcEIsTUFBSSxpQkFBaUI7QUFPckIsUUFBTSw2QkFBNkJBLE1BQUssV0FBVyxxQkFBcUI7QUFDeEUsUUFBTSwwQkFBMEJBLE1BQUssV0FBVyxrQkFBa0I7QUFDbEUsTUFBSSxPQUFPLHVCQUF1QixHQUFHO0FBQ2pDLFdBQU8sMEJBQTBCLElBQUksT0FBTyx1QkFBdUI7QUFBQSxFQUN2RTtBQUNBLE1BQUksT0FBTywwQkFBMEIsR0FBRztBQUNwQyxJQUFBQSxNQUFLLDBCQUEwQixJQUFJQSxNQUFLLHVCQUF1QixJQUMzRCxPQUFPLDBCQUEwQjtBQUFBLEVBQ3pDO0FBQ0EsTUFBSSxzQkFBc0I7QUFDMUIsTUFBSSxtQkFBbUI7QUFDdkIsTUFBSSxhQUFhO0FBQ2pCLE1BQUksdUJBQXVCO0FBQzNCLE1BQUksaUNBQWlDO0FBQ3JDLE1BQUksZUFBZTtBQUNuQixNQUFJLGFBQWE7QUFDakIsTUFBSSxhQUFhO0FBQ2pCLE1BQUksc0JBQXNCO0FBQzFCLE1BQUksbUJBQW1CO0FBQ3ZCLE1BQUksd0JBQXdCO0FBQzVCLE1BQUksb0JBQW9CLE9BQU87QUFDL0IsTUFBSSxpQkFBaUI7QUFDckIsTUFBSSxtQkFBbUIsT0FBTztBQUFBLElBQzFCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0o7QUFDSixDQUFDO0FBTUQsU0FBUyxvQkFBb0IsUUFBUSxLQUFLO0FBQ3RDLE1BQUksWUFBWSxRQUFRLGtCQUFrQixDQUFDLGFBQWE7QUFDcEQsV0FBTyxTQUFVQyxPQUFNLE1BQU07QUFDekIsV0FBSyxRQUFRLGtCQUFrQixrQkFBa0IsS0FBSyxDQUFDLENBQUM7QUFBQSxJQUM1RDtBQUFBLEVBQ0osQ0FBQztBQUNMO0FBTUEsSUFBTSxhQUFhLFdBQVcsVUFBVTtBQUN4QyxTQUFTLFdBQVdXLFNBQVEsU0FBUyxZQUFZLFlBQVk7QUFDekQsTUFBSSxZQUFZO0FBQ2hCLE1BQUksY0FBYztBQUNsQixhQUFXO0FBQ1gsZ0JBQWM7QUFDZCxRQUFNLGtCQUFrQixDQUFDO0FBQ3pCLFdBQVMsYUFBYSxNQUFNO0FBQ3hCLFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFNBQUssS0FBSyxDQUFDLElBQUksV0FBWTtBQUN2QixhQUFPLEtBQUssT0FBTyxNQUFNLE1BQU0sU0FBUztBQUFBLElBQzVDO0FBQ0EsU0FBSyxXQUFXLFVBQVUsTUFBTUEsU0FBUSxLQUFLLElBQUk7QUFDakQsV0FBTztBQUFBLEVBQ1g7QUFDQSxXQUFTLFVBQVUsTUFBTTtBQUNyQixXQUFPLFlBQVksS0FBS0EsU0FBUSxLQUFLLEtBQUssUUFBUTtBQUFBLEVBQ3REO0FBQ0EsY0FDSSxZQUFZQSxTQUFRLFNBQVMsQ0FBQyxhQUFhLFNBQVVYLE9BQU0sTUFBTTtBQUM3RCxRQUFJLE9BQU8sS0FBSyxDQUFDLE1BQU0sWUFBWTtBQUMvQixZQUFNLFVBQVU7QUFBQSxRQUNaLFlBQVksZUFBZTtBQUFBLFFBQzNCLE9BQVEsZUFBZSxhQUFhLGVBQWUsYUFBYyxLQUFLLENBQUMsS0FBSyxJQUN4RTtBQUFBLFFBQ0o7QUFBQSxNQUNKO0FBQ0EsWUFBTSxXQUFXLEtBQUssQ0FBQztBQUN2QixXQUFLLENBQUMsSUFBSSxTQUFTLFFBQVE7QUFDdkIsWUFBSTtBQUNBLGlCQUFPLFNBQVMsTUFBTSxNQUFNLFNBQVM7QUFBQSxRQUN6QyxVQUNBO0FBUUksY0FBSSxDQUFFLFFBQVEsWUFBYTtBQUN2QixnQkFBSSxPQUFPLFFBQVEsYUFBYSxVQUFVO0FBR3RDLHFCQUFPLGdCQUFnQixRQUFRLFFBQVE7QUFBQSxZQUMzQyxXQUNTLFFBQVEsVUFBVTtBQUd2QixzQkFBUSxTQUFTLFVBQVUsSUFBSTtBQUFBLFlBQ25DO0FBQUEsVUFDSjtBQUFBLFFBQ0o7QUFBQSxNQUNKO0FBQ0EsWUFBTSxPQUFPLGlDQUFpQyxTQUFTLEtBQUssQ0FBQyxHQUFHLFNBQVMsY0FBYyxTQUFTO0FBQ2hHLFVBQUksQ0FBQyxNQUFNO0FBQ1AsZUFBTztBQUFBLE1BQ1g7QUFFQSxZQUFNLFNBQVMsS0FBSyxLQUFLO0FBQ3pCLFVBQUksT0FBTyxXQUFXLFVBQVU7QUFHNUIsd0JBQWdCLE1BQU0sSUFBSTtBQUFBLE1BQzlCLFdBQ1MsUUFBUTtBQUdiLGVBQU8sVUFBVSxJQUFJO0FBQUEsTUFDekI7QUFHQSxVQUFJLFVBQVUsT0FBTyxPQUFPLE9BQU8sU0FBUyxPQUFPLE9BQU8sUUFBUSxjQUM5RCxPQUFPLE9BQU8sVUFBVSxZQUFZO0FBQ3BDLGFBQUssTUFBTSxPQUFPLElBQUksS0FBSyxNQUFNO0FBQ2pDLGFBQUssUUFBUSxPQUFPLE1BQU0sS0FBSyxNQUFNO0FBQUEsTUFDekM7QUFDQSxVQUFJLE9BQU8sV0FBVyxZQUFZLFFBQVE7QUFDdEMsZUFBTztBQUFBLE1BQ1g7QUFDQSxhQUFPO0FBQUEsSUFDWCxPQUNLO0FBRUQsYUFBTyxTQUFTLE1BQU1XLFNBQVEsSUFBSTtBQUFBLElBQ3RDO0FBQUEsRUFDSixDQUFDO0FBQ0wsZ0JBQ0ksWUFBWUEsU0FBUSxZQUFZLENBQUMsYUFBYSxTQUFVWCxPQUFNLE1BQU07QUFDaEUsVUFBTSxLQUFLLEtBQUssQ0FBQztBQUNqQixRQUFJO0FBQ0osUUFBSSxPQUFPLE9BQU8sVUFBVTtBQUV4QixhQUFPLGdCQUFnQixFQUFFO0FBQUEsSUFDN0IsT0FDSztBQUVELGFBQU8sTUFBTSxHQUFHLFVBQVU7QUFFMUIsVUFBSSxDQUFDLE1BQU07QUFDUCxlQUFPO0FBQUEsTUFDWDtBQUFBLElBQ0o7QUFDQSxRQUFJLFFBQVEsT0FBTyxLQUFLLFNBQVMsVUFBVTtBQUN2QyxVQUFJLEtBQUssVUFBVSxtQkFDZCxLQUFLLFlBQVksS0FBSyxLQUFLLGNBQWMsS0FBSyxhQUFhLElBQUk7QUFDaEUsWUFBSSxPQUFPLE9BQU8sVUFBVTtBQUN4QixpQkFBTyxnQkFBZ0IsRUFBRTtBQUFBLFFBQzdCLFdBQ1MsSUFBSTtBQUNULGFBQUcsVUFBVSxJQUFJO0FBQUEsUUFDckI7QUFFQSxhQUFLLEtBQUssV0FBVyxJQUFJO0FBQUEsTUFDN0I7QUFBQSxJQUNKLE9BQ0s7QUFFRCxlQUFTLE1BQU1XLFNBQVEsSUFBSTtBQUFBLElBQy9CO0FBQUEsRUFDSixDQUFDO0FBQ1Q7QUFFQSxTQUFTLG9CQUFvQkwsVUFBUyxLQUFLO0FBQ3ZDLFFBQU0sRUFBRSxXQUFBTSxZQUFXLE9BQUFDLE9BQU0sSUFBSSxJQUFJLGlCQUFpQjtBQUNsRCxNQUFLLENBQUNELGNBQWEsQ0FBQ0MsVUFBVSxDQUFDUCxTQUFRLGdCQUFnQixLQUFLLEVBQUUsb0JBQW9CQSxXQUFVO0FBQ3hGO0FBQUEsRUFDSjtBQUNBLFFBQU0sWUFBWSxDQUFDLHFCQUFxQix3QkFBd0IsbUJBQW1CLDBCQUEwQjtBQUM3RyxNQUFJLGVBQWUsS0FBS0EsU0FBUSxnQkFBZ0Isa0JBQWtCLFVBQVUsU0FBUztBQUN6RjtBQUVBLFNBQVMsaUJBQWlCQSxVQUFTLEtBQUs7QUFDcEMsTUFBSSxLQUFLLElBQUksT0FBTyxrQkFBa0IsQ0FBQyxHQUFHO0FBRXRDO0FBQUEsRUFDSjtBQUNBLFFBQU0sRUFBRSxZQUFZLHNCQUFBUSx1QkFBc0IsVUFBQUMsV0FBVSxXQUFBQyxZQUFXLG9CQUFBQyxvQkFBbUIsSUFBSSxJQUFJLGlCQUFpQjtBQUUzRyxXQUFTLElBQUksR0FBRyxJQUFJLFdBQVcsUUFBUSxLQUFLO0FBQ3hDLFVBQU0sWUFBWSxXQUFXLENBQUM7QUFDOUIsVUFBTSxpQkFBaUIsWUFBWUQ7QUFDbkMsVUFBTSxnQkFBZ0IsWUFBWUQ7QUFDbEMsVUFBTSxTQUFTRSxzQkFBcUI7QUFDcEMsVUFBTSxnQkFBZ0JBLHNCQUFxQjtBQUMzQyxJQUFBSCxzQkFBcUIsU0FBUyxJQUFJLENBQUM7QUFDbkMsSUFBQUEsc0JBQXFCLFNBQVMsRUFBRUUsVUFBUyxJQUFJO0FBQzdDLElBQUFGLHNCQUFxQixTQUFTLEVBQUVDLFNBQVEsSUFBSTtBQUFBLEVBQ2hEO0FBQ0EsUUFBTSxlQUFlVCxTQUFRLGFBQWE7QUFDMUMsTUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsV0FBVztBQUMxQztBQUFBLEVBQ0o7QUFDQSxNQUFJLGlCQUFpQkEsVUFBUyxLQUFLLENBQUMsZ0JBQWdCLGFBQWEsU0FBUyxDQUFDO0FBQzNFLFNBQU87QUFDWDtBQUNBLFNBQVMsV0FBVyxRQUFRLEtBQUs7QUFDN0IsTUFBSSxvQkFBb0IsUUFBUSxHQUFHO0FBQ3ZDO0FBTUEsS0FBSyxhQUFhLFVBQVUsQ0FBQyxXQUFXO0FBQ3BDLFFBQU0sY0FBYyxPQUFPLEtBQUssV0FBVyxhQUFhLENBQUM7QUFDekQsTUFBSSxhQUFhO0FBQ2IsZ0JBQVk7QUFBQSxFQUNoQjtBQUNKLENBQUM7QUFDRCxLQUFLLGFBQWEsVUFBVSxDQUFDLFdBQVc7QUFDcEMsUUFBTSxNQUFNO0FBQ1osUUFBTSxRQUFRO0FBQ2QsYUFBVyxRQUFRLEtBQUssT0FBTyxTQUFTO0FBQ3hDLGFBQVcsUUFBUSxLQUFLLE9BQU8sVUFBVTtBQUN6QyxhQUFXLFFBQVEsS0FBSyxPQUFPLFdBQVc7QUFDOUMsQ0FBQztBQUNELEtBQUssYUFBYSx5QkFBeUIsQ0FBQyxXQUFXO0FBQ25ELGFBQVcsUUFBUSxXQUFXLFVBQVUsZ0JBQWdCO0FBQ3hELGFBQVcsUUFBUSxjQUFjLGFBQWEsZ0JBQWdCO0FBQzlELGFBQVcsUUFBUSxpQkFBaUIsZ0JBQWdCLGdCQUFnQjtBQUN4RSxDQUFDO0FBQ0QsS0FBSyxhQUFhLFlBQVksQ0FBQyxRQUFRUCxVQUFTO0FBQzVDLFFBQU0sa0JBQWtCLENBQUMsU0FBUyxVQUFVLFNBQVM7QUFDckQsV0FBUyxJQUFJLEdBQUcsSUFBSSxnQkFBZ0IsUUFBUSxLQUFLO0FBQzdDLFVBQU0sT0FBTyxnQkFBZ0IsQ0FBQztBQUM5QixnQkFBWSxRQUFRLE1BQU0sQ0FBQyxVQUFVLFFBQVFtQixVQUFTO0FBQ2xELGFBQU8sU0FBVSxHQUFHLE1BQU07QUFDdEIsZUFBT25CLE1BQUssUUFBUSxJQUFJLFVBQVUsUUFBUSxNQUFNbUIsS0FBSTtBQUFBLE1BQ3hEO0FBQUEsSUFDSixDQUFDO0FBQUEsRUFDTDtBQUNKLENBQUM7QUFDRCxLQUFLLGFBQWEsZUFBZSxDQUFDLFFBQVFuQixPQUFNLFFBQVE7QUFDcEQsYUFBVyxRQUFRLEdBQUc7QUFDdEIsbUJBQWlCLFFBQVEsR0FBRztBQUU1QixRQUFNLDRCQUE0QixPQUFPLDJCQUEyQjtBQUNwRSxNQUFJLDZCQUE2QiwwQkFBMEIsV0FBVztBQUNsRSxRQUFJLGlCQUFpQixRQUFRLEtBQUssQ0FBQywwQkFBMEIsU0FBUyxDQUFDO0FBQUEsRUFDM0U7QUFDSixDQUFDO0FBQ0QsS0FBSyxhQUFhLG9CQUFvQixDQUFDLFFBQVFBLE9BQU0sUUFBUTtBQUN6RCxhQUFXLGtCQUFrQjtBQUM3QixhQUFXLHdCQUF3QjtBQUN2QyxDQUFDO0FBQ0QsS0FBSyxhQUFhLHdCQUF3QixDQUFDLFFBQVFBLE9BQU0sUUFBUTtBQUM3RCxhQUFXLHNCQUFzQjtBQUNyQyxDQUFDO0FBQ0QsS0FBSyxhQUFhLGNBQWMsQ0FBQyxRQUFRQSxPQUFNLFFBQVE7QUFDbkQsYUFBVyxZQUFZO0FBQzNCLENBQUM7QUFDRCxLQUFLLGFBQWEsZUFBZSxDQUFDLFFBQVFBLE9BQU0sUUFBUTtBQUNwRCwwQkFBd0IsS0FBSyxNQUFNO0FBQ3ZDLENBQUM7QUFDRCxLQUFLLGFBQWEsa0JBQWtCLENBQUMsUUFBUUEsT0FBTSxRQUFRO0FBQ3ZELHNCQUFvQixRQUFRLEdBQUc7QUFDbkMsQ0FBQztBQUNELEtBQUssYUFBYSxPQUFPLENBQUMsUUFBUUEsVUFBUztBQUV2QyxXQUFTLE1BQU07QUFDZixRQUFNLFdBQVcsV0FBVyxTQUFTO0FBQ3JDLFFBQU0sV0FBVyxXQUFXLFNBQVM7QUFDckMsUUFBTSxlQUFlLFdBQVcsYUFBYTtBQUM3QyxRQUFNLGdCQUFnQixXQUFXLGNBQWM7QUFDL0MsUUFBTSxVQUFVLFdBQVcsUUFBUTtBQUNuQyxRQUFNLDZCQUE2QixXQUFXLHlCQUF5QjtBQUN2RSxXQUFTLFNBQVNZLFNBQVE7QUFDdEIsVUFBTSxpQkFBaUJBLFFBQU8sZ0JBQWdCO0FBQzlDLFFBQUksQ0FBQyxnQkFBZ0I7QUFFakI7QUFBQSxJQUNKO0FBQ0EsVUFBTSwwQkFBMEIsZUFBZTtBQUMvQyxhQUFTLGdCQUFnQixRQUFRO0FBQzdCLGFBQU8sT0FBTyxRQUFRO0FBQUEsSUFDMUI7QUFDQSxRQUFJLGlCQUFpQix3QkFBd0IsOEJBQThCO0FBQzNFLFFBQUksb0JBQW9CLHdCQUF3QixpQ0FBaUM7QUFDakYsUUFBSSxDQUFDLGdCQUFnQjtBQUNqQixZQUFNLDRCQUE0QkEsUUFBTywyQkFBMkI7QUFDcEUsVUFBSSwyQkFBMkI7QUFDM0IsY0FBTSxxQ0FBcUMsMEJBQTBCO0FBQ3JFLHlCQUFpQixtQ0FBbUMsOEJBQThCO0FBQ2xGLDRCQUFvQixtQ0FBbUMsaUNBQWlDO0FBQUEsTUFDNUY7QUFBQSxJQUNKO0FBQ0EsVUFBTSxxQkFBcUI7QUFDM0IsVUFBTSxZQUFZO0FBQ2xCLGFBQVMsYUFBYSxNQUFNO0FBQ3hCLFlBQU0sT0FBTyxLQUFLO0FBQ2xCLFlBQU0sU0FBUyxLQUFLO0FBQ3BCLGFBQU8sYUFBYSxJQUFJO0FBQ3hCLGFBQU8sMEJBQTBCLElBQUk7QUFFckMsWUFBTSxXQUFXLE9BQU8sWUFBWTtBQUNwQyxVQUFJLENBQUMsZ0JBQWdCO0FBQ2pCLHlCQUFpQixPQUFPLDhCQUE4QjtBQUN0RCw0QkFBb0IsT0FBTyxpQ0FBaUM7QUFBQSxNQUNoRTtBQUNBLFVBQUksVUFBVTtBQUNWLDBCQUFrQixLQUFLLFFBQVEsb0JBQW9CLFFBQVE7QUFBQSxNQUMvRDtBQUNBLFlBQU0sY0FBYyxPQUFPLFlBQVksSUFBSSxNQUFNO0FBQzdDLFlBQUksT0FBTyxlQUFlLE9BQU8sTUFBTTtBQUduQyxjQUFJLENBQUMsS0FBSyxXQUFXLE9BQU8sYUFBYSxLQUFLLEtBQUssVUFBVSxXQUFXO0FBUXBFLGtCQUFNLFlBQVksT0FBT1osTUFBSyxXQUFXLFdBQVcsQ0FBQztBQUNyRCxnQkFBSSxPQUFPLFdBQVcsS0FBSyxhQUFhLFVBQVUsU0FBUyxHQUFHO0FBQzFELG9CQUFNLFlBQVksS0FBSztBQUN2QixtQkFBSyxTQUFTLFdBQVk7QUFHdEIsc0JBQU1vQixhQUFZLE9BQU9wQixNQUFLLFdBQVcsV0FBVyxDQUFDO0FBQ3JELHlCQUFTLElBQUksR0FBRyxJQUFJb0IsV0FBVSxRQUFRLEtBQUs7QUFDdkMsc0JBQUlBLFdBQVUsQ0FBQyxNQUFNLE1BQU07QUFDdkIsb0JBQUFBLFdBQVUsT0FBTyxHQUFHLENBQUM7QUFBQSxrQkFDekI7QUFBQSxnQkFDSjtBQUNBLG9CQUFJLENBQUMsS0FBSyxXQUFXLEtBQUssVUFBVSxXQUFXO0FBQzNDLDRCQUFVLEtBQUssSUFBSTtBQUFBLGdCQUN2QjtBQUFBLGNBQ0o7QUFDQSx3QkFBVSxLQUFLLElBQUk7QUFBQSxZQUN2QixPQUNLO0FBQ0QsbUJBQUssT0FBTztBQUFBLFlBQ2hCO0FBQUEsVUFDSixXQUNTLENBQUMsS0FBSyxXQUFXLE9BQU8sYUFBYSxNQUFNLE9BQU87QUFFdkQsbUJBQU8sMEJBQTBCLElBQUk7QUFBQSxVQUN6QztBQUFBLFFBQ0o7QUFBQSxNQUNKO0FBQ0EscUJBQWUsS0FBSyxRQUFRLG9CQUFvQixXQUFXO0FBQzNELFlBQU0sYUFBYSxPQUFPLFFBQVE7QUFDbEMsVUFBSSxDQUFDLFlBQVk7QUFDYixlQUFPLFFBQVEsSUFBSTtBQUFBLE1BQ3ZCO0FBQ0EsaUJBQVcsTUFBTSxRQUFRLEtBQUssSUFBSTtBQUNsQyxhQUFPLGFBQWEsSUFBSTtBQUN4QixhQUFPO0FBQUEsSUFDWDtBQUNBLGFBQVMsc0JBQXNCO0FBQUEsSUFBRTtBQUNqQyxhQUFTLFVBQVUsTUFBTTtBQUNyQixZQUFNLE9BQU8sS0FBSztBQUdsQixXQUFLLFVBQVU7QUFDZixhQUFPLFlBQVksTUFBTSxLQUFLLFFBQVEsS0FBSyxJQUFJO0FBQUEsSUFDbkQ7QUFDQSxVQUFNLGFBQWEsWUFBWSx5QkFBeUIsUUFBUSxNQUFNLFNBQVVuQixPQUFNLE1BQU07QUFDeEYsTUFBQUEsTUFBSyxRQUFRLElBQUksS0FBSyxDQUFDLEtBQUs7QUFDNUIsTUFBQUEsTUFBSyxPQUFPLElBQUksS0FBSyxDQUFDO0FBQ3RCLGFBQU8sV0FBVyxNQUFNQSxPQUFNLElBQUk7QUFBQSxJQUN0QyxDQUFDO0FBQ0QsVUFBTSx3QkFBd0I7QUFDOUIsVUFBTSxvQkFBb0IsV0FBVyxtQkFBbUI7QUFDeEQsVUFBTSxzQkFBc0IsV0FBVyxxQkFBcUI7QUFDNUQsVUFBTSxhQUFhLFlBQVkseUJBQXlCLFFBQVEsTUFBTSxTQUFVQSxPQUFNLE1BQU07QUFDeEYsVUFBSUQsTUFBSyxRQUFRLG1CQUFtQixNQUFNLE1BQU07QUFJNUMsZUFBTyxXQUFXLE1BQU1DLE9BQU0sSUFBSTtBQUFBLE1BQ3RDO0FBQ0EsVUFBSUEsTUFBSyxRQUFRLEdBQUc7QUFFaEIsZUFBTyxXQUFXLE1BQU1BLE9BQU0sSUFBSTtBQUFBLE1BQ3RDLE9BQ0s7QUFDRCxjQUFNLFVBQVUsRUFBRSxRQUFRQSxPQUFNLEtBQUtBLE1BQUssT0FBTyxHQUFHLFlBQVksT0FBTyxNQUFZLFNBQVMsTUFBTTtBQUNsRyxjQUFNLE9BQU8saUNBQWlDLHVCQUF1QixxQkFBcUIsU0FBUyxjQUFjLFNBQVM7QUFDMUgsWUFBSUEsU0FBUUEsTUFBSywwQkFBMEIsTUFBTSxRQUFRLENBQUMsUUFBUSxXQUM5RCxLQUFLLFVBQVUsV0FBVztBQUkxQixlQUFLLE9BQU87QUFBQSxRQUNoQjtBQUFBLE1BQ0o7QUFBQSxJQUNKLENBQUM7QUFDRCxVQUFNLGNBQWMsWUFBWSx5QkFBeUIsU0FBUyxNQUFNLFNBQVVBLE9BQU0sTUFBTTtBQUMxRixZQUFNLE9BQU8sZ0JBQWdCQSxLQUFJO0FBQ2pDLFVBQUksUUFBUSxPQUFPLEtBQUssUUFBUSxVQUFVO0FBS3RDLFlBQUksS0FBSyxZQUFZLFFBQVMsS0FBSyxRQUFRLEtBQUssS0FBSyxTQUFVO0FBQzNEO0FBQUEsUUFDSjtBQUNBLGFBQUssS0FBSyxXQUFXLElBQUk7QUFBQSxNQUM3QixXQUNTRCxNQUFLLFFBQVEsaUJBQWlCLE1BQU0sTUFBTTtBQUUvQyxlQUFPLFlBQVksTUFBTUMsT0FBTSxJQUFJO0FBQUEsTUFDdkM7QUFBQSxJQUlKLENBQUM7QUFBQSxFQUNMO0FBQ0osQ0FBQztBQUNELEtBQUssYUFBYSxlQUFlLENBQUMsV0FBVztBQUV6QyxNQUFJLE9BQU8sV0FBVyxLQUFLLE9BQU8sV0FBVyxFQUFFLGFBQWE7QUFDeEQsbUJBQWUsT0FBTyxXQUFXLEVBQUUsYUFBYSxDQUFDLHNCQUFzQixlQUFlLENBQUM7QUFBQSxFQUMzRjtBQUNKLENBQUM7QUFDRCxLQUFLLGFBQWEseUJBQXlCLENBQUMsUUFBUUQsVUFBUztBQUV6RCxXQUFTLDRCQUE0QixTQUFTO0FBQzFDLFdBQU8sU0FBVSxHQUFHO0FBQ2hCLFlBQU0sYUFBYSxlQUFlLFFBQVEsT0FBTztBQUNqRCxpQkFBVyxRQUFRLGVBQWE7QUFHNUIsY0FBTSx3QkFBd0IsT0FBTyx1QkFBdUI7QUFDNUQsWUFBSSx1QkFBdUI7QUFDdkIsZ0JBQU0sTUFBTSxJQUFJLHNCQUFzQixTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsUUFBUSxFQUFFLFVBQVUsQ0FBQztBQUMxRixvQkFBVSxPQUFPLEdBQUc7QUFBQSxRQUN4QjtBQUFBLE1BQ0osQ0FBQztBQUFBLElBQ0w7QUFBQSxFQUNKO0FBQ0EsTUFBSSxPQUFPLHVCQUF1QixHQUFHO0FBQ2pDLElBQUFBLE1BQUssV0FBVyxrQ0FBa0MsQ0FBQyxJQUMvQyw0QkFBNEIsb0JBQW9CO0FBQ3BELElBQUFBLE1BQUssV0FBVyx5QkFBeUIsQ0FBQyxJQUN0Qyw0QkFBNEIsa0JBQWtCO0FBQUEsRUFDdEQ7QUFDSixDQUFDO0FBQ0QsS0FBSyxhQUFhLGtCQUFrQixDQUFDLFFBQVFBLE9BQU0sUUFBUTtBQUN2RCxzQkFBb0IsUUFBUSxHQUFHO0FBQ25DLENBQUM7OztBQ2xxRkQsSUFBTSxpQkFBaUI7QUE0RXZCLElBQU0scUJBQU4sTUFBeUI7QUFBQSxFQUNyQixVQUFVLE1BQU0sU0FBUztBQUNyQixXQUFPLEtBQUs7QUFBQSxFQUNoQjtBQUFBLEVBQ0EsZUFBZSxXQUFXLFNBQVM7QUFDL0IsV0FBTyxJQUFJLFVBQVUsU0FBUyxJQUFJLFdBQVMsTUFBTSxNQUFNLElBQUksQ0FBQyxFQUFFLEtBQUssSUFBSSxDQUFDO0FBQUEsRUFDNUU7QUFBQSxFQUNBLFNBQVMsS0FBSyxTQUFTO0FBQ25CLFVBQU0sV0FBVyxPQUFPLEtBQUssSUFBSSxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEtBQUssSUFBSSxNQUFNLENBQUMsRUFBRSxNQUFNLElBQUksQ0FBQyxHQUFHO0FBQ3ZGLFdBQU8sSUFBSSxJQUFJLFVBQVUsS0FBSyxJQUFJLElBQUksS0FBSyxTQUFTLEtBQUssSUFBSSxDQUFDO0FBQUEsRUFDbEU7QUFBQSxFQUNBLG9CQUFvQixJQUFJLFNBQVM7QUFDN0IsV0FBTyxHQUFHLFNBQ04saUJBQWlCLEdBQUcsU0FBUyxRQUM3QixpQkFBaUIsR0FBRyxTQUFTLEtBQUssR0FBRyxTQUFTLElBQUksV0FBUyxNQUFNLE1BQU0sSUFBSSxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVM7QUFBQSxFQUMxSDtBQUFBLEVBQ0EsaUJBQWlCLElBQUksU0FBUztBQUMxQixXQUFPLEdBQUcsUUFBUSxhQUFhLEdBQUcsSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLGFBQWEsR0FBRyxJQUFJO0FBQUEsRUFDckY7QUFBQSxFQUNBLG9CQUFvQixJQUFJLFNBQVM7QUFDN0IsV0FBTyxpQkFBaUIsR0FBRyxJQUFJLEtBQUssR0FBRyxNQUFNLE1BQU0sSUFBSSxDQUFDO0FBQUEsRUFDNUQ7QUFBQSxFQUNBLHNCQUFzQixJQUFJLFNBQVM7QUFDL0IsV0FBTyxtQkFBbUIsR0FBRyxTQUFTLEtBQUssR0FBRyxTQUFTLElBQUksV0FBUyxNQUFNLE1BQU0sSUFBSSxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVM7QUFBQSxFQUMvSDtBQUNKO0FBQ0EsSUFBTSxvQkFBb0IsSUFBSSxtQkFBbUI7QUE4TWpELElBQUk7QUFBQSxDQUNILFNBQVVxQixTQUFRO0FBQ2YsRUFBQUEsUUFBT0EsUUFBTyxRQUFRLElBQUksQ0FBQyxJQUFJO0FBQy9CLEVBQUFBLFFBQU9BLFFBQU8sS0FBSyxJQUFJLENBQUMsSUFBSTtBQUNoQyxHQUFHLFdBQVcsU0FBUyxDQUFDLEVBQUU7QUE0TTFCLFNBQVMsZUFBZSxRQUFRLEtBQUs7QUFDakMsV0FBUyxjQUFjLEdBQUcsV0FBVyxHQUFHLGNBQWMsT0FBTyxRQUFRLGVBQWUsWUFBWTtBQUM1RixRQUFJLElBQUksUUFBUSxNQUFNLE1BQU07QUFDeEI7QUFBQSxJQUNKLFdBQ1MsT0FBTyxXQUFXLE1BQU0sZ0JBQWdCO0FBQzdDLGFBQU87QUFBQSxJQUNYO0FBQUEsRUFDSjtBQUNBLFFBQU0sSUFBSSxNQUFNLDZDQUE2QyxHQUFHLElBQUk7QUFDeEU7QUE4UkEsSUFBTSxjQUFjLFNBQVUsaUJBQWlCLGFBQWE7QUFDeEQsTUFBSSxZQUFZLFdBQVc7QUFFdkIsVUFBTSxjQUFjLFlBQVksVUFBVSxjQUFjLFdBQVc7QUFDbkUsbUJBQWUsWUFBWSxDQUFDO0FBQzVCLGtCQUFjLFlBQVksQ0FBQztBQUFBLEVBQy9CO0FBQ0EsTUFBSSxVQUFVLFdBQVcsYUFBYSxDQUFDLEdBQUcsYUFBYSxJQUFJLENBQUMsQ0FBQztBQUM3RCxXQUFTLElBQUksR0FBRyxJQUFJLGFBQWEsUUFBUSxLQUFLO0FBQzFDLGVBQVcsWUFBWSxJQUFJLENBQUMsSUFBSSxXQUFXLGFBQWEsQ0FBQyxHQUFHLGFBQWEsSUFBSSxDQUFDLENBQUM7QUFBQSxFQUNuRjtBQUNBLFNBQU87QUFDWDtBQUNBLElBQU0sZUFBZTtBQWNyQixTQUFTLFdBQVcsYUFBYSxnQkFBZ0I7QUFDN0MsU0FBTyxlQUFlLE9BQU8sQ0FBQyxNQUFNLGVBQ2hDLFlBQVksVUFBVSxlQUFlLGFBQWEsY0FBYyxJQUFJLENBQUMsSUFDckU7QUFDUjs7O0FDbjFCQSxXQUFXLFlBQVk7OztBQ1J2QixjQUF5QjtBQUd4QixPQUFlLFNBQVM7QUFFekIsT0FBTyxTQUFTLElBQUk7IiwibmFtZXMiOlsicHJvY2VzcyIsImUiLCJab25lIiwic2VsZiIsImRlbGVnYXRlIiwicHJvcCIsIk9iamVjdEdldE93blByb3BlcnR5RGVzY3JpcHRvciIsIk9iamVjdERlZmluZVByb3BlcnR5IiwidmFsdWUiLCJfZ2xvYmFsIiwiZXZlbnQiLCJwYXRjaE9wdGlvbnMiLCJyZXR1cm5UYXJnZXQiLCJpbnRlcm5hbFdpbmRvdyIsIndpbmRvdyIsImlzQnJvd3NlciIsImlzTWl4Iiwiem9uZVN5bWJvbEV2ZW50TmFtZXMiLCJUUlVFX1NUUiIsIkZBTFNFX1NUUiIsIlpPTkVfU1lNQk9MX1BSRUZJWCIsIm5hbWUiLCJsb2FkVGFza3MiLCJFbmRpYW4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDNdfQ==