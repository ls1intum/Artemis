import {
  ArtemisMarkdownEditorModule,
  init_markdown_editor_component,
  init_markdown_editor_module
} from "/chunk-KPWFZEYZ.js";
import {
  ArtemisMarkdownService,
  init_markdown_service
} from "/chunk-7FP3FWGI.js";
import {
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/pipes/html-for-markdown.pipe.ts
import { Pipe } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var HtmlForMarkdownPipe;
var init_html_for_markdown_pipe = __esm({
  "src/main/webapp/app/shared/pipes/html-for-markdown.pipe.ts"() {
    init_markdown_service();
    init_markdown_service();
    HtmlForMarkdownPipe = class _HtmlForMarkdownPipe {
      markdownService;
      constructor(markdownService) {
        this.markdownService = markdownService;
      }
      transform(markdown, extensions = [], allowedHtmlTags = void 0, allowedHtmlAttributes = void 0) {
        return this.markdownService.safeHtmlForMarkdown(markdown, extensions, allowedHtmlTags, allowedHtmlAttributes);
      }
      static \u0275fac = function HtmlForMarkdownPipe_Factory(t) {
        return new (t || _HtmlForMarkdownPipe)(i0.\u0275\u0275directiveInject(ArtemisMarkdownService, 16));
      };
      static \u0275pipe = i0.\u0275\u0275definePipe({ name: "htmlForMarkdown", type: _HtmlForMarkdownPipe, pure: true });
    };
  }
});

// src/main/webapp/app/shared/markdown.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisMarkdownModule;
var init_markdown_module = __esm({
  "src/main/webapp/app/shared/markdown.module.ts"() {
    init_markdown_service();
    init_markdown_editor_module();
    init_markdown_editor_component();
    init_html_for_markdown_pipe();
    ArtemisMarkdownModule = class _ArtemisMarkdownModule {
      static \u0275fac = function ArtemisMarkdownModule_Factory(t) {
        return new (t || _ArtemisMarkdownModule)();
      };
      static \u0275mod = i02.\u0275\u0275defineNgModule({ type: _ArtemisMarkdownModule });
      static \u0275inj = i02.\u0275\u0275defineInjector({ providers: [ArtemisMarkdownService], imports: [ArtemisMarkdownEditorModule] });
    };
  }
});

export {
  HtmlForMarkdownPipe,
  init_html_for_markdown_pipe,
  ArtemisMarkdownModule,
  init_markdown_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3BpcGVzL2h0bWwtZm9yLW1hcmtkb3duLnBpcGUudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9tYXJrZG93bi5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGlwZSwgUGlwZVRyYW5zZm9ybSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU2hvd2Rvd25FeHRlbnNpb24gfSBmcm9tICdzaG93ZG93bic7XG5pbXBvcnQgeyBTYWZlSHRtbCB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xuaW1wb3J0IHsgQXJ0ZW1pc01hcmtkb3duU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24uc2VydmljZSc7XG5cbkBQaXBlKHtcbiAgICBuYW1lOiAnaHRtbEZvck1hcmtkb3duJyxcbn0pXG5leHBvcnQgY2xhc3MgSHRtbEZvck1hcmtkb3duUGlwZSBpbXBsZW1lbnRzIFBpcGVUcmFuc2Zvcm0ge1xuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgbWFya2Rvd25TZXJ2aWNlOiBBcnRlbWlzTWFya2Rvd25TZXJ2aWNlKSB7fVxuXG4gICAgLyoqXG4gICAgICogQ29udmVydHMgbWFya2Rvd24gaW50byBodG1sLCBzYW5pdGl6ZXMgaXQgYW5kIHRoZW4gZGVjbGFyZXMgaXQgYXMgc2FmZSB0byBieXBhc3MgZnVydGhlciBzZWN1cml0eS5cbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gbWFya2Rvd24gdGhlIG9yaWdpbmFsIG1hcmtkb3duIHRleHRcbiAgICAgKiBAcGFyYW0ge1Nob3dkb3duRXh0ZW5zaW9uW119IGV4dGVuc2lvbnMgdG8gdXNlIGZvciBtYXJrZG93biBwYXJzaW5nXG4gICAgICogQHBhcmFtIHtzdHJpbmdbXX0gYWxsb3dlZEh0bWxUYWdzIHRvIGFsbG93IGR1cmluZyBzYW5pdGl6YXRpb25cbiAgICAgKiBAcGFyYW0ge3N0cmluZ1tdfSBhbGxvd2VkSHRtbEF0dHJpYnV0ZXMgdG8gYWxsb3cgZHVyaW5nIHNhbml0aXphdGlvblxuICAgICAqIEByZXR1cm5zIHtzdHJpbmd9IHRoZSByZXN1bHRpbmcgaHRtbCBhcyBhIFNhZmVIdG1sIG9iamVjdCB0aGF0IGNhbiBiZSBpbnNlcnRlZCBpbnRvIHRoZSBhbmd1bGFyIHRlbXBsYXRlXG4gICAgICovXG4gICAgdHJhbnNmb3JtKFxuICAgICAgICBtYXJrZG93bj86IHN0cmluZyxcbiAgICAgICAgZXh0ZW5zaW9uczogU2hvd2Rvd25FeHRlbnNpb25bXSA9IFtdLFxuICAgICAgICBhbGxvd2VkSHRtbFRhZ3M6IHN0cmluZ1tdIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkLFxuICAgICAgICBhbGxvd2VkSHRtbEF0dHJpYnV0ZXM6IHN0cmluZ1tdIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkLFxuICAgICk6IFNhZmVIdG1sIHtcbiAgICAgICAgcmV0dXJuIHRoaXMubWFya2Rvd25TZXJ2aWNlLnNhZmVIdG1sRm9yTWFya2Rvd24obWFya2Rvd24sIGV4dGVuc2lvbnMsIGFsbG93ZWRIdG1sVGFncywgYWxsb3dlZEh0bWxBdHRyaWJ1dGVzKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQXJ0ZW1pc01hcmtkb3duU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24uc2VydmljZSc7XG5pbXBvcnQgeyBBcnRlbWlzTWFya2Rvd25FZGl0b3JNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9tYXJrZG93bi1lZGl0b3IubW9kdWxlJztcbmltcG9ydCB7IE1hcmtkb3duRWRpdG9yQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvbWFya2Rvd24tZWRpdG9yLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBIdG1sRm9yTWFya2Rvd25QaXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9waXBlcy9odG1sLWZvci1tYXJrZG93bi5waXBlJztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc01hcmtkb3duRWRpdG9yTW9kdWxlXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtIdG1sRm9yTWFya2Rvd25QaXBlXSxcbiAgICBwcm92aWRlcnM6IFtBcnRlbWlzTWFya2Rvd25TZXJ2aWNlXSxcbiAgICBleHBvcnRzOiBbTWFya2Rvd25FZGl0b3JDb21wb25lbnQsIEh0bWxGb3JNYXJrZG93blBpcGVdLFxufSlcbmV4cG9ydCBjbGFzcyBBcnRlbWlzTWFya2Rvd25Nb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLFlBQTJCOztBQUFwQyxJQVFhO0FBUmI7O0FBR0E7O0FBS00sSUFBTyxzQkFBUCxNQUFPLHFCQUFtQjtNQUNSO01BQXBCLFlBQW9CLGlCQUF1QztBQUF2QyxhQUFBLGtCQUFBO01BQTBDO01BVTlELFVBQ0ksVUFDQSxhQUFrQyxDQUFBLEdBQ2xDLGtCQUF3QyxRQUN4Qyx3QkFBOEMsUUFBUztBQUV2RCxlQUFPLEtBQUssZ0JBQWdCLG9CQUFvQixVQUFVLFlBQVksaUJBQWlCLHFCQUFxQjtNQUNoSDs7eUJBbEJTLHNCQUFtQiwrQkFBQSx3QkFBQSxFQUFBLENBQUE7TUFBQTtxRkFBbkIsc0JBQW1CLE1BQUEsS0FBQSxDQUFBOzs7Ozs7QUNSaEMsU0FBUyxnQkFBZ0I7O0FBQXpCLElBWWE7QUFaYjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVFNLElBQU8sd0JBQVAsTUFBTyx1QkFBcUI7O3lCQUFyQix3QkFBcUI7TUFBQTtnRUFBckIsdUJBQXFCLENBQUE7cUVBSG5CLENBQUMsc0JBQXNCLEdBQUMsU0FBQSxDQUZ6QiwyQkFBMkIsRUFBQSxDQUFBOzs7OyIsIm5hbWVzIjpbXX0=