import {
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/utils/navigation.utils.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NavigationEnd, Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { Location } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import { filter, skip, take } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
var ArtemisNavigationUtilService, getLinkToSubmissionAssessment, getExerciseDashboardLink, navigateToExamExercise, findParamInRouteHierarchy;
var init_navigation_utils = __esm({
  "src/main/webapp/app/utils/navigation.utils.ts"() {
    ArtemisNavigationUtilService = class _ArtemisNavigationUtilService {
      router;
      location;
      onFirstPage = true;
      constructor(router, location) {
        this.router = router;
        this.location = location;
        router.events.pipe(filter((e) => e instanceof NavigationEnd), skip(1), take(1)).subscribe(() => {
          this.onFirstPage = false;
        });
      }
      navigateBack(fallbackUrl) {
        if (!this.onFirstPage) {
          this.location.back();
        } else if (fallbackUrl) {
          this.router.navigate(fallbackUrl);
        }
      }
      navigateBackWithOptional(fallbackUrl, optionalLastElement) {
        if (optionalLastElement) {
          fallbackUrl.push(optionalLastElement);
        }
        this.navigateBack(fallbackUrl);
      }
      navigateForwardFromExerciseUpdateOrCreation(exercise) {
        if (exercise?.exerciseGroup?.exam?.course?.id) {
          this.router.navigate([
            "course-management",
            exercise.exerciseGroup.exam.course.id,
            "exams",
            exercise.exerciseGroup.exam.id,
            "exercise-groups",
            exercise.exerciseGroup.id,
            exercise.type + "-exercises",
            exercise.id
          ]);
        } else if (exercise?.course?.id) {
          this.router.navigate(["course-management", exercise.course.id, exercise.type + "-exercises", exercise.id]);
        } else {
          this.navigateBack();
        }
      }
      navigateBackFromExerciseUpdate(exercise) {
        let fallback = void 0;
        if (exercise?.exerciseGroup?.exam?.course?.id) {
          fallback = ["/course-management", exercise.exerciseGroup.exam.course.id, "exams", exercise.exerciseGroup.exam.id, "exercise-groups"];
        } else if (exercise?.course?.id) {
          fallback = ["/course-management", exercise.course.id, "exercises"];
        }
        this.navigateBack(fallback);
      }
      replaceNewWithIdInUrl(url, id) {
        const newUrl = url.slice(0, -3) + id;
        const regex = /http(s)?:\/\/([a-zA-Z0-9.:]*)(?<rest>\/.*)/;
        this.location.go(newUrl.match(regex).groups.rest);
      }
      routeInNewTab(route, params) {
        const url = this.router.serializeUrl(this.router.createUrlTree(route, params));
        window.open(url, "_blank");
      }
      static \u0275fac = function ArtemisNavigationUtilService_Factory(t) {
        return new (t || _ArtemisNavigationUtilService)(i0.\u0275\u0275inject(i1.Router), i0.\u0275\u0275inject(i2.Location));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _ArtemisNavigationUtilService, factory: _ArtemisNavigationUtilService.\u0275fac, providedIn: "root" });
    };
    getLinkToSubmissionAssessment = (exerciseType, courseId, exerciseId, participationId, submissionId, examId, exerciseGroupId, resultId) => {
      if (examId && exerciseGroupId) {
        const route = [
          "/course-management",
          courseId.toString(),
          "exams",
          examId.toString(),
          "exercise-groups",
          exerciseGroupId.toString(),
          exerciseType + "-exercises",
          exerciseId.toString(),
          "submissions",
          submissionId.toString(),
          "assessment"
        ];
        if (resultId) {
          route[route.length - 1] += "s";
          route.push(resultId.toString());
        }
        return route;
      } else {
        return ["/course-management", courseId.toString(), exerciseType + "-exercises", exerciseId.toString(), "submissions", submissionId.toString(), "assessment"];
      }
    };
    getExerciseDashboardLink = (courseId, exerciseId, examId = 0, isTestRun = false) => {
      if (isTestRun) {
        return ["/course-management", courseId.toString(), "exams", examId.toString(), "test-runs", "assess"];
      }
      return examId > 0 ? ["/course-management", courseId.toString(), "exams", examId.toString(), "assessment-dashboard", exerciseId.toString()] : ["/course-management", courseId.toString(), "assessment-dashboard", exerciseId.toString()];
    };
    navigateToExamExercise = (navigationUtilService, courseId, examId, exerciseGroupId, exerciseType, exerciseId, subPage) => {
      setTimeout(() => {
        navigationUtilService.routeInNewTab(["course-management", courseId, "exams", examId, "exercise-groups", exerciseGroupId, `${exerciseType}-exercises`, exerciseId, subPage]);
      }, 1e3);
    };
    findParamInRouteHierarchy = (route, paramKey) => {
      let currentRoute = route;
      while (currentRoute) {
        const paramValue = currentRoute.snapshot.params[paramKey];
        if (paramValue !== void 0) {
          return paramValue;
        }
        currentRoute = currentRoute.parent;
      }
      return void 0;
    };
  }
});

export {
  ArtemisNavigationUtilService,
  getLinkToSubmissionAssessment,
  getExerciseDashboardLink,
  navigateToExamExercise,
  findParamInRouteHierarchy,
  init_navigation_utils
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvdXRpbHMvbmF2aWdhdGlvbi51dGlscy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSwgTmF2aWdhdGlvbkVuZCwgUGFyYW1zLCBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgRXhlcmNpc2UsIEV4ZXJjaXNlVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBmaWx0ZXIsIHNraXAsIHRha2UgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc05hdmlnYXRpb25VdGlsU2VydmljZSB7XG4gICAgcHJpdmF0ZSBvbkZpcnN0UGFnZSA9IHRydWU7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcbiAgICAgICAgcHJpdmF0ZSBsb2NhdGlvbjogTG9jYXRpb24sXG4gICAgKSB7XG4gICAgICAgIHJvdXRlci5ldmVudHNcbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIGZpbHRlcigoZSkgPT4gZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpLFxuICAgICAgICAgICAgICAgIHNraXAoMSksXG4gICAgICAgICAgICAgICAgdGFrZSgxKSxcbiAgICAgICAgICAgIClcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMub25GaXJzdFBhZ2UgPSBmYWxzZTtcbiAgICAgICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE5hdmlnYXRlcyB0byB0aGUgbGFzdCBwYWdlIGlmIHBvc3NpYmxlIG9yIHRvIHRoZSBmYWxsYmFjayB1cmwgaWYgbm90XG4gICAgICogQHBhcmFtIGZhbGxiYWNrVXJsIFVybCB0byBuYXZpZ2F0ZSB0byBpZiBjdXJyZW50IHBhZ2UgaXMgZmlyc3QgbmF2aWdhdGlvblxuICAgICAqL1xuICAgIG5hdmlnYXRlQmFjayhmYWxsYmFja1VybD86IChzdHJpbmcgfCBudW1iZXIpW10pIHtcbiAgICAgICAgaWYgKCF0aGlzLm9uRmlyc3RQYWdlKSB7XG4gICAgICAgICAgICB0aGlzLmxvY2F0aW9uLmJhY2soKTtcbiAgICAgICAgfSBlbHNlIGlmIChmYWxsYmFja1VybCkge1xuICAgICAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoZmFsbGJhY2tVcmwpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTmF2aWdhdGVzIHRvIHRoZSBsYXN0IHBhZ2UgaWYgcG9zc2libGUgb3IgdG8gdGhlIGZhbGxiYWNrIHVybCBpZiBub3QuIElmIHRoZSBvcHRpb25hbCBlbGVtZW50IGlzIHByZXNlbnQsIGl0IGlzIGFwcGVuZGVkIHRvIHRoZSBmYWxsYmFjayB1cmxcbiAgICAgKiBAcGFyYW0gZmFsbGJhY2tVcmwgVXJsIHRvIG5hdmlnYXRlIHRvIGlmIGN1cnJlbnQgcGFnZSBpcyBmaXJzdCBuYXZpZ2F0aW9uXG4gICAgICogQHBhcmFtIG9wdGlvbmFsTGFzdEVsZW1lbnQgbGFzdCBlbGVtZW50IG9mIHRoZSB1cmwgb3Igbm90aGluZ1xuICAgICAqL1xuICAgIG5hdmlnYXRlQmFja1dpdGhPcHRpb25hbChmYWxsYmFja1VybDogc3RyaW5nW10sIG9wdGlvbmFsTGFzdEVsZW1lbnQ6IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICBpZiAob3B0aW9uYWxMYXN0RWxlbWVudCkge1xuICAgICAgICAgICAgZmFsbGJhY2tVcmwucHVzaChvcHRpb25hbExhc3RFbGVtZW50KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm5hdmlnYXRlQmFjayhmYWxsYmFja1VybCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTmF2aWdhdGUgdG8gZXhlcmNpc2UgZGV0YWlsIHBhZ2UgYWZ0ZXIgY3JlYXRpbmcgb3IgZWRpdGluZyBpdC5cbiAgICAgKiBAcGFyYW0gZXhlcmNpc2UgdGhlIHVwZGF0ZWQgb3IgY3JlYXRlZCBleGVyY2lzZVxuICAgICAqL1xuICAgIG5hdmlnYXRlRm9yd2FyZEZyb21FeGVyY2lzZVVwZGF0ZU9yQ3JlYXRpb24oZXhlcmNpc2U/OiBFeGVyY2lzZSkge1xuICAgICAgICBpZiAoZXhlcmNpc2U/LmV4ZXJjaXNlR3JvdXA/LmV4YW0/LmNvdXJzZT8uaWQpIHtcbiAgICAgICAgICAgIC8vIElmIGFuIGV4ZXJjaXNlIGdyb3VwIGlzIHNldCB3ZSBhcmUgaW4gZXhhbSBtb2RlXG4gICAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbXG4gICAgICAgICAgICAgICAgJ2NvdXJzZS1tYW5hZ2VtZW50JyxcbiAgICAgICAgICAgICAgICBleGVyY2lzZS5leGVyY2lzZUdyb3VwLmV4YW0uY291cnNlLmlkLFxuICAgICAgICAgICAgICAgICdleGFtcycsXG4gICAgICAgICAgICAgICAgZXhlcmNpc2UuZXhlcmNpc2VHcm91cC5leGFtLmlkISxcbiAgICAgICAgICAgICAgICAnZXhlcmNpc2UtZ3JvdXBzJyxcbiAgICAgICAgICAgICAgICBleGVyY2lzZS5leGVyY2lzZUdyb3VwLmlkISxcbiAgICAgICAgICAgICAgICBleGVyY2lzZS50eXBlISArICctZXhlcmNpc2VzJyxcbiAgICAgICAgICAgICAgICBleGVyY2lzZS5pZCxcbiAgICAgICAgICAgIF0pO1xuICAgICAgICB9IGVsc2UgaWYgKGV4ZXJjaXNlPy5jb3Vyc2U/LmlkKSB7XG4gICAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJ2NvdXJzZS1tYW5hZ2VtZW50JywgZXhlcmNpc2UuY291cnNlLmlkLCBleGVyY2lzZS50eXBlISArICctZXhlcmNpc2VzJywgZXhlcmNpc2UuaWRdKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIEZhbGxiYWNrXG4gICAgICAgICAgICB0aGlzLm5hdmlnYXRlQmFjaygpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTmF2aWdhdGUgdG8gZXhlcmNpc2UgZGV0YWlsIHBhZ2UgaWYgY2FuY2VsbGluZyB0aGUgdXBkYXRlIG9yIGNyZWF0aW9uXG4gICAgICogRWl0aGVyXG4gICAgICogLSBtb3ZlIGJhY2sgaW4gdGhlIGhpc3RvcnlcbiAgICAgKiAtIGlmIGluIGV4YW0gbW9kZSwgZ28gdG8gdGhlIGV4ZXJjaXNlIGdyb3VwIHZpZXdcbiAgICAgKiAtIGdvIHRvIGV4ZXJjaXNlcyBvdmVydmlld1xuICAgICAqIEBwYXJhbSBleGVyY2lzZSB0aGUgdXBkYXRlZCBvciBjcmVhdGVkIGV4ZXJjaXNlXG4gICAgICovXG4gICAgbmF2aWdhdGVCYWNrRnJvbUV4ZXJjaXNlVXBkYXRlKGV4ZXJjaXNlPzogRXhlcmNpc2UpIHtcbiAgICAgICAgbGV0IGZhbGxiYWNrOiAoc3RyaW5nIHwgbnVtYmVyKVtdIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuICAgICAgICBpZiAoZXhlcmNpc2U/LmV4ZXJjaXNlR3JvdXA/LmV4YW0/LmNvdXJzZT8uaWQpIHtcbiAgICAgICAgICAgIC8vIElmIGFuIGV4ZXJjaXNlIGdyb3VwIGlzIHNldCB3ZSBhcmUgaW4gZXhhbSBtb2RlXG4gICAgICAgICAgICBmYWxsYmFjayA9IFsnL2NvdXJzZS1tYW5hZ2VtZW50JywgZXhlcmNpc2UuZXhlcmNpc2VHcm91cC5leGFtLmNvdXJzZS5pZCwgJ2V4YW1zJywgZXhlcmNpc2UuZXhlcmNpc2VHcm91cC5leGFtLmlkISwgJ2V4ZXJjaXNlLWdyb3VwcyddO1xuICAgICAgICB9IGVsc2UgaWYgKGV4ZXJjaXNlPy5jb3Vyc2U/LmlkKSB7XG4gICAgICAgICAgICBmYWxsYmFjayA9IFsnL2NvdXJzZS1tYW5hZ2VtZW50JywgZXhlcmNpc2UuY291cnNlLmlkLCAnZXhlcmNpc2VzJ107XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5uYXZpZ2F0ZUJhY2soZmFsbGJhY2spO1xuICAgIH1cblxuICAgIHJlcGxhY2VOZXdXaXRoSWRJblVybCh1cmw6IHN0cmluZywgaWQ6IG51bWJlcikge1xuICAgICAgICBjb25zdCBuZXdVcmwgPSB1cmwuc2xpY2UoMCwgLTMpICsgaWQ7XG4gICAgICAgIGNvbnN0IHJlZ2V4ID0gL2h0dHAocyk/OlxcL1xcLyhbYS16QS1aMC05LjpdKikoPzxyZXN0PlxcLy4qKS87XG4gICAgICAgIHRoaXMubG9jYXRpb24uZ28obmV3VXJsLm1hdGNoKHJlZ2V4KSEuZ3JvdXBzIS5yZXN0KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBPcGVucyB0aGUgdGFyZ2V0IHBhZ2UgaW4gYSBuZXcgdGFiXG4gICAgICogQHBhcmFtIHJvdXRlIHRoZSB0YXJnZXQgcm91dGVcbiAgICAgKiBAcGFyYW0gcGFyYW1zIHRoZSBxdWVyeSBwYXJhbXMgb2YgdGhlIHRhcmdldCByb3V0ZVxuICAgICAqL1xuICAgIHJvdXRlSW5OZXdUYWIocm91dGU6IGFueVtdLCBwYXJhbXM/OiBQYXJhbXMpOiB2b2lkIHtcbiAgICAgICAgY29uc3QgdXJsID0gdGhpcy5yb3V0ZXIuc2VyaWFsaXplVXJsKHRoaXMucm91dGVyLmNyZWF0ZVVybFRyZWUocm91dGUsIHBhcmFtcykpO1xuICAgICAgICB3aW5kb3cub3Blbih1cmwsICdfYmxhbmsnKTtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBnZXRMaW5rVG9TdWJtaXNzaW9uQXNzZXNzbWVudCA9IChcbiAgICBleGVyY2lzZVR5cGU6IEV4ZXJjaXNlVHlwZSxcbiAgICBjb3Vyc2VJZDogbnVtYmVyLFxuICAgIGV4ZXJjaXNlSWQ6IG51bWJlcixcbiAgICBwYXJ0aWNpcGF0aW9uSWQ6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgICBzdWJtaXNzaW9uSWQ6IG51bWJlciB8ICduZXcnLFxuICAgIGV4YW1JZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuICAgIGV4ZXJjaXNlR3JvdXBJZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuICAgIHJlc3VsdElkPzogbnVtYmVyLFxuKTogc3RyaW5nW10gPT4ge1xuICAgIGlmIChleGFtSWQgJiYgZXhlcmNpc2VHcm91cElkKSB7XG4gICAgICAgIGNvbnN0IHJvdXRlID0gW1xuICAgICAgICAgICAgJy9jb3Vyc2UtbWFuYWdlbWVudCcsXG4gICAgICAgICAgICBjb3Vyc2VJZC50b1N0cmluZygpLFxuICAgICAgICAgICAgJ2V4YW1zJyxcbiAgICAgICAgICAgIGV4YW1JZC50b1N0cmluZygpLFxuICAgICAgICAgICAgJ2V4ZXJjaXNlLWdyb3VwcycsXG4gICAgICAgICAgICBleGVyY2lzZUdyb3VwSWQudG9TdHJpbmcoKSxcbiAgICAgICAgICAgIGV4ZXJjaXNlVHlwZSArICctZXhlcmNpc2VzJyxcbiAgICAgICAgICAgIGV4ZXJjaXNlSWQudG9TdHJpbmcoKSxcbiAgICAgICAgICAgICdzdWJtaXNzaW9ucycsXG4gICAgICAgICAgICBzdWJtaXNzaW9uSWQudG9TdHJpbmcoKSxcbiAgICAgICAgICAgICdhc3Nlc3NtZW50JyxcbiAgICAgICAgXTtcbiAgICAgICAgaWYgKHJlc3VsdElkKSB7XG4gICAgICAgICAgICByb3V0ZVtyb3V0ZS5sZW5ndGggLSAxXSArPSAncyc7XG4gICAgICAgICAgICByb3V0ZS5wdXNoKHJlc3VsdElkLnRvU3RyaW5nKCkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByb3V0ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gWycvY291cnNlLW1hbmFnZW1lbnQnLCBjb3Vyc2VJZC50b1N0cmluZygpLCBleGVyY2lzZVR5cGUgKyAnLWV4ZXJjaXNlcycsIGV4ZXJjaXNlSWQudG9TdHJpbmcoKSwgJ3N1Ym1pc3Npb25zJywgc3VibWlzc2lvbklkLnRvU3RyaW5nKCksICdhc3Nlc3NtZW50J107XG4gICAgfVxufTtcblxuZXhwb3J0IGNvbnN0IGdldEV4ZXJjaXNlRGFzaGJvYXJkTGluayA9IChjb3Vyc2VJZDogbnVtYmVyLCBleGVyY2lzZUlkOiBudW1iZXIsIGV4YW1JZCA9IDAsIGlzVGVzdFJ1biA9IGZhbHNlKTogc3RyaW5nW10gPT4ge1xuICAgIGlmIChpc1Rlc3RSdW4pIHtcbiAgICAgICAgcmV0dXJuIFsnL2NvdXJzZS1tYW5hZ2VtZW50JywgY291cnNlSWQudG9TdHJpbmcoKSwgJ2V4YW1zJywgZXhhbUlkLnRvU3RyaW5nKCksICd0ZXN0LXJ1bnMnLCAnYXNzZXNzJ107XG4gICAgfVxuXG4gICAgcmV0dXJuIGV4YW1JZCA+IDBcbiAgICAgICAgPyBbJy9jb3Vyc2UtbWFuYWdlbWVudCcsIGNvdXJzZUlkLnRvU3RyaW5nKCksICdleGFtcycsIGV4YW1JZC50b1N0cmluZygpLCAnYXNzZXNzbWVudC1kYXNoYm9hcmQnLCBleGVyY2lzZUlkLnRvU3RyaW5nKCldXG4gICAgICAgIDogWycvY291cnNlLW1hbmFnZW1lbnQnLCBjb3Vyc2VJZC50b1N0cmluZygpLCAnYXNzZXNzbWVudC1kYXNoYm9hcmQnLCBleGVyY2lzZUlkLnRvU3RyaW5nKCldO1xufTtcblxuLyoqXG4gKiBBIGdlbmVyaWMgbWV0aG9kIHdoaWNoIG5hdmlnYXRlcyBpbnRvIGEgc3VicGFnZSBvZiBhbiBleGFtIGV4ZXJjaXNlXG4gKiBAcm91dGVyIHRoZSByb3V0ZXIgdGggY29tcG9uZW50IHVzZXMgdG8gbmF2aWdhdGUgaW50byBkaWZmZXJlbnQgd2VicGFnZXNcbiAqIEBzdWJQYWdlIHRoZSBzdWJwYWdlIG9mIGFuIGV4ZXJjaXNlIHdoaWNoIHdlIHdhbnQgdG8gbmF2aWdhdGUgaW50bywgZS5nLiBzY29yZXNcbiAqL1xuZXhwb3J0IGNvbnN0IG5hdmlnYXRlVG9FeGFtRXhlcmNpc2UgPSAoXG4gICAgbmF2aWdhdGlvblV0aWxTZXJ2aWNlOiBBcnRlbWlzTmF2aWdhdGlvblV0aWxTZXJ2aWNlLFxuICAgIGNvdXJzZUlkOiBudW1iZXIsXG4gICAgZXhhbUlkOiBudW1iZXIsXG4gICAgZXhlcmNpc2VHcm91cElkOiBudW1iZXIsXG4gICAgZXhlcmNpc2VUeXBlOiBFeGVyY2lzZVR5cGUsXG4gICAgZXhlcmNpc2VJZDogbnVtYmVyLFxuICAgIHN1YlBhZ2U6IHN0cmluZyxcbik6IHZvaWQgPT4ge1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBuYXZpZ2F0aW9uVXRpbFNlcnZpY2Uucm91dGVJbk5ld1RhYihbJ2NvdXJzZS1tYW5hZ2VtZW50JywgY291cnNlSWQsICdleGFtcycsIGV4YW1JZCwgJ2V4ZXJjaXNlLWdyb3VwcycsIGV4ZXJjaXNlR3JvdXBJZCwgYCR7ZXhlcmNpc2VUeXBlfS1leGVyY2lzZXNgLCBleGVyY2lzZUlkLCBzdWJQYWdlXSk7XG4gICAgfSwgMTAwMCk7XG59O1xuXG4vKipcbiAqIENoZWNrcyByb3V0ZXIgaGllcmFyY2h5IHRvIGZpbmQgYSBnaXZlbiBwYXJhbUtleSwgc3RhcnRpbmcgZnJvbSB0aGUgY3VycmVudCBBY3RpdmF0ZWRSb3V0ZVNuYXBzaG90XG4gKiBhbmQgdHJhdmVyc2luZyB0aGUgcGFyZW50cy5cbiAqIEBwYXJhbSByb3V0ZSB0aGUgYWN0aXZlIHJvdXRlXG4gKiBAcGFyYW0gcGFyYW1LZXkgdGhlIGRlc2lyZWQga2V5IG9mIHJvdXRlLnNuYXBzaG90LnBhcmFtc1xuICovXG5leHBvcnQgY29uc3QgZmluZFBhcmFtSW5Sb3V0ZUhpZXJhcmNoeSA9IChyb3V0ZTogQWN0aXZhdGVkUm91dGUsIHBhcmFtS2V5OiBzdHJpbmcpOiBzdHJpbmcgfCB1bmRlZmluZWQgPT4ge1xuICAgIGxldCBjdXJyZW50Um91dGU6IEFjdGl2YXRlZFJvdXRlIHwgbnVsbCA9IHJvdXRlO1xuICAgIHdoaWxlIChjdXJyZW50Um91dGUpIHtcbiAgICAgICAgY29uc3QgcGFyYW1WYWx1ZSA9IGN1cnJlbnRSb3V0ZS5zbmFwc2hvdC5wYXJhbXNbcGFyYW1LZXldO1xuICAgICAgICBpZiAocGFyYW1WYWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICByZXR1cm4gcGFyYW1WYWx1ZTtcbiAgICAgICAgfVxuICAgICAgICBjdXJyZW50Um91dGUgPSBjdXJyZW50Um91dGUucGFyZW50O1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xufTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxTQUFTLGtCQUFrQjtBQUMzQixTQUF5QixlQUF1QixjQUFjO0FBQzlELFNBQVMsZ0JBQWdCO0FBRXpCLFNBQVMsUUFBUSxNQUFNLFlBQVk7Ozs7QUFKbkMsSUFPYSw4QkF1R0EsK0JBa0NBLDBCQWVBLHdCQW9CQTtBQW5MYjs7QUFPTSxJQUFPLCtCQUFQLE1BQU8sOEJBQTRCO01BSXpCO01BQ0E7TUFKSixjQUFjO01BRXRCLFlBQ1ksUUFDQSxVQUFrQjtBQURsQixhQUFBLFNBQUE7QUFDQSxhQUFBLFdBQUE7QUFFUixlQUFPLE9BQ0YsS0FDRyxPQUFPLENBQUMsTUFBTSxhQUFhLGFBQWEsR0FDeEMsS0FBSyxDQUFDLEdBQ04sS0FBSyxDQUFDLENBQUMsRUFFVixVQUFVLE1BQUs7QUFDWixlQUFLLGNBQWM7UUFDdkIsQ0FBQztNQUNUO01BTUEsYUFBYSxhQUFpQztBQUMxQyxZQUFJLENBQUMsS0FBSyxhQUFhO0FBQ25CLGVBQUssU0FBUyxLQUFJO21CQUNYLGFBQWE7QUFDcEIsZUFBSyxPQUFPLFNBQVMsV0FBVzs7TUFFeEM7TUFPQSx5QkFBeUIsYUFBdUIscUJBQXVDO0FBQ25GLFlBQUkscUJBQXFCO0FBQ3JCLHNCQUFZLEtBQUssbUJBQW1COztBQUV4QyxhQUFLLGFBQWEsV0FBVztNQUNqQztNQU1BLDRDQUE0QyxVQUFtQjtBQUMzRCxZQUFJLFVBQVUsZUFBZSxNQUFNLFFBQVEsSUFBSTtBQUUzQyxlQUFLLE9BQU8sU0FBUztZQUNqQjtZQUNBLFNBQVMsY0FBYyxLQUFLLE9BQU87WUFDbkM7WUFDQSxTQUFTLGNBQWMsS0FBSztZQUM1QjtZQUNBLFNBQVMsY0FBYztZQUN2QixTQUFTLE9BQVE7WUFDakIsU0FBUztXQUNaO21CQUNNLFVBQVUsUUFBUSxJQUFJO0FBQzdCLGVBQUssT0FBTyxTQUFTLENBQUMscUJBQXFCLFNBQVMsT0FBTyxJQUFJLFNBQVMsT0FBUSxjQUFjLFNBQVMsRUFBRSxDQUFDO2VBQ3ZHO0FBRUgsZUFBSyxhQUFZOztNQUV6QjtNQVVBLCtCQUErQixVQUFtQjtBQUM5QyxZQUFJLFdBQTRDO0FBQ2hELFlBQUksVUFBVSxlQUFlLE1BQU0sUUFBUSxJQUFJO0FBRTNDLHFCQUFXLENBQUMsc0JBQXNCLFNBQVMsY0FBYyxLQUFLLE9BQU8sSUFBSSxTQUFTLFNBQVMsY0FBYyxLQUFLLElBQUssaUJBQWlCO21CQUM3SCxVQUFVLFFBQVEsSUFBSTtBQUM3QixxQkFBVyxDQUFDLHNCQUFzQixTQUFTLE9BQU8sSUFBSSxXQUFXOztBQUVyRSxhQUFLLGFBQWEsUUFBUTtNQUM5QjtNQUVBLHNCQUFzQixLQUFhLElBQVU7QUFDekMsY0FBTSxTQUFTLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSTtBQUNsQyxjQUFNLFFBQVE7QUFDZCxhQUFLLFNBQVMsR0FBRyxPQUFPLE1BQU0sS0FBSyxFQUFHLE9BQVEsSUFBSTtNQUN0RDtNQU9BLGNBQWMsT0FBYyxRQUFlO0FBQ3ZDLGNBQU0sTUFBTSxLQUFLLE9BQU8sYUFBYSxLQUFLLE9BQU8sY0FBYyxPQUFPLE1BQU0sQ0FBQztBQUM3RSxlQUFPLEtBQUssS0FBSyxRQUFRO01BQzdCOzt5QkFwR1MsK0JBQTRCLHNCQUFBLFNBQUEsR0FBQSxzQkFBQSxXQUFBLENBQUE7TUFBQTttRUFBNUIsK0JBQTRCLFNBQTVCLDhCQUE0QixXQUFBLFlBRGYsT0FBTSxDQUFBOztBQXdHekIsSUFBTSxnQ0FBZ0MsQ0FDekMsY0FDQSxVQUNBLFlBQ0EsaUJBQ0EsY0FDQSxRQUNBLGlCQUNBLGFBQ1U7QUFDVixVQUFJLFVBQVUsaUJBQWlCO0FBQzNCLGNBQU0sUUFBUTtVQUNWO1VBQ0EsU0FBUyxTQUFRO1VBQ2pCO1VBQ0EsT0FBTyxTQUFRO1VBQ2Y7VUFDQSxnQkFBZ0IsU0FBUTtVQUN4QixlQUFlO1VBQ2YsV0FBVyxTQUFRO1VBQ25CO1VBQ0EsYUFBYSxTQUFRO1VBQ3JCOztBQUVKLFlBQUksVUFBVTtBQUNWLGdCQUFNLE1BQU0sU0FBUyxDQUFDLEtBQUs7QUFDM0IsZ0JBQU0sS0FBSyxTQUFTLFNBQVEsQ0FBRTs7QUFFbEMsZUFBTzthQUNKO0FBQ0gsZUFBTyxDQUFDLHNCQUFzQixTQUFTLFNBQVEsR0FBSSxlQUFlLGNBQWMsV0FBVyxTQUFRLEdBQUksZUFBZSxhQUFhLFNBQVEsR0FBSSxZQUFZOztJQUVuSztBQUVPLElBQU0sMkJBQTJCLENBQUMsVUFBa0IsWUFBb0IsU0FBUyxHQUFHLFlBQVksVUFBbUI7QUFDdEgsVUFBSSxXQUFXO0FBQ1gsZUFBTyxDQUFDLHNCQUFzQixTQUFTLFNBQVEsR0FBSSxTQUFTLE9BQU8sU0FBUSxHQUFJLGFBQWEsUUFBUTs7QUFHeEcsYUFBTyxTQUFTLElBQ1YsQ0FBQyxzQkFBc0IsU0FBUyxTQUFRLEdBQUksU0FBUyxPQUFPLFNBQVEsR0FBSSx3QkFBd0IsV0FBVyxTQUFRLENBQUUsSUFDckgsQ0FBQyxzQkFBc0IsU0FBUyxTQUFRLEdBQUksd0JBQXdCLFdBQVcsU0FBUSxDQUFFO0lBQ25HO0FBT08sSUFBTSx5QkFBeUIsQ0FDbEMsdUJBQ0EsVUFDQSxRQUNBLGlCQUNBLGNBQ0EsWUFDQSxZQUNNO0FBQ04saUJBQVcsTUFBSztBQUNaLDhCQUFzQixjQUFjLENBQUMscUJBQXFCLFVBQVUsU0FBUyxRQUFRLG1CQUFtQixpQkFBaUIsR0FBRyxZQUFZLGNBQWMsWUFBWSxPQUFPLENBQUM7TUFDOUssR0FBRyxHQUFJO0lBQ1g7QUFRTyxJQUFNLDRCQUE0QixDQUFDLE9BQXVCLGFBQXdDO0FBQ3JHLFVBQUksZUFBc0M7QUFDMUMsYUFBTyxjQUFjO0FBQ2pCLGNBQU0sYUFBYSxhQUFhLFNBQVMsT0FBTyxRQUFRO0FBQ3hELFlBQUksZUFBZSxRQUFXO0FBQzFCLGlCQUFPOztBQUVYLHVCQUFlLGFBQWE7O0FBRWhDLGFBQU87SUFDWDs7OyIsIm5hbWVzIjpbXX0=