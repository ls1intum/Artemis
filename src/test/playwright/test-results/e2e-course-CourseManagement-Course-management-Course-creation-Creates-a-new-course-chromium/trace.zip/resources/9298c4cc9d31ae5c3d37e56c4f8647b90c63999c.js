import {
  esm_default
} from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-DIGADL7D.js?v=b97f8625";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NQN5E7X4.js?v=b97f8625";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-2NJ35WEY.js?v=b97f8625";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NI5XS6XH.js?v=b97f8625";
export {
  esm_default as default
};
//# sourceMappingURL=dayjs_esm.js.map
