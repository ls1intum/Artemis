import {
  ArtemisSharedComponentModule,
  init_exam_model,
  init_shared_component_module
} from "/chunk-ORYTP7RT.js";
import {
  ActionType,
  AlertService,
  ArtemisSharedCommonModule,
  ArtemisTranslatePipe,
  ButtonComponent,
  ButtonSize,
  ButtonType,
  CourseManagementService,
  ExamManagementService,
  HelpIconComponent,
  TranslateDirective,
  TutorialGroupsService,
  __async,
  __esm,
  init_alert_service,
  init_artemis_translate_pipe,
  init_button_component,
  init_course_management_service,
  init_delete_dialog_model,
  init_exam_management_service,
  init_help_icon_component,
  init_shared_common_module,
  init_translate_directive,
  init_tutorial_groups_service
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/user-import/users-import-dialog.component.ts
import { Component, Input, ViewChild, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgForm } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import { NgbActiveModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { Subject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import __vite__cjsImport6_papaparse from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/papaparse.js?v=1d0d9ead"; const parse = __vite__cjsImport6_papaparse["parse"];
import { faArrowRight, faBan, faCheck, faCircleNotch, faSpinner, faUpload } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i7 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i8 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function UsersImportDialogComponent_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275elementStart(1, "div", 17);
    i0.\u0275\u0275text(2, "\n                ");
    i0.\u0275\u0275elementStart(3, "table", 18);
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275elementStart(5, "thead");
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "tr");
    i0.\u0275\u0275text(8, "\n                            ");
    i0.\u0275\u0275elementStart(9, "th");
    i0.\u0275\u0275text(10, "Login");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                            ");
    i0.\u0275\u0275elementStart(12, "th", 3);
    i0.\u0275\u0275text(13, "Email");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(14, "\n                            ");
    i0.\u0275\u0275elementStart(15, "th", 3);
    i0.\u0275\u0275text(16, "Matriculation Number");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(17, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(18, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(19, "\n                    ");
    i0.\u0275\u0275elementStart(20, "tbody");
    i0.\u0275\u0275text(21, "\n                        ");
    i0.\u0275\u0275elementStart(22, "tr");
    i0.\u0275\u0275text(23, "\n                            ");
    i0.\u0275\u0275elementStart(24, "td");
    i0.\u0275\u0275text(25, "user_1");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(26, "\n                            ");
    i0.\u0275\u0275element(27, "td");
    i0.\u0275\u0275text(28, "\n                            ");
    i0.\u0275\u0275element(29, "td");
    i0.\u0275\u0275text(30, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(31, "\n                        ");
    i0.\u0275\u0275elementStart(32, "tr");
    i0.\u0275\u0275text(33, "\n                            ");
    i0.\u0275\u0275element(34, "td");
    i0.\u0275\u0275text(35, "\n                            ");
    i0.\u0275\u0275elementStart(36, "td");
    i0.\u0275\u0275text(37, "user_2@artemis.org");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(38, "\n                            ");
    i0.\u0275\u0275element(39, "td");
    i0.\u0275\u0275text(40, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(41, "\n                        ");
    i0.\u0275\u0275elementStart(42, "tr");
    i0.\u0275\u0275text(43, "\n                            ");
    i0.\u0275\u0275element(44, "td");
    i0.\u0275\u0275text(45, "\n                            ");
    i0.\u0275\u0275element(46, "td");
    i0.\u0275\u0275text(47, "\n                            ");
    i0.\u0275\u0275elementStart(48, "td");
    i0.\u0275\u0275text(49, "11712345");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(50, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(51, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(52, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(53, "\n                ");
    i0.\u0275\u0275element(54, "fa-icon", 19);
    i0.\u0275\u0275text(55, "\n                ");
    i0.\u0275\u0275elementStart(56, "span");
    i0.\u0275\u0275text(57, "user_1, user_2, user_3");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(58, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(59, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(12);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.email");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.registrationNumber");
    i0.\u0275\u0275advance(39);
    i0.\u0275\u0275property("icon", ctx_r0.faArrowRight);
  }
}
function UsersImportDialogComponent_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275elementStart(1, "div", 17);
    i0.\u0275\u0275text(2, "\n                ");
    i0.\u0275\u0275elementStart(3, "table", 18);
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275elementStart(5, "thead");
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "tr");
    i0.\u0275\u0275text(8, "\n                            ");
    i0.\u0275\u0275elementStart(9, "th");
    i0.\u0275\u0275text(10, "Login");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                            ");
    i0.\u0275\u0275elementStart(12, "th", 3);
    i0.\u0275\u0275text(13, "Email");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(14, "\n                            ");
    i0.\u0275\u0275elementStart(15, "th", 3);
    i0.\u0275\u0275text(16, "Matriculation Number");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(17, "\n                            ");
    i0.\u0275\u0275elementStart(18, "th", 3);
    i0.\u0275\u0275text(19, "Room");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(20, "\n                            ");
    i0.\u0275\u0275elementStart(21, "th", 3);
    i0.\u0275\u0275text(22, "Seat");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(23, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(24, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(25, "\n                    ");
    i0.\u0275\u0275elementStart(26, "tbody");
    i0.\u0275\u0275text(27, "\n                        ");
    i0.\u0275\u0275elementStart(28, "tr");
    i0.\u0275\u0275text(29, "\n                            ");
    i0.\u0275\u0275elementStart(30, "td");
    i0.\u0275\u0275text(31, "user_1");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(32, "\n                            ");
    i0.\u0275\u0275elementStart(33, "td");
    i0.\u0275\u0275text(34, "user_2@artemis.org");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(35, "\n                            ");
    i0.\u0275\u0275elementStart(36, "td");
    i0.\u0275\u0275text(37, "11712345");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(38, "\n                            ");
    i0.\u0275\u0275elementStart(39, "td");
    i0.\u0275\u0275text(40, "10.101");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(41, "\n                            ");
    i0.\u0275\u0275elementStart(42, "td");
    i0.\u0275\u0275text(43, "25F");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(44, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(45, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(46, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(47, "\n                ");
    i0.\u0275\u0275element(48, "fa-icon", 19);
    i0.\u0275\u0275text(49, "\n                ");
    i0.\u0275\u0275elementStart(50, "span");
    i0.\u0275\u0275text(51, "user_1");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(52, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(53, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(12);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.email");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.registrationNumber");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.room");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.seat");
    i0.\u0275\u0275advance(27);
    i0.\u0275\u0275property("icon", ctx_r1.faArrowRight);
  }
}
function UsersImportDialogComponent_Conditional_39_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275element(1, "fa-icon", 20);
    i0.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    const ctx_r2 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("icon", ctx_r2.faSpinner)("spin", true);
  }
}
function UsersImportDialogComponent_Conditional_45_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                                ");
    i0.\u0275\u0275elementStart(1, "li");
    i0.\u0275\u0275text(2, "\n                                    ");
    i0.\u0275\u0275element(3, "b", 3);
    i0.\u0275\u0275text(4, "\n                                    ");
    i0.\u0275\u0275elementStart(5, "b", 23);
    i0.\u0275\u0275text(6, " ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r10 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.usersForImport.failedRows");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("innerHTML", ctx_r10.validationError, i0.\u0275\u0275sanitizeHtml);
  }
}
function UsersImportDialogComponent_Conditional_45_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                                ");
    i0.\u0275\u0275elementStart(1, "li");
    i0.\u0275\u0275text(2, "\n                                    ");
    i0.\u0275\u0275element(3, "b", 3);
    i0.\u0275\u0275text(4, "\n                                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n                            ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.usersForImport.noUsersFound");
  }
}
function UsersImportDialogComponent_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "div", 21);
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275element(3, "div", 3);
    i0.\u0275\u0275text(4, "\n                        ");
    i0.\u0275\u0275elementStart(5, "ul", 22);
    i0.\u0275\u0275text(6, "\n                            ");
    i0.\u0275\u0275template(7, UsersImportDialogComponent_Conditional_45_Conditional_7_Template, 9, 2)(8, UsersImportDialogComponent_Conditional_45_Conditional_8_Template, 6, 1);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                ");
  }
  if (rf & 2) {
    const ctx_r3 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.usersForImport.importFailed");
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275conditional(7, ctx_r3.validationError ? 7 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(8, ctx_r3.noUsersFoundError ? 8 : -1);
  }
}
function UsersImportDialogComponent_Conditional_48_For_40_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275elementStart(1, "tr");
    i0.\u0275\u0275text(2, "\n                                ");
    i0.\u0275\u0275elementStart(3, "th", 32);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n                                ");
    i0.\u0275\u0275elementStart(6, "td", 33);
    i0.\u0275\u0275text(7);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                                ");
    i0.\u0275\u0275elementStart(9, "td");
    i0.\u0275\u0275text(10);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                                ");
    i0.\u0275\u0275elementStart(12, "td");
    i0.\u0275\u0275text(13);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(14, "\n                                ");
    i0.\u0275\u0275elementStart(15, "td");
    i0.\u0275\u0275text(16);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(17, "\n                                ");
    i0.\u0275\u0275elementStart(18, "td");
    i0.\u0275\u0275text(19);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(20, "\n                            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(21, "\n                        ");
  }
  if (rf & 2) {
    const user_r13 = ctx.$implicit;
    const i_r14 = ctx.$index;
    const ctx_r12 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275classProp("import-success", ctx_r12.wasImported(user_r13))("import-fail", ctx_r12.wasNotImported(user_r13));
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(i_r14 + 1);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(user_r13.registrationNumber);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(user_r13.login);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(user_r13.email);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(user_r13.firstName);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(user_r13.lastName);
  }
}
function UsersImportDialogComponent_Conditional_48_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275elementStart(1, "div", 24);
    i0.\u0275\u0275text(2, "\n                ");
    i0.\u0275\u0275elementStart(3, "div");
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275elementStart(5, "label", 25);
    i0.\u0275\u0275text(6, " Users for import");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                    ");
    i0.\u0275\u0275element(8, "jhi-help-icon", 26);
    i0.\u0275\u0275text(9, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                ");
    i0.\u0275\u0275elementStart(11, "table", 27);
    i0.\u0275\u0275text(12, "\n                    ");
    i0.\u0275\u0275elementStart(13, "thead");
    i0.\u0275\u0275text(14, "\n                        ");
    i0.\u0275\u0275elementStart(15, "tr");
    i0.\u0275\u0275text(16, "\n                            ");
    i0.\u0275\u0275elementStart(17, "th", 28);
    i0.\u0275\u0275text(18, "#");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(19, "\n                            ");
    i0.\u0275\u0275elementStart(20, "th", 29);
    i0.\u0275\u0275text(21, "Matriculation number");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(22, "\n                            ");
    i0.\u0275\u0275elementStart(23, "th", 28);
    i0.\u0275\u0275text(24, "Login");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(25, "\n                            ");
    i0.\u0275\u0275elementStart(26, "th", 30);
    i0.\u0275\u0275text(27, "Email");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(28, "\n                            ");
    i0.\u0275\u0275elementStart(29, "th", 30);
    i0.\u0275\u0275text(30, "First name");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(31, "\n                            ");
    i0.\u0275\u0275elementStart(32, "th", 30);
    i0.\u0275\u0275text(33, "Last name");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(34, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(35, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(36, "\n                    ");
    i0.\u0275\u0275elementStart(37, "tbody", 31);
    i0.\u0275\u0275text(38, "\n                        ");
    i0.\u0275\u0275repeaterCreate(39, UsersImportDialogComponent_Conditional_48_For_40_Template, 22, 10, null, null, i0.\u0275\u0275repeaterTrackByIdentity);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(41, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(42, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(43, "\n        ");
  }
  if (rf & 2) {
    const ctx_r4 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(20);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.registrationNumber");
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.email");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.firstName");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.lastName");
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275repeater(ctx_r4.usersToImport);
  }
}
function UsersImportDialogComponent_Conditional_49_For_46_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275elementStart(1, "tr");
    i0.\u0275\u0275text(2, "\n                                ");
    i0.\u0275\u0275elementStart(3, "th", 32);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n                                ");
    i0.\u0275\u0275elementStart(6, "td", 36);
    i0.\u0275\u0275text(7);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                                ");
    i0.\u0275\u0275elementStart(9, "td");
    i0.\u0275\u0275text(10);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                                ");
    i0.\u0275\u0275elementStart(12, "td");
    i0.\u0275\u0275text(13);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(14, "\n                                ");
    i0.\u0275\u0275elementStart(15, "td");
    i0.\u0275\u0275text(16);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(17, "\n                                ");
    i0.\u0275\u0275elementStart(18, "td");
    i0.\u0275\u0275text(19);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(20, "\n                                ");
    i0.\u0275\u0275elementStart(21, "td");
    i0.\u0275\u0275text(22);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(23, "\n                                ");
    i0.\u0275\u0275elementStart(24, "td");
    i0.\u0275\u0275text(25);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(26, "\n                            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(27, "\n                        ");
  }
  if (rf & 2) {
    const user_r19 = ctx.$implicit;
    const i_r20 = ctx.$index;
    const ctx_r18 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275classProp("import-success", ctx_r18.wasImported(user_r19))("import-fail", ctx_r18.wasNotImported(user_r19));
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(i_r20 + 1);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(user_r19.registrationNumber);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(user_r19.login);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(user_r19.email);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(user_r19.firstName);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(user_r19.lastName);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(user_r19.room);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(user_r19.seat);
  }
}
function UsersImportDialogComponent_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275elementStart(1, "div", 34);
    i0.\u0275\u0275text(2, "\n                ");
    i0.\u0275\u0275elementStart(3, "div");
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275elementStart(5, "label", 25);
    i0.\u0275\u0275text(6, " Users for import");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                    ");
    i0.\u0275\u0275element(8, "jhi-help-icon", 26);
    i0.\u0275\u0275text(9, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                ");
    i0.\u0275\u0275elementStart(11, "table", 27);
    i0.\u0275\u0275text(12, "\n                    ");
    i0.\u0275\u0275elementStart(13, "thead");
    i0.\u0275\u0275text(14, "\n                        ");
    i0.\u0275\u0275elementStart(15, "tr");
    i0.\u0275\u0275text(16, "\n                            ");
    i0.\u0275\u0275elementStart(17, "th", 28);
    i0.\u0275\u0275text(18, "#");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(19, "\n                            ");
    i0.\u0275\u0275elementStart(20, "th", 35);
    i0.\u0275\u0275text(21, "Matriculation number");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(22, "\n                            ");
    i0.\u0275\u0275elementStart(23, "th", 28);
    i0.\u0275\u0275text(24, "Login");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(25, "\n                            ");
    i0.\u0275\u0275elementStart(26, "th", 30);
    i0.\u0275\u0275text(27, "Email");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(28, "\n                            ");
    i0.\u0275\u0275elementStart(29, "th", 30);
    i0.\u0275\u0275text(30, "First name");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(31, "\n                            ");
    i0.\u0275\u0275elementStart(32, "th", 30);
    i0.\u0275\u0275text(33, "Last name");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(34, "\n                            ");
    i0.\u0275\u0275elementStart(35, "th", 30);
    i0.\u0275\u0275text(36, "Room");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(37, "\n                            ");
    i0.\u0275\u0275elementStart(38, "th", 30);
    i0.\u0275\u0275text(39, "Seat");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(40, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(41, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(42, "\n                    ");
    i0.\u0275\u0275elementStart(43, "tbody", 31);
    i0.\u0275\u0275text(44, "\n                        ");
    i0.\u0275\u0275repeaterCreate(45, UsersImportDialogComponent_Conditional_49_For_46_Template, 28, 12, null, null, i0.\u0275\u0275repeaterTrackByIdentity);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(47, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(48, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(49, "\n        ");
  }
  if (rf & 2) {
    const ctx_r5 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(20);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.registrationNumber");
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.email");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.firstName");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.lastName");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.exam.examUsers.room");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("jhiTranslate", "artemisApp.exam.examUsers.seat");
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275repeater(ctx_r5.examUsersToImport);
  }
}
function UsersImportDialogComponent_Conditional_53_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275elementStart(3, "strong");
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275pipe(5, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "span");
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                ");
  }
  if (rf & 2) {
    const ctx_r24 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(5, 2, "artemisApp.importUsers.numberOfUsers"));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate1("\xA0", ctx_r24.usersToImport.length, "");
  }
}
function UsersImportDialogComponent_Conditional_53_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275elementStart(3, "strong");
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275pipe(5, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "span");
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                    ");
    i0.\u0275\u0275elementStart(11, "div", 38);
    i0.\u0275\u0275text(12, "\n                        ");
    i0.\u0275\u0275elementStart(13, "strong");
    i0.\u0275\u0275text(14);
    i0.\u0275\u0275pipe(15, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(16, "\n                        ");
    i0.\u0275\u0275elementStart(17, "span")(18, "b", 39);
    i0.\u0275\u0275text(19);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(20, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(21, "\n                ");
  }
  if (rf & 2) {
    const ctx_r25 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(5, 4, "artemisApp.importUsers.numberOfUsersImported"));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(ctx_r25.numberOfUsersImported);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(15, 6, "artemisApp.importUsers.numberOfUsersNotImported"));
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate(ctx_r25.numberOfUsersNotImported);
  }
}
function UsersImportDialogComponent_Conditional_53_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275elementStart(1, "div", 37);
    i0.\u0275\u0275text(2, "\n                ");
    i0.\u0275\u0275template(3, UsersImportDialogComponent_Conditional_53_Conditional_3_Template, 11, 4)(4, UsersImportDialogComponent_Conditional_53_Conditional_4_Template, 22, 8);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r6 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(3, !ctx_r6.hasImported ? 3 : 4);
  }
}
function UsersImportDialogComponent_Conditional_54_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275elementStart(3, "strong");
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275pipe(5, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "span");
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                ");
  }
  if (rf & 2) {
    const ctx_r26 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(5, 2, "artemisApp.importUsers.numberOfUsers"));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate1("\xA0", ctx_r26.examUsersToImport.length, "");
  }
}
function UsersImportDialogComponent_Conditional_54_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275elementStart(3, "strong");
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275pipe(5, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "span");
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                    ");
    i0.\u0275\u0275elementStart(11, "div", 38);
    i0.\u0275\u0275text(12, "\n                        ");
    i0.\u0275\u0275elementStart(13, "strong");
    i0.\u0275\u0275text(14);
    i0.\u0275\u0275pipe(15, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(16, "\n                        ");
    i0.\u0275\u0275elementStart(17, "span")(18, "b", 39);
    i0.\u0275\u0275text(19);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(20, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(21, "\n                ");
  }
  if (rf & 2) {
    const ctx_r27 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(5, 4, "artemisApp.importUsers.numberOfUsersImported"));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(ctx_r27.numberOfUsersImported);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(15, 6, "artemisApp.importUsers.numberOfUsersNotImported"));
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate(ctx_r27.numberOfUsersNotImported);
  }
}
function UsersImportDialogComponent_Conditional_54_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275elementStart(1, "div", 37);
    i0.\u0275\u0275text(2, "\n                ");
    i0.\u0275\u0275template(3, UsersImportDialogComponent_Conditional_54_Conditional_3_Template, 11, 4)(4, UsersImportDialogComponent_Conditional_54_Conditional_4_Template, 22, 8);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r7 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(3, !ctx_r7.hasImported ? 3 : 4);
  }
}
function UsersImportDialogComponent_Conditional_57_Template(rf, ctx) {
  if (rf & 1) {
    const _r29 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                ");
    i0.\u0275\u0275elementStart(1, "button", 40);
    i0.\u0275\u0275listener("click", function UsersImportDialogComponent_Conditional_57_Template_button_click_1_listener() {
      i0.\u0275\u0275restoreView(_r29);
      const ctx_r28 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r28.clear());
    });
    i0.\u0275\u0275text(2, "\n                    ");
    i0.\u0275\u0275element(3, "fa-icon", 41);
    i0.\u0275\u0275text(4, "\xA0");
    i0.\u0275\u0275elementStart(5, "span", 42);
    i0.\u0275\u0275text(6, "Cancel");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                ");
    i0.\u0275\u0275elementStart(9, "button", 43);
    i0.\u0275\u0275listener("click", function UsersImportDialogComponent_Conditional_57_Template_button_click_9_listener() {
      i0.\u0275\u0275restoreView(_r29);
      const ctx_r30 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r30.importUsers());
    });
    i0.\u0275\u0275text(10, "\n                    ");
    i0.\u0275\u0275element(11, "fa-icon", 44);
    i0.\u0275\u0275text(12, "\n                    ");
    i0.\u0275\u0275elementStart(13, "span", 45);
    i0.\u0275\u0275text(14, "Import");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(15, "\n                    ");
    i0.\u0275\u0275element(16, "fa-icon", 46);
    i0.\u0275\u0275text(17, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(18, "\n            ");
  }
  if (rf & 2) {
    const ctx_r8 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("icon", ctx_r8.faBan);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275property("disabled", ctx_r8.isSubmitDisabled);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r8.faUpload);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275property("hidden", !ctx_r8.isImporting)("spin", true)("icon", ctx_r8.faCircleNotch);
  }
}
function UsersImportDialogComponent_Conditional_58_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                ");
    i0.\u0275\u0275elementStart(1, "button", 47);
    i0.\u0275\u0275listener("click", function UsersImportDialogComponent_Conditional_58_Template_button_click_1_listener() {
      i0.\u0275\u0275restoreView(_r32);
      const ctx_r31 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r31.onFinish());
    });
    i0.\u0275\u0275text(2, "\n                    ");
    i0.\u0275\u0275element(3, "fa-icon", 44);
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275elementStart(5, "span", 48);
    i0.\u0275\u0275text(6, "Finish");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n            ");
  }
  if (rf & 2) {
    const ctx_r9 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("icon", ctx_r9.faCheck);
  }
}
var _c0, POSSIBLE_REGISTRATION_NUMBER_HEADERS, POSSIBLE_LOGIN_HEADERS, POSSIBLE_EMAIL_HEADERS, POSSIBLE_FIRST_NAME_HEADERS, POSSIBLE_LAST_NAME_HEADERS, POSSIBLE_ROOM_HEADERS, POSSIBLE_SEAT_HEADERS, UsersImportDialogComponent;
var init_users_import_dialog_component = __esm({
  "src/main/webapp/app/shared/user-import/users-import-dialog.component.ts"() {
    init_alert_service();
    init_delete_dialog_model();
    init_course_management_service();
    init_exam_management_service();
    init_tutorial_groups_service();
    init_alert_service();
    init_exam_management_service();
    init_course_management_service();
    init_tutorial_groups_service();
    init_help_icon_component();
    init_translate_directive();
    init_artemis_translate_pipe();
    _c0 = ["importForm"];
    POSSIBLE_REGISTRATION_NUMBER_HEADERS = ["registrationnumber", "matriculationnumber", "matrikelnummer", "number"];
    POSSIBLE_LOGIN_HEADERS = ["login", "user", "username", "benutzer", "benutzername"];
    POSSIBLE_EMAIL_HEADERS = ["email", "e-mail", "mail"];
    POSSIBLE_FIRST_NAME_HEADERS = ["firstname", "firstnameofstudent", "givenname", "forename", "vorname"];
    POSSIBLE_LAST_NAME_HEADERS = ["familyname", "lastname", "familynameofstudent", "surname", "nachname", "familienname", "name"];
    POSSIBLE_ROOM_HEADERS = ["actualroom", "actualRoom", "raum", "room", "Room"];
    POSSIBLE_SEAT_HEADERS = ["actualseat", "actualSeat", "sitzplatz", "sitz", "seat", "Seat"];
    UsersImportDialogComponent = class _UsersImportDialogComponent {
      activeModal;
      alertService;
      examManagementService;
      courseManagementService;
      tutorialGroupService;
      ActionType = ActionType;
      importForm;
      courseId;
      courseGroup;
      exam;
      tutorialGroup;
      examUserMode;
      usersToImport = [];
      examUsersToImport = [];
      notFoundUsers = [];
      isParsing = false;
      validationError;
      noUsersFoundError;
      isImporting = false;
      hasImported = false;
      dialogErrorSource = new Subject();
      dialogError$ = this.dialogErrorSource.asObservable();
      faBan = faBan;
      faSpinner = faSpinner;
      faCheck = faCheck;
      faCircleNotch = faCircleNotch;
      faUpload = faUpload;
      faArrowRight = faArrowRight;
      constructor(activeModal, alertService, examManagementService, courseManagementService, tutorialGroupService) {
        this.activeModal = activeModal;
        this.alertService = alertService;
        this.examManagementService = examManagementService;
        this.courseManagementService = courseManagementService;
        this.tutorialGroupService = tutorialGroupService;
      }
      ngOnDestroy() {
        this.dialogErrorSource.unsubscribe();
      }
      resetDialog() {
        this.usersToImport = [];
        this.examUsersToImport = [];
        this.notFoundUsers = [];
        this.hasImported = false;
      }
      onCSVFileSelect(event) {
        return __async(this, null, function* () {
          if (event.target.files.length > 0) {
            this.resetDialog();
            if (this.examUserMode) {
              this.examUsersToImport = yield this.readUsersFromCSVFile(event, event.target.files[0]);
            } else {
              this.usersToImport = yield this.readUsersFromCSVFile(event, event.target.files[0]);
            }
          }
        });
      }
      readUsersFromCSVFile(event, csvFile) {
        return __async(this, null, function* () {
          let csvUsers = [];
          try {
            this.isParsing = true;
            this.validationError = void 0;
            csvUsers = yield this.parseCSVFile(csvFile);
          } catch (error) {
            this.validationError = error.message;
          } finally {
            this.isParsing = false;
          }
          if (csvUsers.length > 0) {
            this.performExtraValidations(csvFile, csvUsers);
          } else if (csvUsers.length === 0) {
            this.noUsersFoundError = true;
          }
          if (this.validationError || csvUsers.length === 0) {
            event.target.value = "";
            return [];
          }
          const usedHeaders = Object.keys(csvUsers.first() || []);
          const registrationNumberHeader = usedHeaders.find((value) => POSSIBLE_REGISTRATION_NUMBER_HEADERS.includes(value)) || "";
          const loginHeader = usedHeaders.find((value) => POSSIBLE_LOGIN_HEADERS.includes(value)) || "";
          const emailHeader = usedHeaders.find((value) => POSSIBLE_EMAIL_HEADERS.includes(value)) || "";
          const firstNameHeader = usedHeaders.find((value) => POSSIBLE_FIRST_NAME_HEADERS.includes(value)) || "";
          const lastNameHeader = usedHeaders.find((value) => POSSIBLE_LAST_NAME_HEADERS.includes(value)) || "";
          const roomHeader = usedHeaders.find((value) => POSSIBLE_ROOM_HEADERS.includes(value)) || "";
          const seatHeader = usedHeaders.find((value) => POSSIBLE_SEAT_HEADERS.includes(value)) || "";
          if (this.examUserMode) {
            return csvUsers.map((users) => ({
              registrationNumber: users[registrationNumberHeader]?.trim() || "",
              login: users[loginHeader]?.trim() || "",
              email: users[emailHeader]?.trim() || "",
              firstName: users[firstNameHeader]?.trim() || "",
              lastName: users[lastNameHeader]?.trim() || "",
              room: users[roomHeader]?.trim() || "",
              seat: users[seatHeader]?.trim() || ""
            }));
          } else {
            return csvUsers.map((users) => ({
              registrationNumber: users[registrationNumberHeader]?.trim() || "",
              login: users[loginHeader]?.trim() || "",
              email: users[emailHeader]?.trim() || "",
              firstName: users[firstNameHeader]?.trim() || "",
              lastName: users[lastNameHeader]?.trim() || ""
            }));
          }
        });
      }
      performExtraValidations(csvFile, csvUsers) {
        const invalidUserEntries = this.computeInvalidUserEntries(csvUsers);
        if (invalidUserEntries) {
          const maxLength = 30;
          this.validationError = invalidUserEntries.length <= maxLength ? invalidUserEntries : invalidUserEntries.slice(0, maxLength) + "...";
        }
      }
      checkIfEntryContainsKey(entry, keys) {
        return keys.some((key) => entry[key] !== void 0 && entry[key] !== "");
      }
      computeInvalidUserEntries(csvUsers) {
        const invalidList = [];
        for (const [i, user] of csvUsers.entries()) {
          const hasLogin = this.checkIfEntryContainsKey(user, POSSIBLE_LOGIN_HEADERS);
          const hasRegistrationNumber = this.checkIfEntryContainsKey(user, POSSIBLE_REGISTRATION_NUMBER_HEADERS);
          const hasEmail = this.checkIfEntryContainsKey(user, POSSIBLE_EMAIL_HEADERS);
          if (!hasLogin && !hasRegistrationNumber && !hasEmail) {
            invalidList.push(i + 2);
          }
        }
        return invalidList.length === 0 ? void 0 : invalidList.join(", ");
      }
      parseCSVFile(csvFile) {
        return new Promise((resolve, reject) => {
          parse(csvFile, {
            header: true,
            transformHeader: (header) => header.toLowerCase().replaceAll(" ", "").replaceAll("_", "").replaceAll("-", ""),
            skipEmptyLines: true,
            complete: (results) => resolve(results.data),
            error: (error) => reject(error)
          });
        });
      }
      importUsers() {
        this.isImporting = true;
        if (this.tutorialGroup) {
          this.tutorialGroupService.registerMultipleStudents(this.courseId, this.tutorialGroup.id, this.usersToImport).subscribe({
            next: (res) => this.onSaveSuccess(res),
            error: () => this.onSaveError()
          });
        } else if (this.courseGroup && !this.exam) {
          this.courseManagementService.addUsersToGroupInCourse(this.courseId, this.usersToImport, this.courseGroup).subscribe({
            next: (res) => this.onSaveSuccess(res),
            error: () => this.onSaveError()
          });
        } else if (!this.courseGroup && this.exam) {
          this.examManagementService.addStudentsToExam(this.courseId, this.exam.id, this.examUsersToImport).subscribe({
            next: (res) => this.onSaveSuccess(res),
            error: () => this.onSaveError()
          });
        } else {
          this.alertService.error("artemisApp.importUsers.genericErrorMessage");
        }
      }
      wasImported(user) {
        return this.hasImported && !this.wasNotImported(user);
      }
      wasNotImported(user) {
        if (this.hasImported && this.notFoundUsers?.length === 0) {
          return false;
        }
        for (const notFound of this.notFoundUsers) {
          if (notFound.registrationNumber?.length > 0 && notFound.registrationNumber === user.registrationNumber || notFound.login?.length > 0 && notFound.login === user.login || notFound.email?.length > 0 && notFound.email === user.email) {
            return true;
          }
        }
        return false;
      }
      get numberOfUsersImported() {
        return !this.hasImported ? 0 : this.examUserMode ? this.examUsersToImport.length - this.numberOfUsersNotImported : this.usersToImport.length - this.numberOfUsersNotImported;
      }
      get numberOfUsersNotImported() {
        return !this.hasImported ? 0 : this.notFoundUsers.length;
      }
      get isSubmitDisabled() {
        return this.examUserMode ? this.isImporting || !this.examUsersToImport?.length : this.isImporting || !this.usersToImport?.length;
      }
      onSaveSuccess(notFoundUsers) {
        this.isImporting = false;
        this.hasImported = true;
        this.notFoundUsers = notFoundUsers.body || [];
      }
      onSaveError() {
        this.alertService.error("artemisApp.importUsers.genericErrorMessage");
        this.isImporting = false;
      }
      clear() {
        this.activeModal.dismiss("cancel");
      }
      onFinish() {
        this.activeModal.close();
      }
      static \u0275fac = function UsersImportDialogComponent_Factory(t) {
        return new (t || _UsersImportDialogComponent)(i0.\u0275\u0275directiveInject(i1.NgbActiveModal), i0.\u0275\u0275directiveInject(AlertService), i0.\u0275\u0275directiveInject(ExamManagementService), i0.\u0275\u0275directiveInject(CourseManagementService), i0.\u0275\u0275directiveInject(TutorialGroupsService));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _UsersImportDialogComponent, selectors: [["jhi-users-import-dialog"]], viewQuery: function UsersImportDialogComponent_Query(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275viewQuery(_c0, 5);
        }
        if (rf & 2) {
          let _t;
          i0.\u0275\u0275queryRefresh(_t = i0.\u0275\u0275loadQuery()) && (ctx.importForm = _t.first);
        }
      }, inputs: { courseId: "courseId", courseGroup: "courseGroup", exam: "exam", tutorialGroup: "tutorialGroup", examUserMode: "examUserMode" }, decls: 62, vars: 10, consts: [["id", "userImportDialogForm", "name", "importForm", "role", "form", "novalidate", ""], [1, "modal-header"], [1, "modal-title"], [3, "jhiTranslate"], ["type", "button", "data-dismiss", "modal", "aria-hidden", "true", 1, "btn-close", 3, "click"], [1, "modal-body"], [1, "form-group"], ["jhiTranslate", "artemisApp.importUsers.introText", 1, "intro-text"], ["jhiTranslate", "artemisApp.importUsers.dialogText", 1, "intro-text"], ["jhiTranslate", "artemisApp.importUsers.csvExampleText", 1, "intro-text"], [1, "d-flex", "align-items-end"], ["for", "importCSV", "jhiTranslate", "artemisApp.importUsers.csvFile.label", 1, "label-narrow", "font-weight-bold"], ["text", "artemisApp.importUsers.csvFile.tooltip", 1, "me-1"], [1, "mt-2"], ["id", "importCSV", "type", "file", "accept", ".csv", 3, "change"], [1, "modal-footer", "justify-content-between"], [1, "flex-grow-1", "d-flex", "justify-content-end"], [1, "d-flex", "justify-content-center", "align-items-center"], [1, "table", "table-bordered", "w-auto"], [1, "mx-2", 3, "icon"], [1, "loading-spinner", "ms-1", 3, "icon", "spin"], [1, "mt-4", "mb-2", "text-danger"], [1, "mt-1"], [3, "innerHTML"], [1, "form-group", "mt-4"], ["jhiTranslate", "artemisApp.importUsers.usersForImport.label", 1, "label-narrow", "font-weight-bold"], ["text", "artemisApp.importUsers.usersForImport.tooltip", 1, "me-1"], [1, "table", "table-striped", "table-sm", "header-fixed", "mt-2"], ["scope", "col"], ["scope", "col", 2, "width", "300px", 3, "jhiTranslate"], ["scope", "col", 3, "jhiTranslate"], [1, "table-body--students"], ["scope", "row"], [2, "width", "300px"], [1, "form-group", "mt-4", "table-responsive"], ["scope", "col", 2, "width", "350px", 3, "jhiTranslate"], [2, "width", "350px"], [1, "flex-shrink-0", "me-2", "d-flex"], [1, "ms-2"], [2, "color", "red"], ["type", "button", "data-dismiss", "modal", 1, "btn", "btn-default", "cancel", "me-2", 3, "click"], [3, "icon"], ["jhiTranslate", "entity.action.cancel"], ["type", "submit", "id", "import", "name", "importButton", 1, "btn", "btn-primary", 3, "disabled", "click"], [1, "me-2", 3, "icon"], ["jhiTranslate", "entity.action.to-import"], [1, "ms-1", 3, "hidden", "spin", "icon"], ["id", "finish-button", 1, "btn", "btn-success", 3, "click"], ["jhiTranslate", "entity.action.finish"]], template: function UsersImportDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "form", 0);
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275elementStart(2, "div", 1);
          i0.\u0275\u0275text(3, "\n        ");
          i0.\u0275\u0275elementStart(4, "h4", 2);
          i0.\u0275\u0275text(5, "\n            ");
          i0.\u0275\u0275elementStart(6, "span", 3);
          i0.\u0275\u0275text(7, " Import users into: ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(8, "\n        ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(9, "\n        ");
          i0.\u0275\u0275elementStart(10, "button", 4);
          i0.\u0275\u0275listener("click", function UsersImportDialogComponent_Template_button_click_10_listener() {
            return ctx.clear();
          });
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(11, "\n    ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(12, "\n    ");
          i0.\u0275\u0275elementStart(13, "div", 5);
          i0.\u0275\u0275text(14, "\n        ");
          i0.\u0275\u0275elementStart(15, "div", 6);
          i0.\u0275\u0275text(16, "\n            ");
          i0.\u0275\u0275elementStart(17, "p", 7);
          i0.\u0275\u0275text(18, "This dialog can be used to import users.");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(19, "\n            ");
          i0.\u0275\u0275element(20, "p", 8);
          i0.\u0275\u0275text(21, "\n            ");
          i0.\u0275\u0275element(22, "p", 9);
          i0.\u0275\u0275text(23, "\n        ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(24, "\n        ");
          i0.\u0275\u0275template(25, UsersImportDialogComponent_Conditional_25_Template, 60, 3)(26, UsersImportDialogComponent_Conditional_26_Template, 54, 5);
          i0.\u0275\u0275elementStart(27, "div", 6);
          i0.\u0275\u0275text(28, "\n            ");
          i0.\u0275\u0275elementStart(29, "div", 10);
          i0.\u0275\u0275text(30, "\n                ");
          i0.\u0275\u0275elementStart(31, "div");
          i0.\u0275\u0275text(32, "\n                    ");
          i0.\u0275\u0275elementStart(33, "label", 11);
          i0.\u0275\u0275text(34, "Select .csv file");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(35, "\n                    ");
          i0.\u0275\u0275element(36, "jhi-help-icon", 12);
          i0.\u0275\u0275text(37, "\n                ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(38, "\n                ");
          i0.\u0275\u0275template(39, UsersImportDialogComponent_Conditional_39_Template, 3, 2);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(40, "\n            ");
          i0.\u0275\u0275elementStart(41, "div", 13);
          i0.\u0275\u0275text(42, "\n                ");
          i0.\u0275\u0275elementStart(43, "input", 14);
          i0.\u0275\u0275listener("change", function UsersImportDialogComponent_Template_input_change_43_listener($event) {
            return ctx.onCSVFileSelect($event);
          });
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(44, "\n                ");
          i0.\u0275\u0275template(45, UsersImportDialogComponent_Conditional_45_Template, 11, 3);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(46, "\n        ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(47, "\n        ");
          i0.\u0275\u0275template(48, UsersImportDialogComponent_Conditional_48_Template, 44, 4)(49, UsersImportDialogComponent_Conditional_49_Template, 50, 6);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(50, "\n    ");
          i0.\u0275\u0275elementStart(51, "div", 15);
          i0.\u0275\u0275text(52, "\n        ");
          i0.\u0275\u0275template(53, UsersImportDialogComponent_Conditional_53_Template, 6, 1)(54, UsersImportDialogComponent_Conditional_54_Template, 6, 1);
          i0.\u0275\u0275elementStart(55, "div", 16);
          i0.\u0275\u0275text(56, "\n            ");
          i0.\u0275\u0275template(57, UsersImportDialogComponent_Conditional_57_Template, 19, 6)(58, UsersImportDialogComponent_Conditional_58_Template, 9, 1);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(59, "\n    ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(60, "\n");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(61, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275advance(6);
          i0.\u0275\u0275property("jhiTranslate", "artemisApp.importUsers.dialogTitle");
          i0.\u0275\u0275advance(19);
          i0.\u0275\u0275conditional(25, !ctx.examUserMode ? 25 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275conditional(26, ctx.examUserMode ? 26 : -1);
          i0.\u0275\u0275advance(13);
          i0.\u0275\u0275conditional(39, ctx.isParsing ? 39 : -1);
          i0.\u0275\u0275advance(6);
          i0.\u0275\u0275conditional(45, ctx.validationError || ctx.noUsersFoundError ? 45 : -1);
          i0.\u0275\u0275advance(3);
          i0.\u0275\u0275conditional(48, ctx.usersToImport && ctx.usersToImport.length > 0 && !ctx.examUserMode ? 48 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275conditional(49, ctx.examUsersToImport && ctx.examUsersToImport.length > 0 && ctx.examUserMode ? 49 : -1);
          i0.\u0275\u0275advance(4);
          i0.\u0275\u0275conditional(53, ctx.usersToImport && ctx.usersToImport.length > 0 ? 53 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275conditional(54, ctx.examUsersToImport && ctx.examUsersToImport.length > 0 ? 54 : -1);
          i0.\u0275\u0275advance(3);
          i0.\u0275\u0275conditional(57, !ctx.hasImported ? 57 : 58);
        }
      }, dependencies: [HelpIconComponent, i7.\u0275NgNoValidate, i7.NgControlStatusGroup, i7.NgForm, i8.FaIconComponent, TranslateDirective, ArtemisTranslatePipe], styles: ['/* src/main/webapp/app/shared/user-import/users-import-dialog.component.scss */\n:host {\n  display: block;\n}\n.loading-spinner {\n  position: relative;\n  top: -2px;\n}\n.label-narrow {\n  display: inline-block;\n  margin-bottom: 0.1rem;\n}\n.import-success,\n.import-fail {\n  position: relative;\n}\n.import-success:nth-child(odd):before,\n.import-fail:nth-child(odd):before {\n  content: "";\n  pointer-events: none;\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: rgba(0, 0, 0, 0.03);\n}\ntable.table.table-striped .import-success td,\ntable.table.table-striped .import-success th {\n  color: #155724;\n  background-color: #d4edda;\n}\ntable.table.table-striped .import-fail td,\ntable.table.table-striped .import-fail th {\n  color: #dc3545;\n  background-color: #f8d7da;\n}\n.header-fixed {\n  width: 100%;\n}\n.header-fixed thead,\n.header-fixed tbody,\n.header-fixed thead > tr,\n.header-fixed tbody > tr,\n.header-fixed thead > tr > th,\n.header-fixed tbody > tr > td,\n.header-fixed th {\n  display: block;\n}\n.header-fixed tbody > tr:after,\n.header-fixed thead > tr:after {\n  content: " ";\n  display: block;\n  visibility: hidden;\n  clear: both;\n}\n.header-fixed thead {\n  overflow-y: scroll;\n}\n.header-fixed tbody {\n  overflow-y: scroll;\n  min-height: 150px;\n  max-height: max(300px, 100vh - 500px);\n}\n.header-fixed tbody > tr > td,\n.header-fixed tbody > tr > td,\n.header-fixed th {\n  width: 25%;\n  float: left;\n}\n.header-fixed tr {\n  display: flex !important;\n}\n.header-fixed td,\n.header-fixed th {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.modal-footer button[disabled] {\n  cursor: not-allowed;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvdXNlci1pbXBvcnQvdXNlcnMtaW1wb3J0LWRpYWxvZy5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiJHN1Y2Nlc3MtdGV4dC1jb2xvcjogIzE1NTcyNDtcbiRzdWNjZXNzLWJnLWNvbG9yOiAjZDRlZGRhO1xuXG4kZXJyb3ItdGV4dC1jb2xvcjogI2RjMzU0NTtcbiRlcnJvci1iZy1jb2xvcjogI2Y4ZDdkYTtcblxuOmhvc3Qge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xufVxuXG4ubG9hZGluZy1zcGlubmVyIHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgdG9wOiAtMnB4O1xufVxuXG4ubGFiZWwtbmFycm93IHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgbWFyZ2luLWJvdHRvbTogMC4xcmVtO1xufVxuXG4uaW1wb3J0LXN1Y2Nlc3MsXG4uaW1wb3J0LWZhaWwge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICY6bnRoLWNoaWxkKG9kZCk6YmVmb3JlIHtcbiAgICAgICAgY29udGVudDogJyc7XG4gICAgICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHRvcDogMDtcbiAgICAgICAgbGVmdDogMDtcbiAgICAgICAgcmlnaHQ6IDA7XG4gICAgICAgIGJvdHRvbTogMDtcbiAgICAgICAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjAzKTtcbiAgICB9XG59XG5cbnRhYmxlLnRhYmxlLnRhYmxlLXN0cmlwZWQgLmltcG9ydC1zdWNjZXNzIHtcbiAgICB0ZCxcbiAgICB0aCB7XG4gICAgICAgIGNvbG9yOiAkc3VjY2Vzcy10ZXh0LWNvbG9yO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkc3VjY2Vzcy1iZy1jb2xvcjtcbiAgICB9XG59XG5cbnRhYmxlLnRhYmxlLnRhYmxlLXN0cmlwZWQgLmltcG9ydC1mYWlsIHtcbiAgICB0ZCxcbiAgICB0aCB7XG4gICAgICAgIGNvbG9yOiAkZXJyb3ItdGV4dC1jb2xvcjtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGVycm9yLWJnLWNvbG9yO1xuICAgIH1cbn1cblxuLmhlYWRlci1maXhlZCB7XG4gICAgd2lkdGg6IDEwMCU7XG5cbiAgICB0aGVhZCxcbiAgICB0Ym9keSxcbiAgICB0aGVhZCA+IHRyLFxuICAgIHRib2R5ID4gdHIsXG4gICAgdGhlYWQgPiB0ciA+IHRoLFxuICAgIHRib2R5ID4gdHIgPiB0ZCxcbiAgICB0aCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgIHRib2R5ID4gdHI6YWZ0ZXIsXG4gICAgdGhlYWQgPiB0cjphZnRlciB7XG4gICAgICAgIGNvbnRlbnQ6ICcgJztcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcbiAgICAgICAgY2xlYXI6IGJvdGg7XG4gICAgfVxuXG4gICAgdGhlYWQge1xuICAgICAgICBvdmVyZmxvdy15OiBzY3JvbGw7XG4gICAgfVxuXG4gICAgdGJvZHkge1xuICAgICAgICBvdmVyZmxvdy15OiBzY3JvbGw7XG4gICAgICAgIG1pbi1oZWlnaHQ6IDE1MHB4O1xuICAgICAgICBtYXgtaGVpZ2h0OiBtYXgoMzAwcHgsIDEwMHZoIC0gNTAwcHgpO1xuICAgIH1cblxuICAgIHRib2R5ID4gdHIgPiB0ZCxcbiAgICB0Ym9keSA+IHRyID4gdGQsXG4gICAgdGgge1xuICAgICAgICB3aWR0aDogMjUlOyAvLyBkaXZpZGUgYnkgdGhlIG51bWJlciBvZiB0YWJsZSBjb2x1bW5zOiBjYWxjKDEwMCUgLyA0KVxuICAgICAgICBmbG9hdDogbGVmdDtcbiAgICB9XG5cbiAgICB0ciB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICB0ZCxcbiAgICB0aCB7XG4gICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICAgIH1cbn1cblxuLm1vZGFsLWZvb3RlciB7XG4gICAgYnV0dG9uW2Rpc2FibGVkXSB7XG4gICAgICAgIGN1cnNvcjogbm90LWFsbG93ZWQ7XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQU1BO0FBQ0ksV0FBQTs7QUFHSixDQUFBO0FBQ0ksWUFBQTtBQUNBLE9BQUE7O0FBR0osQ0FBQTtBQUNJLFdBQUE7QUFDQSxpQkFBQTs7QUFHSixDQUFBO0FBQUEsQ0FBQTtBQUVJLFlBQUE7O0FBRUEsQ0FKSixjQUlJLGVBQUE7QUFBQSxDQUpKLFdBSUksZUFBQTtBQUNJLFdBQUE7QUFDQSxrQkFBQTtBQUNBLFlBQUE7QUFDQSxPQUFBO0FBQ0EsUUFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBO0FBQ0EsY0FBQSxLQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBOztBQUtKLEtBQUEsQ0FBQSxLQUFBLENBQUEsY0FBQSxDQWpCSixlQWlCSTtBQUFBLEtBQUEsQ0FBQSxLQUFBLENBQUEsY0FBQSxDQWpCSixlQWlCSTtBQUVJLFNBdkNhO0FBd0NiLG9CQXZDVzs7QUE0Q2YsS0FBQSxDQVJBLEtBUUEsQ0FSQSxjQVFBLENBekJKLFlBeUJJO0FBQUEsS0FBQSxDQVJBLEtBUUEsQ0FSQSxjQVFBLENBekJKLFlBeUJJO0FBRUksU0E1Q1c7QUE2Q1gsb0JBNUNTOztBQWdEakIsQ0FBQTtBQUNJLFNBQUE7O0FBRUEsQ0FISixhQUdJO0FBQUEsQ0FISixhQUdJO0FBQUEsQ0FISixhQUdJLE1BQUEsRUFBQTtBQUFBLENBSEosYUFHSSxNQUFBLEVBQUE7QUFBQSxDQUhKLGFBR0ksTUFBQSxFQUFBLEdBQUEsRUFBQTtBQUFBLENBSEosYUFHSSxNQUFBLEVBQUEsR0FBQSxFQUFBO0FBQUEsQ0FISixhQUdJO0FBT0ksV0FBQTs7QUFHSixDQWJKLGFBYUksTUFBQSxFQUFBLEVBQUE7QUFBQSxDQWJKLGFBYUksTUFBQSxFQUFBLEVBQUE7QUFFSSxXQUFBO0FBQ0EsV0FBQTtBQUNBLGNBQUE7QUFDQSxTQUFBOztBQUdKLENBckJKLGFBcUJJO0FBQ0ksY0FBQTs7QUFHSixDQXpCSixhQXlCSTtBQUNJLGNBQUE7QUFDQSxjQUFBO0FBQ0EsY0FBQSxJQUFBLEtBQUEsRUFBQSxNQUFBLEVBQUE7O0FBR0osQ0EvQkosYUErQkksTUFBQSxFQUFBLEdBQUEsRUFBQTtBQUFBLENBL0JKLGFBK0JJLE1BQUEsRUFBQSxHQUFBLEVBQUE7QUFBQSxDQS9CSixhQStCSTtBQUdJLFNBQUE7QUFDQSxTQUFBOztBQUdKLENBdENKLGFBc0NJO0FBQ0ksV0FBQTs7QUFHSixDQTFDSixhQTBDSTtBQUFBLENBMUNKLGFBMENJO0FBRUksZUFBQTtBQUNBLFlBQUE7QUFDQSxpQkFBQTs7QUFLSixDQUFBLGFBQUEsTUFBQSxDQUFBO0FBQ0ksVUFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */\n'], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(UsersImportDialogComponent, { className: "UsersImportDialogComponent" });
    })();
  }
});

// src/main/webapp/app/shared/user-import/users-import-button.component.ts
import { Component as Component2, EventEmitter, Input as Input2, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgbModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { faPlus } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
var UsersImportButtonComponent;
var init_users_import_button_component = __esm({
  "src/main/webapp/app/shared/user-import/users-import-button.component.ts"() {
    init_button_component();
    init_users_import_dialog_component();
    init_exam_model();
    init_button_component();
    UsersImportButtonComponent = class _UsersImportButtonComponent {
      modalService;
      ButtonType = ButtonType;
      ButtonSize = ButtonSize;
      tutorialGroup = void 0;
      examUserMode;
      courseGroup;
      courseId;
      buttonSize = ButtonSize.MEDIUM;
      exam;
      finish = new EventEmitter();
      faPlus = faPlus;
      constructor(modalService) {
        this.modalService = modalService;
      }
      openUsersImportDialog(event) {
        event.stopPropagation();
        const modalRef = this.modalService.open(UsersImportDialogComponent, { keyboard: true, size: "lg", backdrop: "static" });
        modalRef.componentInstance.courseId = this.courseId;
        modalRef.componentInstance.courseGroup = this.courseGroup;
        modalRef.componentInstance.exam = this.exam;
        modalRef.componentInstance.tutorialGroup = this.tutorialGroup;
        modalRef.componentInstance.examUserMode = this.examUserMode;
        modalRef.result.then(() => this.finish.emit(), () => {
        });
      }
      static \u0275fac = function UsersImportButtonComponent_Factory(t) {
        return new (t || _UsersImportButtonComponent)(i02.\u0275\u0275directiveInject(i12.NgbModal));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _UsersImportButtonComponent, selectors: [["jhi-user-import-button"]], inputs: { tutorialGroup: "tutorialGroup", examUserMode: "examUserMode", courseGroup: "courseGroup", courseId: "courseId", buttonSize: "buttonSize", exam: "exam" }, outputs: { finish: "finish" }, decls: 3, vars: 4, consts: [[3, "btnType", "btnSize", "icon", "title", "onClick"]], template: function UsersImportButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275text(0, "\n        ");
          i02.\u0275\u0275elementStart(1, "jhi-button", 0);
          i02.\u0275\u0275listener("onClick", function UsersImportButtonComponent_Template_jhi_button_onClick_1_listener($event) {
            return ctx.openUsersImportDialog($event);
          });
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(2, "\n    ");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275property("btnType", ctx.ButtonType.PRIMARY)("btnSize", ctx.buttonSize)("icon", ctx.faPlus)("title", "artemisApp.importUsers.buttonLabel");
        }
      }, dependencies: [ButtonComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(UsersImportButtonComponent, { className: "UsersImportButtonComponent" });
    })();
  }
});

// src/main/webapp/app/shared/user-import/user-import.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var UserImportModule;
var init_user_import_module = __esm({
  "src/main/webapp/app/shared/user-import/user-import.module.ts"() {
    init_users_import_dialog_component();
    init_users_import_button_component();
    init_shared_component_module();
    init_shared_common_module();
    UserImportModule = class _UserImportModule {
      static \u0275fac = function UserImportModule_Factory(t) {
        return new (t || _UserImportModule)();
      };
      static \u0275mod = i03.\u0275\u0275defineNgModule({ type: _UserImportModule });
      static \u0275inj = i03.\u0275\u0275defineInjector({ imports: [ArtemisSharedComponentModule, ArtemisSharedCommonModule] });
    };
  }
});

export {
  UsersImportButtonComponent,
  init_users_import_button_component,
  UserImportModule,
  init_user_import_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3VzZXItaW1wb3J0L3VzZXJzLWltcG9ydC1kaWFsb2cuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvdXNlci1pbXBvcnQvdXNlcnMtaW1wb3J0LWRpYWxvZy5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3VzZXItaW1wb3J0L3VzZXJzLWltcG9ydC1idXR0b24uY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvdXNlci1pbXBvcnQvdXNlci1pbXBvcnQubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uRGVzdHJveSwgVmlld0NoaWxkLCBWaWV3RW5jYXBzdWxhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmdGb3JtIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgTmdiQWN0aXZlTW9kYWwgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgeyBBbGVydFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuaW1wb3J0IHsgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgRXhhbVVzZXJEVE8gfSBmcm9tICdhcHAvZW50aXRpZXMvZXhhbS11c2VyLWR0by5tb2RlbCc7XG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBBY3Rpb25UeXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9kZWxldGUtZGlhbG9nL2RlbGV0ZS1kaWFsb2cubW9kZWwnO1xuaW1wb3J0IHsgQ291cnNlTWFuYWdlbWVudFNlcnZpY2UgfSBmcm9tICdhcHAvY291cnNlL21hbmFnZS9jb3Vyc2UtbWFuYWdlbWVudC5zZXJ2aWNlJztcbmltcG9ydCB7IEV4YW0gfSBmcm9tICdhcHAvZW50aXRpZXMvZXhhbS5tb2RlbCc7XG5pbXBvcnQgeyBFeGFtTWFuYWdlbWVudFNlcnZpY2UgfSBmcm9tICdhcHAvZXhhbS9tYW5hZ2UvZXhhbS1tYW5hZ2VtZW50LnNlcnZpY2UnO1xuaW1wb3J0IHsgU3R1ZGVudERUTyB9IGZyb20gJ2FwcC9lbnRpdGllcy9zdHVkZW50LWR0by5tb2RlbCc7XG5pbXBvcnQgeyBwYXJzZSB9IGZyb20gJ3BhcGFwYXJzZSc7XG5pbXBvcnQgeyBmYUFycm93UmlnaHQsIGZhQmFuLCBmYUNoZWNrLCBmYUNpcmNsZU5vdGNoLCBmYVNwaW5uZXIsIGZhVXBsb2FkIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IFR1dG9yaWFsR3JvdXAgfSBmcm9tICdhcHAvZW50aXRpZXMvdHV0b3JpYWwtZ3JvdXAvdHV0b3JpYWwtZ3JvdXAubW9kZWwnO1xuaW1wb3J0IHsgVHV0b3JpYWxHcm91cHNTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvdXJzZS90dXRvcmlhbC1ncm91cHMvc2VydmljZXMvdHV0b3JpYWwtZ3JvdXBzLnNlcnZpY2UnO1xuXG5jb25zdCBQT1NTSUJMRV9SRUdJU1RSQVRJT05fTlVNQkVSX0hFQURFUlMgPSBbJ3JlZ2lzdHJhdGlvbm51bWJlcicsICdtYXRyaWN1bGF0aW9ubnVtYmVyJywgJ21hdHJpa2VsbnVtbWVyJywgJ251bWJlciddO1xuY29uc3QgUE9TU0lCTEVfTE9HSU5fSEVBREVSUyA9IFsnbG9naW4nLCAndXNlcicsICd1c2VybmFtZScsICdiZW51dHplcicsICdiZW51dHplcm5hbWUnXTtcbmNvbnN0IFBPU1NJQkxFX0VNQUlMX0hFQURFUlMgPSBbJ2VtYWlsJywgJ2UtbWFpbCcsICdtYWlsJ107XG5jb25zdCBQT1NTSUJMRV9GSVJTVF9OQU1FX0hFQURFUlMgPSBbJ2ZpcnN0bmFtZScsICdmaXJzdG5hbWVvZnN0dWRlbnQnLCAnZ2l2ZW5uYW1lJywgJ2ZvcmVuYW1lJywgJ3Zvcm5hbWUnXTtcbmNvbnN0IFBPU1NJQkxFX0xBU1RfTkFNRV9IRUFERVJTID0gWydmYW1pbHluYW1lJywgJ2xhc3RuYW1lJywgJ2ZhbWlseW5hbWVvZnN0dWRlbnQnLCAnc3VybmFtZScsICduYWNobmFtZScsICdmYW1pbGllbm5hbWUnLCAnbmFtZSddO1xuY29uc3QgUE9TU0lCTEVfUk9PTV9IRUFERVJTID0gWydhY3R1YWxyb29tJywgJ2FjdHVhbFJvb20nLCAncmF1bScsICdyb29tJywgJ1Jvb20nXTtcbmNvbnN0IFBPU1NJQkxFX1NFQVRfSEVBREVSUyA9IFsnYWN0dWFsc2VhdCcsICdhY3R1YWxTZWF0JywgJ3NpdHpwbGF0eicsICdzaXR6JywgJ3NlYXQnLCAnU2VhdCddO1xuXG50eXBlIENzdlVzZXIgPSBvYmplY3Q7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXVzZXJzLWltcG9ydC1kaWFsb2cnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi91c2Vycy1pbXBvcnQtZGlhbG9nLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi91c2Vycy1pbXBvcnQtZGlhbG9nLmNvbXBvbmVudC5zY3NzJ10sXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcbn0pXG5leHBvcnQgY2xhc3MgVXNlcnNJbXBvcnREaWFsb2dDb21wb25lbnQgaW1wbGVtZW50cyBPbkRlc3Ryb3kge1xuICAgIHJlYWRvbmx5IEFjdGlvblR5cGUgPSBBY3Rpb25UeXBlO1xuXG4gICAgQFZpZXdDaGlsZCgnaW1wb3J0Rm9ybScsIHsgc3RhdGljOiBmYWxzZSB9KSBpbXBvcnRGb3JtOiBOZ0Zvcm07XG5cbiAgICBASW5wdXQoKSBjb3Vyc2VJZDogbnVtYmVyO1xuICAgIEBJbnB1dCgpIGNvdXJzZUdyb3VwOiBzdHJpbmc7XG4gICAgQElucHV0KCkgZXhhbTogRXhhbSB8IHVuZGVmaW5lZDtcbiAgICBASW5wdXQoKSB0dXRvcmlhbEdyb3VwOiBUdXRvcmlhbEdyb3VwIHwgdW5kZWZpbmVkO1xuICAgIEBJbnB1dCgpIGV4YW1Vc2VyTW9kZTogYm9vbGVhbjtcblxuICAgIHVzZXJzVG9JbXBvcnQ6IFN0dWRlbnREVE9bXSA9IFtdO1xuICAgIGV4YW1Vc2Vyc1RvSW1wb3J0OiBFeGFtVXNlckRUT1tdID0gW107XG4gICAgbm90Rm91bmRVc2VyczogU3R1ZGVudERUT1tdID0gW107XG5cbiAgICBpc1BhcnNpbmcgPSBmYWxzZTtcbiAgICB2YWxpZGF0aW9uRXJyb3I/OiBzdHJpbmc7XG4gICAgbm9Vc2Vyc0ZvdW5kRXJyb3I/OiBib29sZWFuO1xuICAgIGlzSW1wb3J0aW5nID0gZmFsc2U7XG4gICAgaGFzSW1wb3J0ZWQgPSBmYWxzZTtcblxuICAgIHByaXZhdGUgZGlhbG9nRXJyb3JTb3VyY2UgPSBuZXcgU3ViamVjdDxzdHJpbmc+KCk7XG4gICAgZGlhbG9nRXJyb3IkID0gdGhpcy5kaWFsb2dFcnJvclNvdXJjZS5hc09ic2VydmFibGUoKTtcblxuICAgIC8vIEljb25zXG4gICAgZmFCYW4gPSBmYUJhbjtcbiAgICBmYVNwaW5uZXIgPSBmYVNwaW5uZXI7XG4gICAgZmFDaGVjayA9IGZhQ2hlY2s7XG4gICAgZmFDaXJjbGVOb3RjaCA9IGZhQ2lyY2xlTm90Y2g7XG4gICAgZmFVcGxvYWQgPSBmYVVwbG9hZDtcbiAgICBmYUFycm93UmlnaHQgPSBmYUFycm93UmlnaHQ7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBhY3RpdmVNb2RhbDogTmdiQWN0aXZlTW9kYWwsXG4gICAgICAgIHByaXZhdGUgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgZXhhbU1hbmFnZW1lbnRTZXJ2aWNlOiBFeGFtTWFuYWdlbWVudFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgY291cnNlTWFuYWdlbWVudFNlcnZpY2U6IENvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHR1dG9yaWFsR3JvdXBTZXJ2aWNlOiBUdXRvcmlhbEdyb3Vwc1NlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgICAgIHRoaXMuZGlhbG9nRXJyb3JTb3VyY2UudW5zdWJzY3JpYmUoKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHJlc2V0RGlhbG9nKCkge1xuICAgICAgICB0aGlzLnVzZXJzVG9JbXBvcnQgPSBbXTtcbiAgICAgICAgdGhpcy5leGFtVXNlcnNUb0ltcG9ydCA9IFtdO1xuICAgICAgICB0aGlzLm5vdEZvdW5kVXNlcnMgPSBbXTtcbiAgICAgICAgdGhpcy5oYXNJbXBvcnRlZCA9IGZhbHNlO1xuICAgIH1cblxuICAgIGFzeW5jIG9uQ1NWRmlsZVNlbGVjdChldmVudDogYW55KSB7XG4gICAgICAgIGlmIChldmVudC50YXJnZXQuZmlsZXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgdGhpcy5yZXNldERpYWxvZygpO1xuICAgICAgICAgICAgaWYgKHRoaXMuZXhhbVVzZXJNb2RlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5leGFtVXNlcnNUb0ltcG9ydCA9IGF3YWl0IHRoaXMucmVhZFVzZXJzRnJvbUNTVkZpbGUoZXZlbnQsIGV2ZW50LnRhcmdldC5maWxlc1swXSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMudXNlcnNUb0ltcG9ydCA9IGF3YWl0IHRoaXMucmVhZFVzZXJzRnJvbUNTVkZpbGUoZXZlbnQsIGV2ZW50LnRhcmdldC5maWxlc1swXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZWFkcyB1c2VycyBmcm9tIGEgY3N2IGZpbGUgaW50byBhIGxpc3Qgb2YgU3R1ZGVudERUT3Mgb3IgRXhhbVVzZXJEVE8gaWYgZXhhbVVzZXJNb2RlIGlzIHRydWVcbiAgICAgKiBUaGUgY29sdW1uIFwicmVnaXN0cmF0aW9uTnVtYmVyXCIgaXMgbWFuZGF0b3J5IHNpbmNlIHRoZSBpbXBvcnQgcmVxdWlyZXMgaXQgYXMgYW4gaWRlbnRpZmllclxuICAgICAqIEBwYXJhbSBldmVudCBGaWxlIGNoYW5nZSBldmVudCBmcm9tIHRoZSBIVE1MIGlucHV0IG9mIHR5cGUgZmlsZVxuICAgICAqIEBwYXJhbSBjc3ZGaWxlIEZpbGUgdGhhdCBjb250YWlucyBvbmUgdXNlciBwZXIgcm93IGFuZCBoYXMgYXQgbGVhc3QgdGhlIGNvbHVtbnMgc3BlY2lmaWVkIGluIGNzdkNvbHVtbnNcbiAgICAgKi9cbiAgICBwcml2YXRlIGFzeW5jIHJlYWRVc2Vyc0Zyb21DU1ZGaWxlKGV2ZW50OiBhbnksIGNzdkZpbGU6IEZpbGUpOiBQcm9taXNlPFN0dWRlbnREVE9bXSB8IEV4YW1Vc2VyRFRPW10+IHtcbiAgICAgICAgbGV0IGNzdlVzZXJzOiBDc3ZVc2VyW10gPSBbXTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRoaXMuaXNQYXJzaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMudmFsaWRhdGlvbkVycm9yID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgY3N2VXNlcnMgPSBhd2FpdCB0aGlzLnBhcnNlQ1NWRmlsZShjc3ZGaWxlKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRoaXMudmFsaWRhdGlvbkVycm9yID0gZXJyb3IubWVzc2FnZTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHRoaXMuaXNQYXJzaW5nID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNzdlVzZXJzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMucGVyZm9ybUV4dHJhVmFsaWRhdGlvbnMoY3N2RmlsZSwgY3N2VXNlcnMpO1xuICAgICAgICB9IGVsc2UgaWYgKGNzdlVzZXJzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgdGhpcy5ub1VzZXJzRm91bmRFcnJvciA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMudmFsaWRhdGlvbkVycm9yIHx8IGNzdlVzZXJzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgZXZlbnQudGFyZ2V0LnZhbHVlID0gJyc7IC8vIHJlbW92ZSBzZWxlY3RlZCBmaWxlIHNvIHVzZXIgY2FuIGZpeCB0aGUgZmlsZSBhbmQgc2VsZWN0IGl0IGFnYWluXG4gICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB1c2VkSGVhZGVycyA9IE9iamVjdC5rZXlzKGNzdlVzZXJzLmZpcnN0KCkgfHwgW10pO1xuXG4gICAgICAgIGNvbnN0IHJlZ2lzdHJhdGlvbk51bWJlckhlYWRlciA9IHVzZWRIZWFkZXJzLmZpbmQoKHZhbHVlKSA9PiBQT1NTSUJMRV9SRUdJU1RSQVRJT05fTlVNQkVSX0hFQURFUlMuaW5jbHVkZXModmFsdWUpKSB8fCAnJztcbiAgICAgICAgY29uc3QgbG9naW5IZWFkZXIgPSB1c2VkSGVhZGVycy5maW5kKCh2YWx1ZSkgPT4gUE9TU0lCTEVfTE9HSU5fSEVBREVSUy5pbmNsdWRlcyh2YWx1ZSkpIHx8ICcnO1xuICAgICAgICBjb25zdCBlbWFpbEhlYWRlciA9IHVzZWRIZWFkZXJzLmZpbmQoKHZhbHVlKSA9PiBQT1NTSUJMRV9FTUFJTF9IRUFERVJTLmluY2x1ZGVzKHZhbHVlKSkgfHwgJyc7XG4gICAgICAgIGNvbnN0IGZpcnN0TmFtZUhlYWRlciA9IHVzZWRIZWFkZXJzLmZpbmQoKHZhbHVlKSA9PiBQT1NTSUJMRV9GSVJTVF9OQU1FX0hFQURFUlMuaW5jbHVkZXModmFsdWUpKSB8fCAnJztcbiAgICAgICAgY29uc3QgbGFzdE5hbWVIZWFkZXIgPSB1c2VkSGVhZGVycy5maW5kKCh2YWx1ZSkgPT4gUE9TU0lCTEVfTEFTVF9OQU1FX0hFQURFUlMuaW5jbHVkZXModmFsdWUpKSB8fCAnJztcblxuICAgICAgICBjb25zdCByb29tSGVhZGVyID0gdXNlZEhlYWRlcnMuZmluZCgodmFsdWUpID0+IFBPU1NJQkxFX1JPT01fSEVBREVSUy5pbmNsdWRlcyh2YWx1ZSkpIHx8ICcnO1xuICAgICAgICBjb25zdCBzZWF0SGVhZGVyID0gdXNlZEhlYWRlcnMuZmluZCgodmFsdWUpID0+IFBPU1NJQkxFX1NFQVRfSEVBREVSUy5pbmNsdWRlcyh2YWx1ZSkpIHx8ICcnO1xuXG4gICAgICAgIGlmICh0aGlzLmV4YW1Vc2VyTW9kZSkge1xuICAgICAgICAgICAgcmV0dXJuIGNzdlVzZXJzLm1hcChcbiAgICAgICAgICAgICAgICAodXNlcnMpID0+XG4gICAgICAgICAgICAgICAgICAgICh7XG4gICAgICAgICAgICAgICAgICAgICAgICByZWdpc3RyYXRpb25OdW1iZXI6IHVzZXJzW3JlZ2lzdHJhdGlvbk51bWJlckhlYWRlcl0/LnRyaW0oKSB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvZ2luOiB1c2Vyc1tsb2dpbkhlYWRlcl0/LnRyaW0oKSB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtYWlsOiB1c2Vyc1tlbWFpbEhlYWRlcl0/LnRyaW0oKSB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpcnN0TmFtZTogdXNlcnNbZmlyc3ROYW1lSGVhZGVyXT8udHJpbSgpIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgbGFzdE5hbWU6IHVzZXJzW2xhc3ROYW1lSGVhZGVyXT8udHJpbSgpIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgcm9vbTogdXNlcnNbcm9vbUhlYWRlcl0/LnRyaW0oKSB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlYXQ6IHVzZXJzW3NlYXRIZWFkZXJdPy50cmltKCkgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIH0pIGFzIEV4YW1Vc2VyRFRPLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBjc3ZVc2Vycy5tYXAoXG4gICAgICAgICAgICAgICAgKHVzZXJzKSA9PlxuICAgICAgICAgICAgICAgICAgICAoe1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVnaXN0cmF0aW9uTnVtYmVyOiB1c2Vyc1tyZWdpc3RyYXRpb25OdW1iZXJIZWFkZXJdPy50cmltKCkgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2dpbjogdXNlcnNbbG9naW5IZWFkZXJdPy50cmltKCkgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbWFpbDogdXNlcnNbZW1haWxIZWFkZXJdPy50cmltKCkgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgICAgICBmaXJzdE5hbWU6IHVzZXJzW2ZpcnN0TmFtZUhlYWRlcl0/LnRyaW0oKSB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhc3ROYW1lOiB1c2Vyc1tsYXN0TmFtZUhlYWRlcl0/LnRyaW0oKSB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgfSkgYXMgU3R1ZGVudERUTyxcbiAgICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBQZXJmb3JtcyB2YWxpZGF0aW9ucyBvbiB0aGUgcGFyc2VkIHVzZXJzXG4gICAgICogLSBjaGVja3MgaWYgdmFsdWVzIGZvciB0aGUgcmVxdWlyZWQgY29sdW1uIHtjc3ZDb2x1bW5zLnJlZ2lzdHJhdGlvbk51bWJlcn0gYXJlIHByZXNlbnRcbiAgICAgKlxuICAgICAqIEBwYXJhbSBjc3ZGaWxlIEZpbGUgdGhhdCBjb250YWlucyBvbmUgdXNlciBwZXIgcm93IGFuZCBoYXMgYXQgbGVhc3QgdGhlIGNvbHVtbnMgc3BlY2lmaWVkIGluIGNzdkNvbHVtbnNcbiAgICAgKiBAcGFyYW0gY3N2VXNlcnMgUGFyc2VkIGxpc3Qgb2YgdXNlcnNcbiAgICAgKi9cbiAgICBwZXJmb3JtRXh0cmFWYWxpZGF0aW9ucyhjc3ZGaWxlOiBGaWxlLCBjc3ZVc2VyczogQ3N2VXNlcltdKSB7XG4gICAgICAgIGNvbnN0IGludmFsaWRVc2VyRW50cmllcyA9IHRoaXMuY29tcHV0ZUludmFsaWRVc2VyRW50cmllcyhjc3ZVc2Vycyk7XG4gICAgICAgIGlmIChpbnZhbGlkVXNlckVudHJpZXMpIHtcbiAgICAgICAgICAgIGNvbnN0IG1heExlbmd0aCA9IDMwO1xuICAgICAgICAgICAgdGhpcy52YWxpZGF0aW9uRXJyb3IgPSBpbnZhbGlkVXNlckVudHJpZXMubGVuZ3RoIDw9IG1heExlbmd0aCA/IGludmFsaWRVc2VyRW50cmllcyA6IGludmFsaWRVc2VyRW50cmllcy5zbGljZSgwLCBtYXhMZW5ndGgpICsgJy4uLic7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVja3MgaWYgdGhlIGNzdiBlbnRyeSBjb250YWlucyBvbmUgb2YgdGhlIHN1cHBsaWVkIGtleXMuXG4gICAgICogQHBhcmFtIGVudHJ5IHdoaWNoIHNob3VsZCBiZSBjaGVja2VkIGlmIGl0IGNvbnRhaW5zIG9uZSBvZiB0aGUga2V5cy5cbiAgICAgKiBAcGFyYW0ga2V5cyB0aGF0IHNob3VsZCBiZSBjaGVja2VkIGZvciBpbiB0aGUgZW50cnkuXG4gICAgICovXG4gICAgY2hlY2tJZkVudHJ5Q29udGFpbnNLZXkoZW50cnk6IENzdlVzZXIsIGtleXM6IHN0cmluZ1tdKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiBrZXlzLnNvbWUoKGtleSkgPT4gZW50cnlba2V5XSAhPT0gdW5kZWZpbmVkICYmIGVudHJ5W2tleV0gIT09ICcnKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGEgY29tbWEgc2VwYXJhdGVkIGxpc3Qgb2Ygcm93IG51bWJlcnMgdGhhdCBjb250YWlucyBpbnZhbGlkIHN0dWRlbnQgZW50cmllc1xuICAgICAqIEBwYXJhbSBjc3ZVc2VycyBQYXJzZWQgbGlzdCBvZiB1c2Vyc1xuICAgICAqL1xuICAgIGNvbXB1dGVJbnZhbGlkVXNlckVudHJpZXMoY3N2VXNlcnM6IENzdlVzZXJbXSk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIGNvbnN0IGludmFsaWRMaXN0OiBudW1iZXJbXSA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IFtpLCB1c2VyXSBvZiBjc3ZVc2Vycy5lbnRyaWVzKCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGhhc0xvZ2luID0gdGhpcy5jaGVja0lmRW50cnlDb250YWluc0tleSh1c2VyLCBQT1NTSUJMRV9MT0dJTl9IRUFERVJTKTtcbiAgICAgICAgICAgIGNvbnN0IGhhc1JlZ2lzdHJhdGlvbk51bWJlciA9IHRoaXMuY2hlY2tJZkVudHJ5Q29udGFpbnNLZXkodXNlciwgUE9TU0lCTEVfUkVHSVNUUkFUSU9OX05VTUJFUl9IRUFERVJTKTtcbiAgICAgICAgICAgIGNvbnN0IGhhc0VtYWlsID0gdGhpcy5jaGVja0lmRW50cnlDb250YWluc0tleSh1c2VyLCBQT1NTSUJMRV9FTUFJTF9IRUFERVJTKTtcblxuICAgICAgICAgICAgaWYgKCFoYXNMb2dpbiAmJiAhaGFzUmVnaXN0cmF0aW9uTnVtYmVyICYmICFoYXNFbWFpbCkge1xuICAgICAgICAgICAgICAgIC8vICcrIDInIGluc3RlYWQgb2YgJysgMScgZHVlIHRvIHRoZSBoZWFkZXIgY29sdW1uIGluIHRoZSBjc3YgZmlsZVxuICAgICAgICAgICAgICAgIGludmFsaWRMaXN0LnB1c2goaSArIDIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBpbnZhbGlkTGlzdC5sZW5ndGggPT09IDAgPyB1bmRlZmluZWQgOiBpbnZhbGlkTGlzdC5qb2luKCcsICcpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFBhcnNlcyBhIGNzdiBmaWxlIGFuZCByZXR1cm5zIGEgcHJvbWlzZSB3aXRoIGEgbGlzdCBvZiByb3dzXG4gICAgICogQHBhcmFtIGNzdkZpbGUgRmlsZSB0aGF0IHNob3VsZCBiZSBwYXJzZWRcbiAgICAgKi9cbiAgICBwcml2YXRlIHBhcnNlQ1NWRmlsZShjc3ZGaWxlOiBGaWxlKTogUHJvbWlzZTxDc3ZVc2VyW10+IHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIHBhcnNlKGNzdkZpbGUsIHtcbiAgICAgICAgICAgICAgICBoZWFkZXI6IHRydWUsXG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtSGVhZGVyOiAoaGVhZGVyOiBzdHJpbmcpID0+IGhlYWRlci50b0xvd2VyQ2FzZSgpLnJlcGxhY2VBbGwoJyAnLCAnJykucmVwbGFjZUFsbCgnXycsICcnKS5yZXBsYWNlQWxsKCctJywgJycpLFxuICAgICAgICAgICAgICAgIHNraXBFbXB0eUxpbmVzOiB0cnVlLFxuICAgICAgICAgICAgICAgIGNvbXBsZXRlOiAocmVzdWx0cykgPT4gcmVzb2x2ZShyZXN1bHRzLmRhdGEgYXMgQ3N2VXNlcltdKSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKGVycm9yKSA9PiByZWplY3QoZXJyb3IpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIHRoZSBpbXBvcnQgcmVxdWVzdCB0byB0aGUgc2VydmVyIHdpdGggdGhlIGxpc3Qgb2YgdXNlcnMgdG8gYmUgaW1wb3J0ZWRcbiAgICAgKi9cbiAgICBpbXBvcnRVc2VycygpIHtcbiAgICAgICAgdGhpcy5pc0ltcG9ydGluZyA9IHRydWU7XG4gICAgICAgIGlmICh0aGlzLnR1dG9yaWFsR3JvdXApIHtcbiAgICAgICAgICAgIHRoaXMudHV0b3JpYWxHcm91cFNlcnZpY2UucmVnaXN0ZXJNdWx0aXBsZVN0dWRlbnRzKHRoaXMuY291cnNlSWQsIHRoaXMudHV0b3JpYWxHcm91cC5pZCEsIHRoaXMudXNlcnNUb0ltcG9ydCkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAocmVzKSA9PiB0aGlzLm9uU2F2ZVN1Y2Nlc3MocmVzKSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKCkgPT4gdGhpcy5vblNhdmVFcnJvcigpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5jb3Vyc2VHcm91cCAmJiAhdGhpcy5leGFtKSB7XG4gICAgICAgICAgICB0aGlzLmNvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlLmFkZFVzZXJzVG9Hcm91cEluQ291cnNlKHRoaXMuY291cnNlSWQsIHRoaXMudXNlcnNUb0ltcG9ydCwgdGhpcy5jb3Vyc2VHcm91cCkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAocmVzKSA9PiB0aGlzLm9uU2F2ZVN1Y2Nlc3MocmVzKSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKCkgPT4gdGhpcy5vblNhdmVFcnJvcigpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSBpZiAoIXRoaXMuY291cnNlR3JvdXAgJiYgdGhpcy5leGFtKSB7XG4gICAgICAgICAgICB0aGlzLmV4YW1NYW5hZ2VtZW50U2VydmljZS5hZGRTdHVkZW50c1RvRXhhbSh0aGlzLmNvdXJzZUlkLCB0aGlzLmV4YW0uaWQhLCB0aGlzLmV4YW1Vc2Vyc1RvSW1wb3J0KS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgICAgIG5leHQ6IChyZXMpID0+IHRoaXMub25TYXZlU3VjY2VzcyhyZXMpLFxuICAgICAgICAgICAgICAgIGVycm9yOiAoKSA9PiB0aGlzLm9uU2F2ZUVycm9yKCksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLmVycm9yKCdhcnRlbWlzQXBwLmltcG9ydFVzZXJzLmdlbmVyaWNFcnJvck1lc3NhZ2UnKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFRydWUgaWYgdGhpcyB1c2VyIHdhcyBzdWNjZXNzZnVsbHkgaW1wb3J0ZWQsIGZhbHNlIG90aGVyd2lzZVxuICAgICAqIEBwYXJhbSB1c2VyIFRoZSB1c2VyIHRvIGJlIGNoZWNrZWRcbiAgICAgKi9cbiAgICB3YXNJbXBvcnRlZCh1c2VyOiBTdHVkZW50RFRPKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLmhhc0ltcG9ydGVkICYmICF0aGlzLndhc05vdEltcG9ydGVkKHVzZXIpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFRydWUgaWYgdGhpcyB1c2VyIGNvdWxkIG5vdCBiZSBpbXBvcnRlZCwgZmFsc2Ugb3RoZXJ3aXNlXG4gICAgICogQHBhcmFtIHVzZXIgVGhlIHVzZXIgdG8gYmUgY2hlY2tlZFxuICAgICAqL1xuICAgIHdhc05vdEltcG9ydGVkKHVzZXI6IFN0dWRlbnREVE8pOiBib29sZWFuIHtcbiAgICAgICAgaWYgKHRoaXMuaGFzSW1wb3J0ZWQgJiYgdGhpcy5ub3RGb3VuZFVzZXJzPy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZvciAoY29uc3Qgbm90Rm91bmQgb2YgdGhpcy5ub3RGb3VuZFVzZXJzKSB7XG4gICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgKG5vdEZvdW5kLnJlZ2lzdHJhdGlvbk51bWJlcj8ubGVuZ3RoID4gMCAmJiBub3RGb3VuZC5yZWdpc3RyYXRpb25OdW1iZXIgPT09IHVzZXIucmVnaXN0cmF0aW9uTnVtYmVyKSB8fFxuICAgICAgICAgICAgICAgIChub3RGb3VuZC5sb2dpbj8ubGVuZ3RoID4gMCAmJiBub3RGb3VuZC5sb2dpbiA9PT0gdXNlci5sb2dpbikgfHxcbiAgICAgICAgICAgICAgICAobm90Rm91bmQuZW1haWw/Lmxlbmd0aCA+IDAgJiYgbm90Rm91bmQuZW1haWwgPT09IHVzZXIuZW1haWwpXG4gICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBOdW1iZXIgb2YgVXNlcnMgdGhhdCB3ZXJlIHN1Y2Nlc3NmdWxseSBpbXBvcnRlZFxuICAgICAqL1xuICAgIGdldCBudW1iZXJPZlVzZXJzSW1wb3J0ZWQoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuICF0aGlzLmhhc0ltcG9ydGVkXG4gICAgICAgICAgICA/IDBcbiAgICAgICAgICAgIDogdGhpcy5leGFtVXNlck1vZGVcbiAgICAgICAgICAgID8gdGhpcy5leGFtVXNlcnNUb0ltcG9ydC5sZW5ndGggLSB0aGlzLm51bWJlck9mVXNlcnNOb3RJbXBvcnRlZFxuICAgICAgICAgICAgOiB0aGlzLnVzZXJzVG9JbXBvcnQubGVuZ3RoIC0gdGhpcy5udW1iZXJPZlVzZXJzTm90SW1wb3J0ZWQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTnVtYmVyIG9mIHVzZXJzIHdoaWNoIGNvdWxkIG5vdCBiZSBpbXBvcnRlZFxuICAgICAqL1xuICAgIGdldCBudW1iZXJPZlVzZXJzTm90SW1wb3J0ZWQoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuICF0aGlzLmhhc0ltcG9ydGVkID8gMCA6IHRoaXMubm90Rm91bmRVc2Vycy5sZW5ndGg7XG4gICAgfVxuXG4gICAgZ2V0IGlzU3VibWl0RGlzYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLmV4YW1Vc2VyTW9kZSA/IHRoaXMuaXNJbXBvcnRpbmcgfHwgIXRoaXMuZXhhbVVzZXJzVG9JbXBvcnQ/Lmxlbmd0aCA6IHRoaXMuaXNJbXBvcnRpbmcgfHwgIXRoaXMudXNlcnNUb0ltcG9ydD8ubGVuZ3RoO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENhbGxiYWNrIG1ldGhvZCB0aGF0IGlzIGNhbGxlZCB3aGVuIHRoZSBpbXBvcnQgcmVxdWVzdCB3YXMgc3VjY2Vzc2Z1bFxuICAgICAqIEBwYXJhbSB7SHR0cFJlc3BvbnNlPFN0dWRlbnREVE9bXT59IG5vdEZvdW5kVXNlcnMgLSBMaXN0IG9mIHVzZXJzIHRoYXQgY291bGQgTk9UIGJlIGltcG9ydGVkIHNpbmNlIHRoZXkgd2VyZSBub3QgZm91bmRcbiAgICAgKi9cbiAgICBvblNhdmVTdWNjZXNzKG5vdEZvdW5kVXNlcnM6IEh0dHBSZXNwb25zZTxTdHVkZW50RFRPW10+KSB7XG4gICAgICAgIHRoaXMuaXNJbXBvcnRpbmcgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5oYXNJbXBvcnRlZCA9IHRydWU7XG4gICAgICAgIHRoaXMubm90Rm91bmRVc2VycyA9IG5vdEZvdW5kVXNlcnMuYm9keSEgfHwgW107XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2FsbGJhY2sgbWV0aG9kIHRoYXQgaXMgY2FsbGVkIHdoZW4gdGhlIGltcG9ydCByZXF1ZXN0IGZhaWxlZFxuICAgICAqL1xuICAgIG9uU2F2ZUVycm9yKCkge1xuICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5lcnJvcignYXJ0ZW1pc0FwcC5pbXBvcnRVc2Vycy5nZW5lcmljRXJyb3JNZXNzYWdlJyk7XG4gICAgICAgIHRoaXMuaXNJbXBvcnRpbmcgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBjbGVhcigpIHtcbiAgICAgICAgdGhpcy5hY3RpdmVNb2RhbC5kaXNtaXNzKCdjYW5jZWwnKTtcbiAgICB9XG5cbiAgICBvbkZpbmlzaCgpIHtcbiAgICAgICAgdGhpcy5hY3RpdmVNb2RhbC5jbG9zZSgpO1xuICAgIH1cbn1cbiIsIjxmb3JtIGlkPVwidXNlckltcG9ydERpYWxvZ0Zvcm1cIiBuYW1lPVwiaW1wb3J0Rm9ybVwiIHJvbGU9XCJmb3JtXCIgbm92YWxpZGF0ZT5cbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtaGVhZGVyXCI+XG4gICAgICAgIDxoNCBjbGFzcz1cIm1vZGFsLXRpdGxlXCI+XG4gICAgICAgICAgICA8c3BhbiBbamhpVHJhbnNsYXRlXT1cIidhcnRlbWlzQXBwLmltcG9ydFVzZXJzLmRpYWxvZ1RpdGxlJ1wiPiBJbXBvcnQgdXNlcnMgaW50bzogPC9zcGFuPlxuICAgICAgICA8L2g0PlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1jbG9zZVwiIGRhdGEtZGlzbWlzcz1cIm1vZGFsXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgKGNsaWNrKT1cImNsZWFyKClcIj48L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtYm9keVwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgPHAgY2xhc3M9XCJpbnRyby10ZXh0XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pbXBvcnRVc2Vycy5pbnRyb1RleHRcIj5UaGlzIGRpYWxvZyBjYW4gYmUgdXNlZCB0byBpbXBvcnQgdXNlcnMuPC9wPlxuICAgICAgICAgICAgPHAgY2xhc3M9XCJpbnRyby10ZXh0XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pbXBvcnRVc2Vycy5kaWFsb2dUZXh0XCI+PC9wPlxuICAgICAgICAgICAgPHAgY2xhc3M9XCJpbnRyby10ZXh0XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pbXBvcnRVc2Vycy5jc3ZFeGFtcGxlVGV4dFwiPjwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIEBpZiAoIWV4YW1Vc2VyTW9kZSkge1xuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlIHRhYmxlLWJvcmRlcmVkIHctYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPkxvZ2luPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggW2poaVRyYW5zbGF0ZV09XCInYXJ0ZW1pc0FwcC5pbXBvcnRVc2Vycy5lbWFpbCdcIj5FbWFpbDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIFtqaGlUcmFuc2xhdGVdPVwiJ2FydGVtaXNBcHAuaW1wb3J0VXNlcnMucmVnaXN0cmF0aW9uTnVtYmVyJ1wiPk1hdHJpY3VsYXRpb24gTnVtYmVyPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+dXNlcl8xPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnVzZXJfMiYjNjQ7YXJ0ZW1pcy5vcmc8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD48L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+MTE3MTIzNDU8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQXJyb3dSaWdodFwiIGNsYXNzPVwibXgtMlwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICA8c3Bhbj51c2VyXzEsIHVzZXJfMiwgdXNlcl8zPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChleGFtVXNlck1vZGUpIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWNlbnRlciBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3M9XCJ0YWJsZSB0YWJsZS1ib3JkZXJlZCB3LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5Mb2dpbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIFtqaGlUcmFuc2xhdGVdPVwiJ2FydGVtaXNBcHAuaW1wb3J0VXNlcnMuZW1haWwnXCI+RW1haWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBbamhpVHJhbnNsYXRlXT1cIidhcnRlbWlzQXBwLmltcG9ydFVzZXJzLnJlZ2lzdHJhdGlvbk51bWJlcidcIj5NYXRyaWN1bGF0aW9uIE51bWJlcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIFtqaGlUcmFuc2xhdGVdPVwiJ2FydGVtaXNBcHAuaW1wb3J0VXNlcnMucm9vbSdcIj5Sb29tPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggW2poaVRyYW5zbGF0ZV09XCInYXJ0ZW1pc0FwcC5pbXBvcnRVc2Vycy5zZWF0J1wiPlNlYXQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD51c2VyXzE8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD51c2VyXzImIzY0O2FydGVtaXMub3JnPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+MTE3MTIzNDU8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD4xMC4xMDE8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD4yNUY8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQXJyb3dSaWdodFwiIGNsYXNzPVwibXgtMlwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICA8c3Bhbj51c2VyXzE8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBhbGlnbi1pdGVtcy1lbmRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwiaW1wb3J0Q1NWXCIgY2xhc3M9XCJsYWJlbC1uYXJyb3cgZm9udC13ZWlnaHQtYm9sZFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuaW1wb3J0VXNlcnMuY3N2RmlsZS5sYWJlbFwiPlNlbGVjdCAuY3N2IGZpbGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8amhpLWhlbHAtaWNvbiB0ZXh0PVwiYXJ0ZW1pc0FwcC5pbXBvcnRVc2Vycy5jc3ZGaWxlLnRvb2x0aXBcIiBjbGFzcz1cIm1lLTFcIj48L2poaS1oZWxwLWljb24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgQGlmIChpc1BhcnNpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gY2xhc3M9XCJsb2FkaW5nLXNwaW5uZXIgbXMtMVwiIFtpY29uXT1cImZhU3Bpbm5lclwiIFtzcGluXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXQtMlwiPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBpZD1cImltcG9ydENTVlwiIHR5cGU9XCJmaWxlXCIgYWNjZXB0PVwiLmNzdlwiIChjaGFuZ2UpPVwib25DU1ZGaWxlU2VsZWN0KCRldmVudClcIiAvPlxuICAgICAgICAgICAgICAgIEBpZiAodmFsaWRhdGlvbkVycm9yIHx8IG5vVXNlcnNGb3VuZEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtdC00IG1iLTIgdGV4dC1kYW5nZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgW2poaVRyYW5zbGF0ZV09XCInYXJ0ZW1pc0FwcC5pbXBvcnRVc2Vycy51c2Vyc0ZvckltcG9ydC5pbXBvcnRGYWlsZWQnXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3M9XCJtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICh2YWxpZGF0aW9uRXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGIgW2poaVRyYW5zbGF0ZV09XCInYXJ0ZW1pc0FwcC5pbXBvcnRVc2Vycy51c2Vyc0ZvckltcG9ydC5mYWlsZWRSb3dzJ1wiPjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiIFtpbm5lckhUTUxdPVwidmFsaWRhdGlvbkVycm9yXCI+IDwvYj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChub1VzZXJzRm91bmRFcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YiBbamhpVHJhbnNsYXRlXT1cIidhcnRlbWlzQXBwLmltcG9ydFVzZXJzLnVzZXJzRm9ySW1wb3J0Lm5vVXNlcnNGb3VuZCdcIj48L2I+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICBAaWYgKHVzZXJzVG9JbXBvcnQgJiYgdXNlcnNUb0ltcG9ydC5sZW5ndGggPiAwICYmICFleGFtVXNlck1vZGUpIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwIG10LTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJsYWJlbC1uYXJyb3cgZm9udC13ZWlnaHQtYm9sZFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuaW1wb3J0VXNlcnMudXNlcnNGb3JJbXBvcnQubGFiZWxcIj4gVXNlcnMgZm9yIGltcG9ydDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxqaGktaGVscC1pY29uIHRleHQ9XCJhcnRlbWlzQXBwLmltcG9ydFVzZXJzLnVzZXJzRm9ySW1wb3J0LnRvb2x0aXBcIiBjbGFzcz1cIm1lLTFcIj48L2poaS1oZWxwLWljb24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzPVwidGFibGUgdGFibGUtc3RyaXBlZCB0YWJsZS1zbSBoZWFkZXItZml4ZWQgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCI+IzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgc3R5bGU9XCJ3aWR0aDogMzAwcHhcIiBbamhpVHJhbnNsYXRlXT1cIidhcnRlbWlzQXBwLmltcG9ydFVzZXJzLnJlZ2lzdHJhdGlvbk51bWJlcidcIj5NYXRyaWN1bGF0aW9uIG51bWJlcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCI+TG9naW48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIFtqaGlUcmFuc2xhdGVdPVwiJ2FydGVtaXNBcHAuaW1wb3J0VXNlcnMuZW1haWwnXCI+RW1haWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIFtqaGlUcmFuc2xhdGVdPVwiJ2FydGVtaXNBcHAuaW1wb3J0VXNlcnMuZmlyc3ROYW1lJ1wiPkZpcnN0IG5hbWU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIFtqaGlUcmFuc2xhdGVdPVwiJ2FydGVtaXNBcHAuaW1wb3J0VXNlcnMubGFzdE5hbWUnXCI+TGFzdCBuYW1lPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzcz1cInRhYmxlLWJvZHktLXN0dWRlbnRzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBAZm9yICh1c2VyIG9mIHVzZXJzVG9JbXBvcnQ7IHRyYWNrIHVzZXI7IGxldCBpID0gJGluZGV4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIFtjbGFzcy5pbXBvcnQtc3VjY2Vzc109XCJ3YXNJbXBvcnRlZCh1c2VyKVwiIFtjbGFzcy5pbXBvcnQtZmFpbF09XCJ3YXNOb3RJbXBvcnRlZCh1c2VyKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJyb3dcIj57eyBpICsgMSB9fTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT1cIndpZHRoOiAzMDBweFwiPnt7IHVzZXIucmVnaXN0cmF0aW9uTnVtYmVyIH19PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt7IHVzZXIubG9naW4gfX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e3sgdXNlci5lbWFpbCB9fTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyB1c2VyLmZpcnN0TmFtZSB9fTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyB1c2VyLmxhc3ROYW1lIH19PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgICBAaWYgKGV4YW1Vc2Vyc1RvSW1wb3J0ICYmIGV4YW1Vc2Vyc1RvSW1wb3J0Lmxlbmd0aCA+IDAgJiYgZXhhbVVzZXJNb2RlKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cCBtdC00IHRhYmxlLXJlc3BvbnNpdmVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJsYWJlbC1uYXJyb3cgZm9udC13ZWlnaHQtYm9sZFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuaW1wb3J0VXNlcnMudXNlcnNGb3JJbXBvcnQubGFiZWxcIj4gVXNlcnMgZm9yIGltcG9ydDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxqaGktaGVscC1pY29uIHRleHQ9XCJhcnRlbWlzQXBwLmltcG9ydFVzZXJzLnVzZXJzRm9ySW1wb3J0LnRvb2x0aXBcIiBjbGFzcz1cIm1lLTFcIj48L2poaS1oZWxwLWljb24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzPVwidGFibGUgdGFibGUtc3RyaXBlZCB0YWJsZS1zbSBoZWFkZXItZml4ZWQgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCI+IzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgc3R5bGU9XCJ3aWR0aDogMzUwcHhcIiBbamhpVHJhbnNsYXRlXT1cIidhcnRlbWlzQXBwLmltcG9ydFVzZXJzLnJlZ2lzdHJhdGlvbk51bWJlcidcIj5NYXRyaWN1bGF0aW9uIG51bWJlcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCI+TG9naW48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIFtqaGlUcmFuc2xhdGVdPVwiJ2FydGVtaXNBcHAuaW1wb3J0VXNlcnMuZW1haWwnXCI+RW1haWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIFtqaGlUcmFuc2xhdGVdPVwiJ2FydGVtaXNBcHAuaW1wb3J0VXNlcnMuZmlyc3ROYW1lJ1wiPkZpcnN0IG5hbWU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIFtqaGlUcmFuc2xhdGVdPVwiJ2FydGVtaXNBcHAuaW1wb3J0VXNlcnMubGFzdE5hbWUnXCI+TGFzdCBuYW1lPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBbamhpVHJhbnNsYXRlXT1cIidhcnRlbWlzQXBwLmV4YW0uZXhhbVVzZXJzLnJvb20nXCI+Um9vbTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgW2poaVRyYW5zbGF0ZV09XCInYXJ0ZW1pc0FwcC5leGFtLmV4YW1Vc2Vycy5zZWF0J1wiPlNlYXQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzPVwidGFibGUtYm9keS0tc3R1ZGVudHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKHVzZXIgb2YgZXhhbVVzZXJzVG9JbXBvcnQ7IHRyYWNrIHVzZXI7IGxldCBpID0gJGluZGV4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIFtjbGFzcy5pbXBvcnQtc3VjY2Vzc109XCJ3YXNJbXBvcnRlZCh1c2VyKVwiIFtjbGFzcy5pbXBvcnQtZmFpbF09XCJ3YXNOb3RJbXBvcnRlZCh1c2VyKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJyb3dcIj57eyBpICsgMSB9fTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT1cIndpZHRoOiAzNTBweFwiPnt7IHVzZXIucmVnaXN0cmF0aW9uTnVtYmVyIH19PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt7IHVzZXIubG9naW4gfX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e3sgdXNlci5lbWFpbCB9fTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyB1c2VyLmZpcnN0TmFtZSB9fTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyB1c2VyLmxhc3ROYW1lIH19PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt7IHVzZXIucm9vbSB9fTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyB1c2VyLnNlYXQgfX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cIm1vZGFsLWZvb3RlciBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblwiPlxuICAgICAgICBAaWYgKHVzZXJzVG9JbXBvcnQgJiYgdXNlcnNUb0ltcG9ydC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleC1zaHJpbmstMCBtZS0yIGQtZmxleFwiPlxuICAgICAgICAgICAgICAgIEBpZiAoIWhhc0ltcG9ydGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPnt7ICdhcnRlbWlzQXBwLmltcG9ydFVzZXJzLm51bWJlck9mVXNlcnMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Jm5ic3A7e3sgdXNlcnNUb0ltcG9ydC5sZW5ndGggfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57eyAnYXJ0ZW1pc0FwcC5pbXBvcnRVc2Vycy5udW1iZXJPZlVzZXJzSW1wb3J0ZWQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgbnVtYmVyT2ZVc2Vyc0ltcG9ydGVkIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1zLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e3sgJ2FydGVtaXNBcHAuaW1wb3J0VXNlcnMubnVtYmVyT2ZVc2Vyc05vdEltcG9ydGVkJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjxiIHN0eWxlPVwiY29sb3I6IHJlZFwiPnt7IG51bWJlck9mVXNlcnNOb3RJbXBvcnRlZCB9fTwvYj48L3NwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChleGFtVXNlcnNUb0ltcG9ydCAmJiBleGFtVXNlcnNUb0ltcG9ydC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleC1zaHJpbmstMCBtZS0yIGQtZmxleFwiPlxuICAgICAgICAgICAgICAgIEBpZiAoIWhhc0ltcG9ydGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPnt7ICdhcnRlbWlzQXBwLmltcG9ydFVzZXJzLm51bWJlck9mVXNlcnMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Jm5ic3A7e3sgZXhhbVVzZXJzVG9JbXBvcnQubGVuZ3RoIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e3sgJ2FydGVtaXNBcHAuaW1wb3J0VXNlcnMubnVtYmVyT2ZVc2Vyc0ltcG9ydGVkJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IG51bWJlck9mVXNlcnNJbXBvcnRlZCB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtcy0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPnt7ICdhcnRlbWlzQXBwLmltcG9ydFVzZXJzLm51bWJlck9mVXNlcnNOb3RJbXBvcnRlZCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48YiBzdHlsZT1cImNvbG9yOiByZWRcIj57eyBudW1iZXJPZlVzZXJzTm90SW1wb3J0ZWQgfX08L2I+PC9zcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4LWdyb3ctMSBkLWZsZXgganVzdGlmeS1jb250ZW50LWVuZFwiPlxuICAgICAgICAgICAgQGlmICghaGFzSW1wb3J0ZWQpIHtcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBjYW5jZWwgbWUtMlwiIGRhdGEtZGlzbWlzcz1cIm1vZGFsXCIgKGNsaWNrKT1cImNsZWFyKClcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFCYW5cIj48L2ZhLWljb24+Jm5ic3A7PHNwYW4gamhpVHJhbnNsYXRlPVwiZW50aXR5LmFjdGlvbi5jYW5jZWxcIj5DYW5jZWw8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgaWQ9XCJpbXBvcnRcIiBuYW1lPVwiaW1wb3J0QnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIiBbZGlzYWJsZWRdPVwiaXNTdWJtaXREaXNhYmxlZFwiIChjbGljayk9XCJpbXBvcnRVc2VycygpXCI+XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhVXBsb2FkXCIgY2xhc3M9XCJtZS0yXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJlbnRpdHkuYWN0aW9uLnRvLWltcG9ydFwiPkltcG9ydDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gY2xhc3M9XCJtcy0xXCIgW2hpZGRlbl09XCIhaXNJbXBvcnRpbmdcIiBbc3Bpbl09XCJ0cnVlXCIgW2ljb25dPVwiZmFDaXJjbGVOb3RjaFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIH0gQGVsc2Uge1xuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXN1Y2Nlc3NcIiBpZD1cImZpbmlzaC1idXR0b25cIiAoY2xpY2spPVwib25GaW5pc2goKVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUNoZWNrXCIgY2xhc3M9XCJtZS0yXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJlbnRpdHkuYWN0aW9uLmZpbmlzaFwiPkZpbmlzaDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG48L2Zvcm0+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE91dHB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmdiTW9kYWwsIE5nYk1vZGFsUmVmIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xuaW1wb3J0IHsgQnV0dG9uU2l6ZSwgQnV0dG9uVHlwZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9idXR0b24uY29tcG9uZW50JztcbmltcG9ydCB7IFVzZXJzSW1wb3J0RGlhbG9nQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC91c2VyLWltcG9ydC91c2Vycy1pbXBvcnQtZGlhbG9nLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDb3Vyc2VHcm91cCB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb3Vyc2UubW9kZWwnO1xuaW1wb3J0IHsgRXhhbSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGFtLm1vZGVsJztcbmltcG9ydCB7IGZhUGx1cyB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBUdXRvcmlhbEdyb3VwIH0gZnJvbSAnYXBwL2VudGl0aWVzL3R1dG9yaWFsLWdyb3VwL3R1dG9yaWFsLWdyb3VwLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktdXNlci1pbXBvcnQtYnV0dG9uJyxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICA8amhpLWJ1dHRvblxuICAgICAgICAgICAgW2J0blR5cGVdPVwiQnV0dG9uVHlwZS5QUklNQVJZXCJcbiAgICAgICAgICAgIFtidG5TaXplXT1cImJ1dHRvblNpemVcIlxuICAgICAgICAgICAgW2ljb25dPVwiZmFQbHVzXCJcbiAgICAgICAgICAgIFt0aXRsZV09XCInYXJ0ZW1pc0FwcC5pbXBvcnRVc2Vycy5idXR0b25MYWJlbCdcIlxuICAgICAgICAgICAgKG9uQ2xpY2spPVwib3BlblVzZXJzSW1wb3J0RGlhbG9nKCRldmVudClcIlxuICAgICAgICA+PC9qaGktYnV0dG9uPlxuICAgIGAsXG59KVxuZXhwb3J0IGNsYXNzIFVzZXJzSW1wb3J0QnV0dG9uQ29tcG9uZW50IHtcbiAgICBCdXR0b25UeXBlID0gQnV0dG9uVHlwZTtcbiAgICBCdXR0b25TaXplID0gQnV0dG9uU2l6ZTtcblxuICAgIEBJbnB1dCgpIHR1dG9yaWFsR3JvdXA6IFR1dG9yaWFsR3JvdXAgfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG4gICAgQElucHV0KCkgZXhhbVVzZXJNb2RlOiBib29sZWFuO1xuICAgIEBJbnB1dCgpIGNvdXJzZUdyb3VwOiBDb3Vyc2VHcm91cDtcbiAgICBASW5wdXQoKSBjb3Vyc2VJZDogbnVtYmVyO1xuICAgIEBJbnB1dCgpIGJ1dHRvblNpemU6IEJ1dHRvblNpemUgPSBCdXR0b25TaXplLk1FRElVTTtcbiAgICBASW5wdXQoKSBleGFtOiBFeGFtO1xuXG4gICAgQE91dHB1dCgpIGZpbmlzaDogRXZlbnRFbWl0dGVyPHZvaWQ+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYVBsdXMgPSBmYVBsdXM7XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIG1vZGFsU2VydmljZTogTmdiTW9kYWwpIHt9XG5cbiAgICAvKipcbiAgICAgKiBPcGVuIHVwIGltcG9ydCBkaWFsb2cgZm9yIHVzZXJzXG4gICAgICogQHBhcmFtIHtFdmVudH0gZXZlbnQgLSBNb3VzZSBFdmVudCB3aGljaCBpbnZva2VkIHRoZSBvcGVuaW5nXG4gICAgICovXG4gICAgb3BlblVzZXJzSW1wb3J0RGlhbG9nKGV2ZW50OiBNb3VzZUV2ZW50KSB7XG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBjb25zdCBtb2RhbFJlZjogTmdiTW9kYWxSZWYgPSB0aGlzLm1vZGFsU2VydmljZS5vcGVuKFVzZXJzSW1wb3J0RGlhbG9nQ29tcG9uZW50LCB7IGtleWJvYXJkOiB0cnVlLCBzaXplOiAnbGcnLCBiYWNrZHJvcDogJ3N0YXRpYycgfSk7XG4gICAgICAgIG1vZGFsUmVmLmNvbXBvbmVudEluc3RhbmNlLmNvdXJzZUlkID0gdGhpcy5jb3Vyc2VJZDtcbiAgICAgICAgbW9kYWxSZWYuY29tcG9uZW50SW5zdGFuY2UuY291cnNlR3JvdXAgPSB0aGlzLmNvdXJzZUdyb3VwO1xuICAgICAgICBtb2RhbFJlZi5jb21wb25lbnRJbnN0YW5jZS5leGFtID0gdGhpcy5leGFtO1xuICAgICAgICBtb2RhbFJlZi5jb21wb25lbnRJbnN0YW5jZS50dXRvcmlhbEdyb3VwID0gdGhpcy50dXRvcmlhbEdyb3VwO1xuICAgICAgICBtb2RhbFJlZi5jb21wb25lbnRJbnN0YW5jZS5leGFtVXNlck1vZGUgPSB0aGlzLmV4YW1Vc2VyTW9kZTtcbiAgICAgICAgbW9kYWxSZWYucmVzdWx0LnRoZW4oXG4gICAgICAgICAgICAoKSA9PiB0aGlzLmZpbmlzaC5lbWl0KCksXG4gICAgICAgICAgICAoKSA9PiB7fSxcbiAgICAgICAgKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBVc2Vyc0ltcG9ydERpYWxvZ0NvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvdXNlci1pbXBvcnQvdXNlcnMtaW1wb3J0LWRpYWxvZy5jb21wb25lbnQnO1xuaW1wb3J0IHsgVXNlcnNJbXBvcnRCdXR0b25Db21wb25lbnQgfSBmcm9tICdhcHAvc2hhcmVkL3VzZXItaW1wb3J0L3VzZXJzLWltcG9ydC1idXR0b24uY29tcG9uZW50JztcbmltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL3NoYXJlZC1jb21wb25lbnQubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRDb21tb25Nb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC1jb21tb24ubW9kdWxlJztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSwgQXJ0ZW1pc1NoYXJlZENvbW1vbk1vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbVXNlcnNJbXBvcnREaWFsb2dDb21wb25lbnQsIFVzZXJzSW1wb3J0QnV0dG9uQ29tcG9uZW50XSxcbiAgICBleHBvcnRzOiBbVXNlcnNJbXBvcnREaWFsb2dDb21wb25lbnQsIFVzZXJzSW1wb3J0QnV0dG9uQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgVXNlckltcG9ydE1vZHVsZSB7fVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLFdBQVcsT0FBa0IsV0FBVyx5QkFBeUI7QUFDMUUsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsc0JBQXNCO0FBSS9CLFNBQVMsZUFBZTtBQU14QixTQUFTLGFBQWE7QUFDdEIsU0FBUyxjQUFjLE9BQU8sU0FBUyxlQUFlLFdBQVcsZ0JBQWdCOzs7Ozs7O0FDQ3JFLElBQUEsb0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxvQkFBQSxJQUFBLE9BQUE7QUFBSyxJQUFBLDBCQUFBO0FBQ1QsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUFvRCxJQUFBLG9CQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsMEJBQUE7QUFDekQsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUFpRSxJQUFBLG9CQUFBLElBQUEsc0JBQUE7QUFBb0IsSUFBQSwwQkFBQTtBQUN6RixJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQU0sSUFBQSwwQkFBQTtBQUNWLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsdUJBQUEsSUFBQSxJQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLElBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLHVCQUFBLElBQUEsSUFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQXNCLElBQUEsMEJBQUE7QUFDMUIsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLElBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLHVCQUFBLElBQUEsSUFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsdUJBQUEsSUFBQSxJQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLElBQUEsVUFBQTtBQUFRLElBQUEsMEJBQUE7QUFDaEIsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQXNCLElBQUEsMEJBQUE7QUFDaEMsSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxZQUFBOzs7O0FBekJ3QixJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLHdCQUFBLGdCQUFBLDhCQUFBO0FBQ0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxnQkFBQSwyQ0FBQTtBQXFCUCxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLHdCQUFBLFFBQUEsT0FBQSxZQUFBOzs7OztBQUtiLElBQUEsb0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxvQkFBQSxJQUFBLE9BQUE7QUFBSyxJQUFBLDBCQUFBO0FBQ1QsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUFvRCxJQUFBLG9CQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsMEJBQUE7QUFDekQsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUFpRSxJQUFBLG9CQUFBLElBQUEsc0JBQUE7QUFBb0IsSUFBQSwwQkFBQTtBQUNyRixJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQSxDQUFBO0FBQW1ELElBQUEsb0JBQUEsSUFBQSxNQUFBO0FBQUksSUFBQSwwQkFBQTtBQUN2RCxJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQSxDQUFBO0FBQW1ELElBQUEsb0JBQUEsSUFBQSxNQUFBO0FBQUksSUFBQSwwQkFBQTtBQUMzRCxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQU0sSUFBQSwwQkFBQTtBQUNWLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQXNCLElBQUEsMEJBQUE7QUFDMUIsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLElBQUEsVUFBQTtBQUFRLElBQUEsMEJBQUE7QUFDWixJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQU0sSUFBQSwwQkFBQTtBQUNWLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxvQkFBQSxJQUFBLEtBQUE7QUFBRyxJQUFBLDBCQUFBO0FBQ1gsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFBTSxJQUFBLDBCQUFBO0FBQ2hCLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsWUFBQTs7OztBQW5Cd0IsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSx3QkFBQSxnQkFBQSw4QkFBQTtBQUNBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsZ0JBQUEsMkNBQUE7QUFDQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGdCQUFBLDZCQUFBO0FBQ0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxnQkFBQSw2QkFBQTtBQWFQLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsd0JBQUEsUUFBQSxPQUFBLFlBQUE7Ozs7O0FBV0wsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx1QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxvQkFBQTs7OztBQUQwQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFFBQUEsT0FBQSxTQUFBLEVBQWtCLFFBQUEsSUFBQTs7Ozs7QUFVNUMsSUFBQSxvQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQ0EsSUFBQSxvQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUFrQyxJQUFBLG9CQUFBLEdBQUEsR0FBQTtBQUFBLElBQUEsMEJBQUE7QUFDdEMsSUFBQSxvQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTs7OztBQUhXLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsZ0JBQUEsa0RBQUE7QUFDQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGFBQUEsUUFBQSxpQkFBQSwyQkFBQTs7Ozs7QUFJUCxJQUFBLG9CQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsdUJBQUEsR0FBQSxLQUFBLENBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLGdDQUFBOzs7QUFGVyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGdCQUFBLG9EQUFBOzs7OztBQVhuQixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx1QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsa0VBQUEsR0FBQSxDQUFBLEVBS0MsR0FBQSxrRUFBQSxHQUFBLENBQUE7QUFNTCxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxvQkFBQTs7OztBQWZhLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsZ0JBQUEsb0RBQUE7QUFFRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLEdBQUEsT0FBQSxrQkFBQSxJQUFBLEVBQUE7QUFNQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLEdBQUEsT0FBQSxvQkFBQSxJQUFBLEVBQUE7Ozs7O0FBNkJBLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUFnQixJQUFBLG9CQUFBLENBQUE7QUFBVyxJQUFBLDBCQUFBO0FBQzNCLElBQUEsb0JBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEVBQUE7QUFBeUIsSUFBQSxvQkFBQSxDQUFBO0FBQTZCLElBQUEsMEJBQUE7QUFDdEQsSUFBQSxvQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLEVBQUE7QUFBZ0IsSUFBQSwwQkFBQTtBQUNwQixJQUFBLG9CQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsRUFBQTtBQUFnQixJQUFBLDBCQUFBO0FBQ3BCLElBQUEsb0JBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxvQkFBQSxFQUFBO0FBQW9CLElBQUEsMEJBQUE7QUFDeEIsSUFBQSxvQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLEVBQUE7QUFBbUIsSUFBQSwwQkFBQTtBQUMzQixJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLDRCQUFBOzs7Ozs7QUFSUSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGtCQUFBLFFBQUEsWUFBQSxRQUFBLENBQUEsRUFBMEMsZUFBQSxRQUFBLGVBQUEsUUFBQSxDQUFBO0FBQzFCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsUUFBQSxDQUFBO0FBQ1MsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxTQUFBLGtCQUFBO0FBQ3JCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsU0FBQSxLQUFBO0FBQ0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxTQUFBLEtBQUE7QUFDQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFNBQUEsU0FBQTtBQUNBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsU0FBQSxRQUFBOzs7OztBQXhCeEIsSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUF5RyxJQUFBLG9CQUFBLEdBQUEsbUJBQUE7QUFBZ0IsSUFBQSwwQkFBQTtBQUN6SCxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsaUJBQUEsRUFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7QUFBZ0IsSUFBQSxvQkFBQSxJQUFBLEdBQUE7QUFBQyxJQUFBLDBCQUFBO0FBQ2pCLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7QUFBa0csSUFBQSxvQkFBQSxJQUFBLHNCQUFBO0FBQW9CLElBQUEsMEJBQUE7QUFDdEgsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFnQixJQUFBLG9CQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsMEJBQUE7QUFDckIsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFnRSxJQUFBLG9CQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsMEJBQUE7QUFDckUsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFvRSxJQUFBLG9CQUFBLElBQUEsWUFBQTtBQUFVLElBQUEsMEJBQUE7QUFDOUUsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFtRSxJQUFBLG9CQUFBLElBQUEsV0FBQTtBQUFTLElBQUEsMEJBQUE7QUFDaEYsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLDJEQUFBLElBQUEsSUFBQSxNQUFBLE1BQUEsc0NBQUE7QUFVSixJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsWUFBQTs7OztBQXJCeUQsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSx3QkFBQSxnQkFBQSwyQ0FBQTtBQUVyQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGdCQUFBLDhCQUFBO0FBQ0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxnQkFBQSxrQ0FBQTtBQUNBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsZ0JBQUEsaUNBQUE7QUFJcEIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxPQUFBLGFBQUE7Ozs7O0FBbUNJLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUFnQixJQUFBLG9CQUFBLENBQUE7QUFBVyxJQUFBLDBCQUFBO0FBQzNCLElBQUEsb0JBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEVBQUE7QUFBeUIsSUFBQSxvQkFBQSxDQUFBO0FBQTZCLElBQUEsMEJBQUE7QUFDdEQsSUFBQSxvQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLEVBQUE7QUFBZ0IsSUFBQSwwQkFBQTtBQUNwQixJQUFBLG9CQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsRUFBQTtBQUFnQixJQUFBLDBCQUFBO0FBQ3BCLElBQUEsb0JBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxvQkFBQSxFQUFBO0FBQW9CLElBQUEsMEJBQUE7QUFDeEIsSUFBQSxvQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLEVBQUE7QUFBbUIsSUFBQSwwQkFBQTtBQUN2QixJQUFBLG9CQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsRUFBQTtBQUFlLElBQUEsMEJBQUE7QUFDbkIsSUFBQSxvQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLEVBQUE7QUFBZSxJQUFBLDBCQUFBO0FBQ3ZCLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsNEJBQUE7Ozs7OztBQVZRLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsa0JBQUEsUUFBQSxZQUFBLFFBQUEsQ0FBQSxFQUEwQyxlQUFBLFFBQUEsZUFBQSxRQUFBLENBQUE7QUFDMUIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxRQUFBLENBQUE7QUFDUyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFNBQUEsa0JBQUE7QUFDckIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxTQUFBLEtBQUE7QUFDQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFNBQUEsS0FBQTtBQUNBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsU0FBQSxTQUFBO0FBQ0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxTQUFBLFFBQUE7QUFDQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFNBQUEsSUFBQTtBQUNBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsU0FBQSxJQUFBOzs7OztBQTVCeEIsSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUF5RyxJQUFBLG9CQUFBLEdBQUEsbUJBQUE7QUFBZ0IsSUFBQSwwQkFBQTtBQUN6SCxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsaUJBQUEsRUFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7QUFBZ0IsSUFBQSxvQkFBQSxJQUFBLEdBQUE7QUFBQyxJQUFBLDBCQUFBO0FBQ2pCLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7QUFBa0csSUFBQSxvQkFBQSxJQUFBLHNCQUFBO0FBQW9CLElBQUEsMEJBQUE7QUFDdEgsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFnQixJQUFBLG9CQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsMEJBQUE7QUFDckIsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFnRSxJQUFBLG9CQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsMEJBQUE7QUFDckUsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFvRSxJQUFBLG9CQUFBLElBQUEsWUFBQTtBQUFVLElBQUEsMEJBQUE7QUFDOUUsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFtRSxJQUFBLG9CQUFBLElBQUEsV0FBQTtBQUFTLElBQUEsMEJBQUE7QUFDNUUsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFrRSxJQUFBLG9CQUFBLElBQUEsTUFBQTtBQUFJLElBQUEsMEJBQUE7QUFDdEUsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFrRSxJQUFBLG9CQUFBLElBQUEsTUFBQTtBQUFJLElBQUEsMEJBQUE7QUFDMUUsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLDJEQUFBLElBQUEsSUFBQSxNQUFBLE1BQUEsc0NBQUE7QUFZSixJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsWUFBQTs7OztBQXpCeUQsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSx3QkFBQSxnQkFBQSwyQ0FBQTtBQUVyQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGdCQUFBLDhCQUFBO0FBQ0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxnQkFBQSxrQ0FBQTtBQUNBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsZ0JBQUEsaUNBQUE7QUFDQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGdCQUFBLGdDQUFBO0FBQ0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxnQkFBQSxnQ0FBQTtBQUlwQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLE9BQUEsaUJBQUE7Ozs7O0FBcUJKLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUE7QUFBUSxJQUFBLG9CQUFBLENBQUE7O0FBQStELElBQUEsMEJBQUE7QUFDdkUsSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLENBQUE7QUFBZ0MsSUFBQSwwQkFBQTtBQUMxQyxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLG9CQUFBOzs7O0FBSGdCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsR0FBQSxHQUFBLHNDQUFBLENBQUE7QUFDRixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFFBQUEsUUFBQSxjQUFBLFFBQUEsRUFBQTs7Ozs7QUFHVixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBO0FBQVEsSUFBQSxvQkFBQSxDQUFBOztBQUF1RSxJQUFBLDBCQUFBO0FBQy9FLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxDQUFBO0FBQTJCLElBQUEsMEJBQUE7QUFDckMsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsUUFBQTtBQUFRLElBQUEsb0JBQUEsRUFBQTs7QUFBMEUsSUFBQSwwQkFBQTtBQUNsRixJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQSxFQUNLLElBQUEsS0FBQSxFQUFBO0FBQXNCLElBQUEsb0JBQUEsRUFBQTtBQUE4QixJQUFBLDBCQUFBLEVBQUk7QUFFakUsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxvQkFBQTs7OztBQVRnQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLEdBQUEsR0FBQSw4Q0FBQSxDQUFBO0FBQ0YsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxRQUFBLHFCQUFBO0FBR0UsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxJQUFBLEdBQUEsaURBQUEsQ0FBQTtBQUVtQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFFBQUEsd0JBQUE7Ozs7O0FBZHZDLElBQUEsb0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsa0VBQUEsSUFBQSxDQUFBLEVBS0MsR0FBQSxrRUFBQSxJQUFBLENBQUE7QUFZTCxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFlBQUE7Ozs7QUFsQlEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLENBQUEsT0FBQSxjQUFBLElBQUEsQ0FBQTs7Ozs7QUFzQkksSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQTtBQUFRLElBQUEsb0JBQUEsQ0FBQTs7QUFBK0QsSUFBQSwwQkFBQTtBQUN2RSxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsQ0FBQTtBQUFvQyxJQUFBLDBCQUFBO0FBQzlDLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7Ozs7QUFIZ0IsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxHQUFBLEdBQUEsc0NBQUEsQ0FBQTtBQUNGLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsUUFBQSxRQUFBLGtCQUFBLFFBQUEsRUFBQTs7Ozs7QUFHVixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBO0FBQVEsSUFBQSxvQkFBQSxDQUFBOztBQUF1RSxJQUFBLDBCQUFBO0FBQy9FLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxDQUFBO0FBQTJCLElBQUEsMEJBQUE7QUFDckMsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsUUFBQTtBQUFRLElBQUEsb0JBQUEsRUFBQTs7QUFBMEUsSUFBQSwwQkFBQTtBQUNsRixJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQSxFQUNLLElBQUEsS0FBQSxFQUFBO0FBQXNCLElBQUEsb0JBQUEsRUFBQTtBQUE4QixJQUFBLDBCQUFBLEVBQUk7QUFFakUsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxvQkFBQTs7OztBQVRnQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLEdBQUEsR0FBQSw4Q0FBQSxDQUFBO0FBQ0YsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxRQUFBLHFCQUFBO0FBR0UsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxJQUFBLEdBQUEsaURBQUEsQ0FBQTtBQUVtQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFFBQUEsd0JBQUE7Ozs7O0FBZHZDLElBQUEsb0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsa0VBQUEsSUFBQSxDQUFBLEVBS0MsR0FBQSxrRUFBQSxJQUFBLENBQUE7QUFZTCxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFlBQUE7Ozs7QUFsQlEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLENBQUEsT0FBQSxjQUFBLElBQUEsQ0FBQTs7Ozs7O0FBcUJBLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBK0UsSUFBQSx3QkFBQSxTQUFBLFNBQUEsNkVBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsMkJBQUE7QUFBQSxhQUFTLHlCQUFBLFFBQUEsTUFBQSxDQUFPO0lBQUEsQ0FBQTtBQUMzRixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQWtDLElBQUEsb0JBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSw0QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUEwQyxJQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFNLElBQUEsMEJBQUE7QUFDNUYsSUFBQSxvQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBNEcsSUFBQSx3QkFBQSxTQUFBLFNBQUEsNkVBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsMkJBQUE7QUFBQSxhQUFTLHlCQUFBLFFBQUEsWUFBQSxDQUFhO0lBQUEsQ0FBQTtBQUM5SCxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHVCQUFBLElBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUE2QyxJQUFBLG9CQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsMEJBQUE7QUFDbkQsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsZ0JBQUE7Ozs7QUFQaUIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxRQUFBLE9BQUEsS0FBQTtBQUVpRSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFlBQUEsT0FBQSxnQkFBQTtBQUNqRSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFFBQUEsT0FBQSxRQUFBO0FBRWEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxVQUFBLENBQUEsT0FBQSxXQUFBLEVBQXVCLFFBQUEsSUFBQSxFQUFBLFFBQUEsT0FBQSxhQUFBOzs7Ozs7QUFHakQsSUFBQSxvQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFtRCxJQUFBLHdCQUFBLFNBQUEsU0FBQSw2RUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSwyQkFBQTtBQUFBLGFBQVMseUJBQUEsUUFBQSxTQUFBLENBQVU7SUFBQSxDQUFBO0FBQ2xFLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsdUJBQUEsR0FBQSxXQUFBLEVBQUE7QUFDQSxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTBDLElBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQU0sSUFBQSwwQkFBQTtBQUNwRCxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLGdCQUFBOzs7O0FBSGlCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsUUFBQSxPQUFBLE9BQUE7OztBRG5PN0IsU0FpQk0sc0NBQ0Esd0JBQ0Esd0JBQ0EsNkJBQ0EsNEJBQ0EsdUJBQ0EsdUJBVU87QUFqQ2I7O0FBR0E7QUFJQTtBQUNBO0FBRUE7QUFLQTs7Ozs7Ozs7O0FBRUEsSUFBTSx1Q0FBdUMsQ0FBQyxzQkFBc0IsdUJBQXVCLGtCQUFrQixRQUFRO0FBQ3JILElBQU0seUJBQXlCLENBQUMsU0FBUyxRQUFRLFlBQVksWUFBWSxjQUFjO0FBQ3ZGLElBQU0seUJBQXlCLENBQUMsU0FBUyxVQUFVLE1BQU07QUFDekQsSUFBTSw4QkFBOEIsQ0FBQyxhQUFhLHNCQUFzQixhQUFhLFlBQVksU0FBUztBQUMxRyxJQUFNLDZCQUE2QixDQUFDLGNBQWMsWUFBWSx1QkFBdUIsV0FBVyxZQUFZLGdCQUFnQixNQUFNO0FBQ2xJLElBQU0sd0JBQXdCLENBQUMsY0FBYyxjQUFjLFFBQVEsUUFBUSxNQUFNO0FBQ2pGLElBQU0sd0JBQXdCLENBQUMsY0FBYyxjQUFjLGFBQWEsUUFBUSxRQUFRLE1BQU07QUFVeEYsSUFBTyw2QkFBUCxNQUFPLDRCQUEwQjtNQWlDdkI7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQXBDSCxhQUFhO01BRXNCO01BRW5DO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFFVCxnQkFBOEIsQ0FBQTtNQUM5QixvQkFBbUMsQ0FBQTtNQUNuQyxnQkFBOEIsQ0FBQTtNQUU5QixZQUFZO01BQ1o7TUFDQTtNQUNBLGNBQWM7TUFDZCxjQUFjO01BRU4sb0JBQW9CLElBQUksUUFBTztNQUN2QyxlQUFlLEtBQUssa0JBQWtCLGFBQVk7TUFHbEQsUUFBUTtNQUNSLFlBQVk7TUFDWixVQUFVO01BQ1YsZ0JBQWdCO01BQ2hCLFdBQVc7TUFDWCxlQUFlO01BRWYsWUFDWSxhQUNBLGNBQ0EsdUJBQ0EseUJBQ0Esc0JBQTJDO0FBSjNDLGFBQUEsY0FBQTtBQUNBLGFBQUEsZUFBQTtBQUNBLGFBQUEsd0JBQUE7QUFDQSxhQUFBLDBCQUFBO0FBQ0EsYUFBQSx1QkFBQTtNQUNUO01BRUgsY0FBVztBQUNQLGFBQUssa0JBQWtCLFlBQVc7TUFDdEM7TUFFUSxjQUFXO0FBQ2YsYUFBSyxnQkFBZ0IsQ0FBQTtBQUNyQixhQUFLLG9CQUFvQixDQUFBO0FBQ3pCLGFBQUssZ0JBQWdCLENBQUE7QUFDckIsYUFBSyxjQUFjO01BQ3ZCO01BRU0sZ0JBQWdCLE9BQVU7O0FBQzVCLGNBQUksTUFBTSxPQUFPLE1BQU0sU0FBUyxHQUFHO0FBQy9CLGlCQUFLLFlBQVc7QUFDaEIsZ0JBQUksS0FBSyxjQUFjO0FBQ25CLG1CQUFLLG9CQUFvQixNQUFNLEtBQUsscUJBQXFCLE9BQU8sTUFBTSxPQUFPLE1BQU0sQ0FBQyxDQUFDO21CQUNsRjtBQUNILG1CQUFLLGdCQUFnQixNQUFNLEtBQUsscUJBQXFCLE9BQU8sTUFBTSxPQUFPLE1BQU0sQ0FBQyxDQUFDOzs7UUFHN0Y7O01BUWMscUJBQXFCLE9BQVksU0FBYTs7QUFDeEQsY0FBSSxXQUFzQixDQUFBO0FBQzFCLGNBQUk7QUFDQSxpQkFBSyxZQUFZO0FBQ2pCLGlCQUFLLGtCQUFrQjtBQUN2Qix1QkFBVyxNQUFNLEtBQUssYUFBYSxPQUFPO21CQUNyQyxPQUFPO0FBQ1osaUJBQUssa0JBQWtCLE1BQU07O0FBRTdCLGlCQUFLLFlBQVk7O0FBRXJCLGNBQUksU0FBUyxTQUFTLEdBQUc7QUFDckIsaUJBQUssd0JBQXdCLFNBQVMsUUFBUTtxQkFDdkMsU0FBUyxXQUFXLEdBQUc7QUFDOUIsaUJBQUssb0JBQW9COztBQUU3QixjQUFJLEtBQUssbUJBQW1CLFNBQVMsV0FBVyxHQUFHO0FBQy9DLGtCQUFNLE9BQU8sUUFBUTtBQUNyQixtQkFBTyxDQUFBOztBQUdYLGdCQUFNLGNBQWMsT0FBTyxLQUFLLFNBQVMsTUFBSyxLQUFNLENBQUEsQ0FBRTtBQUV0RCxnQkFBTSwyQkFBMkIsWUFBWSxLQUFLLENBQUMsVUFBVSxxQ0FBcUMsU0FBUyxLQUFLLENBQUMsS0FBSztBQUN0SCxnQkFBTSxjQUFjLFlBQVksS0FBSyxDQUFDLFVBQVUsdUJBQXVCLFNBQVMsS0FBSyxDQUFDLEtBQUs7QUFDM0YsZ0JBQU0sY0FBYyxZQUFZLEtBQUssQ0FBQyxVQUFVLHVCQUF1QixTQUFTLEtBQUssQ0FBQyxLQUFLO0FBQzNGLGdCQUFNLGtCQUFrQixZQUFZLEtBQUssQ0FBQyxVQUFVLDRCQUE0QixTQUFTLEtBQUssQ0FBQyxLQUFLO0FBQ3BHLGdCQUFNLGlCQUFpQixZQUFZLEtBQUssQ0FBQyxVQUFVLDJCQUEyQixTQUFTLEtBQUssQ0FBQyxLQUFLO0FBRWxHLGdCQUFNLGFBQWEsWUFBWSxLQUFLLENBQUMsVUFBVSxzQkFBc0IsU0FBUyxLQUFLLENBQUMsS0FBSztBQUN6RixnQkFBTSxhQUFhLFlBQVksS0FBSyxDQUFDLFVBQVUsc0JBQXNCLFNBQVMsS0FBSyxDQUFDLEtBQUs7QUFFekYsY0FBSSxLQUFLLGNBQWM7QUFDbkIsbUJBQU8sU0FBUyxJQUNaLENBQUMsV0FDSTtjQUNHLG9CQUFvQixNQUFNLHdCQUF3QixHQUFHLEtBQUksS0FBTTtjQUMvRCxPQUFPLE1BQU0sV0FBVyxHQUFHLEtBQUksS0FBTTtjQUNyQyxPQUFPLE1BQU0sV0FBVyxHQUFHLEtBQUksS0FBTTtjQUNyQyxXQUFXLE1BQU0sZUFBZSxHQUFHLEtBQUksS0FBTTtjQUM3QyxVQUFVLE1BQU0sY0FBYyxHQUFHLEtBQUksS0FBTTtjQUMzQyxNQUFNLE1BQU0sVUFBVSxHQUFHLEtBQUksS0FBTTtjQUNuQyxNQUFNLE1BQU0sVUFBVSxHQUFHLEtBQUksS0FBTTtjQUN0QjtpQkFFdEI7QUFDSCxtQkFBTyxTQUFTLElBQ1osQ0FBQyxXQUNJO2NBQ0csb0JBQW9CLE1BQU0sd0JBQXdCLEdBQUcsS0FBSSxLQUFNO2NBQy9ELE9BQU8sTUFBTSxXQUFXLEdBQUcsS0FBSSxLQUFNO2NBQ3JDLE9BQU8sTUFBTSxXQUFXLEdBQUcsS0FBSSxLQUFNO2NBQ3JDLFdBQVcsTUFBTSxlQUFlLEdBQUcsS0FBSSxLQUFNO2NBQzdDLFVBQVUsTUFBTSxjQUFjLEdBQUcsS0FBSSxLQUFNO2NBQy9COztRQUdoQzs7TUFTQSx3QkFBd0IsU0FBZSxVQUFtQjtBQUN0RCxjQUFNLHFCQUFxQixLQUFLLDBCQUEwQixRQUFRO0FBQ2xFLFlBQUksb0JBQW9CO0FBQ3BCLGdCQUFNLFlBQVk7QUFDbEIsZUFBSyxrQkFBa0IsbUJBQW1CLFVBQVUsWUFBWSxxQkFBcUIsbUJBQW1CLE1BQU0sR0FBRyxTQUFTLElBQUk7O01BRXRJO01BT0Esd0JBQXdCLE9BQWdCLE1BQWM7QUFDbEQsZUFBTyxLQUFLLEtBQUssQ0FBQyxRQUFRLE1BQU0sR0FBRyxNQUFNLFVBQWEsTUFBTSxHQUFHLE1BQU0sRUFBRTtNQUMzRTtNQU1BLDBCQUEwQixVQUFtQjtBQUN6QyxjQUFNLGNBQXdCLENBQUE7QUFDOUIsbUJBQVcsQ0FBQyxHQUFHLElBQUksS0FBSyxTQUFTLFFBQU8sR0FBSTtBQUN4QyxnQkFBTSxXQUFXLEtBQUssd0JBQXdCLE1BQU0sc0JBQXNCO0FBQzFFLGdCQUFNLHdCQUF3QixLQUFLLHdCQUF3QixNQUFNLG9DQUFvQztBQUNyRyxnQkFBTSxXQUFXLEtBQUssd0JBQXdCLE1BQU0sc0JBQXNCO0FBRTFFLGNBQUksQ0FBQyxZQUFZLENBQUMseUJBQXlCLENBQUMsVUFBVTtBQUVsRCx3QkFBWSxLQUFLLElBQUksQ0FBQzs7O0FBRzlCLGVBQU8sWUFBWSxXQUFXLElBQUksU0FBWSxZQUFZLEtBQUssSUFBSTtNQUN2RTtNQU1RLGFBQWEsU0FBYTtBQUM5QixlQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVTtBQUNuQyxnQkFBTSxTQUFTO1lBQ1gsUUFBUTtZQUNSLGlCQUFpQixDQUFDLFdBQW1CLE9BQU8sWUFBVyxFQUFHLFdBQVcsS0FBSyxFQUFFLEVBQUUsV0FBVyxLQUFLLEVBQUUsRUFBRSxXQUFXLEtBQUssRUFBRTtZQUNwSCxnQkFBZ0I7WUFDaEIsVUFBVSxDQUFDLFlBQVksUUFBUSxRQUFRLElBQWlCO1lBQ3hELE9BQU8sQ0FBQyxVQUFVLE9BQU8sS0FBSztXQUNqQztRQUNMLENBQUM7TUFDTDtNQUtBLGNBQVc7QUFDUCxhQUFLLGNBQWM7QUFDbkIsWUFBSSxLQUFLLGVBQWU7QUFDcEIsZUFBSyxxQkFBcUIseUJBQXlCLEtBQUssVUFBVSxLQUFLLGNBQWMsSUFBSyxLQUFLLGFBQWEsRUFBRSxVQUFVO1lBQ3BILE1BQU0sQ0FBQyxRQUFRLEtBQUssY0FBYyxHQUFHO1lBQ3JDLE9BQU8sTUFBTSxLQUFLLFlBQVc7V0FDaEM7bUJBQ00sS0FBSyxlQUFlLENBQUMsS0FBSyxNQUFNO0FBQ3ZDLGVBQUssd0JBQXdCLHdCQUF3QixLQUFLLFVBQVUsS0FBSyxlQUFlLEtBQUssV0FBVyxFQUFFLFVBQVU7WUFDaEgsTUFBTSxDQUFDLFFBQVEsS0FBSyxjQUFjLEdBQUc7WUFDckMsT0FBTyxNQUFNLEtBQUssWUFBVztXQUNoQzttQkFDTSxDQUFDLEtBQUssZUFBZSxLQUFLLE1BQU07QUFDdkMsZUFBSyxzQkFBc0Isa0JBQWtCLEtBQUssVUFBVSxLQUFLLEtBQUssSUFBSyxLQUFLLGlCQUFpQixFQUFFLFVBQVU7WUFDekcsTUFBTSxDQUFDLFFBQVEsS0FBSyxjQUFjLEdBQUc7WUFDckMsT0FBTyxNQUFNLEtBQUssWUFBVztXQUNoQztlQUNFO0FBQ0gsZUFBSyxhQUFhLE1BQU0sNENBQTRDOztNQUU1RTtNQU1BLFlBQVksTUFBZ0I7QUFDeEIsZUFBTyxLQUFLLGVBQWUsQ0FBQyxLQUFLLGVBQWUsSUFBSTtNQUN4RDtNQU1BLGVBQWUsTUFBZ0I7QUFDM0IsWUFBSSxLQUFLLGVBQWUsS0FBSyxlQUFlLFdBQVcsR0FBRztBQUN0RCxpQkFBTzs7QUFHWCxtQkFBVyxZQUFZLEtBQUssZUFBZTtBQUN2QyxjQUNLLFNBQVMsb0JBQW9CLFNBQVMsS0FBSyxTQUFTLHVCQUF1QixLQUFLLHNCQUNoRixTQUFTLE9BQU8sU0FBUyxLQUFLLFNBQVMsVUFBVSxLQUFLLFNBQ3RELFNBQVMsT0FBTyxTQUFTLEtBQUssU0FBUyxVQUFVLEtBQUssT0FDekQ7QUFDRSxtQkFBTzs7O0FBSWYsZUFBTztNQUNYO01BS0EsSUFBSSx3QkFBcUI7QUFDckIsZUFBTyxDQUFDLEtBQUssY0FDUCxJQUNBLEtBQUssZUFDTCxLQUFLLGtCQUFrQixTQUFTLEtBQUssMkJBQ3JDLEtBQUssY0FBYyxTQUFTLEtBQUs7TUFDM0M7TUFLQSxJQUFJLDJCQUF3QjtBQUN4QixlQUFPLENBQUMsS0FBSyxjQUFjLElBQUksS0FBSyxjQUFjO01BQ3REO01BRUEsSUFBSSxtQkFBZ0I7QUFDaEIsZUFBTyxLQUFLLGVBQWUsS0FBSyxlQUFlLENBQUMsS0FBSyxtQkFBbUIsU0FBUyxLQUFLLGVBQWUsQ0FBQyxLQUFLLGVBQWU7TUFDOUg7TUFNQSxjQUFjLGVBQXlDO0FBQ25ELGFBQUssY0FBYztBQUNuQixhQUFLLGNBQWM7QUFDbkIsYUFBSyxnQkFBZ0IsY0FBYyxRQUFTLENBQUE7TUFDaEQ7TUFLQSxjQUFXO0FBQ1AsYUFBSyxhQUFhLE1BQU0sNENBQTRDO0FBQ3BFLGFBQUssY0FBYztNQUN2QjtNQUVBLFFBQUs7QUFDRCxhQUFLLFlBQVksUUFBUSxRQUFRO01BQ3JDO01BRUEsV0FBUTtBQUNKLGFBQUssWUFBWSxNQUFLO01BQzFCOzt5QkEvUlMsNkJBQTBCLCtCQUFBLGlCQUFBLEdBQUEsK0JBQUEsWUFBQSxHQUFBLCtCQUFBLHFCQUFBLEdBQUEsK0JBQUEsdUJBQUEsR0FBQSwrQkFBQSxxQkFBQSxDQUFBO01BQUE7Z0VBQTFCLDZCQUEwQixXQUFBLENBQUEsQ0FBQSx5QkFBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLGlDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBOzs7Ozs7Ozs7QUNqQ3ZDLFVBQUEsNEJBQUEsR0FBQSxRQUFBLENBQUE7QUFDSSxVQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxNQUFBLENBQUE7QUFDSSxVQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQTZELFVBQUEsb0JBQUEsR0FBQSxzQkFBQTtBQUFtQixVQUFBLDBCQUFBO0FBQ3BGLFVBQUEsb0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUFnRixVQUFBLHdCQUFBLFNBQUEsU0FBQSwrREFBQTtBQUFBLG1CQUFTLElBQUEsTUFBQTtVQUFPLENBQUE7QUFBRSxVQUFBLDBCQUFBO0FBQ3RHLFVBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxLQUFBLENBQUE7QUFBc0UsVUFBQSxvQkFBQSxJQUFBLDBDQUFBO0FBQXdDLFVBQUEsMEJBQUE7QUFDOUcsVUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSx1QkFBQSxJQUFBLEtBQUEsQ0FBQTtBQUNBLFVBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsdUJBQUEsSUFBQSxLQUFBLENBQUE7QUFDSixVQUFBLG9CQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMEJBQUE7QUFDQSxVQUFBLG9CQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxvREFBQSxJQUFBLENBQUEsRUErQkMsSUFBQSxvREFBQSxJQUFBLENBQUE7QUEyQkQsVUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxVQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsS0FBQTtBQUNJLFVBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBaUgsVUFBQSxvQkFBQSxJQUFBLGtCQUFBO0FBQWdCLFVBQUEsMEJBQUE7QUFDakksVUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx1QkFBQSxJQUFBLGlCQUFBLEVBQUE7QUFDSixVQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDBCQUFBO0FBQ0EsVUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLG9EQUFBLEdBQUEsQ0FBQTtBQUdKLFVBQUEsMEJBQUE7QUFDQSxVQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFnRCxVQUFBLHdCQUFBLFVBQUEsU0FBQSw2REFBQSxRQUFBO0FBQUEsbUJBQVUsSUFBQSxnQkFBQSxNQUFBO1VBQXVCLENBQUE7QUFBakYsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxvREFBQSxJQUFBLENBQUE7QUFrQkosVUFBQSwwQkFBQTtBQUNKLFVBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLG9EQUFBLElBQUEsQ0FBQSxFQStCQyxJQUFBLG9EQUFBLElBQUEsQ0FBQTtBQXFDTCxVQUFBLDBCQUFBO0FBQ0EsVUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxvQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsb0RBQUEsR0FBQSxDQUFBLEVBb0JDLElBQUEsb0RBQUEsR0FBQSxDQUFBO0FBc0JELFVBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxVQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsb0RBQUEsSUFBQSxDQUFBLEVBU0MsSUFBQSxvREFBQSxHQUFBLENBQUE7QUFNTCxVQUFBLDBCQUFBO0FBQ0osVUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDBCQUFBO0FBQ0osVUFBQSxvQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDBCQUFBO0FBQ0EsVUFBQSxvQkFBQSxJQUFBLElBQUE7OztBQXZPa0IsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSx3QkFBQSxnQkFBQSxvQ0FBQTtBQVVWLFVBQUEsdUJBQUEsRUFBQTtBQUFBLFVBQUEsMkJBQUEsSUFBQSxDQUFBLElBQUEsZUFBQSxLQUFBLEVBQUE7QUFnQ0EsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSwyQkFBQSxJQUFBLElBQUEsZUFBQSxLQUFBLEVBQUE7QUFnQ1EsVUFBQSx1QkFBQSxFQUFBO0FBQUEsVUFBQSwyQkFBQSxJQUFBLElBQUEsWUFBQSxLQUFBLEVBQUE7QUFNQSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLDJCQUFBLElBQUEsSUFBQSxtQkFBQSxJQUFBLG9CQUFBLEtBQUEsRUFBQTtBQW9CUixVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLDJCQUFBLElBQUEsSUFBQSxpQkFBQSxJQUFBLGNBQUEsU0FBQSxLQUFBLENBQUEsSUFBQSxlQUFBLEtBQUEsRUFBQTtBQWdDQSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLDJCQUFBLElBQUEsSUFBQSxxQkFBQSxJQUFBLGtCQUFBLFNBQUEsS0FBQSxJQUFBLGVBQUEsS0FBQSxFQUFBO0FBc0NBLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsMkJBQUEsSUFBQSxJQUFBLGlCQUFBLElBQUEsY0FBQSxTQUFBLElBQUEsS0FBQSxFQUFBO0FBcUJBLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsMkJBQUEsSUFBQSxJQUFBLHFCQUFBLElBQUEsa0JBQUEsU0FBQSxJQUFBLEtBQUEsRUFBQTtBQXNCSSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLDJCQUFBLElBQUEsQ0FBQSxJQUFBLGNBQUEsS0FBQSxFQUFBOzs7OztvRkR2TEMsNEJBQTBCLEVBQUEsV0FBQSw2QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVqQ3ZDLFNBQVMsYUFBQUEsWUFBVyxjQUFjLFNBQUFDLFFBQU8sY0FBYztBQUN2RCxTQUFTLGdCQUE2QjtBQUt0QyxTQUFTLGNBQWM7OztBQU52QixJQXFCYTtBQXJCYjs7QUFFQTtBQUNBO0FBRUE7O0FBZ0JNLElBQU8sNkJBQVAsTUFBTyw0QkFBMEI7TUFnQmY7TUFmcEIsYUFBYTtNQUNiLGFBQWE7TUFFSixnQkFBMkM7TUFDM0M7TUFDQTtNQUNBO01BQ0EsYUFBeUIsV0FBVztNQUNwQztNQUVDLFNBQTZCLElBQUksYUFBWTtNQUd2RCxTQUFTO01BRVQsWUFBb0IsY0FBc0I7QUFBdEIsYUFBQSxlQUFBO01BQXlCO01BTTdDLHNCQUFzQixPQUFpQjtBQUNuQyxjQUFNLGdCQUFlO0FBQ3JCLGNBQU0sV0FBd0IsS0FBSyxhQUFhLEtBQUssNEJBQTRCLEVBQUUsVUFBVSxNQUFNLE1BQU0sTUFBTSxVQUFVLFNBQVEsQ0FBRTtBQUNuSSxpQkFBUyxrQkFBa0IsV0FBVyxLQUFLO0FBQzNDLGlCQUFTLGtCQUFrQixjQUFjLEtBQUs7QUFDOUMsaUJBQVMsa0JBQWtCLE9BQU8sS0FBSztBQUN2QyxpQkFBUyxrQkFBa0IsZ0JBQWdCLEtBQUs7QUFDaEQsaUJBQVMsa0JBQWtCLGVBQWUsS0FBSztBQUMvQyxpQkFBUyxPQUFPLEtBQ1osTUFBTSxLQUFLLE9BQU8sS0FBSSxHQUN0QixNQUFLO1FBQUUsQ0FBQztNQUVoQjs7eUJBbENTLDZCQUEwQixnQ0FBQSxZQUFBLENBQUE7TUFBQTtpRUFBMUIsNkJBQTBCLFdBQUEsQ0FBQSxDQUFBLHdCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsZUFBQSxpQkFBQSxjQUFBLGdCQUFBLGFBQUEsZUFBQSxVQUFBLFlBQUEsWUFBQSxjQUFBLE1BQUEsT0FBQSxHQUFBLFNBQUEsRUFBQSxRQUFBLFNBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsV0FBQSxXQUFBLFFBQUEsU0FBQSxTQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsb0NBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUFUL0IsVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsY0FBQSxDQUFBO0FBS0ksVUFBQSx5QkFBQSxXQUFBLFNBQUEsa0VBQUEsUUFBQTtBQUFBLG1CQUFXLElBQUEsc0JBQUEsTUFBQTtVQUE2QixDQUFBO0FBQzNDLFVBQUEsMkJBQUE7QUFDTCxVQUFBLHFCQUFBLEdBQUEsUUFBQTs7O0FBTlEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxXQUFBLElBQUEsV0FBQSxPQUFBLEVBQThCLFdBQUEsSUFBQSxVQUFBLEVBQUEsUUFBQSxJQUFBLE1BQUEsRUFBQSxTQUFBLG9DQUFBOzs7OztxRkFRN0IsNEJBQTBCLEVBQUEsV0FBQSw2QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUNuQnZDLFNBQVMsZ0JBQWdCOztBQUZ6QixJQVdhO0FBWGI7OztBQUNBO0FBRUE7QUFDQTtBQU9NLElBQU8sbUJBQVAsTUFBTyxrQkFBZ0I7O3lCQUFoQixtQkFBZ0I7TUFBQTtnRUFBaEIsa0JBQWdCLENBQUE7b0VBSmYsOEJBQThCLHlCQUF5QixFQUFBLENBQUE7Ozs7IiwibmFtZXMiOlsiQ29tcG9uZW50IiwiSW5wdXQiXX0=