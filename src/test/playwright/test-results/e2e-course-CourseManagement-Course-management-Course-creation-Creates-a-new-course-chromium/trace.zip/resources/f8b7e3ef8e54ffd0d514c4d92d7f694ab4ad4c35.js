import {
  ArtemisSharedModule,
  __esm,
  init_mode_picker_component,
  init_shared_module
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/shared/mode-picker/mode-picker.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisModePickerModule;
var init_mode_picker_module = __esm({
  "src/main/webapp/app/exercises/shared/mode-picker/mode-picker.module.ts"() {
    init_mode_picker_component();
    init_shared_module();
    ArtemisModePickerModule = class _ArtemisModePickerModule {
      static \u0275fac = function ArtemisModePickerModule_Factory(t) {
        return new (t || _ArtemisModePickerModule)();
      };
      static \u0275mod = i0.\u0275\u0275defineNgModule({ type: _ArtemisModePickerModule });
      static \u0275inj = i0.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule] });
    };
  }
});

export {
  ArtemisModePickerModule,
  init_mode_picker_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9tb2RlLXBpY2tlci9tb2RlLXBpY2tlci5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgTW9kZVBpY2tlckNvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL21vZGUtcGlja2VyL21vZGUtcGlja2VyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbTW9kZVBpY2tlckNvbXBvbmVudF0sXG4gICAgZXhwb3J0czogW01vZGVQaWNrZXJDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBBcnRlbWlzTW9kZVBpY2tlck1vZHVsZSB7fVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLFNBQVMsZ0JBQWdCOztBQUF6QixJQVVhO0FBVmI7O0FBRUE7QUFDQTtBQU9NLElBQU8sMEJBQVAsTUFBTyx5QkFBdUI7O3lCQUF2QiwwQkFBdUI7TUFBQTsrREFBdkIseUJBQXVCLENBQUE7bUVBSnRCLG1CQUFtQixFQUFBLENBQUE7Ozs7IiwibmFtZXMiOltdfQ==