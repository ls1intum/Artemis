import {
  OrionBuildAndTestService,
  OrionButtonComponent,
  OrionModule,
  init_orion_build_and_test_service,
  init_orion_button_component,
  init_orion_module
} from "/chunk-ZVM6GU35.js";
import {
  OrionConnectorService,
  init_orion_connector_service
} from "/chunk-ELJG2GZQ.js";
import {
  ArtemisHeaderExercisePageWithDetailsModule,
  ExerciseCategoriesModule,
  init_exercise_categories_module,
  init_exercise_headers_module
} from "/chunk-YH2LEYJ2.js";
import {
  SubmissionResultStatusModule,
  init_submission_result_status_module
} from "/chunk-KZDJAYFO.js";
import {
  init_grading_key_overview_component,
  init_grading_key_table_component
} from "/chunk-TNU7DPOK.js";
import {
  ArtemisCoursesRoutingModule,
  ArtemisSharedComponentModule,
  CourseExerciseRowComponent,
  CourseExercisesComponent,
  ExerciseDetailsStudentActionsComponent,
  ExerciseFilter2 as ExerciseFilter,
  FeatureToggleModule,
  init_course_exercise_row_component,
  init_course_exercises_component,
  init_courses_routing_module,
  init_exercise_details_student_actions_component,
  init_feature_toggle_module,
  init_shared_component_module
} from "/chunk-ORYTP7RT.js";
import {
  ExerciseView,
  init_orion
} from "/chunk-KQ77WIWP.js";
import {
  AccountService,
  ArtemisDatePipe,
  ArtemisSharedModule,
  ArtemisSharedPipesModule,
  ArtemisTranslatePipe,
  ExerciseService,
  FeatureToggle,
  TranslateDirective,
  __esm,
  init_account_service,
  init_artemis_date_pipe,
  init_artemis_translate_pipe,
  init_course_model,
  init_exercise_model,
  init_exercise_service,
  init_feature_toggle_service,
  init_shared_module,
  init_shared_pipes_module,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/orion/participation/orion-exercise-details-student-actions.component.ts
import { Component, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function OrionExerciseDetailsStudentActionsComponent_ng_template_2_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275elementStart(1, "jhi-ide-button", 2);
    i0.\u0275\u0275listener("clickHandler", function OrionExerciseDetailsStudentActionsComponent_ng_template_2_Conditional_1_Template_jhi_ide_button_clickHandler_1_listener() {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r4 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r4.importIntoIDE());
    });
    i0.\u0275\u0275pipe(2, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(3, "\n        ");
  }
  if (rf & 2) {
    const ctx_r2 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("featureToggle", ctx_r2.FeatureToggle.ProgrammingExercises)("buttonLabel", i0.\u0275\u0275pipeBind1(2, 4, "artemisApp.exerciseActions.importIntoIntelliJ"))("buttonLoading", ctx_r2.exercise.loading || ctx_r2.orionState.cloning)("smallButton", ctx_r2.smallButtons);
  }
}
function OrionExerciseDetailsStudentActionsComponent_ng_template_2_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275elementStart(1, "jhi-ide-button", 3);
    i0.\u0275\u0275listener("clickHandler", function OrionExerciseDetailsStudentActionsComponent_ng_template_2_Conditional_2_Template_jhi_ide_button_clickHandler_1_listener() {
      i0.\u0275\u0275restoreView(_r7);
      const ctx_r6 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r6.submitChanges());
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(2, "\n        ");
  }
  if (rf & 2) {
    const ctx_r3 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("featureToggle", ctx_r3.FeatureToggle.ProgrammingExercises)("buttonLoading", ctx_r3.exercise.loading || ctx_r3.orionState.building)("smallButton", ctx_r3.smallButtons);
  }
}
function OrionExerciseDetailsStudentActionsComponent_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275template(1, OrionExerciseDetailsStudentActionsComponent_ng_template_2_Conditional_1_Template, 4, 6)(2, OrionExerciseDetailsStudentActionsComponent_ng_template_2_Conditional_2_Template, 3, 3);
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(1, ctx_r0.isOfflineIdeAllowed && (ctx_r0.orionState.view !== ctx_r0.ExerciseView.STUDENT || ctx_r0.orionState.opened !== ctx_r0.exercise.id) ? 1 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(2, ctx_r0.isOfflineIdeAllowed && ctx_r0.orionState.view === ctx_r0.ExerciseView.STUDENT && ctx_r0.orionState.opened === ctx_r0.exercise.id ? 2 : -1);
  }
}
var OrionExerciseDetailsStudentActionsComponent;
var init_orion_exercise_details_student_actions_component = __esm({
  "src/main/webapp/app/orion/participation/orion-exercise-details-student-actions.component.ts"() {
    init_feature_toggle_service();
    init_orion();
    init_orion_connector_service();
    init_orion_build_and_test_service();
    init_exercise_model();
    init_orion_connector_service();
    init_orion_build_and_test_service();
    init_orion_button_component();
    init_exercise_details_student_actions_component();
    init_artemis_translate_pipe();
    OrionExerciseDetailsStudentActionsComponent = class _OrionExerciseDetailsStudentActionsComponent {
      orionConnectorService;
      ideBuildAndTestService;
      route;
      ExerciseView = ExerciseView;
      orionState;
      FeatureToggle = FeatureToggle;
      exercise;
      courseId;
      smallButtons;
      examMode;
      constructor(orionConnectorService, ideBuildAndTestService, route) {
        this.orionConnectorService = orionConnectorService;
        this.ideBuildAndTestService = ideBuildAndTestService;
        this.route = route;
      }
      ngOnInit() {
        this.orionConnectorService.state().subscribe((orionState) => this.orionState = orionState);
        this.route.queryParams.subscribe((params) => {
          if (params["withIdeSubmit"]) {
            this.submitChanges();
          }
        });
      }
      get isOfflineIdeAllowed() {
        return this.exercise.allowOfflineIde;
      }
      importIntoIDE() {
        const repo = this.exercise.studentParticipations[0].repositoryUri;
        this.orionConnectorService.importParticipation(repo, this.exercise);
      }
      submitChanges() {
        this.orionConnectorService.submit();
        this.ideBuildAndTestService.listenOnBuildOutputAndForwardChanges(this.exercise);
      }
      static \u0275fac = function OrionExerciseDetailsStudentActionsComponent_Factory(t) {
        return new (t || _OrionExerciseDetailsStudentActionsComponent)(i0.\u0275\u0275directiveInject(OrionConnectorService), i0.\u0275\u0275directiveInject(OrionBuildAndTestService), i0.\u0275\u0275directiveInject(i3.ActivatedRoute));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _OrionExerciseDetailsStudentActionsComponent, selectors: [["jhi-orion-exercise-details-student-actions"]], inputs: { exercise: "exercise", courseId: "courseId", smallButtons: "smallButtons", examMode: "examMode" }, decls: 6, vars: 4, consts: [[3, "exercise", "courseId", "smallButtons", "examMode"], ["overrideCloneOnlineEditorButton", ""], [3, "featureToggle", "buttonLabel", "buttonLoading", "smallButton", "clickHandler"], ["buttonLabel", "Submit", 3, "featureToggle", "buttonLoading", "smallButton", "clickHandler"]], template: function OrionExerciseDetailsStudentActionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "jhi-exercise-details-student-actions", 0);
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275template(2, OrionExerciseDetailsStudentActionsComponent_ng_template_2_Template, 3, 2, "ng-template", null, 1, i0.\u0275\u0275templateRefExtractor);
          i0.\u0275\u0275text(4, "\n");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(5, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275property("exercise", ctx.exercise)("courseId", ctx.courseId)("smallButtons", ctx.smallButtons)("examMode", ctx.examMode);
        }
      }, dependencies: [OrionButtonComponent, ExerciseDetailsStudentActionsComponent, ArtemisTranslatePipe], styles: ["\n\n.tab-bar-exercise-details[_ngcontent-%COMP%] {\n  flex-wrap: wrap;\n}\n.tab-bar-exercise-details[_ngcontent-%COMP%]   .instructor-actions[_ngcontent-%COMP%] {\n  width: 100%;\n  flex-basis: 100%;\n  justify-content: flex-end;\n}\n.course-body-container[_ngcontent-%COMP%] {\n  position: relative;\n}\n.refresh-overlay[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  display: flex;\n  justify-content: center;\n  align-items: flex-start;\n  opacity: 0;\n  pointer-events: none;\n  transition: 0.1s ease-out opacity;\n}\n.refresh-overlay.active[_ngcontent-%COMP%] {\n  background-color: var(--overview-refresh-overlay-bg-color);\n  opacity: 1;\n  pointer-events: auto;\n  transition: 0.2s ease-in opacity;\n}\n.refresh-overlay[_ngcontent-%COMP%]   .ng-fa-icon[_ngcontent-%COMP%] {\n  position: relative;\n  top: calc(50vh - 150px - 2.5vh);\n  transform: translateY(-50%);\n  color: var(--overview-refresh-overlay-color);\n}\n.back-button[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\n.current-week-row[_ngcontent-%COMP%]     > div {\n  background-color: var(--overview-light-primary-background-color);\n}\n.statistic-summary[_ngcontent-%COMP%] {\n  margin-top: 25px;\n}\n.statistic-summary[_ngcontent-%COMP%]   .chart-container[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: flex-end;\n  margin-bottom: 20px;\n}\n.statistic-summary[_ngcontent-%COMP%]   .chart-container[_ngcontent-%COMP%]   .chart-text[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 350px;\n}\n.statistic-summary[_ngcontent-%COMP%]   .color-legend-container[_ngcontent-%COMP%] {\n  margin-bottom: 40px;\n}\n.statistic-summary[_ngcontent-%COMP%]   .color-legend-container[_ngcontent-%COMP%]   .color-legend-entry[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  width: 100%;\n}\n.exercise-row-container[_ngcontent-%COMP%]   .control-label[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\n.exercise-row-container[_ngcontent-%COMP%]   .collapsed[_ngcontent-%COMP%] {\n  margin-top: 1rem;\n  border-bottom: 1px solid var(--overview-light-border-color);\n}\n.chevron-position[_ngcontent-%COMP%] {\n  display: inline-block;\n  vertical-align: middle;\n}\n.rotate-icon[_ngcontent-%COMP%] {\n  transition: transform 0.3s ease;\n}\n.rotated[_ngcontent-%COMP%] {\n  transform: rotate(90deg);\n}\n.icon-container[_ngcontent-%COMP%] {\n  display: inline-block;\n  vertical-align: middle;\n  horiz-align: center;\n}\n.course-information[_ngcontent-%COMP%] {\n  padding-top: 29px;\n}\n.course-information[_ngcontent-%COMP%]   .exercise-panel[_ngcontent-%COMP%]   .row.has-exercises[_ngcontent-%COMP%] {\n  cursor: pointer;\n  border-radius: 3px;\n}\n.course-information[_ngcontent-%COMP%]   .exercise-panel[_ngcontent-%COMP%]   .row.has-exercises[_ngcontent-%COMP%]:hover {\n  background-color: var(--overview-light-background-color);\n}\n.course-information[_ngcontent-%COMP%]   .exercise-panel[_ngcontent-%COMP%]   .row.has-exercises[_ngcontent-%COMP%]:hover   .icon[_ngcontent-%COMP%] {\n  color: var(--primary);\n}\n.exercise-divider[_ngcontent-%COMP%] {\n  height: 0;\n  width: 100%;\n  margin: 1rem 0 0.5rem 0;\n  border-top: 1px solid var(--overview-light-border-color);\n}\n.color-indicator[_ngcontent-%COMP%] {\n  height: 20px;\n  width: 20px;\n  background-color: #0f6ab4;\n  position: relative;\n  top: -4px;\n  margin-right: 5px;\n  border-radius: 3px;\n}\ncanvas#complete-chart[_ngcontent-%COMP%] {\n  z-index: 99;\n}\n.dev-button[_ngcontent-%COMP%] {\n  text-align: left;\n  color: white;\n  background-color: #3e8acc;\n  border: none;\n  border-radius: 1px;\n}\n.dev-button[_ngcontent-%COMP%]:hover {\n  background-color: #0f6ab4;\n}\n.dev-button[_ngcontent-%COMP%]:active {\n  box-shadow: 0 2px 0 var(--artemis-dark);\n}\n.dev-button[_ngcontent-%COMP%]:disabled {\n  background-color: gray;\n}\n.btn-primary[_ngcontent-%COMP%], .btn-primary[_ngcontent-%COMP%]:hover, .btn-primary[_ngcontent-%COMP%]:disabled, .btn-info[_ngcontent-%COMP%], .btn-info[_ngcontent-%COMP%]:hover, .btn-success[_ngcontent-%COMP%], .btn-success[_ngcontent-%COMP%]:hover {\n  color: #fff;\n}\n@media (max-width: 768px) {\n  .col-12[_ngcontent-%COMP%] {\n    width: 100% !important;\n  }\n}\n.fadeInIcon[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_fadeIn 0.3s;\n  animation-iteration-count: initial;\n}\n@keyframes _ngcontent-%COMP%_fadeIn {\n  0% {\n    opacity: 0;\n  }\n  50% {\n    opacity: 0.5;\n  }\n  100% {\n    visibility: visible;\n    opacity: 1;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9jb3Vyc2Utb3ZlcnZpZXcuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbkNvdXJzZSBJbmZvIEJhclxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi9cbi50YWItYmFyLWV4ZXJjaXNlLWRldGFpbHMge1xuICAgIGZsZXgtd3JhcDogd3JhcDtcblxuICAgIC8vIG1vdmUgaW5zdHJ1Y3RvciBhY3Rpb25zIG9udG8gdGhlaXIgb3duIGxpbmUgZm9yIHNtYWxsL21lZGl1bSBkZXZpY2VzXG4gICAgLmluc3RydWN0b3ItYWN0aW9ucyB7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBmbGV4LWJhc2lzOiAxMDAlO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICAgIH1cbn1cblxuLmNvdXJzZS1ib2R5LWNvbnRhaW5lciB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4ucmVmcmVzaC1vdmVybGF5IHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgcmlnaHQ6IDA7XG4gICAgYm90dG9tOiAwO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG5cbiAgICBvcGFjaXR5OiAwO1xuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgIHRyYW5zaXRpb246IDAuMXMgZWFzZS1vdXQgb3BhY2l0eTtcblxuICAgICYuYWN0aXZlIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tb3ZlcnZpZXctcmVmcmVzaC1vdmVybGF5LWJnLWNvbG9yKTtcbiAgICAgICAgb3BhY2l0eTogMTtcbiAgICAgICAgcG9pbnRlci1ldmVudHM6IGF1dG87XG4gICAgICAgIHRyYW5zaXRpb246IDAuMnMgZWFzZS1pbiBvcGFjaXR5O1xuICAgIH1cblxuICAgIC5uZy1mYS1pY29uIHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB0b3A6IGNhbGMoNTB2aCAtIDE1MHB4IC0gMi41dmgpO1xuICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1vdmVydmlldy1yZWZyZXNoLW92ZXJsYXktY29sb3IpO1xuICAgIH1cbn1cblxuLmJhY2stYnV0dG9uIHtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbi5jdXJyZW50LXdlZWstcm93IHtcbiAgICA6Om5nLWRlZXAge1xuICAgICAgICA+IGRpdiB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1vdmVydmlldy1saWdodC1wcmltYXJ5LWJhY2tncm91bmQtY29sb3IpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4uc3RhdGlzdGljLXN1bW1hcnkge1xuICAgIG1hcmdpbi10b3A6IDI1cHg7XG5cbiAgICAuY2hhcnQtY29udGFpbmVyIHtcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG5cbiAgICAgICAgLmNoYXJ0LXRleHQge1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgd2lkdGg6IDM1MHB4O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmNvbG9yLWxlZ2VuZC1jb250YWluZXIge1xuICAgICAgICBtYXJnaW4tYm90dG9tOiA0MHB4O1xuXG4gICAgICAgIC5jb2xvci1sZWdlbmQtZW50cnkge1xuICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5leGVyY2lzZS1yb3ctY29udGFpbmVyIHtcbiAgICAuY29udHJvbC1sYWJlbCB7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB9XG5cbiAgICAuY29sbGFwc2VkIHtcbiAgICAgICAgbWFyZ2luLXRvcDogMXJlbTtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLW92ZXJ2aWV3LWxpZ2h0LWJvcmRlci1jb2xvcik7XG4gICAgfVxufVxuXG4uY2hldnJvbi1wb3NpdGlvbiB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG59XG5cbi5yb3RhdGUtaWNvbiB7XG4gICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuM3MgZWFzZTtcbn1cblxuLnJvdGF0ZWQge1xuICAgIHRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbn1cblxuLmljb24tY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICBob3Jpei1hbGlnbjogY2VudGVyO1xufVxuXG4uY291cnNlLWluZm9ybWF0aW9uIHtcbiAgICBwYWRkaW5nLXRvcDogMjlweDtcblxuICAgIC5leGVyY2lzZS1wYW5lbCB7XG4gICAgICAgIC5yb3cuaGFzLWV4ZXJjaXNlcyB7XG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgICAgICAgICAmOmhvdmVyIHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1vdmVydmlldy1saWdodC1iYWNrZ3JvdW5kLWNvbG9yKTtcbiAgICAgICAgICAgICAgICAuaWNvbiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1wcmltYXJ5KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5leGVyY2lzZS1kaXZpZGVyIHtcbiAgICBoZWlnaHQ6IDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luOiAxcmVtIDAgMC41cmVtIDA7XG4gICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkIHZhcigtLW92ZXJ2aWV3LWxpZ2h0LWJvcmRlci1jb2xvcik7XG59XG5cbi5jb2xvci1pbmRpY2F0b3Ige1xuICAgIGhlaWdodDogMjBweDtcbiAgICB3aWR0aDogMjBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMGY2YWI0O1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB0b3A6IC00cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xufVxuXG5jYW52YXMjY29tcGxldGUtY2hhcnQge1xuICAgIHotaW5kZXg6IDk5O1xufVxuXG4uZGV2LWJ1dHRvbiB7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzNlOGFjYztcbiAgICAmOmhvdmVyIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzBmNmFiNDtcbiAgICB9XG4gICAgJjphY3RpdmUge1xuICAgICAgICBib3gtc2hhZG93OiAwIDJweCAwIHZhcigtLWFydGVtaXMtZGFyayk7XG4gICAgfVxuICAgICY6ZGlzYWJsZWQge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmF5O1xuICAgIH1cbiAgICBib3JkZXI6IG5vbmU7XG4gICAgYm9yZGVyLXJhZGl1czogMXB4O1xufVxuXG4vKiBEZWZhdWx0IHRoZSBjb2xvciB0byB3aGl0ZSBldmVuIG9uIGJvb3RzdHJhcCA1ICovXG4uYnRuLXByaW1hcnksXG4uYnRuLXByaW1hcnk6aG92ZXIsXG4uYnRuLXByaW1hcnk6ZGlzYWJsZWQsXG4uYnRuLWluZm8sXG4uYnRuLWluZm86aG92ZXIsXG4uYnRuLXN1Y2Nlc3MsXG4uYnRuLXN1Y2Nlc3M6aG92ZXIge1xuICAgIGNvbG9yOiAjZmZmO1xufVxuXG5AbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcbiAgICAuY29sLTEyIHtcbiAgICAgICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgICB9XG59XG5cbi5mYWRlSW5JY29uIHtcbiAgICAvKiBTdGFydCB0aGUgc2hha2UgYW5pbWF0aW9uIGFuZCBtYWtlIHRoZSBhbmltYXRpb24gbGFzdCBmb3IgMC4zIHNlY29uZHMgKi9cbiAgICBhbmltYXRpb246IGZhZGVJbiAwLjNzO1xuXG4gICAgLyogQW5pbWF0aW9uIG9ubHkgb25jZSAqL1xuICAgIGFuaW1hdGlvbi1pdGVyYXRpb24tY291bnQ6IGluaXRpYWw7XG59XG5cbkBrZXlmcmFtZXMgZmFkZUluIHtcbiAgICAwJSB7XG4gICAgICAgIG9wYWNpdHk6IDA7XG4gICAgfVxuXG4gICAgNTAlIHtcbiAgICAgICAgb3BhY2l0eTogMC41O1xuICAgIH1cblxuICAgIDEwMCUge1xuICAgICAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xuICAgICAgICBvcGFjaXR5OiAxO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFHQSxDQUFBO0FBQ0ksYUFBQTs7QUFHQSxDQUpKLHlCQUlJLENBQUE7QUFDSSxTQUFBO0FBQ0EsY0FBQTtBQUNBLG1CQUFBOztBQUlSLENBQUE7QUFDSSxZQUFBOztBQUdKLENBQUE7QUFDSSxZQUFBO0FBQ0EsT0FBQTtBQUNBLFFBQUE7QUFDQSxTQUFBO0FBQ0EsVUFBQTtBQUNBLFdBQUE7QUFDQSxtQkFBQTtBQUNBLGVBQUE7QUFFQSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxjQUFBLEtBQUEsU0FBQTs7QUFFQSxDQWRKLGVBY0ksQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxjQUFBLEtBQUEsUUFBQTs7QUFHSixDQXJCSixnQkFxQkksQ0FBQTtBQUNJLFlBQUE7QUFDQSxPQUFBLEtBQUEsS0FBQSxFQUFBLE1BQUEsRUFBQTtBQUNBLGFBQUEsV0FBQTtBQUNBLFNBQUEsSUFBQTs7QUFJUixDQUFBO0FBQ0ksVUFBQTs7QUFLSSxDQUFBLGlCQUFBLFVBQUEsRUFBQTtBQUNJLG9CQUFBLElBQUE7O0FBS1osQ0FBQTtBQUNJLGNBQUE7O0FBRUEsQ0FISixrQkFHSSxDQUFBO0FBQ0ksV0FBQTtBQUNBLGVBQUE7QUFDQSxtQkFBQTtBQUNBLGlCQUFBOztBQUVBLENBVFIsa0JBU1EsQ0FOSixnQkFNSSxDQUFBO0FBQ0ksWUFBQTtBQUNBLFNBQUE7O0FBSVIsQ0FmSixrQkFlSSxDQUFBO0FBQ0ksaUJBQUE7O0FBRUEsQ0FsQlIsa0JBa0JRLENBSEosdUJBR0ksQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBO0FBQ0EsU0FBQTs7QUFNUixDQUFBLHVCQUFBLENBQUE7QUFDSSxVQUFBOztBQUdKLENBSkEsdUJBSUEsQ0FBQTtBQUNJLGNBQUE7QUFDQSxpQkFBQSxJQUFBLE1BQUEsSUFBQTs7QUFJUixDQUFBO0FBQ0ksV0FBQTtBQUNBLGtCQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBLFVBQUEsS0FBQTs7QUFHSixDQUFBO0FBQ0ksYUFBQSxPQUFBOztBQUdKLENBQUE7QUFDSSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxlQUFBOztBQUdKLENBQUE7QUFDSSxlQUFBOztBQUdJLENBSlIsbUJBSVEsQ0FBQSxlQUFBLENBQUEsR0FBQSxDQUFBO0FBQ0ksVUFBQTtBQUNBLGlCQUFBOztBQUNBLENBUFosbUJBT1ksQ0FISixlQUdJLENBSEosR0FHSSxDQUhKLGFBR0k7QUFDSSxvQkFBQSxJQUFBOztBQUNBLENBVGhCLG1CQVNnQixDQUxSLGVBS1EsQ0FMUixHQUtRLENBTFIsYUFLUSxPQUFBLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBT3BCLENBQUE7QUFDSSxVQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUEsS0FBQSxFQUFBLE9BQUE7QUFDQSxjQUFBLElBQUEsTUFBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxVQUFBO0FBQ0EsU0FBQTtBQUNBLG9CQUFBO0FBQ0EsWUFBQTtBQUNBLE9BQUE7QUFDQSxnQkFBQTtBQUNBLGlCQUFBOztBQUdKLE1BQUEsQ0FBQTtBQUNJLFdBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUE7QUFDQSxTQUFBO0FBQ0Esb0JBQUE7QUFVQSxVQUFBO0FBQ0EsaUJBQUE7O0FBVkEsQ0FKSixVQUlJO0FBQ0ksb0JBQUE7O0FBRUosQ0FQSixVQU9JO0FBQ0ksY0FBQSxFQUFBLElBQUEsRUFBQSxJQUFBOztBQUVKLENBVkosVUFVSTtBQUNJLG9CQUFBOztBQU9SLENBQUE7QUFBQSxDQUFBLFdBQUE7QUFBQSxDQUFBLFdBQUE7QUFBQSxDQUFBO0FBQUEsQ0FBQSxRQUFBO0FBQUEsQ0FBQTtBQUFBLENBQUEsV0FBQTtBQU9JLFNBQUE7O0FBR0osT0FBQSxDQUFBLFNBQUEsRUFBQTtBQUNJLEdBQUE7QUFDSSxXQUFBOzs7QUFJUixDQUFBO0FBRUksYUFBQSxPQUFBO0FBR0EsNkJBQUE7O0FBR0osV0FOSTtBQU9BO0FBQ0ksYUFBQTs7QUFHSjtBQUNJLGFBQUE7O0FBR0o7QUFDSSxnQkFBQTtBQUNBLGFBQUE7OzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(OrionExerciseDetailsStudentActionsComponent, { className: "OrionExerciseDetailsStudentActionsComponent" });
    })();
  }
});

// src/main/webapp/app/overview/exercise-details/exercise-buttons.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisExerciseButtonsModule;
var init_exercise_buttons_module = __esm({
  "src/main/webapp/app/overview/exercise-details/exercise-buttons.module.ts"() {
    init_shared_module();
    init_orion_module();
    init_feature_toggle_module();
    init_orion_exercise_details_student_actions_component();
    init_exercise_details_student_actions_component();
    init_shared_component_module();
    init_courses_routing_module();
    init_shared_pipes_module();
    ArtemisExerciseButtonsModule = class _ArtemisExerciseButtonsModule {
      static \u0275fac = function ArtemisExerciseButtonsModule_Factory(t) {
        return new (t || _ArtemisExerciseButtonsModule)();
      };
      static \u0275mod = i02.\u0275\u0275defineNgModule({ type: _ArtemisExerciseButtonsModule });
      static \u0275inj = i02.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, ArtemisSharedComponentModule, ArtemisSharedPipesModule, ArtemisCoursesRoutingModule, OrionModule, FeatureToggleModule] });
    };
  }
});

// src/main/webapp/app/grading-system/grading-key-overview/grading-key-overview.module.ts
import { NgModule as NgModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var GradingKeyOverviewModule;
var init_grading_key_overview_module = __esm({
  "src/main/webapp/app/grading-system/grading-key-overview/grading-key-overview.module.ts"() {
    init_shared_module();
    init_grading_key_overview_component();
    init_shared_component_module();
    init_grading_key_table_component();
    GradingKeyOverviewModule = class _GradingKeyOverviewModule {
      static \u0275fac = function GradingKeyOverviewModule_Factory(t) {
        return new (t || _GradingKeyOverviewModule)();
      };
      static \u0275mod = i03.\u0275\u0275defineNgModule({ type: _GradingKeyOverviewModule });
      static \u0275inj = i03.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, ArtemisSharedComponentModule] });
    };
  }
});

// src/main/webapp/app/overview/course-exercises/course-exercises-grouped-by-week.component.ts
import { Component as Component2, Input as Input2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faAngleDown, faAngleUp } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function CourseExercisesGroupedByWeekComponent_Conditional_0_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2);
    i04.\u0275\u0275pipe(3, "artemisTranslate");
    i04.\u0275\u0275pipe(4, "artemisDate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r2 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate1("\n                    ", i04.\u0275\u0275pipeBind2(3, 1, "artemisApp.courseOverview.exerciseList.currentExerciseGroupHeader", i04.\u0275\u0275pureFunction1(6, _c0, i04.\u0275\u0275pipeBind1(4, 4, ctx_r2.nextRelevantExercise.dueDate))), "\n                ");
  }
}
function CourseExercisesGroupedByWeekComponent_Conditional_0_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0);
    i04.\u0275\u0275pipe(1, "artemisTranslate");
  }
  if (rf & 2) {
    i04.\u0275\u0275textInterpolate1("\n                ", i04.\u0275\u0275pipeBind1(1, 1, "artemisApp.courseOverview.exerciseList.currentExerciseGroupHeaderWithoutDueDate"), "\n            ");
  }
}
function CourseExercisesGroupedByWeekComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n    ");
    i04.\u0275\u0275elementStart(1, "div", 1);
    i04.\u0275\u0275text(2, "\n        ");
    i04.\u0275\u0275elementStart(3, "h3", 2);
    i04.\u0275\u0275text(4, "\n            ");
    i04.\u0275\u0275template(5, CourseExercisesGroupedByWeekComponent_Conditional_0_Conditional_5_Template, 6, 8)(6, CourseExercisesGroupedByWeekComponent_Conditional_0_Conditional_6_Template, 2, 3);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n        ");
    i04.\u0275\u0275element(8, "jhi-course-exercise-row", 3);
    i04.\u0275\u0275text(9, "\n        ");
    i04.\u0275\u0275element(10, "div", 4);
    i04.\u0275\u0275text(11, "\n    ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(12, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(5);
    i04.\u0275\u0275conditional(5, ctx_r0.nextRelevantExercise.dueDate ? 5 : 6);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("exercise", ctx_r0.nextRelevantExercise.exercise)("course", ctx_r0.course)("hasGuidedTour", ctx_r0.nextRelevantExercise.exercise === ctx_r0.exerciseForGuidedTour);
  }
}
function CourseExercisesGroupedByWeekComponent_For_4_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2);
    i04.\u0275\u0275pipe(3, "artemisDate");
    i04.\u0275\u0275pipe(4, "artemisDate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const weekKey_r4 = i04.\u0275\u0275nextContext().$implicit;
    const ctx_r9 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate2("\n                        ", i04.\u0275\u0275pipeBind2(3, 2, ctx_r9.exerciseGroups[weekKey_r4].start, "short-date"), " -\n                        ", i04.\u0275\u0275pipeBind2(4, 5, ctx_r9.exerciseGroups[weekKey_r4].end, "short-date"), "\n                    ");
  }
}
function CourseExercisesGroupedByWeekComponent_For_4_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2);
    i04.\u0275\u0275pipe(3, "artemisTranslate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                ");
  }
  if (rf & 2) {
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate1("\n                        ", i04.\u0275\u0275pipeBind1(3, 1, "artemisApp.courseOverview.exerciseList.noDateAssociated"), "\n                    ");
  }
}
function CourseExercisesGroupedByWeekComponent_For_4_Conditional_13_For_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275element(1, "jhi-course-exercise-row", 9);
    i04.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const exercise_r14 = ctx.$implicit;
    const ctx_r13 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("exercise", exercise_r14)("course", ctx_r13.course)("hasGuidedTour", exercise_r14 === ctx_r13.exerciseForGuidedTour);
  }
}
function CourseExercisesGroupedByWeekComponent_For_4_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275repeaterCreate(3, CourseExercisesGroupedByWeekComponent_For_4_Conditional_13_For_4_Template, 3, 3, null, null, i04.\u0275\u0275repeaterTrackByIdentity);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const weekKey_r4 = i04.\u0275\u0275nextContext().$implicit;
    const ctx_r11 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275repeater(ctx_r11.exerciseGroups[weekKey_r4].exercises);
  }
}
function CourseExercisesGroupedByWeekComponent_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n        ");
    i04.\u0275\u0275elementStart(1, "div", 5);
    i04.\u0275\u0275text(2, "\n            ");
    i04.\u0275\u0275elementStart(3, "div", 6);
    i04.\u0275\u0275listener("click", function CourseExercisesGroupedByWeekComponent_For_4_Template_div_click_3_listener() {
      const restoredCtx = i04.\u0275\u0275restoreView(_r21);
      const weekKey_r4 = restoredCtx.$implicit;
      const ctx_r20 = i04.\u0275\u0275nextContext();
      return i04.\u0275\u0275resetView(ctx_r20.exerciseGroups[weekKey_r4].isCollapsed = !ctx_r20.exerciseGroups[weekKey_r4].isCollapsed);
    });
    i04.\u0275\u0275text(4, "\n                ");
    i04.\u0275\u0275element(5, "fa-icon", 7);
    i04.\u0275\u0275text(6, "\n                ");
    i04.\u0275\u0275template(7, CourseExercisesGroupedByWeekComponent_For_4_Conditional_7_Template, 6, 8)(8, CourseExercisesGroupedByWeekComponent_For_4_Conditional_8_Template, 5, 3);
    i04.\u0275\u0275elementStart(9, "span", 8);
    i04.\u0275\u0275text(10);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(11, "\n            ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(12, "\n            ");
    i04.\u0275\u0275template(13, CourseExercisesGroupedByWeekComponent_For_4_Conditional_13_Template, 6, 0);
    i04.\u0275\u0275element(14, "div", 4);
    i04.\u0275\u0275text(15, "\n        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(16, "\n    ");
  }
  if (rf & 2) {
    const weekKey_r4 = ctx.$implicit;
    const ctx_r1 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("ngClass", i04.\u0275\u0275pureFunction1(7, _c1, ctx_r1.exerciseGroups[weekKey_r4] ? ctx_r1.exerciseGroups[weekKey_r4].isCurrentWeek : false));
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275property("icon", ctx_r1.exerciseGroups[weekKey_r4].isCollapsed ? ctx_r1.faAngleDown : ctx_r1.faAngleUp);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275conditional(7, ctx_r1.exerciseGroups[weekKey_r4].start && ctx_r1.exerciseGroups[weekKey_r4].end ? 7 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(8, !ctx_r1.exerciseGroups[weekKey_r4].start || !ctx_r1.exerciseGroups[weekKey_r4].end ? 8 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction1(9, _c2, ctx_r1.exerciseGroups[weekKey_r4].exercises.length));
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275textInterpolate1("\n                    (Exercises: ", ctx_r1.exerciseGroups[weekKey_r4].exercises.length, ")\n                ");
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(13, !ctx_r1.exerciseGroups[weekKey_r4].isCollapsed ? 13 : -1);
  }
}
var _c0, _c1, _c2, WEEK_EXERCISE_GROUP_FORMAT_STRING, CourseExercisesGroupedByWeekComponent;
var init_course_exercises_grouped_by_week_component = __esm({
  "src/main/webapp/app/overview/course-exercises/course-exercises-grouped-by-week.component.ts"() {
    init_exercise_model();
    init_course_exercises_component();
    init_course_model();
    init_exercise_service();
    init_account_service();
    init_exercise_service();
    init_account_service();
    init_translate_directive();
    init_course_exercise_row_component();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    _c0 = (a0) => ({ date: a0 });
    _c1 = (a0) => ({ "text-primary": a0 });
    _c2 = (a0) => ({ total: a0 });
    WEEK_EXERCISE_GROUP_FORMAT_STRING = "YYYY-MM-DD";
    CourseExercisesGroupedByWeekComponent = class _CourseExercisesGroupedByWeekComponent {
      exerciseService;
      accountService;
      translateService;
      Object = Object;
      filteredAndSortedExercises;
      course;
      exerciseForGuidedTour;
      activeFilters;
      sortingAttribute;
      exerciseGroups;
      nextRelevantExercise;
      faAngleUp = faAngleUp;
      faAngleDown = faAngleDown;
      currentUser;
      constructor(exerciseService, accountService, translateService) {
        this.exerciseService = exerciseService;
        this.accountService = accountService;
        this.translateService = translateService;
      }
      ngOnInit() {
        this.accountService.identity().then((user) => {
          this.currentUser = user;
          this.updateNextRelevantExercise();
        });
        this.groupExercises(this.filteredAndSortedExercises);
      }
      ngOnChanges() {
        this.updateNextRelevantExercise();
        this.groupExercises(this.filteredAndSortedExercises);
      }
      isVisibleToStudents(exercise) {
        return !this.activeFilters.has(ExerciseFilter.UNRELEASED) || exercise?.visibleToStudents;
      }
      groupExercises(exercises) {
        const groupedExercises = {};
        const noDueDateKey = this.translateService.instant("artemisApp.courseOverview.exerciseList.noExerciseDate");
        const noDueDateExercises = [];
        exercises?.forEach((exercise) => {
          const dateValue = CourseExercisesComponent.getSortingAttributeFromExercise(exercise, this.sortingAttribute);
          if (!dateValue) {
            noDueDateExercises.push(exercise);
            return;
          }
          const dateIndex = dateValue ? dayjs(dateValue).startOf("week").format(WEEK_EXERCISE_GROUP_FORMAT_STRING) : "NoDate";
          if (!groupedExercises[dateIndex]) {
            groupedExercises[dateIndex] = {
              start: dayjs(dateValue).startOf("week"),
              end: dayjs(dateValue).endOf("week"),
              isCollapsed: dateValue.isBefore(dayjs(), "week"),
              isCurrentWeek: dateValue.isSame(dayjs(), "week"),
              exercises: []
            };
          }
          groupedExercises[dateIndex].exercises.push(exercise);
        });
        if (noDueDateExercises.length) {
          groupedExercises[noDueDateKey] = {
            exercises: noDueDateExercises,
            isCurrentWeek: false,
            isCollapsed: false
          };
        }
        this.exerciseGroups = groupedExercises;
      }
      updateNextRelevantExercise() {
        const nextExercise = this.exerciseService.getNextExerciseForHours(this.course?.exercises?.filter((exercise) => CourseExercisesComponent.fulfillsCurrentFilter(exercise, this.activeFilters)), 12, this.currentUser);
        if (nextExercise) {
          const dueDate = CourseExercisesComponent.exerciseDueDate(nextExercise);
          this.nextRelevantExercise = {
            exercise: nextExercise,
            dueDate
          };
        } else {
          this.nextRelevantExercise = void 0;
        }
      }
      static \u0275fac = function CourseExercisesGroupedByWeekComponent_Factory(t) {
        return new (t || _CourseExercisesGroupedByWeekComponent)(i04.\u0275\u0275directiveInject(ExerciseService), i04.\u0275\u0275directiveInject(AccountService), i04.\u0275\u0275directiveInject(i32.TranslateService));
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _CourseExercisesGroupedByWeekComponent, selectors: [["jhi-course-exercises-grouped-by-week"]], inputs: { filteredAndSortedExercises: "filteredAndSortedExercises", course: "course", exerciseForGuidedTour: "exerciseForGuidedTour", activeFilters: "activeFilters", sortingAttribute: "sortingAttribute" }, features: [i04.\u0275\u0275NgOnChangesFeature], decls: 6, vars: 1, consts: [[1, "guided-tour", "exercise-row-container"], [1, "exercise-row-container", "mb-3"], [1, "text-primary"], ["id", "next-course-exercise-row", 1, "pb-1", 3, "exercise", "course", "hasGuidedTour"], [1, "collapsed"], [1, "mb-3"], [1, "control-label", 3, "ngClass", "click"], [1, "pe-3", 3, "icon"], ["jhiTranslate", "artemisApp.courseOverview.exerciseList.exerciseGroupHeader", 1, "ms-2", 2, "font-weight", "300", 3, "translateValues"], [1, "pb-1", 3, "exercise", "course", "hasGuidedTour"]], template: function CourseExercisesGroupedByWeekComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275template(0, CourseExercisesGroupedByWeekComponent_Conditional_0_Template, 13, 4);
          i04.\u0275\u0275elementStart(1, "div", 0);
          i04.\u0275\u0275text(2, "\n    ");
          i04.\u0275\u0275repeaterCreate(3, CourseExercisesGroupedByWeekComponent_For_4_Template, 17, 11, null, null, i04.\u0275\u0275repeaterTrackByIdentity);
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(5, "\n");
        }
        if (rf & 2) {
          i04.\u0275\u0275conditional(0, ctx.nextRelevantExercise && ctx.isVisibleToStudents(ctx.nextRelevantExercise.exercise) ? 0 : -1);
          i04.\u0275\u0275advance(3);
          i04.\u0275\u0275repeater(ctx.Object.keys(ctx.exerciseGroups));
        }
      }, dependencies: [i4.NgClass, i5.FaIconComponent, TranslateDirective, CourseExerciseRowComponent, ArtemisDatePipe, ArtemisTranslatePipe], styles: ["\n\n.tab-bar-exercise-details[_ngcontent-%COMP%] {\n  flex-wrap: wrap;\n}\n.tab-bar-exercise-details[_ngcontent-%COMP%]   .instructor-actions[_ngcontent-%COMP%] {\n  width: 100%;\n  flex-basis: 100%;\n  justify-content: flex-end;\n}\n.course-body-container[_ngcontent-%COMP%] {\n  position: relative;\n}\n.refresh-overlay[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  display: flex;\n  justify-content: center;\n  align-items: flex-start;\n  opacity: 0;\n  pointer-events: none;\n  transition: 0.1s ease-out opacity;\n}\n.refresh-overlay.active[_ngcontent-%COMP%] {\n  background-color: var(--overview-refresh-overlay-bg-color);\n  opacity: 1;\n  pointer-events: auto;\n  transition: 0.2s ease-in opacity;\n}\n.refresh-overlay[_ngcontent-%COMP%]   .ng-fa-icon[_ngcontent-%COMP%] {\n  position: relative;\n  top: calc(50vh - 150px - 2.5vh);\n  transform: translateY(-50%);\n  color: var(--overview-refresh-overlay-color);\n}\n.back-button[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\n.current-week-row[_ngcontent-%COMP%]     > div {\n  background-color: var(--overview-light-primary-background-color);\n}\n.statistic-summary[_ngcontent-%COMP%] {\n  margin-top: 25px;\n}\n.statistic-summary[_ngcontent-%COMP%]   .chart-container[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: flex-end;\n  margin-bottom: 20px;\n}\n.statistic-summary[_ngcontent-%COMP%]   .chart-container[_ngcontent-%COMP%]   .chart-text[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 350px;\n}\n.statistic-summary[_ngcontent-%COMP%]   .color-legend-container[_ngcontent-%COMP%] {\n  margin-bottom: 40px;\n}\n.statistic-summary[_ngcontent-%COMP%]   .color-legend-container[_ngcontent-%COMP%]   .color-legend-entry[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  width: 100%;\n}\n.exercise-row-container[_ngcontent-%COMP%]   .control-label[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\n.exercise-row-container[_ngcontent-%COMP%]   .collapsed[_ngcontent-%COMP%] {\n  margin-top: 1rem;\n  border-bottom: 1px solid var(--overview-light-border-color);\n}\n.chevron-position[_ngcontent-%COMP%] {\n  display: inline-block;\n  vertical-align: middle;\n}\n.rotate-icon[_ngcontent-%COMP%] {\n  transition: transform 0.3s ease;\n}\n.rotated[_ngcontent-%COMP%] {\n  transform: rotate(90deg);\n}\n.icon-container[_ngcontent-%COMP%] {\n  display: inline-block;\n  vertical-align: middle;\n  horiz-align: center;\n}\n.course-information[_ngcontent-%COMP%] {\n  padding-top: 29px;\n}\n.course-information[_ngcontent-%COMP%]   .exercise-panel[_ngcontent-%COMP%]   .row.has-exercises[_ngcontent-%COMP%] {\n  cursor: pointer;\n  border-radius: 3px;\n}\n.course-information[_ngcontent-%COMP%]   .exercise-panel[_ngcontent-%COMP%]   .row.has-exercises[_ngcontent-%COMP%]:hover {\n  background-color: var(--overview-light-background-color);\n}\n.course-information[_ngcontent-%COMP%]   .exercise-panel[_ngcontent-%COMP%]   .row.has-exercises[_ngcontent-%COMP%]:hover   .icon[_ngcontent-%COMP%] {\n  color: var(--primary);\n}\n.exercise-divider[_ngcontent-%COMP%] {\n  height: 0;\n  width: 100%;\n  margin: 1rem 0 0.5rem 0;\n  border-top: 1px solid var(--overview-light-border-color);\n}\n.color-indicator[_ngcontent-%COMP%] {\n  height: 20px;\n  width: 20px;\n  background-color: #0f6ab4;\n  position: relative;\n  top: -4px;\n  margin-right: 5px;\n  border-radius: 3px;\n}\ncanvas#complete-chart[_ngcontent-%COMP%] {\n  z-index: 99;\n}\n.dev-button[_ngcontent-%COMP%] {\n  text-align: left;\n  color: white;\n  background-color: #3e8acc;\n  border: none;\n  border-radius: 1px;\n}\n.dev-button[_ngcontent-%COMP%]:hover {\n  background-color: #0f6ab4;\n}\n.dev-button[_ngcontent-%COMP%]:active {\n  box-shadow: 0 2px 0 var(--artemis-dark);\n}\n.dev-button[_ngcontent-%COMP%]:disabled {\n  background-color: gray;\n}\n.btn-primary[_ngcontent-%COMP%], .btn-primary[_ngcontent-%COMP%]:hover, .btn-primary[_ngcontent-%COMP%]:disabled, .btn-info[_ngcontent-%COMP%], .btn-info[_ngcontent-%COMP%]:hover, .btn-success[_ngcontent-%COMP%], .btn-success[_ngcontent-%COMP%]:hover {\n  color: #fff;\n}\n@media (max-width: 768px) {\n  .col-12[_ngcontent-%COMP%] {\n    width: 100% !important;\n  }\n}\n.fadeInIcon[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_fadeIn 0.3s;\n  animation-iteration-count: initial;\n}\n@keyframes _ngcontent-%COMP%_fadeIn {\n  0% {\n    opacity: 0;\n  }\n  50% {\n    opacity: 0.5;\n  }\n  100% {\n    visibility: visible;\n    opacity: 1;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9jb3Vyc2Utb3ZlcnZpZXcuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbkNvdXJzZSBJbmZvIEJhclxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi9cbi50YWItYmFyLWV4ZXJjaXNlLWRldGFpbHMge1xuICAgIGZsZXgtd3JhcDogd3JhcDtcblxuICAgIC8vIG1vdmUgaW5zdHJ1Y3RvciBhY3Rpb25zIG9udG8gdGhlaXIgb3duIGxpbmUgZm9yIHNtYWxsL21lZGl1bSBkZXZpY2VzXG4gICAgLmluc3RydWN0b3ItYWN0aW9ucyB7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBmbGV4LWJhc2lzOiAxMDAlO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICAgIH1cbn1cblxuLmNvdXJzZS1ib2R5LWNvbnRhaW5lciB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4ucmVmcmVzaC1vdmVybGF5IHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgcmlnaHQ6IDA7XG4gICAgYm90dG9tOiAwO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG5cbiAgICBvcGFjaXR5OiAwO1xuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgIHRyYW5zaXRpb246IDAuMXMgZWFzZS1vdXQgb3BhY2l0eTtcblxuICAgICYuYWN0aXZlIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tb3ZlcnZpZXctcmVmcmVzaC1vdmVybGF5LWJnLWNvbG9yKTtcbiAgICAgICAgb3BhY2l0eTogMTtcbiAgICAgICAgcG9pbnRlci1ldmVudHM6IGF1dG87XG4gICAgICAgIHRyYW5zaXRpb246IDAuMnMgZWFzZS1pbiBvcGFjaXR5O1xuICAgIH1cblxuICAgIC5uZy1mYS1pY29uIHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB0b3A6IGNhbGMoNTB2aCAtIDE1MHB4IC0gMi41dmgpO1xuICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1vdmVydmlldy1yZWZyZXNoLW92ZXJsYXktY29sb3IpO1xuICAgIH1cbn1cblxuLmJhY2stYnV0dG9uIHtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbi5jdXJyZW50LXdlZWstcm93IHtcbiAgICA6Om5nLWRlZXAge1xuICAgICAgICA+IGRpdiB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1vdmVydmlldy1saWdodC1wcmltYXJ5LWJhY2tncm91bmQtY29sb3IpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4uc3RhdGlzdGljLXN1bW1hcnkge1xuICAgIG1hcmdpbi10b3A6IDI1cHg7XG5cbiAgICAuY2hhcnQtY29udGFpbmVyIHtcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG5cbiAgICAgICAgLmNoYXJ0LXRleHQge1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgd2lkdGg6IDM1MHB4O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmNvbG9yLWxlZ2VuZC1jb250YWluZXIge1xuICAgICAgICBtYXJnaW4tYm90dG9tOiA0MHB4O1xuXG4gICAgICAgIC5jb2xvci1sZWdlbmQtZW50cnkge1xuICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5leGVyY2lzZS1yb3ctY29udGFpbmVyIHtcbiAgICAuY29udHJvbC1sYWJlbCB7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB9XG5cbiAgICAuY29sbGFwc2VkIHtcbiAgICAgICAgbWFyZ2luLXRvcDogMXJlbTtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLW92ZXJ2aWV3LWxpZ2h0LWJvcmRlci1jb2xvcik7XG4gICAgfVxufVxuXG4uY2hldnJvbi1wb3NpdGlvbiB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG59XG5cbi5yb3RhdGUtaWNvbiB7XG4gICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuM3MgZWFzZTtcbn1cblxuLnJvdGF0ZWQge1xuICAgIHRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbn1cblxuLmljb24tY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICBob3Jpei1hbGlnbjogY2VudGVyO1xufVxuXG4uY291cnNlLWluZm9ybWF0aW9uIHtcbiAgICBwYWRkaW5nLXRvcDogMjlweDtcblxuICAgIC5leGVyY2lzZS1wYW5lbCB7XG4gICAgICAgIC5yb3cuaGFzLWV4ZXJjaXNlcyB7XG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgICAgICAgICAmOmhvdmVyIHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1vdmVydmlldy1saWdodC1iYWNrZ3JvdW5kLWNvbG9yKTtcbiAgICAgICAgICAgICAgICAuaWNvbiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1wcmltYXJ5KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5leGVyY2lzZS1kaXZpZGVyIHtcbiAgICBoZWlnaHQ6IDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luOiAxcmVtIDAgMC41cmVtIDA7XG4gICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkIHZhcigtLW92ZXJ2aWV3LWxpZ2h0LWJvcmRlci1jb2xvcik7XG59XG5cbi5jb2xvci1pbmRpY2F0b3Ige1xuICAgIGhlaWdodDogMjBweDtcbiAgICB3aWR0aDogMjBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMGY2YWI0O1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB0b3A6IC00cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xufVxuXG5jYW52YXMjY29tcGxldGUtY2hhcnQge1xuICAgIHotaW5kZXg6IDk5O1xufVxuXG4uZGV2LWJ1dHRvbiB7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzNlOGFjYztcbiAgICAmOmhvdmVyIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzBmNmFiNDtcbiAgICB9XG4gICAgJjphY3RpdmUge1xuICAgICAgICBib3gtc2hhZG93OiAwIDJweCAwIHZhcigtLWFydGVtaXMtZGFyayk7XG4gICAgfVxuICAgICY6ZGlzYWJsZWQge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmF5O1xuICAgIH1cbiAgICBib3JkZXI6IG5vbmU7XG4gICAgYm9yZGVyLXJhZGl1czogMXB4O1xufVxuXG4vKiBEZWZhdWx0IHRoZSBjb2xvciB0byB3aGl0ZSBldmVuIG9uIGJvb3RzdHJhcCA1ICovXG4uYnRuLXByaW1hcnksXG4uYnRuLXByaW1hcnk6aG92ZXIsXG4uYnRuLXByaW1hcnk6ZGlzYWJsZWQsXG4uYnRuLWluZm8sXG4uYnRuLWluZm86aG92ZXIsXG4uYnRuLXN1Y2Nlc3MsXG4uYnRuLXN1Y2Nlc3M6aG92ZXIge1xuICAgIGNvbG9yOiAjZmZmO1xufVxuXG5AbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcbiAgICAuY29sLTEyIHtcbiAgICAgICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgICB9XG59XG5cbi5mYWRlSW5JY29uIHtcbiAgICAvKiBTdGFydCB0aGUgc2hha2UgYW5pbWF0aW9uIGFuZCBtYWtlIHRoZSBhbmltYXRpb24gbGFzdCBmb3IgMC4zIHNlY29uZHMgKi9cbiAgICBhbmltYXRpb246IGZhZGVJbiAwLjNzO1xuXG4gICAgLyogQW5pbWF0aW9uIG9ubHkgb25jZSAqL1xuICAgIGFuaW1hdGlvbi1pdGVyYXRpb24tY291bnQ6IGluaXRpYWw7XG59XG5cbkBrZXlmcmFtZXMgZmFkZUluIHtcbiAgICAwJSB7XG4gICAgICAgIG9wYWNpdHk6IDA7XG4gICAgfVxuXG4gICAgNTAlIHtcbiAgICAgICAgb3BhY2l0eTogMC41O1xuICAgIH1cblxuICAgIDEwMCUge1xuICAgICAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xuICAgICAgICBvcGFjaXR5OiAxO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFHQSxDQUFBO0FBQ0ksYUFBQTs7QUFHQSxDQUpKLHlCQUlJLENBQUE7QUFDSSxTQUFBO0FBQ0EsY0FBQTtBQUNBLG1CQUFBOztBQUlSLENBQUE7QUFDSSxZQUFBOztBQUdKLENBQUE7QUFDSSxZQUFBO0FBQ0EsT0FBQTtBQUNBLFFBQUE7QUFDQSxTQUFBO0FBQ0EsVUFBQTtBQUNBLFdBQUE7QUFDQSxtQkFBQTtBQUNBLGVBQUE7QUFFQSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxjQUFBLEtBQUEsU0FBQTs7QUFFQSxDQWRKLGVBY0ksQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxjQUFBLEtBQUEsUUFBQTs7QUFHSixDQXJCSixnQkFxQkksQ0FBQTtBQUNJLFlBQUE7QUFDQSxPQUFBLEtBQUEsS0FBQSxFQUFBLE1BQUEsRUFBQTtBQUNBLGFBQUEsV0FBQTtBQUNBLFNBQUEsSUFBQTs7QUFJUixDQUFBO0FBQ0ksVUFBQTs7QUFLSSxDQUFBLGlCQUFBLFVBQUEsRUFBQTtBQUNJLG9CQUFBLElBQUE7O0FBS1osQ0FBQTtBQUNJLGNBQUE7O0FBRUEsQ0FISixrQkFHSSxDQUFBO0FBQ0ksV0FBQTtBQUNBLGVBQUE7QUFDQSxtQkFBQTtBQUNBLGlCQUFBOztBQUVBLENBVFIsa0JBU1EsQ0FOSixnQkFNSSxDQUFBO0FBQ0ksWUFBQTtBQUNBLFNBQUE7O0FBSVIsQ0FmSixrQkFlSSxDQUFBO0FBQ0ksaUJBQUE7O0FBRUEsQ0FsQlIsa0JBa0JRLENBSEosdUJBR0ksQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBO0FBQ0EsU0FBQTs7QUFNUixDQUFBLHVCQUFBLENBQUE7QUFDSSxVQUFBOztBQUdKLENBSkEsdUJBSUEsQ0FBQTtBQUNJLGNBQUE7QUFDQSxpQkFBQSxJQUFBLE1BQUEsSUFBQTs7QUFJUixDQUFBO0FBQ0ksV0FBQTtBQUNBLGtCQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBLFVBQUEsS0FBQTs7QUFHSixDQUFBO0FBQ0ksYUFBQSxPQUFBOztBQUdKLENBQUE7QUFDSSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxlQUFBOztBQUdKLENBQUE7QUFDSSxlQUFBOztBQUdJLENBSlIsbUJBSVEsQ0FBQSxlQUFBLENBQUEsR0FBQSxDQUFBO0FBQ0ksVUFBQTtBQUNBLGlCQUFBOztBQUNBLENBUFosbUJBT1ksQ0FISixlQUdJLENBSEosR0FHSSxDQUhKLGFBR0k7QUFDSSxvQkFBQSxJQUFBOztBQUNBLENBVGhCLG1CQVNnQixDQUxSLGVBS1EsQ0FMUixHQUtRLENBTFIsYUFLUSxPQUFBLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBT3BCLENBQUE7QUFDSSxVQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUEsS0FBQSxFQUFBLE9BQUE7QUFDQSxjQUFBLElBQUEsTUFBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxVQUFBO0FBQ0EsU0FBQTtBQUNBLG9CQUFBO0FBQ0EsWUFBQTtBQUNBLE9BQUE7QUFDQSxnQkFBQTtBQUNBLGlCQUFBOztBQUdKLE1BQUEsQ0FBQTtBQUNJLFdBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUE7QUFDQSxTQUFBO0FBQ0Esb0JBQUE7QUFVQSxVQUFBO0FBQ0EsaUJBQUE7O0FBVkEsQ0FKSixVQUlJO0FBQ0ksb0JBQUE7O0FBRUosQ0FQSixVQU9JO0FBQ0ksY0FBQSxFQUFBLElBQUEsRUFBQSxJQUFBOztBQUVKLENBVkosVUFVSTtBQUNJLG9CQUFBOztBQU9SLENBQUE7QUFBQSxDQUFBLFdBQUE7QUFBQSxDQUFBLFdBQUE7QUFBQSxDQUFBO0FBQUEsQ0FBQSxRQUFBO0FBQUEsQ0FBQTtBQUFBLENBQUEsV0FBQTtBQU9JLFNBQUE7O0FBR0osT0FBQSxDQUFBLFNBQUEsRUFBQTtBQUNJLEdBQUE7QUFDSSxXQUFBOzs7QUFJUixDQUFBO0FBRUksYUFBQSxPQUFBO0FBR0EsNkJBQUE7O0FBR0osV0FOSTtBQU9BO0FBQ0ksYUFBQTs7QUFHSjtBQUNJLGFBQUE7O0FBR0o7QUFDSSxnQkFBQTtBQUNBLGFBQUE7OzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(CourseExercisesGroupedByWeekComponent, { className: "CourseExercisesGroupedByWeekComponent" });
    })();
  }
});

// src/main/webapp/app/overview/course-exercises/course-exercises-grouped-by-timeframe.component.ts
import { Component as Component3, Input as Input3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import dayjs2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_.js?v=1d0d9ead";
import { faAngleDown as faAngleDown2, faAngleUp as faAngleUp2, faChevronRight } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { cloneDeep } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function CourseExercisesGroupedByTimeframeComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n    ");
    i05.\u0275\u0275elementStart(1, "div");
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275pipe(3, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n");
  }
  if (rf & 2) {
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate1("\n        ", i05.\u0275\u0275pipeBind1(3, 1, "artemisApp.courseOverview.exerciseList.noExerciseMatchesSearchAndFilters"), "\n    ");
  }
}
function CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_Case_8_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                            ");
    i05.\u0275\u0275elementStart(1, "h3", 6);
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275pipe(3, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate(i05.\u0275\u0275pipeBind1(3, 1, "artemisApp.courseOverview.exerciseList.past"));
  }
}
function CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_Case_9_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                            ");
    i05.\u0275\u0275elementStart(1, "h3", 7);
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275pipe(3, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate(i05.\u0275\u0275pipeBind1(3, 1, "artemisApp.courseOverview.exerciseList.current"));
  }
}
function CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_Case_10_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                            ");
    i05.\u0275\u0275elementStart(1, "h3", 6);
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275pipe(3, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate(i05.\u0275\u0275pipeBind1(3, 1, "artemisApp.courseOverview.exerciseList.future"));
  }
}
function CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_Case_11_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                            ");
    i05.\u0275\u0275elementStart(1, "h3", 6);
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275pipe(3, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate(i05.\u0275\u0275pipeBind1(3, 1, "artemisApp.courseOverview.exerciseList.noDueDate"));
  }
}
function CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_For_17_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                        ");
    i05.\u0275\u0275element(1, "jhi-course-exercise-row", 8);
    i05.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const exercise_r14 = ctx.$implicit;
    const ctx_r13 = i05.\u0275\u0275nextContext(4);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("exercise", exercise_r14)("course", ctx_r13.course)("hasGuidedTour", exercise_r14 === ctx_r13.exerciseForGuidedTour);
  }
}
function CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n                ");
    i05.\u0275\u0275elementStart(1, "div", 1);
    i05.\u0275\u0275listener("click", function CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_Template_div_click_1_listener() {
      i05.\u0275\u0275restoreView(_r21);
      const exerciseGroupKey_r3 = i05.\u0275\u0275nextContext().$implicit;
      const ctx_r19 = i05.\u0275\u0275nextContext(2);
      return i05.\u0275\u0275resetView(ctx_r19.toggleGroupCategoryCollapse(exerciseGroupKey_r3));
    });
    i05.\u0275\u0275text(2, "\n                    ");
    i05.\u0275\u0275elementStart(3, "div", 2);
    i05.\u0275\u0275text(4, "\n                        ");
    i05.\u0275\u0275element(5, "fa-icon", 3);
    i05.\u0275\u0275text(6, "\n                    ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(7, "\n                    ");
    i05.\u0275\u0275template(8, CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_Case_8_Template, 5, 3)(9, CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_Case_9_Template, 5, 3)(10, CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_Case_10_Template, 5, 3)(11, CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_Case_11_Template, 5, 3);
    i05.\u0275\u0275text(12, "\n                ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(13, "\n                ");
    i05.\u0275\u0275elementStart(14, "div", 4);
    i05.\u0275\u0275text(15, "\n                    ");
    i05.\u0275\u0275repeaterCreate(16, CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_For_17_Template, 3, 3, null, null, i05.\u0275\u0275repeaterTrackByIdentity);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(18, "\n                ");
    i05.\u0275\u0275element(19, "div", 5);
    i05.\u0275\u0275text(20, "\n            ");
  }
  if (rf & 2) {
    const exerciseGroupKey_r3 = i05.\u0275\u0275nextContext().$implicit;
    const ctx_r8 = i05.\u0275\u0275nextContext(2);
    let CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_contFlowTmp;
    i05.\u0275\u0275advance(5);
    i05.\u0275\u0275classProp("rotated", !ctx_r8.exerciseGroups[exerciseGroupKey_r3].isCollapsed)("text-primary", exerciseGroupKey_r3 === "current");
    i05.\u0275\u0275property("icon", ctx_r8.faChevronRight);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275conditional(8, (CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_contFlowTmp = exerciseGroupKey_r3) === "past" ? 8 : CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_contFlowTmp === "current" ? 9 : CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_contFlowTmp === "future" ? 10 : CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_contFlowTmp === "noDueDate" ? 11 : -1);
    i05.\u0275\u0275advance(6);
    i05.\u0275\u0275property("ngbCollapse", ctx_r8.exerciseGroups[exerciseGroupKey_r3].isCollapsed);
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275repeater(ctx_r8.exerciseGroups[exerciseGroupKey_r3].exercises);
  }
}
function CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n        ");
    i05.\u0275\u0275elementStart(1, "div", 0);
    i05.\u0275\u0275text(2, "\n            ");
    i05.\u0275\u0275template(3, CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Conditional_3_Template, 21, 7);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n    ");
  }
  if (rf & 2) {
    const exerciseGroupKey_r3 = ctx.$implicit;
    const ctx_r2 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275conditional(3, ctx_r2.exerciseGroups[exerciseGroupKey_r3].exercises.length ? 3 : -1);
  }
}
function CourseExercisesGroupedByTimeframeComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n    ");
    i05.\u0275\u0275repeaterCreate(1, CourseExercisesGroupedByTimeframeComponent_Conditional_1_For_2_Template, 5, 1, null, null, i05.\u0275\u0275repeaterTrackByIdentity);
  }
  if (rf & 2) {
    const ctx_r1 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275repeater(ctx_r1.Object.keys(ctx_r1.exerciseGroups));
  }
}
var DEFAULT_EXPAND_ORDER, DEFAULT_EXERCISE_GROUPS, CourseExercisesGroupedByTimeframeComponent;
var init_course_exercises_grouped_by_timeframe_component = __esm({
  "src/main/webapp/app/overview/course-exercises/course-exercises-grouped-by-timeframe.component.ts"() {
    init_exercise_model();
    init_course_model();
    init_course_exercise_row_component();
    init_artemis_translate_pipe();
    DEFAULT_EXPAND_ORDER = ["current", "future", "noDueDate"];
    DEFAULT_EXERCISE_GROUPS = {
      past: { exercises: [], isCollapsed: true },
      current: { exercises: [], isCollapsed: false },
      future: { exercises: [], isCollapsed: false },
      noDueDate: { exercises: [], isCollapsed: true }
    };
    CourseExercisesGroupedByTimeframeComponent = class _CourseExercisesGroupedByTimeframeComponent {
      Object = Object;
      filteredAndSortedExercises;
      course;
      exerciseForGuidedTour;
      appliedSearchString;
      exerciseGroups;
      searchWasActive = false;
      exerciseGroupsBeforeSearch = cloneDeep(DEFAULT_EXERCISE_GROUPS);
      faAngleUp = faAngleUp2;
      faAngleDown = faAngleDown2;
      faChevronRight = faChevronRight;
      ngOnChanges() {
        this.exerciseGroups = this.groupExercisesByTimeframe();
      }
      toggleGroupCategoryCollapse(exerciseGroupCategoryKey) {
        this.exerciseGroups[exerciseGroupCategoryKey].isCollapsed = !this.exerciseGroups[exerciseGroupCategoryKey].isCollapsed;
      }
      groupExercisesByTimeframe() {
        const updatedExerciseGroups = cloneDeep(DEFAULT_EXERCISE_GROUPS);
        if (!this.filteredAndSortedExercises) {
          return updatedExerciseGroups;
        }
        for (const exercise of this.filteredAndSortedExercises) {
          const exerciseGroup = this.getExerciseGroup(exercise);
          updatedExerciseGroups[exerciseGroup].exercises.push(exercise);
        }
        this.adjustExpandedOrCollapsedStateOfExerciseGroups(updatedExerciseGroups);
        return updatedExerciseGroups;
      }
      expandAllExercisesAndSaveStateBeforeSearch(exerciseGroups) {
        const isAConsecutiveSearchWithAllGroupsExpanded = this.searchWasActive;
        if (!isAConsecutiveSearchWithAllGroupsExpanded) {
          this.exerciseGroupsBeforeSearch = cloneDeep(this.exerciseGroups);
          this.searchWasActive = true;
        }
        Object.entries(exerciseGroups).forEach(([, exerciseGroup]) => {
          exerciseGroup.isCollapsed = false;
        });
      }
      restoreStateBeforeSearch(exerciseGroups) {
        this.searchWasActive = false;
        Object.entries(exerciseGroups).forEach(([exerciseGroupKey, exerciseGroup]) => {
          exerciseGroup.isCollapsed = this.exerciseGroupsBeforeSearch[exerciseGroupKey].isCollapsed;
        });
      }
      keepCurrentCollapsedOrExpandedStateOfExerciseGroups(exerciseGroups) {
        Object.entries(exerciseGroups).forEach(([exerciseGroupKey, exerciseGroup]) => {
          exerciseGroup.isCollapsed = this.exerciseGroups[exerciseGroupKey].isCollapsed;
        });
      }
      makeSureAtLeastOneExerciseGroupIsExpanded(exerciseGroups) {
        const exerciseGroupsWithExercises = Object.entries(exerciseGroups).filter(([, exerciseGroup]) => exerciseGroup.exercises.length > 0);
        const expandedExerciseGroups = exerciseGroupsWithExercises.filter(([, exerciseGroup]) => !exerciseGroup.isCollapsed);
        const atLeastOneExerciseIsExpanded = expandedExerciseGroups.length > 0;
        const expandableGroupsExist = !atLeastOneExerciseIsExpanded && exerciseGroupsWithExercises.length > 0;
        if (!expandableGroupsExist || atLeastOneExerciseIsExpanded) {
          return;
        }
        for (const exerciseGroupKey of DEFAULT_EXPAND_ORDER) {
          const groupToExpand = exerciseGroupsWithExercises.find(([key]) => key === exerciseGroupKey);
          if (groupToExpand) {
            groupToExpand[1].isCollapsed = false;
            break;
          }
        }
      }
      adjustExpandedOrCollapsedStateOfExerciseGroups(exerciseGroups) {
        const isSearchingExercise = this.appliedSearchString;
        if (isSearchingExercise) {
          return this.expandAllExercisesAndSaveStateBeforeSearch(exerciseGroups);
        }
        if (this.searchWasActive) {
          return this.restoreStateBeforeSearch(exerciseGroups);
        }
        const filterIsApplied = this.exerciseGroups;
        if (filterIsApplied) {
          this.keepCurrentCollapsedOrExpandedStateOfExerciseGroups(exerciseGroups);
        }
        this.makeSureAtLeastOneExerciseGroupIsExpanded(exerciseGroups);
      }
      getExerciseGroup(exercise) {
        if (!exercise.dueDate) {
          return "noDueDate";
        }
        const dueDate = dayjs2(exercise.dueDate);
        const now = dayjs2();
        const dueDateIsInThePast = dueDate.isBefore(now);
        if (dueDateIsInThePast) {
          return "past";
        }
        const dueDateIsWithinNextWeek = dueDate.isBefore(now.add(1, "week"));
        if (dueDateIsWithinNextWeek) {
          return "current";
        }
        return "future";
      }
      getDefaultExerciseGroups() {
        return DEFAULT_EXERCISE_GROUPS;
      }
      static \u0275fac = function CourseExercisesGroupedByTimeframeComponent_Factory(t) {
        return new (t || _CourseExercisesGroupedByTimeframeComponent)();
      };
      static \u0275cmp = i05.\u0275\u0275defineComponent({ type: _CourseExercisesGroupedByTimeframeComponent, selectors: [["jhi-course-exercises-grouped-by-timeframe"]], inputs: { filteredAndSortedExercises: "filteredAndSortedExercises", course: "course", exerciseForGuidedTour: "exerciseForGuidedTour", appliedSearchString: "appliedSearchString" }, features: [i05.\u0275\u0275NgOnChangesFeature], decls: 2, vars: 1, consts: [[1, "guided-tour", "exercise-row-container", "mb-3"], [1, "control-label", "d-flex", "align-items-center", 3, "click"], [1, "icon-container", "pe-3"], [1, "rotate-icon", "chevron-position", 3, "icon"], [3, "ngbCollapse"], [1, "collapsed"], [1, "mb-0"], [1, "text-primary", "mb-0"], [1, "pb-1", 3, "exercise", "course", "hasGuidedTour"]], template: function CourseExercisesGroupedByTimeframeComponent_Template(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275template(0, CourseExercisesGroupedByTimeframeComponent_Conditional_0_Template, 5, 3)(1, CourseExercisesGroupedByTimeframeComponent_Conditional_1_Template, 3, 0);
        }
        if (rf & 2) {
          i05.\u0275\u0275conditional(0, !(ctx.filteredAndSortedExercises == null ? null : ctx.filteredAndSortedExercises.length) ? 0 : 1);
        }
      }, dependencies: [i1.NgbCollapse, i2.FaIconComponent, CourseExerciseRowComponent, ArtemisTranslatePipe], styles: ["\n\n.tab-bar-exercise-details[_ngcontent-%COMP%] {\n  flex-wrap: wrap;\n}\n.tab-bar-exercise-details[_ngcontent-%COMP%]   .instructor-actions[_ngcontent-%COMP%] {\n  width: 100%;\n  flex-basis: 100%;\n  justify-content: flex-end;\n}\n.course-body-container[_ngcontent-%COMP%] {\n  position: relative;\n}\n.refresh-overlay[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  display: flex;\n  justify-content: center;\n  align-items: flex-start;\n  opacity: 0;\n  pointer-events: none;\n  transition: 0.1s ease-out opacity;\n}\n.refresh-overlay.active[_ngcontent-%COMP%] {\n  background-color: var(--overview-refresh-overlay-bg-color);\n  opacity: 1;\n  pointer-events: auto;\n  transition: 0.2s ease-in opacity;\n}\n.refresh-overlay[_ngcontent-%COMP%]   .ng-fa-icon[_ngcontent-%COMP%] {\n  position: relative;\n  top: calc(50vh - 150px - 2.5vh);\n  transform: translateY(-50%);\n  color: var(--overview-refresh-overlay-color);\n}\n.back-button[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\n.current-week-row[_ngcontent-%COMP%]     > div {\n  background-color: var(--overview-light-primary-background-color);\n}\n.statistic-summary[_ngcontent-%COMP%] {\n  margin-top: 25px;\n}\n.statistic-summary[_ngcontent-%COMP%]   .chart-container[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: flex-end;\n  margin-bottom: 20px;\n}\n.statistic-summary[_ngcontent-%COMP%]   .chart-container[_ngcontent-%COMP%]   .chart-text[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 350px;\n}\n.statistic-summary[_ngcontent-%COMP%]   .color-legend-container[_ngcontent-%COMP%] {\n  margin-bottom: 40px;\n}\n.statistic-summary[_ngcontent-%COMP%]   .color-legend-container[_ngcontent-%COMP%]   .color-legend-entry[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  width: 100%;\n}\n.exercise-row-container[_ngcontent-%COMP%]   .control-label[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\n.exercise-row-container[_ngcontent-%COMP%]   .collapsed[_ngcontent-%COMP%] {\n  margin-top: 1rem;\n  border-bottom: 1px solid var(--overview-light-border-color);\n}\n.chevron-position[_ngcontent-%COMP%] {\n  display: inline-block;\n  vertical-align: middle;\n}\n.rotate-icon[_ngcontent-%COMP%] {\n  transition: transform 0.3s ease;\n}\n.rotated[_ngcontent-%COMP%] {\n  transform: rotate(90deg);\n}\n.icon-container[_ngcontent-%COMP%] {\n  display: inline-block;\n  vertical-align: middle;\n  horiz-align: center;\n}\n.course-information[_ngcontent-%COMP%] {\n  padding-top: 29px;\n}\n.course-information[_ngcontent-%COMP%]   .exercise-panel[_ngcontent-%COMP%]   .row.has-exercises[_ngcontent-%COMP%] {\n  cursor: pointer;\n  border-radius: 3px;\n}\n.course-information[_ngcontent-%COMP%]   .exercise-panel[_ngcontent-%COMP%]   .row.has-exercises[_ngcontent-%COMP%]:hover {\n  background-color: var(--overview-light-background-color);\n}\n.course-information[_ngcontent-%COMP%]   .exercise-panel[_ngcontent-%COMP%]   .row.has-exercises[_ngcontent-%COMP%]:hover   .icon[_ngcontent-%COMP%] {\n  color: var(--primary);\n}\n.exercise-divider[_ngcontent-%COMP%] {\n  height: 0;\n  width: 100%;\n  margin: 1rem 0 0.5rem 0;\n  border-top: 1px solid var(--overview-light-border-color);\n}\n.color-indicator[_ngcontent-%COMP%] {\n  height: 20px;\n  width: 20px;\n  background-color: #0f6ab4;\n  position: relative;\n  top: -4px;\n  margin-right: 5px;\n  border-radius: 3px;\n}\ncanvas#complete-chart[_ngcontent-%COMP%] {\n  z-index: 99;\n}\n.dev-button[_ngcontent-%COMP%] {\n  text-align: left;\n  color: white;\n  background-color: #3e8acc;\n  border: none;\n  border-radius: 1px;\n}\n.dev-button[_ngcontent-%COMP%]:hover {\n  background-color: #0f6ab4;\n}\n.dev-button[_ngcontent-%COMP%]:active {\n  box-shadow: 0 2px 0 var(--artemis-dark);\n}\n.dev-button[_ngcontent-%COMP%]:disabled {\n  background-color: gray;\n}\n.btn-primary[_ngcontent-%COMP%], .btn-primary[_ngcontent-%COMP%]:hover, .btn-primary[_ngcontent-%COMP%]:disabled, .btn-info[_ngcontent-%COMP%], .btn-info[_ngcontent-%COMP%]:hover, .btn-success[_ngcontent-%COMP%], .btn-success[_ngcontent-%COMP%]:hover {\n  color: #fff;\n}\n@media (max-width: 768px) {\n  .col-12[_ngcontent-%COMP%] {\n    width: 100% !important;\n  }\n}\n.fadeInIcon[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_fadeIn 0.3s;\n  animation-iteration-count: initial;\n}\n@keyframes _ngcontent-%COMP%_fadeIn {\n  0% {\n    opacity: 0;\n  }\n  50% {\n    opacity: 0.5;\n  }\n  100% {\n    visibility: visible;\n    opacity: 1;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9jb3Vyc2Utb3ZlcnZpZXcuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbkNvdXJzZSBJbmZvIEJhclxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi9cbi50YWItYmFyLWV4ZXJjaXNlLWRldGFpbHMge1xuICAgIGZsZXgtd3JhcDogd3JhcDtcblxuICAgIC8vIG1vdmUgaW5zdHJ1Y3RvciBhY3Rpb25zIG9udG8gdGhlaXIgb3duIGxpbmUgZm9yIHNtYWxsL21lZGl1bSBkZXZpY2VzXG4gICAgLmluc3RydWN0b3ItYWN0aW9ucyB7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBmbGV4LWJhc2lzOiAxMDAlO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICAgIH1cbn1cblxuLmNvdXJzZS1ib2R5LWNvbnRhaW5lciB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4ucmVmcmVzaC1vdmVybGF5IHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgcmlnaHQ6IDA7XG4gICAgYm90dG9tOiAwO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG5cbiAgICBvcGFjaXR5OiAwO1xuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgIHRyYW5zaXRpb246IDAuMXMgZWFzZS1vdXQgb3BhY2l0eTtcblxuICAgICYuYWN0aXZlIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tb3ZlcnZpZXctcmVmcmVzaC1vdmVybGF5LWJnLWNvbG9yKTtcbiAgICAgICAgb3BhY2l0eTogMTtcbiAgICAgICAgcG9pbnRlci1ldmVudHM6IGF1dG87XG4gICAgICAgIHRyYW5zaXRpb246IDAuMnMgZWFzZS1pbiBvcGFjaXR5O1xuICAgIH1cblxuICAgIC5uZy1mYS1pY29uIHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB0b3A6IGNhbGMoNTB2aCAtIDE1MHB4IC0gMi41dmgpO1xuICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1vdmVydmlldy1yZWZyZXNoLW92ZXJsYXktY29sb3IpO1xuICAgIH1cbn1cblxuLmJhY2stYnV0dG9uIHtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbi5jdXJyZW50LXdlZWstcm93IHtcbiAgICA6Om5nLWRlZXAge1xuICAgICAgICA+IGRpdiB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1vdmVydmlldy1saWdodC1wcmltYXJ5LWJhY2tncm91bmQtY29sb3IpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4uc3RhdGlzdGljLXN1bW1hcnkge1xuICAgIG1hcmdpbi10b3A6IDI1cHg7XG5cbiAgICAuY2hhcnQtY29udGFpbmVyIHtcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG5cbiAgICAgICAgLmNoYXJ0LXRleHQge1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgd2lkdGg6IDM1MHB4O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmNvbG9yLWxlZ2VuZC1jb250YWluZXIge1xuICAgICAgICBtYXJnaW4tYm90dG9tOiA0MHB4O1xuXG4gICAgICAgIC5jb2xvci1sZWdlbmQtZW50cnkge1xuICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5leGVyY2lzZS1yb3ctY29udGFpbmVyIHtcbiAgICAuY29udHJvbC1sYWJlbCB7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB9XG5cbiAgICAuY29sbGFwc2VkIHtcbiAgICAgICAgbWFyZ2luLXRvcDogMXJlbTtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLW92ZXJ2aWV3LWxpZ2h0LWJvcmRlci1jb2xvcik7XG4gICAgfVxufVxuXG4uY2hldnJvbi1wb3NpdGlvbiB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG59XG5cbi5yb3RhdGUtaWNvbiB7XG4gICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuM3MgZWFzZTtcbn1cblxuLnJvdGF0ZWQge1xuICAgIHRyYW5zZm9ybTogcm90YXRlKDkwZGVnKTtcbn1cblxuLmljb24tY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICBob3Jpei1hbGlnbjogY2VudGVyO1xufVxuXG4uY291cnNlLWluZm9ybWF0aW9uIHtcbiAgICBwYWRkaW5nLXRvcDogMjlweDtcblxuICAgIC5leGVyY2lzZS1wYW5lbCB7XG4gICAgICAgIC5yb3cuaGFzLWV4ZXJjaXNlcyB7XG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgICAgICAgICAmOmhvdmVyIHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1vdmVydmlldy1saWdodC1iYWNrZ3JvdW5kLWNvbG9yKTtcbiAgICAgICAgICAgICAgICAuaWNvbiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1wcmltYXJ5KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5leGVyY2lzZS1kaXZpZGVyIHtcbiAgICBoZWlnaHQ6IDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luOiAxcmVtIDAgMC41cmVtIDA7XG4gICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkIHZhcigtLW92ZXJ2aWV3LWxpZ2h0LWJvcmRlci1jb2xvcik7XG59XG5cbi5jb2xvci1pbmRpY2F0b3Ige1xuICAgIGhlaWdodDogMjBweDtcbiAgICB3aWR0aDogMjBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMGY2YWI0O1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB0b3A6IC00cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xufVxuXG5jYW52YXMjY29tcGxldGUtY2hhcnQge1xuICAgIHotaW5kZXg6IDk5O1xufVxuXG4uZGV2LWJ1dHRvbiB7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzNlOGFjYztcbiAgICAmOmhvdmVyIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzBmNmFiNDtcbiAgICB9XG4gICAgJjphY3RpdmUge1xuICAgICAgICBib3gtc2hhZG93OiAwIDJweCAwIHZhcigtLWFydGVtaXMtZGFyayk7XG4gICAgfVxuICAgICY6ZGlzYWJsZWQge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmF5O1xuICAgIH1cbiAgICBib3JkZXI6IG5vbmU7XG4gICAgYm9yZGVyLXJhZGl1czogMXB4O1xufVxuXG4vKiBEZWZhdWx0IHRoZSBjb2xvciB0byB3aGl0ZSBldmVuIG9uIGJvb3RzdHJhcCA1ICovXG4uYnRuLXByaW1hcnksXG4uYnRuLXByaW1hcnk6aG92ZXIsXG4uYnRuLXByaW1hcnk6ZGlzYWJsZWQsXG4uYnRuLWluZm8sXG4uYnRuLWluZm86aG92ZXIsXG4uYnRuLXN1Y2Nlc3MsXG4uYnRuLXN1Y2Nlc3M6aG92ZXIge1xuICAgIGNvbG9yOiAjZmZmO1xufVxuXG5AbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcbiAgICAuY29sLTEyIHtcbiAgICAgICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgICB9XG59XG5cbi5mYWRlSW5JY29uIHtcbiAgICAvKiBTdGFydCB0aGUgc2hha2UgYW5pbWF0aW9uIGFuZCBtYWtlIHRoZSBhbmltYXRpb24gbGFzdCBmb3IgMC4zIHNlY29uZHMgKi9cbiAgICBhbmltYXRpb246IGZhZGVJbiAwLjNzO1xuXG4gICAgLyogQW5pbWF0aW9uIG9ubHkgb25jZSAqL1xuICAgIGFuaW1hdGlvbi1pdGVyYXRpb24tY291bnQ6IGluaXRpYWw7XG59XG5cbkBrZXlmcmFtZXMgZmFkZUluIHtcbiAgICAwJSB7XG4gICAgICAgIG9wYWNpdHk6IDA7XG4gICAgfVxuXG4gICAgNTAlIHtcbiAgICAgICAgb3BhY2l0eTogMC41O1xuICAgIH1cblxuICAgIDEwMCUge1xuICAgICAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xuICAgICAgICBvcGFjaXR5OiAxO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFHQSxDQUFBO0FBQ0ksYUFBQTs7QUFHQSxDQUpKLHlCQUlJLENBQUE7QUFDSSxTQUFBO0FBQ0EsY0FBQTtBQUNBLG1CQUFBOztBQUlSLENBQUE7QUFDSSxZQUFBOztBQUdKLENBQUE7QUFDSSxZQUFBO0FBQ0EsT0FBQTtBQUNBLFFBQUE7QUFDQSxTQUFBO0FBQ0EsVUFBQTtBQUNBLFdBQUE7QUFDQSxtQkFBQTtBQUNBLGVBQUE7QUFFQSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxjQUFBLEtBQUEsU0FBQTs7QUFFQSxDQWRKLGVBY0ksQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxjQUFBLEtBQUEsUUFBQTs7QUFHSixDQXJCSixnQkFxQkksQ0FBQTtBQUNJLFlBQUE7QUFDQSxPQUFBLEtBQUEsS0FBQSxFQUFBLE1BQUEsRUFBQTtBQUNBLGFBQUEsV0FBQTtBQUNBLFNBQUEsSUFBQTs7QUFJUixDQUFBO0FBQ0ksVUFBQTs7QUFLSSxDQUFBLGlCQUFBLFVBQUEsRUFBQTtBQUNJLG9CQUFBLElBQUE7O0FBS1osQ0FBQTtBQUNJLGNBQUE7O0FBRUEsQ0FISixrQkFHSSxDQUFBO0FBQ0ksV0FBQTtBQUNBLGVBQUE7QUFDQSxtQkFBQTtBQUNBLGlCQUFBOztBQUVBLENBVFIsa0JBU1EsQ0FOSixnQkFNSSxDQUFBO0FBQ0ksWUFBQTtBQUNBLFNBQUE7O0FBSVIsQ0FmSixrQkFlSSxDQUFBO0FBQ0ksaUJBQUE7O0FBRUEsQ0FsQlIsa0JBa0JRLENBSEosdUJBR0ksQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBO0FBQ0EsU0FBQTs7QUFNUixDQUFBLHVCQUFBLENBQUE7QUFDSSxVQUFBOztBQUdKLENBSkEsdUJBSUEsQ0FBQTtBQUNJLGNBQUE7QUFDQSxpQkFBQSxJQUFBLE1BQUEsSUFBQTs7QUFJUixDQUFBO0FBQ0ksV0FBQTtBQUNBLGtCQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBLFVBQUEsS0FBQTs7QUFHSixDQUFBO0FBQ0ksYUFBQSxPQUFBOztBQUdKLENBQUE7QUFDSSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxlQUFBOztBQUdKLENBQUE7QUFDSSxlQUFBOztBQUdJLENBSlIsbUJBSVEsQ0FBQSxlQUFBLENBQUEsR0FBQSxDQUFBO0FBQ0ksVUFBQTtBQUNBLGlCQUFBOztBQUNBLENBUFosbUJBT1ksQ0FISixlQUdJLENBSEosR0FHSSxDQUhKLGFBR0k7QUFDSSxvQkFBQSxJQUFBOztBQUNBLENBVGhCLG1CQVNnQixDQUxSLGVBS1EsQ0FMUixHQUtRLENBTFIsYUFLUSxPQUFBLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBT3BCLENBQUE7QUFDSSxVQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUEsS0FBQSxFQUFBLE9BQUE7QUFDQSxjQUFBLElBQUEsTUFBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxVQUFBO0FBQ0EsU0FBQTtBQUNBLG9CQUFBO0FBQ0EsWUFBQTtBQUNBLE9BQUE7QUFDQSxnQkFBQTtBQUNBLGlCQUFBOztBQUdKLE1BQUEsQ0FBQTtBQUNJLFdBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUE7QUFDQSxTQUFBO0FBQ0Esb0JBQUE7QUFVQSxVQUFBO0FBQ0EsaUJBQUE7O0FBVkEsQ0FKSixVQUlJO0FBQ0ksb0JBQUE7O0FBRUosQ0FQSixVQU9JO0FBQ0ksY0FBQSxFQUFBLElBQUEsRUFBQSxJQUFBOztBQUVKLENBVkosVUFVSTtBQUNJLG9CQUFBOztBQU9SLENBQUE7QUFBQSxDQUFBLFdBQUE7QUFBQSxDQUFBLFdBQUE7QUFBQSxDQUFBO0FBQUEsQ0FBQSxRQUFBO0FBQUEsQ0FBQTtBQUFBLENBQUEsV0FBQTtBQU9JLFNBQUE7O0FBR0osT0FBQSxDQUFBLFNBQUEsRUFBQTtBQUNJLEdBQUE7QUFDSSxXQUFBOzs7QUFJUixDQUFBO0FBRUksYUFBQSxPQUFBO0FBR0EsNkJBQUE7O0FBR0osV0FOSTtBQU9BO0FBQ0ksYUFBQTs7QUFHSjtBQUNJLGFBQUE7O0FBR0o7QUFDSSxnQkFBQTtBQUNBLGFBQUE7OzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(CourseExercisesGroupedByTimeframeComponent, { className: "CourseExercisesGroupedByTimeframeComponent" });
    })();
  }
});

// src/main/webapp/app/overview/course-exercises/course-exercise-row.module.ts
import { NgModule as NgModule3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisCourseExerciseRowModule;
var init_course_exercise_row_module = __esm({
  "src/main/webapp/app/overview/course-exercises/course-exercise-row.module.ts"() {
    init_course_exercise_row_component();
    init_shared_module();
    init_shared_component_module();
    init_shared_pipes_module();
    init_courses_routing_module();
    init_exercise_buttons_module();
    init_exercise_headers_module();
    init_orion_module();
    init_grading_key_overview_module();
    init_submission_result_status_module();
    init_exercise_categories_module();
    init_course_exercises_grouped_by_week_component();
    init_course_exercises_grouped_by_timeframe_component();
    ArtemisCourseExerciseRowModule = class _ArtemisCourseExerciseRowModule {
      static \u0275fac = function ArtemisCourseExerciseRowModule_Factory(t) {
        return new (t || _ArtemisCourseExerciseRowModule)();
      };
      static \u0275mod = i06.\u0275\u0275defineNgModule({ type: _ArtemisCourseExerciseRowModule });
      static \u0275inj = i06.\u0275\u0275defineInjector({ imports: [
        ArtemisSharedModule,
        ArtemisSharedComponentModule,
        ArtemisSharedPipesModule,
        ArtemisCoursesRoutingModule,
        ArtemisExerciseButtonsModule,
        ArtemisHeaderExercisePageWithDetailsModule,
        OrionModule,
        GradingKeyOverviewModule,
        SubmissionResultStatusModule,
        ExerciseCategoriesModule
      ] });
    };
  }
});

export {
  OrionExerciseDetailsStudentActionsComponent,
  init_orion_exercise_details_student_actions_component,
  ArtemisExerciseButtonsModule,
  init_exercise_buttons_module,
  GradingKeyOverviewModule,
  init_grading_key_overview_module,
  CourseExercisesGroupedByWeekComponent,
  init_course_exercises_grouped_by_week_component,
  CourseExercisesGroupedByTimeframeComponent,
  init_course_exercises_grouped_by_timeframe_component,
  ArtemisCourseExerciseRowModule,
  init_course_exercise_row_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvb3Jpb24vcGFydGljaXBhdGlvbi9vcmlvbi1leGVyY2lzZS1kZXRhaWxzLXN0dWRlbnQtYWN0aW9ucy5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL29yaW9uL3BhcnRpY2lwYXRpb24vb3Jpb24tZXhlcmNpc2UtZGV0YWlscy1zdHVkZW50LWFjdGlvbnMuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL292ZXJ2aWV3L2V4ZXJjaXNlLWRldGFpbHMvZXhlcmNpc2UtYnV0dG9ucy5tb2R1bGUudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2dyYWRpbmctc3lzdGVtL2dyYWRpbmcta2V5LW92ZXJ2aWV3L2dyYWRpbmcta2V5LW92ZXJ2aWV3Lm1vZHVsZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvb3ZlcnZpZXcvY291cnNlLWV4ZXJjaXNlcy9jb3Vyc2UtZXhlcmNpc2VzLWdyb3VwZWQtYnktd2Vlay5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL292ZXJ2aWV3L2NvdXJzZS1leGVyY2lzZXMvY291cnNlLWV4ZXJjaXNlcy1ncm91cGVkLWJ5LXdlZWsuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL292ZXJ2aWV3L2NvdXJzZS1leGVyY2lzZXMvY291cnNlLWV4ZXJjaXNlcy1ncm91cGVkLWJ5LXRpbWVmcmFtZS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL292ZXJ2aWV3L2NvdXJzZS1leGVyY2lzZXMvY291cnNlLWV4ZXJjaXNlcy1ncm91cGVkLWJ5LXRpbWVmcmFtZS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvb3ZlcnZpZXcvY291cnNlLWV4ZXJjaXNlcy9jb3Vyc2UtZXhlcmNpc2Utcm93Lm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IEZlYXR1cmVUb2dnbGUgfSBmcm9tICdhcHAvc2hhcmVkL2ZlYXR1cmUtdG9nZ2xlL2ZlYXR1cmUtdG9nZ2xlLnNlcnZpY2UnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9wcm9ncmFtbWluZy1leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlU3R1ZGVudFBhcnRpY2lwYXRpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvcGFydGljaXBhdGlvbi9wcm9ncmFtbWluZy1leGVyY2lzZS1zdHVkZW50LXBhcnRpY2lwYXRpb24ubW9kZWwnO1xuaW1wb3J0IHsgRXhlcmNpc2VWaWV3LCBPcmlvblN0YXRlIH0gZnJvbSAnYXBwL3NoYXJlZC9vcmlvbi9vcmlvbic7XG5pbXBvcnQgeyBPcmlvbkNvbm5lY3RvclNlcnZpY2UgfSBmcm9tICdhcHAvc2hhcmVkL29yaW9uL29yaW9uLWNvbm5lY3Rvci5zZXJ2aWNlJztcbmltcG9ydCB7IE9yaW9uQnVpbGRBbmRUZXN0U2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvb3Jpb24vb3Jpb24tYnVpbGQtYW5kLXRlc3Quc2VydmljZSc7XG5pbXBvcnQgeyBFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLW9yaW9uLWV4ZXJjaXNlLWRldGFpbHMtc3R1ZGVudC1hY3Rpb25zJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vb3Jpb24tZXhlcmNpc2UtZGV0YWlscy1zdHVkZW50LWFjdGlvbnMuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuLi8uLi9vdmVydmlldy9jb3Vyc2Utb3ZlcnZpZXcuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBPcmlvbkV4ZXJjaXNlRGV0YWlsc1N0dWRlbnRBY3Rpb25zQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICByZWFkb25seSBFeGVyY2lzZVZpZXcgPSBFeGVyY2lzZVZpZXc7XG4gICAgb3Jpb25TdGF0ZTogT3Jpb25TdGF0ZTtcbiAgICBGZWF0dXJlVG9nZ2xlID0gRmVhdHVyZVRvZ2dsZTtcblxuICAgIEBJbnB1dCgpIGV4ZXJjaXNlOiBFeGVyY2lzZTtcbiAgICBASW5wdXQoKSBjb3Vyc2VJZDogbnVtYmVyO1xuICAgIEBJbnB1dCgpIHNtYWxsQnV0dG9uczogYm9vbGVhbjtcbiAgICBASW5wdXQoKSBleGFtTW9kZTogYm9vbGVhbjtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIG9yaW9uQ29ubmVjdG9yU2VydmljZTogT3Jpb25Db25uZWN0b3JTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGlkZUJ1aWxkQW5kVGVzdFNlcnZpY2U6IE9yaW9uQnVpbGRBbmRUZXN0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSByb3V0ZTogQWN0aXZhdGVkUm91dGUsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogZ2V0IG9yaW9uU3RhdGUgYW5kIHN1Ym1pdCBjaGFuZ2VzIGlmIHdpdGhJZGVTdWJtaXQgc2V0IGluIHJvdXRlIHF1ZXJ5XG4gICAgICovXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMub3Jpb25Db25uZWN0b3JTZXJ2aWNlLnN0YXRlKCkuc3Vic2NyaWJlKChvcmlvblN0YXRlOiBPcmlvblN0YXRlKSA9PiAodGhpcy5vcmlvblN0YXRlID0gb3Jpb25TdGF0ZSkpO1xuXG4gICAgICAgIHRoaXMucm91dGUucXVlcnlQYXJhbXMuc3Vic2NyaWJlKChwYXJhbXMpID0+IHtcbiAgICAgICAgICAgIGlmIChwYXJhbXNbJ3dpdGhJZGVTdWJtaXQnXSkge1xuICAgICAgICAgICAgICAgIHRoaXMuc3VibWl0Q2hhbmdlcygpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBnZXQgaXNPZmZsaW5lSWRlQWxsb3dlZCgpIHtcbiAgICAgICAgcmV0dXJuICh0aGlzLmV4ZXJjaXNlIGFzIFByb2dyYW1taW5nRXhlcmNpc2UpLmFsbG93T2ZmbGluZUlkZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBJbXBvcnRzIHRoZSBjdXJyZW50IGV4ZXJjaXNlIGluIHRoZSB1c2VyJ3MgSURFIGFuZCB0cmlnZ2VycyB0aGUgb3BlbmluZyBvZiB0aGUgbmV3IHByb2plY3QgaW4gdGhlIElERVxuICAgICAqL1xuICAgIGltcG9ydEludG9JREUoKSB7XG4gICAgICAgIGNvbnN0IHJlcG8gPSAodGhpcy5leGVyY2lzZS5zdHVkZW50UGFydGljaXBhdGlvbnMhWzBdIGFzIFByb2dyYW1taW5nRXhlcmNpc2VTdHVkZW50UGFydGljaXBhdGlvbikucmVwb3NpdG9yeVVyaSE7XG4gICAgICAgIHRoaXMub3Jpb25Db25uZWN0b3JTZXJ2aWNlLmltcG9ydFBhcnRpY2lwYXRpb24ocmVwbywgdGhpcy5leGVyY2lzZSBhcyBQcm9ncmFtbWluZ0V4ZXJjaXNlKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTdWJtaXRzIHRoZSBjaGFuZ2VzIG1hZGUgaW4gdGhlIElERSBieSBzdGFnaW5nIGV2ZXJ5dGhpbmcsIGNvbW1pdHRpbmcgdGhlIGNoYW5nZXMgYW5kIHB1c2hpbmcgdGhlbSB0byBtYXN0ZXIuXG4gICAgICovXG4gICAgc3VibWl0Q2hhbmdlcygpIHtcbiAgICAgICAgdGhpcy5vcmlvbkNvbm5lY3RvclNlcnZpY2Uuc3VibWl0KCk7XG4gICAgICAgIHRoaXMuaWRlQnVpbGRBbmRUZXN0U2VydmljZS5saXN0ZW5PbkJ1aWxkT3V0cHV0QW5kRm9yd2FyZENoYW5nZXModGhpcy5leGVyY2lzZSBhcyBQcm9ncmFtbWluZ0V4ZXJjaXNlKTtcbiAgICB9XG59XG4iLCI8amhpLWV4ZXJjaXNlLWRldGFpbHMtc3R1ZGVudC1hY3Rpb25zIFtleGVyY2lzZV09XCJleGVyY2lzZVwiIFtjb3Vyc2VJZF09XCJjb3Vyc2VJZFwiIFtzbWFsbEJ1dHRvbnNdPVwic21hbGxCdXR0b25zXCIgW2V4YW1Nb2RlXT1cImV4YW1Nb2RlXCI+XG4gICAgPG5nLXRlbXBsYXRlICNvdmVycmlkZUNsb25lT25saW5lRWRpdG9yQnV0dG9uPlxuICAgICAgICBAaWYgKGlzT2ZmbGluZUlkZUFsbG93ZWQgJiYgKG9yaW9uU3RhdGUudmlldyAhPT0gRXhlcmNpc2VWaWV3LlNUVURFTlQgfHwgb3Jpb25TdGF0ZS5vcGVuZWQgIT09IHRoaXMuZXhlcmNpc2UuaWQpKSB7XG4gICAgICAgICAgICA8amhpLWlkZS1idXR0b25cbiAgICAgICAgICAgICAgICBbZmVhdHVyZVRvZ2dsZV09XCJGZWF0dXJlVG9nZ2xlLlByb2dyYW1taW5nRXhlcmNpc2VzXCJcbiAgICAgICAgICAgICAgICAoY2xpY2tIYW5kbGVyKT1cImltcG9ydEludG9JREUoKVwiXG4gICAgICAgICAgICAgICAgW2J1dHRvbkxhYmVsXT1cIidhcnRlbWlzQXBwLmV4ZXJjaXNlQWN0aW9ucy5pbXBvcnRJbnRvSW50ZWxsaUonIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiXG4gICAgICAgICAgICAgICAgW2J1dHRvbkxvYWRpbmddPVwidGhpcy5leGVyY2lzZS5sb2FkaW5nIHx8IG9yaW9uU3RhdGUuY2xvbmluZ1wiXG4gICAgICAgICAgICAgICAgW3NtYWxsQnV0dG9uXT1cInNtYWxsQnV0dG9uc1wiXG4gICAgICAgICAgICA+PC9qaGktaWRlLWJ1dHRvbj5cbiAgICAgICAgfVxuICAgICAgICBAaWYgKGlzT2ZmbGluZUlkZUFsbG93ZWQgJiYgb3Jpb25TdGF0ZS52aWV3ID09PSBFeGVyY2lzZVZpZXcuU1RVREVOVCAmJiBvcmlvblN0YXRlLm9wZW5lZCA9PT0gdGhpcy5leGVyY2lzZS5pZCkge1xuICAgICAgICAgICAgPGpoaS1pZGUtYnV0dG9uXG4gICAgICAgICAgICAgICAgW2ZlYXR1cmVUb2dnbGVdPVwiRmVhdHVyZVRvZ2dsZS5Qcm9ncmFtbWluZ0V4ZXJjaXNlc1wiXG4gICAgICAgICAgICAgICAgKGNsaWNrSGFuZGxlcik9XCJzdWJtaXRDaGFuZ2VzKClcIlxuICAgICAgICAgICAgICAgIGJ1dHRvbkxhYmVsPVwiU3VibWl0XCJcbiAgICAgICAgICAgICAgICBbYnV0dG9uTG9hZGluZ109XCJ0aGlzLmV4ZXJjaXNlLmxvYWRpbmcgfHwgb3Jpb25TdGF0ZS5idWlsZGluZ1wiXG4gICAgICAgICAgICAgICAgW3NtYWxsQnV0dG9uXT1cInNtYWxsQnV0dG9uc1wiXG4gICAgICAgICAgICA+PC9qaGktaWRlLWJ1dHRvbj5cbiAgICAgICAgfVxuICAgIDwvbmctdGVtcGxhdGU+XG48L2poaS1leGVyY2lzZS1kZXRhaWxzLXN0dWRlbnQtYWN0aW9ucz5cbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IE9yaW9uTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9vcmlvbi9vcmlvbi5tb2R1bGUnO1xuaW1wb3J0IHsgRmVhdHVyZVRvZ2dsZU1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvZmVhdHVyZS10b2dnbGUvZmVhdHVyZS10b2dnbGUubW9kdWxlJztcbmltcG9ydCB7IE9yaW9uRXhlcmNpc2VEZXRhaWxzU3R1ZGVudEFjdGlvbnNDb21wb25lbnQgfSBmcm9tICdhcHAvb3Jpb24vcGFydGljaXBhdGlvbi9vcmlvbi1leGVyY2lzZS1kZXRhaWxzLXN0dWRlbnQtYWN0aW9ucy5jb21wb25lbnQnO1xuaW1wb3J0IHsgRXhlcmNpc2VEZXRhaWxzU3R1ZGVudEFjdGlvbnNDb21wb25lbnQgfSBmcm9tICdhcHAvb3ZlcnZpZXcvZXhlcmNpc2UtZGV0YWlscy9leGVyY2lzZS1kZXRhaWxzLXN0dWRlbnQtYWN0aW9ucy5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9zaGFyZWQtY29tcG9uZW50Lm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzQ291cnNlc1JvdXRpbmdNb2R1bGUgfSBmcm9tICdhcHAvb3ZlcnZpZXcvY291cnNlcy1yb3V0aW5nLm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkUGlwZXNNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3BpcGVzL3NoYXJlZC1waXBlcy5tb2R1bGUnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlLCBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlLCBBcnRlbWlzU2hhcmVkUGlwZXNNb2R1bGUsIEFydGVtaXNDb3Vyc2VzUm91dGluZ01vZHVsZSwgT3Jpb25Nb2R1bGUsIEZlYXR1cmVUb2dnbGVNb2R1bGVdLFxuICAgIGRlY2xhcmF0aW9uczogW0V4ZXJjaXNlRGV0YWlsc1N0dWRlbnRBY3Rpb25zQ29tcG9uZW50LCBPcmlvbkV4ZXJjaXNlRGV0YWlsc1N0dWRlbnRBY3Rpb25zQ29tcG9uZW50XSxcbiAgICBleHBvcnRzOiBbRXhlcmNpc2VEZXRhaWxzU3R1ZGVudEFjdGlvbnNDb21wb25lbnQsIE9yaW9uRXhlcmNpc2VEZXRhaWxzU3R1ZGVudEFjdGlvbnNDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBBcnRlbWlzRXhlcmNpc2VCdXR0b25zTW9kdWxlIHt9XG4iLCJpbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IEdyYWRpbmdLZXlPdmVydmlld0NvbXBvbmVudCB9IGZyb20gJ2FwcC9ncmFkaW5nLXN5c3RlbS9ncmFkaW5nLWtleS1vdmVydmlldy9ncmFkaW5nLWtleS1vdmVydmlldy5jb21wb25lbnQnO1xuaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRDb21wb25lbnRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL2NvbXBvbmVudHMvc2hhcmVkLWNvbXBvbmVudC5tb2R1bGUnO1xuaW1wb3J0IHsgR3JhZGluZ0tleVRhYmxlQ29tcG9uZW50IH0gZnJvbSAnYXBwL2dyYWRpbmctc3lzdGVtL2dyYWRpbmcta2V5LW92ZXJ2aWV3L2dyYWRpbmcta2V5L2dyYWRpbmcta2V5LXRhYmxlLmNvbXBvbmVudCc7XG5cbkBOZ01vZHVsZSh7XG4gICAgZGVjbGFyYXRpb25zOiBbR3JhZGluZ0tleU92ZXJ2aWV3Q29tcG9uZW50LCBHcmFkaW5nS2V5VGFibGVDb21wb25lbnRdLFxuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlLCBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlXSxcbiAgICBleHBvcnRzOiBbR3JhZGluZ0tleU92ZXJ2aWV3Q29tcG9uZW50LCBHcmFkaW5nS2V5VGFibGVDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBHcmFkaW5nS2V5T3ZlcnZpZXdNb2R1bGUge31cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uQ2hhbmdlcywgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBDb3Vyc2VFeGVyY2lzZXNDb21wb25lbnQsIEV4ZXJjaXNlRmlsdGVyLCBFeGVyY2lzZVdpdGhEdWVEYXRlLCBTb3J0aW5nQXR0cmlidXRlIH0gZnJvbSAnYXBwL292ZXJ2aWV3L2NvdXJzZS1leGVyY2lzZXMvY291cnNlLWV4ZXJjaXNlcy5jb21wb25lbnQnO1xuaW1wb3J0IHsgQ291cnNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvdXJzZS5tb2RlbCc7XG5pbXBvcnQgeyBmYUFuZ2xlRG93biwgZmFBbmdsZVVwIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IFF1aXpFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L3F1aXotZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgRXhlcmNpc2VTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhlcmNpc2UvZXhlcmNpc2Uuc2VydmljZSc7XG5pbXBvcnQgeyBVc2VyIH0gZnJvbSAnYXBwL2NvcmUvdXNlci91c2VyLm1vZGVsJztcbmltcG9ydCB7IEFjY291bnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvYXV0aC9hY2NvdW50LnNlcnZpY2UnO1xuaW1wb3J0IGRheWpzIGZyb20gJ2RheWpzL2VzbSc7XG5pbXBvcnQgeyBUcmFuc2xhdGVTZXJ2aWNlIH0gZnJvbSAnQG5neC10cmFuc2xhdGUvY29yZSc7XG5cbnR5cGUgR3JvdXBlZEV4ZXJjaXNlc0J5V2VlayA9IFJlY29yZDxcbiAgICBzdHJpbmcsXG4gICAge1xuICAgICAgICBleGVyY2lzZXM6IEV4ZXJjaXNlW107XG4gICAgICAgIGlzQ3VycmVudFdlZWs6IGJvb2xlYW47XG4gICAgICAgIGlzQ29sbGFwc2VkOiBib29sZWFuO1xuICAgICAgICBzdGFydD86IGRheWpzLkRheWpzO1xuICAgICAgICBlbmQ/OiBkYXlqcy5EYXlqcztcbiAgICB9XG4+O1xuXG5leHBvcnQgY29uc3QgV0VFS19FWEVSQ0lTRV9HUk9VUF9GT1JNQVRfU1RSSU5HID0gJ1lZWVktTU0tREQnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1jb3Vyc2UtZXhlcmNpc2VzLWdyb3VwZWQtYnktd2VlaycsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2NvdXJzZS1leGVyY2lzZXMtZ3JvdXBlZC1ieS13ZWVrLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi4vY291cnNlLW92ZXJ2aWV3LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgQ291cnNlRXhlcmNpc2VzR3JvdXBlZEJ5V2Vla0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcbiAgICBwcm90ZWN0ZWQgcmVhZG9ubHkgT2JqZWN0ID0gT2JqZWN0O1xuXG4gICAgQElucHV0KCkgZmlsdGVyZWRBbmRTb3J0ZWRFeGVyY2lzZXM/OiBFeGVyY2lzZVtdO1xuICAgIEBJbnB1dCgpIGNvdXJzZTogQ291cnNlO1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlRm9yR3VpZGVkVG91cj86IEV4ZXJjaXNlO1xuICAgIEBJbnB1dCgpIGFjdGl2ZUZpbHRlcnM6IFNldDxFeGVyY2lzZUZpbHRlcj47XG4gICAgQElucHV0KCkgc29ydGluZ0F0dHJpYnV0ZTogU29ydGluZ0F0dHJpYnV0ZTtcblxuICAgIGV4ZXJjaXNlR3JvdXBzOiBHcm91cGVkRXhlcmNpc2VzQnlXZWVrO1xuICAgIG5leHRSZWxldmFudEV4ZXJjaXNlPzogRXhlcmNpc2VXaXRoRHVlRGF0ZTtcblxuICAgIGZhQW5nbGVVcCA9IGZhQW5nbGVVcDtcbiAgICBmYUFuZ2xlRG93biA9IGZhQW5nbGVEb3duO1xuXG4gICAgcHJpdmF0ZSBjdXJyZW50VXNlcj86IFVzZXI7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBleGVyY2lzZVNlcnZpY2U6IEV4ZXJjaXNlU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBhY2NvdW50U2VydmljZTogQWNjb3VudFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgdHJhbnNsYXRlU2VydmljZTogVHJhbnNsYXRlU2VydmljZSxcbiAgICApIHt9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5hY2NvdW50U2VydmljZS5pZGVudGl0eSgpLnRoZW4oKHVzZXIpID0+IHtcbiAgICAgICAgICAgIHRoaXMuY3VycmVudFVzZXIgPSB1c2VyO1xuICAgICAgICAgICAgdGhpcy51cGRhdGVOZXh0UmVsZXZhbnRFeGVyY2lzZSgpO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLmdyb3VwRXhlcmNpc2VzKHRoaXMuZmlsdGVyZWRBbmRTb3J0ZWRFeGVyY2lzZXMpO1xuICAgIH1cblxuICAgIG5nT25DaGFuZ2VzKCkge1xuICAgICAgICB0aGlzLnVwZGF0ZU5leHRSZWxldmFudEV4ZXJjaXNlKCk7XG4gICAgICAgIHRoaXMuZ3JvdXBFeGVyY2lzZXModGhpcy5maWx0ZXJlZEFuZFNvcnRlZEV4ZXJjaXNlcyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2tzIHdoZXRoZXIgYW4gZXhlcmNpc2UgaXMgdmlzaWJsZSB0byBzdHVkZW50cyBvciBub3RcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2UgVGhlIGV4ZXJjaXNlIHdoaWNoIHNob3VsZCBiZSBjaGVja2VkXG4gICAgICovXG4gICAgaXNWaXNpYmxlVG9TdHVkZW50cyhleGVyY2lzZTogRXhlcmNpc2UpOiBib29sZWFuIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuICF0aGlzLmFjdGl2ZUZpbHRlcnMuaGFzKEV4ZXJjaXNlRmlsdGVyLlVOUkVMRUFTRUQpIHx8IChleGVyY2lzZSBhcyBRdWl6RXhlcmNpc2UpPy52aXNpYmxlVG9TdHVkZW50cztcbiAgICB9XG5cbiAgICBwcml2YXRlIGdyb3VwRXhlcmNpc2VzKGV4ZXJjaXNlcz86IEV4ZXJjaXNlW10pIHtcbiAgICAgICAgY29uc3QgZ3JvdXBlZEV4ZXJjaXNlczogR3JvdXBlZEV4ZXJjaXNlc0J5V2VlayA9IHt9O1xuICAgICAgICBjb25zdCBub0R1ZURhdGVLZXkgPSB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnYXJ0ZW1pc0FwcC5jb3Vyc2VPdmVydmlldy5leGVyY2lzZUxpc3Qubm9FeGVyY2lzZURhdGUnKTtcbiAgICAgICAgY29uc3Qgbm9EdWVEYXRlRXhlcmNpc2VzOiBFeGVyY2lzZVtdID0gW107XG5cbiAgICAgICAgZXhlcmNpc2VzPy5mb3JFYWNoKChleGVyY2lzZSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgZGF0ZVZhbHVlID0gQ291cnNlRXhlcmNpc2VzQ29tcG9uZW50LmdldFNvcnRpbmdBdHRyaWJ1dGVGcm9tRXhlcmNpc2UoZXhlcmNpc2UsIHRoaXMuc29ydGluZ0F0dHJpYnV0ZSk7XG4gICAgICAgICAgICBpZiAoIWRhdGVWYWx1ZSkge1xuICAgICAgICAgICAgICAgIG5vRHVlRGF0ZUV4ZXJjaXNlcy5wdXNoKGV4ZXJjaXNlKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBkYXRlSW5kZXggPSBkYXRlVmFsdWUgPyBkYXlqcyhkYXRlVmFsdWUpLnN0YXJ0T2YoJ3dlZWsnKS5mb3JtYXQoV0VFS19FWEVSQ0lTRV9HUk9VUF9GT1JNQVRfU1RSSU5HKSA6ICdOb0RhdGUnO1xuXG4gICAgICAgICAgICBpZiAoIWdyb3VwZWRFeGVyY2lzZXNbZGF0ZUluZGV4XSkge1xuICAgICAgICAgICAgICAgIGdyb3VwZWRFeGVyY2lzZXNbZGF0ZUluZGV4XSA9IHtcbiAgICAgICAgICAgICAgICAgICAgc3RhcnQ6IGRheWpzKGRhdGVWYWx1ZSkuc3RhcnRPZignd2VlaycpLFxuICAgICAgICAgICAgICAgICAgICBlbmQ6IGRheWpzKGRhdGVWYWx1ZSkuZW5kT2YoJ3dlZWsnKSxcbiAgICAgICAgICAgICAgICAgICAgaXNDb2xsYXBzZWQ6IGRhdGVWYWx1ZS5pc0JlZm9yZShkYXlqcygpLCAnd2VlaycpLFxuICAgICAgICAgICAgICAgICAgICBpc0N1cnJlbnRXZWVrOiBkYXRlVmFsdWUuaXNTYW1lKGRheWpzKCksICd3ZWVrJyksXG4gICAgICAgICAgICAgICAgICAgIGV4ZXJjaXNlczogW10sXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZ3JvdXBlZEV4ZXJjaXNlc1tkYXRlSW5kZXhdLmV4ZXJjaXNlcy5wdXNoKGV4ZXJjaXNlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gRXhlcmNpc2VzIHdpdGhvdXQgZHVlIGRhdGUgc2hhbGwgYWx3YXlzIGJlIGRpc3BsYXllZCBhdCB0aGUgYm90dG9tXG4gICAgICAgIGlmIChub0R1ZURhdGVFeGVyY2lzZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICBncm91cGVkRXhlcmNpc2VzW25vRHVlRGF0ZUtleV0gPSB7XG4gICAgICAgICAgICAgICAgZXhlcmNpc2VzOiBub0R1ZURhdGVFeGVyY2lzZXMsXG4gICAgICAgICAgICAgICAgaXNDdXJyZW50V2VlazogZmFsc2UsXG4gICAgICAgICAgICAgICAgaXNDb2xsYXBzZWQ6IGZhbHNlLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuZXhlcmNpc2VHcm91cHMgPSBncm91cGVkRXhlcmNpc2VzO1xuICAgIH1cblxuICAgIHByaXZhdGUgdXBkYXRlTmV4dFJlbGV2YW50RXhlcmNpc2UoKSB7XG4gICAgICAgIGNvbnN0IG5leHRFeGVyY2lzZSA9IHRoaXMuZXhlcmNpc2VTZXJ2aWNlLmdldE5leHRFeGVyY2lzZUZvckhvdXJzKFxuICAgICAgICAgICAgdGhpcy5jb3Vyc2U/LmV4ZXJjaXNlcz8uZmlsdGVyKChleGVyY2lzZSkgPT4gQ291cnNlRXhlcmNpc2VzQ29tcG9uZW50LmZ1bGZpbGxzQ3VycmVudEZpbHRlcihleGVyY2lzZSwgdGhpcy5hY3RpdmVGaWx0ZXJzKSksXG4gICAgICAgICAgICAxMixcbiAgICAgICAgICAgIHRoaXMuY3VycmVudFVzZXIsXG4gICAgICAgICk7XG4gICAgICAgIGlmIChuZXh0RXhlcmNpc2UpIHtcbiAgICAgICAgICAgIGNvbnN0IGR1ZURhdGUgPSBDb3Vyc2VFeGVyY2lzZXNDb21wb25lbnQuZXhlcmNpc2VEdWVEYXRlKG5leHRFeGVyY2lzZSk7XG4gICAgICAgICAgICB0aGlzLm5leHRSZWxldmFudEV4ZXJjaXNlID0ge1xuICAgICAgICAgICAgICAgIGV4ZXJjaXNlOiBuZXh0RXhlcmNpc2UsXG4gICAgICAgICAgICAgICAgZHVlRGF0ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLm5leHRSZWxldmFudEV4ZXJjaXNlID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiQGlmIChuZXh0UmVsZXZhbnRFeGVyY2lzZSAmJiBpc1Zpc2libGVUb1N0dWRlbnRzKG5leHRSZWxldmFudEV4ZXJjaXNlLmV4ZXJjaXNlKSkge1xuICAgIDxkaXYgY2xhc3M9XCJleGVyY2lzZS1yb3ctY29udGFpbmVyIG1iLTNcIj5cbiAgICAgICAgPGgzIGNsYXNzPVwidGV4dC1wcmltYXJ5XCI+XG4gICAgICAgICAgICBAaWYgKG5leHRSZWxldmFudEV4ZXJjaXNlIS5kdWVEYXRlKSB7XG4gICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlTGlzdC5jdXJyZW50RXhlcmNpc2VHcm91cEhlYWRlcicgfCBhcnRlbWlzVHJhbnNsYXRlOiB7IGRhdGU6IG5leHRSZWxldmFudEV4ZXJjaXNlLmR1ZURhdGUgfCBhcnRlbWlzRGF0ZSB9IH19XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgfSBAZWxzZSB7XG4gICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VMaXN0LmN1cnJlbnRFeGVyY2lzZUdyb3VwSGVhZGVyV2l0aG91dER1ZURhdGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgfVxuICAgICAgICA8L2gzPlxuICAgICAgICA8amhpLWNvdXJzZS1leGVyY2lzZS1yb3dcbiAgICAgICAgICAgIGNsYXNzPVwicGItMVwiXG4gICAgICAgICAgICBpZD1cIm5leHQtY291cnNlLWV4ZXJjaXNlLXJvd1wiXG4gICAgICAgICAgICBbZXhlcmNpc2VdPVwibmV4dFJlbGV2YW50RXhlcmNpc2UhLmV4ZXJjaXNlXCJcbiAgICAgICAgICAgIFtjb3Vyc2VdPVwiY291cnNlXCJcbiAgICAgICAgICAgIFtoYXNHdWlkZWRUb3VyXT1cIm5leHRSZWxldmFudEV4ZXJjaXNlIS5leGVyY2lzZSA9PT0gZXhlcmNpc2VGb3JHdWlkZWRUb3VyXCJcbiAgICAgICAgLz5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNvbGxhcHNlZFwiPjwvZGl2PlxuICAgIDwvZGl2PlxufVxuPGRpdiBjbGFzcz1cImd1aWRlZC10b3VyIGV4ZXJjaXNlLXJvdy1jb250YWluZXJcIj5cbiAgICBAZm9yICh3ZWVrS2V5IG9mIE9iamVjdC5rZXlzKGV4ZXJjaXNlR3JvdXBzKTsgdHJhY2sgd2Vla0tleSkge1xuICAgICAgICA8ZGl2IGNsYXNzPVwibWItM1wiPlxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiY29udHJvbC1sYWJlbFwiXG4gICAgICAgICAgICAgICAgW25nQ2xhc3NdPVwieyAndGV4dC1wcmltYXJ5JzogZXhlcmNpc2VHcm91cHNbd2Vla0tleV0gPyBleGVyY2lzZUdyb3Vwc1t3ZWVrS2V5XS5pc0N1cnJlbnRXZWVrIDogZmFsc2UgfVwiXG4gICAgICAgICAgICAgICAgKGNsaWNrKT1cImV4ZXJjaXNlR3JvdXBzW3dlZWtLZXldLmlzQ29sbGFwc2VkID0gIWV4ZXJjaXNlR3JvdXBzW3dlZWtLZXldLmlzQ29sbGFwc2VkXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZmEtaWNvbiBjbGFzcz1cInBlLTNcIiBbaWNvbl09XCJleGVyY2lzZUdyb3Vwc1t3ZWVrS2V5XS5pc0NvbGxhcHNlZCA/IGZhQW5nbGVEb3duIDogZmFBbmdsZVVwXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2VHcm91cHNbd2Vla0tleV0uc3RhcnQgJiYgZXhlcmNpc2VHcm91cHNbd2Vla0tleV0uZW5kKSB7XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAge3sgZXhlcmNpc2VHcm91cHNbd2Vla0tleV0uc3RhcnQgfCBhcnRlbWlzRGF0ZTogJ3Nob3J0LWRhdGUnIH19IC1cbiAgICAgICAgICAgICAgICAgICAgICAgIHt7IGV4ZXJjaXNlR3JvdXBzW3dlZWtLZXldLmVuZCB8IGFydGVtaXNEYXRlOiAnc2hvcnQtZGF0ZScgfX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKCFleGVyY2lzZUdyb3Vwc1t3ZWVrS2V5XS5zdGFydCB8fCAhZXhlcmNpc2VHcm91cHNbd2Vla0tleV0uZW5kKSB7XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VMaXN0Lm5vRGF0ZUFzc29jaWF0ZWQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwibXMtMlwiXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPVwiZm9udC13ZWlnaHQ6IDMwMFwiXG4gICAgICAgICAgICAgICAgICAgIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VMaXN0LmV4ZXJjaXNlR3JvdXBIZWFkZXJcIlxuICAgICAgICAgICAgICAgICAgICBbdHJhbnNsYXRlVmFsdWVzXT1cInsgdG90YWw6IGV4ZXJjaXNlR3JvdXBzW3dlZWtLZXldLmV4ZXJjaXNlcy5sZW5ndGggfVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAoRXhlcmNpc2VzOiB7eyBleGVyY2lzZUdyb3Vwc1t3ZWVrS2V5XS5leGVyY2lzZXMubGVuZ3RoIH19KVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgQGlmICghZXhlcmNpc2VHcm91cHNbd2Vla0tleV0uaXNDb2xsYXBzZWQpIHtcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICBAZm9yIChleGVyY2lzZSBvZiBleGVyY2lzZUdyb3Vwc1t3ZWVrS2V5XS5leGVyY2lzZXM7IHRyYWNrIGV4ZXJjaXNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8amhpLWNvdXJzZS1leGVyY2lzZS1yb3cgY2xhc3M9XCJwYi0xXCIgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCIgW2NvdXJzZV09XCJjb3Vyc2VcIiBbaGFzR3VpZGVkVG91cl09XCJleGVyY2lzZSA9PT0gZXhlcmNpc2VGb3JHdWlkZWRUb3VyXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbGxhcHNlZFwiPjwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG48L2Rpdj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgQ291cnNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvdXJzZS5tb2RlbCc7XG5pbXBvcnQgZGF5anMgZnJvbSAnZGF5anMvZXNtLyc7XG5pbXBvcnQgeyBmYUFuZ2xlRG93biwgZmFBbmdsZVVwLCBmYUNoZXZyb25SaWdodCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBjbG9uZURlZXAgfSBmcm9tICdsb2Rhc2gtZXMnO1xuXG50eXBlIEV4ZXJjaXNlR3JvdXBDYXRlZ29yeSA9ICdwYXN0JyB8ICdjdXJyZW50JyB8ICdmdXR1cmUnIHwgJ25vRHVlRGF0ZSc7XG5cbi8qKlxuICoge0BsaW5rIEV4ZXJjaXNlR3JvdXBDYXRlZ29yeSNwYXN0fSBpcyBhbHdheXMgY29sbGFwc2VkIGJ5IGRlZmF1bHRcbiAqL1xuY29uc3QgREVGQVVMVF9FWFBBTkRfT1JERVI6IEV4ZXJjaXNlR3JvdXBDYXRlZ29yeVtdID0gWydjdXJyZW50JywgJ2Z1dHVyZScsICdub0R1ZURhdGUnXTtcblxudHlwZSBFeGVyY2lzZUdyb3VwcyA9IFJlY29yZDxFeGVyY2lzZUdyb3VwQ2F0ZWdvcnksIHsgZXhlcmNpc2VzOiBFeGVyY2lzZVtdOyBpc0NvbGxhcHNlZDogYm9vbGVhbiB9PjtcblxuY29uc3QgREVGQVVMVF9FWEVSQ0lTRV9HUk9VUFMgPSB7XG4gICAgcGFzdDogeyBleGVyY2lzZXM6IFtdLCBpc0NvbGxhcHNlZDogdHJ1ZSB9LFxuICAgIGN1cnJlbnQ6IHsgZXhlcmNpc2VzOiBbXSwgaXNDb2xsYXBzZWQ6IGZhbHNlIH0sXG4gICAgZnV0dXJlOiB7IGV4ZXJjaXNlczogW10sIGlzQ29sbGFwc2VkOiBmYWxzZSB9LFxuICAgIG5vRHVlRGF0ZTogeyBleGVyY2lzZXM6IFtdLCBpc0NvbGxhcHNlZDogdHJ1ZSB9LFxufTtcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktY291cnNlLWV4ZXJjaXNlcy1ncm91cGVkLWJ5LXRpbWVmcmFtZScsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2NvdXJzZS1leGVyY2lzZXMtZ3JvdXBlZC1ieS10aW1lZnJhbWUuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuLi9jb3Vyc2Utb3ZlcnZpZXcuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBDb3Vyc2VFeGVyY2lzZXNHcm91cGVkQnlUaW1lZnJhbWVDb21wb25lbnQgaW1wbGVtZW50cyBPbkNoYW5nZXMge1xuICAgIHByb3RlY3RlZCByZWFkb25seSBPYmplY3QgPSBPYmplY3Q7XG5cbiAgICBASW5wdXQoKSBmaWx0ZXJlZEFuZFNvcnRlZEV4ZXJjaXNlcz86IEV4ZXJjaXNlW107XG4gICAgQElucHV0KCkgY291cnNlPzogQ291cnNlO1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlRm9yR3VpZGVkVG91cj86IEV4ZXJjaXNlO1xuICAgIEBJbnB1dCgpIGFwcGxpZWRTZWFyY2hTdHJpbmc/OiBzdHJpbmc7XG5cbiAgICBleGVyY2lzZUdyb3VwczogRXhlcmNpc2VHcm91cHM7XG5cbiAgICBzZWFyY2hXYXNBY3RpdmU6IGJvb2xlYW4gPSBmYWxzZTtcbiAgICBleGVyY2lzZUdyb3Vwc0JlZm9yZVNlYXJjaDogRXhlcmNpc2VHcm91cHMgPSBjbG9uZURlZXAoREVGQVVMVF9FWEVSQ0lTRV9HUk9VUFMpO1xuXG4gICAgZmFBbmdsZVVwID0gZmFBbmdsZVVwO1xuICAgIGZhQW5nbGVEb3duID0gZmFBbmdsZURvd247XG4gICAgZmFDaGV2cm9uUmlnaHQgPSBmYUNoZXZyb25SaWdodDtcblxuICAgIG5nT25DaGFuZ2VzKCkge1xuICAgICAgICB0aGlzLmV4ZXJjaXNlR3JvdXBzID0gdGhpcy5ncm91cEV4ZXJjaXNlc0J5VGltZWZyYW1lKCk7XG4gICAgfVxuXG4gICAgdG9nZ2xlR3JvdXBDYXRlZ29yeUNvbGxhcHNlKGV4ZXJjaXNlR3JvdXBDYXRlZ29yeUtleTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuZXhlcmNpc2VHcm91cHNbZXhlcmNpc2VHcm91cENhdGVnb3J5S2V5XS5pc0NvbGxhcHNlZCA9ICF0aGlzLmV4ZXJjaXNlR3JvdXBzW2V4ZXJjaXNlR3JvdXBDYXRlZ29yeUtleV0uaXNDb2xsYXBzZWQ7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBncm91cEV4ZXJjaXNlc0J5VGltZWZyYW1lKCk6IEV4ZXJjaXNlR3JvdXBzIHtcbiAgICAgICAgY29uc3QgdXBkYXRlZEV4ZXJjaXNlR3JvdXBzOiBFeGVyY2lzZUdyb3VwcyA9IGNsb25lRGVlcChERUZBVUxUX0VYRVJDSVNFX0dST1VQUyk7XG5cbiAgICAgICAgaWYgKCF0aGlzLmZpbHRlcmVkQW5kU29ydGVkRXhlcmNpc2VzKSB7XG4gICAgICAgICAgICByZXR1cm4gdXBkYXRlZEV4ZXJjaXNlR3JvdXBzO1xuICAgICAgICB9XG5cbiAgICAgICAgZm9yIChjb25zdCBleGVyY2lzZSBvZiB0aGlzLmZpbHRlcmVkQW5kU29ydGVkRXhlcmNpc2VzKSB7XG4gICAgICAgICAgICBjb25zdCBleGVyY2lzZUdyb3VwID0gdGhpcy5nZXRFeGVyY2lzZUdyb3VwKGV4ZXJjaXNlKTtcbiAgICAgICAgICAgIHVwZGF0ZWRFeGVyY2lzZUdyb3Vwc1tleGVyY2lzZUdyb3VwXS5leGVyY2lzZXMucHVzaChleGVyY2lzZSk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmFkanVzdEV4cGFuZGVkT3JDb2xsYXBzZWRTdGF0ZU9mRXhlcmNpc2VHcm91cHModXBkYXRlZEV4ZXJjaXNlR3JvdXBzKTtcblxuICAgICAgICByZXR1cm4gdXBkYXRlZEV4ZXJjaXNlR3JvdXBzO1xuICAgIH1cblxuICAgIHByaXZhdGUgZXhwYW5kQWxsRXhlcmNpc2VzQW5kU2F2ZVN0YXRlQmVmb3JlU2VhcmNoKGV4ZXJjaXNlR3JvdXBzOiBFeGVyY2lzZUdyb3Vwcykge1xuICAgICAgICBjb25zdCBpc0FDb25zZWN1dGl2ZVNlYXJjaFdpdGhBbGxHcm91cHNFeHBhbmRlZCA9IHRoaXMuc2VhcmNoV2FzQWN0aXZlO1xuICAgICAgICBpZiAoIWlzQUNvbnNlY3V0aXZlU2VhcmNoV2l0aEFsbEdyb3Vwc0V4cGFuZGVkKSB7XG4gICAgICAgICAgICB0aGlzLmV4ZXJjaXNlR3JvdXBzQmVmb3JlU2VhcmNoID0gY2xvbmVEZWVwKHRoaXMuZXhlcmNpc2VHcm91cHMpO1xuICAgICAgICAgICAgdGhpcy5zZWFyY2hXYXNBY3RpdmUgPSB0cnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgT2JqZWN0LmVudHJpZXMoZXhlcmNpc2VHcm91cHMpLmZvckVhY2goKFssIGV4ZXJjaXNlR3JvdXBdKSA9PiB7XG4gICAgICAgICAgICBleGVyY2lzZUdyb3VwLmlzQ29sbGFwc2VkID0gZmFsc2U7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHByaXZhdGUgcmVzdG9yZVN0YXRlQmVmb3JlU2VhcmNoKGV4ZXJjaXNlR3JvdXBzOiBFeGVyY2lzZUdyb3Vwcykge1xuICAgICAgICB0aGlzLnNlYXJjaFdhc0FjdGl2ZSA9IGZhbHNlO1xuXG4gICAgICAgIE9iamVjdC5lbnRyaWVzKGV4ZXJjaXNlR3JvdXBzKS5mb3JFYWNoKChbZXhlcmNpc2VHcm91cEtleSwgZXhlcmNpc2VHcm91cF0pID0+IHtcbiAgICAgICAgICAgIGV4ZXJjaXNlR3JvdXAuaXNDb2xsYXBzZWQgPSB0aGlzLmV4ZXJjaXNlR3JvdXBzQmVmb3JlU2VhcmNoW2V4ZXJjaXNlR3JvdXBLZXldLmlzQ29sbGFwc2VkO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGtlZXBDdXJyZW50Q29sbGFwc2VkT3JFeHBhbmRlZFN0YXRlT2ZFeGVyY2lzZUdyb3VwcyhleGVyY2lzZUdyb3VwczogRXhlcmNpc2VHcm91cHMpIHtcbiAgICAgICAgT2JqZWN0LmVudHJpZXMoZXhlcmNpc2VHcm91cHMpLmZvckVhY2goKFtleGVyY2lzZUdyb3VwS2V5LCBleGVyY2lzZUdyb3VwXSkgPT4ge1xuICAgICAgICAgICAgZXhlcmNpc2VHcm91cC5pc0NvbGxhcHNlZCA9IHRoaXMuZXhlcmNpc2VHcm91cHNbZXhlcmNpc2VHcm91cEtleV0uaXNDb2xsYXBzZWQ7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEV4cGFuZCBhdCBsZWFzdCBvbmUgZXhlcmNpc2UgZ3JvdXAsIGNvbnNpZGVyaW5nIHRoYXQge0BsaW5rIEV4ZXJjaXNlR3JvdXBDYXRlZ29yeSNwYXN0fSBzaGFsbCBuZXZlciBiZSBleHBhbmRlZCBieSBkZWZhdWx0XG4gICAgICpcbiAgICAgKiBFeHBhbmRlZCBieSB0aGUgb3JkZXIge0BsaW5rIEV4ZXJjaXNlR3JvdXBDYXRlZ29yeSNjdXJyZW50fSwge0BsaW5rIEV4ZXJjaXNlR3JvdXBDYXRlZ29yeSNmdXR1cmV9LCB7QGxpbmsgRXhlcmNpc2VHcm91cENhdGVnb3J5I25vRHVlRGF0ZX1cbiAgICAgKi9cbiAgICBwcml2YXRlIG1ha2VTdXJlQXRMZWFzdE9uZUV4ZXJjaXNlR3JvdXBJc0V4cGFuZGVkKGV4ZXJjaXNlR3JvdXBzOiBFeGVyY2lzZUdyb3Vwcykge1xuICAgICAgICBjb25zdCBleGVyY2lzZUdyb3Vwc1dpdGhFeGVyY2lzZXMgPSBPYmplY3QuZW50cmllcyhleGVyY2lzZUdyb3VwcykuZmlsdGVyKChbLCBleGVyY2lzZUdyb3VwXSkgPT4gZXhlcmNpc2VHcm91cC5leGVyY2lzZXMubGVuZ3RoID4gMCk7XG4gICAgICAgIGNvbnN0IGV4cGFuZGVkRXhlcmNpc2VHcm91cHMgPSBleGVyY2lzZUdyb3Vwc1dpdGhFeGVyY2lzZXMuZmlsdGVyKChbLCBleGVyY2lzZUdyb3VwXSkgPT4gIWV4ZXJjaXNlR3JvdXAuaXNDb2xsYXBzZWQpO1xuXG4gICAgICAgIGNvbnN0IGF0TGVhc3RPbmVFeGVyY2lzZUlzRXhwYW5kZWQgPSBleHBhbmRlZEV4ZXJjaXNlR3JvdXBzLmxlbmd0aCA+IDA7XG4gICAgICAgIGNvbnN0IGV4cGFuZGFibGVHcm91cHNFeGlzdCA9ICFhdExlYXN0T25lRXhlcmNpc2VJc0V4cGFuZGVkICYmIGV4ZXJjaXNlR3JvdXBzV2l0aEV4ZXJjaXNlcy5sZW5ndGggPiAwO1xuXG4gICAgICAgIGlmICghZXhwYW5kYWJsZUdyb3Vwc0V4aXN0IHx8IGF0TGVhc3RPbmVFeGVyY2lzZUlzRXhwYW5kZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGZvciAoY29uc3QgZXhlcmNpc2VHcm91cEtleSBvZiBERUZBVUxUX0VYUEFORF9PUkRFUikge1xuICAgICAgICAgICAgY29uc3QgZ3JvdXBUb0V4cGFuZCA9IGV4ZXJjaXNlR3JvdXBzV2l0aEV4ZXJjaXNlcy5maW5kKChba2V5XSkgPT4ga2V5ID09PSBleGVyY2lzZUdyb3VwS2V5KTtcbiAgICAgICAgICAgIGlmIChncm91cFRvRXhwYW5kKSB7XG4gICAgICAgICAgICAgICAgZ3JvdXBUb0V4cGFuZCFbMV0uaXNDb2xsYXBzZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIDEuIEV4cGFuZCBhbGwgc2VjdGlvbnMgd2l0aCBtYXRjaGVzIG9uIHNlYXJjaFxuICAgICAqIDIuIEtlZXAgdGhlIGV4cGFuZGVkIG9yIGNvbGxhcHNlZCBzdGF0ZSBvZiB0aGUgZXhlcmNpc2UgZ3JvdXBzIHdoZW4gYSBmaWx0ZXIgaXMgYXBwbGllZFxuICAgICAqIDMuIE1ha2Ugc3VyZSBhdCBsZWFzdCBvbmUgZGlzcGxheWVkIHNlY3Rpb24gaXMgZXhwYW5kZWQgYnkgZGVmYXVsdFxuICAgICAqXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlR3JvdXBzIHVwZGF0ZWQgYW5kIGdyb3VwZWQgZXhlcmNpc2VzIHRoYXQgYXJlIHRvIGJlIGRpc3BsYXllZFxuICAgICAqL1xuICAgIHByaXZhdGUgYWRqdXN0RXhwYW5kZWRPckNvbGxhcHNlZFN0YXRlT2ZFeGVyY2lzZUdyb3VwcyhleGVyY2lzZUdyb3VwczogRXhlcmNpc2VHcm91cHMpIHtcbiAgICAgICAgY29uc3QgaXNTZWFyY2hpbmdFeGVyY2lzZSA9IHRoaXMuYXBwbGllZFNlYXJjaFN0cmluZztcbiAgICAgICAgaWYgKGlzU2VhcmNoaW5nRXhlcmNpc2UpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmV4cGFuZEFsbEV4ZXJjaXNlc0FuZFNhdmVTdGF0ZUJlZm9yZVNlYXJjaChleGVyY2lzZUdyb3Vwcyk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGhpcy5zZWFyY2hXYXNBY3RpdmUpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnJlc3RvcmVTdGF0ZUJlZm9yZVNlYXJjaChleGVyY2lzZUdyb3Vwcyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBmaWx0ZXJJc0FwcGxpZWQgPSB0aGlzLmV4ZXJjaXNlR3JvdXBzO1xuICAgICAgICBpZiAoZmlsdGVySXNBcHBsaWVkKSB7XG4gICAgICAgICAgICB0aGlzLmtlZXBDdXJyZW50Q29sbGFwc2VkT3JFeHBhbmRlZFN0YXRlT2ZFeGVyY2lzZUdyb3VwcyhleGVyY2lzZUdyb3Vwcyk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLm1ha2VTdXJlQXRMZWFzdE9uZUV4ZXJjaXNlR3JvdXBJc0V4cGFuZGVkKGV4ZXJjaXNlR3JvdXBzKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGdldEV4ZXJjaXNlR3JvdXAoZXhlcmNpc2U6IEV4ZXJjaXNlKTogRXhlcmNpc2VHcm91cENhdGVnb3J5IHtcbiAgICAgICAgaWYgKCFleGVyY2lzZS5kdWVEYXRlKSB7XG4gICAgICAgICAgICByZXR1cm4gJ25vRHVlRGF0ZSc7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkdWVEYXRlID0gZGF5anMoZXhlcmNpc2UuZHVlRGF0ZSk7XG4gICAgICAgIGNvbnN0IG5vdyA9IGRheWpzKCk7XG5cbiAgICAgICAgY29uc3QgZHVlRGF0ZUlzSW5UaGVQYXN0ID0gZHVlRGF0ZS5pc0JlZm9yZShub3cpO1xuICAgICAgICBpZiAoZHVlRGF0ZUlzSW5UaGVQYXN0KSB7XG4gICAgICAgICAgICByZXR1cm4gJ3Bhc3QnO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZHVlRGF0ZUlzV2l0aGluTmV4dFdlZWsgPSBkdWVEYXRlLmlzQmVmb3JlKG5vdy5hZGQoMSwgJ3dlZWsnKSk7XG4gICAgICAgIGlmIChkdWVEYXRlSXNXaXRoaW5OZXh0V2Vlaykge1xuICAgICAgICAgICAgcmV0dXJuICdjdXJyZW50JztcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiAnZnV0dXJlJztcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUaGlzIGlzIGEgd29ya2Fyb3VuZCB0byBtYWtlIHtAbGluayBERUZBVUxUX0VYRVJDSVNFX0dST1VQU30gYWNjZXNzaWJsZSBmb3IgdGVzdHMgd2l0aG91dCBleHBvcnRpbmcgaXRcbiAgICAgKi9cbiAgICBnZXREZWZhdWx0RXhlcmNpc2VHcm91cHMoKSB7XG4gICAgICAgIHJldHVybiBERUZBVUxUX0VYRVJDSVNFX0dST1VQUztcbiAgICB9XG59XG4iLCJAaWYgKCFmaWx0ZXJlZEFuZFNvcnRlZEV4ZXJjaXNlcz8ubGVuZ3RoKSB7XG4gICAgPGRpdj5cbiAgICAgICAge3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VMaXN0Lm5vRXhlcmNpc2VNYXRjaGVzU2VhcmNoQW5kRmlsdGVycycgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgPC9kaXY+XG59IEBlbHNlIHtcbiAgICBAZm9yIChleGVyY2lzZUdyb3VwS2V5IG9mIE9iamVjdC5rZXlzKGV4ZXJjaXNlR3JvdXBzKTsgdHJhY2sgZXhlcmNpc2VHcm91cEtleSkge1xuICAgICAgICA8ZGl2IGNsYXNzPVwiZ3VpZGVkLXRvdXIgZXhlcmNpc2Utcm93LWNvbnRhaW5lciBtYi0zXCI+XG4gICAgICAgICAgICBAaWYgKGV4ZXJjaXNlR3JvdXBzW2V4ZXJjaXNlR3JvdXBLZXldLmV4ZXJjaXNlcy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29udHJvbC1sYWJlbCBkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyXCIgKGNsaWNrKT1cInRvZ2dsZUdyb3VwQ2F0ZWdvcnlDb2xsYXBzZShleGVyY2lzZUdyb3VwS2V5KVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaWNvbi1jb250YWluZXIgcGUtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbaWNvbl09XCJmYUNoZXZyb25SaWdodFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJyb3RhdGUtaWNvbiBjaGV2cm9uLXBvc2l0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3Mucm90YXRlZF09XCIhZXhlcmNpc2VHcm91cHNbZXhlcmNpc2VHcm91cEtleV0uaXNDb2xsYXBzZWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LXByaW1hcnldPVwiZXhlcmNpc2VHcm91cEtleSA9PT0gJ2N1cnJlbnQnXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICBAc3dpdGNoIChleGVyY2lzZUdyb3VwS2V5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBAY2FzZSAoJ3Bhc3QnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzPVwibWItMFwiPnt7ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlTGlzdC5wYXN0JyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGNhc2UgKCdjdXJyZW50Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzcz1cInRleHQtcHJpbWFyeSBtYi0wXCI+e3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VMaXN0LmN1cnJlbnQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBAY2FzZSAoJ2Z1dHVyZScpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3M9XCJtYi0wXCI+e3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VMaXN0LmZ1dHVyZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIEBjYXNlICgnbm9EdWVEYXRlJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzcz1cIm1iLTBcIj57eyAnYXJ0ZW1pc0FwcC5jb3Vyc2VPdmVydmlldy5leGVyY2lzZUxpc3Qubm9EdWVEYXRlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBbbmdiQ29sbGFwc2VdPVwiZXhlcmNpc2VHcm91cHNbZXhlcmNpc2VHcm91cEtleV0uaXNDb2xsYXBzZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgQGZvciAoZXhlcmNpc2Ugb2YgZXhlcmNpc2VHcm91cHNbZXhlcmNpc2VHcm91cEtleV0uZXhlcmNpc2VzOyB0cmFjayBleGVyY2lzZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1jb3Vyc2UtZXhlcmNpc2Utcm93IGNsYXNzPVwicGItMVwiIFtleGVyY2lzZV09XCJleGVyY2lzZVwiIFtjb3Vyc2VdPVwiY291cnNlIVwiIFtoYXNHdWlkZWRUb3VyXT1cImV4ZXJjaXNlID09PSBleGVyY2lzZUZvckd1aWRlZFRvdXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbGxhcHNlZFwiPjwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICB9XG59XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ291cnNlRXhlcmNpc2VSb3dDb21wb25lbnQgfSBmcm9tICdhcHAvb3ZlcnZpZXcvY291cnNlLWV4ZXJjaXNlcy9jb3Vyc2UtZXhlcmNpc2Utcm93LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRDb21wb25lbnRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL2NvbXBvbmVudHMvc2hhcmVkLWNvbXBvbmVudC5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZFBpcGVzTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9waXBlcy9zaGFyZWQtcGlwZXMubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNDb3Vyc2VzUm91dGluZ01vZHVsZSB9IGZyb20gJ2FwcC9vdmVydmlldy9jb3Vyc2VzLXJvdXRpbmcubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNFeGVyY2lzZUJ1dHRvbnNNb2R1bGUgfSBmcm9tICdhcHAvb3ZlcnZpZXcvZXhlcmNpc2UtZGV0YWlscy9leGVyY2lzZS1idXR0b25zLm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzSGVhZGVyRXhlcmNpc2VQYWdlV2l0aERldGFpbHNNb2R1bGUgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oZWFkZXJzL2V4ZXJjaXNlLWhlYWRlcnMubW9kdWxlJztcbmltcG9ydCB7IE9yaW9uTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9vcmlvbi9vcmlvbi5tb2R1bGUnO1xuaW1wb3J0IHsgR3JhZGluZ0tleU92ZXJ2aWV3TW9kdWxlIH0gZnJvbSAnYXBwL2dyYWRpbmctc3lzdGVtL2dyYWRpbmcta2V5LW92ZXJ2aWV3L2dyYWRpbmcta2V5LW92ZXJ2aWV3Lm1vZHVsZSc7XG5pbXBvcnQgeyBTdWJtaXNzaW9uUmVzdWx0U3RhdHVzTW9kdWxlIH0gZnJvbSAnYXBwL292ZXJ2aWV3L3N1Ym1pc3Npb24tcmVzdWx0LXN0YXR1cy5tb2R1bGUnO1xuaW1wb3J0IHsgRXhlcmNpc2VDYXRlZ29yaWVzTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9leGVyY2lzZS1jYXRlZ29yaWVzL2V4ZXJjaXNlLWNhdGVnb3JpZXMubW9kdWxlJztcbmltcG9ydCB7IENvdXJzZUV4ZXJjaXNlc0dyb3VwZWRCeVdlZWtDb21wb25lbnQgfSBmcm9tICdhcHAvb3ZlcnZpZXcvY291cnNlLWV4ZXJjaXNlcy9jb3Vyc2UtZXhlcmNpc2VzLWdyb3VwZWQtYnktd2Vlay5jb21wb25lbnQnO1xuaW1wb3J0IHsgQ291cnNlRXhlcmNpc2VzR3JvdXBlZEJ5VGltZWZyYW1lQ29tcG9uZW50IH0gZnJvbSAnYXBwL292ZXJ2aWV3L2NvdXJzZS1leGVyY2lzZXMvY291cnNlLWV4ZXJjaXNlcy1ncm91cGVkLWJ5LXRpbWVmcmFtZS5jb21wb25lbnQnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtcbiAgICAgICAgQXJ0ZW1pc1NoYXJlZE1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc1NoYXJlZFBpcGVzTW9kdWxlLFxuICAgICAgICBBcnRlbWlzQ291cnNlc1JvdXRpbmdNb2R1bGUsXG4gICAgICAgIEFydGVtaXNFeGVyY2lzZUJ1dHRvbnNNb2R1bGUsXG4gICAgICAgIEFydGVtaXNIZWFkZXJFeGVyY2lzZVBhZ2VXaXRoRGV0YWlsc01vZHVsZSxcbiAgICAgICAgT3Jpb25Nb2R1bGUsXG4gICAgICAgIEdyYWRpbmdLZXlPdmVydmlld01vZHVsZSxcbiAgICAgICAgU3VibWlzc2lvblJlc3VsdFN0YXR1c01vZHVsZSxcbiAgICAgICAgRXhlcmNpc2VDYXRlZ29yaWVzTW9kdWxlLFxuICAgIF0sXG4gICAgZGVjbGFyYXRpb25zOiBbQ291cnNlRXhlcmNpc2VSb3dDb21wb25lbnQsIENvdXJzZUV4ZXJjaXNlc0dyb3VwZWRCeVdlZWtDb21wb25lbnQsIENvdXJzZUV4ZXJjaXNlc0dyb3VwZWRCeVRpbWVmcmFtZUNvbXBvbmVudF0sXG4gICAgZXhwb3J0czogW0NvdXJzZUV4ZXJjaXNlUm93Q29tcG9uZW50LCBDb3Vyc2VFeGVyY2lzZXNHcm91cGVkQnlXZWVrQ29tcG9uZW50LCBDb3Vyc2VFeGVyY2lzZXNHcm91cGVkQnlUaW1lZnJhbWVDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBBcnRlbWlzQ291cnNlRXhlcmNpc2VSb3dNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLFdBQVcsYUFBcUI7QUFDekMsU0FBUyxzQkFBc0I7Ozs7OztBQ0VuQixJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsa0JBQUEsQ0FBQTtBQUVJLElBQUEsd0JBQUEsZ0JBQUEsU0FBQSwwSEFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBZ0IseUJBQUEsT0FBQSxjQUFBLENBQWU7SUFBQSxDQUFBOztBQUlsQyxJQUFBLDBCQUFBO0FBQ0wsSUFBQSxvQkFBQSxHQUFBLFlBQUE7Ozs7QUFOUSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGlCQUFBLE9BQUEsY0FBQSxvQkFBQSxFQUFvRCxlQUFBLHlCQUFBLEdBQUEsR0FBQSwrQ0FBQSxDQUFBLEVBQUEsaUJBQUEsT0FBQSxTQUFBLFdBQUEsT0FBQSxXQUFBLE9BQUEsRUFBQSxlQUFBLE9BQUEsWUFBQTs7Ozs7O0FBUXhELElBQUEsb0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxrQkFBQSxDQUFBO0FBRUksSUFBQSx3QkFBQSxnQkFBQSxTQUFBLDBIQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFnQix5QkFBQSxPQUFBLGNBQUEsQ0FBZTtJQUFBLENBQUE7QUFJbEMsSUFBQSwwQkFBQTtBQUNMLElBQUEsb0JBQUEsR0FBQSxZQUFBOzs7O0FBTlEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxpQkFBQSxPQUFBLGNBQUEsb0JBQUEsRUFBb0QsaUJBQUEsT0FBQSxTQUFBLFdBQUEsT0FBQSxXQUFBLFFBQUEsRUFBQSxlQUFBLE9BQUEsWUFBQTs7Ozs7QUFYNUQsSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsa0ZBQUEsR0FBQSxDQUFBLEVBUUMsR0FBQSxrRkFBQSxHQUFBLENBQUE7Ozs7QUFSRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLEdBQUEsT0FBQSx3QkFBQSxPQUFBLFdBQUEsU0FBQSxPQUFBLGFBQUEsV0FBQSxPQUFBLFdBQUEsV0FBQSxPQUFBLFNBQUEsTUFBQSxJQUFBLEVBQUE7QUFTQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLEdBQUEsT0FBQSx1QkFBQSxPQUFBLFdBQUEsU0FBQSxPQUFBLGFBQUEsV0FBQSxPQUFBLFdBQUEsV0FBQSxPQUFBLFNBQUEsS0FBQSxJQUFBLEVBQUE7OztBRFhSLElBZWE7QUFmYjs7QUFFQTtBQUdBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7QUFPTSxJQUFPLDhDQUFQLE1BQU8sNkNBQTJDO01BV3hDO01BQ0E7TUFDQTtNQVpILGVBQWU7TUFDeEI7TUFDQSxnQkFBZ0I7TUFFUDtNQUNBO01BQ0E7TUFDQTtNQUVULFlBQ1ksdUJBQ0Esd0JBQ0EsT0FBcUI7QUFGckIsYUFBQSx3QkFBQTtBQUNBLGFBQUEseUJBQUE7QUFDQSxhQUFBLFFBQUE7TUFDVDtNQUtILFdBQVE7QUFDSixhQUFLLHNCQUFzQixNQUFLLEVBQUcsVUFBVSxDQUFDLGVBQTRCLEtBQUssYUFBYSxVQUFXO0FBRXZHLGFBQUssTUFBTSxZQUFZLFVBQVUsQ0FBQyxXQUFVO0FBQ3hDLGNBQUksT0FBTyxlQUFlLEdBQUc7QUFDekIsaUJBQUssY0FBYTs7UUFFMUIsQ0FBQztNQUNMO01BRUEsSUFBSSxzQkFBbUI7QUFDbkIsZUFBUSxLQUFLLFNBQWlDO01BQ2xEO01BS0EsZ0JBQWE7QUFDVCxjQUFNLE9BQVEsS0FBSyxTQUFTLHNCQUF1QixDQUFDLEVBQThDO0FBQ2xHLGFBQUssc0JBQXNCLG9CQUFvQixNQUFNLEtBQUssUUFBK0I7TUFDN0Y7TUFLQSxnQkFBYTtBQUNULGFBQUssc0JBQXNCLE9BQU07QUFDakMsYUFBSyx1QkFBdUIscUNBQXFDLEtBQUssUUFBK0I7TUFDekc7O3lCQS9DUyw4Q0FBMkMsK0JBQUEscUJBQUEsR0FBQSwrQkFBQSx3QkFBQSxHQUFBLCtCQUFBLGlCQUFBLENBQUE7TUFBQTtnRUFBM0MsOENBQTJDLFdBQUEsQ0FBQSxDQUFBLDRDQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLFVBQUEsWUFBQSxjQUFBLGdCQUFBLFVBQUEsV0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxZQUFBLFlBQUEsZ0JBQUEsVUFBQSxHQUFBLENBQUEsbUNBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxlQUFBLGlCQUFBLGVBQUEsY0FBQSxHQUFBLENBQUEsZUFBQSxVQUFBLEdBQUEsaUJBQUEsaUJBQUEsZUFBQSxjQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEscURBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNmeEQsVUFBQSw0QkFBQSxHQUFBLHdDQUFBLENBQUE7QUFDSSxVQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsd0JBQUEsR0FBQSxvRUFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsbUNBQUE7QUFvQkosVUFBQSxvQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDBCQUFBO0FBQ0EsVUFBQSxvQkFBQSxHQUFBLElBQUE7OztBQXRCc0MsVUFBQSx3QkFBQSxZQUFBLElBQUEsUUFBQSxFQUFxQixZQUFBLElBQUEsUUFBQSxFQUFBLGdCQUFBLElBQUEsWUFBQSxFQUFBLFlBQUEsSUFBQSxRQUFBOzs7OztvRkRlOUMsNkNBQTJDLEVBQUEsV0FBQSw4Q0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVmeEQsU0FBUyxnQkFBZ0I7O0FBQXpCLElBZWE7QUFmYjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBT00sSUFBTywrQkFBUCxNQUFPLDhCQUE0Qjs7eUJBQTVCLCtCQUE0QjtNQUFBO2dFQUE1Qiw4QkFBNEIsQ0FBQTtvRUFKM0IscUJBQXFCLDhCQUE4QiwwQkFBMEIsNkJBQTZCLGFBQWEsbUJBQW1CLEVBQUEsQ0FBQTs7Ozs7O0FDVHhKLFNBQVMsWUFBQUEsaUJBQWdCOztBQUZ6QixJQVdhO0FBWGI7OztBQUNBO0FBRUE7QUFDQTtBQU9NLElBQU8sMkJBQVAsTUFBTywwQkFBd0I7O3lCQUF4QiwyQkFBd0I7TUFBQTtnRUFBeEIsMEJBQXdCLENBQUE7b0VBSHZCLHFCQUFxQiw0QkFBNEIsRUFBQSxDQUFBOzs7Ozs7QUNSL0QsU0FBUyxhQUFBQyxZQUFXLFNBQUFDLGNBQWdDO0FBSXBELFNBQVMsYUFBYSxpQkFBaUI7QUFLdkMsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsd0JBQXdCOzs7Ozs7O0FDTmpCLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOzs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBRlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQkFBQSwwQkFBQSxHQUFBLEdBQUEscUVBQUEsOEJBQUEsR0FBQSxLQUFBLDBCQUFBLEdBQUEsR0FBQSxPQUFBLHFCQUFBLE9BQUEsQ0FBQSxDQUFBLEdBQUEsb0JBQUE7Ozs7O0FBR0osSUFBQSxxQkFBQSxDQUFBOzs7O0FBQUEsSUFBQSxpQ0FBQSxzQkFBQSwwQkFBQSxHQUFBLEdBQUEsaUZBQUEsR0FBQSxnQkFBQTs7Ozs7QUFQWixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsNEVBQUEsR0FBQSxDQUFBLEVBSUMsR0FBQSw0RUFBQSxHQUFBLENBQUE7QUFHTCxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsMkJBQUEsQ0FBQTtBQU9BLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxJQUFBOzs7O0FBakJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLHFCQUFBLFVBQUEsSUFBQSxDQUFBO0FBV0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLE9BQUEscUJBQUEsUUFBQSxFQUEyQyxVQUFBLE9BQUEsTUFBQSxFQUFBLGlCQUFBLE9BQUEscUJBQUEsYUFBQSxPQUFBLHFCQUFBOzs7OztBQWlCbkMsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7OztBQUVKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7O0FBSFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSw4QkFBQSwwQkFBQSxHQUFBLEdBQUEsT0FBQSxlQUFBLFVBQUEsRUFBQSxPQUFBLFlBQUEsR0FBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsT0FBQSxlQUFBLFVBQUEsRUFBQSxLQUFBLFlBQUEsR0FBQSx3QkFBQTs7Ozs7QUFLSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDhCQUFBLDBCQUFBLEdBQUEsR0FBQSx5REFBQSxHQUFBLHdCQUFBOzs7OztBQWVBLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSwyQkFBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7OztBQUQwQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsWUFBQSxFQUFxQixVQUFBLFFBQUEsTUFBQSxFQUFBLGlCQUFBLGlCQUFBLFFBQUEscUJBQUE7Ozs7O0FBRm5FLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwrQkFBQSxHQUFBLDJFQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7QUFHSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7OztBQUpRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxlQUFBLFVBQUEsRUFBQSxTQUFBOzs7Ozs7QUE3QlosSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUdJLElBQUEseUJBQUEsU0FBQSxTQUFBLDRFQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGFBQUEsWUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxlQUFBLFVBQUEsRUFBQSxjQUFBLENBQUEsUUFBQSxlQUFBLFVBQUEsRUFBQSxXQUFBO0lBQTBFLENBQUE7QUFFbkYsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxvRUFBQSxHQUFBLENBQUEsRUFLQyxHQUFBLG9FQUFBLEdBQUEsQ0FBQTtBQU1ELElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFNSSxJQUFBLHFCQUFBLEVBQUE7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxxRUFBQSxHQUFBLENBQUE7QUFPQSxJQUFBLHdCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7Ozs7O0FBakNZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSw4QkFBQSxHQUFBLEtBQUEsT0FBQSxlQUFBLFVBQUEsSUFBQSxPQUFBLGVBQUEsVUFBQSxFQUFBLGdCQUFBLEtBQUEsQ0FBQTtBQUdzQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxlQUFBLFVBQUEsRUFBQSxjQUFBLE9BQUEsY0FBQSxPQUFBLFNBQUE7QUFDdEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsZUFBQSxVQUFBLEVBQUEsU0FBQSxPQUFBLGVBQUEsVUFBQSxFQUFBLE1BQUEsSUFBQSxFQUFBO0FBTUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsT0FBQSxlQUFBLFVBQUEsRUFBQSxTQUFBLENBQUEsT0FBQSxlQUFBLFVBQUEsRUFBQSxNQUFBLElBQUEsRUFBQTtBQVNJLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsOEJBQUEsR0FBQSxLQUFBLE9BQUEsZUFBQSxVQUFBLEVBQUEsVUFBQSxNQUFBLENBQUE7QUFFQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLHNDQUFBLE9BQUEsZUFBQSxVQUFBLEVBQUEsVUFBQSxRQUFBLHFCQUFBO0FBR1IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLENBQUEsT0FBQSxlQUFBLFVBQUEsRUFBQSxjQUFBLEtBQUEsRUFBQTs7O0FEbERaLG1CQXVCYSxtQ0FPQTtBQTlCYjs7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUVBOzs7Ozs7Ozs7O0FBZU8sSUFBTSxvQ0FBb0M7QUFPM0MsSUFBTyx3Q0FBUCxNQUFPLHVDQUFxQztNQWtCbEM7TUFDQTtNQUNBO01BbkJPLFNBQVM7TUFFbkI7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUVUO01BQ0E7TUFFQSxZQUFZO01BQ1osY0FBYztNQUVOO01BRVIsWUFDWSxpQkFDQSxnQkFDQSxrQkFBa0M7QUFGbEMsYUFBQSxrQkFBQTtBQUNBLGFBQUEsaUJBQUE7QUFDQSxhQUFBLG1CQUFBO01BQ1Q7TUFFSCxXQUFRO0FBQ0osYUFBSyxlQUFlLFNBQVEsRUFBRyxLQUFLLENBQUMsU0FBUTtBQUN6QyxlQUFLLGNBQWM7QUFDbkIsZUFBSywyQkFBMEI7UUFDbkMsQ0FBQztBQUVELGFBQUssZUFBZSxLQUFLLDBCQUEwQjtNQUN2RDtNQUVBLGNBQVc7QUFDUCxhQUFLLDJCQUEwQjtBQUMvQixhQUFLLGVBQWUsS0FBSywwQkFBMEI7TUFDdkQ7TUFNQSxvQkFBb0IsVUFBa0I7QUFDbEMsZUFBTyxDQUFDLEtBQUssY0FBYyxJQUFJLGVBQWUsVUFBVSxLQUFNLFVBQTJCO01BQzdGO01BRVEsZUFBZSxXQUFzQjtBQUN6QyxjQUFNLG1CQUEyQyxDQUFBO0FBQ2pELGNBQU0sZUFBZSxLQUFLLGlCQUFpQixRQUFRLHVEQUF1RDtBQUMxRyxjQUFNLHFCQUFpQyxDQUFBO0FBRXZDLG1CQUFXLFFBQVEsQ0FBQyxhQUFZO0FBQzVCLGdCQUFNLFlBQVkseUJBQXlCLGdDQUFnQyxVQUFVLEtBQUssZ0JBQWdCO0FBQzFHLGNBQUksQ0FBQyxXQUFXO0FBQ1osK0JBQW1CLEtBQUssUUFBUTtBQUNoQzs7QUFFSixnQkFBTSxZQUFZLFlBQVksTUFBTSxTQUFTLEVBQUUsUUFBUSxNQUFNLEVBQUUsT0FBTyxpQ0FBaUMsSUFBSTtBQUUzRyxjQUFJLENBQUMsaUJBQWlCLFNBQVMsR0FBRztBQUM5Qiw2QkFBaUIsU0FBUyxJQUFJO2NBQzFCLE9BQU8sTUFBTSxTQUFTLEVBQUUsUUFBUSxNQUFNO2NBQ3RDLEtBQUssTUFBTSxTQUFTLEVBQUUsTUFBTSxNQUFNO2NBQ2xDLGFBQWEsVUFBVSxTQUFTLE1BQUssR0FBSSxNQUFNO2NBQy9DLGVBQWUsVUFBVSxPQUFPLE1BQUssR0FBSSxNQUFNO2NBQy9DLFdBQVcsQ0FBQTs7O0FBSW5CLDJCQUFpQixTQUFTLEVBQUUsVUFBVSxLQUFLLFFBQVE7UUFDdkQsQ0FBQztBQUdELFlBQUksbUJBQW1CLFFBQVE7QUFDM0IsMkJBQWlCLFlBQVksSUFBSTtZQUM3QixXQUFXO1lBQ1gsZUFBZTtZQUNmLGFBQWE7OztBQUlyQixhQUFLLGlCQUFpQjtNQUMxQjtNQUVRLDZCQUEwQjtBQUM5QixjQUFNLGVBQWUsS0FBSyxnQkFBZ0Isd0JBQ3RDLEtBQUssUUFBUSxXQUFXLE9BQU8sQ0FBQyxhQUFhLHlCQUF5QixzQkFBc0IsVUFBVSxLQUFLLGFBQWEsQ0FBQyxHQUN6SCxJQUNBLEtBQUssV0FBVztBQUVwQixZQUFJLGNBQWM7QUFDZCxnQkFBTSxVQUFVLHlCQUF5QixnQkFBZ0IsWUFBWTtBQUNyRSxlQUFLLHVCQUF1QjtZQUN4QixVQUFVO1lBQ1Y7O2VBRUQ7QUFDSCxlQUFLLHVCQUF1Qjs7TUFFcEM7O3lCQWxHUyx3Q0FBcUMsZ0NBQUEsZUFBQSxHQUFBLGdDQUFBLGNBQUEsR0FBQSxnQ0FBQSxvQkFBQSxDQUFBO01BQUE7aUVBQXJDLHdDQUFxQyxXQUFBLENBQUEsQ0FBQSxzQ0FBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLDRCQUFBLDhCQUFBLFFBQUEsVUFBQSx1QkFBQSx5QkFBQSxlQUFBLGlCQUFBLGtCQUFBLG1CQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLGVBQUEsd0JBQUEsR0FBQSxDQUFBLEdBQUEsMEJBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxNQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBLFlBQUEsVUFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLFdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsOERBQUEsR0FBQSxRQUFBLEdBQUEsZUFBQSxPQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLFlBQUEsVUFBQSxlQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsK0NBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUM5QmxELFVBQUEseUJBQUEsR0FBQSw4REFBQSxJQUFBLENBQUE7QUFxQkEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSwrQkFBQSxHQUFBLHNEQUFBLElBQUEsSUFBQSxNQUFBLE1BQUEsdUNBQUE7QUFzQ0osVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxJQUFBOzs7QUE3REEsVUFBQSw0QkFBQSxHQUFBLElBQUEsd0JBQUEsSUFBQSxvQkFBQSxJQUFBLHFCQUFBLFFBQUEsSUFBQSxJQUFBLEVBQUE7QUFzQkksVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLE9BQUEsS0FBQSxJQUFBLGNBQUEsQ0FBQTs7Ozs7cUZEUVMsdUNBQXFDLEVBQUEsV0FBQSx3Q0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUU5QmxELFNBQVMsYUFBQUMsWUFBVyxTQUFBQyxjQUF3QjtBQUc1QyxPQUFPQyxZQUFXO0FBQ2xCLFNBQVMsZUFBQUMsY0FBYSxhQUFBQyxZQUFXLHNCQUFzQjtBQUN2RCxTQUFTLGlCQUFpQjs7Ozs7O0FDSnRCLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxJQUFBOzs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGNBQUEsMEJBQUEsR0FBQSxHQUFBLDBFQUFBLEdBQUEsUUFBQTs7Ozs7QUFpQm9CLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFBaUIsSUFBQSxxQkFBQSxDQUFBOztBQUFzRSxJQUFBLDJCQUFBO0FBQzNGLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7O0FBRHFCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLDZDQUFBLENBQUE7Ozs7O0FBR2pCLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFBOEIsSUFBQSxxQkFBQSxDQUFBOztBQUF5RSxJQUFBLDJCQUFBO0FBQzNHLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7O0FBRGtDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLGdEQUFBLENBQUE7Ozs7O0FBRzlCLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFBaUIsSUFBQSxxQkFBQSxDQUFBOztBQUF3RSxJQUFBLDJCQUFBO0FBQzdGLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7O0FBRHFCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLCtDQUFBLENBQUE7Ozs7O0FBR2pCLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFBaUIsSUFBQSxxQkFBQSxDQUFBOztBQUEyRSxJQUFBLDJCQUFBO0FBQ2hHLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7O0FBRHFCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLGtEQUFBLENBQUE7Ozs7O0FBTXJCLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSwyQkFBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7OztBQUQwQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsWUFBQSxFQUFxQixVQUFBLFFBQUEsTUFBQSxFQUFBLGlCQUFBLGlCQUFBLFFBQUEscUJBQUE7Ozs7OztBQTFCbkUsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUFxRCxJQUFBLHlCQUFBLFNBQUEsU0FBQSw2R0FBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsc0JBQUEsNEJBQUEsRUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLDRCQUFBLG1CQUFBLENBQTZDO0lBQUEsQ0FBQTtBQUN2RyxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQU1KLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFDSSxJQUFBLHlCQUFBLEdBQUEsOEZBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSw4RkFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLCtGQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsK0ZBQUEsR0FBQSxDQUFBO0FBV1QsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLCtCQUFBLElBQUEsOEZBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQUdKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBOzs7Ozs7QUF6QmdCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsV0FBQSxDQUFBLE9BQUEsZUFBQSxtQkFBQSxFQUFBLFdBQUEsRUFBK0QsZ0JBQUEsd0JBQUEsU0FBQTtBQUYvRCxJQUFBLHlCQUFBLFFBQUEsT0FBQSxjQUFBO0FBTVIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLDJGQUFBLHlCQUFBLFNBQUEsSUFBQSw2RkFBQSxZQUFBLElBQUEsNkZBQUEsV0FBQSxLQUFBLDZGQUFBLGNBQUEsS0FBQSxFQUFBO0FBZUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxlQUFBLE9BQUEsZUFBQSxtQkFBQSxFQUFBLFdBQUE7QUFDRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsZUFBQSxtQkFBQSxFQUFBLFNBQUE7Ozs7O0FBM0JaLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx1RkFBQSxJQUFBLENBQUE7QUFnQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7OztBQWpDUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxlQUFBLG1CQUFBLEVBQUEsVUFBQSxTQUFBLElBQUEsRUFBQTs7Ozs7QUFGUixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsK0JBQUEsR0FBQSx5RUFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBOzs7O0FBQUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxPQUFBLE9BQUEsS0FBQSxPQUFBLGNBQUEsQ0FBQTs7O0FETEosSUFZTSxzQkFJQSx5QkFZTztBQTVCYjs7QUFDQTtBQUNBOzs7QUFVQSxJQUFNLHVCQUFnRCxDQUFDLFdBQVcsVUFBVSxXQUFXO0FBSXZGLElBQU0sMEJBQTBCO01BQzVCLE1BQU0sRUFBRSxXQUFXLENBQUEsR0FBSSxhQUFhLEtBQUk7TUFDeEMsU0FBUyxFQUFFLFdBQVcsQ0FBQSxHQUFJLGFBQWEsTUFBSztNQUM1QyxRQUFRLEVBQUUsV0FBVyxDQUFBLEdBQUksYUFBYSxNQUFLO01BQzNDLFdBQVcsRUFBRSxXQUFXLENBQUEsR0FBSSxhQUFhLEtBQUk7O0FBUTNDLElBQU8sNkNBQVAsTUFBTyw0Q0FBMEM7TUFDaEMsU0FBUztNQUVuQjtNQUNBO01BQ0E7TUFDQTtNQUVUO01BRUEsa0JBQTJCO01BQzNCLDZCQUE2QyxVQUFVLHVCQUF1QjtNQUU5RSxZQUFZQTtNQUNaLGNBQWNEO01BQ2QsaUJBQWlCO01BRWpCLGNBQVc7QUFDUCxhQUFLLGlCQUFpQixLQUFLLDBCQUF5QjtNQUN4RDtNQUVBLDRCQUE0QiwwQkFBZ0M7QUFDeEQsYUFBSyxlQUFlLHdCQUF3QixFQUFFLGNBQWMsQ0FBQyxLQUFLLGVBQWUsd0JBQXdCLEVBQUU7TUFDL0c7TUFFUSw0QkFBeUI7QUFDN0IsY0FBTSx3QkFBd0MsVUFBVSx1QkFBdUI7QUFFL0UsWUFBSSxDQUFDLEtBQUssNEJBQTRCO0FBQ2xDLGlCQUFPOztBQUdYLG1CQUFXLFlBQVksS0FBSyw0QkFBNEI7QUFDcEQsZ0JBQU0sZ0JBQWdCLEtBQUssaUJBQWlCLFFBQVE7QUFDcEQsZ0NBQXNCLGFBQWEsRUFBRSxVQUFVLEtBQUssUUFBUTs7QUFHaEUsYUFBSywrQ0FBK0MscUJBQXFCO0FBRXpFLGVBQU87TUFDWDtNQUVRLDJDQUEyQyxnQkFBOEI7QUFDN0UsY0FBTSw0Q0FBNEMsS0FBSztBQUN2RCxZQUFJLENBQUMsMkNBQTJDO0FBQzVDLGVBQUssNkJBQTZCLFVBQVUsS0FBSyxjQUFjO0FBQy9ELGVBQUssa0JBQWtCOztBQUczQixlQUFPLFFBQVEsY0FBYyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUUsYUFBYSxNQUFLO0FBQ3pELHdCQUFjLGNBQWM7UUFDaEMsQ0FBQztNQUNMO01BRVEseUJBQXlCLGdCQUE4QjtBQUMzRCxhQUFLLGtCQUFrQjtBQUV2QixlQUFPLFFBQVEsY0FBYyxFQUFFLFFBQVEsQ0FBQyxDQUFDLGtCQUFrQixhQUFhLE1BQUs7QUFDekUsd0JBQWMsY0FBYyxLQUFLLDJCQUEyQixnQkFBZ0IsRUFBRTtRQUNsRixDQUFDO01BQ0w7TUFFUSxvREFBb0QsZ0JBQThCO0FBQ3RGLGVBQU8sUUFBUSxjQUFjLEVBQUUsUUFBUSxDQUFDLENBQUMsa0JBQWtCLGFBQWEsTUFBSztBQUN6RSx3QkFBYyxjQUFjLEtBQUssZUFBZSxnQkFBZ0IsRUFBRTtRQUN0RSxDQUFDO01BQ0w7TUFPUSwwQ0FBMEMsZ0JBQThCO0FBQzVFLGNBQU0sOEJBQThCLE9BQU8sUUFBUSxjQUFjLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBRSxhQUFhLE1BQU0sY0FBYyxVQUFVLFNBQVMsQ0FBQztBQUNuSSxjQUFNLHlCQUF5Qiw0QkFBNEIsT0FBTyxDQUFDLENBQUMsRUFBRSxhQUFhLE1BQU0sQ0FBQyxjQUFjLFdBQVc7QUFFbkgsY0FBTSwrQkFBK0IsdUJBQXVCLFNBQVM7QUFDckUsY0FBTSx3QkFBd0IsQ0FBQyxnQ0FBZ0MsNEJBQTRCLFNBQVM7QUFFcEcsWUFBSSxDQUFDLHlCQUF5Qiw4QkFBOEI7QUFDeEQ7O0FBR0osbUJBQVcsb0JBQW9CLHNCQUFzQjtBQUNqRCxnQkFBTSxnQkFBZ0IsNEJBQTRCLEtBQUssQ0FBQyxDQUFDLEdBQUcsTUFBTSxRQUFRLGdCQUFnQjtBQUMxRixjQUFJLGVBQWU7QUFDZiwwQkFBZSxDQUFDLEVBQUUsY0FBYztBQUNoQzs7O01BR1o7TUFTUSwrQ0FBK0MsZ0JBQThCO0FBQ2pGLGNBQU0sc0JBQXNCLEtBQUs7QUFDakMsWUFBSSxxQkFBcUI7QUFDckIsaUJBQU8sS0FBSywyQ0FBMkMsY0FBYzs7QUFHekUsWUFBSSxLQUFLLGlCQUFpQjtBQUN0QixpQkFBTyxLQUFLLHlCQUF5QixjQUFjOztBQUd2RCxjQUFNLGtCQUFrQixLQUFLO0FBQzdCLFlBQUksaUJBQWlCO0FBQ2pCLGVBQUssb0RBQW9ELGNBQWM7O0FBRzNFLGFBQUssMENBQTBDLGNBQWM7TUFDakU7TUFFUSxpQkFBaUIsVUFBa0I7QUFDdkMsWUFBSSxDQUFDLFNBQVMsU0FBUztBQUNuQixpQkFBTzs7QUFHWCxjQUFNLFVBQVVELE9BQU0sU0FBUyxPQUFPO0FBQ3RDLGNBQU0sTUFBTUEsT0FBSztBQUVqQixjQUFNLHFCQUFxQixRQUFRLFNBQVMsR0FBRztBQUMvQyxZQUFJLG9CQUFvQjtBQUNwQixpQkFBTzs7QUFHWCxjQUFNLDBCQUEwQixRQUFRLFNBQVMsSUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDO0FBQ25FLFlBQUkseUJBQXlCO0FBQ3pCLGlCQUFPOztBQUdYLGVBQU87TUFDWDtNQUtBLDJCQUF3QjtBQUNwQixlQUFPO01BQ1g7O3lCQWhKUyw2Q0FBMEM7TUFBQTtpRUFBMUMsNkNBQTBDLFdBQUEsQ0FBQSxDQUFBLDJDQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsNEJBQUEsOEJBQUEsUUFBQSxVQUFBLHVCQUFBLHlCQUFBLHFCQUFBLHNCQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLGVBQUEsMEJBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxVQUFBLHNCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsb0JBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLFlBQUEsVUFBQSxlQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsb0RBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUM1QnZELFVBQUEseUJBQUEsR0FBQSxtRUFBQSxHQUFBLENBQUEsRUFJQyxHQUFBLG1FQUFBLEdBQUEsQ0FBQTs7O0FBSkQsVUFBQSw0QkFBQSxHQUFBLEVBQUEsSUFBQSw4QkFBQSxPQUFBLE9BQUEsSUFBQSwyQkFBQSxVQUFBLElBQUEsQ0FBQTs7Ozs7cUZENEJhLDRDQUEwQyxFQUFBLFdBQUEsNkNBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFNUJ2RCxTQUFTLFlBQUFHLGlCQUFnQjs7QUFBekIsSUErQmE7QUEvQmI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFrQk0sSUFBTyxpQ0FBUCxNQUFPLGdDQUE4Qjs7eUJBQTlCLGlDQUE4QjtNQUFBO2dFQUE5QixnQ0FBOEIsQ0FBQTs7UUFkbkM7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7TUFBd0IsRUFBQSxDQUFBOzs7OyIsIm5hbWVzIjpbIk5nTW9kdWxlIiwiQ29tcG9uZW50IiwiSW5wdXQiLCJDb21wb25lbnQiLCJJbnB1dCIsImRheWpzIiwiZmFBbmdsZURvd24iLCJmYUFuZ2xlVXAiLCJOZ01vZHVsZSJdfQ==