import {
  DataTableComponent,
  init_data_table_component
} from "/chunk-KUURZL6B.js";
import {
  PROFILE_LOCALCI,
  init_app_constants
} from "/chunk-FM4KGV2V.js";
import {
  ArtemisDatePipe,
  CourseManagementService,
  JhiWebsocketService,
  ProfileService,
  TranslateDirective,
  __async,
  __esm,
  init_artemis_date_pipe,
  init_blob_util,
  init_course_management_service,
  init_profile_service,
  init_translate_directive,
  init_websocket_service,
  objectToJsonBlob
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/localci/build-queue/build-queue.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var BuildQueueService;
var init_build_queue_service = __esm({
  "src/main/webapp/app/localci/build-queue/build-queue.service.ts"() {
    BuildQueueService = class _BuildQueueService {
      http;
      resourceUrl = "api/build-job-queue";
      adminResourceUrl = "api/admin/build-job-queue";
      constructor(http) {
        this.http = http;
      }
      getQueuedBuildJobsByCourseId(courseId) {
        return this.http.get(`${this.resourceUrl}/queued/${courseId}`);
      }
      getRunningBuildJobsByCourseId(courseId) {
        return this.http.get(`${this.resourceUrl}/running/${courseId}`);
      }
      getQueuedBuildJobs() {
        return this.http.get(`${this.adminResourceUrl}/queued`);
      }
      getRunningBuildJobs() {
        return this.http.get(`${this.adminResourceUrl}/running`);
      }
      static \u0275fac = function BuildQueueService_Factory(t) {
        return new (t || _BuildQueueService)(i0.\u0275\u0275inject(i1.HttpClient));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _BuildQueueService, factory: _BuildQueueService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/localci/build-queue/build-queue.component.ts
import { Component } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i6 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@flaviosantoro92_ngx-datatable.js?v=1d0d9ead";
function BuildQueueComponent_ng_template_9_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_9_ng_template_5_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r22);
      const controls_r3 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r3.onSort("name"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 17);
    i02.\u0275\u0275text(4, " Name ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r3 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r3.iconForSortPropField("name"));
  }
}
function BuildQueueComponent_ng_template_9_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r24 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(value_r24);
  }
}
function BuildQueueComponent_ng_template_9_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_9_ng_template_12_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r27);
      const controls_r3 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r3.onSort("participationId"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 19);
    i02.\u0275\u0275text(4, " Participation ID ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r3 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r3.iconForSortPropField("participationId"));
  }
}
function BuildQueueComponent_ng_template_9_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r29 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(value_r29);
  }
}
function BuildQueueComponent_ng_template_9_ng_template_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_9_ng_template_19_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r32);
      const controls_r3 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r3.onSort("repositoryTypeOrUserName"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 20);
    i02.\u0275\u0275text(4, " Repository Type ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r3 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r3.iconForSortPropField("repositoryTypeOrUserName"));
  }
}
function BuildQueueComponent_ng_template_9_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r34 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(value_r34);
  }
}
function BuildQueueComponent_ng_template_9_ng_template_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r37 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_9_ng_template_26_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r37);
      const controls_r3 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r3.onSort("commitHash"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 21);
    i02.\u0275\u0275text(4, " Commit Hash ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r3 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r3.iconForSortPropField("commitHash"));
  }
}
function BuildQueueComponent_ng_template_9_ng_template_28_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 22);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r39 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(value_r39);
  }
}
function BuildQueueComponent_ng_template_9_ng_template_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r42 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_9_ng_template_33_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r42);
      const controls_r3 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r3.onSort("submissionDate"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 23);
    i02.\u0275\u0275text(4, " Submission Date ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r3 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r3.iconForSortPropField("submissionDate"));
  }
}
function BuildQueueComponent_ng_template_9_ng_template_35_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisDate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const value_r44 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind3(3, 1, value_r44, "long", true));
  }
}
function BuildQueueComponent_ng_template_9_ng_template_40_Template(rf, ctx) {
  if (rf & 1) {
    const _r47 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_9_ng_template_40_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r47);
      const controls_r3 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r3.onSort("buildStartDate"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 24);
    i02.\u0275\u0275text(4, " Build Start Date ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r3 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r3.iconForSortPropField("buildStartDate"));
  }
}
function BuildQueueComponent_ng_template_9_ng_template_42_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisDate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const value_r49 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind3(3, 1, value_r49, "long", true));
  }
}
function BuildQueueComponent_ng_template_9_ng_template_47_Template(rf, ctx) {
  if (rf & 1) {
    const _r52 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_9_ng_template_47_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r52);
      const controls_r3 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r3.onSort("courseId"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 25);
    i02.\u0275\u0275text(4, " Course ID ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r3 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r3.iconForSortPropField("courseId"));
  }
}
function BuildQueueComponent_ng_template_9_ng_template_49_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r54 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(value_r54);
  }
}
function BuildQueueComponent_ng_template_9_ng_template_54_Template(rf, ctx) {
  if (rf & 1) {
    const _r57 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_9_ng_template_54_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r57);
      const controls_r3 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r3.onSort("priority"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 26);
    i02.\u0275\u0275text(4, " Priority ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r3 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r3.iconForSortPropField("priority"));
  }
}
function BuildQueueComponent_ng_template_9_ng_template_56_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r59 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(value_r59);
  }
}
function BuildQueueComponent_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275elementStart(1, "ngx-datatable", 5);
    i02.\u0275\u0275text(2, "\n                ");
    i02.\u0275\u0275elementStart(3, "ngx-datatable-column", 6);
    i02.\u0275\u0275text(4, "\n                    ");
    i02.\u0275\u0275template(5, BuildQueueComponent_ng_template_9_ng_template_5_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(6, "\n                    ");
    i02.\u0275\u0275template(7, BuildQueueComponent_ng_template_9_ng_template_7_Template, 4, 1, "ng-template", 8);
    i02.\u0275\u0275text(8, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n                ");
    i02.\u0275\u0275elementStart(10, "ngx-datatable-column", 9);
    i02.\u0275\u0275text(11, "\n                    ");
    i02.\u0275\u0275template(12, BuildQueueComponent_ng_template_9_ng_template_12_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(13, "\n                    ");
    i02.\u0275\u0275template(14, BuildQueueComponent_ng_template_9_ng_template_14_Template, 4, 1, "ng-template", 8);
    i02.\u0275\u0275text(15, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(16, "\n                ");
    i02.\u0275\u0275elementStart(17, "ngx-datatable-column", 10);
    i02.\u0275\u0275text(18, "\n                    ");
    i02.\u0275\u0275template(19, BuildQueueComponent_ng_template_9_ng_template_19_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(20, "\n                    ");
    i02.\u0275\u0275template(21, BuildQueueComponent_ng_template_9_ng_template_21_Template, 4, 1, "ng-template", 8);
    i02.\u0275\u0275text(22, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(23, "\n                ");
    i02.\u0275\u0275elementStart(24, "ngx-datatable-column", 11);
    i02.\u0275\u0275text(25, "\n                    ");
    i02.\u0275\u0275template(26, BuildQueueComponent_ng_template_9_ng_template_26_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(27, "\n                    ");
    i02.\u0275\u0275template(28, BuildQueueComponent_ng_template_9_ng_template_28_Template, 4, 1, "ng-template", 8);
    i02.\u0275\u0275text(29, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(30, "\n                ");
    i02.\u0275\u0275elementStart(31, "ngx-datatable-column", 12);
    i02.\u0275\u0275text(32, "\n                    ");
    i02.\u0275\u0275template(33, BuildQueueComponent_ng_template_9_ng_template_33_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(34, "\n                    ");
    i02.\u0275\u0275template(35, BuildQueueComponent_ng_template_9_ng_template_35_Template, 5, 5, "ng-template", 8);
    i02.\u0275\u0275text(36, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(37, "\n                ");
    i02.\u0275\u0275elementStart(38, "ngx-datatable-column", 13);
    i02.\u0275\u0275text(39, "\n                    ");
    i02.\u0275\u0275template(40, BuildQueueComponent_ng_template_9_ng_template_40_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(41, "\n                    ");
    i02.\u0275\u0275template(42, BuildQueueComponent_ng_template_9_ng_template_42_Template, 5, 5, "ng-template", 8);
    i02.\u0275\u0275text(43, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(44, "\n                ");
    i02.\u0275\u0275elementStart(45, "ngx-datatable-column", 14);
    i02.\u0275\u0275text(46, "\n                    ");
    i02.\u0275\u0275template(47, BuildQueueComponent_ng_template_9_ng_template_47_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(48, "\n                    ");
    i02.\u0275\u0275template(49, BuildQueueComponent_ng_template_9_ng_template_49_Template, 4, 1, "ng-template", 8);
    i02.\u0275\u0275text(50, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(51, "\n                ");
    i02.\u0275\u0275elementStart(52, "ngx-datatable-column", 15);
    i02.\u0275\u0275text(53, "\n                    ");
    i02.\u0275\u0275template(54, BuildQueueComponent_ng_template_9_ng_template_54_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(55, "\n                    ");
    i02.\u0275\u0275template(56, BuildQueueComponent_ng_template_9_ng_template_56_Template, 4, 1, "ng-template", 8);
    i02.\u0275\u0275text(57, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(58, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(59, "\n        ");
  }
  if (rf & 2) {
    const settings_r2 = ctx.settings;
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("limit", settings_r2.limit)("sortType", settings_r2.sortType)("columnMode", settings_r2.columnMode)("headerHeight", settings_r2.headerHeight)("footerHeight", settings_r2.footerHeight)("rowHeight", settings_r2.rowHeight)("rows", settings_r2.rows)("rowClass", settings_r2.rowClass)("scrollbarH", settings_r2.scrollbarH);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 150)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 200);
  }
}
function BuildQueueComponent_ng_template_22_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r78 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_22_ng_template_5_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r78);
      const controls_r61 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r61.onSort("name"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 17);
    i02.\u0275\u0275text(4, " Name ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r61 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r61.iconForSortPropField("name"));
  }
}
function BuildQueueComponent_ng_template_22_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r80 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(value_r80);
  }
}
function BuildQueueComponent_ng_template_22_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r83 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_22_ng_template_12_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r83);
      const controls_r61 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r61.onSort("participationId"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 19);
    i02.\u0275\u0275text(4, " Participation ID ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r61 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r61.iconForSortPropField("participationId"));
  }
}
function BuildQueueComponent_ng_template_22_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r85 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(value_r85);
  }
}
function BuildQueueComponent_ng_template_22_ng_template_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r88 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_22_ng_template_19_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r88);
      const controls_r61 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r61.onSort("repositoryTypeOrUserName"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 20);
    i02.\u0275\u0275text(4, " Repository Type ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r61 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r61.iconForSortPropField("repositoryTypeOrUserName"));
  }
}
function BuildQueueComponent_ng_template_22_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r90 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(value_r90);
  }
}
function BuildQueueComponent_ng_template_22_ng_template_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r93 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_22_ng_template_26_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r93);
      const controls_r61 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r61.onSort("commitHash"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 21);
    i02.\u0275\u0275text(4, " Commit Hash ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r61 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r61.iconForSortPropField("commitHash"));
  }
}
function BuildQueueComponent_ng_template_22_ng_template_28_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 22);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r95 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(value_r95);
  }
}
function BuildQueueComponent_ng_template_22_ng_template_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r98 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_22_ng_template_33_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r98);
      const controls_r61 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r61.onSort("submissionDate"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 23);
    i02.\u0275\u0275text(4, " Submission Date ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r61 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r61.iconForSortPropField("submissionDate"));
  }
}
function BuildQueueComponent_ng_template_22_ng_template_35_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisDate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const value_r100 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind3(3, 1, value_r100, "long", true));
  }
}
function BuildQueueComponent_ng_template_22_ng_template_40_Template(rf, ctx) {
  if (rf & 1) {
    const _r103 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_22_ng_template_40_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r103);
      const controls_r61 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r61.onSort("courseId"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 25);
    i02.\u0275\u0275text(4, " Course ID ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r61 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r61.iconForSortPropField("courseId"));
  }
}
function BuildQueueComponent_ng_template_22_ng_template_42_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r105 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(value_r105);
  }
}
function BuildQueueComponent_ng_template_22_ng_template_47_Template(rf, ctx) {
  if (rf & 1) {
    const _r108 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 16);
    i02.\u0275\u0275listener("click", function BuildQueueComponent_ng_template_22_ng_template_47_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r108);
      const controls_r61 = i02.\u0275\u0275nextContext().controls;
      return i02.\u0275\u0275resetView(controls_r61.onSort("priority"));
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 26);
    i02.\u0275\u0275text(4, " Priority ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275element(6, "fa-icon", 18);
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r61 = i02.\u0275\u0275nextContext().controls;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275property("icon", controls_r61.iconForSortPropField("priority"));
  }
}
function BuildQueueComponent_ng_template_22_ng_template_49_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r110 = ctx.value;
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(value_r110);
  }
}
function BuildQueueComponent_ng_template_22_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275elementStart(1, "ngx-datatable", 5);
    i02.\u0275\u0275text(2, "\n                ");
    i02.\u0275\u0275elementStart(3, "ngx-datatable-column", 6);
    i02.\u0275\u0275text(4, "\n                    ");
    i02.\u0275\u0275template(5, BuildQueueComponent_ng_template_22_ng_template_5_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(6, "\n                    ");
    i02.\u0275\u0275template(7, BuildQueueComponent_ng_template_22_ng_template_7_Template, 4, 1, "ng-template", 8);
    i02.\u0275\u0275text(8, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n                ");
    i02.\u0275\u0275elementStart(10, "ngx-datatable-column", 9);
    i02.\u0275\u0275text(11, "\n                    ");
    i02.\u0275\u0275template(12, BuildQueueComponent_ng_template_22_ng_template_12_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(13, "\n                    ");
    i02.\u0275\u0275template(14, BuildQueueComponent_ng_template_22_ng_template_14_Template, 4, 1, "ng-template", 8);
    i02.\u0275\u0275text(15, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(16, "\n                ");
    i02.\u0275\u0275elementStart(17, "ngx-datatable-column", 10);
    i02.\u0275\u0275text(18, "\n                    ");
    i02.\u0275\u0275template(19, BuildQueueComponent_ng_template_22_ng_template_19_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(20, "\n                    ");
    i02.\u0275\u0275template(21, BuildQueueComponent_ng_template_22_ng_template_21_Template, 4, 1, "ng-template", 8);
    i02.\u0275\u0275text(22, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(23, "\n                ");
    i02.\u0275\u0275elementStart(24, "ngx-datatable-column", 11);
    i02.\u0275\u0275text(25, "\n                    ");
    i02.\u0275\u0275template(26, BuildQueueComponent_ng_template_22_ng_template_26_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(27, "\n                    ");
    i02.\u0275\u0275template(28, BuildQueueComponent_ng_template_22_ng_template_28_Template, 4, 1, "ng-template", 8);
    i02.\u0275\u0275text(29, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(30, "\n                ");
    i02.\u0275\u0275elementStart(31, "ngx-datatable-column", 12);
    i02.\u0275\u0275text(32, "\n                    ");
    i02.\u0275\u0275template(33, BuildQueueComponent_ng_template_22_ng_template_33_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(34, "\n                    ");
    i02.\u0275\u0275template(35, BuildQueueComponent_ng_template_22_ng_template_35_Template, 5, 5, "ng-template", 8);
    i02.\u0275\u0275text(36, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(37, "\n                ");
    i02.\u0275\u0275elementStart(38, "ngx-datatable-column", 14);
    i02.\u0275\u0275text(39, "\n                    ");
    i02.\u0275\u0275template(40, BuildQueueComponent_ng_template_22_ng_template_40_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(41, "\n                    ");
    i02.\u0275\u0275template(42, BuildQueueComponent_ng_template_22_ng_template_42_Template, 4, 1, "ng-template", 8);
    i02.\u0275\u0275text(43, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(44, "\n                ");
    i02.\u0275\u0275elementStart(45, "ngx-datatable-column", 15);
    i02.\u0275\u0275text(46, "\n                    ");
    i02.\u0275\u0275template(47, BuildQueueComponent_ng_template_22_ng_template_47_Template, 9, 1, "ng-template", 7);
    i02.\u0275\u0275text(48, "\n                    ");
    i02.\u0275\u0275template(49, BuildQueueComponent_ng_template_22_ng_template_49_Template, 4, 1, "ng-template", 8);
    i02.\u0275\u0275text(50, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(51, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(52, "\n        ");
  }
  if (rf & 2) {
    const settings_r60 = ctx.settings;
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("limit", settings_r60.limit)("sortType", settings_r60.sortType)("columnMode", settings_r60.columnMode)("headerHeight", settings_r60.headerHeight)("footerHeight", settings_r60.footerHeight)("rowHeight", settings_r60.rowHeight)("rows", settings_r60.rows)("rowClass", settings_r60.rowClass)("scrollbarH", settings_r60.scrollbarH);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 150)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275property("minWidth", 150)("width", 200);
  }
}
var BuildQueueComponent;
var init_build_queue_component = __esm({
  "src/main/webapp/app/localci/build-queue/build-queue.component.ts"() {
    init_websocket_service();
    init_build_queue_service();
    init_websocket_service();
    init_build_queue_service();
    init_translate_directive();
    init_data_table_component();
    init_artemis_date_pipe();
    BuildQueueComponent = class _BuildQueueComponent {
      route;
      websocketService;
      buildQueueService;
      queuedBuildJobs;
      runningBuildJobs;
      courseChannels = [];
      constructor(route, websocketService, buildQueueService) {
        this.route = route;
        this.websocketService = websocketService;
        this.buildQueueService = buildQueueService;
      }
      ngOnInit() {
        this.load();
        this.initWebsocketSubscription();
      }
      ngOnDestroy() {
        this.websocketService.unsubscribe(`/topic/admin/queued-jobs`);
        this.websocketService.unsubscribe(`/topic/admin/running-jobs`);
        this.courseChannels.forEach((channel) => {
          this.websocketService.unsubscribe(channel);
        });
      }
      initWebsocketSubscription() {
        this.route.paramMap.subscribe((params) => {
          const courseId = Number(params.get("courseId"));
          if (courseId) {
            this.websocketService.subscribe(`/topic/courses/${courseId}/queued-jobs`);
            this.websocketService.subscribe(`/topic/courses/${courseId}/running-jobs`);
            this.websocketService.receive(`/topic/courses/${courseId}/queued-jobs`).subscribe((queuedBuildJobs) => {
              this.queuedBuildJobs = queuedBuildJobs;
            });
            this.websocketService.receive(`/topic/courses/${courseId}/running-jobs`).subscribe((runningBuildJobs) => {
              this.runningBuildJobs = runningBuildJobs;
            });
            this.courseChannels.push(`/topic/courses/${courseId}/queued-jobs`);
            this.courseChannels.push(`/topic/courses/${courseId}/running-jobs`);
          } else {
            this.websocketService.subscribe(`/topic/admin/queued-jobs`);
            this.websocketService.subscribe(`/topic/admin/running-jobs`);
            this.websocketService.receive(`/topic/admin/queued-jobs`).subscribe((queuedBuildJobs) => {
              this.queuedBuildJobs = queuedBuildJobs;
            });
            this.websocketService.receive(`/topic/admin/running-jobs`).subscribe((runningBuildJobs) => {
              this.runningBuildJobs = runningBuildJobs;
            });
          }
        });
      }
      load() {
        this.route.paramMap.subscribe((params) => {
          const courseId = Number(params.get("courseId"));
          if (courseId) {
            this.buildQueueService.getQueuedBuildJobsByCourseId(courseId).subscribe((queuedBuildJobs) => {
              this.queuedBuildJobs = queuedBuildJobs;
            });
            this.buildQueueService.getRunningBuildJobsByCourseId(courseId).subscribe((runningBuildJobs) => {
              this.runningBuildJobs = runningBuildJobs;
            });
          } else {
            this.buildQueueService.getQueuedBuildJobs().subscribe((queuedBuildJobs) => {
              this.queuedBuildJobs = queuedBuildJobs;
            });
            this.buildQueueService.getRunningBuildJobs().subscribe((runningBuildJobs) => {
              this.runningBuildJobs = runningBuildJobs;
            });
          }
        });
      }
      static \u0275fac = function BuildQueueComponent_Factory(t) {
        return new (t || _BuildQueueComponent)(i02.\u0275\u0275directiveInject(i12.ActivatedRoute), i02.\u0275\u0275directiveInject(JhiWebsocketService), i02.\u0275\u0275directiveInject(BuildQueueService));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _BuildQueueComponent, selectors: [["jhi-build-queue"]], decls: 26, vars: 6, consts: [[2, "padding-bottom", "60px"], ["id", "build-queue-running-heading", "jhiTranslate", "artemisApp.buildQueue.runningBuildJobs"], [1, "d-flex", "justify-content-between", "align-items-center", "border-bottom", "pb-2", "mb-3"], ["entityType", "buildJob", 3, "showPageSizeDropdown", "showSearchField", "allEntities"], ["id", "build-queue-queued-heading", "jhiTranslate", "artemisApp.buildQueue.queuedBuildJobs"], [1, "bootstrap", 3, "limit", "sortType", "columnMode", "headerHeight", "footerHeight", "rowHeight", "rows", "rowClass", "scrollbarH"], ["prop", "name", 3, "minWidth", "width", "maxWidth"], ["ngx-datatable-header-template", ""], ["ngx-datatable-cell-template", ""], ["prop", "participationId", 3, "minWidth", "width", "maxWidth"], ["prop", "repositoryTypeOrUserName", 3, "minWidth", "width", "maxWidth"], ["prop", "commitHash", 3, "minWidth", "width", "maxWidth"], ["prop", "submissionDate", 3, "minWidth", "width", "maxWidth"], ["prop", "buildStartDate", 3, "minWidth", "width", "maxWidth"], ["prop", "courseId", 3, "minWidth", "width", "maxWidth"], ["prop", "priority", 3, "minWidth", "width"], [1, "datatable-header-cell-wrapper", 3, "click"], ["jhiTranslate", "artemisApp.buildQueue.buildJob.name", 1, "datatable-header-cell-label", "bold", "sortable"], [3, "icon"], ["jhiTranslate", "artemisApp.buildQueue.buildJob.participationId", 1, "datatable-header-cell-label", "bold", "sortable"], ["jhiTranslate", "artemisApp.buildQueue.buildJob.repositoryType", 1, "datatable-header-cell-label", "bold", "sortable"], ["jhiTranslate", "artemisApp.buildQueue.buildJob.commitHash", 1, "datatable-header-cell-label", "bold", "sortable"], [1, "wrap-long-text"], ["jhiTranslate", "artemisApp.buildQueue.buildJob.submissionDate", 1, "datatable-header-cell-label", "bold", "sortable"], ["jhiTranslate", "artemisApp.buildQueue.buildJob.buildStartDate", 1, "datatable-header-cell-label", "bold", "sortable"], ["jhiTranslate", "artemisApp.buildQueue.buildJob.courseId", 1, "datatable-header-cell-label", "bold", "sortable"], ["jhiTranslate", "artemisApp.buildQueue.buildJob.priority", 1, "datatable-header-cell-label", "bold", "sortable"]], template: function BuildQueueComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div", 0);
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275elementStart(2, "h3", 1);
          i02.\u0275\u0275text(3, "Running build jobs");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(4, "\n    ");
          i02.\u0275\u0275element(5, "div", 2);
          i02.\u0275\u0275text(6, "\n    ");
          i02.\u0275\u0275elementStart(7, "jhi-data-table", 3);
          i02.\u0275\u0275text(8, "\n        ");
          i02.\u0275\u0275template(9, BuildQueueComponent_ng_template_9_Template, 60, 32, "ng-template");
          i02.\u0275\u0275text(10, "\n    ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(11, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(12, "\n");
          i02.\u0275\u0275elementStart(13, "div");
          i02.\u0275\u0275text(14, "\n    ");
          i02.\u0275\u0275elementStart(15, "h3", 4);
          i02.\u0275\u0275text(16, "Queued build jobs");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(17, "\n    ");
          i02.\u0275\u0275element(18, "div", 2);
          i02.\u0275\u0275text(19, "\n    ");
          i02.\u0275\u0275elementStart(20, "jhi-data-table", 3);
          i02.\u0275\u0275text(21, "\n        ");
          i02.\u0275\u0275template(22, BuildQueueComponent_ng_template_22_Template, 53, 29, "ng-template");
          i02.\u0275\u0275text(23, "\n    ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(24, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(25, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(7);
          i02.\u0275\u0275property("showPageSizeDropdown", false)("showSearchField", false)("allEntities", ctx.runningBuildJobs);
          i02.\u0275\u0275advance(13);
          i02.\u0275\u0275property("showPageSizeDropdown", false)("showSearchField", false)("allEntities", ctx.queuedBuildJobs);
        }
      }, dependencies: [i4.FaIconComponent, TranslateDirective, i6.DatatableComponent, i6.DataTableColumnDirective, i6.DataTableColumnHeaderDirective, i6.DataTableColumnCellDirective, DataTableComponent, ArtemisDatePipe], styles: ["\n\n.wrap-long-text[_ngcontent-%COMP%] {\n  word-break: break-all;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9sb2NhbGNpL2J1aWxkLXF1ZXVlL2J1aWxkLXF1ZXVlLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIud3JhcC1sb25nLXRleHQge1xuICAgIHdvcmQtYnJlYWs6IGJyZWFrLWFsbDsgLyogVGhpcyB3aWxsIGJyZWFrIHRoZSB0ZXh0IGF0IGFueSBjaGFyYWN0ZXIgKi9cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksY0FBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(BuildQueueComponent, { className: "BuildQueueComponent" });
    })();
  }
});

// src/main/webapp/app/course/manage/course-admin.service.ts
import { Injectable as Injectable2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient as HttpClient3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var CourseAdminService;
var init_course_admin_service = __esm({
  "src/main/webapp/app/course/manage/course-admin.service.ts"() {
    init_blob_util();
    init_course_management_service();
    init_course_management_service();
    CourseAdminService = class _CourseAdminService {
      http;
      courseManagementService;
      resourceUrl = "api/admin/courses";
      constructor(http, courseManagementService) {
        this.http = http;
        this.courseManagementService = courseManagementService;
      }
      getAllGroupsForAllCourses() {
        return this.http.get(this.resourceUrl + "/groups", { observe: "response" });
      }
      create(course, courseImage) {
        const copy = CourseManagementService.convertCourseDatesFromClient(course);
        const formData = new FormData();
        formData.append("course", objectToJsonBlob(copy));
        if (courseImage) {
          formData.append("file", courseImage, "placeholderName.png");
        }
        return this.http.post(this.resourceUrl, formData, { observe: "response" }).pipe(map((res) => this.courseManagementService.processCourseEntityResponseType(res)));
      }
      delete(courseId) {
        return this.http.delete(`${this.resourceUrl}/${courseId}`, { observe: "response" });
      }
      static \u0275fac = function CourseAdminService_Factory(t) {
        return new (t || _CourseAdminService)(i03.\u0275\u0275inject(i13.HttpClient), i03.\u0275\u0275inject(CourseManagementService));
      };
      static \u0275prov = i03.\u0275\u0275defineInjectable({ token: _CourseAdminService, factory: _CourseAdminService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/localci/build-queue/build-queue.guard.ts
import { Injectable as Injectable3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
var BuildQueueGuard;
var init_build_queue_guard = __esm({
  "src/main/webapp/app/localci/build-queue/build-queue.guard.ts"() {
    init_profile_service();
    init_app_constants();
    init_profile_service();
    BuildQueueGuard = class _BuildQueueGuard {
      profileService;
      router;
      localCIActive = false;
      constructor(profileService, router) {
        this.profileService = profileService;
        this.router = router;
      }
      canActivate() {
        return __async(this, null, function* () {
          this.profileService.getProfileInfo().subscribe((profileInfo) => {
            if (profileInfo) {
              this.localCIActive = profileInfo?.activeProfiles.includes(PROFILE_LOCALCI);
            }
          });
          if (!this.localCIActive) {
            this.router.navigate(["/course-management"]);
            return false;
          }
          return true;
        });
      }
      static \u0275fac = function BuildQueueGuard_Factory(t) {
        return new (t || _BuildQueueGuard)(i04.\u0275\u0275inject(ProfileService), i04.\u0275\u0275inject(i2.Router));
      };
      static \u0275prov = i04.\u0275\u0275defineInjectable({ token: _BuildQueueGuard, factory: _BuildQueueGuard.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  CourseAdminService,
  init_course_admin_service,
  BuildQueueComponent,
  init_build_queue_component,
  BuildQueueGuard,
  init_build_queue_guard
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvbG9jYWxjaS9idWlsZC1xdWV1ZS9idWlsZC1xdWV1ZS5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9sb2NhbGNpL2J1aWxkLXF1ZXVlL2J1aWxkLXF1ZXVlLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvbG9jYWxjaS9idWlsZC1xdWV1ZS9idWlsZC1xdWV1ZS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL21hbmFnZS9jb3Vyc2UtYWRtaW4uc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvbG9jYWxjaS9idWlsZC1xdWV1ZS9idWlsZC1xdWV1ZS5ndWFyZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuXG5pbXBvcnQgeyBCdWlsZEpvYiB9IGZyb20gJ2FwcC9lbnRpdGllcy9idWlsZC1qb2IubW9kZWwnO1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIEJ1aWxkUXVldWVTZXJ2aWNlIHtcbiAgICBwdWJsaWMgcmVzb3VyY2VVcmwgPSAnYXBpL2J1aWxkLWpvYi1xdWV1ZSc7XG4gICAgcHVibGljIGFkbWluUmVzb3VyY2VVcmwgPSAnYXBpL2FkbWluL2J1aWxkLWpvYi1xdWV1ZSc7XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQpIHt9XG4gICAgLyoqXG4gICAgICogR2V0IGFsbCBidWlsZCBqb2JzIG9mIGEgY291cnNlIGluIHRoZSBxdWV1ZVxuICAgICAqIEBwYXJhbSBjb3Vyc2VJZFxuICAgICAqL1xuICAgIGdldFF1ZXVlZEJ1aWxkSm9ic0J5Q291cnNlSWQoY291cnNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8QnVpbGRKb2JbXT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxCdWlsZEpvYltdPihgJHt0aGlzLnJlc291cmNlVXJsfS9xdWV1ZWQvJHtjb3Vyc2VJZH1gKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgYWxsIHJ1bm5pbmcgYnVpbGQgam9icyBvZiBhIGNvdXJzZVxuICAgICAqIEBwYXJhbSBjb3Vyc2VJZFxuICAgICAqL1xuICAgIGdldFJ1bm5pbmdCdWlsZEpvYnNCeUNvdXJzZUlkKGNvdXJzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEJ1aWxkSm9iW10+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8QnVpbGRKb2JbXT4oYCR7dGhpcy5yZXNvdXJjZVVybH0vcnVubmluZy8ke2NvdXJzZUlkfWApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBhbGwgYnVpbGQgam9icyBpbiB0aGUgcXVldWVcbiAgICAgKi9cbiAgICBnZXRRdWV1ZWRCdWlsZEpvYnMoKTogT2JzZXJ2YWJsZTxCdWlsZEpvYltdPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PEJ1aWxkSm9iW10+KGAke3RoaXMuYWRtaW5SZXNvdXJjZVVybH0vcXVldWVkYCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGFsbCBydW5uaW5nIGJ1aWxkIGpvYnNcbiAgICAgKi9cbiAgICBnZXRSdW5uaW5nQnVpbGRKb2JzKCk6IE9ic2VydmFibGU8QnVpbGRKb2JbXT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxCdWlsZEpvYltdPihgJHt0aGlzLmFkbWluUmVzb3VyY2VVcmx9L3J1bm5pbmdgKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uRGVzdHJveSwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBCdWlsZEpvYiB9IGZyb20gJ2FwcC9lbnRpdGllcy9idWlsZC1qb2IubW9kZWwnO1xuaW1wb3J0IHsgSmhpV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3dlYnNvY2tldC93ZWJzb2NrZXQuc2VydmljZSc7XG5pbXBvcnQgeyBCdWlsZFF1ZXVlU2VydmljZSB9IGZyb20gJ2FwcC9sb2NhbGNpL2J1aWxkLXF1ZXVlL2J1aWxkLXF1ZXVlLnNlcnZpY2UnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1idWlsZC1xdWV1ZScsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2J1aWxkLXF1ZXVlLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybDogJy4vYnVpbGQtcXVldWUuY29tcG9uZW50LnNjc3MnLFxufSlcbmV4cG9ydCBjbGFzcyBCdWlsZFF1ZXVlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xuICAgIHF1ZXVlZEJ1aWxkSm9iczogQnVpbGRKb2JbXTtcbiAgICBydW5uaW5nQnVpbGRKb2JzOiBCdWlsZEpvYltdO1xuICAgIGNvdXJzZUNoYW5uZWxzOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgICAgICBwcml2YXRlIHdlYnNvY2tldFNlcnZpY2U6IEpoaVdlYnNvY2tldFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgYnVpbGRRdWV1ZVNlcnZpY2U6IEJ1aWxkUXVldWVTZXJ2aWNlLFxuICAgICkge31cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICB0aGlzLmxvYWQoKTtcbiAgICAgICAgdGhpcy5pbml0V2Vic29ja2V0U3Vic2NyaXB0aW9uKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVGhpcyBtZXRob2QgaXMgdXNlZCB0byB1bnN1YnNjcmliZSBmcm9tIHRoZSB3ZWJzb2NrZXQgY2hhbm5lbHMgd2hlbiB0aGUgY29tcG9uZW50IGlzIGRlc3Ryb3llZC5cbiAgICAgKi9cbiAgICBuZ09uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy53ZWJzb2NrZXRTZXJ2aWNlLnVuc3Vic2NyaWJlKGAvdG9waWMvYWRtaW4vcXVldWVkLWpvYnNgKTtcbiAgICAgICAgdGhpcy53ZWJzb2NrZXRTZXJ2aWNlLnVuc3Vic2NyaWJlKGAvdG9waWMvYWRtaW4vcnVubmluZy1qb2JzYCk7XG4gICAgICAgIHRoaXMuY291cnNlQ2hhbm5lbHMuZm9yRWFjaCgoY2hhbm5lbCkgPT4ge1xuICAgICAgICAgICAgdGhpcy53ZWJzb2NrZXRTZXJ2aWNlLnVuc3Vic2NyaWJlKGNoYW5uZWwpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUaGlzIG1ldGhvZCBpcyB1c2VkIHRvIGluaXRpYWxpemUgdGhlIHdlYnNvY2tldCBzdWJzY3JpcHRpb24gZm9yIHRoZSBidWlsZCBqb2JzLiBJdCBzdWJzY3JpYmVzIHRvIHRoZSBjaGFubmVscyBmb3IgdGhlIHF1ZXVlZCBhbmQgcnVubmluZyBidWlsZCBqb2JzLlxuICAgICAqL1xuICAgIGluaXRXZWJzb2NrZXRTdWJzY3JpcHRpb24oKSB7XG4gICAgICAgIHRoaXMucm91dGUucGFyYW1NYXAuc3Vic2NyaWJlKChwYXJhbXMpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNvdXJzZUlkID0gTnVtYmVyKHBhcmFtcy5nZXQoJ2NvdXJzZUlkJykpO1xuICAgICAgICAgICAgaWYgKGNvdXJzZUlkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy53ZWJzb2NrZXRTZXJ2aWNlLnN1YnNjcmliZShgL3RvcGljL2NvdXJzZXMvJHtjb3Vyc2VJZH0vcXVldWVkLWpvYnNgKTtcbiAgICAgICAgICAgICAgICB0aGlzLndlYnNvY2tldFNlcnZpY2Uuc3Vic2NyaWJlKGAvdG9waWMvY291cnNlcy8ke2NvdXJzZUlkfS9ydW5uaW5nLWpvYnNgKTtcbiAgICAgICAgICAgICAgICB0aGlzLndlYnNvY2tldFNlcnZpY2UucmVjZWl2ZShgL3RvcGljL2NvdXJzZXMvJHtjb3Vyc2VJZH0vcXVldWVkLWpvYnNgKS5zdWJzY3JpYmUoKHF1ZXVlZEJ1aWxkSm9icykgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnF1ZXVlZEJ1aWxkSm9icyA9IHF1ZXVlZEJ1aWxkSm9icztcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB0aGlzLndlYnNvY2tldFNlcnZpY2UucmVjZWl2ZShgL3RvcGljL2NvdXJzZXMvJHtjb3Vyc2VJZH0vcnVubmluZy1qb2JzYCkuc3Vic2NyaWJlKChydW5uaW5nQnVpbGRKb2JzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucnVubmluZ0J1aWxkSm9icyA9IHJ1bm5pbmdCdWlsZEpvYnM7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdGhpcy5jb3Vyc2VDaGFubmVscy5wdXNoKGAvdG9waWMvY291cnNlcy8ke2NvdXJzZUlkfS9xdWV1ZWQtam9ic2ApO1xuICAgICAgICAgICAgICAgIHRoaXMuY291cnNlQ2hhbm5lbHMucHVzaChgL3RvcGljL2NvdXJzZXMvJHtjb3Vyc2VJZH0vcnVubmluZy1qb2JzYCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMud2Vic29ja2V0U2VydmljZS5zdWJzY3JpYmUoYC90b3BpYy9hZG1pbi9xdWV1ZWQtam9ic2ApO1xuICAgICAgICAgICAgICAgIHRoaXMud2Vic29ja2V0U2VydmljZS5zdWJzY3JpYmUoYC90b3BpYy9hZG1pbi9ydW5uaW5nLWpvYnNgKTtcbiAgICAgICAgICAgICAgICB0aGlzLndlYnNvY2tldFNlcnZpY2UucmVjZWl2ZShgL3RvcGljL2FkbWluL3F1ZXVlZC1qb2JzYCkuc3Vic2NyaWJlKChxdWV1ZWRCdWlsZEpvYnMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5xdWV1ZWRCdWlsZEpvYnMgPSBxdWV1ZWRCdWlsZEpvYnM7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdGhpcy53ZWJzb2NrZXRTZXJ2aWNlLnJlY2VpdmUoYC90b3BpYy9hZG1pbi9ydW5uaW5nLWpvYnNgKS5zdWJzY3JpYmUoKHJ1bm5pbmdCdWlsZEpvYnMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ydW5uaW5nQnVpbGRKb2JzID0gcnVubmluZ0J1aWxkSm9icztcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVGhpcyBtZXRob2QgaXMgdXNlZCB0byBsb2FkIHRoZSBidWlsZCBqb2JzIGZyb20gdGhlIGJhY2tlbmQgd2hlbiB0aGUgY29tcG9uZW50IGlzIGluaXRpYWxpemVkLlxuICAgICAqIFRoaXMgZW5zdXJlcyB0aGF0IHRoZSB0YWJsZSBpcyBmaWxsZWQgd2l0aCBkYXRhIHdoZW4gdGhlIHBhZ2UgaXMgbG9hZGVkIG9yIHJlZnJlc2hlZCBvdGhlcndpc2UgdGhlIHVzZXIgbmVlZHMgdG9cbiAgICAgKiB3YWl0IHVudGlsIHRoZSB3ZWJzb2NrZXQgc3Vic2NyaXB0aW9uIHJlY2VpdmVzIHRoZSBkYXRhLlxuICAgICAqL1xuICAgIGxvYWQoKSB7XG4gICAgICAgIHRoaXMucm91dGUucGFyYW1NYXAuc3Vic2NyaWJlKChwYXJhbXMpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNvdXJzZUlkID0gTnVtYmVyKHBhcmFtcy5nZXQoJ2NvdXJzZUlkJykpO1xuICAgICAgICAgICAgaWYgKGNvdXJzZUlkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5idWlsZFF1ZXVlU2VydmljZS5nZXRRdWV1ZWRCdWlsZEpvYnNCeUNvdXJzZUlkKGNvdXJzZUlkKS5zdWJzY3JpYmUoKHF1ZXVlZEJ1aWxkSm9icykgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnF1ZXVlZEJ1aWxkSm9icyA9IHF1ZXVlZEJ1aWxkSm9icztcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB0aGlzLmJ1aWxkUXVldWVTZXJ2aWNlLmdldFJ1bm5pbmdCdWlsZEpvYnNCeUNvdXJzZUlkKGNvdXJzZUlkKS5zdWJzY3JpYmUoKHJ1bm5pbmdCdWlsZEpvYnMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ydW5uaW5nQnVpbGRKb2JzID0gcnVubmluZ0J1aWxkSm9icztcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5idWlsZFF1ZXVlU2VydmljZS5nZXRRdWV1ZWRCdWlsZEpvYnMoKS5zdWJzY3JpYmUoKHF1ZXVlZEJ1aWxkSm9icykgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnF1ZXVlZEJ1aWxkSm9icyA9IHF1ZXVlZEJ1aWxkSm9icztcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB0aGlzLmJ1aWxkUXVldWVTZXJ2aWNlLmdldFJ1bm5pbmdCdWlsZEpvYnMoKS5zdWJzY3JpYmUoKHJ1bm5pbmdCdWlsZEpvYnMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ydW5uaW5nQnVpbGRKb2JzID0gcnVubmluZ0J1aWxkSm9icztcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiPGRpdiBzdHlsZT1cInBhZGRpbmctYm90dG9tOiA2MHB4XCI+XG4gICAgPGgzIGlkPVwiYnVpbGQtcXVldWUtcnVubmluZy1oZWFkaW5nXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5idWlsZFF1ZXVlLnJ1bm5pbmdCdWlsZEpvYnNcIj5SdW5uaW5nIGJ1aWxkIGpvYnM8L2gzPlxuICAgIDxkaXYgY2xhc3M9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW4gYWxpZ24taXRlbXMtY2VudGVyIGJvcmRlci1ib3R0b20gcGItMiBtYi0zXCI+PC9kaXY+XG4gICAgPGpoaS1kYXRhLXRhYmxlIFtzaG93UGFnZVNpemVEcm9wZG93bl09XCJmYWxzZVwiIFtzaG93U2VhcmNoRmllbGRdPVwiZmFsc2VcIiBlbnRpdHlUeXBlPVwiYnVpbGRKb2JcIiBbYWxsRW50aXRpZXNdPVwicnVubmluZ0J1aWxkSm9icyFcIj5cbiAgICAgICAgPG5nLXRlbXBsYXRlIGxldC1zZXR0aW5ncz1cInNldHRpbmdzXCIgbGV0LWNvbnRyb2xzPVwiY29udHJvbHNcIj5cbiAgICAgICAgICAgIDxuZ3gtZGF0YXRhYmxlXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJib290c3RyYXBcIlxuICAgICAgICAgICAgICAgIFtsaW1pdF09XCJzZXR0aW5ncy5saW1pdFwiXG4gICAgICAgICAgICAgICAgW3NvcnRUeXBlXT1cInNldHRpbmdzLnNvcnRUeXBlXCJcbiAgICAgICAgICAgICAgICBbY29sdW1uTW9kZV09XCJzZXR0aW5ncy5jb2x1bW5Nb2RlXCJcbiAgICAgICAgICAgICAgICBbaGVhZGVySGVpZ2h0XT1cInNldHRpbmdzLmhlYWRlckhlaWdodFwiXG4gICAgICAgICAgICAgICAgW2Zvb3RlckhlaWdodF09XCJzZXR0aW5ncy5mb290ZXJIZWlnaHRcIlxuICAgICAgICAgICAgICAgIFtyb3dIZWlnaHRdPVwic2V0dGluZ3Mucm93SGVpZ2h0XCJcbiAgICAgICAgICAgICAgICBbcm93c109XCJzZXR0aW5ncy5yb3dzXCJcbiAgICAgICAgICAgICAgICBbcm93Q2xhc3NdPVwic2V0dGluZ3Mucm93Q2xhc3NcIlxuICAgICAgICAgICAgICAgIFtzY3JvbGxiYXJIXT1cInNldHRpbmdzLnNjcm9sbGJhckhcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxuZ3gtZGF0YXRhYmxlLWNvbHVtbiBwcm9wPVwibmFtZVwiIFttaW5XaWR0aF09XCIxNTBcIiBbd2lkdGhdPVwiMjAwXCIgW21heFdpZHRoXT1cIjIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVyXCIgKGNsaWNrKT1cImNvbnRyb2xzLm9uU29ydCgnbmFtZScpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtbGFiZWwgYm9sZCBzb3J0YWJsZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYnVpbGRRdWV1ZS5idWlsZEpvYi5uYW1lXCI+IE5hbWUgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImNvbnRyb2xzLmljb25Gb3JTb3J0UHJvcEZpZWxkKCduYW1lJylcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwidmFsdWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IHZhbHVlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XG4gICAgICAgICAgICAgICAgPG5neC1kYXRhdGFibGUtY29sdW1uIHByb3A9XCJwYXJ0aWNpcGF0aW9uSWRcIiBbbWluV2lkdGhdPVwiMTUwXCIgW3dpZHRoXT1cIjE1MFwiIFttYXhXaWR0aF09XCIyMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtaGVhZGVyLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtd3JhcHBlclwiIChjbGljayk9XCJjb250cm9scy5vblNvcnQoJ3BhcnRpY2lwYXRpb25JZCcpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtbGFiZWwgYm9sZCBzb3J0YWJsZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYnVpbGRRdWV1ZS5idWlsZEpvYi5wYXJ0aWNpcGF0aW9uSWRcIj4gUGFydGljaXBhdGlvbiBJRCA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiY29udHJvbHMuaWNvbkZvclNvcnRQcm9wRmllbGQoJ3BhcnRpY2lwYXRpb25JZCcpXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1jZWxsLXRlbXBsYXRlIGxldC12YWx1ZT1cInZhbHVlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyB2YWx1ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICA8L25neC1kYXRhdGFibGUtY29sdW1uPlxuICAgICAgICAgICAgICAgIDxuZ3gtZGF0YXRhYmxlLWNvbHVtbiBwcm9wPVwicmVwb3NpdG9yeVR5cGVPclVzZXJOYW1lXCIgW21pbldpZHRoXT1cIjE1MFwiIFt3aWR0aF09XCIyMDBcIiBbbWF4V2lkdGhdPVwiMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWhlYWRlci10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLXdyYXBwZXJcIiAoY2xpY2spPVwiY29udHJvbHMub25Tb3J0KCdyZXBvc2l0b3J5VHlwZU9yVXNlck5hbWUnKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLWxhYmVsIGJvbGQgc29ydGFibGVcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmJ1aWxkUXVldWUuYnVpbGRKb2IucmVwb3NpdG9yeVR5cGVcIj4gUmVwb3NpdG9yeSBUeXBlIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJjb250cm9scy5pY29uRm9yU29ydFByb3BGaWVsZCgncmVwb3NpdG9yeVR5cGVPclVzZXJOYW1lJylcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwidmFsdWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IHZhbHVlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XG4gICAgICAgICAgICAgICAgPG5neC1kYXRhdGFibGUtY29sdW1uIHByb3A9XCJjb21taXRIYXNoXCIgW21pbldpZHRoXT1cIjE1MFwiIFt3aWR0aF09XCIyMDBcIiBbbWF4V2lkdGhdPVwiMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWhlYWRlci10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLXdyYXBwZXJcIiAoY2xpY2spPVwiY29udHJvbHMub25Tb3J0KCdjb21taXRIYXNoJylcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC1sYWJlbCBib2xkIHNvcnRhYmxlXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5idWlsZFF1ZXVlLmJ1aWxkSm9iLmNvbW1pdEhhc2hcIj4gQ29tbWl0IEhhc2ggPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImNvbnRyb2xzLmljb25Gb3JTb3J0UHJvcEZpZWxkKCdjb21taXRIYXNoJylcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwidmFsdWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwid3JhcC1sb25nLXRleHRcIj57eyB2YWx1ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICA8L25neC1kYXRhdGFibGUtY29sdW1uPlxuICAgICAgICAgICAgICAgIDxuZ3gtZGF0YXRhYmxlLWNvbHVtbiBwcm9wPVwic3VibWlzc2lvbkRhdGVcIiBbbWluV2lkdGhdPVwiMTUwXCIgW3dpZHRoXT1cIjIwMFwiIFttYXhXaWR0aF09XCIyMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtaGVhZGVyLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtd3JhcHBlclwiIChjbGljayk9XCJjb250cm9scy5vblNvcnQoJ3N1Ym1pc3Npb25EYXRlJylcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC1sYWJlbCBib2xkIHNvcnRhYmxlXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5idWlsZFF1ZXVlLmJ1aWxkSm9iLnN1Ym1pc3Npb25EYXRlXCI+IFN1Ym1pc3Npb24gRGF0ZSA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiY29udHJvbHMuaWNvbkZvclNvcnRQcm9wRmllbGQoJ3N1Ym1pc3Npb25EYXRlJylcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwidmFsdWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IHZhbHVlIHwgYXJ0ZW1pc0RhdGU6ICdsb25nJyA6IHRydWUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgPC9uZ3gtZGF0YXRhYmxlLWNvbHVtbj5cbiAgICAgICAgICAgICAgICA8bmd4LWRhdGF0YWJsZS1jb2x1bW4gcHJvcD1cImJ1aWxkU3RhcnREYXRlXCIgW21pbldpZHRoXT1cIjE1MFwiIFt3aWR0aF09XCIyMDBcIiBbbWF4V2lkdGhdPVwiMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWhlYWRlci10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLXdyYXBwZXJcIiAoY2xpY2spPVwiY29udHJvbHMub25Tb3J0KCdidWlsZFN0YXJ0RGF0ZScpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtbGFiZWwgYm9sZCBzb3J0YWJsZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYnVpbGRRdWV1ZS5idWlsZEpvYi5idWlsZFN0YXJ0RGF0ZVwiPiBCdWlsZCBTdGFydCBEYXRlIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJjb250cm9scy5pY29uRm9yU29ydFByb3BGaWVsZCgnYnVpbGRTdGFydERhdGUnKVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZSBsZXQtdmFsdWU9XCJ2YWx1ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgdmFsdWUgfCBhcnRlbWlzRGF0ZTogJ2xvbmcnIDogdHJ1ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICA8L25neC1kYXRhdGFibGUtY29sdW1uPlxuICAgICAgICAgICAgICAgIDxuZ3gtZGF0YXRhYmxlLWNvbHVtbiBwcm9wPVwiY291cnNlSWRcIiBbbWluV2lkdGhdPVwiMTUwXCIgW3dpZHRoXT1cIjIwMFwiIFttYXhXaWR0aF09XCIyMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtaGVhZGVyLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtd3JhcHBlclwiIChjbGljayk9XCJjb250cm9scy5vblNvcnQoJ2NvdXJzZUlkJylcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC1sYWJlbCBib2xkIHNvcnRhYmxlXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5idWlsZFF1ZXVlLmJ1aWxkSm9iLmNvdXJzZUlkXCI+IENvdXJzZSBJRCA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiY29udHJvbHMuaWNvbkZvclNvcnRQcm9wRmllbGQoJ2NvdXJzZUlkJylcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwidmFsdWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IHZhbHVlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XG4gICAgICAgICAgICAgICAgPG5neC1kYXRhdGFibGUtY29sdW1uIHByb3A9XCJwcmlvcml0eVwiIFttaW5XaWR0aF09XCIxNTBcIiBbd2lkdGhdPVwiMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWhlYWRlci10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLXdyYXBwZXJcIiAoY2xpY2spPVwiY29udHJvbHMub25Tb3J0KCdwcmlvcml0eScpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtbGFiZWwgYm9sZCBzb3J0YWJsZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYnVpbGRRdWV1ZS5idWlsZEpvYi5wcmlvcml0eVwiPiBQcmlvcml0eSA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiY29udHJvbHMuaWNvbkZvclNvcnRQcm9wRmllbGQoJ3ByaW9yaXR5JylcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwidmFsdWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IHZhbHVlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XG4gICAgICAgICAgICA8L25neC1kYXRhdGFibGU+XG4gICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgPC9qaGktZGF0YS10YWJsZT5cbjwvZGl2PlxuPGRpdj5cbiAgICA8aDMgaWQ9XCJidWlsZC1xdWV1ZS1xdWV1ZWQtaGVhZGluZ1wiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYnVpbGRRdWV1ZS5xdWV1ZWRCdWlsZEpvYnNcIj5RdWV1ZWQgYnVpbGQgam9iczwvaDM+XG4gICAgPGRpdiBjbGFzcz1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBhbGlnbi1pdGVtcy1jZW50ZXIgYm9yZGVyLWJvdHRvbSBwYi0yIG1iLTNcIj48L2Rpdj5cbiAgICA8amhpLWRhdGEtdGFibGUgW3Nob3dQYWdlU2l6ZURyb3Bkb3duXT1cImZhbHNlXCIgW3Nob3dTZWFyY2hGaWVsZF09XCJmYWxzZVwiIGVudGl0eVR5cGU9XCJidWlsZEpvYlwiIFthbGxFbnRpdGllc109XCJxdWV1ZWRCdWlsZEpvYnMhXCI+XG4gICAgICAgIDxuZy10ZW1wbGF0ZSBsZXQtc2V0dGluZ3M9XCJzZXR0aW5nc1wiIGxldC1jb250cm9scz1cImNvbnRyb2xzXCI+XG4gICAgICAgICAgICA8bmd4LWRhdGF0YWJsZVxuICAgICAgICAgICAgICAgIGNsYXNzPVwiYm9vdHN0cmFwXCJcbiAgICAgICAgICAgICAgICBbbGltaXRdPVwic2V0dGluZ3MubGltaXRcIlxuICAgICAgICAgICAgICAgIFtzb3J0VHlwZV09XCJzZXR0aW5ncy5zb3J0VHlwZVwiXG4gICAgICAgICAgICAgICAgW2NvbHVtbk1vZGVdPVwic2V0dGluZ3MuY29sdW1uTW9kZVwiXG4gICAgICAgICAgICAgICAgW2hlYWRlckhlaWdodF09XCJzZXR0aW5ncy5oZWFkZXJIZWlnaHRcIlxuICAgICAgICAgICAgICAgIFtmb290ZXJIZWlnaHRdPVwic2V0dGluZ3MuZm9vdGVySGVpZ2h0XCJcbiAgICAgICAgICAgICAgICBbcm93SGVpZ2h0XT1cInNldHRpbmdzLnJvd0hlaWdodFwiXG4gICAgICAgICAgICAgICAgW3Jvd3NdPVwic2V0dGluZ3Mucm93c1wiXG4gICAgICAgICAgICAgICAgW3Jvd0NsYXNzXT1cInNldHRpbmdzLnJvd0NsYXNzXCJcbiAgICAgICAgICAgICAgICBbc2Nyb2xsYmFySF09XCJzZXR0aW5ncy5zY3JvbGxiYXJIXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8bmd4LWRhdGF0YWJsZS1jb2x1bW4gcHJvcD1cIm5hbWVcIiBbbWluV2lkdGhdPVwiMTUwXCIgW3dpZHRoXT1cIjIwMFwiIFttYXhXaWR0aF09XCIyMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtaGVhZGVyLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtd3JhcHBlclwiIChjbGljayk9XCJjb250cm9scy5vblNvcnQoJ25hbWUnKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLWxhYmVsIGJvbGQgc29ydGFibGVcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmJ1aWxkUXVldWUuYnVpbGRKb2IubmFtZVwiPiBOYW1lIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJjb250cm9scy5pY29uRm9yU29ydFByb3BGaWVsZCgnbmFtZScpXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1jZWxsLXRlbXBsYXRlIGxldC12YWx1ZT1cInZhbHVlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyB2YWx1ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICA8L25neC1kYXRhdGFibGUtY29sdW1uPlxuICAgICAgICAgICAgICAgIDxuZ3gtZGF0YXRhYmxlLWNvbHVtbiBwcm9wPVwicGFydGljaXBhdGlvbklkXCIgW21pbldpZHRoXT1cIjE1MFwiIFt3aWR0aF09XCIxNTBcIiBbbWF4V2lkdGhdPVwiMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWhlYWRlci10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLXdyYXBwZXJcIiAoY2xpY2spPVwiY29udHJvbHMub25Tb3J0KCdwYXJ0aWNpcGF0aW9uSWQnKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLWxhYmVsIGJvbGQgc29ydGFibGVcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmJ1aWxkUXVldWUuYnVpbGRKb2IucGFydGljaXBhdGlvbklkXCI+IFBhcnRpY2lwYXRpb24gSUQgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImNvbnRyb2xzLmljb25Gb3JTb3J0UHJvcEZpZWxkKCdwYXJ0aWNpcGF0aW9uSWQnKVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZSBsZXQtdmFsdWU9XCJ2YWx1ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgdmFsdWUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgPC9uZ3gtZGF0YXRhYmxlLWNvbHVtbj5cbiAgICAgICAgICAgICAgICA8bmd4LWRhdGF0YWJsZS1jb2x1bW4gcHJvcD1cInJlcG9zaXRvcnlUeXBlT3JVc2VyTmFtZVwiIFttaW5XaWR0aF09XCIxNTBcIiBbd2lkdGhdPVwiMjAwXCIgW21heFdpZHRoXT1cIjIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVyXCIgKGNsaWNrKT1cImNvbnRyb2xzLm9uU29ydCgncmVwb3NpdG9yeVR5cGVPclVzZXJOYW1lJylcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC1sYWJlbCBib2xkIHNvcnRhYmxlXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5idWlsZFF1ZXVlLmJ1aWxkSm9iLnJlcG9zaXRvcnlUeXBlXCI+IFJlcG9zaXRvcnkgVHlwZSA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiY29udHJvbHMuaWNvbkZvclNvcnRQcm9wRmllbGQoJ3JlcG9zaXRvcnlUeXBlT3JVc2VyTmFtZScpXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1jZWxsLXRlbXBsYXRlIGxldC12YWx1ZT1cInZhbHVlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyB2YWx1ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICA8L25neC1kYXRhdGFibGUtY29sdW1uPlxuICAgICAgICAgICAgICAgIDxuZ3gtZGF0YXRhYmxlLWNvbHVtbiBwcm9wPVwiY29tbWl0SGFzaFwiIFttaW5XaWR0aF09XCIxNTBcIiBbd2lkdGhdPVwiMjAwXCIgW21heFdpZHRoXT1cIjIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVyXCIgKGNsaWNrKT1cImNvbnRyb2xzLm9uU29ydCgnY29tbWl0SGFzaCcpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtbGFiZWwgYm9sZCBzb3J0YWJsZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYnVpbGRRdWV1ZS5idWlsZEpvYi5jb21taXRIYXNoXCI+IENvbW1pdCBIYXNoIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJjb250cm9scy5pY29uRm9yU29ydFByb3BGaWVsZCgnY29tbWl0SGFzaCcpXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1jZWxsLXRlbXBsYXRlIGxldC12YWx1ZT1cInZhbHVlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cIndyYXAtbG9uZy10ZXh0XCI+e3sgdmFsdWUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgPC9uZ3gtZGF0YXRhYmxlLWNvbHVtbj5cbiAgICAgICAgICAgICAgICA8bmd4LWRhdGF0YWJsZS1jb2x1bW4gcHJvcD1cInN1Ym1pc3Npb25EYXRlXCIgW21pbldpZHRoXT1cIjE1MFwiIFt3aWR0aF09XCIyMDBcIiBbbWF4V2lkdGhdPVwiMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWhlYWRlci10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLXdyYXBwZXJcIiAoY2xpY2spPVwiY29udHJvbHMub25Tb3J0KCdzdWJtaXNzaW9uRGF0ZScpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtbGFiZWwgYm9sZCBzb3J0YWJsZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuYnVpbGRRdWV1ZS5idWlsZEpvYi5zdWJtaXNzaW9uRGF0ZVwiPiBTdWJtaXNzaW9uIERhdGUgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImNvbnRyb2xzLmljb25Gb3JTb3J0UHJvcEZpZWxkKCdzdWJtaXNzaW9uRGF0ZScpXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1jZWxsLXRlbXBsYXRlIGxldC12YWx1ZT1cInZhbHVlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyB2YWx1ZSB8IGFydGVtaXNEYXRlOiAnbG9uZycgOiB0cnVlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XG4gICAgICAgICAgICAgICAgPG5neC1kYXRhdGFibGUtY29sdW1uIHByb3A9XCJjb3Vyc2VJZFwiIFttaW5XaWR0aF09XCIxNTBcIiBbd2lkdGhdPVwiMjAwXCIgW21heFdpZHRoXT1cIjIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVyXCIgKGNsaWNrKT1cImNvbnRyb2xzLm9uU29ydCgnY291cnNlSWQnKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLWxhYmVsIGJvbGQgc29ydGFibGVcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmJ1aWxkUXVldWUuYnVpbGRKb2IuY291cnNlSWRcIj4gQ291cnNlIElEIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJjb250cm9scy5pY29uRm9yU29ydFByb3BGaWVsZCgnY291cnNlSWQnKVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZSBsZXQtdmFsdWU9XCJ2YWx1ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgdmFsdWUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgPC9uZ3gtZGF0YXRhYmxlLWNvbHVtbj5cbiAgICAgICAgICAgICAgICA8bmd4LWRhdGF0YWJsZS1jb2x1bW4gcHJvcD1cInByaW9yaXR5XCIgW21pbldpZHRoXT1cIjE1MFwiIFt3aWR0aF09XCIyMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtaGVhZGVyLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtd3JhcHBlclwiIChjbGljayk9XCJjb250cm9scy5vblNvcnQoJ3ByaW9yaXR5JylcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC1sYWJlbCBib2xkIHNvcnRhYmxlXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5idWlsZFF1ZXVlLmJ1aWxkSm9iLnByaW9yaXR5XCI+IFByaW9yaXR5IDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJjb250cm9scy5pY29uRm9yU29ydFByb3BGaWVsZCgncHJpb3JpdHknKVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZSBsZXQtdmFsdWU9XCJ2YWx1ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgdmFsdWUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgPC9uZ3gtZGF0YXRhYmxlLWNvbHVtbj5cbiAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZT5cbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICA8L2poaS1kYXRhLXRhYmxlPlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50LCBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBtYXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBDb3Vyc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvY291cnNlLm1vZGVsJztcbmltcG9ydCB7IG9iamVjdFRvSnNvbkJsb2IgfSBmcm9tICdhcHAvdXRpbHMvYmxvYi11dGlsJztcbmltcG9ydCB7IENvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvdXJzZS9tYW5hZ2UvY291cnNlLW1hbmFnZW1lbnQuc2VydmljZSc7XG5cbmV4cG9ydCB0eXBlIEVudGl0eVJlc3BvbnNlVHlwZSA9IEh0dHBSZXNwb25zZTxDb3Vyc2U+O1xuZXhwb3J0IHR5cGUgRW50aXR5QXJyYXlSZXNwb25zZVR5cGUgPSBIdHRwUmVzcG9uc2U8Q291cnNlW10+O1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIENvdXJzZUFkbWluU2VydmljZSB7XG4gICAgcHJpdmF0ZSByZXNvdXJjZVVybCA9ICdhcGkvYWRtaW4vY291cnNlcyc7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50LFxuICAgICAgICBwcml2YXRlIGNvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlOiBDb3Vyc2VNYW5hZ2VtZW50U2VydmljZSxcbiAgICApIHt9XG5cbiAgICAvKipcbiAgICAgKiBmaW5kcyBhbGwgZ3JvdXBzIGZvciBhbGwgY291cnNlcyB1c2luZyBhIEdFVCByZXF1ZXN0XG4gICAgICovXG4gICAgZ2V0QWxsR3JvdXBzRm9yQWxsQ291cnNlcygpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxzdHJpbmdbXT4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8c3RyaW5nW10+KHRoaXMucmVzb3VyY2VVcmwgKyAnL2dyb3VwcycsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjcmVhdGVzIGEgY291cnNlIHVzaW5nIGEgUE9TVCByZXF1ZXN0XG4gICAgICogQHBhcmFtIGNvdXJzZSAtIHRoZSBjb3Vyc2UgdG8gYmUgY3JlYXRlZCBvbiB0aGUgc2VydmVyXG4gICAgICogQHBhcmFtIGNvdXJzZUltYWdlIC0gdGhlIGNvdXJzZSBpY29uIGZpbGVcbiAgICAgKi9cbiAgICBjcmVhdGUoY291cnNlOiBDb3Vyc2UsIGNvdXJzZUltYWdlPzogQmxvYik6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIGNvbnN0IGNvcHkgPSBDb3Vyc2VNYW5hZ2VtZW50U2VydmljZS5jb252ZXJ0Q291cnNlRGF0ZXNGcm9tQ2xpZW50KGNvdXJzZSk7XG4gICAgICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnY291cnNlJywgb2JqZWN0VG9Kc29uQmxvYihjb3B5KSk7XG4gICAgICAgIGlmIChjb3Vyc2VJbWFnZSkge1xuICAgICAgICAgICAgLy8gVGhlIGltYWdlIHdhcyBjcm9wcGVkIGJ5IHVzIGFuZCBpcyBhIGJsb2IsIHNvIHdlIG5lZWQgdG8gc2V0IGEgcGxhY2Vob2xkZXIgbmFtZSBmb3IgdGhlIHNlcnZlciBjaGVja1xuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdmaWxlJywgY291cnNlSW1hZ2UsICdwbGFjZWhvbGRlck5hbWUucG5nJyk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAucG9zdDxDb3Vyc2U+KHRoaXMucmVzb3VyY2VVcmwsIGZvcm1EYXRhLCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpID0+IHRoaXMuY291cnNlTWFuYWdlbWVudFNlcnZpY2UucHJvY2Vzc0NvdXJzZUVudGl0eVJlc3BvbnNlVHlwZShyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZGVsZXRlcyB0aGUgY291cnNlIGNvcnJlc3BvbmRpbmcgdG8gdGhlIGdpdmVuIHVuaXF1ZSBpZGVudGlmaWVyIHVzaW5nIGEgREVMRVRFIHJlcXVlc3RcbiAgICAgKiBAcGFyYW0gY291cnNlSWQgLSB0aGUgaWQgb2YgdGhlIGNvdXJzZSB0byBiZSBkZWxldGVkXG4gICAgICovXG4gICAgZGVsZXRlKGNvdXJzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTx2b2lkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmRlbGV0ZTx2b2lkPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2NvdXJzZUlkfWAsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDYW5BY3RpdmF0ZSwgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcblxuaW1wb3J0IHsgUHJvZmlsZVNlcnZpY2UgfSBmcm9tICdhcHAvc2hhcmVkL2xheW91dHMvcHJvZmlsZXMvcHJvZmlsZS5zZXJ2aWNlJztcbmltcG9ydCB7IFBST0ZJTEVfTE9DQUxDSSB9IGZyb20gJ2FwcC9hcHAuY29uc3RhbnRzJztcblxuQEluamVjdGFibGUoe1xuICAgIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgQnVpbGRRdWV1ZUd1YXJkIGltcGxlbWVudHMgQ2FuQWN0aXZhdGUge1xuICAgIGxvY2FsQ0lBY3RpdmU6IGJvb2xlYW4gPSBmYWxzZTtcbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBwcm9maWxlU2VydmljZTogUHJvZmlsZVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgKSB7fVxuXG4gICAgYXN5bmMgY2FuQWN0aXZhdGUoKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgICAgIHRoaXMucHJvZmlsZVNlcnZpY2UuZ2V0UHJvZmlsZUluZm8oKS5zdWJzY3JpYmUoKHByb2ZpbGVJbmZvKSA9PiB7XG4gICAgICAgICAgICBpZiAocHJvZmlsZUluZm8pIHtcbiAgICAgICAgICAgICAgICB0aGlzLmxvY2FsQ0lBY3RpdmUgPSBwcm9maWxlSW5mbz8uYWN0aXZlUHJvZmlsZXMuaW5jbHVkZXMoUFJPRklMRV9MT0NBTENJKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCF0aGlzLmxvY2FsQ0lBY3RpdmUpIHtcbiAgICAgICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFsnL2NvdXJzZS1tYW5hZ2VtZW50J10pO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLGtCQUFrQjs7O0FBRDNCLElBT2E7QUFQYjs7QUFPTSxJQUFPLG9CQUFQLE1BQU8sbUJBQWlCO01BSU47TUFIYixjQUFjO01BQ2QsbUJBQW1CO01BRTFCLFlBQW9CLE1BQWdCO0FBQWhCLGFBQUEsT0FBQTtNQUFtQjtNQUt2Qyw2QkFBNkIsVUFBZ0I7QUFDekMsZUFBTyxLQUFLLEtBQUssSUFBZ0IsR0FBRyxLQUFLLFdBQVcsV0FBVyxRQUFRLEVBQUU7TUFDN0U7TUFNQSw4QkFBOEIsVUFBZ0I7QUFDMUMsZUFBTyxLQUFLLEtBQUssSUFBZ0IsR0FBRyxLQUFLLFdBQVcsWUFBWSxRQUFRLEVBQUU7TUFDOUU7TUFLQSxxQkFBa0I7QUFDZCxlQUFPLEtBQUssS0FBSyxJQUFnQixHQUFHLEtBQUssZ0JBQWdCLFNBQVM7TUFDdEU7TUFLQSxzQkFBbUI7QUFDZixlQUFPLEtBQUssS0FBSyxJQUFnQixHQUFHLEtBQUssZ0JBQWdCLFVBQVU7TUFDdkU7O3lCQWpDUyxvQkFBaUIsc0JBQUEsYUFBQSxDQUFBO01BQUE7bUVBQWpCLG9CQUFpQixTQUFqQixtQkFBaUIsV0FBQSxZQURKLE9BQU0sQ0FBQTs7Ozs7O0FDTmhDLFNBQVMsaUJBQW9DO0FBQzdDLFNBQVMsc0JBQXNCOzs7Ozs7OztBQ2tCUCxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTRDLElBQUEseUJBQUEsU0FBQSxTQUFBLGlGQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLEVBQUE7QUFBQSxhQUFTLDBCQUFBLFlBQUEsT0FBZ0IsTUFBTSxDQUFDO0lBQUEsQ0FBQTtBQUN4RSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTRHLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUssSUFBQSwyQkFBQTtBQUNqSCxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsWUFBQSxxQkFBQSxNQUFBLENBQUE7Ozs7O0FBSWIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBVyxJQUFBLDJCQUFBO0FBQ3JCLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsU0FBQTs7Ozs7O0FBS04sSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE0QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSxrRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxFQUFBO0FBQUEsYUFBUywwQkFBQSxZQUFBLE9BQWdCLGlCQUFpQixDQUFDO0lBQUEsQ0FBQTtBQUNuRixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXVILElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFpQixJQUFBLDJCQUFBO0FBQ3hJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRmlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxZQUFBLHFCQUFBLGlCQUFBLENBQUE7Ozs7O0FBSWIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBVyxJQUFBLDJCQUFBO0FBQ3JCLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsU0FBQTs7Ozs7O0FBS04sSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE0QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSxrRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxFQUFBO0FBQUEsYUFBUywwQkFBQSxZQUFBLE9BQWdCLDBCQUEwQixDQUFDO0lBQUEsQ0FBQTtBQUM1RixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXNILElBQUEscUJBQUEsR0FBQSxtQkFBQTtBQUFnQixJQUFBLDJCQUFBO0FBQ3RJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRmlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxZQUFBLHFCQUFBLDBCQUFBLENBQUE7Ozs7O0FBSWIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBVyxJQUFBLDJCQUFBO0FBQ3JCLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsU0FBQTs7Ozs7O0FBS04sSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE0QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSxrRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxFQUFBO0FBQUEsYUFBUywwQkFBQSxZQUFBLE9BQWdCLFlBQVksQ0FBQztJQUFBLENBQUE7QUFDOUUsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFrSCxJQUFBLHFCQUFBLEdBQUEsZUFBQTtBQUFZLElBQUEsMkJBQUE7QUFDOUgsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFGaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFlBQUEscUJBQUEsWUFBQSxDQUFBOzs7OztBQUliLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNkIsSUFBQSxxQkFBQSxDQUFBO0FBQVcsSUFBQSwyQkFBQTtBQUM1QyxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFEaUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxTQUFBOzs7Ozs7QUFLN0IsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE0QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSxrRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxFQUFBO0FBQUEsYUFBUywwQkFBQSxZQUFBLE9BQWdCLGdCQUFnQixDQUFDO0lBQUEsQ0FBQTtBQUNsRixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXNILElBQUEscUJBQUEsR0FBQSxtQkFBQTtBQUFnQixJQUFBLDJCQUFBO0FBQ3RJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRmlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxZQUFBLHFCQUFBLGdCQUFBLENBQUE7Ozs7O0FBSWIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7O0FBQXdDLElBQUEsMkJBQUE7QUFDbEQsSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsV0FBQSxRQUFBLElBQUEsQ0FBQTs7Ozs7O0FBS04sSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE0QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSxrRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxFQUFBO0FBQUEsYUFBUywwQkFBQSxZQUFBLE9BQWdCLGdCQUFnQixDQUFDO0lBQUEsQ0FBQTtBQUNsRixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXNILElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFpQixJQUFBLDJCQUFBO0FBQ3ZJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRmlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxZQUFBLHFCQUFBLGdCQUFBLENBQUE7Ozs7O0FBSWIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7O0FBQXdDLElBQUEsMkJBQUE7QUFDbEQsSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsV0FBQSxRQUFBLElBQUEsQ0FBQTs7Ozs7O0FBS04sSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE0QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSxrRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxFQUFBO0FBQUEsYUFBUywwQkFBQSxZQUFBLE9BQWdCLFVBQVUsQ0FBQztJQUFBLENBQUE7QUFDNUUsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFnSCxJQUFBLHFCQUFBLEdBQUEsYUFBQTtBQUFVLElBQUEsMkJBQUE7QUFDMUgsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFGaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFlBQUEscUJBQUEsVUFBQSxDQUFBOzs7OztBQUliLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBO0FBQVcsSUFBQSwyQkFBQTtBQUNyQixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFEVSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFNBQUE7Ozs7OztBQUtOLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEMsSUFBQSx5QkFBQSxTQUFBLFNBQUEsa0ZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGNBQUEsNEJBQUEsRUFBQTtBQUFBLGFBQVMsMEJBQUEsWUFBQSxPQUFnQixVQUFVLENBQUM7SUFBQSxDQUFBO0FBQzVFLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBZ0gsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBUyxJQUFBLDJCQUFBO0FBQ3pILElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRmlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxZQUFBLHFCQUFBLFVBQUEsQ0FBQTs7Ozs7QUFJYixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUFXLElBQUEsMkJBQUE7QUFDckIsSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxTQUFBOzs7OztBQWpHbEIsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLGlCQUFBLENBQUE7QUFZSSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsd0JBQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwwREFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBTUEsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDBEQUFBLEdBQUEsR0FBQSxlQUFBLENBQUE7QUFHSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLHdCQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsMkRBQUEsR0FBQSxHQUFBLGVBQUEsQ0FBQTtBQU1BLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSwyREFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBR0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSx3QkFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDJEQUFBLEdBQUEsR0FBQSxlQUFBLENBQUE7QUFNQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsMkRBQUEsR0FBQSxHQUFBLGVBQUEsQ0FBQTtBQUdKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsd0JBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSwyREFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBTUEsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDJEQUFBLEdBQUEsR0FBQSxlQUFBLENBQUE7QUFHSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLHdCQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsMkRBQUEsR0FBQSxHQUFBLGVBQUEsQ0FBQTtBQU1BLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSwyREFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBR0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSx3QkFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDJEQUFBLEdBQUEsR0FBQSxlQUFBLENBQUE7QUFNQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsMkRBQUEsR0FBQSxHQUFBLGVBQUEsQ0FBQTtBQUdKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsd0JBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSwyREFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBTUEsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDJEQUFBLEdBQUEsR0FBQSxlQUFBLENBQUE7QUFHSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLHdCQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsMkRBQUEsR0FBQSxHQUFBLGVBQUEsQ0FBQTtBQU1BLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSwyREFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBR0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsWUFBQTs7OztBQW5HUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFNBQUEsWUFBQSxLQUFBLEVBQXdCLFlBQUEsWUFBQSxRQUFBLEVBQUEsY0FBQSxZQUFBLFVBQUEsRUFBQSxnQkFBQSxZQUFBLFlBQUEsRUFBQSxnQkFBQSxZQUFBLFlBQUEsRUFBQSxhQUFBLFlBQUEsU0FBQSxFQUFBLFFBQUEsWUFBQSxJQUFBLEVBQUEsWUFBQSxZQUFBLFFBQUEsRUFBQSxjQUFBLFlBQUEsVUFBQTtBQVVVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxHQUFBLEVBQWdCLFNBQUEsR0FBQSxFQUFBLFlBQUEsR0FBQTtBQVdMLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxHQUFBLEVBQWdCLFNBQUEsR0FBQSxFQUFBLFlBQUEsR0FBQTtBQVdQLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxHQUFBLEVBQWdCLFNBQUEsR0FBQSxFQUFBLFlBQUEsR0FBQTtBQVc5QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsR0FBQSxFQUFnQixTQUFBLEdBQUEsRUFBQSxZQUFBLEdBQUE7QUFXWixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsR0FBQSxFQUFnQixTQUFBLEdBQUEsRUFBQSxZQUFBLEdBQUE7QUFXaEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLEdBQUEsRUFBZ0IsU0FBQSxHQUFBLEVBQUEsWUFBQSxHQUFBO0FBV3RCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxHQUFBLEVBQWdCLFNBQUEsR0FBQSxFQUFBLFlBQUEsR0FBQTtBQVdoQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsR0FBQSxFQUFnQixTQUFBLEdBQUE7Ozs7OztBQWtDOUMsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE0QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSxrRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsZUFBQSw0QkFBQSxFQUFBO0FBQUEsYUFBUywwQkFBQSxhQUFBLE9BQWdCLE1BQU0sQ0FBQztJQUFBLENBQUE7QUFDeEUsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE0RyxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFLLElBQUEsMkJBQUE7QUFDakgsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFGaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLGFBQUEscUJBQUEsTUFBQSxDQUFBOzs7OztBQUliLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBO0FBQVcsSUFBQSwyQkFBQTtBQUNyQixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFEVSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFNBQUE7Ozs7OztBQUtOLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEMsSUFBQSx5QkFBQSxTQUFBLFNBQUEsbUZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGVBQUEsNEJBQUEsRUFBQTtBQUFBLGFBQVMsMEJBQUEsYUFBQSxPQUFnQixpQkFBaUIsQ0FBQztJQUFBLENBQUE7QUFDbkYsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUF1SCxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBaUIsSUFBQSwyQkFBQTtBQUN4SSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsYUFBQSxxQkFBQSxpQkFBQSxDQUFBOzs7OztBQUliLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBO0FBQVcsSUFBQSwyQkFBQTtBQUNyQixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFEVSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFNBQUE7Ozs7OztBQUtOLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEMsSUFBQSx5QkFBQSxTQUFBLFNBQUEsbUZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGVBQUEsNEJBQUEsRUFBQTtBQUFBLGFBQVMsMEJBQUEsYUFBQSxPQUFnQiwwQkFBMEIsQ0FBQztJQUFBLENBQUE7QUFDNUYsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFzSCxJQUFBLHFCQUFBLEdBQUEsbUJBQUE7QUFBZ0IsSUFBQSwyQkFBQTtBQUN0SSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsYUFBQSxxQkFBQSwwQkFBQSxDQUFBOzs7OztBQUliLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBO0FBQVcsSUFBQSwyQkFBQTtBQUNyQixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFEVSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFNBQUE7Ozs7OztBQUtOLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEMsSUFBQSx5QkFBQSxTQUFBLFNBQUEsbUZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGVBQUEsNEJBQUEsRUFBQTtBQUFBLGFBQVMsMEJBQUEsYUFBQSxPQUFnQixZQUFZLENBQUM7SUFBQSxDQUFBO0FBQzlFLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBa0gsSUFBQSxxQkFBQSxHQUFBLGVBQUE7QUFBWSxJQUFBLDJCQUFBO0FBQzlILElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRmlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxhQUFBLHFCQUFBLFlBQUEsQ0FBQTs7Ozs7QUFJYixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTZCLElBQUEscUJBQUEsQ0FBQTtBQUFXLElBQUEsMkJBQUE7QUFDNUMsSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRGlDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsU0FBQTs7Ozs7O0FBSzdCLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEMsSUFBQSx5QkFBQSxTQUFBLFNBQUEsbUZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGVBQUEsNEJBQUEsRUFBQTtBQUFBLGFBQVMsMEJBQUEsYUFBQSxPQUFnQixnQkFBZ0IsQ0FBQztJQUFBLENBQUE7QUFDbEYsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFzSCxJQUFBLHFCQUFBLEdBQUEsbUJBQUE7QUFBZ0IsSUFBQSwyQkFBQTtBQUN0SSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsYUFBQSxxQkFBQSxnQkFBQSxDQUFBOzs7OztBQUliLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBOztBQUF3QyxJQUFBLDJCQUFBO0FBQ2xELElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLFlBQUEsUUFBQSxJQUFBLENBQUE7Ozs7OztBQUtOLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEMsSUFBQSx5QkFBQSxTQUFBLFNBQUEsbUZBQUE7QUFBQSxNQUFBLDRCQUFBLEtBQUE7QUFBQSxZQUFBLGVBQUEsNEJBQUEsRUFBQTtBQUFBLGFBQVMsMEJBQUEsYUFBQSxPQUFnQixVQUFVLENBQUM7SUFBQSxDQUFBO0FBQzVFLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBZ0gsSUFBQSxxQkFBQSxHQUFBLGFBQUE7QUFBVSxJQUFBLDJCQUFBO0FBQzFILElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRmlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxhQUFBLHFCQUFBLFVBQUEsQ0FBQTs7Ozs7QUFJYixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUFXLElBQUEsMkJBQUE7QUFDckIsSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxVQUFBOzs7Ozs7QUFLTixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTRDLElBQUEseUJBQUEsU0FBQSxTQUFBLG1GQUFBO0FBQUEsTUFBQSw0QkFBQSxLQUFBO0FBQUEsWUFBQSxlQUFBLDRCQUFBLEVBQUE7QUFBQSxhQUFTLDBCQUFBLGFBQUEsT0FBZ0IsVUFBVSxDQUFDO0lBQUEsQ0FBQTtBQUM1RSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQWdILElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQVMsSUFBQSwyQkFBQTtBQUN6SCxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsYUFBQSxxQkFBQSxVQUFBLENBQUE7Ozs7O0FBSWIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBVyxJQUFBLDJCQUFBO0FBQ3JCLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsVUFBQTs7Ozs7QUF0RmxCLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxpQkFBQSxDQUFBO0FBWUksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLHdCQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsMkRBQUEsR0FBQSxHQUFBLGVBQUEsQ0FBQTtBQU1BLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwyREFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBR0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSx3QkFBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDREQUFBLEdBQUEsR0FBQSxlQUFBLENBQUE7QUFNQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsNERBQUEsR0FBQSxHQUFBLGVBQUEsQ0FBQTtBQUdKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsd0JBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSw0REFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBTUEsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDREQUFBLEdBQUEsR0FBQSxlQUFBLENBQUE7QUFHSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLHdCQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsNERBQUEsR0FBQSxHQUFBLGVBQUEsQ0FBQTtBQU1BLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSw0REFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBR0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSx3QkFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDREQUFBLEdBQUEsR0FBQSxlQUFBLENBQUE7QUFNQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsNERBQUEsR0FBQSxHQUFBLGVBQUEsQ0FBQTtBQUdKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsd0JBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSw0REFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBTUEsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDREQUFBLEdBQUEsR0FBQSxlQUFBLENBQUE7QUFHSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLHdCQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsNERBQUEsR0FBQSxHQUFBLGVBQUEsQ0FBQTtBQU1BLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSw0REFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBR0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsWUFBQTs7OztBQXhGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFNBQUEsYUFBQSxLQUFBLEVBQXdCLFlBQUEsYUFBQSxRQUFBLEVBQUEsY0FBQSxhQUFBLFVBQUEsRUFBQSxnQkFBQSxhQUFBLFlBQUEsRUFBQSxnQkFBQSxhQUFBLFlBQUEsRUFBQSxhQUFBLGFBQUEsU0FBQSxFQUFBLFFBQUEsYUFBQSxJQUFBLEVBQUEsWUFBQSxhQUFBLFFBQUEsRUFBQSxjQUFBLGFBQUEsVUFBQTtBQVVVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxHQUFBLEVBQWdCLFNBQUEsR0FBQSxFQUFBLFlBQUEsR0FBQTtBQVdMLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxHQUFBLEVBQWdCLFNBQUEsR0FBQSxFQUFBLFlBQUEsR0FBQTtBQVdQLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxHQUFBLEVBQWdCLFNBQUEsR0FBQSxFQUFBLFlBQUEsR0FBQTtBQVc5QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsR0FBQSxFQUFnQixTQUFBLEdBQUEsRUFBQSxZQUFBLEdBQUE7QUFXWixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsR0FBQSxFQUFnQixTQUFBLEdBQUEsRUFBQSxZQUFBLEdBQUE7QUFXdEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLEdBQUEsRUFBZ0IsU0FBQSxHQUFBLEVBQUEsWUFBQSxHQUFBO0FBV2hCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxHQUFBLEVBQWdCLFNBQUEsR0FBQTs7O0FEaE10RSxJQVdhO0FBWGI7O0FBR0E7QUFDQTs7Ozs7O0FBT00sSUFBTyxzQkFBUCxNQUFPLHFCQUFtQjtNQU1oQjtNQUNBO01BQ0E7TUFQWjtNQUNBO01BQ0EsaUJBQTJCLENBQUE7TUFFM0IsWUFDWSxPQUNBLGtCQUNBLG1CQUFvQztBQUZwQyxhQUFBLFFBQUE7QUFDQSxhQUFBLG1CQUFBO0FBQ0EsYUFBQSxvQkFBQTtNQUNUO01BRUgsV0FBUTtBQUNKLGFBQUssS0FBSTtBQUNULGFBQUssMEJBQXlCO01BQ2xDO01BS0EsY0FBVztBQUNQLGFBQUssaUJBQWlCLFlBQVksMEJBQTBCO0FBQzVELGFBQUssaUJBQWlCLFlBQVksMkJBQTJCO0FBQzdELGFBQUssZUFBZSxRQUFRLENBQUMsWUFBVztBQUNwQyxlQUFLLGlCQUFpQixZQUFZLE9BQU87UUFDN0MsQ0FBQztNQUNMO01BS0EsNEJBQXlCO0FBQ3JCLGFBQUssTUFBTSxTQUFTLFVBQVUsQ0FBQyxXQUFVO0FBQ3JDLGdCQUFNLFdBQVcsT0FBTyxPQUFPLElBQUksVUFBVSxDQUFDO0FBQzlDLGNBQUksVUFBVTtBQUNWLGlCQUFLLGlCQUFpQixVQUFVLGtCQUFrQixRQUFRLGNBQWM7QUFDeEUsaUJBQUssaUJBQWlCLFVBQVUsa0JBQWtCLFFBQVEsZUFBZTtBQUN6RSxpQkFBSyxpQkFBaUIsUUFBUSxrQkFBa0IsUUFBUSxjQUFjLEVBQUUsVUFBVSxDQUFDLG9CQUFtQjtBQUNsRyxtQkFBSyxrQkFBa0I7WUFDM0IsQ0FBQztBQUNELGlCQUFLLGlCQUFpQixRQUFRLGtCQUFrQixRQUFRLGVBQWUsRUFBRSxVQUFVLENBQUMscUJBQW9CO0FBQ3BHLG1CQUFLLG1CQUFtQjtZQUM1QixDQUFDO0FBQ0QsaUJBQUssZUFBZSxLQUFLLGtCQUFrQixRQUFRLGNBQWM7QUFDakUsaUJBQUssZUFBZSxLQUFLLGtCQUFrQixRQUFRLGVBQWU7aUJBQy9EO0FBQ0gsaUJBQUssaUJBQWlCLFVBQVUsMEJBQTBCO0FBQzFELGlCQUFLLGlCQUFpQixVQUFVLDJCQUEyQjtBQUMzRCxpQkFBSyxpQkFBaUIsUUFBUSwwQkFBMEIsRUFBRSxVQUFVLENBQUMsb0JBQW1CO0FBQ3BGLG1CQUFLLGtCQUFrQjtZQUMzQixDQUFDO0FBQ0QsaUJBQUssaUJBQWlCLFFBQVEsMkJBQTJCLEVBQUUsVUFBVSxDQUFDLHFCQUFvQjtBQUN0RixtQkFBSyxtQkFBbUI7WUFDNUIsQ0FBQzs7UUFFVCxDQUFDO01BQ0w7TUFPQSxPQUFJO0FBQ0EsYUFBSyxNQUFNLFNBQVMsVUFBVSxDQUFDLFdBQVU7QUFDckMsZ0JBQU0sV0FBVyxPQUFPLE9BQU8sSUFBSSxVQUFVLENBQUM7QUFDOUMsY0FBSSxVQUFVO0FBQ1YsaUJBQUssa0JBQWtCLDZCQUE2QixRQUFRLEVBQUUsVUFBVSxDQUFDLG9CQUFtQjtBQUN4RixtQkFBSyxrQkFBa0I7WUFDM0IsQ0FBQztBQUNELGlCQUFLLGtCQUFrQiw4QkFBOEIsUUFBUSxFQUFFLFVBQVUsQ0FBQyxxQkFBb0I7QUFDMUYsbUJBQUssbUJBQW1CO1lBQzVCLENBQUM7aUJBQ0U7QUFDSCxpQkFBSyxrQkFBa0IsbUJBQWtCLEVBQUcsVUFBVSxDQUFDLG9CQUFtQjtBQUN0RSxtQkFBSyxrQkFBa0I7WUFDM0IsQ0FBQztBQUNELGlCQUFLLGtCQUFrQixvQkFBbUIsRUFBRyxVQUFVLENBQUMscUJBQW9CO0FBQ3hFLG1CQUFLLG1CQUFtQjtZQUM1QixDQUFDOztRQUVULENBQUM7TUFDTDs7eUJBakZTLHNCQUFtQixnQ0FBQSxrQkFBQSxHQUFBLGdDQUFBLG1CQUFBLEdBQUEsZ0NBQUEsaUJBQUEsQ0FBQTtNQUFBO2lFQUFuQixzQkFBbUIsV0FBQSxDQUFBLENBQUEsaUJBQUEsQ0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxrQkFBQSxNQUFBLEdBQUEsQ0FBQSxNQUFBLCtCQUFBLGdCQUFBLHdDQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsMkJBQUEsc0JBQUEsaUJBQUEsUUFBQSxNQUFBLEdBQUEsQ0FBQSxjQUFBLFlBQUEsR0FBQSx3QkFBQSxtQkFBQSxhQUFBLEdBQUEsQ0FBQSxNQUFBLDhCQUFBLGdCQUFBLHVDQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxTQUFBLFlBQUEsY0FBQSxnQkFBQSxnQkFBQSxhQUFBLFFBQUEsWUFBQSxZQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsR0FBQSxZQUFBLFNBQUEsVUFBQSxHQUFBLENBQUEsaUNBQUEsRUFBQSxHQUFBLENBQUEsK0JBQUEsRUFBQSxHQUFBLENBQUEsUUFBQSxtQkFBQSxHQUFBLFlBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxRQUFBLDRCQUFBLEdBQUEsWUFBQSxTQUFBLFVBQUEsR0FBQSxDQUFBLFFBQUEsY0FBQSxHQUFBLFlBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxRQUFBLGtCQUFBLEdBQUEsWUFBQSxTQUFBLFVBQUEsR0FBQSxDQUFBLFFBQUEsa0JBQUEsR0FBQSxZQUFBLFNBQUEsVUFBQSxHQUFBLENBQUEsUUFBQSxZQUFBLEdBQUEsWUFBQSxTQUFBLFVBQUEsR0FBQSxDQUFBLFFBQUEsWUFBQSxHQUFBLFlBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxpQ0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGdCQUFBLHVDQUFBLEdBQUEsK0JBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLGdCQUFBLGtEQUFBLEdBQUEsK0JBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxnQkFBQSxpREFBQSxHQUFBLCtCQUFBLFFBQUEsVUFBQSxHQUFBLENBQUEsZ0JBQUEsNkNBQUEsR0FBQSwrQkFBQSxRQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLGdCQUFBLGlEQUFBLEdBQUEsK0JBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxnQkFBQSxpREFBQSxHQUFBLCtCQUFBLFFBQUEsVUFBQSxHQUFBLENBQUEsZ0JBQUEsMkNBQUEsR0FBQSwrQkFBQSxRQUFBLFVBQUEsR0FBQSxDQUFBLGdCQUFBLDJDQUFBLEdBQUEsK0JBQUEsUUFBQSxVQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsNkJBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNYaEMsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUEyRixVQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBa0IsVUFBQSwyQkFBQTtBQUM3RyxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsd0JBQUEsR0FBQSxPQUFBLENBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxrQkFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLEdBQUEsNENBQUEsSUFBQSxJQUFBLGFBQUE7QUF1R0osVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsS0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUF5RixVQUFBLHFCQUFBLElBQUEsbUJBQUE7QUFBaUIsVUFBQSwyQkFBQTtBQUMxRyxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxPQUFBLENBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxrQkFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsNkNBQUEsSUFBQSxJQUFBLGFBQUE7QUE0RkosVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQTVNb0IsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSx3QkFBQSxLQUFBLEVBQThCLG1CQUFBLEtBQUEsRUFBQSxlQUFBLElBQUEsZ0JBQUE7QUE2RzlCLFVBQUEsd0JBQUEsRUFBQTtBQUFBLFVBQUEseUJBQUEsd0JBQUEsS0FBQSxFQUE4QixtQkFBQSxLQUFBLEVBQUEsZUFBQSxJQUFBLGVBQUE7Ozs7O3FGRHJHckMscUJBQW1CLEVBQUEsV0FBQSxzQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVYaEMsU0FBUyxjQUFBQSxtQkFBa0I7QUFDM0IsU0FBUyxjQUFBQyxtQkFBZ0M7QUFFekMsU0FBUyxXQUFXOzs7QUFIcEIsSUFZYTtBQVpiOztBQUtBO0FBQ0E7O0FBTU0sSUFBTyxxQkFBUCxNQUFPLG9CQUFrQjtNQUlmO01BQ0E7TUFKSixjQUFjO01BRXRCLFlBQ1ksTUFDQSx5QkFBZ0Q7QUFEaEQsYUFBQSxPQUFBO0FBQ0EsYUFBQSwwQkFBQTtNQUNUO01BS0gsNEJBQXlCO0FBQ3JCLGVBQU8sS0FBSyxLQUFLLElBQWMsS0FBSyxjQUFjLFdBQVcsRUFBRSxTQUFTLFdBQVUsQ0FBRTtNQUN4RjtNQU9BLE9BQU8sUUFBZ0IsYUFBa0I7QUFDckMsY0FBTSxPQUFPLHdCQUF3Qiw2QkFBNkIsTUFBTTtBQUN4RSxjQUFNLFdBQVcsSUFBSSxTQUFRO0FBQzdCLGlCQUFTLE9BQU8sVUFBVSxpQkFBaUIsSUFBSSxDQUFDO0FBQ2hELFlBQUksYUFBYTtBQUViLG1CQUFTLE9BQU8sUUFBUSxhQUFhLHFCQUFxQjs7QUFHOUQsZUFBTyxLQUFLLEtBQ1AsS0FBYSxLQUFLLGFBQWEsVUFBVSxFQUFFLFNBQVMsV0FBVSxDQUFFLEVBQ2hFLEtBQUssSUFBSSxDQUFDLFFBQTRCLEtBQUssd0JBQXdCLGdDQUFnQyxHQUFHLENBQUMsQ0FBQztNQUNqSDtNQU1BLE9BQU8sVUFBZ0I7QUFDbkIsZUFBTyxLQUFLLEtBQUssT0FBYSxHQUFHLEtBQUssV0FBVyxJQUFJLFFBQVEsSUFBSSxFQUFFLFNBQVMsV0FBVSxDQUFFO01BQzVGOzt5QkF4Q1MscUJBQWtCLHVCQUFBLGNBQUEsR0FBQSx1QkFBQSx1QkFBQSxDQUFBO01BQUE7b0VBQWxCLHFCQUFrQixTQUFsQixvQkFBa0IsV0FBQSxZQURMLE9BQU0sQ0FBQTs7Ozs7O0FDWGhDLFNBQVMsY0FBQUMsbUJBQWtCO0FBQzNCLFNBQXNCLGNBQWM7OztBQURwQyxJQVNhO0FBVGI7O0FBR0E7QUFDQTs7QUFLTSxJQUFPLGtCQUFQLE1BQU8saUJBQWU7TUFHWjtNQUNBO01BSFosZ0JBQXlCO01BQ3pCLFlBQ1ksZ0JBQ0EsUUFBYztBQURkLGFBQUEsaUJBQUE7QUFDQSxhQUFBLFNBQUE7TUFDVDtNQUVHLGNBQVc7O0FBQ2IsZUFBSyxlQUFlLGVBQWMsRUFBRyxVQUFVLENBQUMsZ0JBQWU7QUFDM0QsZ0JBQUksYUFBYTtBQUNiLG1CQUFLLGdCQUFnQixhQUFhLGVBQWUsU0FBUyxlQUFlOztVQUVqRixDQUFDO0FBRUQsY0FBSSxDQUFDLEtBQUssZUFBZTtBQUNyQixpQkFBSyxPQUFPLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQztBQUMzQyxtQkFBTzs7QUFFWCxpQkFBTztRQUNYOzs7eUJBbkJTLGtCQUFlLHVCQUFBLGNBQUEsR0FBQSx1QkFBQSxTQUFBLENBQUE7TUFBQTtvRUFBZixrQkFBZSxTQUFmLGlCQUFlLFdBQUEsWUFGWixPQUFNLENBQUE7Ozs7IiwibmFtZXMiOlsiSW5qZWN0YWJsZSIsIkh0dHBDbGllbnQiLCJJbmplY3RhYmxlIl19