import {
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  __esm,
  init_artemis_translate_pipe,
  init_shared_module
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/entities/complaint.model.ts
var ComplaintType, Complaint;
var init_complaint_model = __esm({
  "src/main/webapp/app/entities/complaint.model.ts"() {
    (function(ComplaintType2) {
      ComplaintType2["COMPLAINT"] = "COMPLAINT";
      ComplaintType2["MORE_FEEDBACK"] = "MORE_FEEDBACK";
    })(ComplaintType || (ComplaintType = {}));
    Complaint = class {
      id;
      complaintText;
      accepted;
      submittedTime;
      result;
      student;
      team;
      complaintType;
      complaintResponse;
      constructor() {
      }
    };
  }
});

// src/main/webapp/app/exercises/text/participate/string-count.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var StringCountService;
var init_string_count_service = __esm({
  "src/main/webapp/app/exercises/text/participate/string-count.service.ts"() {
    StringCountService = class _StringCountService {
      wordMatchRegex = /[\w\u00C0-\u00ff]+/g;
      constructor() {
      }
      countWords(text) {
        let wordCount = 0;
        if (text) {
          const match = text.match(this.wordMatchRegex);
          if (match) {
            wordCount = match.length;
          }
        }
        return wordCount;
      }
      countCharacters(text) {
        if (text) {
          return text.length;
        } else {
          return 0;
        }
      }
      static \u0275fac = function StringCountService_Factory(t) {
        return new (t || _StringCountService)();
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _StringCountService, factory: _StringCountService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/shared/textarea/textarea-counter.component.ts
import { Component, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function TextareaCounterComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n    ");
    i02.\u0275\u0275elementStart(1, "span", 0);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate2("\n        ", i02.\u0275\u0275pipeBind2(3, 2, "artemisApp.textExercise.characterCount", i02.\u0275\u0275pureFunction1(5, _c0, ctx_r0.characterCount)), " / ", ctx_r0.maxLength, "\n    ");
  }
}
var _c0, TextareaCounterComponent;
var init_textarea_counter_component = __esm({
  "src/main/webapp/app/shared/textarea/textarea-counter.component.ts"() {
    init_string_count_service();
    init_string_count_service();
    init_artemis_translate_pipe();
    _c0 = (a0) => ({ count: a0 });
    TextareaCounterComponent = class _TextareaCounterComponent {
      stringCountService;
      maxLength;
      content;
      visible;
      constructor(stringCountService) {
        this.stringCountService = stringCountService;
      }
      get characterCount() {
        return this.stringCountService.countCharacters(this.content);
      }
      static \u0275fac = function TextareaCounterComponent_Factory(t) {
        return new (t || _TextareaCounterComponent)(i02.\u0275\u0275directiveInject(StringCountService));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _TextareaCounterComponent, selectors: [["jhi-textarea-counter"]], inputs: { maxLength: "maxLength", content: "content", visible: "visible" }, features: [i02.\u0275\u0275ProvidersFeature([])], decls: 1, vars: 1, consts: [[1, "badge", "bg-primary", "mb-2", "mt-1", 2, "float", "right"]], template: function TextareaCounterComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275template(0, TextareaCounterComponent_Conditional_0_Template, 5, 7);
        }
        if (rf & 2) {
          i02.\u0275\u0275conditional(0, ctx.visible ? 0 : -1);
        }
      }, dependencies: [ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(TextareaCounterComponent, { className: "TextareaCounterComponent" });
    })();
  }
});

// src/main/webapp/app/shared/textarea/textarea.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var TextareaModule;
var init_textarea_module = __esm({
  "src/main/webapp/app/shared/textarea/textarea.module.ts"() {
    init_textarea_counter_component();
    init_shared_module();
    TextareaModule = class _TextareaModule {
      static \u0275fac = function TextareaModule_Factory(t) {
        return new (t || _TextareaModule)();
      };
      static \u0275mod = i03.\u0275\u0275defineNgModule({ type: _TextareaModule });
      static \u0275inj = i03.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule] });
    };
  }
});

export {
  ComplaintType,
  Complaint,
  init_complaint_model,
  StringCountService,
  init_string_count_service,
  TextareaCounterComponent,
  init_textarea_counter_component,
  TextareaModule,
  init_textarea_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvY29tcGxhaW50Lm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvdGV4dC9wYXJ0aWNpcGF0ZS9zdHJpbmctY291bnQuc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3RleHRhcmVhL3RleHRhcmVhLWNvdW50ZXIuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvdGV4dGFyZWEvdGV4dGFyZWEtY291bnRlci5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3RleHRhcmVhL3RleHRhcmVhLm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZGF5anMgZnJvbSAnZGF5anMvZXNtJztcbmltcG9ydCB7IFVzZXIgfSBmcm9tICdhcHAvY29yZS91c2VyL3VzZXIubW9kZWwnO1xuaW1wb3J0IHsgQmFzZUVudGl0eSB9IGZyb20gJ2FwcC9zaGFyZWQvbW9kZWwvYmFzZS1lbnRpdHknO1xuaW1wb3J0IHsgUmVzdWx0IH0gZnJvbSAnYXBwL2VudGl0aWVzL3Jlc3VsdC5tb2RlbCc7XG5pbXBvcnQgeyBUZWFtIH0gZnJvbSAnYXBwL2VudGl0aWVzL3RlYW0ubW9kZWwnO1xuaW1wb3J0IHsgQ29tcGxhaW50UmVzcG9uc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvY29tcGxhaW50LXJlc3BvbnNlLm1vZGVsJztcblxuZXhwb3J0IGVudW0gQ29tcGxhaW50VHlwZSB7XG4gICAgQ09NUExBSU5UID0gJ0NPTVBMQUlOVCcsXG4gICAgTU9SRV9GRUVEQkFDSyA9ICdNT1JFX0ZFRURCQUNLJyxcbn1cblxuZXhwb3J0IGNsYXNzIENvbXBsYWludCBpbXBsZW1lbnRzIEJhc2VFbnRpdHkge1xuICAgIHB1YmxpYyBpZD86IG51bWJlcjtcblxuICAgIHB1YmxpYyBjb21wbGFpbnRUZXh0Pzogc3RyaW5nO1xuICAgIHB1YmxpYyBhY2NlcHRlZD86IGJvb2xlYW47XG4gICAgcHVibGljIHN1Ym1pdHRlZFRpbWU/OiBkYXlqcy5EYXlqcztcbiAgICBwdWJsaWMgcmVzdWx0PzogUmVzdWx0O1xuICAgIHB1YmxpYyBzdHVkZW50PzogVXNlcjtcbiAgICBwdWJsaWMgdGVhbT86IFRlYW07XG4gICAgcHVibGljIGNvbXBsYWludFR5cGU/OiBDb21wbGFpbnRUeXBlO1xuICAgIHB1YmxpYyBjb21wbGFpbnRSZXNwb25zZT86IENvbXBsYWludFJlc3BvbnNlO1xuXG4gICAgY29uc3RydWN0b3IoKSB7fVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ASW5qZWN0YWJsZSh7XG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxufSlcbmV4cG9ydCBjbGFzcyBTdHJpbmdDb3VudFNlcnZpY2Uge1xuICAgIC8qKlxuICAgICAqIGluY2x1ZGVzIExhdGluLTEgU3VwcGxlbWVudCAwMEMwIHRvIDAwRkYgdG8gc3VwcG9ydCBnZXJtYW4gXCJ1bWxhdXRlXCJcbiAgICAgKi9cbiAgICBwcml2YXRlIHJlYWRvbmx5IHdvcmRNYXRjaFJlZ2V4ID0gL1tcXHdcXHUwMEMwLVxcdTAwZmZdKy9nO1xuXG4gICAgY29uc3RydWN0b3IoKSB7fVxuXG4gICAgLyoqXG4gICAgICogQ291bnRzIHRoZSBudW1iZXIgb2Ygd29yZHMgaW4gYSB0ZXh0XG4gICAgICogQHBhcmFtIHRleHRcbiAgICAgKi9cbiAgICBwdWJsaWMgY291bnRXb3Jkcyh0ZXh0OiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKTogbnVtYmVyIHtcbiAgICAgICAgbGV0IHdvcmRDb3VudCA9IDA7XG4gICAgICAgIGlmICh0ZXh0KSB7XG4gICAgICAgICAgICBjb25zdCBtYXRjaCA9IHRleHQubWF0Y2godGhpcy53b3JkTWF0Y2hSZWdleCk7XG4gICAgICAgICAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgICAgICAgICB3b3JkQ291bnQgPSBtYXRjaC5sZW5ndGg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHdvcmRDb3VudDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDb3VudHMgdGhlIG51bWJlciBvZiBjaGFyYWN0ZXJzIGluIGEgdGV4dFxuICAgICAqIEBwYXJhbSB0ZXh0XG4gICAgICovXG4gICAgcHVibGljIGNvdW50Q2hhcmFjdGVycyh0ZXh0OiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKTogbnVtYmVyIHtcbiAgICAgICAgaWYgKHRleHQpIHtcbiAgICAgICAgICAgIHJldHVybiB0ZXh0Lmxlbmd0aDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU3RyaW5nQ291bnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy90ZXh0L3BhcnRpY2lwYXRlL3N0cmluZy1jb3VudC5zZXJ2aWNlJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktdGV4dGFyZWEtY291bnRlcicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL3RleHRhcmVhLWNvdW50ZXIuY29tcG9uZW50Lmh0bWwnLFxuICAgIHByb3ZpZGVyczogW10sXG59KVxuZXhwb3J0IGNsYXNzIFRleHRhcmVhQ291bnRlckNvbXBvbmVudCB7XG4gICAgQElucHV0KCkgbWF4TGVuZ3RoOiBudW1iZXI7XG4gICAgQElucHV0KCkgY29udGVudD86IHN0cmluZztcbiAgICBASW5wdXQoKSB2aXNpYmxlPzogYm9vbGVhbjtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgc3RyaW5nQ291bnRTZXJ2aWNlOiBTdHJpbmdDb3VudFNlcnZpY2UpIHt9XG5cbiAgICBnZXQgY2hhcmFjdGVyQ291bnQoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc3RyaW5nQ291bnRTZXJ2aWNlLmNvdW50Q2hhcmFjdGVycyh0aGlzLmNvbnRlbnQpO1xuICAgIH1cbn1cbiIsIkBpZiAodmlzaWJsZSkge1xuICAgIDxzcGFuIHN0eWxlPVwiZmxvYXQ6IHJpZ2h0XCIgY2xhc3M9XCJiYWRnZSBiZy1wcmltYXJ5IG1iLTIgbXQtMVwiPlxuICAgICAgICB7eyAnYXJ0ZW1pc0FwcC50ZXh0RXhlcmNpc2UuY2hhcmFjdGVyQ291bnQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZTogeyBjb3VudDogY2hhcmFjdGVyQ291bnQgfSB9fSAvIHt7IG1heExlbmd0aCB9fVxuICAgIDwvc3Bhbj5cbn1cbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBUZXh0YXJlYUNvdW50ZXJDb21wb25lbnQgfSBmcm9tICdhcHAvc2hhcmVkL3RleHRhcmVhL3RleHRhcmVhLWNvdW50ZXIuY29tcG9uZW50JztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtUZXh0YXJlYUNvdW50ZXJDb21wb25lbnRdLFxuICAgIGV4cG9ydHM6IFtUZXh0YXJlYUNvdW50ZXJDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBUZXh0YXJlYU1vZHVsZSB7fVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFPQSxJQUFZLGVBS0M7QUFMYjs7QUFBQSxLQUFBLFNBQVlBLGdCQUFhO0FBQ3JCLE1BQUFBLGVBQUEsV0FBQSxJQUFBO0FBQ0EsTUFBQUEsZUFBQSxlQUFBLElBQUE7SUFDSixHQUhZLGtCQUFBLGdCQUFhLENBQUEsRUFBQTtBQUtuQixJQUFPLFlBQVAsTUFBZ0I7TUFDWDtNQUVBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFFUCxjQUFBO01BQWU7Ozs7OztBQ3hCbkIsU0FBUyxrQkFBa0I7O0FBQTNCLElBS2E7QUFMYjs7QUFLTSxJQUFPLHFCQUFQLE1BQU8sb0JBQWtCO01BSVYsaUJBQWlCO01BRWxDLGNBQUE7TUFBZTtNQU1SLFdBQVcsTUFBK0I7QUFDN0MsWUFBSSxZQUFZO0FBQ2hCLFlBQUksTUFBTTtBQUNOLGdCQUFNLFFBQVEsS0FBSyxNQUFNLEtBQUssY0FBYztBQUM1QyxjQUFJLE9BQU87QUFDUCx3QkFBWSxNQUFNOzs7QUFHMUIsZUFBTztNQUNYO01BTU8sZ0JBQWdCLE1BQStCO0FBQ2xELFlBQUksTUFBTTtBQUNOLGlCQUFPLEtBQUs7ZUFDVDtBQUNILGlCQUFPOztNQUVmOzt5QkFqQ1MscUJBQWtCO01BQUE7bUVBQWxCLHFCQUFrQixTQUFsQixvQkFBa0IsV0FBQSxZQUZmLE9BQU0sQ0FBQTs7Ozs7O0FDSHRCLFNBQVMsV0FBVyxhQUFhOzs7O0FDQzdCLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLElBQUE7Ozs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGNBQUEsMEJBQUEsR0FBQSxHQUFBLDBDQUFBLDhCQUFBLEdBQUEsS0FBQSxPQUFBLGNBQUEsQ0FBQSxHQUFBLE9BQUEsT0FBQSxXQUFBLFFBQUE7OztBREZSLFNBUWE7QUFSYjs7QUFDQTs7OztBQU9NLElBQU8sMkJBQVAsTUFBTywwQkFBd0I7TUFLYjtNQUpYO01BQ0E7TUFDQTtNQUVULFlBQW9CLG9CQUFzQztBQUF0QyxhQUFBLHFCQUFBO01BQXlDO01BRTdELElBQUksaUJBQWM7QUFDZCxlQUFPLEtBQUssbUJBQW1CLGdCQUFnQixLQUFLLE9BQU87TUFDL0Q7O3lCQVRTLDJCQUF3QixnQ0FBQSxrQkFBQSxDQUFBO01BQUE7aUVBQXhCLDJCQUF3QixXQUFBLENBQUEsQ0FBQSxzQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFdBQUEsYUFBQSxTQUFBLFdBQUEsU0FBQSxVQUFBLEdBQUEsVUFBQSxDQUFBLGlDQUZ0QixDQUFBLENBQUUsQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxTQUFBLGNBQUEsUUFBQSxRQUFBLEdBQUEsU0FBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsa0NBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNOakIsVUFBQSx5QkFBQSxHQUFBLGlEQUFBLEdBQUEsQ0FBQTs7O0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsVUFBQSxJQUFBLEVBQUE7Ozs7O3FGRFFhLDBCQUF3QixFQUFBLFdBQUEsMkJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFUnJDLFNBQVMsZ0JBQWdCOztBQUF6QixJQVNhO0FBVGI7O0FBQ0E7QUFDQTtBQU9NLElBQU8saUJBQVAsTUFBTyxnQkFBYzs7eUJBQWQsaUJBQWM7TUFBQTtnRUFBZCxnQkFBYyxDQUFBO29FQUpiLG1CQUFtQixFQUFBLENBQUE7Ozs7IiwibmFtZXMiOlsiQ29tcGxhaW50VHlwZSJdfQ==