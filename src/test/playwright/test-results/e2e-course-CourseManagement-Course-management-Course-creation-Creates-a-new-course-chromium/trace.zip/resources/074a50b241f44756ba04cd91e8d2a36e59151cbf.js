import {
  __async,
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/core/theme/theme.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faMoon, faSun } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { LocalStorageService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import { BehaviorSubject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
var THEME_LOCAL_STORAGE_KEY, THEME_OVERRIDE_ID, Theme, ThemeService;
var init_theme_service = __esm({
  "src/main/webapp/app/core/theme/theme.service.ts"() {
    THEME_LOCAL_STORAGE_KEY = "artemisapp.theme.preference";
    THEME_OVERRIDE_ID = "artemis-theme-override";
    Theme = class _Theme {
      static LIGHT = new _Theme("LIGHT", true, void 0, faSun, "chrome", "dreamweaver");
      static DARK = new _Theme("DARK", false, "theme-dark.css", faMoon, "dracula", "dracula");
      constructor(identifier, isDefault, fileName, icon, markdownAceTheme, codeAceTheme) {
        this.identifier = identifier;
        this.isDefault = isDefault;
        this.fileName = fileName;
        this.icon = icon;
        this.markdownAceTheme = markdownAceTheme;
        this.codeAceTheme = codeAceTheme;
      }
      identifier;
      isDefault;
      fileName;
      icon;
      markdownAceTheme;
      codeAceTheme;
      static get all() {
        return [this.LIGHT, this.DARK];
      }
    };
    ThemeService = class _ThemeService {
      localStorageService;
      currentTheme = Theme.LIGHT;
      currentThemeSubject = new BehaviorSubject(Theme.LIGHT);
      preferenceSubject = new BehaviorSubject(void 0);
      darkSchemeMediaQuery;
      constructor(localStorageService) {
        this.localStorageService = localStorageService;
      }
      getCurrentTheme() {
        return this.currentTheme;
      }
      getCurrentThemeObservable() {
        return this.currentThemeSubject.asObservable();
      }
      getPreferenceObservable() {
        return this.preferenceSubject.asObservable();
      }
      initialize() {
        this.darkSchemeMediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
        if (this.darkSchemeMediaQuery.media !== "not all") {
          this.darkSchemeMediaQuery.addEventListener("change", () => this.applyPreferredTheme());
        }
        addEventListener("storage", (event) => {
          if (event.key === "jhi-" + THEME_LOCAL_STORAGE_KEY) {
            this.preferenceSubject.next(this.getStoredTheme());
            this.applyPreferredTheme();
          }
        });
        this.applyPreferredTheme();
        this.preferenceSubject.next(this.getStoredTheme());
      }
      applyPreferredTheme() {
        const storedTheme = this.getStoredTheme();
        if (storedTheme) {
          this.applyThemeInternal(storedTheme);
          return;
        }
        if (this.darkSchemeMediaQuery.matches) {
          this.applyThemeInternal(Theme.DARK);
          return;
        }
        this.applyThemeInternal(Theme.LIGHT);
      }
      getStoredTheme() {
        const storedIdentifier = this.localStorageService.retrieve(THEME_LOCAL_STORAGE_KEY);
        const storedTheme = Theme.all.find((theme) => theme.identifier === storedIdentifier);
        if (storedIdentifier && !storedTheme) {
          this.storePreference(void 0);
        }
        return storedTheme;
      }
      print() {
        return __async(this, null, function* () {
          return new Promise((resolve) => {
            const overrideTag = document.getElementById(THEME_OVERRIDE_ID);
            if (overrideTag) {
              overrideTag.rel = "none-tmp";
            }
            setTimeout(() => {
              const notificationSidebarDisplayAttribute = this.hideNotificationSidebar();
              window.print();
              this.showNotificationSidebar(notificationSidebarDisplayAttribute);
            }, 250);
            setTimeout(() => {
              if (overrideTag) {
                overrideTag.rel = "stylesheet";
              }
              resolve();
            }, 500);
          });
        });
      }
      applyThemeExplicitly(theme) {
        this.storePreference(theme);
        this.applyPreferredTheme();
      }
      applyThemeInternal(theme) {
        if (!theme) {
          return;
        }
        if (this.currentTheme === theme) {
          return;
        }
        const overrideTag = document.getElementById(THEME_OVERRIDE_ID);
        if (theme.isDefault) {
          overrideTag?.remove();
          this.currentTheme = theme;
          this.currentThemeSubject.next(theme);
        } else {
          const head = document.getElementsByTagName("head")[0];
          const newTag = document.createElement("link");
          newTag.id = THEME_OVERRIDE_ID;
          newTag.rel = "stylesheet";
          newTag.href = theme.fileName + "?_=" + (/* @__PURE__ */ new Date()).setMinutes(0, 0, 0);
          newTag.onload = () => {
            overrideTag?.remove();
            this.currentTheme = theme;
            this.currentThemeSubject.next(theme);
          };
          const existingLinkTags = head.getElementsByTagName("link");
          const lastLinkTag = existingLinkTags[existingLinkTags.length - 1];
          head.insertBefore(newTag, lastLinkTag?.nextSibling);
        }
      }
      storePreference(theme) {
        if (theme) {
          this.localStorageService.store(THEME_LOCAL_STORAGE_KEY, theme.identifier);
        } else {
          this.localStorageService.clear(THEME_LOCAL_STORAGE_KEY);
        }
        if (this.preferenceSubject.getValue() !== theme) {
          this.preferenceSubject.next(theme);
        }
      }
      hideNotificationSidebar() {
        return this.modifyNotificationSidebarDisplayStyling();
      }
      showNotificationSidebar(displayAttributeBeforeHide) {
        return this.modifyNotificationSidebarDisplayStyling(displayAttributeBeforeHide);
      }
      modifyNotificationSidebarDisplayStyling(newDisplayAttribute) {
        const notificationSidebarElement = document.getElementById("notification-sidebar");
        let displayBefore = "";
        if (notificationSidebarElement) {
          displayBefore = notificationSidebarElement.style.display;
          notificationSidebarElement.style.display = newDisplayAttribute !== void 0 ? newDisplayAttribute : "none";
        }
        return displayBefore;
      }
      static \u0275fac = function ThemeService_Factory(t) {
        return new (t || _ThemeService)(i0.\u0275\u0275inject(i1.LocalStorageService));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _ThemeService, factory: _ThemeService.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  Theme,
  ThemeService,
  init_theme_service
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvY29yZS90aGVtZS90aGVtZS5zZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEljb25EZWZpbml0aW9uLCBmYU1vb24sIGZhU3VuIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IExvY2FsU3RvcmFnZVNlcnZpY2UgfSBmcm9tICduZ3gtd2Vic3RvcmFnZSc7XG5pbXBvcnQgeyBCZWhhdmlvclN1YmplY3QsIE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcblxuZXhwb3J0IGNvbnN0IFRIRU1FX0xPQ0FMX1NUT1JBR0VfS0VZID0gJ2FydGVtaXNhcHAudGhlbWUucHJlZmVyZW5jZSc7XG5leHBvcnQgY29uc3QgVEhFTUVfT1ZFUlJJREVfSUQgPSAnYXJ0ZW1pcy10aGVtZS1vdmVycmlkZSc7XG5cbi8qKlxuICogQ29udGFpbnMgZGVmaW5pdGlvbnMgZm9yIGEgdGhlbWUuXG4gKiBJZiB5b3UgYWRkIG5ldyB0aGVtZXMsIG1ha2Ugc3VyZSB0byBhZGFwdCB0aGUgdGhlbWUgc3dpdGNoIGNvbXBvbmVudCB3aGljaCBjdXJyZW50bHkgb25seSBzdXBwb3J0cyB0d28gdGhlbWVzLlxuICovXG5leHBvcnQgY2xhc3MgVGhlbWUge1xuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTElHSFQgPSBuZXcgVGhlbWUoJ0xJR0hUJywgdHJ1ZSwgdW5kZWZpbmVkLCBmYVN1biwgJ2Nocm9tZScsICdkcmVhbXdlYXZlcicpO1xuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgREFSSyA9IG5ldyBUaGVtZSgnREFSSycsIGZhbHNlLCAndGhlbWUtZGFyay5jc3MnLCBmYU1vb24sICdkcmFjdWxhJywgJ2RyYWN1bGEnKTtcblxuICAgIHByaXZhdGUgY29uc3RydWN0b3IoaWRlbnRpZmllcjogc3RyaW5nLCBpc0RlZmF1bHQ6IGJvb2xlYW4sIGZpbGVOYW1lOiBzdHJpbmcgfCB1bmRlZmluZWQsIGljb246IEljb25EZWZpbml0aW9uLCBtYXJrZG93bkFjZVRoZW1lOiBzdHJpbmcsIGNvZGVBY2VUaGVtZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuaWRlbnRpZmllciA9IGlkZW50aWZpZXI7XG4gICAgICAgIHRoaXMuaXNEZWZhdWx0ID0gaXNEZWZhdWx0O1xuICAgICAgICB0aGlzLmZpbGVOYW1lID0gZmlsZU5hbWU7XG4gICAgICAgIHRoaXMuaWNvbiA9IGljb247XG4gICAgICAgIHRoaXMubWFya2Rvd25BY2VUaGVtZSA9IG1hcmtkb3duQWNlVGhlbWU7XG4gICAgICAgIHRoaXMuY29kZUFjZVRoZW1lID0gY29kZUFjZVRoZW1lO1xuICAgIH1cblxuICAgIHB1YmxpYyByZWFkb25seSBpZGVudGlmaWVyOiBzdHJpbmc7XG4gICAgcHVibGljIHJlYWRvbmx5IGlzRGVmYXVsdDogYm9vbGVhbjtcbiAgICBwdWJsaWMgcmVhZG9ubHkgZmlsZU5hbWU6IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgICBwdWJsaWMgcmVhZG9ubHkgaWNvbjogSWNvbkRlZmluaXRpb247XG4gICAgcHVibGljIHJlYWRvbmx5IG1hcmtkb3duQWNlVGhlbWU6IHN0cmluZztcbiAgICBwdWJsaWMgcmVhZG9ubHkgY29kZUFjZVRoZW1lOiBzdHJpbmc7XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGFuIGFycmF5IHdpdGggYWxsIGF2YWlsYWJsZSB0aGVtZXMuXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXQgYWxsKCk6IFRoZW1lW10ge1xuICAgICAgICByZXR1cm4gW3RoaXMuTElHSFQsIHRoaXMuREFSS107XG4gICAgfVxufVxuXG4vKipcbiAqIFNlcnZpY2UgdGhhdCBtYW5hZ2VzIGFwcGxpY2F0aW9uIFVJIHRoZW1pbmcuXG4gKiBQcm92aWRlcyB0aGUgY3VycmVudCB0aGVtZSBpbmZvcm1hdGlvbiB0byBvdGhlciBjb21wb25lbnRzIGFuZCBzZXJ2aWNlcy5cbiAqIEFwcGxpZXMgbmV3IHRoZW1lcyBhcyByZXF1ZXN0ZWQgZnJvbSBvdGhlciBjb21wb25lbnRzIC8gc2VydmljZXMsIHVzdWFsbHkgdGhlIHRoZW1lIHN3aXRjaGVyIGNvbXBvbmVudC5cbiAqL1xuQEluamVjdGFibGUoe1xuICAgIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgVGhlbWVTZXJ2aWNlIHtcbiAgICAvKipcbiAgICAgKiBUaGUgY3VycmVudGx5IGFwcGxpZWQgdGhlbWVcbiAgICAgKi9cbiAgICBwcml2YXRlIGN1cnJlbnRUaGVtZTogVGhlbWUgPSBUaGVtZS5MSUdIVDtcbiAgICAvKipcbiAgICAgKiBBIGJlaGF2aW9yIHN1YmplY3QgdGhhdCBmaXJlcyBmb3IgZWFjaCBuZXcgYXBwbGllZCB0aGVtZS5cbiAgICAgKi9cbiAgICBwcml2YXRlIGN1cnJlbnRUaGVtZVN1YmplY3Q6IEJlaGF2aW9yU3ViamVjdDxUaGVtZT4gPSBuZXcgQmVoYXZpb3JTdWJqZWN0PFRoZW1lPihUaGVtZS5MSUdIVCk7XG4gICAgLyoqXG4gICAgICogQSBiZWhhdmlvciBzdWJqZWN0IHRoYXQgZmlyZXMgaWYgdGhlIHVzZXIgcHJlZmVyZW5jZSBjaGFuZ2VzLlxuICAgICAqIENhbiBiZSBlaXRoZXIgYSB0aGVtZSBmb3IgYW4gZXhwbGljaXQgdGhlbWUgb3IgdW5kZWZpbmVkIGlmIHN5c3RlbSBzZXR0aW5ncyBhcmUgcHJlZmVycmVkXG4gICAgICovXG4gICAgcHJpdmF0ZSBwcmVmZXJlbmNlU3ViamVjdDogQmVoYXZpb3JTdWJqZWN0PFRoZW1lIHwgdW5kZWZpbmVkPiA9IG5ldyBCZWhhdmlvclN1YmplY3Q8VGhlbWUgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG5cbiAgICBwcml2YXRlIGRhcmtTY2hlbWVNZWRpYVF1ZXJ5OiBNZWRpYVF1ZXJ5TGlzdDtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgbG9jYWxTdG9yYWdlU2VydmljZTogTG9jYWxTdG9yYWdlU2VydmljZSkge31cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIGN1cnJlbnRseSBhY3RpdmUgdGhlbWUuXG4gICAgICovXG4gICAgcHVibGljIGdldEN1cnJlbnRUaGVtZSgpOiBUaGVtZSB7XG4gICAgICAgIHJldHVybiB0aGlzLmN1cnJlbnRUaGVtZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGFuIG9ic2VydmFibGUgdGhhdCB3aWxsIGJlIGZpcmVkIGltbWVkaWF0ZWx5IGZvciB0aGUgY3VycmVudCB0aGVtZSBhbmQgZm9yIGVhY2ggZnV0dXJlIHRoZW1lIGNoYW5nZSB1bnRpbCB1bnN1YnNjcmliZWQuXG4gICAgICovXG4gICAgcHVibGljIGdldEN1cnJlbnRUaGVtZU9ic2VydmFibGUoKTogT2JzZXJ2YWJsZTxUaGVtZT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5jdXJyZW50VGhlbWVTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgYW4gb2JzZXJ2YWJsZSB0aGF0IHdpbGwgYmUgZmlyZWQgaW1tZWRpYXRlbHkgZm9yIHRoZSBjdXJyZW50IHVzZXIgcHJlZmVyZW5jZSBhbmQgaWYgdGhlIHVzZXIgcHJlZmVyZW5jZSBjaGFuZ2VzLlxuICAgICAqIENhbiBiZSBlaXRoZXIgYSB0aGVtZSBmb3IgYW4gZXhwbGljaXQgdGhlbWUgb3IgdW5kZWZpbmVkIGlmIHN5c3RlbSBzZXR0aW5ncyBhcmUgcHJlZmVycmVkXG4gICAgICovXG4gICAgcHVibGljIGdldFByZWZlcmVuY2VPYnNlcnZhYmxlKCk6IE9ic2VydmFibGU8VGhlbWUgfCB1bmRlZmluZWQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJlZmVyZW5jZVN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2hvdWxkIGJlIGNhbGxlZCBvbmNlIG9uIGFwcGxpY2F0aW9uIHN0YXJ0dXAuXG4gICAgICogU2V0cyB1cCB0aGUgc3lzdGVtIHByZWZlcmVuY2UgbGlzdGVuZXIgYW5kIGFwcGxpZXMgdGhlIHRoZW1lIGluaXRpYWxseVxuICAgICAqIFNldHMgdXAgYSBsb2NhbCBzdG9yYWdlIGxpc3RlbmVyIHRvIGFjY291bnQgZm9yIGNoYW5nZXMgaW4gb3RoZXIgdGFic1xuICAgICAqL1xuICAgIGluaXRpYWxpemUoKSB7XG4gICAgICAgIHRoaXMuZGFya1NjaGVtZU1lZGlhUXVlcnkgPSB3aW5kb3cubWF0Y2hNZWRpYSgnKHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKScpO1xuICAgICAgICBpZiAodGhpcy5kYXJrU2NoZW1lTWVkaWFRdWVyeS5tZWRpYSAhPT0gJ25vdCBhbGwnKSB7XG4gICAgICAgICAgICB0aGlzLmRhcmtTY2hlbWVNZWRpYVF1ZXJ5LmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHRoaXMuYXBwbHlQcmVmZXJyZWRUaGVtZSgpKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGFkZEV2ZW50TGlzdGVuZXIoJ3N0b3JhZ2UnLCAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgIGlmIChldmVudC5rZXkgPT09ICdqaGktJyArIFRIRU1FX0xPQ0FMX1NUT1JBR0VfS0VZKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wcmVmZXJlbmNlU3ViamVjdC5uZXh0KHRoaXMuZ2V0U3RvcmVkVGhlbWUoKSk7XG4gICAgICAgICAgICAgICAgdGhpcy5hcHBseVByZWZlcnJlZFRoZW1lKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMuYXBwbHlQcmVmZXJyZWRUaGVtZSgpO1xuICAgICAgICB0aGlzLnByZWZlcmVuY2VTdWJqZWN0Lm5leHQodGhpcy5nZXRTdG9yZWRUaGVtZSgpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBBcHBsaWVzIHRoZSBwcmVmZXJyZWQgdGhlbWUuXG4gICAgICogVGhlIHByZWZlcnJlZCB0aGVtZSBpcyBlaXRoZXJcbiAgICAgKiAtIHRoZSB0aGVtZSBzdG9yZWQgaW4gbG9jYWwgc3RvcmFnZSwgaWYgcHJlc2VudCwgb3IgZWxzZVxuICAgICAqIC0gdGhlIHN5c3RlbSBwcmVmZXJlbmNlLCBpZiBwcmVzZW50LCBvciBlbHNlXG4gICAgICogLSB0aGUgZGVmYXVsdCB0aGVtZVxuICAgICAqL1xuICAgIHByaXZhdGUgYXBwbHlQcmVmZXJyZWRUaGVtZSgpIHtcbiAgICAgICAgY29uc3Qgc3RvcmVkVGhlbWUgPSB0aGlzLmdldFN0b3JlZFRoZW1lKCk7XG4gICAgICAgIGlmIChzdG9yZWRUaGVtZSkge1xuICAgICAgICAgICAgdGhpcy5hcHBseVRoZW1lSW50ZXJuYWwoc3RvcmVkVGhlbWUpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMuZGFya1NjaGVtZU1lZGlhUXVlcnkubWF0Y2hlcykge1xuICAgICAgICAgICAgdGhpcy5hcHBseVRoZW1lSW50ZXJuYWwoVGhlbWUuREFSSyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmFwcGx5VGhlbWVJbnRlcm5hbChUaGVtZS5MSUdIVCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgdGhlbWUgcHJlZmVyZW5jZSBzdG9yZWQgaW4gbG9jYWwgc3RvcmFnZSBvciB1bmRlZmluZWQgaWYgbm8gcHJlZmVyZW5jZSBpcyBzdG9yZWRcbiAgICAgKi9cbiAgICBwcml2YXRlIGdldFN0b3JlZFRoZW1lKCk6IFRoZW1lIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgY29uc3Qgc3RvcmVkSWRlbnRpZmllciA9IHRoaXMubG9jYWxTdG9yYWdlU2VydmljZS5yZXRyaWV2ZShUSEVNRV9MT0NBTF9TVE9SQUdFX0tFWSk7XG4gICAgICAgIGNvbnN0IHN0b3JlZFRoZW1lID0gVGhlbWUuYWxsLmZpbmQoKHRoZW1lKSA9PiB0aGVtZS5pZGVudGlmaWVyID09PSBzdG9yZWRJZGVudGlmaWVyKTtcblxuICAgICAgICAvLyBBbiB1bmtub3duIHRoZW1lIHdhcyBzdG9yZWQuIExldCdzIGNsZWFyIGl0XG4gICAgICAgIGlmIChzdG9yZWRJZGVudGlmaWVyICYmICFzdG9yZWRUaGVtZSkge1xuICAgICAgICAgICAgdGhpcy5zdG9yZVByZWZlcmVuY2UodW5kZWZpbmVkKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBzdG9yZWRUaGVtZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBQcmludHMgdGhlIGN1cnJlbnQgcGFnZS5cbiAgICAgKiBEaXNhYmxlcyBhbnkgdGhlbWUgb3ZlcnJpZGUgYmVmb3JlIGRvaW5nIHRoYXQgdG8gZW5zdXJlIHRoYXQgd2UgcHJpbnQgaW4gZGVmYXVsdCB0aGVtZS5cbiAgICAgKiBSZXNldHMgdGhlIHRoZW1lIGFmdGVyd2FyZCBpZiBuZWVkZWRcbiAgICAgKi9cbiAgICBwdWJsaWMgYXN5bmMgcHJpbnQoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuICAgICAgICAgICAgY29uc3Qgb3ZlcnJpZGVUYWc6IGFueSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFRIRU1FX09WRVJSSURFX0lEKTtcbiAgICAgICAgICAgIGlmIChvdmVycmlkZVRhZykge1xuICAgICAgICAgICAgICAgIG92ZXJyaWRlVGFnLnJlbCA9ICdub25lLXRtcCc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBub3RpZmljYXRpb25TaWRlYmFyRGlzcGxheUF0dHJpYnV0ZSA9IHRoaXMuaGlkZU5vdGlmaWNhdGlvblNpZGViYXIoKTtcblxuICAgICAgICAgICAgICAgIHdpbmRvdy5wcmludCgpO1xuXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93Tm90aWZpY2F0aW9uU2lkZWJhcihub3RpZmljYXRpb25TaWRlYmFyRGlzcGxheUF0dHJpYnV0ZSk7XG4gICAgICAgICAgICB9LCAyNTApO1xuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKG92ZXJyaWRlVGFnKSB7XG4gICAgICAgICAgICAgICAgICAgIG92ZXJyaWRlVGFnLnJlbCA9ICdzdHlsZXNoZWV0JztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgfSwgNTAwKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQXBwbGllcyB0aGUgc3BlY2lmaWVkIHRoZW1lLlxuICAgICAqIFNob3VsZCBvbmx5IGJlIGNhbGxlZCB1cG9uIHVzZXIgcmVxdWVzdC5cbiAgICAgKiBTdG9yZXMgdGhlIHByZWZlcmVuY2UgaW4gbG9jYWwgc3RvcmFnZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB0aGVtZSB0aGUgdGhlbWUgdG8gYmUgYXBwbGllZDsgcGFzcyB1bmRlZmluZWQgdG8gdXNlIHN5c3RlbSBwcmVmZXJlbmNlIG1vZGVcbiAgICAgKi9cbiAgICBwdWJsaWMgYXBwbHlUaGVtZUV4cGxpY2l0bHkodGhlbWU6IFRoZW1lIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuc3RvcmVQcmVmZXJlbmNlKHRoZW1lKTtcbiAgICAgICAgdGhpcy5hcHBseVByZWZlcnJlZFRoZW1lKCk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBhcHBseVRoZW1lSW50ZXJuYWwodGhlbWU6IFRoZW1lKSB7XG4gICAgICAgIGlmICghdGhlbWUpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIERvIG5vdCBpbmplY3Qgb3IgcmVtb3ZlIGFueXRoaW5nIGZyb20gdGhlIERPTSBpZiB0aGUgYXBwbGllZCB0aGVtZSBpcyB0aGUgY3VycmVudCB0aGVtZVxuICAgICAgICBpZiAodGhpcy5jdXJyZW50VGhlbWUgPT09IHRoZW1lKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBHZXQgY3VycmVudCA8bGluaz4gdGhlbWUgb3ZlcnJpZGVcbiAgICAgICAgY29uc3Qgb3ZlcnJpZGVUYWcgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChUSEVNRV9PVkVSUklERV9JRCk7XG5cbiAgICAgICAgaWYgKHRoZW1lLmlzRGVmYXVsdCkge1xuICAgICAgICAgICAgLy8gVGhlIGRlZmF1bHQgdGhlbWUgaXMgYWx3YXlzIGluamVjdGVkIGJ5IEFuZ3VsYXI7IHRoZXJlZm9yZSwgd2UganVzdCBuZWVkIHRvIHJlbW92ZVxuICAgICAgICAgICAgLy8gb3VyIHRoZW1lIG92ZXJyaWRlLCBpZiBwcmVzZW50XG4gICAgICAgICAgICBvdmVycmlkZVRhZz8ucmVtb3ZlKCk7XG5cbiAgICAgICAgICAgIHRoaXMuY3VycmVudFRoZW1lID0gdGhlbWU7XG4gICAgICAgICAgICB0aGlzLmN1cnJlbnRUaGVtZVN1YmplY3QubmV4dCh0aGVtZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBJZiB0aGUgdGhlbWUgaXMgbm90IHRoZSBkZWZhdWx0IHRoZW1lLCB3ZSBuZWVkIHRvIGFkZCBhIHRoZW1lIG92ZXJyaWRlIHN0eWxlc2hlZXQgdG8gdGhlIHBhZ2UgaGVhZGVyXG5cbiAgICAgICAgICAgIC8vIFNlbGVjdCB0aGUgaGVhZCBlbGVtZW50XG4gICAgICAgICAgICBjb25zdCBoZWFkID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2hlYWQnKVswXTtcblxuICAgICAgICAgICAgLy8gQ3JlYXRlIG5ldyBvdmVycmlkZSB0YWcgZnJvbSB0aGUgY3VycmVudCB0aGVtZVxuICAgICAgICAgICAgY29uc3QgbmV3VGFnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGluaycpO1xuICAgICAgICAgICAgbmV3VGFnLmlkID0gVEhFTUVfT1ZFUlJJREVfSUQ7XG4gICAgICAgICAgICBuZXdUYWcucmVsID0gJ3N0eWxlc2hlZXQnO1xuICAgICAgICAgICAgLy8gVXNlIGNhY2hlIGJ1c3Rpbmcgc28gdGhlIGJyb3dzZXIgd2lsbCByZWxvYWQgdGhlIHN0eWxlc2hlZXQgYXQgbGVhc3Qgb25jZSBwZXIgaG91clxuICAgICAgICAgICAgbmV3VGFnLmhyZWYgPSB0aGVtZS5maWxlTmFtZSEgKyAnP189JyArIG5ldyBEYXRlKCkuc2V0TWludXRlcygwLCAwLCAwKTtcblxuICAgICAgICAgICAgLy8gQXMgc29vbiBhcyB0aGUgbmV3IHN0eWxlIHNoZWV0IGxvYWRlZCwgcmVtb3ZlIHRoZSBvbGQgb3ZlcnJpZGUgKGlmIHByZXNlbnQpXG4gICAgICAgICAgICAvLyBhbmQgZmlyZSB0aGUgc3ViamVjdCB0byBpbmZvcm0gb3RoZXIgc2VydmljZXMgYW5kIGNvbXBvbmVudHNcbiAgICAgICAgICAgIG5ld1RhZy5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgb3ZlcnJpZGVUYWc/LnJlbW92ZSgpO1xuICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFRoZW1lID0gdGhlbWU7XG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VGhlbWVTdWJqZWN0Lm5leHQodGhlbWUpO1xuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgLy8gSW5zZXJ0IHRoZSBuZXcgc3R5bGVzaGVldCBsaW5rIHRhZyBhZnRlciB0aGUgbGFzdCBleGlzdGluZyBsaW5rIHRhZ1xuICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdMaW5rVGFncyA9IGhlYWQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2xpbmsnKTtcbiAgICAgICAgICAgIGNvbnN0IGxhc3RMaW5rVGFnID0gZXhpc3RpbmdMaW5rVGFnc1tleGlzdGluZ0xpbmtUYWdzLmxlbmd0aCAtIDFdO1xuICAgICAgICAgICAgaGVhZC5pbnNlcnRCZWZvcmUobmV3VGFnLCBsYXN0TGlua1RhZz8ubmV4dFNpYmxpbmcpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzdG9yZVByZWZlcmVuY2UodGhlbWU/OiBUaGVtZSkge1xuICAgICAgICBpZiAodGhlbWUpIHtcbiAgICAgICAgICAgIHRoaXMubG9jYWxTdG9yYWdlU2VydmljZS5zdG9yZShUSEVNRV9MT0NBTF9TVE9SQUdFX0tFWSwgdGhlbWUuaWRlbnRpZmllcik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmxvY2FsU3RvcmFnZVNlcnZpY2UuY2xlYXIoVEhFTUVfTE9DQUxfU1RPUkFHRV9LRVkpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMucHJlZmVyZW5jZVN1YmplY3QuZ2V0VmFsdWUoKSAhPT0gdGhlbWUpIHtcbiAgICAgICAgICAgIHRoaXMucHJlZmVyZW5jZVN1YmplY3QubmV4dCh0aGVtZSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIaWRlcyB0aGUgbm90aWZpY2F0aW9uIHNpZGViYXIgYXMgdGhlcmUgd2lsbCBiZSBhbiBvdmVybGF5IG92ZSB0aGUgd2hvbGUgcGFnZVxuICAgICAqIHRoYXQgY292ZXJzIGRldGFpbHMgb2YgdGhlIGV4YW0gc3VtbWFyeSAoPT4gZXhhbSBzdW1tYXJ5IGNhbm5vdCBiZSByZWFkKS5cbiAgICAgKlxuICAgICAqIEByZXR1cm4gZGlzcGxheUF0dHJpYnV0ZSBvZiB0aGUgbm90aWZpY2F0aW9uIHNpZGViYXIgYmVmb3JlIGhpZGluZyBpdFxuICAgICAqL1xuICAgIHByaXZhdGUgaGlkZU5vdGlmaWNhdGlvblNpZGViYXIoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMubW9kaWZ5Tm90aWZpY2F0aW9uU2lkZWJhckRpc3BsYXlTdHlsaW5nKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQWZ0ZXIgcHJpbnRpbmcgdGhlIG5vdGlmaWNhdGlvbiBzaWRlYmFyIHNoYWxsIGJlIGRpc3BsYXllZCBhZ2Fpbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBkaXNwbGF5QXR0cmlidXRlQmVmb3JlSGlkZSB0byByZXNldCB0aGUgbm90aWZpY2F0aW9uIHNpZGViYXIgdG8gaXRzIHByZXZpb3VzIHN0YXRlXG4gICAgICogQHJldHVybiBkaXNwbGF5QXR0cmlidXRlIG9mIHRoZSBub3RpZmljYXRpb24gc2lkZWJhciBiZWZvcmUgaGlkaW5nIGl0XG4gICAgICovXG4gICAgcHJpdmF0ZSBzaG93Tm90aWZpY2F0aW9uU2lkZWJhcihkaXNwbGF5QXR0cmlidXRlQmVmb3JlSGlkZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMubW9kaWZ5Tm90aWZpY2F0aW9uU2lkZWJhckRpc3BsYXlTdHlsaW5nKGRpc3BsYXlBdHRyaWJ1dGVCZWZvcmVIaWRlKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBAcGFyYW0gbmV3RGlzcGxheUF0dHJpYnV0ZSB0aGF0IGlzIHNldCBmb3IgdGhlIHtAbGluayBOb3RpZmljYXRpb25TaWRlYmFyQ29tcG9uZW50fVxuICAgICAqIEByZXR1cm4gZGlzcGxheUF0dHJpYnV0ZSBvZiB0aGUgbm90aWZpY2F0aW9uIHNpZGViYXIgYmVmb3JlIGhpZGluZyBpdFxuICAgICAqL1xuICAgIHByaXZhdGUgbW9kaWZ5Tm90aWZpY2F0aW9uU2lkZWJhckRpc3BsYXlTdHlsaW5nKG5ld0Rpc3BsYXlBdHRyaWJ1dGU/OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgICAgICBjb25zdCBub3RpZmljYXRpb25TaWRlYmFyRWxlbWVudDogYW55ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ25vdGlmaWNhdGlvbi1zaWRlYmFyJyk7XG4gICAgICAgIGxldCBkaXNwbGF5QmVmb3JlID0gJyc7XG5cbiAgICAgICAgaWYgKG5vdGlmaWNhdGlvblNpZGViYXJFbGVtZW50KSB7XG4gICAgICAgICAgICBkaXNwbGF5QmVmb3JlID0gbm90aWZpY2F0aW9uU2lkZWJhckVsZW1lbnQuc3R5bGUuZGlzcGxheTtcbiAgICAgICAgICAgIG5vdGlmaWNhdGlvblNpZGViYXJFbGVtZW50LnN0eWxlLmRpc3BsYXkgPSBuZXdEaXNwbGF5QXR0cmlidXRlICE9PSB1bmRlZmluZWQgPyBuZXdEaXNwbGF5QXR0cmlidXRlIDogJ25vbmUnO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkaXNwbGF5QmVmb3JlO1xuICAgIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBeUIsUUFBUSxhQUFhO0FBQzlDLFNBQVMsMkJBQTJCO0FBQ3BDLFNBQVMsdUJBQW1DOzs7QUFINUMsSUFLYSx5QkFDQSxtQkFNQSxPQW9DQTtBQWhEYjs7QUFLTyxJQUFNLDBCQUEwQjtBQUNoQyxJQUFNLG9CQUFvQjtBQU0zQixJQUFPLFFBQVAsTUFBTyxPQUFLO01BQ1AsT0FBZ0IsUUFBUSxJQUFJLE9BQU0sU0FBUyxNQUFNLFFBQVcsT0FBTyxVQUFVLGFBQWE7TUFDMUYsT0FBZ0IsT0FBTyxJQUFJLE9BQU0sUUFBUSxPQUFPLGtCQUFrQixRQUFRLFdBQVcsU0FBUztNQUVyRyxZQUFvQixZQUFvQixXQUFvQixVQUE4QixNQUFzQixrQkFBMEIsY0FBb0I7QUFDMUosYUFBSyxhQUFhO0FBQ2xCLGFBQUssWUFBWTtBQUNqQixhQUFLLFdBQVc7QUFDaEIsYUFBSyxPQUFPO0FBQ1osYUFBSyxtQkFBbUI7QUFDeEIsYUFBSyxlQUFlO01BQ3hCO01BRWdCO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUtULFdBQVcsTUFBRztBQUNqQixlQUFPLENBQUMsS0FBSyxPQUFPLEtBQUssSUFBSTtNQUNqQzs7QUFXRSxJQUFPLGVBQVAsTUFBTyxjQUFZO01BaUJEO01BYlosZUFBc0IsTUFBTTtNQUk1QixzQkFBOEMsSUFBSSxnQkFBdUIsTUFBTSxLQUFLO01BS3BGLG9CQUF3RCxJQUFJLGdCQUFtQyxNQUFTO01BRXhHO01BRVIsWUFBb0IscUJBQXdDO0FBQXhDLGFBQUEsc0JBQUE7TUFBMkM7TUFLeEQsa0JBQWU7QUFDbEIsZUFBTyxLQUFLO01BQ2hCO01BS08sNEJBQXlCO0FBQzVCLGVBQU8sS0FBSyxvQkFBb0IsYUFBWTtNQUNoRDtNQU1PLDBCQUF1QjtBQUMxQixlQUFPLEtBQUssa0JBQWtCLGFBQVk7TUFDOUM7TUFPQSxhQUFVO0FBQ04sYUFBSyx1QkFBdUIsT0FBTyxXQUFXLDhCQUE4QjtBQUM1RSxZQUFJLEtBQUsscUJBQXFCLFVBQVUsV0FBVztBQUMvQyxlQUFLLHFCQUFxQixpQkFBaUIsVUFBVSxNQUFNLEtBQUssb0JBQW1CLENBQUU7O0FBR3pGLHlCQUFpQixXQUFXLENBQUMsVUFBUztBQUNsQyxjQUFJLE1BQU0sUUFBUSxTQUFTLHlCQUF5QjtBQUNoRCxpQkFBSyxrQkFBa0IsS0FBSyxLQUFLLGVBQWMsQ0FBRTtBQUNqRCxpQkFBSyxvQkFBbUI7O1FBRWhDLENBQUM7QUFFRCxhQUFLLG9CQUFtQjtBQUN4QixhQUFLLGtCQUFrQixLQUFLLEtBQUssZUFBYyxDQUFFO01BQ3JEO01BU1Esc0JBQW1CO0FBQ3ZCLGNBQU0sY0FBYyxLQUFLLGVBQWM7QUFDdkMsWUFBSSxhQUFhO0FBQ2IsZUFBSyxtQkFBbUIsV0FBVztBQUNuQzs7QUFHSixZQUFJLEtBQUsscUJBQXFCLFNBQVM7QUFDbkMsZUFBSyxtQkFBbUIsTUFBTSxJQUFJO0FBQ2xDOztBQUdKLGFBQUssbUJBQW1CLE1BQU0sS0FBSztNQUN2QztNQUtRLGlCQUFjO0FBQ2xCLGNBQU0sbUJBQW1CLEtBQUssb0JBQW9CLFNBQVMsdUJBQXVCO0FBQ2xGLGNBQU0sY0FBYyxNQUFNLElBQUksS0FBSyxDQUFDLFVBQVUsTUFBTSxlQUFlLGdCQUFnQjtBQUduRixZQUFJLG9CQUFvQixDQUFDLGFBQWE7QUFDbEMsZUFBSyxnQkFBZ0IsTUFBUzs7QUFHbEMsZUFBTztNQUNYO01BT2EsUUFBSzs7QUFDZCxpQkFBTyxJQUFJLFFBQWMsQ0FBQyxZQUFXO0FBQ2pDLGtCQUFNLGNBQW1CLFNBQVMsZUFBZSxpQkFBaUI7QUFDbEUsZ0JBQUksYUFBYTtBQUNiLDBCQUFZLE1BQU07O0FBRXRCLHVCQUFXLE1BQUs7QUFDWixvQkFBTSxzQ0FBc0MsS0FBSyx3QkFBdUI7QUFFeEUscUJBQU8sTUFBSztBQUVaLG1CQUFLLHdCQUF3QixtQ0FBbUM7WUFDcEUsR0FBRyxHQUFHO0FBQ04sdUJBQVcsTUFBSztBQUNaLGtCQUFJLGFBQWE7QUFDYiw0QkFBWSxNQUFNOztBQUV0QixzQkFBTztZQUNYLEdBQUcsR0FBRztVQUNWLENBQUM7UUFDTDs7TUFTTyxxQkFBcUIsT0FBd0I7QUFDaEQsYUFBSyxnQkFBZ0IsS0FBSztBQUMxQixhQUFLLG9CQUFtQjtNQUM1QjtNQUVRLG1CQUFtQixPQUFZO0FBQ25DLFlBQUksQ0FBQyxPQUFPO0FBQ1I7O0FBSUosWUFBSSxLQUFLLGlCQUFpQixPQUFPO0FBQzdCOztBQUlKLGNBQU0sY0FBYyxTQUFTLGVBQWUsaUJBQWlCO0FBRTdELFlBQUksTUFBTSxXQUFXO0FBR2pCLHVCQUFhLE9BQU07QUFFbkIsZUFBSyxlQUFlO0FBQ3BCLGVBQUssb0JBQW9CLEtBQUssS0FBSztlQUNoQztBQUlILGdCQUFNLE9BQU8sU0FBUyxxQkFBcUIsTUFBTSxFQUFFLENBQUM7QUFHcEQsZ0JBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxpQkFBTyxLQUFLO0FBQ1osaUJBQU8sTUFBTTtBQUViLGlCQUFPLE9BQU8sTUFBTSxXQUFZLFNBQVEsb0JBQUksS0FBSSxHQUFHLFdBQVcsR0FBRyxHQUFHLENBQUM7QUFJckUsaUJBQU8sU0FBUyxNQUFLO0FBQ2pCLHlCQUFhLE9BQU07QUFDbkIsaUJBQUssZUFBZTtBQUNwQixpQkFBSyxvQkFBb0IsS0FBSyxLQUFLO1VBQ3ZDO0FBR0EsZ0JBQU0sbUJBQW1CLEtBQUsscUJBQXFCLE1BQU07QUFDekQsZ0JBQU0sY0FBYyxpQkFBaUIsaUJBQWlCLFNBQVMsQ0FBQztBQUNoRSxlQUFLLGFBQWEsUUFBUSxhQUFhLFdBQVc7O01BRTFEO01BRVEsZ0JBQWdCLE9BQWE7QUFDakMsWUFBSSxPQUFPO0FBQ1AsZUFBSyxvQkFBb0IsTUFBTSx5QkFBeUIsTUFBTSxVQUFVO2VBQ3JFO0FBQ0gsZUFBSyxvQkFBb0IsTUFBTSx1QkFBdUI7O0FBRzFELFlBQUksS0FBSyxrQkFBa0IsU0FBUSxNQUFPLE9BQU87QUFDN0MsZUFBSyxrQkFBa0IsS0FBSyxLQUFLOztNQUV6QztNQVFRLDBCQUF1QjtBQUMzQixlQUFPLEtBQUssd0NBQXVDO01BQ3ZEO01BUVEsd0JBQXdCLDRCQUFrQztBQUM5RCxlQUFPLEtBQUssd0NBQXdDLDBCQUEwQjtNQUNsRjtNQU1RLHdDQUF3QyxxQkFBNEI7QUFDeEUsY0FBTSw2QkFBa0MsU0FBUyxlQUFlLHNCQUFzQjtBQUN0RixZQUFJLGdCQUFnQjtBQUVwQixZQUFJLDRCQUE0QjtBQUM1QiwwQkFBZ0IsMkJBQTJCLE1BQU07QUFDakQscUNBQTJCLE1BQU0sVUFBVSx3QkFBd0IsU0FBWSxzQkFBc0I7O0FBRXpHLGVBQU87TUFDWDs7eUJBeE9TLGVBQVksc0JBQUEsc0JBQUEsQ0FBQTtNQUFBO21FQUFaLGVBQVksU0FBWixjQUFZLFdBQUEsWUFGVCxPQUFNLENBQUE7Ozs7IiwibmFtZXMiOltdfQ==