import {
  AssessmentType,
  Exercise,
  ExerciseType,
  __esm,
  init_assessment_type_model,
  init_exercise_model
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/entities/text-exercise.model.ts
var TextExercise;
var init_text_exercise_model = __esm({
  "src/main/webapp/app/entities/text-exercise.model.ts"() {
    init_exercise_model();
    init_assessment_type_model();
    TextExercise = class extends Exercise {
      exampleSolution;
      constructor(course, exerciseGroup) {
        super(ExerciseType.TEXT);
        this.course = course;
        this.exerciseGroup = exerciseGroup;
        this.assessmentType = AssessmentType.MANUAL;
      }
    };
  }
});

export {
  TextExercise,
  init_text_exercise_model
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvdGV4dC1leGVyY2lzZS5tb2RlbC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFeGVyY2lzZSwgRXhlcmNpc2VUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IENvdXJzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb3Vyc2UubW9kZWwnO1xuaW1wb3J0IHsgRXhlcmNpc2VHcm91cCB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS1ncm91cC5tb2RlbCc7XG5pbXBvcnQgeyBBc3Nlc3NtZW50VHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9hc3Nlc3NtZW50LXR5cGUubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgVGV4dEV4ZXJjaXNlIGV4dGVuZHMgRXhlcmNpc2Uge1xuICAgIHB1YmxpYyBleGFtcGxlU29sdXRpb24/OiBzdHJpbmc7XG5cbiAgICBjb25zdHJ1Y3Rvcihjb3Vyc2U6IENvdXJzZSB8IHVuZGVmaW5lZCwgZXhlcmNpc2VHcm91cDogRXhlcmNpc2VHcm91cCB8IHVuZGVmaW5lZCkge1xuICAgICAgICBzdXBlcihFeGVyY2lzZVR5cGUuVEVYVCk7XG4gICAgICAgIHRoaXMuY291cnNlID0gY291cnNlO1xuICAgICAgICB0aGlzLmV4ZXJjaXNlR3JvdXAgPSBleGVyY2lzZUdyb3VwO1xuICAgICAgICAvLyBTZXQgYSBkZWZhdWx0IHZhbHVlXG4gICAgICAgIHRoaXMuYXNzZXNzbWVudFR5cGUgPSBBc3Nlc3NtZW50VHlwZS5NQU5VQUw7XG4gICAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsSUFLYTtBQUxiOzs7QUFHQTtBQUVNLElBQU8sZUFBUCxjQUE0QixTQUFRO01BQy9CO01BRVAsWUFBWSxRQUE0QixlQUF3QztBQUM1RSxjQUFNLGFBQWEsSUFBSTtBQUN2QixhQUFLLFNBQVM7QUFDZCxhQUFLLGdCQUFnQjtBQUVyQixhQUFLLGlCQUFpQixlQUFlO01BQ3pDOzs7OyIsIm5hbWVzIjpbXX0=