import {
  OrionAssessmentService,
  OrionConnectorService,
  init_orion_assessment_service,
  init_orion_connector_service
} from "/chunk-ELJG2GZQ.js";
import {
  BuildLogEntryArray,
  BuildLogService,
  FeatureToggleModule,
  ParticipationWebsocketService,
  ProgrammingSubmissionService,
  init_build_log_model,
  init_build_log_service,
  init_feature_toggle_module,
  init_orion_filter_directive,
  init_participation_websocket_service,
  init_programming_submission_service
} from "/chunk-ORYTP7RT.js";
import {
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  FeatureToggle,
  FeatureToggleDirective,
  Feedback,
  __esm,
  init_artemis_translate_pipe,
  init_feature_toggle_directive,
  init_feature_toggle_service,
  init_feedback_model,
  init_shared_module
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/orion/orion-button/orion-button.component.ts
import { Component, EventEmitter, Input, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faCircleNotch } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function OrionButtonComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275element(1, "span", 2);
    i0.\u0275\u0275text(2, "\n    ");
  }
}
var OrionButtonComponent;
var init_orion_button_component = __esm({
  "src/main/webapp/app/shared/orion/orion-button/orion-button.component.ts"() {
    init_feature_toggle_service();
    init_feature_toggle_directive();
    OrionButtonComponent = class _OrionButtonComponent {
      buttonLabel;
      buttonLoading = false;
      outlined = false;
      smallButton = false;
      disabled = false;
      featureToggle = FeatureToggle.ProgrammingExercises;
      clickHandler = new EventEmitter();
      faCircleNotch = faCircleNotch;
      constructor() {
      }
      get btnPrimary() {
        return !this.outlined;
      }
      handleClick() {
        if (!this.buttonLoading) {
          this.clickHandler.emit();
        }
      }
      static \u0275fac = function OrionButtonComponent_Factory(t) {
        return new (t || _OrionButtonComponent)();
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _OrionButtonComponent, selectors: [["jhi-ide-button"]], inputs: { buttonLabel: "buttonLabel", buttonLoading: "buttonLoading", outlined: "outlined", smallButton: "smallButton", disabled: "disabled", featureToggle: "featureToggle" }, outputs: { clickHandler: "clickHandler" }, decls: 9, vars: 13, consts: [[1, "btn", 3, "jhiFeatureToggle", "overwriteDisabled", "click"], [3, "hidden", "spin", "icon"], [1, "intellij-logo"]], template: function OrionButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "button", 0);
          i0.\u0275\u0275listener("click", function OrionButtonComponent_Template_button_click_0_listener() {
            return ctx.handleClick();
          });
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275element(2, "fa-icon", 1);
          i0.\u0275\u0275text(3, "\n    ");
          i0.\u0275\u0275template(4, OrionButtonComponent_Conditional_4_Template, 3, 0);
          i0.\u0275\u0275elementStart(5, "span");
          i0.\u0275\u0275text(6);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(7, "\n");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(8, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275classProp("btn-outline-primary", ctx.outlined)("btn-primary", ctx.btnPrimary)("btn-sm", ctx.smallButton);
          i0.\u0275\u0275property("jhiFeatureToggle", ctx.featureToggle)("overwriteDisabled", ctx.buttonLoading);
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275property("hidden", !ctx.buttonLoading)("spin", true)("icon", ctx.faCircleNotch);
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275conditional(4, !ctx.buttonLoading ? 4 : -1);
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275textInterpolate(ctx.buttonLabel);
        }
      }, dependencies: [i1.FaIconComponent, FeatureToggleDirective], styles: ['\n\n.intellij-logo[_ngcontent-%COMP%] {\n  height: 20px;\n  width: 20px;\n  display: inline-block;\n  vertical-align: middle;\n  background: url("./media/intellij_logo.png") no-repeat center center;\n  background-size: contain;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvb3Jpb24vb3Jpb24tYnV0dG9uL29yaW9uLWJ1dHRvbi5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmludGVsbGlqLWxvZ28ge1xuICAgIGhlaWdodDogMjBweDtcbiAgICB3aWR0aDogMjBweDtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICBiYWNrZ3JvdW5kOiB1cmwoJy4uLy4uLy4uLy4uL2NvbnRlbnQvaW1hZ2VzL2ludGVsbGlqX2xvZ28ucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXI7XG4gICAgYmFja2dyb3VuZC1zaXplOiBjb250YWluO1xufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLENBQUE7QUFDSSxVQUFBO0FBQ0EsU0FBQTtBQUNBLFdBQUE7QUFDQSxrQkFBQTtBQUNBLGNBQUEsaUNBQUEsVUFBQSxPQUFBO0FBQ0EsbUJBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */'] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(OrionButtonComponent, { className: "OrionButtonComponent" });
    })();
  }
});

// src/main/webapp/app/shared/orion/modal-confirm-autofocus/modal-confirm-autofocus.component.ts
import { Component as Component2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgbActiveModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
var ModalConfirmAutofocusComponent;
var init_modal_confirm_autofocus_component = __esm({
  "src/main/webapp/app/shared/orion/modal-confirm-autofocus/modal-confirm-autofocus.component.ts"() {
    init_artemis_translate_pipe();
    ModalConfirmAutofocusComponent = class _ModalConfirmAutofocusComponent {
      modal;
      title;
      text;
      constructor(modal) {
        this.modal = modal;
      }
      static \u0275fac = function ModalConfirmAutofocusComponent_Factory(t) {
        return new (t || _ModalConfirmAutofocusComponent)(i02.\u0275\u0275directiveInject(i12.NgbActiveModal));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _ModalConfirmAutofocusComponent, selectors: [["jhi-modal-confirm-autofocus"]], decls: 25, vars: 6, consts: [[1, "modal-header"], [1, "modal-title"], ["type", "button", "aria-label", "Close button", "aria-describedby", "modal-title", 1, "btn-close", 3, "click"], [1, "modal-body"], [1, "modal-footer"], ["type", "button", 1, "btn", "btn-outline-secondary", 3, "click"], ["type", "button", "ngbAutofocus", "", 1, "btn", "btn-danger", 3, "click"]], template: function ModalConfirmAutofocusComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div", 0);
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275elementStart(2, "h4", 1);
          i02.\u0275\u0275text(3);
          i02.\u0275\u0275pipe(4, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(5, "\n    ");
          i02.\u0275\u0275elementStart(6, "button", 2);
          i02.\u0275\u0275listener("click", function ModalConfirmAutofocusComponent_Template_button_click_6_listener() {
            return ctx.modal.dismiss("Cross click");
          });
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(7, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(8, "\n");
          i02.\u0275\u0275elementStart(9, "div", 3);
          i02.\u0275\u0275text(10, "\n    ");
          i02.\u0275\u0275elementStart(11, "p");
          i02.\u0275\u0275text(12);
          i02.\u0275\u0275pipe(13, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(14, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(15, "\n");
          i02.\u0275\u0275elementStart(16, "div", 4);
          i02.\u0275\u0275text(17, "\n    ");
          i02.\u0275\u0275elementStart(18, "button", 5);
          i02.\u0275\u0275listener("click", function ModalConfirmAutofocusComponent_Template_button_click_18_listener() {
            return ctx.modal.dismiss("cancel click");
          });
          i02.\u0275\u0275text(19, "Cancel");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(20, "\n    ");
          i02.\u0275\u0275elementStart(21, "button", 6);
          i02.\u0275\u0275listener("click", function ModalConfirmAutofocusComponent_Template_button_click_21_listener() {
            return ctx.modal.close("Ok click");
          });
          i02.\u0275\u0275text(22, "Ok");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(23, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(24, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(4, 2, ctx.title));
          i02.\u0275\u0275advance(9);
          i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(13, 4, ctx.text));
        }
      }, dependencies: [ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(ModalConfirmAutofocusComponent, { className: "ModalConfirmAutofocusComponent" });
    })();
  }
});

// src/main/webapp/app/shared/orion/orion-build-and-test.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { filter, map, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { Subject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var OrionBuildAndTestService;
var init_orion_build_and_test_service = __esm({
  "src/main/webapp/app/shared/orion/orion-build-and-test.service.ts"() {
    init_programming_submission_service();
    init_participation_websocket_service();
    init_build_log_service();
    init_build_log_model();
    init_orion_connector_service();
    init_feedback_model();
    init_programming_submission_service();
    init_participation_websocket_service();
    init_orion_connector_service();
    init_build_log_service();
    OrionBuildAndTestService = class _OrionBuildAndTestService {
      submissionService;
      participationWebsocketService;
      orionConnectorService;
      buildLogService;
      buildFinished = new Subject();
      resultSubscription;
      buildLogSubscription;
      latestResult;
      constructor(submissionService, participationWebsocketService, orionConnectorService, buildLogService) {
        this.submissionService = submissionService;
        this.participationWebsocketService = participationWebsocketService;
        this.orionConnectorService = orionConnectorService;
        this.buildLogService = buildLogService;
      }
      buildAndTestExercise(exercise) {
        const participationId = exercise.studentParticipations[0].id;
        this.submissionService.triggerBuild(participationId).subscribe();
        this.listenOnBuildOutputAndForwardChanges(exercise);
      }
      listenOnBuildOutputAndForwardChanges(exercise, participation) {
        const participationId = participation ? participation.id : exercise.studentParticipations[0].id;
        this.orionConnectorService.onBuildStarted(exercise.problemStatement);
        if (this.resultSubscription) {
          this.resultSubscription.unsubscribe();
        }
        if (this.buildLogSubscription) {
          this.buildLogSubscription.unsubscribe();
        }
        this.resultSubscription = this.participationWebsocketService.subscribeForLatestResultOfParticipation(participationId, true).pipe(filter(Boolean), map((result) => result), filter((result) => !this.latestResult || this.latestResult.id < result.id), tap((result) => {
          this.latestResult = result;
          if (!result.submission || result.submission.buildFailed) {
            this.forwardBuildLogs(participationId, exercise.programmingLanguage, exercise.projectType);
          } else {
            const testCaseFeedback = result.feedbacks.filter((feedback) => Feedback.isTestCaseFeedback(feedback));
            testCaseFeedback.forEach((feedback) => this.orionConnectorService.onTestResult(!!feedback.positive, feedback.testCase.testName, feedback.detailText));
            this.orionConnectorService.onBuildFinished();
            this.buildFinished.next();
          }
          this.participationWebsocketService.unsubscribeForLatestResultOfParticipation(participationId, exercise);
        })).subscribe();
        return this.buildFinished;
      }
      forwardBuildLogs(participationId, programmingLanguage, projectType) {
        this.buildLogSubscription = this.buildLogService.getBuildLogs(participationId).pipe(map((logs) => new BuildLogEntryArray(...logs)), tap((logs) => {
          const logErrors = logs.extractErrors(programmingLanguage, projectType);
          this.orionConnectorService.onBuildFailed(logErrors);
          this.buildFinished.next();
        })).subscribe();
      }
      static \u0275fac = function OrionBuildAndTestService_Factory(t) {
        return new (t || _OrionBuildAndTestService)(i03.\u0275\u0275inject(ProgrammingSubmissionService), i03.\u0275\u0275inject(ParticipationWebsocketService), i03.\u0275\u0275inject(OrionConnectorService), i03.\u0275\u0275inject(BuildLogService));
      };
      static \u0275prov = i03.\u0275\u0275defineInjectable({ token: _OrionBuildAndTestService, factory: _OrionBuildAndTestService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/shared/orion/orion.module.ts
import { APP_INITIALIZER, NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { CommonModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import { TranslateModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function initOrionConnector(connector) {
  return () => OrionConnectorService.initConnector(connector);
}
var OrionModule;
var init_orion_module = __esm({
  "src/main/webapp/app/shared/orion/orion.module.ts"() {
    init_orion_button_component();
    init_orion_connector_service();
    init_modal_confirm_autofocus_component();
    init_orion_filter_directive();
    init_orion_build_and_test_service();
    init_feature_toggle_module();
    init_shared_module();
    init_orion_assessment_service();
    OrionModule = class _OrionModule {
      static \u0275fac = function OrionModule_Factory(t) {
        return new (t || _OrionModule)();
      };
      static \u0275mod = i04.\u0275\u0275defineNgModule({ type: _OrionModule });
      static \u0275inj = i04.\u0275\u0275defineInjector({ providers: [{ provide: APP_INITIALIZER, useFactory: initOrionConnector, deps: [OrionConnectorService], multi: true }, OrionBuildAndTestService, OrionAssessmentService], imports: [CommonModule, ArtemisSharedModule, TranslateModule, FeatureToggleModule] });
    };
  }
});

export {
  OrionButtonComponent,
  init_orion_button_component,
  ModalConfirmAutofocusComponent,
  init_modal_confirm_autofocus_component,
  OrionBuildAndTestService,
  init_orion_build_and_test_service,
  OrionModule,
  init_orion_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL29yaW9uL29yaW9uLWJ1dHRvbi9vcmlvbi1idXR0b24uY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvb3Jpb24vb3Jpb24tYnV0dG9uL29yaW9uLWJ1dHRvbi5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL29yaW9uL21vZGFsLWNvbmZpcm0tYXV0b2ZvY3VzL21vZGFsLWNvbmZpcm0tYXV0b2ZvY3VzLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL29yaW9uL21vZGFsLWNvbmZpcm0tYXV0b2ZvY3VzL21vZGFsLWNvbmZpcm0tYXV0b2ZvY3VzLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvb3Jpb24vb3Jpb24tYnVpbGQtYW5kLXRlc3Quc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL29yaW9uL29yaW9uLm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE91dHB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZmFDaXJjbGVOb3RjaCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBGZWF0dXJlVG9nZ2xlIH0gZnJvbSAnYXBwL3NoYXJlZC9mZWF0dXJlLXRvZ2dsZS9mZWF0dXJlLXRvZ2dsZS5zZXJ2aWNlJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktaWRlLWJ1dHRvbicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL29yaW9uLWJ1dHRvbi5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vb3Jpb24tYnV0dG9uLmNvbXBvbmVudC5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIE9yaW9uQnV0dG9uQ29tcG9uZW50IHtcbiAgICBASW5wdXQoKSBidXR0b25MYWJlbDogc3RyaW5nO1xuICAgIEBJbnB1dCgpIGJ1dHRvbkxvYWRpbmcgPSBmYWxzZTtcbiAgICBASW5wdXQoKSBvdXRsaW5lZCA9IGZhbHNlO1xuICAgIEBJbnB1dCgpIHNtYWxsQnV0dG9uID0gZmFsc2U7XG4gICAgQElucHV0KCkgZGlzYWJsZWQgPSBmYWxzZTtcbiAgICAvLyBEaXNhYmxlIGJ5IGZlYXR1cmUgdG9nZ2xlLlxuICAgIEBJbnB1dCgpIGZlYXR1cmVUb2dnbGU6IEZlYXR1cmVUb2dnbGUgPSBGZWF0dXJlVG9nZ2xlLlByb2dyYW1taW5nRXhlcmNpc2VzO1xuICAgIC8vIEluZGlyZWN0IGhhbmRsZXIgdG8gZGlzYWJsZSBjbGlja2luZyB3aGlsZSBsb2FkaW5nXG4gICAgQE91dHB1dCgpIGNsaWNrSGFuZGxlciA9IG5ldyBFdmVudEVtaXR0ZXI8dm9pZD4oKTtcblxuICAgIC8vIEljb25zXG4gICAgZmFDaXJjbGVOb3RjaCA9IGZhQ2lyY2xlTm90Y2g7XG5cbiAgICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgICBwdWJsaWMgZ2V0IGJ0blByaW1hcnkoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiAhdGhpcy5vdXRsaW5lZDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBGb3J3YXJkcyB0aGUgY2xpY2sgZXZlbnQgdG8gdGhlIGhhbmRsZXIgb25seSBpZiB0aGUgYnV0dG9uIGlzIGVuYWJsZWRcbiAgICAgKi9cbiAgICBwdWJsaWMgaGFuZGxlQ2xpY2soKSB7XG4gICAgICAgIGlmICghdGhpcy5idXR0b25Mb2FkaW5nKSB7XG4gICAgICAgICAgICB0aGlzLmNsaWNrSGFuZGxlci5lbWl0KCk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCI8YnV0dG9uXG4gICAgY2xhc3M9XCJidG5cIlxuICAgIFtqaGlGZWF0dXJlVG9nZ2xlXT1cImZlYXR1cmVUb2dnbGVcIlxuICAgIFtvdmVyd3JpdGVEaXNhYmxlZF09XCJidXR0b25Mb2FkaW5nXCJcbiAgICBbY2xhc3MuYnRuLW91dGxpbmUtcHJpbWFyeV09XCJvdXRsaW5lZFwiXG4gICAgW2NsYXNzLmJ0bi1wcmltYXJ5XT1cImJ0blByaW1hcnlcIlxuICAgIFtjbGFzcy5idG4tc21dPVwic21hbGxCdXR0b25cIlxuICAgIChjbGljayk9XCJoYW5kbGVDbGljaygpXCJcbj5cbiAgICA8ZmEtaWNvbiBbaGlkZGVuXT1cIiFidXR0b25Mb2FkaW5nXCIgW3NwaW5dPVwidHJ1ZVwiIFtpY29uXT1cImZhQ2lyY2xlTm90Y2hcIj48L2ZhLWljb24+XG4gICAgQGlmICghYnV0dG9uTG9hZGluZykge1xuICAgICAgICA8c3BhbiBjbGFzcz1cImludGVsbGlqLWxvZ29cIj48L3NwYW4+XG4gICAgfVxuICAgIDxzcGFuPnt7IGJ1dHRvbkxhYmVsIH19PC9zcGFuPlxuPC9idXR0b24+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE5nYkFjdGl2ZU1vZGFsIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1tb2RhbC1jb25maXJtLWF1dG9mb2N1cycsXG4gICAgdGVtcGxhdGVVcmw6ICcuL21vZGFsLWNvbmZpcm0tYXV0b2ZvY3VzLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgTW9kYWxDb25maXJtQXV0b2ZvY3VzQ29tcG9uZW50IHtcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHRleHQ6IHN0cmluZztcblxuICAgIGNvbnN0cnVjdG9yKHB1YmxpYyBtb2RhbDogTmdiQWN0aXZlTW9kYWwpIHt9XG59XG4iLCI8ZGl2IGNsYXNzPVwibW9kYWwtaGVhZGVyXCI+XG4gICAgPGg0IGNsYXNzPVwibW9kYWwtdGl0bGVcIj57eyB0aXRsZSB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2g0PlxuICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWNsb3NlXCIgYXJpYS1sYWJlbD1cIkNsb3NlIGJ1dHRvblwiIGFyaWEtZGVzY3JpYmVkYnk9XCJtb2RhbC10aXRsZVwiIChjbGljayk9XCJtb2RhbC5kaXNtaXNzKCdDcm9zcyBjbGljaycpXCI+PC9idXR0b24+XG48L2Rpdj5cbjxkaXYgY2xhc3M9XCJtb2RhbC1ib2R5XCI+XG4gICAgPHA+e3sgdGV4dCB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3A+XG48L2Rpdj5cbjxkaXYgY2xhc3M9XCJtb2RhbC1mb290ZXJcIj5cbiAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1zZWNvbmRhcnlcIiAoY2xpY2spPVwibW9kYWwuZGlzbWlzcygnY2FuY2VsIGNsaWNrJylcIj5DYW5jZWw8L2J1dHRvbj5cbiAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBuZ2JBdXRvZm9jdXMgY2xhc3M9XCJidG4gYnRuLWRhbmdlclwiIChjbGljayk9XCJtb2RhbC5jbG9zZSgnT2sgY2xpY2snKVwiPk9rPC9idXR0b24+XG48L2Rpdj5cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFByb2dyYW1taW5nU3VibWlzc2lvblNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3BhcnRpY2lwYXRlL3Byb2dyYW1taW5nLXN1Ym1pc3Npb24uc2VydmljZSc7XG5pbXBvcnQgeyBQYXJ0aWNpcGF0aW9uV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9vdmVydmlldy9wYXJ0aWNpcGF0aW9uLXdlYnNvY2tldC5zZXJ2aWNlJztcbmltcG9ydCB7IGZpbHRlciwgbWFwLCB0YXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBTdWJqZWN0LCBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEJ1aWxkTG9nU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL3NlcnZpY2UvYnVpbGQtbG9nLnNlcnZpY2UnO1xuaW1wb3J0IHsgUGFydGljaXBhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9wYXJ0aWNpcGF0aW9uL3BhcnRpY2lwYXRpb24ubW9kZWwnO1xuaW1wb3J0IHsgQnVpbGRMb2dFbnRyeUFycmF5IH0gZnJvbSAnYXBwL2VudGl0aWVzL2J1aWxkLWxvZy5tb2RlbCc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlLCBQcm9ncmFtbWluZ0xhbmd1YWdlLCBQcm9qZWN0VHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9wcm9ncmFtbWluZy1leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBSZXN1bHQgfSBmcm9tICdhcHAvZW50aXRpZXMvcmVzdWx0Lm1vZGVsJztcbmltcG9ydCB7IE9yaW9uQ29ubmVjdG9yU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvb3Jpb24vb3Jpb24tY29ubmVjdG9yLnNlcnZpY2UnO1xuaW1wb3J0IHsgRmVlZGJhY2sgfSBmcm9tICdhcHAvZW50aXRpZXMvZmVlZGJhY2subW9kZWwnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdTdWJtaXNzaW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3Byb2dyYW1taW5nLXN1Ym1pc3Npb24ubW9kZWwnO1xuXG4vKipcbiAqIE5vdGlmaWVzIHRoZSBJREUgYWJvdXQgYSByZXN1bHQsIHRoYXQgaXMgY3VycmVudGx5IGJ1aWxkaW5nIGFuZCBmb3J3YXJkcyBpbmNvbWluZyB0ZXN0IHJlc3VsdHMuXG4gKlxuICovXG5ASW5qZWN0YWJsZSh7XG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxufSlcbmV4cG9ydCBjbGFzcyBPcmlvbkJ1aWxkQW5kVGVzdFNlcnZpY2Uge1xuICAgIHByaXZhdGUgYnVpbGRGaW5pc2hlZCA9IG5ldyBTdWJqZWN0PHZvaWQ+KCk7XG4gICAgcHJpdmF0ZSByZXN1bHRTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcbiAgICBwcml2YXRlIGJ1aWxkTG9nU3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb247XG4gICAgcHJpdmF0ZSBsYXRlc3RSZXN1bHQ6IFJlc3VsdDtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIHN1Ym1pc3Npb25TZXJ2aWNlOiBQcm9ncmFtbWluZ1N1Ym1pc3Npb25TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHBhcnRpY2lwYXRpb25XZWJzb2NrZXRTZXJ2aWNlOiBQYXJ0aWNpcGF0aW9uV2Vic29ja2V0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBvcmlvbkNvbm5lY3RvclNlcnZpY2U6IE9yaW9uQ29ubmVjdG9yU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBidWlsZExvZ1NlcnZpY2U6IEJ1aWxkTG9nU2VydmljZSxcbiAgICApIHt9XG5cbiAgICAvKipcbiAgICAgKiBUcmlnZ2VyIGEgbmV3IGJ1aWxkIGZvciBhIHBhcnRpY2lwYXRpb24gZm9yIGFuIGV4ZXJjaXNlIGFuZCBub3RpZnkgdGhlIElERVxuICAgICAqXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlIFRoZSBleGVyY2lzZSBmb3Igd2hpY2ggYSBidWlsZCBzaG91bGQgZ2V0IHRyaWdnZXJlZFxuICAgICAqL1xuICAgIGJ1aWxkQW5kVGVzdEV4ZXJjaXNlKGV4ZXJjaXNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlKSB7XG4gICAgICAgIGNvbnN0IHBhcnRpY2lwYXRpb25JZCA9IGV4ZXJjaXNlLnN0dWRlbnRQYXJ0aWNpcGF0aW9ucyFbMF0uaWQhO1xuICAgICAgICAvLyBUcmlnZ2VyIGEgYnVpbGQgZm9yIHRoZSBjdXJyZW50IHBhcnRpY2lwYXRpb25cbiAgICAgICAgdGhpcy5zdWJtaXNzaW9uU2VydmljZS50cmlnZ2VyQnVpbGQocGFydGljaXBhdGlvbklkKS5zdWJzY3JpYmUoKTtcblxuICAgICAgICB0aGlzLmxpc3Rlbk9uQnVpbGRPdXRwdXRBbmRGb3J3YXJkQ2hhbmdlcyhleGVyY2lzZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTGlzdGVucyBvbiBhbnkgbmV3IGJ1aWxkcyBmb3IgdGhlIHVzZXIncyBwYXJ0aWNpcGF0aW9uIG9uIHRoZSB3ZWJzb2NrZXQgYW5kIGZvcndhcmRzIGluY29taW5nIHJlc3VsdHMgdG8gdGhlIElERVxuICAgICAqXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlIFRoZSBleGVyY2lzZSBmb3Igd2hpY2ggYnVpbGQgcmVzdWx0cyBzaG91bGQgZ2V0IGZvcndhcmRlZFxuICAgICAqIEBwYXJhbSBwYXJ0aWNpcGF0aW9uIFRoZSAob3B0aW9uYWwpIHBhcnRpY2lwYXRpb24gdG8gc3Vic2NyaWJlIHRvLiBUaGUgZGVmYXVsdCBpcyB0aGUgZmlyc3Qgc3R1ZGVudCBwYXJ0aWNpcGF0aW9uXG4gICAgICovXG4gICAgbGlzdGVuT25CdWlsZE91dHB1dEFuZEZvcndhcmRDaGFuZ2VzKGV4ZXJjaXNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlLCBwYXJ0aWNpcGF0aW9uPzogUGFydGljaXBhdGlvbik6IE9ic2VydmFibGU8dm9pZD4ge1xuICAgICAgICBjb25zdCBwYXJ0aWNpcGF0aW9uSWQgPSBwYXJ0aWNpcGF0aW9uID8gcGFydGljaXBhdGlvbi5pZCEgOiBleGVyY2lzZS5zdHVkZW50UGFydGljaXBhdGlvbnMhWzBdLmlkITtcbiAgICAgICAgdGhpcy5vcmlvbkNvbm5lY3RvclNlcnZpY2Uub25CdWlsZFN0YXJ0ZWQoZXhlcmNpc2UucHJvYmxlbVN0YXRlbWVudCEpO1xuXG4gICAgICAgIC8vIExpc3RlbiBmb3IgdGhlIG5ldyByZXN1bHQgb24gdGhlIHdlYnNvY2tldFxuICAgICAgICBpZiAodGhpcy5yZXN1bHRTdWJzY3JpcHRpb24pIHtcbiAgICAgICAgICAgIHRoaXMucmVzdWx0U3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuYnVpbGRMb2dTdWJzY3JpcHRpb24pIHtcbiAgICAgICAgICAgIHRoaXMuYnVpbGRMb2dTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnJlc3VsdFN1YnNjcmlwdGlvbiA9IHRoaXMucGFydGljaXBhdGlvbldlYnNvY2tldFNlcnZpY2VcbiAgICAgICAgICAgIC5zdWJzY3JpYmVGb3JMYXRlc3RSZXN1bHRPZlBhcnRpY2lwYXRpb24ocGFydGljaXBhdGlvbklkLCB0cnVlKVxuICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgZmlsdGVyKEJvb2xlYW4pLFxuICAgICAgICAgICAgICAgIG1hcCgocmVzdWx0KSA9PiByZXN1bHQgYXMgUmVzdWx0KSxcbiAgICAgICAgICAgICAgICBmaWx0ZXIoKHJlc3VsdCkgPT4gIXRoaXMubGF0ZXN0UmVzdWx0IHx8IHRoaXMubGF0ZXN0UmVzdWx0LmlkISA8IHJlc3VsdC5pZCEpLFxuICAgICAgICAgICAgICAgIHRhcCgocmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGF0ZXN0UmVzdWx0ID0gcmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAvLyBJZiB0aGVyZSB3YXMgYSBjb21waWxlIGVycm9yIG9yIHdlIGRvbid0IGhhdmUgYSBzdWJtaXNzaW9uLCB3ZSBoYXZlIHRvIGZldGNoIHRoZSBlcnJvciBvdXRwdXQsIG90aGVyd2lzZSB3ZSBjYW4gZm9yd2FyZCB0aGUgdGVzdCByZXN1bHRzXG4gICAgICAgICAgICAgICAgICAgIGlmICghcmVzdWx0LnN1Ym1pc3Npb24gfHwgKHJlc3VsdC5zdWJtaXNzaW9uIGFzIFByb2dyYW1taW5nU3VibWlzc2lvbikuYnVpbGRGYWlsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZm9yd2FyZEJ1aWxkTG9ncyhwYXJ0aWNpcGF0aW9uSWQsIGV4ZXJjaXNlLnByb2dyYW1taW5nTGFuZ3VhZ2UsIGV4ZXJjaXNlLnByb2plY3RUeXBlKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRPRE86IERlYWwgd2l0aCBzdGF0aWMgY29kZSBhbmFseXNpcyBmZWVkYmFjayBpbiBPcmlvblxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGVzdENhc2VGZWVkYmFjayA9IHJlc3VsdC5mZWVkYmFja3MhLmZpbHRlcigoZmVlZGJhY2spID0+IEZlZWRiYWNrLmlzVGVzdENhc2VGZWVkYmFjayhmZWVkYmFjaykpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGVzdENhc2VGZWVkYmFjay5mb3JFYWNoKChmZWVkYmFjaykgPT4gdGhpcy5vcmlvbkNvbm5lY3RvclNlcnZpY2Uub25UZXN0UmVzdWx0KCEhZmVlZGJhY2sucG9zaXRpdmUsIGZlZWRiYWNrLnRlc3RDYXNlIS50ZXN0TmFtZSEsIGZlZWRiYWNrLmRldGFpbFRleHQhKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9yaW9uQ29ubmVjdG9yU2VydmljZS5vbkJ1aWxkRmluaXNoZWQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYnVpbGRGaW5pc2hlZC5uZXh0KCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wYXJ0aWNpcGF0aW9uV2Vic29ja2V0U2VydmljZS51bnN1YnNjcmliZUZvckxhdGVzdFJlc3VsdE9mUGFydGljaXBhdGlvbihwYXJ0aWNpcGF0aW9uSWQsIGV4ZXJjaXNlKTtcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIClcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5idWlsZEZpbmlzaGVkO1xuICAgIH1cblxuICAgIHByaXZhdGUgZm9yd2FyZEJ1aWxkTG9ncyhwYXJ0aWNpcGF0aW9uSWQ6IG51bWJlciwgcHJvZ3JhbW1pbmdMYW5ndWFnZT86IFByb2dyYW1taW5nTGFuZ3VhZ2UsIHByb2plY3RUeXBlPzogUHJvamVjdFR5cGUpIHtcbiAgICAgICAgdGhpcy5idWlsZExvZ1N1YnNjcmlwdGlvbiA9IHRoaXMuYnVpbGRMb2dTZXJ2aWNlXG4gICAgICAgICAgICAuZ2V0QnVpbGRMb2dzKHBhcnRpY2lwYXRpb25JZClcbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIG1hcCgobG9ncykgPT4gbmV3IEJ1aWxkTG9nRW50cnlBcnJheSguLi5sb2dzKSksXG4gICAgICAgICAgICAgICAgdGFwKChsb2dzOiBCdWlsZExvZ0VudHJ5QXJyYXkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbG9nRXJyb3JzID0gbG9ncy5leHRyYWN0RXJyb3JzKHByb2dyYW1taW5nTGFuZ3VhZ2UsIHByb2plY3RUeXBlKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vcmlvbkNvbm5lY3RvclNlcnZpY2Uub25CdWlsZEZhaWxlZChsb2dFcnJvcnMpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmJ1aWxkRmluaXNoZWQubmV4dCgpO1xuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSgpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEFQUF9JTklUSUFMSVpFUiwgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBPcmlvbkJ1dHRvbkNvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvb3Jpb24vb3Jpb24tYnV0dG9uL29yaW9uLWJ1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgT3Jpb25Db25uZWN0b3JTZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9vcmlvbi9vcmlvbi1jb25uZWN0b3Iuc2VydmljZSc7XG5pbXBvcnQgeyBNb2RhbENvbmZpcm1BdXRvZm9jdXNDb21wb25lbnQgfSBmcm9tICcuL21vZGFsLWNvbmZpcm0tYXV0b2ZvY3VzL21vZGFsLWNvbmZpcm0tYXV0b2ZvY3VzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBUcmFuc2xhdGVNb2R1bGUgfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcbmltcG9ydCB7IE9yaW9uRmlsdGVyRGlyZWN0aXZlIH0gZnJvbSAnLi9vcmlvbi1maWx0ZXIuZGlyZWN0aXZlJztcbmltcG9ydCB7IE9yaW9uQnVpbGRBbmRUZXN0U2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvb3Jpb24vb3Jpb24tYnVpbGQtYW5kLXRlc3Quc2VydmljZSc7XG5pbXBvcnQgeyBGZWF0dXJlVG9nZ2xlTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9mZWF0dXJlLXRvZ2dsZS9mZWF0dXJlLXRvZ2dsZS5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBPcmlvbkFzc2Vzc21lbnRTZXJ2aWNlIH0gZnJvbSAnYXBwL29yaW9uL2Fzc2Vzc21lbnQvb3Jpb24tYXNzZXNzbWVudC5zZXJ2aWNlJztcblxuZXhwb3J0IGZ1bmN0aW9uIGluaXRPcmlvbkNvbm5lY3Rvcihjb25uZWN0b3I6IE9yaW9uQ29ubmVjdG9yU2VydmljZSkge1xuICAgIHJldHVybiAoKSA9PiBPcmlvbkNvbm5lY3RvclNlcnZpY2UuaW5pdENvbm5lY3Rvcihjb25uZWN0b3IpO1xufVxuXG5ATmdNb2R1bGUoe1xuICAgIGRlY2xhcmF0aW9uczogW09yaW9uQnV0dG9uQ29tcG9uZW50LCBNb2RhbENvbmZpcm1BdXRvZm9jdXNDb21wb25lbnQsIE9yaW9uRmlsdGVyRGlyZWN0aXZlXSxcbiAgICBpbXBvcnRzOiBbQ29tbW9uTW9kdWxlLCBBcnRlbWlzU2hhcmVkTW9kdWxlLCBUcmFuc2xhdGVNb2R1bGUsIEZlYXR1cmVUb2dnbGVNb2R1bGVdLFxuICAgIGV4cG9ydHM6IFtPcmlvbkJ1dHRvbkNvbXBvbmVudCwgT3Jpb25GaWx0ZXJEaXJlY3RpdmVdLFxuICAgIHByb3ZpZGVyczogW3sgcHJvdmlkZTogQVBQX0lOSVRJQUxJWkVSLCB1c2VGYWN0b3J5OiBpbml0T3Jpb25Db25uZWN0b3IsIGRlcHM6IFtPcmlvbkNvbm5lY3RvclNlcnZpY2VdLCBtdWx0aTogdHJ1ZSB9LCBPcmlvbkJ1aWxkQW5kVGVzdFNlcnZpY2UsIE9yaW9uQXNzZXNzbWVudFNlcnZpY2VdLFxufSlcbmV4cG9ydCBjbGFzcyBPcmlvbk1vZHVsZSB7fVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsU0FBUyxXQUFXLGNBQWMsT0FBTyxjQUFjO0FBQ3ZELFNBQVMscUJBQXFCOzs7OztBQ1V0QixJQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsdUJBQUEsR0FBQSxRQUFBLENBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsUUFBQTs7O0FEWkosSUFTYTtBQVRiOztBQUVBOztBQU9NLElBQU8sdUJBQVAsTUFBTyxzQkFBb0I7TUFDcEI7TUFDQSxnQkFBZ0I7TUFDaEIsV0FBVztNQUNYLGNBQWM7TUFDZCxXQUFXO01BRVgsZ0JBQStCLGNBQWM7TUFFNUMsZUFBZSxJQUFJLGFBQVk7TUFHekMsZ0JBQWdCO01BRWhCLGNBQUE7TUFBZTtNQUVmLElBQVcsYUFBVTtBQUNqQixlQUFPLENBQUMsS0FBSztNQUNqQjtNQUtPLGNBQVc7QUFDZCxZQUFJLENBQUMsS0FBSyxlQUFlO0FBQ3JCLGVBQUssYUFBYSxLQUFJOztNQUU5Qjs7eUJBM0JTLHVCQUFvQjtNQUFBO2dFQUFwQix1QkFBb0IsV0FBQSxDQUFBLENBQUEsZ0JBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxhQUFBLGVBQUEsZUFBQSxpQkFBQSxVQUFBLFlBQUEsYUFBQSxlQUFBLFVBQUEsWUFBQSxlQUFBLGdCQUFBLEdBQUEsU0FBQSxFQUFBLGNBQUEsZUFBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsb0JBQUEscUJBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLFFBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsOEJBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNUakMsVUFBQSw0QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQU9JLFVBQUEsd0JBQUEsU0FBQSxTQUFBLHdEQUFBO0FBQUEsbUJBQVMsSUFBQSxZQUFBO1VBQWEsQ0FBQTtBQUV0QixVQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsdUJBQUEsR0FBQSxXQUFBLENBQUE7QUFDQSxVQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsd0JBQUEsR0FBQSw2Q0FBQSxHQUFBLENBQUE7QUFHQSxVQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLFVBQUEsb0JBQUEsQ0FBQTtBQUFpQixVQUFBLDBCQUFBO0FBQzNCLFVBQUEsb0JBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsR0FBQSxJQUFBOzs7QUFYSSxVQUFBLHlCQUFBLHVCQUFBLElBQUEsUUFBQSxFQUFzQyxlQUFBLElBQUEsVUFBQSxFQUFBLFVBQUEsSUFBQSxXQUFBO0FBRnRDLFVBQUEsd0JBQUEsb0JBQUEsSUFBQSxhQUFBLEVBQWtDLHFCQUFBLElBQUEsYUFBQTtBQU96QixVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLHdCQUFBLFVBQUEsQ0FBQSxJQUFBLGFBQUEsRUFBeUIsUUFBQSxJQUFBLEVBQUEsUUFBQSxJQUFBLGFBQUE7QUFDbEMsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSwyQkFBQSxHQUFBLENBQUEsSUFBQSxnQkFBQSxJQUFBLEVBQUE7QUFHTSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLCtCQUFBLElBQUEsV0FBQTs7Ozs7b0ZESkcsc0JBQW9CLEVBQUEsV0FBQSx1QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVUakMsU0FBUyxhQUFBQSxrQkFBaUI7QUFDMUIsU0FBUyxzQkFBc0I7OztBQUQvQixJQU9hO0FBUGI7OztBQU9NLElBQU8saUNBQVAsTUFBTyxnQ0FBOEI7TUFJcEI7TUFIbkI7TUFDQTtNQUVBLFlBQW1CLE9BQXFCO0FBQXJCLGFBQUEsUUFBQTtNQUF3Qjs7eUJBSmxDLGlDQUE4QixnQ0FBQSxrQkFBQSxDQUFBO01BQUE7aUVBQTlCLGlDQUE4QixXQUFBLENBQUEsQ0FBQSw2QkFBQSxDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLGNBQUEsZ0JBQUEsb0JBQUEsZUFBQSxHQUFBLGFBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsT0FBQSx5QkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxnQkFBQSxJQUFBLEdBQUEsT0FBQSxjQUFBLEdBQUEsT0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHdDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDUDNDLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFBd0IsVUFBQSxxQkFBQSxDQUFBOztBQUE4QixVQUFBLDJCQUFBO0FBQ3RELFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUFpRyxVQUFBLHlCQUFBLFNBQUEsU0FBQSxrRUFBQTtBQUFBLG1CQUFTLElBQUEsTUFBQSxRQUFjLGFBQWE7VUFBQyxDQUFBO0FBQUUsVUFBQSwyQkFBQTtBQUM1SSxVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxHQUFBO0FBQUcsVUFBQSxxQkFBQSxFQUFBOztBQUE2QixVQUFBLDJCQUFBO0FBQ3BDLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUF3RCxVQUFBLHlCQUFBLFNBQUEsU0FBQSxtRUFBQTtBQUFBLG1CQUFTLElBQUEsTUFBQSxRQUFjLGNBQWM7VUFBQyxDQUFBO0FBQUUsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBTSxVQUFBLDJCQUFBO0FBQ3RHLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUEwRCxVQUFBLHlCQUFBLFNBQUEsU0FBQSxtRUFBQTtBQUFBLG1CQUFTLElBQUEsTUFBQSxNQUFZLFVBQVU7VUFBQyxDQUFBO0FBQUUsVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBRSxVQUFBLDJCQUFBO0FBQ2xHLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUFWNEIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsSUFBQSxLQUFBLENBQUE7QUFJckIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSwwQkFBQSxJQUFBLEdBQUEsSUFBQSxJQUFBLENBQUE7Ozs7O3FGREVNLGdDQUE4QixFQUFBLFdBQUEsaUNBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFUDNDLFNBQVMsa0JBQWtCO0FBRzNCLFNBQVMsUUFBUSxLQUFLLFdBQVc7QUFDakMsU0FBcUIsZUFBNkI7O0FBSmxELElBcUJhO0FBckJiOztBQUNBO0FBQ0E7QUFHQTtBQUVBO0FBR0E7QUFDQTs7Ozs7QUFVTSxJQUFPLDJCQUFQLE1BQU8sMEJBQXdCO01BT3JCO01BQ0E7TUFDQTtNQUNBO01BVEosZ0JBQWdCLElBQUksUUFBTztNQUMzQjtNQUNBO01BQ0E7TUFFUixZQUNZLG1CQUNBLCtCQUNBLHVCQUNBLGlCQUFnQztBQUhoQyxhQUFBLG9CQUFBO0FBQ0EsYUFBQSxnQ0FBQTtBQUNBLGFBQUEsd0JBQUE7QUFDQSxhQUFBLGtCQUFBO01BQ1Q7TUFPSCxxQkFBcUIsVUFBNkI7QUFDOUMsY0FBTSxrQkFBa0IsU0FBUyxzQkFBdUIsQ0FBQyxFQUFFO0FBRTNELGFBQUssa0JBQWtCLGFBQWEsZUFBZSxFQUFFLFVBQVM7QUFFOUQsYUFBSyxxQ0FBcUMsUUFBUTtNQUN0RDtNQVFBLHFDQUFxQyxVQUErQixlQUE2QjtBQUM3RixjQUFNLGtCQUFrQixnQkFBZ0IsY0FBYyxLQUFNLFNBQVMsc0JBQXVCLENBQUMsRUFBRTtBQUMvRixhQUFLLHNCQUFzQixlQUFlLFNBQVMsZ0JBQWlCO0FBR3BFLFlBQUksS0FBSyxvQkFBb0I7QUFDekIsZUFBSyxtQkFBbUIsWUFBVzs7QUFFdkMsWUFBSSxLQUFLLHNCQUFzQjtBQUMzQixlQUFLLHFCQUFxQixZQUFXOztBQUV6QyxhQUFLLHFCQUFxQixLQUFLLDhCQUMxQix3Q0FBd0MsaUJBQWlCLElBQUksRUFDN0QsS0FDRyxPQUFPLE9BQU8sR0FDZCxJQUFJLENBQUMsV0FBVyxNQUFnQixHQUNoQyxPQUFPLENBQUMsV0FBVyxDQUFDLEtBQUssZ0JBQWdCLEtBQUssYUFBYSxLQUFNLE9BQU8sRUFBRyxHQUMzRSxJQUFJLENBQUMsV0FBVTtBQUNYLGVBQUssZUFBZTtBQUVwQixjQUFJLENBQUMsT0FBTyxjQUFlLE9BQU8sV0FBcUMsYUFBYTtBQUNoRixpQkFBSyxpQkFBaUIsaUJBQWlCLFNBQVMscUJBQXFCLFNBQVMsV0FBVztpQkFDdEY7QUFFSCxrQkFBTSxtQkFBbUIsT0FBTyxVQUFXLE9BQU8sQ0FBQyxhQUFhLFNBQVMsbUJBQW1CLFFBQVEsQ0FBQztBQUNyRyw2QkFBaUIsUUFBUSxDQUFDLGFBQWEsS0FBSyxzQkFBc0IsYUFBYSxDQUFDLENBQUMsU0FBUyxVQUFVLFNBQVMsU0FBVSxVQUFXLFNBQVMsVUFBVyxDQUFDO0FBQ3ZKLGlCQUFLLHNCQUFzQixnQkFBZTtBQUMxQyxpQkFBSyxjQUFjLEtBQUk7O0FBRTNCLGVBQUssOEJBQThCLDBDQUEwQyxpQkFBaUIsUUFBUTtRQUMxRyxDQUFDLENBQUMsRUFFTCxVQUFTO0FBRWQsZUFBTyxLQUFLO01BQ2hCO01BRVEsaUJBQWlCLGlCQUF5QixxQkFBMkMsYUFBeUI7QUFDbEgsYUFBSyx1QkFBdUIsS0FBSyxnQkFDNUIsYUFBYSxlQUFlLEVBQzVCLEtBQ0csSUFBSSxDQUFDLFNBQVMsSUFBSSxtQkFBbUIsR0FBRyxJQUFJLENBQUMsR0FDN0MsSUFBSSxDQUFDLFNBQTRCO0FBQzdCLGdCQUFNLFlBQVksS0FBSyxjQUFjLHFCQUFxQixXQUFXO0FBQ3JFLGVBQUssc0JBQXNCLGNBQWMsU0FBUztBQUNsRCxlQUFLLGNBQWMsS0FBSTtRQUMzQixDQUFDLENBQUMsRUFFTCxVQUFTO01BQ2xCOzt5QkFqRlMsMkJBQXdCLHVCQUFBLDRCQUFBLEdBQUEsdUJBQUEsNkJBQUEsR0FBQSx1QkFBQSxxQkFBQSxHQUFBLHVCQUFBLGVBQUEsQ0FBQTtNQUFBO29FQUF4QiwyQkFBd0IsU0FBeEIsMEJBQXdCLFdBQUEsWUFGckIsT0FBTSxDQUFBOzs7Ozs7QUNuQnRCLFNBQVMsaUJBQWlCLGdCQUFnQjtBQUMxQyxTQUFTLG9CQUFvQjtBQUk3QixTQUFTLHVCQUF1Qjs7QUFPMUIsU0FBVSxtQkFBbUIsV0FBZ0M7QUFDL0QsU0FBTyxNQUFNLHNCQUFzQixjQUFjLFNBQVM7QUFDOUQ7QUFkQSxJQXNCYTtBQXRCYjs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWU0sSUFBTyxjQUFQLE1BQU8sYUFBVzs7eUJBQVgsY0FBVztNQUFBO2dFQUFYLGFBQVcsQ0FBQTtxRUFGVCxDQUFDLEVBQUUsU0FBUyxpQkFBaUIsWUFBWSxvQkFBb0IsTUFBTSxDQUFDLHFCQUFxQixHQUFHLE9BQU8sS0FBSSxHQUFJLDBCQUEwQixzQkFBc0IsR0FBQyxTQUFBLENBRjdKLGNBQWMscUJBQXFCLGlCQUFpQixtQkFBbUIsRUFBQSxDQUFBOzs7OyIsIm5hbWVzIjpbIkNvbXBvbmVudCJdfQ==