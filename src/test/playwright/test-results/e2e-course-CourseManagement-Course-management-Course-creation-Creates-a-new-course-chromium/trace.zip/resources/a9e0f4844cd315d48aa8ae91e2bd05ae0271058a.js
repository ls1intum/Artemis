import {
  __commonJS
} from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NI5XS6XH.js?v=b97f8625";

// node_modules/mobile-drag-drop/index.min.js
var require_index_min = __commonJS({
  "node_modules/mobile-drag-drop/index.min.js"(exports, module) {
    !function(t, i) {
      "object" == typeof exports && "undefined" != typeof module ? i(exports) : "function" == typeof define && define.amd ? define(["exports"], i) : i(t.MobileDragDrop = t.MobileDragDrop || {});
    }(exports, function(t) {
      "use strict";
      var c = "dnd-poly-", s = ["none", "copy", "copyLink", "copyMove", "link", "linkMove", "move", "all"], f = ["none", "copy", "move", "link"];
      function i() {
        var t2 = false;
        try {
          var i2 = Object.defineProperty({}, "passive", { get: function() {
            t2 = true;
          } });
          window.addEventListener("test", null, i2);
        } catch (t3) {
        }
        return t2;
      }
      var e = i();
      function l(t2) {
        return t2 && t2.tagName;
      }
      function h(t2, i2, s2) {
        void 0 === s2 && (s2 = true), document.addEventListener(t2, i2, !!e && { passive: s2 });
      }
      function n(t2, i2) {
        document.removeEventListener(t2, i2);
      }
      function u(t2, i2, s2, n2) {
        void 0 === n2 && (n2 = false);
        var h2 = e ? { passive: true, capture: n2 } : n2;
        return t2.addEventListener(i2, s2, h2), { off: function() {
          t2.removeEventListener(i2, s2, h2);
        } };
      }
      function o(t2) {
        return 0 === t2.length ? 0 : t2.reduce(function(t3, i2) {
          return i2 + t3;
        }, 0) / t2.length;
      }
      function r(t2, i2) {
        for (var s2 = 0; s2 < t2.changedTouches.length; s2++)
          if (t2.changedTouches[s2].identifier === i2)
            return true;
        return false;
      }
      function a(t2, i2, s2) {
        for (var n2 = [], h2 = [], e2 = 0; e2 < i2.touches.length; e2++) {
          var r2 = i2.touches[e2];
          n2.push(r2[t2 + "X"]), h2.push(r2[t2 + "Y"]);
        }
        s2.x = o(n2), s2.y = o(h2);
      }
      var d = ["", "-webkit-"];
      function v(t2, i2, s2, n2, h2) {
        var e2 = i2.x, i2 = i2.y;
        n2 && (e2 += n2.x, i2 += n2.y), (h2 = void 0 === h2 || h2) && (e2 -= parseInt(t2.offsetWidth, 10) / 2, i2 -= parseInt(t2.offsetHeight, 10) / 2);
        for (var r2 = "translate3d(" + e2 + "px," + i2 + "px, 0)", o2 = 0; o2 < d.length; o2++) {
          var u2 = d[o2] + "transform";
          t2.style[u2] = r2 + " " + s2[o2];
        }
      }
      var p = (Object.defineProperty(g.prototype, "dropEffect", { get: function() {
        return this.t;
      }, set: function(t2) {
        0 !== this.i.mode && -1 < s.indexOf(t2) && (this.t = t2);
      }, enumerable: false, configurable: true }), Object.defineProperty(g.prototype, "types", { get: function() {
        if (0 !== this.i.mode)
          return Object.freeze(this.i.types);
      }, enumerable: false, configurable: true }), Object.defineProperty(g.prototype, "effectAllowed", { get: function() {
        return this.i.effectAllowed;
      }, set: function(t2) {
        2 === this.i.mode && -1 < s.indexOf(t2) && (this.i.effectAllowed = t2);
      }, enumerable: false, configurable: true }), g.prototype.setData = function(t2, i2) {
        if (2 === this.i.mode) {
          if (-1 < t2.indexOf(" "))
            throw new Error("illegal arg: type contains space");
          this.i.data[t2] = i2, -1 === this.i.types.indexOf(t2) && this.i.types.push(t2);
        }
      }, g.prototype.getData = function(t2) {
        if (1 === this.i.mode || 2 === this.i.mode)
          return this.i.data[t2] || "";
      }, g.prototype.clearData = function(t2) {
        2 === this.i.mode && (t2 && this.i.data[t2] ? (delete this.i.data[t2], -1 < (t2 = this.i.types.indexOf(t2)) && this.i.types.splice(t2, 1)) : (this.i.data = {}, this.i.types = []));
      }, g.prototype.setDragImage = function(t2, i2, s2) {
        2 === this.i.mode && this.h(t2, i2, s2);
      }, g);
      function g(t2, i2) {
        this.i = t2, this.h = i2, this.t = f[0];
      }
      function m(t2, i2) {
        return t2 ? t2 === s[0] ? f[0] : 0 === t2.indexOf(s[1]) || t2 === s[7] ? f[1] : 0 === t2.indexOf(s[4]) ? f[3] : t2 === s[6] ? f[2] : f[1] : 3 === i2.nodeType && "A" === i2.tagName ? f[3] : f[1];
      }
      function y(u2, t2, a2, i2, s2, n2, c2) {
        void 0 === c2 && (c2 = null);
        s2 = function(t3, i3, s3, n3, h2, e2, r2) {
          void 0 === c2 && (r2 = null);
          var o2 = a2.changedTouches[0], n3 = new Event(u2, { bubbles: true, cancelable: n3 });
          n3.dataTransfer = e2, n3.relatedTarget = r2, n3.screenX = o2.screenX, n3.screenY = o2.screenY, n3.clientX = o2.clientX, n3.clientY = o2.clientY, n3.pageX = o2.pageX, n3.pageY = o2.pageY;
          t3 = t3.getBoundingClientRect();
          return n3.offsetX = n3.clientX - t3.left, n3.offsetY = n3.clientY - t3.top, n3;
        }(t2, 0, 0, n2 = void 0 === n2 || n2, document.defaultView, s2, c2), s2 = !t2.dispatchEvent(s2);
        return i2.mode = 0, s2;
      }
      function b(t2, i2) {
        if (!t2 || t2 === s[7])
          return i2;
        if (i2 === f[1]) {
          if (0 === t2.indexOf(f[1]))
            return f[1];
        } else if (i2 === f[3]) {
          if (0 === t2.indexOf(f[3]) || -1 < t2.indexOf("Link"))
            return f[3];
        } else if (i2 === f[2] && (0 === t2.indexOf(f[2]) || -1 < t2.indexOf("Move")))
          return f[2];
        return f[0];
      }
      var w = (x.prototype.o = function() {
        var n2 = this;
        this.u = 1, this.l = f[0], this.v = { data: {}, effectAllowed: void 0, mode: 3, types: [] }, this.p = { x: null, y: null }, this.g = { x: null, y: null };
        var h2 = this.m;
        if (this.I = new p(this.v, function(t3, i3, s3) {
          h2 = t3, "number" != typeof i3 && "number" != typeof s3 || (n2.j = { x: i3 || 0, y: s3 || 0 });
        }), this.v.mode = 2, this.I.dropEffect = f[0], y("dragstart", this.m, this.k, this.v, this.I))
          return this.u = 3, this.C(), false;
        a("page", this.k, this.g);
        var i2, t2, s2 = this.S.dragImageSetup(h2);
        return this.A = (i2 = s2, d.map(function(t3) {
          t3 = i2.style[t3 + "transform"];
          return t3 && "none" !== t3 ? t3.replace(/translate\(\D*\d+[^,]*,\D*\d+[^,]*\)\s*/g, "") : "";
        })), s2.style.position = "absolute", s2.style.left = "0px", s2.style.top = "0px", s2.style.zIndex = "999999", s2.classList.add("dnd-poly-drag-image"), s2.classList.add("dnd-poly-icon"), this.O = s2, this.j || (this.S.dragImageOffset ? this.j = { x: this.S.dragImageOffset.x, y: this.S.dragImageOffset.y } : this.S.dragImageCenterOnTouch ? (t2 = getComputedStyle(h2), this.j = { x: 0 - parseInt(t2.marginLeft, 10), y: 0 - parseInt(t2.marginTop, 10) }) : (s2 = h2.getBoundingClientRect(), t2 = getComputedStyle(h2), this.j = { x: s2.left - this.M.clientX - parseInt(t2.marginLeft, 10) + s2.width / 2, y: s2.top - this.M.clientY - parseInt(t2.marginTop, 10) + s2.height / 2 })), v(this.O, this.g, this.A, this.j, this.S.dragImageCenterOnTouch), document.body.appendChild(this.O), this.D = window.setInterval(function() {
          n2.F || (n2.F = true, n2.N(), n2.F = false);
        }, this.S.iterationInterval), true;
      }, x.prototype.C = function() {
        this.D && (clearInterval(this.D), this.D = null), n("touchmove", this.P), n("touchend", this.T), n("touchcancel", this.T), this.O && (this.O.parentNode.removeChild(this.O), this.O = null), this.L(this.S, this.k, this.u);
      }, x.prototype._ = function(t2) {
        var s2 = this;
        if (false !== r(t2, this.M.identifier)) {
          if (this.k = t2, 0 === this.u) {
            var i2 = void 0;
            if (this.S.dragStartConditionOverride)
              try {
                i2 = this.S.dragStartConditionOverride(t2);
              } catch (t3) {
                i2 = false;
              }
            else
              i2 = 1 === t2.touches.length;
            return i2 ? void (true === this.o() && (this.H.preventDefault(), t2.preventDefault())) : void this.C();
          }
          if (t2.preventDefault(), a("client", t2, this.p), a("page", t2, this.g), this.S.dragImageTranslateOverride)
            try {
              var n2 = false;
              if (this.S.dragImageTranslateOverride(t2, { x: this.p.x, y: this.p.y }, this.V, function(t3, i3) {
                s2.O && (n2 = true, s2.p.x += t3, s2.p.y += i3, s2.g.x += t3, s2.g.y += i3, v(s2.O, s2.g, s2.A, s2.j, s2.S.dragImageCenterOnTouch));
              }), n2)
                return;
            } catch (t3) {
            }
          v(this.O, this.g, this.A, this.j, this.S.dragImageCenterOnTouch);
        }
      }, x.prototype.X = function(t2) {
        if (false !== r(t2, this.M.identifier)) {
          if (this.S.dragImageTranslateOverride)
            try {
              this.S.dragImageTranslateOverride(void 0, void 0, void 0, function() {
              });
            } catch (t3) {
            }
          0 !== this.u ? (t2.preventDefault(), this.u = "touchcancel" === t2.type ? 3 : 2) : this.C();
        }
      }, x.prototype.N = function() {
        var t2 = this, i2 = this.l;
        this.v.mode = 3, this.I.dropEffect = f[0];
        var s2, n2, h2, e2, r2, o2 = y("drag", this.m, this.k, this.v, this.I);
        if (o2 && (this.l = f[0]), o2 || 2 === this.u || 3 === this.u)
          return this.Y(this.u) ? (e2 = this.m, s2 = this.O, n2 = this.A, a2 = function() {
            t2.q();
          }, void ("hidden" !== (r2 = getComputedStyle(e2)).visibility && "none" !== r2.display ? (s2.classList.add("dnd-poly-snapback"), h2 = getComputedStyle(s2), o2 = parseFloat(h2.transitionDuration), isNaN(o2) || 0 === o2 ? a2() : ((e2 = { x: (u2 = e2.getBoundingClientRect()).left, y: u2.top }).x += document.body.scrollLeft || document.documentElement.scrollLeft, e2.y += document.body.scrollTop || document.documentElement.scrollTop, e2.x -= parseInt(r2.marginLeft, 10), e2.y -= parseInt(r2.marginTop, 10), u2 = parseFloat(h2.transitionDelay), u2 = Math.round(1e3 * (o2 + u2)), v(s2, e2, n2, void 0, false), setTimeout(a2, u2))) : a2())) : void this.q();
        var u2 = this.S.elementFromPoint(this.p.x, this.p.y), a2 = this.B;
        u2 !== this.V && u2 !== this.B && (this.V = u2, null !== this.B && (this.v.mode = 3, this.I.dropEffect = f[0], y("dragexit", this.B, this.k, this.v, this.I, false)), null === this.V ? this.B = this.V : (this.v.mode = 3, this.I.dropEffect = m(this.v.effectAllowed, this.m), y("dragenter", this.V, this.k, this.v, this.I) ? (this.B = this.V, this.l = b(this.I.effectAllowed, this.I.dropEffect)) : this.V !== document.body && (this.B = document.body))), a2 !== this.B && l(a2) && (this.v.mode = 3, this.I.dropEffect = f[0], y("dragleave", a2, this.k, this.v, this.I, false, this.B)), l(this.B) && (this.v.mode = 3, this.I.dropEffect = m(this.v.effectAllowed, this.m), false === y("dragover", this.B, this.k, this.v, this.I) ? this.l = f[0] : this.l = b(this.I.effectAllowed, this.I.dropEffect)), i2 !== this.l && this.O.classList.remove(c + i2);
        i2 = c + this.l;
        this.O.classList.add(i2);
      }, x.prototype.Y = function(t2) {
        t2 = this.l === f[0] || null === this.B || 3 === t2;
        return t2 ? l(this.B) && (this.v.mode = 3, this.I.dropEffect = f[0], y("dragleave", this.B, this.k, this.v, this.I, false)) : l(this.B) && (this.v.mode = 1, this.I.dropEffect = this.l, true === y("drop", this.B, this.k, this.v, this.I) ? this.l = this.I.dropEffect : this.l = f[0]), t2;
      }, x.prototype.q = function() {
        this.v.mode = 3, this.I.dropEffect = this.l, y("dragend", this.m, this.k, this.v, this.I, false), this.u = 2, this.C();
      }, x);
      function x(t2, i2, s2, n2) {
        this.H = t2, this.S = i2, this.m = s2, this.L = n2, this.u = 0, this.V = null, this.B = null, this.k = t2, this.M = t2.changedTouches[0], this.P = this._.bind(this), this.T = this.X.bind(this), h("touchmove", this.P, false), h("touchend", this.T, false), h("touchcancel", this.T, false);
      }
      var I, j = { iterationInterval: 150, tryFindDraggableTarget: function(t2) {
        for (var i2 = 0, s2 = t2.composedPath(); i2 < s2.length; i2++) {
          var n2 = s2[i2];
          do {
            if (false !== n2.draggable) {
              if (true === n2.draggable)
                return n2;
              if (n2.getAttribute && "true" === n2.getAttribute("draggable"))
                return n2;
            }
          } while ((n2 = n2.parentNode) && n2 !== document.body);
        }
      }, dragImageSetup: function(t2) {
        var i2 = t2.cloneNode(true);
        return function t3(i3, s2) {
          if (1 === i3.nodeType) {
            for (var n2, h2, e2 = getComputedStyle(i3), r2 = 0; r2 < e2.length; r2++) {
              var o2 = e2[r2];
              s2.style.setProperty(o2, e2.getPropertyValue(o2), e2.getPropertyPriority(o2));
            }
            s2.style.pointerEvents = "none", s2.removeAttribute("id"), s2.removeAttribute("class"), s2.removeAttribute("draggable"), "CANVAS" === s2.nodeName && (n2 = s2, h2 = (h2 = i3).getContext("2d").getImageData(0, 0, h2.width, h2.height), n2.getContext("2d").putImageData(h2, 0, 0));
          }
          if (i3.hasChildNodes())
            for (r2 = 0; r2 < i3.childNodes.length; r2++)
              t3(i3.childNodes[r2], s2.childNodes[r2]);
          !function t4(i4) {
            if (i4 instanceof HTMLElement && (i4.style.pointerEvents = "none"), i4.children && i4.children.length)
              for (var s3 = 0; s3 < i4.children.length; s3++)
                t4(i4.children[s3]);
            if (i4.shadowRoot && i4.shadowRoot.children.length)
              for (s3 = 0; s3 < i4.shadowRoot.children.length; s3++)
                t4(i4.shadowRoot.children[s3]);
          }(s2);
        }(t2, i2), i2;
      }, elementFromPoint: function(t2, i2) {
        var s2 = document.elementFromPoint(t2, i2);
        if (s2) {
          for (; s2.shadowRoot; ) {
            var n2 = s2.shadowRoot.elementFromPoint(t2, i2);
            if (null === n2 || n2 === s2)
              break;
            s2 = n2;
          }
          return s2;
        }
      } };
      function k(i2) {
        if (!I) {
          var t2 = j.tryFindDraggableTarget(i2);
          if (t2)
            try {
              I = new w(i2, j, t2, S);
            } catch (t3) {
              throw S(j, i2, 3), t3;
            }
        }
      }
      function C(t2) {
        function i2(t3) {
          h2.off(), e2.off(), r2.off(), o2.off(), s2 && s2.dispatchEvent(new CustomEvent("dnd-poly-dragstart-cancel", { bubbles: true, cancelable: true })), clearTimeout(n2);
        }
        var s2 = t2.target;
        s2 && s2.dispatchEvent(new CustomEvent("dnd-poly-dragstart-pending", { bubbles: true, cancelable: true }));
        var n2 = window.setTimeout(function() {
          h2.off(), e2.off(), r2.off(), o2.off(), k(t2);
        }, j.holdToDrag), h2 = u(s2, "touchend", i2), e2 = u(s2, "touchcancel", i2), r2 = u(s2, "touchmove", i2), o2 = u(window, "scroll", i2, true);
      }
      function S(t2, i2, s2) {
        if (0 === s2 && t2.defaultActionOverride)
          try {
            t2.defaultActionOverride(i2), i2.defaultPrevented;
          } catch (t3) {
          }
        I = null;
      }
      t.polyfill = function(i2) {
        if (i2 && Object.keys(i2).forEach(function(t3) {
          j[t3] = i2[t3];
        }), !j.forceApply) {
          t2 = (t2 = !!window.chrome || /chrome/i.test(navigator.userAgent), { dragEvents: "ondragstart" in document.documentElement, draggable: "draggable" in document.documentElement, userAgentSupportingNativeDnD: !(/iPad|iPhone|iPod|Android/.test(navigator.userAgent) || t2 && "ontouchstart" in document.documentElement) });
          if (t2.userAgentSupportingNativeDnD && t2.draggable && t2.dragEvents)
            return false;
        }
        var t2;
        return j.holdToDrag ? h("touchstart", C, false) : h("touchstart", k, false), true;
      }, t.supportsPassiveEventListener = i, Object.defineProperty(t, "G", { value: true });
    });
  }
});
export default require_index_min();
/*! Bundled license information:

mobile-drag-drop/index.min.js:
  (*! mobile-drag-drop 3.0.0-rc.0 | Copyright (c) 2022 Tim Ruffles | MIT License *)
*/
//# sourceMappingURL=mobile-drag-drop.js.map
