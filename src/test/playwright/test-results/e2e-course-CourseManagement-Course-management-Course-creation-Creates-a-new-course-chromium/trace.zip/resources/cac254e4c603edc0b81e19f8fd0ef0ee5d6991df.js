import {
  ArtemisExerciseHintSharedModule,
  CastToCodeHintPipe,
  CodeHintContainerComponent,
  CodeHintService,
  ManualSolutionEntryCreationModalComponent,
  ProgrammingExerciseResolve,
  init_code_hint_cast_pipe,
  init_code_hint_container_component,
  init_code_hint_service,
  init_exercise_hint_shared_module,
  init_manual_solution_entry_creation_modal_component,
  init_programming_exercise_management_routing_module
} from "/chunk-BIBQZKKQ.js";
import {
  KatexCommand,
  init_katex_command
} from "/chunk-YWMTYHY2.js";
import {
  ProgrammingExerciseService,
  init_programming_exercise_service
} from "/chunk-J24E6AYR.js";
import {
  ExerciseHintService,
  init_exercise_hint_service
} from "/chunk-FM7Y5DDY.js";
import {
  ExerciseHint,
  HintType,
  init_exercise_hint_model
} from "/chunk-TQC3QNXR.js";
import {
  ArtemisNavigationUtilService,
  init_navigation_utils
} from "/chunk-QOKTVWNZ.js";
import {
  IrisSettingsService,
  init_iris_settings_service
} from "/chunk-VUYHOQDW.js";
import {
  ArtemisMarkdownModule,
  HtmlForMarkdownPipe,
  init_html_for_markdown_pipe,
  init_markdown_module
} from "/chunk-UF4UUZTK.js";
import {
  ArtemisMarkdownEditorModule,
  EditorMode,
  MarkdownEditorComponent,
  MarkdownEditorHeight,
  init_markdown_editor_component,
  init_markdown_editor_module
} from "/chunk-KPWFZEYZ.js";
import {
  ArtemisSharedComponentModule,
  ProgrammingLanguage,
  init_programming_exercise_model,
  init_shared_component_module
} from "/chunk-ORYTP7RT.js";
import {
  UserRouteAccessService,
  init_user_route_access_service
} from "/chunk-KQ77WIWP.js";
import {
  init_global_utils,
  onError
} from "/chunk-LW4WH7EZ.js";
import {
  AlertService,
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  Authority,
  ButtonComponent,
  DeleteButtonDirective,
  EventManager,
  ExerciseType,
  HelpIconComponent,
  ProfileService,
  TranslateDirective,
  __esm,
  exerciseTypes,
  init_alert_service,
  init_artemis_translate_pipe,
  init_authority_constants,
  init_button_component,
  init_delete_button_directive,
  init_event_manager_service,
  init_exercise_model,
  init_help_icon_component,
  init_profile_service,
  init_shared_module,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/shared/exercise-hint/manage/exercise-hint.component.ts
import { Component } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { Subject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { filter, map } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { faArrowsRotate, faCode, faEye, faFont, faPlus, faTimes, faWrench } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ExerciseHintComponent_Conditional_7_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275element(3, "fa-icon", 3);
    i0.\u0275\u0275text(4, "\n                        ");
    i0.\u0275\u0275elementStart(5, "span");
    i0.\u0275\u0275text(6, "Manage Code Hints");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                ");
  }
  if (rf & 2) {
    const ctx_r3 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("icon", ctx_r3.faWrench);
  }
}
function ExerciseHintComponent_Conditional_7_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275element(3, "fa-icon", 3);
    i0.\u0275\u0275text(4, "\n                        ");
    i0.\u0275\u0275elementStart(5, "span", 6);
    i0.\u0275\u0275text(6, "Generate Code Hints");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                ");
  }
  if (rf & 2) {
    const ctx_r4 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("icon", ctx_r4.faArrowsRotate);
  }
}
function ExerciseHintComponent_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275elementStart(1, "a", 5);
    i0.\u0275\u0275text(2, "\n                ");
    i0.\u0275\u0275template(3, ExerciseHintComponent_Conditional_7_Conditional_3_Template, 9, 1)(4, ExerciseHintComponent_Conditional_7_Conditional_4_Template, 9, 1);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275classMap(ctx_r0.containsCodeHints ? "btn-secondary" : "btn-primary");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(3, ctx_r0.containsCodeHints ? 3 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(4, !ctx_r0.containsCodeHints ? 4 : -1);
  }
}
function ExerciseHintComponent_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "div", 7);
    i0.\u0275\u0275text(2, "\n            ");
    i0.\u0275\u0275elementStart(3, "span", 8);
    i0.\u0275\u0275text(4, "No exerciseHints found");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n    ");
  }
}
function ExerciseHintComponent_Conditional_20_For_32_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                                    ");
    i0.\u0275\u0275elementStart(1, "span", 24);
    i0.\u0275\u0275element(2, "fa-icon", 3);
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275pipe(4, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r11 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r11.faCode);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate1(" ", i0.\u0275\u0275pipeBind1(4, 2, "artemisApp.codeHint.type"), "");
  }
}
function ExerciseHintComponent_Conditional_20_For_32_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                                    ");
    i0.\u0275\u0275elementStart(1, "span", 24);
    i0.\u0275\u0275element(2, "fa-icon", 3);
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275pipe(4, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r12 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r12.faText);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate1(" ", i0.\u0275\u0275pipeBind1(4, 2, "artemisApp.exerciseHint.textHint"), "");
  }
}
function ExerciseHintComponent_Conditional_20_For_32_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                                    ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n                                        ");
    i0.\u0275\u0275elementStart(3, "span");
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275pipe(5, "castToCodeHint");
    i0.\u0275\u0275pipe(6, "artemisTranslate");
    i0.\u0275\u0275pipe(7, "castToCodeHint");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                                ");
  }
  if (rf & 2) {
    const exerciseHint_r6 = i0.\u0275\u0275nextContext().$implicit;
    let tmp_0_0;
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate2("\n                                            ", (tmp_0_0 = i0.\u0275\u0275pipeBind1(5, 2, exerciseHint_r6).solutionEntries == null ? null : i0.\u0275\u0275pipeBind1(5, 2, exerciseHint_r6).solutionEntries.length) !== null && tmp_0_0 !== void 0 ? tmp_0_0 : 0, "\n                                            ", i0.\u0275\u0275pipeBind1(6, 4, (i0.\u0275\u0275pipeBind1(7, 6, exerciseHint_r6).solutionEntries == null ? null : i0.\u0275\u0275pipeBind1(7, 6, exerciseHint_r6).solutionEntries.length) === 1 ? "artemisApp.codeHint.entry" : "artemisApp.codeHint.entries"), "\n                                        ");
  }
}
function ExerciseHintComponent_Conditional_20_For_32_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "tr");
    i0.\u0275\u0275text(2, "\n                            ");
    i0.\u0275\u0275elementStart(3, "td");
    i0.\u0275\u0275text(4, "\n                                ");
    i0.\u0275\u0275elementStart(5, "a", 15);
    i0.\u0275\u0275text(6);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, "\n                            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                            ");
    i0.\u0275\u0275elementStart(9, "td");
    i0.\u0275\u0275text(10);
    i0.\u0275\u0275element(11, "br");
    i0.\u0275\u0275text(12, "\n                                ");
    i0.\u0275\u0275template(13, ExerciseHintComponent_Conditional_20_For_32_Conditional_13_Template, 6, 4)(14, ExerciseHintComponent_Conditional_20_For_32_Conditional_14_Template, 6, 4);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(15, "\n                            ");
    i0.\u0275\u0275elementStart(16, "td");
    i0.\u0275\u0275text(17, "\n                                ");
    i0.\u0275\u0275elementStart(18, "div");
    i0.\u0275\u0275text(19, "\n                                    ");
    i0.\u0275\u0275element(20, "span", 16);
    i0.\u0275\u0275pipe(21, "htmlForMarkdown");
    i0.\u0275\u0275text(22, "\n                                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(23, "\n                                ");
    i0.\u0275\u0275template(24, ExerciseHintComponent_Conditional_20_For_32_Conditional_24_Template, 10, 8);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(25, "\n                            ");
    i0.\u0275\u0275elementStart(26, "td");
    i0.\u0275\u0275text(27, "\n                                ");
    i0.\u0275\u0275elementStart(28, "span");
    i0.\u0275\u0275text(29);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(30, "\n                            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(31, "\n                            ");
    i0.\u0275\u0275elementStart(32, "td", 17);
    i0.\u0275\u0275text(33, "\n                                ");
    i0.\u0275\u0275elementStart(34, "div", 18);
    i0.\u0275\u0275text(35, "\n                                    ");
    i0.\u0275\u0275elementStart(36, "a", 19);
    i0.\u0275\u0275text(37, "\n                                        ");
    i0.\u0275\u0275element(38, "fa-icon", 3);
    i0.\u0275\u0275text(39, "\n                                        ");
    i0.\u0275\u0275elementStart(40, "span", 20);
    i0.\u0275\u0275text(41, "View");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(42, "\n                                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(43, "\n                                    ");
    i0.\u0275\u0275elementStart(44, "a", 21);
    i0.\u0275\u0275text(45, "\n                                        ");
    i0.\u0275\u0275element(46, "fa-icon", 3);
    i0.\u0275\u0275text(47, "\n                                        ");
    i0.\u0275\u0275elementStart(48, "span", 22);
    i0.\u0275\u0275text(49, "Edit");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(50, "\n                                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(51, "\n                                    ");
    i0.\u0275\u0275elementStart(52, "button", 23);
    i0.\u0275\u0275listener("delete", function ExerciseHintComponent_Conditional_20_For_32_Template_button_delete_52_listener() {
      const restoredCtx = i0.\u0275\u0275restoreView(_r16);
      const exerciseHint_r6 = restoredCtx.$implicit;
      const ctx_r15 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r15.deleteExerciseHint(exerciseHint_r6.id));
    });
    i0.\u0275\u0275text(53, "\n                                        ");
    i0.\u0275\u0275element(54, "fa-icon", 3);
    i0.\u0275\u0275text(55, "\n                                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(56, "\n                                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(57, "\n                            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(58, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(59, "\n                    ");
  }
  if (rf & 2) {
    const exerciseHint_r6 = ctx.$implicit;
    const ctx_r5 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction1(17, _c0, exerciseHint_r6.id));
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate(exerciseHint_r6.id);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate1("\n                                ", exerciseHint_r6.title, "\n                                ");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(13, exerciseHint_r6.type === ctx_r5.HintType.CODE && (exerciseHint_r6.exercise == null ? null : exerciseHint_r6.exercise.type) === ctx_r5.ExerciseType.PROGRAMMING ? 13 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(14, exerciseHint_r6.type === ctx_r5.HintType.TEXT && (exerciseHint_r6.exercise == null ? null : exerciseHint_r6.exercise.type) === ctx_r5.ExerciseType.PROGRAMMING ? 14 : -1);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275property("innerHTML", i0.\u0275\u0275pipeBind1(21, 15, exerciseHint_r6.content), i0.\u0275\u0275sanitizeHtml);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275conditional(24, exerciseHint_r6.type === ctx_r5.HintType.CODE ? 24 : -1);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate(exerciseHint_r6.exercise == null ? null : exerciseHint_r6.exercise.id);
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction1(19, _c0, exerciseHint_r6.id));
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r5.faEye);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction1(21, _c1, exerciseHint_r6.id));
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r5.faWrench);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275property("entityTitle", exerciseHint_r6.title)("dialogError", ctx_r5.dialogError$);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r5.faTimes);
  }
}
function ExerciseHintComponent_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "div", 9);
    i0.\u0275\u0275text(2, "\n            ");
    i0.\u0275\u0275elementStart(3, "table", 10);
    i0.\u0275\u0275text(4, "\n                ");
    i0.\u0275\u0275elementStart(5, "thead");
    i0.\u0275\u0275text(6, "\n                    ");
    i0.\u0275\u0275elementStart(7, "tr");
    i0.\u0275\u0275text(8, "\n                        ");
    i0.\u0275\u0275elementStart(9, "th")(10, "span", 11);
    i0.\u0275\u0275text(11, "ID");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(12, "\n                        ");
    i0.\u0275\u0275elementStart(13, "th")(14, "span", 12);
    i0.\u0275\u0275text(15, "Title");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(16, "\n                        ");
    i0.\u0275\u0275elementStart(17, "th")(18, "span", 13);
    i0.\u0275\u0275text(19, "Content");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(20, "\n                        ");
    i0.\u0275\u0275elementStart(21, "th")(22, "span", 14);
    i0.\u0275\u0275text(23, "Exercise");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(24, "\n                        ");
    i0.\u0275\u0275element(25, "th");
    i0.\u0275\u0275text(26, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(27, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(28, "\n                ");
    i0.\u0275\u0275elementStart(29, "tbody");
    i0.\u0275\u0275text(30, "\n                    ");
    i0.\u0275\u0275repeaterCreate(31, ExerciseHintComponent_Conditional_20_For_32_Template, 60, 23, null, null, i0.\u0275\u0275componentInstance().trackId);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(33, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(34, "\n        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(35, "\n    ");
  }
  if (rf & 2) {
    const ctx_r2 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(31);
    i0.\u0275\u0275repeater(ctx_r2.exerciseHints);
  }
}
var _c0, _c1, ExerciseHintComponent;
var init_exercise_hint_component = __esm({
  "src/main/webapp/app/exercises/shared/exercise-hint/manage/exercise-hint.component.ts"() {
    init_exercise_hint_service();
    init_global_utils();
    init_alert_service();
    init_event_manager_service();
    init_exercise_hint_model();
    init_exercise_model();
    init_programming_exercise_model();
    init_exercise_hint_service();
    init_alert_service();
    init_event_manager_service();
    init_translate_directive();
    init_delete_button_directive();
    init_artemis_translate_pipe();
    init_html_for_markdown_pipe();
    init_code_hint_cast_pipe();
    _c0 = (a0) => [a0];
    _c1 = (a0) => [a0, "edit"];
    ExerciseHintComponent = class _ExerciseHintComponent {
      route;
      exerciseHintService;
      alertService;
      eventManager;
      HintType = HintType;
      ExerciseType = ExerciseType;
      exercise;
      exerciseHints;
      containsCodeHints;
      eventSubscriber;
      dialogErrorSource = new Subject();
      dialogError$ = this.dialogErrorSource.asObservable();
      paramSub;
      faPlus = faPlus;
      faTimes = faTimes;
      faEye = faEye;
      faWrench = faWrench;
      faText = faFont;
      faCode = faCode;
      faArrowsRotate = faArrowsRotate;
      ProgrammingLanguage = ProgrammingLanguage;
      constructor(route, exerciseHintService, alertService, eventManager) {
        this.route = route;
        this.exerciseHintService = exerciseHintService;
        this.alertService = alertService;
        this.eventManager = eventManager;
      }
      ngOnInit() {
        this.route.data.subscribe(({ exercise }) => {
          this.exercise = exercise;
          this.loadAllByExerciseId();
          this.registerChangeInExerciseHints();
        });
      }
      ngOnDestroy() {
        if (this.paramSub) {
          this.paramSub.unsubscribe();
        }
        this.eventManager.destroy(this.eventSubscriber);
        this.dialogErrorSource.unsubscribe();
      }
      loadAllByExerciseId() {
        this.exerciseHintService.findByExerciseId(this.exercise.id).pipe(filter((res) => res.ok), map((res) => res.body)).subscribe({
          next: (res) => {
            this.exerciseHints = res;
            this.containsCodeHints = this.exerciseHints?.some((hint) => hint.type === HintType.CODE);
          },
          error: (res) => onError(this.alertService, res)
        });
      }
      trackId(index, item) {
        return item.id;
      }
      registerChangeInExerciseHints() {
        if (this.eventSubscriber) {
          this.eventSubscriber.unsubscribe();
        }
        this.eventSubscriber = this.eventManager.subscribe("exerciseHintListModification", () => this.loadAllByExerciseId());
      }
      deleteExerciseHint(exerciseHintId) {
        this.exerciseHintService.delete(this.exercise.id, exerciseHintId).subscribe({
          next: () => {
            this.eventManager.broadcast({
              name: "exerciseHintListModification",
              content: "Deleted an exerciseHint"
            });
            this.dialogErrorSource.next("");
          },
          error: (error) => this.dialogErrorSource.next(error.message)
        });
      }
      static \u0275fac = function ExerciseHintComponent_Factory(t) {
        return new (t || _ExerciseHintComponent)(i0.\u0275\u0275directiveInject(i1.ActivatedRoute), i0.\u0275\u0275directiveInject(ExerciseHintService), i0.\u0275\u0275directiveInject(AlertService), i0.\u0275\u0275directiveInject(EventManager));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _ExerciseHintComponent, selectors: [["jhi-exercise-hint"]], decls: 22, vars: 4, consts: [["id", "page-heading"], ["jhiTranslate", "artemisApp.exerciseHint.home.title"], ["id", "jh-create-entity", "routerLink", "new", 1, "btn", "btn-primary", "float-end", "jh-create-entity", "create-exercise-hint", "mx-2"], [3, "icon"], ["jhiTranslate", "artemisApp.exerciseHint.home.createLabel"], ["id", "jh-code-hints", "routerLink", "code-hint-management", 1, "btn", "float-end", "jh-create-entity", "create-exercise-hint"], ["jhiTranslate", "artemisApp.programmingExercise.generateCodeHintsTitle"], [1, "alert", "alert-warning"], ["jhiTranslate", "artemisApp.exerciseHint.home.notFound"], [1, "table-responsive"], [1, "table", "table-striped"], ["jhiTranslate", "global.field.id"], ["jhiTranslate", "artemisApp.exerciseHint.title"], ["jhiTranslate", "artemisApp.exerciseHint.content"], ["jhiTranslate", "artemisApp.exerciseHint.exercise"], [3, "routerLink"], [3, "innerHTML"], [1, "text-end"], [1, "btn-group"], [1, "btn", "btn-info", "btn-sm", "me-1", 3, "routerLink"], ["jhiTranslate", "entity.action.view", 1, "d-none", "d-md-inline"], [1, "btn", "btn-warning", "btn-sm", "me-1", 3, "routerLink"], ["jhiTranslate", "entity.action.edit", 1, "d-none", "d-md-inline"], ["jhiDeleteButton", "", "deleteQuestion", "artemisApp.exerciseHint.delete.question", 3, "entityTitle", "dialogError", "delete"], [1, "badge", "bg-info"]], template: function ExerciseHintComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "div");
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275elementStart(2, "h2", 0);
          i0.\u0275\u0275text(3, "\n        ");
          i0.\u0275\u0275elementStart(4, "span", 1);
          i0.\u0275\u0275text(5, "Exercise Hints");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(6, "\n        ");
          i0.\u0275\u0275template(7, ExerciseHintComponent_Conditional_7_Template, 6, 4);
          i0.\u0275\u0275elementStart(8, "a", 2);
          i0.\u0275\u0275text(9, "\n            ");
          i0.\u0275\u0275element(10, "fa-icon", 3);
          i0.\u0275\u0275text(11, "\n            ");
          i0.\u0275\u0275elementStart(12, "span", 4);
          i0.\u0275\u0275text(13, " Create new Exercise Hint ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(14, "\n        ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(15, "\n    ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(16, "\n    ");
          i0.\u0275\u0275element(17, "br");
          i0.\u0275\u0275text(18, "\n    ");
          i0.\u0275\u0275template(19, ExerciseHintComponent_Conditional_19_Template, 7, 0)(20, ExerciseHintComponent_Conditional_20_Template, 36, 0);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(21, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275advance(7);
          i0.\u0275\u0275conditional(7, (ctx.exercise == null ? null : ctx.exercise.programmingLanguage) === ctx.ProgrammingLanguage.JAVA ? 7 : -1);
          i0.\u0275\u0275advance(3);
          i0.\u0275\u0275property("icon", ctx.faPlus);
          i0.\u0275\u0275advance(9);
          i0.\u0275\u0275conditional(19, (ctx.exerciseHints == null ? null : ctx.exerciseHints.length) === 0 ? 19 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275conditional(20, ctx.exerciseHints && ctx.exerciseHints.length > 0 ? 20 : -1);
        }
      }, dependencies: [i5.FaIconComponent, TranslateDirective, DeleteButtonDirective, i1.RouterLink, ArtemisTranslatePipe, HtmlForMarkdownPipe, CastToCodeHintPipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(ExerciseHintComponent, { className: "ExerciseHintComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/exercise-hint/manage/exercise-hint-detail.component.ts
import { Component as Component2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { faWrench as faWrench2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ExerciseHintDetailComponent_Conditional_4_Conditional_48_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275element(1, "span", 12);
    i02.\u0275\u0275pipe(2, "htmlForMarkdown");
    i02.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r1 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("innerHTML", i02.\u0275\u0275pipeBind1(2, 1, ctx_r1.exerciseHint.content), i02.\u0275\u0275sanitizeHtml);
  }
}
function ExerciseHintDetailComponent_Conditional_4_Conditional_50_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "dd");
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275element(3, "jhi-code-hint-container", 13);
    i02.\u0275\u0275pipe(4, "castToCodeHint");
    i02.\u0275\u0275text(5, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r2 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("codeHint", i02.\u0275\u0275pipeBind1(4, 1, ctx_r2.exerciseHint));
  }
}
function ExerciseHintDetailComponent_Conditional_4_Conditional_57_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275elementStart(3, "a", 14);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r3 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("routerLink", i02.\u0275\u0275pureFunction3(2, _c02, ctx_r3.courseId, ctx_r3.exerciseHint.exercise.type + "-exercises", ctx_r3.exerciseId));
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275textInterpolate(ctx_r3.exerciseHint.exercise == null ? null : ctx_r3.exerciseHint.exercise.id);
  }
}
function ExerciseHintDetailComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                ");
    i02.\u0275\u0275elementStart(3, "h2")(4, "span", 2);
    i02.\u0275\u0275text(5, "Exercise Hint");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                ");
    i02.\u0275\u0275element(8, "hr");
    i02.\u0275\u0275text(9, "\n                ");
    i02.\u0275\u0275elementStart(10, "dl", 3);
    i02.\u0275\u0275text(11, "\n                    ");
    i02.\u0275\u0275elementStart(12, "dt")(13, "span", 4);
    i02.\u0275\u0275text(14, "Title");
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275text(15, "\n                    ");
    i02.\u0275\u0275elementStart(16, "dd");
    i02.\u0275\u0275text(17, "\n                        ");
    i02.\u0275\u0275elementStart(18, "span");
    i02.\u0275\u0275text(19);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(20, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(21, "\n                    ");
    i02.\u0275\u0275elementStart(22, "dt")(23, "span", 5);
    i02.\u0275\u0275text(24, "Description");
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275text(25, "\n                    ");
    i02.\u0275\u0275elementStart(26, "dd");
    i02.\u0275\u0275text(27, "\n                        ");
    i02.\u0275\u0275elementStart(28, "span");
    i02.\u0275\u0275text(29);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(30, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(31, "\n                    ");
    i02.\u0275\u0275elementStart(32, "dt")(33, "span", 6);
    i02.\u0275\u0275text(34, "Content");
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275text(35, "\n                    ");
    i02.\u0275\u0275elementStart(36, "dd");
    i02.\u0275\u0275text(37, "\n                        ");
    i02.\u0275\u0275elementStart(38, "span");
    i02.\u0275\u0275text(39);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(40, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(41, "\n                    ");
    i02.\u0275\u0275elementStart(42, "dt")(43, "span", 7);
    i02.\u0275\u0275text(44, "Content");
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275text(45, "\n                    ");
    i02.\u0275\u0275elementStart(46, "dd");
    i02.\u0275\u0275text(47, "\n                        ");
    i02.\u0275\u0275template(48, ExerciseHintDetailComponent_Conditional_4_Conditional_48_Template, 4, 3);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(49, "\n                    ");
    i02.\u0275\u0275template(50, ExerciseHintDetailComponent_Conditional_4_Conditional_50_Template, 7, 3);
    i02.\u0275\u0275elementStart(51, "dt")(52, "span", 8);
    i02.\u0275\u0275text(53, "Exercise");
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275text(54, "\n                    ");
    i02.\u0275\u0275elementStart(55, "dd");
    i02.\u0275\u0275text(56, "\n                        ");
    i02.\u0275\u0275template(57, ExerciseHintDetailComponent_Conditional_4_Conditional_57_Template, 7, 6);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(58, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(59, "\n                ");
    i02.\u0275\u0275elementStart(60, "a", 9);
    i02.\u0275\u0275text(61, " ");
    i02.\u0275\u0275element(62, "fa-icon", 10);
    i02.\u0275\u0275text(63, "\xA0");
    i02.\u0275\u0275elementStart(64, "span", 11);
    i02.\u0275\u0275text(65, " Edit");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(66, " ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(67, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(68, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    let tmp_3_0;
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275textInterpolate1(" ", ctx_r0.exerciseHint.id, "");
    i02.\u0275\u0275advance(13);
    i02.\u0275\u0275textInterpolate(ctx_r0.exerciseHint.title);
    i02.\u0275\u0275advance(10);
    i02.\u0275\u0275textInterpolate(ctx_r0.exerciseHint.description);
    i02.\u0275\u0275advance(10);
    i02.\u0275\u0275textInterpolate((tmp_3_0 = ctx_r0.exerciseHint == null ? null : ctx_r0.exerciseHint.programmingExerciseTask == null ? null : ctx_r0.exerciseHint.programmingExerciseTask.taskName) !== null && tmp_3_0 !== void 0 ? tmp_3_0 : "-");
    i02.\u0275\u0275advance(9);
    i02.\u0275\u0275conditional(48, ctx_r0.exerciseHint.content ? 48 : -1);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(50, ctx_r0.exerciseHint.type === ctx_r0.HintType.CODE ? 50 : -1);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275conditional(57, ctx_r0.exerciseHint.exercise ? 57 : -1);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("routerLink", i02.\u0275\u0275pureFunction0(9, _c12));
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("icon", ctx_r0.faWrench);
  }
}
var _c02, _c12, ExerciseHintDetailComponent;
var init_exercise_hint_detail_component = __esm({
  "src/main/webapp/app/exercises/shared/exercise-hint/manage/exercise-hint-detail.component.ts"() {
    init_exercise_hint_model();
    init_translate_directive();
    init_code_hint_container_component();
    init_html_for_markdown_pipe();
    init_code_hint_cast_pipe();
    _c02 = (a1, a2, a3) => ["/course-management", a1, a2, a3];
    _c12 = () => ["edit"];
    ExerciseHintDetailComponent = class _ExerciseHintDetailComponent {
      route;
      HintType = HintType;
      exerciseHint;
      courseId;
      exerciseId;
      paramSub;
      faWrench = faWrench2;
      constructor(route) {
        this.route = route;
      }
      ngOnInit() {
        this.paramSub = this.route.params.subscribe((params) => {
          this.courseId = params["courseId"];
          this.exerciseId = params["exerciseId"];
        });
        this.route.data.subscribe(({ exerciseHint }) => {
          this.exerciseHint = exerciseHint;
        });
      }
      ngOnDestroy() {
        if (this.paramSub) {
          this.paramSub.unsubscribe();
        }
      }
      static \u0275fac = function ExerciseHintDetailComponent_Factory(t) {
        return new (t || _ExerciseHintDetailComponent)(i02.\u0275\u0275directiveInject(i12.ActivatedRoute));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _ExerciseHintDetailComponent, selectors: [["jhi-exercise-hint-detail"]], decls: 7, vars: 1, consts: [[1, "row", "justify-content-center"], [1, "col-md-8"], ["jhiTranslate", "artemisApp.exerciseHint.detail.title"], [1, "row-md", "jh-entity-details"], ["jhiTranslate", "artemisApp.exerciseHint.title"], ["jhiTranslate", "artemisApp.exerciseHint.description"], ["jhiTranslate", "artemisApp.exerciseHint.task"], ["jhiTranslate", "artemisApp.exerciseHint.content"], ["jhiTranslate", "artemisApp.exerciseHint.exercise"], [1, "btn", "btn-warning", 3, "routerLink"], [3, "icon"], ["jhiTranslate", "entity.action.edit"], [3, "innerHTML"], [3, "codeHint"], [3, "routerLink"]], template: function ExerciseHintDetailComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div", 0);
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275elementStart(2, "div", 1);
          i02.\u0275\u0275text(3, "\n        ");
          i02.\u0275\u0275template(4, ExerciseHintDetailComponent_Conditional_4_Template, 69, 10);
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(5, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(6, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(4);
          i02.\u0275\u0275conditional(4, ctx.exerciseHint ? 4 : -1);
        }
      }, dependencies: [i2.FaIconComponent, TranslateDirective, i12.RouterLink, CodeHintContainerComponent, HtmlForMarkdownPipe, CastToCodeHintPipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(ExerciseHintDetailComponent, { className: "ExerciseHintDetailComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/exercise-hint/manage/exercise-hint-update.component.ts
import { Component as Component3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { filter as filter2, switchMap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { faBan, faCircleNotch, faSave } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { NgbModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i10 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i11 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ExerciseHintUpdateComponent_Conditional_48_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                            ");
    i03.\u0275\u0275element(1, "jhi-help-icon", 26);
    i03.\u0275\u0275text(2, "\n                        ");
  }
}
function ExerciseHintUpdateComponent_For_53_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                            ");
    i03.\u0275\u0275elementStart(1, "option", 27);
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const task_r7 = ctx.$implicit;
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("ngValue", task_r7);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275textInterpolate(task_r7.taskName);
  }
}
function ExerciseHintUpdateComponent_Conditional_69_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "div", 28);
    i03.\u0275\u0275text(2, "\n                        ");
    i03.\u0275\u0275elementStart(3, "jhi-button", 29);
    i03.\u0275\u0275listener("click", function ExerciseHintUpdateComponent_Conditional_69_Template_jhi_button_click_3_listener() {
      i03.\u0275\u0275restoreView(_r13);
      const ctx_r12 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r12.generateDescriptionForCodeHint());
    });
    i03.\u0275\u0275text(4, "Generate description\n                        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(6, "\n                ");
  }
  if (rf & 2) {
    const ctx_r3 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("shouldSubmit", false)("isLoading", ctx_r3.isGeneratingDescription)("title", "artemisApp.codeHint.management.step4.iris.generateDescription.label")("tooltip", "artemisApp.codeHint.management.step4.iris.generateDescription.tooltip");
  }
}
function ExerciseHintUpdateComponent_Conditional_75_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "div", 19);
    i03.\u0275\u0275text(2, "\n                        ");
    i03.\u0275\u0275element(3, "jhi-code-hint-container", 30);
    i03.\u0275\u0275pipe(4, "castToCodeHint");
    i03.\u0275\u0275text(5, "\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(6, "\n                ");
  }
  if (rf & 2) {
    const ctx_r4 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("codeHint", i03.\u0275\u0275pipeBind1(4, 2, ctx_r4.exerciseHint))("enableEditing", true);
  }
}
function ExerciseHintUpdateComponent_Conditional_76_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "div", 31);
    i03.\u0275\u0275text(2, "\n                        ");
    i03.\u0275\u0275elementStart(3, "button", 32);
    i03.\u0275\u0275listener("click", function ExerciseHintUpdateComponent_Conditional_76_Template_button_click_3_listener() {
      i03.\u0275\u0275restoreView(_r15);
      const ctx_r14 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r14.openManualEntryCreationModal());
    });
    i03.\u0275\u0275text(4, "\n                            Create new Solution Code Snippets\n                        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(6, "\n                ");
  }
}
function ExerciseHintUpdateComponent_Conditional_77_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "div", 33);
    i03.\u0275\u0275text(2, "\n                        ");
    i03.\u0275\u0275elementStart(3, "label", 34);
    i03.\u0275\u0275text(4, "Exercise");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                        ");
    i03.\u0275\u0275element(6, "input", 35);
    i03.\u0275\u0275text(7, "\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n                ");
  }
  if (rf & 2) {
    const ctx_r6 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(6);
    i03.\u0275\u0275property("disabled", true)("ngModel", ctx_r6.exercise && ctx_r6.exercise.title + " (ID: " + ctx_r6.exercise.id + ")");
  }
}
var DEFAULT_DISPLAY_THRESHOLD, ExerciseHintUpdateComponent;
var init_exercise_hint_update_component = __esm({
  "src/main/webapp/app/exercises/shared/exercise-hint/manage/exercise-hint-update.component.ts"() {
    init_alert_service();
    init_exercise_hint_service();
    init_markdown_editor_component();
    init_katex_command();
    init_navigation_utils();
    init_exercise_hint_model();
    init_programming_exercise_service();
    init_manual_solution_entry_creation_modal_component();
    init_code_hint_service();
    init_global_utils();
    init_iris_settings_service();
    init_profile_service();
    init_alert_service();
    init_code_hint_service();
    init_exercise_hint_service();
    init_programming_exercise_service();
    init_navigation_utils();
    init_iris_settings_service();
    init_profile_service();
    init_translate_directive();
    init_markdown_editor_component();
    init_code_hint_container_component();
    init_button_component();
    init_help_icon_component();
    init_code_hint_cast_pipe();
    DEFAULT_DISPLAY_THRESHOLD = 3;
    ExerciseHintUpdateComponent = class _ExerciseHintUpdateComponent {
      route;
      alertService;
      modalService;
      codeHintService;
      exerciseHintService;
      programmingExerciseService;
      navigationUtilService;
      irisSettingsService;
      profileService;
      MarkdownEditorHeight = MarkdownEditorHeight;
      courseId;
      exercise;
      HintType = HintType;
      exerciseHint = new ExerciseHint();
      solutionEntries;
      programmingExercise;
      tasks;
      irisSettings;
      isSaving;
      isGeneratingDescription;
      paramSub;
      domainCommands = [new KatexCommand()];
      editorMode = EditorMode.LATEX;
      faCircleNotch = faCircleNotch;
      faBan = faBan;
      faSave = faSave;
      constructor(route, alertService, modalService, codeHintService, exerciseHintService, programmingExerciseService, navigationUtilService, irisSettingsService, profileService) {
        this.route = route;
        this.alertService = alertService;
        this.modalService = modalService;
        this.codeHintService = codeHintService;
        this.exerciseHintService = exerciseHintService;
        this.programmingExerciseService = programmingExerciseService;
        this.navigationUtilService = navigationUtilService;
        this.irisSettingsService = irisSettingsService;
        this.profileService = profileService;
      }
      ngOnInit() {
        this.paramSub = this.route.params.subscribe((params) => {
          this.courseId = params["courseId"];
          this.isSaving = false;
          this.isGeneratingDescription = false;
        });
        this.route.data.subscribe(({ exerciseHint, exercise }) => {
          this.exercise = exercise;
          exerciseHint.exercise = exercise;
          this.exerciseHint = exerciseHint;
          this.exerciseHint.displayThreshold = this.exerciseHint.displayThreshold ?? DEFAULT_DISPLAY_THRESHOLD;
          this.programmingExerciseService.getTasksAndTestsExtractedFromProblemStatement(this.exercise.id).subscribe((tasks) => {
            this.tasks = tasks;
            const selectedTask = this.tasks.find((task) => task.id === this.exerciseHint.programmingExerciseTask?.id);
            if (selectedTask) {
              this.exerciseHint.programmingExerciseTask = selectedTask;
            } else if (tasks.length) {
              this.exerciseHint.programmingExerciseTask = this.tasks[0];
            }
          });
          this.profileService.getProfileInfo().pipe(filter2((profileInfo) => profileInfo?.activeProfiles?.includes("iris")), switchMap(() => this.irisSettingsService.getCombinedProgrammingExerciseSettings(this.exercise.id))).subscribe((settings) => {
            this.irisSettings = settings;
          });
        });
      }
      openManualEntryCreationModal() {
        const codeHint = this.exerciseHint;
        const testCasesForCurrentTask = codeHint.programmingExerciseTask?.testCases ?? [];
        const modalRef = this.modalService.open(ManualSolutionEntryCreationModalComponent, { size: "lg", backdrop: "static" });
        modalRef.componentInstance.exerciseId = this.exercise.id;
        modalRef.componentInstance.codeHint = codeHint;
        modalRef.componentInstance.testCases = testCasesForCurrentTask;
        modalRef.componentInstance.onEntryCreated.subscribe((createdEntry) => {
          codeHint.solutionEntries.push(createdEntry);
        });
      }
      ngOnDestroy() {
        if (this.paramSub) {
          this.paramSub.unsubscribe();
        }
      }
      updateHintContent(newContent) {
        this.exerciseHint.content = newContent;
      }
      previousState() {
        this.navigationUtilService.navigateBackWithOptional(["course-management", this.courseId.toString(), "programming-exercises", this.exercise.id.toString(), "hints"], this.exerciseHint.id?.toString());
      }
      save() {
        this.isSaving = true;
        if (this.exerciseHint.id !== void 0) {
          this.subscribeToSaveResponse(this.exerciseHintService.update(this.exercise.id, this.exerciseHint));
        } else {
          this.subscribeToSaveResponse(this.exerciseHintService.create(this.exercise.id, this.exerciseHint));
        }
      }
      generateDescriptionForCodeHint() {
        this.isGeneratingDescription = true;
        this.codeHintService.generateDescriptionForCodeHint(this.exercise.id, this.exerciseHint.id).subscribe({
          next: (response) => {
            this.exerciseHint.description = response.body.description;
            this.exerciseHint.content = response.body.content;
            this.isGeneratingDescription = false;
          },
          error: (error) => {
            this.isGeneratingDescription = false;
            onError(this.alertService, error);
          }
        });
      }
      subscribeToSaveResponse(result) {
        result.subscribe({
          next: () => this.onSaveSuccess(),
          error: () => this.onSaveError()
        });
      }
      onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
      }
      onSaveError() {
        this.isSaving = false;
      }
      static \u0275fac = function ExerciseHintUpdateComponent_Factory(t) {
        return new (t || _ExerciseHintUpdateComponent)(i03.\u0275\u0275directiveInject(i13.ActivatedRoute), i03.\u0275\u0275directiveInject(AlertService), i03.\u0275\u0275directiveInject(i3.NgbModal), i03.\u0275\u0275directiveInject(CodeHintService), i03.\u0275\u0275directiveInject(ExerciseHintService), i03.\u0275\u0275directiveInject(ProgrammingExerciseService), i03.\u0275\u0275directiveInject(ArtemisNavigationUtilService), i03.\u0275\u0275directiveInject(IrisSettingsService), i03.\u0275\u0275directiveInject(ProfileService));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _ExerciseHintUpdateComponent, selectors: [["jhi-exercise-hint-update"]], decls: 101, vars: 20, consts: [[1, "row", "justify-content-center"], [1, "col-md-8"], ["name", "editForm", "role", "form", "novalidate", "", 3, "ngSubmit"], ["hintForm", "ngForm"], ["id", "jhi-exercise-hint-heading", 3, "jhiTranslate"], [1, "form-group", 3, "hidden"], ["for", "id", "jhiTranslate", "global.field.id"], ["type", "text", "id", "id", "name", "id", "readonly", "", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "form-group"], ["jhiTranslate", "artemisApp.exerciseHint.title", "for", "field_title", 1, "form-control-label"], ["type", "text", "required", "", "minlength", "3", "name", "title", "id", "field_title", 1, "form-control", 3, "ngModel", "ngModelChange"], ["jhiTranslate", "artemisApp.exerciseHint.description", "for", "field_description", 1, "label-narrow"], ["text", "artemisApp.exerciseHint.descriptionTooltip"], ["type", "text", "required", "", "minlength", "3", "name", "description", "id", "field_description", 1, "form-control", 3, "ngModel", "ngModelChange"], ["jhiTranslate", "artemisApp.exerciseHint.task", "for", "field_task", 1, "label-narrow"], ["required", "", "name", "task", "id", "field_task", 1, "form-select", 3, "ngModel", "ngModelChange"], ["jhiTranslate", "artemisApp.exerciseHint.displayThreshold", "for", "field_description", 1, "label-narrow"], ["text", "artemisApp.exerciseHint.displayThresholdTooltip"], ["type", "number", "required", "", "min", "0", "max", "100", "name", "displayThreshold", "id", "field_displayThreshold", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "form-group", "hint-form__editor-wrapper"], [3, "markdown", "resizableMinHeight", "resizableMaxHeight", "domainCommands", "editorMode", "markdownChange"], ["type", "button", "id", "cancel-save", 1, "btn", "btn-secondary", 3, "click"], [3, "icon"], ["jhiTranslate", "entity.action.cancel"], ["type", "submit", "id", "save-entity", 1, "btn", "btn-primary", 3, "disabled"], ["jhiTranslate", "entity.action.save"], ["text", "artemisApp.exerciseHint.taskTooltip"], [3, "ngValue"], [1, "d-flex", "justify-content-end"], ["id", "generateDescriptionButton", 3, "shouldSubmit", "isLoading", "title", "tooltip", "click"], [3, "codeHint", "enableEditing"], [1, "btn-group"], ["type", "button", "jhiTranslate", "artemisApp.codeHint.management.step3.createManualFragmentButton.label", 1, "btn", "btn-primary", 3, "click"], [1, "form-group", "mt-3"], ["jhiTranslate", "artemisApp.exerciseHint.exercise", "for", "field_exercise", 1, "form-control-label"], ["type", "text", "required", "", "name", "exercise", "id", "field_exercise", 1, "form-control", 3, "disabled", "ngModel"]], template: function ExerciseHintUpdateComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "div", 0);
          i03.\u0275\u0275text(1, "\n    ");
          i03.\u0275\u0275elementStart(2, "div", 1);
          i03.\u0275\u0275text(3, "\n        ");
          i03.\u0275\u0275elementStart(4, "form", 2, 3);
          i03.\u0275\u0275listener("ngSubmit", function ExerciseHintUpdateComponent_Template_form_ngSubmit_4_listener() {
            return ctx.save();
          });
          i03.\u0275\u0275text(6, "\n            ");
          i03.\u0275\u0275elementStart(7, "h2", 4);
          i03.\u0275\u0275text(8, "\n                Create or edit a Exercise Hint\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(9, "\n            ");
          i03.\u0275\u0275elementStart(10, "div");
          i03.\u0275\u0275text(11, "\n                ");
          i03.\u0275\u0275elementStart(12, "div", 5);
          i03.\u0275\u0275text(13, "\n                    ");
          i03.\u0275\u0275elementStart(14, "label", 6);
          i03.\u0275\u0275text(15, "ID");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(16, "\n                    ");
          i03.\u0275\u0275elementStart(17, "input", 7);
          i03.\u0275\u0275listener("ngModelChange", function ExerciseHintUpdateComponent_Template_input_ngModelChange_17_listener($event) {
            return ctx.exerciseHint.id = $event;
          });
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(18, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(19, "\n                ");
          i03.\u0275\u0275elementStart(20, "div", 8);
          i03.\u0275\u0275text(21, "\n                    ");
          i03.\u0275\u0275elementStart(22, "label", 9);
          i03.\u0275\u0275text(23, "Title");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(24, "\n                    ");
          i03.\u0275\u0275elementStart(25, "input", 10);
          i03.\u0275\u0275listener("ngModelChange", function ExerciseHintUpdateComponent_Template_input_ngModelChange_25_listener($event) {
            return ctx.exerciseHint.title = $event;
          });
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(26, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(27, "\n                ");
          i03.\u0275\u0275elementStart(28, "div", 8);
          i03.\u0275\u0275text(29, "\n                    ");
          i03.\u0275\u0275elementStart(30, "div");
          i03.\u0275\u0275text(31, "\n                        ");
          i03.\u0275\u0275elementStart(32, "label", 11);
          i03.\u0275\u0275text(33, "Description");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(34, "\n                        ");
          i03.\u0275\u0275element(35, "jhi-help-icon", 12);
          i03.\u0275\u0275text(36, "\n                    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(37, "\n                    ");
          i03.\u0275\u0275elementStart(38, "input", 13);
          i03.\u0275\u0275listener("ngModelChange", function ExerciseHintUpdateComponent_Template_input_ngModelChange_38_listener($event) {
            return ctx.exerciseHint.description = $event;
          });
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(39, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(40, "\n                ");
          i03.\u0275\u0275elementStart(41, "div", 8);
          i03.\u0275\u0275text(42, "\n                    ");
          i03.\u0275\u0275elementStart(43, "div");
          i03.\u0275\u0275text(44, "\n                        ");
          i03.\u0275\u0275elementStart(45, "label", 14);
          i03.\u0275\u0275text(46, "Task");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(47, "\n                        ");
          i03.\u0275\u0275template(48, ExerciseHintUpdateComponent_Conditional_48_Template, 3, 0);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(49, "\n                    ");
          i03.\u0275\u0275elementStart(50, "select", 15);
          i03.\u0275\u0275listener("ngModelChange", function ExerciseHintUpdateComponent_Template_select_ngModelChange_50_listener($event) {
            return ctx.exerciseHint.programmingExerciseTask = $event;
          });
          i03.\u0275\u0275text(51, "\n                        ");
          i03.\u0275\u0275repeaterCreate(52, ExerciseHintUpdateComponent_For_53_Template, 4, 2, null, null, i03.\u0275\u0275repeaterTrackByIdentity);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(54, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(55, "\n                ");
          i03.\u0275\u0275elementStart(56, "div", 8);
          i03.\u0275\u0275text(57, "\n                    ");
          i03.\u0275\u0275elementStart(58, "div");
          i03.\u0275\u0275text(59, "\n                        ");
          i03.\u0275\u0275elementStart(60, "label", 16);
          i03.\u0275\u0275text(61, "Display Threshold");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(62, "\n                        ");
          i03.\u0275\u0275element(63, "jhi-help-icon", 17);
          i03.\u0275\u0275text(64, "\n                    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(65, "\n                    ");
          i03.\u0275\u0275elementStart(66, "input", 18);
          i03.\u0275\u0275listener("ngModelChange", function ExerciseHintUpdateComponent_Template_input_ngModelChange_66_listener($event) {
            return ctx.exerciseHint.displayThreshold = $event;
          });
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(67, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(68, "\n                ");
          i03.\u0275\u0275template(69, ExerciseHintUpdateComponent_Conditional_69_Template, 7, 4);
          i03.\u0275\u0275elementStart(70, "div", 19);
          i03.\u0275\u0275text(71, "\n                    ");
          i03.\u0275\u0275elementStart(72, "jhi-markdown-editor", 20);
          i03.\u0275\u0275listener("markdownChange", function ExerciseHintUpdateComponent_Template_jhi_markdown_editor_markdownChange_72_listener($event) {
            return ctx.updateHintContent($event);
          });
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(73, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(74, "\n                ");
          i03.\u0275\u0275template(75, ExerciseHintUpdateComponent_Conditional_75_Template, 7, 4)(76, ExerciseHintUpdateComponent_Conditional_76_Template, 7, 0)(77, ExerciseHintUpdateComponent_Conditional_77_Template, 9, 2);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(78, "\n            ");
          i03.\u0275\u0275elementStart(79, "div");
          i03.\u0275\u0275text(80, "\n                ");
          i03.\u0275\u0275elementStart(81, "button", 21);
          i03.\u0275\u0275listener("click", function ExerciseHintUpdateComponent_Template_button_click_81_listener() {
            return ctx.previousState();
          });
          i03.\u0275\u0275text(82, "\n                    ");
          i03.\u0275\u0275element(83, "fa-icon", 22);
          i03.\u0275\u0275text(84, "\xA0");
          i03.\u0275\u0275elementStart(85, "span", 23);
          i03.\u0275\u0275text(86, "Cancel");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(87, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(88, "\n                ");
          i03.\u0275\u0275elementStart(89, "button", 24);
          i03.\u0275\u0275text(90, "\n                    ");
          i03.\u0275\u0275element(91, "fa-icon", 22);
          i03.\u0275\u0275text(92, "\xA0");
          i03.\u0275\u0275elementStart(93, "span", 25);
          i03.\u0275\u0275text(94, "Save");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(95, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(96, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(97, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(98, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(99, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(100, "\n");
        }
        if (rf & 2) {
          const _r0 = i03.\u0275\u0275reference(5);
          i03.\u0275\u0275advance(7);
          i03.\u0275\u0275property("jhiTranslate", "artemisApp.exerciseHint.home." + (ctx.exerciseHint.id ? "editLabel" : "createLabel"));
          i03.\u0275\u0275advance(5);
          i03.\u0275\u0275property("hidden", !(ctx.exerciseHint == null ? null : ctx.exerciseHint.id));
          i03.\u0275\u0275advance(5);
          i03.\u0275\u0275property("ngModel", ctx.exerciseHint.id);
          i03.\u0275\u0275advance(8);
          i03.\u0275\u0275property("ngModel", ctx.exerciseHint.title);
          i03.\u0275\u0275advance(13);
          i03.\u0275\u0275property("ngModel", ctx.exerciseHint.description);
          i03.\u0275\u0275advance(10);
          i03.\u0275\u0275conditional(48, ctx.exerciseHint.type === "code" ? 48 : -1);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275property("ngModel", ctx.exerciseHint.programmingExerciseTask);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275repeater(ctx.tasks);
          i03.\u0275\u0275advance(14);
          i03.\u0275\u0275property("ngModel", ctx.exerciseHint.displayThreshold);
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275conditional(69, ctx.exerciseHint.type === ctx.HintType.CODE && (ctx.irisSettings == null ? null : ctx.irisSettings.irisHestiaSettings == null ? null : ctx.irisSettings.irisHestiaSettings.enabled) ? 69 : -1);
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275property("markdown", ctx.exerciseHint.content)("resizableMinHeight", ctx.MarkdownEditorHeight.SMALL)("resizableMaxHeight", ctx.MarkdownEditorHeight.LARGE)("domainCommands", ctx.domainCommands)("editorMode", ctx.editorMode);
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275conditional(75, ctx.exerciseHint.type === ctx.HintType.CODE ? 75 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(76, ctx.exerciseHint.type === ctx.HintType.CODE ? 76 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(77, (ctx.exercise == null ? null : ctx.exercise.id) ? 77 : -1);
          i03.\u0275\u0275advance(6);
          i03.\u0275\u0275property("icon", ctx.faBan);
          i03.\u0275\u0275advance(6);
          i03.\u0275\u0275property("disabled", _r0.invalid || ctx.isSaving || !ctx.exercise.id);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275property("icon", ctx.faSave);
        }
      }, dependencies: [i10.\u0275NgNoValidate, i10.NgSelectOption, i10.\u0275NgSelectMultipleOption, i10.DefaultValueAccessor, i10.NumberValueAccessor, i10.SelectControlValueAccessor, i10.NgControlStatus, i10.NgControlStatusGroup, i10.RequiredValidator, i10.MinLengthValidator, i10.MinValidator, i10.MaxValidator, i10.NgModel, i10.NgForm, i11.FaIconComponent, TranslateDirective, MarkdownEditorComponent, CodeHintContainerComponent, ButtonComponent, HelpIconComponent, CastToCodeHintPipe], styles: ["\n\n.hint-form__editor-wrapper[_ngcontent-%COMP%]     .markdown-editor {\n  height: 300px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlLWhpbnQvbWFuYWdlL2V4ZXJjaXNlLWhpbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmhpbnQtZm9ybV9fZWRpdG9yLXdyYXBwZXIge1xuICAgIDo6bmctZGVlcCAubWFya2Rvd24tZWRpdG9yIHtcbiAgICAgICAgaGVpZ2h0OiAzMDBweDtcbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQ0ksQ0FBQSwwQkFBQSxVQUFBLENBQUE7QUFDSSxVQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(ExerciseHintUpdateComponent, { className: "ExerciseHintUpdateComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/exercise-hint/manage/exercise-hint.route.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { of } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { filter as filter3, map as map2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ExerciseHintResolve, exerciseHintRoute;
var init_exercise_hint_route = __esm({
  "src/main/webapp/app/exercises/shared/exercise-hint/manage/exercise-hint.route.ts"() {
    init_user_route_access_service();
    init_exercise_hint_service();
    init_exercise_hint_component();
    init_exercise_hint_detail_component();
    init_exercise_hint_model();
    init_authority_constants();
    init_exercise_model();
    init_exercise_hint_update_component();
    init_programming_exercise_management_routing_module();
    init_exercise_hint_service();
    ExerciseHintResolve = class _ExerciseHintResolve {
      service;
      constructor(service) {
        this.service = service;
      }
      resolve(route) {
        const exerciseId = route.params["exerciseId"] ? route.params["exerciseId"] : void 0;
        const hintId = route.params["hintId"] ? route.params["hintId"] : void 0;
        if (exerciseId && hintId) {
          return this.service.find(exerciseId, hintId).pipe(filter3((response) => response.ok), map2((exerciseHint) => exerciseHint.body));
        }
        return of(new ExerciseHint());
      }
      static \u0275fac = function ExerciseHintResolve_Factory(t) {
        return new (t || _ExerciseHintResolve)(i04.\u0275\u0275inject(ExerciseHintService));
      };
      static \u0275prov = i04.\u0275\u0275defineInjectable({ token: _ExerciseHintResolve, factory: _ExerciseHintResolve.\u0275fac, providedIn: "root" });
    };
    exerciseHintRoute = [
      ...exerciseTypes.map((exerciseType) => {
        return {
          path: ":courseId/" + exerciseType + "-exercises/:exerciseId/exercise-hints/new",
          component: ExerciseHintUpdateComponent,
          resolve: {
            exercise: ProgrammingExerciseResolve,
            exerciseHint: ExerciseHintResolve
          },
          data: {
            authorities: [Authority.EDITOR, Authority.INSTRUCTOR, Authority.ADMIN],
            pageTitle: "artemisApp.exerciseHint.home.title"
          },
          canActivate: [UserRouteAccessService]
        };
      }),
      ...exerciseTypes.map((exerciseType) => {
        return {
          path: ":courseId/" + exerciseType + "-exercises/:exerciseId/exercise-hints/:hintId",
          component: ExerciseHintDetailComponent,
          resolve: {
            exerciseHint: ExerciseHintResolve
          },
          data: {
            authorities: [Authority.EDITOR, Authority.INSTRUCTOR, Authority.ADMIN],
            pageTitle: "artemisApp.exerciseHint.home.title"
          },
          canActivate: [UserRouteAccessService]
        };
      }),
      ...exerciseTypes.map((exerciseType) => {
        return {
          path: ":courseId/" + exerciseType + "-exercises/:exerciseId/exercise-hints/:hintId/edit",
          component: ExerciseHintUpdateComponent,
          resolve: {
            exercise: ProgrammingExerciseResolve,
            exerciseHint: ExerciseHintResolve
          },
          data: {
            authorities: [Authority.EDITOR, Authority.INSTRUCTOR, Authority.ADMIN],
            pageTitle: "artemisApp.exerciseHint.home.title"
          },
          canActivate: [UserRouteAccessService]
        };
      }),
      ...exerciseTypes.map((exerciseType) => {
        return {
          path: ":courseId/" + exerciseType + "-exercises/:exerciseId/exercise-hints",
          component: ExerciseHintComponent,
          resolve: {
            exercise: ProgrammingExerciseResolve
          },
          data: {
            authorities: [Authority.EDITOR, Authority.INSTRUCTOR, Authority.ADMIN],
            pageTitle: "artemisApp.exerciseHint.home.title"
          },
          canActivate: [UserRouteAccessService]
        };
      })
    ];
  }
});

// src/main/webapp/app/exercises/shared/exercise-hint/manage/exercise-hint-management.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { FormsModule, ReactiveFormsModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import { RouterModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ENTITY_STATES, ArtemisExerciseHintManagementModule;
var init_exercise_hint_management_module = __esm({
  "src/main/webapp/app/exercises/shared/exercise-hint/manage/exercise-hint-management.module.ts"() {
    init_shared_module();
    init_exercise_hint_route();
    init_exercise_hint_detail_component();
    init_exercise_hint_update_component();
    init_exercise_hint_component();
    init_exercise_hint_shared_module();
    init_markdown_module();
    init_markdown_editor_module();
    init_shared_component_module();
    ENTITY_STATES = [...exerciseHintRoute];
    ArtemisExerciseHintManagementModule = class _ArtemisExerciseHintManagementModule {
      static \u0275fac = function ArtemisExerciseHintManagementModule_Factory(t) {
        return new (t || _ArtemisExerciseHintManagementModule)();
      };
      static \u0275mod = i05.\u0275\u0275defineNgModule({ type: _ArtemisExerciseHintManagementModule });
      static \u0275inj = i05.\u0275\u0275defineInjector({ imports: [
        ArtemisSharedModule,
        RouterModule.forChild(ENTITY_STATES),
        FormsModule,
        ReactiveFormsModule,
        ArtemisMarkdownModule,
        ArtemisMarkdownEditorModule,
        ArtemisExerciseHintSharedModule,
        ArtemisSharedComponentModule,
        ArtemisExerciseHintSharedModule
      ] });
    };
  }
});

export {
  ArtemisExerciseHintManagementModule,
  init_exercise_hint_management_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oaW50L21hbmFnZS9leGVyY2lzZS1oaW50LmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oaW50L21hbmFnZS9leGVyY2lzZS1oaW50LmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlLWhpbnQvbWFuYWdlL2V4ZXJjaXNlLWhpbnQtZGV0YWlsLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oaW50L21hbmFnZS9leGVyY2lzZS1oaW50LWRldGFpbC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oaW50L21hbmFnZS9leGVyY2lzZS1oaW50LXVwZGF0ZS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhlcmNpc2UtaGludC9tYW5hZ2UvZXhlcmNpc2UtaGludC11cGRhdGUuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhlcmNpc2UtaGludC9tYW5hZ2UvZXhlcmNpc2UtaGludC5yb3V0ZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oaW50L21hbmFnZS9leGVyY2lzZS1oaW50LW1hbmFnZW1lbnQubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25EZXN0cm95LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IEh0dHBFcnJvclJlc3BvbnNlLCBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBTdWJqZWN0LCBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IGZpbHRlciwgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuXG5pbXBvcnQgeyBFeGVyY2lzZUhpbnRTZXJ2aWNlIH0gZnJvbSAnLi4vc2hhcmVkL2V4ZXJjaXNlLWhpbnQuc2VydmljZSc7XG5pbXBvcnQgeyBvbkVycm9yIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2dsb2JhbC51dGlscyc7XG5pbXBvcnQgeyBBbGVydFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuaW1wb3J0IHsgRXZlbnRNYW5hZ2VyIH0gZnJvbSAnYXBwL2NvcmUvdXRpbC9ldmVudC1tYW5hZ2VyLnNlcnZpY2UnO1xuaW1wb3J0IHsgZmFBcnJvd3NSb3RhdGUsIGZhQ29kZSwgZmFFeWUsIGZhRm9udCwgZmFQbHVzLCBmYVRpbWVzLCBmYVdyZW5jaCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBFeGVyY2lzZUhpbnQsIEhpbnRUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2hlc3RpYS9leGVyY2lzZS1oaW50Lm1vZGVsJztcbmltcG9ydCB7IEV4ZXJjaXNlVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlLCBQcm9ncmFtbWluZ0xhbmd1YWdlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3Byb2dyYW1taW5nLWV4ZXJjaXNlLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktZXhlcmNpc2UtaGludCcsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2V4ZXJjaXNlLWhpbnQuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBFeGVyY2lzZUhpbnRDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gICAgcmVhZG9ubHkgSGludFR5cGUgPSBIaW50VHlwZTtcbiAgICBFeGVyY2lzZVR5cGUgPSBFeGVyY2lzZVR5cGU7XG4gICAgZXhlcmNpc2U6IFByb2dyYW1taW5nRXhlcmNpc2U7XG4gICAgZXhlcmNpc2VIaW50czogRXhlcmNpc2VIaW50W107XG4gICAgY29udGFpbnNDb2RlSGludHM6IGJvb2xlYW47XG4gICAgZXZlbnRTdWJzY3JpYmVyOiBTdWJzY3JpcHRpb247XG5cbiAgICBwcml2YXRlIGRpYWxvZ0Vycm9yU291cmNlID0gbmV3IFN1YmplY3Q8c3RyaW5nPigpO1xuICAgIGRpYWxvZ0Vycm9yJCA9IHRoaXMuZGlhbG9nRXJyb3JTb3VyY2UuYXNPYnNlcnZhYmxlKCk7XG5cbiAgICBwYXJhbVN1YjogU3Vic2NyaXB0aW9uO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYVBsdXMgPSBmYVBsdXM7XG4gICAgZmFUaW1lcyA9IGZhVGltZXM7XG4gICAgZmFFeWUgPSBmYUV5ZTtcbiAgICBmYVdyZW5jaCA9IGZhV3JlbmNoO1xuICAgIGZhVGV4dCA9IGZhRm9udDtcbiAgICBmYUNvZGUgPSBmYUNvZGU7XG4gICAgZmFBcnJvd3NSb3RhdGUgPSBmYUFycm93c1JvdGF0ZTtcblxuICAgIHJlYWRvbmx5IFByb2dyYW1taW5nTGFuZ3VhZ2UgPSBQcm9ncmFtbWluZ0xhbmd1YWdlO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgICAgICBwcm90ZWN0ZWQgZXhlcmNpc2VIaW50U2VydmljZTogRXhlcmNpc2VIaW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBhbGVydFNlcnZpY2U6IEFsZXJ0U2VydmljZSxcbiAgICAgICAgcHJvdGVjdGVkIGV2ZW50TWFuYWdlcjogRXZlbnRNYW5hZ2VyLFxuICAgICkge31cblxuICAgIC8qKlxuICAgICAqIFN1YnNjcmliZXMgdG8gdGhlIHJvdXRlIHBhcmFtcyB0byBhY3Qgb24gdGhlIGN1cnJlbnRseSBzZWxlY3RlZCBleGVyY2lzZS5cbiAgICAgKi9cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5yb3V0ZS5kYXRhLnN1YnNjcmliZSgoeyBleGVyY2lzZSB9KSA9PiB7XG4gICAgICAgICAgICB0aGlzLmV4ZXJjaXNlID0gZXhlcmNpc2U7XG4gICAgICAgICAgICB0aGlzLmxvYWRBbGxCeUV4ZXJjaXNlSWQoKTtcbiAgICAgICAgICAgIHRoaXMucmVnaXN0ZXJDaGFuZ2VJbkV4ZXJjaXNlSGludHMoKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVW5zdWJzY3JpYmUgZnJvbSBzdWJzY3JpcHRpb25zXG4gICAgICovXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIGlmICh0aGlzLnBhcmFtU3ViKSB7XG4gICAgICAgICAgICB0aGlzLnBhcmFtU3ViLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5ldmVudE1hbmFnZXIuZGVzdHJveSh0aGlzLmV2ZW50U3Vic2NyaWJlcik7XG4gICAgICAgIHRoaXMuZGlhbG9nRXJyb3JTb3VyY2UudW5zdWJzY3JpYmUoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBMb2FkIGFsbCBleGVyY2lzZSBoaW50cyB3aXRoIHRoZSBjdXJyZW50bHkgc2VsZWN0ZWQgZXhlcmNpc2VJZCAodGFrZW4gZnJvbSByb3V0ZSBwYXJhbXMpLlxuICAgICAqL1xuICAgIGxvYWRBbGxCeUV4ZXJjaXNlSWQoKSB7XG4gICAgICAgIHRoaXMuZXhlcmNpc2VIaW50U2VydmljZVxuICAgICAgICAgICAgLmZpbmRCeUV4ZXJjaXNlSWQodGhpcy5leGVyY2lzZS5pZCEpXG4gICAgICAgICAgICAucGlwZShcbiAgICAgICAgICAgICAgICBmaWx0ZXIoKHJlczogSHR0cFJlc3BvbnNlPEV4ZXJjaXNlSGludFtdPikgPT4gcmVzLm9rKSxcbiAgICAgICAgICAgICAgICBtYXAoKHJlczogSHR0cFJlc3BvbnNlPEV4ZXJjaXNlSGludFtdPikgPT4gcmVzLmJvZHkpLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKHJlczogRXhlcmNpc2VIaW50W10pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5leGVyY2lzZUhpbnRzID0gcmVzO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbnRhaW5zQ29kZUhpbnRzID0gdGhpcy5leGVyY2lzZUhpbnRzPy5zb21lKChoaW50KSA9PiBoaW50LnR5cGUgPT09IEhpbnRUeXBlLkNPREUpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgZXJyb3I6IChyZXM6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiBvbkVycm9yKHRoaXMuYWxlcnRTZXJ2aWNlLCByZXMpLFxuICAgICAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgdHJhY2sgaWQgb2YgYW4gZXhlcmNpc2UgaGludFxuICAgICAqIEBwYXJhbSBpbmRleCBJbmRleCBvZiB0aGUgaXRlbVxuICAgICAqIEBwYXJhbSBpdGVtIEl0ZW0gZm9yIHdoaWNoIHRvIGdldCB0aGUgaWRcbiAgICAgKi9cbiAgICB0cmFja0lkKGluZGV4OiBudW1iZXIsIGl0ZW06IEV4ZXJjaXNlSGludCkge1xuICAgICAgICByZXR1cm4gaXRlbS5pZDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiAoUmUtKXN1YnNjcmliZSB0byB0aGUgZXhlcmNpc2UgaGludCBsaXN0IG1vZGlmaWNhdGlvbiBzdWJzY3JpcHRpb25cbiAgICAgKi9cbiAgICByZWdpc3RlckNoYW5nZUluRXhlcmNpc2VIaW50cygpIHtcbiAgICAgICAgaWYgKHRoaXMuZXZlbnRTdWJzY3JpYmVyKSB7XG4gICAgICAgICAgICB0aGlzLmV2ZW50U3Vic2NyaWJlci51bnN1YnNjcmliZSgpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZXZlbnRTdWJzY3JpYmVyID0gdGhpcy5ldmVudE1hbmFnZXIuc3Vic2NyaWJlKCdleGVyY2lzZUhpbnRMaXN0TW9kaWZpY2F0aW9uJywgKCkgPT4gdGhpcy5sb2FkQWxsQnlFeGVyY2lzZUlkKCkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERlbGV0ZXMgZXhlcmNpc2UgaGludFxuICAgICAqIEBwYXJhbSBleGVyY2lzZUhpbnRJZCB0aGUgaWQgb2YgdGhlIGV4ZXJjaXNlIGhpbnQgdGhhdCB3ZSB3YW50IHRvIGRlbGV0ZVxuICAgICAqL1xuICAgIGRlbGV0ZUV4ZXJjaXNlSGludChleGVyY2lzZUhpbnRJZDogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuZXhlcmNpc2VIaW50U2VydmljZS5kZWxldGUodGhpcy5leGVyY2lzZS5pZCEsIGV4ZXJjaXNlSGludElkKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuZXZlbnRNYW5hZ2VyLmJyb2FkY2FzdCh7XG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICdleGVyY2lzZUhpbnRMaXN0TW9kaWZpY2F0aW9uJyxcbiAgICAgICAgICAgICAgICAgICAgY29udGVudDogJ0RlbGV0ZWQgYW4gZXhlcmNpc2VIaW50JyxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB0aGlzLmRpYWxvZ0Vycm9yU291cmNlLm5leHQoJycpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yOiAoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiB0aGlzLmRpYWxvZ0Vycm9yU291cmNlLm5leHQoZXJyb3IubWVzc2FnZSksXG4gICAgICAgIH0pO1xuICAgIH1cbn1cbiIsIjxkaXY+XG4gICAgPGgyIGlkPVwicGFnZS1oZWFkaW5nXCI+XG4gICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZXhlcmNpc2VIaW50LmhvbWUudGl0bGVcIj5FeGVyY2lzZSBIaW50czwvc3Bhbj5cbiAgICAgICAgQGlmIChleGVyY2lzZT8ucHJvZ3JhbW1pbmdMYW5ndWFnZSA9PT0gUHJvZ3JhbW1pbmdMYW5ndWFnZS5KQVZBKSB7XG4gICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgIGlkPVwiamgtY29kZS1oaW50c1wiXG4gICAgICAgICAgICAgICAgW2NsYXNzXT1cImNvbnRhaW5zQ29kZUhpbnRzID8gJ2J0bi1zZWNvbmRhcnknIDogJ2J0bi1wcmltYXJ5J1wiXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gZmxvYXQtZW5kIGpoLWNyZWF0ZS1lbnRpdHkgY3JlYXRlLWV4ZXJjaXNlLWhpbnRcIlxuICAgICAgICAgICAgICAgIHJvdXRlckxpbms9XCJjb2RlLWhpbnQtbWFuYWdlbWVudFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQGlmIChjb250YWluc0NvZGVIaW50cykge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFXcmVuY2hcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5NYW5hZ2UgQ29kZSBIaW50czwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoIWNvbnRhaW5zQ29kZUhpbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUFycm93c1JvdGF0ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucHJvZ3JhbW1pbmdFeGVyY2lzZS5nZW5lcmF0ZUNvZGVIaW50c1RpdGxlXCI+R2VuZXJhdGUgQ29kZSBIaW50czwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9hPlxuICAgICAgICB9XG4gICAgICAgIDxhIGlkPVwiamgtY3JlYXRlLWVudGl0eVwiIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGZsb2F0LWVuZCBqaC1jcmVhdGUtZW50aXR5IGNyZWF0ZS1leGVyY2lzZS1oaW50IG14LTJcIiByb3V0ZXJMaW5rPVwibmV3XCI+XG4gICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVBsdXNcIj48L2ZhLWljb24+XG4gICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmV4ZXJjaXNlSGludC5ob21lLmNyZWF0ZUxhYmVsXCI+IENyZWF0ZSBuZXcgRXhlcmNpc2UgSGludCA8L3NwYW4+XG4gICAgICAgIDwvYT5cbiAgICA8L2gyPlxuICAgIDxiciAvPlxuICAgIEBpZiAoZXhlcmNpc2VIaW50cz8ubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJhbGVydCBhbGVydC13YXJuaW5nXCI+XG4gICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmV4ZXJjaXNlSGludC5ob21lLm5vdEZvdW5kXCI+Tm8gZXhlcmNpc2VIaW50cyBmb3VuZDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuICAgIEBpZiAoZXhlcmNpc2VIaW50cyAmJiBleGVyY2lzZUhpbnRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cInRhYmxlLXJlc3BvbnNpdmVcIj5cbiAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlIHRhYmxlLXN0cmlwZWRcIj5cbiAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD48c3BhbiBqaGlUcmFuc2xhdGU9XCJnbG9iYWwuZmllbGQuaWRcIj5JRDwvc3Bhbj48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoPjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZXhlcmNpc2VIaW50LnRpdGxlXCI+VGl0bGU8L3NwYW4+PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD48c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmV4ZXJjaXNlSGludC5jb250ZW50XCI+Q29udGVudDwvc3Bhbj48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoPjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZXhlcmNpc2VIaW50LmV4ZXJjaXNlXCI+RXhlcmNpc2U8L3NwYW4+PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD48L3RoPlxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAgICBAZm9yIChleGVyY2lzZUhpbnQgb2YgZXhlcmNpc2VIaW50czsgdHJhY2sgdHJhY2tJZCgkaW5kZXgsIGV4ZXJjaXNlSGludCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIFtyb3V0ZXJMaW5rXT1cIltleGVyY2lzZUhpbnQuaWRdXCI+e3sgZXhlcmNpc2VIaW50LmlkIH19PC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBleGVyY2lzZUhpbnQudGl0bGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2VIaW50LnR5cGUgPT09IEhpbnRUeXBlLkNPREUgJiYgZXhlcmNpc2VIaW50LmV4ZXJjaXNlPy50eXBlID09PSBFeGVyY2lzZVR5cGUuUFJPR1JBTU1JTkcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctaW5mb1wiPjxmYS1pY29uIFtpY29uXT1cImZhQ29kZVwiPjwvZmEtaWNvbj4ge3sgJ2FydGVtaXNBcHAuY29kZUhpbnQudHlwZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2VIaW50LnR5cGUgPT09IEhpbnRUeXBlLlRFWFQgJiYgZXhlcmNpc2VIaW50LmV4ZXJjaXNlPy50eXBlID09PSBFeGVyY2lzZVR5cGUuUFJPR1JBTU1JTkcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctaW5mb1wiPjxmYS1pY29uIFtpY29uXT1cImZhVGV4dFwiPjwvZmEtaWNvbj4ge3sgJ2FydGVtaXNBcHAuZXhlcmNpc2VIaW50LnRleHRIaW50JyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIFtpbm5lckhUTUxdPVwiZXhlcmNpc2VIaW50LmNvbnRlbnQgfCBodG1sRm9yTWFya2Rvd25cIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGV4ZXJjaXNlSGludC50eXBlID09PSBIaW50VHlwZS5DT0RFKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAoZXhlcmNpc2VIaW50IHwgY2FzdFRvQ29kZUhpbnQpLnNvbHV0aW9uRW50cmllcz8ubGVuZ3RoID8/IDAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICgoZXhlcmNpc2VIaW50IHwgY2FzdFRvQ29kZUhpbnQpLnNvbHV0aW9uRW50cmllcz8ubGVuZ3RoID09PSAxID8gJ2FydGVtaXNBcHAuY29kZUhpbnQuZW50cnknIDogJ2FydGVtaXNBcHAuY29kZUhpbnQuZW50cmllcycpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfCBhcnRlbWlzVHJhbnNsYXRlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgZXhlcmNpc2VIaW50LmV4ZXJjaXNlPy5pZCB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cInRleHQtZW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJidG4tZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIFtyb3V0ZXJMaW5rXT1cIltleGVyY2lzZUhpbnQuaWRdXCIgY2xhc3M9XCJidG4gYnRuLWluZm8gYnRuLXNtIG1lLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUV5ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImQtbm9uZSBkLW1kLWlubGluZVwiIGpoaVRyYW5zbGF0ZT1cImVudGl0eS5hY3Rpb24udmlld1wiPlZpZXc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBbcm91dGVyTGlua109XCJbZXhlcmNpc2VIaW50LmlkLCAnZWRpdCddXCIgY2xhc3M9XCJidG4gYnRuLXdhcm5pbmcgYnRuLXNtIG1lLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVdyZW5jaFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImQtbm9uZSBkLW1kLWlubGluZVwiIGpoaVRyYW5zbGF0ZT1cImVudGl0eS5hY3Rpb24uZWRpdFwiPkVkaXQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamhpRGVsZXRlQnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2VudGl0eVRpdGxlXT1cImV4ZXJjaXNlSGludC50aXRsZSFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZVF1ZXN0aW9uPVwiYXJ0ZW1pc0FwcC5leGVyY2lzZUhpbnQuZGVsZXRlLnF1ZXN0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZGVsZXRlKT1cImRlbGV0ZUV4ZXJjaXNlSGludChleGVyY2lzZUhpbnQuaWQhKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2RpYWxvZ0Vycm9yXT1cImRpYWxvZ0Vycm9yJFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFUaW1lc1wiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG48L2Rpdj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25EZXN0cm95LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuXG5pbXBvcnQgeyBmYVdyZW5jaCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBFeGVyY2lzZUhpbnQsIEhpbnRUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2hlc3RpYS9leGVyY2lzZS1oaW50Lm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktZXhlcmNpc2UtaGludC1kZXRhaWwnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9leGVyY2lzZS1oaW50LWRldGFpbC5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIEV4ZXJjaXNlSGludERldGFpbENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcbiAgICByZWFkb25seSBIaW50VHlwZSA9IEhpbnRUeXBlO1xuXG4gICAgZXhlcmNpc2VIaW50OiBFeGVyY2lzZUhpbnQ7XG5cbiAgICBjb3Vyc2VJZDogbnVtYmVyO1xuICAgIGV4ZXJjaXNlSWQ6IG51bWJlcjtcblxuICAgIHBhcmFtU3ViOiBTdWJzY3JpcHRpb247XG5cbiAgICAvLyBJY29uc1xuICAgIGZhV3JlbmNoID0gZmFXcmVuY2g7XG5cbiAgICBjb25zdHJ1Y3Rvcihwcm90ZWN0ZWQgcm91dGU6IEFjdGl2YXRlZFJvdXRlKSB7fVxuXG4gICAgLyoqXG4gICAgICogRXh0cmFjdHMgdGhlIGNvdXJzZSBhbmQgZXhlcmNpc2UgaWQgYW5kIHRoZSBleGVyY2lzZSBoaW50IGZyb20gdGhlIHJvdXRlIHBhcmFtc1xuICAgICAqL1xuICAgIG5nT25Jbml0KCkge1xuICAgICAgICB0aGlzLnBhcmFtU3ViID0gdGhpcy5yb3V0ZS5wYXJhbXMuc3Vic2NyaWJlKChwYXJhbXMpID0+IHtcbiAgICAgICAgICAgIHRoaXMuY291cnNlSWQgPSBwYXJhbXNbJ2NvdXJzZUlkJ107XG4gICAgICAgICAgICB0aGlzLmV4ZXJjaXNlSWQgPSBwYXJhbXNbJ2V4ZXJjaXNlSWQnXTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMucm91dGUuZGF0YS5zdWJzY3JpYmUoKHsgZXhlcmNpc2VIaW50IH0pID0+IHtcbiAgICAgICAgICAgIHRoaXMuZXhlcmNpc2VIaW50ID0gZXhlcmNpc2VIaW50O1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVbnN1YnNjcmliZXMgZnJvbSB0aGUgcGFyYW0gc3Vic2NyaXB0aW9uXG4gICAgICovXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgICAgIGlmICh0aGlzLnBhcmFtU3ViKSB7XG4gICAgICAgICAgICB0aGlzLnBhcmFtU3ViLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwicm93IGp1c3RpZnktY29udGVudC1jZW50ZXJcIj5cbiAgICA8ZGl2IGNsYXNzPVwiY29sLW1kLThcIj5cbiAgICAgICAgQGlmIChleGVyY2lzZUhpbnQpIHtcbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgyPjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZXhlcmNpc2VIaW50LmRldGFpbC50aXRsZVwiPkV4ZXJjaXNlIEhpbnQ8L3NwYW4+IHt7IGV4ZXJjaXNlSGludC5pZCB9fTwvaDI+XG4gICAgICAgICAgICAgICAgPGhyIC8+XG4gICAgICAgICAgICAgICAgPGRsIGNsYXNzPVwicm93LW1kIGpoLWVudGl0eS1kZXRhaWxzXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdD48c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmV4ZXJjaXNlSGludC50aXRsZVwiPlRpdGxlPC9zcGFuPjwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGV4ZXJjaXNlSGludC50aXRsZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZXhlcmNpc2VIaW50LmRlc2NyaXB0aW9uXCI+RGVzY3JpcHRpb248L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgZXhlcmNpc2VIaW50LmRlc2NyaXB0aW9uIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgICAgICA8ZHQ+PHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5leGVyY2lzZUhpbnQudGFza1wiPkNvbnRlbnQ8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgZXhlcmNpc2VIaW50Py5wcm9ncmFtbWluZ0V4ZXJjaXNlVGFzaz8udGFza05hbWUgPz8gJy0nIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgICAgICA8ZHQ+PHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5leGVyY2lzZUhpbnQuY29udGVudFwiPkNvbnRlbnQ8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChleGVyY2lzZUhpbnQuY29udGVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIFtpbm5lckhUTUxdPVwiZXhlcmNpc2VIaW50LmNvbnRlbnQgfCBodG1sRm9yTWFya2Rvd25cIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2VIaW50LnR5cGUgPT09IEhpbnRUeXBlLkNPREUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLWNvZGUtaGludC1jb250YWluZXIgW2NvZGVIaW50XT1cImV4ZXJjaXNlSGludCB8IGNhc3RUb0NvZGVIaW50XCI+PC9qaGktY29kZS1oaW50LWNvbnRhaW5lcj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZXhlcmNpc2VIaW50LmV4ZXJjaXNlXCI+RXhlcmNpc2U8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChleGVyY2lzZUhpbnQuZXhlcmNpc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBbcm91dGVyTGlua109XCJbJy9jb3Vyc2UtbWFuYWdlbWVudCcsIGNvdXJzZUlkLCBleGVyY2lzZUhpbnQuZXhlcmNpc2UudHlwZSArICctZXhlcmNpc2VzJywgZXhlcmNpc2VJZF1cIj57eyBleGVyY2lzZUhpbnQuZXhlcmNpc2U/LmlkIH19PC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgIDwvZGw+XG4gICAgICAgICAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWydlZGl0J11cIiBjbGFzcz1cImJ0biBidG4td2FybmluZ1wiPiA8ZmEtaWNvbiBbaWNvbl09XCJmYVdyZW5jaFwiPjwvZmEtaWNvbj4mbmJzcDs8c3BhbiBqaGlUcmFuc2xhdGU9XCJlbnRpdHkuYWN0aW9uLmVkaXRcIj4gRWRpdDwvc3Bhbj4gPC9hPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkRlc3Ryb3ksIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgU3Vic2NyaXB0aW9uLCBmaWx0ZXIsIHN3aXRjaE1hcCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgQWxlcnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvdXRpbC9hbGVydC5zZXJ2aWNlJztcbmltcG9ydCB7IEV4ZXJjaXNlSGludFNlcnZpY2UgfSBmcm9tICcuLi9zaGFyZWQvZXhlcmNpc2UtaGludC5zZXJ2aWNlJztcbmltcG9ydCB7IEVkaXRvck1vZGUsIE1hcmtkb3duRWRpdG9ySGVpZ2h0IH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvbWFya2Rvd24tZWRpdG9yLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBLYXRleENvbW1hbmQgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9rYXRleC5jb21tYW5kJztcbmltcG9ydCB7IEFydGVtaXNOYXZpZ2F0aW9uVXRpbFNlcnZpY2UgfSBmcm9tICdhcHAvdXRpbHMvbmF2aWdhdGlvbi51dGlscyc7XG5pbXBvcnQgeyBmYUJhbiwgZmFDaXJjbGVOb3RjaCwgZmFTYXZlIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IEV4ZXJjaXNlSGludCwgSGludFR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvaGVzdGlhL2V4ZXJjaXNlLWhpbnQubW9kZWwnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZVNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL21hbmFnZS9zZXJ2aWNlcy9wcm9ncmFtbWluZy1leGVyY2lzZS5zZXJ2aWNlJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2VTb2x1dGlvbkVudHJ5IH0gZnJvbSAnYXBwL2VudGl0aWVzL2hlc3RpYS9wcm9ncmFtbWluZy1leGVyY2lzZS1zb2x1dGlvbi1lbnRyeS5tb2RlbCc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3Byb2dyYW1taW5nLWV4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2VTZXJ2ZXJTaWRlVGFzayB9IGZyb20gJ2FwcC9lbnRpdGllcy9oZXN0aWEvcHJvZ3JhbW1pbmctZXhlcmNpc2UtdGFzay5tb2RlbCc7XG5pbXBvcnQgeyBNYW51YWxTb2x1dGlvbkVudHJ5Q3JlYXRpb25Nb2RhbENvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvaGVzdGlhL2dlbmVyYXRpb24tb3ZlcnZpZXcvbWFudWFsLXNvbHV0aW9uLWVudHJ5LWNyZWF0aW9uLW1vZGFsL21hbnVhbC1zb2x1dGlvbi1lbnRyeS1jcmVhdGlvbi1tb2RhbC5jb21wb25lbnQnO1xuaW1wb3J0IHsgTmdiTW9kYWwsIE5nYk1vZGFsUmVmIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xuaW1wb3J0IHsgQ29kZUhpbnQgfSBmcm9tICdhcHAvZW50aXRpZXMvaGVzdGlhL2NvZGUtaGludC1tb2RlbCc7XG5pbXBvcnQgeyBDb2RlSGludFNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oaW50L3NlcnZpY2VzL2NvZGUtaGludC5zZXJ2aWNlJztcbmltcG9ydCB7IG9uRXJyb3IgfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvZ2xvYmFsLnV0aWxzJztcbmltcG9ydCB7IElyaXNTZXR0aW5nc1NlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9zZXR0aW5ncy9zaGFyZWQvaXJpcy1zZXR0aW5ncy5zZXJ2aWNlJztcbmltcG9ydCB7IElyaXNTZXR0aW5ncyB9IGZyb20gJ2FwcC9lbnRpdGllcy9pcmlzL3NldHRpbmdzL2lyaXMtc2V0dGluZ3MubW9kZWwnO1xuaW1wb3J0IHsgUHJvZmlsZVNlcnZpY2UgfSBmcm9tICdhcHAvc2hhcmVkL2xheW91dHMvcHJvZmlsZXMvcHJvZmlsZS5zZXJ2aWNlJztcblxuY29uc3QgREVGQVVMVF9ESVNQTEFZX1RIUkVTSE9MRCA9IDM7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWV4ZXJjaXNlLWhpbnQtdXBkYXRlJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vZXhlcmNpc2UtaGludC11cGRhdGUuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL2V4ZXJjaXNlLWhpbnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBFeGVyY2lzZUhpbnRVcGRhdGVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gICAgTWFya2Rvd25FZGl0b3JIZWlnaHQgPSBNYXJrZG93bkVkaXRvckhlaWdodDtcblxuICAgIGNvdXJzZUlkOiBudW1iZXI7XG4gICAgZXhlcmNpc2U6IFByb2dyYW1taW5nRXhlcmNpc2U7XG4gICAgcmVhZG9ubHkgSGludFR5cGUgPSBIaW50VHlwZTtcbiAgICBleGVyY2lzZUhpbnQgPSBuZXcgRXhlcmNpc2VIaW50KCk7XG4gICAgc29sdXRpb25FbnRyaWVzOiBQcm9ncmFtbWluZ0V4ZXJjaXNlU29sdXRpb25FbnRyeVtdO1xuXG4gICAgcHJvZ3JhbW1pbmdFeGVyY2lzZTogUHJvZ3JhbW1pbmdFeGVyY2lzZTtcbiAgICB0YXNrczogUHJvZ3JhbW1pbmdFeGVyY2lzZVNlcnZlclNpZGVUYXNrW107XG4gICAgaXJpc1NldHRpbmdzPzogSXJpc1NldHRpbmdzO1xuXG4gICAgaXNTYXZpbmc6IGJvb2xlYW47XG4gICAgaXNHZW5lcmF0aW5nRGVzY3JpcHRpb246IGJvb2xlYW47XG4gICAgcGFyYW1TdWI6IFN1YnNjcmlwdGlvbjtcblxuICAgIGRvbWFpbkNvbW1hbmRzID0gW25ldyBLYXRleENvbW1hbmQoKV07XG4gICAgZWRpdG9yTW9kZSA9IEVkaXRvck1vZGUuTEFURVg7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhQ2lyY2xlTm90Y2ggPSBmYUNpcmNsZU5vdGNoO1xuICAgIGZhQmFuID0gZmFCYW47XG4gICAgZmFTYXZlID0gZmFTYXZlO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgICAgICBwcm90ZWN0ZWQgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgbW9kYWxTZXJ2aWNlOiBOZ2JNb2RhbCxcbiAgICAgICAgcHJvdGVjdGVkIGNvZGVIaW50U2VydmljZTogQ29kZUhpbnRTZXJ2aWNlLFxuICAgICAgICBwcm90ZWN0ZWQgZXhlcmNpc2VIaW50U2VydmljZTogRXhlcmNpc2VIaW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBwcm9ncmFtbWluZ0V4ZXJjaXNlU2VydmljZTogUHJvZ3JhbW1pbmdFeGVyY2lzZVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgbmF2aWdhdGlvblV0aWxTZXJ2aWNlOiBBcnRlbWlzTmF2aWdhdGlvblV0aWxTZXJ2aWNlLFxuICAgICAgICBwcm90ZWN0ZWQgaXJpc1NldHRpbmdzU2VydmljZTogSXJpc1NldHRpbmdzU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBwcm9maWxlU2VydmljZTogUHJvZmlsZVNlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogRmV0Y2hlcyB0aGUgZXhlcmNpc2UgZnJvbSB0aGUgc2VydmVyIGFuZCBhc3NpZ25zIGl0IG9uIHRoZSBleGVyY2lzZSBoaW50XG4gICAgICovXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMucGFyYW1TdWIgPSB0aGlzLnJvdXRlLnBhcmFtcy5zdWJzY3JpYmUoKHBhcmFtcykgPT4ge1xuICAgICAgICAgICAgdGhpcy5jb3Vyc2VJZCA9IHBhcmFtc1snY291cnNlSWQnXTtcbiAgICAgICAgICAgIHRoaXMuaXNTYXZpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgIHRoaXMuaXNHZW5lcmF0aW5nRGVzY3JpcHRpb24gPSBmYWxzZTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMucm91dGUuZGF0YS5zdWJzY3JpYmUoKHsgZXhlcmNpc2VIaW50LCBleGVyY2lzZSB9KSA9PiB7XG4gICAgICAgICAgICB0aGlzLmV4ZXJjaXNlID0gZXhlcmNpc2U7XG4gICAgICAgICAgICBleGVyY2lzZUhpbnQuZXhlcmNpc2UgPSBleGVyY2lzZTtcbiAgICAgICAgICAgIHRoaXMuZXhlcmNpc2VIaW50ID0gZXhlcmNpc2VIaW50O1xuICAgICAgICAgICAgdGhpcy5leGVyY2lzZUhpbnQuZGlzcGxheVRocmVzaG9sZCA9IHRoaXMuZXhlcmNpc2VIaW50LmRpc3BsYXlUaHJlc2hvbGQgPz8gREVGQVVMVF9ESVNQTEFZX1RIUkVTSE9MRDtcblxuICAgICAgICAgICAgdGhpcy5wcm9ncmFtbWluZ0V4ZXJjaXNlU2VydmljZS5nZXRUYXNrc0FuZFRlc3RzRXh0cmFjdGVkRnJvbVByb2JsZW1TdGF0ZW1lbnQodGhpcy5leGVyY2lzZS5pZCEpLnN1YnNjcmliZSgodGFza3MpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnRhc2tzID0gdGFza3M7XG5cbiAgICAgICAgICAgICAgICBjb25zdCBzZWxlY3RlZFRhc2sgPSB0aGlzLnRhc2tzLmZpbmQoKHRhc2spID0+IHRhc2suaWQgPT09IHRoaXMuZXhlcmNpc2VIaW50LnByb2dyYW1taW5nRXhlcmNpc2VUYXNrPy5pZCk7XG4gICAgICAgICAgICAgICAgaWYgKHNlbGVjdGVkVGFzaykge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmV4ZXJjaXNlSGludC5wcm9ncmFtbWluZ0V4ZXJjaXNlVGFzayA9IHNlbGVjdGVkVGFzaztcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRhc2tzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmV4ZXJjaXNlSGludC5wcm9ncmFtbWluZ0V4ZXJjaXNlVGFzayA9IHRoaXMudGFza3NbMF07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHRoaXMucHJvZmlsZVNlcnZpY2VcbiAgICAgICAgICAgICAgICAuZ2V0UHJvZmlsZUluZm8oKVxuICAgICAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXIoKHByb2ZpbGVJbmZvKSA9PiBwcm9maWxlSW5mbz8uYWN0aXZlUHJvZmlsZXM/LmluY2x1ZGVzKCdpcmlzJykpLFxuICAgICAgICAgICAgICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5pcmlzU2V0dGluZ3NTZXJ2aWNlLmdldENvbWJpbmVkUHJvZ3JhbW1pbmdFeGVyY2lzZVNldHRpbmdzKHRoaXMuZXhlcmNpc2UuaWQhKSksXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIC5zdWJzY3JpYmUoKHNldHRpbmdzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXJpc1NldHRpbmdzID0gc2V0dGluZ3M7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIG9wZW5NYW51YWxFbnRyeUNyZWF0aW9uTW9kYWwoKSB7XG4gICAgICAgIGNvbnN0IGNvZGVIaW50ID0gdGhpcy5leGVyY2lzZUhpbnQgYXMgQ29kZUhpbnQ7XG4gICAgICAgIGNvbnN0IHRlc3RDYXNlc0ZvckN1cnJlbnRUYXNrID0gY29kZUhpbnQucHJvZ3JhbW1pbmdFeGVyY2lzZVRhc2s/LnRlc3RDYXNlcyA/PyBbXTtcbiAgICAgICAgY29uc3QgbW9kYWxSZWY6IE5nYk1vZGFsUmVmID0gdGhpcy5tb2RhbFNlcnZpY2Uub3BlbihNYW51YWxTb2x1dGlvbkVudHJ5Q3JlYXRpb25Nb2RhbENvbXBvbmVudCBhcyBDb21wb25lbnQsIHsgc2l6ZTogJ2xnJywgYmFja2Ryb3A6ICdzdGF0aWMnIH0pO1xuICAgICAgICBtb2RhbFJlZi5jb21wb25lbnRJbnN0YW5jZS5leGVyY2lzZUlkID0gdGhpcy5leGVyY2lzZS5pZCE7XG4gICAgICAgIG1vZGFsUmVmLmNvbXBvbmVudEluc3RhbmNlLmNvZGVIaW50ID0gY29kZUhpbnQ7XG4gICAgICAgIG1vZGFsUmVmLmNvbXBvbmVudEluc3RhbmNlLnRlc3RDYXNlcyA9IHRlc3RDYXNlc0ZvckN1cnJlbnRUYXNrO1xuICAgICAgICBtb2RhbFJlZi5jb21wb25lbnRJbnN0YW5jZS5vbkVudHJ5Q3JlYXRlZC5zdWJzY3JpYmUoKGNyZWF0ZWRFbnRyeTogUHJvZ3JhbW1pbmdFeGVyY2lzZVNvbHV0aW9uRW50cnkpID0+IHtcbiAgICAgICAgICAgIGNvZGVIaW50IS5zb2x1dGlvbkVudHJpZXMhLnB1c2goY3JlYXRlZEVudHJ5KTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVW5zdWJzY3JpYmVzIGZyb20gdGhlIHBhcmFtIHN1YnNjcmlwdGlvblxuICAgICAqL1xuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgICAgICBpZiAodGhpcy5wYXJhbVN1Yikge1xuICAgICAgICAgICAgdGhpcy5wYXJhbVN1Yi51bnN1YnNjcmliZSgpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2V0dGVyIHRvIHVwZGF0ZSB0aGUgZXhlcmNpc2UgaGludCBjb250ZW50XG4gICAgICogQHBhcmFtIG5ld0NvbnRlbnQgTmV3IHZhbHVlIHRvIHNldFxuICAgICAqL1xuICAgIHVwZGF0ZUhpbnRDb250ZW50KG5ld0NvbnRlbnQ6IHN0cmluZykge1xuICAgICAgICB0aGlzLmV4ZXJjaXNlSGludC5jb250ZW50ID0gbmV3Q29udGVudDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBOYXZpZ2F0ZSB0byB0aGUgcHJldmlvdXMgcGFnZSB3aGVuIHRoZSB1c2VyIGNhbmNlbHMgdGhlIHVwZGF0ZSBwcm9jZXNzXG4gICAgICogUmV0dXJucyB0byB0aGUgZGV0YWlsIHBhZ2UgaWYgdGhlcmUgaXMgbm8gcHJldmlvdXMgc3RhdGUgYW5kIHdlIGVkaXRlZCBhbiBleGlzdGluZyBoaW50XG4gICAgICogUmV0dXJucyB0byB0aGUgb3ZlcnZpZXcgcGFnZSBpZiB0aGVyZSBpcyBubyBwcmV2aW91cyBzdGF0ZSBhbmQgd2UgY3JlYXRlZCBhIG5ldyBoaW50XG4gICAgICovXG4gICAgcHJldmlvdXNTdGF0ZSgpIHtcbiAgICAgICAgdGhpcy5uYXZpZ2F0aW9uVXRpbFNlcnZpY2UubmF2aWdhdGVCYWNrV2l0aE9wdGlvbmFsKFxuICAgICAgICAgICAgWydjb3Vyc2UtbWFuYWdlbWVudCcsIHRoaXMuY291cnNlSWQudG9TdHJpbmcoKSwgJ3Byb2dyYW1taW5nLWV4ZXJjaXNlcycsIHRoaXMuZXhlcmNpc2UuaWQhLnRvU3RyaW5nKCksICdoaW50cyddLFxuICAgICAgICAgICAgdGhpcy5leGVyY2lzZUhpbnQuaWQ/LnRvU3RyaW5nKCksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2F2ZXMgdGhlIGV4ZXJjaXNlIGhpbnQgYnkgY3JlYXRpbmcgb3IgdXBkYXRpbmcgaXQgb24gdGhlIHNlcnZlclxuICAgICAqL1xuICAgIHNhdmUoKSB7XG4gICAgICAgIHRoaXMuaXNTYXZpbmcgPSB0cnVlO1xuICAgICAgICBpZiAodGhpcy5leGVyY2lzZUhpbnQuaWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhpcy5zdWJzY3JpYmVUb1NhdmVSZXNwb25zZSh0aGlzLmV4ZXJjaXNlSGludFNlcnZpY2UudXBkYXRlKHRoaXMuZXhlcmNpc2UuaWQhLCB0aGlzLmV4ZXJjaXNlSGludCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5zdWJzY3JpYmVUb1NhdmVSZXNwb25zZSh0aGlzLmV4ZXJjaXNlSGludFNlcnZpY2UuY3JlYXRlKHRoaXMuZXhlcmNpc2UuaWQhLCB0aGlzLmV4ZXJjaXNlSGludCkpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZ2VuZXJhdGVEZXNjcmlwdGlvbkZvckNvZGVIaW50KCkge1xuICAgICAgICB0aGlzLmlzR2VuZXJhdGluZ0Rlc2NyaXB0aW9uID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5jb2RlSGludFNlcnZpY2UuZ2VuZXJhdGVEZXNjcmlwdGlvbkZvckNvZGVIaW50KHRoaXMuZXhlcmNpc2UuaWQhLCB0aGlzLmV4ZXJjaXNlSGludC5pZCEpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmV4ZXJjaXNlSGludC5kZXNjcmlwdGlvbiA9IHJlc3BvbnNlLmJvZHkhLmRlc2NyaXB0aW9uO1xuICAgICAgICAgICAgICAgIHRoaXMuZXhlcmNpc2VIaW50LmNvbnRlbnQgPSByZXNwb25zZS5ib2R5IS5jb250ZW50O1xuICAgICAgICAgICAgICAgIHRoaXMuaXNHZW5lcmF0aW5nRGVzY3JpcHRpb24gPSBmYWxzZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogKGVycm9yKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5pc0dlbmVyYXRpbmdEZXNjcmlwdGlvbiA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIG9uRXJyb3IodGhpcy5hbGVydFNlcnZpY2UsIGVycm9yKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBzdWJzY3JpYmVUb1NhdmVSZXNwb25zZShyZXN1bHQ6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPEV4ZXJjaXNlSGludD4+KSB7XG4gICAgICAgIHJlc3VsdC5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKCkgPT4gdGhpcy5vblNhdmVTdWNjZXNzKCksXG4gICAgICAgICAgICBlcnJvcjogKCkgPT4gdGhpcy5vblNhdmVFcnJvcigpLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgb25TYXZlU3VjY2VzcygpIHtcbiAgICAgICAgdGhpcy5pc1NhdmluZyA9IGZhbHNlO1xuICAgICAgICB0aGlzLnByZXZpb3VzU3RhdGUoKTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgb25TYXZlRXJyb3IoKSB7XG4gICAgICAgIHRoaXMuaXNTYXZpbmcgPSBmYWxzZTtcbiAgICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwicm93IGp1c3RpZnktY29udGVudC1jZW50ZXJcIj5cbiAgICA8ZGl2IGNsYXNzPVwiY29sLW1kLThcIj5cbiAgICAgICAgPGZvcm0gbmFtZT1cImVkaXRGb3JtXCIgcm9sZT1cImZvcm1cIiBub3ZhbGlkYXRlIChuZ1N1Ym1pdCk9XCJzYXZlKClcIiAjaGludEZvcm09XCJuZ0Zvcm1cIj5cbiAgICAgICAgICAgIDxoMiBpZD1cImpoaS1leGVyY2lzZS1oaW50LWhlYWRpbmdcIiBbamhpVHJhbnNsYXRlXT1cIidhcnRlbWlzQXBwLmV4ZXJjaXNlSGludC5ob21lLicgKyAodGhpcy5leGVyY2lzZUhpbnQuaWQgPyAnZWRpdExhYmVsJyA6ICdjcmVhdGVMYWJlbCcpXCI+XG4gICAgICAgICAgICAgICAgQ3JlYXRlIG9yIGVkaXQgYSBFeGVyY2lzZSBIaW50XG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiIFtoaWRkZW5dPVwiIWV4ZXJjaXNlSGludD8uaWRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cImlkXCIgamhpVHJhbnNsYXRlPVwiZ2xvYmFsLmZpZWxkLmlkXCI+SUQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBjbGFzcz1cImZvcm0tY29udHJvbFwiIGlkPVwiaWRcIiBuYW1lPVwiaWRcIiByZWFkb25seSBbKG5nTW9kZWwpXT1cImV4ZXJjaXNlSGludC5pZFwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1jb250cm9sLWxhYmVsXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5leGVyY2lzZUhpbnQudGl0bGVcIiBmb3I9XCJmaWVsZF90aXRsZVwiPlRpdGxlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcmVxdWlyZWQgbWlubGVuZ3RoPVwiM1wiIGNsYXNzPVwiZm9ybS1jb250cm9sXCIgbmFtZT1cInRpdGxlXCIgaWQ9XCJmaWVsZF90aXRsZVwiIFsobmdNb2RlbCldPVwiZXhlcmNpc2VIaW50LnRpdGxlXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwibGFiZWwtbmFycm93XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5leGVyY2lzZUhpbnQuZGVzY3JpcHRpb25cIiBmb3I9XCJmaWVsZF9kZXNjcmlwdGlvblwiPkRlc2NyaXB0aW9uPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktaGVscC1pY29uIHRleHQ9XCJhcnRlbWlzQXBwLmV4ZXJjaXNlSGludC5kZXNjcmlwdGlvblRvb2x0aXBcIj48L2poaS1oZWxwLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiByZXF1aXJlZCBtaW5sZW5ndGg9XCIzXCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiBuYW1lPVwiZGVzY3JpcHRpb25cIiBpZD1cImZpZWxkX2Rlc2NyaXB0aW9uXCIgWyhuZ01vZGVsKV09XCJleGVyY2lzZUhpbnQuZGVzY3JpcHRpb25cIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJsYWJlbC1uYXJyb3dcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmV4ZXJjaXNlSGludC50YXNrXCIgZm9yPVwiZmllbGRfdGFza1wiPlRhc2s8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChleGVyY2lzZUhpbnQudHlwZSA9PT0gJ2NvZGUnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1oZWxwLWljb24gdGV4dD1cImFydGVtaXNBcHAuZXhlcmNpc2VIaW50LnRhc2tUb29sdGlwXCI+PC9qaGktaGVscC1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzcz1cImZvcm0tc2VsZWN0XCIgcmVxdWlyZWQgbmFtZT1cInRhc2tcIiBbKG5nTW9kZWwpXT1cInRoaXMuZXhlcmNpc2VIaW50LnByb2dyYW1taW5nRXhlcmNpc2VUYXNrXCIgaWQ9XCJmaWVsZF90YXNrXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBAZm9yICh0YXNrIG9mIHRhc2tzOyB0cmFjayB0YXNrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBbbmdWYWx1ZV09XCJ0YXNrXCI+e3sgdGFzay50YXNrTmFtZSB9fTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwibGFiZWwtbmFycm93XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5leGVyY2lzZUhpbnQuZGlzcGxheVRocmVzaG9sZFwiIGZvcj1cImZpZWxkX2Rlc2NyaXB0aW9uXCI+RGlzcGxheSBUaHJlc2hvbGQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1oZWxwLWljb24gdGV4dD1cImFydGVtaXNBcHAuZXhlcmNpc2VIaW50LmRpc3BsYXlUaHJlc2hvbGRUb29sdGlwXCI+PC9qaGktaGVscC1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heD1cIjEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGlzcGxheVRocmVzaG9sZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImZpZWxkX2Rpc3BsYXlUaHJlc2hvbGRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJleGVyY2lzZUhpbnQuZGlzcGxheVRocmVzaG9sZFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgQGlmIChleGVyY2lzZUhpbnQudHlwZSA9PT0gSGludFR5cGUuQ09ERSAmJiBpcmlzU2V0dGluZ3M/LmlyaXNIZXN0aWFTZXR0aW5ncz8uZW5hYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGp1c3RpZnktY29udGVudC1lbmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktYnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJnZW5lcmF0ZURlc2NyaXB0aW9uQnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwiZ2VuZXJhdGVEZXNjcmlwdGlvbkZvckNvZGVIaW50KClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtzaG91bGRTdWJtaXRdPVwiZmFsc2VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtpc0xvYWRpbmddPVwiaXNHZW5lcmF0aW5nRGVzY3JpcHRpb25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0aXRsZV09XCInYXJ0ZW1pc0FwcC5jb2RlSGludC5tYW5hZ2VtZW50LnN0ZXA0LmlyaXMuZ2VuZXJhdGVEZXNjcmlwdGlvbi5sYWJlbCdcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0b29sdGlwXT1cIidhcnRlbWlzQXBwLmNvZGVIaW50Lm1hbmFnZW1lbnQuc3RlcDQuaXJpcy5nZW5lcmF0ZURlc2NyaXB0aW9uLnRvb2x0aXAnXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+R2VuZXJhdGUgZGVzY3JpcHRpb25cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvamhpLWJ1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwIGhpbnQtZm9ybV9fZWRpdG9yLXdyYXBwZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGpoaS1tYXJrZG93bi1lZGl0b3JcbiAgICAgICAgICAgICAgICAgICAgICAgIFttYXJrZG93bl09XCJleGVyY2lzZUhpbnQuY29udGVudFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAobWFya2Rvd25DaGFuZ2UpPVwidXBkYXRlSGludENvbnRlbnQoJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbcmVzaXphYmxlTWluSGVpZ2h0XT1cIk1hcmtkb3duRWRpdG9ySGVpZ2h0LlNNQUxMXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtyZXNpemFibGVNYXhIZWlnaHRdPVwiTWFya2Rvd25FZGl0b3JIZWlnaHQuTEFSR0VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW2RvbWFpbkNvbW1hbmRzXT1cImRvbWFpbkNvbW1hbmRzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtlZGl0b3JNb2RlXT1cImVkaXRvck1vZGVcIlxuICAgICAgICAgICAgICAgICAgICA+PC9qaGktbWFya2Rvd24tZWRpdG9yPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2VIaW50LnR5cGUgPT09IEhpbnRUeXBlLkNPREUpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXAgaGludC1mb3JtX19lZGl0b3Itd3JhcHBlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1jb2RlLWhpbnQtY29udGFpbmVyIFtjb2RlSGludF09XCJleGVyY2lzZUhpbnQgfCBjYXN0VG9Db2RlSGludFwiIFtlbmFibGVFZGl0aW5nXT1cInRydWVcIj48L2poaS1jb2RlLWhpbnQtY29udGFpbmVyPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmIChleGVyY2lzZUhpbnQudHlwZSA9PT0gSGludFR5cGUuQ09ERSkge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYnRuLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29kZUhpbnQubWFuYWdlbWVudC5zdGVwMy5jcmVhdGVNYW51YWxGcmFnbWVudEJ1dHRvbi5sYWJlbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cIm9wZW5NYW51YWxFbnRyeUNyZWF0aW9uTW9kYWwoKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ3JlYXRlIG5ldyBTb2x1dGlvbiBDb2RlIFNuaXBwZXRzXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2U/LmlkKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwIG10LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImZvcm0tY29udHJvbC1sYWJlbFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZXhlcmNpc2VIaW50LmV4ZXJjaXNlXCIgZm9yPVwiZmllbGRfZXhlcmNpc2VcIj5FeGVyY2lzZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImV4ZXJjaXNlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImZpZWxkX2V4ZXJjaXNlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbZGlzYWJsZWRdPVwidHJ1ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nTW9kZWxdPVwiZXhlcmNpc2UgJiYgZXhlcmNpc2UudGl0bGUgKyAnIChJRDogJyArIGV4ZXJjaXNlLmlkICsgJyknXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBpZD1cImNhbmNlbC1zYXZlXCIgY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeVwiIChjbGljayk9XCJwcmV2aW91c1N0YXRlKClcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFCYW5cIj48L2ZhLWljb24+Jm5ic3A7PHNwYW4gamhpVHJhbnNsYXRlPVwiZW50aXR5LmFjdGlvbi5jYW5jZWxcIj5DYW5jZWw8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgaWQ9XCJzYXZlLWVudGl0eVwiIFtkaXNhYmxlZF09XCJoaW50Rm9ybS5pbnZhbGlkIHx8IGlzU2F2aW5nIHx8ICFleGVyY2lzZS5pZFwiIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhU2F2ZVwiPjwvZmEtaWNvbj4mbmJzcDs8c3BhbiBqaGlUcmFuc2xhdGU9XCJlbnRpdHkuYWN0aW9uLnNhdmVcIj5TYXZlPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGVTbmFwc2hvdCwgUmVzb2x2ZSwgUm91dGVzIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IFVzZXJSb3V0ZUFjY2Vzc1NlcnZpY2UgfSBmcm9tICdhcHAvY29yZS9hdXRoL3VzZXItcm91dGUtYWNjZXNzLXNlcnZpY2UnO1xuaW1wb3J0IHsgb2YgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IGZpbHRlciwgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgRXhlcmNpc2VIaW50U2VydmljZSB9IGZyb20gJy4uL3NoYXJlZC9leGVyY2lzZS1oaW50LnNlcnZpY2UnO1xuaW1wb3J0IHsgRXhlcmNpc2VIaW50Q29tcG9uZW50IH0gZnJvbSAnLi9leGVyY2lzZS1oaW50LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBFeGVyY2lzZUhpbnREZXRhaWxDb21wb25lbnQgfSBmcm9tICcuL2V4ZXJjaXNlLWhpbnQtZGV0YWlsLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBFeGVyY2lzZUhpbnQgfSBmcm9tICdhcHAvZW50aXRpZXMvaGVzdGlhL2V4ZXJjaXNlLWhpbnQubW9kZWwnO1xuaW1wb3J0IHsgQXV0aG9yaXR5IH0gZnJvbSAnYXBwL3NoYXJlZC9jb25zdGFudHMvYXV0aG9yaXR5LmNvbnN0YW50cyc7XG5pbXBvcnQgeyBleGVyY2lzZVR5cGVzIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IEV4ZXJjaXNlSGludFVwZGF0ZUNvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlLWhpbnQvbWFuYWdlL2V4ZXJjaXNlLWhpbnQtdXBkYXRlLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlUmVzb2x2ZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvbWFuYWdlL3Byb2dyYW1taW5nLWV4ZXJjaXNlLW1hbmFnZW1lbnQtcm91dGluZy5tb2R1bGUnO1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIEV4ZXJjaXNlSGludFJlc29sdmUgaW1wbGVtZW50cyBSZXNvbHZlPEV4ZXJjaXNlSGludD4ge1xuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgc2VydmljZTogRXhlcmNpc2VIaW50U2VydmljZSkge31cblxuICAgIC8qKlxuICAgICAqIFJlc29sdmVzIHRoZSByb3V0ZSBpbnRvIGFuIGV4ZXJjaXNlIGhpbnQgaWQgYW5kIGZldGNoZXMgaXQgZnJvbSB0aGUgc2VydmVyXG4gICAgICogQHBhcmFtIHJvdXRlIFJvdXRlIHdoaWNoIHRvIHJlc29sdmVcbiAgICAgKi9cbiAgICByZXNvbHZlKHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZVNuYXBzaG90KSB7XG4gICAgICAgIGNvbnN0IGV4ZXJjaXNlSWQgPSByb3V0ZS5wYXJhbXNbJ2V4ZXJjaXNlSWQnXSA/IHJvdXRlLnBhcmFtc1snZXhlcmNpc2VJZCddIDogdW5kZWZpbmVkO1xuICAgICAgICBjb25zdCBoaW50SWQgPSByb3V0ZS5wYXJhbXNbJ2hpbnRJZCddID8gcm91dGUucGFyYW1zWydoaW50SWQnXSA6IHVuZGVmaW5lZDtcbiAgICAgICAgaWYgKGV4ZXJjaXNlSWQgJiYgaGludElkKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zZXJ2aWNlLmZpbmQoZXhlcmNpc2VJZCwgaGludElkKS5waXBlKFxuICAgICAgICAgICAgICAgIGZpbHRlcigocmVzcG9uc2U6IEh0dHBSZXNwb25zZTxFeGVyY2lzZUhpbnQ+KSA9PiByZXNwb25zZS5vayksXG4gICAgICAgICAgICAgICAgbWFwKChleGVyY2lzZUhpbnQ6IEh0dHBSZXNwb25zZTxFeGVyY2lzZUhpbnQ+KSA9PiBleGVyY2lzZUhpbnQuYm9keSEpLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb2YobmV3IEV4ZXJjaXNlSGludCgpKTtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBleGVyY2lzZUhpbnRSb3V0ZTogUm91dGVzID0gW1xuICAgIC4uLmV4ZXJjaXNlVHlwZXMubWFwKChleGVyY2lzZVR5cGUpID0+IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHBhdGg6ICc6Y291cnNlSWQvJyArIGV4ZXJjaXNlVHlwZSArICctZXhlcmNpc2VzLzpleGVyY2lzZUlkL2V4ZXJjaXNlLWhpbnRzL25ldycsXG4gICAgICAgICAgICBjb21wb25lbnQ6IEV4ZXJjaXNlSGludFVwZGF0ZUNvbXBvbmVudCxcbiAgICAgICAgICAgIHJlc29sdmU6IHtcbiAgICAgICAgICAgICAgICBleGVyY2lzZTogUHJvZ3JhbW1pbmdFeGVyY2lzZVJlc29sdmUsXG4gICAgICAgICAgICAgICAgZXhlcmNpc2VIaW50OiBFeGVyY2lzZUhpbnRSZXNvbHZlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICBhdXRob3JpdGllczogW0F1dGhvcml0eS5FRElUT1IsIEF1dGhvcml0eS5JTlNUUlVDVE9SLCBBdXRob3JpdHkuQURNSU5dLFxuICAgICAgICAgICAgICAgIHBhZ2VUaXRsZTogJ2FydGVtaXNBcHAuZXhlcmNpc2VIaW50LmhvbWUudGl0bGUnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGNhbkFjdGl2YXRlOiBbVXNlclJvdXRlQWNjZXNzU2VydmljZV0sXG4gICAgICAgIH07XG4gICAgfSksXG4gICAgLi4uZXhlcmNpc2VUeXBlcy5tYXAoKGV4ZXJjaXNlVHlwZSkgPT4ge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcGF0aDogJzpjb3Vyc2VJZC8nICsgZXhlcmNpc2VUeXBlICsgJy1leGVyY2lzZXMvOmV4ZXJjaXNlSWQvZXhlcmNpc2UtaGludHMvOmhpbnRJZCcsXG4gICAgICAgICAgICBjb21wb25lbnQ6IEV4ZXJjaXNlSGludERldGFpbENvbXBvbmVudCxcbiAgICAgICAgICAgIHJlc29sdmU6IHtcbiAgICAgICAgICAgICAgICBleGVyY2lzZUhpbnQ6IEV4ZXJjaXNlSGludFJlc29sdmUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgIGF1dGhvcml0aWVzOiBbQXV0aG9yaXR5LkVESVRPUiwgQXV0aG9yaXR5LklOU1RSVUNUT1IsIEF1dGhvcml0eS5BRE1JTl0sXG4gICAgICAgICAgICAgICAgcGFnZVRpdGxlOiAnYXJ0ZW1pc0FwcC5leGVyY2lzZUhpbnQuaG9tZS50aXRsZScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY2FuQWN0aXZhdGU6IFtVc2VyUm91dGVBY2Nlc3NTZXJ2aWNlXSxcbiAgICAgICAgfTtcbiAgICB9KSxcbiAgICAuLi5leGVyY2lzZVR5cGVzLm1hcCgoZXhlcmNpc2VUeXBlKSA9PiB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBwYXRoOiAnOmNvdXJzZUlkLycgKyBleGVyY2lzZVR5cGUgKyAnLWV4ZXJjaXNlcy86ZXhlcmNpc2VJZC9leGVyY2lzZS1oaW50cy86aGludElkL2VkaXQnLFxuICAgICAgICAgICAgY29tcG9uZW50OiBFeGVyY2lzZUhpbnRVcGRhdGVDb21wb25lbnQsXG4gICAgICAgICAgICByZXNvbHZlOiB7XG4gICAgICAgICAgICAgICAgZXhlcmNpc2U6IFByb2dyYW1taW5nRXhlcmNpc2VSZXNvbHZlLFxuICAgICAgICAgICAgICAgIGV4ZXJjaXNlSGludDogRXhlcmNpc2VIaW50UmVzb2x2ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgYXV0aG9yaXRpZXM6IFtBdXRob3JpdHkuRURJVE9SLCBBdXRob3JpdHkuSU5TVFJVQ1RPUiwgQXV0aG9yaXR5LkFETUlOXSxcbiAgICAgICAgICAgICAgICBwYWdlVGl0bGU6ICdhcnRlbWlzQXBwLmV4ZXJjaXNlSGludC5ob21lLnRpdGxlJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjYW5BY3RpdmF0ZTogW1VzZXJSb3V0ZUFjY2Vzc1NlcnZpY2VdLFxuICAgICAgICB9O1xuICAgIH0pLFxuICAgIC4uLmV4ZXJjaXNlVHlwZXMubWFwKChleGVyY2lzZVR5cGUpID0+IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHBhdGg6ICc6Y291cnNlSWQvJyArIGV4ZXJjaXNlVHlwZSArICctZXhlcmNpc2VzLzpleGVyY2lzZUlkL2V4ZXJjaXNlLWhpbnRzJyxcbiAgICAgICAgICAgIGNvbXBvbmVudDogRXhlcmNpc2VIaW50Q29tcG9uZW50LFxuICAgICAgICAgICAgcmVzb2x2ZToge1xuICAgICAgICAgICAgICAgIGV4ZXJjaXNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlUmVzb2x2ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgYXV0aG9yaXRpZXM6IFtBdXRob3JpdHkuRURJVE9SLCBBdXRob3JpdHkuSU5TVFJVQ1RPUiwgQXV0aG9yaXR5LkFETUlOXSxcbiAgICAgICAgICAgICAgICBwYWdlVGl0bGU6ICdhcnRlbWlzQXBwLmV4ZXJjaXNlSGludC5ob21lLnRpdGxlJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjYW5BY3RpdmF0ZTogW1VzZXJSb3V0ZUFjY2Vzc1NlcnZpY2VdLFxuICAgICAgICB9O1xuICAgIH0pLFxuXTtcbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBGb3Jtc01vZHVsZSwgUmVhY3RpdmVGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IFJvdXRlck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IGV4ZXJjaXNlSGludFJvdXRlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhlcmNpc2UtaGludC9tYW5hZ2UvZXhlcmNpc2UtaGludC5yb3V0ZSc7XG5pbXBvcnQgeyBFeGVyY2lzZUhpbnREZXRhaWxDb21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oaW50L21hbmFnZS9leGVyY2lzZS1oaW50LWRldGFpbC5jb21wb25lbnQnO1xuaW1wb3J0IHsgRXhlcmNpc2VIaW50VXBkYXRlQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhlcmNpc2UtaGludC9tYW5hZ2UvZXhlcmNpc2UtaGludC11cGRhdGUuY29tcG9uZW50JztcbmltcG9ydCB7IEV4ZXJjaXNlSGludENvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlLWhpbnQvbWFuYWdlL2V4ZXJjaXNlLWhpbnQuY29tcG9uZW50JztcbmltcG9ydCB7IEFydGVtaXNFeGVyY2lzZUhpbnRTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oaW50L3NoYXJlZC9leGVyY2lzZS1oaW50LXNoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc01hcmtkb3duTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc01hcmtkb3duRWRpdG9yTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvbWFya2Rvd24tZWRpdG9yLm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL3NoYXJlZC1jb21wb25lbnQubW9kdWxlJztcblxuY29uc3QgRU5USVRZX1NUQVRFUyA9IFsuLi5leGVyY2lzZUhpbnRSb3V0ZV07XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW1xuICAgICAgICBBcnRlbWlzU2hhcmVkTW9kdWxlLFxuICAgICAgICBSb3V0ZXJNb2R1bGUuZm9yQ2hpbGQoRU5USVRZX1NUQVRFUyksXG4gICAgICAgIEZvcm1zTW9kdWxlLFxuICAgICAgICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxuICAgICAgICBBcnRlbWlzTWFya2Rvd25Nb2R1bGUsXG4gICAgICAgIEFydGVtaXNNYXJrZG93bkVkaXRvck1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc0V4ZXJjaXNlSGludFNoYXJlZE1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc0V4ZXJjaXNlSGludFNoYXJlZE1vZHVsZSxcbiAgICBdLFxuICAgIGRlY2xhcmF0aW9uczogW0V4ZXJjaXNlSGludENvbXBvbmVudCwgRXhlcmNpc2VIaW50RGV0YWlsQ29tcG9uZW50LCBFeGVyY2lzZUhpbnRVcGRhdGVDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBBcnRlbWlzRXhlcmNpc2VIaW50TWFuYWdlbWVudE1vZHVsZSB7fVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsaUJBQW9DO0FBQzdDLFNBQVMsc0JBQXNCO0FBRS9CLFNBQVMsZUFBNkI7QUFDdEMsU0FBUyxRQUFRLFdBQVc7QUFNNUIsU0FBUyxnQkFBZ0IsUUFBUSxPQUFPLFFBQVEsUUFBUSxTQUFTLGdCQUFnQjs7Ozs7O0FDQzdELElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx1QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxHQUFBLG1CQUFBO0FBQWlCLElBQUEsMEJBQUE7QUFDM0IsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxvQkFBQTs7OztBQUhpQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFFBQUEsT0FBQSxRQUFBOzs7OztBQUtiLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx1QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLENBQUE7QUFBMkUsSUFBQSxvQkFBQSxHQUFBLHFCQUFBO0FBQW1CLElBQUEsMEJBQUE7QUFDbEcsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxvQkFBQTs7OztBQUhpQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFFBQUEsT0FBQSxjQUFBOzs7OztBQWRyQixJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxDQUFBO0FBTUksSUFBQSxvQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLDREQUFBLEdBQUEsQ0FBQSxFQUtDLEdBQUEsNERBQUEsR0FBQSxDQUFBO0FBT0wsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxZQUFBOzs7O0FBakJRLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsT0FBQSxvQkFBQSxrQkFBQSxhQUFBO0FBSUEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLE9BQUEsb0JBQUEsSUFBQSxFQUFBO0FBTUEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLENBQUEsT0FBQSxvQkFBQSxJQUFBLEVBQUE7Ozs7O0FBZVIsSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUEyRCxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBc0IsSUFBQSwwQkFBQTtBQUNyRixJQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsUUFBQTs7Ozs7QUF1QmdDLElBQUEsb0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEIsSUFBQSx1QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUFvQyxJQUFBLG9CQUFBLENBQUE7O0FBQW1ELElBQUEsMEJBQUE7QUFDdkgsSUFBQSxvQkFBQSxHQUFBLG9DQUFBOzs7O0FBRHlDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsUUFBQSxRQUFBLE1BQUE7QUFBMkIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLHlCQUFBLEdBQUEsR0FBQSwwQkFBQSxHQUFBLEVBQUE7Ozs7O0FBR2hFLElBQUEsb0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEIsSUFBQSx1QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUFvQyxJQUFBLG9CQUFBLENBQUE7O0FBQTJELElBQUEsMEJBQUE7QUFDL0gsSUFBQSxvQkFBQSxHQUFBLG9DQUFBOzs7O0FBRHlDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsUUFBQSxRQUFBLE1BQUE7QUFBMkIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLHlCQUFBLEdBQUEsR0FBQSxrQ0FBQSxHQUFBLEVBQUE7Ozs7O0FBUWhFLElBQUEsb0JBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLG9CQUFBLENBQUE7Ozs7QUFLSixJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxvQ0FBQTs7Ozs7QUFQWSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLG1EQUFBLFVBQUEseUJBQUEsR0FBQSxHQUFBLGVBQUEsRUFBQSxtQkFBQSxPQUFBLE9BQUEseUJBQUEsR0FBQSxHQUFBLGVBQUEsRUFBQSxnQkFBQSxZQUFBLFFBQUEsWUFBQSxTQUFBLFVBQUEsR0FBQSxrREFBQSx5QkFBQSxHQUFBLElBQUEseUJBQUEsR0FBQSxHQUFBLGVBQUEsRUFBQSxtQkFBQSxPQUFBLE9BQUEseUJBQUEsR0FBQSxHQUFBLGVBQUEsRUFBQSxnQkFBQSxZQUFBLElBQUEsOEJBQUEsNkJBQUEsR0FBQSw0Q0FBQTs7Ozs7O0FBckJwQixJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUFvQyxJQUFBLG9CQUFBLENBQUE7QUFBcUIsSUFBQSwwQkFBQTtBQUM3RCxJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLEVBQUE7QUFDQSxJQUFBLHVCQUFBLElBQUEsSUFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxxRUFBQSxHQUFBLENBQUEsRUFFQyxJQUFBLHFFQUFBLEdBQUEsQ0FBQTtBQUlMLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxLQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLFFBQUEsRUFBQTs7QUFDSixJQUFBLG9CQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLHFFQUFBLElBQUEsQ0FBQTtBQVdKLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxFQUFBO0FBQStCLElBQUEsMEJBQUE7QUFDekMsSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSw0Q0FBQTtBQUFBLElBQUEsdUJBQUEsSUFBQSxXQUFBLENBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsNENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsUUFBQSxFQUFBO0FBQW1FLElBQUEsb0JBQUEsSUFBQSxNQUFBO0FBQUksSUFBQSwwQkFBQTtBQUMzRSxJQUFBLG9CQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSw0Q0FBQTtBQUFBLElBQUEsdUJBQUEsSUFBQSxXQUFBLENBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsNENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsUUFBQSxFQUFBO0FBQW1FLElBQUEsb0JBQUEsSUFBQSxNQUFBO0FBQUksSUFBQSwwQkFBQTtBQUMzRSxJQUFBLG9CQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUlJLElBQUEsd0JBQUEsVUFBQSxTQUFBLGlGQUFBO0FBQUEsWUFBQSxjQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLGtCQUFBLFlBQUE7QUFBQSxZQUFBLFVBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQVUseUJBQUEsUUFBQSxtQkFBQSxnQkFBQSxFQUFBLENBQW9DO0lBQUEsQ0FBQTtBQUc5QyxJQUFBLG9CQUFBLElBQUEsNENBQUE7QUFBQSxJQUFBLHVCQUFBLElBQUEsV0FBQSxDQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSx3QkFBQTs7Ozs7QUFyRGUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxjQUFBLDZCQUFBLElBQUEsS0FBQSxnQkFBQSxFQUFBLENBQUE7QUFBaUMsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxnQkFBQSxFQUFBO0FBR3BDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsc0NBQUEsZ0JBQUEsT0FBQSxvQ0FBQTtBQUVBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsSUFBQSxnQkFBQSxTQUFBLE9BQUEsU0FBQSxTQUFBLGdCQUFBLFlBQUEsT0FBQSxPQUFBLGdCQUFBLFNBQUEsVUFBQSxPQUFBLGFBQUEsY0FBQSxLQUFBLEVBQUE7QUFHQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLElBQUEsZ0JBQUEsU0FBQSxPQUFBLFNBQUEsU0FBQSxnQkFBQSxZQUFBLE9BQUEsT0FBQSxnQkFBQSxTQUFBLFVBQUEsT0FBQSxhQUFBLGNBQUEsS0FBQSxFQUFBO0FBTVUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxhQUFBLHlCQUFBLElBQUEsSUFBQSxnQkFBQSxPQUFBLEdBQUEsMkJBQUE7QUFFVixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLElBQUEsZ0JBQUEsU0FBQSxPQUFBLFNBQUEsT0FBQSxLQUFBLEVBQUE7QUFhTSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLGdCQUFBLFlBQUEsT0FBQSxPQUFBLGdCQUFBLFNBQUEsRUFBQTtBQUlDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsY0FBQSw2QkFBQSxJQUFBLEtBQUEsZ0JBQUEsRUFBQSxDQUFBO0FBQ1UsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxRQUFBLE9BQUEsS0FBQTtBQUdWLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsY0FBQSw2QkFBQSxJQUFBLEtBQUEsZ0JBQUEsRUFBQSxDQUFBO0FBQ1UsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxRQUFBLE9BQUEsUUFBQTtBQUtULElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsZUFBQSxnQkFBQSxLQUFBLEVBQW1DLGVBQUEsT0FBQSxZQUFBO0FBSzFCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsUUFBQSxPQUFBLE9BQUE7Ozs7O0FBL0R6QyxJQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBLEVBQUksSUFBQSxRQUFBLEVBQUE7QUFBcUMsSUFBQSxvQkFBQSxJQUFBLElBQUE7QUFBRSxJQUFBLDBCQUFBLEVBQU87QUFDbEQsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUEsRUFBSSxJQUFBLFFBQUEsRUFBQTtBQUFtRCxJQUFBLG9CQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsMEJBQUEsRUFBTztBQUNuRSxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxFQUFBO0FBQXFELElBQUEsb0JBQUEsSUFBQSxTQUFBO0FBQU8sSUFBQSwwQkFBQSxFQUFPO0FBQ3ZFLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLEVBQUE7QUFBc0QsSUFBQSxvQkFBQSxJQUFBLFVBQUE7QUFBUSxJQUFBLDBCQUFBLEVBQU87QUFDekUsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLElBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLHNEQUFBLElBQUEsSUFBQSxNQUFBLE1BQUEsaUNBQUEsRUFBQSxPQUFBO0FBeURKLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLFFBQUE7Ozs7QUE1RGdCLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsd0JBQUEsT0FBQSxhQUFBOzs7QURoRHBCLGNBbUJhO0FBbkJiOztBQU1BO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQU1NLElBQU8sd0JBQVAsTUFBTyx1QkFBcUI7TUF5QmxCO01BQ0U7TUFDRjtNQUNFO01BM0JMLFdBQVc7TUFDcEIsZUFBZTtNQUNmO01BQ0E7TUFDQTtNQUNBO01BRVEsb0JBQW9CLElBQUksUUFBTztNQUN2QyxlQUFlLEtBQUssa0JBQWtCLGFBQVk7TUFFbEQ7TUFHQSxTQUFTO01BQ1QsVUFBVTtNQUNWLFFBQVE7TUFDUixXQUFXO01BQ1gsU0FBUztNQUNULFNBQVM7TUFDVCxpQkFBaUI7TUFFUixzQkFBc0I7TUFFL0IsWUFDWSxPQUNFLHFCQUNGLGNBQ0UsY0FBMEI7QUFINUIsYUFBQSxRQUFBO0FBQ0UsYUFBQSxzQkFBQTtBQUNGLGFBQUEsZUFBQTtBQUNFLGFBQUEsZUFBQTtNQUNYO01BS0gsV0FBUTtBQUNKLGFBQUssTUFBTSxLQUFLLFVBQVUsQ0FBQyxFQUFFLFNBQVEsTUFBTTtBQUN2QyxlQUFLLFdBQVc7QUFDaEIsZUFBSyxvQkFBbUI7QUFDeEIsZUFBSyw4QkFBNkI7UUFDdEMsQ0FBQztNQUNMO01BS0EsY0FBVztBQUNQLFlBQUksS0FBSyxVQUFVO0FBQ2YsZUFBSyxTQUFTLFlBQVc7O0FBRTdCLGFBQUssYUFBYSxRQUFRLEtBQUssZUFBZTtBQUM5QyxhQUFLLGtCQUFrQixZQUFXO01BQ3RDO01BS0Esc0JBQW1CO0FBQ2YsYUFBSyxvQkFDQSxpQkFBaUIsS0FBSyxTQUFTLEVBQUcsRUFDbEMsS0FDRyxPQUFPLENBQUMsUUFBc0MsSUFBSSxFQUFFLEdBQ3BELElBQUksQ0FBQyxRQUFzQyxJQUFJLElBQUksQ0FBQyxFQUV2RCxVQUFVO1VBQ1AsTUFBTSxDQUFDLFFBQXVCO0FBQzFCLGlCQUFLLGdCQUFnQjtBQUNyQixpQkFBSyxvQkFBb0IsS0FBSyxlQUFlLEtBQUssQ0FBQyxTQUFTLEtBQUssU0FBUyxTQUFTLElBQUk7VUFDM0Y7VUFDQSxPQUFPLENBQUMsUUFBMkIsUUFBUSxLQUFLLGNBQWMsR0FBRztTQUNwRTtNQUNUO01BT0EsUUFBUSxPQUFlLE1BQWtCO0FBQ3JDLGVBQU8sS0FBSztNQUNoQjtNQUtBLGdDQUE2QjtBQUN6QixZQUFJLEtBQUssaUJBQWlCO0FBQ3RCLGVBQUssZ0JBQWdCLFlBQVc7O0FBRXBDLGFBQUssa0JBQWtCLEtBQUssYUFBYSxVQUFVLGdDQUFnQyxNQUFNLEtBQUssb0JBQW1CLENBQUU7TUFDdkg7TUFNQSxtQkFBbUIsZ0JBQXNCO0FBQ3JDLGFBQUssb0JBQW9CLE9BQU8sS0FBSyxTQUFTLElBQUssY0FBYyxFQUFFLFVBQVU7VUFDekUsTUFBTSxNQUFLO0FBQ1AsaUJBQUssYUFBYSxVQUFVO2NBQ3hCLE1BQU07Y0FDTixTQUFTO2FBQ1o7QUFDRCxpQkFBSyxrQkFBa0IsS0FBSyxFQUFFO1VBQ2xDO1VBQ0EsT0FBTyxDQUFDLFVBQTZCLEtBQUssa0JBQWtCLEtBQUssTUFBTSxPQUFPO1NBQ2pGO01BQ0w7O3lCQTFHUyx3QkFBcUIsK0JBQUEsaUJBQUEsR0FBQSwrQkFBQSxtQkFBQSxHQUFBLCtCQUFBLFlBQUEsR0FBQSwrQkFBQSxZQUFBLENBQUE7TUFBQTtnRUFBckIsd0JBQXFCLFdBQUEsQ0FBQSxDQUFBLG1CQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLE1BQUEsY0FBQSxHQUFBLENBQUEsZ0JBQUEsb0NBQUEsR0FBQSxDQUFBLE1BQUEsb0JBQUEsY0FBQSxPQUFBLEdBQUEsT0FBQSxlQUFBLGFBQUEsb0JBQUEsd0JBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSwwQ0FBQSxHQUFBLENBQUEsTUFBQSxpQkFBQSxjQUFBLHdCQUFBLEdBQUEsT0FBQSxhQUFBLG9CQUFBLHNCQUFBLEdBQUEsQ0FBQSxnQkFBQSx1REFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLGVBQUEsR0FBQSxDQUFBLGdCQUFBLHVDQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsZUFBQSxHQUFBLENBQUEsZ0JBQUEsaUJBQUEsR0FBQSxDQUFBLGdCQUFBLCtCQUFBLEdBQUEsQ0FBQSxnQkFBQSxpQ0FBQSxHQUFBLENBQUEsZ0JBQUEsa0NBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxPQUFBLFlBQUEsVUFBQSxRQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsZ0JBQUEsc0JBQUEsR0FBQSxVQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxlQUFBLFVBQUEsUUFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLGdCQUFBLHNCQUFBLEdBQUEsVUFBQSxhQUFBLEdBQUEsQ0FBQSxtQkFBQSxJQUFBLGtCQUFBLDJDQUFBLEdBQUEsZUFBQSxlQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxTQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsK0JBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNuQmxDLFVBQUEsNEJBQUEsR0FBQSxLQUFBO0FBQ0ksVUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksVUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQXdELFVBQUEsb0JBQUEsR0FBQSxnQkFBQTtBQUFjLFVBQUEsMEJBQUE7QUFDdEUsVUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHdCQUFBLEdBQUEsOENBQUEsR0FBQSxDQUFBO0FBcUJBLFVBQUEsNEJBQUEsR0FBQSxLQUFBLENBQUE7QUFDSSxVQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLHVCQUFBLElBQUEsV0FBQSxDQUFBO0FBQ0EsVUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUErRCxVQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBeUIsVUFBQSwwQkFBQTtBQUM1RixVQUFBLG9CQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMEJBQUE7QUFDSixVQUFBLG9CQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMEJBQUE7QUFDQSxVQUFBLG9CQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsdUJBQUEsSUFBQSxJQUFBO0FBQ0EsVUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsK0NBQUEsR0FBQSxDQUFBLEVBSUMsSUFBQSwrQ0FBQSxJQUFBLENBQUE7QUEyRUwsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsSUFBQSxJQUFBOzs7QUEzR1EsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSwyQkFBQSxJQUFBLElBQUEsWUFBQSxPQUFBLE9BQUEsSUFBQSxTQUFBLHlCQUFBLElBQUEsb0JBQUEsT0FBQSxJQUFBLEVBQUE7QUFzQmEsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSx3QkFBQSxRQUFBLElBQUEsTUFBQTtBQUtqQixVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLDJCQUFBLEtBQUEsSUFBQSxpQkFBQSxPQUFBLE9BQUEsSUFBQSxjQUFBLFlBQUEsSUFBQSxLQUFBLEVBQUE7QUFLQSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLDJCQUFBLElBQUEsSUFBQSxpQkFBQSxJQUFBLGNBQUEsU0FBQSxJQUFBLEtBQUEsRUFBQTs7Ozs7b0ZEaEJTLHVCQUFxQixFQUFBLFdBQUEsd0JBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFbkJsQyxTQUFTLGFBQUFBLGtCQUFvQztBQUM3QyxTQUFTLGtCQUFBQyx1QkFBc0I7QUFHL0IsU0FBUyxZQUFBQyxpQkFBZ0I7Ozs7OztBQ2tCRyxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBOztBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSwwQkFBQSxHQUFBLEdBQUEsT0FBQSxhQUFBLE9BQUEsR0FBQSw0QkFBQTs7Ozs7QUFJVixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSwyQkFBQSxFQUFBOztBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFGaUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLDBCQUFBLEdBQUEsR0FBQSxPQUFBLFlBQUEsQ0FBQTs7Ozs7QUFNekIsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQTBHLElBQUEscUJBQUEsQ0FBQTtBQUErQixJQUFBLDJCQUFBO0FBQzdJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7QUFGVyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGNBQUEsOEJBQUEsR0FBQUMsTUFBQSxPQUFBLFVBQUEsT0FBQSxhQUFBLFNBQUEsT0FBQSxjQUFBLE9BQUEsVUFBQSxDQUFBO0FBQXVHLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsT0FBQSxhQUFBLFlBQUEsT0FBQSxPQUFBLE9BQUEsYUFBQSxTQUFBLEVBQUE7Ozs7O0FBL0I5SCxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxJQUFBLEVBQUksR0FBQSxRQUFBLENBQUE7QUFBMEQsSUFBQSxxQkFBQSxHQUFBLGVBQUE7QUFBYSxJQUFBLDJCQUFBO0FBQVEsSUFBQSxxQkFBQSxDQUFBO0FBQXFCLElBQUEsMkJBQUE7QUFDeEcsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLElBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUEsRUFBSSxJQUFBLFFBQUEsQ0FBQTtBQUFtRCxJQUFBLHFCQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsMkJBQUEsRUFBTztBQUNuRSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxFQUFBO0FBQXdCLElBQUEsMkJBQUE7QUFDbEMsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLENBQUE7QUFBeUQsSUFBQSxxQkFBQSxJQUFBLGFBQUE7QUFBVyxJQUFBLDJCQUFBLEVBQU87QUFDL0UsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsRUFBQTtBQUE4QixJQUFBLDJCQUFBO0FBQ3hDLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxDQUFBO0FBQWtELElBQUEscUJBQUEsSUFBQSxTQUFBO0FBQU8sSUFBQSwyQkFBQSxFQUFPO0FBQ3BFLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEVBQUE7QUFBNEQsSUFBQSwyQkFBQTtBQUN0RSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUEsRUFBSSxJQUFBLFFBQUEsQ0FBQTtBQUFxRCxJQUFBLHFCQUFBLElBQUEsU0FBQTtBQUFPLElBQUEsMkJBQUEsRUFBTztBQUN2RSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxtRUFBQSxHQUFBLENBQUE7QUFHSixJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLG1FQUFBLEdBQUEsQ0FBQTtBQUtBLElBQUEsNkJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLENBQUE7QUFBc0QsSUFBQSxxQkFBQSxJQUFBLFVBQUE7QUFBUSxJQUFBLDJCQUFBLEVBQU87QUFDekUsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsbUVBQUEsR0FBQSxDQUFBO0FBS0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsS0FBQSxDQUFBO0FBQW9ELElBQUEscUJBQUEsSUFBQSxHQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUFxQyxJQUFBLHFCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBeUMsSUFBQSxxQkFBQSxJQUFBLE9BQUE7QUFBSSxJQUFBLDJCQUFBO0FBQVEsSUFBQSxxQkFBQSxJQUFBLEdBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ3hKLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsWUFBQTs7Ozs7QUFyQzJGLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSxPQUFBLGFBQUEsSUFBQSxFQUFBO0FBS3JFLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEsZ0NBQUEsT0FBQSxhQUFBLEtBQUE7QUFJQSxJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLGdDQUFBLE9BQUEsYUFBQSxXQUFBO0FBSUEsSUFBQSx3QkFBQSxFQUFBO0FBQUEsSUFBQSxpQ0FBQSxVQUFBLE9BQUEsZ0JBQUEsT0FBQSxPQUFBLE9BQUEsYUFBQSwyQkFBQSxPQUFBLE9BQUEsT0FBQSxhQUFBLHdCQUFBLGNBQUEsUUFBQSxZQUFBLFNBQUEsVUFBQSxHQUFBO0FBSU4sSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsYUFBQSxVQUFBLEtBQUEsRUFBQTtBQUlKLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLGFBQUEsU0FBQSxPQUFBLFNBQUEsT0FBQSxLQUFBLEVBQUE7QUFPSSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxhQUFBLFdBQUEsS0FBQSxFQUFBO0FBT0wsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLDhCQUFBLEdBQUFDLElBQUEsQ0FBQTtBQUEwRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxRQUFBOzs7QUR2QzdFLGdCQVdhO0FBWGI7O0FBS0E7Ozs7Ozs7QUFNTSxJQUFPLDhCQUFQLE1BQU8sNkJBQTJCO01BYWQ7TUFaYixXQUFXO01BRXBCO01BRUE7TUFDQTtNQUVBO01BR0EsV0FBV0Y7TUFFWCxZQUFzQixPQUFxQjtBQUFyQixhQUFBLFFBQUE7TUFBd0I7TUFLOUMsV0FBUTtBQUNKLGFBQUssV0FBVyxLQUFLLE1BQU0sT0FBTyxVQUFVLENBQUMsV0FBVTtBQUNuRCxlQUFLLFdBQVcsT0FBTyxVQUFVO0FBQ2pDLGVBQUssYUFBYSxPQUFPLFlBQVk7UUFDekMsQ0FBQztBQUNELGFBQUssTUFBTSxLQUFLLFVBQVUsQ0FBQyxFQUFFLGFBQVksTUFBTTtBQUMzQyxlQUFLLGVBQWU7UUFDeEIsQ0FBQztNQUNMO01BS0EsY0FBVztBQUNQLFlBQUksS0FBSyxVQUFVO0FBQ2YsZUFBSyxTQUFTLFlBQVc7O01BRWpDOzt5QkFuQ1MsOEJBQTJCLGdDQUFBLGtCQUFBLENBQUE7TUFBQTtpRUFBM0IsOEJBQTJCLFdBQUEsQ0FBQSxDQUFBLDBCQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsT0FBQSx3QkFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxnQkFBQSxzQ0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLG1CQUFBLEdBQUEsQ0FBQSxnQkFBQSwrQkFBQSxHQUFBLENBQUEsZ0JBQUEscUNBQUEsR0FBQSxDQUFBLGdCQUFBLDhCQUFBLEdBQUEsQ0FBQSxnQkFBQSxpQ0FBQSxHQUFBLENBQUEsZ0JBQUEsa0NBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxlQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSxvQkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHFDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDWHhDLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxvREFBQSxJQUFBLEVBQUE7QUF3Q0osVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxJQUFBOzs7QUExQ1EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsZUFBQSxJQUFBLEVBQUE7Ozs7O3FGRFNLLDZCQUEyQixFQUFBLFdBQUEsOEJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFWHhDLFNBQVMsYUFBQUcsa0JBQW9DO0FBRTdDLFNBQVMsa0JBQUFDLHVCQUFzQjtBQUMvQixTQUFtQyxVQUFBQyxTQUFRLGlCQUFpQjtBQU01RCxTQUFTLE9BQU8sZUFBZSxjQUFjO0FBTzdDLFNBQVMsZ0JBQTZCOzs7Ozs7OztBQ1VWLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxpQkFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7OztBQUlJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBeUIsSUFBQSxxQkFBQSxDQUFBO0FBQW1CLElBQUEsMkJBQUE7QUFDaEQsSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBRFksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLE9BQUE7QUFBaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxRQUFBLFFBQUE7Ozs7OztBQXFCakMsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxjQUFBLEVBQUE7QUFFSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSxrRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSwrQkFBQSxDQUFnQztJQUFBLENBQUE7QUFLeEMsSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQ0wsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUFQWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGdCQUFBLEtBQUEsRUFBc0IsYUFBQSxPQUFBLHVCQUFBLEVBQUEsU0FBQSxxRUFBQSxFQUFBLFdBQUEsdUVBQUE7Ozs7O0FBbUI5QixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLDJCQUFBLEVBQUE7O0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQUZpQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsMEJBQUEsR0FBQSxHQUFBLE9BQUEsWUFBQSxDQUFBLEVBQTBDLGlCQUFBLElBQUE7Ozs7OztBQUl2RSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUlJLElBQUEseUJBQUEsU0FBQSxTQUFBLDhFQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLDZCQUFBLENBQThCO0lBQUEsQ0FBQTtBQUV2QyxJQUFBLHFCQUFBLEdBQUEsMkZBQUE7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7Ozs7QUFFSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUF1RyxJQUFBLHFCQUFBLEdBQUEsVUFBQTtBQUFRLElBQUEsMkJBQUE7QUFDL0csSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFNBQUEsRUFBQTtBQVNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUFKWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsSUFBQSxFQUFpQixXQUFBLE9BQUEsWUFBQSxPQUFBLFNBQUEsUUFBQSxXQUFBLE9BQUEsU0FBQSxLQUFBLEdBQUE7OztBRHBHN0MsSUF3Qk0sMkJBT087QUEvQmI7O0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFJQTtBQUdBO0FBQ0E7QUFDQTtBQUVBOzs7Ozs7Ozs7Ozs7OztBQUVBLElBQU0sNEJBQTRCO0FBTzVCLElBQU8sOEJBQVAsTUFBTyw2QkFBMkI7TUEwQnhCO01BQ0U7TUFDRjtNQUNFO01BQ0E7TUFDRjtNQUNBO01BQ0U7TUFDRjtNQWpDWix1QkFBdUI7TUFFdkI7TUFDQTtNQUNTLFdBQVc7TUFDcEIsZUFBZSxJQUFJLGFBQVk7TUFDL0I7TUFFQTtNQUNBO01BQ0E7TUFFQTtNQUNBO01BQ0E7TUFFQSxpQkFBaUIsQ0FBQyxJQUFJLGFBQVksQ0FBRTtNQUNwQyxhQUFhLFdBQVc7TUFHeEIsZ0JBQWdCO01BQ2hCLFFBQVE7TUFDUixTQUFTO01BRVQsWUFDWSxPQUNFLGNBQ0YsY0FDRSxpQkFDQSxxQkFDRiw0QkFDQSx1QkFDRSxxQkFDRixnQkFBOEI7QUFSOUIsYUFBQSxRQUFBO0FBQ0UsYUFBQSxlQUFBO0FBQ0YsYUFBQSxlQUFBO0FBQ0UsYUFBQSxrQkFBQTtBQUNBLGFBQUEsc0JBQUE7QUFDRixhQUFBLDZCQUFBO0FBQ0EsYUFBQSx3QkFBQTtBQUNFLGFBQUEsc0JBQUE7QUFDRixhQUFBLGlCQUFBO01BQ1Q7TUFLSCxXQUFRO0FBQ0osYUFBSyxXQUFXLEtBQUssTUFBTSxPQUFPLFVBQVUsQ0FBQyxXQUFVO0FBQ25ELGVBQUssV0FBVyxPQUFPLFVBQVU7QUFDakMsZUFBSyxXQUFXO0FBQ2hCLGVBQUssMEJBQTBCO1FBQ25DLENBQUM7QUFDRCxhQUFLLE1BQU0sS0FBSyxVQUFVLENBQUMsRUFBRSxjQUFjLFNBQVEsTUFBTTtBQUNyRCxlQUFLLFdBQVc7QUFDaEIsdUJBQWEsV0FBVztBQUN4QixlQUFLLGVBQWU7QUFDcEIsZUFBSyxhQUFhLG1CQUFtQixLQUFLLGFBQWEsb0JBQW9CO0FBRTNFLGVBQUssMkJBQTJCLDhDQUE4QyxLQUFLLFNBQVMsRUFBRyxFQUFFLFVBQVUsQ0FBQyxVQUFTO0FBQ2pILGlCQUFLLFFBQVE7QUFFYixrQkFBTSxlQUFlLEtBQUssTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sS0FBSyxhQUFhLHlCQUF5QixFQUFFO0FBQ3hHLGdCQUFJLGNBQWM7QUFDZCxtQkFBSyxhQUFhLDBCQUEwQjt1QkFDckMsTUFBTSxRQUFRO0FBQ3JCLG1CQUFLLGFBQWEsMEJBQTBCLEtBQUssTUFBTSxDQUFDOztVQUVoRSxDQUFDO0FBRUQsZUFBSyxlQUNBLGVBQWMsRUFDZCxLQUNHQSxRQUFPLENBQUMsZ0JBQWdCLGFBQWEsZ0JBQWdCLFNBQVMsTUFBTSxDQUFDLEdBQ3JFLFVBQVUsTUFBTSxLQUFLLG9CQUFvQix1Q0FBdUMsS0FBSyxTQUFTLEVBQUcsQ0FBQyxDQUFDLEVBRXRHLFVBQVUsQ0FBQyxhQUFZO0FBQ3BCLGlCQUFLLGVBQWU7VUFDeEIsQ0FBQztRQUNULENBQUM7TUFDTDtNQUVBLCtCQUE0QjtBQUN4QixjQUFNLFdBQVcsS0FBSztBQUN0QixjQUFNLDBCQUEwQixTQUFTLHlCQUF5QixhQUFhLENBQUE7QUFDL0UsY0FBTSxXQUF3QixLQUFLLGFBQWEsS0FBSywyQ0FBd0QsRUFBRSxNQUFNLE1BQU0sVUFBVSxTQUFRLENBQUU7QUFDL0ksaUJBQVMsa0JBQWtCLGFBQWEsS0FBSyxTQUFTO0FBQ3RELGlCQUFTLGtCQUFrQixXQUFXO0FBQ3RDLGlCQUFTLGtCQUFrQixZQUFZO0FBQ3ZDLGlCQUFTLGtCQUFrQixlQUFlLFVBQVUsQ0FBQyxpQkFBa0Q7QUFDbkcsbUJBQVUsZ0JBQWlCLEtBQUssWUFBWTtRQUNoRCxDQUFDO01BQ0w7TUFLQSxjQUFXO0FBQ1AsWUFBSSxLQUFLLFVBQVU7QUFDZixlQUFLLFNBQVMsWUFBVzs7TUFFakM7TUFNQSxrQkFBa0IsWUFBa0I7QUFDaEMsYUFBSyxhQUFhLFVBQVU7TUFDaEM7TUFPQSxnQkFBYTtBQUNULGFBQUssc0JBQXNCLHlCQUN2QixDQUFDLHFCQUFxQixLQUFLLFNBQVMsU0FBUSxHQUFJLHlCQUF5QixLQUFLLFNBQVMsR0FBSSxTQUFRLEdBQUksT0FBTyxHQUM5RyxLQUFLLGFBQWEsSUFBSSxTQUFRLENBQUU7TUFFeEM7TUFLQSxPQUFJO0FBQ0EsYUFBSyxXQUFXO0FBQ2hCLFlBQUksS0FBSyxhQUFhLE9BQU8sUUFBVztBQUNwQyxlQUFLLHdCQUF3QixLQUFLLG9CQUFvQixPQUFPLEtBQUssU0FBUyxJQUFLLEtBQUssWUFBWSxDQUFDO2VBQy9GO0FBQ0gsZUFBSyx3QkFBd0IsS0FBSyxvQkFBb0IsT0FBTyxLQUFLLFNBQVMsSUFBSyxLQUFLLFlBQVksQ0FBQzs7TUFFMUc7TUFFQSxpQ0FBOEI7QUFDMUIsYUFBSywwQkFBMEI7QUFDL0IsYUFBSyxnQkFBZ0IsK0JBQStCLEtBQUssU0FBUyxJQUFLLEtBQUssYUFBYSxFQUFHLEVBQUUsVUFBVTtVQUNwRyxNQUFNLENBQUMsYUFBWTtBQUNmLGlCQUFLLGFBQWEsY0FBYyxTQUFTLEtBQU07QUFDL0MsaUJBQUssYUFBYSxVQUFVLFNBQVMsS0FBTTtBQUMzQyxpQkFBSywwQkFBMEI7VUFDbkM7VUFDQSxPQUFPLENBQUMsVUFBUztBQUNiLGlCQUFLLDBCQUEwQjtBQUMvQixvQkFBUSxLQUFLLGNBQWMsS0FBSztVQUNwQztTQUNIO01BQ0w7TUFFVSx3QkFBd0IsUUFBOEM7QUFDNUUsZUFBTyxVQUFVO1VBQ2IsTUFBTSxNQUFNLEtBQUssY0FBYTtVQUM5QixPQUFPLE1BQU0sS0FBSyxZQUFXO1NBQ2hDO01BQ0w7TUFFVSxnQkFBYTtBQUNuQixhQUFLLFdBQVc7QUFDaEIsYUFBSyxjQUFhO01BQ3RCO01BRVUsY0FBVztBQUNqQixhQUFLLFdBQVc7TUFDcEI7O3lCQTdKUyw4QkFBMkIsZ0NBQUEsa0JBQUEsR0FBQSxnQ0FBQSxZQUFBLEdBQUEsZ0NBQUEsV0FBQSxHQUFBLGdDQUFBLGVBQUEsR0FBQSxnQ0FBQSxtQkFBQSxHQUFBLGdDQUFBLDBCQUFBLEdBQUEsZ0NBQUEsNEJBQUEsR0FBQSxnQ0FBQSxtQkFBQSxHQUFBLGdDQUFBLGNBQUEsQ0FBQTtNQUFBO2lFQUEzQiw4QkFBMkIsV0FBQSxDQUFBLENBQUEsMEJBQUEsQ0FBQSxHQUFBLE9BQUEsS0FBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxPQUFBLHdCQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLFFBQUEsWUFBQSxRQUFBLFFBQUEsY0FBQSxJQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsWUFBQSxRQUFBLEdBQUEsQ0FBQSxNQUFBLDZCQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsT0FBQSxNQUFBLGdCQUFBLGlCQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsTUFBQSxNQUFBLFFBQUEsTUFBQSxZQUFBLElBQUEsR0FBQSxnQkFBQSxHQUFBLFdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxnQkFBQSxpQ0FBQSxPQUFBLGVBQUEsR0FBQSxvQkFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLFlBQUEsSUFBQSxhQUFBLEtBQUEsUUFBQSxTQUFBLE1BQUEsZUFBQSxHQUFBLGdCQUFBLEdBQUEsV0FBQSxlQUFBLEdBQUEsQ0FBQSxnQkFBQSx1Q0FBQSxPQUFBLHFCQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsUUFBQSw0Q0FBQSxHQUFBLENBQUEsUUFBQSxRQUFBLFlBQUEsSUFBQSxhQUFBLEtBQUEsUUFBQSxlQUFBLE1BQUEscUJBQUEsR0FBQSxnQkFBQSxHQUFBLFdBQUEsZUFBQSxHQUFBLENBQUEsZ0JBQUEsZ0NBQUEsT0FBQSxjQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsWUFBQSxJQUFBLFFBQUEsUUFBQSxNQUFBLGNBQUEsR0FBQSxlQUFBLEdBQUEsV0FBQSxlQUFBLEdBQUEsQ0FBQSxnQkFBQSw0Q0FBQSxPQUFBLHFCQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsUUFBQSxpREFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLFlBQUEsSUFBQSxPQUFBLEtBQUEsT0FBQSxPQUFBLFFBQUEsb0JBQUEsTUFBQSwwQkFBQSxHQUFBLGdCQUFBLEdBQUEsV0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsMkJBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxzQkFBQSxzQkFBQSxrQkFBQSxjQUFBLGdCQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsTUFBQSxlQUFBLEdBQUEsT0FBQSxpQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsc0JBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxNQUFBLGVBQUEsR0FBQSxPQUFBLGVBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxnQkFBQSxvQkFBQSxHQUFBLENBQUEsUUFBQSxxQ0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEscUJBQUEsR0FBQSxDQUFBLE1BQUEsNkJBQUEsR0FBQSxnQkFBQSxhQUFBLFNBQUEsV0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsZ0JBQUEseUVBQUEsR0FBQSxPQUFBLGVBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsb0NBQUEsT0FBQSxrQkFBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsWUFBQSxJQUFBLFFBQUEsWUFBQSxNQUFBLGtCQUFBLEdBQUEsZ0JBQUEsR0FBQSxZQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxxQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQy9CeEMsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLFFBQUEsR0FBQSxDQUFBO0FBQTZDLFVBQUEseUJBQUEsWUFBQSxTQUFBLGdFQUFBO0FBQUEsbUJBQVksSUFBQSxLQUFBO1VBQU0sQ0FBQTtBQUMzRCxVQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLGdFQUFBO0FBQ0osVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLENBQUE7QUFBK0MsVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBRSxVQUFBLDJCQUFBO0FBQ2pELFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLENBQUE7QUFBbUUsVUFBQSx5QkFBQSxpQkFBQSxTQUFBLHFFQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLGFBQUEsS0FBQTtVQUFBLENBQUE7QUFBbkUsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUFpRyxVQUFBLHFCQUFBLElBQUEsT0FBQTtBQUFLLFVBQUEsMkJBQUE7QUFDdEcsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUE2RixVQUFBLHlCQUFBLGlCQUFBLFNBQUEscUVBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsYUFBQSxRQUFBO1VBQUEsQ0FBQTtBQUE3RixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsS0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBdUcsVUFBQSxxQkFBQSxJQUFBLGFBQUE7QUFBVyxVQUFBLDJCQUFBO0FBQ2xILFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxpQkFBQSxFQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBeUcsVUFBQSx5QkFBQSxpQkFBQSxTQUFBLHFFQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLGFBQUEsY0FBQTtVQUFBLENBQUE7QUFBekcsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLEtBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsU0FBQSxFQUFBO0FBQXlGLFVBQUEscUJBQUEsSUFBQSxNQUFBO0FBQUksVUFBQSwyQkFBQTtBQUM3RixVQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEscURBQUEsR0FBQSxDQUFBO0FBR0osVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBaUQsVUFBQSx5QkFBQSxpQkFBQSxTQUFBLHNFQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLGFBQUEsMEJBQUE7VUFBQSxDQUFBO0FBQzdDLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsK0JBQUEsSUFBQSw2Q0FBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBO0FBR0osVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLEtBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsU0FBQSxFQUFBO0FBQTRHLFVBQUEscUJBQUEsSUFBQSxtQkFBQTtBQUFpQixVQUFBLDJCQUFBO0FBQzdILFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxpQkFBQSxFQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLEVBQUE7QUFRSSxVQUFBLHlCQUFBLGlCQUFBLFNBQUEscUVBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsYUFBQSxtQkFBQTtVQUFBLENBQUE7QUFSSixVQUFBLDJCQUFBO0FBVUosVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxxREFBQSxHQUFBLENBQUE7QUFhQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLHVCQUFBLEVBQUE7QUFFSSxVQUFBLHlCQUFBLGtCQUFBLFNBQUEsb0ZBQUEsUUFBQTtBQUFBLG1CQUFrQixJQUFBLGtCQUFBLE1BQUE7VUFBeUIsQ0FBQTtBQUs5QyxVQUFBLDJCQUFBO0FBQ0wsVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxxREFBQSxHQUFBLENBQUEsRUFJQyxJQUFBLHFEQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEscURBQUEsR0FBQSxDQUFBO0FBMkJMLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsS0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBaUUsVUFBQSx5QkFBQSxTQUFBLFNBQUEsZ0VBQUE7QUFBQSxtQkFBUyxJQUFBLGNBQUE7VUFBZSxDQUFBO0FBQ3JGLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFBa0MsVUFBQSxxQkFBQSxJQUFBLE1BQUE7QUFBTSxVQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQTBDLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQU0sVUFBQSwyQkFBQTtBQUM1RixVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFBbUMsVUFBQSxxQkFBQSxJQUFBLE1BQUE7QUFBTSxVQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQXdDLFVBQUEscUJBQUEsSUFBQSxNQUFBO0FBQUksVUFBQSwyQkFBQTtBQUN6RixVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsS0FBQSxJQUFBOzs7O0FBbEgrQyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLGdCQUFBLG1DQUFBLElBQUEsYUFBQSxLQUFBLGNBQUEsY0FBQTtBQUlQLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsVUFBQSxFQUFBLElBQUEsZ0JBQUEsT0FBQSxPQUFBLElBQUEsYUFBQSxHQUFBO0FBRStDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsV0FBQSxJQUFBLGFBQUEsRUFBQTtBQUkwQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsSUFBQSxhQUFBLEtBQUE7QUFPWSxVQUFBLHdCQUFBLEVBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsSUFBQSxhQUFBLFdBQUE7QUFLckcsVUFBQSx3QkFBQSxFQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsYUFBQSxTQUFBLFNBQUEsS0FBQSxFQUFBO0FBSTZDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsV0FBQSxJQUFBLGFBQUEsdUJBQUE7QUFDN0MsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLEtBQUE7QUFrQkEsVUFBQSx3QkFBQSxFQUFBO0FBQUEsVUFBQSx5QkFBQSxXQUFBLElBQUEsYUFBQSxnQkFBQTtBQUdSLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLGFBQUEsU0FBQSxJQUFBLFNBQUEsU0FBQSxJQUFBLGdCQUFBLE9BQUEsT0FBQSxJQUFBLGFBQUEsc0JBQUEsT0FBQSxPQUFBLElBQUEsYUFBQSxtQkFBQSxXQUFBLEtBQUEsRUFBQTtBQWVRLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsWUFBQSxJQUFBLGFBQUEsT0FBQSxFQUFpQyxzQkFBQSxJQUFBLHFCQUFBLEtBQUEsRUFBQSxzQkFBQSxJQUFBLHFCQUFBLEtBQUEsRUFBQSxrQkFBQSxJQUFBLGNBQUEsRUFBQSxjQUFBLElBQUEsVUFBQTtBQVF6QyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxhQUFBLFNBQUEsSUFBQSxTQUFBLE9BQUEsS0FBQSxFQUFBO0FBS0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsYUFBQSxTQUFBLElBQUEsU0FBQSxPQUFBLEtBQUEsRUFBQTtBQVlBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsS0FBQSxJQUFBLFlBQUEsT0FBQSxPQUFBLElBQUEsU0FBQSxNQUFBLEtBQUEsRUFBQTtBQWlCYSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxLQUFBO0FBRTBCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsWUFBQSxJQUFBLFdBQUEsSUFBQSxZQUFBLENBQUEsSUFBQSxTQUFBLEVBQUE7QUFDMUIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsTUFBQTs7Ozs7cUZEaEZoQiw2QkFBMkIsRUFBQSxXQUFBLDhCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRS9CeEMsU0FBUyxrQkFBa0I7QUFJM0IsU0FBUyxVQUFVO0FBQ25CLFNBQVMsVUFBQUMsU0FBUSxPQUFBQyxZQUFXOztBQUw1QixJQWdCYSxxQkFvQkE7QUFwQ2I7O0FBR0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdNLElBQU8sc0JBQVAsTUFBTyxxQkFBbUI7TUFDUjtNQUFwQixZQUFvQixTQUE0QjtBQUE1QixhQUFBLFVBQUE7TUFBK0I7TUFNbkQsUUFBUSxPQUE2QjtBQUNqQyxjQUFNLGFBQWEsTUFBTSxPQUFPLFlBQVksSUFBSSxNQUFNLE9BQU8sWUFBWSxJQUFJO0FBQzdFLGNBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxJQUFJLE1BQU0sT0FBTyxRQUFRLElBQUk7QUFDakUsWUFBSSxjQUFjLFFBQVE7QUFDdEIsaUJBQU8sS0FBSyxRQUFRLEtBQUssWUFBWSxNQUFNLEVBQUUsS0FDekNELFFBQU8sQ0FBQyxhQUF5QyxTQUFTLEVBQUUsR0FDNURDLEtBQUksQ0FBQyxpQkFBNkMsYUFBYSxJQUFLLENBQUM7O0FBRzdFLGVBQU8sR0FBRyxJQUFJLGFBQVksQ0FBRTtNQUNoQzs7eUJBakJTLHNCQUFtQix1QkFBQSxtQkFBQSxDQUFBO01BQUE7b0VBQW5CLHNCQUFtQixTQUFuQixxQkFBbUIsV0FBQSxZQUROLE9BQU0sQ0FBQTs7QUFxQnpCLElBQU0sb0JBQTRCO01BQ3JDLEdBQUcsY0FBYyxJQUFJLENBQUMsaUJBQWdCO0FBQ2xDLGVBQU87VUFDSCxNQUFNLGVBQWUsZUFBZTtVQUNwQyxXQUFXO1VBQ1gsU0FBUztZQUNMLFVBQVU7WUFDVixjQUFjOztVQUVsQixNQUFNO1lBQ0YsYUFBYSxDQUFDLFVBQVUsUUFBUSxVQUFVLFlBQVksVUFBVSxLQUFLO1lBQ3JFLFdBQVc7O1VBRWYsYUFBYSxDQUFDLHNCQUFzQjs7TUFFNUMsQ0FBQztNQUNELEdBQUcsY0FBYyxJQUFJLENBQUMsaUJBQWdCO0FBQ2xDLGVBQU87VUFDSCxNQUFNLGVBQWUsZUFBZTtVQUNwQyxXQUFXO1VBQ1gsU0FBUztZQUNMLGNBQWM7O1VBRWxCLE1BQU07WUFDRixhQUFhLENBQUMsVUFBVSxRQUFRLFVBQVUsWUFBWSxVQUFVLEtBQUs7WUFDckUsV0FBVzs7VUFFZixhQUFhLENBQUMsc0JBQXNCOztNQUU1QyxDQUFDO01BQ0QsR0FBRyxjQUFjLElBQUksQ0FBQyxpQkFBZ0I7QUFDbEMsZUFBTztVQUNILE1BQU0sZUFBZSxlQUFlO1VBQ3BDLFdBQVc7VUFDWCxTQUFTO1lBQ0wsVUFBVTtZQUNWLGNBQWM7O1VBRWxCLE1BQU07WUFDRixhQUFhLENBQUMsVUFBVSxRQUFRLFVBQVUsWUFBWSxVQUFVLEtBQUs7WUFDckUsV0FBVzs7VUFFZixhQUFhLENBQUMsc0JBQXNCOztNQUU1QyxDQUFDO01BQ0QsR0FBRyxjQUFjLElBQUksQ0FBQyxpQkFBZ0I7QUFDbEMsZUFBTztVQUNILE1BQU0sZUFBZSxlQUFlO1VBQ3BDLFdBQVc7VUFDWCxTQUFTO1lBQ0wsVUFBVTs7VUFFZCxNQUFNO1lBQ0YsYUFBYSxDQUFDLFVBQVUsUUFBUSxVQUFVLFlBQVksVUFBVSxLQUFLO1lBQ3JFLFdBQVc7O1VBRWYsYUFBYSxDQUFDLHNCQUFzQjs7TUFFNUMsQ0FBQzs7Ozs7O0FDOUZMLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsYUFBYSwyQkFBMkI7QUFDakQsU0FBUyxvQkFBb0I7O0FBRjdCLElBYU0sZUFnQk87QUE3QmI7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsSUFBTSxnQkFBZ0IsQ0FBQyxHQUFHLGlCQUFpQjtBQWdCckMsSUFBTyxzQ0FBUCxNQUFPLHFDQUFtQzs7eUJBQW5DLHNDQUFtQztNQUFBO2dFQUFuQyxxQ0FBbUMsQ0FBQTs7UUFaeEM7UUFDQSxhQUFhLFNBQVMsYUFBYTtRQUNuQztRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtNQUErQixFQUFBLENBQUE7Ozs7IiwibmFtZXMiOlsiQ29tcG9uZW50IiwiQWN0aXZhdGVkUm91dGUiLCJmYVdyZW5jaCIsIl9jMCIsIl9jMSIsIkNvbXBvbmVudCIsIkFjdGl2YXRlZFJvdXRlIiwiZmlsdGVyIiwiZmlsdGVyIiwibWFwIl19