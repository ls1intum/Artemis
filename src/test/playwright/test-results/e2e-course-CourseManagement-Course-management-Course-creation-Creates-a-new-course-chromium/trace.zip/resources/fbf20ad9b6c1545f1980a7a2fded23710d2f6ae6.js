import {
  ModelingSubmissionService,
  init_modeling_exercise_model,
  init_modeling_submission_service
} from "/chunk-G6N6LNHZ.js";
import {
  ModelingEditorComponent,
  init_modeling_editor_component
} from "/chunk-WTEGR6H3.js";
import {
  TextSubmissionService,
  init_text_submission_service
} from "/chunk-ZFYPLKAT.js";
import {
  PlagiarismAndTutorEffortDirective,
  TextExerciseService,
  init_plagiarism_and_tutor_effort_directive,
  init_text_exercise_service
} from "/chunk-RWTFX2WB.js";
import {
  CodeEditorRepositoryFileService,
  DomainType,
  FileType,
  ProgrammingExerciseService,
  init_code_editor_model,
  init_code_editor_repository_service,
  init_programming_exercise_service
} from "/chunk-J24E6AYR.js";
import {
  ConfirmAutofocusModalComponent,
  GraphColors,
  downloadFile,
  downloadStream,
  downloadZipFileFromResponse,
  init_confirm_autofocus_modal_component,
  init_download_util,
  init_statistics_model
} from "/chunk-ORYTP7RT.js";
import {
  AlertService,
  AlertType,
  ArtemisTranslatePipe,
  ExerciseService,
  ExerciseType,
  FeatureToggle,
  FeatureToggleDirective,
  HelpIconComponent,
  JhiWebsocketService,
  Range,
  TranslateDirective,
  __esm,
  __spreadValues,
  createRequestOption,
  getCourseId,
  init_alert_service,
  init_artemis_translate_pipe,
  init_exercise_model,
  init_exercise_service,
  init_feature_toggle_directive,
  init_feature_toggle_service,
  init_help_icon_component,
  init_request_util,
  init_translate_directive,
  init_utils,
  init_websocket_service,
  round
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/course/plagiarism-cases/shared/plagiarism-cases.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient, HttpParams } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var PlagiarismCasesService;
var init_plagiarism_cases_service = __esm({
  "src/main/webapp/app/course/plagiarism-cases/shared/plagiarism-cases.service.ts"() {
    PlagiarismCasesService = class _PlagiarismCasesService {
      http;
      resourceUrl = "api/courses";
      resourceUrlExercises = "api/exercises";
      constructor(http) {
        this.http = http;
      }
      getCoursePlagiarismCasesForInstructor(courseId) {
        return this.http.get(`${this.resourceUrl}/${courseId}/plagiarism-cases/for-instructor`, { observe: "response" });
      }
      getExamPlagiarismCasesForInstructor(courseId, examId) {
        return this.http.get(`${this.resourceUrl}/${courseId}/exams/${examId}/plagiarism-cases/for-instructor`, { observe: "response" });
      }
      getPlagiarismCaseDetailForInstructor(courseId, plagiarismCaseId) {
        return this.http.get(`${this.resourceUrl}/${courseId}/plagiarism-cases/${plagiarismCaseId}/for-instructor`, { observe: "response" });
      }
      saveVerdict(courseId, plagiarismCaseId, plagiarismVerdict) {
        return this.http.put(`${this.resourceUrl}/${courseId}/plagiarism-cases/${plagiarismCaseId}/verdict`, plagiarismVerdict, { observe: "response" });
      }
      getPlagiarismCaseInfoForStudent(courseId, exerciseId) {
        return this.http.get(`${this.resourceUrl}/${courseId}/exercises/${exerciseId}/plagiarism-case`, { observe: "response" });
      }
      getPlagiarismCaseInfosForStudent(courseId, exerciseIds) {
        let params = new HttpParams();
        for (const exerciseId of exerciseIds) {
          params = params.append("exerciseId", exerciseId);
        }
        return this.http.get(`${this.resourceUrl}/${courseId}/plagiarism-cases`, { params, observe: "response" });
      }
      getPlagiarismCaseDetailForStudent(courseId, plagiarismCaseId) {
        return this.http.get(`${this.resourceUrl}/${courseId}/plagiarism-cases/${plagiarismCaseId}/for-student`, { observe: "response" });
      }
      getPlagiarismComparisonForSplitView(courseId, plagiarismComparisonId) {
        return this.http.get(`${this.resourceUrl}/${courseId}/plagiarism-comparisons/${plagiarismComparisonId}/for-split-view`, {
          observe: "response"
        });
      }
      updatePlagiarismComparisonStatus(courseId, plagiarismComparisonId, status) {
        return this.http.put(`${this.resourceUrl}/${courseId}/plagiarism-comparisons/${plagiarismComparisonId}/status`, { status }, { observe: "response" });
      }
      cleanUpPlagiarism(exerciseId, plagiarismResultId, deleteAll = false) {
        const params = new HttpParams().append("deleteAll", deleteAll ? "true" : "false");
        return this.http.delete(`${this.resourceUrlExercises}/${exerciseId}/plagiarism-results/${plagiarismResultId}/plagiarism-comparisons`, {
          params,
          observe: "response"
        });
      }
      getNumberOfPlagiarismCasesForExercise(exercise) {
        let courseId;
        if (exercise.exerciseGroup) {
          courseId = exercise.exerciseGroup.exam.course.id;
        } else {
          courseId = exercise.course.id;
        }
        const exerciseId = exercise.id;
        return this.http.get(`${this.resourceUrl}/${courseId}/exercises/${exerciseId}/plagiarism-cases-count`);
      }
      static \u0275fac = function PlagiarismCasesService_Factory(t) {
        return new (t || _PlagiarismCasesService)(i0.\u0275\u0275inject(i1.HttpClient));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _PlagiarismCasesService, factory: _PlagiarismCasesService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/modeling/manage/modeling-exercise.service.ts
import { Injectable as Injectable2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient as HttpClient3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var ModelingExerciseService;
var init_modeling_exercise_service = __esm({
  "src/main/webapp/app/exercises/modeling/manage/modeling-exercise.service.ts"() {
    init_request_util();
    init_exercise_service();
    init_download_util();
    init_exercise_service();
    ModelingExerciseService = class _ModelingExerciseService {
      http;
      exerciseService;
      resourceUrl = "api/modeling-exercises";
      adminResourceUrl = "api/admin/modeling-exercises";
      constructor(http, exerciseService) {
        this.http = http;
        this.exerciseService = exerciseService;
        this.exerciseService = exerciseService;
      }
      create(modelingExercise) {
        let copy = ExerciseService.convertExerciseDatesFromClient(modelingExercise);
        copy = ExerciseService.setBonusPointsConstrainedByIncludedInOverallScore(copy);
        copy.categories = ExerciseService.stringifyExerciseCategories(copy);
        return this.http.post(this.resourceUrl, copy, { observe: "response" }).pipe(map((res) => this.exerciseService.processExerciseEntityResponse(res)));
      }
      update(modelingExercise, req) {
        const options = createRequestOption(req);
        let copy = ExerciseService.convertExerciseDatesFromClient(modelingExercise);
        copy = ExerciseService.setBonusPointsConstrainedByIncludedInOverallScore(copy);
        copy.categories = ExerciseService.stringifyExerciseCategories(copy);
        return this.http.put(this.resourceUrl, copy, { params: options, observe: "response" }).pipe(map((res) => this.exerciseService.processExerciseEntityResponse(res)));
      }
      find(modelingExerciseId, withPlagiarismDetectionConfig = false) {
        return this.http.get(`${this.resourceUrl}/${modelingExerciseId}`, { observe: "response", params: { withPlagiarismDetectionConfig } }).pipe(map((res) => this.exerciseService.processExerciseEntityResponse(res)));
      }
      delete(modelingExerciseId) {
        return this.http.delete(`${this.resourceUrl}/${modelingExerciseId}`, { observe: "response" });
      }
      import(adaptedSourceModelingExercise) {
        let copy = ExerciseService.convertExerciseDatesFromClient(adaptedSourceModelingExercise);
        copy = ExerciseService.setBonusPointsConstrainedByIncludedInOverallScore(copy);
        copy.categories = ExerciseService.stringifyExerciseCategories(copy);
        return this.http.post(`${this.resourceUrl}/import/${adaptedSourceModelingExercise.id}`, copy, { observe: "response" }).pipe(map((res) => this.exerciseService.processExerciseEntityResponse(res)));
      }
      checkPlagiarism(exerciseId, options) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/check-plagiarism`, { observe: "response", params: __spreadValues({}, options?.toParams()) }).pipe(map((response) => response.body));
      }
      convertToPdf(model, filename) {
        return this.http.post("api/apollon/convert-to-pdf", { model }, { observe: "response", responseType: "blob" }).pipe(tap((response) => downloadStream(response.body, "application/pdf", filename)));
      }
      getLatestPlagiarismResult(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/plagiarism-result`, {
          observe: "response"
        }).pipe(map((response) => response.body));
      }
      getNumberOfClusters(exerciseId) {
        return this.http.get(`${this.adminResourceUrl}/${exerciseId}/check-clusters`, {
          observe: "response"
        });
      }
      buildClusters(modelingExerciseId) {
        return this.http.post(`${this.adminResourceUrl}/${modelingExerciseId}/trigger-automatic-assessment`, { observe: "response" });
      }
      deleteClusters(modelingExerciseId) {
        return this.http.delete(`${this.adminResourceUrl}/${modelingExerciseId}/clusters`, { observe: "response" });
      }
      reevaluateAndUpdate(modelingExercise, req) {
        const options = createRequestOption(req);
        let copy = ExerciseService.convertExerciseDatesFromClient(modelingExercise);
        copy = ExerciseService.setBonusPointsConstrainedByIncludedInOverallScore(copy);
        copy.categories = ExerciseService.stringifyExerciseCategories(copy);
        return this.http.put(`${this.resourceUrl}/${modelingExercise.id}/re-evaluate`, copy, { params: options, observe: "response" }).pipe(map((res) => this.exerciseService.processExerciseEntityResponse(res)));
      }
      static \u0275fac = function ModelingExerciseService_Factory(t) {
        return new (t || _ModelingExerciseService)(i02.\u0275\u0275inject(i12.HttpClient), i02.\u0275\u0275inject(ExerciseService));
      };
      static \u0275prov = i02.\u0275\u0275defineInjectable({ token: _ModelingExerciseService, factory: _ModelingExerciseService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismStatus.ts
var PlagiarismStatus;
var init_PlagiarismStatus = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismStatus.ts"() {
    (function(PlagiarismStatus2) {
      PlagiarismStatus2["CONFIRMED"] = "CONFIRMED";
      PlagiarismStatus2["DENIED"] = "DENIED";
      PlagiarismStatus2["NONE"] = "NONE";
    })(PlagiarismStatus || (PlagiarismStatus = {}));
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismComparison.ts
var init_PlagiarismComparison = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismComparison.ts"() {
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/plagiarism-header/plagiarism-header.component.ts
import { Component, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { NgbModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
var PlagiarismHeaderComponent;
var init_plagiarism_header_component = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/plagiarism-header/plagiarism-header.component.ts"() {
    init_PlagiarismStatus();
    init_PlagiarismComparison();
    init_plagiarism_cases_service();
    init_confirm_autofocus_modal_component();
    init_exercise_model();
    init_plagiarism_cases_service();
    init_artemis_translate_pipe();
    PlagiarismHeaderComponent = class _PlagiarismHeaderComponent {
      plagiarismCasesService;
      modalService;
      comparison;
      exercise;
      splitControlSubject;
      plagiarismStatus = PlagiarismStatus;
      disableConfirmDenyButton = false;
      constructor(plagiarismCasesService, modalService) {
        this.plagiarismCasesService = plagiarismCasesService;
        this.modalService = modalService;
      }
      confirmPlagiarism() {
        this.updatePlagiarismStatus(PlagiarismStatus.CONFIRMED);
      }
      denyPlagiarism() {
        if (this.comparison.status === PlagiarismStatus.CONFIRMED) {
          this.askForConfirmationOfDenying(() => this.updatePlagiarismStatus(PlagiarismStatus.DENIED));
        } else {
          this.updatePlagiarismStatus(PlagiarismStatus.DENIED);
        }
      }
      askForConfirmationOfDenying(onConfirm) {
        this.disableConfirmDenyButton = true;
        const modalRef = this.modalService.open(ConfirmAutofocusModalComponent, { keyboard: true, size: "lg" });
        modalRef.componentInstance.title = "artemisApp.plagiarism.denyAfterConfirmModalTitle";
        modalRef.componentInstance.text = "artemisApp.plagiarism.denyAfterConfirmModalText";
        modalRef.componentInstance.translateText = true;
        modalRef.result.then(onConfirm, () => this.disableConfirmDenyButton = false);
      }
      updatePlagiarismStatus(status) {
        this.disableConfirmDenyButton = true;
        const comparison = this.comparison;
        this.plagiarismCasesService.updatePlagiarismComparisonStatus(getCourseId(this.exercise), comparison.id, status).subscribe(() => {
          comparison.status = status;
          this.disableConfirmDenyButton = false;
        });
      }
      expandSplitPane(pane) {
        this.splitControlSubject.next(pane);
      }
      resetSplitPanes() {
        this.splitControlSubject.next("even");
      }
      static \u0275fac = function PlagiarismHeaderComponent_Factory(t) {
        return new (t || _PlagiarismHeaderComponent)(i03.\u0275\u0275directiveInject(PlagiarismCasesService), i03.\u0275\u0275directiveInject(i2.NgbModal));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _PlagiarismHeaderComponent, selectors: [["jhi-plagiarism-header"]], inputs: { comparison: "comparison", exercise: "exercise", splitControlSubject: "splitControlSubject" }, decls: 57, vars: 14, consts: [[1, "plagiarism-header"], [1, "plagiarism-header-left"], [1, "fw-medium"], [1, "plagiarism-header-right"], ["data-qa", "confirm-plagiarism-button", 1, "btn", "btn-success", "btn-sm", 3, "disabled", "click"], ["data-qa", "deny-plagiarism-button", 1, "btn", "btn-danger", "btn-sm", 3, "disabled", "click"], [1, "vertical-divider"], [1, "split-controls"], ["data-qa", "split-view-left", 1, "split-control", 3, "click"], ["width", "28", "height", "28", "viewBox", "0 0 24 24", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M4 5.5C4 4.67157 4.67157 4 5.5 4H15V20H5.5C4.67157 20 4 19.3284 4 18.5V5.5Z", "fill", "#E4E5E6"], ["d", "M17 4H18.5C19.3284 4 20 4.67157 20 5.5V18.5C20 19.3284 19.3284 20 18.5 20H17V4Z", "fill", "#E4E5E6"], ["data-qa", "split-view-even", 1, "split-control", 3, "click"], ["d", "M4 5.5C4 4.67157 4.67157 4 5.5 4H11V20H5.5C4.67157 20 4 19.3284 4 18.5V5.5Z", "fill", "#E4E5E6"], ["d", "M13 4H18.5C19.3284 4 20 4.67157 20 5.5V18.5C20 19.3284 19.3284 20 18.5 20H13V4Z", "fill", "#E4E5E6"], ["data-qa", "split-view-right", 1, "split-control", 3, "click"], ["d", "M20 18.5C20 19.3284 19.3284 20 18.5 20L9 20L9 4L18.5 4C19.3284 4 20 4.67157 20 5.5L20 18.5Z", "fill", "#E4E5E6"], ["d", "M7 20L5.5 20C4.67157 20 4 19.3284 4 18.5L4 5.5C4 4.67157 4.67157 4 5.5 4L7 4L7 20Z", "fill", "#E4E5E6"]], template: function PlagiarismHeaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "div", 0);
          i03.\u0275\u0275text(1, "\n    ");
          i03.\u0275\u0275elementStart(2, "div", 1);
          i03.\u0275\u0275text(3, "\n        ");
          i03.\u0275\u0275elementStart(4, "h5", 2);
          i03.\u0275\u0275text(5);
          i03.\u0275\u0275pipe(6, "artemisTranslate");
          i03.\u0275\u0275pipe(7, "artemisTranslate");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(8, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(9, "\n\n    ");
          i03.\u0275\u0275elementStart(10, "div", 3);
          i03.\u0275\u0275text(11, "\n        ");
          i03.\u0275\u0275elementStart(12, "button", 4);
          i03.\u0275\u0275listener("click", function PlagiarismHeaderComponent_Template_button_click_12_listener() {
            return ctx.confirmPlagiarism();
          });
          i03.\u0275\u0275text(13);
          i03.\u0275\u0275pipe(14, "artemisTranslate");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(15, "\n\n        ");
          i03.\u0275\u0275elementStart(16, "button", 5);
          i03.\u0275\u0275listener("click", function PlagiarismHeaderComponent_Template_button_click_16_listener() {
            return ctx.denyPlagiarism();
          });
          i03.\u0275\u0275text(17);
          i03.\u0275\u0275pipe(18, "artemisTranslate");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(19, "\n\n        ");
          i03.\u0275\u0275element(20, "div", 6);
          i03.\u0275\u0275text(21, "\n\n        ");
          i03.\u0275\u0275elementStart(22, "div", 7);
          i03.\u0275\u0275text(23, "\n            ");
          i03.\u0275\u0275elementStart(24, "div", 8);
          i03.\u0275\u0275listener("click", function PlagiarismHeaderComponent_Template_div_click_24_listener() {
            return ctx.expandSplitPane("left");
          });
          i03.\u0275\u0275text(25, "\n                ");
          i03.\u0275\u0275namespaceSVG();
          i03.\u0275\u0275elementStart(26, "svg", 9);
          i03.\u0275\u0275text(27, "\n                    ");
          i03.\u0275\u0275element(28, "path", 10);
          i03.\u0275\u0275text(29, "\n                    ");
          i03.\u0275\u0275element(30, "path", 11);
          i03.\u0275\u0275text(31, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(32, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(33, "\n            ");
          i03.\u0275\u0275namespaceHTML();
          i03.\u0275\u0275elementStart(34, "div", 12);
          i03.\u0275\u0275listener("click", function PlagiarismHeaderComponent_Template_div_click_34_listener() {
            return ctx.resetSplitPanes();
          });
          i03.\u0275\u0275text(35, "\n                ");
          i03.\u0275\u0275namespaceSVG();
          i03.\u0275\u0275elementStart(36, "svg", 9);
          i03.\u0275\u0275text(37, "\n                    ");
          i03.\u0275\u0275element(38, "path", 13);
          i03.\u0275\u0275text(39, "\n                    ");
          i03.\u0275\u0275element(40, "path", 14);
          i03.\u0275\u0275text(41, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(42, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(43, "\n            ");
          i03.\u0275\u0275namespaceHTML();
          i03.\u0275\u0275elementStart(44, "div", 15);
          i03.\u0275\u0275listener("click", function PlagiarismHeaderComponent_Template_div_click_44_listener() {
            return ctx.expandSplitPane("right");
          });
          i03.\u0275\u0275text(45, "\n                ");
          i03.\u0275\u0275namespaceSVG();
          i03.\u0275\u0275elementStart(46, "svg", 9);
          i03.\u0275\u0275text(47, "\n                    ");
          i03.\u0275\u0275element(48, "path", 16);
          i03.\u0275\u0275text(49, "\n                    ");
          i03.\u0275\u0275element(50, "path", 17);
          i03.\u0275\u0275text(51, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(52, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(53, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(54, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(55, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(56, "\n");
        }
        if (rf & 2) {
          i03.\u0275\u0275advance(5);
          i03.\u0275\u0275textInterpolate2("\n            ", ctx.comparison.submissionA.studentLogin || i03.\u0275\u0275pipeBind1(6, 6, "artemisApp.plagiarism.unknownStudent"), ",\n            ", ctx.comparison.submissionB.studentLogin || i03.\u0275\u0275pipeBind1(7, 8, "artemisApp.plagiarism.unknownStudent"), "\n        ");
          i03.\u0275\u0275advance(7);
          i03.\u0275\u0275property("disabled", ctx.comparison.status === ctx.plagiarismStatus.CONFIRMED || ctx.disableConfirmDenyButton);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275textInterpolate1("\n            ", i03.\u0275\u0275pipeBind1(14, 10, "artemisApp.plagiarism.confirm"), "\n        ");
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275property("disabled", ctx.comparison.status === ctx.plagiarismStatus.DENIED || ctx.disableConfirmDenyButton);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275textInterpolate1("\n            ", i03.\u0275\u0275pipeBind1(18, 12, "artemisApp.plagiarism.deny"), "\n        ");
        }
      }, dependencies: [ArtemisTranslatePipe], styles: ["\n\n.plagiarism-header[_ngcontent-%COMP%] {\n  align-items: center;\n  border-bottom: 1px solid var(--body-bg);\n  display: flex;\n  justify-content: space-between;\n  padding: 1rem;\n}\n.plagiarism-header-right[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n}\n.plagiarism-header-right[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\n  margin: 0 8px;\n}\n.plagiarism-header-right[_ngcontent-%COMP%]   .split-controls[_ngcontent-%COMP%] {\n  display: flex;\n}\n.plagiarism-header-right[_ngcontent-%COMP%]   .split-controls[_ngcontent-%COMP%]   .split-control[_ngcontent-%COMP%] {\n  border-radius: 4px;\n  cursor: pointer;\n  margin: 0 2px;\n}\n.plagiarism-header-right[_ngcontent-%COMP%]   .split-controls[_ngcontent-%COMP%]   .split-control[_ngcontent-%COMP%]:hover {\n  background-color: #f5f5f5;\n}\n.plagiarism-header-right[_ngcontent-%COMP%]   .vertical-divider[_ngcontent-%COMP%] {\n  background-color: var(--body-bg);\n  height: 24px;\n  width: 1px;\n}\n.plagiarism-header[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  margin-bottom: 0;\n}\n.plagiarism-header[_ngcontent-%COMP%]   .plagiarism-warning[_ngcontent-%COMP%] {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1oZWFkZXIvcGxhZ2lhcmlzbS1oZWFkZXIuY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5wbGFnaWFyaXNtLWhlYWRlciB7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0tYm9keS1iZyk7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgcGFkZGluZzogMXJlbTtcblxuICAgICYtcmlnaHQge1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuXG4gICAgICAgICYgPiAqIHtcbiAgICAgICAgICAgIG1hcmdpbjogMCA4cHg7XG4gICAgICAgIH1cblxuICAgICAgICAuc3BsaXQtY29udHJvbHMge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcblxuICAgICAgICAgICAgLnNwbGl0LWNvbnRyb2wge1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgICAgICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwIDJweDtcblxuICAgICAgICAgICAgICAgICY6aG92ZXIge1xuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNWY1O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC52ZXJ0aWNhbC1kaXZpZGVyIHtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWJvZHktYmcpO1xuICAgICAgICAgICAgaGVpZ2h0OiAyNHB4O1xuICAgICAgICAgICAgd2lkdGg6IDFweDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGg1IHtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcbiAgICB9XG5cbiAgICAucGxhZ2lhcmlzbS13YXJuaW5nIHtcbiAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksZUFBQTtBQUNBLGlCQUFBLElBQUEsTUFBQSxJQUFBO0FBQ0EsV0FBQTtBQUNBLG1CQUFBO0FBQ0EsV0FBQTs7QUFFQSxDQUFBO0FBQ0ksZUFBQTtBQUNBLFdBQUE7O0FBRUEsQ0FKSix3QkFJSSxFQUFBO0FBQ0ksVUFBQSxFQUFBOztBQUdKLENBUkosd0JBUUksQ0FBQTtBQUNJLFdBQUE7O0FBRUEsQ0FYUix3QkFXUSxDQUhKLGVBR0ksQ0FBQTtBQUNJLGlCQUFBO0FBQ0EsVUFBQTtBQUNBLFVBQUEsRUFBQTs7QUFFQSxDQWhCWix3QkFnQlksQ0FSUixlQVFRLENBTEosYUFLSTtBQUNJLG9CQUFBOztBQUtaLENBdEJKLHdCQXNCSSxDQUFBO0FBQ0ksb0JBQUEsSUFBQTtBQUNBLFVBQUE7QUFDQSxTQUFBOztBQUlSLENBcENKLGtCQW9DSTtBQUNJLGlCQUFBOztBQUdKLENBeENKLGtCQXdDSSxDQUFBO0FBQ0ksU0FBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(PlagiarismHeaderComponent, { className: "PlagiarismHeaderComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/plagiarism-split-view/split-pane-header/split-pane-header.component.ts
import { Component as Component2, EventEmitter, Input as Input2, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faChevronDown } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function SplitPaneHeaderComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n            ");
    i04.\u0275\u0275elementStart(1, "div", 2);
    i04.\u0275\u0275text(2, "\n                ");
    i04.\u0275\u0275element(3, "fa-icon", 3);
    i04.\u0275\u0275text(4, "\n                ");
    i04.\u0275\u0275elementStart(5, "span", 4);
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n            ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(8, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("icon", ctx_r0.faChevronDown);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate(ctx_r0.getActiveFile());
  }
}
function SplitPaneHeaderComponent_Conditional_10_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "li", 6);
    i04.\u0275\u0275listener("click", function SplitPaneHeaderComponent_Conditional_10_For_4_Template_li_click_1_listener() {
      const restoredCtx = i04.\u0275\u0275restoreView(_r10);
      const file_r4 = restoredCtx.$implicit;
      const idx_r5 = restoredCtx.$index;
      const ctx_r9 = i04.\u0275\u0275nextContext(2);
      return i04.\u0275\u0275resetView(ctx_r9.handleFileSelect(file_r4, idx_r5));
    });
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275elementStart(3, "span");
    i04.\u0275\u0275text(4);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n                ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(6, "\n            ");
  }
  if (rf & 2) {
    const file_r4 = ctx.$implicit;
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275classProp("split-pane-header-file-with-match", file_r4.hasMatch);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275textInterpolate(file_r4.file);
  }
}
function SplitPaneHeaderComponent_Conditional_10_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "li");
    i04.\u0275\u0275text(2);
    i04.\u0275\u0275pipe(3, "artemisTranslate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(3, 1, "artemisApp.plagiarism.noFilesFound"));
  }
}
function SplitPaneHeaderComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n        ");
    i04.\u0275\u0275elementStart(1, "ul", 5);
    i04.\u0275\u0275text(2, "\n            ");
    i04.\u0275\u0275repeaterCreate(3, SplitPaneHeaderComponent_Conditional_10_For_4_Template, 7, 3, null, null, i04.\u0275\u0275repeaterTrackByIdentity);
    i04.\u0275\u0275template(5, SplitPaneHeaderComponent_Conditional_10_Conditional_5_Template, 5, 3);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(6, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275repeater(ctx_r1.files);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275conditional(5, !ctx_r1.hasFiles() ? 5 : -1);
  }
}
var _c0, SplitPaneHeaderComponent;
var init_split_pane_header_component = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/plagiarism-split-view/split-pane-header/split-pane-header.component.ts"() {
    init_artemis_translate_pipe();
    _c0 = (a0, a1) => ({ active: a0, clickable: a1 });
    SplitPaneHeaderComponent = class _SplitPaneHeaderComponent {
      files;
      studentLogin;
      selectFile = new EventEmitter();
      showFiles = false;
      activeFileIndex = 0;
      faChevronDown = faChevronDown;
      ngOnChanges(changes) {
        if (changes.files) {
          const files = changes.files.currentValue;
          this.activeFileIndex = 0;
          if (this.hasFiles()) {
            this.selectFile.emit(files[0].file);
          }
        }
      }
      hasActiveFile() {
        return this.hasFiles() && this.activeFileIndex < this.files.length;
      }
      getActiveFile() {
        return this.files[this.activeFileIndex].file;
      }
      handleFileSelect(file, idx) {
        this.activeFileIndex = idx;
        this.showFiles = false;
        this.selectFile.emit(file.file);
      }
      hasFiles() {
        return this.files && this.files.length > 0;
      }
      toggleShowFiles() {
        if (this.hasFiles()) {
          this.showFiles = !this.showFiles;
        }
      }
      static \u0275fac = function SplitPaneHeaderComponent_Factory(t) {
        return new (t || _SplitPaneHeaderComponent)();
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _SplitPaneHeaderComponent, selectors: [["jhi-split-pane-header"]], inputs: { files: "files", studentLogin: "studentLogin" }, outputs: { selectFile: "selectFile" }, features: [i04.\u0275\u0275NgOnChangesFeature], decls: 12, vars: 9, consts: [["ngbDropdown", "", 1, "split-pane-header"], ["data-toggle", "dropdown", 1, "split-pane-header-top", 3, "ngClass", "click"], [1, "split-pane-header-file-name"], [1, "file-arrow-down", 3, "icon"], [1, "split-pane-header-selected-file"], [1, "split-pane-header-files"], ["ngbDropdownItem", "", 1, "split-pane-header-file", 3, "click"]], template: function SplitPaneHeaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275elementStart(0, "div", 0);
          i04.\u0275\u0275text(1, "\n    ");
          i04.\u0275\u0275elementStart(2, "div", 1);
          i04.\u0275\u0275listener("click", function SplitPaneHeaderComponent_Template_div_click_2_listener() {
            return ctx.toggleShowFiles();
          });
          i04.\u0275\u0275text(3, "\n        ");
          i04.\u0275\u0275template(4, SplitPaneHeaderComponent_Conditional_4_Template, 9, 2);
          i04.\u0275\u0275elementStart(5, "div");
          i04.\u0275\u0275text(6);
          i04.\u0275\u0275pipe(7, "artemisTranslate");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(8, "\n    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(9, "\n    ");
          i04.\u0275\u0275template(10, SplitPaneHeaderComponent_Conditional_10_Template, 7, 1);
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(11, "\n");
        }
        if (rf & 2) {
          i04.\u0275\u0275advance(2);
          i04.\u0275\u0275property("ngClass", i04.\u0275\u0275pureFunction2(6, _c0, ctx.showFiles, ctx.hasFiles()));
          i04.\u0275\u0275advance(2);
          i04.\u0275\u0275conditional(4, ctx.hasActiveFile() ? 4 : -1);
          i04.\u0275\u0275advance(2);
          i04.\u0275\u0275textInterpolate(ctx.studentLogin || i04.\u0275\u0275pipeBind1(7, 4, "artemisApp.plagiarism.unknownStudent"));
          i04.\u0275\u0275advance(4);
          i04.\u0275\u0275conditional(10, ctx.showFiles ? 10 : -1);
        }
      }, dependencies: [i13.NgClass, i22.NgbDropdown, i22.NgbDropdownItem, i3.FaIconComponent, ArtemisTranslatePipe], styles: ["\n\n.split-pane-header[_ngcontent-%COMP%] {\n  z-index: 1;\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  background-color: var(--bs-body-bg);\n  border-bottom: 1px solid var(--body-bg);\n}\n.split-pane-header-top[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  overflow: hidden;\n  padding: 0.25rem 0.5rem;\n}\n.split-pane-header-top.active[_ngcontent-%COMP%]   .file-arrow-down[_ngcontent-%COMP%] {\n  display: inline-block;\n  transform: rotate(180deg);\n}\n.split-pane-header-selected-file[_ngcontent-%COMP%] {\n  margin-left: 0.5rem;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n}\n.split-pane-header-file[_ngcontent-%COMP%] {\n  cursor: pointer;\n  padding: 0.25rem 0.5rem;\n}\n.split-pane-header-file[_ngcontent-%COMP%]:hover {\n  background-color: lightskyblue;\n}\n.split-pane-header-file-with-match[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n.split-pane-header-file-name[_ngcontent-%COMP%] {\n  white-space: nowrap;\n}\n.split-pane-header-files[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0.5rem 0;\n  padding: 0;\n  max-height: 300px;\n  overflow: scroll;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1zcGxpdC12aWV3L3NwbGl0LXBhbmUtaGVhZGVyL3NwbGl0LXBhbmUtaGVhZGVyLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuc3BsaXQtcGFuZS1oZWFkZXIge1xuICAgIHotaW5kZXg6IDE7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMDtcbiAgICBsZWZ0OiAwO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWJzLWJvZHktYmcpO1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1ib2R5LWJnKTtcblxuICAgICYtdG9wIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgICBwYWRkaW5nOiAwLjI1cmVtIDAuNXJlbTtcblxuICAgICAgICAmLmFjdGl2ZSAuZmlsZS1hcnJvdy1kb3duIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDE4MGRlZyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAmLXNlbGVjdGVkLWZpbGUge1xuICAgICAgICBtYXJnaW4tbGVmdDogMC41cmVtO1xuICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgICAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgICB9XG5cbiAgICAmLWZpbGUge1xuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgICAgIHBhZGRpbmc6IDAuMjVyZW0gMC41cmVtO1xuXG4gICAgICAgICY6aG92ZXIge1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRza3libHVlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgJi1maWxlLXdpdGgtbWF0Y2gge1xuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICB9XG5cbiAgICAmLWZpbGUtbmFtZSB7XG4gICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgfVxuXG4gICAgJi1maWxlcyB7XG4gICAgICAgIGxpc3Qtc3R5bGU6IG5vbmU7XG4gICAgICAgIG1hcmdpbjogMC41cmVtIDA7XG4gICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgIG1heC1oZWlnaHQ6IDMwMHB4O1xuICAgICAgICBvdmVyZmxvdzogc2Nyb2xsO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksV0FBQTtBQUNBLFlBQUE7QUFDQSxPQUFBO0FBQ0EsUUFBQTtBQUNBLFNBQUE7QUFDQSxvQkFBQSxJQUFBO0FBQ0EsaUJBQUEsSUFBQSxNQUFBLElBQUE7O0FBRUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxtQkFBQTtBQUNBLFlBQUE7QUFDQSxXQUFBLFFBQUE7O0FBRUEsQ0FOSixxQkFNSSxDQUFBLE9BQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxhQUFBLE9BQUE7O0FBSVIsQ0FBQTtBQUNJLGVBQUE7QUFDQSxlQUFBO0FBQ0EsaUJBQUE7O0FBR0osQ0FBQTtBQUNJLFVBQUE7QUFDQSxXQUFBLFFBQUE7O0FBRUEsQ0FKSixzQkFJSTtBQUNJLG9CQUFBOztBQUlSLENBQUE7QUFDSSxlQUFBOztBQUdKLENBQUE7QUFDSSxlQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBO0FBQ0EsVUFBQSxPQUFBO0FBQ0EsV0FBQTtBQUNBLGNBQUE7QUFDQSxZQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(SplitPaneHeaderComponent, { className: "SplitPaneHeaderComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismSubmission.ts
var init_PlagiarismSubmission = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismSubmission.ts"() {
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/plagiarism-split-view/modeling-submission-viewer/modeling-submission-viewer.component.ts
import { Component as Component3, Input as Input3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function ModelingSubmissionViewerComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n    ");
    i05.\u0275\u0275element(1, "jhi-modeling-editor", 1);
    i05.\u0275\u0275text(2, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("umlModel", ctx_r0.submissionModel)("diagramType", ctx_r0.exercise.diagramType)("readOnly", true);
  }
}
function ModelingSubmissionViewerComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n    ");
    i05.\u0275\u0275elementStart(1, "div", 2);
    i05.\u0275\u0275text(2, "\n        ");
    i05.\u0275\u0275elementStart(3, "div", 3);
    i05.\u0275\u0275text(4, "\n            ");
    i05.\u0275\u0275elementStart(5, "span", 4);
    i05.\u0275\u0275text(6, "Loading...");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(7, "\n        ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(8, "\n    ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(9, "\n");
  }
}
var ModelingSubmissionViewerComponent;
var init_modeling_submission_viewer_component = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/plagiarism-split-view/modeling-submission-viewer/modeling-submission-viewer.component.ts"() {
    init_modeling_submission_service();
    init_PlagiarismSubmission();
    init_modeling_exercise_model();
    init_modeling_submission_service();
    init_modeling_editor_component();
    init_split_pane_header_component();
    ModelingSubmissionViewerComponent = class _ModelingSubmissionViewerComponent {
      modelingSubmissionService;
      exercise;
      plagiarismSubmission;
      loading;
      submissionModel;
      constructor(modelingSubmissionService) {
        this.modelingSubmissionService = modelingSubmissionService;
      }
      ngOnChanges(changes) {
        if (changes.plagiarismSubmission) {
          this.loading = true;
          const currentPlagiarismSubmission = changes.plagiarismSubmission.currentValue;
          this.modelingSubmissionService.getSubmissionWithoutLock(currentPlagiarismSubmission.submissionId).subscribe({
            next: (submission) => {
              this.loading = false;
              this.submissionModel = JSON.parse(submission.model);
            },
            error: () => {
              this.loading = false;
            }
          });
        }
      }
      static \u0275fac = function ModelingSubmissionViewerComponent_Factory(t) {
        return new (t || _ModelingSubmissionViewerComponent)(i05.\u0275\u0275directiveInject(ModelingSubmissionService));
      };
      static \u0275cmp = i05.\u0275\u0275defineComponent({ type: _ModelingSubmissionViewerComponent, selectors: [["jhi-modeling-submission-viewer"]], inputs: { exercise: "exercise", plagiarismSubmission: "plagiarismSubmission" }, features: [i05.\u0275\u0275NgOnChangesFeature], decls: 4, vars: 3, consts: [[3, "studentLogin"], [3, "umlModel", "diagramType", "readOnly"], [1, "plagiarism-submission-loader"], ["role", "status", 1, "spinner-border", "text-primary"], [1, "sr-only"]], template: function ModelingSubmissionViewerComponent_Template(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275element(0, "jhi-split-pane-header", 0);
          i05.\u0275\u0275text(1, "\n");
          i05.\u0275\u0275template(2, ModelingSubmissionViewerComponent_Conditional_2_Template, 3, 3)(3, ModelingSubmissionViewerComponent_Conditional_3_Template, 10, 0);
        }
        if (rf & 2) {
          i05.\u0275\u0275propertyInterpolate("studentLogin", ctx.plagiarismSubmission == null ? null : ctx.plagiarismSubmission.studentLogin);
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275conditional(2, !ctx.loading ? 2 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(3, ctx.loading ? 3 : -1);
        }
      }, dependencies: [ModelingEditorComponent, SplitPaneHeaderComponent], styles: ["\n\n[_nghost-%COMP%] {\n  height: 100%;\n}\n.plagiarism-submission-loader[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n  height: 100%;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1zcGxpdC12aWV3L21vZGVsaW5nLXN1Ym1pc3Npb24tdmlld2VyL21vZGVsaW5nLXN1Ym1pc3Npb24tdmlld2VyLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyI6aG9zdCB7XG4gICAgaGVpZ2h0OiAxMDAlO1xufVxuXG4ucGxhZ2lhcmlzbS1zdWJtaXNzaW9uLWxvYWRlciB7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQTtBQUNJLFVBQUE7O0FBR0osQ0FBQTtBQUNJLGVBQUE7QUFDQSxXQUFBO0FBQ0EsVUFBQTtBQUNBLG1CQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(ModelingSubmissionViewerComponent, { className: "ModelingSubmissionViewerComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/plagiarism-split-view/text-submission-viewer/text-submission-viewer.component.ts
import { Component as Component4, Input as Input4, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { escape } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
function TextSubmissionViewerComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n    ");
    i06.\u0275\u0275elementStart(1, "div", 1);
    i06.\u0275\u0275text(2);
    i06.\u0275\u0275pipe(3, "artemisTranslate");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(4, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("innerHTML", ctx_r0.fileContent || " ", i06.\u0275\u0275sanitizeHtml)("ngClass", i06.\u0275\u0275pureFunction2(5, _c02, !ctx_r0.fileContent, ctx_r0.isProgrammingExercise));
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275textInterpolate1("\n        ", i06.\u0275\u0275pipeBind1(3, 3, "artemisApp.plagiarism.noFileSelected"), "\n    ");
  }
}
function TextSubmissionViewerComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n    ");
    i06.\u0275\u0275elementStart(1, "div", 2);
    i06.\u0275\u0275text(2, "\n        ");
    i06.\u0275\u0275elementStart(3, "div", 3);
    i06.\u0275\u0275text(4, "\n            ");
    i06.\u0275\u0275elementStart(5, "span", 4);
    i06.\u0275\u0275text(6, "Loading...");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n        ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(8, "\n    ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(9, "\n");
  }
}
function TextSubmissionViewerComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n    ");
    i06.\u0275\u0275elementStart(1, "div", 5);
    i06.\u0275\u0275text(2, "\n        ");
    i06.\u0275\u0275elementStart(3, "span", 6);
    i06.\u0275\u0275text(4);
    i06.\u0275\u0275pipe(5, "artemisTranslate");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(6, "\n        ");
    i06.\u0275\u0275elementStart(7, "a", 7);
    i06.\u0275\u0275listener("click", function TextSubmissionViewerComponent_Conditional_4_Template_a_click_7_listener() {
      i06.\u0275\u0275restoreView(_r4);
      const ctx_r3 = i06.\u0275\u0275nextContext();
      return i06.\u0275\u0275resetView(ctx_r3.downloadCurrentFile());
    });
    i06.\u0275\u0275text(8);
    i06.\u0275\u0275pipe(9, "artemisTranslate");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(10, "\n    ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(11, "\n");
  }
  if (rf & 2) {
    i06.\u0275\u0275advance(4);
    i06.\u0275\u0275textInterpolate(i06.\u0275\u0275pipeBind1(5, 2, "artemisApp.plagiarism.binaryFileNotRendered"));
    i06.\u0275\u0275advance(4);
    i06.\u0275\u0275textInterpolate(i06.\u0275\u0275pipeBind1(9, 4, "entity.action.download"));
  }
}
var _c02, TextSubmissionViewerComponent;
var init_text_submission_viewer_component = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/plagiarism-split-view/text-submission-viewer/text-submission-viewer.component.ts"() {
    init_text_submission_service();
    init_PlagiarismSubmission();
    init_exercise_model();
    init_code_editor_model();
    init_code_editor_repository_service();
    init_code_editor_repository_service();
    init_text_submission_service();
    init_split_pane_header_component();
    init_artemis_translate_pipe();
    _c02 = (a0, a1) => ({ "no-file": a0, "is-code": a1 });
    TextSubmissionViewerComponent = class _TextSubmissionViewerComponent {
      repositoryService;
      textSubmissionService;
      exercise;
      matches;
      plagiarismSubmission;
      currentFile;
      fileContent;
      files;
      isProgrammingExercise;
      loading;
      tokenStart = '<span class="plagiarism-match">';
      tokenEnd = "</span>";
      binaryFile;
      constructor(repositoryService, textSubmissionService) {
        this.repositoryService = repositoryService;
        this.textSubmissionService = textSubmissionService;
      }
      ngOnChanges(changes) {
        if (changes.plagiarismSubmission) {
          const currentPlagiarismSubmission = changes.plagiarismSubmission.currentValue;
          this.loading = true;
          if (this.exercise.type === ExerciseType.PROGRAMMING) {
            this.loadProgrammingExercise(currentPlagiarismSubmission);
          } else {
            this.loadTextExercise(currentPlagiarismSubmission);
          }
        }
      }
      loadProgrammingExercise(currentPlagiarismSubmission) {
        this.isProgrammingExercise = true;
        const domain = [DomainType.PARTICIPATION, { id: currentPlagiarismSubmission.submissionId }];
        this.repositoryService.getRepositoryContent(domain).subscribe({
          next: (files) => {
            this.loading = false;
            this.files = this.programmingExerciseFilesWithMatches(files);
          },
          error: () => {
            this.loading = false;
          }
        });
      }
      programmingExerciseFilesWithMatches(files) {
        return this.filterFiles(files).map((file) => ({ file, hasMatch: this.hasMatch(file) })).sort(_TextSubmissionViewerComponent.compareFileWithHasMatch);
      }
      static compareFileWithHasMatch(file1, file2) {
        if (file1.hasMatch === file2.hasMatch) {
          return file1.file.localeCompare(file2.file);
        } else if (file1.hasMatch) {
          return -1;
        } else {
          return 1;
        }
      }
      loadTextExercise(currentPlagiarismSubmission) {
        this.isProgrammingExercise = false;
        this.textSubmissionService.getTextSubmission(currentPlagiarismSubmission.submissionId).subscribe({
          next: (submission) => {
            this.loading = false;
            this.fileContent = this.insertMatchTokens(submission.text || "");
          },
          error: () => {
            this.loading = false;
          }
        });
      }
      filterFiles(files) {
        return Object.keys(files).filter((fileName) => files[fileName] === FileType.FILE);
      }
      handleFileSelect(file) {
        this.currentFile = file;
        this.loading = true;
        const domain = [DomainType.PARTICIPATION, { id: this.plagiarismSubmission.submissionId }];
        this.repositoryService.getFileHeaders(file, domain).subscribe((response) => {
          const contentType = response.headers.get("content-type");
          if (contentType && !contentType.startsWith("text")) {
            this.binaryFile = true;
            this.loading = false;
          } else {
            this.binaryFile = false;
            this.repositoryService.getFile(file, domain).subscribe({
              next: ({ fileContent }) => {
                this.loading = false;
                this.fileContent = this.insertMatchTokens(fileContent);
              },
              error: () => {
                this.loading = false;
              }
            });
          }
        });
      }
      downloadCurrentFile() {
        this.repositoryService.downloadFile(this.currentFile, this.exercise.shortName + "_" + this.plagiarismSubmission.studentLogin + "_" + this.currentFile);
      }
      getMatchesForCurrentFile() {
        return this.matches.get(this.currentFile || "none") || [];
      }
      hasMatch(file) {
        return this.matches.has(file);
      }
      insertMatchTokens(fileContent) {
        const matches = this.getMatchesForCurrentFile().filter((match) => match.from && match.to).sort((m1, m2) => {
          const lines = m1.from.line - m2.from.line;
          if (lines === 0) {
            return m1.from.column - m2.from.column;
          }
          return lines;
        });
        if (!matches.length) {
          return escape(fileContent);
        }
        const rows = fileContent.split("\n");
        let result = "";
        for (let i = 0; i < matches[0].from.line - 1; i++) {
          result += escape(rows[i]) + "\n";
        }
        result += escape(rows[matches[0].from.line - 1].slice(0, matches[0].from.column - 1));
        for (let i = 0; i < matches.length; i++) {
          const match = matches[i];
          const idxLineFrom = match.from.line - 1;
          const idxLineTo = match.to.line - 1;
          const idxColumnFrom = match.from.column - 1;
          const idxColumnTo = match.to.column + match.to.length - 1;
          result += this.tokenStart;
          if (idxLineFrom === idxLineTo) {
            result += escape(rows[idxLineFrom].slice(idxColumnFrom, idxColumnTo)) + this.tokenEnd;
          } else {
            result += escape(rows[idxLineFrom].slice(idxColumnFrom));
            for (let j = idxLineFrom + 1; j < idxLineTo; j++) {
              result += "\n" + escape(rows[j]);
            }
            result += "\n" + escape(rows[idxLineTo].slice(0, idxColumnTo)) + this.tokenEnd;
          }
          if (i === matches.length - 1) {
            result += escape(rows[idxLineTo].slice(idxColumnTo));
            for (let j = idxLineTo + 1; j < rows.length; j++) {
              result += "\n" + escape(rows[j]);
            }
          } else if (matches[i + 1].from.line === match.to.line) {
            result += escape(rows[idxLineTo].slice(idxColumnTo, matches[i + 1].from.column - 1));
          } else {
            result += escape(rows[idxLineTo].slice(idxColumnTo)) + "\n";
            for (let j = idxLineTo + 1; j < matches[i + 1].from.line - 1; j++) {
              result += escape(rows[j]) + "\n";
            }
            result += escape(rows[matches[i + 1].from.line - 1].slice(0, matches[i + 1].from.column - 1));
          }
        }
        return result;
      }
      static \u0275fac = function TextSubmissionViewerComponent_Factory(t) {
        return new (t || _TextSubmissionViewerComponent)(i06.\u0275\u0275directiveInject(CodeEditorRepositoryFileService), i06.\u0275\u0275directiveInject(TextSubmissionService));
      };
      static \u0275cmp = i06.\u0275\u0275defineComponent({ type: _TextSubmissionViewerComponent, selectors: [["jhi-text-submission-viewer"]], inputs: { exercise: "exercise", matches: "matches", plagiarismSubmission: "plagiarismSubmission" }, features: [i06.\u0275\u0275NgOnChangesFeature], decls: 5, vars: 5, consts: [[3, "files", "studentLogin", "selectFile"], [1, "text-submission-viewer", 3, "innerHTML", "ngClass"], [1, "plagiarism-submission-loader"], ["role", "status", 1, "spinner-border", "text-primary"], [1, "sr-only"], [1, "binaryFileDialogue"], [1, "me-1"], [1, "text-primary", 3, "click"]], template: function TextSubmissionViewerComponent_Template(rf, ctx) {
        if (rf & 1) {
          i06.\u0275\u0275elementStart(0, "jhi-split-pane-header", 0);
          i06.\u0275\u0275listener("selectFile", function TextSubmissionViewerComponent_Template_jhi_split_pane_header_selectFile_0_listener($event) {
            return ctx.handleFileSelect($event);
          });
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(1, "\n");
          i06.\u0275\u0275template(2, TextSubmissionViewerComponent_Conditional_2_Template, 5, 8)(3, TextSubmissionViewerComponent_Conditional_3_Template, 10, 0)(4, TextSubmissionViewerComponent_Conditional_4_Template, 12, 6);
        }
        if (rf & 2) {
          i06.\u0275\u0275propertyInterpolate("studentLogin", ctx.plagiarismSubmission == null ? null : ctx.plagiarismSubmission.studentLogin);
          i06.\u0275\u0275property("files", ctx.files);
          i06.\u0275\u0275advance(2);
          i06.\u0275\u0275conditional(2, !ctx.loading && !ctx.binaryFile ? 2 : -1);
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275conditional(3, ctx.loading ? 3 : -1);
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275conditional(4, ctx.binaryFile ? 4 : -1);
        }
      }, dependencies: [i32.NgClass, SplitPaneHeaderComponent, ArtemisTranslatePipe], styles: ["/* src/main/webapp/app/exercises/shared/plagiarism/plagiarism-split-view/text-submission-viewer/text-submission-viewer.component.scss */\n.text-submission-viewer {\n  height: 100%;\n  overflow-y: auto;\n  padding: 0.5rem;\n  white-space: pre-wrap;\n  word-wrap: normal;\n}\n.text-submission-viewer.no-file {\n  opacity: 0.5;\n}\n.text-submission-viewer.is-code {\n  font-family: monospace;\n  white-space: pre;\n}\n.plagiarism-match {\n  color: dodgerblue;\n  font-weight: bold;\n}\n.plagiarism-submission-loader {\n  align-items: center;\n  display: flex;\n  height: 100%;\n  justify-content: center;\n}\n.binaryFileDialogue {\n  text-align: center;\n  margin-top: 3rem;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1zcGxpdC12aWV3L3RleHQtc3VibWlzc2lvbi12aWV3ZXIvdGV4dC1zdWJtaXNzaW9uLXZpZXdlci5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLnRleHQtc3VibWlzc2lvbi12aWV3ZXIge1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBvdmVyZmxvdy15OiBhdXRvO1xuICAgIHBhZGRpbmc6IDAuNXJlbTtcbiAgICB3aGl0ZS1zcGFjZTogcHJlLXdyYXA7XG4gICAgd29yZC13cmFwOiBub3JtYWw7XG5cbiAgICAmLm5vLWZpbGUge1xuICAgICAgICBvcGFjaXR5OiAwLjU7XG4gICAgfVxuXG4gICAgJi5pcy1jb2RlIHtcbiAgICAgICAgZm9udC1mYW1pbHk6IG1vbm9zcGFjZTtcbiAgICAgICAgd2hpdGUtc3BhY2U6IHByZTtcbiAgICB9XG59XG5cbi5wbGFnaWFyaXNtLW1hdGNoIHtcbiAgICBjb2xvcjogZG9kZ2VyYmx1ZTtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLnBsYWdpYXJpc20tc3VibWlzc2lvbi1sb2FkZXIge1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5iaW5hcnlGaWxlRGlhbG9ndWUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBtYXJnaW4tdG9wOiAzcmVtO1xufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLENBQUE7QUFDSSxVQUFBO0FBQ0EsY0FBQTtBQUNBLFdBQUE7QUFDQSxlQUFBO0FBQ0EsYUFBQTs7QUFFQSxDQVBKLHNCQU9JLENBQUE7QUFDSSxXQUFBOztBQUdKLENBWEosc0JBV0ksQ0FBQTtBQUNJLGVBQUE7QUFDQSxlQUFBOztBQUlSLENBQUE7QUFDSSxTQUFBO0FBQ0EsZUFBQTs7QUFHSixDQUFBO0FBQ0ksZUFBQTtBQUNBLFdBQUE7QUFDQSxVQUFBO0FBQ0EsbUJBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUE7QUFDQSxjQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i06.\u0275setClassDebugInfo(TextSubmissionViewerComponent, { className: "TextSubmissionViewerComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismSubmissionElement.ts
var init_PlagiarismSubmissionElement = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismSubmissionElement.ts"() {
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/types/text/TextSubmissionElement.ts
var FromToElement;
var init_TextSubmissionElement = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/types/text/TextSubmissionElement.ts"() {
    init_PlagiarismSubmissionElement();
    FromToElement = class {
      from;
      to;
      constructor(from, to) {
        this.from = from;
        this.to = to;
      }
    };
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismMatch.ts
var SimpleMatch;
var init_PlagiarismMatch = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismMatch.ts"() {
    SimpleMatch = class {
      start;
      length;
      constructor(start, length) {
        this.start = start;
        this.length = length;
      }
    };
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/plagiarism-split-view/plagiarism-split-view.component.ts
import { Component as Component5, Directive, ElementRef, Input as Input5, QueryList, ViewChildren } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as Split from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/split__js.js?v=1d0d9ead";
import { Subject as Subject2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function PlagiarismSplitViewComponent_Conditional_4_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275element(1, "jhi-modeling-submission-viewer", 2);
    i07.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r2 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("exercise", ctx_r2.exercise)("plagiarismSubmission", ctx_r2.getModelingSubmissionA());
  }
}
function PlagiarismSplitViewComponent_Conditional_4_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275element(1, "jhi-text-submission-viewer", 3);
    i07.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r3 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("exercise", ctx_r3.exercise)("matches", ctx_r3.matchesA)("plagiarismSubmission", ctx_r3.getTextSubmissionA());
  }
}
function PlagiarismSplitViewComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n            ");
    i07.\u0275\u0275template(1, PlagiarismSplitViewComponent_Conditional_4_Conditional_1_Template, 3, 2)(2, PlagiarismSplitViewComponent_Conditional_4_Conditional_2_Template, 3, 3);
  }
  if (rf & 2) {
    const ctx_r0 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(1, ctx_r0.isModelingExercise ? 1 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(2, ctx_r0.isProgrammingOrTextExercise ? 2 : -1);
  }
}
function PlagiarismSplitViewComponent_Conditional_8_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275element(1, "jhi-modeling-submission-viewer", 2);
    i07.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r4 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("exercise", ctx_r4.exercise)("plagiarismSubmission", ctx_r4.getModelingSubmissionB());
  }
}
function PlagiarismSplitViewComponent_Conditional_8_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275element(1, "jhi-text-submission-viewer", 3);
    i07.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r5 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("exercise", ctx_r5.exercise)("matches", ctx_r5.matchesB)("plagiarismSubmission", ctx_r5.getTextSubmissionB());
  }
}
function PlagiarismSplitViewComponent_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n            ");
    i07.\u0275\u0275template(1, PlagiarismSplitViewComponent_Conditional_8_Conditional_1_Template, 3, 2)(2, PlagiarismSplitViewComponent_Conditional_8_Conditional_2_Template, 3, 3);
  }
  if (rf & 2) {
    const ctx_r1 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(1, ctx_r1.isModelingExercise ? 1 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(2, ctx_r1.isProgrammingOrTextExercise ? 2 : -1);
  }
}
var SplitPaneDirective, PlagiarismSplitViewComponent;
var init_plagiarism_split_view_component = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/plagiarism-split-view/plagiarism-split-view.component.ts"() {
    init_PlagiarismComparison();
    init_TextSubmissionElement();
    init_exercise_model();
    init_plagiarism_cases_service();
    init_PlagiarismMatch();
    init_plagiarism_cases_service();
    init_modeling_submission_viewer_component();
    init_text_submission_viewer_component();
    SplitPaneDirective = class _SplitPaneDirective {
      elementRef;
      constructor(elementRef) {
        this.elementRef = elementRef;
      }
      static \u0275fac = function SplitPaneDirective_Factory(t) {
        return new (t || _SplitPaneDirective)(i07.\u0275\u0275directiveInject(i07.ElementRef));
      };
      static \u0275dir = i07.\u0275\u0275defineDirective({ type: _SplitPaneDirective, selectors: [["", "jhiPane", ""]] });
    };
    PlagiarismSplitViewComponent = class _PlagiarismSplitViewComponent {
      plagiarismCasesService;
      comparison;
      exercise;
      splitControlSubject;
      sortByStudentLogin;
      panes;
      plagiarismComparison;
      split;
      isModelingExercise;
      isProgrammingOrTextExercise;
      matchesA;
      matchesB;
      constructor(plagiarismCasesService) {
        this.plagiarismCasesService = plagiarismCasesService;
      }
      ngAfterViewInit() {
        const paneElements = this.panes.map((pane) => pane.elementRef.nativeElement);
        this.split = Split.default(paneElements, {
          minSize: 100,
          sizes: [50, 50],
          gutterSize: 8
        });
      }
      ngOnInit() {
        this.splitControlSubject.subscribe((pane) => this.handleSplitControl(pane));
      }
      ngOnChanges(changes) {
        if (changes.exercise) {
          const exercise = changes.exercise.currentValue;
          this.isModelingExercise = exercise.type === ExerciseType.MODELING;
          this.isProgrammingOrTextExercise = exercise.type === ExerciseType.PROGRAMMING || exercise.type === ExerciseType.TEXT;
        }
        if (changes.comparison) {
          this.plagiarismCasesService.getPlagiarismComparisonForSplitView(getCourseId(this.exercise), changes.comparison.currentValue.id).subscribe((resp) => {
            this.plagiarismComparison = resp.body;
            if (this.sortByStudentLogin && this.sortByStudentLogin === this.plagiarismComparison.submissionB.studentLogin) {
              this.swapSubmissions(this.plagiarismComparison);
            }
            if (this.isProgrammingOrTextExercise) {
              this.parseTextMatches(this.plagiarismComparison);
            }
          });
        }
      }
      swapSubmissions(plagiarismComparison) {
        const temp = plagiarismComparison.submissionA;
        plagiarismComparison.submissionA = plagiarismComparison.submissionB;
        plagiarismComparison.submissionB = temp;
        if (plagiarismComparison?.matches) {
          plagiarismComparison.matches.forEach((match) => {
            const tempStart = match.startA;
            match.startA = match.startB;
            match.startB = tempStart;
          });
        }
      }
      parseTextMatches(plagComparison) {
        if (plagComparison.matches) {
          const matchesA = plagComparison.matches.map((match) => new SimpleMatch(match.startA, match.length)).sort((m1, m2) => m1.start - m2.start);
          const matchesB = plagComparison.matches.map((match) => new SimpleMatch(match.startB, match.length)).sort((m1, m2) => m1.start - m2.start);
          this.matchesA = this.mapMatchesToElements(matchesA, plagComparison.submissionA);
          this.matchesB = this.mapMatchesToElements(matchesB, plagComparison.submissionB);
        } else {
          this.matchesA = /* @__PURE__ */ new Map();
          this.matchesB = /* @__PURE__ */ new Map();
        }
      }
      mapMatchesToElements(matches, submission) {
        const filesToMatchedElements = /* @__PURE__ */ new Map();
        matches.forEach((match) => {
          if (match.length === 0) {
            return;
          }
          const file = submission.elements[match.start]?.file || "none";
          if (!filesToMatchedElements.has(file)) {
            filesToMatchedElements.set(file, []);
          }
          const fileMatches = filesToMatchedElements.get(file);
          fileMatches.push(new FromToElement(submission.elements[match.start], submission.elements[match.start + match.length - 1]));
        });
        return filesToMatchedElements;
      }
      getModelingSubmissionA() {
        return this.plagiarismComparison.submissionA;
      }
      getModelingSubmissionB() {
        return this.plagiarismComparison.submissionB;
      }
      getTextSubmissionA() {
        return this.plagiarismComparison.submissionA;
      }
      getTextSubmissionB() {
        return this.plagiarismComparison.submissionB;
      }
      handleSplitControl(pane) {
        switch (pane) {
          case "left": {
            this.split.collapse(1);
            return;
          }
          case "right": {
            this.split.collapse(0);
            return;
          }
          case "even": {
            this.split.setSizes([50, 50]);
          }
        }
      }
      static \u0275fac = function PlagiarismSplitViewComponent_Factory(t) {
        return new (t || _PlagiarismSplitViewComponent)(i07.\u0275\u0275directiveInject(PlagiarismCasesService));
      };
      static \u0275cmp = i07.\u0275\u0275defineComponent({ type: _PlagiarismSplitViewComponent, selectors: [["jhi-plagiarism-split-view"]], viewQuery: function PlagiarismSplitViewComponent_Query(rf, ctx) {
        if (rf & 1) {
          i07.\u0275\u0275viewQuery(SplitPaneDirective, 5);
        }
        if (rf & 2) {
          let _t;
          i07.\u0275\u0275queryRefresh(_t = i07.\u0275\u0275loadQuery()) && (ctx.panes = _t);
        }
      }, inputs: { comparison: "comparison", exercise: "exercise", splitControlSubject: "splitControlSubject", sortByStudentLogin: "sortByStudentLogin" }, features: [i07.\u0275\u0275NgOnChangesFeature], decls: 11, vars: 2, consts: [[1, "plagiarism-split-view"], ["jhiPane", "", 1, "plagiarism-split-pane"], [3, "exercise", "plagiarismSubmission"], [3, "exercise", "matches", "plagiarismSubmission"]], template: function PlagiarismSplitViewComponent_Template(rf, ctx) {
        if (rf & 1) {
          i07.\u0275\u0275elementStart(0, "div", 0);
          i07.\u0275\u0275text(1, "\n    ");
          i07.\u0275\u0275elementStart(2, "div", 1);
          i07.\u0275\u0275text(3, "\n        ");
          i07.\u0275\u0275template(4, PlagiarismSplitViewComponent_Conditional_4_Template, 3, 2);
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(5, "\n    ");
          i07.\u0275\u0275elementStart(6, "div", 1);
          i07.\u0275\u0275text(7, "\n        ");
          i07.\u0275\u0275template(8, PlagiarismSplitViewComponent_Conditional_8_Template, 3, 2);
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(9, "\n");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(10, "\n");
        }
        if (rf & 2) {
          i07.\u0275\u0275advance(4);
          i07.\u0275\u0275conditional(4, ctx.plagiarismComparison ? 4 : -1);
          i07.\u0275\u0275advance(4);
          i07.\u0275\u0275conditional(8, ctx.plagiarismComparison ? 8 : -1);
        }
      }, dependencies: [SplitPaneDirective, ModelingSubmissionViewerComponent, TextSubmissionViewerComponent], styles: ["\n\n[_nghost-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  flex-grow: 1;\n  overflow: hidden;\n}\n.plagiarism-split-view[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: row;\n  flex-grow: 1;\n  height: 100%;\n  overflow: hidden;\n}\n.plagiarism-split-view[_ngcontent-%COMP%]   .plagiarism-split-pane[_ngcontent-%COMP%] {\n  padding-top: 30px;\n  position: relative;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1zcGxpdC12aWV3L3BsYWdpYXJpc20tc3BsaXQtdmlldy5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiQGltcG9ydCAnc3JjL21haW4vd2ViYXBwL2NvbnRlbnQvc2Nzcy9hcnRlbWlzLXZhcmlhYmxlcyc7XG5cbjpob3N0IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgZmxleC1ncm93OiAxO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi5wbGFnaWFyaXNtLXNwbGl0LXZpZXcge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICBmbGV4LWdyb3c6IDE7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG5cbiAgICAucGxhZ2lhcmlzbS1zcGxpdC1wYW5lIHtcbiAgICAgICAgcGFkZGluZy10b3A6IDMwcHg7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRUE7QUFDSSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxhQUFBO0FBQ0EsWUFBQTs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLGtCQUFBO0FBQ0EsYUFBQTtBQUNBLFVBQUE7QUFDQSxZQUFBOztBQUVBLENBUEosc0JBT0ksQ0FBQTtBQUNJLGVBQUE7QUFDQSxZQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i07.\u0275setClassDebugInfo(PlagiarismSplitViewComponent, { className: "PlagiarismSplitViewComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/plagiarism-details/plagiarism-details.component.ts
import { Component as Component6, Input as Input6 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject as Subject3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i08 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function PlagiarismDetailsComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n    ");
    i08.\u0275\u0275elementStart(1, "div", 0);
    i08.\u0275\u0275text(2, "\n        ");
    i08.\u0275\u0275element(3, "jhi-plagiarism-header", 1);
    i08.\u0275\u0275text(4, "\n        ");
    i08.\u0275\u0275element(5, "jhi-plagiarism-split-view", 2);
    i08.\u0275\u0275text(6, "\n    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275property("splitControlSubject", ctx_r0.splitControlSubject)("exercise", ctx_r0.exercise)("comparison", ctx_r0.comparison);
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275property("comparison", ctx_r0.comparison)("exercise", ctx_r0.exercise)("splitControlSubject", ctx_r0.splitControlSubject);
  }
}
var PlagiarismDetailsComponent;
var init_plagiarism_details_component = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/plagiarism-details/plagiarism-details.component.ts"() {
    init_PlagiarismComparison();
    init_exercise_model();
    init_plagiarism_header_component();
    init_plagiarism_split_view_component();
    PlagiarismDetailsComponent = class _PlagiarismDetailsComponent {
      comparison;
      exercise;
      splitControlSubject = new Subject3();
      static \u0275fac = function PlagiarismDetailsComponent_Factory(t) {
        return new (t || _PlagiarismDetailsComponent)();
      };
      static \u0275cmp = i08.\u0275\u0275defineComponent({ type: _PlagiarismDetailsComponent, selectors: [["jhi-plagiarism-details"]], inputs: { comparison: "comparison", exercise: "exercise" }, decls: 1, vars: 1, consts: [[1, "plagiarism-details"], [3, "splitControlSubject", "exercise", "comparison"], [3, "comparison", "exercise", "splitControlSubject"]], template: function PlagiarismDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i08.\u0275\u0275template(0, PlagiarismDetailsComponent_Conditional_0_Template, 8, 6);
        }
        if (rf & 2) {
          i08.\u0275\u0275conditional(0, ctx.comparison ? 0 : -1);
        }
      }, dependencies: [PlagiarismHeaderComponent, PlagiarismSplitViewComponent], styles: ["\n\n[_nghost-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  flex-grow: 1;\n  overflow: hidden;\n}\n.plagiarism-details[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  flex-grow: 1;\n  height: 100%;\n  overflow: hidden;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1kZXRhaWxzL3BsYWdpYXJpc20tZGV0YWlscy5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiOmhvc3Qge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBmbGV4LWdyb3c6IDE7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnBsYWdpYXJpc20tZGV0YWlscyB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQTtBQUNJLFdBQUE7QUFDQSxrQkFBQTtBQUNBLGFBQUE7QUFDQSxZQUFBOztBQUdKLENBQUE7QUFDSSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxhQUFBO0FBQ0EsVUFBQTtBQUNBLFlBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassDebugInfo(PlagiarismDetailsComponent, { className: "PlagiarismDetailsComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/plagiarism-sidebar/plagiarism-sidebar.component.ts
import { Component as Component7, EventEmitter as EventEmitter2, Input as Input7, Output as Output2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faArrowLeft, faArrowRight, faChevronRight, faExclamationTriangle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i09 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i14 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i23 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function PlagiarismSidebarComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n        ");
    i09.\u0275\u0275elementStart(1, "div", 7);
    i09.\u0275\u0275text(2, "\n            ");
    i09.\u0275\u0275element(3, "fa-icon", 8);
    i09.\u0275\u0275text(4, "\n            ");
    i09.\u0275\u0275elementStart(5, "span");
    i09.\u0275\u0275text(6);
    i09.\u0275\u0275pipe(7, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(8, "\n        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(9, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("icon", ctx_r0.faExclamationTriangle);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(7, 2, "artemisApp.plagiarism.casesFiltered"));
  }
}
function PlagiarismSidebarComponent_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n        ");
    i09.\u0275\u0275elementStart(1, "div", 7);
    i09.\u0275\u0275text(2, "\n            ");
    i09.\u0275\u0275element(3, "fa-icon", 8);
    i09.\u0275\u0275text(4, "\n            ");
    i09.\u0275\u0275elementStart(5, "span");
    i09.\u0275\u0275text(6);
    i09.\u0275\u0275pipe(7, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(8, "\n        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(9, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("icon", ctx_r1.faExclamationTriangle);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(7, 2, "artemisApp.plagiarism.casesTrimmed"));
  }
}
function PlagiarismSidebarComponent_Conditional_13_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = i09.\u0275\u0275getCurrentView();
    i09.\u0275\u0275text(0, "\n                ");
    i09.\u0275\u0275elementStart(1, "li", 10);
    i09.\u0275\u0275listener("click", function PlagiarismSidebarComponent_Conditional_13_For_4_Template_li_click_1_listener() {
      const restoredCtx = i09.\u0275\u0275restoreView(_r11);
      const comparison_r5 = restoredCtx.$implicit;
      const ctx_r10 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r10.selectIndex.emit(comparison_r5.id));
    });
    i09.\u0275\u0275text(2, "\n                    ");
    i09.\u0275\u0275elementStart(3, "div", 11);
    i09.\u0275\u0275text(4, "\n                        ");
    i09.\u0275\u0275element(5, "span", 12);
    i09.\u0275\u0275text(6, "\n                        ");
    i09.\u0275\u0275elementStart(7, "div", 13);
    i09.\u0275\u0275text(8, "\n                            ");
    i09.\u0275\u0275elementStart(9, "span", 14);
    i09.\u0275\u0275text(10);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(11, "\n                            ");
    i09.\u0275\u0275elementStart(12, "span", 15);
    i09.\u0275\u0275text(13, "\n                                ");
    i09.\u0275\u0275elementStart(14, "span");
    i09.\u0275\u0275text(15);
    i09.\u0275\u0275pipe(16, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(17, "\n                                ");
    i09.\u0275\u0275elementStart(18, "span");
    i09.\u0275\u0275text(19);
    i09.\u0275\u0275pipe(20, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(21, "\n                            ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(22, "\n                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(23, "\n                    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(24, "\n                    ");
    i09.\u0275\u0275elementStart(25, "span", 16);
    i09.\u0275\u0275text(26);
    i09.\u0275\u0275pipe(27, "number");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(28, "\n                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(29, "\n            ");
  }
  if (rf & 2) {
    const comparison_r5 = ctx.$implicit;
    const idx_r6 = ctx.$index;
    const ctx_r4 = i09.\u0275\u0275nextContext(2);
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275classProp("selected", !ctx_r4.showRunDetails && comparison_r5.id === ctx_r4.activeID);
    i09.\u0275\u0275advance(4);
    i09.\u0275\u0275property("ngClass", i09.\u0275\u0275pureFunction2(14, _c03, comparison_r5.status === ctx_r4.CONFIRMED, comparison_r5.status === ctx_r4.DENIED));
    i09.\u0275\u0275advance(5);
    i09.\u0275\u0275textInterpolate1(" #", ctx_r4.getPagedIndex(idx_r6) + 1 + ctx_r4.offset, " ");
    i09.\u0275\u0275advance(5);
    i09.\u0275\u0275textInterpolate1("", comparison_r5.submissionA.studentLogin || i09.\u0275\u0275pipeBind1(16, 7, "artemisApp.plagiarism.unknownStudent"), ", ");
    i09.\u0275\u0275advance(4);
    i09.\u0275\u0275textInterpolate(comparison_r5.submissionB.studentLogin || i09.\u0275\u0275pipeBind1(20, 9, "artemisApp.plagiarism.unknownStudent"));
    i09.\u0275\u0275advance(7);
    i09.\u0275\u0275textInterpolate1("(", i09.\u0275\u0275pipeBind2(27, 11, comparison_r5.similarity || 0, "1.2-2"), " %)");
  }
}
function PlagiarismSidebarComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n        ");
    i09.\u0275\u0275elementStart(1, "ul", 9);
    i09.\u0275\u0275text(2, "\n            ");
    i09.\u0275\u0275repeaterCreate(3, PlagiarismSidebarComponent_Conditional_13_For_4_Template, 30, 17, null, null, i09.\u0275\u0275repeaterTrackByIdentity);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r2 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275repeater(ctx_r2.pagedComparisons);
  }
}
function PlagiarismSidebarComponent_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n        ");
    i09.\u0275\u0275elementStart(1, "div", 17);
    i09.\u0275\u0275text(2);
    i09.\u0275\u0275pipe(3, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(4, "\n    ");
  }
  if (rf & 2) {
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275textInterpolate1("\n            ", i09.\u0275\u0275pipeBind1(3, 1, "artemisApp.plagiarism.notFound"), "\n        ");
  }
}
var _c03, PlagiarismSidebarComponent;
var init_plagiarism_sidebar_component = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/plagiarism-sidebar/plagiarism-sidebar.component.ts"() {
    init_PlagiarismStatus();
    init_artemis_translate_pipe();
    _c03 = (a0, a1) => ({ confirmed: a0, denied: a1 });
    PlagiarismSidebarComponent = class _PlagiarismSidebarComponent {
      activeID;
      comparisons;
      casesFiltered = false;
      offset = 0;
      showRunDetails;
      showRunDetailsChange = new EventEmitter2();
      selectIndex = new EventEmitter2();
      CONFIRMED = PlagiarismStatus.CONFIRMED;
      DENIED = PlagiarismStatus.DENIED;
      faExclamationTriangle = faExclamationTriangle;
      currentPage = 0;
      numberOfPages = 0;
      pagedComparisons;
      pageSize = 100;
      faChevronRight = faChevronRight;
      faArrowLeft = faArrowLeft;
      faArrowRight = faArrowRight;
      ngOnChanges(changes) {
        if (changes.comparisons) {
          const comparisons = changes.comparisons.currentValue;
          this.currentPage = 0;
          if (!comparisons) {
            this.numberOfPages = 1;
          } else {
            this.numberOfPages = this.computeNumberOfPages(comparisons.length);
          }
          this.pagedComparisons = this.getPagedComparisons();
        }
      }
      displayRunDetails() {
        this.showRunDetailsChange.emit(true);
      }
      computeNumberOfPages(totalComparisons) {
        return Math.ceil(totalComparisons / this.pageSize);
      }
      getPagedComparisons() {
        const startIndex = this.currentPage * this.pageSize;
        return this.comparisons?.slice(startIndex, startIndex + this.pageSize);
      }
      getPagedIndex(idx) {
        return idx + this.currentPage * this.pageSize;
      }
      handlePageLeft() {
        if (this.currentPage === 0) {
          return;
        }
        this.currentPage--;
        this.pagedComparisons = this.getPagedComparisons();
      }
      handlePageRight() {
        if (this.currentPage + 1 >= this.numberOfPages) {
          return;
        }
        this.currentPage++;
        this.pagedComparisons = this.getPagedComparisons();
      }
      static \u0275fac = function PlagiarismSidebarComponent_Factory(t) {
        return new (t || _PlagiarismSidebarComponent)();
      };
      static \u0275cmp = i09.\u0275\u0275defineComponent({ type: _PlagiarismSidebarComponent, selectors: [["jhi-plagiarism-sidebar"]], inputs: { activeID: "activeID", comparisons: "comparisons", casesFiltered: "casesFiltered", offset: "offset", showRunDetails: "showRunDetails" }, outputs: { showRunDetailsChange: "showRunDetailsChange", selectIndex: "selectIndex" }, features: [i09.\u0275\u0275NgOnChangesFeature], decls: 32, vars: 15, consts: [[1, "plagiarism-sidebar"], [1, "plagiarism-info-tab", 3, "click"], [3, "icon"], [1, "plagiarism-paging"], [1, "plagiarism-paging-left", 3, "click"], [1, "plagiarism-paging-center"], [1, "plagiarism-paging-right", 3, "click"], [1, "filter-disclaimer"], [1, "text-warning", "disclaimer-icon", 3, "icon"], [1, "plagiarism-list"], [1, "plagiarism-list-item", 3, "click"], [1, "plagiarism-list-item-content"], [1, "plagiarism-status-indicator", 3, "ngClass"], [1, "plagiarism-list-item-info"], [1, "plagiarism-name"], [1, "plagiarism-list-item-students"], [1, "plagiarism-percentage"], [1, "plagiarism-empty"]], template: function PlagiarismSidebarComponent_Template(rf, ctx) {
        if (rf & 1) {
          i09.\u0275\u0275elementStart(0, "aside", 0);
          i09.\u0275\u0275text(1, "\n    ");
          i09.\u0275\u0275elementStart(2, "div", 1);
          i09.\u0275\u0275listener("click", function PlagiarismSidebarComponent_Template_div_click_2_listener() {
            return ctx.displayRunDetails();
          });
          i09.\u0275\u0275text(3, "\n        ");
          i09.\u0275\u0275elementStart(4, "span");
          i09.\u0275\u0275text(5, "Run details");
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(6, "\n        ");
          i09.\u0275\u0275element(7, "fa-icon", 2);
          i09.\u0275\u0275text(8, "\n    ");
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(9, "\n    ");
          i09.\u0275\u0275template(10, PlagiarismSidebarComponent_Conditional_10_Template, 10, 4);
          i09.\u0275\u0275text(11, "\n    ");
          i09.\u0275\u0275template(12, PlagiarismSidebarComponent_Conditional_12_Template, 10, 4)(13, PlagiarismSidebarComponent_Conditional_13_Template, 6, 0)(14, PlagiarismSidebarComponent_Conditional_14_Template, 5, 3);
          i09.\u0275\u0275elementStart(15, "div", 3);
          i09.\u0275\u0275text(16, "\n        ");
          i09.\u0275\u0275elementStart(17, "div", 4);
          i09.\u0275\u0275listener("click", function PlagiarismSidebarComponent_Template_div_click_17_listener() {
            return ctx.handlePageLeft();
          });
          i09.\u0275\u0275text(18, "\n            ");
          i09.\u0275\u0275element(19, "fa-icon", 2);
          i09.\u0275\u0275text(20, "\n        ");
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(21, "\n        ");
          i09.\u0275\u0275elementStart(22, "div", 5);
          i09.\u0275\u0275text(23);
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(24, "\n        ");
          i09.\u0275\u0275elementStart(25, "div", 6);
          i09.\u0275\u0275listener("click", function PlagiarismSidebarComponent_Template_div_click_25_listener() {
            return ctx.handlePageRight();
          });
          i09.\u0275\u0275text(26, "\n            ");
          i09.\u0275\u0275element(27, "fa-icon", 2);
          i09.\u0275\u0275text(28, "\n        ");
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(29, "\n    ");
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(30, "\n");
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(31, "\n");
        }
        if (rf & 2) {
          i09.\u0275\u0275advance(2);
          i09.\u0275\u0275classProp("selected", ctx.showRunDetails);
          i09.\u0275\u0275advance(5);
          i09.\u0275\u0275property("icon", ctx.faChevronRight);
          i09.\u0275\u0275advance(3);
          i09.\u0275\u0275conditional(10, ctx.casesFiltered ? 10 : -1);
          i09.\u0275\u0275advance(2);
          i09.\u0275\u0275conditional(12, (ctx.comparisons == null ? null : ctx.comparisons.length) === 100 ? 12 : -1);
          i09.\u0275\u0275advance(1);
          i09.\u0275\u0275conditional(13, ctx.comparisons && ctx.comparisons.length ? 13 : -1);
          i09.\u0275\u0275advance(1);
          i09.\u0275\u0275conditional(14, !ctx.comparisons || !ctx.comparisons.length ? 14 : -1);
          i09.\u0275\u0275advance(3);
          i09.\u0275\u0275classProp("disabled", ctx.currentPage === 0);
          i09.\u0275\u0275advance(2);
          i09.\u0275\u0275property("icon", ctx.faArrowLeft);
          i09.\u0275\u0275advance(4);
          i09.\u0275\u0275textInterpolate2("", ctx.currentPage + 1, "/", ctx.numberOfPages, "");
          i09.\u0275\u0275advance(2);
          i09.\u0275\u0275classProp("disabled", ctx.currentPage + 1 >= ctx.numberOfPages);
          i09.\u0275\u0275advance(2);
          i09.\u0275\u0275property("icon", ctx.faArrowRight);
        }
      }, dependencies: [i14.NgClass, i23.FaIconComponent, i14.DecimalPipe, ArtemisTranslatePipe], styles: ["\n\n.plagiarism-sidebar[_ngcontent-%COMP%] {\n  border-right: 1px solid var(--body-bg);\n  display: flex;\n  flex-direction: column;\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  top: 0;\n  width: 240px;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .filter-disclaimer[_ngcontent-%COMP%] {\n  padding: 0.75rem;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .filter-disclaimer[_ngcontent-%COMP%]   .disclaimer-icon[_ngcontent-%COMP%] {\n  margin-right: 0.5rem;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-paging[_ngcontent-%COMP%] {\n  border-top: 1px solid var(--body-bg);\n  display: flex;\n  flex-shrink: 0;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-paging-left[_ngcontent-%COMP%], .plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-paging-right[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n  padding: 0.75rem;\n  opacity: 0.5;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-paging-left.disabled[_ngcontent-%COMP%], .plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-paging-right.disabled[_ngcontent-%COMP%] {\n  opacity: 0.2;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-paging-left[_ngcontent-%COMP%]:hover:not(.disabled), .plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-paging-right[_ngcontent-%COMP%]:hover:not(.disabled) {\n  cursor: pointer;\n  opacity: 0.8;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-paging-center[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n  flex-grow: 1;\n  font-weight: bold;\n  justify-content: center;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-info-tab[_ngcontent-%COMP%] {\n  border-bottom: 1px solid var(--body-bg);\n  flex-shrink: 0;\n  cursor: pointer;\n  padding: 0.75rem;\n  display: flex;\n  justify-content: space-between;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-info-tab.selected[_ngcontent-%COMP%] {\n  background-color: rgba(135, 206, 250, 0.5);\n  font-weight: bold;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-info-tab[_ngcontent-%COMP%]:hover {\n  background-color: lightskyblue;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-list[_ngcontent-%COMP%] {\n  flex-grow: 1;\n  overflow-y: auto;\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-list-item[_ngcontent-%COMP%] {\n  align-items: center;\n  cursor: pointer;\n  display: flex;\n  justify-content: space-between;\n  padding: 0.75rem;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-list-item-students[_ngcontent-%COMP%] {\n  font-size: 10px;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-list-item-content[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-list-item-info[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-list-item.selected[_ngcontent-%COMP%] {\n  background-color: rgba(135, 206, 250, 0.5);\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-list-item.selected[_ngcontent-%COMP%]   .plagiarism-name[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-list-item[_ngcontent-%COMP%]:hover {\n  background-color: lightskyblue;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-empty[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n  flex-grow: 1;\n  justify-content: center;\n  opacity: 0.5;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-status-indicator[_ngcontent-%COMP%] {\n  background-color: var(--body-bg);\n  border-radius: 50%;\n  flex-shrink: 0;\n  height: 8px;\n  margin-right: 0.75rem;\n  width: 8px;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-status-indicator.confirmed[_ngcontent-%COMP%] {\n  background-color: green;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-status-indicator.denied[_ngcontent-%COMP%] {\n  background-color: red;\n}\n.plagiarism-sidebar[_ngcontent-%COMP%]   .plagiarism-percentage[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1zaWRlYmFyL3BsYWdpYXJpc20tc2lkZWJhci5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLnBsYWdpYXJpc20tc2lkZWJhciB7XG4gICAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgdmFyKC0tYm9keS1iZyk7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBib3R0b206IDA7XG4gICAgbGVmdDogMDtcbiAgICB0b3A6IDA7XG4gICAgd2lkdGg6IDI0MHB4O1xuXG4gICAgLmZpbHRlci1kaXNjbGFpbWVyIHtcbiAgICAgICAgcGFkZGluZzogMC43NXJlbTtcblxuICAgICAgICAuZGlzY2xhaW1lci1pY29uIHtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMC41cmVtO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnBsYWdpYXJpc20tcGFnaW5nIHtcbiAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkIHZhcigtLWJvZHktYmcpO1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LXNocmluazogMDtcblxuICAgICAgICAmLWxlZnQsXG4gICAgICAgICYtcmlnaHQge1xuICAgICAgICAgICAgZmxleC1zaHJpbms6IDA7XG4gICAgICAgICAgICBwYWRkaW5nOiAwLjc1cmVtO1xuICAgICAgICAgICAgb3BhY2l0eTogMC41O1xuXG4gICAgICAgICAgICAmLmRpc2FibGVkIHtcbiAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLjI7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICY6aG92ZXI6bm90KC5kaXNhYmxlZCkge1xuICAgICAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLjg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAmLWNlbnRlciB7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGZsZXgtZ3JvdzogMTtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAucGxhZ2lhcmlzbS1pbmZvLXRhYiB7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1ib2R5LWJnKTtcbiAgICAgICAgZmxleC1zaHJpbms6IDA7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgcGFkZGluZzogMC43NXJlbTtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXG4gICAgICAgICYuc2VsZWN0ZWQge1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnRpemUobGlnaHRza3libHVlLCAwLjUpO1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgIH1cblxuICAgICAgICAmOmhvdmVyIHtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0c2t5Ymx1ZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5wbGFnaWFyaXNtLWxpc3Qge1xuICAgICAgICBmbGV4LWdyb3c6IDE7XG4gICAgICAgIG92ZXJmbG93LXk6IGF1dG87XG4gICAgICAgIGxpc3Qtc3R5bGU6IG5vbmU7XG4gICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgcGFkZGluZzogMDtcblxuICAgICAgICAmLWl0ZW0ge1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgICAgICBwYWRkaW5nOiAwLjc1cmVtO1xuXG4gICAgICAgICAgICAmLXN0dWRlbnRzIHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICYtY29udGVudCB7XG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAmLWluZm8ge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgJi5zZWxlY3RlZCB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnRpemUobGlnaHRza3libHVlLCAwLjUpO1xuXG4gICAgICAgICAgICAgICAgLnBsYWdpYXJpc20tbmFtZSB7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgJjpob3ZlciB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRza3libHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnBsYWdpYXJpc20tZW1wdHkge1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWdyb3c6IDE7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBvcGFjaXR5OiAwLjU7XG4gICAgfVxuXG4gICAgLnBsYWdpYXJpc20tc3RhdHVzLWluZGljYXRvciB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWJvZHktYmcpO1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgIGZsZXgtc2hyaW5rOiAwO1xuICAgICAgICBoZWlnaHQ6IDhweDtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAwLjc1cmVtO1xuICAgICAgICB3aWR0aDogOHB4O1xuXG4gICAgICAgICYuY29uZmlybWVkIHtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IGdyZWVuO1xuICAgICAgICB9XG5cbiAgICAgICAgJi5kZW5pZWQge1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmVkO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnBsYWdpYXJpc20tcGVyY2VudGFnZSB7XG4gICAgICAgIGZsZXgtc2hyaW5rOiAwO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksZ0JBQUEsSUFBQSxNQUFBLElBQUE7QUFDQSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxZQUFBO0FBQ0EsVUFBQTtBQUNBLFFBQUE7QUFDQSxPQUFBO0FBQ0EsU0FBQTs7QUFFQSxDQVZKLG1CQVVJLENBQUE7QUFDSSxXQUFBOztBQUVBLENBYlIsbUJBYVEsQ0FISixrQkFHSSxDQUFBO0FBQ0ksZ0JBQUE7O0FBSVIsQ0FsQkosbUJBa0JJLENBQUE7QUFDSSxjQUFBLElBQUEsTUFBQSxJQUFBO0FBQ0EsV0FBQTtBQUNBLGVBQUE7O0FBRUEsQ0F2QlIsbUJBdUJRLENBQUE7QUFBQSxDQXZCUixtQkF1QlEsQ0FBQTtBQUVJLGVBQUE7QUFDQSxXQUFBO0FBQ0EsV0FBQTs7QUFFQSxDQTdCWixtQkE2QlksQ0FOSixzQkFNSSxDQUFBO0FBQUEsQ0E3QlosbUJBNkJZLENBTkosdUJBTUksQ0FBQTtBQUNJLFdBQUE7O0FBR0osQ0FqQ1osbUJBaUNZLENBVkosc0JBVUksTUFBQSxLQUFBLENBSkE7QUFJQSxDQWpDWixtQkFpQ1ksQ0FWSix1QkFVSSxNQUFBLEtBQUEsQ0FKQTtBQUtJLFVBQUE7QUFDQSxXQUFBOztBQUlSLENBdkNSLG1CQXVDUSxDQUFBO0FBQ0ksZUFBQTtBQUNBLFdBQUE7QUFDQSxhQUFBO0FBQ0EsZUFBQTtBQUNBLG1CQUFBOztBQUlSLENBaERKLG1CQWdESSxDQUFBO0FBQ0ksaUJBQUEsSUFBQSxNQUFBLElBQUE7QUFDQSxlQUFBO0FBQ0EsVUFBQTtBQUNBLFdBQUE7QUFDQSxXQUFBO0FBQ0EsbUJBQUE7O0FBRUEsQ0F4RFIsbUJBd0RRLENBUkosbUJBUUksQ0FBQTtBQUNJLG9CQUFBLEtBQUEsR0FBQSxFQUFBLEdBQUEsRUFBQSxHQUFBLEVBQUE7QUFDQSxlQUFBOztBQUdKLENBN0RSLG1CQTZEUSxDQWJKLG1CQWFJO0FBQ0ksb0JBQUE7O0FBSVIsQ0FsRUosbUJBa0VJLENBQUE7QUFDSSxhQUFBO0FBQ0EsY0FBQTtBQUNBLGNBQUE7QUFDQSxVQUFBO0FBQ0EsV0FBQTs7QUFFQSxDQXpFUixtQkF5RVEsQ0FBQTtBQUNJLGVBQUE7QUFDQSxVQUFBO0FBQ0EsV0FBQTtBQUNBLG1CQUFBO0FBQ0EsV0FBQTs7QUFFQSxDQWhGWixtQkFnRlksQ0FBQTtBQUNJLGFBQUE7O0FBR0osQ0FwRlosbUJBb0ZZLENBQUE7QUFDSSxlQUFBO0FBQ0EsV0FBQTs7QUFHSixDQXpGWixtQkF5RlksQ0FBQTtBQUNJLFdBQUE7QUFDQSxrQkFBQTs7QUFHSixDQTlGWixtQkE4RlksQ0FyQkosb0JBcUJJLENBdENKO0FBdUNRLG9CQUFBLEtBQUEsR0FBQSxFQUFBLEdBQUEsRUFBQSxHQUFBLEVBQUE7O0FBRUEsQ0FqR2hCLG1CQWlHZ0IsQ0F4QlIsb0JBd0JRLENBekNSLFNBeUNRLENBQUE7QUFDSSxlQUFBOztBQUlSLENBdEdaLG1CQXNHWSxDQTdCSixvQkE2Qkk7QUFDSSxvQkFBQTs7QUFLWixDQTVHSixtQkE0R0ksQ0FBQTtBQUNJLGVBQUE7QUFDQSxXQUFBO0FBQ0EsYUFBQTtBQUNBLG1CQUFBO0FBQ0EsV0FBQTs7QUFHSixDQXBISixtQkFvSEksQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxpQkFBQTtBQUNBLGVBQUE7QUFDQSxVQUFBO0FBQ0EsZ0JBQUE7QUFDQSxTQUFBOztBQUVBLENBNUhSLG1CQTRIUSxDQVJKLDJCQVFJLENBQUE7QUFDSSxvQkFBQTs7QUFHSixDQWhJUixtQkFnSVEsQ0FaSiwyQkFZSSxDQUFBO0FBQ0ksb0JBQUE7O0FBSVIsQ0FySUosbUJBcUlJLENBQUE7QUFDSSxlQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i09.\u0275setClassDebugInfo(PlagiarismSidebarComponent, { className: "PlagiarismSidebarComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/plagiarism-inspector/plagiarism-inspector.service.ts
import { Injectable as Injectable3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i010 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var PlagiarismInspectorService;
var init_plagiarism_inspector_service = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/plagiarism-inspector/plagiarism-inspector.service.ts"() {
    PlagiarismInspectorService = class _PlagiarismInspectorService {
      filterComparisons(range, comparisons) {
        if (!comparisons) {
          return [];
        }
        let filterFunction;
        if (range.upperBound === 100) {
          filterFunction = (comparison) => comparison.similarity >= range.lowerBound && comparison.similarity <= range.upperBound;
        } else {
          filterFunction = (comparison) => comparison.similarity >= range.lowerBound && comparison.similarity < range.upperBound;
        }
        return comparisons.filter(filterFunction);
      }
      static \u0275fac = function PlagiarismInspectorService_Factory(t) {
        return new (t || _PlagiarismInspectorService)();
      };
      static \u0275prov = i010.\u0275\u0275defineInjectable({ token: _PlagiarismInspectorService, factory: _PlagiarismInspectorService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismResultDTO.ts
var init_PlagiarismResultDTO = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismResultDTO.ts"() {
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/plagiarism-run-details/plagiarism-run-details.component.ts
import { Component as Component8, EventEmitter as EventEmitter3, Input as Input8, Output as Output3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i011 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i33 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
function PlagiarismRunDetailsComponent_ng_template_80_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                    ");
    i011.\u0275\u0275elementStart(1, "b");
    i011.\u0275\u0275text(2);
    i011.\u0275\u0275pipe(3, "artemisTranslate");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(4, " ");
    i011.\u0275\u0275element(5, "br");
    i011.\u0275\u0275text(6, "\n                    ");
    i011.\u0275\u0275elementStart(7, "span");
    i011.\u0275\u0275text(8);
    i011.\u0275\u0275pipe(9, "artemisTranslate");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(10, " ");
    i011.\u0275\u0275element(11, "br");
    i011.\u0275\u0275text(12, "\n                    ");
    i011.\u0275\u0275elementStart(13, "span");
    i011.\u0275\u0275text(14);
    i011.\u0275\u0275pipe(15, "artemisTranslate");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(16, " ");
    i011.\u0275\u0275element(17, "br");
    i011.\u0275\u0275text(18, "\n                    ");
    i011.\u0275\u0275elementStart(19, "span");
    i011.\u0275\u0275text(20);
    i011.\u0275\u0275pipe(21, "artemisTranslate");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(22, " ");
    i011.\u0275\u0275element(23, "br");
    i011.\u0275\u0275text(24, "\n                    ");
    i011.\u0275\u0275elementStart(25, "span");
    i011.\u0275\u0275text(26);
    i011.\u0275\u0275pipe(27, "artemisTranslate");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(28, " ");
    i011.\u0275\u0275element(29, "br");
    i011.\u0275\u0275text(30, "\n                    ");
    i011.\u0275\u0275elementStart(31, "b");
    i011.\u0275\u0275text(32);
    i011.\u0275\u0275pipe(33, "artemisTranslate");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(34, "\n                ");
  }
  if (rf & 2) {
    const model_r3 = ctx.model;
    const ctx_r1 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(2);
    i011.\u0275\u0275textInterpolate1("", i011.\u0275\u0275pipeBind2(3, 6, "artemisApp.plagiarism.numberIdentifiedPairs", i011.\u0275\u0275pureFunction1(24, _c04, model_r3.value)), " ");
    i011.\u0275\u0275advance(6);
    i011.\u0275\u0275textInterpolate1(" ", i011.\u0275\u0275pipeBind2(9, 9, "artemisApp.plagiarism.confirmed", i011.\u0275\u0275pureFunction1(26, _c04, ctx_r1.getBucketDTO(model_r3.label).confirmed)), "");
    i011.\u0275\u0275advance(6);
    i011.\u0275\u0275textInterpolate1(" ", i011.\u0275\u0275pipeBind2(15, 12, "artemisApp.plagiarism.denied", i011.\u0275\u0275pureFunction1(28, _c04, ctx_r1.getBucketDTO(model_r3.label).denied)), "");
    i011.\u0275\u0275advance(6);
    i011.\u0275\u0275textInterpolate1(" ", i011.\u0275\u0275pipeBind2(21, 15, "artemisApp.plagiarism.open", i011.\u0275\u0275pureFunction1(30, _c04, ctx_r1.getBucketDTO(model_r3.label).open)), "");
    i011.\u0275\u0275advance(6);
    i011.\u0275\u0275textInterpolate(i011.\u0275\u0275pipeBind2(27, 18, "artemisApp.plagiarism.withSimilarity", i011.\u0275\u0275pureFunction1(32, _c1, model_r3.name)));
    i011.\u0275\u0275advance(6);
    i011.\u0275\u0275textInterpolate(i011.\u0275\u0275pipeBind2(33, 21, "artemisApp.plagiarism.portionOfAllCases", i011.\u0275\u0275pureFunction1(34, _c2, ctx_r1.totalDetectedPlagiarisms > 0 ? ctx_r1.round(model_r3.value * 100 / ctx_r1.totalDetectedPlagiarisms, 2) : 0)));
  }
}
var _c04, _c1, _c2, _c3, PlagiarismRunDetailsComponent;
var init_plagiarism_run_details_component = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/plagiarism-run-details/plagiarism-run-details.component.ts"() {
    init_plagiarism_and_tutor_effort_directive();
    init_statistics_model();
    init_utils();
    init_plagiarism_inspector_service();
    init_PlagiarismStatus();
    init_PlagiarismResultDTO();
    init_plagiarism_inspector_service();
    init_help_icon_component();
    init_artemis_translate_pipe();
    _c04 = (a0) => ({ amount: a0 });
    _c1 = (a0) => ({ range: a0 });
    _c2 = (a0) => ({ percentage: a0 });
    _c3 = (a0) => [a0, 400];
    PlagiarismRunDetailsComponent = class _PlagiarismRunDetailsComponent extends PlagiarismAndTutorEffortDirective {
      inspectorService;
      plagiarismResult;
      plagiarismResultStats;
      similaritySelected = new EventEmitter3();
      yScaleMax = 5;
      totalDetectedPlagiarisms;
      bucketDTOs = [];
      round = round;
      constructor(inspectorService) {
        super();
        this.inspectorService = inspectorService;
        this.ngxChartLabels = ["[0%-10%)", "[10%-20%)", "[20%-30%)", "[30%-40%)", "[40%-50%)", "[50%-60%)", "[60%-70%)", "[70%-80%)", "[80%-90%)", "[90%-100%]"];
        this.ngxColor.domain = [...Array(8).fill(GraphColors.LIGHT_BLUE), ...Array(2).fill(GraphColors.RED)];
      }
      ngOnChanges(changes) {
        if (changes.plagiarismResult) {
          this.setBucketDTOs(changes.plagiarismResult.currentValue.comparisons || []);
          this.updateChartDataSet(changes.plagiarismResult.currentValue.similarityDistribution || []);
        }
      }
      updateChartDataSet(data) {
        let ngxDataEntity;
        this.ngxData = [];
        data.forEach((value, position) => {
          ngxDataEntity = {
            name: this.ngxChartLabels[position],
            value
          };
          this.ngxData.push(ngxDataEntity);
        });
        this.totalDetectedPlagiarisms = data.reduce((number1, number2) => number1 + number2, 0);
        this.ngxData = [...this.ngxData];
      }
      setBucketDTOs(comparisons) {
        this.bucketDTOs = [];
        const steps = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90];
        let comparisonsWithinRange;
        let additionInformationEntry;
        steps.forEach((minimumSimilarity) => {
          comparisonsWithinRange = this.inspectorService.filterComparisons(new Range(minimumSimilarity, minimumSimilarity + 10), comparisons);
          additionInformationEntry = {
            confirmed: comparisonsWithinRange.filter((comparison) => comparison.status === PlagiarismStatus.CONFIRMED).length,
            denied: comparisonsWithinRange.filter((comparison) => comparison.status === PlagiarismStatus.DENIED).length,
            open: comparisonsWithinRange.filter((comparison) => comparison.status === PlagiarismStatus.NONE).length
          };
          this.bucketDTOs.push(additionInformationEntry);
        });
      }
      getBucketDTO(label) {
        const index = this.ngxChartLabels.indexOf(label);
        return this.bucketDTOs[index];
      }
      onSelect(event) {
        const interval = event.name;
        const separatorIndex = interval.indexOf("-");
        const lowerBound = parseInt(interval.slice(1, separatorIndex), 10);
        const upperBound = parseInt(interval.slice(separatorIndex + 1, interval.length - 2), 10);
        this.similaritySelected.emit(new Range(lowerBound, upperBound));
      }
      static \u0275fac = function PlagiarismRunDetailsComponent_Factory(t) {
        return new (t || _PlagiarismRunDetailsComponent)(i011.\u0275\u0275directiveInject(PlagiarismInspectorService));
      };
      static \u0275cmp = i011.\u0275\u0275defineComponent({ type: _PlagiarismRunDetailsComponent, selectors: [["jhi-plagiarism-run-details"]], inputs: { plagiarismResult: "plagiarismResult", plagiarismResultStats: "plagiarismResultStats" }, outputs: { similaritySelected: "similaritySelected" }, features: [i011.\u0275\u0275InheritDefinitionFeature, i011.\u0275\u0275NgOnChangesFeature], decls: 87, vars: 46, consts: [[1, "plagiarism-run-details"], [1, "plagiarism-run-details-stats"], [1, "plagiarism-run-details-stats-item"], [1, "plagiarism-run-details-label"], [1, "plagiarism-run-details-info"], [1, "plagiarism-run-details-info", "duration"], [1, "plagiarism-run-details-item"], [1, "plagiarism-run-details-label", "text-center"], ["placement", "right auto", "text", "artemisApp.plagiarism.similarityDistributionExplanationTooltip"], ["containerRef", ""], [3, "roundEdges", "view", "scheme", "results", "xAxis", "yAxis", "yAxisTickFormatting", "yScaleMax", "showDataLabel", "select"], ["tooltipTemplate", ""]], template: function PlagiarismRunDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i011.\u0275\u0275elementStart(0, "div", 0);
          i011.\u0275\u0275text(1, "\n    ");
          i011.\u0275\u0275elementStart(2, "div", 1);
          i011.\u0275\u0275text(3, "\n        ");
          i011.\u0275\u0275elementStart(4, "div", 2);
          i011.\u0275\u0275text(5, "\n            ");
          i011.\u0275\u0275elementStart(6, "div", 3);
          i011.\u0275\u0275text(7);
          i011.\u0275\u0275pipe(8, "artemisTranslate");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(9, "\n            ");
          i011.\u0275\u0275elementStart(10, "div", 4);
          i011.\u0275\u0275text(11);
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(12, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(13, "\n        ");
          i011.\u0275\u0275elementStart(14, "div", 2);
          i011.\u0275\u0275text(15, "\n            ");
          i011.\u0275\u0275elementStart(16, "div", 3);
          i011.\u0275\u0275text(17);
          i011.\u0275\u0275pipe(18, "artemisTranslate");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(19, "\n            ");
          i011.\u0275\u0275elementStart(20, "div", 4);
          i011.\u0275\u0275text(21);
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(22, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(23, "\n        ");
          i011.\u0275\u0275elementStart(24, "div", 2);
          i011.\u0275\u0275text(25, "\n            ");
          i011.\u0275\u0275elementStart(26, "div", 3);
          i011.\u0275\u0275text(27);
          i011.\u0275\u0275pipe(28, "artemisTranslate");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(29, "\n            ");
          i011.\u0275\u0275elementStart(30, "div", 4);
          i011.\u0275\u0275text(31);
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(32, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(33, "\n        ");
          i011.\u0275\u0275elementStart(34, "div", 2);
          i011.\u0275\u0275text(35, "\n            ");
          i011.\u0275\u0275elementStart(36, "div", 3);
          i011.\u0275\u0275text(37);
          i011.\u0275\u0275pipe(38, "artemisTranslate");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(39, "\n            ");
          i011.\u0275\u0275elementStart(40, "div", 5);
          i011.\u0275\u0275text(41);
          i011.\u0275\u0275pipe(42, "date");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(43, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(44, "\n        ");
          i011.\u0275\u0275elementStart(45, "div", 2);
          i011.\u0275\u0275text(46, "\n            ");
          i011.\u0275\u0275elementStart(47, "div", 3);
          i011.\u0275\u0275text(48);
          i011.\u0275\u0275pipe(49, "artemisTranslate");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(50, "\n            ");
          i011.\u0275\u0275elementStart(51, "div", 4);
          i011.\u0275\u0275text(52);
          i011.\u0275\u0275pipe(53, "date");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(54, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(55, "\n        ");
          i011.\u0275\u0275elementStart(56, "div", 2);
          i011.\u0275\u0275text(57, "\n            ");
          i011.\u0275\u0275elementStart(58, "div", 3);
          i011.\u0275\u0275text(59);
          i011.\u0275\u0275pipe(60, "artemisTranslate");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(61, "\n            ");
          i011.\u0275\u0275elementStart(62, "div", 4);
          i011.\u0275\u0275text(63);
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(64, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(65, "\n    ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(66, "\n\n    ");
          i011.\u0275\u0275elementStart(67, "div", 6);
          i011.\u0275\u0275text(68, "\n        ");
          i011.\u0275\u0275elementStart(69, "div", 7);
          i011.\u0275\u0275text(70);
          i011.\u0275\u0275pipe(71, "artemisTranslate");
          i011.\u0275\u0275element(72, "jhi-help-icon", 8);
          i011.\u0275\u0275text(73, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(74, "\n        ");
          i011.\u0275\u0275elementStart(75, "div", 4, 9);
          i011.\u0275\u0275text(77, "\n            ");
          i011.\u0275\u0275elementStart(78, "ngx-charts-bar-vertical", 10);
          i011.\u0275\u0275listener("select", function PlagiarismRunDetailsComponent_Template_ngx_charts_bar_vertical_select_78_listener($event) {
            return ctx.onSelect($event);
          });
          i011.\u0275\u0275text(79, "\n                ");
          i011.\u0275\u0275template(80, PlagiarismRunDetailsComponent_ng_template_80_Template, 35, 36, "ng-template", null, 11, i011.\u0275\u0275templateRefExtractor);
          i011.\u0275\u0275text(82, "\n            ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(83, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(84, "\n    ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(85, "\n");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(86, "\n");
        }
        if (rf & 2) {
          const _r0 = i011.\u0275\u0275reference(76);
          let tmp_11_0;
          i011.\u0275\u0275advance(7);
          i011.\u0275\u0275textInterpolate1("\n                ", i011.\u0275\u0275pipeBind1(8, 22, "artemisApp.plagiarism.numberOfDetectedSubmissions"), "\n            ");
          i011.\u0275\u0275advance(4);
          i011.\u0275\u0275textInterpolate1("\n                ", ctx.plagiarismResultStats == null ? null : ctx.plagiarismResultStats.numberOfDetectedSubmissions, "\n            ");
          i011.\u0275\u0275advance(6);
          i011.\u0275\u0275textInterpolate1("\n                ", i011.\u0275\u0275pipeBind1(18, 24, "artemisApp.plagiarism.averageSimilarity"), "\n            ");
          i011.\u0275\u0275advance(4);
          i011.\u0275\u0275textInterpolate1("\n                ", (ctx.plagiarismResultStats == null ? null : ctx.plagiarismResultStats.averageSimilarity == null ? null : ctx.plagiarismResultStats.averageSimilarity.toFixed(2)) + " %", "\n            ");
          i011.\u0275\u0275advance(6);
          i011.\u0275\u0275textInterpolate1("\n                ", i011.\u0275\u0275pipeBind1(28, 26, "artemisApp.plagiarism.maximalSimilarity"), "\n            ");
          i011.\u0275\u0275advance(4);
          i011.\u0275\u0275textInterpolate1("\n                ", (ctx.plagiarismResultStats == null ? null : ctx.plagiarismResultStats.maximalSimilarity == null ? null : ctx.plagiarismResultStats.maximalSimilarity.toFixed(2)) + " %", "\n            ");
          i011.\u0275\u0275advance(6);
          i011.\u0275\u0275textInterpolate1("\n                ", i011.\u0275\u0275pipeBind1(38, 28, "artemisApp.plagiarism.duration"), "\n            ");
          i011.\u0275\u0275advance(4);
          i011.\u0275\u0275textInterpolate1("\n                ", i011.\u0275\u0275pipeBind3(42, 30, ctx.plagiarismResult == null ? null : ctx.plagiarismResult.duration, "HH:mm:ss", "GMT"), "\n            ");
          i011.\u0275\u0275advance(7);
          i011.\u0275\u0275textInterpolate1("\n                ", i011.\u0275\u0275pipeBind1(49, 34, "artemisApp.plagiarism.startedAt"), "\n            ");
          i011.\u0275\u0275advance(4);
          i011.\u0275\u0275textInterpolate1("\n                ", i011.\u0275\u0275pipeBind3(53, 36, ctx.plagiarismResult == null ? null : ctx.plagiarismResult.createdDate == null ? null : ctx.plagiarismResult.createdDate.toLocaleString(), "dd.MM.YY HH:mm", "GMT"), "\n            ");
          i011.\u0275\u0275advance(7);
          i011.\u0275\u0275textInterpolate1("\n                ", i011.\u0275\u0275pipeBind1(60, 40, "artemisApp.plagiarism.startedBy"), "\n            ");
          i011.\u0275\u0275advance(4);
          i011.\u0275\u0275textInterpolate1("\n                ", (tmp_11_0 = ctx.plagiarismResultStats == null ? null : ctx.plagiarismResultStats.createdBy) !== null && tmp_11_0 !== void 0 ? tmp_11_0 : "unknown", "\n            ");
          i011.\u0275\u0275advance(7);
          i011.\u0275\u0275textInterpolate1("\n            ", i011.\u0275\u0275pipeBind1(71, 42, "artemisApp.plagiarism.similarityDistribution"), "\n            ");
          i011.\u0275\u0275advance(8);
          i011.\u0275\u0275property("roundEdges", false)("view", i011.\u0275\u0275pureFunction1(44, _c3, _r0.offsetWidth))("scheme", ctx.ngxColor)("results", ctx.ngxData)("xAxis", true)("yAxis", true)("yAxisTickFormatting", ctx.yAxisTickFormatting)("yScaleMax", ctx.yScaleMax)("showDataLabel", true);
        }
      }, dependencies: [HelpIconComponent, i33.BarVerticalComponent, i4.DatePipe, ArtemisTranslatePipe], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  overflow-y: auto;\n}\n.plagiarism-run-details[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  padding: 1rem;\n}\n.plagiarism-run-details-stats[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: row;\n  flex-wrap: wrap;\n  margin-bottom: 1.5rem;\n}\n.plagiarism-run-details-stats-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: 180px;\n  margin-right: 1rem;\n}\n.plagiarism-run-details-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.plagiarism-run-details-item[_ngcontent-%COMP%]:not(:last-child) {\n  margin-bottom: 1rem;\n}\n.plagiarism-run-details-label[_ngcontent-%COMP%] {\n  margin-bottom: 0.25rem;\n}\n.plagiarism-run-details-info[_ngcontent-%COMP%] {\n  font-size: 1.4rem;\n  font-weight: bold;\n}\n[_nghost-%COMP%]  .tick {\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1ydW4tZGV0YWlscy9wbGFnaWFyaXNtLXJ1bi1kZXRhaWxzLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJAaW1wb3J0ICdzcmMvbWFpbi93ZWJhcHAvY29udGVudC9zY3NzL2FydGVtaXMtdmFyaWFibGVzJztcblxuOmhvc3Qge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIG92ZXJmbG93LXk6IGF1dG87XG59XG5cbi5wbGFnaWFyaXNtLXJ1bi1kZXRhaWxzIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgcGFkZGluZzogMXJlbTtcblxuICAgICYtc3RhdHMge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgICBmbGV4LXdyYXA6IHdyYXA7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDEuNXJlbTtcblxuICAgICAgICAmLWl0ZW0ge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgICAgICB3aWR0aDogMTgwcHg7XG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDFyZW07XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAmLWl0ZW0ge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuXG4gICAgICAgICY6bm90KDpsYXN0LWNoaWxkKSB7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxcmVtO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgJi1sYWJlbCB7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDAuMjVyZW07XG4gICAgfVxuXG4gICAgJi1pbmZvIHtcbiAgICAgICAgZm9udC1zaXplOiAxLjRyZW07XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIH1cbn1cblxuOmhvc3Q6Om5nLWRlZXAudGljayB7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRUE7QUFDSSxXQUFBO0FBQ0EsY0FBQTs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLGtCQUFBO0FBQ0EsV0FBQTs7QUFFQSxDQUFBO0FBQ0ksV0FBQTtBQUNBLGtCQUFBO0FBQ0EsYUFBQTtBQUNBLGlCQUFBOztBQUVBLENBQUE7QUFDSSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxTQUFBO0FBQ0EsZ0JBQUE7O0FBSVIsQ0FBQTtBQUNJLFdBQUE7QUFDQSxrQkFBQTs7QUFFQSxDQUpKLDJCQUlJLEtBQUE7QUFDSSxpQkFBQTs7QUFJUixDQUFBO0FBQ0ksaUJBQUE7O0FBR0osQ0FBQTtBQUNJLGFBQUE7QUFDQSxlQUFBOztBQUlSLEtBQUEsVUFBQSxDQUFBO0FBQ0ksZUFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */", "\n\n[_nghost-%COMP%]  .textDataLabel {\n  font-weight: bolder;\n  font-size: small !important;\n  alignment-baseline: middle;\n  text-anchor: start;\n}\n@media (min-width: 1420px) {\n  [_nghost-%COMP%]  .textDataLabel {\n    transform: rotate(0deg);\n    font-size: medium !important;\n    alignment-baseline: baseline;\n    text-anchor: middle;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvY2hhcnQvdmVydGljYWwtYmFyLWNoYXJ0LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIjpob3N0OjpuZy1kZWVwIC50ZXh0RGF0YUxhYmVsIHtcbiAgICBmb250LXdlaWdodDogYm9sZGVyO1xuICAgIGZvbnQtc2l6ZTogc21hbGwgIWltcG9ydGFudDtcbiAgICBhbGlnbm1lbnQtYmFzZWxpbmU6IG1pZGRsZTtcbiAgICB0ZXh0LWFuY2hvcjogc3RhcnQ7XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiAxNDIwcHgpIHtcbiAgICA6aG9zdDo6bmctZGVlcCAudGV4dERhdGFMYWJlbCB7XG4gICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xuICAgICAgICBmb250LXNpemU6IG1lZGl1bSAhaW1wb3J0YW50O1xuICAgICAgICBhbGlnbm1lbnQtYmFzZWxpbmU6IGJhc2VsaW5lO1xuICAgICAgICB0ZXh0LWFuY2hvcjogbWlkZGxlO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxLQUFBLFVBQUEsQ0FBQTtBQUNJLGVBQUE7QUFDQSxhQUFBO0FBQ0Esc0JBQUE7QUFDQSxlQUFBOztBQUdKLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFDSSxPQUFBLFVBQUEsQ0FSSjtBQVNRLGVBQUEsT0FBQTtBQUNBLGVBQUE7QUFDQSx3QkFBQTtBQUNBLGlCQUFBOzs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i011.\u0275setClassDebugInfo(PlagiarismRunDetailsComponent, { className: "PlagiarismRunDetailsComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismOptions.ts
var PlagiarismOptions;
var init_PlagiarismOptions = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/types/PlagiarismOptions.ts"() {
    PlagiarismOptions = class {
      similarityThreshold;
      minimumScore;
      minimumSize;
      constructor(similarityThreshold, minimumScore, minimumSize) {
        this.similarityThreshold = similarityThreshold;
        this.minimumScore = minimumScore;
        this.minimumSize = minimumSize;
      }
      toParams() {
        return {
          similarityThreshold: this.similarityThreshold.toString(),
          minimumScore: this.minimumScore.toString(),
          minimumSize: this.minimumSize.toString()
        };
      }
    };
  }
});

// src/main/webapp/app/exercises/shared/plagiarism/plagiarism-inspector/plagiarism-inspector.component.ts
import { Component as Component9 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute, Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import __vite__cjsImport53_exportToCsv from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/export-to-csv.js?v=1d0d9ead"; const ExportToCsv = __vite__cjsImport53_exportToCsv["ExportToCsv"];
import { tap as tap2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import { faChevronRight as faChevronRight2, faExclamationTriangle as faExclamationTriangle2, faQuestionCircle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { NgbModal as NgbModal3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i012 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i15 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i6 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i9 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i11 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i122 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function PlagiarismInspectorComponent_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275text(0, "\n                    ");
    i012.\u0275\u0275elementStart(1, "button", 24);
    i012.\u0275\u0275listener("click", function PlagiarismInspectorComponent_Conditional_29_Template_button_click_1_listener() {
      i012.\u0275\u0275restoreView(_r9);
      const ctx_r8 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r8.resetFilter());
    });
    i012.\u0275\u0275text(2, "\n                        ");
    i012.\u0275\u0275elementStart(3, "span");
    i012.\u0275\u0275text(4);
    i012.\u0275\u0275pipe(5, "artemisTranslate");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(6, "\n                    ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(7, "\n                ");
  }
  if (rf & 2) {
    i012.\u0275\u0275advance(4);
    i012.\u0275\u0275textInterpolate(i012.\u0275\u0275pipeBind1(5, 1, "artemisApp.plagiarism.resetFilter"));
  }
}
function PlagiarismInspectorComponent_ng_template_38_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275text(0, "\n                            ");
    i012.\u0275\u0275element(1, "p", 37);
    i012.\u0275\u0275text(2, "\n                        ");
  }
}
function PlagiarismInspectorComponent_ng_template_38_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275text(0, "\n                    ");
    i012.\u0275\u0275elementStart(1, "div", 25);
    i012.\u0275\u0275text(2, "\n                        ");
    i012.\u0275\u0275elementStart(3, "h4", 26);
    i012.\u0275\u0275text(4, "\n                            ");
    i012.\u0275\u0275elementStart(5, "span", 27);
    i012.\u0275\u0275text(6, "Clean up plagiarism results");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(7, "\n                        ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(8, "\n                        ");
    i012.\u0275\u0275elementStart(9, "button", 28);
    i012.\u0275\u0275listener("click", function PlagiarismInspectorComponent_ng_template_38_Template_button_click_9_listener() {
      const restoredCtx = i012.\u0275\u0275restoreView(_r13);
      const modal_r10 = restoredCtx.$implicit;
      return i012.\u0275\u0275resetView(modal_r10.dismiss());
    });
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(10, "\n                    ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(11, "\n                    ");
    i012.\u0275\u0275elementStart(12, "div", 29);
    i012.\u0275\u0275text(13, "\n                        ");
    i012.\u0275\u0275elementStart(14, "p", 30);
    i012.\u0275\u0275text(15, "Are you sure you want to delete the plagiarism comparisons?");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(16, "\n                        ");
    i012.\u0275\u0275elementStart(17, "div", 31);
    i012.\u0275\u0275text(18, "\n                            ");
    i012.\u0275\u0275elementStart(19, "input", 32);
    i012.\u0275\u0275listener("change", function PlagiarismInspectorComponent_ng_template_38_Template_input_change_19_listener() {
      i012.\u0275\u0275restoreView(_r13);
      const ctx_r14 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r14.toggleDeleteAllPlagiarismComparisons());
    });
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(20, "\n                            ");
    i012.\u0275\u0275elementStart(21, "label", 33);
    i012.\u0275\u0275text(22);
    i012.\u0275\u0275pipe(23, "artemisTranslate");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(24, "\n                        ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(25, "\n                        ");
    i012.\u0275\u0275template(26, PlagiarismInspectorComponent_ng_template_38_Conditional_26_Template, 3, 0);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(27, "\n                    ");
    i012.\u0275\u0275elementStart(28, "div", 34);
    i012.\u0275\u0275text(29, "\n                        ");
    i012.\u0275\u0275elementStart(30, "button", 35);
    i012.\u0275\u0275listener("click", function PlagiarismInspectorComponent_ng_template_38_Template_button_click_30_listener() {
      const restoredCtx = i012.\u0275\u0275restoreView(_r13);
      const modal_r10 = restoredCtx.$implicit;
      return i012.\u0275\u0275resetView(modal_r10.close("confirm"));
    });
    i012.\u0275\u0275text(31, "\n                            ");
    i012.\u0275\u0275elementStart(32, "span", 36);
    i012.\u0275\u0275text(33, "Clean up");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(34, "\n                        ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(35, "\n                    ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(36, "\n                ");
  }
  if (rf & 2) {
    const ctx_r1 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(19);
    i012.\u0275\u0275property("checked", ctx_r1.deleteAllPlagiarismComparisons);
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275textInterpolate(i012.\u0275\u0275pipeBind1(23, 3, "artemisApp.plagiarism.cleanUp.confirmDialog.deleteAll"));
    i012.\u0275\u0275advance(4);
    i012.\u0275\u0275conditional(26, ctx_r1.deleteAllPlagiarismComparisons ? 26 : -1);
  }
}
function PlagiarismInspectorComponent_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275text(0, "\n                    ");
    i012.\u0275\u0275elementStart(1, "button", 38);
    i012.\u0275\u0275listener("click", function PlagiarismInspectorComponent_Conditional_41_Template_button_click_1_listener() {
      i012.\u0275\u0275restoreView(_r17);
      const ctx_r16 = i012.\u0275\u0275nextContext();
      const _r2 = i012.\u0275\u0275reference(39);
      return i012.\u0275\u0275resetView(ctx_r16.openCleanUpModal(_r2));
    });
    i012.\u0275\u0275text(2, "\n                        ");
    i012.\u0275\u0275elementStart(3, "span", 36);
    i012.\u0275\u0275text(4, "Clean up");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(5, "\n                    ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(6, "\n                ");
  }
  if (rf & 2) {
    const ctx_r3 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(1);
    i012.\u0275\u0275property("jhiFeatureToggle", ctx_r3.FeatureToggle.PlagiarismChecks)("overwriteDisabled", ctx_r3.detectionInProgress);
  }
}
function PlagiarismInspectorComponent_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275text(0, "\n                    ");
    i012.\u0275\u0275elementStart(1, "div", 39);
    i012.\u0275\u0275text(2, "\n                        ");
    i012.\u0275\u0275elementStart(3, "button", 40);
    i012.\u0275\u0275text(4, "\n                            ");
    i012.\u0275\u0275elementStart(5, "span");
    i012.\u0275\u0275text(6, "Download");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(7, "\n                        ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(8, "\n                        ");
    i012.\u0275\u0275elementStart(9, "div", 41);
    i012.\u0275\u0275text(10, "\n                            ");
    i012.\u0275\u0275elementStart(11, "button", 42);
    i012.\u0275\u0275listener("click", function PlagiarismInspectorComponent_Conditional_42_Template_button_click_11_listener() {
      i012.\u0275\u0275restoreView(_r19);
      const ctx_r18 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r18.downloadPlagiarismResultsJson());
    });
    i012.\u0275\u0275text(12, "JSON");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(13, "\n                            ");
    i012.\u0275\u0275elementStart(14, "button", 42);
    i012.\u0275\u0275listener("click", function PlagiarismInspectorComponent_Conditional_42_Template_button_click_14_listener() {
      i012.\u0275\u0275restoreView(_r19);
      const ctx_r20 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r20.downloadPlagiarismResultsCsv());
    });
    i012.\u0275\u0275text(15, "CSV");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(16, "\n                        ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(17, "\n                    ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(18, "\n                ");
  }
}
function PlagiarismInspectorComponent_Conditional_90_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275text(0, "\n                ");
    i012.\u0275\u0275elementStart(1, "div", 43);
    i012.\u0275\u0275text(2, "\n                    ");
    i012.\u0275\u0275elementStart(3, "input", 44);
    i012.\u0275\u0275listener("ngModelChange", function PlagiarismInspectorComponent_Conditional_90_Template_input_ngModelChange_3_listener($event) {
      i012.\u0275\u0275restoreView(_r22);
      const ctx_r21 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r21.generateJPlagReport = $event);
    });
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(4, "\n                    ");
    i012.\u0275\u0275elementStart(5, "label", 45);
    i012.\u0275\u0275text(6, "Generate JPlag Report");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(7, "\n                ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(8, "\n            ");
  }
  if (rf & 2) {
    const ctx_r5 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275property("ngModel", ctx_r5.generateJPlagReport);
  }
}
function PlagiarismInspectorComponent_Conditional_93_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275text(0, "\n        ");
    i012.\u0275\u0275elementStart(1, "div", 46);
    i012.\u0275\u0275text(2, "\n            ");
    i012.\u0275\u0275elementStart(3, "jhi-plagiarism-sidebar", 47);
    i012.\u0275\u0275listener("showRunDetailsChange", function PlagiarismInspectorComponent_Conditional_93_Template_jhi_plagiarism_sidebar_showRunDetailsChange_3_listener($event) {
      i012.\u0275\u0275restoreView(_r24);
      const ctx_r23 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r23.showSimilarityDistribution($event));
    })("selectIndex", function PlagiarismInspectorComponent_Conditional_93_Template_jhi_plagiarism_sidebar_selectIndex_3_listener($event) {
      i012.\u0275\u0275restoreView(_r24);
      const ctx_r25 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r25.selectComparisonWithID($event));
    });
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(4, "\n            ");
    i012.\u0275\u0275element(5, "jhi-plagiarism-details", 48);
    i012.\u0275\u0275text(6, "\n            ");
    i012.\u0275\u0275elementStart(7, "jhi-plagiarism-run-details", 49);
    i012.\u0275\u0275listener("similaritySelected", function PlagiarismInspectorComponent_Conditional_93_Template_jhi_plagiarism_run_details_similaritySelected_7_listener($event) {
      i012.\u0275\u0275restoreView(_r24);
      const ctx_r26 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r26.filterByChart($event));
    });
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(8, "\n        ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(9, "\n    ");
  }
  if (rf & 2) {
    const ctx_r6 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275property("showRunDetails", ctx_r6.showRunDetails)("comparisons", ctx_r6.visibleComparisons)("offset", ctx_r6.sidebarOffset)("activeID", ctx_r6.selectedComparisonId)("casesFiltered", ctx_r6.chartFilterApplied);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275property("hidden", ctx_r6.showRunDetails)("comparison", ctx_r6.plagiarismResult.comparisons ? ctx_r6.getSelectedComparison() : void 0)("exercise", ctx_r6.exercise);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275property("hidden", !ctx_r6.showRunDetails)("plagiarismResult", ctx_r6.plagiarismResult)("plagiarismResultStats", ctx_r6.plagiarismResultStats);
  }
}
function PlagiarismInspectorComponent_Conditional_94_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275text(0, "\n                ");
    i012.\u0275\u0275elementStart(1, "div", 51);
    i012.\u0275\u0275text(2, "\n                    ");
    i012.\u0275\u0275elementStart(3, "div", 52);
    i012.\u0275\u0275text(4, "\n                        ");
    i012.\u0275\u0275element(5, "span", 53);
    i012.\u0275\u0275text(6, "\n                    ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(7, "\n                    ");
    i012.\u0275\u0275elementStart(8, "p");
    i012.\u0275\u0275text(9);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(10, "\n                ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(11, "\n            ");
  }
  if (rf & 2) {
    const ctx_r27 = i012.\u0275\u0275nextContext(2);
    i012.\u0275\u0275advance(9);
    i012.\u0275\u0275textInterpolate(ctx_r27.detectionInProgressMessage);
  }
}
function PlagiarismInspectorComponent_Conditional_94_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275text(0, "\n                ");
    i012.\u0275\u0275elementStart(1, "span", 54);
    i012.\u0275\u0275text(2);
    i012.\u0275\u0275pipe(3, "artemisTranslate");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate1("\n                    ", i012.\u0275\u0275pipeBind1(3, 1, "artemisApp.plagiarism.empty"), "\n                ");
  }
}
function PlagiarismInspectorComponent_Conditional_94_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275text(0, "\n        ");
    i012.\u0275\u0275elementStart(1, "div", 50);
    i012.\u0275\u0275text(2, "\n            ");
    i012.\u0275\u0275template(3, PlagiarismInspectorComponent_Conditional_94_Conditional_3_Template, 12, 1)(4, PlagiarismInspectorComponent_Conditional_94_Conditional_4_Template, 5, 3);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r7 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275conditional(3, ctx_r7.detectionInProgress ? 3 : -1);
    i012.\u0275\u0275advance(1);
    i012.\u0275\u0275conditional(4, !ctx_r7.detectionInProgress ? 4 : -1);
  }
}
var PlagiarismInspectorComponent;
var init_plagiarism_inspector_component = __esm({
  "src/main/webapp/app/exercises/shared/plagiarism/plagiarism-inspector/plagiarism-inspector.component.ts"() {
    init_modeling_exercise_service();
    init_exercise_model();
    init_text_exercise_service();
    init_download_util();
    init_programming_exercise_service();
    init_PlagiarismOptions();
    init_websocket_service();
    init_feature_toggle_service();
    init_plagiarism_inspector_service();
    init_plagiarism_cases_service();
    init_alert_service();
    init_modeling_exercise_service();
    init_programming_exercise_service();
    init_text_exercise_service();
    init_websocket_service();
    init_plagiarism_inspector_service();
    init_plagiarism_cases_service();
    init_alert_service();
    init_translate_directive();
    init_feature_toggle_directive();
    init_plagiarism_details_component();
    init_plagiarism_sidebar_component();
    init_plagiarism_run_details_component();
    init_artemis_translate_pipe();
    PlagiarismInspectorComponent = class _PlagiarismInspectorComponent {
      route;
      router;
      modelingExerciseService;
      programmingExerciseService;
      textExerciseService;
      websocketService;
      translateService;
      inspectorService;
      plagiarismCasesService;
      modalService;
      alertService;
      exercise;
      plagiarismResult;
      plagiarismResultStats;
      detectionInProgress = false;
      detectionInProgressMessage = "";
      selectedComparisonId;
      showRunDetails = false;
      showOptions = false;
      generateJPlagReport = false;
      similarityThreshold = 90;
      minimumScore = 0;
      minimumSize = 50;
      enableMinimumScore = false;
      enableMinimumSize = false;
      visibleComparisons;
      chartFilterApplied = false;
      sidebarOffset = 0;
      deleteAllPlagiarismComparisons = false;
      FeatureToggle = FeatureToggle;
      PROGRAMMING = ExerciseType.PROGRAMMING;
      faQuestionCircle = faQuestionCircle;
      faExclamationTriangle = faExclamationTriangle2;
      faChevronRight = faChevronRight2;
      constructor(route, router, modelingExerciseService, programmingExerciseService, textExerciseService, websocketService, translateService, inspectorService, plagiarismCasesService, modalService, alertService) {
        this.route = route;
        this.router = router;
        this.modelingExerciseService = modelingExerciseService;
        this.programmingExerciseService = programmingExerciseService;
        this.textExerciseService = textExerciseService;
        this.websocketService = websocketService;
        this.translateService = translateService;
        this.inspectorService = inspectorService;
        this.plagiarismCasesService = plagiarismCasesService;
        this.modalService = modalService;
        this.alertService = alertService;
      }
      ngOnInit() {
        this.route.data.subscribe(({ exercise }) => {
          this.exercise = exercise;
          this.registerToPlagarismDetectionTopic();
          this.getLatestPlagiarismResult();
        });
      }
      registerToPlagarismDetectionTopic() {
        const topic = this.getPlagarismDetectionTopic();
        this.websocketService.subscribe(topic);
        this.websocketService.receive(topic).pipe(tap2((plagiarismCheckState) => this.handlePlagiarismCheckStateChange(plagiarismCheckState))).subscribe();
      }
      getPlagarismDetectionTopic() {
        let topic = "/topic/";
        switch (this.exercise.type) {
          case ExerciseType.PROGRAMMING:
            topic += "programming-exercises";
            break;
          case ExerciseType.TEXT:
            topic += "text-exercises";
            break;
          case ExerciseType.MODELING:
            topic += "modeling-exercises";
            break;
        }
        return topic + "/" + this.exercise.id + "/plagiarism-check";
      }
      handlePlagiarismCheckStateChange(plagiarismCheckState) {
        const { state, messages } = plagiarismCheckState;
        this.detectionInProgress = state === "RUNNING";
        this.detectionInProgressMessage = state === "RUNNING" ? messages : this.translateService.instant("artemisApp.plagiarism.loading");
        if (state === "COMPLETED") {
          this.detectionInProgressMessage = this.translateService.instant("artemisApp.plagiarism.fetchingResults");
          this.getLatestPlagiarismResult();
        }
      }
      getLatestPlagiarismResult() {
        this.detectionInProgress = true;
        switch (this.exercise.type) {
          case ExerciseType.MODELING: {
            this.modelingExerciseService.getLatestPlagiarismResult(this.exercise.id).subscribe({
              next: (result) => this.handlePlagiarismResult(result),
              error: () => this.handleError()
            });
            return;
          }
          case ExerciseType.PROGRAMMING: {
            this.programmingExerciseService.getLatestPlagiarismResult(this.exercise.id).subscribe({
              next: (result) => this.handlePlagiarismResult(result),
              error: () => this.handleError()
            });
            return;
          }
          case ExerciseType.TEXT: {
            this.textExerciseService.getLatestPlagiarismResult(this.exercise.id).subscribe({
              next: (result) => this.handlePlagiarismResult(result),
              error: () => this.handleError()
            });
            return;
          }
          default: {
            this.detectionInProgress = false;
          }
        }
      }
      checkPlagiarism() {
        const minimumScore = this.enableMinimumScore ? this.minimumScore : 0;
        const minimumSize = this.enableMinimumSize ? this.minimumSize : 0;
        const options = new PlagiarismOptions(this.similarityThreshold, minimumScore, minimumSize);
        if (this.exercise.type === ExerciseType.MODELING) {
          this.checkPlagiarismModeling(options);
        } else if (this.generateJPlagReport) {
          this.checkPlagiarismJPlagReport(options);
        } else {
          this.checkPlagiarismJPlag(options);
        }
      }
      selectComparisonWithID(id) {
        this.selectedComparisonId = id;
        this.showRunDetails = false;
      }
      checkPlagiarismJPlagReport(options) {
        this.detectionInProgress = true;
        this.programmingExerciseService.checkPlagiarismJPlagReport(this.exercise.id, options).subscribe({
          next: (response) => {
            this.detectionInProgress = false;
            downloadZipFileFromResponse(response);
          },
          error: (error) => {
            const errorMessage = error.headers.get("x-artemisapp-error");
            if (errorMessage === "error.notEnoughSubmissions") {
              this.alertService.addAlert({
                type: AlertType.DANGER,
                message: "Insufficient amount of valid and long enough submissions available for comparison",
                disableTranslation: true
              });
            }
            this.handleError();
          }
        });
      }
      isProgrammingExercise() {
        return this.exercise?.type === ExerciseType.PROGRAMMING;
      }
      checkPlagiarismJPlag(options) {
        this.detectionInProgress = true;
        if (this.exercise.type === ExerciseType.TEXT) {
          this.textExerciseService.checkPlagiarism(this.exercise.id, options).subscribe({
            next: (result) => this.handlePlagiarismResult(result),
            error: () => this.handleError()
          });
        } else {
          this.programmingExerciseService.checkPlagiarism(this.exercise.id, options).subscribe({
            next: (result) => this.handlePlagiarismResult(result),
            error: () => this.handleError()
          });
        }
      }
      handleError() {
        this.detectionInProgress = false;
      }
      checkPlagiarismModeling(options) {
        this.detectionInProgress = true;
        this.modelingExerciseService.checkPlagiarism(this.exercise.id, options).subscribe({
          next: (result) => this.handlePlagiarismResult(result),
          error: () => this.handleError()
        });
      }
      handlePlagiarismResult(result) {
        this.detectionInProgress = false;
        if (result?.plagiarismResult?.comparisons) {
          this.sortComparisonsForResult(result.plagiarismResult);
          this.showRunDetails = true;
        }
        this.plagiarismResult = result.plagiarismResult;
        this.plagiarismResultStats = result.plagiarismResultStats;
        this.visibleComparisons = result?.plagiarismResult?.comparisons;
      }
      sortComparisonsForResult(result) {
        result.comparisons = result.comparisons.sort((a, b) => {
          if (b.similarity - a.similarity === 0) {
            return b.id - a.id;
          } else {
            return b.similarity - a.similarity;
          }
        });
      }
      downloadPlagiarismResultsJson() {
        const json = JSON.stringify(this.plagiarismResult);
        const blob = new Blob([json], { type: "application/json" });
        downloadFile(blob, `plagiarism-result_${this.exercise.type}-exercise-${this.exercise.id}.json`);
      }
      downloadPlagiarismResultsCsv() {
        if (this.plagiarismResult && this.plagiarismResult.comparisons.length > 0) {
          const csvExporter = new ExportToCsv({
            fieldSeparator: ";",
            quoteStrings: '"',
            decimalSeparator: "locale",
            showLabels: true,
            title: `Plagiarism Check for Exercise ${this.exercise.id}: ${this.exercise.title}`,
            filename: `plagiarism-result_${this.exercise.type}-exercise-${this.exercise.id}`,
            useTextFile: false,
            useBom: true,
            headers: ["Similarity", "Status", "Participant 1", "Submission 1", "Score 1", "Size 1", "Participant 2", "Submission 2", "Score 2", "Size 2"]
          });
          const csvData = this.plagiarismResult.comparisons.map((comparison) => {
            return Object.assign({
              Similarity: comparison.similarity,
              Status: comparison.status,
              "Participant 1": comparison.submissionA.studentLogin,
              "Submission 1": comparison.submissionA.submissionId,
              "Score 1": comparison.submissionA.score,
              "Size 1": comparison.submissionA.size,
              "Participant 2": comparison.submissionB.studentLogin,
              "Submission 2": comparison.submissionB.submissionId,
              "Score 2": comparison.submissionB.score,
              "Size 2": comparison.submissionB.size
            });
          });
          csvExporter.generateCsv(csvData);
        }
      }
      getMinimumSizeTooltip() {
        switch (this.exercise.type) {
          case ExerciseType.PROGRAMMING: {
            return "artemisApp.plagiarism.minimumSizeTooltipProgrammingExercise";
          }
          case ExerciseType.TEXT: {
            return "artemisApp.plagiarism.minimumSizeTooltipTextExercise";
          }
          case ExerciseType.MODELING: {
            return "artemisApp.plagiarism.minimumSizeTooltipModelingExercise";
          }
        }
      }
      filterByChart(range) {
        this.visibleComparisons = this.inspectorService.filterComparisons(range, this.plagiarismResult?.comparisons);
        const index = this.plagiarismResult?.comparisons.indexOf(this.visibleComparisons[0]) ?? 0;
        this.sidebarOffset = index !== -1 ? index : 0;
        this.chartFilterApplied = true;
      }
      resetFilter() {
        this.visibleComparisons = this.plagiarismResult?.comparisons;
        this.chartFilterApplied = false;
        this.sidebarOffset = 0;
      }
      showSimilarityDistribution(flag) {
        this.resetFilter();
        this.getLatestPlagiarismResult();
        this.showRunDetails = flag;
      }
      getSelectedComparison() {
        return this.visibleComparisons.filter((comparison) => comparison.id === this.selectedComparisonId)[0];
      }
      toggleDeleteAllPlagiarismComparisons() {
        this.deleteAllPlagiarismComparisons = !this.deleteAllPlagiarismComparisons;
      }
      cleanUpPlagiarism() {
        this.plagiarismCasesService.cleanUpPlagiarism(this.exercise.id, this.plagiarismResult.id, this.deleteAllPlagiarismComparisons).subscribe({
          next: () => {
            if (this.deleteAllPlagiarismComparisons) {
              this.deleteAllPlagiarismComparisons = false;
              this.plagiarismResult = void 0;
            } else {
              this.deleteAllPlagiarismComparisons = false;
              this.getLatestPlagiarismResult();
            }
          }
        });
      }
      openCleanUpModal(content) {
        this.modalService.open(content).result.then((result) => {
          if (result === "confirm") {
            this.cleanUpPlagiarism();
          }
        });
      }
      static \u0275fac = function PlagiarismInspectorComponent_Factory(t) {
        return new (t || _PlagiarismInspectorComponent)(i012.\u0275\u0275directiveInject(i15.ActivatedRoute), i012.\u0275\u0275directiveInject(i15.Router), i012.\u0275\u0275directiveInject(ModelingExerciseService), i012.\u0275\u0275directiveInject(ProgrammingExerciseService), i012.\u0275\u0275directiveInject(TextExerciseService), i012.\u0275\u0275directiveInject(JhiWebsocketService), i012.\u0275\u0275directiveInject(i6.TranslateService), i012.\u0275\u0275directiveInject(PlagiarismInspectorService), i012.\u0275\u0275directiveInject(PlagiarismCasesService), i012.\u0275\u0275directiveInject(i9.NgbModal), i012.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i012.\u0275\u0275defineComponent({ type: _PlagiarismInspectorComponent, selectors: [["jhi-plagiarism-inspector"]], decls: 96, vars: 47, consts: [[1, "plagiarism-inspector"], [1, "plagiarism-header"], [1, "plagiarism-header-top"], [1, "plagiarism-header-top-left"], [1, "plagiarism-page-title", "fw-medium", 3, "click"], [1, "plagiarism-options-toggle", 3, "icon"], [1, "plagiarism-warning"], ["id", "plagiarismCaution", 3, "icon"], [1, "plagiarism-header-top-right"], [1, "check-plagiarism", "btn", "btn-primary", 3, "jhiFeatureToggle", "overwriteDisabled", "click"], ["toggleDeleteModal", ""], [1, "plagiarism-header-options", 3, "hidden"], [1, "plagiarism-option"], ["jhiTranslate", "artemisApp.plagiarism.similarityThreshold", 1, "plagiarism-option-label"], ["placement", "bottom auto", 3, "icon", "ngbTooltip"], ["type", "number", "required", "", "min", "0", "max", "100", "step", "5", "id", "plagiarism-similarity-threshold", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "enableMinimumScore", 1, "plagiarism-checkbox", "form-check"], ["type", "checkbox", "id", "enableMinimumScore", "checked", "", 1, "plagiarism-option-checkbox", "form-check-input", 3, "ngModel", "ngModelChange"], ["jhiTranslate", "artemisApp.plagiarism.minimumScore", 1, "plagiarism-option-label", "form-check-label"], ["required", "", "type", "number", "min", "0", "max", "100", "id", "plagiarism-minimum-score", 1, "form-control", 3, "disabled", "ngModel", "ngModelChange"], ["for", "enableMinimumSize", 1, "plagiarism-checkbox", "form-check"], ["type", "checkbox", "id", "enableMinimumSize", "checked", "", 1, "plagiarism-option-checkbox", "form-check-input", 3, "ngModel", "ngModelChange"], ["for", "enableMinimumSize", "jhiTranslate", "artemisApp.plagiarism.minimumSize", 1, "plagiarism-option-label", "form-check-label"], ["required", "", "type", "number", "min", "0", "max", "100", "id", "plagiarism-minimum-size", 1, "form-control", 3, "disabled", "ngModel", "ngModelChange"], [1, "check-plagiarism", "btn", "btn-info", 3, "click"], [1, "modal-header"], [1, "modal-title"], ["jhiTranslate", "artemisApp.plagiarism.cleanUp.confirmDialog.title"], ["type", "button", "aria-label", "Close", 1, "btn-close", 3, "click"], [1, "modal-body"], ["jhiTranslate", "artemisApp.plagiarism.cleanUp.confirmDialog.question"], [1, "form-check", "flex-grow-0"], ["id", "deleteAllPlagiarismComparisons", "type", "checkbox", 1, "form-check-input", 3, "checked", "change"], ["for", "deleteAllPlagiarismComparisons", 1, "form-check-label"], [1, "modal-footer"], ["type", "button", 1, "btn", "btn-danger", 3, "click"], ["jhiTranslate", "artemisApp.plagiarism.cleanUp.confirmDialog.submit"], ["jhiTranslate", "artemisApp.plagiarism.cleanUp.confirmDialog.warning", 1, "text-warning"], [1, "check-plagiarism", "btn", "btn-danger", 3, "jhiFeatureToggle", "overwriteDisabled", "click"], ["ngbDropdown", ""], ["id", "download-plagiarism", "ngbDropdownToggle", "", 1, "btn", "btn-secondary", "btn-block"], ["ngbDropdownMenu", "", "aria-labelledby", "download-plagiarism"], ["type", "button", "ngbDropdownItem", "", 3, "click"], ["for", "generateJPlagReport", 1, "plagiarism-checkbox", "form-check"], ["type", "checkbox", "id", "generateJPlagReport", "checked", "", 1, "form-check-input", 3, "ngModel", "ngModelChange"], ["for", "generateJPlagReport", "jhiTranslate", "artemisApp.plagiarism.generateJplagReport", 1, "plagiarism-option-label"], [1, "plagiarism-body"], [3, "showRunDetails", "comparisons", "offset", "activeID", "casesFiltered", "showRunDetailsChange", "selectIndex"], [3, "hidden", "comparison", "exercise"], [3, "hidden", "plagiarismResult", "plagiarismResultStats", "similaritySelected"], [1, "plagiarism-empty"], [1, "d-flex", "flex-column"], ["role", "status", 1, "spinner-border", "text-primary", "align-self-center", "mb-1"], [1, "sr-only"], [1, "plagiarism-empty-label"]], template: function PlagiarismInspectorComponent_Template(rf, ctx) {
        if (rf & 1) {
          i012.\u0275\u0275elementStart(0, "div", 0);
          i012.\u0275\u0275text(1, "\n    ");
          i012.\u0275\u0275elementStart(2, "div", 1);
          i012.\u0275\u0275text(3, "\n        ");
          i012.\u0275\u0275elementStart(4, "div", 2);
          i012.\u0275\u0275text(5, "\n            ");
          i012.\u0275\u0275elementStart(6, "div", 3);
          i012.\u0275\u0275text(7, "\n                ");
          i012.\u0275\u0275elementStart(8, "h4", 4);
          i012.\u0275\u0275listener("click", function PlagiarismInspectorComponent_Template_h4_click_8_listener() {
            return ctx.showOptions = !ctx.showOptions;
          });
          i012.\u0275\u0275text(9, "\n                    ");
          i012.\u0275\u0275element(10, "fa-icon", 5);
          i012.\u0275\u0275text(11, "\n                    ");
          i012.\u0275\u0275elementStart(12, "span");
          i012.\u0275\u0275text(13);
          i012.\u0275\u0275pipe(14, "artemisTranslate");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(15, "\n                ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(16, "\n                ");
          i012.\u0275\u0275elementStart(17, "div", 6);
          i012.\u0275\u0275text(18, "\n                    ");
          i012.\u0275\u0275element(19, "fa-icon", 7);
          i012.\u0275\u0275text(20, "\n                    ");
          i012.\u0275\u0275elementStart(21, "span");
          i012.\u0275\u0275text(22);
          i012.\u0275\u0275pipe(23, "artemisTranslate");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(24, "\n                ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(25, "\n            ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(26, "\n            ");
          i012.\u0275\u0275elementStart(27, "div", 8);
          i012.\u0275\u0275text(28, "\n                ");
          i012.\u0275\u0275template(29, PlagiarismInspectorComponent_Conditional_29_Template, 8, 3);
          i012.\u0275\u0275elementStart(30, "button", 9);
          i012.\u0275\u0275listener("click", function PlagiarismInspectorComponent_Template_button_click_30_listener() {
            return ctx.checkPlagiarism();
          });
          i012.\u0275\u0275text(31, "\n                    ");
          i012.\u0275\u0275elementStart(32, "span");
          i012.\u0275\u0275text(33);
          i012.\u0275\u0275pipe(34, "artemisTranslate");
          i012.\u0275\u0275pipe(35, "artemisTranslate");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(36, "\n                ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(37, "\n                ");
          i012.\u0275\u0275template(38, PlagiarismInspectorComponent_ng_template_38_Template, 37, 5, "ng-template", null, 10, i012.\u0275\u0275templateRefExtractor);
          i012.\u0275\u0275text(40, "\n                ");
          i012.\u0275\u0275template(41, PlagiarismInspectorComponent_Conditional_41_Template, 7, 2)(42, PlagiarismInspectorComponent_Conditional_42_Template, 19, 0);
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(43, "\n        ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(44, "\n        ");
          i012.\u0275\u0275elementStart(45, "div", 11);
          i012.\u0275\u0275text(46, "\n            ");
          i012.\u0275\u0275elementStart(47, "div", 12);
          i012.\u0275\u0275text(48, "\n                ");
          i012.\u0275\u0275elementStart(49, "div", 13);
          i012.\u0275\u0275text(50, "Similarity Threshold");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(51, "\n                ");
          i012.\u0275\u0275element(52, "fa-icon", 14);
          i012.\u0275\u0275pipe(53, "artemisTranslate");
          i012.\u0275\u0275text(54, "\n                ");
          i012.\u0275\u0275elementStart(55, "input", 15);
          i012.\u0275\u0275listener("ngModelChange", function PlagiarismInspectorComponent_Template_input_ngModelChange_55_listener($event) {
            return ctx.similarityThreshold = $event;
          });
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(56, "\n            ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(57, "\n            ");
          i012.\u0275\u0275elementStart(58, "div", 12);
          i012.\u0275\u0275text(59, "\n                ");
          i012.\u0275\u0275elementStart(60, "div", 16);
          i012.\u0275\u0275text(61, "\n                    ");
          i012.\u0275\u0275elementStart(62, "input", 17);
          i012.\u0275\u0275listener("ngModelChange", function PlagiarismInspectorComponent_Template_input_ngModelChange_62_listener($event) {
            return ctx.enableMinimumScore = $event;
          });
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(63, "\n                    ");
          i012.\u0275\u0275elementStart(64, "div", 18);
          i012.\u0275\u0275text(65, "Minimum Score");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(66, "\n                ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(67, "\n                ");
          i012.\u0275\u0275element(68, "fa-icon", 14);
          i012.\u0275\u0275pipe(69, "artemisTranslate");
          i012.\u0275\u0275text(70, "\n                ");
          i012.\u0275\u0275elementStart(71, "input", 19);
          i012.\u0275\u0275listener("ngModelChange", function PlagiarismInspectorComponent_Template_input_ngModelChange_71_listener($event) {
            return ctx.minimumScore = $event;
          });
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(72, "\n            ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(73, "\n            ");
          i012.\u0275\u0275elementStart(74, "div", 12);
          i012.\u0275\u0275text(75, "\n                ");
          i012.\u0275\u0275elementStart(76, "div", 20);
          i012.\u0275\u0275text(77, "\n                    ");
          i012.\u0275\u0275elementStart(78, "input", 21);
          i012.\u0275\u0275listener("ngModelChange", function PlagiarismInspectorComponent_Template_input_ngModelChange_78_listener($event) {
            return ctx.enableMinimumSize = $event;
          });
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(79, "\n                    ");
          i012.\u0275\u0275elementStart(80, "label", 22);
          i012.\u0275\u0275text(81, "Minimum Size");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(82, "\n                ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(83, "\n                ");
          i012.\u0275\u0275element(84, "fa-icon", 14);
          i012.\u0275\u0275pipe(85, "artemisTranslate");
          i012.\u0275\u0275text(86, "\n                ");
          i012.\u0275\u0275elementStart(87, "input", 23);
          i012.\u0275\u0275listener("ngModelChange", function PlagiarismInspectorComponent_Template_input_ngModelChange_87_listener($event) {
            return ctx.minimumSize = $event;
          });
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(88, "\n            ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(89, "\n            ");
          i012.\u0275\u0275template(90, PlagiarismInspectorComponent_Conditional_90_Template, 9, 1);
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(91, "\n    ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(92, "\n    ");
          i012.\u0275\u0275template(93, PlagiarismInspectorComponent_Conditional_93_Template, 10, 11)(94, PlagiarismInspectorComponent_Conditional_94_Template, 6, 2);
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(95, "\n");
        }
        if (rf & 2) {
          i012.\u0275\u0275advance(8);
          i012.\u0275\u0275classProp("active", ctx.showOptions);
          i012.\u0275\u0275advance(2);
          i012.\u0275\u0275property("icon", ctx.faChevronRight);
          i012.\u0275\u0275advance(3);
          i012.\u0275\u0275textInterpolate(i012.\u0275\u0275pipeBind1(14, 33, "artemisApp.plagiarism.plagiarismDetection"));
          i012.\u0275\u0275advance(6);
          i012.\u0275\u0275property("icon", ctx.faExclamationTriangle);
          i012.\u0275\u0275advance(3);
          i012.\u0275\u0275textInterpolate(i012.\u0275\u0275pipeBind1(23, 35, "artemisApp.plagiarism.caution"));
          i012.\u0275\u0275advance(7);
          i012.\u0275\u0275conditional(29, ctx.chartFilterApplied ? 29 : -1);
          i012.\u0275\u0275advance(1);
          i012.\u0275\u0275property("jhiFeatureToggle", ctx.FeatureToggle.PlagiarismChecks)("overwriteDisabled", ctx.detectionInProgress);
          i012.\u0275\u0275advance(3);
          i012.\u0275\u0275textInterpolate(ctx.plagiarismResult ? i012.\u0275\u0275pipeBind1(34, 37, "artemisApp.plagiarism.rerun") : i012.\u0275\u0275pipeBind1(35, 39, "artemisApp.plagiarism.detect"));
          i012.\u0275\u0275advance(8);
          i012.\u0275\u0275conditional(41, ctx.exercise.isAtLeastInstructor && ctx.plagiarismResult ? 41 : -1);
          i012.\u0275\u0275advance(1);
          i012.\u0275\u0275conditional(42, ctx.plagiarismResult ? 42 : -1);
          i012.\u0275\u0275advance(3);
          i012.\u0275\u0275property("hidden", !ctx.showOptions);
          i012.\u0275\u0275advance(7);
          i012.\u0275\u0275property("icon", ctx.faQuestionCircle)("ngbTooltip", i012.\u0275\u0275pipeBind1(53, 41, "artemisApp.plagiarism.similarityThresholdTooltip"));
          i012.\u0275\u0275advance(3);
          i012.\u0275\u0275property("ngModel", ctx.similarityThreshold);
          i012.\u0275\u0275advance(3);
          i012.\u0275\u0275classProp("disabled", !ctx.enableMinimumScore);
          i012.\u0275\u0275advance(4);
          i012.\u0275\u0275property("ngModel", ctx.enableMinimumScore);
          i012.\u0275\u0275advance(6);
          i012.\u0275\u0275property("icon", ctx.faQuestionCircle)("ngbTooltip", i012.\u0275\u0275pipeBind1(69, 43, "artemisApp.plagiarism.minimumScoreTooltip"));
          i012.\u0275\u0275advance(3);
          i012.\u0275\u0275property("disabled", !ctx.enableMinimumScore)("ngModel", ctx.minimumScore);
          i012.\u0275\u0275advance(3);
          i012.\u0275\u0275classProp("disabled", !ctx.enableMinimumSize);
          i012.\u0275\u0275advance(4);
          i012.\u0275\u0275property("ngModel", ctx.enableMinimumSize);
          i012.\u0275\u0275advance(6);
          i012.\u0275\u0275property("icon", ctx.faQuestionCircle)("ngbTooltip", i012.\u0275\u0275pipeBind1(85, 45, ctx.getMinimumSizeTooltip()));
          i012.\u0275\u0275advance(3);
          i012.\u0275\u0275property("disabled", !ctx.enableMinimumSize)("ngModel", ctx.minimumSize);
          i012.\u0275\u0275advance(3);
          i012.\u0275\u0275conditional(90, ctx.isProgrammingExercise() ? 90 : -1);
          i012.\u0275\u0275advance(3);
          i012.\u0275\u0275conditional(93, ctx.plagiarismResult && !ctx.detectionInProgress ? 93 : -1);
          i012.\u0275\u0275advance(1);
          i012.\u0275\u0275conditional(94, !ctx.plagiarismResult || ctx.detectionInProgress ? 94 : -1);
        }
      }, dependencies: [i11.DefaultValueAccessor, i11.NumberValueAccessor, i11.CheckboxControlValueAccessor, i11.NgControlStatus, i11.RequiredValidator, i11.MinValidator, i11.MaxValidator, i11.NgModel, i9.NgbDropdown, i9.NgbDropdownToggle, i9.NgbDropdownMenu, i9.NgbDropdownItem, i9.NgbDropdownButtonItem, i9.NgbTooltip, i122.FaIconComponent, TranslateDirective, FeatureToggleDirective, PlagiarismDetailsComponent, PlagiarismSidebarComponent, PlagiarismRunDetailsComponent, ArtemisTranslatePipe], styles: ["\n\n.plagiarism-inspector[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  height: calc(100vh - 2 * 1rem - 57px - 31px - 41px);\n  margin: -1rem;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header[_ngcontent-%COMP%] {\n  background-color: var(--artemis-dark);\n  color: white;\n  flex-shrink: 0;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-top[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n  justify-content: space-between;\n  padding: 1.5rem;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-top-left[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n  flex-wrap: wrap;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-top-right[_ngcontent-%COMP%] {\n  display: flex;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-top-right[_ngcontent-%COMP%]   .check-plagiarism[_ngcontent-%COMP%] {\n  margin-right: 1rem;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header[_ngcontent-%COMP%]   .plagiarism-page-title[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n  margin: 0 1rem 0 0;\n  padding: 0.25rem 0.5rem;\n  border-radius: 4px;\n  cursor: pointer;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header[_ngcontent-%COMP%]   .plagiarism-page-title[_ngcontent-%COMP%]:hover {\n  background-color: rgba(255, 255, 255, 0.1);\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header[_ngcontent-%COMP%]   .plagiarism-page-title[_ngcontent-%COMP%]   .plagiarism-options-toggle[_ngcontent-%COMP%] {\n  font-size: 1.1rem;\n  margin-right: 1rem;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header[_ngcontent-%COMP%]   .plagiarism-page-title.active[_ngcontent-%COMP%]   .plagiarism-options-toggle[_ngcontent-%COMP%] {\n  transform: rotate(90deg);\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-options[_ngcontent-%COMP%] {\n  align-items: center;\n  background-color: var(--plagiarism-inspector-darker-artemis-dark);\n  display: flex;\n  flex-wrap: wrap;\n  padding: 1rem 1.5rem;\n  white-space: nowrap;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-options[_ngcontent-%COMP%]    > [_ngcontent-%COMP%]:not(:last-child) {\n  margin-right: 1.5rem;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-options[_ngcontent-%COMP%]   .plagiarism-option[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n  flex-shrink: 0;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-options[_ngcontent-%COMP%]   .plagiarism-option.disabled[_ngcontent-%COMP%]   .form-control[_ngcontent-%COMP%] {\n  opacity: 0.4;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-options[_ngcontent-%COMP%]   .plagiarism-option-label[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n  margin-right: 0.5rem;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-options[_ngcontent-%COMP%]   .plagiarism-option-checkbox[_ngcontent-%COMP%] {\n  margin-right: 0.5rem;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-options[_ngcontent-%COMP%]   .plagiarism-option[_ngcontent-%COMP%]   #plagiarism-similarity-threshold[_ngcontent-%COMP%], .plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-options[_ngcontent-%COMP%]   .plagiarism-option[_ngcontent-%COMP%]   #plagiarism-minimum-score[_ngcontent-%COMP%], .plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-options[_ngcontent-%COMP%]   .plagiarism-option[_ngcontent-%COMP%]   #plagiarism-minimum-size[_ngcontent-%COMP%] {\n  margin-left: 1rem;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-header-options[_ngcontent-%COMP%]   .plagiarism-option[_ngcontent-%COMP%]   .form-control[_ngcontent-%COMP%] {\n  padding-right: 0;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-body[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  flex-grow: 1;\n  padding-left: 240px;\n  position: relative;\n  overflow: hidden;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-body[_ngcontent-%COMP%]   .plagiarism-content[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-warning[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n  color: white;\n  padding-top: 1px;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-warning[_ngcontent-%COMP%]   #plagiarismCaution[_ngcontent-%COMP%] {\n  margin-right: 0.5rem;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-checkbox[_ngcontent-%COMP%] {\n  margin: 0;\n  flex-shrink: 0;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-checkbox[_ngcontent-%COMP%]   #generateJPlagReport[_ngcontent-%COMP%] {\n  margin-right: 0.5rem;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-empty[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n  flex-grow: 1;\n  justify-content: center;\n}\n.plagiarism-inspector[_ngcontent-%COMP%]   .plagiarism-empty-label[_ngcontent-%COMP%] {\n  opacity: 0.5;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1pbnNwZWN0b3IvcGxhZ2lhcmlzbS1pbnNwZWN0b3IuY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIiRjYXJkLWJvZHktcGFkZGluZzogMXJlbTtcbiRuYXZiYXItaGVpZ2h0OiA1N3B4O1xuJGJyZWFkY3J1bWJzLWhlaWdodDogNDFweDtcbiRmb290ZXItaGVpZ2h0OiAzMXB4O1xuXG4ucGxhZ2lhcmlzbS1pbnNwZWN0b3Ige1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBoZWlnaHQ6IGNhbGMoMTAwdmggLSAyICogI3skY2FyZC1ib2R5LXBhZGRpbmd9IC0gI3skbmF2YmFyLWhlaWdodH0gLSAjeyRmb290ZXItaGVpZ2h0fSAtICN7JGJyZWFkY3J1bWJzLWhlaWdodH0pO1xuICAgIC8vIEpIaXBzdGVyJ3MgLmNhcmQtYm9keSBoYXMgZGVmYXVsdCBwYWRkaW5nIG9mIDEuMjVcbiAgICBtYXJnaW46IC0xcmVtO1xuXG4gICAgLnBsYWdpYXJpc20taGVhZGVyIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYXJ0ZW1pcy1kYXJrKTtcbiAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICBmbGV4LXNocmluazogMDtcblxuICAgICAgICAmLXRvcCB7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgICAgIHBhZGRpbmc6IDEuNXJlbTtcblxuICAgICAgICAgICAgJi1sZWZ0IHtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgZmxleC13cmFwOiB3cmFwO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAmLXJpZ2h0IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuXG4gICAgICAgICAgICAgICAgLmNoZWNrLXBsYWdpYXJpc20ge1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDFyZW07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLnBsYWdpYXJpc20tcGFnZS10aXRsZSB7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIG1hcmdpbjogMCAxcmVtIDAgMDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDAuMjVyZW0gMC41cmVtO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuXG4gICAgICAgICAgICAmOmhvdmVyIHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5wbGFnaWFyaXNtLW9wdGlvbnMtdG9nZ2xlIHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEuMXJlbTtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDFyZW07XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICYuYWN0aXZlIC5wbGFnaWFyaXNtLW9wdGlvbnMtdG9nZ2xlIHtcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAmLW9wdGlvbnMge1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXBsYWdpYXJpc20taW5zcGVjdG9yLWRhcmtlci1hcnRlbWlzLWRhcmspO1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGZsZXgtd3JhcDogd3JhcDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDFyZW0gMS41cmVtO1xuICAgICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcblxuICAgICAgICAgICAgJiA+IDpub3QoOmxhc3QtY2hpbGQpIHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEuNXJlbTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLnBsYWdpYXJpc20tb3B0aW9uIHtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgZmxleC1zaHJpbms6IDA7XG5cbiAgICAgICAgICAgICAgICAmLmRpc2FibGVkIC5mb3JtLWNvbnRyb2wge1xuICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLjQ7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgJi1sYWJlbCB7XG4gICAgICAgICAgICAgICAgICAgIGZsZXgtc2hyaW5rOiAwO1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDAuNXJlbTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAmLWNoZWNrYm94IHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAwLjVyZW07XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgI3BsYWdpYXJpc20tc2ltaWxhcml0eS10aHJlc2hvbGQsXG4gICAgICAgICAgICAgICAgI3BsYWdpYXJpc20tbWluaW11bS1zY29yZSxcbiAgICAgICAgICAgICAgICAjcGxhZ2lhcmlzbS1taW5pbXVtLXNpemUge1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMXJlbTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAuZm9ybS1jb250cm9sIHtcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZy1yaWdodDogMDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAucGxhZ2lhcmlzbS1ib2R5IHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgZmxleC1ncm93OiAxO1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDI0MHB4O1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG5cbiAgICAgICAgLnBsYWdpYXJpc20tY29udGVudCB7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5wbGFnaWFyaXNtLXdhcm5pbmcge1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgIHBhZGRpbmctdG9wOiAxcHg7XG5cbiAgICAgICAgI3BsYWdpYXJpc21DYXV0aW9uIHtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMC41cmVtO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnBsYWdpYXJpc20tY2hlY2tib3gge1xuICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgIGZsZXgtc2hyaW5rOiAwO1xuXG4gICAgICAgICNnZW5lcmF0ZUpQbGFnUmVwb3J0IHtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMC41cmVtO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnBsYWdpYXJpc20tZW1wdHkge1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWdyb3c6IDE7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuXG4gICAgICAgICYtbGFiZWwge1xuICAgICAgICAgICAgb3BhY2l0eTogMC41O1xuICAgICAgICB9XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUtBLENBQUE7QUFDSSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxVQUFBLEtBQUEsTUFBQSxFQUFBLEVBQUEsRUFBQSxLQUFBLEVBQUEsS0FBQSxFQUFBLEtBQUEsRUFBQTtBQUVBLFVBQUE7O0FBRUEsQ0FQSixxQkFPSSxDQUFBO0FBQ0ksb0JBQUEsSUFBQTtBQUNBLFNBQUE7QUFDQSxlQUFBOztBQUVBLENBWlIscUJBWVEsQ0FBQTtBQUNJLGVBQUE7QUFDQSxXQUFBO0FBQ0EsbUJBQUE7QUFDQSxXQUFBOztBQUVBLENBbEJaLHFCQWtCWSxDQUFBO0FBQ0ksZUFBQTtBQUNBLFdBQUE7QUFDQSxhQUFBOztBQUdKLENBeEJaLHFCQXdCWSxDQUFBO0FBQ0ksV0FBQTs7QUFFQSxDQTNCaEIscUJBMkJnQixDQUhKLDRCQUdJLENBQUE7QUFDSSxnQkFBQTs7QUFLWixDQWpDUixxQkFpQ1EsQ0ExQkosa0JBMEJJLENBQUE7QUFDSSxlQUFBO0FBQ0EsV0FBQTtBQUNBLFVBQUEsRUFBQSxLQUFBLEVBQUE7QUFDQSxXQUFBLFFBQUE7QUFDQSxpQkFBQTtBQUNBLFVBQUE7O0FBRUEsQ0F6Q1oscUJBeUNZLENBbENSLGtCQWtDUSxDQVJKLHFCQVFJO0FBQ0ksb0JBQUEsS0FBQSxHQUFBLEVBQUEsR0FBQSxFQUFBLEdBQUEsRUFBQTs7QUFHSixDQTdDWixxQkE2Q1ksQ0F0Q1Isa0JBc0NRLENBWkosc0JBWUksQ0FBQTtBQUNJLGFBQUE7QUFDQSxnQkFBQTs7QUFHSixDQWxEWixxQkFrRFksQ0EzQ1Isa0JBMkNRLENBakJKLHFCQWlCSSxDQUFBLE9BQUEsQ0FMQTtBQU1JLGFBQUEsT0FBQTs7QUFJUixDQXZEUixxQkF1RFEsQ0FBQTtBQUNJLGVBQUE7QUFDQSxvQkFBQSxJQUFBO0FBQ0EsV0FBQTtBQUNBLGFBQUE7QUFDQSxXQUFBLEtBQUE7QUFDQSxlQUFBOztBQUVBLENBL0RaLHFCQStEWSxDQVJKLDBCQVFJLEVBQUEsS0FBQTtBQUNJLGdCQUFBOztBQUdKLENBbkVaLHFCQW1FWSxDQVpKLDBCQVlJLENBQUE7QUFDSSxlQUFBO0FBQ0EsV0FBQTtBQUNBLGVBQUE7O0FBRUEsQ0F4RWhCLHFCQXdFZ0IsQ0FqQlIsMEJBaUJRLENBTEosaUJBS0ksQ0FBQSxTQUFBLENBQUE7QUFDSSxXQUFBOztBQUdKLENBNUVoQixxQkE0RWdCLENBckJSLDBCQXFCUSxDQUFBO0FBQ0ksZUFBQTtBQUNBLGdCQUFBOztBQUdKLENBakZoQixxQkFpRmdCLENBMUJSLDBCQTBCUSxDQUFBO0FBQ0ksZ0JBQUE7O0FBR0osQ0FyRmhCLHFCQXFGZ0IsQ0E5QlIsMEJBOEJRLENBbEJKLGtCQWtCSSxDQUFBO0FBQUEsQ0FyRmhCLHFCQXFGZ0IsQ0E5QlIsMEJBOEJRLENBbEJKLGtCQWtCSSxDQUFBO0FBQUEsQ0FyRmhCLHFCQXFGZ0IsQ0E5QlIsMEJBOEJRLENBbEJKLGtCQWtCSSxDQUFBO0FBR0ksZUFBQTs7QUFHSixDQTNGaEIscUJBMkZnQixDQXBDUiwwQkFvQ1EsQ0F4Qkosa0JBd0JJLENBbkJBO0FBb0JJLGlCQUFBOztBQU1oQixDQWxHSixxQkFrR0ksQ0FBQTtBQUNJLFdBQUE7QUFDQSxrQkFBQTtBQUNBLGFBQUE7QUFDQSxnQkFBQTtBQUNBLFlBQUE7QUFDQSxZQUFBOztBQUVBLENBMUdSLHFCQTBHUSxDQVJKLGdCQVFJLENBQUE7QUFDSSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxVQUFBOztBQUlSLENBakhKLHFCQWlISSxDQUFBO0FBQ0ksZUFBQTtBQUNBLFdBQUE7QUFDQSxTQUFBO0FBQ0EsZUFBQTs7QUFFQSxDQXZIUixxQkF1SFEsQ0FOSixtQkFNSSxDQUFBO0FBQ0ksZ0JBQUE7O0FBSVIsQ0E1SEoscUJBNEhJLENBQUE7QUFDSSxVQUFBO0FBQ0EsZUFBQTs7QUFFQSxDQWhJUixxQkFnSVEsQ0FKSixvQkFJSSxDQUFBO0FBQ0ksZ0JBQUE7O0FBSVIsQ0FySUoscUJBcUlJLENBQUE7QUFDSSxlQUFBO0FBQ0EsV0FBQTtBQUNBLGFBQUE7QUFDQSxtQkFBQTs7QUFFQSxDQTNJUixxQkEySVEsQ0FBQTtBQUNJLFdBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i012.\u0275setClassDebugInfo(PlagiarismInspectorComponent, { className: "PlagiarismInspectorComponent" });
    })();
  }
});

export {
  PlagiarismCasesService,
  init_plagiarism_cases_service,
  ModelingExerciseService,
  init_modeling_exercise_service,
  init_plagiarism_header_component,
  init_split_pane_header_component,
  init_modeling_submission_viewer_component,
  init_text_submission_viewer_component,
  PlagiarismSplitViewComponent,
  init_plagiarism_split_view_component,
  init_plagiarism_details_component,
  init_plagiarism_sidebar_component,
  init_plagiarism_run_details_component,
  PlagiarismInspectorComponent,
  init_plagiarism_inspector_component
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL3BsYWdpYXJpc20tY2FzZXMvc2hhcmVkL3BsYWdpYXJpc20tY2FzZXMuc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL21vZGVsaW5nL21hbmFnZS9tb2RlbGluZy1leGVyY2lzZS5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbVN0YXR1cy50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21Db21wYXJpc29uLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1oZWFkZXIvcGxhZ2lhcmlzbS1oZWFkZXIuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1oZWFkZXIvcGxhZ2lhcmlzbS1oZWFkZXIuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS9wbGFnaWFyaXNtLXNwbGl0LXZpZXcvc3BsaXQtcGFuZS1oZWFkZXIvc3BsaXQtcGFuZS1oZWFkZXIuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1zcGxpdC12aWV3L3NwbGl0LXBhbmUtaGVhZGVyL3NwbGl0LXBhbmUtaGVhZGVyLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbVN1Ym1pc3Npb24udHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS9wbGFnaWFyaXNtLXNwbGl0LXZpZXcvbW9kZWxpbmctc3VibWlzc2lvbi12aWV3ZXIvbW9kZWxpbmctc3VibWlzc2lvbi12aWV3ZXIuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1zcGxpdC12aWV3L21vZGVsaW5nLXN1Ym1pc3Npb24tdmlld2VyL21vZGVsaW5nLXN1Ym1pc3Npb24tdmlld2VyLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1zcGxpdC12aWV3L3RleHQtc3VibWlzc2lvbi12aWV3ZXIvdGV4dC1zdWJtaXNzaW9uLXZpZXdlci5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS9wbGFnaWFyaXNtLXNwbGl0LXZpZXcvdGV4dC1zdWJtaXNzaW9uLXZpZXdlci90ZXh0LXN1Ym1pc3Npb24tdmlld2VyLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbVN1Ym1pc3Npb25FbGVtZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvdGV4dC9UZXh0U3VibWlzc2lvbkVsZW1lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtTWF0Y2gudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS9wbGFnaWFyaXNtLXNwbGl0LXZpZXcvcGxhZ2lhcmlzbS1zcGxpdC12aWV3LmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3BsYWdpYXJpc20tc3BsaXQtdmlldy9wbGFnaWFyaXNtLXNwbGl0LXZpZXcuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS9wbGFnaWFyaXNtLWRldGFpbHMvcGxhZ2lhcmlzbS1kZXRhaWxzLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3BsYWdpYXJpc20tZGV0YWlscy9wbGFnaWFyaXNtLWRldGFpbHMuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS9wbGFnaWFyaXNtLXNpZGViYXIvcGxhZ2lhcmlzbS1zaWRlYmFyLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3BsYWdpYXJpc20tc2lkZWJhci9wbGFnaWFyaXNtLXNpZGViYXIuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS9wbGFnaWFyaXNtLWluc3BlY3Rvci9wbGFnaWFyaXNtLWluc3BlY3Rvci5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbVJlc3VsdERUTy50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3BsYWdpYXJpc20tcnVuLWRldGFpbHMvcGxhZ2lhcmlzbS1ydW4tZGV0YWlscy5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS9wbGFnaWFyaXNtLXJ1bi1kZXRhaWxzL3BsYWdpYXJpc20tcnVuLWRldGFpbHMuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtT3B0aW9ucy50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3BsYWdpYXJpc20taW5zcGVjdG9yL3BsYWdpYXJpc20taW5zcGVjdG9yLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3BsYWdpYXJpc20taW5zcGVjdG9yL3BsYWdpYXJpc20taW5zcGVjdG9yLmNvbXBvbmVudC5odG1sIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBQYXJhbXMsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IFBsYWdpYXJpc21DYXNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtQ2FzZSc7XG5pbXBvcnQgeyBQbGFnaWFyaXNtU3RhdHVzIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtU3RhdHVzJztcbmltcG9ydCB7IFBsYWdpYXJpc21Db21wYXJpc29uIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtQ29tcGFyaXNvbic7XG5pbXBvcnQgeyBQbGFnaWFyaXNtU3VibWlzc2lvbkVsZW1lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21TdWJtaXNzaW9uRWxlbWVudCc7XG5pbXBvcnQgeyBQbGFnaWFyaXNtVmVyZGljdCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbVZlcmRpY3QnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbUNhc2VJbmZvIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtQ2FzZUluZm8nO1xuaW1wb3J0IHsgRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuXG5leHBvcnQgdHlwZSBFbnRpdHlSZXNwb25zZVR5cGUgPSBIdHRwUmVzcG9uc2U8UGxhZ2lhcmlzbUNhc2U+O1xuZXhwb3J0IHR5cGUgRW50aXR5QXJyYXlSZXNwb25zZVR5cGUgPSBIdHRwUmVzcG9uc2U8UGxhZ2lhcmlzbUNhc2VbXT47XG5leHBvcnQgdHlwZSBDb21wYXJpc29uID0gUGxhZ2lhcmlzbUNvbXBhcmlzb248UGxhZ2lhcmlzbVN1Ym1pc3Npb25FbGVtZW50PjtcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBQbGFnaWFyaXNtQ2FzZXNTZXJ2aWNlIHtcbiAgICBwcml2YXRlIHJlc291cmNlVXJsID0gJ2FwaS9jb3Vyc2VzJztcbiAgICBwcml2YXRlIHJlc291cmNlVXJsRXhlcmNpc2VzID0gJ2FwaS9leGVyY2lzZXMnO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50KSB7fVxuXG4gICAgLyogSW5zdHJ1Y3RvciAqL1xuXG4gICAgLyoqXG4gICAgICogR2V0IGFsbCBwbGFnaWFyaXNtIGNhc2VzIGZvciB0aGUgaW5zdHJ1Y3RvciBvZiB0aGUgY291cnNlIHdpdGggdGhlIGdpdmVuIGlkXG4gICAgICogQHBhcmFtIHsgbnVtYmVyIH0gY291cnNlSWQgaWQgb2YgdGhlIGNvdXJzZVxuICAgICAqL1xuICAgIHB1YmxpYyBnZXRDb3Vyc2VQbGFnaWFyaXNtQ2FzZXNGb3JJbnN0cnVjdG9yKGNvdXJzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEVudGl0eUFycmF5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFBsYWdpYXJpc21DYXNlW10+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7Y291cnNlSWR9L3BsYWdpYXJpc20tY2FzZXMvZm9yLWluc3RydWN0b3JgLCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGFsbCBwbGFnaWFyaXNtIGNhc2VzIGZvciB0aGUgaW5zdHJ1Y3RvciBvZiB0aGUgZXhhbSB3aXRoIHRoZSBnaXZlbiBpZFxuICAgICAqIEBwYXJhbSB7IG51bWJlciB9IGNvdXJzZUlkIGlkIG9mIHRoZSBjb3Vyc2VcbiAgICAgKiBAcGFyYW0geyBudW1iZXIgfSBleGFtSWQgaWQgb2YgdGhlIGV4YW1cbiAgICAgKi9cbiAgICBwdWJsaWMgZ2V0RXhhbVBsYWdpYXJpc21DYXNlc0Zvckluc3RydWN0b3IoY291cnNlSWQ6IG51bWJlciwgZXhhbUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEVudGl0eUFycmF5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFBsYWdpYXJpc21DYXNlW10+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7Y291cnNlSWR9L2V4YW1zLyR7ZXhhbUlkfS9wbGFnaWFyaXNtLWNhc2VzL2Zvci1pbnN0cnVjdG9yYCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCB0aGUgcGxhZ2lhcmlzbSBjYXNlIHdpdGggdGhlIGdpdmVuIGlkIGZvciB0aGUgaW5zdHJ1Y3RvclxuICAgICAqIEBwYXJhbSB7IG51bWJlciB9IGNvdXJzZUlkIGlkIG9mIHRoZSBjb3Vyc2VcbiAgICAgKiBAcGFyYW0geyBudW1iZXIgfSBwbGFnaWFyaXNtQ2FzZUlkIGlkIG9mIHRoZSBwbGFnaWFyaXNtQ2FzZVxuICAgICAqL1xuICAgIHB1YmxpYyBnZXRQbGFnaWFyaXNtQ2FzZURldGFpbEZvckluc3RydWN0b3IoY291cnNlSWQ6IG51bWJlciwgcGxhZ2lhcmlzbUNhc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxFbnRpdHlSZXNwb25zZVR5cGU+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8UGxhZ2lhcmlzbUNhc2U+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7Y291cnNlSWR9L3BsYWdpYXJpc20tY2FzZXMvJHtwbGFnaWFyaXNtQ2FzZUlkfS9mb3ItaW5zdHJ1Y3RvcmAsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKlxuICAgICAqIEBwYXJhbSB7IG51bWJlciB9IGNvdXJzZUlkIGlkIG9mIHRoZSBjb3Vyc2VcbiAgICAgKiBAcGFyYW0geyBudW1iZXIgfSBwbGFnaWFyaXNtQ2FzZUlkIGlkIG9mIHRoZSBwbGFnaWFyaXNtQ2FzZVxuICAgICAqIEBwYXJhbSBwbGFnaWFyaXNtVmVyZGljdCBwbGFnaWFyaXNtIGNhc2UgdmVyZGljdCB0byBzYXZlIGluY2x1ZGluZyB0aGUgdmVyZGljdCBpdHNlbGYgYW5kIG9wdGlvbmFsbHkgdGhlIG1lc3NhZ2Ugb3IgdGhlIHBvaW50IGRlZHVjdGlvblxuICAgICAqL1xuICAgIHB1YmxpYyBzYXZlVmVyZGljdChcbiAgICAgICAgY291cnNlSWQ6IG51bWJlcixcbiAgICAgICAgcGxhZ2lhcmlzbUNhc2VJZDogbnVtYmVyLFxuICAgICAgICBwbGFnaWFyaXNtVmVyZGljdDogeyB2ZXJkaWN0OiBQbGFnaWFyaXNtVmVyZGljdDsgdmVyZGljdE1lc3NhZ2U/OiBzdHJpbmc7IHZlcmRpY3RQb2ludERlZHVjdGlvbj86IG51bWJlciB9LFxuICAgICk6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucHV0PFBsYWdpYXJpc21DYXNlPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2NvdXJzZUlkfS9wbGFnaWFyaXNtLWNhc2VzLyR7cGxhZ2lhcmlzbUNhc2VJZH0vdmVyZGljdGAsIHBsYWdpYXJpc21WZXJkaWN0LCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgLyogU3R1ZGVudCAqL1xuXG4gICAgLyoqXG4gICAgICogR2V0IHRoZSBwbGFnaWFyaXNtIGNhc2UgaW5mbyBmb3IgdGhlIHN0dWRlbnQgZm9yIHRoZSBnaXZlbiBjb3Vyc2UgYW5kIGV4ZXJjaXNlXG4gICAgICogQHBhcmFtIHsgbnVtYmVyIH0gY291cnNlSWQgaWQgb2YgdGhlIGNvdXJzZVxuICAgICAqIEBwYXJhbSB7IG51bWJlciB9IGV4ZXJjaXNlSWQgaWQgb2YgdGhlIGV4ZXJjaXNlXG4gICAgICovXG4gICAgcHVibGljIGdldFBsYWdpYXJpc21DYXNlSW5mb0ZvclN0dWRlbnQoY291cnNlSWQ6IG51bWJlciwgZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8UGxhZ2lhcmlzbUNhc2VJbmZvPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxQbGFnaWFyaXNtQ2FzZUluZm8+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7Y291cnNlSWR9L2V4ZXJjaXNlcy8ke2V4ZXJjaXNlSWR9L3BsYWdpYXJpc20tY2FzZWAsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgdGhlIHBsYWdpYXJpc20gY2FzZSBpbmZvcyBmb3IgdGhlIHN0dWRlbnQgZm9yIHRoZSBnaXZlbiBjb3Vyc2UgYW5kIGV4ZXJjaXNlIGlkIGxpc3QgZm9yIHRoZSBleGVyY2lzZXMgdGhhdCB0aGUgc3R1ZGVudCBpcyBhbGxvd2VkIHRvIGFjY2Vzcy5cbiAgICAgKiBAcGFyYW0geyBudW1iZXIgfSBjb3Vyc2VJZCBpZCBvZiB0aGUgY291cnNlXG4gICAgICogQHBhcmFtIHsgbnVtYmVyW10gfSBleGVyY2lzZUlkcyBpZHMgb2YgdGhlIGV4ZXJjaXNlc1xuICAgICAqL1xuICAgIHB1YmxpYyBnZXRQbGFnaWFyaXNtQ2FzZUluZm9zRm9yU3R1ZGVudChjb3Vyc2VJZDogbnVtYmVyLCBleGVyY2lzZUlkczogbnVtYmVyW10pOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTx7IFtleGVyY2lzZUlkOiBudW1iZXJdOiBQbGFnaWFyaXNtQ2FzZUluZm8gfT4+IHtcbiAgICAgICAgbGV0IHBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKCk7XG4gICAgICAgIGZvciAoY29uc3QgZXhlcmNpc2VJZCBvZiBleGVyY2lzZUlkcykge1xuICAgICAgICAgICAgcGFyYW1zID0gcGFyYW1zLmFwcGVuZCgnZXhlcmNpc2VJZCcsIGV4ZXJjaXNlSWQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFBsYWdpYXJpc21DYXNlSW5mb1tdPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2NvdXJzZUlkfS9wbGFnaWFyaXNtLWNhc2VzYCwgeyBwYXJhbXMsIG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IHRoZSBwbGFnaWFyaXNtIGNhc2Ugd2l0aCB0aGUgZ2l2ZW4gaWQgZm9yIHRoZSBzdHVkZW50XG4gICAgICogQHBhcmFtIHsgbnVtYmVyIH0gY291cnNlSWQgaWQgb2YgdGhlIGNvdXJzZVxuICAgICAqIEBwYXJhbSB7IG51bWJlciB9IHBsYWdpYXJpc21DYXNlSWQgaWQgb2YgdGhlIHBsYWdpYXJpc21DYXNlXG4gICAgICovXG4gICAgcHVibGljIGdldFBsYWdpYXJpc21DYXNlRGV0YWlsRm9yU3R1ZGVudChjb3Vyc2VJZDogbnVtYmVyLCBwbGFnaWFyaXNtQ2FzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxQbGFnaWFyaXNtQ2FzZT4oYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtjb3Vyc2VJZH0vcGxhZ2lhcmlzbS1jYXNlcy8ke3BsYWdpYXJpc21DYXNlSWR9L2Zvci1zdHVkZW50YCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCB0aGUgcGxhZ2lhcmlzbSBjb21wYXJpc29uIHdpdGggdGhlIGdpdmVuIGlkXG4gICAgICogQHBhcmFtIHsgbnVtYmVyIH0gY291cnNlSWRcbiAgICAgKiBAcGFyYW0geyBudW1iZXIgfSBwbGFnaWFyaXNtQ29tcGFyaXNvbklkXG4gICAgICovXG4gICAgcHVibGljIGdldFBsYWdpYXJpc21Db21wYXJpc29uRm9yU3BsaXRWaWV3KGNvdXJzZUlkOiBudW1iZXIsIHBsYWdpYXJpc21Db21wYXJpc29uSWQ6IG51bWJlcik6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPENvbXBhcmlzb24+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PENvbXBhcmlzb24+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7Y291cnNlSWR9L3BsYWdpYXJpc20tY29tcGFyaXNvbnMvJHtwbGFnaWFyaXNtQ29tcGFyaXNvbklkfS9mb3Itc3BsaXQtdmlld2AsIHtcbiAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZSB0aGUgc3RhdHVzIG9mIHRoZSBwbGFnaWFyaXNtIGNvbXBhcmlzb24gd2l0aCBnaXZlbiBpZFxuICAgICAqIEBwYXJhbSB7IG51bWJlciB9IGNvdXJzZUlkXG4gICAgICogQHBhcmFtIHsgbnVtYmVyIH0gcGxhZ2lhcmlzbUNvbXBhcmlzb25JZFxuICAgICAqIEBwYXJhbSB7IFBsYWdpYXJpc21TdGF0dXMgfSBzdGF0dXNcbiAgICAgKi9cbiAgICBwdWJsaWMgdXBkYXRlUGxhZ2lhcmlzbUNvbXBhcmlzb25TdGF0dXMoY291cnNlSWQ6IG51bWJlciwgcGxhZ2lhcmlzbUNvbXBhcmlzb25JZDogbnVtYmVyLCBzdGF0dXM6IFBsYWdpYXJpc21TdGF0dXMpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTx2b2lkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnB1dDx2b2lkPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2NvdXJzZUlkfS9wbGFnaWFyaXNtLWNvbXBhcmlzb25zLyR7cGxhZ2lhcmlzbUNvbXBhcmlzb25JZH0vc3RhdHVzYCwgeyBzdGF0dXMgfSwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENsZWFuIHVwIHBsYWdpYXJpc20gcmVzdWx0cyBhbmQgY29tcGFyaXNvbnNcbiAgICAgKiBJZiBkZWxldGVBbGwgaXMgc2V0IHRvIHRydWUsIGFsbCBwbGFnaWFyaXNtIHJlc3VsdHMgYmVsb25naW5nIHRvIHRoZSBleGVyY2lzZSBhcmUgZGVsZXRlZCxcbiAgICAgKiBvdGhlcndpc2Ugb25seSBwbGFnaWFyaXNtIGNvbXBhcmlzb25zIG9yIHdpdGggc3RhdHVzIERFTklFRCBvciBDT05GSVJNRUQgYXJlIGRlbGV0ZWQgYW5kIG9sZCByZXN1bHRzIGFyZSBkZWxldGVkIGFzIHdlbGwuXG4gICAgICpcbiAgICAgKiBAcGFyYW0geyBudW1iZXIgfSBleGVyY2lzZUlkXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IHBsYWdpYXJpc21SZXN1bHRJZFxuICAgICAqIEBwYXJhbSB7IGJvb2xlYW4gfSBkZWxldGVBbGxcbiAgICAgKi9cbiAgICBwdWJsaWMgY2xlYW5VcFBsYWdpYXJpc20oZXhlcmNpc2VJZDogbnVtYmVyLCBwbGFnaWFyaXNtUmVzdWx0SWQ6IG51bWJlciwgZGVsZXRlQWxsID0gZmFsc2UpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTx2b2lkPj4ge1xuICAgICAgICBjb25zdCBwYXJhbXMgPSBuZXcgSHR0cFBhcmFtcygpLmFwcGVuZCgnZGVsZXRlQWxsJywgZGVsZXRlQWxsID8gJ3RydWUnIDogJ2ZhbHNlJyk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZGVsZXRlPHZvaWQ+KGAke3RoaXMucmVzb3VyY2VVcmxFeGVyY2lzZXN9LyR7ZXhlcmNpc2VJZH0vcGxhZ2lhcmlzbS1yZXN1bHRzLyR7cGxhZ2lhcmlzbVJlc3VsdElkfS9wbGFnaWFyaXNtLWNvbXBhcmlzb25zYCwge1xuICAgICAgICAgICAgcGFyYW1zLFxuICAgICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHB1YmxpYyBnZXROdW1iZXJPZlBsYWdpYXJpc21DYXNlc0ZvckV4ZXJjaXNlKGV4ZXJjaXNlOiBFeGVyY2lzZSk6IE9ic2VydmFibGU8bnVtYmVyPiB7XG4gICAgICAgIGxldCBjb3Vyc2VJZDogbnVtYmVyO1xuICAgICAgICBpZiAoZXhlcmNpc2UuZXhlcmNpc2VHcm91cCkge1xuICAgICAgICAgICAgY291cnNlSWQgPSBleGVyY2lzZS5leGVyY2lzZUdyb3VwLmV4YW0hLmNvdXJzZSEuaWQhO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY291cnNlSWQgPSBleGVyY2lzZS5jb3Vyc2UhLmlkITtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBleGVyY2lzZUlkID0gZXhlcmNpc2UhLmlkO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxudW1iZXI+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7Y291cnNlSWR9L2V4ZXJjaXNlcy8ke2V4ZXJjaXNlSWR9L3BsYWdpYXJpc20tY2FzZXMtY291bnRgKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50LCBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBtYXAsIHRhcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IE1vZGVsaW5nRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvbW9kZWxpbmctZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgY3JlYXRlUmVxdWVzdE9wdGlvbiB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC9yZXF1ZXN0LnV0aWwnO1xuaW1wb3J0IHsgRXhlcmNpc2VTZXJ2aWNhYmxlLCBFeGVyY2lzZVNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS9leGVyY2lzZS5zZXJ2aWNlJztcbmltcG9ydCB7IE1vZGVsaW5nUGxhZ2lhcmlzbVJlc3VsdCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvbW9kZWxpbmcvTW9kZWxpbmdQbGFnaWFyaXNtUmVzdWx0JztcbmltcG9ydCB7IFBsYWdpYXJpc21PcHRpb25zIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtT3B0aW9ucyc7XG5pbXBvcnQgeyBkb3dubG9hZFN0cmVhbSB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC9kb3dubG9hZC51dGlsJztcbmltcG9ydCB7IFBsYWdpYXJpc21SZXN1bHREVE8gfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21SZXN1bHREVE8nO1xuXG5leHBvcnQgdHlwZSBFbnRpdHlSZXNwb25zZVR5cGUgPSBIdHRwUmVzcG9uc2U8TW9kZWxpbmdFeGVyY2lzZT47XG5leHBvcnQgdHlwZSBFbnRpdHlBcnJheVJlc3BvbnNlVHlwZSA9IEh0dHBSZXNwb25zZTxNb2RlbGluZ0V4ZXJjaXNlW10+O1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIE1vZGVsaW5nRXhlcmNpc2VTZXJ2aWNlIGltcGxlbWVudHMgRXhlcmNpc2VTZXJ2aWNhYmxlPE1vZGVsaW5nRXhlcmNpc2U+IHtcbiAgICBwdWJsaWMgcmVzb3VyY2VVcmwgPSAnYXBpL21vZGVsaW5nLWV4ZXJjaXNlcyc7XG4gICAgcHVibGljIGFkbWluUmVzb3VyY2VVcmwgPSAnYXBpL2FkbWluL21vZGVsaW5nLWV4ZXJjaXNlcyc7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50LFxuICAgICAgICBwcml2YXRlIGV4ZXJjaXNlU2VydmljZTogRXhlcmNpc2VTZXJ2aWNlLFxuICAgICkge1xuICAgICAgICB0aGlzLmV4ZXJjaXNlU2VydmljZSA9IGV4ZXJjaXNlU2VydmljZTtcbiAgICB9XG5cbiAgICBjcmVhdGUobW9kZWxpbmdFeGVyY2lzZTogTW9kZWxpbmdFeGVyY2lzZSk6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIGxldCBjb3B5ID0gRXhlcmNpc2VTZXJ2aWNlLmNvbnZlcnRFeGVyY2lzZURhdGVzRnJvbUNsaWVudChtb2RlbGluZ0V4ZXJjaXNlKTtcbiAgICAgICAgY29weSA9IEV4ZXJjaXNlU2VydmljZS5zZXRCb251c1BvaW50c0NvbnN0cmFpbmVkQnlJbmNsdWRlZEluT3ZlcmFsbFNjb3JlKGNvcHkpO1xuICAgICAgICBjb3B5LmNhdGVnb3JpZXMgPSBFeGVyY2lzZVNlcnZpY2Uuc3RyaW5naWZ5RXhlcmNpc2VDYXRlZ29yaWVzKGNvcHkpO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAucG9zdDxNb2RlbGluZ0V4ZXJjaXNlPih0aGlzLnJlc291cmNlVXJsLCBjb3B5LCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpID0+IHRoaXMuZXhlcmNpc2VTZXJ2aWNlLnByb2Nlc3NFeGVyY2lzZUVudGl0eVJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG5cbiAgICB1cGRhdGUobW9kZWxpbmdFeGVyY2lzZTogTW9kZWxpbmdFeGVyY2lzZSwgcmVxPzogYW55KTogT2JzZXJ2YWJsZTxFbnRpdHlSZXNwb25zZVR5cGU+IHtcbiAgICAgICAgY29uc3Qgb3B0aW9ucyA9IGNyZWF0ZVJlcXVlc3RPcHRpb24ocmVxKTtcbiAgICAgICAgbGV0IGNvcHkgPSBFeGVyY2lzZVNlcnZpY2UuY29udmVydEV4ZXJjaXNlRGF0ZXNGcm9tQ2xpZW50KG1vZGVsaW5nRXhlcmNpc2UpO1xuICAgICAgICBjb3B5ID0gRXhlcmNpc2VTZXJ2aWNlLnNldEJvbnVzUG9pbnRzQ29uc3RyYWluZWRCeUluY2x1ZGVkSW5PdmVyYWxsU2NvcmUoY29weSk7XG4gICAgICAgIGNvcHkuY2F0ZWdvcmllcyA9IEV4ZXJjaXNlU2VydmljZS5zdHJpbmdpZnlFeGVyY2lzZUNhdGVnb3JpZXMoY29weSk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5wdXQ8TW9kZWxpbmdFeGVyY2lzZT4odGhpcy5yZXNvdXJjZVVybCwgY29weSwgeyBwYXJhbXM6IG9wdGlvbnMsIG9ic2VydmU6ICdyZXNwb25zZScgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpID0+IHRoaXMuZXhlcmNpc2VTZXJ2aWNlLnByb2Nlc3NFeGVyY2lzZUVudGl0eVJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG5cbiAgICBmaW5kKG1vZGVsaW5nRXhlcmNpc2VJZDogbnVtYmVyLCB3aXRoUGxhZ2lhcmlzbURldGVjdGlvbkNvbmZpZzogYm9vbGVhbiA9IGZhbHNlKTogT2JzZXJ2YWJsZTxFbnRpdHlSZXNwb25zZVR5cGU+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLmdldDxNb2RlbGluZ0V4ZXJjaXNlPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke21vZGVsaW5nRXhlcmNpc2VJZH1gLCB7IG9ic2VydmU6ICdyZXNwb25zZScsIHBhcmFtczogeyB3aXRoUGxhZ2lhcmlzbURldGVjdGlvbkNvbmZpZzogd2l0aFBsYWdpYXJpc21EZXRlY3Rpb25Db25maWcgfSB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEVudGl0eVJlc3BvbnNlVHlwZSkgPT4gdGhpcy5leGVyY2lzZVNlcnZpY2UucHJvY2Vzc0V4ZXJjaXNlRW50aXR5UmVzcG9uc2UocmVzKSkpO1xuICAgIH1cblxuICAgIGRlbGV0ZShtb2RlbGluZ0V4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPGFueT4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5kZWxldGUoYCR7dGhpcy5yZXNvdXJjZVVybH0vJHttb2RlbGluZ0V4ZXJjaXNlSWR9YCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEltcG9ydHMgYSBtb2RlbGluZyBleGVyY2lzZSBieSBjbG9uaW5nIHRoZSBlbnRpdHkgaXRzZWxmIHBsdXMgZXhhbXBsZSBzb2x1dGlvbnMgYW5kIGV4YW1wbGUgc3VibWlzc2lvbnNcbiAgICAgKlxuICAgICAqIEBwYXJhbSBhZGFwdGVkU291cmNlTW9kZWxpbmdFeGVyY2lzZSBUaGUgZXhlcmNpc2UgdGhhdCBzaG91bGQgYmUgaW1wb3J0ZWQsIGluY2x1ZGluZyBhZGFwdGVkIHZhbHVlcyBmb3IgdGhlXG4gICAgICogbmV3IGV4ZXJjaXNlLiBFLmcuIHdpdGggYW5vdGhlciB0aXRsZSB0aGFuIHRoZSBvcmlnaW5hbCBleGVyY2lzZS4gT2xkIHZhbHVlcyB0aGF0IHNob3VsZCBnZXQgZGlzY2FyZGVkXG4gICAgICogKGxpa2UgdGhlIG9sZCBJRCkgd2lsbCBiZSBoYW5kbGVkIGJ5IHRoZSBzZXJ2ZXIuXG4gICAgICovXG4gICAgaW1wb3J0KGFkYXB0ZWRTb3VyY2VNb2RlbGluZ0V4ZXJjaXNlOiBNb2RlbGluZ0V4ZXJjaXNlKSB7XG4gICAgICAgIGxldCBjb3B5ID0gRXhlcmNpc2VTZXJ2aWNlLmNvbnZlcnRFeGVyY2lzZURhdGVzRnJvbUNsaWVudChhZGFwdGVkU291cmNlTW9kZWxpbmdFeGVyY2lzZSk7XG4gICAgICAgIGNvcHkgPSBFeGVyY2lzZVNlcnZpY2Uuc2V0Qm9udXNQb2ludHNDb25zdHJhaW5lZEJ5SW5jbHVkZWRJbk92ZXJhbGxTY29yZShjb3B5KTtcbiAgICAgICAgY29weS5jYXRlZ29yaWVzID0gRXhlcmNpc2VTZXJ2aWNlLnN0cmluZ2lmeUV4ZXJjaXNlQ2F0ZWdvcmllcyhjb3B5KTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLnBvc3Q8TW9kZWxpbmdFeGVyY2lzZT4oYCR7dGhpcy5yZXNvdXJjZVVybH0vaW1wb3J0LyR7YWRhcHRlZFNvdXJjZU1vZGVsaW5nRXhlcmNpc2UuaWR9YCwgY29weSwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlczogRW50aXR5UmVzcG9uc2VUeXBlKSA9PiB0aGlzLmV4ZXJjaXNlU2VydmljZS5wcm9jZXNzRXhlcmNpc2VFbnRpdHlSZXNwb25zZShyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgZm9yIHBsYWdpYXJpc21cbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCBvZiB0aGUgcHJvZ3JhbW1pbmcgZXhlcmNpc2VcbiAgICAgKiBAcGFyYW0gb3B0aW9uc1xuICAgICAqL1xuICAgIGNoZWNrUGxhZ2lhcmlzbShleGVyY2lzZUlkOiBudW1iZXIsIG9wdGlvbnM/OiBQbGFnaWFyaXNtT3B0aW9ucyk6IE9ic2VydmFibGU8UGxhZ2lhcmlzbVJlc3VsdERUTzxNb2RlbGluZ1BsYWdpYXJpc21SZXN1bHQ+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5nZXQ8UGxhZ2lhcmlzbVJlc3VsdERUTzxNb2RlbGluZ1BsYWdpYXJpc21SZXN1bHQ+PihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L2NoZWNrLXBsYWdpYXJpc21gLCB7IG9ic2VydmU6ICdyZXNwb25zZScsIHBhcmFtczogeyAuLi5vcHRpb25zPy50b1BhcmFtcygpIH0gfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzcG9uc2U6IEh0dHBSZXNwb25zZTxQbGFnaWFyaXNtUmVzdWx0RFRPPE1vZGVsaW5nUGxhZ2lhcmlzbVJlc3VsdD4+KSA9PiByZXNwb25zZS5ib2R5ISkpO1xuICAgIH1cblxuICAgIGNvbnZlcnRUb1BkZihtb2RlbDogc3RyaW5nLCBmaWxlbmFtZTogc3RyaW5nKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8QmxvYj4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLnBvc3QoJ2FwaS9hcG9sbG9uL2NvbnZlcnQtdG8tcGRmJywgeyBtb2RlbCB9LCB7IG9ic2VydmU6ICdyZXNwb25zZScsIHJlc3BvbnNlVHlwZTogJ2Jsb2InIH0pXG4gICAgICAgICAgICAucGlwZSh0YXAoKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2U8QmxvYj4pID0+IGRvd25sb2FkU3RyZWFtKHJlc3BvbnNlLmJvZHksICdhcHBsaWNhdGlvbi9wZGYnLCBmaWxlbmFtZSkpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgdGhlIGxhdGVzdCBwbGFnaWFyaXNtIHJlc3VsdCBmb3IgdGhlIGV4ZXJjaXNlIHdpdGggdGhlIGdpdmVuIElELlxuICAgICAqXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlSWRcbiAgICAgKi9cbiAgICBnZXRMYXRlc3RQbGFnaWFyaXNtUmVzdWx0KGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8UGxhZ2lhcmlzbVJlc3VsdERUTzxNb2RlbGluZ1BsYWdpYXJpc21SZXN1bHQ+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5nZXQ8UGxhZ2lhcmlzbVJlc3VsdERUTzxNb2RlbGluZ1BsYWdpYXJpc21SZXN1bHQ+PihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L3BsYWdpYXJpc20tcmVzdWx0YCwge1xuICAgICAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXNwb25zZTogSHR0cFJlc3BvbnNlPFBsYWdpYXJpc21SZXN1bHREVE88TW9kZWxpbmdQbGFnaWFyaXNtUmVzdWx0Pj4pID0+IHJlc3BvbnNlLmJvZHkhKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IHRoZSBudW1iZXIgb2YgY2x1c3RlcnMgZm9yIHRoZSBleGVyY2lzZSB3aXRoIHRoZSBnaXZlbiBJRC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkXG4gICAgICovXG4gICAgZ2V0TnVtYmVyT2ZDbHVzdGVycyhleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxudW1iZXI+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PG51bWJlcj4oYCR7dGhpcy5hZG1pblJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L2NoZWNrLWNsdXN0ZXJzYCwge1xuICAgICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQnVpbGQgdGhlIGNsdXN0ZXJzIHRvIHVzZSBpbiBDb21wYXNzXG4gICAgICogQHBhcmFtIG1vZGVsaW5nRXhlcmNpc2VJZCBpZCBvZiB0aGUgZXhlcmNpc2UgdG8gYnVpbGQgdGhlIGNsdXN0ZXJzIGZvclxuICAgICAqL1xuICAgIGJ1aWxkQ2x1c3RlcnMobW9kZWxpbmdFeGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QoYCR7dGhpcy5hZG1pblJlc291cmNlVXJsfS8ke21vZGVsaW5nRXhlcmNpc2VJZH0vdHJpZ2dlci1hdXRvbWF0aWMtYXNzZXNzbWVudGAsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEZWxldGUgdGhlIGNsdXN0ZXJzIHVzZWQgaW4gQ29tcGFzc1xuICAgICAqIEBwYXJhbSBtb2RlbGluZ0V4ZXJjaXNlSWQgaWQgb2YgdGhlIGV4ZXJjaXNlIHRvIGRlbGV0ZSB0aGUgY2x1c3RlcnMgb2ZcbiAgICAgKi9cbiAgICBkZWxldGVDbHVzdGVycyhtb2RlbGluZ0V4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPHZvaWQ+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZGVsZXRlPHZvaWQ+KGAke3RoaXMuYWRtaW5SZXNvdXJjZVVybH0vJHttb2RlbGluZ0V4ZXJjaXNlSWR9L2NsdXN0ZXJzYCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlLWV2YWx1YXRlcyBhbmQgdXBkYXRlcyBhIG1vZGVsaW5nIGV4ZXJjaXNlLlxuICAgICAqXG4gICAgICogQHBhcmFtIG1vZGVsaW5nRXhlcmNpc2UgdGhhdCBzaG91bGQgYmUgdXBkYXRlZCBvZiB0eXBlIHtNb2RlbGluZ0V4ZXJjaXNlfVxuICAgICAqIEBwYXJhbSByZXEgb3B0aW9uYWwgcmVxdWVzdCBvcHRpb25zXG4gICAgICovXG4gICAgcmVldmFsdWF0ZUFuZFVwZGF0ZShtb2RlbGluZ0V4ZXJjaXNlOiBNb2RlbGluZ0V4ZXJjaXNlLCByZXE/OiBhbnkpOiBPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT4ge1xuICAgICAgICBjb25zdCBvcHRpb25zID0gY3JlYXRlUmVxdWVzdE9wdGlvbihyZXEpO1xuICAgICAgICBsZXQgY29weSA9IEV4ZXJjaXNlU2VydmljZS5jb252ZXJ0RXhlcmNpc2VEYXRlc0Zyb21DbGllbnQobW9kZWxpbmdFeGVyY2lzZSk7XG4gICAgICAgIGNvcHkgPSBFeGVyY2lzZVNlcnZpY2Uuc2V0Qm9udXNQb2ludHNDb25zdHJhaW5lZEJ5SW5jbHVkZWRJbk92ZXJhbGxTY29yZShjb3B5KTtcbiAgICAgICAgY29weS5jYXRlZ29yaWVzID0gRXhlcmNpc2VTZXJ2aWNlLnN0cmluZ2lmeUV4ZXJjaXNlQ2F0ZWdvcmllcyhjb3B5KTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLnB1dDxNb2RlbGluZ0V4ZXJjaXNlPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke21vZGVsaW5nRXhlcmNpc2UuaWR9L3JlLWV2YWx1YXRlYCwgY29weSwgeyBwYXJhbXM6IG9wdGlvbnMsIG9ic2VydmU6ICdyZXNwb25zZScgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpID0+IHRoaXMuZXhlcmNpc2VTZXJ2aWNlLnByb2Nlc3NFeGVyY2lzZUVudGl0eVJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG59XG4iLCIvKipcbiAqIEFmdGVyIGF1dG9tYXRpYyBkZXRlY3Rpb24sIGVhY2ggcGxhZ2lhcmlzbSBoYXMgdG8gYmUgcmV2aWV3ZWQgYW5kIHJldmFsaWRhdGVkIGJ5IGFuIGluc3RydWN0b3IuXG4gKi9cbmV4cG9ydCBlbnVtIFBsYWdpYXJpc21TdGF0dXMge1xuICAgIC8qKlxuICAgICAqIFBsYWdpYXJpc20gaGFzIGJlZW4gY29uZmlybWVkIGJ5IGFuIGluc3RydWN0b3IuXG4gICAgICovXG4gICAgQ09ORklSTUVEID0gJ0NPTkZJUk1FRCcsXG5cbiAgICAvKipcbiAgICAgKiBQbGFnaWFyaXNtIGhhcyBiZWVuIGRlbmllZCBieSBhbiBpbnN0cnVjdG9yLlxuICAgICAqL1xuICAgIERFTklFRCA9ICdERU5JRUQnLFxuXG4gICAgLyoqXG4gICAgICogVGhlIGluY2lkZW50IGhhcyBub3QgYmVlbiByZXZpZXdlZCB5ZXQuXG4gICAgICovXG4gICAgTk9ORSA9ICdOT05FJyxcbn1cbiIsImltcG9ydCB7IFBsYWdpYXJpc21TdGF0dXMgfSBmcm9tICcuL1BsYWdpYXJpc21TdGF0dXMnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbVN1Ym1pc3Npb24gfSBmcm9tICcuL1BsYWdpYXJpc21TdWJtaXNzaW9uJztcbmltcG9ydCB7IFBsYWdpYXJpc21NYXRjaCB9IGZyb20gJy4vUGxhZ2lhcmlzbU1hdGNoJztcbmltcG9ydCB7IFBsYWdpYXJpc21TdWJtaXNzaW9uRWxlbWVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbVN1Ym1pc3Npb25FbGVtZW50JztcbmltcG9ydCB7IFBsYWdpYXJpc21SZXN1bHQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21SZXN1bHQnO1xuXG4vKipcbiAqIFBhaXIgb2YgY29tcGFyZWQgc3R1ZGVudCBzdWJtaXNzaW9ucyB3aG9zZSBzaW1pbGFyaXR5IGlzIGFib3ZlIGEgY2VydGFpbiB0aHJlc2hvbGQuXG4gKi9cbmV4cG9ydCBjbGFzcyBQbGFnaWFyaXNtQ29tcGFyaXNvbjxFIGV4dGVuZHMgUGxhZ2lhcmlzbVN1Ym1pc3Npb25FbGVtZW50PiB7XG4gICAgLyoqXG4gICAgICogVW5pcXVlIGlkZW50aWZpZXIgb2YgdGhlIGNvbXBhcmlzb24uXG4gICAgICovXG4gICAgaWQ6IG51bWJlcjtcblxuICAgIC8qKlxuICAgICAqIFRoZSBwbGFnaWFyaXNtIHJlc3VsdFxuICAgICAqL1xuICAgIHBsYWdpYXJpc21SZXN1bHQ/OiBQbGFnaWFyaXNtUmVzdWx0PFBsYWdpYXJpc21TdWJtaXNzaW9uRWxlbWVudD47XG5cbiAgICAvKipcbiAgICAgKiBGaXJzdCBzdWJtaXNzaW9uIGludm9sdmVkIGluIHRoaXMgY29tcGFyaXNvbi5cbiAgICAgKi9cbiAgICBzdWJtaXNzaW9uQTogUGxhZ2lhcmlzbVN1Ym1pc3Npb248RT47XG5cbiAgICAvKipcbiAgICAgKiBTZWNvbmQgc3VibWlzc2lvbiBpbnZvbHZlZCBpbiB0aGlzIGNvbXBhcmlzb24uXG4gICAgICovXG4gICAgc3VibWlzc2lvbkI6IFBsYWdpYXJpc21TdWJtaXNzaW9uPEU+O1xuXG4gICAgLyoqXG4gICAgICogTGlzdCBvZiBtYXRjaGVzIGJldHdlZW4gYm90aCBzdWJtaXNzaW9ucyBpbnZvbHZlZCBpbiB0aGlzIGNvbXBhcmlzb24uXG4gICAgICovXG4gICAgbWF0Y2hlcz86IFBsYWdpYXJpc21NYXRjaFtdO1xuXG4gICAgLyoqXG4gICAgICogU2ltaWxhcml0eSBvZiB0aGUgY29tcGFyZWQgc3VibWlzc2lvbnMgaW4gcGVyY2VudGFnZSAoYmV0d2VlbiAwIGFuZCAxMDApLlxuICAgICAqL1xuICAgIHNpbWlsYXJpdHk6IG51bWJlcjtcblxuICAgIC8qKlxuICAgICAqIFN0YXR1cyBvZiB0aGlzIHN1Ym1pc3Npb24gY29tcGFyaXNvbi5cbiAgICAgKi9cbiAgICBzdGF0dXM6IFBsYWdpYXJpc21TdGF0dXM7XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBQbGFnaWFyaXNtU3RhdHVzIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtU3RhdHVzJztcbmltcG9ydCB7IFBsYWdpYXJpc21Db21wYXJpc29uIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtQ29tcGFyaXNvbic7XG5pbXBvcnQgeyBUZXh0U3VibWlzc2lvbkVsZW1lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL3RleHQvVGV4dFN1Ym1pc3Npb25FbGVtZW50JztcbmltcG9ydCB7IE1vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL21vZGVsaW5nL01vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbUNhc2VzU2VydmljZSB9IGZyb20gJ2FwcC9jb3Vyc2UvcGxhZ2lhcmlzbS1jYXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS1jYXNlcy5zZXJ2aWNlJztcbmltcG9ydCB7IENvbmZpcm1BdXRvZm9jdXNNb2RhbENvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9jb25maXJtLWF1dG9mb2N1cy1tb2RhbC5jb21wb25lbnQnO1xuaW1wb3J0IHsgTmdiTW9kYWwgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgeyBFeGVyY2lzZSwgZ2V0Q291cnNlSWQgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1wbGFnaWFyaXNtLWhlYWRlcicsXG4gICAgc3R5bGVVcmxzOiBbJy4vcGxhZ2lhcmlzbS1oZWFkZXIuY29tcG9uZW50LnNjc3MnXSxcbiAgICB0ZW1wbGF0ZVVybDogJy4vcGxhZ2lhcmlzbS1oZWFkZXIuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBQbGFnaWFyaXNtSGVhZGVyQ29tcG9uZW50IHtcbiAgICBASW5wdXQoKSBjb21wYXJpc29uOiBQbGFnaWFyaXNtQ29tcGFyaXNvbjxUZXh0U3VibWlzc2lvbkVsZW1lbnQgfCBNb2RlbGluZ1N1Ym1pc3Npb25FbGVtZW50PjtcbiAgICBASW5wdXQoKSBleGVyY2lzZTogRXhlcmNpc2U7XG4gICAgQElucHV0KCkgc3BsaXRDb250cm9sU3ViamVjdDogU3ViamVjdDxzdHJpbmc+O1xuXG4gICAgcmVhZG9ubHkgcGxhZ2lhcmlzbVN0YXR1cyA9IFBsYWdpYXJpc21TdGF0dXM7XG4gICAgZGlzYWJsZUNvbmZpcm1EZW55QnV0dG9uID0gZmFsc2U7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBwbGFnaWFyaXNtQ2FzZXNTZXJ2aWNlOiBQbGFnaWFyaXNtQ2FzZXNTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIG1vZGFsU2VydmljZTogTmdiTW9kYWwsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogU2V0IHRoZSBzdGF0dXMgb2YgdGhlIGN1cnJlbnRseSBzZWxlY3RlZCBjb21wYXJpc29uIHRvIENPTkZJUk1FRC5cbiAgICAgKi9cbiAgICBjb25maXJtUGxhZ2lhcmlzbSgpIHtcbiAgICAgICAgdGhpcy51cGRhdGVQbGFnaWFyaXNtU3RhdHVzKFBsYWdpYXJpc21TdGF0dXMuQ09ORklSTUVEKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXQgdGhlIHN0YXR1cyBvZiB0aGUgY3VycmVudGx5IHNlbGVjdGVkIGNvbXBhcmlzb24gdG8gREVOSUVELlxuICAgICAqL1xuICAgIGRlbnlQbGFnaWFyaXNtKCkge1xuICAgICAgICBpZiAodGhpcy5jb21wYXJpc29uLnN0YXR1cyA9PT0gUGxhZ2lhcmlzbVN0YXR1cy5DT05GSVJNRUQpIHtcbiAgICAgICAgICAgIHRoaXMuYXNrRm9yQ29uZmlybWF0aW9uT2ZEZW55aW5nKCgpID0+IHRoaXMudXBkYXRlUGxhZ2lhcmlzbVN0YXR1cyhQbGFnaWFyaXNtU3RhdHVzLkRFTklFRCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy51cGRhdGVQbGFnaWFyaXNtU3RhdHVzKFBsYWdpYXJpc21TdGF0dXMuREVOSUVEKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgYXNrRm9yQ29uZmlybWF0aW9uT2ZEZW55aW5nKG9uQ29uZmlybTogKCkgPT4gdm9pZCkge1xuICAgICAgICB0aGlzLmRpc2FibGVDb25maXJtRGVueUJ1dHRvbiA9IHRydWU7XG5cbiAgICAgICAgY29uc3QgbW9kYWxSZWYgPSB0aGlzLm1vZGFsU2VydmljZS5vcGVuKENvbmZpcm1BdXRvZm9jdXNNb2RhbENvbXBvbmVudCwgeyBrZXlib2FyZDogdHJ1ZSwgc2l6ZTogJ2xnJyB9KTtcbiAgICAgICAgbW9kYWxSZWYuY29tcG9uZW50SW5zdGFuY2UudGl0bGUgPSAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLmRlbnlBZnRlckNvbmZpcm1Nb2RhbFRpdGxlJztcbiAgICAgICAgbW9kYWxSZWYuY29tcG9uZW50SW5zdGFuY2UudGV4dCA9ICdhcnRlbWlzQXBwLnBsYWdpYXJpc20uZGVueUFmdGVyQ29uZmlybU1vZGFsVGV4dCc7XG4gICAgICAgIG1vZGFsUmVmLmNvbXBvbmVudEluc3RhbmNlLnRyYW5zbGF0ZVRleHQgPSB0cnVlO1xuICAgICAgICBtb2RhbFJlZi5yZXN1bHQudGhlbihvbkNvbmZpcm0sICgpID0+ICh0aGlzLmRpc2FibGVDb25maXJtRGVueUJ1dHRvbiA9IGZhbHNlKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlIHRoZSBzdGF0dXMgb2YgdGhlIGN1cnJlbnRseSBzZWxlY3RlZCBjb21wYXJpc29uLlxuICAgICAqIEBwYXJhbSBzdGF0dXMgdGhlIG5ldyBzdGF0dXMgb2YgdGhlIGNvbXBhcmlzb25cbiAgICAgKi9cbiAgICB1cGRhdGVQbGFnaWFyaXNtU3RhdHVzKHN0YXR1czogUGxhZ2lhcmlzbVN0YXR1cykge1xuICAgICAgICB0aGlzLmRpc2FibGVDb25maXJtRGVueUJ1dHRvbiA9IHRydWU7XG4gICAgICAgIC8vIHN0b3JlIGNvbXBhcmlzb24gaW4gdmFyaWFibGUgaW4gY2FzZSBjb21wYXJpc29uIGNoYW5nZXMgd2hpbGUgcmVxdWVzdCBpcyBtYWRlXG4gICAgICAgIGNvbnN0IGNvbXBhcmlzb24gPSB0aGlzLmNvbXBhcmlzb247XG4gICAgICAgIHRoaXMucGxhZ2lhcmlzbUNhc2VzU2VydmljZS51cGRhdGVQbGFnaWFyaXNtQ29tcGFyaXNvblN0YXR1cyhnZXRDb3Vyc2VJZCh0aGlzLmV4ZXJjaXNlKSEsIGNvbXBhcmlzb24uaWQsIHN0YXR1cykuc3Vic2NyaWJlKCgpID0+IHtcbiAgICAgICAgICAgIGNvbXBhcmlzb24uc3RhdHVzID0gc3RhdHVzO1xuICAgICAgICAgICAgdGhpcy5kaXNhYmxlQ29uZmlybURlbnlCdXR0b24gPSBmYWxzZTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgZXhwYW5kU3BsaXRQYW5lKHBhbmU6ICdsZWZ0JyB8ICdyaWdodCcpIHtcbiAgICAgICAgdGhpcy5zcGxpdENvbnRyb2xTdWJqZWN0Lm5leHQocGFuZSk7XG4gICAgfVxuXG4gICAgcmVzZXRTcGxpdFBhbmVzKCkge1xuICAgICAgICB0aGlzLnNwbGl0Q29udHJvbFN1YmplY3QubmV4dCgnZXZlbicpO1xuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLWhlYWRlclwiPlxuICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLWhlYWRlci1sZWZ0XCI+XG4gICAgICAgIDxoNSBjbGFzcz1cImZ3LW1lZGl1bVwiPlxuICAgICAgICAgICAge3sgY29tcGFyaXNvbi5zdWJtaXNzaW9uQS5zdHVkZW50TG9naW4gfHwgKCdhcnRlbWlzQXBwLnBsYWdpYXJpc20udW5rbm93blN0dWRlbnQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSkgfX0sXG4gICAgICAgICAgICB7eyBjb21wYXJpc29uLnN1Ym1pc3Npb25CLnN0dWRlbnRMb2dpbiB8fCAoJ2FydGVtaXNBcHAucGxhZ2lhcmlzbS51bmtub3duU3R1ZGVudCcgfCBhcnRlbWlzVHJhbnNsYXRlKSB9fVxuICAgICAgICA8L2g1PlxuICAgIDwvZGl2PlxuXG4gICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20taGVhZGVyLXJpZ2h0XCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIFtkaXNhYmxlZF09XCJjb21wYXJpc29uLnN0YXR1cyA9PT0gcGxhZ2lhcmlzbVN0YXR1cy5DT05GSVJNRUQgfHwgZGlzYWJsZUNvbmZpcm1EZW55QnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzPVwiYnRuIGJ0bi1zdWNjZXNzIGJ0bi1zbVwiXG4gICAgICAgICAgICAoY2xpY2spPVwiY29uZmlybVBsYWdpYXJpc20oKVwiXG4gICAgICAgICAgICBkYXRhLXFhPVwiY29uZmlybS1wbGFnaWFyaXNtLWJ1dHRvblwiXG4gICAgICAgID5cbiAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLnBsYWdpYXJpc20uY29uZmlybScgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIFtkaXNhYmxlZF09XCJjb21wYXJpc29uLnN0YXR1cyA9PT0gcGxhZ2lhcmlzbVN0YXR1cy5ERU5JRUQgfHwgZGlzYWJsZUNvbmZpcm1EZW55QnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzPVwiYnRuIGJ0bi1kYW5nZXIgYnRuLXNtXCJcbiAgICAgICAgICAgIChjbGljayk9XCJkZW55UGxhZ2lhcmlzbSgpXCJcbiAgICAgICAgICAgIGRhdGEtcWE9XCJkZW55LXBsYWdpYXJpc20tYnV0dG9uXCJcbiAgICAgICAgPlxuICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAucGxhZ2lhcmlzbS5kZW55JyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGRpdiBjbGFzcz1cInZlcnRpY2FsLWRpdmlkZXJcIj48L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzPVwic3BsaXQtY29udHJvbHNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzcGxpdC1jb250cm9sXCIgKGNsaWNrKT1cImV4cGFuZFNwbGl0UGFuZSgnbGVmdCcpXCIgZGF0YS1xYT1cInNwbGl0LXZpZXctbGVmdFwiPlxuICAgICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyOFwiIGhlaWdodD1cIjI4XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk00IDUuNUM0IDQuNjcxNTcgNC42NzE1NyA0IDUuNSA0SDE1VjIwSDUuNUM0LjY3MTU3IDIwIDQgMTkuMzI4NCA0IDE4LjVWNS41WlwiIGZpbGw9XCIjRTRFNUU2XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0xNyA0SDE4LjVDMTkuMzI4NCA0IDIwIDQuNjcxNTcgMjAgNS41VjE4LjVDMjAgMTkuMzI4NCAxOS4zMjg0IDIwIDE4LjUgMjBIMTdWNFpcIiBmaWxsPVwiI0U0RTVFNlwiIC8+XG4gICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzcGxpdC1jb250cm9sXCIgKGNsaWNrKT1cInJlc2V0U3BsaXRQYW5lcygpXCIgZGF0YS1xYT1cInNwbGl0LXZpZXctZXZlblwiPlxuICAgICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyOFwiIGhlaWdodD1cIjI4XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk00IDUuNUM0IDQuNjcxNTcgNC42NzE1NyA0IDUuNSA0SDExVjIwSDUuNUM0LjY3MTU3IDIwIDQgMTkuMzI4NCA0IDE4LjVWNS41WlwiIGZpbGw9XCIjRTRFNUU2XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0xMyA0SDE4LjVDMTkuMzI4NCA0IDIwIDQuNjcxNTcgMjAgNS41VjE4LjVDMjAgMTkuMzI4NCAxOS4zMjg0IDIwIDE4LjUgMjBIMTNWNFpcIiBmaWxsPVwiI0U0RTVFNlwiIC8+XG4gICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzcGxpdC1jb250cm9sXCIgKGNsaWNrKT1cImV4cGFuZFNwbGl0UGFuZSgncmlnaHQnKVwiIGRhdGEtcWE9XCJzcGxpdC12aWV3LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgPHN2ZyB3aWR0aD1cIjI4XCIgaGVpZ2h0PVwiMjhcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTIwIDE4LjVDMjAgMTkuMzI4NCAxOS4zMjg0IDIwIDE4LjUgMjBMOSAyMEw5IDRMMTguNSA0QzE5LjMyODQgNCAyMCA0LjY3MTU3IDIwIDUuNUwyMCAxOC41WlwiIGZpbGw9XCIjRTRFNUU2XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk03IDIwTDUuNSAyMEM0LjY3MTU3IDIwIDQgMTkuMzI4NCA0IDE4LjVMNCA1LjVDNCA0LjY3MTU3IDQuNjcxNTcgNCA1LjUgNEw3IDRMNyAyMFpcIiBmaWxsPVwiI0U0RTVFNlwiIC8+XG4gICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT25DaGFuZ2VzLCBPdXRwdXQsIFNpbXBsZUNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGZhQ2hldnJvbkRvd24gfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuXG4vKipcbiAqIEEgZmlsZSBuYW1lIHRoYXQgYWRkaXRpb25hbGx5IHN0b3JlcyBpZiBhIHBsYWdpYXJpc20gbWF0Y2ggaGFzIGJlZW4gZm91bmQgZm9yIGl0LlxuICovXG5leHBvcnQgdHlwZSBGaWxlV2l0aEhhc01hdGNoID0ge1xuICAgIGZpbGU6IHN0cmluZztcbiAgICBoYXNNYXRjaDogYm9vbGVhbjtcbn07XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXNwbGl0LXBhbmUtaGVhZGVyJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vc3BsaXQtcGFuZS1oZWFkZXIuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL3NwbGl0LXBhbmUtaGVhZGVyLmNvbXBvbmVudC5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIFNwbGl0UGFuZUhlYWRlckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gICAgQElucHV0KCkgZmlsZXM6IEZpbGVXaXRoSGFzTWF0Y2hbXTtcbiAgICBASW5wdXQoKSBzdHVkZW50TG9naW46IHN0cmluZztcbiAgICBAT3V0cHV0KCkgc2VsZWN0RmlsZSA9IG5ldyBFdmVudEVtaXR0ZXI8c3RyaW5nPigpO1xuXG4gICAgcHVibGljIHNob3dGaWxlcyA9IGZhbHNlO1xuICAgIHB1YmxpYyBhY3RpdmVGaWxlSW5kZXggPSAwO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUNoZXZyb25Eb3duID0gZmFDaGV2cm9uRG93bjtcblxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcbiAgICAgICAgaWYgKGNoYW5nZXMuZmlsZXMpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpbGVzOiBGaWxlV2l0aEhhc01hdGNoID0gY2hhbmdlcy5maWxlcy5jdXJyZW50VmFsdWU7XG5cbiAgICAgICAgICAgIHRoaXMuYWN0aXZlRmlsZUluZGV4ID0gMDtcblxuICAgICAgICAgICAgaWYgKHRoaXMuaGFzRmlsZXMoKSkge1xuICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0RmlsZS5lbWl0KGZpbGVzWzBdLmZpbGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgaGFzQWN0aXZlRmlsZSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaGFzRmlsZXMoKSAmJiB0aGlzLmFjdGl2ZUZpbGVJbmRleCA8IHRoaXMuZmlsZXMubGVuZ3RoO1xuICAgIH1cblxuICAgIGdldEFjdGl2ZUZpbGUoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZmlsZXNbdGhpcy5hY3RpdmVGaWxlSW5kZXhdLmZpbGU7XG4gICAgfVxuXG4gICAgaGFuZGxlRmlsZVNlbGVjdChmaWxlOiBGaWxlV2l0aEhhc01hdGNoLCBpZHg6IG51bWJlcik6IHZvaWQge1xuICAgICAgICB0aGlzLmFjdGl2ZUZpbGVJbmRleCA9IGlkeDtcbiAgICAgICAgdGhpcy5zaG93RmlsZXMgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5zZWxlY3RGaWxlLmVtaXQoZmlsZS5maWxlKTtcbiAgICB9XG5cbiAgICBoYXNGaWxlcygpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZmlsZXMgJiYgdGhpcy5maWxlcy5sZW5ndGggPiAwO1xuICAgIH1cblxuICAgIHRvZ2dsZVNob3dGaWxlcygpOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMuaGFzRmlsZXMoKSkge1xuICAgICAgICAgICAgdGhpcy5zaG93RmlsZXMgPSAhdGhpcy5zaG93RmlsZXM7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwic3BsaXQtcGFuZS1oZWFkZXJcIiBuZ2JEcm9wZG93bj5cbiAgICA8ZGl2IGNsYXNzPVwic3BsaXQtcGFuZS1oZWFkZXItdG9wXCIgZGF0YS10b2dnbGU9XCJkcm9wZG93blwiIFtuZ0NsYXNzXT1cInsgYWN0aXZlOiBzaG93RmlsZXMsIGNsaWNrYWJsZTogaGFzRmlsZXMoKSB9XCIgKGNsaWNrKT1cInRvZ2dsZVNob3dGaWxlcygpXCI+XG4gICAgICAgIEBpZiAoaGFzQWN0aXZlRmlsZSgpKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3BsaXQtcGFuZS1oZWFkZXItZmlsZS1uYW1lXCI+XG4gICAgICAgICAgICAgICAgPGZhLWljb24gY2xhc3M9XCJmaWxlLWFycm93LWRvd25cIiBbaWNvbl09XCJmYUNoZXZyb25Eb3duXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwic3BsaXQtcGFuZS1oZWFkZXItc2VsZWN0ZWQtZmlsZVwiPnt7IGdldEFjdGl2ZUZpbGUoKSB9fTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICAgIDxkaXY+e3sgc3R1ZGVudExvZ2luIHx8ICgnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLnVua25vd25TdHVkZW50JyB8IGFydGVtaXNUcmFuc2xhdGUpIH19PC9kaXY+XG4gICAgPC9kaXY+XG4gICAgQGlmIChzaG93RmlsZXMpIHtcbiAgICAgICAgPHVsIGNsYXNzPVwic3BsaXQtcGFuZS1oZWFkZXItZmlsZXNcIj5cbiAgICAgICAgICAgIEBmb3IgKGZpbGUgb2YgZmlsZXM7IHRyYWNrIGZpbGU7IGxldCBpZHggPSAkaW5kZXgpIHtcbiAgICAgICAgICAgICAgICA8bGkgY2xhc3M9XCJzcGxpdC1wYW5lLWhlYWRlci1maWxlXCIgbmdiRHJvcGRvd25JdGVtIChjbGljayk9XCJoYW5kbGVGaWxlU2VsZWN0KGZpbGUsIGlkeClcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gW2NsYXNzLnNwbGl0LXBhbmUtaGVhZGVyLWZpbGUtd2l0aC1tYXRjaF09XCJmaWxlLmhhc01hdGNoXCI+e3sgZmlsZS5maWxlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKCFoYXNGaWxlcygpKSB7XG4gICAgICAgICAgICAgICAgPGxpPnt7ICdhcnRlbWlzQXBwLnBsYWdpYXJpc20ubm9GaWxlc0ZvdW5kJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2xpPlxuICAgICAgICAgICAgfVxuICAgICAgICA8L3VsPlxuICAgIH1cbjwvZGl2PlxuIiwiaW1wb3J0IHsgUGxhZ2lhcmlzbVN1Ym1pc3Npb25FbGVtZW50IH0gZnJvbSAnLi9QbGFnaWFyaXNtU3VibWlzc2lvbkVsZW1lbnQnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbUNvbXBhcmlzb24gfSBmcm9tICcuL1BsYWdpYXJpc21Db21wYXJpc29uJztcblxuLyoqXG4gKiBFYWNoIGBQbGFnaWFyaXNtU3VibWlzc2lvbmAgcmVmZXJzIHRvIGEgc3VibWlzc2lvbiB0aGF0IGhhcyBiZWVuIGNvbXBhcmVkIGR1cmluZyBwbGFnaWFyaXNtIGRldGVjdGlvbi5cbiAqIEl0IGNvbnRhaW5zIGZ1bmRhbWVudGFsIGluZm9ybWF0aW9uIGluZGVwZW5kZW50IG9mIHRoZSBleGVyY2lzZSB0eXBlIG9yIGFsZ29yaXRobSB1c2VkLlxuICovXG5leHBvcnQgY2xhc3MgUGxhZ2lhcmlzbVN1Ym1pc3Npb248RSBleHRlbmRzIFBsYWdpYXJpc21TdWJtaXNzaW9uRWxlbWVudD4ge1xuICAgIC8qKlxuICAgICAqIElEIG9mIHRoZSBzdWJtaXNzaW9uLlxuICAgICAqL1xuICAgIGlkOiBudW1iZXI7XG5cbiAgICAvKipcbiAgICAgKiBMb2dpbiBvZiB0aGUgc3R1ZGVudCB3aG8gY3JlYXRlZCB0aGUgc3VibWlzc2lvbi5cbiAgICAgKi9cbiAgICBzdHVkZW50TG9naW46IHN0cmluZztcblxuICAgIC8qKlxuICAgICAqIExpc3Qgb2YgZWxlbWVudHMgdGhlIHJlbGF0ZWQgc3VibWlzc2lvbiBjb25zaXN0cyBvZi5cbiAgICAgKi9cbiAgICBlbGVtZW50cz86IEVbXTtcblxuICAgIC8qKlxuICAgICAqIElEIG9mIHRoZSByZWxhdGVkIHN1Ym1pc3Npb24uXG4gICAgICovXG4gICAgc3VibWlzc2lvbklkOiBudW1iZXI7XG5cbiAgICAvKipcbiAgICAgKiBTaXplIG9mIHRoZSByZWxhdGVkIHN1Ym1pc3Npb24uXG4gICAgICpcbiAgICAgKiBGb3IgbW9kZWxpbmcgc3VibWlzc2lvbnMsIHRoaXMgaXMgdGhlIG51bWJlciBvZiBtb2RlbGluZyBlbGVtZW50cy5cbiAgICAgKiBGb3IgdGV4dCBhbmQgcHJvZ3JhbW1pbmcgc3VibWlzc2lvbnMsIHRoaXMgaXMgdGhlIG51bWJlciBvZiB3b3JkcyBvciB0b2tlbnMuXG4gICAgICovXG4gICAgc2l6ZTogbnVtYmVyO1xuXG4gICAgLyoqXG4gICAgICogUmVzdWx0IHNjb3JlIG9mIHRoZSByZWxhdGVkIHN1Ym1pc3Npb24uXG4gICAgICovXG4gICAgc2NvcmU6IG51bWJlcjtcblxuICAgIC8qKlxuICAgICAqIENvbXBhcmlzb24gb2YgdGhlIHN1Ym1pc3Npb24uXG4gICAgICovXG4gICAgcGxhZ2lhcmlzbUNvbXBhcmlzb246IFBsYWdpYXJpc21Db21wYXJpc29uPEU+O1xufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25DaGFuZ2VzLCBTaW1wbGVDaGFuZ2VzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNb2RlbGluZ1N1Ym1pc3Npb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9tb2RlbGluZy9wYXJ0aWNpcGF0ZS9tb2RlbGluZy1zdWJtaXNzaW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbVN1Ym1pc3Npb24gfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21TdWJtaXNzaW9uJztcbmltcG9ydCB7IE1vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL21vZGVsaW5nL01vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQnO1xuaW1wb3J0IHsgTW9kZWxpbmdFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9tb2RlbGluZy1leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBNb2RlbGluZ1N1Ym1pc3Npb24gfSBmcm9tICdhcHAvZW50aXRpZXMvbW9kZWxpbmctc3VibWlzc2lvbi5tb2RlbCc7XG5pbXBvcnQgeyBVTUxNb2RlbCB9IGZyb20gJ0BsczFpbnR1bS9hcG9sbG9uJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbW9kZWxpbmctc3VibWlzc2lvbi12aWV3ZXInLFxuICAgIHN0eWxlVXJsczogWycuL21vZGVsaW5nLXN1Ym1pc3Npb24tdmlld2VyLmNvbXBvbmVudC5zY3NzJ10sXG4gICAgdGVtcGxhdGVVcmw6ICcuL21vZGVsaW5nLXN1Ym1pc3Npb24tdmlld2VyLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgTW9kZWxpbmdTdWJtaXNzaW9uVmlld2VyQ29tcG9uZW50IGltcGxlbWVudHMgT25DaGFuZ2VzIHtcbiAgICBASW5wdXQoKSBleGVyY2lzZTogTW9kZWxpbmdFeGVyY2lzZTtcbiAgICBASW5wdXQoKSBwbGFnaWFyaXNtU3VibWlzc2lvbjogUGxhZ2lhcmlzbVN1Ym1pc3Npb248TW9kZWxpbmdTdWJtaXNzaW9uRWxlbWVudD47XG5cbiAgICBwdWJsaWMgbG9hZGluZzogYm9vbGVhbjtcbiAgICBwdWJsaWMgc3VibWlzc2lvbk1vZGVsOiBVTUxNb2RlbDtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgbW9kZWxpbmdTdWJtaXNzaW9uU2VydmljZTogTW9kZWxpbmdTdWJtaXNzaW9uU2VydmljZSkge31cblxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcbiAgICAgICAgaWYgKGNoYW5nZXMucGxhZ2lhcmlzbVN1Ym1pc3Npb24pIHtcbiAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IHRydWU7XG5cbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRQbGFnaWFyaXNtU3VibWlzc2lvbjogUGxhZ2lhcmlzbVN1Ym1pc3Npb248TW9kZWxpbmdTdWJtaXNzaW9uRWxlbWVudD4gPSBjaGFuZ2VzLnBsYWdpYXJpc21TdWJtaXNzaW9uLmN1cnJlbnRWYWx1ZTtcblxuICAgICAgICAgICAgdGhpcy5tb2RlbGluZ1N1Ym1pc3Npb25TZXJ2aWNlLmdldFN1Ym1pc3Npb25XaXRob3V0TG9jayhjdXJyZW50UGxhZ2lhcmlzbVN1Ym1pc3Npb24uc3VibWlzc2lvbklkKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgICAgIG5leHQ6IChzdWJtaXNzaW9uOiBNb2RlbGluZ1N1Ym1pc3Npb24pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3VibWlzc2lvbk1vZGVsID0gSlNPTi5wYXJzZShzdWJtaXNzaW9uLm1vZGVsISkgYXMgVU1MTW9kZWw7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCI8amhpLXNwbGl0LXBhbmUtaGVhZGVyIHN0dWRlbnRMb2dpbj1cInt7IHBsYWdpYXJpc21TdWJtaXNzaW9uPy5zdHVkZW50TG9naW4gfX1cIj48L2poaS1zcGxpdC1wYW5lLWhlYWRlcj5cbkBpZiAoIWxvYWRpbmcpIHtcbiAgICA8amhpLW1vZGVsaW5nLWVkaXRvciBbdW1sTW9kZWxdPVwic3VibWlzc2lvbk1vZGVsXCIgW2RpYWdyYW1UeXBlXT1cImV4ZXJjaXNlLmRpYWdyYW1UeXBlXCIgW3JlYWRPbmx5XT1cInRydWVcIj48L2poaS1tb2RlbGluZy1lZGl0b3I+XG59XG5AaWYgKGxvYWRpbmcpIHtcbiAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1zdWJtaXNzaW9uLWxvYWRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3Bpbm5lci1ib3JkZXIgdGV4dC1wcmltYXJ5XCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJzci1vbmx5XCI+TG9hZGluZy4uLjwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkNoYW5nZXMsIFNpbXBsZUNoYW5nZXMsIFZpZXdFbmNhcHN1bGF0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBUZXh0U3VibWlzc2lvblNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3RleHQvcGFydGljaXBhdGUvdGV4dC1zdWJtaXNzaW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbVN1Ym1pc3Npb24gfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21TdWJtaXNzaW9uJztcbmltcG9ydCB7IFRleHRTdWJtaXNzaW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3RleHQtc3VibWlzc2lvbi5tb2RlbCc7XG5pbXBvcnQgeyBGcm9tVG9FbGVtZW50LCBUZXh0U3VibWlzc2lvbkVsZW1lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL3RleHQvVGV4dFN1Ym1pc3Npb25FbGVtZW50JztcbmltcG9ydCB7IFRleHRFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy90ZXh0LWV4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvcHJvZ3JhbW1pbmctZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgRXhlcmNpc2VUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IERvbWFpbkNoYW5nZSwgRG9tYWluVHlwZSwgRmlsZVR5cGUgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9jb2RlLWVkaXRvci9tb2RlbC9jb2RlLWVkaXRvci5tb2RlbCc7XG5pbXBvcnQgeyBDb2RlRWRpdG9yUmVwb3NpdG9yeUZpbGVTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvY29kZS1lZGl0b3Ivc2VydmljZS9jb2RlLWVkaXRvci1yZXBvc2l0b3J5LnNlcnZpY2UnO1xuaW1wb3J0IHsgRmlsZVdpdGhIYXNNYXRjaCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vcGxhZ2lhcmlzbS1zcGxpdC12aWV3L3NwbGl0LXBhbmUtaGVhZGVyL3NwbGl0LXBhbmUtaGVhZGVyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBlc2NhcGUgfSBmcm9tICdsb2Rhc2gtZXMnO1xuXG50eXBlIEZpbGVzV2l0aFR5cGUgPSB7IFtwOiBzdHJpbmddOiBGaWxlVHlwZSB9O1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS10ZXh0LXN1Ym1pc3Npb24tdmlld2VyJyxcbiAgICBzdHlsZVVybHM6IFsnLi90ZXh0LXN1Ym1pc3Npb24tdmlld2VyLmNvbXBvbmVudC5zY3NzJ10sXG4gICAgdGVtcGxhdGVVcmw6ICcuL3RleHQtc3VibWlzc2lvbi12aWV3ZXIuY29tcG9uZW50Lmh0bWwnLFxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXG59KVxuZXhwb3J0IGNsYXNzIFRleHRTdWJtaXNzaW9uVmlld2VyQ29tcG9uZW50IGltcGxlbWVudHMgT25DaGFuZ2VzIHtcbiAgICBASW5wdXQoKSBleGVyY2lzZTogUHJvZ3JhbW1pbmdFeGVyY2lzZSB8IFRleHRFeGVyY2lzZTtcbiAgICBASW5wdXQoKSBtYXRjaGVzOiBNYXA8c3RyaW5nLCBGcm9tVG9FbGVtZW50W10+O1xuICAgIEBJbnB1dCgpIHBsYWdpYXJpc21TdWJtaXNzaW9uOiBQbGFnaWFyaXNtU3VibWlzc2lvbjxUZXh0U3VibWlzc2lvbkVsZW1lbnQ+O1xuXG4gICAgLyoqXG4gICAgICogTmFtZSBvZiB0aGUgY3VycmVudGx5IHNlbGVjdGVkIGZpbGUuXG4gICAgICovXG4gICAgcHVibGljIGN1cnJlbnRGaWxlOiBzdHJpbmc7XG5cbiAgICAvKipcbiAgICAgKiBDb250ZW50IG9mIHRoZSBjdXJyZW50bHkgc2VsZWN0ZWQgZmlsZS5cbiAgICAgKi9cbiAgICBwdWJsaWMgZmlsZUNvbnRlbnQ6IHN0cmluZztcblxuICAgIC8qKlxuICAgICAqIExpc3Qgb2YgZmlsZXMgdGhlIGdpdmVuIHN1Ym1pc3Npb24gY29uc2lzdHMgb2YuXG4gICAgICogYG51bGxgIGZvciB0ZXh0IGV4ZXJjaXNlcy5cbiAgICAgKi9cbiAgICBwdWJsaWMgZmlsZXM6IEZpbGVXaXRoSGFzTWF0Y2hbXTtcblxuICAgIC8qKlxuICAgICAqIFRydWUsIGlmIHRoZSBnaXZlbiBleGVyY2lzZSBpcyBvZiB0eXBlICdwcm9ncmFtbWluZycuXG4gICAgICovXG4gICAgcHVibGljIGlzUHJvZ3JhbW1pbmdFeGVyY2lzZTogYm9vbGVhbjtcblxuICAgIC8qKlxuICAgICAqIFRydWUsIGlmIHRoZSBmaWxlIGNvbnRlbnQgZm9yIHRoZSBnaXZlbiBzdWJtaXNzaW9uIGlzIGJlaW5nIGxvYWRlZC5cbiAgICAgKi9cbiAgICBwdWJsaWMgbG9hZGluZzogYm9vbGVhbjtcblxuICAgIC8qKlxuICAgICAqIFRva2VuIHRoYXQgbWFya3MgdGhlIGJlZ2lubmluZyBvZiBhIGhpZ2hsaWdodGVkIG1hdGNoLlxuICAgICAqL1xuICAgIHB1YmxpYyB0b2tlblN0YXJ0ID0gJzxzcGFuIGNsYXNzPVwicGxhZ2lhcmlzbS1tYXRjaFwiPic7XG5cbiAgICAvKipcbiAgICAgKiBUb2tlbiB0aGF0IG1hcmtzIHRoZSBlbmQgb2YgYSBoaWdobGlnaHRlZCBtYXRjaC5cbiAgICAgKi9cbiAgICBwdWJsaWMgdG9rZW5FbmQgPSAnPC9zcGFuPic7XG5cbiAgICAvKipcbiAgICAgKiBUcnVlIGlmIGN1cnJlbnRseSBzZWxlY3RlZCBmaWxlIGlzIG5vdCBhIHRleHQgZmlsZS5cbiAgICAgKi9cbiAgICBiaW5hcnlGaWxlPzogYm9vbGVhbjtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIHJlcG9zaXRvcnlTZXJ2aWNlOiBDb2RlRWRpdG9yUmVwb3NpdG9yeUZpbGVTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHRleHRTdWJtaXNzaW9uU2VydmljZTogVGV4dFN1Ym1pc3Npb25TZXJ2aWNlLFxuICAgICkge31cblxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcbiAgICAgICAgaWYgKGNoYW5nZXMucGxhZ2lhcmlzbVN1Ym1pc3Npb24pIHtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRQbGFnaWFyaXNtU3VibWlzc2lvbjogUGxhZ2lhcmlzbVN1Ym1pc3Npb248VGV4dFN1Ym1pc3Npb25FbGVtZW50PiA9IGNoYW5nZXMucGxhZ2lhcmlzbVN1Ym1pc3Npb24uY3VycmVudFZhbHVlO1xuICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gdHJ1ZTtcblxuICAgICAgICAgICAgaWYgKHRoaXMuZXhlcmNpc2UudHlwZSA9PT0gRXhlcmNpc2VUeXBlLlBST0dSQU1NSU5HKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2FkUHJvZ3JhbW1pbmdFeGVyY2lzZShjdXJyZW50UGxhZ2lhcmlzbVN1Ym1pc3Npb24pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLmxvYWRUZXh0RXhlcmNpc2UoY3VycmVudFBsYWdpYXJpc21TdWJtaXNzaW9uKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEluaXRpYWxpemVzIHRoaXMgY29tcG9uZW50IHdpdGggYSBwcm9ncmFtbWluZyBleGVyY2lzZSBzdWJtaXNzaW9uLlxuICAgICAqXG4gICAgICogQHBhcmFtIGN1cnJlbnRQbGFnaWFyaXNtU3VibWlzc2lvbiBUaGUgc3VibWlzc2lvbiB0byBsb2FkIHRoZSBwbGFnaWFyaXNtIGluZm9ybWF0aW9uIGZvci5cbiAgICAgKi9cbiAgICBwcml2YXRlIGxvYWRQcm9ncmFtbWluZ0V4ZXJjaXNlKGN1cnJlbnRQbGFnaWFyaXNtU3VibWlzc2lvbjogUGxhZ2lhcmlzbVN1Ym1pc3Npb248VGV4dFN1Ym1pc3Npb25FbGVtZW50Pikge1xuICAgICAgICB0aGlzLmlzUHJvZ3JhbW1pbmdFeGVyY2lzZSA9IHRydWU7XG5cbiAgICAgICAgY29uc3QgZG9tYWluOiBEb21haW5DaGFuZ2UgPSBbRG9tYWluVHlwZS5QQVJUSUNJUEFUSU9OLCB7IGlkOiBjdXJyZW50UGxhZ2lhcmlzbVN1Ym1pc3Npb24uc3VibWlzc2lvbklkIH1dO1xuICAgICAgICB0aGlzLnJlcG9zaXRvcnlTZXJ2aWNlLmdldFJlcG9zaXRvcnlDb250ZW50KGRvbWFpbikuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5leHQ6IChmaWxlcykgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHRoaXMuZmlsZXMgPSB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2VGaWxlc1dpdGhNYXRjaGVzKGZpbGVzKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ29tcHV0ZXMgdGhlIGxpc3Qgb2YgYWxsIGZpbGVzIHRoYXQgc2hvdWxkIGJlIHNob3duIGZvciB0aGUgcGxhZ2lhcmlzbSB2aWV3LlxuICAgICAqXG4gICAgICogQHBhcmFtIGZpbGVzIEFuIHVuZmlsdGVyZWQgbGlzdCBvZiBmaWxlcy5cbiAgICAgKiBAcmV0dXJuIEEgc29ydGVkIGxpc3Qgb2YgZmlsZXMgdGhhdCBzaG91bGQgYmUgc2hvd24gZm9yIHRoZSBwbGFnaWFyaXNtIHZpZXcuXG4gICAgICovXG4gICAgcHJpdmF0ZSBwcm9ncmFtbWluZ0V4ZXJjaXNlRmlsZXNXaXRoTWF0Y2hlcyhmaWxlczogRmlsZXNXaXRoVHlwZSk6IEFycmF5PEZpbGVXaXRoSGFzTWF0Y2g+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZmlsdGVyRmlsZXMoZmlsZXMpXG4gICAgICAgICAgICAubWFwKChmaWxlKSA9PiAoeyBmaWxlLCBoYXNNYXRjaDogdGhpcy5oYXNNYXRjaChmaWxlKSB9KSlcbiAgICAgICAgICAgIC5zb3J0KFRleHRTdWJtaXNzaW9uVmlld2VyQ29tcG9uZW50LmNvbXBhcmVGaWxlV2l0aEhhc01hdGNoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDb21wYXJlcyB0d28gZmlsZXMuXG4gICAgICpcbiAgICAgKiBGaWxlcyB3aGljaCBoYXZlIGdvdCBhIG1hdGNoIGhhdmUgZ290IHByZWNlZGVuY2Ugb3ZlciBvbmVzIHdoaWNoIGRvbuKAmXQuXG4gICAgICogSWYgdHdvIGZpbGVzIGVpdGhlciBib3RoIG9yIG5laXRoZXIgaGF2ZSBhIG1hdGNoLCB0aGVuIHRoZXkgYXJlIHNvcnRlZCBsZXhpY29ncmFwaGljYWxseS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBmaWxlMSBTb21lIGZpbGUgd2l0aCBpbmZvcm1hdGlvbiBpZiBpdCBoYXMgYSBtYXRjaC5cbiAgICAgKiBAcGFyYW0gZmlsZTIgU29tZSBvdGhlciBmaWxlIHdpdGggaW5mb3JtYXRpb24gaWYgaXQgaGFzIGEgbWF0Y2guXG4gICAgICogQHJldHVybiBgLTFgLCBpZiBgZmlsZTFgIGlzIHNtYWxsZXIgYWNjb3JkaW5nIHRvIHRoZSBzb3J0aW5nIG9yZGVyIGRlc2NyaWJlZCBhYm92ZSwgYDFgIG90aGVyd2lzZS5cbiAgICAgKi9cbiAgICBwcml2YXRlIHN0YXRpYyBjb21wYXJlRmlsZVdpdGhIYXNNYXRjaChmaWxlMTogRmlsZVdpdGhIYXNNYXRjaCwgZmlsZTI6IEZpbGVXaXRoSGFzTWF0Y2gpOiBudW1iZXIge1xuICAgICAgICBpZiAoZmlsZTEuaGFzTWF0Y2ggPT09IGZpbGUyLmhhc01hdGNoKSB7XG4gICAgICAgICAgICByZXR1cm4gZmlsZTEuZmlsZS5sb2NhbGVDb21wYXJlKGZpbGUyLmZpbGUpO1xuICAgICAgICB9IGVsc2UgaWYgKGZpbGUxLmhhc01hdGNoKSB7XG4gICAgICAgICAgICByZXR1cm4gLTE7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gMTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEluaXRpYWxpemVzIHRoaXMgY29tcG9uZW50IHdpdGggYSB0ZXh0IGV4ZXJjaXNlIHN1Ym1pc3Npb24uXG4gICAgICpcbiAgICAgKiBAcGFyYW0gY3VycmVudFBsYWdpYXJpc21TdWJtaXNzaW9uIFRoZSBzdWJtaXNzaW9uIHRvIGxvYWQgdGhlIHBsYWdpYXJpc20gaW5mb3JtYXRpb24gZm9yLlxuICAgICAqL1xuICAgIHByaXZhdGUgbG9hZFRleHRFeGVyY2lzZShjdXJyZW50UGxhZ2lhcmlzbVN1Ym1pc3Npb246IFBsYWdpYXJpc21TdWJtaXNzaW9uPFRleHRTdWJtaXNzaW9uRWxlbWVudD4pIHtcbiAgICAgICAgdGhpcy5pc1Byb2dyYW1taW5nRXhlcmNpc2UgPSBmYWxzZTtcblxuICAgICAgICB0aGlzLnRleHRTdWJtaXNzaW9uU2VydmljZS5nZXRUZXh0U3VibWlzc2lvbihjdXJyZW50UGxhZ2lhcmlzbVN1Ym1pc3Npb24uc3VibWlzc2lvbklkKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKHN1Ym1pc3Npb246IFRleHRTdWJtaXNzaW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhpcy5maWxlQ29udGVudCA9IHRoaXMuaW5zZXJ0TWF0Y2hUb2tlbnMoc3VibWlzc2lvbi50ZXh0IHx8ICcnKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgZmlsdGVyRmlsZXMoZmlsZXM6IEZpbGVzV2l0aFR5cGUpIHtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKGZpbGVzKS5maWx0ZXIoKGZpbGVOYW1lKSA9PiBmaWxlc1tmaWxlTmFtZV0gPT09IEZpbGVUeXBlLkZJTEUpO1xuICAgIH1cblxuICAgIGhhbmRsZUZpbGVTZWxlY3QoZmlsZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuY3VycmVudEZpbGUgPSBmaWxlO1xuICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuXG4gICAgICAgIGNvbnN0IGRvbWFpbjogRG9tYWluQ2hhbmdlID0gW0RvbWFpblR5cGUuUEFSVElDSVBBVElPTiwgeyBpZDogdGhpcy5wbGFnaWFyaXNtU3VibWlzc2lvbi5zdWJtaXNzaW9uSWQgfV07XG5cbiAgICAgICAgdGhpcy5yZXBvc2l0b3J5U2VydmljZS5nZXRGaWxlSGVhZGVycyhmaWxlLCBkb21haW4pLnN1YnNjcmliZSgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ2NvbnRlbnQtdHlwZScpO1xuICAgICAgICAgICAgaWYgKGNvbnRlbnRUeXBlICYmICFjb250ZW50VHlwZS5zdGFydHNXaXRoKCd0ZXh0JykpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmJpbmFyeUZpbGUgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLmJpbmFyeUZpbGUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLnJlcG9zaXRvcnlTZXJ2aWNlLmdldEZpbGUoZmlsZSwgZG9tYWluKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgICAgICAgICBuZXh0OiAoeyBmaWxlQ29udGVudCB9KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZmlsZUNvbnRlbnQgPSB0aGlzLmluc2VydE1hdGNoVG9rZW5zKGZpbGVDb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEb3dubG9hZHMgdGhlIGN1cnJlbnRseSBzZWxlY3RlZCBmaWxlIHdpdGggYSBmcmllbmRseSBuYW1lIGNvbnNpc3Rpbmcgb2YgdGhlIGV4ZXJjaXNlcyBzaG9ydCBuYW1lLCB0aGUgc3R1ZGVudCBsb2dpbiBhbmQgdGhlIGZpbGVuYW1lLlxuICAgICAqL1xuICAgIGRvd25sb2FkQ3VycmVudEZpbGUoKSB7XG4gICAgICAgIHRoaXMucmVwb3NpdG9yeVNlcnZpY2UuZG93bmxvYWRGaWxlKHRoaXMuY3VycmVudEZpbGUsIHRoaXMuZXhlcmNpc2Uuc2hvcnROYW1lICsgJ18nICsgdGhpcy5wbGFnaWFyaXNtU3VibWlzc2lvbi5zdHVkZW50TG9naW4gKyAnXycgKyB0aGlzLmN1cnJlbnRGaWxlKTtcbiAgICB9XG5cbiAgICBnZXRNYXRjaGVzRm9yQ3VycmVudEZpbGUoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLm1hdGNoZXMuZ2V0KHRoaXMuY3VycmVudEZpbGUgfHwgJ25vbmUnKSB8fCBbXTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGhhc01hdGNoKGZpbGU6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5tYXRjaGVzLmhhcyhmaWxlKTtcbiAgICB9XG5cbiAgICBpbnNlcnRNYXRjaFRva2VucyhmaWxlQ29udGVudDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICAgICAgY29uc3QgbWF0Y2hlcyA9IHRoaXMuZ2V0TWF0Y2hlc0ZvckN1cnJlbnRGaWxlKClcbiAgICAgICAgICAgIC5maWx0ZXIoKG1hdGNoKSA9PiBtYXRjaC5mcm9tICYmIG1hdGNoLnRvKVxuICAgICAgICAgICAgLnNvcnQoKG0xLCBtMikgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVzID0gbTEuZnJvbS5saW5lIC0gbTIuZnJvbS5saW5lO1xuICAgICAgICAgICAgICAgIGlmIChsaW5lcyA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbTEuZnJvbS5jb2x1bW4gLSBtMi5mcm9tLmNvbHVtbjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGxpbmVzO1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFtYXRjaGVzLmxlbmd0aCkge1xuICAgICAgICAgICAgcmV0dXJuIGVzY2FwZShmaWxlQ29udGVudCk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCByb3dzID0gZmlsZUNvbnRlbnQuc3BsaXQoJ1xcbicpO1xuICAgICAgICBsZXQgcmVzdWx0ID0gJyc7XG5cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXRjaGVzWzBdLmZyb20ubGluZSAtIDE7IGkrKykge1xuICAgICAgICAgICAgcmVzdWx0ICs9IGVzY2FwZShyb3dzW2ldKSArICdcXG4nO1xuICAgICAgICB9XG4gICAgICAgIHJlc3VsdCArPSBlc2NhcGUocm93c1ttYXRjaGVzWzBdLmZyb20ubGluZSAtIDFdLnNsaWNlKDAsIG1hdGNoZXNbMF0uZnJvbS5jb2x1bW4gLSAxKSk7XG5cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXRjaGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBtYXRjaCA9IG1hdGNoZXNbaV07XG5cbiAgICAgICAgICAgIGNvbnN0IGlkeExpbmVGcm9tID0gbWF0Y2guZnJvbS5saW5lIC0gMTtcbiAgICAgICAgICAgIGNvbnN0IGlkeExpbmVUbyA9IG1hdGNoLnRvLmxpbmUgLSAxO1xuXG4gICAgICAgICAgICBjb25zdCBpZHhDb2x1bW5Gcm9tID0gbWF0Y2guZnJvbS5jb2x1bW4gLSAxO1xuICAgICAgICAgICAgY29uc3QgaWR4Q29sdW1uVG8gPSBtYXRjaC50by5jb2x1bW4gKyBtYXRjaC50by5sZW5ndGggLSAxO1xuXG4gICAgICAgICAgICByZXN1bHQgKz0gdGhpcy50b2tlblN0YXJ0O1xuXG4gICAgICAgICAgICBpZiAoaWR4TGluZUZyb20gPT09IGlkeExpbmVUbykge1xuICAgICAgICAgICAgICAgIHJlc3VsdCArPSBlc2NhcGUocm93c1tpZHhMaW5lRnJvbV0uc2xpY2UoaWR4Q29sdW1uRnJvbSwgaWR4Q29sdW1uVG8pKSArIHRoaXMudG9rZW5FbmQ7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJlc3VsdCArPSBlc2NhcGUocm93c1tpZHhMaW5lRnJvbV0uc2xpY2UoaWR4Q29sdW1uRnJvbSkpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGogPSBpZHhMaW5lRnJvbSArIDE7IGogPCBpZHhMaW5lVG87IGorKykge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQgKz0gJ1xcbicgKyBlc2NhcGUocm93c1tqXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJlc3VsdCArPSAnXFxuJyArIGVzY2FwZShyb3dzW2lkeExpbmVUb10uc2xpY2UoMCwgaWR4Q29sdW1uVG8pKSArIHRoaXMudG9rZW5FbmQ7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIGVzY2FwZSBldmVyeXRoaW5nIHVwIHVudGlsIHRoZSBuZXh0IG1hdGNoIChvciB0aGUgZW5kIG9mIHRoZSBzdHJpbmcgaWYgdGhlcmUgaXMgbm8gbW9yZSBtYXRjaClcbiAgICAgICAgICAgIGlmIChpID09PSBtYXRjaGVzLmxlbmd0aCAtIDEpIHtcbiAgICAgICAgICAgICAgICByZXN1bHQgKz0gZXNjYXBlKHJvd3NbaWR4TGluZVRvXS5zbGljZShpZHhDb2x1bW5UbykpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGogPSBpZHhMaW5lVG8gKyAxOyBqIDwgcm93cy5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQgKz0gJ1xcbicgKyBlc2NhcGUocm93c1tqXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmIChtYXRjaGVzW2kgKyAxXS5mcm9tLmxpbmUgPT09IG1hdGNoLnRvLmxpbmUpIHtcbiAgICAgICAgICAgICAgICByZXN1bHQgKz0gZXNjYXBlKHJvd3NbaWR4TGluZVRvXS5zbGljZShpZHhDb2x1bW5UbywgbWF0Y2hlc1tpICsgMV0uZnJvbS5jb2x1bW4gLSAxKSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJlc3VsdCArPSBlc2NhcGUocm93c1tpZHhMaW5lVG9dLnNsaWNlKGlkeENvbHVtblRvKSkgKyAnXFxuJztcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBqID0gaWR4TGluZVRvICsgMTsgaiA8IG1hdGNoZXNbaSArIDFdLmZyb20ubGluZSAtIDE7IGorKykge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQgKz0gZXNjYXBlKHJvd3Nbal0pICsgJ1xcbic7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJlc3VsdCArPSBlc2NhcGUocm93c1ttYXRjaGVzW2kgKyAxXS5mcm9tLmxpbmUgLSAxXS5zbGljZSgwLCBtYXRjaGVzW2kgKyAxXS5mcm9tLmNvbHVtbiAtIDEpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxufVxuIiwiPGpoaS1zcGxpdC1wYW5lLWhlYWRlciBbZmlsZXNdPVwiZmlsZXNcIiAoc2VsZWN0RmlsZSk9XCJoYW5kbGVGaWxlU2VsZWN0KCRldmVudClcIiBzdHVkZW50TG9naW49XCJ7eyBwbGFnaWFyaXNtU3VibWlzc2lvbj8uc3R1ZGVudExvZ2luIH19XCI+PC9qaGktc3BsaXQtcGFuZS1oZWFkZXI+XG5AaWYgKCFsb2FkaW5nICYmICFiaW5hcnlGaWxlISEpIHtcbiAgICA8ZGl2IGNsYXNzPVwidGV4dC1zdWJtaXNzaW9uLXZpZXdlclwiIFtpbm5lckhUTUxdPVwiZmlsZUNvbnRlbnQgfHwgJyAnXCIgW25nQ2xhc3NdPVwieyAnbm8tZmlsZSc6ICFmaWxlQ29udGVudCwgJ2lzLWNvZGUnOiBpc1Byb2dyYW1taW5nRXhlcmNpc2UgfVwiPlxuICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLm5vRmlsZVNlbGVjdGVkJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICA8L2Rpdj5cbn1cbkBpZiAobG9hZGluZykge1xuICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXN1Ym1pc3Npb24tbG9hZGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyLWJvcmRlciB0ZXh0LXByaW1hcnlcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInNyLW9ubHlcIj5Mb2FkaW5nLi4uPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbn1cbkBpZiAoYmluYXJ5RmlsZSkge1xuICAgIDxkaXYgY2xhc3M9XCJiaW5hcnlGaWxlRGlhbG9ndWVcIj5cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJtZS0xXCI+e3sgJ2FydGVtaXNBcHAucGxhZ2lhcmlzbS5iaW5hcnlGaWxlTm90UmVuZGVyZWQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgPGEgY2xhc3M9XCJ0ZXh0LXByaW1hcnlcIiAoY2xpY2spPVwiZG93bmxvYWRDdXJyZW50RmlsZSgpXCI+e3sgJ2VudGl0eS5hY3Rpb24uZG93bmxvYWQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvYT5cbiAgICA8L2Rpdj5cbn1cbiIsImV4cG9ydCBjbGFzcyBQbGFnaWFyaXNtU3VibWlzc2lvbkVsZW1lbnQge1xuICAgIHByaXZhdGUgUGxhZ2lhcmlzbVN1Ym1pc3Npb25FbGVtZW50KCkge31cbn1cbiIsImltcG9ydCB7IFBsYWdpYXJpc21TdWJtaXNzaW9uRWxlbWVudCB9IGZyb20gJy4uL1BsYWdpYXJpc21TdWJtaXNzaW9uRWxlbWVudCc7XG5cbmV4cG9ydCBjbGFzcyBGcm9tVG9FbGVtZW50IHtcbiAgICBmcm9tOiBUZXh0U3VibWlzc2lvbkVsZW1lbnQ7XG4gICAgdG86IFRleHRTdWJtaXNzaW9uRWxlbWVudDtcbiAgICBjb25zdHJ1Y3Rvcihmcm9tOiBUZXh0U3VibWlzc2lvbkVsZW1lbnQsIHRvOiBUZXh0U3VibWlzc2lvbkVsZW1lbnQpIHtcbiAgICAgICAgdGhpcy5mcm9tID0gZnJvbTtcbiAgICAgICAgdGhpcy50byA9IHRvO1xuICAgIH1cbn1cblxuZXhwb3J0IGNsYXNzIFRleHRTdWJtaXNzaW9uRWxlbWVudCBleHRlbmRzIFBsYWdpYXJpc21TdWJtaXNzaW9uRWxlbWVudCB7XG4gICAgY29sdW1uOiBudW1iZXI7XG4gICAgbGluZTogbnVtYmVyO1xuICAgIGZpbGU6IHN0cmluZztcbiAgICBsZW5ndGg6IG51bWJlcjtcbn1cbiIsImV4cG9ydCBjbGFzcyBTaW1wbGVNYXRjaCB7XG4gICAgc3RhcnQ6IG51bWJlcjtcbiAgICBsZW5ndGg6IG51bWJlcjtcblxuICAgIGNvbnN0cnVjdG9yKHN0YXJ0OiBudW1iZXIsIGxlbmd0aDogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuc3RhcnQgPSBzdGFydDtcbiAgICAgICAgdGhpcy5sZW5ndGggPSBsZW5ndGg7XG4gICAgfVxufVxuXG4vKipcbiAqIEEgYFBsYWdpYXJpc21NYXRjaGAgaXMgYSBzZXF1ZW5jZSBvZiBpZGVudGljYWwgZWxlbWVudHMgb2YgYm90aCBzdWJtaXNzaW9ucy5cbiAqL1xuZXhwb3J0IGNsYXNzIFBsYWdpYXJpc21NYXRjaCB7XG4gICAgLyoqXG4gICAgICogSW5kZXggb2YgdGhlIGZpcnN0IGVsZW1lbnQgb2Ygc3VibWlzc2lvbiBBIHRoYXQgaXMgcGFydCBvZiB0aGlzIG1hdGNoLlxuICAgICAqL1xuICAgIHN0YXJ0QTogbnVtYmVyO1xuXG4gICAgLyoqXG4gICAgICogSW5kZXggb2YgdGhlIGZpcnN0IGVsZW1lbnQgb2Ygc3VibWlzc2lvbiBCIHRoYXQgaXMgcGFydCBvZiB0aGlzIG1hdGNoLlxuICAgICAqL1xuICAgIHN0YXJ0QjogbnVtYmVyO1xuXG4gICAgLyoqXG4gICAgICogTGVuZ3RoIG9mIHRoZSBzZXF1ZW5jZSBvZiBpZGVudGljYWwgZWxlbWVudHMsIGJlZ2lubmluZyBhdCBzdGFydEEgYW5kIHN0YXJ0QiwgcmVzcGVjdGl2ZWx5LlxuICAgICAqL1xuICAgIGxlbmd0aDogbnVtYmVyO1xufVxuIiwiaW1wb3J0IHsgQWZ0ZXJWaWV3SW5pdCwgQ29tcG9uZW50LCBEaXJlY3RpdmUsIEVsZW1lbnRSZWYsIElucHV0LCBPbkNoYW5nZXMsIE9uSW5pdCwgUXVlcnlMaXN0LCBTaW1wbGVDaGFuZ2VzLCBWaWV3Q2hpbGRyZW4gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCAqIGFzIFNwbGl0IGZyb20gJ3NwbGl0LmpzJztcbmltcG9ydCB7IFN1YmplY3QgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IFBsYWdpYXJpc21Db21wYXJpc29uIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtQ29tcGFyaXNvbic7XG5pbXBvcnQgeyBGcm9tVG9FbGVtZW50LCBUZXh0U3VibWlzc2lvbkVsZW1lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL3RleHQvVGV4dFN1Ym1pc3Npb25FbGVtZW50JztcbmltcG9ydCB7IE1vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL21vZGVsaW5nL01vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQnO1xuaW1wb3J0IHsgRXhlcmNpc2UsIEV4ZXJjaXNlVHlwZSwgZ2V0Q291cnNlSWQgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbVN1Ym1pc3Npb24gfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21TdWJtaXNzaW9uJztcbmltcG9ydCB7IFBsYWdpYXJpc21DYXNlc1NlcnZpY2UgfSBmcm9tICdhcHAvY291cnNlL3BsYWdpYXJpc20tY2FzZXMvc2hhcmVkL3BsYWdpYXJpc20tY2FzZXMuc2VydmljZSc7XG5pbXBvcnQgeyBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBTaW1wbGVNYXRjaCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbU1hdGNoJztcblxuQERpcmVjdGl2ZSh7IHNlbGVjdG9yOiAnW2poaVBhbmVdJyB9KVxuZXhwb3J0IGNsYXNzIFNwbGl0UGFuZURpcmVjdGl2ZSB7XG4gICAgY29uc3RydWN0b3IocHVibGljIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYpIHt9XG59XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXBsYWdpYXJpc20tc3BsaXQtdmlldycsXG4gICAgc3R5bGVVcmxzOiBbJy4vcGxhZ2lhcmlzbS1zcGxpdC12aWV3LmNvbXBvbmVudC5zY3NzJ10sXG4gICAgdGVtcGxhdGVVcmw6ICcuL3BsYWdpYXJpc20tc3BsaXQtdmlldy5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIFBsYWdpYXJpc21TcGxpdFZpZXdDb21wb25lbnQgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0LCBPbkNoYW5nZXMsIE9uSW5pdCB7XG4gICAgQElucHV0KCkgY29tcGFyaXNvbjogUGxhZ2lhcmlzbUNvbXBhcmlzb248VGV4dFN1Ym1pc3Npb25FbGVtZW50IHwgTW9kZWxpbmdTdWJtaXNzaW9uRWxlbWVudD47XG4gICAgQElucHV0KCkgZXhlcmNpc2U6IEV4ZXJjaXNlO1xuICAgIEBJbnB1dCgpIHNwbGl0Q29udHJvbFN1YmplY3Q6IFN1YmplY3Q8c3RyaW5nPjtcbiAgICBASW5wdXQoKSBzb3J0QnlTdHVkZW50TG9naW46IHN0cmluZztcblxuICAgIEBWaWV3Q2hpbGRyZW4oU3BsaXRQYW5lRGlyZWN0aXZlKSBwYW5lcyE6IFF1ZXJ5TGlzdDxTcGxpdFBhbmVEaXJlY3RpdmU+O1xuXG4gICAgcGxhZ2lhcmlzbUNvbXBhcmlzb246IFBsYWdpYXJpc21Db21wYXJpc29uPFRleHRTdWJtaXNzaW9uRWxlbWVudCB8IE1vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQ+O1xuXG4gICAgcHVibGljIHNwbGl0OiBTcGxpdC5JbnN0YW5jZTtcblxuICAgIHB1YmxpYyBpc01vZGVsaW5nRXhlcmNpc2U6IGJvb2xlYW47XG4gICAgcHVibGljIGlzUHJvZ3JhbW1pbmdPclRleHRFeGVyY2lzZTogYm9vbGVhbjtcblxuICAgIHB1YmxpYyBtYXRjaGVzQTogTWFwPHN0cmluZywgRnJvbVRvRWxlbWVudFtdPjtcbiAgICBwdWJsaWMgbWF0Y2hlc0I6IE1hcDxzdHJpbmcsIEZyb21Ub0VsZW1lbnRbXT47XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIHBsYWdpYXJpc21DYXNlc1NlcnZpY2U6IFBsYWdpYXJpc21DYXNlc1NlcnZpY2UpIHt9XG5cbiAgICAvKipcbiAgICAgKiBJbml0aWFsaXplIHRoaXJkIHBhcnR5IGxpYnMgaW5zaWRlIHRoaXMgbGlmZWN5Y2xlIGhvb2suXG4gICAgICovXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xuICAgICAgICBjb25zdCBwYW5lRWxlbWVudHMgPSB0aGlzLnBhbmVzLm1hcCgocGFuZTogU3BsaXRQYW5lRGlyZWN0aXZlKSA9PiBwYW5lLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCk7XG5cbiAgICAgICAgdGhpcy5zcGxpdCA9IFNwbGl0LmRlZmF1bHQocGFuZUVsZW1lbnRzLCB7XG4gICAgICAgICAgICBtaW5TaXplOiAxMDAsXG4gICAgICAgICAgICBzaXplczogWzUwLCA1MF0sXG4gICAgICAgICAgICBndXR0ZXJTaXplOiA4LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5zcGxpdENvbnRyb2xTdWJqZWN0LnN1YnNjcmliZSgocGFuZTogc3RyaW5nKSA9PiB0aGlzLmhhbmRsZVNwbGl0Q29udHJvbChwYW5lKSk7XG4gICAgfVxuXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBpZiAoY2hhbmdlcy5leGVyY2lzZSkge1xuICAgICAgICAgICAgY29uc3QgZXhlcmNpc2UgPSBjaGFuZ2VzLmV4ZXJjaXNlLmN1cnJlbnRWYWx1ZTtcblxuICAgICAgICAgICAgdGhpcy5pc01vZGVsaW5nRXhlcmNpc2UgPSBleGVyY2lzZS50eXBlID09PSBFeGVyY2lzZVR5cGUuTU9ERUxJTkc7XG4gICAgICAgICAgICB0aGlzLmlzUHJvZ3JhbW1pbmdPclRleHRFeGVyY2lzZSA9IGV4ZXJjaXNlLnR5cGUgPT09IEV4ZXJjaXNlVHlwZS5QUk9HUkFNTUlORyB8fCBleGVyY2lzZS50eXBlID09PSBFeGVyY2lzZVR5cGUuVEVYVDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjaGFuZ2VzLmNvbXBhcmlzb24pIHtcbiAgICAgICAgICAgIHRoaXMucGxhZ2lhcmlzbUNhc2VzU2VydmljZVxuICAgICAgICAgICAgICAgIC5nZXRQbGFnaWFyaXNtQ29tcGFyaXNvbkZvclNwbGl0VmlldyhnZXRDb3Vyc2VJZCh0aGlzLmV4ZXJjaXNlKSEsIGNoYW5nZXMuY29tcGFyaXNvbi5jdXJyZW50VmFsdWUuaWQpXG4gICAgICAgICAgICAgICAgLnN1YnNjcmliZSgocmVzcDogSHR0cFJlc3BvbnNlPFBsYWdpYXJpc21Db21wYXJpc29uPFRleHRTdWJtaXNzaW9uRWxlbWVudCB8IE1vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQ+PikgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnBsYWdpYXJpc21Db21wYXJpc29uID0gcmVzcC5ib2R5ITtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuc29ydEJ5U3R1ZGVudExvZ2luICYmIHRoaXMuc29ydEJ5U3R1ZGVudExvZ2luID09PSB0aGlzLnBsYWdpYXJpc21Db21wYXJpc29uLnN1Ym1pc3Npb25CLnN0dWRlbnRMb2dpbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zd2FwU3VibWlzc2lvbnModGhpcy5wbGFnaWFyaXNtQ29tcGFyaXNvbik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuaXNQcm9ncmFtbWluZ09yVGV4dEV4ZXJjaXNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnBhcnNlVGV4dE1hdGNoZXModGhpcy5wbGFnaWFyaXNtQ29tcGFyaXNvbiBhcyBQbGFnaWFyaXNtQ29tcGFyaXNvbjxUZXh0U3VibWlzc2lvbkVsZW1lbnQ+KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU3dhcHMgZmllbGRzIG9mIEEgd2l0aCBmaWVsZHMgb2YgQiBpbi1wbGFjZS5cbiAgICAgKiBNb3JlIHNwZWNpZmljYWxseSwgc3dhcHMgc3VibWlzc2lvbkEgd2l0aCBzdWJtaXNzaW9uQiBhbmQgc3RhcnRBIHdpdGggc3RhcnRCIGluIG1hdGNoZXMuXG4gICAgICogQHBhcmFtIHBsYWdpYXJpc21Db21wYXJpc29uIHBsYWdpYXJpc20gY29tcGFyaXNvbiB0aGF0IHdpbGwgYmUgbW9kaWZpZWQgaW4tcGxhY2VcbiAgICAgKi9cbiAgICBwcml2YXRlIHN3YXBTdWJtaXNzaW9ucyhwbGFnaWFyaXNtQ29tcGFyaXNvbjogUGxhZ2lhcmlzbUNvbXBhcmlzb248VGV4dFN1Ym1pc3Npb25FbGVtZW50IHwgTW9kZWxpbmdTdWJtaXNzaW9uRWxlbWVudD4pIHtcbiAgICAgICAgY29uc3QgdGVtcCA9IHBsYWdpYXJpc21Db21wYXJpc29uLnN1Ym1pc3Npb25BO1xuICAgICAgICBwbGFnaWFyaXNtQ29tcGFyaXNvbi5zdWJtaXNzaW9uQSA9IHBsYWdpYXJpc21Db21wYXJpc29uLnN1Ym1pc3Npb25CO1xuICAgICAgICBwbGFnaWFyaXNtQ29tcGFyaXNvbi5zdWJtaXNzaW9uQiA9IHRlbXA7XG5cbiAgICAgICAgaWYgKHBsYWdpYXJpc21Db21wYXJpc29uPy5tYXRjaGVzKSB7XG4gICAgICAgICAgICBwbGFnaWFyaXNtQ29tcGFyaXNvbi5tYXRjaGVzLmZvckVhY2goKG1hdGNoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdGVtcFN0YXJ0ID0gbWF0Y2guc3RhcnRBO1xuICAgICAgICAgICAgICAgIG1hdGNoLnN0YXJ0QSA9IG1hdGNoLnN0YXJ0QjtcbiAgICAgICAgICAgICAgICBtYXRjaC5zdGFydEIgPSB0ZW1wU3RhcnQ7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHBhcnNlVGV4dE1hdGNoZXMocGxhZ0NvbXBhcmlzb246IFBsYWdpYXJpc21Db21wYXJpc29uPFRleHRTdWJtaXNzaW9uRWxlbWVudD4pIHtcbiAgICAgICAgaWYgKHBsYWdDb21wYXJpc29uLm1hdGNoZXMpIHtcbiAgICAgICAgICAgIGNvbnN0IG1hdGNoZXNBID0gcGxhZ0NvbXBhcmlzb24ubWF0Y2hlcy5tYXAoKG1hdGNoKSA9PiBuZXcgU2ltcGxlTWF0Y2gobWF0Y2guc3RhcnRBLCBtYXRjaC5sZW5ndGgpKS5zb3J0KChtMSwgbTIpID0+IG0xLnN0YXJ0IC0gbTIuc3RhcnQpO1xuICAgICAgICAgICAgY29uc3QgbWF0Y2hlc0IgPSBwbGFnQ29tcGFyaXNvbi5tYXRjaGVzLm1hcCgobWF0Y2gpID0+IG5ldyBTaW1wbGVNYXRjaChtYXRjaC5zdGFydEIsIG1hdGNoLmxlbmd0aCkpLnNvcnQoKG0xLCBtMikgPT4gbTEuc3RhcnQgLSBtMi5zdGFydCk7XG5cbiAgICAgICAgICAgIHRoaXMubWF0Y2hlc0EgPSB0aGlzLm1hcE1hdGNoZXNUb0VsZW1lbnRzKG1hdGNoZXNBLCBwbGFnQ29tcGFyaXNvbi5zdWJtaXNzaW9uQSk7XG4gICAgICAgICAgICB0aGlzLm1hdGNoZXNCID0gdGhpcy5tYXBNYXRjaGVzVG9FbGVtZW50cyhtYXRjaGVzQiwgcGxhZ0NvbXBhcmlzb24uc3VibWlzc2lvbkIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gZW1wdHkgbWFwIGluIGNhc2Ugbm8gbWF0Y2hlcyBhcmUgYXZhaWxhYmxlXG4gICAgICAgICAgICB0aGlzLm1hdGNoZXNBID0gbmV3IE1hcDxzdHJpbmcsIEZyb21Ub0VsZW1lbnRbXT4oKTtcbiAgICAgICAgICAgIHRoaXMubWF0Y2hlc0IgPSBuZXcgTWFwPHN0cmluZywgRnJvbVRvRWxlbWVudFtdPigpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ3JlYXRlIGEgbWFwIG9mIGZpbGUgbmFtZXMgdG8gbWF0Y2hlcyBlbGVtZW50cy5cbiAgICAgKiBAcGFyYW0gbWF0Y2hlcyBsaXN0IG9mIG9iamVjdHMgY29udGFpbmluZyB0aGUgaW5kZXggYW5kIGxlbmd0aCBvZiBtYXRjaGVkIGVsZW1lbnRzXG4gICAgICogQHBhcmFtIHN1Ym1pc3Npb24gdGhlIHN1Ym1pc3Npb24gdG8gbWFwIHRoZSBlbGVtZW50cyBvZlxuICAgICAqL1xuICAgIG1hcE1hdGNoZXNUb0VsZW1lbnRzKG1hdGNoZXM6IFNpbXBsZU1hdGNoW10sIHN1Ym1pc3Npb246IFBsYWdpYXJpc21TdWJtaXNzaW9uPFRleHRTdWJtaXNzaW9uRWxlbWVudD4pIHtcbiAgICAgICAgY29uc3QgZmlsZXNUb01hdGNoZWRFbGVtZW50cyA9IG5ldyBNYXA8c3RyaW5nLCBGcm9tVG9FbGVtZW50W10+KCk7XG5cbiAgICAgICAgbWF0Y2hlcy5mb3JFYWNoKChtYXRjaCkgPT4ge1xuICAgICAgICAgICAgLy8gc2tpcCBlbXB0eSBqcGxhZyAod2hpdGVzcGFjZSkgbWF0Y2hlc1xuICAgICAgICAgICAgaWYgKG1hdGNoLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGZpbGUgPSBzdWJtaXNzaW9uLmVsZW1lbnRzIVttYXRjaC5zdGFydF0/LmZpbGUgfHwgJ25vbmUnO1xuXG4gICAgICAgICAgICBpZiAoIWZpbGVzVG9NYXRjaGVkRWxlbWVudHMuaGFzKGZpbGUpKSB7XG4gICAgICAgICAgICAgICAgZmlsZXNUb01hdGNoZWRFbGVtZW50cy5zZXQoZmlsZSwgW10pO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjb25zdCBmaWxlTWF0Y2hlcyA9IGZpbGVzVG9NYXRjaGVkRWxlbWVudHMuZ2V0KGZpbGUpITtcblxuICAgICAgICAgICAgZmlsZU1hdGNoZXMucHVzaChuZXcgRnJvbVRvRWxlbWVudChzdWJtaXNzaW9uLmVsZW1lbnRzIVttYXRjaC5zdGFydF0sIHN1Ym1pc3Npb24uZWxlbWVudHMhW21hdGNoLnN0YXJ0ICsgbWF0Y2gubGVuZ3RoIC0gMV0pKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgcmV0dXJuIGZpbGVzVG9NYXRjaGVkRWxlbWVudHM7XG4gICAgfVxuXG4gICAgZ2V0TW9kZWxpbmdTdWJtaXNzaW9uQSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucGxhZ2lhcmlzbUNvbXBhcmlzb24uc3VibWlzc2lvbkEgYXMgUGxhZ2lhcmlzbVN1Ym1pc3Npb248TW9kZWxpbmdTdWJtaXNzaW9uRWxlbWVudD47XG4gICAgfVxuXG4gICAgZ2V0TW9kZWxpbmdTdWJtaXNzaW9uQigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucGxhZ2lhcmlzbUNvbXBhcmlzb24uc3VibWlzc2lvbkIgYXMgUGxhZ2lhcmlzbVN1Ym1pc3Npb248TW9kZWxpbmdTdWJtaXNzaW9uRWxlbWVudD47XG4gICAgfVxuXG4gICAgZ2V0VGV4dFN1Ym1pc3Npb25BKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5wbGFnaWFyaXNtQ29tcGFyaXNvbi5zdWJtaXNzaW9uQSBhcyBQbGFnaWFyaXNtU3VibWlzc2lvbjxUZXh0U3VibWlzc2lvbkVsZW1lbnQ+O1xuICAgIH1cblxuICAgIGdldFRleHRTdWJtaXNzaW9uQigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucGxhZ2lhcmlzbUNvbXBhcmlzb24uc3VibWlzc2lvbkIgYXMgUGxhZ2lhcmlzbVN1Ym1pc3Npb248VGV4dFN1Ym1pc3Npb25FbGVtZW50PjtcbiAgICB9XG5cbiAgICBoYW5kbGVTcGxpdENvbnRyb2wocGFuZTogc3RyaW5nKSB7XG4gICAgICAgIHN3aXRjaCAocGFuZSkge1xuICAgICAgICAgICAgY2FzZSAnbGVmdCc6IHtcbiAgICAgICAgICAgICAgICB0aGlzLnNwbGl0LmNvbGxhcHNlKDEpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ3JpZ2h0Jzoge1xuICAgICAgICAgICAgICAgIHRoaXMuc3BsaXQuY29sbGFwc2UoMCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnZXZlbic6IHtcbiAgICAgICAgICAgICAgICB0aGlzLnNwbGl0LnNldFNpemVzKFs1MCwgNTBdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXNwbGl0LXZpZXdcIj5cbiAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1zcGxpdC1wYW5lXCIgamhpUGFuZT5cbiAgICAgICAgQGlmIChwbGFnaWFyaXNtQ29tcGFyaXNvbikge1xuICAgICAgICAgICAgQGlmIChpc01vZGVsaW5nRXhlcmNpc2UpIHtcbiAgICAgICAgICAgICAgICA8amhpLW1vZGVsaW5nLXN1Ym1pc3Npb24tdmlld2VyIFtleGVyY2lzZV09XCJleGVyY2lzZVwiIFtwbGFnaWFyaXNtU3VibWlzc2lvbl09XCJnZXRNb2RlbGluZ1N1Ym1pc3Npb25BKClcIj48L2poaS1tb2RlbGluZy1zdWJtaXNzaW9uLXZpZXdlcj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAoaXNQcm9ncmFtbWluZ09yVGV4dEV4ZXJjaXNlKSB7XG4gICAgICAgICAgICAgICAgPGpoaS10ZXh0LXN1Ym1pc3Npb24tdmlld2VyIFtleGVyY2lzZV09XCJleGVyY2lzZVwiIFttYXRjaGVzXT1cIm1hdGNoZXNBXCIgW3BsYWdpYXJpc21TdWJtaXNzaW9uXT1cImdldFRleHRTdWJtaXNzaW9uQSgpXCI+PC9qaGktdGV4dC1zdWJtaXNzaW9uLXZpZXdlcj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXNwbGl0LXBhbmVcIiBqaGlQYW5lPlxuICAgICAgICBAaWYgKHBsYWdpYXJpc21Db21wYXJpc29uKSB7XG4gICAgICAgICAgICBAaWYgKGlzTW9kZWxpbmdFeGVyY2lzZSkge1xuICAgICAgICAgICAgICAgIDxqaGktbW9kZWxpbmctc3VibWlzc2lvbi12aWV3ZXIgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCIgW3BsYWdpYXJpc21TdWJtaXNzaW9uXT1cImdldE1vZGVsaW5nU3VibWlzc2lvbkIoKVwiPjwvamhpLW1vZGVsaW5nLXN1Ym1pc3Npb24tdmlld2VyPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmIChpc1Byb2dyYW1taW5nT3JUZXh0RXhlcmNpc2UpIHtcbiAgICAgICAgICAgICAgICA8amhpLXRleHQtc3VibWlzc2lvbi12aWV3ZXIgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCIgW21hdGNoZXNdPVwibWF0Y2hlc0JcIiBbcGxhZ2lhcmlzbVN1Ym1pc3Npb25dPVwiZ2V0VGV4dFN1Ym1pc3Npb25CKClcIj48L2poaS10ZXh0LXN1Ym1pc3Npb24tdmlld2VyPlxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgPC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFN1YmplY3QgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IFBsYWdpYXJpc21Db21wYXJpc29uIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtQ29tcGFyaXNvbic7XG5pbXBvcnQgeyBFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBUZXh0U3VibWlzc2lvbkVsZW1lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL3RleHQvVGV4dFN1Ym1pc3Npb25FbGVtZW50JztcbmltcG9ydCB7IE1vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL21vZGVsaW5nL01vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1wbGFnaWFyaXNtLWRldGFpbHMnLFxuICAgIHN0eWxlVXJsczogWycuL3BsYWdpYXJpc20tZGV0YWlscy5jb21wb25lbnQuc2NzcyddLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9wbGFnaWFyaXNtLWRldGFpbHMuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBQbGFnaWFyaXNtRGV0YWlsc0NvbXBvbmVudCB7XG4gICAgQElucHV0KCkgY29tcGFyaXNvbj86IFBsYWdpYXJpc21Db21wYXJpc29uPFRleHRTdWJtaXNzaW9uRWxlbWVudCB8IE1vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQ+O1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlOiBFeGVyY2lzZTtcblxuICAgIC8qKlxuICAgICAqIFN1YmplY3QgdG8gYmUgcGFzc2VkIGludG8gUGxhZ2lhcmlzbVNwbGl0Vmlld0NvbXBvbmVudCB0byBjb250cm9sIHRoZSBzcGxpdCB2aWV3LlxuICAgICAqL1xuICAgIHNwbGl0Q29udHJvbFN1YmplY3Q6IFN1YmplY3Q8c3RyaW5nPiA9IG5ldyBTdWJqZWN0PHN0cmluZz4oKTtcbn1cbiIsIkBpZiAoY29tcGFyaXNvbikge1xuICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLWRldGFpbHNcIj5cbiAgICAgICAgPGpoaS1wbGFnaWFyaXNtLWhlYWRlciBbc3BsaXRDb250cm9sU3ViamVjdF09XCJzcGxpdENvbnRyb2xTdWJqZWN0XCIgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCIgW2NvbXBhcmlzb25dPVwiY29tcGFyaXNvblwiPjwvamhpLXBsYWdpYXJpc20taGVhZGVyPlxuICAgICAgICA8amhpLXBsYWdpYXJpc20tc3BsaXQtdmlldyBbY29tcGFyaXNvbl09XCJjb21wYXJpc29uXCIgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCIgW3NwbGl0Q29udHJvbFN1YmplY3RdPVwic3BsaXRDb250cm9sU3ViamVjdFwiPjwvamhpLXBsYWdpYXJpc20tc3BsaXQtdmlldz5cbiAgICA8L2Rpdj5cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT25DaGFuZ2VzLCBPdXRwdXQsIFNpbXBsZUNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFBsYWdpYXJpc21Db21wYXJpc29uIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtQ29tcGFyaXNvbic7XG5pbXBvcnQgeyBUZXh0U3VibWlzc2lvbkVsZW1lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL3RleHQvVGV4dFN1Ym1pc3Npb25FbGVtZW50JztcbmltcG9ydCB7IE1vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL21vZGVsaW5nL01vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbVN0YXR1cyB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbVN0YXR1cyc7XG5pbXBvcnQgeyBmYUFycm93TGVmdCwgZmFBcnJvd1JpZ2h0LCBmYUNoZXZyb25SaWdodCwgZmFFeGNsYW1hdGlvblRyaWFuZ2xlIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktcGxhZ2lhcmlzbS1zaWRlYmFyJyxcbiAgICBzdHlsZVVybHM6IFsnLi9wbGFnaWFyaXNtLXNpZGViYXIuY29tcG9uZW50LnNjc3MnXSxcbiAgICB0ZW1wbGF0ZVVybDogJy4vcGxhZ2lhcmlzbS1zaWRlYmFyLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgUGxhZ2lhcmlzbVNpZGViYXJDb21wb25lbnQgaW1wbGVtZW50cyBPbkNoYW5nZXMge1xuICAgIEBJbnB1dCgpIGFjdGl2ZUlEOiBudW1iZXI7XG4gICAgQElucHV0KCkgY29tcGFyaXNvbnM/OiBQbGFnaWFyaXNtQ29tcGFyaXNvbjxUZXh0U3VibWlzc2lvbkVsZW1lbnQgfCBNb2RlbGluZ1N1Ym1pc3Npb25FbGVtZW50PltdO1xuICAgIEBJbnB1dCgpIGNhc2VzRmlsdGVyZWQgPSBmYWxzZTtcbiAgICBASW5wdXQoKSBvZmZzZXQgPSAwO1xuXG4gICAgQElucHV0KCkgc2hvd1J1bkRldGFpbHM6IGJvb2xlYW47XG4gICAgQE91dHB1dCgpIHNob3dSdW5EZXRhaWxzQ2hhbmdlID0gbmV3IEV2ZW50RW1pdHRlcjxib29sZWFuPigpO1xuXG4gICAgQE91dHB1dCgpIHNlbGVjdEluZGV4ID0gbmV3IEV2ZW50RW1pdHRlcjxudW1iZXI+KCk7XG5cbiAgICByZWFkb25seSBDT05GSVJNRUQgPSBQbGFnaWFyaXNtU3RhdHVzLkNPTkZJUk1FRDtcbiAgICByZWFkb25seSBERU5JRUQgPSBQbGFnaWFyaXNtU3RhdHVzLkRFTklFRDtcblxuICAgIGZhRXhjbGFtYXRpb25UcmlhbmdsZSA9IGZhRXhjbGFtYXRpb25UcmlhbmdsZTtcblxuICAgIC8qKlxuICAgICAqIEluZGV4IG9mIHRoZSBjdXJyZW50bHkgc2VsZWN0ZWQgcmVzdWx0IHBhZ2UuXG4gICAgICovXG4gICAgcHVibGljIGN1cnJlbnRQYWdlID0gMDtcblxuICAgIC8qKlxuICAgICAqIFRvdGFsIG51bWJlciBvZiByZXN1bHQgcGFnZXMuXG4gICAgICovXG4gICAgcHVibGljIG51bWJlck9mUGFnZXMgPSAwO1xuXG4gICAgLyoqXG4gICAgICogU3Vic2V0IG9mIGN1cnJlbnRseSBwYWdlZCBjb21wYXJpc29ucy5cbiAgICAgKi9cbiAgICBwdWJsaWMgcGFnZWRDb21wYXJpc29ucz86IFBsYWdpYXJpc21Db21wYXJpc29uPFRleHRTdWJtaXNzaW9uRWxlbWVudCB8IE1vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQ+W107XG5cbiAgICAvKipcbiAgICAgKiBOdW1iZXIgb2YgY29tcGFyaXNvbnMgcGVyIHBhZ2UuXG4gICAgICovXG4gICAgcHVibGljIHBhZ2VTaXplID0gMTAwO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUNoZXZyb25SaWdodCA9IGZhQ2hldnJvblJpZ2h0O1xuICAgIGZhQXJyb3dMZWZ0ID0gZmFBcnJvd0xlZnQ7XG4gICAgZmFBcnJvd1JpZ2h0ID0gZmFBcnJvd1JpZ2h0O1xuXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBpZiAoY2hhbmdlcy5jb21wYXJpc29ucykge1xuICAgICAgICAgICAgY29uc3QgY29tcGFyaXNvbnM6IFBsYWdpYXJpc21Db21wYXJpc29uPFRleHRTdWJtaXNzaW9uRWxlbWVudCB8IE1vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQ+W10gPSBjaGFuZ2VzLmNvbXBhcmlzb25zLmN1cnJlbnRWYWx1ZTtcblxuICAgICAgICAgICAgdGhpcy5jdXJyZW50UGFnZSA9IDA7XG4gICAgICAgICAgICBpZiAoIWNvbXBhcmlzb25zKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5udW1iZXJPZlBhZ2VzID0gMTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5udW1iZXJPZlBhZ2VzID0gdGhpcy5jb21wdXRlTnVtYmVyT2ZQYWdlcyhjb21wYXJpc29ucy5sZW5ndGgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5wYWdlZENvbXBhcmlzb25zID0gdGhpcy5nZXRQYWdlZENvbXBhcmlzb25zKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBkaXNwbGF5UnVuRGV0YWlscygpIHtcbiAgICAgICAgdGhpcy5zaG93UnVuRGV0YWlsc0NoYW5nZS5lbWl0KHRydWUpO1xuICAgIH1cblxuICAgIGNvbXB1dGVOdW1iZXJPZlBhZ2VzKHRvdGFsQ29tcGFyaXNvbnM6IG51bWJlcikge1xuICAgICAgICByZXR1cm4gTWF0aC5jZWlsKHRvdGFsQ29tcGFyaXNvbnMgLyB0aGlzLnBhZ2VTaXplKTtcbiAgICB9XG5cbiAgICBnZXRQYWdlZENvbXBhcmlzb25zKCkge1xuICAgICAgICBjb25zdCBzdGFydEluZGV4ID0gdGhpcy5jdXJyZW50UGFnZSAqIHRoaXMucGFnZVNpemU7XG4gICAgICAgIHJldHVybiB0aGlzLmNvbXBhcmlzb25zPy5zbGljZShzdGFydEluZGV4LCBzdGFydEluZGV4ICsgdGhpcy5wYWdlU2l6ZSk7XG4gICAgfVxuXG4gICAgZ2V0UGFnZWRJbmRleChpZHg6IG51bWJlcikge1xuICAgICAgICByZXR1cm4gaWR4ICsgdGhpcy5jdXJyZW50UGFnZSAqIHRoaXMucGFnZVNpemU7XG4gICAgfVxuXG4gICAgaGFuZGxlUGFnZUxlZnQoKSB7XG4gICAgICAgIGlmICh0aGlzLmN1cnJlbnRQYWdlID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmN1cnJlbnRQYWdlLS07XG4gICAgICAgIHRoaXMucGFnZWRDb21wYXJpc29ucyA9IHRoaXMuZ2V0UGFnZWRDb21wYXJpc29ucygpO1xuICAgIH1cblxuICAgIGhhbmRsZVBhZ2VSaWdodCgpIHtcbiAgICAgICAgaWYgKHRoaXMuY3VycmVudFBhZ2UgKyAxID49IHRoaXMubnVtYmVyT2ZQYWdlcykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5jdXJyZW50UGFnZSsrO1xuICAgICAgICB0aGlzLnBhZ2VkQ29tcGFyaXNvbnMgPSB0aGlzLmdldFBhZ2VkQ29tcGFyaXNvbnMoKTtcbiAgICB9XG59XG4iLCI8YXNpZGUgY2xhc3M9XCJwbGFnaWFyaXNtLXNpZGViYXJcIj5cbiAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1pbmZvLXRhYlwiIFtjbGFzcy5zZWxlY3RlZF09XCJzaG93UnVuRGV0YWlsc1wiIChjbGljayk9XCJkaXNwbGF5UnVuRGV0YWlscygpXCI+XG4gICAgICAgIDxzcGFuPlJ1biBkZXRhaWxzPC9zcGFuPlxuICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUNoZXZyb25SaWdodFwiPjwvZmEtaWNvbj5cbiAgICA8L2Rpdj5cbiAgICBAaWYgKGNhc2VzRmlsdGVyZWQpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cImZpbHRlci1kaXNjbGFpbWVyXCI+XG4gICAgICAgICAgICA8ZmEtaWNvbiBjbGFzcz1cInRleHQtd2FybmluZyBkaXNjbGFpbWVyLWljb25cIiBbaWNvbl09XCJmYUV4Y2xhbWF0aW9uVHJpYW5nbGVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICA8c3Bhbj57eyAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLmNhc2VzRmlsdGVyZWQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuICAgIDwhLS0gIFRlbXBvcmFyeSBzb2x1dGlvbiB1bnRpbCAjNjU5MyBpcyBmaXhlZCAgLS0+XG4gICAgQGlmIChjb21wYXJpc29ucz8ubGVuZ3RoID09PSAxMDApIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cImZpbHRlci1kaXNjbGFpbWVyXCI+XG4gICAgICAgICAgICA8ZmEtaWNvbiBjbGFzcz1cInRleHQtd2FybmluZyBkaXNjbGFpbWVyLWljb25cIiBbaWNvbl09XCJmYUV4Y2xhbWF0aW9uVHJpYW5nbGVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICA8c3Bhbj57eyAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLmNhc2VzVHJpbW1lZCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmIChjb21wYXJpc29ucyAmJiBjb21wYXJpc29ucy5sZW5ndGgpIHtcbiAgICAgICAgPHVsIGNsYXNzPVwicGxhZ2lhcmlzbS1saXN0XCI+XG4gICAgICAgICAgICBAZm9yIChjb21wYXJpc29uIG9mIHBhZ2VkQ29tcGFyaXNvbnM7IHRyYWNrIGNvbXBhcmlzb247IGxldCBpZHggPSAkaW5kZXgpIHtcbiAgICAgICAgICAgICAgICA8bGkgY2xhc3M9XCJwbGFnaWFyaXNtLWxpc3QtaXRlbVwiIFtjbGFzcy5zZWxlY3RlZF09XCIhc2hvd1J1bkRldGFpbHMgJiYgY29tcGFyaXNvbi5pZCA9PT0gYWN0aXZlSURcIiAoY2xpY2spPVwic2VsZWN0SW5kZXguZW1pdChjb21wYXJpc29uLmlkKVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1saXN0LWl0ZW0tY29udGVudFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInBsYWdpYXJpc20tc3RhdHVzLWluZGljYXRvclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nQ2xhc3NdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25maXJtZWQ6IGNvbXBhcmlzb24uc3RhdHVzID09PSBDT05GSVJNRUQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbmllZDogY29tcGFyaXNvbi5zdGF0dXMgPT09IERFTklFRFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLWxpc3QtaXRlbS1pbmZvXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJwbGFnaWFyaXNtLW5hbWVcIj4gI3t7IGdldFBhZ2VkSW5kZXgoaWR4KSArIDEgKyBvZmZzZXQgfX0gPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwicGxhZ2lhcmlzbS1saXN0LWl0ZW0tc3R1ZGVudHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgY29tcGFyaXNvbi5zdWJtaXNzaW9uQS5zdHVkZW50TG9naW4gfHwgKCdhcnRlbWlzQXBwLnBsYWdpYXJpc20udW5rbm93blN0dWRlbnQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSkgfX0sIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgY29tcGFyaXNvbi5zdWJtaXNzaW9uQi5zdHVkZW50TG9naW4gfHwgKCdhcnRlbWlzQXBwLnBsYWdpYXJpc20udW5rbm93blN0dWRlbnQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSkgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInBsYWdpYXJpc20tcGVyY2VudGFnZVwiPih7eyBjb21wYXJpc29uLnNpbWlsYXJpdHkgfHwgMCB8IG51bWJlcjogJzEuMi0yJyB9fSAlKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgfVxuICAgICAgICA8L3VsPlxuICAgIH1cbiAgICBAaWYgKCFjb21wYXJpc29ucyB8fCAhY29tcGFyaXNvbnMubGVuZ3RoKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLWVtcHR5XCI+XG4gICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLm5vdEZvdW5kJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXBhZ2luZ1wiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1wYWdpbmctbGVmdFwiIFtjbGFzcy5kaXNhYmxlZF09XCJjdXJyZW50UGFnZSA9PT0gMFwiIChjbGljayk9XCJoYW5kbGVQYWdlTGVmdCgpXCI+XG4gICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUFycm93TGVmdFwiPjwvZmEtaWNvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXBhZ2luZy1jZW50ZXJcIj57eyBjdXJyZW50UGFnZSArIDEgfX0ve3sgbnVtYmVyT2ZQYWdlcyB9fTwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1wYWdpbmctcmlnaHRcIiBbY2xhc3MuZGlzYWJsZWRdPVwiY3VycmVudFBhZ2UgKyAxID49IG51bWJlck9mUGFnZXNcIiAoY2xpY2spPVwiaGFuZGxlUGFnZVJpZ2h0KClcIj5cbiAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQXJyb3dSaWdodFwiPjwvZmEtaWNvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG48L2FzaWRlPlxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbUNvbXBhcmlzb24gfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21Db21wYXJpc29uJztcbmltcG9ydCB7IFJhbmdlIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL3V0aWxzJztcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBQbGFnaWFyaXNtSW5zcGVjdG9yU2VydmljZSB7XG4gICAgLyoqXG4gICAgICogRmlsdGVycyB0aGUgZ2l2ZW4gY29tcGFyaXNvbnMgYW5kIHJldHVybnMgb25seSB0aG9zZSB0aGF0IGhhdmUgYSBzaW1pbGFyaXR5IHdpdGhpbiB0aGUgcmFuZ2UgW21pbmltdW1TaW1pbGFyaXR5LCBtYXhpbXVtU2ltaWxhcml0eSlcbiAgICAgKiBOb3RlOiBzaW1pbGFyaXRpZXMgYXJlIGRlZmluZWQgYXMgZG91YmxlcyBiZXR3ZWVuIDAgYW5kIDEwMFxuICAgICAqIEBwYXJhbSByYW5nZSB0aGUgc2ltaWxhcml0eSByYW5nZSB0aGUgY29tcGFyaXNvbnMgc2hvdWxkIGJlIGZpbHRlcmVkIGFnYWluc3RcbiAgICAgKiBAcGFyYW0gY29tcGFyaXNvbnMgdGhlIGNvbXBhcmlzb25zIHRoYXQgc2hvdWxkIGJlIGZpbHRlcmVkXG4gICAgICovXG4gICAgZmlsdGVyQ29tcGFyaXNvbnMocmFuZ2U6IFJhbmdlLCBjb21wYXJpc29ucz86IFBsYWdpYXJpc21Db21wYXJpc29uPGFueT5bXSk6IFBsYWdpYXJpc21Db21wYXJpc29uPGFueT5bXSB7XG4gICAgICAgIGlmICghY29tcGFyaXNvbnMpIHtcbiAgICAgICAgICAgIHJldHVybiBbXTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgZmlsdGVyRnVuY3Rpb247XG4gICAgICAgIGlmIChyYW5nZS51cHBlckJvdW5kID09PSAxMDApIHtcbiAgICAgICAgICAgIGZpbHRlckZ1bmN0aW9uID0gKGNvbXBhcmlzb246IFBsYWdpYXJpc21Db21wYXJpc29uPGFueT4pID0+IGNvbXBhcmlzb24uc2ltaWxhcml0eSA+PSByYW5nZS5sb3dlckJvdW5kICYmIGNvbXBhcmlzb24uc2ltaWxhcml0eSA8PSByYW5nZS51cHBlckJvdW5kO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZmlsdGVyRnVuY3Rpb24gPSAoY29tcGFyaXNvbjogUGxhZ2lhcmlzbUNvbXBhcmlzb248YW55PikgPT4gY29tcGFyaXNvbi5zaW1pbGFyaXR5ID49IHJhbmdlLmxvd2VyQm91bmQgJiYgY29tcGFyaXNvbi5zaW1pbGFyaXR5IDwgcmFuZ2UudXBwZXJCb3VuZDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY29tcGFyaXNvbnMuZmlsdGVyKGZpbHRlckZ1bmN0aW9uKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBQbGFnaWFyaXNtUmVzdWx0IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtUmVzdWx0JztcbmltcG9ydCB7IFBsYWdpYXJpc21TdWJtaXNzaW9uRWxlbWVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbVN1Ym1pc3Npb25FbGVtZW50JztcblxuLyoqXG4gKiBSZXN1bHQgb2YgdGhlIGF1dG9tYXRpYyBwbGFnaWFyaXNtIGRldGVjdGlvbiBmb3IgbW9kZWxpbmcgZXhlcmNpc2VzLlxuICovXG5leHBvcnQgY2xhc3MgUGxhZ2lhcmlzbVJlc3VsdERUTzxFIGV4dGVuZHMgUGxhZ2lhcmlzbVJlc3VsdDxQbGFnaWFyaXNtU3VibWlzc2lvbkVsZW1lbnQ+PiB7XG4gICAgcGxhZ2lhcmlzbVJlc3VsdDogRTtcbiAgICBwbGFnaWFyaXNtUmVzdWx0U3RhdHM6IFBsYWdpYXJpc21SZXN1bHRTdGF0cztcbn1cblxuZXhwb3J0IGNsYXNzIFBsYWdpYXJpc21SZXN1bHRTdGF0cyB7XG4gICAgbnVtYmVyT2ZEZXRlY3RlZFN1Ym1pc3Npb25zOiBudW1iZXI7XG4gICAgYXZlcmFnZVNpbWlsYXJpdHk6IG51bWJlcjtcbiAgICBtYXhpbWFsU2ltaWxhcml0eTogbnVtYmVyO1xuICAgIGNyZWF0ZWRCeTogc3RyaW5nO1xufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIElucHV0LCBPbkNoYW5nZXMsIE91dHB1dCwgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgVGV4dFBsYWdpYXJpc21SZXN1bHQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL3RleHQvVGV4dFBsYWdpYXJpc21SZXN1bHQnO1xuaW1wb3J0IHsgTW9kZWxpbmdQbGFnaWFyaXNtUmVzdWx0IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9tb2RlbGluZy9Nb2RlbGluZ1BsYWdpYXJpc21SZXN1bHQnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbUFuZFR1dG9yRWZmb3J0RGlyZWN0aXZlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS9wbGFnaWFyaXNtLXJ1bi1kZXRhaWxzL3BsYWdpYXJpc20tYW5kLXR1dG9yLWVmZm9ydC5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgR3JhcGhDb2xvcnMgfSBmcm9tICdhcHAvZW50aXRpZXMvc3RhdGlzdGljcy5tb2RlbCc7XG5pbXBvcnQgeyBSYW5nZSwgcm91bmQgfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvdXRpbHMnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbUNvbXBhcmlzb24gfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21Db21wYXJpc29uJztcbmltcG9ydCB7IFBsYWdpYXJpc21JbnNwZWN0b3JTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS9wbGFnaWFyaXNtLWluc3BlY3Rvci9wbGFnaWFyaXNtLWluc3BlY3Rvci5zZXJ2aWNlJztcbmltcG9ydCB7IFBsYWdpYXJpc21TdGF0dXMgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21TdGF0dXMnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbVJlc3VsdFN0YXRzIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy9QbGFnaWFyaXNtUmVzdWx0RFRPJztcblxuaW50ZXJmYWNlIFNpbWlsYXJpdHlSYW5nZUNvbXBhcmlzb25TdGF0ZURUTyB7XG4gICAgY29uZmlybWVkOiBudW1iZXI7XG4gICAgZGVuaWVkOiBudW1iZXI7XG4gICAgb3BlbjogbnVtYmVyO1xufVxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1wbGFnaWFyaXNtLXJ1bi1kZXRhaWxzJyxcbiAgICBzdHlsZVVybHM6IFsnLi9wbGFnaWFyaXNtLXJ1bi1kZXRhaWxzLmNvbXBvbmVudC5zY3NzJywgJy4uLy4uLy4uLy4uL3NoYXJlZC9jaGFydC92ZXJ0aWNhbC1iYXItY2hhcnQuc2NzcyddLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9wbGFnaWFyaXNtLXJ1bi1kZXRhaWxzLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgUGxhZ2lhcmlzbVJ1bkRldGFpbHNDb21wb25lbnQgZXh0ZW5kcyBQbGFnaWFyaXNtQW5kVHV0b3JFZmZvcnREaXJlY3RpdmUgaW1wbGVtZW50cyBPbkNoYW5nZXMge1xuICAgIC8qKlxuICAgICAqIFJlc3VsdCBvZiB0aGUgYXV0b21hdGVkIHBsYWdpYXJpc20gZGV0ZWN0aW9uXG4gICAgICovXG4gICAgQElucHV0KCkgcGxhZ2lhcmlzbVJlc3VsdD86IFRleHRQbGFnaWFyaXNtUmVzdWx0IHwgTW9kZWxpbmdQbGFnaWFyaXNtUmVzdWx0O1xuICAgIC8qKlxuICAgICAqIFN0YXRpc3RpY3MgZm9yIHRoZSBhdXRvbWF0ZWQgcGxhZ2lhcmlzbSBkZXRlY3Rpb24gcmVzdWx0XG4gICAgICovXG4gICAgQElucHV0KCkgcGxhZ2lhcmlzbVJlc3VsdFN0YXRzPzogUGxhZ2lhcmlzbVJlc3VsdFN0YXRzO1xuICAgIEBPdXRwdXQoKSBzaW1pbGFyaXR5U2VsZWN0ZWQ6IEV2ZW50RW1pdHRlcjxSYW5nZT4gPSBuZXcgRXZlbnRFbWl0dGVyPFJhbmdlPigpO1xuXG4gICAgeVNjYWxlTWF4ID0gNTtcbiAgICB0b3RhbERldGVjdGVkUGxhZ2lhcmlzbXM6IG51bWJlcjtcbiAgICBidWNrZXREVE9zOiBTaW1pbGFyaXR5UmFuZ2VDb21wYXJpc29uU3RhdGVEVE9bXSA9IFtdO1xuXG4gICAgcmVhZG9ubHkgcm91bmQgPSByb3VuZDtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgaW5zcGVjdG9yU2VydmljZTogUGxhZ2lhcmlzbUluc3BlY3RvclNlcnZpY2UpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFRoZSBsYWJlbHMgb2YgdGhlIGNoYXJ0IGFyZSBmaXhlZCBhbmQgcmVwcmVzZW50IHRoZSAxMCBpbnRlcnZhbHMgd2UgZ3JvdXAgdGhlIHNpbWlsYXJpdGllcyBpbnRvLlxuICAgICAgICAgKi9cbiAgICAgICAgdGhpcy5uZ3hDaGFydExhYmVscyA9IFsnWzAlLTEwJSknLCAnWzEwJS0yMCUpJywgJ1syMCUtMzAlKScsICdbMzAlLTQwJSknLCAnWzQwJS01MCUpJywgJ1s1MCUtNjAlKScsICdbNjAlLTcwJSknLCAnWzcwJS04MCUpJywgJ1s4MCUtOTAlKScsICdbOTAlLTEwMCVdJ107XG4gICAgICAgIHRoaXMubmd4Q29sb3IuZG9tYWluID0gWy4uLkFycmF5KDgpLmZpbGwoR3JhcGhDb2xvcnMuTElHSFRfQkxVRSksIC4uLkFycmF5KDIpLmZpbGwoR3JhcGhDb2xvcnMuUkVEKV07XG4gICAgfVxuXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBpZiAoY2hhbmdlcy5wbGFnaWFyaXNtUmVzdWx0KSB7XG4gICAgICAgICAgICB0aGlzLnNldEJ1Y2tldERUT3MoY2hhbmdlcy5wbGFnaWFyaXNtUmVzdWx0LmN1cnJlbnRWYWx1ZS5jb21wYXJpc29ucyB8fCBbXSk7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZUNoYXJ0RGF0YVNldChjaGFuZ2VzLnBsYWdpYXJpc21SZXN1bHQuY3VycmVudFZhbHVlLnNpbWlsYXJpdHlEaXN0cmlidXRpb24gfHwgW10pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlIHRoZSBkYXRhIG9mIHRoZSBkYXRhc2V0IGF0IHRoZSBnaXZlbiBpbmRleC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBkYXRhICAtIHRoZSB1cGRhdGVkIGRhdGEgYXJyYXlcbiAgICAgKi9cbiAgICB1cGRhdGVDaGFydERhdGFTZXQoZGF0YTogbnVtYmVyW10pIHtcbiAgICAgICAgbGV0IG5neERhdGFFbnRpdHk7XG4gICAgICAgIHRoaXMubmd4RGF0YSA9IFtdO1xuICAgICAgICBkYXRhLmZvckVhY2goKHZhbHVlLCBwb3NpdGlvbikgPT4ge1xuICAgICAgICAgICAgbmd4RGF0YUVudGl0eSA9IHtcbiAgICAgICAgICAgICAgICBuYW1lOiB0aGlzLm5neENoYXJ0TGFiZWxzW3Bvc2l0aW9uXSxcbiAgICAgICAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB0aGlzLm5neERhdGEucHVzaChuZ3hEYXRhRW50aXR5KTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMudG90YWxEZXRlY3RlZFBsYWdpYXJpc21zID0gZGF0YS5yZWR1Y2UoKG51bWJlcjEsIG51bWJlcjIpID0+IG51bWJlcjEgKyBudW1iZXIyLCAwKTtcbiAgICAgICAgdGhpcy5uZ3hEYXRhID0gWy4uLnRoaXMubmd4RGF0YV07XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQXV4aWxpYXJ5IG1ldGhvZCB0aGF0IHNldHMgdGhlIGNvbXBhcmlzb24gZHRvcyBmb3IgdGhlIGRpZmZlcmVudCBjaGFydCBidWNrZXRzLiBUaGVzZSBhcmUgdXNlZCBmb3IgdGhlIGNoYXJ0IHRvb2x0aXBzXG4gICAgICogdG8gc2hvdyB0aGUgbnVtYmVyIG9mIGNvbmZpcm1lZCwgZGVuaWVkIGFuZCBvcGVuIHBsYWdpYXJpc20gY2FzZXNcbiAgICAgKiBAcGFyYW0gY29tcGFyaXNvbnMgdGhlIHBhaXJzIGlkZW50aWZpZWQgYnkgdGhlIGRldGVjdGlvbiB0b29sXG4gICAgICovXG4gICAgcHJpdmF0ZSBzZXRCdWNrZXREVE9zKGNvbXBhcmlzb25zOiBQbGFnaWFyaXNtQ29tcGFyaXNvbjxhbnk+W10pOiB2b2lkIHtcbiAgICAgICAgdGhpcy5idWNrZXREVE9zID0gW107XG4gICAgICAgIC8vIHdlIHVzZSB0aGlzIGFycmF5IGFzIG1pbmltdW0gc2ltaWxhcml0aWVzIGZvciB0aGUgZmlsdGVyaW5nXG4gICAgICAgIGNvbnN0IHN0ZXBzID0gWzAsIDEwLCAyMCwgMzAsIDQwLCA1MCwgNjAsIDcwLCA4MCwgOTBdO1xuICAgICAgICBsZXQgY29tcGFyaXNvbnNXaXRoaW5SYW5nZTtcbiAgICAgICAgbGV0IGFkZGl0aW9uSW5mb3JtYXRpb25FbnRyeTtcbiAgICAgICAgc3RlcHMuZm9yRWFjaCgobWluaW11bVNpbWlsYXJpdHkpID0+IHtcbiAgICAgICAgICAgIGNvbXBhcmlzb25zV2l0aGluUmFuZ2UgPSB0aGlzLmluc3BlY3RvclNlcnZpY2UuZmlsdGVyQ29tcGFyaXNvbnMobmV3IFJhbmdlKG1pbmltdW1TaW1pbGFyaXR5LCBtaW5pbXVtU2ltaWxhcml0eSArIDEwKSwgY29tcGFyaXNvbnMpO1xuICAgICAgICAgICAgYWRkaXRpb25JbmZvcm1hdGlvbkVudHJ5ID0ge1xuICAgICAgICAgICAgICAgIGNvbmZpcm1lZDogY29tcGFyaXNvbnNXaXRoaW5SYW5nZS5maWx0ZXIoKGNvbXBhcmlzb24pID0+IGNvbXBhcmlzb24uc3RhdHVzID09PSBQbGFnaWFyaXNtU3RhdHVzLkNPTkZJUk1FRCkubGVuZ3RoLFxuICAgICAgICAgICAgICAgIGRlbmllZDogY29tcGFyaXNvbnNXaXRoaW5SYW5nZS5maWx0ZXIoKGNvbXBhcmlzb24pID0+IGNvbXBhcmlzb24uc3RhdHVzID09PSBQbGFnaWFyaXNtU3RhdHVzLkRFTklFRCkubGVuZ3RoLFxuICAgICAgICAgICAgICAgIG9wZW46IGNvbXBhcmlzb25zV2l0aGluUmFuZ2UuZmlsdGVyKChjb21wYXJpc29uKSA9PiBjb21wYXJpc29uLnN0YXR1cyA9PT0gUGxhZ2lhcmlzbVN0YXR1cy5OT05FKS5sZW5ndGgsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdGhpcy5idWNrZXREVE9zLnB1c2goYWRkaXRpb25JbmZvcm1hdGlvbkVudHJ5KTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgRFRPIGZvciBhIHNwZWNpZmljIGJ1Y2tldFxuICAgICAqIEBwYXJhbSBsYWJlbCB0aGUgYmFyIGxhYmVsIHRoZSBEVE8gc2hvdWxkIGJlIHJldHVybmVkIGZvclxuICAgICAqL1xuICAgIGdldEJ1Y2tldERUTyhsYWJlbDogc3RyaW5nKTogU2ltaWxhcml0eVJhbmdlQ29tcGFyaXNvblN0YXRlRFRPIHtcbiAgICAgICAgY29uc3QgaW5kZXggPSB0aGlzLm5neENoYXJ0TGFiZWxzLmluZGV4T2YobGFiZWwpO1xuICAgICAgICByZXR1cm4gdGhpcy5idWNrZXREVE9zW2luZGV4XTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIYW5kbGVzIHRoZSBjbGljayBvbiBhIHNwZWNpZmljIGNoYXJ0IGJhclxuICAgICAqIEVtaXRzIHRoZSBzZWxlY3RlZCByYW5nZSB0byB7QGxpbmsgUGxhZ2lhcmlzbUluc3BlY3RvckNvbXBvbmVudCNmaWx0ZXJCeUNoYXJ0fSBzbyB0aGF0IHRoZSBjb21wYXJpc29ucyBzaG93biBpbiB0aGUgc2lkZWJhciBjYW4gYmUgZmlsdGVyZWQgYWNjb3JkaW5nbHlcbiAgICAgKiBAcGFyYW0gZXZlbnQgdGhlIGV2ZW50IHRoYXQgaXMgcGFzc2VkIGJ5IG5neC1jaGFydHNcbiAgICAgKi9cbiAgICBvblNlbGVjdChldmVudDogYW55KTogdm9pZCB7XG4gICAgICAgIGNvbnN0IGludGVydmFsID0gZXZlbnQubmFtZSBhcyBzdHJpbmc7XG4gICAgICAgIGNvbnN0IHNlcGFyYXRvckluZGV4ID0gaW50ZXJ2YWwuaW5kZXhPZignLScpO1xuICAgICAgICBjb25zdCBsb3dlckJvdW5kID0gcGFyc2VJbnQoaW50ZXJ2YWwuc2xpY2UoMSwgc2VwYXJhdG9ySW5kZXgpLCAxMCk7XG4gICAgICAgIGNvbnN0IHVwcGVyQm91bmQgPSBwYXJzZUludChpbnRlcnZhbC5zbGljZShzZXBhcmF0b3JJbmRleCArIDEsIGludGVydmFsLmxlbmd0aCAtIDIpLCAxMCk7XG5cbiAgICAgICAgdGhpcy5zaW1pbGFyaXR5U2VsZWN0ZWQuZW1pdChuZXcgUmFuZ2UobG93ZXJCb3VuZCwgdXBwZXJCb3VuZCkpO1xuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXJ1bi1kZXRhaWxzXCI+XG4gICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tcnVuLWRldGFpbHMtc3RhdHNcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tcnVuLWRldGFpbHMtc3RhdHMtaXRlbVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tcnVuLWRldGFpbHMtbGFiZWxcIj5cbiAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLm51bWJlck9mRGV0ZWN0ZWRTdWJtaXNzaW9ucycgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXJ1bi1kZXRhaWxzLWluZm9cIj5cbiAgICAgICAgICAgICAgICB7eyBwbGFnaWFyaXNtUmVzdWx0U3RhdHM/Lm51bWJlck9mRGV0ZWN0ZWRTdWJtaXNzaW9ucyB9fVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1ydW4tZGV0YWlscy1zdGF0cy1pdGVtXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1ydW4tZGV0YWlscy1sYWJlbFwiPlxuICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLnBsYWdpYXJpc20uYXZlcmFnZVNpbWlsYXJpdHknIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1ydW4tZGV0YWlscy1pbmZvXCI+XG4gICAgICAgICAgICAgICAge3sgcGxhZ2lhcmlzbVJlc3VsdFN0YXRzPy5hdmVyYWdlU2ltaWxhcml0eT8udG9GaXhlZCgyKSArICcgJScgfX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tcnVuLWRldGFpbHMtc3RhdHMtaXRlbVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tcnVuLWRldGFpbHMtbGFiZWxcIj5cbiAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLm1heGltYWxTaW1pbGFyaXR5JyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tcnVuLWRldGFpbHMtaW5mb1wiPlxuICAgICAgICAgICAgICAgIHt7IHBsYWdpYXJpc21SZXN1bHRTdGF0cz8ubWF4aW1hbFNpbWlsYXJpdHk/LnRvRml4ZWQoMikgKyAnICUnIH19XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXJ1bi1kZXRhaWxzLXN0YXRzLWl0ZW1cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXJ1bi1kZXRhaWxzLWxhYmVsXCI+XG4gICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAucGxhZ2lhcmlzbS5kdXJhdGlvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXJ1bi1kZXRhaWxzLWluZm8gZHVyYXRpb25cIj5cbiAgICAgICAgICAgICAgICB7eyBwbGFnaWFyaXNtUmVzdWx0Py5kdXJhdGlvbiB8IGRhdGU6ICdISDptbTpzcycgOiAnR01UJyB9fVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1ydW4tZGV0YWlscy1zdGF0cy1pdGVtXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1ydW4tZGV0YWlscy1sYWJlbFwiPlxuICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLnBsYWdpYXJpc20uc3RhcnRlZEF0JyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tcnVuLWRldGFpbHMtaW5mb1wiPlxuICAgICAgICAgICAgICAgIHt7IHBsYWdpYXJpc21SZXN1bHQ/LmNyZWF0ZWREYXRlPy50b0xvY2FsZVN0cmluZygpIHwgZGF0ZTogJ2RkLk1NLllZIEhIOm1tJyA6ICdHTVQnIH19XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXJ1bi1kZXRhaWxzLXN0YXRzLWl0ZW1cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXJ1bi1kZXRhaWxzLWxhYmVsXCI+XG4gICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAucGxhZ2lhcmlzbS5zdGFydGVkQnknIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1ydW4tZGV0YWlscy1pbmZvXCI+XG4gICAgICAgICAgICAgICAge3sgcGxhZ2lhcmlzbVJlc3VsdFN0YXRzPy5jcmVhdGVkQnkgPz8gJ3Vua25vd24nIH19XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG5cbiAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1ydW4tZGV0YWlscy1pdGVtXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXJ1bi1kZXRhaWxzLWxhYmVsIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLnNpbWlsYXJpdHlEaXN0cmlidXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgPGpoaS1oZWxwLWljb24gcGxhY2VtZW50PVwicmlnaHQgYXV0b1wiIHRleHQ9XCJhcnRlbWlzQXBwLnBsYWdpYXJpc20uc2ltaWxhcml0eURpc3RyaWJ1dGlvbkV4cGxhbmF0aW9uVG9vbHRpcFwiPjwvamhpLWhlbHAtaWNvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgI2NvbnRhaW5lclJlZiBjbGFzcz1cInBsYWdpYXJpc20tcnVuLWRldGFpbHMtaW5mb1wiPlxuICAgICAgICAgICAgPG5neC1jaGFydHMtYmFyLXZlcnRpY2FsXG4gICAgICAgICAgICAgICAgW3JvdW5kRWRnZXNdPVwiZmFsc2VcIlxuICAgICAgICAgICAgICAgIFt2aWV3XT1cIltjb250YWluZXJSZWYub2Zmc2V0V2lkdGgsIDQwMF1cIlxuICAgICAgICAgICAgICAgIFtzY2hlbWVdPVwibmd4Q29sb3JcIlxuICAgICAgICAgICAgICAgIFtyZXN1bHRzXT1cIm5neERhdGFcIlxuICAgICAgICAgICAgICAgIFt4QXhpc109XCJ0cnVlXCJcbiAgICAgICAgICAgICAgICBbeUF4aXNdPVwidHJ1ZVwiXG4gICAgICAgICAgICAgICAgW3lBeGlzVGlja0Zvcm1hdHRpbmddPVwieUF4aXNUaWNrRm9ybWF0dGluZ1wiXG4gICAgICAgICAgICAgICAgW3lTY2FsZU1heF09XCJ5U2NhbGVNYXhcIlxuICAgICAgICAgICAgICAgIFtzaG93RGF0YUxhYmVsXT1cInRydWVcIlxuICAgICAgICAgICAgICAgIChzZWxlY3QpPVwib25TZWxlY3QoJGV2ZW50KVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlICN0b29sdGlwVGVtcGxhdGUgbGV0LW1vZGVsPVwibW9kZWxcIj5cbiAgICAgICAgICAgICAgICAgICAgPGI+e3sgJ2FydGVtaXNBcHAucGxhZ2lhcmlzbS5udW1iZXJJZGVudGlmaWVkUGFpcnMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZTogeyBhbW91bnQ6IG1vZGVsLnZhbHVlIH0gfX0gPC9iPiA8YnIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+IHt7ICdhcnRlbWlzQXBwLnBsYWdpYXJpc20uY29uZmlybWVkJyB8IGFydGVtaXNUcmFuc2xhdGU6IHsgYW1vdW50OiBnZXRCdWNrZXREVE8obW9kZWwubGFiZWwpLmNvbmZpcm1lZCB9IH19PC9zcGFuPiA8YnIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+IHt7ICdhcnRlbWlzQXBwLnBsYWdpYXJpc20uZGVuaWVkJyB8IGFydGVtaXNUcmFuc2xhdGU6IHsgYW1vdW50OiBnZXRCdWNrZXREVE8obW9kZWwubGFiZWwpLmRlbmllZCB9IH19PC9zcGFuPiA8YnIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+IHt7ICdhcnRlbWlzQXBwLnBsYWdpYXJpc20ub3BlbicgfCBhcnRlbWlzVHJhbnNsYXRlOiB7IGFtb3VudDogZ2V0QnVja2V0RFRPKG1vZGVsLmxhYmVsKS5vcGVuIH0gfX08L3NwYW4+IDxiciAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLndpdGhTaW1pbGFyaXR5JyB8IGFydGVtaXNUcmFuc2xhdGU6IHsgcmFuZ2U6IG1vZGVsLm5hbWUgfSB9fTwvc3Bhbj4gPGJyIC8+XG4gICAgICAgICAgICAgICAgICAgIDxiPnt7XG4gICAgICAgICAgICAgICAgICAgICAgICAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLnBvcnRpb25PZkFsbENhc2VzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHwgYXJ0ZW1pc1RyYW5zbGF0ZTogeyBwZXJjZW50YWdlOiB0b3RhbERldGVjdGVkUGxhZ2lhcmlzbXMgPiAwID8gcm91bmQoKG1vZGVsLnZhbHVlICogMTAwKSAvIHRvdGFsRGV0ZWN0ZWRQbGFnaWFyaXNtcywgMikgOiAwIH1cbiAgICAgICAgICAgICAgICAgICAgfX08L2I+XG4gICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgIDwvbmd4LWNoYXJ0cy1iYXItdmVydGljYWw+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuPC9kaXY+XG4iLCJleHBvcnQgY2xhc3MgUGxhZ2lhcmlzbU9wdGlvbnMge1xuICAgIC8qKlxuICAgICAqIElnbm9yZSBjb21wYXJpc29ucyB3aG9zZSBzaW1pbGFyaXR5IGlzIGJlbG93IHRoaXMgdGhyZXNob2xkICglKS5cbiAgICAgKi9cbiAgICBzaW1pbGFyaXR5VGhyZXNob2xkOiBudW1iZXI7XG5cbiAgICAvKipcbiAgICAgKiBDb25zaWRlciBvbmx5IHN1Ym1pc3Npb25zIHdob3NlIHNjb3JlIGlzIGdyZWF0ZXIgb3IgZXF1YWwgdG8gdGhpcyB2YWx1ZS5cbiAgICAgKi9cbiAgICBtaW5pbXVtU2NvcmU6IG51bWJlcjtcblxuICAgIC8qKlxuICAgICAqIENvbnNpZGVyIG9ubHkgc3VibWlzc2lvbnMgd2hvc2Ugc2l6ZSBpcyBncmVhdGVyIG9yIGVxdWFsIHRvIHRoaXMgdmFsdWUuXG4gICAgICovXG4gICAgbWluaW11bVNpemU6IG51bWJlcjtcblxuICAgIGNvbnN0cnVjdG9yKHNpbWlsYXJpdHlUaHJlc2hvbGQ6IG51bWJlciwgbWluaW11bVNjb3JlOiBudW1iZXIsIG1pbmltdW1TaXplOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5zaW1pbGFyaXR5VGhyZXNob2xkID0gc2ltaWxhcml0eVRocmVzaG9sZDtcbiAgICAgICAgdGhpcy5taW5pbXVtU2NvcmUgPSBtaW5pbXVtU2NvcmU7XG4gICAgICAgIHRoaXMubWluaW11bVNpemUgPSBtaW5pbXVtU2l6ZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBNYXAgdGhlIG9wdGlvbiB2YWx1ZXMgdG8gc3RyaW5ncyBzbyB0aGF0IHRoZXkgY2FuIGJlIHVzZWQgYXMgcmVxdWVzdCBwYXJhbXMuXG4gICAgICovXG4gICAgdG9QYXJhbXMoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzaW1pbGFyaXR5VGhyZXNob2xkOiB0aGlzLnNpbWlsYXJpdHlUaHJlc2hvbGQudG9TdHJpbmcoKSxcbiAgICAgICAgICAgIG1pbmltdW1TY29yZTogdGhpcy5taW5pbXVtU2NvcmUudG9TdHJpbmcoKSxcbiAgICAgICAgICAgIG1pbmltdW1TaXplOiB0aGlzLm1pbmltdW1TaXplLnRvU3RyaW5nKCksXG4gICAgICAgIH07XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlLCBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE1vZGVsaW5nRXhlcmNpc2VTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9tb2RlbGluZy9tYW5hZ2UvbW9kZWxpbmctZXhlcmNpc2Uuc2VydmljZSc7XG5pbXBvcnQgeyBFeGVyY2lzZSwgRXhlcmNpc2VUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IFRleHRFeGVyY2lzZVNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3RleHQvbWFuYWdlL3RleHQtZXhlcmNpc2UvdGV4dC1leGVyY2lzZS5zZXJ2aWNlJztcbmltcG9ydCB7IE1vZGVsaW5nUGxhZ2lhcmlzbVJlc3VsdCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvbW9kZWxpbmcvTW9kZWxpbmdQbGFnaWFyaXNtUmVzdWx0JztcbmltcG9ydCB7IGRvd25sb2FkRmlsZSwgZG93bmxvYWRaaXBGaWxlRnJvbVJlc3BvbnNlIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2Rvd25sb2FkLnV0aWwnO1xuaW1wb3J0IHsgVGV4dFBsYWdpYXJpc21SZXN1bHQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL3RleHQvVGV4dFBsYWdpYXJpc21SZXN1bHQnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbVJlc3VsdCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbVJlc3VsdCc7XG5pbXBvcnQgeyBFeHBvcnRUb0NzdiB9IGZyb20gJ2V4cG9ydC10by1jc3YnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbUNvbXBhcmlzb24gfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21Db21wYXJpc29uJztcbmltcG9ydCB7IE1vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL21vZGVsaW5nL01vZGVsaW5nU3VibWlzc2lvbkVsZW1lbnQnO1xuaW1wb3J0IHsgVGV4dFN1Ym1pc3Npb25FbGVtZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS90eXBlcy90ZXh0L1RleHRTdWJtaXNzaW9uRWxlbWVudCc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvbWFuYWdlL3NlcnZpY2VzL3Byb2dyYW1taW5nLWV4ZXJjaXNlLnNlcnZpY2UnO1xuaW1wb3J0IHsgUGxhZ2lhcmlzbU9wdGlvbnMgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21PcHRpb25zJztcbmltcG9ydCB7IEpoaVdlYnNvY2tldFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS93ZWJzb2NrZXQvd2Vic29ja2V0LnNlcnZpY2UnO1xuaW1wb3J0IHsgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgVHJhbnNsYXRlU2VydmljZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xuaW1wb3J0IHsgZmFDaGV2cm9uUmlnaHQsIGZhRXhjbGFtYXRpb25UcmlhbmdsZSwgZmFRdWVzdGlvbkNpcmNsZSB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBGZWF0dXJlVG9nZ2xlIH0gZnJvbSAnYXBwL3NoYXJlZC9mZWF0dXJlLXRvZ2dsZS9mZWF0dXJlLXRvZ2dsZS5zZXJ2aWNlJztcbmltcG9ydCB7IFJhbmdlIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL3V0aWxzJztcbmltcG9ydCB7IFBsYWdpYXJpc21JbnNwZWN0b3JTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGxhZ2lhcmlzbS9wbGFnaWFyaXNtLWluc3BlY3Rvci9wbGFnaWFyaXNtLWluc3BlY3Rvci5zZXJ2aWNlJztcbmltcG9ydCB7IFBsYWdpYXJpc21DYXNlc1NlcnZpY2UgfSBmcm9tICdhcHAvY291cnNlL3BsYWdpYXJpc20tY2FzZXMvc2hhcmVkL3BsYWdpYXJpc20tY2FzZXMuc2VydmljZSc7XG5pbXBvcnQgeyBOZ2JNb2RhbCB9IGZyb20gJ0BuZy1ib290c3RyYXAvbmctYm9vdHN0cmFwJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSwgQWxlcnRUeXBlIH0gZnJvbSAnYXBwL2NvcmUvdXRpbC9hbGVydC5zZXJ2aWNlJztcbmltcG9ydCB7IFBsYWdpYXJpc21SZXN1bHREVE8sIFBsYWdpYXJpc21SZXN1bHRTdGF0cyB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbVJlc3VsdERUTyc7XG5cbmV4cG9ydCB0eXBlIFBsYWdpYXJpc21DaGVja1N0YXRlID0ge1xuICAgIHN0YXRlOiAnQ09NUExFVEVEJyB8ICdSVU5OSU5HJztcbiAgICBtZXNzYWdlczogc3RyaW5nO1xufTtcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktcGxhZ2lhcmlzbS1pbnNwZWN0b3InLFxuICAgIHN0eWxlVXJsczogWycuL3BsYWdpYXJpc20taW5zcGVjdG9yLmNvbXBvbmVudC5zY3NzJ10sXG4gICAgdGVtcGxhdGVVcmw6ICcuL3BsYWdpYXJpc20taW5zcGVjdG9yLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgUGxhZ2lhcmlzbUluc3BlY3RvckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgLyoqXG4gICAgICogVGhlIG1vZGVsaW5nIGV4ZXJjaXNlIGZvciB3aGljaCBwbGFnaWFyaXNtIGlzIHRvIGJlIGRldGVjdGVkLlxuICAgICAqL1xuICAgIGV4ZXJjaXNlOiBFeGVyY2lzZTtcblxuICAgIC8qKlxuICAgICAqIFJlc3VsdCBvZiB0aGUgYXV0b21hdGVkIHBsYWdpYXJpc20gZGV0ZWN0aW9uXG4gICAgICovXG4gICAgcGxhZ2lhcmlzbVJlc3VsdD86IFRleHRQbGFnaWFyaXNtUmVzdWx0IHwgTW9kZWxpbmdQbGFnaWFyaXNtUmVzdWx0O1xuXG4gICAgLyoqXG4gICAgICogU3RhdGlzdGljcyBmb3IgdGhlIGF1dG9tYXRlZCBwbGFnaWFyaXNtIGRldGVjdGlvbiByZXN1bHRcbiAgICAgKi9cbiAgICBwbGFnaWFyaXNtUmVzdWx0U3RhdHM/OiBQbGFnaWFyaXNtUmVzdWx0U3RhdHM7XG5cbiAgICAvKipcbiAgICAgKiBUcnVlLCBpZiBhbiBhdXRvbWF0ZWQgcGxhZ2lhcmlzbSBkZXRlY3Rpb24gaXMgcnVubmluZzsgZmFsc2Ugb3RoZXJ3aXNlLlxuICAgICAqL1xuICAgIGRldGVjdGlvbkluUHJvZ3Jlc3MgPSBmYWxzZTtcblxuICAgIGRldGVjdGlvbkluUHJvZ3Jlc3NNZXNzYWdlID0gJyc7XG5cbiAgICAvKipcbiAgICAgKiBJbmRleCBvZiB0aGUgY3VycmVudGx5IHNlbGVjdGVkIGNvbXBhcmlzb24uXG4gICAgICovXG4gICAgc2VsZWN0ZWRDb21wYXJpc29uSWQ6IG51bWJlcjtcblxuICAgIC8qKlxuICAgICAqIFRydWUsIGlmIHRoZSBwbGFnaWFyaXNtIGRldGFpbHMgdGFiIGlzIGFjdGl2ZS5cbiAgICAgKi9cbiAgICBzaG93UnVuRGV0YWlscyA9IGZhbHNlO1xuXG4gICAgLyoqXG4gICAgICogVHJ1ZSwgaWYgdGhlIHBsYWdpYXJpc20gb3B0aW9ucyBzaG91bGQgYmUgZGlzcGxheWVkLlxuICAgICAqL1xuICAgIHNob3dPcHRpb25zID0gZmFsc2U7XG5cbiAgICAvKipcbiAgICAgKiBJZiB0cnVlLCB0aGUgcGxhZ2lhcmlzbSBkZXRlY3Rpb24gd2lsbCByZXR1cm4gdGhlIGdlbmVyYXRlZCBqcGxhZyByZXBvcnQuXG4gICAgICovXG4gICAgZ2VuZXJhdGVKUGxhZ1JlcG9ydCA9IGZhbHNlO1xuXG4gICAgLyoqXG4gICAgICogTWluaW11bSBzaW1pbGFyaXR5ICglKSBvZiB0aGUgY29tcGFyaXNvbnMgdG8gcmV0dXJuLlxuICAgICAqL1xuICAgIHNpbWlsYXJpdHlUaHJlc2hvbGQgPSA5MDtcblxuICAgIC8qKlxuICAgICAqIElnbm9yZSBzdWJtaXNzaW9ucyB3aXRoIGEgc2NvcmUgbGVzcyB0aGFuIGBtaW5pbXVtU2NvcmVgIGluIHBsYWdpYXJpc20gZGV0ZWN0aW9uLlxuICAgICAqL1xuICAgIG1pbmltdW1TY29yZSA9IDA7XG5cbiAgICAvKipcbiAgICAgKiBJZ25vcmUgc3VibWlzc2lvbnMgd2l0aCBhIHNpemUgbGVzcyB0aGFuIGBtaW5pbXVtU2l6ZWAgaW4gcGxhZ2lhcmlzbSBkZXRlY3Rpb24uXG4gICAgICovXG4gICAgbWluaW11bVNpemUgPSA1MDtcblxuICAgIC8qKlxuICAgICAqIFRoZSBtaW5pbXVtU2NvcmUgb3B0aW9uIGlzIG9ubHkgY29uZmlndXJhYmxlLCBpZiB0aGlzIHZhbHVlIGlzIHRydWUuXG4gICAgICovXG4gICAgZW5hYmxlTWluaW11bVNjb3JlID0gZmFsc2U7XG5cbiAgICAvKipcbiAgICAgKiBUaGUgbWluaW11bVNpemUgb3B0aW9uIGlzIG9ubHkgY29uZmlndXJhYmxlLCBpZiB0aGlzIHZhbHVlIGlzIHRydWUuXG4gICAgICovXG4gICAgZW5hYmxlTWluaW11bVNpemUgPSBmYWxzZTtcbiAgICAvKipcbiAgICAgKiBDb21wYXJpc29ucyB0aGF0IGFyZSBjdXJyZW50bHkgdmlzaWJsZSAobWlnaHQgZGlmZmVyIGZyb20gdGhlIG9yaWdpbmFsIHNldCBhcyBmaWx0ZXJpbmcgY2FuIGJlIGFwcGxpZWQpXG4gICAgICovXG4gICAgdmlzaWJsZUNvbXBhcmlzb25zPzogUGxhZ2lhcmlzbUNvbXBhcmlzb248YW55PltdO1xuICAgIGNoYXJ0RmlsdGVyQXBwbGllZCA9IGZhbHNlO1xuICAgIC8qKlxuICAgICAqIE9mZnNldCBvZiB0aGUgY3VycmVudGx5IHZpc2libGUgY29tcGFyaXNvbnMgdG8gdGhlIG9yaWdpbmFsIHNldCBpbiBvcmRlciB0byBrZWVwIHRoZSBudW1iZXJpbmcgZXZlbiBpZiBjb21wYXJpc29ucyBhcmUgZmlsdGVyZWRcbiAgICAgKi9cbiAgICBzaWRlYmFyT2Zmc2V0ID0gMDtcblxuICAgIC8qKlxuICAgICAqIFdoZXRoZXIgYWxsIHBsYWdpYXJpc20gY29tcGFyaXNvbnMgc2hvdWxkIGJlIGRlbGV0ZWQuIElmIHRoaXMgaXMgdHJ1ZSwgY29tcGFyaXNvbnMgd2l0aCB0aGUgc3RhdHVzIFwiYXBwcm92ZWRcIiBvciBcImRlbmllZFwiIHdpbGwgYWxzbyBiZSBkZWxldGVkXG4gICAgICovXG4gICAgZGVsZXRlQWxsUGxhZ2lhcmlzbUNvbXBhcmlzb25zID0gZmFsc2U7XG5cbiAgICByZWFkb25seSBGZWF0dXJlVG9nZ2xlID0gRmVhdHVyZVRvZ2dsZTtcbiAgICByZWFkb25seSBQUk9HUkFNTUlORyA9IEV4ZXJjaXNlVHlwZS5QUk9HUkFNTUlORztcblxuICAgIC8vIEljb25zXG4gICAgZmFRdWVzdGlvbkNpcmNsZSA9IGZhUXVlc3Rpb25DaXJjbGU7XG4gICAgZmFFeGNsYW1hdGlvblRyaWFuZ2xlID0gZmFFeGNsYW1hdGlvblRyaWFuZ2xlO1xuICAgIGZhQ2hldnJvblJpZ2h0ID0gZmFDaGV2cm9uUmlnaHQ7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSByb3V0ZTogQWN0aXZhdGVkUm91dGUsXG4gICAgICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgICAgIHByaXZhdGUgbW9kZWxpbmdFeGVyY2lzZVNlcnZpY2U6IE1vZGVsaW5nRXhlcmNpc2VTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHByb2dyYW1taW5nRXhlcmNpc2VTZXJ2aWNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSB0ZXh0RXhlcmNpc2VTZXJ2aWNlOiBUZXh0RXhlcmNpc2VTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHdlYnNvY2tldFNlcnZpY2U6IEpoaVdlYnNvY2tldFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgdHJhbnNsYXRlU2VydmljZTogVHJhbnNsYXRlU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBpbnNwZWN0b3JTZXJ2aWNlOiBQbGFnaWFyaXNtSW5zcGVjdG9yU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBwbGFnaWFyaXNtQ2FzZXNTZXJ2aWNlOiBQbGFnaWFyaXNtQ2FzZXNTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIG1vZGFsU2VydmljZTogTmdiTW9kYWwsXG4gICAgICAgIHByaXZhdGUgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMucm91dGUuZGF0YS5zdWJzY3JpYmUoKHsgZXhlcmNpc2UgfSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5leGVyY2lzZSA9IGV4ZXJjaXNlO1xuXG4gICAgICAgICAgICB0aGlzLnJlZ2lzdGVyVG9QbGFnYXJpc21EZXRlY3Rpb25Ub3BpYygpO1xuICAgICAgICAgICAgdGhpcy5nZXRMYXRlc3RQbGFnaWFyaXNtUmVzdWx0KCk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlZ2lzdGVycyB0byB0aGUgd2Vic29ja2V0IHRvcGljIG9mIHRoZSBwbGFnaWFyaXNtIGNoZWNrXG4gICAgICogdG8gZ2V0IGZlZWRiYWNrIGFib3V0IHRoZSBwcm9ncmVzc1xuICAgICAqL1xuICAgIHJlZ2lzdGVyVG9QbGFnYXJpc21EZXRlY3Rpb25Ub3BpYygpIHtcbiAgICAgICAgY29uc3QgdG9waWMgPSB0aGlzLmdldFBsYWdhcmlzbURldGVjdGlvblRvcGljKCk7XG4gICAgICAgIHRoaXMud2Vic29ja2V0U2VydmljZS5zdWJzY3JpYmUodG9waWMpO1xuICAgICAgICB0aGlzLndlYnNvY2tldFNlcnZpY2VcbiAgICAgICAgICAgIC5yZWNlaXZlKHRvcGljKVxuICAgICAgICAgICAgLnBpcGUodGFwKChwbGFnaWFyaXNtQ2hlY2tTdGF0ZTogUGxhZ2lhcmlzbUNoZWNrU3RhdGUpID0+IHRoaXMuaGFuZGxlUGxhZ2lhcmlzbUNoZWNrU3RhdGVDaGFuZ2UocGxhZ2lhcmlzbUNoZWNrU3RhdGUpKSlcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXRzIHRoZSB1cmwgdG8gdGhlIHBsYWdpYXJpc20gZGV0ZWN0aW9uIHdlYnNvY2tldCB0b3BpYy5cbiAgICAgKi9cbiAgICBnZXRQbGFnYXJpc21EZXRlY3Rpb25Ub3BpYygpIHtcbiAgICAgICAgbGV0IHRvcGljID0gJy90b3BpYy8nO1xuICAgICAgICBzd2l0Y2ggKHRoaXMuZXhlcmNpc2UudHlwZSkge1xuICAgICAgICAgICAgY2FzZSBFeGVyY2lzZVR5cGUuUFJPR1JBTU1JTkc6XG4gICAgICAgICAgICAgICAgdG9waWMgKz0gJ3Byb2dyYW1taW5nLWV4ZXJjaXNlcyc7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIEV4ZXJjaXNlVHlwZS5URVhUOlxuICAgICAgICAgICAgICAgIHRvcGljICs9ICd0ZXh0LWV4ZXJjaXNlcyc7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIEV4ZXJjaXNlVHlwZS5NT0RFTElORzpcbiAgICAgICAgICAgICAgICB0b3BpYyArPSAnbW9kZWxpbmctZXhlcmNpc2VzJztcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdG9waWMgKyAnLycgKyB0aGlzLmV4ZXJjaXNlLmlkICsgJy9wbGFnaWFyaXNtLWNoZWNrJztcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIYW5kbGVzIHRoZSBzdGF0ZSBjaGFuZ2UgYnkgdXBkYXRpbmcgdGhlIHByb2dyZXNzIHN0YXRlLiBGZXRjaGVzIGxhdGVzdFxuICAgICAqIHJlc3VsdHMgb25jZSBwbGFnaWFyaXNtIGRldGVjdGlvbiBpcyBkb25lLlxuICAgICAqXG4gICAgICogQHBhcmFtIHBsYWdpYXJpc21DaGVja1N0YXRlIHRoZSBzdGF0ZSBwbGFnaWFyaXNtIGNoZWNrXG4gICAgICovXG4gICAgaGFuZGxlUGxhZ2lhcmlzbUNoZWNrU3RhdGVDaGFuZ2UocGxhZ2lhcmlzbUNoZWNrU3RhdGU6IFBsYWdpYXJpc21DaGVja1N0YXRlKSB7XG4gICAgICAgIGNvbnN0IHsgc3RhdGUsIG1lc3NhZ2VzIH0gPSBwbGFnaWFyaXNtQ2hlY2tTdGF0ZTtcbiAgICAgICAgdGhpcy5kZXRlY3Rpb25JblByb2dyZXNzID0gc3RhdGUgPT09ICdSVU5OSU5HJztcbiAgICAgICAgdGhpcy5kZXRlY3Rpb25JblByb2dyZXNzTWVzc2FnZSA9IHN0YXRlID09PSAnUlVOTklORycgPyBtZXNzYWdlcyA6IHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KCdhcnRlbWlzQXBwLnBsYWdpYXJpc20ubG9hZGluZycpO1xuXG4gICAgICAgIGlmIChzdGF0ZSA9PT0gJ0NPTVBMRVRFRCcpIHtcbiAgICAgICAgICAgIHRoaXMuZGV0ZWN0aW9uSW5Qcm9ncmVzc01lc3NhZ2UgPSB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLmZldGNoaW5nUmVzdWx0cycpO1xuICAgICAgICAgICAgdGhpcy5nZXRMYXRlc3RQbGFnaWFyaXNtUmVzdWx0KCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBGZXRjaCB0aGUgbGF0ZXN0IHBsYWdpYXJpc20gcmVzdWx0LiBUaGVyZSBtaWdodCBiZSBubyBwbGFnaWFyaXNtIHJlc3VsdCBmb3IgdGhlIGdpdmVuIGV4ZXJjaXNlIHlldC5cbiAgICAgKi9cbiAgICBnZXRMYXRlc3RQbGFnaWFyaXNtUmVzdWx0KCkge1xuICAgICAgICB0aGlzLmRldGVjdGlvbkluUHJvZ3Jlc3MgPSB0cnVlO1xuXG4gICAgICAgIHN3aXRjaCAodGhpcy5leGVyY2lzZS50eXBlKSB7XG4gICAgICAgICAgICBjYXNlIEV4ZXJjaXNlVHlwZS5NT0RFTElORzoge1xuICAgICAgICAgICAgICAgIHRoaXMubW9kZWxpbmdFeGVyY2lzZVNlcnZpY2UuZ2V0TGF0ZXN0UGxhZ2lhcmlzbVJlc3VsdCh0aGlzLmV4ZXJjaXNlLmlkISkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICAgICAgbmV4dDogKHJlc3VsdCkgPT4gdGhpcy5oYW5kbGVQbGFnaWFyaXNtUmVzdWx0KHJlc3VsdCksXG4gICAgICAgICAgICAgICAgICAgIGVycm9yOiAoKSA9PiB0aGlzLmhhbmRsZUVycm9yKCksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBFeGVyY2lzZVR5cGUuUFJPR1JBTU1JTkc6IHtcbiAgICAgICAgICAgICAgICB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2VTZXJ2aWNlLmdldExhdGVzdFBsYWdpYXJpc21SZXN1bHQodGhpcy5leGVyY2lzZS5pZCEpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgICAgIG5leHQ6IChyZXN1bHQpID0+IHRoaXMuaGFuZGxlUGxhZ2lhcmlzbVJlc3VsdChyZXN1bHQpLFxuICAgICAgICAgICAgICAgICAgICBlcnJvcjogKCkgPT4gdGhpcy5oYW5kbGVFcnJvcigpLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgRXhlcmNpc2VUeXBlLlRFWFQ6IHtcbiAgICAgICAgICAgICAgICB0aGlzLnRleHRFeGVyY2lzZVNlcnZpY2UuZ2V0TGF0ZXN0UGxhZ2lhcmlzbVJlc3VsdCh0aGlzLmV4ZXJjaXNlLmlkISkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICAgICAgbmV4dDogKHJlc3VsdCkgPT4gdGhpcy5oYW5kbGVQbGFnaWFyaXNtUmVzdWx0KHJlc3VsdCksXG4gICAgICAgICAgICAgICAgICAgIGVycm9yOiAoKSA9PiB0aGlzLmhhbmRsZUVycm9yKCksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZGVmYXVsdDoge1xuICAgICAgICAgICAgICAgIHRoaXMuZGV0ZWN0aW9uSW5Qcm9ncmVzcyA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgY2hlY2tQbGFnaWFyaXNtKCkge1xuICAgICAgICBjb25zdCBtaW5pbXVtU2NvcmUgPSB0aGlzLmVuYWJsZU1pbmltdW1TY29yZSA/IHRoaXMubWluaW11bVNjb3JlIDogMDtcbiAgICAgICAgY29uc3QgbWluaW11bVNpemUgPSB0aGlzLmVuYWJsZU1pbmltdW1TaXplID8gdGhpcy5taW5pbXVtU2l6ZSA6IDA7XG5cbiAgICAgICAgY29uc3Qgb3B0aW9ucyA9IG5ldyBQbGFnaWFyaXNtT3B0aW9ucyh0aGlzLnNpbWlsYXJpdHlUaHJlc2hvbGQsIG1pbmltdW1TY29yZSwgbWluaW11bVNpemUpO1xuXG4gICAgICAgIGlmICh0aGlzLmV4ZXJjaXNlLnR5cGUgPT09IEV4ZXJjaXNlVHlwZS5NT0RFTElORykge1xuICAgICAgICAgICAgdGhpcy5jaGVja1BsYWdpYXJpc21Nb2RlbGluZyhvcHRpb25zKTtcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmdlbmVyYXRlSlBsYWdSZXBvcnQpIHtcbiAgICAgICAgICAgIHRoaXMuY2hlY2tQbGFnaWFyaXNtSlBsYWdSZXBvcnQob3B0aW9ucyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmNoZWNrUGxhZ2lhcmlzbUpQbGFnKG9wdGlvbnMpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgc2VsZWN0Q29tcGFyaXNvbldpdGhJRChpZDogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuc2VsZWN0ZWRDb21wYXJpc29uSWQgPSBpZDtcbiAgICAgICAgdGhpcy5zaG93UnVuRGV0YWlscyA9IGZhbHNlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFRoaXMgbWV0aG9kIHRyaWdnZXJzIHRoZSBwbGFnaWFyaXNtIGRldGVjdGlvbiBmb3IgcHJvZ3JhbW1pbmcgZXhlcmNpc2VzIGFuZCBkb3dubG9hZHMgdGhlIHppcHBlZCByZXBvcnQgZ2VuZXJhdGVkIGJ5IEpQbGFnLlxuICAgICAqL1xuICAgIGNoZWNrUGxhZ2lhcmlzbUpQbGFnUmVwb3J0KG9wdGlvbnM/OiBQbGFnaWFyaXNtT3B0aW9ucykge1xuICAgICAgICB0aGlzLmRldGVjdGlvbkluUHJvZ3Jlc3MgPSB0cnVlO1xuXG4gICAgICAgIHRoaXMucHJvZ3JhbW1pbmdFeGVyY2lzZVNlcnZpY2UuY2hlY2tQbGFnaWFyaXNtSlBsYWdSZXBvcnQodGhpcy5leGVyY2lzZS5pZCEsIG9wdGlvbnMpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAocmVzcG9uc2U6IEh0dHBSZXNwb25zZTxCbG9iPikgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuZGV0ZWN0aW9uSW5Qcm9ncmVzcyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGRvd25sb2FkWmlwRmlsZUZyb21SZXNwb25zZShyZXNwb25zZSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZXJyb3I6IChlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICAvLyBOb3RlOiBmb3Igc29tZSByZWFzb24gdGhlIGFsZXJ0IGlzIG5vdCBzaG93biwgd2UgZG8gaXQgbWFudWFsbHkgd2l0aCBhIHdvcmthcm91bmQsIGJlY2F1c2UgdGhlIG1lc3NhZ2UgKHBhcnQgb2YgdGhlIGJvZHkpIGlzIG5vdCBhY2Nlc3NpYmxlIGluIHRoZSBlcnJvclxuICAgICAgICAgICAgICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGVycm9yLmhlYWRlcnMuZ2V0KCd4LWFydGVtaXNhcHAtZXJyb3InKTtcbiAgICAgICAgICAgICAgICBpZiAoZXJyb3JNZXNzYWdlID09PSAnZXJyb3Iubm90RW5vdWdoU3VibWlzc2lvbnMnKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLmFkZEFsZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IEFsZXJ0VHlwZS5EQU5HRVIsXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnSW5zdWZmaWNpZW50IGFtb3VudCBvZiB2YWxpZCBhbmQgbG9uZyBlbm91Z2ggc3VibWlzc2lvbnMgYXZhaWxhYmxlIGZvciBjb21wYXJpc29uJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVUcmFuc2xhdGlvbjogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMuaGFuZGxlRXJyb3IoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGlzUHJvZ3JhbW1pbmdFeGVyY2lzZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZXhlcmNpc2U/LnR5cGUgPT09IEV4ZXJjaXNlVHlwZS5QUk9HUkFNTUlORztcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUcmlnZ2VyIHRoZSBzZXJ2ZXItc2lkZSBwbGFnaWFyaXNtIGRldGVjdGlvbiBhbmQgZmV0Y2ggaXRzIHJlc3VsdC5cbiAgICAgKi9cbiAgICBjaGVja1BsYWdpYXJpc21KUGxhZyhvcHRpb25zPzogUGxhZ2lhcmlzbU9wdGlvbnMpIHtcbiAgICAgICAgdGhpcy5kZXRlY3Rpb25JblByb2dyZXNzID0gdHJ1ZTtcblxuICAgICAgICBpZiAodGhpcy5leGVyY2lzZS50eXBlID09PSBFeGVyY2lzZVR5cGUuVEVYVCkge1xuICAgICAgICAgICAgdGhpcy50ZXh0RXhlcmNpc2VTZXJ2aWNlLmNoZWNrUGxhZ2lhcmlzbSh0aGlzLmV4ZXJjaXNlLmlkISwgb3B0aW9ucykuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAocmVzdWx0KSA9PiB0aGlzLmhhbmRsZVBsYWdpYXJpc21SZXN1bHQocmVzdWx0KSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKCkgPT4gdGhpcy5oYW5kbGVFcnJvcigpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2VTZXJ2aWNlLmNoZWNrUGxhZ2lhcmlzbSh0aGlzLmV4ZXJjaXNlLmlkISwgb3B0aW9ucykuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAocmVzdWx0KSA9PiB0aGlzLmhhbmRsZVBsYWdpYXJpc21SZXN1bHQocmVzdWx0KSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKCkgPT4gdGhpcy5oYW5kbGVFcnJvcigpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBoYW5kbGVFcnJvcigpIHtcbiAgICAgICAgdGhpcy5kZXRlY3Rpb25JblByb2dyZXNzID0gZmFsc2U7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVHJpZ2dlciB0aGUgc2VydmVyLXNpZGUgcGxhZ2lhcmlzbSBkZXRlY3Rpb24gYW5kIGZldGNoIGl0cyByZXN1bHQuXG4gICAgICovXG4gICAgY2hlY2tQbGFnaWFyaXNtTW9kZWxpbmcob3B0aW9ucz86IFBsYWdpYXJpc21PcHRpb25zKSB7XG4gICAgICAgIHRoaXMuZGV0ZWN0aW9uSW5Qcm9ncmVzcyA9IHRydWU7XG5cbiAgICAgICAgdGhpcy5tb2RlbGluZ0V4ZXJjaXNlU2VydmljZS5jaGVja1BsYWdpYXJpc20odGhpcy5leGVyY2lzZS5pZCEsIG9wdGlvbnMpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAocmVzdWx0OiBQbGFnaWFyaXNtUmVzdWx0RFRPPE1vZGVsaW5nUGxhZ2lhcmlzbVJlc3VsdD4pID0+IHRoaXMuaGFuZGxlUGxhZ2lhcmlzbVJlc3VsdChyZXN1bHQpLFxuICAgICAgICAgICAgZXJyb3I6ICgpID0+IHRoaXMuaGFuZGxlRXJyb3IoKSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgaGFuZGxlUGxhZ2lhcmlzbVJlc3VsdChyZXN1bHQ6IFBsYWdpYXJpc21SZXN1bHREVE88TW9kZWxpbmdQbGFnaWFyaXNtUmVzdWx0IHwgVGV4dFBsYWdpYXJpc21SZXN1bHQ+KSB7XG4gICAgICAgIHRoaXMuZGV0ZWN0aW9uSW5Qcm9ncmVzcyA9IGZhbHNlO1xuXG4gICAgICAgIGlmIChyZXN1bHQ/LnBsYWdpYXJpc21SZXN1bHQ/LmNvbXBhcmlzb25zKSB7XG4gICAgICAgICAgICB0aGlzLnNvcnRDb21wYXJpc29uc0ZvclJlc3VsdChyZXN1bHQucGxhZ2lhcmlzbVJlc3VsdCk7XG4gICAgICAgICAgICB0aGlzLnNob3dSdW5EZXRhaWxzID0gdHJ1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMucGxhZ2lhcmlzbVJlc3VsdCA9IHJlc3VsdC5wbGFnaWFyaXNtUmVzdWx0O1xuICAgICAgICB0aGlzLnBsYWdpYXJpc21SZXN1bHRTdGF0cyA9IHJlc3VsdC5wbGFnaWFyaXNtUmVzdWx0U3RhdHM7XG4gICAgICAgIHRoaXMudmlzaWJsZUNvbXBhcmlzb25zID0gcmVzdWx0Py5wbGFnaWFyaXNtUmVzdWx0Py5jb21wYXJpc29ucztcbiAgICB9XG5cbiAgICBzb3J0Q29tcGFyaXNvbnNGb3JSZXN1bHQocmVzdWx0OiBQbGFnaWFyaXNtUmVzdWx0PGFueT4pIHtcbiAgICAgICAgcmVzdWx0LmNvbXBhcmlzb25zID0gcmVzdWx0LmNvbXBhcmlzb25zLnNvcnQoKGEsIGIpID0+IHtcbiAgICAgICAgICAgIC8vIGlmIHRoZSBjYXNlcyBzaGFyZSB0aGUgc2FtZSBzaW1pbGFyaXR5LCB3ZSBzb3J0IGJ5IHRoZSBpZFxuICAgICAgICAgICAgaWYgKGIuc2ltaWxhcml0eSAtIGEuc2ltaWxhcml0eSA9PT0gMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBiLmlkIC0gYS5pZDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGIuc2ltaWxhcml0eSAtIGEuc2ltaWxhcml0eTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRG93bmxvYWQgcGxhZ2lhcmlzbSBkZXRlY3Rpb24gcmVzdWx0cyBhcyBKU09OIGRvY3VtZW50LlxuICAgICAqL1xuICAgIGRvd25sb2FkUGxhZ2lhcmlzbVJlc3VsdHNKc29uKCkge1xuICAgICAgICBjb25zdCBqc29uID0gSlNPTi5zdHJpbmdpZnkodGhpcy5wbGFnaWFyaXNtUmVzdWx0KTtcbiAgICAgICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtqc29uXSwgeyB0eXBlOiAnYXBwbGljYXRpb24vanNvbicgfSk7XG5cbiAgICAgICAgZG93bmxvYWRGaWxlKGJsb2IsIGBwbGFnaWFyaXNtLXJlc3VsdF8ke3RoaXMuZXhlcmNpc2UudHlwZX0tZXhlcmNpc2UtJHt0aGlzLmV4ZXJjaXNlLmlkfS5qc29uYCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRG93bmxvYWQgcGxhZ2lhcmlzbSBkZXRlY3Rpb24gcmVzdWx0cyBhcyBDU1YgZG9jdW1lbnQuXG4gICAgICovXG4gICAgZG93bmxvYWRQbGFnaWFyaXNtUmVzdWx0c0NzdigpIHtcbiAgICAgICAgaWYgKHRoaXMucGxhZ2lhcmlzbVJlc3VsdCAmJiB0aGlzLnBsYWdpYXJpc21SZXN1bHQuY29tcGFyaXNvbnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgY29uc3QgY3N2RXhwb3J0ZXIgPSBuZXcgRXhwb3J0VG9Dc3Yoe1xuICAgICAgICAgICAgICAgIGZpZWxkU2VwYXJhdG9yOiAnOycsXG4gICAgICAgICAgICAgICAgcXVvdGVTdHJpbmdzOiAnXCInLFxuICAgICAgICAgICAgICAgIGRlY2ltYWxTZXBhcmF0b3I6ICdsb2NhbGUnLFxuICAgICAgICAgICAgICAgIHNob3dMYWJlbHM6IHRydWUsXG4gICAgICAgICAgICAgICAgdGl0bGU6IGBQbGFnaWFyaXNtIENoZWNrIGZvciBFeGVyY2lzZSAke3RoaXMuZXhlcmNpc2UuaWR9OiAke3RoaXMuZXhlcmNpc2UudGl0bGV9YCxcbiAgICAgICAgICAgICAgICBmaWxlbmFtZTogYHBsYWdpYXJpc20tcmVzdWx0XyR7dGhpcy5leGVyY2lzZS50eXBlfS1leGVyY2lzZS0ke3RoaXMuZXhlcmNpc2UuaWR9YCxcbiAgICAgICAgICAgICAgICB1c2VUZXh0RmlsZTogZmFsc2UsXG4gICAgICAgICAgICAgICAgdXNlQm9tOiB0cnVlLFxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IFsnU2ltaWxhcml0eScsICdTdGF0dXMnLCAnUGFydGljaXBhbnQgMScsICdTdWJtaXNzaW9uIDEnLCAnU2NvcmUgMScsICdTaXplIDEnLCAnUGFydGljaXBhbnQgMicsICdTdWJtaXNzaW9uIDInLCAnU2NvcmUgMicsICdTaXplIDInXSxcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBjb25zdCBjc3ZEYXRhID0gKHRoaXMucGxhZ2lhcmlzbVJlc3VsdC5jb21wYXJpc29ucyBhcyBQbGFnaWFyaXNtQ29tcGFyaXNvbjxNb2RlbGluZ1N1Ym1pc3Npb25FbGVtZW50IHwgVGV4dFN1Ym1pc3Npb25FbGVtZW50PltdKS5tYXAoKGNvbXBhcmlzb24pID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7XG4gICAgICAgICAgICAgICAgICAgIFNpbWlsYXJpdHk6IGNvbXBhcmlzb24uc2ltaWxhcml0eSxcbiAgICAgICAgICAgICAgICAgICAgU3RhdHVzOiBjb21wYXJpc29uLnN0YXR1cyxcbiAgICAgICAgICAgICAgICAgICAgJ1BhcnRpY2lwYW50IDEnOiBjb21wYXJpc29uLnN1Ym1pc3Npb25BLnN0dWRlbnRMb2dpbixcbiAgICAgICAgICAgICAgICAgICAgJ1N1Ym1pc3Npb24gMSc6IGNvbXBhcmlzb24uc3VibWlzc2lvbkEuc3VibWlzc2lvbklkLFxuICAgICAgICAgICAgICAgICAgICAnU2NvcmUgMSc6IGNvbXBhcmlzb24uc3VibWlzc2lvbkEuc2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICdTaXplIDEnOiBjb21wYXJpc29uLnN1Ym1pc3Npb25BLnNpemUsXG4gICAgICAgICAgICAgICAgICAgICdQYXJ0aWNpcGFudCAyJzogY29tcGFyaXNvbi5zdWJtaXNzaW9uQi5zdHVkZW50TG9naW4sXG4gICAgICAgICAgICAgICAgICAgICdTdWJtaXNzaW9uIDInOiBjb21wYXJpc29uLnN1Ym1pc3Npb25CLnN1Ym1pc3Npb25JZCxcbiAgICAgICAgICAgICAgICAgICAgJ1Njb3JlIDInOiBjb21wYXJpc29uLnN1Ym1pc3Npb25CLnNjb3JlLFxuICAgICAgICAgICAgICAgICAgICAnU2l6ZSAyJzogY29tcGFyaXNvbi5zdWJtaXNzaW9uQi5zaXplLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGNzdkV4cG9ydGVyLmdlbmVyYXRlQ3N2KGNzdkRhdGEpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJuIHRoZSB0cmFuc2xhdGlvbiBpZGVudGlmaWVyIG9mIHRoZSBtaW5pbXVtIHNpemUgdG9vbHRpcCBmb3IgdGhlIGN1cnJlbnQgZXhlcmNpc2UgdHlwZS5cbiAgICAgKi9cbiAgICBnZXRNaW5pbXVtU2l6ZVRvb2x0aXAoKSB7XG4gICAgICAgIHN3aXRjaCAodGhpcy5leGVyY2lzZS50eXBlKSB7XG4gICAgICAgICAgICBjYXNlIEV4ZXJjaXNlVHlwZS5QUk9HUkFNTUlORzoge1xuICAgICAgICAgICAgICAgIHJldHVybiAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLm1pbmltdW1TaXplVG9vbHRpcFByb2dyYW1taW5nRXhlcmNpc2UnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBFeGVyY2lzZVR5cGUuVEVYVDoge1xuICAgICAgICAgICAgICAgIHJldHVybiAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLm1pbmltdW1TaXplVG9vbHRpcFRleHRFeGVyY2lzZSc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIEV4ZXJjaXNlVHlwZS5NT0RFTElORzoge1xuICAgICAgICAgICAgICAgIHJldHVybiAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLm1pbmltdW1TaXplVG9vbHRpcE1vZGVsaW5nRXhlcmNpc2UnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRmlsdGVycyB0aGUgY29tcGFyaXNvbnMgdmlzaWJsZSBpbiB7QGxpbmsgUGxhZ2lhcmlzbVNpZGViYXJDb21wb25lbnR9IGFjY29yZGluZyB0byB0aGUgc2VsZWN0ZWQgc2ltaWxhcml0eSByYW5nZVxuICAgICAqIHNlbGVjdGVkIGJ5IHRoZSB1c2VyIGluIHRoZSBjaGFydFxuICAgICAqIEBwYXJhbSByYW5nZSB0aGUgcmFuZ2Ugc2VsZWN0ZWQgYnkgdGhlIHVzZXIgaW4gdGhlIGNoYXJ0IGJ5IGNsaWNraW5nIG9uIGEgY2hhcnQgYmFyXG4gICAgICovXG4gICAgZmlsdGVyQnlDaGFydChyYW5nZTogUmFuZ2UpOiB2b2lkIHtcbiAgICAgICAgdGhpcy52aXNpYmxlQ29tcGFyaXNvbnMgPSB0aGlzLmluc3BlY3RvclNlcnZpY2UuZmlsdGVyQ29tcGFyaXNvbnMocmFuZ2UsIHRoaXMucGxhZ2lhcmlzbVJlc3VsdD8uY29tcGFyaXNvbnMpO1xuICAgICAgICBjb25zdCBpbmRleCA9IHRoaXMucGxhZ2lhcmlzbVJlc3VsdD8uY29tcGFyaXNvbnMuaW5kZXhPZih0aGlzLnZpc2libGVDb21wYXJpc29uc1swXSkgPz8gMDtcbiAgICAgICAgdGhpcy5zaWRlYmFyT2Zmc2V0ID0gaW5kZXggIT09IC0xID8gaW5kZXggOiAwO1xuICAgICAgICB0aGlzLmNoYXJ0RmlsdGVyQXBwbGllZCA9IHRydWU7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmVzZXRzIHRoZSBmaWx0ZXIgYXBwbGllZCBieSBjaGFydCBpbnRlcmFjdGlvblxuICAgICAqL1xuICAgIHJlc2V0RmlsdGVyKCk6IHZvaWQge1xuICAgICAgICB0aGlzLnZpc2libGVDb21wYXJpc29ucyA9IHRoaXMucGxhZ2lhcmlzbVJlc3VsdD8uY29tcGFyaXNvbnM7XG4gICAgICAgIHRoaXMuY2hhcnRGaWx0ZXJBcHBsaWVkID0gZmFsc2U7XG4gICAgICAgIHRoaXMuc2lkZWJhck9mZnNldCA9IDA7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQXV4aWxpYXJ5IG1ldGhvZCBjYWxsZWQgaWYgdGhlIFwiUnVuIGRldGFpbHNcIiBCdXR0b24gaXMgY2xpY2tlZFxuICAgICAqIFRoaXMgYWRkaXRpb25hbCBsb2dpYyBpcyBuZWNlc3NhcnkgaW4gb3JkZXIgdG8gdXBkYXRlIHRoZSB7QGxpbmsgUGxhZ2lhcmlzbVJ1bkRldGFpbHNDb21wb25lbnQjYnVja2V0RFRPc31cbiAgICAgKiBAcGFyYW0gZmxhZyBlbWl0dGVkIGJ5IHtAbGluayBQbGFnaWFyaXNtU2lkZWJhckNvbXBvbmVudCNzaG93UnVuRGV0YWlsc0NoYW5nZX1cbiAgICAgKi9cbiAgICBzaG93U2ltaWxhcml0eURpc3RyaWJ1dGlvbihmbGFnOiBib29sZWFuKTogdm9pZCB7XG4gICAgICAgIHRoaXMucmVzZXRGaWx0ZXIoKTtcbiAgICAgICAgdGhpcy5nZXRMYXRlc3RQbGFnaWFyaXNtUmVzdWx0KCk7XG4gICAgICAgIHRoaXMuc2hvd1J1bkRldGFpbHMgPSBmbGFnO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEF1eGlsaWFyeSBtZXRob2QgdGhhdCByZXR1cm5zIHRoZSBjb21wYXJpc29uIGN1cnJlbnRseSBzZWxlY3RlZCBieSB0aGUgdXNlclxuICAgICAqL1xuICAgIGdldFNlbGVjdGVkQ29tcGFyaXNvbigpOiBQbGFnaWFyaXNtQ29tcGFyaXNvbjxhbnk+IHtcbiAgICAgICAgLy8gYXMgdGhlIGlkIGlzIHVuaXF1ZSwgdGhlIGZpbHRlcmVkIGFycmF5IHNob3VsZCBhbHdheXMgaGF2ZSBsZW5ndGggMVxuICAgICAgICByZXR1cm4gdGhpcy52aXNpYmxlQ29tcGFyaXNvbnMhLmZpbHRlcigoY29tcGFyaXNvbikgPT4gY29tcGFyaXNvbi5pZCA9PT0gdGhpcy5zZWxlY3RlZENvbXBhcmlzb25JZClbMF07XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU3dpdGNoZXMgdGhlIHN0YXRlIGlmIGFsbCBwbGFnaWFyaXNtIGNvbXBhcmlzb25zIHNob3VsZCBiZSBkZWxldGVkXG4gICAgICovXG4gICAgdG9nZ2xlRGVsZXRlQWxsUGxhZ2lhcmlzbUNvbXBhcmlzb25zKCk6IHZvaWQge1xuICAgICAgICB0aGlzLmRlbGV0ZUFsbFBsYWdpYXJpc21Db21wYXJpc29ucyA9ICF0aGlzLmRlbGV0ZUFsbFBsYWdpYXJpc21Db21wYXJpc29ucztcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDbGVhbiB1cCBwbGFnaWFyaXNtIHJlc3VsdHMgYW5kIHJlbGF0ZWQgb2JqZWN0cyBiZWxvbmdpbmcgdG8gdGhpcyBleGVyY2lzZVxuICAgICAqL1xuICAgIGNsZWFuVXBQbGFnaWFyaXNtKCk6IHZvaWQge1xuICAgICAgICB0aGlzLnBsYWdpYXJpc21DYXNlc1NlcnZpY2UuY2xlYW5VcFBsYWdpYXJpc20odGhpcy5leGVyY2lzZS5pZCEsIHRoaXMucGxhZ2lhcmlzbVJlc3VsdCEuaWQhLCB0aGlzLmRlbGV0ZUFsbFBsYWdpYXJpc21Db21wYXJpc29ucykuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5leHQ6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5kZWxldGVBbGxQbGFnaWFyaXNtQ29tcGFyaXNvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kZWxldGVBbGxQbGFnaWFyaXNtQ29tcGFyaXNvbnMgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wbGFnaWFyaXNtUmVzdWx0ID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZGVsZXRlQWxsUGxhZ2lhcmlzbUNvbXBhcmlzb25zID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2V0TGF0ZXN0UGxhZ2lhcmlzbVJlc3VsdCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE9wZW4gYSBtb2RhbCB0aGF0IHJlcXVpcmVzIHRoZSB1c2VyJ3MgY29uZmlybWF0aW9uLlxuICAgICAqIEBwYXJhbSBjb250ZW50IHRoZSBtb2RhbCBjb250ZW50XG4gICAgICovXG4gICAgb3BlbkNsZWFuVXBNb2RhbChjb250ZW50OiBhbnkpIHtcbiAgICAgICAgdGhpcy5tb2RhbFNlcnZpY2Uub3Blbihjb250ZW50KS5yZXN1bHQudGhlbigocmVzdWx0OiBzdHJpbmcpID0+IHtcbiAgICAgICAgICAgIGlmIChyZXN1bHQgPT09ICdjb25maXJtJykge1xuICAgICAgICAgICAgICAgIHRoaXMuY2xlYW5VcFBsYWdpYXJpc20oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInBsYWdpYXJpc20taW5zcGVjdG9yXCI+XG4gICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20taGVhZGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLWhlYWRlci10b3BcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLWhlYWRlci10b3AtbGVmdFwiPlxuICAgICAgICAgICAgICAgIDxoNCBjbGFzcz1cInBsYWdpYXJpc20tcGFnZS10aXRsZSBmdy1tZWRpdW1cIiAoY2xpY2spPVwic2hvd09wdGlvbnMgPSAhc2hvd09wdGlvbnNcIiBbY2xhc3MuYWN0aXZlXT1cInNob3dPcHRpb25zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIGNsYXNzPVwicGxhZ2lhcmlzbS1vcHRpb25zLXRvZ2dsZVwiIFtpY29uXT1cImZhQ2hldnJvblJpZ2h0XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLnBsYWdpYXJpc21EZXRlY3Rpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLXdhcm5pbmdcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFFeGNsYW1hdGlvblRyaWFuZ2xlXCIgaWQ9XCJwbGFnaWFyaXNtQ2F1dGlvblwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgJ2FydGVtaXNBcHAucGxhZ2lhcmlzbS5jYXV0aW9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLWhlYWRlci10b3AtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICBAaWYgKGNoYXJ0RmlsdGVyQXBwbGllZCkge1xuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiY2hlY2stcGxhZ2lhcmlzbSBidG4gYnRuLWluZm9cIiAoY2xpY2spPVwicmVzZXRGaWx0ZXIoKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgJ2FydGVtaXNBcHAucGxhZ2lhcmlzbS5yZXNldEZpbHRlcicgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBbamhpRmVhdHVyZVRvZ2dsZV09XCJGZWF0dXJlVG9nZ2xlLlBsYWdpYXJpc21DaGVja3NcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImNoZWNrLXBsYWdpYXJpc20gYnRuIGJ0bi1wcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cImNoZWNrUGxhZ2lhcmlzbSgpXCJcbiAgICAgICAgICAgICAgICAgICAgW292ZXJ3cml0ZURpc2FibGVkXT1cImRldGVjdGlvbkluUHJvZ3Jlc3NcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgcGxhZ2lhcmlzbVJlc3VsdCA/ICgnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLnJlcnVuJyB8IGFydGVtaXNUcmFuc2xhdGUpIDogKCdhcnRlbWlzQXBwLnBsYWdpYXJpc20uZGV0ZWN0JyB8IGFydGVtaXNUcmFuc2xhdGUpIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSAjdG9nZ2xlRGVsZXRlTW9kYWwgbGV0LW1vZGFsPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtaGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3M9XCJtb2RhbC10aXRsZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucGxhZ2lhcmlzbS5jbGVhblVwLmNvbmZpcm1EaWFsb2cudGl0bGVcIj5DbGVhbiB1cCBwbGFnaWFyaXNtIHJlc3VsdHM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tY2xvc2VcIiBhcmlhLWxhYmVsPVwiQ2xvc2VcIiAoY2xpY2spPVwibW9kYWwuZGlzbWlzcygpXCI+PC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtYm9keVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLmNsZWFuVXAuY29uZmlybURpYWxvZy5xdWVzdGlvblwiPkFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgdGhlIHBsYWdpYXJpc20gY29tcGFyaXNvbnM/PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tY2hlY2sgZmxleC1ncm93LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkZWxldGVBbGxQbGFnaWFyaXNtQ29tcGFyaXNvbnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY2hlY2staW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2hlY2tlZF09XCJkZWxldGVBbGxQbGFnaWFyaXNtQ29tcGFyaXNvbnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2hhbmdlKT1cInRvZ2dsZURlbGV0ZUFsbFBsYWdpYXJpc21Db21wYXJpc29ucygpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJkZWxldGVBbGxQbGFnaWFyaXNtQ29tcGFyaXNvbnNcIiBjbGFzcz1cImZvcm0tY2hlY2stbGFiZWxcIj57e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLmNsZWFuVXAuY29uZmlybURpYWxvZy5kZWxldGVBbGwnIHwgYXJ0ZW1pc1RyYW5zbGF0ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChkZWxldGVBbGxQbGFnaWFyaXNtQ29tcGFyaXNvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnBsYWdpYXJpc20uY2xlYW5VcC5jb25maXJtRGlhbG9nLndhcm5pbmdcIiBjbGFzcz1cInRleHQtd2FybmluZ1wiPjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1mb290ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuIGJ0bi1kYW5nZXJcIiAoY2xpY2spPVwibW9kYWwuY2xvc2UoJ2NvbmZpcm0nKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucGxhZ2lhcmlzbS5jbGVhblVwLmNvbmZpcm1EaWFsb2cuc3VibWl0XCI+Q2xlYW4gdXA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICBAaWYgKGV4ZXJjaXNlLmlzQXRMZWFzdEluc3RydWN0b3IgJiYgcGxhZ2lhcmlzbVJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBbamhpRmVhdHVyZVRvZ2dsZV09XCJGZWF0dXJlVG9nZ2xlLlBsYWdpYXJpc21DaGVja3NcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJjaGVjay1wbGFnaWFyaXNtIGJ0biBidG4tZGFuZ2VyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJvcGVuQ2xlYW5VcE1vZGFsKHRvZ2dsZURlbGV0ZU1vZGFsKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbb3ZlcndyaXRlRGlzYWJsZWRdPVwiZGV0ZWN0aW9uSW5Qcm9ncmVzc1wiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucGxhZ2lhcmlzbS5jbGVhblVwLmNvbmZpcm1EaWFsb2cuc3VibWl0XCI+Q2xlYW4gdXA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKHBsYWdpYXJpc21SZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBuZ2JEcm9wZG93bj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tYmxvY2tcIiBpZD1cImRvd25sb2FkLXBsYWdpYXJpc21cIiBuZ2JEcm9wZG93blRvZ2dsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Eb3dubG9hZDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBuZ2JEcm9wZG93bk1lbnUgYXJpYS1sYWJlbGxlZGJ5PVwiZG93bmxvYWQtcGxhZ2lhcmlzbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIChjbGljayk9XCJkb3dubG9hZFBsYWdpYXJpc21SZXN1bHRzSnNvbigpXCIgbmdiRHJvcGRvd25JdGVtPkpTT048L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiAoY2xpY2spPVwiZG93bmxvYWRQbGFnaWFyaXNtUmVzdWx0c0NzdigpXCIgbmdiRHJvcGRvd25JdGVtPkNTVjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20taGVhZGVyLW9wdGlvbnNcIiBbaGlkZGVuXT1cIiFzaG93T3B0aW9uc1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tb3B0aW9uXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tb3B0aW9uLWxhYmVsXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLnNpbWlsYXJpdHlUaHJlc2hvbGRcIj5TaW1pbGFyaXR5IFRocmVzaG9sZDwvZGl2PlxuICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhUXVlc3Rpb25DaXJjbGVcIiBwbGFjZW1lbnQ9XCJib3R0b20gYXV0b1wiIFtuZ2JUb29sdGlwXT1cIidhcnRlbWlzQXBwLnBsYWdpYXJpc20uc2ltaWxhcml0eVRocmVzaG9sZFRvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIHJlcXVpcmVkIGNsYXNzPVwiZm9ybS1jb250cm9sXCIgbWluPVwiMFwiIG1heD1cIjEwMFwiIHN0ZXA9XCI1XCIgaWQ9XCJwbGFnaWFyaXNtLXNpbWlsYXJpdHktdGhyZXNob2xkXCIgWyhuZ01vZGVsKV09XCJzaW1pbGFyaXR5VGhyZXNob2xkXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tb3B0aW9uXCIgW2NsYXNzLmRpc2FibGVkXT1cIiFlbmFibGVNaW5pbXVtU2NvcmVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1jaGVja2JveCBmb3JtLWNoZWNrXCIgZm9yPVwiZW5hYmxlTWluaW11bVNjb3JlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBpZD1cImVuYWJsZU1pbmltdW1TY29yZVwiIGNsYXNzPVwicGxhZ2lhcmlzbS1vcHRpb24tY2hlY2tib3ggZm9ybS1jaGVjay1pbnB1dFwiIFsobmdNb2RlbCldPVwiZW5hYmxlTWluaW11bVNjb3JlXCIgY2hlY2tlZCAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1vcHRpb24tbGFiZWwgZm9ybS1jaGVjay1sYWJlbFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucGxhZ2lhcmlzbS5taW5pbXVtU2NvcmVcIj5NaW5pbXVtIFNjb3JlPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFRdWVzdGlvbkNpcmNsZVwiIHBsYWNlbWVudD1cImJvdHRvbSBhdXRvXCIgW25nYlRvb2x0aXBdPVwiJ2FydGVtaXNBcHAucGxhZ2lhcmlzbS5taW5pbXVtU2NvcmVUb29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgPGlucHV0IHJlcXVpcmVkIHR5cGU9XCJudW1iZXJcIiBbZGlzYWJsZWRdPVwiIWVuYWJsZU1pbmltdW1TY29yZVwiIGNsYXNzPVwiZm9ybS1jb250cm9sXCIgbWluPVwiMFwiIG1heD1cIjEwMFwiIGlkPVwicGxhZ2lhcmlzbS1taW5pbXVtLXNjb3JlXCIgWyhuZ01vZGVsKV09XCJtaW5pbXVtU2NvcmVcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicGxhZ2lhcmlzbS1vcHRpb25cIiBbY2xhc3MuZGlzYWJsZWRdPVwiIWVuYWJsZU1pbmltdW1TaXplXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tY2hlY2tib3ggZm9ybS1jaGVja1wiIGZvcj1cImVuYWJsZU1pbmltdW1TaXplXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBpZD1cImVuYWJsZU1pbmltdW1TaXplXCIgY2xhc3M9XCJwbGFnaWFyaXNtLW9wdGlvbi1jaGVja2JveCBmb3JtLWNoZWNrLWlucHV0XCIgWyhuZ01vZGVsKV09XCJlbmFibGVNaW5pbXVtU2l6ZVwiIGNoZWNrZWQgLz5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cImVuYWJsZU1pbmltdW1TaXplXCIgY2xhc3M9XCJwbGFnaWFyaXNtLW9wdGlvbi1sYWJlbCBmb3JtLWNoZWNrLWxhYmVsXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLm1pbmltdW1TaXplXCI+TWluaW11bSBTaXplPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVF1ZXN0aW9uQ2lyY2xlXCIgcGxhY2VtZW50PVwiYm90dG9tIGF1dG9cIiBbbmdiVG9vbHRpcF09XCJnZXRNaW5pbXVtU2l6ZVRvb2x0aXAoKSB8IGFydGVtaXNUcmFuc2xhdGVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgPGlucHV0IHJlcXVpcmVkIHR5cGU9XCJudW1iZXJcIiBbZGlzYWJsZWRdPVwiIWVuYWJsZU1pbmltdW1TaXplXCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiBtaW49XCIwXCIgbWF4PVwiMTAwXCIgaWQ9XCJwbGFnaWFyaXNtLW1pbmltdW0tc2l6ZVwiIFsobmdNb2RlbCldPVwibWluaW11bVNpemVcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICBAaWYgKGlzUHJvZ3JhbW1pbmdFeGVyY2lzZSgpKSB7XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tY2hlY2tib3ggZm9ybS1jaGVja1wiIGZvcj1cImdlbmVyYXRlSlBsYWdSZXBvcnRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IGNsYXNzPVwiZm9ybS1jaGVjay1pbnB1dFwiIHR5cGU9XCJjaGVja2JveFwiIGlkPVwiZ2VuZXJhdGVKUGxhZ1JlcG9ydFwiIFsobmdNb2RlbCldPVwiZ2VuZXJhdGVKUGxhZ1JlcG9ydFwiIGNoZWNrZWQgLz5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cImdlbmVyYXRlSlBsYWdSZXBvcnRcIiBjbGFzcz1cInBsYWdpYXJpc20tb3B0aW9uLWxhYmVsXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLmdlbmVyYXRlSnBsYWdSZXBvcnRcIj5HZW5lcmF0ZSBKUGxhZyBSZXBvcnQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICBAaWYgKHBsYWdpYXJpc21SZXN1bHQgJiYgIWRldGVjdGlvbkluUHJvZ3Jlc3MpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cInBsYWdpYXJpc20tYm9keVwiPlxuICAgICAgICAgICAgPGpoaS1wbGFnaWFyaXNtLXNpZGViYXJcbiAgICAgICAgICAgICAgICBbc2hvd1J1bkRldGFpbHNdPVwic2hvd1J1bkRldGFpbHNcIlxuICAgICAgICAgICAgICAgIChzaG93UnVuRGV0YWlsc0NoYW5nZSk9XCJzaG93U2ltaWxhcml0eURpc3RyaWJ1dGlvbigkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICBbY29tcGFyaXNvbnNdPVwidmlzaWJsZUNvbXBhcmlzb25zXCJcbiAgICAgICAgICAgICAgICBbb2Zmc2V0XT1cInNpZGViYXJPZmZzZXRcIlxuICAgICAgICAgICAgICAgIChzZWxlY3RJbmRleCk9XCJzZWxlY3RDb21wYXJpc29uV2l0aElEKCRldmVudClcIlxuICAgICAgICAgICAgICAgIFthY3RpdmVJRF09XCJzZWxlY3RlZENvbXBhcmlzb25JZFwiXG4gICAgICAgICAgICAgICAgW2Nhc2VzRmlsdGVyZWRdPVwiY2hhcnRGaWx0ZXJBcHBsaWVkXCJcbiAgICAgICAgICAgID48L2poaS1wbGFnaWFyaXNtLXNpZGViYXI+XG4gICAgICAgICAgICA8amhpLXBsYWdpYXJpc20tZGV0YWlsc1xuICAgICAgICAgICAgICAgIFtoaWRkZW5dPVwic2hvd1J1bkRldGFpbHNcIlxuICAgICAgICAgICAgICAgIFtjb21wYXJpc29uXT1cInBsYWdpYXJpc21SZXN1bHQuY29tcGFyaXNvbnMgPyBnZXRTZWxlY3RlZENvbXBhcmlzb24oKSA6IHVuZGVmaW5lZFwiXG4gICAgICAgICAgICAgICAgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCJcbiAgICAgICAgICAgID48L2poaS1wbGFnaWFyaXNtLWRldGFpbHM+XG4gICAgICAgICAgICA8amhpLXBsYWdpYXJpc20tcnVuLWRldGFpbHNcbiAgICAgICAgICAgICAgICBbaGlkZGVuXT1cIiFzaG93UnVuRGV0YWlsc1wiXG4gICAgICAgICAgICAgICAgW3BsYWdpYXJpc21SZXN1bHRdPVwicGxhZ2lhcmlzbVJlc3VsdFwiXG4gICAgICAgICAgICAgICAgW3BsYWdpYXJpc21SZXN1bHRTdGF0c109XCJwbGFnaWFyaXNtUmVzdWx0U3RhdHNcIlxuICAgICAgICAgICAgICAgIChzaW1pbGFyaXR5U2VsZWN0ZWQpPVwiZmlsdGVyQnlDaGFydCgkZXZlbnQpXCJcbiAgICAgICAgICAgID48L2poaS1wbGFnaWFyaXNtLXJ1bi1kZXRhaWxzPlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmICghcGxhZ2lhcmlzbVJlc3VsdCB8fCBkZXRlY3Rpb25JblByb2dyZXNzKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJwbGFnaWFyaXNtLWVtcHR5XCI+XG4gICAgICAgICAgICBAaWYgKGRldGVjdGlvbkluUHJvZ3Jlc3MpIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGZsZXgtY29sdW1uXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyLWJvcmRlciB0ZXh0LXByaW1hcnkgYWxpZ24tc2VsZi1jZW50ZXIgbWItMVwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwic3Itb25seVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwPnt7IGRldGVjdGlvbkluUHJvZ3Jlc3NNZXNzYWdlIH19PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmICghZGV0ZWN0aW9uSW5Qcm9ncmVzcykge1xuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwicGxhZ2lhcmlzbS1lbXB0eS1sYWJlbFwiPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5wbGFnaWFyaXNtLmVtcHR5JyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbjwvZGl2PlxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLFlBQVksa0JBQWdDOzs7QUFEckQsSUFnQmE7QUFoQmI7O0FBZ0JNLElBQU8seUJBQVAsTUFBTyx3QkFBc0I7TUFJWDtNQUhaLGNBQWM7TUFDZCx1QkFBdUI7TUFFL0IsWUFBb0IsTUFBZ0I7QUFBaEIsYUFBQSxPQUFBO01BQW1CO01BUWhDLHNDQUFzQyxVQUFnQjtBQUN6RCxlQUFPLEtBQUssS0FBSyxJQUFzQixHQUFHLEtBQUssV0FBVyxJQUFJLFFBQVEsb0NBQW9DLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDckk7TUFPTyxvQ0FBb0MsVUFBa0IsUUFBYztBQUN2RSxlQUFPLEtBQUssS0FBSyxJQUFzQixHQUFHLEtBQUssV0FBVyxJQUFJLFFBQVEsVUFBVSxNQUFNLG9DQUFvQyxFQUFFLFNBQVMsV0FBVSxDQUFFO01BQ3JKO01BT08scUNBQXFDLFVBQWtCLGtCQUF3QjtBQUNsRixlQUFPLEtBQUssS0FBSyxJQUFvQixHQUFHLEtBQUssV0FBVyxJQUFJLFFBQVEscUJBQXFCLGdCQUFnQixtQkFBbUIsRUFBRSxTQUFTLFdBQVUsQ0FBRTtNQUN2SjtNQVFPLFlBQ0gsVUFDQSxrQkFDQSxtQkFBMEc7QUFFMUcsZUFBTyxLQUFLLEtBQUssSUFBb0IsR0FBRyxLQUFLLFdBQVcsSUFBSSxRQUFRLHFCQUFxQixnQkFBZ0IsWUFBWSxtQkFBbUIsRUFBRSxTQUFTLFdBQVUsQ0FBRTtNQUNuSztNQVNPLGdDQUFnQyxVQUFrQixZQUFrQjtBQUN2RSxlQUFPLEtBQUssS0FBSyxJQUF3QixHQUFHLEtBQUssV0FBVyxJQUFJLFFBQVEsY0FBYyxVQUFVLG9CQUFvQixFQUFFLFNBQVMsV0FBVSxDQUFFO01BQy9JO01BT08saUNBQWlDLFVBQWtCLGFBQXFCO0FBQzNFLFlBQUksU0FBUyxJQUFJLFdBQVU7QUFDM0IsbUJBQVcsY0FBYyxhQUFhO0FBQ2xDLG1CQUFTLE9BQU8sT0FBTyxjQUFjLFVBQVU7O0FBRW5ELGVBQU8sS0FBSyxLQUFLLElBQTBCLEdBQUcsS0FBSyxXQUFXLElBQUksUUFBUSxxQkFBcUIsRUFBRSxRQUFRLFNBQVMsV0FBVSxDQUFFO01BQ2xJO01BT08sa0NBQWtDLFVBQWtCLGtCQUF3QjtBQUMvRSxlQUFPLEtBQUssS0FBSyxJQUFvQixHQUFHLEtBQUssV0FBVyxJQUFJLFFBQVEscUJBQXFCLGdCQUFnQixnQkFBZ0IsRUFBRSxTQUFTLFdBQVUsQ0FBRTtNQUNwSjtNQU9PLG9DQUFvQyxVQUFrQix3QkFBOEI7QUFDdkYsZUFBTyxLQUFLLEtBQUssSUFBZ0IsR0FBRyxLQUFLLFdBQVcsSUFBSSxRQUFRLDJCQUEyQixzQkFBc0IsbUJBQW1CO1VBQ2hJLFNBQVM7U0FDWjtNQUNMO01BUU8saUNBQWlDLFVBQWtCLHdCQUFnQyxRQUF3QjtBQUM5RyxlQUFPLEtBQUssS0FBSyxJQUFVLEdBQUcsS0FBSyxXQUFXLElBQUksUUFBUSwyQkFBMkIsc0JBQXNCLFdBQVcsRUFBRSxPQUFNLEdBQUksRUFBRSxTQUFTLFdBQVUsQ0FBRTtNQUM3SjtNQVdPLGtCQUFrQixZQUFvQixvQkFBNEIsWUFBWSxPQUFLO0FBQ3RGLGNBQU0sU0FBUyxJQUFJLFdBQVUsRUFBRyxPQUFPLGFBQWEsWUFBWSxTQUFTLE9BQU87QUFDaEYsZUFBTyxLQUFLLEtBQUssT0FBYSxHQUFHLEtBQUssb0JBQW9CLElBQUksVUFBVSx1QkFBdUIsa0JBQWtCLDJCQUEyQjtVQUN4STtVQUNBLFNBQVM7U0FDWjtNQUNMO01BQ08sc0NBQXNDLFVBQWtCO0FBQzNELFlBQUk7QUFDSixZQUFJLFNBQVMsZUFBZTtBQUN4QixxQkFBVyxTQUFTLGNBQWMsS0FBTSxPQUFRO2VBQzdDO0FBQ0gscUJBQVcsU0FBUyxPQUFROztBQUVoQyxjQUFNLGFBQWEsU0FBVTtBQUM3QixlQUFPLEtBQUssS0FBSyxJQUFZLEdBQUcsS0FBSyxXQUFXLElBQUksUUFBUSxjQUFjLFVBQVUseUJBQXlCO01BQ2pIOzt5QkEvSFMseUJBQXNCLHNCQUFBLGFBQUEsQ0FBQTtNQUFBO21FQUF0Qix5QkFBc0IsU0FBdEIsd0JBQXNCLFdBQUEsWUFEVCxPQUFNLENBQUE7Ozs7OztBQ2ZoQyxTQUFTLGNBQUFBLG1CQUFrQjtBQUMzQixTQUFTLGNBQUFDLG1CQUFnQztBQUV6QyxTQUFTLEtBQUssV0FBVzs7O0FBSHpCLElBZ0JhO0FBaEJiOztBQUtBO0FBQ0E7QUFHQTs7QUFPTSxJQUFPLDBCQUFQLE1BQU8seUJBQXVCO01BS3BCO01BQ0E7TUFMTCxjQUFjO01BQ2QsbUJBQW1CO01BRTFCLFlBQ1ksTUFDQSxpQkFBZ0M7QUFEaEMsYUFBQSxPQUFBO0FBQ0EsYUFBQSxrQkFBQTtBQUVSLGFBQUssa0JBQWtCO01BQzNCO01BRUEsT0FBTyxrQkFBa0M7QUFDckMsWUFBSSxPQUFPLGdCQUFnQiwrQkFBK0IsZ0JBQWdCO0FBQzFFLGVBQU8sZ0JBQWdCLGtEQUFrRCxJQUFJO0FBQzdFLGFBQUssYUFBYSxnQkFBZ0IsNEJBQTRCLElBQUk7QUFDbEUsZUFBTyxLQUFLLEtBQ1AsS0FBdUIsS0FBSyxhQUFhLE1BQU0sRUFBRSxTQUFTLFdBQVUsQ0FBRSxFQUN0RSxLQUFLLElBQUksQ0FBQyxRQUE0QixLQUFLLGdCQUFnQiw4QkFBOEIsR0FBRyxDQUFDLENBQUM7TUFDdkc7TUFFQSxPQUFPLGtCQUFvQyxLQUFTO0FBQ2hELGNBQU0sVUFBVSxvQkFBb0IsR0FBRztBQUN2QyxZQUFJLE9BQU8sZ0JBQWdCLCtCQUErQixnQkFBZ0I7QUFDMUUsZUFBTyxnQkFBZ0Isa0RBQWtELElBQUk7QUFDN0UsYUFBSyxhQUFhLGdCQUFnQiw0QkFBNEIsSUFBSTtBQUNsRSxlQUFPLEtBQUssS0FDUCxJQUFzQixLQUFLLGFBQWEsTUFBTSxFQUFFLFFBQVEsU0FBUyxTQUFTLFdBQVUsQ0FBRSxFQUN0RixLQUFLLElBQUksQ0FBQyxRQUE0QixLQUFLLGdCQUFnQiw4QkFBOEIsR0FBRyxDQUFDLENBQUM7TUFDdkc7TUFFQSxLQUFLLG9CQUE0QixnQ0FBeUMsT0FBSztBQUMzRSxlQUFPLEtBQUssS0FDUCxJQUFzQixHQUFHLEtBQUssV0FBVyxJQUFJLGtCQUFrQixJQUFJLEVBQUUsU0FBUyxZQUFZLFFBQVEsRUFBRSw4QkFBNEQsRUFBRSxDQUFFLEVBQ3BLLEtBQUssSUFBSSxDQUFDLFFBQTRCLEtBQUssZ0JBQWdCLDhCQUE4QixHQUFHLENBQUMsQ0FBQztNQUN2RztNQUVBLE9BQU8sb0JBQTBCO0FBQzdCLGVBQU8sS0FBSyxLQUFLLE9BQU8sR0FBRyxLQUFLLFdBQVcsSUFBSSxrQkFBa0IsSUFBSSxFQUFFLFNBQVMsV0FBVSxDQUFFO01BQ2hHO01BU0EsT0FBTywrQkFBK0M7QUFDbEQsWUFBSSxPQUFPLGdCQUFnQiwrQkFBK0IsNkJBQTZCO0FBQ3ZGLGVBQU8sZ0JBQWdCLGtEQUFrRCxJQUFJO0FBQzdFLGFBQUssYUFBYSxnQkFBZ0IsNEJBQTRCLElBQUk7QUFDbEUsZUFBTyxLQUFLLEtBQ1AsS0FBdUIsR0FBRyxLQUFLLFdBQVcsV0FBVyw4QkFBOEIsRUFBRSxJQUFJLE1BQU0sRUFBRSxTQUFTLFdBQVUsQ0FBRSxFQUN0SCxLQUFLLElBQUksQ0FBQyxRQUE0QixLQUFLLGdCQUFnQiw4QkFBOEIsR0FBRyxDQUFDLENBQUM7TUFDdkc7TUFPQSxnQkFBZ0IsWUFBb0IsU0FBMkI7QUFDM0QsZUFBTyxLQUFLLEtBQ1AsSUFBbUQsR0FBRyxLQUFLLFdBQVcsSUFBSSxVQUFVLHFCQUFxQixFQUFFLFNBQVMsWUFBWSxRQUFRLG1CQUFLLFNBQVMsU0FBUSxHQUFJLENBQUUsRUFDcEssS0FBSyxJQUFJLENBQUMsYUFBMEUsU0FBUyxJQUFLLENBQUM7TUFDNUc7TUFFQSxhQUFhLE9BQWUsVUFBZ0I7QUFDeEMsZUFBTyxLQUFLLEtBQ1AsS0FBSyw4QkFBOEIsRUFBRSxNQUFLLEdBQUksRUFBRSxTQUFTLFlBQVksY0FBYyxPQUFNLENBQUUsRUFDM0YsS0FBSyxJQUFJLENBQUMsYUFBaUMsZUFBZSxTQUFTLE1BQU0sbUJBQW1CLFFBQVEsQ0FBQyxDQUFDO01BQy9HO01BT0EsMEJBQTBCLFlBQWtCO0FBQ3hDLGVBQU8sS0FBSyxLQUNQLElBQW1ELEdBQUcsS0FBSyxXQUFXLElBQUksVUFBVSxzQkFBc0I7VUFDdkcsU0FBUztTQUNaLEVBQ0EsS0FBSyxJQUFJLENBQUMsYUFBMEUsU0FBUyxJQUFLLENBQUM7TUFDNUc7TUFPQSxvQkFBb0IsWUFBa0I7QUFDbEMsZUFBTyxLQUFLLEtBQUssSUFBWSxHQUFHLEtBQUssZ0JBQWdCLElBQUksVUFBVSxtQkFBbUI7VUFDbEYsU0FBUztTQUNaO01BQ0w7TUFNQSxjQUFjLG9CQUEwQjtBQUNwQyxlQUFPLEtBQUssS0FBSyxLQUFLLEdBQUcsS0FBSyxnQkFBZ0IsSUFBSSxrQkFBa0IsaUNBQWlDLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDaEk7TUFNQSxlQUFlLG9CQUEwQjtBQUNyQyxlQUFPLEtBQUssS0FBSyxPQUFhLEdBQUcsS0FBSyxnQkFBZ0IsSUFBSSxrQkFBa0IsYUFBYSxFQUFFLFNBQVMsV0FBVSxDQUFFO01BQ3BIO01BUUEsb0JBQW9CLGtCQUFvQyxLQUFTO0FBQzdELGNBQU0sVUFBVSxvQkFBb0IsR0FBRztBQUN2QyxZQUFJLE9BQU8sZ0JBQWdCLCtCQUErQixnQkFBZ0I7QUFDMUUsZUFBTyxnQkFBZ0Isa0RBQWtELElBQUk7QUFDN0UsYUFBSyxhQUFhLGdCQUFnQiw0QkFBNEIsSUFBSTtBQUNsRSxlQUFPLEtBQUssS0FDUCxJQUFzQixHQUFHLEtBQUssV0FBVyxJQUFJLGlCQUFpQixFQUFFLGdCQUFnQixNQUFNLEVBQUUsUUFBUSxTQUFTLFNBQVMsV0FBVSxDQUFFLEVBQzlILEtBQUssSUFBSSxDQUFDLFFBQTRCLEtBQUssZ0JBQWdCLDhCQUE4QixHQUFHLENBQUMsQ0FBQztNQUN2Rzs7eUJBL0hTLDBCQUF1Qix1QkFBQSxjQUFBLEdBQUEsdUJBQUEsZUFBQSxDQUFBO01BQUE7b0VBQXZCLDBCQUF1QixTQUF2Qix5QkFBdUIsV0FBQSxZQURWLE9BQU0sQ0FBQTs7Ozs7O0FDWmhDLElBQVk7QUFBWjs7QUFBQSxLQUFBLFNBQVlDLG1CQUFnQjtBQUl4QixNQUFBQSxrQkFBQSxXQUFBLElBQUE7QUFLQSxNQUFBQSxrQkFBQSxRQUFBLElBQUE7QUFLQSxNQUFBQSxrQkFBQSxNQUFBLElBQUE7SUFDSixHQWZZLHFCQUFBLG1CQUFnQixDQUFBLEVBQUE7Ozs7O0FDTTVCOzs7Ozs7QUNUQSxTQUFTLFdBQVcsYUFBYTtBQUNqQyxTQUFTLGVBQWU7QUFPeEIsU0FBUyxnQkFBZ0I7OztBQVJ6QixJQWdCYTtBQWhCYjs7QUFFQTtBQUNBO0FBR0E7QUFDQTtBQUVBOzs7QUFPTSxJQUFPLDRCQUFQLE1BQU8sMkJBQXlCO01BU3RCO01BQ0E7TUFUSDtNQUNBO01BQ0E7TUFFQSxtQkFBbUI7TUFDNUIsMkJBQTJCO01BRTNCLFlBQ1ksd0JBQ0EsY0FBc0I7QUFEdEIsYUFBQSx5QkFBQTtBQUNBLGFBQUEsZUFBQTtNQUNUO01BS0gsb0JBQWlCO0FBQ2IsYUFBSyx1QkFBdUIsaUJBQWlCLFNBQVM7TUFDMUQ7TUFLQSxpQkFBYztBQUNWLFlBQUksS0FBSyxXQUFXLFdBQVcsaUJBQWlCLFdBQVc7QUFDdkQsZUFBSyw0QkFBNEIsTUFBTSxLQUFLLHVCQUF1QixpQkFBaUIsTUFBTSxDQUFDO2VBQ3hGO0FBQ0gsZUFBSyx1QkFBdUIsaUJBQWlCLE1BQU07O01BRTNEO01BRVEsNEJBQTRCLFdBQXFCO0FBQ3JELGFBQUssMkJBQTJCO0FBRWhDLGNBQU0sV0FBVyxLQUFLLGFBQWEsS0FBSyxnQ0FBZ0MsRUFBRSxVQUFVLE1BQU0sTUFBTSxLQUFJLENBQUU7QUFDdEcsaUJBQVMsa0JBQWtCLFFBQVE7QUFDbkMsaUJBQVMsa0JBQWtCLE9BQU87QUFDbEMsaUJBQVMsa0JBQWtCLGdCQUFnQjtBQUMzQyxpQkFBUyxPQUFPLEtBQUssV0FBVyxNQUFPLEtBQUssMkJBQTJCLEtBQU07TUFDakY7TUFNQSx1QkFBdUIsUUFBd0I7QUFDM0MsYUFBSywyQkFBMkI7QUFFaEMsY0FBTSxhQUFhLEtBQUs7QUFDeEIsYUFBSyx1QkFBdUIsaUNBQWlDLFlBQVksS0FBSyxRQUFRLEdBQUksV0FBVyxJQUFJLE1BQU0sRUFBRSxVQUFVLE1BQUs7QUFDNUgscUJBQVcsU0FBUztBQUNwQixlQUFLLDJCQUEyQjtRQUNwQyxDQUFDO01BQ0w7TUFFQSxnQkFBZ0IsTUFBc0I7QUFDbEMsYUFBSyxvQkFBb0IsS0FBSyxJQUFJO01BQ3RDO01BRUEsa0JBQWU7QUFDWCxhQUFLLG9CQUFvQixLQUFLLE1BQU07TUFDeEM7O3lCQTdEUyw0QkFBeUIsZ0NBQUEsc0JBQUEsR0FBQSxnQ0FBQSxXQUFBLENBQUE7TUFBQTtpRUFBekIsNEJBQXlCLFdBQUEsQ0FBQSxDQUFBLHVCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsWUFBQSxjQUFBLFVBQUEsWUFBQSxxQkFBQSxzQkFBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSx3QkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLHlCQUFBLEdBQUEsQ0FBQSxXQUFBLDZCQUFBLEdBQUEsT0FBQSxlQUFBLFVBQUEsR0FBQSxZQUFBLE9BQUEsR0FBQSxDQUFBLFdBQUEsMEJBQUEsR0FBQSxPQUFBLGNBQUEsVUFBQSxHQUFBLFlBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsV0FBQSxtQkFBQSxHQUFBLGlCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsU0FBQSxNQUFBLFVBQUEsTUFBQSxXQUFBLGFBQUEsU0FBQSw0QkFBQSxHQUFBLENBQUEsS0FBQSwrRUFBQSxRQUFBLFNBQUEsR0FBQSxDQUFBLEtBQUEsbUZBQUEsUUFBQSxTQUFBLEdBQUEsQ0FBQSxXQUFBLG1CQUFBLEdBQUEsaUJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxLQUFBLCtFQUFBLFFBQUEsU0FBQSxHQUFBLENBQUEsS0FBQSxtRkFBQSxRQUFBLFNBQUEsR0FBQSxDQUFBLFdBQUEsb0JBQUEsR0FBQSxpQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEtBQUEsK0ZBQUEsUUFBQSxTQUFBLEdBQUEsQ0FBQSxLQUFBLHNGQUFBLFFBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLG1DQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDaEJ0QyxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxDQUFBOzs7QUFFSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBRUEsVUFBQSxxQkFBQSxHQUFBLFVBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsVUFBQSxDQUFBO0FBR0ksVUFBQSx5QkFBQSxTQUFBLFNBQUEsOERBQUE7QUFBQSxtQkFBUyxJQUFBLGtCQUFBO1VBQW1CLENBQUE7QUFHNUIsVUFBQSxxQkFBQSxFQUFBOztBQUNKLFVBQUEsMkJBQUE7QUFFQSxVQUFBLHFCQUFBLElBQUEsY0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxVQUFBLENBQUE7QUFHSSxVQUFBLHlCQUFBLFNBQUEsU0FBQSw4REFBQTtBQUFBLG1CQUFTLElBQUEsZUFBQTtVQUFnQixDQUFBO0FBR3pCLFVBQUEscUJBQUEsRUFBQTs7QUFDSixVQUFBLDJCQUFBO0FBRUEsVUFBQSxxQkFBQSxJQUFBLGNBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsT0FBQSxDQUFBO0FBRUEsVUFBQSxxQkFBQSxJQUFBLGNBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUEyQixVQUFBLHlCQUFBLFNBQUEsU0FBQSwyREFBQTtBQUFBLG1CQUFTLElBQUEsZ0JBQWdCLE1BQU07VUFBQyxDQUFBO0FBQ3ZELFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNkJBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxRQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQTJCLFVBQUEseUJBQUEsU0FBQSxTQUFBLDJEQUFBO0FBQUEsbUJBQVMsSUFBQSxnQkFBQTtVQUFpQixDQUFBO0FBQ2pELFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNkJBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxRQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQTJCLFVBQUEseUJBQUEsU0FBQSxTQUFBLDJEQUFBO0FBQUEsbUJBQVMsSUFBQSxnQkFBZ0IsT0FBTztVQUFDLENBQUE7QUFDeEQsVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsUUFBQSxFQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQWhEWSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLGtCQUFBLElBQUEsV0FBQSxZQUFBLGdCQUFBLDBCQUFBLEdBQUEsR0FBQSxzQ0FBQSxHQUFBLG1CQUFBLElBQUEsV0FBQSxZQUFBLGdCQUFBLDBCQUFBLEdBQUEsR0FBQSxzQ0FBQSxHQUFBLFlBQUE7QUFPQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFlBQUEsSUFBQSxXQUFBLFdBQUEsSUFBQSxpQkFBQSxhQUFBLElBQUEsd0JBQUE7QUFLQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLGtCQUFBLDBCQUFBLElBQUEsSUFBQSwrQkFBQSxHQUFBLFlBQUE7QUFJQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFlBQUEsSUFBQSxXQUFBLFdBQUEsSUFBQSxpQkFBQSxVQUFBLElBQUEsd0JBQUE7QUFLQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLGtCQUFBLDBCQUFBLElBQUEsSUFBQSw0QkFBQSxHQUFBLFlBQUE7Ozs7O3FGRFJDLDJCQUF5QixFQUFBLFdBQUEsNEJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFaEJ0QyxTQUFTLGFBQUFDLFlBQVcsY0FBYyxTQUFBQyxRQUFrQixjQUE2QjtBQUNqRixTQUFTLHFCQUFxQjs7Ozs7OztBQ0VsQixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFBOEMsSUFBQSxxQkFBQSxDQUFBO0FBQXFCLElBQUEsMkJBQUE7QUFDdkUsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxZQUFBOzs7O0FBSHlDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLGFBQUE7QUFDYSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLE9BQUEsY0FBQSxDQUFBOzs7Ozs7QUFROUMsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUFtRCxJQUFBLHlCQUFBLFNBQUEsU0FBQSw2RUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLFlBQUE7QUFBQSxZQUFBLFNBQUEsWUFBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxPQUFBLGlCQUFBLFNBQUEsTUFBQSxDQUEyQjtJQUFBLENBQUE7QUFDbkYsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBZ0UsSUFBQSxxQkFBQSxDQUFBO0FBQWUsSUFBQSwyQkFBQTtBQUNuRixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBRmMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxxQ0FBQSxRQUFBLFFBQUE7QUFBMEQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxRQUFBLElBQUE7Ozs7O0FBSXBFLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxxQkFBQSxDQUFBOztBQUE2RCxJQUFBLDJCQUFBO0FBQ3JFLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7O0FBRFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsb0NBQUEsQ0FBQTs7Ozs7QUFQWixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEsd0RBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQUtBLElBQUEseUJBQUEsR0FBQSxnRUFBQSxHQUFBLENBQUE7QUFHSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7QUFUUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsS0FBQTtBQUtBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxDQUFBLE9BQUEsU0FBQSxJQUFBLElBQUEsRUFBQTs7O0FEakJaLFNBZ0JhO0FBaEJiOzs7O0FBZ0JNLElBQU8sMkJBQVAsTUFBTywwQkFBd0I7TUFDeEI7TUFDQTtNQUNDLGFBQWEsSUFBSSxhQUFZO01BRWhDLFlBQVk7TUFDWixrQkFBa0I7TUFHekIsZ0JBQWdCO01BRWhCLFlBQVksU0FBc0I7QUFDOUIsWUFBSSxRQUFRLE9BQU87QUFDZixnQkFBTSxRQUEwQixRQUFRLE1BQU07QUFFOUMsZUFBSyxrQkFBa0I7QUFFdkIsY0FBSSxLQUFLLFNBQVEsR0FBSTtBQUNqQixpQkFBSyxXQUFXLEtBQUssTUFBTSxDQUFDLEVBQUUsSUFBSTs7O01BRzlDO01BRUEsZ0JBQWE7QUFDVCxlQUFPLEtBQUssU0FBUSxLQUFNLEtBQUssa0JBQWtCLEtBQUssTUFBTTtNQUNoRTtNQUVBLGdCQUFhO0FBQ1QsZUFBTyxLQUFLLE1BQU0sS0FBSyxlQUFlLEVBQUU7TUFDNUM7TUFFQSxpQkFBaUIsTUFBd0IsS0FBVztBQUNoRCxhQUFLLGtCQUFrQjtBQUN2QixhQUFLLFlBQVk7QUFDakIsYUFBSyxXQUFXLEtBQUssS0FBSyxJQUFJO01BQ2xDO01BRUEsV0FBUTtBQUNKLGVBQU8sS0FBSyxTQUFTLEtBQUssTUFBTSxTQUFTO01BQzdDO01BRUEsa0JBQWU7QUFDWCxZQUFJLEtBQUssU0FBUSxHQUFJO0FBQ2pCLGVBQUssWUFBWSxDQUFDLEtBQUs7O01BRS9COzt5QkE3Q1MsMkJBQXdCO01BQUE7aUVBQXhCLDJCQUF3QixXQUFBLENBQUEsQ0FBQSx1QkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLE9BQUEsU0FBQSxjQUFBLGVBQUEsR0FBQSxTQUFBLEVBQUEsWUFBQSxhQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxlQUFBLElBQUEsR0FBQSxtQkFBQSxHQUFBLENBQUEsZUFBQSxZQUFBLEdBQUEseUJBQUEsR0FBQSxXQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsNkJBQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGlDQUFBLEdBQUEsQ0FBQSxHQUFBLHlCQUFBLEdBQUEsQ0FBQSxtQkFBQSxJQUFBLEdBQUEsMEJBQUEsR0FBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsa0NBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNoQnJDLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFBbUgsVUFBQSx5QkFBQSxTQUFBLFNBQUEseURBQUE7QUFBQSxtQkFBUyxJQUFBLGdCQUFBO1VBQWlCLENBQUE7QUFDekksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLEdBQUEsaURBQUEsR0FBQSxDQUFBO0FBTUEsVUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFBSyxVQUFBLHFCQUFBLENBQUE7O0FBQWlGLFVBQUEsMkJBQUE7QUFDMUYsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsa0RBQUEsR0FBQSxDQUFBO0FBWUosVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUF0QjhELFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsV0FBQSw4QkFBQSxHQUFBLEtBQUEsSUFBQSxXQUFBLElBQUEsU0FBQSxDQUFBLENBQUE7QUFDdEQsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsY0FBQSxJQUFBLElBQUEsRUFBQTtBQU1LLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsZ0NBQUEsSUFBQSxnQkFBQSwwQkFBQSxHQUFBLEdBQUEsc0NBQUEsQ0FBQTtBQUVULFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLFlBQUEsS0FBQSxFQUFBOzs7OztxRkRNUywwQkFBd0IsRUFBQSxXQUFBLDJCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVRyQzs7Ozs7O0FDUEEsU0FBUyxhQUFBQyxZQUFXLFNBQUFDLGNBQXVDOzs7O0FDRXZELElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLHVCQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsSUFBQTs7OztBQUR5QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsT0FBQSxlQUFBLEVBQTRCLGVBQUEsT0FBQSxTQUFBLFdBQUEsRUFBQSxZQUFBLElBQUE7Ozs7O0FBR2pELElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFBc0IsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBVSxJQUFBLDJCQUFBO0FBQ3BDLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxJQUFBOzs7QURWQSxJQWFhO0FBYmI7O0FBQ0E7QUFDQTtBQUVBOzs7O0FBU00sSUFBTyxvQ0FBUCxNQUFPLG1DQUFpQztNQU90QjtNQU5YO01BQ0E7TUFFRjtNQUNBO01BRVAsWUFBb0IsMkJBQW9EO0FBQXBELGFBQUEsNEJBQUE7TUFBdUQ7TUFFM0UsWUFBWSxTQUFzQjtBQUM5QixZQUFJLFFBQVEsc0JBQXNCO0FBQzlCLGVBQUssVUFBVTtBQUVmLGdCQUFNLDhCQUErRSxRQUFRLHFCQUFxQjtBQUVsSCxlQUFLLDBCQUEwQix5QkFBeUIsNEJBQTRCLFlBQVksRUFBRSxVQUFVO1lBQ3hHLE1BQU0sQ0FBQyxlQUFrQztBQUNyQyxtQkFBSyxVQUFVO0FBQ2YsbUJBQUssa0JBQWtCLEtBQUssTUFBTSxXQUFXLEtBQU07WUFDdkQ7WUFDQSxPQUFPLE1BQUs7QUFDUixtQkFBSyxVQUFVO1lBQ25CO1dBQ0g7O01BRVQ7O3lCQXpCUyxvQ0FBaUMsZ0NBQUEseUJBQUEsQ0FBQTtNQUFBO2lFQUFqQyxvQ0FBaUMsV0FBQSxDQUFBLENBQUEsZ0NBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsc0JBQUEsdUJBQUEsR0FBQSxVQUFBLENBQUEsa0NBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGVBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSw4QkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsa0JBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsMkNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNiOUMsVUFBQSx3QkFBQSxHQUFBLHlCQUFBLENBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSwwREFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLDBEQUFBLElBQUEsQ0FBQTs7O0FBSHNCLFVBQUEsb0NBQUEsZ0JBQUEsSUFBQSx3QkFBQSxPQUFBLE9BQUEsSUFBQSxxQkFBQSxZQUFBO0FBQ3ZCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxDQUFBLElBQUEsVUFBQSxJQUFBLEVBQUE7QUFHQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxVQUFBLElBQUEsRUFBQTs7Ozs7cUZEU2EsbUNBQWlDLEVBQUEsV0FBQSxvQ0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUViOUMsU0FBUyxhQUFBQyxZQUFXLFNBQUFDLFFBQWlDLHlCQUF5QjtBQVc5RSxTQUFTLGNBQWM7Ozs7O0FDVG5CLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLElBQUE7Ozs7QUFId0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLE9BQUEsZUFBQSxLQUFBLDRCQUFBLEVBQWdDLFdBQUEsOEJBQUEsR0FBQUMsTUFBQSxDQUFBLE9BQUEsYUFBQSxPQUFBLHFCQUFBLENBQUE7QUFDaEUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxjQUFBLDBCQUFBLEdBQUEsR0FBQSxzQ0FBQSxHQUFBLFFBQUE7Ozs7O0FBSUosSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUFzQixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFVLElBQUEsMkJBQUE7QUFDcEMsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLElBQUE7Ozs7OztBQUVJLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUFtQixJQUFBLHFCQUFBLENBQUE7O0FBQXNFLElBQUEsMkJBQUE7QUFDekYsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQXdCLElBQUEseUJBQUEsU0FBQSxTQUFBLDBFQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxPQUFBLG9CQUFBLENBQXFCO0lBQUEsQ0FBQTtBQUFFLElBQUEscUJBQUEsQ0FBQTs7QUFBaUQsSUFBQSwyQkFBQTtBQUM3RyxJQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBSDJCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLDZDQUFBLENBQUE7QUFDcUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsd0JBQUEsQ0FBQTs7O0FEaEJoRSxVQXFCYTtBQXJCYjs7QUFDQTtBQUNBO0FBS0E7QUFDQTtBQUNBOzs7Ozs7QUFZTSxJQUFPLGdDQUFQLE1BQU8sK0JBQTZCO01BK0MxQjtNQUNBO01BL0NIO01BQ0E7TUFDQTtNQUtGO01BS0E7TUFNQTtNQUtBO01BS0E7TUFLQSxhQUFhO01BS2IsV0FBVztNQUtsQjtNQUVBLFlBQ1ksbUJBQ0EsdUJBQTRDO0FBRDVDLGFBQUEsb0JBQUE7QUFDQSxhQUFBLHdCQUFBO01BQ1Q7TUFFSCxZQUFZLFNBQXNCO0FBQzlCLFlBQUksUUFBUSxzQkFBc0I7QUFDOUIsZ0JBQU0sOEJBQTJFLFFBQVEscUJBQXFCO0FBQzlHLGVBQUssVUFBVTtBQUVmLGNBQUksS0FBSyxTQUFTLFNBQVMsYUFBYSxhQUFhO0FBQ2pELGlCQUFLLHdCQUF3QiwyQkFBMkI7aUJBQ3JEO0FBQ0gsaUJBQUssaUJBQWlCLDJCQUEyQjs7O01BRzdEO01BT1Esd0JBQXdCLDZCQUF3RTtBQUNwRyxhQUFLLHdCQUF3QjtBQUU3QixjQUFNLFNBQXVCLENBQUMsV0FBVyxlQUFlLEVBQUUsSUFBSSw0QkFBNEIsYUFBWSxDQUFFO0FBQ3hHLGFBQUssa0JBQWtCLHFCQUFxQixNQUFNLEVBQUUsVUFBVTtVQUMxRCxNQUFNLENBQUMsVUFBUztBQUNaLGlCQUFLLFVBQVU7QUFDZixpQkFBSyxRQUFRLEtBQUssb0NBQW9DLEtBQUs7VUFDL0Q7VUFDQSxPQUFPLE1BQUs7QUFDUixpQkFBSyxVQUFVO1VBQ25CO1NBQ0g7TUFDTDtNQVFRLG9DQUFvQyxPQUFvQjtBQUM1RCxlQUFPLEtBQUssWUFBWSxLQUFLLEVBQ3hCLElBQUksQ0FBQyxVQUFVLEVBQUUsTUFBTSxVQUFVLEtBQUssU0FBUyxJQUFJLEVBQUMsRUFBRyxFQUN2RCxLQUFLLCtCQUE4Qix1QkFBdUI7TUFDbkU7TUFZUSxPQUFPLHdCQUF3QixPQUF5QixPQUF1QjtBQUNuRixZQUFJLE1BQU0sYUFBYSxNQUFNLFVBQVU7QUFDbkMsaUJBQU8sTUFBTSxLQUFLLGNBQWMsTUFBTSxJQUFJO21CQUNuQyxNQUFNLFVBQVU7QUFDdkIsaUJBQU87ZUFDSjtBQUNILGlCQUFPOztNQUVmO01BT1EsaUJBQWlCLDZCQUF3RTtBQUM3RixhQUFLLHdCQUF3QjtBQUU3QixhQUFLLHNCQUFzQixrQkFBa0IsNEJBQTRCLFlBQVksRUFBRSxVQUFVO1VBQzdGLE1BQU0sQ0FBQyxlQUE4QjtBQUNqQyxpQkFBSyxVQUFVO0FBQ2YsaUJBQUssY0FBYyxLQUFLLGtCQUFrQixXQUFXLFFBQVEsRUFBRTtVQUNuRTtVQUNBLE9BQU8sTUFBSztBQUNSLGlCQUFLLFVBQVU7VUFDbkI7U0FDSDtNQUNMO01BRUEsWUFBWSxPQUFvQjtBQUM1QixlQUFPLE9BQU8sS0FBSyxLQUFLLEVBQUUsT0FBTyxDQUFDLGFBQWEsTUFBTSxRQUFRLE1BQU0sU0FBUyxJQUFJO01BQ3BGO01BRUEsaUJBQWlCLE1BQVk7QUFDekIsYUFBSyxjQUFjO0FBQ25CLGFBQUssVUFBVTtBQUVmLGNBQU0sU0FBdUIsQ0FBQyxXQUFXLGVBQWUsRUFBRSxJQUFJLEtBQUsscUJBQXFCLGFBQVksQ0FBRTtBQUV0RyxhQUFLLGtCQUFrQixlQUFlLE1BQU0sTUFBTSxFQUFFLFVBQVUsQ0FBQyxhQUFZO0FBQ3ZFLGdCQUFNLGNBQWMsU0FBUyxRQUFRLElBQUksY0FBYztBQUN2RCxjQUFJLGVBQWUsQ0FBQyxZQUFZLFdBQVcsTUFBTSxHQUFHO0FBQ2hELGlCQUFLLGFBQWE7QUFDbEIsaUJBQUssVUFBVTtpQkFDWjtBQUNILGlCQUFLLGFBQWE7QUFDbEIsaUJBQUssa0JBQWtCLFFBQVEsTUFBTSxNQUFNLEVBQUUsVUFBVTtjQUNuRCxNQUFNLENBQUMsRUFBRSxZQUFXLE1BQU07QUFDdEIscUJBQUssVUFBVTtBQUNmLHFCQUFLLGNBQWMsS0FBSyxrQkFBa0IsV0FBVztjQUN6RDtjQUNBLE9BQU8sTUFBSztBQUNSLHFCQUFLLFVBQVU7Y0FDbkI7YUFDSDs7UUFFVCxDQUFDO01BQ0w7TUFLQSxzQkFBbUI7QUFDZixhQUFLLGtCQUFrQixhQUFhLEtBQUssYUFBYSxLQUFLLFNBQVMsWUFBWSxNQUFNLEtBQUsscUJBQXFCLGVBQWUsTUFBTSxLQUFLLFdBQVc7TUFDeko7TUFFQSwyQkFBd0I7QUFDcEIsZUFBTyxLQUFLLFFBQVEsSUFBSSxLQUFLLGVBQWUsTUFBTSxLQUFLLENBQUE7TUFDM0Q7TUFFUSxTQUFTLE1BQVk7QUFDekIsZUFBTyxLQUFLLFFBQVEsSUFBSSxJQUFJO01BQ2hDO01BRUEsa0JBQWtCLGFBQW1CO0FBQ2pDLGNBQU0sVUFBVSxLQUFLLHlCQUF3QixFQUN4QyxPQUFPLENBQUMsVUFBVSxNQUFNLFFBQVEsTUFBTSxFQUFFLEVBQ3hDLEtBQUssQ0FBQyxJQUFJLE9BQU07QUFDYixnQkFBTSxRQUFRLEdBQUcsS0FBSyxPQUFPLEdBQUcsS0FBSztBQUNyQyxjQUFJLFVBQVUsR0FBRztBQUNiLG1CQUFPLEdBQUcsS0FBSyxTQUFTLEdBQUcsS0FBSzs7QUFFcEMsaUJBQU87UUFDWCxDQUFDO0FBRUwsWUFBSSxDQUFDLFFBQVEsUUFBUTtBQUNqQixpQkFBTyxPQUFPLFdBQVc7O0FBRzdCLGNBQU0sT0FBTyxZQUFZLE1BQU0sSUFBSTtBQUNuQyxZQUFJLFNBQVM7QUFFYixpQkFBUyxJQUFJLEdBQUcsSUFBSSxRQUFRLENBQUMsRUFBRSxLQUFLLE9BQU8sR0FBRyxLQUFLO0FBQy9DLG9CQUFVLE9BQU8sS0FBSyxDQUFDLENBQUMsSUFBSTs7QUFFaEMsa0JBQVUsT0FBTyxLQUFLLFFBQVEsQ0FBQyxFQUFFLEtBQUssT0FBTyxDQUFDLEVBQUUsTUFBTSxHQUFHLFFBQVEsQ0FBQyxFQUFFLEtBQUssU0FBUyxDQUFDLENBQUM7QUFFcEYsaUJBQVMsSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7QUFDckMsZ0JBQU0sUUFBUSxRQUFRLENBQUM7QUFFdkIsZ0JBQU0sY0FBYyxNQUFNLEtBQUssT0FBTztBQUN0QyxnQkFBTSxZQUFZLE1BQU0sR0FBRyxPQUFPO0FBRWxDLGdCQUFNLGdCQUFnQixNQUFNLEtBQUssU0FBUztBQUMxQyxnQkFBTSxjQUFjLE1BQU0sR0FBRyxTQUFTLE1BQU0sR0FBRyxTQUFTO0FBRXhELG9CQUFVLEtBQUs7QUFFZixjQUFJLGdCQUFnQixXQUFXO0FBQzNCLHNCQUFVLE9BQU8sS0FBSyxXQUFXLEVBQUUsTUFBTSxlQUFlLFdBQVcsQ0FBQyxJQUFJLEtBQUs7aUJBQzFFO0FBQ0gsc0JBQVUsT0FBTyxLQUFLLFdBQVcsRUFBRSxNQUFNLGFBQWEsQ0FBQztBQUN2RCxxQkFBUyxJQUFJLGNBQWMsR0FBRyxJQUFJLFdBQVcsS0FBSztBQUM5Qyx3QkFBVSxPQUFPLE9BQU8sS0FBSyxDQUFDLENBQUM7O0FBRW5DLHNCQUFVLE9BQU8sT0FBTyxLQUFLLFNBQVMsRUFBRSxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksS0FBSzs7QUFJMUUsY0FBSSxNQUFNLFFBQVEsU0FBUyxHQUFHO0FBQzFCLHNCQUFVLE9BQU8sS0FBSyxTQUFTLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDbkQscUJBQVMsSUFBSSxZQUFZLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FBSztBQUM5Qyx3QkFBVSxPQUFPLE9BQU8sS0FBSyxDQUFDLENBQUM7O3FCQUU1QixRQUFRLElBQUksQ0FBQyxFQUFFLEtBQUssU0FBUyxNQUFNLEdBQUcsTUFBTTtBQUNuRCxzQkFBVSxPQUFPLEtBQUssU0FBUyxFQUFFLE1BQU0sYUFBYSxRQUFRLElBQUksQ0FBQyxFQUFFLEtBQUssU0FBUyxDQUFDLENBQUM7aUJBQ2hGO0FBQ0gsc0JBQVUsT0FBTyxLQUFLLFNBQVMsRUFBRSxNQUFNLFdBQVcsQ0FBQyxJQUFJO0FBQ3ZELHFCQUFTLElBQUksWUFBWSxHQUFHLElBQUksUUFBUSxJQUFJLENBQUMsRUFBRSxLQUFLLE9BQU8sR0FBRyxLQUFLO0FBQy9ELHdCQUFVLE9BQU8sS0FBSyxDQUFDLENBQUMsSUFBSTs7QUFFaEMsc0JBQVUsT0FBTyxLQUFLLFFBQVEsSUFBSSxDQUFDLEVBQUUsS0FBSyxPQUFPLENBQUMsRUFBRSxNQUFNLEdBQUcsUUFBUSxJQUFJLENBQUMsRUFBRSxLQUFLLFNBQVMsQ0FBQyxDQUFDOzs7QUFJcEcsZUFBTztNQUNYOzt5QkFsUFMsZ0NBQTZCLGdDQUFBLCtCQUFBLEdBQUEsZ0NBQUEscUJBQUEsQ0FBQTtNQUFBO2lFQUE3QixnQ0FBNkIsV0FBQSxDQUFBLENBQUEsNEJBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsU0FBQSxXQUFBLHNCQUFBLHVCQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFNBQUEsZ0JBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSwwQkFBQSxHQUFBLGFBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSw4QkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsa0JBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsdUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNyQjFDLFVBQUEsNkJBQUEsR0FBQSx5QkFBQSxDQUFBO0FBQXVDLFVBQUEseUJBQUEsY0FBQSxTQUFBLG1GQUFBLFFBQUE7QUFBQSxtQkFBYyxJQUFBLGlCQUFBLE1BQUE7VUFBd0IsQ0FBQTtBQUEwRCxVQUFBLDJCQUFBO0FBQ3ZJLFVBQUEscUJBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLHNEQUFBLEdBQUEsQ0FBQSxFQUlDLEdBQUEsc0RBQUEsSUFBQSxDQUFBLEVBQUEsR0FBQSxzREFBQSxJQUFBLENBQUE7OztBQUw4RSxVQUFBLG9DQUFBLGdCQUFBLElBQUEsd0JBQUEsT0FBQSxPQUFBLElBQUEscUJBQUEsWUFBQTtBQUF4RCxVQUFBLHlCQUFBLFNBQUEsSUFBQSxLQUFBO0FBQ3ZCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxDQUFBLElBQUEsV0FBQSxDQUFBLElBQUEsYUFBQSxJQUFBLEVBQUE7QUFLQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxVQUFBLElBQUEsRUFBQTtBQU9BLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLGFBQUEsSUFBQSxFQUFBOzs7OztxRkRRYSwrQkFBNkIsRUFBQSxXQUFBLGdDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRXJCMUM7Ozs7OztBQ0FBLElBRWE7QUFGYjs7O0FBRU0sSUFBTyxnQkFBUCxNQUFvQjtNQUN0QjtNQUNBO01BQ0EsWUFBWSxNQUE2QixJQUF5QjtBQUM5RCxhQUFLLE9BQU87QUFDWixhQUFLLEtBQUs7TUFDZDs7Ozs7O0FDUkosSUFBYTtBQUFiOztBQUFNLElBQU8sY0FBUCxNQUFrQjtNQUNwQjtNQUNBO01BRUEsWUFBWSxPQUFlLFFBQWM7QUFDckMsYUFBSyxRQUFRO0FBQ2IsYUFBSyxTQUFTO01BQ2xCOzs7Ozs7QUNQSixTQUF3QixhQUFBQyxZQUFXLFdBQVcsWUFBWSxTQUFBQyxRQUEwQixXQUEwQixvQkFBb0I7QUFDbEksWUFBWSxXQUFXO0FBQ3ZCLFNBQVMsV0FBQUMsZ0JBQWU7Ozs7QUNFUixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsa0NBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQURvQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsT0FBQSxRQUFBLEVBQXFCLHdCQUFBLE9BQUEsdUJBQUEsQ0FBQTs7Ozs7QUFHckQsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLDhCQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFEZ0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLE9BQUEsUUFBQSxFQUFxQixXQUFBLE9BQUEsUUFBQSxFQUFBLHdCQUFBLE9BQUEsbUJBQUEsQ0FBQTs7Ozs7QUFKckQsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLG1FQUFBLEdBQUEsQ0FBQSxFQUVDLEdBQUEsbUVBQUEsR0FBQSxDQUFBOzs7O0FBRkQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEscUJBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsOEJBQUEsSUFBQSxFQUFBOzs7OztBQVFJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxrQ0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBRG9DLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxPQUFBLFFBQUEsRUFBcUIsd0JBQUEsT0FBQSx1QkFBQSxDQUFBOzs7OztBQUdyRCxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsOEJBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQURnQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsT0FBQSxRQUFBLEVBQXFCLFdBQUEsT0FBQSxRQUFBLEVBQUEsd0JBQUEsT0FBQSxtQkFBQSxDQUFBOzs7OztBQUpyRCxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsbUVBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSxtRUFBQSxHQUFBLENBQUE7Ozs7QUFGRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxxQkFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSw4QkFBQSxJQUFBLEVBQUE7OztBRGhCWixJQWFhLG9CQVNBO0FBdEJiOztBQUdBO0FBQ0E7QUFFQTtBQUVBO0FBRUE7Ozs7QUFHTSxJQUFPLHFCQUFQLE1BQU8sb0JBQWtCO01BQ1I7TUFBbkIsWUFBbUIsWUFBc0I7QUFBdEIsYUFBQSxhQUFBO01BQXlCOzt5QkFEbkMscUJBQWtCLGdDQUFBLGNBQUEsQ0FBQTtNQUFBO2lFQUFsQixxQkFBa0IsV0FBQSxDQUFBLENBQUEsSUFBQSxXQUFBLEVBQUEsQ0FBQSxFQUFBLENBQUE7O0FBU3pCLElBQU8sK0JBQVAsTUFBTyw4QkFBNEI7TUFrQmpCO01BakJYO01BQ0E7TUFDQTtNQUNBO01BRXlCO01BRWxDO01BRU87TUFFQTtNQUNBO01BRUE7TUFDQTtNQUVQLFlBQW9CLHdCQUE4QztBQUE5QyxhQUFBLHlCQUFBO01BQWlEO01BS3JFLGtCQUFlO0FBQ1gsY0FBTSxlQUFlLEtBQUssTUFBTSxJQUFJLENBQUMsU0FBNkIsS0FBSyxXQUFXLGFBQWE7QUFFL0YsYUFBSyxRQUFjLGNBQVEsY0FBYztVQUNyQyxTQUFTO1VBQ1QsT0FBTyxDQUFDLElBQUksRUFBRTtVQUNkLFlBQVk7U0FDZjtNQUNMO01BRUEsV0FBUTtBQUNKLGFBQUssb0JBQW9CLFVBQVUsQ0FBQyxTQUFpQixLQUFLLG1CQUFtQixJQUFJLENBQUM7TUFDdEY7TUFFQSxZQUFZLFNBQXNCO0FBQzlCLFlBQUksUUFBUSxVQUFVO0FBQ2xCLGdCQUFNLFdBQVcsUUFBUSxTQUFTO0FBRWxDLGVBQUsscUJBQXFCLFNBQVMsU0FBUyxhQUFhO0FBQ3pELGVBQUssOEJBQThCLFNBQVMsU0FBUyxhQUFhLGVBQWUsU0FBUyxTQUFTLGFBQWE7O0FBR3BILFlBQUksUUFBUSxZQUFZO0FBQ3BCLGVBQUssdUJBQ0Esb0NBQW9DLFlBQVksS0FBSyxRQUFRLEdBQUksUUFBUSxXQUFXLGFBQWEsRUFBRSxFQUNuRyxVQUFVLENBQUMsU0FBK0Y7QUFDdkcsaUJBQUssdUJBQXVCLEtBQUs7QUFDakMsZ0JBQUksS0FBSyxzQkFBc0IsS0FBSyx1QkFBdUIsS0FBSyxxQkFBcUIsWUFBWSxjQUFjO0FBQzNHLG1CQUFLLGdCQUFnQixLQUFLLG9CQUFvQjs7QUFFbEQsZ0JBQUksS0FBSyw2QkFBNkI7QUFDbEMsbUJBQUssaUJBQWlCLEtBQUssb0JBQW1FOztVQUV0RyxDQUFDOztNQUViO01BT1EsZ0JBQWdCLHNCQUE2RjtBQUNqSCxjQUFNLE9BQU8scUJBQXFCO0FBQ2xDLDZCQUFxQixjQUFjLHFCQUFxQjtBQUN4RCw2QkFBcUIsY0FBYztBQUVuQyxZQUFJLHNCQUFzQixTQUFTO0FBQy9CLCtCQUFxQixRQUFRLFFBQVEsQ0FBQyxVQUFTO0FBQzNDLGtCQUFNLFlBQVksTUFBTTtBQUN4QixrQkFBTSxTQUFTLE1BQU07QUFDckIsa0JBQU0sU0FBUztVQUNuQixDQUFDOztNQUVUO01BRUEsaUJBQWlCLGdCQUEyRDtBQUN4RSxZQUFJLGVBQWUsU0FBUztBQUN4QixnQkFBTSxXQUFXLGVBQWUsUUFBUSxJQUFJLENBQUMsVUFBVSxJQUFJLFlBQVksTUFBTSxRQUFRLE1BQU0sTUFBTSxDQUFDLEVBQUUsS0FBSyxDQUFDLElBQUksT0FBTyxHQUFHLFFBQVEsR0FBRyxLQUFLO0FBQ3hJLGdCQUFNLFdBQVcsZUFBZSxRQUFRLElBQUksQ0FBQyxVQUFVLElBQUksWUFBWSxNQUFNLFFBQVEsTUFBTSxNQUFNLENBQUMsRUFBRSxLQUFLLENBQUMsSUFBSSxPQUFPLEdBQUcsUUFBUSxHQUFHLEtBQUs7QUFFeEksZUFBSyxXQUFXLEtBQUsscUJBQXFCLFVBQVUsZUFBZSxXQUFXO0FBQzlFLGVBQUssV0FBVyxLQUFLLHFCQUFxQixVQUFVLGVBQWUsV0FBVztlQUMzRTtBQUVILGVBQUssV0FBVyxvQkFBSSxJQUFHO0FBQ3ZCLGVBQUssV0FBVyxvQkFBSSxJQUFHOztNQUUvQjtNQU9BLHFCQUFxQixTQUF3QixZQUF1RDtBQUNoRyxjQUFNLHlCQUF5QixvQkFBSSxJQUFHO0FBRXRDLGdCQUFRLFFBQVEsQ0FBQyxVQUFTO0FBRXRCLGNBQUksTUFBTSxXQUFXLEdBQUc7QUFDcEI7O0FBRUosZ0JBQU0sT0FBTyxXQUFXLFNBQVUsTUFBTSxLQUFLLEdBQUcsUUFBUTtBQUV4RCxjQUFJLENBQUMsdUJBQXVCLElBQUksSUFBSSxHQUFHO0FBQ25DLG1DQUF1QixJQUFJLE1BQU0sQ0FBQSxDQUFFOztBQUd2QyxnQkFBTSxjQUFjLHVCQUF1QixJQUFJLElBQUk7QUFFbkQsc0JBQVksS0FBSyxJQUFJLGNBQWMsV0FBVyxTQUFVLE1BQU0sS0FBSyxHQUFHLFdBQVcsU0FBVSxNQUFNLFFBQVEsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBQy9ILENBQUM7QUFFRCxlQUFPO01BQ1g7TUFFQSx5QkFBc0I7QUFDbEIsZUFBTyxLQUFLLHFCQUFxQjtNQUNyQztNQUVBLHlCQUFzQjtBQUNsQixlQUFPLEtBQUsscUJBQXFCO01BQ3JDO01BRUEscUJBQWtCO0FBQ2QsZUFBTyxLQUFLLHFCQUFxQjtNQUNyQztNQUVBLHFCQUFrQjtBQUNkLGVBQU8sS0FBSyxxQkFBcUI7TUFDckM7TUFFQSxtQkFBbUIsTUFBWTtBQUMzQixnQkFBUSxNQUFNO1VBQ1YsS0FBSyxRQUFRO0FBQ1QsaUJBQUssTUFBTSxTQUFTLENBQUM7QUFDckI7O1VBRUosS0FBSyxTQUFTO0FBQ1YsaUJBQUssTUFBTSxTQUFTLENBQUM7QUFDckI7O1VBRUosS0FBSyxRQUFRO0FBQ1QsaUJBQUssTUFBTSxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUM7OztNQUd4Qzs7eUJBdEpTLCtCQUE0QixnQ0FBQSxzQkFBQSxDQUFBO01BQUE7aUVBQTVCLCtCQUE0QixXQUFBLENBQUEsQ0FBQSwyQkFBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLG1DQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO29DQU12QixvQkFBa0IsQ0FBQTs7Ozs7Ozs7QUM1QnBDLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxxREFBQSxHQUFBLENBQUE7QUFRSixVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLEdBQUEscURBQUEsR0FBQSxDQUFBO0FBUUosVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUFwQlEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsdUJBQUEsSUFBQSxFQUFBO0FBVUEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsdUJBQUEsSUFBQSxFQUFBOzt3QkRDSyxvQkFBa0IsbUNBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUEsMjZDQUFBLEVBQUEsQ0FBQTs7O3FGQVNsQiw4QkFBNEIsRUFBQSxXQUFBLCtCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRXRCekMsU0FBUyxhQUFBQyxZQUFXLFNBQUFDLGNBQWE7QUFDakMsU0FBUyxXQUFBQyxnQkFBZTs7OztBQ0FwQixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSx5QkFBQSxDQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsNkJBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxJQUFBOzs7O0FBSCtCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsdUJBQUEsT0FBQSxtQkFBQSxFQUEyQyxZQUFBLE9BQUEsUUFBQSxFQUFBLGNBQUEsT0FBQSxVQUFBO0FBQ3ZDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSxPQUFBLFVBQUEsRUFBeUIsWUFBQSxPQUFBLFFBQUEsRUFBQSx1QkFBQSxPQUFBLG1CQUFBOzs7QURINUQsSUFZYTtBQVpiOztBQUVBO0FBQ0E7OztBQVNNLElBQU8sNkJBQVAsTUFBTyw0QkFBMEI7TUFDMUI7TUFDQTtNQUtULHNCQUF1QyxJQUFJQSxTQUFPOzt5QkFQekMsNkJBQTBCO01BQUE7aUVBQTFCLDZCQUEwQixXQUFBLENBQUEsQ0FBQSx3QkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFlBQUEsY0FBQSxVQUFBLFdBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsb0JBQUEsR0FBQSxDQUFBLEdBQUEsdUJBQUEsWUFBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsWUFBQSxxQkFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLG9DQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDWnZDLFVBQUEseUJBQUEsR0FBQSxtREFBQSxHQUFBLENBQUE7OztBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLGFBQUEsSUFBQSxFQUFBOzs7OztxRkRZYSw0QkFBMEIsRUFBQSxXQUFBLDZCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVp2QyxTQUFTLGFBQUFDLFlBQVcsZ0JBQUFDLGVBQWMsU0FBQUMsUUFBa0IsVUFBQUMsZUFBNkI7QUFLakYsU0FBUyxhQUFhLGNBQWMsZ0JBQWdCLDZCQUE2Qjs7Ozs7O0FDQ3pFLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTs7QUFBOEQsSUFBQSwyQkFBQTtBQUN4RSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQUhzRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxxQkFBQTtBQUN4QyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsR0FBQSxxQ0FBQSxDQUFBOzs7OztBQUtWLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTs7QUFBNkQsSUFBQSwyQkFBQTtBQUN2RSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQUhzRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxxQkFBQTtBQUN4QyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsR0FBQSxvQ0FBQSxDQUFBOzs7Ozs7QUFNRixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQWtHLElBQUEseUJBQUEsU0FBQSxTQUFBLCtFQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGdCQUFBLFlBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxZQUFBLEtBQUEsY0FBQSxFQUFBLENBQStCO0lBQUEsQ0FBQTtBQUN0SSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQU9BLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQStCLElBQUEscUJBQUEsRUFBQTtBQUF1QyxJQUFBLDJCQUFBO0FBQ3RFLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsRUFBQTs7QUFBMEcsSUFBQSwyQkFBQTtBQUNoSCxJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsRUFBQTs7QUFBd0csSUFBQSwyQkFBQTtBQUNsSCxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQW9DLElBQUEscUJBQUEsRUFBQTs7QUFBc0QsSUFBQSwyQkFBQTtBQUM5RixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBOzs7Ozs7QUFuQnFDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsWUFBQSxDQUFBLE9BQUEsa0JBQUEsY0FBQSxPQUFBLE9BQUEsUUFBQTtBQUlyQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsOEJBQUEsSUFBQUMsTUFBQSxjQUFBLFdBQUEsT0FBQSxXQUFBLGNBQUEsV0FBQSxPQUFBLE1BQUEsQ0FBQTtBQU0rQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLE1BQUEsT0FBQSxjQUFBLE1BQUEsSUFBQSxJQUFBLE9BQUEsUUFBQSxHQUFBO0FBRXJCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsSUFBQSxjQUFBLFlBQUEsZ0JBQUEsMEJBQUEsSUFBQSxHQUFBLHNDQUFBLEdBQUEsSUFBQTtBQUNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsY0FBQSxZQUFBLGdCQUFBLDBCQUFBLElBQUEsR0FBQSxzQ0FBQSxDQUFBO0FBSWtCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSwwQkFBQSxJQUFBLElBQUEsY0FBQSxjQUFBLEdBQUEsT0FBQSxHQUFBLEtBQUE7Ozs7O0FBbkJoRCxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEsMERBQUEsSUFBQSxJQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQXFCSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7QUF0QlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxPQUFBLGdCQUFBOzs7OztBQXdCSixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtCQUFBLDBCQUFBLEdBQUEsR0FBQSxnQ0FBQSxHQUFBLFlBQUE7OztBRDdDWixVQVlhO0FBWmI7O0FBSUE7OztBQVFNLElBQU8sNkJBQVAsTUFBTyw0QkFBMEI7TUFDMUI7TUFDQTtNQUNBLGdCQUFnQjtNQUNoQixTQUFTO01BRVQ7TUFDQyx1QkFBdUIsSUFBSUgsY0FBWTtNQUV2QyxjQUFjLElBQUlBLGNBQVk7TUFFL0IsWUFBWSxpQkFBaUI7TUFDN0IsU0FBUyxpQkFBaUI7TUFFbkMsd0JBQXdCO01BS2pCLGNBQWM7TUFLZCxnQkFBZ0I7TUFLaEI7TUFLQSxXQUFXO01BR2xCLGlCQUFpQjtNQUNqQixjQUFjO01BQ2QsZUFBZTtNQUVmLFlBQVksU0FBc0I7QUFDOUIsWUFBSSxRQUFRLGFBQWE7QUFDckIsZ0JBQU0sY0FBeUYsUUFBUSxZQUFZO0FBRW5ILGVBQUssY0FBYztBQUNuQixjQUFJLENBQUMsYUFBYTtBQUNkLGlCQUFLLGdCQUFnQjtpQkFDbEI7QUFDSCxpQkFBSyxnQkFBZ0IsS0FBSyxxQkFBcUIsWUFBWSxNQUFNOztBQUVyRSxlQUFLLG1CQUFtQixLQUFLLG9CQUFtQjs7TUFFeEQ7TUFFQSxvQkFBaUI7QUFDYixhQUFLLHFCQUFxQixLQUFLLElBQUk7TUFDdkM7TUFFQSxxQkFBcUIsa0JBQXdCO0FBQ3pDLGVBQU8sS0FBSyxLQUFLLG1CQUFtQixLQUFLLFFBQVE7TUFDckQ7TUFFQSxzQkFBbUI7QUFDZixjQUFNLGFBQWEsS0FBSyxjQUFjLEtBQUs7QUFDM0MsZUFBTyxLQUFLLGFBQWEsTUFBTSxZQUFZLGFBQWEsS0FBSyxRQUFRO01BQ3pFO01BRUEsY0FBYyxLQUFXO0FBQ3JCLGVBQU8sTUFBTSxLQUFLLGNBQWMsS0FBSztNQUN6QztNQUVBLGlCQUFjO0FBQ1YsWUFBSSxLQUFLLGdCQUFnQixHQUFHO0FBQ3hCOztBQUdKLGFBQUs7QUFDTCxhQUFLLG1CQUFtQixLQUFLLG9CQUFtQjtNQUNwRDtNQUVBLGtCQUFlO0FBQ1gsWUFBSSxLQUFLLGNBQWMsS0FBSyxLQUFLLGVBQWU7QUFDNUM7O0FBR0osYUFBSztBQUNMLGFBQUssbUJBQW1CLEtBQUssb0JBQW1CO01BQ3BEOzt5QkF4RlMsNkJBQTBCO01BQUE7aUVBQTFCLDZCQUEwQixXQUFBLENBQUEsQ0FBQSx3QkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFVBQUEsWUFBQSxhQUFBLGVBQUEsZUFBQSxpQkFBQSxRQUFBLFVBQUEsZ0JBQUEsaUJBQUEsR0FBQSxTQUFBLEVBQUEsc0JBQUEsd0JBQUEsYUFBQSxjQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLG1CQUFBLEdBQUEsQ0FBQSxHQUFBLDBCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSwwQkFBQSxHQUFBLENBQUEsR0FBQSwyQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsbUJBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLHdCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSw4QkFBQSxHQUFBLENBQUEsR0FBQSwrQkFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsMkJBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsK0JBQUEsR0FBQSxDQUFBLEdBQUEsdUJBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxvQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1p2QyxVQUFBLDZCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQW1FLFVBQUEseUJBQUEsU0FBQSxTQUFBLDJEQUFBO0FBQUEsbUJBQVMsSUFBQSxrQkFBQTtVQUFtQixDQUFBO0FBQzNGLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxVQUFBLHFCQUFBLEdBQUEsYUFBQTtBQUFXLFVBQUEsMkJBQUE7QUFDakIsVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0osVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsb0RBQUEsSUFBQSxDQUFBO0FBT0EsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsb0RBQUEsSUFBQSxDQUFBLEVBS0MsSUFBQSxvREFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLG9EQUFBLEdBQUEsQ0FBQTtBQStCRCxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQXlFLFVBQUEseUJBQUEsU0FBQSxTQUFBLDREQUFBO0FBQUEsbUJBQVMsSUFBQSxlQUFBO1VBQWdCLENBQUE7QUFDOUYsVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUFzQyxVQUFBLHFCQUFBLEVBQUE7QUFBeUMsVUFBQSwyQkFBQTtBQUMvRSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFBeUYsVUFBQSx5QkFBQSxTQUFBLFNBQUEsNERBQUE7QUFBQSxtQkFBUyxJQUFBLGdCQUFBO1VBQWlCLENBQUE7QUFDL0csVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUF6RHFDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsWUFBQSxJQUFBLGNBQUE7QUFFcEIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsY0FBQTtBQUViLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLGdCQUFBLEtBQUEsRUFBQTtBQU9BLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsS0FBQSxJQUFBLGVBQUEsT0FBQSxPQUFBLElBQUEsWUFBQSxZQUFBLE1BQUEsS0FBQSxFQUFBO0FBTUEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsZUFBQSxJQUFBLFlBQUEsU0FBQSxLQUFBLEVBQUE7QUF5QkEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLENBQUEsSUFBQSxlQUFBLENBQUEsSUFBQSxZQUFBLFNBQUEsS0FBQSxFQUFBO0FBTXdDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsWUFBQSxJQUFBLGdCQUFBLENBQUE7QUFDdkIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsV0FBQTtBQUV5QixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLElBQUEsSUFBQSxjQUFBLEdBQUEsS0FBQSxJQUFBLGVBQUEsRUFBQTtBQUNELFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsWUFBQSxJQUFBLGNBQUEsS0FBQSxJQUFBLGFBQUE7QUFDeEIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsWUFBQTs7Ozs7cUZEMUNSLDRCQUEwQixFQUFBLFdBQUEsNkJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFWnZDLFNBQVMsY0FBQUksbUJBQWtCOztBQUEzQixJQUthO0FBTGI7O0FBS00sSUFBTyw2QkFBUCxNQUFPLDRCQUEwQjtNQU9uQyxrQkFBa0IsT0FBYyxhQUF5QztBQUNyRSxZQUFJLENBQUMsYUFBYTtBQUNkLGlCQUFPLENBQUE7O0FBRVgsWUFBSTtBQUNKLFlBQUksTUFBTSxlQUFlLEtBQUs7QUFDMUIsMkJBQWlCLENBQUMsZUFBMEMsV0FBVyxjQUFjLE1BQU0sY0FBYyxXQUFXLGNBQWMsTUFBTTtlQUNySTtBQUNILDJCQUFpQixDQUFDLGVBQTBDLFdBQVcsY0FBYyxNQUFNLGNBQWMsV0FBVyxhQUFhLE1BQU07O0FBRTNJLGVBQU8sWUFBWSxPQUFPLGNBQWM7TUFDNUM7O3lCQWxCUyw2QkFBMEI7TUFBQTtxRUFBMUIsNkJBQTBCLFNBQTFCLDRCQUEwQixXQUFBLFlBRGIsT0FBTSxDQUFBOzs7Ozs7QUNFaEM7Ozs7OztBQ05BLFNBQVMsYUFBQUMsWUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFrQixVQUFBQyxlQUE2Qjs7Ozs7O0FDdUU3RCxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsR0FBQTtBQUFHLElBQUEsc0JBQUEsQ0FBQTs7QUFBZ0csSUFBQSw0QkFBQTtBQUFLLElBQUEsc0JBQUEsR0FBQSxHQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLElBQUE7QUFDeEcsSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE1BQUE7QUFBTyxJQUFBLHNCQUFBLENBQUE7O0FBQTJHLElBQUEsNEJBQUE7QUFBUSxJQUFBLHNCQUFBLElBQUEsR0FBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxJQUFBO0FBQzFILElBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxNQUFBO0FBQU8sSUFBQSxzQkFBQSxFQUFBOztBQUFxRyxJQUFBLDRCQUFBO0FBQVEsSUFBQSxzQkFBQSxJQUFBLEdBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsSUFBQTtBQUNwSCxJQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsTUFBQTtBQUFPLElBQUEsc0JBQUEsRUFBQTs7QUFBaUcsSUFBQSw0QkFBQTtBQUFRLElBQUEsc0JBQUEsSUFBQSxHQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLElBQUE7QUFDaEgsSUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLHNCQUFBLEVBQUE7O0FBQXNGLElBQUEsNEJBQUE7QUFBUSxJQUFBLHNCQUFBLElBQUEsR0FBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxJQUFBO0FBQ3BHLElBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxHQUFBO0FBQUcsSUFBQSxzQkFBQSxFQUFBOztBQUdELElBQUEsNEJBQUE7QUFDTixJQUFBLHNCQUFBLElBQUEsb0JBQUE7Ozs7O0FBVE8sSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSxJQUFBLDJCQUFBLEdBQUEsR0FBQSwrQ0FBQSwrQkFBQSxJQUFBQyxNQUFBLFNBQUEsS0FBQSxDQUFBLEdBQUEsR0FBQTtBQUNJLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsS0FBQSwyQkFBQSxHQUFBLEdBQUEsbUNBQUEsK0JBQUEsSUFBQUEsTUFBQSxPQUFBLGFBQUEsU0FBQSxLQUFBLEVBQUEsU0FBQSxDQUFBLEdBQUEsRUFBQTtBQUNBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsS0FBQSwyQkFBQSxJQUFBLElBQUEsZ0NBQUEsK0JBQUEsSUFBQUEsTUFBQSxPQUFBLGFBQUEsU0FBQSxLQUFBLEVBQUEsTUFBQSxDQUFBLEdBQUEsRUFBQTtBQUNBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsS0FBQSwyQkFBQSxJQUFBLElBQUEsOEJBQUEsK0JBQUEsSUFBQUEsTUFBQSxPQUFBLGFBQUEsU0FBQSxLQUFBLEVBQUEsSUFBQSxDQUFBLEdBQUEsRUFBQTtBQUNELElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMkJBQUEsSUFBQSxJQUFBLHdDQUFBLCtCQUFBLElBQUEsS0FBQSxTQUFBLElBQUEsQ0FBQSxDQUFBO0FBQ0gsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwyQkFBQSxJQUFBLElBQUEsMkNBQUEsK0JBQUEsSUFBQSxLQUFBLE9BQUEsMkJBQUEsSUFBQSxPQUFBLE1BQUEsU0FBQSxRQUFBLE1BQUEsT0FBQSwwQkFBQSxDQUFBLElBQUEsQ0FBQSxDQUFBLENBQUE7OztBRDVFdkIseUJBc0JhO0FBdEJiOztBQUdBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUFhTSxJQUFPLGdDQUFQLE1BQU8sdUNBQXNDLGtDQUFpQztNQWlCNUQ7TUFiWDtNQUlBO01BQ0MscUJBQTBDLElBQUlILGNBQVk7TUFFcEUsWUFBWTtNQUNaO01BQ0EsYUFBa0QsQ0FBQTtNQUV6QyxRQUFRO01BRWpCLFlBQW9CLGtCQUE0QztBQUM1RCxjQUFLO0FBRFcsYUFBQSxtQkFBQTtBQUtoQixhQUFLLGlCQUFpQixDQUFDLFlBQVksYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLFlBQVk7QUFDdkosYUFBSyxTQUFTLFNBQVMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxFQUFFLEtBQUssWUFBWSxVQUFVLEdBQUcsR0FBRyxNQUFNLENBQUMsRUFBRSxLQUFLLFlBQVksR0FBRyxDQUFDO01BQ3ZHO01BRUEsWUFBWSxTQUFzQjtBQUM5QixZQUFJLFFBQVEsa0JBQWtCO0FBQzFCLGVBQUssY0FBYyxRQUFRLGlCQUFpQixhQUFhLGVBQWUsQ0FBQSxDQUFFO0FBQzFFLGVBQUssbUJBQW1CLFFBQVEsaUJBQWlCLGFBQWEsMEJBQTBCLENBQUEsQ0FBRTs7TUFFbEc7TUFPQSxtQkFBbUIsTUFBYztBQUM3QixZQUFJO0FBQ0osYUFBSyxVQUFVLENBQUE7QUFDZixhQUFLLFFBQVEsQ0FBQyxPQUFPLGFBQVk7QUFDN0IsMEJBQWdCO1lBQ1osTUFBTSxLQUFLLGVBQWUsUUFBUTtZQUNsQzs7QUFFSixlQUFLLFFBQVEsS0FBSyxhQUFhO1FBQ25DLENBQUM7QUFDRCxhQUFLLDJCQUEyQixLQUFLLE9BQU8sQ0FBQyxTQUFTLFlBQVksVUFBVSxTQUFTLENBQUM7QUFDdEYsYUFBSyxVQUFVLENBQUMsR0FBRyxLQUFLLE9BQU87TUFDbkM7TUFPUSxjQUFjLGFBQXdDO0FBQzFELGFBQUssYUFBYSxDQUFBO0FBRWxCLGNBQU0sUUFBUSxDQUFDLEdBQUcsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUU7QUFDcEQsWUFBSTtBQUNKLFlBQUk7QUFDSixjQUFNLFFBQVEsQ0FBQyxzQkFBcUI7QUFDaEMsbUNBQXlCLEtBQUssaUJBQWlCLGtCQUFrQixJQUFJLE1BQU0sbUJBQW1CLG9CQUFvQixFQUFFLEdBQUcsV0FBVztBQUNsSSxxQ0FBMkI7WUFDdkIsV0FBVyx1QkFBdUIsT0FBTyxDQUFDLGVBQWUsV0FBVyxXQUFXLGlCQUFpQixTQUFTLEVBQUU7WUFDM0csUUFBUSx1QkFBdUIsT0FBTyxDQUFDLGVBQWUsV0FBVyxXQUFXLGlCQUFpQixNQUFNLEVBQUU7WUFDckcsTUFBTSx1QkFBdUIsT0FBTyxDQUFDLGVBQWUsV0FBVyxXQUFXLGlCQUFpQixJQUFJLEVBQUU7O0FBRXJHLGVBQUssV0FBVyxLQUFLLHdCQUF3QjtRQUNqRCxDQUFDO01BQ0w7TUFNQSxhQUFhLE9BQWE7QUFDdEIsY0FBTSxRQUFRLEtBQUssZUFBZSxRQUFRLEtBQUs7QUFDL0MsZUFBTyxLQUFLLFdBQVcsS0FBSztNQUNoQztNQU9BLFNBQVMsT0FBVTtBQUNmLGNBQU0sV0FBVyxNQUFNO0FBQ3ZCLGNBQU0saUJBQWlCLFNBQVMsUUFBUSxHQUFHO0FBQzNDLGNBQU0sYUFBYSxTQUFTLFNBQVMsTUFBTSxHQUFHLGNBQWMsR0FBRyxFQUFFO0FBQ2pFLGNBQU0sYUFBYSxTQUFTLFNBQVMsTUFBTSxpQkFBaUIsR0FBRyxTQUFTLFNBQVMsQ0FBQyxHQUFHLEVBQUU7QUFFdkYsYUFBSyxtQkFBbUIsS0FBSyxJQUFJLE1BQU0sWUFBWSxVQUFVLENBQUM7TUFDbEU7O3lCQS9GUyxnQ0FBNkIsaUNBQUEsMEJBQUEsQ0FBQTtNQUFBO2tFQUE3QixnQ0FBNkIsV0FBQSxDQUFBLENBQUEsNEJBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxrQkFBQSxvQkFBQSx1QkFBQSx3QkFBQSxHQUFBLFNBQUEsRUFBQSxvQkFBQSxxQkFBQSxHQUFBLFVBQUEsQ0FBQSwyQ0FBQSxtQ0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSx3QkFBQSxHQUFBLENBQUEsR0FBQSw4QkFBQSxHQUFBLENBQUEsR0FBQSxtQ0FBQSxHQUFBLENBQUEsR0FBQSw4QkFBQSxHQUFBLENBQUEsR0FBQSw2QkFBQSxHQUFBLENBQUEsR0FBQSwrQkFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLDZCQUFBLEdBQUEsQ0FBQSxHQUFBLGdDQUFBLGFBQUEsR0FBQSxDQUFBLGFBQUEsY0FBQSxRQUFBLGdFQUFBLEdBQUEsQ0FBQSxnQkFBQSxFQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsUUFBQSxVQUFBLFdBQUEsU0FBQSxTQUFBLHVCQUFBLGFBQUEsaUJBQUEsUUFBQSxHQUFBLENBQUEsbUJBQUEsRUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHVDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDdEIxQyxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsQ0FBQTs7QUFDSixVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsRUFBQTtBQUNKLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxFQUFBOztBQUNKLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxFQUFBO0FBQ0osVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEVBQUE7O0FBQ0osVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEVBQUE7QUFDSixVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsRUFBQTs7QUFDSixVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsRUFBQTs7QUFDSixVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsRUFBQTs7QUFDSixVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsRUFBQTs7QUFDSixVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsRUFBQTs7QUFDSixVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsRUFBQTtBQUNKLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFFQSxVQUFBLHNCQUFBLElBQUEsVUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEVBQUE7O0FBQ0EsVUFBQSx5QkFBQSxJQUFBLGlCQUFBLENBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLEdBQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSwyQkFBQSxFQUFBO0FBVUksVUFBQSwwQkFBQSxVQUFBLFNBQUEsa0ZBQUEsUUFBQTtBQUFBLG1CQUFVLElBQUEsU0FBQSxNQUFBO1VBQWdCLENBQUE7QUFFMUIsVUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSwwQkFBQSxJQUFBLHVEQUFBLElBQUEsSUFBQSxlQUFBLE1BQUEsSUFBQSxxQ0FBQTtBQVdKLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsSUFBQTs7Ozs7QUFqRmdCLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsa0NBQUEsc0JBQUEsMkJBQUEsR0FBQSxJQUFBLG1EQUFBLEdBQUEsZ0JBQUE7QUFHQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLGtDQUFBLHNCQUFBLElBQUEseUJBQUEsT0FBQSxPQUFBLElBQUEsc0JBQUEsNkJBQUEsZ0JBQUE7QUFLQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLGtDQUFBLHNCQUFBLDJCQUFBLElBQUEsSUFBQSx5Q0FBQSxHQUFBLGdCQUFBO0FBR0EsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxrQ0FBQSx1QkFBQSxJQUFBLHlCQUFBLE9BQUEsT0FBQSxJQUFBLHNCQUFBLHFCQUFBLE9BQUEsT0FBQSxJQUFBLHNCQUFBLGtCQUFBLFFBQUEsQ0FBQSxLQUFBLE1BQUEsZ0JBQUE7QUFLQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLGtDQUFBLHNCQUFBLDJCQUFBLElBQUEsSUFBQSx5Q0FBQSxHQUFBLGdCQUFBO0FBR0EsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxrQ0FBQSx1QkFBQSxJQUFBLHlCQUFBLE9BQUEsT0FBQSxJQUFBLHNCQUFBLHFCQUFBLE9BQUEsT0FBQSxJQUFBLHNCQUFBLGtCQUFBLFFBQUEsQ0FBQSxLQUFBLE1BQUEsZ0JBQUE7QUFLQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLGtDQUFBLHNCQUFBLDJCQUFBLElBQUEsSUFBQSxnQ0FBQSxHQUFBLGdCQUFBO0FBR0EsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxrQ0FBQSxzQkFBQSwyQkFBQSxJQUFBLElBQUEsSUFBQSxvQkFBQSxPQUFBLE9BQUEsSUFBQSxpQkFBQSxVQUFBLFlBQUEsS0FBQSxHQUFBLGdCQUFBO0FBS0EsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxrQ0FBQSxzQkFBQSwyQkFBQSxJQUFBLElBQUEsaUNBQUEsR0FBQSxnQkFBQTtBQUdBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsa0NBQUEsc0JBQUEsMkJBQUEsSUFBQSxJQUFBLElBQUEsb0JBQUEsT0FBQSxPQUFBLElBQUEsaUJBQUEsZUFBQSxPQUFBLE9BQUEsSUFBQSxpQkFBQSxZQUFBLGVBQUEsR0FBQSxrQkFBQSxLQUFBLEdBQUEsZ0JBQUE7QUFLQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLGtDQUFBLHNCQUFBLDJCQUFBLElBQUEsSUFBQSxpQ0FBQSxHQUFBLGdCQUFBO0FBR0EsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxrQ0FBQSx1QkFBQSxXQUFBLElBQUEseUJBQUEsT0FBQSxPQUFBLElBQUEsc0JBQUEsZUFBQSxRQUFBLGFBQUEsU0FBQSxXQUFBLFdBQUEsZ0JBQUE7QUFPSixVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLGtDQUFBLGtCQUFBLDJCQUFBLElBQUEsSUFBQSw4Q0FBQSxHQUFBLGdCQUFBO0FBS0ksVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxjQUFBLEtBQUEsRUFBb0IsUUFBQSwrQkFBQSxJQUFBLEtBQUEsSUFBQSxXQUFBLENBQUEsRUFBQSxVQUFBLElBQUEsUUFBQSxFQUFBLFdBQUEsSUFBQSxPQUFBLEVBQUEsU0FBQSxJQUFBLEVBQUEsU0FBQSxJQUFBLEVBQUEsdUJBQUEsSUFBQSxtQkFBQSxFQUFBLGFBQUEsSUFBQSxTQUFBLEVBQUEsaUJBQUEsSUFBQTs7Ozs7c0ZEckN2QiwrQkFBNkIsRUFBQSxXQUFBLGdDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRXRCMUMsSUFBYTtBQUFiOztBQUFNLElBQU8sb0JBQVAsTUFBd0I7TUFJMUI7TUFLQTtNQUtBO01BRUEsWUFBWSxxQkFBNkIsY0FBc0IsYUFBbUI7QUFDOUUsYUFBSyxzQkFBc0I7QUFDM0IsYUFBSyxlQUFlO0FBQ3BCLGFBQUssY0FBYztNQUN2QjtNQUtBLFdBQVE7QUFDSixlQUFPO1VBQ0gscUJBQXFCLEtBQUssb0JBQW9CLFNBQVE7VUFDdEQsY0FBYyxLQUFLLGFBQWEsU0FBUTtVQUN4QyxhQUFhLEtBQUssWUFBWSxTQUFROztNQUU5Qzs7Ozs7O0FDL0JKLFNBQVMsYUFBQUksa0JBQXlCO0FBQ2xDLFNBQVMsZ0JBQWdCLGNBQWM7QUFTdkMsU0FBUyxtQkFBbUI7QUFPNUIsU0FBUyxPQUFBQyxZQUFXO0FBQ3BCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsa0JBQUFDLGlCQUFnQix5QkFBQUMsd0JBQXVCLHdCQUF3QjtBQUt4RSxTQUFTLFlBQUFDLGlCQUFnQjs7Ozs7Ozs7OztBQ1RMLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBOEMsSUFBQSwwQkFBQSxTQUFBLFNBQUEsK0VBQUE7QUFBQSxNQUFBLDZCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUE7QUFBQSxhQUFTLDJCQUFBLE9BQUEsWUFBQSxDQUFhO0lBQUEsQ0FBQTtBQUNoRSxJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsc0JBQUEsQ0FBQTs7QUFBNEQsSUFBQSw0QkFBQTtBQUN0RSxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLG9CQUFBOzs7QUFGYyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDJCQUFBLEdBQUEsR0FBQSxtQ0FBQSxDQUFBOzs7OztBQWlDRixJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLDRCQUFBOzs7Ozs7QUF0QkosSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXVFLElBQUEsc0JBQUEsR0FBQSw2QkFBQTtBQUEyQixJQUFBLDRCQUFBO0FBQ3RHLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTJELElBQUEsMEJBQUEsU0FBQSxTQUFBLCtFQUFBO0FBQUEsWUFBQSxjQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFlBQUEsWUFBQTtBQUFBLGFBQVMsMkJBQUEsVUFBQSxRQUFBLENBQWU7SUFBQSxDQUFBO0FBQUUsSUFBQSw0QkFBQTtBQUN6RixJQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxLQUFBLEVBQUE7QUFBdUUsSUFBQSxzQkFBQSxJQUFBLDZEQUFBO0FBQTJELElBQUEsNEJBQUE7QUFDbEksSUFBQSxzQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxTQUFBLEVBQUE7QUFLSSxJQUFBLDBCQUFBLFVBQUEsU0FBQSxnRkFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQTtBQUFBLGFBQVUsMkJBQUEsUUFBQSxxQ0FBQSxDQUFzQztJQUFBLENBQUE7QUFMcEQsSUFBQSw0QkFBQTtBQU9BLElBQUEsc0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBcUUsSUFBQSxzQkFBQSxFQUFBOztBQUVuRSxJQUFBLDRCQUFBO0FBQ04sSUFBQSxzQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMEJBQUEsSUFBQSxxRUFBQSxHQUFBLENBQUE7QUFHSixJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBNkMsSUFBQSwwQkFBQSxTQUFBLFNBQUEsZ0ZBQUE7QUFBQSxZQUFBLGNBQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsWUFBQSxZQUFBO0FBQUEsYUFBUywyQkFBQSxVQUFBLE1BQVksU0FBUyxDQUFDO0lBQUEsQ0FBQTtBQUN4RSxJQUFBLHNCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsUUFBQSxFQUFBO0FBQXdFLElBQUEsc0JBQUEsSUFBQSxVQUFBO0FBQVEsSUFBQSw0QkFBQTtBQUNwRixJQUFBLHNCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxvQkFBQTs7OztBQWhCZ0IsSUFBQSx5QkFBQSxFQUFBO0FBQUEsSUFBQSwwQkFBQSxXQUFBLE9BQUEsOEJBQUE7QUFHaUUsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwyQkFBQSxJQUFBLEdBQUEsdURBQUEsQ0FBQTtBQUl6RSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxpQ0FBQSxLQUFBLEVBQUE7Ozs7OztBQVdKLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFHSSxJQUFBLDBCQUFBLFNBQUEsU0FBQSwrRUFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQTtBQUFBLFlBQUEsTUFBQSwyQkFBQSxFQUFBO0FBQUEsYUFBUywyQkFBQSxRQUFBLGlCQUFBLEdBQUEsQ0FBbUM7SUFBQSxDQUFBO0FBRzVDLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBd0UsSUFBQSxzQkFBQSxHQUFBLFVBQUE7QUFBUSxJQUFBLDRCQUFBO0FBQ3BGLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsb0JBQUE7Ozs7QUFQUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLG9CQUFBLE9BQUEsY0FBQSxnQkFBQSxFQUFtRCxxQkFBQSxPQUFBLG1CQUFBOzs7Ozs7QUFTdkQsSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsc0JBQUEsR0FBQSxVQUFBO0FBQVEsSUFBQSw0QkFBQTtBQUNsQixJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBc0IsSUFBQSwwQkFBQSxTQUFBLFNBQUEsZ0ZBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUE7QUFBQSxhQUFTLDJCQUFBLFFBQUEsOEJBQUEsQ0FBK0I7SUFBQSxDQUFBO0FBQWtCLElBQUEsc0JBQUEsSUFBQSxNQUFBO0FBQUksSUFBQSw0QkFBQTtBQUNwRixJQUFBLHNCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBO0FBQXNCLElBQUEsMEJBQUEsU0FBQSxTQUFBLGdGQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDZCQUFBO0FBQUEsYUFBUywyQkFBQSxRQUFBLDZCQUFBLENBQThCO0lBQUEsQ0FBQTtBQUFrQixJQUFBLHNCQUFBLElBQUEsS0FBQTtBQUFHLElBQUEsNEJBQUE7QUFDdEYsSUFBQSxzQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsb0JBQUE7Ozs7OztBQTBCQSxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUF5RSxJQUFBLDBCQUFBLGlCQUFBLFNBQUEsb0ZBQUEsUUFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQTtBQUFBLGFBQUEsMkJBQUEsUUFBQSxzQkFBQSxNQUFBO0lBQUEsQ0FBQTtBQUF6RSxJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUEwSCxJQUFBLHNCQUFBLEdBQUEsdUJBQUE7QUFBcUIsSUFBQSw0QkFBQTtBQUNuSixJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLGdCQUFBOzs7O0FBSGlGLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsV0FBQSxPQUFBLG1CQUFBOzs7Ozs7QUFPckYsSUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLDBCQUFBLEVBQUE7QUFFSSxJQUFBLDBCQUFBLHdCQUFBLFNBQUEsNEdBQUEsUUFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQTtBQUFBLGFBQXdCLDJCQUFBLFFBQUEsMkJBQUEsTUFBQSxDQUFrQztJQUFBLENBQUEsRUFBQyxlQUFBLFNBQUEsbUdBQUEsUUFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQTtBQUFBLGFBRzVDLDJCQUFBLFFBQUEsdUJBQUEsTUFBQSxDQUE4QjtJQUFBLENBQUE7QUFHaEQsSUFBQSw0QkFBQTtBQUNELElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwwQkFBQSxFQUFBO0FBS0EsSUFBQSxzQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLDhCQUFBLEVBQUE7QUFJSSxJQUFBLDBCQUFBLHNCQUFBLFNBQUEsOEdBQUEsUUFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQTtBQUFBLGFBQXNCLDJCQUFBLFFBQUEsY0FBQSxNQUFBLENBQXFCO0lBQUEsQ0FBQTtBQUM5QyxJQUFBLDRCQUFBO0FBQ0wsSUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLFFBQUE7Ozs7QUFwQlksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxrQkFBQSxPQUFBLGNBQUEsRUFBaUMsZUFBQSxPQUFBLGtCQUFBLEVBQUEsVUFBQSxPQUFBLGFBQUEsRUFBQSxZQUFBLE9BQUEsb0JBQUEsRUFBQSxpQkFBQSxPQUFBLGtCQUFBO0FBU2pDLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsVUFBQSxPQUFBLGNBQUEsRUFBeUIsY0FBQSxPQUFBLGlCQUFBLGNBQUEsT0FBQSxzQkFBQSxJQUFBLE1BQUEsRUFBQSxZQUFBLE9BQUEsUUFBQTtBQUt6QixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFVBQUEsQ0FBQSxPQUFBLGNBQUEsRUFBMEIsb0JBQUEsT0FBQSxnQkFBQSxFQUFBLHlCQUFBLE9BQUEscUJBQUE7Ozs7O0FBVTFCLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsR0FBQTtBQUFHLElBQUEsc0JBQUEsQ0FBQTtBQUFnQyxJQUFBLDRCQUFBO0FBQ3ZDLElBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsZ0JBQUE7Ozs7QUFGVyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLFFBQUEsMEJBQUE7Ozs7O0FBSVAsSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsQ0FBQTs7QUFDSixJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLGdCQUFBOzs7QUFGUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLDBCQUFBLDJCQUFBLEdBQUEsR0FBQSw2QkFBQSxHQUFBLG9CQUFBOzs7OztBQVhaLElBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsMEJBQUEsR0FBQSxvRUFBQSxJQUFBLENBQUEsRUFPQyxHQUFBLG9FQUFBLEdBQUEsQ0FBQTtBQU1MLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsUUFBQTs7OztBQWRRLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLHNCQUFBLElBQUEsRUFBQTtBQVFBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxDQUFBLE9BQUEsc0JBQUEsSUFBQSxFQUFBOzs7QURqSlosSUFzQ2E7QUF0Q2I7O0FBR0E7QUFDQTtBQUNBO0FBRUE7QUFPQTtBQUNBO0FBQ0E7QUFJQTtBQUVBO0FBQ0E7QUFFQTs7Ozs7Ozs7Ozs7Ozs7QUFhTSxJQUFPLCtCQUFQLE1BQU8sOEJBQTRCO01BMkZ6QjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BakdaO01BS0E7TUFLQTtNQUtBLHNCQUFzQjtNQUV0Qiw2QkFBNkI7TUFLN0I7TUFLQSxpQkFBaUI7TUFLakIsY0FBYztNQUtkLHNCQUFzQjtNQUt0QixzQkFBc0I7TUFLdEIsZUFBZTtNQUtmLGNBQWM7TUFLZCxxQkFBcUI7TUFLckIsb0JBQW9CO01BSXBCO01BQ0EscUJBQXFCO01BSXJCLGdCQUFnQjtNQUtoQixpQ0FBaUM7TUFFeEIsZ0JBQWdCO01BQ2hCLGNBQWMsYUFBYTtNQUdwQyxtQkFBbUI7TUFDbkIsd0JBQXdCRDtNQUN4QixpQkFBaUJEO01BRWpCLFlBQ1ksT0FDQSxRQUNBLHlCQUNBLDRCQUNBLHFCQUNBLGtCQUNBLGtCQUNBLGtCQUNBLHdCQUNBLGNBQ0EsY0FBMEI7QUFWMUIsYUFBQSxRQUFBO0FBQ0EsYUFBQSxTQUFBO0FBQ0EsYUFBQSwwQkFBQTtBQUNBLGFBQUEsNkJBQUE7QUFDQSxhQUFBLHNCQUFBO0FBQ0EsYUFBQSxtQkFBQTtBQUNBLGFBQUEsbUJBQUE7QUFDQSxhQUFBLG1CQUFBO0FBQ0EsYUFBQSx5QkFBQTtBQUNBLGFBQUEsZUFBQTtBQUNBLGFBQUEsZUFBQTtNQUNUO01BRUgsV0FBUTtBQUNKLGFBQUssTUFBTSxLQUFLLFVBQVUsQ0FBQyxFQUFFLFNBQVEsTUFBTTtBQUN2QyxlQUFLLFdBQVc7QUFFaEIsZUFBSyxrQ0FBaUM7QUFDdEMsZUFBSywwQkFBeUI7UUFDbEMsQ0FBQztNQUNMO01BTUEsb0NBQWlDO0FBQzdCLGNBQU0sUUFBUSxLQUFLLDJCQUEwQjtBQUM3QyxhQUFLLGlCQUFpQixVQUFVLEtBQUs7QUFDckMsYUFBSyxpQkFDQSxRQUFRLEtBQUssRUFDYixLQUFLRCxLQUFJLENBQUMseUJBQStDLEtBQUssaUNBQWlDLG9CQUFvQixDQUFDLENBQUMsRUFDckgsVUFBUztNQUNsQjtNQUtBLDZCQUEwQjtBQUN0QixZQUFJLFFBQVE7QUFDWixnQkFBUSxLQUFLLFNBQVMsTUFBTTtVQUN4QixLQUFLLGFBQWE7QUFDZCxxQkFBUztBQUNUO1VBQ0osS0FBSyxhQUFhO0FBQ2QscUJBQVM7QUFDVDtVQUNKLEtBQUssYUFBYTtBQUNkLHFCQUFTO0FBQ1Q7O0FBRVIsZUFBTyxRQUFRLE1BQU0sS0FBSyxTQUFTLEtBQUs7TUFDNUM7TUFRQSxpQ0FBaUMsc0JBQTBDO0FBQ3ZFLGNBQU0sRUFBRSxPQUFPLFNBQVEsSUFBSztBQUM1QixhQUFLLHNCQUFzQixVQUFVO0FBQ3JDLGFBQUssNkJBQTZCLFVBQVUsWUFBWSxXQUFXLEtBQUssaUJBQWlCLFFBQVEsK0JBQStCO0FBRWhJLFlBQUksVUFBVSxhQUFhO0FBQ3ZCLGVBQUssNkJBQTZCLEtBQUssaUJBQWlCLFFBQVEsdUNBQXVDO0FBQ3ZHLGVBQUssMEJBQXlCOztNQUV0QztNQUtBLDRCQUF5QjtBQUNyQixhQUFLLHNCQUFzQjtBQUUzQixnQkFBUSxLQUFLLFNBQVMsTUFBTTtVQUN4QixLQUFLLGFBQWEsVUFBVTtBQUN4QixpQkFBSyx3QkFBd0IsMEJBQTBCLEtBQUssU0FBUyxFQUFHLEVBQUUsVUFBVTtjQUNoRixNQUFNLENBQUMsV0FBVyxLQUFLLHVCQUF1QixNQUFNO2NBQ3BELE9BQU8sTUFBTSxLQUFLLFlBQVc7YUFDaEM7QUFDRDs7VUFFSixLQUFLLGFBQWEsYUFBYTtBQUMzQixpQkFBSywyQkFBMkIsMEJBQTBCLEtBQUssU0FBUyxFQUFHLEVBQUUsVUFBVTtjQUNuRixNQUFNLENBQUMsV0FBVyxLQUFLLHVCQUF1QixNQUFNO2NBQ3BELE9BQU8sTUFBTSxLQUFLLFlBQVc7YUFDaEM7QUFDRDs7VUFFSixLQUFLLGFBQWEsTUFBTTtBQUNwQixpQkFBSyxvQkFBb0IsMEJBQTBCLEtBQUssU0FBUyxFQUFHLEVBQUUsVUFBVTtjQUM1RSxNQUFNLENBQUMsV0FBVyxLQUFLLHVCQUF1QixNQUFNO2NBQ3BELE9BQU8sTUFBTSxLQUFLLFlBQVc7YUFDaEM7QUFDRDs7VUFFSixTQUFTO0FBQ0wsaUJBQUssc0JBQXNCOzs7TUFHdkM7TUFFQSxrQkFBZTtBQUNYLGNBQU0sZUFBZSxLQUFLLHFCQUFxQixLQUFLLGVBQWU7QUFDbkUsY0FBTSxjQUFjLEtBQUssb0JBQW9CLEtBQUssY0FBYztBQUVoRSxjQUFNLFVBQVUsSUFBSSxrQkFBa0IsS0FBSyxxQkFBcUIsY0FBYyxXQUFXO0FBRXpGLFlBQUksS0FBSyxTQUFTLFNBQVMsYUFBYSxVQUFVO0FBQzlDLGVBQUssd0JBQXdCLE9BQU87bUJBQzdCLEtBQUsscUJBQXFCO0FBQ2pDLGVBQUssMkJBQTJCLE9BQU87ZUFDcEM7QUFDSCxlQUFLLHFCQUFxQixPQUFPOztNQUV6QztNQUVBLHVCQUF1QixJQUFVO0FBQzdCLGFBQUssdUJBQXVCO0FBQzVCLGFBQUssaUJBQWlCO01BQzFCO01BS0EsMkJBQTJCLFNBQTJCO0FBQ2xELGFBQUssc0JBQXNCO0FBRTNCLGFBQUssMkJBQTJCLDJCQUEyQixLQUFLLFNBQVMsSUFBSyxPQUFPLEVBQUUsVUFBVTtVQUM3RixNQUFNLENBQUMsYUFBZ0M7QUFDbkMsaUJBQUssc0JBQXNCO0FBQzNCLHdDQUE0QixRQUFRO1VBQ3hDO1VBQ0EsT0FBTyxDQUFDLFVBQTRCO0FBRWhDLGtCQUFNLGVBQWUsTUFBTSxRQUFRLElBQUksb0JBQW9CO0FBQzNELGdCQUFJLGlCQUFpQiw4QkFBOEI7QUFDL0MsbUJBQUssYUFBYSxTQUFTO2dCQUN2QixNQUFNLFVBQVU7Z0JBQ2hCLFNBQVM7Z0JBQ1Qsb0JBQW9CO2VBQ3ZCOztBQUVMLGlCQUFLLFlBQVc7VUFDcEI7U0FDSDtNQUNMO01BRUEsd0JBQXFCO0FBQ2pCLGVBQU8sS0FBSyxVQUFVLFNBQVMsYUFBYTtNQUNoRDtNQUtBLHFCQUFxQixTQUEyQjtBQUM1QyxhQUFLLHNCQUFzQjtBQUUzQixZQUFJLEtBQUssU0FBUyxTQUFTLGFBQWEsTUFBTTtBQUMxQyxlQUFLLG9CQUFvQixnQkFBZ0IsS0FBSyxTQUFTLElBQUssT0FBTyxFQUFFLFVBQVU7WUFDM0UsTUFBTSxDQUFDLFdBQVcsS0FBSyx1QkFBdUIsTUFBTTtZQUNwRCxPQUFPLE1BQU0sS0FBSyxZQUFXO1dBQ2hDO2VBQ0U7QUFDSCxlQUFLLDJCQUEyQixnQkFBZ0IsS0FBSyxTQUFTLElBQUssT0FBTyxFQUFFLFVBQVU7WUFDbEYsTUFBTSxDQUFDLFdBQVcsS0FBSyx1QkFBdUIsTUFBTTtZQUNwRCxPQUFPLE1BQU0sS0FBSyxZQUFXO1dBQ2hDOztNQUVUO01BRUEsY0FBVztBQUNQLGFBQUssc0JBQXNCO01BQy9CO01BS0Esd0JBQXdCLFNBQTJCO0FBQy9DLGFBQUssc0JBQXNCO0FBRTNCLGFBQUssd0JBQXdCLGdCQUFnQixLQUFLLFNBQVMsSUFBSyxPQUFPLEVBQUUsVUFBVTtVQUMvRSxNQUFNLENBQUMsV0FBMEQsS0FBSyx1QkFBdUIsTUFBTTtVQUNuRyxPQUFPLE1BQU0sS0FBSyxZQUFXO1NBQ2hDO01BQ0w7TUFFQSx1QkFBdUIsUUFBNEU7QUFDL0YsYUFBSyxzQkFBc0I7QUFFM0IsWUFBSSxRQUFRLGtCQUFrQixhQUFhO0FBQ3ZDLGVBQUsseUJBQXlCLE9BQU8sZ0JBQWdCO0FBQ3JELGVBQUssaUJBQWlCOztBQUcxQixhQUFLLG1CQUFtQixPQUFPO0FBQy9CLGFBQUssd0JBQXdCLE9BQU87QUFDcEMsYUFBSyxxQkFBcUIsUUFBUSxrQkFBa0I7TUFDeEQ7TUFFQSx5QkFBeUIsUUFBNkI7QUFDbEQsZUFBTyxjQUFjLE9BQU8sWUFBWSxLQUFLLENBQUMsR0FBRyxNQUFLO0FBRWxELGNBQUksRUFBRSxhQUFhLEVBQUUsZUFBZSxHQUFHO0FBQ25DLG1CQUFPLEVBQUUsS0FBSyxFQUFFO2lCQUNiO0FBQ0gsbUJBQU8sRUFBRSxhQUFhLEVBQUU7O1FBRWhDLENBQUM7TUFDTDtNQUtBLGdDQUE2QjtBQUN6QixjQUFNLE9BQU8sS0FBSyxVQUFVLEtBQUssZ0JBQWdCO0FBQ2pELGNBQU0sT0FBTyxJQUFJLEtBQUssQ0FBQyxJQUFJLEdBQUcsRUFBRSxNQUFNLG1CQUFrQixDQUFFO0FBRTFELHFCQUFhLE1BQU0scUJBQXFCLEtBQUssU0FBUyxJQUFJLGFBQWEsS0FBSyxTQUFTLEVBQUUsT0FBTztNQUNsRztNQUtBLCtCQUE0QjtBQUN4QixZQUFJLEtBQUssb0JBQW9CLEtBQUssaUJBQWlCLFlBQVksU0FBUyxHQUFHO0FBQ3ZFLGdCQUFNLGNBQWMsSUFBSSxZQUFZO1lBQ2hDLGdCQUFnQjtZQUNoQixjQUFjO1lBQ2Qsa0JBQWtCO1lBQ2xCLFlBQVk7WUFDWixPQUFPLGlDQUFpQyxLQUFLLFNBQVMsRUFBRSxLQUFLLEtBQUssU0FBUyxLQUFLO1lBQ2hGLFVBQVUscUJBQXFCLEtBQUssU0FBUyxJQUFJLGFBQWEsS0FBSyxTQUFTLEVBQUU7WUFDOUUsYUFBYTtZQUNiLFFBQVE7WUFDUixTQUFTLENBQUMsY0FBYyxVQUFVLGlCQUFpQixnQkFBZ0IsV0FBVyxVQUFVLGlCQUFpQixnQkFBZ0IsV0FBVyxRQUFRO1dBQy9JO0FBRUQsZ0JBQU0sVUFBVyxLQUFLLGlCQUFpQixZQUEwRixJQUFJLENBQUMsZUFBYztBQUNoSixtQkFBTyxPQUFPLE9BQU87Y0FDakIsWUFBWSxXQUFXO2NBQ3ZCLFFBQVEsV0FBVztjQUNuQixpQkFBaUIsV0FBVyxZQUFZO2NBQ3hDLGdCQUFnQixXQUFXLFlBQVk7Y0FDdkMsV0FBVyxXQUFXLFlBQVk7Y0FDbEMsVUFBVSxXQUFXLFlBQVk7Y0FDakMsaUJBQWlCLFdBQVcsWUFBWTtjQUN4QyxnQkFBZ0IsV0FBVyxZQUFZO2NBQ3ZDLFdBQVcsV0FBVyxZQUFZO2NBQ2xDLFVBQVUsV0FBVyxZQUFZO2FBQ3BDO1VBQ0wsQ0FBQztBQUVELHNCQUFZLFlBQVksT0FBTzs7TUFFdkM7TUFLQSx3QkFBcUI7QUFDakIsZ0JBQVEsS0FBSyxTQUFTLE1BQU07VUFDeEIsS0FBSyxhQUFhLGFBQWE7QUFDM0IsbUJBQU87O1VBRVgsS0FBSyxhQUFhLE1BQU07QUFDcEIsbUJBQU87O1VBRVgsS0FBSyxhQUFhLFVBQVU7QUFDeEIsbUJBQU87OztNQUduQjtNQU9BLGNBQWMsT0FBWTtBQUN0QixhQUFLLHFCQUFxQixLQUFLLGlCQUFpQixrQkFBa0IsT0FBTyxLQUFLLGtCQUFrQixXQUFXO0FBQzNHLGNBQU0sUUFBUSxLQUFLLGtCQUFrQixZQUFZLFFBQVEsS0FBSyxtQkFBbUIsQ0FBQyxDQUFDLEtBQUs7QUFDeEYsYUFBSyxnQkFBZ0IsVUFBVSxLQUFLLFFBQVE7QUFDNUMsYUFBSyxxQkFBcUI7TUFDOUI7TUFLQSxjQUFXO0FBQ1AsYUFBSyxxQkFBcUIsS0FBSyxrQkFBa0I7QUFDakQsYUFBSyxxQkFBcUI7QUFDMUIsYUFBSyxnQkFBZ0I7TUFDekI7TUFPQSwyQkFBMkIsTUFBYTtBQUNwQyxhQUFLLFlBQVc7QUFDaEIsYUFBSywwQkFBeUI7QUFDOUIsYUFBSyxpQkFBaUI7TUFDMUI7TUFLQSx3QkFBcUI7QUFFakIsZUFBTyxLQUFLLG1CQUFvQixPQUFPLENBQUMsZUFBZSxXQUFXLE9BQU8sS0FBSyxvQkFBb0IsRUFBRSxDQUFDO01BQ3pHO01BS0EsdUNBQW9DO0FBQ2hDLGFBQUssaUNBQWlDLENBQUMsS0FBSztNQUNoRDtNQUtBLG9CQUFpQjtBQUNiLGFBQUssdUJBQXVCLGtCQUFrQixLQUFLLFNBQVMsSUFBSyxLQUFLLGlCQUFrQixJQUFLLEtBQUssOEJBQThCLEVBQUUsVUFBVTtVQUN4SSxNQUFNLE1BQUs7QUFDUCxnQkFBSSxLQUFLLGdDQUFnQztBQUNyQyxtQkFBSyxpQ0FBaUM7QUFDdEMsbUJBQUssbUJBQW1CO21CQUNyQjtBQUNILG1CQUFLLGlDQUFpQztBQUN0QyxtQkFBSywwQkFBeUI7O1VBRXRDO1NBQ0g7TUFDTDtNQU1BLGlCQUFpQixTQUFZO0FBQ3pCLGFBQUssYUFBYSxLQUFLLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQyxXQUFrQjtBQUMzRCxjQUFJLFdBQVcsV0FBVztBQUN0QixpQkFBSyxrQkFBaUI7O1FBRTlCLENBQUM7TUFDTDs7eUJBMWJTLCtCQUE0QixpQ0FBQSxrQkFBQSxHQUFBLGlDQUFBLFVBQUEsR0FBQSxpQ0FBQSx1QkFBQSxHQUFBLGlDQUFBLDBCQUFBLEdBQUEsaUNBQUEsbUJBQUEsR0FBQSxpQ0FBQSxtQkFBQSxHQUFBLGlDQUFBLG1CQUFBLEdBQUEsaUNBQUEsMEJBQUEsR0FBQSxpQ0FBQSxzQkFBQSxHQUFBLGlDQUFBLFdBQUEsR0FBQSxpQ0FBQSxZQUFBLENBQUE7TUFBQTtrRUFBNUIsK0JBQTRCLFdBQUEsQ0FBQSxDQUFBLDBCQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsc0JBQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsR0FBQSxDQUFBLEdBQUEsdUJBQUEsR0FBQSxDQUFBLEdBQUEsNEJBQUEsR0FBQSxDQUFBLEdBQUEseUJBQUEsYUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsNkJBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxNQUFBLHFCQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSw2QkFBQSxHQUFBLENBQUEsR0FBQSxvQkFBQSxPQUFBLGVBQUEsR0FBQSxvQkFBQSxxQkFBQSxPQUFBLEdBQUEsQ0FBQSxxQkFBQSxFQUFBLEdBQUEsQ0FBQSxHQUFBLDZCQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxHQUFBLENBQUEsZ0JBQUEsNkNBQUEsR0FBQSx5QkFBQSxHQUFBLENBQUEsYUFBQSxlQUFBLEdBQUEsUUFBQSxZQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsWUFBQSxJQUFBLE9BQUEsS0FBQSxPQUFBLE9BQUEsUUFBQSxLQUFBLE1BQUEsbUNBQUEsR0FBQSxnQkFBQSxHQUFBLFdBQUEsZUFBQSxHQUFBLENBQUEsT0FBQSxzQkFBQSxHQUFBLHVCQUFBLFlBQUEsR0FBQSxDQUFBLFFBQUEsWUFBQSxNQUFBLHNCQUFBLFdBQUEsSUFBQSxHQUFBLDhCQUFBLG9CQUFBLEdBQUEsV0FBQSxlQUFBLEdBQUEsQ0FBQSxnQkFBQSxzQ0FBQSxHQUFBLDJCQUFBLGtCQUFBLEdBQUEsQ0FBQSxZQUFBLElBQUEsUUFBQSxVQUFBLE9BQUEsS0FBQSxPQUFBLE9BQUEsTUFBQSw0QkFBQSxHQUFBLGdCQUFBLEdBQUEsWUFBQSxXQUFBLGVBQUEsR0FBQSxDQUFBLE9BQUEscUJBQUEsR0FBQSx1QkFBQSxZQUFBLEdBQUEsQ0FBQSxRQUFBLFlBQUEsTUFBQSxxQkFBQSxXQUFBLElBQUEsR0FBQSw4QkFBQSxvQkFBQSxHQUFBLFdBQUEsZUFBQSxHQUFBLENBQUEsT0FBQSxxQkFBQSxnQkFBQSxxQ0FBQSxHQUFBLDJCQUFBLGtCQUFBLEdBQUEsQ0FBQSxZQUFBLElBQUEsUUFBQSxVQUFBLE9BQUEsS0FBQSxPQUFBLE9BQUEsTUFBQSwyQkFBQSxHQUFBLGdCQUFBLEdBQUEsWUFBQSxXQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsb0JBQUEsT0FBQSxZQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLGdCQUFBLG1EQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsY0FBQSxTQUFBLEdBQUEsYUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsZ0JBQUEsc0RBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxhQUFBLEdBQUEsQ0FBQSxNQUFBLGtDQUFBLFFBQUEsWUFBQSxHQUFBLG9CQUFBLEdBQUEsV0FBQSxRQUFBLEdBQUEsQ0FBQSxPQUFBLGtDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsT0FBQSxjQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEsb0RBQUEsR0FBQSxDQUFBLGdCQUFBLHVEQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxvQkFBQSxPQUFBLGNBQUEsR0FBQSxvQkFBQSxxQkFBQSxPQUFBLEdBQUEsQ0FBQSxlQUFBLEVBQUEsR0FBQSxDQUFBLE1BQUEsdUJBQUEscUJBQUEsSUFBQSxHQUFBLE9BQUEsaUJBQUEsV0FBQSxHQUFBLENBQUEsbUJBQUEsSUFBQSxtQkFBQSxxQkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLG1CQUFBLElBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxPQUFBLHVCQUFBLEdBQUEsdUJBQUEsWUFBQSxHQUFBLENBQUEsUUFBQSxZQUFBLE1BQUEsdUJBQUEsV0FBQSxJQUFBLEdBQUEsb0JBQUEsR0FBQSxXQUFBLGVBQUEsR0FBQSxDQUFBLE9BQUEsdUJBQUEsZ0JBQUEsNkNBQUEsR0FBQSx5QkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxlQUFBLFVBQUEsWUFBQSxpQkFBQSx3QkFBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsY0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsb0JBQUEseUJBQUEsb0JBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxhQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxrQkFBQSxnQkFBQSxxQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsd0JBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxzQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ3RDekMsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQTRDLFVBQUEsMEJBQUEsU0FBQSxTQUFBLDREQUFBO0FBQUEsbUJBQUEsSUFBQSxjQUFBLENBQUEsSUFBQTtVQUFBLENBQUE7QUFDeEMsVUFBQSxzQkFBQSxHQUFBLHdCQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxNQUFBO0FBQU0sVUFBQSxzQkFBQSxFQUFBOztBQUFvRSxVQUFBLDRCQUFBO0FBQzlFLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxNQUFBO0FBQU0sVUFBQSxzQkFBQSxFQUFBOztBQUF3RCxVQUFBLDRCQUFBO0FBQ2xFLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMEJBQUEsSUFBQSxzREFBQSxHQUFBLENBQUE7QUFLQSxVQUFBLDhCQUFBLElBQUEsVUFBQSxDQUFBO0FBR0ksVUFBQSwwQkFBQSxTQUFBLFNBQUEsaUVBQUE7QUFBQSxtQkFBUyxJQUFBLGdCQUFBO1VBQWlCLENBQUE7QUFHMUIsVUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE1BQUE7QUFBTSxVQUFBLHNCQUFBLEVBQUE7OztBQUFpSSxVQUFBLDRCQUFBO0FBQzNJLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDBCQUFBLElBQUEsc0RBQUEsSUFBQSxHQUFBLGVBQUEsTUFBQSxJQUFBLHFDQUFBO0FBK0JBLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMEJBQUEsSUFBQSxzREFBQSxHQUFBLENBQUEsRUFTQyxJQUFBLHNEQUFBLElBQUEsQ0FBQTtBQVlMLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUE4RixVQUFBLHNCQUFBLElBQUEsc0JBQUE7QUFBb0IsVUFBQSw0QkFBQTtBQUNsSCxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsV0FBQSxFQUFBOztBQUNBLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBbUgsVUFBQSwwQkFBQSxpQkFBQSxTQUFBLHNFQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLHNCQUFBO1VBQUEsQ0FBQTtBQUFuSCxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFtRyxVQUFBLDBCQUFBLGlCQUFBLFNBQUEsc0VBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEscUJBQUE7VUFBQSxDQUFBO0FBQW5HLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxFQUFBO0FBQXdHLFVBQUEsc0JBQUEsSUFBQSxlQUFBO0FBQWEsVUFBQSw0QkFBQTtBQUN6SCxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLFdBQUEsRUFBQTs7QUFDQSxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsU0FBQSxFQUFBO0FBQW9JLFVBQUEsMEJBQUEsaUJBQUEsU0FBQSxzRUFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSxlQUFBO1VBQUEsQ0FBQTtBQUFwSSxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFrRyxVQUFBLDBCQUFBLGlCQUFBLFNBQUEsc0VBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsb0JBQUE7VUFBQSxDQUFBO0FBQWxHLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsU0FBQSxFQUFBO0FBQWlJLFVBQUEsc0JBQUEsSUFBQSxjQUFBO0FBQVksVUFBQSw0QkFBQTtBQUNqSixVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLFdBQUEsRUFBQTs7QUFDQSxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsU0FBQSxFQUFBO0FBQWtJLFVBQUEsMEJBQUEsaUJBQUEsU0FBQSxzRUFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSxjQUFBO1VBQUEsQ0FBQTtBQUFsSSxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMEJBQUEsSUFBQSxzREFBQSxHQUFBLENBQUE7QUFNSixVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDBCQUFBLElBQUEsc0RBQUEsSUFBQSxFQUFBLEVBdUJDLElBQUEsc0RBQUEsR0FBQSxDQUFBO0FBa0JMLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsSUFBQTs7O0FBckppRyxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDJCQUFBLFVBQUEsSUFBQSxXQUFBO0FBQ2xDLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsUUFBQSxJQUFBLGNBQUE7QUFDckMsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSwyQkFBQSxJQUFBLElBQUEsMkNBQUEsQ0FBQTtBQUdHLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsUUFBQSxJQUFBLHFCQUFBO0FBQ0gsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSwyQkFBQSxJQUFBLElBQUEsK0JBQUEsQ0FBQTtBQUlWLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLHFCQUFBLEtBQUEsRUFBQTtBQU1JLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsb0JBQUEsSUFBQSxjQUFBLGdCQUFBLEVBQW1ELHFCQUFBLElBQUEsbUJBQUE7QUFLN0MsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSxJQUFBLG1CQUFBLDJCQUFBLElBQUEsSUFBQSw2QkFBQSxJQUFBLDJCQUFBLElBQUEsSUFBQSw4QkFBQSxDQUFBO0FBaUNWLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLFNBQUEsdUJBQUEsSUFBQSxtQkFBQSxLQUFBLEVBQUE7QUFVQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsSUFBQSxtQkFBQSxLQUFBLEVBQUE7QUFhK0IsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxVQUFBLENBQUEsSUFBQSxXQUFBO0FBR3RCLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsUUFBQSxJQUFBLGdCQUFBLEVBQXlCLGNBQUEsMkJBQUEsSUFBQSxJQUFBLGtEQUFBLENBQUE7QUFDaUYsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxXQUFBLElBQUEsbUJBQUE7QUFFeEYsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwyQkFBQSxZQUFBLENBQUEsSUFBQSxrQkFBQTtBQUU0RSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLFdBQUEsSUFBQSxrQkFBQTtBQUc5RixVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLFFBQUEsSUFBQSxnQkFBQSxFQUF5QixjQUFBLDJCQUFBLElBQUEsSUFBQSwyQ0FBQSxDQUFBO0FBQ0osVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxZQUFBLENBQUEsSUFBQSxrQkFBQSxFQUFnQyxXQUFBLElBQUEsWUFBQTtBQUVuQyxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDJCQUFBLFlBQUEsQ0FBQSxJQUFBLGlCQUFBO0FBRTJFLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsV0FBQSxJQUFBLGlCQUFBO0FBRzdGLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsUUFBQSxJQUFBLGdCQUFBLEVBQXlCLGNBQUEsMkJBQUEsSUFBQSxJQUFBLElBQUEsc0JBQUEsQ0FBQSxDQUFBO0FBQ0osVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwwQkFBQSxZQUFBLENBQUEsSUFBQSxpQkFBQSxFQUErQixXQUFBLElBQUEsV0FBQTtBQUVqRSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsSUFBQSxzQkFBQSxJQUFBLEtBQUEsRUFBQTtBQVFSLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLG9CQUFBLENBQUEsSUFBQSxzQkFBQSxLQUFBLEVBQUE7QUF3QkEsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLENBQUEsSUFBQSxvQkFBQSxJQUFBLHNCQUFBLEtBQUEsRUFBQTs7Ozs7c0ZEakdTLDhCQUE0QixFQUFBLFdBQUEsK0JBQUEsQ0FBQTtJQUFBLEdBQUE7OzsiLCJuYW1lcyI6WyJJbmplY3RhYmxlIiwiSHR0cENsaWVudCIsIlBsYWdpYXJpc21TdGF0dXMiLCJDb21wb25lbnQiLCJJbnB1dCIsIkNvbXBvbmVudCIsIklucHV0IiwiQ29tcG9uZW50IiwiSW5wdXQiLCJfYzAiLCJDb21wb25lbnQiLCJJbnB1dCIsIlN1YmplY3QiLCJDb21wb25lbnQiLCJJbnB1dCIsIlN1YmplY3QiLCJDb21wb25lbnQiLCJFdmVudEVtaXR0ZXIiLCJJbnB1dCIsIk91dHB1dCIsIl9jMCIsIkluamVjdGFibGUiLCJDb21wb25lbnQiLCJFdmVudEVtaXR0ZXIiLCJJbnB1dCIsIk91dHB1dCIsIl9jMCIsIkNvbXBvbmVudCIsInRhcCIsImZhQ2hldnJvblJpZ2h0IiwiZmFFeGNsYW1hdGlvblRyaWFuZ2xlIiwiTmdiTW9kYWwiXX0=