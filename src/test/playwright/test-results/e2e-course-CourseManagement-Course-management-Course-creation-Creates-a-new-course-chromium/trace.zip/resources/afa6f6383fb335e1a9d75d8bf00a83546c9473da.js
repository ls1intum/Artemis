import {
  ArtemisMarkdownModule,
  init_markdown_module
} from "/chunk-UF4UUZTK.js";
import {
  init_multiple_choice_question_model,
  init_multiple_choice_visual_question_component
} from "/chunk-KPWFZEYZ.js";
import {
  ArtemisMarkdownService,
  init_markdown_service
} from "/chunk-7FP3FWGI.js";
import {
  init_result_model
} from "/chunk-ORYTP7RT.js";
import {
  MAX_QUIZ_SHORT_ANSWER_TEXT_LENGTH,
  QuizQuestionType,
  RenderedQuizQuestionMarkDownElement,
  ScoringType,
  init_input_constants,
  init_quiz_question_model
} from "/chunk-HFO42WCR.js";
import {
  htmlForMarkdown,
  init_markdown_conversion_util
} from "/chunk-EI7VZDEV.js";
import {
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  SecuredImageComponent,
  Submission,
  TranslateDirective,
  __esm,
  init_artemis_translate_pipe,
  init_secured_image_component,
  init_shared_module,
  init_submission_model,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/quiz/shared/drag-and-drop-question-util.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var DragAndDropQuestionUtil;
var init_drag_and_drop_question_util_service = __esm({
  "src/main/webapp/app/exercises/quiz/shared/drag-and-drop-question-util.service.ts"() {
    DragAndDropQuestionUtil = class _DragAndDropQuestionUtil {
      constructor() {
      }
      solve(question, mappings) {
        if (!question.correctMappings) {
          return [];
        }
        const sampleMappings = new Array();
        let availableDragItems = question.dragItems;
        let remainingDropLocations = question.dropLocations?.filter((dropLocation) => {
          return question.correctMappings?.some((mapping) => {
            return this.isSameEntityWithTempId(mapping.dropLocation, dropLocation);
          }, this);
        }, this);
        if (mappings) {
          mappings.forEach(function(mapping) {
            const correctMapping = this.getMapping(question.correctMappings, mapping.dragItem, mapping.dropLocation);
            if (correctMapping) {
              sampleMappings.push(correctMapping);
              remainingDropLocations = remainingDropLocations?.filter(function(dropLocation) {
                return !this.isSameEntityWithTempId(dropLocation, mapping.dropLocation);
              }, this);
              availableDragItems = availableDragItems?.filter(function(dragItem) {
                return !this.isSameEntityWithTempId(dragItem, mapping.dragItem);
              }, this);
            }
          }, this);
        }
        const solved = this.solveRec(question.correctMappings, remainingDropLocations, availableDragItems, sampleMappings);
        if (solved) {
          return sampleMappings;
        } else {
          return [];
        }
      }
      solveRec(correctMappings, remainingDropLocations, availableDragItems, sampleMappings) {
        if (!remainingDropLocations || remainingDropLocations.length === 0) {
          return true;
        }
        const dropLocation = remainingDropLocations[0];
        return availableDragItems?.some(function(dragItem, index) {
          const correctMapping = this.getMapping(correctMappings, dragItem, dropLocation);
          if (correctMapping) {
            sampleMappings.push(correctMapping);
            remainingDropLocations.splice(0, 1);
            availableDragItems.splice(index, 1);
            const solved = this.solveRec(correctMappings, remainingDropLocations, availableDragItems, sampleMappings);
            remainingDropLocations.splice(0, 0, dropLocation);
            availableDragItems.splice(index, 0, dragItem);
            if (!solved) {
              sampleMappings.pop();
            }
            return solved;
          } else {
            return false;
          }
        }, this);
      }
      validateNoMisleadingCorrectMapping(question) {
        if (!question.correctMappings || !question.dragItems) {
          return true;
        }
        for (let i = 0; i < question.dragItems.length; i++) {
          for (let j = 0; j < i; j++) {
            const dragItem1 = question.dragItems[i];
            const dragItem2 = question.dragItems[j];
            const shareOneDropLocation = question.dropLocations?.some(function(dropLocation) {
              const isMappedWithDragItem1 = this.isMappedTogether(question.correctMappings, dragItem1, dropLocation);
              const isMappedWithDragItem2 = this.isMappedTogether(question.correctMappings, dragItem2, dropLocation);
              return isMappedWithDragItem1 && isMappedWithDragItem2;
            }, this);
            if (shareOneDropLocation) {
              const allDropLocationsForDragItem1 = this.getAllDropLocationsForDragItem(question.correctMappings, dragItem1);
              const allDropLocationsForDragItem2 = this.getAllDropLocationsForDragItem(question.correctMappings, dragItem2);
              if (!this.isSameSetOfDropLocations(allDropLocationsForDragItem1, allDropLocationsForDragItem2)) {
                return false;
              }
            }
          }
        }
        return true;
      }
      isMappedTogether(mappings, dragItem, dropLocation) {
        return !!this.getMapping(mappings, dragItem, dropLocation);
      }
      getMapping(mappings, dragItem, dropLocation) {
        return mappings.find((mapping) => {
          return this.isSameEntityWithTempId(dropLocation, mapping.dropLocation) && this.isSameEntityWithTempId(dragItem, mapping.dragItem);
        }, this);
      }
      getAllDropLocationsForDragItem(mappings, dragItem) {
        return mappings.filter((mapping) => this.isSameEntityWithTempId(mapping.dragItem, dragItem)).map((mapping) => mapping.dropLocation);
      }
      isSameSetOfDropLocations(set1, set2) {
        if (set1.length !== set2.length) {
          return false;
        }
        return set1.every((element1) => {
          return set2.some((element2) => {
            return this.isSameEntityWithTempId(element1, element2);
          });
        }) && set2.every((element2) => {
          return set1.some((element1) => {
            return this.isSameEntityWithTempId(element1, element2);
          });
        });
      }
      isSameEntityWithTempId(a, b) {
        return a === b || a != void 0 && b != void 0 && (a.id && b.id && a.id === b.id || a.tempID != void 0 && b.tempID != void 0 && a.tempID === b.tempID);
      }
      static \u0275fac = function DragAndDropQuestionUtil_Factory(t) {
        return new (t || _DragAndDropQuestionUtil)();
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _DragAndDropQuestionUtil, factory: _DragAndDropQuestionUtil.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/entities/quiz/drag-and-drop-mapping.model.ts
var DragAndDropMapping;
var init_drag_and_drop_mapping_model = __esm({
  "src/main/webapp/app/entities/quiz/drag-and-drop-mapping.model.ts"() {
    DragAndDropMapping = class {
      id;
      dragItemIndex;
      dropLocationIndex;
      invalid = false;
      submittedAnswer;
      question;
      dragItem;
      dropLocation;
      constructor(dragItem, dropLocation) {
        this.dragItem = dragItem;
        this.dropLocation = dropLocation;
      }
    };
  }
});

// src/main/webapp/app/exercises/quiz/manage/temp-id.ts
function generate() {
  return Math.floor(Math.random() * Number.MAX_SAFE_INTEGER);
}
var init_temp_id = __esm({
  "src/main/webapp/app/exercises/quiz/manage/temp-id.ts"() {
  }
});

// src/main/webapp/app/entities/quiz/drop-location.model.ts
var BaseEntityWithTempId, DropLocation;
var init_drop_location_model = __esm({
  "src/main/webapp/app/entities/quiz/drop-location.model.ts"() {
    init_temp_id();
    BaseEntityWithTempId = class {
      id;
      tempID;
      constructor() {
        this.tempID = generate();
      }
    };
    DropLocation = class extends BaseEntityWithTempId {
      posX;
      posY;
      width;
      height;
      invalid = false;
      question;
      constructor() {
        super();
      }
    };
  }
});

// src/main/webapp/app/entities/quiz/drag-item.model.ts
var DragItem;
var init_drag_item_model = __esm({
  "src/main/webapp/app/entities/quiz/drag-item.model.ts"() {
    init_drop_location_model();
    DragItem = class extends BaseEntityWithTempId {
      pictureFilePath;
      text;
      question;
      invalid = false;
      constructor() {
        super();
      }
    };
  }
});

// src/main/webapp/app/exercises/quiz/shared/fit-text/fit-text.directive.ts
import { Directive, ElementRef, HostListener, Input, Renderer2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var FitTextDirective;
var init_fit_text_directive = __esm({
  "src/main/webapp/app/exercises/quiz/shared/fit-text/fit-text.directive.ts"() {
    FitTextDirective = class _FitTextDirective {
      el;
      renderer;
      fitText = true;
      compression = 1;
      activateOnResize = true;
      minFontSize = 0;
      maxFontSize = Number.POSITIVE_INFINITY;
      delay = 100;
      innerHTML;
      fontUnit = "px";
      fitTextElement;
      computed;
      newlines;
      lineHeight;
      display;
      fitTextParent;
      fitTextMinFontSize;
      fitTextMaxFontSize;
      calcSize = 10;
      resizeTimeout;
      constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.fitTextElement = el.nativeElement;
        this.fitTextParent = this.fitTextElement.parentElement;
        this.computed = window.getComputedStyle(this.fitTextElement);
        this.newlines = this.fitTextElement.childElementCount > 0 ? this.fitTextElement.childElementCount : 1;
        this.lineHeight = this.computed["line-height"];
        this.display = this.computed["display"];
      }
      onWindowResize = () => {
        if (this.activateOnResize) {
          this.setFontSize();
        }
      };
      ngOnInit() {
        this.fitTextMinFontSize = this.minFontSize === "inherit" ? this.computed["font-size"] : this.minFontSize;
        this.fitTextMaxFontSize = this.maxFontSize === "inherit" ? this.computed["font-size"] : this.maxFontSize;
      }
      ngAfterViewInit() {
        this.setFontSize(0);
      }
      ngOnChanges(changes) {
        if (changes["compression"] && !changes["compression"].firstChange) {
          this.setFontSize(0);
        }
        if (changes["innerHTML"]) {
          this.fitTextElement.innerHTML = this.innerHTML;
          if (!changes["innerHTML"].firstChange) {
            this.setFontSize(0);
          }
        }
      }
      setFontSize = (delay = this.delay) => {
        this.resizeTimeout = setTimeout(() => {
          if (this.fitTextElement.offsetHeight * this.fitTextElement.offsetWidth !== 0) {
            this.setStyles(this.calcSize, 1, "inline-block");
            this.setStyles(this.calculateNewFontSize(), this.lineHeight, this.display);
          }
        }, delay);
      };
      calculateNewFontSize = () => {
        const ratio = this.calcSize * this.newlines / this.fitTextElement.offsetWidth / this.newlines;
        return Math.max(Math.min((this.fitTextParent.offsetWidth - (parseFloat(getComputedStyle(this.fitTextParent).paddingLeft) + parseFloat(getComputedStyle(this.fitTextParent).paddingRight)) - 6) * ratio * this.compression, this.fitTextMaxFontSize), this.fitTextMinFontSize);
      };
      setStyles = (fontSize, lineHeight, display) => {
        this.renderer.setStyle(this.fitTextElement, "fontSize", fontSize.toString() + this.fontUnit);
        this.renderer.setStyle(this.fitTextElement, "lineHeight", lineHeight.toString());
        this.renderer.setStyle(this.fitTextElement, "display", display);
      };
      static \u0275fac = function FitTextDirective_Factory(t) {
        return new (t || _FitTextDirective)(i02.\u0275\u0275directiveInject(i02.ElementRef), i02.\u0275\u0275directiveInject(i02.Renderer2));
      };
      static \u0275dir = i02.\u0275\u0275defineDirective({ type: _FitTextDirective, selectors: [["", "fitText", ""]], hostBindings: function FitTextDirective_HostBindings(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275listener("resize", function FitTextDirective_resize_HostBindingHandler() {
            return ctx.onWindowResize();
          }, false, i02.\u0275\u0275resolveWindow);
        }
      }, inputs: { fitText: "fitText", compression: "compression", activateOnResize: "activateOnResize", minFontSize: "minFontSize", maxFontSize: "maxFontSize", delay: "delay", innerHTML: "innerHTML", fontUnit: "fontUnit" }, features: [i02.\u0275\u0275NgOnChangesFeature] });
    };
  }
});

// src/main/webapp/app/exercises/quiz/shared/questions/drag-and-drop-question/drag-item.component.ts
import { Component, Input as Input2, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import isMobile from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ismobilejs-es5.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_cdk_drag-drop.js?v=1d0d9ead";
function DragItemComponent_Conditional_2_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275element(1, "jhi-secured-image", 3);
    i03.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r3 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("src", ctx_r3.filePreviewPaths.get(ctx_r3.dragItem.pictureFilePath) || ctx_r3.dragItem.pictureFilePath)("mobileDragAndDrop", ctx_r3.isMobile);
  }
}
function DragItemComponent_Conditional_2_div_4_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275element(0, "div");
  }
}
function DragItemComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275elementStart(1, "div", 1);
    i03.\u0275\u0275text(2, "\n            ");
    i03.\u0275\u0275template(3, DragItemComponent_Conditional_2_Conditional_3_Template, 3, 2)(4, DragItemComponent_Conditional_2_div_4_Template, 1, 0, "div", 2);
    i03.\u0275\u0275text(5, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(6, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("cdkDragDisabled", ctx_r0.clickDisabled)("cdkDragData", ctx_r0.dragItem);
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275conditional(3, ctx_r0.dragItem.pictureFilePath ? 3 : -1);
  }
}
function DragItemComponent_Conditional_3_div_10_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275element(0, "div");
  }
}
function DragItemComponent_Conditional_3_div_12_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275elementStart(0, "div", 8);
    i03.\u0275\u0275text(1, "\n                        ");
    i03.\u0275\u0275elementStart(2, "div", 9);
    i03.\u0275\u0275text(3);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(4, "\n                    ");
    i03.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r6 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275textInterpolate(ctx_r6.dragItem.text);
  }
}
function DragItemComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275elementStart(1, "div", 4);
    i03.\u0275\u0275text(2, "\n            ");
    i03.\u0275\u0275elementStart(3, "div", 5);
    i03.\u0275\u0275text(4, "\n                ");
    i03.\u0275\u0275elementStart(5, "div", 6);
    i03.\u0275\u0275text(6, "\n                    ");
    i03.\u0275\u0275elementStart(7, "span");
    i03.\u0275\u0275text(8);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(9, "\n                    ");
    i03.\u0275\u0275template(10, DragItemComponent_Conditional_3_div_10_Template, 1, 0, "div", 2);
    i03.\u0275\u0275text(11, "\n                    ");
    i03.\u0275\u0275template(12, DragItemComponent_Conditional_3_div_12_Template, 5, 1, "div", 7);
    i03.\u0275\u0275text(13, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(14, "\n            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(15, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(16, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("fitText", true)("activateOnResize", true)("maxFontSize", 17)("minFontSize", 15)("delay", 150);
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275property("cdkDragDisabled", ctx_r1.clickDisabled)("cdkDragData", ctx_r1.dragItem);
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275textInterpolate(ctx_r1.dragItem.text);
  }
}
function DragItemComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275elementStart(1, "div", 10);
    i03.\u0275\u0275text(2, "\n            ");
    i03.\u0275\u0275element(3, "span", 11);
    i03.\u0275\u0275text(4, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n    ");
  }
}
var _c0, DragItemComponent;
var init_drag_item_component = __esm({
  "src/main/webapp/app/exercises/quiz/shared/questions/drag-and-drop-question/drag-item.component.ts"() {
    init_drag_item_model();
    init_translate_directive();
    init_secured_image_component();
    init_fit_text_directive();
    _c0 = (a0) => ({ "min-width": a0 });
    DragItemComponent = class _DragItemComponent {
      minWidth;
      dragItem;
      clickDisabled;
      invalid;
      filePreviewPaths = /* @__PURE__ */ new Map();
      isMobile = false;
      constructor() {
      }
      ngOnInit() {
        this.isMobile = isMobile(window.navigator.userAgent).any;
      }
      static \u0275fac = function DragItemComponent_Factory(t) {
        return new (t || _DragItemComponent)();
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _DragItemComponent, selectors: [["jhi-drag-item"]], inputs: { minWidth: "minWidth", dragItem: "dragItem", clickDisabled: "clickDisabled", invalid: "invalid", filePreviewPaths: "filePreviewPaths" }, decls: 6, vars: 6, consts: [["ngClass", "{'no-click': clickDisabled}", 1, "drag-item", 3, "ngStyle"], ["cdkDrag", "", 1, "drag-item-picture", 3, "cdkDragDisabled", "cdkDragData"], [4, "cdkDragPlaceholder"], [3, "src", "mobileDragAndDrop"], [1, "drag-item-text"], [3, "fitText", "activateOnResize", "maxFontSize", "minFontSize", "delay"], ["cdkDrag", "", 1, "drag-box", 3, "cdkDragDisabled", "cdkDragData"], ["matchSize", "", 4, "cdkDragPreview"], ["matchSize", ""], [2, "border", "1px solid #000", "background", "white", "color", "black", "padding", "4px", "overflow", "hidden", "text-overflow", "ellipsis"], [1, "invalid"], ["jhiTranslate", "artemisApp.showStatistic.invalid"]], template: function DragItemComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "div", 0);
          i03.\u0275\u0275text(1, "\n    ");
          i03.\u0275\u0275template(2, DragItemComponent_Conditional_2_Template, 7, 3)(3, DragItemComponent_Conditional_3_Template, 17, 8)(4, DragItemComponent_Conditional_4_Template, 6, 0);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(5, "\n");
        }
        if (rf & 2) {
          i03.\u0275\u0275property("ngStyle", i03.\u0275\u0275pureFunction1(4, _c0, ctx.minWidth));
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275conditional(2, ctx.dragItem && ctx.dragItem.pictureFilePath ? 2 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(3, ctx.dragItem && !ctx.dragItem.pictureFilePath ? 3 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(4, ctx.invalid ? 4 : -1);
        }
      }, dependencies: [i1.NgClass, i1.NgStyle, TranslateDirective, SecuredImageComponent, i4.CdkDrag, i4.CdkDragPreview, i4.CdkDragPlaceholder, FitTextDirective], styles: ["/* src/main/webapp/app/exercises/quiz/shared/questions/drag-and-drop-question/drag-item.component.scss */\n.drag-item {\n  background: transparent;\n  border: none;\n  position: relative;\n  max-width: 360px;\n  margin: 5px 4px;\n}\n.drag-item img {\n  max-width: 160px;\n  max-height: 160px;\n}\n.drag-item.no-click * {\n  cursor: default !important;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none;\n}\n.drag-item .drag-item-picture {\n  cursor: move;\n  padding: 0;\n  margin: 0;\n  text-align: center;\n}\n.drag-item .drag-item-text {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  height: 100%;\n  width: 100%;\n  white-space: pre-wrap;\n}\n.drag-item .drag-item-text div {\n  display: flex;\n  overflow: hidden;\n}\n.drag-item .drag-item-text span {\n  border: 1px solid #000;\n  background: white;\n  color: black;\n  padding: 4px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.cdk-drag-preview img {\n  max-height: 158px;\n  max-width: 160px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL2RyYWctYW5kLWRyb3AtcXVlc3Rpb24vZHJhZy1pdGVtLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuZHJhZy1pdGVtIHtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIG1heC13aWR0aDogMzYwcHg7XG4gICAgbWFyZ2luOiA1cHggNHB4O1xuXG4gICAgaW1nIHtcbiAgICAgICAgbWF4LXdpZHRoOiAxNjBweDtcbiAgICAgICAgbWF4LWhlaWdodDogMTYwcHg7XG4gICAgfVxuXG4gICAgJi5uby1jbGljayB7XG4gICAgICAgICoge1xuICAgICAgICAgICAgY3Vyc29yOiBkZWZhdWx0ICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICAtd2Via2l0LXVzZXItc2VsZWN0OiBub25lO1xuICAgICAgICAgICAgLW1vei11c2VyLXNlbGVjdDogbm9uZTtcbiAgICAgICAgICAgIC1tcy11c2VyLXNlbGVjdDogbm9uZTtcbiAgICAgICAgICAgIHVzZXItc2VsZWN0OiBub25lO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmRyYWctaXRlbS1waWN0dXJlIHtcbiAgICAgICAgY3Vyc29yOiBtb3ZlO1xuICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICB9XG5cbiAgICAuZHJhZy1pdGVtLXRleHQge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICB3aGl0ZS1zcGFjZTogcHJlLXdyYXA7XG5cbiAgICAgICAgZGl2IHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgICB9XG5cbiAgICAgICAgc3BhbiB7XG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjMDAwO1xuICAgICAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgICAgICAgICBwYWRkaW5nOiA0cHg7XG4gICAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgICAgICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5jZGstZHJhZy1wcmV2aWV3IHtcbiAgICBpbWcge1xuICAgICAgICBtYXgtaGVpZ2h0OiAxNThweDtcbiAgICAgICAgbWF4LXdpZHRoOiAxNjBweDtcbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLGNBQUE7QUFDQSxVQUFBO0FBQ0EsWUFBQTtBQUNBLGFBQUE7QUFDQSxVQUFBLElBQUE7O0FBRUEsQ0FQSixVQU9JO0FBQ0ksYUFBQTtBQUNBLGNBQUE7O0FBSUEsQ0FiUixTQWFRLENBQUEsU0FBQTtBQUNJLFVBQUE7QUFDQSx1QkFBQTtBQUNBLG9CQUFBO0FBQ0EsbUJBQUE7QUFDQSxlQUFBOztBQUlSLENBdEJKLFVBc0JJLENBQUE7QUFDSSxVQUFBO0FBQ0EsV0FBQTtBQUNBLFVBQUE7QUFDQSxjQUFBOztBQUdKLENBN0JKLFVBNkJJLENBQUE7QUFDSSxXQUFBO0FBQ0EsZUFBQTtBQUNBLG1CQUFBO0FBQ0EsY0FBQTtBQUNBLFVBQUE7QUFDQSxTQUFBO0FBQ0EsZUFBQTs7QUFFQSxDQXRDUixVQXNDUSxDQVRKLGVBU0k7QUFDSSxXQUFBO0FBQ0EsWUFBQTs7QUFHSixDQTNDUixVQTJDUSxDQWRKLGVBY0k7QUFDSSxVQUFBLElBQUEsTUFBQTtBQUNBLGNBQUE7QUFDQSxTQUFBO0FBQ0EsV0FBQTtBQUNBLFlBQUE7QUFDQSxpQkFBQTs7QUFNUixDQUFBLGlCQUFBO0FBQ0ksY0FBQTtBQUNBLGFBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(DragItemComponent, { className: "DragItemComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/quiz/shared/questions/quiz-scoring-infostudent-modal/quiz-scoring-info-student-modal.component.ts
import { Component as Component2, Input as Input3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgbModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import { faQuestionCircle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i42 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_11_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                        ");
    i04.\u0275\u0275element(3, "span", 12);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                ");
  }
  if (rf & 2) {
    const ctx_r8 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction4(1, _c02, ctx_r8.score, ctx_r8.question.points, ctx_r8.scorePoint, ctx_r8.questionPoint));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_11_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                        ");
    i04.\u0275\u0275element(3, "span", 13);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                ");
  }
  if (rf & 2) {
    const ctx_r9 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction4(1, _c02, ctx_r9.score, ctx_r9.question.points, ctx_r9.scorePoint, ctx_r9.questionPoint));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n        ");
    i04.\u0275\u0275elementStart(1, "div", 9);
    i04.\u0275\u0275text(2, "\n            ");
    i04.\u0275\u0275element(3, "span", 10);
    i04.\u0275\u0275text(4, "\n            ");
    i04.\u0275\u0275element(5, "span", 11);
    i04.\u0275\u0275text(6, "\n            ");
    i04.\u0275\u0275element(7, "br");
    i04.\u0275\u0275text(8, "\n            ");
    i04.\u0275\u0275elementStart(9, "div");
    i04.\u0275\u0275text(10, "\n                ");
    i04.\u0275\u0275template(11, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_11_Conditional_11_Template, 5, 6)(12, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_11_Conditional_12_Template, 5, 6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(13, "\n        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(14, "\n    ");
  }
  if (rf & 2) {
    const ctx_r4 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(11);
    i04.\u0275\u0275conditional(11, ctx_r4.correctMultipleChoiceAnswers == ctx_r4.multipleChoiceCorrectAnswerCorrectlyChosen && ctx_r4.multipleChoiceWrongAnswerChosen == 0 ? 11 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(12, !(ctx_r4.correctMultipleChoiceAnswers == ctx_r4.multipleChoiceCorrectAnswerCorrectlyChosen && ctx_r4.multipleChoiceWrongAnswerChosen == 0) ? 12 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_9_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "span", 16);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r13 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction4(1, _c02, ctx_r13.score, ctx_r13.question.points, ctx_r13.scorePoint, ctx_r13.questionPoint));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_9_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "span", 17);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r14 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction8(1, _c1, ctx_r14.score, ctx_r14.question.points, ctx_r14.inTotalSelectedWrongOptions, ctx_r14.inTotalSelectedRightOptions, ctx_r14.scorePoint, ctx_r14.questionPoint, ctx_r14.wrongOption, ctx_r14.rightOption));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275template(3, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_9_Conditional_3_Template, 5, 6)(4, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_9_Conditional_4_Template, 5, 10);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r10 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, ctx_r10.correctMultipleChoiceAnswers == ctx_r10.multipleChoiceCorrectAnswerCorrectlyChosen && ctx_r10.multipleChoiceWrongAnswerChosen == 0 ? 3 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(4, !(ctx_r10.correctMultipleChoiceAnswers == ctx_r10.multipleChoiceCorrectAnswerCorrectlyChosen && ctx_r10.multipleChoiceWrongAnswerChosen == 0) ? 4 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_10_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "span", 18);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r15 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction4(1, _c02, ctx_r15.score, ctx_r15.question.points, ctx_r15.scorePoint, ctx_r15.questionPoint));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_10_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "span", 19);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r16 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction8(1, _c2, ctx_r16.score, ctx_r16.question.points, ctx_r16.incorrectlyMappedDragAndDropItems, ctx_r16.correctlyMappedDragAndDropItems, ctx_r16.scorePoint, ctx_r16.questionPoint, ctx_r16.rightMap, ctx_r16.wrongMap));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275template(3, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_10_Conditional_3_Template, 5, 6)(4, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_10_Conditional_4_Template, 5, 10);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r11 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, ctx_r11.incorrectlyMappedDragAndDropItems == 0 ? 3 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(4, ctx_r11.incorrectlyMappedDragAndDropItems != 0 ? 4 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_11_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "span", 20);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r17 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction4(1, _c02, ctx_r17.score, ctx_r17.question.points, ctx_r17.scorePoint, ctx_r17.questionPoint));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_11_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "span", 21);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r18 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction8(1, _c3, ctx_r18.score, ctx_r18.question.points, ctx_r18.shortAnswerWrongAnswers, ctx_r18.shortAnswerCorrectAnswers, ctx_r18.scorePoint, ctx_r18.questionPoint, ctx_r18.rightGap, ctx_r18.wrongGap));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275template(3, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_11_Conditional_3_Template, 5, 6)(4, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_11_Conditional_4_Template, 5, 10);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r12 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, !(ctx_r12.shortAnswerWrongAnswers > 0) ? 3 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(4, ctx_r12.shortAnswerWrongAnswers > 0 ? 4 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n        ");
    i04.\u0275\u0275elementStart(1, "div", 9);
    i04.\u0275\u0275text(2, "\n            ");
    i04.\u0275\u0275element(3, "span", 14);
    i04.\u0275\u0275text(4, "\n            ");
    i04.\u0275\u0275element(5, "span", 15);
    i04.\u0275\u0275text(6, "\n            ");
    i04.\u0275\u0275element(7, "br");
    i04.\u0275\u0275text(8, "\n            ");
    i04.\u0275\u0275template(9, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_9_Template, 6, 2)(10, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_10_Template, 6, 2)(11, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Conditional_11_Template, 6, 2);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(12, "\n    ");
  }
  if (rf & 2) {
    const ctx_r5 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(9);
    i04.\u0275\u0275conditional(9, ctx_r5.question.type === ctx_r5.QuizQuestionType.MULTIPLE_CHOICE ? 9 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(10, ctx_r5.question.type === ctx_r5.QuizQuestionType.DRAG_AND_DROP ? 10 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(11, ctx_r5.question.type === ctx_r5.QuizQuestionType.SHORT_ANSWER ? 11 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_9_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "span", 16);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r22 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction4(1, _c02, ctx_r22.score, ctx_r22.question.points, ctx_r22.scorePoint, ctx_r22.questionPoint));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_9_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "p", 24);
    i04.\u0275\u0275text(4, "\n                            ");
    i04.\u0275\u0275elementStart(5, "b");
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275element(8, "p", 25);
    i04.\u0275\u0275text(9, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r23 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunctionV(8, _c4, [ctx_r23.score, ctx_r23.question.points, ctx_r23.multipleChoiceAnswerOptions, ctx_r23.inTotalSelectedWrongOptions, ctx_r23.inTotalSelectedRightOptions, ctx_r23.scorePoint, ctx_r23.questionPoint, ctx_r23.wrongOption, ctx_r23.rightOption]));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate7("+ ", ctx_r23.inTotalSelectedRightOptions, "*", ctx_r23.question.points, " /", ctx_r23.multipleChoiceAnswerOptions, " -\n                                ", ctx_r23.inTotalSelectedWrongOptions, "*", ctx_r23.question.points, "/", ctx_r23.multipleChoiceAnswerOptions, " = ", ctx_r23.score, "");
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_9_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "p", 24);
    i04.\u0275\u0275text(4, "\n                            ");
    i04.\u0275\u0275elementStart(5, "b");
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275element(8, "p", 26);
    i04.\u0275\u0275text(9, "\n                            ");
    i04.\u0275\u0275element(10, "p", 25);
    i04.\u0275\u0275text(11, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(12, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r24 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunctionV(7, _c4, [ctx_r24.score, ctx_r24.question.points, ctx_r24.multipleChoiceAnswerOptions, ctx_r24.inTotalSelectedWrongOptions, ctx_r24.inTotalSelectedRightOptions, ctx_r24.scorePoint, ctx_r24.questionPoint, ctx_r24.wrongOption, ctx_r24.rightOption]));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate6("+ ", ctx_r24.inTotalSelectedRightOptions, "*", ctx_r24.question.points, " /", ctx_r24.multipleChoiceAnswerOptions, " -\n                                ", ctx_r24.inTotalSelectedWrongOptions, "*", ctx_r24.question.points, "/", ctx_r24.multipleChoiceAnswerOptions, "\n                                = 0\n                            ");
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275template(3, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_9_Conditional_3_Template, 5, 6)(4, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_9_Conditional_4_Template, 11, 18)(5, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_9_Conditional_5_Template, 13, 17);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(6, "\n            ");
  }
  if (rf & 2) {
    const ctx_r19 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, ctx_r19.correctMultipleChoiceAnswers == ctx_r19.multipleChoiceCorrectAnswerCorrectlyChosen && ctx_r19.multipleChoiceWrongAnswerChosen == 0 ? 3 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(4, !(ctx_r19.correctMultipleChoiceAnswers == ctx_r19.multipleChoiceCorrectAnswerCorrectlyChosen && ctx_r19.multipleChoiceWrongAnswerChosen == 0) && ctx_r19.differenceMultipleChoice >= 0 ? 4 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(5, !(ctx_r19.correctMultipleChoiceAnswers == ctx_r19.multipleChoiceCorrectAnswerCorrectlyChosen && ctx_r19.multipleChoiceWrongAnswerChosen == 0) && ctx_r19.differenceMultipleChoice < 0 ? 5 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_10_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "span", 18);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r25 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction4(1, _c02, ctx_r25.score, ctx_r25.question.points, ctx_r25.scorePoint, ctx_r25.questionPoint));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_10_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "p", 27);
    i04.\u0275\u0275text(4, "\n                            ");
    i04.\u0275\u0275elementStart(5, "b");
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275element(8, "p", 25);
    i04.\u0275\u0275text(9, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r26 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunctionV(8, _c5, [ctx_r26.score, ctx_r26.question.points, ctx_r26.incorrectlyMappedDragAndDropItems, ctx_r26.correctlyMappedDragAndDropItems, ctx_r26.mappedLocations, ctx_r26.scorePoint, ctx_r26.questionPoint, ctx_r26.rightMap, ctx_r26.wrongMap]));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate7("+ ", ctx_r26.correctlyMappedDragAndDropItems, "*", ctx_r26.question.points, "/", ctx_r26.mappedLocations, " -\n                                ", ctx_r26.incorrectlyMappedDragAndDropItems, "*", ctx_r26.question.points, "/", ctx_r26.mappedLocations, " = ", ctx_r26.score, "");
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_10_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "p", 27);
    i04.\u0275\u0275text(4, "\n                            ");
    i04.\u0275\u0275elementStart(5, "b");
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275element(8, "p", 26);
    i04.\u0275\u0275text(9, "\n                            ");
    i04.\u0275\u0275element(10, "p", 25);
    i04.\u0275\u0275text(11, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(12, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r27 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunctionV(7, _c5, [ctx_r27.score, ctx_r27.question.points, ctx_r27.incorrectlyMappedDragAndDropItems, ctx_r27.correctlyMappedDragAndDropItems, ctx_r27.mappedLocations, ctx_r27.scorePoint, ctx_r27.questionPoint, ctx_r27.rightMap, ctx_r27.wrongMap]));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate6("+ ", ctx_r27.correctlyMappedDragAndDropItems, "*", ctx_r27.question.points, "/", ctx_r27.mappedLocations, " -\n                                ", ctx_r27.incorrectlyMappedDragAndDropItems, "*", ctx_r27.question.points, "/", ctx_r27.mappedLocations, "\n                                = 0\n                            ");
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275template(3, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_10_Conditional_3_Template, 5, 6)(4, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_10_Conditional_4_Template, 11, 18)(5, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_10_Conditional_5_Template, 13, 17);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(6, "\n            ");
  }
  if (rf & 2) {
    const ctx_r20 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, ctx_r20.incorrectlyMappedDragAndDropItems == 0 ? 3 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(4, ctx_r20.incorrectlyMappedDragAndDropItems != 0 && ctx_r20.differenceDragAndDrop >= 0 ? 4 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(5, ctx_r20.incorrectlyMappedDragAndDropItems != 0 && ctx_r20.differenceDragAndDrop < 0 ? 5 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_11_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "span", 20);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r28 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction4(1, _c02, ctx_r28.score, ctx_r28.question.points, ctx_r28.scorePoint, ctx_r28.questionPoint));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_11_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "p", 28);
    i04.\u0275\u0275text(4, "\n                            ");
    i04.\u0275\u0275elementStart(5, "b");
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275element(8, "p", 25);
    i04.\u0275\u0275text(9, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r29 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunctionV(8, _c6, [ctx_r29.score, ctx_r29.question.points, ctx_r29.shortAnswerWrongAnswers, ctx_r29.shortAnswerCorrectAnswers, ctx_r29.shortAnswerSpots, ctx_r29.scorePoint, ctx_r29.questionPoint, ctx_r29.rightGap, ctx_r29.wrongGap]));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate7("+ ", ctx_r29.shortAnswerCorrectAnswers, "*", ctx_r29.question.points, "/", ctx_r29.shortAnswerSpots, " - ", ctx_r29.shortAnswerWrongAnswers, "*", ctx_r29.question.points, "/", ctx_r29.shortAnswerSpots, " = ", ctx_r29.score, "");
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_11_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "p", 28);
    i04.\u0275\u0275text(4, "\n                            ");
    i04.\u0275\u0275elementStart(5, "b");
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275element(8, "p", 26);
    i04.\u0275\u0275text(9, "\n                            ");
    i04.\u0275\u0275element(10, "p", 25);
    i04.\u0275\u0275text(11, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(12, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r30 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunctionV(7, _c6, [ctx_r30.score, ctx_r30.question.points, ctx_r30.shortAnswerWrongAnswers, ctx_r30.shortAnswerCorrectAnswers, ctx_r30.shortAnswerSpots, ctx_r30.scorePoint, ctx_r30.questionPoint, ctx_r30.rightGap, ctx_r30.wrongGap]));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate6("+ ", ctx_r30.shortAnswerCorrectAnswers, "*", ctx_r30.question.points, "/", ctx_r30.shortAnswerSpots, " - ", ctx_r30.shortAnswerWrongAnswers, "*", ctx_r30.question.points, "/", ctx_r30.shortAnswerSpots, "\n                                = 0\n                            ");
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275template(3, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_11_Conditional_3_Template, 5, 6)(4, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_11_Conditional_4_Template, 11, 18)(5, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_11_Conditional_5_Template, 13, 17);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(6, "\n            ");
  }
  if (rf & 2) {
    const ctx_r21 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, ctx_r21.shortAnswerWrongAnswers <= 0 ? 3 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(4, ctx_r21.shortAnswerWrongAnswers > 0 && ctx_r21.differenceShortAnswer >= 0 ? 4 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(5, ctx_r21.shortAnswerWrongAnswers > 0 && ctx_r21.differenceShortAnswer < 0 ? 5 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n        ");
    i04.\u0275\u0275elementStart(1, "div", 9);
    i04.\u0275\u0275text(2, "\n            ");
    i04.\u0275\u0275element(3, "span", 22);
    i04.\u0275\u0275text(4, "\n            ");
    i04.\u0275\u0275element(5, "span", 23);
    i04.\u0275\u0275text(6, "\n            ");
    i04.\u0275\u0275element(7, "br");
    i04.\u0275\u0275text(8, "\n            ");
    i04.\u0275\u0275template(9, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_9_Template, 7, 3)(10, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_10_Template, 7, 3)(11, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Conditional_11_Template, 7, 3);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(12, "\n    ");
  }
  if (rf & 2) {
    const ctx_r6 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(9);
    i04.\u0275\u0275conditional(9, ctx_r6.question.type === ctx_r6.QuizQuestionType.MULTIPLE_CHOICE ? 9 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(10, ctx_r6.question.type === ctx_r6.QuizQuestionType.DRAG_AND_DROP ? 10 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(11, ctx_r6.question.type === ctx_r6.QuizQuestionType.SHORT_ANSWER ? 11 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_9_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "span", 16);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r34 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction4(1, _c02, ctx_r34.score, ctx_r34.question.points, ctx_r34.scorePoint, ctx_r34.questionPoint));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_9_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "p", 24);
    i04.\u0275\u0275text(4, "\n                            ");
    i04.\u0275\u0275elementStart(5, "b");
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275element(8, "p", 25);
    i04.\u0275\u0275text(9, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r35 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunctionV(5, _c4, [ctx_r35.score, ctx_r35.question.points, ctx_r35.multipleChoiceAnswerOptions, ctx_r35.inTotalSelectedWrongOptions, ctx_r35.inTotalSelectedRightOptions, ctx_r35.scorePoint, ctx_r35.questionPoint, ctx_r35.wrongOption, ctx_r35.rightOption]));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate4("+ ", ctx_r35.inTotalSelectedRightOptions, "*", ctx_r35.question.points, " /", ctx_r35.multipleChoiceAnswerOptions, " = ", ctx_r35.score, "");
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_9_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "p", 24);
    i04.\u0275\u0275text(4, "\n                            ");
    i04.\u0275\u0275elementStart(5, "b");
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275element(8, "p", 25);
    i04.\u0275\u0275text(9, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r36 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunctionV(4, _c4, [ctx_r36.score, ctx_r36.question.points, ctx_r36.multipleChoiceAnswerOptions, ctx_r36.inTotalSelectedWrongOptions, ctx_r36.inTotalSelectedRightOptions, ctx_r36.scorePoint, ctx_r36.questionPoint, ctx_r36.wrongOption, ctx_r36.rightOption]));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate3("+ ", ctx_r36.inTotalSelectedRightOptions, "*", ctx_r36.question.points, " /", ctx_r36.multipleChoiceAnswerOptions, " = 0 ");
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275template(3, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_9_Conditional_3_Template, 5, 6)(4, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_9_Conditional_4_Template, 11, 15)(5, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_9_Conditional_5_Template, 11, 14);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(6, "\n            ");
  }
  if (rf & 2) {
    const ctx_r31 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, ctx_r31.correctMultipleChoiceAnswers == ctx_r31.multipleChoiceCorrectAnswerCorrectlyChosen && ctx_r31.multipleChoiceWrongAnswerChosen == 0 ? 3 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(4, !(ctx_r31.correctMultipleChoiceAnswers == ctx_r31.multipleChoiceCorrectAnswerCorrectlyChosen && ctx_r31.multipleChoiceWrongAnswerChosen == 0) && ctx_r31.differenceMultipleChoice >= 0 ? 4 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(5, !(ctx_r31.correctMultipleChoiceAnswers == ctx_r31.multipleChoiceCorrectAnswerCorrectlyChosen && ctx_r31.multipleChoiceWrongAnswerChosen == 0) && ctx_r31.differenceMultipleChoice < 0 ? 5 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_10_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "span", 18);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r37 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction4(1, _c02, ctx_r37.score, ctx_r37.question.points, ctx_r37.scorePoint, ctx_r37.questionPoint));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_10_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "p", 27);
    i04.\u0275\u0275text(4, "\n                            ");
    i04.\u0275\u0275elementStart(5, "b");
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275element(8, "p", 25);
    i04.\u0275\u0275text(9, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r38 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunctionV(5, _c5, [ctx_r38.score, ctx_r38.question.points, ctx_r38.incorrectlyMappedDragAndDropItems, ctx_r38.correctlyMappedDragAndDropItems, ctx_r38.mappedLocations, ctx_r38.scorePoint, ctx_r38.questionPoint, ctx_r38.rightMap, ctx_r38.wrongMap]));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate4("+ ", ctx_r38.correctlyMappedDragAndDropItems, "*", ctx_r38.question.points, "/", ctx_r38.mappedLocations, " = ", ctx_r38.score, "");
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_10_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "p", 27);
    i04.\u0275\u0275text(4, "\n                            ");
    i04.\u0275\u0275elementStart(5, "b");
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275element(8, "p", 26);
    i04.\u0275\u0275text(9, "\n                            ");
    i04.\u0275\u0275element(10, "p", 25);
    i04.\u0275\u0275text(11, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(12, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r39 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunctionV(4, _c5, [ctx_r39.score, ctx_r39.question.points, ctx_r39.incorrectlyMappedDragAndDropItems, ctx_r39.correctlyMappedDragAndDropItems, ctx_r39.mappedLocations, ctx_r39.scorePoint, ctx_r39.questionPoint, ctx_r39.rightMap, ctx_r39.wrongMap]));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate3("+ ", ctx_r39.correctlyMappedDragAndDropItems, "*", ctx_r39.question.points, "/", ctx_r39.mappedLocations, " = 0 ");
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275template(3, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_10_Conditional_3_Template, 5, 6)(4, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_10_Conditional_4_Template, 11, 15)(5, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_10_Conditional_5_Template, 13, 14);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(6, "\n            ");
  }
  if (rf & 2) {
    const ctx_r32 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, ctx_r32.incorrectlyMappedDragAndDropItems == 0 ? 3 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(4, ctx_r32.incorrectlyMappedDragAndDropItems != 0 && ctx_r32.differenceDragAndDrop >= 0 ? 4 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(5, ctx_r32.incorrectlyMappedDragAndDropItems != 0 && ctx_r32.differenceDragAndDrop < 0 ? 5 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_11_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "span", 20);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r40 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction4(1, _c02, ctx_r40.score, ctx_r40.question.points, ctx_r40.scorePoint, ctx_r40.questionPoint));
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_11_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "p", 28);
    i04.\u0275\u0275text(4, "\n                            ");
    i04.\u0275\u0275elementStart(5, "b");
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275element(8, "p", 25);
    i04.\u0275\u0275text(9, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r41 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunctionV(5, _c6, [ctx_r41.score, ctx_r41.question.points, ctx_r41.shortAnswerWrongAnswers, ctx_r41.shortAnswerCorrectAnswers, ctx_r41.shortAnswerSpots, ctx_r41.scorePoint, ctx_r41.questionPoint, ctx_r41.rightGap, ctx_r41.wrongGap]));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate4("+ ", ctx_r41.shortAnswerCorrectAnswers, "*", ctx_r41.question.points, "/", ctx_r41.shortAnswerSpots, " = ", ctx_r41.score, "");
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_11_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275element(3, "p", 28);
    i04.\u0275\u0275text(4, "\n                            ");
    i04.\u0275\u0275elementStart(5, "b");
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275element(8, "p", 25);
    i04.\u0275\u0275text(9, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r42 = i04.\u0275\u0275nextContext(4);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunctionV(4, _c6, [ctx_r42.score, ctx_r42.question.points, ctx_r42.shortAnswerWrongAnswers, ctx_r42.shortAnswerCorrectAnswers, ctx_r42.shortAnswerSpots, ctx_r42.scorePoint, ctx_r42.questionPoint, ctx_r42.rightGap, ctx_r42.wrongGap]));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate3("+ ", ctx_r42.shortAnswerCorrectAnswers, "*", ctx_r42.question.points, "/", ctx_r42.shortAnswerSpots, " = 0 ");
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275template(3, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_11_Conditional_3_Template, 5, 6)(4, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_11_Conditional_4_Template, 11, 15)(5, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_11_Conditional_5_Template, 11, 14);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(6, "\n            ");
  }
  if (rf & 2) {
    const ctx_r33 = i04.\u0275\u0275nextContext(3);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, ctx_r33.shortAnswerWrongAnswers <= 0 ? 3 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(4, ctx_r33.shortAnswerWrongAnswers > 0 && ctx_r33.differenceShortAnswer >= 0 ? 4 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(5, ctx_r33.shortAnswerWrongAnswers > 0 && ctx_r33.differenceShortAnswer < 0 ? 5 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n        ");
    i04.\u0275\u0275elementStart(1, "div", 9);
    i04.\u0275\u0275text(2, "\n            ");
    i04.\u0275\u0275element(3, "span", 29);
    i04.\u0275\u0275text(4, "\n            ");
    i04.\u0275\u0275element(5, "span", 30);
    i04.\u0275\u0275text(6, "\n            ");
    i04.\u0275\u0275element(7, "br");
    i04.\u0275\u0275text(8, "\n            ");
    i04.\u0275\u0275template(9, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_9_Template, 7, 3)(10, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_10_Template, 7, 3)(11, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Conditional_11_Template, 7, 3);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(12, "\n    ");
  }
  if (rf & 2) {
    const ctx_r7 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(9);
    i04.\u0275\u0275conditional(9, ctx_r7.question.type === ctx_r7.QuizQuestionType.MULTIPLE_CHOICE ? 9 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(10, ctx_r7.question.type === ctx_r7.QuizQuestionType.DRAG_AND_DROP ? 10 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(11, ctx_r7.question.type === ctx_r7.QuizQuestionType.SHORT_ANSWER ? 11 : -1);
  }
}
function QuizScoringInfoStudentModalComponent_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r44 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n    ");
    i04.\u0275\u0275elementStart(1, "div", 3);
    i04.\u0275\u0275text(2, "\n        ");
    i04.\u0275\u0275elementStart(3, "h5", 4);
    i04.\u0275\u0275text(4, "\n            ");
    i04.\u0275\u0275element(5, "span", 5);
    i04.\u0275\u0275text(6, "\n        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n        ");
    i04.\u0275\u0275elementStart(8, "button", 6);
    i04.\u0275\u0275listener("click", function QuizScoringInfoStudentModalComponent_ng_template_0_Template_button_click_8_listener() {
      const restoredCtx = i04.\u0275\u0275restoreView(_r44);
      const d_r3 = restoredCtx.dismiss;
      return i04.\u0275\u0275resetView(d_r3());
    });
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(9, "\n    ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n    ");
    i04.\u0275\u0275template(11, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_11_Template, 15, 2)(12, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_12_Template, 13, 3)(13, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_13_Template, 13, 3)(14, QuizScoringInfoStudentModalComponent_ng_template_0_Conditional_14_Template, 13, 3);
    i04.\u0275\u0275elementStart(15, "div", 7);
    i04.\u0275\u0275text(16, "\n        ");
    i04.\u0275\u0275elementStart(17, "button", 8);
    i04.\u0275\u0275listener("click", function QuizScoringInfoStudentModalComponent_ng_template_0_Template_button_click_17_listener() {
      const restoredCtx = i04.\u0275\u0275restoreView(_r44);
      const c_r2 = restoredCtx.close;
      return i04.\u0275\u0275resetView(c_r2());
    });
    i04.\u0275\u0275text(18, "Close");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(19, "\n    ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(20, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(5);
    i04.\u0275\u0275property("translateValues", i04.\u0275\u0275pureFunction2(5, _c7, ctx_r0.question.title, ctx_r0.questionIndex));
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275conditional(11, ctx_r0.question.scoringType === ctx_r0.ScoringType.ALL_OR_NOTHING && ctx_r0.isSingleChoice ? 11 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(12, ctx_r0.question.scoringType === ctx_r0.ScoringType.ALL_OR_NOTHING && !ctx_r0.isSingleChoice ? 12 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(13, ctx_r0.question.scoringType === ctx_r0.ScoringType.PROPORTIONAL_WITH_PENALTY ? 13 : -1);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(14, ctx_r0.question.scoringType === ctx_r0.ScoringType.PROPORTIONAL_WITHOUT_PENALTY ? 14 : -1);
  }
}
var _c02, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, QuizScoringInfoStudentModalComponent;
var init_quiz_scoring_info_student_modal_component = __esm({
  "src/main/webapp/app/exercises/quiz/shared/questions/quiz-scoring-infostudent-modal/quiz-scoring-info-student-modal.component.ts"() {
    init_result_model();
    init_quiz_question_model();
    init_translate_directive();
    _c02 = (a0, a1, a2, a3) => ({ paramScore: a0, paramQuestionScore: a1, paramPoint: a2, paramScorePoint: a3 });
    _c1 = (a0, a1, a2, a3, a4, a5, a6, a7) => ({ paramScore: a0, paramQuestionScore: a1, paramInTotalWrongOptions: a2, paramInTotalRightOptions: a3, paramPoint: a4, paramScorePoint: a5, wrongOption: a6, rightOption: a7 });
    _c2 = (a0, a1, a2, a3, a4, a5, a6, a7) => ({ paramScore: a0, paramQuestionScore: a1, paramWrongMappedItems: a2, paramRightMapping: a3, paramPoint: a4, paramScorePoint: a5, rightMap: a6, wrongMap: a7 });
    _c3 = (a0, a1, a2, a3, a4, a5, a6, a7) => ({ paramScore: a0, paramQuestionScore: a1, paramShortAnswerWrongOption: a2, paramShortAnswerCorrectAnswers: a3, paramPoint: a4, paramScorePoint: a5, rightGap: a6, wrongGap: a7 });
    _c4 = (a0, a1, a2, a3, a4, a5, a6, a7, a8) => ({ paramScore: a0, paramQuestionScore: a1, paramAmountOfAnswerOptions: a2, paramInTotalWrongOptions: a3, paramInTotalRightOptions: a4, paramPoint: a5, paramScorePoint: a6, wrongOption: a7, rightOption: a8 });
    _c5 = (a0, a1, a2, a3, a4, a5, a6, a7, a8) => ({ paramScore: a0, paramQuestionScore: a1, paramWrongMappedItems: a2, paramRightMapping: a3, paramDragAndDropElementsCount: a4, paramPoint: a5, paramScorePoint: a6, rightMap: a7, wrongMap: a8 });
    _c6 = (a0, a1, a2, a3, a4, a5, a6, a7, a8) => ({ paramScore: a0, paramQuestionScore: a1, paramShortAnswerWrongOption: a2, paramShortAnswerCorrectAnswers: a3, paramCount: a4, paramPoint: a5, paramScorePoint: a6, rightGap: a7, wrongGap: a8 });
    _c7 = (a0, a1) => ({ paramTitle: a0, paramIndex: a1 });
    _c8 = (a0, a1) => ({ questionCorrect: a0, questionWrong: a1 });
    QuizScoringInfoStudentModalComponent = class _QuizScoringInfoStudentModalComponent {
      modalService;
      translateService;
      QuizQuestionType = QuizQuestionType;
      ScoringType = ScoringType;
      score;
      questionIndex;
      question;
      dragAndDropMapping = new Array();
      incorrectlyMappedDragAndDropItems;
      mappedLocations;
      multipleChoiceMapping = new Array();
      shortAnswerText = new Array();
      correctlyMappedDragAndDropItems;
      multipleChoiceSubmittedResult;
      quizQuestions;
      multipleChoiceCorrectAnswerCorrectlyChosen;
      multipleChoiceWrongAnswerChosen;
      correctMultipleChoiceAnswers;
      forgottenMultipleChoiceRightAnswers;
      multipleChoiceAnswerOptions;
      inTotalSelectedRightOptions;
      inTotalSelectedWrongOptions;
      differenceMultipleChoice;
      checkForCorrectAnswers = new Array();
      checkForWrongAnswers = new Array();
      isSingleChoice;
      differenceDragAndDrop;
      shortAnswerSpots;
      shortAnswerCorrectAnswers;
      shortAnswerWrongAnswers;
      differenceShortAnswer;
      questionPoint;
      scorePoint;
      wrongOption;
      rightOption;
      rightMap;
      wrongMap;
      rightGap;
      wrongGap;
      farQuestionCircle = faQuestionCircle;
      constructor(modalService, translateService) {
        this.modalService = modalService;
        this.translateService = translateService;
      }
      ngAfterViewInit() {
        this.checkForSingleOrPluralPoints();
        switch (this.question.type) {
          case QuizQuestionType.MULTIPLE_CHOICE:
            this.countMultipleChoice();
            break;
          case QuizQuestionType.DRAG_AND_DROP:
            this.countDragAndDrop();
            break;
          case QuizQuestionType.SHORT_ANSWER:
            this.countShortAnswer();
            break;
        }
      }
      open(content) {
        this.modalService.open(content, { size: "lg" });
      }
      submittedAnswerCorrectValues() {
        let answerOptionsOfQuestion = new Array();
        for (const question of this.quizQuestions || []) {
          const mcQuizQuestion = question;
          if (mcQuizQuestion.id === this.question.id) {
            answerOptionsOfQuestion = mcQuizQuestion.answerOptions;
            this.correctMultipleChoiceAnswers = mcQuizQuestion.answerOptions.filter((option) => option.isCorrect).length;
          }
        }
        if (!this.multipleChoiceSubmittedResult || !this.multipleChoiceSubmittedResult.submission) {
          return;
        }
        const submittedQuizSubmission = this.multipleChoiceSubmittedResult.submission;
        const submittedAnswerLength = submittedQuizSubmission.submittedAnswers?.length ?? 0;
        for (let i = 0; i < submittedAnswerLength; i++) {
          if (submittedQuizSubmission.submittedAnswers[i].quizQuestion.id === this.question.id) {
            const multipleChoiceSubmittedAnswers = submittedQuizSubmission.submittedAnswers[i];
            if (multipleChoiceSubmittedAnswers.selectedOptions === void 0) {
              this.checkForCorrectAnswers = [];
              this.checkForWrongAnswers = [];
            } else {
              for (const selectedOption of multipleChoiceSubmittedAnswers.selectedOptions) {
                for (const answerOptionElement of answerOptionsOfQuestion) {
                  if (selectedOption.id === answerOptionElement.id && answerOptionElement.isCorrect) {
                    this.checkForCorrectAnswers.push(selectedOption);
                  } else if (selectedOption.id === answerOptionElement.id && !answerOptionElement.isCorrect) {
                    this.checkForWrongAnswers.push(selectedOption);
                  }
                }
              }
            }
          }
        }
      }
      countMultipleChoice() {
        this.submittedAnswerCorrectValues();
        const translationBasePath = "artemisApp.quizExercise.explanationText.";
        const mcmQuestion = this.question;
        this.isSingleChoice = mcmQuestion.singleChoice ?? false;
        this.multipleChoiceAnswerOptions = mcmQuestion.answerOptions.length;
        this.multipleChoiceCorrectAnswerCorrectlyChosen = this.checkForCorrectAnswers.length;
        this.multipleChoiceWrongAnswerChosen = this.checkForWrongAnswers.length;
        this.forgottenMultipleChoiceRightAnswers = this.correctMultipleChoiceAnswers - this.multipleChoiceCorrectAnswerCorrectlyChosen;
        this.inTotalSelectedRightOptions = this.multipleChoiceCorrectAnswerCorrectlyChosen + (this.multipleChoiceAnswerOptions - this.correctMultipleChoiceAnswers - this.multipleChoiceWrongAnswerChosen);
        this.inTotalSelectedWrongOptions = this.multipleChoiceWrongAnswerChosen + this.forgottenMultipleChoiceRightAnswers;
        this.differenceMultipleChoice = this.inTotalSelectedRightOptions - this.inTotalSelectedWrongOptions;
        if (this.inTotalSelectedRightOptions === 1) {
          this.rightOption = this.translateService.instant(translationBasePath + "option");
        } else {
          this.rightOption = this.translateService.instant(translationBasePath + "options");
        }
        if (this.inTotalSelectedWrongOptions === 1) {
          this.wrongOption = this.translateService.instant(translationBasePath + "option");
        } else {
          this.wrongOption = this.translateService.instant(translationBasePath + "options");
        }
      }
      countDragAndDrop() {
        const translationBasePath = "artemisApp.quizExercise.explanationText.";
        this.differenceDragAndDrop = this.correctlyMappedDragAndDropItems - this.incorrectlyMappedDragAndDropItems;
        if (this.correctlyMappedDragAndDropItems === 1) {
          this.rightMap = this.translateService.instant(translationBasePath + "item");
        } else {
          this.rightMap = this.translateService.instant(translationBasePath + "items");
        }
        if (this.incorrectlyMappedDragAndDropItems === 1) {
          this.wrongMap = this.translateService.instant(translationBasePath + "item");
        } else {
          this.wrongMap = this.translateService.instant(translationBasePath + "items");
        }
      }
      countShortAnswer() {
        const translationBasePath = "artemisApp.quizExercise.explanationText.";
        const shortAnswer = this.question;
        this.shortAnswerSpots = shortAnswer.spots.length;
        this.shortAnswerCorrectAnswers = this.shortAnswerText.filter((option) => option.isCorrect).length;
        this.shortAnswerWrongAnswers = this.shortAnswerSpots - this.shortAnswerCorrectAnswers;
        this.differenceShortAnswer = this.shortAnswerCorrectAnswers - this.shortAnswerWrongAnswers;
        if (this.shortAnswerCorrectAnswers === 1) {
          this.rightGap = this.translateService.instant(translationBasePath + "textgap");
        } else {
          this.rightGap = this.translateService.instant(translationBasePath + "textgaps");
        }
        if (this.shortAnswerWrongAnswers === 1) {
          this.wrongGap = this.translateService.instant(translationBasePath + "textgap");
        } else {
          this.wrongGap = this.translateService.instant(translationBasePath + "textgaps");
        }
      }
      checkForSingleOrPluralPoints() {
        const translationBasePath = "artemisApp.quizExercise.explanationText.";
        if (this.question.points === 1) {
          this.questionPoint = this.translateService.instant(translationBasePath + "point");
        } else {
          this.questionPoint = this.translateService.instant(translationBasePath + "points");
        }
        if (this.score === void 0) {
          this.score = 0;
        }
        if (this.score === 1) {
          this.scorePoint = this.translateService.instant(translationBasePath + "point");
        } else {
          this.scorePoint = this.translateService.instant(translationBasePath + "points");
        }
      }
      static \u0275fac = function QuizScoringInfoStudentModalComponent_Factory(t) {
        return new (t || _QuizScoringInfoStudentModalComponent)(i04.\u0275\u0275directiveInject(i12.NgbModal), i04.\u0275\u0275directiveInject(i2.TranslateService));
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _QuizScoringInfoStudentModalComponent, selectors: [["jhi-quiz-scoring-infostudent-modal"]], inputs: { score: "score", questionIndex: "questionIndex", question: "question", dragAndDropMapping: "dragAndDropMapping", incorrectlyMappedDragAndDropItems: "incorrectlyMappedDragAndDropItems", mappedLocations: "mappedLocations", multipleChoiceMapping: "multipleChoiceMapping", shortAnswerText: "shortAnswerText", correctlyMappedDragAndDropItems: "correctlyMappedDragAndDropItems", multipleChoiceSubmittedResult: "multipleChoiceSubmittedResult", quizQuestions: "quizQuestions" }, decls: 11, vars: 5, consts: [["scoringExplanation", ""], [1, "btn", 3, "click"], [3, "ngClass", "icon"], [1, "modal-header"], [1, "modal-title"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.scoringTitle", 3, "translateValues"], ["type", "button", "aria-label", "Close", 1, "btn-close", 3, "click"], [1, "modal-footer"], ["type", "button", 1, "btn", "btn-outline", 3, "click"], [1, "modal-body"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.scoringTypeSingleChoice", 1, "font-weight-bold"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.scoringTypeSingleChoiceExplanation"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.multipleChoiceSingleChoiceCorrect", 3, "translateValues"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.multipleChoiceSingleChoiceNotCorrect", 3, "translateValues"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.scoringTypeAllOrNothing", 1, "font-weight-bold"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.scoringTypeAllOrNothingExplanation"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.multipleChoiceAllOrNothingCorrect", 3, "translateValues"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.multipleChoiceAllOrNothingNotCorrect", 3, "translateValues"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.dragAndDropAllOrNothingCorrect", 3, "translateValues"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.dragAndDropAllOrNothingNotCorrect", 3, "translateValues"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.shortAnswerAllOrNothingCorrect", 3, "translateValues"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.shortAnswerAllOrNothingNotCorrect", 3, "translateValues"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.scoringTypeProportional", 1, "font-weight-bold"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.scoringTypeProportionalExplanation"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.multipleChoiceProp", 3, "translateValues"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.KeepTrying"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.zeroPointer"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.dragAndDropProp", 3, "translateValues"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.shortAnswerProp", 3, "translateValues"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.scoringTypeProportionalWithout", 1, "font-weight-bold"], ["jhiTranslate", "artemisApp.quizExercise.explanationText.scoringTypeProportionalWithoutExplanation"]], template: function QuizScoringInfoStudentModalComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r46 = i04.\u0275\u0275getCurrentView();
          i04.\u0275\u0275template(0, QuizScoringInfoStudentModalComponent_ng_template_0_Template, 21, 8, "ng-template", null, 0, i04.\u0275\u0275templateRefExtractor);
          i04.\u0275\u0275text(2, "\n");
          i04.\u0275\u0275elementStart(3, "div");
          i04.\u0275\u0275text(4, "\n    ");
          i04.\u0275\u0275elementStart(5, "button", 1);
          i04.\u0275\u0275listener("click", function QuizScoringInfoStudentModalComponent_Template_button_click_5_listener() {
            i04.\u0275\u0275restoreView(_r46);
            const _r1 = i04.\u0275\u0275reference(1);
            return i04.\u0275\u0275resetView(ctx.open(_r1));
          });
          i04.\u0275\u0275text(6, "\n        ");
          i04.\u0275\u0275element(7, "fa-icon", 2);
          i04.\u0275\u0275text(8, "\n    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(9, "\n");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(10, "\n");
        }
        if (rf & 2) {
          i04.\u0275\u0275advance(7);
          i04.\u0275\u0275property("ngClass", i04.\u0275\u0275pureFunction2(2, _c8, ctx.score === ctx.question.points, ctx.score !== ctx.question.points))("icon", ctx.farQuestionCircle);
        }
      }, dependencies: [i3.NgClass, i42.FaIconComponent, TranslateDirective], styles: ["\n\n.questionCorrect[_ngcontent-%COMP%] {\n  color: var(--quiz-scoring-info-student-modal-question-correct);\n}\n.questionWrong[_ngcontent-%COMP%] {\n  color: var(--quiz-scoring-info-student-modal-question-wrong);\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL3F1aXotc2NvcmluZy1pbmZvc3R1ZGVudC1tb2RhbC9xdWl6LXNjb3JpbmctaW5mby1zdHVkZW50LW1vZGFsLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIucXVlc3Rpb25Db3JyZWN0IHtcbiAgICBjb2xvcjogdmFyKC0tcXVpei1zY29yaW5nLWluZm8tc3R1ZGVudC1tb2RhbC1xdWVzdGlvbi1jb3JyZWN0KTtcbn1cblxuLnF1ZXN0aW9uV3Jvbmcge1xuICAgIGNvbG9yOiB2YXIoLS1xdWl6LXNjb3JpbmctaW5mby1zdHVkZW50LW1vZGFsLXF1ZXN0aW9uLXdyb25nKTtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxTQUFBLElBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(QuizScoringInfoStudentModalComponent, { className: "QuizScoringInfoStudentModalComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/quiz/shared/questions/drag-and-drop-question/drag-and-drop-question.component.ts
import { Component as Component3, EventEmitter, Input as Input4, Output, ViewChild, ViewEncapsulation as ViewEncapsulation2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import __vite__cjsImport26_mobileDragDrop from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/mobile-drag-drop.js?v=1d0d9ead"; const polyfill = __vite__cjsImport26_mobileDragDrop["polyfill"];
import __vite__cjsImport27_mobileDragDrop_scrollBehaviour from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/mobile-drag-drop_scroll-behaviour.js?v=1d0d9ead"; const scrollBehaviourDragImageTranslateOverride = __vite__cjsImport27_mobileDragDrop_scrollBehaviour["scrollBehaviourDragImageTranslateOverride"];
import { faExclamationCircle, faExclamationTriangle, faQuestionCircle as faQuestionCircle2, faSpinner } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i43 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i8 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_cdk_drag-drop.js?v=1d0d9ead";
function DragAndDropQuestionComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n            ");
    i05.\u0275\u0275elementStart(1, "h2");
    i05.\u0275\u0275text(2, "\n                ");
    i05.\u0275\u0275elementStart(3, "span", 8);
    i05.\u0275\u0275element(4, "fa-icon", 9);
    i05.\u0275\u0275text(5, "\xA0");
    i05.\u0275\u0275elementStart(6, "span");
    i05.\u0275\u0275text(7);
    i05.\u0275\u0275pipe(8, "artemisTranslate");
    i05.\u0275\u0275elementEnd()();
    i05.\u0275\u0275text(9, "\n            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(10, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(4);
    i05.\u0275\u0275property("icon", ctx_r0.faSpinner)("spin", true);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275textInterpolate(i05.\u0275\u0275pipeBind1(8, 3, "artemisApp.quizQuestion.loading"));
  }
}
function DragAndDropQuestionComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n            ");
    i05.\u0275\u0275elementStart(1, "div");
    i05.\u0275\u0275text(2, "\n                ");
    i05.\u0275\u0275elementStart(3, "h2");
    i05.\u0275\u0275text(4, "\n                    ");
    i05.\u0275\u0275elementStart(5, "span", 8);
    i05.\u0275\u0275element(6, "fa-icon", 10);
    i05.\u0275\u0275text(7, "\xA0");
    i05.\u0275\u0275elementStart(8, "span");
    i05.\u0275\u0275text(9);
    i05.\u0275\u0275pipe(10, "artemisTranslate");
    i05.\u0275\u0275elementEnd()();
    i05.\u0275\u0275text(11, "\n                ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(12, "\n                ");
    i05.\u0275\u0275elementStart(13, "p");
    i05.\u0275\u0275text(14, "\n                    ");
    i05.\u0275\u0275elementStart(15, "button", 11);
    i05.\u0275\u0275listener("click", function DragAndDropQuestionComponent_Conditional_5_Template_button_click_15_listener() {
      i05.\u0275\u0275restoreView(_r15);
      const ctx_r14 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r14.secureImageComponent.retryLoadImage());
    });
    i05.\u0275\u0275text(16);
    i05.\u0275\u0275pipe(17, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(18, "\n                ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(19, "\n            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(20, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(6);
    i05.\u0275\u0275property("icon", ctx_r1.faExclamationCircle);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275textInterpolate(i05.\u0275\u0275pipeBind1(10, 3, "artemisApp.quizQuestion.failed"));
    i05.\u0275\u0275advance(7);
    i05.\u0275\u0275textInterpolate1("\n                        ", i05.\u0275\u0275pipeBind1(17, 5, "artemisApp.quizQuestion.retry"), "\n                    ");
  }
}
function DragAndDropQuestionComponent_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n            ");
    i05.\u0275\u0275element(1, "span", 12);
    i05.\u0275\u0275text(2, "\n        ");
  }
}
function DragAndDropQuestionComponent_Conditional_18_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275elementStart(1, "span", 16);
    i05.\u0275\u0275text(2, "\n                        ");
    i05.\u0275\u0275element(3, "fa-icon", 10);
    i05.\u0275\u0275text(4, "\n                        ");
    i05.\u0275\u0275element(5, "span", 17);
    i05.\u0275\u0275text(6, "\n                    ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(7, "\n                ");
  }
  if (rf & 2) {
    i05.\u0275\u0275nextContext();
    const _r18 = i05.\u0275\u0275reference(5);
    const ctx_r16 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("ngbPopover", _r18);
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275property("icon", ctx_r16.faQuestionCircle);
  }
}
function DragAndDropQuestionComponent_Conditional_18_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275element(1, "div", 3);
    i05.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    const ctx_r17 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("innerHTML", ctx_r17.renderedQuestion.hint, i05.\u0275\u0275sanitizeHtml);
  }
}
function DragAndDropQuestionComponent_Conditional_18_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275elementStart(1, "span", 18);
    i05.\u0275\u0275text(2, "\n                        ");
    i05.\u0275\u0275element(3, "fa-icon", 10);
    i05.\u0275\u0275text(4, "\n                        ");
    i05.\u0275\u0275element(5, "span", 19);
    i05.\u0275\u0275text(6, "\n                    ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(7, "\n                ");
  }
  if (rf & 2) {
    i05.\u0275\u0275nextContext();
    const _r21 = i05.\u0275\u0275reference(11);
    const ctx_r19 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("ngbPopover", _r21);
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275property("icon", ctx_r19.faExclamationCircle);
  }
}
function DragAndDropQuestionComponent_Conditional_18_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275element(1, "div", 3);
    i05.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    const ctx_r20 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("innerHTML", ctx_r20.renderedQuestion.explanation, i05.\u0275\u0275sanitizeHtml);
  }
}
function DragAndDropQuestionComponent_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n            ");
    i05.\u0275\u0275elementStart(1, "div", 13);
    i05.\u0275\u0275text(2, "\n                ");
    i05.\u0275\u0275template(3, DragAndDropQuestionComponent_Conditional_18_Conditional_3_Template, 8, 2)(4, DragAndDropQuestionComponent_Conditional_18_ng_template_4_Template, 3, 1, "ng-template", null, 14, i05.\u0275\u0275templateRefExtractor);
    i05.\u0275\u0275text(6, "\n                ");
    i05.\u0275\u0275element(7, "br");
    i05.\u0275\u0275text(8, "\n                ");
    i05.\u0275\u0275template(9, DragAndDropQuestionComponent_Conditional_18_Conditional_9_Template, 8, 2)(10, DragAndDropQuestionComponent_Conditional_18_ng_template_10_Template, 3, 1, "ng-template", null, 15, i05.\u0275\u0275templateRefExtractor);
    i05.\u0275\u0275text(12, "\n            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(13, "\n        ");
  }
  if (rf & 2) {
    const ctx_r3 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275conditional(3, ctx_r3.question.hint ? 3 : -1);
    i05.\u0275\u0275advance(6);
    i05.\u0275\u0275conditional(9, ctx_r3.question.explanation && ctx_r3.showResult ? 9 : -1);
  }
}
function DragAndDropQuestionComponent_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n            ");
    i05.\u0275\u0275elementStart(1, "div", 20);
    i05.\u0275\u0275text(2, "\n                ");
    i05.\u0275\u0275element(3, "span", 21);
    i05.\u0275\u0275text(4, "\n                ");
    i05.\u0275\u0275elementStart(5, "span");
    i05.\u0275\u0275text(6);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(7, "\n            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(8, "\n        ");
  }
  if (rf & 2) {
    const ctx_r4 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(6);
    i05.\u0275\u0275textInterpolate(ctx_r4.question.points);
  }
}
function DragAndDropQuestionComponent_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n            ");
    i05.\u0275\u0275elementStart(1, "div", 22);
    i05.\u0275\u0275text(2, "\n                ");
    i05.\u0275\u0275element(3, "span", 23);
    i05.\u0275\u0275text(4, "\n                ");
    i05.\u0275\u0275elementStart(5, "span", 24);
    i05.\u0275\u0275text(6);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(7, "\n                ");
    i05.\u0275\u0275elementStart(8, "span", 24);
    i05.\u0275\u0275text(9, "\n                    ");
    i05.\u0275\u0275element(10, "jhi-quiz-scoring-infostudent-modal", 25);
    i05.\u0275\u0275text(11, "\n                ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(12, "\n            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(13, "\n        ");
  }
  if (rf & 2) {
    const ctx_r5 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("ngClass", i05.\u0275\u0275pureFunction1(10, _c03, (ctx_r5.score || 0) < ctx_r5.question.points));
    i05.\u0275\u0275advance(5);
    i05.\u0275\u0275textInterpolate2("", ctx_r5.score || 0, "/", ctx_r5.question.points, "");
    i05.\u0275\u0275advance(4);
    i05.\u0275\u0275property("score", ctx_r5.score)("question", ctx_r5.question)("dragAndDropMapping", ctx_r5.mappings)("correctlyMappedDragAndDropItems", ctx_r5.correctAnswer)("incorrectlyMappedDragAndDropItems", ctx_r5.incorrectLocationMappings)("mappedLocations", ctx_r5.mappedLocations)("questionIndex", ctx_r5.questionIndex);
  }
}
function DragAndDropQuestionComponent_Conditional_21_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275element(1, "span", 27);
    i05.\u0275\u0275text(2, "\n                ");
  }
}
function DragAndDropQuestionComponent_Conditional_21_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275element(1, "span", 28);
    i05.\u0275\u0275text(2, "\n                ");
  }
}
function DragAndDropQuestionComponent_Conditional_21_Conditional_5_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r28 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n                            ");
    i05.\u0275\u0275elementStart(1, "div", 29);
    i05.\u0275\u0275listener("click", function DragAndDropQuestionComponent_Conditional_21_Conditional_5_Conditional_3_Template_div_click_1_listener() {
      i05.\u0275\u0275restoreView(_r28);
      const ctx_r27 = i05.\u0275\u0275nextContext(3);
      return i05.\u0275\u0275resetView(ctx_r27.showSampleSolution());
    });
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275pipe(3, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate1("\n                                ", i05.\u0275\u0275pipeBind1(3, 1, "artemisApp.quizQuestion.showSampleSolution"), "\n                            ");
  }
}
function DragAndDropQuestionComponent_Conditional_21_Conditional_5_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r30 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n                            ");
    i05.\u0275\u0275elementStart(1, "div", 29);
    i05.\u0275\u0275listener("click", function DragAndDropQuestionComponent_Conditional_21_Conditional_5_Conditional_4_Template_div_click_1_listener() {
      i05.\u0275\u0275restoreView(_r30);
      const ctx_r29 = i05.\u0275\u0275nextContext(3);
      return i05.\u0275\u0275resetView(ctx_r29.hideSampleSolution());
    });
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275pipe(3, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate1("\n                                ", i05.\u0275\u0275pipeBind1(3, 1, "artemisApp.quizQuestion.hideSampleSolution"), "\n                            ");
  }
}
function DragAndDropQuestionComponent_Conditional_21_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275elementStart(1, "div");
    i05.\u0275\u0275text(2, "\n                        ");
    i05.\u0275\u0275template(3, DragAndDropQuestionComponent_Conditional_21_Conditional_5_Conditional_3_Template, 5, 3)(4, DragAndDropQuestionComponent_Conditional_21_Conditional_5_Conditional_4_Template, 5, 3);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r24 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275conditional(3, !ctx_r24.showingSampleSolution ? 3 : -1);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275conditional(4, ctx_r24.showingSampleSolution ? 4 : -1);
  }
}
function DragAndDropQuestionComponent_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n            ");
    i05.\u0275\u0275elementStart(1, "div", 26);
    i05.\u0275\u0275text(2, "\n                ");
    i05.\u0275\u0275template(3, DragAndDropQuestionComponent_Conditional_21_Conditional_3_Template, 3, 0)(4, DragAndDropQuestionComponent_Conditional_21_Conditional_4_Template, 3, 0)(5, DragAndDropQuestionComponent_Conditional_21_Conditional_5_Template, 6, 2);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(6, "\n        ");
  }
  if (rf & 2) {
    const ctx_r6 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275conditional(3, ctx_r6.showingSampleSolution ? 3 : -1);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275conditional(4, !ctx_r6.showingSampleSolution ? 4 : -1);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275conditional(5, ctx_r6.showResult && !ctx_r6.forceSampleSolution ? 5 : -1);
  }
}
function DragAndDropQuestionComponent_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275elementStart(1, "jhi-secured-image", 30);
    i05.\u0275\u0275listener("endLoadingProcess", function DragAndDropQuestionComponent_Conditional_26_Template_jhi_secured_image_endLoadingProcess_1_listener($event) {
      i05.\u0275\u0275restoreView(_r32);
      const ctx_r31 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r31.changeLoading($event));
    });
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    const ctx_r7 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("src", ctx_r7.filePreviewPaths.get(ctx_r7.question.backgroundFilePath) || ctx_r7.question.backgroundFilePath);
  }
}
function DragAndDropQuestionComponent_Conditional_29_For_4_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r41 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n                                        ");
    i05.\u0275\u0275elementStart(1, "jhi-drag-item", 32);
    i05.\u0275\u0275listener("dragenter", function DragAndDropQuestionComponent_Conditional_29_For_4_Conditional_3_Template_jhi_drag_item_dragenter_1_listener() {
      i05.\u0275\u0275restoreView(_r41);
      const ctx_r40 = i05.\u0275\u0275nextContext(3);
      return i05.\u0275\u0275resetView(ctx_r40.drag());
    })("dragend", function DragAndDropQuestionComponent_Conditional_29_For_4_Conditional_3_Template_jhi_drag_item_dragend_1_listener() {
      i05.\u0275\u0275restoreView(_r41);
      const ctx_r42 = i05.\u0275\u0275nextContext(3);
      return i05.\u0275\u0275resetView(ctx_r42.drop());
    });
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(2, "\n                                    ");
  }
  if (rf & 2) {
    const dropLocation_r34 = i05.\u0275\u0275nextContext().$implicit;
    const ctx_r39 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("dragItem", ctx_r39.dragItemForDropLocation(dropLocation_r34))("clickDisabled", ctx_r39.clickDisabled)("minWidth", "100%")("filePreviewPaths", ctx_r39.filePreviewPaths);
  }
}
function DragAndDropQuestionComponent_Conditional_29_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r45 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n                                ");
    i05.\u0275\u0275elementStart(1, "div", 31);
    i05.\u0275\u0275listener("cdkDropListDropped", function DragAndDropQuestionComponent_Conditional_29_For_4_Template_div_cdkDropListDropped_1_listener($event) {
      const restoredCtx = i05.\u0275\u0275restoreView(_r45);
      const dropLocation_r34 = restoredCtx.$implicit;
      const ctx_r44 = i05.\u0275\u0275nextContext(2);
      return i05.\u0275\u0275resetView(ctx_r44.onDragDrop(dropLocation_r34, $event));
    })("onDragEnter", function DragAndDropQuestionComponent_Conditional_29_For_4_Template_div_onDragEnter_1_listener($event) {
      i05.\u0275\u0275restoreView(_r45);
      const ctx_r46 = i05.\u0275\u0275nextContext(2);
      return i05.\u0275\u0275resetView(ctx_r46.preventDefault($event));
    })("onDragOver", function DragAndDropQuestionComponent_Conditional_29_For_4_Template_div_onDragOver_1_listener($event) {
      i05.\u0275\u0275restoreView(_r45);
      const ctx_r47 = i05.\u0275\u0275nextContext(2);
      return i05.\u0275\u0275resetView(ctx_r47.preventDefault($event));
    })("onDragLeave", function DragAndDropQuestionComponent_Conditional_29_For_4_Template_div_onDragLeave_1_listener($event) {
      i05.\u0275\u0275restoreView(_r45);
      const ctx_r48 = i05.\u0275\u0275nextContext(2);
      return i05.\u0275\u0275resetView(ctx_r48.preventDefault($event));
    });
    i05.\u0275\u0275text(2, "\n                                    ");
    i05.\u0275\u0275template(3, DragAndDropQuestionComponent_Conditional_29_For_4_Conditional_3_Template, 3, 4);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    const dropLocation_r34 = ctx.$implicit;
    const ctx_r33 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("ngClass", ctx_r33.dropAllowed ? "drop-allowed" : "")("ngStyle", i05.\u0275\u0275pureFunction4(4, _c12, dropLocation_r34.posY / 2 + "%", dropLocation_r34.posX / 2 + "%", dropLocation_r34.width / 2 + "%", dropLocation_r34.height / 2 + "%"))("cdkDropListAutoScrollStep", 60);
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275conditional(3, ctx_r33.dragItemForDropLocation(dropLocation_r34) ? 3 : -1);
  }
}
function DragAndDropQuestionComponent_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                        ");
    i05.\u0275\u0275elementStart(1, "div");
    i05.\u0275\u0275text(2, "\n                            ");
    i05.\u0275\u0275repeaterCreate(3, DragAndDropQuestionComponent_Conditional_29_For_4_Template, 5, 9, null, null, i05.\u0275\u0275repeaterTrackByIdentity);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r8 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275repeater(ctx_r8.question.dropLocations);
  }
}
function DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                            ");
    i05.\u0275\u0275elementStart(1, "div", 35);
    i05.\u0275\u0275text(2, "\n                                                ");
    i05.\u0275\u0275element(3, "fa-icon", 36);
    i05.\u0275\u0275text(4, "\n                                            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(5, "\n                                        ");
  }
  if (rf & 2) {
    const ctx_r55 = i05.\u0275\u0275nextContext(3);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275property("icon", ctx_r55.faExclamationTriangle);
  }
}
function DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                                ");
    i05.\u0275\u0275element(1, "span", 37);
    i05.\u0275\u0275text(2, "\n                                            ");
  }
}
function DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                                ");
    i05.\u0275\u0275element(1, "span", 38);
    i05.\u0275\u0275text(2, "\n                                            ");
  }
}
function DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                                ");
    i05.\u0275\u0275element(1, "span", 39);
    i05.\u0275\u0275text(2, "\n                                            ");
  }
}
function DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                                ");
    i05.\u0275\u0275element(1, "fa-icon", 40);
    i05.\u0275\u0275text(2, "\n                                            ");
  }
  if (rf & 2) {
    const ctx_r59 = i05.\u0275\u0275nextContext(3);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("icon", ctx_r59.faQuestionCircle);
  }
}
function DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                            ");
    i05.\u0275\u0275elementStart(1, "jhi-drag-item", 41);
    i05.\u0275\u0275text(2, "\n                                            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(3, "\n                                        ");
  }
  if (rf & 2) {
    const dropLocation_r50 = i05.\u0275\u0275nextContext().$implicit;
    const ctx_r60 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("dragItem", ctx_r60.dragItemForDropLocation(dropLocation_r50))("clickDisabled", true)("minWidth", "100%")("filePreviewPaths", ctx_r60.filePreviewPaths);
  }
}
function DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                            ");
    i05.\u0275\u0275elementStart(1, "div", 42);
    i05.\u0275\u0275text(2, "\n                                                ");
    i05.\u0275\u0275element(3, "div");
    i05.\u0275\u0275text(4, "\n                                            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(5, "\n                                        ");
  }
}
function DragAndDropQuestionComponent_Conditional_30_For_4_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                ");
    i05.\u0275\u0275elementStart(1, "div");
    i05.\u0275\u0275text(2, "\n                                    ");
    i05.\u0275\u0275elementStart(3, "div", 33);
    i05.\u0275\u0275text(4, "\n                                        ");
    i05.\u0275\u0275template(5, DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_5_Template, 6, 1);
    i05.\u0275\u0275elementStart(6, "div", 34);
    i05.\u0275\u0275text(7, "\n                                            ");
    i05.\u0275\u0275template(8, DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_8_Template, 3, 0)(9, DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_9_Template, 3, 0)(10, DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_10_Template, 3, 0)(11, DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_11_Template, 3, 1);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(12, "\n                                        ");
    i05.\u0275\u0275template(13, DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_13_Template, 4, 4)(14, DragAndDropQuestionComponent_Conditional_30_For_4_Conditional_14_Template, 6, 0);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(15, "\n                                ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(16, "\n                            ");
  }
  if (rf & 2) {
    const dropLocation_r50 = ctx.$implicit;
    const ctx_r49 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275property("ngClass", i05.\u0275\u0275pureFunction1(9, _c03, ctx_r49.isLocationCorrect(dropLocation_r50) === ctx_r49.MappingResult.MAPPED_INCORRECT && !dropLocation_r50.invalid && !ctx_r49.invalidDragItemForDropLocation(dropLocation_r50) && !ctx_r49.question.invalid))("ngStyle", i05.\u0275\u0275pureFunction4(11, _c12, dropLocation_r50.posY / 2 + "%", dropLocation_r50.posX / 2 + "%", dropLocation_r50.width / 2 + "%", dropLocation_r50.height / 2 + "%"));
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275conditional(5, ctx_r49.isLocationCorrect(dropLocation_r50) === ctx_r49.MappingResult.MAPPED_INCORRECT && !dropLocation_r50.invalid && !ctx_r49.invalidDragItemForDropLocation(dropLocation_r50) && !ctx_r49.question.invalid ? 5 : -1);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275conditional(8, dropLocation_r50.invalid && !ctx_r49.invalidDragItemForDropLocation(dropLocation_r50) && !ctx_r49.question.invalid ? 8 : -1);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275conditional(9, !dropLocation_r50.invalid && ctx_r49.invalidDragItemForDropLocation(dropLocation_r50) && !ctx_r49.question.invalid ? 9 : -1);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275conditional(10, dropLocation_r50.invalid && ctx_r49.invalidDragItemForDropLocation(dropLocation_r50) || ctx_r49.question.invalid ? 10 : -1);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275conditional(11, dropLocation_r50.invalid || ctx_r49.question.invalid || ctx_r49.invalidDragItemForDropLocation(dropLocation_r50) ? 11 : -1);
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275conditional(13, ctx_r49.dragItemForDropLocation(dropLocation_r50) ? 13 : -1);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275conditional(14, !ctx_r49.dragItemForDropLocation(dropLocation_r50) ? 14 : -1);
  }
}
function DragAndDropQuestionComponent_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                        ");
    i05.\u0275\u0275elementStart(1, "div");
    i05.\u0275\u0275text(2, "\n                            ");
    i05.\u0275\u0275repeaterCreate(3, DragAndDropQuestionComponent_Conditional_30_For_4_Template, 17, 16, null, null, i05.\u0275\u0275repeaterTrackByIdentity);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r9 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275repeater(ctx_r9.question.dropLocations);
  }
}
function DragAndDropQuestionComponent_Conditional_31_For_4_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                            ");
    i05.\u0275\u0275elementStart(1, "div", 35);
    i05.\u0275\u0275text(2, "\n                                                ");
    i05.\u0275\u0275element(3, "fa-icon", 36);
    i05.\u0275\u0275text(4, "\n                                            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(5, "\n                                        ");
  }
  if (rf & 2) {
    const ctx_r69 = i05.\u0275\u0275nextContext(3);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275property("icon", ctx_r69.faExclamationTriangle);
  }
}
function DragAndDropQuestionComponent_Conditional_31_For_4_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                                ");
    i05.\u0275\u0275element(1, "span", 37);
    i05.\u0275\u0275text(2, "\n                                            ");
  }
}
function DragAndDropQuestionComponent_Conditional_31_For_4_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                                ");
    i05.\u0275\u0275element(1, "span", 39);
    i05.\u0275\u0275text(2, "\n                                            ");
  }
}
function DragAndDropQuestionComponent_Conditional_31_For_4_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                                ");
    i05.\u0275\u0275element(1, "fa-icon", 40);
    i05.\u0275\u0275text(2, "\n                                            ");
  }
  if (rf & 2) {
    const ctx_r72 = i05.\u0275\u0275nextContext(3);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("icon", ctx_r72.faQuestionCircle);
  }
}
function DragAndDropQuestionComponent_Conditional_31_For_4_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                            ");
    i05.\u0275\u0275element(1, "jhi-drag-item", 41);
    i05.\u0275\u0275text(2, "\n                                        ");
  }
  if (rf & 2) {
    const dropLocation_r64 = i05.\u0275\u0275nextContext().$implicit;
    const ctx_r73 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("dragItem", ctx_r73.correctDragItemForDropLocation(dropLocation_r64))("clickDisabled", true)("minWidth", "100%")("filePreviewPaths", ctx_r73.filePreviewPaths);
  }
}
function DragAndDropQuestionComponent_Conditional_31_For_4_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                            ");
    i05.\u0275\u0275elementStart(1, "div", 42);
    i05.\u0275\u0275text(2, "\n                                                ");
    i05.\u0275\u0275element(3, "div");
    i05.\u0275\u0275text(4, "\n                                            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(5, "\n                                        ");
  }
}
function DragAndDropQuestionComponent_Conditional_31_For_4_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                                ");
    i05.\u0275\u0275elementStart(1, "div");
    i05.\u0275\u0275text(2, "\n                                    ");
    i05.\u0275\u0275elementStart(3, "div", 43);
    i05.\u0275\u0275text(4, "\n                                        ");
    i05.\u0275\u0275template(5, DragAndDropQuestionComponent_Conditional_31_For_4_Conditional_5_Template, 6, 1);
    i05.\u0275\u0275elementStart(6, "div", 34);
    i05.\u0275\u0275text(7, "\n                                            ");
    i05.\u0275\u0275template(8, DragAndDropQuestionComponent_Conditional_31_For_4_Conditional_8_Template, 3, 0)(9, DragAndDropQuestionComponent_Conditional_31_For_4_Conditional_9_Template, 3, 0)(10, DragAndDropQuestionComponent_Conditional_31_For_4_Conditional_10_Template, 3, 1);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(11, "\n                                        ");
    i05.\u0275\u0275template(12, DragAndDropQuestionComponent_Conditional_31_For_4_Conditional_12_Template, 3, 4)(13, DragAndDropQuestionComponent_Conditional_31_For_4_Conditional_13_Template, 6, 0);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(14, "\n                                ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(15, "\n                            ");
  }
  if (rf & 2) {
    const dropLocation_r64 = ctx.$implicit;
    const ctx_r63 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275property("ngClass", i05.\u0275\u0275pureFunction1(8, _c03, ctx_r63.isLocationCorrect(dropLocation_r64) === ctx_r63.MappingResult.MAPPED_INCORRECT && !dropLocation_r64.invalid && !ctx_r63.invalidDragItemForDropLocation(dropLocation_r64) && !ctx_r63.question.invalid))("ngStyle", i05.\u0275\u0275pureFunction4(10, _c12, dropLocation_r64.posY / 2 + "%", dropLocation_r64.posX / 2 + "%", dropLocation_r64.width / 2 + "%", dropLocation_r64.height / 2 + "%"));
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275conditional(5, ctx_r63.isLocationCorrect(dropLocation_r64) === ctx_r63.MappingResult.MAPPED_INCORRECT && !dropLocation_r64.invalid && !ctx_r63.invalidDragItemForDropLocation(dropLocation_r64) && !ctx_r63.question.invalid && !ctx_r63.forceSampleSolution ? 5 : -1);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275conditional(8, dropLocation_r64.invalid && !ctx_r63.invalidDragItemForDropLocation(dropLocation_r64) && !ctx_r63.question.invalid ? 8 : -1);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275conditional(9, dropLocation_r64.invalid && ctx_r63.invalidDragItemForDropLocation(dropLocation_r64) || ctx_r63.question.invalid ? 9 : -1);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275conditional(10, dropLocation_r64.invalid || ctx_r63.question.invalid ? 10 : -1);
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275conditional(12, dropLocation_r64 && ctx_r63.correctDragItemForDropLocation(dropLocation_r64) && !dropLocation_r64.invalid && !ctx_r63.question.invalid ? 12 : -1);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275conditional(13, !dropLocation_r64 || !ctx_r63.correctDragItemForDropLocation(dropLocation_r64) ? 13 : -1);
  }
}
function DragAndDropQuestionComponent_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                        ");
    i05.\u0275\u0275elementStart(1, "div");
    i05.\u0275\u0275text(2, "\n                            ");
    i05.\u0275\u0275repeaterCreate(3, DragAndDropQuestionComponent_Conditional_31_For_4_Template, 16, 15, null, null, i05.\u0275\u0275repeaterTrackByIdentity);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r10 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275repeater(ctx_r10.question.dropLocations);
  }
}
function DragAndDropQuestionComponent_Conditional_36_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275elementStart(1, "div", 26);
    i05.\u0275\u0275text(2, "\n                        ");
    i05.\u0275\u0275element(3, "span", 44);
    i05.\u0275\u0275text(4, "\n                    ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(5, "\n                ");
  }
}
function DragAndDropQuestionComponent_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275element(1, "div");
    i05.\u0275\u0275text(2, "\n                ");
  }
}
function DragAndDropQuestionComponent_Conditional_38_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r83 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n                            ");
    i05.\u0275\u0275elementStart(1, "jhi-drag-item", 46);
    i05.\u0275\u0275listener("dragenter", function DragAndDropQuestionComponent_Conditional_38_For_4_Template_jhi_drag_item_dragenter_1_listener() {
      i05.\u0275\u0275restoreView(_r83);
      const ctx_r82 = i05.\u0275\u0275nextContext(2);
      return i05.\u0275\u0275resetView(ctx_r82.drag());
    })("dragend", function DragAndDropQuestionComponent_Conditional_38_For_4_Template_jhi_drag_item_dragend_1_listener() {
      i05.\u0275\u0275restoreView(_r83);
      const ctx_r84 = i05.\u0275\u0275nextContext(2);
      return i05.\u0275\u0275resetView(ctx_r84.drop());
    });
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const dragItem_r77 = ctx.$implicit;
    const i_r78 = ctx.$index;
    const ctx_r76 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275propertyInterpolate1("id", "drag-item-", i_r78, "");
    i05.\u0275\u0275property("dragItem", dragItem_r77)("clickDisabled", ctx_r76.clickDisabled)("minWidth", "160")("filePreviewPaths", ctx_r76.filePreviewPaths);
  }
}
function DragAndDropQuestionComponent_Conditional_38_Template(rf, ctx) {
  if (rf & 1) {
    const _r86 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275elementStart(1, "div", 45);
    i05.\u0275\u0275listener("cdkDropListDropped", function DragAndDropQuestionComponent_Conditional_38_Template_div_cdkDropListDropped_1_listener($event) {
      i05.\u0275\u0275restoreView(_r86);
      const ctx_r85 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r85.onDragDrop(void 0, $event));
    })("onDragEnter", function DragAndDropQuestionComponent_Conditional_38_Template_div_onDragEnter_1_listener($event) {
      i05.\u0275\u0275restoreView(_r86);
      const ctx_r87 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r87.preventDefault($event));
    })("onDragOver", function DragAndDropQuestionComponent_Conditional_38_Template_div_onDragOver_1_listener($event) {
      i05.\u0275\u0275restoreView(_r86);
      const ctx_r88 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r88.preventDefault($event));
    })("onDragLeave", function DragAndDropQuestionComponent_Conditional_38_Template_div_onDragLeave_1_listener($event) {
      i05.\u0275\u0275restoreView(_r86);
      const ctx_r89 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r89.preventDefault($event));
    });
    i05.\u0275\u0275text(2, "\n                        ");
    i05.\u0275\u0275repeaterCreate(3, DragAndDropQuestionComponent_Conditional_38_For_4_Template, 3, 5, null, null, i05.\u0275\u0275repeaterTrackByIdentity);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r13 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("ngClass", ctx_r13.dropAllowed ? "drop-allowed" : "")("cdkDropListAutoScrollStep", 60);
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275repeater(ctx_r13.getUnassignedDragItems());
  }
}
var _c03, _c12, _c22, MappingResult, DragAndDropQuestionComponent;
var init_drag_and_drop_question_component = __esm({
  "src/main/webapp/app/exercises/quiz/shared/questions/drag-and-drop-question/drag-and-drop-question.component.ts"() {
    init_markdown_service();
    init_drag_and_drop_question_util_service();
    init_secured_image_component();
    init_drag_and_drop_mapping_model();
    init_quiz_question_model();
    init_markdown_service();
    init_drag_and_drop_question_util_service();
    init_translate_directive();
    init_secured_image_component();
    init_drag_item_component();
    init_quiz_scoring_info_student_modal_component();
    init_artemis_translate_pipe();
    _c03 = (a0) => ({ incorrect: a0 });
    _c12 = (a0, a1, a2, a3) => ({ top: a0, left: a1, width: a2, height: a3 });
    _c22 = (a0, a1, a2) => ({ disabled: a0, result: a1, incorrect: a2 });
    polyfill({
      dragImageTranslateOverride: scrollBehaviourDragImageTranslateOverride
    });
    window.addEventListener("touchmove", () => {
    }, { passive: false });
    (function(MappingResult2) {
      MappingResult2[MappingResult2["MAPPED_CORRECT"] = 0] = "MAPPED_CORRECT";
      MappingResult2[MappingResult2["MAPPED_INCORRECT"] = 1] = "MAPPED_INCORRECT";
      MappingResult2[MappingResult2["NOT_MAPPED"] = 2] = "NOT_MAPPED";
    })(MappingResult || (MappingResult = {}));
    DragAndDropQuestionComponent = class _DragAndDropQuestionComponent {
      artemisMarkdown;
      dragAndDropQuestionUtil;
      secureImageComponent;
      _question;
      _forceSampleSolution;
      set question(question) {
        this._question = question;
        this.watchCollection();
      }
      get question() {
        return this._question;
      }
      mappings;
      clickDisabled;
      showResult;
      questionIndex;
      score;
      set forceSampleSolution(forceSampleSolution) {
        this._forceSampleSolution = forceSampleSolution;
        if (this.forceSampleSolution) {
          this.showSampleSolution();
        }
      }
      get forceSampleSolution() {
        return this._forceSampleSolution;
      }
      onMappingUpdate;
      filePreviewPaths = /* @__PURE__ */ new Map();
      mappingsChange = new EventEmitter();
      showingSampleSolution = false;
      renderedQuestion;
      sampleSolutionMappings = new Array();
      dropAllowed = false;
      correctAnswer;
      incorrectLocationMappings;
      mappedLocations;
      MappingResult = MappingResult;
      loadingState = "loading";
      faSpinner = faSpinner;
      faQuestionCircle = faQuestionCircle2;
      faExclamationTriangle = faExclamationTriangle;
      faExclamationCircle = faExclamationCircle;
      constructor(artemisMarkdown, dragAndDropQuestionUtil) {
        this.artemisMarkdown = artemisMarkdown;
        this.dragAndDropQuestionUtil = dragAndDropQuestionUtil;
      }
      ngOnInit() {
        this.evaluateDropLocations();
      }
      ngOnChanges() {
        this.evaluateDropLocations();
      }
      watchCollection() {
        this.renderedQuestion = new RenderedQuizQuestionMarkDownElement();
        this.renderedQuestion.text = this.artemisMarkdown.safeHtmlForMarkdown(this.question.text);
        this.renderedQuestion.hint = this.artemisMarkdown.safeHtmlForMarkdown(this.question.hint);
        this.renderedQuestion.explanation = this.artemisMarkdown.safeHtmlForMarkdown(this.question.explanation);
      }
      drag() {
        this.dropAllowed = true;
      }
      drop() {
        this.dropAllowed = false;
      }
      changeLoading(value) {
        this.loadingState = value;
      }
      preventDefault(event) {
        event.mouseEvent.preventDefault();
        return false;
      }
      onDragDrop(dropLocation, dropEvent) {
        this.drop();
        const dragItem = dropEvent.item.data;
        if (dropLocation) {
          if (this.dragAndDropQuestionUtil.isMappedTogether(this.mappings, dragItem, dropLocation)) {
            return;
          }
          let oldDragItem;
          let oldDropLocation;
          this.mappings = this.mappings.filter(function(mapping) {
            if (this.dragAndDropQuestionUtil.isSameEntityWithTempId(dropLocation, mapping.dropLocation)) {
              oldDragItem = mapping.dragItem;
              return false;
            }
            if (this.dragAndDropQuestionUtil.isSameEntityWithTempId(dragItem, mapping.dragItem)) {
              oldDropLocation = mapping.dropLocation;
              return false;
            }
            return true;
          }, this);
          this.mappings.push(new DragAndDropMapping(dragItem, dropLocation));
          if (oldDragItem && oldDropLocation) {
            this.mappings.push(new DragAndDropMapping(oldDragItem, oldDropLocation));
          }
        } else {
          const lengthBefore = this.mappings.length;
          this.mappings = this.mappings.filter(function(mapping) {
            return !this.dragAndDropQuestionUtil.isSameEntityWithTempId(mapping.dragItem, dragItem);
          }, this);
          if (this.mappings.length === lengthBefore) {
            return;
          }
        }
        this.mappingsChange.emit(this.mappings);
        if (this.onMappingUpdate) {
          this.onMappingUpdate();
        }
      }
      dragItemForDropLocation(dropLocation) {
        if (this.mappings) {
          const mapping = this.mappings.find((localMapping) => this.dragAndDropQuestionUtil.isSameEntityWithTempId(localMapping.dropLocation, dropLocation));
          if (mapping) {
            return mapping.dragItem;
          } else {
            return void 0;
          }
        }
        return void 0;
      }
      invalidDragItemForDropLocation(dropLocation) {
        const item = this.dragItemForDropLocation(dropLocation);
        return item ? item.invalid : false;
      }
      getUnassignedDragItems() {
        return this.question.dragItems?.filter((dragItem) => {
          return !this.mappings?.some((mapping) => {
            return this.dragAndDropQuestionUtil.isSameEntityWithTempId(mapping.dragItem, dragItem);
          }, this);
        }, this);
      }
      isLocationCorrect(dropLocation) {
        if (!this.question.correctMappings) {
          return MappingResult.MAPPED_INCORRECT;
        }
        const validDragItems = this.question.correctMappings.filter(function(mapping) {
          return this.dragAndDropQuestionUtil.isSameEntityWithTempId(mapping.dropLocation, dropLocation);
        }, this).map(function(mapping) {
          return mapping.dragItem;
        });
        const selectedItem = this.dragItemForDropLocation(dropLocation);
        if (!selectedItem) {
          return validDragItems.length === 0 ? MappingResult.NOT_MAPPED : MappingResult.MAPPED_INCORRECT;
        } else {
          return validDragItems.some(function(dragItem) {
            return this.dragAndDropQuestionUtil.isSameEntityWithTempId(dragItem, selectedItem);
          }, this) ? MappingResult.MAPPED_CORRECT : MappingResult.MAPPED_INCORRECT;
        }
      }
      isAssignedLocation(dropLocation) {
        if (!this.question.correctMappings) {
          return false;
        }
        return this.question.correctMappings.some((mapping) => this.dragAndDropQuestionUtil.isSameEntityWithTempId(dropLocation, mapping.dropLocation));
      }
      showSampleSolution() {
        this.sampleSolutionMappings = this.dragAndDropQuestionUtil.solve(this.question, this.mappings);
        this.showingSampleSolution = true;
      }
      hideSampleSolution() {
        this.showingSampleSolution = false;
      }
      correctDragItemForDropLocation(dropLocation) {
        const dragAndDropQuestionUtil = this.dragAndDropQuestionUtil;
        const mapping = this.sampleSolutionMappings.find(function(solutionMapping) {
          return dragAndDropQuestionUtil.isSameEntityWithTempId(solutionMapping.dropLocation, dropLocation);
        });
        return mapping?.dragItem;
      }
      evaluateDropLocations() {
        if (this.question.dropLocations) {
          this.correctAnswer = this.question.dropLocations.filter((dropLocation) => this.isLocationCorrect(dropLocation) === MappingResult.MAPPED_CORRECT).length;
          this.incorrectLocationMappings = this.question.dropLocations.filter((dropLocation) => this.isLocationCorrect(dropLocation) === MappingResult.MAPPED_INCORRECT).length;
          this.mappedLocations = this.question.dropLocations.filter((dropLocation) => this.isAssignedLocation(dropLocation)).length;
        }
      }
      static \u0275fac = function DragAndDropQuestionComponent_Factory(t) {
        return new (t || _DragAndDropQuestionComponent)(i05.\u0275\u0275directiveInject(ArtemisMarkdownService), i05.\u0275\u0275directiveInject(DragAndDropQuestionUtil));
      };
      static \u0275cmp = i05.\u0275\u0275defineComponent({ type: _DragAndDropQuestionComponent, selectors: [["jhi-drag-and-drop-question"]], viewQuery: function DragAndDropQuestionComponent_Query(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275viewQuery(SecuredImageComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i05.\u0275\u0275queryRefresh(_t = i05.\u0275\u0275loadQuery()) && (ctx.secureImageComponent = _t.first);
        }
      }, inputs: { question: "question", mappings: "mappings", clickDisabled: "clickDisabled", showResult: "showResult", questionIndex: "questionIndex", score: "score", forceSampleSolution: "forceSampleSolution", onMappingUpdate: "onMappingUpdate", filePreviewPaths: "filePreviewPaths" }, outputs: { mappingsChange: "mappingsChange" }, features: [i05.\u0275\u0275ProvidersFeature([DragAndDropQuestionUtil]), i05.\u0275\u0275NgOnChangesFeature], decls: 43, vars: 24, consts: [[1, "dnd-question", "markdown-preview", 3, "ngClass"], [3, "hidden"], [1, "question-title-display"], [3, "innerHTML"], ["cdkDropListGroup", "", 1, "drag-and-drop-area"], [1, "background-area"], [1, "click-layer"], [1, "drag-and-drop-items"], [2, "color", "grey"], [3, "icon", "spin"], [3, "icon"], [1, "btn", "btn-default", 3, "click"], ["jhiTranslate", "artemisApp.quizQuestion.invalidText", 2, "color", "red"], [1, "hint"], ["renderedHint", ""], ["renderedExplanation", ""], ["triggers", "mouseenter:mouseleave", 1, "label", "label-info", 3, "ngbPopover"], ["jhiTranslate", "artemisApp.quizQuestion.hint"], ["triggers", "mouseenter:mouseleave", 1, "label", "label-primary", 3, "ngbPopover"], ["jhiTranslate", "artemisApp.quizQuestion.explanation"], [1, "question-score"], ["jhiTranslate", "artemisApp.quizQuestion.score", 1, "colon-suffix"], [1, "question-score", "result", 3, "ngClass"], ["jhiTranslate", "artemisApp.quizQuestion.yourScore", 1, "colon-suffix"], [1, "show-explanation"], [3, "score", "question", "dragAndDropMapping", "correctlyMappedDragAndDropItems", "incorrectlyMappedDragAndDropItems", "mappedLocations", "questionIndex"], [1, "dnd-instructions"], ["jhiTranslate", "artemisApp.dragAndDropQuestion.showingSampleSolution"], ["jhiTranslate", "artemisApp.dragAndDropQuestion.showingYourAnswer"], [1, "btn", "btn-outline-primary", 3, "click"], [3, "src", "endLoadingProcess"], ["id", "drop-location", "cdkDropList", "", 1, "drop-location", 3, "ngClass", "ngStyle", "cdkDropListAutoScrollStep", "cdkDropListDropped", "onDragEnter", "onDragOver", "onDragLeave"], [3, "dragItem", "clickDisabled", "minWidth", "filePreviewPaths", "dragenter", "dragend"], [1, "drop-location", "results", 3, "ngClass", "ngStyle"], [1, "invalid"], [1, "result-symbol"], ["size", "2x", 1, "warning", 3, "icon"], ["jhiTranslate", "artemisApp.dragAndDropQuestion.invalid.dropLocation"], ["jhiTranslate", "artemisApp.dragAndDropQuestion.invalid.dragItem"], ["jhiTranslate", "artemisApp.quizQuestion.invalid"], ["ngbTooltip", "Invalid Drop Locations and invalid Drag Items will be assessed as correct.", 2, "color", "black", 3, "icon"], [3, "dragItem", "clickDisabled", "minWidth", "filePreviewPaths"], [1, "drag-item", "no-click"], [1, "drop-location", "sampleSolution", 3, "ngClass", "ngStyle"], ["jhiTranslate", "artemisApp.dragAndDropQuestion.studentInstructions"], ["id", "drag-items", "cdkDropList", "", 1, "drag-items", 3, "ngClass", "cdkDropListAutoScrollStep", "cdkDropListDropped", "onDragEnter", "onDragOver", "onDragLeave"], [3, "id", "dragItem", "clickDisabled", "minWidth", "filePreviewPaths", "dragenter", "dragend"]], template: function DragAndDropQuestionComponent_Template(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275elementStart(0, "div", 0);
          i05.\u0275\u0275text(1, "\n    ");
          i05.\u0275\u0275elementStart(2, "div", 1);
          i05.\u0275\u0275text(3, "\n        ");
          i05.\u0275\u0275template(4, DragAndDropQuestionComponent_Conditional_4_Template, 11, 5)(5, DragAndDropQuestionComponent_Conditional_5_Template, 21, 7);
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(6, "\n    ");
          i05.\u0275\u0275elementStart(7, "div", 1);
          i05.\u0275\u0275text(8, "\n        ");
          i05.\u0275\u0275elementStart(9, "h4", 2);
          i05.\u0275\u0275text(10, "\n            ");
          i05.\u0275\u0275elementStart(11, "span");
          i05.\u0275\u0275text(12);
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(13);
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(14, "\n        ");
          i05.\u0275\u0275element(15, "p", 3);
          i05.\u0275\u0275text(16, "\n        ");
          i05.\u0275\u0275template(17, DragAndDropQuestionComponent_Conditional_17_Template, 3, 0)(18, DragAndDropQuestionComponent_Conditional_18_Template, 14, 2)(19, DragAndDropQuestionComponent_Conditional_19_Template, 9, 1)(20, DragAndDropQuestionComponent_Conditional_20_Template, 14, 12)(21, DragAndDropQuestionComponent_Conditional_21_Template, 7, 3);
          i05.\u0275\u0275elementStart(22, "div", 4);
          i05.\u0275\u0275text(23, "\n            ");
          i05.\u0275\u0275elementStart(24, "div", 5);
          i05.\u0275\u0275text(25, "\n                ");
          i05.\u0275\u0275template(26, DragAndDropQuestionComponent_Conditional_26_Template, 3, 1);
          i05.\u0275\u0275elementStart(27, "div", 6);
          i05.\u0275\u0275text(28, "\n                    ");
          i05.\u0275\u0275template(29, DragAndDropQuestionComponent_Conditional_29_Template, 6, 0)(30, DragAndDropQuestionComponent_Conditional_30_Template, 6, 0)(31, DragAndDropQuestionComponent_Conditional_31_Template, 6, 0);
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(32, "\n            ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(33, "\n            ");
          i05.\u0275\u0275elementStart(34, "div", 7);
          i05.\u0275\u0275text(35, "\n                ");
          i05.\u0275\u0275template(36, DragAndDropQuestionComponent_Conditional_36_Template, 6, 0)(37, DragAndDropQuestionComponent_Conditional_37_Template, 3, 0)(38, DragAndDropQuestionComponent_Conditional_38_Template, 6, 2);
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(39, "\n        ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(40, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(41, "\n");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(42, "\n");
        }
        if (rf & 2) {
          i05.\u0275\u0275property("ngClass", i05.\u0275\u0275pureFunction3(20, _c22, ctx.clickDisabled && !ctx.showResult, ctx.showResult && !ctx.forceSampleSolution, (ctx.score || 0) < ctx.question.points && !ctx.forceSampleSolution));
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275property("hidden", ctx.loadingState === "success");
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275conditional(4, ctx.loadingState !== "error" ? 4 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(5, ctx.loadingState === "error" ? 5 : -1);
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275property("hidden", ctx.loadingState !== "success");
          i05.\u0275\u0275advance(5);
          i05.\u0275\u0275textInterpolate1("", ctx.questionIndex, ")");
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275textInterpolate1(" ", ctx.question.title, "\n        ");
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275property("innerHTML", ctx.renderedQuestion.text, i05.\u0275\u0275sanitizeHtml);
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275conditional(17, ctx.question.invalid ? 17 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(18, ctx.question.hint || ctx.question.explanation && ctx.showResult ? 18 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(19, !ctx.showResult || ctx.forceSampleSolution ? 19 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(20, ctx.showResult && !ctx.forceSampleSolution ? 20 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(21, ctx.showResult ? 21 : -1);
          i05.\u0275\u0275advance(5);
          i05.\u0275\u0275conditional(26, ctx.question.backgroundFilePath ? 26 : -1);
          i05.\u0275\u0275advance(3);
          i05.\u0275\u0275conditional(29, !ctx.showResult ? 29 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(30, ctx.showResult && !ctx.showingSampleSolution && ctx.question.dropLocations ? 30 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(31, ctx.showResult && ctx.showingSampleSolution ? 31 : -1);
          i05.\u0275\u0275advance(5);
          i05.\u0275\u0275conditional(36, !ctx.showResult ? 36 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(37, ctx.showResult ? 37 : -1);
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(38, !ctx.showResult ? 38 : -1);
        }
      }, dependencies: [i32.NgClass, i32.NgStyle, i43.NgbPopover, i43.NgbTooltip, i5.FaIconComponent, TranslateDirective, SecuredImageComponent, i8.CdkDropList, i8.CdkDropListGroup, DragItemComponent, QuizScoringInfoStudentModalComponent, ArtemisTranslatePipe], styles: ["/* src/main/webapp/app/exercises/quiz/shared/questions/drag-and-drop-question/drag-and-drop-question.component.scss */\n.dnd-question {\n  background: var(--quiz-question-background);\n  border: 1px solid var(--quiz-question-border-color);\n  box-sizing: border-box;\n  margin-bottom: 18px;\n  padding: 20px;\n  position: relative;\n  width: 100%;\n}\n.dnd-question .dnd-instructions {\n  display: flex;\n  justify-content: space-between;\n  margin: 10px 0;\n  font-weight: 500;\n}\n.dnd-question .drag-and-drop-area {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n@media (max-width: 1199.98px) {\n  .dnd-question .drag-and-drop-area {\n    flex-direction: column;\n  }\n}\n.dnd-question .drag-and-drop-area .background-area {\n  position: relative;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none;\n}\n.dnd-question .drag-and-drop-area .background-area > jhi-secured-image img {\n  max-width: 100%;\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer {\n  position: absolute;\n  top: 0;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  z-index: 1;\n  width: 100%;\n  height: 100%;\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location {\n  position: absolute;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: center;\n  background: var(--dnd-question-drop-location-background);\n  border: 1px dashed var(--dnd-question-drop-location-border-color);\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location.drop-hover,\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location.drop-allowed > *,\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location .dnd-drag-over > * {\n  opacity: 0.5;\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location.results {\n  border-color: var(--dnd-question-drop-location-results-border-color);\n  background: var(--dnd-question-drop-location-results-background);\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location.results > * {\n  opacity: 0.8;\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location.results.incorrect {\n  border-color: var(--dnd-question-drop-location-results-incorrect-border-color);\n  background: var(--dnd-question-drop-location-results-incorrect-background);\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location.results .drag-item {\n  background: transparent;\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location.sampleSolution {\n  border-color: var(--dnd-question-drop-location-results-sample-border-color);\n  background: var(--dnd-question-drop-location-results-sample-background);\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location.sampleSolution > * {\n  opacity: 1;\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location .result-symbol {\n  color: var(--dnd-question-drop-location-result-symbol-color);\n  position: absolute;\n  top: 0;\n  left: 0;\n  z-index: 1;\n  opacity: 1;\n  -webkit-transform: translate3d(-63%, -63%, 0);\n  -moz-transform: translate3d(-63%, -63%, 0);\n  -ms-transform: translate3d(-63%, -63%, 0);\n  -o-transform: translate3d(-63%, -63%, 0);\n  transform: translate3d(-63%, -63%, 0);\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location .invalid {\n  color: var(--dnd-question-drop-location-result-invalid-color);\n  position: absolute;\n  bottom: 0px;\n  left: 2px;\n  z-index: 1;\n  opacity: 1;\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location jhi-drag-item,\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location .drag-item {\n  width: 100%;\n  height: 100%;\n  margin: 0;\n  background: var(--dnd-question-drop-location-drag-item-background);\n}\n@media (max-width: 991.98px) {\n  .dnd-question .drag-and-drop-area .background-area .click-layer .drop-location jhi-drag-item div,\n  .dnd-question .drag-and-drop-area .background-area .click-layer .drop-location .drag-item div {\n    padding: 0 !important;\n  }\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location jhi-drag-item img,\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location .drag-item img {\n  max-height: 100%;\n  max-width: 100%;\n  height: auto;\n  width: auto !important;\n  margin: auto;\n  position: absolute;\n  transform: translate(-50%, -50%);\n  top: 50%;\n  left: 50%;\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location jhi-drag-item .drag-item-text,\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location jhi-drag-item .drag-item-picture,\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location .drag-item .drag-item-text,\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location .drag-item .drag-item-picture {\n  line-height: 1;\n}\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location jhi-drag-item .drag-item-text span,\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location jhi-drag-item .drag-item-picture span,\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location .drag-item .drag-item-text span,\n.dnd-question .drag-and-drop-area .background-area .click-layer .drop-location .drag-item .drag-item-picture span {\n  border: none;\n  vertical-align: middle;\n  display: inline-block;\n  font-size: 1rem;\n}\n@media (min-width: 1200px) {\n  .dnd-question .drag-and-drop-area .drag-and-drop-items {\n    margin: -6px 0 0 20px;\n  }\n}\n@media (min-width: 1200px) {\n  .dnd-question .drag-and-drop-area .drag-and-drop-items .dnd-instructions {\n    margin: 0 0 10px 0;\n  }\n}\n.dnd-question .drag-and-drop-area .drag-and-drop-items .drag-items {\n  background: var(--dnd-question-dnd-items-drag-items-background) !important;\n  display: flex;\n  flex-direction: row;\n  flex-wrap: wrap;\n  justify-content: flex-start;\n  align-items: center;\n  margin-left: auto;\n  margin-right: auto;\n  min-height: 50px;\n  overflow: auto;\n  max-height: calc(100vh - 90px);\n}\n@media (min-width: 1200px) {\n  .dnd-question .drag-and-drop-area .drag-and-drop-items .drag-items {\n    flex-direction: column;\n    flex-wrap: nowrap;\n  }\n}\n.dnd-question .cdk-drop-list-receiving {\n  background: var(--dnd-question-drop-list-receiving-background) !important;\n}\n.dnd-question .cdk-drop-list-dragging {\n  background: var(--dnd-question-drop-list-dragging-background) !important;\n  cursor: pointer;\n}\n.dnd-question .cdk-drag {\n  cursor: pointer;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2NvbnRlbnQvc2Nzcy9fYXJ0ZW1pcy1taXhpbnMuc2NzcyIsICJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9xdWl6L3NoYXJlZC9xdWVzdGlvbnMvZHJhZy1hbmQtZHJvcC1xdWVzdGlvbi9kcmFnLWFuZC1kcm9wLXF1ZXN0aW9uLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIvKiBkZWZpbmUgcG9zaXRpb24gc3R5bGUgbWl4aW4gKi9cbkBtaXhpbiBwb3NpdGlvbi1zdHlsZSgkcG9zaXRpb24sICR0b3AsICRsZWZ0LCAkYm90dG9tLCAkcmlnaHQsICR6LWluZGV4KSB7XG4gICAgcG9zaXRpb246ICRwb3NpdGlvbjtcbiAgICB0b3A6ICR0b3A7XG4gICAgbGVmdDogJGxlZnQ7XG4gICAgYm90dG9tOiAkYm90dG9tO1xuICAgIHJpZ2h0OiAkcmlnaHQ7XG4gICAgei1pbmRleDogJHotaW5kZXg7XG59XG5cbi8qIGRlZmluZSB1c2VyLXNlbGVjdCBtaXhpbiAqL1xuQG1peGluIHVzZXItc2VsZWN0KCR2YWx1ZSkge1xuICAgIC13ZWJraXQtdXNlci1zZWxlY3Q6ICR2YWx1ZTtcbiAgICAtbW96LXVzZXItc2VsZWN0OiAkdmFsdWU7XG4gICAgLW1zLXVzZXItc2VsZWN0OiAkdmFsdWU7XG4gICAgdXNlci1zZWxlY3Q6ICR2YWx1ZTtcbn1cblxuLyogYXBwbHkgdHJhbnNmb3JtIHRyYW5zbGF0ZTNkIG1peGluICovXG5AbWl4aW4gdHJhbnNmb3JtVHJhbnNsYXRlM0QoJHR4LCAkdHksICR0eikge1xuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgkdHgsICR0eSwgJHR6KTtcbiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoJHR4LCAkdHksICR0eik7XG4gICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoJHR4LCAkdHksICR0eik7XG4gICAgLW8tdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgkdHgsICR0eSwgJHR6KTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKCR0eCwgJHR5LCAkdHopO1xufVxuXG4vKiBxdWl6IG1hcHBpbmcgbGV0dGVyIG9yIG51bWJlciBtaXhpbiAqL1xuQG1peGluIHF1aXotbWFwcGluZy1sZXR0ZXItbnVtYmVyKCRjb2xvcikge1xuICAgIHdpZHRoOiAzMHB4O1xuICAgIGhlaWdodDogMzBweDtcbiAgICBsaW5lLWhlaWdodDogMzBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkY29sb3I7XG4gICAgY29sb3I6IHZhcigtLXF1aXotbWFwcGluZy1sZXR0ZXItbnVtYmVyLW1peGluLWNvbG9yKTtcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4vKiBkbmQgcXVpeiBzdGF0aXN0aWMgbGV0dGVyIHBvc2l0aW9uIG1peGluICovXG5AbWl4aW4gZG5kLWxldHRlci1wb3NpdGlvbigkdHgsICR0eSwgJHR6KSB7XG4gICAgQGluY2x1ZGUgdHJhbnNmb3JtVHJhbnNsYXRlM0QoJHR4LCAkdHksICR0eik7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMyU7XG4gICAgbGVmdDogMyU7XG4gICAgei1pbmRleDogMTtcbiAgICBvcGFjaXR5OiAxO1xufVxuIiwgIkBpbXBvcnQgJy4uLy4uLy4uLy4uLy4uLy4uL2NvbnRlbnQvc2Nzcy9hcnRlbWlzLW1peGlucyc7XG5cbi5kbmQtcXVlc3Rpb24ge1xuICAgIGJhY2tncm91bmQ6IHZhcigtLXF1aXotcXVlc3Rpb24tYmFja2dyb3VuZCk7XG4gICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tcXVpei1xdWVzdGlvbi1ib3JkZXItY29sb3IpO1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgbWFyZ2luLWJvdHRvbTogMThweDtcbiAgICBwYWRkaW5nOiAyMHB4O1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB3aWR0aDogMTAwJTtcblxuICAgIC5kbmQtaW5zdHJ1Y3Rpb25zIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICBtYXJnaW46IDEwcHggMDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICB9XG5cbiAgICAuZHJhZy1hbmQtZHJvcC1hcmVhIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDExOTkuOThweCkge1xuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qIGJhY2tncm91bmQgaW1hZ2UgYW5kIGNsaWNrLWxheWVyIHN0eWxlcyAqL1xuICAgICAgICAuYmFja2dyb3VuZC1hcmVhIHtcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgICAgIEBpbmNsdWRlIHVzZXItc2VsZWN0KG5vbmUpO1xuXG4gICAgICAgICAgICA+IGpoaS1zZWN1cmVkLWltYWdlIGltZyB7XG4gICAgICAgICAgICAgICAgbWF4LXdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuY2xpY2stbGF5ZXIge1xuICAgICAgICAgICAgICAgIEBpbmNsdWRlIHBvc2l0aW9uLXN0eWxlKGFic29sdXRlLCAwLCAwLCAwLCAwLCAxKTtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG5cbiAgICAgICAgICAgICAgICAvKiBkb3R0ZWQgZHJvcC1sb2NhdGlvbiAqL1xuICAgICAgICAgICAgICAgIC5kcm9wLWxvY2F0aW9uIHtcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tZG5kLXF1ZXN0aW9uLWRyb3AtbG9jYXRpb24tYmFja2dyb3VuZCk7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IGRhc2hlZCB2YXIoLS1kbmQtcXVlc3Rpb24tZHJvcC1sb2NhdGlvbi1ib3JkZXItY29sb3IpO1xuXG4gICAgICAgICAgICAgICAgICAgICYuZHJvcC1ob3ZlcixcbiAgICAgICAgICAgICAgICAgICAgJi5kcm9wLWFsbG93ZWQgPiAqLFxuICAgICAgICAgICAgICAgICAgICAuZG5kLWRyYWctb3ZlciA+ICoge1xuICAgICAgICAgICAgICAgICAgICAgICAgb3BhY2l0eTogMC41O1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgJi5yZXN1bHRzIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlci1jb2xvcjogdmFyKC0tZG5kLXF1ZXN0aW9uLWRyb3AtbG9jYXRpb24tcmVzdWx0cy1ib3JkZXItY29sb3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tZG5kLXF1ZXN0aW9uLWRyb3AtbG9jYXRpb24tcmVzdWx0cy1iYWNrZ3JvdW5kKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgPiAqIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLjg7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICYuaW5jb3JyZWN0IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItY29sb3I6IHZhcigtLWRuZC1xdWVzdGlvbi1kcm9wLWxvY2F0aW9uLXJlc3VsdHMtaW5jb3JyZWN0LWJvcmRlci1jb2xvcik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tZG5kLXF1ZXN0aW9uLWRyb3AtbG9jYXRpb24tcmVzdWx0cy1pbmNvcnJlY3QtYmFja2dyb3VuZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC5kcmFnLWl0ZW0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgJi5zYW1wbGVTb2x1dGlvbiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItY29sb3I6IHZhcigtLWRuZC1xdWVzdGlvbi1kcm9wLWxvY2F0aW9uLXJlc3VsdHMtc2FtcGxlLWJvcmRlci1jb2xvcik7XG4gICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1kbmQtcXVlc3Rpb24tZHJvcC1sb2NhdGlvbi1yZXN1bHRzLXNhbXBsZS1iYWNrZ3JvdW5kKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgPiAqIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLnJlc3VsdC1zeW1ib2wge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWRuZC1xdWVzdGlvbi1kcm9wLWxvY2F0aW9uLXJlc3VsdC1zeW1ib2wtY29sb3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9wOiAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHotaW5kZXg6IDE7XG4gICAgICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgQGluY2x1ZGUgdHJhbnNmb3JtVHJhbnNsYXRlM0QoLTYzJSwgLTYzJSwgMCk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAuaW52YWxpZCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0tZG5kLXF1ZXN0aW9uLWRyb3AtbG9jYXRpb24tcmVzdWx0LWludmFsaWQtY29sb3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tOiAwcHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiAycHg7XG4gICAgICAgICAgICAgICAgICAgICAgICB6LWluZGV4OiAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgb3BhY2l0eTogMTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGpoaS1kcmFnLWl0ZW0sXG4gICAgICAgICAgICAgICAgICAgIC5kcmFnLWl0ZW0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1kbmQtcXVlc3Rpb24tZHJvcC1sb2NhdGlvbi1kcmFnLWl0ZW0tYmFja2dyb3VuZCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpdiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDk5MS45OHB4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGltZyB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4LWhlaWdodDogMTAwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXgtd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiBhdXRvICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiBhdXRvO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC5kcmFnLWl0ZW0tdGV4dCxcbiAgICAgICAgICAgICAgICAgICAgICAgIC5kcmFnLWl0ZW0tcGljdHVyZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDE7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcGFuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBub25lO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMXJlbTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvKiBkcmFnIGFuZCBkcm9wIGl0ZW1zIGFyZWEgd2l0aCBncmV5IGJhY2tncm91bmQgKi9cbiAgICAgICAgLmRyYWctYW5kLWRyb3AtaXRlbXMge1xuICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDEyMDBweCkge1xuICAgICAgICAgICAgICAgIG1hcmdpbjogLTZweCAwIDAgMjBweDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLmRuZC1pbnN0cnVjdGlvbnMge1xuICAgICAgICAgICAgICAgIEBtZWRpYSAobWluLXdpZHRoOiAxMjAwcHgpIHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwIDAgMTBweCAwO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLmRyYWctaXRlbXMge1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWRuZC1xdWVzdGlvbi1kbmQtaXRlbXMtZHJhZy1pdGVtcy1iYWNrZ3JvdW5kKSAhaW1wb3J0YW50O1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICAgICAgICAgICAgICBmbGV4LXdyYXA6IHdyYXA7XG4gICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xuICAgICAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDUwcHg7XG4gICAgICAgICAgICAgICAgb3ZlcmZsb3c6IGF1dG87XG4gICAgICAgICAgICAgICAgbWF4LWhlaWdodDogY2FsYygxMDB2aCAtIDkwcHgpO1xuXG4gICAgICAgICAgICAgICAgQG1lZGlhIChtaW4td2lkdGg6IDEyMDBweCkge1xuICAgICAgICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAgICAgICAgICBmbGV4LXdyYXA6IG5vd3JhcDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKiBoaWdobGlnaHQgZHJvcCBsb2NhdGlvbiBpbiBsaWdodCBibHVlIHdoZW4gc2VsZWN0aW5nIGEgZHJhZyBpdGVtICovXG4gICAgLmNkay1kcm9wLWxpc3QtcmVjZWl2aW5nIHtcbiAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tZG5kLXF1ZXN0aW9uLWRyb3AtbGlzdC1yZWNlaXZpbmctYmFja2dyb3VuZCkgIWltcG9ydGFudDtcbiAgICB9XG4gICAgLyogY2hhbmdlIGhpZ2hsaWdodCBjb2xvciB0byBsaWdodCBncmVlbiB3aGVuIGRyYWdnaW5nIHRoZSBpdGVtIGFib3ZlIGEgZHJvcCBsb2NhdGlvbiAqL1xuICAgIC5jZGstZHJvcC1saXN0LWRyYWdnaW5nIHtcbiAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tZG5kLXF1ZXN0aW9uLWRyb3AtbGlzdC1kcmFnZ2luZy1iYWNrZ3JvdW5kKSAhaW1wb3J0YW50O1xuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgfVxuXG4gICAgLmNkay1kcmFnIHtcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUNFQSxDQUFBO0FBQ0ksY0FBQSxJQUFBO0FBQ0EsVUFBQSxJQUFBLE1BQUEsSUFBQTtBQUNBLGNBQUE7QUFDQSxpQkFBQTtBQUNBLFdBQUE7QUFDQSxZQUFBO0FBQ0EsU0FBQTs7QUFFQSxDQVRKLGFBU0ksQ0FBQTtBQUNJLFdBQUE7QUFDQSxtQkFBQTtBQUNBLFVBQUEsS0FBQTtBQUNBLGVBQUE7O0FBR0osQ0FoQkosYUFnQkksQ0FBQTtBQUNJLFdBQUE7QUFDQSxtQkFBQTtBQUNBLGVBQUE7O0FBRUEsT0FBQSxDQUFBLFNBQUEsRUFBQTtBQUxKLEdBaEJKLGFBZ0JJLENBQUE7QUFNUSxvQkFBQTs7O0FBSUosQ0ExQlIsYUEwQlEsQ0FWSixtQkFVSSxDQUFBO0FBQ0ksWUFBQTtBRGpCUix1QkNrQjZCO0FEakI3QixvQkNpQjZCO0FEaEI3QixtQkNnQjZCO0FEZjdCLGVDZTZCOztBQUVyQixDQTlCWixhQThCWSxDQWRSLG1CQWNRLENBSkosZ0JBSUksRUFBQSxrQkFBQTtBQUNJLGFBQUE7O0FBR0osQ0FsQ1osYUFrQ1ksQ0FsQlIsbUJBa0JRLENBUkosZ0JBUUksQ0FBQTtBRGxDUixZQ21Db0M7QURsQ3BDLE9Da0M4QztBRGpDOUMsUUNpQ2lEO0FEaENqRCxVQ2dDb0Q7QUQvQnBELFNDK0J1RDtBRDlCdkQsV0M4QjBEO0FBQzlDLFNBQUE7QUFDQSxVQUFBOztBQUdBLENBeENoQixhQXdDZ0IsQ0F4QlosbUJBd0JZLENBZFIsZ0JBY1EsQ0FOSixZQU1JLENBQUE7QUFDSSxZQUFBO0FBQ0EsV0FBQTtBQUNBLGtCQUFBO0FBQ0EsZUFBQTtBQUNBLG1CQUFBO0FBQ0EsY0FBQSxJQUFBO0FBQ0EsVUFBQSxJQUFBLE9BQUEsSUFBQTs7QUFFQSxDQWpEcEIsYUFpRG9CLENBakNoQixtQkFpQ2dCLENBdkJaLGdCQXVCWSxDQWZSLFlBZVEsQ0FUSixhQVNJLENBQUE7QUFBQSxDQWpEcEIsYUFpRG9CLENBakNoQixtQkFpQ2dCLENBdkJaLGdCQXVCWSxDQWZSLFlBZVEsQ0FUSixhQVNJLENBQUEsYUFBQSxFQUFBO0FBQUEsQ0FqRHBCLGFBaURvQixDQWpDaEIsbUJBaUNnQixDQXZCWixnQkF1QlksQ0FmUixZQWVRLENBVEosY0FTSSxDQUFBLGNBQUEsRUFBQTtBQUdJLFdBQUE7O0FBR0osQ0F2RHBCLGFBdURvQixDQXZDaEIsbUJBdUNnQixDQTdCWixnQkE2QlksQ0FyQlIsWUFxQlEsQ0FmSixhQWVJLENBQUE7QUFDSSxnQkFBQSxJQUFBO0FBQ0EsY0FBQSxJQUFBOztBQUVBLENBM0R4QixhQTJEd0IsQ0EzQ3BCLG1CQTJDb0IsQ0FqQ2hCLGdCQWlDZ0IsQ0F6QlosWUF5QlksQ0FuQlIsYUFtQlEsQ0FKSixRQUlJLEVBQUE7QUFDSSxXQUFBOztBQUdKLENBL0R4QixhQStEd0IsQ0EvQ3BCLG1CQStDb0IsQ0FyQ2hCLGdCQXFDZ0IsQ0E3QlosWUE2QlksQ0F2QlIsYUF1QlEsQ0FSSixPQVFJLENBQUE7QUFDSSxnQkFBQSxJQUFBO0FBQ0EsY0FBQSxJQUFBOztBQUdKLENBcEV4QixhQW9Fd0IsQ0FwRHBCLG1CQW9Eb0IsQ0ExQ2hCLGdCQTBDZ0IsQ0FsQ1osWUFrQ1ksQ0E1QlIsYUE0QlEsQ0FiSixRQWFJLENBQUE7QUFDSSxjQUFBOztBQUlSLENBekVwQixhQXlFb0IsQ0F6RGhCLG1CQXlEZ0IsQ0EvQ1osZ0JBK0NZLENBdkNSLFlBdUNRLENBakNKLGFBaUNJLENBQUE7QUFDSSxnQkFBQSxJQUFBO0FBQ0EsY0FBQSxJQUFBOztBQUVBLENBN0V4QixhQTZFd0IsQ0E3RHBCLG1CQTZEb0IsQ0FuRGhCLGdCQW1EZ0IsQ0EzQ1osWUEyQ1ksQ0FyQ1IsYUFxQ1EsQ0FKSixlQUlJLEVBQUE7QUFDSSxXQUFBOztBQUlSLENBbEZwQixhQWtGb0IsQ0FsRWhCLG1CQWtFZ0IsQ0F4RFosZ0JBd0RZLENBaERSLFlBZ0RRLENBMUNKLGNBMENJLENBQUE7QUFDSSxTQUFBLElBQUE7QUFDQSxZQUFBO0FBQ0EsT0FBQTtBQUNBLFFBQUE7QUFDQSxXQUFBO0FBQ0EsV0FBQTtBRHRFcEIscUJBQUEsWUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBO0FBQ0Esa0JBQUEsWUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBO0FBQ0EsaUJBQUEsWUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBO0FBQ0EsZ0JBQUEsWUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBO0FBQ0EsYUFBQSxZQUFBLElBQUEsRUFBQSxJQUFBLEVBQUE7O0FDc0VnQixDQTVGcEIsYUE0Rm9CLENBNUVoQixtQkE0RWdCLENBbEVaLGdCQWtFWSxDQTFEUixZQTBEUSxDQXBESixjQW9ESSxDQUFBO0FBQ0ksU0FBQSxJQUFBO0FBQ0EsWUFBQTtBQUNBLFVBQUE7QUFDQSxRQUFBO0FBQ0EsV0FBQTtBQUNBLFdBQUE7O0FBR0osQ0FyR3BCLGFBcUdvQixDQXJGaEIsbUJBcUZnQixDQTNFWixnQkEyRVksQ0FuRVIsWUFtRVEsQ0E3REosY0E2REk7QUFBQSxDQXJHcEIsYUFxR29CLENBckZoQixtQkFxRmdCLENBM0VaLGdCQTJFWSxDQW5FUixZQW1FUSxDQTdESixjQTZESSxDQWpDSTtBQW1DQSxTQUFBO0FBQ0EsVUFBQTtBQUNBLFVBQUE7QUFDQSxjQUFBLElBQUE7O0FBR0ksT0FBQSxDQUFBLFNBQUEsRUFBQTtBQURKLEdBNUd4QixhQTRHd0IsQ0E1RnBCLG1CQTRGb0IsQ0FsRmhCLGdCQWtGZ0IsQ0ExRVosWUEwRVksQ0FwRVIsY0FvRVEsY0FBQTtFQUFBLENBNUd4QixhQTRHd0IsQ0E1RnBCLG1CQTRGb0IsQ0FsRmhCLGdCQWtGZ0IsQ0ExRVosWUEwRVksQ0FwRVIsY0FvRVEsQ0F4Q0EsVUF3Q0E7QUFFUSxhQUFBOzs7QUFJUixDQWxIeEIsYUFrSHdCLENBbEdwQixtQkFrR29CLENBeEZoQixnQkF3RmdCLENBaEZaLFlBZ0ZZLENBMUVSLGNBMEVRLGNBQUE7QUFBQSxDQWxIeEIsYUFrSHdCLENBbEdwQixtQkFrR29CLENBeEZoQixnQkF3RmdCLENBaEZaLFlBZ0ZZLENBMUVSLGNBMEVRLENBOUNBLFVBOENBO0FBQ0ksY0FBQTtBQUNBLGFBQUE7QUFDQSxVQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxZQUFBO0FBQ0EsYUFBQSxVQUFBLElBQUEsRUFBQTtBQUNBLE9BQUE7QUFDQSxRQUFBOztBQUdKLENBOUh4QixhQThId0IsQ0E5R3BCLG1CQThHb0IsQ0FwR2hCLGdCQW9HZ0IsQ0E1RlosWUE0RlksQ0F0RlIsY0FzRlEsY0FBQSxDQUFBO0FBQUEsQ0E5SHhCLGFBOEh3QixDQTlHcEIsbUJBOEdvQixDQXBHaEIsZ0JBb0dnQixDQTVGWixZQTRGWSxDQXRGUixjQXNGUSxjQUFBLENBQUE7QUFBQSxDQTlIeEIsYUE4SHdCLENBOUdwQixtQkE4R29CLENBcEdoQixnQkFvR2dCLENBNUZaLFlBNEZZLENBdEZSLGNBc0ZRLENBMURBLFVBMERBLENBQUE7QUFBQSxDQTlIeEIsYUE4SHdCLENBOUdwQixtQkE4R29CLENBcEdoQixnQkFvR2dCLENBNUZaLFlBNEZZLENBdEZSLGNBc0ZRLENBMURBLFVBMERBLENBQUE7QUFFSSxlQUFBOztBQUVBLENBbEk1QixhQWtJNEIsQ0FsSHhCLG1CQWtId0IsQ0F4R3BCLGdCQXdHb0IsQ0FoR2hCLFlBZ0dnQixDQTFGWixjQTBGWSxjQUFBLENBSkosZUFJSTtBQUFBLENBbEk1QixhQWtJNEIsQ0FsSHhCLG1CQWtId0IsQ0F4R3BCLGdCQXdHb0IsQ0FoR2hCLFlBZ0dnQixDQTFGWixjQTBGWSxjQUFBLENBSkosa0JBSUk7QUFBQSxDQWxJNUIsYUFrSTRCLENBbEh4QixtQkFrSHdCLENBeEdwQixnQkF3R29CLENBaEdoQixZQWdHZ0IsQ0ExRlosY0EwRlksQ0E5REosVUE4REksQ0FKSixlQUlJO0FBQUEsQ0FsSTVCLGFBa0k0QixDQWxIeEIsbUJBa0h3QixDQXhHcEIsZ0JBd0dvQixDQWhHaEIsWUFnR2dCLENBMUZaLGNBMEZZLENBOURKLFVBOERJLENBSkosa0JBSUk7QUFDSSxVQUFBO0FBQ0Esa0JBQUE7QUFDQSxXQUFBO0FBQ0EsYUFBQTs7QUFVcEIsT0FBQSxDQUFBLFNBQUEsRUFBQTtBQURKLEdBL0lSLGFBK0lRLENBL0hKLG1CQStISSxDQUFBO0FBRVEsWUFBQSxLQUFBLEVBQUEsRUFBQTs7O0FBSUEsT0FBQSxDQUFBLFNBQUEsRUFBQTtBQURKLEdBcEpaLGFBb0pZLENBcElSLG1CQW9JUSxDQUxKLG9CQUtJLENBM0lSO0FBNklnQixZQUFBLEVBQUEsRUFBQSxLQUFBOzs7QUFJUixDQTFKWixhQTBKWSxDQTFJUixtQkEwSVEsQ0FYSixvQkFXSSxDQUFBO0FBQ0ksY0FBQSxJQUFBO0FBQ0EsV0FBQTtBQUNBLGtCQUFBO0FBQ0EsYUFBQTtBQUNBLG1CQUFBO0FBQ0EsZUFBQTtBQUNBLGVBQUE7QUFDQSxnQkFBQTtBQUNBLGNBQUE7QUFDQSxZQUFBO0FBQ0EsY0FBQSxLQUFBLE1BQUEsRUFBQTs7QUFFQSxPQUFBLENBQUEsU0FBQSxFQUFBO0FBYkosR0ExSlosYUEwSlksQ0ExSVIsbUJBMElRLENBWEosb0JBV0ksQ0FBQTtBQWNRLG9CQUFBO0FBQ0EsZUFBQTs7O0FBT2hCLENBaExKLGFBZ0xJLENBQUE7QUFDSSxjQUFBLElBQUE7O0FBR0osQ0FwTEosYUFvTEksQ0FBQTtBQUNJLGNBQUEsSUFBQTtBQUNBLFVBQUE7O0FBR0osQ0F6TEosYUF5TEksQ0FBQTtBQUNJLFVBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */\n", "/* src/main/webapp/app/exercises/quiz/participate/quiz-participation.scss */\n.dnd-question,\n.mc-question,\n.sa-question {\n}\n.dnd-question.disabled,\n.mc-question.disabled,\n.sa-question.disabled {\n  color: var(--quiz-participation-question-disabled-color);\n  background: var(--quiz-participation-question-disabled-background);\n}\n.dnd-question.result,\n.mc-question.result,\n.sa-question.result {\n  border-color: var(--quiz-participation-question-result-border-color);\n}\n.dnd-question.result .show-explanation,\n.mc-question.result .show-explanation,\n.sa-question.result .show-explanation {\n  display: inline-block;\n}\n.dnd-question.result.incorrect,\n.mc-question.result.incorrect,\n.sa-question.result.incorrect {\n  border-color: var(--quiz-participation-question-result-incorrect-border-color);\n}\n.dnd-question h2,\n.mc-question h2,\n.sa-question h2 {\n  margin: 0 90px 0 0;\n}\n.dnd-question h2 span,\n.mc-question h2 span,\n.sa-question h2 span {\n  color: var(--quiz-participation-question-h2-span-color);\n}\n.dnd-question p,\n.mc-question p,\n.sa-question p {\n  margin: 10px 0;\n  font-size: 16px;\n}\n.dnd-question .question-title-display,\n.mc-question .question-title-display,\n.sa-question .question-title-display {\n  max-width: 80%;\n}\n.dnd-question .question-score,\n.mc-question .question-score,\n.sa-question .question-score {\n  position: absolute;\n  top: 20px;\n  right: 20px;\n  max-width: 30%;\n}\n@media (max-width: 900px) {\n  .dnd-question .question-score,\n  .mc-question .question-score,\n  .sa-question .question-score {\n    position: relative;\n    top: 0;\n    right: 0;\n    max-width: 100%;\n  }\n}\n.dnd-question .question-score.result,\n.mc-question .question-score.result,\n.sa-question .question-score.result {\n  font-weight: bold;\n  color: var(--quiz-participation-question-score-result);\n}\n.dnd-question .question-score.result.incorrect,\n.mc-question .question-score.result.incorrect,\n.sa-question .question-score.result.incorrect {\n  color: var(--quiz-participation-question-score-incorrect-result);\n}\n.dnd-question .label,\n.mc-question .label,\n.sa-question .label {\n  cursor: pointer;\n  margin: 2px 0;\n}\n.dnd-question .label + ngb-popover-window,\n.mc-question .label + ngb-popover-window,\n.sa-question .label + ngb-popover-window {\n  max-width: 500px;\n}\n.dnd-question ngb-popover-window,\n.mc-question ngb-popover-window,\n.sa-question ngb-popover-window {\n  max-width: 500px;\n}\n@media (max-width: 991.98px) {\n  .dnd-question ngb-popover-window,\n  .mc-question ngb-popover-window,\n  .sa-question ngb-popover-window {\n    max-width: 300px !important;\n  }\n}\n@media (max-width: 575.98px) {\n  .dnd-question ngb-popover-window,\n  .mc-question ngb-popover-window,\n  .sa-question ngb-popover-window {\n    max-width: 200px !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9wYXJ0aWNpcGF0ZS9xdWl6LXBhcnRpY2lwYXRpb24uc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmRuZC1xdWVzdGlvbixcbi5tYy1xdWVzdGlvbixcbi5zYS1xdWVzdGlvbiB7XG4gICAgJi5kaXNhYmxlZCB7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tcXVlc3Rpb24tZGlzYWJsZWQtY29sb3IpO1xuICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tcXVlc3Rpb24tZGlzYWJsZWQtYmFja2dyb3VuZCk7XG4gICAgfVxuXG4gICAgJi5yZXN1bHQge1xuICAgICAgICBib3JkZXItY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1yZXN1bHQtYm9yZGVyLWNvbG9yKTtcblxuICAgICAgICAuc2hvdy1leHBsYW5hdGlvbiB7XG4gICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgIH1cblxuICAgICAgICAmLmluY29ycmVjdCB7XG4gICAgICAgICAgICBib3JkZXItY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1yZXN1bHQtaW5jb3JyZWN0LWJvcmRlci1jb2xvcik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBoMiB7XG4gICAgICAgIG1hcmdpbjogMCA5MHB4IDAgMDtcblxuICAgICAgICBzcGFuIHtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tcXVlc3Rpb24taDItc3Bhbi1jb2xvcik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwIHtcbiAgICAgICAgbWFyZ2luOiAxMHB4IDA7XG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICB9XG5cbiAgICAucXVlc3Rpb24tdGl0bGUtZGlzcGxheSB7XG4gICAgICAgIG1heC13aWR0aDogODAlO1xuICAgIH1cblxuICAgIC5xdWVzdGlvbi1zY29yZSB7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdG9wOiAyMHB4O1xuICAgICAgICByaWdodDogMjBweDtcbiAgICAgICAgbWF4LXdpZHRoOiAzMCU7XG5cbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDkwMHB4KSB7XG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICB0b3A6IDA7XG4gICAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgICAgIG1heC13aWR0aDogMTAwJTtcbiAgICAgICAgfVxuXG4gICAgICAgICYucmVzdWx0IHtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1zY29yZS1yZXN1bHQpO1xuXG4gICAgICAgICAgICAmLmluY29ycmVjdCB7XG4gICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1zY29yZS1pbmNvcnJlY3QtcmVzdWx0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5sYWJlbCB7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgbWFyZ2luOiAycHggMDtcblxuICAgICAgICAvKiBhZGp1c3QgW25nYlBvcG92ZXJdIHdpbmRvdyBzdHlsZSAqL1xuICAgICAgICAmICsgbmdiLXBvcG92ZXItd2luZG93IHtcbiAgICAgICAgICAgIG1heC13aWR0aDogNTAwcHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKiBhZGp1c3QgW25nYlBvcG92ZXJdIHdpbmRvdyBzdHlsZSAqL1xuICAgIG5nYi1wb3BvdmVyLXdpbmRvdyB7XG4gICAgICAgIG1heC13aWR0aDogNTAwcHg7XG5cbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDk5MS45OHB4KSB7XG4gICAgICAgICAgICBtYXgtd2lkdGg6IDMwMHB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIH1cblxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNTc1Ljk4cHgpIHtcbiAgICAgICAgICAgIG1heC13aWR0aDogMjAwcHggIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQUEsQ0FBQTtBQUFBLENBQUE7O0FBR0ksQ0FISixZQUdJLENBQUE7QUFBQSxDQUhKLFdBR0ksQ0FBQTtBQUFBLENBSEosV0FHSSxDQUFBO0FBQ0ksU0FBQSxJQUFBO0FBQ0EsY0FBQSxJQUFBOztBQUdKLENBUkosWUFRSSxDQUFBO0FBQUEsQ0FSSixXQVFJLENBQUE7QUFBQSxDQVJKLFdBUUksQ0FBQTtBQUNJLGdCQUFBLElBQUE7O0FBRUEsQ0FYUixZQVdRLENBSEosT0FHSSxDQUFBO0FBQUEsQ0FYUixXQVdRLENBSEosT0FHSSxDQUFBO0FBQUEsQ0FYUixXQVdRLENBSEosT0FHSSxDQUFBO0FBQ0ksV0FBQTs7QUFHSixDQWZSLFlBZVEsQ0FQSixNQU9JLENBQUE7QUFBQSxDQWZSLFdBZVEsQ0FQSixNQU9JLENBQUE7QUFBQSxDQWZSLFdBZVEsQ0FQSixNQU9JLENBQUE7QUFDSSxnQkFBQSxJQUFBOztBQUlSLENBcEJKLGFBb0JJO0FBQUEsQ0FwQkosWUFvQkk7QUFBQSxDQXBCSixZQW9CSTtBQUNJLFVBQUEsRUFBQSxLQUFBLEVBQUE7O0FBRUEsQ0F2QlIsYUF1QlEsR0FBQTtBQUFBLENBdkJSLFlBdUJRLEdBQUE7QUFBQSxDQXZCUixZQXVCUSxHQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUlSLENBNUJKLGFBNEJJO0FBQUEsQ0E1QkosWUE0Qkk7QUFBQSxDQTVCSixZQTRCSTtBQUNJLFVBQUEsS0FBQTtBQUNBLGFBQUE7O0FBR0osQ0FqQ0osYUFpQ0ksQ0FBQTtBQUFBLENBakNKLFlBaUNJLENBQUE7QUFBQSxDQWpDSixZQWlDSSxDQUFBO0FBQ0ksYUFBQTs7QUFHSixDQXJDSixhQXFDSSxDQUFBO0FBQUEsQ0FyQ0osWUFxQ0ksQ0FBQTtBQUFBLENBckNKLFlBcUNJLENBQUE7QUFDSSxZQUFBO0FBQ0EsT0FBQTtBQUNBLFNBQUE7QUFDQSxhQUFBOztBQUVBLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFOSixHQXJDSixhQXFDSSxDQUFBO0VBQUEsQ0FyQ0osWUFxQ0ksQ0FBQTtFQUFBLENBckNKLFlBcUNJLENBQUE7QUFPUSxjQUFBO0FBQ0EsU0FBQTtBQUNBLFdBQUE7QUFDQSxlQUFBOzs7QUFHSixDQWxEUixhQWtEUSxDQWJKLGNBYUksQ0ExQ0o7QUEwQ0ksQ0FsRFIsWUFrRFEsQ0FiSixjQWFJLENBMUNKO0FBMENJLENBbERSLFlBa0RRLENBYkosY0FhSSxDQTFDSjtBQTJDUSxlQUFBO0FBQ0EsU0FBQSxJQUFBOztBQUVBLENBdERaLGFBc0RZLENBakJSLGNBaUJRLENBOUNSLE1BOENRLENBdkNKO0FBdUNJLENBdERaLFlBc0RZLENBakJSLGNBaUJRLENBOUNSLE1BOENRLENBdkNKO0FBdUNJLENBdERaLFlBc0RZLENBakJSLGNBaUJRLENBOUNSLE1BOENRLENBdkNKO0FBd0NRLFNBQUEsSUFBQTs7QUFLWixDQTVESixhQTRESSxDQUFBO0FBQUEsQ0E1REosWUE0REksQ0FBQTtBQUFBLENBNURKLFlBNERJLENBQUE7QUFDSSxVQUFBO0FBQ0EsVUFBQSxJQUFBOztBQUdBLENBakVSLGFBaUVRLENBTEosTUFLSSxFQUFBO0FBQUEsQ0FqRVIsWUFpRVEsQ0FMSixNQUtJLEVBQUE7QUFBQSxDQWpFUixZQWlFUSxDQUxKLE1BS0ksRUFBQTtBQUNJLGFBQUE7O0FBS1IsQ0F2RUosYUF1RUk7QUFBQSxDQXZFSixZQXVFSTtBQUFBLENBdkVKLFlBdUVJO0FBQ0ksYUFBQTs7QUFFQSxPQUFBLENBQUEsU0FBQSxFQUFBO0FBSEosR0F2RUosYUF1RUk7RUFBQSxDQXZFSixZQXVFSTtFQUFBLENBdkVKLFlBdUVJO0FBSVEsZUFBQTs7O0FBR0osT0FBQSxDQUFBLFNBQUEsRUFBQTtBQVBKLEdBdkVKLGFBdUVJO0VBQUEsQ0F2RUosWUF1RUk7RUFBQSxDQXZFSixZQXVFSTtBQVFRLGVBQUE7OzsiLAogICJuYW1lcyI6IFtdCn0K */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(DragAndDropQuestionComponent, { className: "DragAndDropQuestionComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/quiz/shared/questions/multiple-choice-question/multiple-choice-question.component.ts
import { Component as Component4, EventEmitter as EventEmitter2, Input as Input5, Output as Output2, ViewEncapsulation as ViewEncapsulation3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faExclamationCircle as faExclamationCircle2, faExclamationTriangle as faExclamationTriangle2, faQuestionCircle as faQuestionCircle3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { faCheckSquare, faCircle, faDotCircle, faSquare } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i33 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i44 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function MultipleChoiceQuestionComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275element(1, "span", 3);
    i06.\u0275\u0275text(2, "\n    ");
  }
}
function MultipleChoiceQuestionComponent_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "h6");
    i06.\u0275\u0275text(2);
    i06.\u0275\u0275pipe(3, "artemisTranslate");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(4, "\n    ");
  }
  if (rf & 2) {
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275textInterpolate(i06.\u0275\u0275pipeBind1(3, 1, "artemisApp.quizQuestion.allOptions"));
  }
}
function MultipleChoiceQuestionComponent_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "h6");
    i06.\u0275\u0275text(2);
    i06.\u0275\u0275pipe(3, "artemisTranslate");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(4, "\n    ");
  }
  if (rf & 2) {
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275textInterpolate(i06.\u0275\u0275pipeBind1(3, 1, "artemisApp.quizQuestion.singleOption"));
  }
}
function MultipleChoiceQuestionComponent_Conditional_13_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275element(1, "div", 2);
    i06.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r8 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("innerHTML", ctx_r8.renderedQuestion.hint, i06.\u0275\u0275sanitizeHtml);
  }
}
function MultipleChoiceQuestionComponent_Conditional_13_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "span", 7);
    i06.\u0275\u0275text(2, "\n                    ");
    i06.\u0275\u0275element(3, "fa-icon", 8);
    i06.\u0275\u0275text(4, "\n                    ");
    i06.\u0275\u0275element(5, "span", 9);
    i06.\u0275\u0275text(6, "\n                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n            ");
  }
  if (rf & 2) {
    i06.\u0275\u0275nextContext();
    const _r9 = i06.\u0275\u0275reference(4);
    const ctx_r10 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("ngbPopover", _r9);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275property("icon", ctx_r10.faQuestionCircle);
  }
}
function MultipleChoiceQuestionComponent_Conditional_13_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275element(1, "div", 2);
    i06.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r11 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("innerHTML", ctx_r11.renderedQuestion.explanation, i06.\u0275\u0275sanitizeHtml);
  }
}
function MultipleChoiceQuestionComponent_Conditional_13_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "span", 10);
    i06.\u0275\u0275text(2, "\n                    ");
    i06.\u0275\u0275element(3, "fa-icon", 8);
    i06.\u0275\u0275text(4, "\n                    ");
    i06.\u0275\u0275element(5, "span", 11);
    i06.\u0275\u0275text(6, "\n                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n            ");
  }
  if (rf & 2) {
    i06.\u0275\u0275nextContext();
    const _r12 = i06.\u0275\u0275reference(10);
    const ctx_r13 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("ngbPopover", _r12);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275property("icon", ctx_r13.faExclamationCircle);
  }
}
function MultipleChoiceQuestionComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "div", 4);
    i06.\u0275\u0275text(2, "\n            ");
    i06.\u0275\u0275template(3, MultipleChoiceQuestionComponent_Conditional_13_ng_template_3_Template, 3, 1, "ng-template", null, 5, i06.\u0275\u0275templateRefExtractor);
    i06.\u0275\u0275text(5, "\n            ");
    i06.\u0275\u0275template(6, MultipleChoiceQuestionComponent_Conditional_13_Conditional_6_Template, 8, 2);
    i06.\u0275\u0275element(7, "br");
    i06.\u0275\u0275text(8, "\n            ");
    i06.\u0275\u0275template(9, MultipleChoiceQuestionComponent_Conditional_13_ng_template_9_Template, 3, 1, "ng-template", null, 6, i06.\u0275\u0275templateRefExtractor);
    i06.\u0275\u0275text(11, "\n            ");
    i06.\u0275\u0275template(12, MultipleChoiceQuestionComponent_Conditional_13_Conditional_12_Template, 8, 2);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(13, "\n    ");
  }
  if (rf & 2) {
    const ctx_r3 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(6);
    i06.\u0275\u0275conditional(6, ctx_r3.question.hint ? 6 : -1);
    i06.\u0275\u0275advance(6);
    i06.\u0275\u0275conditional(12, ctx_r3.question.explanation && ctx_r3.showResult ? 12 : -1);
  }
}
function MultipleChoiceQuestionComponent_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "div", 12);
    i06.\u0275\u0275text(2, "\n            ");
    i06.\u0275\u0275element(3, "span", 13);
    i06.\u0275\u0275text(4, "\n            ");
    i06.\u0275\u0275elementStart(5, "span");
    i06.\u0275\u0275text(6);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n        ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(8, "\n    ");
  }
  if (rf & 2) {
    const ctx_r4 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(6);
    i06.\u0275\u0275textInterpolate(ctx_r4.question.points);
  }
}
function MultipleChoiceQuestionComponent_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "div", 14);
    i06.\u0275\u0275text(2, "\n            ");
    i06.\u0275\u0275element(3, "span", 15);
    i06.\u0275\u0275text(4, "\n            ");
    i06.\u0275\u0275elementStart(5, "span", 16);
    i06.\u0275\u0275text(6);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n            ");
    i06.\u0275\u0275elementStart(8, "span", 16);
    i06.\u0275\u0275text(9, "\n                ");
    i06.\u0275\u0275element(10, "jhi-quiz-scoring-infostudent-modal", 17);
    i06.\u0275\u0275text(11, "\n            ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(12, "\n        ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(13, "\n    ");
  }
  if (rf & 2) {
    const ctx_r5 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("ngClass", i06.\u0275\u0275pureFunction1(9, _c04, (ctx_r5.score || 0) < ctx_r5.question.points));
    i06.\u0275\u0275advance(5);
    i06.\u0275\u0275textInterpolate2("", ctx_r5.score || 0, "/", ctx_r5.question.points, "");
    i06.\u0275\u0275advance(4);
    i06.\u0275\u0275property("score", ctx_r5.score)("question", ctx_r5.question)("multipleChoiceMapping", ctx_r5.selectedAnswerOptions)("questionIndex", ctx_r5.questionIndex)("multipleChoiceSubmittedResult", ctx_r5.submittedResult)("quizQuestions", ctx_r5.quizQuestions);
  }
}
function MultipleChoiceQuestionComponent_Conditional_16_For_4_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                                ");
    i06.\u0275\u0275element(1, "div", 2);
    i06.\u0275\u0275text(2, "\n                            ");
  }
  if (rf & 2) {
    const i_r16 = i06.\u0275\u0275nextContext().$index;
    const ctx_r20 = i06.\u0275\u0275nextContext(2);
    let tmp_0_0;
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("innerHTML", (tmp_0_0 = ctx_r20.renderedQuestion.renderedSubElements[i_r16] == null ? null : ctx_r20.renderedQuestion.renderedSubElements[i_r16].hint) !== null && tmp_0_0 !== void 0 ? tmp_0_0 : "", i06.\u0275\u0275sanitizeHtml);
  }
}
function MultipleChoiceQuestionComponent_Conditional_16_For_4_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                                ");
    i06.\u0275\u0275elementStart(1, "span", 7);
    i06.\u0275\u0275text(2, "\n                                    ");
    i06.\u0275\u0275element(3, "fa-icon", 8);
    i06.\u0275\u0275text(4, "\n                                    ");
    i06.\u0275\u0275element(5, "span", 9);
    i06.\u0275\u0275text(6, "\n                                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n                            ");
  }
  if (rf & 2) {
    i06.\u0275\u0275nextContext();
    const _r21 = i06.\u0275\u0275reference(10);
    const ctx_r22 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("ngbPopover", _r21);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275property("icon", ctx_r22.faQuestionCircle);
  }
}
function MultipleChoiceQuestionComponent_Conditional_16_For_4_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                            ");
    i06.\u0275\u0275element(1, "fa-icon", 24);
    i06.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r23 = i06.\u0275\u0275nextContext(3);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r23.question.singleChoice ? ctx_r23.faDotCircle : ctx_r23.faCheckSquare);
  }
}
function MultipleChoiceQuestionComponent_Conditional_16_For_4_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                            ");
    i06.\u0275\u0275element(1, "fa-icon", 24);
    i06.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r24 = i06.\u0275\u0275nextContext(3);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r24.question.singleChoice ? ctx_r24.faCircle : ctx_r24.faSquare);
  }
}
function MultipleChoiceQuestionComponent_Conditional_16_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "div", 19);
    i06.\u0275\u0275listener("click", function MultipleChoiceQuestionComponent_Conditional_16_For_4_Template_div_click_1_listener() {
      const restoredCtx = i06.\u0275\u0275restoreView(_r27);
      const answerOption_r15 = restoredCtx.$implicit;
      const ctx_r26 = i06.\u0275\u0275nextContext(2);
      return i06.\u0275\u0275resetView(ctx_r26.toggleSelection(answerOption_r15));
    });
    i06.\u0275\u0275text(2, "\n                    ");
    i06.\u0275\u0275elementStart(3, "div", 20);
    i06.\u0275\u0275text(4, "\n                        ");
    i06.\u0275\u0275element(5, "div", 21);
    i06.\u0275\u0275text(6, "\n                        ");
    i06.\u0275\u0275elementStart(7, "div", 4);
    i06.\u0275\u0275text(8, "\n                            ");
    i06.\u0275\u0275template(9, MultipleChoiceQuestionComponent_Conditional_16_For_4_ng_template_9_Template, 3, 1, "ng-template", null, 22, i06.\u0275\u0275templateRefExtractor);
    i06.\u0275\u0275text(11, "\n                            ");
    i06.\u0275\u0275template(12, MultipleChoiceQuestionComponent_Conditional_16_For_4_Conditional_12_Template, 8, 2);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(13, "\n                    ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(14, "\n                    ");
    i06.\u0275\u0275elementStart(15, "div", 23);
    i06.\u0275\u0275text(16, "\n                        ");
    i06.\u0275\u0275template(17, MultipleChoiceQuestionComponent_Conditional_16_For_4_Conditional_17_Template, 3, 1)(18, MultipleChoiceQuestionComponent_Conditional_16_For_4_Conditional_18_Template, 3, 1);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(19, "\n                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(20, "\n            ");
  }
  if (rf & 2) {
    const answerOption_r15 = ctx.$implicit;
    const i_r16 = ctx.$index;
    const ctx_r14 = i06.\u0275\u0275nextContext(2);
    let tmp_2_0;
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275propertyInterpolate1("id", "answer-option-", i_r16, "");
    i06.\u0275\u0275property("ngClass", i06.\u0275\u0275pureFunction2(7, _c13, ctx_r14.clickDisabled, ctx_r14.isAnswerOptionSelected(answerOption_r15)));
    i06.\u0275\u0275advance(4);
    i06.\u0275\u0275property("innerHTML", (tmp_2_0 = ctx_r14.renderedQuestion.renderedSubElements[i_r16] == null ? null : ctx_r14.renderedQuestion.renderedSubElements[i_r16].text) !== null && tmp_2_0 !== void 0 ? tmp_2_0 : "", i06.\u0275\u0275sanitizeHtml);
    i06.\u0275\u0275advance(7);
    i06.\u0275\u0275conditional(12, answerOption_r15.hint ? 12 : -1);
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275propertyInterpolate1("id", "mc-answer-selection-", i_r16, "");
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275conditional(17, ctx_r14.isAnswerOptionSelected(answerOption_r15) ? 17 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(18, !ctx_r14.isAnswerOptionSelected(answerOption_r15) ? 18 : -1);
  }
}
function MultipleChoiceQuestionComponent_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "div", 18);
    i06.\u0275\u0275text(2, "\n            ");
    i06.\u0275\u0275repeaterCreate(3, MultipleChoiceQuestionComponent_Conditional_16_For_4_Template, 21, 10, null, null, i06.\u0275\u0275repeaterTrackByIdentity);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r6 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275repeater(ctx_r6.question.answerOptions);
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                    ");
    i06.\u0275\u0275element(1, "th", 27);
    i06.\u0275\u0275text(2, "\n                ");
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                    ");
    i06.\u0275\u0275elementStart(1, "th", 28);
    i06.\u0275\u0275text(2);
    i06.\u0275\u0275pipe(3, "artemisTranslate");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(4, "\n                ");
  }
  if (rf & 2) {
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275textInterpolate(i06.\u0275\u0275pipeBind1(3, 1, "artemisApp.multipleChoiceQuestion.you"));
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                                ");
    i06.\u0275\u0275element(1, "div", 2);
    i06.\u0275\u0275text(2, "\n                            ");
  }
  if (rf & 2) {
    const i_r32 = i06.\u0275\u0275nextContext().$index;
    const ctx_r36 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("innerHTML", ctx_r36.renderedQuestion.renderedSubElements[i_r32].hint, i06.\u0275\u0275sanitizeHtml);
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                                ");
    i06.\u0275\u0275elementStart(1, "span", 7);
    i06.\u0275\u0275text(2, "\n                                    ");
    i06.\u0275\u0275element(3, "fa-icon", 8);
    i06.\u0275\u0275text(4, "\n                                    ");
    i06.\u0275\u0275element(5, "span", 9);
    i06.\u0275\u0275text(6, "\n                                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n                            ");
  }
  if (rf & 2) {
    i06.\u0275\u0275nextContext();
    const _r37 = i06.\u0275\u0275reference(10);
    const ctx_r38 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("ngbPopover", _r37);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275property("icon", ctx_r38.faQuestionCircle);
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_ng_template_13_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                                ");
    i06.\u0275\u0275element(1, "div", 2);
    i06.\u0275\u0275text(2, "\n                            ");
  }
  if (rf & 2) {
    const i_r32 = i06.\u0275\u0275nextContext().$index;
    const ctx_r39 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("innerHTML", ctx_r39.renderedQuestion.renderedSubElements[i_r32].explanation, i06.\u0275\u0275sanitizeHtml);
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                                ");
    i06.\u0275\u0275elementStart(1, "span", 32);
    i06.\u0275\u0275text(2, "\n                                    ");
    i06.\u0275\u0275element(3, "fa-icon", 8);
    i06.\u0275\u0275text(4, "\n                                    ");
    i06.\u0275\u0275element(5, "span", 11);
    i06.\u0275\u0275text(6, "\n                                ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(7, "\n                            ");
  }
  if (rf & 2) {
    i06.\u0275\u0275nextContext();
    const _r40 = i06.\u0275\u0275reference(14);
    const ctx_r41 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("ngbPopover", _r40);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275property("icon", ctx_r41.faExclamationCircle);
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                            ");
    i06.\u0275\u0275elementStart(1, "span", 33);
    i06.\u0275\u0275text(2);
    i06.\u0275\u0275pipe(3, "artemisTranslate");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    const i_r32 = i06.\u0275\u0275nextContext().$index;
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275propertyInterpolate1("id", "answer-option-", i_r32, "-correct");
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275textInterpolate(i06.\u0275\u0275pipeBind1(3, 2, "artemisApp.multipleChoiceQuestion.correct"));
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                            ");
    i06.\u0275\u0275elementStart(1, "span", 34);
    i06.\u0275\u0275text(2);
    i06.\u0275\u0275pipe(3, "artemisTranslate");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    const i_r32 = i06.\u0275\u0275nextContext().$index;
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275propertyInterpolate1("id", "answer-option-", i_r32, "-wrong");
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275textInterpolate(i06.\u0275\u0275pipeBind1(3, 2, "artemisApp.multipleChoiceQuestion.wrong"));
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                            ");
    i06.\u0275\u0275element(1, "span", 35);
    i06.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const i_r32 = i06.\u0275\u0275nextContext().$index;
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275propertyInterpolate1("id", "answer-option-", i_r32, "-invalid");
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                            ");
    i06.\u0275\u0275element(1, "fa-icon", 36);
    i06.\u0275\u0275pipe(2, "artemisTranslate");
    i06.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r45 = i06.\u0275\u0275nextContext(3);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275propertyInterpolate("ngbTooltip", i06.\u0275\u0275pipeBind1(2, 2, "artemisApp.multipleChoiceQuestion.invalid"));
    i06.\u0275\u0275property("icon", ctx_r45.faQuestionCircle);
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_26_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                                ");
    i06.\u0275\u0275element(1, "fa-icon", 37);
    i06.\u0275\u0275text(2, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r53 = i06.\u0275\u0275nextContext(4);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r53.faExclamationTriangle);
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                        ");
    i06.\u0275\u0275elementStart(1, "td", 27);
    i06.\u0275\u0275text(2, "\n                            ");
    i06.\u0275\u0275template(3, MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_26_Conditional_3_Template, 3, 1);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const answerOption_r31 = i06.\u0275\u0275nextContext().$implicit;
    const ctx_r46 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275conditional(3, !ctx_r46.question.invalid && !answerOption_r31.invalid && (ctx_r46.isAnswerOptionSelected(answerOption_r31) && !answerOption_r31.isCorrect || !ctx_r46.isAnswerOptionSelected(answerOption_r31) && answerOption_r31.isCorrect) ? 3 : -1);
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_27_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                                ");
    i06.\u0275\u0275element(1, "fa-icon", 24);
    i06.\u0275\u0275text(2, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r55 = i06.\u0275\u0275nextContext(4);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r55.question.singleChoice ? ctx_r55.faDotCircle : ctx_r55.faCheckSquare);
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_27_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                                ");
    i06.\u0275\u0275element(1, "fa-icon", 24);
    i06.\u0275\u0275text(2, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r56 = i06.\u0275\u0275nextContext(4);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r56.question.singleChoice ? ctx_r56.faCircle : ctx_r56.faSquare);
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                        ");
    i06.\u0275\u0275elementStart(1, "td", 28);
    i06.\u0275\u0275text(2, "\n                            ");
    i06.\u0275\u0275template(3, MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_27_Conditional_3_Template, 3, 1)(4, MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_27_Conditional_4_Template, 3, 1);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const answerOption_r31 = i06.\u0275\u0275nextContext().$implicit;
    const ctx_r47 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275conditional(3, ctx_r47.isAnswerOptionSelected(answerOption_r31) ? 3 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(4, !ctx_r47.isAnswerOptionSelected(answerOption_r31) ? 4 : -1);
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_For_17_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275elementStart(1, "tr", 29);
    i06.\u0275\u0275text(2, "\n                    ");
    i06.\u0275\u0275elementStart(3, "td", 20);
    i06.\u0275\u0275text(4, "\n                        ");
    i06.\u0275\u0275element(5, "div", 21);
    i06.\u0275\u0275text(6, "\n                        ");
    i06.\u0275\u0275elementStart(7, "div", 4);
    i06.\u0275\u0275text(8, "\n                            ");
    i06.\u0275\u0275template(9, MultipleChoiceQuestionComponent_Conditional_17_For_17_ng_template_9_Template, 3, 1, "ng-template", null, 30, i06.\u0275\u0275templateRefExtractor);
    i06.\u0275\u0275text(11, "\n                            ");
    i06.\u0275\u0275template(12, MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_12_Template, 8, 2)(13, MultipleChoiceQuestionComponent_Conditional_17_For_17_ng_template_13_Template, 3, 1, "ng-template", null, 31, i06.\u0275\u0275templateRefExtractor);
    i06.\u0275\u0275text(15, "\n                            ");
    i06.\u0275\u0275template(16, MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_16_Template, 8, 2);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(17, "\n                    ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(18, "\n                    ");
    i06.\u0275\u0275elementStart(19, "td", 26);
    i06.\u0275\u0275text(20, "\n                        ");
    i06.\u0275\u0275template(21, MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_21_Template, 5, 4)(22, MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_22_Template, 5, 4)(23, MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_23_Template, 3, 1)(24, MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_24_Template, 4, 4);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(25, "\n                    ");
    i06.\u0275\u0275template(26, MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_26_Template, 5, 1)(27, MultipleChoiceQuestionComponent_Conditional_17_For_17_Conditional_27_Template, 6, 2);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(28, "\n            ");
  }
  if (rf & 2) {
    const answerOption_r31 = ctx.$implicit;
    const i_r32 = ctx.$index;
    const ctx_r30 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275propertyInterpolate1("id", "answer-option-", i_r32, "");
    i06.\u0275\u0275advance(4);
    i06.\u0275\u0275property("innerHTML", ctx_r30.renderedQuestion.renderedSubElements[i_r32].text, i06.\u0275\u0275sanitizeHtml);
    i06.\u0275\u0275advance(7);
    i06.\u0275\u0275conditional(12, answerOption_r31.hint ? 12 : -1);
    i06.\u0275\u0275advance(4);
    i06.\u0275\u0275conditional(16, answerOption_r31.explanation ? 16 : -1);
    i06.\u0275\u0275advance(5);
    i06.\u0275\u0275conditional(21, !answerOption_r31.invalid && !ctx_r30.question.invalid && answerOption_r31.isCorrect ? 21 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(22, !answerOption_r31.invalid && !ctx_r30.question.invalid && !answerOption_r31.isCorrect ? 22 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(23, answerOption_r31.invalid || ctx_r30.question.invalid ? 23 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(24, answerOption_r31.invalid || ctx_r30.question.invalid ? 24 : -1);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275conditional(26, !ctx_r30.forceSampleSolution ? 26 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(27, !ctx_r30.forceSampleSolution ? 27 : -1);
  }
}
function MultipleChoiceQuestionComponent_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "table", 25);
    i06.\u0275\u0275text(2, "\n            ");
    i06.\u0275\u0275elementStart(3, "tr");
    i06.\u0275\u0275text(4, "\n                ");
    i06.\u0275\u0275elementStart(5, "th", 20);
    i06.\u0275\u0275text(6);
    i06.\u0275\u0275pipe(7, "artemisTranslate");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(8, "\n                ");
    i06.\u0275\u0275elementStart(9, "th", 26);
    i06.\u0275\u0275text(10);
    i06.\u0275\u0275pipe(11, "artemisTranslate");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(12, "\n                ");
    i06.\u0275\u0275template(13, MultipleChoiceQuestionComponent_Conditional_17_Conditional_13_Template, 3, 0)(14, MultipleChoiceQuestionComponent_Conditional_17_Conditional_14_Template, 5, 3);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(15, "\n            ");
    i06.\u0275\u0275repeaterCreate(16, MultipleChoiceQuestionComponent_Conditional_17_For_17_Template, 29, 10, null, null, i06.\u0275\u0275repeaterTrackByIdentity);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(18, "\n    ");
  }
  if (rf & 2) {
    const ctx_r7 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(6);
    i06.\u0275\u0275textInterpolate(i06.\u0275\u0275pipeBind1(7, 4, "artemisApp.multipleChoiceQuestion.answer"));
    i06.\u0275\u0275advance(4);
    i06.\u0275\u0275textInterpolate(i06.\u0275\u0275pipeBind1(11, 6, "artemisApp.multipleChoiceQuestion.solution"));
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275conditional(13, !ctx_r7.forceSampleSolution ? 13 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(14, !ctx_r7.forceSampleSolution ? 14 : -1);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275repeater(ctx_r7.question.answerOptions);
  }
}
var _c04, _c13, _c23, MultipleChoiceQuestionComponent;
var init_multiple_choice_question_component = __esm({
  "src/main/webapp/app/exercises/quiz/shared/questions/multiple-choice-question/multiple-choice-question.component.ts"() {
    init_markdown_service();
    init_multiple_choice_question_model();
    init_quiz_question_model();
    init_result_model();
    init_markdown_service();
    init_translate_directive();
    init_quiz_scoring_info_student_modal_component();
    init_artemis_translate_pipe();
    _c04 = (a0) => ({ incorrect: a0 });
    _c13 = (a0, a1) => ({ "click-disabled": a0, selected: a1 });
    _c23 = (a0, a1, a2) => ({ disabled: a0, result: a1, incorrect: a2 });
    MultipleChoiceQuestionComponent = class _MultipleChoiceQuestionComponent {
      artemisMarkdown;
      _question;
      set question(question) {
        this._question = question;
        this.watchCollection();
      }
      get question() {
        return this._question;
      }
      selectedAnswerOptions;
      clickDisabled;
      showResult;
      questionIndex;
      score;
      forceSampleSolution;
      fnOnSelection;
      submittedResult;
      quizQuestions;
      selectedAnswerOptionsChange = new EventEmitter2();
      renderedQuestion;
      faQuestionCircle = faQuestionCircle3;
      faExclamationTriangle = faExclamationTriangle2;
      faExclamationCircle = faExclamationCircle2;
      faSquare = faSquare;
      faCheckSquare = faCheckSquare;
      faCircle = faCircle;
      faDotCircle = faDotCircle;
      constructor(artemisMarkdown) {
        this.artemisMarkdown = artemisMarkdown;
      }
      watchCollection() {
        this.renderedQuestion = new RenderedQuizQuestionMarkDownElement();
        this.renderedQuestion.text = this.artemisMarkdown.safeHtmlForMarkdown(this.question.text);
        this.renderedQuestion.hint = this.artemisMarkdown.safeHtmlForMarkdown(this.question.hint);
        this.renderedQuestion.explanation = this.artemisMarkdown.safeHtmlForMarkdown(this.question.explanation);
        this.renderedQuestion.renderedSubElements = this.question.answerOptions.map((answerOption) => {
          const renderedAnswerOption = new RenderedQuizQuestionMarkDownElement();
          renderedAnswerOption.text = this.artemisMarkdown.safeHtmlForMarkdown(answerOption.text);
          renderedAnswerOption.hint = this.artemisMarkdown.safeHtmlForMarkdown(answerOption.hint);
          renderedAnswerOption.explanation = this.artemisMarkdown.safeHtmlForMarkdown(answerOption.explanation);
          return renderedAnswerOption;
        });
      }
      toggleSelection(answerOption) {
        if (this.clickDisabled) {
          return;
        }
        if (this.isAnswerOptionSelected(answerOption)) {
          this.selectedAnswerOptions = this.selectedAnswerOptions.filter((selectedAnswerOption) => {
            if (answerOption.id) {
              return selectedAnswerOption.id !== answerOption.id;
            }
            return selectedAnswerOption !== answerOption;
          });
        } else if (this.isSingleChoice) {
          this.selectedAnswerOptions = [answerOption];
        } else {
          this.selectedAnswerOptions.push(answerOption);
        }
        this.selectedAnswerOptionsChange.emit(this.selectedAnswerOptions);
        if (this.fnOnSelection) {
          this.fnOnSelection();
        }
      }
      isAnswerOptionSelected(answerOption) {
        return this.selectedAnswerOptions.findIndex((selectedAnswerOption) => {
          if (answerOption.id) {
            return selectedAnswerOption.id === answerOption.id;
          }
          return selectedAnswerOption === answerOption;
        }) !== -1;
      }
      get isSingleChoice() {
        return this.question.singleChoice;
      }
      static \u0275fac = function MultipleChoiceQuestionComponent_Factory(t) {
        return new (t || _MultipleChoiceQuestionComponent)(i06.\u0275\u0275directiveInject(ArtemisMarkdownService));
      };
      static \u0275cmp = i06.\u0275\u0275defineComponent({ type: _MultipleChoiceQuestionComponent, selectors: [["jhi-multiple-choice-question"]], inputs: { question: "question", selectedAnswerOptions: "selectedAnswerOptions", clickDisabled: "clickDisabled", showResult: "showResult", questionIndex: "questionIndex", score: "score", forceSampleSolution: "forceSampleSolution", fnOnSelection: "fnOnSelection", submittedResult: "submittedResult", quizQuestions: "quizQuestions" }, outputs: { selectedAnswerOptionsChange: "selectedAnswerOptionsChange" }, decls: 19, vars: 16, consts: [[1, "mc-question", "markdown-preview", 3, "ngClass"], [1, "question-title-display"], [3, "innerHTML"], ["jhiTranslate", "artemisApp.quizQuestion.invalidText", 2, "color", "red"], [1, "hint"], ["renderedHint", ""], ["renderedExplanation", ""], ["triggers", "mouseenter:mouseleave", 1, "label", "label-info", 3, "ngbPopover"], [3, "icon"], ["jhiTranslate", "artemisApp.quizQuestion.hint"], ["placement", "right auto", "triggers", "mouseenter:mouseleave", 1, "label", "label-primary", 3, "ngbPopover"], ["jhiTranslate", "artemisApp.quizQuestion.explanation"], [1, "question-score"], ["jhiTranslate", "artemisApp.quizQuestion.score", 1, "colon-suffix"], [1, "question-score", "result", 3, "ngClass"], ["jhiTranslate", "artemisApp.quizQuestion.yourScore", 1, "colon-suffix"], [1, "show-explanation"], [3, "score", "question", "multipleChoiceMapping", "questionIndex", "multipleChoiceSubmittedResult", "quizQuestions"], [1, "answer-options"], [1, "answer-option", 3, "id", "ngClass", "click"], [1, "content"], [1, "text", 3, "innerHTML"], ["renderedAnswerOptionsHint", ""], [1, "selection", 3, "id"], ["size", "2x", 3, "icon"], [1, "answer-options-result"], [1, "solution"], [1, "result-symbol"], [1, "selection"], [1, "answer-option", 3, "id"], ["renderedAnswerOptionsHint2", ""], ["renderedAnswerOptionsExplanation", ""], ["triggers", "mouseenter:mouseleave", 1, "label", "label-primary", 3, "ngbPopover"], [1, "correct", 3, "id"], [1, "wrong", 3, "id"], ["jhiTranslate", "artemisApp.quizQuestion.invalid", 1, "wrong", 3, "id"], [2, "color", "black", 3, "ngbTooltip", "icon"], ["size", "2x", 1, "warning", 3, "icon"]], template: function MultipleChoiceQuestionComponent_Template(rf, ctx) {
        if (rf & 1) {
          i06.\u0275\u0275elementStart(0, "div", 0);
          i06.\u0275\u0275text(1, "\n    ");
          i06.\u0275\u0275elementStart(2, "h4", 1);
          i06.\u0275\u0275text(3, "\n        ");
          i06.\u0275\u0275elementStart(4, "span");
          i06.\u0275\u0275text(5);
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(6);
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(7, "\n    ");
          i06.\u0275\u0275element(8, "p", 2);
          i06.\u0275\u0275text(9, "\n    ");
          i06.\u0275\u0275template(10, MultipleChoiceQuestionComponent_Conditional_10_Template, 3, 0)(11, MultipleChoiceQuestionComponent_Conditional_11_Template, 5, 3)(12, MultipleChoiceQuestionComponent_Conditional_12_Template, 5, 3)(13, MultipleChoiceQuestionComponent_Conditional_13_Template, 14, 2)(14, MultipleChoiceQuestionComponent_Conditional_14_Template, 9, 1)(15, MultipleChoiceQuestionComponent_Conditional_15_Template, 14, 11)(16, MultipleChoiceQuestionComponent_Conditional_16_Template, 6, 0)(17, MultipleChoiceQuestionComponent_Conditional_17_Template, 19, 8);
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(18, "\n");
        }
        if (rf & 2) {
          i06.\u0275\u0275property("ngClass", i06.\u0275\u0275pureFunction3(12, _c23, ctx.clickDisabled && !ctx.showResult, ctx.showResult && !ctx.forceSampleSolution, (ctx.score || 0) < ctx.question.points && !ctx.forceSampleSolution));
          i06.\u0275\u0275advance(5);
          i06.\u0275\u0275textInterpolate1("", ctx.questionIndex, ")");
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275textInterpolate1(" ", ctx.question.title, "\n    ");
          i06.\u0275\u0275advance(2);
          i06.\u0275\u0275property("innerHTML", ctx.renderedQuestion.text, i06.\u0275\u0275sanitizeHtml);
          i06.\u0275\u0275advance(2);
          i06.\u0275\u0275conditional(10, ctx.question.invalid ? 10 : -1);
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275conditional(11, !ctx.isSingleChoice ? 11 : -1);
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275conditional(12, ctx.isSingleChoice ? 12 : -1);
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275conditional(13, ctx.question.hint || ctx.question.explanation && ctx.showResult ? 13 : -1);
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275conditional(14, !ctx.showResult || ctx.forceSampleSolution ? 14 : -1);
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275conditional(15, ctx.showResult && !ctx.forceSampleSolution ? 15 : -1);
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275conditional(16, !ctx.showResult ? 16 : -1);
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275conditional(17, ctx.showResult ? 17 : -1);
        }
      }, dependencies: [i22.NgClass, i33.NgbPopover, i33.NgbTooltip, i44.FaIconComponent, TranslateDirective, QuizScoringInfoStudentModalComponent, ArtemisTranslatePipe], styles: ["/* src/main/webapp/app/exercises/quiz/shared/questions/multiple-choice-question/multiple-choice-question.component.scss */\n.mc-question {\n  background: var(--quiz-question-background);\n  border: 1px solid var(--quiz-question-border-color);\n  box-sizing: border-box;\n  margin-bottom: 18px;\n  padding: 20px;\n  position: relative;\n  width: 100%;\n}\n.mc-question .answer-option {\n  display: flex;\n  align-items: center;\n  outline: none !important;\n  border: 1px solid var(--mc-question-answer-option-border);\n  margin: 4px 0;\n  padding: 6px 10px;\n}\n.mc-question .answer-option .selection {\n  width: 36px;\n  margin-left: 16px;\n}\n.mc-question .answer-option .content {\n  display: flex;\n  flex: 1;\n  align-items: center;\n}\n.mc-question .answer-option .content .text {\n  flex: 1;\n  padding-right: 8px;\n  font-size: 16px;\n}\n.mc-question .answer-option .content .hint {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-end;\n  font-size: 18px;\n}\n.mc-question .answer-options {\n  margin-top: 20px;\n}\n.mc-question .answer-options .answer-option {\n  cursor: pointer;\n  user-select: none;\n  -webkit-touch-callout: none;\n  -webkit-user-select: none;\n}\n.mc-question .answer-options .answer-option:hover {\n  background: var(--mc-question-answer-option-hover-background);\n}\n.mc-question .answer-options .answer-option:not(.click-disabled).selected {\n  animation: on-select 0.6s ease;\n  animation-fill-mode: forwards;\n  background: var(--mc-question-answer-option-selected-background);\n}\n@keyframes on-select {\n  0%, 100% {\n    transform: scale(1);\n  }\n  33% {\n    transform: scale(1.012);\n  }\n}\n.mc-question .answer-options .answer-option.click-disabled {\n  cursor: not-allowed;\n}\n.mc-question .answer-options .answer-option.click-disabled:hover {\n  background: inherit;\n}\n.mc-question table.answer-options-result {\n  width: 100%;\n}\n.mc-question table.answer-options-result .answer-option {\n  display: table-row;\n}\n.mc-question table.answer-options-result th {\n  color: var(--gray-600);\n}\n.mc-question table.answer-options-result th,\n.mc-question table.answer-options-result td {\n  padding: 6px 10px;\n}\n.mc-question table.answer-options-result .solution {\n  width: 100px;\n}\n.mc-question table.answer-options-result .result-symbol {\n  padding: 0;\n  color: var(--warning);\n  width: 50px;\n}\n.mc-question table.answer-options-result .selection {\n  width: 36px;\n  margin-left: 0;\n}\n.mc-question table.answer-options-result .correct {\n  color: var(--success);\n}\n.mc-question table.answer-options-result .wrong {\n  color: var(--danger);\n}\n.visual-mode {\n  margin-top: 20px;\n}\n.visual-question {\n  border-radius: 4px;\n  border: 1px solid var(--quiz-visual-question-border-color);\n  padding: 6px;\n}\n.visual-question-hint {\n  display: flex;\n  align-items: center;\n  font-size: 18px;\n}\n.visual-answer-option {\n  outline: none !important;\n  border: 1px solid var(--mc-question-answer-option-border);\n  margin: 4px 0;\n  padding: 6px 10px;\n}\n.visual-answer-question-container {\n  display: flex;\n}\n.visual-answer-delete-container {\n  background: var(--red);\n  align-items: center;\n  display: flex;\n  justify-content: center;\n  cursor: pointer;\n  width: 2.5%;\n  min-width: 35px;\n  margin-left: 0.2rem;\n  border-radius: 2px;\n}\n.visual-answer-correct-container {\n  background: var(--quiz-visual-answer-correct-container-color);\n  align-items: center;\n  display: flex;\n  justify-content: center;\n  cursor: pointer;\n  width: 2.5%;\n  min-width: 35px;\n  margin-right: 0.2rem;\n  border-radius: 2px;\n}\n.visual-answer-wrong-container {\n  background: var(--red);\n  align-items: center;\n  display: flex;\n  justify-content: center;\n  cursor: pointer;\n  width: 2.5%;\n  min-width: 35px;\n  margin-right: 0.2rem;\n  border-radius: 2px;\n}\n.visual-answer-add-container {\n  background: var(--quiz-visual-answer-add-container-color);\n  align-items: center;\n  display: flex;\n  justify-content: center;\n  cursor: pointer;\n  width: 2.5%;\n  min-width: 35px;\n  margin-left: 0.2rem;\n  border-radius: 2px;\n  color: var(--white);\n}\n.visual-answer-add-container:hover {\n  background: var(--quiz-visual-answer-add-container-hover-color);\n}\n.visual-answer-add-container-disabled {\n  background: var(--quiz-visual-answer-add-container-hover-color);\n  align-items: center;\n  display: flex;\n  justify-content: center;\n  cursor: pointer;\n  width: 2.5%;\n  min-width: 35px;\n  margin-left: 0.2rem;\n  border-radius: 2px;\n  color: var(--white);\n}\n.visual-answer-delete-container:hover {\n  color: var(--white);\n}\n.visual-answer-correct-container:hover {\n  background: var(--quiz-visual-answer-correct-container-hover-color);\n}\n.visual-answer-wrong-container:hover {\n  background: var(--quiz-visual-answer-wrong-container-hover-color);\n}\n.visual-answer {\n  color: var(--white);\n}\n.visual-new-answer-title {\n  margin-top: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL211bHRpcGxlLWNob2ljZS1xdWVzdGlvbi9tdWx0aXBsZS1jaG9pY2UtcXVlc3Rpb24uY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5tYy1xdWVzdGlvbiB7XG4gICAgYmFja2dyb3VuZDogdmFyKC0tcXVpei1xdWVzdGlvbi1iYWNrZ3JvdW5kKTtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1xdWl6LXF1ZXN0aW9uLWJvcmRlci1jb2xvcik7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICBtYXJnaW4tYm90dG9tOiAxOHB4O1xuICAgIHBhZGRpbmc6IDIwcHg7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHdpZHRoOiAxMDAlO1xuXG4gICAgLmFuc3dlci1vcHRpb24ge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBvdXRsaW5lOiBub25lICFpbXBvcnRhbnQ7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLW1jLXF1ZXN0aW9uLWFuc3dlci1vcHRpb24tYm9yZGVyKTtcbiAgICAgICAgbWFyZ2luOiA0cHggMDtcbiAgICAgICAgcGFkZGluZzogNnB4IDEwcHg7XG5cbiAgICAgICAgLnNlbGVjdGlvbiB7XG4gICAgICAgICAgICB3aWR0aDogMzZweDtcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxNnB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLmNvbnRlbnQge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGZsZXg6IDE7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgICAgICAgICAudGV4dCB7XG4gICAgICAgICAgICAgICAgZmxleDogMTtcbiAgICAgICAgICAgICAgICBwYWRkaW5nLXJpZ2h0OiA4cHg7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuaGludCB7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBmbGV4LWVuZDtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKiBVc2VkIHdoZW4gdGhlIHN0dWRlbnQgY2FuIHdvcmsgb24gdGhlIGV4ZXJjaXNlLiBTZWUgYW5zd2VyLW9wdGlvbnMtcmVzdWx0IGNsYXNzIGZvciByZXN1bHQgZGlzcGxheS4gKi9cbiAgICAuYW5zd2VyLW9wdGlvbnMge1xuICAgICAgICBtYXJnaW4tdG9wOiAyMHB4O1xuXG4gICAgICAgIC5hbnN3ZXItb3B0aW9uIHtcbiAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgICAgIHVzZXItc2VsZWN0OiBub25lO1xuICAgICAgICAgICAgLXdlYmtpdC10b3VjaC1jYWxsb3V0OiBub25lOyAvKiBpT1MgU2FmYXJpICovXG4gICAgICAgICAgICAtd2Via2l0LXVzZXItc2VsZWN0OiBub25lOyAvKiBTYWZhcmkgKi9cblxuICAgICAgICAgICAgJjpob3ZlciB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tbWMtcXVlc3Rpb24tYW5zd2VyLW9wdGlvbi1ob3Zlci1iYWNrZ3JvdW5kKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgJjpub3QoLmNsaWNrLWRpc2FibGVkKS5zZWxlY3RlZCB7XG4gICAgICAgICAgICAgICAgYW5pbWF0aW9uOiBvbi1zZWxlY3QgMC42cyBlYXNlO1xuICAgICAgICAgICAgICAgIGFuaW1hdGlvbi1maWxsLW1vZGU6IGZvcndhcmRzO1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLW1jLXF1ZXN0aW9uLWFuc3dlci1vcHRpb24tc2VsZWN0ZWQtYmFja2dyb3VuZCk7XG5cbiAgICAgICAgICAgICAgICBAa2V5ZnJhbWVzIG9uLXNlbGVjdCB7XG4gICAgICAgICAgICAgICAgICAgIDAlLFxuICAgICAgICAgICAgICAgICAgICAxMDAlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAzMyUge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjAxMik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICYuY2xpY2stZGlzYWJsZWQge1xuICAgICAgICAgICAgICAgIGN1cnNvcjogbm90LWFsbG93ZWQ7XG5cbiAgICAgICAgICAgICAgICAmOmhvdmVyIHtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogaW5oZXJpdDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICB0YWJsZS5hbnN3ZXItb3B0aW9ucy1yZXN1bHQge1xuICAgICAgICB3aWR0aDogMTAwJTtcblxuICAgICAgICAuYW5zd2VyLW9wdGlvbiB7XG4gICAgICAgICAgICBkaXNwbGF5OiB0YWJsZS1yb3c7XG4gICAgICAgIH1cblxuICAgICAgICB0aCB7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0tZ3JheS02MDApO1xuICAgICAgICB9XG5cbiAgICAgICAgdGgsXG4gICAgICAgIHRkIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDZweCAxMHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLnNvbHV0aW9uIHtcbiAgICAgICAgICAgIHdpZHRoOiAxMDBweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5yZXN1bHQtc3ltYm9sIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0td2FybmluZyk7XG4gICAgICAgICAgICB3aWR0aDogNTBweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5zZWxlY3Rpb24ge1xuICAgICAgICAgICAgd2lkdGg6IDM2cHg7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5jb3JyZWN0IHtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1zdWNjZXNzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC53cm9uZyB7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0tZGFuZ2VyKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnZpc3VhbC1tb2RlIHtcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuXG4udmlzdWFsLXF1ZXN0aW9uIHtcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tcXVpei12aXN1YWwtcXVlc3Rpb24tYm9yZGVyLWNvbG9yKTtcbiAgICBwYWRkaW5nOiA2cHg7XG59XG5cbi52aXN1YWwtcXVlc3Rpb24taGludCB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbn1cblxuLnZpc3VhbC1hbnN3ZXItb3B0aW9uIHtcbiAgICBvdXRsaW5lOiBub25lICFpbXBvcnRhbnQ7XG4gICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tbWMtcXVlc3Rpb24tYW5zd2VyLW9wdGlvbi1ib3JkZXIpO1xuICAgIG1hcmdpbjogNHB4IDA7XG4gICAgcGFkZGluZzogNnB4IDEwcHg7XG59XG5cbi52aXN1YWwtYW5zd2VyLXF1ZXN0aW9uLWNvbnRhaW5lciB7XG4gICAgZGlzcGxheTogZmxleDtcbn1cblxuLnZpc3VhbC1hbnN3ZXItZGVsZXRlLWNvbnRhaW5lciB7XG4gICAgYmFja2dyb3VuZDogdmFyKC0tcmVkKTtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHdpZHRoOiAyLjUlO1xuICAgIG1pbi13aWR0aDogMzVweDtcbiAgICBtYXJnaW4tbGVmdDogMC4ycmVtO1xuICAgIGJvcmRlci1yYWRpdXM6IDJweDtcbn1cblxuLnZpc3VhbC1hbnN3ZXItY29ycmVjdC1jb250YWluZXIge1xuICAgIGJhY2tncm91bmQ6IHZhcigtLXF1aXotdmlzdWFsLWFuc3dlci1jb3JyZWN0LWNvbnRhaW5lci1jb2xvcik7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB3aWR0aDogMi41JTtcbiAgICBtaW4td2lkdGg6IDM1cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAwLjJyZW07XG4gICAgYm9yZGVyLXJhZGl1czogMnB4O1xufVxuXG4udmlzdWFsLWFuc3dlci13cm9uZy1jb250YWluZXIge1xuICAgIGJhY2tncm91bmQ6IHZhcigtLXJlZCk7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB3aWR0aDogMi41JTtcbiAgICBtaW4td2lkdGg6IDM1cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAwLjJyZW07XG4gICAgYm9yZGVyLXJhZGl1czogMnB4O1xufVxuXG4udmlzdWFsLWFuc3dlci1hZGQtY29udGFpbmVyIHtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1xdWl6LXZpc3VhbC1hbnN3ZXItYWRkLWNvbnRhaW5lci1jb2xvcik7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB3aWR0aDogMi41JTtcbiAgICBtaW4td2lkdGg6IDM1cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDAuMnJlbTtcbiAgICBib3JkZXItcmFkaXVzOiAycHg7XG4gICAgY29sb3I6IHZhcigtLXdoaXRlKTtcbn1cblxuLnZpc3VhbC1hbnN3ZXItYWRkLWNvbnRhaW5lcjpob3ZlciB7XG4gICAgYmFja2dyb3VuZDogdmFyKC0tcXVpei12aXN1YWwtYW5zd2VyLWFkZC1jb250YWluZXItaG92ZXItY29sb3IpO1xufVxuXG4udmlzdWFsLWFuc3dlci1hZGQtY29udGFpbmVyLWRpc2FibGVkIHtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1xdWl6LXZpc3VhbC1hbnN3ZXItYWRkLWNvbnRhaW5lci1ob3Zlci1jb2xvcik7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB3aWR0aDogMi41JTtcbiAgICBtaW4td2lkdGg6IDM1cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDAuMnJlbTtcbiAgICBib3JkZXItcmFkaXVzOiAycHg7XG4gICAgY29sb3I6IHZhcigtLXdoaXRlKTtcbn1cblxuLnZpc3VhbC1hbnN3ZXItZGVsZXRlLWNvbnRhaW5lcjpob3ZlciB7XG4gICAgY29sb3I6IHZhcigtLXdoaXRlKTtcbn1cblxuLnZpc3VhbC1hbnN3ZXItY29ycmVjdC1jb250YWluZXI6aG92ZXIge1xuICAgIGJhY2tncm91bmQ6IHZhcigtLXF1aXotdmlzdWFsLWFuc3dlci1jb3JyZWN0LWNvbnRhaW5lci1ob3Zlci1jb2xvcik7XG59XG5cbi52aXN1YWwtYW5zd2VyLXdyb25nLWNvbnRhaW5lcjpob3ZlciB7XG4gICAgYmFja2dyb3VuZDogdmFyKC0tcXVpei12aXN1YWwtYW5zd2VyLXdyb25nLWNvbnRhaW5lci1ob3Zlci1jb2xvcik7XG59XG5cbi52aXN1YWwtYW5zd2VyIHtcbiAgICBjb2xvcjogdmFyKC0td2hpdGUpO1xufVxuXG4udmlzdWFsLW5ldy1hbnN3ZXItdGl0bGUge1xuICAgIG1hcmdpbi10b3A6IDFyZW07XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLGNBQUEsSUFBQTtBQUNBLFVBQUEsSUFBQSxNQUFBLElBQUE7QUFDQSxjQUFBO0FBQ0EsaUJBQUE7QUFDQSxXQUFBO0FBQ0EsWUFBQTtBQUNBLFNBQUE7O0FBRUEsQ0FUSixZQVNJLENBQUE7QUFDSSxXQUFBO0FBQ0EsZUFBQTtBQUNBLFdBQUE7QUFDQSxVQUFBLElBQUEsTUFBQSxJQUFBO0FBQ0EsVUFBQSxJQUFBO0FBQ0EsV0FBQSxJQUFBOztBQUVBLENBakJSLFlBaUJRLENBUkosY0FRSSxDQUFBO0FBQ0ksU0FBQTtBQUNBLGVBQUE7O0FBR0osQ0F0QlIsWUFzQlEsQ0FiSixjQWFJLENBQUE7QUFDSSxXQUFBO0FBQ0EsUUFBQTtBQUNBLGVBQUE7O0FBRUEsQ0EzQlosWUEyQlksQ0FsQlIsY0FrQlEsQ0FMSixRQUtJLENBQUE7QUFDSSxRQUFBO0FBQ0EsaUJBQUE7QUFDQSxhQUFBOztBQUdKLENBakNaLFlBaUNZLENBeEJSLGNBd0JRLENBWEosUUFXSSxDQUFBO0FBQ0ksV0FBQTtBQUNBLGtCQUFBO0FBQ0EsZUFBQTtBQUNBLGFBQUE7O0FBTVosQ0EzQ0osWUEyQ0ksQ0FBQTtBQUNJLGNBQUE7O0FBRUEsQ0E5Q1IsWUE4Q1EsQ0FISixlQUdJLENBckNKO0FBc0NRLFVBQUE7QUFDQSxlQUFBO0FBQ0EseUJBQUE7QUFDQSx1QkFBQTs7QUFFQSxDQXBEWixZQW9EWSxDQVRSLGVBU1EsQ0EzQ1IsYUEyQ1E7QUFDSSxjQUFBLElBQUE7O0FBR0osQ0F4RFosWUF3RFksQ0FiUixlQWFRLENBL0NSLGFBK0NRLEtBQUEsQ0FBQSxlQUFBLENBQUE7QUFDSSxhQUFBLFVBQUEsS0FBQTtBQUNBLHVCQUFBO0FBQ0EsY0FBQSxJQUFBOztBQUVBLFdBSkE7QUFLSTtBQUVJLGVBQUEsTUFBQTs7QUFHSjtBQUNJLGVBQUEsTUFBQTs7O0FBS1osQ0F6RVosWUF5RVksQ0E5QlIsZUE4QlEsQ0FoRVIsYUFnRVEsQ0FqQkE7QUFrQkksVUFBQTs7QUFFQSxDQTVFaEIsWUE0RWdCLENBakNaLGVBaUNZLENBbkVaLGFBbUVZLENBcEJKLGNBb0JJO0FBQ0ksY0FBQTs7QUFNaEIsQ0FuRkosWUFtRkksS0FBQSxDQUFBO0FBQ0ksU0FBQTs7QUFFQSxDQXRGUixZQXNGUSxLQUFBLENBSEosc0JBR0ksQ0E3RUo7QUE4RVEsV0FBQTs7QUFHSixDQTFGUixZQTBGUSxLQUFBLENBUEosc0JBT0k7QUFDSSxTQUFBLElBQUE7O0FBR0osQ0E5RlIsWUE4RlEsS0FBQSxDQVhKLHNCQVdJO0FBQUEsQ0E5RlIsWUE4RlEsS0FBQSxDQVhKLHNCQVdJO0FBRUksV0FBQSxJQUFBOztBQUdKLENBbkdSLFlBbUdRLEtBQUEsQ0FoQkosc0JBZ0JJLENBQUE7QUFDSSxTQUFBOztBQUdKLENBdkdSLFlBdUdRLEtBQUEsQ0FwQkosc0JBb0JJLENBQUE7QUFDSSxXQUFBO0FBQ0EsU0FBQSxJQUFBO0FBQ0EsU0FBQTs7QUFHSixDQTdHUixZQTZHUSxLQUFBLENBMUJKLHNCQTBCSSxDQTVGQTtBQTZGSSxTQUFBO0FBQ0EsZUFBQTs7QUFHSixDQWxIUixZQWtIUSxLQUFBLENBL0JKLHNCQStCSSxDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUdKLENBdEhSLFlBc0hRLEtBQUEsQ0FuQ0osc0JBbUNJLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBS1osQ0FBQTtBQUNJLGNBQUE7O0FBR0osQ0FBQTtBQUNJLGlCQUFBO0FBQ0EsVUFBQSxJQUFBLE1BQUEsSUFBQTtBQUNBLFdBQUE7O0FBR0osQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBO0FBQ0EsYUFBQTs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLFVBQUEsSUFBQSxNQUFBLElBQUE7QUFDQSxVQUFBLElBQUE7QUFDQSxXQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLFdBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUEsSUFBQTtBQUNBLGVBQUE7QUFDQSxXQUFBO0FBQ0EsbUJBQUE7QUFDQSxVQUFBO0FBQ0EsU0FBQTtBQUNBLGFBQUE7QUFDQSxlQUFBO0FBQ0EsaUJBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUEsSUFBQTtBQUNBLGVBQUE7QUFDQSxXQUFBO0FBQ0EsbUJBQUE7QUFDQSxVQUFBO0FBQ0EsU0FBQTtBQUNBLGFBQUE7QUFDQSxnQkFBQTtBQUNBLGlCQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBLElBQUE7QUFDQSxlQUFBO0FBQ0EsV0FBQTtBQUNBLG1CQUFBO0FBQ0EsVUFBQTtBQUNBLFNBQUE7QUFDQSxhQUFBO0FBQ0EsZ0JBQUE7QUFDQSxpQkFBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQSxJQUFBO0FBQ0EsZUFBQTtBQUNBLFdBQUE7QUFDQSxtQkFBQTtBQUNBLFVBQUE7QUFDQSxTQUFBO0FBQ0EsYUFBQTtBQUNBLGVBQUE7QUFDQSxpQkFBQTtBQUNBLFNBQUEsSUFBQTs7QUFHSixDQWJBLDJCQWFBO0FBQ0ksY0FBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBLElBQUE7QUFDQSxlQUFBO0FBQ0EsV0FBQTtBQUNBLG1CQUFBO0FBQ0EsVUFBQTtBQUNBLFNBQUE7QUFDQSxhQUFBO0FBQ0EsZUFBQTtBQUNBLGlCQUFBO0FBQ0EsU0FBQSxJQUFBOztBQUdKLENBbEVBLDhCQWtFQTtBQUNJLFNBQUEsSUFBQTs7QUFHSixDQTFEQSwrQkEwREE7QUFDSSxjQUFBLElBQUE7O0FBR0osQ0FsREEsNkJBa0RBO0FBQ0ksY0FBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */\n", "/* src/main/webapp/app/exercises/quiz/participate/quiz-participation.scss */\n.dnd-question,\n.mc-question,\n.sa-question {\n}\n.dnd-question.disabled,\n.mc-question.disabled,\n.sa-question.disabled {\n  color: var(--quiz-participation-question-disabled-color);\n  background: var(--quiz-participation-question-disabled-background);\n}\n.dnd-question.result,\n.mc-question.result,\n.sa-question.result {\n  border-color: var(--quiz-participation-question-result-border-color);\n}\n.dnd-question.result .show-explanation,\n.mc-question.result .show-explanation,\n.sa-question.result .show-explanation {\n  display: inline-block;\n}\n.dnd-question.result.incorrect,\n.mc-question.result.incorrect,\n.sa-question.result.incorrect {\n  border-color: var(--quiz-participation-question-result-incorrect-border-color);\n}\n.dnd-question h2,\n.mc-question h2,\n.sa-question h2 {\n  margin: 0 90px 0 0;\n}\n.dnd-question h2 span,\n.mc-question h2 span,\n.sa-question h2 span {\n  color: var(--quiz-participation-question-h2-span-color);\n}\n.dnd-question p,\n.mc-question p,\n.sa-question p {\n  margin: 10px 0;\n  font-size: 16px;\n}\n.dnd-question .question-title-display,\n.mc-question .question-title-display,\n.sa-question .question-title-display {\n  max-width: 80%;\n}\n.dnd-question .question-score,\n.mc-question .question-score,\n.sa-question .question-score {\n  position: absolute;\n  top: 20px;\n  right: 20px;\n  max-width: 30%;\n}\n@media (max-width: 900px) {\n  .dnd-question .question-score,\n  .mc-question .question-score,\n  .sa-question .question-score {\n    position: relative;\n    top: 0;\n    right: 0;\n    max-width: 100%;\n  }\n}\n.dnd-question .question-score.result,\n.mc-question .question-score.result,\n.sa-question .question-score.result {\n  font-weight: bold;\n  color: var(--quiz-participation-question-score-result);\n}\n.dnd-question .question-score.result.incorrect,\n.mc-question .question-score.result.incorrect,\n.sa-question .question-score.result.incorrect {\n  color: var(--quiz-participation-question-score-incorrect-result);\n}\n.dnd-question .label,\n.mc-question .label,\n.sa-question .label {\n  cursor: pointer;\n  margin: 2px 0;\n}\n.dnd-question .label + ngb-popover-window,\n.mc-question .label + ngb-popover-window,\n.sa-question .label + ngb-popover-window {\n  max-width: 500px;\n}\n.dnd-question ngb-popover-window,\n.mc-question ngb-popover-window,\n.sa-question ngb-popover-window {\n  max-width: 500px;\n}\n@media (max-width: 991.98px) {\n  .dnd-question ngb-popover-window,\n  .mc-question ngb-popover-window,\n  .sa-question ngb-popover-window {\n    max-width: 300px !important;\n  }\n}\n@media (max-width: 575.98px) {\n  .dnd-question ngb-popover-window,\n  .mc-question ngb-popover-window,\n  .sa-question ngb-popover-window {\n    max-width: 200px !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9wYXJ0aWNpcGF0ZS9xdWl6LXBhcnRpY2lwYXRpb24uc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmRuZC1xdWVzdGlvbixcbi5tYy1xdWVzdGlvbixcbi5zYS1xdWVzdGlvbiB7XG4gICAgJi5kaXNhYmxlZCB7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tcXVlc3Rpb24tZGlzYWJsZWQtY29sb3IpO1xuICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tcXVlc3Rpb24tZGlzYWJsZWQtYmFja2dyb3VuZCk7XG4gICAgfVxuXG4gICAgJi5yZXN1bHQge1xuICAgICAgICBib3JkZXItY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1yZXN1bHQtYm9yZGVyLWNvbG9yKTtcblxuICAgICAgICAuc2hvdy1leHBsYW5hdGlvbiB7XG4gICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgIH1cblxuICAgICAgICAmLmluY29ycmVjdCB7XG4gICAgICAgICAgICBib3JkZXItY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1yZXN1bHQtaW5jb3JyZWN0LWJvcmRlci1jb2xvcik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBoMiB7XG4gICAgICAgIG1hcmdpbjogMCA5MHB4IDAgMDtcblxuICAgICAgICBzcGFuIHtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tcXVlc3Rpb24taDItc3Bhbi1jb2xvcik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwIHtcbiAgICAgICAgbWFyZ2luOiAxMHB4IDA7XG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICB9XG5cbiAgICAucXVlc3Rpb24tdGl0bGUtZGlzcGxheSB7XG4gICAgICAgIG1heC13aWR0aDogODAlO1xuICAgIH1cblxuICAgIC5xdWVzdGlvbi1zY29yZSB7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdG9wOiAyMHB4O1xuICAgICAgICByaWdodDogMjBweDtcbiAgICAgICAgbWF4LXdpZHRoOiAzMCU7XG5cbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDkwMHB4KSB7XG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICB0b3A6IDA7XG4gICAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgICAgIG1heC13aWR0aDogMTAwJTtcbiAgICAgICAgfVxuXG4gICAgICAgICYucmVzdWx0IHtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1zY29yZS1yZXN1bHQpO1xuXG4gICAgICAgICAgICAmLmluY29ycmVjdCB7XG4gICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1zY29yZS1pbmNvcnJlY3QtcmVzdWx0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5sYWJlbCB7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgbWFyZ2luOiAycHggMDtcblxuICAgICAgICAvKiBhZGp1c3QgW25nYlBvcG92ZXJdIHdpbmRvdyBzdHlsZSAqL1xuICAgICAgICAmICsgbmdiLXBvcG92ZXItd2luZG93IHtcbiAgICAgICAgICAgIG1heC13aWR0aDogNTAwcHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKiBhZGp1c3QgW25nYlBvcG92ZXJdIHdpbmRvdyBzdHlsZSAqL1xuICAgIG5nYi1wb3BvdmVyLXdpbmRvdyB7XG4gICAgICAgIG1heC13aWR0aDogNTAwcHg7XG5cbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDk5MS45OHB4KSB7XG4gICAgICAgICAgICBtYXgtd2lkdGg6IDMwMHB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIH1cblxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNTc1Ljk4cHgpIHtcbiAgICAgICAgICAgIG1heC13aWR0aDogMjAwcHggIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQUEsQ0FBQTtBQUFBLENBQUE7O0FBR0ksQ0FISixZQUdJLENBQUE7QUFBQSxDQUhKLFdBR0ksQ0FBQTtBQUFBLENBSEosV0FHSSxDQUFBO0FBQ0ksU0FBQSxJQUFBO0FBQ0EsY0FBQSxJQUFBOztBQUdKLENBUkosWUFRSSxDQUFBO0FBQUEsQ0FSSixXQVFJLENBQUE7QUFBQSxDQVJKLFdBUUksQ0FBQTtBQUNJLGdCQUFBLElBQUE7O0FBRUEsQ0FYUixZQVdRLENBSEosT0FHSSxDQUFBO0FBQUEsQ0FYUixXQVdRLENBSEosT0FHSSxDQUFBO0FBQUEsQ0FYUixXQVdRLENBSEosT0FHSSxDQUFBO0FBQ0ksV0FBQTs7QUFHSixDQWZSLFlBZVEsQ0FQSixNQU9JLENBQUE7QUFBQSxDQWZSLFdBZVEsQ0FQSixNQU9JLENBQUE7QUFBQSxDQWZSLFdBZVEsQ0FQSixNQU9JLENBQUE7QUFDSSxnQkFBQSxJQUFBOztBQUlSLENBcEJKLGFBb0JJO0FBQUEsQ0FwQkosWUFvQkk7QUFBQSxDQXBCSixZQW9CSTtBQUNJLFVBQUEsRUFBQSxLQUFBLEVBQUE7O0FBRUEsQ0F2QlIsYUF1QlEsR0FBQTtBQUFBLENBdkJSLFlBdUJRLEdBQUE7QUFBQSxDQXZCUixZQXVCUSxHQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUlSLENBNUJKLGFBNEJJO0FBQUEsQ0E1QkosWUE0Qkk7QUFBQSxDQTVCSixZQTRCSTtBQUNJLFVBQUEsS0FBQTtBQUNBLGFBQUE7O0FBR0osQ0FqQ0osYUFpQ0ksQ0FBQTtBQUFBLENBakNKLFlBaUNJLENBQUE7QUFBQSxDQWpDSixZQWlDSSxDQUFBO0FBQ0ksYUFBQTs7QUFHSixDQXJDSixhQXFDSSxDQUFBO0FBQUEsQ0FyQ0osWUFxQ0ksQ0FBQTtBQUFBLENBckNKLFlBcUNJLENBQUE7QUFDSSxZQUFBO0FBQ0EsT0FBQTtBQUNBLFNBQUE7QUFDQSxhQUFBOztBQUVBLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFOSixHQXJDSixhQXFDSSxDQUFBO0VBQUEsQ0FyQ0osWUFxQ0ksQ0FBQTtFQUFBLENBckNKLFlBcUNJLENBQUE7QUFPUSxjQUFBO0FBQ0EsU0FBQTtBQUNBLFdBQUE7QUFDQSxlQUFBOzs7QUFHSixDQWxEUixhQWtEUSxDQWJKLGNBYUksQ0ExQ0o7QUEwQ0ksQ0FsRFIsWUFrRFEsQ0FiSixjQWFJLENBMUNKO0FBMENJLENBbERSLFlBa0RRLENBYkosY0FhSSxDQTFDSjtBQTJDUSxlQUFBO0FBQ0EsU0FBQSxJQUFBOztBQUVBLENBdERaLGFBc0RZLENBakJSLGNBaUJRLENBOUNSLE1BOENRLENBdkNKO0FBdUNJLENBdERaLFlBc0RZLENBakJSLGNBaUJRLENBOUNSLE1BOENRLENBdkNKO0FBdUNJLENBdERaLFlBc0RZLENBakJSLGNBaUJRLENBOUNSLE1BOENRLENBdkNKO0FBd0NRLFNBQUEsSUFBQTs7QUFLWixDQTVESixhQTRESSxDQUFBO0FBQUEsQ0E1REosWUE0REksQ0FBQTtBQUFBLENBNURKLFlBNERJLENBQUE7QUFDSSxVQUFBO0FBQ0EsVUFBQSxJQUFBOztBQUdBLENBakVSLGFBaUVRLENBTEosTUFLSSxFQUFBO0FBQUEsQ0FqRVIsWUFpRVEsQ0FMSixNQUtJLEVBQUE7QUFBQSxDQWpFUixZQWlFUSxDQUxKLE1BS0ksRUFBQTtBQUNJLGFBQUE7O0FBS1IsQ0F2RUosYUF1RUk7QUFBQSxDQXZFSixZQXVFSTtBQUFBLENBdkVKLFlBdUVJO0FBQ0ksYUFBQTs7QUFFQSxPQUFBLENBQUEsU0FBQSxFQUFBO0FBSEosR0F2RUosYUF1RUk7RUFBQSxDQXZFSixZQXVFSTtFQUFBLENBdkVKLFlBdUVJO0FBSVEsZUFBQTs7O0FBR0osT0FBQSxDQUFBLFNBQUEsRUFBQTtBQVBKLEdBdkVKLGFBdUVJO0VBQUEsQ0F2RUosWUF1RUk7RUFBQSxDQXZFSixZQXVFSTtBQVFRLGVBQUE7OzsiLAogICJuYW1lcyI6IFtdCn0K */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i06.\u0275setClassDebugInfo(MultipleChoiceQuestionComponent, { className: "MultipleChoiceQuestionComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/quiz/shared/short-answer-question-util.service.ts
import { Injectable as Injectable2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { cloneDeep } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ShortAnswerQuestionUtil;
var init_short_answer_question_util_service = __esm({
  "src/main/webapp/app/exercises/quiz/shared/short-answer-question-util.service.ts"() {
    init_markdown_conversion_util();
    ShortAnswerQuestionUtil = class _ShortAnswerQuestionUtil {
      constructor() {
      }
      validateNoMisleadingShortAnswerMapping(question) {
        if (!question.correctMappings) {
          return true;
        }
        let unusedMappings = cloneDeep(question.correctMappings);
        const spotsCanBeSolved = [];
        for (const spot of question.spots) {
          let atLeastOneMapping = false;
          const solutionsForSpots = this.getAllSolutionsForSpot(question.correctMappings, spot);
          solutionsForSpots.forEach((solution) => {
            if (unusedMappings.length > 0 && unusedMappings.length !== question.correctMappings.length) {
              atLeastOneMapping = true;
            }
            if (unusedMappings.length === question.correctMappings.length) {
              const allSolutionsForSpot = this.getAllSolutionsForSpot(question.correctMappings, spot);
              const allSolutionsOnlyForSpot = allSolutionsForSpot.filter((solutionForSpot) => this.getAllSpotsForSolutions(question.correctMappings, solutionForSpot).length === 1);
              if (allSolutionsOnlyForSpot.length > 0) {
                atLeastOneMapping = true;
              }
            }
            unusedMappings = unusedMappings.filter((mapping) => !this.isSameSolution(solution, mapping.solution));
          });
          const hasSpotEnoughSolutions = this.getAllSolutionsForSpot(question.correctMappings, spot).length >= question.spots.length;
          if (atLeastOneMapping || hasSpotEnoughSolutions) {
            spotsCanBeSolved.push(true);
          } else {
            spotsCanBeSolved.push(false);
          }
        }
        return !spotsCanBeSolved.includes(false);
      }
      isMappedTogether(mappings, solution, spot) {
        return !!this.getShortAnswerMapping(mappings, solution, spot);
      }
      getAllSpotsForSolutions(mappings, solution) {
        return mappings?.filter(function(mapping) {
          return this.isSameSolution(mapping.solution, solution);
        }, this).map(function(mapping) {
          return mapping.spot;
        });
      }
      getAllSolutionsForSpot(mappings, spot) {
        return mappings?.filter((mapping) => {
          return this.isSameSpot(mapping.spot, spot);
        }, this).map((mapping) => {
          return mapping.solution;
        });
      }
      isSameSetOfSpots(set1, set2) {
        if (set1?.length !== set2?.length) {
          return false;
        }
        return set1?.every((spot1) => {
          return set2?.some((spot2) => {
            return this.isSameSpot(spot1, spot2);
          });
        }) && set2?.every((spot2) => {
          return set1?.some((spot1) => {
            return this.isSameSpot(spot1, spot2);
          });
        });
      }
      getShortAnswerMapping(mappings, solution, spot) {
        return mappings?.find((mapping) => {
          return this.isSameSpot(spot, mapping.spot) && this.isSameSolution(solution, mapping.solution);
        }, this);
      }
      isSameSpot(a, b) {
        return a === b || a !== void 0 && b !== void 0 && (a.id && b.id && a.id === b.id || a.tempID != void 0 && b.tempID != void 0 && a.tempID === b.tempID);
      }
      isSameSolution(a, b) {
        return a === b || a !== void 0 && b !== void 0 && (a.id && b.id && a.id === b.id || a.tempID != void 0 && b.tempID != void 0 && a.tempID === b.tempID);
      }
      everySpotHasASolution(mappings, spots) {
        let i = 0;
        for (const spot of spots) {
          const solutions = this.getAllSolutionsForSpot(mappings, spot);
          if (solutions && solutions.length > 0) {
            i++;
          }
        }
        return i === spots.length;
      }
      everyMappedSolutionHasASpot(mappings) {
        return !(mappings.filter((mapping) => mapping.spot === void 0).length > 0);
      }
      hasMappingDuplicateValues(mappings) {
        if (mappings.filter((mapping) => mapping.spot === void 0).length > 0) {
          return false;
        }
        let duplicateValues = 0;
        for (let i = 0; i < mappings.length - 1; i++) {
          for (let j = i + 1; j < mappings.length; j++) {
            if (mappings[i].spot.spotNr === mappings[j].spot.spotNr && mappings[i].solution.text === mappings[j].solution.text) {
              duplicateValues++;
            }
          }
        }
        return duplicateValues > 0;
      }
      getSampleSolutions(question) {
        const sampleSolutions = [];
        for (const spot of question.spots) {
          const solutionsForSpot = this.getAllSolutionsForSpot(question.correctMappings, spot);
          for (const mapping of question.correctMappings) {
            if (mapping.spot.id === spot.id && !sampleSolutions.some((sampleSolution) => sampleSolution.text === mapping.solution.text && !this.allSolutionsAreInSampleSolution(solutionsForSpot, sampleSolutions))) {
              sampleSolutions.push(mapping.solution);
              break;
            }
          }
        }
        return sampleSolutions;
      }
      allSolutionsAreInSampleSolution(solutionsForSpot, sampleSolutions) {
        let i = 0;
        for (const solutionForSpot of solutionsForSpot || []) {
          for (const sampleSolution of sampleSolutions || []) {
            if (solutionForSpot.text === sampleSolution.text) {
              i++;
              break;
            }
          }
        }
        return i === solutionsForSpot?.length;
      }
      atLeastAsManySolutionsAsSpots(question) {
        return question.spots.length <= question.solutions.length;
      }
      divideQuestionTextIntoTextParts(questionText) {
        const spotRegExpo = /\[-spot\s*[0-9]+\]/g;
        function interleave([x, ...xs], ys = []) {
          return x === void 0 ? ys : [x, ...interleave(ys, xs)];
        }
        return questionText.split(/\n/g).map((line) => {
          const spots = line.match(spotRegExpo) || [];
          const texts = line.split(spotRegExpo).map((text) => text.trim());
          return interleave(texts, spots).filter((x) => x.length > 0);
        });
      }
      isInputField(text) {
        return !(text.search(/\[-spot/g) === -1);
      }
      getSpotNr(text) {
        return +text.split(/\[-spot/g)[1].split("]")[0].trim();
      }
      getSpot(spotNr, question) {
        return question.spots.filter((spot) => spot.spotNr === spotNr)[0];
      }
      transformTextPartsIntoHTML(textParts) {
        const formattedTextParts = textParts.map((textPart) => textPart.map((element) => htmlForMarkdown(element.trim())));
        return this.addIndentationToTextParts(textParts, formattedTextParts);
      }
      addIndentationToTextParts(originalTextParts, formattedTextParts) {
        for (let i = 0; i < formattedTextParts.length; i++) {
          const element = formattedTextParts[i][0];
          let firstWord = "";
          if (originalTextParts[i].length > 1) {
            firstWord = formattedTextParts[i][0] === "" && originalTextParts[i][1].startsWith("[-spot") ? this.getFirstWord(originalTextParts[i][1]) : this.getFirstWord(originalTextParts[i][0]);
          } else {
            firstWord = this.getFirstWord(originalTextParts[i][0]);
          }
          if (firstWord === "") {
            continue;
          }
          const firstWordIndex = element.indexOf(firstWord);
          const whitespace = "&nbsp;".repeat(this.getIndentation(originalTextParts[i][0]).length);
          formattedTextParts[i][0] = [element.substring(0, firstWordIndex), whitespace, element.substring(firstWordIndex).trim()].join("");
        }
        return formattedTextParts;
      }
      getIndentation(text) {
        if (!text) {
          return "";
        }
        if (text.startsWith("`")) {
          text = text.substring(1);
        }
        let index = 0;
        let indentation = "";
        while (text[index] === " ") {
          indentation = indentation.concat(" ");
          index++;
        }
        return indentation;
      }
      getFirstWord(text) {
        if (!text) {
          return "";
        }
        const words = text.trim().split(" ").filter((word) => word !== "");
        if (words.length === 0) {
          return "";
        } else if (words[0] === "`") {
          return words[1];
        } else {
          return words[0].startsWith("`") ? words[0].substring(1) : words[0];
        }
      }
      static \u0275fac = function ShortAnswerQuestionUtil_Factory(t) {
        return new (t || _ShortAnswerQuestionUtil)();
      };
      static \u0275prov = i07.\u0275\u0275defineInjectable({ token: _ShortAnswerQuestionUtil, factory: _ShortAnswerQuestionUtil.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/entities/quiz/short-answer-submitted-text.model.ts
var ShortAnswerSubmittedText;
var init_short_answer_submitted_text_model = __esm({
  "src/main/webapp/app/entities/quiz/short-answer-submitted-text.model.ts"() {
    ShortAnswerSubmittedText = class {
      id;
      text;
      isCorrect;
      spot;
      submittedAnswer;
    };
  }
});

// src/main/webapp/app/exercises/quiz/shared/questions/short-answer-question/short-answer-question.component.ts
import { Component as Component5, EventEmitter as EventEmitter3, Input as Input6, Output as Output3, ViewEncapsulation as ViewEncapsulation4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faExclamationCircle as faExclamationCircle3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { faQuestionCircle as faQuestionCircle4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import * as i08 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i34 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i45 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i52 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ShortAnswerQuestionComponent_Conditional_8_For_4_For_4_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                                ");
    i08.\u0275\u0275element(1, "div", 4);
    i08.\u0275\u0275text(2, "\n                            ");
  }
  if (rf & 2) {
    const element_r14 = i08.\u0275\u0275nextContext().$implicit;
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("innerHTML", element_r14, i08.\u0275\u0275sanitizeHtml);
  }
}
function ShortAnswerQuestionComponent_Conditional_8_For_4_For_4_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                                ");
    i08.\u0275\u0275elementStart(1, "div", 5);
    i08.\u0275\u0275text(2, "\n                                    ");
    i08.\u0275\u0275elementStart(3, "input", 6);
    i08.\u0275\u0275listener("change", function ShortAnswerQuestionComponent_Conditional_8_For_4_For_4_Conditional_4_Template_input_change_3_listener() {
      i08.\u0275\u0275restoreView(_r23);
      const ctx_r22 = i08.\u0275\u0275nextContext(4);
      return i08.\u0275\u0275resetView(ctx_r22.setSubmittedText());
    });
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(4, "\n                                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(5, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r24 = i08.\u0275\u0275nextContext();
    const element_r14 = ctx_r24.$implicit;
    const j_r15 = ctx_r24.$index;
    const i_r9 = i08.\u0275\u0275nextContext().$index;
    const ctx_r20 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275propertyInterpolate("value", ctx_r20.getSubmittedTextForSpotAsString(element_r14));
    i08.\u0275\u0275propertyInterpolate3("id", "solution-", i_r9, "-", j_r15, "-", ctx_r20.shortAnswerQuestion.id, "");
    i08.\u0275\u0275property("maxLength", ctx_r20.maxCharacterCount)("disabled", ctx_r20.clickDisabled);
  }
}
function ShortAnswerQuestionComponent_Conditional_8_For_4_For_4_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                        ");
    i08.\u0275\u0275elementStart(1, "div", 3);
    i08.\u0275\u0275text(2, "\n                            ");
    i08.\u0275\u0275template(3, ShortAnswerQuestionComponent_Conditional_8_For_4_For_4_Conditional_3_Template, 3, 1)(4, ShortAnswerQuestionComponent_Conditional_8_For_4_For_4_Conditional_4_Template, 6, 6);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const element_r14 = ctx.$implicit;
    const ctx_r13 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275conditional(3, !ctx_r13.shortAnswerQuestionUtil.isInputField(element_r14) ? 3 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275conditional(4, ctx_r13.shortAnswerQuestionUtil.isInputField(element_r14) ? 4 : -1);
  }
}
function ShortAnswerQuestionComponent_Conditional_8_For_4_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275elementStart(1, "div", 2);
    i08.\u0275\u0275text(2, "\n                    ");
    i08.\u0275\u0275repeaterCreate(3, ShortAnswerQuestionComponent_Conditional_8_For_4_For_4_Template, 6, 2, null, null, i08.\u0275\u0275repeaterTrackByIdentity);
    i08.\u0275\u0275element(5, "br");
    i08.\u0275\u0275text(6, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n            ");
  }
  if (rf & 2) {
    const textPart_r8 = ctx.$implicit;
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275repeater(textPart_r8);
  }
}
function ShortAnswerQuestionComponent_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n        ");
    i08.\u0275\u0275elementStart(1, "div");
    i08.\u0275\u0275text(2, "\n            ");
    i08.\u0275\u0275repeaterCreate(3, ShortAnswerQuestionComponent_Conditional_8_For_4_Template, 8, 0, null, null, i08.\u0275\u0275repeaterTrackByIdentity);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275repeater(ctx_r0.textParts);
  }
}
function ShortAnswerQuestionComponent_Conditional_9_For_4_For_4_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                                ");
    i08.\u0275\u0275element(1, "div", 4);
    i08.\u0275\u0275text(2, "\n                            ");
  }
  if (rf & 2) {
    const element_r33 = i08.\u0275\u0275nextContext().$implicit;
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("innerHTML", element_r33, i08.\u0275\u0275sanitizeHtml);
  }
}
function ShortAnswerQuestionComponent_Conditional_9_For_4_For_4_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                                ");
    i08.\u0275\u0275elementStart(1, "div", 7);
    i08.\u0275\u0275pipe(2, "artemisTranslate");
    i08.\u0275\u0275text(3, "\n                                    ");
    i08.\u0275\u0275element(4, "input", 8);
    i08.\u0275\u0275text(5, "\n                                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(6, "\n                            ");
  }
  if (rf & 2) {
    const element_r33 = i08.\u0275\u0275nextContext().$implicit;
    const ctx_r39 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("ngbTooltip", ctx_r39.classifyInputField(element_r33) === "invalid" ? i08.\u0275\u0275pipeBind1(2, 7, "artemisApp.shortAnswerSpot.invalidSpot") : void 0);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275classMapInterpolate1("short-answer-question-container__input ", ctx_r39.classifyInputField(element_r33), "");
    i08.\u0275\u0275propertyInterpolate("value", ctx_r39.getTextForSpotAsString(element_r33));
    i08.\u0275\u0275propertyInterpolate("size", ctx_r39.getSizeForSpot(element_r33));
    i08.\u0275\u0275property("maxLength", ctx_r39.maxCharacterCount);
  }
}
function ShortAnswerQuestionComponent_Conditional_9_For_4_For_4_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                        ");
    i08.\u0275\u0275elementStart(1, "div", 3);
    i08.\u0275\u0275text(2, "\n                            ");
    i08.\u0275\u0275template(3, ShortAnswerQuestionComponent_Conditional_9_For_4_For_4_Conditional_3_Template, 3, 1)(4, ShortAnswerQuestionComponent_Conditional_9_For_4_For_4_Conditional_4_Template, 7, 9);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const element_r33 = ctx.$implicit;
    const ctx_r32 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275conditional(3, !ctx_r32.shortAnswerQuestionUtil.isInputField(element_r33) ? 3 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275conditional(4, ctx_r32.shortAnswerQuestionUtil.isInputField(element_r33) ? 4 : -1);
  }
}
function ShortAnswerQuestionComponent_Conditional_9_For_4_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275elementStart(1, "div", 2);
    i08.\u0275\u0275text(2, "\n                    ");
    i08.\u0275\u0275repeaterCreate(3, ShortAnswerQuestionComponent_Conditional_9_For_4_For_4_Template, 6, 2, null, null, i08.\u0275\u0275repeaterTrackByIdentity);
    i08.\u0275\u0275element(5, "br");
    i08.\u0275\u0275text(6, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n            ");
  }
  if (rf & 2) {
    const textPart_r27 = ctx.$implicit;
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275repeater(textPart_r27);
  }
}
function ShortAnswerQuestionComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n        ");
    i08.\u0275\u0275elementStart(1, "div");
    i08.\u0275\u0275text(2, "\n            ");
    i08.\u0275\u0275repeaterCreate(3, ShortAnswerQuestionComponent_Conditional_9_For_4_Template, 8, 0, null, null, i08.\u0275\u0275repeaterTrackByIdentity);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275repeater(ctx_r1.textParts);
  }
}
function ShortAnswerQuestionComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n        ");
    i08.\u0275\u0275element(1, "span", 9);
    i08.\u0275\u0275text(2, "\n    ");
  }
}
function ShortAnswerQuestionComponent_Conditional_11_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275element(1, "div", 4);
    i08.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r42 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("innerHTML", ctx_r42.renderedQuestion.hint, i08.\u0275\u0275sanitizeHtml);
  }
}
function ShortAnswerQuestionComponent_Conditional_11_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275elementStart(1, "span", 13);
    i08.\u0275\u0275text(2, "\n                    ");
    i08.\u0275\u0275element(3, "fa-icon", 14);
    i08.\u0275\u0275text(4, "\n                    ");
    i08.\u0275\u0275element(5, "span", 15);
    i08.\u0275\u0275text(6, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n            ");
  }
  if (rf & 2) {
    i08.\u0275\u0275nextContext();
    const _r43 = i08.\u0275\u0275reference(4);
    const ctx_r44 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("ngbPopover", _r43);
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275property("icon", ctx_r44.farQuestionCircle);
  }
}
function ShortAnswerQuestionComponent_Conditional_11_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275element(1, "div", 4);
    i08.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r45 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("innerHTML", ctx_r45.renderedQuestion.explanation, i08.\u0275\u0275sanitizeHtml);
  }
}
function ShortAnswerQuestionComponent_Conditional_11_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275elementStart(1, "span", 16);
    i08.\u0275\u0275text(2, "\n                    ");
    i08.\u0275\u0275element(3, "fa-icon", 14);
    i08.\u0275\u0275text(4, "\n                    ");
    i08.\u0275\u0275element(5, "span", 17);
    i08.\u0275\u0275text(6, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n            ");
  }
  if (rf & 2) {
    i08.\u0275\u0275nextContext();
    const _r46 = i08.\u0275\u0275reference(10);
    const ctx_r47 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("ngbPopover", _r46);
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275property("icon", ctx_r47.faExclamationCircle);
  }
}
function ShortAnswerQuestionComponent_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n        ");
    i08.\u0275\u0275elementStart(1, "div", 10);
    i08.\u0275\u0275text(2, "\n            ");
    i08.\u0275\u0275template(3, ShortAnswerQuestionComponent_Conditional_11_ng_template_3_Template, 3, 1, "ng-template", null, 11, i08.\u0275\u0275templateRefExtractor);
    i08.\u0275\u0275text(5, "\n            ");
    i08.\u0275\u0275template(6, ShortAnswerQuestionComponent_Conditional_11_Conditional_6_Template, 8, 2);
    i08.\u0275\u0275element(7, "br");
    i08.\u0275\u0275text(8, "\n            ");
    i08.\u0275\u0275template(9, ShortAnswerQuestionComponent_Conditional_11_ng_template_9_Template, 3, 1, "ng-template", null, 12, i08.\u0275\u0275templateRefExtractor);
    i08.\u0275\u0275text(11, "\n            ");
    i08.\u0275\u0275template(12, ShortAnswerQuestionComponent_Conditional_11_Conditional_12_Template, 8, 2);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(13, "\n    ");
  }
  if (rf & 2) {
    const ctx_r3 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(6);
    i08.\u0275\u0275conditional(6, ctx_r3.shortAnswerQuestion.hint ? 6 : -1);
    i08.\u0275\u0275advance(6);
    i08.\u0275\u0275conditional(12, ctx_r3.shortAnswerQuestion.explanation && ctx_r3.showResult ? 12 : -1);
  }
}
function ShortAnswerQuestionComponent_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n        ");
    i08.\u0275\u0275elementStart(1, "div", 18);
    i08.\u0275\u0275text(2, "\n            ");
    i08.\u0275\u0275element(3, "span", 19);
    i08.\u0275\u0275text(4, "\n            ");
    i08.\u0275\u0275elementStart(5, "span");
    i08.\u0275\u0275text(6);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(8, "\n    ");
  }
  if (rf & 2) {
    const ctx_r4 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(6);
    i08.\u0275\u0275textInterpolate(ctx_r4.shortAnswerQuestion.points);
  }
}
function ShortAnswerQuestionComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n        ");
    i08.\u0275\u0275elementStart(1, "div", 20);
    i08.\u0275\u0275text(2, "\n            ");
    i08.\u0275\u0275element(3, "span", 21);
    i08.\u0275\u0275text(4, "\n            ");
    i08.\u0275\u0275elementStart(5, "span", 22);
    i08.\u0275\u0275text(6);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n            ");
    i08.\u0275\u0275elementStart(8, "span", 22);
    i08.\u0275\u0275text(9, "\n                ");
    i08.\u0275\u0275element(10, "jhi-quiz-scoring-infostudent-modal", 23);
    i08.\u0275\u0275text(11, "\n            ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(12, "\n        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(13, "\n    ");
  }
  if (rf & 2) {
    const ctx_r5 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("ngClass", i08.\u0275\u0275pureFunction1(7, _c05, (ctx_r5.score || 0) < ctx_r5.shortAnswerQuestion.points));
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275textInterpolate2("", ctx_r5.score || 0, "/", ctx_r5.shortAnswerQuestion.points, "");
    i08.\u0275\u0275advance(4);
    i08.\u0275\u0275property("score", ctx_r5.score)("question", ctx_r5.shortAnswerQuestion)("shortAnswerText", ctx_r5.submittedTexts)("questionIndex", ctx_r5.questionIndex);
  }
}
function ShortAnswerQuestionComponent_Conditional_18_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r51 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275elementStart(1, "div", 24);
    i08.\u0275\u0275listener("click", function ShortAnswerQuestionComponent_Conditional_18_Conditional_3_Template_div_click_1_listener() {
      i08.\u0275\u0275restoreView(_r51);
      const ctx_r50 = i08.\u0275\u0275nextContext(2);
      return i08.\u0275\u0275resetView(ctx_r50.showSampleSolution());
    });
    i08.\u0275\u0275text(2);
    i08.\u0275\u0275pipe(3, "artemisTranslate");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275textInterpolate1("\n                    ", i08.\u0275\u0275pipeBind1(3, 1, "artemisApp.quizQuestion.showSampleSolution"), "\n                ");
  }
}
function ShortAnswerQuestionComponent_Conditional_18_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r53 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275elementStart(1, "div", 24);
    i08.\u0275\u0275listener("click", function ShortAnswerQuestionComponent_Conditional_18_Conditional_4_Template_div_click_1_listener() {
      i08.\u0275\u0275restoreView(_r53);
      const ctx_r52 = i08.\u0275\u0275nextContext(2);
      return i08.\u0275\u0275resetView(ctx_r52.hideSampleSolution());
    });
    i08.\u0275\u0275text(2);
    i08.\u0275\u0275pipe(3, "artemisTranslate");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275textInterpolate1("\n                    ", i08.\u0275\u0275pipeBind1(3, 1, "artemisApp.quizQuestion.hideSampleSolution"), "\n                ");
  }
}
function ShortAnswerQuestionComponent_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n        ");
    i08.\u0275\u0275elementStart(1, "div");
    i08.\u0275\u0275text(2, "\n            ");
    i08.\u0275\u0275template(3, ShortAnswerQuestionComponent_Conditional_18_Conditional_3_Template, 5, 3)(4, ShortAnswerQuestionComponent_Conditional_18_Conditional_4_Template, 5, 3);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r6 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275conditional(3, !ctx_r6.showingSampleSolution ? 3 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275conditional(4, ctx_r6.showingSampleSolution ? 4 : -1);
  }
}
var _c05, _c14, ShortAnswerQuestionComponent;
var init_short_answer_question_component = __esm({
  "src/main/webapp/app/exercises/quiz/shared/questions/short-answer-question/short-answer-question.component.ts"() {
    init_markdown_service();
    init_short_answer_question_util_service();
    init_short_answer_submitted_text_model();
    init_quiz_question_model();
    init_input_constants();
    init_markdown_service();
    init_short_answer_question_util_service();
    init_translate_directive();
    init_quiz_scoring_info_student_modal_component();
    init_artemis_translate_pipe();
    _c05 = (a0) => ({ incorrect: a0 });
    _c14 = (a0, a1, a2) => ({ disabled: a0, result: a1, incorrect: a2 });
    ShortAnswerQuestionComponent = class _ShortAnswerQuestionComponent {
      artemisMarkdown;
      shortAnswerQuestionUtil;
      shortAnswerQuestion;
      _forceSampleSolution;
      set question(question) {
        this.shortAnswerQuestion = question;
        this.watchCollection();
      }
      submittedTexts;
      clickDisabled;
      showResult;
      questionIndex;
      score;
      set forceSampleSolution(forceSampleSolution) {
        this._forceSampleSolution = forceSampleSolution;
        if (this.forceSampleSolution) {
          this.showSampleSolution();
        }
      }
      get forceSampleSolution() {
        return this._forceSampleSolution;
      }
      fnOnSubmittedTextUpdate;
      submittedTextsChange = new EventEmitter3();
      maxCharacterCount = MAX_QUIZ_SHORT_ANSWER_TEXT_LENGTH;
      showingSampleSolution = false;
      renderedQuestion;
      sampleSolutions = [];
      textParts;
      faExclamationCircle = faExclamationCircle3;
      farQuestionCircle = faQuestionCircle4;
      constructor(artemisMarkdown, shortAnswerQuestionUtil) {
        this.artemisMarkdown = artemisMarkdown;
        this.shortAnswerQuestionUtil = shortAnswerQuestionUtil;
      }
      watchCollection() {
        this.renderedQuestion = new RenderedQuizQuestionMarkDownElement();
        const textParts = this.shortAnswerQuestionUtil.divideQuestionTextIntoTextParts(this.shortAnswerQuestion.text);
        this.textParts = this.shortAnswerQuestionUtil.transformTextPartsIntoHTML(textParts);
        this.renderedQuestion.text = this.artemisMarkdown.safeHtmlForMarkdown(this.shortAnswerQuestion.text);
        this.renderedQuestion.hint = this.artemisMarkdown.safeHtmlForMarkdown(this.shortAnswerQuestion.hint);
        this.renderedQuestion.explanation = this.artemisMarkdown.safeHtmlForMarkdown(this.shortAnswerQuestion.explanation);
      }
      setSubmittedText() {
        this.submittedTexts = [];
        let i = 0;
        for (const textpart of this.textParts) {
          let j = 0;
          for (const element of textpart) {
            if (this.shortAnswerQuestionUtil.isInputField(element)) {
              const submittedText = new ShortAnswerSubmittedText();
              submittedText.text = document.getElementById("solution-" + i + "-" + j + "-" + this.shortAnswerQuestion.id).value;
              submittedText.spot = this.shortAnswerQuestionUtil.getSpot(this.shortAnswerQuestionUtil.getSpotNr(element), this.shortAnswerQuestion);
              this.submittedTexts.push(submittedText);
            }
            j++;
          }
          i++;
        }
        this.submittedTextsChange.emit(this.submittedTexts);
        if (this.fnOnSubmittedTextUpdate) {
          this.fnOnSubmittedTextUpdate();
        }
      }
      showSampleSolution() {
        this.sampleSolutions = this.shortAnswerQuestionUtil.getSampleSolutions(this.shortAnswerQuestion);
        this.showingSampleSolution = true;
      }
      hideSampleSolution() {
        this.showingSampleSolution = false;
      }
      getSubmittedTextForSpot(spotTag) {
        return this.submittedTexts.filter((submittedText) => submittedText.spot.spotNr === this.shortAnswerQuestionUtil.getSpotNr(spotTag))[0];
      }
      getSubmittedTextForSpotAsString(spotTag) {
        const submittedText = this.getSubmittedTextForSpot(spotTag);
        return submittedText?.text ?? "";
      }
      getSubmittedTextSizeForSpot(spotTag) {
        const submittedText = this.getSubmittedTextForSpotAsString(spotTag);
        return submittedText !== "" ? submittedText.length + 2 : 5;
      }
      getSampleSolutionForSpot(spotTag) {
        const index = this.shortAnswerQuestion.spots.findIndex((spot) => spot.spotNr === this.shortAnswerQuestionUtil.getSpotNr(spotTag));
        return this.sampleSolutions[index];
      }
      getSampleSolutionForSpotAsString(spotTag) {
        const sampleSolution = this.getSampleSolutionForSpot(spotTag);
        return sampleSolution?.text ?? "";
      }
      getSampleSolutionSizeForSpot(spotTag) {
        const sampleSolution = this.getSampleSolutionForSpotAsString(spotTag);
        return sampleSolution !== "" ? sampleSolution.length + 2 : 5;
      }
      getTextForSpotAsString(spotTag) {
        if (this.showingSampleSolution) {
          return this.getSampleSolutionForSpotAsString(spotTag);
        }
        return this.getSubmittedTextForSpotAsString(spotTag);
      }
      getSizeForSpot(spotTag) {
        if (this.showingSampleSolution) {
          return this.getSampleSolutionSizeForSpot(spotTag);
        }
        return this.getSubmittedTextSizeForSpot(spotTag);
      }
      classifyInputField(spotTag) {
        if (this.shortAnswerQuestion.invalid) {
          return "invalid";
        }
        const spot = this.shortAnswerQuestionUtil.getSpot(this.shortAnswerQuestionUtil.getSpotNr(spotTag), this.shortAnswerQuestion);
        if (spot.invalid) {
          return "invalid";
        }
        if (this.showingSampleSolution) {
          return "completely-correct";
        }
        const submittedTextForSpot = this.getSubmittedTextForSpot(spotTag);
        if (submittedTextForSpot?.isCorrect !== true) {
          return "wrong";
        }
        if (this.isSubmittedTextCompletelyCorrect(spotTag)) {
          return "completely-correct";
        }
        return "correct";
      }
      isSubmittedTextCompletelyCorrect(spotTag) {
        let isTextCorrect = false;
        const solutionsForSpot = this.shortAnswerQuestionUtil.getAllSolutionsForSpot(this.shortAnswerQuestion.correctMappings, this.shortAnswerQuestionUtil.getSpot(this.shortAnswerQuestionUtil.getSpotNr(spotTag), this.shortAnswerQuestion));
        const solutions = solutionsForSpot?.filter((solution) => solution.text?.trim() === this.getSubmittedTextForSpot(spotTag)?.text?.trim());
        if (solutions && solutions.length > 0) {
          isTextCorrect = true;
        }
        return isTextCorrect;
      }
      static \u0275fac = function ShortAnswerQuestionComponent_Factory(t) {
        return new (t || _ShortAnswerQuestionComponent)(i08.\u0275\u0275directiveInject(ArtemisMarkdownService), i08.\u0275\u0275directiveInject(ShortAnswerQuestionUtil));
      };
      static \u0275cmp = i08.\u0275\u0275defineComponent({ type: _ShortAnswerQuestionComponent, selectors: [["jhi-short-answer-question"]], inputs: { question: "question", submittedTexts: "submittedTexts", clickDisabled: "clickDisabled", showResult: "showResult", questionIndex: "questionIndex", score: "score", forceSampleSolution: "forceSampleSolution", fnOnSubmittedTextUpdate: "fnOnSubmittedTextUpdate" }, outputs: { submittedTextsChange: "submittedTextsChange" }, features: [i08.\u0275\u0275ProvidersFeature([ShortAnswerQuestionUtil])], decls: 20, vars: 14, consts: [[1, "sa-question", 3, "ngClass"], [1, "question-title-display"], [1, "short-answer-question-display"], [1, "short-answer-question-display__element"], [3, "innerHTML"], ["id", "sa-question-container-A", 1, "short-answer-question-container"], ["type", "text", 1, "short-answer-question-container__input", 3, "maxLength", "disabled", "value", "id", "change"], [1, "short-answer-question-container", 3, "ngbTooltip"], ["type", "text", "disabled", "", 3, "maxLength", "value", "size"], ["jhiTranslate", "artemisApp.quizQuestion.invalidText", 2, "color", "red"], [1, "hint"], ["renderedHint", ""], ["renderedExplanation", ""], ["placement", "right auto", "triggers", "mouseenter:mouseleave", 1, "label", "label-info", 3, "ngbPopover"], [3, "icon"], ["jhiTranslate", "artemisApp.quizQuestion.hint"], ["placement", "right auto", "triggers", "mouseenter:mouseleave", 1, "label", "label-primary", 3, "ngbPopover"], ["jhiTranslate", "artemisApp.quizQuestion.explanation"], [1, "question-score"], ["jhiTranslate", "artemisApp.quizQuestion.score", 1, "colon-suffix"], [1, "question-score", "result", 3, "ngClass"], ["jhiTranslate", "artemisApp.quizQuestion.yourScore", 1, "colon-suffix"], [1, "show-explanation"], [3, "score", "question", "shortAnswerText", "questionIndex"], [1, "btn", "btn-outline-primary", 3, "click"]], template: function ShortAnswerQuestionComponent_Template(rf, ctx) {
        if (rf & 1) {
          i08.\u0275\u0275elementStart(0, "div", 0);
          i08.\u0275\u0275text(1, "\n    ");
          i08.\u0275\u0275elementStart(2, "h4", 1);
          i08.\u0275\u0275text(3, "\n        ");
          i08.\u0275\u0275elementStart(4, "span");
          i08.\u0275\u0275text(5);
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(6);
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(7, "\n    ");
          i08.\u0275\u0275template(8, ShortAnswerQuestionComponent_Conditional_8_Template, 6, 0)(9, ShortAnswerQuestionComponent_Conditional_9_Template, 6, 0)(10, ShortAnswerQuestionComponent_Conditional_10_Template, 3, 0)(11, ShortAnswerQuestionComponent_Conditional_11_Template, 14, 2)(12, ShortAnswerQuestionComponent_Conditional_12_Template, 9, 1)(13, ShortAnswerQuestionComponent_Conditional_13_Template, 14, 9);
          i08.\u0275\u0275element(14, "br");
          i08.\u0275\u0275text(15, "\n    ");
          i08.\u0275\u0275element(16, "br");
          i08.\u0275\u0275text(17, "\n    ");
          i08.\u0275\u0275template(18, ShortAnswerQuestionComponent_Conditional_18_Template, 6, 2);
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(19, "\n");
        }
        if (rf & 2) {
          i08.\u0275\u0275property("ngClass", i08.\u0275\u0275pureFunction3(10, _c14, ctx.clickDisabled && !ctx.showResult, ctx.showResult && !ctx.forceSampleSolution, (ctx.score || 0) < ctx.shortAnswerQuestion.points && !ctx.forceSampleSolution));
          i08.\u0275\u0275advance(5);
          i08.\u0275\u0275textInterpolate1("", ctx.questionIndex, ")");
          i08.\u0275\u0275advance(1);
          i08.\u0275\u0275textInterpolate1(" ", ctx.shortAnswerQuestion.title, "\n    ");
          i08.\u0275\u0275advance(2);
          i08.\u0275\u0275conditional(8, !ctx.showResult ? 8 : -1);
          i08.\u0275\u0275advance(1);
          i08.\u0275\u0275conditional(9, ctx.showResult ? 9 : -1);
          i08.\u0275\u0275advance(1);
          i08.\u0275\u0275conditional(10, ctx.shortAnswerQuestion.invalid ? 10 : -1);
          i08.\u0275\u0275advance(1);
          i08.\u0275\u0275conditional(11, ctx.shortAnswerQuestion.hint || ctx.shortAnswerQuestion.explanation && ctx.showResult ? 11 : -1);
          i08.\u0275\u0275advance(1);
          i08.\u0275\u0275conditional(12, !ctx.showResult || ctx.forceSampleSolution ? 12 : -1);
          i08.\u0275\u0275advance(1);
          i08.\u0275\u0275conditional(13, ctx.showResult && !ctx.forceSampleSolution ? 13 : -1);
          i08.\u0275\u0275advance(5);
          i08.\u0275\u0275conditional(18, ctx.showResult && !ctx.forceSampleSolution ? 18 : -1);
        }
      }, dependencies: [i34.NgClass, i45.NgbPopover, i45.NgbTooltip, i52.FaIconComponent, TranslateDirective, QuizScoringInfoStudentModalComponent, ArtemisTranslatePipe], styles: ["/* src/main/webapp/app/exercises/quiz/shared/questions/short-answer-question/short-answer-question.component.scss */\n.sa-question {\n  background: var(--quiz-question-background);\n  border: 1px solid var(--quiz-question-border-color);\n  box-sizing: border-box;\n  margin-bottom: 18px;\n  padding: 20px;\n  position: relative;\n  width: 100%;\n  word-break: break-word;\n}\n.sa-question .short-answer-question-display {\n  display: flex;\n  flex-wrap: wrap;\n  max-width: 100%;\n}\n.sa-question .short-answer-question-display__element {\n  display: inline-flex;\n}\n.sa-question .short-answer-question-display .short-answer-question-container {\n  display: inline-block;\n  position: relative;\n}\n.sa-question .short-answer-question-display .short-answer-question-container__input {\n  border: 1px solid var(--sa-question-container-input-border);\n  background-color: var(--sa-question-container-input-background);\n  color: var(--bs-body-color);\n  line-height: 35px;\n  margin-bottom: 10px;\n}\n.sa-question .short-answer-question-display .short-answer-question-container__input.invalid {\n  background: var(--sa-question-input-invalid-background);\n}\n.sa-question .short-answer-question-display .short-answer-question-container__input.wrong {\n  background: var(--sa-question-input-wrong-background);\n}\n.sa-question .short-answer-question-display .short-answer-question-container__input.correct {\n  background: var(--sa-question-input-correct-background);\n}\n.sa-question .short-answer-question-display .short-answer-question-container__input.completely-correct {\n  background: var(--sa-question-input-completely-correct-background);\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL3Nob3J0LWFuc3dlci1xdWVzdGlvbi9zaG9ydC1hbnN3ZXItcXVlc3Rpb24uY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5zYS1xdWVzdGlvbiB7XG4gICAgYmFja2dyb3VuZDogdmFyKC0tcXVpei1xdWVzdGlvbi1iYWNrZ3JvdW5kKTtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1xdWl6LXF1ZXN0aW9uLWJvcmRlci1jb2xvcik7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICBtYXJnaW4tYm90dG9tOiAxOHB4O1xuICAgIHBhZGRpbmc6IDIwcHg7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHdvcmQtYnJlYWs6IGJyZWFrLXdvcmQ7XG5cbiAgICAuc2hvcnQtYW5zd2VyLXF1ZXN0aW9uLWRpc3BsYXkge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LXdyYXA6IHdyYXA7XG4gICAgICAgIG1heC13aWR0aDogMTAwJTtcblxuICAgICAgICAmX19lbGVtZW50IHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICAgICAgICB9XG5cbiAgICAgICAgLnNob3J0LWFuc3dlci1xdWVzdGlvbi1jb250YWluZXIge1xuICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgICAgICAgICAmX19pbnB1dCB7XG4gICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tc2EtcXVlc3Rpb24tY29udGFpbmVyLWlucHV0LWJvcmRlcik7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tc2EtcXVlc3Rpb24tY29udGFpbmVyLWlucHV0LWJhY2tncm91bmQpO1xuICAgICAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1icy1ib2R5LWNvbG9yKTtcbiAgICAgICAgICAgICAgICBsaW5lLWhlaWdodDogMzVweDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAmX19pbnB1dC5pbnZhbGlkIHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1zYS1xdWVzdGlvbi1pbnB1dC1pbnZhbGlkLWJhY2tncm91bmQpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAmX19pbnB1dC53cm9uZyB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tc2EtcXVlc3Rpb24taW5wdXQtd3JvbmctYmFja2dyb3VuZCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICZfX2lucHV0LmNvcnJlY3Qge1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLXNhLXF1ZXN0aW9uLWlucHV0LWNvcnJlY3QtYmFja2dyb3VuZCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICZfX2lucHV0LmNvbXBsZXRlbHktY29ycmVjdCB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tc2EtcXVlc3Rpb24taW5wdXQtY29tcGxldGVseS1jb3JyZWN0LWJhY2tncm91bmQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLENBQUE7QUFDSSxjQUFBLElBQUE7QUFDQSxVQUFBLElBQUEsTUFBQSxJQUFBO0FBQ0EsY0FBQTtBQUNBLGlCQUFBO0FBQ0EsV0FBQTtBQUNBLFlBQUE7QUFDQSxTQUFBO0FBQ0EsY0FBQTs7QUFFQSxDQVZKLFlBVUksQ0FBQTtBQUNJLFdBQUE7QUFDQSxhQUFBO0FBQ0EsYUFBQTs7QUFFQSxDQWZSLFlBZVEsQ0FBQTtBQUNJLFdBQUE7O0FBR0osQ0FuQlIsWUFtQlEsQ0FUSiw4QkFTSSxDQUFBO0FBQ0ksV0FBQTtBQUNBLFlBQUE7O0FBRUEsQ0F2QlosWUF1QlksQ0FiUiw4QkFhUSxDQUFBO0FBQ0ksVUFBQSxJQUFBLE1BQUEsSUFBQTtBQUNBLG9CQUFBLElBQUE7QUFDQSxTQUFBLElBQUE7QUFDQSxlQUFBO0FBQ0EsaUJBQUE7O0FBR0osQ0EvQlosWUErQlksQ0FyQlIsOEJBcUJRLENBUkEsc0NBUUEsQ0FBQTtBQUNJLGNBQUEsSUFBQTs7QUFHSixDQW5DWixZQW1DWSxDQXpCUiw4QkF5QlEsQ0FaQSxzQ0FZQSxDQUFBO0FBQ0ksY0FBQSxJQUFBOztBQUdKLENBdkNaLFlBdUNZLENBN0JSLDhCQTZCUSxDQWhCQSxzQ0FnQkEsQ0FBQTtBQUNJLGNBQUEsSUFBQTs7QUFHSixDQTNDWixZQTJDWSxDQWpDUiw4QkFpQ1EsQ0FwQkEsc0NBb0JBLENBQUE7QUFDSSxjQUFBLElBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */\n", "/* src/main/webapp/app/exercises/quiz/participate/quiz-participation.scss */\n.dnd-question,\n.mc-question,\n.sa-question {\n}\n.dnd-question.disabled,\n.mc-question.disabled,\n.sa-question.disabled {\n  color: var(--quiz-participation-question-disabled-color);\n  background: var(--quiz-participation-question-disabled-background);\n}\n.dnd-question.result,\n.mc-question.result,\n.sa-question.result {\n  border-color: var(--quiz-participation-question-result-border-color);\n}\n.dnd-question.result .show-explanation,\n.mc-question.result .show-explanation,\n.sa-question.result .show-explanation {\n  display: inline-block;\n}\n.dnd-question.result.incorrect,\n.mc-question.result.incorrect,\n.sa-question.result.incorrect {\n  border-color: var(--quiz-participation-question-result-incorrect-border-color);\n}\n.dnd-question h2,\n.mc-question h2,\n.sa-question h2 {\n  margin: 0 90px 0 0;\n}\n.dnd-question h2 span,\n.mc-question h2 span,\n.sa-question h2 span {\n  color: var(--quiz-participation-question-h2-span-color);\n}\n.dnd-question p,\n.mc-question p,\n.sa-question p {\n  margin: 10px 0;\n  font-size: 16px;\n}\n.dnd-question .question-title-display,\n.mc-question .question-title-display,\n.sa-question .question-title-display {\n  max-width: 80%;\n}\n.dnd-question .question-score,\n.mc-question .question-score,\n.sa-question .question-score {\n  position: absolute;\n  top: 20px;\n  right: 20px;\n  max-width: 30%;\n}\n@media (max-width: 900px) {\n  .dnd-question .question-score,\n  .mc-question .question-score,\n  .sa-question .question-score {\n    position: relative;\n    top: 0;\n    right: 0;\n    max-width: 100%;\n  }\n}\n.dnd-question .question-score.result,\n.mc-question .question-score.result,\n.sa-question .question-score.result {\n  font-weight: bold;\n  color: var(--quiz-participation-question-score-result);\n}\n.dnd-question .question-score.result.incorrect,\n.mc-question .question-score.result.incorrect,\n.sa-question .question-score.result.incorrect {\n  color: var(--quiz-participation-question-score-incorrect-result);\n}\n.dnd-question .label,\n.mc-question .label,\n.sa-question .label {\n  cursor: pointer;\n  margin: 2px 0;\n}\n.dnd-question .label + ngb-popover-window,\n.mc-question .label + ngb-popover-window,\n.sa-question .label + ngb-popover-window {\n  max-width: 500px;\n}\n.dnd-question ngb-popover-window,\n.mc-question ngb-popover-window,\n.sa-question ngb-popover-window {\n  max-width: 500px;\n}\n@media (max-width: 991.98px) {\n  .dnd-question ngb-popover-window,\n  .mc-question ngb-popover-window,\n  .sa-question ngb-popover-window {\n    max-width: 300px !important;\n  }\n}\n@media (max-width: 575.98px) {\n  .dnd-question ngb-popover-window,\n  .mc-question ngb-popover-window,\n  .sa-question ngb-popover-window {\n    max-width: 200px !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9wYXJ0aWNpcGF0ZS9xdWl6LXBhcnRpY2lwYXRpb24uc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmRuZC1xdWVzdGlvbixcbi5tYy1xdWVzdGlvbixcbi5zYS1xdWVzdGlvbiB7XG4gICAgJi5kaXNhYmxlZCB7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tcXVlc3Rpb24tZGlzYWJsZWQtY29sb3IpO1xuICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tcXVlc3Rpb24tZGlzYWJsZWQtYmFja2dyb3VuZCk7XG4gICAgfVxuXG4gICAgJi5yZXN1bHQge1xuICAgICAgICBib3JkZXItY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1yZXN1bHQtYm9yZGVyLWNvbG9yKTtcblxuICAgICAgICAuc2hvdy1leHBsYW5hdGlvbiB7XG4gICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgIH1cblxuICAgICAgICAmLmluY29ycmVjdCB7XG4gICAgICAgICAgICBib3JkZXItY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1yZXN1bHQtaW5jb3JyZWN0LWJvcmRlci1jb2xvcik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBoMiB7XG4gICAgICAgIG1hcmdpbjogMCA5MHB4IDAgMDtcblxuICAgICAgICBzcGFuIHtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tcXVlc3Rpb24taDItc3Bhbi1jb2xvcik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwIHtcbiAgICAgICAgbWFyZ2luOiAxMHB4IDA7XG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICB9XG5cbiAgICAucXVlc3Rpb24tdGl0bGUtZGlzcGxheSB7XG4gICAgICAgIG1heC13aWR0aDogODAlO1xuICAgIH1cblxuICAgIC5xdWVzdGlvbi1zY29yZSB7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdG9wOiAyMHB4O1xuICAgICAgICByaWdodDogMjBweDtcbiAgICAgICAgbWF4LXdpZHRoOiAzMCU7XG5cbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDkwMHB4KSB7XG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICB0b3A6IDA7XG4gICAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgICAgIG1heC13aWR0aDogMTAwJTtcbiAgICAgICAgfVxuXG4gICAgICAgICYucmVzdWx0IHtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1zY29yZS1yZXN1bHQpO1xuXG4gICAgICAgICAgICAmLmluY29ycmVjdCB7XG4gICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1zY29yZS1pbmNvcnJlY3QtcmVzdWx0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5sYWJlbCB7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgbWFyZ2luOiAycHggMDtcblxuICAgICAgICAvKiBhZGp1c3QgW25nYlBvcG92ZXJdIHdpbmRvdyBzdHlsZSAqL1xuICAgICAgICAmICsgbmdiLXBvcG92ZXItd2luZG93IHtcbiAgICAgICAgICAgIG1heC13aWR0aDogNTAwcHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKiBhZGp1c3QgW25nYlBvcG92ZXJdIHdpbmRvdyBzdHlsZSAqL1xuICAgIG5nYi1wb3BvdmVyLXdpbmRvdyB7XG4gICAgICAgIG1heC13aWR0aDogNTAwcHg7XG5cbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDk5MS45OHB4KSB7XG4gICAgICAgICAgICBtYXgtd2lkdGg6IDMwMHB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIH1cblxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNTc1Ljk4cHgpIHtcbiAgICAgICAgICAgIG1heC13aWR0aDogMjAwcHggIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQUEsQ0FBQTtBQUFBLENBQUE7O0FBR0ksQ0FISixZQUdJLENBQUE7QUFBQSxDQUhKLFdBR0ksQ0FBQTtBQUFBLENBSEosV0FHSSxDQUFBO0FBQ0ksU0FBQSxJQUFBO0FBQ0EsY0FBQSxJQUFBOztBQUdKLENBUkosWUFRSSxDQUFBO0FBQUEsQ0FSSixXQVFJLENBQUE7QUFBQSxDQVJKLFdBUUksQ0FBQTtBQUNJLGdCQUFBLElBQUE7O0FBRUEsQ0FYUixZQVdRLENBSEosT0FHSSxDQUFBO0FBQUEsQ0FYUixXQVdRLENBSEosT0FHSSxDQUFBO0FBQUEsQ0FYUixXQVdRLENBSEosT0FHSSxDQUFBO0FBQ0ksV0FBQTs7QUFHSixDQWZSLFlBZVEsQ0FQSixNQU9JLENBQUE7QUFBQSxDQWZSLFdBZVEsQ0FQSixNQU9JLENBQUE7QUFBQSxDQWZSLFdBZVEsQ0FQSixNQU9JLENBQUE7QUFDSSxnQkFBQSxJQUFBOztBQUlSLENBcEJKLGFBb0JJO0FBQUEsQ0FwQkosWUFvQkk7QUFBQSxDQXBCSixZQW9CSTtBQUNJLFVBQUEsRUFBQSxLQUFBLEVBQUE7O0FBRUEsQ0F2QlIsYUF1QlEsR0FBQTtBQUFBLENBdkJSLFlBdUJRLEdBQUE7QUFBQSxDQXZCUixZQXVCUSxHQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUlSLENBNUJKLGFBNEJJO0FBQUEsQ0E1QkosWUE0Qkk7QUFBQSxDQTVCSixZQTRCSTtBQUNJLFVBQUEsS0FBQTtBQUNBLGFBQUE7O0FBR0osQ0FqQ0osYUFpQ0ksQ0FBQTtBQUFBLENBakNKLFlBaUNJLENBQUE7QUFBQSxDQWpDSixZQWlDSSxDQUFBO0FBQ0ksYUFBQTs7QUFHSixDQXJDSixhQXFDSSxDQUFBO0FBQUEsQ0FyQ0osWUFxQ0ksQ0FBQTtBQUFBLENBckNKLFlBcUNJLENBQUE7QUFDSSxZQUFBO0FBQ0EsT0FBQTtBQUNBLFNBQUE7QUFDQSxhQUFBOztBQUVBLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFOSixHQXJDSixhQXFDSSxDQUFBO0VBQUEsQ0FyQ0osWUFxQ0ksQ0FBQTtFQUFBLENBckNKLFlBcUNJLENBQUE7QUFPUSxjQUFBO0FBQ0EsU0FBQTtBQUNBLFdBQUE7QUFDQSxlQUFBOzs7QUFHSixDQWxEUixhQWtEUSxDQWJKLGNBYUksQ0ExQ0o7QUEwQ0ksQ0FsRFIsWUFrRFEsQ0FiSixjQWFJLENBMUNKO0FBMENJLENBbERSLFlBa0RRLENBYkosY0FhSSxDQTFDSjtBQTJDUSxlQUFBO0FBQ0EsU0FBQSxJQUFBOztBQUVBLENBdERaLGFBc0RZLENBakJSLGNBaUJRLENBOUNSLE1BOENRLENBdkNKO0FBdUNJLENBdERaLFlBc0RZLENBakJSLGNBaUJRLENBOUNSLE1BOENRLENBdkNKO0FBdUNJLENBdERaLFlBc0RZLENBakJSLGNBaUJRLENBOUNSLE1BOENRLENBdkNKO0FBd0NRLFNBQUEsSUFBQTs7QUFLWixDQTVESixhQTRESSxDQUFBO0FBQUEsQ0E1REosWUE0REksQ0FBQTtBQUFBLENBNURKLFlBNERJLENBQUE7QUFDSSxVQUFBO0FBQ0EsVUFBQSxJQUFBOztBQUdBLENBakVSLGFBaUVRLENBTEosTUFLSSxFQUFBO0FBQUEsQ0FqRVIsWUFpRVEsQ0FMSixNQUtJLEVBQUE7QUFBQSxDQWpFUixZQWlFUSxDQUxKLE1BS0ksRUFBQTtBQUNJLGFBQUE7O0FBS1IsQ0F2RUosYUF1RUk7QUFBQSxDQXZFSixZQXVFSTtBQUFBLENBdkVKLFlBdUVJO0FBQ0ksYUFBQTs7QUFFQSxPQUFBLENBQUEsU0FBQSxFQUFBO0FBSEosR0F2RUosYUF1RUk7RUFBQSxDQXZFSixZQXVFSTtFQUFBLENBdkVKLFlBdUVJO0FBSVEsZUFBQTs7O0FBR0osT0FBQSxDQUFBLFNBQUEsRUFBQTtBQVBKLEdBdkVKLGFBdUVJO0VBQUEsQ0F2RUosWUF1RUk7RUFBQSxDQXZFSixZQXVFSTtBQVFRLGVBQUE7OzsiLAogICJuYW1lcyI6IFtdCn0K */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassDebugInfo(ShortAnswerQuestionComponent, { className: "ShortAnswerQuestionComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/quiz/shared/fit-text/fit-text.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i09 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var FitTextModule;
var init_fit_text_module = __esm({
  "src/main/webapp/app/exercises/quiz/shared/fit-text/fit-text.module.ts"() {
    init_fit_text_directive();
    FitTextModule = class _FitTextModule {
      static \u0275fac = function FitTextModule_Factory(t) {
        return new (t || _FitTextModule)();
      };
      static \u0275mod = i09.\u0275\u0275defineNgModule({ type: _FitTextModule });
      static \u0275inj = i09.\u0275\u0275defineInjector({});
    };
  }
});

// src/main/webapp/app/exercises/quiz/shared/questions/artemis-quiz-question-types.module.ts
import { NgModule as NgModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { DragDropModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_cdk_drag-drop.js?v=1d0d9ead";
import * as i010 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisQuizQuestionTypesModule;
var init_artemis_quiz_question_types_module = __esm({
  "src/main/webapp/app/exercises/quiz/shared/questions/artemis-quiz-question-types.module.ts"() {
    init_shared_module();
    init_drag_and_drop_question_component();
    init_multiple_choice_question_component();
    init_short_answer_question_component();
    init_drag_item_component();
    init_quiz_scoring_info_student_modal_component();
    init_markdown_module();
    init_fit_text_module();
    init_multiple_choice_visual_question_component();
    ArtemisQuizQuestionTypesModule = class _ArtemisQuizQuestionTypesModule {
      static \u0275fac = function ArtemisQuizQuestionTypesModule_Factory(t) {
        return new (t || _ArtemisQuizQuestionTypesModule)();
      };
      static \u0275mod = i010.\u0275\u0275defineNgModule({ type: _ArtemisQuizQuestionTypesModule });
      static \u0275inj = i010.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, DragDropModule, ArtemisMarkdownModule, FitTextModule] });
    };
  }
});

// src/main/webapp/app/entities/quiz/submitted-answer.model.ts
var SubmittedAnswer;
var init_submitted_answer_model = __esm({
  "src/main/webapp/app/entities/quiz/submitted-answer.model.ts"() {
    SubmittedAnswer = class {
      id;
      scoreInPoints;
      quizQuestion;
      submission;
      type;
      constructor(type) {
        this.type = type;
      }
    };
  }
});

// src/main/webapp/app/entities/quiz/multiple-choice-submitted-answer.model.ts
var MultipleChoiceSubmittedAnswer;
var init_multiple_choice_submitted_answer_model = __esm({
  "src/main/webapp/app/entities/quiz/multiple-choice-submitted-answer.model.ts"() {
    init_submitted_answer_model();
    init_quiz_question_model();
    MultipleChoiceSubmittedAnswer = class extends SubmittedAnswer {
      selectedOptions;
      constructor() {
        super(QuizQuestionType.MULTIPLE_CHOICE);
      }
    };
  }
});

// src/main/webapp/app/entities/quiz/drag-and-drop-submitted-answer.model.ts
var DragAndDropSubmittedAnswer;
var init_drag_and_drop_submitted_answer_model = __esm({
  "src/main/webapp/app/entities/quiz/drag-and-drop-submitted-answer.model.ts"() {
    init_submitted_answer_model();
    init_quiz_question_model();
    DragAndDropSubmittedAnswer = class extends SubmittedAnswer {
      mappings;
      constructor() {
        super(QuizQuestionType.DRAG_AND_DROP);
      }
    };
  }
});

// src/main/webapp/app/entities/quiz/short-answer-submitted-answer.model.ts
var ShortAnswerSubmittedAnswer;
var init_short_answer_submitted_answer_model = __esm({
  "src/main/webapp/app/entities/quiz/short-answer-submitted-answer.model.ts"() {
    init_submitted_answer_model();
    init_quiz_question_model();
    ShortAnswerSubmittedAnswer = class extends SubmittedAnswer {
      submittedTexts;
      constructor() {
        super(QuizQuestionType.SHORT_ANSWER);
      }
    };
  }
});

// src/main/webapp/app/entities/quiz/abstract-quiz-exam-submission.model.ts
var AbstractQuizSubmission;
var init_abstract_quiz_exam_submission_model = __esm({
  "src/main/webapp/app/entities/quiz/abstract-quiz-exam-submission.model.ts"() {
    init_submission_model();
    AbstractQuizSubmission = class extends Submission {
      scoreInPoints;
      submittedAnswers;
      constructor(type) {
        super(type);
      }
    };
  }
});

// src/main/webapp/app/entities/quiz/quiz-submission.model.ts
var QuizSubmission;
var init_quiz_submission_model = __esm({
  "src/main/webapp/app/entities/quiz/quiz-submission.model.ts"() {
    init_abstract_quiz_exam_submission_model();
    QuizSubmission = class extends AbstractQuizSubmission {
      constructor() {
        super("quiz");
      }
    };
  }
});

export {
  DragAndDropQuestionUtil,
  init_drag_and_drop_question_util_service,
  ShortAnswerQuestionUtil,
  init_short_answer_question_util_service,
  DragAndDropMapping,
  init_drag_and_drop_mapping_model,
  BaseEntityWithTempId,
  DropLocation,
  init_drop_location_model,
  DragItem,
  init_drag_item_model,
  MultipleChoiceQuestionComponent,
  init_multiple_choice_question_component,
  DragItemComponent,
  init_drag_item_component,
  DragAndDropQuestionComponent,
  init_drag_and_drop_question_component,
  ShortAnswerQuestionComponent,
  init_short_answer_question_component,
  MultipleChoiceSubmittedAnswer,
  init_multiple_choice_submitted_answer_model,
  DragAndDropSubmittedAnswer,
  init_drag_and_drop_submitted_answer_model,
  ShortAnswerSubmittedAnswer,
  init_short_answer_submitted_answer_model,
  init_abstract_quiz_exam_submission_model,
  QuizSubmission,
  init_quiz_submission_model,
  FitTextModule,
  init_fit_text_module,
  ArtemisQuizQuestionTypesModule,
  init_artemis_quiz_question_types_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3F1aXovc2hhcmVkL2RyYWctYW5kLWRyb3AtcXVlc3Rpb24tdXRpbC5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9xdWl6L2RyYWctYW5kLWRyb3AtbWFwcGluZy5tb2RlbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3F1aXovbWFuYWdlL3RlbXAtaWQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2VudGl0aWVzL3F1aXovZHJvcC1sb2NhdGlvbi5tb2RlbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvcXVpei9kcmFnLWl0ZW0ubW9kZWwudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9xdWl6L3NoYXJlZC9maXQtdGV4dC9maXQtdGV4dC5kaXJlY3RpdmUudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9xdWl6L3NoYXJlZC9xdWVzdGlvbnMvZHJhZy1hbmQtZHJvcC1xdWVzdGlvbi9kcmFnLWl0ZW0uY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL2RyYWctYW5kLWRyb3AtcXVlc3Rpb24vZHJhZy1pdGVtLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL3F1aXotc2NvcmluZy1pbmZvc3R1ZGVudC1tb2RhbC9xdWl6LXNjb3JpbmctaW5mby1zdHVkZW50LW1vZGFsLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3F1aXovc2hhcmVkL3F1ZXN0aW9ucy9xdWl6LXNjb3JpbmctaW5mb3N0dWRlbnQtbW9kYWwvcXVpei1zY29yaW5nLWluZm8tc3R1ZGVudC1tb2RhbC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3F1aXovc2hhcmVkL3F1ZXN0aW9ucy9kcmFnLWFuZC1kcm9wLXF1ZXN0aW9uL2RyYWctYW5kLWRyb3AtcXVlc3Rpb24uY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL2RyYWctYW5kLWRyb3AtcXVlc3Rpb24vZHJhZy1hbmQtZHJvcC1xdWVzdGlvbi5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3F1aXovc2hhcmVkL3F1ZXN0aW9ucy9tdWx0aXBsZS1jaG9pY2UtcXVlc3Rpb24vbXVsdGlwbGUtY2hvaWNlLXF1ZXN0aW9uLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3F1aXovc2hhcmVkL3F1ZXN0aW9ucy9tdWx0aXBsZS1jaG9pY2UtcXVlc3Rpb24vbXVsdGlwbGUtY2hvaWNlLXF1ZXN0aW9uLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvc2hvcnQtYW5zd2VyLXF1ZXN0aW9uLXV0aWwuc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvcXVpei9zaG9ydC1hbnN3ZXItc3VibWl0dGVkLXRleHQubW9kZWwudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9xdWl6L3NoYXJlZC9xdWVzdGlvbnMvc2hvcnQtYW5zd2VyLXF1ZXN0aW9uL3Nob3J0LWFuc3dlci1xdWVzdGlvbi5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9xdWl6L3NoYXJlZC9xdWVzdGlvbnMvc2hvcnQtYW5zd2VyLXF1ZXN0aW9uL3Nob3J0LWFuc3dlci1xdWVzdGlvbi5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3F1aXovc2hhcmVkL2ZpdC10ZXh0L2ZpdC10ZXh0Lm1vZHVsZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3F1aXovc2hhcmVkL3F1ZXN0aW9ucy9hcnRlbWlzLXF1aXotcXVlc3Rpb24tdHlwZXMubW9kdWxlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9xdWl6L3N1Ym1pdHRlZC1hbnN3ZXIubW9kZWwudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2VudGl0aWVzL3F1aXovbXVsdGlwbGUtY2hvaWNlLXN1Ym1pdHRlZC1hbnN3ZXIubW9kZWwudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2VudGl0aWVzL3F1aXovZHJhZy1hbmQtZHJvcC1zdWJtaXR0ZWQtYW5zd2VyLm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9xdWl6L3Nob3J0LWFuc3dlci1zdWJtaXR0ZWQtYW5zd2VyLm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9xdWl6L2Fic3RyYWN0LXF1aXotZXhhbS1zdWJtaXNzaW9uLm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9xdWl6L3F1aXotc3VibWlzc2lvbi5tb2RlbC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEcmFnQW5kRHJvcE1hcHBpbmcgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9kcmFnLWFuZC1kcm9wLW1hcHBpbmcubW9kZWwnO1xuaW1wb3J0IHsgRHJhZ0FuZERyb3BRdWVzdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L2RyYWctYW5kLWRyb3AtcXVlc3Rpb24ubW9kZWwnO1xuaW1wb3J0IHsgRHJhZ0l0ZW0gfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9kcmFnLWl0ZW0ubW9kZWwnO1xuaW1wb3J0IHsgQmFzZUVudGl0eVdpdGhUZW1wSWQsIERyb3BMb2NhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L2Ryb3AtbG9jYXRpb24ubW9kZWwnO1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIERyYWdBbmREcm9wUXVlc3Rpb25VdGlsIHtcbiAgICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgYSBzYW1wbGUgc29sdXRpb24gZm9yIHRoZSBnaXZlbiBkcmFnIGFuZCBkcm9wIHF1ZXN0aW9uXG4gICAgICpcbiAgICAgKiBAcGFyYW0gcXVlc3Rpb24ge29iamVjdH0gdGhlIGRyYWcgYW5kIGRyb3AgcXVlc3Rpb24gd2Ugd2FudCB0byBzb2x2ZVxuICAgICAqIEBwYXJhbSBbbWFwcGluZ3NdIHtBcnJheX0gKG9wdGlvbmFsKSB0aGUgbWFwcGluZ3Mgd2UgdHJ5IHRvIHVzZSBpbiB0aGUgc2FtcGxlIHNvbHV0aW9uICh0aGlzIG1heSBjb250YWluIGluY29ycmVjdCBtYXBwaW5ncyAtIHRoZXkgd2lsbCBiZSBmaWx0ZXJlZCBvdXQpXG4gICAgICogQHJldHVybiB7QXJyYXl9IGFycmF5IG9mIG1hcHBpbmdzIHRoYXQgd291bGQgc29sdmUgdGhpcyBxdWVzdGlvbiAoY2FuIGJlIGVtcHR5LCBpZiBxdWVzdGlvbiBpcyB1bnNvbHZhYmxlKVxuICAgICAqL1xuICAgIHNvbHZlKHF1ZXN0aW9uOiBEcmFnQW5kRHJvcFF1ZXN0aW9uLCBtYXBwaW5ncz86IERyYWdBbmREcm9wTWFwcGluZ1tdKSB7XG4gICAgICAgIGlmICghcXVlc3Rpb24uY29ycmVjdE1hcHBpbmdzKSB7XG4gICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBzYW1wbGVNYXBwaW5ncyA9IG5ldyBBcnJheTxEcmFnQW5kRHJvcE1hcHBpbmc+KCk7XG4gICAgICAgIGxldCBhdmFpbGFibGVEcmFnSXRlbXMgPSBxdWVzdGlvbi5kcmFnSXRlbXM7XG5cbiAgICAgICAgLy8gZmlsdGVyIG91dCBkcm9wTG9jYXRpb25zIHRoYXQgZG8gbm90IG5lZWQgdG8gYmUgbWFwcGVkXG4gICAgICAgIGxldCByZW1haW5pbmdEcm9wTG9jYXRpb25zID0gcXVlc3Rpb24uZHJvcExvY2F0aW9ucz8uZmlsdGVyKChkcm9wTG9jYXRpb24pID0+IHtcbiAgICAgICAgICAgIHJldHVybiBxdWVzdGlvbi5jb3JyZWN0TWFwcGluZ3M/LnNvbWUoKG1hcHBpbmcpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5pc1NhbWVFbnRpdHlXaXRoVGVtcElkKG1hcHBpbmcuZHJvcExvY2F0aW9uLCBkcm9wTG9jYXRpb24pO1xuICAgICAgICAgICAgfSwgdGhpcyk7XG4gICAgICAgIH0sIHRoaXMpO1xuXG4gICAgICAgIGlmIChtYXBwaW5ncykge1xuICAgICAgICAgICAgLy8gYWRkIG1hcHBpbmdzIHRoYXQgYXJlIGFscmVhZHkgY29ycmVjdFxuICAgICAgICAgICAgbWFwcGluZ3MuZm9yRWFjaChmdW5jdGlvbiAobWFwcGluZykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvcnJlY3RNYXBwaW5nID0gdGhpcy5nZXRNYXBwaW5nKHF1ZXN0aW9uLmNvcnJlY3RNYXBwaW5ncyEsIG1hcHBpbmcuZHJhZ0l0ZW0hLCBtYXBwaW5nLmRyb3BMb2NhdGlvbiEpO1xuICAgICAgICAgICAgICAgIGlmIChjb3JyZWN0TWFwcGluZykge1xuICAgICAgICAgICAgICAgICAgICBzYW1wbGVNYXBwaW5ncy5wdXNoKGNvcnJlY3RNYXBwaW5nKTtcbiAgICAgICAgICAgICAgICAgICAgcmVtYWluaW5nRHJvcExvY2F0aW9ucyA9IHJlbWFpbmluZ0Ryb3BMb2NhdGlvbnM/LmZpbHRlcihmdW5jdGlvbiAoZHJvcExvY2F0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gIXRoaXMuaXNTYW1lRW50aXR5V2l0aFRlbXBJZChkcm9wTG9jYXRpb24sIG1hcHBpbmcuZHJvcExvY2F0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgfSwgdGhpcyk7XG4gICAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZURyYWdJdGVtcyA9IGF2YWlsYWJsZURyYWdJdGVtcz8uZmlsdGVyKGZ1bmN0aW9uIChkcmFnSXRlbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICF0aGlzLmlzU2FtZUVudGl0eVdpdGhUZW1wSWQoZHJhZ0l0ZW0sIG1hcHBpbmcuZHJhZ0l0ZW0pO1xuICAgICAgICAgICAgICAgICAgICB9LCB0aGlzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCB0aGlzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHNvbHZlIHJlY3Vyc2l2ZWx5XG4gICAgICAgIGNvbnN0IHNvbHZlZCA9IHRoaXMuc29sdmVSZWMocXVlc3Rpb24uY29ycmVjdE1hcHBpbmdzLCByZW1haW5pbmdEcm9wTG9jYXRpb25zLCBhdmFpbGFibGVEcmFnSXRlbXMsIHNhbXBsZU1hcHBpbmdzKTtcblxuICAgICAgICBpZiAoc29sdmVkKSB7XG4gICAgICAgICAgICByZXR1cm4gc2FtcGxlTWFwcGluZ3M7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUcnkgdG8gc29sdmUgYSBkcmFnIGFuZCBkcm9wIHF1ZXN0aW9uIHJlY3Vyc2l2ZWx5XG4gICAgICpcbiAgICAgKiBAcGFyYW0gY29ycmVjdE1hcHBpbmdzIHtBcnJheX0gdGhlIGNvcnJlY3QgbWFwcGluZ3MgZGVmaW5lZCBieSB0aGUgY3JlYXRvciBvZiB0aGUgcXVlc3Rpb25cbiAgICAgKiBAcGFyYW0gcmVtYWluaW5nRHJvcExvY2F0aW9ucyB7QXJyYXl9IHRoZSBkcm9wIGxvY2F0aW9ucyB0aGF0IHN0aWxsIG5lZWQgdG8gYmUgbWFwcGVkIChyZWN1cnNpb24gc3RvcHMgaWYgdGhpcyBpcyBlbXB0eSlcbiAgICAgKiBAcGFyYW0gYXZhaWxhYmxlRHJhZ0l0ZW1zIHtBcnJheX0gdGhlIHVudXNlZCBkcmFnIGl0ZW1zIHRoYXQgY2FuIHN0aWxsIGJlIHVzZWQgdG8gbWFwIHRvIGRyb3AgbG9jYXRpb25zIChyZWN1cnNpb24gc3RvcHMgaWYgdGhpcyBpcyBlbXB0eSlcbiAgICAgKiBAcGFyYW0gc2FtcGxlTWFwcGluZ3Mge0FycmF5fSB0aGUgbWFwcGluZ3Mgc28gZmFyXG4gICAgICogQHJldHVybiB7Ym9vbGVhbn0gdHJ1ZSwgaWYgdGhlIHF1ZXN0aW9uIHdhcyBzb2x2ZWQgKHNvbHV0aW9uIGlzIHNhdmVkIGluIHNhbXBsZU1hcHBpbmdzKSwgb3RoZXJ3aXNlIGZhbHNlXG4gICAgICovXG4gICAgc29sdmVSZWMoXG4gICAgICAgIGNvcnJlY3RNYXBwaW5nczogRHJhZ0FuZERyb3BNYXBwaW5nW10sXG4gICAgICAgIHJlbWFpbmluZ0Ryb3BMb2NhdGlvbnM6IERyb3BMb2NhdGlvbltdIHwgdW5kZWZpbmVkLFxuICAgICAgICBhdmFpbGFibGVEcmFnSXRlbXM6IERyYWdJdGVtW10gfCB1bmRlZmluZWQsXG4gICAgICAgIHNhbXBsZU1hcHBpbmdzOiBEcmFnQW5kRHJvcE1hcHBpbmdbXSxcbiAgICApIHtcbiAgICAgICAgaWYgKCFyZW1haW5pbmdEcm9wTG9jYXRpb25zIHx8IHJlbWFpbmluZ0Ryb3BMb2NhdGlvbnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRyb3BMb2NhdGlvbiA9IHJlbWFpbmluZ0Ryb3BMb2NhdGlvbnNbMF07XG4gICAgICAgIHJldHVybiBhdmFpbGFibGVEcmFnSXRlbXM/LnNvbWUoZnVuY3Rpb24gKGRyYWdJdGVtLCBpbmRleCkge1xuICAgICAgICAgICAgY29uc3QgY29ycmVjdE1hcHBpbmcgPSB0aGlzLmdldE1hcHBpbmcoY29ycmVjdE1hcHBpbmdzLCBkcmFnSXRlbSwgZHJvcExvY2F0aW9uKTtcbiAgICAgICAgICAgIGlmIChjb3JyZWN0TWFwcGluZykge1xuICAgICAgICAgICAgICAgIHNhbXBsZU1hcHBpbmdzLnB1c2goY29ycmVjdE1hcHBpbmcpOyAvLyBhZGQgbmV3IG1hcHBpbmdcbiAgICAgICAgICAgICAgICByZW1haW5pbmdEcm9wTG9jYXRpb25zLnNwbGljZSgwLCAxKTsgLy8gcmVtb3ZlIGZpcnN0IGRyb3BMb2NhdGlvblxuICAgICAgICAgICAgICAgIGF2YWlsYWJsZURyYWdJdGVtcy5zcGxpY2UoaW5kZXgsIDEpOyAvLyByZW1vdmUgdGhlIHVzZWQgZHJhZ0l0ZW1cbiAgICAgICAgICAgICAgICBjb25zdCBzb2x2ZWQgPSB0aGlzLnNvbHZlUmVjKGNvcnJlY3RNYXBwaW5ncywgcmVtYWluaW5nRHJvcExvY2F0aW9ucywgYXZhaWxhYmxlRHJhZ0l0ZW1zLCBzYW1wbGVNYXBwaW5ncyk7XG4gICAgICAgICAgICAgICAgcmVtYWluaW5nRHJvcExvY2F0aW9ucy5zcGxpY2UoMCwgMCwgZHJvcExvY2F0aW9uKTsgLy8gcmUtaW5zZXJ0IGZpcnN0IGRyb3BMb2NhdGlvblxuICAgICAgICAgICAgICAgIGF2YWlsYWJsZURyYWdJdGVtcy5zcGxpY2UoaW5kZXgsIDAsIGRyYWdJdGVtKTsgLy8gcmUtaW5zZXJ0IHRoZSB1c2VkIGRyYWdJdGVtXG4gICAgICAgICAgICAgICAgaWYgKCFzb2x2ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgc2FtcGxlTWFwcGluZ3MucG9wKCk7IC8vIHJlbW92ZSBuZXcgbWFwcGluZyAob25seSBpZiBzb2x1dGlvbiB3YXMgbm90IGZvdW5kKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gc29sdmVkO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIHRoaXMpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFZhbGlkYXRlIHRoYXQgYWxsIGNvcnJlY3QgbWFwcGluZ3MgKGFuZCBhbnkgY29tYmluYXRpb24gb2YgdGhlbSB0aGF0IGRvZXNuJ3QgdXNlIGEgZHJvcExvY2F0aW9uIG9yIGRyYWdJdGVtIHR3aWNlKVxuICAgICAqIGNhbiBiZSB1c2VkIGluIGEgMTAwJSBjb3JyZWN0IHNvbHV0aW9uLlxuICAgICAqIFRoaXMgbWVhbnMgdGhhdCBpZiBhbnkgcGFpciBvZiBkcmFnSXRlbXMgc2hhcmUgYSBwb3NzaWJsZSBkcm9wTG9jYXRpb24sIHRoZW4gdGhleSBtdXN0IHNoYXJlIGFsbCBkcm9wTG9jYXRpb25zLFxuICAgICAqIG9yIGluIG90aGVyIHdvcmRzIHRoZSBzZXRzIG9mIHBvc3NpYmxlIGRyb3BMb2NhdGlvbnMgZm9yIHRoZXNlIHR3byBkcmFnSXRlbXMgbXVzdCBiZSBpZGVudGljYWxcbiAgICAgKlxuICAgICAqIEBwYXJhbSBxdWVzdGlvbiB7b2JqZWN0fSB0aGUgcXVlc3Rpb24gdG8gY2hlY2tcbiAgICAgKiBAcmV0dXJuIHtib29sZWFufSB0cnVlLCBpZiB0aGUgY29uZGl0aW9uIGlzIG1ldCwgb3RoZXJ3aXNlIGZhbHNlXG4gICAgICovXG4gICAgdmFsaWRhdGVOb01pc2xlYWRpbmdDb3JyZWN0TWFwcGluZyhxdWVzdGlvbjogRHJhZ0FuZERyb3BRdWVzdGlvbikge1xuICAgICAgICBpZiAoIXF1ZXN0aW9uLmNvcnJlY3RNYXBwaW5ncyB8fCAhcXVlc3Rpb24uZHJhZ0l0ZW1zKSB7XG4gICAgICAgICAgICAvLyBubyBjb3JyZWN0IG1hcHBpbmdzIGF0IGFsbCBtZWFucyB0aGVyZSBjYW4gYmUgbm8gbWlzbGVhZGluZyBtYXBwaW5nc1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgLy8gaXRlcmF0ZSB0aHJvdWdoIGFsbCBwYWlycyBvZiBkcmFnIGl0ZW1zXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcXVlc3Rpb24uZHJhZ0l0ZW1zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGk7IGorKykge1xuICAgICAgICAgICAgICAgIC8vIGlmIHRoZXNlIHR3byBkcmFnIGl0ZW1zIGhhdmUgb25lIGNvbW1vbiBkcm9wIGxvY2F0aW9uLCB0aGV5IG11c3Qgc2hhcmUgYWxsIGRyb3AgbG9jYXRpb25zXG4gICAgICAgICAgICAgICAgY29uc3QgZHJhZ0l0ZW0xID0gcXVlc3Rpb24uZHJhZ0l0ZW1zW2ldO1xuICAgICAgICAgICAgICAgIGNvbnN0IGRyYWdJdGVtMiA9IHF1ZXN0aW9uLmRyYWdJdGVtc1tqXTtcbiAgICAgICAgICAgICAgICBjb25zdCBzaGFyZU9uZURyb3BMb2NhdGlvbiA9IHF1ZXN0aW9uLmRyb3BMb2NhdGlvbnM/LnNvbWUoZnVuY3Rpb24gKGRyb3BMb2NhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc01hcHBlZFdpdGhEcmFnSXRlbTEgPSB0aGlzLmlzTWFwcGVkVG9nZXRoZXIocXVlc3Rpb24uY29ycmVjdE1hcHBpbmdzLCBkcmFnSXRlbTEsIGRyb3BMb2NhdGlvbik7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzTWFwcGVkV2l0aERyYWdJdGVtMiA9IHRoaXMuaXNNYXBwZWRUb2dldGhlcihxdWVzdGlvbi5jb3JyZWN0TWFwcGluZ3MsIGRyYWdJdGVtMiwgZHJvcExvY2F0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGlzTWFwcGVkV2l0aERyYWdJdGVtMSAmJiBpc01hcHBlZFdpdGhEcmFnSXRlbTI7XG4gICAgICAgICAgICAgICAgfSwgdGhpcyk7XG4gICAgICAgICAgICAgICAgaWYgKHNoYXJlT25lRHJvcExvY2F0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGFsbERyb3BMb2NhdGlvbnNGb3JEcmFnSXRlbTEgPSB0aGlzLmdldEFsbERyb3BMb2NhdGlvbnNGb3JEcmFnSXRlbShxdWVzdGlvbi5jb3JyZWN0TWFwcGluZ3MsIGRyYWdJdGVtMSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGFsbERyb3BMb2NhdGlvbnNGb3JEcmFnSXRlbTIgPSB0aGlzLmdldEFsbERyb3BMb2NhdGlvbnNGb3JEcmFnSXRlbShxdWVzdGlvbi5jb3JyZWN0TWFwcGluZ3MsIGRyYWdJdGVtMik7XG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5pc1NhbWVTZXRPZkRyb3BMb2NhdGlvbnMoYWxsRHJvcExvY2F0aW9uc0ZvckRyYWdJdGVtMSwgYWxsRHJvcExvY2F0aW9uc0ZvckRyYWdJdGVtMikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbmRpdGlvbiBpcyB2aW9sYXRlZCBmb3IgdGhpcyBwYWlyIG9mIGRyYWdJdGVtc1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIGNvbmRpdGlvbiB3YXMgbWV0IGZvciBhbGwgcGFpcnMgb2YgZHJhZyBpdGVtc1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiB0aGUgZ2l2ZW4gZHJhZ0l0ZW0gYW5kIGRyb3BMb2NhdGlvbiBhcmUgbWFwcGVkIHRvZ2V0aGVyIGluIHRoZSBnaXZlbiBtYXBwaW5nc1xuICAgICAqXG4gICAgICogQHBhcmFtIG1hcHBpbmdzIHtBcnJheX0gdGhlIGV4aXN0aW5nIG1hcHBpbmdzIHRvIGNvbnNpZGVyXG4gICAgICogQHBhcmFtIGRyYWdJdGVtIHtvYmplY3R9IHRoZSBkcmFnIGl0ZW0gdG8gc2VhcmNoIGZvclxuICAgICAqIEBwYXJhbSBkcm9wTG9jYXRpb24ge29iamVjdH0gdGhlIGRyb3AgbG9jYXRpb24gdG8gc2VhcmNoIGZvclxuICAgICAqIEByZXR1cm4ge2Jvb2xlYW59IHRydWUgaWYgdGhleSBhcmUgbWFwcGVkIHRvZ2V0aGVyLCBvdGhlcndpc2UgZmFsc2VcbiAgICAgKi9cbiAgICBpc01hcHBlZFRvZ2V0aGVyKG1hcHBpbmdzOiBEcmFnQW5kRHJvcE1hcHBpbmdbXSwgZHJhZ0l0ZW06IERyYWdJdGVtLCBkcm9wTG9jYXRpb246IERyb3BMb2NhdGlvbikge1xuICAgICAgICByZXR1cm4gISF0aGlzLmdldE1hcHBpbmcobWFwcGluZ3MsIGRyYWdJdGVtLCBkcm9wTG9jYXRpb24pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCB0aGUgbWFwcGluZyB0aGF0IG1hcHMgdGhlIGdpdmVuIGRyYWdJdGVtIGFuZCBkcm9wTG9jYXRpb24gdG9nZXRoZXJcbiAgICAgKlxuICAgICAqIEBwYXJhbSBtYXBwaW5ncyB7QXJyYXl9IHRoZSBleGlzdGluZyBtYXBwaW5ncyB0byBjb25zaWRlclxuICAgICAqIEBwYXJhbSBkcmFnSXRlbSB7b2JqZWN0fSB0aGUgZHJhZyBpdGVtIHRvIHNlYXJjaCBmb3JcbiAgICAgKiBAcGFyYW0gZHJvcExvY2F0aW9uIHtvYmplY3R9IHRoZSBkcm9wIGxvY2F0aW9uIHRvIHNlYXJjaCBmb3JcbiAgICAgKiBAcmV0dXJuIHtvYmplY3QgfCBudWxsfSB0aGUgZm91bmQgbWFwcGluZywgb3IgbnVsbCBpZiBpdCBkb2Vzbid0IGV4aXN0XG4gICAgICovXG4gICAgZ2V0TWFwcGluZyhtYXBwaW5nczogRHJhZ0FuZERyb3BNYXBwaW5nW10sIGRyYWdJdGVtOiBEcmFnSXRlbSwgZHJvcExvY2F0aW9uOiBEcm9wTG9jYXRpb24pIHtcbiAgICAgICAgcmV0dXJuIG1hcHBpbmdzLmZpbmQoKG1hcHBpbmc6IERyYWdBbmREcm9wTWFwcGluZykgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuaXNTYW1lRW50aXR5V2l0aFRlbXBJZChkcm9wTG9jYXRpb24sIG1hcHBpbmcuZHJvcExvY2F0aW9uKSAmJiB0aGlzLmlzU2FtZUVudGl0eVdpdGhUZW1wSWQoZHJhZ0l0ZW0sIG1hcHBpbmcuZHJhZ0l0ZW0pO1xuICAgICAgICB9LCB0aGlzKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgYWxsIGRyb3AgbG9jYXRpb25zIHRoYXQgYXJlIG1hcHBlZCB0byB0aGUgZ2l2ZW4gZHJhZyBpdGVtc1xuICAgICAqXG4gICAgICogQHBhcmFtIG1hcHBpbmdzIHtBcnJheX0gdGhlIGV4aXN0aW5nIG1hcHBpbmdzIHRvIGNvbnNpZGVyXG4gICAgICogQHBhcmFtIGRyYWdJdGVtIHtvYmplY3R9IHRoZSBkcmFnIGl0ZW0gdGhhdCB0aGUgcmV0dXJuZWQgZHJvcCBsb2NhdGlvbnMgaGF2ZSB0byBiZSBtYXBwZWQgdG9cbiAgICAgKiBAcmV0dXJuIHtBcnJheX0gdGhlIHJlc3VsdGluZyBkcm9wIGxvY2F0aW9uc1xuICAgICAqL1xuICAgIGdldEFsbERyb3BMb2NhdGlvbnNGb3JEcmFnSXRlbShtYXBwaW5nczogRHJhZ0FuZERyb3BNYXBwaW5nW10sIGRyYWdJdGVtOiBEcmFnSXRlbSk6IERyb3BMb2NhdGlvbltdIHtcbiAgICAgICAgcmV0dXJuIG1hcHBpbmdzLmZpbHRlcigobWFwcGluZykgPT4gdGhpcy5pc1NhbWVFbnRpdHlXaXRoVGVtcElkKG1hcHBpbmcuZHJhZ0l0ZW0sIGRyYWdJdGVtKSkubWFwKChtYXBwaW5nKSA9PiBtYXBwaW5nLmRyb3BMb2NhdGlvbiEpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIHNldDEgYW5kIHNldDIgY29udGFpbiB0aGUgc2FtZSBkcmFnIGl0ZW1zIG9yIGRyb3AgbG9jYXRpb25zXG4gICAgICpcbiAgICAgKiBAcGFyYW0gc2V0MSB7QXJyYXl9IG9uZSBzZXQgb2YgZHJhZyBpdGVtcyBvciBkcm9wIGxvY2F0aW9uc1xuICAgICAqIEBwYXJhbSBzZXQyIHtBcnJheX0gYW5vdGhlciBzZXQgb2YgZHJhZyBpdGVtcyBvciBkcm9wIGxvY2F0aW9uc1xuICAgICAqIEByZXR1cm4ge2Jvb2xlYW59IHRydWUgaWYgdGhlIHNldHMgY29udGFpbiB0aGUgc2FtZSBpdGVtcywgb3RoZXJ3aXNlIGZhbHNlXG4gICAgICovXG4gICAgaXNTYW1lU2V0T2ZEcm9wTG9jYXRpb25zKHNldDE6IERyb3BMb2NhdGlvbltdLCBzZXQyOiBEcm9wTG9jYXRpb25bXSk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAoc2V0MS5sZW5ndGggIT09IHNldDIubGVuZ3RoKSB7XG4gICAgICAgICAgICAvLyBkaWZmZXJlbnQgbnVtYmVyIG9mIGVsZW1lbnRzID0+IGltcG9zc2libGUgdG8gY29udGFpbiB0aGUgc2FtZSBlbGVtZW50c1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAvLyBmb3IgZXZlcnkgZWxlbWVudCBpbiBzZXQxIHRoZXJlIGhhcyB0byBiZSBhbiBpZGVudGljYWwgZWxlbWVudCBpbiBzZXQyIGFuZCB2aWNlIHZlcnNhXG4gICAgICAgICAgICBzZXQxLmV2ZXJ5KChlbGVtZW50MTogRHJvcExvY2F0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHNldDIuc29tZSgoZWxlbWVudDI6IERyb3BMb2NhdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5pc1NhbWVFbnRpdHlXaXRoVGVtcElkKGVsZW1lbnQxLCBlbGVtZW50Mik7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KSAmJlxuICAgICAgICAgICAgc2V0Mi5ldmVyeSgoZWxlbWVudDI6IERyb3BMb2NhdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiBzZXQxLnNvbWUoKGVsZW1lbnQxOiBEcm9wTG9jYXRpb24pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuaXNTYW1lRW50aXR5V2l0aFRlbXBJZChlbGVtZW50MSwgZWxlbWVudDIpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjb21wYXJlIGlmIHRoZSB0d28gb2JqZWN0cyBhcmUgdGhlIHNhbWUgZW50aXRpZXMgd2l0aCBhIHRlbXAgaWRcbiAgICAgKlxuICAgICAqIEBwYXJhbSBhIHtvYmplY3R9IGFuIGVudGl0eSB3aXRoIGEgdGVtcCBpZFxuICAgICAqIEBwYXJhbSBiIHtvYmplY3R9IGFub3RoZXIgZW50aXR5IHdpdGggYSB0ZW1wIGlkXG4gICAgICogQHJldHVybiB7Ym9vbGVhbn1cbiAgICAgKi9cbiAgICBpc1NhbWVFbnRpdHlXaXRoVGVtcElkKGE6IEJhc2VFbnRpdHlXaXRoVGVtcElkIHwgdW5kZWZpbmVkLCBiOiBCYXNlRW50aXR5V2l0aFRlbXBJZCB8IHVuZGVmaW5lZCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gYSA9PT0gYiB8fCAoYSAhPSB1bmRlZmluZWQgJiYgYiAhPSB1bmRlZmluZWQgJiYgKChhLmlkICYmIGIuaWQgJiYgYS5pZCA9PT0gYi5pZCkgfHwgKGEudGVtcElEICE9IHVuZGVmaW5lZCAmJiBiLnRlbXBJRCAhPSB1bmRlZmluZWQgJiYgYS50ZW1wSUQgPT09IGIudGVtcElEKSkpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEJhc2VFbnRpdHkgfSBmcm9tICdhcHAvc2hhcmVkL21vZGVsL2Jhc2UtZW50aXR5JztcbmltcG9ydCB7IERyYWdBbmREcm9wU3VibWl0dGVkQW5zd2VyIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovZHJhZy1hbmQtZHJvcC1zdWJtaXR0ZWQtYW5zd2VyLm1vZGVsJztcbmltcG9ydCB7IERyYWdBbmREcm9wUXVlc3Rpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9kcmFnLWFuZC1kcm9wLXF1ZXN0aW9uLm1vZGVsJztcbmltcG9ydCB7IERyYWdJdGVtIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovZHJhZy1pdGVtLm1vZGVsJztcbmltcG9ydCB7IENhbkJlY29tZUludmFsaWQsIERyb3BMb2NhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L2Ryb3AtbG9jYXRpb24ubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgRHJhZ0FuZERyb3BNYXBwaW5nIGltcGxlbWVudHMgQmFzZUVudGl0eSwgQ2FuQmVjb21lSW52YWxpZCB7XG4gICAgcHVibGljIGlkPzogbnVtYmVyO1xuICAgIHB1YmxpYyBkcmFnSXRlbUluZGV4PzogbnVtYmVyO1xuICAgIHB1YmxpYyBkcm9wTG9jYXRpb25JbmRleD86IG51bWJlcjtcbiAgICBwdWJsaWMgaW52YWxpZCA9IGZhbHNlO1xuICAgIHB1YmxpYyBzdWJtaXR0ZWRBbnN3ZXI/OiBEcmFnQW5kRHJvcFN1Ym1pdHRlZEFuc3dlcjtcbiAgICBwdWJsaWMgcXVlc3Rpb24/OiBEcmFnQW5kRHJvcFF1ZXN0aW9uO1xuICAgIHB1YmxpYyBkcmFnSXRlbT86IERyYWdJdGVtO1xuICAgIHB1YmxpYyBkcm9wTG9jYXRpb24/OiBEcm9wTG9jYXRpb247XG5cbiAgICBjb25zdHJ1Y3RvcihkcmFnSXRlbTogRHJhZ0l0ZW0gfCB1bmRlZmluZWQsIGRyb3BMb2NhdGlvbjogRHJvcExvY2F0aW9uIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuZHJhZ0l0ZW0gPSBkcmFnSXRlbTtcbiAgICAgICAgdGhpcy5kcm9wTG9jYXRpb24gPSBkcm9wTG9jYXRpb247XG4gICAgfVxufVxuIiwiLyoqXG4gKiBHZW5lcmF0ZXMgYSB0ZW1wb3JhcnkgSUQgdGhhdCB3ZSBjYW4gYXNzaWduIHRvIGEgRHJhZ0l0ZW0gb3IgRHJvcExvY2F0aW9uIG9yIG90aGVyIHF1aXogZWxlbWVudFxuICogc28gdGhhdCB3ZSBjYW4gcmVmZXIgdG8gdGhvc2Ugb2JqZWN0cyBiZWZvcmUgdGhlIHNlcnZlciBoYXMgY3JlYXRlZCBhbiBJRC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdlbmVyYXRlKCk6IG51bWJlciB7XG4gICAgcmV0dXJuIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIE51bWJlci5NQVhfU0FGRV9JTlRFR0VSKTtcbn1cbiIsImltcG9ydCB7IEJhc2VFbnRpdHkgfSBmcm9tICdhcHAvc2hhcmVkL21vZGVsL2Jhc2UtZW50aXR5JztcbmltcG9ydCB7IERyYWdBbmREcm9wUXVlc3Rpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9kcmFnLWFuZC1kcm9wLXF1ZXN0aW9uLm1vZGVsJztcbmltcG9ydCB7IGdlbmVyYXRlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9xdWl6L21hbmFnZS90ZW1wLWlkJztcblxuZXhwb3J0IGludGVyZmFjZSBDYW5CZWNvbWVJbnZhbGlkIHtcbiAgICBpbnZhbGlkOiBib29sZWFuO1xufVxuXG5leHBvcnQgY2xhc3MgQmFzZUVudGl0eVdpdGhUZW1wSWQgaW1wbGVtZW50cyBCYXNlRW50aXR5IHtcbiAgICBwdWJsaWMgaWQ/OiBudW1iZXI7XG4gICAgcHVibGljIHRlbXBJRD86IG51bWJlcjtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy50ZW1wSUQgPSBnZW5lcmF0ZSgpO1xuICAgIH1cbn1cblxuZXhwb3J0IGNsYXNzIERyb3BMb2NhdGlvbiBleHRlbmRzIEJhc2VFbnRpdHlXaXRoVGVtcElkIGltcGxlbWVudHMgQ2FuQmVjb21lSW52YWxpZCB7XG4gICAgcHVibGljIHBvc1g/OiBudW1iZXI7XG4gICAgcHVibGljIHBvc1k/OiBudW1iZXI7XG4gICAgcHVibGljIHdpZHRoPzogbnVtYmVyO1xuICAgIHB1YmxpYyBoZWlnaHQ/OiBudW1iZXI7XG4gICAgcHVibGljIGludmFsaWQgPSBmYWxzZTsgLy8gZGVmYXVsdCB2YWx1ZVxuICAgIHB1YmxpYyBxdWVzdGlvbj86IERyYWdBbmREcm9wUXVlc3Rpb247XG5cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBEcmFnQW5kRHJvcFF1ZXN0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovZHJhZy1hbmQtZHJvcC1xdWVzdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBCYXNlRW50aXR5V2l0aFRlbXBJZCwgQ2FuQmVjb21lSW52YWxpZCB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L2Ryb3AtbG9jYXRpb24ubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgRHJhZ0l0ZW0gZXh0ZW5kcyBCYXNlRW50aXR5V2l0aFRlbXBJZCBpbXBsZW1lbnRzIENhbkJlY29tZUludmFsaWQge1xuICAgIHB1YmxpYyBwaWN0dXJlRmlsZVBhdGg/OiBzdHJpbmc7XG4gICAgcHVibGljIHRleHQ/OiBzdHJpbmc7XG4gICAgcHVibGljIHF1ZXN0aW9uPzogRHJhZ0FuZERyb3BRdWVzdGlvbjtcbiAgICBwdWJsaWMgaW52YWxpZCA9IGZhbHNlOyAvLyBkZWZhdWx0IHZhbHVlXG5cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBBZnRlclZpZXdJbml0LCBEaXJlY3RpdmUsIEVsZW1lbnRSZWYsIEhvc3RMaXN0ZW5lciwgSW5wdXQsIE9uQ2hhbmdlcywgT25Jbml0LCBSZW5kZXJlcjIsIFNpbXBsZUNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuLy8gTk9URTogdGhpcyBjb2RlIHdhcyB0YWtlbiBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9zb2xsZW5uZS9hbmd1bGFyLWZpdHRleHQgYmVjYXVzZSB0aGUgcmVwb3NpdG9yeSB3YXMgbm90IG1haW50YWluZWQgYW55IG1vcmUgc2luY2UgSnVuZSAyMDE4XG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAYW5ndWxhci1lc2xpbnQvZGlyZWN0aXZlLXNlbGVjdG9yXG5ARGlyZWN0aXZlKHsgc2VsZWN0b3I6ICdbZml0VGV4dF0nIH0pXG5leHBvcnQgY2xhc3MgRml0VGV4dERpcmVjdGl2ZSBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQsIE9uSW5pdCwgT25DaGFuZ2VzIHtcbiAgICBASW5wdXQoKSBmaXRUZXh0ID0gdHJ1ZTtcbiAgICBASW5wdXQoKSBjb21wcmVzc2lvbiA9IDE7XG4gICAgQElucHV0KCkgYWN0aXZhdGVPblJlc2l6ZSA9IHRydWU7XG4gICAgQElucHV0KCkgbWluRm9udFNpemU/OiBudW1iZXIgfCAnaW5oZXJpdCcgPSAwO1xuICAgIEBJbnB1dCgpIG1heEZvbnRTaXplPzogbnVtYmVyIHwgJ2luaGVyaXQnID0gTnVtYmVyLlBPU0lUSVZFX0lORklOSVRZO1xuICAgIEBJbnB1dCgpIGRlbGF5ID0gMTAwO1xuICAgIEBJbnB1dCgpIGlubmVySFRNTDogYW55O1xuICAgIEBJbnB1dCgpIGZvbnRVbml0OiAncHgnIHwgJ2VtJyB8IHN0cmluZyA9ICdweCc7XG5cbiAgICBwcml2YXRlIHJlYWRvbmx5IGZpdFRleHRFbGVtZW50OiBIVE1MRWxlbWVudDtcbiAgICBwcml2YXRlIHJlYWRvbmx5IGNvbXB1dGVkOiBDU1NTdHlsZURlY2xhcmF0aW9uO1xuICAgIHByaXZhdGUgcmVhZG9ubHkgbmV3bGluZXM6IG51bWJlcjtcbiAgICBwcml2YXRlIHJlYWRvbmx5IGxpbmVIZWlnaHQ6IHN0cmluZztcbiAgICBwcml2YXRlIHJlYWRvbmx5IGRpc3BsYXk6IHN0cmluZztcbiAgICBwcml2YXRlIGZpdFRleHRQYXJlbnQ6IEhUTUxFbGVtZW50O1xuICAgIHByaXZhdGUgZml0VGV4dE1pbkZvbnRTaXplOiBudW1iZXI7XG4gICAgcHJpdmF0ZSBmaXRUZXh0TWF4Rm9udFNpemU6IG51bWJlcjtcbiAgICBwcml2YXRlIGNhbGNTaXplID0gMTA7XG4gICAgcHJpdmF0ZSByZXNpemVUaW1lb3V0OiBhbnk7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBlbDogRWxlbWVudFJlZixcbiAgICAgICAgcHJpdmF0ZSByZW5kZXJlcjogUmVuZGVyZXIyLFxuICAgICkge1xuICAgICAgICB0aGlzLmZpdFRleHRFbGVtZW50ID0gZWwubmF0aXZlRWxlbWVudDtcbiAgICAgICAgdGhpcy5maXRUZXh0UGFyZW50ID0gdGhpcy5maXRUZXh0RWxlbWVudC5wYXJlbnRFbGVtZW50ITtcbiAgICAgICAgdGhpcy5jb21wdXRlZCA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKHRoaXMuZml0VGV4dEVsZW1lbnQpO1xuICAgICAgICB0aGlzLm5ld2xpbmVzID0gdGhpcy5maXRUZXh0RWxlbWVudC5jaGlsZEVsZW1lbnRDb3VudCA+IDAgPyB0aGlzLmZpdFRleHRFbGVtZW50LmNoaWxkRWxlbWVudENvdW50IDogMTtcbiAgICAgICAgdGhpcy5saW5lSGVpZ2h0ID0gdGhpcy5jb21wdXRlZFsnbGluZS1oZWlnaHQnXTtcbiAgICAgICAgdGhpcy5kaXNwbGF5ID0gdGhpcy5jb21wdXRlZFsnZGlzcGxheSddO1xuICAgIH1cblxuICAgIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzpyZXNpemUnKVxuICAgIHB1YmxpYyBvbldpbmRvd1Jlc2l6ZSA9ICgpOiB2b2lkID0+IHtcbiAgICAgICAgaWYgKHRoaXMuYWN0aXZhdGVPblJlc2l6ZSkge1xuICAgICAgICAgICAgdGhpcy5zZXRGb250U2l6ZSgpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIHB1YmxpYyBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5maXRUZXh0TWluRm9udFNpemUgPSB0aGlzLm1pbkZvbnRTaXplID09PSAnaW5oZXJpdCcgPyB0aGlzLmNvbXB1dGVkWydmb250LXNpemUnXSA6IHRoaXMubWluRm9udFNpemU7XG4gICAgICAgIHRoaXMuZml0VGV4dE1heEZvbnRTaXplID0gdGhpcy5tYXhGb250U2l6ZSA9PT0gJ2luaGVyaXQnID8gdGhpcy5jb21wdXRlZFsnZm9udC1zaXplJ10gOiB0aGlzLm1heEZvbnRTaXplO1xuICAgIH1cblxuICAgIHB1YmxpYyBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgICAgIHRoaXMuc2V0Rm9udFNpemUoMCk7XG4gICAgfVxuXG4gICAgcHVibGljIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcbiAgICAgICAgaWYgKGNoYW5nZXNbJ2NvbXByZXNzaW9uJ10gJiYgIWNoYW5nZXNbJ2NvbXByZXNzaW9uJ10uZmlyc3RDaGFuZ2UpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0Rm9udFNpemUoMCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNoYW5nZXNbJ2lubmVySFRNTCddKSB7XG4gICAgICAgICAgICB0aGlzLmZpdFRleHRFbGVtZW50LmlubmVySFRNTCA9IHRoaXMuaW5uZXJIVE1MO1xuICAgICAgICAgICAgaWYgKCFjaGFuZ2VzWydpbm5lckhUTUwnXS5maXJzdENoYW5nZSkge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0Rm9udFNpemUoMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIHNldEZvbnRTaXplID0gKGRlbGF5OiBudW1iZXIgPSB0aGlzLmRlbGF5KTogdm9pZCA9PiB7XG4gICAgICAgIHRoaXMucmVzaXplVGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgaWYgKHRoaXMuZml0VGV4dEVsZW1lbnQub2Zmc2V0SGVpZ2h0ICogdGhpcy5maXRUZXh0RWxlbWVudC5vZmZzZXRXaWR0aCAhPT0gMCkge1xuICAgICAgICAgICAgICAgIC8vIHJlc2V0IHRvIGRlZmF1bHRcbiAgICAgICAgICAgICAgICB0aGlzLnNldFN0eWxlcyh0aGlzLmNhbGNTaXplLCAxLCAnaW5saW5lLWJsb2NrJyk7XG4gICAgICAgICAgICAgICAgLy8gc2V0IG5ld1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0U3R5bGVzKHRoaXMuY2FsY3VsYXRlTmV3Rm9udFNpemUoKSwgdGhpcy5saW5lSGVpZ2h0LCB0aGlzLmRpc3BsYXkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LCBkZWxheSk7XG4gICAgfTtcblxuICAgIHByaXZhdGUgY2FsY3VsYXRlTmV3Rm9udFNpemUgPSAoKTogbnVtYmVyID0+IHtcbiAgICAgICAgY29uc3QgcmF0aW8gPSAodGhpcy5jYWxjU2l6ZSAqIHRoaXMubmV3bGluZXMpIC8gdGhpcy5maXRUZXh0RWxlbWVudC5vZmZzZXRXaWR0aCAvIHRoaXMubmV3bGluZXM7XG5cbiAgICAgICAgcmV0dXJuIE1hdGgubWF4KFxuICAgICAgICAgICAgTWF0aC5taW4oXG4gICAgICAgICAgICAgICAgKHRoaXMuZml0VGV4dFBhcmVudC5vZmZzZXRXaWR0aCAtXG4gICAgICAgICAgICAgICAgICAgIChwYXJzZUZsb2F0KGdldENvbXB1dGVkU3R5bGUodGhpcy5maXRUZXh0UGFyZW50KS5wYWRkaW5nTGVmdCkgKyBwYXJzZUZsb2F0KGdldENvbXB1dGVkU3R5bGUodGhpcy5maXRUZXh0UGFyZW50KS5wYWRkaW5nUmlnaHQpKSAtXG4gICAgICAgICAgICAgICAgICAgIDYpICpcbiAgICAgICAgICAgICAgICAgICAgcmF0aW8gKlxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbXByZXNzaW9uLFxuICAgICAgICAgICAgICAgIHRoaXMuZml0VGV4dE1heEZvbnRTaXplLFxuICAgICAgICAgICAgKSxcbiAgICAgICAgICAgIHRoaXMuZml0VGV4dE1pbkZvbnRTaXplLFxuICAgICAgICApO1xuICAgIH07XG5cbiAgICBwcml2YXRlIHNldFN0eWxlcyA9IChmb250U2l6ZTogbnVtYmVyLCBsaW5lSGVpZ2h0OiBudW1iZXIgfCBzdHJpbmcsIGRpc3BsYXk6IHN0cmluZyk6IHZvaWQgPT4ge1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHRoaXMuZml0VGV4dEVsZW1lbnQsICdmb250U2l6ZScsIGZvbnRTaXplLnRvU3RyaW5nKCkgKyB0aGlzLmZvbnRVbml0KTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZSh0aGlzLmZpdFRleHRFbGVtZW50LCAnbGluZUhlaWdodCcsIGxpbmVIZWlnaHQudG9TdHJpbmcoKSk7XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUodGhpcy5maXRUZXh0RWxlbWVudCwgJ2Rpc3BsYXknLCBkaXNwbGF5KTtcbiAgICB9O1xufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0LCBWaWV3RW5jYXBzdWxhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IGlzTW9iaWxlIGZyb20gJ2lzbW9iaWxlanMtZXM1JztcbmltcG9ydCB7IERyYWdJdGVtIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovZHJhZy1pdGVtLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktZHJhZy1pdGVtJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vZHJhZy1pdGVtLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9kcmFnLWl0ZW0uY29tcG9uZW50LnNjc3MnXSxcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxufSlcbmV4cG9ydCBjbGFzcyBEcmFnSXRlbUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgQElucHV0KCkgbWluV2lkdGg6IHN0cmluZztcbiAgICBASW5wdXQoKSBkcmFnSXRlbTogRHJhZ0l0ZW07XG4gICAgQElucHV0KCkgY2xpY2tEaXNhYmxlZDogYm9vbGVhbjtcbiAgICBASW5wdXQoKSBpbnZhbGlkOiBib29sZWFuO1xuICAgIEBJbnB1dCgpIGZpbGVQcmV2aWV3UGF0aHM6IE1hcDxzdHJpbmcsIHN0cmluZz4gPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nPigpO1xuICAgIGlzTW9iaWxlID0gZmFsc2U7XG5cbiAgICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgICAvKipcbiAgICAgKiBJbml0aWFsaXplcyBkZXZpY2UgaW5mb3JtYXRpb24gYW5kIHdoZXRoZXIgdGhlIGRldmljZSBpcyBhIG1vYmlsZSBkZXZpY2VcbiAgICAgKi9cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5pc01vYmlsZSA9IGlzTW9iaWxlKHdpbmRvdy5uYXZpZ2F0b3IudXNlckFnZW50KS5hbnk7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cImRyYWctaXRlbVwiIG5nQ2xhc3M9XCJ7J25vLWNsaWNrJzogY2xpY2tEaXNhYmxlZH1cIiBbbmdTdHlsZV09XCJ7ICdtaW4td2lkdGgnOiBtaW5XaWR0aCB9XCI+XG4gICAgQGlmIChkcmFnSXRlbSAmJiBkcmFnSXRlbS5waWN0dXJlRmlsZVBhdGgpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cImRyYWctaXRlbS1waWN0dXJlXCIgW2Nka0RyYWdEaXNhYmxlZF09XCJjbGlja0Rpc2FibGVkXCIgW2Nka0RyYWdEYXRhXT1cImRyYWdJdGVtXCIgY2RrRHJhZz5cbiAgICAgICAgICAgIEBpZiAoZHJhZ0l0ZW0ucGljdHVyZUZpbGVQYXRoKSB7XG4gICAgICAgICAgICAgICAgPGpoaS1zZWN1cmVkLWltYWdlIFtzcmNdPVwiZmlsZVByZXZpZXdQYXRocy5nZXQoZHJhZ0l0ZW0ucGljdHVyZUZpbGVQYXRoISkgfHwgZHJhZ0l0ZW0ucGljdHVyZUZpbGVQYXRoIVwiIFttb2JpbGVEcmFnQW5kRHJvcF09XCJpc01vYmlsZVwiPjwvamhpLXNlY3VyZWQtaW1hZ2U+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICA8ZGl2ICpjZGtEcmFnUGxhY2Vob2xkZXI+PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICBAaWYgKGRyYWdJdGVtICYmICFkcmFnSXRlbS5waWN0dXJlRmlsZVBhdGgpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cImRyYWctaXRlbS10ZXh0XCI+XG4gICAgICAgICAgICA8ZGl2IFtmaXRUZXh0XT1cInRydWVcIiBbYWN0aXZhdGVPblJlc2l6ZV09XCJ0cnVlXCIgW21heEZvbnRTaXplXT1cIjE3XCIgW21pbkZvbnRTaXplXT1cIjE1XCIgW2RlbGF5XT1cIjE1MFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkcmFnLWJveFwiIFtjZGtEcmFnRGlzYWJsZWRdPVwiY2xpY2tEaXNhYmxlZFwiIFtjZGtEcmFnRGF0YV09XCJkcmFnSXRlbVwiIGNka0RyYWc+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGRyYWdJdGVtLnRleHQgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgKmNka0RyYWdQbGFjZWhvbGRlcj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiAqY2RrRHJhZ1ByZXZpZXcgbWF0Y2hTaXplPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT1cImJvcmRlcjogMXB4IHNvbGlkICMwMDA7IGJhY2tncm91bmQ6IHdoaXRlOyBjb2xvcjogYmxhY2s7IHBhZGRpbmc6IDRweDsgb3ZlcmZsb3c6IGhpZGRlbjsgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXNcIj57eyBkcmFnSXRlbS50ZXh0IH19PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICBAaWYgKGludmFsaWQpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cImludmFsaWRcIj5cbiAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuc2hvd1N0YXRpc3RpYy5pbnZhbGlkXCI+PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG48L2Rpdj5cbiIsImltcG9ydCB7IEFmdGVyVmlld0luaXQsIENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE5nYk1vZGFsIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xuaW1wb3J0IHsgVHJhbnNsYXRlU2VydmljZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xuaW1wb3J0IHsgUmVzdWx0IH0gZnJvbSAnYXBwL2VudGl0aWVzL3Jlc3VsdC5tb2RlbCc7XG5pbXBvcnQgeyBRdWl6U3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L3F1aXotc3VibWlzc2lvbi5tb2RlbCc7XG5pbXBvcnQgeyBTaG9ydEFuc3dlclF1ZXN0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovc2hvcnQtYW5zd2VyLXF1ZXN0aW9uLm1vZGVsJztcbmltcG9ydCB7IFF1aXpRdWVzdGlvbiwgUXVpelF1ZXN0aW9uVHlwZSwgU2NvcmluZ1R5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9xdWl6LXF1ZXN0aW9uLm1vZGVsJztcbmltcG9ydCB7IE11bHRpcGxlQ2hvaWNlU3VibWl0dGVkQW5zd2VyIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovbXVsdGlwbGUtY2hvaWNlLXN1Ym1pdHRlZC1hbnN3ZXIubW9kZWwnO1xuaW1wb3J0IHsgRHJhZ0FuZERyb3BNYXBwaW5nIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovZHJhZy1hbmQtZHJvcC1tYXBwaW5nLm1vZGVsJztcbmltcG9ydCB7IEFuc3dlck9wdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L2Fuc3dlci1vcHRpb24ubW9kZWwnO1xuaW1wb3J0IHsgU2hvcnRBbnN3ZXJTdWJtaXR0ZWRUZXh0IH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovc2hvcnQtYW5zd2VyLXN1Ym1pdHRlZC10ZXh0Lm1vZGVsJztcbmltcG9ydCB7IE11bHRpcGxlQ2hvaWNlUXVlc3Rpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9tdWx0aXBsZS1jaG9pY2UtcXVlc3Rpb24ubW9kZWwnO1xuaW1wb3J0IHsgZmFRdWVzdGlvbkNpcmNsZSB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXJlZ3VsYXItc3ZnLWljb25zJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktcXVpei1zY29yaW5nLWluZm9zdHVkZW50LW1vZGFsJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vcXVpei1zY29yaW5nLWluZm8tc3R1ZGVudC1tb2RhbC5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vcXVpei1zY29yaW5nLWluZm8tc3R1ZGVudC1tb2RhbC5jb21wb25lbnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBRdWl6U2NvcmluZ0luZm9TdHVkZW50TW9kYWxDb21wb25lbnQgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0IHtcbiAgICBRdWl6UXVlc3Rpb25UeXBlID0gUXVpelF1ZXN0aW9uVHlwZTtcbiAgICBTY29yaW5nVHlwZSA9IFNjb3JpbmdUeXBlO1xuXG4gICAgQElucHV0KCkgc2NvcmU6IG51bWJlcjsgLy8gU2NvcmUgb2YgdGhlIHN0dWRlbnQgdGhhdCBoYXMgYmVlbiBhY2hpZXZlZFxuICAgIEBJbnB1dCgpIHF1ZXN0aW9uSW5kZXg6IG51bWJlcjsgLy8gUXVlc3Rpb24gSW5kZXggb2YgdGhlIHF1ZXN0aW9uXG4gICAgQElucHV0KCkgcXVlc3Rpb246IFF1aXpRdWVzdGlvbjtcbiAgICBASW5wdXQoKSBkcmFnQW5kRHJvcE1hcHBpbmcgPSBuZXcgQXJyYXk8RHJhZ0FuZERyb3BNYXBwaW5nPigpO1xuICAgIEBJbnB1dCgpIGluY29ycmVjdGx5TWFwcGVkRHJhZ0FuZERyb3BJdGVtczogbnVtYmVyO1xuICAgIEBJbnB1dCgpIG1hcHBlZExvY2F0aW9uczogbnVtYmVyO1xuICAgIEBJbnB1dCgpIG11bHRpcGxlQ2hvaWNlTWFwcGluZyA9IG5ldyBBcnJheTxBbnN3ZXJPcHRpb24+KCk7XG4gICAgQElucHV0KCkgc2hvcnRBbnN3ZXJUZXh0ID0gbmV3IEFycmF5PFNob3J0QW5zd2VyU3VibWl0dGVkVGV4dD4oKTtcbiAgICBASW5wdXQoKSBjb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zOiBudW1iZXI7IC8vIEFtb3VudCBvZiBjb3JyZWN0bHkgbWFwcGVkIGRyYWcgYW5kIGRyb3AgaXRlbXNcbiAgICBASW5wdXQoKSBtdWx0aXBsZUNob2ljZVN1Ym1pdHRlZFJlc3VsdDogUmVzdWx0O1xuICAgIEBJbnB1dCgpIHF1aXpRdWVzdGlvbnM6IFF1aXpRdWVzdGlvbltdIHwgdW5kZWZpbmVkO1xuXG4gICAgLyogTXVsdGlwbGUgQ2hvaWNlIENvdW50aW5nIFZhcmlhYmxlcyovXG4gICAgbXVsdGlwbGVDaG9pY2VDb3JyZWN0QW5zd2VyQ29ycmVjdGx5Q2hvc2VuOiBudW1iZXI7IC8vIEFtb3VudCBvZiByaWdodCBvcHRpb25zIGNob3NlbiBieSB0aGUgc3R1ZGVudFxuICAgIG11bHRpcGxlQ2hvaWNlV3JvbmdBbnN3ZXJDaG9zZW46IG51bWJlcjsgLy8gQW1vdW50IG9mIHdyb25nIG9wdGlvbnMgY2hvc2VuIGJ5IHRoZSBzdHVkZW50XG4gICAgY29ycmVjdE11bHRpcGxlQ2hvaWNlQW5zd2VyczogbnVtYmVyOyAvLyBBbW91bnQgb2YgY29ycmVjdCBvcHRpb25zIGZvciB0aGUgcXVlc3Rpb25cbiAgICBmb3Jnb3R0ZW5NdWx0aXBsZUNob2ljZVJpZ2h0QW5zd2VyczogbnVtYmVyOyAvLyBBbW91bnQgb2Ygd3Jvbmcgb3B0aW9ucyBmb3IgdGhlIHF1ZXN0aW9uXG4gICAgbXVsdGlwbGVDaG9pY2VBbnN3ZXJPcHRpb25zOiBudW1iZXI7IC8vIEFtb3VudCBvZiBhbGwgcG9zc2libGUgb3B0aW9ucyBmb3IgdGhlIHF1ZXN0aW9uXG4gICAgaW5Ub3RhbFNlbGVjdGVkUmlnaHRPcHRpb25zOiBudW1iZXI7IC8vIEFtb3VudCBvZiBjb3JyZWN0IGFuZCB3cm9uZyBvcHRpb25zIGFzc2lnbmVkIGNvcnJlY3RseVxuICAgIGluVG90YWxTZWxlY3RlZFdyb25nT3B0aW9uczogbnVtYmVyOyAvLyBBbW91bnQgb2YgY29ycmVjdCBhbmQgd3Jvbmcgb3B0aW9ucyBhc3NpZ25lZCB3cm9uZ2x5XG4gICAgZGlmZmVyZW5jZU11bHRpcGxlQ2hvaWNlOiBudW1iZXI7IC8vIERpZmZlcmVuY2UgYmV0d2VlbiBpblRvdGFsU2VsZWN0ZWRSaWdodE9wdGlvbnMgYW5kIGRpZmZlcmVuY2VNdWx0aXBsZUNob2ljZVxuICAgIGNoZWNrRm9yQ29ycmVjdEFuc3dlcnMgPSBuZXcgQXJyYXk8QW5zd2VyT3B0aW9uPigpO1xuICAgIGNoZWNrRm9yV3JvbmdBbnN3ZXJzID0gbmV3IEFycmF5PEFuc3dlck9wdGlvbj4oKTtcbiAgICBpc1NpbmdsZUNob2ljZTogYm9vbGVhbjtcblxuICAgIC8qIERyYWcgYW5kIERyb3AgQ291bnRpbmcgVmFyaWFibGVzKi9cbiAgICBkaWZmZXJlbmNlRHJhZ0FuZERyb3A6IG51bWJlcjsgLy8gRGlmZmVyZW5jZSBiZXR3ZWVuIHRoZSBpbmNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXMgYW5kIGNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXNcblxuICAgIC8qIFNob3J0IEFuc3dlciBDb3VudGluZyBWYXJpYWJsZXMqL1xuICAgIHNob3J0QW5zd2VyU3BvdHM6IG51bWJlcjsgLy8gQW1vdW50IG9mIHNob3J0IGFuc3dlciBzcG90c1xuICAgIHNob3J0QW5zd2VyQ29ycmVjdEFuc3dlcnM6IG51bWJlcjsgLy8gQSBtb3VudCBvZiBjb3JyZWN0bHkgZmlsbGVkIG91dCBzcG90c1xuICAgIHNob3J0QW5zd2VyV3JvbmdBbnN3ZXJzOiBudW1iZXI7IC8vIEEgbW91bnQgb2Ygd3JvbmdseSBmaWxsZWQgb3V0IHNwb3RzXG4gICAgZGlmZmVyZW5jZVNob3J0QW5zd2VyOiBudW1iZXI7IC8vIERpZmZlcmVuY2UgYmV0d2VlbiBzaG9ydEFuc3dlckNvcnJlY3RBbnN3ZXJzIGFuZCBzaG9ydEFuc3dlcldyb25nQW5zd2Vyc1xuXG4gICAgLyogUGx1cmFsIFZhcmlhYmxlcyovXG4gICAgcXVlc3Rpb25Qb2ludDogc3RyaW5nO1xuICAgIHNjb3JlUG9pbnQ6IHN0cmluZztcbiAgICB3cm9uZ09wdGlvbjogc3RyaW5nO1xuICAgIHJpZ2h0T3B0aW9uOiBzdHJpbmc7XG4gICAgcmlnaHRNYXA6IHN0cmluZztcbiAgICB3cm9uZ01hcDogc3RyaW5nO1xuICAgIHJpZ2h0R2FwOiBzdHJpbmc7XG4gICAgd3JvbmdHYXA6IHN0cmluZztcblxuICAgIC8vIEljb25zXG4gICAgZmFyUXVlc3Rpb25DaXJjbGUgPSBmYVF1ZXN0aW9uQ2lyY2xlO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgbW9kYWxTZXJ2aWNlOiBOZ2JNb2RhbCxcbiAgICAgICAgcHJpdmF0ZSB0cmFuc2xhdGVTZXJ2aWNlOiBUcmFuc2xhdGVTZXJ2aWNlLFxuICAgICkge31cblxuICAgIC8qKlxuICAgICAqIENvdW50IHRoZSB2YXJpYWJsZXMgZGVwZW5kaW5nIG9uIHRoZSBxdWl6IHF1ZXN0aW9uIHR5cGVcbiAgICAgKi9cbiAgICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgICAgIHRoaXMuY2hlY2tGb3JTaW5nbGVPclBsdXJhbFBvaW50cygpO1xuICAgICAgICBzd2l0Y2ggKHRoaXMucXVlc3Rpb24udHlwZSkge1xuICAgICAgICAgICAgY2FzZSBRdWl6UXVlc3Rpb25UeXBlLk1VTFRJUExFX0NIT0lDRTpcbiAgICAgICAgICAgICAgICB0aGlzLmNvdW50TXVsdGlwbGVDaG9pY2UoKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgUXVpelF1ZXN0aW9uVHlwZS5EUkFHX0FORF9EUk9QOlxuICAgICAgICAgICAgICAgIHRoaXMuY291bnREcmFnQW5kRHJvcCgpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBRdWl6UXVlc3Rpb25UeXBlLlNIT1JUX0FOU1dFUjpcbiAgICAgICAgICAgICAgICB0aGlzLmNvdW50U2hvcnRBbnN3ZXIoKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIG9wZW5zIHRoZSBwb3AtdXAgZm9yIHRoZSBleHBsYW5hdGlvbiBvZiB0aGUgcG9pbnRzXG4gICAgICovXG4gICAgb3Blbihjb250ZW50OiBhbnkpIHtcbiAgICAgICAgdGhpcy5tb2RhbFNlcnZpY2Uub3Blbihjb250ZW50LCB7IHNpemU6ICdsZycgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY2hlY2tzIGZvciB0aGUgY29ycmVjdCBhbnN3ZXJPcHRpb25zIGJhc2VkIG9uIHRoZSBzdWJtaXR0ZWRBbnN3ZXJcbiAgICAgKi9cbiAgICBwcml2YXRlIHN1Ym1pdHRlZEFuc3dlckNvcnJlY3RWYWx1ZXMoKSB7XG4gICAgICAgIGxldCBhbnN3ZXJPcHRpb25zT2ZRdWVzdGlvbiA9IG5ldyBBcnJheTxBbnN3ZXJPcHRpb24+KCk7XG4gICAgICAgIGZvciAoY29uc3QgcXVlc3Rpb24gb2YgdGhpcy5xdWl6UXVlc3Rpb25zIHx8IFtdKSB7XG4gICAgICAgICAgICBjb25zdCBtY1F1aXpRdWVzdGlvbiA9IHF1ZXN0aW9uIGFzIE11bHRpcGxlQ2hvaWNlUXVlc3Rpb247XG4gICAgICAgICAgICBpZiAobWNRdWl6UXVlc3Rpb24uaWQgPT09IHRoaXMucXVlc3Rpb24uaWQpIHtcbiAgICAgICAgICAgICAgICBhbnN3ZXJPcHRpb25zT2ZRdWVzdGlvbiA9IG1jUXVpelF1ZXN0aW9uLmFuc3dlck9wdGlvbnMhO1xuICAgICAgICAgICAgICAgIHRoaXMuY29ycmVjdE11bHRpcGxlQ2hvaWNlQW5zd2VycyA9IG1jUXVpelF1ZXN0aW9uLmFuc3dlck9wdGlvbnMhLmZpbHRlcigob3B0aW9uKSA9PiBvcHRpb24uaXNDb3JyZWN0KS5sZW5ndGg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXRoaXMubXVsdGlwbGVDaG9pY2VTdWJtaXR0ZWRSZXN1bHQgfHwgIXRoaXMubXVsdGlwbGVDaG9pY2VTdWJtaXR0ZWRSZXN1bHQuc3VibWlzc2lvbikge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHN1Ym1pdHRlZFF1aXpTdWJtaXNzaW9uID0gdGhpcy5tdWx0aXBsZUNob2ljZVN1Ym1pdHRlZFJlc3VsdC5zdWJtaXNzaW9uIGFzIFF1aXpTdWJtaXNzaW9uO1xuICAgICAgICBjb25zdCBzdWJtaXR0ZWRBbnN3ZXJMZW5ndGggPSBzdWJtaXR0ZWRRdWl6U3VibWlzc2lvbi5zdWJtaXR0ZWRBbnN3ZXJzPy5sZW5ndGggPz8gMDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdWJtaXR0ZWRBbnN3ZXJMZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKHN1Ym1pdHRlZFF1aXpTdWJtaXNzaW9uLnN1Ym1pdHRlZEFuc3dlcnMhW2ldLnF1aXpRdWVzdGlvbiEuaWQgPT09IHRoaXMucXVlc3Rpb24uaWQpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBtdWx0aXBsZUNob2ljZVN1Ym1pdHRlZEFuc3dlcnMgPSBzdWJtaXR0ZWRRdWl6U3VibWlzc2lvbi5zdWJtaXR0ZWRBbnN3ZXJzIVtpXSBhcyBNdWx0aXBsZUNob2ljZVN1Ym1pdHRlZEFuc3dlcjtcbiAgICAgICAgICAgICAgICBpZiAobXVsdGlwbGVDaG9pY2VTdWJtaXR0ZWRBbnN3ZXJzLnNlbGVjdGVkT3B0aW9ucyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JDb3JyZWN0QW5zd2VycyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRm9yV3JvbmdBbnN3ZXJzID0gW107XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBzZWxlY3RlZE9wdGlvbiBvZiBtdWx0aXBsZUNob2ljZVN1Ym1pdHRlZEFuc3dlcnMuc2VsZWN0ZWRPcHRpb25zKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGFuc3dlck9wdGlvbkVsZW1lbnQgb2YgYW5zd2VyT3B0aW9uc09mUXVlc3Rpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZWN0ZWRPcHRpb24uaWQgPT09IGFuc3dlck9wdGlvbkVsZW1lbnQuaWQgJiYgYW5zd2VyT3B0aW9uRWxlbWVudC5pc0NvcnJlY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvckNvcnJlY3RBbnN3ZXJzLnB1c2goc2VsZWN0ZWRPcHRpb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoc2VsZWN0ZWRPcHRpb24uaWQgPT09IGFuc3dlck9wdGlvbkVsZW1lbnQuaWQgJiYgIWFuc3dlck9wdGlvbkVsZW1lbnQuaXNDb3JyZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGb3JXcm9uZ0Fuc3dlcnMucHVzaChzZWxlY3RlZE9wdGlvbik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY291bnRzIHRoZSB2YXJpYWJsZXMgZm9yIE11bHRpcGxlIENob2ljZSBRdWVzdGlvbnNcbiAgICAgKi9cbiAgICBwcml2YXRlIGNvdW50TXVsdGlwbGVDaG9pY2UoKSB7XG4gICAgICAgIHRoaXMuc3VibWl0dGVkQW5zd2VyQ29ycmVjdFZhbHVlcygpO1xuICAgICAgICBjb25zdCB0cmFuc2xhdGlvbkJhc2VQYXRoID0gJ2FydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC4nO1xuICAgICAgICBjb25zdCBtY21RdWVzdGlvbiA9IHRoaXMucXVlc3Rpb24gYXMgTXVsdGlwbGVDaG9pY2VRdWVzdGlvbjtcbiAgICAgICAgdGhpcy5pc1NpbmdsZUNob2ljZSA9IG1jbVF1ZXN0aW9uLnNpbmdsZUNob2ljZSA/PyBmYWxzZTtcbiAgICAgICAgdGhpcy5tdWx0aXBsZUNob2ljZUFuc3dlck9wdGlvbnMgPSBtY21RdWVzdGlvbi5hbnN3ZXJPcHRpb25zIS5sZW5ndGg7XG4gICAgICAgIHRoaXMubXVsdGlwbGVDaG9pY2VDb3JyZWN0QW5zd2VyQ29ycmVjdGx5Q2hvc2VuID0gdGhpcy5jaGVja0ZvckNvcnJlY3RBbnN3ZXJzLmxlbmd0aDtcbiAgICAgICAgdGhpcy5tdWx0aXBsZUNob2ljZVdyb25nQW5zd2VyQ2hvc2VuID0gdGhpcy5jaGVja0Zvcldyb25nQW5zd2Vycy5sZW5ndGg7XG4gICAgICAgIHRoaXMuZm9yZ290dGVuTXVsdGlwbGVDaG9pY2VSaWdodEFuc3dlcnMgPSB0aGlzLmNvcnJlY3RNdWx0aXBsZUNob2ljZUFuc3dlcnMgLSB0aGlzLm11bHRpcGxlQ2hvaWNlQ29ycmVjdEFuc3dlckNvcnJlY3RseUNob3NlbjtcbiAgICAgICAgdGhpcy5pblRvdGFsU2VsZWN0ZWRSaWdodE9wdGlvbnMgPVxuICAgICAgICAgICAgdGhpcy5tdWx0aXBsZUNob2ljZUNvcnJlY3RBbnN3ZXJDb3JyZWN0bHlDaG9zZW4gKyAodGhpcy5tdWx0aXBsZUNob2ljZUFuc3dlck9wdGlvbnMgLSB0aGlzLmNvcnJlY3RNdWx0aXBsZUNob2ljZUFuc3dlcnMgLSB0aGlzLm11bHRpcGxlQ2hvaWNlV3JvbmdBbnN3ZXJDaG9zZW4pO1xuICAgICAgICB0aGlzLmluVG90YWxTZWxlY3RlZFdyb25nT3B0aW9ucyA9IHRoaXMubXVsdGlwbGVDaG9pY2VXcm9uZ0Fuc3dlckNob3NlbiArIHRoaXMuZm9yZ290dGVuTXVsdGlwbGVDaG9pY2VSaWdodEFuc3dlcnM7XG4gICAgICAgIHRoaXMuZGlmZmVyZW5jZU11bHRpcGxlQ2hvaWNlID0gdGhpcy5pblRvdGFsU2VsZWN0ZWRSaWdodE9wdGlvbnMgLSB0aGlzLmluVG90YWxTZWxlY3RlZFdyb25nT3B0aW9ucztcblxuICAgICAgICBpZiAodGhpcy5pblRvdGFsU2VsZWN0ZWRSaWdodE9wdGlvbnMgPT09IDEpIHtcbiAgICAgICAgICAgIHRoaXMucmlnaHRPcHRpb24gPSB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCh0cmFuc2xhdGlvbkJhc2VQYXRoICsgJ29wdGlvbicpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5yaWdodE9wdGlvbiA9IHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KHRyYW5zbGF0aW9uQmFzZVBhdGggKyAnb3B0aW9ucycpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMuaW5Ub3RhbFNlbGVjdGVkV3JvbmdPcHRpb25zID09PSAxKSB7XG4gICAgICAgICAgICB0aGlzLndyb25nT3B0aW9uID0gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQodHJhbnNsYXRpb25CYXNlUGF0aCArICdvcHRpb24nKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMud3JvbmdPcHRpb24gPSB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCh0cmFuc2xhdGlvbkJhc2VQYXRoICsgJ29wdGlvbnMnKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGNvdW50cyB0aGUgdmFyaWFibGVzIGZvciBEcmFnIGFuZCBEcm9wIFF1ZXN0aW9uc1xuICAgICAqL1xuICAgIHByaXZhdGUgY291bnREcmFnQW5kRHJvcCgpIHtcbiAgICAgICAgY29uc3QgdHJhbnNsYXRpb25CYXNlUGF0aCA9ICdhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuJztcbiAgICAgICAgdGhpcy5kaWZmZXJlbmNlRHJhZ0FuZERyb3AgPSB0aGlzLmNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXMgLSB0aGlzLmluY29ycmVjdGx5TWFwcGVkRHJhZ0FuZERyb3BJdGVtcztcblxuICAgICAgICBpZiAodGhpcy5jb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zID09PSAxKSB7XG4gICAgICAgICAgICB0aGlzLnJpZ2h0TWFwID0gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQodHJhbnNsYXRpb25CYXNlUGF0aCArICdpdGVtJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnJpZ2h0TWFwID0gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQodHJhbnNsYXRpb25CYXNlUGF0aCArICdpdGVtcycpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMuaW5jb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zID09PSAxKSB7XG4gICAgICAgICAgICB0aGlzLndyb25nTWFwID0gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQodHJhbnNsYXRpb25CYXNlUGF0aCArICdpdGVtJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLndyb25nTWFwID0gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQodHJhbnNsYXRpb25CYXNlUGF0aCArICdpdGVtcycpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY291bnRzIHRoZSB2YXJpYWJsZXMgZm9yIFNob3J0IEFuc3dlciBRdWVzdGlvbnNcbiAgICAgKi9cbiAgICBwcml2YXRlIGNvdW50U2hvcnRBbnN3ZXIoKSB7XG4gICAgICAgIGNvbnN0IHRyYW5zbGF0aW9uQmFzZVBhdGggPSAnYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0Lic7XG4gICAgICAgIGNvbnN0IHNob3J0QW5zd2VyID0gdGhpcy5xdWVzdGlvbiBhcyBTaG9ydEFuc3dlclF1ZXN0aW9uO1xuICAgICAgICB0aGlzLnNob3J0QW5zd2VyU3BvdHMgPSBzaG9ydEFuc3dlci5zcG90cyEubGVuZ3RoO1xuICAgICAgICB0aGlzLnNob3J0QW5zd2VyQ29ycmVjdEFuc3dlcnMgPSB0aGlzLnNob3J0QW5zd2VyVGV4dC5maWx0ZXIoKG9wdGlvbikgPT4gb3B0aW9uLmlzQ29ycmVjdCkubGVuZ3RoO1xuICAgICAgICB0aGlzLnNob3J0QW5zd2VyV3JvbmdBbnN3ZXJzID0gdGhpcy5zaG9ydEFuc3dlclNwb3RzIC0gdGhpcy5zaG9ydEFuc3dlckNvcnJlY3RBbnN3ZXJzO1xuICAgICAgICB0aGlzLmRpZmZlcmVuY2VTaG9ydEFuc3dlciA9IHRoaXMuc2hvcnRBbnN3ZXJDb3JyZWN0QW5zd2VycyAtIHRoaXMuc2hvcnRBbnN3ZXJXcm9uZ0Fuc3dlcnM7XG5cbiAgICAgICAgaWYgKHRoaXMuc2hvcnRBbnN3ZXJDb3JyZWN0QW5zd2VycyA9PT0gMSkge1xuICAgICAgICAgICAgdGhpcy5yaWdodEdhcCA9IHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KHRyYW5zbGF0aW9uQmFzZVBhdGggKyAndGV4dGdhcCcpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5yaWdodEdhcCA9IHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KHRyYW5zbGF0aW9uQmFzZVBhdGggKyAndGV4dGdhcHMnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLnNob3J0QW5zd2VyV3JvbmdBbnN3ZXJzID09PSAxKSB7XG4gICAgICAgICAgICB0aGlzLndyb25nR2FwID0gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQodHJhbnNsYXRpb25CYXNlUGF0aCArICd0ZXh0Z2FwJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLndyb25nR2FwID0gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQodHJhbnNsYXRpb25CYXNlUGF0aCArICd0ZXh0Z2FwcycpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2tzIHRoZSBzY29yZSBvZiB0aGUgcXVlc3Rpb24gYW5kIHRoZSBzY29yZSB0aGUgc3R1ZGVudCBoYXMgYWNoaWV2ZWQsIGRlcGVuZGluZyBvbiB0aGF0IHdyaXRlIGVpdGhlciBwb2ludCBvciBwb2ludHNcbiAgICAgKi9cbiAgICBwcml2YXRlIGNoZWNrRm9yU2luZ2xlT3JQbHVyYWxQb2ludHMoKSB7XG4gICAgICAgIGNvbnN0IHRyYW5zbGF0aW9uQmFzZVBhdGggPSAnYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0Lic7XG4gICAgICAgIGlmICh0aGlzLnF1ZXN0aW9uLnBvaW50cyA9PT0gMSkge1xuICAgICAgICAgICAgdGhpcy5xdWVzdGlvblBvaW50ID0gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQodHJhbnNsYXRpb25CYXNlUGF0aCArICdwb2ludCcpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5xdWVzdGlvblBvaW50ID0gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQodHJhbnNsYXRpb25CYXNlUGF0aCArICdwb2ludHMnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLnNjb3JlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRoaXMuc2NvcmUgPSAwO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMuc2NvcmUgPT09IDEpIHtcbiAgICAgICAgICAgIHRoaXMuc2NvcmVQb2ludCA9IHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KHRyYW5zbGF0aW9uQmFzZVBhdGggKyAncG9pbnQnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuc2NvcmVQb2ludCA9IHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KHRyYW5zbGF0aW9uQmFzZVBhdGggKyAncG9pbnRzJyk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCI8bmctdGVtcGxhdGUgI3Njb3JpbmdFeHBsYW5hdGlvbiBsZXQtYz1cImNsb3NlXCIgbGV0LWQ9XCJkaXNtaXNzXCI+XG4gICAgPGRpdiBjbGFzcz1cIm1vZGFsLWhlYWRlclwiPlxuICAgICAgICA8aDUgY2xhc3M9XCJtb2RhbC10aXRsZVwiPlxuICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuc2NvcmluZ1RpdGxlXCJcbiAgICAgICAgICAgICAgICBbdHJhbnNsYXRlVmFsdWVzXT1cInsgcGFyYW1UaXRsZTogdGhpcy5xdWVzdGlvbi50aXRsZSwgcGFyYW1JbmRleDogdGhpcy5xdWVzdGlvbkluZGV4IH1cIlxuICAgICAgICAgICAgPjwvc3Bhbj5cbiAgICAgICAgPC9oNT5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tY2xvc2VcIiBhcmlhLWxhYmVsPVwiQ2xvc2VcIiAoY2xpY2spPVwiZCgpXCI+PC9idXR0b24+XG4gICAgPC9kaXY+XG4gICAgQGlmICh0aGlzLnF1ZXN0aW9uLnNjb3JpbmdUeXBlID09PSBTY29yaW5nVHlwZS5BTExfT1JfTk9USElORyAmJiBpc1NpbmdsZUNob2ljZSkge1xuICAgICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtYm9keVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmb250LXdlaWdodC1ib2xkXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0LnNjb3JpbmdUeXBlU2luZ2xlQ2hvaWNlXCI+PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0LnNjb3JpbmdUeXBlU2luZ2xlQ2hvaWNlRXhwbGFuYXRpb25cIj48L3NwYW4+XG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgQGlmICh0aGlzLmNvcnJlY3RNdWx0aXBsZUNob2ljZUFuc3dlcnMgPT0gdGhpcy5tdWx0aXBsZUNob2ljZUNvcnJlY3RBbnN3ZXJDb3JyZWN0bHlDaG9zZW4gJiYgdGhpcy5tdWx0aXBsZUNob2ljZVdyb25nQW5zd2VyQ2hvc2VuID09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5tdWx0aXBsZUNob2ljZVNpbmdsZUNob2ljZUNvcnJlY3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0cmFuc2xhdGVWYWx1ZXNdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlOiB0aGlzLnNjb3JlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVF1ZXN0aW9uU2NvcmU6IHRoaXMucXVlc3Rpb24ucG9pbnRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVBvaW50OiB0aGlzLnNjb3JlUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmVQb2ludDogdGhpcy5xdWVzdGlvblBvaW50XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+PC9zcGFuXG4gICAgICAgICAgICAgICAgICAgID48L3NwYW4+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoISh0aGlzLmNvcnJlY3RNdWx0aXBsZUNob2ljZUFuc3dlcnMgPT0gdGhpcy5tdWx0aXBsZUNob2ljZUNvcnJlY3RBbnN3ZXJDb3JyZWN0bHlDaG9zZW4gJiYgdGhpcy5tdWx0aXBsZUNob2ljZVdyb25nQW5zd2VyQ2hvc2VuID09IDApKSB7XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQubXVsdGlwbGVDaG9pY2VTaW5nbGVDaG9pY2VOb3RDb3JyZWN0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdHJhbnNsYXRlVmFsdWVzXT1cIntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZTogdGhpcy5zY29yZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1RdWVzdGlvblNjb3JlOiB0aGlzLnF1ZXN0aW9uLnBvaW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Qb2ludDogdGhpcy5zY29yZVBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlUG9pbnQ6IHRoaXMucXVlc3Rpb25Qb2ludFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvc3BhblxuICAgICAgICAgICAgICAgICAgICA+PC9zcGFuPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmICh0aGlzLnF1ZXN0aW9uLnNjb3JpbmdUeXBlID09PSBTY29yaW5nVHlwZS5BTExfT1JfTk9USElORyAmJiAhaXNTaW5nbGVDaG9pY2UpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWJvZHlcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC13ZWlnaHQtYm9sZFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5zY29yaW5nVHlwZUFsbE9yTm90aGluZ1wiPjwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5zY29yaW5nVHlwZUFsbE9yTm90aGluZ0V4cGxhbmF0aW9uXCI+PC9zcGFuPlxuICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICBAaWYgKHRoaXMucXVlc3Rpb24udHlwZSA9PT0gUXVpelF1ZXN0aW9uVHlwZS5NVUxUSVBMRV9DSE9JQ0UpIHtcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICBAaWYgKHRoaXMuY29ycmVjdE11bHRpcGxlQ2hvaWNlQW5zd2VycyA9PSB0aGlzLm11bHRpcGxlQ2hvaWNlQ29ycmVjdEFuc3dlckNvcnJlY3RseUNob3NlbiAmJiB0aGlzLm11bHRpcGxlQ2hvaWNlV3JvbmdBbnN3ZXJDaG9zZW4gPT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0Lm11bHRpcGxlQ2hvaWNlQWxsT3JOb3RoaW5nQ29ycmVjdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0cmFuc2xhdGVWYWx1ZXNdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZTogdGhpcy5zY29yZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUXVlc3Rpb25TY29yZTogdGhpcy5xdWVzdGlvbi5wb2ludHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVBvaW50OiB0aGlzLnNjb3JlUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlUG9pbnQ6IHRoaXMucXVlc3Rpb25Qb2ludFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9zcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICA+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoISh0aGlzLmNvcnJlY3RNdWx0aXBsZUNob2ljZUFuc3dlcnMgPT0gdGhpcy5tdWx0aXBsZUNob2ljZUNvcnJlY3RBbnN3ZXJDb3JyZWN0bHlDaG9zZW4gJiYgdGhpcy5tdWx0aXBsZUNob2ljZVdyb25nQW5zd2VyQ2hvc2VuID09IDApKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQubXVsdGlwbGVDaG9pY2VBbGxPck5vdGhpbmdOb3RDb3JyZWN0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3RyYW5zbGF0ZVZhbHVlc109XCJ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlOiB0aGlzLnNjb3JlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1RdWVzdGlvblNjb3JlOiB0aGlzLnF1ZXN0aW9uLnBvaW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtSW5Ub3RhbFdyb25nT3B0aW9uczogdGhpcy5pblRvdGFsU2VsZWN0ZWRXcm9uZ09wdGlvbnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbUluVG90YWxSaWdodE9wdGlvbnM6IHRoaXMuaW5Ub3RhbFNlbGVjdGVkUmlnaHRPcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Qb2ludDogdGhpcy5zY29yZVBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZVBvaW50OiB0aGlzLnF1ZXN0aW9uUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3cm9uZ09wdGlvbjogdGhpcy53cm9uZ09wdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0T3B0aW9uOiB0aGlzLnJpZ2h0T3B0aW9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L3NwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgID48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAodGhpcy5xdWVzdGlvbi50eXBlID09PSBRdWl6UXVlc3Rpb25UeXBlLkRSQUdfQU5EX0RST1ApIHtcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICBAaWYgKHRoaXMuaW5jb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zID09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5kcmFnQW5kRHJvcEFsbE9yTm90aGluZ0NvcnJlY3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdHJhbnNsYXRlVmFsdWVzXT1cIntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmU6IHRoaXMuc2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVF1ZXN0aW9uU2NvcmU6IHRoaXMucXVlc3Rpb24ucG9pbnRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Qb2ludDogdGhpcy5zY29yZVBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZVBvaW50OiB0aGlzLnF1ZXN0aW9uUG9pbnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvc3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKHRoaXMuaW5jb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zICE9IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5kcmFnQW5kRHJvcEFsbE9yTm90aGluZ05vdENvcnJlY3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdHJhbnNsYXRlVmFsdWVzXT1cIntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmU6IHRoaXMuc2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVF1ZXN0aW9uU2NvcmU6IHRoaXMucXVlc3Rpb24ucG9pbnRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Xcm9uZ01hcHBlZEl0ZW1zOiB0aGlzLmluY29ycmVjdGx5TWFwcGVkRHJhZ0FuZERyb3BJdGVtcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUmlnaHRNYXBwaW5nOiB0aGlzLmNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVBvaW50OiB0aGlzLnNjb3JlUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlUG9pbnQ6IHRoaXMucXVlc3Rpb25Qb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0TWFwOiB0aGlzLnJpZ2h0TWFwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd3JvbmdNYXA6IHRoaXMud3JvbmdNYXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvc3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmICh0aGlzLnF1ZXN0aW9uLnR5cGUgPT09IFF1aXpRdWVzdGlvblR5cGUuU0hPUlRfQU5TV0VSKSB7XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgQGlmICghKHRoaXMuc2hvcnRBbnN3ZXJXcm9uZ0Fuc3dlcnMgPiAwKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0LnNob3J0QW5zd2VyQWxsT3JOb3RoaW5nQ29ycmVjdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0cmFuc2xhdGVWYWx1ZXNdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZTogdGhpcy5zY29yZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUXVlc3Rpb25TY29yZTogdGhpcy5xdWVzdGlvbi5wb2ludHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVBvaW50OiB0aGlzLnNjb3JlUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlUG9pbnQ6IHRoaXMucXVlc3Rpb25Qb2ludFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9zcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICA+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAodGhpcy5zaG9ydEFuc3dlcldyb25nQW5zd2VycyA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5zaG9ydEFuc3dlckFsbE9yTm90aGluZ05vdENvcnJlY3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdHJhbnNsYXRlVmFsdWVzXT1cIntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmU6IHRoaXMuc2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVF1ZXN0aW9uU2NvcmU6IHRoaXMucXVlc3Rpb24ucG9pbnRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TaG9ydEFuc3dlcldyb25nT3B0aW9uOiB0aGlzLnNob3J0QW5zd2VyV3JvbmdBbnN3ZXJzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TaG9ydEFuc3dlckNvcnJlY3RBbnN3ZXJzOiB0aGlzLnNob3J0QW5zd2VyQ29ycmVjdEFuc3dlcnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVBvaW50OiB0aGlzLnNjb3JlUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlUG9pbnQ6IHRoaXMucXVlc3Rpb25Qb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0R2FwOiB0aGlzLnJpZ2h0R2FwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd3JvbmdHYXA6IHRoaXMud3JvbmdHYXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvc3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmICh0aGlzLnF1ZXN0aW9uLnNjb3JpbmdUeXBlID09PSBTY29yaW5nVHlwZS5QUk9QT1JUSU9OQUxfV0lUSF9QRU5BTFRZKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1ib2R5XCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImZvbnQtd2VpZ2h0LWJvbGRcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuc2NvcmluZ1R5cGVQcm9wb3J0aW9uYWxcIj48L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuc2NvcmluZ1R5cGVQcm9wb3J0aW9uYWxFeHBsYW5hdGlvblwiPjwvc3Bhbj5cbiAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgQGlmICh0aGlzLnF1ZXN0aW9uLnR5cGUgPT09IFF1aXpRdWVzdGlvblR5cGUuTVVMVElQTEVfQ0hPSUNFKSB7XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgQGlmICh0aGlzLmNvcnJlY3RNdWx0aXBsZUNob2ljZUFuc3dlcnMgPT0gdGhpcy5tdWx0aXBsZUNob2ljZUNvcnJlY3RBbnN3ZXJDb3JyZWN0bHlDaG9zZW4gJiYgdGhpcy5tdWx0aXBsZUNob2ljZVdyb25nQW5zd2VyQ2hvc2VuID09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5tdWx0aXBsZUNob2ljZUFsbE9yTm90aGluZ0NvcnJlY3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdHJhbnNsYXRlVmFsdWVzXT1cIntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmU6IHRoaXMuc2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVF1ZXN0aW9uU2NvcmU6IHRoaXMucXVlc3Rpb24ucG9pbnRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Qb2ludDogdGhpcy5zY29yZVBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZVBvaW50OiB0aGlzLnF1ZXN0aW9uUG9pbnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvc3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgISh0aGlzLmNvcnJlY3RNdWx0aXBsZUNob2ljZUFuc3dlcnMgPT0gdGhpcy5tdWx0aXBsZUNob2ljZUNvcnJlY3RBbnN3ZXJDb3JyZWN0bHlDaG9zZW4gJiYgdGhpcy5tdWx0aXBsZUNob2ljZVdyb25nQW5zd2VyQ2hvc2VuID09IDApICYmXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRpZmZlcmVuY2VNdWx0aXBsZUNob2ljZSA+PSAwXG4gICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0Lm11bHRpcGxlQ2hvaWNlUHJvcFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0cmFuc2xhdGVWYWx1ZXNdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZTogdGhpcy5zY29yZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUXVlc3Rpb25TY29yZTogdGhpcy5xdWVzdGlvbi5wb2ludHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbUFtb3VudE9mQW5zd2VyT3B0aW9uczogdGhpcy5tdWx0aXBsZUNob2ljZUFuc3dlck9wdGlvbnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbUluVG90YWxXcm9uZ09wdGlvbnM6IHRoaXMuaW5Ub3RhbFNlbGVjdGVkV3JvbmdPcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1JblRvdGFsUmlnaHRPcHRpb25zOiB0aGlzLmluVG90YWxTZWxlY3RlZFJpZ2h0T3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUG9pbnQ6IHRoaXMuc2NvcmVQb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmVQb2ludDogdGhpcy5xdWVzdGlvblBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd3JvbmdPcHRpb246IHRoaXMud3JvbmdPcHRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByaWdodE9wdGlvbjogdGhpcy5yaWdodE9wdGlvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID4rIHt7IHRoaXMuaW5Ub3RhbFNlbGVjdGVkUmlnaHRPcHRpb25zIH19Knt7IHRoaXMucXVlc3Rpb24ucG9pbnRzIH19IC97eyB0aGlzLm11bHRpcGxlQ2hvaWNlQW5zd2VyT3B0aW9ucyB9fSAtXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IHRoaXMuaW5Ub3RhbFNlbGVjdGVkV3JvbmdPcHRpb25zIH19Knt7IHRoaXMucXVlc3Rpb24ucG9pbnRzIH19L3t7IHRoaXMubXVsdGlwbGVDaG9pY2VBbnN3ZXJPcHRpb25zIH19ID0ge3sgdGhpcy5zY29yZSB9fTwvYlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuS2VlcFRyeWluZ1wiPjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgISh0aGlzLmNvcnJlY3RNdWx0aXBsZUNob2ljZUFuc3dlcnMgPT0gdGhpcy5tdWx0aXBsZUNob2ljZUNvcnJlY3RBbnN3ZXJDb3JyZWN0bHlDaG9zZW4gJiYgdGhpcy5tdWx0aXBsZUNob2ljZVdyb25nQW5zd2VyQ2hvc2VuID09IDApICYmXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRpZmZlcmVuY2VNdWx0aXBsZUNob2ljZSA8IDBcbiAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQubXVsdGlwbGVDaG9pY2VQcm9wXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3RyYW5zbGF0ZVZhbHVlc109XCJ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlOiB0aGlzLnNjb3JlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1RdWVzdGlvblNjb3JlOiB0aGlzLnF1ZXN0aW9uLnBvaW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtQW1vdW50T2ZBbnN3ZXJPcHRpb25zOiB0aGlzLm11bHRpcGxlQ2hvaWNlQW5zd2VyT3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtSW5Ub3RhbFdyb25nT3B0aW9uczogdGhpcy5pblRvdGFsU2VsZWN0ZWRXcm9uZ09wdGlvbnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbUluVG90YWxSaWdodE9wdGlvbnM6IHRoaXMuaW5Ub3RhbFNlbGVjdGVkUmlnaHRPcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Qb2ludDogdGhpcy5zY29yZVBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZVBvaW50OiB0aGlzLnF1ZXN0aW9uUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3cm9uZ09wdGlvbjogdGhpcy53cm9uZ09wdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0T3B0aW9uOiB0aGlzLnJpZ2h0T3B0aW9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPisge3sgdGhpcy5pblRvdGFsU2VsZWN0ZWRSaWdodE9wdGlvbnMgfX0qe3sgdGhpcy5xdWVzdGlvbi5wb2ludHMgfX0gL3t7IHRoaXMubXVsdGlwbGVDaG9pY2VBbnN3ZXJPcHRpb25zIH19IC1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgdGhpcy5pblRvdGFsU2VsZWN0ZWRXcm9uZ09wdGlvbnMgfX0qe3sgdGhpcy5xdWVzdGlvbi5wb2ludHMgfX0ve3sgdGhpcy5tdWx0aXBsZUNob2ljZUFuc3dlck9wdGlvbnMgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPSAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9iPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC56ZXJvUG9pbnRlclwiPjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuS2VlcFRyeWluZ1wiPjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmICh0aGlzLnF1ZXN0aW9uLnR5cGUgPT09IFF1aXpRdWVzdGlvblR5cGUuRFJBR19BTkRfRFJPUCkge1xuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAodGhpcy5pbmNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXMgPT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0LmRyYWdBbmREcm9wQWxsT3JOb3RoaW5nQ29ycmVjdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0cmFuc2xhdGVWYWx1ZXNdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZTogdGhpcy5zY29yZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUXVlc3Rpb25TY29yZTogdGhpcy5xdWVzdGlvbi5wb2ludHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVBvaW50OiB0aGlzLnNjb3JlUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlUG9pbnQ6IHRoaXMucXVlc3Rpb25Qb2ludFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9zcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICA+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAodGhpcy5pbmNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXMgIT0gMCAmJiB0aGlzLmRpZmZlcmVuY2VEcmFnQW5kRHJvcCA+PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuZHJhZ0FuZERyb3BQcm9wXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3RyYW5zbGF0ZVZhbHVlc109XCJ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlOiB0aGlzLnNjb3JlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1RdWVzdGlvblNjb3JlOiB0aGlzLnF1ZXN0aW9uLnBvaW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtV3JvbmdNYXBwZWRJdGVtczogdGhpcy5pbmNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVJpZ2h0TWFwcGluZzogdGhpcy5jb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1EcmFnQW5kRHJvcEVsZW1lbnRzQ291bnQ6IHRoaXMubWFwcGVkTG9jYXRpb25zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Qb2ludDogdGhpcy5zY29yZVBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZVBvaW50OiB0aGlzLnF1ZXN0aW9uUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByaWdodE1hcDogdGhpcy5yaWdodE1hcCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdyb25nTWFwOiB0aGlzLndyb25nTWFwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPisge3sgdGhpcy5jb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zIH19Knt7IHRoaXMucXVlc3Rpb24ucG9pbnRzIH19L3t7IHRoaXMubWFwcGVkTG9jYXRpb25zIH19IC1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgdGhpcy5pbmNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXMgfX0qe3sgdGhpcy5xdWVzdGlvbi5wb2ludHMgfX0ve3sgdGhpcy5tYXBwZWRMb2NhdGlvbnMgfX0gPSB7eyB0aGlzLnNjb3JlIH19PC9iXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5LZWVwVHJ5aW5nXCI+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAodGhpcy5pbmNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXMgIT0gMCAmJiB0aGlzLmRpZmZlcmVuY2VEcmFnQW5kRHJvcCA8IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5kcmFnQW5kRHJvcFByb3BcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdHJhbnNsYXRlVmFsdWVzXT1cIntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmU6IHRoaXMuc2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVF1ZXN0aW9uU2NvcmU6IHRoaXMucXVlc3Rpb24ucG9pbnRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Xcm9uZ01hcHBlZEl0ZW1zOiB0aGlzLmluY29ycmVjdGx5TWFwcGVkRHJhZ0FuZERyb3BJdGVtcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUmlnaHRNYXBwaW5nOiB0aGlzLmNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbURyYWdBbmREcm9wRWxlbWVudHNDb3VudDogdGhpcy5tYXBwZWRMb2NhdGlvbnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVBvaW50OiB0aGlzLnNjb3JlUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlUG9pbnQ6IHRoaXMucXVlc3Rpb25Qb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0TWFwOiB0aGlzLnJpZ2h0TWFwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd3JvbmdNYXA6IHRoaXMud3JvbmdNYXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+KyB7eyB0aGlzLmNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXMgfX0qe3sgdGhpcy5xdWVzdGlvbi5wb2ludHMgfX0ve3sgdGhpcy5tYXBwZWRMb2NhdGlvbnMgfX0gLVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyB0aGlzLmluY29ycmVjdGx5TWFwcGVkRHJhZ0FuZERyb3BJdGVtcyB9fSp7eyB0aGlzLnF1ZXN0aW9uLnBvaW50cyB9fS97eyB0aGlzLm1hcHBlZExvY2F0aW9ucyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA9IDBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0Lnplcm9Qb2ludGVyXCI+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5LZWVwVHJ5aW5nXCI+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKHRoaXMucXVlc3Rpb24udHlwZSA9PT0gUXVpelF1ZXN0aW9uVHlwZS5TSE9SVF9BTlNXRVIpIHtcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICBAaWYgKHRoaXMuc2hvcnRBbnN3ZXJXcm9uZ0Fuc3dlcnMgPD0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0LnNob3J0QW5zd2VyQWxsT3JOb3RoaW5nQ29ycmVjdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0cmFuc2xhdGVWYWx1ZXNdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZTogdGhpcy5zY29yZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUXVlc3Rpb25TY29yZTogdGhpcy5xdWVzdGlvbi5wb2ludHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVBvaW50OiB0aGlzLnNjb3JlUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlUG9pbnQ6IHRoaXMucXVlc3Rpb25Qb2ludFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9zcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICA+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAodGhpcy5zaG9ydEFuc3dlcldyb25nQW5zd2VycyA+IDAgJiYgdGhpcy5kaWZmZXJlbmNlU2hvcnRBbnN3ZXIgPj0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0LnNob3J0QW5zd2VyUHJvcFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0cmFuc2xhdGVWYWx1ZXNdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZTogdGhpcy5zY29yZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUXVlc3Rpb25TY29yZTogdGhpcy5xdWVzdGlvbi5wb2ludHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNob3J0QW5zd2VyV3JvbmdPcHRpb246IHRoaXMuc2hvcnRBbnN3ZXJXcm9uZ0Fuc3dlcnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNob3J0QW5zd2VyQ29ycmVjdEFuc3dlcnM6IHRoaXMuc2hvcnRBbnN3ZXJDb3JyZWN0QW5zd2VycyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtQ291bnQ6IHRoaXMuc2hvcnRBbnN3ZXJTcG90cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUG9pbnQ6IHRoaXMuc2NvcmVQb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmVQb2ludDogdGhpcy5xdWVzdGlvblBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHRHYXA6IHRoaXMucmlnaHRHYXAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3cm9uZ0dhcDogdGhpcy53cm9uZ0dhcFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID4rIHt7IHRoaXMuc2hvcnRBbnN3ZXJDb3JyZWN0QW5zd2VycyB9fSp7eyB0aGlzLnF1ZXN0aW9uLnBvaW50cyB9fS97eyB0aGlzLnNob3J0QW5zd2VyU3BvdHMgfX0gLSB7eyB0aGlzLnNob3J0QW5zd2VyV3JvbmdBbnN3ZXJzIH19Knt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnF1ZXN0aW9uLnBvaW50c1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fS97eyB0aGlzLnNob3J0QW5zd2VyU3BvdHMgfX0gPSB7eyB0aGlzLnNjb3JlIH19PC9iXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5LZWVwVHJ5aW5nXCI+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAodGhpcy5zaG9ydEFuc3dlcldyb25nQW5zd2VycyA+IDAgJiYgdGhpcy5kaWZmZXJlbmNlU2hvcnRBbnN3ZXIgPCAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuc2hvcnRBbnN3ZXJQcm9wXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3RyYW5zbGF0ZVZhbHVlc109XCJ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlOiB0aGlzLnNjb3JlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1RdWVzdGlvblNjb3JlOiB0aGlzLnF1ZXN0aW9uLnBvaW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2hvcnRBbnN3ZXJXcm9uZ09wdGlvbjogdGhpcy5zaG9ydEFuc3dlcldyb25nQW5zd2VycyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2hvcnRBbnN3ZXJDb3JyZWN0QW5zd2VyczogdGhpcy5zaG9ydEFuc3dlckNvcnJlY3RBbnN3ZXJzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Db3VudDogdGhpcy5zaG9ydEFuc3dlclNwb3RzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Qb2ludDogdGhpcy5zY29yZVBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZVBvaW50OiB0aGlzLnF1ZXN0aW9uUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByaWdodEdhcDogdGhpcy5yaWdodEdhcCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdyb25nR2FwOiB0aGlzLndyb25nR2FwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPisge3sgdGhpcy5zaG9ydEFuc3dlckNvcnJlY3RBbnN3ZXJzIH19Knt7IHRoaXMucXVlc3Rpb24ucG9pbnRzIH19L3t7IHRoaXMuc2hvcnRBbnN3ZXJTcG90cyB9fSAtIHt7IHRoaXMuc2hvcnRBbnN3ZXJXcm9uZ0Fuc3dlcnMgfX0qe3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucXVlc3Rpb24ucG9pbnRzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19L3t7IHRoaXMuc2hvcnRBbnN3ZXJTcG90cyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA9IDBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0Lnplcm9Qb2ludGVyXCI+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5LZWVwVHJ5aW5nXCI+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICBAaWYgKHRoaXMucXVlc3Rpb24uc2NvcmluZ1R5cGUgPT09IFNjb3JpbmdUeXBlLlBST1BPUlRJT05BTF9XSVRIT1VUX1BFTkFMVFkpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWJvZHlcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC13ZWlnaHQtYm9sZFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5zY29yaW5nVHlwZVByb3BvcnRpb25hbFdpdGhvdXRcIj48L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuc2NvcmluZ1R5cGVQcm9wb3J0aW9uYWxXaXRob3V0RXhwbGFuYXRpb25cIj48L3NwYW4+XG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIEBpZiAodGhpcy5xdWVzdGlvbi50eXBlID09PSBRdWl6UXVlc3Rpb25UeXBlLk1VTFRJUExFX0NIT0lDRSkge1xuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAodGhpcy5jb3JyZWN0TXVsdGlwbGVDaG9pY2VBbnN3ZXJzID09IHRoaXMubXVsdGlwbGVDaG9pY2VDb3JyZWN0QW5zd2VyQ29ycmVjdGx5Q2hvc2VuICYmIHRoaXMubXVsdGlwbGVDaG9pY2VXcm9uZ0Fuc3dlckNob3NlbiA9PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQubXVsdGlwbGVDaG9pY2VBbGxPck5vdGhpbmdDb3JyZWN0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3RyYW5zbGF0ZVZhbHVlc109XCJ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlOiB0aGlzLnNjb3JlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1RdWVzdGlvblNjb3JlOiB0aGlzLnF1ZXN0aW9uLnBvaW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUG9pbnQ6IHRoaXMuc2NvcmVQb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmVQb2ludDogdGhpcy5xdWVzdGlvblBvaW50XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L3NwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgID48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICEodGhpcy5jb3JyZWN0TXVsdGlwbGVDaG9pY2VBbnN3ZXJzID09IHRoaXMubXVsdGlwbGVDaG9pY2VDb3JyZWN0QW5zd2VyQ29ycmVjdGx5Q2hvc2VuICYmIHRoaXMubXVsdGlwbGVDaG9pY2VXcm9uZ0Fuc3dlckNob3NlbiA9PSAwKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaWZmZXJlbmNlTXVsdGlwbGVDaG9pY2UgPj0gMFxuICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5tdWx0aXBsZUNob2ljZVByb3BcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdHJhbnNsYXRlVmFsdWVzXT1cIntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmU6IHRoaXMuc2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVF1ZXN0aW9uU2NvcmU6IHRoaXMucXVlc3Rpb24ucG9pbnRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1BbW91bnRPZkFuc3dlck9wdGlvbnM6IHRoaXMubXVsdGlwbGVDaG9pY2VBbnN3ZXJPcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1JblRvdGFsV3JvbmdPcHRpb25zOiB0aGlzLmluVG90YWxTZWxlY3RlZFdyb25nT3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtSW5Ub3RhbFJpZ2h0T3B0aW9uczogdGhpcy5pblRvdGFsU2VsZWN0ZWRSaWdodE9wdGlvbnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVBvaW50OiB0aGlzLnNjb3JlUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlUG9pbnQ6IHRoaXMucXVlc3Rpb25Qb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdyb25nT3B0aW9uOiB0aGlzLndyb25nT3B0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHRPcHRpb246IHRoaXMucmlnaHRPcHRpb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Yj4rIHt7IHRoaXMuaW5Ub3RhbFNlbGVjdGVkUmlnaHRPcHRpb25zIH19Knt7IHRoaXMucXVlc3Rpb24ucG9pbnRzIH19IC97eyB0aGlzLm11bHRpcGxlQ2hvaWNlQW5zd2VyT3B0aW9ucyB9fSA9IHt7IHRoaXMuc2NvcmUgfX08L2I+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0LktlZXBUcnlpbmdcIj48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICEodGhpcy5jb3JyZWN0TXVsdGlwbGVDaG9pY2VBbnN3ZXJzID09IHRoaXMubXVsdGlwbGVDaG9pY2VDb3JyZWN0QW5zd2VyQ29ycmVjdGx5Q2hvc2VuICYmIHRoaXMubXVsdGlwbGVDaG9pY2VXcm9uZ0Fuc3dlckNob3NlbiA9PSAwKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaWZmZXJlbmNlTXVsdGlwbGVDaG9pY2UgPCAwXG4gICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0Lm11bHRpcGxlQ2hvaWNlUHJvcFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0cmFuc2xhdGVWYWx1ZXNdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZTogdGhpcy5zY29yZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUXVlc3Rpb25TY29yZTogdGhpcy5xdWVzdGlvbi5wb2ludHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbUFtb3VudE9mQW5zd2VyT3B0aW9uczogdGhpcy5tdWx0aXBsZUNob2ljZUFuc3dlck9wdGlvbnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbUluVG90YWxXcm9uZ09wdGlvbnM6IHRoaXMuaW5Ub3RhbFNlbGVjdGVkV3JvbmdPcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1JblRvdGFsUmlnaHRPcHRpb25zOiB0aGlzLmluVG90YWxTZWxlY3RlZFJpZ2h0T3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUG9pbnQ6IHRoaXMuc2NvcmVQb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmVQb2ludDogdGhpcy5xdWVzdGlvblBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd3JvbmdPcHRpb246IHRoaXMud3JvbmdPcHRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByaWdodE9wdGlvbjogdGhpcy5yaWdodE9wdGlvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiPisge3sgdGhpcy5pblRvdGFsU2VsZWN0ZWRSaWdodE9wdGlvbnMgfX0qe3sgdGhpcy5xdWVzdGlvbi5wb2ludHMgfX0gL3t7IHRoaXMubXVsdGlwbGVDaG9pY2VBbnN3ZXJPcHRpb25zIH19ID0gMCA8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0LktlZXBUcnlpbmdcIj48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAodGhpcy5xdWVzdGlvbi50eXBlID09PSBRdWl6UXVlc3Rpb25UeXBlLkRSQUdfQU5EX0RST1ApIHtcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICBAaWYgKHRoaXMuaW5jb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zID09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5kcmFnQW5kRHJvcEFsbE9yTm90aGluZ0NvcnJlY3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdHJhbnNsYXRlVmFsdWVzXT1cIntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmU6IHRoaXMuc2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVF1ZXN0aW9uU2NvcmU6IHRoaXMucXVlc3Rpb24ucG9pbnRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Qb2ludDogdGhpcy5zY29yZVBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZVBvaW50OiB0aGlzLnF1ZXN0aW9uUG9pbnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvc3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKHRoaXMuaW5jb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zICE9IDAgJiYgdGhpcy5kaWZmZXJlbmNlRHJhZ0FuZERyb3AgPj0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0LmRyYWdBbmREcm9wUHJvcFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0cmFuc2xhdGVWYWx1ZXNdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZTogdGhpcy5zY29yZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUXVlc3Rpb25TY29yZTogdGhpcy5xdWVzdGlvbi5wb2ludHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVdyb25nTWFwcGVkSXRlbXM6IHRoaXMuaW5jb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1SaWdodE1hcHBpbmc6IHRoaXMuY29ycmVjdGx5TWFwcGVkRHJhZ0FuZERyb3BJdGVtcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtRHJhZ0FuZERyb3BFbGVtZW50c0NvdW50OiB0aGlzLm1hcHBlZExvY2F0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUG9pbnQ6IHRoaXMuc2NvcmVQb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmVQb2ludDogdGhpcy5xdWVzdGlvblBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHRNYXA6IHRoaXMucmlnaHRNYXAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3cm9uZ01hcDogdGhpcy53cm9uZ01hcFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiPisge3sgdGhpcy5jb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zIH19Knt7IHRoaXMucXVlc3Rpb24ucG9pbnRzIH19L3t7IHRoaXMubWFwcGVkTG9jYXRpb25zIH19ID0ge3sgdGhpcy5zY29yZSB9fTwvYj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuS2VlcFRyeWluZ1wiPjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKHRoaXMuaW5jb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zICE9IDAgJiYgdGhpcy5kaWZmZXJlbmNlRHJhZ0FuZERyb3AgPCAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuZHJhZ0FuZERyb3BQcm9wXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3RyYW5zbGF0ZVZhbHVlc109XCJ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlOiB0aGlzLnNjb3JlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1RdWVzdGlvblNjb3JlOiB0aGlzLnF1ZXN0aW9uLnBvaW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtV3JvbmdNYXBwZWRJdGVtczogdGhpcy5pbmNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVJpZ2h0TWFwcGluZzogdGhpcy5jb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1EcmFnQW5kRHJvcEVsZW1lbnRzQ291bnQ6IHRoaXMubWFwcGVkTG9jYXRpb25zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Qb2ludDogdGhpcy5zY29yZVBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZVBvaW50OiB0aGlzLnF1ZXN0aW9uUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByaWdodE1hcDogdGhpcy5yaWdodE1hcCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdyb25nTWFwOiB0aGlzLndyb25nTWFwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGI+KyB7eyB0aGlzLmNvcnJlY3RseU1hcHBlZERyYWdBbmREcm9wSXRlbXMgfX0qe3sgdGhpcy5xdWVzdGlvbi5wb2ludHMgfX0ve3sgdGhpcy5tYXBwZWRMb2NhdGlvbnMgfX0gPSAwIDwvYj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuemVyb1BvaW50ZXJcIj48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0LktlZXBUcnlpbmdcIj48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAodGhpcy5xdWVzdGlvbi50eXBlID09PSBRdWl6UXVlc3Rpb25UeXBlLlNIT1JUX0FOU1dFUikge1xuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAodGhpcy5zaG9ydEFuc3dlcldyb25nQW5zd2VycyA8PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuc2hvcnRBbnN3ZXJBbGxPck5vdGhpbmdDb3JyZWN0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3RyYW5zbGF0ZVZhbHVlc109XCJ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlOiB0aGlzLnNjb3JlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1RdWVzdGlvblNjb3JlOiB0aGlzLnF1ZXN0aW9uLnBvaW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUG9pbnQ6IHRoaXMuc2NvcmVQb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmVQb2ludDogdGhpcy5xdWVzdGlvblBvaW50XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L3NwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgID48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQGlmICh0aGlzLnNob3J0QW5zd2VyV3JvbmdBbnN3ZXJzID4gMCAmJiB0aGlzLmRpZmZlcmVuY2VTaG9ydEFuc3dlciA+PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuc2hvcnRBbnN3ZXJQcm9wXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3RyYW5zbGF0ZVZhbHVlc109XCJ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNjb3JlOiB0aGlzLnNjb3JlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1RdWVzdGlvblNjb3JlOiB0aGlzLnF1ZXN0aW9uLnBvaW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2hvcnRBbnN3ZXJXcm9uZ09wdGlvbjogdGhpcy5zaG9ydEFuc3dlcldyb25nQW5zd2VycyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2hvcnRBbnN3ZXJDb3JyZWN0QW5zd2VyczogdGhpcy5zaG9ydEFuc3dlckNvcnJlY3RBbnN3ZXJzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Db3VudDogdGhpcy5zaG9ydEFuc3dlclNwb3RzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1Qb2ludDogdGhpcy5zY29yZVBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZVBvaW50OiB0aGlzLnF1ZXN0aW9uUG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByaWdodEdhcDogdGhpcy5yaWdodEdhcCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdyb25nR2FwOiB0aGlzLndyb25nR2FwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGI+KyB7eyB0aGlzLnNob3J0QW5zd2VyQ29ycmVjdEFuc3dlcnMgfX0qe3sgdGhpcy5xdWVzdGlvbi5wb2ludHMgfX0ve3sgdGhpcy5zaG9ydEFuc3dlclNwb3RzIH19ID0ge3sgdGhpcy5zY29yZSB9fTwvYj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvblRleHQuS2VlcFRyeWluZ1wiPjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKHRoaXMuc2hvcnRBbnN3ZXJXcm9uZ0Fuc3dlcnMgPiAwICYmIHRoaXMuZGlmZmVyZW5jZVNob3J0QW5zd2VyIDwgMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25UZXh0LnNob3J0QW5zd2VyUHJvcFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0cmFuc2xhdGVWYWx1ZXNdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1TY29yZTogdGhpcy5zY29yZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUXVlc3Rpb25TY29yZTogdGhpcy5xdWVzdGlvbi5wb2ludHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNob3J0QW5zd2VyV3JvbmdPcHRpb246IHRoaXMuc2hvcnRBbnN3ZXJXcm9uZ0Fuc3dlcnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbVNob3J0QW5zd2VyQ29ycmVjdEFuc3dlcnM6IHRoaXMuc2hvcnRBbnN3ZXJDb3JyZWN0QW5zd2VycyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtQ291bnQ6IHRoaXMuc2hvcnRBbnN3ZXJTcG90cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtUG9pbnQ6IHRoaXMuc2NvcmVQb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtU2NvcmVQb2ludDogdGhpcy5xdWVzdGlvblBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHRHYXA6IHRoaXMucmlnaHRHYXAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3cm9uZ0dhcDogdGhpcy53cm9uZ0dhcFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiPisge3sgdGhpcy5zaG9ydEFuc3dlckNvcnJlY3RBbnN3ZXJzIH19Knt7IHRoaXMucXVlc3Rpb24ucG9pbnRzIH19L3t7IHRoaXMuc2hvcnRBbnN3ZXJTcG90cyB9fSA9IDAgPC9iPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmV4cGxhbmF0aW9uVGV4dC5LZWVwVHJ5aW5nXCI+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtZm9vdGVyXCI+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuIGJ0bi1vdXRsaW5lXCIgKGNsaWNrKT1cImMoKVwiPkNsb3NlPC9idXR0b24+XG4gICAgPC9kaXY+XG48L25nLXRlbXBsYXRlPlxuPGRpdj5cbiAgICA8YnV0dG9uIGNsYXNzPVwiYnRuXCIgKGNsaWNrKT1cIm9wZW4oc2NvcmluZ0V4cGxhbmF0aW9uKVwiPlxuICAgICAgICA8ZmEtaWNvbiBbbmdDbGFzc109XCJ7IHF1ZXN0aW9uQ29ycmVjdDogdGhpcy5zY29yZSA9PT0gdGhpcy5xdWVzdGlvbi5wb2ludHMsIHF1ZXN0aW9uV3Jvbmc6IHRoaXMuc2NvcmUgIT09IHRoaXMucXVlc3Rpb24ucG9pbnRzIH1cIiBbaWNvbl09XCJmYXJRdWVzdGlvbkNpcmNsZVwiPjwvZmEtaWNvbj5cbiAgICA8L2J1dHRvbj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIElucHV0LCBPbkNoYW5nZXMsIE9uSW5pdCwgT3V0cHV0LCBWaWV3Q2hpbGQsIFZpZXdFbmNhcHN1bGF0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBcnRlbWlzTWFya2Rvd25TZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi5zZXJ2aWNlJztcbmltcG9ydCB7IERyYWdBbmREcm9wUXVlc3Rpb25VdGlsIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9xdWl6L3NoYXJlZC9kcmFnLWFuZC1kcm9wLXF1ZXN0aW9uLXV0aWwuc2VydmljZSc7XG5pbXBvcnQgeyBwb2x5ZmlsbCB9IGZyb20gJ21vYmlsZS1kcmFnLWRyb3AnO1xuaW1wb3J0IHsgc2Nyb2xsQmVoYXZpb3VyRHJhZ0ltYWdlVHJhbnNsYXRlT3ZlcnJpZGUgfSBmcm9tICdtb2JpbGUtZHJhZy1kcm9wL3Njcm9sbC1iZWhhdmlvdXInO1xuaW1wb3J0IHsgU2VjdXJlZEltYWdlQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC9pbWFnZS9zZWN1cmVkLWltYWdlLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBEcmFnQW5kRHJvcFF1ZXN0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovZHJhZy1hbmQtZHJvcC1xdWVzdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBEcmFnQW5kRHJvcE1hcHBpbmcgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9kcmFnLWFuZC1kcm9wLW1hcHBpbmcubW9kZWwnO1xuaW1wb3J0IHsgUmVuZGVyZWRRdWl6UXVlc3Rpb25NYXJrRG93bkVsZW1lbnQgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9xdWl6LXF1ZXN0aW9uLm1vZGVsJztcbmltcG9ydCB7IERyb3BMb2NhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L2Ryb3AtbG9jYXRpb24ubW9kZWwnO1xuaW1wb3J0IHsgZmFFeGNsYW1hdGlvbkNpcmNsZSwgZmFFeGNsYW1hdGlvblRyaWFuZ2xlLCBmYVF1ZXN0aW9uQ2lyY2xlLCBmYVNwaW5uZXIgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgQ2RrRHJhZ0Ryb3AgfSBmcm9tICdAYW5ndWxhci9jZGsvZHJhZy1kcm9wJztcbmltcG9ydCB7IERyYWdJdGVtIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovZHJhZy1pdGVtLm1vZGVsJztcblxuLy8gb3B0aW9ucyBhcmUgb3B0aW9uYWwgOylcbnBvbHlmaWxsKHtcbiAgICAvLyB1c2UgdGhpcyB0byBtYWtlIHVzZSBvZiB0aGUgc2Nyb2xsIGJlaGF2aW91clxuICAgIGRyYWdJbWFnZVRyYW5zbGF0ZU92ZXJyaWRlOiBzY3JvbGxCZWhhdmlvdXJEcmFnSW1hZ2VUcmFuc2xhdGVPdmVycmlkZSxcbn0pO1xuXG4vLyBEcmFnLWVudGVyIGxpc3RlbmVyIGZvciBtb2JpbGUgZGV2aWNlczogd2l0aG91dCB0aGlzIGNvZGUsIG1vYmlsZSBkcmFnIGFuZCBkcm9wIHdpbGwgbm90IHdvcmsgY29ycmVjdGx5IVxuKGV2ZW50OiBhbnkpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xufTtcbi8qIGVzbGludC1lbmFibGUgKi9cbndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCd0b3VjaG1vdmUnLCAoKSA9PiB7fSwgeyBwYXNzaXZlOiBmYWxzZSB9KTtcblxuZW51bSBNYXBwaW5nUmVzdWx0IHtcbiAgICBNQVBQRURfQ09SUkVDVCxcbiAgICBNQVBQRURfSU5DT1JSRUNULFxuICAgIE5PVF9NQVBQRUQsXG59XG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1kcmFnLWFuZC1kcm9wLXF1ZXN0aW9uJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vZHJhZy1hbmQtZHJvcC1xdWVzdGlvbi5jb21wb25lbnQuaHRtbCcsXG4gICAgcHJvdmlkZXJzOiBbRHJhZ0FuZERyb3BRdWVzdGlvblV0aWxdLFxuICAgIHN0eWxlVXJsczogWycuL2RyYWctYW5kLWRyb3AtcXVlc3Rpb24uY29tcG9uZW50LnNjc3MnLCAnLi4vLi4vLi4vcGFydGljaXBhdGUvcXVpei1wYXJ0aWNpcGF0aW9uLnNjc3MnXSxcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxufSlcbmV4cG9ydCBjbGFzcyBEcmFnQW5kRHJvcFF1ZXN0aW9uQ29tcG9uZW50IGltcGxlbWVudHMgT25DaGFuZ2VzLCBPbkluaXQge1xuICAgIC8qKiBuZWVkZWQgdG8gdHJpZ2dlciBhIG1hbnVhbCByZWxvYWQgb2YgdGhlIGRyYWcgYW5kIGRyb3AgYmFja2dyb3VuZCBwaWN0dXJlICovXG4gICAgQFZpZXdDaGlsZChTZWN1cmVkSW1hZ2VDb21wb25lbnQsIHsgc3RhdGljOiBmYWxzZSB9KVxuICAgIHNlY3VyZUltYWdlQ29tcG9uZW50OiBTZWN1cmVkSW1hZ2VDb21wb25lbnQ7XG5cbiAgICBfcXVlc3Rpb246IERyYWdBbmREcm9wUXVlc3Rpb247XG4gICAgX2ZvcmNlU2FtcGxlU29sdXRpb246IGJvb2xlYW47XG5cbiAgICBASW5wdXQoKVxuICAgIHNldCBxdWVzdGlvbihxdWVzdGlvbikge1xuICAgICAgICB0aGlzLl9xdWVzdGlvbiA9IHF1ZXN0aW9uO1xuICAgICAgICB0aGlzLndhdGNoQ29sbGVjdGlvbigpO1xuICAgIH1cbiAgICBnZXQgcXVlc3Rpb24oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9xdWVzdGlvbjtcbiAgICB9XG4gICAgLy8gVE9ETzogTWFwIHZzLiBBcnJheSAtLT4gY29uc2lzdGVuY3lcbiAgICBASW5wdXQoKVxuICAgIG1hcHBpbmdzOiBEcmFnQW5kRHJvcE1hcHBpbmdbXTtcbiAgICBASW5wdXQoKVxuICAgIGNsaWNrRGlzYWJsZWQ6IGJvb2xlYW47XG4gICAgQElucHV0KClcbiAgICBzaG93UmVzdWx0OiBib29sZWFuO1xuICAgIEBJbnB1dCgpXG4gICAgcXVlc3Rpb25JbmRleDogbnVtYmVyO1xuICAgIEBJbnB1dCgpXG4gICAgc2NvcmU6IG51bWJlcjtcbiAgICBASW5wdXQoKVxuICAgIHNldCBmb3JjZVNhbXBsZVNvbHV0aW9uKGZvcmNlU2FtcGxlU29sdXRpb24pIHtcbiAgICAgICAgdGhpcy5fZm9yY2VTYW1wbGVTb2x1dGlvbiA9IGZvcmNlU2FtcGxlU29sdXRpb247XG4gICAgICAgIGlmICh0aGlzLmZvcmNlU2FtcGxlU29sdXRpb24pIHtcbiAgICAgICAgICAgIHRoaXMuc2hvd1NhbXBsZVNvbHV0aW9uKCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZ2V0IGZvcmNlU2FtcGxlU29sdXRpb24oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9mb3JjZVNhbXBsZVNvbHV0aW9uO1xuICAgIH1cbiAgICBASW5wdXQoKVxuICAgIG9uTWFwcGluZ1VwZGF0ZTogYW55O1xuICAgIEBJbnB1dCgpXG4gICAgZmlsZVByZXZpZXdQYXRoczogTWFwPHN0cmluZywgc3RyaW5nPiA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KCk7XG5cbiAgICBAT3V0cHV0KClcbiAgICBtYXBwaW5nc0NoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8RHJhZ0FuZERyb3BNYXBwaW5nW10+KCk7XG5cbiAgICBzaG93aW5nU2FtcGxlU29sdXRpb24gPSBmYWxzZTtcbiAgICByZW5kZXJlZFF1ZXN0aW9uOiBSZW5kZXJlZFF1aXpRdWVzdGlvbk1hcmtEb3duRWxlbWVudDtcbiAgICBzYW1wbGVTb2x1dGlvbk1hcHBpbmdzID0gbmV3IEFycmF5PERyYWdBbmREcm9wTWFwcGluZz4oKTtcbiAgICBkcm9wQWxsb3dlZCA9IGZhbHNlO1xuICAgIGNvcnJlY3RBbnN3ZXI6IG51bWJlcjtcbiAgICBpbmNvcnJlY3RMb2NhdGlvbk1hcHBpbmdzOiBudW1iZXI7XG4gICAgbWFwcGVkTG9jYXRpb25zOiBudW1iZXI7XG5cbiAgICByZWFkb25seSBNYXBwaW5nUmVzdWx0ID0gTWFwcGluZ1Jlc3VsdDtcblxuICAgIGxvYWRpbmdTdGF0ZSA9ICdsb2FkaW5nJztcblxuICAgIC8vIEljb25zXG4gICAgZmFTcGlubmVyID0gZmFTcGlubmVyO1xuICAgIGZhUXVlc3Rpb25DaXJjbGUgPSBmYVF1ZXN0aW9uQ2lyY2xlO1xuICAgIGZhRXhjbGFtYXRpb25UcmlhbmdsZSA9IGZhRXhjbGFtYXRpb25UcmlhbmdsZTtcbiAgICBmYUV4Y2xhbWF0aW9uQ2lyY2xlID0gZmFFeGNsYW1hdGlvbkNpcmNsZTtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGFydGVtaXNNYXJrZG93bjogQXJ0ZW1pc01hcmtkb3duU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBkcmFnQW5kRHJvcFF1ZXN0aW9uVXRpbDogRHJhZ0FuZERyb3BRdWVzdGlvblV0aWwsXG4gICAgKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuZXZhbHVhdGVEcm9wTG9jYXRpb25zKCk7XG4gICAgfVxuXG4gICAgbmdPbkNoYW5nZXMoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuZXZhbHVhdGVEcm9wTG9jYXRpb25zKCk7XG4gICAgfVxuXG4gICAgd2F0Y2hDb2xsZWN0aW9uKCkge1xuICAgICAgICAvLyB1cGRhdGUgaHRtbCBmb3IgdGV4dCwgaGludCBhbmQgZXhwbGFuYXRpb24gZm9yIHRoZSBxdWVzdGlvblxuICAgICAgICB0aGlzLnJlbmRlcmVkUXVlc3Rpb24gPSBuZXcgUmVuZGVyZWRRdWl6UXVlc3Rpb25NYXJrRG93bkVsZW1lbnQoKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlZFF1ZXN0aW9uLnRleHQgPSB0aGlzLmFydGVtaXNNYXJrZG93bi5zYWZlSHRtbEZvck1hcmtkb3duKHRoaXMucXVlc3Rpb24udGV4dCk7XG4gICAgICAgIHRoaXMucmVuZGVyZWRRdWVzdGlvbi5oaW50ID0gdGhpcy5hcnRlbWlzTWFya2Rvd24uc2FmZUh0bWxGb3JNYXJrZG93bih0aGlzLnF1ZXN0aW9uLmhpbnQpO1xuICAgICAgICB0aGlzLnJlbmRlcmVkUXVlc3Rpb24uZXhwbGFuYXRpb24gPSB0aGlzLmFydGVtaXNNYXJrZG93bi5zYWZlSHRtbEZvck1hcmtkb3duKHRoaXMucXVlc3Rpb24uZXhwbGFuYXRpb24pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEhhbmRsZXMgZHJhZy1hdmFpbGFibGUgVUlcbiAgICAgKi9cbiAgICBkcmFnKCkge1xuICAgICAgICB0aGlzLmRyb3BBbGxvd2VkID0gdHJ1ZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIYW5kbGVzIGRyYWctYXZhaWxhYmxlIFVJXG4gICAgICovXG4gICAgZHJvcCgpIHtcbiAgICAgICAgdGhpcy5kcm9wQWxsb3dlZCA9IGZhbHNlO1xuICAgIH1cblxuICAgIC8qKiBTZXRzIHRoZSB2aWV3IGRpc3BsYXllZCB0byB0aGUgdXNlclxuICAgICAqIEBwYXJhbSB7T3V0cHV0fSB2YWx1ZSAtPiBsb2FkaW5nOiBiYWNrZ3JvdW5kIHBpY3R1cmUgZm9yIGRyYWcgYW5kIGRyb3AgcXVlc3Rpb24gaXMgY3VycmVudGx5IGxvYWRpbmdcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgc3VjY2VzczogYmFja2dyb3VuZCBwaWN0dXJlIGZvciBkcmFnIGFuZCBkcm9wIHF1ZXN0aW9uIHdhcyBsb2FkZWRcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3I6IGFuIGVycm9yIG9jY3VycmVkIGR1cmluZyBiYWNrZ3JvdW5kIGRvd25sb2FkICovXG4gICAgY2hhbmdlTG9hZGluZyh2YWx1ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMubG9hZGluZ1N0YXRlID0gdmFsdWU7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUHJldmVudCBzY3JvbGxpbmcgd2hlbiBkcmFnZ2luZyBlbGVtZW50cyBvbiBtb2JpbGUgZGV2aWNlc1xuICAgICAqIEBwYXJhbSBldmVudFxuICAgICAqL1xuICAgIHByZXZlbnREZWZhdWx0KGV2ZW50OiBhbnkpIHtcbiAgICAgICAgZXZlbnQubW91c2VFdmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogcmVhY3QgdG8gdGhlIGRyb3AgZXZlbnQgb2YgYSBkcmFnIGl0ZW1cbiAgICAgKlxuICAgICAqIEBwYXJhbSBkcm9wTG9jYXRpb24ge29iamVjdCB8IHVuZGVmaW5lZH0gdGhlIGRyb3BMb2NhdGlvbiB0aGF0IHRoZSBkcmFnIGl0ZW0gd2FzIGRyb3BwZWQgb24uXG4gICAgICogICAgICAgICAgICAgICAgICAgICBNYXkgYmUgdW5kZWZpbmVkIGlmIGRyYWcgaXRlbSB3YXMgZHJhZ2dlZCBiYWNrIHRvIHRoZSB1bmFzc2lnbmVkIGl0ZW1zLlxuICAgICAqIEBwYXJhbSBkcm9wRXZlbnQge29iamVjdH0gYW4gZXZlbnQgY29udGFpbmluZyB0aGUgZHJhZyBpdGVtIHRoYXQgd2FzIGRyb3BwZWRcbiAgICAgKi9cbiAgICBvbkRyYWdEcm9wKGRyb3BMb2NhdGlvbjogRHJvcExvY2F0aW9uIHwgdW5kZWZpbmVkLCBkcm9wRXZlbnQ6IENka0RyYWdEcm9wPERyYWdJdGVtLCBEcmFnSXRlbT4pIHtcbiAgICAgICAgdGhpcy5kcm9wKCk7XG4gICAgICAgIGNvbnN0IGRyYWdJdGVtID0gZHJvcEV2ZW50Lml0ZW0uZGF0YSBhcyBEcmFnSXRlbTtcblxuICAgICAgICBpZiAoZHJvcExvY2F0aW9uKSB7XG4gICAgICAgICAgICAvLyBjaGVjayBpZiB0aGlzIG1hcHBpbmcgaXMgbmV3XG4gICAgICAgICAgICBpZiAodGhpcy5kcmFnQW5kRHJvcFF1ZXN0aW9uVXRpbC5pc01hcHBlZFRvZ2V0aGVyKHRoaXMubWFwcGluZ3MsIGRyYWdJdGVtLCBkcm9wTG9jYXRpb24pKSB7XG4gICAgICAgICAgICAgICAgLy8gRG8gbm90aGluZ1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gcmVtb3ZlIGV4aXN0aW5nIG1hcHBpbmdzIHRoYXQgY29udGFpbiB0aGUgZHJvcCBsb2NhdGlvbiBvciBkcmFnIGl0ZW0gYW5kIHNhdmUgdGhlaXIgb2xkIHBhcnRuZXJzXG4gICAgICAgICAgICBsZXQgb2xkRHJhZ0l0ZW07XG4gICAgICAgICAgICBsZXQgb2xkRHJvcExvY2F0aW9uO1xuICAgICAgICAgICAgdGhpcy5tYXBwaW5ncyA9IHRoaXMubWFwcGluZ3MuZmlsdGVyKGZ1bmN0aW9uIChtYXBwaW5nKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuZHJhZ0FuZERyb3BRdWVzdGlvblV0aWwuaXNTYW1lRW50aXR5V2l0aFRlbXBJZChkcm9wTG9jYXRpb24sIG1hcHBpbmcuZHJvcExvY2F0aW9uKSkge1xuICAgICAgICAgICAgICAgICAgICBvbGREcmFnSXRlbSA9IG1hcHBpbmcuZHJhZ0l0ZW07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuZHJhZ0FuZERyb3BRdWVzdGlvblV0aWwuaXNTYW1lRW50aXR5V2l0aFRlbXBJZChkcmFnSXRlbSwgbWFwcGluZy5kcmFnSXRlbSkpIHtcbiAgICAgICAgICAgICAgICAgICAgb2xkRHJvcExvY2F0aW9uID0gbWFwcGluZy5kcm9wTG9jYXRpb247XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9LCB0aGlzKTtcblxuICAgICAgICAgICAgLy8gYWRkIG5ldyBtYXBwaW5nXG4gICAgICAgICAgICB0aGlzLm1hcHBpbmdzLnB1c2gobmV3IERyYWdBbmREcm9wTWFwcGluZyhkcmFnSXRlbSwgZHJvcExvY2F0aW9uKSk7XG5cbiAgICAgICAgICAgIC8vIG1hcCBvbGREcmFnSXRlbSBhbmQgb2xkRHJvcExvY2F0aW9uLCBpZiB0aGV5IGV4aXN0XG4gICAgICAgICAgICAvLyB0aGlzIGZsaXBzIHBvc2l0aW9ucyBvZiBkcmFnIGl0ZW1zIHdoZW4gYSBkcmFnIGl0ZW0gaXMgZHJvcHBlZCBvbiBhIGRyb3AgbG9jYXRpb24gd2l0aCBhbiBleGlzdGluZyBkcmFnIGl0ZW1cbiAgICAgICAgICAgIGlmIChvbGREcmFnSXRlbSAmJiBvbGREcm9wTG9jYXRpb24pIHtcbiAgICAgICAgICAgICAgICB0aGlzLm1hcHBpbmdzLnB1c2gobmV3IERyYWdBbmREcm9wTWFwcGluZyhvbGREcmFnSXRlbSwgb2xkRHJvcExvY2F0aW9uKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBsZW5ndGhCZWZvcmUgPSB0aGlzLm1hcHBpbmdzLmxlbmd0aDtcbiAgICAgICAgICAgIC8vIHJlbW92ZSBleGlzdGluZyBtYXBwaW5nIHRoYXQgY29udGFpbnMgdGhlIGRyYWcgaXRlbVxuICAgICAgICAgICAgdGhpcy5tYXBwaW5ncyA9IHRoaXMubWFwcGluZ3MuZmlsdGVyKGZ1bmN0aW9uIChtYXBwaW5nKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICF0aGlzLmRyYWdBbmREcm9wUXVlc3Rpb25VdGlsLmlzU2FtZUVudGl0eVdpdGhUZW1wSWQobWFwcGluZy5kcmFnSXRlbSwgZHJhZ0l0ZW0pO1xuICAgICAgICAgICAgfSwgdGhpcyk7XG4gICAgICAgICAgICBpZiAodGhpcy5tYXBwaW5ncy5sZW5ndGggPT09IGxlbmd0aEJlZm9yZSkge1xuICAgICAgICAgICAgICAgIC8vIG5vdGhpbmcgY2hhbmdlZCA9PiByZXR1cm4gaGVyZSB0byBza2lwIGNhbGxpbmcgdGhpcy5vbk1hcHBpbmdVcGRhdGUoKVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMubWFwcGluZ3NDaGFuZ2UuZW1pdCh0aGlzLm1hcHBpbmdzKTtcbiAgICAgICAgLyoqIE9ubHkgZXhlY3V0ZSB0aGUgb25NYXBwaW5nVXBkYXRlIGZ1bmN0aW9uIGlmIHdlIHJlY2VpdmVkIHN1Y2ggaW5wdXQgKiovXG4gICAgICAgIGlmICh0aGlzLm9uTWFwcGluZ1VwZGF0ZSkge1xuICAgICAgICAgICAgdGhpcy5vbk1hcHBpbmdVcGRhdGUoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCB0aGUgZHJhZyBpdGVtIHRoYXQgd2FzIG1hcHBlZCB0byB0aGUgZ2l2ZW4gZHJvcCBsb2NhdGlvblxuICAgICAqXG4gICAgICogQHBhcmFtIGRyb3BMb2NhdGlvbiB7b2JqZWN0fSB0aGUgZHJvcCBsb2NhdGlvbiB0aGF0IHRoZSBkcmFnIGl0ZW0gc2hvdWxkIGJlIG1hcHBlZCB0b1xuICAgICAqIEByZXR1cm4ge29iamVjdCB8IHVuZGVmaW5lZH0gdGhlIG1hcHBlZCBkcmFnIGl0ZW0sIG9yIHVuZGVmaW5lZCwgaWYgbm8gZHJhZyBpdGVtIGhhcyBiZWVuIG1hcHBlZCB0byB0aGlzIGxvY2F0aW9uXG4gICAgICovXG4gICAgZHJhZ0l0ZW1Gb3JEcm9wTG9jYXRpb24oZHJvcExvY2F0aW9uOiBEcm9wTG9jYXRpb24pIHtcbiAgICAgICAgaWYgKHRoaXMubWFwcGluZ3MpIHtcbiAgICAgICAgICAgIGNvbnN0IG1hcHBpbmcgPSB0aGlzLm1hcHBpbmdzLmZpbmQoKGxvY2FsTWFwcGluZykgPT4gdGhpcy5kcmFnQW5kRHJvcFF1ZXN0aW9uVXRpbC5pc1NhbWVFbnRpdHlXaXRoVGVtcElkKGxvY2FsTWFwcGluZy5kcm9wTG9jYXRpb24sIGRyb3BMb2NhdGlvbikpO1xuICAgICAgICAgICAgaWYgKG1hcHBpbmcpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbWFwcGluZy5kcmFnSXRlbTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIGludmFsaWREcmFnSXRlbUZvckRyb3BMb2NhdGlvbihkcm9wTG9jYXRpb246IERyb3BMb2NhdGlvbikge1xuICAgICAgICBjb25zdCBpdGVtID0gdGhpcy5kcmFnSXRlbUZvckRyb3BMb2NhdGlvbihkcm9wTG9jYXRpb24pO1xuICAgICAgICByZXR1cm4gaXRlbSA/IGl0ZW0uaW52YWxpZCA6IGZhbHNlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBhbGwgZHJhZyBpdGVtcyB0aGF0IGhhdmUgbm90IGJlZW4gYXNzaWduZWQgdG8gYSBkcm9wIGxvY2F0aW9uIHlldFxuICAgICAqXG4gICAgICogQHJldHVybiB7QXJyYXl9IGFuIGFycmF5IG9mIGFsbCB1bmFzc2lnbmVkIGRyYWcgaXRlbXNcbiAgICAgKi9cbiAgICBnZXRVbmFzc2lnbmVkRHJhZ0l0ZW1zKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5xdWVzdGlvbi5kcmFnSXRlbXM/LmZpbHRlcigoZHJhZ0l0ZW0pID0+IHtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgIXRoaXMubWFwcGluZ3M/LnNvbWUoKG1hcHBpbmcpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZHJhZ0FuZERyb3BRdWVzdGlvblV0aWwuaXNTYW1lRW50aXR5V2l0aFRlbXBJZChtYXBwaW5nLmRyYWdJdGVtLCBkcmFnSXRlbSk7XG4gICAgICAgICAgICAgICAgfSwgdGhpcykgPz8gdHJ1ZVxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSwgdGhpcyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgdGhlIGFzc2lnbmVkIGRyYWcgaXRlbSBmcm9tIHRoZSBnaXZlbiBsb2NhdGlvbiBpcyBjb3JyZWN0XG4gICAgICogKE9ubHkgcG9zc2libGUgaWYgdGhpcy5xdWVzdGlvbi5jb3JyZWN0TWFwcGluZ3MgaXMgYXZhaWxhYmxlKVxuICAgICAqXG4gICAgICogQHBhcmFtIGRyb3BMb2NhdGlvbiB7b2JqZWN0fSB0aGUgZHJvcCBsb2NhdGlvbiB0byBjaGVjayBmb3IgY29ycmVjdG5lc3NcbiAgICAgKiBAcmV0dXJuIHtNYXBwaW5nUmVzdWx0fSBNQVBQRURfQ09SUkVDVCwgaWYgdGhlIGRyb3AgbG9jYXRpb24gaXMgY29ycmVjdCwgTUFQUEVEX0lOQ09SUkVDVCBpZiBub3QgYW5kIE5PVF9NQVBQRUQgaWYgdGhlIGxvY2F0aW9uIGlzIGNvcnJlY3RseSBsZWZ0IGJsYW5rXG4gICAgICovXG4gICAgaXNMb2NhdGlvbkNvcnJlY3QoZHJvcExvY2F0aW9uOiBEcm9wTG9jYXRpb24pOiBNYXBwaW5nUmVzdWx0IHtcbiAgICAgICAgaWYgKCF0aGlzLnF1ZXN0aW9uLmNvcnJlY3RNYXBwaW5ncykge1xuICAgICAgICAgICAgcmV0dXJuIE1hcHBpbmdSZXN1bHQuTUFQUEVEX0lOQ09SUkVDVDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB2YWxpZERyYWdJdGVtcyA9IHRoaXMucXVlc3Rpb24uY29ycmVjdE1hcHBpbmdzXG4gICAgICAgICAgICAuZmlsdGVyKGZ1bmN0aW9uIChtYXBwaW5nKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZHJhZ0FuZERyb3BRdWVzdGlvblV0aWwuaXNTYW1lRW50aXR5V2l0aFRlbXBJZChtYXBwaW5nLmRyb3BMb2NhdGlvbiwgZHJvcExvY2F0aW9uKTtcbiAgICAgICAgICAgIH0sIHRoaXMpXG4gICAgICAgICAgICAubWFwKGZ1bmN0aW9uIChtYXBwaW5nKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1hcHBpbmcuZHJhZ0l0ZW07XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgY29uc3Qgc2VsZWN0ZWRJdGVtID0gdGhpcy5kcmFnSXRlbUZvckRyb3BMb2NhdGlvbihkcm9wTG9jYXRpb24pO1xuXG4gICAgICAgIGlmICghc2VsZWN0ZWRJdGVtKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsaWREcmFnSXRlbXMubGVuZ3RoID09PSAwID8gTWFwcGluZ1Jlc3VsdC5OT1RfTUFQUEVEIDogTWFwcGluZ1Jlc3VsdC5NQVBQRURfSU5DT1JSRUNUO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIHZhbGlkRHJhZ0l0ZW1zLnNvbWUoZnVuY3Rpb24gKGRyYWdJdGVtKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZHJhZ0FuZERyb3BRdWVzdGlvblV0aWwuaXNTYW1lRW50aXR5V2l0aFRlbXBJZChkcmFnSXRlbSwgc2VsZWN0ZWRJdGVtKTtcbiAgICAgICAgICAgIH0sIHRoaXMpXG4gICAgICAgICAgICAgICAgPyBNYXBwaW5nUmVzdWx0Lk1BUFBFRF9DT1JSRUNUXG4gICAgICAgICAgICAgICAgOiBNYXBwaW5nUmVzdWx0Lk1BUFBFRF9JTkNPUlJFQ1Q7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiB0aGVyZSBpcyBhIGRyYWcgaXRlbSBhc3NpZ25lZCB0byB0aGUgZ2l2ZW4gbG9jYXRpb24gaW4gdGhlIHNvbHV0aW9uIG9mIHRoZSBxdWVzdGlvblxuICAgICAqIChPbmx5IHBvc3NpYmxlIGlmIHRoaXMucXVlc3Rpb24uY29ycmVjdE1hcHBpbmdzIGlzIGF2YWlsYWJsZSlcbiAgICAgKlxuICAgICAqIEBwYXJhbSBkcm9wTG9jYXRpb24ge29iamVjdH0gdGhlIGRyb3AgbG9jYXRpb24gdG8gY2hlY2sgZm9yIG1hcHBpbmdcbiAgICAgKiBAcmV0dXJuIHtib29sZWFufSB0cnVlLCBpZiB0aGUgZHJvcCBsb2NhdGlvbiBpcyBwYXJ0IG9mIGEgbWFwcGluZywgb3RoZXJ3aXNlIGZhbHNlLlxuICAgICAqL1xuXG4gICAgaXNBc3NpZ25lZExvY2F0aW9uKGRyb3BMb2NhdGlvbjogRHJvcExvY2F0aW9uKTogYm9vbGVhbiB7XG4gICAgICAgIGlmICghdGhpcy5xdWVzdGlvbi5jb3JyZWN0TWFwcGluZ3MpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5xdWVzdGlvbi5jb3JyZWN0TWFwcGluZ3Muc29tZSgobWFwcGluZykgPT4gdGhpcy5kcmFnQW5kRHJvcFF1ZXN0aW9uVXRpbC5pc1NhbWVFbnRpdHlXaXRoVGVtcElkKGRyb3BMb2NhdGlvbiwgbWFwcGluZy5kcm9wTG9jYXRpb24pKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEaXNwbGF5IGEgc2FtcGxlIHNvbHV0aW9uIGluc3RlYWQgb2YgdGhlIHN0dWRlbnQncyBhbnN3ZXJcbiAgICAgKi9cbiAgICBzaG93U2FtcGxlU29sdXRpb24oKSB7XG4gICAgICAgIHRoaXMuc2FtcGxlU29sdXRpb25NYXBwaW5ncyA9IHRoaXMuZHJhZ0FuZERyb3BRdWVzdGlvblV0aWwuc29sdmUodGhpcy5xdWVzdGlvbiwgdGhpcy5tYXBwaW5ncyk7XG4gICAgICAgIHRoaXMuc2hvd2luZ1NhbXBsZVNvbHV0aW9uID0gdHJ1ZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEaXNwbGF5IHRoZSBzdHVkZW50J3MgYW5zd2VyIGFnYWluXG4gICAgICovXG4gICAgaGlkZVNhbXBsZVNvbHV0aW9uKCkge1xuICAgICAgICB0aGlzLnNob3dpbmdTYW1wbGVTb2x1dGlvbiA9IGZhbHNlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCB0aGUgZHJhZyBpdGVtIHRoYXQgd2FzIG1hcHBlZCB0byB0aGUgZ2l2ZW4gZHJvcCBsb2NhdGlvbiBpbiB0aGUgc2FtcGxlIHNvbHV0aW9uXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZHJvcExvY2F0aW9uIHtvYmplY3R9IHRoZSBkcm9wIGxvY2F0aW9uIHRoYXQgdGhlIGRyYWcgaXRlbSBzaG91bGQgYmUgbWFwcGVkIHRvXG4gICAgICogQHJldHVybiB7RHJhZ0l0ZW0gfCB1bmRlZmluZWR9IHRoZSBtYXBwZWQgZHJhZyBpdGVtLCBvciB1bmRlZmluZWQsIGlmIG5vIGRyYWcgaXRlbSBoYXMgYmVlbiBtYXBwZWQgdG8gdGhpcyBsb2NhdGlvblxuICAgICAqL1xuICAgIGNvcnJlY3REcmFnSXRlbUZvckRyb3BMb2NhdGlvbihkcm9wTG9jYXRpb246IERyb3BMb2NhdGlvbikge1xuICAgICAgICBjb25zdCBkcmFnQW5kRHJvcFF1ZXN0aW9uVXRpbCA9IHRoaXMuZHJhZ0FuZERyb3BRdWVzdGlvblV0aWw7XG4gICAgICAgIGNvbnN0IG1hcHBpbmcgPSB0aGlzLnNhbXBsZVNvbHV0aW9uTWFwcGluZ3MuZmluZChmdW5jdGlvbiAoc29sdXRpb25NYXBwaW5nKSB7XG4gICAgICAgICAgICByZXR1cm4gZHJhZ0FuZERyb3BRdWVzdGlvblV0aWwuaXNTYW1lRW50aXR5V2l0aFRlbXBJZChzb2x1dGlvbk1hcHBpbmcuZHJvcExvY2F0aW9uLCBkcm9wTG9jYXRpb24pO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIG1hcHBpbmc/LmRyYWdJdGVtO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENvdW50IGFuZCBhc3NpZ24gdGhlIGFtb3VudCBvZiByaWdodCBtYXBwaW5ncywgaW5jb3JyZWN0IG1hcHBpbmdzIGFuZCB0aGUgbnVtYmVyIG9mIGRyb3AgbG9jYXRpb25zIHBhcnRpY2lwYXRpbmcgaW4gYXQgbGVhc3Qgb25lIG1hcHBpbmcgZm9yIGEgcXVlc3Rpb25cbiAgICAgKiBieSB1c2luZyB0aGUgaXNMb2NhdGlvbkNvcnJlY3QgTWV0aG9kIGFuZCB0aGUgaXNBc3NpZ25lZExvY2F0aW9uIE1ldGhvZFxuICAgICAqL1xuICAgIGV2YWx1YXRlRHJvcExvY2F0aW9ucygpOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMucXVlc3Rpb24uZHJvcExvY2F0aW9ucykge1xuICAgICAgICAgICAgdGhpcy5jb3JyZWN0QW5zd2VyID0gdGhpcy5xdWVzdGlvbi5kcm9wTG9jYXRpb25zLmZpbHRlcigoZHJvcExvY2F0aW9uKSA9PiB0aGlzLmlzTG9jYXRpb25Db3JyZWN0KGRyb3BMb2NhdGlvbikgPT09IE1hcHBpbmdSZXN1bHQuTUFQUEVEX0NPUlJFQ1QpLmxlbmd0aDtcbiAgICAgICAgICAgIHRoaXMuaW5jb3JyZWN0TG9jYXRpb25NYXBwaW5ncyA9IHRoaXMucXVlc3Rpb24uZHJvcExvY2F0aW9ucy5maWx0ZXIoKGRyb3BMb2NhdGlvbikgPT4gdGhpcy5pc0xvY2F0aW9uQ29ycmVjdChkcm9wTG9jYXRpb24pID09PSBNYXBwaW5nUmVzdWx0Lk1BUFBFRF9JTkNPUlJFQ1QpLmxlbmd0aDtcbiAgICAgICAgICAgIHRoaXMubWFwcGVkTG9jYXRpb25zID0gdGhpcy5xdWVzdGlvbi5kcm9wTG9jYXRpb25zLmZpbHRlcigoZHJvcExvY2F0aW9uKSA9PiB0aGlzLmlzQXNzaWduZWRMb2NhdGlvbihkcm9wTG9jYXRpb24pKS5sZW5ndGg7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCI8ZGl2XG4gICAgY2xhc3M9XCJkbmQtcXVlc3Rpb24gbWFya2Rvd24tcHJldmlld1wiXG4gICAgW25nQ2xhc3NdPVwieyBkaXNhYmxlZDogY2xpY2tEaXNhYmxlZCAmJiAhc2hvd1Jlc3VsdCwgcmVzdWx0OiBzaG93UmVzdWx0ICYmICFmb3JjZVNhbXBsZVNvbHV0aW9uLCBpbmNvcnJlY3Q6IChzY29yZSB8fCAwKSA8IHF1ZXN0aW9uLnBvaW50cyEgJiYgIWZvcmNlU2FtcGxlU29sdXRpb24gfVwiXG4+XG4gICAgPGRpdiBbaGlkZGVuXT1cImxvYWRpbmdTdGF0ZSA9PT0gJ3N1Y2Nlc3MnXCI+XG4gICAgICAgIEBpZiAobG9hZGluZ1N0YXRlICE9PSAnZXJyb3InKSB7XG4gICAgICAgICAgICA8aDI+XG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9XCJjb2xvcjogZ3JleVwiXG4gICAgICAgICAgICAgICAgICAgID48ZmEtaWNvbiBbaWNvbl09XCJmYVNwaW5uZXJcIiBbc3Bpbl09XCJ0cnVlXCI+PC9mYS1pY29uPiZuYnNwOzxzcGFuPnt7ICdhcnRlbWlzQXBwLnF1aXpRdWVzdGlvbi5sb2FkaW5nJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+PC9zcGFuXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgfVxuICAgICAgICBAaWYgKGxvYWRpbmdTdGF0ZSA9PT0gJ2Vycm9yJykge1xuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPVwiY29sb3I6IGdyZXlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPjxmYS1pY29uIFtpY29uXT1cImZhRXhjbGFtYXRpb25DaXJjbGVcIj48L2ZhLWljb24+Jm5ic3A7PHNwYW4+e3sgJ2FydGVtaXNBcHAucXVpelF1ZXN0aW9uLmZhaWxlZCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPjwvc3BhblxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdFwiIChjbGljayk9XCJzZWN1cmVJbWFnZUNvbXBvbmVudC5yZXRyeUxvYWRJbWFnZSgpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5xdWl6UXVlc3Rpb24ucmV0cnknIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgIDwvZGl2PlxuICAgIDxkaXYgW2hpZGRlbl09XCJsb2FkaW5nU3RhdGUgIT09ICdzdWNjZXNzJ1wiPlxuICAgICAgICA8aDQgY2xhc3M9XCJxdWVzdGlvbi10aXRsZS1kaXNwbGF5XCI+XG4gICAgICAgICAgICA8c3Bhbj57eyBxdWVzdGlvbkluZGV4IH19KTwvc3Bhbj4ge3sgcXVlc3Rpb24udGl0bGUgfX1cbiAgICAgICAgPC9oND5cbiAgICAgICAgPHAgW2lubmVySFRNTF09XCJyZW5kZXJlZFF1ZXN0aW9uLnRleHRcIj48L3A+XG4gICAgICAgIEBpZiAocXVlc3Rpb24uaW52YWxpZCkge1xuICAgICAgICAgICAgPHNwYW4gc3R5bGU9XCJjb2xvcjogcmVkXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6UXVlc3Rpb24uaW52YWxpZFRleHRcIj48L3NwYW4+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChxdWVzdGlvbi5oaW50IHx8IChxdWVzdGlvbi5leHBsYW5hdGlvbiAmJiBzaG93UmVzdWx0KSkge1xuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImhpbnRcIj5cbiAgICAgICAgICAgICAgICBAaWYgKHF1ZXN0aW9uLmhpbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsYWJlbCBsYWJlbC1pbmZvXCIgW25nYlBvcG92ZXJdPVwicmVuZGVyZWRIaW50XCIgdHJpZ2dlcnM9XCJtb3VzZWVudGVyOm1vdXNlbGVhdmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhUXVlc3Rpb25DaXJjbGVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpRdWVzdGlvbi5oaW50XCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSAjcmVuZGVyZWRIaW50PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IFtpbm5lckhUTUxdPVwicmVuZGVyZWRRdWVzdGlvbi5oaW50XCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgICAgICBAaWYgKHF1ZXN0aW9uLmV4cGxhbmF0aW9uICYmIHNob3dSZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsYWJlbCBsYWJlbC1wcmltYXJ5XCIgW25nYlBvcG92ZXJdPVwicmVuZGVyZWRFeHBsYW5hdGlvblwiIHRyaWdnZXJzPVwibW91c2VlbnRlcjptb3VzZWxlYXZlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUV4Y2xhbWF0aW9uQ2lyY2xlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6UXVlc3Rpb24uZXhwbGFuYXRpb25cIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlICNyZW5kZXJlZEV4cGxhbmF0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IFtpbm5lckhUTUxdPVwicmVuZGVyZWRRdWVzdGlvbi5leHBsYW5hdGlvblwiPjwvZGl2PlxuICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgICBAaWYgKCFzaG93UmVzdWx0IHx8IGZvcmNlU2FtcGxlU29sdXRpb24pIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJxdWVzdGlvbi1zY29yZVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpelF1ZXN0aW9uLnNjb3JlXCIgY2xhc3M9XCJjb2xvbi1zdWZmaXhcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4+e3sgcXVlc3Rpb24ucG9pbnRzIH19PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChzaG93UmVzdWx0ICYmICFmb3JjZVNhbXBsZVNvbHV0aW9uKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicXVlc3Rpb24tc2NvcmUgcmVzdWx0XCIgW25nQ2xhc3NdPVwieyBpbmNvcnJlY3Q6IChzY29yZSB8fCAwKSA8IHF1ZXN0aW9uLnBvaW50cyEgfVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpelF1ZXN0aW9uLnlvdXJTY29yZVwiIGNsYXNzPVwiY29sb24tc3VmZml4XCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwic2hvdy1leHBsYW5hdGlvblwiPnt7IHNjb3JlIHx8IDAgfX0ve3sgcXVlc3Rpb24ucG9pbnRzIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwic2hvdy1leHBsYW5hdGlvblwiPlxuICAgICAgICAgICAgICAgICAgICA8amhpLXF1aXotc2NvcmluZy1pbmZvc3R1ZGVudC1tb2RhbFxuICAgICAgICAgICAgICAgICAgICAgICAgW3Njb3JlXT1cInNjb3JlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtxdWVzdGlvbl09XCJxdWVzdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbZHJhZ0FuZERyb3BNYXBwaW5nXT1cIm1hcHBpbmdzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjb3JyZWN0bHlNYXBwZWREcmFnQW5kRHJvcEl0ZW1zXT1cImNvcnJlY3RBbnN3ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW2luY29ycmVjdGx5TWFwcGVkRHJhZ0FuZERyb3BJdGVtc109XCJpbmNvcnJlY3RMb2NhdGlvbk1hcHBpbmdzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFttYXBwZWRMb2NhdGlvbnNdPVwibWFwcGVkTG9jYXRpb25zXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtxdWVzdGlvbkluZGV4XT1cInF1ZXN0aW9uSW5kZXhcIlxuICAgICAgICAgICAgICAgICAgICA+PC9qaGktcXVpei1zY29yaW5nLWluZm9zdHVkZW50LW1vZGFsPlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICAgIEBpZiAoc2hvd1Jlc3VsdCkge1xuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImRuZC1pbnN0cnVjdGlvbnNcIj5cbiAgICAgICAgICAgICAgICBAaWYgKHNob3dpbmdTYW1wbGVTb2x1dGlvbikge1xuICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmRyYWdBbmREcm9wUXVlc3Rpb24uc2hvd2luZ1NhbXBsZVNvbHV0aW9uXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKCFzaG93aW5nU2FtcGxlU29sdXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5kcmFnQW5kRHJvcFF1ZXN0aW9uLnNob3dpbmdZb3VyQW5zd2VyXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKHNob3dSZXN1bHQgJiYgIWZvcmNlU2FtcGxlU29sdXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIXNob3dpbmdTYW1wbGVTb2x1dGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJidG4gYnRuLW91dGxpbmUtcHJpbWFyeVwiIChjbGljayk9XCJzaG93U2FtcGxlU29sdXRpb24oKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5xdWl6UXVlc3Rpb24uc2hvd1NhbXBsZVNvbHV0aW9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc2hvd2luZ1NhbXBsZVNvbHV0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1wcmltYXJ5XCIgKGNsaWNrKT1cImhpZGVTYW1wbGVTb2x1dGlvbigpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLnF1aXpRdWVzdGlvbi5oaWRlU2FtcGxlU29sdXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgICA8ZGl2IGNka0Ryb3BMaXN0R3JvdXAgY2xhc3M9XCJkcmFnLWFuZC1kcm9wLWFyZWFcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJiYWNrZ3JvdW5kLWFyZWFcIj5cbiAgICAgICAgICAgICAgICBAaWYgKHF1ZXN0aW9uLmJhY2tncm91bmRGaWxlUGF0aCkge1xuICAgICAgICAgICAgICAgICAgICA8amhpLXNlY3VyZWQtaW1hZ2VcbiAgICAgICAgICAgICAgICAgICAgICAgIFtzcmNdPVwiZmlsZVByZXZpZXdQYXRocy5nZXQocXVlc3Rpb24uYmFja2dyb3VuZEZpbGVQYXRoISkgfHwgcXVlc3Rpb24uYmFja2dyb3VuZEZpbGVQYXRoIVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAoZW5kTG9hZGluZ1Byb2Nlc3MpPVwiY2hhbmdlTG9hZGluZygkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAgICAgPjwvamhpLXNlY3VyZWQtaW1hZ2U+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjbGljay1sYXllclwiPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKCFzaG93UmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKGRyb3BMb2NhdGlvbiBvZiBxdWVzdGlvbi5kcm9wTG9jYXRpb25zOyB0cmFjayBkcm9wTG9jYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkcm9wLWxvY2F0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZHJvcC1sb2NhdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbmdDbGFzc109XCJkcm9wQWxsb3dlZCA/ICdkcm9wLWFsbG93ZWQnIDogJydcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nU3R5bGVdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcDogZHJvcExvY2F0aW9uLnBvc1khIC8gMiArICclJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiBkcm9wTG9jYXRpb24ucG9zWCEgLyAyICsgJyUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiBkcm9wTG9jYXRpb24ud2lkdGghIC8gMiArICclJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGRyb3BMb2NhdGlvbi5oZWlnaHQhIC8gMiArICclJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2RrRHJvcExpc3REcm9wcGVkKT1cIm9uRHJhZ0Ryb3AoZHJvcExvY2F0aW9uLCAkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChvbkRyYWdFbnRlcik9XCJwcmV2ZW50RGVmYXVsdCgkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChvbkRyYWdPdmVyKT1cInByZXZlbnREZWZhdWx0KCRldmVudClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKG9uRHJhZ0xlYXZlKT1cInByZXZlbnREZWZhdWx0KCRldmVudClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2RrRHJvcExpc3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjZGtEcm9wTGlzdEF1dG9TY3JvbGxTdGVwXT1cIjYwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChkcmFnSXRlbUZvckRyb3BMb2NhdGlvbihkcm9wTG9jYXRpb24pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1kcmFnLWl0ZW1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGRyYWdlbnRlcik9XCJkcmFnKClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZHJhZ2VuZCk9XCJkcm9wKClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbZHJhZ0l0ZW1dPVwiZHJhZ0l0ZW1Gb3JEcm9wTG9jYXRpb24oZHJvcExvY2F0aW9uKSFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xpY2tEaXNhYmxlZF09XCJjbGlja0Rpc2FibGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW21pbldpZHRoXT1cIjEwMCArICclJ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtmaWxlUHJldmlld1BhdGhzXT1cImZpbGVQcmV2aWV3UGF0aHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2poaS1kcmFnLWl0ZW0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoc2hvd1Jlc3VsdCAmJiAhc2hvd2luZ1NhbXBsZVNvbHV0aW9uICYmIHF1ZXN0aW9uLmRyb3BMb2NhdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAoZHJvcExvY2F0aW9uIG9mIHF1ZXN0aW9uLmRyb3BMb2NhdGlvbnM7IHRyYWNrIGRyb3BMb2NhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZHJvcC1sb2NhdGlvbiByZXN1bHRzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbmdDbGFzc109XCJ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluY29ycmVjdDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9jYXRpb25Db3JyZWN0KGRyb3BMb2NhdGlvbikgPT09IE1hcHBpbmdSZXN1bHQuTUFQUEVEX0lOQ09SUkVDVCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIWRyb3BMb2NhdGlvbi5pbnZhbGlkICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhaW52YWxpZERyYWdJdGVtRm9yRHJvcExvY2F0aW9uKGRyb3BMb2NhdGlvbikgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFxdWVzdGlvbi5pbnZhbGlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nU3R5bGVdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A6IGRyb3BMb2NhdGlvbi5wb3NZISAvIDIgKyAnJScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6IGRyb3BMb2NhdGlvbi5wb3NYISAvIDIgKyAnJScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiBkcm9wTG9jYXRpb24ud2lkdGghIC8gMiArICclJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBkcm9wTG9jYXRpb24uaGVpZ2h0ISAvIDIgKyAnJSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0xvY2F0aW9uQ29ycmVjdChkcm9wTG9jYXRpb24pID09PSBNYXBwaW5nUmVzdWx0Lk1BUFBFRF9JTkNPUlJFQ1QgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIWRyb3BMb2NhdGlvbi5pbnZhbGlkICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFpbnZhbGlkRHJhZ0l0ZW1Gb3JEcm9wTG9jYXRpb24oZHJvcExvY2F0aW9uKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhcXVlc3Rpb24uaW52YWxpZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicmVzdWx0LXN5bWJvbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFFeGNsYW1hdGlvblRyaWFuZ2xlXCIgc2l6ZT1cIjJ4XCIgY2xhc3M9XCJ3YXJuaW5nXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImludmFsaWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChkcm9wTG9jYXRpb24uaW52YWxpZCAmJiAhaW52YWxpZERyYWdJdGVtRm9yRHJvcExvY2F0aW9uKGRyb3BMb2NhdGlvbikgJiYgIXF1ZXN0aW9uLmludmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuZHJhZ0FuZERyb3BRdWVzdGlvbi5pbnZhbGlkLmRyb3BMb2NhdGlvblwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKCFkcm9wTG9jYXRpb24uaW52YWxpZCAmJiBpbnZhbGlkRHJhZ0l0ZW1Gb3JEcm9wTG9jYXRpb24oZHJvcExvY2F0aW9uKSAmJiAhcXVlc3Rpb24uaW52YWxpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5kcmFnQW5kRHJvcFF1ZXN0aW9uLmludmFsaWQuZHJhZ0l0ZW1cIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICgoZHJvcExvY2F0aW9uLmludmFsaWQgJiYgaW52YWxpZERyYWdJdGVtRm9yRHJvcExvY2F0aW9uKGRyb3BMb2NhdGlvbikpIHx8IHF1ZXN0aW9uLmludmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpelF1ZXN0aW9uLmludmFsaWRcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChkcm9wTG9jYXRpb24uaW52YWxpZCB8fCBxdWVzdGlvbi5pbnZhbGlkIHx8IGludmFsaWREcmFnSXRlbUZvckRyb3BMb2NhdGlvbihkcm9wTG9jYXRpb24pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5nYlRvb2x0aXA9XCJJbnZhbGlkIERyb3AgTG9jYXRpb25zIGFuZCBpbnZhbGlkIERyYWcgSXRlbXMgd2lsbCBiZSBhc3Nlc3NlZCBhcyBjb3JyZWN0LlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9XCJjb2xvcjogYmxhY2tcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtpY29uXT1cImZhUXVlc3Rpb25DaXJjbGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZHJhZ0l0ZW1Gb3JEcm9wTG9jYXRpb24oZHJvcExvY2F0aW9uKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLWRyYWctaXRlbVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2RyYWdJdGVtXT1cImRyYWdJdGVtRm9yRHJvcExvY2F0aW9uKGRyb3BMb2NhdGlvbikhXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGlja0Rpc2FibGVkXT1cInRydWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW21pbldpZHRoXT1cIjEwMCArICclJ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbZmlsZVByZXZpZXdQYXRoc109XCJmaWxlUHJldmlld1BhdGhzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2poaS1kcmFnLWl0ZW0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWRyYWdJdGVtRm9yRHJvcExvY2F0aW9uKGRyb3BMb2NhdGlvbikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImRyYWctaXRlbSBuby1jbGlja1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoc2hvd1Jlc3VsdCAmJiBzaG93aW5nU2FtcGxlU29sdXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAoZHJvcExvY2F0aW9uIG9mIHF1ZXN0aW9uLmRyb3BMb2NhdGlvbnM7IHRyYWNrIGRyb3BMb2NhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZHJvcC1sb2NhdGlvbiBzYW1wbGVTb2x1dGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nQ2xhc3NdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmNvcnJlY3Q6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0xvY2F0aW9uQ29ycmVjdChkcm9wTG9jYXRpb24pID09PSBNYXBwaW5nUmVzdWx0Lk1BUFBFRF9JTkNPUlJFQ1QgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFkcm9wTG9jYXRpb24uaW52YWxpZCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIWludmFsaWREcmFnSXRlbUZvckRyb3BMb2NhdGlvbihkcm9wTG9jYXRpb24pICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhcXVlc3Rpb24uaW52YWxpZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ1N0eWxlXT1cIntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wOiBkcm9wTG9jYXRpb24ucG9zWSEgLyAyICsgJyUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiBkcm9wTG9jYXRpb24ucG9zWCEgLyAyICsgJyUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogZHJvcExvY2F0aW9uLndpZHRoISAvIDIgKyAnJScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogZHJvcExvY2F0aW9uLmhlaWdodCEgLyAyICsgJyUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNMb2NhdGlvbkNvcnJlY3QoZHJvcExvY2F0aW9uKSA9PT0gTWFwcGluZ1Jlc3VsdC5NQVBQRURfSU5DT1JSRUNUICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFkcm9wTG9jYXRpb24uaW52YWxpZCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhaW52YWxpZERyYWdJdGVtRm9yRHJvcExvY2F0aW9uKGRyb3BMb2NhdGlvbikgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIXF1ZXN0aW9uLmludmFsaWQgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIWZvcmNlU2FtcGxlU29sdXRpb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJlc3VsdC1zeW1ib2xcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhRXhjbGFtYXRpb25UcmlhbmdsZVwiIHNpemU9XCIyeFwiIGNsYXNzPVwid2FybmluZ1wiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbnZhbGlkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZHJvcExvY2F0aW9uLmludmFsaWQgJiYgIWludmFsaWREcmFnSXRlbUZvckRyb3BMb2NhdGlvbihkcm9wTG9jYXRpb24pICYmICFxdWVzdGlvbi5pbnZhbGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmRyYWdBbmREcm9wUXVlc3Rpb24uaW52YWxpZC5kcm9wTG9jYXRpb25cIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICgoZHJvcExvY2F0aW9uLmludmFsaWQgJiYgaW52YWxpZERyYWdJdGVtRm9yRHJvcExvY2F0aW9uKGRyb3BMb2NhdGlvbikpIHx8IHF1ZXN0aW9uLmludmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpelF1ZXN0aW9uLmludmFsaWRcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChkcm9wTG9jYXRpb24uaW52YWxpZCB8fCBxdWVzdGlvbi5pbnZhbGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5nYlRvb2x0aXA9XCJJbnZhbGlkIERyb3AgTG9jYXRpb25zIGFuZCBpbnZhbGlkIERyYWcgSXRlbXMgd2lsbCBiZSBhc3Nlc3NlZCBhcyBjb3JyZWN0LlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9XCJjb2xvcjogYmxhY2tcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtpY29uXT1cImZhUXVlc3Rpb25DaXJjbGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZHJvcExvY2F0aW9uICYmIGNvcnJlY3REcmFnSXRlbUZvckRyb3BMb2NhdGlvbihkcm9wTG9jYXRpb24pICYmICFkcm9wTG9jYXRpb24uaW52YWxpZCAmJiAhcXVlc3Rpb24uaW52YWxpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLWRyYWctaXRlbVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2RyYWdJdGVtXT1cImNvcnJlY3REcmFnSXRlbUZvckRyb3BMb2NhdGlvbihkcm9wTG9jYXRpb24pIVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xpY2tEaXNhYmxlZF09XCJ0cnVlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFttaW5XaWR0aF09XCIxMDAgKyAnJSdcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2ZpbGVQcmV2aWV3UGF0aHNdPVwiZmlsZVByZXZpZXdQYXRoc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2poaS1kcmFnLWl0ZW0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWRyb3BMb2NhdGlvbiB8fCAhY29ycmVjdERyYWdJdGVtRm9yRHJvcExvY2F0aW9uKGRyb3BMb2NhdGlvbikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImRyYWctaXRlbSBuby1jbGlja1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkcmFnLWFuZC1kcm9wLWl0ZW1zXCI+XG4gICAgICAgICAgICAgICAgQGlmICghc2hvd1Jlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZG5kLWluc3RydWN0aW9uc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5kcmFnQW5kRHJvcFF1ZXN0aW9uLnN0dWRlbnRJbnN0cnVjdGlvbnNcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKHNob3dSZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdj48L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmICghc2hvd1Jlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImRyYWctaXRlbXNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkcmFnLWl0ZW1zXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtuZ0NsYXNzXT1cImRyb3BBbGxvd2VkID8gJ2Ryb3AtYWxsb3dlZCcgOiAnJ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAoY2RrRHJvcExpc3REcm9wcGVkKT1cIm9uRHJhZ0Ryb3AodW5kZWZpbmVkLCAkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIChvbkRyYWdFbnRlcik9XCJwcmV2ZW50RGVmYXVsdCgkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIChvbkRyYWdPdmVyKT1cInByZXZlbnREZWZhdWx0KCRldmVudClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKG9uRHJhZ0xlYXZlKT1cInByZXZlbnREZWZhdWx0KCRldmVudClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2RrRHJvcExpc3RcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjZGtEcm9wTGlzdEF1dG9TY3JvbGxTdGVwXT1cIjYwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAoZHJhZ0l0ZW0gb2YgZ2V0VW5hc3NpZ25lZERyYWdJdGVtcygpOyB0cmFjayBkcmFnSXRlbTsgbGV0IGkgPSAkaW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLWRyYWctaXRlbVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImRyYWctaXRlbS17eyBpIH19XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGRyYWdlbnRlcik9XCJkcmFnKClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZHJhZ2VuZCk9XCJkcm9wKClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbZHJhZ0l0ZW1dPVwiZHJhZ0l0ZW1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xpY2tEaXNhYmxlZF09XCJjbGlja0Rpc2FibGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW21pbldpZHRoXT1cIicxNjAnXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2ZpbGVQcmV2aWV3UGF0aHNdPVwiZmlsZVByZXZpZXdQYXRoc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvamhpLWRyYWctaXRlbT5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE91dHB1dCwgVmlld0VuY2Fwc3VsYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFydGVtaXNNYXJrZG93blNlcnZpY2UgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLnNlcnZpY2UnO1xuaW1wb3J0IHsgQW5zd2VyT3B0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovYW5zd2VyLW9wdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBNdWx0aXBsZUNob2ljZVF1ZXN0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovbXVsdGlwbGUtY2hvaWNlLXF1ZXN0aW9uLm1vZGVsJztcbmltcG9ydCB7IFF1aXpRdWVzdGlvbiwgUmVuZGVyZWRRdWl6UXVlc3Rpb25NYXJrRG93bkVsZW1lbnQgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9xdWl6LXF1ZXN0aW9uLm1vZGVsJztcbmltcG9ydCB7IFJlc3VsdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9yZXN1bHQubW9kZWwnO1xuaW1wb3J0IHsgZmFFeGNsYW1hdGlvbkNpcmNsZSwgZmFFeGNsYW1hdGlvblRyaWFuZ2xlLCBmYVF1ZXN0aW9uQ2lyY2xlIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IGZhQ2hlY2tTcXVhcmUsIGZhQ2lyY2xlLCBmYURvdENpcmNsZSwgZmFTcXVhcmUgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1yZWd1bGFyLXN2Zy1pY29ucyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLW11bHRpcGxlLWNob2ljZS1xdWVzdGlvbicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL211bHRpcGxlLWNob2ljZS1xdWVzdGlvbi5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vbXVsdGlwbGUtY2hvaWNlLXF1ZXN0aW9uLmNvbXBvbmVudC5zY3NzJywgJy4uLy4uLy4uL3BhcnRpY2lwYXRlL3F1aXotcGFydGljaXBhdGlvbi5zY3NzJ10sXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcbn0pXG5leHBvcnQgY2xhc3MgTXVsdGlwbGVDaG9pY2VRdWVzdGlvbkNvbXBvbmVudCB7XG4gICAgX3F1ZXN0aW9uOiBNdWx0aXBsZUNob2ljZVF1ZXN0aW9uO1xuXG4gICAgQElucHV0KClcbiAgICBzZXQgcXVlc3Rpb24ocXVlc3Rpb246IE11bHRpcGxlQ2hvaWNlUXVlc3Rpb24pIHtcbiAgICAgICAgdGhpcy5fcXVlc3Rpb24gPSBxdWVzdGlvbjtcbiAgICAgICAgdGhpcy53YXRjaENvbGxlY3Rpb24oKTtcbiAgICB9XG4gICAgZ2V0IHF1ZXN0aW9uKCk6IE11bHRpcGxlQ2hvaWNlUXVlc3Rpb24ge1xuICAgICAgICByZXR1cm4gdGhpcy5fcXVlc3Rpb247XG4gICAgfVxuICAgIC8vIFRPRE86IE1hcCB2cy4gQXJyYXkgLS0+IGNvbnNpc3RlbmN5XG4gICAgQElucHV0KClcbiAgICBzZWxlY3RlZEFuc3dlck9wdGlvbnM6IEFuc3dlck9wdGlvbltdO1xuICAgIEBJbnB1dCgpXG4gICAgY2xpY2tEaXNhYmxlZDogYm9vbGVhbjtcbiAgICBASW5wdXQoKVxuICAgIHNob3dSZXN1bHQ6IGJvb2xlYW47XG4gICAgQElucHV0KClcbiAgICBxdWVzdGlvbkluZGV4OiBudW1iZXI7XG4gICAgQElucHV0KClcbiAgICBzY29yZTogbnVtYmVyO1xuICAgIEBJbnB1dCgpXG4gICAgZm9yY2VTYW1wbGVTb2x1dGlvbjogYm9vbGVhbjtcbiAgICBASW5wdXQoKVxuICAgIGZuT25TZWxlY3Rpb246IGFueTtcbiAgICBASW5wdXQoKVxuICAgIHN1Ym1pdHRlZFJlc3VsdDogUmVzdWx0O1xuICAgIEBJbnB1dCgpXG4gICAgcXVpelF1ZXN0aW9uczogUXVpelF1ZXN0aW9uW10gfCB1bmRlZmluZWQ7XG5cbiAgICBAT3V0cHV0KClcbiAgICBzZWxlY3RlZEFuc3dlck9wdGlvbnNDaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPEFuc3dlck9wdGlvbltdPigpO1xuXG4gICAgcmVuZGVyZWRRdWVzdGlvbjogUmVuZGVyZWRRdWl6UXVlc3Rpb25NYXJrRG93bkVsZW1lbnQ7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhUXVlc3Rpb25DaXJjbGUgPSBmYVF1ZXN0aW9uQ2lyY2xlO1xuICAgIGZhRXhjbGFtYXRpb25UcmlhbmdsZSA9IGZhRXhjbGFtYXRpb25UcmlhbmdsZTtcbiAgICBmYUV4Y2xhbWF0aW9uQ2lyY2xlID0gZmFFeGNsYW1hdGlvbkNpcmNsZTtcbiAgICBmYVNxdWFyZSA9IGZhU3F1YXJlO1xuICAgIGZhQ2hlY2tTcXVhcmUgPSBmYUNoZWNrU3F1YXJlO1xuICAgIGZhQ2lyY2xlID0gZmFDaXJjbGU7XG4gICAgZmFEb3RDaXJjbGUgPSBmYURvdENpcmNsZTtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgYXJ0ZW1pc01hcmtkb3duOiBBcnRlbWlzTWFya2Rvd25TZXJ2aWNlKSB7fVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlIGh0bWwgZm9yIHRleHQsIGhpbnQgYW5kIGV4cGxhbmF0aW9uIGZvciB0aGUgcXVlc3Rpb24gYW5kIGV2ZXJ5IGFuc3dlciBvcHRpb25cbiAgICAgKi9cbiAgICB3YXRjaENvbGxlY3Rpb24oKTogdm9pZCB7XG4gICAgICAgIHRoaXMucmVuZGVyZWRRdWVzdGlvbiA9IG5ldyBSZW5kZXJlZFF1aXpRdWVzdGlvbk1hcmtEb3duRWxlbWVudCgpO1xuICAgICAgICB0aGlzLnJlbmRlcmVkUXVlc3Rpb24udGV4dCA9IHRoaXMuYXJ0ZW1pc01hcmtkb3duLnNhZmVIdG1sRm9yTWFya2Rvd24odGhpcy5xdWVzdGlvbi50ZXh0KTtcbiAgICAgICAgdGhpcy5yZW5kZXJlZFF1ZXN0aW9uLmhpbnQgPSB0aGlzLmFydGVtaXNNYXJrZG93bi5zYWZlSHRtbEZvck1hcmtkb3duKHRoaXMucXVlc3Rpb24uaGludCk7XG4gICAgICAgIHRoaXMucmVuZGVyZWRRdWVzdGlvbi5leHBsYW5hdGlvbiA9IHRoaXMuYXJ0ZW1pc01hcmtkb3duLnNhZmVIdG1sRm9yTWFya2Rvd24odGhpcy5xdWVzdGlvbi5leHBsYW5hdGlvbik7XG4gICAgICAgIHRoaXMucmVuZGVyZWRRdWVzdGlvbi5yZW5kZXJlZFN1YkVsZW1lbnRzID0gdGhpcy5xdWVzdGlvbi5hbnN3ZXJPcHRpb25zIS5tYXAoKGFuc3dlck9wdGlvbikgPT4ge1xuICAgICAgICAgICAgY29uc3QgcmVuZGVyZWRBbnN3ZXJPcHRpb24gPSBuZXcgUmVuZGVyZWRRdWl6UXVlc3Rpb25NYXJrRG93bkVsZW1lbnQoKTtcbiAgICAgICAgICAgIHJlbmRlcmVkQW5zd2VyT3B0aW9uLnRleHQgPSB0aGlzLmFydGVtaXNNYXJrZG93bi5zYWZlSHRtbEZvck1hcmtkb3duKGFuc3dlck9wdGlvbi50ZXh0KTtcbiAgICAgICAgICAgIHJlbmRlcmVkQW5zd2VyT3B0aW9uLmhpbnQgPSB0aGlzLmFydGVtaXNNYXJrZG93bi5zYWZlSHRtbEZvck1hcmtkb3duKGFuc3dlck9wdGlvbi5oaW50KTtcbiAgICAgICAgICAgIHJlbmRlcmVkQW5zd2VyT3B0aW9uLmV4cGxhbmF0aW9uID0gdGhpcy5hcnRlbWlzTWFya2Rvd24uc2FmZUh0bWxGb3JNYXJrZG93bihhbnN3ZXJPcHRpb24uZXhwbGFuYXRpb24pO1xuICAgICAgICAgICAgcmV0dXJuIHJlbmRlcmVkQW5zd2VyT3B0aW9uO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUb2dnbGVzIHRoZSBzZWxlY3Rpb24gc3RhdGUgb2YgYSBtdWx0aXBsZSBjaG9pY2UgYW5zd2VyIG9wdGlvblxuICAgICAqIEBwYXJhbSBhbnN3ZXJPcHRpb24gVGhlIGFuc3dlciBvcHRpb24gdG8gdG9nZ2xlXG4gICAgICovXG4gICAgdG9nZ2xlU2VsZWN0aW9uKGFuc3dlck9wdGlvbjogQW5zd2VyT3B0aW9uKTogdm9pZCB7XG4gICAgICAgIGlmICh0aGlzLmNsaWNrRGlzYWJsZWQpIHtcbiAgICAgICAgICAgIC8vIERvIG5vdGhpbmdcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5pc0Fuc3dlck9wdGlvblNlbGVjdGVkKGFuc3dlck9wdGlvbikpIHtcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRBbnN3ZXJPcHRpb25zID0gdGhpcy5zZWxlY3RlZEFuc3dlck9wdGlvbnMuZmlsdGVyKChzZWxlY3RlZEFuc3dlck9wdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChhbnN3ZXJPcHRpb24uaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHNlbGVjdGVkQW5zd2VyT3B0aW9uLmlkICE9PSBhbnN3ZXJPcHRpb24uaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBzZWxlY3RlZEFuc3dlck9wdGlvbiAhPT0gYW5zd2VyT3B0aW9uO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5pc1NpbmdsZUNob2ljZSkge1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZEFuc3dlck9wdGlvbnMgPSBbYW5zd2VyT3B0aW9uXTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRBbnN3ZXJPcHRpb25zLnB1c2goYW5zd2VyT3B0aW9uKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNlbGVjdGVkQW5zd2VyT3B0aW9uc0NoYW5nZS5lbWl0KHRoaXMuc2VsZWN0ZWRBbnN3ZXJPcHRpb25zKTtcbiAgICAgICAgLyoqIE9ubHkgZXhlY3V0ZSB0aGUgb25TZWxlY3Rpb24gZnVuY3Rpb24gaWYgd2UgcmVjZWl2ZWQgc3VjaCBpbnB1dCAqKi9cbiAgICAgICAgaWYgKHRoaXMuZm5PblNlbGVjdGlvbikge1xuICAgICAgICAgICAgdGhpcy5mbk9uU2VsZWN0aW9uKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXR0ZXIgd2hldGhlciB0aGUgZ2l2ZW4gYW5zd2VyIG9wdGlvbiBpcyBzZWxlY3RlZFxuICAgICAqIEBwYXJhbSBhbnN3ZXJPcHRpb24gQW5zd2VyIG9wdGlvbiB0byBiZSBjaGVja2VkIGZvciBzZWxlY3Rpb24gc3RhdGVcbiAgICAgKi9cbiAgICBpc0Fuc3dlck9wdGlvblNlbGVjdGVkKGFuc3dlck9wdGlvbjogQW5zd2VyT3B0aW9uKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICB0aGlzLnNlbGVjdGVkQW5zd2VyT3B0aW9ucy5maW5kSW5kZXgoKHNlbGVjdGVkQW5zd2VyT3B0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGFuc3dlck9wdGlvbi5pZCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gc2VsZWN0ZWRBbnN3ZXJPcHRpb24uaWQgPT09IGFuc3dlck9wdGlvbi5pZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHNlbGVjdGVkQW5zd2VyT3B0aW9uID09PSBhbnN3ZXJPcHRpb247XG4gICAgICAgICAgICB9KSAhPT0gLTFcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXQgaXNTaW5nbGVDaG9pY2UoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnF1ZXN0aW9uLnNpbmdsZUNob2ljZTtcbiAgICB9XG59XG4iLCI8ZGl2XG4gICAgY2xhc3M9XCJtYy1xdWVzdGlvbiBtYXJrZG93bi1wcmV2aWV3XCJcbiAgICBbbmdDbGFzc109XCJ7IGRpc2FibGVkOiBjbGlja0Rpc2FibGVkICYmICFzaG93UmVzdWx0LCByZXN1bHQ6IHNob3dSZXN1bHQgJiYgIWZvcmNlU2FtcGxlU29sdXRpb24sIGluY29ycmVjdDogKHNjb3JlIHx8IDApIDwgcXVlc3Rpb24ucG9pbnRzISAmJiAhZm9yY2VTYW1wbGVTb2x1dGlvbiB9XCJcbj5cbiAgICA8aDQgY2xhc3M9XCJxdWVzdGlvbi10aXRsZS1kaXNwbGF5XCI+XG4gICAgICAgIDxzcGFuPnt7IHF1ZXN0aW9uSW5kZXggfX0pPC9zcGFuPiB7eyBxdWVzdGlvbi50aXRsZSB9fVxuICAgIDwvaDQ+XG4gICAgPHAgW2lubmVySFRNTF09XCJyZW5kZXJlZFF1ZXN0aW9uLnRleHRcIj48L3A+XG4gICAgQGlmIChxdWVzdGlvbi5pbnZhbGlkKSB7XG4gICAgICAgIDxzcGFuIHN0eWxlPVwiY29sb3I6IHJlZFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpelF1ZXN0aW9uLmludmFsaWRUZXh0XCI+PC9zcGFuPlxuICAgIH1cbiAgICBAaWYgKCFpc1NpbmdsZUNob2ljZSkge1xuICAgICAgICA8aDY+e3sgJ2FydGVtaXNBcHAucXVpelF1ZXN0aW9uLmFsbE9wdGlvbnMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvaDY+XG4gICAgfVxuICAgIEBpZiAoaXNTaW5nbGVDaG9pY2UpIHtcbiAgICAgICAgPGg2Pnt7ICdhcnRlbWlzQXBwLnF1aXpRdWVzdGlvbi5zaW5nbGVPcHRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvaDY+XG4gICAgfVxuICAgIEBpZiAocXVlc3Rpb24uaGludCB8fCAocXVlc3Rpb24uZXhwbGFuYXRpb24gJiYgc2hvd1Jlc3VsdCkpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cImhpbnRcIj5cbiAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSAjcmVuZGVyZWRIaW50PlxuICAgICAgICAgICAgICAgIDxkaXYgW2lubmVySFRNTF09XCJyZW5kZXJlZFF1ZXN0aW9uLmhpbnRcIj48L2Rpdj5cbiAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICBAaWYgKHF1ZXN0aW9uLmhpbnQpIHtcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImxhYmVsIGxhYmVsLWluZm9cIiBbbmdiUG9wb3Zlcl09XCJyZW5kZXJlZEhpbnRcIiB0cmlnZ2Vycz1cIm1vdXNlZW50ZXI6bW91c2VsZWF2ZVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVF1ZXN0aW9uQ2lyY2xlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpRdWVzdGlvbi5oaW50XCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgPG5nLXRlbXBsYXRlICNyZW5kZXJlZEV4cGxhbmF0aW9uPlxuICAgICAgICAgICAgICAgIDxkaXYgW2lubmVySFRNTF09XCJyZW5kZXJlZFF1ZXN0aW9uLmV4cGxhbmF0aW9uXCI+PC9kaXY+XG4gICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgQGlmIChxdWVzdGlvbi5leHBsYW5hdGlvbiAmJiBzaG93UmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsYWJlbCBsYWJlbC1wcmltYXJ5XCIgW25nYlBvcG92ZXJdPVwicmVuZGVyZWRFeHBsYW5hdGlvblwiIHBsYWNlbWVudD1cInJpZ2h0IGF1dG9cIiB0cmlnZ2Vycz1cIm1vdXNlZW50ZXI6bW91c2VsZWF2ZVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUV4Y2xhbWF0aW9uQ2lyY2xlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpRdWVzdGlvbi5leHBsYW5hdGlvblwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICBAaWYgKCFzaG93UmVzdWx0IHx8IGZvcmNlU2FtcGxlU29sdXRpb24pIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cInF1ZXN0aW9uLXNjb3JlXCI+XG4gICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpRdWVzdGlvbi5zY29yZVwiIGNsYXNzPVwiY29sb24tc3VmZml4XCI+PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+e3sgcXVlc3Rpb24ucG9pbnRzIH19PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmIChzaG93UmVzdWx0ICYmICFmb3JjZVNhbXBsZVNvbHV0aW9uKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJxdWVzdGlvbi1zY29yZSByZXN1bHRcIiBbbmdDbGFzc109XCJ7IGluY29ycmVjdDogKHNjb3JlIHx8IDApIDwgcXVlc3Rpb24ucG9pbnRzISB9XCI+XG4gICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpRdWVzdGlvbi55b3VyU2NvcmVcIiBjbGFzcz1cImNvbG9uLXN1ZmZpeFwiPjwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwic2hvdy1leHBsYW5hdGlvblwiPnt7IHNjb3JlIHx8IDAgfX0ve3sgcXVlc3Rpb24ucG9pbnRzIH19PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJzaG93LWV4cGxhbmF0aW9uXCI+XG4gICAgICAgICAgICAgICAgPGpoaS1xdWl6LXNjb3JpbmctaW5mb3N0dWRlbnQtbW9kYWxcbiAgICAgICAgICAgICAgICAgICAgW3Njb3JlXT1cInNjb3JlXCJcbiAgICAgICAgICAgICAgICAgICAgW3F1ZXN0aW9uXT1cInF1ZXN0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgW211bHRpcGxlQ2hvaWNlTWFwcGluZ109XCJzZWxlY3RlZEFuc3dlck9wdGlvbnNcIlxuICAgICAgICAgICAgICAgICAgICBbcXVlc3Rpb25JbmRleF09XCJxdWVzdGlvbkluZGV4XCJcbiAgICAgICAgICAgICAgICAgICAgW211bHRpcGxlQ2hvaWNlU3VibWl0dGVkUmVzdWx0XT1cInN1Ym1pdHRlZFJlc3VsdFwiXG4gICAgICAgICAgICAgICAgICAgIFtxdWl6UXVlc3Rpb25zXT1cInF1aXpRdWVzdGlvbnNcIlxuICAgICAgICAgICAgICAgID48L2poaS1xdWl6LXNjb3JpbmctaW5mb3N0dWRlbnQtbW9kYWw+XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICBAaWYgKCFzaG93UmVzdWx0KSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJhbnN3ZXItb3B0aW9uc1wiPlxuICAgICAgICAgICAgQGZvciAoYW5zd2VyT3B0aW9uIG9mIHF1ZXN0aW9uLmFuc3dlck9wdGlvbnM7IHRyYWNrIGFuc3dlck9wdGlvbjsgbGV0IGkgPSAkaW5kZXgpIHtcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGlkPVwiYW5zd2VyLW9wdGlvbi17eyBpIH19XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJhbnN3ZXItb3B0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgW25nQ2xhc3NdPVwieyAnY2xpY2stZGlzYWJsZWQnOiBjbGlja0Rpc2FibGVkLCBzZWxlY3RlZDogaXNBbnN3ZXJPcHRpb25TZWxlY3RlZChhbnN3ZXJPcHRpb24pIH1cIlxuICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwidG9nZ2xlU2VsZWN0aW9uKGFuc3dlck9wdGlvbilcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbnRlbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0XCIgW2lubmVySFRNTF09XCJyZW5kZXJlZFF1ZXN0aW9uLnJlbmRlcmVkU3ViRWxlbWVudHNbaV0/LnRleHQgPz8gJydcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaW50XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlICNyZW5kZXJlZEFuc3dlck9wdGlvbnNIaW50PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IFtpbm5lckhUTUxdPVwicmVuZGVyZWRRdWVzdGlvbi5yZW5kZXJlZFN1YkVsZW1lbnRzW2ldPy5oaW50ID8/ICcnXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGFuc3dlck9wdGlvbi5oaW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibGFiZWwgbGFiZWwtaW5mb1wiIFtuZ2JQb3BvdmVyXT1cInJlbmRlcmVkQW5zd2VyT3B0aW9uc0hpbnRcIiB0cmlnZ2Vycz1cIm1vdXNlZW50ZXI6bW91c2VsZWF2ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFRdWVzdGlvbkNpcmNsZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpelF1ZXN0aW9uLmhpbnRcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzZWxlY3Rpb25cIiBpZD1cIm1jLWFuc3dlci1zZWxlY3Rpb24te3sgaSB9fVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChpc0Fuc3dlck9wdGlvblNlbGVjdGVkKGFuc3dlck9wdGlvbikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJxdWVzdGlvbi5zaW5nbGVDaG9pY2UgPyBmYURvdENpcmNsZSA6IGZhQ2hlY2tTcXVhcmVcIiBzaXplPVwiMnhcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKCFpc0Fuc3dlck9wdGlvblNlbGVjdGVkKGFuc3dlck9wdGlvbikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJxdWVzdGlvbi5zaW5nbGVDaG9pY2UgPyBmYUNpcmNsZSA6IGZhU3F1YXJlXCIgc2l6ZT1cIjJ4XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuICAgIEBpZiAoc2hvd1Jlc3VsdCkge1xuICAgICAgICA8dGFibGUgY2xhc3M9XCJhbnN3ZXItb3B0aW9ucy1yZXN1bHRcIj5cbiAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJjb250ZW50XCI+e3sgJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi5hbnN3ZXInIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzPVwic29sdXRpb25cIj57eyAnYXJ0ZW1pc0FwcC5tdWx0aXBsZUNob2ljZVF1ZXN0aW9uLnNvbHV0aW9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3RoPlxuICAgICAgICAgICAgICAgIEBpZiAoIWZvcmNlU2FtcGxlU29sdXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzPVwicmVzdWx0LXN5bWJvbFwiPjwvdGg+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoIWZvcmNlU2FtcGxlU29sdXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzPVwic2VsZWN0aW9uXCI+e3sgJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi55b3UnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvdGg+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIEBmb3IgKGFuc3dlck9wdGlvbiBvZiBxdWVzdGlvbi5hbnN3ZXJPcHRpb25zOyB0cmFjayBhbnN3ZXJPcHRpb247IGxldCBpID0gJGluZGV4KSB7XG4gICAgICAgICAgICAgICAgPHRyIGNsYXNzPVwiYW5zd2VyLW9wdGlvblwiIGlkPVwiYW5zd2VyLW9wdGlvbi17eyBpIH19XCI+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cImNvbnRlbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0XCIgW2lubmVySFRNTF09XCJyZW5kZXJlZFF1ZXN0aW9uLnJlbmRlcmVkU3ViRWxlbWVudHMhW2ldLnRleHRcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaW50XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlICNyZW5kZXJlZEFuc3dlck9wdGlvbnNIaW50Mj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBbaW5uZXJIVE1MXT1cInJlbmRlcmVkUXVlc3Rpb24ucmVuZGVyZWRTdWJFbGVtZW50cyFbaV0uaGludFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChhbnN3ZXJPcHRpb24uaGludCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImxhYmVsIGxhYmVsLWluZm9cIiBbbmdiUG9wb3Zlcl09XCJyZW5kZXJlZEFuc3dlck9wdGlvbnNIaW50MlwiIHRyaWdnZXJzPVwibW91c2VlbnRlcjptb3VzZWxlYXZlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVF1ZXN0aW9uQ2lyY2xlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6UXVlc3Rpb24uaGludFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgI3JlbmRlcmVkQW5zd2VyT3B0aW9uc0V4cGxhbmF0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IFtpbm5lckhUTUxdPVwicmVuZGVyZWRRdWVzdGlvbi5yZW5kZXJlZFN1YkVsZW1lbnRzIVtpXS5leHBsYW5hdGlvblwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChhbnN3ZXJPcHRpb24uZXhwbGFuYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsYWJlbCBsYWJlbC1wcmltYXJ5XCIgW25nYlBvcG92ZXJdPVwicmVuZGVyZWRBbnN3ZXJPcHRpb25zRXhwbGFuYXRpb25cIiB0cmlnZ2Vycz1cIm1vdXNlZW50ZXI6bW91c2VsZWF2ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFFeGNsYW1hdGlvbkNpcmNsZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpelF1ZXN0aW9uLmV4cGxhbmF0aW9uXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cInNvbHV0aW9uXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKCFhbnN3ZXJPcHRpb24uaW52YWxpZCAmJiAhcXVlc3Rpb24uaW52YWxpZCAmJiBhbnN3ZXJPcHRpb24uaXNDb3JyZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gaWQ9XCJhbnN3ZXItb3B0aW9uLXt7IGkgfX0tY29ycmVjdFwiIGNsYXNzPVwiY29ycmVjdFwiPnt7ICdhcnRlbWlzQXBwLm11bHRpcGxlQ2hvaWNlUXVlc3Rpb24uY29ycmVjdCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghYW5zd2VyT3B0aW9uLmludmFsaWQgJiYgIXF1ZXN0aW9uLmludmFsaWQgJiYgIWFuc3dlck9wdGlvbi5pc0NvcnJlY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBpZD1cImFuc3dlci1vcHRpb24te3sgaSB9fS13cm9uZ1wiIGNsYXNzPVwid3JvbmdcIj57eyAnYXJ0ZW1pc0FwcC5tdWx0aXBsZUNob2ljZVF1ZXN0aW9uLndyb25nJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGFuc3dlck9wdGlvbi5pbnZhbGlkIHx8IHF1ZXN0aW9uLmludmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBpZD1cImFuc3dlci1vcHRpb24te3sgaSB9fS1pbnZhbGlkXCIgY2xhc3M9XCJ3cm9uZ1wiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpelF1ZXN0aW9uLmludmFsaWRcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGFuc3dlck9wdGlvbi5pbnZhbGlkIHx8IHF1ZXN0aW9uLmludmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBuZ2JUb29sdGlwPVwie3sgJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi5pbnZhbGlkJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIiBzdHlsZT1cImNvbG9yOiBibGFja1wiIFtpY29uXT1cImZhUXVlc3Rpb25DaXJjbGVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoIWZvcmNlU2FtcGxlU29sdXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cInJlc3VsdC1zeW1ib2xcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhcXVlc3Rpb24uaW52YWxpZCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhYW5zd2VyT3B0aW9uLmludmFsaWQgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKChpc0Fuc3dlck9wdGlvblNlbGVjdGVkKGFuc3dlck9wdGlvbikgJiYgIWFuc3dlck9wdGlvbi5pc0NvcnJlY3QpIHx8ICghaXNBbnN3ZXJPcHRpb25TZWxlY3RlZChhbnN3ZXJPcHRpb24pICYmIGFuc3dlck9wdGlvbi5pc0NvcnJlY3QpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBzaXplPVwiMnhcIiBbaWNvbl09XCJmYUV4Y2xhbWF0aW9uVHJpYW5nbGVcIiBjbGFzcz1cIndhcm5pbmdcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKCFmb3JjZVNhbXBsZVNvbHV0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJzZWxlY3Rpb25cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGlzQW5zd2VyT3B0aW9uU2VsZWN0ZWQoYW5zd2VyT3B0aW9uKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJxdWVzdGlvbi5zaW5nbGVDaG9pY2UgPyBmYURvdENpcmNsZSA6IGZhQ2hlY2tTcXVhcmVcIiBzaXplPVwiMnhcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWlzQW5zd2VyT3B0aW9uU2VsZWN0ZWQoYW5zd2VyT3B0aW9uKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJxdWVzdGlvbi5zaW5nbGVDaG9pY2UgPyBmYUNpcmNsZSA6IGZhU3F1YXJlXCIgc2l6ZT1cIjJ4XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgfVxuICAgICAgICA8L3RhYmxlPlxuICAgIH1cbjwvZGl2PlxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU2hvcnRBbnN3ZXJRdWVzdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L3Nob3J0LWFuc3dlci1xdWVzdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBTaG9ydEFuc3dlck1hcHBpbmcgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9zaG9ydC1hbnN3ZXItbWFwcGluZy5tb2RlbCc7XG5pbXBvcnQgeyBTaG9ydEFuc3dlclNwb3QgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9zaG9ydC1hbnN3ZXItc3BvdC5tb2RlbCc7XG5pbXBvcnQgeyBTaG9ydEFuc3dlclNvbHV0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovc2hvcnQtYW5zd2VyLXNvbHV0aW9uLm1vZGVsJztcbmltcG9ydCB7IGNsb25lRGVlcCB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBodG1sRm9yTWFya2Rvd24gfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvbWFya2Rvd24uY29udmVyc2lvbi51dGlsJztcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBTaG9ydEFuc3dlclF1ZXN0aW9uVXRpbCB7XG4gICAgY29uc3RydWN0b3IoKSB7fVxuXG4gICAgLyoqXG4gICAgICogVmFsaWRhdGUgdGhhdCBubyBtYXBwaW5nIGV4aXN0cyB0aGF0IG1ha2VzIGl0IGltcG9zc2libGUgdG8gc29sdmUgdGhlIHF1ZXN0aW9uLlxuICAgICAqIFdlIGl0ZXJhdGUgdGhyb3VnaCBhbGwgc3BvdHMgYW5kIHJlbW92ZSBhbGwgcG9zc2libGUgbWFwcGluZ3MgKHNvbHV0aW9ucykgZm9yIHRoYXQgc3BvdC5cbiAgICAgKiBJZiB0aGVyZSBhcmUgc3RpbGwgbWFwcGluZ3MgKHNvbHV0aW9ucykgbGVmdCBmb3IgdGhlIG90aGVyIHNwb3RzIGV2ZXJ5dGhpbmcgaXMgb2suXG4gICAgICogSW4gY2FzZSB3ZSBoYXZlIG11bHRpcGxlIG1hcHBpbmdzIGZvciBzcG90cywgd2UgY2hlY2sgd2hldGhlciB0aGVyZSBhcmUgYW4gZXF1YWwgb3IgZ3JlYXRlciBhbW91bnQgb2YgbWFwcGluZ3MgdGhhbiBzcG90cy5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBxdWVzdGlvbiB7b2JqZWN0fSB0aGUgcXVlc3Rpb24gdG8gY2hlY2tcbiAgICAgKiBAcmV0dXJuIHtib29sZWFufSB0cnVlLCBpZiB0aGUgY29uZGl0aW9uIGlzIG1ldCwgb3RoZXJ3aXNlIGZhbHNlXG4gICAgICovXG5cbiAgICB2YWxpZGF0ZU5vTWlzbGVhZGluZ1Nob3J0QW5zd2VyTWFwcGluZyhxdWVzdGlvbjogU2hvcnRBbnN3ZXJRdWVzdGlvbikge1xuICAgICAgICBpZiAoIXF1ZXN0aW9uLmNvcnJlY3RNYXBwaW5ncykge1xuICAgICAgICAgICAgLy8gbm8gY29ycmVjdCBtYXBwaW5ncyBhdCBhbGwgbWVhbnMgdGhlcmUgY2FuIGJlIG5vIG1pc2xlYWRpbmcgbWFwcGluZ3NcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgbGV0IHVudXNlZE1hcHBpbmdzOiBTaG9ydEFuc3dlck1hcHBpbmdbXSA9IGNsb25lRGVlcChxdWVzdGlvbi5jb3JyZWN0TWFwcGluZ3MpO1xuICAgICAgICBjb25zdCBzcG90c0NhbkJlU29sdmVkOiBib29sZWFuW10gPSBbXTtcblxuICAgICAgICBmb3IgKGNvbnN0IHNwb3Qgb2YgcXVlc3Rpb24uc3BvdHMhKSB7XG4gICAgICAgICAgICBsZXQgYXRMZWFzdE9uZU1hcHBpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgIGNvbnN0IHNvbHV0aW9uc0ZvclNwb3RzID0gdGhpcy5nZXRBbGxTb2x1dGlvbnNGb3JTcG90KHF1ZXN0aW9uLmNvcnJlY3RNYXBwaW5ncywgc3BvdCkhO1xuXG4gICAgICAgICAgICBzb2x1dGlvbnNGb3JTcG90cy5mb3JFYWNoKChzb2x1dGlvbikgPT4ge1xuICAgICAgICAgICAgICAgIGlmICh1bnVzZWRNYXBwaW5ncy5sZW5ndGggPiAwICYmIHVudXNlZE1hcHBpbmdzLmxlbmd0aCAhPT0gcXVlc3Rpb24uY29ycmVjdE1hcHBpbmdzIS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgYXRMZWFzdE9uZU1hcHBpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyB1bnVzZWRNYXBwaW5ncy5sZW5ndGggPiAwIHdpbGwgYmUgYWx3YXlzIHRydWUgZm9yIHRoZSBmaXJzdCBpdGVyYXRpb24sIHRoZXJlZm9yZSB3ZSBuZWVkIGEgc3BlY2lhbCBjaGVja1xuICAgICAgICAgICAgICAgIGlmICh1bnVzZWRNYXBwaW5ncy5sZW5ndGggPT09IHF1ZXN0aW9uLmNvcnJlY3RNYXBwaW5ncyEubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFdlIG5lZWQgdG8gdmVyaWZ5IGlmIHRoZSBmaXJzdCBzcG90IGhhcyBtYXBwaW5ncyAoc29sdXRpb25zKSB0aGF0IGlzIG9ubHkgZm9yIGl0c2VsZlxuICAgICAgICAgICAgICAgICAgICAvLyBJbiBjYXNlIHRoZXJlIGFyZSBtdWx0aXBsZSBtYXBwaW5ncyAoc29sdXRpb25zKSBmb3Igc3BvdHMsIHdlIHVzZSBoYXNTcG90RW5vdWdoU29sdXRpb25zXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGFsbFNvbHV0aW9uc0ZvclNwb3QgPSB0aGlzLmdldEFsbFNvbHV0aW9uc0ZvclNwb3QocXVlc3Rpb24uY29ycmVjdE1hcHBpbmdzLCBzcG90KSE7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGFsbFNvbHV0aW9uc09ubHlGb3JTcG90ID0gYWxsU29sdXRpb25zRm9yU3BvdC5maWx0ZXIoXG4gICAgICAgICAgICAgICAgICAgICAgICAoc29sdXRpb25Gb3JTcG90KSA9PiB0aGlzLmdldEFsbFNwb3RzRm9yU29sdXRpb25zKHF1ZXN0aW9uLmNvcnJlY3RNYXBwaW5ncywgc29sdXRpb25Gb3JTcG90KSEubGVuZ3RoID09PSAxLFxuICAgICAgICAgICAgICAgICAgICApO1xuXG4gICAgICAgICAgICAgICAgICAgIGlmIChhbGxTb2x1dGlvbnNPbmx5Rm9yU3BvdC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhdExlYXN0T25lTWFwcGluZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gUmVtb3ZlIGV2ZXJ5IHNvbHV0aW9uIGZvciBhIHNwb3QgaW4gdGhlIG1hcHBpbmdcbiAgICAgICAgICAgICAgICB1bnVzZWRNYXBwaW5ncyA9IHVudXNlZE1hcHBpbmdzLmZpbHRlcigobWFwcGluZykgPT4gIXRoaXMuaXNTYW1lU29sdXRpb24oc29sdXRpb24sIG1hcHBpbmcuc29sdXRpb24pKTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAvLyBJbiBjYXNlIHRoZXJlIGFyZSBtdWx0aXBsZSBtYXBwaW5ncyBmb3IgdGhlIHNwb3RzIHRoZXJlIGhhdmUgdG8gYmUgYXQgbGVhc3QgYXMgbWFueSBzb2x1dGlvbnMgYXMgc3BvdHNcbiAgICAgICAgICAgIGNvbnN0IGhhc1Nwb3RFbm91Z2hTb2x1dGlvbnMgPSB0aGlzLmdldEFsbFNvbHV0aW9uc0ZvclNwb3QocXVlc3Rpb24uY29ycmVjdE1hcHBpbmdzLCBzcG90KSEubGVuZ3RoID49IHF1ZXN0aW9uLnNwb3RzIS5sZW5ndGg7XG4gICAgICAgICAgICAvLyBDaGVjayB3aGV0aGVyIGEgbWFwcGluZyBpcyBzdGlsbCBsZWZ0IHRvIHNvbHZlIGEgc3BvdCBjb3JyZWN0bHkuXG4gICAgICAgICAgICBpZiAoYXRMZWFzdE9uZU1hcHBpbmcgfHwgaGFzU3BvdEVub3VnaFNvbHV0aW9ucykge1xuICAgICAgICAgICAgICAgIHNwb3RzQ2FuQmVTb2x2ZWQucHVzaCh0cnVlKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgc3BvdHNDYW5CZVNvbHZlZC5wdXNoKGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gIXNwb3RzQ2FuQmVTb2x2ZWQuaW5jbHVkZXMoZmFsc2UpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIHRoZSBnaXZlbiBzb2x1dGlvbiBhbmQgc3BvdCBhcmUgbWFwcGVkIHRvZ2V0aGVyIGluIHRoZSBnaXZlbiBtYXBwaW5nc1xuICAgICAqXG4gICAgICogQHBhcmFtIG1hcHBpbmdzIHtBcnJheX0gdGhlIGV4aXN0aW5nIG1hcHBpbmdzIHRvIGNvbnNpZGVyXG4gICAgICogQHBhcmFtIHNvbHV0aW9uIHtvYmplY3R9IHRoZSBzb2x1dGlvbiB0byBzZWFyY2ggZm9yXG4gICAgICogQHBhcmFtIHNwb3Qge29iamVjdH0gdGhlIHNwb3QgdG8gc2VhcmNoIGZvclxuICAgICAqIEByZXR1cm4ge2Jvb2xlYW59IHRydWUgaWYgdGhleSBhcmUgbWFwcGVkIHRvZ2V0aGVyLCBvdGhlcndpc2UgZmFsc2VcbiAgICAgKi9cbiAgICBpc01hcHBlZFRvZ2V0aGVyKG1hcHBpbmdzPzogU2hvcnRBbnN3ZXJNYXBwaW5nW10sIHNvbHV0aW9uPzogU2hvcnRBbnN3ZXJTb2x1dGlvbiwgc3BvdD86IFNob3J0QW5zd2VyU3BvdCkge1xuICAgICAgICByZXR1cm4gISF0aGlzLmdldFNob3J0QW5zd2VyTWFwcGluZyhtYXBwaW5ncywgc29sdXRpb24sIHNwb3QpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBhbGwgc3BvdHMgdGhhdCBhcmUgbWFwcGVkIHRvIHRoZSBnaXZlbiBzb2x1dGlvbnNcbiAgICAgKlxuICAgICAqIEBwYXJhbSBtYXBwaW5ncyB7QXJyYXl9IHRoZSBleGlzdGluZyBtYXBwaW5ncyB0byBjb25zaWRlclxuICAgICAqIEBwYXJhbSBzb2x1dGlvbiB7b2JqZWN0fSB0aGUgc29sdXRpb24gdGhhdCB0aGUgcmV0dXJuZWQgc3BvdHMgaGF2ZSB0byBiZSBtYXBwZWQgdG9cbiAgICAgKiBAcmV0dXJuIHtBcnJheX0gdGhlIHJlc3VsdGluZyBzcG90c1xuICAgICAqL1xuICAgIGdldEFsbFNwb3RzRm9yU29sdXRpb25zKG1hcHBpbmdzPzogU2hvcnRBbnN3ZXJNYXBwaW5nW10sIHNvbHV0aW9uPzogU2hvcnRBbnN3ZXJTb2x1dGlvbikge1xuICAgICAgICByZXR1cm4gbWFwcGluZ3NcbiAgICAgICAgICAgID8uZmlsdGVyKGZ1bmN0aW9uIChtYXBwaW5nKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuaXNTYW1lU29sdXRpb24obWFwcGluZy5zb2x1dGlvbiwgc29sdXRpb24pO1xuICAgICAgICAgICAgfSwgdGhpcylcbiAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKG1hcHBpbmcpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbWFwcGluZy5zcG90ITtcbiAgICAgICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBhbGwgc29sdXRpb25zIHRoYXQgYXJlIG1hcHBlZCB0byB0aGUgZ2l2ZW4gc3BvdFxuICAgICAqXG4gICAgICogQHBhcmFtIG1hcHBpbmdzIHtBcnJheX0gdGhlIGV4aXN0aW5nIG1hcHBpbmdzIHRvIGNvbnNpZGVyXG4gICAgICogQHBhcmFtIHNwb3Qge29iamVjdH0gdGhlIHNwb3QgZm9yIHdoaWNoIHRvIGdldCB0aGUgc29sdXRpb25zXG4gICAgICogQHJldHVybiB7QXJyYXl9IHRoZSByZXN1bHRpbmcgc29sdXRpb25zXG4gICAgICovXG4gICAgZ2V0QWxsU29sdXRpb25zRm9yU3BvdChtYXBwaW5ncz86IFNob3J0QW5zd2VyTWFwcGluZ1tdLCBzcG90PzogU2hvcnRBbnN3ZXJTcG90KSB7XG4gICAgICAgIHJldHVybiBtYXBwaW5nc1xuICAgICAgICAgICAgPy5maWx0ZXIoKG1hcHBpbmcpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5pc1NhbWVTcG90KG1hcHBpbmcuc3BvdCwgc3BvdCk7XG4gICAgICAgICAgICB9LCB0aGlzKVxuICAgICAgICAgICAgLm1hcCgobWFwcGluZykgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiBtYXBwaW5nLnNvbHV0aW9uITtcbiAgICAgICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIHNldDEgYW5kIHNldDIgY29udGFpbiB0aGUgc2FtZSBzb2x1dGlvbnMgb3Igc3BvdHNcbiAgICAgKlxuICAgICAqIEBwYXJhbSBzZXQxIHtBcnJheX0gb25lIHNldCBvZiBzb2x1dGlvbnMgb3Igc3BvdHNcbiAgICAgKiBAcGFyYW0gc2V0MiB7QXJyYXl9IGFub3RoZXIgc2V0IG9mIHNvbHV0aW9ucyBvciBzcG90c1xuICAgICAqIEByZXR1cm4ge2Jvb2xlYW59IHRydWUgaWYgdGhlIHNldHMgY29udGFpbiB0aGUgc2FtZSBpdGVtcywgb3RoZXJ3aXNlIGZhbHNlXG4gICAgICovXG4gICAgaXNTYW1lU2V0T2ZTcG90cyhzZXQxPzogU2hvcnRBbnN3ZXJTcG90W10sIHNldDI/OiBTaG9ydEFuc3dlclNwb3RbXSkge1xuICAgICAgICBpZiAoc2V0MT8ubGVuZ3RoICE9PSBzZXQyPy5sZW5ndGgpIHtcbiAgICAgICAgICAgIC8vIGRpZmZlcmVudCBudW1iZXIgb2YgZWxlbWVudHMgPT4gaW1wb3NzaWJsZSB0byBjb250YWluIHRoZSBzYW1lIGVsZW1lbnRzXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIC8vIGZvciBldmVyeSBlbGVtZW50IGluIHNldDEgdGhlcmUgaGFzIHRvIGJlIGFuIGlkZW50aWNhbCBlbGVtZW50IGluIHNldDIgYW5kIHZpY2UgdmVyc2FcbiAgICAgICAgICAgIHNldDE/LmV2ZXJ5KChzcG90MSkgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiBzZXQyPy5zb21lKChzcG90MikgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5pc1NhbWVTcG90KHNwb3QxLCBzcG90Mik7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KSAmJlxuICAgICAgICAgICAgc2V0Mj8uZXZlcnkoKHNwb3QyKSA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHNldDE/LnNvbWUoKHNwb3QxKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmlzU2FtZVNwb3Qoc3BvdDEsIHNwb3QyKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IHRoZSBtYXBwaW5nIHRoYXQgbWFwcyB0aGUgZ2l2ZW4gc29sdXRpb24gYW5kIHNwb3QgdG9nZXRoZXJcbiAgICAgKlxuICAgICAqIEBwYXJhbSBtYXBwaW5ncyB7QXJyYXl9IHRoZSBleGlzdGluZyBtYXBwaW5ncyB0byBjb25zaWRlclxuICAgICAqIEBwYXJhbSBzb2x1dGlvbiB7b2JqZWN0fSB0aGUgc29sdXRpb24gdG8gc2VhcmNoIGZvclxuICAgICAqIEBwYXJhbSBzcG90IHtvYmplY3R9IHRoZSBzcG90IHRvIHNlYXJjaCBmb3JcbiAgICAgKiBAcmV0dXJuIHRoZSBmb3VuZCBtYXBwaW5nLCBvciB1bmRlZmluZWQgaWYgaXQgZG9lc24ndCBleGlzdFxuICAgICAqL1xuICAgIGdldFNob3J0QW5zd2VyTWFwcGluZyhtYXBwaW5ncz86IFNob3J0QW5zd2VyTWFwcGluZ1tdLCBzb2x1dGlvbj86IFNob3J0QW5zd2VyU29sdXRpb24sIHNwb3Q/OiBTaG9ydEFuc3dlclNwb3QpIHtcbiAgICAgICAgcmV0dXJuIG1hcHBpbmdzPy5maW5kKChtYXBwaW5nOiBTaG9ydEFuc3dlck1hcHBpbmcpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmlzU2FtZVNwb3Qoc3BvdCwgbWFwcGluZy5zcG90KSAmJiB0aGlzLmlzU2FtZVNvbHV0aW9uKHNvbHV0aW9uLCBtYXBwaW5nLnNvbHV0aW9uKTtcbiAgICAgICAgfSwgdGhpcyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY29tcGFyZSBpZiB0aGUgdHdvIG9iamVjdHMgYXJlIHRoZSBzYW1lIHNwb3RcbiAgICAgKlxuICAgICAqIEBwYXJhbSBhIHtvYmplY3R9IGEgc3BvdFxuICAgICAqIEBwYXJhbSBiIHtvYmplY3R9IGFub3RoZXIgc3BvdFxuICAgICAqIEByZXR1cm4ge2Jvb2xlYW59XG4gICAgICovXG4gICAgaXNTYW1lU3BvdChhPzogU2hvcnRBbnN3ZXJTcG90LCBiPzogU2hvcnRBbnN3ZXJTcG90KTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiBhID09PSBiIHx8IChhICE9PSB1bmRlZmluZWQgJiYgYiAhPT0gdW5kZWZpbmVkICYmICgoYS5pZCAmJiBiLmlkICYmIGEuaWQgPT09IGIuaWQpIHx8IChhLnRlbXBJRCAhPSB1bmRlZmluZWQgJiYgYi50ZW1wSUQgIT0gdW5kZWZpbmVkICYmIGEudGVtcElEID09PSBiLnRlbXBJRCkpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjb21wYXJlIGlmIHRoZSB0d28gb2JqZWN0cyBhcmUgdGhlIHNhbWUgc29sdXRpb25cbiAgICAgKlxuICAgICAqIEBwYXJhbSBhIHtvYmplY3R9IGEgc29sdXRpb25cbiAgICAgKiBAcGFyYW0gYiB7b2JqZWN0fSBhbm90aGVyIHNvbHV0aW9uXG4gICAgICogQHJldHVybiB7Ym9vbGVhbn1cbiAgICAgKi9cbiAgICBpc1NhbWVTb2x1dGlvbihhPzogU2hvcnRBbnN3ZXJTb2x1dGlvbiwgYj86IFNob3J0QW5zd2VyU29sdXRpb24pOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIGEgPT09IGIgfHwgKGEgIT09IHVuZGVmaW5lZCAmJiBiICE9PSB1bmRlZmluZWQgJiYgKChhLmlkICYmIGIuaWQgJiYgYS5pZCA9PT0gYi5pZCkgfHwgKGEudGVtcElEICE9IHVuZGVmaW5lZCAmJiBiLnRlbXBJRCAhPSB1bmRlZmluZWQgJiYgYS50ZW1wSUQgPT09IGIudGVtcElEKSkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGNoZWNrcyBpZiBldmVyeSBzcG90IGhhcyBhIHNvbHV0aW9uXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbWFwcGluZ3Mge29iamVjdH0gbWFwcGluZ3NcbiAgICAgKiBAcGFyYW0gc3BvdHMge29iamVjdH0gc3BvdHNcbiAgICAgKiBAcmV0dXJuIHtib29sZWFufVxuICAgICAqL1xuICAgIGV2ZXJ5U3BvdEhhc0FTb2x1dGlvbihtYXBwaW5nczogU2hvcnRBbnN3ZXJNYXBwaW5nW10sIHNwb3RzOiBTaG9ydEFuc3dlclNwb3RbXSk6IGJvb2xlYW4ge1xuICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgIGZvciAoY29uc3Qgc3BvdCBvZiBzcG90cykge1xuICAgICAgICAgICAgY29uc3Qgc29sdXRpb25zID0gdGhpcy5nZXRBbGxTb2x1dGlvbnNGb3JTcG90KG1hcHBpbmdzLCBzcG90KTtcbiAgICAgICAgICAgIGlmIChzb2x1dGlvbnMgJiYgc29sdXRpb25zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBpKys7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGkgPT09IHNwb3RzLmxlbmd0aDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjaGVja3MgaWYgZXZlcnkgbWFwcGVkIHNvbHV0aW9uIGhhcyBhIHNwb3RcbiAgICAgKlxuICAgICAqIEBwYXJhbSBtYXBwaW5ncyB7b2JqZWN0fSBtYXBwaW5nc1xuICAgICAqIEByZXR1cm4ge2Jvb2xlYW59XG4gICAgICovXG4gICAgZXZlcnlNYXBwZWRTb2x1dGlvbkhhc0FTcG90KG1hcHBpbmdzOiBTaG9ydEFuc3dlck1hcHBpbmdbXSk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gIShtYXBwaW5ncy5maWx0ZXIoKG1hcHBpbmcpID0+IG1hcHBpbmcuc3BvdCA9PT0gdW5kZWZpbmVkKS5sZW5ndGggPiAwKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjaGVja3MgaWYgbWFwcGluZ3MgaGF2ZSBkdXBsaWNhdGUgdmFsdWVzXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbWFwcGluZ3NcbiAgICAgKiBAcmV0dXJuIHtib29sZWFufVxuICAgICAqL1xuICAgIGhhc01hcHBpbmdEdXBsaWNhdGVWYWx1ZXMobWFwcGluZ3M6IFNob3J0QW5zd2VyTWFwcGluZ1tdKTogYm9vbGVhbiB7XG4gICAgICAgIGlmIChtYXBwaW5ncy5maWx0ZXIoKG1hcHBpbmcpID0+IG1hcHBpbmcuc3BvdCA9PT0gdW5kZWZpbmVkKS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGR1cGxpY2F0ZVZhbHVlcyA9IDA7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbWFwcGluZ3MubGVuZ3RoIC0gMTsgaSsrKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBqID0gaSArIDE7IGogPCBtYXBwaW5ncy5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgIGlmIChtYXBwaW5nc1tpXS5zcG90IS5zcG90TnIgPT09IG1hcHBpbmdzW2pdLnNwb3QhLnNwb3ROciAmJiBtYXBwaW5nc1tpXS5zb2x1dGlvbiEudGV4dCEgPT09IG1hcHBpbmdzW2pdLnNvbHV0aW9uIS50ZXh0ISkge1xuICAgICAgICAgICAgICAgICAgICBkdXBsaWNhdGVWYWx1ZXMrKztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGR1cGxpY2F0ZVZhbHVlcyA+IDA7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGlzcGxheSBhIHNhbXBsZSBzb2x1dGlvbiBpbnN0ZWFkIG9mIHRoZSBzdHVkZW50J3MgYW5zd2VyXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge1Nob3J0QW5zd2VyUXVlc3Rpb259IHF1ZXN0aW9uXG4gICAgICogQHJldHVybnMge1Nob3J0QW5zd2VyU29sdXRpb25bXX1cbiAgICAgKi9cbiAgICBnZXRTYW1wbGVTb2x1dGlvbnMocXVlc3Rpb246IFNob3J0QW5zd2VyUXVlc3Rpb24pOiBTaG9ydEFuc3dlclNvbHV0aW9uW10ge1xuICAgICAgICBjb25zdCBzYW1wbGVTb2x1dGlvbnM6IFNob3J0QW5zd2VyU29sdXRpb25bXSA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IHNwb3Qgb2YgcXVlc3Rpb24uc3BvdHMhKSB7XG4gICAgICAgICAgICBjb25zdCBzb2x1dGlvbnNGb3JTcG90ID0gdGhpcy5nZXRBbGxTb2x1dGlvbnNGb3JTcG90KHF1ZXN0aW9uLmNvcnJlY3RNYXBwaW5ncyEsIHNwb3QpO1xuICAgICAgICAgICAgZm9yIChjb25zdCBtYXBwaW5nIG9mIHF1ZXN0aW9uLmNvcnJlY3RNYXBwaW5ncyEpIHtcbiAgICAgICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgICAgIG1hcHBpbmcuc3BvdCEuaWQgPT09IHNwb3QuaWQgJiZcbiAgICAgICAgICAgICAgICAgICAgIXNhbXBsZVNvbHV0aW9ucy5zb21lKFxuICAgICAgICAgICAgICAgICAgICAgICAgKHNhbXBsZVNvbHV0aW9uKSA9PiBzYW1wbGVTb2x1dGlvbi50ZXh0ID09PSBtYXBwaW5nLnNvbHV0aW9uIS50ZXh0ICYmICF0aGlzLmFsbFNvbHV0aW9uc0FyZUluU2FtcGxlU29sdXRpb24oc29sdXRpb25zRm9yU3BvdCwgc2FtcGxlU29sdXRpb25zKSxcbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICBzYW1wbGVTb2x1dGlvbnMucHVzaChtYXBwaW5nLnNvbHV0aW9uISk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc2FtcGxlU29sdXRpb25zO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGNoZWNrcyBpZiBhbGwgc29sdXRpb25zIGFyZSBpbiB0aGUgc2FtcGxlIHNvbHV0aW9uXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge1Nob3J0QW5zd2VyU29sdXRpb25bXX0gc29sdXRpb25zRm9yU3BvdFxuICAgICAqIEBwYXJhbSB7U2hvcnRBbnN3ZXJTb2x1dGlvbltdfSBzYW1wbGVTb2x1dGlvbnNcbiAgICAgKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAgICAgKi9cbiAgICBhbGxTb2x1dGlvbnNBcmVJblNhbXBsZVNvbHV0aW9uKHNvbHV0aW9uc0ZvclNwb3Q/OiBTaG9ydEFuc3dlclNvbHV0aW9uW10sIHNhbXBsZVNvbHV0aW9ucz86IFNob3J0QW5zd2VyU29sdXRpb25bXSk6IGJvb2xlYW4ge1xuICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgIGZvciAoY29uc3Qgc29sdXRpb25Gb3JTcG90IG9mIHNvbHV0aW9uc0ZvclNwb3QgfHwgW10pIHtcbiAgICAgICAgICAgIGZvciAoY29uc3Qgc2FtcGxlU29sdXRpb24gb2Ygc2FtcGxlU29sdXRpb25zIHx8IFtdKSB7XG4gICAgICAgICAgICAgICAgaWYgKHNvbHV0aW9uRm9yU3BvdC50ZXh0ID09PSBzYW1wbGVTb2x1dGlvbi50ZXh0KSB7XG4gICAgICAgICAgICAgICAgICAgIGkrKztcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBpID09PSBzb2x1dGlvbnNGb3JTcG90Py5sZW5ndGg7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY2hlY2tzIGlmIGF0IGxlYXN0IHRoZXJlIGFyZSBhcyBtYW55IHNvbHV0aW9ucyBhcyBzcG90c1xuICAgICAqXG4gICAgICogQHBhcmFtIHtTaG9ydEFuc3dlclF1ZXN0aW9ufSBxdWVzdGlvblxuICAgICAqIEByZXR1cm5zIHtib29sZWFufVxuICAgICAqL1xuICAgIGF0TGVhc3RBc01hbnlTb2x1dGlvbnNBc1Nwb3RzKHF1ZXN0aW9uOiBTaG9ydEFuc3dlclF1ZXN0aW9uKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiBxdWVzdGlvbi5zcG90cyEubGVuZ3RoIDw9IHF1ZXN0aW9uLnNvbHV0aW9ucyEubGVuZ3RoO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFdlIGNyZWF0ZSBub3cgdGhlIHN0cnVjdHVyZSBvbiBob3cgdG8gZGlzcGxheSB0aGUgdGV4dCBvZiB0aGUgcXVlc3Rpb25cbiAgICAgKiAxLiBUaGUgcXVlc3Rpb24gdGV4dCBpcyBzcGxpdCBhdCBldmVyeSBuZXcgbGluZS4gVGhlIGZpcnN0IGVsZW1lbnQgb2YgdGhlIGFycmF5IHdvdWxkIGJlIHRoZW4gdGhlIGZpcnN0IGxpbmUgb2YgdGhlIHF1ZXN0aW9uIHRleHQuXG4gICAgICogMi4gTm93IGVhY2ggbGluZSBvZiB0aGUgcXVlc3Rpb24gdGV4dCB3aWxsIGJlIGRpdmlkZWQgaW50byB0ZXh0IGJlZm9yZSBzcG90IHRhZywgc3BvdCB0YWcgYW5kIHRleHQgYWZ0ZXIgc3BvdCB0YWcuXG4gICAgICogKGUuZyAnRW50ZXIgWy1zcG90IDFdIGxvbmcgWy1zcG90IDJdIGlmIG5lZWRlZCcgd2lsbCBiZSB0cmFuc2Zvcm1lZCB0byBbW1wiRW50ZXJcIiwgXCJbLXNwb3QgMV1cIiwgXCJsb25nXCIsIFwiWy1zcG90IDJdXCIsIFwiaWYgbmVlZGVkXCJdXSlcbiAgICAgKlxuICAgICAqIEBwYXJhbSBxdWVzdGlvblRleHRcbiAgICAgKiBAcmV0dXJucyB7c3RyaW5nW11bXX1cbiAgICAgKi9cbiAgICBkaXZpZGVRdWVzdGlvblRleHRJbnRvVGV4dFBhcnRzKHF1ZXN0aW9uVGV4dDogc3RyaW5nKTogc3RyaW5nW11bXSB7XG4gICAgICAgIGNvbnN0IHNwb3RSZWdFeHBvID0gL1xcWy1zcG90XFxzKlswLTldK1xcXS9nO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBJbnRlcmxlYXZlcyBlbGVtZW50cyBvZiB0d28gbGlzdHMgeHMgYW5kIHlzIHJlY3Vyc2l2ZWx5XG4gICAgICAgICAqIEBwYXJhbSB4IEZpcnN0IGVsZW1lbnRcbiAgICAgICAgICogQHBhcmFtIHhzIFJlc3Qgb2YgdGhlIGxpc3RcbiAgICAgICAgICogQHBhcmFtIHlzIE90aGVyIGxpc3RcbiAgICAgICAgICovXG4gICAgICAgIGZ1bmN0aW9uIGludGVybGVhdmUoW3gsIC4uLnhzXTogc3RyaW5nW10sIHlzOiBzdHJpbmdbXSA9IFtdKTogc3RyaW5nW10ge1xuICAgICAgICAgICAgcmV0dXJuIHggPT09IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgID8geXMgLy8gYmFzZTogbm8geFxuICAgICAgICAgICAgICAgIDogW3gsIC4uLmludGVybGVhdmUoeXMsIHhzKV07IC8vIGluZHVjdGl2ZTogc29tZSB4XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcXVlc3Rpb25UZXh0LnNwbGl0KC9cXG4vZykubWFwKChsaW5lKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBzcG90cyA9IGxpbmUubWF0Y2goc3BvdFJlZ0V4cG8pIHx8IFtdO1xuICAgICAgICAgICAgY29uc3QgdGV4dHMgPSBsaW5lLnNwbGl0KHNwb3RSZWdFeHBvKS5tYXAoKHRleHQpID0+IHRleHQudHJpbSgpKTtcbiAgICAgICAgICAgIHJldHVybiBpbnRlcmxlYXZlKHRleHRzLCBzcG90cykuZmlsdGVyKCh4KSA9PiB4Lmxlbmd0aCA+IDApO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjaGVja3MgaWYgdGV4dCBpcyBhbiBpbnB1dCBmaWVsZCAoY2hlY2sgZm9yIHNwb3QgdGFnKVxuICAgICAqIEBwYXJhbSB0ZXh0XG4gICAgICovXG4gICAgaXNJbnB1dEZpZWxkKHRleHQ6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gISh0ZXh0LnNlYXJjaCgvXFxbLXNwb3QvZykgPT09IC0xKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXRzIGp1c3QgdGhlIHNwb3QgbnVtYmVyXG4gICAgICogQHBhcmFtIHRleHRcbiAgICAgKi9cbiAgICBnZXRTcG90TnIodGV4dDogc3RyaW5nKTogbnVtYmVyIHtcbiAgICAgICAgLy8gc2VwYXJhdGUgXCJbLXNwb3QgMV1cIiBpbnRvIGp1c3QgXCIxXCJcbiAgICAgICAgcmV0dXJuICt0ZXh0XG4gICAgICAgICAgICAuc3BsaXQoL1xcWy1zcG90L2cpWzFdXG4gICAgICAgICAgICAuc3BsaXQoJ10nKVswXVxuICAgICAgICAgICAgLnRyaW0oKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXRzIHRoZSBzcG90IGZvciBhIHNwZWNpZmljIHNwb3ROclxuICAgICAqIEBwYXJhbSBzcG90TnIgdGhlIHNwb3QgbnVtYmVyIGZvciB3aGljaCB0aGUgc3BvcnQgc2hvdWxkIGJlIHJldHJpdmVkXG4gICAgICogQHBhcmFtIHF1ZXN0aW9uXG4gICAgICovXG4gICAgZ2V0U3BvdChzcG90TnI6IG51bWJlciwgcXVlc3Rpb246IFNob3J0QW5zd2VyUXVlc3Rpb24pOiBTaG9ydEFuc3dlclNwb3Qge1xuICAgICAgICByZXR1cm4gcXVlc3Rpb24uc3BvdHMhLmZpbHRlcigoc3BvdCkgPT4gc3BvdC5zcG90TnIgPT09IHNwb3ROcilbMF07XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogV2UgdHJhbnNmb3JtIG5vdyB0aGUgZGlmZmVyZW50IHRleHQgcGFydHMgb2YgdGhlIHF1ZXN0aW9uIHRleHQgdG8gSFRNTC5cbiAgICAgKiAxLiBXZSBpdGVyYXRlIHRocm91Z2ggZXZlcnkgbGluZSBvZiB0aGUgcXVlc3Rpb24gdGV4dC5cbiAgICAgKiAyLiBXZSBpdGVyYXRlIHRocm91Z2ggZXZlcnkgZWxlbWVudCBvZiBlYWNoIGxpbmUgb2YgdGhlIHF1ZXN0aW9uIHRleHQgYW5kIHNldCBlYWNoIGVsZW1lbnQgd2l0aCB0aGUgbmV3IEhUTUwuXG4gICAgICogQHBhcmFtIHRleHRQYXJ0c1xuICAgICAqIEByZXR1cm5zIHtzdHJpbmdbXVtdfVxuICAgICAqL1xuICAgIHRyYW5zZm9ybVRleHRQYXJ0c0ludG9IVE1MKHRleHRQYXJ0czogc3RyaW5nW11bXSk6IHN0cmluZ1tdW10ge1xuICAgICAgICBjb25zdCBmb3JtYXR0ZWRUZXh0UGFydHMgPSB0ZXh0UGFydHMubWFwKCh0ZXh0UGFydCkgPT4gdGV4dFBhcnQubWFwKChlbGVtZW50KSA9PiBodG1sRm9yTWFya2Rvd24oZWxlbWVudC50cmltKCkpKSk7XG4gICAgICAgIHJldHVybiB0aGlzLmFkZEluZGVudGF0aW9uVG9UZXh0UGFydHModGV4dFBhcnRzLCBmb3JtYXR0ZWRUZXh0UGFydHMpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEBmdW5jdGlvbiBhZGRJbmRlbnRhdGlvblRvVGV4dFBhcnRzXG4gICAgICogQGRlc2MgRm9ybWF0cyB0aGUgZmlyc3Qgd29yZCBvZiBlYWNoIGxpbmUgd2l0aCB0aGUgaW5kZW50YXRpb24gaXQgb3JpZ2luYWxseSBoYWQuXG4gICAgICogQHBhcmFtIG9yaWdpbmFsVGV4dFBhcnRzIHtzdHJpbmdbXVtdfSB0aGUgdGV4dCBwYXJ0cyB3aXRob3V0IGh0bWwgZm9ybWF0dGluZ1xuICAgICAqIEBwYXJhbSBmb3JtYXR0ZWRUZXh0UGFydHMge3N0cmluZ1tdW119IHRoZSB0ZXh0IHBhcnRzIHdpdGggaHRtbCBmb3JtYXR0aW5nXG4gICAgICovXG4gICAgYWRkSW5kZW50YXRpb25Ub1RleHRQYXJ0cyhvcmlnaW5hbFRleHRQYXJ0czogc3RyaW5nW11bXSwgZm9ybWF0dGVkVGV4dFBhcnRzOiBzdHJpbmdbXVtdKTogc3RyaW5nW11bXSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm9ybWF0dGVkVGV4dFBhcnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBlbGVtZW50ID0gZm9ybWF0dGVkVGV4dFBhcnRzW2ldWzBdO1xuICAgICAgICAgICAgbGV0IGZpcnN0V29yZCA9ICcnO1xuICAgICAgICAgICAgLy8gY2hlY2sgaWYgZmlyc3Qgd29yZCBpcyBhIHNwb3QgKGZpcnN0IGFycmF5IGVsZW1lbnQgd2lsbCBiZSBhbiBlbXB0eSBzdHJpbmcpXG4gICAgICAgICAgICBpZiAob3JpZ2luYWxUZXh0UGFydHNbaV0ubGVuZ3RoID4gMSkge1xuICAgICAgICAgICAgICAgIGZpcnN0V29yZCA9XG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdHRlZFRleHRQYXJ0c1tpXVswXSA9PT0gJycgJiYgb3JpZ2luYWxUZXh0UGFydHNbaV1bMV0uc3RhcnRzV2l0aCgnWy1zcG90JylcbiAgICAgICAgICAgICAgICAgICAgICAgID8gdGhpcy5nZXRGaXJzdFdvcmQob3JpZ2luYWxUZXh0UGFydHNbaV1bMV0pXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHRoaXMuZ2V0Rmlyc3RXb3JkKG9yaWdpbmFsVGV4dFBhcnRzW2ldWzBdKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZmlyc3RXb3JkID0gdGhpcy5nZXRGaXJzdFdvcmQob3JpZ2luYWxUZXh0UGFydHNbaV1bMF0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGZpcnN0V29yZCA9PT0gJycpIHtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGZpcnN0V29yZEluZGV4ID0gZWxlbWVudC5pbmRleE9mKGZpcnN0V29yZCk7XG4gICAgICAgICAgICBjb25zdCB3aGl0ZXNwYWNlID0gJyZuYnNwOycucmVwZWF0KHRoaXMuZ2V0SW5kZW50YXRpb24ob3JpZ2luYWxUZXh0UGFydHNbaV1bMF0pLmxlbmd0aCk7XG4gICAgICAgICAgICBmb3JtYXR0ZWRUZXh0UGFydHNbaV1bMF0gPSBbZWxlbWVudC5zdWJzdHJpbmcoMCwgZmlyc3RXb3JkSW5kZXgpLCB3aGl0ZXNwYWNlLCBlbGVtZW50LnN1YnN0cmluZyhmaXJzdFdvcmRJbmRleCkudHJpbSgpXS5qb2luKCcnKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZm9ybWF0dGVkVGV4dFBhcnRzO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEBmdW5jdGlvbiBnZXRJbmRlbnRhdGlvblxuICAgICAqIEBkZXNjIFJldHVybnMgdGhlIHdoaXRlc3BhY2UgaW4gZnJvbnQgb2YgdGhlIHRleHQuXG4gICAgICogQHBhcmFtIHRleHQge3N0cmluZ30gdGhlIHRleHQgZm9yIHdoaWNoIHdlIGdldCB0aGUgaW5kZW50YXRpb25cbiAgICAgKi9cbiAgICBwdWJsaWMgZ2V0SW5kZW50YXRpb24odGV4dDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICAgICAgaWYgKCF0ZXh0KSB7XG4gICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRleHQuc3RhcnRzV2l0aCgnYCcpKSB7XG4gICAgICAgICAgICB0ZXh0ID0gdGV4dC5zdWJzdHJpbmcoMSk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgbGV0IGluZGVudGF0aW9uID0gJyc7XG4gICAgICAgIHdoaWxlICh0ZXh0W2luZGV4XSA9PT0gJyAnKSB7XG4gICAgICAgICAgICBpbmRlbnRhdGlvbiA9IGluZGVudGF0aW9uLmNvbmNhdCgnICcpO1xuICAgICAgICAgICAgaW5kZXgrKztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaW5kZW50YXRpb247XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGdldEZpcnN0V29yZFxuICAgICAqIEBkZXNjIFJldHVybnMgdGhlIGZpcnN0IHdvcmQgaW4gYSB0ZXh0LlxuICAgICAqIEBwYXJhbSB0ZXh0IHtzdHJpbmd9IGZvciB3aGljaCB0aGUgZmlyc3Qgd29yZCBpcyByZXR1cm5lZFxuICAgICAqL1xuICAgIGdldEZpcnN0V29yZCh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgICAgICBpZiAoIXRleHQpIHtcbiAgICAgICAgICAgIHJldHVybiAnJztcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB3b3JkcyA9IHRleHRcbiAgICAgICAgICAgIC50cmltKClcbiAgICAgICAgICAgIC5zcGxpdCgnICcpXG4gICAgICAgICAgICAuZmlsdGVyKCh3b3JkKSA9PiB3b3JkICE9PSAnJyk7XG4gICAgICAgIGlmICh3b3Jkcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHJldHVybiAnJztcbiAgICAgICAgfSBlbHNlIGlmICh3b3Jkc1swXSA9PT0gJ2AnKSB7XG4gICAgICAgICAgICByZXR1cm4gd29yZHNbMV07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gd29yZHNbMF0uc3RhcnRzV2l0aCgnYCcpID8gd29yZHNbMF0uc3Vic3RyaW5nKDEpIDogd29yZHNbMF07XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgeyBCYXNlRW50aXR5IH0gZnJvbSAnYXBwL3NoYXJlZC9tb2RlbC9iYXNlLWVudGl0eSc7XG5pbXBvcnQgeyBTaG9ydEFuc3dlclN1Ym1pdHRlZEFuc3dlciB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L3Nob3J0LWFuc3dlci1zdWJtaXR0ZWQtYW5zd2VyLm1vZGVsJztcbmltcG9ydCB7IFNob3J0QW5zd2VyU3BvdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L3Nob3J0LWFuc3dlci1zcG90Lm1vZGVsJztcblxuZXhwb3J0IGNsYXNzIFNob3J0QW5zd2VyU3VibWl0dGVkVGV4dCBpbXBsZW1lbnRzIEJhc2VFbnRpdHkge1xuICAgIHB1YmxpYyBpZD86IG51bWJlcjtcbiAgICBwdWJsaWMgdGV4dD86IHN0cmluZztcbiAgICBwdWJsaWMgaXNDb3JyZWN0PzogYm9vbGVhbjtcbiAgICBwdWJsaWMgc3BvdD86IFNob3J0QW5zd2VyU3BvdDtcbiAgICBwdWJsaWMgc3VibWl0dGVkQW5zd2VyPzogU2hvcnRBbnN3ZXJTdWJtaXR0ZWRBbnN3ZXI7XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE91dHB1dCwgVmlld0VuY2Fwc3VsYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFydGVtaXNNYXJrZG93blNlcnZpY2UgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLnNlcnZpY2UnO1xuaW1wb3J0IHsgU2hvcnRBbnN3ZXJRdWVzdGlvblV0aWwgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3F1aXovc2hhcmVkL3Nob3J0LWFuc3dlci1xdWVzdGlvbi11dGlsLnNlcnZpY2UnO1xuaW1wb3J0IHsgU2hvcnRBbnN3ZXJTb2x1dGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L3Nob3J0LWFuc3dlci1zb2x1dGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBTaG9ydEFuc3dlclF1ZXN0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovc2hvcnQtYW5zd2VyLXF1ZXN0aW9uLm1vZGVsJztcbmltcG9ydCB7IFNob3J0QW5zd2VyU3VibWl0dGVkVGV4dCB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L3Nob3J0LWFuc3dlci1zdWJtaXR0ZWQtdGV4dC5tb2RlbCc7XG5pbXBvcnQgeyBRdWl6UXVlc3Rpb24sIFJlbmRlcmVkUXVpelF1ZXN0aW9uTWFya0Rvd25FbGVtZW50IH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovcXVpei1xdWVzdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBmYUV4Y2xhbWF0aW9uQ2lyY2xlIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IGZhUXVlc3Rpb25DaXJjbGUgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1yZWd1bGFyLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBNQVhfUVVJWl9TSE9SVF9BTlNXRVJfVEVYVF9MRU5HVEggfSBmcm9tICdhcHAvc2hhcmVkL2NvbnN0YW50cy9pbnB1dC5jb25zdGFudHMnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1zaG9ydC1hbnN3ZXItcXVlc3Rpb24nLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9zaG9ydC1hbnN3ZXItcXVlc3Rpb24uY29tcG9uZW50Lmh0bWwnLFxuICAgIHByb3ZpZGVyczogW1Nob3J0QW5zd2VyUXVlc3Rpb25VdGlsXSxcbiAgICBzdHlsZVVybHM6IFsnLi9zaG9ydC1hbnN3ZXItcXVlc3Rpb24uY29tcG9uZW50LnNjc3MnLCAnLi4vLi4vLi4vcGFydGljaXBhdGUvcXVpei1wYXJ0aWNpcGF0aW9uLnNjc3MnXSxcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxufSlcbmV4cG9ydCBjbGFzcyBTaG9ydEFuc3dlclF1ZXN0aW9uQ29tcG9uZW50IHtcbiAgICBzaG9ydEFuc3dlclF1ZXN0aW9uOiBTaG9ydEFuc3dlclF1ZXN0aW9uO1xuICAgIF9mb3JjZVNhbXBsZVNvbHV0aW9uOiBib29sZWFuO1xuXG4gICAgQElucHV0KClcbiAgICBzZXQgcXVlc3Rpb24ocXVlc3Rpb246IFF1aXpRdWVzdGlvbikge1xuICAgICAgICB0aGlzLnNob3J0QW5zd2VyUXVlc3Rpb24gPSBxdWVzdGlvbiBhcyBTaG9ydEFuc3dlclF1ZXN0aW9uO1xuICAgICAgICB0aGlzLndhdGNoQ29sbGVjdGlvbigpO1xuICAgIH1cblxuICAgIC8vIFRPRE86IE1hcCB2cy4gQXJyYXkgLS0+IGNvbnNpc3RlbmN5XG4gICAgQElucHV0KClcbiAgICBzdWJtaXR0ZWRUZXh0czogU2hvcnRBbnN3ZXJTdWJtaXR0ZWRUZXh0W107XG4gICAgQElucHV0KClcbiAgICBjbGlja0Rpc2FibGVkOiBib29sZWFuO1xuICAgIEBJbnB1dCgpXG4gICAgc2hvd1Jlc3VsdDogYm9vbGVhbjtcbiAgICBASW5wdXQoKVxuICAgIHF1ZXN0aW9uSW5kZXg6IG51bWJlcjtcbiAgICBASW5wdXQoKVxuICAgIHNjb3JlOiBudW1iZXI7XG4gICAgQElucHV0KClcbiAgICBzZXQgZm9yY2VTYW1wbGVTb2x1dGlvbihmb3JjZVNhbXBsZVNvbHV0aW9uKSB7XG4gICAgICAgIHRoaXMuX2ZvcmNlU2FtcGxlU29sdXRpb24gPSBmb3JjZVNhbXBsZVNvbHV0aW9uO1xuICAgICAgICBpZiAodGhpcy5mb3JjZVNhbXBsZVNvbHV0aW9uKSB7XG4gICAgICAgICAgICB0aGlzLnNob3dTYW1wbGVTb2x1dGlvbigpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZ2V0IGZvcmNlU2FtcGxlU29sdXRpb24oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9mb3JjZVNhbXBsZVNvbHV0aW9uO1xuICAgIH1cbiAgICBASW5wdXQoKVxuICAgIGZuT25TdWJtaXR0ZWRUZXh0VXBkYXRlOiBhbnk7XG5cbiAgICBAT3V0cHV0KClcbiAgICBzdWJtaXR0ZWRUZXh0c0NoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8U2hvcnRBbnN3ZXJTdWJtaXR0ZWRUZXh0W10+KCk7XG5cbiAgICByZWFkb25seSBtYXhDaGFyYWN0ZXJDb3VudCA9IE1BWF9RVUlaX1NIT1JUX0FOU1dFUl9URVhUX0xFTkdUSDtcblxuICAgIHNob3dpbmdTYW1wbGVTb2x1dGlvbiA9IGZhbHNlO1xuICAgIHJlbmRlcmVkUXVlc3Rpb246IFJlbmRlcmVkUXVpelF1ZXN0aW9uTWFya0Rvd25FbGVtZW50O1xuICAgIHNhbXBsZVNvbHV0aW9uczogU2hvcnRBbnN3ZXJTb2x1dGlvbltdID0gW107XG4gICAgdGV4dFBhcnRzOiBzdHJpbmdbXVtdO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUV4Y2xhbWF0aW9uQ2lyY2xlID0gZmFFeGNsYW1hdGlvbkNpcmNsZTtcbiAgICBmYXJRdWVzdGlvbkNpcmNsZSA9IGZhUXVlc3Rpb25DaXJjbGU7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBhcnRlbWlzTWFya2Rvd246IEFydGVtaXNNYXJrZG93blNlcnZpY2UsXG4gICAgICAgIHB1YmxpYyBzaG9ydEFuc3dlclF1ZXN0aW9uVXRpbDogU2hvcnRBbnN3ZXJRdWVzdGlvblV0aWwsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlIGh0bWwgZm9yIHRleHQsIGhpbnQgYW5kIGV4cGxhbmF0aW9uIGZvciB0aGUgcXVlc3Rpb24gYW5kIGV2ZXJ5IGFuc3dlciBvcHRpb25cbiAgICAgKi9cbiAgICB3YXRjaENvbGxlY3Rpb24oKSB7XG4gICAgICAgIHRoaXMucmVuZGVyZWRRdWVzdGlvbiA9IG5ldyBSZW5kZXJlZFF1aXpRdWVzdGlvbk1hcmtEb3duRWxlbWVudCgpO1xuXG4gICAgICAgIGNvbnN0IHRleHRQYXJ0cyA9IHRoaXMuc2hvcnRBbnN3ZXJRdWVzdGlvblV0aWwuZGl2aWRlUXVlc3Rpb25UZXh0SW50b1RleHRQYXJ0cyh0aGlzLnNob3J0QW5zd2VyUXVlc3Rpb24udGV4dCEpO1xuICAgICAgICB0aGlzLnRleHRQYXJ0cyA9IHRoaXMuc2hvcnRBbnN3ZXJRdWVzdGlvblV0aWwudHJhbnNmb3JtVGV4dFBhcnRzSW50b0hUTUwodGV4dFBhcnRzKTtcblxuICAgICAgICB0aGlzLnJlbmRlcmVkUXVlc3Rpb24udGV4dCA9IHRoaXMuYXJ0ZW1pc01hcmtkb3duLnNhZmVIdG1sRm9yTWFya2Rvd24odGhpcy5zaG9ydEFuc3dlclF1ZXN0aW9uLnRleHQpO1xuICAgICAgICB0aGlzLnJlbmRlcmVkUXVlc3Rpb24uaGludCA9IHRoaXMuYXJ0ZW1pc01hcmtkb3duLnNhZmVIdG1sRm9yTWFya2Rvd24odGhpcy5zaG9ydEFuc3dlclF1ZXN0aW9uLmhpbnQpO1xuICAgICAgICB0aGlzLnJlbmRlcmVkUXVlc3Rpb24uZXhwbGFuYXRpb24gPSB0aGlzLmFydGVtaXNNYXJrZG93bi5zYWZlSHRtbEZvck1hcmtkb3duKHRoaXMuc2hvcnRBbnN3ZXJRdWVzdGlvbi5leHBsYW5hdGlvbik7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogV2hlbiBzdHVkZW50cyB0eXBlIGluIHRoZWlyIGFuc3dlcnMgYW5kIHRoZSBmb2N1cyBnZXRzIGF3YXkgZnJvbSB0aGUgaW5wdXQgc3BvdCwgdGhlIGFuc3dlcnMgYXJlXG4gICAgICogc2V0IGFzIHN1Ym1pdHRlZCB0ZXh0c1xuICAgICAqL1xuICAgIHNldFN1Ym1pdHRlZFRleHQoKSB7XG4gICAgICAgIHRoaXMuc3VibWl0dGVkVGV4dHMgPSBbXTtcbiAgICAgICAgbGV0IGkgPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHRleHRwYXJ0IG9mIHRoaXMudGV4dFBhcnRzKSB7XG4gICAgICAgICAgICBsZXQgaiA9IDA7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGVsZW1lbnQgb2YgdGV4dHBhcnQpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5zaG9ydEFuc3dlclF1ZXN0aW9uVXRpbC5pc0lucHV0RmllbGQoZWxlbWVudCEpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHN1Ym1pdHRlZFRleHQgPSBuZXcgU2hvcnRBbnN3ZXJTdWJtaXR0ZWRUZXh0KCk7XG4gICAgICAgICAgICAgICAgICAgIHN1Ym1pdHRlZFRleHQudGV4dCA9ICg8SFRNTElucHV0RWxlbWVudD5kb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc29sdXRpb24tJyArIGkgKyAnLScgKyBqICsgJy0nICsgdGhpcy5zaG9ydEFuc3dlclF1ZXN0aW9uLmlkKSkudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIHN1Ym1pdHRlZFRleHQuc3BvdCA9IHRoaXMuc2hvcnRBbnN3ZXJRdWVzdGlvblV0aWwuZ2V0U3BvdCh0aGlzLnNob3J0QW5zd2VyUXVlc3Rpb25VdGlsLmdldFNwb3ROcihlbGVtZW50ISksIHRoaXMuc2hvcnRBbnN3ZXJRdWVzdGlvbik7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3VibWl0dGVkVGV4dHMucHVzaChzdWJtaXR0ZWRUZXh0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaisrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaSsrO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc3VibWl0dGVkVGV4dHNDaGFuZ2UuZW1pdCh0aGlzLnN1Ym1pdHRlZFRleHRzKTtcbiAgICAgICAgLyoqIE9ubHkgZXhlY3V0ZSB0aGUgb25NYXBwaW5nVXBkYXRlIGZ1bmN0aW9uIGlmIHdlIHJlY2VpdmVkIHN1Y2ggaW5wdXQgKiovXG4gICAgICAgIGlmICh0aGlzLmZuT25TdWJtaXR0ZWRUZXh0VXBkYXRlKSB7XG4gICAgICAgICAgICB0aGlzLmZuT25TdWJtaXR0ZWRUZXh0VXBkYXRlKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEaXNwbGF5IGEgc2FtcGxlIHNvbHV0aW9uIGluc3RlYWQgb2YgdGhlIHN0dWRlbnQncyBhbnN3ZXJcbiAgICAgKi9cbiAgICBzaG93U2FtcGxlU29sdXRpb24oKSB7XG4gICAgICAgIC8vIFRPRE86IHRoZSBxdWVzdGlvbiBpcyBub3QgeWV0IGF2YWlsYWJsZVxuICAgICAgICB0aGlzLnNhbXBsZVNvbHV0aW9ucyA9IHRoaXMuc2hvcnRBbnN3ZXJRdWVzdGlvblV0aWwuZ2V0U2FtcGxlU29sdXRpb25zKHRoaXMuc2hvcnRBbnN3ZXJRdWVzdGlvbik7XG4gICAgICAgIHRoaXMuc2hvd2luZ1NhbXBsZVNvbHV0aW9uID0gdHJ1ZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEaXNwbGF5IHRoZSBzdHVkZW50J3MgYW5zd2VyIGFnYWluXG4gICAgICovXG4gICAgaGlkZVNhbXBsZVNvbHV0aW9uKCkge1xuICAgICAgICB0aGlzLnNob3dpbmdTYW1wbGVTb2x1dGlvbiA9IGZhbHNlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIHN1Ym1pdHRlZCB0ZXh0IGZvciBhIHNob3J0IGFuc3dlciBmb3IgdGhlIGdpdmVuIHNwb3QgdGFnXG4gICAgICogQHBhcmFtIHNwb3RUYWcgU3BvdCB0YWcgZm9yIHdoaWNoIHRvIGdldCB0aGUgc3VibWl0dGVkIHRleHRcbiAgICAgKi9cbiAgICBnZXRTdWJtaXR0ZWRUZXh0Rm9yU3BvdChzcG90VGFnOiBzdHJpbmcpOiBTaG9ydEFuc3dlclN1Ym1pdHRlZFRleHQge1xuICAgICAgICByZXR1cm4gdGhpcy5zdWJtaXR0ZWRUZXh0cy5maWx0ZXIoKHN1Ym1pdHRlZFRleHQpID0+IHN1Ym1pdHRlZFRleHQuc3BvdCEuc3BvdE5yID09PSB0aGlzLnNob3J0QW5zd2VyUXVlc3Rpb25VdGlsLmdldFNwb3ROcihzcG90VGFnKSlbMF07XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgc3VibWl0dGVkIHRleHQgYXMgc3RyaW5nIGZvciBhIHNob3J0IGFuc3dlciBmb3IgdGhlIGdpdmVuIHNwb3QgdGFnXG4gICAgICogQHBhcmFtIHNwb3RUYWcgU3BvdCB0YWcgZm9yIHdoaWNoIHRvIGdldCB0aGUgc3VibWl0dGVkIHRleHRcbiAgICAgKi9cbiAgICBnZXRTdWJtaXR0ZWRUZXh0Rm9yU3BvdEFzU3RyaW5nKHNwb3RUYWc6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgICAgIGNvbnN0IHN1Ym1pdHRlZFRleHQgPSB0aGlzLmdldFN1Ym1pdHRlZFRleHRGb3JTcG90KHNwb3RUYWcpO1xuICAgICAgICByZXR1cm4gc3VibWl0dGVkVGV4dD8udGV4dCA/PyAnJztcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBzaXplIGZvciBhIHN1Ym1pdHRlZCB0ZXh0IGZvciBhIHNob3J0IGFuc3dlciBmb3IgdGhlIGdpdmVuIHNwb3QgdGFnXG4gICAgICogQHBhcmFtIHNwb3RUYWcgU3BvdCB0YWcgZm9yIHdoaWNoIHRvIGdldCB0aGUgc3VibWl0dGVkIHRleHRcbiAgICAgKi9cbiAgICBnZXRTdWJtaXR0ZWRUZXh0U2l6ZUZvclNwb3Qoc3BvdFRhZzogc3RyaW5nKTogbnVtYmVyIHtcbiAgICAgICAgY29uc3Qgc3VibWl0dGVkVGV4dCA9IHRoaXMuZ2V0U3VibWl0dGVkVGV4dEZvclNwb3RBc1N0cmluZyhzcG90VGFnKTtcbiAgICAgICAgcmV0dXJuIHN1Ym1pdHRlZFRleHQgIT09ICcnID8gc3VibWl0dGVkVGV4dC5sZW5ndGggKyAyIDogNTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBzYW1wbGUgc29sdXRpb24gZm9yIGEgc2hvcnQgYW5zd2VyIGZvciB0aGUgZ2l2ZW4gc3BvdCB0YWdcbiAgICAgKiBAcGFyYW0gc3BvdFRhZyBTcG90IHRhZyBmb3Igd2hpY2ggdG8gZ2V0IHRoZSBzYW1wbGUgc29sdXRpb25cbiAgICAgKi9cbiAgICBnZXRTYW1wbGVTb2x1dGlvbkZvclNwb3Qoc3BvdFRhZzogc3RyaW5nKTogU2hvcnRBbnN3ZXJTb2x1dGlvbiB7XG4gICAgICAgIGNvbnN0IGluZGV4ID0gdGhpcy5zaG9ydEFuc3dlclF1ZXN0aW9uLnNwb3RzIS5maW5kSW5kZXgoKHNwb3QpID0+IHNwb3Quc3BvdE5yID09PSB0aGlzLnNob3J0QW5zd2VyUXVlc3Rpb25VdGlsLmdldFNwb3ROcihzcG90VGFnKSk7XG4gICAgICAgIHJldHVybiB0aGlzLnNhbXBsZVNvbHV0aW9uc1tpbmRleF07XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgc2FtcGxlIHNvbHV0aW9uIGFzIHRleHQgZm9yIGEgc2hvcnQgYW5zd2VyIGZvciB0aGUgZ2l2ZW4gc3BvdCB0YWdcbiAgICAgKiBAcGFyYW0gc3BvdFRhZyBTcG90IHRhZyBmb3Igd2hpY2ggdG8gZ2V0IHRoZSBzYW1wbGUgc29sdXRpb25cbiAgICAgKi9cbiAgICBnZXRTYW1wbGVTb2x1dGlvbkZvclNwb3RBc1N0cmluZyhzcG90VGFnOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgICAgICBjb25zdCBzYW1wbGVTb2x1dGlvbiA9IHRoaXMuZ2V0U2FtcGxlU29sdXRpb25Gb3JTcG90KHNwb3RUYWcpO1xuICAgICAgICByZXR1cm4gc2FtcGxlU29sdXRpb24/LnRleHQgPz8gJyc7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgc2l6ZSBmb3IgYSBzYW1wbGUgc29sdXRpb24gZm9yIGEgc2hvcnQgYW5zd2VyIGZvciB0aGUgZ2l2ZW4gc3BvdCB0YWdcbiAgICAgKiBAcGFyYW0gc3BvdFRhZyBTcG90IHRhZyBmb3Igd2hpY2ggdG8gZ2V0IHRoZSBzdWJtaXR0ZWQgdGV4dFxuICAgICAqL1xuICAgIGdldFNhbXBsZVNvbHV0aW9uU2l6ZUZvclNwb3Qoc3BvdFRhZzogc3RyaW5nKTogbnVtYmVyIHtcbiAgICAgICAgY29uc3Qgc2FtcGxlU29sdXRpb24gPSB0aGlzLmdldFNhbXBsZVNvbHV0aW9uRm9yU3BvdEFzU3RyaW5nKHNwb3RUYWcpO1xuICAgICAgICByZXR1cm4gc2FtcGxlU29sdXRpb24gIT09ICcnID8gc2FtcGxlU29sdXRpb24ubGVuZ3RoICsgMiA6IDU7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgdGV4dCB0aGF0IHNob3VsZCBiZSBzaG93biBmb3IgdGhlIGdpdmVuIHNwb3QgdGFnXG4gICAgICogQHBhcmFtIHNwb3RUYWcgU3BvdCB0YWcgZm9yIHdoaWNoIHRvIGdldCB0aGUgdGV4dFxuICAgICAqL1xuICAgIGdldFRleHRGb3JTcG90QXNTdHJpbmcoc3BvdFRhZzogc3RyaW5nKTogc3RyaW5nIHtcbiAgICAgICAgaWYgKHRoaXMuc2hvd2luZ1NhbXBsZVNvbHV0aW9uKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5nZXRTYW1wbGVTb2x1dGlvbkZvclNwb3RBc1N0cmluZyhzcG90VGFnKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5nZXRTdWJtaXR0ZWRUZXh0Rm9yU3BvdEFzU3RyaW5nKHNwb3RUYWcpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIHNpemUgb2YgdGhlIGlucHV0IGZvciB0aGUgZ2l2ZW4gc3BvdCB0YWdcbiAgICAgKiBAcGFyYW0gc3BvdFRhZyBTcG90IHRhZyBmb3Igd2hpY2ggdG8gZ2V0IHRoZSBzaXplXG4gICAgICovXG4gICAgZ2V0U2l6ZUZvclNwb3Qoc3BvdFRhZzogc3RyaW5nKTogbnVtYmVyIHtcbiAgICAgICAgaWYgKHRoaXMuc2hvd2luZ1NhbXBsZVNvbHV0aW9uKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5nZXRTYW1wbGVTb2x1dGlvblNpemVGb3JTcG90KHNwb3RUYWcpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLmdldFN1Ym1pdHRlZFRleHRTaXplRm9yU3BvdChzcG90VGFnKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBjbGFzcyBmb3IgdGhlIGlucHV0IGZpZWxkIG9mIHRoZSBnaXZlbiBzcG90IHRhZ1xuICAgICAqIEBwYXJhbSBzcG90VGFnIFNwb3QgdGFnIGZvciB3aGljaCB0byByZXR1cm4gdGhlIGlucHV0IGZpZWxkJ3MgY2xhc3NcbiAgICAgKi9cbiAgICBjbGFzc2lmeUlucHV0RmllbGQoc3BvdFRhZzogc3RyaW5nKTogc3RyaW5nIHtcbiAgICAgICAgaWYgKHRoaXMuc2hvcnRBbnN3ZXJRdWVzdGlvbi5pbnZhbGlkKSB7XG4gICAgICAgICAgICByZXR1cm4gJ2ludmFsaWQnO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHNwb3QgPSB0aGlzLnNob3J0QW5zd2VyUXVlc3Rpb25VdGlsLmdldFNwb3QodGhpcy5zaG9ydEFuc3dlclF1ZXN0aW9uVXRpbC5nZXRTcG90TnIoc3BvdFRhZyksIHRoaXMuc2hvcnRBbnN3ZXJRdWVzdGlvbik7XG4gICAgICAgIGlmIChzcG90LmludmFsaWQpIHtcbiAgICAgICAgICAgIHJldHVybiAnaW52YWxpZCc7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuc2hvd2luZ1NhbXBsZVNvbHV0aW9uKSB7XG4gICAgICAgICAgICByZXR1cm4gJ2NvbXBsZXRlbHktY29ycmVjdCc7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3VibWl0dGVkVGV4dEZvclNwb3QgPSB0aGlzLmdldFN1Ym1pdHRlZFRleHRGb3JTcG90KHNwb3RUYWcpO1xuICAgICAgICBpZiAoc3VibWl0dGVkVGV4dEZvclNwb3Q/LmlzQ29ycmVjdCAhPT0gdHJ1ZSkge1xuICAgICAgICAgICAgcmV0dXJuICd3cm9uZyc7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuaXNTdWJtaXR0ZWRUZXh0Q29tcGxldGVseUNvcnJlY3Qoc3BvdFRhZykpIHtcbiAgICAgICAgICAgIHJldHVybiAnY29tcGxldGVseS1jb3JyZWN0JztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gJ2NvcnJlY3QnO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgd2hldGhlciB0aGUgc3VibWl0dGVkIHRleHQgZm9yIHRoZSBhbnN3ZXIgcmVnYXJkaW5nIHRoZSBnaXZlbiBzcG90IHRhZyBpcyBjb21wbGV0ZWx5IGNvcnJlY3RcbiAgICAgKiBAcGFyYW0gc3BvdFRhZyBTcG90IHRhZyBmb3Igd2hpY2ggdG8gZXZhbHVhdGVcbiAgICAgKi9cbiAgICBpc1N1Ym1pdHRlZFRleHRDb21wbGV0ZWx5Q29ycmVjdChzcG90VGFnOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgICAgbGV0IGlzVGV4dENvcnJlY3QgPSBmYWxzZTtcbiAgICAgICAgY29uc3Qgc29sdXRpb25zRm9yU3BvdCA9IHRoaXMuc2hvcnRBbnN3ZXJRdWVzdGlvblV0aWwuZ2V0QWxsU29sdXRpb25zRm9yU3BvdChcbiAgICAgICAgICAgIHRoaXMuc2hvcnRBbnN3ZXJRdWVzdGlvbi5jb3JyZWN0TWFwcGluZ3MsXG4gICAgICAgICAgICB0aGlzLnNob3J0QW5zd2VyUXVlc3Rpb25VdGlsLmdldFNwb3QodGhpcy5zaG9ydEFuc3dlclF1ZXN0aW9uVXRpbC5nZXRTcG90TnIoc3BvdFRhZyksIHRoaXMuc2hvcnRBbnN3ZXJRdWVzdGlvbiksXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IHNvbHV0aW9ucyA9IHNvbHV0aW9uc0ZvclNwb3Q/LmZpbHRlcigoc29sdXRpb24pID0+IHNvbHV0aW9uLnRleHQ/LnRyaW0oKSA9PT0gdGhpcy5nZXRTdWJtaXR0ZWRUZXh0Rm9yU3BvdChzcG90VGFnKT8udGV4dD8udHJpbSgpKTtcbiAgICAgICAgaWYgKHNvbHV0aW9ucyAmJiBzb2x1dGlvbnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgaXNUZXh0Q29ycmVjdCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGlzVGV4dENvcnJlY3Q7XG4gICAgfVxufVxuIiwiPGRpdlxuICAgIGNsYXNzPVwic2EtcXVlc3Rpb25cIlxuICAgIFtuZ0NsYXNzXT1cIntcbiAgICAgICAgZGlzYWJsZWQ6IGNsaWNrRGlzYWJsZWQgJiYgIXNob3dSZXN1bHQsXG4gICAgICAgIHJlc3VsdDogc2hvd1Jlc3VsdCAmJiAhZm9yY2VTYW1wbGVTb2x1dGlvbixcbiAgICAgICAgaW5jb3JyZWN0OiAoc2NvcmUgfHwgMCkgPCBzaG9ydEFuc3dlclF1ZXN0aW9uLnBvaW50cyEgJiYgIWZvcmNlU2FtcGxlU29sdXRpb25cbiAgICB9XCJcbj5cbiAgICA8aDQgY2xhc3M9XCJxdWVzdGlvbi10aXRsZS1kaXNwbGF5XCI+XG4gICAgICAgIDxzcGFuPnt7IHF1ZXN0aW9uSW5kZXggfX0pPC9zcGFuPiB7eyBzaG9ydEFuc3dlclF1ZXN0aW9uLnRpdGxlIH19XG4gICAgPC9oND5cbiAgICBAaWYgKCFzaG93UmVzdWx0KSB7XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICBAZm9yICh0ZXh0UGFydCBvZiB0ZXh0UGFydHM7IHRyYWNrIHRleHRQYXJ0OyBsZXQgaSA9ICRpbmRleCkge1xuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzaG9ydC1hbnN3ZXItcXVlc3Rpb24tZGlzcGxheVwiPlxuICAgICAgICAgICAgICAgICAgICBAZm9yIChlbGVtZW50IG9mIHRleHRQYXJ0OyB0cmFjayBlbGVtZW50OyBsZXQgaiA9ICRpbmRleCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNob3J0LWFuc3dlci1xdWVzdGlvbi1kaXNwbGF5X19lbGVtZW50XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghc2hvcnRBbnN3ZXJRdWVzdGlvblV0aWwuaXNJbnB1dEZpZWxkKGVsZW1lbnQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgW2lubmVySFRNTF09XCJlbGVtZW50XCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc2hvcnRBbnN3ZXJRdWVzdGlvblV0aWwuaXNJbnB1dEZpZWxkKGVsZW1lbnQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzaG9ydC1hbnN3ZXItcXVlc3Rpb24tY29udGFpbmVyXCIgaWQ9XCJzYS1xdWVzdGlvbi1jb250YWluZXItQVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJzaG9ydC1hbnN3ZXItcXVlc3Rpb24tY29udGFpbmVyX19pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFttYXhMZW5ndGhdPVwibWF4Q2hhcmFjdGVyQ291bnRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtkaXNhYmxlZF09XCJjbGlja0Rpc2FibGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT1cInt7IGdldFN1Ym1pdHRlZFRleHRGb3JTcG90QXNTdHJpbmcoZWxlbWVudCkgfX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwic29sdXRpb24te3sgaSB9fS17eyBqIH19LXt7IHNob3J0QW5zd2VyUXVlc3Rpb24uaWQgfX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChjaGFuZ2UpPVwic2V0U3VibWl0dGVkVGV4dCgpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAmbmJzcDtcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmIChzaG93UmVzdWx0KSB7XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICBAZm9yICh0ZXh0UGFydCBvZiB0ZXh0UGFydHM7IHRyYWNrIHRleHRQYXJ0KSB7XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNob3J0LWFuc3dlci1xdWVzdGlvbi1kaXNwbGF5XCI+XG4gICAgICAgICAgICAgICAgICAgIEBmb3IgKGVsZW1lbnQgb2YgdGV4dFBhcnQ7IHRyYWNrIGVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzaG9ydC1hbnN3ZXItcXVlc3Rpb24tZGlzcGxheV9fZWxlbWVudFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIXNob3J0QW5zd2VyUXVlc3Rpb25VdGlsLmlzSW5wdXRGaWVsZChlbGVtZW50KSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IFtpbm5lckhUTUxdPVwiZWxlbWVudFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHNob3J0QW5zd2VyUXVlc3Rpb25VdGlsLmlzSW5wdXRGaWVsZChlbGVtZW50KSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInNob3J0LWFuc3dlci1xdWVzdGlvbi1jb250YWluZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nYlRvb2x0aXBdPVwiY2xhc3NpZnlJbnB1dEZpZWxkKGVsZW1lbnQpID09PSAnaW52YWxpZCcgPyAoJ2FydGVtaXNBcHAuc2hvcnRBbnN3ZXJTcG90LmludmFsaWRTcG90JyB8IGFydGVtaXNUcmFuc2xhdGUpIDogdW5kZWZpbmVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJzaG9ydC1hbnN3ZXItcXVlc3Rpb24tY29udGFpbmVyX19pbnB1dCB7eyBjbGFzc2lmeUlucHV0RmllbGQoZWxlbWVudCkgfX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFttYXhMZW5ndGhdPVwibWF4Q2hhcmFjdGVyQ291bnRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPVwie3sgZ2V0VGV4dEZvclNwb3RBc1N0cmluZyhlbGVtZW50KSB9fVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInt7IGdldFNpemVGb3JTcG90KGVsZW1lbnQpIH19XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmIChzaG9ydEFuc3dlclF1ZXN0aW9uLmludmFsaWQpIHtcbiAgICAgICAgPHNwYW4gc3R5bGU9XCJjb2xvcjogcmVkXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6UXVlc3Rpb24uaW52YWxpZFRleHRcIj48L3NwYW4+XG4gICAgfVxuICAgIEBpZiAoc2hvcnRBbnN3ZXJRdWVzdGlvbi5oaW50IHx8IChzaG9ydEFuc3dlclF1ZXN0aW9uLmV4cGxhbmF0aW9uICYmIHNob3dSZXN1bHQpKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJoaW50XCI+XG4gICAgICAgICAgICA8bmctdGVtcGxhdGUgI3JlbmRlcmVkSGludD5cbiAgICAgICAgICAgICAgICA8ZGl2IFtpbm5lckhUTUxdPVwicmVuZGVyZWRRdWVzdGlvbi5oaW50XCI+PC9kaXY+XG4gICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgQGlmIChzaG9ydEFuc3dlclF1ZXN0aW9uLmhpbnQpIHtcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImxhYmVsIGxhYmVsLWluZm9cIiBbbmdiUG9wb3Zlcl09XCJyZW5kZXJlZEhpbnRcIiBwbGFjZW1lbnQ9XCJyaWdodCBhdXRvXCIgdHJpZ2dlcnM9XCJtb3VzZWVudGVyOm1vdXNlbGVhdmVcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFyUXVlc3Rpb25DaXJjbGVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpelF1ZXN0aW9uLmhpbnRcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICA8bmctdGVtcGxhdGUgI3JlbmRlcmVkRXhwbGFuYXRpb24+XG4gICAgICAgICAgICAgICAgPGRpdiBbaW5uZXJIVE1MXT1cInJlbmRlcmVkUXVlc3Rpb24uZXhwbGFuYXRpb25cIj48L2Rpdj5cbiAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICBAaWYgKHNob3J0QW5zd2VyUXVlc3Rpb24uZXhwbGFuYXRpb24gJiYgc2hvd1Jlc3VsdCkge1xuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibGFiZWwgbGFiZWwtcHJpbWFyeVwiIFtuZ2JQb3BvdmVyXT1cInJlbmRlcmVkRXhwbGFuYXRpb25cIiBwbGFjZW1lbnQ9XCJyaWdodCBhdXRvXCIgdHJpZ2dlcnM9XCJtb3VzZWVudGVyOm1vdXNlbGVhdmVcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFFeGNsYW1hdGlvbkNpcmNsZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6UXVlc3Rpb24uZXhwbGFuYXRpb25cIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmICghc2hvd1Jlc3VsdCB8fCBmb3JjZVNhbXBsZVNvbHV0aW9uKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJxdWVzdGlvbi1zY29yZVwiPlxuICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6UXVlc3Rpb24uc2NvcmVcIiBjbGFzcz1cImNvbG9uLXN1ZmZpeFwiPjwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPnt7IHNob3J0QW5zd2VyUXVlc3Rpb24ucG9pbnRzIH19PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmIChzaG93UmVzdWx0ICYmICFmb3JjZVNhbXBsZVNvbHV0aW9uKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJxdWVzdGlvbi1zY29yZSByZXN1bHRcIiBbbmdDbGFzc109XCJ7IGluY29ycmVjdDogKHNjb3JlIHx8IDApIDwgc2hvcnRBbnN3ZXJRdWVzdGlvbi5wb2ludHMhIH1cIj5cbiAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpelF1ZXN0aW9uLnlvdXJTY29yZVwiIGNsYXNzPVwiY29sb24tc3VmZml4XCI+PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJzaG93LWV4cGxhbmF0aW9uXCI+e3sgc2NvcmUgfHwgMCB9fS97eyBzaG9ydEFuc3dlclF1ZXN0aW9uLnBvaW50cyB9fTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwic2hvdy1leHBsYW5hdGlvblwiPlxuICAgICAgICAgICAgICAgIDxqaGktcXVpei1zY29yaW5nLWluZm9zdHVkZW50LW1vZGFsXG4gICAgICAgICAgICAgICAgICAgIFtzY29yZV09XCJzY29yZVwiXG4gICAgICAgICAgICAgICAgICAgIFtxdWVzdGlvbl09XCJzaG9ydEFuc3dlclF1ZXN0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgW3Nob3J0QW5zd2VyVGV4dF09XCJzdWJtaXR0ZWRUZXh0c1wiXG4gICAgICAgICAgICAgICAgICAgIFtxdWVzdGlvbkluZGV4XT1cInF1ZXN0aW9uSW5kZXhcIlxuICAgICAgICAgICAgICAgID48L2poaS1xdWl6LXNjb3JpbmctaW5mb3N0dWRlbnQtbW9kYWw+XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICA8YnIgLz5cbiAgICA8YnIgLz5cbiAgICBAaWYgKHNob3dSZXN1bHQgJiYgIWZvcmNlU2FtcGxlU29sdXRpb24pIHtcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIEBpZiAoIXNob3dpbmdTYW1wbGVTb2x1dGlvbikge1xuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJidG4gYnRuLW91dGxpbmUtcHJpbWFyeVwiIChjbGljayk9XCJzaG93U2FtcGxlU29sdXRpb24oKVwiPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5xdWl6UXVlc3Rpb24uc2hvd1NhbXBsZVNvbHV0aW9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAoc2hvd2luZ1NhbXBsZVNvbHV0aW9uKSB7XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1wcmltYXJ5XCIgKGNsaWNrKT1cImhpZGVTYW1wbGVTb2x1dGlvbigpXCI+XG4gICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLnF1aXpRdWVzdGlvbi5oaWRlU2FtcGxlU29sdXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICB9XG48L2Rpdj5cbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBGaXRUZXh0RGlyZWN0aXZlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9xdWl6L3NoYXJlZC9maXQtdGV4dC9maXQtdGV4dC5kaXJlY3RpdmUnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGRlY2xhcmF0aW9uczogW0ZpdFRleHREaXJlY3RpdmVdLFxuICAgIGV4cG9ydHM6IFtGaXRUZXh0RGlyZWN0aXZlXSxcbn0pXG5leHBvcnQgY2xhc3MgRml0VGV4dE1vZHVsZSB7fVxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgRHJhZ0FuZERyb3BRdWVzdGlvbkNvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL2RyYWctYW5kLWRyb3AtcXVlc3Rpb24vZHJhZy1hbmQtZHJvcC1xdWVzdGlvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgTXVsdGlwbGVDaG9pY2VRdWVzdGlvbkNvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL211bHRpcGxlLWNob2ljZS1xdWVzdGlvbi9tdWx0aXBsZS1jaG9pY2UtcXVlc3Rpb24uY29tcG9uZW50JztcbmltcG9ydCB7IFNob3J0QW5zd2VyUXVlc3Rpb25Db21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3F1aXovc2hhcmVkL3F1ZXN0aW9ucy9zaG9ydC1hbnN3ZXItcXVlc3Rpb24vc2hvcnQtYW5zd2VyLXF1ZXN0aW9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBEcmFnSXRlbUNvbXBvbmVudCB9IGZyb20gJy4vZHJhZy1hbmQtZHJvcC1xdWVzdGlvbi9kcmFnLWl0ZW0uY29tcG9uZW50JztcbmltcG9ydCB7IERyYWdEcm9wTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL2RyYWctZHJvcCc7XG5pbXBvcnQgeyBRdWl6U2NvcmluZ0luZm9TdHVkZW50TW9kYWxDb21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3F1aXovc2hhcmVkL3F1ZXN0aW9ucy9xdWl6LXNjb3JpbmctaW5mb3N0dWRlbnQtbW9kYWwvcXVpei1zY29yaW5nLWluZm8tc3R1ZGVudC1tb2RhbC5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc01hcmtkb3duTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi5tb2R1bGUnO1xuaW1wb3J0IHsgRml0VGV4dE1vZHVsZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvZml0LXRleHQvZml0LXRleHQubW9kdWxlJztcbmltcG9ydCB7IE11bHRpcGxlQ2hvaWNlVmlzdWFsUXVlc3Rpb25Db21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3F1aXovc2hhcmVkL3F1ZXN0aW9ucy9tdWx0aXBsZS1jaG9pY2UtcXVlc3Rpb24vbXVsdGlwbGUtY2hvaWNlLXZpc3VhbC1xdWVzdGlvbi5jb21wb25lbnQnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlLCBEcmFnRHJvcE1vZHVsZSwgQXJ0ZW1pc01hcmtkb3duTW9kdWxlLCBGaXRUZXh0TW9kdWxlXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtcbiAgICAgICAgRHJhZ0l0ZW1Db21wb25lbnQsXG4gICAgICAgIERyYWdBbmREcm9wUXVlc3Rpb25Db21wb25lbnQsXG4gICAgICAgIE11bHRpcGxlQ2hvaWNlUXVlc3Rpb25Db21wb25lbnQsXG4gICAgICAgIE11bHRpcGxlQ2hvaWNlVmlzdWFsUXVlc3Rpb25Db21wb25lbnQsXG4gICAgICAgIFNob3J0QW5zd2VyUXVlc3Rpb25Db21wb25lbnQsXG4gICAgICAgIFF1aXpTY29yaW5nSW5mb1N0dWRlbnRNb2RhbENvbXBvbmVudCxcbiAgICBdLFxuICAgIGV4cG9ydHM6IFtEcmFnSXRlbUNvbXBvbmVudCwgRHJhZ0FuZERyb3BRdWVzdGlvbkNvbXBvbmVudCwgTXVsdGlwbGVDaG9pY2VRdWVzdGlvbkNvbXBvbmVudCwgU2hvcnRBbnN3ZXJRdWVzdGlvbkNvbXBvbmVudCwgTXVsdGlwbGVDaG9pY2VWaXN1YWxRdWVzdGlvbkNvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNRdWl6UXVlc3Rpb25UeXBlc01vZHVsZSB7fVxuIiwiaW1wb3J0IHsgQmFzZUVudGl0eSB9IGZyb20gJ2FwcC9zaGFyZWQvbW9kZWwvYmFzZS1lbnRpdHknO1xuaW1wb3J0IHsgUXVpelN1Ym1pc3Npb24gfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9xdWl6LXN1Ym1pc3Npb24ubW9kZWwnO1xuaW1wb3J0IHsgUXVpelF1ZXN0aW9uLCBRdWl6UXVlc3Rpb25UeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovcXVpei1xdWVzdGlvbi5tb2RlbCc7XG5cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBTdWJtaXR0ZWRBbnN3ZXIgaW1wbGVtZW50cyBCYXNlRW50aXR5IHtcbiAgICBwdWJsaWMgaWQ/OiBudW1iZXI7XG4gICAgcHVibGljIHNjb3JlSW5Qb2ludHM/OiBudW1iZXI7XG4gICAgcHVibGljIHF1aXpRdWVzdGlvbj86IFF1aXpRdWVzdGlvbjtcbiAgICBwdWJsaWMgc3VibWlzc2lvbj86IFF1aXpTdWJtaXNzaW9uO1xuXG4gICAgcHVibGljIHR5cGU/OiBRdWl6UXVlc3Rpb25UeXBlO1xuXG4gICAgcHJvdGVjdGVkIGNvbnN0cnVjdG9yKHR5cGU6IFF1aXpRdWVzdGlvblR5cGUpIHtcbiAgICAgICAgdGhpcy50eXBlID0gdHlwZTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBTdWJtaXR0ZWRBbnN3ZXIgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9zdWJtaXR0ZWQtYW5zd2VyLm1vZGVsJztcbmltcG9ydCB7IFF1aXpRdWVzdGlvblR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9xdWl6LXF1ZXN0aW9uLm1vZGVsJztcbmltcG9ydCB7IEFuc3dlck9wdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L2Fuc3dlci1vcHRpb24ubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgTXVsdGlwbGVDaG9pY2VTdWJtaXR0ZWRBbnN3ZXIgZXh0ZW5kcyBTdWJtaXR0ZWRBbnN3ZXIge1xuICAgIHB1YmxpYyBzZWxlY3RlZE9wdGlvbnM/OiBBbnN3ZXJPcHRpb25bXTtcblxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihRdWl6UXVlc3Rpb25UeXBlLk1VTFRJUExFX0NIT0lDRSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgU3VibWl0dGVkQW5zd2VyIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovc3VibWl0dGVkLWFuc3dlci5tb2RlbCc7XG5pbXBvcnQgeyBEcmFnQW5kRHJvcE1hcHBpbmcgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9kcmFnLWFuZC1kcm9wLW1hcHBpbmcubW9kZWwnO1xuaW1wb3J0IHsgUXVpelF1ZXN0aW9uVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L3F1aXotcXVlc3Rpb24ubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgRHJhZ0FuZERyb3BTdWJtaXR0ZWRBbnN3ZXIgZXh0ZW5kcyBTdWJtaXR0ZWRBbnN3ZXIge1xuICAgIHB1YmxpYyBtYXBwaW5ncz86IERyYWdBbmREcm9wTWFwcGluZ1tdO1xuXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKFF1aXpRdWVzdGlvblR5cGUuRFJBR19BTkRfRFJPUCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgU3VibWl0dGVkQW5zd2VyIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovc3VibWl0dGVkLWFuc3dlci5tb2RlbCc7XG5pbXBvcnQgeyBRdWl6UXVlc3Rpb25UeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovcXVpei1xdWVzdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBTaG9ydEFuc3dlclN1Ym1pdHRlZFRleHQgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9zaG9ydC1hbnN3ZXItc3VibWl0dGVkLXRleHQubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgU2hvcnRBbnN3ZXJTdWJtaXR0ZWRBbnN3ZXIgZXh0ZW5kcyBTdWJtaXR0ZWRBbnN3ZXIge1xuICAgIHB1YmxpYyBzdWJtaXR0ZWRUZXh0cz86IFNob3J0QW5zd2VyU3VibWl0dGVkVGV4dFtdO1xuXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKFF1aXpRdWVzdGlvblR5cGUuU0hPUlRfQU5TV0VSKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBTdWJtaXR0ZWRBbnN3ZXIgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9zdWJtaXR0ZWQtYW5zd2VyLm1vZGVsJztcbmltcG9ydCB7IFN1Ym1pc3Npb24sIFN1Ym1pc3Npb25FeGVyY2lzZVR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvc3VibWlzc2lvbi5tb2RlbCc7XG5cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBBYnN0cmFjdFF1aXpTdWJtaXNzaW9uIGV4dGVuZHMgU3VibWlzc2lvbiB7XG4gICAgcHVibGljIHNjb3JlSW5Qb2ludHM/OiBudW1iZXI7XG4gICAgcHVibGljIHN1Ym1pdHRlZEFuc3dlcnM/OiBTdWJtaXR0ZWRBbnN3ZXJbXTtcblxuICAgIHByb3RlY3RlZCBjb25zdHJ1Y3Rvcih0eXBlOiBTdWJtaXNzaW9uRXhlcmNpc2VUeXBlKSB7XG4gICAgICAgIHN1cGVyKHR5cGUpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IFN1Ym1pc3Npb25FeGVyY2lzZVR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvc3VibWlzc2lvbi5tb2RlbCc7XG5pbXBvcnQgeyBBYnN0cmFjdFF1aXpTdWJtaXNzaW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovYWJzdHJhY3QtcXVpei1leGFtLXN1Ym1pc3Npb24ubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgUXVpelN1Ym1pc3Npb24gZXh0ZW5kcyBBYnN0cmFjdFF1aXpTdWJtaXNzaW9uIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoU3VibWlzc2lvbkV4ZXJjaXNlVHlwZS5RVUlaKTtcbiAgICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsa0JBQWtCOztBQUEzQixJQU9hO0FBUGI7O0FBT00sSUFBTywwQkFBUCxNQUFPLHlCQUF1QjtNQUNoQyxjQUFBO01BQWU7TUFTZixNQUFNLFVBQStCLFVBQStCO0FBQ2hFLFlBQUksQ0FBQyxTQUFTLGlCQUFpQjtBQUMzQixpQkFBTyxDQUFBOztBQUdYLGNBQU0saUJBQWlCLElBQUksTUFBSztBQUNoQyxZQUFJLHFCQUFxQixTQUFTO0FBR2xDLFlBQUkseUJBQXlCLFNBQVMsZUFBZSxPQUFPLENBQUMsaUJBQWdCO0FBQ3pFLGlCQUFPLFNBQVMsaUJBQWlCLEtBQUssQ0FBQyxZQUFXO0FBQzlDLG1CQUFPLEtBQUssdUJBQXVCLFFBQVEsY0FBYyxZQUFZO1VBQ3pFLEdBQUcsSUFBSTtRQUNYLEdBQUcsSUFBSTtBQUVQLFlBQUksVUFBVTtBQUVWLG1CQUFTLFFBQVEsU0FBVSxTQUFPO0FBQzlCLGtCQUFNLGlCQUFpQixLQUFLLFdBQVcsU0FBUyxpQkFBa0IsUUFBUSxVQUFXLFFBQVEsWUFBYTtBQUMxRyxnQkFBSSxnQkFBZ0I7QUFDaEIsNkJBQWUsS0FBSyxjQUFjO0FBQ2xDLHVDQUF5Qix3QkFBd0IsT0FBTyxTQUFVLGNBQVk7QUFDMUUsdUJBQU8sQ0FBQyxLQUFLLHVCQUF1QixjQUFjLFFBQVEsWUFBWTtjQUMxRSxHQUFHLElBQUk7QUFDUCxtQ0FBcUIsb0JBQW9CLE9BQU8sU0FBVSxVQUFRO0FBQzlELHVCQUFPLENBQUMsS0FBSyx1QkFBdUIsVUFBVSxRQUFRLFFBQVE7Y0FDbEUsR0FBRyxJQUFJOztVQUVmLEdBQUcsSUFBSTs7QUFJWCxjQUFNLFNBQVMsS0FBSyxTQUFTLFNBQVMsaUJBQWlCLHdCQUF3QixvQkFBb0IsY0FBYztBQUVqSCxZQUFJLFFBQVE7QUFDUixpQkFBTztlQUNKO0FBQ0gsaUJBQU8sQ0FBQTs7TUFFZjtNQVdBLFNBQ0ksaUJBQ0Esd0JBQ0Esb0JBQ0EsZ0JBQW9DO0FBRXBDLFlBQUksQ0FBQywwQkFBMEIsdUJBQXVCLFdBQVcsR0FBRztBQUNoRSxpQkFBTzs7QUFHWCxjQUFNLGVBQWUsdUJBQXVCLENBQUM7QUFDN0MsZUFBTyxvQkFBb0IsS0FBSyxTQUFVLFVBQVUsT0FBSztBQUNyRCxnQkFBTSxpQkFBaUIsS0FBSyxXQUFXLGlCQUFpQixVQUFVLFlBQVk7QUFDOUUsY0FBSSxnQkFBZ0I7QUFDaEIsMkJBQWUsS0FBSyxjQUFjO0FBQ2xDLG1DQUF1QixPQUFPLEdBQUcsQ0FBQztBQUNsQywrQkFBbUIsT0FBTyxPQUFPLENBQUM7QUFDbEMsa0JBQU0sU0FBUyxLQUFLLFNBQVMsaUJBQWlCLHdCQUF3QixvQkFBb0IsY0FBYztBQUN4RyxtQ0FBdUIsT0FBTyxHQUFHLEdBQUcsWUFBWTtBQUNoRCwrQkFBbUIsT0FBTyxPQUFPLEdBQUcsUUFBUTtBQUM1QyxnQkFBSSxDQUFDLFFBQVE7QUFDVCw2QkFBZSxJQUFHOztBQUV0QixtQkFBTztpQkFDSjtBQUNILG1CQUFPOztRQUVmLEdBQUcsSUFBSTtNQUNYO01BV0EsbUNBQW1DLFVBQTZCO0FBQzVELFlBQUksQ0FBQyxTQUFTLG1CQUFtQixDQUFDLFNBQVMsV0FBVztBQUVsRCxpQkFBTzs7QUFHWCxpQkFBUyxJQUFJLEdBQUcsSUFBSSxTQUFTLFVBQVUsUUFBUSxLQUFLO0FBQ2hELG1CQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztBQUV4QixrQkFBTSxZQUFZLFNBQVMsVUFBVSxDQUFDO0FBQ3RDLGtCQUFNLFlBQVksU0FBUyxVQUFVLENBQUM7QUFDdEMsa0JBQU0sdUJBQXVCLFNBQVMsZUFBZSxLQUFLLFNBQVUsY0FBWTtBQUM1RSxvQkFBTSx3QkFBd0IsS0FBSyxpQkFBaUIsU0FBUyxpQkFBaUIsV0FBVyxZQUFZO0FBQ3JHLG9CQUFNLHdCQUF3QixLQUFLLGlCQUFpQixTQUFTLGlCQUFpQixXQUFXLFlBQVk7QUFDckcscUJBQU8seUJBQXlCO1lBQ3BDLEdBQUcsSUFBSTtBQUNQLGdCQUFJLHNCQUFzQjtBQUN0QixvQkFBTSwrQkFBK0IsS0FBSywrQkFBK0IsU0FBUyxpQkFBaUIsU0FBUztBQUM1RyxvQkFBTSwrQkFBK0IsS0FBSywrQkFBK0IsU0FBUyxpQkFBaUIsU0FBUztBQUM1RyxrQkFBSSxDQUFDLEtBQUsseUJBQXlCLDhCQUE4Qiw0QkFBNEIsR0FBRztBQUU1Rix1QkFBTzs7Ozs7QUFNdkIsZUFBTztNQUNYO01BVUEsaUJBQWlCLFVBQWdDLFVBQW9CLGNBQTBCO0FBQzNGLGVBQU8sQ0FBQyxDQUFDLEtBQUssV0FBVyxVQUFVLFVBQVUsWUFBWTtNQUM3RDtNQVVBLFdBQVcsVUFBZ0MsVUFBb0IsY0FBMEI7QUFDckYsZUFBTyxTQUFTLEtBQUssQ0FBQyxZQUErQjtBQUNqRCxpQkFBTyxLQUFLLHVCQUF1QixjQUFjLFFBQVEsWUFBWSxLQUFLLEtBQUssdUJBQXVCLFVBQVUsUUFBUSxRQUFRO1FBQ3BJLEdBQUcsSUFBSTtNQUNYO01BU0EsK0JBQStCLFVBQWdDLFVBQWtCO0FBQzdFLGVBQU8sU0FBUyxPQUFPLENBQUMsWUFBWSxLQUFLLHVCQUF1QixRQUFRLFVBQVUsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLFlBQVksUUFBUSxZQUFhO01BQ3ZJO01BU0EseUJBQXlCLE1BQXNCLE1BQW9CO0FBQy9ELFlBQUksS0FBSyxXQUFXLEtBQUssUUFBUTtBQUU3QixpQkFBTzs7QUFFWCxlQUVJLEtBQUssTUFBTSxDQUFDLGFBQTBCO0FBQ2xDLGlCQUFPLEtBQUssS0FBSyxDQUFDLGFBQTBCO0FBQ3hDLG1CQUFPLEtBQUssdUJBQXVCLFVBQVUsUUFBUTtVQUN6RCxDQUFDO1FBQ0wsQ0FBQyxLQUNELEtBQUssTUFBTSxDQUFDLGFBQTBCO0FBQ2xDLGlCQUFPLEtBQUssS0FBSyxDQUFDLGFBQTBCO0FBQ3hDLG1CQUFPLEtBQUssdUJBQXVCLFVBQVUsUUFBUTtVQUN6RCxDQUFDO1FBQ0wsQ0FBQztNQUVUO01BU0EsdUJBQXVCLEdBQXFDLEdBQW1DO0FBQzNGLGVBQU8sTUFBTSxLQUFNLEtBQUssVUFBYSxLQUFLLFdBQWUsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFRLEVBQUUsVUFBVSxVQUFhLEVBQUUsVUFBVSxVQUFhLEVBQUUsV0FBVyxFQUFFO01BQ2pLOzt5QkExTVMsMEJBQXVCO01BQUE7bUVBQXZCLDBCQUF1QixTQUF2Qix5QkFBdUIsV0FBQSxZQURWLE9BQU0sQ0FBQTs7Ozs7O0FDQWhDLElBQWE7QUFBYjs7QUFBTSxJQUFPLHFCQUFQLE1BQXlCO01BQ3BCO01BQ0E7TUFDQTtNQUNBLFVBQVU7TUFDVjtNQUNBO01BQ0E7TUFDQTtNQUVQLFlBQVksVUFBZ0MsY0FBc0M7QUFDOUUsYUFBSyxXQUFXO0FBQ2hCLGFBQUssZUFBZTtNQUN4Qjs7Ozs7O0FDZkUsU0FBVSxXQUFRO0FBQ3BCLFNBQU8sS0FBSyxNQUFNLEtBQUssT0FBTSxJQUFLLE9BQU8sZ0JBQWdCO0FBQzdEO0FBRkE7Ozs7OztBQ0ZBLElBTWEsc0JBUUE7QUFkYjs7O0FBTU0sSUFBTyx1QkFBUCxNQUEyQjtNQUN0QjtNQUNBO01BQ1AsY0FBQTtBQUNJLGFBQUssU0FBUyxTQUFRO01BQzFCOztBQUdFLElBQU8sZUFBUCxjQUE0QixxQkFBb0I7TUFDM0M7TUFDQTtNQUNBO01BQ0E7TUFDQSxVQUFVO01BQ1Y7TUFFUCxjQUFBO0FBQ0ksY0FBSztNQUNUOzs7Ozs7QUN6QkosSUFFYTtBQUZiOzs7QUFFTSxJQUFPLFdBQVAsY0FBd0IscUJBQW9CO01BQ3ZDO01BQ0E7TUFDQTtNQUNBLFVBQVU7TUFFakIsY0FBQTtBQUNJLGNBQUs7TUFDVDs7Ozs7O0FDWEosU0FBd0IsV0FBVyxZQUFZLGNBQWMsT0FBMEIsaUJBQWdDOztBQUF2SCxJQU1hO0FBTmI7O0FBTU0sSUFBTyxtQkFBUCxNQUFPLGtCQUFnQjtNQXNCYjtNQUNBO01BdEJILFVBQVU7TUFDVixjQUFjO01BQ2QsbUJBQW1CO01BQ25CLGNBQW1DO01BQ25DLGNBQW1DLE9BQU87TUFDMUMsUUFBUTtNQUNSO01BQ0EsV0FBaUM7TUFFekI7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNUO01BQ0E7TUFDQTtNQUNBLFdBQVc7TUFDWDtNQUVSLFlBQ1ksSUFDQSxVQUFtQjtBQURuQixhQUFBLEtBQUE7QUFDQSxhQUFBLFdBQUE7QUFFUixhQUFLLGlCQUFpQixHQUFHO0FBQ3pCLGFBQUssZ0JBQWdCLEtBQUssZUFBZTtBQUN6QyxhQUFLLFdBQVcsT0FBTyxpQkFBaUIsS0FBSyxjQUFjO0FBQzNELGFBQUssV0FBVyxLQUFLLGVBQWUsb0JBQW9CLElBQUksS0FBSyxlQUFlLG9CQUFvQjtBQUNwRyxhQUFLLGFBQWEsS0FBSyxTQUFTLGFBQWE7QUFDN0MsYUFBSyxVQUFVLEtBQUssU0FBUyxTQUFTO01BQzFDO01BR08saUJBQWlCLE1BQVc7QUFDL0IsWUFBSSxLQUFLLGtCQUFrQjtBQUN2QixlQUFLLFlBQVc7O01BRXhCO01BRU8sV0FBUTtBQUNYLGFBQUsscUJBQXFCLEtBQUssZ0JBQWdCLFlBQVksS0FBSyxTQUFTLFdBQVcsSUFBSSxLQUFLO0FBQzdGLGFBQUsscUJBQXFCLEtBQUssZ0JBQWdCLFlBQVksS0FBSyxTQUFTLFdBQVcsSUFBSSxLQUFLO01BQ2pHO01BRU8sa0JBQWU7QUFDbEIsYUFBSyxZQUFZLENBQUM7TUFDdEI7TUFFTyxZQUFZLFNBQXNCO0FBQ3JDLFlBQUksUUFBUSxhQUFhLEtBQUssQ0FBQyxRQUFRLGFBQWEsRUFBRSxhQUFhO0FBQy9ELGVBQUssWUFBWSxDQUFDOztBQUV0QixZQUFJLFFBQVEsV0FBVyxHQUFHO0FBQ3RCLGVBQUssZUFBZSxZQUFZLEtBQUs7QUFDckMsY0FBSSxDQUFDLFFBQVEsV0FBVyxFQUFFLGFBQWE7QUFDbkMsaUJBQUssWUFBWSxDQUFDOzs7TUFHOUI7TUFFUSxjQUFjLENBQUMsUUFBZ0IsS0FBSyxVQUFlO0FBQ3ZELGFBQUssZ0JBQWdCLFdBQVcsTUFBSztBQUNqQyxjQUFJLEtBQUssZUFBZSxlQUFlLEtBQUssZUFBZSxnQkFBZ0IsR0FBRztBQUUxRSxpQkFBSyxVQUFVLEtBQUssVUFBVSxHQUFHLGNBQWM7QUFFL0MsaUJBQUssVUFBVSxLQUFLLHFCQUFvQixHQUFJLEtBQUssWUFBWSxLQUFLLE9BQU87O1FBRWpGLEdBQUcsS0FBSztNQUNaO01BRVEsdUJBQXVCLE1BQWE7QUFDeEMsY0FBTSxRQUFTLEtBQUssV0FBVyxLQUFLLFdBQVksS0FBSyxlQUFlLGNBQWMsS0FBSztBQUV2RixlQUFPLEtBQUssSUFDUixLQUFLLEtBQ0EsS0FBSyxjQUFjLGVBQ2YsV0FBVyxpQkFBaUIsS0FBSyxhQUFhLEVBQUUsV0FBVyxJQUFJLFdBQVcsaUJBQWlCLEtBQUssYUFBYSxFQUFFLFlBQVksS0FDNUgsS0FDQSxRQUNBLEtBQUssYUFDVCxLQUFLLGtCQUFrQixHQUUzQixLQUFLLGtCQUFrQjtNQUUvQjtNQUVRLFlBQVksQ0FBQyxVQUFrQixZQUE2QixZQUF5QjtBQUN6RixhQUFLLFNBQVMsU0FBUyxLQUFLLGdCQUFnQixZQUFZLFNBQVMsU0FBUSxJQUFLLEtBQUssUUFBUTtBQUMzRixhQUFLLFNBQVMsU0FBUyxLQUFLLGdCQUFnQixjQUFjLFdBQVcsU0FBUSxDQUFFO0FBQy9FLGFBQUssU0FBUyxTQUFTLEtBQUssZ0JBQWdCLFdBQVcsT0FBTztNQUNsRTs7eUJBNUZTLG1CQUFnQixnQ0FBQSxjQUFBLEdBQUEsZ0NBQUEsYUFBQSxDQUFBO01BQUE7aUVBQWhCLG1CQUFnQixXQUFBLENBQUEsQ0FBQSxJQUFBLFdBQUEsRUFBQSxDQUFBLEdBQUEsY0FBQSxTQUFBLDhCQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBOzttQkFBaEIsSUFBQSxlQUFBO1VBQWdCLEdBQUEsT0FBQSw2QkFBQTs7Ozs7Ozs7QUNON0IsU0FBUyxXQUFXLFNBQUFBLFFBQWUseUJBQXlCO0FBQzVELE9BQU8sY0FBYzs7Ozs7O0FDR0wsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLHFCQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFEdUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxPQUFBLE9BQUEsaUJBQUEsSUFBQSxPQUFBLFNBQUEsZUFBQSxLQUFBLE9BQUEsU0FBQSxlQUFBLEVBQW9GLHFCQUFBLE9BQUEsUUFBQTs7Ozs7QUFFM0csSUFBQSx3QkFBQSxHQUFBLEtBQUE7Ozs7O0FBSkosSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLHdEQUFBLEdBQUEsQ0FBQSxFQUVDLEdBQUEsZ0RBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTtBQUVMLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBTm1DLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsT0FBQSxhQUFBLEVBQWlDLGVBQUEsT0FBQSxRQUFBO0FBQzVELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLFNBQUEsa0JBQUEsSUFBQSxFQUFBOzs7OztBQVdRLElBQUEsd0JBQUEsR0FBQSxLQUFBOzs7OztBQUNBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQThILElBQUEscUJBQUEsQ0FBQTtBQUFtQixJQUFBLDJCQUFBO0FBQ3JKLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7Ozs7QUFEa0ksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxPQUFBLFNBQUEsSUFBQTs7Ozs7QUFOOUksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUFtQixJQUFBLDJCQUFBO0FBQ3pCLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxpREFBQSxHQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLGlEQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7QUFHSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBOzs7O0FBVmEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLElBQUEsRUFBZ0Isb0JBQUEsSUFBQSxFQUFBLGVBQUEsRUFBQSxFQUFBLGVBQUEsRUFBQSxFQUFBLFNBQUEsR0FBQTtBQUNLLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsT0FBQSxhQUFBLEVBQWlDLGVBQUEsT0FBQSxRQUFBO0FBQzdDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsT0FBQSxTQUFBLElBQUE7Ozs7O0FBVWxCLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7O0FEMUJKLFNBVWE7QUFWYjs7QUFFQTs7Ozs7QUFRTSxJQUFPLG9CQUFQLE1BQU8sbUJBQWlCO01BQ2pCO01BQ0E7TUFDQTtNQUNBO01BQ0EsbUJBQXdDLG9CQUFJLElBQUc7TUFDeEQsV0FBVztNQUVYLGNBQUE7TUFBZTtNQUtmLFdBQVE7QUFDSixhQUFLLFdBQVcsU0FBUyxPQUFPLFVBQVUsU0FBUyxFQUFFO01BQ3pEOzt5QkFmUyxvQkFBaUI7TUFBQTtpRUFBakIsb0JBQWlCLFdBQUEsQ0FBQSxDQUFBLGVBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsVUFBQSxZQUFBLGVBQUEsaUJBQUEsU0FBQSxXQUFBLGtCQUFBLG1CQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxXQUFBLCtCQUFBLEdBQUEsYUFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLFdBQUEsSUFBQSxHQUFBLHFCQUFBLEdBQUEsbUJBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxvQkFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLG1CQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsb0JBQUEsZUFBQSxlQUFBLE9BQUEsR0FBQSxDQUFBLFdBQUEsSUFBQSxHQUFBLFlBQUEsR0FBQSxtQkFBQSxhQUFBLEdBQUEsQ0FBQSxhQUFBLElBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsYUFBQSxFQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsa0JBQUEsY0FBQSxTQUFBLFNBQUEsU0FBQSxXQUFBLE9BQUEsWUFBQSxVQUFBLGlCQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsZ0JBQUEsa0NBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSwyQkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1Y5QixVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLHlCQUFBLEdBQUEsMENBQUEsR0FBQSxDQUFBLEVBT0MsR0FBQSwwQ0FBQSxJQUFBLENBQUEsRUFBQSxHQUFBLDBDQUFBLEdBQUEsQ0FBQTtBQW1CTCxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLElBQUE7OztBQTVCNkQsVUFBQSx5QkFBQSxXQUFBLDhCQUFBLEdBQUEsS0FBQSxJQUFBLFFBQUEsQ0FBQTtBQUN6RCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxZQUFBLElBQUEsU0FBQSxrQkFBQSxJQUFBLEVBQUE7QUFRQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxZQUFBLENBQUEsSUFBQSxTQUFBLGtCQUFBLElBQUEsRUFBQTtBQWFBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLFVBQUEsSUFBQSxFQUFBOzs7OztxRkRaUyxtQkFBaUIsRUFBQSxXQUFBLG9CQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVY5QixTQUF3QixhQUFBQyxZQUFXLFNBQUFDLGNBQWE7QUFDaEQsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyx3QkFBd0I7QUFVakMsU0FBUyx3QkFBd0I7Ozs7Ozs7O0FDS2IsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBU0gsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQVJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsOEJBQUEsR0FBQUMsTUFBQSxPQUFBLE9BQUEsT0FBQSxTQUFBLFFBQUEsT0FBQSxZQUFBLE9BQUEsYUFBQSxDQUFBOzs7OztBQVVSLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQVNILElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUFSWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLG1CQUFBLDhCQUFBLEdBQUFBLE1BQUEsT0FBQSxPQUFBLE9BQUEsU0FBQSxRQUFBLE9BQUEsWUFBQSxPQUFBLGFBQUEsQ0FBQTs7Ozs7QUF0QnBCLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLElBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSwyRkFBQSxHQUFBLENBQUEsRUFZQyxJQUFBLDJGQUFBLEdBQUEsQ0FBQTtBQWNMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsUUFBQTs7OztBQTVCWSxJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxnQ0FBQSxPQUFBLDhDQUFBLE9BQUEsbUNBQUEsSUFBQSxLQUFBLEVBQUE7QUFhQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsRUFBQSxPQUFBLGdDQUFBLE9BQUEsOENBQUEsT0FBQSxtQ0FBQSxLQUFBLEtBQUEsRUFBQTs7Ozs7QUF3QlEsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBU0gsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQVJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsOEJBQUEsR0FBQUEsTUFBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSxZQUFBLFFBQUEsYUFBQSxDQUFBOzs7OztBQVVSLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQWFILElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFaWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLG1CQUFBLDhCQUFBLEdBQUEsS0FBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSw2QkFBQSxRQUFBLDZCQUFBLFFBQUEsWUFBQSxRQUFBLGVBQUEsUUFBQSxhQUFBLFFBQUEsV0FBQSxDQUFBOzs7OztBQWxCaEIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsd0dBQUEsR0FBQSxDQUFBLEVBWUMsR0FBQSx3R0FBQSxHQUFBLEVBQUE7QUFrQkwsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQS9CUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxnQ0FBQSxRQUFBLDhDQUFBLFFBQUEsbUNBQUEsSUFBQSxJQUFBLEVBQUE7QUFhQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsRUFBQSxRQUFBLGdDQUFBLFFBQUEsOENBQUEsUUFBQSxtQ0FBQSxLQUFBLElBQUEsRUFBQTs7Ozs7QUFzQkksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBU0gsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQVJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsOEJBQUEsR0FBQUEsTUFBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSxZQUFBLFFBQUEsYUFBQSxDQUFBOzs7OztBQVVSLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQWFILElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFaWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLG1CQUFBLDhCQUFBLEdBQUEsS0FBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSxtQ0FBQSxRQUFBLGlDQUFBLFFBQUEsWUFBQSxRQUFBLGVBQUEsUUFBQSxVQUFBLFFBQUEsUUFBQSxDQUFBOzs7OztBQWxCaEIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEseUdBQUEsR0FBQSxDQUFBLEVBWUMsR0FBQSx5R0FBQSxHQUFBLEVBQUE7QUFrQkwsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQS9CUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxxQ0FBQSxJQUFBLElBQUEsRUFBQTtBQWFBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLHFDQUFBLElBQUEsSUFBQSxFQUFBOzs7OztBQXNCSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFTSCxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBUlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxtQkFBQSw4QkFBQSxHQUFBQSxNQUFBLFFBQUEsT0FBQSxRQUFBLFNBQUEsUUFBQSxRQUFBLFlBQUEsUUFBQSxhQUFBLENBQUE7Ozs7O0FBVVIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBYUgsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQVpZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsOEJBQUEsR0FBQSxLQUFBLFFBQUEsT0FBQSxRQUFBLFNBQUEsUUFBQSxRQUFBLHlCQUFBLFFBQUEsMkJBQUEsUUFBQSxZQUFBLFFBQUEsZUFBQSxRQUFBLFVBQUEsUUFBQSxRQUFBLENBQUE7Ozs7O0FBbEJoQixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx5R0FBQSxHQUFBLENBQUEsRUFZQyxHQUFBLHlHQUFBLEdBQUEsRUFBQTtBQWtCTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBL0JRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxFQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLEVBQUE7QUFhQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSwwQkFBQSxJQUFBLElBQUEsRUFBQTs7Ozs7QUF2RlosSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsSUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwwRkFBQSxHQUFBLENBQUEsRUFpQ0MsSUFBQSwyRkFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLDJGQUFBLEdBQUEsQ0FBQTtBQXFFTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7Ozs7QUF2R1EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsU0FBQSxTQUFBLE9BQUEsaUJBQUEsa0JBQUEsSUFBQSxFQUFBO0FBa0NBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLFNBQUEsU0FBQSxPQUFBLGlCQUFBLGdCQUFBLEtBQUEsRUFBQTtBQWtDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxTQUFBLFNBQUEsT0FBQSxpQkFBQSxlQUFBLEtBQUEsRUFBQTs7Ozs7QUE0Q1ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBU0gsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQVJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsOEJBQUEsR0FBQUEsTUFBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSxZQUFBLFFBQUEsYUFBQSxDQUFBOzs7OztBQWFSLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLEtBQUEsRUFBQTtBQWNBLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxHQUFBO0FBQ0ssSUFBQSxxQkFBQSxDQUFBO0FBQzBILElBQUEsMkJBQUE7QUFFL0gsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFsQlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxtQkFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSw2QkFBQSxRQUFBLDZCQUFBLFFBQUEsNkJBQUEsUUFBQSxZQUFBLFFBQUEsZUFBQSxRQUFBLGFBQUEsUUFBQSxXQUFBLENBQUEsQ0FBQTtBQWFDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsTUFBQSxRQUFBLDZCQUFBLEtBQUEsUUFBQSxTQUFBLFFBQUEsTUFBQSxRQUFBLDZCQUFBLHdDQUFBLFFBQUEsNkJBQUEsS0FBQSxRQUFBLFNBQUEsUUFBQSxLQUFBLFFBQUEsNkJBQUEsT0FBQSxRQUFBLE9BQUEsRUFBQTs7Ozs7QUFVVCxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxLQUFBLEVBQUE7QUFjQSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsR0FBQTtBQUNLLElBQUEscUJBQUEsQ0FBQTtBQUdMLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFwQlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxtQkFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSw2QkFBQSxRQUFBLDZCQUFBLFFBQUEsNkJBQUEsUUFBQSxZQUFBLFFBQUEsZUFBQSxRQUFBLGFBQUEsUUFBQSxXQUFBLENBQUEsQ0FBQTtBQWFDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsTUFBQSxRQUFBLDZCQUFBLEtBQUEsUUFBQSxTQUFBLFFBQUEsTUFBQSxRQUFBLDZCQUFBLHdDQUFBLFFBQUEsNkJBQUEsS0FBQSxRQUFBLFNBQUEsUUFBQSxLQUFBLFFBQUEsNkJBQUEscUVBQUE7Ozs7O0FBNURqQixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx3R0FBQSxHQUFBLENBQUEsRUFZQyxHQUFBLHdHQUFBLElBQUEsRUFBQSxFQUFBLEdBQUEsd0dBQUEsSUFBQSxFQUFBO0FBdURMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFwRVEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsZ0NBQUEsUUFBQSw4Q0FBQSxRQUFBLG1DQUFBLElBQUEsSUFBQSxFQUFBO0FBYUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLEVBQUEsUUFBQSxnQ0FBQSxRQUFBLDhDQUFBLFFBQUEsbUNBQUEsTUFBQSxRQUFBLDRCQUFBLElBQUEsSUFBQSxFQUFBO0FBMEJBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxFQUFBLFFBQUEsZ0NBQUEsUUFBQSw4Q0FBQSxRQUFBLG1DQUFBLE1BQUEsUUFBQSwyQkFBQSxJQUFBLElBQUEsRUFBQTs7Ozs7QUFpQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBU0gsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQVJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsOEJBQUEsR0FBQUEsTUFBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSxZQUFBLFFBQUEsYUFBQSxDQUFBOzs7OztBQVVSLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLEtBQUEsRUFBQTtBQWNBLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxHQUFBO0FBQ0ssSUFBQSxxQkFBQSxDQUFBO0FBQ29ILElBQUEsMkJBQUE7QUFFekgsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFsQlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxtQkFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSxtQ0FBQSxRQUFBLGlDQUFBLFFBQUEsaUJBQUEsUUFBQSxZQUFBLFFBQUEsZUFBQSxRQUFBLFVBQUEsUUFBQSxRQUFBLENBQUEsQ0FBQTtBQWFDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsTUFBQSxRQUFBLGlDQUFBLEtBQUEsUUFBQSxTQUFBLFFBQUEsS0FBQSxRQUFBLGlCQUFBLHdDQUFBLFFBQUEsbUNBQUEsS0FBQSxRQUFBLFNBQUEsUUFBQSxLQUFBLFFBQUEsaUJBQUEsT0FBQSxRQUFBLE9BQUEsRUFBQTs7Ozs7QUFPVCxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxLQUFBLEVBQUE7QUFjQSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsR0FBQTtBQUNLLElBQUEscUJBQUEsQ0FBQTtBQUdMLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFwQlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxtQkFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSxtQ0FBQSxRQUFBLGlDQUFBLFFBQUEsaUJBQUEsUUFBQSxZQUFBLFFBQUEsZUFBQSxRQUFBLFVBQUEsUUFBQSxRQUFBLENBQUEsQ0FBQTtBQWFDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsTUFBQSxRQUFBLGlDQUFBLEtBQUEsUUFBQSxTQUFBLFFBQUEsS0FBQSxRQUFBLGlCQUFBLHdDQUFBLFFBQUEsbUNBQUEsS0FBQSxRQUFBLFNBQUEsUUFBQSxLQUFBLFFBQUEsaUJBQUEscUVBQUE7Ozs7O0FBdERqQixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx5R0FBQSxHQUFBLENBQUEsRUFZQyxHQUFBLHlHQUFBLElBQUEsRUFBQSxFQUFBLEdBQUEseUdBQUEsSUFBQSxFQUFBO0FBaURMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUE5RFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEscUNBQUEsSUFBQSxJQUFBLEVBQUE7QUFhQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxxQ0FBQSxLQUFBLFFBQUEseUJBQUEsSUFBQSxJQUFBLEVBQUE7QUF1QkEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEscUNBQUEsS0FBQSxRQUFBLHdCQUFBLElBQUEsSUFBQSxFQUFBOzs7OztBQThCSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFTSCxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBUlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxtQkFBQSw4QkFBQSxHQUFBQSxNQUFBLFFBQUEsT0FBQSxRQUFBLFNBQUEsUUFBQSxRQUFBLFlBQUEsUUFBQSxhQUFBLENBQUE7Ozs7O0FBVVIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBY0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEdBQUE7QUFDSyxJQUFBLHFCQUFBLENBQUE7QUFFZ0QsSUFBQSwyQkFBQTtBQUVyRCxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTs7OztBQW5CWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLG1CQUFBLDhCQUFBLEdBQUEsS0FBQSxDQUFBLFFBQUEsT0FBQSxRQUFBLFNBQUEsUUFBQSxRQUFBLHlCQUFBLFFBQUEsMkJBQUEsUUFBQSxrQkFBQSxRQUFBLFlBQUEsUUFBQSxlQUFBLFFBQUEsVUFBQSxRQUFBLFFBQUEsQ0FBQSxDQUFBO0FBYUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxNQUFBLFFBQUEsMkJBQUEsS0FBQSxRQUFBLFNBQUEsUUFBQSxLQUFBLFFBQUEsa0JBQUEsT0FBQSxRQUFBLHlCQUFBLEtBQUEsUUFBQSxTQUFBLFFBQUEsS0FBQSxRQUFBLGtCQUFBLE9BQUEsUUFBQSxPQUFBLEVBQUE7Ozs7O0FBUVQsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBY0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEdBQUE7QUFDSyxJQUFBLHFCQUFBLENBQUE7QUFJTCxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxLQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBOzs7O0FBckJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsOEJBQUEsR0FBQSxLQUFBLENBQUEsUUFBQSxPQUFBLFFBQUEsU0FBQSxRQUFBLFFBQUEseUJBQUEsUUFBQSwyQkFBQSxRQUFBLGtCQUFBLFFBQUEsWUFBQSxRQUFBLGVBQUEsUUFBQSxVQUFBLFFBQUEsUUFBQSxDQUFBLENBQUE7QUFhQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLE1BQUEsUUFBQSwyQkFBQSxLQUFBLFFBQUEsU0FBQSxRQUFBLEtBQUEsUUFBQSxrQkFBQSxPQUFBLFFBQUEseUJBQUEsS0FBQSxRQUFBLFNBQUEsUUFBQSxLQUFBLFFBQUEsa0JBQUEscUVBQUE7Ozs7O0FBdkRqQixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx5R0FBQSxHQUFBLENBQUEsRUFZQyxHQUFBLHlHQUFBLElBQUEsRUFBQSxFQUFBLEdBQUEseUdBQUEsSUFBQSxFQUFBO0FBbURMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFoRVEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsMkJBQUEsSUFBQSxJQUFBLEVBQUE7QUFhQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSwwQkFBQSxLQUFBLFFBQUEseUJBQUEsSUFBQSxJQUFBLEVBQUE7QUF3QkEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsMEJBQUEsS0FBQSxRQUFBLHdCQUFBLElBQUEsSUFBQSxFQUFBOzs7OztBQW5MWixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxJQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDBGQUFBLEdBQUEsQ0FBQSxFQXNFQyxJQUFBLDJGQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsMkZBQUEsR0FBQSxDQUFBO0FBcUlMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsUUFBQTs7OztBQTVNUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxTQUFBLFNBQUEsT0FBQSxpQkFBQSxrQkFBQSxJQUFBLEVBQUE7QUF1RUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsU0FBQSxTQUFBLE9BQUEsaUJBQUEsZ0JBQUEsS0FBQSxFQUFBO0FBaUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLFNBQUEsU0FBQSxPQUFBLGlCQUFBLGVBQUEsS0FBQSxFQUFBOzs7OztBQTZFWSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFTSCxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBUlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxtQkFBQSw4QkFBQSxHQUFBQSxNQUFBLFFBQUEsT0FBQSxRQUFBLFNBQUEsUUFBQSxRQUFBLFlBQUEsUUFBQSxhQUFBLENBQUE7Ozs7O0FBYVIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBY0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEdBQUE7QUFBRyxJQUFBLHFCQUFBLENBQUE7QUFBOEgsSUFBQSwyQkFBQTtBQUNqSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTs7OztBQWZZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsOEJBQUEsR0FBQSxLQUFBLENBQUEsUUFBQSxPQUFBLFFBQUEsU0FBQSxRQUFBLFFBQUEsNkJBQUEsUUFBQSw2QkFBQSxRQUFBLDZCQUFBLFFBQUEsWUFBQSxRQUFBLGVBQUEsUUFBQSxhQUFBLFFBQUEsV0FBQSxDQUFBLENBQUE7QUFZRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLE1BQUEsUUFBQSw2QkFBQSxLQUFBLFFBQUEsU0FBQSxRQUFBLE1BQUEsUUFBQSw2QkFBQSxPQUFBLFFBQUEsT0FBQSxFQUFBOzs7OztBQVFQLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLEtBQUEsRUFBQTtBQWNBLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxHQUFBO0FBQUcsSUFBQSxxQkFBQSxDQUFBO0FBQWdILElBQUEsMkJBQUE7QUFDbkgsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFmWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLG1CQUFBLDhCQUFBLEdBQUEsS0FBQSxDQUFBLFFBQUEsT0FBQSxRQUFBLFNBQUEsUUFBQSxRQUFBLDZCQUFBLFFBQUEsNkJBQUEsUUFBQSw2QkFBQSxRQUFBLFlBQUEsUUFBQSxlQUFBLFFBQUEsYUFBQSxRQUFBLFdBQUEsQ0FBQSxDQUFBO0FBWUQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxNQUFBLFFBQUEsNkJBQUEsS0FBQSxRQUFBLFNBQUEsUUFBQSxNQUFBLFFBQUEsNkJBQUEsT0FBQTs7Ozs7QUF4RGYsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsd0dBQUEsR0FBQSxDQUFBLEVBWUMsR0FBQSx3R0FBQSxJQUFBLEVBQUEsRUFBQSxHQUFBLHdHQUFBLElBQUEsRUFBQTtBQStDTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBNURRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLGdDQUFBLFFBQUEsOENBQUEsUUFBQSxtQ0FBQSxJQUFBLElBQUEsRUFBQTtBQWFBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxFQUFBLFFBQUEsZ0NBQUEsUUFBQSw4Q0FBQSxRQUFBLG1DQUFBLE1BQUEsUUFBQSw0QkFBQSxJQUFBLElBQUEsRUFBQTtBQXVCQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsRUFBQSxRQUFBLGdDQUFBLFFBQUEsOENBQUEsUUFBQSxtQ0FBQSxNQUFBLFFBQUEsMkJBQUEsSUFBQSxJQUFBLEVBQUE7Ozs7O0FBNEJJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQVNILElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFSWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLG1CQUFBLDhCQUFBLEdBQUFBLE1BQUEsUUFBQSxPQUFBLFFBQUEsU0FBQSxRQUFBLFFBQUEsWUFBQSxRQUFBLGFBQUEsQ0FBQTs7Ozs7QUFVUixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxLQUFBLEVBQUE7QUFjQSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsR0FBQTtBQUFHLElBQUEscUJBQUEsQ0FBQTtBQUFxSCxJQUFBLDJCQUFBO0FBQ3hILElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxLQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBOzs7O0FBZlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxtQkFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSxtQ0FBQSxRQUFBLGlDQUFBLFFBQUEsaUJBQUEsUUFBQSxZQUFBLFFBQUEsZUFBQSxRQUFBLFVBQUEsUUFBQSxRQUFBLENBQUEsQ0FBQTtBQVlELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsTUFBQSxRQUFBLGlDQUFBLEtBQUEsUUFBQSxTQUFBLFFBQUEsS0FBQSxRQUFBLGlCQUFBLE9BQUEsUUFBQSxPQUFBLEVBQUE7Ozs7O0FBS1AsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBY0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEdBQUE7QUFBRyxJQUFBLHFCQUFBLENBQUE7QUFBdUcsSUFBQSwyQkFBQTtBQUMxRyxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFoQlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxtQkFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSxtQ0FBQSxRQUFBLGlDQUFBLFFBQUEsaUJBQUEsUUFBQSxZQUFBLFFBQUEsZUFBQSxRQUFBLFVBQUEsUUFBQSxRQUFBLENBQUEsQ0FBQTtBQVlELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsTUFBQSxRQUFBLGlDQUFBLEtBQUEsUUFBQSxTQUFBLFFBQUEsS0FBQSxRQUFBLGlCQUFBLE9BQUE7Ozs7O0FBbERmLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLHlHQUFBLEdBQUEsQ0FBQSxFQVlDLEdBQUEseUdBQUEsSUFBQSxFQUFBLEVBQUEsR0FBQSx5R0FBQSxJQUFBLEVBQUE7QUEwQ0wsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQXZEUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxxQ0FBQSxJQUFBLElBQUEsRUFBQTtBQWFBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLHFDQUFBLEtBQUEsUUFBQSx5QkFBQSxJQUFBLElBQUEsRUFBQTtBQW9CQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxxQ0FBQSxLQUFBLFFBQUEsd0JBQUEsSUFBQSxJQUFBLEVBQUE7Ozs7O0FBMEJJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQVNILElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFSWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLG1CQUFBLDhCQUFBLEdBQUFBLE1BQUEsUUFBQSxPQUFBLFFBQUEsU0FBQSxRQUFBLFFBQUEsWUFBQSxRQUFBLGFBQUEsQ0FBQTs7Ozs7QUFVUixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxLQUFBLEVBQUE7QUFjQSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsR0FBQTtBQUFHLElBQUEscUJBQUEsQ0FBQTtBQUFnSCxJQUFBLDJCQUFBO0FBQ25ILElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxLQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBOzs7O0FBZlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxtQkFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQSxRQUFBLE9BQUEsUUFBQSxTQUFBLFFBQUEsUUFBQSx5QkFBQSxRQUFBLDJCQUFBLFFBQUEsa0JBQUEsUUFBQSxZQUFBLFFBQUEsZUFBQSxRQUFBLFVBQUEsUUFBQSxRQUFBLENBQUEsQ0FBQTtBQVlELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsTUFBQSxRQUFBLDJCQUFBLEtBQUEsUUFBQSxTQUFBLFFBQUEsS0FBQSxRQUFBLGtCQUFBLE9BQUEsUUFBQSxPQUFBLEVBQUE7Ozs7O0FBS1AsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBY0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEdBQUE7QUFBRyxJQUFBLHFCQUFBLENBQUE7QUFBa0csSUFBQSwyQkFBQTtBQUNyRyxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTs7OztBQWZZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsOEJBQUEsR0FBQSxLQUFBLENBQUEsUUFBQSxPQUFBLFFBQUEsU0FBQSxRQUFBLFFBQUEseUJBQUEsUUFBQSwyQkFBQSxRQUFBLGtCQUFBLFFBQUEsWUFBQSxRQUFBLGVBQUEsUUFBQSxVQUFBLFFBQUEsUUFBQSxDQUFBLENBQUE7QUFZRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLE1BQUEsUUFBQSwyQkFBQSxLQUFBLFFBQUEsU0FBQSxRQUFBLEtBQUEsUUFBQSxrQkFBQSxPQUFBOzs7OztBQWxEZixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx5R0FBQSxHQUFBLENBQUEsRUFZQyxHQUFBLHlHQUFBLElBQUEsRUFBQSxFQUFBLEdBQUEseUdBQUEsSUFBQSxFQUFBO0FBeUNMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUF0RFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsMkJBQUEsSUFBQSxJQUFBLEVBQUE7QUFhQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSwwQkFBQSxLQUFBLFFBQUEseUJBQUEsSUFBQSxJQUFBLEVBQUE7QUFvQkEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsMEJBQUEsS0FBQSxRQUFBLHdCQUFBLElBQUEsSUFBQSxFQUFBOzs7OztBQWhLWixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxJQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDBGQUFBLEdBQUEsQ0FBQSxFQThEQyxJQUFBLDJGQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsMkZBQUEsR0FBQSxDQUFBO0FBb0hMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsUUFBQTs7OztBQW5MUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxTQUFBLFNBQUEsT0FBQSxpQkFBQSxrQkFBQSxJQUFBLEVBQUE7QUErREEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsU0FBQSxTQUFBLE9BQUEsaUJBQUEsZ0JBQUEsS0FBQSxFQUFBO0FBMERBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLFNBQUEsU0FBQSxPQUFBLGlCQUFBLGVBQUEsS0FBQSxFQUFBOzs7Ozs7QUF6ZVIsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUlKLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUEyRCxJQUFBLHlCQUFBLFNBQUEsU0FBQSxzRkFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxPQUFBLFlBQUE7QUFBQSxhQUFTLDBCQUFBLEtBQUEsQ0FBRztJQUFBLENBQUE7QUFBRSxJQUFBLDJCQUFBO0FBQzdFLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDRFQUFBLElBQUEsQ0FBQSxFQWtDQyxJQUFBLDRFQUFBLElBQUEsQ0FBQSxFQUFBLElBQUEsNEVBQUEsSUFBQSxDQUFBLEVBQUEsSUFBQSw0RUFBQSxJQUFBLENBQUE7QUF5ZkQsSUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUE4QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSx1RkFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxPQUFBLFlBQUE7QUFBQSxhQUFTLDBCQUFBLEtBQUEsQ0FBRztJQUFBLENBQUE7QUFBRSxJQUFBLHFCQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsMkJBQUE7QUFDckUsSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLElBQUE7Ozs7QUFuaUJnQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLG1CQUFBLDhCQUFBLEdBQUEsS0FBQSxPQUFBLFNBQUEsT0FBQSxPQUFBLGFBQUEsQ0FBQTtBQUtaLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLFNBQUEsZ0JBQUEsT0FBQSxZQUFBLGtCQUFBLE9BQUEsaUJBQUEsS0FBQSxFQUFBO0FBbUNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLFNBQUEsZ0JBQUEsT0FBQSxZQUFBLGtCQUFBLENBQUEsT0FBQSxpQkFBQSxLQUFBLEVBQUE7QUE2R0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsU0FBQSxnQkFBQSxPQUFBLFlBQUEsNEJBQUEsS0FBQSxFQUFBO0FBa05BLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLFNBQUEsZ0JBQUEsT0FBQSxZQUFBLCtCQUFBLEtBQUEsRUFBQTs7O0FENVdKLGtEQW1CYTtBQW5CYjs7QUFHQTtBQUdBOzs7Ozs7Ozs7OztBQWFNLElBQU8sdUNBQVAsTUFBTyxzQ0FBb0M7TUFvRGpDO01BQ0E7TUFwRFosbUJBQW1CO01BQ25CLGNBQWM7TUFFTDtNQUNBO01BQ0E7TUFDQSxxQkFBcUIsSUFBSSxNQUFLO01BQzlCO01BQ0E7TUFDQSx3QkFBd0IsSUFBSSxNQUFLO01BQ2pDLGtCQUFrQixJQUFJLE1BQUs7TUFDM0I7TUFDQTtNQUNBO01BR1Q7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLHlCQUF5QixJQUFJLE1BQUs7TUFDbEMsdUJBQXVCLElBQUksTUFBSztNQUNoQztNQUdBO01BR0E7TUFDQTtNQUNBO01BQ0E7TUFHQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BR0Esb0JBQW9CO01BRXBCLFlBQ1ksY0FDQSxrQkFBa0M7QUFEbEMsYUFBQSxlQUFBO0FBQ0EsYUFBQSxtQkFBQTtNQUNUO01BS0gsa0JBQWU7QUFDWCxhQUFLLDZCQUE0QjtBQUNqQyxnQkFBUSxLQUFLLFNBQVMsTUFBTTtVQUN4QixLQUFLLGlCQUFpQjtBQUNsQixpQkFBSyxvQkFBbUI7QUFDeEI7VUFDSixLQUFLLGlCQUFpQjtBQUNsQixpQkFBSyxpQkFBZ0I7QUFDckI7VUFDSixLQUFLLGlCQUFpQjtBQUNsQixpQkFBSyxpQkFBZ0I7QUFDckI7O01BRVo7TUFLQSxLQUFLLFNBQVk7QUFDYixhQUFLLGFBQWEsS0FBSyxTQUFTLEVBQUUsTUFBTSxLQUFJLENBQUU7TUFDbEQ7TUFLUSwrQkFBNEI7QUFDaEMsWUFBSSwwQkFBMEIsSUFBSSxNQUFLO0FBQ3ZDLG1CQUFXLFlBQVksS0FBSyxpQkFBaUIsQ0FBQSxHQUFJO0FBQzdDLGdCQUFNLGlCQUFpQjtBQUN2QixjQUFJLGVBQWUsT0FBTyxLQUFLLFNBQVMsSUFBSTtBQUN4QyxzQ0FBMEIsZUFBZTtBQUN6QyxpQkFBSywrQkFBK0IsZUFBZSxjQUFlLE9BQU8sQ0FBQyxXQUFXLE9BQU8sU0FBUyxFQUFFOzs7QUFJL0csWUFBSSxDQUFDLEtBQUssaUNBQWlDLENBQUMsS0FBSyw4QkFBOEIsWUFBWTtBQUN2Rjs7QUFFSixjQUFNLDBCQUEwQixLQUFLLDhCQUE4QjtBQUNuRSxjQUFNLHdCQUF3Qix3QkFBd0Isa0JBQWtCLFVBQVU7QUFDbEYsaUJBQVMsSUFBSSxHQUFHLElBQUksdUJBQXVCLEtBQUs7QUFDNUMsY0FBSSx3QkFBd0IsaUJBQWtCLENBQUMsRUFBRSxhQUFjLE9BQU8sS0FBSyxTQUFTLElBQUk7QUFDcEYsa0JBQU0saUNBQWlDLHdCQUF3QixpQkFBa0IsQ0FBQztBQUNsRixnQkFBSSwrQkFBK0Isb0JBQW9CLFFBQVc7QUFDOUQsbUJBQUsseUJBQXlCLENBQUE7QUFDOUIsbUJBQUssdUJBQXVCLENBQUE7bUJBQ3pCO0FBQ0gseUJBQVcsa0JBQWtCLCtCQUErQixpQkFBaUI7QUFDekUsMkJBQVcsdUJBQXVCLHlCQUF5QjtBQUN2RCxzQkFBSSxlQUFlLE9BQU8sb0JBQW9CLE1BQU0sb0JBQW9CLFdBQVc7QUFDL0UseUJBQUssdUJBQXVCLEtBQUssY0FBYzs2QkFDeEMsZUFBZSxPQUFPLG9CQUFvQixNQUFNLENBQUMsb0JBQW9CLFdBQVc7QUFDdkYseUJBQUsscUJBQXFCLEtBQUssY0FBYzs7Ozs7OztNQU96RTtNQUtRLHNCQUFtQjtBQUN2QixhQUFLLDZCQUE0QjtBQUNqQyxjQUFNLHNCQUFzQjtBQUM1QixjQUFNLGNBQWMsS0FBSztBQUN6QixhQUFLLGlCQUFpQixZQUFZLGdCQUFnQjtBQUNsRCxhQUFLLDhCQUE4QixZQUFZLGNBQWU7QUFDOUQsYUFBSyw2Q0FBNkMsS0FBSyx1QkFBdUI7QUFDOUUsYUFBSyxrQ0FBa0MsS0FBSyxxQkFBcUI7QUFDakUsYUFBSyxzQ0FBc0MsS0FBSywrQkFBK0IsS0FBSztBQUNwRixhQUFLLDhCQUNELEtBQUssOENBQThDLEtBQUssOEJBQThCLEtBQUssK0JBQStCLEtBQUs7QUFDbkksYUFBSyw4QkFBOEIsS0FBSyxrQ0FBa0MsS0FBSztBQUMvRSxhQUFLLDJCQUEyQixLQUFLLDhCQUE4QixLQUFLO0FBRXhFLFlBQUksS0FBSyxnQ0FBZ0MsR0FBRztBQUN4QyxlQUFLLGNBQWMsS0FBSyxpQkFBaUIsUUFBUSxzQkFBc0IsUUFBUTtlQUM1RTtBQUNILGVBQUssY0FBYyxLQUFLLGlCQUFpQixRQUFRLHNCQUFzQixTQUFTOztBQUdwRixZQUFJLEtBQUssZ0NBQWdDLEdBQUc7QUFDeEMsZUFBSyxjQUFjLEtBQUssaUJBQWlCLFFBQVEsc0JBQXNCLFFBQVE7ZUFDNUU7QUFDSCxlQUFLLGNBQWMsS0FBSyxpQkFBaUIsUUFBUSxzQkFBc0IsU0FBUzs7TUFFeEY7TUFLUSxtQkFBZ0I7QUFDcEIsY0FBTSxzQkFBc0I7QUFDNUIsYUFBSyx3QkFBd0IsS0FBSyxrQ0FBa0MsS0FBSztBQUV6RSxZQUFJLEtBQUssb0NBQW9DLEdBQUc7QUFDNUMsZUFBSyxXQUFXLEtBQUssaUJBQWlCLFFBQVEsc0JBQXNCLE1BQU07ZUFDdkU7QUFDSCxlQUFLLFdBQVcsS0FBSyxpQkFBaUIsUUFBUSxzQkFBc0IsT0FBTzs7QUFHL0UsWUFBSSxLQUFLLHNDQUFzQyxHQUFHO0FBQzlDLGVBQUssV0FBVyxLQUFLLGlCQUFpQixRQUFRLHNCQUFzQixNQUFNO2VBQ3ZFO0FBQ0gsZUFBSyxXQUFXLEtBQUssaUJBQWlCLFFBQVEsc0JBQXNCLE9BQU87O01BRW5GO01BS1EsbUJBQWdCO0FBQ3BCLGNBQU0sc0JBQXNCO0FBQzVCLGNBQU0sY0FBYyxLQUFLO0FBQ3pCLGFBQUssbUJBQW1CLFlBQVksTUFBTztBQUMzQyxhQUFLLDRCQUE0QixLQUFLLGdCQUFnQixPQUFPLENBQUMsV0FBVyxPQUFPLFNBQVMsRUFBRTtBQUMzRixhQUFLLDBCQUEwQixLQUFLLG1CQUFtQixLQUFLO0FBQzVELGFBQUssd0JBQXdCLEtBQUssNEJBQTRCLEtBQUs7QUFFbkUsWUFBSSxLQUFLLDhCQUE4QixHQUFHO0FBQ3RDLGVBQUssV0FBVyxLQUFLLGlCQUFpQixRQUFRLHNCQUFzQixTQUFTO2VBQzFFO0FBQ0gsZUFBSyxXQUFXLEtBQUssaUJBQWlCLFFBQVEsc0JBQXNCLFVBQVU7O0FBR2xGLFlBQUksS0FBSyw0QkFBNEIsR0FBRztBQUNwQyxlQUFLLFdBQVcsS0FBSyxpQkFBaUIsUUFBUSxzQkFBc0IsU0FBUztlQUMxRTtBQUNILGVBQUssV0FBVyxLQUFLLGlCQUFpQixRQUFRLHNCQUFzQixVQUFVOztNQUV0RjtNQUtRLCtCQUE0QjtBQUNoQyxjQUFNLHNCQUFzQjtBQUM1QixZQUFJLEtBQUssU0FBUyxXQUFXLEdBQUc7QUFDNUIsZUFBSyxnQkFBZ0IsS0FBSyxpQkFBaUIsUUFBUSxzQkFBc0IsT0FBTztlQUM3RTtBQUNILGVBQUssZ0JBQWdCLEtBQUssaUJBQWlCLFFBQVEsc0JBQXNCLFFBQVE7O0FBR3JGLFlBQUksS0FBSyxVQUFVLFFBQVc7QUFDMUIsZUFBSyxRQUFROztBQUdqQixZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ2xCLGVBQUssYUFBYSxLQUFLLGlCQUFpQixRQUFRLHNCQUFzQixPQUFPO2VBQzFFO0FBQ0gsZUFBSyxhQUFhLEtBQUssaUJBQWlCLFFBQVEsc0JBQXNCLFFBQVE7O01BRXRGOzt5QkF0TlMsdUNBQW9DLGdDQUFBLFlBQUEsR0FBQSxnQ0FBQSxtQkFBQSxDQUFBO01BQUE7aUVBQXBDLHVDQUFvQyxXQUFBLENBQUEsQ0FBQSxvQ0FBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLE9BQUEsU0FBQSxlQUFBLGlCQUFBLFVBQUEsWUFBQSxvQkFBQSxzQkFBQSxtQ0FBQSxxQ0FBQSxpQkFBQSxtQkFBQSx1QkFBQSx5QkFBQSxpQkFBQSxtQkFBQSxpQ0FBQSxtQ0FBQSwrQkFBQSxpQ0FBQSxlQUFBLGdCQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxzQkFBQSxFQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLGdCQUFBLHdEQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxjQUFBLFNBQUEsR0FBQSxhQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxPQUFBLGVBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLGdCQUFBLG1FQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLGdCQUFBLDRFQUFBLEdBQUEsQ0FBQSxnQkFBQSw2RUFBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxnQkFBQSxnRkFBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxnQkFBQSxtRUFBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxnQkFBQSw0RUFBQSxHQUFBLENBQUEsZ0JBQUEsNkVBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsZ0JBQUEsZ0ZBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsZ0JBQUEsMEVBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsZ0JBQUEsNkVBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsZ0JBQUEsMEVBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsZ0JBQUEsNkVBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsZ0JBQUEsbUVBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsZ0JBQUEsNEVBQUEsR0FBQSxDQUFBLGdCQUFBLDhEQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLGdCQUFBLG9EQUFBLEdBQUEsQ0FBQSxnQkFBQSxxREFBQSxHQUFBLENBQUEsZ0JBQUEsMkRBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsZ0JBQUEsMkRBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsZ0JBQUEsMEVBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsZ0JBQUEsbUZBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSw4Q0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7QUNuQmpELFVBQUEseUJBQUEsR0FBQSw2REFBQSxJQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUE7QUF5aUJBLFVBQUEscUJBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxVQUFBLENBQUE7QUFBb0IsVUFBQSx5QkFBQSxTQUFBLFNBQUEsd0VBQUE7QUFBQSxZQUFBLDRCQUFBLElBQUE7QUFBQSxrQkFBQSxNQUFBLDBCQUFBLENBQUE7QUFBQSxtQkFBUywwQkFBQSxJQUFBLEtBQUEsR0FBQSxDQUF3QjtVQUFBLENBQUE7QUFDakQsVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0osVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQUhpQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsOEJBQUEsR0FBQSxLQUFBLElBQUEsVUFBQSxJQUFBLFNBQUEsUUFBQSxJQUFBLFVBQUEsSUFBQSxTQUFBLE1BQUEsQ0FBQSxFQUF3SCxRQUFBLElBQUEsaUJBQUE7Ozs7O3FGRHhoQjVILHNDQUFvQyxFQUFBLFdBQUEsdUNBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFbkJqRCxTQUFTLGFBQUFDLFlBQVcsY0FBYyxTQUFBQyxRQUEwQixRQUFRLFdBQVcscUJBQUFDLDBCQUF5QjtBQUd4RyxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGlEQUFpRDtBQU0xRCxTQUFTLHFCQUFxQix1QkFBdUIsb0JBQUFDLG1CQUFrQixpQkFBaUI7Ozs7Ozs7O0FDSjVFLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUNLLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFBb0QsSUFBQSxxQkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTs7QUFBMEQsSUFBQSwyQkFBQSxFQUFPO0FBRTFJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsWUFBQTs7OztBQUhzQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxTQUFBLEVBQWtCLFFBQUEsSUFBQTtBQUFxQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsR0FBQSxpQ0FBQSxDQUFBOzs7Ozs7QUFLekUsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFDSyxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQWdELElBQUEscUJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7O0FBQXlELElBQUEsMkJBQUEsRUFBTztBQUVySSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLEdBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQWdDLElBQUEseUJBQUEsU0FBQSxTQUFBLCtFQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLHFCQUFBLGVBQUEsQ0FBcUM7SUFBQSxDQUFBO0FBQzFFLElBQUEscUJBQUEsRUFBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsWUFBQTs7OztBQVQwQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxtQkFBQTtBQUFtRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLElBQUEsR0FBQSxnQ0FBQSxDQUFBO0FBSzdELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsOEJBQUEsMEJBQUEsSUFBQSxHQUFBLCtCQUFBLEdBQUEsd0JBQUE7Ozs7O0FBWVosSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxZQUFBOzs7OztBQUlZLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7OztBQUptQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGNBQUEsSUFBQTtBQUNsQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxnQkFBQTs7Ozs7QUFLYixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7O0FBRFMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLFFBQUEsaUJBQUEsTUFBQSw0QkFBQTs7Ozs7QUFJTCxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7Ozs7QUFKc0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLElBQUE7QUFDckIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsbUJBQUE7Ozs7O0FBS2IsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQURTLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxRQUFBLGlCQUFBLGFBQUEsNEJBQUE7Ozs7O0FBbEJiLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsb0VBQUEsR0FBQSxDQUFBLEVBS0MsR0FBQSxvRUFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLElBQUEsb0NBQUE7QUFJRCxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsSUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxvRUFBQSxHQUFBLENBQUEsRUFLQyxJQUFBLHFFQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsSUFBQSxvQ0FBQTtBQUlMLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsWUFBQTs7OztBQXBCUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxTQUFBLE9BQUEsSUFBQSxFQUFBO0FBVUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsU0FBQSxlQUFBLE9BQUEsYUFBQSxJQUFBLEVBQUE7Ozs7O0FBWUosSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUFxQixJQUFBLDJCQUFBO0FBQy9CLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7OztBQUZjLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsT0FBQSxTQUFBLE1BQUE7Ozs7O0FBSVYsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQStCLElBQUEscUJBQUEsQ0FBQTtBQUFzQyxJQUFBLDJCQUFBO0FBQ3JFLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsc0NBQUEsRUFBQTtBQVNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7Ozs7QUFmdUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLDhCQUFBLElBQUFDLE9BQUEsT0FBQSxTQUFBLEtBQUEsT0FBQSxTQUFBLE1BQUEsQ0FBQTtBQUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsSUFBQSxPQUFBLFNBQUEsR0FBQSxLQUFBLE9BQUEsU0FBQSxRQUFBLEVBQUE7QUFHdkIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxTQUFBLE9BQUEsS0FBQSxFQUFlLFlBQUEsT0FBQSxRQUFBLEVBQUEsc0JBQUEsT0FBQSxRQUFBLEVBQUEsbUNBQUEsT0FBQSxhQUFBLEVBQUEscUNBQUEsT0FBQSx5QkFBQSxFQUFBLG1CQUFBLE9BQUEsZUFBQSxFQUFBLGlCQUFBLE9BQUEsYUFBQTs7Ozs7QUFjbkIsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7Ozs7QUFFSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7Ozs7QUFJWSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQXFDLElBQUEseUJBQUEsU0FBQSxTQUFBLHdHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsbUJBQUEsQ0FBb0I7SUFBQSxDQUFBO0FBQzlELElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLHNDQUFBLDBCQUFBLEdBQUEsR0FBQSw0Q0FBQSxHQUFBLGdDQUFBOzs7Ozs7QUFJSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQXFDLElBQUEseUJBQUEsU0FBQSxTQUFBLHdHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsbUJBQUEsQ0FBb0I7SUFBQSxDQUFBO0FBQzlELElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLHNDQUFBLDBCQUFBLEdBQUEsR0FBQSw0Q0FBQSxHQUFBLGdDQUFBOzs7OztBQVJaLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLGtGQUFBLEdBQUEsQ0FBQSxFQUlDLEdBQUEsa0ZBQUEsR0FBQSxDQUFBO0FBTUwsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQVhRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxDQUFBLFFBQUEsd0JBQUEsSUFBQSxFQUFBO0FBS0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsd0JBQUEsSUFBQSxFQUFBOzs7OztBQWRaLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsb0VBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSxvRUFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLG9FQUFBLEdBQUEsQ0FBQTtBQWtCTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFlBQUE7Ozs7QUFyQlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsd0JBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsT0FBQSx3QkFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxjQUFBLENBQUEsT0FBQSxzQkFBQSxJQUFBLEVBQUE7Ozs7OztBQW1CSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEscUJBQUEsRUFBQTtBQUVJLElBQUEseUJBQUEscUJBQUEsU0FBQSxvR0FBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBcUIsMEJBQUEsUUFBQSxjQUFBLE1BQUEsQ0FBcUI7SUFBQSxDQUFBO0FBQzdDLElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUFIUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsT0FBQSxpQkFBQSxJQUFBLE9BQUEsU0FBQSxrQkFBQSxLQUFBLE9BQUEsU0FBQSxrQkFBQTs7Ozs7O0FBMEJnQixJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsaUJBQUEsRUFBQTtBQUNJLElBQUEseUJBQUEsYUFBQSxTQUFBLDhHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFhLDBCQUFBLFFBQUEsS0FBQSxDQUFNO0lBQUEsQ0FBQSxFQUFDLFdBQUEsU0FBQSw0R0FBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFDVCwwQkFBQSxRQUFBLEtBQUEsQ0FBTTtJQUFBLENBQUE7QUFLcEIsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSx3Q0FBQTs7Ozs7QUFMUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsUUFBQSx3QkFBQSxnQkFBQSxDQUFBLEVBQW1ELGlCQUFBLFFBQUEsYUFBQSxFQUFBLFlBQUEsTUFBQSxFQUFBLG9CQUFBLFFBQUEsZ0JBQUE7Ozs7OztBQXJCL0QsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQVVJLElBQUEseUJBQUEsc0JBQUEsU0FBQSw2RkFBQSxRQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLG1CQUFBLFlBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQXNCLDBCQUFBLFFBQUEsV0FBQSxrQkFBQSxNQUFBLENBQWdDO0lBQUEsQ0FBQSxFQUFDLGVBQUEsU0FBQSxzRkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUN4QywwQkFBQSxRQUFBLGVBQUEsTUFBQSxDQUFzQjtJQUFBLENBQUEsRUFEa0IsY0FBQSxTQUFBLHFGQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBRXpDLDBCQUFBLFFBQUEsZUFBQSxNQUFBLENBQXNCO0lBQUEsQ0FBQSxFQUZtQixlQUFBLFNBQUEsc0ZBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFHeEMsMEJBQUEsUUFBQSxlQUFBLE1BQUEsQ0FBc0I7SUFBQSxDQUFBO0FBSXJDLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwwRUFBQSxHQUFBLENBQUE7QUFVSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7OztBQXpCUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsUUFBQSxjQUFBLGlCQUFBLEVBQUEsRUFBNkMsV0FBQSw4QkFBQSxHQUFBQyxNQUFBLGlCQUFBLE9BQUEsSUFBQSxLQUFBLGlCQUFBLE9BQUEsSUFBQSxLQUFBLGlCQUFBLFFBQUEsSUFBQSxLQUFBLGlCQUFBLFNBQUEsSUFBQSxHQUFBLENBQUEsRUFBQSw2QkFBQSxFQUFBO0FBYzdDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLHdCQUFBLGdCQUFBLElBQUEsSUFBQSxFQUFBOzs7OztBQW5CWixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsK0JBQUEsR0FBQSw0REFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBO0FBOEJKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUEvQlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxPQUFBLFNBQUEsYUFBQTs7Ozs7QUEwRGdCLElBQUEscUJBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0Q0FBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxxQkFBQTs7Ozs7QUFLVCxJQUFBLHFCQUFBLEdBQUEsb0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdEQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSxvREFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLG9EQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnREFBQTs7Ozs7QUFFSSxJQUFBLHFCQUFBLEdBQUEsb0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBS0osSUFBQSxxQkFBQSxHQUFBLGdEQUFBOzs7O0FBRlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsZ0JBQUE7Ozs7O0FBS1IsSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLGlCQUFBLEVBQUE7QUFNQSxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRDQUFBOzs7OztBQU5RLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxRQUFBLHdCQUFBLGdCQUFBLENBQUEsRUFBbUQsaUJBQUEsSUFBQSxFQUFBLFlBQUEsTUFBQSxFQUFBLG9CQUFBLFFBQUEsZ0JBQUE7Ozs7O0FBUXZELElBQUEscUJBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNENBQUE7Ozs7O0FBMURSLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQWdCSSxJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsMEVBQUEsR0FBQSxDQUFBO0FBVUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwwRUFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLDBFQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsMkVBQUEsR0FBQSxDQUFBLEVBQUEsSUFBQSwyRUFBQSxHQUFBLENBQUE7QUFjTCxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLDRDQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDJFQUFBLEdBQUEsQ0FBQSxFQVFDLElBQUEsMkVBQUEsR0FBQSxDQUFBO0FBTUwsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0NBQUE7Ozs7O0FBMURZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSw4QkFBQSxHQUFBRCxNQUFBLFFBQUEsa0JBQUEsZ0JBQUEsTUFBQSxRQUFBLGNBQUEsb0JBQUEsQ0FBQSxpQkFBQSxXQUFBLENBQUEsUUFBQSwrQkFBQSxnQkFBQSxLQUFBLENBQUEsUUFBQSxTQUFBLE9BQUEsQ0FBQSxFQU1FLFdBQUEsOEJBQUEsSUFBQUMsTUFBQSxpQkFBQSxPQUFBLElBQUEsS0FBQSxpQkFBQSxPQUFBLElBQUEsS0FBQSxpQkFBQSxRQUFBLElBQUEsS0FBQSxpQkFBQSxTQUFBLElBQUEsR0FBQSxDQUFBO0FBUUYsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsa0JBQUEsZ0JBQUEsTUFBQSxRQUFBLGNBQUEsb0JBQUEsQ0FBQSxpQkFBQSxXQUFBLENBQUEsUUFBQSwrQkFBQSxnQkFBQSxLQUFBLENBQUEsUUFBQSxTQUFBLFVBQUEsSUFBQSxFQUFBO0FBV0ksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLGlCQUFBLFdBQUEsQ0FBQSxRQUFBLCtCQUFBLGdCQUFBLEtBQUEsQ0FBQSxRQUFBLFNBQUEsVUFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxpQkFBQSxXQUFBLFFBQUEsK0JBQUEsZ0JBQUEsS0FBQSxDQUFBLFFBQUEsU0FBQSxVQUFBLElBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxpQkFBQSxXQUFBLFFBQUEsK0JBQUEsZ0JBQUEsS0FBQSxRQUFBLFNBQUEsVUFBQSxLQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsaUJBQUEsV0FBQSxRQUFBLFNBQUEsV0FBQSxRQUFBLCtCQUFBLGdCQUFBLElBQUEsS0FBQSxFQUFBO0FBUUosSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsd0JBQUEsZ0JBQUEsSUFBQSxLQUFBLEVBQUE7QUFTQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsQ0FBQSxRQUFBLHdCQUFBLGdCQUFBLElBQUEsS0FBQSxFQUFBOzs7OztBQXhEaEIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEsNERBQUEsSUFBQSxJQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQStESixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBaEVRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsT0FBQSxTQUFBLGFBQUE7Ozs7O0FBNEZnQixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9EQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNENBQUE7Ozs7QUFGaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEscUJBQUE7Ozs7O0FBS1QsSUFBQSxxQkFBQSxHQUFBLG9EQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnREFBQTs7Ozs7QUFFSSxJQUFBLHFCQUFBLEdBQUEsb0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdEQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSxvREFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFLSixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7Ozs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxnQkFBQTs7Ozs7QUFLUixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsaUJBQUEsRUFBQTtBQU1KLElBQUEscUJBQUEsR0FBQSw0Q0FBQTs7Ozs7QUFMUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsUUFBQSwrQkFBQSxnQkFBQSxDQUFBLEVBQTBELGlCQUFBLElBQUEsRUFBQSxZQUFBLE1BQUEsRUFBQSxvQkFBQSxRQUFBLGdCQUFBOzs7OztBQU85RCxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9EQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLEtBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRDQUFBOzs7OztBQXZEUixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFnQkksSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDBFQUFBLEdBQUEsQ0FBQTtBQVdBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsMEVBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSwwRUFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLDJFQUFBLEdBQUEsQ0FBQTtBQVdMLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsNENBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsMkVBQUEsR0FBQSxDQUFBLEVBT0MsSUFBQSwyRUFBQSxHQUFBLENBQUE7QUFNTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQ0FBQTs7Ozs7QUF2RFksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLDhCQUFBLEdBQUFELE1BQUEsUUFBQSxrQkFBQSxnQkFBQSxNQUFBLFFBQUEsY0FBQSxvQkFBQSxDQUFBLGlCQUFBLFdBQUEsQ0FBQSxRQUFBLCtCQUFBLGdCQUFBLEtBQUEsQ0FBQSxRQUFBLFNBQUEsT0FBQSxDQUFBLEVBTUUsV0FBQSw4QkFBQSxJQUFBQyxNQUFBLGlCQUFBLE9BQUEsSUFBQSxLQUFBLGlCQUFBLE9BQUEsSUFBQSxLQUFBLGlCQUFBLFFBQUEsSUFBQSxLQUFBLGlCQUFBLFNBQUEsSUFBQSxHQUFBLENBQUE7QUFRRixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxrQkFBQSxnQkFBQSxNQUFBLFFBQUEsY0FBQSxvQkFBQSxDQUFBLGlCQUFBLFdBQUEsQ0FBQSxRQUFBLCtCQUFBLGdCQUFBLEtBQUEsQ0FBQSxRQUFBLFNBQUEsV0FBQSxDQUFBLFFBQUEsc0JBQUEsSUFBQSxFQUFBO0FBWUksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLGlCQUFBLFdBQUEsQ0FBQSxRQUFBLCtCQUFBLGdCQUFBLEtBQUEsQ0FBQSxRQUFBLFNBQUEsVUFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsaUJBQUEsV0FBQSxRQUFBLCtCQUFBLGdCQUFBLEtBQUEsUUFBQSxTQUFBLFVBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLGlCQUFBLFdBQUEsUUFBQSxTQUFBLFVBQUEsS0FBQSxFQUFBO0FBUUosSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLG9CQUFBLFFBQUEsK0JBQUEsZ0JBQUEsS0FBQSxDQUFBLGlCQUFBLFdBQUEsQ0FBQSxRQUFBLFNBQUEsVUFBQSxLQUFBLEVBQUE7QUFRQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsQ0FBQSxvQkFBQSxDQUFBLFFBQUEsK0JBQUEsZ0JBQUEsSUFBQSxLQUFBLEVBQUE7Ozs7O0FBckRoQixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsK0JBQUEsR0FBQSw0REFBQSxJQUFBLElBQUEsTUFBQSxNQUFBLHVDQUFBO0FBNERKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUE3RFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFNBQUEsYUFBQTs7Ozs7QUFrRVIsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxLQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7Ozs7QUFjWSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsaUJBQUEsRUFBQTtBQUVJLElBQUEseUJBQUEsYUFBQSxTQUFBLGdHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFhLDBCQUFBLFFBQUEsS0FBQSxDQUFNO0lBQUEsQ0FBQSxFQUFDLFdBQUEsU0FBQSw4RkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFDVCwwQkFBQSxRQUFBLEtBQUEsQ0FBTTtJQUFBLENBQUE7QUFLcEIsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7Ozs7O0FBUlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxxQ0FBQSxNQUFBLGNBQUEsT0FBQSxFQUFBO0FBR0EsSUFBQSx5QkFBQSxZQUFBLFlBQUEsRUFBcUIsaUJBQUEsUUFBQSxhQUFBLEVBQUEsWUFBQSxLQUFBLEVBQUEsb0JBQUEsUUFBQSxnQkFBQTs7Ozs7O0FBaEJqQyxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBSUksSUFBQSx5QkFBQSxzQkFBQSxTQUFBLHVGQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUFzQiwwQkFBQSxRQUFBLFdBQVcsUUFBUyxNQUFBLENBQVM7SUFBQSxDQUFBLEVBQUMsZUFBQSxTQUFBLGdGQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUNyQywwQkFBQSxRQUFBLGVBQUEsTUFBQSxDQUFzQjtJQUFBLENBQUEsRUFEZSxjQUFBLFNBQUEsK0VBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBRXRDLDBCQUFBLFFBQUEsZUFBQSxNQUFBLENBQXNCO0lBQUEsQ0FBQSxFQUZnQixlQUFBLFNBQUEsZ0ZBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBR3JDLDBCQUFBLFFBQUEsZUFBQSxNQUFBLENBQXNCO0lBQUEsQ0FBQTtBQUlyQyxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEsNERBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQVdKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUFwQlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLFFBQUEsY0FBQSxpQkFBQSxFQUFBLEVBQTZDLDZCQUFBLEVBQUE7QUFRN0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLHVCQUFBLENBQUE7OztBRDlTeEIsc0JBMkJLLGVBWVE7QUF2Q2I7O0FBQ0E7QUFDQTtBQUdBO0FBRUE7QUFDQTs7Ozs7Ozs7Ozs7QUFPQSxhQUFTO01BRUwsNEJBQTRCO0tBQy9CO0FBT0QsV0FBTyxpQkFBaUIsYUFBYSxNQUFLO0lBQUUsR0FBRyxFQUFFLFNBQVMsTUFBSyxDQUFFO0FBRWpFLEtBQUEsU0FBS0MsZ0JBQWE7QUFDZCxNQUFBQSxlQUFBQSxlQUFBLGdCQUFBLElBQUEsQ0FBQSxJQUFBO0FBQ0EsTUFBQUEsZUFBQUEsZUFBQSxrQkFBQSxJQUFBLENBQUEsSUFBQTtBQUNBLE1BQUFBLGVBQUFBLGVBQUEsWUFBQSxJQUFBLENBQUEsSUFBQTtJQUNKLEdBSkssa0JBQUEsZ0JBQWEsQ0FBQSxFQUFBO0FBWVosSUFBTywrQkFBUCxNQUFPLDhCQUE0QjtNQWdFekI7TUFDQTtNQTlEWjtNQUVBO01BQ0E7TUFFQSxJQUNJLFNBQVMsVUFBUTtBQUNqQixhQUFLLFlBQVk7QUFDakIsYUFBSyxnQkFBZTtNQUN4QjtNQUNBLElBQUksV0FBUTtBQUNSLGVBQU8sS0FBSztNQUNoQjtNQUdBO01BRUE7TUFFQTtNQUVBO01BRUE7TUFDQSxJQUNJLG9CQUFvQixxQkFBbUI7QUFDdkMsYUFBSyx1QkFBdUI7QUFDNUIsWUFBSSxLQUFLLHFCQUFxQjtBQUMxQixlQUFLLG1CQUFrQjs7TUFFL0I7TUFDQSxJQUFJLHNCQUFtQjtBQUNuQixlQUFPLEtBQUs7TUFDaEI7TUFFQTtNQUVBLG1CQUF3QyxvQkFBSSxJQUFHO01BRy9DLGlCQUFpQixJQUFJLGFBQVk7TUFFakMsd0JBQXdCO01BQ3hCO01BQ0EseUJBQXlCLElBQUksTUFBSztNQUNsQyxjQUFjO01BQ2Q7TUFDQTtNQUNBO01BRVMsZ0JBQWdCO01BRXpCLGVBQWU7TUFHZixZQUFZO01BQ1osbUJBQW1CSDtNQUNuQix3QkFBd0I7TUFDeEIsc0JBQXNCO01BRXRCLFlBQ1ksaUJBQ0EseUJBQWdEO0FBRGhELGFBQUEsa0JBQUE7QUFDQSxhQUFBLDBCQUFBO01BQ1Q7TUFFSCxXQUFRO0FBQ0osYUFBSyxzQkFBcUI7TUFDOUI7TUFFQSxjQUFXO0FBQ1AsYUFBSyxzQkFBcUI7TUFDOUI7TUFFQSxrQkFBZTtBQUVYLGFBQUssbUJBQW1CLElBQUksb0NBQW1DO0FBQy9ELGFBQUssaUJBQWlCLE9BQU8sS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssU0FBUyxJQUFJO0FBQ3hGLGFBQUssaUJBQWlCLE9BQU8sS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssU0FBUyxJQUFJO0FBQ3hGLGFBQUssaUJBQWlCLGNBQWMsS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssU0FBUyxXQUFXO01BQzFHO01BS0EsT0FBSTtBQUNBLGFBQUssY0FBYztNQUN2QjtNQUtBLE9BQUk7QUFDQSxhQUFLLGNBQWM7TUFDdkI7TUFNQSxjQUFjLE9BQWE7QUFDdkIsYUFBSyxlQUFlO01BQ3hCO01BTUEsZUFBZSxPQUFVO0FBQ3JCLGNBQU0sV0FBVyxlQUFjO0FBQy9CLGVBQU87TUFDWDtNQVNBLFdBQVcsY0FBd0MsV0FBMEM7QUFDekYsYUFBSyxLQUFJO0FBQ1QsY0FBTSxXQUFXLFVBQVUsS0FBSztBQUVoQyxZQUFJLGNBQWM7QUFFZCxjQUFJLEtBQUssd0JBQXdCLGlCQUFpQixLQUFLLFVBQVUsVUFBVSxZQUFZLEdBQUc7QUFFdEY7O0FBSUosY0FBSTtBQUNKLGNBQUk7QUFDSixlQUFLLFdBQVcsS0FBSyxTQUFTLE9BQU8sU0FBVSxTQUFPO0FBQ2xELGdCQUFJLEtBQUssd0JBQXdCLHVCQUF1QixjQUFjLFFBQVEsWUFBWSxHQUFHO0FBQ3pGLDRCQUFjLFFBQVE7QUFDdEIscUJBQU87O0FBRVgsZ0JBQUksS0FBSyx3QkFBd0IsdUJBQXVCLFVBQVUsUUFBUSxRQUFRLEdBQUc7QUFDakYsZ0NBQWtCLFFBQVE7QUFDMUIscUJBQU87O0FBRVgsbUJBQU87VUFDWCxHQUFHLElBQUk7QUFHUCxlQUFLLFNBQVMsS0FBSyxJQUFJLG1CQUFtQixVQUFVLFlBQVksQ0FBQztBQUlqRSxjQUFJLGVBQWUsaUJBQWlCO0FBQ2hDLGlCQUFLLFNBQVMsS0FBSyxJQUFJLG1CQUFtQixhQUFhLGVBQWUsQ0FBQzs7ZUFFeEU7QUFDSCxnQkFBTSxlQUFlLEtBQUssU0FBUztBQUVuQyxlQUFLLFdBQVcsS0FBSyxTQUFTLE9BQU8sU0FBVSxTQUFPO0FBQ2xELG1CQUFPLENBQUMsS0FBSyx3QkFBd0IsdUJBQXVCLFFBQVEsVUFBVSxRQUFRO1VBQzFGLEdBQUcsSUFBSTtBQUNQLGNBQUksS0FBSyxTQUFTLFdBQVcsY0FBYztBQUV2Qzs7O0FBSVIsYUFBSyxlQUFlLEtBQUssS0FBSyxRQUFRO0FBRXRDLFlBQUksS0FBSyxpQkFBaUI7QUFDdEIsZUFBSyxnQkFBZTs7TUFFNUI7TUFRQSx3QkFBd0IsY0FBMEI7QUFDOUMsWUFBSSxLQUFLLFVBQVU7QUFDZixnQkFBTSxVQUFVLEtBQUssU0FBUyxLQUFLLENBQUMsaUJBQWlCLEtBQUssd0JBQXdCLHVCQUF1QixhQUFhLGNBQWMsWUFBWSxDQUFDO0FBQ2pKLGNBQUksU0FBUztBQUNULG1CQUFPLFFBQVE7aUJBQ1o7QUFDSCxtQkFBTzs7O0FBR2YsZUFBTztNQUNYO01BRUEsK0JBQStCLGNBQTBCO0FBQ3JELGNBQU0sT0FBTyxLQUFLLHdCQUF3QixZQUFZO0FBQ3RELGVBQU8sT0FBTyxLQUFLLFVBQVU7TUFDakM7TUFPQSx5QkFBc0I7QUFDbEIsZUFBTyxLQUFLLFNBQVMsV0FBVyxPQUFPLENBQUMsYUFBWTtBQUNoRCxpQkFDSSxDQUFDLEtBQUssVUFBVSxLQUFLLENBQUMsWUFBVztBQUM3QixtQkFBTyxLQUFLLHdCQUF3Qix1QkFBdUIsUUFBUSxVQUFVLFFBQVE7VUFDekYsR0FBRyxJQUFJO1FBRWYsR0FBRyxJQUFJO01BQ1g7TUFTQSxrQkFBa0IsY0FBMEI7QUFDeEMsWUFBSSxDQUFDLEtBQUssU0FBUyxpQkFBaUI7QUFDaEMsaUJBQU8sY0FBYzs7QUFFekIsY0FBTSxpQkFBaUIsS0FBSyxTQUFTLGdCQUNoQyxPQUFPLFNBQVUsU0FBTztBQUNyQixpQkFBTyxLQUFLLHdCQUF3Qix1QkFBdUIsUUFBUSxjQUFjLFlBQVk7UUFDakcsR0FBRyxJQUFJLEVBQ04sSUFBSSxTQUFVLFNBQU87QUFDbEIsaUJBQU8sUUFBUTtRQUNuQixDQUFDO0FBQ0wsY0FBTSxlQUFlLEtBQUssd0JBQXdCLFlBQVk7QUFFOUQsWUFBSSxDQUFDLGNBQWM7QUFDZixpQkFBTyxlQUFlLFdBQVcsSUFBSSxjQUFjLGFBQWEsY0FBYztlQUMzRTtBQUNILGlCQUFPLGVBQWUsS0FBSyxTQUFVLFVBQVE7QUFDekMsbUJBQU8sS0FBSyx3QkFBd0IsdUJBQXVCLFVBQVUsWUFBWTtVQUNyRixHQUFHLElBQUksSUFDRCxjQUFjLGlCQUNkLGNBQWM7O01BRTVCO01BVUEsbUJBQW1CLGNBQTBCO0FBQ3pDLFlBQUksQ0FBQyxLQUFLLFNBQVMsaUJBQWlCO0FBQ2hDLGlCQUFPOztBQUVYLGVBQU8sS0FBSyxTQUFTLGdCQUFnQixLQUFLLENBQUMsWUFBWSxLQUFLLHdCQUF3Qix1QkFBdUIsY0FBYyxRQUFRLFlBQVksQ0FBQztNQUNsSjtNQUtBLHFCQUFrQjtBQUNkLGFBQUsseUJBQXlCLEtBQUssd0JBQXdCLE1BQU0sS0FBSyxVQUFVLEtBQUssUUFBUTtBQUM3RixhQUFLLHdCQUF3QjtNQUNqQztNQUtBLHFCQUFrQjtBQUNkLGFBQUssd0JBQXdCO01BQ2pDO01BUUEsK0JBQStCLGNBQTBCO0FBQ3JELGNBQU0sMEJBQTBCLEtBQUs7QUFDckMsY0FBTSxVQUFVLEtBQUssdUJBQXVCLEtBQUssU0FBVSxpQkFBZTtBQUN0RSxpQkFBTyx3QkFBd0IsdUJBQXVCLGdCQUFnQixjQUFjLFlBQVk7UUFDcEcsQ0FBQztBQUNELGVBQU8sU0FBUztNQUNwQjtNQU1BLHdCQUFxQjtBQUNqQixZQUFJLEtBQUssU0FBUyxlQUFlO0FBQzdCLGVBQUssZ0JBQWdCLEtBQUssU0FBUyxjQUFjLE9BQU8sQ0FBQyxpQkFBaUIsS0FBSyxrQkFBa0IsWUFBWSxNQUFNLGNBQWMsY0FBYyxFQUFFO0FBQ2pKLGVBQUssNEJBQTRCLEtBQUssU0FBUyxjQUFjLE9BQU8sQ0FBQyxpQkFBaUIsS0FBSyxrQkFBa0IsWUFBWSxNQUFNLGNBQWMsZ0JBQWdCLEVBQUU7QUFDL0osZUFBSyxrQkFBa0IsS0FBSyxTQUFTLGNBQWMsT0FBTyxDQUFDLGlCQUFpQixLQUFLLG1CQUFtQixZQUFZLENBQUMsRUFBRTs7TUFFM0g7O3lCQTFTUywrQkFBNEIsZ0NBQUEsc0JBQUEsR0FBQSxnQ0FBQSx1QkFBQSxDQUFBO01BQUE7aUVBQTVCLCtCQUE0QixXQUFBLENBQUEsQ0FBQSw0QkFBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLG1DQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO29DQUUxQix1QkFBcUIsQ0FBQTs7Ozs7OzRYQU5yQixDQUFDLHVCQUF1QixDQUFDLEdBQUEsa0NBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsZ0JBQUEsb0JBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsd0JBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsb0JBQUEsSUFBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEscUJBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsZUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGdCQUFBLHVDQUFBLEdBQUEsU0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLGdCQUFBLEVBQUEsR0FBQSxDQUFBLHVCQUFBLEVBQUEsR0FBQSxDQUFBLFlBQUEseUJBQUEsR0FBQSxTQUFBLGNBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxnQkFBQSw4QkFBQSxHQUFBLENBQUEsWUFBQSx5QkFBQSxHQUFBLFNBQUEsaUJBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxnQkFBQSxxQ0FBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsZ0JBQUEsaUNBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLFVBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxnQkFBQSxxQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxZQUFBLHNCQUFBLG1DQUFBLHFDQUFBLG1CQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLGdCQUFBLHNEQUFBLEdBQUEsQ0FBQSxnQkFBQSxrREFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxPQUFBLG1CQUFBLEdBQUEsQ0FBQSxNQUFBLGlCQUFBLGVBQUEsSUFBQSxHQUFBLGlCQUFBLEdBQUEsV0FBQSxXQUFBLDZCQUFBLHNCQUFBLGVBQUEsY0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsaUJBQUEsWUFBQSxvQkFBQSxhQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsV0FBQSxHQUFBLFdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxHQUFBLFdBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSxxREFBQSxHQUFBLENBQUEsZ0JBQUEsaURBQUEsR0FBQSxDQUFBLGdCQUFBLGlDQUFBLEdBQUEsQ0FBQSxjQUFBLDhFQUFBLEdBQUEsU0FBQSxTQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGlCQUFBLFlBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLGtCQUFBLEdBQUEsV0FBQSxTQUFBLEdBQUEsQ0FBQSxnQkFBQSxvREFBQSxHQUFBLENBQUEsTUFBQSxjQUFBLGVBQUEsSUFBQSxHQUFBLGNBQUEsR0FBQSxXQUFBLDZCQUFBLHNCQUFBLGVBQUEsY0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsWUFBQSxpQkFBQSxZQUFBLG9CQUFBLGFBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHNDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDbkN4QyxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBSUksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLEdBQUEscURBQUEsSUFBQSxDQUFBLEVBTUMsR0FBQSxxREFBQSxJQUFBLENBQUE7QUFlTCxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFBTSxVQUFBLHFCQUFBLEVBQUE7QUFBb0IsVUFBQSwyQkFBQTtBQUFRLFVBQUEscUJBQUEsRUFBQTtBQUN0QyxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsS0FBQSxDQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsc0RBQUEsR0FBQSxDQUFBLEVBRUMsSUFBQSxzREFBQSxJQUFBLENBQUEsRUFBQSxJQUFBLHNEQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsc0RBQUEsSUFBQSxFQUFBLEVBQUEsSUFBQSxzREFBQSxHQUFBLENBQUE7QUF1RUQsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsc0RBQUEsR0FBQSxDQUFBO0FBTUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxzREFBQSxHQUFBLENBQUEsRUFpQ0MsSUFBQSxzREFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLHNEQUFBLEdBQUEsQ0FBQTtBQW9JTCxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsc0RBQUEsR0FBQSxDQUFBLEVBSUMsSUFBQSxzREFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLHNEQUFBLEdBQUEsQ0FBQTtBQTZCTCxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQTdUSSxVQUFBLHlCQUFBLFdBQUEsOEJBQUEsSUFBQUksTUFBQSxJQUFBLGlCQUFBLENBQUEsSUFBQSxZQUFBLElBQUEsY0FBQSxDQUFBLElBQUEsc0JBQUEsSUFBQSxTQUFBLEtBQUEsSUFBQSxTQUFBLFVBQUEsQ0FBQSxJQUFBLG1CQUFBLENBQUE7QUFFSyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFVBQUEsSUFBQSxpQkFBQSxTQUFBO0FBQ0QsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsaUJBQUEsVUFBQSxJQUFBLEVBQUE7QUFPQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxpQkFBQSxVQUFBLElBQUEsRUFBQTtBQWVDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsVUFBQSxJQUFBLGlCQUFBLFNBQUE7QUFFUyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLElBQUEsSUFBQSxlQUFBLEdBQUE7QUFBNEIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSxLQUFBLElBQUEsU0FBQSxPQUFBLFlBQUE7QUFFbkMsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxhQUFBLElBQUEsaUJBQUEsTUFBQSw0QkFBQTtBQUNILFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLFNBQUEsVUFBQSxLQUFBLEVBQUE7QUFHQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxTQUFBLFFBQUEsSUFBQSxTQUFBLGVBQUEsSUFBQSxhQUFBLEtBQUEsRUFBQTtBQXVCQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLGNBQUEsSUFBQSxzQkFBQSxLQUFBLEVBQUE7QUFNQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxjQUFBLENBQUEsSUFBQSxzQkFBQSxLQUFBLEVBQUE7QUFpQkEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsYUFBQSxLQUFBLEVBQUE7QUEwQlEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsU0FBQSxxQkFBQSxLQUFBLEVBQUE7QUFPSSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLGFBQUEsS0FBQSxFQUFBO0FBa0NBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLGNBQUEsQ0FBQSxJQUFBLHlCQUFBLElBQUEsU0FBQSxnQkFBQSxLQUFBLEVBQUE7QUFtRUEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsY0FBQSxJQUFBLHdCQUFBLEtBQUEsRUFBQTtBQW1FSixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLGFBQUEsS0FBQSxFQUFBO0FBS0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsYUFBQSxLQUFBLEVBQUE7QUFHQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLGFBQUEsS0FBQSxFQUFBOzs7OztxRkQzUEgsOEJBQTRCLEVBQUEsV0FBQSwrQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUV2Q3pDLFNBQVMsYUFBQUMsWUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFPLFVBQUFDLFNBQVEscUJBQUFDLDBCQUF5QjtBQU0xRSxTQUFTLHVCQUFBQyxzQkFBcUIseUJBQUFDLHdCQUF1QixvQkFBQUMseUJBQXdCO0FBQzdFLFNBQVMsZUFBZSxVQUFVLGFBQWEsZ0JBQWdCOzs7Ozs7O0FDRXZELElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHFCQUFBLENBQUE7O0FBQTZELElBQUEsMkJBQUE7QUFDckUsSUFBQSxxQkFBQSxHQUFBLFFBQUE7OztBQURRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLG9DQUFBLENBQUE7Ozs7O0FBR0osSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEscUJBQUEsQ0FBQTs7QUFBK0QsSUFBQSwyQkFBQTtBQUN2RSxJQUFBLHFCQUFBLEdBQUEsUUFBQTs7O0FBRFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsc0NBQUEsQ0FBQTs7Ozs7QUFLSSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBRFMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLE9BQUEsaUJBQUEsTUFBQSw0QkFBQTs7Ozs7QUFHTCxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7Ozs7QUFKbUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLEdBQUE7QUFDbEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsZ0JBQUE7Ozs7O0FBTWIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQURTLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxRQUFBLGlCQUFBLGFBQUEsNEJBQUE7Ozs7O0FBR0wsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7Ozs7O0FBSnNDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSxJQUFBO0FBQ3JCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLG1CQUFBOzs7OztBQWhCckIsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLHVFQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsR0FBQSxvQ0FBQTtBQUdBLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx1RUFBQSxHQUFBLENBQUE7QUFNQSxJQUFBLHdCQUFBLEdBQUEsSUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx1RUFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUE7QUFHQSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsd0VBQUEsR0FBQSxDQUFBO0FBTUosSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBOzs7O0FBakJRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLFNBQUEsT0FBQSxJQUFBLEVBQUE7QUFVQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxTQUFBLGVBQUEsT0FBQSxhQUFBLEtBQUEsRUFBQTs7Ozs7QUFTSixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBcUIsSUFBQSwyQkFBQTtBQUMvQixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQUZjLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsT0FBQSxTQUFBLE1BQUE7Ozs7O0FBSVYsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBK0IsSUFBQSxxQkFBQSxDQUFBO0FBQXNDLElBQUEsMkJBQUE7QUFDckUsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxzQ0FBQSxFQUFBO0FBUUosSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBOzs7O0FBZHVDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSw4QkFBQSxHQUFBQyxPQUFBLE9BQUEsU0FBQSxLQUFBLE9BQUEsU0FBQSxNQUFBLENBQUE7QUFFQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLElBQUEsT0FBQSxTQUFBLEdBQUEsS0FBQSxPQUFBLFNBQUEsUUFBQSxFQUFBO0FBR3ZCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsU0FBQSxPQUFBLEtBQUEsRUFBZSxZQUFBLE9BQUEsUUFBQSxFQUFBLHlCQUFBLE9BQUEscUJBQUEsRUFBQSxpQkFBQSxPQUFBLGFBQUEsRUFBQSxpQ0FBQSxPQUFBLGVBQUEsRUFBQSxpQkFBQSxPQUFBLGFBQUE7Ozs7O0FBdUJILElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxPQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7OztBQURTLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSxVQUFBLFFBQUEsaUJBQUEsb0JBQUEsS0FBQSxLQUFBLE9BQUEsT0FBQSxRQUFBLGlCQUFBLG9CQUFBLEtBQUEsRUFBQSxVQUFBLFFBQUEsWUFBQSxTQUFBLFVBQUEsSUFBQSw0QkFBQTs7Ozs7QUFHTCxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7Ozs7QUFKbUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLElBQUE7QUFDbEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsZ0JBQUE7Ozs7O0FBUWpCLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7QUFEYSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxTQUFBLGVBQUEsUUFBQSxjQUFBLFFBQUEsYUFBQTs7Ozs7QUFHVCxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsU0FBQSxlQUFBLFFBQUEsV0FBQSxRQUFBLFFBQUE7Ozs7OztBQXpCckIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUlJLElBQUEseUJBQUEsU0FBQSxTQUFBLHFGQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLG1CQUFBLFlBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxnQkFBQSxnQkFBQSxDQUE2QjtJQUFBLENBQUE7QUFFdEMsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxPQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDZFQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsSUFBQSxvQ0FBQTtBQUdBLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEseUJBQUEsSUFBQSw4RUFBQSxHQUFBLENBQUE7QUFNSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsOEVBQUEsR0FBQSxDQUFBLEVBRUMsSUFBQSw4RUFBQSxHQUFBLENBQUE7QUFJTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTs7Ozs7OztBQTVCUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHFDQUFBLE1BQUEsa0JBQUEsT0FBQSxFQUFBO0FBRUEsSUFBQSx5QkFBQSxXQUFBLDhCQUFBLEdBQUFDLE1BQUEsUUFBQSxlQUFBLFFBQUEsdUJBQUEsZ0JBQUEsQ0FBQSxDQUFBO0FBSXNCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSxVQUFBLFFBQUEsaUJBQUEsb0JBQUEsS0FBQSxLQUFBLE9BQUEsT0FBQSxRQUFBLGlCQUFBLG9CQUFBLEtBQUEsRUFBQSxVQUFBLFFBQUEsWUFBQSxTQUFBLFVBQUEsSUFBQSw0QkFBQTtBQUtkLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxpQkFBQSxPQUFBLEtBQUEsRUFBQTtBQVFlLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEscUNBQUEsTUFBQSx3QkFBQSxPQUFBLEVBQUE7QUFDbkIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsdUJBQUEsZ0JBQUEsSUFBQSxLQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsQ0FBQSxRQUFBLHVCQUFBLGdCQUFBLElBQUEsS0FBQSxFQUFBOzs7OztBQTFCaEIsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSwrQkFBQSxHQUFBLCtEQUFBLElBQUEsSUFBQSxNQUFBLE1BQUEsdUNBQUE7QUErQkosSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBaENRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsT0FBQSxTQUFBLGFBQUE7Ozs7O0FBdUNRLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUFzQixJQUFBLHFCQUFBLENBQUE7O0FBQWdFLElBQUEsMkJBQUE7QUFDMUYsSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7QUFEMEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsdUNBQUEsQ0FBQTs7Ozs7QUFTVixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7OztBQURTLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxRQUFBLGlCQUFBLG9CQUFBLEtBQUEsRUFBQSxNQUFBLDRCQUFBOzs7OztBQUdMLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7OztBQUptQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGNBQUEsSUFBQTtBQUNsQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxnQkFBQTs7Ozs7QUFLYixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7OztBQURTLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxRQUFBLGlCQUFBLG9CQUFBLEtBQUEsRUFBQSxhQUFBLDRCQUFBOzs7OztBQUdMLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7OztBQUpzQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGNBQUEsSUFBQTtBQUNyQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxtQkFBQTs7Ozs7QUFRakIsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUF5RCxJQUFBLHFCQUFBLENBQUE7O0FBQW9FLElBQUEsMkJBQUE7QUFDakksSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBRFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxxQ0FBQSxNQUFBLGtCQUFBLE9BQUEsVUFBQTtBQUFtRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsR0FBQSwyQ0FBQSxDQUFBOzs7OztBQUd6RCxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXFELElBQUEscUJBQUEsQ0FBQTs7QUFBa0UsSUFBQSwyQkFBQTtBQUMzSCxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7QUFEVSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHFDQUFBLE1BQUEsa0JBQUEsT0FBQSxRQUFBO0FBQStDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLHlDQUFBLENBQUE7Ozs7O0FBR3JELElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7QUFEVSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHFDQUFBLE1BQUEsa0JBQUEsT0FBQSxVQUFBOzs7OztBQUdOLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7O0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxjQUFBLDBCQUFBLEdBQUEsR0FBQSwyQ0FBQSxDQUFBO0FBQXVHLElBQUEseUJBQUEsUUFBQSxRQUFBLGdCQUFBOzs7OztBQVU1RyxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7O0FBRHVCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLHFCQUFBOzs7OztBQU4zQixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDZGQUFBLEdBQUEsQ0FBQTtBQU9KLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7O0FBUlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsUUFBQSxTQUFBLFdBQUEsQ0FBQSxpQkFBQSxZQUFBLFFBQUEsdUJBQUEsZ0JBQUEsS0FBQSxDQUFBLGlCQUFBLGFBQUEsQ0FBQSxRQUFBLHVCQUFBLGdCQUFBLEtBQUEsaUJBQUEsYUFBQSxJQUFBLEVBQUE7Ozs7O0FBWUksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7OztBQURhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLFNBQUEsZUFBQSxRQUFBLGNBQUEsUUFBQSxhQUFBOzs7OztBQUdULElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7QUFEYSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxTQUFBLGVBQUEsUUFBQSxXQUFBLFFBQUEsUUFBQTs7Ozs7QUFMakIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSw2RkFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLDZGQUFBLEdBQUEsQ0FBQTtBQUlMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7O0FBUFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsdUJBQUEsZ0JBQUEsSUFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxRQUFBLHVCQUFBLGdCQUFBLElBQUEsSUFBQSxFQUFBOzs7OztBQXREWixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxPQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDhFQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsSUFBQSxvQ0FBQTtBQUdBLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEseUJBQUEsSUFBQSwrRUFBQSxHQUFBLENBQUEsRUFLQyxJQUFBLCtFQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsSUFBQSxvQ0FBQTtBQUlELElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEseUJBQUEsSUFBQSwrRUFBQSxHQUFBLENBQUE7QUFNSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsK0VBQUEsR0FBQSxDQUFBLEVBRUMsSUFBQSwrRUFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLCtFQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsK0VBQUEsR0FBQSxDQUFBO0FBVUwsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSwrRUFBQSxHQUFBLENBQUEsRUFVQyxJQUFBLCtFQUFBLEdBQUEsQ0FBQTtBQVdMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7Ozs7OztBQTVEOEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxxQ0FBQSxNQUFBLGtCQUFBLE9BQUEsRUFBQTtBQUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxRQUFBLGlCQUFBLG9CQUFBLEtBQUEsRUFBQSxNQUFBLDRCQUFBO0FBS2QsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLGlCQUFBLE9BQUEsS0FBQSxFQUFBO0FBU0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLGlCQUFBLGNBQUEsS0FBQSxFQUFBO0FBU0osSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLENBQUEsaUJBQUEsV0FBQSxDQUFBLFFBQUEsU0FBQSxXQUFBLGlCQUFBLFlBQUEsS0FBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLENBQUEsaUJBQUEsV0FBQSxDQUFBLFFBQUEsU0FBQSxXQUFBLENBQUEsaUJBQUEsWUFBQSxLQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsaUJBQUEsV0FBQSxRQUFBLFNBQUEsVUFBQSxLQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsaUJBQUEsV0FBQSxRQUFBLFNBQUEsVUFBQSxLQUFBLEVBQUE7QUFJSixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsQ0FBQSxRQUFBLHNCQUFBLEtBQUEsRUFBQTtBQVdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxDQUFBLFFBQUEsc0JBQUEsS0FBQSxFQUFBOzs7OztBQTdEWixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxTQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFBb0IsSUFBQSxxQkFBQSxDQUFBOztBQUFtRSxJQUFBLDJCQUFBO0FBQ3ZGLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFBcUIsSUFBQSxxQkFBQSxFQUFBOztBQUFxRSxJQUFBLDJCQUFBO0FBQzFGLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSx3RUFBQSxHQUFBLENBQUEsRUFFQyxJQUFBLHdFQUFBLEdBQUEsQ0FBQTtBQUlMLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLCtCQUFBLElBQUEsZ0VBQUEsSUFBQSxJQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQThESixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7Ozs7QUF4RWdDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLDBDQUFBLENBQUE7QUFDQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLElBQUEsR0FBQSw0Q0FBQSxDQUFBO0FBQ3JCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxDQUFBLE9BQUEsc0JBQUEsS0FBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLENBQUEsT0FBQSxzQkFBQSxLQUFBLEVBQUE7QUFJSixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsU0FBQSxhQUFBOzs7QUQ3R1osc0JBZWE7QUFmYjs7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUFVTSxJQUFPLGtDQUFQLE1BQU8saUNBQStCO01BNkNwQjtNQTVDcEI7TUFFQSxJQUNJLFNBQVMsVUFBZ0M7QUFDekMsYUFBSyxZQUFZO0FBQ2pCLGFBQUssZ0JBQWU7TUFDeEI7TUFDQSxJQUFJLFdBQVE7QUFDUixlQUFPLEtBQUs7TUFDaEI7TUFHQTtNQUVBO01BRUE7TUFFQTtNQUVBO01BRUE7TUFFQTtNQUVBO01BRUE7TUFHQSw4QkFBOEIsSUFBSVIsY0FBWTtNQUU5QztNQUdBLG1CQUFtQk07TUFDbkIsd0JBQXdCRDtNQUN4QixzQkFBc0JEO01BQ3RCLFdBQVc7TUFDWCxnQkFBZ0I7TUFDaEIsV0FBVztNQUNYLGNBQWM7TUFFZCxZQUFvQixpQkFBdUM7QUFBdkMsYUFBQSxrQkFBQTtNQUEwQztNQUs5RCxrQkFBZTtBQUNYLGFBQUssbUJBQW1CLElBQUksb0NBQW1DO0FBQy9ELGFBQUssaUJBQWlCLE9BQU8sS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssU0FBUyxJQUFJO0FBQ3hGLGFBQUssaUJBQWlCLE9BQU8sS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssU0FBUyxJQUFJO0FBQ3hGLGFBQUssaUJBQWlCLGNBQWMsS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssU0FBUyxXQUFXO0FBQ3RHLGFBQUssaUJBQWlCLHNCQUFzQixLQUFLLFNBQVMsY0FBZSxJQUFJLENBQUMsaUJBQWdCO0FBQzFGLGdCQUFNLHVCQUF1QixJQUFJLG9DQUFtQztBQUNwRSwrQkFBcUIsT0FBTyxLQUFLLGdCQUFnQixvQkFBb0IsYUFBYSxJQUFJO0FBQ3RGLCtCQUFxQixPQUFPLEtBQUssZ0JBQWdCLG9CQUFvQixhQUFhLElBQUk7QUFDdEYsK0JBQXFCLGNBQWMsS0FBSyxnQkFBZ0Isb0JBQW9CLGFBQWEsV0FBVztBQUNwRyxpQkFBTztRQUNYLENBQUM7TUFDTDtNQU1BLGdCQUFnQixjQUEwQjtBQUN0QyxZQUFJLEtBQUssZUFBZTtBQUVwQjs7QUFFSixZQUFJLEtBQUssdUJBQXVCLFlBQVksR0FBRztBQUMzQyxlQUFLLHdCQUF3QixLQUFLLHNCQUFzQixPQUFPLENBQUMseUJBQXdCO0FBQ3BGLGdCQUFJLGFBQWEsSUFBSTtBQUNqQixxQkFBTyxxQkFBcUIsT0FBTyxhQUFhOztBQUVwRCxtQkFBTyx5QkFBeUI7VUFDcEMsQ0FBQzttQkFDTSxLQUFLLGdCQUFnQjtBQUM1QixlQUFLLHdCQUF3QixDQUFDLFlBQVk7ZUFDdkM7QUFDSCxlQUFLLHNCQUFzQixLQUFLLFlBQVk7O0FBRWhELGFBQUssNEJBQTRCLEtBQUssS0FBSyxxQkFBcUI7QUFFaEUsWUFBSSxLQUFLLGVBQWU7QUFDcEIsZUFBSyxjQUFhOztNQUUxQjtNQU1BLHVCQUF1QixjQUEwQjtBQUM3QyxlQUNJLEtBQUssc0JBQXNCLFVBQVUsQ0FBQyx5QkFBd0I7QUFDMUQsY0FBSSxhQUFhLElBQUk7QUFDakIsbUJBQU8scUJBQXFCLE9BQU8sYUFBYTs7QUFFcEQsaUJBQU8seUJBQXlCO1FBQ3BDLENBQUMsTUFBTTtNQUVmO01BRUEsSUFBSSxpQkFBYztBQUNkLGVBQU8sS0FBSyxTQUFTO01BQ3pCOzt5QkE3R1Msa0NBQStCLGdDQUFBLHNCQUFBLENBQUE7TUFBQTtpRUFBL0Isa0NBQStCLFdBQUEsQ0FBQSxDQUFBLDhCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLHVCQUFBLHlCQUFBLGVBQUEsaUJBQUEsWUFBQSxjQUFBLGVBQUEsaUJBQUEsT0FBQSxTQUFBLHFCQUFBLHVCQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsZUFBQSxnQkFBQSxHQUFBLFNBQUEsRUFBQSw2QkFBQSw4QkFBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxlQUFBLG9CQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSx3QkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxnQkFBQSx1Q0FBQSxHQUFBLFNBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSxFQUFBLEdBQUEsQ0FBQSx1QkFBQSxFQUFBLEdBQUEsQ0FBQSxZQUFBLHlCQUFBLEdBQUEsU0FBQSxjQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSw4QkFBQSxHQUFBLENBQUEsYUFBQSxjQUFBLFlBQUEseUJBQUEsR0FBQSxTQUFBLGlCQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsZ0JBQUEscUNBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLGdCQUFBLGlDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxVQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsZ0JBQUEscUNBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsWUFBQSx5QkFBQSxpQkFBQSxpQ0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsTUFBQSxXQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsNkJBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsSUFBQSxHQUFBLENBQUEsUUFBQSxNQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSx1QkFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLElBQUEsR0FBQSxDQUFBLDhCQUFBLEVBQUEsR0FBQSxDQUFBLG9DQUFBLEVBQUEsR0FBQSxDQUFBLFlBQUEseUJBQUEsR0FBQSxTQUFBLGlCQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsSUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsSUFBQSxHQUFBLENBQUEsZ0JBQUEsbUNBQUEsR0FBQSxTQUFBLEdBQUEsSUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLFNBQUEsR0FBQSxjQUFBLE1BQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxHQUFBLFdBQUEsR0FBQSxNQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEseUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNmNUMsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUlJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxVQUFBLHFCQUFBLENBQUE7QUFBb0IsVUFBQSwyQkFBQTtBQUFRLFVBQUEscUJBQUEsQ0FBQTtBQUN0QyxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLHdCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEseURBQUEsR0FBQSxDQUFBLEVBRUMsSUFBQSx5REFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLHlEQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEseURBQUEsSUFBQSxDQUFBLEVBQUEsSUFBQSx5REFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLHlEQUFBLElBQUEsRUFBQSxFQUFBLElBQUEseURBQUEsR0FBQSxDQUFBLEVBQUEsSUFBQSx5REFBQSxJQUFBLENBQUE7QUFtS0wsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUE1S0ksVUFBQSx5QkFBQSxXQUFBLDhCQUFBLElBQUFLLE1BQUEsSUFBQSxpQkFBQSxDQUFBLElBQUEsWUFBQSxJQUFBLGNBQUEsQ0FBQSxJQUFBLHNCQUFBLElBQUEsU0FBQSxLQUFBLElBQUEsU0FBQSxVQUFBLENBQUEsSUFBQSxtQkFBQSxDQUFBO0FBR1UsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSxJQUFBLElBQUEsZUFBQSxHQUFBO0FBQTRCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsaUNBQUEsS0FBQSxJQUFBLFNBQUEsT0FBQSxRQUFBO0FBRW5DLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsYUFBQSxJQUFBLGlCQUFBLE1BQUEsNEJBQUE7QUFDSCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxTQUFBLFVBQUEsS0FBQSxFQUFBO0FBR0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLENBQUEsSUFBQSxpQkFBQSxLQUFBLEVBQUE7QUFHQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxpQkFBQSxLQUFBLEVBQUE7QUFHQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxTQUFBLFFBQUEsSUFBQSxTQUFBLGVBQUEsSUFBQSxhQUFBLEtBQUEsRUFBQTtBQXVCQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLGNBQUEsSUFBQSxzQkFBQSxLQUFBLEVBQUE7QUFNQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxjQUFBLENBQUEsSUFBQSxzQkFBQSxLQUFBLEVBQUE7QUFnQkEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLENBQUEsSUFBQSxhQUFBLEtBQUEsRUFBQTtBQW1DQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxhQUFBLEtBQUEsRUFBQTs7Ozs7cUZEbEZTLGlDQUErQixFQUFBLFdBQUEsa0NBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFZjVDLFNBQVMsY0FBQUMsbUJBQWtCO0FBSzNCLFNBQVMsaUJBQWlCOztBQUwxQixJQVNhO0FBVGI7O0FBTUE7QUFHTSxJQUFPLDBCQUFQLE1BQU8seUJBQXVCO01BQ2hDLGNBQUE7TUFBZTtNQVlmLHVDQUF1QyxVQUE2QjtBQUNoRSxZQUFJLENBQUMsU0FBUyxpQkFBaUI7QUFFM0IsaUJBQU87O0FBR1gsWUFBSSxpQkFBdUMsVUFBVSxTQUFTLGVBQWU7QUFDN0UsY0FBTSxtQkFBOEIsQ0FBQTtBQUVwQyxtQkFBVyxRQUFRLFNBQVMsT0FBUTtBQUNoQyxjQUFJLG9CQUFvQjtBQUN4QixnQkFBTSxvQkFBb0IsS0FBSyx1QkFBdUIsU0FBUyxpQkFBaUIsSUFBSTtBQUVwRiw0QkFBa0IsUUFBUSxDQUFDLGFBQVk7QUFDbkMsZ0JBQUksZUFBZSxTQUFTLEtBQUssZUFBZSxXQUFXLFNBQVMsZ0JBQWlCLFFBQVE7QUFDekYsa0NBQW9COztBQUd4QixnQkFBSSxlQUFlLFdBQVcsU0FBUyxnQkFBaUIsUUFBUTtBQUc1RCxvQkFBTSxzQkFBc0IsS0FBSyx1QkFBdUIsU0FBUyxpQkFBaUIsSUFBSTtBQUN0RixvQkFBTSwwQkFBMEIsb0JBQW9CLE9BQ2hELENBQUMsb0JBQW9CLEtBQUssd0JBQXdCLFNBQVMsaUJBQWlCLGVBQWUsRUFBRyxXQUFXLENBQUM7QUFHOUcsa0JBQUksd0JBQXdCLFNBQVMsR0FBRztBQUNwQyxvQ0FBb0I7OztBQUk1Qiw2QkFBaUIsZUFBZSxPQUFPLENBQUMsWUFBWSxDQUFDLEtBQUssZUFBZSxVQUFVLFFBQVEsUUFBUSxDQUFDO1VBQ3hHLENBQUM7QUFHRCxnQkFBTSx5QkFBeUIsS0FBSyx1QkFBdUIsU0FBUyxpQkFBaUIsSUFBSSxFQUFHLFVBQVUsU0FBUyxNQUFPO0FBRXRILGNBQUkscUJBQXFCLHdCQUF3QjtBQUM3Qyw2QkFBaUIsS0FBSyxJQUFJO2lCQUN2QjtBQUNILDZCQUFpQixLQUFLLEtBQUs7OztBQUduQyxlQUFPLENBQUMsaUJBQWlCLFNBQVMsS0FBSztNQUMzQztNQVVBLGlCQUFpQixVQUFpQyxVQUFnQyxNQUFzQjtBQUNwRyxlQUFPLENBQUMsQ0FBQyxLQUFLLHNCQUFzQixVQUFVLFVBQVUsSUFBSTtNQUNoRTtNQVNBLHdCQUF3QixVQUFpQyxVQUE4QjtBQUNuRixlQUFPLFVBQ0QsT0FBTyxTQUFVLFNBQU87QUFDdEIsaUJBQU8sS0FBSyxlQUFlLFFBQVEsVUFBVSxRQUFRO1FBQ3pELEdBQUcsSUFBSSxFQUNOLElBQUksU0FBVSxTQUFPO0FBQ2xCLGlCQUFPLFFBQVE7UUFDbkIsQ0FBQztNQUNUO01BU0EsdUJBQXVCLFVBQWlDLE1BQXNCO0FBQzFFLGVBQU8sVUFDRCxPQUFPLENBQUMsWUFBVztBQUNqQixpQkFBTyxLQUFLLFdBQVcsUUFBUSxNQUFNLElBQUk7UUFDN0MsR0FBRyxJQUFJLEVBQ04sSUFBSSxDQUFDLFlBQVc7QUFDYixpQkFBTyxRQUFRO1FBQ25CLENBQUM7TUFDVDtNQVNBLGlCQUFpQixNQUEwQixNQUF3QjtBQUMvRCxZQUFJLE1BQU0sV0FBVyxNQUFNLFFBQVE7QUFFL0IsaUJBQU87O0FBRVgsZUFFSSxNQUFNLE1BQU0sQ0FBQyxVQUFTO0FBQ2xCLGlCQUFPLE1BQU0sS0FBSyxDQUFDLFVBQVM7QUFDeEIsbUJBQU8sS0FBSyxXQUFXLE9BQU8sS0FBSztVQUN2QyxDQUFDO1FBQ0wsQ0FBQyxLQUNELE1BQU0sTUFBTSxDQUFDLFVBQVM7QUFDbEIsaUJBQU8sTUFBTSxLQUFLLENBQUMsVUFBUztBQUN4QixtQkFBTyxLQUFLLFdBQVcsT0FBTyxLQUFLO1VBQ3ZDLENBQUM7UUFDTCxDQUFDO01BRVQ7TUFVQSxzQkFBc0IsVUFBaUMsVUFBZ0MsTUFBc0I7QUFDekcsZUFBTyxVQUFVLEtBQUssQ0FBQyxZQUErQjtBQUNsRCxpQkFBTyxLQUFLLFdBQVcsTUFBTSxRQUFRLElBQUksS0FBSyxLQUFLLGVBQWUsVUFBVSxRQUFRLFFBQVE7UUFDaEcsR0FBRyxJQUFJO01BQ1g7TUFTQSxXQUFXLEdBQXFCLEdBQW1CO0FBQy9DLGVBQU8sTUFBTSxLQUFNLE1BQU0sVUFBYSxNQUFNLFdBQWUsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFRLEVBQUUsVUFBVSxVQUFhLEVBQUUsVUFBVSxVQUFhLEVBQUUsV0FBVyxFQUFFO01BQ25LO01BU0EsZUFBZSxHQUF5QixHQUF1QjtBQUMzRCxlQUFPLE1BQU0sS0FBTSxNQUFNLFVBQWEsTUFBTSxXQUFlLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBUSxFQUFFLFVBQVUsVUFBYSxFQUFFLFVBQVUsVUFBYSxFQUFFLFdBQVcsRUFBRTtNQUNuSztNQVNBLHNCQUFzQixVQUFnQyxPQUF3QjtBQUMxRSxZQUFJLElBQUk7QUFDUixtQkFBVyxRQUFRLE9BQU87QUFDdEIsZ0JBQU0sWUFBWSxLQUFLLHVCQUF1QixVQUFVLElBQUk7QUFDNUQsY0FBSSxhQUFhLFVBQVUsU0FBUyxHQUFHO0FBQ25DOzs7QUFHUixlQUFPLE1BQU0sTUFBTTtNQUN2QjtNQVFBLDRCQUE0QixVQUE4QjtBQUN0RCxlQUFPLEVBQUUsU0FBUyxPQUFPLENBQUMsWUFBWSxRQUFRLFNBQVMsTUFBUyxFQUFFLFNBQVM7TUFDL0U7TUFRQSwwQkFBMEIsVUFBOEI7QUFDcEQsWUFBSSxTQUFTLE9BQU8sQ0FBQyxZQUFZLFFBQVEsU0FBUyxNQUFTLEVBQUUsU0FBUyxHQUFHO0FBQ3JFLGlCQUFPOztBQUVYLFlBQUksa0JBQWtCO0FBQ3RCLGlCQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsU0FBUyxHQUFHLEtBQUs7QUFDMUMsbUJBQVMsSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztBQUMxQyxnQkFBSSxTQUFTLENBQUMsRUFBRSxLQUFNLFdBQVcsU0FBUyxDQUFDLEVBQUUsS0FBTSxVQUFVLFNBQVMsQ0FBQyxFQUFFLFNBQVUsU0FBVSxTQUFTLENBQUMsRUFBRSxTQUFVLE1BQU87QUFDdEg7Ozs7QUFJWixlQUFPLGtCQUFrQjtNQUM3QjtNQVFBLG1CQUFtQixVQUE2QjtBQUM1QyxjQUFNLGtCQUF5QyxDQUFBO0FBQy9DLG1CQUFXLFFBQVEsU0FBUyxPQUFRO0FBQ2hDLGdCQUFNLG1CQUFtQixLQUFLLHVCQUF1QixTQUFTLGlCQUFrQixJQUFJO0FBQ3BGLHFCQUFXLFdBQVcsU0FBUyxpQkFBa0I7QUFDN0MsZ0JBQ0ksUUFBUSxLQUFNLE9BQU8sS0FBSyxNQUMxQixDQUFDLGdCQUFnQixLQUNiLENBQUMsbUJBQW1CLGVBQWUsU0FBUyxRQUFRLFNBQVUsUUFBUSxDQUFDLEtBQUssZ0NBQWdDLGtCQUFrQixlQUFlLENBQUMsR0FFcEo7QUFDRSw4QkFBZ0IsS0FBSyxRQUFRLFFBQVM7QUFDdEM7Ozs7QUFJWixlQUFPO01BQ1g7TUFTQSxnQ0FBZ0Msa0JBQTBDLGlCQUF1QztBQUM3RyxZQUFJLElBQUk7QUFDUixtQkFBVyxtQkFBbUIsb0JBQW9CLENBQUEsR0FBSTtBQUNsRCxxQkFBVyxrQkFBa0IsbUJBQW1CLENBQUEsR0FBSTtBQUNoRCxnQkFBSSxnQkFBZ0IsU0FBUyxlQUFlLE1BQU07QUFDOUM7QUFDQTs7OztBQUlaLGVBQU8sTUFBTSxrQkFBa0I7TUFDbkM7TUFRQSw4QkFBOEIsVUFBNkI7QUFDdkQsZUFBTyxTQUFTLE1BQU8sVUFBVSxTQUFTLFVBQVc7TUFDekQ7TUFXQSxnQ0FBZ0MsY0FBb0I7QUFDaEQsY0FBTSxjQUFjO0FBUXBCLGlCQUFTLFdBQVcsQ0FBQyxHQUFHLEdBQUcsRUFBRSxHQUFhLEtBQWUsQ0FBQSxHQUFFO0FBQ3ZELGlCQUFPLE1BQU0sU0FDUCxLQUNBLENBQUMsR0FBRyxHQUFHLFdBQVcsSUFBSSxFQUFFLENBQUM7UUFDbkM7QUFFQSxlQUFPLGFBQWEsTUFBTSxLQUFLLEVBQUUsSUFBSSxDQUFDLFNBQVE7QUFDMUMsZ0JBQU0sUUFBUSxLQUFLLE1BQU0sV0FBVyxLQUFLLENBQUE7QUFDekMsZ0JBQU0sUUFBUSxLQUFLLE1BQU0sV0FBVyxFQUFFLElBQUksQ0FBQyxTQUFTLEtBQUssS0FBSSxDQUFFO0FBQy9ELGlCQUFPLFdBQVcsT0FBTyxLQUFLLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7UUFDOUQsQ0FBQztNQUNMO01BTUEsYUFBYSxNQUFZO0FBQ3JCLGVBQU8sRUFBRSxLQUFLLE9BQU8sVUFBVSxNQUFNO01BQ3pDO01BTUEsVUFBVSxNQUFZO0FBRWxCLGVBQU8sQ0FBQyxLQUNILE1BQU0sVUFBVSxFQUFFLENBQUMsRUFDbkIsTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUNaLEtBQUk7TUFDYjtNQU9BLFFBQVEsUUFBZ0IsVUFBNkI7QUFDakQsZUFBTyxTQUFTLE1BQU8sT0FBTyxDQUFDLFNBQVMsS0FBSyxXQUFXLE1BQU0sRUFBRSxDQUFDO01BQ3JFO01BU0EsMkJBQTJCLFdBQXFCO0FBQzVDLGNBQU0scUJBQXFCLFVBQVUsSUFBSSxDQUFDLGFBQWEsU0FBUyxJQUFJLENBQUMsWUFBWSxnQkFBZ0IsUUFBUSxLQUFJLENBQUUsQ0FBQyxDQUFDO0FBQ2pILGVBQU8sS0FBSywwQkFBMEIsV0FBVyxrQkFBa0I7TUFDdkU7TUFRQSwwQkFBMEIsbUJBQStCLG9CQUE4QjtBQUNuRixpQkFBUyxJQUFJLEdBQUcsSUFBSSxtQkFBbUIsUUFBUSxLQUFLO0FBQ2hELGdCQUFNLFVBQVUsbUJBQW1CLENBQUMsRUFBRSxDQUFDO0FBQ3ZDLGNBQUksWUFBWTtBQUVoQixjQUFJLGtCQUFrQixDQUFDLEVBQUUsU0FBUyxHQUFHO0FBQ2pDLHdCQUNJLG1CQUFtQixDQUFDLEVBQUUsQ0FBQyxNQUFNLE1BQU0sa0JBQWtCLENBQUMsRUFBRSxDQUFDLEVBQUUsV0FBVyxRQUFRLElBQ3hFLEtBQUssYUFBYSxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUN6QyxLQUFLLGFBQWEsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUM7aUJBQ2hEO0FBQ0gsd0JBQVksS0FBSyxhQUFhLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDOztBQUV6RCxjQUFJLGNBQWMsSUFBSTtBQUNsQjs7QUFFSixnQkFBTSxpQkFBaUIsUUFBUSxRQUFRLFNBQVM7QUFDaEQsZ0JBQU0sYUFBYSxTQUFTLE9BQU8sS0FBSyxlQUFlLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTTtBQUN0Riw2QkFBbUIsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsVUFBVSxHQUFHLGNBQWMsR0FBRyxZQUFZLFFBQVEsVUFBVSxjQUFjLEVBQUUsS0FBSSxDQUFFLEVBQUUsS0FBSyxFQUFFOztBQUVuSSxlQUFPO01BQ1g7TUFPTyxlQUFlLE1BQVk7QUFDOUIsWUFBSSxDQUFDLE1BQU07QUFDUCxpQkFBTzs7QUFFWCxZQUFJLEtBQUssV0FBVyxHQUFHLEdBQUc7QUFDdEIsaUJBQU8sS0FBSyxVQUFVLENBQUM7O0FBRTNCLFlBQUksUUFBUTtBQUNaLFlBQUksY0FBYztBQUNsQixlQUFPLEtBQUssS0FBSyxNQUFNLEtBQUs7QUFDeEIsd0JBQWMsWUFBWSxPQUFPLEdBQUc7QUFDcEM7O0FBRUosZUFBTztNQUNYO01BT0EsYUFBYSxNQUFZO0FBQ3JCLFlBQUksQ0FBQyxNQUFNO0FBQ1AsaUJBQU87O0FBRVgsY0FBTSxRQUFRLEtBQ1QsS0FBSSxFQUNKLE1BQU0sR0FBRyxFQUNULE9BQU8sQ0FBQyxTQUFTLFNBQVMsRUFBRTtBQUNqQyxZQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3BCLGlCQUFPO21CQUNBLE1BQU0sQ0FBQyxNQUFNLEtBQUs7QUFDekIsaUJBQU8sTUFBTSxDQUFDO2VBQ1g7QUFDSCxpQkFBTyxNQUFNLENBQUMsRUFBRSxXQUFXLEdBQUcsSUFBSSxNQUFNLENBQUMsRUFBRSxVQUFVLENBQUMsSUFBSSxNQUFNLENBQUM7O01BRXpFOzt5QkE5WlMsMEJBQXVCO01BQUE7b0VBQXZCLDBCQUF1QixTQUF2Qix5QkFBdUIsV0FBQSxZQURWLE9BQU0sQ0FBQTs7Ozs7O0FDSmhDLElBQWE7QUFBYjs7QUFBTSxJQUFPLDJCQUFQLE1BQStCO01BQzFCO01BQ0E7TUFDQTtNQUNBO01BQ0E7Ozs7OztBQ1RYLFNBQVMsYUFBQUMsWUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFPLFVBQUFDLFNBQVEscUJBQUFDLDBCQUF5QjtBQU8xRSxTQUFTLHVCQUFBQyw0QkFBMkI7QUFDcEMsU0FBUyxvQkFBQUMseUJBQXdCOzs7Ozs7O0FDVUQsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7OztBQURTLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxhQUFBLDRCQUFBOzs7Ozs7QUFHTCxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQU9JLElBQUEseUJBQUEsVUFBQSxTQUFBLHdHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFVLDBCQUFBLFFBQUEsaUJBQUEsQ0FBa0I7SUFBQSxDQUFBO0FBUGhDLElBQUEsMkJBQUE7QUFTSixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7Ozs7OztBQUxZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsb0NBQUEsU0FBQSxRQUFBLGdDQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEscUNBQUEsTUFBQSxhQUFBLE1BQUEsS0FBQSxPQUFBLEtBQUEsUUFBQSxvQkFBQSxJQUFBLEVBQUE7QUFIQSxJQUFBLHlCQUFBLGFBQUEsUUFBQSxpQkFBQSxFQUErQixZQUFBLFFBQUEsYUFBQTs7Ozs7QUFUL0MsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwrRUFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLCtFQUFBLEdBQUEsQ0FBQTtBQWVMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7O0FBbEJRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxDQUFBLFFBQUEsd0JBQUEsYUFBQSxXQUFBLElBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsd0JBQUEsYUFBQSxXQUFBLElBQUEsSUFBQSxFQUFBOzs7OztBQU5aLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEsaUVBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQXFCQSxJQUFBLHdCQUFBLEdBQUEsSUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUF2QlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBOzs7OztBQUhaLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEsMkRBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQTBCSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7QUEzQlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxPQUFBLFNBQUE7Ozs7O0FBbUNvQixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7O0FBRFMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLGFBQUEsNEJBQUE7Ozs7O0FBR0wsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTs7QUFJSSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsU0FBQSxDQUFBO0FBUUosSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7Ozs7QUFYUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGNBQUEsUUFBQSxtQkFBQSxXQUFBLE1BQUEsWUFBQSwwQkFBQSxHQUFBLEdBQUEsd0NBQUEsSUFBQSxNQUFBO0FBR0ksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxxQ0FBQSwyQ0FBQSxRQUFBLG1CQUFBLFdBQUEsR0FBQSxFQUFBO0FBSUEsSUFBQSxvQ0FBQSxTQUFBLFFBQUEsdUJBQUEsV0FBQSxDQUFBO0FBQ0EsSUFBQSxvQ0FBQSxRQUFBLFFBQUEsZUFBQSxXQUFBLENBQUE7QUFGQSxJQUFBLHlCQUFBLGFBQUEsUUFBQSxpQkFBQTs7Ozs7QUFiaEIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwrRUFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLCtFQUFBLEdBQUEsQ0FBQTtBQWdCTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7OztBQW5CUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxRQUFBLHdCQUFBLGFBQUEsV0FBQSxJQUFBLElBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLHdCQUFBLGFBQUEsV0FBQSxJQUFBLElBQUEsRUFBQTs7Ozs7QUFOWixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwrQkFBQSxHQUFBLGlFQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7QUFzQkEsSUFBQSx3QkFBQSxHQUFBLElBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBeEJRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQTs7Ozs7QUFIWixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSwrQkFBQSxHQUFBLDJEQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7QUEyQkosSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBNUJRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsT0FBQSxTQUFBOzs7OztBQThCSixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7Ozs7QUFJWSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBRFMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLFFBQUEsaUJBQUEsTUFBQSw0QkFBQTs7Ozs7QUFHTCxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7Ozs7QUFKbUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLElBQUE7QUFDbEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsaUJBQUE7Ozs7O0FBTWIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQURTLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxRQUFBLGlCQUFBLGFBQUEsNEJBQUE7Ozs7O0FBR0wsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7Ozs7O0FBSnNDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSxJQUFBO0FBQ3JCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLG1CQUFBOzs7OztBQWhCckIsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLG9FQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsSUFBQSxvQ0FBQTtBQUdBLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxvRUFBQSxHQUFBLENBQUE7QUFNQSxJQUFBLHdCQUFBLEdBQUEsSUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxvRUFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLElBQUEsb0NBQUE7QUFHQSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEscUVBQUEsR0FBQSxDQUFBO0FBTUosSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBOzs7O0FBakJRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLG9CQUFBLE9BQUEsSUFBQSxFQUFBO0FBVUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsb0JBQUEsZUFBQSxPQUFBLGFBQUEsS0FBQSxFQUFBOzs7OztBQVNKLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUFnQyxJQUFBLDJCQUFBO0FBQzFDLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBRmMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxPQUFBLG9CQUFBLE1BQUE7Ozs7O0FBSVYsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBK0IsSUFBQSxxQkFBQSxDQUFBO0FBQWlELElBQUEsMkJBQUE7QUFDaEYsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxzQ0FBQSxFQUFBO0FBTUosSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBOzs7O0FBWnVDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSw4QkFBQSxHQUFBQyxPQUFBLE9BQUEsU0FBQSxLQUFBLE9BQUEsb0JBQUEsTUFBQSxDQUFBO0FBRUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxJQUFBLE9BQUEsU0FBQSxHQUFBLEtBQUEsT0FBQSxvQkFBQSxRQUFBLEVBQUE7QUFHdkIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxTQUFBLE9BQUEsS0FBQSxFQUFlLFlBQUEsT0FBQSxtQkFBQSxFQUFBLG1CQUFBLE9BQUEsY0FBQSxFQUFBLGlCQUFBLE9BQUEsYUFBQTs7Ozs7O0FBYW5CLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBcUMsSUFBQSx5QkFBQSxTQUFBLFNBQUEsMEZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxtQkFBQSxDQUFvQjtJQUFBLENBQUE7QUFDOUQsSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7OztBQUZRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMEJBQUEsMEJBQUEsR0FBQSxHQUFBLDRDQUFBLEdBQUEsb0JBQUE7Ozs7OztBQUlKLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBcUMsSUFBQSx5QkFBQSxTQUFBLFNBQUEsMEZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxtQkFBQSxDQUFvQjtJQUFBLENBQUE7QUFDOUQsSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7OztBQUZRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMEJBQUEsMEJBQUEsR0FBQSxHQUFBLDRDQUFBLEdBQUEsb0JBQUE7Ozs7O0FBUlosSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxvRUFBQSxHQUFBLENBQUEsRUFJQyxHQUFBLG9FQUFBLEdBQUEsQ0FBQTtBQU1MLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQVhRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxDQUFBLE9BQUEsd0JBQUEsSUFBQSxFQUFBO0FBS0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsd0JBQUEsSUFBQSxFQUFBOzs7QUQvSFosZ0JBa0JhO0FBbEJiOztBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBR0E7Ozs7Ozs7O0FBU00sSUFBTywrQkFBUCxNQUFPLDhCQUE0QjtNQWtEekI7TUFDRDtNQWxEWDtNQUNBO01BRUEsSUFDSSxTQUFTLFVBQXNCO0FBQy9CLGFBQUssc0JBQXNCO0FBQzNCLGFBQUssZ0JBQWU7TUFDeEI7TUFJQTtNQUVBO01BRUE7TUFFQTtNQUVBO01BQ0EsSUFDSSxvQkFBb0IscUJBQW1CO0FBQ3ZDLGFBQUssdUJBQXVCO0FBQzVCLFlBQUksS0FBSyxxQkFBcUI7QUFDMUIsZUFBSyxtQkFBa0I7O01BRS9CO01BRUEsSUFBSSxzQkFBbUI7QUFDbkIsZUFBTyxLQUFLO01BQ2hCO01BRUE7TUFHQSx1QkFBdUIsSUFBSU4sY0FBWTtNQUU5QixvQkFBb0I7TUFFN0Isd0JBQXdCO01BQ3hCO01BQ0Esa0JBQXlDLENBQUE7TUFDekM7TUFHQSxzQkFBc0JJO01BQ3RCLG9CQUFvQkM7TUFFcEIsWUFDWSxpQkFDRCx5QkFBZ0Q7QUFEL0MsYUFBQSxrQkFBQTtBQUNELGFBQUEsMEJBQUE7TUFDUjtNQUtILGtCQUFlO0FBQ1gsYUFBSyxtQkFBbUIsSUFBSSxvQ0FBbUM7QUFFL0QsY0FBTSxZQUFZLEtBQUssd0JBQXdCLGdDQUFnQyxLQUFLLG9CQUFvQixJQUFLO0FBQzdHLGFBQUssWUFBWSxLQUFLLHdCQUF3QiwyQkFBMkIsU0FBUztBQUVsRixhQUFLLGlCQUFpQixPQUFPLEtBQUssZ0JBQWdCLG9CQUFvQixLQUFLLG9CQUFvQixJQUFJO0FBQ25HLGFBQUssaUJBQWlCLE9BQU8sS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssb0JBQW9CLElBQUk7QUFDbkcsYUFBSyxpQkFBaUIsY0FBYyxLQUFLLGdCQUFnQixvQkFBb0IsS0FBSyxvQkFBb0IsV0FBVztNQUNySDtNQU1BLG1CQUFnQjtBQUNaLGFBQUssaUJBQWlCLENBQUE7QUFDdEIsWUFBSSxJQUFJO0FBQ1IsbUJBQVcsWUFBWSxLQUFLLFdBQVc7QUFDbkMsY0FBSSxJQUFJO0FBQ1IscUJBQVcsV0FBVyxVQUFVO0FBQzVCLGdCQUFJLEtBQUssd0JBQXdCLGFBQWEsT0FBUSxHQUFHO0FBQ3JELG9CQUFNLGdCQUFnQixJQUFJLHlCQUF3QjtBQUNsRCw0QkFBYyxPQUEwQixTQUFTLGVBQWUsY0FBYyxJQUFJLE1BQU0sSUFBSSxNQUFNLEtBQUssb0JBQW9CLEVBQUUsRUFBRztBQUNoSSw0QkFBYyxPQUFPLEtBQUssd0JBQXdCLFFBQVEsS0FBSyx3QkFBd0IsVUFBVSxPQUFRLEdBQUcsS0FBSyxtQkFBbUI7QUFDcEksbUJBQUssZUFBZSxLQUFLLGFBQWE7O0FBRTFDOztBQUVKOztBQUVKLGFBQUsscUJBQXFCLEtBQUssS0FBSyxjQUFjO0FBRWxELFlBQUksS0FBSyx5QkFBeUI7QUFDOUIsZUFBSyx3QkFBdUI7O01BRXBDO01BS0EscUJBQWtCO0FBRWQsYUFBSyxrQkFBa0IsS0FBSyx3QkFBd0IsbUJBQW1CLEtBQUssbUJBQW1CO0FBQy9GLGFBQUssd0JBQXdCO01BQ2pDO01BS0EscUJBQWtCO0FBQ2QsYUFBSyx3QkFBd0I7TUFDakM7TUFNQSx3QkFBd0IsU0FBZTtBQUNuQyxlQUFPLEtBQUssZUFBZSxPQUFPLENBQUMsa0JBQWtCLGNBQWMsS0FBTSxXQUFXLEtBQUssd0JBQXdCLFVBQVUsT0FBTyxDQUFDLEVBQUUsQ0FBQztNQUMxSTtNQU1BLGdDQUFnQyxTQUFlO0FBQzNDLGNBQU0sZ0JBQWdCLEtBQUssd0JBQXdCLE9BQU87QUFDMUQsZUFBTyxlQUFlLFFBQVE7TUFDbEM7TUFNQSw0QkFBNEIsU0FBZTtBQUN2QyxjQUFNLGdCQUFnQixLQUFLLGdDQUFnQyxPQUFPO0FBQ2xFLGVBQU8sa0JBQWtCLEtBQUssY0FBYyxTQUFTLElBQUk7TUFDN0Q7TUFNQSx5QkFBeUIsU0FBZTtBQUNwQyxjQUFNLFFBQVEsS0FBSyxvQkFBb0IsTUFBTyxVQUFVLENBQUMsU0FBUyxLQUFLLFdBQVcsS0FBSyx3QkFBd0IsVUFBVSxPQUFPLENBQUM7QUFDakksZUFBTyxLQUFLLGdCQUFnQixLQUFLO01BQ3JDO01BTUEsaUNBQWlDLFNBQWU7QUFDNUMsY0FBTSxpQkFBaUIsS0FBSyx5QkFBeUIsT0FBTztBQUM1RCxlQUFPLGdCQUFnQixRQUFRO01BQ25DO01BTUEsNkJBQTZCLFNBQWU7QUFDeEMsY0FBTSxpQkFBaUIsS0FBSyxpQ0FBaUMsT0FBTztBQUNwRSxlQUFPLG1CQUFtQixLQUFLLGVBQWUsU0FBUyxJQUFJO01BQy9EO01BTUEsdUJBQXVCLFNBQWU7QUFDbEMsWUFBSSxLQUFLLHVCQUF1QjtBQUM1QixpQkFBTyxLQUFLLGlDQUFpQyxPQUFPOztBQUV4RCxlQUFPLEtBQUssZ0NBQWdDLE9BQU87TUFDdkQ7TUFNQSxlQUFlLFNBQWU7QUFDMUIsWUFBSSxLQUFLLHVCQUF1QjtBQUM1QixpQkFBTyxLQUFLLDZCQUE2QixPQUFPOztBQUVwRCxlQUFPLEtBQUssNEJBQTRCLE9BQU87TUFDbkQ7TUFNQSxtQkFBbUIsU0FBZTtBQUM5QixZQUFJLEtBQUssb0JBQW9CLFNBQVM7QUFDbEMsaUJBQU87O0FBRVgsY0FBTSxPQUFPLEtBQUssd0JBQXdCLFFBQVEsS0FBSyx3QkFBd0IsVUFBVSxPQUFPLEdBQUcsS0FBSyxtQkFBbUI7QUFDM0gsWUFBSSxLQUFLLFNBQVM7QUFDZCxpQkFBTzs7QUFFWCxZQUFJLEtBQUssdUJBQXVCO0FBQzVCLGlCQUFPOztBQUVYLGNBQU0sdUJBQXVCLEtBQUssd0JBQXdCLE9BQU87QUFDakUsWUFBSSxzQkFBc0IsY0FBYyxNQUFNO0FBQzFDLGlCQUFPOztBQUVYLFlBQUksS0FBSyxpQ0FBaUMsT0FBTyxHQUFHO0FBQ2hELGlCQUFPOztBQUVYLGVBQU87TUFDWDtNQU1BLGlDQUFpQyxTQUFlO0FBQzVDLFlBQUksZ0JBQWdCO0FBQ3BCLGNBQU0sbUJBQW1CLEtBQUssd0JBQXdCLHVCQUNsRCxLQUFLLG9CQUFvQixpQkFDekIsS0FBSyx3QkFBd0IsUUFBUSxLQUFLLHdCQUF3QixVQUFVLE9BQU8sR0FBRyxLQUFLLG1CQUFtQixDQUFDO0FBRW5ILGNBQU0sWUFBWSxrQkFBa0IsT0FBTyxDQUFDLGFBQWEsU0FBUyxNQUFNLEtBQUksTUFBTyxLQUFLLHdCQUF3QixPQUFPLEdBQUcsTUFBTSxLQUFJLENBQUU7QUFDdEksWUFBSSxhQUFhLFVBQVUsU0FBUyxHQUFHO0FBQ25DLDBCQUFnQjs7QUFFcEIsZUFBTztNQUNYOzt5QkFsT1MsK0JBQTRCLGdDQUFBLHNCQUFBLEdBQUEsZ0NBQUEsdUJBQUEsQ0FBQTtNQUFBO2lFQUE1QiwrQkFBNEIsV0FBQSxDQUFBLENBQUEsMkJBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsZ0JBQUEsa0JBQUEsZUFBQSxpQkFBQSxZQUFBLGNBQUEsZUFBQSxpQkFBQSxPQUFBLFNBQUEscUJBQUEsdUJBQUEseUJBQUEsMEJBQUEsR0FBQSxTQUFBLEVBQUEsc0JBQUEsdUJBQUEsR0FBQSxVQUFBLENBQUEsaUNBSjFCLENBQUMsdUJBQXVCLENBQUMsQ0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxlQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSx3QkFBQSxHQUFBLENBQUEsR0FBQSwrQkFBQSxHQUFBLENBQUEsR0FBQSx3Q0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxNQUFBLDJCQUFBLEdBQUEsaUNBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxHQUFBLDBDQUFBLEdBQUEsYUFBQSxZQUFBLFNBQUEsTUFBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLG1DQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLFlBQUEsSUFBQSxHQUFBLGFBQUEsU0FBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSx1Q0FBQSxHQUFBLFNBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSxFQUFBLEdBQUEsQ0FBQSx1QkFBQSxFQUFBLEdBQUEsQ0FBQSxhQUFBLGNBQUEsWUFBQSx5QkFBQSxHQUFBLFNBQUEsY0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsOEJBQUEsR0FBQSxDQUFBLGFBQUEsY0FBQSxZQUFBLHlCQUFBLEdBQUEsU0FBQSxpQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLGdCQUFBLHFDQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxnQkFBQSxpQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsVUFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLGdCQUFBLHFDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLFlBQUEsbUJBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLHVCQUFBLEdBQUEsT0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHNDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDZHhDLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFRSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sVUFBQSxxQkFBQSxDQUFBO0FBQW9CLFVBQUEsMkJBQUE7QUFBUSxVQUFBLHFCQUFBLENBQUE7QUFDdEMsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLHFEQUFBLEdBQUEsQ0FBQSxFQTZCQyxHQUFBLHFEQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsc0RBQUEsR0FBQSxDQUFBLEVBQUEsSUFBQSxzREFBQSxJQUFBLENBQUEsRUFBQSxJQUFBLHNEQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsc0RBQUEsSUFBQSxDQUFBO0FBOEVELFVBQUEsd0JBQUEsSUFBQSxJQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsSUFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLHNEQUFBLEdBQUEsQ0FBQTtBQWNKLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBcklJLFVBQUEseUJBQUEsV0FBQSw4QkFBQSxJQUFBRSxNQUFBLElBQUEsaUJBQUEsQ0FBQSxJQUFBLFlBQUEsSUFBQSxjQUFBLENBQUEsSUFBQSxzQkFBQSxJQUFBLFNBQUEsS0FBQSxJQUFBLG9CQUFBLFVBQUEsQ0FBQSxJQUFBLG1CQUFBLENBQUE7QUFPVSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLElBQUEsSUFBQSxlQUFBLEdBQUE7QUFBNEIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSxLQUFBLElBQUEsb0JBQUEsT0FBQSxRQUFBO0FBRXRDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxDQUFBLElBQUEsYUFBQSxJQUFBLEVBQUE7QUE4QkEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsYUFBQSxJQUFBLEVBQUE7QUErQkEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsb0JBQUEsVUFBQSxLQUFBLEVBQUE7QUFHQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxvQkFBQSxRQUFBLElBQUEsb0JBQUEsZUFBQSxJQUFBLGFBQUEsS0FBQSxFQUFBO0FBdUJBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxDQUFBLElBQUEsY0FBQSxJQUFBLHNCQUFBLEtBQUEsRUFBQTtBQU1BLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLGNBQUEsQ0FBQSxJQUFBLHNCQUFBLEtBQUEsRUFBQTtBQWdCQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxjQUFBLENBQUEsSUFBQSxzQkFBQSxLQUFBLEVBQUE7Ozs7O3FGRHRHUyw4QkFBNEIsRUFBQSxXQUFBLCtCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRWxCekMsU0FBUyxnQkFBZ0I7O0FBQXpCLElBT2E7QUFQYjs7QUFDQTtBQU1NLElBQU8sZ0JBQVAsTUFBTyxlQUFhOzt5QkFBYixnQkFBYTtNQUFBO2dFQUFiLGVBQWEsQ0FBQTs7Ozs7OztBQ1AxQixTQUFTLFlBQUFDLGlCQUFnQjtBQU16QixTQUFTLHNCQUFzQjs7QUFOL0IsSUF3QmE7QUF4QmI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBY00sSUFBTyxpQ0FBUCxNQUFPLGdDQUE4Qjs7eUJBQTlCLGlDQUE4QjtNQUFBO2lFQUE5QixnQ0FBOEIsQ0FBQTtxRUFYN0IscUJBQXFCLGdCQUFnQix1QkFBdUIsYUFBYSxFQUFBLENBQUE7Ozs7OztBQ1R2RixJQUFzQjtBQUF0Qjs7QUFBTSxJQUFnQixrQkFBaEIsTUFBK0I7TUFDMUI7TUFDQTtNQUNBO01BQ0E7TUFFQTtNQUVQLFlBQXNCLE1BQXNCO0FBQ3hDLGFBQUssT0FBTztNQUNoQjs7Ozs7O0FDZEosSUFJYTtBQUpiOzs7QUFDQTtBQUdNLElBQU8sZ0NBQVAsY0FBNkMsZ0JBQWU7TUFDdkQ7TUFFUCxjQUFBO0FBQ0ksY0FBTSxpQkFBaUIsZUFBZTtNQUMxQzs7Ozs7O0FDVEosSUFJYTtBQUpiOzs7QUFFQTtBQUVNLElBQU8sNkJBQVAsY0FBMEMsZ0JBQWU7TUFDcEQ7TUFFUCxjQUFBO0FBQ0ksY0FBTSxpQkFBaUIsYUFBYTtNQUN4Qzs7Ozs7O0FDVEosSUFJYTtBQUpiOzs7QUFDQTtBQUdNLElBQU8sNkJBQVAsY0FBMEMsZ0JBQWU7TUFDcEQ7TUFFUCxjQUFBO0FBQ0ksY0FBTSxpQkFBaUIsWUFBWTtNQUN2Qzs7Ozs7O0FDUkosSUFFc0I7QUFGdEI7OztBQUVNLElBQWdCLHlCQUFoQixjQUErQyxXQUFVO01BQ3BEO01BQ0E7TUFFUCxZQUFzQixNQUE0QjtBQUM5QyxjQUFNLElBQUk7TUFDZDs7Ozs7O0FDUkosSUFFYTtBQUZiOzs7QUFFTSxJQUFPLGlCQUFQLGNBQThCLHVCQUFzQjtNQUN0RCxjQUFBO0FBQ0ksY0FBSyxNQUFBO01BQ1Q7Ozs7IiwibmFtZXMiOlsiSW5wdXQiLCJDb21wb25lbnQiLCJJbnB1dCIsIl9jMCIsIkNvbXBvbmVudCIsIklucHV0IiwiVmlld0VuY2Fwc3VsYXRpb24iLCJmYVF1ZXN0aW9uQ2lyY2xlIiwiX2MwIiwiX2MxIiwiTWFwcGluZ1Jlc3VsdCIsIl9jMiIsIkNvbXBvbmVudCIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwiVmlld0VuY2Fwc3VsYXRpb24iLCJmYUV4Y2xhbWF0aW9uQ2lyY2xlIiwiZmFFeGNsYW1hdGlvblRyaWFuZ2xlIiwiZmFRdWVzdGlvbkNpcmNsZSIsIl9jMCIsIl9jMSIsIl9jMiIsIkluamVjdGFibGUiLCJDb21wb25lbnQiLCJFdmVudEVtaXR0ZXIiLCJJbnB1dCIsIk91dHB1dCIsIlZpZXdFbmNhcHN1bGF0aW9uIiwiZmFFeGNsYW1hdGlvbkNpcmNsZSIsImZhUXVlc3Rpb25DaXJjbGUiLCJfYzAiLCJfYzEiLCJOZ01vZHVsZSJdfQ==