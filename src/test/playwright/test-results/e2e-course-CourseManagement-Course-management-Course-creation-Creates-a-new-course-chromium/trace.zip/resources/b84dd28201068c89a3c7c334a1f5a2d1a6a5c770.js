import {
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/guard/pending-changes.guard.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
var PendingChangesGuard;
var init_pending_changes_guard = __esm({
  "src/main/webapp/app/shared/guard/pending-changes.guard.ts"() {
    PendingChangesGuard = class _PendingChangesGuard {
      translateService;
      constructor(translateService) {
        this.translateService = translateService;
      }
      canDeactivate(component) {
        const warning = component.canDeactivateWarning || this.translateService.instant("pendingChanges");
        return component.canDeactivate() ? true : confirm(warning);
      }
      static \u0275fac = function PendingChangesGuard_Factory(t) {
        return new (t || _PendingChangesGuard)(i0.\u0275\u0275inject(i1.TranslateService));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _PendingChangesGuard, factory: _PendingChangesGuard.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  PendingChangesGuard,
  init_pending_changes_guard
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2d1YXJkL3BlbmRpbmctY2hhbmdlcy5ndWFyZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDYW5EZWFjdGl2YXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFRyYW5zbGF0ZVNlcnZpY2UgfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcbmltcG9ydCB7IENvbXBvbmVudENhbkRlYWN0aXZhdGUgfSBmcm9tICdhcHAvc2hhcmVkL2d1YXJkL2Nhbi1kZWFjdGl2YXRlLm1vZGVsJztcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBQZW5kaW5nQ2hhbmdlc0d1YXJkIGltcGxlbWVudHMgQ2FuRGVhY3RpdmF0ZTxDb21wb25lbnRDYW5EZWFjdGl2YXRlPiB7XG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSB0cmFuc2xhdGVTZXJ2aWNlOiBUcmFuc2xhdGVTZXJ2aWNlKSB7fVxuXG4gICAgLyoqXG4gICAgICogRnVuY3Rpb24gd2hpY2ggcmV0dXJucyB3aGV0aGVyIGEgY29tcG9uZW50IGNhbiBiZSBkZWFjdGl2YXRlZFxuICAgICAqIEBwYXJhbSBjb21wb25lbnRcbiAgICAgKlxuICAgICAqIEByZXR1cm5zIGJvb2xlYW4gfCBPYnNlcnZhYmxlPGJvb2xlYW4+XG4gICAgICovXG4gICAgY2FuRGVhY3RpdmF0ZShjb21wb25lbnQ6IENvbXBvbmVudENhbkRlYWN0aXZhdGUpOiBib29sZWFuIHtcbiAgICAgICAgY29uc3Qgd2FybmluZyA9IGNvbXBvbmVudC5jYW5EZWFjdGl2YXRlV2FybmluZyB8fCB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgncGVuZGluZ0NoYW5nZXMnKTtcbiAgICAgICAgcmV0dXJuIGNvbXBvbmVudC5jYW5EZWFjdGl2YXRlKCkgPyB0cnVlIDogY29uZmlybSh3YXJuaW5nKTtcbiAgICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7O0FBQ0EsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyx3QkFBd0I7OztBQURqQyxJQUthO0FBTGI7O0FBS00sSUFBTyxzQkFBUCxNQUFPLHFCQUFtQjtNQUNSO01BQXBCLFlBQW9CLGtCQUFrQztBQUFsQyxhQUFBLG1CQUFBO01BQXFDO01BUXpELGNBQWMsV0FBaUM7QUFDM0MsY0FBTSxVQUFVLFVBQVUsd0JBQXdCLEtBQUssaUJBQWlCLFFBQVEsZ0JBQWdCO0FBQ2hHLGVBQU8sVUFBVSxjQUFhLElBQUssT0FBTyxRQUFRLE9BQU87TUFDN0Q7O3lCQVpTLHNCQUFtQixzQkFBQSxtQkFBQSxDQUFBO01BQUE7bUVBQW5CLHNCQUFtQixTQUFuQixxQkFBbUIsV0FBQSxZQUROLE9BQU0sQ0FBQTs7OzsiLCJuYW1lcyI6W119