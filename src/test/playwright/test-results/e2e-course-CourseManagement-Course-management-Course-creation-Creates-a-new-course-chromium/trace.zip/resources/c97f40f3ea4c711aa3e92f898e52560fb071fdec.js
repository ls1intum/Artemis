import {
  ArtemisAssessmentSharedModule,
  ScoreDisplayComponent,
  init_assessment_shared_module,
  init_score_display_component
} from "/chunk-5224NT7T.js";
import {
  ArtemisModelingEditorModule,
  ModelingComponent,
  ModelingExplanationEditorComponent,
  init_modeling_component,
  init_modeling_editor_module,
  init_modeling_explanation_editor_component
} from "/chunk-WTEGR6H3.js";
import {
  enterFullscreen,
  exitFullscreen,
  init_fullscreen_util,
  isFullScreen
} from "/chunk-KPWFZEYZ.js";
import {
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  Feedback,
  FeedbackType,
  Submission,
  __async,
  __esm,
  init_artemis_translate_pipe,
  init_course_model,
  init_feedback_model,
  init_shared_module,
  init_submission_model
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/fullscreen/fullscreen.component.ts
import { Component, ElementRef, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faCompress } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function FullscreenComponent_Case_7_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                ");
    i0.\u0275\u0275element(1, "fa-icon", 1);
    i0.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("icon", ctx_r0.faCompress);
  }
}
function FullscreenComponent_Case_8_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0);
    i0.\u0275\u0275pipe(1, "artemisTranslate");
  }
  if (rf & 2) {
    i0.\u0275\u0275textInterpolate1("\n                        ", i0.\u0275\u0275pipeBind1(1, 1, "artemisApp.modelingEditor.fullscreen.enterButtonText"), "\n                    ");
  }
}
function FullscreenComponent_Case_8_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0);
    i0.\u0275\u0275pipe(1, "artemisTranslate");
  }
  if (rf & 2) {
    i0.\u0275\u0275textInterpolate1("\n                        ", i0.\u0275\u0275pipeBind1(1, 1, "artemisApp.modelingEditor.fullscreen.exitButtonText"), "\n                    ");
  }
}
function FullscreenComponent_Case_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2, "\n                    ");
    i0.\u0275\u0275template(3, FullscreenComponent_Case_8_Conditional_3_Template, 2, 3)(4, FullscreenComponent_Case_8_Conditional_4_Template, 2, 3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(3, !ctx_r1.isFullScreen() ? 3 : 4);
  }
}
var _c0, FullscreenComponent;
var init_fullscreen_component = __esm({
  "src/main/webapp/app/shared/fullscreen/fullscreen.component.ts"() {
    init_fullscreen_util();
    init_artemis_translate_pipe();
    _c0 = ["*"];
    FullscreenComponent = class _FullscreenComponent {
      fullScreenWrapper;
      position = "top-right";
      mode = "extended";
      faCompress = faCompress;
      constructor(fullScreenWrapper) {
        this.fullScreenWrapper = fullScreenWrapper;
      }
      toggleFullscreen() {
        if (this.isFullScreen()) {
          exitFullscreen();
        } else {
          const element = this.fullScreenWrapper.nativeElement;
          enterFullscreen(element);
        }
      }
      isFullScreen() {
        return isFullScreen();
      }
      static \u0275fac = function FullscreenComponent_Factory(t) {
        return new (t || _FullscreenComponent)(i0.\u0275\u0275directiveInject(i0.ElementRef));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _FullscreenComponent, selectors: [["jhi-fullscreen"]], inputs: { position: "position", mode: "mode" }, ngContentSelectors: _c0, decls: 12, vars: 18, consts: [["type", "button", 1, "btn", "d-none", "d-sm-block", 2, "position", "absolute", 3, "ngbTooltip", "click"], [3, "icon"]], template: function FullscreenComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275projectionDef();
          i0.\u0275\u0275elementContainerStart(0);
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275projection(2);
          i0.\u0275\u0275text(3, "\n    ");
          i0.\u0275\u0275elementStart(4, "button", 0);
          i0.\u0275\u0275listener("click", function FullscreenComponent_Template_button_click_4_listener() {
            return ctx.toggleFullscreen();
          });
          i0.\u0275\u0275pipe(5, "artemisTranslate");
          i0.\u0275\u0275text(6, "\n        ");
          i0.\u0275\u0275template(7, FullscreenComponent_Case_7_Template, 3, 1)(8, FullscreenComponent_Case_8_Template, 6, 1);
          i0.\u0275\u0275text(9, "\n    ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(10, "\n");
          i0.\u0275\u0275elementContainerEnd();
          i0.\u0275\u0275text(11, "\n");
        }
        if (rf & 2) {
          let FullscreenComponent_contFlowTmp;
          i0.\u0275\u0275advance(4);
          i0.\u0275\u0275classProp("btn-primary", ctx.mode === "extended")("mb-2", ctx.mode === "extended")("btn-sm", ctx.mode === "compact")("top-left", ctx.position === "top-left")("top-right", ctx.position === "top-right")("bottom-left", ctx.position === "bottom-left")("bottom-right", ctx.position === "bottom-right");
          i0.\u0275\u0275property("ngbTooltip", i0.\u0275\u0275pipeBind1(5, 16, "artemisApp.modelingEditor.fullscreen.tooltip"));
          i0.\u0275\u0275advance(3);
          i0.\u0275\u0275conditional(7, (FullscreenComponent_contFlowTmp = ctx.mode) === "compact" ? 7 : FullscreenComponent_contFlowTmp === "extended" ? 8 : -1);
        }
      }, dependencies: [i1.NgbTooltip, i2.FaIconComponent, ArtemisTranslatePipe], styles: ["\n\n[_nghost-%COMP%] {\n  display: flex;\n  position: relative;\n  background-color: transparent;\n  width: 100%;\n  height: 100%;\n}\n[_nghost-%COMP%]:fullscreen {\n  background-color: var(--body-bg);\n}\n.absolute[_ngcontent-%COMP%] {\n  position: absolute;\n}\n.flow[_ngcontent-%COMP%] {\n  position: static;\n}\n.top-left[_ngcontent-%COMP%] {\n  top: 0;\n  left: 0;\n}\n.top-right[_ngcontent-%COMP%] {\n  top: 0;\n  right: 0;\n}\n.bottom-left[_ngcontent-%COMP%] {\n  bottom: 0;\n  left: 0;\n}\n.bottom-right[_ngcontent-%COMP%] {\n  bottom: 0;\n  right: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvZnVsbHNjcmVlbi9mdWxsc2NyZWVuLnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIjpob3N0IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG59XG5cbjpob3N0OmZ1bGxzY3JlZW4ge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWJvZHktYmcpO1xufVxuXG4uYWJzb2x1dGUge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbn1cblxuLmZsb3cge1xuICAgIHBvc2l0aW9uOiBzdGF0aWM7XG59XG5cbi50b3AtbGVmdCB7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG59XG5cbi50b3AtcmlnaHQge1xuICAgIHRvcDogMDtcbiAgICByaWdodDogMDtcbn1cblxuLmJvdHRvbS1sZWZ0IHtcbiAgICBib3R0b206IDA7XG4gICAgbGVmdDogMDtcbn1cblxuLmJvdHRvbS1yaWdodCB7XG4gICAgYm90dG9tOiAwO1xuICAgIHJpZ2h0OiAwO1xufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBO0FBQ0ksV0FBQTtBQUNBLFlBQUE7QUFDQSxvQkFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBOztBQUdKLEtBQUE7QUFDSSxvQkFBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxZQUFBOztBQUdKLENBQUE7QUFDSSxZQUFBOztBQUdKLENBQUE7QUFDSSxPQUFBO0FBQ0EsUUFBQTs7QUFHSixDQUFBO0FBQ0ksT0FBQTtBQUNBLFNBQUE7O0FBR0osQ0FBQTtBQUNJLFVBQUE7QUFDQSxRQUFBOztBQUdKLENBQUE7QUFDSSxVQUFBO0FBQ0EsU0FBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(FullscreenComponent, { className: "FullscreenComponent" });
    })();
  }
});

// src/main/webapp/app/shared/fullscreen/fullscreen.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisFullscreenModule;
var init_fullscreen_module = __esm({
  "src/main/webapp/app/shared/fullscreen/fullscreen.module.ts"() {
    init_fullscreen_component();
    init_shared_module();
    ArtemisFullscreenModule = class _ArtemisFullscreenModule {
      static \u0275fac = function ArtemisFullscreenModule_Factory(t) {
        return new (t || _ArtemisFullscreenModule)();
      };
      static \u0275mod = i02.\u0275\u0275defineNgModule({ type: _ArtemisFullscreenModule });
      static \u0275inj = i02.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule] });
    };
  }
});

// src/main/webapp/app/exercises/modeling/assess/modeling-assessment.util.ts
import { UMLElementType, UMLRelationshipType, findElement, findRelationship } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ls1intum_apollon.js?v=1d0d9ead";
function getNamesForAssessments(result, model) {
  const assessmentsNames = /* @__PURE__ */ new Map();
  for (const feedback of result.feedbacks) {
    const referencedModelType = feedback.referenceType;
    const referencedModelId = feedback.referenceId;
    if (referencedModelType in UMLElementType) {
      const element = findElement(model, referencedModelId);
      if (!element) {
        assessmentsNames[referencedModelId] = { name: "", type: "" };
        continue;
      }
      const name = element.name;
      let type;
      switch (element.type) {
        case UMLElementType.Class:
          type = "class";
          break;
        case UMLElementType.Package:
          type = "package";
          break;
        case UMLElementType.Interface:
          type = "interface";
          break;
        case UMLElementType.AbstractClass:
          type = "abstract class";
          break;
        case UMLElementType.Enumeration:
          type = "enum";
          break;
        case UMLElementType.ClassAttribute:
          type = "attribute";
          break;
        case UMLElementType.ClassMethod:
          type = "method";
          break;
        case UMLElementType.ActivityInitialNode:
          type = "initial node";
          break;
        case UMLElementType.ActivityFinalNode:
          type = "final node";
          break;
        case UMLElementType.ActivityObjectNode:
          type = "object";
          break;
        case UMLElementType.ActivityActionNode:
          type = "action";
          break;
        case UMLElementType.ActivityForkNode:
          type = "fork node";
          break;
        case UMLElementType.ActivityMergeNode:
          type = "merge node";
          break;
        default:
          type = "";
          break;
      }
      assessmentsNames[referencedModelId] = { type, name };
    } else if (referencedModelType in UMLRelationshipType) {
      const relationship = findRelationship(model, referencedModelId);
      if (!relationship) {
        assessmentsNames[referencedModelId] = { name: "", type: "" };
        continue;
      }
      const source = findElement(model, relationship.source.element)?.name ?? "?";
      const target = findElement(model, relationship.target.element)?.name ?? "?";
      const relationshipType = relationship.type;
      let type = "association";
      let relation;
      switch (relationshipType) {
        case UMLRelationshipType.ClassBidirectional:
          relation = " <-> ";
          break;
        case UMLRelationshipType.ClassUnidirectional:
          relation = " --> ";
          break;
        case UMLRelationshipType.ClassAggregation:
          relation = " --\u25C7 ";
          break;
        case UMLRelationshipType.ClassInheritance:
          relation = " --\u25B7 ";
          break;
        case UMLRelationshipType.ClassDependency:
          relation = " \u254C\u254C> ";
          break;
        case UMLRelationshipType.ClassComposition:
          relation = " --\u25C6 ";
          break;
        case UMLRelationshipType.ActivityControlFlow:
          relation = " --> ";
          type = "control flow";
          break;
        default:
          relation = " --- ";
      }
      assessmentsNames[referencedModelId] = { type, name: source + relation + target };
    } else {
      assessmentsNames[referencedModelId] = { type: referencedModelType, name: "" };
    }
  }
  return assessmentsNames;
}
function filterInvalidFeedback(feedbacks, umlModel) {
  if (!feedbacks) {
    return feedbacks;
  }
  if (!umlModel || !umlModel.elements) {
    return [];
  }
  let availableIds = Object.values(umlModel.elements).map((el) => el.id);
  if (umlModel.relationships) {
    availableIds = availableIds.concat(Object.values(umlModel.relationships).map((rel) => rel.id));
  }
  return feedbacks.filter((feedback) => availableIds.includes(feedback.referenceId));
}
var init_modeling_assessment_util = __esm({
  "src/main/webapp/app/exercises/modeling/assess/modeling-assessment.util.ts"() {
  }
});

// src/main/webapp/app/exercises/modeling/assess/modeling-assessment.component.ts
import { Component as Component2, EventEmitter, Input as Input2, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ApollonEditor, ApollonMode, UMLDiagramType, addOrUpdateAssessment } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ls1intum_apollon.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ModelingAssessmentComponent_Conditional_3_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275elementStart(1, "span");
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n            ");
  }
  if (rf & 2) {
    const ctx_r6 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275textInterpolate(ctx_r6.title);
  }
}
function ModelingAssessmentComponent_Conditional_3_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275element(1, "jhi-score-display", 7);
    i03.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r7 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("score", ctx_r7.totalScore)("maxPoints", ctx_r7.maxScore)("maxBonusPoints", ctx_r7.maxBonusPoints)("course", ctx_r7.course);
  }
}
function ModelingAssessmentComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275elementStart(1, "div", 5);
    i03.\u0275\u0275text(2, "\n            ");
    i03.\u0275\u0275template(3, ModelingAssessmentComponent_Conditional_3_Conditional_3_Template, 4, 1);
    i03.\u0275\u0275element(4, "span", 6);
    i03.\u0275\u0275text(5, "\n            ");
    i03.\u0275\u0275template(6, ModelingAssessmentComponent_Conditional_3_Conditional_6_Template, 3, 4);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(7, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275conditional(3, ctx_r1.title ? 3 : -1);
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275conditional(6, ctx_r1.displayPoints ? 6 : -1);
  }
}
function ModelingAssessmentComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n            ");
    i03.\u0275\u0275elementStart(1, "div", 8);
    i03.\u0275\u0275text(2, "\n                ");
    i03.\u0275\u0275element(3, "fa-icon", 9);
    i03.\u0275\u0275text(4, "\n            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r3 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("icon", ctx_r3.faGripLinesVertical);
  }
}
function ModelingAssessmentComponent_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275elementStart(1, "div", 10);
    i03.\u0275\u0275text(2, "\n            ");
    i03.\u0275\u0275element(3, "fa-icon", 9);
    i03.\u0275\u0275text(4, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r4 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("icon", ctx_r4.faGripLines);
  }
}
function ModelingAssessmentComponent_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275element(1, "jhi-modeling-explanation-editor", 11);
    i03.\u0275\u0275text(2, "\n    ");
  }
  if (rf & 2) {
    const ctx_r5 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("explanation", ctx_r5.explanation)("readOnly", true);
  }
}
var ModelingAssessmentComponent;
var init_modeling_assessment_component = __esm({
  "src/main/webapp/app/exercises/modeling/assess/modeling-assessment.component.ts"() {
    init_feedback_model();
    init_artemis_translate_pipe();
    init_course_model();
    init_modeling_component();
    init_modeling_assessment_util();
    init_artemis_translate_pipe();
    init_score_display_component();
    init_modeling_explanation_editor_component();
    ModelingAssessmentComponent = class _ModelingAssessmentComponent extends ModelingComponent {
      artemisTranslatePipe;
      maxScore;
      maxBonusPoints = 0;
      totalScore;
      title;
      enablePopups = true;
      displayPoints = true;
      highlightDifferences;
      feedbackChanged = new EventEmitter();
      selectionChanged = new EventEmitter();
      highlightedElements;
      elementCounts;
      course;
      set resultFeedbacks(feedback) {
        this.feedbacks = feedback;
        this.referencedFeedbacks = this.feedbacks.filter((feedbackElement) => feedbackElement.reference != void 0);
        this.updateApollonAssessments(this.referencedFeedbacks);
      }
      feedbacks;
      elementFeedback;
      referencedFeedbacks = [];
      unreferencedFeedbacks = [];
      firstCorrectionRoundColor = "#3e8acc";
      secondCorrectionRoundColor = "#ffa561";
      constructor(artemisTranslatePipe) {
        super();
        this.artemisTranslatePipe = artemisTranslatePipe;
      }
      ngAfterViewInit() {
        return __async(this, null, function* () {
          if (this.feedbacks) {
            this.referencedFeedbacks = this.feedbacks.filter((feedbackElement) => feedbackElement.reference != void 0);
            this.unreferencedFeedbacks = this.feedbacks.filter((feedbackElement) => feedbackElement.reference == void 0 && feedbackElement.type === FeedbackType.MANUAL_UNREFERENCED);
          }
          this.initializeApollonEditor();
          if (this.highlightedElements) {
            yield this.updateHighlightedElements(this.highlightedElements);
          }
          if (this.elementCounts) {
            yield this.updateElementCounts(this.elementCounts);
          }
          yield this.applyStateConfiguration();
          this.setupInteract();
        });
      }
      ngOnDestroy() {
        if (this.apollonEditor) {
          this.apollonEditor.destroy();
        }
      }
      ngOnChanges(changes) {
        return __async(this, null, function* () {
          if (changes.model && changes.model.currentValue && this.apollonEditor) {
            this.apollonEditor.model = changes.model.currentValue;
            this.handleFeedback();
          }
          if (changes.feedbacks && changes.feedbacks.currentValue && this.umlModel) {
            this.feedbacks = changes.feedbacks.currentValue;
            this.handleFeedback();
            yield this.applyStateConfiguration();
          }
          if (changes.highlightedElements) {
            this.highlightedElements = changes.highlightedElements.currentValue;
            if (this.apollonEditor) {
              yield this.applyStateConfiguration();
            }
          }
          if (changes.highlightDifferences) {
            yield this.updateApollonAssessments(this.referencedFeedbacks);
          }
        });
      }
      initializeApollonEditor() {
        if (this.apollonEditor) {
          this.apollonEditor.destroy();
        }
        this.handleFeedback();
        this.apollonEditor = new ApollonEditor(this.editorContainer.nativeElement, {
          mode: ApollonMode.Assessment,
          readonly: this.readOnly,
          model: this.umlModel,
          type: this.diagramType || UMLDiagramType.ClassDiagram,
          enablePopups: this.enablePopups
        });
        this.apollonEditor.subscribeToSelectionChange((selection) => {
          if (this.readOnly) {
            this.selectionChanged.emit(selection);
          }
        });
        if (!this.readOnly) {
          this.apollonEditor.subscribeToAssessmentChange((assessments) => {
            this.referencedFeedbacks = this.generateFeedbackFromAssessment(assessments);
            this.feedbackChanged.emit(this.referencedFeedbacks);
          });
        }
      }
      applyStateConfiguration() {
        return __async(this, null, function* () {
          if (this.highlightedElements) {
            yield this.updateHighlightedElements(this.highlightedElements);
          }
        });
      }
      generateFeedbackFromAssessment(assessments) {
        const newElementFeedback = /* @__PURE__ */ new Map();
        for (const assessment of assessments) {
          let feedback = this.elementFeedback.get(assessment.modelElementId);
          if (feedback) {
            if (feedback.credits !== assessment.score && feedback.gradingInstruction) {
              feedback.gradingInstruction = void 0;
            }
            feedback.credits = assessment.score;
            feedback.text = assessment.feedback;
            if (assessment.dropInfo && assessment.dropInfo.instruction?.id) {
              feedback.gradingInstruction = assessment.dropInfo.instruction;
            }
            if (feedback.gradingInstruction && assessment.dropInfo == void 0) {
              feedback.gradingInstruction = void 0;
            }
          } else {
            feedback = Feedback.forModeling(assessment.score, assessment.feedback, assessment.modelElementId, assessment.elementType, assessment.dropInfo);
          }
          newElementFeedback.set(assessment.modelElementId, feedback);
        }
        this.elementFeedback = newElementFeedback;
        return [...this.elementFeedback.values()];
      }
      handleFeedback() {
        this.referencedFeedbacks = filterInvalidFeedback(this.feedbacks, this.umlModel);
        this.updateElementFeedbackMapping(this.referencedFeedbacks);
        this.updateApollonAssessments(this.referencedFeedbacks);
      }
      updateElementFeedbackMapping(feedbacks) {
        if (!this.elementFeedback) {
          this.elementFeedback = /* @__PURE__ */ new Map();
        }
        if (!feedbacks) {
          return;
        }
        for (const feedback of feedbacks) {
          this.elementFeedback.set(feedback.referenceId, feedback);
        }
      }
      updateHighlightedElements(newElements) {
        return __async(this, null, function* () {
          if (!newElements) {
            newElements = /* @__PURE__ */ new Map();
          }
          if (this.apollonEditor != void 0) {
            yield this.apollonEditor.nextRender;
            const model = this.apollonEditor.model;
            for (const element of Object.values(model.elements)) {
              element.highlight = newElements.get(element.id);
            }
            for (const relationship of Object.values(model.relationships)) {
              relationship.highlight = newElements.get(relationship.id);
            }
            this.apollonEditor.model = model;
          }
        });
      }
      updateElementCounts(newElementCounts) {
        return __async(this, null, function* () {
          if (!newElementCounts) {
            return;
          }
          const elementCountMap = /* @__PURE__ */ new Map();
          newElementCounts.forEach((elementCount) => elementCountMap.set(elementCount.elementId, elementCount.numberOfOtherElements));
          if (this.apollonEditor != void 0) {
            yield this.apollonEditor.nextRender;
            const model = this.apollonEditor.model;
            for (const element of Object.values(model.elements)) {
              element.assessmentNote = this.calculateNote(elementCountMap.get(element.id));
            }
            for (const relationship of Object.values(model.relationships)) {
              relationship.assessmentNote = this.calculateNote(elementCountMap.get(relationship.id));
            }
            this.apollonEditor.model = model;
          }
        });
      }
      updateApollonAssessments(feedbacks) {
        return __async(this, null, function* () {
          if (!feedbacks || !this.umlModel) {
            return;
          }
          feedbacks.forEach((feedback) => {
            addOrUpdateAssessment(this.umlModel, {
              modelElementId: feedback.referenceId,
              elementType: feedback.referenceType,
              score: feedback.credits,
              feedback: feedback.text || void 0,
              label: this.calculateLabel(feedback),
              labelColor: this.calculateLabelColor(feedback),
              correctionStatus: this.calculateCorrectionStatusForFeedback(feedback),
              dropInfo: this.calculateDropInfo(feedback)
            });
          });
          if (this.apollonEditor) {
            yield this.apollonEditor.nextRender;
            this.apollonEditor.model = this.umlModel;
          }
        });
      }
      calculateLabel(feedback) {
        const firstCorrectionRoundText = this.artemisTranslatePipe.transform("artemisApp.assessment.diffView.correctionRoundDiffFirst");
        const secondCorrectionRoundText = this.artemisTranslatePipe.transform("artemisApp.assessment.diffView.correctionRoundDiffSecond");
        if (this.highlightDifferences) {
          return feedback.copiedFeedbackId ? firstCorrectionRoundText : secondCorrectionRoundText;
        }
        return void 0;
      }
      calculateLabelColor(feedback) {
        if (this.highlightDifferences) {
          return feedback.copiedFeedbackId ? this.firstCorrectionRoundColor : this.secondCorrectionRoundColor;
        }
        return "";
      }
      calculateNote(count) {
        if (count) {
          return this.artemisTranslatePipe.transform("artemisApp.modelingAssessment.impactWarning", { affectedSubmissionsCount: count });
        }
        return void 0;
      }
      calculateCorrectionStatusForFeedback(feedback) {
        let correctionStatusDescription = feedback.correctionStatus ? this.artemisTranslatePipe.transform("artemisApp.exampleSubmission.feedback." + feedback.correctionStatus) : feedback.correctionStatus;
        if (feedback.correctionStatus && feedback.correctionStatus !== "CORRECT") {
          correctionStatusDescription += " \u26A0\uFE0F";
        }
        let correctionStatus;
        switch (feedback.correctionStatus) {
          case "CORRECT":
            correctionStatus = "CORRECT";
            break;
          case void 0:
            correctionStatus = "NOT_VALIDATED";
            break;
          default:
            correctionStatus = "INCORRECT";
        }
        return {
          description: correctionStatusDescription,
          status: correctionStatus
        };
      }
      calculateDropInfo(feedback) {
        if (feedback.gradingInstruction) {
          const dropInfo = {};
          dropInfo.instruction = feedback.gradingInstruction;
          dropInfo.removeMessage = this.artemisTranslatePipe.transform("artemisApp.assessment.messages.removeAssessmentInstructionLink");
          dropInfo.tooltipMessage = this.artemisTranslatePipe.transform("artemisApp.exercise.assessmentInstruction") + feedback.gradingInstruction.instructionDescription;
          dropInfo.feedbackHint = this.artemisTranslatePipe.transform("artemisApp.assessment.feedbackHint");
          return dropInfo;
        }
        return void 0;
      }
      static \u0275fac = function ModelingAssessmentComponent_Factory(t) {
        return new (t || _ModelingAssessmentComponent)(i03.\u0275\u0275directiveInject(ArtemisTranslatePipe));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _ModelingAssessmentComponent, selectors: [["jhi-modeling-assessment"]], inputs: { maxScore: "maxScore", maxBonusPoints: "maxBonusPoints", totalScore: "totalScore", title: "title", enablePopups: "enablePopups", displayPoints: "displayPoints", highlightDifferences: "highlightDifferences", highlightedElements: "highlightedElements", elementCounts: "elementCounts", course: "course", resultFeedbacks: "resultFeedbacks" }, outputs: { feedbackChanged: "feedbackChanged", selectionChanged: "selectionChanged" }, features: [i03.\u0275\u0275InheritDefinitionFeature, i03.\u0275\u0275NgOnChangesFeature], decls: 14, vars: 6, consts: [[1, "modeling-assessment"], ["resizeContainer", ""], ["id", "apollon-assessment-row", 1, "apollon-row"], [1, "apollon-container"], ["editorContainer", ""], [1, "card-header", "bg-primary", "text-white"], [1, "flex-fill"], [3, "score", "maxPoints", "maxBonusPoints", "course"], [1, "draggable-right"], [3, "icon"], [1, "draggable-bottom"], [3, "explanation", "readOnly"]], template: function ModelingAssessmentComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "div", 0, 1);
          i03.\u0275\u0275text(2, "\n    ");
          i03.\u0275\u0275template(3, ModelingAssessmentComponent_Conditional_3_Template, 8, 2);
          i03.\u0275\u0275elementStart(4, "div", 2);
          i03.\u0275\u0275text(5, "\n        ");
          i03.\u0275\u0275element(6, "div", 3, 4);
          i03.\u0275\u0275text(8, "\n        ");
          i03.\u0275\u0275template(9, ModelingAssessmentComponent_Conditional_9_Template, 6, 1);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(10, "\n    ");
          i03.\u0275\u0275template(11, ModelingAssessmentComponent_Conditional_11_Template, 6, 1)(12, ModelingAssessmentComponent_Conditional_12_Template, 3, 2);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(13, "\n");
        }
        if (rf & 2) {
          i03.\u0275\u0275classProp("resizable", ctx.resizeOptions);
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275conditional(3, ctx.title || ctx.displayPoints ? 3 : -1);
          i03.\u0275\u0275advance(6);
          i03.\u0275\u0275conditional(9, ctx.resizeOptions && ctx.resizeOptions.horizontalResize ? 9 : -1);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275conditional(11, ctx.resizeOptions && ctx.resizeOptions.verticalResize ? 11 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(12, ctx.explanation ? 12 : -1);
        }
      }, dependencies: [i22.FaIconComponent, ScoreDisplayComponent, ModelingExplanationEditorComponent], styles: ["\n\n.modeling-assessment[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  flex-flow: column nowrap;\n  height: 100%;\n}\n.modeling-assessment[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  width: 100%;\n  font-size: 1rem;\n  font-weight: 500;\n}\n.resizable[_ngcontent-%COMP%] {\n  display: flex;\n}\n.resizable[_ngcontent-%COMP%]   .draggable-right[_ngcontent-%COMP%], .resizable[_ngcontent-%COMP%]   .draggable-bottom[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  min-width: 15px;\n}\n.apollon-container[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 100%;\n}\n.apollon-row[_ngcontent-%COMP%] {\n  display: flex;\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvbW9kZWxpbmcvYXNzZXNzL21vZGVsaW5nLWFzc2Vzc21lbnQuY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIiRkcmFnZ2FibGUtd2lkdGg6IDE1cHg7XG5cbi5tb2RlbGluZy1hc3Nlc3NtZW50IHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWZsb3c6IGNvbHVtbiBub3dyYXA7XG4gICAgaGVpZ2h0OiAxMDAlO1xuXG4gICAgLmNhcmQtaGVhZGVyIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgZm9udC1zaXplOiAxcmVtO1xuICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgIH1cbn1cblxuLnJlc2l6YWJsZSB7XG4gICAgZGlzcGxheTogZmxleDtcblxuICAgIC5kcmFnZ2FibGUtcmlnaHQsXG4gICAgLmRyYWdnYWJsZS1ib3R0b20ge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgbWluLXdpZHRoOiAkZHJhZ2dhYmxlLXdpZHRoO1xuICAgIH1cbn1cblxuLmFwb2xsb24tY29udGFpbmVyIHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgd2lkdGg6IDEwMCU7XG59XG5cbi5hcG9sbG9uLXJvdyB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBoZWlnaHQ6IDEwMCU7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRUEsQ0FBQTtBQUNJLFlBQUE7QUFDQSxXQUFBO0FBQ0EsYUFBQSxPQUFBO0FBQ0EsVUFBQTs7QUFFQSxDQU5KLG9CQU1JLENBQUE7QUFDSSxXQUFBO0FBQ0EsZUFBQTtBQUNBLG1CQUFBO0FBQ0EsU0FBQTtBQUNBLGFBQUE7QUFDQSxlQUFBOztBQUlSLENBQUE7QUFDSSxXQUFBOztBQUVBLENBSEosVUFHSSxDQUFBO0FBQUEsQ0FISixVQUdJLENBQUE7QUFFSSxXQUFBO0FBQ0EsZUFBQTtBQUNBLG1CQUFBO0FBQ0EsYUExQlU7O0FBOEJsQixDQUFBO0FBQ0ksVUFBQTtBQUNBLFNBQUE7O0FBR0osQ0FBQTtBQUNJLFdBQUE7QUFDQSxVQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(ModelingAssessmentComponent, { className: "ModelingAssessmentComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/modeling/assess/modeling-assessment.module.ts
import { NgModule as NgModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ModelingAssessmentModule;
var init_modeling_assessment_module = __esm({
  "src/main/webapp/app/exercises/modeling/assess/modeling-assessment.module.ts"() {
    init_modeling_assessment_component();
    init_shared_module();
    init_assessment_shared_module();
    init_modeling_editor_module();
    ModelingAssessmentModule = class _ModelingAssessmentModule {
      static \u0275fac = function ModelingAssessmentModule_Factory(t) {
        return new (t || _ModelingAssessmentModule)();
      };
      static \u0275mod = i04.\u0275\u0275defineNgModule({ type: _ModelingAssessmentModule });
      static \u0275inj = i04.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, ArtemisAssessmentSharedModule, ArtemisModelingEditorModule] });
    };
  }
});

// src/main/webapp/app/entities/modeling-submission.model.ts
var ModelingSubmission;
var init_modeling_submission_model = __esm({
  "src/main/webapp/app/entities/modeling-submission.model.ts"() {
    init_submission_model();
    ModelingSubmission = class extends Submission {
      model;
      explanationText;
      similarElements;
      constructor() {
        super("modeling");
      }
    };
  }
});

export {
  ModelingSubmission,
  init_modeling_submission_model,
  FullscreenComponent,
  init_fullscreen_component,
  getNamesForAssessments,
  filterInvalidFeedback,
  init_modeling_assessment_util,
  ModelingAssessmentComponent,
  init_modeling_assessment_component,
  ArtemisFullscreenModule,
  init_fullscreen_module,
  ModelingAssessmentModule,
  init_modeling_assessment_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2Z1bGxzY3JlZW4vZnVsbHNjcmVlbi5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9mdWxsc2NyZWVuL2Z1bGxzY3JlZW4uY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9mdWxsc2NyZWVuL2Z1bGxzY3JlZW4ubW9kdWxlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvbW9kZWxpbmcvYXNzZXNzL21vZGVsaW5nLWFzc2Vzc21lbnQudXRpbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL21vZGVsaW5nL2Fzc2Vzcy9tb2RlbGluZy1hc3Nlc3NtZW50LmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL21vZGVsaW5nL2Fzc2Vzcy9tb2RlbGluZy1hc3Nlc3NtZW50LmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvbW9kZWxpbmcvYXNzZXNzL21vZGVsaW5nLWFzc2Vzc21lbnQubW9kdWxlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9tb2RlbGluZy1zdWJtaXNzaW9uLm1vZGVsLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgRWxlbWVudFJlZiwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGZhQ29tcHJlc3MgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgZW50ZXJGdWxsc2NyZWVuLCBleGl0RnVsbHNjcmVlbiwgaXNGdWxsU2NyZWVuIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2Z1bGxzY3JlZW4udXRpbCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWZ1bGxzY3JlZW4nLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9mdWxsc2NyZWVuLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9mdWxsc2NyZWVuLnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgRnVsbHNjcmVlbkNvbXBvbmVudCB7XG4gICAgQElucHV0KClcbiAgICBwb3NpdGlvbjogJ3RvcC1sZWZ0JyB8ICd0b3AtcmlnaHQnIHwgJ2JvdHRvbS1sZWZ0JyB8ICdib3R0b20tcmlnaHQnID0gJ3RvcC1yaWdodCc7XG5cbiAgICBASW5wdXQoKVxuICAgIG1vZGU6ICdjb21wYWN0JyB8ICdleHRlbmRlZCcgPSAnZXh0ZW5kZWQnO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUNvbXByZXNzID0gZmFDb21wcmVzcztcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgZnVsbFNjcmVlbldyYXBwZXI6IEVsZW1lbnRSZWYpIHt9XG5cbiAgICAvKipcbiAgICAgKiBjaGVjayBjdXJyZW50IHN0YXRlIGFuZCB0b2dnbGUgZnVsbHNjcmVlblxuICAgICAqL1xuICAgIHRvZ2dsZUZ1bGxzY3JlZW4oKSB7XG4gICAgICAgIGlmICh0aGlzLmlzRnVsbFNjcmVlbigpKSB7XG4gICAgICAgICAgICBleGl0RnVsbHNjcmVlbigpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgZWxlbWVudDogYW55ID0gdGhpcy5mdWxsU2NyZWVuV3JhcHBlci5uYXRpdmVFbGVtZW50O1xuICAgICAgICAgICAgZW50ZXJGdWxsc2NyZWVuKGVsZW1lbnQpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgaXNGdWxsU2NyZWVuKCkge1xuICAgICAgICByZXR1cm4gaXNGdWxsU2NyZWVuKCk7XG4gICAgfVxufVxuIiwiPG5nLWNvbnRhaW5lcj5cbiAgICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG4gICAgPGJ1dHRvblxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgY2xhc3M9XCJidG4gZC1ub25lIGQtc20tYmxvY2tcIlxuICAgICAgICBzdHlsZT1cInBvc2l0aW9uOiBhYnNvbHV0ZVwiXG4gICAgICAgIFtjbGFzcy5idG4tcHJpbWFyeV09XCJtb2RlID09PSAnZXh0ZW5kZWQnXCJcbiAgICAgICAgW2NsYXNzLm1iLTJdPVwibW9kZSA9PT0gJ2V4dGVuZGVkJ1wiXG4gICAgICAgIFtjbGFzcy5idG4tc21dPVwibW9kZSA9PT0gJ2NvbXBhY3QnXCJcbiAgICAgICAgW2NsYXNzLnRvcC1sZWZ0XT1cInBvc2l0aW9uID09PSAndG9wLWxlZnQnXCJcbiAgICAgICAgW2NsYXNzLnRvcC1yaWdodF09XCJwb3NpdGlvbiA9PT0gJ3RvcC1yaWdodCdcIlxuICAgICAgICBbY2xhc3MuYm90dG9tLWxlZnRdPVwicG9zaXRpb24gPT09ICdib3R0b20tbGVmdCdcIlxuICAgICAgICBbY2xhc3MuYm90dG9tLXJpZ2h0XT1cInBvc2l0aW9uID09PSAnYm90dG9tLXJpZ2h0J1wiXG4gICAgICAgIChjbGljayk9XCJ0b2dnbGVGdWxsc2NyZWVuKClcIlxuICAgICAgICBbbmdiVG9vbHRpcF09XCInYXJ0ZW1pc0FwcC5tb2RlbGluZ0VkaXRvci5mdWxsc2NyZWVuLnRvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiXG4gICAgPlxuICAgICAgICBAc3dpdGNoIChtb2RlKSB7XG4gICAgICAgICAgICBAY2FzZSAoJ2NvbXBhY3QnKSB7XG4gICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFDb21wcmVzc1wiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBjYXNlICgnZXh0ZW5kZWQnKSB7XG4gICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoIWlzRnVsbFNjcmVlbigpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5tb2RlbGluZ0VkaXRvci5mdWxsc2NyZWVuLmVudGVyQnV0dG9uVGV4dCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAubW9kZWxpbmdFZGl0b3IuZnVsbHNjcmVlbi5leGl0QnV0dG9uVGV4dCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICA8L2J1dHRvbj5cbjwvbmctY29udGFpbmVyPlxuIiwiaW1wb3J0IHsgRnVsbHNjcmVlbkNvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvZnVsbHNjcmVlbi9mdWxsc2NyZWVuLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW0FydGVtaXNTaGFyZWRNb2R1bGVdLFxuICAgIGRlY2xhcmF0aW9uczogW0Z1bGxzY3JlZW5Db21wb25lbnRdLFxuICAgIGV4cG9ydHM6IFtGdWxsc2NyZWVuQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc0Z1bGxzY3JlZW5Nb2R1bGUge31cbiIsImltcG9ydCB7IFJlc3VsdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9yZXN1bHQubW9kZWwnO1xuaW1wb3J0IHsgVU1MRWxlbWVudFR5cGUsIFVNTE1vZGVsQ29tcGF0LCBVTUxSZWxhdGlvbnNoaXBUeXBlLCBmaW5kRWxlbWVudCwgZmluZFJlbGF0aW9uc2hpcCB9IGZyb20gJ0BsczFpbnR1bS9hcG9sbG9uJztcbmltcG9ydCB7IEZlZWRiYWNrIH0gZnJvbSAnYXBwL2VudGl0aWVzL2ZlZWRiYWNrLm1vZGVsJztcblxuLyoqXG4gKiBDcmVhdGVzIHRoZSBsYWJlbHMgZm9yIHRoZSBhc3Nlc3NtZW50IGVsZW1lbnRzIGZvciBkaXNwbGF5aW5nIHRoZW0gaW4gdGhlIG1vZGVsaW5nIGFuZCBhc3Nlc3NtZW50IGVkaXRvci5cbiAqL1xuLy8gVE9ETzogZGVmaW5lIGEgbWFwcGluZyBvciBzaW1wbGlmeSB0aGlzIGNvbXBsZXggbW9uc3RlciBpbiBhIGFub3RoZXIgd2F5IHNvIHRoYXQgd2UgY2FuIHN1cHBvcnQgb3RoZXIgZGlhZ3JhbSB0eXBlcyBhcyB3ZWxsXG5leHBvcnQgZnVuY3Rpb24gZ2V0TmFtZXNGb3JBc3Nlc3NtZW50cyhyZXN1bHQ6IFJlc3VsdCwgbW9kZWw6IFVNTE1vZGVsQ29tcGF0KTogTWFwPHN0cmluZywgTWFwPHN0cmluZywgc3RyaW5nPj4ge1xuICAgIGNvbnN0IGFzc2Vzc21lbnRzTmFtZXMgPSBuZXcgTWFwPHN0cmluZywgTWFwPHN0cmluZywgc3RyaW5nPj4oKTtcbiAgICBmb3IgKGNvbnN0IGZlZWRiYWNrIG9mIHJlc3VsdC5mZWVkYmFja3MhKSB7XG4gICAgICAgIGNvbnN0IHJlZmVyZW5jZWRNb2RlbFR5cGUgPSBmZWVkYmFjay5yZWZlcmVuY2VUeXBlISBhcyBVTUxFbGVtZW50VHlwZTtcbiAgICAgICAgY29uc3QgcmVmZXJlbmNlZE1vZGVsSWQgPSBmZWVkYmFjay5yZWZlcmVuY2VJZCE7XG4gICAgICAgIGlmIChyZWZlcmVuY2VkTW9kZWxUeXBlIGluIFVNTEVsZW1lbnRUeXBlKSB7XG4gICAgICAgICAgICBjb25zdCBlbGVtZW50ID0gZmluZEVsZW1lbnQobW9kZWwsIHJlZmVyZW5jZWRNb2RlbElkKTtcbiAgICAgICAgICAgIGlmICghZWxlbWVudCkge1xuICAgICAgICAgICAgICAgIC8vIHByZXZlbnQgZXJyb3JzIHdoZW4gZWxlbWVudCBjb3VsZCBub3QgYmUgZm91bmQsIHNob3VsZCBuZXZlciBoYXBwZW5cbiAgICAgICAgICAgICAgICBhc3Nlc3NtZW50c05hbWVzW3JlZmVyZW5jZWRNb2RlbElkXSA9IHsgbmFtZTogJycsIHR5cGU6ICcnIH07XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IG5hbWUgPSBlbGVtZW50Lm5hbWU7XG4gICAgICAgICAgICBsZXQgdHlwZTogc3RyaW5nO1xuICAgICAgICAgICAgc3dpdGNoIChlbGVtZW50LnR5cGUpIHtcbiAgICAgICAgICAgICAgICBjYXNlIFVNTEVsZW1lbnRUeXBlLkNsYXNzOlxuICAgICAgICAgICAgICAgICAgICB0eXBlID0gJ2NsYXNzJztcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBVTUxFbGVtZW50VHlwZS5QYWNrYWdlOlxuICAgICAgICAgICAgICAgICAgICB0eXBlID0gJ3BhY2thZ2UnO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIFVNTEVsZW1lbnRUeXBlLkludGVyZmFjZTpcbiAgICAgICAgICAgICAgICAgICAgdHlwZSA9ICdpbnRlcmZhY2UnO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIFVNTEVsZW1lbnRUeXBlLkFic3RyYWN0Q2xhc3M6XG4gICAgICAgICAgICAgICAgICAgIHR5cGUgPSAnYWJzdHJhY3QgY2xhc3MnO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIFVNTEVsZW1lbnRUeXBlLkVudW1lcmF0aW9uOlxuICAgICAgICAgICAgICAgICAgICB0eXBlID0gJ2VudW0nO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIFVNTEVsZW1lbnRUeXBlLkNsYXNzQXR0cmlidXRlOlxuICAgICAgICAgICAgICAgICAgICB0eXBlID0gJ2F0dHJpYnV0ZSc7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgVU1MRWxlbWVudFR5cGUuQ2xhc3NNZXRob2Q6XG4gICAgICAgICAgICAgICAgICAgIHR5cGUgPSAnbWV0aG9kJztcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBVTUxFbGVtZW50VHlwZS5BY3Rpdml0eUluaXRpYWxOb2RlOlxuICAgICAgICAgICAgICAgICAgICB0eXBlID0gJ2luaXRpYWwgbm9kZSc7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgVU1MRWxlbWVudFR5cGUuQWN0aXZpdHlGaW5hbE5vZGU6XG4gICAgICAgICAgICAgICAgICAgIHR5cGUgPSAnZmluYWwgbm9kZSc7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgVU1MRWxlbWVudFR5cGUuQWN0aXZpdHlPYmplY3ROb2RlOlxuICAgICAgICAgICAgICAgICAgICB0eXBlID0gJ29iamVjdCc7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgVU1MRWxlbWVudFR5cGUuQWN0aXZpdHlBY3Rpb25Ob2RlOlxuICAgICAgICAgICAgICAgICAgICB0eXBlID0gJ2FjdGlvbic7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgVU1MRWxlbWVudFR5cGUuQWN0aXZpdHlGb3JrTm9kZTpcbiAgICAgICAgICAgICAgICAgICAgdHlwZSA9ICdmb3JrIG5vZGUnO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIFVNTEVsZW1lbnRUeXBlLkFjdGl2aXR5TWVyZ2VOb2RlOlxuICAgICAgICAgICAgICAgICAgICB0eXBlID0gJ21lcmdlIG5vZGUnO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICB0eXBlID0gJyc7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYXNzZXNzbWVudHNOYW1lc1tyZWZlcmVuY2VkTW9kZWxJZF0gPSB7IHR5cGUsIG5hbWUgfTtcbiAgICAgICAgfSBlbHNlIGlmIChyZWZlcmVuY2VkTW9kZWxUeXBlIGluIFVNTFJlbGF0aW9uc2hpcFR5cGUpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlbGF0aW9uc2hpcCA9IGZpbmRSZWxhdGlvbnNoaXAobW9kZWwsIHJlZmVyZW5jZWRNb2RlbElkKTtcbiAgICAgICAgICAgIGlmICghcmVsYXRpb25zaGlwKSB7XG4gICAgICAgICAgICAgICAgLy8gcHJldmVudCBlcnJvcnMgd2hlbiByZWxhdGlvbnNoaXAgY291bGQgbm90IGJlIGZvdW5kLCBzaG91bGQgbmV2ZXIgaGFwcGVuXG4gICAgICAgICAgICAgICAgYXNzZXNzbWVudHNOYW1lc1tyZWZlcmVuY2VkTW9kZWxJZF0gPSB7IG5hbWU6ICcnLCB0eXBlOiAnJyB9O1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3Qgc291cmNlID0gZmluZEVsZW1lbnQobW9kZWwsIHJlbGF0aW9uc2hpcC5zb3VyY2UuZWxlbWVudCk/Lm5hbWUgPz8gJz8nO1xuICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gZmluZEVsZW1lbnQobW9kZWwsIHJlbGF0aW9uc2hpcC50YXJnZXQuZWxlbWVudCk/Lm5hbWUgPz8gJz8nO1xuICAgICAgICAgICAgY29uc3QgcmVsYXRpb25zaGlwVHlwZSA9IHJlbGF0aW9uc2hpcC50eXBlO1xuICAgICAgICAgICAgbGV0IHR5cGUgPSAnYXNzb2NpYXRpb24nO1xuICAgICAgICAgICAgbGV0IHJlbGF0aW9uOiBzdHJpbmc7XG4gICAgICAgICAgICBzd2l0Y2ggKHJlbGF0aW9uc2hpcFR5cGUpIHtcbiAgICAgICAgICAgICAgICBjYXNlIFVNTFJlbGF0aW9uc2hpcFR5cGUuQ2xhc3NCaWRpcmVjdGlvbmFsOlxuICAgICAgICAgICAgICAgICAgICByZWxhdGlvbiA9ICcgPC0+ICc7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgVU1MUmVsYXRpb25zaGlwVHlwZS5DbGFzc1VuaWRpcmVjdGlvbmFsOlxuICAgICAgICAgICAgICAgICAgICByZWxhdGlvbiA9ICcgLS0+ICc7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgVU1MUmVsYXRpb25zaGlwVHlwZS5DbGFzc0FnZ3JlZ2F0aW9uOlxuICAgICAgICAgICAgICAgICAgICByZWxhdGlvbiA9ICcgLS3il4cgJztcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBVTUxSZWxhdGlvbnNoaXBUeXBlLkNsYXNzSW5oZXJpdGFuY2U6XG4gICAgICAgICAgICAgICAgICAgIHJlbGF0aW9uID0gJyAtLeKWtyAnO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIFVNTFJlbGF0aW9uc2hpcFR5cGUuQ2xhc3NEZXBlbmRlbmN5OlxuICAgICAgICAgICAgICAgICAgICByZWxhdGlvbiA9ICcg4pWM4pWMPiAnO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIFVNTFJlbGF0aW9uc2hpcFR5cGUuQ2xhc3NDb21wb3NpdGlvbjpcbiAgICAgICAgICAgICAgICAgICAgcmVsYXRpb24gPSAnIC0t4peGICc7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgVU1MUmVsYXRpb25zaGlwVHlwZS5BY3Rpdml0eUNvbnRyb2xGbG93OlxuICAgICAgICAgICAgICAgICAgICByZWxhdGlvbiA9ICcgLS0+ICc7XG4gICAgICAgICAgICAgICAgICAgIHR5cGUgPSAnY29udHJvbCBmbG93JztcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgcmVsYXRpb24gPSAnIC0tLSAnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYXNzZXNzbWVudHNOYW1lc1tyZWZlcmVuY2VkTW9kZWxJZF0gPSB7IHR5cGUsIG5hbWU6IHNvdXJjZSArIHJlbGF0aW9uICsgdGFyZ2V0IH07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBhc3Nlc3NtZW50c05hbWVzW3JlZmVyZW5jZWRNb2RlbElkXSA9IHsgdHlwZTogcmVmZXJlbmNlZE1vZGVsVHlwZSwgbmFtZTogJycgfTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gYXNzZXNzbWVudHNOYW1lcztcbn1cblxuLyoqXG4gKiBSZW1vdmVzIGZlZWRiYWNrIGVsZW1lbnRzIGZvciB3aGljaCB0aGUgY29ycmVzcG9uZGluZyBtb2RlbCBlbGVtZW50IGRvZXMgbm90IGV4aXN0IGluIHRoZSBtb2RlbCBhbnltb3JlLlxuICogQHBhcmFtIGZlZWRiYWNrcyB0aGUgbGlzdCBvZiBmZWVkYmFjayB0byBmaWx0ZXJcbiAqIEBwYXJhbSB1bWxNb2RlbCB0aGUgVU1MIG1vZGVsIGNvbnRhaW5pbmcgdGhlIHJlZmVyZW5jZXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbHRlckludmFsaWRGZWVkYmFjayhmZWVkYmFja3M6IEZlZWRiYWNrW10sIHVtbE1vZGVsOiBVTUxNb2RlbENvbXBhdCk6IEZlZWRiYWNrW10ge1xuICAgIGlmICghZmVlZGJhY2tzKSB7XG4gICAgICAgIHJldHVybiBmZWVkYmFja3M7XG4gICAgfVxuICAgIGlmICghdW1sTW9kZWwgfHwgIXVtbE1vZGVsLmVsZW1lbnRzKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG5cbiAgICBsZXQgYXZhaWxhYmxlSWRzOiBzdHJpbmdbXSA9IE9iamVjdC52YWx1ZXModW1sTW9kZWwuZWxlbWVudHMpLm1hcCgoZWwpID0+IGVsLmlkKTtcbiAgICBpZiAodW1sTW9kZWwucmVsYXRpb25zaGlwcykge1xuICAgICAgICBhdmFpbGFibGVJZHMgPSBhdmFpbGFibGVJZHMuY29uY2F0KE9iamVjdC52YWx1ZXModW1sTW9kZWwucmVsYXRpb25zaGlwcykubWFwKChyZWwpID0+IHJlbC5pZCkpO1xuICAgIH1cbiAgICByZXR1cm4gZmVlZGJhY2tzLmZpbHRlcigoZmVlZGJhY2spID0+IGF2YWlsYWJsZUlkcy5pbmNsdWRlcyhmZWVkYmFjay5yZWZlcmVuY2VJZCEpKTtcbn1cbiIsImltcG9ydCB7IEFmdGVyVmlld0luaXQsIENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT25DaGFuZ2VzLCBPbkRlc3Ryb3ksIE91dHB1dCwgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQXBvbGxvbkVkaXRvciwgQXBvbGxvbk1vZGUsIEFzc2Vzc21lbnQsIFNlbGVjdGlvbiwgVU1MRGlhZ3JhbVR5cGUsIFVNTEVsZW1lbnRUeXBlLCBVTUxNb2RlbCwgVU1MUmVsYXRpb25zaGlwVHlwZSwgYWRkT3JVcGRhdGVBc3Nlc3NtZW50IH0gZnJvbSAnQGxzMWludHVtL2Fwb2xsb24nO1xuaW1wb3J0IHsgRmVlZGJhY2ssIEZlZWRiYWNrVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9mZWVkYmFjay5tb2RlbCc7XG5pbXBvcnQgeyBNb2RlbEVsZW1lbnRDb3VudCB9IGZyb20gJ2FwcC9lbnRpdGllcy9tb2RlbGluZy1zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IEFydGVtaXNUcmFuc2xhdGVQaXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9waXBlcy9hcnRlbWlzLXRyYW5zbGF0ZS5waXBlJztcbmltcG9ydCB7IENvdXJzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb3Vyc2UubW9kZWwnO1xuaW1wb3J0IHsgR3JhZGluZ0luc3RydWN0aW9uIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvc3RydWN0dXJlZC1ncmFkaW5nLWNyaXRlcmlvbi9ncmFkaW5nLWluc3RydWN0aW9uLm1vZGVsJztcbmltcG9ydCB7IE1vZGVsaW5nQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9tb2RlbGluZy9zaGFyZWQvbW9kZWxpbmcuY29tcG9uZW50JztcbmltcG9ydCB7IGZpbHRlckludmFsaWRGZWVkYmFjayB9IGZyb20gJ2FwcC9leGVyY2lzZXMvbW9kZWxpbmcvYXNzZXNzL21vZGVsaW5nLWFzc2Vzc21lbnQudXRpbCc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgRHJvcEluZm8ge1xuICAgIGluc3RydWN0aW9uOiBHcmFkaW5nSW5zdHJ1Y3Rpb247XG4gICAgdG9vbHRpcE1lc3NhZ2U6IHN0cmluZztcbiAgICByZW1vdmVNZXNzYWdlOiBzdHJpbmc7XG4gICAgZmVlZGJhY2tIaW50OiBzdHJpbmc7XG59XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLW1vZGVsaW5nLWFzc2Vzc21lbnQnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9tb2RlbGluZy1hc3Nlc3NtZW50LmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9tb2RlbGluZy1hc3Nlc3NtZW50LmNvbXBvbmVudC5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIE1vZGVsaW5nQXNzZXNzbWVudENvbXBvbmVudCBleHRlbmRzIE1vZGVsaW5nQ29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95LCBPbkNoYW5nZXMge1xuICAgIEBJbnB1dCgpIG1heFNjb3JlOiBudW1iZXI7XG4gICAgQElucHV0KCkgbWF4Qm9udXNQb2ludHMgPSAwO1xuICAgIEBJbnB1dCgpIHRvdGFsU2NvcmU6IG51bWJlcjtcbiAgICBASW5wdXQoKSB0aXRsZTogc3RyaW5nO1xuICAgIEBJbnB1dCgpIGVuYWJsZVBvcHVwcyA9IHRydWU7XG4gICAgQElucHV0KCkgZGlzcGxheVBvaW50cyA9IHRydWU7XG4gICAgQElucHV0KCkgaGlnaGxpZ2h0RGlmZmVyZW5jZXM6IGJvb2xlYW47XG5cbiAgICBAT3V0cHV0KCkgZmVlZGJhY2tDaGFuZ2VkID0gbmV3IEV2ZW50RW1pdHRlcjxGZWVkYmFja1tdPigpO1xuICAgIEBPdXRwdXQoKSBzZWxlY3Rpb25DaGFuZ2VkID0gbmV3IEV2ZW50RW1pdHRlcjxTZWxlY3Rpb24+KCk7XG5cbiAgICBASW5wdXQoKSBoaWdobGlnaHRlZEVsZW1lbnRzOiBNYXA8c3RyaW5nLCBzdHJpbmc+OyAvLyBtYXAgZWxlbWVudElkIC0+IGhpZ2hsaWdodCBjb2xvclxuICAgIEBJbnB1dCgpIGVsZW1lbnRDb3VudHM/OiBNb2RlbEVsZW1lbnRDb3VudFtdO1xuICAgIEBJbnB1dCgpIGNvdXJzZT86IENvdXJzZTtcblxuICAgIEBJbnB1dCgpIHNldCByZXN1bHRGZWVkYmFja3MoZmVlZGJhY2s6IEZlZWRiYWNrW10pIHtcbiAgICAgICAgdGhpcy5mZWVkYmFja3MgPSBmZWVkYmFjaztcbiAgICAgICAgdGhpcy5yZWZlcmVuY2VkRmVlZGJhY2tzID0gdGhpcy5mZWVkYmFja3MuZmlsdGVyKChmZWVkYmFja0VsZW1lbnQpID0+IGZlZWRiYWNrRWxlbWVudC5yZWZlcmVuY2UgIT0gdW5kZWZpbmVkKTtcbiAgICAgICAgdGhpcy51cGRhdGVBcG9sbG9uQXNzZXNzbWVudHModGhpcy5yZWZlcmVuY2VkRmVlZGJhY2tzKTtcbiAgICB9XG5cbiAgICBmZWVkYmFja3M6IEZlZWRiYWNrW107XG4gICAgZWxlbWVudEZlZWRiYWNrOiBNYXA8c3RyaW5nLCBGZWVkYmFjaz47IC8vIG1hcCBlbGVtZW50LmlkIC0tPiBGZWVkYmFja1xuICAgIHJlZmVyZW5jZWRGZWVkYmFja3M6IEZlZWRiYWNrW10gPSBbXTtcbiAgICB1bnJlZmVyZW5jZWRGZWVkYmFja3M6IEZlZWRiYWNrW10gPSBbXTtcbiAgICBmaXJzdENvcnJlY3Rpb25Sb3VuZENvbG9yID0gJyMzZThhY2MnO1xuICAgIHNlY29uZENvcnJlY3Rpb25Sb3VuZENvbG9yID0gJyNmZmE1NjEnO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBhcnRlbWlzVHJhbnNsYXRlUGlwZTogQXJ0ZW1pc1RyYW5zbGF0ZVBpcGUpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICB9XG5cbiAgICBhc3luYyBuZ0FmdGVyVmlld0luaXQoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgICAgIGlmICh0aGlzLmZlZWRiYWNrcykge1xuICAgICAgICAgICAgdGhpcy5yZWZlcmVuY2VkRmVlZGJhY2tzID0gdGhpcy5mZWVkYmFja3MuZmlsdGVyKChmZWVkYmFja0VsZW1lbnQpID0+IGZlZWRiYWNrRWxlbWVudC5yZWZlcmVuY2UgIT0gdW5kZWZpbmVkKTtcbiAgICAgICAgICAgIHRoaXMudW5yZWZlcmVuY2VkRmVlZGJhY2tzID0gdGhpcy5mZWVkYmFja3MuZmlsdGVyKFxuICAgICAgICAgICAgICAgIChmZWVkYmFja0VsZW1lbnQpID0+IGZlZWRiYWNrRWxlbWVudC5yZWZlcmVuY2UgPT0gdW5kZWZpbmVkICYmIGZlZWRiYWNrRWxlbWVudC50eXBlID09PSBGZWVkYmFja1R5cGUuTUFOVUFMX1VOUkVGRVJFTkNFRCxcbiAgICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5pbml0aWFsaXplQXBvbGxvbkVkaXRvcigpO1xuICAgICAgICBpZiAodGhpcy5oaWdobGlnaHRlZEVsZW1lbnRzKSB7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLnVwZGF0ZUhpZ2hsaWdodGVkRWxlbWVudHModGhpcy5oaWdobGlnaHRlZEVsZW1lbnRzKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5lbGVtZW50Q291bnRzKSB7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLnVwZGF0ZUVsZW1lbnRDb3VudHModGhpcy5lbGVtZW50Q291bnRzKTtcbiAgICAgICAgfVxuICAgICAgICBhd2FpdCB0aGlzLmFwcGx5U3RhdGVDb25maWd1cmF0aW9uKCk7XG4gICAgICAgIHRoaXMuc2V0dXBJbnRlcmFjdCgpO1xuICAgIH1cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICBpZiAodGhpcy5hcG9sbG9uRWRpdG9yKSB7XG4gICAgICAgICAgICB0aGlzLmFwb2xsb25FZGl0b3IuZGVzdHJveSgpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgYXN5bmMgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IFByb21pc2U8dm9pZD4ge1xuICAgICAgICBpZiAoY2hhbmdlcy5tb2RlbCAmJiBjaGFuZ2VzLm1vZGVsLmN1cnJlbnRWYWx1ZSAmJiB0aGlzLmFwb2xsb25FZGl0b3IpIHtcbiAgICAgICAgICAgIHRoaXMuYXBvbGxvbkVkaXRvciEubW9kZWwgPSBjaGFuZ2VzLm1vZGVsLmN1cnJlbnRWYWx1ZTtcbiAgICAgICAgICAgIHRoaXMuaGFuZGxlRmVlZGJhY2soKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY2hhbmdlcy5mZWVkYmFja3MgJiYgY2hhbmdlcy5mZWVkYmFja3MuY3VycmVudFZhbHVlICYmIHRoaXMudW1sTW9kZWwpIHtcbiAgICAgICAgICAgIHRoaXMuZmVlZGJhY2tzID0gY2hhbmdlcy5mZWVkYmFja3MuY3VycmVudFZhbHVlO1xuICAgICAgICAgICAgdGhpcy5oYW5kbGVGZWVkYmFjaygpO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5hcHBseVN0YXRlQ29uZmlndXJhdGlvbigpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjaGFuZ2VzLmhpZ2hsaWdodGVkRWxlbWVudHMpIHtcbiAgICAgICAgICAgIHRoaXMuaGlnaGxpZ2h0ZWRFbGVtZW50cyA9IGNoYW5nZXMuaGlnaGxpZ2h0ZWRFbGVtZW50cy5jdXJyZW50VmFsdWU7XG5cbiAgICAgICAgICAgIGlmICh0aGlzLmFwb2xsb25FZGl0b3IpIHtcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmFwcGx5U3RhdGVDb25maWd1cmF0aW9uKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNoYW5nZXMuaGlnaGxpZ2h0RGlmZmVyZW5jZXMpIHtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMudXBkYXRlQXBvbGxvbkFzc2Vzc21lbnRzKHRoaXMucmVmZXJlbmNlZEZlZWRiYWNrcyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBJbml0aWFsaXplcyB0aGUgQXBvbGxvbiBlZGl0b3IgYWZ0ZXIgdXBkYXRpbmcgdGhlIEZlZWRiYWNrIGFjY29yZGluZ2x5LiBJdCBhbHNvIHN1YnNjcmliZXMgdG8gY2hhbmdlXG4gICAgICogZXZlbnRzIG9mIEFwb2xsb24gYW5kIHBhc3NlcyB0aGVtIG9uIHRvIHBhcmVudCBjb21wb25lbnRzLlxuICAgICAqL1xuICAgIHByaXZhdGUgaW5pdGlhbGl6ZUFwb2xsb25FZGl0b3IoKSB7XG4gICAgICAgIGlmICh0aGlzLmFwb2xsb25FZGl0b3IpIHtcbiAgICAgICAgICAgIHRoaXMuYXBvbGxvbkVkaXRvci5kZXN0cm95KCk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmhhbmRsZUZlZWRiYWNrKCk7XG5cbiAgICAgICAgdGhpcy5hcG9sbG9uRWRpdG9yID0gbmV3IEFwb2xsb25FZGl0b3IodGhpcy5lZGl0b3JDb250YWluZXIubmF0aXZlRWxlbWVudCwge1xuICAgICAgICAgICAgbW9kZTogQXBvbGxvbk1vZGUuQXNzZXNzbWVudCxcbiAgICAgICAgICAgIHJlYWRvbmx5OiB0aGlzLnJlYWRPbmx5LFxuICAgICAgICAgICAgbW9kZWw6IHRoaXMudW1sTW9kZWwsXG4gICAgICAgICAgICB0eXBlOiB0aGlzLmRpYWdyYW1UeXBlIHx8IFVNTERpYWdyYW1UeXBlLkNsYXNzRGlhZ3JhbSxcbiAgICAgICAgICAgIGVuYWJsZVBvcHVwczogdGhpcy5lbmFibGVQb3B1cHMsXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmFwb2xsb25FZGl0b3IhLnN1YnNjcmliZVRvU2VsZWN0aW9uQ2hhbmdlKChzZWxlY3Rpb246IFNlbGVjdGlvbikgPT4ge1xuICAgICAgICAgICAgaWYgKHRoaXMucmVhZE9ubHkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdGlvbkNoYW5nZWQuZW1pdChzZWxlY3Rpb24pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKCF0aGlzLnJlYWRPbmx5KSB7XG4gICAgICAgICAgICB0aGlzLmFwb2xsb25FZGl0b3IhLnN1YnNjcmliZVRvQXNzZXNzbWVudENoYW5nZSgoYXNzZXNzbWVudHM6IEFzc2Vzc21lbnRbXSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMucmVmZXJlbmNlZEZlZWRiYWNrcyA9IHRoaXMuZ2VuZXJhdGVGZWVkYmFja0Zyb21Bc3Nlc3NtZW50KGFzc2Vzc21lbnRzKTtcbiAgICAgICAgICAgICAgICB0aGlzLmZlZWRiYWNrQ2hhbmdlZC5lbWl0KHRoaXMucmVmZXJlbmNlZEZlZWRiYWNrcyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgYXN5bmMgYXBwbHlTdGF0ZUNvbmZpZ3VyYXRpb24oKSB7XG4gICAgICAgIGlmICh0aGlzLmhpZ2hsaWdodGVkRWxlbWVudHMpIHtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMudXBkYXRlSGlnaGxpZ2h0ZWRFbGVtZW50cyh0aGlzLmhpZ2hsaWdodGVkRWxlbWVudHMpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0cyB0aGUgYXNzZXNzbWVudHMgZnJvbSBBcG9sbG9uIGFuZCBjcmVhdGVzL3VwZGF0ZXMgdGhlIGNvcnJlc3BvbmRpbmcgRmVlZGJhY2sgZW50cmllcyBpbiB0aGVcbiAgICAgKiBlbGVtZW50IGZlZWRiYWNrIG1hcHBpbmcuXG4gICAgICogUmV0dXJucyBhbiBhcnJheSBjb250YWluaW5nIGFsbCBmZWVkYmFjayBlbnRyaWVzIGZyb20gdGhlIG1hcHBpbmcuXG4gICAgICovXG4gICAgZ2VuZXJhdGVGZWVkYmFja0Zyb21Bc3Nlc3NtZW50KGFzc2Vzc21lbnRzOiBBc3Nlc3NtZW50W10pOiBGZWVkYmFja1tdIHtcbiAgICAgICAgY29uc3QgbmV3RWxlbWVudEZlZWRiYWNrID0gbmV3IE1hcCgpO1xuICAgICAgICBmb3IgKGNvbnN0IGFzc2Vzc21lbnQgb2YgYXNzZXNzbWVudHMpIHtcbiAgICAgICAgICAgIGxldCBmZWVkYmFjayA9IHRoaXMuZWxlbWVudEZlZWRiYWNrLmdldChhc3Nlc3NtZW50Lm1vZGVsRWxlbWVudElkKTtcbiAgICAgICAgICAgIGlmIChmZWVkYmFjaykge1xuICAgICAgICAgICAgICAgIGlmIChmZWVkYmFjay5jcmVkaXRzICE9PSBhc3Nlc3NtZW50LnNjb3JlICYmIGZlZWRiYWNrLmdyYWRpbmdJbnN0cnVjdGlvbikge1xuICAgICAgICAgICAgICAgICAgICBmZWVkYmFjay5ncmFkaW5nSW5zdHJ1Y3Rpb24gPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZlZWRiYWNrLmNyZWRpdHMgPSBhc3Nlc3NtZW50LnNjb3JlO1xuICAgICAgICAgICAgICAgIGZlZWRiYWNrLnRleHQgPSBhc3Nlc3NtZW50LmZlZWRiYWNrO1xuICAgICAgICAgICAgICAgIGlmIChhc3Nlc3NtZW50LmRyb3BJbmZvICYmIGFzc2Vzc21lbnQuZHJvcEluZm8uaW5zdHJ1Y3Rpb24/LmlkKSB7XG4gICAgICAgICAgICAgICAgICAgIGZlZWRiYWNrLmdyYWRpbmdJbnN0cnVjdGlvbiA9IGFzc2Vzc21lbnQuZHJvcEluZm8uaW5zdHJ1Y3Rpb247XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChmZWVkYmFjay5ncmFkaW5nSW5zdHJ1Y3Rpb24gJiYgYXNzZXNzbWVudC5kcm9wSW5mbyA9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgZmVlZGJhY2suZ3JhZGluZ0luc3RydWN0aW9uID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZmVlZGJhY2sgPSBGZWVkYmFjay5mb3JNb2RlbGluZyhhc3Nlc3NtZW50LnNjb3JlLCBhc3Nlc3NtZW50LmZlZWRiYWNrLCBhc3Nlc3NtZW50Lm1vZGVsRWxlbWVudElkLCBhc3Nlc3NtZW50LmVsZW1lbnRUeXBlLCBhc3Nlc3NtZW50LmRyb3BJbmZvKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG5ld0VsZW1lbnRGZWVkYmFjay5zZXQoYXNzZXNzbWVudC5tb2RlbEVsZW1lbnRJZCwgZmVlZGJhY2spO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZWxlbWVudEZlZWRiYWNrID0gbmV3RWxlbWVudEZlZWRiYWNrO1xuICAgICAgICByZXR1cm4gWy4uLnRoaXMuZWxlbWVudEZlZWRiYWNrLnZhbHVlcygpXTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIYW5kbGVzIChuZXcpIGZlZWRiYWNrIGJ5IHJlbW92aW5nIGludmFsaWQgZmVlZGJhY2ssIHVwZGF0aW5nIHRoZSBlbGVtZW50LWZlZWRiYWNrIG1hcHBpbmcgYW5kIHVwZGF0aW5nXG4gICAgICogdGhlIGFzc2Vzc21lbnRzIGZvciBBcG9sbG9uIGFjY29yZGluZ2x5LlxuICAgICAqIHdoaWNoIGlzIHRoZW4gc2hvd24gaW4gdGhlIHNjb3JlIGRpc3BsYXkgY29tcG9uZW50LlxuICAgICAqIFRoaXMgbWV0aG9kIGlzIGNhbGxlZCBiZWZvcmUgaW5pdGlhbGl6aW5nIEFwb2xsb24gYW5kIHdoZW4gdGhlIGZlZWRiYWNrIG9yIG1vZGVsIGlzIHVwZGF0ZWQuXG4gICAgICovXG4gICAgcHJpdmF0ZSBoYW5kbGVGZWVkYmFjaygpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5yZWZlcmVuY2VkRmVlZGJhY2tzID0gZmlsdGVySW52YWxpZEZlZWRiYWNrKHRoaXMuZmVlZGJhY2tzLCB0aGlzLnVtbE1vZGVsKTtcbiAgICAgICAgdGhpcy51cGRhdGVFbGVtZW50RmVlZGJhY2tNYXBwaW5nKHRoaXMucmVmZXJlbmNlZEZlZWRiYWNrcyk7XG4gICAgICAgIHRoaXMudXBkYXRlQXBvbGxvbkFzc2Vzc21lbnRzKHRoaXMucmVmZXJlbmNlZEZlZWRiYWNrcyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlcyB0aGUgbWFwcGluZyBvZiBlbGVtZW50SWRzIHRvIEZlZWRiYWNrIGVsZW1lbnRzLiBUaGlzIHNob3VsZCBiZSBjYWxsZWQgYWZ0ZXIgZ2V0dGluZyB0aGVcbiAgICAgKiAodXBkYXRlZCkgRmVlZGJhY2sgbGlzdCBmcm9tIHRoZSBzZXJ2ZXIuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZmVlZGJhY2tzIG5ldyBGZWVkYmFjayBlbGVtZW50cyB0byBpbnNlcnRcbiAgICAgKi9cbiAgICBwcml2YXRlIHVwZGF0ZUVsZW1lbnRGZWVkYmFja01hcHBpbmcoZmVlZGJhY2tzOiBGZWVkYmFja1tdKSB7XG4gICAgICAgIGlmICghdGhpcy5lbGVtZW50RmVlZGJhY2spIHtcbiAgICAgICAgICAgIHRoaXMuZWxlbWVudEZlZWRiYWNrID0gbmV3IE1hcCgpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZmVlZGJhY2tzKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBmZWVkYmFjayBvZiBmZWVkYmFja3MpIHtcbiAgICAgICAgICAgIHRoaXMuZWxlbWVudEZlZWRiYWNrLnNldChmZWVkYmFjay5yZWZlcmVuY2VJZCEsIGZlZWRiYWNrKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNldHMgdGhlIGNvcnJlc3BvbmRpbmcgaGlnaGxpZ2h0IGNvbG9yIGluIHRoZSBhcG9sbG9uIG1vZGVsIG9mIGFsbCBlbGVtZW50cyBjb250YWluZWQgaW4gdGhlIGdpdmVuIGVsZW1lbnQgbWFwLlxuICAgICAqXG4gICAgICogQHBhcmFtIG5ld0VsZW1lbnRzIGEgbWFwIG9mIGVsZW1lbnRJZHMgLT4gaGlnaGxpZ2h0IGNvbG9yXG4gICAgICovXG4gICAgcHJpdmF0ZSBhc3luYyB1cGRhdGVIaWdobGlnaHRlZEVsZW1lbnRzKG5ld0VsZW1lbnRzOiBNYXA8c3RyaW5nLCBzdHJpbmc+KSB7XG4gICAgICAgIGlmICghbmV3RWxlbWVudHMpIHtcbiAgICAgICAgICAgIG5ld0VsZW1lbnRzID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLmFwb2xsb25FZGl0b3IgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLmFwb2xsb25FZGl0b3IubmV4dFJlbmRlcjtcbiAgICAgICAgICAgIGNvbnN0IG1vZGVsOiBVTUxNb2RlbCA9IHRoaXMuYXBvbGxvbkVkaXRvciEubW9kZWw7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGVsZW1lbnQgb2YgT2JqZWN0LnZhbHVlcyhtb2RlbCEuZWxlbWVudHMpKSB7XG4gICAgICAgICAgICAgICAgZWxlbWVudC5oaWdobGlnaHQgPSBuZXdFbGVtZW50cy5nZXQoZWxlbWVudC5pZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHJlbGF0aW9uc2hpcCBvZiBPYmplY3QudmFsdWVzKG1vZGVsIS5yZWxhdGlvbnNoaXBzKSkge1xuICAgICAgICAgICAgICAgIHJlbGF0aW9uc2hpcC5oaWdobGlnaHQgPSBuZXdFbGVtZW50cy5nZXQocmVsYXRpb25zaGlwLmlkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuYXBvbGxvbkVkaXRvciEubW9kZWwgPSBtb2RlbCE7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXRzIHRoZSBjb3JyZXNwb25kaW5nIGhpZ2hsaWdodCBjb2xvciBpbiB0aGUgYXBvbGxvbiBtb2RlbCBvZiBhbGwgZWxlbWVudHMgY29udGFpbmVkIGluIHRoZSBnaXZlbiBlbGVtZW50IG1hcC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBuZXdFbGVtZW50Q291bnRzIGEgbWFwIG9mIGVsZW1lbnRJZHMgLT4gaGlnaGxpZ2h0IGNvbG9yXG4gICAgICovXG4gICAgcHJpdmF0ZSBhc3luYyB1cGRhdGVFbGVtZW50Q291bnRzKG5ld0VsZW1lbnRDb3VudHM6IE1vZGVsRWxlbWVudENvdW50W10pIHtcbiAgICAgICAgaWYgKCFuZXdFbGVtZW50Q291bnRzKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBlbGVtZW50Q291bnRNYXAgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpO1xuXG4gICAgICAgIG5ld0VsZW1lbnRDb3VudHMuZm9yRWFjaCgoZWxlbWVudENvdW50KSA9PiBlbGVtZW50Q291bnRNYXAuc2V0KGVsZW1lbnRDb3VudC5lbGVtZW50SWQsIGVsZW1lbnRDb3VudC5udW1iZXJPZk90aGVyRWxlbWVudHMpKTtcblxuICAgICAgICBpZiAodGhpcy5hcG9sbG9uRWRpdG9yICE9IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5hcG9sbG9uRWRpdG9yLm5leHRSZW5kZXI7XG4gICAgICAgICAgICBjb25zdCBtb2RlbDogVU1MTW9kZWwgPSB0aGlzLmFwb2xsb25FZGl0b3IubW9kZWw7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGVsZW1lbnQgb2YgT2JqZWN0LnZhbHVlcyhtb2RlbC5lbGVtZW50cykpIHtcbiAgICAgICAgICAgICAgICBlbGVtZW50LmFzc2Vzc21lbnROb3RlID0gdGhpcy5jYWxjdWxhdGVOb3RlKGVsZW1lbnRDb3VudE1hcC5nZXQoZWxlbWVudC5pZCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChjb25zdCByZWxhdGlvbnNoaXAgb2YgT2JqZWN0LnZhbHVlcyhtb2RlbC5yZWxhdGlvbnNoaXBzKSkge1xuICAgICAgICAgICAgICAgIHJlbGF0aW9uc2hpcC5hc3Nlc3NtZW50Tm90ZSA9IHRoaXMuY2FsY3VsYXRlTm90ZShlbGVtZW50Q291bnRNYXAuZ2V0KHJlbGF0aW9uc2hpcC5pZCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5hcG9sbG9uRWRpdG9yLm1vZGVsID0gbW9kZWw7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDb252ZXJ0cyBhIGdpdmVuIGZlZWRiYWNrIGxpc3QgdG8gQXBvbGxvbiBhc3Nlc3NtZW50cyBhbmQgdXBkYXRlcyB0aGUgbW9kZWwgb2YgQXBvbGxvbiB3aXRoIHRoZSBuZXcgYXNzZXNzbWVudHMuXG4gICAgICogQHBhcmFtIGZlZWRiYWNrcyB0aGUgZmVlZGJhY2sgbGlzdCB0byBjb252ZXJ0IGFuZCBwYXNzIG9uIHRvIEFwb2xsb25cbiAgICAgKi9cbiAgICBwcml2YXRlIGFzeW5jIHVwZGF0ZUFwb2xsb25Bc3Nlc3NtZW50cyhmZWVkYmFja3M6IEZlZWRiYWNrW10pIHtcbiAgICAgICAgaWYgKCFmZWVkYmFja3MgfHwgIXRoaXMudW1sTW9kZWwpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGZlZWRiYWNrcy5mb3JFYWNoKChmZWVkYmFjaykgPT4ge1xuICAgICAgICAgICAgYWRkT3JVcGRhdGVBc3Nlc3NtZW50KHRoaXMudW1sTW9kZWwsIHtcbiAgICAgICAgICAgICAgICBtb2RlbEVsZW1lbnRJZDogZmVlZGJhY2sucmVmZXJlbmNlSWQhLFxuICAgICAgICAgICAgICAgIGVsZW1lbnRUeXBlOiBmZWVkYmFjay5yZWZlcmVuY2VUeXBlISBhcyBVTUxFbGVtZW50VHlwZSB8IFVNTFJlbGF0aW9uc2hpcFR5cGUsXG4gICAgICAgICAgICAgICAgc2NvcmU6IGZlZWRiYWNrLmNyZWRpdHMhLFxuICAgICAgICAgICAgICAgIGZlZWRiYWNrOiBmZWVkYmFjay50ZXh0IHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICBsYWJlbDogdGhpcy5jYWxjdWxhdGVMYWJlbChmZWVkYmFjayksXG4gICAgICAgICAgICAgICAgbGFiZWxDb2xvcjogdGhpcy5jYWxjdWxhdGVMYWJlbENvbG9yKGZlZWRiYWNrKSxcbiAgICAgICAgICAgICAgICBjb3JyZWN0aW9uU3RhdHVzOiB0aGlzLmNhbGN1bGF0ZUNvcnJlY3Rpb25TdGF0dXNGb3JGZWVkYmFjayhmZWVkYmFjayksXG4gICAgICAgICAgICAgICAgZHJvcEluZm86IHRoaXMuY2FsY3VsYXRlRHJvcEluZm8oZmVlZGJhY2spLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmICh0aGlzLmFwb2xsb25FZGl0b3IpIHtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMuYXBvbGxvbkVkaXRvci5uZXh0UmVuZGVyO1xuICAgICAgICAgICAgdGhpcy5hcG9sbG9uRWRpdG9yLm1vZGVsID0gdGhpcy51bWxNb2RlbDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgY2FsY3VsYXRlTGFiZWwoZmVlZGJhY2s6IGFueSkge1xuICAgICAgICBjb25zdCBmaXJzdENvcnJlY3Rpb25Sb3VuZFRleHQgPSB0aGlzLmFydGVtaXNUcmFuc2xhdGVQaXBlLnRyYW5zZm9ybSgnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LmRpZmZWaWV3LmNvcnJlY3Rpb25Sb3VuZERpZmZGaXJzdCcpO1xuICAgICAgICBjb25zdCBzZWNvbmRDb3JyZWN0aW9uUm91bmRUZXh0ID0gdGhpcy5hcnRlbWlzVHJhbnNsYXRlUGlwZS50cmFuc2Zvcm0oJ2FydGVtaXNBcHAuYXNzZXNzbWVudC5kaWZmVmlldy5jb3JyZWN0aW9uUm91bmREaWZmU2Vjb25kJyk7XG4gICAgICAgIGlmICh0aGlzLmhpZ2hsaWdodERpZmZlcmVuY2VzKSB7XG4gICAgICAgICAgICByZXR1cm4gZmVlZGJhY2suY29waWVkRmVlZGJhY2tJZCA/IGZpcnN0Q29ycmVjdGlvblJvdW5kVGV4dCA6IHNlY29uZENvcnJlY3Rpb25Sb3VuZFRleHQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG5cbiAgICBwcml2YXRlIGNhbGN1bGF0ZUxhYmVsQ29sb3IoZmVlZGJhY2s6IGFueSkge1xuICAgICAgICBpZiAodGhpcy5oaWdobGlnaHREaWZmZXJlbmNlcykge1xuICAgICAgICAgICAgcmV0dXJuIGZlZWRiYWNrLmNvcGllZEZlZWRiYWNrSWQgPyB0aGlzLmZpcnN0Q29ycmVjdGlvblJvdW5kQ29sb3IgOiB0aGlzLnNlY29uZENvcnJlY3Rpb25Sb3VuZENvbG9yO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAnJztcbiAgICB9XG5cbiAgICBwcml2YXRlIGNhbGN1bGF0ZU5vdGUoY291bnQ6IG51bWJlciB8IHVuZGVmaW5lZCkge1xuICAgICAgICBpZiAoY291bnQpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmFydGVtaXNUcmFuc2xhdGVQaXBlLnRyYW5zZm9ybSgnYXJ0ZW1pc0FwcC5tb2RlbGluZ0Fzc2Vzc21lbnQuaW1wYWN0V2FybmluZycsIHsgYWZmZWN0ZWRTdWJtaXNzaW9uc0NvdW50OiBjb3VudCB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBjYWxjdWxhdGVDb3JyZWN0aW9uU3RhdHVzRm9yRmVlZGJhY2soZmVlZGJhY2s6IEZlZWRiYWNrKSB7XG4gICAgICAgIGxldCBjb3JyZWN0aW9uU3RhdHVzRGVzY3JpcHRpb24gPSBmZWVkYmFjay5jb3JyZWN0aW9uU3RhdHVzXG4gICAgICAgICAgICA/IHRoaXMuYXJ0ZW1pc1RyYW5zbGF0ZVBpcGUudHJhbnNmb3JtKCdhcnRlbWlzQXBwLmV4YW1wbGVTdWJtaXNzaW9uLmZlZWRiYWNrLicgKyBmZWVkYmFjay5jb3JyZWN0aW9uU3RhdHVzKVxuICAgICAgICAgICAgOiBmZWVkYmFjay5jb3JyZWN0aW9uU3RhdHVzO1xuICAgICAgICBpZiAoZmVlZGJhY2suY29ycmVjdGlvblN0YXR1cyAmJiBmZWVkYmFjay5jb3JyZWN0aW9uU3RhdHVzICE9PSAnQ09SUkVDVCcpIHtcbiAgICAgICAgICAgIC8vIEFkZGluZyBhIG1pc3Npbmcgd2FybmluZyBpY29uIHRvIHRoZSB0cmFuc2xhdGlvbiBzdHJpbmdzIG9mIGluY29ycmVjdCBmZWVkYmFja3MuXG4gICAgICAgICAgICBjb3JyZWN0aW9uU3RhdHVzRGVzY3JpcHRpb24gKz0gJyDimqDvuI8nO1xuICAgICAgICB9XG4gICAgICAgIGxldCBjb3JyZWN0aW9uU3RhdHVzOiAnQ09SUkVDVCcgfCAnSU5DT1JSRUNUJyB8ICdOT1RfVkFMSURBVEVEJztcbiAgICAgICAgc3dpdGNoIChmZWVkYmFjay5jb3JyZWN0aW9uU3RhdHVzKSB7XG4gICAgICAgICAgICBjYXNlICdDT1JSRUNUJzpcbiAgICAgICAgICAgICAgICBjb3JyZWN0aW9uU3RhdHVzID0gJ0NPUlJFQ1QnO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSB1bmRlZmluZWQ6XG4gICAgICAgICAgICAgICAgY29ycmVjdGlvblN0YXR1cyA9ICdOT1RfVkFMSURBVEVEJztcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgY29ycmVjdGlvblN0YXR1cyA9ICdJTkNPUlJFQ1QnO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBjb3JyZWN0aW9uU3RhdHVzRGVzY3JpcHRpb24sXG4gICAgICAgICAgICBzdGF0dXM6IGNvcnJlY3Rpb25TdGF0dXMsXG4gICAgICAgIH07XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBjYWxjdWxhdGVEcm9wSW5mbyhmZWVkYmFjazogRmVlZGJhY2spIHtcbiAgICAgICAgaWYgKGZlZWRiYWNrLmdyYWRpbmdJbnN0cnVjdGlvbikge1xuICAgICAgICAgICAgY29uc3QgZHJvcEluZm8gPSA8RHJvcEluZm8+e307XG4gICAgICAgICAgICBkcm9wSW5mby5pbnN0cnVjdGlvbiA9IGZlZWRiYWNrLmdyYWRpbmdJbnN0cnVjdGlvbjtcbiAgICAgICAgICAgIGRyb3BJbmZvLnJlbW92ZU1lc3NhZ2UgPSB0aGlzLmFydGVtaXNUcmFuc2xhdGVQaXBlLnRyYW5zZm9ybSgnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50Lm1lc3NhZ2VzLnJlbW92ZUFzc2Vzc21lbnRJbnN0cnVjdGlvbkxpbmsnKTtcbiAgICAgICAgICAgIGRyb3BJbmZvLnRvb2x0aXBNZXNzYWdlID0gdGhpcy5hcnRlbWlzVHJhbnNsYXRlUGlwZS50cmFuc2Zvcm0oJ2FydGVtaXNBcHAuZXhlcmNpc2UuYXNzZXNzbWVudEluc3RydWN0aW9uJykgKyBmZWVkYmFjayEuZ3JhZGluZ0luc3RydWN0aW9uIS5pbnN0cnVjdGlvbkRlc2NyaXB0aW9uO1xuICAgICAgICAgICAgZHJvcEluZm8uZmVlZGJhY2tIaW50ID0gdGhpcy5hcnRlbWlzVHJhbnNsYXRlUGlwZS50cmFuc2Zvcm0oJ2FydGVtaXNBcHAuYXNzZXNzbWVudC5mZWVkYmFja0hpbnQnKTtcbiAgICAgICAgICAgIHJldHVybiBkcm9wSW5mbztcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxufVxuIiwiPGRpdiAjcmVzaXplQ29udGFpbmVyIGNsYXNzPVwibW9kZWxpbmctYXNzZXNzbWVudFwiIFtjbGFzcy5yZXNpemFibGVdPVwicmVzaXplT3B0aW9uc1wiPlxuICAgIEBpZiAodGl0bGUgfHwgZGlzcGxheVBvaW50cykge1xuICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1oZWFkZXIgYmctcHJpbWFyeSB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICBAaWYgKHRpdGxlKSB7XG4gICAgICAgICAgICAgICAgPHNwYW4+e3sgdGl0bGUgfX08L3NwYW4+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImZsZXgtZmlsbFwiPjwvc3Bhbj5cbiAgICAgICAgICAgIEBpZiAoZGlzcGxheVBvaW50cykge1xuICAgICAgICAgICAgICAgIDxqaGktc2NvcmUtZGlzcGxheSBbc2NvcmVdPVwidG90YWxTY29yZVwiIFttYXhQb2ludHNdPVwibWF4U2NvcmVcIiBbbWF4Qm9udXNQb2ludHNdPVwibWF4Qm9udXNQb2ludHNcIiBbY291cnNlXT1cImNvdXJzZVwiPjwvamhpLXNjb3JlLWRpc3BsYXk+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICA8ZGl2IGNsYXNzPVwiYXBvbGxvbi1yb3dcIiBpZD1cImFwb2xsb24tYXNzZXNzbWVudC1yb3dcIj5cbiAgICAgICAgPGRpdiAjZWRpdG9yQ29udGFpbmVyIGNsYXNzPVwiYXBvbGxvbi1jb250YWluZXJcIj48L2Rpdj5cbiAgICAgICAgQGlmIChyZXNpemVPcHRpb25zICYmIHJlc2l6ZU9wdGlvbnMuaG9yaXpvbnRhbFJlc2l6ZSkge1xuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImRyYWdnYWJsZS1yaWdodFwiPlxuICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhR3JpcExpbmVzVmVydGljYWxcIj48L2ZhLWljb24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgIDwvZGl2PlxuICAgIEBpZiAocmVzaXplT3B0aW9ucyAmJiByZXNpemVPcHRpb25zLnZlcnRpY2FsUmVzaXplKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJkcmFnZ2FibGUtYm90dG9tXCI+XG4gICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUdyaXBMaW5lc1wiPjwvZmEtaWNvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuICAgIEBpZiAoZXhwbGFuYXRpb24pIHtcbiAgICAgICAgPGpoaS1tb2RlbGluZy1leHBsYW5hdGlvbi1lZGl0b3IgW2V4cGxhbmF0aW9uXT1cImV4cGxhbmF0aW9uXCIgW3JlYWRPbmx5XT1cInRydWVcIj48L2poaS1tb2RlbGluZy1leHBsYW5hdGlvbi1lZGl0b3I+XG4gICAgfVxuPC9kaXY+XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTW9kZWxpbmdBc3Nlc3NtZW50Q29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9tb2RlbGluZy9hc3Nlc3MvbW9kZWxpbmctYXNzZXNzbWVudC5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzQXNzZXNzbWVudFNoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9hc3Nlc3NtZW50L2Fzc2Vzc21lbnQtc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzTW9kZWxpbmdFZGl0b3JNb2R1bGUgfSBmcm9tICdhcHAvZXhlcmNpc2VzL21vZGVsaW5nL3NoYXJlZC9tb2RlbGluZy1lZGl0b3IubW9kdWxlJztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZSwgQXJ0ZW1pc0Fzc2Vzc21lbnRTaGFyZWRNb2R1bGUsIEFydGVtaXNNb2RlbGluZ0VkaXRvck1vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbTW9kZWxpbmdBc3Nlc3NtZW50Q29tcG9uZW50XSxcbiAgICBleHBvcnRzOiBbTW9kZWxpbmdBc3Nlc3NtZW50Q29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgTW9kZWxpbmdBc3Nlc3NtZW50TW9kdWxlIHt9XG4iLCJpbXBvcnQgeyBTdWJtaXNzaW9uLCBTdWJtaXNzaW9uRXhlcmNpc2VUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3N1Ym1pc3Npb24ubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgTW9kZWxFbGVtZW50Q291bnQge1xuICAgIGVsZW1lbnRJZDogc3RyaW5nO1xuICAgIG51bWJlck9mT3RoZXJFbGVtZW50czogbnVtYmVyO1xufVxuXG5leHBvcnQgY2xhc3MgTW9kZWxpbmdTdWJtaXNzaW9uIGV4dGVuZHMgU3VibWlzc2lvbiB7XG4gICAgcHVibGljIG1vZGVsPzogc3RyaW5nO1xuICAgIHB1YmxpYyBleHBsYW5hdGlvblRleHQ/OiBzdHJpbmc7XG4gICAgcHVibGljIHNpbWlsYXJFbGVtZW50cz86IE1vZGVsRWxlbWVudENvdW50W107XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKFN1Ym1pc3Npb25FeGVyY2lzZVR5cGUuTU9ERUxJTkcpO1xuICAgIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsU0FBUyxXQUFXLFlBQVksYUFBYTtBQUM3QyxTQUFTLGtCQUFrQjs7Ozs7O0FDaUJYLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsdUJBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7Ozs7QUFEYSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFFBQUEsT0FBQSxVQUFBOzs7OztBQUtELElBQUEsb0JBQUEsQ0FBQTs7OztBQUFBLElBQUEsZ0NBQUEsOEJBQUEseUJBQUEsR0FBQSxHQUFBLHNEQUFBLEdBQUEsd0JBQUE7Ozs7O0FBRUEsSUFBQSxvQkFBQSxDQUFBOzs7O0FBQUEsSUFBQSxnQ0FBQSw4QkFBQSx5QkFBQSxHQUFBLEdBQUEscURBQUEsR0FBQSx3QkFBQTs7Ozs7QUFKUixJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxtREFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLG1EQUFBLEdBQUEsQ0FBQTtBQUdMLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7Ozs7QUFOUSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLEdBQUEsQ0FBQSxPQUFBLGFBQUEsSUFBQSxJQUFBLENBQUE7OztBRHRCcEIsU0FTYTtBQVRiOztBQUVBOzs7QUFPTSxJQUFPLHNCQUFQLE1BQU8scUJBQW1CO01BVVI7TUFScEIsV0FBc0U7TUFHdEUsT0FBK0I7TUFHL0IsYUFBYTtNQUViLFlBQW9CLG1CQUE2QjtBQUE3QixhQUFBLG9CQUFBO01BQWdDO01BS3BELG1CQUFnQjtBQUNaLFlBQUksS0FBSyxhQUFZLEdBQUk7QUFDckIseUJBQWM7ZUFDWDtBQUNILGdCQUFNLFVBQWUsS0FBSyxrQkFBa0I7QUFDNUMsMEJBQWdCLE9BQU87O01BRS9CO01BRUEsZUFBWTtBQUNSLGVBQU8sYUFBWTtNQUN2Qjs7eUJBMUJTLHNCQUFtQiwrQkFBQSxhQUFBLENBQUE7TUFBQTtnRUFBbkIsc0JBQW1CLFdBQUEsQ0FBQSxDQUFBLGdCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLE1BQUEsT0FBQSxHQUFBLG9CQUFBLEtBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxPQUFBLFVBQUEsY0FBQSxHQUFBLFlBQUEsWUFBQSxHQUFBLGNBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsNkJBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7O0FDVGhDLFVBQUEscUNBQUEsQ0FBQTtBQUNJLFVBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSwwQkFBQSxDQUFBO0FBQ0EsVUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsVUFBQSxDQUFBO0FBV0ksVUFBQSx3QkFBQSxTQUFBLFNBQUEsdURBQUE7QUFBQSxtQkFBUyxJQUFBLGlCQUFBO1VBQWtCLENBQUE7O0FBRzNCLFVBQUEsb0JBQUEsR0FBQSxZQUFBO0FBQ0ksVUFBQSx3QkFBQSxHQUFBLHFDQUFBLEdBQUEsQ0FBQSxFQUVDLEdBQUEscUNBQUEsR0FBQSxDQUFBO0FBV1QsVUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDBCQUFBO0FBQ0osVUFBQSxvQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLG1DQUFBO0FBQ0EsVUFBQSxvQkFBQSxJQUFBLElBQUE7Ozs7QUExQlEsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxlQUFBLElBQUEsU0FBQSxVQUFBLEVBQXlDLFFBQUEsSUFBQSxTQUFBLFVBQUEsRUFBQSxVQUFBLElBQUEsU0FBQSxTQUFBLEVBQUEsWUFBQSxJQUFBLGFBQUEsVUFBQSxFQUFBLGFBQUEsSUFBQSxhQUFBLFdBQUEsRUFBQSxlQUFBLElBQUEsYUFBQSxhQUFBLEVBQUEsZ0JBQUEsSUFBQSxhQUFBLGNBQUE7QUFRekMsVUFBQSx3QkFBQSxjQUFBLHlCQUFBLEdBQUEsSUFBQSw4Q0FBQSxDQUFBO0FBRUEsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSwyQkFBQSxJQUFBLGtDQUFBLElBQUEsVUFBQSxZQUFBLElBQUEsb0NBQUEsYUFBQSxJQUFBLEVBQUE7Ozs7O29GRFBLLHFCQUFtQixFQUFBLFdBQUEsc0JBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFUmhDLFNBQVMsZ0JBQWdCOztBQUR6QixJQVNhO0FBVGI7OztBQUVBO0FBT00sSUFBTywwQkFBUCxNQUFPLHlCQUF1Qjs7eUJBQXZCLDBCQUF1QjtNQUFBO2dFQUF2Qix5QkFBdUIsQ0FBQTtvRUFKdEIsbUJBQW1CLEVBQUEsQ0FBQTs7Ozs7O0FDSmpDLFNBQVMsZ0JBQWdDLHFCQUFxQixhQUFhLHdCQUF3QjtBQU83RixTQUFVLHVCQUF1QixRQUFnQixPQUFxQjtBQUN4RSxRQUFNLG1CQUFtQixvQkFBSSxJQUFHO0FBQ2hDLGFBQVcsWUFBWSxPQUFPLFdBQVk7QUFDdEMsVUFBTSxzQkFBc0IsU0FBUztBQUNyQyxVQUFNLG9CQUFvQixTQUFTO0FBQ25DLFFBQUksdUJBQXVCLGdCQUFnQjtBQUN2QyxZQUFNLFVBQVUsWUFBWSxPQUFPLGlCQUFpQjtBQUNwRCxVQUFJLENBQUMsU0FBUztBQUVWLHlCQUFpQixpQkFBaUIsSUFBSSxFQUFFLE1BQU0sSUFBSSxNQUFNLEdBQUU7QUFDMUQ7O0FBR0osWUFBTSxPQUFPLFFBQVE7QUFDckIsVUFBSTtBQUNKLGNBQVEsUUFBUSxNQUFNO1FBQ2xCLEtBQUssZUFBZTtBQUNoQixpQkFBTztBQUNQO1FBQ0osS0FBSyxlQUFlO0FBQ2hCLGlCQUFPO0FBQ1A7UUFDSixLQUFLLGVBQWU7QUFDaEIsaUJBQU87QUFDUDtRQUNKLEtBQUssZUFBZTtBQUNoQixpQkFBTztBQUNQO1FBQ0osS0FBSyxlQUFlO0FBQ2hCLGlCQUFPO0FBQ1A7UUFDSixLQUFLLGVBQWU7QUFDaEIsaUJBQU87QUFDUDtRQUNKLEtBQUssZUFBZTtBQUNoQixpQkFBTztBQUNQO1FBQ0osS0FBSyxlQUFlO0FBQ2hCLGlCQUFPO0FBQ1A7UUFDSixLQUFLLGVBQWU7QUFDaEIsaUJBQU87QUFDUDtRQUNKLEtBQUssZUFBZTtBQUNoQixpQkFBTztBQUNQO1FBQ0osS0FBSyxlQUFlO0FBQ2hCLGlCQUFPO0FBQ1A7UUFDSixLQUFLLGVBQWU7QUFDaEIsaUJBQU87QUFDUDtRQUNKLEtBQUssZUFBZTtBQUNoQixpQkFBTztBQUNQO1FBQ0o7QUFDSSxpQkFBTztBQUNQOztBQUVSLHVCQUFpQixpQkFBaUIsSUFBSSxFQUFFLE1BQU0sS0FBSTtlQUMzQyx1QkFBdUIscUJBQXFCO0FBQ25ELFlBQU0sZUFBZSxpQkFBaUIsT0FBTyxpQkFBaUI7QUFDOUQsVUFBSSxDQUFDLGNBQWM7QUFFZix5QkFBaUIsaUJBQWlCLElBQUksRUFBRSxNQUFNLElBQUksTUFBTSxHQUFFO0FBQzFEOztBQUVKLFlBQU0sU0FBUyxZQUFZLE9BQU8sYUFBYSxPQUFPLE9BQU8sR0FBRyxRQUFRO0FBQ3hFLFlBQU0sU0FBUyxZQUFZLE9BQU8sYUFBYSxPQUFPLE9BQU8sR0FBRyxRQUFRO0FBQ3hFLFlBQU0sbUJBQW1CLGFBQWE7QUFDdEMsVUFBSSxPQUFPO0FBQ1gsVUFBSTtBQUNKLGNBQVEsa0JBQWtCO1FBQ3RCLEtBQUssb0JBQW9CO0FBQ3JCLHFCQUFXO0FBQ1g7UUFDSixLQUFLLG9CQUFvQjtBQUNyQixxQkFBVztBQUNYO1FBQ0osS0FBSyxvQkFBb0I7QUFDckIscUJBQVc7QUFDWDtRQUNKLEtBQUssb0JBQW9CO0FBQ3JCLHFCQUFXO0FBQ1g7UUFDSixLQUFLLG9CQUFvQjtBQUNyQixxQkFBVztBQUNYO1FBQ0osS0FBSyxvQkFBb0I7QUFDckIscUJBQVc7QUFDWDtRQUNKLEtBQUssb0JBQW9CO0FBQ3JCLHFCQUFXO0FBQ1gsaUJBQU87QUFDUDtRQUNKO0FBQ0kscUJBQVc7O0FBRW5CLHVCQUFpQixpQkFBaUIsSUFBSSxFQUFFLE1BQU0sTUFBTSxTQUFTLFdBQVcsT0FBTTtXQUMzRTtBQUNILHVCQUFpQixpQkFBaUIsSUFBSSxFQUFFLE1BQU0scUJBQXFCLE1BQU0sR0FBRTs7O0FBR25GLFNBQU87QUFDWDtBQU9NLFNBQVUsc0JBQXNCLFdBQXVCLFVBQXdCO0FBQ2pGLE1BQUksQ0FBQyxXQUFXO0FBQ1osV0FBTzs7QUFFWCxNQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsVUFBVTtBQUNqQyxXQUFPLENBQUE7O0FBR1gsTUFBSSxlQUF5QixPQUFPLE9BQU8sU0FBUyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFO0FBQy9FLE1BQUksU0FBUyxlQUFlO0FBQ3hCLG1CQUFlLGFBQWEsT0FBTyxPQUFPLE9BQU8sU0FBUyxhQUFhLEVBQUUsSUFBSSxDQUFDLFFBQVEsSUFBSSxFQUFFLENBQUM7O0FBRWpHLFNBQU8sVUFBVSxPQUFPLENBQUMsYUFBYSxhQUFhLFNBQVMsU0FBUyxXQUFZLENBQUM7QUFDdEY7QUFuSUE7Ozs7OztBQ0RBLFNBQXdCLGFBQUFBLFlBQVcsY0FBYyxTQUFBQyxRQUE2QixjQUE2QjtBQUMzRyxTQUFTLGVBQWUsYUFBb0MsZ0JBQStELDZCQUE2Qjs7Ozs7QUNHeEksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBVyxJQUFBLDJCQUFBO0FBQ3JCLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsT0FBQSxLQUFBOzs7OztBQUlOLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxxQkFBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBRHVCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsU0FBQSxPQUFBLFVBQUEsRUFBb0IsYUFBQSxPQUFBLFFBQUEsRUFBQSxrQkFBQSxPQUFBLGNBQUEsRUFBQSxVQUFBLE9BQUEsTUFBQTs7Ozs7QUFOL0MsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLGtFQUFBLEdBQUEsQ0FBQTtBQUdBLElBQUEsd0JBQUEsR0FBQSxRQUFBLENBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsa0VBQUEsR0FBQSxDQUFBO0FBR0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBUlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsUUFBQSxJQUFBLEVBQUE7QUFJQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxnQkFBQSxJQUFBLEVBQUE7Ozs7O0FBUUEsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFlBQUE7Ozs7QUFGaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsbUJBQUE7Ozs7O0FBS2pCLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxXQUFBOzs7OztBQUliLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLG1DQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQURxQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGVBQUEsT0FBQSxXQUFBLEVBQTJCLFlBQUEsSUFBQTs7O0FEMUJwRSxJQXNCYTtBQXRCYjs7QUFFQTtBQUVBO0FBQ0E7QUFFQTtBQUNBOzs7O0FBY00sSUFBTyw4QkFBUCxNQUFPLHFDQUFvQyxrQkFBaUI7TUE2QjFDO01BNUJYO01BQ0EsaUJBQWlCO01BQ2pCO01BQ0E7TUFDQSxlQUFlO01BQ2YsZ0JBQWdCO01BQ2hCO01BRUMsa0JBQWtCLElBQUksYUFBWTtNQUNsQyxtQkFBbUIsSUFBSSxhQUFZO01BRXBDO01BQ0E7TUFDQTtNQUVULElBQWEsZ0JBQWdCLFVBQW9CO0FBQzdDLGFBQUssWUFBWTtBQUNqQixhQUFLLHNCQUFzQixLQUFLLFVBQVUsT0FBTyxDQUFDLG9CQUFvQixnQkFBZ0IsYUFBYSxNQUFTO0FBQzVHLGFBQUsseUJBQXlCLEtBQUssbUJBQW1CO01BQzFEO01BRUE7TUFDQTtNQUNBLHNCQUFrQyxDQUFBO01BQ2xDLHdCQUFvQyxDQUFBO01BQ3BDLDRCQUE0QjtNQUM1Qiw2QkFBNkI7TUFFN0IsWUFBb0Isc0JBQTBDO0FBQzFELGNBQUs7QUFEVyxhQUFBLHVCQUFBO01BRXBCO01BRU0sa0JBQWU7O0FBQ2pCLGNBQUksS0FBSyxXQUFXO0FBQ2hCLGlCQUFLLHNCQUFzQixLQUFLLFVBQVUsT0FBTyxDQUFDLG9CQUFvQixnQkFBZ0IsYUFBYSxNQUFTO0FBQzVHLGlCQUFLLHdCQUF3QixLQUFLLFVBQVUsT0FDeEMsQ0FBQyxvQkFBb0IsZ0JBQWdCLGFBQWEsVUFBYSxnQkFBZ0IsU0FBUyxhQUFhLG1CQUFtQjs7QUFHaEksZUFBSyx3QkFBdUI7QUFDNUIsY0FBSSxLQUFLLHFCQUFxQjtBQUMxQixrQkFBTSxLQUFLLDBCQUEwQixLQUFLLG1CQUFtQjs7QUFFakUsY0FBSSxLQUFLLGVBQWU7QUFDcEIsa0JBQU0sS0FBSyxvQkFBb0IsS0FBSyxhQUFhOztBQUVyRCxnQkFBTSxLQUFLLHdCQUF1QjtBQUNsQyxlQUFLLGNBQWE7UUFDdEI7O01BRUEsY0FBVztBQUNQLFlBQUksS0FBSyxlQUFlO0FBQ3BCLGVBQUssY0FBYyxRQUFPOztNQUVsQztNQUVNLFlBQVksU0FBc0I7O0FBQ3BDLGNBQUksUUFBUSxTQUFTLFFBQVEsTUFBTSxnQkFBZ0IsS0FBSyxlQUFlO0FBQ25FLGlCQUFLLGNBQWUsUUFBUSxRQUFRLE1BQU07QUFDMUMsaUJBQUssZUFBYzs7QUFFdkIsY0FBSSxRQUFRLGFBQWEsUUFBUSxVQUFVLGdCQUFnQixLQUFLLFVBQVU7QUFDdEUsaUJBQUssWUFBWSxRQUFRLFVBQVU7QUFDbkMsaUJBQUssZUFBYztBQUNuQixrQkFBTSxLQUFLLHdCQUF1Qjs7QUFFdEMsY0FBSSxRQUFRLHFCQUFxQjtBQUM3QixpQkFBSyxzQkFBc0IsUUFBUSxvQkFBb0I7QUFFdkQsZ0JBQUksS0FBSyxlQUFlO0FBQ3BCLG9CQUFNLEtBQUssd0JBQXVCOzs7QUFHMUMsY0FBSSxRQUFRLHNCQUFzQjtBQUM5QixrQkFBTSxLQUFLLHlCQUF5QixLQUFLLG1CQUFtQjs7UUFFcEU7O01BTVEsMEJBQXVCO0FBQzNCLFlBQUksS0FBSyxlQUFlO0FBQ3BCLGVBQUssY0FBYyxRQUFPOztBQUc5QixhQUFLLGVBQWM7QUFFbkIsYUFBSyxnQkFBZ0IsSUFBSSxjQUFjLEtBQUssZ0JBQWdCLGVBQWU7VUFDdkUsTUFBTSxZQUFZO1VBQ2xCLFVBQVUsS0FBSztVQUNmLE9BQU8sS0FBSztVQUNaLE1BQU0sS0FBSyxlQUFlLGVBQWU7VUFDekMsY0FBYyxLQUFLO1NBQ3RCO0FBQ0QsYUFBSyxjQUFlLDJCQUEyQixDQUFDLGNBQXdCO0FBQ3BFLGNBQUksS0FBSyxVQUFVO0FBQ2YsaUJBQUssaUJBQWlCLEtBQUssU0FBUzs7UUFFNUMsQ0FBQztBQUNELFlBQUksQ0FBQyxLQUFLLFVBQVU7QUFDaEIsZUFBSyxjQUFlLDRCQUE0QixDQUFDLGdCQUE2QjtBQUMxRSxpQkFBSyxzQkFBc0IsS0FBSywrQkFBK0IsV0FBVztBQUMxRSxpQkFBSyxnQkFBZ0IsS0FBSyxLQUFLLG1CQUFtQjtVQUN0RCxDQUFDOztNQUVUO01BRWMsMEJBQXVCOztBQUNqQyxjQUFJLEtBQUsscUJBQXFCO0FBQzFCLGtCQUFNLEtBQUssMEJBQTBCLEtBQUssbUJBQW1COztRQUVyRTs7TUFPQSwrQkFBK0IsYUFBeUI7QUFDcEQsY0FBTSxxQkFBcUIsb0JBQUksSUFBRztBQUNsQyxtQkFBVyxjQUFjLGFBQWE7QUFDbEMsY0FBSSxXQUFXLEtBQUssZ0JBQWdCLElBQUksV0FBVyxjQUFjO0FBQ2pFLGNBQUksVUFBVTtBQUNWLGdCQUFJLFNBQVMsWUFBWSxXQUFXLFNBQVMsU0FBUyxvQkFBb0I7QUFDdEUsdUJBQVMscUJBQXFCOztBQUVsQyxxQkFBUyxVQUFVLFdBQVc7QUFDOUIscUJBQVMsT0FBTyxXQUFXO0FBQzNCLGdCQUFJLFdBQVcsWUFBWSxXQUFXLFNBQVMsYUFBYSxJQUFJO0FBQzVELHVCQUFTLHFCQUFxQixXQUFXLFNBQVM7O0FBRXRELGdCQUFJLFNBQVMsc0JBQXNCLFdBQVcsWUFBWSxRQUFXO0FBQ2pFLHVCQUFTLHFCQUFxQjs7aUJBRS9CO0FBQ0gsdUJBQVcsU0FBUyxZQUFZLFdBQVcsT0FBTyxXQUFXLFVBQVUsV0FBVyxnQkFBZ0IsV0FBVyxhQUFhLFdBQVcsUUFBUTs7QUFFakosNkJBQW1CLElBQUksV0FBVyxnQkFBZ0IsUUFBUTs7QUFFOUQsYUFBSyxrQkFBa0I7QUFDdkIsZUFBTyxDQUFDLEdBQUcsS0FBSyxnQkFBZ0IsT0FBTSxDQUFFO01BQzVDO01BUVEsaUJBQWM7QUFDbEIsYUFBSyxzQkFBc0Isc0JBQXNCLEtBQUssV0FBVyxLQUFLLFFBQVE7QUFDOUUsYUFBSyw2QkFBNkIsS0FBSyxtQkFBbUI7QUFDMUQsYUFBSyx5QkFBeUIsS0FBSyxtQkFBbUI7TUFDMUQ7TUFRUSw2QkFBNkIsV0FBcUI7QUFDdEQsWUFBSSxDQUFDLEtBQUssaUJBQWlCO0FBQ3ZCLGVBQUssa0JBQWtCLG9CQUFJLElBQUc7O0FBRWxDLFlBQUksQ0FBQyxXQUFXO0FBQ1o7O0FBRUosbUJBQVcsWUFBWSxXQUFXO0FBQzlCLGVBQUssZ0JBQWdCLElBQUksU0FBUyxhQUFjLFFBQVE7O01BRWhFO01BT2MsMEJBQTBCLGFBQWdDOztBQUNwRSxjQUFJLENBQUMsYUFBYTtBQUNkLDBCQUFjLG9CQUFJLElBQUc7O0FBR3pCLGNBQUksS0FBSyxpQkFBaUIsUUFBVztBQUNqQyxrQkFBTSxLQUFLLGNBQWM7QUFDekIsa0JBQU0sUUFBa0IsS0FBSyxjQUFlO0FBQzVDLHVCQUFXLFdBQVcsT0FBTyxPQUFPLE1BQU8sUUFBUSxHQUFHO0FBQ2xELHNCQUFRLFlBQVksWUFBWSxJQUFJLFFBQVEsRUFBRTs7QUFFbEQsdUJBQVcsZ0JBQWdCLE9BQU8sT0FBTyxNQUFPLGFBQWEsR0FBRztBQUM1RCwyQkFBYSxZQUFZLFlBQVksSUFBSSxhQUFhLEVBQUU7O0FBRTVELGlCQUFLLGNBQWUsUUFBUTs7UUFFcEM7O01BT2Msb0JBQW9CLGtCQUFxQzs7QUFDbkUsY0FBSSxDQUFDLGtCQUFrQjtBQUNuQjs7QUFHSixnQkFBTSxrQkFBa0Isb0JBQUksSUFBRztBQUUvQiwyQkFBaUIsUUFBUSxDQUFDLGlCQUFpQixnQkFBZ0IsSUFBSSxhQUFhLFdBQVcsYUFBYSxxQkFBcUIsQ0FBQztBQUUxSCxjQUFJLEtBQUssaUJBQWlCLFFBQVc7QUFDakMsa0JBQU0sS0FBSyxjQUFjO0FBQ3pCLGtCQUFNLFFBQWtCLEtBQUssY0FBYztBQUMzQyx1QkFBVyxXQUFXLE9BQU8sT0FBTyxNQUFNLFFBQVEsR0FBRztBQUNqRCxzQkFBUSxpQkFBaUIsS0FBSyxjQUFjLGdCQUFnQixJQUFJLFFBQVEsRUFBRSxDQUFDOztBQUUvRSx1QkFBVyxnQkFBZ0IsT0FBTyxPQUFPLE1BQU0sYUFBYSxHQUFHO0FBQzNELDJCQUFhLGlCQUFpQixLQUFLLGNBQWMsZ0JBQWdCLElBQUksYUFBYSxFQUFFLENBQUM7O0FBRXpGLGlCQUFLLGNBQWMsUUFBUTs7UUFFbkM7O01BTWMseUJBQXlCLFdBQXFCOztBQUN4RCxjQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssVUFBVTtBQUM5Qjs7QUFHSixvQkFBVSxRQUFRLENBQUMsYUFBWTtBQUMzQixrQ0FBc0IsS0FBSyxVQUFVO2NBQ2pDLGdCQUFnQixTQUFTO2NBQ3pCLGFBQWEsU0FBUztjQUN0QixPQUFPLFNBQVM7Y0FDaEIsVUFBVSxTQUFTLFFBQVE7Y0FDM0IsT0FBTyxLQUFLLGVBQWUsUUFBUTtjQUNuQyxZQUFZLEtBQUssb0JBQW9CLFFBQVE7Y0FDN0Msa0JBQWtCLEtBQUsscUNBQXFDLFFBQVE7Y0FDcEUsVUFBVSxLQUFLLGtCQUFrQixRQUFRO2FBQzVDO1VBQ0wsQ0FBQztBQUVELGNBQUksS0FBSyxlQUFlO0FBQ3BCLGtCQUFNLEtBQUssY0FBYztBQUN6QixpQkFBSyxjQUFjLFFBQVEsS0FBSzs7UUFFeEM7O01BRVEsZUFBZSxVQUFhO0FBQ2hDLGNBQU0sMkJBQTJCLEtBQUsscUJBQXFCLFVBQVUseURBQXlEO0FBQzlILGNBQU0sNEJBQTRCLEtBQUsscUJBQXFCLFVBQVUsMERBQTBEO0FBQ2hJLFlBQUksS0FBSyxzQkFBc0I7QUFDM0IsaUJBQU8sU0FBUyxtQkFBbUIsMkJBQTJCOztBQUVsRSxlQUFPO01BQ1g7TUFFUSxvQkFBb0IsVUFBYTtBQUNyQyxZQUFJLEtBQUssc0JBQXNCO0FBQzNCLGlCQUFPLFNBQVMsbUJBQW1CLEtBQUssNEJBQTRCLEtBQUs7O0FBRTdFLGVBQU87TUFDWDtNQUVRLGNBQWMsT0FBeUI7QUFDM0MsWUFBSSxPQUFPO0FBQ1AsaUJBQU8sS0FBSyxxQkFBcUIsVUFBVSwrQ0FBK0MsRUFBRSwwQkFBMEIsTUFBSyxDQUFFOztBQUdqSSxlQUFPO01BQ1g7TUFFUSxxQ0FBcUMsVUFBa0I7QUFDM0QsWUFBSSw4QkFBOEIsU0FBUyxtQkFDckMsS0FBSyxxQkFBcUIsVUFBVSwyQ0FBMkMsU0FBUyxnQkFBZ0IsSUFDeEcsU0FBUztBQUNmLFlBQUksU0FBUyxvQkFBb0IsU0FBUyxxQkFBcUIsV0FBVztBQUV0RSx5Q0FBK0I7O0FBRW5DLFlBQUk7QUFDSixnQkFBUSxTQUFTLGtCQUFrQjtVQUMvQixLQUFLO0FBQ0QsK0JBQW1CO0FBQ25CO1VBQ0osS0FBSztBQUNELCtCQUFtQjtBQUNuQjtVQUNKO0FBQ0ksK0JBQW1COztBQUczQixlQUFPO1VBQ0gsYUFBYTtVQUNiLFFBQVE7O01BRWhCO01BRVEsa0JBQWtCLFVBQWtCO0FBQ3hDLFlBQUksU0FBUyxvQkFBb0I7QUFDN0IsZ0JBQU0sV0FBcUIsQ0FBQTtBQUMzQixtQkFBUyxjQUFjLFNBQVM7QUFDaEMsbUJBQVMsZ0JBQWdCLEtBQUsscUJBQXFCLFVBQVUsZ0VBQWdFO0FBQzdILG1CQUFTLGlCQUFpQixLQUFLLHFCQUFxQixVQUFVLDJDQUEyQyxJQUFJLFNBQVUsbUJBQW9CO0FBQzNJLG1CQUFTLGVBQWUsS0FBSyxxQkFBcUIsVUFBVSxvQ0FBb0M7QUFDaEcsaUJBQU87O0FBR1gsZUFBTztNQUNYOzt5QkEzVFMsOEJBQTJCLGdDQUFBLG9CQUFBLENBQUE7TUFBQTtpRUFBM0IsOEJBQTJCLFdBQUEsQ0FBQSxDQUFBLHlCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLGdCQUFBLGtCQUFBLFlBQUEsY0FBQSxPQUFBLFNBQUEsY0FBQSxnQkFBQSxlQUFBLGlCQUFBLHNCQUFBLHdCQUFBLHFCQUFBLHVCQUFBLGVBQUEsaUJBQUEsUUFBQSxVQUFBLGlCQUFBLGtCQUFBLEdBQUEsU0FBQSxFQUFBLGlCQUFBLG1CQUFBLGtCQUFBLG1CQUFBLEdBQUEsVUFBQSxDQUFBLDBDQUFBLGtDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLHFCQUFBLEdBQUEsQ0FBQSxtQkFBQSxFQUFBLEdBQUEsQ0FBQSxNQUFBLDBCQUFBLEdBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxHQUFBLENBQUEsbUJBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLGNBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsYUFBQSxrQkFBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxVQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEscUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUN0QnhDLFVBQUEsNkJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLG9EQUFBLEdBQUEsQ0FBQTtBQVdBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsd0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLG9EQUFBLEdBQUEsQ0FBQTtBQUtKLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxxREFBQSxHQUFBLENBQUEsRUFJQyxJQUFBLHFEQUFBLEdBQUEsQ0FBQTtBQUlMLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBN0JrRCxVQUFBLDBCQUFBLGFBQUEsSUFBQSxhQUFBO0FBQzlDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLFNBQUEsSUFBQSxnQkFBQSxJQUFBLEVBQUE7QUFhSSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxpQkFBQSxJQUFBLGNBQUEsbUJBQUEsSUFBQSxFQUFBO0FBTUosVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsaUJBQUEsSUFBQSxjQUFBLGlCQUFBLEtBQUEsRUFBQTtBQUtBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLGNBQUEsS0FBQSxFQUFBOzs7OztxRkRIUyw2QkFBMkIsRUFBQSxXQUFBLDhCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRXRCeEMsU0FBUyxZQUFBQyxpQkFBZ0I7O0FBQXpCLElBV2E7QUFYYjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU9NLElBQU8sMkJBQVAsTUFBTywwQkFBd0I7O3lCQUF4QiwyQkFBd0I7TUFBQTtnRUFBeEIsMEJBQXdCLENBQUE7b0VBSnZCLHFCQUFxQiwrQkFBK0IsMkJBQTJCLEVBQUEsQ0FBQTs7Ozs7O0FDUDdGLElBT2E7QUFQYjs7O0FBT00sSUFBTyxxQkFBUCxjQUFrQyxXQUFVO01BQ3ZDO01BQ0E7TUFDQTtNQUNQLGNBQUE7QUFDSSxjQUFLLFVBQUE7TUFDVDs7OzsiLCJuYW1lcyI6WyJDb21wb25lbnQiLCJJbnB1dCIsIk5nTW9kdWxlIl19