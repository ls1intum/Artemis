import {
  ArtemisQuizQuestionTypesModule,
  DragAndDropQuestionComponent,
  DragAndDropSubmittedAnswer,
  MultipleChoiceQuestionComponent,
  MultipleChoiceSubmittedAnswer,
  QuizSubmission,
  ShortAnswerQuestionComponent,
  ShortAnswerSubmittedAnswer,
  init_artemis_quiz_question_types_module,
  init_drag_and_drop_question_component,
  init_drag_and_drop_submitted_answer_model,
  init_multiple_choice_question_component,
  init_multiple_choice_submitted_answer_model,
  init_quiz_submission_model,
  init_short_answer_question_component,
  init_short_answer_submitted_answer_model
} from "/chunk-GCOR4W2L.js";
import {
  QuizExerciseService,
  init_quiz_exercise_service
} from "/chunk-QGISQIQ2.js";
import {
  UI_RELOAD_TIME,
  init_exercise_exam_constants
} from "/chunk-AWLA7IJ7.js";
import {
  ArtemisQuizService,
  ArtemisServerDateService,
  ArtemisSharedComponentModule,
  ParticipationWebsocketService,
  init_participation_websocket_service,
  init_quiz_service,
  init_server_date_service,
  init_shared_component_module
} from "/chunk-ORYTP7RT.js";
import {
  QuizQuestionType,
  init_quiz_question_model
} from "/chunk-HFO42WCR.js";
import {
  UserRouteAccessService,
  init_user_route_access_service
} from "/chunk-KQ77WIWP.js";
import {
  init_global_utils,
  onError
} from "/chunk-LW4WH7EZ.js";
import {
  AlertService,
  AlertType,
  ArtemisDatePipe,
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  ButtonComponent,
  ButtonSize,
  ButtonType,
  JhiConnectionStatusComponent,
  JhiWebsocketService,
  ParticipationService,
  QuizMode,
  SubmissionService,
  TranslateDirective,
  __esm,
  getCourseFromExercise,
  init_alert_service,
  init_artemis_date_pipe,
  init_artemis_translate_pipe,
  init_button_component,
  init_connection_status_component,
  init_exercise_model,
  init_participation_service,
  init_quiz_exercise_model,
  init_shared_module,
  init_submission_service,
  init_translate_directive,
  init_utils,
  init_websocket_service,
  roundValueSpecifiedByCourseSettings
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/quiz/participate/quiz-participation.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var QuizParticipationService;
var init_quiz_participation_service = __esm({
  "src/main/webapp/app/exercises/quiz/participate/quiz-participation.service.ts"() {
    init_submission_service();
    init_submission_service();
    QuizParticipationService = class _QuizParticipationService {
      http;
      submissionService;
      constructor(http, submissionService) {
        this.http = http;
        this.submissionService = submissionService;
      }
      submitForPractice(quizSubmission, exerciseId) {
        const copy = this.submissionService.convert(quizSubmission);
        return this.http.post(`api/exercises/${exerciseId}/submissions/practice`, copy, { observe: "response" }).pipe(map((res) => this.submissionService.convertResponse(res)));
      }
      submitForPreview(quizSubmission, exerciseId) {
        const copy = this.submissionService.convert(quizSubmission);
        return this.http.post(`api/exercises/${exerciseId}/submissions/preview`, copy, { observe: "response" }).pipe(map((res) => this.submissionService.convertResponse(res)));
      }
      submitForLiveMode(quizSubmission, exerciseId) {
        const copy = this.submissionService.convert(quizSubmission);
        return this.http.post(`api/exercises/${exerciseId}/submissions/live`, copy, { observe: "response" }).pipe(map((res) => this.submissionService.convertResponse(res)));
      }
      static \u0275fac = function QuizParticipationService_Factory(t) {
        return new (t || _QuizParticipationService)(i0.\u0275\u0275inject(i1.HttpClient), i0.\u0275\u0275inject(SubmissionService));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _QuizParticipationService, factory: _QuizParticipationService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/quiz/participate/quiz-participation.component.ts
import { Component, QueryList, ViewChildren } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import isMobile from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ismobilejs-es5.js?v=1d0d9ead";
import { ActivatedRoute } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import __vite__cjsImport18_smoothscrollPolyfill from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/smoothscroll-polyfill.js?v=1d0d9ead"; const smoothscroll = __vite__cjsImport18_smoothscrollPolyfill;
import { debounce } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import { captureException } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@sentry_angular-ivy.js?v=1d0d9ead";
import { faCircleNotch, faSync } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i8 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i11 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i14 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function QuizParticipationComponent_Conditional_2_Case_5_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275element(1, "span", 4);
    i02.\u0275\u0275text(2, "\n                    ");
  }
}
function QuizParticipationComponent_Conditional_2_Case_6_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275element(1, "span", 5);
    i02.\u0275\u0275text(2, "\n                    ");
  }
}
function QuizParticipationComponent_Conditional_2_Case_7_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275element(1, "span", 6);
    i02.\u0275\u0275text(2, "\n                    ");
  }
}
function QuizParticipationComponent_Conditional_2_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275element(1, "p", 7);
    i02.\u0275\u0275text(2, "\n            ");
  }
}
function QuizParticipationComponent_Conditional_2_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275element(1, "p", 8);
    i02.\u0275\u0275text(2, "\n            ");
  }
}
function QuizParticipationComponent_Conditional_2_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275element(1, "p", 9);
    i02.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r11 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("translateValues", i02.\u0275\u0275pureFunction3(1, _c0, ctx_r11.userScore, ctx_r11.totalScore, ctx_r11.roundScoreSpecifiedByCourseSettings(ctx_r11.result.score, ctx_r11.getCourseFromExercise(ctx_r11.quizExercise))));
  }
}
function QuizParticipationComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n        ");
    i02.\u0275\u0275elementStart(1, "div", 3);
    i02.\u0275\u0275text(2, "\n            ");
    i02.\u0275\u0275elementStart(3, "h2");
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275template(5, QuizParticipationComponent_Conditional_2_Case_5_Template, 3, 0)(6, QuizParticipationComponent_Conditional_2_Case_6_Template, 3, 0)(7, QuizParticipationComponent_Conditional_2_Case_7_Template, 3, 0);
    i02.\u0275\u0275text(8, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n            ");
    i02.\u0275\u0275template(10, QuizParticipationComponent_Conditional_2_Conditional_10_Template, 3, 0)(11, QuizParticipationComponent_Conditional_2_Conditional_11_Template, 3, 0)(12, QuizParticipationComponent_Conditional_2_Conditional_12_Template, 3, 5);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(13, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    let QuizParticipationComponent_Conditional_2_contFlowTmp;
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate2("\n                ", (ctx_r0.quizExercise.course == null ? null : ctx_r0.quizExercise.course.title) ? ctx_r0.quizExercise.course == null ? null : ctx_r0.quizExercise.course.title : ctx_r0.quizExercise.exerciseGroup == null ? null : ctx_r0.quizExercise.exerciseGroup.exam == null ? null : ctx_r0.quizExercise.exerciseGroup.exam.course == null ? null : ctx_r0.quizExercise.exerciseGroup.exam.course.title, " - ", ctx_r0.quizExercise.title, "\n                ");
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(5, (QuizParticipationComponent_Conditional_2_contFlowTmp = ctx_r0.mode) === "practice" ? 5 : QuizParticipationComponent_Conditional_2_contFlowTmp === "preview" ? 6 : QuizParticipationComponent_Conditional_2_contFlowTmp === "solution" ? 7 : -1);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275conditional(10, !ctx_r0.waitingForQuizStart && !ctx_r0.submission.submitted && !ctx_r0.showingResult && ctx_r0.remainingTimeSeconds >= 0 ? 10 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(11, !ctx_r0.waitingForQuizStart && ctx_r0.submission.submitted && !ctx_r0.showingResult ? 11 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(12, !ctx_r0.waitingForQuizStart && ctx_r0.showingResult && ctx_r0.mode !== "solution" ? 12 : -1);
  }
}
function QuizParticipationComponent_Conditional_3_For_4_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "jhi-multiple-choice-question", 11);
    i02.\u0275\u0275listener("selectedAnswerOptionsChange", function QuizParticipationComponent_Conditional_3_For_4_Conditional_4_Template_jhi_multiple_choice_question_selectedAnswerOptionsChange_1_listener($event) {
      i02.\u0275\u0275restoreView(_r23);
      const question_r13 = i02.\u0275\u0275nextContext().$implicit;
      const ctx_r21 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r21.selectedAnswerOptions.set(question_r13.id, $event));
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r24 = i02.\u0275\u0275nextContext();
    const i_r14 = ctx_r24.$index;
    const question_r13 = ctx_r24.$implicit;
    const ctx_r18 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275propertyInterpolate1("id", "question", i_r14, "");
    i02.\u0275\u0275property("question", question_r13)("selectedAnswerOptions", ctx_r18.selectedAnswerOptions.get(question_r13.id))("fnOnSelection", ctx_r18.onSelectionChanged.bind(ctx_r18))("clickDisabled", ctx_r18.submission.submitted || ctx_r18.remainingTimeSeconds < 0)("showResult", ctx_r18.showingResult)("submittedResult", ctx_r18.result)("quizQuestions", ctx_r18.quizExercise.quizQuestions)("forceSampleSolution", ctx_r18.mode === "solution")("questionIndex", i_r14 + 1)("score", ctx_r18.questionScores[question_r13.id]);
  }
}
function QuizParticipationComponent_Conditional_3_For_4_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "jhi-drag-and-drop-question", 12);
    i02.\u0275\u0275listener("mappingsChange", function QuizParticipationComponent_Conditional_3_For_4_Conditional_6_Template_jhi_drag_and_drop_question_mappingsChange_1_listener($event) {
      i02.\u0275\u0275restoreView(_r27);
      const question_r13 = i02.\u0275\u0275nextContext().$implicit;
      const ctx_r25 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r25.dragAndDropMappings.set(question_r13.id, $event));
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r28 = i02.\u0275\u0275nextContext();
    const i_r14 = ctx_r28.$index;
    const question_r13 = ctx_r28.$implicit;
    const ctx_r19 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275propertyInterpolate1("id", "question", i_r14, "");
    i02.\u0275\u0275property("question", question_r13)("mappings", ctx_r19.dragAndDropMappings.get(question_r13.id))("onMappingUpdate", ctx_r19.onSelectionChanged.bind(ctx_r19))("clickDisabled", ctx_r19.submission.submitted || ctx_r19.remainingTimeSeconds < 0)("showResult", ctx_r19.showingResult)("forceSampleSolution", ctx_r19.mode === "solution")("questionIndex", i_r14 + 1)("score", ctx_r19.questionScores[question_r13.id]);
  }
}
function QuizParticipationComponent_Conditional_3_For_4_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "jhi-short-answer-question", 13);
    i02.\u0275\u0275listener("submittedTextsChange", function QuizParticipationComponent_Conditional_3_For_4_Conditional_8_Template_jhi_short_answer_question_submittedTextsChange_1_listener($event) {
      i02.\u0275\u0275restoreView(_r31);
      const question_r13 = i02.\u0275\u0275nextContext().$implicit;
      const ctx_r29 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r29.shortAnswerSubmittedTexts.set(question_r13.id, $event));
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r32 = i02.\u0275\u0275nextContext();
    const i_r14 = ctx_r32.$index;
    const question_r13 = ctx_r32.$implicit;
    const ctx_r20 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275propertyInterpolate1("id", "question", i_r14, "");
    i02.\u0275\u0275property("question", question_r13)("submittedTexts", ctx_r20.shortAnswerSubmittedTexts.get(question_r13.id))("fnOnSubmittedTextUpdate", ctx_r20.onSelectionChanged.bind(ctx_r20))("clickDisabled", ctx_r20.submission.submitted || ctx_r20.remainingTimeSeconds < 0)("showResult", ctx_r20.showingResult)("forceSampleSolution", ctx_r20.mode === "solution")("questionIndex", i_r14 + 1)("score", ctx_r20.questionScores[question_r13.id]);
  }
}
function QuizParticipationComponent_Conditional_3_For_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                    ");
    i02.\u0275\u0275text(3, "\n                    ");
    i02.\u0275\u0275template(4, QuizParticipationComponent_Conditional_3_For_4_Conditional_4_Template, 3, 11);
    i02.\u0275\u0275text(5, "\n                    ");
    i02.\u0275\u0275template(6, QuizParticipationComponent_Conditional_3_For_4_Conditional_6_Template, 3, 9);
    i02.\u0275\u0275text(7, "\n                    ");
    i02.\u0275\u0275template(8, QuizParticipationComponent_Conditional_3_For_4_Conditional_8_Template, 3, 9);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n            ");
  }
  if (rf & 2) {
    const question_r13 = ctx.$implicit;
    const ctx_r12 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275conditional(4, question_r13.type === ctx_r12.MULTIPLE_CHOICE ? 4 : -1);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(6, question_r13.type === ctx_r12.DRAG_AND_DROP ? 6 : -1);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(8, question_r13.type === ctx_r12.SHORT_ANSWER ? 8 : -1);
  }
}
function QuizParticipationComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n        ");
    i02.\u0275\u0275elementStart(1, "div", 10);
    i02.\u0275\u0275text(2, "\n            ");
    i02.\u0275\u0275repeaterCreate(3, QuizParticipationComponent_Conditional_3_For_4_Template, 10, 3, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275repeater(ctx_r1.quizExercise.quizQuestions);
  }
}
function QuizParticipationComponent_Conditional_4_For_12_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r55 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                                        ");
    i02.\u0275\u0275elementStart(1, "span", 23);
    i02.\u0275\u0275listener("click", function QuizParticipationComponent_Conditional_4_For_12_Conditional_3_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r55);
      const i_r42 = i02.\u0275\u0275nextContext().$index;
      const ctx_r53 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r53.navigateToQuestion(i_r42));
    });
    i02.\u0275\u0275text(2, "\n                                            ");
    i02.\u0275\u0275elementStart(3, "b", 24);
    i02.\u0275\u0275text(4, "DD");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                                    ");
  }
  if (rf & 2) {
    const question_r41 = i02.\u0275\u0275nextContext().$implicit;
    const _r50 = i02.\u0275\u0275reference(7);
    const _r52 = i02.\u0275\u0275reference(10);
    const ctx_r46 = i02.\u0275\u0275nextContext(2);
    let tmp_0_0;
    let tmp_1_0;
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("ngbTooltip", ctx_r46.mode !== "solution" ? ((tmp_0_0 = ctx_r46.dragAndDropMappings.get(question_r41.id)) == null ? null : tmp_0_0.length) ? _r50 : _r52 : "")("ngClass", !!((tmp_1_0 = ctx_r46.dragAndDropMappings.get(question_r41.id)) == null ? null : tmp_1_0.length) ? "changed-question" : "");
  }
}
function QuizParticipationComponent_Conditional_4_For_12_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r59 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                                        ");
    i02.\u0275\u0275elementStart(1, "span", 25);
    i02.\u0275\u0275listener("click", function QuizParticipationComponent_Conditional_4_For_12_Conditional_4_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r59);
      const i_r42 = i02.\u0275\u0275nextContext().$index;
      const ctx_r57 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r57.navigateToQuestion(i_r42));
    });
    i02.\u0275\u0275text(2, "\n                                            ");
    i02.\u0275\u0275elementStart(3, "b", 24);
    i02.\u0275\u0275text(4, "MC");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                                    ");
  }
  if (rf & 2) {
    const question_r41 = i02.\u0275\u0275nextContext().$implicit;
    const _r50 = i02.\u0275\u0275reference(7);
    const _r52 = i02.\u0275\u0275reference(10);
    const ctx_r47 = i02.\u0275\u0275nextContext(2);
    let tmp_0_0;
    let tmp_1_0;
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("ngbTooltip", ctx_r47.mode !== "solution" ? ((tmp_0_0 = ctx_r47.selectedAnswerOptions.get(question_r41.id)) == null ? null : tmp_0_0.length) ? _r50 : _r52 : "")("ngClass", !!((tmp_1_0 = ctx_r47.selectedAnswerOptions.get(question_r41.id)) == null ? null : tmp_1_0.length) ? "changed-question" : "");
  }
}
function QuizParticipationComponent_Conditional_4_For_12_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r63 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                                        ");
    i02.\u0275\u0275elementStart(1, "span", 26);
    i02.\u0275\u0275listener("click", function QuizParticipationComponent_Conditional_4_For_12_Conditional_5_Template_span_click_1_listener() {
      i02.\u0275\u0275restoreView(_r63);
      const i_r42 = i02.\u0275\u0275nextContext().$index;
      const ctx_r61 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r61.navigateToQuestion(i_r42));
    });
    i02.\u0275\u0275text(2, "\n                                            ");
    i02.\u0275\u0275elementStart(3, "b", 24);
    i02.\u0275\u0275text(4, "SA");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                                    ");
  }
  if (rf & 2) {
    const question_r41 = i02.\u0275\u0275nextContext().$implicit;
    const _r50 = i02.\u0275\u0275reference(7);
    const _r52 = i02.\u0275\u0275reference(10);
    const ctx_r48 = i02.\u0275\u0275nextContext(2);
    let tmp_0_0;
    let tmp_1_0;
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("ngbTooltip", ctx_r48.mode !== "solution" ? ((tmp_0_0 = ctx_r48.shortAnswerSubmittedTexts.get(question_r41.id)) == null ? null : tmp_0_0.length) ? _r50 : _r52 : "")("ngClass", !!((tmp_1_0 = ctx_r48.shortAnswerSubmittedTexts.get(question_r41.id)) == null ? null : tmp_1_0.length) ? "changed-question" : "");
  }
}
function QuizParticipationComponent_Conditional_4_For_12_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0);
    i02.\u0275\u0275pipe(1, "artemisTranslate");
  }
  if (rf & 2) {
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(1, 1, "artemisApp.quizExercise.explanationAnswered"));
  }
}
function QuizParticipationComponent_Conditional_4_For_12_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0);
    i02.\u0275\u0275pipe(1, "artemisTranslate");
  }
  if (rf & 2) {
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(1, 1, "artemisApp.quizExercise.explanationNotAnswered"));
  }
}
function QuizParticipationComponent_Conditional_4_For_12_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "div", 20);
    i02.\u0275\u0275text(2, "\n                                    ");
    i02.\u0275\u0275template(3, QuizParticipationComponent_Conditional_4_For_12_Conditional_3_Template, 7, 2)(4, QuizParticipationComponent_Conditional_4_For_12_Conditional_4_Template, 7, 2)(5, QuizParticipationComponent_Conditional_4_For_12_Conditional_5_Template, 7, 2)(6, QuizParticipationComponent_Conditional_4_For_12_ng_template_6_Template, 2, 3, "ng-template", null, 21, i02.\u0275\u0275templateRefExtractor);
    i02.\u0275\u0275text(8, "\n                                    ");
    i02.\u0275\u0275template(9, QuizParticipationComponent_Conditional_4_For_12_ng_template_9_Template, 2, 3, "ng-template", null, 22, i02.\u0275\u0275templateRefExtractor);
    i02.\u0275\u0275text(11, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(12, "\n                            ");
  }
  if (rf & 2) {
    const question_r41 = ctx.$implicit;
    const ctx_r33 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, question_r41.type === ctx_r33.DRAG_AND_DROP ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(4, question_r41.type === ctx_r33.MULTIPLE_CHOICE ? 4 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(5, question_r41.type === ctx_r33.SHORT_ANSWER ? 5 : -1);
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div", 27);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275element(3, "span", 28);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275element(5, "span", 29);
    i02.\u0275\u0275text(6, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r34 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                ", ctx_r34.quizExercise.quizQuestions ? ctx_r34.quizExercise.quizQuestions.length : 0, " ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1(",\n                                ", ctx_r34.totalScore, "\n                                ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div", 30);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r35 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate2("", ctx_r35.quizExercise.quizQuestions ? ctx_r35.quizExercise.quizQuestions.length : 0, " Q / ", ctx_r35.totalScore, " P");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                                    ");
    i02.\u0275\u0275element(3, "span", 32);
    i02.\u0275\u0275text(4, "\n                                    ");
    i02.\u0275\u0275elementStart(5, "span", 33);
    i02.\u0275\u0275text(6);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r65 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275property("ngClass", i02.\u0275\u0275pureFunction2(2, _c1, ctx_r65.remainingTimeSeconds < 60 || ctx_r65.remainingTimeSeconds < ctx_r65.quizExercise.duration / 4, ctx_r65.remainingTimeSeconds < 120 || ctx_r65.remainingTimeSeconds < ctx_r65.quizExercise.duration / 2));
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275textInterpolate1("\n                                        ", ctx_r65.remainingTimeText, "\n                                    ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                                    ");
    i02.\u0275\u0275element(3, "span", 34);
    i02.\u0275\u0275text(4, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_3_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                                ");
    i02.\u0275\u0275element(1, "span", 36);
    i02.\u0275\u0275text(2, "\n                                            ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_3_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                                ");
    i02.\u0275\u0275element(1, "span", 37);
    i02.\u0275\u0275text(2, "\n                                            ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_3_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                                ");
    i02.\u0275\u0275element(1, "span", 38);
    i02.\u0275\u0275text(2, "\n                                            ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_3_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                                ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                                            ");
  }
  if (rf & 2) {
    const ctx_r76 = i02.\u0275\u0275nextContext(5);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(ctx_r76.lastSavedTimeText);
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_3_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                                ");
    i02.\u0275\u0275element(1, "span", 39);
    i02.\u0275\u0275text(2, "\n                                            ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                        ");
    i02.\u0275\u0275elementStart(1, "span", 35);
    i02.\u0275\u0275pipe(2, "artemisDate");
    i02.\u0275\u0275text(3, "\n                                            ");
    i02.\u0275\u0275template(4, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_3_Conditional_4_Template, 3, 0)(5, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_3_Conditional_5_Template, 3, 0)(6, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_3_Conditional_6_Template, 3, 0)(7, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_3_Conditional_7_Template, 4, 1)(8, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_3_Conditional_8_Template, 3, 0);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n                                    ");
  }
  if (rf & 2) {
    const ctx_r71 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275propertyInterpolate("ngbTooltip", i02.\u0275\u0275pipeBind3(2, 6, ctx_r71.submission.submissionDate, "long", true));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(4, !ctx_r71.submission.submitted ? 4 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(5, ctx_r71.submission.submitted ? 5 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(6, ctx_r71.justSaved ? 6 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(7, !ctx_r71.justSaved && ctx_r71.lastSavedTimeText !== "" ? 7 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(8, !ctx_r71.justSaved && ctx_r71.lastSavedTimeText === "" ? 8 : -1);
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_5_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                                ");
    i02.\u0275\u0275element(1, "span", 40);
    i02.\u0275\u0275text(2, "\n                                            ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_5_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                                ");
    i02.\u0275\u0275element(1, "span", 41);
    i02.\u0275\u0275text(2, "\n                                            ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                        ");
    i02.\u0275\u0275elementStart(1, "span", 35);
    i02.\u0275\u0275pipe(2, "artemisDate");
    i02.\u0275\u0275text(3, "\n                                            ");
    i02.\u0275\u0275template(4, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_5_Conditional_4_Template, 3, 0)(5, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_5_Conditional_5_Template, 3, 0);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                                    ");
  }
  if (rf & 2) {
    const ctx_r72 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275propertyInterpolate("ngbTooltip", i02.\u0275\u0275pipeBind3(2, 3, ctx_r72.submission.submissionDate, "long", true));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(4, !ctx_r72.submission.submitted ? 4 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(5, ctx_r72.submission.submitted ? 5 : -1);
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                                    ");
    i02.\u0275\u0275template(3, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_3_Template, 10, 10);
    i02.\u0275\u0275text(4, "\n                                    ");
    i02.\u0275\u0275template(5, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Conditional_5_Template, 7, 7);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r67 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, !ctx_r67.isMobile ? 3 : -1);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(5, ctx_r67.isMobile ? 5 : -1);
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_6_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                            ");
    i02.\u0275\u0275element(1, "span", 44);
    i02.\u0275\u0275text(2, "\n                                        ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "jhi-connection-status", 42);
    i02.\u0275\u0275text(2, "\n                                    ");
    i02.\u0275\u0275elementContainerStart(3, 43);
    i02.\u0275\u0275text(4, "\n                                        ");
    i02.\u0275\u0275template(5, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_6_Conditional_5_Template, 3, 0);
    i02.\u0275\u0275elementContainerEnd();
    i02.\u0275\u0275text(6, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r68 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275conditional(5, ctx_r68.unsavedChanges ? 5 : -1);
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                                    ");
    i02.\u0275\u0275element(3, "span", 45);
    i02.\u0275\u0275text(4, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                                    ");
    i02.\u0275\u0275element(3, "span", 46);
    i02.\u0275\u0275text(4, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "div", 31);
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275template(3, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_3_Template, 9, 5)(4, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_4_Template, 6, 0)(5, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_5_Template, 7, 2)(6, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_6_Template, 8, 1)(7, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_7_Template, 6, 0)(8, QuizParticipationComponent_Conditional_4_Conditional_17_Conditional_8_Template, 6, 0);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r36 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, !ctx_r36.waitingForQuizStart ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(4, ctx_r36.mode === "live" && ctx_r36.waitingForQuizStart && ctx_r36.quizExercise.remainingNumberOfAttempts !== 0 ? 4 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(5, ctx_r36.mode === "live" && !ctx_r36.waitingForQuizStart ? 5 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(6, ctx_r36.mode === "live" ? 6 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(7, ctx_r36.mode === "practice" ? 7 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(8, ctx_r36.mode === "preview" ? 8 : -1);
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_18_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                                    ");
    i02.\u0275\u0275element(3, "span", 45);
    i02.\u0275\u0275text(4, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_18_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                                    ");
    i02.\u0275\u0275element(3, "span", 46);
    i02.\u0275\u0275text(4, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "div", 47);
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "div", 48);
    i02.\u0275\u0275text(4, "\n                                ");
    i02.\u0275\u0275element(5, "span", 49);
    i02.\u0275\u0275text(6, "\n                                ");
    i02.\u0275\u0275elementStart(7, "span", 50);
    i02.\u0275\u0275text(8);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n                            ");
    i02.\u0275\u0275template(11, QuizParticipationComponent_Conditional_4_Conditional_18_Conditional_11_Template, 6, 0)(12, QuizParticipationComponent_Conditional_4_Conditional_18_Conditional_12_Template, 6, 0);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(13, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r37 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("ngClass", i02.\u0275\u0275pureFunction1(6, _c2, ctx_r37.userScore < ctx_r37.totalScore));
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275textInterpolate3("", ctx_r37.userScore, "/", ctx_r37.totalScore, " (", ctx_r37.roundScoreSpecifiedByCourseSettings(ctx_r37.result.score, ctx_r37.quizExercise.course || (ctx_r37.quizExercise.exerciseGroup == null ? null : ctx_r37.quizExercise.exerciseGroup.exam == null ? null : ctx_r37.quizExercise.exerciseGroup.exam.course)), "\n                                    %)");
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(11, ctx_r37.mode === "practice" ? 11 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(12, ctx_r37.mode === "preview" ? 12 : -1);
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275element(3, "span", 51);
    i02.\u0275\u0275text(4, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                    ");
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r84 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "jhi-button", 52);
    i02.\u0275\u0275listener("onClick", function QuizParticipationComponent_Conditional_4_Conditional_20_Template_jhi_button_onClick_1_listener() {
      i02.\u0275\u0275restoreView(_r84);
      const ctx_r83 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r83.refreshQuiz(true));
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r39 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("btnSize", ctx_r39.isMobile ? ctx_r39.ButtonSize.SMALL : ctx_r39.ButtonSize.LARGE)("btnType", ctx_r39.ButtonType.PRIMARY)("title", "artemisApp.exercise.refresh")("disabled", ctx_r39.refreshingQuiz)("icon", ctx_r39.faSync);
  }
}
function QuizParticipationComponent_Conditional_4_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r86 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "jhi-button", 53);
    i02.\u0275\u0275listener("onClick", function QuizParticipationComponent_Conditional_4_Conditional_23_Template_jhi_button_onClick_1_listener() {
      i02.\u0275\u0275restoreView(_r86);
      const ctx_r85 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r85.onSubmit());
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r40 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("btnSize", ctx_r40.isMobile ? ctx_r40.ButtonSize.SMALL : ctx_r40.ButtonSize.LARGE)("btnType", ctx_r40.ButtonType.SUCCESS)("title", ctx_r40.submission.submitted ? "artemisApp.quizExercise.submitted" : "entity.action.submit")("disabled", ctx_r40.submission.submitted || ctx_r40.isSubmitting || ctx_r40.waitingForQuizStart || ctx_r40.remainingTimeSeconds < 0);
  }
}
function QuizParticipationComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n        ");
    i02.\u0275\u0275elementStart(1, "div", 14);
    i02.\u0275\u0275text(2, "\n            ");
    i02.\u0275\u0275elementStart(3, "div", 15);
    i02.\u0275\u0275text(4, "\n                ");
    i02.\u0275\u0275elementStart(5, "div", 16);
    i02.\u0275\u0275text(6, "\n                    ");
    i02.\u0275\u0275elementStart(7, "div", 17);
    i02.\u0275\u0275text(8, "\n                        ");
    i02.\u0275\u0275elementStart(9, "div", 18);
    i02.\u0275\u0275text(10, "\n                            ");
    i02.\u0275\u0275repeaterCreate(11, QuizParticipationComponent_Conditional_4_For_12_Template, 13, 3, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(13, "\n                        ");
    i02.\u0275\u0275template(14, QuizParticipationComponent_Conditional_4_Conditional_14_Template, 8, 2)(15, QuizParticipationComponent_Conditional_4_Conditional_15_Template, 4, 2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(16, "\n                    ");
    i02.\u0275\u0275template(17, QuizParticipationComponent_Conditional_4_Conditional_17_Template, 10, 6)(18, QuizParticipationComponent_Conditional_4_Conditional_18_Template, 14, 8)(19, QuizParticipationComponent_Conditional_4_Conditional_19_Template, 6, 0)(20, QuizParticipationComponent_Conditional_4_Conditional_20_Template, 3, 5);
    i02.\u0275\u0275elementStart(21, "div", 19);
    i02.\u0275\u0275text(22, "\n                        ");
    i02.\u0275\u0275template(23, QuizParticipationComponent_Conditional_4_Conditional_23_Template, 3, 4);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(24, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(25, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(26, "\n        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(27, "\n    ");
  }
  if (rf & 2) {
    const ctx_r2 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(11);
    i02.\u0275\u0275repeater(ctx_r2.quizExercise.quizQuestions);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(14, ctx_r2.quizExercise.quizQuestions && !ctx_r2.isMobile ? 14 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(15, ctx_r2.quizExercise.quizQuestions && ctx_r2.isMobile ? 15 : -1);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(17, !ctx_r2.showingResult ? 17 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(18, ctx_r2.showingResult && ctx_r2.mode !== "solution" ? 18 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(19, ctx_r2.mode === "solution" ? 19 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(20, ctx_r2.mode === "live" && !(ctx_r2.quizBatch == null ? null : ctx_r2.quizBatch.started) && !(ctx_r2.quizBatch == null ? null : ctx_r2.quizBatch.startTime) ? 20 : -1);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(23, !ctx_r2.showingResult ? 23 : -1);
  }
}
function QuizParticipationComponent_Conditional_5_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275element(1, "span", 55);
    i02.\u0275\u0275text(2, "\n            ");
  }
}
function QuizParticipationComponent_Conditional_5_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275element(1, "span", 56);
    i02.\u0275\u0275text(2, "\n            ");
  }
}
function QuizParticipationComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n        ");
    i02.\u0275\u0275elementStart(1, "div", 54);
    i02.\u0275\u0275text(2, "\n            ");
    i02.\u0275\u0275template(3, QuizParticipationComponent_Conditional_5_Conditional_3_Template, 3, 0)(4, QuizParticipationComponent_Conditional_5_Conditional_4_Template, 3, 0);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r3 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, ctx_r3.submission.submissionDate ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(4, !ctx_r3.submission.submissionDate ? 4 : -1);
  }
}
function QuizParticipationComponent_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n        ");
    i02.\u0275\u0275elementStart(1, "div", 57);
    i02.\u0275\u0275text(2, "\n            ");
    i02.\u0275\u0275element(3, "span", 58);
    i02.\u0275\u0275text(4, "\n        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n    ");
  }
}
function QuizParticipationComponent_Conditional_7_Conditional_3_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                        ");
    i02.\u0275\u0275element(3, "hr");
    i02.\u0275\u0275text(4, "\n                        ");
    i02.\u0275\u0275element(5, "span", 61);
    i02.\u0275\u0275text(6, "\n                        ");
    i02.\u0275\u0275elementStart(7, "span", 62);
    i02.\u0275\u0275text(8);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n                        ");
    i02.\u0275\u0275element(10, "br");
    i02.\u0275\u0275text(11, "\n                        ");
    i02.\u0275\u0275elementStart(12, "span");
    i02.\u0275\u0275text(13);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(14, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(15, "\n                ");
  }
  if (rf & 2) {
    const ctx_r93 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(8);
    i02.\u0275\u0275textInterpolate(ctx_r93.timeUntilStart);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275textInterpolate1("(", ctx_r93.quizExercise.releaseDate.format("LT"), ")");
  }
}
function QuizParticipationComponent_Conditional_7_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275element(1, "span", 60);
    i02.\u0275\u0275text(2, "\n                ");
    i02.\u0275\u0275template(3, QuizParticipationComponent_Conditional_7_Conditional_3_Conditional_3_Template, 16, 2);
  }
  if (rf & 2) {
    const ctx_r89 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, ctx_r89.startDate ? 3 : -1);
  }
}
function QuizParticipationComponent_Conditional_7_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r95 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275element(1, "div", 63);
    i02.\u0275\u0275text(2, "\n                ");
    i02.\u0275\u0275elementStart(3, "input", 64);
    i02.\u0275\u0275listener("ngModelChange", function QuizParticipationComponent_Conditional_7_Conditional_4_Template_input_ngModelChange_3_listener($event) {
      i02.\u0275\u0275restoreView(_r95);
      const ctx_r94 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r94.password = $event);
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                ");
    i02.\u0275\u0275elementStart(5, "jhi-button", 65);
    i02.\u0275\u0275listener("onClick", function QuizParticipationComponent_Conditional_7_Conditional_4_Template_jhi_button_onClick_5_listener() {
      i02.\u0275\u0275restoreView(_r95);
      const ctx_r96 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r96.joinBatch());
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n            ");
  }
  if (rf & 2) {
    const ctx_r90 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("ngModel", ctx_r90.password);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("title", "artemisApp.quizExercise.join")("btnType", ctx_r90.ButtonType.SUCCESS);
  }
}
function QuizParticipationComponent_Conditional_7_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r98 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275element(1, "div", 66);
    i02.\u0275\u0275text(2, "\n                ");
    i02.\u0275\u0275elementStart(3, "jhi-button", 67);
    i02.\u0275\u0275listener("onClick", function QuizParticipationComponent_Conditional_7_Conditional_5_Template_jhi_button_onClick_3_listener() {
      i02.\u0275\u0275restoreView(_r98);
      const ctx_r97 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r97.joinBatch());
    });
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    const ctx_r91 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("title", "artemisApp.quizExercise.startBatch")("btnType", ctx_r91.ButtonType.SUCCESS);
  }
}
function QuizParticipationComponent_Conditional_7_Conditional_6_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275element(1, "div", 68);
    i02.\u0275\u0275text(2, "\n                ");
  }
}
function QuizParticipationComponent_Conditional_7_Conditional_6_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275element(1, "div", 69);
    i02.\u0275\u0275text(2, "\n                ");
  }
}
function QuizParticipationComponent_Conditional_7_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275template(1, QuizParticipationComponent_Conditional_7_Conditional_6_Conditional_1_Template, 3, 0)(2, QuizParticipationComponent_Conditional_7_Conditional_6_Conditional_2_Template, 3, 0);
  }
  if (rf & 2) {
    const ctx_r92 = i02.\u0275\u0275nextContext(2);
    let tmp_0_0;
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(1, ((tmp_0_0 = ctx_r92.quizExercise.allowedNumberOfAttempts) !== null && tmp_0_0 !== void 0 ? tmp_0_0 : 0) > 1 ? 1 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(2, ctx_r92.quizExercise.allowedNumberOfAttempts === 1 ? 2 : -1);
  }
}
function QuizParticipationComponent_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n        ");
    i02.\u0275\u0275elementStart(1, "div", 59);
    i02.\u0275\u0275text(2, "\n            ");
    i02.\u0275\u0275template(3, QuizParticipationComponent_Conditional_7_Conditional_3_Template, 4, 1)(4, QuizParticipationComponent_Conditional_7_Conditional_4_Template, 7, 3)(5, QuizParticipationComponent_Conditional_7_Conditional_5_Template, 5, 2)(6, QuizParticipationComponent_Conditional_7_Conditional_6_Template, 3, 2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n    ");
  }
  if (rf & 2) {
    const ctx_r5 = i02.\u0275\u0275nextContext();
    let tmp_1_0;
    let tmp_2_0;
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, ctx_r5.quizBatch || ctx_r5.quizExercise.quizMode === ctx_r5.QuizMode.SYNCHRONIZED ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(4, !ctx_r5.quizBatch && ctx_r5.quizExercise.quizMode === ctx_r5.QuizMode.BATCHED && ((tmp_1_0 = ctx_r5.quizExercise.remainingNumberOfAttempts) !== null && tmp_1_0 !== void 0 ? tmp_1_0 : 1) > 0 ? 4 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(5, !ctx_r5.quizBatch && ctx_r5.quizExercise.quizMode === ctx_r5.QuizMode.INDIVIDUAL && ((tmp_2_0 = ctx_r5.quizExercise.remainingNumberOfAttempts) !== null && tmp_2_0 !== void 0 ? tmp_2_0 : 1) > 0 ? 5 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(6, !ctx_r5.quizBatch && ctx_r5.quizExercise.quizMode !== ctx_r5.QuizMode.SYNCHRONIZED && ctx_r5.quizExercise.remainingNumberOfAttempts === 0 ? 6 : -1);
  }
}
var _c0, _c1, _c2, QuizParticipationComponent;
var init_quiz_participation_component = __esm({
  "src/main/webapp/app/exercises/quiz/participate/quiz-participation.component.ts"() {
    init_alert_service();
    init_participation_service();
    init_participation_websocket_service();
    init_multiple_choice_question_component();
    init_drag_and_drop_question_component();
    init_short_answer_question_component();
    init_button_component();
    init_websocket_service();
    init_short_answer_submitted_answer_model();
    init_quiz_exercise_service();
    init_quiz_participation_service();
    init_quiz_exercise_model();
    init_drag_and_drop_submitted_answer_model();
    init_quiz_submission_model();
    init_quiz_question_model();
    init_multiple_choice_submitted_answer_model();
    init_quiz_service();
    init_utils();
    init_global_utils();
    init_exercise_exam_constants();
    init_exercise_model();
    init_server_date_service();
    init_websocket_service();
    init_quiz_exercise_service();
    init_participation_service();
    init_participation_websocket_service();
    init_alert_service();
    init_quiz_participation_service();
    init_quiz_service();
    init_server_date_service();
    init_translate_directive();
    init_connection_status_component();
    init_button_component();
    init_drag_and_drop_question_component();
    init_multiple_choice_question_component();
    init_short_answer_question_component();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    _c0 = (a0, a1, a2) => ({ userScore: a0, maxScore: a1, percentage: a2 });
    _c1 = (a0, a1) => ({ "time-critical": a0, "time-warning": a1 });
    _c2 = (a0) => ({ incorrect: a0 });
    QuizParticipationComponent = class _QuizParticipationComponent {
      jhiWebsocketService;
      quizExerciseService;
      participationService;
      participationWebsocketService;
      route;
      alertService;
      quizParticipationService;
      translateService;
      quizService;
      serverDateService;
      DRAG_AND_DROP = QuizQuestionType.DRAG_AND_DROP;
      MULTIPLE_CHOICE = QuizQuestionType.MULTIPLE_CHOICE;
      SHORT_ANSWER = QuizQuestionType.SHORT_ANSWER;
      ButtonSize = ButtonSize;
      ButtonType = ButtonType;
      QuizMode = QuizMode;
      roundScoreSpecifiedByCourseSettings = roundValueSpecifiedByCourseSettings;
      getCourseFromExercise = getCourseFromExercise;
      mcQuestionComponents;
      dndQuestionComponents;
      shortAnswerQuestionComponents;
      subscription;
      subscriptionData;
      runningTimeouts = new Array();
      isSubmitting = false;
      lastSavedTimeText = "";
      justSaved = false;
      waitingForQuizStart = false;
      refreshingQuiz = false;
      remainingTimeText = "?";
      remainingTimeSeconds = 0;
      timeUntilStart = "0";
      disconnected = false;
      unsavedChanges = false;
      sendWebsocket;
      showingResult = false;
      userScore;
      mode;
      submission = new QuizSubmission();
      quizExercise;
      quizBatch;
      totalScore;
      selectedAnswerOptions = /* @__PURE__ */ new Map();
      dragAndDropMappings = /* @__PURE__ */ new Map();
      shortAnswerSubmittedTexts = /* @__PURE__ */ new Map();
      result;
      questionScores = {};
      quizId;
      courseId;
      interval;
      quizStarted = false;
      startDate;
      endDate;
      password = "";
      previousRunning = false;
      isMobile = false;
      submissionChannel;
      participationChannel;
      quizExerciseChannel;
      quizBatchChannel;
      websocketSubscription;
      timeoutJustSaved = debounce(() => {
        this.justSaved = false;
      }, 2e3);
      faSync = faSync;
      faCircleNotch = faCircleNotch;
      constructor(jhiWebsocketService, quizExerciseService, participationService, participationWebsocketService, route, alertService, quizParticipationService, translateService, quizService, serverDateService) {
        this.jhiWebsocketService = jhiWebsocketService;
        this.quizExerciseService = quizExerciseService;
        this.participationService = participationService;
        this.participationWebsocketService = participationWebsocketService;
        this.route = route;
        this.alertService = alertService;
        this.quizParticipationService = quizParticipationService;
        this.translateService = translateService;
        this.quizService = quizService;
        this.serverDateService = serverDateService;
        smoothscroll.polyfill();
      }
      ngOnInit() {
        this.isMobile = isMobile(window.navigator.userAgent).any;
        this.subscriptionData = this.route.data.subscribe((data) => {
          this.mode = data.mode;
          this.subscription = this.route.params.subscribe((params) => {
            this.quizId = Number(params["exerciseId"]);
            this.courseId = Number(params["courseId"]);
            switch (this.mode) {
              case "practice":
                this.initPracticeMode();
                break;
              case "preview":
                this.initPreview();
                break;
              case "solution":
                this.initShowSolution();
                break;
              case "live":
                this.initLiveMode();
                break;
            }
          });
        });
        this.interval = setInterval(() => {
          this.updateDisplayedTimes();
          this.checkForQuizEnd();
        }, UI_RELOAD_TIME);
      }
      ngOnDestroy() {
        clearInterval(this.interval);
        this.runningTimeouts.forEach((timeout) => {
          clearTimeout(timeout);
        });
        if (this.submissionChannel) {
          this.jhiWebsocketService.unsubscribe("/user" + this.submissionChannel);
        }
        if (this.participationChannel) {
          this.jhiWebsocketService.unsubscribe(this.participationChannel);
        }
        if (this.quizExerciseChannel) {
          this.jhiWebsocketService.unsubscribe(this.quizExerciseChannel);
        }
        this.websocketSubscription?.unsubscribe();
        if (this.subscription) {
          this.subscription.unsubscribe();
        }
        if (this.subscriptionData) {
          this.subscriptionData.unsubscribe();
        }
      }
      initLiveMode() {
        this.websocketSubscription = this.jhiWebsocketService.connectionState.subscribe((status) => {
          if (status.connected && this.disconnected) {
            if (this.unsavedChanges && this.sendWebsocket) {
              this.onSelectionChanged();
            }
            if (this.quizBatch && !this.quizBatch.started) {
              this.refreshQuiz(true);
            } else if (this.quizBatch && this.endDate && this.endDate.isBefore(this.serverDateService.now())) {
              this.refreshQuiz(true);
            }
          }
          this.disconnected = !status.connected;
        });
        this.subscribeToWebsocketChannels();
        this.participationService.findParticipationForCurrentUser(this.quizId).subscribe({
          next: (response) => {
            this.updateParticipationFromServer(response.body);
          },
          error: (error) => onError(this.alertService, error)
        });
      }
      initPracticeMode() {
        this.quizExerciseService.findForStudent(this.quizId).subscribe({
          next: (res) => {
            if (res.body && res.body.isOpenForPractice) {
              this.startQuizPreviewOrPractice(res.body);
            } else {
              alert("Error: This quiz is not open for practice!");
            }
          },
          error: (error) => onError(this.alertService, error)
        });
      }
      initPreview() {
        this.quizExerciseService.find(this.quizId).subscribe({
          next: (res) => {
            this.startQuizPreviewOrPractice(res.body);
          },
          error: (error) => onError(this.alertService, error)
        });
      }
      initShowSolution() {
        this.quizExerciseService.find(this.quizId).subscribe({
          next: (res) => {
            this.quizExercise = res.body;
            this.initQuiz();
            this.showingResult = true;
          },
          error: (error) => onError(this.alertService, error)
        });
      }
      startQuizPreviewOrPractice(quizExercise) {
        this.quizExercise = quizExercise;
        this.initQuiz();
        this.quizService.randomizeOrder(this.quizExercise.quizQuestions, this.quizExercise.randomizeQuestionOrder);
        this.submission = new QuizSubmission();
        this.endDate = dayjs().add(this.quizExercise.duration, "seconds");
        this.runningTimeouts.push(setTimeout(() => {
          this.onSubmit();
        }, quizExercise.duration * 1e3));
      }
      subscribeToWebsocketChannels() {
        if (!this.submissionChannel) {
          this.submissionChannel = "/topic/quizExercise/" + this.quizId + "/submission";
          this.jhiWebsocketService.subscribe("/user" + this.submissionChannel);
          this.jhiWebsocketService.receive("/user" + this.submissionChannel).subscribe({
            next: (payload) => {
              if (payload.error) {
                this.onSaveError(payload.error);
              }
            },
            error: (error) => {
              this.onSaveError(error);
            }
          });
          this.sendWebsocket = (submission) => {
            this.jhiWebsocketService.send(this.submissionChannel, submission);
          };
        }
        if (!this.participationChannel) {
          this.participationChannel = "/user/topic/exercise/" + this.quizId + "/participation";
          this.jhiWebsocketService.subscribe(this.participationChannel);
          this.jhiWebsocketService.receive(this.participationChannel).subscribe((changedParticipation) => {
            if (changedParticipation && this.quizExercise && changedParticipation.exercise.id === this.quizExercise.id) {
              if (this.waitingForQuizStart) {
                this.updateParticipationFromServer(changedParticipation);
              } else {
                this.showQuizResultAfterQuizEnd(changedParticipation);
              }
            }
          });
        }
        if (!this.quizExerciseChannel) {
          this.quizExerciseChannel = "/topic/courses/" + this.courseId + "/quizExercises";
          this.jhiWebsocketService.subscribe(this.quizExerciseChannel);
          this.jhiWebsocketService.receive(this.quizExerciseChannel).subscribe((quiz) => {
            if (this.waitingForQuizStart && this.quizId === quiz.id) {
              this.applyQuizFull(quiz);
            }
          });
        }
        if (this.quizBatch && !this.quizBatch.started) {
          const batchChannel = this.quizExerciseChannel + "/" + this.quizBatch.id;
          if (this.quizBatchChannel !== batchChannel) {
            this.quizBatchChannel = batchChannel;
            this.jhiWebsocketService.subscribe(this.quizBatchChannel);
            this.jhiWebsocketService.receive(this.quizBatchChannel).subscribe((quiz) => {
              this.applyQuizFull(quiz);
            });
          }
        }
      }
      updateDisplayedTimes() {
        const translationBasePath = "artemisApp.showStatistic.";
        if (this.endDate) {
          const endDate = this.endDate;
          if (endDate.isAfter(this.serverDateService.now())) {
            this.remainingTimeSeconds = endDate.diff(this.serverDateService.now(), "seconds");
            this.remainingTimeText = this.relativeTimeText(this.remainingTimeSeconds);
          } else {
            this.remainingTimeSeconds = -1;
            this.remainingTimeText = this.translateService.instant(translationBasePath + "quizHasEnded");
          }
        } else {
          this.remainingTimeSeconds = 0;
          this.remainingTimeText = "?";
        }
        if (this.submission && this.submission.submissionDate) {
          this.lastSavedTimeText = dayjs(this.submission.submissionDate).fromNow();
        }
        if (this.quizBatch && this.startDate) {
          if (this.startDate.isAfter(this.serverDateService.now())) {
            this.timeUntilStart = this.relativeTimeText(this.startDate.diff(this.serverDateService.now(), "seconds"));
          } else {
            this.timeUntilStart = this.translateService.instant(translationBasePath + "now");
            if (!this.quizBatch.started && !this.quizStarted) {
              this.quizStarted = true;
              if (this.quizExercise.quizMode === QuizMode.INDIVIDUAL) {
                this.refreshQuiz(true);
              } else {
                setTimeout(() => {
                  if (!this.quizBatch || !this.quizBatch.started) {
                    this.refreshQuiz(true);
                  }
                }, 5e3);
              }
            }
          }
        } else {
          this.timeUntilStart = "";
        }
      }
      relativeTimeText(remainingTimeSeconds) {
        if (remainingTimeSeconds > 210) {
          return Math.ceil(remainingTimeSeconds / 60) + " min";
        } else if (remainingTimeSeconds > 59) {
          return Math.floor(remainingTimeSeconds / 60) + " min " + remainingTimeSeconds % 60 + " s";
        } else {
          return remainingTimeSeconds + " s";
        }
      }
      checkForQuizEnd() {
        const running = this.mode === "live" && !!this.quizBatch && this.remainingTimeSeconds >= 0 && this.quizExercise?.quizMode !== QuizMode.SYNCHRONIZED;
        if (!running && this.previousRunning) {
          if (!this.submission.submitted && this.submission.submissionDate) {
            this.alertService.success("artemisApp.quizExercise.submitSuccess");
          }
        }
        this.previousRunning = running;
      }
      initQuiz() {
        this.totalScore = this.quizExercise.quizQuestions ? this.quizExercise.quizQuestions.reduce((score, question) => {
          return score + question.points;
        }, 0) : 0;
        this.selectedAnswerOptions = /* @__PURE__ */ new Map();
        this.dragAndDropMappings = /* @__PURE__ */ new Map();
        this.shortAnswerSubmittedTexts = /* @__PURE__ */ new Map();
        if (this.quizExercise.quizQuestions) {
          this.quizExercise.quizQuestions.forEach((question) => {
            if (question.type === QuizQuestionType.MULTIPLE_CHOICE) {
              this.selectedAnswerOptions.set(question.id, []);
            } else if (question.type === QuizQuestionType.DRAG_AND_DROP) {
              this.dragAndDropMappings.set(question.id, []);
            } else if (question.type === QuizQuestionType.SHORT_ANSWER) {
              this.shortAnswerSubmittedTexts.set(question.id, []);
            } else {
              console.error("Unknown question type: " + question);
            }
          }, this);
        }
      }
      applySubmission() {
        this.selectedAnswerOptions = /* @__PURE__ */ new Map();
        this.dragAndDropMappings = /* @__PURE__ */ new Map();
        this.shortAnswerSubmittedTexts = /* @__PURE__ */ new Map();
        if (this.quizExercise.quizQuestions) {
          this.quizExercise.quizQuestions.forEach((question) => {
            const submittedAnswer = this.submission.submittedAnswers?.find((answer) => {
              return answer.quizQuestion.id === question.id;
            });
            if (question.type === QuizQuestionType.MULTIPLE_CHOICE) {
              this.selectedAnswerOptions.set(question.id, submittedAnswer?.selectedOptions || []);
            } else if (question.type === QuizQuestionType.DRAG_AND_DROP) {
              this.dragAndDropMappings.set(question.id, submittedAnswer?.mappings || []);
            } else if (question.type === QuizQuestionType.SHORT_ANSWER) {
              this.shortAnswerSubmittedTexts.set(question.id, submittedAnswer?.submittedTexts || []);
            } else {
              console.error("Unknown question type: " + question);
            }
          }, this);
        }
      }
      applySelection() {
        this.submission.submittedAnswers = [];
        this.selectedAnswerOptions.forEach((answerOptions, questionId) => {
          const question = this.quizExercise.quizQuestions?.find((selectedQuestion) => {
            return selectedQuestion.id === questionId;
          });
          if (!question) {
            console.error("question not found for ID: " + questionId);
            return;
          }
          const mcSubmittedAnswer = new MultipleChoiceSubmittedAnswer();
          mcSubmittedAnswer.quizQuestion = question;
          mcSubmittedAnswer.selectedOptions = answerOptions;
          this.submission.submittedAnswers.push(mcSubmittedAnswer);
        }, this);
        this.dragAndDropMappings.forEach((mappings, questionId) => {
          const question = this.quizExercise.quizQuestions?.find((localQuestion) => {
            return localQuestion.id === questionId;
          });
          if (!question) {
            console.error("question not found for ID: " + questionId);
            return;
          }
          const dndSubmittedAnswer = new DragAndDropSubmittedAnswer();
          dndSubmittedAnswer.quizQuestion = question;
          dndSubmittedAnswer.mappings = mappings;
          this.submission.submittedAnswers.push(dndSubmittedAnswer);
        }, this);
        this.shortAnswerSubmittedTexts.forEach((submittedTexts, questionId) => {
          const question = this.quizExercise.quizQuestions?.find((localQuestion) => {
            return localQuestion.id === questionId;
          });
          if (!question) {
            console.error("question not found for ID: " + questionId);
            return;
          }
          const shortAnswerSubmittedAnswer = new ShortAnswerSubmittedAnswer();
          shortAnswerSubmittedAnswer.quizQuestion = question;
          shortAnswerSubmittedAnswer.submittedTexts = submittedTexts;
          this.submission.submittedAnswers.push(shortAnswerSubmittedAnswer);
        }, this);
      }
      updateParticipationFromServer(participation) {
        if (participation) {
          this.applyQuizFull(participation.exercise);
        }
        if (participation?.results?.length) {
          this.submission = participation.results[0].submission;
          this.updateSubmissionTime();
          this.applySubmission();
          if (participation.results[0].score !== void 0 && this.quizExercise.quizEnded) {
            this.showResult(participation.results[0]);
          }
        } else {
          this.submission = new QuizSubmission();
          this.initQuiz();
        }
      }
      applyQuizFull(quizExercise) {
        this.quizExercise = quizExercise;
        this.initQuiz();
        this.quizBatch = this.quizExercise.quizBatches?.[0];
        if (this.quizExercise.quizEnded) {
          this.waitingForQuizStart = false;
        } else if (!this.quizBatch || !this.quizBatch.started) {
          this.waitingForQuizStart = true;
          this.jhiWebsocketService.enableReconnect();
          if (this.quizBatch && this.quizBatch.startTime) {
            this.startDate = dayjs(this.quizBatch.startTime ?? this.serverDateService.now());
          }
        } else {
          this.waitingForQuizStart = false;
          this.startDate = dayjs(this.quizBatch.startTime ?? this.serverDateService.now());
          this.endDate = this.startDate.add(this.quizExercise.duration, "seconds");
          if (!this.quizBatch.ended) {
            this.jhiWebsocketService.enableReconnect();
            this.quizService.randomizeOrder(this.quizExercise.quizQuestions, this.quizExercise.randomizeQuestionOrder);
          }
        }
      }
      showQuizResultAfterQuizEnd(participation) {
        const quizExercise = participation.exercise;
        if (participation.results?.first()?.submission !== void 0 && quizExercise.quizEnded) {
          this.submission = participation.results[0].submission;
          this.updateSubmissionTime();
          this.transferInformationToQuizExercise(quizExercise);
          this.applySubmission();
          this.showResult(participation.results[0]);
        }
      }
      transferInformationToQuizExercise(fullQuizExerciseFromServer) {
        this.quizExercise.quizQuestions.forEach((clientQuestion) => {
          const fullQuestionFromServer = fullQuizExerciseFromServer.quizQuestions?.find((fullQuestion) => {
            return clientQuestion.id === fullQuestion.id;
          });
          if (fullQuestionFromServer) {
            clientQuestion.explanation = fullQuestionFromServer.explanation;
            if (clientQuestion.type === QuizQuestionType.MULTIPLE_CHOICE) {
              const mcClientQuestion = clientQuestion;
              const mcFullQuestionFromServer = fullQuestionFromServer;
              const answerOptions = mcClientQuestion.answerOptions;
              answerOptions.forEach((clientAnswerOption) => {
                const fullAnswerOptionFromServer = mcFullQuestionFromServer.answerOptions.find((option) => {
                  return clientAnswerOption.id === option.id;
                });
                if (fullAnswerOptionFromServer) {
                  clientAnswerOption.explanation = fullAnswerOptionFromServer.explanation;
                  clientAnswerOption.isCorrect = fullAnswerOptionFromServer.isCorrect;
                }
              });
            } else if (clientQuestion.type === QuizQuestionType.DRAG_AND_DROP) {
              const dndClientQuestion = clientQuestion;
              const dndFullQuestionFromServer = fullQuestionFromServer;
              dndClientQuestion.correctMappings = dndFullQuestionFromServer.correctMappings;
            } else if (clientQuestion.type === QuizQuestionType.SHORT_ANSWER) {
              const shortAnswerClientQuestion = clientQuestion;
              const shortAnswerFullQuestionFromServer = fullQuestionFromServer;
              shortAnswerClientQuestion.correctMappings = shortAnswerFullQuestionFromServer.correctMappings;
            } else {
              captureException(new Error("Unknown question type: " + clientQuestion));
            }
          }
        }, this);
        this.mcQuestionComponents.forEach((mcQuestionComponent) => {
          mcQuestionComponent.watchCollection();
        });
        this.dndQuestionComponents.forEach((dndQuestionComponent) => {
          dndQuestionComponent.watchCollection();
        });
        this.shortAnswerQuestionComponents.forEach((shortAnswerQuestionComponent) => {
          shortAnswerQuestionComponent.watchCollection();
        });
      }
      showResult(result) {
        this.result = result;
        if (this.result) {
          this.showingResult = true;
          const course = this.quizExercise.course || this.quizExercise?.exerciseGroup?.exam?.course;
          this.userScore = this.submission.scoreInPoints ? roundValueSpecifiedByCourseSettings(this.submission.scoreInPoints, course) : 0;
          this.questionScores = {};
          this.submission.submittedAnswers?.forEach((submittedAnswer) => {
            this.questionScores[submittedAnswer.quizQuestion.id] = roundValueSpecifiedByCourseSettings(submittedAnswer.scoreInPoints, course);
          }, this);
        }
      }
      onSelectionChanged() {
        this.applySelection();
        if (this.sendWebsocket) {
          if (!this.disconnected) {
            this.submission.submissionDate = this.serverDateService.now();
            this.sendWebsocket(this.submission);
            this.unsavedChanges = false;
            this.updateSubmissionTime();
          } else {
            this.unsavedChanges = true;
          }
        }
      }
      updateSubmissionTime() {
        if (this.submission.submissionDate) {
          if (Math.abs(dayjs(this.submission.submissionDate).diff(this.serverDateService.now(), "seconds")) < 2) {
            this.justSaved = true;
            this.timeoutJustSaved();
          }
        }
      }
      onSaveError(error) {
        if (error) {
          const errorMessage = "Saving answers failed: " + error;
          this.alertService.addAlert({
            type: AlertType.DANGER,
            message: errorMessage,
            disableTranslation: true
          });
          this.unsavedChanges = true;
          this.isSubmitting = false;
        }
      }
      areAllQuestionsAnswered() {
        if (!this.quizExercise.quizQuestions) {
          return true;
        }
        for (const question of this.quizExercise.quizQuestions) {
          if (question.type === QuizQuestionType.MULTIPLE_CHOICE) {
            const options = this.selectedAnswerOptions.get(question.id);
            if (options && options.length === 0) {
              return false;
            }
          } else if (question.type === QuizQuestionType.DRAG_AND_DROP) {
            const mappings = this.dragAndDropMappings.get(question.id);
            if (mappings && mappings.length === 0) {
              return false;
            }
          } else if (question.type === QuizQuestionType.SHORT_ANSWER) {
            const submittedTexts = this.shortAnswerSubmittedTexts.get(question.id);
            if (submittedTexts && submittedTexts.length === 0) {
              return false;
            }
          }
        }
        return true;
      }
      onSubmit() {
        const translationBasePath = "artemisApp.quizExercise.";
        this.applySelection();
        let confirmSubmit = true;
        if (this.remainingTimeSeconds > 15 && !this.areAllQuestionsAnswered()) {
          const warningText = this.translateService.instant(translationBasePath + "submissionWarning");
          confirmSubmit = window.confirm(warningText);
        }
        if (confirmSubmit) {
          this.isSubmitting = true;
          switch (this.mode) {
            case "practice":
              if (!this.submission.id) {
                this.quizParticipationService.submitForPractice(this.submission, this.quizId).subscribe({
                  next: (response) => {
                    this.onSubmitPracticeOrPreviewSuccess(response.body);
                  },
                  error: (error) => this.onSubmitError(error)
                });
              }
              break;
            case "preview":
              if (!this.submission.id) {
                this.quizParticipationService.submitForPreview(this.submission, this.quizId).subscribe({
                  next: (response) => {
                    this.onSubmitPracticeOrPreviewSuccess(response.body);
                  },
                  error: (error) => this.onSubmitError(error)
                });
              }
              break;
            case "live":
              const quizSubmission = new QuizSubmission();
              quizSubmission.submittedAnswers = this.submission.submittedAnswers;
              this.quizParticipationService.submitForLiveMode(quizSubmission, this.quizId).subscribe({
                next: (response) => {
                  this.submission = response.body;
                  this.isSubmitting = false;
                  this.updateSubmissionTime();
                  this.applySubmission();
                  if (this.quizExercise.quizMode !== QuizMode.SYNCHRONIZED) {
                    this.alertService.success("artemisApp.quizExercise.submitSuccess");
                  }
                },
                error: (error) => this.onSubmitError(error)
              });
              break;
          }
        }
      }
      onSubmitPracticeOrPreviewSuccess(result) {
        this.isSubmitting = false;
        this.submission = result.submission;
        const quizExercise = result.participation.exercise;
        this.transferInformationToQuizExercise(quizExercise);
        this.applySubmission();
        this.showResult(result);
      }
      onSubmitError(error) {
        const errorMessage = "Submitting the quiz was not possible. " + error.headers?.get("X-artemisApp-message") || error.message;
        this.alertService.addAlert({
          type: AlertType.DANGER,
          message: errorMessage,
          disableTranslation: true
        });
        this.isSubmitting = false;
      }
      navigateToQuestion(questionIndex) {
        document.getElementById("question" + questionIndex).scrollIntoView({
          behavior: "smooth"
        });
      }
      refreshQuiz(refresh = false) {
        this.refreshingQuiz = refresh;
        this.quizExerciseService.findForStudent(this.quizId).subscribe({
          next: (res) => {
            const quizExercise = res.body;
            if (quizExercise.quizStarted) {
              if (quizExercise.quizEnded) {
                this.waitingForQuizStart = false;
                this.endDate = dayjs();
              }
              this.quizExercise = quizExercise;
              this.initQuiz();
              this.initLiveMode();
            }
            setTimeout(() => this.refreshingQuiz = false, 500);
          },
          error: () => {
            setTimeout(() => this.refreshingQuiz = false, 500);
          }
        });
      }
      joinBatch() {
        this.quizExerciseService.join(this.quizId, this.password).subscribe({
          next: (res) => {
            if (res.body) {
              this.quizBatch = res.body;
              if (this.quizBatch?.started) {
                this.refreshQuiz();
              } else {
                this.subscribeToWebsocketChannels();
              }
            }
          },
          error: (error) => {
            const errorMessage = "Joining the quiz was not possible: " + error.headers?.get("X-artemisApp-message") || error.message;
            this.alertService.addAlert({
              type: AlertType.DANGER,
              message: errorMessage,
              disableTranslation: true
            });
          }
        });
      }
      static \u0275fac = function QuizParticipationComponent_Factory(t) {
        return new (t || _QuizParticipationComponent)(i02.\u0275\u0275directiveInject(JhiWebsocketService), i02.\u0275\u0275directiveInject(QuizExerciseService), i02.\u0275\u0275directiveInject(ParticipationService), i02.\u0275\u0275directiveInject(ParticipationWebsocketService), i02.\u0275\u0275directiveInject(i5.ActivatedRoute), i02.\u0275\u0275directiveInject(AlertService), i02.\u0275\u0275directiveInject(QuizParticipationService), i02.\u0275\u0275directiveInject(i8.TranslateService), i02.\u0275\u0275directiveInject(ArtemisQuizService), i02.\u0275\u0275directiveInject(ArtemisServerDateService));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _QuizParticipationComponent, selectors: [["jhi-quiz"]], viewQuery: function QuizParticipationComponent_Query(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275viewQuery(MultipleChoiceQuestionComponent, 5);
          i02.\u0275\u0275viewQuery(DragAndDropQuestionComponent, 5);
          i02.\u0275\u0275viewQuery(ShortAnswerQuestionComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i02.\u0275\u0275queryRefresh(_t = i02.\u0275\u0275loadQuery()) && (ctx.mcQuestionComponents = _t);
          i02.\u0275\u0275queryRefresh(_t = i02.\u0275\u0275loadQuery()) && (ctx.dndQuestionComponents = _t);
          i02.\u0275\u0275queryRefresh(_t = i02.\u0275\u0275loadQuery()) && (ctx.shortAnswerQuestionComponents = _t);
        }
      }, features: [i02.\u0275\u0275ProvidersFeature([ParticipationService])], decls: 14, vars: 11, consts: [[3, "id"], [1, "quiz-refresh-overlay"], ["size", "lg", 3, "icon", "spin"], [1, "quiz-header", "container"], ["jhiTranslate", "artemisApp.quizExercise.practiceMode", 1, "in-parentheses"], ["jhiTranslate", "artemisApp.quizExercise.previewMode", 1, "in-parentheses"], ["jhiTranslate", "artemisApp.quizExercise.solution", 1, "in-parentheses"], ["jhiTranslate", "artemisApp.quizExercise.quizInstructions.live"], ["jhiTranslate", "artemisApp.quizExercise.quizInstructions.wait"], ["jhiTranslate", "artemisApp.quizExercise.quizInstructions.result", 3, "translateValues"], [1, "quiz-content", "container"], [3, "id", "question", "selectedAnswerOptions", "fnOnSelection", "clickDisabled", "showResult", "submittedResult", "quizQuestions", "forceSampleSolution", "questionIndex", "score", "selectedAnswerOptionsChange"], [3, "id", "question", "mappings", "onMappingUpdate", "clickDisabled", "showResult", "forceSampleSolution", "questionIndex", "score", "mappingsChange"], [3, "id", "question", "submittedTexts", "fnOnSubmittedTextUpdate", "clickDisabled", "showResult", "forceSampleSolution", "questionIndex", "score", "submittedTextsChange"], [1, "quiz-footer"], [1, "container"], [1, "quiz-footer-content"], [1, "quiz-icons"], [1, "stepwizardquiz"], [1, "submit-button"], [1, "stepwizardquiz__step"], ["tooltipExplanationTranslate", ""], ["tooltipNotExplanationTranslate", ""], [1, "btn", "btn-light", "btn-circle", "stepbutton", "stepwizardquiz-circle", "draganddropcolor-question", 3, "ngbTooltip", "ngClass", "click"], [1, "fa"], [1, "btn", "btn-light", "btn-circle", "stepbutton", "stepwizardquiz-circle", "multiplechoicecolor-question", 3, "ngbTooltip", "ngClass", "click"], [1, "btn", "btn-light", "btn-circle", "stepbutton", "stepwizardquiz-circle", "shortanswercolor-question", 3, "ngbTooltip", "ngClass", "click"], [1, "align-text", "hide-mobile"], ["jhiTranslate", "artemisApp.quizExercise.questions"], ["jhiTranslate", "artemisApp.quizExercise.totalPoints"], [1, "align-text", "show-mobile"], ["id", "remaining-time"], ["jhiTranslate", "artemisApp.quizExercise.remainingTime", 1, "colon-suffix"], ["id", "remaining-time-value", 3, "ngClass"], ["jhiTranslate", "artemisApp.quizExercise.waitingForStart"], ["placement", "right auto", 3, "ngbTooltip"], ["jhiTranslate", "artemisApp.quizExercise.lastSaved", 1, "colon-suffix"], ["jhiTranslate", "artemisApp.quizExercise.submitted", 1, "colon-suffix"], ["jhiTranslate", "justNow"], ["jhiTranslate", "artemisApp.quizExercise.lastSavedTimeNever"], ["jhiTranslate", "artemisApp.quizExercise.lastSaved"], ["jhiTranslate", "artemisApp.quizExercise.submitted"], [1, "connection-status-quiz"], ["innerContent", ""], ["jhiTranslate", "artemisApp.quizExercise.unsavedChanges", 1, "in-parentheses"], ["jhiTranslate", "artemisApp.quizExercise.practiceMode"], ["jhiTranslate", "artemisApp.quizExercise.previewMode"], [1, "text-center"], ["id", "quiz-score", 3, "ngClass"], ["jhiTranslate", "artemisApp.quizExercise.totalScore", 1, "colon-suffix"], ["id", "quiz-score-result"], ["jhiTranslate", "artemisApp.quizExercise.solution"], ["id", "refresh-quiz", 3, "btnSize", "btnType", "title", "disabled", "icon", "onClick"], ["id", "submit-quiz", 3, "btnSize", "btnType", "title", "disabled", "onClick"], [1, "quiz-is-over-overlay", "alert", "alert-info"], ["jhiTranslate", "artemisApp.quizExercise.quizIsOverText"], ["jhiTranslate", "artemisApp.quizExercise.notParticipatedText"], [1, "quiz-submitted-overlay", "alert", "alert-success"], ["jhiTranslate", "artemisApp.quizExercise.successfullySubmittedText"], [1, "quiz-waiting-for-start-overlay", "alert", "alert-info"], ["jhiTranslate", "artemisApp.quizExercise.quizInstructions.waitForStart"], ["jhiTranslate", "artemisApp.quizExercise.quizInstructions.timeUntilPlannedStart"], [1, "text-bold"], ["jhiTranslate", "artemisApp.quizExercise.quizInstructions.enterPassword"], ["id", "join-patch-password", 3, "ngModel", "ngModelChange"], ["id", "join-batch", 3, "title", "btnType", "onClick"], ["jhiTranslate", "artemisApp.quizExercise.quizInstructions.startNow"], ["id", "start-batch", 3, "title", "btnType", "onClick"], ["jhiTranslate", "artemisApp.quizExercise.quizInstructions.noMoreAttempts"], ["jhiTranslate", "artemisApp.quizExercise.quizInstructions.alreadyAttempted"]], template: function QuizParticipationComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div", 0);
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275template(2, QuizParticipationComponent_Conditional_2_Template, 14, 6)(3, QuizParticipationComponent_Conditional_3_Template, 6, 0)(4, QuizParticipationComponent_Conditional_4_Template, 28, 7)(5, QuizParticipationComponent_Conditional_5_Template, 6, 2)(6, QuizParticipationComponent_Conditional_6_Template, 6, 0)(7, QuizParticipationComponent_Conditional_7_Template, 8, 4);
          i02.\u0275\u0275elementStart(8, "div", 1);
          i02.\u0275\u0275text(9, "\n        ");
          i02.\u0275\u0275element(10, "fa-icon", 2);
          i02.\u0275\u0275text(11, "\n    ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(12, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(13, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275property("id", "exercise-" + (ctx.quizExercise == null ? null : ctx.quizExercise.id));
          i02.\u0275\u0275advance(2);
          i02.\u0275\u0275conditional(2, ctx.quizExercise ? 2 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(3, ctx.quizExercise ? 3 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(4, ctx.quizExercise ? 4 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(5, !ctx.waitingForQuizStart && !ctx.showingResult && !ctx.submission.submitted && ctx.remainingTimeSeconds < 0 ? 5 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(6, !ctx.waitingForQuizStart && ctx.submission.submitted && !ctx.showingResult && (ctx.quizExercise == null ? null : ctx.quizExercise.quizMode) === ctx.QuizMode.SYNCHRONIZED ? 6 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(7, ctx.waitingForQuizStart ? 7 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275classProp("active", ctx.refreshingQuiz);
          i02.\u0275\u0275advance(2);
          i02.\u0275\u0275property("icon", ctx.faCircleNotch)("spin", true);
        }
      }, dependencies: [i11.DefaultValueAccessor, i11.NgControlStatus, i11.NgModel, i12.NgClass, i13.NgbTooltip, i14.FaIconComponent, TranslateDirective, JhiConnectionStatusComponent, ButtonComponent, DragAndDropQuestionComponent, MultipleChoiceQuestionComponent, ShortAnswerQuestionComponent, ArtemisDatePipe, ArtemisTranslatePipe], styles: ['\n\n.quiz-header[_ngcontent-%COMP%] {\n  font-size: 16px;\n  margin-top: 25px;\n}\n.quiz-content[_ngcontent-%COMP%] {\n  margin-top: 6px;\n  margin-bottom: 110px;\n  min-height: calc(100vh - 400px);\n}\n.quiz-content[_ngcontent-%COMP%]   .question-index[_ngcontent-%COMP%] {\n  padding: 2px 6px;\n}\n.quiz-footer[_ngcontent-%COMP%] {\n  height: 90px;\n  position: fixed;\n  padding: 0 10px;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  z-index: 10;\n  box-shadow: 0 0 3px var(--quiz-participation-footer-box-shadow);\n  background: var(--quiz-participation-footer-background);\n}\n.quiz-footer[_ngcontent-%COMP%]   .container[_ngcontent-%COMP%] {\n  height: 100%;\n}\n.quiz-footer[_ngcontent-%COMP%]   .draganddropcolor-question[_ngcontent-%COMP%] {\n  background-color: var(--quiz-participation-footer-dnd-background) !important;\n}\n.quiz-footer[_ngcontent-%COMP%]   .multiplechoicecolor-question[_ngcontent-%COMP%] {\n  background-color: var(--quiz-participation-footer-mc-background) !important;\n}\n.quiz-footer[_ngcontent-%COMP%]   .shortanswercolor-question[_ngcontent-%COMP%] {\n  background-color: var(--quiz-participation-footer-sa-background) !important;\n}\n.quiz-footer[_ngcontent-%COMP%]   .changed-question[_ngcontent-%COMP%] {\n  background-color: var(--quiz-participation-footer-changed-background) !important;\n}\n.quiz-content[_ngcontent-%COMP%], .quiz-footer-content[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n.quiz-footer-content[_ngcontent-%COMP%] {\n  height: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.quiz-footer-content[_ngcontent-%COMP%]   .form-control[_ngcontent-%COMP%], .quiz-footer-content[_ngcontent-%COMP%]   .input-group-btn[_ngcontent-%COMP%] {\n  width: auto;\n}\n.quiz-footer-content[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n.quiz-footer-content[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\n  margin: 0 4px;\n}\n.quiz-footer-content[_ngcontent-%COMP%]   .invalid-reasons-tooltip[_ngcontent-%COMP%]   .tooltip-inner[_ngcontent-%COMP%] {\n  text-align: left;\n  max-width: 300px;\n}\n.quiz-footer-content[_ngcontent-%COMP%]   .invalid-reasons-tooltip[_ngcontent-%COMP%]   .tooltip-inner[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 4px 0;\n  padding: 4px;\n}\n.quiz-footer-content[_ngcontent-%COMP%]   #remaining-time[_ngcontent-%COMP%] {\n  margin: 0 10px;\n  max-width: 35%;\n  text-align: center;\n}\n.quiz-footer-content[_ngcontent-%COMP%]   #remaining-time[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%] {\n  text-align: center;\n  width: 100%;\n}\n@media (max-width: 599px) {\n  .quiz-footer-content[_ngcontent-%COMP%]   #remaining-time[_ngcontent-%COMP%] {\n    max-width: 50%;\n    max-height: 55px;\n    overflow-y: hidden;\n  }\n}\n.quiz-footer-content[_ngcontent-%COMP%]   #remaining-time-value[_ngcontent-%COMP%] {\n  font-weight: bold;\n  white-space: nowrap;\n}\n.quiz-footer-content[_ngcontent-%COMP%]   #quiz-score[_ngcontent-%COMP%] {\n  text-align: center;\n  font-weight: bold;\n  color: var(--quiz-participation-footer-content-quiz-score-color);\n}\n.quiz-footer-content[_ngcontent-%COMP%]   #quiz-score.incorrect[_ngcontent-%COMP%] {\n  color: var(--quiz-participation-footer-content-quiz-score-incorrect-color);\n}\n.quiz-footer-content[_ngcontent-%COMP%]   .time-warning[_ngcontent-%COMP%] {\n  color: var(--quiz-participation-footer-content-time-warning-color);\n}\n.quiz-footer-content[_ngcontent-%COMP%]   .time-critical[_ngcontent-%COMP%] {\n  color: var(--quiz-participation-footer-content-time-critical-color);\n}\n@media (max-width: 767.98px) {\n  .quiz-footer-content[_ngcontent-%COMP%]   .connection-status-quiz[_ngcontent-%COMP%] {\n    font-size: 11px;\n  }\n}\n@media (max-width: 767.98px) {\n  .quiz-footer-content[_ngcontent-%COMP%] {\n    font-size: 12px;\n  }\n}\n.quiz-submitted-overlay[_ngcontent-%COMP%], .quiz-waiting-for-start-overlay[_ngcontent-%COMP%], .quiz-is-active-overlay[_ngcontent-%COMP%], .quiz-is-over-overlay[_ngcontent-%COMP%] {\n  position: fixed !important;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate3d(-50%, -50%, 0);\n  -moz-transform: translate3d(-50%, -50%, 0);\n  -ms-transform: translate3d(-50%, -50%, 0);\n  -o-transform: translate3d(-50%, -50%, 0);\n  transform: translate3d(-50%, -50%, 0);\n  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16), 0 3px 6px rgba(0, 0, 0, 0.23);\n  font-size: 16px;\n  text-align: center;\n  font-weight: bold;\n  border-color: var(--quiz-participation-quiz-is-over-border-color);\n  z-index: 8;\n}\n.in-parentheses[_ngcontent-%COMP%]:before {\n  content: "(";\n}\n.in-parentheses[_ngcontent-%COMP%]:after {\n  content: ")";\n}\n.align-text[_ngcontent-%COMP%] {\n  max-height: 22px;\n  white-space: nowrap;\n}\n@media (max-width: 699px) {\n  .hide-mobile[_ngcontent-%COMP%] {\n    display: none;\n  }\n}\n@media (min-width: 700px) {\n  .show-mobile[_ngcontent-%COMP%] {\n    display: none;\n  }\n}\n.quiz-icons[_ngcontent-%COMP%] {\n  max-width: 40%;\n}\n.stepwizardquiz[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  max-height: 60px;\n  overflow: hidden;\n  position: relative;\n}\n@media (max-width: 767.98px) {\n  .stepwizardquiz[_ngcontent-%COMP%] {\n    max-height: 45px;\n  }\n}\n@media (max-width: 450px) {\n  .stepwizardquiz[_ngcontent-%COMP%] {\n    max-width: 100px;\n  }\n}\n.stepwizardquiz__step[_ngcontent-%COMP%] {\n  display: inline-block;\n  text-align: center;\n  position: relative;\n}\n.stepwizardquiz__step[_ngcontent-%COMP%]   .fa[_ngcontent-%COMP%] {\n  vertical-align: initial;\n}\n.stepwizardquiz__step[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\n  cursor: pointer;\n  opacity: 1 !important;\n}\n.submit-button[_ngcontent-%COMP%] {\n  width: 25%;\n}\n.submit-button[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  float: right;\n}\n.quiz-refresh-overlay[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  opacity: 0;\n  z-index: 12;\n  pointer-events: none;\n  transition: 0.1s ease-out opacity;\n}\n.quiz-refresh-overlay.active[_ngcontent-%COMP%] {\n  background-color: var(--quiz-participation-refresh-overlay-active-background);\n  opacity: 1;\n  pointer-events: none;\n  transition: 0.2s ease-in opacity;\n}\n.quiz-refresh-overlay[_ngcontent-%COMP%]   .ng-fa-icon[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.btn-circle.btn-circle[_ngcontent-%COMP%] {\n  width: 30px;\n  height: 30px;\n  text-align: center;\n  font-size: 12px;\n  font-family:\n    Arial,\n    Helvetica,\n    sans-serif;\n  border-radius: 15px;\n  border-spacing: 5px;\n  padding: 6px 0;\n}\n.btn-circle.btn-circle.btn-light[_ngcontent-%COMP%] {\n  border-color: var(--quiz-participation-btn-circle-light-border-color);\n}\n@media (max-width: 990px) {\n  .btn-circle.btn-circle[_ngcontent-%COMP%] {\n    width: 23px;\n    height: 23px;\n    display: flex;\n    justify-content: center;\n    align-items: center;\n  }\n  .btn-circle.btn-circle[_ngcontent-%COMP%]   .fa[_ngcontent-%COMP%] {\n    font-size: 10px;\n  }\n}\n@media (max-width: 767.98px) {\n  .btn-circle.btn-circle[_ngcontent-%COMP%] {\n    width: 16px;\n    height: 16px;\n    display: flex;\n    justify-content: center;\n    align-items: center;\n  }\n  .btn-circle.btn-circle[_ngcontent-%COMP%]   .fa[_ngcontent-%COMP%] {\n    font-size: 6px;\n  }\n}\n@media (max-width: 990px) {\n  .btn-circle.btn-circle[_ngcontent-%COMP%] {\n    width: 23px;\n    height: 23px;\n    display: flex;\n    justify-content: center;\n    align-items: center;\n  }\n  .btn-circle.btn-circle[_ngcontent-%COMP%]   .fa[_ngcontent-%COMP%] {\n    font-size: 10px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9wYXJ0aWNpcGF0ZS9xdWl6LXBhcnRpY2lwYXRpb24uY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5xdWl6LWhlYWRlciB7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIG1hcmdpbi10b3A6IDI1cHg7XG59XG5cbi5xdWl6LWNvbnRlbnQge1xuICAgIG1hcmdpbi10b3A6IDZweDtcbiAgICBtYXJnaW4tYm90dG9tOiAxMTBweDtcbiAgICBtaW4taGVpZ2h0OiBjYWxjKDEwMHZoIC0gNDAwcHgpO1xuXG4gICAgLnF1ZXN0aW9uLWluZGV4IHtcbiAgICAgICAgcGFkZGluZzogMnB4IDZweDtcbiAgICB9XG59XG5cbi5xdWl6LWZvb3RlciB7XG4gICAgaGVpZ2h0OiA5MHB4O1xuICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICBwYWRkaW5nOiAwIDEwcHg7XG4gICAgYm90dG9tOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgcmlnaHQ6IDA7XG4gICAgei1pbmRleDogMTA7XG4gICAgYm94LXNoYWRvdzogMCAwIDNweCB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tZm9vdGVyLWJveC1zaGFkb3cpO1xuICAgIGJhY2tncm91bmQ6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1mb290ZXItYmFja2dyb3VuZCk7XG5cbiAgICAuY29udGFpbmVyIHtcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgIH1cblxuICAgIC5kcmFnYW5kZHJvcGNvbG9yLXF1ZXN0aW9uIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcXVpei1wYXJ0aWNpcGF0aW9uLWZvb3Rlci1kbmQtYmFja2dyb3VuZCkgIWltcG9ydGFudDtcbiAgICB9XG4gICAgLm11bHRpcGxlY2hvaWNlY29sb3ItcXVlc3Rpb24ge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tZm9vdGVyLW1jLWJhY2tncm91bmQpICFpbXBvcnRhbnQ7XG4gICAgfVxuICAgIC5zaG9ydGFuc3dlcmNvbG9yLXF1ZXN0aW9uIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcXVpei1wYXJ0aWNpcGF0aW9uLWZvb3Rlci1zYS1iYWNrZ3JvdW5kKSAhaW1wb3J0YW50O1xuICAgIH1cbiAgICAuY2hhbmdlZC1xdWVzdGlvbiB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1mb290ZXItY2hhbmdlZC1iYWNrZ3JvdW5kKSAhaW1wb3J0YW50O1xuICAgIH1cbn1cblxuLnF1aXotY29udGVudCxcbi5xdWl6LWZvb3Rlci1jb250ZW50IHtcbiAgICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5xdWl6LWZvb3Rlci1jb250ZW50IHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcblxuICAgIC5mb3JtLWNvbnRyb2wsXG4gICAgLmlucHV0LWdyb3VwLWJ0biB7XG4gICAgICAgIHdpZHRoOiBhdXRvO1xuICAgIH1cblxuICAgIC5mb3JtLWdyb3VwIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICA+ICoge1xuICAgICAgICAgICAgbWFyZ2luOiAwIDRweDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5pbnZhbGlkLXJlYXNvbnMtdG9vbHRpcCAudG9vbHRpcC1pbm5lciB7XG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgICAgIG1heC13aWR0aDogMzAwcHg7XG5cbiAgICAgICAgcCB7XG4gICAgICAgICAgICBtYXJnaW46IDRweCAwO1xuICAgICAgICAgICAgcGFkZGluZzogNHB4O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgI3JlbWFpbmluZy10aW1lIHtcbiAgICAgICAgbWFyZ2luOiAwIDEwcHg7XG4gICAgICAgIG1heC13aWR0aDogMzUlO1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgICAgICAgPiBkaXYge1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIH1cblxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNTk5cHgpIHtcbiAgICAgICAgICAgIG1heC13aWR0aDogNTAlO1xuICAgICAgICAgICAgbWF4LWhlaWdodDogNTVweDtcbiAgICAgICAgICAgIG92ZXJmbG93LXk6IGhpZGRlbjtcbiAgICAgICAgfVxuICAgIH1cblxuICAgICNyZW1haW5pbmctdGltZS12YWx1ZSB7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgIH1cblxuICAgICNxdWl6LXNjb3JlIHtcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1mb290ZXItY29udGVudC1xdWl6LXNjb3JlLWNvbG9yKTtcblxuICAgICAgICAmLmluY29ycmVjdCB7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0tcXVpei1wYXJ0aWNpcGF0aW9uLWZvb3Rlci1jb250ZW50LXF1aXotc2NvcmUtaW5jb3JyZWN0LWNvbG9yKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC50aW1lLXdhcm5pbmcge1xuICAgICAgICBjb2xvcjogdmFyKC0tcXVpei1wYXJ0aWNpcGF0aW9uLWZvb3Rlci1jb250ZW50LXRpbWUtd2FybmluZy1jb2xvcik7XG4gICAgfVxuXG4gICAgLnRpbWUtY3JpdGljYWwge1xuICAgICAgICBjb2xvcjogdmFyKC0tcXVpei1wYXJ0aWNpcGF0aW9uLWZvb3Rlci1jb250ZW50LXRpbWUtY3JpdGljYWwtY29sb3IpO1xuICAgIH1cblxuICAgIC5jb25uZWN0aW9uLXN0YXR1cy1xdWl6IHtcbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDc2Ny45OHB4KSB7XG4gICAgICAgICAgICBmb250LXNpemU6IDExcHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBAbWVkaWEgKG1heC13aWR0aDogNzY3Ljk4cHgpIHtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgIH1cbn1cblxuLnF1aXotc3VibWl0dGVkLW92ZXJsYXksXG4ucXVpei13YWl0aW5nLWZvci1zdGFydC1vdmVybGF5LFxuLnF1aXotaXMtYWN0aXZlLW92ZXJsYXksXG4ucXVpei1pcy1vdmVyLW92ZXJsYXkge1xuICAgIHBvc2l0aW9uOiBmaXhlZCAhaW1wb3J0YW50O1xuICAgIHRvcDogNTAlO1xuICAgIGxlZnQ6IDUwJTtcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTUwJSwgLTUwJSwgMCk7XG4gICAgLW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC01MCUsIC01MCUsIDApO1xuICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC01MCUsIC01MCUsIDApO1xuICAgIC1vLXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTUwJSwgLTUwJSwgMCk7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtNTAlLCAtNTAlLCAwKTtcbiAgICBib3gtc2hhZG93OlxuICAgICAgICAwIDNweCA2cHggcmdiYSgwLCAwLCAwLCAwLjE2KSxcbiAgICAgICAgMCAzcHggNnB4IHJnYmEoMCwgMCwgMCwgMC4yMyk7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBib3JkZXItY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWl6LWlzLW92ZXItYm9yZGVyLWNvbG9yKTtcbiAgICB6LWluZGV4OiA4O1xufVxuXG4uaW4tcGFyZW50aGVzZXM6YmVmb3JlIHtcbiAgICBjb250ZW50OiAnKCc7XG59XG5cbi5pbi1wYXJlbnRoZXNlczphZnRlciB7XG4gICAgY29udGVudDogJyknO1xufVxuXG4uYWxpZ24tdGV4dCB7XG4gICAgbWF4LWhlaWdodDogMjJweDtcbiAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xufVxuXG4uaGlkZS1tb2JpbGUge1xuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA2OTlweCkge1xuICAgICAgICBkaXNwbGF5OiBub25lO1xuICAgIH1cbn1cbi5zaG93LW1vYmlsZSB7XG4gICAgQG1lZGlhIChtaW4td2lkdGg6IDcwMHB4KSB7XG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgfVxufVxuXG4ucXVpei1pY29ucyB7XG4gICAgbWF4LXdpZHRoOiA0MCU7XG59XG5cbi5zdGVwd2l6YXJkcXVpeiB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LXdyYXA6IHdyYXA7XG4gICAgbWF4LWhlaWdodDogNjBweDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjcuOThweCkge1xuICAgICAgICBtYXgtaGVpZ2h0OiA0NXB4O1xuICAgIH1cblxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA0NTBweCkge1xuICAgICAgICBtYXgtd2lkdGg6IDEwMHB4O1xuICAgIH1cblxuICAgICZfX3N0ZXAge1xuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgICAgIC5mYSB7XG4gICAgICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogaW5pdGlhbDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5idG4ge1xuICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICAgICAgb3BhY2l0eTogMSAhaW1wb3J0YW50O1xuICAgICAgICB9XG4gICAgfVxufVxuXG4uc3VibWl0LWJ1dHRvbiB7XG4gICAgd2lkdGg6IDI1JTtcblxuICAgIGJ1dHRvbiB7XG4gICAgICAgIGZsb2F0OiByaWdodDtcbiAgICB9XG59XG5cbi5xdWl6LXJlZnJlc2gtb3ZlcmxheSB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMDtcbiAgICBsZWZ0OiAwO1xuICAgIHJpZ2h0OiAwO1xuICAgIGJvdHRvbTogMDtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHotaW5kZXg6IDEyO1xuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgIHRyYW5zaXRpb246IDAuMXMgZWFzZS1vdXQgb3BhY2l0eTtcblxuICAgICYuYWN0aXZlIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcXVpei1wYXJ0aWNpcGF0aW9uLXJlZnJlc2gtb3ZlcmxheS1hY3RpdmUtYmFja2dyb3VuZCk7XG4gICAgICAgIG9wYWNpdHk6IDE7XG4gICAgICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgICAgICB0cmFuc2l0aW9uOiAwLjJzIGVhc2UtaW4gb3BhY2l0eTtcbiAgICB9XG4gICAgLm5nLWZhLWljb24ge1xuICAgICAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgICAgIHRvcDogNTAlO1xuICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xuICAgIH1cbn1cblxuLmJ0bi1jaXJjbGUuYnRuLWNpcmNsZSB7XG4gICAgd2lkdGg6IDMwcHg7XG4gICAgaGVpZ2h0OiAzMHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDEycHg7XG4gICAgZm9udC1mYW1pbHk6IEFyaWFsLCBIZWx2ZXRpY2EsIHNhbnMtc2VyaWY7XG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcbiAgICBib3JkZXItc3BhY2luZzogNXB4O1xuICAgIHBhZGRpbmc6IDZweCAwO1xuICAgICYuYnRuLWxpZ2h0IHtcbiAgICAgICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tYnRuLWNpcmNsZS1saWdodC1ib3JkZXItY29sb3IpO1xuICAgIH1cblxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA5OTBweCkge1xuICAgICAgICB3aWR0aDogMjNweDtcbiAgICAgICAgaGVpZ2h0OiAyM3B4O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgLmZhIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NjcuOThweCkge1xuICAgICAgICB3aWR0aDogMTZweDtcbiAgICAgICAgaGVpZ2h0OiAxNnB4O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgLmZhIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogNnB4O1xuICAgICAgICB9XG4gICAgfVxufVxuXG5AbWVkaWEgKG1heC13aWR0aDogOTkwcHgpIHtcbiAgICAuYnRuLWNpcmNsZS5idG4tY2lyY2xlIHtcbiAgICAgICAgd2lkdGg6IDIzcHg7XG4gICAgICAgIGhlaWdodDogMjNweDtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIC5mYSB7XG4gICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLGFBQUE7QUFDQSxjQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBO0FBQ0EsaUJBQUE7QUFDQSxjQUFBLEtBQUEsTUFBQSxFQUFBOztBQUVBLENBTEosYUFLSSxDQUFBO0FBQ0ksV0FBQSxJQUFBOztBQUlSLENBQUE7QUFDSSxVQUFBO0FBQ0EsWUFBQTtBQUNBLFdBQUEsRUFBQTtBQUNBLFVBQUE7QUFDQSxRQUFBO0FBQ0EsU0FBQTtBQUNBLFdBQUE7QUFDQSxjQUFBLEVBQUEsRUFBQSxJQUFBLElBQUE7QUFDQSxjQUFBLElBQUE7O0FBRUEsQ0FYSixZQVdJLENBQUE7QUFDSSxVQUFBOztBQUdKLENBZkosWUFlSSxDQUFBO0FBQ0ksb0JBQUEsSUFBQTs7QUFFSixDQWxCSixZQWtCSSxDQUFBO0FBQ0ksb0JBQUEsSUFBQTs7QUFFSixDQXJCSixZQXFCSSxDQUFBO0FBQ0ksb0JBQUEsSUFBQTs7QUFFSixDQXhCSixZQXdCSSxDQUFBO0FBQ0ksb0JBQUEsSUFBQTs7QUFJUixDQXZDQTtBQXVDQSxDQUFBO0FBRUksYUFBQTs7QUFHSixDQUxBO0FBTUksVUFBQTtBQUNBLFdBQUE7QUFDQSxlQUFBO0FBQ0EsbUJBQUE7O0FBRUEsQ0FYSixvQkFXSSxDQUFBO0FBQUEsQ0FYSixvQkFXSSxDQUFBO0FBRUksU0FBQTs7QUFHSixDQWhCSixvQkFnQkksQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBOztBQUVBLENBcEJSLG9CQW9CUSxDQUpKLFdBSUksRUFBQTtBQUNJLFVBQUEsRUFBQTs7QUFJUixDQXpCSixvQkF5QkksQ0FBQSx3QkFBQSxDQUFBO0FBQ0ksY0FBQTtBQUNBLGFBQUE7O0FBRUEsQ0E3QlIsb0JBNkJRLENBSkosd0JBSUksQ0FKSixjQUlJO0FBQ0ksVUFBQSxJQUFBO0FBQ0EsV0FBQTs7QUFJUixDQW5DSixvQkFtQ0ksQ0FBQTtBQUNJLFVBQUEsRUFBQTtBQUNBLGFBQUE7QUFDQSxjQUFBOztBQUVBLENBeENSLG9CQXdDUSxDQUxKLGVBS0ksRUFBQTtBQUNJLGNBQUE7QUFDQSxTQUFBOztBQUdKLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFWSixHQW5DSixvQkFtQ0ksQ0FBQTtBQVdRLGVBQUE7QUFDQSxnQkFBQTtBQUNBLGdCQUFBOzs7QUFJUixDQXBESixvQkFvREksQ0FBQTtBQUNJLGVBQUE7QUFDQSxlQUFBOztBQUdKLENBekRKLG9CQXlESSxDQUFBO0FBQ0ksY0FBQTtBQUNBLGVBQUE7QUFDQSxTQUFBLElBQUE7O0FBRUEsQ0E5RFIsb0JBOERRLENBTEosVUFLSSxDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUlSLENBbkVKLG9CQW1FSSxDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUdKLENBdkVKLG9CQXVFSSxDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUlBLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFESixHQTNFSixvQkEyRUksQ0FBQTtBQUVRLGVBQUE7OztBQUlSLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUE1RUosR0FMQTtBQWtGUSxlQUFBOzs7QUFJUixDQUFBO0FBQUEsQ0FBQTtBQUFBLENBQUE7QUFBQSxDQUFBO0FBSUksWUFBQTtBQUNBLE9BQUE7QUFDQSxRQUFBO0FBQ0EscUJBQUEsWUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBO0FBQ0Esa0JBQUEsWUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBO0FBQ0EsaUJBQUEsWUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBO0FBQ0EsZ0JBQUEsWUFBQSxJQUFBLEVBQUEsSUFBQSxFQUFBO0FBQ0EsYUFBQSxZQUFBLElBQUEsRUFBQSxJQUFBLEVBQUE7QUFDQSxjQUNJLEVBQUEsSUFBQSxJQUFBLEtBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsS0FBQSxFQUFBLEVBQUEsSUFBQSxJQUFBLEtBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLEVBQUE7QUFFSixhQUFBO0FBQ0EsY0FBQTtBQUNBLGVBQUE7QUFDQSxnQkFBQSxJQUFBO0FBQ0EsV0FBQTs7QUFHSixDQUFBLGNBQUE7QUFDSSxXQUFBOztBQUdKLENBSkEsY0FJQTtBQUNJLFdBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUE7QUFDQSxlQUFBOztBQUlBLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFESixHQUFBO0FBRVEsYUFBQTs7O0FBSUosT0FBQSxDQUFBLFNBQUEsRUFBQTtBQURKLEdBQUE7QUFFUSxhQUFBOzs7QUFJUixDQUFBO0FBQ0ksYUFBQTs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLGFBQUE7QUFDQSxjQUFBO0FBQ0EsWUFBQTtBQUNBLFlBQUE7O0FBRUEsT0FBQSxDQUFBLFNBQUEsRUFBQTtBQVBKLEdBQUE7QUFRUSxnQkFBQTs7O0FBR0osT0FBQSxDQUFBLFNBQUEsRUFBQTtBQVhKLEdBQUE7QUFZUSxlQUFBOzs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLGNBQUE7QUFDQSxZQUFBOztBQUVBLENBTEoscUJBS0ksQ0FBQTtBQUNJLGtCQUFBOztBQUdKLENBVEoscUJBU0ksQ0FBQTtBQUNJLFVBQUE7QUFDQSxXQUFBOztBQUtaLENBQUE7QUFDSSxTQUFBOztBQUVBLENBSEosY0FHSTtBQUNJLFNBQUE7O0FBSVIsQ0FBQTtBQUNJLFlBQUE7QUFDQSxPQUFBO0FBQ0EsUUFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBO0FBQ0EsV0FBQTtBQUNBLFdBQUE7QUFDQSxrQkFBQTtBQUNBLGNBQUEsS0FBQSxTQUFBOztBQUVBLENBWEosb0JBV0ksQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxXQUFBO0FBQ0Esa0JBQUE7QUFDQSxjQUFBLEtBQUEsUUFBQTs7QUFFSixDQWpCSixxQkFpQkksQ0FBQTtBQUNJLFlBQUE7QUFDQSxPQUFBO0FBQ0EsUUFBQTtBQUNBLGFBQUEsVUFBQSxJQUFBLEVBQUE7O0FBSVIsQ0FBQSxVQUFBLENBQUE7QUFDSSxTQUFBO0FBQ0EsVUFBQTtBQUNBLGNBQUE7QUFDQSxhQUFBO0FBQ0E7SUFBQSxLQUFBO0lBQUEsU0FBQTtJQUFBO0FBQ0EsaUJBQUE7QUFDQSxrQkFBQTtBQUNBLFdBQUEsSUFBQTs7QUFDQSxDQVRKLFVBU0ksQ0FUSixVQVNJLENBQUE7QUFDSSxnQkFBQSxJQUFBOztBQUdKLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFiSixHQUFBLFVBQUEsQ0FBQTtBQWNRLFdBQUE7QUFDQSxZQUFBO0FBQ0EsYUFBQTtBQUNBLHFCQUFBO0FBQ0EsaUJBQUE7O0FBQ0EsR0FuQlIsVUFtQlEsQ0FuQlIsV0FtQlEsQ0EvREE7QUFnRUksZUFBQTs7O0FBSVIsT0FBQSxDQUFBLFNBQUEsRUFBQTtBQXhCSixHQUFBLFVBQUEsQ0FBQTtBQXlCUSxXQUFBO0FBQ0EsWUFBQTtBQUNBLGFBQUE7QUFDQSxxQkFBQTtBQUNBLGlCQUFBOztBQUNBLEdBOUJSLFVBOEJRLENBOUJSLFdBOEJRLENBMUVBO0FBMkVJLGVBQUE7OztBQUtaLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFDSSxHQXJDSixVQXFDSSxDQXJDSjtBQXNDUSxXQUFBO0FBQ0EsWUFBQTtBQUNBLGFBQUE7QUFDQSxxQkFBQTtBQUNBLGlCQUFBOztBQUNBLEdBM0NSLFVBMkNRLENBM0NSLFdBMkNRLENBdkZBO0FBd0ZJLGVBQUE7OzsiLAogICJuYW1lcyI6IFtdCn0K */'] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(QuizParticipationComponent, { className: "QuizParticipationComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/quiz/participate/quiz-participation.route.ts
var quizParticipationRoute;
var init_quiz_participation_route = __esm({
  "src/main/webapp/app/exercises/quiz/participate/quiz-participation.route.ts"() {
    init_quiz_participation_component();
    init_user_route_access_service();
    quizParticipationRoute = [
      {
        path: "live",
        component: QuizParticipationComponent,
        data: {
          authorities: [],
          pageTitle: "artemisApp.quizExercise.home.title",
          mode: "live"
        },
        canActivate: [UserRouteAccessService]
      },
      {
        path: "practice",
        component: QuizParticipationComponent,
        data: {
          authorities: [],
          pageTitle: "artemisApp.quizExercise.home.title",
          mode: "practice"
        },
        canActivate: [UserRouteAccessService]
      }
    ];
  }
});

// src/main/webapp/app/exercises/quiz/participate/quiz-participation.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { RouterModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisQuizParticipationModule;
var init_quiz_participation_module = __esm({
  "src/main/webapp/app/exercises/quiz/participate/quiz-participation.module.ts"() {
    init_quiz_participation_route();
    init_quiz_participation_component();
    init_shared_component_module();
    init_shared_module();
    init_artemis_quiz_question_types_module();
    ArtemisQuizParticipationModule = class _ArtemisQuizParticipationModule {
      static \u0275fac = function ArtemisQuizParticipationModule_Factory(t) {
        return new (t || _ArtemisQuizParticipationModule)();
      };
      static \u0275mod = i03.\u0275\u0275defineNgModule({ type: _ArtemisQuizParticipationModule });
      static \u0275inj = i03.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, RouterModule.forChild(quizParticipationRoute), ArtemisSharedComponentModule, ArtemisQuizQuestionTypesModule] });
    };
  }
});

export {
  QuizParticipationComponent,
  init_quiz_participation_component,
  ArtemisQuizParticipationModule,
  init_quiz_participation_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3F1aXovcGFydGljaXBhdGUvcXVpei1wYXJ0aWNpcGF0aW9uLnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9xdWl6L3BhcnRpY2lwYXRlL3F1aXotcGFydGljaXBhdGlvbi5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9xdWl6L3BhcnRpY2lwYXRlL3F1aXotcGFydGljaXBhdGlvbi5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3F1aXovcGFydGljaXBhdGUvcXVpei1wYXJ0aWNpcGF0aW9uLnJvdXRlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9wYXJ0aWNpcGF0ZS9xdWl6LXBhcnRpY2lwYXRpb24ubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IFF1aXpTdWJtaXNzaW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovcXVpei1zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IFJlc3VsdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9yZXN1bHQubW9kZWwnO1xuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgU3VibWlzc2lvblNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9zdWJtaXNzaW9uL3N1Ym1pc3Npb24uc2VydmljZSc7XG5cbmV4cG9ydCB0eXBlIEVudGl0eVJlc3BvbnNlVHlwZSA9IEh0dHBSZXNwb25zZTxRdWl6U3VibWlzc2lvbj47XG5leHBvcnQgdHlwZSBSZXN1bHRSZXNwb25zZVR5cGUgPSBIdHRwUmVzcG9uc2U8UmVzdWx0PjtcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBRdWl6UGFydGljaXBhdGlvblNlcnZpY2Uge1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQsXG4gICAgICAgIHByaXZhdGUgc3VibWlzc2lvblNlcnZpY2U6IFN1Ym1pc3Npb25TZXJ2aWNlLFxuICAgICkge31cblxuICAgIHN1Ym1pdEZvclByYWN0aWNlKHF1aXpTdWJtaXNzaW9uOiBRdWl6U3VibWlzc2lvbiwgZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxSZXN1bHRSZXNwb25zZVR5cGU+IHtcbiAgICAgICAgY29uc3QgY29weSA9IHRoaXMuc3VibWlzc2lvblNlcnZpY2UuY29udmVydChxdWl6U3VibWlzc2lvbik7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5wb3N0PFJlc3VsdD4oYGFwaS9leGVyY2lzZXMvJHtleGVyY2lzZUlkfS9zdWJtaXNzaW9ucy9wcmFjdGljZWAsIGNvcHksIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IFJlc3VsdFJlc3BvbnNlVHlwZSkgPT4gdGhpcy5zdWJtaXNzaW9uU2VydmljZS5jb252ZXJ0UmVzcG9uc2UocmVzKSkpO1xuICAgIH1cblxuICAgIHN1Ym1pdEZvclByZXZpZXcocXVpelN1Ym1pc3Npb246IFF1aXpTdWJtaXNzaW9uLCBleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPFJlc3VsdFJlc3BvbnNlVHlwZT4ge1xuICAgICAgICBjb25zdCBjb3B5ID0gdGhpcy5zdWJtaXNzaW9uU2VydmljZS5jb252ZXJ0KHF1aXpTdWJtaXNzaW9uKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLnBvc3Q8UmVzdWx0PihgYXBpL2V4ZXJjaXNlcy8ke2V4ZXJjaXNlSWR9L3N1Ym1pc3Npb25zL3ByZXZpZXdgLCBjb3B5LCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBSZXN1bHRSZXNwb25zZVR5cGUpID0+IHRoaXMuc3VibWlzc2lvblNlcnZpY2UuY29udmVydFJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG5cbiAgICBzdWJtaXRGb3JMaXZlTW9kZShxdWl6U3VibWlzc2lvbjogUXVpelN1Ym1pc3Npb24sIGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIGNvbnN0IGNvcHkgPSB0aGlzLnN1Ym1pc3Npb25TZXJ2aWNlLmNvbnZlcnQocXVpelN1Ym1pc3Npb24pO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAucG9zdDxRdWl6U3VibWlzc2lvbj4oYGFwaS9leGVyY2lzZXMvJHtleGVyY2lzZUlkfS9zdWJtaXNzaW9ucy9saXZlYCwgY29weSwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlczogRW50aXR5UmVzcG9uc2VUeXBlKSA9PiB0aGlzLnN1Ym1pc3Npb25TZXJ2aWNlLmNvbnZlcnRSZXNwb25zZShyZXMpKSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkRlc3Ryb3ksIE9uSW5pdCwgUXVlcnlMaXN0LCBWaWV3Q2hpbGRyZW4gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCBkYXlqcyBmcm9tICdkYXlqcy9lc20nO1xuaW1wb3J0IGlzTW9iaWxlIGZyb20gJ2lzbW9iaWxlanMtZXM1JztcbmltcG9ydCB7IEh0dHBFcnJvclJlc3BvbnNlLCBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSwgQWxlcnRUeXBlIH0gZnJvbSAnYXBwL2NvcmUvdXRpbC9hbGVydC5zZXJ2aWNlJztcbmltcG9ydCB7IFBhcnRpY2lwYXRpb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGFydGljaXBhdGlvbi9wYXJ0aWNpcGF0aW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgUGFydGljaXBhdGlvbldlYnNvY2tldFNlcnZpY2UgfSBmcm9tICdhcHAvb3ZlcnZpZXcvcGFydGljaXBhdGlvbi13ZWJzb2NrZXQuc2VydmljZSc7XG5pbXBvcnQgeyBSZXN1bHQgfSBmcm9tICdhcHAvZW50aXRpZXMvcmVzdWx0Lm1vZGVsJztcbmltcG9ydCB7IE11bHRpcGxlQ2hvaWNlUXVlc3Rpb25Db21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3F1aXovc2hhcmVkL3F1ZXN0aW9ucy9tdWx0aXBsZS1jaG9pY2UtcXVlc3Rpb24vbXVsdGlwbGUtY2hvaWNlLXF1ZXN0aW9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBEcmFnQW5kRHJvcFF1ZXN0aW9uQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9xdWl6L3NoYXJlZC9xdWVzdGlvbnMvZHJhZy1hbmQtZHJvcC1xdWVzdGlvbi9kcmFnLWFuZC1kcm9wLXF1ZXN0aW9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBTaG9ydEFuc3dlclF1ZXN0aW9uQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9xdWl6L3NoYXJlZC9xdWVzdGlvbnMvc2hvcnQtYW5zd2VyLXF1ZXN0aW9uL3Nob3J0LWFuc3dlci1xdWVzdGlvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgVHJhbnNsYXRlU2VydmljZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xuaW1wb3J0ICogYXMgc21vb3Roc2Nyb2xsIGZyb20gJ3Ntb290aHNjcm9sbC1wb2x5ZmlsbCc7XG5pbXBvcnQgeyBTdHVkZW50UGFydGljaXBhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9wYXJ0aWNpcGF0aW9uL3N0dWRlbnQtcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBCdXR0b25TaXplLCBCdXR0b25UeXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL2J1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgSmhpV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3dlYnNvY2tldC93ZWJzb2NrZXQuc2VydmljZSc7XG5pbXBvcnQgeyBTaG9ydEFuc3dlclN1Ym1pdHRlZEFuc3dlciB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L3Nob3J0LWFuc3dlci1zdWJtaXR0ZWQtYW5zd2VyLm1vZGVsJztcbmltcG9ydCB7IFF1aXpFeGVyY2lzZVNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3F1aXovbWFuYWdlL3F1aXotZXhlcmNpc2Uuc2VydmljZSc7XG5pbXBvcnQgeyBEcmFnQW5kRHJvcE1hcHBpbmcgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9kcmFnLWFuZC1kcm9wLW1hcHBpbmcubW9kZWwnO1xuaW1wb3J0IHsgQW5zd2VyT3B0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovYW5zd2VyLW9wdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBTaG9ydEFuc3dlclN1Ym1pdHRlZFRleHQgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9zaG9ydC1hbnN3ZXItc3VibWl0dGVkLXRleHQubW9kZWwnO1xuaW1wb3J0IHsgUXVpelBhcnRpY2lwYXRpb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9xdWl6L3BhcnRpY2lwYXRlL3F1aXotcGFydGljaXBhdGlvbi5zZXJ2aWNlJztcbmltcG9ydCB7IE11bHRpcGxlQ2hvaWNlUXVlc3Rpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9tdWx0aXBsZS1jaG9pY2UtcXVlc3Rpb24ubW9kZWwnO1xuaW1wb3J0IHsgUXVpekJhdGNoLCBRdWl6RXhlcmNpc2UsIFF1aXpNb2RlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovcXVpei1leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBEcmFnQW5kRHJvcFN1Ym1pdHRlZEFuc3dlciB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L2RyYWctYW5kLWRyb3Atc3VibWl0dGVkLWFuc3dlci5tb2RlbCc7XG5pbXBvcnQgeyBRdWl6U3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L3F1aXotc3VibWlzc2lvbi5tb2RlbCc7XG5pbXBvcnQgeyBTaG9ydEFuc3dlclF1ZXN0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovc2hvcnQtYW5zd2VyLXF1ZXN0aW9uLm1vZGVsJztcbmltcG9ydCB7IFF1aXpRdWVzdGlvblR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9xdWl6LXF1ZXN0aW9uLm1vZGVsJztcbmltcG9ydCB7IE11bHRpcGxlQ2hvaWNlU3VibWl0dGVkQW5zd2VyIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovbXVsdGlwbGUtY2hvaWNlLXN1Ym1pdHRlZC1hbnN3ZXIubW9kZWwnO1xuaW1wb3J0IHsgRHJhZ0FuZERyb3BRdWVzdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L2RyYWctYW5kLWRyb3AtcXVlc3Rpb24ubW9kZWwnO1xuaW1wb3J0IHsgQXJ0ZW1pc1F1aXpTZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9xdWl6L3F1aXouc2VydmljZSc7XG5pbXBvcnQgeyByb3VuZFZhbHVlU3BlY2lmaWVkQnlDb3Vyc2VTZXR0aW5ncyB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC91dGlscyc7XG5pbXBvcnQgeyBvbkVycm9yIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2dsb2JhbC51dGlscyc7XG5pbXBvcnQgeyBVSV9SRUxPQURfVElNRSB9IGZyb20gJ2FwcC9zaGFyZWQvY29uc3RhbnRzL2V4ZXJjaXNlLWV4YW0tY29uc3RhbnRzJztcbmltcG9ydCB7IGRlYm91bmNlIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IGNhcHR1cmVFeGNlcHRpb24gfSBmcm9tICdAc2VudHJ5L2FuZ3VsYXItaXZ5JztcbmltcG9ydCB7IGdldENvdXJzZUZyb21FeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBmYUNpcmNsZU5vdGNoLCBmYVN5bmMgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NlcnZlckRhdGVTZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9zZXJ2ZXItZGF0ZS5zZXJ2aWNlJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktcXVpeicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL3F1aXotcGFydGljaXBhdGlvbi5jb21wb25lbnQuaHRtbCcsXG4gICAgcHJvdmlkZXJzOiBbUGFydGljaXBhdGlvblNlcnZpY2VdLFxuICAgIHN0eWxlVXJsczogWycuL3F1aXotcGFydGljaXBhdGlvbi5jb21wb25lbnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBRdWl6UGFydGljaXBhdGlvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcbiAgICAvLyBtYWtlIGNvbnN0YW50cyBhdmFpbGFibGUgdG8gaHRtbCBmb3IgY29tcGFyaXNvblxuICAgIHJlYWRvbmx5IERSQUdfQU5EX0RST1AgPSBRdWl6UXVlc3Rpb25UeXBlLkRSQUdfQU5EX0RST1A7XG4gICAgcmVhZG9ubHkgTVVMVElQTEVfQ0hPSUNFID0gUXVpelF1ZXN0aW9uVHlwZS5NVUxUSVBMRV9DSE9JQ0U7XG4gICAgcmVhZG9ubHkgU0hPUlRfQU5TV0VSID0gUXVpelF1ZXN0aW9uVHlwZS5TSE9SVF9BTlNXRVI7XG4gICAgcmVhZG9ubHkgQnV0dG9uU2l6ZSA9IEJ1dHRvblNpemU7XG4gICAgcmVhZG9ubHkgQnV0dG9uVHlwZSA9IEJ1dHRvblR5cGU7XG4gICAgcmVhZG9ubHkgUXVpek1vZGUgPSBRdWl6TW9kZTtcbiAgICByZWFkb25seSByb3VuZFNjb3JlU3BlY2lmaWVkQnlDb3Vyc2VTZXR0aW5ncyA9IHJvdW5kVmFsdWVTcGVjaWZpZWRCeUNvdXJzZVNldHRpbmdzO1xuICAgIHJlYWRvbmx5IGdldENvdXJzZUZyb21FeGVyY2lzZSA9IGdldENvdXJzZUZyb21FeGVyY2lzZTtcblxuICAgIEBWaWV3Q2hpbGRyZW4oTXVsdGlwbGVDaG9pY2VRdWVzdGlvbkNvbXBvbmVudClcbiAgICBtY1F1ZXN0aW9uQ29tcG9uZW50czogUXVlcnlMaXN0PE11bHRpcGxlQ2hvaWNlUXVlc3Rpb25Db21wb25lbnQ+O1xuXG4gICAgQFZpZXdDaGlsZHJlbihEcmFnQW5kRHJvcFF1ZXN0aW9uQ29tcG9uZW50KVxuICAgIGRuZFF1ZXN0aW9uQ29tcG9uZW50czogUXVlcnlMaXN0PERyYWdBbmREcm9wUXVlc3Rpb25Db21wb25lbnQ+O1xuXG4gICAgQFZpZXdDaGlsZHJlbihTaG9ydEFuc3dlclF1ZXN0aW9uQ29tcG9uZW50KVxuICAgIHNob3J0QW5zd2VyUXVlc3Rpb25Db21wb25lbnRzOiBRdWVyeUxpc3Q8U2hvcnRBbnN3ZXJRdWVzdGlvbkNvbXBvbmVudD47XG5cbiAgICBwcml2YXRlIHN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xuICAgIHByaXZhdGUgc3Vic2NyaXB0aW9uRGF0YTogU3Vic2NyaXB0aW9uO1xuXG4gICAgcnVubmluZ1RpbWVvdXRzID0gbmV3IEFycmF5PGFueT4oKTsgLy8gYWN0dWFsbHkgdGhlIGZ1bmN0aW9uIHR5cGUgc2V0VGltZW91dCgpOiAoaGFuZGxlcjogYW55LCB0aW1lb3V0PzogYW55LCAuLi5hcmdzOiBhbnlbXSk6IG51bWJlclxuXG4gICAgaXNTdWJtaXR0aW5nID0gZmFsc2U7XG4gICAgLy8gaXNTYXZpbmcgPSBmYWxzZTtcbiAgICBsYXN0U2F2ZWRUaW1lVGV4dCA9ICcnO1xuICAgIGp1c3RTYXZlZCA9IGZhbHNlO1xuICAgIHdhaXRpbmdGb3JRdWl6U3RhcnQgPSBmYWxzZTtcbiAgICByZWZyZXNoaW5nUXVpeiA9IGZhbHNlO1xuXG4gICAgcmVtYWluaW5nVGltZVRleHQgPSAnPyc7XG4gICAgcmVtYWluaW5nVGltZVNlY29uZHMgPSAwO1xuICAgIHRpbWVVbnRpbFN0YXJ0ID0gJzAnO1xuICAgIGRpc2Nvbm5lY3RlZCA9IGZhbHNlO1xuICAgIHVuc2F2ZWRDaGFuZ2VzID0gZmFsc2U7XG5cbiAgICBzZW5kV2Vic29ja2V0PzogKHN1Ym1pc3Npb246IFF1aXpTdWJtaXNzaW9uKSA9PiB2b2lkO1xuICAgIHNob3dpbmdSZXN1bHQgPSBmYWxzZTtcbiAgICB1c2VyU2NvcmU6IG51bWJlcjtcblxuICAgIG1vZGU6IHN0cmluZztcbiAgICBzdWJtaXNzaW9uID0gbmV3IFF1aXpTdWJtaXNzaW9uKCk7XG4gICAgcXVpekV4ZXJjaXNlOiBRdWl6RXhlcmNpc2U7XG4gICAgcXVpekJhdGNoPzogUXVpekJhdGNoO1xuICAgIHRvdGFsU2NvcmU6IG51bWJlcjtcbiAgICBzZWxlY3RlZEFuc3dlck9wdGlvbnMgPSBuZXcgTWFwPG51bWJlciwgQW5zd2VyT3B0aW9uW10+KCk7XG4gICAgZHJhZ0FuZERyb3BNYXBwaW5ncyA9IG5ldyBNYXA8bnVtYmVyLCBEcmFnQW5kRHJvcE1hcHBpbmdbXT4oKTtcbiAgICBzaG9ydEFuc3dlclN1Ym1pdHRlZFRleHRzID0gbmV3IE1hcDxudW1iZXIsIFNob3J0QW5zd2VyU3VibWl0dGVkVGV4dFtdPigpO1xuICAgIHJlc3VsdDogUmVzdWx0O1xuICAgIHF1ZXN0aW9uU2NvcmVzID0ge307XG4gICAgcXVpeklkOiBudW1iZXI7XG4gICAgY291cnNlSWQ6IG51bWJlcjtcbiAgICBpbnRlcnZhbDogYW55O1xuICAgIHF1aXpTdGFydGVkID0gZmFsc2U7XG4gICAgc3RhcnREYXRlOiBkYXlqcy5EYXlqcyB8IHVuZGVmaW5lZDtcbiAgICBlbmREYXRlOiBkYXlqcy5EYXlqcyB8IHVuZGVmaW5lZDtcbiAgICBwYXNzd29yZCA9ICcnO1xuICAgIHByZXZpb3VzUnVubmluZyA9IGZhbHNlO1xuICAgIGlzTW9iaWxlID0gZmFsc2U7XG5cbiAgICAvKipcbiAgICAgKiBXZWJzb2NrZXQgY2hhbm5lbHNcbiAgICAgKi9cbiAgICBzdWJtaXNzaW9uQ2hhbm5lbDogc3RyaW5nO1xuICAgIHBhcnRpY2lwYXRpb25DaGFubmVsOiBzdHJpbmc7XG4gICAgcXVpekV4ZXJjaXNlQ2hhbm5lbDogc3RyaW5nO1xuICAgIHF1aXpCYXRjaENoYW5uZWw6IHN0cmluZztcbiAgICB3ZWJzb2NrZXRTdWJzY3JpcHRpb24/OiBTdWJzY3JpcHRpb247XG5cbiAgICAvKipcbiAgICAgKiBkZWJvdW5jZWQgZnVuY3Rpb24gdG8gcmVzZXQgJ2p1c3RTdWJtaXR0ZWQnLCBzbyB0aGF0IHRpbWUgc2luY2UgbGFzdCBzdWJtaXNzaW9uIGlzIGRpc3BsYXllZCBhZ2FpbiB3aGVuIG5vIHN1Ym1pc3Npb24gaGFzIGJlZW4gbWFkZSBmb3IgYXQgbGVhc3QgMiBzZWNvbmRzXG4gICAgICogQHR5cGUge0Z1bmN0aW9ufVxuICAgICAqL1xuICAgIHRpbWVvdXRKdXN0U2F2ZWQgPSBkZWJvdW5jZSgoKSA9PiB7XG4gICAgICAgIHRoaXMuanVzdFNhdmVkID0gZmFsc2U7XG4gICAgfSwgMjAwMCk7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhU3luYyA9IGZhU3luYztcbiAgICBmYUNpcmNsZU5vdGNoID0gZmFDaXJjbGVOb3RjaDtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGpoaVdlYnNvY2tldFNlcnZpY2U6IEpoaVdlYnNvY2tldFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgcXVpekV4ZXJjaXNlU2VydmljZTogUXVpekV4ZXJjaXNlU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBwYXJ0aWNpcGF0aW9uU2VydmljZTogUGFydGljaXBhdGlvblNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgcGFydGljaXBhdGlvbldlYnNvY2tldFNlcnZpY2U6IFBhcnRpY2lwYXRpb25XZWJzb2NrZXRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSxcbiAgICAgICAgcHJpdmF0ZSBhbGVydFNlcnZpY2U6IEFsZXJ0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBxdWl6UGFydGljaXBhdGlvblNlcnZpY2U6IFF1aXpQYXJ0aWNpcGF0aW9uU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSB0cmFuc2xhdGVTZXJ2aWNlOiBUcmFuc2xhdGVTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHF1aXpTZXJ2aWNlOiBBcnRlbWlzUXVpelNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgc2VydmVyRGF0ZVNlcnZpY2U6IEFydGVtaXNTZXJ2ZXJEYXRlU2VydmljZSxcbiAgICApIHtcbiAgICAgICAgc21vb3Roc2Nyb2xsLnBvbHlmaWxsKCk7XG4gICAgfVxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMuaXNNb2JpbGUgPSBpc01vYmlsZSh3aW5kb3cubmF2aWdhdG9yLnVzZXJBZ2VudCkuYW55O1xuICAgICAgICAvLyBzZXQgY29ycmVjdCBtb2RlXG4gICAgICAgIHRoaXMuc3Vic2NyaXB0aW9uRGF0YSA9IHRoaXMucm91dGUuZGF0YS5zdWJzY3JpYmUoKGRhdGEpID0+IHtcbiAgICAgICAgICAgIHRoaXMubW9kZSA9IGRhdGEubW9kZTtcbiAgICAgICAgICAgIHRoaXMuc3Vic2NyaXB0aW9uID0gdGhpcy5yb3V0ZS5wYXJhbXMuc3Vic2NyaWJlKChwYXJhbXMpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnF1aXpJZCA9IE51bWJlcihwYXJhbXNbJ2V4ZXJjaXNlSWQnXSk7XG4gICAgICAgICAgICAgICAgdGhpcy5jb3Vyc2VJZCA9IE51bWJlcihwYXJhbXNbJ2NvdXJzZUlkJ10pO1xuICAgICAgICAgICAgICAgIC8vIGluaXQgYWNjb3JkaW5nIHRvIG1vZGVcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRoaXMubW9kZSkge1xuICAgICAgICAgICAgICAgICAgICBjYXNlICdwcmFjdGljZSc6XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmluaXRQcmFjdGljZU1vZGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBjYXNlICdwcmV2aWV3JzpcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5pdFByZXZpZXcoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBjYXNlICdzb2x1dGlvbic6XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmluaXRTaG93U29sdXRpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBjYXNlICdsaXZlJzpcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5pdExpdmVNb2RlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIHVwZGF0ZSBkaXNwbGF5ZWQgdGltZXMgaW4gVUkgcmVndWxhcmx5XG4gICAgICAgIHRoaXMuaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZURpc3BsYXllZFRpbWVzKCk7XG4gICAgICAgICAgICB0aGlzLmNoZWNrRm9yUXVpekVuZCgpO1xuICAgICAgICB9LCBVSV9SRUxPQURfVElNRSk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy5pbnRlcnZhbCk7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiB1bnN1YnNjcmliZSBmcm9tIGFsbCBzdWJzY3JpYmVkIHdlYnNvY2tldCBjaGFubmVscyB3aGVuIHBhZ2UgaXMgY2xvc2VkXG4gICAgICAgICAqL1xuICAgICAgICB0aGlzLnJ1bm5pbmdUaW1lb3V0cy5mb3JFYWNoKCh0aW1lb3V0KSA9PiB7XG4gICAgICAgICAgICBjbGVhclRpbWVvdXQodGltZW91dCk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmICh0aGlzLnN1Ym1pc3Npb25DaGFubmVsKSB7XG4gICAgICAgICAgICB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2UudW5zdWJzY3JpYmUoJy91c2VyJyArIHRoaXMuc3VibWlzc2lvbkNoYW5uZWwpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLnBhcnRpY2lwYXRpb25DaGFubmVsKSB7XG4gICAgICAgICAgICB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2UudW5zdWJzY3JpYmUodGhpcy5wYXJ0aWNpcGF0aW9uQ2hhbm5lbCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMucXVpekV4ZXJjaXNlQ2hhbm5lbCkge1xuICAgICAgICAgICAgdGhpcy5qaGlXZWJzb2NrZXRTZXJ2aWNlLnVuc3Vic2NyaWJlKHRoaXMucXVpekV4ZXJjaXNlQ2hhbm5lbCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy53ZWJzb2NrZXRTdWJzY3JpcHRpb24/LnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIGlmICh0aGlzLnN1YnNjcmlwdGlvbikge1xuICAgICAgICAgICAgdGhpcy5zdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5zdWJzY3JpcHRpb25EYXRhKSB7XG4gICAgICAgICAgICB0aGlzLnN1YnNjcmlwdGlvbkRhdGEudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGxvYWRzIGxhdGVzdCBzdWJtaXNzaW9uIGZyb20gc2VydmVyIGFuZCBzZXRzIHVwIHNvY2tldCBjb25uZWN0aW9uXG4gICAgICovXG4gICAgaW5pdExpdmVNb2RlKCkge1xuICAgICAgICAvLyBsaXN0ZW4gdG8gY29ubmVjdCAvIGRpc2Nvbm5lY3QgZXZlbnRzXG4gICAgICAgIHRoaXMud2Vic29ja2V0U3Vic2NyaXB0aW9uID0gdGhpcy5qaGlXZWJzb2NrZXRTZXJ2aWNlLmNvbm5lY3Rpb25TdGF0ZS5zdWJzY3JpYmUoKHN0YXR1cykgPT4ge1xuICAgICAgICAgICAgaWYgKHN0YXR1cy5jb25uZWN0ZWQgJiYgdGhpcy5kaXNjb25uZWN0ZWQpIHtcbiAgICAgICAgICAgICAgICAvLyBpZiB0aGUgZGlzY29ubmVjdCBoYXBwZW5lZCBkdXJpbmcgdGhlIGxpdmUgcXVpeiBhbmQgdGhlcmUgYXJlIHVuc2F2ZWQgY2hhbmdlcywgd2UgdHJpZ2dlciBhIHNlbGVjdGlvbiBjaGFuZ2VkIGV2ZW50IHRvIHNhdmUgdGhlIHN1Ym1pc3Npb24gb24gdGhlIHNlcnZlclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLnVuc2F2ZWRDaGFuZ2VzICYmIHRoaXMuc2VuZFdlYnNvY2tldCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uU2VsZWN0aW9uQ2hhbmdlZCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBpZiB0aGUgcXVpeiB3YXMgbm90IHlldCBzdGFydGVkLCB3ZSBtaWdodCBoYXZlIG1pc3NlZCB0aGUgcXVpeiBzdGFydCA9PiByZWZyZXNoXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMucXVpekJhdGNoICYmICF0aGlzLnF1aXpCYXRjaC5zdGFydGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVmcmVzaFF1aXoodHJ1ZSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLnF1aXpCYXRjaCAmJiB0aGlzLmVuZERhdGUgJiYgdGhpcy5lbmREYXRlLmlzQmVmb3JlKHRoaXMuc2VydmVyRGF0ZVNlcnZpY2Uubm93KCkpKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGlmIHRoZSBxdWl6IGhhcyBlbmRlZCwgd2UgbWlnaHQgaGF2ZSBtaXNzZWQgdG8gbG9hZCB0aGUgcmVzdWx0cyA9PiByZWZyZXNoXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVmcmVzaFF1aXoodHJ1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5kaXNjb25uZWN0ZWQgPSAhc3RhdHVzLmNvbm5lY3RlZDtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5zdWJzY3JpYmVUb1dlYnNvY2tldENoYW5uZWxzKCk7XG5cbiAgICAgICAgLy8gbG9hZCB0aGUgcXVpeiAoYW5kIGV4aXN0aW5nIHN1Ym1pc3Npb24gaWYgcXVpeiBoYXMgc3RhcnRlZClcbiAgICAgICAgdGhpcy5wYXJ0aWNpcGF0aW9uU2VydmljZS5maW5kUGFydGljaXBhdGlvbkZvckN1cnJlbnRVc2VyKHRoaXMucXVpeklkKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2U8U3R1ZGVudFBhcnRpY2lwYXRpb24+KSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy51cGRhdGVQYXJ0aWNpcGF0aW9uRnJvbVNlcnZlcihyZXNwb25zZS5ib2R5ISk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZXJyb3I6IChlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpID0+IG9uRXJyb3IodGhpcy5hbGVydFNlcnZpY2UsIGVycm9yKSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogbG9hZHMgcXVpekV4ZXJjaXNlIGFuZCBzdGFydHMgcHJhY3RpY2UgbW9kZVxuICAgICAqL1xuICAgIGluaXRQcmFjdGljZU1vZGUoKSB7XG4gICAgICAgIHRoaXMucXVpekV4ZXJjaXNlU2VydmljZS5maW5kRm9yU3R1ZGVudCh0aGlzLnF1aXpJZCkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5leHQ6IChyZXM6IEh0dHBSZXNwb25zZTxRdWl6RXhlcmNpc2U+KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlcy5ib2R5ICYmIHJlcy5ib2R5LmlzT3BlbkZvclByYWN0aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhcnRRdWl6UHJldmlld09yUHJhY3RpY2UocmVzLmJvZHkpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGFsZXJ0KCdFcnJvcjogVGhpcyBxdWl6IGlzIG5vdCBvcGVuIGZvciBwcmFjdGljZSEnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZXJyb3I6IChlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpID0+IG9uRXJyb3IodGhpcy5hbGVydFNlcnZpY2UsIGVycm9yKSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogbG9hZHMgcXVpeiBleGVyY2lzZSBhbmQgc3RhcnRzIHByZXZpZXcgbW9kZVxuICAgICAqL1xuICAgIGluaXRQcmV2aWV3KCkge1xuICAgICAgICB0aGlzLnF1aXpFeGVyY2lzZVNlcnZpY2UuZmluZCh0aGlzLnF1aXpJZCkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5leHQ6IChyZXM6IEh0dHBSZXNwb25zZTxRdWl6RXhlcmNpc2U+KSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5zdGFydFF1aXpQcmV2aWV3T3JQcmFjdGljZShyZXMuYm9keSEpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yOiAoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiBvbkVycm9yKHRoaXMuYWxlcnRTZXJ2aWNlLCBlcnJvciksXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGluaXRTaG93U29sdXRpb24oKSB7XG4gICAgICAgIHRoaXMucXVpekV4ZXJjaXNlU2VydmljZS5maW5kKHRoaXMucXVpeklkKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKHJlczogSHR0cFJlc3BvbnNlPFF1aXpFeGVyY2lzZT4pID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnF1aXpFeGVyY2lzZSA9IHJlcy5ib2R5ITtcbiAgICAgICAgICAgICAgICB0aGlzLmluaXRRdWl6KCk7XG4gICAgICAgICAgICAgICAgdGhpcy5zaG93aW5nUmVzdWx0ID0gdHJ1ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4gb25FcnJvcih0aGlzLmFsZXJ0U2VydmljZSwgZXJyb3IpLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTdGFydCB0aGUgZ2l2ZW4gcXVpeiBpbiBwcmFjdGljZSBvciBwcmV2aWV3IG1vZGVcbiAgICAgKlxuICAgICAqIEBwYXJhbSBxdWl6RXhlcmNpc2Uge29iamVjdH0gdGhlIHF1aXpFeGVyY2lzZSB0byBzdGFydFxuICAgICAqL1xuICAgIHN0YXJ0UXVpelByZXZpZXdPclByYWN0aWNlKHF1aXpFeGVyY2lzZTogUXVpekV4ZXJjaXNlKSB7XG4gICAgICAgIC8vIGluaXQgcXVpelxuICAgICAgICB0aGlzLnF1aXpFeGVyY2lzZSA9IHF1aXpFeGVyY2lzZTtcbiAgICAgICAgdGhpcy5pbml0UXVpeigpO1xuXG4gICAgICAgIC8vIHJhbmRvbWl6ZSBvcmRlclxuICAgICAgICB0aGlzLnF1aXpTZXJ2aWNlLnJhbmRvbWl6ZU9yZGVyKHRoaXMucXVpekV4ZXJjaXNlLnF1aXpRdWVzdGlvbnMsIHRoaXMucXVpekV4ZXJjaXNlLnJhbmRvbWl6ZVF1ZXN0aW9uT3JkZXIpO1xuXG4gICAgICAgIC8vIGluaXQgZW1wdHkgc3VibWlzc2lvblxuICAgICAgICB0aGlzLnN1Ym1pc3Npb24gPSBuZXcgUXVpelN1Ym1pc3Npb24oKTtcblxuICAgICAgICAvLyBhZGp1c3QgZW5kIGRhdGVcbiAgICAgICAgdGhpcy5lbmREYXRlID0gZGF5anMoKS5hZGQodGhpcy5xdWl6RXhlcmNpc2UuZHVyYXRpb24hLCAnc2Vjb25kcycpO1xuXG4gICAgICAgIC8vIGF1dG8gc3VibWl0IHdoZW4gdGltZSBpcyB1cFxuICAgICAgICB0aGlzLnJ1bm5pbmdUaW1lb3V0cy5wdXNoKFxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5vblN1Ym1pdCgpO1xuICAgICAgICAgICAgfSwgcXVpekV4ZXJjaXNlLmR1cmF0aW9uISAqIDEwMDApLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIHN1YnNjcmliZSB0byBhbnkgb3V0c3RhbmRpbmcgd2Vic29ja2V0IGNoYW5uZWxzXG4gICAgICovXG4gICAgc3Vic2NyaWJlVG9XZWJzb2NrZXRDaGFubmVscygpIHtcbiAgICAgICAgaWYgKCF0aGlzLnN1Ym1pc3Npb25DaGFubmVsKSB7XG4gICAgICAgICAgICB0aGlzLnN1Ym1pc3Npb25DaGFubmVsID0gJy90b3BpYy9xdWl6RXhlcmNpc2UvJyArIHRoaXMucXVpeklkICsgJy9zdWJtaXNzaW9uJztcblxuICAgICAgICAgICAgLy8gc3VibWlzc2lvbiBjaGFubmVsID0+IHJlYWN0IHRvIG5ldyBzdWJtaXNzaW9uc1xuICAgICAgICAgICAgdGhpcy5qaGlXZWJzb2NrZXRTZXJ2aWNlLnN1YnNjcmliZSgnL3VzZXInICsgdGhpcy5zdWJtaXNzaW9uQ2hhbm5lbCk7XG4gICAgICAgICAgICB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2UucmVjZWl2ZSgnL3VzZXInICsgdGhpcy5zdWJtaXNzaW9uQ2hhbm5lbCkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAocGF5bG9hZCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAocGF5bG9hZC5lcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vblNhdmVFcnJvcihwYXlsb2FkLmVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgZXJyb3I6IChlcnJvcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uU2F2ZUVycm9yKGVycm9yKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIC8vIHNhdmUgYW5zd2VycyAoc3VibWlzc2lvbnMpIHRocm91Z2ggd2Vic29ja2V0XG4gICAgICAgICAgICB0aGlzLnNlbmRXZWJzb2NrZXQgPSAoc3VibWlzc2lvbjogUXVpelN1Ym1pc3Npb24pID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2Uuc2VuZCh0aGlzLnN1Ym1pc3Npb25DaGFubmVsLCBzdWJtaXNzaW9uKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXRoaXMucGFydGljaXBhdGlvbkNoYW5uZWwpIHtcbiAgICAgICAgICAgIHRoaXMucGFydGljaXBhdGlvbkNoYW5uZWwgPSAnL3VzZXIvdG9waWMvZXhlcmNpc2UvJyArIHRoaXMucXVpeklkICsgJy9wYXJ0aWNpcGF0aW9uJztcbiAgICAgICAgICAgIC8vIFRPRE86IHN1YnNjcmliZSBmb3IgbmV3IHJlc3VsdHMgaW5zdGVhZCBpZiB0aGlzIGlzIHdoYXQgd2UgYXJlIGFjdHVhbGx5IGludGVyZXN0ZWQgaW5cbiAgICAgICAgICAgIC8vIHBhcnRpY2lwYXRpb24gY2hhbm5lbCA9PiByZWFjdCB0byBuZXcgcmVzdWx0c1xuICAgICAgICAgICAgdGhpcy5qaGlXZWJzb2NrZXRTZXJ2aWNlLnN1YnNjcmliZSh0aGlzLnBhcnRpY2lwYXRpb25DaGFubmVsKTtcbiAgICAgICAgICAgIHRoaXMuamhpV2Vic29ja2V0U2VydmljZS5yZWNlaXZlKHRoaXMucGFydGljaXBhdGlvbkNoYW5uZWwpLnN1YnNjcmliZSgoY2hhbmdlZFBhcnRpY2lwYXRpb246IFN0dWRlbnRQYXJ0aWNpcGF0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGNoYW5nZWRQYXJ0aWNpcGF0aW9uICYmIHRoaXMucXVpekV4ZXJjaXNlICYmIGNoYW5nZWRQYXJ0aWNpcGF0aW9uLmV4ZXJjaXNlIS5pZCA9PT0gdGhpcy5xdWl6RXhlcmNpc2UuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMud2FpdGluZ0ZvclF1aXpTdGFydCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gb25seSBhcHBseSBjb21wbGV0ZWx5IGlmIHF1aXogaGFzbid0IHN0YXJ0ZWQgdG8gcHJldmVudCBqdW1waW5nIHVpIGR1cmluZyBwYXJ0aWNpcGF0aW9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZVBhcnRpY2lwYXRpb25Gcm9tU2VydmVyKGNoYW5nZWRQYXJ0aWNpcGF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHVwZGF0ZSBxdWl6RXhlcmNpc2UgYW5kIHJlc3VsdHMgLyBzdWJtaXNzaW9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNob3dRdWl6UmVzdWx0QWZ0ZXJRdWl6RW5kKGNoYW5nZWRQYXJ0aWNpcGF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCF0aGlzLnF1aXpFeGVyY2lzZUNoYW5uZWwpIHtcbiAgICAgICAgICAgIHRoaXMucXVpekV4ZXJjaXNlQ2hhbm5lbCA9ICcvdG9waWMvY291cnNlcy8nICsgdGhpcy5jb3Vyc2VJZCArICcvcXVpekV4ZXJjaXNlcyc7XG4gICAgICAgICAgICAvLyBxdWl6RXhlcmNpc2UgY2hhbm5lbCA9PiByZWFjdCB0byBjaGFuZ2VzIG1hZGUgdG8gcXVpekV4ZXJjaXNlIChlLmcuIHN0YXJ0IGRhdGUpXG4gICAgICAgICAgICB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2Uuc3Vic2NyaWJlKHRoaXMucXVpekV4ZXJjaXNlQ2hhbm5lbCk7XG4gICAgICAgICAgICB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2UucmVjZWl2ZSh0aGlzLnF1aXpFeGVyY2lzZUNoYW5uZWwpLnN1YnNjcmliZSgocXVpeikgPT4ge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLndhaXRpbmdGb3JRdWl6U3RhcnQgJiYgdGhpcy5xdWl6SWQgPT09IHF1aXouaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hcHBseVF1aXpGdWxsKHF1aXopO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMucXVpekJhdGNoICYmICF0aGlzLnF1aXpCYXRjaC5zdGFydGVkKSB7XG4gICAgICAgICAgICBjb25zdCBiYXRjaENoYW5uZWwgPSB0aGlzLnF1aXpFeGVyY2lzZUNoYW5uZWwgKyAnLycgKyB0aGlzLnF1aXpCYXRjaC5pZDtcbiAgICAgICAgICAgIGlmICh0aGlzLnF1aXpCYXRjaENoYW5uZWwgIT09IGJhdGNoQ2hhbm5lbCkge1xuICAgICAgICAgICAgICAgIHRoaXMucXVpekJhdGNoQ2hhbm5lbCA9IGJhdGNoQ2hhbm5lbDtcbiAgICAgICAgICAgICAgICB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2Uuc3Vic2NyaWJlKHRoaXMucXVpekJhdGNoQ2hhbm5lbCk7XG4gICAgICAgICAgICAgICAgdGhpcy5qaGlXZWJzb2NrZXRTZXJ2aWNlLnJlY2VpdmUodGhpcy5xdWl6QmF0Y2hDaGFubmVsKS5zdWJzY3JpYmUoKHF1aXopID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hcHBseVF1aXpGdWxsKHF1aXopO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogdXBkYXRlcyBhbGwgZGlzcGxheWVkIChyZWxhdGl2ZSkgdGltZXMgaW4gdGhlIFVJXG4gICAgICovXG4gICAgdXBkYXRlRGlzcGxheWVkVGltZXMoKSB7XG4gICAgICAgIGNvbnN0IHRyYW5zbGF0aW9uQmFzZVBhdGggPSAnYXJ0ZW1pc0FwcC5zaG93U3RhdGlzdGljLic7XG4gICAgICAgIC8vIHVwZGF0ZSByZW1haW5pbmcgdGltZVxuICAgICAgICBpZiAodGhpcy5lbmREYXRlKSB7XG4gICAgICAgICAgICBjb25zdCBlbmREYXRlID0gdGhpcy5lbmREYXRlO1xuICAgICAgICAgICAgaWYgKGVuZERhdGUuaXNBZnRlcih0aGlzLnNlcnZlckRhdGVTZXJ2aWNlLm5vdygpKSkge1xuICAgICAgICAgICAgICAgIC8vIHF1aXogaXMgc3RpbGwgcnVubmluZyA9PiBjYWxjdWxhdGUgcmVtYWluaW5nIHNlY29uZHMgYW5kIGdlbmVyYXRlIHRleHQgYmFzZWQgb24gdGhhdFxuICAgICAgICAgICAgICAgIHRoaXMucmVtYWluaW5nVGltZVNlY29uZHMgPSBlbmREYXRlLmRpZmYodGhpcy5zZXJ2ZXJEYXRlU2VydmljZS5ub3coKSwgJ3NlY29uZHMnKTtcbiAgICAgICAgICAgICAgICB0aGlzLnJlbWFpbmluZ1RpbWVUZXh0ID0gdGhpcy5yZWxhdGl2ZVRpbWVUZXh0KHRoaXMucmVtYWluaW5nVGltZVNlY29uZHMpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBxdWl6IGlzIG92ZXIgPT4gc2V0IHJlbWFpbmluZyBzZWNvbmRzIHRvIG5lZ2F0aXZlLCB0byBkZWFjdGl2YXRlICdTdWJtaXQnIGJ1dHRvblxuICAgICAgICAgICAgICAgIHRoaXMucmVtYWluaW5nVGltZVNlY29uZHMgPSAtMTtcbiAgICAgICAgICAgICAgICB0aGlzLnJlbWFpbmluZ1RpbWVUZXh0ID0gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQodHJhbnNsYXRpb25CYXNlUGF0aCArICdxdWl6SGFzRW5kZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIHJlbWFpbmluZyB0aW1lIGlzIHVua25vd24gPT4gU2V0IHJlbWFpbmluZyBzZWNvbmRzIHRvIDAsIHRvIGtlZXAgJ1N1Ym1pdCcgYnV0dG9uIGVuYWJsZWRcbiAgICAgICAgICAgIHRoaXMucmVtYWluaW5nVGltZVNlY29uZHMgPSAwO1xuICAgICAgICAgICAgdGhpcy5yZW1haW5pbmdUaW1lVGV4dCA9ICc/JztcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHVwZGF0ZSBzdWJtaXNzaW9uIHRpbWVcbiAgICAgICAgaWYgKHRoaXMuc3VibWlzc2lvbiAmJiB0aGlzLnN1Ym1pc3Npb24uc3VibWlzc2lvbkRhdGUpIHtcbiAgICAgICAgICAgIC8vIGV4YWN0IHZhbHVlIGlzIG5vdCBpbXBvcnRhbnQgPT4gdXNlIGRlZmF1bHQgcmVsYXRpdmUgdGltZSBmcm9tIGRheWpzIGZvciBiZXR0ZXIgcmVhZGFiaWxpdHkgYW5kIGxlc3MgZGlzdHJhY3Rpb25cbiAgICAgICAgICAgIHRoaXMubGFzdFNhdmVkVGltZVRleHQgPSBkYXlqcyh0aGlzLnN1Ym1pc3Npb24uc3VibWlzc2lvbkRhdGUpLmZyb21Ob3coKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHVwZGF0ZSB0aW1lIHVudGlsIHN0YXJ0XG4gICAgICAgIGlmICh0aGlzLnF1aXpCYXRjaCAmJiB0aGlzLnN0YXJ0RGF0ZSkge1xuICAgICAgICAgICAgaWYgKHRoaXMuc3RhcnREYXRlLmlzQWZ0ZXIodGhpcy5zZXJ2ZXJEYXRlU2VydmljZS5ub3coKSkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRpbWVVbnRpbFN0YXJ0ID0gdGhpcy5yZWxhdGl2ZVRpbWVUZXh0KHRoaXMuc3RhcnREYXRlLmRpZmYodGhpcy5zZXJ2ZXJEYXRlU2VydmljZS5ub3coKSwgJ3NlY29uZHMnKSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMudGltZVVudGlsU3RhcnQgPSB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCh0cmFuc2xhdGlvbkJhc2VQYXRoICsgJ25vdycpO1xuICAgICAgICAgICAgICAgIC8vIENoZWNrIGlmIHdlYnNvY2tldCBoYXMgdXBkYXRlZCB0aGUgcXVpeiBleGVyY2lzZSBhbmQgY2hlY2sgdGhhdCBmb2xsb3dpbmcgYmxvY2sgaXMgb25seSBleGVjdXRlZCBvbmNlXG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzLnF1aXpCYXRjaC5zdGFydGVkICYmICF0aGlzLnF1aXpTdGFydGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucXVpelN0YXJ0ZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5xdWl6RXhlcmNpc2UucXVpek1vZGUgPT09IFF1aXpNb2RlLklORElWSURVQUwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRoZXJlIGlzIG5vdCB3ZWJzb2NrZXQgbm90aWZpY2F0aW9uIGZvciBJTkRJVklEVUFMIG1vZGUgc28ganVzdCBsb2FkIHRoZSBxdWl6XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlZnJlc2hRdWl6KHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVmcmVzaCBxdWl6IGFmdGVyIDUgc2Vjb25kcyB3aGVuIGNsaWVudCBkaWQgbm90IHJlY2VpdmUgd2Vic29ja2V0IG1lc3NhZ2UgdG8gc3RhcnQgdGhlIHF1aXpcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIENoZWNrIGFnYWluIGlmIHdlYnNvY2tldCBoYXMgdXBkYXRlZCB0aGUgcXVpeiBleGVyY2lzZSB3aXRoaW4gdGhlIDUgc2Vjb25kc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5xdWl6QmF0Y2ggfHwgIXRoaXMucXVpekJhdGNoLnN0YXJ0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZWZyZXNoUXVpeih0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9LCA1MDAwKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMudGltZVVudGlsU3RhcnQgPSAnJztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEV4cHJlc3MgdGhlIGdpdmVuIHRpbWVzcGFuIGFzIGh1bWFuaXplZCB0ZXh0XG4gICAgICpcbiAgICAgKiBAcGFyYW0gcmVtYWluaW5nVGltZVNlY29uZHMge251bWJlcn0gdGhlIGFtb3VudCBvZiBzZWNvbmRzIHRvIGRpc3BsYXlcbiAgICAgKiBAcmV0dXJuIHtzdHJpbmd9IGh1bWFuaXplZCB0ZXh0IGZvciB0aGUgZ2l2ZW4gYW1vdW50IG9mIHNlY29uZHNcbiAgICAgKi9cbiAgICByZWxhdGl2ZVRpbWVUZXh0KHJlbWFpbmluZ1RpbWVTZWNvbmRzOiBudW1iZXIpIHtcbiAgICAgICAgaWYgKHJlbWFpbmluZ1RpbWVTZWNvbmRzID4gMjEwKSB7XG4gICAgICAgICAgICByZXR1cm4gTWF0aC5jZWlsKHJlbWFpbmluZ1RpbWVTZWNvbmRzIC8gNjApICsgJyBtaW4nO1xuICAgICAgICB9IGVsc2UgaWYgKHJlbWFpbmluZ1RpbWVTZWNvbmRzID4gNTkpIHtcbiAgICAgICAgICAgIHJldHVybiBNYXRoLmZsb29yKHJlbWFpbmluZ1RpbWVTZWNvbmRzIC8gNjApICsgJyBtaW4gJyArIChyZW1haW5pbmdUaW1lU2Vjb25kcyAlIDYwKSArICcgcyc7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gcmVtYWluaW5nVGltZVNlY29uZHMgKyAnIHMnO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgY2hlY2tGb3JRdWl6RW5kKCkge1xuICAgICAgICBjb25zdCBydW5uaW5nID0gdGhpcy5tb2RlID09PSAnbGl2ZScgJiYgISF0aGlzLnF1aXpCYXRjaCAmJiB0aGlzLnJlbWFpbmluZ1RpbWVTZWNvbmRzID49IDAgJiYgdGhpcy5xdWl6RXhlcmNpc2U/LnF1aXpNb2RlICE9PSBRdWl6TW9kZS5TWU5DSFJPTklaRUQ7XG4gICAgICAgIGlmICghcnVubmluZyAmJiB0aGlzLnByZXZpb3VzUnVubmluZykge1xuICAgICAgICAgICAgaWYgKCF0aGlzLnN1Ym1pc3Npb24uc3VibWl0dGVkICYmIHRoaXMuc3VibWlzc2lvbi5zdWJtaXNzaW9uRGF0ZSkge1xuICAgICAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLnN1Y2Nlc3MoJ2FydGVtaXNBcHAucXVpekV4ZXJjaXNlLnN1Ym1pdFN1Y2Nlc3MnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLnByZXZpb3VzUnVubmluZyA9IHJ1bm5pbmc7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSW5pdGlhbGl6ZSB0aGUgc2VsZWN0aW9ucyAvIG1hcHBpbmdzIGZvciBlYWNoIHF1ZXN0aW9uIHdpdGggYW4gZW1wdHkgYXJyYXlcbiAgICAgKi9cbiAgICBpbml0UXVpeigpIHtcbiAgICAgICAgLy8gY2FsY3VsYXRlIHNjb3JlXG4gICAgICAgIHRoaXMudG90YWxTY29yZSA9IHRoaXMucXVpekV4ZXJjaXNlLnF1aXpRdWVzdGlvbnNcbiAgICAgICAgICAgID8gdGhpcy5xdWl6RXhlcmNpc2UucXVpelF1ZXN0aW9ucy5yZWR1Y2UoKHNjb3JlLCBxdWVzdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHNjb3JlICsgcXVlc3Rpb24ucG9pbnRzITtcbiAgICAgICAgICAgICAgfSwgMClcbiAgICAgICAgICAgIDogMDtcblxuICAgICAgICAvLyBwcmVwYXJlIHNlbGVjdGlvbiBhcnJheXMgZm9yIGVhY2ggcXVlc3Rpb25cbiAgICAgICAgdGhpcy5zZWxlY3RlZEFuc3dlck9wdGlvbnMgPSBuZXcgTWFwPG51bWJlciwgQW5zd2VyT3B0aW9uW10+KCk7XG4gICAgICAgIHRoaXMuZHJhZ0FuZERyb3BNYXBwaW5ncyA9IG5ldyBNYXA8bnVtYmVyLCBEcmFnQW5kRHJvcE1hcHBpbmdbXT4oKTtcbiAgICAgICAgdGhpcy5zaG9ydEFuc3dlclN1Ym1pdHRlZFRleHRzID0gbmV3IE1hcDxudW1iZXIsIFNob3J0QW5zd2VyU3VibWl0dGVkVGV4dFtdPigpO1xuXG4gICAgICAgIGlmICh0aGlzLnF1aXpFeGVyY2lzZS5xdWl6UXVlc3Rpb25zKSB7XG4gICAgICAgICAgICB0aGlzLnF1aXpFeGVyY2lzZS5xdWl6UXVlc3Rpb25zLmZvckVhY2goKHF1ZXN0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHF1ZXN0aW9uLnR5cGUgPT09IFF1aXpRdWVzdGlvblR5cGUuTVVMVElQTEVfQ0hPSUNFKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGFkZCB0aGUgYXJyYXkgb2Ygc2VsZWN0ZWQgb3B0aW9ucyB0byB0aGUgZGljdGlvbmFyeSAoYWRkIGFuIGVtcHR5IGFycmF5LCBpZiB0aGVyZSBpcyBubyBzdWJtaXR0ZWRBbnN3ZXIgZm9yIHRoaXMgcXVlc3Rpb24pXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRBbnN3ZXJPcHRpb25zLnNldChxdWVzdGlvbi5pZCEsIFtdKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHF1ZXN0aW9uLnR5cGUgPT09IFF1aXpRdWVzdGlvblR5cGUuRFJBR19BTkRfRFJPUCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBhZGQgdGhlIGFycmF5IG9mIG1hcHBpbmdzIHRvIHRoZSBkaWN0aW9uYXJ5IChhZGQgYW4gZW1wdHkgYXJyYXksIGlmIHRoZXJlIGlzIG5vIHN1Ym1pdHRlZEFuc3dlciBmb3IgdGhpcyBxdWVzdGlvbilcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kcmFnQW5kRHJvcE1hcHBpbmdzLnNldChxdWVzdGlvbi5pZCEsIFtdKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHF1ZXN0aW9uLnR5cGUgPT09IFF1aXpRdWVzdGlvblR5cGUuU0hPUlRfQU5TV0VSKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGFkZCB0aGUgYXJyYXkgb2Ygc3VibWl0dGVkIHRleHRzIHRvIHRoZSBkaWN0aW9uYXJ5IChhZGQgYW4gZW1wdHkgYXJyYXksIGlmIHRoZXJlIGlzIG5vIHN1Ym1pdHRlZEFuc3dlciBmb3IgdGhpcyBxdWVzdGlvbilcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zaG9ydEFuc3dlclN1Ym1pdHRlZFRleHRzLnNldChxdWVzdGlvbi5pZCEsIFtdKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdVbmtub3duIHF1ZXN0aW9uIHR5cGU6ICcgKyBxdWVzdGlvbik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSwgdGhpcyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBhcHBsaWVzIHRoZSBkYXRhIGZyb20gdGhlIG1vZGVsIHRvIHRoZSBVSSAocmV2ZXJzZSBvZiBhcHBseVNlbGVjdGlvbik6XG4gICAgICpcbiAgICAgKiBTZXRzIHRoZSBjaGVja21hcmtzIChzZWxlY3RlZCBhbnN3ZXJzKSBmb3IgYWxsIHF1ZXN0aW9ucyBhY2NvcmRpbmcgdG8gdGhlIHN1Ym1pc3Npb24gZGF0YVxuICAgICAqIHRoaXMgbmVlZHMgdG8gYmUgZG9uZSB3aGVuIHdlIGdldCBuZXcgc3VibWlzc2lvbiBkYXRhLCBlLmcuIHRocm91Z2ggdGhlIHdlYnNvY2tldCBjb25uZWN0aW9uXG4gICAgICovXG4gICAgYXBwbHlTdWJtaXNzaW9uKCkge1xuICAgICAgICAvLyBjcmVhdGUgZGljdGlvbmFyaWVzIChrZXk6IHF1ZXN0aW9uSUQsIHZhbHVlOiBBcnJheSBvZiBzZWxlY3RlZCBhbnN3ZXJPcHRpb25zIC8gbWFwcGluZ3MpXG4gICAgICAgIC8vIGZvciB0aGUgc3VibWl0dGVkQW5zd2VycyB0byBoYW5kIHRoZSBzZWxlY3RlZCBvcHRpb25zIC8gbWFwcGluZ3MgaW4gaW5kaXZpZHVhbCBhcnJheXMgdG8gdGhlIHF1ZXN0aW9uIGNvbXBvbmVudHNcbiAgICAgICAgdGhpcy5zZWxlY3RlZEFuc3dlck9wdGlvbnMgPSBuZXcgTWFwPG51bWJlciwgQW5zd2VyT3B0aW9uW10+KCk7XG4gICAgICAgIHRoaXMuZHJhZ0FuZERyb3BNYXBwaW5ncyA9IG5ldyBNYXA8bnVtYmVyLCBEcmFnQW5kRHJvcE1hcHBpbmdbXT4oKTtcbiAgICAgICAgdGhpcy5zaG9ydEFuc3dlclN1Ym1pdHRlZFRleHRzID0gbmV3IE1hcDxudW1iZXIsIFNob3J0QW5zd2VyU3VibWl0dGVkVGV4dFtdPigpO1xuXG4gICAgICAgIGlmICh0aGlzLnF1aXpFeGVyY2lzZS5xdWl6UXVlc3Rpb25zKSB7XG4gICAgICAgICAgICAvLyBpdGVyYXRlIHRocm91Z2ggYWxsIHF1ZXN0aW9ucyBvZiB0aGlzIHF1aXpcbiAgICAgICAgICAgIHRoaXMucXVpekV4ZXJjaXNlLnF1aXpRdWVzdGlvbnMuZm9yRWFjaCgocXVlc3Rpb24pID0+IHtcbiAgICAgICAgICAgICAgICAvLyBmaW5kIHRoZSBzdWJtaXR0ZWQgYW5zd2VyIHRoYXQgYmVsb25ncyB0byB0aGlzIHF1ZXN0aW9uLCBvbmx5IHdoZW4gc3VibWl0dGVkIGFuc3dlcnMgYWxyZWFkeSBleGlzdFxuICAgICAgICAgICAgICAgIGNvbnN0IHN1Ym1pdHRlZEFuc3dlciA9IHRoaXMuc3VibWlzc2lvbi5zdWJtaXR0ZWRBbnN3ZXJzPy5maW5kKChhbnN3ZXIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFuc3dlci5xdWl6UXVlc3Rpb24hLmlkID09PSBxdWVzdGlvbi5pZDtcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIGlmIChxdWVzdGlvbi50eXBlID09PSBRdWl6UXVlc3Rpb25UeXBlLk1VTFRJUExFX0NIT0lDRSkge1xuICAgICAgICAgICAgICAgICAgICAvLyBhZGQgdGhlIGFycmF5IG9mIHNlbGVjdGVkIG9wdGlvbnMgdG8gdGhlIGRpY3Rpb25hcnkgKGFkZCBhbiBlbXB0eSBhcnJheSwgaWYgdGhlcmUgaXMgbm8gc3VibWl0dGVkQW5zd2VyIGZvciB0aGlzIHF1ZXN0aW9uKVxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdGVkQW5zd2VyT3B0aW9ucy5zZXQocXVlc3Rpb24uaWQhLCAoc3VibWl0dGVkQW5zd2VyIGFzIE11bHRpcGxlQ2hvaWNlU3VibWl0dGVkQW5zd2VyKT8uc2VsZWN0ZWRPcHRpb25zIHx8IFtdKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHF1ZXN0aW9uLnR5cGUgPT09IFF1aXpRdWVzdGlvblR5cGUuRFJBR19BTkRfRFJPUCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBhZGQgdGhlIGFycmF5IG9mIG1hcHBpbmdzIHRvIHRoZSBkaWN0aW9uYXJ5IChhZGQgYW4gZW1wdHkgYXJyYXksIGlmIHRoZXJlIGlzIG5vIHN1Ym1pdHRlZEFuc3dlciBmb3IgdGhpcyBxdWVzdGlvbilcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kcmFnQW5kRHJvcE1hcHBpbmdzLnNldChxdWVzdGlvbi5pZCEsIChzdWJtaXR0ZWRBbnN3ZXIgYXMgRHJhZ0FuZERyb3BTdWJtaXR0ZWRBbnN3ZXIpPy5tYXBwaW5ncyB8fCBbXSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChxdWVzdGlvbi50eXBlID09PSBRdWl6UXVlc3Rpb25UeXBlLlNIT1JUX0FOU1dFUikge1xuICAgICAgICAgICAgICAgICAgICAvLyBhZGQgdGhlIGFycmF5IG9mIHN1Ym1pdHRlZCB0ZXh0cyB0byB0aGUgZGljdGlvbmFyeSAoYWRkIGFuIGVtcHR5IGFycmF5LCBpZiB0aGVyZSBpcyBubyBzdWJtaXR0ZWRBbnN3ZXIgZm9yIHRoaXMgcXVlc3Rpb24pXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvcnRBbnN3ZXJTdWJtaXR0ZWRUZXh0cy5zZXQocXVlc3Rpb24uaWQhLCAoc3VibWl0dGVkQW5zd2VyIGFzIFNob3J0QW5zd2VyU3VibWl0dGVkQW5zd2VyKT8uc3VibWl0dGVkVGV4dHMgfHwgW10pO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1Vua25vd24gcXVlc3Rpb24gdHlwZTogJyArIHF1ZXN0aW9uKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCB0aGlzKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIHVwZGF0ZXMgdGhlIG1vZGVsIGFjY29yZGluZyB0byBVSSBzdGF0ZSAocmV2ZXJzZSBvZiBhcHBseVN1Ym1pc3Npb24pOlxuICAgICAqIENyZWF0ZXMgdGhlIHN1Ym1pc3Npb24gZnJvbSB0aGUgdXNlcidzIHNlbGVjdGlvblxuICAgICAqIHRoaXMgbmVlZHMgdG8gYmUgZG9uZSB3aGVuIHdlIHdhbnQgdG8gc2VuZCB0aGUgc3VibWlzc2lvbiBlaXRoZXIgZm9yIHNhdmluZyAodGhyb3VnaCB3ZWJzb2NrZXQpIG9yIGZvciBzdWJtaXR0aW5nICh0aHJvdWdoIFJFU1QgY2FsbClcbiAgICAgKi9cbiAgICBhcHBseVNlbGVjdGlvbigpIHtcbiAgICAgICAgLy8gY29udmVydCB0aGUgc2VsZWN0aW9uIGRpY3Rpb25hcnkgKGtleTogcXVlc3Rpb25JRCwgdmFsdWU6IEFycmF5IG9mIHNlbGVjdGVkIGFuc3dlck9wdGlvbnMgLyBtYXBwaW5ncylcbiAgICAgICAgLy8gaW50byBhbiBhcnJheSBvZiBzdWJtaXR0ZWRBbnN3ZXIgb2JqZWN0cyBhbmQgc2F2ZSBpdCBhcyB0aGUgc3VibWl0dGVkQW5zd2VycyBvZiB0aGUgc3VibWlzc2lvblxuICAgICAgICB0aGlzLnN1Ym1pc3Npb24uc3VibWl0dGVkQW5zd2VycyA9IFtdO1xuXG4gICAgICAgIC8vIGZvciBtdWx0aXBsZS1jaG9pY2UgcXVlc3Rpb25zXG4gICAgICAgIHRoaXMuc2VsZWN0ZWRBbnN3ZXJPcHRpb25zLmZvckVhY2goKGFuc3dlck9wdGlvbnMsIHF1ZXN0aW9uSWQpID0+IHtcbiAgICAgICAgICAgIC8vIGZpbmQgdGhlIHF1ZXN0aW9uIG9iamVjdCBmb3IgdGhlIGdpdmVuIHF1ZXN0aW9uIGlkXG4gICAgICAgICAgICBjb25zdCBxdWVzdGlvbiA9IHRoaXMucXVpekV4ZXJjaXNlLnF1aXpRdWVzdGlvbnM/LmZpbmQoKHNlbGVjdGVkUXVlc3Rpb24pID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gc2VsZWN0ZWRRdWVzdGlvbi5pZCA9PT0gcXVlc3Rpb25JZDtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKCFxdWVzdGlvbikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ3F1ZXN0aW9uIG5vdCBmb3VuZCBmb3IgSUQ6ICcgKyBxdWVzdGlvbklkKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBnZW5lcmF0ZSB0aGUgc3VibWl0dGVkQW5zd2VyIG9iamVjdFxuICAgICAgICAgICAgY29uc3QgbWNTdWJtaXR0ZWRBbnN3ZXIgPSBuZXcgTXVsdGlwbGVDaG9pY2VTdWJtaXR0ZWRBbnN3ZXIoKTtcbiAgICAgICAgICAgIG1jU3VibWl0dGVkQW5zd2VyLnF1aXpRdWVzdGlvbiA9IHF1ZXN0aW9uO1xuICAgICAgICAgICAgbWNTdWJtaXR0ZWRBbnN3ZXIuc2VsZWN0ZWRPcHRpb25zID0gYW5zd2VyT3B0aW9ucztcbiAgICAgICAgICAgIHRoaXMuc3VibWlzc2lvbi5zdWJtaXR0ZWRBbnN3ZXJzIS5wdXNoKG1jU3VibWl0dGVkQW5zd2VyKTtcbiAgICAgICAgfSwgdGhpcyk7XG5cbiAgICAgICAgLy8gZm9yIGRyYWctYW5kLWRyb3AgcXVlc3Rpb25zXG4gICAgICAgIHRoaXMuZHJhZ0FuZERyb3BNYXBwaW5ncy5mb3JFYWNoKChtYXBwaW5ncywgcXVlc3Rpb25JZCkgPT4ge1xuICAgICAgICAgICAgLy8gZmluZCB0aGUgcXVlc3Rpb24gb2JqZWN0IGZvciB0aGUgZ2l2ZW4gcXVlc3Rpb24gaWRcbiAgICAgICAgICAgIGNvbnN0IHF1ZXN0aW9uID0gdGhpcy5xdWl6RXhlcmNpc2UucXVpelF1ZXN0aW9ucz8uZmluZCgobG9jYWxRdWVzdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiBsb2NhbFF1ZXN0aW9uLmlkID09PSBxdWVzdGlvbklkO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoIXF1ZXN0aW9uKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcigncXVlc3Rpb24gbm90IGZvdW5kIGZvciBJRDogJyArIHF1ZXN0aW9uSWQpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIGdlbmVyYXRlIHRoZSBzdWJtaXR0ZWRBbnN3ZXIgb2JqZWN0XG4gICAgICAgICAgICBjb25zdCBkbmRTdWJtaXR0ZWRBbnN3ZXIgPSBuZXcgRHJhZ0FuZERyb3BTdWJtaXR0ZWRBbnN3ZXIoKTtcbiAgICAgICAgICAgIGRuZFN1Ym1pdHRlZEFuc3dlci5xdWl6UXVlc3Rpb24gPSBxdWVzdGlvbjtcbiAgICAgICAgICAgIGRuZFN1Ym1pdHRlZEFuc3dlci5tYXBwaW5ncyA9IG1hcHBpbmdzO1xuICAgICAgICAgICAgdGhpcy5zdWJtaXNzaW9uLnN1Ym1pdHRlZEFuc3dlcnMhLnB1c2goZG5kU3VibWl0dGVkQW5zd2VyKTtcbiAgICAgICAgfSwgdGhpcyk7XG4gICAgICAgIC8vIGZvciBzaG9ydC1hbnN3ZXIgcXVlc3Rpb25zXG4gICAgICAgIHRoaXMuc2hvcnRBbnN3ZXJTdWJtaXR0ZWRUZXh0cy5mb3JFYWNoKChzdWJtaXR0ZWRUZXh0cywgcXVlc3Rpb25JZCkgPT4ge1xuICAgICAgICAgICAgLy8gZmluZCB0aGUgcXVlc3Rpb24gb2JqZWN0IGZvciB0aGUgZ2l2ZW4gcXVlc3Rpb24gaWRcbiAgICAgICAgICAgIGNvbnN0IHF1ZXN0aW9uID0gdGhpcy5xdWl6RXhlcmNpc2UucXVpelF1ZXN0aW9ucz8uZmluZCgobG9jYWxRdWVzdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiBsb2NhbFF1ZXN0aW9uLmlkID09PSBxdWVzdGlvbklkO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoIXF1ZXN0aW9uKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcigncXVlc3Rpb24gbm90IGZvdW5kIGZvciBJRDogJyArIHF1ZXN0aW9uSWQpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIGdlbmVyYXRlIHRoZSBzdWJtaXR0ZWRBbnN3ZXIgb2JqZWN0XG4gICAgICAgICAgICBjb25zdCBzaG9ydEFuc3dlclN1Ym1pdHRlZEFuc3dlciA9IG5ldyBTaG9ydEFuc3dlclN1Ym1pdHRlZEFuc3dlcigpO1xuICAgICAgICAgICAgc2hvcnRBbnN3ZXJTdWJtaXR0ZWRBbnN3ZXIucXVpelF1ZXN0aW9uID0gcXVlc3Rpb247XG4gICAgICAgICAgICBzaG9ydEFuc3dlclN1Ym1pdHRlZEFuc3dlci5zdWJtaXR0ZWRUZXh0cyA9IHN1Ym1pdHRlZFRleHRzO1xuICAgICAgICAgICAgdGhpcy5zdWJtaXNzaW9uLnN1Ym1pdHRlZEFuc3dlcnMhLnB1c2goc2hvcnRBbnN3ZXJTdWJtaXR0ZWRBbnN3ZXIpO1xuICAgICAgICB9LCB0aGlzKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBBcHBseSB0aGUgZGF0YSBvZiB0aGUgcGFydGljaXBhdGlvbiwgcmVwbGFjaW5nIGFsbCBvbGQgZGF0YVxuICAgICAqL1xuICAgIHVwZGF0ZVBhcnRpY2lwYXRpb25Gcm9tU2VydmVyKHBhcnRpY2lwYXRpb246IFN0dWRlbnRQYXJ0aWNpcGF0aW9uKSB7XG4gICAgICAgIGlmIChwYXJ0aWNpcGF0aW9uKSB7XG4gICAgICAgICAgICB0aGlzLmFwcGx5UXVpekZ1bGwocGFydGljaXBhdGlvbi5leGVyY2lzZSBhcyBRdWl6RXhlcmNpc2UpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gYXBwbHkgc3VibWlzc2lvbiBpZiBpdCBleGlzdHNcbiAgICAgICAgaWYgKHBhcnRpY2lwYXRpb24/LnJlc3VsdHM/Lmxlbmd0aCkge1xuICAgICAgICAgICAgdGhpcy5zdWJtaXNzaW9uID0gcGFydGljaXBhdGlvbi5yZXN1bHRzWzBdLnN1Ym1pc3Npb24gYXMgUXVpelN1Ym1pc3Npb247XG5cbiAgICAgICAgICAgIC8vIHVwZGF0ZSBzdWJtaXNzaW9uIHRpbWVcbiAgICAgICAgICAgIHRoaXMudXBkYXRlU3VibWlzc2lvblRpbWUoKTtcblxuICAgICAgICAgICAgLy8gc2hvdyBzdWJtaXNzaW9uIGFuc3dlcnMgaW4gVUlcbiAgICAgICAgICAgIHRoaXMuYXBwbHlTdWJtaXNzaW9uKCk7XG5cbiAgICAgICAgICAgIGlmIChwYXJ0aWNpcGF0aW9uLnJlc3VsdHNbMF0uc2NvcmUgIT09IHVuZGVmaW5lZCAmJiB0aGlzLnF1aXpFeGVyY2lzZS5xdWl6RW5kZWQpIHtcbiAgICAgICAgICAgICAgICAvLyBxdWl6IGhhcyBlbmRlZCBhbmQgcmVzdWx0cyBhcmUgYXZhaWxhYmxlXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93UmVzdWx0KHBhcnRpY2lwYXRpb24ucmVzdWx0c1swXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnN1Ym1pc3Npb24gPSBuZXcgUXVpelN1Ym1pc3Npb24oKTtcbiAgICAgICAgICAgIHRoaXMuaW5pdFF1aXooKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGFwcGx5IHRoZSBkYXRhIG9mIHRoZSBxdWl6LCByZXBsYWNpbmcgYWxsIG9sZCBkYXRhIGFuZCBlbmFibGluZyByZWNvbm5lY3QgaWYgbmVjZXNzYXJ5XG4gICAgICogQHBhcmFtIHF1aXpFeGVyY2lzZVxuICAgICAqL1xuICAgIGFwcGx5UXVpekZ1bGwocXVpekV4ZXJjaXNlOiBRdWl6RXhlcmNpc2UpIHtcbiAgICAgICAgdGhpcy5xdWl6RXhlcmNpc2UgPSBxdWl6RXhlcmNpc2U7XG4gICAgICAgIHRoaXMuaW5pdFF1aXooKTtcblxuICAgICAgICB0aGlzLnF1aXpCYXRjaCA9IHRoaXMucXVpekV4ZXJjaXNlLnF1aXpCYXRjaGVzPy5bMF07XG4gICAgICAgIGlmICh0aGlzLnF1aXpFeGVyY2lzZS5xdWl6RW5kZWQpIHtcbiAgICAgICAgICAgIC8vIHF1aXogaXMgZG9uZVxuICAgICAgICAgICAgdGhpcy53YWl0aW5nRm9yUXVpelN0YXJ0ID0gZmFsc2U7XG4gICAgICAgIH0gZWxzZSBpZiAoIXRoaXMucXVpekJhdGNoIHx8ICF0aGlzLnF1aXpCYXRjaC5zdGFydGVkKSB7XG4gICAgICAgICAgICAvLyBxdWl6IGhhc24ndCBzdGFydGVkIHlldFxuICAgICAgICAgICAgdGhpcy53YWl0aW5nRm9yUXVpelN0YXJ0ID0gdHJ1ZTtcblxuICAgICAgICAgICAgLy8gZW5hYmxlIGF1dG9tYXRpYyB3ZWJzb2NrZXQgcmVjb25uZWN0XG4gICAgICAgICAgICB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2UuZW5hYmxlUmVjb25uZWN0KCk7XG5cbiAgICAgICAgICAgIGlmICh0aGlzLnF1aXpCYXRjaCAmJiB0aGlzLnF1aXpCYXRjaC5zdGFydFRpbWUpIHtcbiAgICAgICAgICAgICAgICAvLyBzeW5jaHJvbml6ZSB0aW1lIHdpdGggc2VydmVyXG4gICAgICAgICAgICAgICAgdGhpcy5zdGFydERhdGUgPSBkYXlqcyh0aGlzLnF1aXpCYXRjaC5zdGFydFRpbWUgPz8gdGhpcy5zZXJ2ZXJEYXRlU2VydmljZS5ub3coKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBxdWl6IGhhcyBzdGFydGVkXG4gICAgICAgICAgICB0aGlzLndhaXRpbmdGb3JRdWl6U3RhcnQgPSBmYWxzZTtcblxuICAgICAgICAgICAgLy8gdXBkYXRlIHRpbWVEaWZmZXJlbmNlXG4gICAgICAgICAgICB0aGlzLnN0YXJ0RGF0ZSA9IGRheWpzKHRoaXMucXVpekJhdGNoLnN0YXJ0VGltZSA/PyB0aGlzLnNlcnZlckRhdGVTZXJ2aWNlLm5vdygpKTtcbiAgICAgICAgICAgIHRoaXMuZW5kRGF0ZSA9IHRoaXMuc3RhcnREYXRlLmFkZCh0aGlzLnF1aXpFeGVyY2lzZS5kdXJhdGlvbiEsICdzZWNvbmRzJyk7XG5cbiAgICAgICAgICAgIC8vIGNoZWNrIGlmIHF1aXogaGFzbid0IGVuZGVkXG4gICAgICAgICAgICBpZiAoIXRoaXMucXVpekJhdGNoLmVuZGVkKSB7XG4gICAgICAgICAgICAgICAgLy8gZW5hYmxlIGF1dG9tYXRpYyB3ZWJzb2NrZXQgcmVjb25uZWN0XG4gICAgICAgICAgICAgICAgdGhpcy5qaGlXZWJzb2NrZXRTZXJ2aWNlLmVuYWJsZVJlY29ubmVjdCgpO1xuXG4gICAgICAgICAgICAgICAgLy8gYXBwbHkgcmFuZG9taXplZCBvcmRlciB3aGVyZSBuZWNlc3NhcnlcbiAgICAgICAgICAgICAgICB0aGlzLnF1aXpTZXJ2aWNlLnJhbmRvbWl6ZU9yZGVyKHRoaXMucXVpekV4ZXJjaXNlLnF1aXpRdWVzdGlvbnMsIHRoaXMucXVpekV4ZXJjaXNlLnJhbmRvbWl6ZVF1ZXN0aW9uT3JkZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgKiBUaGlzIG1ldGhvZCBvbmx5IGhhbmRsZXMgdGhlIHVwZGF0ZSBvZiB0aGUgcXVpeiBhZnRlciB0aGUgcXVpeiBoYXMgZW5kZWRcbiAgICAgKi9cbiAgICBzaG93UXVpelJlc3VsdEFmdGVyUXVpekVuZChwYXJ0aWNpcGF0aW9uOiBTdHVkZW50UGFydGljaXBhdGlvbikge1xuICAgICAgICBjb25zdCBxdWl6RXhlcmNpc2UgPSBwYXJ0aWNpcGF0aW9uLmV4ZXJjaXNlIGFzIFF1aXpFeGVyY2lzZTtcbiAgICAgICAgaWYgKHBhcnRpY2lwYXRpb24ucmVzdWx0cz8uZmlyc3QoKT8uc3VibWlzc2lvbiAhPT0gdW5kZWZpbmVkICYmIHF1aXpFeGVyY2lzZS5xdWl6RW5kZWQpIHtcbiAgICAgICAgICAgIC8vIHF1aXogaGFzIGVuZGVkIGFuZCByZXN1bHRzIGFyZSBhdmFpbGFibGVcbiAgICAgICAgICAgIHRoaXMuc3VibWlzc2lvbiA9IHBhcnRpY2lwYXRpb24ucmVzdWx0c1swXS5zdWJtaXNzaW9uIGFzIFF1aXpTdWJtaXNzaW9uO1xuXG4gICAgICAgICAgICAvLyB1cGRhdGUgc3VibWlzc2lvbiB0aW1lXG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVN1Ym1pc3Npb25UaW1lKCk7XG4gICAgICAgICAgICB0aGlzLnRyYW5zZmVySW5mb3JtYXRpb25Ub1F1aXpFeGVyY2lzZShxdWl6RXhlcmNpc2UpO1xuICAgICAgICAgICAgdGhpcy5hcHBseVN1Ym1pc3Npb24oKTtcbiAgICAgICAgICAgIHRoaXMuc2hvd1Jlc3VsdChwYXJ0aWNpcGF0aW9uLnJlc3VsdHNbMF0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVHJhbnNmZXIgYWRkaXRpb25hbCBpbmZvcm1hdGlvbiAoZXhwbGFuYXRpb25zLCBjb3JyZWN0IGFuc3dlcnMpIGZyb20gdGhlIGdpdmVuIGZ1bGwgcXVpeiBleGVyY2lzZSB0byBxdWl6RXhlcmNpc2UuXG4gICAgICogVGhpcyBtZXRob2QgaXMgdHlwaWNhbGx5IGludm9rZWQgYWZ0ZXIgdGhlIHF1aXogaGFzIGVuZGVkIGFuZCBtYWtlcyBzdXJlIHRoYXQgdGhlIChyYW5kb20pIG9yZGVyIG9mIHRoZSBxdWl6XG4gICAgICogcXVlc3Rpb25zIGFuZCBhbnN3ZXIgb3B0aW9ucyBmb3IgdGhlIHBhcnRpY3VsYXIgdXNlciBpcyByZXNwZWN0ZWRcbiAgICAgKlxuICAgICAqIEBwYXJhbSBmdWxsUXVpekV4ZXJjaXNlRnJvbVNlcnZlciB7b2JqZWN0fSB0aGUgcXVpekV4ZXJjaXNlIGNvbnRhaW5pbmcgYWRkaXRpb25hbCBpbmZvcm1hdGlvblxuICAgICAqL1xuICAgIHRyYW5zZmVySW5mb3JtYXRpb25Ub1F1aXpFeGVyY2lzZShmdWxsUXVpekV4ZXJjaXNlRnJvbVNlcnZlcjogUXVpekV4ZXJjaXNlKSB7XG4gICAgICAgIHRoaXMucXVpekV4ZXJjaXNlLnF1aXpRdWVzdGlvbnMhLmZvckVhY2goKGNsaWVudFF1ZXN0aW9uKSA9PiB7XG4gICAgICAgICAgICAvLyBmaW5kIHVwZGF0ZWQgcXVlc3Rpb25cbiAgICAgICAgICAgIGNvbnN0IGZ1bGxRdWVzdGlvbkZyb21TZXJ2ZXIgPSBmdWxsUXVpekV4ZXJjaXNlRnJvbVNlcnZlci5xdWl6UXVlc3Rpb25zPy5maW5kKChmdWxsUXVlc3Rpb24pID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gY2xpZW50UXVlc3Rpb24uaWQgPT09IGZ1bGxRdWVzdGlvbi5pZDtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKGZ1bGxRdWVzdGlvbkZyb21TZXJ2ZXIpIHtcbiAgICAgICAgICAgICAgICBjbGllbnRRdWVzdGlvbi5leHBsYW5hdGlvbiA9IGZ1bGxRdWVzdGlvbkZyb21TZXJ2ZXIuZXhwbGFuYXRpb247XG5cbiAgICAgICAgICAgICAgICBpZiAoY2xpZW50UXVlc3Rpb24udHlwZSA9PT0gUXVpelF1ZXN0aW9uVHlwZS5NVUxUSVBMRV9DSE9JQ0UpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbWNDbGllbnRRdWVzdGlvbiA9IGNsaWVudFF1ZXN0aW9uIGFzIE11bHRpcGxlQ2hvaWNlUXVlc3Rpb247XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG1jRnVsbFF1ZXN0aW9uRnJvbVNlcnZlciA9IGZ1bGxRdWVzdGlvbkZyb21TZXJ2ZXIgYXMgTXVsdGlwbGVDaG9pY2VRdWVzdGlvbjtcblxuICAgICAgICAgICAgICAgICAgICBjb25zdCBhbnN3ZXJPcHRpb25zID0gbWNDbGllbnRRdWVzdGlvbi5hbnN3ZXJPcHRpb25zITtcbiAgICAgICAgICAgICAgICAgICAgYW5zd2VyT3B0aW9ucy5mb3JFYWNoKChjbGllbnRBbnN3ZXJPcHRpb24pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGZpbmQgdXBkYXRlZCBhbnN3ZXJPcHRpb25cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZ1bGxBbnN3ZXJPcHRpb25Gcm9tU2VydmVyID0gbWNGdWxsUXVlc3Rpb25Gcm9tU2VydmVyLmFuc3dlck9wdGlvbnMhLmZpbmQoKG9wdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjbGllbnRBbnN3ZXJPcHRpb24uaWQgPT09IG9wdGlvbi5pZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZ1bGxBbnN3ZXJPcHRpb25Gcm9tU2VydmVyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xpZW50QW5zd2VyT3B0aW9uLmV4cGxhbmF0aW9uID0gZnVsbEFuc3dlck9wdGlvbkZyb21TZXJ2ZXIuZXhwbGFuYXRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xpZW50QW5zd2VyT3B0aW9uLmlzQ29ycmVjdCA9IGZ1bGxBbnN3ZXJPcHRpb25Gcm9tU2VydmVyLmlzQ29ycmVjdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChjbGllbnRRdWVzdGlvbi50eXBlID09PSBRdWl6UXVlc3Rpb25UeXBlLkRSQUdfQU5EX0RST1ApIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZG5kQ2xpZW50UXVlc3Rpb24gPSBjbGllbnRRdWVzdGlvbiBhcyBEcmFnQW5kRHJvcFF1ZXN0aW9uO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBkbmRGdWxsUXVlc3Rpb25Gcm9tU2VydmVyID0gZnVsbFF1ZXN0aW9uRnJvbVNlcnZlciBhcyBEcmFnQW5kRHJvcFF1ZXN0aW9uO1xuXG4gICAgICAgICAgICAgICAgICAgIGRuZENsaWVudFF1ZXN0aW9uLmNvcnJlY3RNYXBwaW5ncyA9IGRuZEZ1bGxRdWVzdGlvbkZyb21TZXJ2ZXIuY29ycmVjdE1hcHBpbmdzO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoY2xpZW50UXVlc3Rpb24udHlwZSA9PT0gUXVpelF1ZXN0aW9uVHlwZS5TSE9SVF9BTlNXRVIpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2hvcnRBbnN3ZXJDbGllbnRRdWVzdGlvbiA9IGNsaWVudFF1ZXN0aW9uIGFzIFNob3J0QW5zd2VyUXVlc3Rpb247XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNob3J0QW5zd2VyRnVsbFF1ZXN0aW9uRnJvbVNlcnZlciA9IGZ1bGxRdWVzdGlvbkZyb21TZXJ2ZXIgYXMgU2hvcnRBbnN3ZXJRdWVzdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgc2hvcnRBbnN3ZXJDbGllbnRRdWVzdGlvbi5jb3JyZWN0TWFwcGluZ3MgPSBzaG9ydEFuc3dlckZ1bGxRdWVzdGlvbkZyb21TZXJ2ZXIuY29ycmVjdE1hcHBpbmdzO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGNhcHR1cmVFeGNlcHRpb24obmV3IEVycm9yKCdVbmtub3duIHF1ZXN0aW9uIHR5cGU6ICcgKyBjbGllbnRRdWVzdGlvbikpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgdGhpcyk7XG5cbiAgICAgICAgLy8gbWFrZSBzdXJlIHRoYXQgYSBwb3NzaWJsZSBleHBsYW5hdGlvbiBpcyB1cGRhdGVkIGNvcnJlY3RseSBpbiBhbGwgc3ViIGNvbXBvbmVudHNcbiAgICAgICAgdGhpcy5tY1F1ZXN0aW9uQ29tcG9uZW50cy5mb3JFYWNoKChtY1F1ZXN0aW9uQ29tcG9uZW50KSA9PiB7XG4gICAgICAgICAgICBtY1F1ZXN0aW9uQ29tcG9uZW50LndhdGNoQ29sbGVjdGlvbigpO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5kbmRRdWVzdGlvbkNvbXBvbmVudHMuZm9yRWFjaCgoZG5kUXVlc3Rpb25Db21wb25lbnQpID0+IHtcbiAgICAgICAgICAgIGRuZFF1ZXN0aW9uQ29tcG9uZW50LndhdGNoQ29sbGVjdGlvbigpO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5zaG9ydEFuc3dlclF1ZXN0aW9uQ29tcG9uZW50cy5mb3JFYWNoKChzaG9ydEFuc3dlclF1ZXN0aW9uQ29tcG9uZW50KSA9PiB7XG4gICAgICAgICAgICBzaG9ydEFuc3dlclF1ZXN0aW9uQ29tcG9uZW50LndhdGNoQ29sbGVjdGlvbigpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEaXNwbGF5IHJlc3VsdHMgb2YgdGhlIHF1aXogZm9yIHRoZSB1c2VyXG4gICAgICogQHBhcmFtIHJlc3VsdFxuICAgICAqL1xuICAgIHNob3dSZXN1bHQocmVzdWx0OiBSZXN1bHQpIHtcbiAgICAgICAgdGhpcy5yZXN1bHQgPSByZXN1bHQ7XG4gICAgICAgIGlmICh0aGlzLnJlc3VsdCkge1xuICAgICAgICAgICAgdGhpcy5zaG93aW5nUmVzdWx0ID0gdHJ1ZTtcblxuICAgICAgICAgICAgLy8gYXQgdGhlIG1vbWVudCwgdGhpcyBpcyBhbHdheXMgZW5hYmxlZFxuICAgICAgICAgICAgLy8gZGlzYWJsZSBhdXRvbWF0aWMgd2Vic29ja2V0IHJlY29ubmVjdFxuICAgICAgICAgICAgLy8gdGhpcy5qaGlXZWJzb2NrZXRTZXJ2aWNlLmRpc2FibGVSZWNvbm5lY3QoKTtcblxuICAgICAgICAgICAgY29uc3QgY291cnNlID0gdGhpcy5xdWl6RXhlcmNpc2UuY291cnNlIHx8IHRoaXMucXVpekV4ZXJjaXNlPy5leGVyY2lzZUdyb3VwPy5leGFtPy5jb3Vyc2U7XG5cbiAgICAgICAgICAgIC8vIGFzc2lnbiB1c2VyIHNjb3JlIChsaW1pdCBkZWNpbWFsIHBsYWNlcyB0byAyKVxuICAgICAgICAgICAgdGhpcy51c2VyU2NvcmUgPSB0aGlzLnN1Ym1pc3Npb24uc2NvcmVJblBvaW50cyA/IHJvdW5kVmFsdWVTcGVjaWZpZWRCeUNvdXJzZVNldHRpbmdzKHRoaXMuc3VibWlzc2lvbi5zY29yZUluUG9pbnRzLCBjb3Vyc2UpIDogMDtcblxuICAgICAgICAgICAgLy8gY3JlYXRlIGRpY3Rpb25hcnkgd2l0aCBzY29yZXMgZm9yIGVhY2ggcXVlc3Rpb25cbiAgICAgICAgICAgIHRoaXMucXVlc3Rpb25TY29yZXMgPSB7fTtcbiAgICAgICAgICAgIHRoaXMuc3VibWlzc2lvbi5zdWJtaXR0ZWRBbnN3ZXJzPy5mb3JFYWNoKChzdWJtaXR0ZWRBbnN3ZXIpID0+IHtcbiAgICAgICAgICAgICAgICAvLyBsaW1pdCBkZWNpbWFsIHBsYWNlc1xuICAgICAgICAgICAgICAgIHRoaXMucXVlc3Rpb25TY29yZXNbc3VibWl0dGVkQW5zd2VyLnF1aXpRdWVzdGlvbiEuaWQhXSA9IHJvdW5kVmFsdWVTcGVjaWZpZWRCeUNvdXJzZVNldHRpbmdzKHN1Ym1pdHRlZEFuc3dlci5zY29yZUluUG9pbnRzISwgY291cnNlKTtcbiAgICAgICAgICAgIH0sIHRoaXMpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2FsbGJhY2sgbWV0aG9kIHRvIGJlIHRyaWdnZXJlZCB3aGVuIHRoZSB1c2VyIGNoYW5nZXMgYW55IG9mIHRoZSBhbnN3ZXJzIGluIHRoZSBxdWl6IChpbiBzdWIgY29tcG9uZW50cyBiYXNlZCBvbiB0aGUgcXVlc3Rpb24gdHlwZSlcbiAgICAgKi9cbiAgICBvblNlbGVjdGlvbkNoYW5nZWQoKSB7XG4gICAgICAgIHRoaXMuYXBwbHlTZWxlY3Rpb24oKTtcbiAgICAgICAgaWYgKHRoaXMuc2VuZFdlYnNvY2tldCkge1xuICAgICAgICAgICAgaWYgKCF0aGlzLmRpc2Nvbm5lY3RlZCkge1xuICAgICAgICAgICAgICAgIC8vIHRoaXMuaXNTYXZpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHRoaXMuc3VibWlzc2lvbi5zdWJtaXNzaW9uRGF0ZSA9IHRoaXMuc2VydmVyRGF0ZVNlcnZpY2Uubm93KCk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZW5kV2Vic29ja2V0KHRoaXMuc3VibWlzc2lvbik7XG4gICAgICAgICAgICAgICAgdGhpcy51bnNhdmVkQ2hhbmdlcyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlU3VibWlzc2lvblRpbWUoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy51bnNhdmVkQ2hhbmdlcyA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiB1cGRhdGUgdGhlIHZhbHVlIGZvciBhZGp1c3RlZFN1Ym1pc3Npb25EYXRlIGluIHN1Ym1pc3Npb25cbiAgICAgKi9cbiAgICB1cGRhdGVTdWJtaXNzaW9uVGltZSgpIHtcbiAgICAgICAgaWYgKHRoaXMuc3VibWlzc2lvbi5zdWJtaXNzaW9uRGF0ZSkge1xuICAgICAgICAgICAgaWYgKE1hdGguYWJzKGRheWpzKHRoaXMuc3VibWlzc2lvbi5zdWJtaXNzaW9uRGF0ZSkuZGlmZih0aGlzLnNlcnZlckRhdGVTZXJ2aWNlLm5vdygpLCAnc2Vjb25kcycpKSA8IDIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmp1c3RTYXZlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGhpcy50aW1lb3V0SnVzdFNhdmVkKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDYWxsYmFjayBmdW5jdGlvbiBmb3IgaGFuZGxpbmcgcXVpeiBzdWJtaXNzaW9uIGFmdGVyIHNhdmluZyBzdWJtaXNzaW9uIHRvIHNlcnZlclxuICAgICAqIEBwYXJhbSBlcnJvciBhIHBvdGVudGlhbCBlcnJvciBkdXJpbmcgc2F2ZVxuICAgICAqL1xuICAgIG9uU2F2ZUVycm9yKGVycm9yOiBzdHJpbmcpIHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSAnU2F2aW5nIGFuc3dlcnMgZmFpbGVkOiAnICsgZXJyb3I7XG4gICAgICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5hZGRBbGVydCh7XG4gICAgICAgICAgICAgICAgdHlwZTogQWxlcnRUeXBlLkRBTkdFUixcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBlcnJvck1lc3NhZ2UsXG4gICAgICAgICAgICAgICAgZGlzYWJsZVRyYW5zbGF0aW9uOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLnVuc2F2ZWRDaGFuZ2VzID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMuaXNTdWJtaXR0aW5nID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVja3MgaWYgdGhlIHN0dWRlbnQgaGFzIGludGVyYWN0ZWQgd2l0aCBlYWNoIHF1ZXN0aW9uIG9mIHRoZSBxdWl6OlxuICAgICAqIC0gZm9yIGEgTXVsdGlwbGUgQ2hvaWNlIFF1ZXN0aW9ucyBpdCBjaGVja3MgaWYgYW4gYW5zd2VyIG9wdGlvbiB3YXMgc2VsZWN0ZWRcbiAgICAgKiAtIGZvciBhIERyYWcgYW5kIERyb3AgUXVlc3Rpb25zIGl0IGNoZWNrcyBpZiBhdCBsZWFzdCBvbmUgbWFwcGluZyBoYXMgYmVlbiBtYWRlXG4gICAgICogLSBmb3IgYSBTaG9ydCBBbnN3ZXIgUXVlc3Rpb25zIGl0IGNoZWNrcyBpZiBhdCBsZWFzdCBvbmUgZmllbGQgaGFzIGJlZW4gY2xpY2tlZCBpblxuICAgICAqIEByZXR1cm4ge2Jvb2xlYW59IHRydWUgd2hlbiBzdHVkZW50IGludGVyYWN0ZWQgd2l0aCBldmVyeSBxdWVzdGlvbiwgZmFsc2Ugd2hlbiBub3Qgd2l0aCBldmVyeSBxdWVzdGlvbnMgaGFzIGFuIGludGVyYWN0aW9uXG4gICAgICovXG4gICAgYXJlQWxsUXVlc3Rpb25zQW5zd2VyZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIGlmICghdGhpcy5xdWl6RXhlcmNpc2UucXVpelF1ZXN0aW9ucykge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cblxuICAgICAgICBmb3IgKGNvbnN0IHF1ZXN0aW9uIG9mIHRoaXMucXVpekV4ZXJjaXNlLnF1aXpRdWVzdGlvbnMpIHtcbiAgICAgICAgICAgIGlmIChxdWVzdGlvbi50eXBlID09PSBRdWl6UXVlc3Rpb25UeXBlLk1VTFRJUExFX0NIT0lDRSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IG9wdGlvbnMgPSB0aGlzLnNlbGVjdGVkQW5zd2VyT3B0aW9ucy5nZXQocXVlc3Rpb24uaWQhKTtcbiAgICAgICAgICAgICAgICBpZiAob3B0aW9ucyAmJiBvcHRpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmIChxdWVzdGlvbi50eXBlID09PSBRdWl6UXVlc3Rpb25UeXBlLkRSQUdfQU5EX0RST1ApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBtYXBwaW5ncyA9IHRoaXMuZHJhZ0FuZERyb3BNYXBwaW5ncy5nZXQocXVlc3Rpb24uaWQhKTtcbiAgICAgICAgICAgICAgICBpZiAobWFwcGluZ3MgJiYgbWFwcGluZ3MubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHF1ZXN0aW9uLnR5cGUgPT09IFF1aXpRdWVzdGlvblR5cGUuU0hPUlRfQU5TV0VSKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgc3VibWl0dGVkVGV4dHMgPSB0aGlzLnNob3J0QW5zd2VyU3VibWl0dGVkVGV4dHMuZ2V0KHF1ZXN0aW9uLmlkISk7XG4gICAgICAgICAgICAgICAgaWYgKHN1Ym1pdHRlZFRleHRzICYmIHN1Ym1pdHRlZFRleHRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVGhpcyBmdW5jdGlvbiBpcyBjYWxsZWQgd2hlbiB0aGUgdXNlciBjbGlja3MgdGhlICdTdWJtaXQnIGJ1dHRvblxuICAgICAqL1xuICAgIG9uU3VibWl0KCkge1xuICAgICAgICBjb25zdCB0cmFuc2xhdGlvbkJhc2VQYXRoID0gJ2FydGVtaXNBcHAucXVpekV4ZXJjaXNlLic7XG4gICAgICAgIHRoaXMuYXBwbHlTZWxlY3Rpb24oKTtcbiAgICAgICAgbGV0IGNvbmZpcm1TdWJtaXQgPSB0cnVlO1xuXG4gICAgICAgIGlmICh0aGlzLnJlbWFpbmluZ1RpbWVTZWNvbmRzID4gMTUgJiYgIXRoaXMuYXJlQWxsUXVlc3Rpb25zQW5zd2VyZWQoKSkge1xuICAgICAgICAgICAgY29uc3Qgd2FybmluZ1RleHQgPSB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCh0cmFuc2xhdGlvbkJhc2VQYXRoICsgJ3N1Ym1pc3Npb25XYXJuaW5nJyk7XG4gICAgICAgICAgICBjb25maXJtU3VibWl0ID0gd2luZG93LmNvbmZpcm0od2FybmluZ1RleHQpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjb25maXJtU3VibWl0KSB7XG4gICAgICAgICAgICB0aGlzLmlzU3VibWl0dGluZyA9IHRydWU7XG4gICAgICAgICAgICBzd2l0Y2ggKHRoaXMubW9kZSkge1xuICAgICAgICAgICAgICAgIGNhc2UgJ3ByYWN0aWNlJzpcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF0aGlzLnN1Ym1pc3Npb24uaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucXVpelBhcnRpY2lwYXRpb25TZXJ2aWNlLnN1Ym1pdEZvclByYWN0aWNlKHRoaXMuc3VibWlzc2lvbiwgdGhpcy5xdWl6SWQpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV4dDogKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2U8UmVzdWx0PikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9uU3VibWl0UHJhY3RpY2VPclByZXZpZXdTdWNjZXNzKHJlc3BvbnNlLmJvZHkhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yOiAoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiB0aGlzLm9uU3VibWl0RXJyb3IoZXJyb3IpLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAncHJldmlldyc6XG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5zdWJtaXNzaW9uLmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnF1aXpQYXJ0aWNpcGF0aW9uU2VydmljZS5zdWJtaXRGb3JQcmV2aWV3KHRoaXMuc3VibWlzc2lvbiwgdGhpcy5xdWl6SWQpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV4dDogKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2U8UmVzdWx0PikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9uU3VibWl0UHJhY3RpY2VPclByZXZpZXdTdWNjZXNzKHJlc3BvbnNlLmJvZHkhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yOiAoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiB0aGlzLm9uU3VibWl0RXJyb3IoZXJyb3IpLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAnbGl2ZSc6XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvcHkgc3VibWlzc2lvbiBhbmQgc2VuZCBpdCB0aHJvdWdoIHdlYnNvY2tldCB3aXRoICdzdWJtaXR0ZWQgPSB0cnVlJ1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBxdWl6U3VibWlzc2lvbiA9IG5ldyBRdWl6U3VibWlzc2lvbigpO1xuICAgICAgICAgICAgICAgICAgICBxdWl6U3VibWlzc2lvbi5zdWJtaXR0ZWRBbnN3ZXJzID0gdGhpcy5zdWJtaXNzaW9uLnN1Ym1pdHRlZEFuc3dlcnM7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucXVpelBhcnRpY2lwYXRpb25TZXJ2aWNlLnN1Ym1pdEZvckxpdmVNb2RlKHF1aXpTdWJtaXNzaW9uLCB0aGlzLnF1aXpJZCkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5leHQ6IChyZXNwb25zZTogSHR0cFJlc3BvbnNlPFF1aXpTdWJtaXNzaW9uPikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3VibWlzc2lvbiA9IHJlc3BvbnNlLmJvZHkhO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaXNTdWJtaXR0aW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy51cGRhdGVTdWJtaXNzaW9uVGltZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYXBwbHlTdWJtaXNzaW9uKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMucXVpekV4ZXJjaXNlLnF1aXpNb2RlICE9PSBRdWl6TW9kZS5TWU5DSFJPTklaRUQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGVydFNlcnZpY2Uuc3VjY2VzcygnYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2Uuc3VibWl0U3VjY2VzcycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvcjogKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4gdGhpcy5vblN1Ym1pdEVycm9yKGVycm9yKSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2FsbGJhY2sgZnVuY3Rpb24gZm9yIGhhbmRsaW5nIHJlc3BvbnNlIGFmdGVyIHN1Ym1pdHRpbmcgZm9yIHByYWN0aWNlIG9yIHByZXZpZXdcbiAgICAgKiBAcGFyYW0gcmVzdWx0XG4gICAgICovXG4gICAgb25TdWJtaXRQcmFjdGljZU9yUHJldmlld1N1Y2Nlc3MocmVzdWx0OiBSZXN1bHQpIHtcbiAgICAgICAgdGhpcy5pc1N1Ym1pdHRpbmcgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5zdWJtaXNzaW9uID0gcmVzdWx0LnN1Ym1pc3Npb24gYXMgUXVpelN1Ym1pc3Npb247XG4gICAgICAgIC8vIG1ha2Ugc3VyZSB0aGUgYWRkaXRpb25hbCBpbmZvcm1hdGlvbiAoZXhwbGFuYXRpb25zLCBjb3JyZWN0IGFuc3dlcnMpIGlzIGF2YWlsYWJsZVxuICAgICAgICBjb25zdCBxdWl6RXhlcmNpc2UgPSAocmVzdWx0LnBhcnRpY2lwYXRpb24hIGFzIFN0dWRlbnRQYXJ0aWNpcGF0aW9uKS5leGVyY2lzZSBhcyBRdWl6RXhlcmNpc2U7XG4gICAgICAgIHRoaXMudHJhbnNmZXJJbmZvcm1hdGlvblRvUXVpekV4ZXJjaXNlKHF1aXpFeGVyY2lzZSk7XG4gICAgICAgIHRoaXMuYXBwbHlTdWJtaXNzaW9uKCk7XG4gICAgICAgIHRoaXMuc2hvd1Jlc3VsdChyZXN1bHQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENhbGxiYWNrIGZ1bmN0aW9uIGZvciBoYW5kbGluZyBlcnJvciB3aGVuIHN1Ym1pdHRpbmdcbiAgICAgKiBAcGFyYW0gZXJyb3JcbiAgICAgKi9cbiAgICBvblN1Ym1pdEVycm9yKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkge1xuICAgICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSAnU3VibWl0dGluZyB0aGUgcXVpeiB3YXMgbm90IHBvc3NpYmxlLiAnICsgZXJyb3IuaGVhZGVycz8uZ2V0KCdYLWFydGVtaXNBcHAtbWVzc2FnZScpIHx8IGVycm9yLm1lc3NhZ2U7XG4gICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLmFkZEFsZXJ0KHtcbiAgICAgICAgICAgIHR5cGU6IEFsZXJ0VHlwZS5EQU5HRVIsXG4gICAgICAgICAgICBtZXNzYWdlOiBlcnJvck1lc3NhZ2UsXG4gICAgICAgICAgICBkaXNhYmxlVHJhbnNsYXRpb246IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmlzU3VibWl0dGluZyA9IGZhbHNlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEJ5IGNsaWNraW5nIG9uIHRoZSBidWJibGUgb2YgdGhlIHByb2dyZXNzIG5hdmlnYXRpb24gdG93YXJkcyB0aGUgY29ycmVzcG9uZGluZyBxdWVzdGlvbiBvZiB0aGUgcXVpeiBpcyB0cmlnZ2VyZWRcbiAgICAgKiBAcGFyYW0gcXVlc3Rpb25JbmRleFxuICAgICAqL1xuICAgIG5hdmlnYXRlVG9RdWVzdGlvbihxdWVzdGlvbkluZGV4OiBudW1iZXIpOiB2b2lkIHtcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3F1ZXN0aW9uJyArIHF1ZXN0aW9uSW5kZXgpIS5zY3JvbGxJbnRvVmlldyh7XG4gICAgICAgICAgICBiZWhhdmlvcjogJ3Ntb290aCcsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlZnJlc2ggcXVpelxuICAgICAqL1xuICAgIHJlZnJlc2hRdWl6KHJlZnJlc2ggPSBmYWxzZSkge1xuICAgICAgICB0aGlzLnJlZnJlc2hpbmdRdWl6ID0gcmVmcmVzaDtcbiAgICAgICAgdGhpcy5xdWl6RXhlcmNpc2VTZXJ2aWNlLmZpbmRGb3JTdHVkZW50KHRoaXMucXVpeklkKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKHJlczogSHR0cFJlc3BvbnNlPFF1aXpFeGVyY2lzZT4pID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBxdWl6RXhlcmNpc2UgPSByZXMuYm9keSE7XG4gICAgICAgICAgICAgICAgaWYgKHF1aXpFeGVyY2lzZS5xdWl6U3RhcnRlZCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAocXVpekV4ZXJjaXNlLnF1aXpFbmRlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy53YWl0aW5nRm9yUXVpelN0YXJ0ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmVuZERhdGUgPSBkYXlqcygpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucXVpekV4ZXJjaXNlID0gcXVpekV4ZXJjaXNlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmluaXRRdWl6KCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW5pdExpdmVNb2RlKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gKHRoaXMucmVmcmVzaGluZ1F1aXogPSBmYWxzZSksIDUwMCk7IC8vIGVuc3VyZSBtaW4gYW5pbWF0aW9uIGR1cmF0aW9uXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZXJyb3I6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+ICh0aGlzLnJlZnJlc2hpbmdRdWl6ID0gZmFsc2UpLCA1MDApOyAvLyBlbnN1cmUgbWluIGFuaW1hdGlvbiBkdXJhdGlvblxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgam9pbkJhdGNoKCkge1xuICAgICAgICB0aGlzLnF1aXpFeGVyY2lzZVNlcnZpY2Uuam9pbih0aGlzLnF1aXpJZCwgdGhpcy5wYXNzd29yZCkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5leHQ6IChyZXM6IEh0dHBSZXNwb25zZTxRdWl6QmF0Y2g+KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlcy5ib2R5KSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucXVpekJhdGNoID0gcmVzLmJvZHk7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnF1aXpCYXRjaD8uc3RhcnRlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZWZyZXNoUXVpeigpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdWJzY3JpYmVUb1dlYnNvY2tldENoYW5uZWxzKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZXJyb3I6IChlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSAnSm9pbmluZyB0aGUgcXVpeiB3YXMgbm90IHBvc3NpYmxlOiAnICsgZXJyb3IuaGVhZGVycz8uZ2V0KCdYLWFydGVtaXNBcHAtbWVzc2FnZScpIHx8IGVycm9yLm1lc3NhZ2U7XG4gICAgICAgICAgICAgICAgdGhpcy5hbGVydFNlcnZpY2UuYWRkQWxlcnQoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBBbGVydFR5cGUuREFOR0VSLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBlcnJvck1lc3NhZ2UsXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVUcmFuc2xhdGlvbjogdHJ1ZSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbn1cbiIsIjxkaXYgW2lkXT1cIidleGVyY2lzZS0nICsgcXVpekV4ZXJjaXNlPy5pZFwiPlxuICAgIEBpZiAocXVpekV4ZXJjaXNlKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJxdWl6LWhlYWRlciBjb250YWluZXJcIj5cbiAgICAgICAgICAgIDxoMj5cbiAgICAgICAgICAgICAgICB7eyBxdWl6RXhlcmNpc2UuY291cnNlPy50aXRsZSA/IHF1aXpFeGVyY2lzZS5jb3Vyc2U/LnRpdGxlIDogcXVpekV4ZXJjaXNlLmV4ZXJjaXNlR3JvdXA/LmV4YW0/LmNvdXJzZT8udGl0bGUgfX0gLSB7eyBxdWl6RXhlcmNpc2UudGl0bGUgfX1cbiAgICAgICAgICAgICAgICBAc3dpdGNoIChtb2RlKSB7XG4gICAgICAgICAgICAgICAgICAgIEBjYXNlICgncHJhY3RpY2UnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImluLXBhcmVudGhlc2VzXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UucHJhY3RpY2VNb2RlXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBjYXNlICgncHJldmlldycpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaW4tcGFyZW50aGVzZXNcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5wcmV2aWV3TW9kZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAY2FzZSAoJ3NvbHV0aW9uJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJpbi1wYXJlbnRoZXNlc1wiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLnNvbHV0aW9uXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgIEBpZiAoIXdhaXRpbmdGb3JRdWl6U3RhcnQgJiYgIXN1Ym1pc3Npb24uc3VibWl0dGVkICYmICFzaG93aW5nUmVzdWx0ICYmIHJlbWFpbmluZ1RpbWVTZWNvbmRzID49IDApIHtcbiAgICAgICAgICAgICAgICA8cCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5xdWl6SW5zdHJ1Y3Rpb25zLmxpdmVcIj48L3A+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKCF3YWl0aW5nRm9yUXVpelN0YXJ0ICYmIHN1Ym1pc3Npb24uc3VibWl0dGVkICYmICFzaG93aW5nUmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgPHAgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UucXVpekluc3RydWN0aW9ucy53YWl0XCI+PC9wPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmICghd2FpdGluZ0ZvclF1aXpTdGFydCAmJiBzaG93aW5nUmVzdWx0ICYmIG1vZGUgIT09ICdzb2x1dGlvbicpIHtcbiAgICAgICAgICAgICAgICA8cFxuICAgICAgICAgICAgICAgICAgICBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5xdWl6SW5zdHJ1Y3Rpb25zLnJlc3VsdFwiXG4gICAgICAgICAgICAgICAgICAgIFt0cmFuc2xhdGVWYWx1ZXNdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgdXNlclNjb3JlOiB1c2VyU2NvcmUsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXhTY29yZTogdG90YWxTY29yZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlcmNlbnRhZ2U6IHJvdW5kU2NvcmVTcGVjaWZpZWRCeUNvdXJzZVNldHRpbmdzKHJlc3VsdC5zY29yZSwgZ2V0Q291cnNlRnJvbUV4ZXJjaXNlKHF1aXpFeGVyY2lzZSkpXG4gICAgICAgICAgICAgICAgICAgIH1cIlxuICAgICAgICAgICAgICAgID48L3A+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICBAaWYgKHF1aXpFeGVyY2lzZSkge1xuICAgICAgICA8ZGl2IGNsYXNzPVwicXVpei1jb250ZW50IGNvbnRhaW5lclwiPlxuICAgICAgICAgICAgQGZvciAocXVlc3Rpb24gb2YgcXVpekV4ZXJjaXNlLnF1aXpRdWVzdGlvbnM7IHRyYWNrIHF1ZXN0aW9uOyBsZXQgaSA9ICRpbmRleCkge1xuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDwhLS0gVE9ETzogTWFwIHZzIEFycmF5IGNvbnNpc3RlbmN5IC0tPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKHF1ZXN0aW9uLnR5cGUgPT09IE1VTFRJUExFX0NIT0lDRSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1tdWx0aXBsZS1jaG9pY2UtcXVlc3Rpb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInF1ZXN0aW9ue3sgaSB9fVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW3F1ZXN0aW9uXT1cInF1ZXN0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbc2VsZWN0ZWRBbnN3ZXJPcHRpb25zXT1cInNlbGVjdGVkQW5zd2VyT3B0aW9ucy5nZXQocXVlc3Rpb24uaWQhKSFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChzZWxlY3RlZEFuc3dlck9wdGlvbnNDaGFuZ2UpPVwic2VsZWN0ZWRBbnN3ZXJPcHRpb25zLnNldChxdWVzdGlvbi5pZCEsICRldmVudClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtmbk9uU2VsZWN0aW9uXT1cIm9uU2VsZWN0aW9uQ2hhbmdlZC5iaW5kKHRoaXMpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xpY2tEaXNhYmxlZF09XCJzdWJtaXNzaW9uLnN1Ym1pdHRlZCB8fCByZW1haW5pbmdUaW1lU2Vjb25kcyA8IDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtzaG93UmVzdWx0XT1cInNob3dpbmdSZXN1bHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtzdWJtaXR0ZWRSZXN1bHRdPVwicmVzdWx0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbcXVpelF1ZXN0aW9uc109XCJxdWl6RXhlcmNpc2UucXVpelF1ZXN0aW9uc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2ZvcmNlU2FtcGxlU29sdXRpb25dPVwibW9kZSA9PT0gJ3NvbHV0aW9uJ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW3F1ZXN0aW9uSW5kZXhdPVwiaSArIDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtzY29yZV09XCJxdWVzdGlvblNjb3Jlc1txdWVzdGlvbi5pZCFdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID48L2poaS1tdWx0aXBsZS1jaG9pY2UtcXVlc3Rpb24+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPCEtLSBUT0RPOiBNYXAgdnMgQXJyYXkgY29uc2lzdGVuY3kgLS0+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAocXVlc3Rpb24udHlwZSA9PT0gRFJBR19BTkRfRFJPUCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1kcmFnLWFuZC1kcm9wLXF1ZXN0aW9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJxdWVzdGlvbnt7IGkgfX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtxdWVzdGlvbl09XCJxdWVzdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW21hcHBpbmdzXT1cImRyYWdBbmREcm9wTWFwcGluZ3MuZ2V0KHF1ZXN0aW9uLmlkISkhXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAobWFwcGluZ3NDaGFuZ2UpPVwiZHJhZ0FuZERyb3BNYXBwaW5ncy5zZXQocXVlc3Rpb24uaWQhLCAkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbb25NYXBwaW5nVXBkYXRlXT1cIm9uU2VsZWN0aW9uQ2hhbmdlZC5iaW5kKHRoaXMpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xpY2tEaXNhYmxlZF09XCJzdWJtaXNzaW9uLnN1Ym1pdHRlZCB8fCByZW1haW5pbmdUaW1lU2Vjb25kcyA8IDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtzaG93UmVzdWx0XT1cInNob3dpbmdSZXN1bHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtmb3JjZVNhbXBsZVNvbHV0aW9uXT1cIm1vZGUgPT09ICdzb2x1dGlvbidcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtxdWVzdGlvbkluZGV4XT1cImkgKyAxXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbc2NvcmVdPVwicXVlc3Rpb25TY29yZXNbcXVlc3Rpb24uaWQhXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+PC9qaGktZHJhZy1hbmQtZHJvcC1xdWVzdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8IS0tIFRPRE86IE1hcCB2cyBBcnJheSBjb25zaXN0ZW5jeSAtLT5cbiAgICAgICAgICAgICAgICAgICAgQGlmIChxdWVzdGlvbi50eXBlID09PSBTSE9SVF9BTlNXRVIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktc2hvcnQtYW5zd2VyLXF1ZXN0aW9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJxdWVzdGlvbnt7IGkgfX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtxdWVzdGlvbl09XCJxdWVzdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW3N1Ym1pdHRlZFRleHRzXT1cInNob3J0QW5zd2VyU3VibWl0dGVkVGV4dHMuZ2V0KHF1ZXN0aW9uLmlkISkhXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoc3VibWl0dGVkVGV4dHNDaGFuZ2UpPVwic2hvcnRBbnN3ZXJTdWJtaXR0ZWRUZXh0cy5zZXQocXVlc3Rpb24uaWQhLCAkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbZm5PblN1Ym1pdHRlZFRleHRVcGRhdGVdPVwib25TZWxlY3Rpb25DaGFuZ2VkLmJpbmQodGhpcylcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGlja0Rpc2FibGVkXT1cInN1Ym1pc3Npb24uc3VibWl0dGVkIHx8IHJlbWFpbmluZ1RpbWVTZWNvbmRzIDwgMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW3Nob3dSZXN1bHRdPVwic2hvd2luZ1Jlc3VsdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2ZvcmNlU2FtcGxlU29sdXRpb25dPVwibW9kZSA9PT0gJ3NvbHV0aW9uJ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW3F1ZXN0aW9uSW5kZXhdPVwiaSArIDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtzY29yZV09XCJxdWVzdGlvblNjb3Jlc1txdWVzdGlvbi5pZCFdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID48L2poaS1zaG9ydC1hbnN3ZXItcXVlc3Rpb24+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuICAgIEBpZiAocXVpekV4ZXJjaXNlKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJxdWl6LWZvb3RlclwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbnRhaW5lclwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJxdWl6LWZvb3Rlci1jb250ZW50XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJxdWl6LWljb25zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3RlcHdpemFyZHF1aXpcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAZm9yIChxdWVzdGlvbiBvZiBxdWl6RXhlcmNpc2UucXVpelF1ZXN0aW9uczsgdHJhY2sgcXVlc3Rpb247IGxldCBpID0gJGluZGV4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGVwd2l6YXJkcXVpel9fc3RlcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChxdWVzdGlvbi50eXBlID09PSBEUkFHX0FORF9EUk9QKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gYnRuLWxpZ2h0IGJ0bi1jaXJjbGUgc3RlcGJ1dHRvbiBzdGVwd2l6YXJkcXVpei1jaXJjbGUgZHJhZ2FuZGRyb3Bjb2xvci1xdWVzdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJuYXZpZ2F0ZVRvUXVlc3Rpb24oaSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbmdiVG9vbHRpcF09XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZGUgIT09ICdzb2x1dGlvbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGRyYWdBbmREcm9wTWFwcGluZ3MuZ2V0KHF1ZXN0aW9uLmlkISk/Lmxlbmd0aFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHRvb2x0aXBFeHBsYW5hdGlvblRyYW5zbGF0ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHRvb2x0aXBOb3RFeHBsYW5hdGlvblRyYW5zbGF0ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nQ2xhc3NdPVwiISFkcmFnQW5kRHJvcE1hcHBpbmdzLmdldChxdWVzdGlvbi5pZCEpPy5sZW5ndGggPyAnY2hhbmdlZC1xdWVzdGlvbicgOiAnJ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YiBjbGFzcz1cImZhXCI+REQ8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChxdWVzdGlvbi50eXBlID09PSBNVUxUSVBMRV9DSE9JQ0UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tbGlnaHQgYnRuLWNpcmNsZSBzdGVwYnV0dG9uIHN0ZXB3aXphcmRxdWl6LWNpcmNsZSBtdWx0aXBsZWNob2ljZWNvbG9yLXF1ZXN0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cIm5hdmlnYXRlVG9RdWVzdGlvbihpKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ2JUb29sdGlwXT1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kZSAhPT0gJ3NvbHV0aW9uJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gc2VsZWN0ZWRBbnN3ZXJPcHRpb25zLmdldChxdWVzdGlvbi5pZCEpPy5sZW5ndGhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB0b29sdGlwRXhwbGFuYXRpb25UcmFuc2xhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB0b29sdGlwTm90RXhwbGFuYXRpb25UcmFuc2xhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICcnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ0NsYXNzXT1cIiEhc2VsZWN0ZWRBbnN3ZXJPcHRpb25zLmdldChxdWVzdGlvbi5pZCEpPy5sZW5ndGggPyAnY2hhbmdlZC1xdWVzdGlvbicgOiAnJ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YiBjbGFzcz1cImZhXCI+TUM8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChxdWVzdGlvbi50eXBlID09PSBTSE9SVF9BTlNXRVIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tbGlnaHQgYnRuLWNpcmNsZSBzdGVwYnV0dG9uIHN0ZXB3aXphcmRxdWl6LWNpcmNsZSBzaG9ydGFuc3dlcmNvbG9yLXF1ZXN0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cIm5hdmlnYXRlVG9RdWVzdGlvbihpKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ2JUb29sdGlwXT1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kZSAhPT0gJ3NvbHV0aW9uJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gc2hvcnRBbnN3ZXJTdWJtaXR0ZWRUZXh0cy5nZXQocXVlc3Rpb24uaWQhKT8ubGVuZ3RoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gdG9vbHRpcEV4cGxhbmF0aW9uVHJhbnNsYXRlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdG9vbHRpcE5vdEV4cGxhbmF0aW9uVHJhbnNsYXRlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbmdDbGFzc109XCIhIXNob3J0QW5zd2VyU3VibWl0dGVkVGV4dHMuZ2V0KHF1ZXN0aW9uLmlkISk/Lmxlbmd0aCA/ICdjaGFuZ2VkLXF1ZXN0aW9uJyA6ICcnXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiIGNsYXNzPVwiZmFcIj5TQTwvYj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgI3Rvb2x0aXBFeHBsYW5hdGlvblRyYW5zbGF0ZT57eyAnYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuZXhwbGFuYXRpb25BbnN3ZXJlZCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSAjdG9vbHRpcE5vdEV4cGxhbmF0aW9uVHJhbnNsYXRlPnt7ICdhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5leHBsYW5hdGlvbk5vdEFuc3dlcmVkJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAocXVpekV4ZXJjaXNlLnF1aXpRdWVzdGlvbnMgJiYgIXRoaXMuaXNNb2JpbGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWxpZ24tdGV4dCBoaWRlLW1vYmlsZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBxdWl6RXhlcmNpc2UucXVpelF1ZXN0aW9ucyA/IHF1aXpFeGVyY2lzZS5xdWl6UXVlc3Rpb25zLmxlbmd0aCA6IDAgfX0gPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UucXVlc3Rpb25zXCI+PC9zcGFuPixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgdG90YWxTY29yZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS50b3RhbFBvaW50c1wiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAocXVpekV4ZXJjaXNlLnF1aXpRdWVzdGlvbnMgJiYgdGhpcy5pc01vYmlsZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhbGlnbi10ZXh0IHNob3ctbW9iaWxlXCI+e3sgcXVpekV4ZXJjaXNlLnF1aXpRdWVzdGlvbnMgPyBxdWl6RXhlcmNpc2UucXVpelF1ZXN0aW9ucy5sZW5ndGggOiAwIH19IFEgLyB7eyB0b3RhbFNjb3JlIH19IFA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoIXNob3dpbmdSZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgaWQ9XCJyZW1haW5pbmctdGltZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIXdhaXRpbmdGb3JRdWl6U3RhcnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLnJlbWFpbmluZ1RpbWVcIiBjbGFzcz1cImNvbG9uLXN1ZmZpeFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJyZW1haW5pbmctdGltZS12YWx1ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nQ2xhc3NdPVwie1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAndGltZS1jcml0aWNhbCc6IHJlbWFpbmluZ1RpbWVTZWNvbmRzIDwgNjAgfHwgcmVtYWluaW5nVGltZVNlY29uZHMgPCBxdWl6RXhlcmNpc2UuZHVyYXRpb24hIC8gNCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3RpbWUtd2FybmluZyc6IHJlbWFpbmluZ1RpbWVTZWNvbmRzIDwgMTIwIHx8IHJlbWFpbmluZ1RpbWVTZWNvbmRzIDwgcXVpekV4ZXJjaXNlLmR1cmF0aW9uISAvIDJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyByZW1haW5pbmdUaW1lVGV4dCB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChtb2RlID09PSAnbGl2ZScgJiYgd2FpdGluZ0ZvclF1aXpTdGFydCAmJiBxdWl6RXhlcmNpc2UucmVtYWluaW5nTnVtYmVyT2ZBdHRlbXB0cyAhPT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2Uud2FpdGluZ0ZvclN0YXJ0XCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChtb2RlID09PSAnbGl2ZScgJiYgIXdhaXRpbmdGb3JRdWl6U3RhcnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWlzTW9iaWxlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gbmdiVG9vbHRpcD1cInt7IHN1Ym1pc3Npb24uc3VibWlzc2lvbkRhdGUgfCBhcnRlbWlzRGF0ZTogJ2xvbmcnIDogdHJ1ZSB9fVwiIHBsYWNlbWVudD1cInJpZ2h0IGF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghc3VibWlzc2lvbi5zdWJtaXR0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmxhc3RTYXZlZFwiIGNsYXNzPVwiY29sb24tc3VmZml4XCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc3VibWlzc2lvbi5zdWJtaXR0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLnN1Ym1pdHRlZFwiIGNsYXNzPVwiY29sb24tc3VmZml4XCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoanVzdFNhdmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJqdXN0Tm93XCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWp1c3RTYXZlZCAmJiBsYXN0U2F2ZWRUaW1lVGV4dCAhPT0gJycpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGxhc3RTYXZlZFRpbWVUZXh0IH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWp1c3RTYXZlZCAmJiBsYXN0U2F2ZWRUaW1lVGV4dCA9PT0gJycpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmxhc3RTYXZlZFRpbWVOZXZlclwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gT25seSBkaXNwbGF5IHNhdmUgYW5kIHN1Ym1pc3Npb24gaGludCB3aXRob3V0IHRpbWUgc3RhbXBzIGZvciBtb2JpbGUgLS0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGlzTW9iaWxlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gbmdiVG9vbHRpcD1cInt7IHN1Ym1pc3Npb24uc3VibWlzc2lvbkRhdGUgfCBhcnRlbWlzRGF0ZTogJ2xvbmcnIDogdHJ1ZSB9fVwiIHBsYWNlbWVudD1cInJpZ2h0IGF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghc3VibWlzc2lvbi5zdWJtaXR0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLmxhc3RTYXZlZFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHN1Ym1pc3Npb24uc3VibWl0dGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5zdWJtaXR0ZWRcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKG1vZGUgPT09ICdsaXZlJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLWNvbm5lY3Rpb24tc3RhdHVzIGNsYXNzPVwiY29ubmVjdGlvbi1zdGF0dXMtcXVpelwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG5nLWNvbnRhaW5lciBpbm5lckNvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICh1bnNhdmVkQ2hhbmdlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS51bnNhdmVkQ2hhbmdlc1wiIGNsYXNzPVwiaW4tcGFyZW50aGVzZXNcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9uZy1jb250YWluZXI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvamhpLWNvbm5lY3Rpb24tc3RhdHVzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKG1vZGUgPT09ICdwcmFjdGljZScpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLnByYWN0aWNlTW9kZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAobW9kZSA9PT0gJ3ByZXZpZXcnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5wcmV2aWV3TW9kZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQGlmIChzaG93aW5nUmVzdWx0ICYmIG1vZGUgIT09ICdzb2x1dGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgaWQ9XCJxdWl6LXNjb3JlXCIgW25nQ2xhc3NdPVwieyBpbmNvcnJlY3Q6IHVzZXJTY29yZSA8IHRvdGFsU2NvcmUgfVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImNvbG9uLXN1ZmZpeFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLnRvdGFsU2NvcmVcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGlkPVwicXVpei1zY29yZS1yZXN1bHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPnt7IHVzZXJTY29yZSB9fS97eyB0b3RhbFNjb3JlIH19ICh7e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdW5kU2NvcmVTcGVjaWZpZWRCeUNvdXJzZVNldHRpbmdzKHJlc3VsdC5zY29yZSwgcXVpekV4ZXJjaXNlLmNvdXJzZSB8fCBxdWl6RXhlcmNpc2UuZXhlcmNpc2VHcm91cD8uZXhhbT8uY291cnNlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICUpPC9zcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKG1vZGUgPT09ICdwcmFjdGljZScpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLnByYWN0aWNlTW9kZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAobW9kZSA9PT0gJ3ByZXZpZXcnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5wcmV2aWV3TW9kZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQGlmIChtb2RlID09PSAnc29sdXRpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLnNvbHV0aW9uXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQGlmIChtb2RlID09PSAnbGl2ZScgJiYgIXF1aXpCYXRjaD8uc3RhcnRlZCAmJiAhcXVpekJhdGNoPy5zdGFydFRpbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktYnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJyZWZyZXNoLXF1aXpcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChvbkNsaWNrKT1cInJlZnJlc2hRdWl6KHRydWUpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbYnRuU2l6ZV09XCJpc01vYmlsZSA/IEJ1dHRvblNpemUuU01BTEwgOiBCdXR0b25TaXplLkxBUkdFXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbYnRuVHlwZV09XCJCdXR0b25UeXBlLlBSSU1BUllcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0aXRsZV09XCInYXJ0ZW1pc0FwcC5leGVyY2lzZS5yZWZyZXNoJ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2Rpc2FibGVkXT1cInJlZnJlc2hpbmdRdWl6XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbaWNvbl09XCJmYVN5bmNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvamhpLWJ1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3VibWl0LWJ1dHRvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghc2hvd2luZ1Jlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktYnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwic3VibWl0LXF1aXpcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAob25DbGljayk9XCJvblN1Ym1pdCgpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2J0blNpemVdPVwiaXNNb2JpbGUgPyBCdXR0b25TaXplLlNNQUxMIDogQnV0dG9uU2l6ZS5MQVJHRVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtidG5UeXBlXT1cIkJ1dHRvblR5cGUuU1VDQ0VTU1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0aXRsZV09XCJzdWJtaXNzaW9uLnN1Ym1pdHRlZCA/ICdhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5zdWJtaXR0ZWQnIDogJ2VudGl0eS5hY3Rpb24uc3VibWl0J1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtkaXNhYmxlZF09XCJzdWJtaXNzaW9uLnN1Ym1pdHRlZCB8fCBpc1N1Ym1pdHRpbmcgfHwgd2FpdGluZ0ZvclF1aXpTdGFydCB8fCByZW1haW5pbmdUaW1lU2Vjb25kcyA8IDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2poaS1idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICBAaWYgKCF3YWl0aW5nRm9yUXVpelN0YXJ0ICYmICFzaG93aW5nUmVzdWx0ICYmICFzdWJtaXNzaW9uLnN1Ym1pdHRlZCAmJiByZW1haW5pbmdUaW1lU2Vjb25kcyA8IDApIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cInF1aXotaXMtb3Zlci1vdmVybGF5IGFsZXJ0IGFsZXJ0LWluZm9cIj5cbiAgICAgICAgICAgIEBpZiAoc3VibWlzc2lvbi5zdWJtaXNzaW9uRGF0ZSkge1xuICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLnF1aXpJc092ZXJUZXh0XCI+PC9zcGFuPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmICghc3VibWlzc2lvbi5zdWJtaXNzaW9uRGF0ZSkge1xuICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLm5vdFBhcnRpY2lwYXRlZFRleHRcIj48L3NwYW4+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICBAaWYgKCF3YWl0aW5nRm9yUXVpelN0YXJ0ICYmIHN1Ym1pc3Npb24uc3VibWl0dGVkICYmICFzaG93aW5nUmVzdWx0ICYmIHF1aXpFeGVyY2lzZT8ucXVpek1vZGUgPT09IFF1aXpNb2RlLlNZTkNIUk9OSVpFRCkge1xuICAgICAgICA8ZGl2IGNsYXNzPVwicXVpei1zdWJtaXR0ZWQtb3ZlcmxheSBhbGVydCBhbGVydC1zdWNjZXNzXCI+XG4gICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5zdWNjZXNzZnVsbHlTdWJtaXR0ZWRUZXh0XCI+PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmICh3YWl0aW5nRm9yUXVpelN0YXJ0KSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJxdWl6LXdhaXRpbmctZm9yLXN0YXJ0LW92ZXJsYXkgYWxlcnQgYWxlcnQtaW5mb1wiPlxuICAgICAgICAgICAgQGlmIChxdWl6QmF0Y2ggfHwgcXVpekV4ZXJjaXNlLnF1aXpNb2RlID09PSBRdWl6TW9kZS5TWU5DSFJPTklaRUQpIHtcbiAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5xdWl6SW5zdHJ1Y3Rpb25zLndhaXRGb3JTdGFydFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICBAaWYgKHN0YXJ0RGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGhyIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5xdWl6SW5zdHJ1Y3Rpb25zLnRpbWVVbnRpbFBsYW5uZWRTdGFydFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1ib2xkXCI+e3sgdGltZVVudGlsU3RhcnQgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPih7eyBxdWl6RXhlcmNpc2UucmVsZWFzZURhdGUhLmZvcm1hdCgnTFQnKSB9fSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAoIXF1aXpCYXRjaCAmJiBxdWl6RXhlcmNpc2UucXVpek1vZGUgPT09IFF1aXpNb2RlLkJBVENIRUQgJiYgKHF1aXpFeGVyY2lzZS5yZW1haW5pbmdOdW1iZXJPZkF0dGVtcHRzID8/IDEpID4gMCkge1xuICAgICAgICAgICAgICAgIDxkaXYgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UucXVpekluc3RydWN0aW9ucy5lbnRlclBhc3N3b3JkXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0IGlkPVwiam9pbi1wYXRjaC1wYXNzd29yZFwiIFsobmdNb2RlbCldPVwicGFzc3dvcmRcIiAvPlxuICAgICAgICAgICAgICAgIDxqaGktYnV0dG9uIGlkPVwiam9pbi1iYXRjaFwiIFt0aXRsZV09XCInYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2Uuam9pbidcIiBbYnRuVHlwZV09XCJCdXR0b25UeXBlLlNVQ0NFU1NcIiAob25DbGljayk9XCJqb2luQmF0Y2goKVwiPjwvamhpLWJ1dHRvbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAoIXF1aXpCYXRjaCAmJiBxdWl6RXhlcmNpc2UucXVpek1vZGUgPT09IFF1aXpNb2RlLklORElWSURVQUwgJiYgKHF1aXpFeGVyY2lzZS5yZW1haW5pbmdOdW1iZXJPZkF0dGVtcHRzID8/IDEpID4gMCkge1xuICAgICAgICAgICAgICAgIDxkaXYgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UucXVpekluc3RydWN0aW9ucy5zdGFydE5vd1wiPjwvZGl2PlxuICAgICAgICAgICAgICAgIDxqaGktYnV0dG9uIGlkPVwic3RhcnQtYmF0Y2hcIiBbdGl0bGVdPVwiJ2FydGVtaXNBcHAucXVpekV4ZXJjaXNlLnN0YXJ0QmF0Y2gnXCIgW2J0blR5cGVdPVwiQnV0dG9uVHlwZS5TVUNDRVNTXCIgKG9uQ2xpY2spPVwiam9pbkJhdGNoKClcIj48L2poaS1idXR0b24+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKCFxdWl6QmF0Y2ggJiYgcXVpekV4ZXJjaXNlLnF1aXpNb2RlICE9PSBRdWl6TW9kZS5TWU5DSFJPTklaRUQgJiYgcXVpekV4ZXJjaXNlLnJlbWFpbmluZ051bWJlck9mQXR0ZW1wdHMgPT09IDApIHtcbiAgICAgICAgICAgICAgICBAaWYgKChxdWl6RXhlcmNpc2UuYWxsb3dlZE51bWJlck9mQXR0ZW1wdHMgPz8gMCkgPiAxKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UucXVpekluc3RydWN0aW9ucy5ub01vcmVBdHRlbXB0c1wiPjwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKHF1aXpFeGVyY2lzZS5hbGxvd2VkTnVtYmVyT2ZBdHRlbXB0cyA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2IGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucXVpekV4ZXJjaXNlLnF1aXpJbnN0cnVjdGlvbnMuYWxyZWFkeUF0dGVtcHRlZFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuICAgIDxkaXYgY2xhc3M9XCJxdWl6LXJlZnJlc2gtb3ZlcmxheVwiIFtjbGFzcy5hY3RpdmVdPVwicmVmcmVzaGluZ1F1aXpcIj5cbiAgICAgICAgPGZhLWljb24gc2l6ZT1cImxnXCIgW2ljb25dPVwiZmFDaXJjbGVOb3RjaFwiIFtzcGluXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgPC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IFJvdXRlcyB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5cbmltcG9ydCB7IFF1aXpQYXJ0aWNpcGF0aW9uQ29tcG9uZW50IH0gZnJvbSAnLi9xdWl6LXBhcnRpY2lwYXRpb24uY29tcG9uZW50JztcbmltcG9ydCB7IFVzZXJSb3V0ZUFjY2Vzc1NlcnZpY2UgfSBmcm9tICdhcHAvY29yZS9hdXRoL3VzZXItcm91dGUtYWNjZXNzLXNlcnZpY2UnO1xuXG5leHBvcnQgY29uc3QgcXVpelBhcnRpY2lwYXRpb25Sb3V0ZTogUm91dGVzID0gW1xuICAgIHtcbiAgICAgICAgcGF0aDogJ2xpdmUnLFxuICAgICAgICBjb21wb25lbnQ6IFF1aXpQYXJ0aWNpcGF0aW9uQ29tcG9uZW50LFxuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICBhdXRob3JpdGllczogW10sXG4gICAgICAgICAgICBwYWdlVGl0bGU6ICdhcnRlbWlzQXBwLnF1aXpFeGVyY2lzZS5ob21lLnRpdGxlJyxcbiAgICAgICAgICAgIG1vZGU6ICdsaXZlJyxcbiAgICAgICAgfSxcbiAgICAgICAgY2FuQWN0aXZhdGU6IFtVc2VyUm91dGVBY2Nlc3NTZXJ2aWNlXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgcGF0aDogJ3ByYWN0aWNlJyxcbiAgICAgICAgY29tcG9uZW50OiBRdWl6UGFydGljaXBhdGlvbkNvbXBvbmVudCxcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgYXV0aG9yaXRpZXM6IFtdLFxuICAgICAgICAgICAgcGFnZVRpdGxlOiAnYXJ0ZW1pc0FwcC5xdWl6RXhlcmNpc2UuaG9tZS50aXRsZScsXG4gICAgICAgICAgICBtb2RlOiAncHJhY3RpY2UnLFxuICAgICAgICB9LFxuICAgICAgICBjYW5BY3RpdmF0ZTogW1VzZXJSb3V0ZUFjY2Vzc1NlcnZpY2VdLFxuICAgIH0sXG5dO1xuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJvdXRlck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBxdWl6UGFydGljaXBhdGlvblJvdXRlIH0gZnJvbSAnLi9xdWl6LXBhcnRpY2lwYXRpb24ucm91dGUnO1xuaW1wb3J0IHsgUXVpelBhcnRpY2lwYXRpb25Db21wb25lbnQgfSBmcm9tICcuL3F1aXotcGFydGljaXBhdGlvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9zaGFyZWQtY29tcG9uZW50Lm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNRdWl6UXVlc3Rpb25UeXBlc01vZHVsZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL2FydGVtaXMtcXVpei1xdWVzdGlvbi10eXBlcy5tb2R1bGUnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlLCBSb3V0ZXJNb2R1bGUuZm9yQ2hpbGQocXVpelBhcnRpY2lwYXRpb25Sb3V0ZSksIEFydGVtaXNTaGFyZWRDb21wb25lbnRNb2R1bGUsIEFydGVtaXNRdWl6UXVlc3Rpb25UeXBlc01vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbUXVpelBhcnRpY2lwYXRpb25Db21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBBcnRlbWlzUXVpelBhcnRpY2lwYXRpb25Nb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsa0JBQWdDO0FBSXpDLFNBQVMsV0FBVzs7O0FBTHBCLElBWWE7QUFaYjs7QUFNQTs7QUFNTSxJQUFPLDJCQUFQLE1BQU8sMEJBQXdCO01BRXJCO01BQ0E7TUFGWixZQUNZLE1BQ0EsbUJBQW9DO0FBRHBDLGFBQUEsT0FBQTtBQUNBLGFBQUEsb0JBQUE7TUFDVDtNQUVILGtCQUFrQixnQkFBZ0MsWUFBa0I7QUFDaEUsY0FBTSxPQUFPLEtBQUssa0JBQWtCLFFBQVEsY0FBYztBQUMxRCxlQUFPLEtBQUssS0FDUCxLQUFhLGlCQUFpQixVQUFVLHlCQUF5QixNQUFNLEVBQUUsU0FBUyxXQUFVLENBQUUsRUFDOUYsS0FBSyxJQUFJLENBQUMsUUFBNEIsS0FBSyxrQkFBa0IsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO01BQzNGO01BRUEsaUJBQWlCLGdCQUFnQyxZQUFrQjtBQUMvRCxjQUFNLE9BQU8sS0FBSyxrQkFBa0IsUUFBUSxjQUFjO0FBQzFELGVBQU8sS0FBSyxLQUNQLEtBQWEsaUJBQWlCLFVBQVUsd0JBQXdCLE1BQU0sRUFBRSxTQUFTLFdBQVUsQ0FBRSxFQUM3RixLQUFLLElBQUksQ0FBQyxRQUE0QixLQUFLLGtCQUFrQixnQkFBZ0IsR0FBRyxDQUFDLENBQUM7TUFDM0Y7TUFFQSxrQkFBa0IsZ0JBQWdDLFlBQWtCO0FBQ2hFLGNBQU0sT0FBTyxLQUFLLGtCQUFrQixRQUFRLGNBQWM7QUFDMUQsZUFBTyxLQUFLLEtBQ1AsS0FBcUIsaUJBQWlCLFVBQVUscUJBQXFCLE1BQU0sRUFBRSxTQUFTLFdBQVUsQ0FBRSxFQUNsRyxLQUFLLElBQUksQ0FBQyxRQUE0QixLQUFLLGtCQUFrQixnQkFBZ0IsR0FBRyxDQUFDLENBQUM7TUFDM0Y7O3lCQXpCUywyQkFBd0Isc0JBQUEsYUFBQSxHQUFBLHNCQUFBLGlCQUFBLENBQUE7TUFBQTttRUFBeEIsMkJBQXdCLFNBQXhCLDBCQUF3QixXQUFBLFlBRFgsT0FBTSxDQUFBOzs7Ozs7QUNYaEMsU0FBUyxXQUE4QixXQUFXLG9CQUFvQjtBQUN0RSxPQUFPLFdBQVc7QUFDbEIsT0FBTyxjQUFjO0FBR3JCLFNBQVMsc0JBQXNCO0FBUS9CLFNBQVMsd0JBQXdCO0FBQ2pDLFlBQVksa0JBQWtCO0FBc0I5QixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLHdCQUF3QjtBQUVqQyxTQUFTLGVBQWUsY0FBYzs7Ozs7Ozs7OztBQ2hDZCxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7Ozs7QUFJSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxLQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQVFKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQU5RLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsOEJBQUEsR0FBQSxLQUFBLFFBQUEsV0FBQSxRQUFBLFlBQUEsUUFBQSxvQ0FBQSxRQUFBLE9BQUEsT0FBQSxRQUFBLHNCQUFBLFFBQUEsWUFBQSxDQUFBLENBQUEsQ0FBQTs7Ozs7QUF4QlosSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7QUFFSSxJQUFBLHlCQUFBLEdBQUEsMERBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSwwREFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLDBEQUFBLEdBQUEsQ0FBQTtBQVFULElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsa0VBQUEsR0FBQSxDQUFBLEVBRUMsSUFBQSxrRUFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLGtFQUFBLEdBQUEsQ0FBQTtBQWNMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsUUFBQTs7Ozs7QUE5QlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSx1QkFBQSxPQUFBLGFBQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxhQUFBLE9BQUEsU0FBQSxPQUFBLGFBQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxhQUFBLE9BQUEsUUFBQSxPQUFBLGFBQUEsaUJBQUEsT0FBQSxPQUFBLE9BQUEsYUFBQSxjQUFBLFFBQUEsT0FBQSxPQUFBLE9BQUEsYUFBQSxjQUFBLEtBQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxhQUFBLGNBQUEsS0FBQSxPQUFBLE9BQUEsT0FBQSxPQUFBLGFBQUEsT0FBQSxvQkFBQTtBQUNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSx1REFBQSxPQUFBLFVBQUEsYUFBQSxJQUFBLHlEQUFBLFlBQUEsSUFBQSx5REFBQSxhQUFBLElBQUEsRUFBQTtBQVlKLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxDQUFBLE9BQUEsdUJBQUEsQ0FBQSxPQUFBLFdBQUEsYUFBQSxDQUFBLE9BQUEsaUJBQUEsT0FBQSx3QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxDQUFBLE9BQUEsdUJBQUEsT0FBQSxXQUFBLGFBQUEsQ0FBQSxPQUFBLGdCQUFBLEtBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxDQUFBLE9BQUEsdUJBQUEsT0FBQSxpQkFBQSxPQUFBLFNBQUEsYUFBQSxLQUFBLEVBQUE7Ozs7OztBQWtCWSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsZ0NBQUEsRUFBQTtBQUlJLElBQUEseUJBQUEsK0JBQUEsU0FBQSwwSUFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxlQUFBLDRCQUFBLEVBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQStCLDBCQUFBLFFBQUEsc0JBQUEsSUFBQSxhQUFBLElBQUEsTUFBQSxDQUErQztJQUFBLENBQUE7QUFTakYsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7Ozs7OztBQWJRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEscUNBQUEsTUFBQSxZQUFBLE9BQUEsRUFBQTtBQUNBLElBQUEseUJBQUEsWUFBQSxZQUFBLEVBQXFCLHlCQUFBLFFBQUEsc0JBQUEsSUFBQSxhQUFBLEVBQUEsQ0FBQSxFQUFBLGlCQUFBLFFBQUEsbUJBQUEsS0FBQSxPQUFBLENBQUEsRUFBQSxpQkFBQSxRQUFBLFdBQUEsYUFBQSxRQUFBLHVCQUFBLENBQUEsRUFBQSxjQUFBLFFBQUEsYUFBQSxFQUFBLG1CQUFBLFFBQUEsTUFBQSxFQUFBLGlCQUFBLFFBQUEsYUFBQSxhQUFBLEVBQUEsdUJBQUEsUUFBQSxTQUFBLFVBQUEsRUFBQSxpQkFBQSxRQUFBLENBQUEsRUFBQSxTQUFBLFFBQUEsZUFBQSxhQUFBLEVBQUEsQ0FBQTs7Ozs7O0FBZXpCLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSw4QkFBQSxFQUFBO0FBSUksSUFBQSx5QkFBQSxrQkFBQSxTQUFBLDJIQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGVBQUEsNEJBQUEsRUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBa0IsMEJBQUEsUUFBQSxvQkFBQSxJQUFBLGFBQUEsSUFBQSxNQUFBLENBQTZDO0lBQUEsQ0FBQTtBQU9sRSxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7Ozs7O0FBWFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxxQ0FBQSxNQUFBLFlBQUEsT0FBQSxFQUFBO0FBQ0EsSUFBQSx5QkFBQSxZQUFBLFlBQUEsRUFBcUIsWUFBQSxRQUFBLG9CQUFBLElBQUEsYUFBQSxFQUFBLENBQUEsRUFBQSxtQkFBQSxRQUFBLG1CQUFBLEtBQUEsT0FBQSxDQUFBLEVBQUEsaUJBQUEsUUFBQSxXQUFBLGFBQUEsUUFBQSx1QkFBQSxDQUFBLEVBQUEsY0FBQSxRQUFBLGFBQUEsRUFBQSx1QkFBQSxRQUFBLFNBQUEsVUFBQSxFQUFBLGlCQUFBLFFBQUEsQ0FBQSxFQUFBLFNBQUEsUUFBQSxlQUFBLGFBQUEsRUFBQSxDQUFBOzs7Ozs7QUFhekIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLDZCQUFBLEVBQUE7QUFJSSxJQUFBLHlCQUFBLHdCQUFBLFNBQUEsZ0lBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsZUFBQSw0QkFBQSxFQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUF3QiwwQkFBQSxRQUFBLDBCQUFBLElBQUEsYUFBQSxJQUFBLE1BQUEsQ0FBbUQ7SUFBQSxDQUFBO0FBTzlFLElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7Ozs7QUFYUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHFDQUFBLE1BQUEsWUFBQSxPQUFBLEVBQUE7QUFDQSxJQUFBLHlCQUFBLFlBQUEsWUFBQSxFQUFxQixrQkFBQSxRQUFBLDBCQUFBLElBQUEsYUFBQSxFQUFBLENBQUEsRUFBQSwyQkFBQSxRQUFBLG1CQUFBLEtBQUEsT0FBQSxDQUFBLEVBQUEsaUJBQUEsUUFBQSxXQUFBLGFBQUEsUUFBQSx1QkFBQSxDQUFBLEVBQUEsY0FBQSxRQUFBLGFBQUEsRUFBQSx1QkFBQSxRQUFBLFNBQUEsVUFBQSxFQUFBLGlCQUFBLFFBQUEsQ0FBQSxFQUFBLFNBQUEsUUFBQSxlQUFBLGFBQUEsRUFBQSxDQUFBOzs7OztBQXJDakMsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsdUVBQUEsR0FBQSxFQUFBO0FBaUJBLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx1RUFBQSxHQUFBLENBQUE7QUFlQSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsdUVBQUEsR0FBQSxDQUFBO0FBY0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7Ozs7QUEvQ1EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLGFBQUEsU0FBQSxRQUFBLGtCQUFBLElBQUEsRUFBQTtBQWlCQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsYUFBQSxTQUFBLFFBQUEsZ0JBQUEsSUFBQSxFQUFBO0FBZUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLGFBQUEsU0FBQSxRQUFBLGVBQUEsSUFBQSxFQUFBOzs7OztBQXBDWixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEseURBQUEsSUFBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQW1ESixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7QUFwRFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxPQUFBLGFBQUEsYUFBQTs7Ozs7O0FBOEQ0QixJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBRUksSUFBQSx5QkFBQSxTQUFBLFNBQUEsK0ZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFFBQUEsNEJBQUEsRUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLG1CQUFBLEtBQUEsQ0FBcUI7SUFBQSxDQUFBO0FBVTlCLElBQUEscUJBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBYyxJQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFFLElBQUEsMkJBQUE7QUFDcEIsSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3Q0FBQTs7Ozs7Ozs7O0FBWFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLFFBQUEsU0FBQSxlQUFBLFVBQUEsUUFBQSxvQkFBQSxJQUFBLGFBQUEsRUFBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLFVBQUEsT0FBQSxPQUFBLEVBQUEsRUFNQyxXQUFBLENBQUEsR0FBQSxVQUFBLFFBQUEsb0JBQUEsSUFBQSxhQUFBLEVBQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxVQUFBLHFCQUFBLEVBQUE7Ozs7OztBQU9MLElBQUEscUJBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFFSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSwrRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsUUFBQSw0QkFBQSxFQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsbUJBQUEsS0FBQSxDQUFxQjtJQUFBLENBQUE7QUFVOUIsSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUFjLElBQUEscUJBQUEsR0FBQSxJQUFBO0FBQUUsSUFBQSwyQkFBQTtBQUNwQixJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdDQUFBOzs7Ozs7Ozs7QUFYUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGNBQUEsUUFBQSxTQUFBLGVBQUEsVUFBQSxRQUFBLHNCQUFBLElBQUEsYUFBQSxFQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsVUFBQSxPQUFBLE9BQUEsRUFBQSxFQU1DLFdBQUEsQ0FBQSxHQUFBLFVBQUEsUUFBQSxzQkFBQSxJQUFBLGFBQUEsRUFBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLFVBQUEscUJBQUEsRUFBQTs7Ozs7O0FBT0wsSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUVJLElBQUEseUJBQUEsU0FBQSxTQUFBLCtGQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxRQUFBLDRCQUFBLEVBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxtQkFBQSxLQUFBLENBQXFCO0lBQUEsQ0FBQTtBQVU5QixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQWMsSUFBQSxxQkFBQSxHQUFBLElBQUE7QUFBRSxJQUFBLDJCQUFBO0FBQ3BCLElBQUEscUJBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0NBQUE7Ozs7Ozs7OztBQVhRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSxRQUFBLFNBQUEsZUFBQSxVQUFBLFFBQUEsMEJBQUEsSUFBQSxhQUFBLEVBQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxVQUFBLE9BQUEsT0FBQSxFQUFBLEVBTUMsV0FBQSxDQUFBLEdBQUEsVUFBQSxRQUFBLDBCQUFBLElBQUEsYUFBQSxFQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsVUFBQSxxQkFBQSxFQUFBOzs7OztBQU1pQyxJQUFBLHFCQUFBLENBQUE7Ozs7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsR0FBQSw2Q0FBQSxDQUFBOzs7OztBQUNHLElBQUEscUJBQUEsQ0FBQTs7OztBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLGdEQUFBLENBQUE7Ozs7O0FBbERqRCxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLHdFQUFBLEdBQUEsQ0FBQSxFQWVDLEdBQUEsd0VBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSx3RUFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLHdFQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsSUFBQSxvQ0FBQTtBQWtDRCxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsd0VBQUEsR0FBQSxHQUFBLGVBQUEsTUFBQSxJQUFBLG9DQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQ0FBQTs7Ozs7QUFuRFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLGFBQUEsU0FBQSxRQUFBLGdCQUFBLElBQUEsRUFBQTtBQWdCQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsYUFBQSxTQUFBLFFBQUEsa0JBQUEsSUFBQSxFQUFBO0FBZ0JBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxhQUFBLFNBQUEsUUFBQSxlQUFBLElBQUEsRUFBQTs7Ozs7QUFzQlIsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUF5RSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQThELElBQUEscUJBQUEsQ0FBQTtBQUV2SSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQUpRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsc0NBQUEsUUFBQSxhQUFBLGdCQUFBLFFBQUEsYUFBQSxjQUFBLFNBQUEsR0FBQSxHQUFBO0FBQXVJLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsdUNBQUEsUUFBQSxZQUFBLG9DQUFBOzs7OztBQU0zSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQW9DLElBQUEscUJBQUEsQ0FBQTtBQUErRixJQUFBLDJCQUFBO0FBQ3ZJLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQUR3QyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLElBQUEsUUFBQSxhQUFBLGdCQUFBLFFBQUEsYUFBQSxjQUFBLFNBQUEsR0FBQSxTQUFBLFFBQUEsWUFBQSxJQUFBOzs7OztBQU1oQyxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBT0ksSUFBQSxxQkFBQSxDQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7QUFSWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsOEJBQUEsR0FBQSxLQUFBLFFBQUEsdUJBQUEsTUFBQSxRQUFBLHVCQUFBLFFBQUEsYUFBQSxXQUFBLEdBQUEsUUFBQSx1QkFBQSxPQUFBLFFBQUEsdUJBQUEsUUFBQSxhQUFBLFdBQUEsQ0FBQSxDQUFBO0FBS0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSw4Q0FBQSxRQUFBLG1CQUFBLHdDQUFBOzs7OztBQUtSLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7O0FBTW9CLElBQUEscUJBQUEsR0FBQSxvREFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLG9EQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnREFBQTs7Ozs7QUFFSSxJQUFBLHFCQUFBLEdBQUEsb0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdEQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSxvREFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBO0FBQXVCLElBQUEsMkJBQUE7QUFDakMsSUFBQSxxQkFBQSxHQUFBLGdEQUFBOzs7O0FBRFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxRQUFBLGlCQUFBOzs7OztBQUdOLElBQUEscUJBQUEsR0FBQSxvREFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7Ozs7O0FBZkosSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTs7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsNEdBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSw0R0FBQSxHQUFBLENBQUEsRUFBQSxHQUFBLDRHQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsNEdBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSw0R0FBQSxHQUFBLENBQUE7QUFhTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdDQUFBOzs7O0FBakJVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsb0NBQUEsY0FBQSwwQkFBQSxHQUFBLEdBQUEsUUFBQSxXQUFBLGdCQUFBLFFBQUEsSUFBQSxDQUFBO0FBQ0YsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsUUFBQSxXQUFBLFlBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsV0FBQSxZQUFBLElBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLFlBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsUUFBQSxhQUFBLFFBQUEsc0JBQUEsS0FBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxRQUFBLGFBQUEsUUFBQSxzQkFBQSxLQUFBLElBQUEsRUFBQTs7Ozs7QUFTSSxJQUFBLHFCQUFBLEdBQUEsb0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdEQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSxvREFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7Ozs7O0FBTkosSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTs7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsNEdBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSw0R0FBQSxHQUFBLENBQUE7QUFJTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdDQUFBOzs7O0FBUlUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxjQUFBLDBCQUFBLEdBQUEsR0FBQSxRQUFBLFdBQUEsZ0JBQUEsUUFBQSxJQUFBLENBQUE7QUFDRixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxRQUFBLFdBQUEsWUFBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxXQUFBLFlBQUEsSUFBQSxFQUFBOzs7OztBQTFCWixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSw4RkFBQSxJQUFBLEVBQUE7QUFvQkEsSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDhGQUFBLEdBQUEsQ0FBQTtBQVVKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7QUEvQlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsUUFBQSxXQUFBLElBQUEsRUFBQTtBQW9CQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxXQUFBLElBQUEsRUFBQTs7Ozs7QUFnQlEsSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0Q0FBQTs7Ozs7QUFKUixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEseUJBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsc0NBQUEsR0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDhGQUFBLEdBQUEsQ0FBQTtBQUdKLElBQUEsb0NBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7O0FBTFksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsaUJBQUEsSUFBQSxFQUFBOzs7OztBQU9SLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7Ozs7QUF4RUosSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxnRkFBQSxHQUFBLENBQUEsRUFhQyxHQUFBLGdGQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsZ0ZBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSxnRkFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLGdGQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsZ0ZBQUEsR0FBQSxDQUFBO0FBMkRMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUF6RVEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsUUFBQSxzQkFBQSxJQUFBLEVBQUE7QUFjQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxTQUFBLFVBQUEsUUFBQSx1QkFBQSxRQUFBLGFBQUEsOEJBQUEsSUFBQSxJQUFBLEVBQUE7QUFLQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxTQUFBLFVBQUEsQ0FBQSxRQUFBLHNCQUFBLElBQUEsRUFBQTtBQWtDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxTQUFBLFNBQUEsSUFBQSxFQUFBO0FBU0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsU0FBQSxhQUFBLElBQUEsRUFBQTtBQUtBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLFNBQUEsWUFBQSxJQUFBLEVBQUE7Ozs7O0FBbUJJLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7Ozs7QUFuQkosSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNLLElBQUEscUJBQUEsQ0FBQTtBQUdDLElBQUEsMkJBQUE7QUFFVixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLGlGQUFBLEdBQUEsQ0FBQSxFQUlDLElBQUEsaUZBQUEsR0FBQSxDQUFBO0FBTUwsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTs7OztBQXBCNkIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLDhCQUFBLEdBQUEsS0FBQSxRQUFBLFlBQUEsUUFBQSxVQUFBLENBQUE7QUFHWixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLElBQUEsUUFBQSxXQUFBLEtBQUEsUUFBQSxZQUFBLE1BQUEsUUFBQSxvQ0FBQSxRQUFBLE9BQUEsT0FBQSxRQUFBLGFBQUEsV0FBQSxRQUFBLGFBQUEsaUJBQUEsT0FBQSxPQUFBLFFBQUEsYUFBQSxjQUFBLFFBQUEsT0FBQSxPQUFBLFFBQUEsYUFBQSxjQUFBLEtBQUEsT0FBQSxHQUFBLDBDQUFBO0FBTVQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsU0FBQSxhQUFBLEtBQUEsRUFBQTtBQUtBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLFNBQUEsWUFBQSxLQUFBLEVBQUE7Ozs7O0FBUUosSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLGNBQUEsRUFBQTtBQUVJLElBQUEseUJBQUEsV0FBQSxTQUFBLGlHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFXLDBCQUFBLFFBQUEsWUFBWSxJQUFJLENBQUM7SUFBQSxDQUFBO0FBTS9CLElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFOUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsUUFBQSxXQUFBLFFBQUEsV0FBQSxRQUFBLFFBQUEsV0FBQSxLQUFBLEVBQTBELFdBQUEsUUFBQSxXQUFBLE9BQUEsRUFBQSxTQUFBLDZCQUFBLEVBQUEsWUFBQSxRQUFBLGNBQUEsRUFBQSxRQUFBLFFBQUEsTUFBQTs7Ozs7O0FBUzFELElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxjQUFBLEVBQUE7QUFFSSxJQUFBLHlCQUFBLFdBQUEsU0FBQSxpR0FBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBVywwQkFBQSxRQUFBLFNBQUEsQ0FBVTtJQUFBLENBQUE7QUFLeEIsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQUxRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxRQUFBLFdBQUEsUUFBQSxXQUFBLFFBQUEsUUFBQSxXQUFBLEtBQUEsRUFBMEQsV0FBQSxRQUFBLFdBQUEsT0FBQSxFQUFBLFNBQUEsUUFBQSxXQUFBLFlBQUEsc0NBQUEsc0JBQUEsRUFBQSxZQUFBLFFBQUEsV0FBQSxhQUFBLFFBQUEsZ0JBQUEsUUFBQSx1QkFBQSxRQUFBLHVCQUFBLENBQUE7Ozs7O0FBL0xsRixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwrQkFBQSxJQUFBLDBEQUFBLElBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7QUFzREosSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxrRUFBQSxHQUFBLENBQUEsRUFNQyxJQUFBLGtFQUFBLEdBQUEsQ0FBQTtBQUlMLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsa0VBQUEsSUFBQSxDQUFBLEVBMkVDLElBQUEsa0VBQUEsSUFBQSxDQUFBLEVBQUEsSUFBQSxrRUFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLGtFQUFBLEdBQUEsQ0FBQTtBQXdDRCxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLGtFQUFBLEdBQUEsQ0FBQTtBQVVKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBOzs7O0FBcE13QixJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsYUFBQSxhQUFBO0FBdURKLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLGFBQUEsaUJBQUEsQ0FBQSxPQUFBLFdBQUEsS0FBQSxFQUFBO0FBT0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsYUFBQSxpQkFBQSxPQUFBLFdBQUEsS0FBQSxFQUFBO0FBSUosSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLENBQUEsT0FBQSxnQkFBQSxLQUFBLEVBQUE7QUE0RUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsaUJBQUEsT0FBQSxTQUFBLGFBQUEsS0FBQSxFQUFBO0FBdUJBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLFNBQUEsYUFBQSxLQUFBLEVBQUE7QUFLQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxTQUFBLFVBQUEsRUFBQSxPQUFBLGFBQUEsT0FBQSxPQUFBLE9BQUEsVUFBQSxZQUFBLEVBQUEsT0FBQSxhQUFBLE9BQUEsT0FBQSxPQUFBLFVBQUEsYUFBQSxLQUFBLEVBQUE7QUFZSSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsQ0FBQSxPQUFBLGdCQUFBLEtBQUEsRUFBQTs7Ozs7QUFrQlIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7Ozs7QUFFSSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7OztBQU5KLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxpRUFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLGlFQUFBLEdBQUEsQ0FBQTtBQUlMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQVBRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLFdBQUEsaUJBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsT0FBQSxXQUFBLGlCQUFBLElBQUEsRUFBQTs7Ozs7QUFNSixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7O0FBTWdCLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLElBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUF3QixJQUFBLHFCQUFBLENBQUE7QUFBb0IsSUFBQSwyQkFBQTtBQUM1QyxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsSUFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxFQUFBO0FBQThDLElBQUEsMkJBQUE7QUFDeEQsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTs7OztBQUpnQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFFBQUEsY0FBQTtBQUVsQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsUUFBQSxhQUFBLFlBQUEsT0FBQSxJQUFBLEdBQUEsR0FBQTs7Ozs7QUFQZCxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLCtFQUFBLElBQUEsQ0FBQTs7OztBQUFBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLFlBQUEsSUFBQSxFQUFBOzs7Ozs7QUFXQSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUFnQyxJQUFBLHlCQUFBLGlCQUFBLFNBQUEsK0ZBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBQSwwQkFBQSxRQUFBLFdBQUEsTUFBQTtJQUFBLENBQUE7QUFBaEMsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxjQUFBLEVBQUE7QUFBb0csSUFBQSx5QkFBQSxXQUFBLFNBQUEsZ0dBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVcsMEJBQUEsUUFBQSxVQUFBLENBQVc7SUFBQSxDQUFBO0FBQUUsSUFBQSwyQkFBQTtBQUNoSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFGb0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLFFBQUEsUUFBQTtBQUNKLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsU0FBQSw4QkFBQSxFQUF3QyxXQUFBLFFBQUEsV0FBQSxPQUFBOzs7Ozs7QUFHcEUsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxjQUFBLEVBQUE7QUFBMkcsSUFBQSx5QkFBQSxXQUFBLFNBQUEsZ0dBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVcsMEJBQUEsUUFBQSxVQUFBLENBQVc7SUFBQSxDQUFBO0FBQUUsSUFBQSwyQkFBQTtBQUN2SSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFEaUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxTQUFBLG9DQUFBLEVBQThDLFdBQUEsUUFBQSxXQUFBLE9BQUE7Ozs7O0FBSXZFLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7Ozs7QUFMQSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsK0VBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSwrRUFBQSxHQUFBLENBQUE7Ozs7O0FBRkQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxLQUFBLFVBQUEsUUFBQSxhQUFBLDZCQUFBLFFBQUEsWUFBQSxTQUFBLFVBQUEsS0FBQSxJQUFBLElBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLGFBQUEsNEJBQUEsSUFBQSxJQUFBLEVBQUE7Ozs7O0FBMUJSLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxpRUFBQSxHQUFBLENBQUEsRUFXQyxHQUFBLGlFQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsaUVBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSxpRUFBQSxHQUFBLENBQUE7QUFrQkwsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7Ozs7QUE5QlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsYUFBQSxPQUFBLGFBQUEsYUFBQSxPQUFBLFNBQUEsZUFBQSxJQUFBLEVBQUE7QUFZQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxPQUFBLGFBQUEsT0FBQSxhQUFBLGFBQUEsT0FBQSxTQUFBLGFBQUEsVUFBQSxPQUFBLGFBQUEsK0JBQUEsUUFBQSxZQUFBLFNBQUEsVUFBQSxLQUFBLElBQUEsSUFBQSxFQUFBO0FBS0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsT0FBQSxhQUFBLE9BQUEsYUFBQSxhQUFBLE9BQUEsU0FBQSxnQkFBQSxVQUFBLE9BQUEsYUFBQSwrQkFBQSxRQUFBLFlBQUEsU0FBQSxVQUFBLEtBQUEsSUFBQSxJQUFBLEVBQUE7QUFJQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsQ0FBQSxPQUFBLGFBQUEsT0FBQSxhQUFBLGFBQUEsT0FBQSxTQUFBLGdCQUFBLE9BQUEsYUFBQSw4QkFBQSxJQUFBLElBQUEsRUFBQTs7O0FEM1VaLG1CQWdEYTtBQWhEYjs7QUFNQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFRTSxJQUFPLDZCQUFQLE1BQU8sNEJBQTBCO01Bb0Z2QjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQTNGSCxnQkFBZ0IsaUJBQWlCO01BQ2pDLGtCQUFrQixpQkFBaUI7TUFDbkMsZUFBZSxpQkFBaUI7TUFDaEMsYUFBYTtNQUNiLGFBQWE7TUFDYixXQUFXO01BQ1gsc0NBQXNDO01BQ3RDLHdCQUF3QjtNQUdqQztNQUdBO01BR0E7TUFFUTtNQUNBO01BRVIsa0JBQWtCLElBQUksTUFBSztNQUUzQixlQUFlO01BRWYsb0JBQW9CO01BQ3BCLFlBQVk7TUFDWixzQkFBc0I7TUFDdEIsaUJBQWlCO01BRWpCLG9CQUFvQjtNQUNwQix1QkFBdUI7TUFDdkIsaUJBQWlCO01BQ2pCLGVBQWU7TUFDZixpQkFBaUI7TUFFakI7TUFDQSxnQkFBZ0I7TUFDaEI7TUFFQTtNQUNBLGFBQWEsSUFBSSxlQUFjO01BQy9CO01BQ0E7TUFDQTtNQUNBLHdCQUF3QixvQkFBSSxJQUFHO01BQy9CLHNCQUFzQixvQkFBSSxJQUFHO01BQzdCLDRCQUE0QixvQkFBSSxJQUFHO01BQ25DO01BQ0EsaUJBQWlCLENBQUE7TUFDakI7TUFDQTtNQUNBO01BQ0EsY0FBYztNQUNkO01BQ0E7TUFDQSxXQUFXO01BQ1gsa0JBQWtCO01BQ2xCLFdBQVc7TUFLWDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BTUEsbUJBQW1CLFNBQVMsTUFBSztBQUM3QixhQUFLLFlBQVk7TUFDckIsR0FBRyxHQUFJO01BR1AsU0FBUztNQUNULGdCQUFnQjtNQUVoQixZQUNZLHFCQUNBLHFCQUNBLHNCQUNBLCtCQUNBLE9BQ0EsY0FDQSwwQkFDQSxrQkFDQSxhQUNBLG1CQUEyQztBQVQzQyxhQUFBLHNCQUFBO0FBQ0EsYUFBQSxzQkFBQTtBQUNBLGFBQUEsdUJBQUE7QUFDQSxhQUFBLGdDQUFBO0FBQ0EsYUFBQSxRQUFBO0FBQ0EsYUFBQSxlQUFBO0FBQ0EsYUFBQSwyQkFBQTtBQUNBLGFBQUEsbUJBQUE7QUFDQSxhQUFBLGNBQUE7QUFDQSxhQUFBLG9CQUFBO0FBRVIsUUFBYSxzQkFBUTtNQUN6QjtNQUVBLFdBQVE7QUFDSixhQUFLLFdBQVcsU0FBUyxPQUFPLFVBQVUsU0FBUyxFQUFFO0FBRXJELGFBQUssbUJBQW1CLEtBQUssTUFBTSxLQUFLLFVBQVUsQ0FBQyxTQUFRO0FBQ3ZELGVBQUssT0FBTyxLQUFLO0FBQ2pCLGVBQUssZUFBZSxLQUFLLE1BQU0sT0FBTyxVQUFVLENBQUMsV0FBVTtBQUN2RCxpQkFBSyxTQUFTLE9BQU8sT0FBTyxZQUFZLENBQUM7QUFDekMsaUJBQUssV0FBVyxPQUFPLE9BQU8sVUFBVSxDQUFDO0FBRXpDLG9CQUFRLEtBQUssTUFBTTtjQUNmLEtBQUs7QUFDRCxxQkFBSyxpQkFBZ0I7QUFDckI7Y0FDSixLQUFLO0FBQ0QscUJBQUssWUFBVztBQUNoQjtjQUNKLEtBQUs7QUFDRCxxQkFBSyxpQkFBZ0I7QUFDckI7Y0FDSixLQUFLO0FBQ0QscUJBQUssYUFBWTtBQUNqQjs7VUFFWixDQUFDO1FBQ0wsQ0FBQztBQUVELGFBQUssV0FBVyxZQUFZLE1BQUs7QUFDN0IsZUFBSyxxQkFBb0I7QUFDekIsZUFBSyxnQkFBZTtRQUN4QixHQUFHLGNBQWM7TUFDckI7TUFFQSxjQUFXO0FBQ1Asc0JBQWMsS0FBSyxRQUFRO0FBSTNCLGFBQUssZ0JBQWdCLFFBQVEsQ0FBQyxZQUFXO0FBQ3JDLHVCQUFhLE9BQU87UUFDeEIsQ0FBQztBQUVELFlBQUksS0FBSyxtQkFBbUI7QUFDeEIsZUFBSyxvQkFBb0IsWUFBWSxVQUFVLEtBQUssaUJBQWlCOztBQUV6RSxZQUFJLEtBQUssc0JBQXNCO0FBQzNCLGVBQUssb0JBQW9CLFlBQVksS0FBSyxvQkFBb0I7O0FBRWxFLFlBQUksS0FBSyxxQkFBcUI7QUFDMUIsZUFBSyxvQkFBb0IsWUFBWSxLQUFLLG1CQUFtQjs7QUFFakUsYUFBSyx1QkFBdUIsWUFBVztBQUN2QyxZQUFJLEtBQUssY0FBYztBQUNuQixlQUFLLGFBQWEsWUFBVzs7QUFFakMsWUFBSSxLQUFLLGtCQUFrQjtBQUN2QixlQUFLLGlCQUFpQixZQUFXOztNQUV6QztNQUtBLGVBQVk7QUFFUixhQUFLLHdCQUF3QixLQUFLLG9CQUFvQixnQkFBZ0IsVUFBVSxDQUFDLFdBQVU7QUFDdkYsY0FBSSxPQUFPLGFBQWEsS0FBSyxjQUFjO0FBRXZDLGdCQUFJLEtBQUssa0JBQWtCLEtBQUssZUFBZTtBQUMzQyxtQkFBSyxtQkFBa0I7O0FBRzNCLGdCQUFJLEtBQUssYUFBYSxDQUFDLEtBQUssVUFBVSxTQUFTO0FBQzNDLG1CQUFLLFlBQVksSUFBSTt1QkFDZCxLQUFLLGFBQWEsS0FBSyxXQUFXLEtBQUssUUFBUSxTQUFTLEtBQUssa0JBQWtCLElBQUcsQ0FBRSxHQUFHO0FBRTlGLG1CQUFLLFlBQVksSUFBSTs7O0FBRzdCLGVBQUssZUFBZSxDQUFDLE9BQU87UUFDaEMsQ0FBQztBQUVELGFBQUssNkJBQTRCO0FBR2pDLGFBQUsscUJBQXFCLGdDQUFnQyxLQUFLLE1BQU0sRUFBRSxVQUFVO1VBQzdFLE1BQU0sQ0FBQyxhQUFnRDtBQUNuRCxpQkFBSyw4QkFBOEIsU0FBUyxJQUFLO1VBQ3JEO1VBQ0EsT0FBTyxDQUFDLFVBQTZCLFFBQVEsS0FBSyxjQUFjLEtBQUs7U0FDeEU7TUFDTDtNQUtBLG1CQUFnQjtBQUNaLGFBQUssb0JBQW9CLGVBQWUsS0FBSyxNQUFNLEVBQUUsVUFBVTtVQUMzRCxNQUFNLENBQUMsUUFBbUM7QUFDdEMsZ0JBQUksSUFBSSxRQUFRLElBQUksS0FBSyxtQkFBbUI7QUFDeEMsbUJBQUssMkJBQTJCLElBQUksSUFBSTttQkFDckM7QUFDSCxvQkFBTSw0Q0FBNEM7O1VBRTFEO1VBQ0EsT0FBTyxDQUFDLFVBQTZCLFFBQVEsS0FBSyxjQUFjLEtBQUs7U0FDeEU7TUFDTDtNQUtBLGNBQVc7QUFDUCxhQUFLLG9CQUFvQixLQUFLLEtBQUssTUFBTSxFQUFFLFVBQVU7VUFDakQsTUFBTSxDQUFDLFFBQW1DO0FBQ3RDLGlCQUFLLDJCQUEyQixJQUFJLElBQUs7VUFDN0M7VUFDQSxPQUFPLENBQUMsVUFBNkIsUUFBUSxLQUFLLGNBQWMsS0FBSztTQUN4RTtNQUNMO01BRUEsbUJBQWdCO0FBQ1osYUFBSyxvQkFBb0IsS0FBSyxLQUFLLE1BQU0sRUFBRSxVQUFVO1VBQ2pELE1BQU0sQ0FBQyxRQUFtQztBQUN0QyxpQkFBSyxlQUFlLElBQUk7QUFDeEIsaUJBQUssU0FBUTtBQUNiLGlCQUFLLGdCQUFnQjtVQUN6QjtVQUNBLE9BQU8sQ0FBQyxVQUE2QixRQUFRLEtBQUssY0FBYyxLQUFLO1NBQ3hFO01BQ0w7TUFPQSwyQkFBMkIsY0FBMEI7QUFFakQsYUFBSyxlQUFlO0FBQ3BCLGFBQUssU0FBUTtBQUdiLGFBQUssWUFBWSxlQUFlLEtBQUssYUFBYSxlQUFlLEtBQUssYUFBYSxzQkFBc0I7QUFHekcsYUFBSyxhQUFhLElBQUksZUFBYztBQUdwQyxhQUFLLFVBQVUsTUFBSyxFQUFHLElBQUksS0FBSyxhQUFhLFVBQVcsU0FBUztBQUdqRSxhQUFLLGdCQUFnQixLQUNqQixXQUFXLE1BQUs7QUFDWixlQUFLLFNBQVE7UUFDakIsR0FBRyxhQUFhLFdBQVksR0FBSSxDQUFDO01BRXpDO01BS0EsK0JBQTRCO0FBQ3hCLFlBQUksQ0FBQyxLQUFLLG1CQUFtQjtBQUN6QixlQUFLLG9CQUFvQix5QkFBeUIsS0FBSyxTQUFTO0FBR2hFLGVBQUssb0JBQW9CLFVBQVUsVUFBVSxLQUFLLGlCQUFpQjtBQUNuRSxlQUFLLG9CQUFvQixRQUFRLFVBQVUsS0FBSyxpQkFBaUIsRUFBRSxVQUFVO1lBQ3pFLE1BQU0sQ0FBQyxZQUFXO0FBQ2Qsa0JBQUksUUFBUSxPQUFPO0FBQ2YscUJBQUssWUFBWSxRQUFRLEtBQUs7O1lBRXRDO1lBQ0EsT0FBTyxDQUFDLFVBQVM7QUFDYixtQkFBSyxZQUFZLEtBQUs7WUFDMUI7V0FDSDtBQUdELGVBQUssZ0JBQWdCLENBQUMsZUFBOEI7QUFDaEQsaUJBQUssb0JBQW9CLEtBQUssS0FBSyxtQkFBbUIsVUFBVTtVQUNwRTs7QUFHSixZQUFJLENBQUMsS0FBSyxzQkFBc0I7QUFDNUIsZUFBSyx1QkFBdUIsMEJBQTBCLEtBQUssU0FBUztBQUdwRSxlQUFLLG9CQUFvQixVQUFVLEtBQUssb0JBQW9CO0FBQzVELGVBQUssb0JBQW9CLFFBQVEsS0FBSyxvQkFBb0IsRUFBRSxVQUFVLENBQUMseUJBQThDO0FBQ2pILGdCQUFJLHdCQUF3QixLQUFLLGdCQUFnQixxQkFBcUIsU0FBVSxPQUFPLEtBQUssYUFBYSxJQUFJO0FBQ3pHLGtCQUFJLEtBQUsscUJBQXFCO0FBRTFCLHFCQUFLLDhCQUE4QixvQkFBb0I7cUJBQ3BEO0FBRUgscUJBQUssMkJBQTJCLG9CQUFvQjs7O1VBR2hFLENBQUM7O0FBR0wsWUFBSSxDQUFDLEtBQUsscUJBQXFCO0FBQzNCLGVBQUssc0JBQXNCLG9CQUFvQixLQUFLLFdBQVc7QUFFL0QsZUFBSyxvQkFBb0IsVUFBVSxLQUFLLG1CQUFtQjtBQUMzRCxlQUFLLG9CQUFvQixRQUFRLEtBQUssbUJBQW1CLEVBQUUsVUFBVSxDQUFDLFNBQVE7QUFDMUUsZ0JBQUksS0FBSyx1QkFBdUIsS0FBSyxXQUFXLEtBQUssSUFBSTtBQUNyRCxtQkFBSyxjQUFjLElBQUk7O1VBRS9CLENBQUM7O0FBR0wsWUFBSSxLQUFLLGFBQWEsQ0FBQyxLQUFLLFVBQVUsU0FBUztBQUMzQyxnQkFBTSxlQUFlLEtBQUssc0JBQXNCLE1BQU0sS0FBSyxVQUFVO0FBQ3JFLGNBQUksS0FBSyxxQkFBcUIsY0FBYztBQUN4QyxpQkFBSyxtQkFBbUI7QUFDeEIsaUJBQUssb0JBQW9CLFVBQVUsS0FBSyxnQkFBZ0I7QUFDeEQsaUJBQUssb0JBQW9CLFFBQVEsS0FBSyxnQkFBZ0IsRUFBRSxVQUFVLENBQUMsU0FBUTtBQUN2RSxtQkFBSyxjQUFjLElBQUk7WUFDM0IsQ0FBQzs7O01BR2I7TUFLQSx1QkFBb0I7QUFDaEIsY0FBTSxzQkFBc0I7QUFFNUIsWUFBSSxLQUFLLFNBQVM7QUFDZCxnQkFBTSxVQUFVLEtBQUs7QUFDckIsY0FBSSxRQUFRLFFBQVEsS0FBSyxrQkFBa0IsSUFBRyxDQUFFLEdBQUc7QUFFL0MsaUJBQUssdUJBQXVCLFFBQVEsS0FBSyxLQUFLLGtCQUFrQixJQUFHLEdBQUksU0FBUztBQUNoRixpQkFBSyxvQkFBb0IsS0FBSyxpQkFBaUIsS0FBSyxvQkFBb0I7aUJBQ3JFO0FBRUgsaUJBQUssdUJBQXVCO0FBQzVCLGlCQUFLLG9CQUFvQixLQUFLLGlCQUFpQixRQUFRLHNCQUFzQixjQUFjOztlQUU1RjtBQUVILGVBQUssdUJBQXVCO0FBQzVCLGVBQUssb0JBQW9COztBQUk3QixZQUFJLEtBQUssY0FBYyxLQUFLLFdBQVcsZ0JBQWdCO0FBRW5ELGVBQUssb0JBQW9CLE1BQU0sS0FBSyxXQUFXLGNBQWMsRUFBRSxRQUFPOztBQUkxRSxZQUFJLEtBQUssYUFBYSxLQUFLLFdBQVc7QUFDbEMsY0FBSSxLQUFLLFVBQVUsUUFBUSxLQUFLLGtCQUFrQixJQUFHLENBQUUsR0FBRztBQUN0RCxpQkFBSyxpQkFBaUIsS0FBSyxpQkFBaUIsS0FBSyxVQUFVLEtBQUssS0FBSyxrQkFBa0IsSUFBRyxHQUFJLFNBQVMsQ0FBQztpQkFDckc7QUFDSCxpQkFBSyxpQkFBaUIsS0FBSyxpQkFBaUIsUUFBUSxzQkFBc0IsS0FBSztBQUUvRSxnQkFBSSxDQUFDLEtBQUssVUFBVSxXQUFXLENBQUMsS0FBSyxhQUFhO0FBQzlDLG1CQUFLLGNBQWM7QUFDbkIsa0JBQUksS0FBSyxhQUFhLGFBQWEsU0FBUyxZQUFZO0FBRXBELHFCQUFLLFlBQVksSUFBSTtxQkFDbEI7QUFFSCwyQkFBVyxNQUFLO0FBRVosc0JBQUksQ0FBQyxLQUFLLGFBQWEsQ0FBQyxLQUFLLFVBQVUsU0FBUztBQUM1Qyx5QkFBSyxZQUFZLElBQUk7O2dCQUU3QixHQUFHLEdBQUk7Ozs7ZUFJaEI7QUFDSCxlQUFLLGlCQUFpQjs7TUFFOUI7TUFRQSxpQkFBaUIsc0JBQTRCO0FBQ3pDLFlBQUksdUJBQXVCLEtBQUs7QUFDNUIsaUJBQU8sS0FBSyxLQUFLLHVCQUF1QixFQUFFLElBQUk7bUJBQ3ZDLHVCQUF1QixJQUFJO0FBQ2xDLGlCQUFPLEtBQUssTUFBTSx1QkFBdUIsRUFBRSxJQUFJLFVBQVcsdUJBQXVCLEtBQU07ZUFDcEY7QUFDSCxpQkFBTyx1QkFBdUI7O01BRXRDO01BRUEsa0JBQWU7QUFDWCxjQUFNLFVBQVUsS0FBSyxTQUFTLFVBQVUsQ0FBQyxDQUFDLEtBQUssYUFBYSxLQUFLLHdCQUF3QixLQUFLLEtBQUssY0FBYyxhQUFhLFNBQVM7QUFDdkksWUFBSSxDQUFDLFdBQVcsS0FBSyxpQkFBaUI7QUFDbEMsY0FBSSxDQUFDLEtBQUssV0FBVyxhQUFhLEtBQUssV0FBVyxnQkFBZ0I7QUFDOUQsaUJBQUssYUFBYSxRQUFRLHVDQUF1Qzs7O0FBR3pFLGFBQUssa0JBQWtCO01BQzNCO01BS0EsV0FBUTtBQUVKLGFBQUssYUFBYSxLQUFLLGFBQWEsZ0JBQzlCLEtBQUssYUFBYSxjQUFjLE9BQU8sQ0FBQyxPQUFPLGFBQVk7QUFDdkQsaUJBQU8sUUFBUSxTQUFTO1FBQzVCLEdBQUcsQ0FBQyxJQUNKO0FBR04sYUFBSyx3QkFBd0Isb0JBQUksSUFBRztBQUNwQyxhQUFLLHNCQUFzQixvQkFBSSxJQUFHO0FBQ2xDLGFBQUssNEJBQTRCLG9CQUFJLElBQUc7QUFFeEMsWUFBSSxLQUFLLGFBQWEsZUFBZTtBQUNqQyxlQUFLLGFBQWEsY0FBYyxRQUFRLENBQUMsYUFBWTtBQUNqRCxnQkFBSSxTQUFTLFNBQVMsaUJBQWlCLGlCQUFpQjtBQUVwRCxtQkFBSyxzQkFBc0IsSUFBSSxTQUFTLElBQUssQ0FBQSxDQUFFO3VCQUN4QyxTQUFTLFNBQVMsaUJBQWlCLGVBQWU7QUFFekQsbUJBQUssb0JBQW9CLElBQUksU0FBUyxJQUFLLENBQUEsQ0FBRTt1QkFDdEMsU0FBUyxTQUFTLGlCQUFpQixjQUFjO0FBRXhELG1CQUFLLDBCQUEwQixJQUFJLFNBQVMsSUFBSyxDQUFBLENBQUU7bUJBQ2hEO0FBQ0gsc0JBQVEsTUFBTSw0QkFBNEIsUUFBUTs7VUFFMUQsR0FBRyxJQUFJOztNQUVmO01BUUEsa0JBQWU7QUFHWCxhQUFLLHdCQUF3QixvQkFBSSxJQUFHO0FBQ3BDLGFBQUssc0JBQXNCLG9CQUFJLElBQUc7QUFDbEMsYUFBSyw0QkFBNEIsb0JBQUksSUFBRztBQUV4QyxZQUFJLEtBQUssYUFBYSxlQUFlO0FBRWpDLGVBQUssYUFBYSxjQUFjLFFBQVEsQ0FBQyxhQUFZO0FBRWpELGtCQUFNLGtCQUFrQixLQUFLLFdBQVcsa0JBQWtCLEtBQUssQ0FBQyxXQUFVO0FBQ3RFLHFCQUFPLE9BQU8sYUFBYyxPQUFPLFNBQVM7WUFDaEQsQ0FBQztBQUVELGdCQUFJLFNBQVMsU0FBUyxpQkFBaUIsaUJBQWlCO0FBRXBELG1CQUFLLHNCQUFzQixJQUFJLFNBQVMsSUFBTSxpQkFBbUQsbUJBQW1CLENBQUEsQ0FBRTt1QkFDL0csU0FBUyxTQUFTLGlCQUFpQixlQUFlO0FBRXpELG1CQUFLLG9CQUFvQixJQUFJLFNBQVMsSUFBTSxpQkFBZ0QsWUFBWSxDQUFBLENBQUU7dUJBQ25HLFNBQVMsU0FBUyxpQkFBaUIsY0FBYztBQUV4RCxtQkFBSywwQkFBMEIsSUFBSSxTQUFTLElBQU0saUJBQWdELGtCQUFrQixDQUFBLENBQUU7bUJBQ25IO0FBQ0gsc0JBQVEsTUFBTSw0QkFBNEIsUUFBUTs7VUFFMUQsR0FBRyxJQUFJOztNQUVmO01BT0EsaUJBQWM7QUFHVixhQUFLLFdBQVcsbUJBQW1CLENBQUE7QUFHbkMsYUFBSyxzQkFBc0IsUUFBUSxDQUFDLGVBQWUsZUFBYztBQUU3RCxnQkFBTSxXQUFXLEtBQUssYUFBYSxlQUFlLEtBQUssQ0FBQyxxQkFBb0I7QUFDeEUsbUJBQU8saUJBQWlCLE9BQU87VUFDbkMsQ0FBQztBQUNELGNBQUksQ0FBQyxVQUFVO0FBQ1gsb0JBQVEsTUFBTSxnQ0FBZ0MsVUFBVTtBQUN4RDs7QUFHSixnQkFBTSxvQkFBb0IsSUFBSSw4QkFBNkI7QUFDM0QsNEJBQWtCLGVBQWU7QUFDakMsNEJBQWtCLGtCQUFrQjtBQUNwQyxlQUFLLFdBQVcsaUJBQWtCLEtBQUssaUJBQWlCO1FBQzVELEdBQUcsSUFBSTtBQUdQLGFBQUssb0JBQW9CLFFBQVEsQ0FBQyxVQUFVLGVBQWM7QUFFdEQsZ0JBQU0sV0FBVyxLQUFLLGFBQWEsZUFBZSxLQUFLLENBQUMsa0JBQWlCO0FBQ3JFLG1CQUFPLGNBQWMsT0FBTztVQUNoQyxDQUFDO0FBQ0QsY0FBSSxDQUFDLFVBQVU7QUFDWCxvQkFBUSxNQUFNLGdDQUFnQyxVQUFVO0FBQ3hEOztBQUdKLGdCQUFNLHFCQUFxQixJQUFJLDJCQUEwQjtBQUN6RCw2QkFBbUIsZUFBZTtBQUNsQyw2QkFBbUIsV0FBVztBQUM5QixlQUFLLFdBQVcsaUJBQWtCLEtBQUssa0JBQWtCO1FBQzdELEdBQUcsSUFBSTtBQUVQLGFBQUssMEJBQTBCLFFBQVEsQ0FBQyxnQkFBZ0IsZUFBYztBQUVsRSxnQkFBTSxXQUFXLEtBQUssYUFBYSxlQUFlLEtBQUssQ0FBQyxrQkFBaUI7QUFDckUsbUJBQU8sY0FBYyxPQUFPO1VBQ2hDLENBQUM7QUFDRCxjQUFJLENBQUMsVUFBVTtBQUNYLG9CQUFRLE1BQU0sZ0NBQWdDLFVBQVU7QUFDeEQ7O0FBR0osZ0JBQU0sNkJBQTZCLElBQUksMkJBQTBCO0FBQ2pFLHFDQUEyQixlQUFlO0FBQzFDLHFDQUEyQixpQkFBaUI7QUFDNUMsZUFBSyxXQUFXLGlCQUFrQixLQUFLLDBCQUEwQjtRQUNyRSxHQUFHLElBQUk7TUFDWDtNQUtBLDhCQUE4QixlQUFtQztBQUM3RCxZQUFJLGVBQWU7QUFDZixlQUFLLGNBQWMsY0FBYyxRQUF3Qjs7QUFJN0QsWUFBSSxlQUFlLFNBQVMsUUFBUTtBQUNoQyxlQUFLLGFBQWEsY0FBYyxRQUFRLENBQUMsRUFBRTtBQUczQyxlQUFLLHFCQUFvQjtBQUd6QixlQUFLLGdCQUFlO0FBRXBCLGNBQUksY0FBYyxRQUFRLENBQUMsRUFBRSxVQUFVLFVBQWEsS0FBSyxhQUFhLFdBQVc7QUFFN0UsaUJBQUssV0FBVyxjQUFjLFFBQVEsQ0FBQyxDQUFDOztlQUV6QztBQUNILGVBQUssYUFBYSxJQUFJLGVBQWM7QUFDcEMsZUFBSyxTQUFROztNQUVyQjtNQU1BLGNBQWMsY0FBMEI7QUFDcEMsYUFBSyxlQUFlO0FBQ3BCLGFBQUssU0FBUTtBQUViLGFBQUssWUFBWSxLQUFLLGFBQWEsY0FBYyxDQUFDO0FBQ2xELFlBQUksS0FBSyxhQUFhLFdBQVc7QUFFN0IsZUFBSyxzQkFBc0I7bUJBQ3BCLENBQUMsS0FBSyxhQUFhLENBQUMsS0FBSyxVQUFVLFNBQVM7QUFFbkQsZUFBSyxzQkFBc0I7QUFHM0IsZUFBSyxvQkFBb0IsZ0JBQWU7QUFFeEMsY0FBSSxLQUFLLGFBQWEsS0FBSyxVQUFVLFdBQVc7QUFFNUMsaUJBQUssWUFBWSxNQUFNLEtBQUssVUFBVSxhQUFhLEtBQUssa0JBQWtCLElBQUcsQ0FBRTs7ZUFFaEY7QUFFSCxlQUFLLHNCQUFzQjtBQUczQixlQUFLLFlBQVksTUFBTSxLQUFLLFVBQVUsYUFBYSxLQUFLLGtCQUFrQixJQUFHLENBQUU7QUFDL0UsZUFBSyxVQUFVLEtBQUssVUFBVSxJQUFJLEtBQUssYUFBYSxVQUFXLFNBQVM7QUFHeEUsY0FBSSxDQUFDLEtBQUssVUFBVSxPQUFPO0FBRXZCLGlCQUFLLG9CQUFvQixnQkFBZTtBQUd4QyxpQkFBSyxZQUFZLGVBQWUsS0FBSyxhQUFhLGVBQWUsS0FBSyxhQUFhLHNCQUFzQjs7O01BR3JIO01BS0EsMkJBQTJCLGVBQW1DO0FBQzFELGNBQU0sZUFBZSxjQUFjO0FBQ25DLFlBQUksY0FBYyxTQUFTLE1BQUssR0FBSSxlQUFlLFVBQWEsYUFBYSxXQUFXO0FBRXBGLGVBQUssYUFBYSxjQUFjLFFBQVEsQ0FBQyxFQUFFO0FBRzNDLGVBQUsscUJBQW9CO0FBQ3pCLGVBQUssa0NBQWtDLFlBQVk7QUFDbkQsZUFBSyxnQkFBZTtBQUNwQixlQUFLLFdBQVcsY0FBYyxRQUFRLENBQUMsQ0FBQzs7TUFFaEQ7TUFTQSxrQ0FBa0MsNEJBQXdDO0FBQ3RFLGFBQUssYUFBYSxjQUFlLFFBQVEsQ0FBQyxtQkFBa0I7QUFFeEQsZ0JBQU0seUJBQXlCLDJCQUEyQixlQUFlLEtBQUssQ0FBQyxpQkFBZ0I7QUFDM0YsbUJBQU8sZUFBZSxPQUFPLGFBQWE7VUFDOUMsQ0FBQztBQUNELGNBQUksd0JBQXdCO0FBQ3hCLDJCQUFlLGNBQWMsdUJBQXVCO0FBRXBELGdCQUFJLGVBQWUsU0FBUyxpQkFBaUIsaUJBQWlCO0FBQzFELG9CQUFNLG1CQUFtQjtBQUN6QixvQkFBTSwyQkFBMkI7QUFFakMsb0JBQU0sZ0JBQWdCLGlCQUFpQjtBQUN2Qyw0QkFBYyxRQUFRLENBQUMsdUJBQXNCO0FBRXpDLHNCQUFNLDZCQUE2Qix5QkFBeUIsY0FBZSxLQUFLLENBQUMsV0FBVTtBQUN2Rix5QkFBTyxtQkFBbUIsT0FBTyxPQUFPO2dCQUM1QyxDQUFDO0FBQ0Qsb0JBQUksNEJBQTRCO0FBQzVCLHFDQUFtQixjQUFjLDJCQUEyQjtBQUM1RCxxQ0FBbUIsWUFBWSwyQkFBMkI7O2NBRWxFLENBQUM7dUJBQ00sZUFBZSxTQUFTLGlCQUFpQixlQUFlO0FBQy9ELG9CQUFNLG9CQUFvQjtBQUMxQixvQkFBTSw0QkFBNEI7QUFFbEMsZ0NBQWtCLGtCQUFrQiwwQkFBMEI7dUJBQ3ZELGVBQWUsU0FBUyxpQkFBaUIsY0FBYztBQUM5RCxvQkFBTSw0QkFBNEI7QUFDbEMsb0JBQU0sb0NBQW9DO0FBQzFDLHdDQUEwQixrQkFBa0Isa0NBQWtDO21CQUMzRTtBQUNILCtCQUFpQixJQUFJLE1BQU0sNEJBQTRCLGNBQWMsQ0FBQzs7O1FBR2xGLEdBQUcsSUFBSTtBQUdQLGFBQUsscUJBQXFCLFFBQVEsQ0FBQyx3QkFBdUI7QUFDdEQsOEJBQW9CLGdCQUFlO1FBQ3ZDLENBQUM7QUFDRCxhQUFLLHNCQUFzQixRQUFRLENBQUMseUJBQXdCO0FBQ3hELCtCQUFxQixnQkFBZTtRQUN4QyxDQUFDO0FBQ0QsYUFBSyw4QkFBOEIsUUFBUSxDQUFDLGlDQUFnQztBQUN4RSx1Q0FBNkIsZ0JBQWU7UUFDaEQsQ0FBQztNQUNMO01BTUEsV0FBVyxRQUFjO0FBQ3JCLGFBQUssU0FBUztBQUNkLFlBQUksS0FBSyxRQUFRO0FBQ2IsZUFBSyxnQkFBZ0I7QUFNckIsZ0JBQU0sU0FBUyxLQUFLLGFBQWEsVUFBVSxLQUFLLGNBQWMsZUFBZSxNQUFNO0FBR25GLGVBQUssWUFBWSxLQUFLLFdBQVcsZ0JBQWdCLG9DQUFvQyxLQUFLLFdBQVcsZUFBZSxNQUFNLElBQUk7QUFHOUgsZUFBSyxpQkFBaUIsQ0FBQTtBQUN0QixlQUFLLFdBQVcsa0JBQWtCLFFBQVEsQ0FBQyxvQkFBbUI7QUFFMUQsaUJBQUssZUFBZSxnQkFBZ0IsYUFBYyxFQUFHLElBQUksb0NBQW9DLGdCQUFnQixlQUFnQixNQUFNO1VBQ3ZJLEdBQUcsSUFBSTs7TUFFZjtNQUtBLHFCQUFrQjtBQUNkLGFBQUssZUFBYztBQUNuQixZQUFJLEtBQUssZUFBZTtBQUNwQixjQUFJLENBQUMsS0FBSyxjQUFjO0FBRXBCLGlCQUFLLFdBQVcsaUJBQWlCLEtBQUssa0JBQWtCLElBQUc7QUFDM0QsaUJBQUssY0FBYyxLQUFLLFVBQVU7QUFDbEMsaUJBQUssaUJBQWlCO0FBQ3RCLGlCQUFLLHFCQUFvQjtpQkFDdEI7QUFDSCxpQkFBSyxpQkFBaUI7OztNQUdsQztNQUtBLHVCQUFvQjtBQUNoQixZQUFJLEtBQUssV0FBVyxnQkFBZ0I7QUFDaEMsY0FBSSxLQUFLLElBQUksTUFBTSxLQUFLLFdBQVcsY0FBYyxFQUFFLEtBQUssS0FBSyxrQkFBa0IsSUFBRyxHQUFJLFNBQVMsQ0FBQyxJQUFJLEdBQUc7QUFDbkcsaUJBQUssWUFBWTtBQUNqQixpQkFBSyxpQkFBZ0I7OztNQUdqQztNQU1BLFlBQVksT0FBYTtBQUNyQixZQUFJLE9BQU87QUFDUCxnQkFBTSxlQUFlLDRCQUE0QjtBQUNqRCxlQUFLLGFBQWEsU0FBUztZQUN2QixNQUFNLFVBQVU7WUFDaEIsU0FBUztZQUNULG9CQUFvQjtXQUN2QjtBQUNELGVBQUssaUJBQWlCO0FBQ3RCLGVBQUssZUFBZTs7TUFFNUI7TUFTQSwwQkFBdUI7QUFDbkIsWUFBSSxDQUFDLEtBQUssYUFBYSxlQUFlO0FBQ2xDLGlCQUFPOztBQUdYLG1CQUFXLFlBQVksS0FBSyxhQUFhLGVBQWU7QUFDcEQsY0FBSSxTQUFTLFNBQVMsaUJBQWlCLGlCQUFpQjtBQUNwRCxrQkFBTSxVQUFVLEtBQUssc0JBQXNCLElBQUksU0FBUyxFQUFHO0FBQzNELGdCQUFJLFdBQVcsUUFBUSxXQUFXLEdBQUc7QUFDakMscUJBQU87O3FCQUVKLFNBQVMsU0FBUyxpQkFBaUIsZUFBZTtBQUN6RCxrQkFBTSxXQUFXLEtBQUssb0JBQW9CLElBQUksU0FBUyxFQUFHO0FBQzFELGdCQUFJLFlBQVksU0FBUyxXQUFXLEdBQUc7QUFDbkMscUJBQU87O3FCQUVKLFNBQVMsU0FBUyxpQkFBaUIsY0FBYztBQUN4RCxrQkFBTSxpQkFBaUIsS0FBSywwQkFBMEIsSUFBSSxTQUFTLEVBQUc7QUFDdEUsZ0JBQUksa0JBQWtCLGVBQWUsV0FBVyxHQUFHO0FBQy9DLHFCQUFPOzs7O0FBS25CLGVBQU87TUFDWDtNQUtBLFdBQVE7QUFDSixjQUFNLHNCQUFzQjtBQUM1QixhQUFLLGVBQWM7QUFDbkIsWUFBSSxnQkFBZ0I7QUFFcEIsWUFBSSxLQUFLLHVCQUF1QixNQUFNLENBQUMsS0FBSyx3QkFBdUIsR0FBSTtBQUNuRSxnQkFBTSxjQUFjLEtBQUssaUJBQWlCLFFBQVEsc0JBQXNCLG1CQUFtQjtBQUMzRiwwQkFBZ0IsT0FBTyxRQUFRLFdBQVc7O0FBRTlDLFlBQUksZUFBZTtBQUNmLGVBQUssZUFBZTtBQUNwQixrQkFBUSxLQUFLLE1BQU07WUFDZixLQUFLO0FBQ0Qsa0JBQUksQ0FBQyxLQUFLLFdBQVcsSUFBSTtBQUNyQixxQkFBSyx5QkFBeUIsa0JBQWtCLEtBQUssWUFBWSxLQUFLLE1BQU0sRUFBRSxVQUFVO2tCQUNwRixNQUFNLENBQUMsYUFBa0M7QUFDckMseUJBQUssaUNBQWlDLFNBQVMsSUFBSztrQkFDeEQ7a0JBQ0EsT0FBTyxDQUFDLFVBQTZCLEtBQUssY0FBYyxLQUFLO2lCQUNoRTs7QUFFTDtZQUNKLEtBQUs7QUFDRCxrQkFBSSxDQUFDLEtBQUssV0FBVyxJQUFJO0FBQ3JCLHFCQUFLLHlCQUF5QixpQkFBaUIsS0FBSyxZQUFZLEtBQUssTUFBTSxFQUFFLFVBQVU7a0JBQ25GLE1BQU0sQ0FBQyxhQUFrQztBQUNyQyx5QkFBSyxpQ0FBaUMsU0FBUyxJQUFLO2tCQUN4RDtrQkFDQSxPQUFPLENBQUMsVUFBNkIsS0FBSyxjQUFjLEtBQUs7aUJBQ2hFOztBQUVMO1lBQ0osS0FBSztBQUVELG9CQUFNLGlCQUFpQixJQUFJLGVBQWM7QUFDekMsNkJBQWUsbUJBQW1CLEtBQUssV0FBVztBQUNsRCxtQkFBSyx5QkFBeUIsa0JBQWtCLGdCQUFnQixLQUFLLE1BQU0sRUFBRSxVQUFVO2dCQUNuRixNQUFNLENBQUMsYUFBMEM7QUFDN0MsdUJBQUssYUFBYSxTQUFTO0FBQzNCLHVCQUFLLGVBQWU7QUFDcEIsdUJBQUsscUJBQW9CO0FBQ3pCLHVCQUFLLGdCQUFlO0FBQ3BCLHNCQUFJLEtBQUssYUFBYSxhQUFhLFNBQVMsY0FBYztBQUN0RCx5QkFBSyxhQUFhLFFBQVEsdUNBQXVDOztnQkFFekU7Z0JBQ0EsT0FBTyxDQUFDLFVBQTZCLEtBQUssY0FBYyxLQUFLO2VBQ2hFO0FBQ0Q7OztNQUdoQjtNQU1BLGlDQUFpQyxRQUFjO0FBQzNDLGFBQUssZUFBZTtBQUNwQixhQUFLLGFBQWEsT0FBTztBQUV6QixjQUFNLGVBQWdCLE9BQU8sY0FBd0M7QUFDckUsYUFBSyxrQ0FBa0MsWUFBWTtBQUNuRCxhQUFLLGdCQUFlO0FBQ3BCLGFBQUssV0FBVyxNQUFNO01BQzFCO01BTUEsY0FBYyxPQUF3QjtBQUNsQyxjQUFNLGVBQWUsMkNBQTJDLE1BQU0sU0FBUyxJQUFJLHNCQUFzQixLQUFLLE1BQU07QUFDcEgsYUFBSyxhQUFhLFNBQVM7VUFDdkIsTUFBTSxVQUFVO1VBQ2hCLFNBQVM7VUFDVCxvQkFBb0I7U0FDdkI7QUFDRCxhQUFLLGVBQWU7TUFDeEI7TUFNQSxtQkFBbUIsZUFBcUI7QUFDcEMsaUJBQVMsZUFBZSxhQUFhLGFBQWEsRUFBRyxlQUFlO1VBQ2hFLFVBQVU7U0FDYjtNQUNMO01BS0EsWUFBWSxVQUFVLE9BQUs7QUFDdkIsYUFBSyxpQkFBaUI7QUFDdEIsYUFBSyxvQkFBb0IsZUFBZSxLQUFLLE1BQU0sRUFBRSxVQUFVO1VBQzNELE1BQU0sQ0FBQyxRQUFtQztBQUN0QyxrQkFBTSxlQUFlLElBQUk7QUFDekIsZ0JBQUksYUFBYSxhQUFhO0FBQzFCLGtCQUFJLGFBQWEsV0FBVztBQUN4QixxQkFBSyxzQkFBc0I7QUFDM0IscUJBQUssVUFBVSxNQUFLOztBQUV4QixtQkFBSyxlQUFlO0FBQ3BCLG1CQUFLLFNBQVE7QUFDYixtQkFBSyxhQUFZOztBQUVyQix1QkFBVyxNQUFPLEtBQUssaUJBQWlCLE9BQVEsR0FBRztVQUN2RDtVQUNBLE9BQU8sTUFBSztBQUNSLHVCQUFXLE1BQU8sS0FBSyxpQkFBaUIsT0FBUSxHQUFHO1VBQ3ZEO1NBQ0g7TUFDTDtNQUVBLFlBQVM7QUFDTCxhQUFLLG9CQUFvQixLQUFLLEtBQUssUUFBUSxLQUFLLFFBQVEsRUFBRSxVQUFVO1VBQ2hFLE1BQU0sQ0FBQyxRQUFnQztBQUNuQyxnQkFBSSxJQUFJLE1BQU07QUFDVixtQkFBSyxZQUFZLElBQUk7QUFDckIsa0JBQUksS0FBSyxXQUFXLFNBQVM7QUFDekIscUJBQUssWUFBVztxQkFDYjtBQUNILHFCQUFLLDZCQUE0Qjs7O1VBRzdDO1VBQ0EsT0FBTyxDQUFDLFVBQTRCO0FBQ2hDLGtCQUFNLGVBQWUsd0NBQXdDLE1BQU0sU0FBUyxJQUFJLHNCQUFzQixLQUFLLE1BQU07QUFDakgsaUJBQUssYUFBYSxTQUFTO2NBQ3ZCLE1BQU0sVUFBVTtjQUNoQixTQUFTO2NBQ1Qsb0JBQW9CO2FBQ3ZCO1VBQ0w7U0FDSDtNQUNMOzt5QkFuNkJTLDZCQUEwQixnQ0FBQSxtQkFBQSxHQUFBLGdDQUFBLG1CQUFBLEdBQUEsZ0NBQUEsb0JBQUEsR0FBQSxnQ0FBQSw2QkFBQSxHQUFBLGdDQUFBLGlCQUFBLEdBQUEsZ0NBQUEsWUFBQSxHQUFBLGdDQUFBLHdCQUFBLEdBQUEsZ0NBQUEsbUJBQUEsR0FBQSxnQ0FBQSxrQkFBQSxHQUFBLGdDQUFBLHdCQUFBLENBQUE7TUFBQTtpRUFBMUIsNkJBQTBCLFdBQUEsQ0FBQSxDQUFBLFVBQUEsQ0FBQSxHQUFBLFdBQUEsU0FBQSxpQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtvQ0FXckIsaUNBQStCLENBQUE7b0NBRy9CLDhCQUE0QixDQUFBO29DQUc1Qiw4QkFBNEIsQ0FBQTs7Ozs7Ozs7cURBcEIvQixDQUFDLG9CQUFvQixDQUFDLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsSUFBQSxHQUFBLENBQUEsR0FBQSxzQkFBQSxHQUFBLENBQUEsUUFBQSxNQUFBLEdBQUEsUUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsV0FBQSxHQUFBLENBQUEsZ0JBQUEsd0NBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsZ0JBQUEsdUNBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsZ0JBQUEsb0NBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsZ0JBQUEsK0NBQUEsR0FBQSxDQUFBLGdCQUFBLCtDQUFBLEdBQUEsQ0FBQSxnQkFBQSxtREFBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxZQUFBLHlCQUFBLGlCQUFBLGlCQUFBLGNBQUEsbUJBQUEsaUJBQUEsdUJBQUEsaUJBQUEsU0FBQSw2QkFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLFlBQUEsWUFBQSxtQkFBQSxpQkFBQSxjQUFBLHVCQUFBLGlCQUFBLFNBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxZQUFBLGtCQUFBLDJCQUFBLGlCQUFBLGNBQUEsdUJBQUEsaUJBQUEsU0FBQSxzQkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEscUJBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLHNCQUFBLEdBQUEsQ0FBQSwrQkFBQSxFQUFBLEdBQUEsQ0FBQSxrQ0FBQSxFQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsYUFBQSxjQUFBLGNBQUEseUJBQUEsNkJBQUEsR0FBQSxjQUFBLFdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxJQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsYUFBQSxjQUFBLGNBQUEseUJBQUEsZ0NBQUEsR0FBQSxjQUFBLFdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxPQUFBLGFBQUEsY0FBQSxjQUFBLHlCQUFBLDZCQUFBLEdBQUEsY0FBQSxXQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxhQUFBLEdBQUEsQ0FBQSxnQkFBQSxtQ0FBQSxHQUFBLENBQUEsZ0JBQUEscUNBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxhQUFBLEdBQUEsQ0FBQSxNQUFBLGdCQUFBLEdBQUEsQ0FBQSxnQkFBQSx5Q0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLE1BQUEsd0JBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxnQkFBQSx5Q0FBQSxHQUFBLENBQUEsYUFBQSxjQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsZ0JBQUEscUNBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxnQkFBQSxxQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLGdCQUFBLFNBQUEsR0FBQSxDQUFBLGdCQUFBLDRDQUFBLEdBQUEsQ0FBQSxnQkFBQSxtQ0FBQSxHQUFBLENBQUEsZ0JBQUEsbUNBQUEsR0FBQSxDQUFBLEdBQUEsd0JBQUEsR0FBQSxDQUFBLGdCQUFBLEVBQUEsR0FBQSxDQUFBLGdCQUFBLDBDQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLGdCQUFBLHNDQUFBLEdBQUEsQ0FBQSxnQkFBQSxxQ0FBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxNQUFBLGNBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxnQkFBQSxzQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLE1BQUEsbUJBQUEsR0FBQSxDQUFBLGdCQUFBLGtDQUFBLEdBQUEsQ0FBQSxNQUFBLGdCQUFBLEdBQUEsV0FBQSxXQUFBLFNBQUEsWUFBQSxRQUFBLFNBQUEsR0FBQSxDQUFBLE1BQUEsZUFBQSxHQUFBLFdBQUEsV0FBQSxTQUFBLFlBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSx3QkFBQSxTQUFBLFlBQUEsR0FBQSxDQUFBLGdCQUFBLHdDQUFBLEdBQUEsQ0FBQSxnQkFBQSw2Q0FBQSxHQUFBLENBQUEsR0FBQSwwQkFBQSxTQUFBLGVBQUEsR0FBQSxDQUFBLGdCQUFBLG1EQUFBLEdBQUEsQ0FBQSxHQUFBLGtDQUFBLFNBQUEsWUFBQSxHQUFBLENBQUEsZ0JBQUEsdURBQUEsR0FBQSxDQUFBLGdCQUFBLGdFQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLGdCQUFBLHdEQUFBLEdBQUEsQ0FBQSxNQUFBLHVCQUFBLEdBQUEsV0FBQSxlQUFBLEdBQUEsQ0FBQSxNQUFBLGNBQUEsR0FBQSxTQUFBLFdBQUEsU0FBQSxHQUFBLENBQUEsZ0JBQUEsbURBQUEsR0FBQSxDQUFBLE1BQUEsZUFBQSxHQUFBLFNBQUEsV0FBQSxTQUFBLEdBQUEsQ0FBQSxnQkFBQSx5REFBQSxHQUFBLENBQUEsZ0JBQUEsMkRBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxvQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQzdDckMsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLG1EQUFBLElBQUEsQ0FBQSxFQWlDQyxHQUFBLG1EQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsbURBQUEsSUFBQSxDQUFBLEVBQUEsR0FBQSxtREFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLG1EQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsbURBQUEsR0FBQSxDQUFBO0FBbVRELFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLENBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBelZLLFVBQUEseUJBQUEsTUFBQSxlQUFBLElBQUEsZ0JBQUEsT0FBQSxPQUFBLElBQUEsYUFBQSxHQUFBO0FBQ0QsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsZUFBQSxJQUFBLEVBQUE7QUFrQ0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsZUFBQSxJQUFBLEVBQUE7QUF1REEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsZUFBQSxJQUFBLEVBQUE7QUEyTUEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLENBQUEsSUFBQSx1QkFBQSxDQUFBLElBQUEsaUJBQUEsQ0FBQSxJQUFBLFdBQUEsYUFBQSxJQUFBLHVCQUFBLElBQUEsSUFBQSxFQUFBO0FBVUEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLENBQUEsSUFBQSx1QkFBQSxJQUFBLFdBQUEsYUFBQSxDQUFBLElBQUEsa0JBQUEsSUFBQSxnQkFBQSxPQUFBLE9BQUEsSUFBQSxhQUFBLGNBQUEsSUFBQSxTQUFBLGVBQUEsSUFBQSxFQUFBO0FBS0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsc0JBQUEsSUFBQSxFQUFBO0FBaUNrQyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLFVBQUEsSUFBQSxjQUFBO0FBQ1gsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsYUFBQSxFQUFzQixRQUFBLElBQUE7Ozs7O3FGRHRTcEMsNEJBQTBCLEVBQUEsV0FBQSw2QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUU5Q3ZDLElBR2E7QUFIYjs7O0FBQ0E7QUFFTyxJQUFNLHlCQUFpQztNQUMxQztRQUNJLE1BQU07UUFDTixXQUFXO1FBQ1gsTUFBTTtVQUNGLGFBQWEsQ0FBQTtVQUNiLFdBQVc7VUFDWCxNQUFNOztRQUVWLGFBQWEsQ0FBQyxzQkFBc0I7O01BRXhDO1FBQ0ksTUFBTTtRQUNOLFdBQVc7UUFDWCxNQUFNO1VBQ0YsYUFBYSxDQUFBO1VBQ2IsV0FBVztVQUNYLE1BQU07O1FBRVYsYUFBYSxDQUFDLHNCQUFzQjs7Ozs7OztBQ3hCNUMsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxvQkFBb0I7O0FBRDdCLElBWWE7QUFaYjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTU0sSUFBTyxpQ0FBUCxNQUFPLGdDQUE4Qjs7eUJBQTlCLGlDQUE4QjtNQUFBO2dFQUE5QixnQ0FBOEIsQ0FBQTtvRUFIN0IscUJBQXFCLGFBQWEsU0FBUyxzQkFBc0IsR0FBRyw4QkFBOEIsOEJBQThCLEVBQUEsQ0FBQTs7OzsiLCJuYW1lcyI6W119