import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NI5XS6XH.js?v=b97f8625";

// node_modules/dayjs/esm/plugin/isSameOrBefore/index.js
var isSameOrBefore_default = function(o, c) {
  c.prototype.isSameOrBefore = function(that, units) {
    return this.isSame(that, units) || this.isBefore(that, units);
  };
};
export {
  isSameOrBefore_default as default
};
//# sourceMappingURL=dayjs_esm_plugin_isSameOrBefore.js.map
