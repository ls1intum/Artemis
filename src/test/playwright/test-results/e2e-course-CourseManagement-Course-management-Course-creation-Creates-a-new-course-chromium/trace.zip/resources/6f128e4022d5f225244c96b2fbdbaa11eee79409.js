import {
  nil_default,
  parse_default,
  stringify_default,
  v1_default,
  v3_default,
  v4_default,
  v5_default,
  validate_default,
  version_default
} from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-T4VHK35S.js?v=b97f8625";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NI5XS6XH.js?v=b97f8625";
export {
  nil_default as NIL,
  parse_default as parse,
  stringify_default as stringify,
  v1_default as v1,
  v3_default as v3,
  v4_default as v4,
  v5_default as v5,
  validate_default as validate,
  version_default as version
};
//# sourceMappingURL=uuid.js.map
