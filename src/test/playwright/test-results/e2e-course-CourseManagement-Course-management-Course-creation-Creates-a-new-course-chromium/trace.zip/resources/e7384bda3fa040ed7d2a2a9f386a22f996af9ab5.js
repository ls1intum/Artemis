import {
  ArtemisComplaintsModule,
  init_complaints_module
} from "/chunk-YXA3WNWK.js";
import {
  RatingModule,
  init_rating_module
} from "/chunk-HPI3PUA5.js";
import {
  ArtemisSidePanelModule,
  init_side_panel_module
} from "/chunk-6HPWWGFU.js";
import {
  ArtemisCourseExerciseRowModule,
  ArtemisExerciseButtonsModule,
  CourseExercisesGroupedByTimeframeComponent,
  CourseExercisesGroupedByWeekComponent,
  init_course_exercise_row_module,
  init_course_exercises_grouped_by_timeframe_component,
  init_course_exercises_grouped_by_week_component,
  init_exercise_buttons_module
} from "/chunk-O2UXKYID.js";
import {
  OrionModule,
  init_orion_module
} from "/chunk-ZVM6GU35.js";
import {
  ArtemisHeaderExercisePageWithDetailsModule,
  init_exercise_headers_module
} from "/chunk-YH2LEYJ2.js";
import {
  ArtemisCoursesRoutingModule,
  CourseExercisesComponent,
  FeatureToggleModule,
  init_course_card_component,
  init_course_exercises_component,
  init_course_lecture_row_component,
  init_course_lectures_component,
  init_course_overview_component,
  init_course_unenrollment_modal_component,
  init_courses_component,
  init_courses_routing_module,
  init_feature_toggle_module,
  init_header_course_component
} from "/chunk-ORYTP7RT.js";
import {
  SidePanelComponent,
  init_side_panel_component
} from "/chunk-H46RESQY.js";
import {
  ArtemisDatePipe,
  ArtemisSharedModule,
  ArtemisSharedPipesModule,
  ArtemisTranslatePipe,
  TranslateDirective,
  __esm,
  init_artemis_date_pipe,
  init_artemis_translate_pipe,
  init_shared_module,
  init_shared_pipes_module,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/overview/courses.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgxChartsModule, PieChartModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i6 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i9 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
var ArtemisCoursesModule;
var init_courses_module = __esm({
  "src/main/webapp/app/overview/courses.module.ts"() {
    init_shared_module();
    init_side_panel_module();
    init_course_lecture_row_component();
    init_orion_module();
    init_feature_toggle_module();
    init_course_card_component();
    init_course_overview_component();
    init_exercise_headers_module();
    init_course_exercises_component();
    init_courses_component();
    init_complaints_module();
    init_course_lectures_component();
    init_courses_routing_module();
    init_shared_pipes_module();
    init_rating_module();
    init_exercise_buttons_module();
    init_course_exercise_row_module();
    init_header_course_component();
    init_course_unenrollment_modal_component();
    init_course_exercises_grouped_by_week_component();
    init_course_exercises_grouped_by_timeframe_component();
    init_translate_directive();
    init_side_panel_component();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    ArtemisCoursesModule = class _ArtemisCoursesModule {
      static \u0275fac = function ArtemisCoursesModule_Factory(t) {
        return new (t || _ArtemisCoursesModule)();
      };
      static \u0275mod = i0.\u0275\u0275defineNgModule({ type: _ArtemisCoursesModule });
      static \u0275inj = i0.\u0275\u0275defineInjector({ imports: [
        ArtemisExerciseButtonsModule,
        ArtemisCourseExerciseRowModule,
        ArtemisSharedModule,
        ArtemisSharedPipesModule,
        ArtemisSidePanelModule,
        ArtemisCoursesRoutingModule,
        ArtemisHeaderExercisePageWithDetailsModule,
        OrionModule,
        ArtemisComplaintsModule,
        FeatureToggleModule,
        RatingModule,
        NgxChartsModule,
        PieChartModule
      ] });
    };
    i0.\u0275\u0275setComponentScope(CourseExercisesComponent, [CourseExercisesGroupedByWeekComponent, CourseExercisesGroupedByTimeframeComponent, i3.DefaultValueAccessor, i3.NgControlStatus, i3.NgModel, i4.NgClass, i5.NgbDropdown, i5.NgbDropdownToggle, i5.NgbDropdownMenu, i6.FaIconComponent, TranslateDirective, SidePanelComponent, i9.RouterLink], [i4.KeyValuePipe, ArtemisDatePipe, ArtemisTranslatePipe]);
  }
});

export {
  ArtemisCoursesModule,
  init_courses_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvb3ZlcnZpZXcvY291cnNlcy5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NpZGVQYW5lbE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2lkZS1wYW5lbC9zaWRlLXBhbmVsLm1vZHVsZSc7XG5pbXBvcnQgeyBDb3Vyc2VMZWN0dXJlUm93Q29tcG9uZW50IH0gZnJvbSAnYXBwL292ZXJ2aWV3L2NvdXJzZS1sZWN0dXJlcy9jb3Vyc2UtbGVjdHVyZS1yb3cuY29tcG9uZW50JztcbmltcG9ydCB7IE9yaW9uTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9vcmlvbi9vcmlvbi5tb2R1bGUnO1xuaW1wb3J0IHsgRmVhdHVyZVRvZ2dsZU1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvZmVhdHVyZS10b2dnbGUvZmVhdHVyZS10b2dnbGUubW9kdWxlJztcbmltcG9ydCB7IENvdXJzZUNhcmRDb21wb25lbnQgfSBmcm9tICdhcHAvb3ZlcnZpZXcvY291cnNlLWNhcmQuY29tcG9uZW50JztcbmltcG9ydCB7IENvdXJzZU92ZXJ2aWV3Q29tcG9uZW50IH0gZnJvbSAnYXBwL292ZXJ2aWV3L2NvdXJzZS1vdmVydmlldy5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc0hlYWRlckV4ZXJjaXNlUGFnZVdpdGhEZXRhaWxzTW9kdWxlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhlcmNpc2UtaGVhZGVycy9leGVyY2lzZS1oZWFkZXJzLm1vZHVsZSc7XG5pbXBvcnQgeyBDb3Vyc2VFeGVyY2lzZXNDb21wb25lbnQgfSBmcm9tICdhcHAvb3ZlcnZpZXcvY291cnNlLWV4ZXJjaXNlcy9jb3Vyc2UtZXhlcmNpc2VzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDb3Vyc2VzQ29tcG9uZW50IH0gZnJvbSAnYXBwL292ZXJ2aWV3L2NvdXJzZXMuY29tcG9uZW50JztcbmltcG9ydCB7IEFydGVtaXNDb21wbGFpbnRzTW9kdWxlIH0gZnJvbSAnYXBwL2NvbXBsYWludHMvY29tcGxhaW50cy5tb2R1bGUnO1xuaW1wb3J0IHsgQ291cnNlTGVjdHVyZXNDb21wb25lbnQgfSBmcm9tICdhcHAvb3ZlcnZpZXcvY291cnNlLWxlY3R1cmVzL2NvdXJzZS1sZWN0dXJlcy5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc0NvdXJzZXNSb3V0aW5nTW9kdWxlIH0gZnJvbSAnYXBwL292ZXJ2aWV3L2NvdXJzZXMtcm91dGluZy5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZFBpcGVzTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9waXBlcy9zaGFyZWQtcGlwZXMubW9kdWxlJztcbmltcG9ydCB7IFJhdGluZ01vZHVsZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3JhdGluZy9yYXRpbmcubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNFeGVyY2lzZUJ1dHRvbnNNb2R1bGUgfSBmcm9tICdhcHAvb3ZlcnZpZXcvZXhlcmNpc2UtZGV0YWlscy9leGVyY2lzZS1idXR0b25zLm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzQ291cnNlRXhlcmNpc2VSb3dNb2R1bGUgfSBmcm9tICdhcHAvb3ZlcnZpZXcvY291cnNlLWV4ZXJjaXNlcy9jb3Vyc2UtZXhlcmNpc2Utcm93Lm1vZHVsZSc7XG5pbXBvcnQgeyBOZ3hDaGFydHNNb2R1bGUsIFBpZUNoYXJ0TW9kdWxlIH0gZnJvbSAnQHN3aW1sYW5lL25neC1jaGFydHMnO1xuaW1wb3J0IHsgSGVhZGVyQ291cnNlQ29tcG9uZW50IH0gZnJvbSAnYXBwL292ZXJ2aWV3L2hlYWRlci1jb3Vyc2UuY29tcG9uZW50JztcbmltcG9ydCB7IENvdXJzZVVuZW5yb2xsbWVudE1vZGFsQ29tcG9uZW50IH0gZnJvbSAnYXBwL292ZXJ2aWV3L2NvdXJzZS11bmVucm9sbG1lbnQtbW9kYWwuY29tcG9uZW50JztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbXG4gICAgICAgIEFydGVtaXNFeGVyY2lzZUJ1dHRvbnNNb2R1bGUsXG4gICAgICAgIEFydGVtaXNDb3Vyc2VFeGVyY2lzZVJvd01vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc1NoYXJlZE1vZHVsZSxcbiAgICAgICAgQXJ0ZW1pc1NoYXJlZFBpcGVzTW9kdWxlLFxuICAgICAgICBBcnRlbWlzU2lkZVBhbmVsTW9kdWxlLFxuICAgICAgICBBcnRlbWlzQ291cnNlc1JvdXRpbmdNb2R1bGUsXG4gICAgICAgIEFydGVtaXNIZWFkZXJFeGVyY2lzZVBhZ2VXaXRoRGV0YWlsc01vZHVsZSxcbiAgICAgICAgT3Jpb25Nb2R1bGUsXG4gICAgICAgIEFydGVtaXNDb21wbGFpbnRzTW9kdWxlLFxuICAgICAgICBGZWF0dXJlVG9nZ2xlTW9kdWxlLFxuICAgICAgICBSYXRpbmdNb2R1bGUsXG4gICAgICAgIE5neENoYXJ0c01vZHVsZSxcbiAgICAgICAgUGllQ2hhcnRNb2R1bGUsXG4gICAgXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtcbiAgICAgICAgQ291cnNlc0NvbXBvbmVudCxcbiAgICAgICAgQ291cnNlT3ZlcnZpZXdDb21wb25lbnQsXG4gICAgICAgIEhlYWRlckNvdXJzZUNvbXBvbmVudCxcbiAgICAgICAgQ291cnNlQ2FyZENvbXBvbmVudCxcbiAgICAgICAgQ291cnNlRXhlcmNpc2VzQ29tcG9uZW50LFxuICAgICAgICBDb3Vyc2VMZWN0dXJlc0NvbXBvbmVudCxcbiAgICAgICAgQ291cnNlTGVjdHVyZVJvd0NvbXBvbmVudCxcbiAgICAgICAgQ291cnNlVW5lbnJvbGxtZW50TW9kYWxDb21wb25lbnQsXG4gICAgXSxcbiAgICBleHBvcnRzOiBbSGVhZGVyQ291cnNlQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc0NvdXJzZXNNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsZ0JBQWdCO0FBa0J6QixTQUFTLGlCQUFpQixzQkFBc0I7Ozs7Ozs7QUFsQmhELElBa0RhO0FBbERiOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOzs7Ozs7O0FBOEJNLElBQU8sdUJBQVAsTUFBTyxzQkFBb0I7O3lCQUFwQix1QkFBb0I7TUFBQTsrREFBcEIsc0JBQW9CLENBQUE7O1FBMUJ6QjtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtNQUFjLEVBQUEsQ0FBQTs7cUNBT2QsMEJBQXdCLENBQUEsdUNBQUEsNENBQUEseUJBQUEsb0JBQUEsWUFBQSxZQUFBLGdCQUFBLHNCQUFBLG9CQUFBLG9CQUFBLG9CQUFBLG9CQUFBLGFBQUEsR0FBQSxDQUFBLGlCQUFBLGlCQUFBLG9CQUFBLENBQUE7OzsiLCJuYW1lcyI6W119