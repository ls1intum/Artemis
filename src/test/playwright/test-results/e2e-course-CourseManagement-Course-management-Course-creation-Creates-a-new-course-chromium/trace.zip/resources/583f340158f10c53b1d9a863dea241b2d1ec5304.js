import {
  AssessmentObject,
  AssessmentTaskTourStep,
  GuidedTourAssessmentTask,
  Orientation,
  ResetParticipation,
  TextTourStep,
  UserInterActionTourStep,
  UserInteractionEvent,
  init_guided_tour_constants,
  init_guided_tour_step_model,
  init_guided_tour_task_model
} from "/chunk-ORYTP7RT.js";
import {
  init_global_utils,
  onError
} from "/chunk-LW4WH7EZ.js";
import {
  Authority,
  __esm,
  init_authority_constants
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/guided-tour/tours/tutor-assessment-tour.ts
var tutorAssessmentTour;
var init_tutor_assessment_tour = __esm({
  "src/main/webapp/app/guided-tour/tours/tutor-assessment-tour.ts"() {
    init_guided_tour_step_model();
    init_guided_tour_constants();
    init_guided_tour_task_model();
    init_authority_constants();
    tutorAssessmentTour = {
      settingsKey: "tutor_assessment_tour",
      resetParticipation: ResetParticipation.TUTOR_ASSESSMENT,
      steps: [
        new UserInterActionTourStep({
          highlightSelector: ".guided-tour-assessment-dashboard-btn",
          headlineTranslateKey: "tour.courseAdministration.assessmentDashboardButton.headline",
          contentTranslateKey: "tour.courseAdministration.assessmentDashboardButton.content",
          highlightPadding: 10,
          orientation: Orientation.TOPLEFT,
          permission: [Authority.TA],
          pageUrl: "/course-management",
          userInteractionEvent: UserInteractionEvent.CLICK
        }),
        new TextTourStep({
          highlightSelector: ".guided-tour-assessment-stats",
          headlineTranslateKey: "tour.assessmentDashboard.overview.headline",
          contentTranslateKey: "tour.assessmentDashboard.overview.content",
          highlightPadding: 10,
          orientation: Orientation.TOP,
          permission: [Authority.TA],
          pageUrl: "/course-management/(\\d+)+/assessment-dashboard"
        }),
        new TextTourStep({
          highlightSelector: ".guided-tour-form-check",
          headlineTranslateKey: "tour.assessmentDashboard.showFinished.headline",
          contentTranslateKey: "tour.assessmentDashboard.showFinished.content",
          highlightPadding: 10,
          orientation: Orientation.TOPLEFT,
          permission: [Authority.TA]
        }),
        new TextTourStep({
          highlightSelector: ".guided-tour-exercise-table",
          headlineTranslateKey: "tour.assessmentDashboard.exerciseTable.headline",
          contentTranslateKey: "tour.assessmentDashboard.exerciseTable.content",
          highlightPadding: 25,
          orientation: Orientation.TOP,
          permission: [Authority.TA]
        }),
        new TextTourStep({
          highlightSelector: "jhi-tutor-participation-graph.guided-tour",
          headlineTranslateKey: "tour.assessmentDashboard.gradingProcess.headline",
          contentTranslateKey: "tour.assessmentDashboard.gradingProcess.content",
          highlightPadding: 10,
          orientation: Orientation.TOP,
          permission: [Authority.TA]
        }),
        new UserInterActionTourStep({
          highlightSelector: ".btn.guided-tour",
          headlineTranslateKey: "tour.assessmentDashboard.exerciseDashboardButton.headline",
          contentTranslateKey: "tour.assessmentDashboard.exerciseDashboardButton.content",
          highlightPadding: 10,
          orientation: Orientation.TOPRIGHT,
          permission: [Authority.TA],
          userInteractionEvent: UserInteractionEvent.CLICK
        }),
        new TextTourStep({
          highlightSelector: ".guided-tour-markdown-preview",
          headlineTranslateKey: "tour.exerciseAssessmentDashboard.instructions.headline",
          contentTranslateKey: "tour.exerciseAssessmentDashboard.instructions.content",
          highlightPadding: 10,
          orientation: Orientation.TOP,
          permission: [Authority.TA],
          pageUrl: "/course-management/(\\d+)+/assessment-dashboard/(\\d+)+"
        }),
        new UserInterActionTourStep({
          highlightSelector: ".guided-tour-instructions-button",
          headlineTranslateKey: "tour.exerciseAssessmentDashboard.instructionsButton.headline",
          contentTranslateKey: "tour.exerciseAssessmentDashboard.instructionsButton.content",
          highlightPadding: 10,
          orientation: Orientation.TOP,
          permission: [Authority.TA],
          userInteractionEvent: UserInteractionEvent.CLICK,
          triggerNextStep: true
        }),
        new UserInterActionTourStep({
          highlightSelector: ".review-example-submission.guided-tour",
          headlineTranslateKey: "tour.exerciseAssessmentDashboard.readExampleSubmission.headline",
          contentTranslateKey: "tour.exerciseAssessmentDashboard.readExampleSubmission.content",
          highlightPadding: 10,
          orientation: Orientation.TOPLEFT,
          userInteractionEvent: UserInteractionEvent.CLICK,
          permission: [Authority.TA]
        }),
        new TextTourStep({
          highlightSelector: ".guided-tour-assessment-editor",
          headlineTranslateKey: "tour.exampleRead.readSubmission.headline",
          contentTranslateKey: "tour.exampleRead.readSubmission.content",
          orientation: Orientation.TOP,
          permission: [Authority.TA],
          pageUrl: "course-management/(\\d+)+/text-exercises/(\\d+)+/example-submissions/(\\d+)+?readOnly=true"
        }),
        new TextTourStep({
          highlightSelector: ".guided-tour-text-assessment",
          headlineTranslateKey: "tour.exampleRead.readAssessment.headline",
          contentTranslateKey: "tour.exampleRead.readAssessment.content",
          orientation: Orientation.TOP,
          permission: [Authority.TA]
        }),
        new UserInterActionTourStep({
          highlightSelector: "jhi-example-text-submission .guided-tour-read",
          headlineTranslateKey: "tour.exampleRead.confirm.headline",
          contentTranslateKey: "tour.exampleRead.confirm.content",
          userInteractionEvent: UserInteractionEvent.CLICK,
          orientation: Orientation.TOPRIGHT,
          highlightPadding: 10,
          permission: [Authority.TA]
        }),
        new UserInterActionTourStep({
          highlightSelector: ".assess-example-submission.guided-tour",
          headlineTranslateKey: "tour.exerciseAssessmentDashboard.assessExampleSubmission.headline",
          contentTranslateKey: "tour.exerciseAssessmentDashboard.assessExampleSubmission.content",
          highlightPadding: 10,
          orientation: Orientation.TOPLEFT,
          userInteractionEvent: UserInteractionEvent.CLICK,
          permission: [Authority.TA],
          pageUrl: "/course-management/(\\d+)+/assessment-dashboard/(\\d+)+"
        }),
        new AssessmentTaskTourStep({
          highlightSelector: ".guided-tour-complete-assessment-editor",
          headlineTranslateKey: "tour.exampleAssessment.addAssessment.headline",
          contentTranslateKey: "tour.exampleAssessment.addAssessment.content",
          orientation: Orientation.TOP,
          highlightPadding: 10,
          permission: [Authority.TA],
          userInteractionEvent: UserInteractionEvent.ASSESS_SUBMISSION,
          assessmentTask: new GuidedTourAssessmentTask("tour.exampleAssessment.addAssessment.task", new AssessmentObject(3, 0)),
          pageUrl: "course-management/(\\d+)+/text-exercises/(\\d+)+/example-submissions/(\\d+)+?toComplete=true"
        }),
        new AssessmentTaskTourStep({
          highlightSelector: ".guided-tour-assessment-editor",
          headlineTranslateKey: "tour.exampleAssessment.addScore.headline",
          contentTranslateKey: "tour.exampleAssessment.addScore.content",
          userInteractionEvent: UserInteractionEvent.ASSESS_SUBMISSION,
          orientation: Orientation.TOP,
          highlightPadding: 10,
          permission: [Authority.TA],
          assessmentTask: new GuidedTourAssessmentTask("tour.exampleAssessment.addScore.task", new AssessmentObject(3, 3))
        }),
        new UserInterActionTourStep({
          highlightSelector: "jhi-example-text-submission .guided-tour-check-assessment",
          headlineTranslateKey: "tour.exampleAssessment.submit.headline",
          contentTranslateKey: "tour.exampleAssessment.submit.content",
          orientation: Orientation.TOPRIGHT,
          highlightPadding: 10,
          userInteractionEvent: UserInteractionEvent.CLICK,
          permission: [Authority.TA]
        }),
        new UserInterActionTourStep({
          highlightSelector: "jhi-example-text-submission .guided-tour-back",
          headlineTranslateKey: "tour.exampleAssessment.back.headline",
          contentTranslateKey: "tour.exampleAssessment.back.content",
          orientation: Orientation.RIGHT,
          highlightPadding: 10,
          userInteractionEvent: UserInteractionEvent.CLICK,
          permission: [Authority.TA]
        }),
        new TextTourStep({
          highlightSelector: ".guided-tour-exercise-dashboard-table",
          headlineTranslateKey: "tour.exerciseAssessmentDashboard.submissionsAndComplaints.headline",
          contentTranslateKey: "tour.exerciseAssessmentDashboard.submissionsAndComplaints.content",
          highlightPadding: 10,
          orientation: Orientation.TOP,
          permission: [Authority.TA],
          pageUrl: "/course-management/(\\d+)+/assessment-dashboard/(\\d+)+"
        }),
        new TextTourStep({
          highlightSelector: ".guided-tour-new-assessment-btn",
          headlineTranslateKey: "tour.exerciseAssessmentDashboard.assessSubmissions.headline",
          contentTranslateKey: "tour.exerciseAssessmentDashboard.assessSubmissions.content",
          highlightPadding: 10,
          orientation: Orientation.TOP,
          permission: [Authority.TA]
        })
      ]
    };
  }
});

// src/main/webapp/app/entities/example-submission.model.ts
var ExampleSubmission, ExampleSubmissionMode;
var init_example_submission_model = __esm({
  "src/main/webapp/app/entities/example-submission.model.ts"() {
    ExampleSubmission = class {
      id;
      usedForTutorial;
      exercise;
      submission;
      tutorParticipations;
      assessmentExplanation;
      constructor() {
      }
    };
    (function(ExampleSubmissionMode2) {
      ExampleSubmissionMode2["READ_AND_CONFIRM"] = "readConfirm";
      ExampleSubmissionMode2["ASSESS_CORRECTLY"] = "assessCorrectly";
    })(ExampleSubmissionMode || (ExampleSubmissionMode = {}));
  }
});

// src/main/webapp/app/exercises/shared/example-submission/example-submission-assess-command.ts
var ExampleSubmissionAssessCommand;
var init_example_submission_assess_command = __esm({
  "src/main/webapp/app/exercises/shared/example-submission/example-submission-assess-command.ts"() {
    init_global_utils();
    ExampleSubmissionAssessCommand = class {
      tutorParticipationService;
      alertService;
      feedbackMarker;
      constructor(tutorParticipationService, alertService, feedbackMarker) {
        this.tutorParticipationService = tutorParticipationService;
        this.alertService = alertService;
        this.feedbackMarker = feedbackMarker;
      }
      assessExampleSubmission(exampleSubmission, exerciseId) {
        this.tutorParticipationService.assessExampleSubmission(exampleSubmission, exerciseId).subscribe({
          next: () => this.onSuccess(),
          error: (error) => this.onFailure(error)
        });
      }
      onSuccess() {
        this.feedbackMarker.markAllFeedbackToCorrect();
        this.alertService.success("artemisApp.exampleSubmission.correctTutorAssessment");
      }
      onFailure(error) {
        const errorType = error.headers.get("x-artemisapp-error");
        if (errorType === "error.invalid_assessment") {
          this.feedbackMarker.markAllFeedbackToCorrect();
          const correctionErrors = JSON.parse(error["error"]["title"])["errors"];
          this.feedbackMarker.markWrongFeedback(correctionErrors);
          const msg = correctionErrors.length === 0 ? "artemisApp.exampleSubmission.submissionValidation.missing" : "artemisApp.exampleSubmission.submissionValidation.wrong";
          this.alertService.error(msg, { mistakeCount: correctionErrors.length });
        } else {
          onError(this.alertService, error);
        }
      }
    };
  }
});

export {
  tutorAssessmentTour,
  init_tutor_assessment_tour,
  ExampleSubmission,
  ExampleSubmissionMode,
  init_example_submission_model,
  ExampleSubmissionAssessCommand,
  init_example_submission_assess_command
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZ3VpZGVkLXRvdXIvdG91cnMvdHV0b3ItYXNzZXNzbWVudC10b3VyLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9leGFtcGxlLXN1Ym1pc3Npb24ubW9kZWwudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhhbXBsZS1zdWJtaXNzaW9uL2V4YW1wbGUtc3VibWlzc2lvbi1hc3Nlc3MtY29tbWFuZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHdWlkZWRUb3VyIH0gZnJvbSAnYXBwL2d1aWRlZC10b3VyL2d1aWRlZC10b3VyLm1vZGVsJztcbmltcG9ydCB7IEFzc2Vzc21lbnRUYXNrVG91clN0ZXAsIFRleHRUb3VyU3RlcCwgVXNlckludGVyQWN0aW9uVG91clN0ZXAgfSBmcm9tICdhcHAvZ3VpZGVkLXRvdXIvZ3VpZGVkLXRvdXItc3RlcC5tb2RlbCc7XG5pbXBvcnQgeyBPcmllbnRhdGlvbiwgUmVzZXRQYXJ0aWNpcGF0aW9uLCBVc2VySW50ZXJhY3Rpb25FdmVudCB9IGZyb20gJ2FwcC9ndWlkZWQtdG91ci9ndWlkZWQtdG91ci5jb25zdGFudHMnO1xuaW1wb3J0IHsgQXNzZXNzbWVudE9iamVjdCwgR3VpZGVkVG91ckFzc2Vzc21lbnRUYXNrIH0gZnJvbSAnYXBwL2d1aWRlZC10b3VyL2d1aWRlZC10b3VyLXRhc2subW9kZWwnO1xuaW1wb3J0IHsgQXV0aG9yaXR5IH0gZnJvbSAnYXBwL3NoYXJlZC9jb25zdGFudHMvYXV0aG9yaXR5LmNvbnN0YW50cyc7XG5cbmV4cG9ydCBjb25zdCB0dXRvckFzc2Vzc21lbnRUb3VyOiBHdWlkZWRUb3VyID0ge1xuICAgIHNldHRpbmdzS2V5OiAndHV0b3JfYXNzZXNzbWVudF90b3VyJyxcbiAgICByZXNldFBhcnRpY2lwYXRpb246IFJlc2V0UGFydGljaXBhdGlvbi5UVVRPUl9BU1NFU1NNRU5ULFxuICAgIHN0ZXBzOiBbXG4gICAgICAgIC8vIHN0ZXAgMVxuICAgICAgICBuZXcgVXNlckludGVyQWN0aW9uVG91clN0ZXAoe1xuICAgICAgICAgICAgaGlnaGxpZ2h0U2VsZWN0b3I6ICcuZ3VpZGVkLXRvdXItYXNzZXNzbWVudC1kYXNoYm9hcmQtYnRuJyxcbiAgICAgICAgICAgIGhlYWRsaW5lVHJhbnNsYXRlS2V5OiAndG91ci5jb3Vyc2VBZG1pbmlzdHJhdGlvbi5hc3Nlc3NtZW50RGFzaGJvYXJkQnV0dG9uLmhlYWRsaW5lJyxcbiAgICAgICAgICAgIGNvbnRlbnRUcmFuc2xhdGVLZXk6ICd0b3VyLmNvdXJzZUFkbWluaXN0cmF0aW9uLmFzc2Vzc21lbnREYXNoYm9hcmRCdXR0b24uY29udGVudCcsXG4gICAgICAgICAgICBoaWdobGlnaHRQYWRkaW5nOiAxMCxcbiAgICAgICAgICAgIG9yaWVudGF0aW9uOiBPcmllbnRhdGlvbi5UT1BMRUZULFxuICAgICAgICAgICAgcGVybWlzc2lvbjogW0F1dGhvcml0eS5UQV0sXG4gICAgICAgICAgICBwYWdlVXJsOiAnL2NvdXJzZS1tYW5hZ2VtZW50JyxcbiAgICAgICAgICAgIHVzZXJJbnRlcmFjdGlvbkV2ZW50OiBVc2VySW50ZXJhY3Rpb25FdmVudC5DTElDSyxcbiAgICAgICAgfSksXG4gICAgICAgIC8vIHN0ZXAgMlxuICAgICAgICAvLyBuZXcgcGFnZVxuICAgICAgICBuZXcgVGV4dFRvdXJTdGVwKHtcbiAgICAgICAgICAgIGhpZ2hsaWdodFNlbGVjdG9yOiAnLmd1aWRlZC10b3VyLWFzc2Vzc21lbnQtc3RhdHMnLFxuICAgICAgICAgICAgaGVhZGxpbmVUcmFuc2xhdGVLZXk6ICd0b3VyLmFzc2Vzc21lbnREYXNoYm9hcmQub3ZlcnZpZXcuaGVhZGxpbmUnLFxuICAgICAgICAgICAgY29udGVudFRyYW5zbGF0ZUtleTogJ3RvdXIuYXNzZXNzbWVudERhc2hib2FyZC5vdmVydmlldy5jb250ZW50JyxcbiAgICAgICAgICAgIGhpZ2hsaWdodFBhZGRpbmc6IDEwLFxuICAgICAgICAgICAgb3JpZW50YXRpb246IE9yaWVudGF0aW9uLlRPUCxcbiAgICAgICAgICAgIHBlcm1pc3Npb246IFtBdXRob3JpdHkuVEFdLFxuICAgICAgICAgICAgcGFnZVVybDogJy9jb3Vyc2UtbWFuYWdlbWVudC8oXFxcXGQrKSsvYXNzZXNzbWVudC1kYXNoYm9hcmQnLFxuICAgICAgICB9KSxcbiAgICAgICAgLy8gc3RlcCAzXG4gICAgICAgIG5ldyBUZXh0VG91clN0ZXAoe1xuICAgICAgICAgICAgaGlnaGxpZ2h0U2VsZWN0b3I6ICcuZ3VpZGVkLXRvdXItZm9ybS1jaGVjaycsXG4gICAgICAgICAgICBoZWFkbGluZVRyYW5zbGF0ZUtleTogJ3RvdXIuYXNzZXNzbWVudERhc2hib2FyZC5zaG93RmluaXNoZWQuaGVhZGxpbmUnLFxuICAgICAgICAgICAgY29udGVudFRyYW5zbGF0ZUtleTogJ3RvdXIuYXNzZXNzbWVudERhc2hib2FyZC5zaG93RmluaXNoZWQuY29udGVudCcsXG4gICAgICAgICAgICBoaWdobGlnaHRQYWRkaW5nOiAxMCxcbiAgICAgICAgICAgIG9yaWVudGF0aW9uOiBPcmllbnRhdGlvbi5UT1BMRUZULFxuICAgICAgICAgICAgcGVybWlzc2lvbjogW0F1dGhvcml0eS5UQV0sXG4gICAgICAgIH0pLFxuICAgICAgICAvLyBzdGVwIDRcbiAgICAgICAgbmV3IFRleHRUb3VyU3RlcCh7XG4gICAgICAgICAgICBoaWdobGlnaHRTZWxlY3RvcjogJy5ndWlkZWQtdG91ci1leGVyY2lzZS10YWJsZScsXG4gICAgICAgICAgICBoZWFkbGluZVRyYW5zbGF0ZUtleTogJ3RvdXIuYXNzZXNzbWVudERhc2hib2FyZC5leGVyY2lzZVRhYmxlLmhlYWRsaW5lJyxcbiAgICAgICAgICAgIGNvbnRlbnRUcmFuc2xhdGVLZXk6ICd0b3VyLmFzc2Vzc21lbnREYXNoYm9hcmQuZXhlcmNpc2VUYWJsZS5jb250ZW50JyxcbiAgICAgICAgICAgIGhpZ2hsaWdodFBhZGRpbmc6IDI1LFxuICAgICAgICAgICAgb3JpZW50YXRpb246IE9yaWVudGF0aW9uLlRPUCxcbiAgICAgICAgICAgIHBlcm1pc3Npb246IFtBdXRob3JpdHkuVEFdLFxuICAgICAgICB9KSxcbiAgICAgICAgLy8gc3RlcCA1XG4gICAgICAgIG5ldyBUZXh0VG91clN0ZXAoe1xuICAgICAgICAgICAgaGlnaGxpZ2h0U2VsZWN0b3I6ICdqaGktdHV0b3ItcGFydGljaXBhdGlvbi1ncmFwaC5ndWlkZWQtdG91cicsXG4gICAgICAgICAgICBoZWFkbGluZVRyYW5zbGF0ZUtleTogJ3RvdXIuYXNzZXNzbWVudERhc2hib2FyZC5ncmFkaW5nUHJvY2Vzcy5oZWFkbGluZScsXG4gICAgICAgICAgICBjb250ZW50VHJhbnNsYXRlS2V5OiAndG91ci5hc3Nlc3NtZW50RGFzaGJvYXJkLmdyYWRpbmdQcm9jZXNzLmNvbnRlbnQnLFxuICAgICAgICAgICAgaGlnaGxpZ2h0UGFkZGluZzogMTAsXG4gICAgICAgICAgICBvcmllbnRhdGlvbjogT3JpZW50YXRpb24uVE9QLFxuICAgICAgICAgICAgcGVybWlzc2lvbjogW0F1dGhvcml0eS5UQV0sXG4gICAgICAgIH0pLFxuICAgICAgICAvLyBzdGVwIDZcbiAgICAgICAgbmV3IFVzZXJJbnRlckFjdGlvblRvdXJTdGVwKHtcbiAgICAgICAgICAgIGhpZ2hsaWdodFNlbGVjdG9yOiAnLmJ0bi5ndWlkZWQtdG91cicsXG4gICAgICAgICAgICBoZWFkbGluZVRyYW5zbGF0ZUtleTogJ3RvdXIuYXNzZXNzbWVudERhc2hib2FyZC5leGVyY2lzZURhc2hib2FyZEJ1dHRvbi5oZWFkbGluZScsXG4gICAgICAgICAgICBjb250ZW50VHJhbnNsYXRlS2V5OiAndG91ci5hc3Nlc3NtZW50RGFzaGJvYXJkLmV4ZXJjaXNlRGFzaGJvYXJkQnV0dG9uLmNvbnRlbnQnLFxuICAgICAgICAgICAgaGlnaGxpZ2h0UGFkZGluZzogMTAsXG4gICAgICAgICAgICBvcmllbnRhdGlvbjogT3JpZW50YXRpb24uVE9QUklHSFQsXG4gICAgICAgICAgICBwZXJtaXNzaW9uOiBbQXV0aG9yaXR5LlRBXSxcbiAgICAgICAgICAgIHVzZXJJbnRlcmFjdGlvbkV2ZW50OiBVc2VySW50ZXJhY3Rpb25FdmVudC5DTElDSyxcbiAgICAgICAgfSksXG4gICAgICAgIC8vIHN0ZXAgN1xuICAgICAgICAvLyBuZXcgcGFnZVxuICAgICAgICBuZXcgVGV4dFRvdXJTdGVwKHtcbiAgICAgICAgICAgIGhpZ2hsaWdodFNlbGVjdG9yOiAnLmd1aWRlZC10b3VyLW1hcmtkb3duLXByZXZpZXcnLFxuICAgICAgICAgICAgaGVhZGxpbmVUcmFuc2xhdGVLZXk6ICd0b3VyLmV4ZXJjaXNlQXNzZXNzbWVudERhc2hib2FyZC5pbnN0cnVjdGlvbnMuaGVhZGxpbmUnLFxuICAgICAgICAgICAgY29udGVudFRyYW5zbGF0ZUtleTogJ3RvdXIuZXhlcmNpc2VBc3Nlc3NtZW50RGFzaGJvYXJkLmluc3RydWN0aW9ucy5jb250ZW50JyxcbiAgICAgICAgICAgIGhpZ2hsaWdodFBhZGRpbmc6IDEwLFxuICAgICAgICAgICAgb3JpZW50YXRpb246IE9yaWVudGF0aW9uLlRPUCxcbiAgICAgICAgICAgIHBlcm1pc3Npb246IFtBdXRob3JpdHkuVEFdLFxuICAgICAgICAgICAgcGFnZVVybDogJy9jb3Vyc2UtbWFuYWdlbWVudC8oXFxcXGQrKSsvYXNzZXNzbWVudC1kYXNoYm9hcmQvKFxcXFxkKykrJyxcbiAgICAgICAgfSksXG4gICAgICAgIC8vIHN0ZXAgOFxuICAgICAgICBuZXcgVXNlckludGVyQWN0aW9uVG91clN0ZXAoe1xuICAgICAgICAgICAgaGlnaGxpZ2h0U2VsZWN0b3I6ICcuZ3VpZGVkLXRvdXItaW5zdHJ1Y3Rpb25zLWJ1dHRvbicsXG4gICAgICAgICAgICBoZWFkbGluZVRyYW5zbGF0ZUtleTogJ3RvdXIuZXhlcmNpc2VBc3Nlc3NtZW50RGFzaGJvYXJkLmluc3RydWN0aW9uc0J1dHRvbi5oZWFkbGluZScsXG4gICAgICAgICAgICBjb250ZW50VHJhbnNsYXRlS2V5OiAndG91ci5leGVyY2lzZUFzc2Vzc21lbnREYXNoYm9hcmQuaW5zdHJ1Y3Rpb25zQnV0dG9uLmNvbnRlbnQnLFxuICAgICAgICAgICAgaGlnaGxpZ2h0UGFkZGluZzogMTAsXG4gICAgICAgICAgICBvcmllbnRhdGlvbjogT3JpZW50YXRpb24uVE9QLFxuICAgICAgICAgICAgcGVybWlzc2lvbjogW0F1dGhvcml0eS5UQV0sXG4gICAgICAgICAgICB1c2VySW50ZXJhY3Rpb25FdmVudDogVXNlckludGVyYWN0aW9uRXZlbnQuQ0xJQ0ssXG4gICAgICAgICAgICB0cmlnZ2VyTmV4dFN0ZXA6IHRydWUsXG4gICAgICAgIH0pLFxuICAgICAgICAvLyBzdGVwIDlcbiAgICAgICAgbmV3IFVzZXJJbnRlckFjdGlvblRvdXJTdGVwKHtcbiAgICAgICAgICAgIGhpZ2hsaWdodFNlbGVjdG9yOiAnLnJldmlldy1leGFtcGxlLXN1Ym1pc3Npb24uZ3VpZGVkLXRvdXInLFxuICAgICAgICAgICAgaGVhZGxpbmVUcmFuc2xhdGVLZXk6ICd0b3VyLmV4ZXJjaXNlQXNzZXNzbWVudERhc2hib2FyZC5yZWFkRXhhbXBsZVN1Ym1pc3Npb24uaGVhZGxpbmUnLFxuICAgICAgICAgICAgY29udGVudFRyYW5zbGF0ZUtleTogJ3RvdXIuZXhlcmNpc2VBc3Nlc3NtZW50RGFzaGJvYXJkLnJlYWRFeGFtcGxlU3VibWlzc2lvbi5jb250ZW50JyxcbiAgICAgICAgICAgIGhpZ2hsaWdodFBhZGRpbmc6IDEwLFxuICAgICAgICAgICAgb3JpZW50YXRpb246IE9yaWVudGF0aW9uLlRPUExFRlQsXG4gICAgICAgICAgICB1c2VySW50ZXJhY3Rpb25FdmVudDogVXNlckludGVyYWN0aW9uRXZlbnQuQ0xJQ0ssXG4gICAgICAgICAgICBwZXJtaXNzaW9uOiBbQXV0aG9yaXR5LlRBXSxcbiAgICAgICAgfSksXG4gICAgICAgIC8vIHN0ZXAgMTBcbiAgICAgICAgLy8gbmV3IHBhZ2VcbiAgICAgICAgbmV3IFRleHRUb3VyU3RlcCh7XG4gICAgICAgICAgICBoaWdobGlnaHRTZWxlY3RvcjogJy5ndWlkZWQtdG91ci1hc3Nlc3NtZW50LWVkaXRvcicsXG4gICAgICAgICAgICBoZWFkbGluZVRyYW5zbGF0ZUtleTogJ3RvdXIuZXhhbXBsZVJlYWQucmVhZFN1Ym1pc3Npb24uaGVhZGxpbmUnLFxuICAgICAgICAgICAgY29udGVudFRyYW5zbGF0ZUtleTogJ3RvdXIuZXhhbXBsZVJlYWQucmVhZFN1Ym1pc3Npb24uY29udGVudCcsXG4gICAgICAgICAgICBvcmllbnRhdGlvbjogT3JpZW50YXRpb24uVE9QLFxuICAgICAgICAgICAgcGVybWlzc2lvbjogW0F1dGhvcml0eS5UQV0sXG4gICAgICAgICAgICBwYWdlVXJsOiAnY291cnNlLW1hbmFnZW1lbnQvKFxcXFxkKykrL3RleHQtZXhlcmNpc2VzLyhcXFxcZCspKy9leGFtcGxlLXN1Ym1pc3Npb25zLyhcXFxcZCspKz9yZWFkT25seT10cnVlJyxcbiAgICAgICAgfSksXG4gICAgICAgIC8vIHN0ZXAgMTFcbiAgICAgICAgbmV3IFRleHRUb3VyU3RlcCh7XG4gICAgICAgICAgICBoaWdobGlnaHRTZWxlY3RvcjogJy5ndWlkZWQtdG91ci10ZXh0LWFzc2Vzc21lbnQnLFxuICAgICAgICAgICAgaGVhZGxpbmVUcmFuc2xhdGVLZXk6ICd0b3VyLmV4YW1wbGVSZWFkLnJlYWRBc3Nlc3NtZW50LmhlYWRsaW5lJyxcbiAgICAgICAgICAgIGNvbnRlbnRUcmFuc2xhdGVLZXk6ICd0b3VyLmV4YW1wbGVSZWFkLnJlYWRBc3Nlc3NtZW50LmNvbnRlbnQnLFxuICAgICAgICAgICAgb3JpZW50YXRpb246IE9yaWVudGF0aW9uLlRPUCxcbiAgICAgICAgICAgIHBlcm1pc3Npb246IFtBdXRob3JpdHkuVEFdLFxuICAgICAgICB9KSxcbiAgICAgICAgLy8gc3RlcCAxMlxuICAgICAgICBuZXcgVXNlckludGVyQWN0aW9uVG91clN0ZXAoe1xuICAgICAgICAgICAgaGlnaGxpZ2h0U2VsZWN0b3I6ICdqaGktZXhhbXBsZS10ZXh0LXN1Ym1pc3Npb24gLmd1aWRlZC10b3VyLXJlYWQnLFxuICAgICAgICAgICAgaGVhZGxpbmVUcmFuc2xhdGVLZXk6ICd0b3VyLmV4YW1wbGVSZWFkLmNvbmZpcm0uaGVhZGxpbmUnLFxuICAgICAgICAgICAgY29udGVudFRyYW5zbGF0ZUtleTogJ3RvdXIuZXhhbXBsZVJlYWQuY29uZmlybS5jb250ZW50JyxcbiAgICAgICAgICAgIHVzZXJJbnRlcmFjdGlvbkV2ZW50OiBVc2VySW50ZXJhY3Rpb25FdmVudC5DTElDSyxcbiAgICAgICAgICAgIG9yaWVudGF0aW9uOiBPcmllbnRhdGlvbi5UT1BSSUdIVCxcbiAgICAgICAgICAgIGhpZ2hsaWdodFBhZGRpbmc6IDEwLFxuICAgICAgICAgICAgcGVybWlzc2lvbjogW0F1dGhvcml0eS5UQV0sXG4gICAgICAgIH0pLFxuICAgICAgICAvLyBzdGVwIDEzXG4gICAgICAgIC8vIG5ldyBwYWdlXG4gICAgICAgIG5ldyBVc2VySW50ZXJBY3Rpb25Ub3VyU3RlcCh7XG4gICAgICAgICAgICBoaWdobGlnaHRTZWxlY3RvcjogJy5hc3Nlc3MtZXhhbXBsZS1zdWJtaXNzaW9uLmd1aWRlZC10b3VyJyxcbiAgICAgICAgICAgIGhlYWRsaW5lVHJhbnNsYXRlS2V5OiAndG91ci5leGVyY2lzZUFzc2Vzc21lbnREYXNoYm9hcmQuYXNzZXNzRXhhbXBsZVN1Ym1pc3Npb24uaGVhZGxpbmUnLFxuICAgICAgICAgICAgY29udGVudFRyYW5zbGF0ZUtleTogJ3RvdXIuZXhlcmNpc2VBc3Nlc3NtZW50RGFzaGJvYXJkLmFzc2Vzc0V4YW1wbGVTdWJtaXNzaW9uLmNvbnRlbnQnLFxuICAgICAgICAgICAgaGlnaGxpZ2h0UGFkZGluZzogMTAsXG4gICAgICAgICAgICBvcmllbnRhdGlvbjogT3JpZW50YXRpb24uVE9QTEVGVCxcbiAgICAgICAgICAgIHVzZXJJbnRlcmFjdGlvbkV2ZW50OiBVc2VySW50ZXJhY3Rpb25FdmVudC5DTElDSyxcbiAgICAgICAgICAgIHBlcm1pc3Npb246IFtBdXRob3JpdHkuVEFdLFxuICAgICAgICAgICAgcGFnZVVybDogJy9jb3Vyc2UtbWFuYWdlbWVudC8oXFxcXGQrKSsvYXNzZXNzbWVudC1kYXNoYm9hcmQvKFxcXFxkKykrJyxcbiAgICAgICAgfSksXG4gICAgICAgIC8vIHN0ZXAgMTRcbiAgICAgICAgLy8gbmV3IHBhZ2VcbiAgICAgICAgbmV3IEFzc2Vzc21lbnRUYXNrVG91clN0ZXAoe1xuICAgICAgICAgICAgaGlnaGxpZ2h0U2VsZWN0b3I6ICcuZ3VpZGVkLXRvdXItY29tcGxldGUtYXNzZXNzbWVudC1lZGl0b3InLFxuICAgICAgICAgICAgaGVhZGxpbmVUcmFuc2xhdGVLZXk6ICd0b3VyLmV4YW1wbGVBc3Nlc3NtZW50LmFkZEFzc2Vzc21lbnQuaGVhZGxpbmUnLFxuICAgICAgICAgICAgY29udGVudFRyYW5zbGF0ZUtleTogJ3RvdXIuZXhhbXBsZUFzc2Vzc21lbnQuYWRkQXNzZXNzbWVudC5jb250ZW50JyxcbiAgICAgICAgICAgIG9yaWVudGF0aW9uOiBPcmllbnRhdGlvbi5UT1AsXG4gICAgICAgICAgICBoaWdobGlnaHRQYWRkaW5nOiAxMCxcbiAgICAgICAgICAgIHBlcm1pc3Npb246IFtBdXRob3JpdHkuVEFdLFxuICAgICAgICAgICAgdXNlckludGVyYWN0aW9uRXZlbnQ6IFVzZXJJbnRlcmFjdGlvbkV2ZW50LkFTU0VTU19TVUJNSVNTSU9OLFxuICAgICAgICAgICAgYXNzZXNzbWVudFRhc2s6IG5ldyBHdWlkZWRUb3VyQXNzZXNzbWVudFRhc2soJ3RvdXIuZXhhbXBsZUFzc2Vzc21lbnQuYWRkQXNzZXNzbWVudC50YXNrJywgbmV3IEFzc2Vzc21lbnRPYmplY3QoMywgMCkpLFxuICAgICAgICAgICAgcGFnZVVybDogJ2NvdXJzZS1tYW5hZ2VtZW50LyhcXFxcZCspKy90ZXh0LWV4ZXJjaXNlcy8oXFxcXGQrKSsvZXhhbXBsZS1zdWJtaXNzaW9ucy8oXFxcXGQrKSs/dG9Db21wbGV0ZT10cnVlJyxcbiAgICAgICAgfSksXG4gICAgICAgIC8vIHN0ZXAgMTVcbiAgICAgICAgbmV3IEFzc2Vzc21lbnRUYXNrVG91clN0ZXAoe1xuICAgICAgICAgICAgaGlnaGxpZ2h0U2VsZWN0b3I6ICcuZ3VpZGVkLXRvdXItYXNzZXNzbWVudC1lZGl0b3InLFxuICAgICAgICAgICAgaGVhZGxpbmVUcmFuc2xhdGVLZXk6ICd0b3VyLmV4YW1wbGVBc3Nlc3NtZW50LmFkZFNjb3JlLmhlYWRsaW5lJyxcbiAgICAgICAgICAgIGNvbnRlbnRUcmFuc2xhdGVLZXk6ICd0b3VyLmV4YW1wbGVBc3Nlc3NtZW50LmFkZFNjb3JlLmNvbnRlbnQnLFxuICAgICAgICAgICAgdXNlckludGVyYWN0aW9uRXZlbnQ6IFVzZXJJbnRlcmFjdGlvbkV2ZW50LkFTU0VTU19TVUJNSVNTSU9OLFxuICAgICAgICAgICAgb3JpZW50YXRpb246IE9yaWVudGF0aW9uLlRPUCxcbiAgICAgICAgICAgIGhpZ2hsaWdodFBhZGRpbmc6IDEwLFxuICAgICAgICAgICAgcGVybWlzc2lvbjogW0F1dGhvcml0eS5UQV0sXG4gICAgICAgICAgICBhc3Nlc3NtZW50VGFzazogbmV3IEd1aWRlZFRvdXJBc3Nlc3NtZW50VGFzaygndG91ci5leGFtcGxlQXNzZXNzbWVudC5hZGRTY29yZS50YXNrJywgbmV3IEFzc2Vzc21lbnRPYmplY3QoMywgMykpLFxuICAgICAgICB9KSxcbiAgICAgICAgLy8gc3RlcCAxNlxuICAgICAgICBuZXcgVXNlckludGVyQWN0aW9uVG91clN0ZXAoe1xuICAgICAgICAgICAgaGlnaGxpZ2h0U2VsZWN0b3I6ICdqaGktZXhhbXBsZS10ZXh0LXN1Ym1pc3Npb24gLmd1aWRlZC10b3VyLWNoZWNrLWFzc2Vzc21lbnQnLFxuICAgICAgICAgICAgaGVhZGxpbmVUcmFuc2xhdGVLZXk6ICd0b3VyLmV4YW1wbGVBc3Nlc3NtZW50LnN1Ym1pdC5oZWFkbGluZScsXG4gICAgICAgICAgICBjb250ZW50VHJhbnNsYXRlS2V5OiAndG91ci5leGFtcGxlQXNzZXNzbWVudC5zdWJtaXQuY29udGVudCcsXG4gICAgICAgICAgICBvcmllbnRhdGlvbjogT3JpZW50YXRpb24uVE9QUklHSFQsXG4gICAgICAgICAgICBoaWdobGlnaHRQYWRkaW5nOiAxMCxcbiAgICAgICAgICAgIHVzZXJJbnRlcmFjdGlvbkV2ZW50OiBVc2VySW50ZXJhY3Rpb25FdmVudC5DTElDSyxcbiAgICAgICAgICAgIHBlcm1pc3Npb246IFtBdXRob3JpdHkuVEFdLFxuICAgICAgICB9KSxcbiAgICAgICAgLy8gc3RlcCAxN1xuICAgICAgICBuZXcgVXNlckludGVyQWN0aW9uVG91clN0ZXAoe1xuICAgICAgICAgICAgaGlnaGxpZ2h0U2VsZWN0b3I6ICdqaGktZXhhbXBsZS10ZXh0LXN1Ym1pc3Npb24gLmd1aWRlZC10b3VyLWJhY2snLFxuICAgICAgICAgICAgaGVhZGxpbmVUcmFuc2xhdGVLZXk6ICd0b3VyLmV4YW1wbGVBc3Nlc3NtZW50LmJhY2suaGVhZGxpbmUnLFxuICAgICAgICAgICAgY29udGVudFRyYW5zbGF0ZUtleTogJ3RvdXIuZXhhbXBsZUFzc2Vzc21lbnQuYmFjay5jb250ZW50JyxcbiAgICAgICAgICAgIG9yaWVudGF0aW9uOiBPcmllbnRhdGlvbi5SSUdIVCxcbiAgICAgICAgICAgIGhpZ2hsaWdodFBhZGRpbmc6IDEwLFxuICAgICAgICAgICAgdXNlckludGVyYWN0aW9uRXZlbnQ6IFVzZXJJbnRlcmFjdGlvbkV2ZW50LkNMSUNLLFxuICAgICAgICAgICAgcGVybWlzc2lvbjogW0F1dGhvcml0eS5UQV0sXG4gICAgICAgIH0pLFxuICAgICAgICAvLyBzdGVwIDE4XG4gICAgICAgIC8vIG5ldyBwYWdlXG4gICAgICAgIG5ldyBUZXh0VG91clN0ZXAoe1xuICAgICAgICAgICAgaGlnaGxpZ2h0U2VsZWN0b3I6ICcuZ3VpZGVkLXRvdXItZXhlcmNpc2UtZGFzaGJvYXJkLXRhYmxlJyxcbiAgICAgICAgICAgIGhlYWRsaW5lVHJhbnNsYXRlS2V5OiAndG91ci5leGVyY2lzZUFzc2Vzc21lbnREYXNoYm9hcmQuc3VibWlzc2lvbnNBbmRDb21wbGFpbnRzLmhlYWRsaW5lJyxcbiAgICAgICAgICAgIGNvbnRlbnRUcmFuc2xhdGVLZXk6ICd0b3VyLmV4ZXJjaXNlQXNzZXNzbWVudERhc2hib2FyZC5zdWJtaXNzaW9uc0FuZENvbXBsYWludHMuY29udGVudCcsXG4gICAgICAgICAgICBoaWdobGlnaHRQYWRkaW5nOiAxMCxcbiAgICAgICAgICAgIG9yaWVudGF0aW9uOiBPcmllbnRhdGlvbi5UT1AsXG4gICAgICAgICAgICBwZXJtaXNzaW9uOiBbQXV0aG9yaXR5LlRBXSxcbiAgICAgICAgICAgIHBhZ2VVcmw6ICcvY291cnNlLW1hbmFnZW1lbnQvKFxcXFxkKykrL2Fzc2Vzc21lbnQtZGFzaGJvYXJkLyhcXFxcZCspKycsXG4gICAgICAgIH0pLFxuICAgICAgICAvLyBzdGVwIDE5XG4gICAgICAgIG5ldyBUZXh0VG91clN0ZXAoe1xuICAgICAgICAgICAgaGlnaGxpZ2h0U2VsZWN0b3I6ICcuZ3VpZGVkLXRvdXItbmV3LWFzc2Vzc21lbnQtYnRuJyxcbiAgICAgICAgICAgIGhlYWRsaW5lVHJhbnNsYXRlS2V5OiAndG91ci5leGVyY2lzZUFzc2Vzc21lbnREYXNoYm9hcmQuYXNzZXNzU3VibWlzc2lvbnMuaGVhZGxpbmUnLFxuICAgICAgICAgICAgY29udGVudFRyYW5zbGF0ZUtleTogJ3RvdXIuZXhlcmNpc2VBc3Nlc3NtZW50RGFzaGJvYXJkLmFzc2Vzc1N1Ym1pc3Npb25zLmNvbnRlbnQnLFxuICAgICAgICAgICAgaGlnaGxpZ2h0UGFkZGluZzogMTAsXG4gICAgICAgICAgICBvcmllbnRhdGlvbjogT3JpZW50YXRpb24uVE9QLFxuICAgICAgICAgICAgcGVybWlzc2lvbjogW0F1dGhvcml0eS5UQV0sXG4gICAgICAgIH0pLFxuICAgIF0sXG59O1xuIiwiaW1wb3J0IHsgQmFzZUVudGl0eSB9IGZyb20gJ2FwcC9zaGFyZWQvbW9kZWwvYmFzZS1lbnRpdHknO1xuaW1wb3J0IHsgRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgU3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IFR1dG9yUGFydGljaXBhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9wYXJ0aWNpcGF0aW9uL3R1dG9yLXBhcnRpY2lwYXRpb24ubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgRXhhbXBsZVN1Ym1pc3Npb24gaW1wbGVtZW50cyBCYXNlRW50aXR5IHtcbiAgICBwdWJsaWMgaWQ/OiBudW1iZXI7XG5cbiAgICBwdWJsaWMgdXNlZEZvclR1dG9yaWFsPzogYm9vbGVhbjtcbiAgICBwdWJsaWMgZXhlcmNpc2U/OiBFeGVyY2lzZTtcbiAgICBwdWJsaWMgc3VibWlzc2lvbj86IFN1Ym1pc3Npb247XG4gICAgcHVibGljIHR1dG9yUGFydGljaXBhdGlvbnM/OiBUdXRvclBhcnRpY2lwYXRpb25bXTtcbiAgICBwdWJsaWMgYXNzZXNzbWVudEV4cGxhbmF0aW9uPzogc3RyaW5nO1xuXG4gICAgY29uc3RydWN0b3IoKSB7fVxufVxuXG5leHBvcnQgZW51bSBFeGFtcGxlU3VibWlzc2lvbk1vZGUge1xuICAgIFJFQURfQU5EX0NPTkZJUk0gPSAncmVhZENvbmZpcm0nLFxuICAgIEFTU0VTU19DT1JSRUNUTFkgPSAnYXNzZXNzQ29ycmVjdGx5Jyxcbn1cbiIsImltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IEZlZWRiYWNrQ29ycmVjdGlvbkVycm9yIH0gZnJvbSAnYXBwL2VudGl0aWVzL2ZlZWRiYWNrLm1vZGVsJztcbmltcG9ydCB7IG9uRXJyb3IgfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvZ2xvYmFsLnV0aWxzJztcbmltcG9ydCB7IFR1dG9yUGFydGljaXBhdGlvblNlcnZpY2UgfSBmcm9tICcuLi9kYXNoYm9hcmRzL3R1dG9yL3R1dG9yLXBhcnRpY2lwYXRpb24uc2VydmljZSc7XG5pbXBvcnQgeyBFeGFtcGxlU3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGFtcGxlLXN1Ym1pc3Npb24ubW9kZWwnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEZlZWRiYWNrTWFya2VyIHtcbiAgICBtYXJrV3JvbmdGZWVkYmFjayhlcnJvcnM6IEZlZWRiYWNrQ29ycmVjdGlvbkVycm9yW10pOiB2b2lkO1xuICAgIG1hcmtBbGxGZWVkYmFja1RvQ29ycmVjdCgpOiB2b2lkO1xufVxuXG5leHBvcnQgY2xhc3MgRXhhbXBsZVN1Ym1pc3Npb25Bc3Nlc3NDb21tYW5kIHtcbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSB0dXRvclBhcnRpY2lwYXRpb25TZXJ2aWNlOiBUdXRvclBhcnRpY2lwYXRpb25TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFsZXJ0U2VydmljZTogQWxlcnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGZlZWRiYWNrTWFya2VyOiBGZWVkYmFja01hcmtlcixcbiAgICApIHt9XG5cbiAgICBhc3Nlc3NFeGFtcGxlU3VibWlzc2lvbihleGFtcGxlU3VibWlzc2lvbjogRXhhbXBsZVN1Ym1pc3Npb24sIGV4ZXJjaXNlSWQ6IG51bWJlcikge1xuICAgICAgICB0aGlzLnR1dG9yUGFydGljaXBhdGlvblNlcnZpY2UuYXNzZXNzRXhhbXBsZVN1Ym1pc3Npb24oZXhhbXBsZVN1Ym1pc3Npb24sIGV4ZXJjaXNlSWQpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAoKSA9PiB0aGlzLm9uU3VjY2VzcygpLFxuICAgICAgICAgICAgZXJyb3I6IChlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHRoaXMub25GYWlsdXJlKGVycm9yKSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBvblN1Y2Nlc3MoKSB7XG4gICAgICAgIHRoaXMuZmVlZGJhY2tNYXJrZXIubWFya0FsbEZlZWRiYWNrVG9Db3JyZWN0KCk7XG4gICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLnN1Y2Nlc3MoJ2FydGVtaXNBcHAuZXhhbXBsZVN1Ym1pc3Npb24uY29ycmVjdFR1dG9yQXNzZXNzbWVudCcpO1xuICAgIH1cblxuICAgIHByaXZhdGUgb25GYWlsdXJlKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkge1xuICAgICAgICBjb25zdCBlcnJvclR5cGUgPSBlcnJvci5oZWFkZXJzLmdldCgneC1hcnRlbWlzYXBwLWVycm9yJyk7XG5cbiAgICAgICAgaWYgKGVycm9yVHlwZSA9PT0gJ2Vycm9yLmludmFsaWRfYXNzZXNzbWVudCcpIHtcbiAgICAgICAgICAgIHRoaXMuZmVlZGJhY2tNYXJrZXIubWFya0FsbEZlZWRiYWNrVG9Db3JyZWN0KCk7XG5cbiAgICAgICAgICAgIC8vIE1hcmsgYWxsIHdyb25nbHkgbWFkZSBmZWVkYmFja3MgYWNjb3JkaW5nbHkuXG4gICAgICAgICAgICBjb25zdCBjb3JyZWN0aW9uRXJyb3JzOiBGZWVkYmFja0NvcnJlY3Rpb25FcnJvcltdID0gSlNPTi5wYXJzZShlcnJvclsnZXJyb3InXVsndGl0bGUnXSlbJ2Vycm9ycyddO1xuICAgICAgICAgICAgdGhpcy5mZWVkYmFja01hcmtlci5tYXJrV3JvbmdGZWVkYmFjayhjb3JyZWN0aW9uRXJyb3JzKTtcblxuICAgICAgICAgICAgY29uc3QgbXNnID0gY29ycmVjdGlvbkVycm9ycy5sZW5ndGggPT09IDAgPyAnYXJ0ZW1pc0FwcC5leGFtcGxlU3VibWlzc2lvbi5zdWJtaXNzaW9uVmFsaWRhdGlvbi5taXNzaW5nJyA6ICdhcnRlbWlzQXBwLmV4YW1wbGVTdWJtaXNzaW9uLnN1Ym1pc3Npb25WYWxpZGF0aW9uLndyb25nJztcbiAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLmVycm9yKG1zZywgeyBtaXN0YWtlQ291bnQ6IGNvcnJlY3Rpb25FcnJvcnMubGVuZ3RoIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgb25FcnJvcih0aGlzLmFsZXJ0U2VydmljZSwgZXJyb3IpO1xuICAgICAgICB9XG4gICAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxJQUthO0FBTGI7OztBQUNBO0FBQ0E7QUFDQTtBQUVPLElBQU0sc0JBQWtDO01BQzNDLGFBQWE7TUFDYixvQkFBb0IsbUJBQW1CO01BQ3ZDLE9BQU87UUFFSCxJQUFJLHdCQUF3QjtVQUN4QixtQkFBbUI7VUFDbkIsc0JBQXNCO1VBQ3RCLHFCQUFxQjtVQUNyQixrQkFBa0I7VUFDbEIsYUFBYSxZQUFZO1VBQ3pCLFlBQVksQ0FBQyxVQUFVLEVBQUU7VUFDekIsU0FBUztVQUNULHNCQUFzQixxQkFBcUI7U0FDOUM7UUFHRCxJQUFJLGFBQWE7VUFDYixtQkFBbUI7VUFDbkIsc0JBQXNCO1VBQ3RCLHFCQUFxQjtVQUNyQixrQkFBa0I7VUFDbEIsYUFBYSxZQUFZO1VBQ3pCLFlBQVksQ0FBQyxVQUFVLEVBQUU7VUFDekIsU0FBUztTQUNaO1FBRUQsSUFBSSxhQUFhO1VBQ2IsbUJBQW1CO1VBQ25CLHNCQUFzQjtVQUN0QixxQkFBcUI7VUFDckIsa0JBQWtCO1VBQ2xCLGFBQWEsWUFBWTtVQUN6QixZQUFZLENBQUMsVUFBVSxFQUFFO1NBQzVCO1FBRUQsSUFBSSxhQUFhO1VBQ2IsbUJBQW1CO1VBQ25CLHNCQUFzQjtVQUN0QixxQkFBcUI7VUFDckIsa0JBQWtCO1VBQ2xCLGFBQWEsWUFBWTtVQUN6QixZQUFZLENBQUMsVUFBVSxFQUFFO1NBQzVCO1FBRUQsSUFBSSxhQUFhO1VBQ2IsbUJBQW1CO1VBQ25CLHNCQUFzQjtVQUN0QixxQkFBcUI7VUFDckIsa0JBQWtCO1VBQ2xCLGFBQWEsWUFBWTtVQUN6QixZQUFZLENBQUMsVUFBVSxFQUFFO1NBQzVCO1FBRUQsSUFBSSx3QkFBd0I7VUFDeEIsbUJBQW1CO1VBQ25CLHNCQUFzQjtVQUN0QixxQkFBcUI7VUFDckIsa0JBQWtCO1VBQ2xCLGFBQWEsWUFBWTtVQUN6QixZQUFZLENBQUMsVUFBVSxFQUFFO1VBQ3pCLHNCQUFzQixxQkFBcUI7U0FDOUM7UUFHRCxJQUFJLGFBQWE7VUFDYixtQkFBbUI7VUFDbkIsc0JBQXNCO1VBQ3RCLHFCQUFxQjtVQUNyQixrQkFBa0I7VUFDbEIsYUFBYSxZQUFZO1VBQ3pCLFlBQVksQ0FBQyxVQUFVLEVBQUU7VUFDekIsU0FBUztTQUNaO1FBRUQsSUFBSSx3QkFBd0I7VUFDeEIsbUJBQW1CO1VBQ25CLHNCQUFzQjtVQUN0QixxQkFBcUI7VUFDckIsa0JBQWtCO1VBQ2xCLGFBQWEsWUFBWTtVQUN6QixZQUFZLENBQUMsVUFBVSxFQUFFO1VBQ3pCLHNCQUFzQixxQkFBcUI7VUFDM0MsaUJBQWlCO1NBQ3BCO1FBRUQsSUFBSSx3QkFBd0I7VUFDeEIsbUJBQW1CO1VBQ25CLHNCQUFzQjtVQUN0QixxQkFBcUI7VUFDckIsa0JBQWtCO1VBQ2xCLGFBQWEsWUFBWTtVQUN6QixzQkFBc0IscUJBQXFCO1VBQzNDLFlBQVksQ0FBQyxVQUFVLEVBQUU7U0FDNUI7UUFHRCxJQUFJLGFBQWE7VUFDYixtQkFBbUI7VUFDbkIsc0JBQXNCO1VBQ3RCLHFCQUFxQjtVQUNyQixhQUFhLFlBQVk7VUFDekIsWUFBWSxDQUFDLFVBQVUsRUFBRTtVQUN6QixTQUFTO1NBQ1o7UUFFRCxJQUFJLGFBQWE7VUFDYixtQkFBbUI7VUFDbkIsc0JBQXNCO1VBQ3RCLHFCQUFxQjtVQUNyQixhQUFhLFlBQVk7VUFDekIsWUFBWSxDQUFDLFVBQVUsRUFBRTtTQUM1QjtRQUVELElBQUksd0JBQXdCO1VBQ3hCLG1CQUFtQjtVQUNuQixzQkFBc0I7VUFDdEIscUJBQXFCO1VBQ3JCLHNCQUFzQixxQkFBcUI7VUFDM0MsYUFBYSxZQUFZO1VBQ3pCLGtCQUFrQjtVQUNsQixZQUFZLENBQUMsVUFBVSxFQUFFO1NBQzVCO1FBR0QsSUFBSSx3QkFBd0I7VUFDeEIsbUJBQW1CO1VBQ25CLHNCQUFzQjtVQUN0QixxQkFBcUI7VUFDckIsa0JBQWtCO1VBQ2xCLGFBQWEsWUFBWTtVQUN6QixzQkFBc0IscUJBQXFCO1VBQzNDLFlBQVksQ0FBQyxVQUFVLEVBQUU7VUFDekIsU0FBUztTQUNaO1FBR0QsSUFBSSx1QkFBdUI7VUFDdkIsbUJBQW1CO1VBQ25CLHNCQUFzQjtVQUN0QixxQkFBcUI7VUFDckIsYUFBYSxZQUFZO1VBQ3pCLGtCQUFrQjtVQUNsQixZQUFZLENBQUMsVUFBVSxFQUFFO1VBQ3pCLHNCQUFzQixxQkFBcUI7VUFDM0MsZ0JBQWdCLElBQUkseUJBQXlCLDZDQUE2QyxJQUFJLGlCQUFpQixHQUFHLENBQUMsQ0FBQztVQUNwSCxTQUFTO1NBQ1o7UUFFRCxJQUFJLHVCQUF1QjtVQUN2QixtQkFBbUI7VUFDbkIsc0JBQXNCO1VBQ3RCLHFCQUFxQjtVQUNyQixzQkFBc0IscUJBQXFCO1VBQzNDLGFBQWEsWUFBWTtVQUN6QixrQkFBa0I7VUFDbEIsWUFBWSxDQUFDLFVBQVUsRUFBRTtVQUN6QixnQkFBZ0IsSUFBSSx5QkFBeUIsd0NBQXdDLElBQUksaUJBQWlCLEdBQUcsQ0FBQyxDQUFDO1NBQ2xIO1FBRUQsSUFBSSx3QkFBd0I7VUFDeEIsbUJBQW1CO1VBQ25CLHNCQUFzQjtVQUN0QixxQkFBcUI7VUFDckIsYUFBYSxZQUFZO1VBQ3pCLGtCQUFrQjtVQUNsQixzQkFBc0IscUJBQXFCO1VBQzNDLFlBQVksQ0FBQyxVQUFVLEVBQUU7U0FDNUI7UUFFRCxJQUFJLHdCQUF3QjtVQUN4QixtQkFBbUI7VUFDbkIsc0JBQXNCO1VBQ3RCLHFCQUFxQjtVQUNyQixhQUFhLFlBQVk7VUFDekIsa0JBQWtCO1VBQ2xCLHNCQUFzQixxQkFBcUI7VUFDM0MsWUFBWSxDQUFDLFVBQVUsRUFBRTtTQUM1QjtRQUdELElBQUksYUFBYTtVQUNiLG1CQUFtQjtVQUNuQixzQkFBc0I7VUFDdEIscUJBQXFCO1VBQ3JCLGtCQUFrQjtVQUNsQixhQUFhLFlBQVk7VUFDekIsWUFBWSxDQUFDLFVBQVUsRUFBRTtVQUN6QixTQUFTO1NBQ1o7UUFFRCxJQUFJLGFBQWE7VUFDYixtQkFBbUI7VUFDbkIsc0JBQXNCO1VBQ3RCLHFCQUFxQjtVQUNyQixrQkFBa0I7VUFDbEIsYUFBYSxZQUFZO1VBQ3pCLFlBQVksQ0FBQyxVQUFVLEVBQUU7U0FDNUI7Ozs7Ozs7QUN2TVQsSUFBYSxtQkFZRDtBQVpaOztBQUFNLElBQU8sb0JBQVAsTUFBd0I7TUFDbkI7TUFFQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BRVAsY0FBQTtNQUFlOztBQUduQixLQUFBLFNBQVlBLHdCQUFxQjtBQUM3QixNQUFBQSx1QkFBQSxrQkFBQSxJQUFBO0FBQ0EsTUFBQUEsdUJBQUEsa0JBQUEsSUFBQTtJQUNKLEdBSFksMEJBQUEsd0JBQXFCLENBQUEsRUFBQTs7Ozs7QUNkakMsSUFTYTtBQVRiOzs7QUFTTSxJQUFPLGlDQUFQLE1BQXFDO01BRTNCO01BQ0E7TUFDQTtNQUhaLFlBQ1ksMkJBQ0EsY0FDQSxnQkFBOEI7QUFGOUIsYUFBQSw0QkFBQTtBQUNBLGFBQUEsZUFBQTtBQUNBLGFBQUEsaUJBQUE7TUFDVDtNQUVILHdCQUF3QixtQkFBc0MsWUFBa0I7QUFDNUUsYUFBSywwQkFBMEIsd0JBQXdCLG1CQUFtQixVQUFVLEVBQUUsVUFBVTtVQUM1RixNQUFNLE1BQU0sS0FBSyxVQUFTO1VBQzFCLE9BQU8sQ0FBQyxVQUE2QixLQUFLLFVBQVUsS0FBSztTQUM1RDtNQUNMO01BRVEsWUFBUztBQUNiLGFBQUssZUFBZSx5QkFBd0I7QUFDNUMsYUFBSyxhQUFhLFFBQVEscURBQXFEO01BQ25GO01BRVEsVUFBVSxPQUF3QjtBQUN0QyxjQUFNLFlBQVksTUFBTSxRQUFRLElBQUksb0JBQW9CO0FBRXhELFlBQUksY0FBYyw0QkFBNEI7QUFDMUMsZUFBSyxlQUFlLHlCQUF3QjtBQUc1QyxnQkFBTSxtQkFBOEMsS0FBSyxNQUFNLE1BQU0sT0FBTyxFQUFFLE9BQU8sQ0FBQyxFQUFFLFFBQVE7QUFDaEcsZUFBSyxlQUFlLGtCQUFrQixnQkFBZ0I7QUFFdEQsZ0JBQU0sTUFBTSxpQkFBaUIsV0FBVyxJQUFJLDhEQUE4RDtBQUMxRyxlQUFLLGFBQWEsTUFBTSxLQUFLLEVBQUUsY0FBYyxpQkFBaUIsT0FBTSxDQUFFO2VBQ25FO0FBQ0gsa0JBQVEsS0FBSyxjQUFjLEtBQUs7O01BRXhDOzs7OyIsIm5hbWVzIjpbIkV4YW1wbGVTdWJtaXNzaW9uTW9kZSJdfQ==