import {
  FormDateTimePickerComponent,
  FormDateTimePickerModule,
  init_date_time_picker_component,
  init_date_time_picker_module
} from "/chunk-OYUGERZV.js";
import {
  ArtemisSharedComponentModule,
  DocumentationButtonComponent,
  PagingService,
  SortingOrder,
  init_documentation_button_component,
  init_pageable_table,
  init_paging_service,
  init_shared_component_module
} from "/chunk-ORYTP7RT.js";
import {
  SortService,
  init_sort_service
} from "/chunk-H46RESQY.js";
import {
  init_global_utils,
  onError
} from "/chunk-LW4WH7EZ.js";
import {
  AlertService,
  ArtemisDatePipe,
  ArtemisSharedModule,
  ArtemisTimeAgoPipe,
  ArtemisTranslatePipe,
  ButtonComponent,
  Competency,
  CompetencyRelationError,
  CompetencyService,
  CompetencyTaxonomy,
  DeleteButtonDirective,
  LectureService,
  LectureUnitService,
  LectureUnitType,
  SortByDirective,
  SortDirective,
  TranslateDirective,
  __esm,
  __spreadValues,
  getIcon3 as getIcon,
  getIconTooltip3 as getIconTooltip,
  init_alert_service,
  init_artemis_date_pipe,
  init_artemis_time_ago_pipe,
  init_artemis_translate_pipe,
  init_button_component,
  init_competency_model,
  init_competency_service,
  init_delete_button_directive,
  init_lectureUnit_model,
  init_lectureUnit_service,
  init_lecture_service,
  init_shared_module,
  init_sort_by_directive,
  init_sort_directive,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/course/competencies/competencies-popover/competencies-popover.component.ts
import { Component, Input, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faFlag } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function CompetenciesPopoverComponent_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "span", 4);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(3, 1, "artemisApp.competency.competencyPopover.connectedCompetencies"));
  }
}
function CompetenciesPopoverComponent_ng_template_3_Conditional_1_For_10_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "a", 6);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(3, "\n                ");
  }
  if (rf & 2) {
    const competency_r7 = ctx.$implicit;
    const ctx_r6 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("routerLink", ctx_r6.navigationArray);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate(competency_r7.title);
  }
}
function CompetenciesPopoverComponent_ng_template_3_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n            ");
    i0.\u0275\u0275elementStart(3, "small");
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275pipe(5, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n            ");
    i0.\u0275\u0275elementStart(7, "ul", 5);
    i0.\u0275\u0275text(8, "\n                ");
    i0.\u0275\u0275repeaterCreate(9, CompetenciesPopoverComponent_ng_template_3_Conditional_1_For_10_Template, 4, 2, null, null, i0.\u0275\u0275repeaterTrackByIdentity);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12, "\n    ");
  }
  if (rf & 2) {
    const ctx_r4 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate1("\n                ", i0.\u0275\u0275pipeBind1(5, 1, "artemisApp.competency.competencyPopover.explanation"), "\n            ");
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275repeater(ctx_r4.competencies);
  }
}
function CompetenciesPopoverComponent_ng_template_3_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "a", 7);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n    ");
  }
  if (rf & 2) {
    const ctx_r5 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("routerLink", ctx_r5.navigationArray);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(3, 2, "artemisApp.competency.competencyPopover.noCompetencies"));
  }
}
function CompetenciesPopoverComponent_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275template(1, CompetenciesPopoverComponent_ng_template_3_Conditional_1_Template, 13, 3)(2, CompetenciesPopoverComponent_ng_template_3_Conditional_2_Template, 5, 4);
  }
  if (rf & 2) {
    const ctx_r2 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(1, ctx_r2.competencies && ctx_r2.competencies.length > 0 ? 1 : 2);
  }
}
var CompetenciesPopoverComponent;
var init_competencies_popover_component = __esm({
  "src/main/webapp/app/course/competencies/competencies-popover/competencies-popover.component.ts"() {
    init_artemis_translate_pipe();
    CompetenciesPopoverComponent = class _CompetenciesPopoverComponent {
      courseId;
      competencies = [];
      navigateTo = "courseCompetencies";
      navigationArray = [];
      faFlag = faFlag;
      constructor() {
      }
      ngOnInit() {
        if (this.courseId) {
          switch (this.navigateTo) {
            case "courseCompetencies": {
              this.navigationArray = ["/courses", `${this.courseId}`, "competencies"];
              break;
            }
            case "competencyManagement": {
              this.navigationArray = ["/course-management", `${this.courseId}`, "competency-management"];
              break;
            }
          }
        }
      }
      static \u0275fac = function CompetenciesPopoverComponent_Factory(t) {
        return new (t || _CompetenciesPopoverComponent)();
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _CompetenciesPopoverComponent, selectors: [["jhi-competencies-popover"]], inputs: { courseId: "courseId", competencies: "competencies", navigateTo: "navigateTo" }, decls: 11, vars: 4, consts: [["popTitle", ""], ["popContent", ""], ["type", "button", "popoverClass", "competency-popover", 1, "btn", "btn-sm", "btn-primary", "competency-button", 3, "ngbPopover", "popoverTitle"], [3, "icon", "fixedWidth"], [1, "font-weight-bold"], [1, "list-group"], [1, "list-group-item", 3, "routerLink"], [3, "routerLink"]], template: function CompetenciesPopoverComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275template(0, CompetenciesPopoverComponent_ng_template_0_Template, 4, 3, "ng-template", null, 0, i0.\u0275\u0275templateRefExtractor);
          i0.\u0275\u0275text(2, "\n");
          i0.\u0275\u0275template(3, CompetenciesPopoverComponent_ng_template_3_Template, 3, 1, "ng-template", null, 1, i0.\u0275\u0275templateRefExtractor);
          i0.\u0275\u0275text(5, "\n");
          i0.\u0275\u0275elementStart(6, "button", 2);
          i0.\u0275\u0275text(7, "\n    ");
          i0.\u0275\u0275element(8, "fa-icon", 3);
          i0.\u0275\u0275text(9, "\n");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(10, "\n");
        }
        if (rf & 2) {
          const _r1 = i0.\u0275\u0275reference(1);
          const _r3 = i0.\u0275\u0275reference(4);
          i0.\u0275\u0275advance(6);
          i0.\u0275\u0275property("ngbPopover", _r3)("popoverTitle", _r1);
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275property("icon", ctx.faFlag)("fixedWidth", true);
        }
      }, dependencies: [i1.NgbPopover, i2.FaIconComponent, i3.RouterLink, ArtemisTranslatePipe], styles: ["/* src/main/webapp/app/course/competencies/competencies-popover/competencies-popover.component.scss */\n.competency-button {\n  width: 100%;\n}\n.competency-popover {\n  max-width: 1000px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvY29tcGV0ZW5jaWVzL2NvbXBldGVuY2llcy1wb3BvdmVyL2NvbXBldGVuY2llcy1wb3BvdmVyLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuY29tcGV0ZW5jeS1idXR0b24ge1xuICAgIHdpZHRoOiAxMDAlO1xufVxuXG4uY29tcGV0ZW5jeS1wb3BvdmVyIHtcbiAgICBtYXgtd2lkdGg6IDEwMDBweCAhaW1wb3J0YW50O1xufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLENBQUE7QUFDSSxTQUFBOztBQUdKLENBQUE7QUFDSSxhQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(CompetenciesPopoverComponent, { className: "CompetenciesPopoverComponent" });
    })();
  }
});

// src/main/webapp/app/course/competencies/competency-form/competency-form.component.ts
import { Component as Component2, EventEmitter, Input as Input2, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { FormBuilder, Validators } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import { merge, of } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { catchError, delay, map, switchMap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import { intersection } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import { faQuestionCircle, faTimes } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i6 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i9 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
function CompetencyFormComponent_Conditional_4_Conditional_3_Conditional_10_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                                ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                        ", i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.competency.createCompetency.titleRequiredValidationError"), "\n                                    ");
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_3_Conditional_10_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                                ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                        ", i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.competency.createCompetency.titleMaxLengthValidationError"), "\n                                    ");
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_3_Conditional_10_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                                ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                        ", i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.competency.createCompetency.titleUniqueValidationError"), "\n                                    ");
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_3_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div", 12);
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275template(3, CompetencyFormComponent_Conditional_4_Conditional_3_Conditional_10_Conditional_3_Template, 5, 3)(4, CompetencyFormComponent_Conditional_4_Conditional_3_Conditional_10_Conditional_4_Template, 5, 3)(5, CompetencyFormComponent_Conditional_4_Conditional_3_Conditional_10_Conditional_5_Template, 5, 3);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r11 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, (ctx_r11.titleControl == null ? null : ctx_r11.titleControl.errors == null ? null : ctx_r11.titleControl.errors.required) ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(4, (ctx_r11.titleControl == null ? null : ctx_r11.titleControl.errors == null ? null : ctx_r11.titleControl.errors.maxlength) ? 4 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(5, (ctx_r11.titleControl == null ? null : ctx_r11.titleControl.errors == null ? null : ctx_r11.titleControl.errors.titleUnique) ? 5 : -1);
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "div", 3);
    i02.\u0275\u0275text(2, "\n                        ");
    i02.\u0275\u0275elementStart(3, "label", 10);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                        ");
    i02.\u0275\u0275element(7, "input", 11);
    i02.\u0275\u0275pipe(8, "artemisTranslate");
    i02.\u0275\u0275text(9, "\n                        ");
    i02.\u0275\u0275template(10, CompetencyFormComponent_Conditional_4_Conditional_3_Conditional_10_Template, 7, 3);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n                ");
  }
  if (rf & 2) {
    const ctx_r1 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate1("", i02.\u0275\u0275pipeBind1(5, 3, "artemisApp.competency.title"), "*");
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("placeholder", i02.\u0275\u0275pipeBind1(8, 5, "artemisApp.competency.createCompetency.titlePlaceholder"));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(10, (ctx_r1.titleControl == null ? null : ctx_r1.titleControl.invalid) && ((ctx_r1.titleControl == null ? null : ctx_r1.titleControl.dirty) || (ctx_r1.titleControl == null ? null : ctx_r1.titleControl.touched)) ? 10 : -1);
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_4_Conditional_10_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                                ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                        ", i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.competency.createCompetency.descriptionMaxLengthValidationError"), "\n                                    ");
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_4_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "div", 12);
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275template(3, CompetencyFormComponent_Conditional_4_Conditional_4_Conditional_10_Conditional_3_Template, 5, 3);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r15 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, (ctx_r15.descriptionControl == null ? null : ctx_r15.descriptionControl.errors == null ? null : ctx_r15.descriptionControl.errors.maxlength) ? 3 : -1);
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "div", 3);
    i02.\u0275\u0275text(2, "\n                        ");
    i02.\u0275\u0275elementStart(3, "label", 13);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                        ");
    i02.\u0275\u0275element(7, "textarea", 14);
    i02.\u0275\u0275pipe(8, "artemisTranslate");
    i02.\u0275\u0275text(9, "\n                        ");
    i02.\u0275\u0275template(10, CompetencyFormComponent_Conditional_4_Conditional_4_Conditional_10_Template, 5, 1);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n                ");
  }
  if (rf & 2) {
    const ctx_r2 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(5, 3, "artemisApp.competency.description"));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("placeholder", i02.\u0275\u0275pipeBind1(8, 5, "artemisApp.competency.createCompetency.descriptionPlaceholder"));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(10, (ctx_r2.descriptionControl == null ? null : ctx_r2.descriptionControl.invalid) && ((ctx_r2.descriptionControl == null ? null : ctx_r2.descriptionControl.dirty) || (ctx_r2.descriptionControl == null ? null : ctx_r2.descriptionControl.touched)) ? 10 : -1);
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_12_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "small");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r17 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate2(" (", i02.\u0275\u0275pipeBind1(3, 2, "artemisApp.competency.createCompetency.suggestedTaxonomy"), ": ", ctx_r17.suggestedTaxonomies.join(", "), ") ");
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_12_For_13_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "option", 18);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275pipe(4, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                            ");
  }
  if (rf & 2) {
    const taxonomy_r19 = ctx.$implicit;
    const i_r20 = ctx.$index;
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("ngValue", taxonomy_r19.key);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275textInterpolate3("\n                                    ", "\u2009".repeat(i_r20), "\u2514\n                                    ", i02.\u0275\u0275pipeBind1(3, 4, "artemisApp.competency.taxonomies." + taxonomy_r19.value.toLowerCase()), "\n                                    (", i02.\u0275\u0275pipeBind1(4, 6, "artemisApp.competency.keywords." + taxonomy_r19.value.toLowerCase()), ")\n                                ");
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "div", 3);
    i02.\u0275\u0275text(2, "\n                        ");
    i02.\u0275\u0275elementStart(3, "label", 15);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275template(6, CompetencyFormComponent_Conditional_4_Conditional_12_Conditional_6_Template, 5, 4);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementStart(8, "select", 16);
    i02.\u0275\u0275text(9, "\n                            ");
    i02.\u0275\u0275element(10, "option", 17);
    i02.\u0275\u0275text(11, "\n                            ");
    i02.\u0275\u0275repeaterCreate(12, CompetencyFormComponent_Conditional_4_Conditional_12_For_13_Template, 6, 8, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
    i02.\u0275\u0275pipe(14, "keyvalue");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(15, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(16, "\n                ");
  }
  if (rf & 2) {
    const ctx_r3 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate1("\n                            ", i02.\u0275\u0275pipeBind1(5, 3, "artemisApp.competency.taxonomy"), "\n                            ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(6, (ctx_r3.suggestedTaxonomies == null ? null : ctx_r3.suggestedTaxonomies.length) ? 6 : -1);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275property("ngValue", void 0);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275repeater(i02.\u0275\u0275pipeBind2(14, 5, ctx_r3.competencyTaxonomy, ctx_r3.keepOrder));
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_13_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "small");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r24 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate2(" (", i02.\u0275\u0275pipeBind1(3, 2, "artemisApp.competency.createCompetency.averageStudentScore"), ": ", ctx_r24.averageStudentScore, "%) ");
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "div", 3);
    i02.\u0275\u0275text(2, "\n                        ");
    i02.\u0275\u0275elementStart(3, "label", 19);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275template(6, CompetencyFormComponent_Conditional_4_Conditional_13_Conditional_6_Template, 5, 4);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275element(8, "input", 20);
    i02.\u0275\u0275text(9, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n                ");
  }
  if (rf & 2) {
    const ctx_r4 = i02.\u0275\u0275nextContext(2);
    let tmp_0_0;
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate2("\n                            ", i02.\u0275\u0275pipeBind1(5, 3, "artemisApp.competency.masteryThreshold"), ": ", (tmp_0_0 = ctx_r4.masteryThresholdControl.value) !== null && tmp_0_0 !== void 0 ? tmp_0_0 : 50, "%\n                            ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(6, ctx_r4.averageStudentScore ? 6 : -1);
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_30_For_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275elementStart(1, "button", 24);
    i02.\u0275\u0275listener("click", function CompetencyFormComponent_Conditional_4_Conditional_30_For_10_Template_button_click_1_listener() {
      const restoredCtx = i02.\u0275\u0275restoreView(_r32);
      const lecture_r26 = restoredCtx.$implicit;
      const ctx_r31 = i02.\u0275\u0275nextContext(3);
      return i02.\u0275\u0275resetView(ctx_r31.selectLectureInDropdown(lecture_r26));
    });
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                                ");
  }
  if (rf & 2) {
    const lecture_r26 = ctx.$implicit;
    const ctx_r25 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                        ", ctx_r25.getLectureTitleForDropdown(lecture_r26), "\n                                    ");
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "div", 21);
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "button", 22);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                            ");
    i02.\u0275\u0275elementStart(7, "div", 23);
    i02.\u0275\u0275text(8, "\n                                ");
    i02.\u0275\u0275repeaterCreate(9, CompetencyFormComponent_Conditional_4_Conditional_30_For_10_Template, 4, 1, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(12, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r5 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("hidden", ctx_r5.isInSingleLectureMode);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate1("\n                                ", ctx_r5.selectedLectureInDropdown ? ctx_r5.getLectureTitleForDropdown(ctx_r5.selectedLectureInDropdown) : i02.\u0275\u0275pipeBind1(5, 2, "artemisApp.competency.createCompetency.selectLecture"), "\n                            ");
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275repeater(ctx_r5.lecturesOfCourseWithLectureUnits);
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "div", 25);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                            ", i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.competency.createCompetency.noLectures"), "\n                        ");
  }
}
function CompetencyFormComponent_Conditional_4_ng_template_32_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "div", 25);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                            ", i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.competency.createCompetency.noLectures"), "\n                        ");
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_35_For_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r40 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                                        ");
    i02.\u0275\u0275elementStart(1, "tr", 29);
    i02.\u0275\u0275listener("click", function CompetencyFormComponent_Conditional_4_Conditional_35_For_29_Template_tr_click_1_listener() {
      const restoredCtx = i02.\u0275\u0275restoreView(_r40);
      const lectureUnit_r34 = restoredCtx.$implicit;
      const ctx_r39 = i02.\u0275\u0275nextContext(3);
      return i02.\u0275\u0275resetView(ctx_r39.selectLectureUnitInTable(lectureUnit_r34));
    });
    i02.\u0275\u0275text(2, "\n                                            ");
    i02.\u0275\u0275elementStart(3, "td");
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                                            ");
    i02.\u0275\u0275elementStart(6, "td");
    i02.\u0275\u0275text(7);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                                            ");
    i02.\u0275\u0275elementStart(9, "td");
    i02.\u0275\u0275text(10);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n                                            ");
    i02.\u0275\u0275elementStart(12, "td");
    i02.\u0275\u0275text(13);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(14, "\n                                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(15, "\n                                    ");
  }
  if (rf & 2) {
    const lectureUnit_r34 = ctx.$implicit;
    const ctx_r33 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275classProp("table-primary", ctx_r33.isLectureUnitAlreadySelectedInTable(lectureUnit_r34));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(lectureUnit_r34.id ? lectureUnit_r34.id : "");
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(lectureUnit_r34.type ? lectureUnit_r34.type : "");
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(ctx_r33.lectureUnitService.getLectureUnitName(lectureUnit_r34) ? ctx_r33.lectureUnitService.getLectureUnitName(lectureUnit_r34) : "");
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate1("\n                                                ", ctx_r33.lectureUnitService.getLectureUnitReleaseDate(lectureUnit_r34) ? ctx_r33.lectureUnitService.getLectureUnitReleaseDate(lectureUnit_r34).format("MMM DD YYYY, HH:mm:ss") : "", "\n                                            ");
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_35_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "div", 26);
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "table", 27);
    i02.\u0275\u0275text(4, "\n                                ");
    i02.\u0275\u0275elementStart(5, "thead", 28);
    i02.\u0275\u0275text(6, "\n                                    ");
    i02.\u0275\u0275elementStart(7, "tr");
    i02.\u0275\u0275text(8, "\n                                        ");
    i02.\u0275\u0275elementStart(9, "th");
    i02.\u0275\u0275text(10, "id");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n                                        ");
    i02.\u0275\u0275elementStart(12, "th");
    i02.\u0275\u0275text(13);
    i02.\u0275\u0275pipe(14, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(15, "\n                                        ");
    i02.\u0275\u0275elementStart(16, "th");
    i02.\u0275\u0275text(17);
    i02.\u0275\u0275pipe(18, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(19, "\n                                        ");
    i02.\u0275\u0275elementStart(20, "th");
    i02.\u0275\u0275text(21);
    i02.\u0275\u0275pipe(22, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(23, "\n                                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(24, "\n                                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(25, "\n                                ");
    i02.\u0275\u0275elementStart(26, "tbody");
    i02.\u0275\u0275text(27, "\n                                    ");
    i02.\u0275\u0275repeaterCreate(28, CompetencyFormComponent_Conditional_4_Conditional_35_For_29_Template, 16, 6, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(30, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(31, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(32, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r9 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(13);
    i02.\u0275\u0275textInterpolate1("\n                                            ", i02.\u0275\u0275pipeBind1(14, 3, "artemisApp.competency.createCompetency.lectureUnitTable.type"), "\n                                        ");
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate1("\n                                            ", i02.\u0275\u0275pipeBind1(18, 5, "artemisApp.competency.createCompetency.lectureUnitTable.name"), "\n                                        ");
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate1("\n                                            ", i02.\u0275\u0275pipeBind1(22, 7, "artemisApp.competency.createCompetency.lectureUnitTable.releaseDate"), "\n                                        ");
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275repeater(ctx_r9.selectedLectureInDropdown.lectureUnits);
  }
}
function CompetencyFormComponent_Conditional_4_Conditional_46_Template(rf, ctx) {
  if (rf & 1) {
    const _r42 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "button", 30);
    i02.\u0275\u0275listener("click", function CompetencyFormComponent_Conditional_4_Conditional_46_Template_button_click_1_listener() {
      i02.\u0275\u0275restoreView(_r42);
      const ctx_r41 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r41.cancelForm());
    });
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275element(3, "fa-icon", 31);
    i02.\u0275\u0275text(4, "\xA0");
    i02.\u0275\u0275elementStart(5, "span", 32);
    i02.\u0275\u0275text(6, "Cancel");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r10 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("icon", ctx_r10.faTimes);
  }
}
function CompetencyFormComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r44 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275elementStart(1, "form", 2);
    i02.\u0275\u0275listener("ngSubmit", function CompetencyFormComponent_Conditional_4_Template_form_ngSubmit_1_listener() {
      i02.\u0275\u0275restoreView(_r44);
      const ctx_r43 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r43.submitForm());
    });
    i02.\u0275\u0275text(2, "\n                ");
    i02.\u0275\u0275template(3, CompetencyFormComponent_Conditional_4_Conditional_3_Template, 12, 7)(4, CompetencyFormComponent_Conditional_4_Conditional_4_Template, 12, 7);
    i02.\u0275\u0275elementStart(5, "div", 3);
    i02.\u0275\u0275text(6, "\n                    ");
    i02.\u0275\u0275element(7, "jhi-date-time-picker", 4);
    i02.\u0275\u0275pipe(8, "artemisTranslate");
    i02.\u0275\u0275pipe(9, "artemisTranslate");
    i02.\u0275\u0275text(10, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n                ");
    i02.\u0275\u0275template(12, CompetencyFormComponent_Conditional_4_Conditional_12_Template, 17, 8)(13, CompetencyFormComponent_Conditional_4_Conditional_13_Template, 11, 5);
    i02.\u0275\u0275elementStart(14, "div", 3);
    i02.\u0275\u0275text(15, "\n                    ");
    i02.\u0275\u0275element(16, "input", 5);
    i02.\u0275\u0275text(17, "\n                    ");
    i02.\u0275\u0275element(18, "label", 6);
    i02.\u0275\u0275text(19, "\n                    ");
    i02.\u0275\u0275element(20, "fa-icon", 7);
    i02.\u0275\u0275pipe(21, "artemisTranslate");
    i02.\u0275\u0275text(22, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(23, "\n                ");
    i02.\u0275\u0275elementStart(24, "div");
    i02.\u0275\u0275text(25, "\n                    ");
    i02.\u0275\u0275elementStart(26, "label");
    i02.\u0275\u0275text(27);
    i02.\u0275\u0275pipe(28, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(29, "\n                    ");
    i02.\u0275\u0275template(30, CompetencyFormComponent_Conditional_4_Conditional_30_Template, 13, 4)(31, CompetencyFormComponent_Conditional_4_Conditional_31_Template, 5, 3)(32, CompetencyFormComponent_Conditional_4_ng_template_32_Template, 5, 3, "ng-template", null, 8, i02.\u0275\u0275templateRefExtractor);
    i02.\u0275\u0275text(34, "\n                    ");
    i02.\u0275\u0275template(35, CompetencyFormComponent_Conditional_4_Conditional_35_Template, 33, 9);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(36, "\n                ");
    i02.\u0275\u0275elementStart(37, "div");
    i02.\u0275\u0275text(38, "\n                    ");
    i02.\u0275\u0275elementStart(39, "button", 9);
    i02.\u0275\u0275text(40, "\n                        ");
    i02.\u0275\u0275elementStart(41, "span");
    i02.\u0275\u0275text(42);
    i02.\u0275\u0275pipe(43, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(44, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(45, "\n                    ");
    i02.\u0275\u0275template(46, CompetencyFormComponent_Conditional_4_Conditional_46_Template, 9, 1);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(47, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(48, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("formGroup", ctx_r0.form);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(3, !ctx_r0.isInConnectMode ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(4, !ctx_r0.isInConnectMode ? 4 : -1);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275propertyInterpolate("labelName", i02.\u0275\u0275pipeBind1(8, 15, "artemisApp.competency.createCompetency.softDueDate"));
    i02.\u0275\u0275propertyInterpolate("labelTooltip", i02.\u0275\u0275pipeBind1(9, 17, "artemisApp.competency.createCompetency.softDueDateHint"));
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275conditional(12, !ctx_r0.isInConnectMode ? 12 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(13, !ctx_r0.isInConnectMode ? 13 : -1);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275propertyInterpolate("ngbTooltip", i02.\u0275\u0275pipeBind1(21, 19, "artemisApp.competency.optionalDescription"));
    i02.\u0275\u0275property("icon", ctx_r0.faQuestionCircle);
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(28, 21, "artemisApp.competency.createCompetency.connectWithLectureUnits"));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(30, ctx_r0.lecturesOfCourseWithLectureUnits && ctx_r0.lecturesOfCourseWithLectureUnits.length > 0 ? 30 : 31);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275conditional(35, ctx_r0.selectedLectureInDropdown ? 35 : -1);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275property("disabled", !ctx_r0.isSubmitPossible);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(43, 23, "entity.action.submit"));
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275conditional(46, ctx_r0.hasCancelButton ? 46 : -1);
  }
}
var titleUniqueValidator, CompetencyFormComponent;
var init_competency_form_component = __esm({
  "src/main/webapp/app/course/competencies/competency-form/competency-form.component.ts"() {
    init_competency_service();
    init_lectureUnit_service();
    init_competency_model();
    init_competency_service();
    init_lectureUnit_service();
    init_translate_directive();
    init_date_time_picker_component();
    init_artemis_translate_pipe();
    titleUniqueValidator = (competencyService, courseId, initialTitle) => {
      return (competencyTitleControl) => {
        return of(competencyTitleControl.value).pipe(delay(250), switchMap((title) => {
          if (initialTitle && title === initialTitle) {
            return of(null);
          }
          return competencyService.getAllForCourse(courseId).pipe(map((res) => {
            let competencyTitles = [];
            if (res.body) {
              competencyTitles = res.body.map((competency) => competency.title);
            }
            if (title && competencyTitles.includes(title)) {
              return {
                titleUnique: { valid: false }
              };
            } else {
              return null;
            }
          }), catchError(() => of(null)));
        }));
      };
    };
    CompetencyFormComponent = class _CompetencyFormComponent {
      fb;
      competencyService;
      translateService;
      lectureUnitService;
      formData = {
        id: void 0,
        title: void 0,
        description: void 0,
        softDueDate: void 0,
        taxonomy: void 0,
        masteryThreshold: void 0,
        optional: false,
        connectedLectureUnits: void 0
      };
      isEditMode = false;
      isInConnectMode = false;
      isInSingleLectureMode = false;
      courseId;
      lecturesOfCourseWithLectureUnits = [];
      averageStudentScore;
      hasCancelButton;
      onCancel = new EventEmitter();
      titleUniqueValidator = titleUniqueValidator;
      competencyTaxonomy = CompetencyTaxonomy;
      formSubmitted = new EventEmitter();
      form;
      selectedLectureInDropdown;
      selectedLectureUnitsInTable = [];
      suggestedTaxonomies = [];
      faTimes = faTimes;
      faQuestionCircle = faQuestionCircle;
      constructor(fb, competencyService, translateService, lectureUnitService) {
        this.fb = fb;
        this.competencyService = competencyService;
        this.translateService = translateService;
        this.lectureUnitService = lectureUnitService;
      }
      get titleControl() {
        return this.form.get("title");
      }
      get descriptionControl() {
        return this.form.get("description");
      }
      get softDueDateControl() {
        return this.form.get("softDueDate");
      }
      get masteryThresholdControl() {
        return this.form.get("masteryThreshold");
      }
      get optionalControl() {
        return this.form.get("optional");
      }
      ngOnChanges() {
        this.initializeForm();
        if (this.isEditMode && this.formData) {
          this.setFormValues(this.formData);
        }
      }
      ngOnInit() {
        this.initializeForm();
      }
      initializeForm() {
        if (this.form) {
          return;
        }
        let initialTitle = void 0;
        if (this.isEditMode && this.formData && this.formData.title) {
          initialTitle = this.formData.title;
        }
        this.form = this.fb.group({
          title: [
            void 0,
            [Validators.required, Validators.maxLength(255)],
            [this.titleUniqueValidator(this.competencyService, this.courseId, initialTitle)]
          ],
          description: [void 0, [Validators.maxLength(1e4)]],
          softDueDate: [void 0],
          taxonomy: [void 0, [Validators.pattern("^(" + Object.keys(this.competencyTaxonomy).join("|") + ")$")]],
          masteryThreshold: [void 0, [Validators.min(0), Validators.max(100)]],
          optional: [false]
        });
        this.selectedLectureUnitsInTable = [];
        merge(this.titleControl.valueChanges, this.descriptionControl.valueChanges).subscribe(() => this.suggestTaxonomies());
        if (this.isInSingleLectureMode) {
          this.selectLectureInDropdown(this.lecturesOfCourseWithLectureUnits.first());
        }
      }
      setFormValues(formData) {
        this.form.patchValue(formData);
        if (formData.connectedLectureUnits) {
          this.selectedLectureUnitsInTable = formData.connectedLectureUnits;
        }
      }
      cancelForm() {
        this.onCancel.emit();
      }
      submitForm() {
        const competencyFormData = __spreadValues({}, this.form.value);
        competencyFormData.connectedLectureUnits = this.selectedLectureUnitsInTable;
        this.formSubmitted.emit(competencyFormData);
      }
      get isSubmitPossible() {
        return !this.form.invalid;
      }
      selectLectureInDropdown(lecture) {
        this.selectedLectureInDropdown = lecture;
      }
      keepOrder = () => {
        return 0;
      };
      suggestTaxonomies() {
        this.suggestedTaxonomies = [];
        const title = this.titleControl?.value?.toLowerCase() ?? "";
        const description = this.descriptionControl?.value?.toLowerCase() ?? "";
        for (const taxonomy in this.competencyTaxonomy) {
          const keywords = this.translateService.instant("artemisApp.competency.keywords." + taxonomy.toLowerCase()).split(", ");
          const taxonomyName = this.translateService.instant("artemisApp.competency.taxonomies." + taxonomy.toLowerCase());
          keywords.push(taxonomyName);
          if (keywords.map((keyword) => keyword.toLowerCase()).some((keyword) => title.includes(keyword) || description.includes(keyword))) {
            this.suggestedTaxonomies.push(taxonomyName);
          }
        }
      }
      selectLectureUnitInTable(lectureUnit) {
        if (this.isLectureUnitAlreadySelectedInTable(lectureUnit)) {
          this.selectedLectureUnitsInTable.forEach((selectedLectureUnit, index) => {
            if (selectedLectureUnit.id === lectureUnit.id) {
              this.selectedLectureUnitsInTable.splice(index, 1);
            }
          });
        } else {
          this.selectedLectureUnitsInTable.push(lectureUnit);
        }
      }
      isLectureUnitAlreadySelectedInTable(lectureUnit) {
        return this.selectedLectureUnitsInTable.map((selectedLectureUnit) => selectedLectureUnit.id).includes(lectureUnit.id);
      }
      getLectureTitleForDropdown(lecture) {
        const noOfSelectedUnitsInLecture = intersection(this.selectedLectureUnitsInTable.map((unit) => unit.id), lecture.lectureUnits?.map((unit) => unit.id)).length;
        return this.translateService.instant("artemisApp.competency.createCompetency.dropdown", {
          lectureTitle: lecture.title,
          noOfConnectedUnits: noOfSelectedUnitsInLecture
        });
      }
      static \u0275fac = function CompetencyFormComponent_Factory(t) {
        return new (t || _CompetencyFormComponent)(i02.\u0275\u0275directiveInject(i12.FormBuilder), i02.\u0275\u0275directiveInject(CompetencyService), i02.\u0275\u0275directiveInject(i32.TranslateService), i02.\u0275\u0275directiveInject(LectureUnitService));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _CompetencyFormComponent, selectors: [["jhi-competency-form"]], inputs: { formData: "formData", isEditMode: "isEditMode", isInConnectMode: "isInConnectMode", isInSingleLectureMode: "isInSingleLectureMode", courseId: "courseId", lecturesOfCourseWithLectureUnits: "lecturesOfCourseWithLectureUnits", averageStudentScore: "averageStudentScore", hasCancelButton: "hasCancelButton" }, outputs: { onCancel: "onCancel", formSubmitted: "formSubmitted" }, features: [i02.\u0275\u0275NgOnChangesFeature], decls: 7, vars: 1, consts: [[1, "row"], [1, "col-12"], [3, "formGroup", "ngSubmit"], [1, "form-group"], ["id", "softDueDate", "formControlName", "softDueDate", 3, "labelName", "labelTooltip"], ["type", "checkbox", "id", "optional", "formControlName", "optional", 1, "form-check-input"], ["jhiTranslate", "artemisApp.competency.optional", "for", "optional", 1, "form-control-label"], [1, "text-secondary", 3, "icon", "ngbTooltip"], ["noLectures", ""], ["id", "submitButton", "type", "submit", 1, "btn", "btn-primary", "me-2", 3, "disabled"], ["for", "title"], ["type", "text", "id", "title", "formControlName", "title", 1, "form-control", 3, "placeholder"], [1, "alert", "alert-danger"], ["for", "description"], ["id", "description", "rows", "6", "formControlName", "description", 1, "form-control", 3, "placeholder"], ["for", "taxonomy"], ["id", "taxonomy", "formControlName", "taxonomy", 1, "form-select", "mb-2"], ["selected", "", 3, "ngValue"], [3, "ngValue"], ["for", "masteryThreshold"], ["type", "range", "min", "0", "max", "100", "id", "masteryThreshold", "formControlName", "masteryThreshold", 1, "form-range"], ["ngbDropdown", "", 1, "mb-2", 3, "hidden"], ["ngbDropdownToggle", "", "type", "button", 1, "btn", "btn-outline-primary"], ["ngbDropdownMenu", ""], ["ngbDropdownItem", "", "type", "button", 3, "click"], [1, "alert", "alert-info"], [1, "table-responsive"], [1, "table", "table-bordered"], [1, "thead-dark"], [1, "lectureUnitRow", 3, "click"], ["type", "button", 1, "btn", "btn-default", 3, "click"], [3, "icon"], ["jhiTranslate", "entity.action.cancel"]], template: function CompetencyFormComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div", 0);
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275elementStart(2, "div", 1);
          i02.\u0275\u0275text(3, "\n        ");
          i02.\u0275\u0275template(4, CompetencyFormComponent_Conditional_4_Template, 49, 25);
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(5, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(6, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(4);
          i02.\u0275\u0275conditional(4, ctx.form ? 4 : -1);
        }
      }, dependencies: [i12.\u0275NgNoValidate, i12.NgSelectOption, i12.\u0275NgSelectMultipleOption, i12.DefaultValueAccessor, i12.RangeValueAccessor, i12.CheckboxControlValueAccessor, i12.SelectControlValueAccessor, i12.NgControlStatus, i12.NgControlStatusGroup, i5.NgbDropdown, i5.NgbDropdownToggle, i5.NgbDropdownMenu, i5.NgbDropdownItem, i5.NgbDropdownButtonItem, i5.NgbTooltip, i6.FaIconComponent, i12.FormGroupDirective, i12.FormControlName, TranslateDirective, FormDateTimePickerComponent, i9.KeyValuePipe, ArtemisTranslatePipe], styles: ["\n\ntr[_ngcontent-%COMP%]:hover {\n  background-color: lightgray;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvY29tcGV0ZW5jaWVzL2NvbXBldGVuY3ktZm9ybS9jb21wZXRlbmN5LWZvcm0uY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbInRyOmhvdmVyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBsaWdodGdyYXk7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsRUFBQTtBQUNJLG9CQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(CompetencyFormComponent, { className: "CompetencyFormComponent" });
    })();
  }
});

// src/main/webapp/app/course/competencies/create-competency/create-competency.component.ts
import { Component as Component3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute, Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { finalize, switchMap as switchMap2, take } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function CreateCompetencyComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n    ");
    i03.\u0275\u0275elementStart(1, "div", 0);
    i03.\u0275\u0275text(2, "\n        ");
    i03.\u0275\u0275elementStart(3, "div", 1);
    i03.\u0275\u0275text(4, "\n            ");
    i03.\u0275\u0275elementStart(5, "span", 2);
    i03.\u0275\u0275text(6);
    i03.\u0275\u0275pipe(7, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(9, "\n    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(10, "\n");
  }
  if (rf & 2) {
    i03.\u0275\u0275advance(6);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(7, 1, "loading"));
  }
}
function CreateCompetencyComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n    ");
    i03.\u0275\u0275elementStart(1, "div", 3);
    i03.\u0275\u0275text(2, "\n        ");
    i03.\u0275\u0275elementStart(3, "div", 4);
    i03.\u0275\u0275text(4, "\n            ");
    i03.\u0275\u0275elementStart(5, "h3");
    i03.\u0275\u0275text(6);
    i03.\u0275\u0275pipe(7, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n            ");
    i03.\u0275\u0275element(9, "jhi-documentation-button", 5);
    i03.\u0275\u0275text(10, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(11, "\n        ");
    i03.\u0275\u0275elementStart(12, "jhi-competency-form", 6);
    i03.\u0275\u0275listener("formSubmitted", function CreateCompetencyComponent_Conditional_1_Template_jhi_competency_form_formSubmitted_12_listener($event) {
      i03.\u0275\u0275restoreView(_r3);
      const ctx_r2 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r2.createCompetency($event));
    });
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(13, "\n    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(14, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(6);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(7, 5, "artemisApp.competency.createCompetency.title"));
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("type", ctx_r1.documentationType);
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("isEditMode", false)("courseId", ctx_r1.courseId)("lecturesOfCourseWithLectureUnits", ctx_r1.lecturesWithLectureUnits);
  }
}
var CreateCompetencyComponent;
var init_create_competency_component = __esm({
  "src/main/webapp/app/course/competencies/create-competency/create-competency.component.ts"() {
    init_global_utils();
    init_competency_model();
    init_alert_service();
    init_competency_service();
    init_lecture_service();
    init_competency_service();
    init_alert_service();
    init_lecture_service();
    init_documentation_button_component();
    init_competency_form_component();
    init_artemis_translate_pipe();
    CreateCompetencyComponent = class _CreateCompetencyComponent {
      activatedRoute;
      router;
      competencyService;
      alertService;
      lectureService;
      documentationType = "Competencies";
      competencyToCreate = new Competency();
      isLoading;
      courseId;
      lecturesWithLectureUnits = [];
      constructor(activatedRoute, router, competencyService, alertService, lectureService) {
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.competencyService = competencyService;
        this.alertService = alertService;
        this.lectureService = lectureService;
      }
      ngOnInit() {
        this.competencyToCreate = new Competency();
        this.isLoading = true;
        this.activatedRoute.parent.parent.paramMap.pipe(take(1), switchMap2((params) => {
          this.courseId = Number(params.get("courseId"));
          return this.lectureService.findAllByCourseId(this.courseId, true);
        }), finalize(() => {
          this.isLoading = false;
        })).subscribe({
          next: (lectureResult) => {
            if (lectureResult.body) {
              this.lecturesWithLectureUnits = lectureResult.body;
              for (const lecture of this.lecturesWithLectureUnits) {
                if (!lecture.lectureUnits) {
                  lecture.lectureUnits = [];
                }
              }
            }
          },
          error: (res) => onError(this.alertService, res)
        });
      }
      createCompetency(formData) {
        if (!formData?.title) {
          return;
        }
        const { title, description, softDueDate, taxonomy, masteryThreshold, optional, connectedLectureUnits } = formData;
        this.competencyToCreate.title = title;
        this.competencyToCreate.description = description;
        this.competencyToCreate.softDueDate = softDueDate;
        this.competencyToCreate.taxonomy = taxonomy;
        this.competencyToCreate.masteryThreshold = masteryThreshold;
        this.competencyToCreate.optional = optional;
        this.competencyToCreate.lectureUnits = connectedLectureUnits;
        this.isLoading = true;
        this.competencyService.create(this.competencyToCreate, this.courseId).pipe(finalize(() => {
          this.isLoading = false;
        })).subscribe({
          next: () => {
            this.router.navigate(["../"], { relativeTo: this.activatedRoute });
          },
          error: (res) => onError(this.alertService, res)
        });
      }
      static \u0275fac = function CreateCompetencyComponent_Factory(t) {
        return new (t || _CreateCompetencyComponent)(i03.\u0275\u0275directiveInject(i13.ActivatedRoute), i03.\u0275\u0275directiveInject(i13.Router), i03.\u0275\u0275directiveInject(CompetencyService), i03.\u0275\u0275directiveInject(AlertService), i03.\u0275\u0275directiveInject(LectureService));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _CreateCompetencyComponent, selectors: [["jhi-create-competency"]], decls: 2, vars: 2, consts: [[1, "d-flex", "justify-content-center"], ["role", "status", 1, "spinner-border"], [1, "sr-only"], [1, "container"], [1, "d-flex", "align-items-center"], [3, "type"], [3, "isEditMode", "courseId", "lecturesOfCourseWithLectureUnits", "formSubmitted"]], template: function CreateCompetencyComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275template(0, CreateCompetencyComponent_Conditional_0_Template, 11, 3)(1, CreateCompetencyComponent_Conditional_1_Template, 15, 7);
        }
        if (rf & 2) {
          i03.\u0275\u0275conditional(0, ctx.isLoading ? 0 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(1, !ctx.isLoading ? 1 : -1);
        }
      }, dependencies: [DocumentationButtonComponent, CompetencyFormComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(CreateCompetencyComponent, { className: "CreateCompetencyComponent" });
    })();
  }
});

// src/main/webapp/app/course/competencies/edit-competency/edit-competency.component.ts
import { Component as Component4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute3, Router as Router3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { finalize as finalize2, switchMap as switchMap3, take as take2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { combineLatest, forkJoin } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i14 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function EditCompetencyComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n    ");
    i04.\u0275\u0275elementStart(1, "div", 0);
    i04.\u0275\u0275text(2, "\n        ");
    i04.\u0275\u0275elementStart(3, "div", 1);
    i04.\u0275\u0275text(4, "\n            ");
    i04.\u0275\u0275elementStart(5, "span", 2);
    i04.\u0275\u0275text(6);
    i04.\u0275\u0275pipe(7, "artemisTranslate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(8, "\n        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(9, "\n    ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n");
  }
  if (rf & 2) {
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(7, 1, "loading"));
  }
}
function EditCompetencyComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n    ");
    i04.\u0275\u0275elementStart(1, "div", 3);
    i04.\u0275\u0275text(2, "\n        ");
    i04.\u0275\u0275elementStart(3, "h3");
    i04.\u0275\u0275text(4);
    i04.\u0275\u0275pipe(5, "artemisTranslate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(6, "\n        ");
    i04.\u0275\u0275elementStart(7, "jhi-competency-form", 4);
    i04.\u0275\u0275listener("formSubmitted", function EditCompetencyComponent_Conditional_1_Template_jhi_competency_form_formSubmitted_7_listener($event) {
      i04.\u0275\u0275restoreView(_r3);
      const ctx_r2 = i04.\u0275\u0275nextContext();
      return i04.\u0275\u0275resetView(ctx_r2.updateCompetency($event));
    });
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(8, "\n    ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(9, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i04.\u0275\u0275nextContext();
    let tmp_5_0;
    i04.\u0275\u0275advance(4);
    i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(5, 6, "artemisApp.competency.editCompetency.title"));
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("isEditMode", true)("formData", ctx_r1.formData)("courseId", ctx_r1.courseId)("lecturesOfCourseWithLectureUnits", ctx_r1.lecturesWithLectureUnits)("averageStudentScore", (tmp_5_0 = ctx_r1.competency == null ? null : ctx_r1.competency.courseProgress == null ? null : ctx_r1.competency.courseProgress.averageStudentScore) !== null && tmp_5_0 !== void 0 ? tmp_5_0 : 0);
  }
}
var EditCompetencyComponent;
var init_edit_competency_component = __esm({
  "src/main/webapp/app/course/competencies/edit-competency/edit-competency.component.ts"() {
    init_global_utils();
    init_alert_service();
    init_competency_service();
    init_lecture_service();
    init_lectureUnit_model();
    init_lecture_service();
    init_competency_service();
    init_alert_service();
    init_competency_form_component();
    init_artemis_translate_pipe();
    EditCompetencyComponent = class _EditCompetencyComponent {
      activatedRoute;
      lectureService;
      router;
      competencyService;
      alertService;
      isLoading = false;
      competency;
      lecturesWithLectureUnits = [];
      formData;
      courseId;
      constructor(activatedRoute, lectureService, router, competencyService, alertService) {
        this.activatedRoute = activatedRoute;
        this.lectureService = lectureService;
        this.router = router;
        this.competencyService = competencyService;
        this.alertService = alertService;
      }
      ngOnInit() {
        this.isLoading = true;
        combineLatest([this.activatedRoute.paramMap, this.activatedRoute.parent.parent.paramMap]).pipe(take2(1), switchMap3(([params, parentParams]) => {
          const competencyId = Number(params.get("competencyId"));
          this.courseId = Number(parentParams.get("courseId"));
          const competencyObservable = this.competencyService.findById(competencyId, this.courseId);
          const competencyCourseProgressObservable = this.competencyService.getCourseProgress(competencyId, this.courseId);
          const lecturesObservable = this.lectureService.findAllByCourseId(this.courseId, true);
          return forkJoin([competencyObservable, competencyCourseProgressObservable, lecturesObservable]);
        }), finalize2(() => this.isLoading = false)).subscribe({
          next: ([competencyResult, courseProgressResult, lecturesResult]) => {
            if (competencyResult.body) {
              this.competency = competencyResult.body;
              if (courseProgressResult.body) {
                this.competency.courseProgress = courseProgressResult.body;
              }
              if (!this.competency.lectureUnits) {
                this.competency.lectureUnits = [];
              }
            }
            if (lecturesResult.body) {
              this.lecturesWithLectureUnits = lecturesResult.body;
              for (const lecture of this.lecturesWithLectureUnits) {
                if (!lecture.lectureUnits) {
                  lecture.lectureUnits = [];
                } else {
                  lecture.lectureUnits = lecture.lectureUnits.filter((lectureUnit) => lectureUnit.type !== LectureUnitType.EXERCISE);
                }
              }
            }
            this.formData = {
              id: this.competency.id,
              title: this.competency.title,
              description: this.competency.description,
              softDueDate: this.competency.softDueDate,
              connectedLectureUnits: this.competency.lectureUnits,
              taxonomy: this.competency.taxonomy,
              masteryThreshold: this.competency.masteryThreshold,
              optional: this.competency.optional
            };
          },
          error: (res) => onError(this.alertService, res)
        });
      }
      updateCompetency(formData) {
        const { title, description, softDueDate, taxonomy, masteryThreshold, optional, connectedLectureUnits } = formData;
        this.competency.title = title;
        this.competency.description = description;
        this.competency.softDueDate = softDueDate;
        this.competency.taxonomy = taxonomy;
        this.competency.masteryThreshold = masteryThreshold;
        this.competency.optional = optional;
        this.competency.lectureUnits = connectedLectureUnits;
        this.isLoading = true;
        this.competencyService.update(this.competency, this.courseId).pipe(finalize2(() => {
          this.isLoading = false;
          this.router.navigate(["../../"], { relativeTo: this.activatedRoute });
        })).subscribe({
          error: (res) => onError(this.alertService, res)
        });
      }
      static \u0275fac = function EditCompetencyComponent_Factory(t) {
        return new (t || _EditCompetencyComponent)(i04.\u0275\u0275directiveInject(i14.ActivatedRoute), i04.\u0275\u0275directiveInject(LectureService), i04.\u0275\u0275directiveInject(i14.Router), i04.\u0275\u0275directiveInject(CompetencyService), i04.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _EditCompetencyComponent, selectors: [["jhi-edit-competency"]], decls: 2, vars: 2, consts: [[1, "d-flex", "justify-content-center"], ["role", "status", 1, "spinner-border"], [1, "sr-only"], [1, "container"], [3, "isEditMode", "formData", "courseId", "lecturesOfCourseWithLectureUnits", "averageStudentScore", "formSubmitted"]], template: function EditCompetencyComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275template(0, EditCompetencyComponent_Conditional_0_Template, 11, 3)(1, EditCompetencyComponent_Conditional_1_Template, 10, 8);
        }
        if (rf & 2) {
          i04.\u0275\u0275conditional(0, ctx.isLoading ? 0 : -1);
          i04.\u0275\u0275advance(1);
          i04.\u0275\u0275conditional(1, !ctx.isLoading ? 1 : -1);
        }
      }, dependencies: [CompetencyFormComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(EditCompetencyComponent, { className: "EditCompetencyComponent" });
    })();
  }
});

// src/main/webapp/app/course/competencies/competency-paging.service.ts
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { map as map2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i15 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var CompetencyPagingService;
var init_competency_paging_service = __esm({
  "src/main/webapp/app/course/competencies/competency-paging.service.ts"() {
    init_paging_service();
    CompetencyPagingService = class _CompetencyPagingService extends PagingService {
      http;
      resourceUrl = "api/competencies";
      constructor(http) {
        super();
        this.http = http;
      }
      searchForCompetencies(pageable) {
        const params = this.createHttpParams(pageable);
        return this.http.get(`${this.resourceUrl}`, { params, observe: "response" }).pipe(map2((resp) => resp && resp.body));
      }
      static \u0275fac = function CompetencyPagingService_Factory(t) {
        return new (t || _CompetencyPagingService)(i05.\u0275\u0275inject(i15.HttpClient));
      };
      static \u0275prov = i05.\u0275\u0275defineInjectable({ token: _CompetencyPagingService, factory: _CompetencyPagingService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/shared/import/import-component.ts
import { Component as Component5, Input as Input3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { NgbActiveModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { Router as Router5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { faCheck, faSort } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i16 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
var TableColumn, ImportComponent;
var init_import_component = __esm({
  "src/main/webapp/app/shared/import/import-component.ts"() {
    init_pageable_table();
    init_sort_service();
    init_competency_paging_service();
    init_competency_paging_service();
    init_sort_service();
    (function(TableColumn2) {
      TableColumn2["ID"] = "ID";
      TableColumn2["TITLE"] = "TITLE";
      TableColumn2["COURSE_TITLE"] = "COURSE_TITLE";
      TableColumn2["SEMESTER"] = "SEMESTER";
    })(TableColumn || (TableColumn = {}));
    ImportComponent = class _ImportComponent {
      router;
      pagingService;
      sortService;
      activeModal;
      column = TableColumn;
      loading = false;
      content;
      total = 0;
      state = {
        page: 1,
        pageSize: 10,
        searchTerm: "",
        sortingOrder: SortingOrder.DESCENDING,
        sortedColumn: TableColumn.ID
      };
      faSort = faSort;
      faCheck = faCheck;
      search = new Subject();
      sort = new Subject();
      disabledIds;
      constructor(router, pagingService, sortService, activeModal) {
        this.router = router;
        this.pagingService = pagingService;
        this.sortService = sortService;
        this.activeModal = activeModal;
      }
      get page() {
        return this.state.page;
      }
      set page(page) {
        this.setSearchParam({ page });
      }
      get listSorting() {
        return this.state.sortingOrder === SortingOrder.ASCENDING;
      }
      set listSorting(ascending) {
        const sortingOrder = ascending ? SortingOrder.ASCENDING : SortingOrder.DESCENDING;
        this.setSearchParam({ sortingOrder });
      }
      get sortedColumn() {
        return this.state.sortedColumn;
      }
      set sortedColumn(sortedColumn) {
        this.setSearchParam({ sortedColumn });
      }
      get searchTerm() {
        return this.state.searchTerm;
      }
      set searchTerm(searchTerm) {
        this.state.searchTerm = searchTerm;
        this.search.next();
      }
      ngOnInit() {
        this.content = { resultsOnPage: [], numberOfPages: 0 };
        this.performSearch(this.sort, 0);
        this.performSearch(this.search, 300);
      }
      sortRows() {
        this.sortService.sortByProperty(this.content.resultsOnPage, this.sortedColumn, this.listSorting);
      }
      trackId(index, item) {
        return item.id;
      }
      selectImport(item) {
        this.activeModal.close(item);
      }
      clear() {
        this.activeModal.dismiss("cancel");
      }
      onPageChange(pageNumber) {
        if (pageNumber) {
          this.page = pageNumber;
        }
      }
      setSearchParam(patch) {
        Object.assign(this.state, patch);
        this.sort.next();
      }
      static \u0275fac = function ImportComponent_Factory(t) {
        return new (t || _ImportComponent)(i06.\u0275\u0275directiveInject(i16.Router), i06.\u0275\u0275directiveInject(CompetencyPagingService), i06.\u0275\u0275directiveInject(SortService), i06.\u0275\u0275directiveInject(i4.NgbActiveModal));
      };
      static \u0275cmp = i06.\u0275\u0275defineComponent({ type: _ImportComponent, selectors: [["ng-component"]], inputs: { disabledIds: "disabledIds" }, decls: 0, vars: 0, template: function ImportComponent_Template(rf, ctx) {
      }, encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i06.\u0275setClassDebugInfo(ImportComponent, { className: "ImportComponent" });
    })();
  }
});

// src/main/webapp/app/course/competencies/competency-management/competency-import.component.ts
import { Component as Component6 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { debounceTime, switchMap as switchMap4, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i17 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i33 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function CompetencyImportComponent_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275elementStart(1, "span", 20);
    i07.\u0275\u0275text(2, "Loading...");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n            ");
  }
}
function CompetencyImportComponent_For_66_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                    ");
    i07.\u0275\u0275elementStart(1, "tr", 21);
    i07.\u0275\u0275text(2, "\n                        ");
    i07.\u0275\u0275elementStart(3, "td", 17);
    i07.\u0275\u0275text(4, "\n                            ");
    i07.\u0275\u0275elementStart(5, "span");
    i07.\u0275\u0275text(6);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(7, "\n                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(8, "\n                        ");
    i07.\u0275\u0275elementStart(9, "td", 22);
    i07.\u0275\u0275text(10, "\n                            ");
    i07.\u0275\u0275element(11, "ngb-highlight", 23);
    i07.\u0275\u0275text(12, "\n                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(13, "\n                        ");
    i07.\u0275\u0275elementStart(14, "td", 22);
    i07.\u0275\u0275text(15, "\n                            ");
    i07.\u0275\u0275element(16, "ngb-highlight", 23);
    i07.\u0275\u0275text(17, "\n                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(18, "\n                        ");
    i07.\u0275\u0275elementStart(19, "td", 24);
    i07.\u0275\u0275text(20, "\n                            ");
    i07.\u0275\u0275elementStart(21, "span");
    i07.\u0275\u0275text(22);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(23, "\n                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(24, "\n                        ");
    i07.\u0275\u0275elementStart(25, "td", 17);
    i07.\u0275\u0275text(26, "\n                            ");
    i07.\u0275\u0275elementStart(27, "jhi-button", 25);
    i07.\u0275\u0275listener("onClick", function CompetencyImportComponent_For_66_Template_jhi_button_onClick_27_listener() {
      const restoredCtx = i07.\u0275\u0275restoreView(_r8);
      const competency_r2 = restoredCtx.$implicit;
      const ctx_r7 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r7.selectImport(competency_r2));
    });
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(28, "\n                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(29, "\n                    ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(30, "\n                ");
  }
  if (rf & 2) {
    const competency_r2 = ctx.$implicit;
    const ctx_r1 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(6);
    i07.\u0275\u0275textInterpolate(competency_r2.id);
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275property("result", competency_r2.title)("term", ctx_r1.searchTerm);
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275property("result", competency_r2.course == null ? null : competency_r2.course.title)("term", ctx_r1.searchTerm);
    i07.\u0275\u0275advance(6);
    i07.\u0275\u0275textInterpolate((competency_r2.course == null ? null : competency_r2.course.semester) || "");
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275property("disabled", ctx_r1.disabledIds.includes(competency_r2.id))("title", "artemisApp.competency.importCompetency.table.doSelect");
  }
}
var CompetencyImportComponent;
var init_competency_import_component = __esm({
  "src/main/webapp/app/course/competencies/competency-management/competency-import.component.ts"() {
    init_import_component();
    init_translate_directive();
    init_sort_by_directive();
    init_sort_directive();
    init_button_component();
    CompetencyImportComponent = class _CompetencyImportComponent extends ImportComponent {
      performSearch(searchSubject, debounce) {
        searchSubject.pipe(debounceTime(debounce), tap(() => this.loading = true), switchMap4(() => this.pagingService.searchForCompetencies(this.state))).subscribe((resp) => {
          this.content = resp;
          this.loading = false;
          this.total = resp.numberOfPages * this.state.pageSize;
        });
      }
      static \u0275fac = (() => {
        let \u0275CompetencyImportComponent_BaseFactory;
        return function CompetencyImportComponent_Factory(t) {
          return (\u0275CompetencyImportComponent_BaseFactory || (\u0275CompetencyImportComponent_BaseFactory = i07.\u0275\u0275getInheritedFactory(_CompetencyImportComponent)))(t || _CompetencyImportComponent);
        };
      })();
      static \u0275cmp = i07.\u0275\u0275defineComponent({ type: _CompetencyImportComponent, selectors: [["jhi-competency-import"]], features: [i07.\u0275\u0275InheritDefinitionFeature], decls: 77, vars: 17, consts: [[1, "modal-header"], ["jhiTranslate", "artemisApp.competency.importCompetency.title", 1, "modal-title"], ["aria-hidden", "true", "data-dismiss", "modal", "type", "button", 1, "btn-close", 3, "click"], [1, "modal-body"], [1, "form-group", "form-inline"], ["jhiTranslate", "artemisApp.competency.importCompetency.search"], ["name", "searchCompetency", "type", "text", 1, "form-control", "ms-2", 3, "ngModel", "ngModelChange"], [1, "table", "table-striped", "align-middle", "flex"], [1, "thead-dark"], ["jhiSort", "", 1, "flex-row", 3, "ascending", "predicate", "sortChange", "ascendingChange", "predicateChange"], [1, "col-1", 3, "jhiSortBy"], [3, "icon"], [1, "col-4", 3, "jhiSortBy"], ["jhiTranslate", "artemisApp.competency.importCompetency.table.title"], ["jhiTranslate", "artemisApp.competency.importCompetency.table.course"], [1, "col-2", 3, "jhiSortBy"], ["jhiTranslate", "artemisApp.competency.importCompetency.table.semester"], [1, "col-1"], [1, "d-flex", "justify-content-between", "p-2"], [3, "page", "collectionSize", "maxSize", "pageSize", "rotate", "pageChange"], ["jhiTranslate", "artemisApp.competency.importCompetency.loading", 1, "ms-3"], [1, "flex-row"], [1, "text-break", "col-4"], [3, "result", "term"], [1, "col-2"], [3, "disabled", "title", "onClick"]], template: function CompetencyImportComponent_Template(rf, ctx) {
        if (rf & 1) {
          i07.\u0275\u0275elementStart(0, "form");
          i07.\u0275\u0275text(1, "\n    ");
          i07.\u0275\u0275elementStart(2, "div", 0);
          i07.\u0275\u0275text(3, "\n        ");
          i07.\u0275\u0275elementStart(4, "h4", 1);
          i07.\u0275\u0275text(5, "Import a Competency");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(6, "\n        ");
          i07.\u0275\u0275elementStart(7, "button", 2);
          i07.\u0275\u0275listener("click", function CompetencyImportComponent_Template_button_click_7_listener() {
            return ctx.clear();
          });
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(8, "\n    ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(9, "\n    ");
          i07.\u0275\u0275elementStart(10, "div", 3);
          i07.\u0275\u0275text(11, "\n        ");
          i07.\u0275\u0275elementStart(12, "div", 4);
          i07.\u0275\u0275text(13, "\n            ");
          i07.\u0275\u0275elementStart(14, "span", 5);
          i07.\u0275\u0275text(15, "Search for competency:");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(16, "\n            ");
          i07.\u0275\u0275elementStart(17, "input", 6);
          i07.\u0275\u0275listener("ngModelChange", function CompetencyImportComponent_Template_input_ngModelChange_17_listener($event) {
            return ctx.searchTerm = $event;
          });
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(18, "\n            ");
          i07.\u0275\u0275template(19, CompetencyImportComponent_Conditional_19_Template, 4, 0);
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(20, "\n        ");
          i07.\u0275\u0275elementStart(21, "table", 7);
          i07.\u0275\u0275text(22, "\n            ");
          i07.\u0275\u0275elementStart(23, "thead", 8);
          i07.\u0275\u0275text(24, "\n                ");
          i07.\u0275\u0275elementStart(25, "tr", 9);
          i07.\u0275\u0275listener("sortChange", function CompetencyImportComponent_Template_tr_sortChange_25_listener() {
            return ctx.sortRows();
          })("ascendingChange", function CompetencyImportComponent_Template_tr_ascendingChange_25_listener($event) {
            return ctx.listSorting = $event;
          })("predicateChange", function CompetencyImportComponent_Template_tr_predicateChange_25_listener($event) {
            return ctx.sortedColumn = $event;
          });
          i07.\u0275\u0275text(26, "\n                    ");
          i07.\u0275\u0275elementStart(27, "th", 10);
          i07.\u0275\u0275text(28, "\n                        ");
          i07.\u0275\u0275elementStart(29, "span");
          i07.\u0275\u0275text(30, "#");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(31, "\n                        ");
          i07.\u0275\u0275element(32, "fa-icon", 11);
          i07.\u0275\u0275text(33, "\n                    ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(34, "\n                    ");
          i07.\u0275\u0275elementStart(35, "th", 12);
          i07.\u0275\u0275text(36, "\n                        ");
          i07.\u0275\u0275elementStart(37, "span", 13);
          i07.\u0275\u0275text(38, "Title");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(39, "\n                        ");
          i07.\u0275\u0275element(40, "fa-icon", 11);
          i07.\u0275\u0275text(41, "\n                    ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(42, "\n                    ");
          i07.\u0275\u0275elementStart(43, "th", 12);
          i07.\u0275\u0275text(44, "\n                        ");
          i07.\u0275\u0275elementStart(45, "span", 14);
          i07.\u0275\u0275text(46, "Course");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(47, "\n                        ");
          i07.\u0275\u0275element(48, "fa-icon", 11);
          i07.\u0275\u0275text(49, "\n                    ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(50, "\n                    ");
          i07.\u0275\u0275elementStart(51, "th", 15);
          i07.\u0275\u0275text(52, "\n                        ");
          i07.\u0275\u0275elementStart(53, "span", 16);
          i07.\u0275\u0275text(54, "Semester");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(55, "\n                        ");
          i07.\u0275\u0275element(56, "fa-icon", 11);
          i07.\u0275\u0275text(57, "\n                    ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(58, "\n                    ");
          i07.\u0275\u0275element(59, "th", 17);
          i07.\u0275\u0275text(60, "\n                ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(61, "\n            ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(62, "\n            ");
          i07.\u0275\u0275elementStart(63, "tbody");
          i07.\u0275\u0275text(64, "\n                ");
          i07.\u0275\u0275repeaterCreate(65, CompetencyImportComponent_For_66_Template, 31, 8, null, null, ctx.trackId);
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(67, "\n        ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(68, "\n        ");
          i07.\u0275\u0275elementStart(69, "div", 18);
          i07.\u0275\u0275text(70, "\n            ");
          i07.\u0275\u0275elementStart(71, "ngb-pagination", 19);
          i07.\u0275\u0275listener("pageChange", function CompetencyImportComponent_Template_ngb_pagination_pageChange_71_listener($event) {
            return ctx.onPageChange($event);
          })("pageChange", function CompetencyImportComponent_Template_ngb_pagination_pageChange_71_listener($event) {
            return ctx.state.page = $event;
          });
          i07.\u0275\u0275text(72, "\n            ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(73, "\n        ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(74, "\n    ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(75, "\n");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(76, "\n");
        }
        if (rf & 2) {
          i07.\u0275\u0275advance(17);
          i07.\u0275\u0275property("ngModel", ctx.searchTerm);
          i07.\u0275\u0275advance(2);
          i07.\u0275\u0275conditional(19, ctx.loading ? 19 : -1);
          i07.\u0275\u0275advance(6);
          i07.\u0275\u0275property("ascending", ctx.listSorting)("predicate", ctx.sortedColumn);
          i07.\u0275\u0275advance(2);
          i07.\u0275\u0275propertyInterpolate("jhiSortBy", ctx.column.ID);
          i07.\u0275\u0275advance(5);
          i07.\u0275\u0275property("icon", ctx.faSort);
          i07.\u0275\u0275advance(3);
          i07.\u0275\u0275propertyInterpolate("jhiSortBy", ctx.column.TITLE);
          i07.\u0275\u0275advance(5);
          i07.\u0275\u0275property("icon", ctx.faSort);
          i07.\u0275\u0275advance(3);
          i07.\u0275\u0275propertyInterpolate("jhiSortBy", ctx.column.COURSE_TITLE);
          i07.\u0275\u0275advance(5);
          i07.\u0275\u0275property("icon", ctx.faSort);
          i07.\u0275\u0275advance(3);
          i07.\u0275\u0275propertyInterpolate("jhiSortBy", ctx.column.SEMESTER);
          i07.\u0275\u0275advance(5);
          i07.\u0275\u0275property("icon", ctx.faSort);
          i07.\u0275\u0275advance(9);
          i07.\u0275\u0275repeater(ctx.content.resultsOnPage);
          i07.\u0275\u0275advance(6);
          i07.\u0275\u0275property("page", ctx.state.page)("collectionSize", ctx.total)("maxSize", 10)("pageSize", ctx.state.pageSize)("rotate", true);
        }
      }, dependencies: [i17.\u0275NgNoValidate, i17.DefaultValueAccessor, i17.NgControlStatus, i17.NgControlStatusGroup, i17.NgModel, i17.NgForm, i22.NgbPagination, i22.NgbHighlight, i33.FaIconComponent, TranslateDirective, SortByDirective, SortDirective, ButtonComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i07.\u0275setClassDebugInfo(CompetencyImportComponent, { className: "CompetencyImportComponent" });
    })();
  }
});

// src/main/webapp/app/course/competencies/competency-management/prerequisite-import.component.ts
import { Component as Component7 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i08 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i18 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i23 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i34 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function PrerequisiteImportComponent_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275elementStart(1, "span", 20);
    i08.\u0275\u0275text(2, "Loading...");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(3, "\n            ");
  }
}
function PrerequisiteImportComponent_For_66_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                    ");
    i08.\u0275\u0275elementStart(1, "tr", 21);
    i08.\u0275\u0275text(2, "\n                        ");
    i08.\u0275\u0275elementStart(3, "td", 17);
    i08.\u0275\u0275text(4, "\n                            ");
    i08.\u0275\u0275elementStart(5, "span");
    i08.\u0275\u0275text(6);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(8, "\n                        ");
    i08.\u0275\u0275elementStart(9, "td", 22);
    i08.\u0275\u0275text(10, "\n                            ");
    i08.\u0275\u0275element(11, "ngb-highlight", 23);
    i08.\u0275\u0275text(12, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(13, "\n                        ");
    i08.\u0275\u0275elementStart(14, "td", 22);
    i08.\u0275\u0275text(15, "\n                            ");
    i08.\u0275\u0275element(16, "ngb-highlight", 23);
    i08.\u0275\u0275text(17, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(18, "\n                        ");
    i08.\u0275\u0275elementStart(19, "td", 24);
    i08.\u0275\u0275text(20, "\n                            ");
    i08.\u0275\u0275elementStart(21, "span");
    i08.\u0275\u0275text(22);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(23, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(24, "\n                        ");
    i08.\u0275\u0275elementStart(25, "td", 17);
    i08.\u0275\u0275text(26, "\n                            ");
    i08.\u0275\u0275elementStart(27, "jhi-button", 25);
    i08.\u0275\u0275listener("onClick", function PrerequisiteImportComponent_For_66_Template_jhi_button_onClick_27_listener() {
      const restoredCtx = i08.\u0275\u0275restoreView(_r8);
      const competency_r2 = restoredCtx.$implicit;
      const ctx_r7 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r7.selectImport(competency_r2));
    });
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(28, "\n                        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(29, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(30, "\n                ");
  }
  if (rf & 2) {
    const competency_r2 = ctx.$implicit;
    const ctx_r1 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(6);
    i08.\u0275\u0275textInterpolate(competency_r2.id);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275property("result", competency_r2.title)("term", ctx_r1.searchTerm);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275property("result", competency_r2.course == null ? null : competency_r2.course.title)("term", ctx_r1.searchTerm);
    i08.\u0275\u0275advance(6);
    i08.\u0275\u0275textInterpolate((competency_r2.course == null ? null : competency_r2.course.semester) || "");
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275property("disabled", ctx_r1.disabledIds.includes(competency_r2.id))("title", "artemisApp.competency.prerequisite.import.table.doSelect");
  }
}
var PrerequisiteImportComponent;
var init_prerequisite_import_component = __esm({
  "src/main/webapp/app/course/competencies/competency-management/prerequisite-import.component.ts"() {
    init_competency_import_component();
    init_translate_directive();
    init_sort_by_directive();
    init_sort_directive();
    init_button_component();
    PrerequisiteImportComponent = class _PrerequisiteImportComponent extends CompetencyImportComponent {
      static \u0275fac = (() => {
        let \u0275PrerequisiteImportComponent_BaseFactory;
        return function PrerequisiteImportComponent_Factory(t) {
          return (\u0275PrerequisiteImportComponent_BaseFactory || (\u0275PrerequisiteImportComponent_BaseFactory = i08.\u0275\u0275getInheritedFactory(_PrerequisiteImportComponent)))(t || _PrerequisiteImportComponent);
        };
      })();
      static \u0275cmp = i08.\u0275\u0275defineComponent({ type: _PrerequisiteImportComponent, selectors: [["jhi-prerequisite-import"]], features: [i08.\u0275\u0275InheritDefinitionFeature], decls: 77, vars: 17, consts: [[1, "modal-header"], ["jhiTranslate", "artemisApp.competency.prerequisite.import.title", 1, "modal-title"], ["aria-hidden", "true", "data-dismiss", "modal", "type", "button", 1, "btn-close", 3, "click"], [1, "modal-body"], [1, "form-group", "form-inline"], ["jhiTranslate", "artemisApp.competency.prerequisite.import.searchCompetency"], ["name", "searchCompetency", "type", "text", 1, "form-control", "ms-2", 3, "ngModel", "ngModelChange"], [1, "table", "table-striped", "align-middle", "flex"], [1, "thead-dark"], ["jhiSort", "", 1, "flex-row", 3, "ascending", "predicate", "sortChange", "ascendingChange", "predicateChange"], [1, "col-1", 3, "jhiSortBy"], [3, "icon"], [1, "col-4", 3, "jhiSortBy"], ["jhiTranslate", "artemisApp.competency.prerequisite.import.table.title"], ["jhiTranslate", "artemisApp.competency.prerequisite.import.table.course"], [1, "col-2", 3, "jhiSortBy"], ["jhiTranslate", "artemisApp.competency.prerequisite.import.table.semester"], [1, "col-1"], [1, "d-flex", "justify-content-between", "p-2"], [3, "page", "collectionSize", "maxSize", "pageSize", "rotate", "pageChange"], ["jhiTranslate", "artemisApp.competency.prerequisite.import.loading", 1, "ms-3"], [1, "flex-row"], [1, "text-break", "col-4"], [3, "result", "term"], [1, "col-2"], [3, "disabled", "title", "onClick"]], template: function PrerequisiteImportComponent_Template(rf, ctx) {
        if (rf & 1) {
          i08.\u0275\u0275elementStart(0, "form");
          i08.\u0275\u0275text(1, "\n    ");
          i08.\u0275\u0275elementStart(2, "div", 0);
          i08.\u0275\u0275text(3, "\n        ");
          i08.\u0275\u0275elementStart(4, "h4", 1);
          i08.\u0275\u0275text(5, "Select Prerequisite");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(6, "\n        ");
          i08.\u0275\u0275elementStart(7, "button", 2);
          i08.\u0275\u0275listener("click", function PrerequisiteImportComponent_Template_button_click_7_listener() {
            return ctx.clear();
          });
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(8, "\n    ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(9, "\n    ");
          i08.\u0275\u0275elementStart(10, "div", 3);
          i08.\u0275\u0275text(11, "\n        ");
          i08.\u0275\u0275elementStart(12, "div", 4);
          i08.\u0275\u0275text(13, "\n            ");
          i08.\u0275\u0275elementStart(14, "span", 5);
          i08.\u0275\u0275text(15, "Search for competency:");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(16, "\n            ");
          i08.\u0275\u0275elementStart(17, "input", 6);
          i08.\u0275\u0275listener("ngModelChange", function PrerequisiteImportComponent_Template_input_ngModelChange_17_listener($event) {
            return ctx.searchTerm = $event;
          });
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(18, "\n            ");
          i08.\u0275\u0275template(19, PrerequisiteImportComponent_Conditional_19_Template, 4, 0);
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(20, "\n        ");
          i08.\u0275\u0275elementStart(21, "table", 7);
          i08.\u0275\u0275text(22, "\n            ");
          i08.\u0275\u0275elementStart(23, "thead", 8);
          i08.\u0275\u0275text(24, "\n                ");
          i08.\u0275\u0275elementStart(25, "tr", 9);
          i08.\u0275\u0275listener("sortChange", function PrerequisiteImportComponent_Template_tr_sortChange_25_listener() {
            return ctx.sortRows();
          })("ascendingChange", function PrerequisiteImportComponent_Template_tr_ascendingChange_25_listener($event) {
            return ctx.listSorting = $event;
          })("predicateChange", function PrerequisiteImportComponent_Template_tr_predicateChange_25_listener($event) {
            return ctx.sortedColumn = $event;
          });
          i08.\u0275\u0275text(26, "\n                    ");
          i08.\u0275\u0275elementStart(27, "th", 10);
          i08.\u0275\u0275text(28, "\n                        ");
          i08.\u0275\u0275elementStart(29, "span");
          i08.\u0275\u0275text(30, "#");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(31, "\n                        ");
          i08.\u0275\u0275element(32, "fa-icon", 11);
          i08.\u0275\u0275text(33, "\n                    ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(34, "\n                    ");
          i08.\u0275\u0275elementStart(35, "th", 12);
          i08.\u0275\u0275text(36, "\n                        ");
          i08.\u0275\u0275elementStart(37, "span", 13);
          i08.\u0275\u0275text(38, "Title");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(39, "\n                        ");
          i08.\u0275\u0275element(40, "fa-icon", 11);
          i08.\u0275\u0275text(41, "\n                    ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(42, "\n                    ");
          i08.\u0275\u0275elementStart(43, "th", 12);
          i08.\u0275\u0275text(44, "\n                        ");
          i08.\u0275\u0275elementStart(45, "span", 14);
          i08.\u0275\u0275text(46, "Course");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(47, "\n                        ");
          i08.\u0275\u0275element(48, "fa-icon", 11);
          i08.\u0275\u0275text(49, "\n                    ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(50, "\n                    ");
          i08.\u0275\u0275elementStart(51, "th", 15);
          i08.\u0275\u0275text(52, "\n                        ");
          i08.\u0275\u0275elementStart(53, "span", 16);
          i08.\u0275\u0275text(54, "Semester");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(55, "\n                        ");
          i08.\u0275\u0275element(56, "fa-icon", 11);
          i08.\u0275\u0275text(57, "\n                    ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(58, "\n                    ");
          i08.\u0275\u0275element(59, "th", 17);
          i08.\u0275\u0275text(60, "\n                ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(61, "\n            ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(62, "\n            ");
          i08.\u0275\u0275elementStart(63, "tbody");
          i08.\u0275\u0275text(64, "\n                ");
          i08.\u0275\u0275repeaterCreate(65, PrerequisiteImportComponent_For_66_Template, 31, 8, null, null, ctx.trackId);
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(67, "\n        ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(68, "\n        ");
          i08.\u0275\u0275elementStart(69, "div", 18);
          i08.\u0275\u0275text(70, "\n            ");
          i08.\u0275\u0275elementStart(71, "ngb-pagination", 19);
          i08.\u0275\u0275listener("pageChange", function PrerequisiteImportComponent_Template_ngb_pagination_pageChange_71_listener($event) {
            return ctx.onPageChange($event);
          })("pageChange", function PrerequisiteImportComponent_Template_ngb_pagination_pageChange_71_listener($event) {
            return ctx.state.page = $event;
          });
          i08.\u0275\u0275text(72, "\n            ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(73, "\n        ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(74, "\n    ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(75, "\n");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(76, "\n");
        }
        if (rf & 2) {
          i08.\u0275\u0275advance(17);
          i08.\u0275\u0275property("ngModel", ctx.searchTerm);
          i08.\u0275\u0275advance(2);
          i08.\u0275\u0275conditional(19, ctx.loading ? 19 : -1);
          i08.\u0275\u0275advance(6);
          i08.\u0275\u0275property("ascending", ctx.listSorting)("predicate", ctx.sortedColumn);
          i08.\u0275\u0275advance(2);
          i08.\u0275\u0275propertyInterpolate("jhiSortBy", ctx.column.ID);
          i08.\u0275\u0275advance(5);
          i08.\u0275\u0275property("icon", ctx.faSort);
          i08.\u0275\u0275advance(3);
          i08.\u0275\u0275propertyInterpolate("jhiSortBy", ctx.column.TITLE);
          i08.\u0275\u0275advance(5);
          i08.\u0275\u0275property("icon", ctx.faSort);
          i08.\u0275\u0275advance(3);
          i08.\u0275\u0275propertyInterpolate("jhiSortBy", ctx.column.COURSE_TITLE);
          i08.\u0275\u0275advance(5);
          i08.\u0275\u0275property("icon", ctx.faSort);
          i08.\u0275\u0275advance(3);
          i08.\u0275\u0275propertyInterpolate("jhiSortBy", ctx.column.SEMESTER);
          i08.\u0275\u0275advance(5);
          i08.\u0275\u0275property("icon", ctx.faSort);
          i08.\u0275\u0275advance(9);
          i08.\u0275\u0275repeater(ctx.content.resultsOnPage);
          i08.\u0275\u0275advance(6);
          i08.\u0275\u0275property("page", ctx.state.page)("collectionSize", ctx.total)("maxSize", 10)("pageSize", ctx.state.pageSize)("rotate", true);
        }
      }, dependencies: [i18.\u0275NgNoValidate, i18.DefaultValueAccessor, i18.NgControlStatus, i18.NgControlStatusGroup, i18.NgModel, i18.NgForm, i23.NgbPagination, i23.NgbHighlight, i34.FaIconComponent, TranslateDirective, SortByDirective, SortDirective, ButtonComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassDebugInfo(PrerequisiteImportComponent, { className: "PrerequisiteImportComponent" });
    })();
  }
});

// src/main/webapp/app/course/competencies/competency-management/competency-management.component.ts
import { Component as Component8 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { filter, finalize as finalize3, map as map3, switchMap as switchMap5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { Subject as Subject2, forkJoin as forkJoin2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { faPencilAlt, faPlus, faTrash } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { NgbModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i09 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i19 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i42 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i52 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i62 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i7 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i10 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-graph.js?v=1d0d9ead";
function CompetencyManagementComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n    ");
    i09.\u0275\u0275elementStart(1, "div", 0);
    i09.\u0275\u0275text(2, "\n        ");
    i09.\u0275\u0275elementStart(3, "div", 1);
    i09.\u0275\u0275text(4, "\n            ");
    i09.\u0275\u0275elementStart(5, "span", 2);
    i09.\u0275\u0275text(6);
    i09.\u0275\u0275pipe(7, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(8, "\n        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(9, "\n    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(10, "\n");
  }
  if (rf & 2) {
    i09.\u0275\u0275advance(6);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(7, 1, "loading"));
  }
}
function CompetencyManagementComponent_Conditional_1_ng_template_55_For_14_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                                                    ");
    i09.\u0275\u0275elementStart(1, "option", 42);
    i09.\u0275\u0275text(2);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(3, "\n                                                ");
  }
  if (rf & 2) {
    const competency_r16 = ctx.$implicit;
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275property("value", competency_r16.id);
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275textInterpolate(competency_r16.title);
  }
}
function CompetencyManagementComponent_Conditional_1_ng_template_55_For_58_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                                                    ");
    i09.\u0275\u0275elementStart(1, "option", 42);
    i09.\u0275\u0275text(2);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(3, "\n                                                ");
  }
  if (rf & 2) {
    const competency_r21 = ctx.$implicit;
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275property("value", competency_r21.id);
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275textInterpolate(competency_r21.title);
  }
}
function CompetencyManagementComponent_Conditional_1_ng_template_55_Conditional_67_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                                            ");
    i09.\u0275\u0275elementStart(1, "span", 43);
    i09.\u0275\u0275text(2, "\n                                                You can not create this relation.\n                                            ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(3, "\n                                        ");
  }
  if (rf & 2) {
    const ctx_r7 = i09.\u0275\u0275nextContext(3);
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275propertyInterpolate("jhiTranslate", ctx_r7.getErrorMessage(ctx_r7.relationError));
  }
}
function CompetencyManagementComponent_Conditional_1_ng_template_55_ng_template_72_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                                        ");
    i09.\u0275\u0275namespaceSVG();
    i09.\u0275\u0275elementStart(1, "marker", 44);
    i09.\u0275\u0275text(2, "\n                                            ");
    i09.\u0275\u0275element(3, "path", 45);
    i09.\u0275\u0275text(4, "\n                                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(5, "\n                                    ");
  }
}
function CompetencyManagementComponent_Conditional_1_ng_template_55_ng_template_75_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                                        ");
    i09.\u0275\u0275namespaceSVG();
    i09.\u0275\u0275elementStart(1, "g", 46);
    i09.\u0275\u0275text(2, "\n                                            ");
    i09.\u0275\u0275element(3, "rect", 47);
    i09.\u0275\u0275text(4, "\n                                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(5, "\n                                    ");
  }
  if (rf & 2) {
    const cluster_r26 = ctx.$implicit;
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275attribute("width", cluster_r26.dimension.width)("height", cluster_r26.dimension.height)("fill", cluster_r26.data.color);
  }
}
function CompetencyManagementComponent_Conditional_1_ng_template_55_ng_template_78_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                                        ");
    i09.\u0275\u0275namespaceSVG();
    i09.\u0275\u0275elementStart(1, "g", 48);
    i09.\u0275\u0275text(2, "\n                                            ");
    i09.\u0275\u0275element(3, "rect");
    i09.\u0275\u0275text(4, "\n                                            ");
    i09.\u0275\u0275elementStart(5, "text", 49);
    i09.\u0275\u0275text(6);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(7, "\n                                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(8, "\n                                    ");
  }
  if (rf & 2) {
    const node_r27 = ctx.$implicit;
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275attribute("width", node_r27.dimension.width)("height", node_r27.dimension.height);
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275attribute("x", 10)("y", node_r27.dimension.height / 2);
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275textInterpolate1("\n                                                ", node_r27.label, "\n                                            ");
  }
}
function CompetencyManagementComponent_Conditional_1_ng_template_55_ng_template_81_Template(rf, ctx) {
  if (rf & 1) {
    const _r30 = i09.\u0275\u0275getCurrentView();
    i09.\u0275\u0275text(0, "\n                                        ");
    i09.\u0275\u0275namespaceSVG();
    i09.\u0275\u0275elementStart(1, "g", 50);
    i09.\u0275\u0275listener("click", function CompetencyManagementComponent_Conditional_1_ng_template_55_ng_template_81_Template__svg_g_click_1_listener() {
      const restoredCtx = i09.\u0275\u0275restoreView(_r30);
      const link_r28 = restoredCtx.$implicit;
      const ctx_r29 = i09.\u0275\u0275nextContext(3);
      return i09.\u0275\u0275resetView(ctx_r29.removeRelation(link_r28));
    });
    i09.\u0275\u0275text(2, "\n                                            ");
    i09.\u0275\u0275element(3, "path", 51);
    i09.\u0275\u0275text(4, "\n                                            ");
    i09.\u0275\u0275elementStart(5, "text", 52);
    i09.\u0275\u0275text(6, "\n                                                ");
    i09.\u0275\u0275elementStart(7, "textPath", 53);
    i09.\u0275\u0275text(8);
    i09.\u0275\u0275pipe(9, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(10, "\n                                            ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(11, "\n                                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(12, "\n                                    ");
  }
  if (rf & 2) {
    const link_r28 = ctx.$implicit;
    i09.\u0275\u0275advance(7);
    i09.\u0275\u0275styleProp("dominant-baseline", link_r28.dominantBaseline);
    i09.\u0275\u0275attribute("href", "#" + link_r28.id);
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275textInterpolate1("\n                                                    ", i09.\u0275\u0275pipeBind1(9, 4, "artemisApp.competency.relation." + link_r28.label.toLowerCase()).toUpperCase(), "\n                                                ");
  }
}
function CompetencyManagementComponent_Conditional_1_ng_template_55_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = i09.\u0275\u0275getCurrentView();
    i09.\u0275\u0275text(0, "\n                                ");
    i09.\u0275\u0275elementStart(1, "form", 22);
    i09.\u0275\u0275text(2, "\n                                    ");
    i09.\u0275\u0275elementStart(3, "div", 23);
    i09.\u0275\u0275text(4, "\n                                        ");
    i09.\u0275\u0275elementStart(5, "div", 24);
    i09.\u0275\u0275text(6, "\n                                            ");
    i09.\u0275\u0275elementStart(7, "label", 25);
    i09.\u0275\u0275text(8);
    i09.\u0275\u0275pipe(9, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(10, "\n                                            ");
    i09.\u0275\u0275elementStart(11, "select", 26);
    i09.\u0275\u0275listener("ngModelChange", function CompetencyManagementComponent_Conditional_1_ng_template_55_Template_select_ngModelChange_11_listener($event) {
      i09.\u0275\u0275restoreView(_r32);
      const ctx_r31 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r31.tailCompetency = $event);
    })("change", function CompetencyManagementComponent_Conditional_1_ng_template_55_Template_select_change_11_listener() {
      i09.\u0275\u0275restoreView(_r32);
      const ctx_r33 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r33.validate());
    });
    i09.\u0275\u0275text(12, "\n                                                ");
    i09.\u0275\u0275repeaterCreate(13, CompetencyManagementComponent_Conditional_1_ng_template_55_For_14_Template, 4, 2, null, null, i09.\u0275\u0275repeaterTrackByIdentity);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(15, "\n                                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(16, "\n                                    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(17, "\n                                    ");
    i09.\u0275\u0275elementStart(18, "div", 23);
    i09.\u0275\u0275text(19, "\n                                        ");
    i09.\u0275\u0275elementStart(20, "div", 24);
    i09.\u0275\u0275text(21, "\n                                            ");
    i09.\u0275\u0275elementStart(22, "label", 27);
    i09.\u0275\u0275text(23);
    i09.\u0275\u0275pipe(24, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(25, "\n                                            ");
    i09.\u0275\u0275elementStart(26, "select", 28);
    i09.\u0275\u0275listener("ngModelChange", function CompetencyManagementComponent_Conditional_1_ng_template_55_Template_select_ngModelChange_26_listener($event) {
      i09.\u0275\u0275restoreView(_r32);
      const ctx_r34 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r34.relationType = $event);
    })("change", function CompetencyManagementComponent_Conditional_1_ng_template_55_Template_select_change_26_listener() {
      i09.\u0275\u0275restoreView(_r32);
      const ctx_r35 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r35.validate());
    });
    i09.\u0275\u0275text(27, "\n                                                >\n                                                ");
    i09.\u0275\u0275elementStart(28, "option", 29);
    i09.\u0275\u0275text(29);
    i09.\u0275\u0275pipe(30, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(31, "\n                                                ");
    i09.\u0275\u0275elementStart(32, "option", 30);
    i09.\u0275\u0275text(33);
    i09.\u0275\u0275pipe(34, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(35, "\n                                                ");
    i09.\u0275\u0275elementStart(36, "option", 31);
    i09.\u0275\u0275text(37);
    i09.\u0275\u0275pipe(38, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(39, "\n                                                ");
    i09.\u0275\u0275elementStart(40, "option", 32);
    i09.\u0275\u0275text(41);
    i09.\u0275\u0275pipe(42, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(43, "\n                                            ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(44, "\n                                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(45, "\n                                    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(46, "\n                                    ");
    i09.\u0275\u0275elementStart(47, "div", 23);
    i09.\u0275\u0275text(48, "\n                                        ");
    i09.\u0275\u0275elementStart(49, "div", 24);
    i09.\u0275\u0275text(50, "\n                                            ");
    i09.\u0275\u0275elementStart(51, "label", 33);
    i09.\u0275\u0275text(52);
    i09.\u0275\u0275pipe(53, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(54, "\n                                            ");
    i09.\u0275\u0275elementStart(55, "select", 34);
    i09.\u0275\u0275listener("ngModelChange", function CompetencyManagementComponent_Conditional_1_ng_template_55_Template_select_ngModelChange_55_listener($event) {
      i09.\u0275\u0275restoreView(_r32);
      const ctx_r36 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r36.headCompetency = $event);
    })("ngModelChange", function CompetencyManagementComponent_Conditional_1_ng_template_55_Template_select_ngModelChange_55_listener() {
      i09.\u0275\u0275restoreView(_r32);
      const ctx_r37 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r37.validate());
    });
    i09.\u0275\u0275text(56, "\n                                                ");
    i09.\u0275\u0275repeaterCreate(57, CompetencyManagementComponent_Conditional_1_ng_template_55_For_58_Template, 4, 2, null, null, i09.\u0275\u0275repeaterTrackByIdentity);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(59, "\n                                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(60, "\n                                    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(61, "\n                                    ");
    i09.\u0275\u0275elementStart(62, "div", 35);
    i09.\u0275\u0275text(63, "\n                                        ");
    i09.\u0275\u0275elementStart(64, "input", 36);
    i09.\u0275\u0275listener("click", function CompetencyManagementComponent_Conditional_1_ng_template_55_Template_input_click_64_listener() {
      i09.\u0275\u0275restoreView(_r32);
      const ctx_r38 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r38.createRelation());
    });
    i09.\u0275\u0275pipe(65, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(66, "\n                                        ");
    i09.\u0275\u0275template(67, CompetencyManagementComponent_Conditional_1_ng_template_55_Conditional_67_Template, 4, 1);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(68, "\n                                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(69, "\n                                ");
    i09.\u0275\u0275elementStart(70, "ngx-graph", 37);
    i09.\u0275\u0275text(71, "\n                                    ");
    i09.\u0275\u0275template(72, CompetencyManagementComponent_Conditional_1_ng_template_55_ng_template_72_Template, 6, 0, "ng-template", null, 38, i09.\u0275\u0275templateRefExtractor);
    i09.\u0275\u0275text(74, "\n                                    ");
    i09.\u0275\u0275template(75, CompetencyManagementComponent_Conditional_1_ng_template_55_ng_template_75_Template, 6, 3, "ng-template", null, 39, i09.\u0275\u0275templateRefExtractor);
    i09.\u0275\u0275text(77, "\n                                    ");
    i09.\u0275\u0275template(78, CompetencyManagementComponent_Conditional_1_ng_template_55_ng_template_78_Template, 9, 5, "ng-template", null, 40, i09.\u0275\u0275templateRefExtractor);
    i09.\u0275\u0275text(80, "\n                                    ");
    i09.\u0275\u0275template(81, CompetencyManagementComponent_Conditional_1_ng_template_55_ng_template_81_Template, 13, 6, "ng-template", null, 41, i09.\u0275\u0275templateRefExtractor);
    i09.\u0275\u0275text(83, "\n                                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(84, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r2 = i09.\u0275\u0275nextContext(2);
    i09.\u0275\u0275advance(8);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(9, 22, "artemisApp.competency.relation.tailCompetency"));
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("ngClass", i09.\u0275\u0275pureFunction1(38, _c0, ctx_r2.relationError !== ctx_r2.competencyRelationError.NONE))("ngModel", ctx_r2.tailCompetency);
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275repeater(ctx_r2.competencies);
    i09.\u0275\u0275advance(10);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(24, 24, "artemisApp.competency.relation.relationType"));
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("ngClass", i09.\u0275\u0275pureFunction1(40, _c0, ctx_r2.relationError !== ctx_r2.competencyRelationError.NONE))("ngModel", ctx_r2.relationType);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(30, 26, "artemisApp.competency.relation.relates"));
    i09.\u0275\u0275advance(4);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(34, 28, "artemisApp.competency.relation.assumes"));
    i09.\u0275\u0275advance(4);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(38, 30, "artemisApp.competency.relation.extends"));
    i09.\u0275\u0275advance(4);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(42, 32, "artemisApp.competency.relation.matches"));
    i09.\u0275\u0275advance(11);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(53, 34, "artemisApp.competency.relation.headCompetency"));
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("ngClass", i09.\u0275\u0275pureFunction1(42, _c0, ctx_r2.relationError !== ctx_r2.competencyRelationError.NONE))("ngModel", ctx_r2.headCompetency);
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275repeater(ctx_r2.competencies);
    i09.\u0275\u0275advance(7);
    i09.\u0275\u0275propertyInterpolate("value", i09.\u0275\u0275pipeBind1(65, 36, "artemisApp.competency.relation.createRelation"));
    i09.\u0275\u0275property("disabled", !ctx_r2.headCompetency || !ctx_r2.tailCompetency || !ctx_r2.relationType || ctx_r2.relationError !== ctx_r2.competencyRelationError.NONE);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275conditional(67, ctx_r2.relationError !== ctx_r2.competencyRelationError.NONE ? 67 : -1);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("enableZoom", false)("draggingEnabled", false)("nodes", ctx_r2.nodes)("links", ctx_r2.edges)("clusters", ctx_r2.clusters)("update$", ctx_r2.update$);
  }
}
function CompetencyManagementComponent_Conditional_1_Conditional_64_For_42_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                                        ");
    i09.\u0275\u0275elementStart(1, "div");
    i09.\u0275\u0275text(2, "\n                                            ");
    i09.\u0275\u0275element(3, "fa-icon", 72);
    i09.\u0275\u0275text(4);
    i09.\u0275\u0275pipe(5, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(6, "\n                                    ");
  }
  if (rf & 2) {
    const competency_r40 = i09.\u0275\u0275nextContext().$implicit;
    const ctx_r45 = i09.\u0275\u0275nextContext(3);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("icon", ctx_r45.getIcon(competency_r40.taxonomy))("fixedWidth", true);
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275textInterpolate1("\n                                            ", i09.\u0275\u0275pipeBind1(5, 3, ctx_r45.getIconTooltip(competency_r40.taxonomy)), "\n                                        ");
  }
}
function CompetencyManagementComponent_Conditional_1_Conditional_64_For_42_Template(rf, ctx) {
  if (rf & 1) {
    const _r48 = i09.\u0275\u0275getCurrentView();
    i09.\u0275\u0275text(0, "\n                            ");
    i09.\u0275\u0275elementStart(1, "tr", 64);
    i09.\u0275\u0275text(2, "\n                                ");
    i09.\u0275\u0275elementStart(3, "td");
    i09.\u0275\u0275text(4, "\n                                    ");
    i09.\u0275\u0275elementStart(5, "a", 65);
    i09.\u0275\u0275text(6);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(7, "\n                                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(8, "\n                                ");
    i09.\u0275\u0275elementStart(9, "td");
    i09.\u0275\u0275text(10, "\n                                    ");
    i09.\u0275\u0275elementStart(11, "a", 65);
    i09.\u0275\u0275text(12);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(13, "\n                                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(14, "\n                                ");
    i09.\u0275\u0275element(15, "td", 66);
    i09.\u0275\u0275text(16, "\n                                ");
    i09.\u0275\u0275elementStart(17, "td");
    i09.\u0275\u0275text(18, "\n                                    ");
    i09.\u0275\u0275template(19, CompetencyManagementComponent_Conditional_1_Conditional_64_For_42_Conditional_19_Template, 7, 5);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(20, "\n                                ");
    i09.\u0275\u0275elementStart(21, "td");
    i09.\u0275\u0275text(22);
    i09.\u0275\u0275pipe(23, "artemisDate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(24, "\n                                ");
    i09.\u0275\u0275elementStart(25, "td", 61);
    i09.\u0275\u0275text(26, "\n                                    ");
    i09.\u0275\u0275element(27, "ngb-progressbar", 67);
    i09.\u0275\u0275text(28, "\n                                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(29, "\n                                ");
    i09.\u0275\u0275elementStart(30, "td");
    i09.\u0275\u0275text(31, "\n                                    ");
    i09.\u0275\u0275elementStart(32, "span");
    i09.\u0275\u0275text(33);
    i09.\u0275\u0275pipe(34, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(35, "\n                                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(36, "\n                                ");
    i09.\u0275\u0275elementStart(37, "td", 68);
    i09.\u0275\u0275text(38, "\n                                    ");
    i09.\u0275\u0275elementStart(39, "a", 69);
    i09.\u0275\u0275text(40, "\n                                        ");
    i09.\u0275\u0275element(41, "fa-icon", 9);
    i09.\u0275\u0275text(42, "\n                                        ");
    i09.\u0275\u0275elementStart(43, "span", 70);
    i09.\u0275\u0275text(44);
    i09.\u0275\u0275pipe(45, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(46, "\n                                    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(47, "\n                                    ");
    i09.\u0275\u0275elementStart(48, "button", 71);
    i09.\u0275\u0275listener("delete", function CompetencyManagementComponent_Conditional_1_Conditional_64_For_42_Template_button_delete_48_listener() {
      const restoredCtx = i09.\u0275\u0275restoreView(_r48);
      const competency_r40 = restoredCtx.$implicit;
      const ctx_r47 = i09.\u0275\u0275nextContext(3);
      return i09.\u0275\u0275resetView(ctx_r47.deleteCompetency(competency_r40.id));
    });
    i09.\u0275\u0275text(49, "\n                                        ");
    i09.\u0275\u0275element(50, "fa-icon", 9);
    i09.\u0275\u0275text(51, "\n                                    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(52, "\n                                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(53, "\n                            ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(54, "\n                        ");
  }
  if (rf & 2) {
    const competency_r40 = ctx.$implicit;
    const i_r41 = ctx.$index;
    const ctx_r39 = i09.\u0275\u0275nextContext(3);
    let tmp_9_0;
    let tmp_10_0;
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275propertyInterpolate1("id", "competency-row-", i_r41, "");
    i09.\u0275\u0275advance(4);
    i09.\u0275\u0275property("routerLink", i09.\u0275\u0275pureFunction2(26, _c1, ctx_r39.courseId, competency_r40.id));
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275textInterpolate(competency_r40.id);
    i09.\u0275\u0275advance(5);
    i09.\u0275\u0275property("routerLink", i09.\u0275\u0275pureFunction2(29, _c1, ctx_r39.courseId, competency_r40.id));
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275textInterpolate(competency_r40.title);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("innerHTML", competency_r40.description, i09.\u0275\u0275sanitizeHtml);
    i09.\u0275\u0275advance(4);
    i09.\u0275\u0275conditional(19, competency_r40.taxonomy ? 19 : -1);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275textInterpolate1("\n                                    ", i09.\u0275\u0275pipeBind1(23, 20, competency_r40.softDueDate), "\n                                ");
    i09.\u0275\u0275advance(5);
    i09.\u0275\u0275property("showValue", true)("value", (tmp_9_0 = competency_r40.courseProgress == null ? null : competency_r40.courseProgress.numberOfMasteredStudents) !== null && tmp_9_0 !== void 0 ? tmp_9_0 : 0)("max", (tmp_10_0 = competency_r40.courseProgress == null ? null : competency_r40.courseProgress.numberOfStudents) !== null && tmp_10_0 !== void 0 ? tmp_10_0 : 0);
    i09.\u0275\u0275advance(6);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(34, 22, "global.generic." + (competency_r40.optional ? "yes" : "no")));
    i09.\u0275\u0275advance(6);
    i09.\u0275\u0275property("routerLink", i09.\u0275\u0275pureFunction2(32, _c2, ctx_r39.courseId, competency_r40.id));
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275property("icon", ctx_r39.faPencilAlt);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(45, 24, "entity.action.edit"));
    i09.\u0275\u0275advance(4);
    i09.\u0275\u0275property("entityTitle", competency_r40.title || "")("deleteQuestion", "artemisApp.competency.competencyCard.delete.question")("deleteConfirmationText", "artemisApp.competency.competencyCard.delete.typeNameToConfirm")("dialogError", ctx_r39.dialogError$);
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275property("icon", ctx_r39.faTrash);
  }
}
function CompetencyManagementComponent_Conditional_1_Conditional_64_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                ");
    i09.\u0275\u0275elementStart(1, "table", 54);
    i09.\u0275\u0275text(2, "\n                    ");
    i09.\u0275\u0275elementStart(3, "thead");
    i09.\u0275\u0275text(4, "\n                        ");
    i09.\u0275\u0275elementStart(5, "tr");
    i09.\u0275\u0275text(6, "\n                            ");
    i09.\u0275\u0275elementStart(7, "th")(8, "span", 55);
    i09.\u0275\u0275text(9, "ID");
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275text(10, "\n                            ");
    i09.\u0275\u0275elementStart(11, "th")(12, "span", 56);
    i09.\u0275\u0275text(13, "Title");
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275text(14, "\n                            ");
    i09.\u0275\u0275elementStart(15, "th", 57)(16, "span", 58);
    i09.\u0275\u0275text(17, "Description");
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275text(18, "\n                            ");
    i09.\u0275\u0275elementStart(19, "th")(20, "span", 59);
    i09.\u0275\u0275text(21, "Taxonomy");
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275text(22, "\n                            ");
    i09.\u0275\u0275elementStart(23, "th")(24, "span", 60);
    i09.\u0275\u0275text(25, "Due Date");
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275text(26, "\n                            ");
    i09.\u0275\u0275elementStart(27, "th", 61)(28, "span", 62);
    i09.\u0275\u0275text(29, "Mastered Students");
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275text(30, "\n                            ");
    i09.\u0275\u0275elementStart(31, "th")(32, "span", 63);
    i09.\u0275\u0275text(33, "Optional");
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275text(34, "\n                            ");
    i09.\u0275\u0275element(35, "th");
    i09.\u0275\u0275text(36, "\n                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(37, "\n                    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(38, "\n                    ");
    i09.\u0275\u0275elementStart(39, "tbody");
    i09.\u0275\u0275text(40, "\n                        ");
    i09.\u0275\u0275repeaterCreate(41, CompetencyManagementComponent_Conditional_1_Conditional_64_For_42_Template, 55, 35, null, null, i09.\u0275\u0275componentInstance().identify);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(43, "\n                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(44, "\n            ");
  }
  if (rf & 2) {
    const ctx_r3 = i09.\u0275\u0275nextContext(2);
    i09.\u0275\u0275advance(41);
    i09.\u0275\u0275repeater(ctx_r3.competencies);
  }
}
function CompetencyManagementComponent_Conditional_1_Conditional_86_For_34_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                                        ");
    i09.\u0275\u0275elementStart(1, "div");
    i09.\u0275\u0275text(2, "\n                                            ");
    i09.\u0275\u0275element(3, "fa-icon", 72);
    i09.\u0275\u0275text(4);
    i09.\u0275\u0275pipe(5, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(6, "\n                                    ");
  }
  if (rf & 2) {
    const prerequisite_r50 = i09.\u0275\u0275nextContext().$implicit;
    const ctx_r55 = i09.\u0275\u0275nextContext(3);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("icon", ctx_r55.getIcon(prerequisite_r50.taxonomy))("fixedWidth", true);
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275textInterpolate1("\n                                            ", i09.\u0275\u0275pipeBind1(5, 3, ctx_r55.getIconTooltip(prerequisite_r50.taxonomy)), "\n                                        ");
  }
}
function CompetencyManagementComponent_Conditional_1_Conditional_86_For_34_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                                        ");
    i09.\u0275\u0275elementStart(1, "div");
    i09.\u0275\u0275text(2, "\n                                            ");
    i09.\u0275\u0275elementStart(3, "a", 65);
    i09.\u0275\u0275text(4);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(5, "\n                                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(6, "\n                                    ");
  }
  if (rf & 2) {
    const prerequisite_r50 = i09.\u0275\u0275nextContext().$implicit;
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("routerLink", i09.\u0275\u0275pureFunction1(2, _c3, prerequisite_r50.course.id));
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275textInterpolate(prerequisite_r50.course.title);
  }
}
function CompetencyManagementComponent_Conditional_1_Conditional_86_For_34_Template(rf, ctx) {
  if (rf & 1) {
    const _r60 = i09.\u0275\u0275getCurrentView();
    i09.\u0275\u0275text(0, "\n                            ");
    i09.\u0275\u0275elementStart(1, "tr", 64);
    i09.\u0275\u0275text(2, "\n                                ");
    i09.\u0275\u0275elementStart(3, "td");
    i09.\u0275\u0275text(4);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(5, "\n                                ");
    i09.\u0275\u0275elementStart(6, "td");
    i09.\u0275\u0275text(7);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(8, "\n                                ");
    i09.\u0275\u0275element(9, "td", 66);
    i09.\u0275\u0275text(10, "\n                                ");
    i09.\u0275\u0275elementStart(11, "td");
    i09.\u0275\u0275text(12, "\n                                    ");
    i09.\u0275\u0275template(13, CompetencyManagementComponent_Conditional_1_Conditional_86_For_34_Conditional_13_Template, 7, 5);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(14, "\n                                ");
    i09.\u0275\u0275elementStart(15, "td");
    i09.\u0275\u0275text(16, "\n                                    ");
    i09.\u0275\u0275template(17, CompetencyManagementComponent_Conditional_1_Conditional_86_For_34_Conditional_17_Template, 7, 4);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(18, "\n                                ");
    i09.\u0275\u0275elementStart(19, "td", 68);
    i09.\u0275\u0275text(20, "\n                                    ");
    i09.\u0275\u0275elementStart(21, "button", 74);
    i09.\u0275\u0275listener("click", function CompetencyManagementComponent_Conditional_1_Conditional_86_For_34_Template_button_click_21_listener() {
      const restoredCtx = i09.\u0275\u0275restoreView(_r60);
      const prerequisite_r50 = restoredCtx.$implicit;
      const ctx_r59 = i09.\u0275\u0275nextContext(3);
      return i09.\u0275\u0275resetView(ctx_r59.removePrerequisite(prerequisite_r50.id));
    });
    i09.\u0275\u0275text(22, "\n                                        ");
    i09.\u0275\u0275element(23, "fa-icon", 9);
    i09.\u0275\u0275text(24);
    i09.\u0275\u0275pipe(25, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(26, "\n                                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(27, "\n                            ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(28, "\n                        ");
  }
  if (rf & 2) {
    const prerequisite_r50 = ctx.$implicit;
    const i_r51 = ctx.$index;
    const ctx_r49 = i09.\u0275\u0275nextContext(3);
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275propertyInterpolate1("id", "competency-row-", i_r51, "");
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275textInterpolate1("\n                                    ", prerequisite_r50.id, "\n                                ");
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275textInterpolate1("\n                                    ", prerequisite_r50.title, "\n                                ");
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275property("innerHTML", prerequisite_r50.description, i09.\u0275\u0275sanitizeHtml);
    i09.\u0275\u0275advance(4);
    i09.\u0275\u0275conditional(13, prerequisite_r50.taxonomy ? 13 : -1);
    i09.\u0275\u0275advance(4);
    i09.\u0275\u0275conditional(17, prerequisite_r50.course ? 17 : -1);
    i09.\u0275\u0275advance(6);
    i09.\u0275\u0275property("icon", ctx_r49.faTrash);
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275textInterpolate1(" ", i09.\u0275\u0275pipeBind1(25, 8, "artemisApp.competency.competencyCard.remove"), "\n                                    ");
  }
}
function CompetencyManagementComponent_Conditional_1_Conditional_86_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                ");
    i09.\u0275\u0275elementStart(1, "table", 54);
    i09.\u0275\u0275text(2, "\n                    ");
    i09.\u0275\u0275elementStart(3, "thead");
    i09.\u0275\u0275text(4, "\n                        ");
    i09.\u0275\u0275elementStart(5, "tr");
    i09.\u0275\u0275text(6, "\n                            ");
    i09.\u0275\u0275elementStart(7, "th")(8, "span", 55);
    i09.\u0275\u0275text(9, "ID");
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275text(10, "\n                            ");
    i09.\u0275\u0275elementStart(11, "th")(12, "span", 56);
    i09.\u0275\u0275text(13, "Title");
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275text(14, "\n                            ");
    i09.\u0275\u0275elementStart(15, "th", 57)(16, "span", 58);
    i09.\u0275\u0275text(17, "Description");
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275text(18, "\n                            ");
    i09.\u0275\u0275elementStart(19, "th")(20, "span", 59);
    i09.\u0275\u0275text(21, "Taxonomy");
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275text(22, "\n                            ");
    i09.\u0275\u0275elementStart(23, "th")(24, "span", 73);
    i09.\u0275\u0275text(25, "Course");
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275text(26, "\n                            ");
    i09.\u0275\u0275element(27, "th");
    i09.\u0275\u0275text(28, "\n                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(29, "\n                    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(30, "\n                    ");
    i09.\u0275\u0275elementStart(31, "tbody");
    i09.\u0275\u0275text(32, "\n                        ");
    i09.\u0275\u0275repeaterCreate(33, CompetencyManagementComponent_Conditional_1_Conditional_86_For_34_Template, 29, 10, null, null, i09.\u0275\u0275componentInstance().identify);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(35, "\n                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(36, "\n            ");
  }
  if (rf & 2) {
    const ctx_r4 = i09.\u0275\u0275nextContext(2);
    i09.\u0275\u0275advance(33);
    i09.\u0275\u0275repeater(ctx_r4.prerequisites);
  }
}
function CompetencyManagementComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r62 = i09.\u0275\u0275getCurrentView();
    i09.\u0275\u0275text(0, "\n    ");
    i09.\u0275\u0275elementStart(1, "div");
    i09.\u0275\u0275text(2, "\n        ");
    i09.\u0275\u0275elementStart(3, "div", 3);
    i09.\u0275\u0275text(4, "\n            ");
    i09.\u0275\u0275elementStart(5, "div", 4);
    i09.\u0275\u0275text(6, "\n                ");
    i09.\u0275\u0275elementStart(7, "h2", 5);
    i09.\u0275\u0275text(8, "Competency Management");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(9, "\n                ");
    i09.\u0275\u0275element(10, "jhi-documentation-button", 6);
    i09.\u0275\u0275text(11, "\n            ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(12, "\n            ");
    i09.\u0275\u0275elementStart(13, "div", 7);
    i09.\u0275\u0275text(14, "\n                ");
    i09.\u0275\u0275elementStart(15, "button", 8);
    i09.\u0275\u0275listener("click", function CompetencyManagementComponent_Conditional_1_Template_button_click_15_listener() {
      i09.\u0275\u0275restoreView(_r62);
      const ctx_r61 = i09.\u0275\u0275nextContext();
      return i09.\u0275\u0275resetView(ctx_r61.openImportModal());
    });
    i09.\u0275\u0275text(16, "\n                    ");
    i09.\u0275\u0275element(17, "fa-icon", 9);
    i09.\u0275\u0275text(18, "\n                    ");
    i09.\u0275\u0275elementStart(19, "span");
    i09.\u0275\u0275text(20);
    i09.\u0275\u0275pipe(21, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(22, "\n                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(23, "\n                ");
    i09.\u0275\u0275elementStart(24, "a", 10);
    i09.\u0275\u0275text(25, "\n                    ");
    i09.\u0275\u0275element(26, "fa-icon", 9);
    i09.\u0275\u0275text(27, "\n                    ");
    i09.\u0275\u0275elementStart(28, "span");
    i09.\u0275\u0275text(29);
    i09.\u0275\u0275pipe(30, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(31, "\n                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(32, "\n            ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(33, "\n        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(34, "\n        ");
    i09.\u0275\u0275elementStart(35, "div", 11);
    i09.\u0275\u0275text(36, "\n            ");
    i09.\u0275\u0275elementStart(37, "div", 12);
    i09.\u0275\u0275text(38, "\n                ");
    i09.\u0275\u0275elementStart(39, "div", 13);
    i09.\u0275\u0275text(40, "\n                    ");
    i09.\u0275\u0275elementStart(41, "div", 14);
    i09.\u0275\u0275text(42, "\n                        ");
    i09.\u0275\u0275elementStart(43, "button", 15);
    i09.\u0275\u0275text(44);
    i09.\u0275\u0275pipe(45, "artemisTranslate");
    i09.\u0275\u0275elementStart(46, "span", 16);
    i09.\u0275\u0275text(47, "BETA");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(48, "\n                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(49, "\n                    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(50, "\n                    ");
    i09.\u0275\u0275elementStart(51, "div", 17);
    i09.\u0275\u0275text(52, "\n                        ");
    i09.\u0275\u0275elementStart(53, "div", 18);
    i09.\u0275\u0275text(54, "\n                            ");
    i09.\u0275\u0275template(55, CompetencyManagementComponent_Conditional_1_ng_template_55_Template, 85, 44, "ng-template");
    i09.\u0275\u0275text(56, "\n                        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(57, "\n                    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(58, "\n                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(59, "\n            ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(60, "\n        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(61, "\n        ");
    i09.\u0275\u0275elementStart(62, "div", 19);
    i09.\u0275\u0275text(63, "\n            ");
    i09.\u0275\u0275template(64, CompetencyManagementComponent_Conditional_1_Conditional_64_Template, 45, 0);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(65, "\n        ");
    i09.\u0275\u0275elementStart(66, "div", 3);
    i09.\u0275\u0275text(67, "\n            ");
    i09.\u0275\u0275elementStart(68, "h2", 20);
    i09.\u0275\u0275text(69, "Prerequisite Management");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(70, "\n            ");
    i09.\u0275\u0275elementStart(71, "div", 7);
    i09.\u0275\u0275text(72, "\n                ");
    i09.\u0275\u0275elementStart(73, "a", 21);
    i09.\u0275\u0275listener("click", function CompetencyManagementComponent_Conditional_1_Template_a_click_73_listener() {
      i09.\u0275\u0275restoreView(_r62);
      const ctx_r63 = i09.\u0275\u0275nextContext();
      return i09.\u0275\u0275resetView(ctx_r63.openPrerequisiteSelectionModal());
    });
    i09.\u0275\u0275text(74, "\n                    ");
    i09.\u0275\u0275element(75, "fa-icon", 9);
    i09.\u0275\u0275text(76, "\n                    ");
    i09.\u0275\u0275elementStart(77, "span");
    i09.\u0275\u0275text(78);
    i09.\u0275\u0275pipe(79, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(80, "\n                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(81, "\n            ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(82, "\n        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(83, "\n        ");
    i09.\u0275\u0275elementStart(84, "div", 19);
    i09.\u0275\u0275text(85, "\n            ");
    i09.\u0275\u0275template(86, CompetencyManagementComponent_Conditional_1_Conditional_86_Template, 37, 0);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(87, "\n    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(88, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(10);
    i09.\u0275\u0275property("type", ctx_r1.documentationType);
    i09.\u0275\u0275advance(7);
    i09.\u0275\u0275property("icon", ctx_r1.faPlus);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(21, 12, "artemisApp.competency.manageCompetencies.import"));
    i09.\u0275\u0275advance(4);
    i09.\u0275\u0275property("routerLink", i09.\u0275\u0275pureFunction1(20, _c4, ctx_r1.courseId));
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275property("icon", ctx_r1.faPlus);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(30, 14, "artemisApp.competency.manageCompetencies.create"));
    i09.\u0275\u0275advance(8);
    i09.\u0275\u0275property("closeOthers", true);
    i09.\u0275\u0275advance(7);
    i09.\u0275\u0275textInterpolate1("\n                            ", i09.\u0275\u0275pipeBind1(45, 16, "artemisApp.competency.relation.competencyRelations"), "");
    i09.\u0275\u0275advance(20);
    i09.\u0275\u0275conditional(64, ctx_r1.competencies.length ? 64 : -1);
    i09.\u0275\u0275advance(11);
    i09.\u0275\u0275property("icon", ctx_r1.faPlus);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(79, 18, "artemisApp.competency.prerequisite.managePrerequisites.select"));
    i09.\u0275\u0275advance(8);
    i09.\u0275\u0275conditional(86, ctx_r1.prerequisites.length ? 86 : -1);
  }
}
var _c0, _c1, _c2, _c3, _c4, CompetencyManagementComponent, Vertex, Graph;
var init_competency_management_component = __esm({
  "src/main/webapp/app/course/competencies/competency-management/competency-management.component.ts"() {
    init_competency_service();
    init_alert_service();
    init_competency_model();
    init_global_utils();
    init_prerequisite_import_component();
    init_competency_import_component();
    init_competency_service();
    init_alert_service();
    init_translate_directive();
    init_delete_button_directive();
    init_documentation_button_component();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    _c0 = (a0) => ({ "border-danger": a0 });
    _c1 = (a1, a3) => ["/courses", a1, "competencies", a3];
    _c2 = (a1, a3) => ["/course-management", a1, "competency-management", a3, "edit"];
    _c3 = (a1) => ["/course-management", a1, "competency-management"];
    _c4 = (a1) => ["/course-management", a1, "competency-management", "create"];
    CompetencyManagementComponent = class _CompetencyManagementComponent {
      activatedRoute;
      competencyService;
      alertService;
      modalService;
      courseId;
      isLoading = false;
      competencies = [];
      prerequisites = [];
      tailCompetency;
      headCompetency;
      relationType;
      nodes = [];
      edges = [];
      clusters = [];
      competencyRelationError = CompetencyRelationError;
      relationError = CompetencyRelationError.NONE;
      dialogErrorSource = new Subject2();
      dialogError$ = this.dialogErrorSource.asObservable();
      update$ = new Subject2();
      getIcon = getIcon;
      getIconTooltip = getIconTooltip;
      documentationType = "Competencies";
      faPlus = faPlus;
      faTrash = faTrash;
      faPencilAlt = faPencilAlt;
      constructor(activatedRoute, competencyService, alertService, modalService) {
        this.activatedRoute = activatedRoute;
        this.competencyService = competencyService;
        this.alertService = alertService;
        this.modalService = modalService;
      }
      ngOnDestroy() {
        this.dialogErrorSource.unsubscribe();
      }
      ngOnInit() {
        this.activatedRoute.parent.params.subscribe((params) => {
          this.courseId = params["courseId"];
          if (this.courseId) {
            this.loadData();
          }
        });
      }
      validate() {
        if (this.headCompetency && this.tailCompetency && this.relationType && this.headCompetency === this.tailCompetency) {
          this.relationError = CompetencyRelationError.SELF;
          return;
        }
        if (this.doesRelationAlreadyExist()) {
          this.relationError = CompetencyRelationError.EXISTING;
          return;
        }
        if (this.containsCircularRelation()) {
          this.relationError = CompetencyRelationError.CIRCULAR;
          return;
        }
        this.relationError = CompetencyRelationError.NONE;
      }
      getErrorMessage(error) {
        switch (error) {
          case CompetencyRelationError.CIRCULAR: {
            return "artemisApp.competency.relation.createsCircularRelation";
          }
          case CompetencyRelationError.EXISTING: {
            return "artemisApp.competency.relation.relationAlreadyExists";
          }
          case CompetencyRelationError.SELF: {
            return "artemisApp.competency.relation.selfRelation";
          }
          case CompetencyRelationError.NONE: {
            throw new TypeError("There is no error message if there is no error.");
          }
        }
      }
      identify(index, competency) {
        return `${index}-${competency.id}`;
      }
      deleteCompetency(competencyId) {
        this.competencyService.delete(competencyId, this.courseId).subscribe({
          next: () => {
            this.dialogErrorSource.next("");
            this.loadData();
          },
          error: (error) => this.dialogErrorSource.next(error.message)
        });
      }
      removePrerequisite(competencyId) {
        this.competencyService.removePrerequisite(competencyId, this.courseId).subscribe({
          next: () => {
            this.dialogErrorSource.next("");
            this.loadData();
          },
          error: (error) => this.dialogErrorSource.next(error.message)
        });
      }
      loadData() {
        this.isLoading = true;
        this.competencyService.getAllPrerequisitesForCourse(this.courseId).pipe(map3((response) => response.body)).subscribe({
          next: (competencies) => {
            this.prerequisites = competencies;
          },
          error: (errorResponse) => onError(this.alertService, errorResponse)
        });
        this.competencyService.getAllForCourse(this.courseId).pipe(switchMap5((res) => {
          this.competencies = res.body;
          this.nodes = this.competencies.map((competency) => ({
            id: `${competency.id}`,
            label: competency.title
          }));
          const relationsObservable = this.competencies.map((lg) => {
            return this.competencyService.getCompetencyRelations(lg.id, this.courseId);
          });
          const progressObservable = this.competencies.map((lg) => {
            return this.competencyService.getCourseProgress(lg.id, this.courseId);
          });
          return forkJoin2([forkJoin2(relationsObservable), forkJoin2(progressObservable)]);
        })).pipe(finalize3(() => {
          this.isLoading = false;
        })).subscribe({
          next: ([competencyRelations, competencyProgressResponses]) => {
            const relations = [
              ...competencyRelations.flatMap((response) => response.body).reduce((a, c) => {
                a.set(c.id, c);
                return a;
              }, /* @__PURE__ */ new Map()).values()
            ];
            this.edges = relations.map((relation) => ({
              id: `edge${relation.id}`,
              source: `${relation.tailCompetency?.id}`,
              target: `${relation.headCompetency?.id}`,
              label: relation.type,
              data: {
                id: relation.id
              }
            }));
            this.clusters = relations.filter((relation) => relation.type === "CONSECUTIVE").map((relation) => ({
              id: `cluster${relation.id}`,
              label: relation.type,
              childNodeIds: [`${relation.tailCompetency?.id}`, `${relation.headCompetency?.id}`],
              data: {
                id: relation.id
              }
            }));
            for (const competencyProgressResponse of competencyProgressResponses) {
              const courseCompetencyProgress = competencyProgressResponse.body;
              this.competencies.find((lg) => lg.id === courseCompetencyProgress.competencyId).courseProgress = courseCompetencyProgress;
            }
          },
          error: (errorResponse) => onError(this.alertService, errorResponse)
        });
      }
      openPrerequisiteSelectionModal() {
        const modalRef = this.modalService.open(PrerequisiteImportComponent, { size: "lg", backdrop: "static" });
        modalRef.componentInstance.disabledIds = this.competencies.concat(this.prerequisites).map((competency) => competency.id);
        modalRef.result.then((result) => {
          this.competencyService.addPrerequisite(result.id, this.courseId).pipe(filter((res) => res.ok), map3((res) => res.body)).subscribe({
            next: (res) => {
              this.prerequisites.push(res);
            },
            error: (res) => onError(this.alertService, res)
          });
        });
      }
      openImportModal() {
        const modalRef = this.modalService.open(CompetencyImportComponent, { size: "lg", backdrop: "static" });
        modalRef.componentInstance.disabledIds = this.competencies.concat(this.prerequisites).map((competency) => competency.id);
        modalRef.result.then((selectedCompetency) => {
          this.competencyService.import(selectedCompetency, this.courseId).pipe(filter((res) => res.ok), map3((res) => res.body)).subscribe({
            next: (res) => {
              this.competencies.push(res);
            },
            error: (res) => onError(this.alertService, res)
          });
        });
      }
      createRelation() {
        if (this.relationError !== CompetencyRelationError.NONE) {
          switch (this.relationError) {
            case CompetencyRelationError.CIRCULAR: {
              throw new TypeError("Creation of circular relations is not allowed.");
            }
            case CompetencyRelationError.EXISTING: {
              throw new TypeError("Creation of an already existing relation is not allowed.");
            }
            case CompetencyRelationError.SELF: {
              throw new TypeError("Creation of a self relation is not allowed.");
            }
          }
        }
        this.competencyService.createCompetencyRelation(this.tailCompetency, this.headCompetency, this.relationType, this.courseId).pipe(filter((res) => res.ok), map3((res) => res.body)).subscribe({
          next: (relation) => {
            if (relation) {
              this.edges.push({
                id: `edge${relation.id}`,
                source: `${relation.tailCompetency?.id}`,
                target: `${relation.headCompetency?.id}`,
                label: relation.type,
                data: {
                  id: relation.id
                }
              });
              this.update$.next(true);
            }
          },
          error: (res) => onError(this.alertService, res)
        });
      }
      removeRelation(edge) {
        this.competencyService.removeCompetencyRelation(Number(edge.source), Number(edge.data.id), this.courseId).subscribe({
          next: () => {
            const index = this.edges.findIndex((e) => e.id === edge.id);
            this.edges.splice(index, 1);
            this.update$.next(true);
          },
          error: (res) => onError(this.alertService, res)
        });
      }
      containsCircularRelation() {
        if (this.headCompetency !== this.tailCompetency) {
          return !!(this.tailCompetency && this.headCompetency && this.relationType && this.doesCreateCircularRelation(this.nodes, this.edges, {
            source: this.tailCompetency + "",
            target: this.headCompetency + "",
            label: this.relationType
          }));
        } else {
          return false;
        }
      }
      doesRelationAlreadyExist() {
        return this.edges.find((edge) => edge.source === this.tailCompetency?.toString() && edge.target === this.headCompetency?.toString()) !== void 0;
      }
      doesCreateCircularRelation(nodes, edges, edgeToAdd) {
        const edgesWithNewEdge = JSON.parse(JSON.stringify(edges));
        edgesWithNewEdge.push(edgeToAdd);
        const graph = new Graph();
        for (const node of nodes) {
          graph.addVertex(new Vertex(node.id));
        }
        for (const edge of edgesWithNewEdge) {
          const headVertex = graph.vertices.find((vertex) => vertex.getLabel() === edge.target);
          const tailVertex = graph.vertices.find((vertex) => vertex.getLabel() === edge.source);
          if (headVertex === void 0 || tailVertex === void 0) {
            throw new TypeError("Every edge needs a source or a target.");
          }
          switch (edge.label) {
            case "EXTENDS":
            case "ASSUMES": {
              graph.addEdge(tailVertex, headVertex);
              break;
            }
          }
        }
        for (const edge of edgesWithNewEdge) {
          if (edge.label === "MATCHES") {
            const headVertex = graph.vertices.find((vertex) => vertex.getLabel() === edge.target);
            const tailVertex = graph.vertices.find((vertex) => vertex.getLabel() === edge.source);
            if (headVertex === void 0 || tailVertex === void 0) {
              throw new TypeError("Every edge needs a source or a target.");
            }
            if (headVertex.getAdjacencyList().includes(tailVertex) || tailVertex.getAdjacencyList().includes(headVertex)) {
              return true;
            }
            const mergedVertex = new Vertex(tailVertex.getLabel() + ", " + headVertex.getLabel());
            mergedVertex.getAdjacencyList().push(...headVertex.getAdjacencyList());
            mergedVertex.getAdjacencyList().push(...tailVertex.getAdjacencyList());
            for (const vertex of graph.vertices) {
              for (const adjacentVertex of vertex.getAdjacencyList()) {
                if (adjacentVertex.getLabel() === headVertex.getLabel() || adjacentVertex.getLabel() === tailVertex.getLabel()) {
                  const index = vertex.getAdjacencyList().indexOf(adjacentVertex, 0);
                  if (index > -1) {
                    vertex.getAdjacencyList().splice(index, 1);
                  }
                  vertex.getAdjacencyList().push(mergedVertex);
                }
              }
            }
          }
        }
        return graph.hasCycle();
      }
      static \u0275fac = function CompetencyManagementComponent_Factory(t) {
        return new (t || _CompetencyManagementComponent)(i09.\u0275\u0275directiveInject(i19.ActivatedRoute), i09.\u0275\u0275directiveInject(CompetencyService), i09.\u0275\u0275directiveInject(AlertService), i09.\u0275\u0275directiveInject(i42.NgbModal));
      };
      static \u0275cmp = i09.\u0275\u0275defineComponent({ type: _CompetencyManagementComponent, selectors: [["jhi-competency-management"]], decls: 2, vars: 2, consts: [[1, "d-flex", "justify-content-center"], ["role", "status", 1, "spinner-border"], [1, "sr-only"], [1, "d-flex", "flex-wrap"], [1, "my-auto", "d-flex", "align-items-center"], ["jhiTranslate", "artemisApp.competency.manageCompetencies.title"], [3, "type"], [1, "ms-auto", "text-truncate", "justify-content-end"], ["id", "competencyImportButton", 1, "btn", "btn-primary", 3, "click"], [3, "icon"], [1, "btn", "btn-primary", 3, "routerLink"], [1, "container", "mx-0", "mt-3", "mb-3", "mw-100"], ["ngbAccordion", "", 3, "closeOthers"], ["ngbAccordionItem", ""], ["ngbAccordionHeader", ""], ["ngbAccordionButton", ""], [1, "badge", "rounded-pill", "text-bg-warning", "ms-1"], ["ngbAccordionCollapse", ""], ["ngbAccordionBody", ""], [1, "container-fluid", 2, "min-height", "100px"], ["jhiTranslate", "artemisApp.competency.prerequisite.managePrerequisites.title"], [1, "btn", "btn-primary", 3, "click"], [1, "row", "p-3", "g-3", "align-items-center"], [1, "col"], [1, "form-group"], ["for", "tail"], ["id", "tail", "name", "tail", 1, "form-select", 3, "ngClass", "ngModel", "ngModelChange", "change"], ["for", "type"], ["id", "type", "name", "type", 1, "form-select", 3, "ngClass", "ngModel", "ngModelChange", "change"], ["value", "RELATES", "selected", ""], ["value", "ASSUMES"], ["value", "EXTENDS"], ["value", "MATCHES"], ["for", "head"], ["id", "head", "name", "head", 1, "form-select", 3, "ngClass", "ngModel", "ngModelChange"], [1, "col-auto"], ["type", "button", 1, "btn", "btn-primary", 3, "value", "disabled", "click"], ["layout", "dagreCluster", 1, "m-1", "chart-container", 3, "enableZoom", "draggingEnabled", "nodes", "links", "clusters", "update$"], ["defsTemplate", ""], ["clusterTemplate", ""], ["nodeTemplate", ""], ["linkTemplate", ""], [3, "value"], ["id", "relation-not-valid-text", 1, "invalid-feedback", 3, "jhiTranslate"], ["id", "arrow", "viewBox", "0 -5 10 10", "refX", "8", "refY", "0", "markerWidth", "4", "markerHeight", "4", "orient", "auto"], ["d", "M0,-5L10,0L0,5", 1, "arrow-head"], [1, "node", "cluster"], ["rx", "5", "ry", "5"], [1, "node"], ["alignment-baseline", "central"], [1, "edge", 3, "click"], ["stroke-width", "2", "marker-end", "url(#arrow)", 1, "line"], ["text-anchor", "middle", 1, "edge-label"], ["startOffset", "50%", 1, "text-path"], [1, "table", "table-striped"], ["jhiTranslate", "global.field.id"], ["jhiTranslate", "artemisApp.competency.title"], ["width", "300"], ["jhiTranslate", "artemisApp.competency.description"], ["jhiTranslate", "artemisApp.competency.taxonomy"], ["jhiTranslate", "artemisApp.competency.softDueDate"], [1, "d-none", "d-lg-table-cell"], ["jhiTranslate", "artemisApp.competency.masteredStudents"], ["jhiTranslate", "artemisApp.competency.optional"], [3, "id"], [3, "routerLink"], [3, "innerHTML"], ["type", "primary", 3, "showValue", "value", "max"], [1, "text-end"], [1, "btn", "btn-sm", "btn-primary", 3, "routerLink"], [1, "d-none", "d-md-inline"], ["jhiDeleteButton", "", 3, "entityTitle", "deleteQuestion", "deleteConfirmationText", "dialogError", "delete"], ["container", "body", 3, "icon", "fixedWidth"], ["jhiTranslate", "artemisApp.competency.course"], ["id", "removeButton", 1, "btn", "btn-secondary", "btn-sm", 3, "click"]], template: function CompetencyManagementComponent_Template(rf, ctx) {
        if (rf & 1) {
          i09.\u0275\u0275template(0, CompetencyManagementComponent_Conditional_0_Template, 11, 3)(1, CompetencyManagementComponent_Conditional_1_Template, 89, 22);
        }
        if (rf & 2) {
          i09.\u0275\u0275conditional(0, ctx.isLoading ? 0 : -1);
          i09.\u0275\u0275advance(1);
          i09.\u0275\u0275conditional(1, !ctx.isLoading ? 1 : -1);
        }
      }, dependencies: [i52.\u0275NgNoValidate, i52.NgSelectOption, i52.\u0275NgSelectMultipleOption, i52.SelectControlValueAccessor, i52.NgControlStatus, i52.NgControlStatusGroup, i52.NgModel, i52.NgForm, i62.NgClass, i42.NgbAccordionButton, i42.NgbAccordionDirective, i42.NgbAccordionItem, i42.NgbAccordionHeader, i42.NgbAccordionBody, i42.NgbAccordionCollapse, i42.NgbProgressbar, i7.FaIconComponent, TranslateDirective, DeleteButtonDirective, i10.GraphComponent, DocumentationButtonComponent, i19.RouterLink, ArtemisDatePipe, ArtemisTranslatePipe], styles: ["\n\n.btn-circle[_ngcontent-%COMP%] {\n  width: 50px !important;\n  height: 50px !important;\n  text-align: center;\n  padding: 6px 0;\n  font-size: 12px;\n  line-height: 1.428571429;\n  border-radius: 100px;\n}\n.btn-circle[_ngcontent-%COMP%]:hover {\n  box-shadow: rgba(100, 100, 111, 0.2) 0 7px 29px 0;\n}\n.grow[_ngcontent-%COMP%] {\n  transition: all 0.2s ease-in-out;\n}\n.grow[_ngcontent-%COMP%]:hover {\n  transform: scale(1.1);\n}\n.center-link[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.border-danger[_ngcontent-%COMP%] {\n  border-color: var(--danger);\n}\n.node[_ngcontent-%COMP%]   text[_ngcontent-%COMP%] {\n  fill: var(--body-color);\n}\n.node[_ngcontent-%COMP%]   rect[_ngcontent-%COMP%] {\n  fill: var(--primary);\n}\n#arrow[_ngcontent-%COMP%] {\n  stroke: var(--body-color);\n  fill: var(--body-color);\n}\n.edge[_ngcontent-%COMP%] {\n  stroke: var(--body-color) !important;\n  marker-end: url(#arrow);\n}\n.text-path[_ngcontent-%COMP%] {\n  fill: var(--body-color);\n}\n  .accordion-body {\n  overflow: hidden;\n  max-height: 60vh;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvY29tcGV0ZW5jaWVzL2NvbXBldGVuY3ktbWFuYWdlbWVudC9jb21wZXRlbmN5LW1hbmFnZW1lbnQuY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5idG4tY2lyY2xlIHtcbiAgICB3aWR0aDogNTBweCAhaW1wb3J0YW50O1xuICAgIGhlaWdodDogNTBweCAhaW1wb3J0YW50O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwYWRkaW5nOiA2cHggMDtcbiAgICBmb250LXNpemU6IDEycHg7XG4gICAgbGluZS1oZWlnaHQ6IDEuNDI4NTcxNDI5O1xuICAgIGJvcmRlci1yYWRpdXM6IDEwMHB4O1xufVxuXG4uYnRuLWNpcmNsZTpob3ZlciB7XG4gICAgYm94LXNoYWRvdzogcmdiYSgxMDAsIDEwMCwgMTExLCAwLjIpIDAgN3B4IDI5cHggMDtcbn1cblxuLmdyb3cge1xuICAgIHRyYW5zaXRpb246IGFsbCAwLjJzIGVhc2UtaW4tb3V0O1xufVxuXG4uZ3Jvdzpob3ZlciB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZSgxLjEpO1xufVxuXG4uY2VudGVyLWxpbmsge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmJvcmRlci1kYW5nZXIge1xuICAgIGJvcmRlci1jb2xvcjogdmFyKC0tZGFuZ2VyKTtcbn1cblxuLm5vZGUge1xuICAgIHRleHQge1xuICAgICAgICBmaWxsOiB2YXIoLS1ib2R5LWNvbG9yKTtcbiAgICB9XG5cbiAgICByZWN0IHtcbiAgICAgICAgZmlsbDogdmFyKC0tcHJpbWFyeSk7XG4gICAgfVxufVxuXG4jYXJyb3cge1xuICAgIHN0cm9rZTogdmFyKC0tYm9keS1jb2xvcik7XG4gICAgZmlsbDogdmFyKC0tYm9keS1jb2xvcik7XG59XG5cbi5lZGdlIHtcbiAgICBzdHJva2U6IHZhcigtLWJvZHktY29sb3IpICFpbXBvcnRhbnQ7XG4gICAgbWFya2VyLWVuZDogdXJsKCNhcnJvdyk7XG59XG5cbi50ZXh0LXBhdGgge1xuICAgIGZpbGw6IHZhcigtLWJvZHktY29sb3IpO1xufVxuXG46Om5nLWRlZXAgLmFjY29yZGlvbi1ib2R5IHtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIG1heC1oZWlnaHQ6IDYwdmg7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFNBQUE7QUFDQSxVQUFBO0FBQ0EsY0FBQTtBQUNBLFdBQUEsSUFBQTtBQUNBLGFBQUE7QUFDQSxlQUFBO0FBQ0EsaUJBQUE7O0FBR0osQ0FWQSxVQVVBO0FBQ0ksY0FBQSxLQUFBLEdBQUEsRUFBQSxHQUFBLEVBQUEsR0FBQSxFQUFBLEtBQUEsRUFBQSxJQUFBLEtBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUEsSUFBQSxLQUFBOztBQUdKLENBSkEsSUFJQTtBQUNJLGFBQUEsTUFBQTs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLG1CQUFBO0FBQ0EsZUFBQTs7QUFHSixDQUFBO0FBQ0ksZ0JBQUEsSUFBQTs7QUFJQSxDQUFBLEtBQUE7QUFDSSxRQUFBLElBQUE7O0FBR0osQ0FKQSxLQUlBO0FBQ0ksUUFBQSxJQUFBOztBQUlSLENBQUE7QUFDSSxVQUFBLElBQUE7QUFDQSxRQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLFVBQUEsSUFBQTtBQUNBLGNBQUE7O0FBR0osQ0FBQTtBQUNJLFFBQUEsSUFBQTs7QUFHSixVQUFBLENBQUE7QUFDSSxZQUFBO0FBQ0EsY0FBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i09.\u0275setClassDebugInfo(CompetencyManagementComponent, { className: "CompetencyManagementComponent" });
    })();
    Vertex = class {
      label;
      beingVisited;
      visited;
      adjacencyList;
      constructor(label) {
        this.label = label;
        this.adjacencyList = [];
      }
      getLabel() {
        return this.label;
      }
      addNeighbor(adjacent) {
        this.adjacencyList.push(adjacent);
      }
      getAdjacencyList() {
        return this.adjacencyList;
      }
      isBeingVisited() {
        return this.beingVisited;
      }
      setBeingVisited(beingVisited) {
        this.beingVisited = beingVisited;
      }
      isVisited() {
        return this.visited;
      }
      setVisited(visited) {
        this.visited = visited;
      }
    };
    Graph = class {
      vertices;
      constructor() {
        this.vertices = [];
      }
      addVertex(vertex) {
        this.vertices.push(vertex);
      }
      addEdge(from, to) {
        from.addNeighbor(to);
      }
      hasCycle() {
        for (const vertex of this.vertices) {
          if (!vertex.isVisited() && this.vertexHasCycle(vertex)) {
            return true;
          }
        }
        return false;
      }
      vertexHasCycle(sourceVertex) {
        sourceVertex.setBeingVisited(true);
        for (const neighbor of sourceVertex.getAdjacencyList()) {
          if (neighbor.isBeingVisited()) {
            return true;
          } else if (!neighbor.isVisited() && this.vertexHasCycle(neighbor)) {
            return true;
          }
        }
        sourceVertex.setBeingVisited(false);
        sourceVertex.setVisited(true);
        return false;
      }
    };
  }
});

// src/main/webapp/app/course/competencies/competency-rings/competency-rings.component.ts
import { Component as Component9, Input as Input4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i010 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i110 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
var CompetencyRingsComponent;
var init_competency_rings_component = __esm({
  "src/main/webapp/app/course/competencies/competency-rings/competency-rings.component.ts"() {
    init_artemis_translate_pipe();
    CompetencyRingsComponent = class _CompetencyRingsComponent {
      progress = 0;
      confidence = 0;
      mastery = 0;
      hideTooltip = false;
      get progressPercentage() {
        return this.percentageRange(this.progress);
      }
      get confidencePercentage() {
        return this.percentageRange(this.confidence);
      }
      get masteryPercentage() {
        return this.percentageRange(this.mastery);
      }
      percentageRange(value) {
        return Math.min(Math.max(value, 0), 100);
      }
      static \u0275fac = function CompetencyRingsComponent_Factory(t) {
        return new (t || _CompetencyRingsComponent)();
      };
      static \u0275cmp = i010.\u0275\u0275defineComponent({ type: _CompetencyRingsComponent, selectors: [["jhi-competency-rings"]], inputs: { progress: "progress", confidence: "confidence", mastery: "mastery", hideTooltip: "hideTooltip" }, decls: 26, vars: 12, consts: [["viewBox", "0 0 35 35", "xmlns", "http://www.w3.org/2000/svg", 3, "ngbTooltip"], [1, "ring", "ring1"], ["cx", "50%", "cy", "50%", "r", "15.915", "stroke-width", "3", 1, "background"], ["cx", "50%", "cy", "50%", "r", "15.915", "stroke-width", "3", 1, "progressbar"], [1, "ring", "ring2"], ["cx", "50%", "cy", "50%", "r", "15.915", "stroke-width", "4", 1, "background"], ["cx", "50%", "cy", "50%", "r", "15.915", "stroke-width", "4", 1, "progressbar"], [1, "ring", "ring3"], ["cx", "50%", "cy", "50%", "r", "15.915", "stroke-width", "6", 1, "background"], ["cx", "50%", "cy", "50%", "r", "15.915", "stroke-width", "6", 1, "progressbar"]], template: function CompetencyRingsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i010.\u0275\u0275text(0, "\n");
          i010.\u0275\u0275namespaceSVG();
          i010.\u0275\u0275elementStart(1, "svg", 0);
          i010.\u0275\u0275pipe(2, "artemisTranslate");
          i010.\u0275\u0275text(3, "\n    ");
          i010.\u0275\u0275elementStart(4, "g", 1);
          i010.\u0275\u0275text(5, "\n        ");
          i010.\u0275\u0275element(6, "circle", 2);
          i010.\u0275\u0275text(7, "\n        ");
          i010.\u0275\u0275element(8, "circle", 3);
          i010.\u0275\u0275text(9, "\n    ");
          i010.\u0275\u0275elementEnd();
          i010.\u0275\u0275text(10, "\n\n    ");
          i010.\u0275\u0275elementStart(11, "g", 4);
          i010.\u0275\u0275text(12, "\n        ");
          i010.\u0275\u0275element(13, "circle", 5);
          i010.\u0275\u0275text(14, "\n        ");
          i010.\u0275\u0275element(15, "circle", 6);
          i010.\u0275\u0275text(16, "\n    ");
          i010.\u0275\u0275elementEnd();
          i010.\u0275\u0275text(17, "\n\n    ");
          i010.\u0275\u0275elementStart(18, "g", 7);
          i010.\u0275\u0275text(19, "\n        ");
          i010.\u0275\u0275element(20, "circle", 8);
          i010.\u0275\u0275text(21, "\n        ");
          i010.\u0275\u0275element(22, "circle", 9);
          i010.\u0275\u0275text(23, "\n    ");
          i010.\u0275\u0275elementEnd();
          i010.\u0275\u0275text(24, "\n");
          i010.\u0275\u0275elementEnd();
          i010.\u0275\u0275text(25, "\n");
        }
        if (rf & 2) {
          i010.\u0275\u0275advance(1);
          i010.\u0275\u0275property("ngbTooltip", ctx.hideTooltip ? void 0 : i010.\u0275\u0275pipeBind1(2, 10, "artemisApp.competency.competencyCard.ringsTooltip"));
          i010.\u0275\u0275advance(7);
          i010.\u0275\u0275styleProp("opacity", ctx.masteryPercentage === 0 ? 0 : 1);
          i010.\u0275\u0275attribute("stroke-dasharray", ctx.masteryPercentage + ", 100");
          i010.\u0275\u0275advance(7);
          i010.\u0275\u0275styleProp("opacity", ctx.confidencePercentage === 0 ? 0 : 1);
          i010.\u0275\u0275attribute("stroke-dasharray", ctx.confidencePercentage + ", 100");
          i010.\u0275\u0275advance(7);
          i010.\u0275\u0275styleProp("opacity", ctx.progressPercentage === 0 ? 0 : 1);
          i010.\u0275\u0275attribute("stroke-dasharray", ctx.progressPercentage + ", 100");
        }
      }, dependencies: [i110.NgbTooltip, ArtemisTranslatePipe], styles: ["\n\n@keyframes _ngcontent-%COMP%_ring-appear {\n  0% {\n    stroke-dashoffset: 100;\n  }\n  100% {\n    stroke-dashoffset: 0;\n  }\n}\nsvg[_ngcontent-%COMP%] {\n  width: 100%;\n  height: auto;\n}\nsvg[_ngcontent-%COMP%]   .ring[_ngcontent-%COMP%] {\n  transform-origin: 50%;\n}\nsvg[_ngcontent-%COMP%]   .progressbar[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_ring-appear 1s ease-in-out forwards;\n  transition: stroke-dasharray 1s ease-in-out, opacity 1s linear;\n  stroke-linecap: round;\n}\nsvg[_ngcontent-%COMP%]   .progressbar.hidden[_ngcontent-%COMP%] {\n  opacity: 0;\n}\nsvg[_ngcontent-%COMP%]   circle[_ngcontent-%COMP%] {\n  fill: none;\n}\nsvg[_ngcontent-%COMP%]   .ring1[_ngcontent-%COMP%] {\n  transform: scale(1) rotate(-90deg);\n}\nsvg[_ngcontent-%COMP%]   .ring1[_ngcontent-%COMP%]   .background[_ngcontent-%COMP%] {\n  stroke: var(--competency-rings-red-bg);\n}\nsvg[_ngcontent-%COMP%]   .ring1[_ngcontent-%COMP%]   .progressbar[_ngcontent-%COMP%] {\n  stroke: var(--competency-rings-red);\n  animation-duration: 1.6s;\n  transition-duration: 1.6s;\n}\nsvg[_ngcontent-%COMP%]   .ring2[_ngcontent-%COMP%] {\n  transform: scale(0.75) rotate(-90deg);\n}\nsvg[_ngcontent-%COMP%]   .ring2[_ngcontent-%COMP%]   .background[_ngcontent-%COMP%] {\n  stroke: var(--competency-rings-green-bg);\n}\nsvg[_ngcontent-%COMP%]   .ring2[_ngcontent-%COMP%]   .progressbar[_ngcontent-%COMP%] {\n  stroke: var(--competency-rings-green);\n  animation-duration: 1.3s;\n  transition-duration: 1.3s;\n}\nsvg[_ngcontent-%COMP%]   .ring3[_ngcontent-%COMP%] {\n  transform: scale(0.5) rotate(-90deg);\n}\nsvg[_ngcontent-%COMP%]   .ring3[_ngcontent-%COMP%]   .background[_ngcontent-%COMP%] {\n  stroke: var(--competency-rings-blue-bg);\n}\nsvg[_ngcontent-%COMP%]   .ring3[_ngcontent-%COMP%]   .progressbar[_ngcontent-%COMP%] {\n  stroke: var(--competency-rings-blue);\n  animation-duration: 1s;\n  transition-duration: 1s;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvY29tcGV0ZW5jaWVzL2NvbXBldGVuY3ktcmluZ3MvY29tcGV0ZW5jeS1yaW5ncy5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLy8gQWRhcHRlZCBmcm9tIGh0dHBzOi8vd3d3LmNoaWxpdGltZS5kZXNpZ24vMjAxOC8wOS9BY3Rpdml0eVJpbmdzL1xuXG5Aa2V5ZnJhbWVzIHJpbmctYXBwZWFyIHtcbiAgICAwJSB7XG4gICAgICAgIHN0cm9rZS1kYXNob2Zmc2V0OiAxMDA7XG4gICAgfVxuICAgIDEwMCUge1xuICAgICAgICBzdHJva2UtZGFzaG9mZnNldDogMDtcbiAgICB9XG59XG5cbnN2ZyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiBhdXRvO1xuXG4gICAgLnJpbmcge1xuICAgICAgICB0cmFuc2Zvcm0tb3JpZ2luOiA1MCU7XG4gICAgfVxuICAgIC5wcm9ncmVzc2JhciB7XG4gICAgICAgIGFuaW1hdGlvbjogcmluZy1hcHBlYXIgMXMgZWFzZS1pbi1vdXQgZm9yd2FyZHM7XG4gICAgICAgIHRyYW5zaXRpb246XG4gICAgICAgICAgICBzdHJva2UtZGFzaGFycmF5IDFzIGVhc2UtaW4tb3V0LFxuICAgICAgICAgICAgb3BhY2l0eSAxcyBsaW5lYXI7XG4gICAgICAgIHN0cm9rZS1saW5lY2FwOiByb3VuZDtcblxuICAgICAgICAmLmhpZGRlbiB7XG4gICAgICAgICAgICAvLyBVc2Ugb3BhY2l0eTogMCBpbnN0ZWFkIG9mIGRpc3BsYXk6IG5vbmUgdG8gcHJldmVudCBhbmltYXRpb24gd2hlbiBhcHBlYXJpbmdcbiAgICAgICAgICAgIG9wYWNpdHk6IDA7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2lyY2xlIHtcbiAgICAgICAgZmlsbDogbm9uZTtcbiAgICB9XG5cbiAgICAucmluZzEge1xuICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpIHJvdGF0ZSgtOTBkZWcpO1xuXG4gICAgICAgIC5iYWNrZ3JvdW5kIHtcbiAgICAgICAgICAgIHN0cm9rZTogdmFyKC0tY29tcGV0ZW5jeS1yaW5ncy1yZWQtYmcpO1xuICAgICAgICB9XG4gICAgICAgIC5wcm9ncmVzc2JhciB7XG4gICAgICAgICAgICBzdHJva2U6IHZhcigtLWNvbXBldGVuY3ktcmluZ3MtcmVkKTtcbiAgICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogMS42cztcbiAgICAgICAgICAgIHRyYW5zaXRpb24tZHVyYXRpb246IDEuNnM7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAucmluZzIge1xuICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDAuNzUpIHJvdGF0ZSgtOTBkZWcpO1xuXG4gICAgICAgIC5iYWNrZ3JvdW5kIHtcbiAgICAgICAgICAgIHN0cm9rZTogdmFyKC0tY29tcGV0ZW5jeS1yaW5ncy1ncmVlbi1iZyk7XG4gICAgICAgIH1cbiAgICAgICAgLnByb2dyZXNzYmFyIHtcbiAgICAgICAgICAgIHN0cm9rZTogdmFyKC0tY29tcGV0ZW5jeS1yaW5ncy1ncmVlbik7XG4gICAgICAgICAgICBhbmltYXRpb24tZHVyYXRpb246IDEuM3M7XG4gICAgICAgICAgICB0cmFuc2l0aW9uLWR1cmF0aW9uOiAxLjNzO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnJpbmczIHtcbiAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwLjUpIHJvdGF0ZSgtOTBkZWcpO1xuXG4gICAgICAgIC5iYWNrZ3JvdW5kIHtcbiAgICAgICAgICAgIHN0cm9rZTogdmFyKC0tY29tcGV0ZW5jeS1yaW5ncy1ibHVlLWJnKTtcbiAgICAgICAgfVxuICAgICAgICAucHJvZ3Jlc3NiYXIge1xuICAgICAgICAgICAgc3Ryb2tlOiB2YXIoLS1jb21wZXRlbmN5LXJpbmdzLWJsdWUpO1xuICAgICAgICAgICAgYW5pbWF0aW9uLWR1cmF0aW9uOiAxcztcbiAgICAgICAgICAgIHRyYW5zaXRpb24tZHVyYXRpb246IDFzO1xuICAgICAgICB9XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUVBLFdBQUE7QUFDSTtBQUNJLHVCQUFBOztBQUVKO0FBQ0ksdUJBQUE7OztBQUlSO0FBQ0ksU0FBQTtBQUNBLFVBQUE7O0FBRUEsSUFBQSxDQUFBO0FBQ0ksb0JBQUE7O0FBRUosSUFBQSxDQUFBO0FBQ0ksYUFBQSxZQUFBLEdBQUEsWUFBQTtBQUNBLGNBQ0ksaUJBQUEsR0FBQSxXQUFBLEVBQUEsUUFBQSxHQUFBO0FBRUosa0JBQUE7O0FBRUEsSUFBQSxDQVBKLFdBT0ksQ0FBQTtBQUVJLFdBQUE7O0FBR1IsSUFBQTtBQUNJLFFBQUE7O0FBR0osSUFBQSxDQUFBO0FBQ0ksYUFBQSxNQUFBLEdBQUEsT0FBQTs7QUFFQSxJQUFBLENBSEosTUFHSSxDQUFBO0FBQ0ksVUFBQSxJQUFBOztBQUVKLElBQUEsQ0FOSixNQU1JLENBdEJKO0FBdUJRLFVBQUEsSUFBQTtBQUNBLHNCQUFBO0FBQ0EsdUJBQUE7O0FBSVIsSUFBQSxDQUFBO0FBQ0ksYUFBQSxNQUFBLE1BQUEsT0FBQTs7QUFFQSxJQUFBLENBSEosTUFHSSxDQWJBO0FBY0ksVUFBQSxJQUFBOztBQUVKLElBQUEsQ0FOSixNQU1JLENBbkNKO0FBb0NRLFVBQUEsSUFBQTtBQUNBLHNCQUFBO0FBQ0EsdUJBQUE7O0FBSVIsSUFBQSxDQUFBO0FBQ0ksYUFBQSxNQUFBLEtBQUEsT0FBQTs7QUFFQSxJQUFBLENBSEosTUFHSSxDQTFCQTtBQTJCSSxVQUFBLElBQUE7O0FBRUosSUFBQSxDQU5KLE1BTUksQ0FoREo7QUFpRFEsVUFBQSxJQUFBO0FBQ0Esc0JBQUE7QUFDQSx1QkFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i010.\u0275setClassDebugInfo(CompetencyRingsComponent, { className: "CompetencyRingsComponent" });
    })();
  }
});

// src/main/webapp/app/course/competencies/competency-card/competency-card.component.ts
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import { Component as Component10, Input as Input5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { TranslateService as TranslateService3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i011 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i111 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i24 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i35 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i43 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i63 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function CompetencyCardComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n        ");
    i011.\u0275\u0275element(1, "a", 10);
    i011.\u0275\u0275text(2, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("routerLink", i011.\u0275\u0275pureFunction2(1, _c02, ctx_r0.courseId, ctx_r0.competency.id));
  }
}
function CompetencyCardComponent_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275element(1, "fa-icon", 11);
    i011.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r1 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("icon", ctx_r1.getIcon(ctx_r1.competency.taxonomy));
  }
}
function CompetencyCardComponent_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275elementStart(1, "span", 12);
    i011.\u0275\u0275text(2, "Mastered");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(3, "\n                    ");
  }
}
function CompetencyCardComponent_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275elementStart(1, "span", 13);
    i011.\u0275\u0275text(2, "Optional");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(3, "\n                    ");
  }
}
function CompetencyCardComponent_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                    ");
    i011.\u0275\u0275element(1, "p", 14);
    i011.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    const ctx_r4 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("innerHTML", ctx_r4.competency.description, i011.\u0275\u0275sanitizeHtml);
  }
}
function CompetencyCardComponent_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                    ");
    i011.\u0275\u0275elementStart(1, "div");
    i011.\u0275\u0275text(2, "\n                        ");
    i011.\u0275\u0275elementStart(3, "span", 15);
    i011.\u0275\u0275text(4);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(5, "\n                        ");
    i011.\u0275\u0275elementStart(6, "span", 16);
    i011.\u0275\u0275text(7);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(8, "\n                    ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(9, "\n                ");
  }
  if (rf & 2) {
    const ctx_r5 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(4);
    i011.\u0275\u0275textInterpolate(ctx_r5.competency.course.title);
    i011.\u0275\u0275advance(3);
    i011.\u0275\u0275textInterpolate(ctx_r5.competency.course.semester);
  }
}
function CompetencyCardComponent_Conditional_35_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                ");
    i011.\u0275\u0275elementStart(1, "div", 17);
    i011.\u0275\u0275text(2, "\n                    ");
    i011.\u0275\u0275elementStart(3, "span", 18);
    i011.\u0275\u0275text(4);
    i011.\u0275\u0275pipe(5, "artemisTranslate");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(6, "\n                    ");
    i011.\u0275\u0275elementStart(7, "span", 19);
    i011.\u0275\u0275text(8);
    i011.\u0275\u0275pipe(9, "artemisTimeAgo");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(10, "\n                ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(11, "\n            ");
  }
  if (rf & 2) {
    const ctx_r6 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(4);
    i011.\u0275\u0275textInterpolate1(" ", i011.\u0275\u0275pipeBind1(5, 3, "artemisApp.competency.competencyCard.softDueDate"), " ");
    i011.\u0275\u0275advance(3);
    i011.\u0275\u0275property("ngClass", ctx_r6.softDueDatePassed && !ctx_r6.isMastered ? "bg-danger" : "bg-success");
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275textInterpolate1("\n                        ", i011.\u0275\u0275pipeBind1(9, 5, ctx_r6.competency.softDueDate), "\n                    ");
  }
}
function CompetencyCardComponent_Conditional_36_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                ");
    i011.\u0275\u0275elementStart(1, "div", 20);
    i011.\u0275\u0275text(2, "\n                    ");
    i011.\u0275\u0275element(3, "jhi-competency-rings", 21);
    i011.\u0275\u0275text(4, "\n                ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r7 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(3);
    i011.\u0275\u0275property("progress", ctx_r7.progress)("confidence", ctx_r7.confidence)("mastery", ctx_r7.mastery);
  }
}
var _c02, _c12, CompetencyCardComponent;
var init_competency_card_component = __esm({
  "src/main/webapp/app/course/competencies/competency-card/competency-card.component.ts"() {
    init_competency_model();
    init_translate_directive();
    init_competency_rings_component();
    init_artemis_translate_pipe();
    init_artemis_time_ago_pipe();
    _c02 = (a1, a3) => ["/courses", a1, "competencies", a3];
    _c12 = ["*"];
    CompetencyCardComponent = class _CompetencyCardComponent {
      translateService;
      courseId;
      competency;
      isPrerequisite;
      getIcon = getIcon;
      getIconTooltip = getIconTooltip;
      constructor(translateService) {
        this.translateService = translateService;
      }
      getUserProgress() {
        if (this.competency.userProgress?.length) {
          return this.competency.userProgress.first();
        }
        return { progress: 0, confidence: 0 };
      }
      get progress() {
        return this.getUserProgress().progress ?? 0;
      }
      get confidence() {
        return Math.min(Math.round((this.getUserProgress().confidence ?? 0) / (this.competency.masteryThreshold ?? 100) * 100), 100);
      }
      get mastery() {
        const weight = 2 / 3;
        return Math.round((1 - weight) * this.progress + weight * this.confidence);
      }
      get isMastered() {
        return this.mastery >= 100;
      }
      get softDueDatePassed() {
        return dayjs().isAfter(this.competency.softDueDate);
      }
      static \u0275fac = function CompetencyCardComponent_Factory(t) {
        return new (t || _CompetencyCardComponent)(i011.\u0275\u0275directiveInject(i111.TranslateService));
      };
      static \u0275cmp = i011.\u0275\u0275defineComponent({ type: _CompetencyCardComponent, selectors: [["jhi-competency-card"]], inputs: { courseId: "courseId", competency: "competency", isPrerequisite: "isPrerequisite" }, ngContentSelectors: _c12, decls: 40, vars: 20, consts: [[1, "course-exercise-row", "row", "align-items-center", "justify-content-between", "mb-2", "mt-2", "position-relative", 3, "id"], [1, "col-auto", "d-none", "d-sm-block"], [1, "exercise-row-icon"], ["size", "2x", "container", "body", 3, "icon", "ngbTooltip"], [1, "col"], [1, "row"], [1, "col-auto", "d-sm-none"], [1, "fw-medium"], [1, "col-sm", "col", "py-2"], [1, "m-0"], [1, "stretched-link", 3, "routerLink"], [3, "icon"], ["jhiTranslate", "artemisApp.competency.mastered", 1, "badge", "text-white", "text-bg-success"], ["id", "optional-badge", "jhiTranslate", "artemisApp.competency.optional", 1, "badge", "text-white", "bg-warning"], [1, "m-0", 3, "innerHTML"], [1, "badge", "bg-primary"], [1, "badge", "bg-secondary"], [1, "col-sm", "col", "py-2", 2, "max-width", "fit-content"], [2, "vertical-align", "middle"], ["id", "date-badge", 1, "badge", 3, "ngClass"], [1, "col-sm", "col", "text-end", "py-1", "px-2", 2, "max-width", "95px"], [3, "progress", "confidence", "mastery"]], template: function CompetencyCardComponent_Template(rf, ctx) {
        if (rf & 1) {
          i011.\u0275\u0275projectionDef();
          i011.\u0275\u0275elementStart(0, "div", 0);
          i011.\u0275\u0275text(1, "\n    ");
          i011.\u0275\u0275template(2, CompetencyCardComponent_Conditional_2_Template, 3, 4);
          i011.\u0275\u0275elementStart(3, "div", 1);
          i011.\u0275\u0275text(4, "\n        ");
          i011.\u0275\u0275elementStart(5, "a", 2);
          i011.\u0275\u0275text(6, "\n            ");
          i011.\u0275\u0275element(7, "fa-icon", 3);
          i011.\u0275\u0275pipe(8, "artemisTranslate");
          i011.\u0275\u0275text(9, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(10, "\n    ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(11, "\n    ");
          i011.\u0275\u0275elementStart(12, "div", 4);
          i011.\u0275\u0275text(13, "\n        ");
          i011.\u0275\u0275elementStart(14, "div", 5);
          i011.\u0275\u0275text(15, "\n            ");
          i011.\u0275\u0275elementStart(16, "div", 6);
          i011.\u0275\u0275text(17, "\n                ");
          i011.\u0275\u0275elementStart(18, "h4", 7);
          i011.\u0275\u0275text(19, "\n                    ");
          i011.\u0275\u0275template(20, CompetencyCardComponent_Conditional_20_Template, 3, 1);
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(21, "\n            ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(22, "\n            ");
          i011.\u0275\u0275elementStart(23, "div", 8);
          i011.\u0275\u0275text(24, "\n                ");
          i011.\u0275\u0275elementStart(25, "h4", 9);
          i011.\u0275\u0275text(26);
          i011.\u0275\u0275template(27, CompetencyCardComponent_Conditional_27_Template, 4, 0)(28, CompetencyCardComponent_Conditional_28_Template, 4, 0);
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(29, "\n                ");
          i011.\u0275\u0275template(30, CompetencyCardComponent_Conditional_30_Template, 3, 1)(31, CompetencyCardComponent_Conditional_31_Template, 10, 2);
          i011.\u0275\u0275projection(32);
          i011.\u0275\u0275text(33, "\n            ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(34, "\n            ");
          i011.\u0275\u0275template(35, CompetencyCardComponent_Conditional_35_Template, 12, 7)(36, CompetencyCardComponent_Conditional_36_Template, 6, 3);
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(37, "\n    ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(38, "\n");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(39, "\n");
        }
        if (rf & 2) {
          i011.\u0275\u0275classProp("border-secondary", ctx.isPrerequisite)("border-success", ctx.isMastered)("text-secondary", ctx.isMastered);
          i011.\u0275\u0275property("id", "competency-card-" + ctx.competency.id);
          i011.\u0275\u0275advance(2);
          i011.\u0275\u0275conditional(2, ctx.courseId && !ctx.isPrerequisite ? 2 : -1);
          i011.\u0275\u0275advance(5);
          i011.\u0275\u0275property("icon", ctx.getIcon(ctx.competency.taxonomy))("ngbTooltip", i011.\u0275\u0275pipeBind1(8, 18, ctx.getIconTooltip(ctx.competency.taxonomy)));
          i011.\u0275\u0275advance(13);
          i011.\u0275\u0275conditional(20, ctx.competency.taxonomy ? 20 : -1);
          i011.\u0275\u0275advance(6);
          i011.\u0275\u0275textInterpolate1("\n                    ", ctx.competency.title, "\n                    ");
          i011.\u0275\u0275advance(1);
          i011.\u0275\u0275conditional(27, ctx.isMastered ? 27 : -1);
          i011.\u0275\u0275advance(1);
          i011.\u0275\u0275conditional(28, ctx.competency.optional ? 28 : -1);
          i011.\u0275\u0275advance(2);
          i011.\u0275\u0275conditional(30, ctx.competency.description ? 30 : -1);
          i011.\u0275\u0275advance(1);
          i011.\u0275\u0275conditional(31, ctx.isPrerequisite && ctx.competency.course ? 31 : -1);
          i011.\u0275\u0275advance(4);
          i011.\u0275\u0275conditional(35, !ctx.isPrerequisite && ctx.competency.softDueDate ? 35 : -1);
          i011.\u0275\u0275advance(1);
          i011.\u0275\u0275conditional(36, !ctx.isPrerequisite ? 36 : -1);
        }
      }, dependencies: [i24.NgClass, i35.NgbTooltip, i43.FaIconComponent, TranslateDirective, i63.RouterLink, CompetencyRingsComponent, ArtemisTranslatePipe, ArtemisTimeAgoPipe], styles: ["\n\n[_nghost-%COMP%] {\n  cursor: pointer;\n}\n[_nghost-%COMP%]    > div[_ngcontent-%COMP%] {\n  padding: 5px 0;\n  border: 1px solid var(--overview-blue-border-color);\n  background-color: var(--overview-light-background-color);\n  border-radius: 3px;\n  transition: transform 0.2s linear;\n}\n[_nghost-%COMP%]    > div[_ngcontent-%COMP%]   .row[_ngcontent-%COMP%] {\n  min-height: 35px;\n  align-items: center;\n}\n[_nghost-%COMP%]    > div[_ngcontent-%COMP%]:hover {\n  transform: scale(1.012);\n  background-color: var(--hover-slightly-darker-body-bg);\n}\n[_nghost-%COMP%]    > div[_ngcontent-%COMP%]   .exercise-link[_ngcontent-%COMP%] {\n  color: #212529;\n}\n[_nghost-%COMP%]   .course-exercise-row[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  padding: 0.5rem 1rem;\n}\n[_nghost-%COMP%]   .exercise-row-icon[_ngcontent-%COMP%] {\n  color: var(--bs-body-color);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-right: 1rem;\n  min-width: 40px;\n}\n[_nghost-%COMP%]   .exercise-row-icon[_ngcontent-%COMP%]    > fa-icon[_ngcontent-%COMP%] {\n  z-index: 1;\n}\n[_nghost-%COMP%]   .result[_ngcontent-%COMP%] {\n  width: unset;\n  z-index: 2;\n}\n[_nghost-%COMP%]   .due-date[_ngcontent-%COMP%] {\n  z-index: 1;\n}\n.raised-actions[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 1;\n}\n@media (min-width: 768px) {\n  .max-width[_ngcontent-%COMP%] {\n    max-width: 90%;\n  }\n}\n@media (max-width: 767px) {\n  .max-width[_ngcontent-%COMP%] {\n    max-width: 100%;\n  }\n}\n.exercise-title[_ngcontent-%COMP%] {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9jb3Vyc2UtZXhlcmNpc2VzL2NvdXJzZS1leGVyY2lzZS1yb3cuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiQGltcG9ydCAnbm9kZV9tb2R1bGVzL2Jvb3RzdHJhcC9zY3NzL2Z1bmN0aW9ucyc7XG5AaW1wb3J0ICdub2RlX21vZHVsZXMvYm9vdHN0cmFwL3Njc3MvdmFyaWFibGVzJztcbkBpbXBvcnQgJ25vZGVfbW9kdWxlcy9ib290c3RyYXAvc2Nzcy9taXhpbnMnO1xuXG46aG9zdCB7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuXG4gICAgPiBkaXYge1xuICAgICAgICBwYWRkaW5nOiA1cHggMDtcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tb3ZlcnZpZXctYmx1ZS1ib3JkZXItY29sb3IpO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1vdmVydmlldy1saWdodC1iYWNrZ3JvdW5kLWNvbG9yKTtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogM3B4O1xuICAgICAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC4ycyBsaW5lYXI7XG4gICAgICAgIC5yb3cge1xuICAgICAgICAgICAgbWluLWhlaWdodDogMzVweDtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIH1cbiAgICAgICAgJjpob3ZlciB7XG4gICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEuMDEyKTtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWhvdmVyLXNsaWdodGx5LWRhcmtlci1ib2R5LWJnKTtcbiAgICAgICAgfVxuICAgICAgICAuZXhlcmNpc2UtbGluayB7XG4gICAgICAgICAgICBjb2xvcjogIzIxMjUyOTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5jb3Vyc2UtZXhlcmNpc2Utcm93IHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgZmxleC13cmFwOiB3cmFwO1xuICAgICAgICBwYWRkaW5nOiAwLjVyZW0gMXJlbTtcbiAgICB9XG5cbiAgICAuZXhlcmNpc2Utcm93LWljb24ge1xuICAgICAgICBjb2xvcjogdmFyKC0tYnMtYm9keS1jb2xvcik7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDFyZW07XG4gICAgICAgIG1pbi13aWR0aDogNDBweDtcblxuICAgICAgICA+IGZhLWljb24ge1xuICAgICAgICAgICAgei1pbmRleDogMTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5yZXN1bHQge1xuICAgICAgICB3aWR0aDogdW5zZXQ7XG4gICAgICAgIHotaW5kZXg6IDI7XG4gICAgfVxuXG4gICAgLmR1ZS1kYXRlIHtcbiAgICAgICAgei1pbmRleDogMTtcbiAgICB9XG59XG5cbi5yYWlzZWQtYWN0aW9ucyB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHotaW5kZXg6IDE7XG59XG5cbi5tYXgtd2lkdGgge1xuICAgIEBtZWRpYSAobWluLXdpZHRoOiA3NjhweCkge1xuICAgICAgICBtYXgtd2lkdGg6IDkwJTtcbiAgICB9XG5cbiAgICBAbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgICAgICAgbWF4LXdpZHRoOiAxMDAlO1xuICAgIH1cbn1cblxuLmV4ZXJjaXNlLXRpdGxlIHtcbiAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gICAgbWF4LXdpZHRoOiAxMDAlO1xufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUlBO0FBQ0ksVUFBQTs7QUFFQSxNQUFBLEVBQUE7QUFDSSxXQUFBLElBQUE7QUFDQSxVQUFBLElBQUEsTUFBQSxJQUFBO0FBQ0Esb0JBQUEsSUFBQTtBQUNBLGlCQUFBO0FBQ0EsY0FBQSxVQUFBLEtBQUE7O0FBQ0EsTUFBQSxFQUFBLElBQUEsQ0FBQTtBQUNJLGNBQUE7QUFDQSxlQUFBOztBQUVKLE1BQUEsRUFBQSxHQUFBO0FBQ0ksYUFBQSxNQUFBO0FBQ0Esb0JBQUEsSUFBQTs7QUFFSixNQUFBLEVBQUEsSUFBQSxDQUFBO0FBQ0ksU0FBQTs7QUFJUixNQUFBLENBQUE7QUFDSSxXQUFBO0FBQ0EsYUFBQTtBQUNBLFdBQUEsT0FBQTs7QUFHSixNQUFBLENBQUE7QUFDSSxTQUFBLElBQUE7QUFDQSxXQUFBO0FBQ0EsZUFBQTtBQUNBLG1CQUFBO0FBQ0EsZ0JBQUE7QUFDQSxhQUFBOztBQUVBLE1BQUEsQ0FSSixrQkFRSSxFQUFBO0FBQ0ksV0FBQTs7QUFJUixNQUFBLENBQUE7QUFDSSxTQUFBO0FBQ0EsV0FBQTs7QUFHSixNQUFBLENBQUE7QUFDSSxXQUFBOztBQUlSLENBQUE7QUFDSSxZQUFBO0FBQ0EsV0FBQTs7QUFJQSxPQUFBLENBQUEsU0FBQSxFQUFBO0FBREosR0FBQTtBQUVRLGVBQUE7OztBQUdKLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFMSixHQUFBO0FBTVEsZUFBQTs7O0FBSVIsQ0FBQTtBQUNJLGVBQUE7QUFDQSxZQUFBO0FBQ0EsaUJBQUE7QUFDQSxhQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i011.\u0275setClassDebugInfo(CompetencyCardComponent, { className: "CompetencyCardComponent" });
    })();
  }
});

// src/main/webapp/app/course/competencies/competency.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { RouterModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { FormsModule, ReactiveFormsModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import { NgxGraphModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-graph.js?v=1d0d9ead";
import { NgbAccordionModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i012 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisCompetenciesModule;
var init_competency_module = __esm({
  "src/main/webapp/app/course/competencies/competency.module.ts"() {
    init_competency_form_component();
    init_create_competency_component();
    init_shared_module();
    init_shared_component_module();
    init_edit_competency_component();
    init_competency_management_component();
    init_competency_card_component();
    init_competencies_popover_component();
    init_prerequisite_import_component();
    init_competency_rings_component();
    init_competency_import_component();
    init_date_time_picker_module();
    ArtemisCompetenciesModule = class _ArtemisCompetenciesModule {
      static \u0275fac = function ArtemisCompetenciesModule_Factory(t) {
        return new (t || _ArtemisCompetenciesModule)();
      };
      static \u0275mod = i012.\u0275\u0275defineNgModule({ type: _ArtemisCompetenciesModule });
      static \u0275inj = i012.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, FormsModule, ReactiveFormsModule, NgxGraphModule, ArtemisSharedComponentModule, RouterModule, FormDateTimePickerModule, NgbAccordionModule] });
    };
  }
});

export {
  CompetencyRingsComponent,
  init_competency_rings_component,
  CompetencyCardComponent,
  init_competency_card_component,
  CompetencyFormComponent,
  init_competency_form_component,
  CreateCompetencyComponent,
  init_create_competency_component,
  EditCompetencyComponent,
  init_edit_competency_component,
  CompetencyManagementComponent,
  init_competency_management_component,
  CompetenciesPopoverComponent,
  init_competencies_popover_component,
  ArtemisCompetenciesModule,
  init_competency_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL2NvbXBldGVuY2llcy9jb21wZXRlbmNpZXMtcG9wb3Zlci9jb21wZXRlbmNpZXMtcG9wb3Zlci5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jaWVzLXBvcG92ZXIvY29tcGV0ZW5jaWVzLXBvcG92ZXIuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jeS1mb3JtL2NvbXBldGVuY3ktZm9ybS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jeS1mb3JtL2NvbXBldGVuY3ktZm9ybS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL2NvbXBldGVuY2llcy9jcmVhdGUtY29tcGV0ZW5jeS9jcmVhdGUtY29tcGV0ZW5jeS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY3JlYXRlLWNvbXBldGVuY3kvY3JlYXRlLWNvbXBldGVuY3kuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvZWRpdC1jb21wZXRlbmN5L2VkaXQtY29tcGV0ZW5jeS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvZWRpdC1jb21wZXRlbmN5L2VkaXQtY29tcGV0ZW5jeS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL2NvbXBldGVuY2llcy9jb21wZXRlbmN5LXBhZ2luZy5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvaW1wb3J0L2ltcG9ydC1jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jeS1tYW5hZ2VtZW50L2NvbXBldGVuY3ktaW1wb3J0LmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL2NvbXBldGVuY2llcy9jb21wZXRlbmN5LW1hbmFnZW1lbnQvY29tcGV0ZW5jeS1pbXBvcnQuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jeS1tYW5hZ2VtZW50L3ByZXJlcXVpc2l0ZS1pbXBvcnQuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvY29tcGV0ZW5jaWVzL2NvbXBldGVuY3ktbWFuYWdlbWVudC9wcmVyZXF1aXNpdGUtaW1wb3J0LmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvY29tcGV0ZW5jaWVzL2NvbXBldGVuY3ktbWFuYWdlbWVudC9jb21wZXRlbmN5LW1hbmFnZW1lbnQuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvY29tcGV0ZW5jaWVzL2NvbXBldGVuY3ktbWFuYWdlbWVudC9jb21wZXRlbmN5LW1hbmFnZW1lbnQuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jeS1yaW5ncy9jb21wZXRlbmN5LXJpbmdzLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL2NvbXBldGVuY2llcy9jb21wZXRlbmN5LXJpbmdzL2NvbXBldGVuY3ktcmluZ3MuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jeS1jYXJkL2NvbXBldGVuY3ktY2FyZC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jeS1jYXJkL2NvbXBldGVuY3ktY2FyZC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL2NvbXBldGVuY2llcy9jb21wZXRlbmN5Lm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQsIFZpZXdFbmNhcHN1bGF0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBmYUZsYWcgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgQ29tcGV0ZW5jeSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb21wZXRlbmN5Lm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktY29tcGV0ZW5jaWVzLXBvcG92ZXInLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9jb21wZXRlbmNpZXMtcG9wb3Zlci5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vY29tcGV0ZW5jaWVzLXBvcG92ZXIuY29tcG9uZW50LnNjc3MnXSxcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxufSlcbmV4cG9ydCBjbGFzcyBDb21wZXRlbmNpZXNQb3BvdmVyQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICBASW5wdXQoKVxuICAgIGNvdXJzZUlkOiBudW1iZXI7XG4gICAgQElucHV0KClcbiAgICBjb21wZXRlbmNpZXM6IENvbXBldGVuY3lbXSA9IFtdO1xuICAgIEBJbnB1dCgpXG4gICAgbmF2aWdhdGVUbzogJ2NvbXBldGVuY3lNYW5hZ2VtZW50JyB8ICdjb3Vyc2VDb21wZXRlbmNpZXMnID0gJ2NvdXJzZUNvbXBldGVuY2llcyc7XG5cbiAgICBuYXZpZ2F0aW9uQXJyYXk6IHN0cmluZ1tdID0gW107XG5cbiAgICAvLyBJY29uc1xuICAgIGZhRmxhZyA9IGZhRmxhZztcblxuICAgIGNvbnN0cnVjdG9yKCkge31cblxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICBpZiAodGhpcy5jb3Vyc2VJZCkge1xuICAgICAgICAgICAgc3dpdGNoICh0aGlzLm5hdmlnYXRlVG8pIHtcbiAgICAgICAgICAgICAgICBjYXNlICdjb3Vyc2VDb21wZXRlbmNpZXMnOiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubmF2aWdhdGlvbkFycmF5ID0gWycvY291cnNlcycsIGAke3RoaXMuY291cnNlSWR9YCwgJ2NvbXBldGVuY2llcyddO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2FzZSAnY29tcGV0ZW5jeU1hbmFnZW1lbnQnOiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubmF2aWdhdGlvbkFycmF5ID0gWycvY291cnNlLW1hbmFnZW1lbnQnLCBgJHt0aGlzLmNvdXJzZUlkfWAsICdjb21wZXRlbmN5LW1hbmFnZW1lbnQnXTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuIiwiPG5nLXRlbXBsYXRlICNwb3BUaXRsZT5cbiAgICA8c3BhbiBjbGFzcz1cImZvbnQtd2VpZ2h0LWJvbGRcIj57eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LmNvbXBldGVuY3lQb3BvdmVyLmNvbm5lY3RlZENvbXBldGVuY2llcycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPjwvbmctdGVtcGxhdGVcbj5cbjxuZy10ZW1wbGF0ZSAjcG9wQ29udGVudD5cbiAgICBAaWYgKGNvbXBldGVuY2llcyAmJiBjb21wZXRlbmNpZXMubGVuZ3RoID4gMCkge1xuICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPHNtYWxsPlxuICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kuY29tcGV0ZW5jeVBvcG92ZXIuZXhwbGFuYXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgPC9zbWFsbD5cbiAgICAgICAgICAgIDx1bCBjbGFzcz1cImxpc3QtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICBAZm9yIChjb21wZXRlbmN5IG9mIGNvbXBldGVuY2llczsgdHJhY2sgY29tcGV0ZW5jeSkge1xuICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImxpc3QtZ3JvdXAtaXRlbVwiIFtyb3V0ZXJMaW5rXT1cIm5hdmlnYXRpb25BcnJheVwiPnt7IGNvbXBldGVuY3kudGl0bGUgfX08L2E+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgPC9kaXY+XG4gICAgfSBAZWxzZSB7XG4gICAgICAgIDxhIFtyb3V0ZXJMaW5rXT1cIm5hdmlnYXRpb25BcnJheVwiPnt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kuY29tcGV0ZW5jeVBvcG92ZXIubm9Db21wZXRlbmNpZXMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvYT5cbiAgICB9XG48L25nLXRlbXBsYXRlPlxuPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLXNtIGJ0bi1wcmltYXJ5IGNvbXBldGVuY3ktYnV0dG9uXCIgW25nYlBvcG92ZXJdPVwicG9wQ29udGVudFwiIFtwb3BvdmVyVGl0bGVdPVwicG9wVGl0bGVcIiBwb3BvdmVyQ2xhc3M9XCJjb21wZXRlbmN5LXBvcG92ZXJcIj5cbiAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUZsYWdcIiBbZml4ZWRXaWR0aF09XCJ0cnVlXCI+PC9mYS1pY29uPlxuPC9idXR0b24+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uQ2hhbmdlcywgT25Jbml0LCBPdXRwdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZvcm1CdWlsZGVyLCBGb3JtQ29udHJvbCwgRm9ybUdyb3VwLCBWYWxpZGF0b3JzIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgQ29tcGV0ZW5jeVNlcnZpY2UgfSBmcm9tICdhcHAvY291cnNlL2NvbXBldGVuY2llcy9jb21wZXRlbmN5LnNlcnZpY2UnO1xuaW1wb3J0IHsgbWVyZ2UsIG9mIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBkZWxheSwgbWFwLCBzd2l0Y2hNYXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBMZWN0dXJlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2xlY3R1cmUubW9kZWwnO1xuaW1wb3J0IHsgTGVjdHVyZVVuaXQgfSBmcm9tICdhcHAvZW50aXRpZXMvbGVjdHVyZS11bml0L2xlY3R1cmVVbml0Lm1vZGVsJztcbmltcG9ydCB7IFRyYW5zbGF0ZVNlcnZpY2UgfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcbmltcG9ydCB7IExlY3R1cmVVbml0U2VydmljZSB9IGZyb20gJ2FwcC9sZWN0dXJlL2xlY3R1cmUtdW5pdC9sZWN0dXJlLXVuaXQtbWFuYWdlbWVudC9sZWN0dXJlVW5pdC5zZXJ2aWNlJztcbmltcG9ydCB7IGludGVyc2VjdGlvbiB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBDb21wZXRlbmN5VGF4b25vbXkgfSBmcm9tICdhcHAvZW50aXRpZXMvY29tcGV0ZW5jeS5tb2RlbCc7XG5pbXBvcnQgeyBmYVF1ZXN0aW9uQ2lyY2xlLCBmYVRpbWVzIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCBkYXlqcyBmcm9tICdkYXlqcy9lc20nO1xuXG4vKipcbiAqIEFzeW5jIFZhbGlkYXRvciB0byBtYWtlIHN1cmUgdGhhdCBhIGNvbXBldGVuY3kgdGl0bGUgaXMgdW5pcXVlIHdpdGhpbiBhIGNvdXJzZVxuICovXG5leHBvcnQgY29uc3QgdGl0bGVVbmlxdWVWYWxpZGF0b3IgPSAoY29tcGV0ZW5jeVNlcnZpY2U6IENvbXBldGVuY3lTZXJ2aWNlLCBjb3Vyc2VJZDogbnVtYmVyLCBpbml0aWFsVGl0bGU/OiBzdHJpbmcpID0+IHtcbiAgICByZXR1cm4gKGNvbXBldGVuY3lUaXRsZUNvbnRyb2w6IEZvcm1Db250cm9sPHN0cmluZyB8IHVuZGVmaW5lZD4pID0+IHtcbiAgICAgICAgcmV0dXJuIG9mKGNvbXBldGVuY3lUaXRsZUNvbnRyb2wudmFsdWUpLnBpcGUoXG4gICAgICAgICAgICBkZWxheSgyNTApLFxuICAgICAgICAgICAgc3dpdGNoTWFwKCh0aXRsZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChpbml0aWFsVGl0bGUgJiYgdGl0bGUgPT09IGluaXRpYWxUaXRsZSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gb2YobnVsbCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBjb21wZXRlbmN5U2VydmljZS5nZXRBbGxGb3JDb3Vyc2UoY291cnNlSWQpLnBpcGUoXG4gICAgICAgICAgICAgICAgICAgIG1hcCgocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29tcGV0ZW5jeVRpdGxlczogc3RyaW5nW10gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXMuYm9keSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBldGVuY3lUaXRsZXMgPSByZXMuYm9keS5tYXAoKGNvbXBldGVuY3kpID0+IGNvbXBldGVuY3kudGl0bGUhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aXRsZSAmJiBjb21wZXRlbmN5VGl0bGVzLmluY2x1ZGVzKHRpdGxlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlVW5pcXVlOiB7IHZhbGlkOiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgY2F0Y2hFcnJvcigoKSA9PiBvZihudWxsKSksXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH07XG59O1xuXG5leHBvcnQgaW50ZXJmYWNlIENvbXBldGVuY3lGb3JtRGF0YSB7XG4gICAgaWQ/OiBudW1iZXI7XG4gICAgdGl0bGU/OiBzdHJpbmc7XG4gICAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gICAgc29mdER1ZURhdGU/OiBkYXlqcy5EYXlqcztcbiAgICB0YXhvbm9teT86IENvbXBldGVuY3lUYXhvbm9teTtcbiAgICBvcHRpb25hbD86IGJvb2xlYW47XG4gICAgbWFzdGVyeVRocmVzaG9sZD86IG51bWJlcjtcbiAgICBjb25uZWN0ZWRMZWN0dXJlVW5pdHM/OiBMZWN0dXJlVW5pdFtdO1xufVxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1jb21wZXRlbmN5LWZvcm0nLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9jb21wZXRlbmN5LWZvcm0uY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL2NvbXBldGVuY3ktZm9ybS5jb21wb25lbnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBDb21wZXRlbmN5Rm9ybUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcbiAgICBASW5wdXQoKVxuICAgIGZvcm1EYXRhOiBDb21wZXRlbmN5Rm9ybURhdGEgPSB7XG4gICAgICAgIGlkOiB1bmRlZmluZWQsXG4gICAgICAgIHRpdGxlOiB1bmRlZmluZWQsXG4gICAgICAgIGRlc2NyaXB0aW9uOiB1bmRlZmluZWQsXG4gICAgICAgIHNvZnREdWVEYXRlOiB1bmRlZmluZWQsXG4gICAgICAgIHRheG9ub215OiB1bmRlZmluZWQsXG4gICAgICAgIG1hc3RlcnlUaHJlc2hvbGQ6IHVuZGVmaW5lZCxcbiAgICAgICAgb3B0aW9uYWw6IGZhbHNlLFxuICAgICAgICBjb25uZWN0ZWRMZWN0dXJlVW5pdHM6IHVuZGVmaW5lZCxcbiAgICB9O1xuXG4gICAgQElucHV0KClcbiAgICBpc0VkaXRNb2RlID0gZmFsc2U7XG4gICAgQElucHV0KClcbiAgICBpc0luQ29ubmVjdE1vZGUgPSBmYWxzZTtcbiAgICBASW5wdXQoKVxuICAgIGlzSW5TaW5nbGVMZWN0dXJlTW9kZSA9IGZhbHNlO1xuICAgIEBJbnB1dCgpXG4gICAgY291cnNlSWQ6IG51bWJlcjtcbiAgICBASW5wdXQoKVxuICAgIGxlY3R1cmVzT2ZDb3Vyc2VXaXRoTGVjdHVyZVVuaXRzOiBMZWN0dXJlW10gPSBbXTtcbiAgICBASW5wdXQoKVxuICAgIGF2ZXJhZ2VTdHVkZW50U2NvcmU/OiBudW1iZXI7XG4gICAgQElucHV0KClcbiAgICBoYXNDYW5jZWxCdXR0b246IGJvb2xlYW47XG4gICAgQE91dHB1dCgpXG4gICAgb25DYW5jZWw6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcjxhbnk+KCk7XG5cbiAgICB0aXRsZVVuaXF1ZVZhbGlkYXRvciA9IHRpdGxlVW5pcXVlVmFsaWRhdG9yO1xuICAgIGNvbXBldGVuY3lUYXhvbm9teSA9IENvbXBldGVuY3lUYXhvbm9teTtcblxuICAgIEBPdXRwdXQoKVxuICAgIGZvcm1TdWJtaXR0ZWQ6IEV2ZW50RW1pdHRlcjxDb21wZXRlbmN5Rm9ybURhdGE+ID0gbmV3IEV2ZW50RW1pdHRlcjxDb21wZXRlbmN5Rm9ybURhdGE+KCk7XG5cbiAgICBmb3JtOiBGb3JtR3JvdXA7XG4gICAgc2VsZWN0ZWRMZWN0dXJlSW5Ecm9wZG93bjogTGVjdHVyZTtcbiAgICBzZWxlY3RlZExlY3R1cmVVbml0c0luVGFibGU6IExlY3R1cmVVbml0W10gPSBbXTtcbiAgICBzdWdnZXN0ZWRUYXhvbm9taWVzOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgZmFUaW1lcyA9IGZhVGltZXM7XG4gICAgZmFRdWVzdGlvbkNpcmNsZSA9IGZhUXVlc3Rpb25DaXJjbGU7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBmYjogRm9ybUJ1aWxkZXIsXG4gICAgICAgIHByaXZhdGUgY29tcGV0ZW5jeVNlcnZpY2U6IENvbXBldGVuY3lTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHRyYW5zbGF0ZVNlcnZpY2U6IFRyYW5zbGF0ZVNlcnZpY2UsXG4gICAgICAgIHB1YmxpYyBsZWN0dXJlVW5pdFNlcnZpY2U6IExlY3R1cmVVbml0U2VydmljZSxcbiAgICApIHt9XG5cbiAgICBnZXQgdGl0bGVDb250cm9sKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5mb3JtLmdldCgndGl0bGUnKTtcbiAgICB9XG5cbiAgICBnZXQgZGVzY3JpcHRpb25Db250cm9sKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5mb3JtLmdldCgnZGVzY3JpcHRpb24nKTtcbiAgICB9XG5cbiAgICBnZXQgc29mdER1ZURhdGVDb250cm9sKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5mb3JtLmdldCgnc29mdER1ZURhdGUnKTtcbiAgICB9XG5cbiAgICBnZXQgbWFzdGVyeVRocmVzaG9sZENvbnRyb2woKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmZvcm0uZ2V0KCdtYXN0ZXJ5VGhyZXNob2xkJyk7XG4gICAgfVxuXG4gICAgZ2V0IG9wdGlvbmFsQ29udHJvbCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZm9ybS5nZXQoJ29wdGlvbmFsJyk7XG4gICAgfVxuXG4gICAgbmdPbkNoYW5nZXMoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuaW5pdGlhbGl6ZUZvcm0oKTtcbiAgICAgICAgaWYgKHRoaXMuaXNFZGl0TW9kZSAmJiB0aGlzLmZvcm1EYXRhKSB7XG4gICAgICAgICAgICB0aGlzLnNldEZvcm1WYWx1ZXModGhpcy5mb3JtRGF0YSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5pbml0aWFsaXplRm9ybSgpO1xuICAgIH1cblxuICAgIHByaXZhdGUgaW5pdGlhbGl6ZUZvcm0oKSB7XG4gICAgICAgIGlmICh0aGlzLmZvcm0pIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBsZXQgaW5pdGlhbFRpdGxlOiBzdHJpbmcgfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG4gICAgICAgIGlmICh0aGlzLmlzRWRpdE1vZGUgJiYgdGhpcy5mb3JtRGF0YSAmJiB0aGlzLmZvcm1EYXRhLnRpdGxlKSB7XG4gICAgICAgICAgICBpbml0aWFsVGl0bGUgPSB0aGlzLmZvcm1EYXRhLnRpdGxlO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZm9ybSA9IHRoaXMuZmIuZ3JvdXAoe1xuICAgICAgICAgICAgdGl0bGU6IFtcbiAgICAgICAgICAgICAgICB1bmRlZmluZWQgYXMgc3RyaW5nIHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIFtWYWxpZGF0b3JzLnJlcXVpcmVkLCBWYWxpZGF0b3JzLm1heExlbmd0aCgyNTUpXSxcbiAgICAgICAgICAgICAgICBbdGhpcy50aXRsZVVuaXF1ZVZhbGlkYXRvcih0aGlzLmNvbXBldGVuY3lTZXJ2aWNlLCB0aGlzLmNvdXJzZUlkLCBpbml0aWFsVGl0bGUpXSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogW3VuZGVmaW5lZCBhcyBzdHJpbmcgfCB1bmRlZmluZWQsIFtWYWxpZGF0b3JzLm1heExlbmd0aCgxMDAwMCldXSxcbiAgICAgICAgICAgIHNvZnREdWVEYXRlOiBbdW5kZWZpbmVkXSxcbiAgICAgICAgICAgIHRheG9ub215OiBbdW5kZWZpbmVkLCBbVmFsaWRhdG9ycy5wYXR0ZXJuKCdeKCcgKyBPYmplY3Qua2V5cyh0aGlzLmNvbXBldGVuY3lUYXhvbm9teSkuam9pbignfCcpICsgJykkJyldXSxcbiAgICAgICAgICAgIG1hc3RlcnlUaHJlc2hvbGQ6IFt1bmRlZmluZWQsIFtWYWxpZGF0b3JzLm1pbigwKSwgVmFsaWRhdG9ycy5tYXgoMTAwKV1dLFxuICAgICAgICAgICAgb3B0aW9uYWw6IFtmYWxzZV0sXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLnNlbGVjdGVkTGVjdHVyZVVuaXRzSW5UYWJsZSA9IFtdO1xuXG4gICAgICAgIG1lcmdlKHRoaXMudGl0bGVDb250cm9sIS52YWx1ZUNoYW5nZXMsIHRoaXMuZGVzY3JpcHRpb25Db250cm9sIS52YWx1ZUNoYW5nZXMpLnN1YnNjcmliZSgoKSA9PiB0aGlzLnN1Z2dlc3RUYXhvbm9taWVzKCkpO1xuXG4gICAgICAgIGlmICh0aGlzLmlzSW5TaW5nbGVMZWN0dXJlTW9kZSkge1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RMZWN0dXJlSW5Ecm9wZG93bih0aGlzLmxlY3R1cmVzT2ZDb3Vyc2VXaXRoTGVjdHVyZVVuaXRzLmZpcnN0KCkhKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgc2V0Rm9ybVZhbHVlcyhmb3JtRGF0YTogQ29tcGV0ZW5jeUZvcm1EYXRhKSB7XG4gICAgICAgIHRoaXMuZm9ybS5wYXRjaFZhbHVlKGZvcm1EYXRhKTtcbiAgICAgICAgaWYgKGZvcm1EYXRhLmNvbm5lY3RlZExlY3R1cmVVbml0cykge1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZExlY3R1cmVVbml0c0luVGFibGUgPSBmb3JtRGF0YS5jb25uZWN0ZWRMZWN0dXJlVW5pdHM7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBjYW5jZWxGb3JtKCkge1xuICAgICAgICB0aGlzLm9uQ2FuY2VsLmVtaXQoKTtcbiAgICB9XG5cbiAgICBzdWJtaXRGb3JtKCkge1xuICAgICAgICBjb25zdCBjb21wZXRlbmN5Rm9ybURhdGE6IENvbXBldGVuY3lGb3JtRGF0YSA9IHsgLi4udGhpcy5mb3JtLnZhbHVlIH07XG4gICAgICAgIGNvbXBldGVuY3lGb3JtRGF0YS5jb25uZWN0ZWRMZWN0dXJlVW5pdHMgPSB0aGlzLnNlbGVjdGVkTGVjdHVyZVVuaXRzSW5UYWJsZTtcbiAgICAgICAgdGhpcy5mb3JtU3VibWl0dGVkLmVtaXQoY29tcGV0ZW5jeUZvcm1EYXRhKTtcbiAgICB9XG5cbiAgICBnZXQgaXNTdWJtaXRQb3NzaWJsZSgpIHtcbiAgICAgICAgcmV0dXJuICF0aGlzLmZvcm0uaW52YWxpZDtcbiAgICB9XG5cbiAgICBzZWxlY3RMZWN0dXJlSW5Ecm9wZG93bihsZWN0dXJlOiBMZWN0dXJlKSB7XG4gICAgICAgIHRoaXMuc2VsZWN0ZWRMZWN0dXJlSW5Ecm9wZG93biA9IGxlY3R1cmU7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTmVlZGVkIHRvIGtlZXAgdGhlIG9yZGVyIGluIGtleXZhbHVlIHBpcGVcbiAgICAgKi9cbiAgICBrZWVwT3JkZXIgPSAoKSA9PiB7XG4gICAgICAgIHJldHVybiAwO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBTdWdnZXN0IHNvbWUgdGF4b25vbWllcyBiYXNlZCBvbiBrZXl3b3JkcyB1c2VkIGluIHRoZSB0aXRsZSBvciBkZXNjcmlwdGlvbi5cbiAgICAgKiBUcmlnZ2VyZWQgYWZ0ZXIgdGhlIHVzZXIgY2hhbmdlcyB0aGUgdGl0bGUgb3IgZGVzY3JpcHRpb24gaW5wdXQgZmllbGQuXG4gICAgICovXG4gICAgc3VnZ2VzdFRheG9ub21pZXMoKSB7XG4gICAgICAgIHRoaXMuc3VnZ2VzdGVkVGF4b25vbWllcyA9IFtdO1xuICAgICAgICBjb25zdCB0aXRsZSA9IHRoaXMudGl0bGVDb250cm9sPy52YWx1ZT8udG9Mb3dlckNhc2UoKSA/PyAnJztcbiAgICAgICAgY29uc3QgZGVzY3JpcHRpb24gPSB0aGlzLmRlc2NyaXB0aW9uQ29udHJvbD8udmFsdWU/LnRvTG93ZXJDYXNlKCkgPz8gJyc7XG4gICAgICAgIGZvciAoY29uc3QgdGF4b25vbXkgaW4gdGhpcy5jb21wZXRlbmN5VGF4b25vbXkpIHtcbiAgICAgICAgICAgIGNvbnN0IGtleXdvcmRzID0gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQoJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5rZXl3b3Jkcy4nICsgdGF4b25vbXkudG9Mb3dlckNhc2UoKSkuc3BsaXQoJywgJyk7XG4gICAgICAgICAgICBjb25zdCB0YXhvbm9teU5hbWUgPSB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LnRheG9ub21pZXMuJyArIHRheG9ub215LnRvTG93ZXJDYXNlKCkpO1xuICAgICAgICAgICAga2V5d29yZHMucHVzaCh0YXhvbm9teU5hbWUpO1xuICAgICAgICAgICAgaWYgKGtleXdvcmRzLm1hcCgoa2V5d29yZDogc3RyaW5nKSA9PiBrZXl3b3JkLnRvTG93ZXJDYXNlKCkpLnNvbWUoKGtleXdvcmQ6IHN0cmluZykgPT4gdGl0bGUuaW5jbHVkZXMoa2V5d29yZCkgfHwgZGVzY3JpcHRpb24uaW5jbHVkZXMoa2V5d29yZCkpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zdWdnZXN0ZWRUYXhvbm9taWVzLnB1c2godGF4b25vbXlOYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIHNlbGVjdExlY3R1cmVVbml0SW5UYWJsZShsZWN0dXJlVW5pdDogTGVjdHVyZVVuaXQpIHtcbiAgICAgICAgaWYgKHRoaXMuaXNMZWN0dXJlVW5pdEFscmVhZHlTZWxlY3RlZEluVGFibGUobGVjdHVyZVVuaXQpKSB7XG4gICAgICAgICAgICB0aGlzLnNlbGVjdGVkTGVjdHVyZVVuaXRzSW5UYWJsZS5mb3JFYWNoKChzZWxlY3RlZExlY3R1cmVVbml0LCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChzZWxlY3RlZExlY3R1cmVVbml0LmlkID09PSBsZWN0dXJlVW5pdC5pZCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdGVkTGVjdHVyZVVuaXRzSW5UYWJsZS5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZExlY3R1cmVVbml0c0luVGFibGUucHVzaChsZWN0dXJlVW5pdCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBpc0xlY3R1cmVVbml0QWxyZWFkeVNlbGVjdGVkSW5UYWJsZShsZWN0dXJlVW5pdDogTGVjdHVyZVVuaXQpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VsZWN0ZWRMZWN0dXJlVW5pdHNJblRhYmxlLm1hcCgoc2VsZWN0ZWRMZWN0dXJlVW5pdCkgPT4gc2VsZWN0ZWRMZWN0dXJlVW5pdC5pZCkuaW5jbHVkZXMobGVjdHVyZVVuaXQuaWQpO1xuICAgIH1cblxuICAgIGdldExlY3R1cmVUaXRsZUZvckRyb3Bkb3duKGxlY3R1cmU6IExlY3R1cmUpIHtcbiAgICAgICAgY29uc3Qgbm9PZlNlbGVjdGVkVW5pdHNJbkxlY3R1cmUgPSBpbnRlcnNlY3Rpb24oXG4gICAgICAgICAgICB0aGlzLnNlbGVjdGVkTGVjdHVyZVVuaXRzSW5UYWJsZS5tYXAoKHVuaXQpID0+IHVuaXQuaWQpLFxuICAgICAgICAgICAgbGVjdHVyZS5sZWN0dXJlVW5pdHM/Lm1hcCgodW5pdCkgPT4gdW5pdC5pZCksXG4gICAgICAgICkubGVuZ3RoO1xuICAgICAgICByZXR1cm4gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQoJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5jcmVhdGVDb21wZXRlbmN5LmRyb3Bkb3duJywge1xuICAgICAgICAgICAgbGVjdHVyZVRpdGxlOiBsZWN0dXJlLnRpdGxlLFxuICAgICAgICAgICAgbm9PZkNvbm5lY3RlZFVuaXRzOiBub09mU2VsZWN0ZWRVbml0c0luTGVjdHVyZSxcbiAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgIDxkaXYgY2xhc3M9XCJjb2wtMTJcIj5cbiAgICAgICAgQGlmIChmb3JtKSB7XG4gICAgICAgICAgICA8Zm9ybSBbZm9ybUdyb3VwXT1cImZvcm1cIiAobmdTdWJtaXQpPVwic3VibWl0Rm9ybSgpXCI+XG4gICAgICAgICAgICAgICAgQGlmICghaXNJbkNvbm5lY3RNb2RlKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwidGl0bGVcIj57eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LnRpdGxlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX0qPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0aXRsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwidGl0bGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtwbGFjZWhvbGRlcl09XCInYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LmNyZWF0ZUNvbXBldGVuY3kudGl0bGVQbGFjZWhvbGRlcicgfCBhcnRlbWlzVHJhbnNsYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHRpdGxlQ29udHJvbD8uaW52YWxpZCAmJiAodGl0bGVDb250cm9sPy5kaXJ0eSB8fCB0aXRsZUNvbnRyb2w/LnRvdWNoZWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFsZXJ0IGFsZXJ0LWRhbmdlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHRpdGxlQ29udHJvbD8uZXJyb3JzPy5yZXF1aXJlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LmNyZWF0ZUNvbXBldGVuY3kudGl0bGVSZXF1aXJlZFZhbGlkYXRpb25FcnJvcicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHRpdGxlQ29udHJvbD8uZXJyb3JzPy5tYXhsZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5jcmVhdGVDb21wZXRlbmN5LnRpdGxlTWF4TGVuZ3RoVmFsaWRhdGlvbkVycm9yJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAodGl0bGVDb250cm9sPy5lcnJvcnM/LnRpdGxlVW5pcXVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kuY3JlYXRlQ29tcGV0ZW5jeS50aXRsZVVuaXF1ZVZhbGlkYXRpb25FcnJvcicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmICghaXNJbkNvbm5lY3RNb2RlKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwiZGVzY3JpcHRpb25cIj57eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LmRlc2NyaXB0aW9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZGVzY3JpcHRpb25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9XCI2XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJkZXNjcmlwdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW3BsYWNlaG9sZGVyXT1cIidhcnRlbWlzQXBwLmNvbXBldGVuY3kuY3JlYXRlQ29tcGV0ZW5jeS5kZXNjcmlwdGlvblBsYWNlaG9sZGVyJyB8IGFydGVtaXNUcmFuc2xhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvdGV4dGFyZWE+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGRlc2NyaXB0aW9uQ29udHJvbD8uaW52YWxpZCAmJiAoZGVzY3JpcHRpb25Db250cm9sPy5kaXJ0eSB8fCBkZXNjcmlwdGlvbkNvbnRyb2w/LnRvdWNoZWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFsZXJ0IGFsZXJ0LWRhbmdlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGRlc2NyaXB0aW9uQ29udHJvbD8uZXJyb3JzPy5tYXhsZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5jcmVhdGVDb21wZXRlbmN5LmRlc2NyaXB0aW9uTWF4TGVuZ3RoVmFsaWRhdGlvbkVycm9yJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICA8amhpLWRhdGUtdGltZS1waWNrZXJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwic29mdER1ZURhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWxOYW1lPVwie3sgJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5jcmVhdGVDb21wZXRlbmN5LnNvZnREdWVEYXRlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWxUb29sdGlwPVwie3sgJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5jcmVhdGVDb21wZXRlbmN5LnNvZnREdWVEYXRlSGludCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1Db250cm9sTmFtZT1cInNvZnREdWVEYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgPjwvamhpLWRhdGUtdGltZS1waWNrZXI+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgQGlmICghaXNJbkNvbm5lY3RNb2RlKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwidGF4b25vbXlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LnRheG9ub215JyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHN1Z2dlc3RlZFRheG9ub21pZXM/Lmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c21hbGw+ICh7eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LmNyZWF0ZUNvbXBldGVuY3kuc3VnZ2VzdGVkVGF4b25vbXknIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fToge3sgc3VnZ2VzdGVkVGF4b25vbWllcy5qb2luKCcsICcpIH19KSA8L3NtYWxsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IGNsYXNzPVwiZm9ybS1zZWxlY3QgbWItMlwiIGlkPVwidGF4b25vbXlcIiBmb3JtQ29udHJvbE5hbWU9XCJ0YXhvbm9teVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gW25nVmFsdWVdPVwidW5kZWZpbmVkXCIgc2VsZWN0ZWQ+PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAodGF4b25vbXkgb2YgY29tcGV0ZW5jeVRheG9ub215IHwga2V5dmFsdWU6IGtlZXBPcmRlcjsgdHJhY2sgdGF4b25vbXk7IGxldCBpID0gJGluZGV4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gW25nVmFsdWVdPVwidGF4b25vbXkua2V5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnJlRoaW5TcGFjZTsnLnJlcGVhdChpKSB9fSZib3h1cjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kudGF4b25vbWllcy4nICsgdGF4b25vbXkudmFsdWUudG9Mb3dlckNhc2UoKSB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICh7eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LmtleXdvcmRzLicgKyB0YXhvbm9teS52YWx1ZS50b0xvd2VyQ2FzZSgpIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKCFpc0luQ29ubmVjdE1vZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJtYXN0ZXJ5VGhyZXNob2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5tYXN0ZXJ5VGhyZXNob2xkJyB8IGFydGVtaXNUcmFuc2xhdGUgfX06IHt7IG1hc3RlcnlUaHJlc2hvbGRDb250cm9sIS52YWx1ZSA/PyA1MCB9fSVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGF2ZXJhZ2VTdHVkZW50U2NvcmUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNtYWxsPiAoe3sgJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5jcmVhdGVDb21wZXRlbmN5LmF2ZXJhZ2VTdHVkZW50U2NvcmUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fToge3sgYXZlcmFnZVN0dWRlbnRTY29yZSB9fSUpIDwvc21hbGw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicmFuZ2VcIiBtaW49XCIwXCIgbWF4PVwiMTAwXCIgY2xhc3M9XCJmb3JtLXJhbmdlXCIgaWQ9XCJtYXN0ZXJ5VGhyZXNob2xkXCIgZm9ybUNvbnRyb2xOYW1lPVwibWFzdGVyeVRocmVzaG9sZFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2xhc3M9XCJmb3JtLWNoZWNrLWlucHV0XCIgaWQ9XCJvcHRpb25hbFwiIGZvcm1Db250cm9sTmFtZT1cIm9wdGlvbmFsXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1jb250cm9sLWxhYmVsXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb21wZXRlbmN5Lm9wdGlvbmFsXCIgZm9yPVwib3B0aW9uYWxcIj48L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVF1ZXN0aW9uQ2lyY2xlXCIgY2xhc3M9XCJ0ZXh0LXNlY29uZGFyeVwiIG5nYlRvb2x0aXA9XCJ7eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5Lm9wdGlvbmFsRGVzY3JpcHRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWw+e3sgJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5jcmVhdGVDb21wZXRlbmN5LmNvbm5lY3RXaXRoTGVjdHVyZVVuaXRzJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKGxlY3R1cmVzT2ZDb3Vyc2VXaXRoTGVjdHVyZVVuaXRzICYmIGxlY3R1cmVzT2ZDb3Vyc2VXaXRoTGVjdHVyZVVuaXRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgW2hpZGRlbl09XCJpc0luU2luZ2xlTGVjdHVyZU1vZGVcIiBuZ2JEcm9wZG93biBjbGFzcz1cIm1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1vdXRsaW5lLXByaW1hcnlcIiBuZ2JEcm9wZG93blRvZ2dsZSB0eXBlPVwiYnV0dG9uXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZExlY3R1cmVJbkRyb3Bkb3duXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBnZXRMZWN0dXJlVGl0bGVGb3JEcm9wZG93bihzZWxlY3RlZExlY3R1cmVJbkRyb3Bkb3duKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogKCdhcnRlbWlzQXBwLmNvbXBldGVuY3kuY3JlYXRlQ29tcGV0ZW5jeS5zZWxlY3RMZWN0dXJlJyB8IGFydGVtaXNUcmFuc2xhdGUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBuZ2JEcm9wZG93bk1lbnU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKGxlY3R1cmUgb2YgbGVjdHVyZXNPZkNvdXJzZVdpdGhMZWN0dXJlVW5pdHM7IHRyYWNrIGxlY3R1cmUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gbmdiRHJvcGRvd25JdGVtIHR5cGU9XCJidXR0b25cIiAoY2xpY2spPVwic2VsZWN0TGVjdHVyZUluRHJvcGRvd24obGVjdHVyZSlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBnZXRMZWN0dXJlVGl0bGVGb3JEcm9wZG93bihsZWN0dXJlKSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhbGVydCBhbGVydC1pbmZvXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5jcmVhdGVDb21wZXRlbmN5Lm5vTGVjdHVyZXMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlICNub0xlY3R1cmVzPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFsZXJ0IGFsZXJ0LWluZm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LmNyZWF0ZUNvbXBldGVuY3kubm9MZWN0dXJlcycgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgQGlmIChzZWxlY3RlZExlY3R1cmVJbkRyb3Bkb3duKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGFibGUtcmVzcG9uc2l2ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlIHRhYmxlLWJvcmRlcmVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzcz1cInRoZWFkLWRhcmtcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+aWQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5jcmVhdGVDb21wZXRlbmN5LmxlY3R1cmVVbml0VGFibGUudHlwZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kuY3JlYXRlQ29tcGV0ZW5jeS5sZWN0dXJlVW5pdFRhYmxlLm5hbWUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LmNyZWF0ZUNvbXBldGVuY3kubGVjdHVyZVVuaXRUYWJsZS5yZWxlYXNlRGF0ZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKGxlY3R1cmVVbml0IG9mIHNlbGVjdGVkTGVjdHVyZUluRHJvcGRvd24ubGVjdHVyZVVuaXRzOyB0cmFjayBsZWN0dXJlVW5pdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0clxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImxlY3R1cmVVbml0Um93XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cInNlbGVjdExlY3R1cmVVbml0SW5UYWJsZShsZWN0dXJlVW5pdClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGFibGUtcHJpbWFyeV09XCJpc0xlY3R1cmVVbml0QWxyZWFkeVNlbGVjdGVkSW5UYWJsZShsZWN0dXJlVW5pdClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt7IGxlY3R1cmVVbml0LmlkID8gbGVjdHVyZVVuaXQuaWQgOiAnJyB9fTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyBsZWN0dXJlVW5pdC50eXBlID8gbGVjdHVyZVVuaXQudHlwZSA6ICcnIH19PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt7IGxlY3R1cmVVbml0U2VydmljZS5nZXRMZWN0dXJlVW5pdE5hbWUobGVjdHVyZVVuaXQpID8gbGVjdHVyZVVuaXRTZXJ2aWNlLmdldExlY3R1cmVVbml0TmFtZShsZWN0dXJlVW5pdCkgOiAnJyB9fTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVjdHVyZVVuaXRTZXJ2aWNlLmdldExlY3R1cmVVbml0UmVsZWFzZURhdGUobGVjdHVyZVVuaXQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gbGVjdHVyZVVuaXRTZXJ2aWNlLmdldExlY3R1cmVVbml0UmVsZWFzZURhdGUobGVjdHVyZVVuaXQpIS5mb3JtYXQoJ01NTSBERCBZWVlZLCBISDptbTpzcycpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwic3VibWl0QnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgbWUtMlwiIHR5cGU9XCJzdWJtaXRcIiBbZGlzYWJsZWRdPVwiIWlzU3VibWl0UG9zc2libGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7ICdlbnRpdHkuYWN0aW9uLnN1Ym1pdCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgQGlmIChoYXNDYW5jZWxCdXR0b24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIChjbGljayk9XCJjYW5jZWxGb3JtKClcIiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhVGltZXNcIj48L2ZhLWljb24+Jm5ic3A7PHNwYW4gamhpVHJhbnNsYXRlPVwiZW50aXR5LmFjdGlvbi5jYW5jZWxcIj5DYW5jZWw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICB9XG4gICAgPC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBvbkVycm9yIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2dsb2JhbC51dGlscyc7XG5pbXBvcnQgeyBDb21wZXRlbmN5IH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvbXBldGVuY3kubW9kZWwnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUsIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBBbGVydFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuaW1wb3J0IHsgQ29tcGV0ZW5jeVNlcnZpY2UgfSBmcm9tICdhcHAvY291cnNlL2NvbXBldGVuY2llcy9jb21wZXRlbmN5LnNlcnZpY2UnO1xuaW1wb3J0IHsgQ29tcGV0ZW5jeUZvcm1EYXRhIH0gZnJvbSAnYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jeS1mb3JtL2NvbXBldGVuY3ktZm9ybS5jb21wb25lbnQnO1xuaW1wb3J0IHsgZmluYWxpemUsIHN3aXRjaE1hcCwgdGFrZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IEh0dHBFcnJvclJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgTGVjdHVyZVNlcnZpY2UgfSBmcm9tICdhcHAvbGVjdHVyZS9sZWN0dXJlLnNlcnZpY2UnO1xuaW1wb3J0IHsgTGVjdHVyZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9sZWN0dXJlLm1vZGVsJztcbmltcG9ydCB7IERvY3VtZW50YXRpb25UeXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL2RvY3VtZW50YXRpb24tYnV0dG9uL2RvY3VtZW50YXRpb24tYnV0dG9uLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWNyZWF0ZS1jb21wZXRlbmN5JyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vY3JlYXRlLWNvbXBldGVuY3kuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlczogW10sXG59KVxuZXhwb3J0IGNsYXNzIENyZWF0ZUNvbXBldGVuY3lDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIHJlYWRvbmx5IGRvY3VtZW50YXRpb25UeXBlOiBEb2N1bWVudGF0aW9uVHlwZSA9ICdDb21wZXRlbmNpZXMnO1xuICAgIGNvbXBldGVuY3lUb0NyZWF0ZTogQ29tcGV0ZW5jeSA9IG5ldyBDb21wZXRlbmN5KCk7XG4gICAgaXNMb2FkaW5nOiBib29sZWFuO1xuICAgIGNvdXJzZUlkOiBudW1iZXI7XG4gICAgbGVjdHVyZXNXaXRoTGVjdHVyZVVuaXRzOiBMZWN0dXJlW10gPSBbXTtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGFjdGl2YXRlZFJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSxcbiAgICAgICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcbiAgICAgICAgcHJpdmF0ZSBjb21wZXRlbmN5U2VydmljZTogQ29tcGV0ZW5jeVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgbGVjdHVyZVNlcnZpY2U6IExlY3R1cmVTZXJ2aWNlLFxuICAgICkge31cblxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICB0aGlzLmNvbXBldGVuY3lUb0NyZWF0ZSA9IG5ldyBDb21wZXRlbmN5KCk7XG4gICAgICAgIHRoaXMuaXNMb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5hY3RpdmF0ZWRSb3V0ZVxuICAgICAgICAgICAgLnBhcmVudCEucGFyZW50IS5wYXJhbU1hcC5waXBlKFxuICAgICAgICAgICAgICAgIHRha2UoMSksXG4gICAgICAgICAgICAgICAgc3dpdGNoTWFwKChwYXJhbXMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb3Vyc2VJZCA9IE51bWJlcihwYXJhbXMuZ2V0KCdjb3Vyc2VJZCcpKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMubGVjdHVyZVNlcnZpY2UuZmluZEFsbEJ5Q291cnNlSWQodGhpcy5jb3Vyc2VJZCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgZmluYWxpemUoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKGxlY3R1cmVSZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGxlY3R1cmVSZXN1bHQuYm9keSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sZWN0dXJlc1dpdGhMZWN0dXJlVW5pdHMgPSBsZWN0dXJlUmVzdWx0LmJvZHk7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGxlY3R1cmUgb2YgdGhpcy5sZWN0dXJlc1dpdGhMZWN0dXJlVW5pdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBzZXJ2ZXIgd2lsbCBzZW5kIHVuZGVmaW5lZCBpbnN0ZWFkIG9mIGVtcHR5IGFycmF5LCB0aGVyZWZvcmUgd2Ugc2V0IGl0IGhlcmUgYXMgaXQgaXMgZWFzaWVyIHRvIGhhbmRsZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghbGVjdHVyZS5sZWN0dXJlVW5pdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVjdHVyZS5sZWN0dXJlVW5pdHMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGVycm9yOiAocmVzOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4gb25FcnJvcih0aGlzLmFsZXJ0U2VydmljZSwgcmVzKSxcbiAgICAgICAgICAgIH0pO1xuICAgIH1cblxuICAgIGNyZWF0ZUNvbXBldGVuY3koZm9ybURhdGE6IENvbXBldGVuY3lGb3JtRGF0YSkge1xuICAgICAgICBpZiAoIWZvcm1EYXRhPy50aXRsZSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgeyB0aXRsZSwgZGVzY3JpcHRpb24sIHNvZnREdWVEYXRlLCB0YXhvbm9teSwgbWFzdGVyeVRocmVzaG9sZCwgb3B0aW9uYWwsIGNvbm5lY3RlZExlY3R1cmVVbml0cyB9ID0gZm9ybURhdGE7XG5cbiAgICAgICAgdGhpcy5jb21wZXRlbmN5VG9DcmVhdGUudGl0bGUgPSB0aXRsZTtcbiAgICAgICAgdGhpcy5jb21wZXRlbmN5VG9DcmVhdGUuZGVzY3JpcHRpb24gPSBkZXNjcmlwdGlvbjtcbiAgICAgICAgdGhpcy5jb21wZXRlbmN5VG9DcmVhdGUuc29mdER1ZURhdGUgPSBzb2Z0RHVlRGF0ZTtcbiAgICAgICAgdGhpcy5jb21wZXRlbmN5VG9DcmVhdGUudGF4b25vbXkgPSB0YXhvbm9teTtcbiAgICAgICAgdGhpcy5jb21wZXRlbmN5VG9DcmVhdGUubWFzdGVyeVRocmVzaG9sZCA9IG1hc3RlcnlUaHJlc2hvbGQ7XG4gICAgICAgIHRoaXMuY29tcGV0ZW5jeVRvQ3JlYXRlLm9wdGlvbmFsID0gb3B0aW9uYWw7XG4gICAgICAgIHRoaXMuY29tcGV0ZW5jeVRvQ3JlYXRlLmxlY3R1cmVVbml0cyA9IGNvbm5lY3RlZExlY3R1cmVVbml0cztcblxuICAgICAgICB0aGlzLmlzTG9hZGluZyA9IHRydWU7XG5cbiAgICAgICAgdGhpcy5jb21wZXRlbmN5U2VydmljZVxuICAgICAgICAgICAgLmNyZWF0ZSh0aGlzLmNvbXBldGVuY3lUb0NyZWF0ZSEsIHRoaXMuY291cnNlSWQpXG4gICAgICAgICAgICAucGlwZShcbiAgICAgICAgICAgICAgICBmaW5hbGl6ZSgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXNMb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGN1cnJlbnRseSBhdCAvY291cnNlLW1hbmFnZW1lbnQve2NvdXJzZUlkfS9jb21wZXRlbmN5LW1hbmFnZW1lbnQvY3JlYXRlLCBnb2luZyBiYWNrIHRvIC9jb3Vyc2UtbWFuYWdlbWVudC97Y291cnNlSWR9L2NvbXBldGVuY3ktbWFuYWdlbWVudC9cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycuLi8nXSwgeyByZWxhdGl2ZVRvOiB0aGlzLmFjdGl2YXRlZFJvdXRlIH0pO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgZXJyb3I6IChyZXM6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiBvbkVycm9yKHRoaXMuYWxlcnRTZXJ2aWNlLCByZXMpLFxuICAgICAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiQGlmIChpc0xvYWRpbmcpIHtcbiAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGp1c3RpZnktY29udGVudC1jZW50ZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInNwaW5uZXItYm9yZGVyXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJzci1vbmx5XCI+e3sgJ2xvYWRpbmcnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG59XG5AaWYgKCFpc0xvYWRpbmcpIHtcbiAgICA8ZGl2IGNsYXNzPVwiY29udGFpbmVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICA8aDM+e3sgJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5jcmVhdGVDb21wZXRlbmN5LnRpdGxlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2gzPlxuICAgICAgICAgICAgPGpoaS1kb2N1bWVudGF0aW9uLWJ1dHRvbiBbdHlwZV09XCJkb2N1bWVudGF0aW9uVHlwZVwiPjwvamhpLWRvY3VtZW50YXRpb24tYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGpoaS1jb21wZXRlbmN5LWZvcm1cbiAgICAgICAgICAgIFtpc0VkaXRNb2RlXT1cImZhbHNlXCJcbiAgICAgICAgICAgIChmb3JtU3VibWl0dGVkKT1cImNyZWF0ZUNvbXBldGVuY3koJGV2ZW50KVwiXG4gICAgICAgICAgICBbY291cnNlSWRdPVwiY291cnNlSWRcIlxuICAgICAgICAgICAgW2xlY3R1cmVzT2ZDb3Vyc2VXaXRoTGVjdHVyZVVuaXRzXT1cImxlY3R1cmVzV2l0aExlY3R1cmVVbml0c1wiXG4gICAgICAgID48L2poaS1jb21wZXRlbmN5LWZvcm0+XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgb25FcnJvciB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC9nbG9iYWwudXRpbHMnO1xuaW1wb3J0IHsgQ29tcGV0ZW5jeSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb21wZXRlbmN5Lm1vZGVsJztcbmltcG9ydCB7IENvbXBldGVuY3lGb3JtRGF0YSB9IGZyb20gJ2FwcC9jb3Vyc2UvY29tcGV0ZW5jaWVzL2NvbXBldGVuY3ktZm9ybS9jb21wZXRlbmN5LWZvcm0uY29tcG9uZW50JztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlLCBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgQWxlcnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvdXRpbC9hbGVydC5zZXJ2aWNlJztcbmltcG9ydCB7IGZpbmFsaXplLCBzd2l0Y2hNYXAsIHRha2UgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBDb21wZXRlbmN5U2VydmljZSB9IGZyb20gJ2FwcC9jb3Vyc2UvY29tcGV0ZW5jaWVzL2NvbXBldGVuY3kuc2VydmljZSc7XG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IExlY3R1cmVTZXJ2aWNlIH0gZnJvbSAnYXBwL2xlY3R1cmUvbGVjdHVyZS5zZXJ2aWNlJztcbmltcG9ydCB7IGNvbWJpbmVMYXRlc3QsIGZvcmtKb2luIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBMZWN0dXJlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2xlY3R1cmUubW9kZWwnO1xuaW1wb3J0IHsgTGVjdHVyZVVuaXRUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2xlY3R1cmUtdW5pdC9sZWN0dXJlVW5pdC5tb2RlbCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWVkaXQtY29tcGV0ZW5jeScsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2VkaXQtY29tcGV0ZW5jeS5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVzOiBbXSxcbn0pXG5leHBvcnQgY2xhc3MgRWRpdENvbXBldGVuY3lDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIGlzTG9hZGluZyA9IGZhbHNlO1xuICAgIGNvbXBldGVuY3k6IENvbXBldGVuY3k7XG4gICAgbGVjdHVyZXNXaXRoTGVjdHVyZVVuaXRzOiBMZWN0dXJlW10gPSBbXTtcbiAgICBmb3JtRGF0YTogQ29tcGV0ZW5jeUZvcm1EYXRhO1xuICAgIGNvdXJzZUlkOiBudW1iZXI7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBhY3RpdmF0ZWRSb3V0ZTogQWN0aXZhdGVkUm91dGUsXG4gICAgICAgIHByaXZhdGUgbGVjdHVyZVNlcnZpY2U6IExlY3R1cmVTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgICAgICBwcml2YXRlIGNvbXBldGVuY3lTZXJ2aWNlOiBDb21wZXRlbmN5U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBhbGVydFNlcnZpY2U6IEFsZXJ0U2VydmljZSxcbiAgICApIHt9XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5pc0xvYWRpbmcgPSB0cnVlO1xuICAgICAgICBjb21iaW5lTGF0ZXN0KFt0aGlzLmFjdGl2YXRlZFJvdXRlLnBhcmFtTWFwLCB0aGlzLmFjdGl2YXRlZFJvdXRlLnBhcmVudCEucGFyZW50IS5wYXJhbU1hcF0pXG4gICAgICAgICAgICAucGlwZShcbiAgICAgICAgICAgICAgICB0YWtlKDEpLFxuICAgICAgICAgICAgICAgIHN3aXRjaE1hcCgoW3BhcmFtcywgcGFyZW50UGFyYW1zXSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjb21wZXRlbmN5SWQgPSBOdW1iZXIocGFyYW1zLmdldCgnY29tcGV0ZW5jeUlkJykpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZUlkID0gTnVtYmVyKHBhcmVudFBhcmFtcy5nZXQoJ2NvdXJzZUlkJykpO1xuXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvbXBldGVuY3lPYnNlcnZhYmxlID0gdGhpcy5jb21wZXRlbmN5U2VydmljZS5maW5kQnlJZChjb21wZXRlbmN5SWQsIHRoaXMuY291cnNlSWQpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjb21wZXRlbmN5Q291cnNlUHJvZ3Jlc3NPYnNlcnZhYmxlID0gdGhpcy5jb21wZXRlbmN5U2VydmljZS5nZXRDb3Vyc2VQcm9ncmVzcyhjb21wZXRlbmN5SWQsIHRoaXMuY291cnNlSWQpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBsZWN0dXJlc09ic2VydmFibGUgPSB0aGlzLmxlY3R1cmVTZXJ2aWNlLmZpbmRBbGxCeUNvdXJzZUlkKHRoaXMuY291cnNlSWQsIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZm9ya0pvaW4oW2NvbXBldGVuY3lPYnNlcnZhYmxlLCBjb21wZXRlbmN5Q291cnNlUHJvZ3Jlc3NPYnNlcnZhYmxlLCBsZWN0dXJlc09ic2VydmFibGVdKTtcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICBmaW5hbGl6ZSgoKSA9PiAodGhpcy5pc0xvYWRpbmcgPSBmYWxzZSkpLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKFtjb21wZXRlbmN5UmVzdWx0LCBjb3Vyc2VQcm9ncmVzc1Jlc3VsdCwgbGVjdHVyZXNSZXN1bHRdKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb21wZXRlbmN5UmVzdWx0LmJvZHkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcGV0ZW5jeSA9IGNvbXBldGVuY3lSZXN1bHQuYm9keTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb3Vyc2VQcm9ncmVzc1Jlc3VsdC5ib2R5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb21wZXRlbmN5LmNvdXJzZVByb2dyZXNzID0gY291cnNlUHJvZ3Jlc3NSZXN1bHQuYm9keTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNlcnZlciB3aWxsIHNlbmQgdW5kZWZpbmVkIGluc3RlYWQgb2YgZW1wdHkgYXJyYXksIHRoZXJlZm9yZSB3ZSBzZXQgaXQgaGVyZSBhcyBpdCBpcyBlYXNpZXIgdG8gaGFuZGxlXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXRoaXMuY29tcGV0ZW5jeS5sZWN0dXJlVW5pdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbXBldGVuY3kubGVjdHVyZVVuaXRzID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKGxlY3R1cmVzUmVzdWx0LmJvZHkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubGVjdHVyZXNXaXRoTGVjdHVyZVVuaXRzID0gbGVjdHVyZXNSZXN1bHQuYm9keTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3QgbGVjdHVyZSBvZiB0aGlzLmxlY3R1cmVzV2l0aExlY3R1cmVVbml0cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNlcnZlciB3aWxsIHNlbmQgdW5kZWZpbmVkIGluc3RlYWQgb2YgZW1wdHkgYXJyYXksIHRoZXJlZm9yZSB3ZSBzZXQgaXQgaGVyZSBhcyBpdCBpcyBlYXNpZXIgdG8gaGFuZGxlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFsZWN0dXJlLmxlY3R1cmVVbml0cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWN0dXJlLmxlY3R1cmVVbml0cyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZpbHRlciBvdXQgZXhlcmNpc2UgdW5pdHMsIHRoZXkgc2hvdWxkIGJlIGFkZGVkIHZpYSB0aGUgZXhlcmNpc2UgbWFuYWdlbWVudCBmb3Igbm93XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRPRE86IFVzZXIgZXhwZXJpZW5jZSBpbXByb3ZlbWVudHMgZm9yIGxpbmtpbmcgbGVhcm5pbmcgb2JqZWN0cyB3aGVuIGVkaXRpbmcgYSBjb21wZXRlbmN5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlY3R1cmUubGVjdHVyZVVuaXRzID0gbGVjdHVyZS5sZWN0dXJlVW5pdHMuZmlsdGVyKChsZWN0dXJlVW5pdCkgPT4gbGVjdHVyZVVuaXQudHlwZSAhPT0gTGVjdHVyZVVuaXRUeXBlLkVYRVJDSVNFKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICB0aGlzLmZvcm1EYXRhID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRoaXMuY29tcGV0ZW5jeS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiB0aGlzLmNvbXBldGVuY3kudGl0bGUsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogdGhpcy5jb21wZXRlbmN5LmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgc29mdER1ZURhdGU6IHRoaXMuY29tcGV0ZW5jeS5zb2Z0RHVlRGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbm5lY3RlZExlY3R1cmVVbml0czogdGhpcy5jb21wZXRlbmN5LmxlY3R1cmVVbml0cyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRheG9ub215OiB0aGlzLmNvbXBldGVuY3kudGF4b25vbXksXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXN0ZXJ5VGhyZXNob2xkOiB0aGlzLmNvbXBldGVuY3kubWFzdGVyeVRocmVzaG9sZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbmFsOiB0aGlzLmNvbXBldGVuY3kub3B0aW9uYWwsXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKHJlczogSHR0cEVycm9yUmVzcG9uc2UpID0+IG9uRXJyb3IodGhpcy5hbGVydFNlcnZpY2UsIHJlcyksXG4gICAgICAgICAgICB9KTtcbiAgICB9XG5cbiAgICB1cGRhdGVDb21wZXRlbmN5KGZvcm1EYXRhOiBDb21wZXRlbmN5Rm9ybURhdGEpIHtcbiAgICAgICAgY29uc3QgeyB0aXRsZSwgZGVzY3JpcHRpb24sIHNvZnREdWVEYXRlLCB0YXhvbm9teSwgbWFzdGVyeVRocmVzaG9sZCwgb3B0aW9uYWwsIGNvbm5lY3RlZExlY3R1cmVVbml0cyB9ID0gZm9ybURhdGE7XG5cbiAgICAgICAgdGhpcy5jb21wZXRlbmN5LnRpdGxlID0gdGl0bGU7XG4gICAgICAgIHRoaXMuY29tcGV0ZW5jeS5kZXNjcmlwdGlvbiA9IGRlc2NyaXB0aW9uO1xuICAgICAgICB0aGlzLmNvbXBldGVuY3kuc29mdER1ZURhdGUgPSBzb2Z0RHVlRGF0ZTtcbiAgICAgICAgdGhpcy5jb21wZXRlbmN5LnRheG9ub215ID0gdGF4b25vbXk7XG4gICAgICAgIHRoaXMuY29tcGV0ZW5jeS5tYXN0ZXJ5VGhyZXNob2xkID0gbWFzdGVyeVRocmVzaG9sZDtcbiAgICAgICAgdGhpcy5jb21wZXRlbmN5Lm9wdGlvbmFsID0gb3B0aW9uYWw7XG4gICAgICAgIHRoaXMuY29tcGV0ZW5jeS5sZWN0dXJlVW5pdHMgPSBjb25uZWN0ZWRMZWN0dXJlVW5pdHM7XG5cbiAgICAgICAgdGhpcy5pc0xvYWRpbmcgPSB0cnVlO1xuXG4gICAgICAgIHRoaXMuY29tcGV0ZW5jeVNlcnZpY2VcbiAgICAgICAgICAgIC51cGRhdGUodGhpcy5jb21wZXRlbmN5LCB0aGlzLmNvdXJzZUlkKVxuICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgZmluYWxpemUoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAvLyBjdXJyZW50bHkgYXQgL2NvdXJzZS1tYW5hZ2VtZW50L3tjb3Vyc2VJZH0vY29tcGV0ZW5jeS1tYW5hZ2VtZW50L3tjb21wZXRlbmN5SWR9L2VkaXQsIGdvaW5nIGJhY2sgdG8gL2NvdXJzZS1tYW5hZ2VtZW50L3tjb3Vyc2VJZH0vY29tcGV0ZW5jeS1tYW5hZ2VtZW50L1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy4uLy4uLyddLCB7IHJlbGF0aXZlVG86IHRoaXMuYWN0aXZhdGVkUm91dGUgfSk7XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBlcnJvcjogKHJlczogSHR0cEVycm9yUmVzcG9uc2UpID0+IG9uRXJyb3IodGhpcy5hbGVydFNlcnZpY2UsIHJlcyksXG4gICAgICAgICAgICB9KTtcbiAgICB9XG59XG4iLCJAaWYgKGlzTG9hZGluZykge1xuICAgIDxkaXYgY2xhc3M9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWNlbnRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3Bpbm5lci1ib3JkZXJcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInNyLW9ubHlcIj57eyAnbG9hZGluZycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbn1cbkBpZiAoIWlzTG9hZGluZykge1xuICAgIDxkaXYgY2xhc3M9XCJjb250YWluZXJcIj5cbiAgICAgICAgPGgzPnt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kuZWRpdENvbXBldGVuY3kudGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvaDM+XG4gICAgICAgIDxqaGktY29tcGV0ZW5jeS1mb3JtXG4gICAgICAgICAgICBbaXNFZGl0TW9kZV09XCJ0cnVlXCJcbiAgICAgICAgICAgIFtmb3JtRGF0YV09XCJmb3JtRGF0YVwiXG4gICAgICAgICAgICAoZm9ybVN1Ym1pdHRlZCk9XCJ1cGRhdGVDb21wZXRlbmN5KCRldmVudClcIlxuICAgICAgICAgICAgW2NvdXJzZUlkXT1cImNvdXJzZUlkXCJcbiAgICAgICAgICAgIFtsZWN0dXJlc09mQ291cnNlV2l0aExlY3R1cmVVbml0c109XCJsZWN0dXJlc1dpdGhMZWN0dXJlVW5pdHNcIlxuICAgICAgICAgICAgW2F2ZXJhZ2VTdHVkZW50U2NvcmVdPVwiY29tcGV0ZW5jeT8uY291cnNlUHJvZ3Jlc3M/LmF2ZXJhZ2VTdHVkZW50U2NvcmUgPz8gMFwiXG4gICAgICAgID48L2poaS1jb21wZXRlbmN5LWZvcm0+XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBIdHRwQ2xpZW50LCBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb21wZXRlbmN5IH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvbXBldGVuY3kubW9kZWwnO1xuaW1wb3J0IHsgUGFnaW5nU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL21hbmFnZS9wYWdpbmcuc2VydmljZSc7XG5pbXBvcnQgeyBQYWdlYWJsZVNlYXJjaCwgU2VhcmNoUmVzdWx0IH0gZnJvbSAnYXBwL3NoYXJlZC90YWJsZS9wYWdlYWJsZS10YWJsZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBtYXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5cbnR5cGUgRW50aXR5UmVzcG9uc2VUeXBlID0gU2VhcmNoUmVzdWx0PENvbXBldGVuY3k+O1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIENvbXBldGVuY3lQYWdpbmdTZXJ2aWNlIGV4dGVuZHMgUGFnaW5nU2VydmljZSB7XG4gICAgcHVibGljIHJlc291cmNlVXJsID0gJ2FwaS9jb21wZXRlbmNpZXMnO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgfVxuXG4gICAgc2VhcmNoRm9yQ29tcGV0ZW5jaWVzKHBhZ2VhYmxlOiBQYWdlYWJsZVNlYXJjaCk6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIGNvbnN0IHBhcmFtcyA9IHRoaXMuY3JlYXRlSHR0cFBhcmFtcyhwYWdlYWJsZSk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KGAke3RoaXMucmVzb3VyY2VVcmx9YCwgeyBwYXJhbXMsIG9ic2VydmU6ICdyZXNwb25zZScgfSkucGlwZShtYXAoKHJlc3A6IEh0dHBSZXNwb25zZTxFbnRpdHlSZXNwb25zZVR5cGU+KSA9PiByZXNwICYmIHJlc3AuYm9keSEpKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFN1YmplY3QgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IE5nYkFjdGl2ZU1vZGFsIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xuaW1wb3J0IHsgUGFnZWFibGVTZWFyY2gsIFNlYXJjaFJlc3VsdCwgU29ydGluZ09yZGVyIH0gZnJvbSAnYXBwL3NoYXJlZC90YWJsZS9wYWdlYWJsZS10YWJsZSc7XG5pbXBvcnQgeyBTb3J0U2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2VydmljZS9zb3J0LnNlcnZpY2UnO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IGZhQ2hlY2ssIGZhU29ydCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBCYXNlRW50aXR5IH0gZnJvbSAnYXBwL3NoYXJlZC9tb2RlbC9iYXNlLWVudGl0eSc7XG5pbXBvcnQgeyBDb21wZXRlbmN5UGFnaW5nU2VydmljZSB9IGZyb20gJ2FwcC9jb3Vyc2UvY29tcGV0ZW5jaWVzL2NvbXBldGVuY3ktcGFnaW5nLnNlcnZpY2UnO1xuXG5leHBvcnQgZW51bSBUYWJsZUNvbHVtbiB7XG4gICAgSUQgPSAnSUQnLFxuICAgIFRJVExFID0gJ1RJVExFJyxcbiAgICBDT1VSU0VfVElUTEUgPSAnQ09VUlNFX1RJVExFJyxcbiAgICBTRU1FU1RFUiA9ICdTRU1FU1RFUicsXG59XG5cbi8vIFRPRE86IEdlbmVyYWxpemUgdGhpcyBjb21wb25lbnQgZnVydGhlciB0byBtYWtlIGl0IGNvbXBhdGlibGUgd2l0aCBhbGwgcG90ZW50aWFsIGltcGxlbWVudGF0aW9ucyAoRXhlcmNpc2VJbXBvcnRDb21wb25lbnQsIExlY3R1cmVJbXBvcnRDb21wb25lbnQsIGV0Yy4pXG4vKipcbiAqIEFuIGFic3RyYWN0IGNvbXBvbmVudCBpbnRlbmRlZCBmb3IgY2FzZXMgd2hlcmUgYSByZXNvdXJjZSBuZWVkcyB0byBiZSBpbXBvcnRlZCBmcm9tIG9uZSBjb3Vyc2UgaW50byBhbm90aGVyLlxuICpcbiAqIEB0ZW1wbGF0ZSBUXG4gKi9cbkBDb21wb25lbnQoeyB0ZW1wbGF0ZTogJycgfSlcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBJbXBvcnRDb21wb25lbnQ8VCBleHRlbmRzIEJhc2VFbnRpdHk+IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICByZWFkb25seSBjb2x1bW4gPSBUYWJsZUNvbHVtbjtcbiAgICBsb2FkaW5nID0gZmFsc2U7XG4gICAgY29udGVudDogU2VhcmNoUmVzdWx0PFQ+O1xuICAgIHRvdGFsID0gMDtcbiAgICBzdGF0ZTogUGFnZWFibGVTZWFyY2ggPSB7XG4gICAgICAgIHBhZ2U6IDEsXG4gICAgICAgIHBhZ2VTaXplOiAxMCxcbiAgICAgICAgc2VhcmNoVGVybTogJycsXG4gICAgICAgIHNvcnRpbmdPcmRlcjogU29ydGluZ09yZGVyLkRFU0NFTkRJTkcsXG4gICAgICAgIHNvcnRlZENvbHVtbjogVGFibGVDb2x1bW4uSUQsXG4gICAgfTtcblxuICAgIC8vIEljb25zXG4gICAgZmFTb3J0ID0gZmFTb3J0O1xuICAgIGZhQ2hlY2sgPSBmYUNoZWNrO1xuICAgIHByaXZhdGUgc2VhcmNoID0gbmV3IFN1YmplY3Q8dm9pZD4oKTtcbiAgICBwcml2YXRlIHNvcnQgPSBuZXcgU3ViamVjdDx2b2lkPigpO1xuXG4gICAgQElucHV0KCkgcHVibGljIGRpc2FibGVkSWRzOiBudW1iZXJbXTtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgICAgICBwdWJsaWMgcGFnaW5nU2VydmljZTogQ29tcGV0ZW5jeVBhZ2luZ1NlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgc29ydFNlcnZpY2U6IFNvcnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFjdGl2ZU1vZGFsOiBOZ2JBY3RpdmVNb2RhbCxcbiAgICApIHt9XG5cbiAgICBnZXQgcGFnZSgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5zdGF0ZS5wYWdlO1xuICAgIH1cblxuICAgIHNldCBwYWdlKHBhZ2U6IG51bWJlcikge1xuICAgICAgICB0aGlzLnNldFNlYXJjaFBhcmFtKHsgcGFnZSB9KTtcbiAgICB9XG5cbiAgICBnZXQgbGlzdFNvcnRpbmcoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLnN0YXRlLnNvcnRpbmdPcmRlciA9PT0gU29ydGluZ09yZGVyLkFTQ0VORElORztcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXQgdGhlIGxpc3Qgc29ydGluZyBkaXJlY3Rpb25cbiAgICAgKlxuICAgICAqIEBwYXJhbSBhc2NlbmRpbmcge2Jvb2xlYW59IEFzY2VuZGluZyBvcmRlciBzZXRcbiAgICAgKi9cbiAgICBzZXQgbGlzdFNvcnRpbmcoYXNjZW5kaW5nOiBib29sZWFuKSB7XG4gICAgICAgIGNvbnN0IHNvcnRpbmdPcmRlciA9IGFzY2VuZGluZyA/IFNvcnRpbmdPcmRlci5BU0NFTkRJTkcgOiBTb3J0aW5nT3JkZXIuREVTQ0VORElORztcbiAgICAgICAgdGhpcy5zZXRTZWFyY2hQYXJhbSh7IHNvcnRpbmdPcmRlciB9KTtcbiAgICB9XG5cbiAgICBnZXQgc29ydGVkQ29sdW1uKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLnN0YXRlLnNvcnRlZENvbHVtbjtcbiAgICB9XG5cbiAgICBzZXQgc29ydGVkQ29sdW1uKHNvcnRlZENvbHVtbjogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuc2V0U2VhcmNoUGFyYW0oeyBzb3J0ZWRDb2x1bW4gfSk7XG4gICAgfVxuXG4gICAgZ2V0IHNlYXJjaFRlcm0oKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc3RhdGUuc2VhcmNoVGVybTtcbiAgICB9XG5cbiAgICBzZXQgc2VhcmNoVGVybShzZWFyY2hUZXJtOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5zdGF0ZS5zZWFyY2hUZXJtID0gc2VhcmNoVGVybTtcbiAgICAgICAgdGhpcy5zZWFyY2gubmV4dCgpO1xuICAgIH1cblxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICB0aGlzLmNvbnRlbnQgPSB7IHJlc3VsdHNPblBhZ2U6IFtdLCBudW1iZXJPZlBhZ2VzOiAwIH07XG5cbiAgICAgICAgdGhpcy5wZXJmb3JtU2VhcmNoKHRoaXMuc29ydCwgMCk7XG4gICAgICAgIHRoaXMucGVyZm9ybVNlYXJjaCh0aGlzLnNlYXJjaCwgMzAwKTtcbiAgICB9XG5cbiAgICBzb3J0Um93cygpIHtcbiAgICAgICAgdGhpcy5zb3J0U2VydmljZS5zb3J0QnlQcm9wZXJ0eSh0aGlzLmNvbnRlbnQucmVzdWx0c09uUGFnZSwgdGhpcy5zb3J0ZWRDb2x1bW4sIHRoaXMubGlzdFNvcnRpbmcpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqXG4gICAgICogR2l2ZXMgdGhlIElEIGZvciBhbnkgaXRlbSBpbiB0aGUgdGFibGUsIHNvIHRoYXQgaXQgY2FuIGJlIHRyYWNrZWQvaWRlbnRpZmllZCBieSBuZ0ZvclxuICAgICAqXG4gICAgICogQHRlbXBsYXRlIFRcbiAgICAgKiBAcGFyYW0gaW5kZXggVGhlIGluZGV4IG9mIHRoZSBlbGVtZW50IGluIHRoZSBuZ0ZvclxuICAgICAqIEBwYXJhbSB7VH0gaXRlbSBUaGUgaXRlbSBpdHNlbGZcbiAgICAgKiBAcmV0dXJucyBUaGUgSUQgb2YgdGhlIGl0ZW1cbiAgICAgKi9cbiAgICB0cmFja0lkKGluZGV4OiBudW1iZXIsIGl0ZW06IFQpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gaXRlbS5pZCE7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2xvc2VzIHRoZSBtb2RhbCBpbiB3aGljaCB0aGUgaW1wb3J0IGNvbXBvbmVudCBpcyBvcGVuZWQuIEdpdmVzIHRoZSBzZWxlY3RlZCBpdGVtIGFzIGEgcmVzdWx0LlxuICAgICAqXG4gICAgICogQHBhcmFtIGl0ZW0gVGhlIGl0ZW0gd2hpY2ggd2FzIHNlbGVjdGVkIGJ5IHRoZSB1c2VyIGZvciB0aGUgaW1wb3J0LlxuICAgICAqL1xuICAgIHNlbGVjdEltcG9ydChpdGVtOiBUKSB7XG4gICAgICAgIHRoaXMuYWN0aXZlTW9kYWwuY2xvc2UoaXRlbSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2xvc2VzIHRoZSBtb2RhbCBpbiB3aGljaCB0aGUgaW1wb3J0IGNvbXBvbmVudCBpcyBvcGVuZWQgYnkgZGlzbWlzc2luZyBpdFxuICAgICAqL1xuICAgIGNsZWFyKCkge1xuICAgICAgICB0aGlzLmFjdGl2ZU1vZGFsLmRpc21pc3MoJ2NhbmNlbCcpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENhbGxiYWNrIGZ1bmN0aW9uIHdoZW4gdGhlIHVzZXIgbmF2aWdhdGVzIHRocm91Z2ggdGhlIHBhZ2UgcmVzdWx0c1xuICAgICAqXG4gICAgICogQHBhcmFtIHBhZ2VOdW1iZXIgVGhlIGN1cnJlbnQgcGFnZSBudW1iZXJcbiAgICAgKi9cbiAgICBvblBhZ2VDaGFuZ2UocGFnZU51bWJlcjogbnVtYmVyKSB7XG4gICAgICAgIGlmIChwYWdlTnVtYmVyKSB7XG4gICAgICAgICAgICB0aGlzLnBhZ2UgPSBwYWdlTnVtYmVyO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTWV0aG9kIHRvIHBlcmZvcm0gdGhlIHNlYXJjaCBiYXNlZCBvbiBhIHNlYXJjaCBzdWJqZWN0XG4gICAgICpcbiAgICAgKiBAcGFyYW0gc2VhcmNoU3ViamVjdCBUaGUgc2VhcmNoIHN1YmplY3Qgd2hpY2ggd2UgdXNlIHRvIHNlYXJjaC5cbiAgICAgKiBAcGFyYW0gZGVib3VuY2UgVGhlIGRlbGF5IHdlIGFwcGx5IHRvIGRlbGF5IHRoZSBmZWVkYmFjayAvIHdhaXQgZm9yIGlucHV0XG4gICAgICovXG4gICAgYWJzdHJhY3QgcGVyZm9ybVNlYXJjaChzZWFyY2hTdWJqZWN0OiBTdWJqZWN0PHZvaWQ+LCBkZWJvdW5jZTogbnVtYmVyKTogdm9pZDtcblxuICAgIHByaXZhdGUgc2V0U2VhcmNoUGFyYW0ocGF0Y2g6IFBhcnRpYWw8UGFnZWFibGVTZWFyY2g+KSB7XG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcy5zdGF0ZSwgcGF0Y2gpO1xuICAgICAgICB0aGlzLnNvcnQubmV4dCgpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSW1wb3J0Q29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC9pbXBvcnQvaW1wb3J0LWNvbXBvbmVudCc7XG5pbXBvcnQgeyBkZWJvdW5jZVRpbWUsIHN3aXRjaE1hcCwgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgQ29tcGV0ZW5jeSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb21wZXRlbmN5Lm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktY29tcGV0ZW5jeS1pbXBvcnQnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9jb21wZXRlbmN5LWltcG9ydC5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIENvbXBldGVuY3lJbXBvcnRDb21wb25lbnQgZXh0ZW5kcyBJbXBvcnRDb21wb25lbnQ8Q29tcGV0ZW5jeT4ge1xuICAgIG92ZXJyaWRlIHBlcmZvcm1TZWFyY2goc2VhcmNoU3ViamVjdDogU3ViamVjdDx2b2lkPiwgZGVib3VuY2U6IG51bWJlcikge1xuICAgICAgICBzZWFyY2hTdWJqZWN0XG4gICAgICAgICAgICAucGlwZShcbiAgICAgICAgICAgICAgICBkZWJvdW5jZVRpbWUoZGVib3VuY2UpLFxuICAgICAgICAgICAgICAgIHRhcCgoKSA9PiAodGhpcy5sb2FkaW5nID0gdHJ1ZSkpLFxuICAgICAgICAgICAgICAgIHN3aXRjaE1hcCgoKSA9PiB0aGlzLnBhZ2luZ1NlcnZpY2Uuc2VhcmNoRm9yQ29tcGV0ZW5jaWVzKHRoaXMuc3RhdGUpKSxcbiAgICAgICAgICAgIClcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoKHJlc3ApID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRlbnQgPSByZXNwO1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHRoaXMudG90YWwgPSByZXNwLm51bWJlck9mUGFnZXMgKiB0aGlzLnN0YXRlLnBhZ2VTaXplO1xuICAgICAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiPGZvcm0+XG4gICAgPGRpdiBjbGFzcz1cIm1vZGFsLWhlYWRlclwiPlxuICAgICAgICA8aDQgY2xhc3M9XCJtb2RhbC10aXRsZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5pbXBvcnRDb21wZXRlbmN5LnRpdGxlXCI+SW1wb3J0IGEgQ29tcGV0ZW5jeTwvaDQ+XG4gICAgICAgIDxidXR0b24gKGNsaWNrKT1cImNsZWFyKClcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzcz1cImJ0bi1jbG9zZVwiIGRhdGEtZGlzbWlzcz1cIm1vZGFsXCIgdHlwZT1cImJ1dHRvblwiPjwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1ib2R5XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwIGZvcm0taW5saW5lXCI+XG4gICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvbXBldGVuY3kuaW1wb3J0Q29tcGV0ZW5jeS5zZWFyY2hcIj5TZWFyY2ggZm9yIGNvbXBldGVuY3k6PC9zcGFuPlxuICAgICAgICAgICAgPGlucHV0IFsobmdNb2RlbCldPVwic2VhcmNoVGVybVwiIGNsYXNzPVwiZm9ybS1jb250cm9sIG1zLTJcIiBuYW1lPVwic2VhcmNoQ29tcGV0ZW5jeVwiIHR5cGU9XCJ0ZXh0XCIgLz5cbiAgICAgICAgICAgIEBpZiAobG9hZGluZykge1xuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibXMtM1wiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5pbXBvcnRDb21wZXRlbmN5LmxvYWRpbmdcIj5Mb2FkaW5nLi4uPC9zcGFuPlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHRhYmxlIGNsYXNzPVwidGFibGUgdGFibGUtc3RyaXBlZCBhbGlnbi1taWRkbGUgZmxleFwiPlxuICAgICAgICAgICAgPHRoZWFkIGNsYXNzPVwidGhlYWQtZGFya1wiPlxuICAgICAgICAgICAgICAgIDx0ciAoc29ydENoYW5nZSk9XCJzb3J0Um93cygpXCIgWyhhc2NlbmRpbmcpXT1cImxpc3RTb3J0aW5nXCIgWyhwcmVkaWNhdGUpXT1cInNvcnRlZENvbHVtblwiIGNsYXNzPVwiZmxleC1yb3dcIiBqaGlTb3J0PlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJjb2wtMVwiIGpoaVNvcnRCeT1cInt7IGNvbHVtbi5JRCB9fVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Izwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhU29ydFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzPVwiY29sLTRcIiBqaGlTb3J0Qnk9XCJ7eyBjb2x1bW4uVElUTEUgfX1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5pbXBvcnRDb21wZXRlbmN5LnRhYmxlLnRpdGxlXCI+VGl0bGU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVNvcnRcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz1cImNvbC00XCIgamhpU29ydEJ5PVwie3sgY29sdW1uLkNPVVJTRV9USVRMRSB9fVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LmltcG9ydENvbXBldGVuY3kudGFibGUuY291cnNlXCI+Q291cnNlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFTb3J0XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJjb2wtMlwiIGpoaVNvcnRCeT1cInt7IGNvbHVtbi5TRU1FU1RFUiB9fVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LmltcG9ydENvbXBldGVuY3kudGFibGUuc2VtZXN0ZXJcIj5TZW1lc3Rlcjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhU29ydFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzPVwiY29sLTFcIj48L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgIEBmb3IgKGNvbXBldGVuY3kgb2YgY29udGVudC5yZXN1bHRzT25QYWdlOyB0cmFjayB0cmFja0lkKCRpbmRleCwgY29tcGV0ZW5jeSkpIHtcbiAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzPVwiZmxleC1yb3dcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cImNvbC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgY29tcGV0ZW5jeS5pZCB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJ0ZXh0LWJyZWFrIGNvbC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG5nYi1oaWdobGlnaHQgW3Jlc3VsdF09XCJjb21wZXRlbmN5LnRpdGxlXCIgW3Rlcm1dPVwic2VhcmNoVGVybVwiPjwvbmdiLWhpZ2hsaWdodD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJ0ZXh0LWJyZWFrIGNvbC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG5nYi1oaWdobGlnaHQgW3Jlc3VsdF09XCJjb21wZXRlbmN5LmNvdXJzZT8udGl0bGVcIiBbdGVybV09XCJzZWFyY2hUZXJtXCI+PC9uZ2ItaGlnaGxpZ2h0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cImNvbC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgY29tcGV0ZW5jeS5jb3Vyc2U/LnNlbWVzdGVyIHx8ICcnIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cImNvbC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1idXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKG9uQ2xpY2spPVwic2VsZWN0SW1wb3J0KGNvbXBldGVuY3kpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2Rpc2FibGVkXT1cImRpc2FibGVkSWRzLmluY2x1ZGVzKGNvbXBldGVuY3kuaWQhKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0aXRsZV09XCInYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LmltcG9ydENvbXBldGVuY3kudGFibGUuZG9TZWxlY3QnXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9qaGktYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICA8L3RhYmxlPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGp1c3RpZnktY29udGVudC1iZXR3ZWVuIHAtMlwiPlxuICAgICAgICAgICAgPG5nYi1wYWdpbmF0aW9uIChwYWdlQ2hhbmdlKT1cIm9uUGFnZUNoYW5nZSgkZXZlbnQpXCIgWyhwYWdlKV09XCJzdGF0ZS5wYWdlXCIgW2NvbGxlY3Rpb25TaXplXT1cInRvdGFsXCIgW21heFNpemVdPVwiMTBcIiBbcGFnZVNpemVdPVwic3RhdGUucGFnZVNpemVcIiBbcm90YXRlXT1cInRydWVcIj5cbiAgICAgICAgICAgIDwvbmdiLXBhZ2luYXRpb24+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuPC9mb3JtPlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb21wZXRlbmN5SW1wb3J0Q29tcG9uZW50IH0gZnJvbSAnYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jeS1tYW5hZ2VtZW50L2NvbXBldGVuY3ktaW1wb3J0LmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXByZXJlcXVpc2l0ZS1pbXBvcnQnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9wcmVyZXF1aXNpdGUtaW1wb3J0LmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgUHJlcmVxdWlzaXRlSW1wb3J0Q29tcG9uZW50IGV4dGVuZHMgQ29tcGV0ZW5jeUltcG9ydENvbXBvbmVudCB7fVxuIiwiPGZvcm0+XG4gICAgPGRpdiBjbGFzcz1cIm1vZGFsLWhlYWRlclwiPlxuICAgICAgICA8aDQgY2xhc3M9XCJtb2RhbC10aXRsZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5wcmVyZXF1aXNpdGUuaW1wb3J0LnRpdGxlXCI+U2VsZWN0IFByZXJlcXVpc2l0ZTwvaDQ+XG4gICAgICAgIDxidXR0b24gKGNsaWNrKT1cImNsZWFyKClcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzcz1cImJ0bi1jbG9zZVwiIGRhdGEtZGlzbWlzcz1cIm1vZGFsXCIgdHlwZT1cImJ1dHRvblwiPjwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1ib2R5XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwIGZvcm0taW5saW5lXCI+XG4gICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvbXBldGVuY3kucHJlcmVxdWlzaXRlLmltcG9ydC5zZWFyY2hDb21wZXRlbmN5XCI+U2VhcmNoIGZvciBjb21wZXRlbmN5Ojwvc3Bhbj5cbiAgICAgICAgICAgIDxpbnB1dCBbKG5nTW9kZWwpXT1cInNlYXJjaFRlcm1cIiBjbGFzcz1cImZvcm0tY29udHJvbCBtcy0yXCIgbmFtZT1cInNlYXJjaENvbXBldGVuY3lcIiB0eXBlPVwidGV4dFwiIC8+XG4gICAgICAgICAgICBAaWYgKGxvYWRpbmcpIHtcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cIm1zLTNcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvbXBldGVuY3kucHJlcmVxdWlzaXRlLmltcG9ydC5sb2FkaW5nXCI+TG9hZGluZy4uLjwvc3Bhbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlIHRhYmxlLXN0cmlwZWQgYWxpZ24tbWlkZGxlIGZsZXhcIj5cbiAgICAgICAgICAgIDx0aGVhZCBjbGFzcz1cInRoZWFkLWRhcmtcIj5cbiAgICAgICAgICAgICAgICA8dHIgKHNvcnRDaGFuZ2UpPVwic29ydFJvd3MoKVwiIFsoYXNjZW5kaW5nKV09XCJsaXN0U29ydGluZ1wiIFsocHJlZGljYXRlKV09XCJzb3J0ZWRDb2x1bW5cIiBjbGFzcz1cImZsZXgtcm93XCIgamhpU29ydD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzPVwiY29sLTFcIiBqaGlTb3J0Qnk9XCJ7eyBjb2x1bW4uSUQgfX1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVNvcnRcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz1cImNvbC00XCIgamhpU29ydEJ5PVwie3sgY29sdW1uLlRJVExFIH19XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvbXBldGVuY3kucHJlcmVxdWlzaXRlLmltcG9ydC50YWJsZS50aXRsZVwiPlRpdGxlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFTb3J0XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJjb2wtNFwiIGpoaVNvcnRCeT1cInt7IGNvbHVtbi5DT1VSU0VfVElUTEUgfX1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5wcmVyZXF1aXNpdGUuaW1wb3J0LnRhYmxlLmNvdXJzZVwiPkNvdXJzZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhU29ydFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzPVwiY29sLTJcIiBqaGlTb3J0Qnk9XCJ7eyBjb2x1bW4uU0VNRVNURVIgfX1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5wcmVyZXF1aXNpdGUuaW1wb3J0LnRhYmxlLnNlbWVzdGVyXCI+U2VtZXN0ZXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVNvcnRcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzcz1cImNvbC0xXCI+PC90aD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICBAZm9yIChjb21wZXRlbmN5IG9mIGNvbnRlbnQucmVzdWx0c09uUGFnZTsgdHJhY2sgdHJhY2tJZCgkaW5kZXgsIGNvbXBldGVuY3kpKSB7XG4gICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzcz1cImZsZXgtcm93XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJjb2wtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGNvbXBldGVuY3kuaWQgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPVwidGV4dC1icmVhayBjb2wtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxuZ2ItaGlnaGxpZ2h0IFtyZXN1bHRdPVwiY29tcGV0ZW5jeS50aXRsZVwiIFt0ZXJtXT1cInNlYXJjaFRlcm1cIj48L25nYi1oaWdobGlnaHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPVwidGV4dC1icmVhayBjb2wtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxuZ2ItaGlnaGxpZ2h0IFtyZXN1bHRdPVwiY29tcGV0ZW5jeS5jb3Vyc2U/LnRpdGxlXCIgW3Rlcm1dPVwic2VhcmNoVGVybVwiPjwvbmdiLWhpZ2hsaWdodD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJjb2wtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGNvbXBldGVuY3kuY291cnNlPy5zZW1lc3RlciB8fCAnJyB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJjb2wtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktYnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChvbkNsaWNrKT1cInNlbGVjdEltcG9ydChjb21wZXRlbmN5KVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtkaXNhYmxlZF09XCJkaXNhYmxlZElkcy5pbmNsdWRlcyhjb21wZXRlbmN5LmlkISlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdGl0bGVdPVwiJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5wcmVyZXF1aXNpdGUuaW1wb3J0LnRhYmxlLmRvU2VsZWN0J1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvamhpLWJ1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgPC90YWJsZT5cbiAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBwLTJcIj5cbiAgICAgICAgICAgIDxuZ2ItcGFnaW5hdGlvbiAocGFnZUNoYW5nZSk9XCJvblBhZ2VDaGFuZ2UoJGV2ZW50KVwiIFsocGFnZSldPVwic3RhdGUucGFnZVwiIFtjb2xsZWN0aW9uU2l6ZV09XCJ0b3RhbFwiIFttYXhTaXplXT1cIjEwXCIgW3BhZ2VTaXplXT1cInN0YXRlLnBhZ2VTaXplXCIgW3JvdGF0ZV09XCJ0cnVlXCI+XG4gICAgICAgICAgICA8L25nYi1wYWdpbmF0aW9uPlxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbjwvZm9ybT5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25EZXN0cm95LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IENvbXBldGVuY3lTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jeS5zZXJ2aWNlJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5pbXBvcnQgeyBDb21wZXRlbmN5LCBDb21wZXRlbmN5UmVsYXRpb24sIENvbXBldGVuY3lSZWxhdGlvbkVycm9yLCBDb3Vyc2VDb21wZXRlbmN5UHJvZ3Jlc3MsIGdldEljb24sIGdldEljb25Ub29sdGlwIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvbXBldGVuY3kubW9kZWwnO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IGZpbHRlciwgZmluYWxpemUsIG1hcCwgc3dpdGNoTWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgb25FcnJvciB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC9nbG9iYWwudXRpbHMnO1xuaW1wb3J0IHsgU3ViamVjdCwgZm9ya0pvaW4gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IGZhUGVuY2lsQWx0LCBmYVBsdXMsIGZhVHJhc2ggfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgTmdiTW9kYWwgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgeyBQcmVyZXF1aXNpdGVJbXBvcnRDb21wb25lbnQgfSBmcm9tICdhcHAvY291cnNlL2NvbXBldGVuY2llcy9jb21wZXRlbmN5LW1hbmFnZW1lbnQvcHJlcmVxdWlzaXRlLWltcG9ydC5jb21wb25lbnQnO1xuaW1wb3J0IHsgQ2x1c3Rlck5vZGUsIEVkZ2UsIE5vZGUgfSBmcm9tICdAc3dpbWxhbmUvbmd4LWdyYXBoJztcbmltcG9ydCB7IENvbXBldGVuY3lJbXBvcnRDb21wb25lbnQgfSBmcm9tICdhcHAvY291cnNlL2NvbXBldGVuY2llcy9jb21wZXRlbmN5LW1hbmFnZW1lbnQvY29tcGV0ZW5jeS1pbXBvcnQuY29tcG9uZW50JztcbmltcG9ydCB7IERvY3VtZW50YXRpb25UeXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL2RvY3VtZW50YXRpb24tYnV0dG9uL2RvY3VtZW50YXRpb24tYnV0dG9uLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWNvbXBldGVuY3ktbWFuYWdlbWVudCcsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2NvbXBldGVuY3ktbWFuYWdlbWVudC5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vY29tcGV0ZW5jeS1tYW5hZ2VtZW50LmNvbXBvbmVudC5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIENvbXBldGVuY3lNYW5hZ2VtZW50Q29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xuICAgIGNvdXJzZUlkOiBudW1iZXI7XG4gICAgaXNMb2FkaW5nID0gZmFsc2U7XG4gICAgY29tcGV0ZW5jaWVzOiBDb21wZXRlbmN5W10gPSBbXTtcbiAgICBwcmVyZXF1aXNpdGVzOiBDb21wZXRlbmN5W10gPSBbXTtcblxuICAgIHRhaWxDb21wZXRlbmN5PzogbnVtYmVyO1xuICAgIGhlYWRDb21wZXRlbmN5PzogbnVtYmVyO1xuICAgIHJlbGF0aW9uVHlwZT86IHN0cmluZztcbiAgICBub2RlczogTm9kZVtdID0gW107XG4gICAgZWRnZXM6IEVkZ2VbXSA9IFtdO1xuICAgIGNsdXN0ZXJzOiBDbHVzdGVyTm9kZVtdID0gW107XG4gICAgY29tcGV0ZW5jeVJlbGF0aW9uRXJyb3IgPSBDb21wZXRlbmN5UmVsYXRpb25FcnJvcjtcbiAgICByZWxhdGlvbkVycm9yOiBDb21wZXRlbmN5UmVsYXRpb25FcnJvciA9IENvbXBldGVuY3lSZWxhdGlvbkVycm9yLk5PTkU7XG5cbiAgICBwcml2YXRlIGRpYWxvZ0Vycm9yU291cmNlID0gbmV3IFN1YmplY3Q8c3RyaW5nPigpO1xuICAgIGRpYWxvZ0Vycm9yJCA9IHRoaXMuZGlhbG9nRXJyb3JTb3VyY2UuYXNPYnNlcnZhYmxlKCk7XG5cbiAgICB1cGRhdGUkOiBTdWJqZWN0PGJvb2xlYW4+ID0gbmV3IFN1YmplY3Q8Ym9vbGVhbj4oKTtcblxuICAgIHJlYWRvbmx5IGdldEljb24gPSBnZXRJY29uO1xuICAgIHJlYWRvbmx5IGdldEljb25Ub29sdGlwID0gZ2V0SWNvblRvb2x0aXA7XG4gICAgcmVhZG9ubHkgZG9jdW1lbnRhdGlvblR5cGU6IERvY3VtZW50YXRpb25UeXBlID0gJ0NvbXBldGVuY2llcyc7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhUGx1cyA9IGZhUGx1cztcbiAgICBmYVRyYXNoID0gZmFUcmFzaDtcbiAgICBmYVBlbmNpbEFsdCA9IGZhUGVuY2lsQWx0O1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgYWN0aXZhdGVkUm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgICAgICBwcml2YXRlIGNvbXBldGVuY3lTZXJ2aWNlOiBDb21wZXRlbmN5U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBhbGVydFNlcnZpY2U6IEFsZXJ0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBtb2RhbFNlcnZpY2U6IE5nYk1vZGFsLFxuICAgICkge31cblxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgICAgICB0aGlzLmRpYWxvZ0Vycm9yU291cmNlLnVuc3Vic2NyaWJlKCk7XG4gICAgfVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuYWN0aXZhdGVkUm91dGUucGFyZW50IS5wYXJhbXMuc3Vic2NyaWJlKChwYXJhbXMpID0+IHtcbiAgICAgICAgICAgIHRoaXMuY291cnNlSWQgPSBwYXJhbXNbJ2NvdXJzZUlkJ107XG4gICAgICAgICAgICBpZiAodGhpcy5jb3Vyc2VJZCkge1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZERhdGEoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgdmFsaWRhdGUoKTogdm9pZCB7XG4gICAgICAgIGlmICh0aGlzLmhlYWRDb21wZXRlbmN5ICYmIHRoaXMudGFpbENvbXBldGVuY3kgJiYgdGhpcy5yZWxhdGlvblR5cGUgJiYgdGhpcy5oZWFkQ29tcGV0ZW5jeSA9PT0gdGhpcy50YWlsQ29tcGV0ZW5jeSkge1xuICAgICAgICAgICAgdGhpcy5yZWxhdGlvbkVycm9yID0gQ29tcGV0ZW5jeVJlbGF0aW9uRXJyb3IuU0VMRjtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5kb2VzUmVsYXRpb25BbHJlYWR5RXhpc3QoKSkge1xuICAgICAgICAgICAgdGhpcy5yZWxhdGlvbkVycm9yID0gQ29tcGV0ZW5jeVJlbGF0aW9uRXJyb3IuRVhJU1RJTkc7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuY29udGFpbnNDaXJjdWxhclJlbGF0aW9uKCkpIHtcbiAgICAgICAgICAgIHRoaXMucmVsYXRpb25FcnJvciA9IENvbXBldGVuY3lSZWxhdGlvbkVycm9yLkNJUkNVTEFSO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMucmVsYXRpb25FcnJvciA9IENvbXBldGVuY3lSZWxhdGlvbkVycm9yLk5PTkU7XG4gICAgfVxuXG4gICAgZ2V0RXJyb3JNZXNzYWdlKGVycm9yOiBDb21wZXRlbmN5UmVsYXRpb25FcnJvcik6IHN0cmluZyB7XG4gICAgICAgIHN3aXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNhc2UgQ29tcGV0ZW5jeVJlbGF0aW9uRXJyb3IuQ0lSQ1VMQVI6IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5yZWxhdGlvbi5jcmVhdGVzQ2lyY3VsYXJSZWxhdGlvbic7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIENvbXBldGVuY3lSZWxhdGlvbkVycm9yLkVYSVNUSU5HOiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICdhcnRlbWlzQXBwLmNvbXBldGVuY3kucmVsYXRpb24ucmVsYXRpb25BbHJlYWR5RXhpc3RzJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgQ29tcGV0ZW5jeVJlbGF0aW9uRXJyb3IuU0VMRjoge1xuICAgICAgICAgICAgICAgIHJldHVybiAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LnJlbGF0aW9uLnNlbGZSZWxhdGlvbic7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIENvbXBldGVuY3lSZWxhdGlvbkVycm9yLk5PTkU6IHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdUaGVyZSBpcyBubyBlcnJvciBtZXNzYWdlIGlmIHRoZXJlIGlzIG5vIGVycm9yLicpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgaWRlbnRpZnkoaW5kZXg6IG51bWJlciwgY29tcGV0ZW5jeTogQ29tcGV0ZW5jeSkge1xuICAgICAgICByZXR1cm4gYCR7aW5kZXh9LSR7Y29tcGV0ZW5jeS5pZH1gO1xuICAgIH1cblxuICAgIGRlbGV0ZUNvbXBldGVuY3koY29tcGV0ZW5jeUlkOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5jb21wZXRlbmN5U2VydmljZS5kZWxldGUoY29tcGV0ZW5jeUlkLCB0aGlzLmNvdXJzZUlkKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuZGlhbG9nRXJyb3JTb3VyY2UubmV4dCgnJyk7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2FkRGF0YSgpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yOiAoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiB0aGlzLmRpYWxvZ0Vycm9yU291cmNlLm5leHQoZXJyb3IubWVzc2FnZSksXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHJlbW92ZVByZXJlcXVpc2l0ZShjb21wZXRlbmN5SWQ6IG51bWJlcikge1xuICAgICAgICB0aGlzLmNvbXBldGVuY3lTZXJ2aWNlLnJlbW92ZVByZXJlcXVpc2l0ZShjb21wZXRlbmN5SWQsIHRoaXMuY291cnNlSWQpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5kaWFsb2dFcnJvclNvdXJjZS5uZXh0KCcnKTtcbiAgICAgICAgICAgICAgICB0aGlzLmxvYWREYXRhKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZXJyb3I6IChlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHRoaXMuZGlhbG9nRXJyb3JTb3VyY2UubmV4dChlcnJvci5tZXNzYWdlKSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgbG9hZERhdGEoKSB7XG4gICAgICAgIHRoaXMuaXNMb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5jb21wZXRlbmN5U2VydmljZVxuICAgICAgICAgICAgLmdldEFsbFByZXJlcXVpc2l0ZXNGb3JDb3Vyc2UodGhpcy5jb3Vyc2VJZClcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzcG9uc2U6IEh0dHBSZXNwb25zZTxDb21wZXRlbmN5W10+KSA9PiByZXNwb25zZS5ib2R5ISkpXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAoY29tcGV0ZW5jaWVzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucHJlcmVxdWlzaXRlcyA9IGNvbXBldGVuY2llcztcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGVycm9yOiAoZXJyb3JSZXNwb25zZTogSHR0cEVycm9yUmVzcG9uc2UpID0+IG9uRXJyb3IodGhpcy5hbGVydFNlcnZpY2UsIGVycm9yUmVzcG9uc2UpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuY29tcGV0ZW5jeVNlcnZpY2VcbiAgICAgICAgICAgIC5nZXRBbGxGb3JDb3Vyc2UodGhpcy5jb3Vyc2VJZClcbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIHN3aXRjaE1hcCgocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcGV0ZW5jaWVzID0gcmVzLmJvZHkhO1xuXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubm9kZXMgPSB0aGlzLmNvbXBldGVuY2llcy5tYXAoXG4gICAgICAgICAgICAgICAgICAgICAgICAoY29tcGV0ZW5jeSk6IE5vZGUgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogYCR7Y29tcGV0ZW5jeS5pZH1gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBjb21wZXRlbmN5LnRpdGxlLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVsYXRpb25zT2JzZXJ2YWJsZSA9IHRoaXMuY29tcGV0ZW5jaWVzLm1hcCgobGcpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbXBldGVuY3lTZXJ2aWNlLmdldENvbXBldGVuY3lSZWxhdGlvbnMobGcuaWQhLCB0aGlzLmNvdXJzZUlkKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcHJvZ3Jlc3NPYnNlcnZhYmxlID0gdGhpcy5jb21wZXRlbmNpZXMubWFwKChsZykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29tcGV0ZW5jeVNlcnZpY2UuZ2V0Q291cnNlUHJvZ3Jlc3MobGcuaWQhLCB0aGlzLmNvdXJzZUlkKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZvcmtKb2luKFtmb3JrSm9pbihyZWxhdGlvbnNPYnNlcnZhYmxlKSwgZm9ya0pvaW4ocHJvZ3Jlc3NPYnNlcnZhYmxlKV0pO1xuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgZmluYWxpemUoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKFtjb21wZXRlbmN5UmVsYXRpb25zLCBjb21wZXRlbmN5UHJvZ3Jlc3NSZXNwb25zZXNdKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlbGF0aW9ucyA9IFtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmNvbXBldGVuY3lSZWxhdGlvbnNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmxhdE1hcCgocmVzcG9uc2UpID0+IHJlc3BvbnNlLmJvZHkhKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5yZWR1Y2UoKGEsIGMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYS5zZXQoYy5pZCwgYyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBhO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sIG5ldyBNYXAoKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudmFsdWVzKCksXG4gICAgICAgICAgICAgICAgICAgIF07XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZWRnZXMgPSByZWxhdGlvbnMubWFwKFxuICAgICAgICAgICAgICAgICAgICAgICAgKHJlbGF0aW9uKTogRWRnZSA9PiAoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBgZWRnZSR7cmVsYXRpb24uaWR9YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzb3VyY2U6IGAke3JlbGF0aW9uLnRhaWxDb21wZXRlbmN5Py5pZH1gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldDogYCR7cmVsYXRpb24uaGVhZENvbXBldGVuY3k/LmlkfWAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IHJlbGF0aW9uLnR5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogcmVsYXRpb24uaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNsdXN0ZXJzID0gcmVsYXRpb25zXG4gICAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKChyZWxhdGlvbikgPT4gcmVsYXRpb24udHlwZSA9PT0gJ0NPTlNFQ1VUSVZFJylcbiAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKHJlbGF0aW9uKTogQ2x1c3Rlck5vZGUgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGBjbHVzdGVyJHtyZWxhdGlvbi5pZH1gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogcmVsYXRpb24udHlwZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hpbGROb2RlSWRzOiBbYCR7cmVsYXRpb24udGFpbENvbXBldGVuY3k/LmlkfWAsIGAke3JlbGF0aW9uLmhlYWRDb21wZXRlbmN5Py5pZH1gXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHJlbGF0aW9uLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGNvbXBldGVuY3lQcm9ncmVzc1Jlc3BvbnNlIG9mIGNvbXBldGVuY3lQcm9ncmVzc1Jlc3BvbnNlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY291cnNlQ29tcGV0ZW5jeVByb2dyZXNzOiBDb3Vyc2VDb21wZXRlbmN5UHJvZ3Jlc3MgPSBjb21wZXRlbmN5UHJvZ3Jlc3NSZXNwb25zZS5ib2R5ITtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcGV0ZW5jaWVzLmZpbmQoKGxnKSA9PiBsZy5pZCA9PT0gY291cnNlQ29tcGV0ZW5jeVByb2dyZXNzLmNvbXBldGVuY3lJZCkhLmNvdXJzZVByb2dyZXNzID0gY291cnNlQ29tcGV0ZW5jeVByb2dyZXNzO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKGVycm9yUmVzcG9uc2U6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiBvbkVycm9yKHRoaXMuYWxlcnRTZXJ2aWNlLCBlcnJvclJlc3BvbnNlKSxcbiAgICAgICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE9wZW5zIGEgbW9kYWwgZm9yIGFkZGluZyBhIHByZXJlcXVpc2l0ZSB0byB0aGUgY3VycmVudCBjb3Vyc2UuXG4gICAgICovXG4gICAgb3BlblByZXJlcXVpc2l0ZVNlbGVjdGlvbk1vZGFsKCkge1xuICAgICAgICBjb25zdCBtb2RhbFJlZiA9IHRoaXMubW9kYWxTZXJ2aWNlLm9wZW4oUHJlcmVxdWlzaXRlSW1wb3J0Q29tcG9uZW50LCB7IHNpemU6ICdsZycsIGJhY2tkcm9wOiAnc3RhdGljJyB9KTtcbiAgICAgICAgbW9kYWxSZWYuY29tcG9uZW50SW5zdGFuY2UuZGlzYWJsZWRJZHMgPSB0aGlzLmNvbXBldGVuY2llcy5jb25jYXQodGhpcy5wcmVyZXF1aXNpdGVzKS5tYXAoKGNvbXBldGVuY3kpID0+IGNvbXBldGVuY3kuaWQpO1xuICAgICAgICBtb2RhbFJlZi5yZXN1bHQudGhlbigocmVzdWx0OiBDb21wZXRlbmN5KSA9PiB7XG4gICAgICAgICAgICB0aGlzLmNvbXBldGVuY3lTZXJ2aWNlXG4gICAgICAgICAgICAgICAgLmFkZFByZXJlcXVpc2l0ZShyZXN1bHQuaWQhLCB0aGlzLmNvdXJzZUlkKVxuICAgICAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXIoKHJlczogSHR0cFJlc3BvbnNlPENvbXBldGVuY3k+KSA9PiByZXMub2spLFxuICAgICAgICAgICAgICAgICAgICBtYXAoKHJlczogSHR0cFJlc3BvbnNlPENvbXBldGVuY3k+KSA9PiByZXMuYm9keSksXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIC5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgICAgICAgICBuZXh0OiAocmVzOiBDb21wZXRlbmN5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnByZXJlcXVpc2l0ZXMucHVzaChyZXMpO1xuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBlcnJvcjogKHJlczogSHR0cEVycm9yUmVzcG9uc2UpID0+IG9uRXJyb3IodGhpcy5hbGVydFNlcnZpY2UsIHJlcyksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE9wZW5zIGEgbW9kYWwgZm9yIHNlbGVjdGluZyBhIGNvbXBldGVuY3kgdG8gaW1wb3J0IHRvIHRoZSBjdXJyZW50IGNvdXJzZS5cbiAgICAgKi9cbiAgICBvcGVuSW1wb3J0TW9kYWwoKSB7XG4gICAgICAgIGNvbnN0IG1vZGFsUmVmID0gdGhpcy5tb2RhbFNlcnZpY2Uub3BlbihDb21wZXRlbmN5SW1wb3J0Q29tcG9uZW50LCB7IHNpemU6ICdsZycsIGJhY2tkcm9wOiAnc3RhdGljJyB9KTtcbiAgICAgICAgbW9kYWxSZWYuY29tcG9uZW50SW5zdGFuY2UuZGlzYWJsZWRJZHMgPSB0aGlzLmNvbXBldGVuY2llcy5jb25jYXQodGhpcy5wcmVyZXF1aXNpdGVzKS5tYXAoKGNvbXBldGVuY3kpID0+IGNvbXBldGVuY3kuaWQpO1xuICAgICAgICBtb2RhbFJlZi5yZXN1bHQudGhlbigoc2VsZWN0ZWRDb21wZXRlbmN5OiBDb21wZXRlbmN5KSA9PiB7XG4gICAgICAgICAgICB0aGlzLmNvbXBldGVuY3lTZXJ2aWNlXG4gICAgICAgICAgICAgICAgLmltcG9ydChzZWxlY3RlZENvbXBldGVuY3ksIHRoaXMuY291cnNlSWQpXG4gICAgICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlcigocmVzOiBIdHRwUmVzcG9uc2U8Q29tcGV0ZW5jeT4pID0+IHJlcy5vayksXG4gICAgICAgICAgICAgICAgICAgIG1hcCgocmVzOiBIdHRwUmVzcG9uc2U8Q29tcGV0ZW5jeT4pID0+IHJlcy5ib2R5KSxcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgICAgIG5leHQ6IChyZXM6IENvbXBldGVuY3kpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcGV0ZW5jaWVzLnB1c2gocmVzKTtcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I6IChyZXM6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiBvbkVycm9yKHRoaXMuYWxlcnRTZXJ2aWNlLCByZXMpLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBjcmVhdGVSZWxhdGlvbigpIHtcbiAgICAgICAgaWYgKHRoaXMucmVsYXRpb25FcnJvciAhPT0gQ29tcGV0ZW5jeVJlbGF0aW9uRXJyb3IuTk9ORSkge1xuICAgICAgICAgICAgc3dpdGNoICh0aGlzLnJlbGF0aW9uRXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjYXNlIENvbXBldGVuY3lSZWxhdGlvbkVycm9yLkNJUkNVTEFSOiB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0NyZWF0aW9uIG9mIGNpcmN1bGFyIHJlbGF0aW9ucyBpcyBub3QgYWxsb3dlZC4nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2FzZSBDb21wZXRlbmN5UmVsYXRpb25FcnJvci5FWElTVElORzoge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdDcmVhdGlvbiBvZiBhbiBhbHJlYWR5IGV4aXN0aW5nIHJlbGF0aW9uIGlzIG5vdCBhbGxvd2VkLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXNlIENvbXBldGVuY3lSZWxhdGlvbkVycm9yLlNFTEY6IHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQ3JlYXRpb24gb2YgYSBzZWxmIHJlbGF0aW9uIGlzIG5vdCBhbGxvd2VkLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNvbXBldGVuY3lTZXJ2aWNlXG4gICAgICAgICAgICAuY3JlYXRlQ29tcGV0ZW5jeVJlbGF0aW9uKHRoaXMudGFpbENvbXBldGVuY3khLCB0aGlzLmhlYWRDb21wZXRlbmN5ISwgdGhpcy5yZWxhdGlvblR5cGUhLCB0aGlzLmNvdXJzZUlkKVxuICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgZmlsdGVyKChyZXM6IEh0dHBSZXNwb25zZTxDb21wZXRlbmN5UmVsYXRpb24+KSA9PiByZXMub2spLFxuICAgICAgICAgICAgICAgIG1hcCgocmVzOiBIdHRwUmVzcG9uc2U8Q29tcGV0ZW5jeVJlbGF0aW9uPikgPT4gcmVzLmJvZHkpLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKHJlbGF0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZWxhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5lZGdlcy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogYGVkZ2Uke3JlbGF0aW9uLmlkfWAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc291cmNlOiBgJHtyZWxhdGlvbi50YWlsQ29tcGV0ZW5jeT8uaWR9YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ6IGAke3JlbGF0aW9uLmhlYWRDb21wZXRlbmN5Py5pZH1gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiByZWxhdGlvbi50eXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHJlbGF0aW9uLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlJC5uZXh0KHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKHJlczogSHR0cEVycm9yUmVzcG9uc2UpID0+IG9uRXJyb3IodGhpcy5hbGVydFNlcnZpY2UsIHJlcyksXG4gICAgICAgICAgICB9KTtcbiAgICB9XG5cbiAgICByZW1vdmVSZWxhdGlvbihlZGdlOiBFZGdlKSB7XG4gICAgICAgIHRoaXMuY29tcGV0ZW5jeVNlcnZpY2UucmVtb3ZlQ29tcGV0ZW5jeVJlbGF0aW9uKE51bWJlcihlZGdlLnNvdXJjZSksIE51bWJlcihlZGdlLmRhdGEuaWQpLCB0aGlzLmNvdXJzZUlkKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gdGhpcy5lZGdlcy5maW5kSW5kZXgoKGUpID0+IGUuaWQgPT09IGVkZ2UuaWQpO1xuICAgICAgICAgICAgICAgIHRoaXMuZWRnZXMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZSQubmV4dCh0cnVlKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogKHJlczogSHR0cEVycm9yUmVzcG9uc2UpID0+IG9uRXJyb3IodGhpcy5hbGVydFNlcnZpY2UsIHJlcyksXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHByaXZhdGUgY29udGFpbnNDaXJjdWxhclJlbGF0aW9uKCk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAodGhpcy5oZWFkQ29tcGV0ZW5jeSAhPT0gdGhpcy50YWlsQ29tcGV0ZW5jeSkge1xuICAgICAgICAgICAgcmV0dXJuICEhKFxuICAgICAgICAgICAgICAgIHRoaXMudGFpbENvbXBldGVuY3kgJiZcbiAgICAgICAgICAgICAgICB0aGlzLmhlYWRDb21wZXRlbmN5ICYmXG4gICAgICAgICAgICAgICAgdGhpcy5yZWxhdGlvblR5cGUgJiZcbiAgICAgICAgICAgICAgICB0aGlzLmRvZXNDcmVhdGVDaXJjdWxhclJlbGF0aW9uKHRoaXMubm9kZXMsIHRoaXMuZWRnZXMsIHtcbiAgICAgICAgICAgICAgICAgICAgc291cmNlOiB0aGlzLnRhaWxDb21wZXRlbmN5ISArICcnLFxuICAgICAgICAgICAgICAgICAgICB0YXJnZXQ6IHRoaXMuaGVhZENvbXBldGVuY3khICsgJycsXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiB0aGlzLnJlbGF0aW9uVHlwZSEsXG4gICAgICAgICAgICAgICAgfSBhcyBFZGdlKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgZG9lc1JlbGF0aW9uQWxyZWFkeUV4aXN0KCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5lZGdlcy5maW5kKChlZGdlKSA9PiBlZGdlLnNvdXJjZSA9PT0gdGhpcy50YWlsQ29tcGV0ZW5jeT8udG9TdHJpbmcoKSAmJiBlZGdlLnRhcmdldCA9PT0gdGhpcy5oZWFkQ29tcGV0ZW5jeT8udG9TdHJpbmcoKSkgIT09IHVuZGVmaW5lZDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVja3MgaWYgYWRkaW5nIGFuIGVkZ2Ugd291bGQgY3JlYXRlIGEgY2lyY3VsYXIgcmVsYXRpb25cbiAgICAgKiBAcGFyYW0gICB7Tm9kZVtdfSBub2RlcyBhbiBhcnJheSBvZiBhbGwgZXhpc3Rpbmcgbm9kZXMgb2YgYSBncmFwaFxuICAgICAqIEBwYXJhbSAgIHtFZGdlW119IGVkZ2VzIGFuIGFycmF5IG9mIGFsbCBleGlzdGluZyBlZGdlcyBvZiBhIGdyYXBoXG4gICAgICogQHBhcmFtICAge0VkZ2V9IGVkZ2VUb0FkZCB0aGUgZWRnZSB0aGF0IHlvdSB0cnkgdG8gYWRkIHRvIHRoZSBncmFwaFxuICAgICAqXG4gICAgICogQHJldHVybnMge2Jvb2xlYW59IHdoZXRoZXIgb3Igbm90IGFkZGluZyB0aGUgcHJvdmlkZWQgZWRnZSB3b3VsZCByZXN1bHQgaW4gYSBjaXJjbGUgaW4gdGhlIGdyYXBoXG4gICAgICovXG4gICAgcHJpdmF0ZSBkb2VzQ3JlYXRlQ2lyY3VsYXJSZWxhdGlvbihub2RlczogTm9kZVtdLCBlZGdlczogRWRnZVtdLCBlZGdlVG9BZGQ6IEVkZ2UpOiBib29sZWFuIHtcbiAgICAgICAgY29uc3QgZWRnZXNXaXRoTmV3RWRnZSA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoZWRnZXMpKTtcbiAgICAgICAgZWRnZXNXaXRoTmV3RWRnZS5wdXNoKGVkZ2VUb0FkZCk7XG4gICAgICAgIGNvbnN0IGdyYXBoID0gbmV3IEdyYXBoKCk7XG4gICAgICAgIGZvciAoY29uc3Qgbm9kZSBvZiBub2Rlcykge1xuICAgICAgICAgICAgZ3JhcGguYWRkVmVydGV4KG5ldyBWZXJ0ZXgobm9kZS5pZCkpO1xuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgZWRnZSBvZiBlZGdlc1dpdGhOZXdFZGdlKSB7XG4gICAgICAgICAgICBjb25zdCBoZWFkVmVydGV4ID0gZ3JhcGgudmVydGljZXMuZmluZCgodmVydGV4OiBWZXJ0ZXgpID0+IHZlcnRleC5nZXRMYWJlbCgpID09PSBlZGdlLnRhcmdldCk7XG4gICAgICAgICAgICBjb25zdCB0YWlsVmVydGV4ID0gZ3JhcGgudmVydGljZXMuZmluZCgodmVydGV4OiBWZXJ0ZXgpID0+IHZlcnRleC5nZXRMYWJlbCgpID09PSBlZGdlLnNvdXJjZSk7XG4gICAgICAgICAgICBpZiAoaGVhZFZlcnRleCA9PT0gdW5kZWZpbmVkIHx8IHRhaWxWZXJ0ZXggPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0V2ZXJ5IGVkZ2UgbmVlZHMgYSBzb3VyY2Ugb3IgYSB0YXJnZXQuJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBvbmx5IGV4dGVuZHMgYW5kIGFzc3VtZXMgcmVsYXRpb25zIGFyZSBjb25zaWRlcmVkIHdoZW4gY2hlY2tpbmcgZm9yIGNpcmNsZXMgYmVjYXVzZSBvbmx5IHRoZXkgZG9uJ3QgbWFrZSBzZW5zZVxuICAgICAgICAgICAgLy8gTUFUQ0hFUyByZWxhdGlvbnMgYXJlIGNvbnNpZGVyZWQgaW4gdGhlIG5leHQgc3RlcCBieSBtZXJnaW5nIHRoZSBlZGdlcyBhbmQgY29tYmluaW5nIHRoZSBhZGphY2VuY3lMaXN0c1xuICAgICAgICAgICAgc3dpdGNoIChlZGdlLmxhYmVsKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAnRVhURU5EUyc6XG4gICAgICAgICAgICAgICAgY2FzZSAnQVNTVU1FUyc6IHtcbiAgICAgICAgICAgICAgICAgICAgZ3JhcGguYWRkRWRnZSh0YWlsVmVydGV4LCBoZWFkVmVydGV4KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIGNvbWJpbmUgdmVydGljZXMgdGhhdCBhcmUgY29ubmVjdGVkIHRocm91Z2ggTUFUQ0hFU1xuICAgICAgICBmb3IgKGNvbnN0IGVkZ2Ugb2YgZWRnZXNXaXRoTmV3RWRnZSkge1xuICAgICAgICAgICAgaWYgKGVkZ2UubGFiZWwgPT09ICdNQVRDSEVTJykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGhlYWRWZXJ0ZXggPSBncmFwaC52ZXJ0aWNlcy5maW5kKCh2ZXJ0ZXg6IFZlcnRleCkgPT4gdmVydGV4LmdldExhYmVsKCkgPT09IGVkZ2UudGFyZ2V0KTtcbiAgICAgICAgICAgICAgICBjb25zdCB0YWlsVmVydGV4ID0gZ3JhcGgudmVydGljZXMuZmluZCgodmVydGV4OiBWZXJ0ZXgpID0+IHZlcnRleC5nZXRMYWJlbCgpID09PSBlZGdlLnNvdXJjZSk7XG4gICAgICAgICAgICAgICAgaWYgKGhlYWRWZXJ0ZXggPT09IHVuZGVmaW5lZCB8fCB0YWlsVmVydGV4ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignRXZlcnkgZWRnZSBuZWVkcyBhIHNvdXJjZSBvciBhIHRhcmdldC4nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGhlYWRWZXJ0ZXguZ2V0QWRqYWNlbmN5TGlzdCgpLmluY2x1ZGVzKHRhaWxWZXJ0ZXgpIHx8IHRhaWxWZXJ0ZXguZ2V0QWRqYWNlbmN5TGlzdCgpLmluY2x1ZGVzKGhlYWRWZXJ0ZXgpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBjcmVhdGUgYSBtZXJnZWQgdmVydGV4XG4gICAgICAgICAgICAgICAgY29uc3QgbWVyZ2VkVmVydGV4ID0gbmV3IFZlcnRleCh0YWlsVmVydGV4LmdldExhYmVsKCkgKyAnLCAnICsgaGVhZFZlcnRleC5nZXRMYWJlbCgpKTtcbiAgICAgICAgICAgICAgICAvLyBhZGQgYWxsIG5laWdoYm91cnMgdG8gbWVyZ2VkIHZlcnRleFxuICAgICAgICAgICAgICAgIG1lcmdlZFZlcnRleC5nZXRBZGphY2VuY3lMaXN0KCkucHVzaCguLi5oZWFkVmVydGV4LmdldEFkamFjZW5jeUxpc3QoKSk7XG4gICAgICAgICAgICAgICAgbWVyZ2VkVmVydGV4LmdldEFkamFjZW5jeUxpc3QoKS5wdXNoKC4uLnRhaWxWZXJ0ZXguZ2V0QWRqYWNlbmN5TGlzdCgpKTtcbiAgICAgICAgICAgICAgICAvLyB1cGRhdGUgZXZlcnkgdmVydGV4IHRoYXQgaW5pdGlhbGx5IGhhZCBvbmUgb2YgdGhlIHR3byBtZXJnZWQgdmVydGljZXMgYXMgbmVpZ2hib3VycyB0byBub3cgcmVmZXJlbmNlIHRoZSBtZXJnZWQgdmVydGV4XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCB2ZXJ0ZXggb2YgZ3JhcGgudmVydGljZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBhZGphY2VudFZlcnRleCBvZiB2ZXJ0ZXguZ2V0QWRqYWNlbmN5TGlzdCgpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYWRqYWNlbnRWZXJ0ZXguZ2V0TGFiZWwoKSA9PT0gaGVhZFZlcnRleC5nZXRMYWJlbCgpIHx8IGFkamFjZW50VmVydGV4LmdldExhYmVsKCkgPT09IHRhaWxWZXJ0ZXguZ2V0TGFiZWwoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gdmVydGV4LmdldEFkamFjZW5jeUxpc3QoKS5pbmRleE9mKGFkamFjZW50VmVydGV4LCAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaW5kZXggPiAtMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2ZXJ0ZXguZ2V0QWRqYWNlbmN5TGlzdCgpLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZlcnRleC5nZXRBZGphY2VuY3lMaXN0KCkucHVzaChtZXJnZWRWZXJ0ZXgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBncmFwaC5oYXNDeWNsZSgpO1xuICAgIH1cbn1cblxuLyoqXG4gKiBBIGNsYXNzIHRoYXQgcmVwcmVzZW50cyBhIHZlcnRleCBpbiBhIGdyYXBoXG4gKiBAY2xhc3NcbiAqXG4gKiBAY29uc3RydWN0b3JcbiAqXG4gKiBAcHJvcGVydHkgbGFiZWwgICAgICAgICAgYSBsYWJlbCB0byBpZGVudGlmeSB0aGUgdmVydGV4ICh3ZSB1c2UgdGhlIG5vZGUgaWQpXG4gKiBAcHJvcGVydHkgYmVpbmdWaXNpdGVkICAgaXMgdGhlIHZlcnRleCB0aGUgb25lIHRoYXQgaXMgY3VycmVudGx5IGJlaW5nIHZpc2l0ZWQgZHVyaW5nIHRoZSBncmFwaCB0cmF2ZXJzYWxcbiAqIEBwcm9wZXJ0eSB2aXNpdGVkICAgICAgICBoYXMgdGhpcyB2ZXJ0ZXggYmVlbiB2aXNpdGVkIGJlZm9yZVxuICogQHByb3BlcnR5IGFkamFjZW5jeUxpc3QgIGFuIGFycmF5IHRoYXQgY29udGFpbnMgYWxsIGFkamFjZW50IHZlcnRpY2VzXG4gKi9cbmV4cG9ydCBjbGFzcyBWZXJ0ZXgge1xuICAgIHByaXZhdGUgcmVhZG9ubHkgbGFiZWw6IHN0cmluZztcbiAgICBwcml2YXRlIGJlaW5nVmlzaXRlZDogYm9vbGVhbjtcbiAgICBwcml2YXRlIHZpc2l0ZWQ6IGJvb2xlYW47XG4gICAgcHJpdmF0ZSByZWFkb25seSBhZGphY2VuY3lMaXN0OiBWZXJ0ZXhbXTtcblxuICAgIGNvbnN0cnVjdG9yKGxhYmVsOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5sYWJlbCA9IGxhYmVsO1xuICAgICAgICB0aGlzLmFkamFjZW5jeUxpc3QgPSBbXTtcbiAgICB9XG5cbiAgICBnZXRMYWJlbCgpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5sYWJlbDtcbiAgICB9XG5cbiAgICBhZGROZWlnaGJvcihhZGphY2VudDogVmVydGV4KTogdm9pZCB7XG4gICAgICAgIHRoaXMuYWRqYWNlbmN5TGlzdC5wdXNoKGFkamFjZW50KTtcbiAgICB9XG5cbiAgICBnZXRBZGphY2VuY3lMaXN0KCk6IFZlcnRleFtdIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuYWRqYWNlbmN5TGlzdDtcbiAgICB9XG5cbiAgICBpc0JlaW5nVmlzaXRlZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuYmVpbmdWaXNpdGVkO1xuICAgIH1cblxuICAgIHNldEJlaW5nVmlzaXRlZChiZWluZ1Zpc2l0ZWQ6IGJvb2xlYW4pOiB2b2lkIHtcbiAgICAgICAgdGhpcy5iZWluZ1Zpc2l0ZWQgPSBiZWluZ1Zpc2l0ZWQ7XG4gICAgfVxuXG4gICAgaXNWaXNpdGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy52aXNpdGVkO1xuICAgIH1cblxuICAgIHNldFZpc2l0ZWQodmlzaXRlZDogYm9vbGVhbikge1xuICAgICAgICB0aGlzLnZpc2l0ZWQgPSB2aXNpdGVkO1xuICAgIH1cbn1cblxuLyoqXG4gKiBBIGNsYXNzIHRoYXQgcmVwcmVzZW50cyBhIGdyYXBoXG4gKiBAY2xhc3NcbiAqXG4gKiBAY29uc3RydWN0b3JcbiAqXG4gKiBAcHJvcGVydHkgdmVydGljZXMgICBhbiBhcnJheSBvZiBhbGwgdmVydGljZXMgaW4gdGhlIGdyYXBoIChlZGdlcyBhcmUgcmVwcmVzZW50ZWQgYnkgdGhlIGFkamFjZW50IHZlcnRpY2VzIHByb3BlcnR5IG9mIGVhY2ggdmVydGV4KVxuICovXG5leHBvcnQgY2xhc3MgR3JhcGgge1xuICAgIHZlcnRpY2VzOiBWZXJ0ZXhbXTtcblxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLnZlcnRpY2VzID0gW107XG4gICAgfVxuXG4gICAgcHVibGljIGFkZFZlcnRleCh2ZXJ0ZXg6IFZlcnRleCk6IHZvaWQge1xuICAgICAgICB0aGlzLnZlcnRpY2VzLnB1c2godmVydGV4KTtcbiAgICB9XG5cbiAgICBwdWJsaWMgYWRkRWRnZShmcm9tOiBWZXJ0ZXgsIHRvOiBWZXJ0ZXgpOiB2b2lkIHtcbiAgICAgICAgZnJvbS5hZGROZWlnaGJvcih0byk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2tzIGlmIHRoZSBncmFwaCBjb250YWlucyBhIGNpcmNsZVxuICAgICAqXG4gICAgICogQHJldHVybnMge2Jvb2xlYW59IHdoZXRoZXIgb3Igbm90IHRoZSBncmFwaCBjb250YWlucyBhIGNpcmNsZVxuICAgICAqL1xuICAgIHB1YmxpYyBoYXNDeWNsZSgpOiBib29sZWFuIHtcbiAgICAgICAgLy8gd2UgaGF2ZSB0byBjaGVjayBmb3IgZXZlcnkgdmVydGV4IGlmIGl0IGlzIHBhcnQgb2YgYSBjeWNsZSBpbiBjYXNlIHRoZSBncmFwaCBpcyBub3QgY29ubmVjdGVkXG4gICAgICAgIGZvciAoY29uc3QgdmVydGV4IG9mIHRoaXMudmVydGljZXMpIHtcbiAgICAgICAgICAgIGlmICghdmVydGV4LmlzVmlzaXRlZCgpICYmIHRoaXMudmVydGV4SGFzQ3ljbGUodmVydGV4KSkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVja3MgaWYgYSB2ZXJ0ZXggaXMgcGFydCBvZiBhIGNpcmNsZVxuICAgICAqXG4gICAgICogQHJldHVybnMge2Jvb2xlYW59IHdoZXRoZXIgb3Igbm90IHRoZSB2ZXJ0ZXggaXMgcGFydCBvZiBhIGNpcmNsZVxuICAgICAqL1xuICAgIHByaXZhdGUgdmVydGV4SGFzQ3ljbGUoc291cmNlVmVydGV4OiBWZXJ0ZXgpOiBib29sZWFuIHtcbiAgICAgICAgc291cmNlVmVydGV4LnNldEJlaW5nVmlzaXRlZCh0cnVlKTtcblxuICAgICAgICBmb3IgKGNvbnN0IG5laWdoYm9yIG9mIHNvdXJjZVZlcnRleC5nZXRBZGphY2VuY3lMaXN0KCkpIHtcbiAgICAgICAgICAgIGlmIChuZWlnaGJvci5pc0JlaW5nVmlzaXRlZCgpKSB7XG4gICAgICAgICAgICAgICAgLy8gYmFja3dhcmQgZWRnZSBleGlzdHNcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoIW5laWdoYm9yLmlzVmlzaXRlZCgpICYmIHRoaXMudmVydGV4SGFzQ3ljbGUobmVpZ2hib3IpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBzb3VyY2VWZXJ0ZXguc2V0QmVpbmdWaXNpdGVkKGZhbHNlKTtcbiAgICAgICAgc291cmNlVmVydGV4LnNldFZpc2l0ZWQodHJ1ZSk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG59XG4iLCJAaWYgKGlzTG9hZGluZykge1xuICAgIDxkaXYgY2xhc3M9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWNlbnRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3Bpbm5lci1ib3JkZXJcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInNyLW9ubHlcIj57eyAnbG9hZGluZycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbn1cbkBpZiAoIWlzTG9hZGluZykge1xuICAgIDxkaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXggZmxleC13cmFwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXktYXV0byBkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPGgyIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5tYW5hZ2VDb21wZXRlbmNpZXMudGl0bGVcIj5Db21wZXRlbmN5IE1hbmFnZW1lbnQ8L2gyPlxuICAgICAgICAgICAgICAgIDxqaGktZG9jdW1lbnRhdGlvbi1idXR0b24gW3R5cGVdPVwiZG9jdW1lbnRhdGlvblR5cGVcIj48L2poaS1kb2N1bWVudGF0aW9uLWJ1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1zLWF1dG8gdGV4dC10cnVuY2F0ZSBqdXN0aWZ5LWNvbnRlbnQtZW5kXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeVwiIGlkPVwiY29tcGV0ZW5jeUltcG9ydEJ1dHRvblwiIChjbGljayk9XCJvcGVuSW1wb3J0TW9kYWwoKVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVBsdXNcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kubWFuYWdlQ29tcGV0ZW5jaWVzLmltcG9ydCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5XCIgW3JvdXRlckxpbmtdPVwiWycvY291cnNlLW1hbmFnZW1lbnQnLCBjb3Vyc2VJZCwgJ2NvbXBldGVuY3ktbWFuYWdlbWVudCcsICdjcmVhdGUnXVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVBsdXNcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kubWFuYWdlQ29tcGV0ZW5jaWVzLmNyZWF0ZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNvbnRhaW5lciBteC0wIG10LTMgbWItMyBtdy0xMDBcIj5cbiAgICAgICAgICAgIDxkaXYgbmdiQWNjb3JkaW9uIFtjbG9zZU90aGVyc109XCJ0cnVlXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBuZ2JBY2NvcmRpb25JdGVtPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IG5nYkFjY29yZGlvbkhlYWRlcj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gbmdiQWNjb3JkaW9uQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kucmVsYXRpb24uY29tcGV0ZW5jeVJlbGF0aW9ucycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PHNwYW4gY2xhc3M9XCJiYWRnZSByb3VuZGVkLXBpbGwgdGV4dC1iZy13YXJuaW5nIG1zLTFcIj5CRVRBPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IG5nYkFjY29yZGlvbkNvbGxhcHNlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBuZ2JBY2NvcmRpb25Cb2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm0gY2xhc3M9XCJyb3cgcC0zIGctMyBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2xcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwidGFpbFwiPnt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kucmVsYXRpb24udGFpbENvbXBldGVuY3knIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ0NsYXNzXT1cInsgJ2JvcmRlci1kYW5nZXInOiByZWxhdGlvbkVycm9yICE9PSBjb21wZXRlbmN5UmVsYXRpb25FcnJvci5OT05FIH1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtLXNlbGVjdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInRhaWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRhaWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJ0YWlsQ29tcGV0ZW5jeVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2hhbmdlKT1cInZhbGlkYXRlKClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAZm9yIChjb21wZXRlbmN5IG9mIGNvbXBldGVuY2llczsgdHJhY2sgY29tcGV0ZW5jeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gW3ZhbHVlXT1cImNvbXBldGVuY3kuaWRcIj57eyBjb21wZXRlbmN5LnRpdGxlIH19PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cInR5cGVcIj57eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LnJlbGF0aW9uLnJlbGF0aW9uVHlwZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nQ2xhc3NdPVwieyAnYm9yZGVyLWRhbmdlcic6IHJlbGF0aW9uRXJyb3IgIT09IGNvbXBldGVuY3lSZWxhdGlvbkVycm9yLk5PTkUgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tc2VsZWN0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwidHlwZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidHlwZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbKG5nTW9kZWwpXT1cInJlbGF0aW9uVHlwZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2hhbmdlKT1cInZhbGlkYXRlKClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUkVMQVRFU1wiIHNlbGVjdGVkPnt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kucmVsYXRpb24ucmVsYXRlcycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQVNTVU1FU1wiPnt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kucmVsYXRpb24uYXNzdW1lcycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRVhURU5EU1wiPnt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kucmVsYXRpb24uZXh0ZW5kcycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTUFUQ0hFU1wiPnt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kucmVsYXRpb24ubWF0Y2hlcycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cImhlYWRcIj57eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LnJlbGF0aW9uLmhlYWRDb21wZXRlbmN5JyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbmdDbGFzc109XCJ7ICdib3JkZXItZGFuZ2VyJzogcmVsYXRpb25FcnJvciAhPT0gY29tcGV0ZW5jeVJlbGF0aW9uRXJyb3IuTk9ORSB9XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1zZWxlY3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJoZWFkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJoZWFkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFsobmdNb2RlbCldPVwiaGVhZENvbXBldGVuY3lcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKG5nTW9kZWxDaGFuZ2UpPVwidmFsaWRhdGUoKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKGNvbXBldGVuY3kgb2YgY29tcGV0ZW5jaWVzOyB0cmFjayBjb21wZXRlbmN5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBbdmFsdWVdPVwiY29tcGV0ZW5jeS5pZFwiPnt7IGNvbXBldGVuY3kudGl0bGUgfX08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT1cInt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kucmVsYXRpb24uY3JlYXRlUmVsYXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJjcmVhdGVSZWxhdGlvbigpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2Rpc2FibGVkXT1cIiFoZWFkQ29tcGV0ZW5jeSB8fCAhdGFpbENvbXBldGVuY3kgfHwgIXJlbGF0aW9uVHlwZSB8fCByZWxhdGlvbkVycm9yICE9PSBjb21wZXRlbmN5UmVsYXRpb25FcnJvci5OT05FXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAocmVsYXRpb25FcnJvciAhPT0gY29tcGV0ZW5jeVJlbGF0aW9uRXJyb3IuTk9ORSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJ7eyBnZXRFcnJvck1lc3NhZ2UocmVsYXRpb25FcnJvcikgfX1cIiBpZD1cInJlbGF0aW9uLW5vdC12YWxpZC10ZXh0XCIgY2xhc3M9XCJpbnZhbGlkLWZlZWRiYWNrXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBZb3UgY2FuIG5vdCBjcmVhdGUgdGhpcyByZWxhdGlvbi5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxuZ3gtZ3JhcGhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwibS0xIGNoYXJ0LWNvbnRhaW5lclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXlvdXQ9XCJkYWdyZUNsdXN0ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2VuYWJsZVpvb21dPVwiZmFsc2VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2RyYWdnaW5nRW5hYmxlZF09XCJmYWxzZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbm9kZXNdPVwibm9kZXNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2xpbmtzXT1cImVkZ2VzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbHVzdGVyc109XCJjbHVzdGVyc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdXBkYXRlJF09XCJ1cGRhdGUkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlICNkZWZzVGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZzptYXJrZXIgaWQ9XCJhcnJvd1wiIHZpZXdCb3g9XCIwIC01IDEwIDEwXCIgcmVmWD1cIjhcIiByZWZZPVwiMFwiIG1hcmtlcldpZHRoPVwiNFwiIG1hcmtlckhlaWdodD1cIjRcIiBvcmllbnQ9XCJhdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmc6cGF0aCBkPVwiTTAsLTVMMTAsMEwwLDVcIiBjbGFzcz1cImFycm93LWhlYWRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnOm1hcmtlcj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgI2NsdXN0ZXJUZW1wbGF0ZSBsZXQtY2x1c3Rlcj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnOmcgY2xhc3M9XCJub2RlIGNsdXN0ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZzpyZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByeD1cIjVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcnk9XCI1XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFthdHRyLndpZHRoXT1cImNsdXN0ZXIuZGltZW5zaW9uLndpZHRoXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFthdHRyLmhlaWdodF09XCJjbHVzdGVyLmRpbWVuc2lvbi5oZWlnaHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2F0dHIuZmlsbF09XCJjbHVzdGVyLmRhdGEuY29sb3JcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnOmc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlICNub2RlVGVtcGxhdGUgbGV0LW5vZGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZzpnIGNsYXNzPVwibm9kZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnOnJlY3QgW2F0dHIud2lkdGhdPVwibm9kZS5kaW1lbnNpb24ud2lkdGhcIiBbYXR0ci5oZWlnaHRdPVwibm9kZS5kaW1lbnNpb24uaGVpZ2h0XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2Zzp0ZXh0IGFsaWdubWVudC1iYXNlbGluZT1cImNlbnRyYWxcIiBbYXR0ci54XT1cIjEwXCIgW2F0dHIueV09XCJub2RlLmRpbWVuc2lvbi5oZWlnaHQgLyAyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBub2RlLmxhYmVsIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnOnRleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc6Zz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgI2xpbmtUZW1wbGF0ZSBsZXQtbGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnOmcgY2xhc3M9XCJlZGdlXCIgKGNsaWNrKT1cInJlbW92ZVJlbGF0aW9uKGxpbmspXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmc6cGF0aCBjbGFzcz1cImxpbmVcIiBzdHJva2Utd2lkdGg9XCIyXCIgbWFya2VyLWVuZD1cInVybCgjYXJyb3cpXCI+PC9zdmc6cGF0aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2Zzp0ZXh0IGNsYXNzPVwiZWRnZS1sYWJlbFwiIHRleHQtYW5jaG9yPVwibWlkZGxlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGV4dFBhdGggY2xhc3M9XCJ0ZXh0LXBhdGhcIiBbYXR0ci5ocmVmXT1cIicjJyArIGxpbmsuaWRcIiBbc3R5bGUuZG9taW5hbnQtYmFzZWxpbmVdPVwibGluay5kb21pbmFudEJhc2VsaW5lXCIgc3RhcnRPZmZzZXQ9XCI1MCVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAoJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5yZWxhdGlvbi4nICsgbGluay5sYWJlbC50b0xvd2VyQ2FzZSgpIHwgYXJ0ZW1pc1RyYW5zbGF0ZSkudG9VcHBlckNhc2UoKSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZXh0UGF0aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc6dGV4dD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2ZzpnPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9uZ3gtZ3JhcGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNvbnRhaW5lci1mbHVpZFwiIHN0eWxlPVwibWluLWhlaWdodDogMTAwcHhcIj5cbiAgICAgICAgICAgIEBpZiAoY29tcGV0ZW5jaWVzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlIHRhYmxlLXN0cmlwZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD48c3BhbiBqaGlUcmFuc2xhdGU9XCJnbG9iYWwuZmllbGQuaWRcIj5JRDwvc3Bhbj48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD48c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvbXBldGVuY3kudGl0bGVcIj5UaXRsZTwvc3Bhbj48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCB3aWR0aD1cIjMwMFwiPjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5kZXNjcmlwdGlvblwiPkRlc2NyaXB0aW9uPC9zcGFuPjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS50YXhvbm9teVwiPlRheG9ub215PC9zcGFuPjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5zb2Z0RHVlRGF0ZVwiPkR1ZSBEYXRlPC9zcGFuPjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzPVwiZC1ub25lIGQtbGctdGFibGUtY2VsbFwiPjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5tYXN0ZXJlZFN0dWRlbnRzXCI+TWFzdGVyZWQgU3R1ZGVudHM8L3NwYW4+PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+PHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb21wZXRlbmN5Lm9wdGlvbmFsXCI+T3B0aW9uYWw8L3NwYW4+PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKGNvbXBldGVuY3kgb2YgY29tcGV0ZW5jaWVzOyB0cmFjayBpZGVudGlmeShpLCBjb21wZXRlbmN5KTsgbGV0IGkgPSAkaW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIgaWQ9XCJjb21wZXRlbmN5LXJvdy17eyBpIH19XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIFtyb3V0ZXJMaW5rXT1cIlsnL2NvdXJzZXMnLCBjb3Vyc2VJZCwgJ2NvbXBldGVuY2llcycsIGNvbXBldGVuY3kuaWRdXCI+e3sgY29tcGV0ZW5jeS5pZCB9fTwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWycvY291cnNlcycsIGNvdXJzZUlkLCAnY29tcGV0ZW5jaWVzJywgY29tcGV0ZW5jeS5pZF1cIj57eyBjb21wZXRlbmN5LnRpdGxlIH19PC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgW2lubmVySFRNTF09XCJjb21wZXRlbmN5LmRlc2NyaXB0aW9uXCI+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjb21wZXRlbmN5LnRheG9ub215KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZ2V0SWNvbihjb21wZXRlbmN5LnRheG9ub215KVwiIFtmaXhlZFdpZHRoXT1cInRydWVcIiBjb250YWluZXI9XCJib2R5XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBnZXRJY29uVG9vbHRpcChjb21wZXRlbmN5LnRheG9ub215KSB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgY29tcGV0ZW5jeS5zb2Z0RHVlRGF0ZSB8IGFydGVtaXNEYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzcz1cImQtbm9uZSBkLWxnLXRhYmxlLWNlbGxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxuZ2ItcHJvZ3Jlc3NiYXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3Nob3dWYWx1ZV09XCJ0cnVlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdmFsdWVdPVwiY29tcGV0ZW5jeS5jb3Vyc2VQcm9ncmVzcz8ubnVtYmVyT2ZNYXN0ZXJlZFN0dWRlbnRzID8/IDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFttYXhdPVwiY29tcGV0ZW5jeS5jb3Vyc2VQcm9ncmVzcz8ubnVtYmVyT2ZTdHVkZW50cyA/PyAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L25nYi1wcm9ncmVzc2Jhcj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgJ2dsb2JhbC5nZW5lcmljLicgKyAoY29tcGV0ZW5jeS5vcHRpb25hbCA/ICd5ZXMnIDogJ25vJykgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJ0ZXh0LWVuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJidG4gYnRuLXNtIGJ0bi1wcmltYXJ5XCIgW3JvdXRlckxpbmtdPVwiWycvY291cnNlLW1hbmFnZW1lbnQnLCBjb3Vyc2VJZCwgJ2NvbXBldGVuY3ktbWFuYWdlbWVudCcsIGNvbXBldGVuY3kuaWQsICdlZGl0J11cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVBlbmNpbEFsdFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImQtbm9uZSBkLW1kLWlubGluZVwiPnt7ICdlbnRpdHkuYWN0aW9uLmVkaXQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqaGlEZWxldGVCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbZW50aXR5VGl0bGVdPVwiY29tcGV0ZW5jeS50aXRsZSB8fCAnJ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2RlbGV0ZVF1ZXN0aW9uXT1cIidhcnRlbWlzQXBwLmNvbXBldGVuY3kuY29tcGV0ZW5jeUNhcmQuZGVsZXRlLnF1ZXN0aW9uJ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2RlbGV0ZUNvbmZpcm1hdGlvblRleHRdPVwiJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5jb21wZXRlbmN5Q2FyZC5kZWxldGUudHlwZU5hbWVUb0NvbmZpcm0nXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZGVsZXRlKT1cImRlbGV0ZUNvbXBldGVuY3koY29tcGV0ZW5jeS5pZCEpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbZGlhbG9nRXJyb3JdPVwiZGlhbG9nRXJyb3IkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVRyYXNoXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgIDxoMiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvbXBldGVuY3kucHJlcmVxdWlzaXRlLm1hbmFnZVByZXJlcXVpc2l0ZXMudGl0bGVcIj5QcmVyZXF1aXNpdGUgTWFuYWdlbWVudDwvaDI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibXMtYXV0byB0ZXh0LXRydW5jYXRlIGp1c3RpZnktY29udGVudC1lbmRcIj5cbiAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImJ0biBidG4tcHJpbWFyeVwiIChjbGljayk9XCJvcGVuUHJlcmVxdWlzaXRlU2VsZWN0aW9uTW9kYWwoKVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVBsdXNcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kucHJlcmVxdWlzaXRlLm1hbmFnZVByZXJlcXVpc2l0ZXMuc2VsZWN0JyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiY29udGFpbmVyLWZsdWlkXCIgc3R5bGU9XCJtaW4taGVpZ2h0OiAxMDBweFwiPlxuICAgICAgICAgICAgQGlmIChwcmVyZXF1aXNpdGVzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlIHRhYmxlLXN0cmlwZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD48c3BhbiBqaGlUcmFuc2xhdGU9XCJnbG9iYWwuZmllbGQuaWRcIj5JRDwvc3Bhbj48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD48c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvbXBldGVuY3kudGl0bGVcIj5UaXRsZTwvc3Bhbj48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCB3aWR0aD1cIjMwMFwiPjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5kZXNjcmlwdGlvblwiPkRlc2NyaXB0aW9uPC9zcGFuPjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS50YXhvbm9teVwiPlRheG9ub215PC9zcGFuPjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5jb3Vyc2VcIj5Db3Vyc2U8L3NwYW4+PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKHByZXJlcXVpc2l0ZSBvZiBwcmVyZXF1aXNpdGVzOyB0cmFjayBpZGVudGlmeShpLCBwcmVyZXF1aXNpdGUpOyBsZXQgaSA9ICRpbmRleCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBpZD1cImNvbXBldGVuY3ktcm93LXt7IGkgfX1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgcHJlcmVxdWlzaXRlLmlkIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IHByZXJlcXVpc2l0ZS50aXRsZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgW2lubmVySFRNTF09XCJwcmVyZXF1aXNpdGUuZGVzY3JpcHRpb25cIj48L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHByZXJlcXVpc2l0ZS50YXhvbm9teSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImdldEljb24ocHJlcmVxdWlzaXRlLnRheG9ub215KVwiIFtmaXhlZFdpZHRoXT1cInRydWVcIiBjb250YWluZXI9XCJib2R5XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBnZXRJY29uVG9vbHRpcChwcmVyZXF1aXNpdGUudGF4b25vbXkpIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHByZXJlcXVpc2l0ZS5jb3Vyc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBbcm91dGVyTGlua109XCJbJy9jb3Vyc2UtbWFuYWdlbWVudCcsIHByZXJlcXVpc2l0ZS5jb3Vyc2UhLmlkLCAnY29tcGV0ZW5jeS1tYW5hZ2VtZW50J11cIj57eyBwcmVyZXF1aXNpdGUuY291cnNlIS50aXRsZSB9fTwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPVwidGV4dC1lbmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJyZW1vdmVCdXR0b25cIiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIChjbGljayk9XCJyZW1vdmVQcmVyZXF1aXNpdGUocHJlcmVxdWlzaXRlLmlkISlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVRyYXNoXCI+PC9mYS1pY29uPiB7eyAnYXJ0ZW1pc0FwcC5jb21wZXRlbmN5LmNvbXBldGVuY3lDYXJkLnJlbW92ZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1jb21wZXRlbmN5LXJpbmdzJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vY29tcGV0ZW5jeS1yaW5ncy5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vY29tcGV0ZW5jeS1yaW5ncy5jb21wb25lbnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBDb21wZXRlbmN5UmluZ3NDb21wb25lbnQge1xuICAgIEBJbnB1dCgpIHByb2dyZXNzID0gMDtcbiAgICBASW5wdXQoKSBjb25maWRlbmNlID0gMDtcbiAgICBASW5wdXQoKSBtYXN0ZXJ5ID0gMDtcbiAgICBASW5wdXQoKSBoaWRlVG9vbHRpcCA9IGZhbHNlO1xuXG4gICAgZ2V0IHByb2dyZXNzUGVyY2VudGFnZSgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5wZXJjZW50YWdlUmFuZ2UodGhpcy5wcm9ncmVzcyk7XG4gICAgfVxuXG4gICAgZ2V0IGNvbmZpZGVuY2VQZXJjZW50YWdlKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLnBlcmNlbnRhZ2VSYW5nZSh0aGlzLmNvbmZpZGVuY2UpO1xuICAgIH1cblxuICAgIGdldCBtYXN0ZXJ5UGVyY2VudGFnZSgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5wZXJjZW50YWdlUmFuZ2UodGhpcy5tYXN0ZXJ5KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXN0cmljdCB0aGUgdmFsdWUgdG8gdGhlIHBlcmNlbnRhZ2UgcmFuZ2UgKGJldHdlZW4gMCBhbmQgMTAwKVxuICAgICAqIEBwYXJhbSB2YWx1ZVxuICAgICAqL1xuICAgIHBlcmNlbnRhZ2VSYW5nZSh2YWx1ZTogbnVtYmVyKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIE1hdGgubWluKE1hdGgubWF4KHZhbHVlLCAwKSwgMTAwKTtcbiAgICB9XG59XG4iLCI8IS0tIEFkYXB0ZWQgZnJvbSBodHRwczovL3d3dy5jaGlsaXRpbWUuZGVzaWduLzIwMTgvMDkvQWN0aXZpdHlSaW5ncy8gLS0+XG48c3ZnIHZpZXdCb3g9XCIwIDAgMzUgMzVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgW25nYlRvb2x0aXBdPVwiaGlkZVRvb2x0aXAgPyB1bmRlZmluZWQgOiAoJ2FydGVtaXNBcHAuY29tcGV0ZW5jeS5jb21wZXRlbmN5Q2FyZC5yaW5nc1Rvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSlcIj5cbiAgICA8ZyBjbGFzcz1cInJpbmcgcmluZzFcIj5cbiAgICAgICAgPGNpcmNsZSBjbGFzcz1cImJhY2tncm91bmRcIiBjeD1cIjUwJVwiIGN5PVwiNTAlXCIgcj1cIjE1LjkxNVwiIHN0cm9rZS13aWR0aD1cIjNcIj48L2NpcmNsZT5cbiAgICAgICAgPGNpcmNsZVxuICAgICAgICAgICAgY2xhc3M9XCJwcm9ncmVzc2JhclwiXG4gICAgICAgICAgICBjeD1cIjUwJVwiXG4gICAgICAgICAgICBjeT1cIjUwJVwiXG4gICAgICAgICAgICByPVwiMTUuOTE1XCJcbiAgICAgICAgICAgIHN0cm9rZS13aWR0aD1cIjNcIlxuICAgICAgICAgICAgW3N0eWxlLm9wYWNpdHldPVwibWFzdGVyeVBlcmNlbnRhZ2UgPT09IDAgPyAwIDogMVwiXG4gICAgICAgICAgICBbYXR0ci5zdHJva2UtZGFzaGFycmF5XT1cIm1hc3RlcnlQZXJjZW50YWdlICsgJywgMTAwJ1wiXG4gICAgICAgID48L2NpcmNsZT5cbiAgICA8L2c+XG5cbiAgICA8ZyBjbGFzcz1cInJpbmcgcmluZzJcIj5cbiAgICAgICAgPGNpcmNsZSBjbGFzcz1cImJhY2tncm91bmRcIiBjeD1cIjUwJVwiIGN5PVwiNTAlXCIgcj1cIjE1LjkxNVwiIHN0cm9rZS13aWR0aD1cIjRcIj48L2NpcmNsZT5cbiAgICAgICAgPGNpcmNsZVxuICAgICAgICAgICAgY2xhc3M9XCJwcm9ncmVzc2JhclwiXG4gICAgICAgICAgICBjeD1cIjUwJVwiXG4gICAgICAgICAgICBjeT1cIjUwJVwiXG4gICAgICAgICAgICByPVwiMTUuOTE1XCJcbiAgICAgICAgICAgIHN0cm9rZS13aWR0aD1cIjRcIlxuICAgICAgICAgICAgW3N0eWxlLm9wYWNpdHldPVwiY29uZmlkZW5jZVBlcmNlbnRhZ2UgPT09IDAgPyAwIDogMVwiXG4gICAgICAgICAgICBbYXR0ci5zdHJva2UtZGFzaGFycmF5XT1cImNvbmZpZGVuY2VQZXJjZW50YWdlICsgJywgMTAwJ1wiXG4gICAgICAgID48L2NpcmNsZT5cbiAgICA8L2c+XG5cbiAgICA8ZyBjbGFzcz1cInJpbmcgcmluZzNcIj5cbiAgICAgICAgPGNpcmNsZSBjbGFzcz1cImJhY2tncm91bmRcIiBjeD1cIjUwJVwiIGN5PVwiNTAlXCIgcj1cIjE1LjkxNVwiIHN0cm9rZS13aWR0aD1cIjZcIj48L2NpcmNsZT5cbiAgICAgICAgPGNpcmNsZVxuICAgICAgICAgICAgY2xhc3M9XCJwcm9ncmVzc2JhclwiXG4gICAgICAgICAgICBjeD1cIjUwJVwiXG4gICAgICAgICAgICBjeT1cIjUwJVwiXG4gICAgICAgICAgICByPVwiMTUuOTE1XCJcbiAgICAgICAgICAgIHN0cm9rZS13aWR0aD1cIjZcIlxuICAgICAgICAgICAgW3N0eWxlLm9wYWNpdHldPVwicHJvZ3Jlc3NQZXJjZW50YWdlID09PSAwID8gMCA6IDFcIlxuICAgICAgICAgICAgW2F0dHIuc3Ryb2tlLWRhc2hhcnJheV09XCJwcm9ncmVzc1BlcmNlbnRhZ2UgKyAnLCAxMDAnXCJcbiAgICAgICAgPjwvY2lyY2xlPlxuICAgIDwvZz5cbjwvc3ZnPlxuIiwiaW1wb3J0IGRheWpzIGZyb20gJ2RheWpzL2VzbSc7XG5pbXBvcnQgeyBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBUcmFuc2xhdGVTZXJ2aWNlIH0gZnJvbSAnQG5neC10cmFuc2xhdGUvY29yZSc7XG5pbXBvcnQgeyBDb21wZXRlbmN5LCBDb21wZXRlbmN5UHJvZ3Jlc3MsIGdldEljb24sIGdldEljb25Ub29sdGlwIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvbXBldGVuY3kubW9kZWwnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1jb21wZXRlbmN5LWNhcmQnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9jb21wZXRlbmN5LWNhcmQuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuLi8uLi8uLi9vdmVydmlldy9jb3Vyc2UtZXhlcmNpc2VzL2NvdXJzZS1leGVyY2lzZS1yb3cuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBDb21wZXRlbmN5Q2FyZENvbXBvbmVudCB7XG4gICAgQElucHV0KClcbiAgICBjb3Vyc2VJZD86IG51bWJlcjtcbiAgICBASW5wdXQoKVxuICAgIGNvbXBldGVuY3k6IENvbXBldGVuY3k7XG4gICAgQElucHV0KClcbiAgICBpc1ByZXJlcXVpc2l0ZTogYm9vbGVhbjtcblxuICAgIGdldEljb24gPSBnZXRJY29uO1xuICAgIGdldEljb25Ub29sdGlwID0gZ2V0SWNvblRvb2x0aXA7XG5cbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgdHJhbnNsYXRlU2VydmljZTogVHJhbnNsYXRlU2VydmljZSkge31cblxuICAgIGdldFVzZXJQcm9ncmVzcygpOiBDb21wZXRlbmN5UHJvZ3Jlc3Mge1xuICAgICAgICBpZiAodGhpcy5jb21wZXRlbmN5LnVzZXJQcm9ncmVzcz8ubGVuZ3RoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb21wZXRlbmN5LnVzZXJQcm9ncmVzcy5maXJzdCgpITtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4geyBwcm9ncmVzczogMCwgY29uZmlkZW5jZTogMCB9IGFzIENvbXBldGVuY3lQcm9ncmVzcztcbiAgICB9XG5cbiAgICBnZXQgcHJvZ3Jlc3MoKTogbnVtYmVyIHtcbiAgICAgICAgLy8gVGhlIHBlcmNlbnRhZ2Ugb2YgY29tcGxldGVkIGxlY3R1cmUgdW5pdHMgYW5kIHBhcnRpY2lwYXRlZCBleGVyY2lzZXNcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0VXNlclByb2dyZXNzKCkucHJvZ3Jlc3MgPz8gMDtcbiAgICB9XG5cbiAgICBnZXQgY29uZmlkZW5jZSgpOiBudW1iZXIge1xuICAgICAgICAvLyBDb25maWRlbmNlIGxldmVsIChhdmVyYWdlIHNjb3JlIGluIGV4ZXJjaXNlcykgaW4gcHJvcG9ydGlvbiB0byB0aGUgdGhyZXNob2xkIHZhbHVlIChtYXguIDEwMCAlKVxuICAgICAgICAvLyBFeGFtcGxlOiBJZiB0aGUgc3R1ZGVudOKAmXMgbGF0ZXN0IGNvbmZpZGVuY2UgbGV2ZWwgZXF1YWxzIDYwICUgYW5kIHRoZSBtYXN0ZXJ5IHRocmVzaG9sZCBpcyBzZXQgdG8gODAgJSwgdGhlIHJpbmcgd291bGQgYmUgNzUgJSBmdWxsLlxuICAgICAgICByZXR1cm4gTWF0aC5taW4oTWF0aC5yb3VuZCgoKHRoaXMuZ2V0VXNlclByb2dyZXNzKCkuY29uZmlkZW5jZSA/PyAwKSAvICh0aGlzLmNvbXBldGVuY3kubWFzdGVyeVRocmVzaG9sZCA/PyAxMDApKSAqIDEwMCksIDEwMCk7XG4gICAgfVxuXG4gICAgZ2V0IG1hc3RlcnkoKTogbnVtYmVyIHtcbiAgICAgICAgLy8gQWR2YW5jZW1lbnQgdG93YXJkcyBtYXN0ZXJ5IGFzIGEgd2VpZ2h0ZWQgZnVuY3Rpb24gb2YgcHJvZ3Jlc3MgYW5kIGNvbmZpZGVuY2VcbiAgICAgICAgY29uc3Qgd2VpZ2h0ID0gMiAvIDM7XG4gICAgICAgIHJldHVybiBNYXRoLnJvdW5kKCgxIC0gd2VpZ2h0KSAqIHRoaXMucHJvZ3Jlc3MgKyB3ZWlnaHQgKiB0aGlzLmNvbmZpZGVuY2UpO1xuICAgIH1cblxuICAgIGdldCBpc01hc3RlcmVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5tYXN0ZXJ5ID49IDEwMDtcbiAgICB9XG5cbiAgICBnZXQgc29mdER1ZURhdGVQYXNzZWQoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiBkYXlqcygpLmlzQWZ0ZXIodGhpcy5jb21wZXRlbmN5LnNvZnREdWVEYXRlKTtcbiAgICB9XG59XG4iLCI8ZGl2XG4gICAgW2lkXT1cIidjb21wZXRlbmN5LWNhcmQtJyArIGNvbXBldGVuY3kuaWRcIlxuICAgIGNsYXNzPVwiY291cnNlLWV4ZXJjaXNlLXJvdyByb3cgYWxpZ24taXRlbXMtY2VudGVyIGp1c3RpZnktY29udGVudC1iZXR3ZWVuIG1iLTIgbXQtMiBwb3NpdGlvbi1yZWxhdGl2ZVwiXG4gICAgW2NsYXNzLmJvcmRlci1zZWNvbmRhcnldPVwiaXNQcmVyZXF1aXNpdGVcIlxuICAgIFtjbGFzcy5ib3JkZXItc3VjY2Vzc109XCJpc01hc3RlcmVkXCJcbiAgICBbY2xhc3MudGV4dC1zZWNvbmRhcnldPVwiaXNNYXN0ZXJlZFwiXG4+XG4gICAgQGlmIChjb3Vyc2VJZCAmJiAhaXNQcmVyZXF1aXNpdGUpIHtcbiAgICAgICAgPGEgY2xhc3M9XCJzdHJldGNoZWQtbGlua1wiIFtyb3V0ZXJMaW5rXT1cIlsnL2NvdXJzZXMnLCBjb3Vyc2VJZCwgJ2NvbXBldGVuY2llcycsIGNvbXBldGVuY3kuaWQhXVwiPjwvYT5cbiAgICB9XG4gICAgPGRpdiBjbGFzcz1cImNvbC1hdXRvIGQtbm9uZSBkLXNtLWJsb2NrXCI+XG4gICAgICAgIDxhIGNsYXNzPVwiZXhlcmNpc2Utcm93LWljb25cIj5cbiAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImdldEljb24oY29tcGV0ZW5jeS50YXhvbm9teSlcIiBzaXplPVwiMnhcIiBbbmdiVG9vbHRpcF09XCJnZXRJY29uVG9vbHRpcChjb21wZXRlbmN5LnRheG9ub215KSB8IGFydGVtaXNUcmFuc2xhdGVcIiBjb250YWluZXI9XCJib2R5XCI+PC9mYS1pY29uPlxuICAgICAgICA8L2E+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImNvbFwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLWF1dG8gZC1zbS1ub25lXCI+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzPVwiZnctbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoY29tcGV0ZW5jeS50YXhvbm9teSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZ2V0SWNvbihjb21wZXRlbmN5LnRheG9ub215KVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtc20gY29sIHB5LTJcIj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3M9XCJtLTBcIj5cbiAgICAgICAgICAgICAgICAgICAge3sgY29tcGV0ZW5jeS50aXRsZSB9fVxuICAgICAgICAgICAgICAgICAgICBAaWYgKGlzTWFzdGVyZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgdGV4dC13aGl0ZSB0ZXh0LWJnLXN1Y2Nlc3NcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvbXBldGVuY3kubWFzdGVyZWRcIj5NYXN0ZXJlZDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKGNvbXBldGVuY3kub3B0aW9uYWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGlkPVwib3B0aW9uYWwtYmFkZ2VcIiBjbGFzcz1cImJhZGdlIHRleHQtd2hpdGUgYmctd2FybmluZ1wiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5vcHRpb25hbFwiPk9wdGlvbmFsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICBAaWYgKGNvbXBldGVuY3kuZGVzY3JpcHRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJtLTBcIiBbaW5uZXJIVE1MXT1cImNvbXBldGVuY3kuZGVzY3JpcHRpb25cIj48L3A+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoaXNQcmVyZXF1aXNpdGUgJiYgY29tcGV0ZW5jeS5jb3Vyc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctcHJpbWFyeVwiPnt7IGNvbXBldGVuY3kuY291cnNlLnRpdGxlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSBiZy1zZWNvbmRhcnlcIj57eyBjb21wZXRlbmN5LmNvdXJzZS5zZW1lc3RlciB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDxuZy1jb250ZW50PjwvbmctY29udGVudD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgQGlmICghaXNQcmVyZXF1aXNpdGUgJiYgY29tcGV0ZW5jeS5zb2Z0RHVlRGF0ZSkge1xuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtc20gY29sIHB5LTJcIiBzdHlsZT1cIm1heC13aWR0aDogZml0LWNvbnRlbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9XCJ2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlXCI+IHt7ICdhcnRlbWlzQXBwLmNvbXBldGVuY3kuY29tcGV0ZW5jeUNhcmQuc29mdER1ZURhdGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fSA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2VcIiBbbmdDbGFzc109XCJzb2Z0RHVlRGF0ZVBhc3NlZCAmJiAhaXNNYXN0ZXJlZCA/ICdiZy1kYW5nZXInIDogJ2JnLXN1Y2Nlc3MnXCIgaWQ9XCJkYXRlLWJhZGdlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7eyBjb21wZXRlbmN5LnNvZnREdWVEYXRlIHwgYXJ0ZW1pc1RpbWVBZ28gfX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmICghaXNQcmVyZXF1aXNpdGUpIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLXNtIGNvbCB0ZXh0LWVuZCBweS0xIHB4LTJcIiBzdHlsZT1cIm1heC13aWR0aDogOTVweFwiPlxuICAgICAgICAgICAgICAgICAgICA8amhpLWNvbXBldGVuY3ktcmluZ3MgW3Byb2dyZXNzXT1cInByb2dyZXNzXCIgW2NvbmZpZGVuY2VdPVwiY29uZmlkZW5jZVwiIFttYXN0ZXJ5XT1cIm1hc3RlcnlcIj48L2poaS1jb21wZXRlbmN5LXJpbmdzPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJvdXRlck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBDb21wZXRlbmN5Rm9ybUNvbXBvbmVudCB9IGZyb20gJy4vY29tcGV0ZW5jeS1mb3JtL2NvbXBldGVuY3ktZm9ybS5jb21wb25lbnQnO1xuaW1wb3J0IHsgQ3JlYXRlQ29tcGV0ZW5jeUNvbXBvbmVudCB9IGZyb20gJy4vY3JlYXRlLWNvbXBldGVuY3kvY3JlYXRlLWNvbXBldGVuY3kuY29tcG9uZW50JztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9zaGFyZWQtY29tcG9uZW50Lm1vZHVsZSc7XG5pbXBvcnQgeyBGb3Jtc01vZHVsZSwgUmVhY3RpdmVGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IEVkaXRDb21wZXRlbmN5Q29tcG9uZW50IH0gZnJvbSAnLi9lZGl0LWNvbXBldGVuY3kvZWRpdC1jb21wZXRlbmN5LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDb21wZXRlbmN5TWFuYWdlbWVudENvbXBvbmVudCB9IGZyb20gJy4vY29tcGV0ZW5jeS1tYW5hZ2VtZW50L2NvbXBldGVuY3ktbWFuYWdlbWVudC5jb21wb25lbnQnO1xuaW1wb3J0IHsgQ29tcGV0ZW5jeUNhcmRDb21wb25lbnQgfSBmcm9tICdhcHAvY291cnNlL2NvbXBldGVuY2llcy9jb21wZXRlbmN5LWNhcmQvY29tcGV0ZW5jeS1jYXJkLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDb21wZXRlbmNpZXNQb3BvdmVyQ29tcG9uZW50IH0gZnJvbSAnLi9jb21wZXRlbmNpZXMtcG9wb3Zlci9jb21wZXRlbmNpZXMtcG9wb3Zlci5jb21wb25lbnQnO1xuaW1wb3J0IHsgUHJlcmVxdWlzaXRlSW1wb3J0Q29tcG9uZW50IH0gZnJvbSAnYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jeS1tYW5hZ2VtZW50L3ByZXJlcXVpc2l0ZS1pbXBvcnQuY29tcG9uZW50JztcbmltcG9ydCB7IE5neEdyYXBoTW9kdWxlIH0gZnJvbSAnQHN3aW1sYW5lL25neC1ncmFwaCc7XG5pbXBvcnQgeyBDb21wZXRlbmN5UmluZ3NDb21wb25lbnQgfSBmcm9tICdhcHAvY291cnNlL2NvbXBldGVuY2llcy9jb21wZXRlbmN5LXJpbmdzL2NvbXBldGVuY3ktcmluZ3MuY29tcG9uZW50JztcbmltcG9ydCB7IENvbXBldGVuY3lJbXBvcnRDb21wb25lbnQgfSBmcm9tICdhcHAvY291cnNlL2NvbXBldGVuY2llcy9jb21wZXRlbmN5LW1hbmFnZW1lbnQvY29tcGV0ZW5jeS1pbXBvcnQuY29tcG9uZW50JztcbmltcG9ydCB7IEZvcm1EYXRlVGltZVBpY2tlck1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvZGF0ZS10aW1lLXBpY2tlci9kYXRlLXRpbWUtcGlja2VyLm1vZHVsZSc7XG5pbXBvcnQgeyBOZ2JBY2NvcmRpb25Nb2R1bGUgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW0FydGVtaXNTaGFyZWRNb2R1bGUsIEZvcm1zTW9kdWxlLCBSZWFjdGl2ZUZvcm1zTW9kdWxlLCBOZ3hHcmFwaE1vZHVsZSwgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSwgUm91dGVyTW9kdWxlLCBGb3JtRGF0ZVRpbWVQaWNrZXJNb2R1bGUsIE5nYkFjY29yZGlvbk1vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbXG4gICAgICAgIENvbXBldGVuY3lGb3JtQ29tcG9uZW50LFxuICAgICAgICBDb21wZXRlbmN5UmluZ3NDb21wb25lbnQsXG4gICAgICAgIENyZWF0ZUNvbXBldGVuY3lDb21wb25lbnQsXG4gICAgICAgIEVkaXRDb21wZXRlbmN5Q29tcG9uZW50LFxuICAgICAgICBDb21wZXRlbmN5TWFuYWdlbWVudENvbXBvbmVudCxcbiAgICAgICAgQ29tcGV0ZW5jeUNhcmRDb21wb25lbnQsXG4gICAgICAgIENvbXBldGVuY2llc1BvcG92ZXJDb21wb25lbnQsXG4gICAgICAgIFByZXJlcXVpc2l0ZUltcG9ydENvbXBvbmVudCxcbiAgICAgICAgQ29tcGV0ZW5jeUltcG9ydENvbXBvbmVudCxcbiAgICBdLFxuICAgIGV4cG9ydHM6IFtDb21wZXRlbmN5Q2FyZENvbXBvbmVudCwgQ29tcGV0ZW5jaWVzUG9wb3ZlckNvbXBvbmVudCwgQ29tcGV0ZW5jeUZvcm1Db21wb25lbnQsIENvbXBldGVuY3lSaW5nc0NvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNDb21wZXRlbmNpZXNNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsV0FBVyxPQUFlLHlCQUF5QjtBQUM1RCxTQUFTLGNBQWM7Ozs7Ozs7QUNBbkIsSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQStCLElBQUEsb0JBQUEsQ0FBQTs7QUFBd0YsSUFBQSwwQkFBQTs7O0FBQXhGLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsR0FBQSxHQUFBLCtEQUFBLENBQUE7Ozs7O0FBVWYsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUEwRCxJQUFBLG9CQUFBLENBQUE7QUFBc0IsSUFBQSwwQkFBQTtBQUNwRixJQUFBLG9CQUFBLEdBQUEsb0JBQUE7Ozs7O0FBRCtCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsY0FBQSxPQUFBLGVBQUE7QUFBK0IsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxjQUFBLEtBQUE7Ozs7O0FBTnRFLElBQUEsb0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQTtBQUNJLElBQUEsb0JBQUEsQ0FBQTs7QUFDSixJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSwwRUFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHNDQUFBO0FBR0osSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxRQUFBOzs7O0FBUlksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxzQkFBQSx5QkFBQSxHQUFBLEdBQUEscURBQUEsR0FBQSxnQkFBQTtBQUdBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsT0FBQSxZQUFBOzs7OztBQU1SLElBQUEsb0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUFrQyxJQUFBLG9CQUFBLENBQUE7O0FBQWlGLElBQUEsMEJBQUE7QUFDdkgsSUFBQSxvQkFBQSxHQUFBLFFBQUE7Ozs7QUFETyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGNBQUEsT0FBQSxlQUFBO0FBQStCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsR0FBQSxHQUFBLHdEQUFBLENBQUE7Ozs7O0FBWnRDLElBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLG1FQUFBLElBQUEsQ0FBQSxFQVdDLEdBQUEsbUVBQUEsR0FBQSxDQUFBOzs7O0FBWEQsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLE9BQUEsZ0JBQUEsT0FBQSxhQUFBLFNBQUEsSUFBQSxJQUFBLENBQUE7OztBREpKLElBVWE7QUFWYjs7O0FBVU0sSUFBTywrQkFBUCxNQUFPLDhCQUE0QjtNQUVyQztNQUVBLGVBQTZCLENBQUE7TUFFN0IsYUFBNEQ7TUFFNUQsa0JBQTRCLENBQUE7TUFHNUIsU0FBUztNQUVULGNBQUE7TUFBZTtNQUVmLFdBQVE7QUFDSixZQUFJLEtBQUssVUFBVTtBQUNmLGtCQUFRLEtBQUssWUFBWTtZQUNyQixLQUFLLHNCQUFzQjtBQUN2QixtQkFBSyxrQkFBa0IsQ0FBQyxZQUFZLEdBQUcsS0FBSyxRQUFRLElBQUksY0FBYztBQUN0RTs7WUFFSixLQUFLLHdCQUF3QjtBQUN6QixtQkFBSyxrQkFBa0IsQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLFFBQVEsSUFBSSx1QkFBdUI7QUFDekY7Ozs7TUFJaEI7O3lCQTVCUywrQkFBNEI7TUFBQTtnRUFBNUIsK0JBQTRCLFdBQUEsQ0FBQSxDQUFBLDBCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLGNBQUEsZ0JBQUEsWUFBQSxhQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxZQUFBLEVBQUEsR0FBQSxDQUFBLGNBQUEsRUFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLGdCQUFBLHNCQUFBLEdBQUEsT0FBQSxVQUFBLGVBQUEscUJBQUEsR0FBQSxjQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxzQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1Z6QyxVQUFBLHdCQUFBLEdBQUEscURBQUEsR0FBQSxHQUFBLGVBQUEsTUFBQSxHQUFBLG1DQUFBO0FBR0EsVUFBQSxvQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLHdCQUFBLEdBQUEscURBQUEsR0FBQSxHQUFBLGVBQUEsTUFBQSxHQUFBLG1DQUFBO0FBZ0JBLFVBQUEsb0JBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUNJLFVBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx1QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNKLFVBQUEsb0JBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsSUFBQSxJQUFBOzs7OztBQUh1RSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLHdCQUFBLGNBQUEsR0FBQSxFQUF5QixnQkFBQSxHQUFBO0FBQ25GLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsd0JBQUEsUUFBQSxJQUFBLE1BQUEsRUFBZSxjQUFBLElBQUE7Ozs7O29GRFZmLDhCQUE0QixFQUFBLFdBQUEsK0JBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFVnpDLFNBQVMsYUFBQUEsWUFBVyxjQUFjLFNBQUFDLFFBQTBCLGNBQWM7QUFDMUUsU0FBUyxhQUFxQyxrQkFBa0I7QUFFaEUsU0FBUyxPQUFPLFVBQVU7QUFDMUIsU0FBUyxZQUFZLE9BQU8sS0FBSyxpQkFBaUI7QUFHbEQsU0FBUyx3QkFBd0I7QUFFakMsU0FBUyxvQkFBb0I7QUFFN0IsU0FBUyxrQkFBa0IsZUFBZTs7Ozs7Ozs7O0FDTU4sSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTs7O0FBRlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSw4Q0FBQSwwQkFBQSxHQUFBLEdBQUEscUVBQUEsR0FBQSx3Q0FBQTs7Ozs7QUFJSixJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9DQUFBOzs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDhDQUFBLDBCQUFBLEdBQUEsR0FBQSxzRUFBQSxHQUFBLHdDQUFBOzs7OztBQUlKLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7OztBQUZRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsOENBQUEsMEJBQUEsR0FBQSxHQUFBLG1FQUFBLEdBQUEsd0NBQUE7Ozs7O0FBYlosSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwyRkFBQSxHQUFBLENBQUEsRUFJQyxHQUFBLDJGQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsMkZBQUEsR0FBQSxDQUFBO0FBV0wsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQWhCUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsUUFBQSxnQkFBQSxPQUFBLE9BQUEsUUFBQSxhQUFBLFVBQUEsT0FBQSxPQUFBLFFBQUEsYUFBQSxPQUFBLFlBQUEsSUFBQSxFQUFBO0FBS0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsZ0JBQUEsT0FBQSxPQUFBLFFBQUEsYUFBQSxVQUFBLE9BQUEsT0FBQSxRQUFBLGFBQUEsT0FBQSxhQUFBLElBQUEsRUFBQTtBQUtBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLGdCQUFBLE9BQUEsT0FBQSxRQUFBLGFBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxhQUFBLE9BQUEsZUFBQSxJQUFBLEVBQUE7Ozs7O0FBckJaLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQW1CLElBQUEscUJBQUEsQ0FBQTs7QUFBdUQsSUFBQSwyQkFBQTtBQUMxRSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsU0FBQSxFQUFBOztBQU9BLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSw2RUFBQSxHQUFBLENBQUE7QUFtQkosSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTs7OztBQTVCMkIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxJQUFBLDBCQUFBLEdBQUEsR0FBQSw2QkFBQSxHQUFBLEdBQUE7QUFNZixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGVBQUEsMEJBQUEsR0FBQSxHQUFBLHlEQUFBLENBQUE7QUFFSixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEtBQUEsT0FBQSxnQkFBQSxPQUFBLE9BQUEsT0FBQSxhQUFBLGNBQUEsT0FBQSxnQkFBQSxPQUFBLE9BQUEsT0FBQSxhQUFBLFdBQUEsT0FBQSxnQkFBQSxPQUFBLE9BQUEsT0FBQSxhQUFBLFlBQUEsS0FBQSxFQUFBOzs7OztBQWtDWSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9DQUFBOzs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDhDQUFBLDBCQUFBLEdBQUEsR0FBQSw0RUFBQSxHQUFBLHdDQUFBOzs7OztBQUhaLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsMkZBQUEsR0FBQSxDQUFBO0FBS0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQU5RLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLHNCQUFBLE9BQUEsT0FBQSxRQUFBLG1CQUFBLFVBQUEsT0FBQSxPQUFBLFFBQUEsbUJBQUEsT0FBQSxhQUFBLElBQUEsRUFBQTs7Ozs7QUFYWixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUF5QixJQUFBLHFCQUFBLENBQUE7O0FBQTRELElBQUEsMkJBQUE7QUFDckYsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFlBQUEsRUFBQTs7QUFPQSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsNkVBQUEsR0FBQSxDQUFBO0FBU0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTs7OztBQWxCaUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsbUNBQUEsQ0FBQTtBQU1yQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGVBQUEsMEJBQUEsR0FBQSxHQUFBLCtEQUFBLENBQUE7QUFFSixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEtBQUEsT0FBQSxzQkFBQSxPQUFBLE9BQUEsT0FBQSxtQkFBQSxjQUFBLE9BQUEsc0JBQUEsT0FBQSxPQUFBLE9BQUEsbUJBQUEsV0FBQSxPQUFBLHNCQUFBLE9BQUEsT0FBQSxPQUFBLG1CQUFBLFlBQUEsS0FBQSxFQUFBOzs7OztBQXdCUSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQTtBQUFRLElBQUEscUJBQUEsQ0FBQTs7QUFBNEgsSUFBQSwyQkFBQTtBQUN4SSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7QUFEWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLE1BQUEsMEJBQUEsR0FBQSxHQUFBLDBEQUFBLEdBQUEsTUFBQSxRQUFBLG9CQUFBLEtBQUEsSUFBQSxHQUFBLElBQUE7Ozs7O0FBTVIsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTs7O0FBR0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7Ozs7QUFMWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsYUFBQSxHQUFBO0FBQ0osSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQ0FBQSxTQUFBLE9BQUEsS0FBQSxHQUFBLGdEQUFBLDBCQUFBLEdBQUEsR0FBQSxzQ0FBQSxhQUFBLE1BQUEsWUFBQSxDQUFBLEdBQUEsMkNBQUEsMEJBQUEsR0FBQSxHQUFBLG9DQUFBLGFBQUEsTUFBQSxZQUFBLENBQUEsR0FBQSxxQ0FBQTs7Ozs7QUFYaEIsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxTQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0EsSUFBQSx5QkFBQSxHQUFBLDZFQUFBLEdBQUEsQ0FBQTtBQUdKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsK0JBQUEsSUFBQSxzRUFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBOztBQU9KLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBOzs7O0FBaEJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsa0NBQUEsMEJBQUEsR0FBQSxHQUFBLGdDQUFBLEdBQUEsZ0NBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSx1QkFBQSxPQUFBLE9BQUEsT0FBQSxvQkFBQSxVQUFBLElBQUEsRUFBQTtBQUtRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxNQUFBO0FBQ1IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSwwQkFBQSxJQUFBLEdBQUEsT0FBQSxvQkFBQSxPQUFBLFNBQUEsQ0FBQTs7Ozs7QUFlSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQTtBQUFRLElBQUEscUJBQUEsQ0FBQTs7QUFBb0gsSUFBQSwyQkFBQTtBQUNoSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7QUFEWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLE1BQUEsMEJBQUEsR0FBQSxHQUFBLDREQUFBLEdBQUEsTUFBQSxRQUFBLHFCQUFBLEtBQUE7Ozs7O0FBSnBCLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOztBQUNBLElBQUEseUJBQUEsR0FBQSw2RUFBQSxHQUFBLENBQUE7QUFHSixJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7Ozs7O0FBUFksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxrQ0FBQSwwQkFBQSxHQUFBLEdBQUEsd0NBQUEsR0FBQSxPQUFBLFVBQUEsT0FBQSx3QkFBQSxXQUFBLFFBQUEsWUFBQSxTQUFBLFVBQUEsSUFBQSxpQ0FBQTtBQUNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLHNCQUFBLElBQUEsRUFBQTs7Ozs7O0FBeUJRLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBc0MsSUFBQSx5QkFBQSxTQUFBLFNBQUEsK0ZBQUE7QUFBQSxZQUFBLGNBQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsY0FBQSxZQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsd0JBQUEsV0FBQSxDQUFnQztJQUFBLENBQUE7QUFDM0UsSUFBQSxxQkFBQSxDQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTs7Ozs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDhDQUFBLFFBQUEsMkJBQUEsV0FBQSxHQUFBLHdDQUFBOzs7OztBQVhoQixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTs7QUFLSixJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsK0JBQUEsR0FBQSxzRUFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBO0FBS0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFoQlMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxVQUFBLE9BQUEscUJBQUE7QUFFRyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLHNDQUFBLE9BQUEsNEJBQUEsT0FBQSwyQkFBQSxPQUFBLHlCQUFBLElBQUEsMEJBQUEsR0FBQSxHQUFBLHNEQUFBLEdBQUEsZ0NBQUE7QUFPQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsZ0NBQUE7Ozs7O0FBUVIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtDQUFBLDBCQUFBLEdBQUEsR0FBQSxtREFBQSxHQUFBLDRCQUFBOzs7OztBQUlKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7O0FBRlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxrQ0FBQSwwQkFBQSxHQUFBLEdBQUEsbURBQUEsR0FBQSw0QkFBQTs7Ozs7O0FBc0JZLElBQUEscUJBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFFSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSwyRkFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxrQkFBQSxZQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEseUJBQUEsZUFBQSxDQUFxQztJQUFBLENBQUE7QUFHOUMsSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHFCQUFBLENBQUE7QUFBMEMsSUFBQSwyQkFBQTtBQUM5QyxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEscUJBQUEsQ0FBQTtBQUE4QyxJQUFBLDJCQUFBO0FBQ2xELElBQUEscUJBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxxQkFBQSxFQUFBO0FBQWtILElBQUEsMkJBQUE7QUFDdEgsSUFBQSxxQkFBQSxJQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEVBQUE7QUFLSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3Q0FBQTs7Ozs7QUFiUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGlCQUFBLFFBQUEsb0NBQUEsZUFBQSxDQUFBO0FBRUksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxnQkFBQSxLQUFBLGdCQUFBLEtBQUEsRUFBQTtBQUNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsZ0JBQUEsT0FBQSxnQkFBQSxPQUFBLEVBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFFBQUEsbUJBQUEsbUJBQUEsZUFBQSxJQUFBLFFBQUEsbUJBQUEsbUJBQUEsZUFBQSxJQUFBLEVBQUE7QUFFQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLHNEQUFBLFFBQUEsbUJBQUEsMEJBQUEsZUFBQSxJQUFBLFFBQUEsbUJBQUEsMEJBQUEsZUFBQSxFQUFBLE9BQUEsdUJBQUEsSUFBQSxJQUFBLGdEQUFBOzs7OztBQTNCeEIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxTQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUUsSUFBQSwyQkFBQTtBQUNOLElBQUEscUJBQUEsSUFBQSw0Q0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxFQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsRUFBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLDRDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEVBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3Q0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLCtCQUFBLElBQUEsc0VBQUEsSUFBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQWtCSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFoQ3dCLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEsaUNBQUEsa0RBQUEsMEJBQUEsSUFBQSxHQUFBLDhEQUFBLEdBQUEsNENBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtEQUFBLDBCQUFBLElBQUEsR0FBQSw4REFBQSxHQUFBLDRDQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxrREFBQSwwQkFBQSxJQUFBLEdBQUEscUVBQUEsR0FBQSw0Q0FBQTtBQUtSLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsT0FBQSwwQkFBQSxZQUFBOzs7Ozs7QUE0QlosSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFzQixJQUFBLHlCQUFBLFNBQUEsU0FBQSx3RkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLFdBQUEsQ0FBWTtJQUFBLENBQUE7QUFDdkMsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUFvQyxJQUFBLHFCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBMEMsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBTSxJQUFBLDJCQUFBO0FBQzlGLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFGaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsT0FBQTs7Ozs7O0FBN0t6QixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQXlCLElBQUEseUJBQUEsWUFBQSxTQUFBLDBFQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBWSwwQkFBQSxRQUFBLFdBQUEsQ0FBWTtJQUFBLENBQUE7QUFDN0MsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDhEQUFBLElBQUEsQ0FBQSxFQThCQyxHQUFBLDhEQUFBLElBQUEsQ0FBQTtBQXNCRCxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLHdCQUFBLENBQUE7OztBQU1KLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsK0RBQUEsSUFBQSxDQUFBLEVBbUJDLElBQUEsK0RBQUEsSUFBQSxDQUFBO0FBWUQsSUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxTQUFBLENBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsU0FBQSxDQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTs7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQTtBQUFPLElBQUEscUJBQUEsRUFBQTs7QUFBeUYsSUFBQSwyQkFBQTtBQUNoRyxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsK0RBQUEsSUFBQSxDQUFBLEVBaUJDLElBQUEsK0RBQUEsR0FBQSxDQUFBLEVBQUEsSUFBQSwrREFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUE7QUFVRCxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsK0RBQUEsSUFBQSxDQUFBO0FBd0NKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxVQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsRUFBQTs7QUFBK0MsSUFBQSwyQkFBQTtBQUN6RCxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLCtEQUFBLEdBQUEsQ0FBQTtBQUtKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7Ozs7QUFsTFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLE9BQUEsSUFBQTtBQUNGLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxDQUFBLE9BQUEsa0JBQUEsSUFBQSxFQUFBO0FBK0JBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxDQUFBLE9BQUEsa0JBQUEsSUFBQSxFQUFBO0FBd0JRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsb0NBQUEsYUFBQSwwQkFBQSxHQUFBLElBQUEsb0RBQUEsQ0FBQTtBQUNBLElBQUEsb0NBQUEsZ0JBQUEsMEJBQUEsR0FBQSxJQUFBLHdEQUFBLENBQUE7QUFJUixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsQ0FBQSxPQUFBLGtCQUFBLEtBQUEsRUFBQTtBQW9CQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsQ0FBQSxPQUFBLGtCQUFBLEtBQUEsRUFBQTtBQWM4RCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLG9DQUFBLGNBQUEsMEJBQUEsSUFBQSxJQUFBLDJDQUFBLENBQUE7QUFBakQsSUFBQSx5QkFBQSxRQUFBLE9BQUEsZ0JBQUE7QUFHRixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSxnRUFBQSxDQUFBO0FBQ1AsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsb0NBQUEsT0FBQSxpQ0FBQSxTQUFBLElBQUEsS0FBQSxFQUFBO0FBMkJBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLDRCQUFBLEtBQUEsRUFBQTtBQTBDcUUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLENBQUEsT0FBQSxnQkFBQTtBQUMzRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSxzQkFBQSxDQUFBO0FBRVYsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsa0JBQUEsS0FBQSxFQUFBOzs7QUQ5S3BCLElBaUJhLHNCQTZDQTtBQTlEYjs7QUFFQTtBQU1BO0FBRUE7Ozs7OztBQU9PLElBQU0sdUJBQXVCLENBQUMsbUJBQXNDLFVBQWtCLGlCQUF5QjtBQUNsSCxhQUFPLENBQUMsMkJBQTJEO0FBQy9ELGVBQU8sR0FBRyx1QkFBdUIsS0FBSyxFQUFFLEtBQ3BDLE1BQU0sR0FBRyxHQUNULFVBQVUsQ0FBQyxVQUFTO0FBQ2hCLGNBQUksZ0JBQWdCLFVBQVUsY0FBYztBQUN4QyxtQkFBTyxHQUFHLElBQUk7O0FBRWxCLGlCQUFPLGtCQUFrQixnQkFBZ0IsUUFBUSxFQUFFLEtBQy9DLElBQUksQ0FBQyxRQUFPO0FBQ1IsZ0JBQUksbUJBQTZCLENBQUE7QUFDakMsZ0JBQUksSUFBSSxNQUFNO0FBQ1YsaUNBQW1CLElBQUksS0FBSyxJQUFJLENBQUMsZUFBZSxXQUFXLEtBQU07O0FBRXJFLGdCQUFJLFNBQVMsaUJBQWlCLFNBQVMsS0FBSyxHQUFHO0FBQzNDLHFCQUFPO2dCQUNILGFBQWEsRUFBRSxPQUFPLE1BQUs7O21CQUU1QjtBQUNILHFCQUFPOztVQUVmLENBQUMsR0FDRCxXQUFXLE1BQU0sR0FBRyxJQUFJLENBQUMsQ0FBQztRQUVsQyxDQUFDLENBQUM7TUFFVjtJQUNKO0FBa0JNLElBQU8sMEJBQVAsTUFBTyx5QkFBdUI7TUE2Q3BCO01BQ0E7TUFDQTtNQUNEO01BOUNYLFdBQStCO1FBQzNCLElBQUk7UUFDSixPQUFPO1FBQ1AsYUFBYTtRQUNiLGFBQWE7UUFDYixVQUFVO1FBQ1Ysa0JBQWtCO1FBQ2xCLFVBQVU7UUFDVix1QkFBdUI7O01BSTNCLGFBQWE7TUFFYixrQkFBa0I7TUFFbEIsd0JBQXdCO01BRXhCO01BRUEsbUNBQThDLENBQUE7TUFFOUM7TUFFQTtNQUVBLFdBQThCLElBQUksYUFBWTtNQUU5Qyx1QkFBdUI7TUFDdkIscUJBQXFCO01BR3JCLGdCQUFrRCxJQUFJLGFBQVk7TUFFbEU7TUFDQTtNQUNBLDhCQUE2QyxDQUFBO01BQzdDLHNCQUFnQyxDQUFBO01BRWhDLFVBQVU7TUFDVixtQkFBbUI7TUFFbkIsWUFDWSxJQUNBLG1CQUNBLGtCQUNELG9CQUFzQztBQUhyQyxhQUFBLEtBQUE7QUFDQSxhQUFBLG9CQUFBO0FBQ0EsYUFBQSxtQkFBQTtBQUNELGFBQUEscUJBQUE7TUFDUjtNQUVILElBQUksZUFBWTtBQUNaLGVBQU8sS0FBSyxLQUFLLElBQUksT0FBTztNQUNoQztNQUVBLElBQUkscUJBQWtCO0FBQ2xCLGVBQU8sS0FBSyxLQUFLLElBQUksYUFBYTtNQUN0QztNQUVBLElBQUkscUJBQWtCO0FBQ2xCLGVBQU8sS0FBSyxLQUFLLElBQUksYUFBYTtNQUN0QztNQUVBLElBQUksMEJBQXVCO0FBQ3ZCLGVBQU8sS0FBSyxLQUFLLElBQUksa0JBQWtCO01BQzNDO01BRUEsSUFBSSxrQkFBZTtBQUNmLGVBQU8sS0FBSyxLQUFLLElBQUksVUFBVTtNQUNuQztNQUVBLGNBQVc7QUFDUCxhQUFLLGVBQWM7QUFDbkIsWUFBSSxLQUFLLGNBQWMsS0FBSyxVQUFVO0FBQ2xDLGVBQUssY0FBYyxLQUFLLFFBQVE7O01BRXhDO01BRUEsV0FBUTtBQUNKLGFBQUssZUFBYztNQUN2QjtNQUVRLGlCQUFjO0FBQ2xCLFlBQUksS0FBSyxNQUFNO0FBQ1g7O0FBRUosWUFBSSxlQUFtQztBQUN2QyxZQUFJLEtBQUssY0FBYyxLQUFLLFlBQVksS0FBSyxTQUFTLE9BQU87QUFDekQseUJBQWUsS0FBSyxTQUFTOztBQUVqQyxhQUFLLE9BQU8sS0FBSyxHQUFHLE1BQU07VUFDdEIsT0FBTztZQUNIO1lBQ0EsQ0FBQyxXQUFXLFVBQVUsV0FBVyxVQUFVLEdBQUcsQ0FBQztZQUMvQyxDQUFDLEtBQUsscUJBQXFCLEtBQUssbUJBQW1CLEtBQUssVUFBVSxZQUFZLENBQUM7O1VBRW5GLGFBQWEsQ0FBQyxRQUFpQyxDQUFDLFdBQVcsVUFBVSxHQUFLLENBQUMsQ0FBQztVQUM1RSxhQUFhLENBQUMsTUFBUztVQUN2QixVQUFVLENBQUMsUUFBVyxDQUFDLFdBQVcsUUFBUSxPQUFPLE9BQU8sS0FBSyxLQUFLLGtCQUFrQixFQUFFLEtBQUssR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDO1VBQ3hHLGtCQUFrQixDQUFDLFFBQVcsQ0FBQyxXQUFXLElBQUksQ0FBQyxHQUFHLFdBQVcsSUFBSSxHQUFHLENBQUMsQ0FBQztVQUN0RSxVQUFVLENBQUMsS0FBSztTQUNuQjtBQUNELGFBQUssOEJBQThCLENBQUE7QUFFbkMsY0FBTSxLQUFLLGFBQWMsY0FBYyxLQUFLLG1CQUFvQixZQUFZLEVBQUUsVUFBVSxNQUFNLEtBQUssa0JBQWlCLENBQUU7QUFFdEgsWUFBSSxLQUFLLHVCQUF1QjtBQUM1QixlQUFLLHdCQUF3QixLQUFLLGlDQUFpQyxNQUFLLENBQUc7O01BRW5GO01BRVEsY0FBYyxVQUE0QjtBQUM5QyxhQUFLLEtBQUssV0FBVyxRQUFRO0FBQzdCLFlBQUksU0FBUyx1QkFBdUI7QUFDaEMsZUFBSyw4QkFBOEIsU0FBUzs7TUFFcEQ7TUFFQSxhQUFVO0FBQ04sYUFBSyxTQUFTLEtBQUk7TUFDdEI7TUFFQSxhQUFVO0FBQ04sY0FBTSxxQkFBeUMsbUJBQUssS0FBSyxLQUFLO0FBQzlELDJCQUFtQix3QkFBd0IsS0FBSztBQUNoRCxhQUFLLGNBQWMsS0FBSyxrQkFBa0I7TUFDOUM7TUFFQSxJQUFJLG1CQUFnQjtBQUNoQixlQUFPLENBQUMsS0FBSyxLQUFLO01BQ3RCO01BRUEsd0JBQXdCLFNBQWdCO0FBQ3BDLGFBQUssNEJBQTRCO01BQ3JDO01BS0EsWUFBWSxNQUFLO0FBQ2IsZUFBTztNQUNYO01BTUEsb0JBQWlCO0FBQ2IsYUFBSyxzQkFBc0IsQ0FBQTtBQUMzQixjQUFNLFFBQVEsS0FBSyxjQUFjLE9BQU8sWUFBVyxLQUFNO0FBQ3pELGNBQU0sY0FBYyxLQUFLLG9CQUFvQixPQUFPLFlBQVcsS0FBTTtBQUNyRSxtQkFBVyxZQUFZLEtBQUssb0JBQW9CO0FBQzVDLGdCQUFNLFdBQVcsS0FBSyxpQkFBaUIsUUFBUSxvQ0FBb0MsU0FBUyxZQUFXLENBQUUsRUFBRSxNQUFNLElBQUk7QUFDckgsZ0JBQU0sZUFBZSxLQUFLLGlCQUFpQixRQUFRLHNDQUFzQyxTQUFTLFlBQVcsQ0FBRTtBQUMvRyxtQkFBUyxLQUFLLFlBQVk7QUFDMUIsY0FBSSxTQUFTLElBQUksQ0FBQyxZQUFvQixRQUFRLFlBQVcsQ0FBRSxFQUFFLEtBQUssQ0FBQyxZQUFvQixNQUFNLFNBQVMsT0FBTyxLQUFLLFlBQVksU0FBUyxPQUFPLENBQUMsR0FBRztBQUM5SSxpQkFBSyxvQkFBb0IsS0FBSyxZQUFZOzs7TUFHdEQ7TUFFQSx5QkFBeUIsYUFBd0I7QUFDN0MsWUFBSSxLQUFLLG9DQUFvQyxXQUFXLEdBQUc7QUFDdkQsZUFBSyw0QkFBNEIsUUFBUSxDQUFDLHFCQUFxQixVQUFTO0FBQ3BFLGdCQUFJLG9CQUFvQixPQUFPLFlBQVksSUFBSTtBQUMzQyxtQkFBSyw0QkFBNEIsT0FBTyxPQUFPLENBQUM7O1VBRXhELENBQUM7ZUFDRTtBQUNILGVBQUssNEJBQTRCLEtBQUssV0FBVzs7TUFFekQ7TUFFQSxvQ0FBb0MsYUFBd0I7QUFDeEQsZUFBTyxLQUFLLDRCQUE0QixJQUFJLENBQUMsd0JBQXdCLG9CQUFvQixFQUFFLEVBQUUsU0FBUyxZQUFZLEVBQUU7TUFDeEg7TUFFQSwyQkFBMkIsU0FBZ0I7QUFDdkMsY0FBTSw2QkFBNkIsYUFDL0IsS0FBSyw0QkFBNEIsSUFBSSxDQUFDLFNBQVMsS0FBSyxFQUFFLEdBQ3RELFFBQVEsY0FBYyxJQUFJLENBQUMsU0FBUyxLQUFLLEVBQUUsQ0FBQyxFQUM5QztBQUNGLGVBQU8sS0FBSyxpQkFBaUIsUUFBUSxtREFBbUQ7VUFDcEYsY0FBYyxRQUFRO1VBQ3RCLG9CQUFvQjtTQUN2QjtNQUNMOzt5QkExTFMsMEJBQXVCLGdDQUFBLGVBQUEsR0FBQSxnQ0FBQSxpQkFBQSxHQUFBLGdDQUFBLG9CQUFBLEdBQUEsZ0NBQUEsa0JBQUEsQ0FBQTtNQUFBO2lFQUF2QiwwQkFBdUIsV0FBQSxDQUFBLENBQUEscUJBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsWUFBQSxjQUFBLGlCQUFBLG1CQUFBLHVCQUFBLHlCQUFBLFVBQUEsWUFBQSxrQ0FBQSxvQ0FBQSxxQkFBQSx1QkFBQSxpQkFBQSxrQkFBQSxHQUFBLFNBQUEsRUFBQSxVQUFBLFlBQUEsZUFBQSxnQkFBQSxHQUFBLFVBQUEsQ0FBQSxrQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLE1BQUEsZUFBQSxtQkFBQSxlQUFBLEdBQUEsYUFBQSxjQUFBLEdBQUEsQ0FBQSxRQUFBLFlBQUEsTUFBQSxZQUFBLG1CQUFBLFlBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsZ0JBQUEsa0NBQUEsT0FBQSxZQUFBLEdBQUEsb0JBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxRQUFBLFlBQUEsR0FBQSxDQUFBLGNBQUEsRUFBQSxHQUFBLENBQUEsTUFBQSxnQkFBQSxRQUFBLFVBQUEsR0FBQSxPQUFBLGVBQUEsUUFBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLE9BQUEsT0FBQSxHQUFBLENBQUEsUUFBQSxRQUFBLE1BQUEsU0FBQSxtQkFBQSxTQUFBLEdBQUEsZ0JBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsY0FBQSxHQUFBLENBQUEsT0FBQSxhQUFBLEdBQUEsQ0FBQSxNQUFBLGVBQUEsUUFBQSxLQUFBLG1CQUFBLGVBQUEsR0FBQSxnQkFBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLE9BQUEsVUFBQSxHQUFBLENBQUEsTUFBQSxZQUFBLG1CQUFBLFlBQUEsR0FBQSxlQUFBLE1BQUEsR0FBQSxDQUFBLFlBQUEsSUFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsT0FBQSxrQkFBQSxHQUFBLENBQUEsUUFBQSxTQUFBLE9BQUEsS0FBQSxPQUFBLE9BQUEsTUFBQSxvQkFBQSxtQkFBQSxvQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLGVBQUEsSUFBQSxHQUFBLFFBQUEsR0FBQSxRQUFBLEdBQUEsQ0FBQSxxQkFBQSxJQUFBLFFBQUEsVUFBQSxHQUFBLE9BQUEscUJBQUEsR0FBQSxDQUFBLG1CQUFBLEVBQUEsR0FBQSxDQUFBLG1CQUFBLElBQUEsUUFBQSxVQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsT0FBQSxlQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSxzQkFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGlDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDOURwQyxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLEdBQUEsZ0RBQUEsSUFBQSxFQUFBO0FBb0xKLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsSUFBQTs7O0FBdExRLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLE9BQUEsSUFBQSxFQUFBOzs7OztxRkQ0REsseUJBQXVCLEVBQUEsV0FBQSwwQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUU5RHBDLFNBQVMsYUFBQUMsa0JBQXlCO0FBR2xDLFNBQVMsZ0JBQWdCLGNBQWM7QUFJdkMsU0FBUyxVQUFVLGFBQUFDLFlBQVcsWUFBWTs7Ozs7QUNOdEMsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUFzQixJQUFBLHFCQUFBLENBQUE7O0FBQWtDLElBQUEsMkJBQUE7QUFDNUQsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQUhrQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsR0FBQSxTQUFBLENBQUE7Ozs7OztBQUs5QixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEscUJBQUEsQ0FBQTs7QUFBdUUsSUFBQSwyQkFBQTtBQUMzRSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsNEJBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLHVCQUFBLENBQUE7QUFFSSxJQUFBLHlCQUFBLGlCQUFBLFNBQUEsK0ZBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQWlCLDBCQUFBLE9BQUEsaUJBQUEsTUFBQSxDQUF3QjtJQUFBLENBQUE7QUFHNUMsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxJQUFBOzs7O0FBVmdCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLDhDQUFBLENBQUE7QUFDc0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsaUJBQUE7QUFHMUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLEtBQUEsRUFBb0IsWUFBQSxPQUFBLFFBQUEsRUFBQSxvQ0FBQSxPQUFBLHdCQUFBOzs7QURkaEMsSUFrQmE7QUFsQmI7O0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFJQTs7Ozs7OztBQVNNLElBQU8sNEJBQVAsTUFBTywyQkFBeUI7TUFRdEI7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQVhILG9CQUF1QztNQUNoRCxxQkFBaUMsSUFBSSxXQUFVO01BQy9DO01BQ0E7TUFDQSwyQkFBc0MsQ0FBQTtNQUV0QyxZQUNZLGdCQUNBLFFBQ0EsbUJBQ0EsY0FDQSxnQkFBOEI7QUFKOUIsYUFBQSxpQkFBQTtBQUNBLGFBQUEsU0FBQTtBQUNBLGFBQUEsb0JBQUE7QUFDQSxhQUFBLGVBQUE7QUFDQSxhQUFBLGlCQUFBO01BQ1Q7TUFFSCxXQUFRO0FBQ0osYUFBSyxxQkFBcUIsSUFBSSxXQUFVO0FBQ3hDLGFBQUssWUFBWTtBQUNqQixhQUFLLGVBQ0EsT0FBUSxPQUFRLFNBQVMsS0FDdEIsS0FBSyxDQUFDLEdBQ05BLFdBQVUsQ0FBQyxXQUFVO0FBQ2pCLGVBQUssV0FBVyxPQUFPLE9BQU8sSUFBSSxVQUFVLENBQUM7QUFDN0MsaUJBQU8sS0FBSyxlQUFlLGtCQUFrQixLQUFLLFVBQVUsSUFBSTtRQUNwRSxDQUFDLEdBQ0QsU0FBUyxNQUFLO0FBQ1YsZUFBSyxZQUFZO1FBQ3JCLENBQUMsQ0FBQyxFQUVMLFVBQVU7VUFDUCxNQUFNLENBQUMsa0JBQWlCO0FBQ3BCLGdCQUFJLGNBQWMsTUFBTTtBQUNwQixtQkFBSywyQkFBMkIsY0FBYztBQUM5Qyx5QkFBVyxXQUFXLEtBQUssMEJBQTBCO0FBRWpELG9CQUFJLENBQUMsUUFBUSxjQUFjO0FBQ3ZCLDBCQUFRLGVBQWUsQ0FBQTs7OztVQUl2QztVQUNBLE9BQU8sQ0FBQyxRQUEyQixRQUFRLEtBQUssY0FBYyxHQUFHO1NBQ3BFO01BQ1Q7TUFFQSxpQkFBaUIsVUFBNEI7QUFDekMsWUFBSSxDQUFDLFVBQVUsT0FBTztBQUNsQjs7QUFHSixjQUFNLEVBQUUsT0FBTyxhQUFhLGFBQWEsVUFBVSxrQkFBa0IsVUFBVSxzQkFBcUIsSUFBSztBQUV6RyxhQUFLLG1CQUFtQixRQUFRO0FBQ2hDLGFBQUssbUJBQW1CLGNBQWM7QUFDdEMsYUFBSyxtQkFBbUIsY0FBYztBQUN0QyxhQUFLLG1CQUFtQixXQUFXO0FBQ25DLGFBQUssbUJBQW1CLG1CQUFtQjtBQUMzQyxhQUFLLG1CQUFtQixXQUFXO0FBQ25DLGFBQUssbUJBQW1CLGVBQWU7QUFFdkMsYUFBSyxZQUFZO0FBRWpCLGFBQUssa0JBQ0EsT0FBTyxLQUFLLG9CQUFxQixLQUFLLFFBQVEsRUFDOUMsS0FDRyxTQUFTLE1BQUs7QUFDVixlQUFLLFlBQVk7UUFDckIsQ0FBQyxDQUFDLEVBRUwsVUFBVTtVQUNQLE1BQU0sTUFBSztBQUVQLGlCQUFLLE9BQU8sU0FBUyxDQUFDLEtBQUssR0FBRyxFQUFFLFlBQVksS0FBSyxlQUFjLENBQUU7VUFDckU7VUFDQSxPQUFPLENBQUMsUUFBMkIsUUFBUSxLQUFLLGNBQWMsR0FBRztTQUNwRTtNQUNUOzt5QkE1RVMsNEJBQXlCLGdDQUFBLGtCQUFBLEdBQUEsZ0NBQUEsVUFBQSxHQUFBLGdDQUFBLGlCQUFBLEdBQUEsZ0NBQUEsWUFBQSxHQUFBLGdDQUFBLGNBQUEsQ0FBQTtNQUFBO2lFQUF6Qiw0QkFBeUIsV0FBQSxDQUFBLENBQUEsdUJBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxVQUFBLHdCQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxvQkFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsWUFBQSxvQ0FBQSxlQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsbUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNsQnRDLFVBQUEseUJBQUEsR0FBQSxrREFBQSxJQUFBLENBQUEsRUFNQyxHQUFBLGtEQUFBLElBQUEsQ0FBQTs7O0FBTkQsVUFBQSw0QkFBQSxHQUFBLElBQUEsWUFBQSxJQUFBLEVBQUE7QUFPQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsQ0FBQSxJQUFBLFlBQUEsSUFBQSxFQUFBOzs7OztxRkRXYSwyQkFBeUIsRUFBQSxXQUFBLDRCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRWxCdEMsU0FBUyxhQUFBQyxrQkFBeUI7QUFJbEMsU0FBUyxrQkFBQUMsaUJBQWdCLFVBQUFDLGVBQWM7QUFFdkMsU0FBUyxZQUFBQyxXQUFVLGFBQUFDLFlBQVcsUUFBQUMsYUFBWTtBQUkxQyxTQUFTLGVBQWUsZ0JBQWdCOzs7OztBQ1RwQyxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQXNCLElBQUEscUJBQUEsQ0FBQTs7QUFBa0MsSUFBQSwyQkFBQTtBQUM1RCxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBSGtDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLFNBQUEsQ0FBQTs7Ozs7O0FBSzlCLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHFCQUFBLENBQUE7O0FBQXFFLElBQUEsMkJBQUE7QUFDekUsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsdUJBQUEsQ0FBQTtBQUdJLElBQUEseUJBQUEsaUJBQUEsU0FBQSw0RkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBaUIsMEJBQUEsT0FBQSxpQkFBQSxNQUFBLENBQXdCO0lBQUEsQ0FBQTtBQUk1QyxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLElBQUE7Ozs7O0FBVlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsNENBQUEsQ0FBQTtBQUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSxJQUFBLEVBQW1CLFlBQUEsT0FBQSxRQUFBLEVBQUEsWUFBQSxPQUFBLFFBQUEsRUFBQSxvQ0FBQSxPQUFBLHdCQUFBLEVBQUEsd0JBQUEsVUFBQSxPQUFBLGNBQUEsT0FBQSxPQUFBLE9BQUEsV0FBQSxrQkFBQSxPQUFBLE9BQUEsT0FBQSxXQUFBLGVBQUEseUJBQUEsUUFBQSxZQUFBLFNBQUEsVUFBQSxDQUFBOzs7QURYL0IsSUFtQmE7QUFuQmI7O0FBQ0E7QUFJQTtBQUVBO0FBRUE7QUFHQTs7Ozs7O0FBT00sSUFBTywwQkFBUCxNQUFPLHlCQUF1QjtNQVFwQjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BWFosWUFBWTtNQUNaO01BQ0EsMkJBQXNDLENBQUE7TUFDdEM7TUFDQTtNQUVBLFlBQ1ksZ0JBQ0EsZ0JBQ0EsUUFDQSxtQkFDQSxjQUEwQjtBQUoxQixhQUFBLGlCQUFBO0FBQ0EsYUFBQSxpQkFBQTtBQUNBLGFBQUEsU0FBQTtBQUNBLGFBQUEsb0JBQUE7QUFDQSxhQUFBLGVBQUE7TUFDVDtNQUVILFdBQVE7QUFDSixhQUFLLFlBQVk7QUFDakIsc0JBQWMsQ0FBQyxLQUFLLGVBQWUsVUFBVSxLQUFLLGVBQWUsT0FBUSxPQUFRLFFBQVEsQ0FBQyxFQUNyRixLQUNHQSxNQUFLLENBQUMsR0FDTkQsV0FBVSxDQUFDLENBQUMsUUFBUSxZQUFZLE1BQUs7QUFDakMsZ0JBQU0sZUFBZSxPQUFPLE9BQU8sSUFBSSxjQUFjLENBQUM7QUFDdEQsZUFBSyxXQUFXLE9BQU8sYUFBYSxJQUFJLFVBQVUsQ0FBQztBQUVuRCxnQkFBTSx1QkFBdUIsS0FBSyxrQkFBa0IsU0FBUyxjQUFjLEtBQUssUUFBUTtBQUN4RixnQkFBTSxxQ0FBcUMsS0FBSyxrQkFBa0Isa0JBQWtCLGNBQWMsS0FBSyxRQUFRO0FBQy9HLGdCQUFNLHFCQUFxQixLQUFLLGVBQWUsa0JBQWtCLEtBQUssVUFBVSxJQUFJO0FBQ3BGLGlCQUFPLFNBQVMsQ0FBQyxzQkFBc0Isb0NBQW9DLGtCQUFrQixDQUFDO1FBQ2xHLENBQUMsR0FDREQsVUFBUyxNQUFPLEtBQUssWUFBWSxLQUFNLENBQUMsRUFFM0MsVUFBVTtVQUNQLE1BQU0sQ0FBQyxDQUFDLGtCQUFrQixzQkFBc0IsY0FBYyxNQUFLO0FBQy9ELGdCQUFJLGlCQUFpQixNQUFNO0FBQ3ZCLG1CQUFLLGFBQWEsaUJBQWlCO0FBQ25DLGtCQUFJLHFCQUFxQixNQUFNO0FBQzNCLHFCQUFLLFdBQVcsaUJBQWlCLHFCQUFxQjs7QUFHMUQsa0JBQUksQ0FBQyxLQUFLLFdBQVcsY0FBYztBQUMvQixxQkFBSyxXQUFXLGVBQWUsQ0FBQTs7O0FBR3ZDLGdCQUFJLGVBQWUsTUFBTTtBQUNyQixtQkFBSywyQkFBMkIsZUFBZTtBQUMvQyx5QkFBVyxXQUFXLEtBQUssMEJBQTBCO0FBRWpELG9CQUFJLENBQUMsUUFBUSxjQUFjO0FBQ3ZCLDBCQUFRLGVBQWUsQ0FBQTt1QkFDcEI7QUFHSCwwQkFBUSxlQUFlLFFBQVEsYUFBYSxPQUFPLENBQUMsZ0JBQWdCLFlBQVksU0FBUyxnQkFBZ0IsUUFBUTs7OztBQUs3SCxpQkFBSyxXQUFXO2NBQ1osSUFBSSxLQUFLLFdBQVc7Y0FDcEIsT0FBTyxLQUFLLFdBQVc7Y0FDdkIsYUFBYSxLQUFLLFdBQVc7Y0FDN0IsYUFBYSxLQUFLLFdBQVc7Y0FDN0IsdUJBQXVCLEtBQUssV0FBVztjQUN2QyxVQUFVLEtBQUssV0FBVztjQUMxQixrQkFBa0IsS0FBSyxXQUFXO2NBQ2xDLFVBQVUsS0FBSyxXQUFXOztVQUVsQztVQUNBLE9BQU8sQ0FBQyxRQUEyQixRQUFRLEtBQUssY0FBYyxHQUFHO1NBQ3BFO01BQ1Q7TUFFQSxpQkFBaUIsVUFBNEI7QUFDekMsY0FBTSxFQUFFLE9BQU8sYUFBYSxhQUFhLFVBQVUsa0JBQWtCLFVBQVUsc0JBQXFCLElBQUs7QUFFekcsYUFBSyxXQUFXLFFBQVE7QUFDeEIsYUFBSyxXQUFXLGNBQWM7QUFDOUIsYUFBSyxXQUFXLGNBQWM7QUFDOUIsYUFBSyxXQUFXLFdBQVc7QUFDM0IsYUFBSyxXQUFXLG1CQUFtQjtBQUNuQyxhQUFLLFdBQVcsV0FBVztBQUMzQixhQUFLLFdBQVcsZUFBZTtBQUUvQixhQUFLLFlBQVk7QUFFakIsYUFBSyxrQkFDQSxPQUFPLEtBQUssWUFBWSxLQUFLLFFBQVEsRUFDckMsS0FDR0EsVUFBUyxNQUFLO0FBQ1YsZUFBSyxZQUFZO0FBRWpCLGVBQUssT0FBTyxTQUFTLENBQUMsUUFBUSxHQUFHLEVBQUUsWUFBWSxLQUFLLGVBQWMsQ0FBRTtRQUN4RSxDQUFDLENBQUMsRUFFTCxVQUFVO1VBQ1AsT0FBTyxDQUFDLFFBQTJCLFFBQVEsS0FBSyxjQUFjLEdBQUc7U0FDcEU7TUFDVDs7eUJBakdTLDBCQUF1QixnQ0FBQSxrQkFBQSxHQUFBLGdDQUFBLGNBQUEsR0FBQSxnQ0FBQSxVQUFBLEdBQUEsZ0NBQUEsaUJBQUEsR0FBQSxnQ0FBQSxZQUFBLENBQUE7TUFBQTtpRUFBdkIsMEJBQXVCLFdBQUEsQ0FBQSxDQUFBLHFCQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsVUFBQSx3QkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsWUFBQSxZQUFBLG9DQUFBLHVCQUFBLGVBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxpQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ25CcEMsVUFBQSx5QkFBQSxHQUFBLGdEQUFBLElBQUEsQ0FBQSxFQU1DLEdBQUEsZ0RBQUEsSUFBQSxDQUFBOzs7QUFORCxVQUFBLDRCQUFBLEdBQUEsSUFBQSxZQUFBLElBQUEsRUFBQTtBQU9BLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxDQUFBLElBQUEsWUFBQSxJQUFBLEVBQUE7Ozs7O3FGRFlhLHlCQUF1QixFQUFBLFdBQUEsMEJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFbkJwQyxTQUFTLGtCQUFnQztBQUN6QyxTQUFTLGtCQUFrQjtBQUszQixTQUFTLE9BQUFHLFlBQVc7OztBQU5wQixJQVdhO0FBWGI7O0FBR0E7QUFRTSxJQUFPLDBCQUFQLE1BQU8saUNBQWdDLGNBQWE7TUFHbEM7TUFGYixjQUFjO01BRXJCLFlBQW9CLE1BQWdCO0FBQ2hDLGNBQUs7QUFEVyxhQUFBLE9BQUE7TUFFcEI7TUFFQSxzQkFBc0IsVUFBd0I7QUFDMUMsY0FBTSxTQUFTLEtBQUssaUJBQWlCLFFBQVE7QUFDN0MsZUFBTyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssV0FBVyxJQUFJLEVBQUUsUUFBUSxTQUFTLFdBQVUsQ0FBRSxFQUFFLEtBQUtBLEtBQUksQ0FBQyxTQUEyQyxRQUFRLEtBQUssSUFBSyxDQUFDO01BQ3pKOzt5QkFWUywwQkFBdUIsdUJBQUEsY0FBQSxDQUFBO01BQUE7b0VBQXZCLDBCQUF1QixTQUF2Qix5QkFBdUIsV0FBQSxZQURWLE9BQU0sQ0FBQTs7Ozs7O0FDVmhDLFNBQVMsYUFBQUMsWUFBVyxTQUFBQyxjQUFxQjtBQUN6QyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxzQkFBc0I7QUFHL0IsU0FBUyxVQUFBQyxlQUFjO0FBQ3ZCLFNBQVMsU0FBUyxjQUFjOzs7O0FBTmhDLElBVVksYUFjVTtBQXhCdEI7O0FBR0E7QUFDQTtBQUlBOzs7QUFFQSxLQUFBLFNBQVlDLGNBQVc7QUFDbkIsTUFBQUEsYUFBQSxJQUFBLElBQUE7QUFDQSxNQUFBQSxhQUFBLE9BQUEsSUFBQTtBQUNBLE1BQUFBLGFBQUEsY0FBQSxJQUFBO0FBQ0EsTUFBQUEsYUFBQSxVQUFBLElBQUE7SUFDSixHQUxZLGdCQUFBLGNBQVcsQ0FBQSxFQUFBO0FBY2pCLElBQWdCLGtCQUFoQixNQUFnQixpQkFBZTtNQXNCckI7TUFDRDtNQUNDO01BQ0E7TUF4QkgsU0FBUztNQUNsQixVQUFVO01BQ1Y7TUFDQSxRQUFRO01BQ1IsUUFBd0I7UUFDcEIsTUFBTTtRQUNOLFVBQVU7UUFDVixZQUFZO1FBQ1osY0FBYyxhQUFhO1FBQzNCLGNBQWMsWUFBWTs7TUFJOUIsU0FBUztNQUNULFVBQVU7TUFDRixTQUFTLElBQUksUUFBTztNQUNwQixPQUFPLElBQUksUUFBTztNQUVWO01BRWhCLFlBQ1ksUUFDRCxlQUNDLGFBQ0EsYUFBMkI7QUFIM0IsYUFBQSxTQUFBO0FBQ0QsYUFBQSxnQkFBQTtBQUNDLGFBQUEsY0FBQTtBQUNBLGFBQUEsY0FBQTtNQUNUO01BRUgsSUFBSSxPQUFJO0FBQ0osZUFBTyxLQUFLLE1BQU07TUFDdEI7TUFFQSxJQUFJLEtBQUssTUFBWTtBQUNqQixhQUFLLGVBQWUsRUFBRSxLQUFJLENBQUU7TUFDaEM7TUFFQSxJQUFJLGNBQVc7QUFDWCxlQUFPLEtBQUssTUFBTSxpQkFBaUIsYUFBYTtNQUNwRDtNQU9BLElBQUksWUFBWSxXQUFrQjtBQUM5QixjQUFNLGVBQWUsWUFBWSxhQUFhLFlBQVksYUFBYTtBQUN2RSxhQUFLLGVBQWUsRUFBRSxhQUFZLENBQUU7TUFDeEM7TUFFQSxJQUFJLGVBQVk7QUFDWixlQUFPLEtBQUssTUFBTTtNQUN0QjtNQUVBLElBQUksYUFBYSxjQUFvQjtBQUNqQyxhQUFLLGVBQWUsRUFBRSxhQUFZLENBQUU7TUFDeEM7TUFFQSxJQUFJLGFBQVU7QUFDVixlQUFPLEtBQUssTUFBTTtNQUN0QjtNQUVBLElBQUksV0FBVyxZQUFrQjtBQUM3QixhQUFLLE1BQU0sYUFBYTtBQUN4QixhQUFLLE9BQU8sS0FBSTtNQUNwQjtNQUVBLFdBQVE7QUFDSixhQUFLLFVBQVUsRUFBRSxlQUFlLENBQUEsR0FBSSxlQUFlLEVBQUM7QUFFcEQsYUFBSyxjQUFjLEtBQUssTUFBTSxDQUFDO0FBQy9CLGFBQUssY0FBYyxLQUFLLFFBQVEsR0FBRztNQUN2QztNQUVBLFdBQVE7QUFDSixhQUFLLFlBQVksZUFBZSxLQUFLLFFBQVEsZUFBZSxLQUFLLGNBQWMsS0FBSyxXQUFXO01BQ25HO01BV0EsUUFBUSxPQUFlLE1BQU87QUFDMUIsZUFBTyxLQUFLO01BQ2hCO01BT0EsYUFBYSxNQUFPO0FBQ2hCLGFBQUssWUFBWSxNQUFNLElBQUk7TUFDL0I7TUFLQSxRQUFLO0FBQ0QsYUFBSyxZQUFZLFFBQVEsUUFBUTtNQUNyQztNQU9BLGFBQWEsWUFBa0I7QUFDM0IsWUFBSSxZQUFZO0FBQ1osZUFBSyxPQUFPOztNQUVwQjtNQVVRLGVBQWUsT0FBOEI7QUFDakQsZUFBTyxPQUFPLEtBQUssT0FBTyxLQUFLO0FBQy9CLGFBQUssS0FBSyxLQUFJO01BQ2xCOzt5QkFqSWtCLGtCQUFlLGdDQUFBLFVBQUEsR0FBQSxnQ0FBQSx1QkFBQSxHQUFBLGdDQUFBLFdBQUEsR0FBQSxnQ0FBQSxpQkFBQSxDQUFBO01BQUE7aUVBQWYsa0JBQWUsV0FBQSxDQUFBLENBQUEsY0FBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLGFBQUEsY0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsVUFBQSxTQUFBLHlCQUFBLElBQUEsS0FBQTtNQUFBLEdBQUEsZUFBQSxFQUFBLENBQUE7OztxRkFBZixpQkFBZSxFQUFBLFdBQUEsa0JBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FDeEJyQyxTQUFTLGFBQUFDLGtCQUFpQjtBQUUxQixTQUFTLGNBQWMsYUFBQUMsWUFBVyxXQUFXOzs7Ozs7O0FDUTdCLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBaUYsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBVSxJQUFBLDJCQUFBO0FBQy9GLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7Ozs7O0FBMEJRLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBbUIsSUFBQSwyQkFBQTtBQUM3QixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxpQkFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsaUJBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEVBQUE7QUFBdUMsSUFBQSwyQkFBQTtBQUNqRCxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxjQUFBLEVBQUE7QUFDSSxJQUFBLHlCQUFBLFdBQUEsU0FBQSwyRUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxnQkFBQSxZQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBVywwQkFBQSxPQUFBLGFBQUEsYUFBQSxDQUF3QjtJQUFBLENBQUE7QUFHdEMsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBOzs7OztBQW5Ca0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxjQUFBLEVBQUE7QUFHUyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFVBQUEsY0FBQSxLQUFBLEVBQTJCLFFBQUEsT0FBQSxVQUFBO0FBRzNCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsVUFBQSxjQUFBLFVBQUEsT0FBQSxPQUFBLGNBQUEsT0FBQSxLQUFBLEVBQW1DLFFBQUEsT0FBQSxVQUFBO0FBRzVDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsY0FBQSxVQUFBLE9BQUEsT0FBQSxjQUFBLE9BQUEsYUFBQSxFQUFBO0FBS0YsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLE9BQUEsWUFBQSxTQUFBLGNBQUEsRUFBQSxDQUFBLEVBQWlELFNBQUEsdURBQUE7OztBRHJEakYsSUFVYTtBQVZiOztBQUNBOzs7OztBQVNNLElBQU8sNEJBQVAsTUFBTyxtQ0FBa0MsZ0JBQTJCO01BQzdELGNBQWMsZUFBOEIsVUFBZ0I7QUFDakUsc0JBQ0ssS0FDRyxhQUFhLFFBQVEsR0FDckIsSUFBSSxNQUFPLEtBQUssVUFBVSxJQUFLLEdBQy9CQSxXQUFVLE1BQU0sS0FBSyxjQUFjLHNCQUFzQixLQUFLLEtBQUssQ0FBQyxDQUFDLEVBRXhFLFVBQVUsQ0FBQyxTQUFRO0FBQ2hCLGVBQUssVUFBVTtBQUNmLGVBQUssVUFBVTtBQUNmLGVBQUssUUFBUSxLQUFLLGdCQUFnQixLQUFLLE1BQU07UUFDakQsQ0FBQztNQUNUOzs7O29KQWJTLDBCQUF5QixJQUFBLEtBQXpCLDBCQUF5QjtRQUFBO01BQUEsR0FBQTtpRUFBekIsNEJBQXlCLFdBQUEsQ0FBQSxDQUFBLHVCQUFBLENBQUEsR0FBQSxVQUFBLENBQUEsd0NBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsZ0JBQUEsZ0RBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxlQUFBLFFBQUEsZ0JBQUEsU0FBQSxRQUFBLFVBQUEsR0FBQSxhQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsYUFBQSxHQUFBLENBQUEsZ0JBQUEsK0NBQUEsR0FBQSxDQUFBLFFBQUEsb0JBQUEsUUFBQSxRQUFBLEdBQUEsZ0JBQUEsUUFBQSxHQUFBLFdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLGlCQUFBLGdCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsV0FBQSxJQUFBLEdBQUEsWUFBQSxHQUFBLGFBQUEsYUFBQSxjQUFBLG1CQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLGdCQUFBLG9EQUFBLEdBQUEsQ0FBQSxnQkFBQSxxREFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsZ0JBQUEsdURBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLDJCQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxrQkFBQSxXQUFBLFlBQUEsVUFBQSxZQUFBLEdBQUEsQ0FBQSxnQkFBQSxrREFBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxTQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxtQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1Z0QyxVQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUFvRixVQUFBLHFCQUFBLEdBQUEscUJBQUE7QUFBbUIsVUFBQSwyQkFBQTtBQUN2RyxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxVQUFBLENBQUE7QUFBUSxVQUFBLHlCQUFBLFNBQUEsU0FBQSw2REFBQTtBQUFBLG1CQUFTLElBQUEsTUFBQTtVQUFPLENBQUE7QUFBMEUsVUFBQSwyQkFBQTtBQUN0RyxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsUUFBQSxDQUFBO0FBQW1FLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFzQixVQUFBLDJCQUFBO0FBQ3pGLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLENBQUE7QUFBTyxVQUFBLHlCQUFBLGlCQUFBLFNBQUEsbUVBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsYUFBQTtVQUFBLENBQUE7QUFBUCxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLG1EQUFBLEdBQUEsQ0FBQTtBQUdKLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsU0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUFJLFVBQUEseUJBQUEsY0FBQSxTQUFBLCtEQUFBO0FBQUEsbUJBQWMsSUFBQSxTQUFBO1VBQVUsQ0FBQSxFQUFDLG1CQUFBLFNBQUEsa0VBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsY0FBQTtVQUFBLENBQUEsRUFBQSxtQkFBQSxTQUFBLGtFQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLGVBQUE7VUFBQSxDQUFBO0FBQ3pCLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLFVBQUEscUJBQUEsSUFBQSxHQUFBO0FBQUMsVUFBQSwyQkFBQTtBQUNQLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBd0UsVUFBQSxxQkFBQSxJQUFBLE9BQUE7QUFBSyxVQUFBLDJCQUFBO0FBQzdFLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBeUUsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBTSxVQUFBLDJCQUFBO0FBQy9FLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBMkUsVUFBQSxxQkFBQSxJQUFBLFVBQUE7QUFBUSxVQUFBLDJCQUFBO0FBQ25GLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLCtCQUFBLElBQUEsMkNBQUEsSUFBQSxHQUFBLE1BQUEsTUFBQSxJQUFBLE9BQUE7QUF1QkosVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxrQkFBQSxFQUFBO0FBQWdCLFVBQUEseUJBQUEsY0FBQSxTQUFBLHlFQUFBLFFBQUE7QUFBQSxtQkFBYyxJQUFBLGFBQUEsTUFBQTtVQUFvQixDQUFBLEVBQUMsY0FBQSxTQUFBLHlFQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLE1BQUEsT0FBQTtVQUFBLENBQUE7QUFDbkQsVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUEzRG1CLFVBQUEsd0JBQUEsRUFBQTtBQUFBLFVBQUEseUJBQUEsV0FBQSxJQUFBLFVBQUE7QUFDUCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxVQUFBLEtBQUEsRUFBQTtBQU1rQyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLGFBQUEsSUFBQSxXQUFBLEVBQTJCLGFBQUEsSUFBQSxZQUFBO0FBQ25DLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsb0NBQUEsYUFBQSxJQUFBLE9BQUEsRUFBQTtBQUVMLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLE1BQUE7QUFFSyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLG9DQUFBLGFBQUEsSUFBQSxPQUFBLEtBQUE7QUFFTCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxNQUFBO0FBRUssVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxvQ0FBQSxhQUFBLElBQUEsT0FBQSxZQUFBO0FBRUwsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsTUFBQTtBQUVLLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsb0NBQUEsYUFBQSxJQUFBLE9BQUEsUUFBQTtBQUVMLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLE1BQUE7QUFNakIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLFFBQUEsYUFBQTtBQTBCZ0QsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsTUFBQSxJQUFBLEVBQXFCLGtCQUFBLElBQUEsS0FBQSxFQUFBLFdBQUEsRUFBQSxFQUFBLFlBQUEsSUFBQSxNQUFBLFFBQUEsRUFBQSxVQUFBLElBQUE7Ozs7O3FGRHBEeEUsMkJBQXlCLEVBQUEsV0FBQSw0QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVWdEMsU0FBUyxhQUFBQyxrQkFBaUI7Ozs7Ozs7QUNVVixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQW9GLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQVUsSUFBQSwyQkFBQTtBQUNsRyxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7OztBQTBCUSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBO0FBQW1CLElBQUEsMkJBQUE7QUFDN0IsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsaUJBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLGlCQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxFQUFBO0FBQXVDLElBQUEsMkJBQUE7QUFDakQsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsY0FBQSxFQUFBO0FBQ0ksSUFBQSx5QkFBQSxXQUFBLFNBQUEsNkVBQUE7QUFBQSxZQUFBLGNBQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsZ0JBQUEsWUFBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQVcsMEJBQUEsT0FBQSxhQUFBLGFBQUEsQ0FBd0I7SUFBQSxDQUFBO0FBR3RDLElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTs7Ozs7QUFuQmtCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsY0FBQSxFQUFBO0FBR1MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxVQUFBLGNBQUEsS0FBQSxFQUEyQixRQUFBLE9BQUEsVUFBQTtBQUczQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFVBQUEsY0FBQSxVQUFBLE9BQUEsT0FBQSxjQUFBLE9BQUEsS0FBQSxFQUFtQyxRQUFBLE9BQUEsVUFBQTtBQUc1QyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGNBQUEsVUFBQSxPQUFBLE9BQUEsY0FBQSxPQUFBLGFBQUEsRUFBQTtBQUtGLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxPQUFBLFlBQUEsU0FBQSxjQUFBLEVBQUEsQ0FBQSxFQUFpRCxTQUFBLDBEQUFBOzs7QURyRGpGLElBT2E7QUFQYjs7QUFDQTs7Ozs7QUFNTSxJQUFPLDhCQUFQLE1BQU8scUNBQW9DLDBCQUF5Qjs7Ozt3SkFBN0QsNEJBQTJCLElBQUEsS0FBM0IsNEJBQTJCO1FBQUE7TUFBQSxHQUFBO2lFQUEzQiw4QkFBMkIsV0FBQSxDQUFBLENBQUEseUJBQUEsQ0FBQSxHQUFBLFVBQUEsQ0FBQSx3Q0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxnQkFBQSxtREFBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLGVBQUEsUUFBQSxnQkFBQSxTQUFBLFFBQUEsVUFBQSxHQUFBLGFBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxhQUFBLEdBQUEsQ0FBQSxnQkFBQSw0REFBQSxHQUFBLENBQUEsUUFBQSxvQkFBQSxRQUFBLFFBQUEsR0FBQSxnQkFBQSxRQUFBLEdBQUEsV0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsaUJBQUEsZ0JBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxXQUFBLElBQUEsR0FBQSxZQUFBLEdBQUEsYUFBQSxhQUFBLGNBQUEsbUJBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsZ0JBQUEsdURBQUEsR0FBQSxDQUFBLGdCQUFBLHdEQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxnQkFBQSwwREFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsMkJBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGtCQUFBLFdBQUEsWUFBQSxVQUFBLFlBQUEsR0FBQSxDQUFBLGdCQUFBLHFEQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFNBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHFDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDUHhDLFVBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQXVGLFVBQUEscUJBQUEsR0FBQSxxQkFBQTtBQUFtQixVQUFBLDJCQUFBO0FBQzFHLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUFRLFVBQUEseUJBQUEsU0FBQSxTQUFBLCtEQUFBO0FBQUEsbUJBQVMsSUFBQSxNQUFBO1VBQU8sQ0FBQTtBQUEwRSxVQUFBLDJCQUFBO0FBQ3RHLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxRQUFBLENBQUE7QUFBZ0YsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQXNCLFVBQUEsMkJBQUE7QUFDdEcsVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUFPLFVBQUEseUJBQUEsaUJBQUEsU0FBQSxxRUFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSxhQUFBO1VBQUEsQ0FBQTtBQUFQLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEscURBQUEsR0FBQSxDQUFBO0FBR0osVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsTUFBQSxDQUFBO0FBQUksVUFBQSx5QkFBQSxjQUFBLFNBQUEsaUVBQUE7QUFBQSxtQkFBYyxJQUFBLFNBQUE7VUFBVSxDQUFBLEVBQUMsbUJBQUEsU0FBQSxvRUFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSxjQUFBO1VBQUEsQ0FBQSxFQUFBLG1CQUFBLFNBQUEsb0VBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsZUFBQTtVQUFBLENBQUE7QUFDekIsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxNQUFBO0FBQU0sVUFBQSxxQkFBQSxJQUFBLEdBQUE7QUFBQyxVQUFBLDJCQUFBO0FBQ1AsVUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUEyRSxVQUFBLHFCQUFBLElBQUEsT0FBQTtBQUFLLFVBQUEsMkJBQUE7QUFDaEYsVUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUE0RSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFNLFVBQUEsMkJBQUE7QUFDbEYsVUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUE4RSxVQUFBLHFCQUFBLElBQUEsVUFBQTtBQUFRLFVBQUEsMkJBQUE7QUFDdEYsVUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsK0JBQUEsSUFBQSw2Q0FBQSxJQUFBLEdBQUEsTUFBQSxNQUFBLElBQUEsT0FBQTtBQXVCSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLGtCQUFBLEVBQUE7QUFBZ0IsVUFBQSx5QkFBQSxjQUFBLFNBQUEsMkVBQUEsUUFBQTtBQUFBLG1CQUFjLElBQUEsYUFBQSxNQUFBO1VBQW9CLENBQUEsRUFBQyxjQUFBLFNBQUEsMkVBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsTUFBQSxPQUFBO1VBQUEsQ0FBQTtBQUNuRCxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQTNEbUIsVUFBQSx3QkFBQSxFQUFBO0FBQUEsVUFBQSx5QkFBQSxXQUFBLElBQUEsVUFBQTtBQUNQLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLFVBQUEsS0FBQSxFQUFBO0FBTWtDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsYUFBQSxJQUFBLFdBQUEsRUFBMkIsYUFBQSxJQUFBLFlBQUE7QUFDbkMsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxvQ0FBQSxhQUFBLElBQUEsT0FBQSxFQUFBO0FBRUwsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsTUFBQTtBQUVLLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsb0NBQUEsYUFBQSxJQUFBLE9BQUEsS0FBQTtBQUVMLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLE1BQUE7QUFFSyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLG9DQUFBLGFBQUEsSUFBQSxPQUFBLFlBQUE7QUFFTCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxNQUFBO0FBRUssVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxvQ0FBQSxhQUFBLElBQUEsT0FBQSxRQUFBO0FBRUwsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsTUFBQTtBQU1qQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsUUFBQSxhQUFBO0FBMEJnRCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxNQUFBLElBQUEsRUFBcUIsa0JBQUEsSUFBQSxLQUFBLEVBQUEsV0FBQSxFQUFBLEVBQUEsWUFBQSxJQUFBLE1BQUEsUUFBQSxFQUFBLFVBQUEsSUFBQTs7Ozs7cUZEdkR4RSw2QkFBMkIsRUFBQSxXQUFBLDhCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVB4QyxTQUFTLGFBQUFDLGtCQUFvQztBQUM3QyxTQUFTLGtCQUFBQyx1QkFBc0I7QUFLL0IsU0FBUyxRQUFRLFlBQUFDLFdBQVUsT0FBQUMsTUFBSyxhQUFBQyxrQkFBaUI7QUFFakQsU0FBUyxXQUFBQyxVQUFTLFlBQUFDLGlCQUFnQjtBQUNsQyxTQUFTLGFBQWEsUUFBUSxlQUFlO0FBQzdDLFNBQVMsZ0JBQWdCOzs7Ozs7Ozs7O0FDVHJCLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFBc0IsSUFBQSxxQkFBQSxDQUFBOztBQUFrQyxJQUFBLDJCQUFBO0FBQzVELElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUFIa0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsU0FBQSxDQUFBOzs7OztBQThDa0IsSUFBQSxxQkFBQSxHQUFBLHdEQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFnQyxJQUFBLHFCQUFBLENBQUE7QUFBc0IsSUFBQSwyQkFBQTtBQUMxRCxJQUFBLHFCQUFBLEdBQUEsb0RBQUE7Ozs7QUFEWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFNBQUEsZUFBQSxFQUFBO0FBQXdCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsZUFBQSxLQUFBOzs7OztBQW9DaEMsSUFBQSxxQkFBQSxHQUFBLHdEQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFnQyxJQUFBLHFCQUFBLENBQUE7QUFBc0IsSUFBQSwyQkFBQTtBQUMxRCxJQUFBLHFCQUFBLEdBQUEsb0RBQUE7Ozs7QUFEWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFNBQUEsZUFBQSxFQUFBO0FBQXdCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsZUFBQSxLQUFBOzs7OztBQWN4QyxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG1JQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0Q0FBQTs7OztBQUhVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsb0NBQUEsZ0JBQUEsT0FBQSxnQkFBQSxPQUFBLGFBQUEsQ0FBQTs7Ozs7QUFpQlYsSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw2QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3Q0FBQTs7Ozs7QUFFSSxJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFPSixJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdDQUFBOzs7O0FBTFksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxTQUFBLFlBQUEsVUFBQSxLQUFBLEVBQXNDLFVBQUEsWUFBQSxVQUFBLE1BQUEsRUFBQSxRQUFBLFlBQUEsS0FBQSxLQUFBOzs7OztBQU85QyxJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxNQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdDQUFBOzs7O0FBTGtCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsU0FBQSxTQUFBLFVBQUEsS0FBQSxFQUFtQyxVQUFBLFNBQUEsVUFBQSxNQUFBO0FBQ04sSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxLQUFBLEVBQUEsRUFBYSxLQUFBLFNBQUEsVUFBQSxTQUFBLENBQUE7QUFDaEQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxzREFBQSxTQUFBLE9BQUEsZ0RBQUE7Ozs7OztBQUtSLElBQUEscUJBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsNkJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQW9CLElBQUEseUJBQUEsU0FBQSxTQUFBLDZHQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFdBQUEsWUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLGVBQUEsUUFBQSxDQUFvQjtJQUFBLENBQUE7QUFDN0MsSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0RBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsWUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0RBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3Q0FBQTs7OztBQUxvRSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLHFCQUFBLFNBQUEsZ0JBQUE7QUFBNUIsSUFBQSwwQkFBQSxRQUFBLE1BQUEsU0FBQSxFQUFBO0FBQ3hCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMERBQUEsMEJBQUEsR0FBQSxHQUFBLG9DQUFBLFNBQUEsTUFBQSxZQUFBLENBQUEsRUFBQSxZQUFBLEdBQUEsb0RBQUE7Ozs7OztBQTVHcEIsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUFrQixJQUFBLHFCQUFBLENBQUE7O0FBQXdFLElBQUEsMkJBQUE7QUFDMUYsSUFBQSxxQkFBQSxJQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUtJLElBQUEseUJBQUEsaUJBQUEsU0FBQSxxR0FBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFBLFFBQUEsaUJBQUEsTUFBQTtJQUFBLENBQUEsRUFBNEIsVUFBQSxTQUFBLGdHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUNsQiwwQkFBQSxRQUFBLFNBQUEsQ0FBVTtJQUFBLENBQUE7QUFFcEIsSUFBQSxxQkFBQSxJQUFBLG9EQUFBO0FBQUEsSUFBQSwrQkFBQSxJQUFBLDRFQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7QUFHSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3Q0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxnREFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBa0IsSUFBQSxxQkFBQSxFQUFBOztBQUFzRSxJQUFBLDJCQUFBO0FBQ3hGLElBQUEscUJBQUEsSUFBQSxnREFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFLSSxJQUFBLHlCQUFBLGlCQUFBLFNBQUEscUdBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBQSwwQkFBQSxRQUFBLGVBQUEsTUFBQTtJQUFBLENBQUEsRUFBMEIsVUFBQSxTQUFBLGdHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUNoQiwwQkFBQSxRQUFBLFNBQUEsQ0FBVTtJQUFBLENBQUE7QUFFcEIsSUFBQSxxQkFBQSxJQUFBLHVHQUFBO0FBQ0EsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUFpQyxJQUFBLHFCQUFBLEVBQUE7O0FBQWlFLElBQUEsMkJBQUE7QUFDbEcsSUFBQSxxQkFBQSxJQUFBLG9EQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUF3QixJQUFBLHFCQUFBLEVBQUE7O0FBQWlFLElBQUEsMkJBQUE7QUFDekYsSUFBQSxxQkFBQSxJQUFBLG9EQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUF3QixJQUFBLHFCQUFBLEVBQUE7O0FBQWlFLElBQUEsMkJBQUE7QUFDekYsSUFBQSxxQkFBQSxJQUFBLG9EQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUF3QixJQUFBLHFCQUFBLEVBQUE7O0FBQWlFLElBQUEsMkJBQUE7QUFDN0YsSUFBQSxxQkFBQSxJQUFBLGdEQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0Q0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSw0Q0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0RBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsU0FBQSxFQUFBO0FBQWtCLElBQUEscUJBQUEsRUFBQTs7QUFBd0UsSUFBQSwyQkFBQTtBQUMxRixJQUFBLHFCQUFBLElBQUEsZ0RBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBS0ksSUFBQSx5QkFBQSxpQkFBQSxTQUFBLHFHQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQUEsMEJBQUEsUUFBQSxpQkFBQSxNQUFBO0lBQUEsQ0FBQSxFQUE0QixpQkFBQSxTQUFBLHVHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUNYLDBCQUFBLFFBQUEsU0FBQSxDQUFVO0lBQUEsQ0FBQTtBQUUzQixJQUFBLHFCQUFBLElBQUEsb0RBQUE7QUFBQSxJQUFBLCtCQUFBLElBQUEsNEVBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQUdKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsNENBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsU0FBQSxFQUFBO0FBSUksSUFBQSx5QkFBQSxTQUFBLFNBQUEsOEZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTs7QUFKN0IsSUFBQSwyQkFBQTtBQU9BLElBQUEscUJBQUEsSUFBQSw0Q0FBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxvRkFBQSxHQUFBLENBQUE7QUFLSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxhQUFBLEVBQUE7QUFVSSxJQUFBLHFCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsb0ZBQUEsR0FBQSxHQUFBLGVBQUEsTUFBQSxJQUFBLG9DQUFBO0FBS0EsSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLG9GQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsSUFBQSxvQ0FBQTtBQVdBLElBQUEscUJBQUEsSUFBQSx3Q0FBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxvRkFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLElBQUEsb0NBQUE7QUFRQSxJQUFBLHFCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsb0ZBQUEsSUFBQSxHQUFBLGVBQUEsTUFBQSxJQUFBLG9DQUFBO0FBVUosSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQ0FBQTs7OztBQS9Ha0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLElBQUEsK0NBQUEsQ0FBQTtBQUVkLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSw4QkFBQSxJQUFBLEtBQUEsT0FBQSxrQkFBQSxPQUFBLHdCQUFBLElBQUEsQ0FBQSxFQUErRSxXQUFBLE9BQUEsY0FBQTtBQU8vRSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsWUFBQTtBQVFjLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLDZDQUFBLENBQUE7QUFFZCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsOEJBQUEsSUFBQSxLQUFBLE9BQUEsa0JBQUEsT0FBQSx3QkFBQSxJQUFBLENBQUEsRUFBK0UsV0FBQSxPQUFBLFlBQUE7QUFROUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxJQUFBLElBQUEsd0NBQUEsQ0FBQTtBQUNULElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLHdDQUFBLENBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSx3Q0FBQSxDQUFBO0FBQ0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxJQUFBLElBQUEsd0NBQUEsQ0FBQTtBQU1WLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLCtDQUFBLENBQUE7QUFFZCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsOEJBQUEsSUFBQSxLQUFBLE9BQUEsa0JBQUEsT0FBQSx3QkFBQSxJQUFBLENBQUEsRUFBK0UsV0FBQSxPQUFBLGNBQUE7QUFPL0UsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxPQUFBLFlBQUE7QUFVSixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLG9DQUFBLFNBQUEsMEJBQUEsSUFBQSxJQUFBLCtDQUFBLENBQUE7QUFFQSxJQUFBLHlCQUFBLFlBQUEsQ0FBQSxPQUFBLGtCQUFBLENBQUEsT0FBQSxrQkFBQSxDQUFBLE9BQUEsZ0JBQUEsT0FBQSxrQkFBQSxPQUFBLHdCQUFBLElBQUE7QUFFSixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxrQkFBQSxPQUFBLHdCQUFBLE9BQUEsS0FBQSxFQUFBO0FBVUosSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLEtBQUEsRUFBb0IsbUJBQUEsS0FBQSxFQUFBLFNBQUEsT0FBQSxLQUFBLEVBQUEsU0FBQSxPQUFBLEtBQUEsRUFBQSxZQUFBLE9BQUEsUUFBQSxFQUFBLFdBQUEsT0FBQSxPQUFBOzs7OztBQTJFaEIsSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0NBQUE7Ozs7O0FBSGlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLFFBQUEsZUFBQSxRQUFBLENBQUEsRUFBcUMsY0FBQSxJQUFBO0FBQzlDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsa0RBQUEsMEJBQUEsR0FBQSxHQUFBLFFBQUEsZUFBQSxlQUFBLFFBQUEsQ0FBQSxHQUFBLDRDQUFBOzs7Ozs7QUFaaEIsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUF3RSxJQUFBLHFCQUFBLENBQUE7QUFBbUIsSUFBQSwyQkFBQTtBQUMvRixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsS0FBQSxFQUFBO0FBQXdFLElBQUEscUJBQUEsRUFBQTtBQUFzQixJQUFBLDJCQUFBO0FBQ2xHLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsMkZBQUEsR0FBQSxDQUFBO0FBTUosSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxFQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLG1CQUFBLEVBQUE7QUFNSixJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsRUFBQTs7QUFBaUYsSUFBQSwyQkFBQTtBQUMzRixJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxLQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsNENBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsV0FBQSxDQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLDRDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUFpQyxJQUFBLHFCQUFBLEVBQUE7O0FBQTZDLElBQUEsMkJBQUE7QUFDbEYsSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFLSSxJQUFBLHlCQUFBLFVBQUEsU0FBQSx1R0FBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxpQkFBQSxZQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFVLDBCQUFBLFFBQUEsaUJBQUEsZUFBQSxFQUFBLENBQWdDO0lBQUEsQ0FBQTtBQUcxQyxJQUFBLHFCQUFBLElBQUEsNENBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsV0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRCQUFBOzs7Ozs7OztBQS9DUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHFDQUFBLE1BQUEsbUJBQUEsT0FBQSxFQUFBO0FBRU8sSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLDhCQUFBLElBQUEsS0FBQSxRQUFBLFVBQUEsZUFBQSxFQUFBLENBQUE7QUFBcUUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxlQUFBLEVBQUE7QUFHckUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLDhCQUFBLElBQUEsS0FBQSxRQUFBLFVBQUEsZUFBQSxFQUFBLENBQUE7QUFBcUUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxlQUFBLEtBQUE7QUFFeEUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLGVBQUEsYUFBQSw0QkFBQTtBQUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxlQUFBLFdBQUEsS0FBQSxFQUFBO0FBUUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQ0FBQSwwQkFBQSxJQUFBLElBQUEsZUFBQSxXQUFBLEdBQUEsb0NBQUE7QUFLSSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGFBQUEsSUFBQSxFQUFrQixVQUFBLFVBQUEsZUFBQSxrQkFBQSxPQUFBLE9BQUEsZUFBQSxlQUFBLDhCQUFBLFFBQUEsWUFBQSxTQUFBLFVBQUEsQ0FBQSxFQUFBLFFBQUEsV0FBQSxlQUFBLGtCQUFBLE9BQUEsT0FBQSxlQUFBLGVBQUEsc0JBQUEsUUFBQSxhQUFBLFNBQUEsV0FBQSxDQUFBO0FBTWhCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLHFCQUFBLGVBQUEsV0FBQSxRQUFBLEtBQUEsQ0FBQTtBQUc0QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGNBQUEsOEJBQUEsSUFBQSxLQUFBLFFBQUEsVUFBQSxlQUFBLEVBQUEsQ0FBQTtBQUNyQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxXQUFBO0FBQ3dCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLG9CQUFBLENBQUE7QUFJakMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxlQUFBLGVBQUEsU0FBQSxFQUFBLEVBQXNDLGtCQUFBLHNEQUFBLEVBQUEsMEJBQUEsK0RBQUEsRUFBQSxlQUFBLFFBQUEsWUFBQTtBQU03QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxPQUFBOzs7OztBQTFEakMsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQSxFQUFJLEdBQUEsUUFBQSxFQUFBO0FBQXFDLElBQUEscUJBQUEsR0FBQSxJQUFBO0FBQUUsSUFBQSwyQkFBQSxFQUFPO0FBQ2xELElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLEVBQUE7QUFBaUQsSUFBQSxxQkFBQSxJQUFBLE9BQUE7QUFBSyxJQUFBLDJCQUFBLEVBQU87QUFDakUsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQSxFQUFnQixJQUFBLFFBQUEsRUFBQTtBQUF1RCxJQUFBLHFCQUFBLElBQUEsYUFBQTtBQUFXLElBQUEsMkJBQUEsRUFBTztBQUN6RixJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxFQUFBO0FBQW9ELElBQUEscUJBQUEsSUFBQSxVQUFBO0FBQVEsSUFBQSwyQkFBQSxFQUFPO0FBQ3ZFLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLEVBQUE7QUFBdUQsSUFBQSxxQkFBQSxJQUFBLFVBQUE7QUFBUSxJQUFBLDJCQUFBLEVBQU87QUFDMUUsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQSxFQUFtQyxJQUFBLFFBQUEsRUFBQTtBQUE0RCxJQUFBLHFCQUFBLElBQUEsbUJBQUE7QUFBaUIsSUFBQSwyQkFBQSxFQUFPO0FBQ3ZILElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLEVBQUE7QUFBb0QsSUFBQSxxQkFBQSxJQUFBLFVBQUE7QUFBUSxJQUFBLDJCQUFBLEVBQU87QUFDdkUsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLElBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwrQkFBQSxJQUFBLDRFQUFBLElBQUEsSUFBQSxNQUFBLE1BQUEsa0NBQUEsRUFBQSxRQUFBO0FBaURKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBOzs7O0FBbkRZLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEseUJBQUEsT0FBQSxZQUFBOzs7OztBQXVGZ0IsSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0NBQUE7Ozs7O0FBSGlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLFFBQUEsaUJBQUEsUUFBQSxDQUFBLEVBQXVDLGNBQUEsSUFBQTtBQUNoRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtEQUFBLDBCQUFBLEdBQUEsR0FBQSxRQUFBLGVBQUEsaUJBQUEsUUFBQSxDQUFBLEdBQUEsNENBQUE7Ozs7O0FBTUosSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQTJGLElBQUEscUJBQUEsQ0FBQTtBQUFnQyxJQUFBLDJCQUFBO0FBQy9ILElBQUEscUJBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0NBQUE7Ozs7QUFGVyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGNBQUEsOEJBQUEsR0FBQSxLQUFBLGlCQUFBLE9BQUEsRUFBQSxDQUFBO0FBQXdGLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsaUJBQUEsT0FBQSxLQUFBOzs7Ozs7QUFuQjNHLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUNKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUNKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsMkZBQUEsR0FBQSxDQUFBO0FBTUosSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDJGQUFBLEdBQUEsQ0FBQTtBQUtKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUEyRCxJQUFBLHlCQUFBLFNBQUEsU0FBQSxzR0FBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxtQkFBQSxZQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsbUJBQUEsaUJBQUEsRUFBQSxDQUFvQztJQUFBLENBQUE7QUFDcEcsSUFBQSxxQkFBQSxJQUFBLDRDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUFxQyxJQUFBLHFCQUFBLEVBQUE7O0FBQ3pDLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTs7Ozs7O0FBN0JRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEscUNBQUEsTUFBQSxtQkFBQSxPQUFBLEVBQUE7QUFFSSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDBDQUFBLGlCQUFBLElBQUEsb0NBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDBDQUFBLGlCQUFBLE9BQUEsb0NBQUE7QUFFQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGFBQUEsaUJBQUEsYUFBQSw0QkFBQTtBQUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxpQkFBQSxXQUFBLEtBQUEsRUFBQTtBQVFBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxpQkFBQSxTQUFBLEtBQUEsRUFBQTtBQVFhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLE9BQUE7QUFBNEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxLQUFBLDBCQUFBLElBQUEsR0FBQSw2Q0FBQSxHQUFBLHdDQUFBOzs7OztBQXRDN0QsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQSxFQUFJLEdBQUEsUUFBQSxFQUFBO0FBQXFDLElBQUEscUJBQUEsR0FBQSxJQUFBO0FBQUUsSUFBQSwyQkFBQSxFQUFPO0FBQ2xELElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLEVBQUE7QUFBaUQsSUFBQSxxQkFBQSxJQUFBLE9BQUE7QUFBSyxJQUFBLDJCQUFBLEVBQU87QUFDakUsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQSxFQUFnQixJQUFBLFFBQUEsRUFBQTtBQUF1RCxJQUFBLHFCQUFBLElBQUEsYUFBQTtBQUFXLElBQUEsMkJBQUEsRUFBTztBQUN6RixJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxFQUFBO0FBQW9ELElBQUEscUJBQUEsSUFBQSxVQUFBO0FBQVEsSUFBQSwyQkFBQSxFQUFPO0FBQ3ZFLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLEVBQUE7QUFBa0QsSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBTSxJQUFBLDJCQUFBLEVBQU87QUFDbkUsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLElBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwrQkFBQSxJQUFBLDRFQUFBLElBQUEsSUFBQSxNQUFBLE1BQUEsa0NBQUEsRUFBQSxRQUFBO0FBK0JKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBOzs7O0FBakNZLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEseUJBQUEsT0FBQSxhQUFBOzs7Ozs7QUFoUHBCLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUFrRSxJQUFBLHFCQUFBLEdBQUEsdUJBQUE7QUFBcUIsSUFBQSwyQkFBQTtBQUN2RixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsNEJBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUE0RCxJQUFBLHlCQUFBLFNBQUEsU0FBQSxnRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxnQkFBQSxDQUFpQjtJQUFBLENBQUE7QUFDbEYsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxFQUFBOztBQUEwRSxJQUFBLDJCQUFBO0FBQ3BGLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsS0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxFQUFBOztBQUEwRSxJQUFBLDJCQUFBO0FBQ3BGLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsRUFBQTs7QUFBNkUsSUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUFzRCxJQUFBLHFCQUFBLElBQUEsTUFBQTtBQUFJLElBQUEsMkJBQUE7QUFDM0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxxRUFBQSxJQUFBLElBQUEsYUFBQTtBQW9ISixJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLHFFQUFBLElBQUEsQ0FBQTtBQW1FSixJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUFnRixJQUFBLHFCQUFBLElBQUEseUJBQUE7QUFBdUIsSUFBQSwyQkFBQTtBQUN2RyxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUEyQixJQUFBLHlCQUFBLFNBQUEsU0FBQSwyRUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSwrQkFBQSxDQUFnQztJQUFBLENBQUE7QUFDaEUsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxFQUFBOztBQUF3RixJQUFBLDJCQUFBO0FBQ2xHLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLHFFQUFBLElBQUEsQ0FBQTtBQStDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLElBQUE7Ozs7QUFoUjBDLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLGlCQUFBO0FBSWIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsTUFBQTtBQUNILElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLGlEQUFBLENBQUE7QUFFaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLDhCQUFBLElBQUEsS0FBQSxPQUFBLFFBQUEsQ0FBQTtBQUNkLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLE1BQUE7QUFDSCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSxpREFBQSxDQUFBO0FBS0ksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxlQUFBLElBQUE7QUFJRixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtDQUFBLDBCQUFBLElBQUEsSUFBQSxvREFBQSxHQUFBLEVBQUE7QUErSGhCLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLGFBQUEsU0FBQSxLQUFBLEVBQUE7QUF3RWlCLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLE1BQUE7QUFDSCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSwrREFBQSxDQUFBO0FBS2QsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsY0FBQSxTQUFBLEtBQUEsRUFBQTs7O0FEM09aLDZCQXFCYSwrQkE2WEEsUUFnREE7QUFsY2I7O0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFJQTtBQUVBOzs7Ozs7Ozs7Ozs7O0FBUU0sSUFBTyxnQ0FBUCxNQUFPLCtCQUE2QjtNQThCMUI7TUFDQTtNQUNBO01BQ0E7TUFoQ1o7TUFDQSxZQUFZO01BQ1osZUFBNkIsQ0FBQTtNQUM3QixnQkFBOEIsQ0FBQTtNQUU5QjtNQUNBO01BQ0E7TUFDQSxRQUFnQixDQUFBO01BQ2hCLFFBQWdCLENBQUE7TUFDaEIsV0FBMEIsQ0FBQTtNQUMxQiwwQkFBMEI7TUFDMUIsZ0JBQXlDLHdCQUF3QjtNQUV6RCxvQkFBb0IsSUFBSUQsU0FBTztNQUN2QyxlQUFlLEtBQUssa0JBQWtCLGFBQVk7TUFFbEQsVUFBNEIsSUFBSUEsU0FBTztNQUU5QixVQUFVO01BQ1YsaUJBQWlCO01BQ2pCLG9CQUF1QztNQUdoRCxTQUFTO01BQ1QsVUFBVTtNQUNWLGNBQWM7TUFFZCxZQUNZLGdCQUNBLG1CQUNBLGNBQ0EsY0FBc0I7QUFIdEIsYUFBQSxpQkFBQTtBQUNBLGFBQUEsb0JBQUE7QUFDQSxhQUFBLGVBQUE7QUFDQSxhQUFBLGVBQUE7TUFDVDtNQUVILGNBQVc7QUFDUCxhQUFLLGtCQUFrQixZQUFXO01BQ3RDO01BRUEsV0FBUTtBQUNKLGFBQUssZUFBZSxPQUFRLE9BQU8sVUFBVSxDQUFDLFdBQVU7QUFDcEQsZUFBSyxXQUFXLE9BQU8sVUFBVTtBQUNqQyxjQUFJLEtBQUssVUFBVTtBQUNmLGlCQUFLLFNBQVE7O1FBRXJCLENBQUM7TUFDTDtNQUVBLFdBQVE7QUFDSixZQUFJLEtBQUssa0JBQWtCLEtBQUssa0JBQWtCLEtBQUssZ0JBQWdCLEtBQUssbUJBQW1CLEtBQUssZ0JBQWdCO0FBQ2hILGVBQUssZ0JBQWdCLHdCQUF3QjtBQUM3Qzs7QUFFSixZQUFJLEtBQUsseUJBQXdCLEdBQUk7QUFDakMsZUFBSyxnQkFBZ0Isd0JBQXdCO0FBQzdDOztBQUVKLFlBQUksS0FBSyx5QkFBd0IsR0FBSTtBQUNqQyxlQUFLLGdCQUFnQix3QkFBd0I7QUFDN0M7O0FBRUosYUFBSyxnQkFBZ0Isd0JBQXdCO01BQ2pEO01BRUEsZ0JBQWdCLE9BQThCO0FBQzFDLGdCQUFRLE9BQU87VUFDWCxLQUFLLHdCQUF3QixVQUFVO0FBQ25DLG1CQUFPOztVQUVYLEtBQUssd0JBQXdCLFVBQVU7QUFDbkMsbUJBQU87O1VBRVgsS0FBSyx3QkFBd0IsTUFBTTtBQUMvQixtQkFBTzs7VUFFWCxLQUFLLHdCQUF3QixNQUFNO0FBQy9CLGtCQUFNLElBQUksVUFBVSxpREFBaUQ7OztNQUdqRjtNQUVBLFNBQVMsT0FBZSxZQUFzQjtBQUMxQyxlQUFPLEdBQUcsS0FBSyxJQUFJLFdBQVcsRUFBRTtNQUNwQztNQUVBLGlCQUFpQixjQUFvQjtBQUNqQyxhQUFLLGtCQUFrQixPQUFPLGNBQWMsS0FBSyxRQUFRLEVBQUUsVUFBVTtVQUNqRSxNQUFNLE1BQUs7QUFDUCxpQkFBSyxrQkFBa0IsS0FBSyxFQUFFO0FBQzlCLGlCQUFLLFNBQVE7VUFDakI7VUFDQSxPQUFPLENBQUMsVUFBNkIsS0FBSyxrQkFBa0IsS0FBSyxNQUFNLE9BQU87U0FDakY7TUFDTDtNQUVBLG1CQUFtQixjQUFvQjtBQUNuQyxhQUFLLGtCQUFrQixtQkFBbUIsY0FBYyxLQUFLLFFBQVEsRUFBRSxVQUFVO1VBQzdFLE1BQU0sTUFBSztBQUNQLGlCQUFLLGtCQUFrQixLQUFLLEVBQUU7QUFDOUIsaUJBQUssU0FBUTtVQUNqQjtVQUNBLE9BQU8sQ0FBQyxVQUE2QixLQUFLLGtCQUFrQixLQUFLLE1BQU0sT0FBTztTQUNqRjtNQUNMO01BRUEsV0FBUTtBQUNKLGFBQUssWUFBWTtBQUNqQixhQUFLLGtCQUNBLDZCQUE2QixLQUFLLFFBQVEsRUFDMUMsS0FBS0YsS0FBSSxDQUFDLGFBQXlDLFNBQVMsSUFBSyxDQUFDLEVBQ2xFLFVBQVU7VUFDUCxNQUFNLENBQUMsaUJBQWdCO0FBQ25CLGlCQUFLLGdCQUFnQjtVQUN6QjtVQUNBLE9BQU8sQ0FBQyxrQkFBcUMsUUFBUSxLQUFLLGNBQWMsYUFBYTtTQUN4RjtBQUNMLGFBQUssa0JBQ0EsZ0JBQWdCLEtBQUssUUFBUSxFQUM3QixLQUNHQyxXQUFVLENBQUMsUUFBTztBQUNkLGVBQUssZUFBZSxJQUFJO0FBRXhCLGVBQUssUUFBUSxLQUFLLGFBQWEsSUFDM0IsQ0FBQyxnQkFBc0I7WUFDbkIsSUFBSSxHQUFHLFdBQVcsRUFBRTtZQUNwQixPQUFPLFdBQVc7WUFDcEI7QUFHTixnQkFBTSxzQkFBc0IsS0FBSyxhQUFhLElBQUksQ0FBQyxPQUFNO0FBQ3JELG1CQUFPLEtBQUssa0JBQWtCLHVCQUF1QixHQUFHLElBQUssS0FBSyxRQUFRO1VBQzlFLENBQUM7QUFFRCxnQkFBTSxxQkFBcUIsS0FBSyxhQUFhLElBQUksQ0FBQyxPQUFNO0FBQ3BELG1CQUFPLEtBQUssa0JBQWtCLGtCQUFrQixHQUFHLElBQUssS0FBSyxRQUFRO1VBQ3pFLENBQUM7QUFFRCxpQkFBT0UsVUFBUyxDQUFDQSxVQUFTLG1CQUFtQixHQUFHQSxVQUFTLGtCQUFrQixDQUFDLENBQUM7UUFDakYsQ0FBQyxDQUFDLEVBRUwsS0FDR0osVUFBUyxNQUFLO0FBQ1YsZUFBSyxZQUFZO1FBQ3JCLENBQUMsQ0FBQyxFQUVMLFVBQVU7VUFDUCxNQUFNLENBQUMsQ0FBQyxxQkFBcUIsMkJBQTJCLE1BQUs7QUFDekQsa0JBQU0sWUFBWTtjQUNkLEdBQUcsb0JBQ0UsUUFBUSxDQUFDLGFBQWEsU0FBUyxJQUFLLEVBQ3BDLE9BQU8sQ0FBQyxHQUFHLE1BQUs7QUFDYixrQkFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDO0FBQ2IsdUJBQU87Y0FDWCxHQUFHLG9CQUFJLElBQUcsQ0FBRSxFQUNYLE9BQU07O0FBRWYsaUJBQUssUUFBUSxVQUFVLElBQ25CLENBQUMsY0FBb0I7Y0FDakIsSUFBSSxPQUFPLFNBQVMsRUFBRTtjQUN0QixRQUFRLEdBQUcsU0FBUyxnQkFBZ0IsRUFBRTtjQUN0QyxRQUFRLEdBQUcsU0FBUyxnQkFBZ0IsRUFBRTtjQUN0QyxPQUFPLFNBQVM7Y0FDaEIsTUFBTTtnQkFDRixJQUFJLFNBQVM7O2NBRW5CO0FBRU4saUJBQUssV0FBVyxVQUNYLE9BQU8sQ0FBQyxhQUFhLFNBQVMsU0FBUyxhQUFhLEVBQ3BELElBQ0csQ0FBQyxjQUEyQjtjQUN4QixJQUFJLFVBQVUsU0FBUyxFQUFFO2NBQ3pCLE9BQU8sU0FBUztjQUNoQixjQUFjLENBQUMsR0FBRyxTQUFTLGdCQUFnQixFQUFFLElBQUksR0FBRyxTQUFTLGdCQUFnQixFQUFFLEVBQUU7Y0FDakYsTUFBTTtnQkFDRixJQUFJLFNBQVM7O2NBRW5CO0FBR1YsdUJBQVcsOEJBQThCLDZCQUE2QjtBQUNsRSxvQkFBTSwyQkFBcUQsMkJBQTJCO0FBQ3RGLG1CQUFLLGFBQWEsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPLHlCQUF5QixZQUFZLEVBQUcsaUJBQWlCOztVQUUxRztVQUNBLE9BQU8sQ0FBQyxrQkFBcUMsUUFBUSxLQUFLLGNBQWMsYUFBYTtTQUN4RjtNQUNUO01BS0EsaUNBQThCO0FBQzFCLGNBQU0sV0FBVyxLQUFLLGFBQWEsS0FBSyw2QkFBNkIsRUFBRSxNQUFNLE1BQU0sVUFBVSxTQUFRLENBQUU7QUFDdkcsaUJBQVMsa0JBQWtCLGNBQWMsS0FBSyxhQUFhLE9BQU8sS0FBSyxhQUFhLEVBQUUsSUFBSSxDQUFDLGVBQWUsV0FBVyxFQUFFO0FBQ3ZILGlCQUFTLE9BQU8sS0FBSyxDQUFDLFdBQXNCO0FBQ3hDLGVBQUssa0JBQ0EsZ0JBQWdCLE9BQU8sSUFBSyxLQUFLLFFBQVEsRUFDekMsS0FDRyxPQUFPLENBQUMsUUFBa0MsSUFBSSxFQUFFLEdBQ2hEQyxLQUFJLENBQUMsUUFBa0MsSUFBSSxJQUFJLENBQUMsRUFFbkQsVUFBVTtZQUNQLE1BQU0sQ0FBQyxRQUFtQjtBQUN0QixtQkFBSyxjQUFjLEtBQUssR0FBRztZQUMvQjtZQUNBLE9BQU8sQ0FBQyxRQUEyQixRQUFRLEtBQUssY0FBYyxHQUFHO1dBQ3BFO1FBQ1QsQ0FBQztNQUNMO01BS0Esa0JBQWU7QUFDWCxjQUFNLFdBQVcsS0FBSyxhQUFhLEtBQUssMkJBQTJCLEVBQUUsTUFBTSxNQUFNLFVBQVUsU0FBUSxDQUFFO0FBQ3JHLGlCQUFTLGtCQUFrQixjQUFjLEtBQUssYUFBYSxPQUFPLEtBQUssYUFBYSxFQUFFLElBQUksQ0FBQyxlQUFlLFdBQVcsRUFBRTtBQUN2SCxpQkFBUyxPQUFPLEtBQUssQ0FBQyx1QkFBa0M7QUFDcEQsZUFBSyxrQkFDQSxPQUFPLG9CQUFvQixLQUFLLFFBQVEsRUFDeEMsS0FDRyxPQUFPLENBQUMsUUFBa0MsSUFBSSxFQUFFLEdBQ2hEQSxLQUFJLENBQUMsUUFBa0MsSUFBSSxJQUFJLENBQUMsRUFFbkQsVUFBVTtZQUNQLE1BQU0sQ0FBQyxRQUFtQjtBQUN0QixtQkFBSyxhQUFhLEtBQUssR0FBRztZQUM5QjtZQUNBLE9BQU8sQ0FBQyxRQUEyQixRQUFRLEtBQUssY0FBYyxHQUFHO1dBQ3BFO1FBQ1QsQ0FBQztNQUNMO01BRUEsaUJBQWM7QUFDVixZQUFJLEtBQUssa0JBQWtCLHdCQUF3QixNQUFNO0FBQ3JELGtCQUFRLEtBQUssZUFBZTtZQUN4QixLQUFLLHdCQUF3QixVQUFVO0FBQ25DLG9CQUFNLElBQUksVUFBVSxnREFBZ0Q7O1lBRXhFLEtBQUssd0JBQXdCLFVBQVU7QUFDbkMsb0JBQU0sSUFBSSxVQUFVLDBEQUEwRDs7WUFFbEYsS0FBSyx3QkFBd0IsTUFBTTtBQUMvQixvQkFBTSxJQUFJLFVBQVUsNkNBQTZDOzs7O0FBSTdFLGFBQUssa0JBQ0EseUJBQXlCLEtBQUssZ0JBQWlCLEtBQUssZ0JBQWlCLEtBQUssY0FBZSxLQUFLLFFBQVEsRUFDdEcsS0FDRyxPQUFPLENBQUMsUUFBMEMsSUFBSSxFQUFFLEdBQ3hEQSxLQUFJLENBQUMsUUFBMEMsSUFBSSxJQUFJLENBQUMsRUFFM0QsVUFBVTtVQUNQLE1BQU0sQ0FBQyxhQUFZO0FBQ2YsZ0JBQUksVUFBVTtBQUNWLG1CQUFLLE1BQU0sS0FBSztnQkFDWixJQUFJLE9BQU8sU0FBUyxFQUFFO2dCQUN0QixRQUFRLEdBQUcsU0FBUyxnQkFBZ0IsRUFBRTtnQkFDdEMsUUFBUSxHQUFHLFNBQVMsZ0JBQWdCLEVBQUU7Z0JBQ3RDLE9BQU8sU0FBUztnQkFDaEIsTUFBTTtrQkFDRixJQUFJLFNBQVM7O2VBRXBCO0FBQ0QsbUJBQUssUUFBUSxLQUFLLElBQUk7O1VBRTlCO1VBQ0EsT0FBTyxDQUFDLFFBQTJCLFFBQVEsS0FBSyxjQUFjLEdBQUc7U0FDcEU7TUFDVDtNQUVBLGVBQWUsTUFBVTtBQUNyQixhQUFLLGtCQUFrQix5QkFBeUIsT0FBTyxLQUFLLE1BQU0sR0FBRyxPQUFPLEtBQUssS0FBSyxFQUFFLEdBQUcsS0FBSyxRQUFRLEVBQUUsVUFBVTtVQUNoSCxNQUFNLE1BQUs7QUFDUCxrQkFBTSxRQUFRLEtBQUssTUFBTSxVQUFVLENBQUMsTUFBTSxFQUFFLE9BQU8sS0FBSyxFQUFFO0FBQzFELGlCQUFLLE1BQU0sT0FBTyxPQUFPLENBQUM7QUFDMUIsaUJBQUssUUFBUSxLQUFLLElBQUk7VUFDMUI7VUFDQSxPQUFPLENBQUMsUUFBMkIsUUFBUSxLQUFLLGNBQWMsR0FBRztTQUNwRTtNQUNMO01BRVEsMkJBQXdCO0FBQzVCLFlBQUksS0FBSyxtQkFBbUIsS0FBSyxnQkFBZ0I7QUFDN0MsaUJBQU8sQ0FBQyxFQUNKLEtBQUssa0JBQ0wsS0FBSyxrQkFDTCxLQUFLLGdCQUNMLEtBQUssMkJBQTJCLEtBQUssT0FBTyxLQUFLLE9BQU87WUFDcEQsUUFBUSxLQUFLLGlCQUFrQjtZQUMvQixRQUFRLEtBQUssaUJBQWtCO1lBQy9CLE9BQU8sS0FBSztXQUNQO2VBRVY7QUFDSCxpQkFBTzs7TUFFZjtNQUVRLDJCQUF3QjtBQUM1QixlQUFPLEtBQUssTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLFdBQVcsS0FBSyxnQkFBZ0IsU0FBUSxLQUFNLEtBQUssV0FBVyxLQUFLLGdCQUFnQixTQUFRLENBQUUsTUFBTTtNQUM3STtNQVVRLDJCQUEyQixPQUFlLE9BQWUsV0FBZTtBQUM1RSxjQUFNLG1CQUFtQixLQUFLLE1BQU0sS0FBSyxVQUFVLEtBQUssQ0FBQztBQUN6RCx5QkFBaUIsS0FBSyxTQUFTO0FBQy9CLGNBQU0sUUFBUSxJQUFJLE1BQUs7QUFDdkIsbUJBQVcsUUFBUSxPQUFPO0FBQ3RCLGdCQUFNLFVBQVUsSUFBSSxPQUFPLEtBQUssRUFBRSxDQUFDOztBQUV2QyxtQkFBVyxRQUFRLGtCQUFrQjtBQUNqQyxnQkFBTSxhQUFhLE1BQU0sU0FBUyxLQUFLLENBQUMsV0FBbUIsT0FBTyxTQUFRLE1BQU8sS0FBSyxNQUFNO0FBQzVGLGdCQUFNLGFBQWEsTUFBTSxTQUFTLEtBQUssQ0FBQyxXQUFtQixPQUFPLFNBQVEsTUFBTyxLQUFLLE1BQU07QUFDNUYsY0FBSSxlQUFlLFVBQWEsZUFBZSxRQUFXO0FBQ3RELGtCQUFNLElBQUksVUFBVSx3Q0FBd0M7O0FBSWhFLGtCQUFRLEtBQUssT0FBTztZQUNoQixLQUFLO1lBQ0wsS0FBSyxXQUFXO0FBQ1osb0JBQU0sUUFBUSxZQUFZLFVBQVU7QUFDcEM7Ozs7QUFLWixtQkFBVyxRQUFRLGtCQUFrQjtBQUNqQyxjQUFJLEtBQUssVUFBVSxXQUFXO0FBQzFCLGtCQUFNLGFBQWEsTUFBTSxTQUFTLEtBQUssQ0FBQyxXQUFtQixPQUFPLFNBQVEsTUFBTyxLQUFLLE1BQU07QUFDNUYsa0JBQU0sYUFBYSxNQUFNLFNBQVMsS0FBSyxDQUFDLFdBQW1CLE9BQU8sU0FBUSxNQUFPLEtBQUssTUFBTTtBQUM1RixnQkFBSSxlQUFlLFVBQWEsZUFBZSxRQUFXO0FBQ3RELG9CQUFNLElBQUksVUFBVSx3Q0FBd0M7O0FBRWhFLGdCQUFJLFdBQVcsaUJBQWdCLEVBQUcsU0FBUyxVQUFVLEtBQUssV0FBVyxpQkFBZ0IsRUFBRyxTQUFTLFVBQVUsR0FBRztBQUMxRyxxQkFBTzs7QUFHWCxrQkFBTSxlQUFlLElBQUksT0FBTyxXQUFXLFNBQVEsSUFBSyxPQUFPLFdBQVcsU0FBUSxDQUFFO0FBRXBGLHlCQUFhLGlCQUFnQixFQUFHLEtBQUssR0FBRyxXQUFXLGlCQUFnQixDQUFFO0FBQ3JFLHlCQUFhLGlCQUFnQixFQUFHLEtBQUssR0FBRyxXQUFXLGlCQUFnQixDQUFFO0FBRXJFLHVCQUFXLFVBQVUsTUFBTSxVQUFVO0FBQ2pDLHlCQUFXLGtCQUFrQixPQUFPLGlCQUFnQixHQUFJO0FBQ3BELG9CQUFJLGVBQWUsU0FBUSxNQUFPLFdBQVcsU0FBUSxLQUFNLGVBQWUsU0FBUSxNQUFPLFdBQVcsU0FBUSxHQUFJO0FBQzVHLHdCQUFNLFFBQVEsT0FBTyxpQkFBZ0IsRUFBRyxRQUFRLGdCQUFnQixDQUFDO0FBQ2pFLHNCQUFJLFFBQVEsSUFBSTtBQUNaLDJCQUFPLGlCQUFnQixFQUFHLE9BQU8sT0FBTyxDQUFDOztBQUU3Qyx5QkFBTyxpQkFBZ0IsRUFBRyxLQUFLLFlBQVk7Ozs7OztBQU0vRCxlQUFPLE1BQU0sU0FBUTtNQUN6Qjs7eUJBL1dTLGdDQUE2QixnQ0FBQSxrQkFBQSxHQUFBLGdDQUFBLGlCQUFBLEdBQUEsZ0NBQUEsWUFBQSxHQUFBLGdDQUFBLFlBQUEsQ0FBQTtNQUFBO2lFQUE3QixnQ0FBNkIsV0FBQSxDQUFBLENBQUEsMkJBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxVQUFBLHdCQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLFVBQUEsb0JBQUEsR0FBQSxDQUFBLGdCQUFBLGdEQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxpQkFBQSxxQkFBQSxHQUFBLENBQUEsTUFBQSwwQkFBQSxHQUFBLE9BQUEsZUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLGVBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsUUFBQSxRQUFBLFFBQUEsUUFBQSxHQUFBLENBQUEsZ0JBQUEsSUFBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLG9CQUFBLEVBQUEsR0FBQSxDQUFBLHNCQUFBLEVBQUEsR0FBQSxDQUFBLHNCQUFBLEVBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxnQkFBQSxtQkFBQSxNQUFBLEdBQUEsQ0FBQSx3QkFBQSxFQUFBLEdBQUEsQ0FBQSxvQkFBQSxFQUFBLEdBQUEsQ0FBQSxHQUFBLG1CQUFBLEdBQUEsY0FBQSxPQUFBLEdBQUEsQ0FBQSxnQkFBQSw4REFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLGVBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsT0FBQSxPQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsT0FBQSxNQUFBLEdBQUEsQ0FBQSxNQUFBLFFBQUEsUUFBQSxRQUFBLEdBQUEsZUFBQSxHQUFBLFdBQUEsV0FBQSxpQkFBQSxRQUFBLEdBQUEsQ0FBQSxPQUFBLE1BQUEsR0FBQSxDQUFBLE1BQUEsUUFBQSxRQUFBLFFBQUEsR0FBQSxlQUFBLEdBQUEsV0FBQSxXQUFBLGlCQUFBLFFBQUEsR0FBQSxDQUFBLFNBQUEsV0FBQSxZQUFBLEVBQUEsR0FBQSxDQUFBLFNBQUEsU0FBQSxHQUFBLENBQUEsU0FBQSxTQUFBLEdBQUEsQ0FBQSxTQUFBLFNBQUEsR0FBQSxDQUFBLE9BQUEsTUFBQSxHQUFBLENBQUEsTUFBQSxRQUFBLFFBQUEsUUFBQSxHQUFBLGVBQUEsR0FBQSxXQUFBLFdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxPQUFBLGVBQUEsR0FBQSxTQUFBLFlBQUEsT0FBQSxHQUFBLENBQUEsVUFBQSxnQkFBQSxHQUFBLE9BQUEsbUJBQUEsR0FBQSxjQUFBLG1CQUFBLFNBQUEsU0FBQSxZQUFBLFNBQUEsR0FBQSxDQUFBLGdCQUFBLEVBQUEsR0FBQSxDQUFBLG1CQUFBLEVBQUEsR0FBQSxDQUFBLGdCQUFBLEVBQUEsR0FBQSxDQUFBLGdCQUFBLEVBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSwyQkFBQSxHQUFBLG9CQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSxTQUFBLFdBQUEsY0FBQSxRQUFBLEtBQUEsUUFBQSxLQUFBLGVBQUEsS0FBQSxnQkFBQSxLQUFBLFVBQUEsTUFBQSxHQUFBLENBQUEsS0FBQSxrQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxTQUFBLEdBQUEsQ0FBQSxNQUFBLEtBQUEsTUFBQSxHQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLHNCQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGdCQUFBLEtBQUEsY0FBQSxlQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZUFBQSxVQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsZUFBQSxPQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLGVBQUEsR0FBQSxDQUFBLGdCQUFBLGlCQUFBLEdBQUEsQ0FBQSxnQkFBQSw2QkFBQSxHQUFBLENBQUEsU0FBQSxLQUFBLEdBQUEsQ0FBQSxnQkFBQSxtQ0FBQSxHQUFBLENBQUEsZ0JBQUEsZ0NBQUEsR0FBQSxDQUFBLGdCQUFBLG1DQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsaUJBQUEsR0FBQSxDQUFBLGdCQUFBLHdDQUFBLEdBQUEsQ0FBQSxnQkFBQSxnQ0FBQSxHQUFBLENBQUEsR0FBQSxJQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsUUFBQSxXQUFBLEdBQUEsYUFBQSxTQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLFVBQUEsZUFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxhQUFBLEdBQUEsQ0FBQSxtQkFBQSxJQUFBLEdBQUEsZUFBQSxrQkFBQSwwQkFBQSxlQUFBLFFBQUEsR0FBQSxDQUFBLGFBQUEsUUFBQSxHQUFBLFFBQUEsWUFBQSxHQUFBLENBQUEsZ0JBQUEsOEJBQUEsR0FBQSxDQUFBLE1BQUEsZ0JBQUEsR0FBQSxPQUFBLGlCQUFBLFVBQUEsR0FBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsdUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNyQjFDLFVBQUEseUJBQUEsR0FBQSxzREFBQSxJQUFBLENBQUEsRUFNQyxHQUFBLHNEQUFBLElBQUEsRUFBQTs7O0FBTkQsVUFBQSw0QkFBQSxHQUFBLElBQUEsWUFBQSxJQUFBLEVBQUE7QUFPQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsQ0FBQSxJQUFBLFlBQUEsSUFBQSxFQUFBOzs7OztxRkRjYSwrQkFBNkIsRUFBQSxXQUFBLGdDQUFBLENBQUE7SUFBQSxHQUFBO0FBNlhwQyxJQUFPLFNBQVAsTUFBYTtNQUNFO01BQ1Q7TUFDQTtNQUNTO01BRWpCLFlBQVksT0FBYTtBQUNyQixhQUFLLFFBQVE7QUFDYixhQUFLLGdCQUFnQixDQUFBO01BQ3pCO01BRUEsV0FBUTtBQUNKLGVBQU8sS0FBSztNQUNoQjtNQUVBLFlBQVksVUFBZ0I7QUFDeEIsYUFBSyxjQUFjLEtBQUssUUFBUTtNQUNwQztNQUVBLG1CQUFnQjtBQUNaLGVBQU8sS0FBSztNQUNoQjtNQUVBLGlCQUFjO0FBQ1YsZUFBTyxLQUFLO01BQ2hCO01BRUEsZ0JBQWdCLGNBQXFCO0FBQ2pDLGFBQUssZUFBZTtNQUN4QjtNQUVBLFlBQVM7QUFDTCxlQUFPLEtBQUs7TUFDaEI7TUFFQSxXQUFXLFNBQWdCO0FBQ3ZCLGFBQUssVUFBVTtNQUNuQjs7QUFXRSxJQUFPLFFBQVAsTUFBWTtNQUNkO01BRUEsY0FBQTtBQUNJLGFBQUssV0FBVyxDQUFBO01BQ3BCO01BRU8sVUFBVSxRQUFjO0FBQzNCLGFBQUssU0FBUyxLQUFLLE1BQU07TUFDN0I7TUFFTyxRQUFRLE1BQWMsSUFBVTtBQUNuQyxhQUFLLFlBQVksRUFBRTtNQUN2QjtNQU9PLFdBQVE7QUFFWCxtQkFBVyxVQUFVLEtBQUssVUFBVTtBQUNoQyxjQUFJLENBQUMsT0FBTyxVQUFTLEtBQU0sS0FBSyxlQUFlLE1BQU0sR0FBRztBQUNwRCxtQkFBTzs7O0FBR2YsZUFBTztNQUNYO01BT1EsZUFBZSxjQUFvQjtBQUN2QyxxQkFBYSxnQkFBZ0IsSUFBSTtBQUVqQyxtQkFBVyxZQUFZLGFBQWEsaUJBQWdCLEdBQUk7QUFDcEQsY0FBSSxTQUFTLGVBQWMsR0FBSTtBQUUzQixtQkFBTztxQkFDQSxDQUFDLFNBQVMsVUFBUyxLQUFNLEtBQUssZUFBZSxRQUFRLEdBQUc7QUFDL0QsbUJBQU87OztBQUlmLHFCQUFhLGdCQUFnQixLQUFLO0FBQ2xDLHFCQUFhLFdBQVcsSUFBSTtBQUM1QixlQUFPO01BQ1g7Ozs7OztBRXBmSixTQUFTLGFBQUFJLFlBQVcsU0FBQUMsY0FBYTs7O0FBQWpDLElBT2E7QUFQYjs7O0FBT00sSUFBTywyQkFBUCxNQUFPLDBCQUF3QjtNQUN4QixXQUFXO01BQ1gsYUFBYTtNQUNiLFVBQVU7TUFDVixjQUFjO01BRXZCLElBQUkscUJBQWtCO0FBQ2xCLGVBQU8sS0FBSyxnQkFBZ0IsS0FBSyxRQUFRO01BQzdDO01BRUEsSUFBSSx1QkFBb0I7QUFDcEIsZUFBTyxLQUFLLGdCQUFnQixLQUFLLFVBQVU7TUFDL0M7TUFFQSxJQUFJLG9CQUFpQjtBQUNqQixlQUFPLEtBQUssZ0JBQWdCLEtBQUssT0FBTztNQUM1QztNQU1BLGdCQUFnQixPQUFhO0FBQ3pCLGVBQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxPQUFPLENBQUMsR0FBRyxHQUFHO01BQzNDOzt5QkF4QlMsMkJBQXdCO01BQUE7a0VBQXhCLDJCQUF3QixXQUFBLENBQUEsQ0FBQSxzQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFVBQUEsWUFBQSxZQUFBLGNBQUEsU0FBQSxXQUFBLGFBQUEsY0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsV0FBQSxhQUFBLFNBQUEsOEJBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSxPQUFBLE1BQUEsT0FBQSxLQUFBLFVBQUEsZ0JBQUEsS0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLE1BQUEsT0FBQSxNQUFBLE9BQUEsS0FBQSxVQUFBLGdCQUFBLEtBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSxPQUFBLE1BQUEsT0FBQSxLQUFBLFVBQUEsZ0JBQUEsS0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLE1BQUEsT0FBQSxNQUFBLE9BQUEsS0FBQSxVQUFBLGdCQUFBLEtBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSxPQUFBLE1BQUEsT0FBQSxLQUFBLFVBQUEsZ0JBQUEsS0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLE1BQUEsT0FBQSxNQUFBLE9BQUEsS0FBQSxVQUFBLGdCQUFBLEtBQUEsR0FBQSxhQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsa0NBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNOckMsVUFBQSxzQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDhCQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTs7QUFDSSxVQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxLQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxVQUFBLENBQUE7QUFDQSxVQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxVQUFBLENBQUE7QUFTSixVQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFFQSxVQUFBLHNCQUFBLElBQUEsVUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxLQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxVQUFBLENBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxVQUFBLENBQUE7QUFTSixVQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFFQSxVQUFBLHNCQUFBLElBQUEsVUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxLQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxVQUFBLENBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxVQUFBLENBQUE7QUFTSixVQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsSUFBQTs7O0FBeEM0RCxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLGNBQUEsSUFBQSxjQUFBLFNBQUEsMkJBQUEsR0FBQSxJQUFBLG1EQUFBLENBQUE7QUFTaEQsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSwyQkFBQSxXQUFBLElBQUEsc0JBQUEsSUFBQSxJQUFBLENBQUE7QUFDQSxVQUFBLDJCQUFBLG9CQUFBLElBQUEsb0JBQUEsT0FBQTtBQVlBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMkJBQUEsV0FBQSxJQUFBLHlCQUFBLElBQUEsSUFBQSxDQUFBO0FBQ0EsVUFBQSwyQkFBQSxvQkFBQSxJQUFBLHVCQUFBLE9BQUE7QUFZQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDJCQUFBLFdBQUEsSUFBQSx1QkFBQSxJQUFBLElBQUEsQ0FBQTtBQUNBLFVBQUEsMkJBQUEsb0JBQUEsSUFBQSxxQkFBQSxPQUFBOzs7OztzRkQ5QkMsMEJBQXdCLEVBQUEsV0FBQSwyQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVQckMsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsYUFBQUMsYUFBVyxTQUFBQyxjQUFhO0FBQ2pDLFNBQVMsb0JBQUFDLHlCQUF3Qjs7Ozs7Ozs7O0FDTXpCLElBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxRQUFBOzs7O0FBRDhCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsY0FBQSwrQkFBQSxHQUFBQyxNQUFBLE9BQUEsVUFBQSxPQUFBLFdBQUEsRUFBQSxDQUFBOzs7OztBQVlWLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7Ozs7QUFEYSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsT0FBQSxRQUFBLE9BQUEsV0FBQSxRQUFBLENBQUE7Ozs7O0FBUVQsSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE2RixJQUFBLHNCQUFBLEdBQUEsVUFBQTtBQUFRLElBQUEsNEJBQUE7QUFDekcsSUFBQSxzQkFBQSxHQUFBLHdCQUFBOzs7OztBQUVJLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEcsSUFBQSxzQkFBQSxHQUFBLFVBQUE7QUFBUSxJQUFBLDRCQUFBO0FBQ3hILElBQUEsc0JBQUEsR0FBQSx3QkFBQTs7Ozs7QUFHQSxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLG9CQUFBOzs7O0FBRG1CLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsYUFBQSxPQUFBLFdBQUEsYUFBQSw2QkFBQTs7Ozs7QUFHZixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBK0IsSUFBQSxzQkFBQSxDQUFBO0FBQTZCLElBQUEsNEJBQUE7QUFDNUQsSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFpQyxJQUFBLHNCQUFBLENBQUE7QUFBZ0MsSUFBQSw0QkFBQTtBQUNyRSxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLG9CQUFBOzs7O0FBSHVDLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsT0FBQSxXQUFBLE9BQUEsS0FBQTtBQUNFLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsT0FBQSxXQUFBLE9BQUEsUUFBQTs7Ozs7QUFNekMsSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBc0MsSUFBQSxzQkFBQSxDQUFBOztBQUE0RSxJQUFBLDRCQUFBO0FBQ2xILElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLENBQUE7O0FBQ0osSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsZ0JBQUE7Ozs7QUFMOEMsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSxLQUFBLDJCQUFBLEdBQUEsR0FBQSxrREFBQSxHQUFBLEdBQUE7QUFDbEIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxXQUFBLE9BQUEscUJBQUEsQ0FBQSxPQUFBLGFBQUEsY0FBQSxZQUFBO0FBQ2hCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsOEJBQUEsMkJBQUEsR0FBQSxHQUFBLE9BQUEsV0FBQSxXQUFBLEdBQUEsd0JBQUE7Ozs7O0FBS1IsSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSx3QkFBQSxFQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSxnQkFBQTs7OztBQUY4QixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFlBQUEsT0FBQSxRQUFBLEVBQXFCLGNBQUEsT0FBQSxVQUFBLEVBQUEsV0FBQSxPQUFBLE9BQUE7OztBRHZEL0QsZ0JBVWE7QUFWYjs7QUFHQTs7Ozs7OztBQU9NLElBQU8sMEJBQVAsTUFBTyx5QkFBdUI7TUFXYjtNQVRuQjtNQUVBO01BRUE7TUFFQSxVQUFVO01BQ1YsaUJBQWlCO01BRWpCLFlBQW1CLGtCQUFrQztBQUFsQyxhQUFBLG1CQUFBO01BQXFDO01BRXhELGtCQUFlO0FBQ1gsWUFBSSxLQUFLLFdBQVcsY0FBYyxRQUFRO0FBQ3RDLGlCQUFPLEtBQUssV0FBVyxhQUFhLE1BQUs7O0FBRTdDLGVBQU8sRUFBRSxVQUFVLEdBQUcsWUFBWSxFQUFDO01BQ3ZDO01BRUEsSUFBSSxXQUFRO0FBRVIsZUFBTyxLQUFLLGdCQUFlLEVBQUcsWUFBWTtNQUM5QztNQUVBLElBQUksYUFBVTtBQUdWLGVBQU8sS0FBSyxJQUFJLEtBQUssT0FBUSxLQUFLLGdCQUFlLEVBQUcsY0FBYyxNQUFNLEtBQUssV0FBVyxvQkFBb0IsT0FBUSxHQUFHLEdBQUcsR0FBRztNQUNqSTtNQUVBLElBQUksVUFBTztBQUVQLGNBQU0sU0FBUyxJQUFJO0FBQ25CLGVBQU8sS0FBSyxPQUFPLElBQUksVUFBVSxLQUFLLFdBQVcsU0FBUyxLQUFLLFVBQVU7TUFDN0U7TUFFQSxJQUFJLGFBQVU7QUFDVixlQUFPLEtBQUssV0FBVztNQUMzQjtNQUVBLElBQUksb0JBQWlCO0FBQ2pCLGVBQU8sTUFBSyxFQUFHLFFBQVEsS0FBSyxXQUFXLFdBQVc7TUFDdEQ7O3lCQTNDUywwQkFBdUIsaUNBQUEscUJBQUEsQ0FBQTtNQUFBO2tFQUF2QiwwQkFBdUIsV0FBQSxDQUFBLENBQUEscUJBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsWUFBQSxjQUFBLGdCQUFBLGlCQUFBLEdBQUEsb0JBQUFDLE1BQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLHVCQUFBLE9BQUEsc0JBQUEsMkJBQUEsUUFBQSxRQUFBLHFCQUFBLEdBQUEsSUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFVBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxHQUFBLENBQUEsUUFBQSxNQUFBLGFBQUEsUUFBQSxHQUFBLFFBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxPQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsa0NBQUEsR0FBQSxTQUFBLGNBQUEsaUJBQUEsR0FBQSxDQUFBLE1BQUEsa0JBQUEsZ0JBQUEsa0NBQUEsR0FBQSxTQUFBLGNBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsT0FBQSxRQUFBLEdBQUEsYUFBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLFFBQUEsR0FBQSxDQUFBLE1BQUEsY0FBQSxHQUFBLFNBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsT0FBQSxZQUFBLFFBQUEsUUFBQSxHQUFBLGFBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGNBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGlDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBOztBQ1ZwQyxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBT0ksVUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDBCQUFBLEdBQUEsZ0RBQUEsR0FBQSxDQUFBO0FBR0EsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxXQUFBLENBQUE7O0FBQ0osVUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxNQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDBCQUFBLElBQUEsaURBQUEsR0FBQSxDQUFBO0FBR0osVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsRUFBQTtBQUNBLFVBQUEsMEJBQUEsSUFBQSxpREFBQSxHQUFBLENBQUEsRUFFQyxJQUFBLGlEQUFBLEdBQUEsQ0FBQTtBQUlMLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDBCQUFBLElBQUEsaURBQUEsR0FBQSxDQUFBLEVBRUMsSUFBQSxpREFBQSxJQUFBLENBQUE7QUFPRCxVQUFBLDRCQUFBLEVBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwwQkFBQSxJQUFBLGlEQUFBLElBQUEsQ0FBQSxFQU9DLElBQUEsaURBQUEsR0FBQSxDQUFBO0FBTUwsVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxJQUFBOzs7QUExREksVUFBQSwyQkFBQSxvQkFBQSxJQUFBLGNBQUEsRUFBeUMsa0JBQUEsSUFBQSxVQUFBLEVBQUEsa0JBQUEsSUFBQSxVQUFBO0FBRnpDLFVBQUEsMEJBQUEsTUFBQSxxQkFBQSxJQUFBLFdBQUEsRUFBQTtBQU1BLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxJQUFBLFlBQUEsQ0FBQSxJQUFBLGlCQUFBLElBQUEsRUFBQTtBQUtpQixVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLFFBQUEsSUFBQSxRQUFBLElBQUEsV0FBQSxRQUFBLENBQUEsRUFBcUMsY0FBQSwyQkFBQSxHQUFBLElBQUEsSUFBQSxlQUFBLElBQUEsV0FBQSxRQUFBLENBQUEsQ0FBQTtBQU90QyxVQUFBLHlCQUFBLEVBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsSUFBQSxXQUFBLFdBQUEsS0FBQSxFQUFBO0FBT0EsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxrQ0FBQSwwQkFBQSxJQUFBLFdBQUEsT0FBQSx3QkFBQTtBQUNBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLGFBQUEsS0FBQSxFQUFBO0FBR0EsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLElBQUEsV0FBQSxXQUFBLEtBQUEsRUFBQTtBQUlKLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLFdBQUEsY0FBQSxLQUFBLEVBQUE7QUFHQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsSUFBQSxrQkFBQSxJQUFBLFdBQUEsU0FBQSxLQUFBLEVBQUE7QUFRSixVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsQ0FBQSxJQUFBLGtCQUFBLElBQUEsV0FBQSxjQUFBLEtBQUEsRUFBQTtBQVFBLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxDQUFBLElBQUEsaUJBQUEsS0FBQSxFQUFBOzs7OztzRkQzQ0MseUJBQXVCLEVBQUEsV0FBQSwwQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVWcEMsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxvQkFBb0I7QUFLN0IsU0FBUyxhQUFhLDJCQUEyQjtBQU1qRCxTQUFTLHNCQUFzQjtBQUkvQixTQUFTLDBCQUEwQjs7QUFoQm5DLElBaUNhO0FBakNiOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQWtCTSxJQUFPLDRCQUFQLE1BQU8sMkJBQXlCOzt5QkFBekIsNEJBQXlCO01BQUE7aUVBQXpCLDJCQUF5QixDQUFBO3FFQWR4QixxQkFBcUIsYUFBYSxxQkFBcUIsZ0JBQWdCLDhCQUE4QixjQUFjLDBCQUEwQixrQkFBa0IsRUFBQSxDQUFBOzs7OyIsIm5hbWVzIjpbIkNvbXBvbmVudCIsIklucHV0IiwiQ29tcG9uZW50Iiwic3dpdGNoTWFwIiwiQ29tcG9uZW50IiwiQWN0aXZhdGVkUm91dGUiLCJSb3V0ZXIiLCJmaW5hbGl6ZSIsInN3aXRjaE1hcCIsInRha2UiLCJtYXAiLCJDb21wb25lbnQiLCJJbnB1dCIsIlJvdXRlciIsIlRhYmxlQ29sdW1uIiwiQ29tcG9uZW50Iiwic3dpdGNoTWFwIiwiQ29tcG9uZW50IiwiQ29tcG9uZW50IiwiQWN0aXZhdGVkUm91dGUiLCJmaW5hbGl6ZSIsIm1hcCIsInN3aXRjaE1hcCIsIlN1YmplY3QiLCJmb3JrSm9pbiIsIkNvbXBvbmVudCIsIklucHV0IiwiQ29tcG9uZW50IiwiSW5wdXQiLCJUcmFuc2xhdGVTZXJ2aWNlIiwiX2MwIiwiX2MxIl19