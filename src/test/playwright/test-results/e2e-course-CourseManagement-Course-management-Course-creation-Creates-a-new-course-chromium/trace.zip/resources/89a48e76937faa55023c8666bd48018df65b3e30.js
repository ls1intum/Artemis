import {
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/shared/team/team.utils.ts
function formatTeamAsSearchResult(team) {
  const { name, shortName, students } = team;
  const studentsFormatted = students?.map((s) => `${s.name} (${s.login})`).join(", ");
  return `${name} (${shortName})` + (students && students.length > 0 ? ` \u27F9 ${studentsFormatted}` : "");
}
var init_team_utils = __esm({
  "src/main/webapp/app/exercises/shared/team/team.utils.ts"() {
  }
});

export {
  formatTeamAsSearchResult,
  init_team_utils
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0udXRpbHMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgVGVhbSB9IGZyb20gJ2FwcC9lbnRpdGllcy90ZWFtLm1vZGVsJztcblxuLyoqXG4gKiBGb3JtYXRzIGEgdGVhbSBmb3IgZGlzcGxheWluZyBpdCBpbiBhbiBhdXRvY29tcGxldGUgc2VhcmNoXG4gKlxuICogRXhhbXBsZXM6XG4gKiBUZWFtIDEgKHRlYW0xKSDin7kgTWF4IE11c3Rlcm1hbm4gKGdhMTJhYmMpLCBFcmlrYSBNdXN0ZXJmcmF1IChnYTM0ZGVmKVxuICogVGVhbSAyICh0ZWFtMilcbiAqXG4gKiBAcGFyYW0gdGVhbVxuICovXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0VGVhbUFzU2VhcmNoUmVzdWx0KHRlYW06IFRlYW0pIHtcbiAgICBjb25zdCB7IG5hbWUsIHNob3J0TmFtZSwgc3R1ZGVudHMgfSA9IHRlYW07XG4gICAgY29uc3Qgc3R1ZGVudHNGb3JtYXR0ZWQgPSBzdHVkZW50cz8ubWFwKChzKSA9PiBgJHtzLm5hbWV9ICgke3MubG9naW59KWApLmpvaW4oJywgJyk7XG4gICAgcmV0dXJuIGAke25hbWV9ICgke3Nob3J0TmFtZX0pYCArIChzdHVkZW50cyAmJiBzdHVkZW50cy5sZW5ndGggPiAwID8gYCDin7kgJHtzdHVkZW50c0Zvcm1hdHRlZH1gIDogJycpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7OztBQVdNLFNBQVUseUJBQXlCLE1BQVU7QUFDL0MsUUFBTSxFQUFFLE1BQU0sV0FBVyxTQUFRLElBQUs7QUFDdEMsUUFBTSxvQkFBb0IsVUFBVSxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsSUFBSSxLQUFLLEVBQUUsS0FBSyxHQUFHLEVBQUUsS0FBSyxJQUFJO0FBQ2xGLFNBQU8sR0FBRyxJQUFJLEtBQUssU0FBUyxPQUFPLFlBQVksU0FBUyxTQUFTLElBQUksV0FBTSxpQkFBaUIsS0FBSztBQUNyRztBQUpBOzs7OyIsIm5hbWVzIjpbXX0=