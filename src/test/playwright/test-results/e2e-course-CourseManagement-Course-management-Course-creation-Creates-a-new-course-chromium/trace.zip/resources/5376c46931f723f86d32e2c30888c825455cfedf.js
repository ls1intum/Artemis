import {
  AssessmentType,
  Exercise,
  ExerciseType,
  SubmissionService,
  __esm,
  createRequestOption,
  init_assessment_type_model,
  init_exercise_model,
  init_request_util,
  init_submission_service,
  init_utils,
  stringifyCircular
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/modeling/participate/modeling-submission.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient, HttpParams } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var ModelingSubmissionService;
var init_modeling_submission_service = __esm({
  "src/main/webapp/app/exercises/modeling/participate/modeling-submission.service.ts"() {
    init_request_util();
    init_utils();
    init_submission_service();
    init_submission_service();
    ModelingSubmissionService = class _ModelingSubmissionService {
      http;
      submissionService;
      resourceUrl = "api";
      constructor(http, submissionService) {
        this.http = http;
        this.submissionService = submissionService;
      }
      create(modelingSubmission, exerciseId) {
        const copy = this.submissionService.convert(modelingSubmission);
        return this.http.post(`api/exercises/${exerciseId}/modeling-submissions`, stringifyCircular(copy), {
          headers: { "Content-Type": "application/json" },
          observe: "response"
        }).pipe(map((res) => this.submissionService.convertResponse(res)));
      }
      update(modelingSubmission, exerciseId) {
        const copy = this.submissionService.convert(modelingSubmission);
        return this.http.put(`api/exercises/${exerciseId}/modeling-submissions`, stringifyCircular(copy), {
          headers: { "Content-Type": "application/json" },
          observe: "response"
        }).pipe(map((res) => this.submissionService.convertResponse(res)));
      }
      getSubmissions(exerciseId, req, correctionRound = 0) {
        const url = `${this.resourceUrl}/exercises/${exerciseId}/modeling-submissions`;
        let params = createRequestOption(req);
        if (correctionRound !== 0) {
          params = params.set("correction-round", correctionRound.toString());
        }
        return this.http.get(url, {
          params,
          observe: "response"
        }).pipe(map((res) => this.submissionService.convertArrayResponse(res)));
      }
      getSubmissionWithoutAssessment(exerciseId, lock, correctionRound = 0) {
        const url = `api/exercises/${exerciseId}/modeling-submission-without-assessment`;
        let params = new HttpParams();
        if (correctionRound !== 0) {
          params = params.set("correction-round", correctionRound.toString());
        }
        if (lock) {
          params = params.set("lock", "true");
        }
        return this.http.get(url, { params }).pipe(map((res) => {
          if (!res) {
            return void 0;
          }
          return this.submissionService.convertSubmissionFromServer(res);
        }));
      }
      getSubmission(submissionId, correctionRound = 0, resultId) {
        const url = `api/modeling-submissions/${submissionId}`;
        let params = new HttpParams();
        if (correctionRound !== 0) {
          params = params.set("correction-round", correctionRound.toString());
        }
        if (resultId && resultId > 0) {
          params = params.set("resultId", resultId.toString());
        }
        return this.http.get(url, { params }).pipe(map((res) => this.submissionService.convertSubmissionFromServer(res)));
      }
      getSubmissionWithoutLock(submissionId) {
        const url = `api/modeling-submissions/${submissionId}`;
        let params = new HttpParams();
        params = params.set("withoutResults", "true");
        return this.http.get(url, { params }).pipe(map((res) => this.submissionService.convertSubmissionFromServer(res)));
      }
      getLatestSubmissionForModelingEditor(participationId) {
        return this.http.get(`api/participations/${participationId}/latest-modeling-submission`, { responseType: "json" }).pipe(map((res) => this.submissionService.convertSubmissionFromServer(res)));
      }
      static \u0275fac = function ModelingSubmissionService_Factory(t) {
        return new (t || _ModelingSubmissionService)(i0.\u0275\u0275inject(i1.HttpClient), i0.\u0275\u0275inject(SubmissionService));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _ModelingSubmissionService, factory: _ModelingSubmissionService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/entities/modeling-exercise.model.ts
var UMLDiagramType, ModelingExercise;
var init_modeling_exercise_model = __esm({
  "src/main/webapp/app/entities/modeling-exercise.model.ts"() {
    init_exercise_model();
    init_assessment_type_model();
    (function(UMLDiagramType2) {
      UMLDiagramType2["ClassDiagram"] = "ClassDiagram";
      UMLDiagramType2["ObjectDiagram"] = "ObjectDiagram";
      UMLDiagramType2["ActivityDiagram"] = "ActivityDiagram";
      UMLDiagramType2["UseCaseDiagram"] = "UseCaseDiagram";
      UMLDiagramType2["CommunicationDiagram"] = "CommunicationDiagram";
      UMLDiagramType2["ComponentDiagram"] = "ComponentDiagram";
      UMLDiagramType2["DeploymentDiagram"] = "DeploymentDiagram";
      UMLDiagramType2["PetriNet"] = "PetriNet";
      UMLDiagramType2["SyntaxTree"] = "SyntaxTree";
      UMLDiagramType2["Flowchart"] = "Flowchart";
      UMLDiagramType2["BPMN"] = "BPMN";
    })(UMLDiagramType || (UMLDiagramType = {}));
    ModelingExercise = class extends Exercise {
      diagramType;
      exampleSolutionModel;
      exampleSolutionExplanation;
      constructor(diagramType, course, exerciseGroup) {
        super(ExerciseType.MODELING);
        this.course = course;
        this.exerciseGroup = exerciseGroup;
        this.diagramType = diagramType;
        this.assessmentType = AssessmentType.MANUAL;
        if (this.diagramType === UMLDiagramType.ClassDiagram || this.diagramType === UMLDiagramType.ActivityDiagram) {
          this.assessmentType = AssessmentType.SEMI_AUTOMATIC;
        }
      }
    };
  }
});

export {
  ModelingSubmissionService,
  init_modeling_submission_service,
  UMLDiagramType,
  ModelingExercise,
  init_modeling_exercise_model
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL21vZGVsaW5nL3BhcnRpY2lwYXRlL21vZGVsaW5nLXN1Ym1pc3Npb24uc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvbW9kZWxpbmctZXhlcmNpc2UubW9kZWwudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cFBhcmFtcywgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuXG5pbXBvcnQgeyBNb2RlbGluZ1N1Ym1pc3Npb24gfSBmcm9tICdhcHAvZW50aXRpZXMvbW9kZWxpbmctc3VibWlzc2lvbi5tb2RlbCc7XG5pbXBvcnQgeyBjcmVhdGVSZXF1ZXN0T3B0aW9uIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL3JlcXVlc3QudXRpbCc7XG5pbXBvcnQgeyBzdHJpbmdpZnlDaXJjdWxhciB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC91dGlscyc7XG5pbXBvcnQgeyBTdWJtaXNzaW9uU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3N1Ym1pc3Npb24vc3VibWlzc2lvbi5zZXJ2aWNlJztcblxuZXhwb3J0IHR5cGUgRW50aXR5UmVzcG9uc2VUeXBlID0gSHR0cFJlc3BvbnNlPE1vZGVsaW5nU3VibWlzc2lvbj47XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgTW9kZWxpbmdTdWJtaXNzaW9uU2VydmljZSB7XG4gICAgcHVibGljIHJlc291cmNlVXJsID0gJ2FwaSc7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50LFxuICAgICAgICBwcml2YXRlIHN1Ym1pc3Npb25TZXJ2aWNlOiBTdWJtaXNzaW9uU2VydmljZSxcbiAgICApIHt9XG5cbiAgICAvKipcbiAgICAgKiBDcmVhdGUgYSBuZXcgbW9kZWxpbmcgc3VibWlzc2lvblxuICAgICAqIEBwYXJhbSB7TW9kZWxpbmdTdWJtaXNzaW9ufSBtb2RlbGluZ1N1Ym1pc3Npb24gLSBOZXcgc3VibWlzc2lvbiB0byBiZSBjcmVhdGVkXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IGV4ZXJjaXNlSWQgLSBJZCBvZiB0aGUgZXhlcmNpc2UsIGZvciB3aGljaCB0aGUgc3VibWlzc2lvbiBpcyBtYWRlXG4gICAgICovXG4gICAgY3JlYXRlKG1vZGVsaW5nU3VibWlzc2lvbjogTW9kZWxpbmdTdWJtaXNzaW9uLCBleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT4ge1xuICAgICAgICBjb25zdCBjb3B5ID0gdGhpcy5zdWJtaXNzaW9uU2VydmljZS5jb252ZXJ0KG1vZGVsaW5nU3VibWlzc2lvbik7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5wb3N0PE1vZGVsaW5nU3VibWlzc2lvbj4oYGFwaS9leGVyY2lzZXMvJHtleGVyY2lzZUlkfS9tb2RlbGluZy1zdWJtaXNzaW9uc2AsIHN0cmluZ2lmeUNpcmN1bGFyKGNvcHkpLCB7XG4gICAgICAgICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sIC8vIG5lZWRlZCBkdWUgdG8gc3RyaW5naWZ5Q2lyY3VsYXJcbiAgICAgICAgICAgICAgICBvYnNlcnZlOiAncmVzcG9uc2UnLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpID0+IHRoaXMuc3VibWlzc2lvblNlcnZpY2UuY29udmVydFJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVcGRhdGUgYW4gZXhpc3RpbmcgbW9kZWxpbmcgc3VibWlzc2lvblxuICAgICAqIEBwYXJhbSB7TW9kZWxpbmdTdWJtaXNzaW9ufSBtb2RlbGluZ1N1Ym1pc3Npb24gLSBVcGRhdGVkIHN1Ym1pc3Npb25cbiAgICAgKiBAcGFyYW0ge251bWJlcn0gZXhlcmNpc2VJZCAtIElkIG9mIHRoZSBleGVyY2lzZSwgZm9yIHdoaWNoIHRoZSBzdWJtaXNzaW9uIGlzIG1hZGVcbiAgICAgKi9cbiAgICB1cGRhdGUobW9kZWxpbmdTdWJtaXNzaW9uOiBNb2RlbGluZ1N1Ym1pc3Npb24sIGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIGNvbnN0IGNvcHkgPSB0aGlzLnN1Ym1pc3Npb25TZXJ2aWNlLmNvbnZlcnQobW9kZWxpbmdTdWJtaXNzaW9uKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLnB1dDxNb2RlbGluZ1N1Ym1pc3Npb24+KGBhcGkvZXhlcmNpc2VzLyR7ZXhlcmNpc2VJZH0vbW9kZWxpbmctc3VibWlzc2lvbnNgLCBzdHJpbmdpZnlDaXJjdWxhcihjb3B5KSwge1xuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LCAvLyBuZWVkZWQgZHVlIHRvIHN0cmluZ2lmeUNpcmN1bGFyXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlczogRW50aXR5UmVzcG9uc2VUeXBlKSA9PiB0aGlzLnN1Ym1pc3Npb25TZXJ2aWNlLmNvbnZlcnRSZXNwb25zZShyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGFsbCBzdWJtaXNzaW9ucyBmb3IgYW4gZXhlcmNpc2VcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gZXhlcmNpc2VJZCAtIElkIG9mIHRoZSBleGVyY2lzZVxuICAgICAqIEBwYXJhbSB7YW55P30gcmVxIC0gUmVxdWVzdCBvcHRpb25cbiAgICAgKiBAcGFyYW0gY29ycmVjdGlvblJvdW5kIGNvcnJlY3Rpb25Sb3VuZCBmb3Igd2hpY2ggdG8gZ2V0IHRoZSBTdWJtaXNzaW9uc1xuICAgICAqL1xuICAgIGdldFN1Ym1pc3Npb25zKGV4ZXJjaXNlSWQ6IG51bWJlciwgcmVxPzogYW55LCBjb3JyZWN0aW9uUm91bmQgPSAwKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8TW9kZWxpbmdTdWJtaXNzaW9uW10+PiB7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMucmVzb3VyY2VVcmx9L2V4ZXJjaXNlcy8ke2V4ZXJjaXNlSWR9L21vZGVsaW5nLXN1Ym1pc3Npb25zYDtcbiAgICAgICAgbGV0IHBhcmFtcyA9IGNyZWF0ZVJlcXVlc3RPcHRpb24ocmVxKTtcbiAgICAgICAgaWYgKGNvcnJlY3Rpb25Sb3VuZCAhPT0gMCkge1xuICAgICAgICAgICAgcGFyYW1zID0gcGFyYW1zLnNldCgnY29ycmVjdGlvbi1yb3VuZCcsIGNvcnJlY3Rpb25Sb3VuZC50b1N0cmluZygpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAuZ2V0PE1vZGVsaW5nU3VibWlzc2lvbltdPih1cmwsIHtcbiAgICAgICAgICAgICAgICBwYXJhbXMsXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlczogSHR0cFJlc3BvbnNlPE1vZGVsaW5nU3VibWlzc2lvbltdPikgPT4gdGhpcy5zdWJtaXNzaW9uU2VydmljZS5jb252ZXJ0QXJyYXlSZXNwb25zZShyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGFuIHVuYXNzZXNzZWQgbW9kZWxpbmcgZXhlcmNpc2UgZm9yIGFuIGV4ZXJjaXNlXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IGV4ZXJjaXNlSWQgLSBJZCBvZiB0aGUgZXhlcmNpc2VcbiAgICAgKiBAcGFyYW0ge2Jvb2xlYW4/fSBsb2NrIC0gVHJ1ZSBpZiBhc3Nlc3NtZW50IGlzIGxvY2tlZFxuICAgICAqIEBwYXJhbSBjb3JyZWN0aW9uUm91bmQgY29ycmVjdGlvblJvdW5kIGZvciB3aGljaCB0byBnZXQgdGhlIFN1Ym1pc3Npb25zXG4gICAgICovXG4gICAgZ2V0U3VibWlzc2lvbldpdGhvdXRBc3Nlc3NtZW50KGV4ZXJjaXNlSWQ6IG51bWJlciwgbG9jaz86IGJvb2xlYW4sIGNvcnJlY3Rpb25Sb3VuZCA9IDApOiBPYnNlcnZhYmxlPE1vZGVsaW5nU3VibWlzc2lvbiB8IHVuZGVmaW5lZD4ge1xuICAgICAgICBjb25zdCB1cmwgPSBgYXBpL2V4ZXJjaXNlcy8ke2V4ZXJjaXNlSWR9L21vZGVsaW5nLXN1Ym1pc3Npb24td2l0aG91dC1hc3Nlc3NtZW50YDtcbiAgICAgICAgbGV0IHBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKCk7XG4gICAgICAgIGlmIChjb3JyZWN0aW9uUm91bmQgIT09IDApIHtcbiAgICAgICAgICAgIHBhcmFtcyA9IHBhcmFtcy5zZXQoJ2NvcnJlY3Rpb24tcm91bmQnLCBjb3JyZWN0aW9uUm91bmQudG9TdHJpbmcoKSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGxvY2spIHtcbiAgICAgICAgICAgIHBhcmFtcyA9IHBhcmFtcy5zZXQoJ2xvY2snLCAndHJ1ZScpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PE1vZGVsaW5nU3VibWlzc2lvbiB8IHVuZGVmaW5lZD4odXJsLCB7IHBhcmFtcyB9KS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXM/OiBNb2RlbGluZ1N1Ym1pc3Npb24pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIXJlcykge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5zdWJtaXNzaW9uU2VydmljZS5jb252ZXJ0U3VibWlzc2lvbkZyb21TZXJ2ZXIocmVzKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBhIHN1Ym1pc3Npb24gd2l0aCBnaXZlbiBJZFxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSBzdWJtaXNzaW9uSWQgLSBJZCBvZiB0aGUgc3VibWlzc2lvblxuICAgICAqIEBwYXJhbSBjb3JyZWN0aW9uUm91bmRcbiAgICAgKiBAcGFyYW0gcmVzdWx0SWRcbiAgICAgKi9cbiAgICBnZXRTdWJtaXNzaW9uKHN1Ym1pc3Npb25JZDogbnVtYmVyLCBjb3JyZWN0aW9uUm91bmQgPSAwLCByZXN1bHRJZD86IG51bWJlcik6IE9ic2VydmFibGU8TW9kZWxpbmdTdWJtaXNzaW9uPiB7XG4gICAgICAgIGNvbnN0IHVybCA9IGBhcGkvbW9kZWxpbmctc3VibWlzc2lvbnMvJHtzdWJtaXNzaW9uSWR9YDtcbiAgICAgICAgbGV0IHBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKCk7XG4gICAgICAgIGlmIChjb3JyZWN0aW9uUm91bmQgIT09IDApIHtcbiAgICAgICAgICAgIHBhcmFtcyA9IHBhcmFtcy5zZXQoJ2NvcnJlY3Rpb24tcm91bmQnLCBjb3JyZWN0aW9uUm91bmQudG9TdHJpbmcoKSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc3VsdElkICYmIHJlc3VsdElkID4gMCkge1xuICAgICAgICAgICAgcGFyYW1zID0gcGFyYW1zLnNldCgncmVzdWx0SWQnLCByZXN1bHRJZC50b1N0cmluZygpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxNb2RlbGluZ1N1Ym1pc3Npb24+KHVybCwgeyBwYXJhbXMgfSkucGlwZShtYXAoKHJlczogTW9kZWxpbmdTdWJtaXNzaW9uKSA9PiB0aGlzLnN1Ym1pc3Npb25TZXJ2aWNlLmNvbnZlcnRTdWJtaXNzaW9uRnJvbVNlcnZlcihyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IGEgc3VibWlzc2lvbiB3aXRoIGdpdmVuIElkIHdpdGhvdXQgbG9ja2luZyBpdCBvbiBhcnRlbWlzIHNvIHBsYWdpYXJpc20gZGV0ZWN0aW9uIGRvZXNuJ3QgZGlzcnVwdCBhc3Nlc3NtZW50XG4gICAgICogQHBhcmFtIHtudW1iZXJ9IHN1Ym1pc3Npb25JZCAtIElkIG9mIHRoZSBzdWJtaXNzaW9uXG4gICAgICovXG4gICAgZ2V0U3VibWlzc2lvbldpdGhvdXRMb2NrKHN1Ym1pc3Npb25JZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxNb2RlbGluZ1N1Ym1pc3Npb24+IHtcbiAgICAgICAgY29uc3QgdXJsID0gYGFwaS9tb2RlbGluZy1zdWJtaXNzaW9ucy8ke3N1Ym1pc3Npb25JZH1gO1xuICAgICAgICBsZXQgcGFyYW1zID0gbmV3IEh0dHBQYXJhbXMoKTtcbiAgICAgICAgcGFyYW1zID0gcGFyYW1zLnNldCgnd2l0aG91dFJlc3VsdHMnLCAndHJ1ZScpO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxNb2RlbGluZ1N1Ym1pc3Npb24+KHVybCwgeyBwYXJhbXMgfSkucGlwZShtYXAoKHJlczogTW9kZWxpbmdTdWJtaXNzaW9uKSA9PiB0aGlzLnN1Ym1pc3Npb25TZXJ2aWNlLmNvbnZlcnRTdWJtaXNzaW9uRnJvbVNlcnZlcihyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IHRoZSBsYXRlc3Qgc3VibWlzc2lvbiBmb3IgYSBnaXZlbiBwYXJ0aWNpcGF0aW9uXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IHBhcnRpY2lwYXRpb25JZCAtIElkIG9mIHRoZSBwYXJ0aWNpcGF0aW9uXG4gICAgICovXG4gICAgZ2V0TGF0ZXN0U3VibWlzc2lvbkZvck1vZGVsaW5nRWRpdG9yKHBhcnRpY2lwYXRpb25JZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxNb2RlbGluZ1N1Ym1pc3Npb24+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLmdldDxNb2RlbGluZ1N1Ym1pc3Npb24+KGBhcGkvcGFydGljaXBhdGlvbnMvJHtwYXJ0aWNpcGF0aW9uSWR9L2xhdGVzdC1tb2RlbGluZy1zdWJtaXNzaW9uYCwgeyByZXNwb25zZVR5cGU6ICdqc29uJyB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IE1vZGVsaW5nU3VibWlzc2lvbikgPT4gdGhpcy5zdWJtaXNzaW9uU2VydmljZS5jb252ZXJ0U3VibWlzc2lvbkZyb21TZXJ2ZXIocmVzKSkpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEV4ZXJjaXNlLCBFeGVyY2lzZVR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgQ291cnNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvdXJzZS5tb2RlbCc7XG5pbXBvcnQgeyBBc3Nlc3NtZW50VHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9hc3Nlc3NtZW50LXR5cGUubW9kZWwnO1xuaW1wb3J0IHsgRXhlcmNpc2VHcm91cCB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS1ncm91cC5tb2RlbCc7XG5cbi8qKlxuICogVGhlIFVNTERpYWdyYW1UeXBlIGVudW1lcmF0aW9uLiBUaGlzIGhhcyB0byBiZSBleGFjdGx5IHRoZSBzYW1lIGFzIGRlZmluZWQgaW4gQXBvbGxvbiAoc2VlIGRpYWdyYW0tdHlwZS5kLnRzKVxuICovXG5leHBvcnQgZW51bSBVTUxEaWFncmFtVHlwZSB7XG4gICAgQ2xhc3NEaWFncmFtID0gJ0NsYXNzRGlhZ3JhbScsXG4gICAgT2JqZWN0RGlhZ3JhbSA9ICdPYmplY3REaWFncmFtJyxcbiAgICBBY3Rpdml0eURpYWdyYW0gPSAnQWN0aXZpdHlEaWFncmFtJyxcbiAgICBVc2VDYXNlRGlhZ3JhbSA9ICdVc2VDYXNlRGlhZ3JhbScsXG4gICAgQ29tbXVuaWNhdGlvbkRpYWdyYW0gPSAnQ29tbXVuaWNhdGlvbkRpYWdyYW0nLFxuICAgIENvbXBvbmVudERpYWdyYW0gPSAnQ29tcG9uZW50RGlhZ3JhbScsXG4gICAgRGVwbG95bWVudERpYWdyYW0gPSAnRGVwbG95bWVudERpYWdyYW0nLFxuICAgIFBldHJpTmV0ID0gJ1BldHJpTmV0JyxcbiAgICBTeW50YXhUcmVlID0gJ1N5bnRheFRyZWUnLFxuICAgIEZsb3djaGFydCA9ICdGbG93Y2hhcnQnLFxuICAgIEJQTU4gPSAnQlBNTicsXG59XG5cbmV4cG9ydCBjbGFzcyBNb2RlbGluZ0V4ZXJjaXNlIGV4dGVuZHMgRXhlcmNpc2Uge1xuICAgIHB1YmxpYyBkaWFncmFtVHlwZT86IFVNTERpYWdyYW1UeXBlO1xuICAgIHB1YmxpYyBleGFtcGxlU29sdXRpb25Nb2RlbD86IHN0cmluZztcbiAgICBwdWJsaWMgZXhhbXBsZVNvbHV0aW9uRXhwbGFuYXRpb24/OiBzdHJpbmc7XG5cbiAgICBjb25zdHJ1Y3RvcihkaWFncmFtVHlwZTogVU1MRGlhZ3JhbVR5cGUsIGNvdXJzZTogQ291cnNlIHwgdW5kZWZpbmVkLCBleGVyY2lzZUdyb3VwOiBFeGVyY2lzZUdyb3VwIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHN1cGVyKEV4ZXJjaXNlVHlwZS5NT0RFTElORyk7XG4gICAgICAgIHRoaXMuY291cnNlID0gY291cnNlO1xuICAgICAgICB0aGlzLmV4ZXJjaXNlR3JvdXAgPSBleGVyY2lzZUdyb3VwO1xuICAgICAgICB0aGlzLmRpYWdyYW1UeXBlID0gZGlhZ3JhbVR5cGU7XG4gICAgICAgIC8vIGRlZmF1bHQgdmFsdWVcblxuICAgICAgICB0aGlzLmFzc2Vzc21lbnRUeXBlID0gQXNzZXNzbWVudFR5cGUuTUFOVUFMO1xuICAgICAgICBpZiAodGhpcy5kaWFncmFtVHlwZSA9PT0gVU1MRGlhZ3JhbVR5cGUuQ2xhc3NEaWFncmFtIHx8IHRoaXMuZGlhZ3JhbVR5cGUgPT09IFVNTERpYWdyYW1UeXBlLkFjdGl2aXR5RGlhZ3JhbSkge1xuICAgICAgICAgICAgdGhpcy5hc3Nlc3NtZW50VHlwZSA9IEFzc2Vzc21lbnRUeXBlLlNFTUlfQVVUT01BVElDO1xuICAgICAgICB9XG4gICAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxZQUFZLGtCQUFnQztBQUVyRCxTQUFTLFdBQVc7OztBQUhwQixJQWFhO0FBYmI7O0FBTUE7QUFDQTtBQUNBOztBQUtNLElBQU8sNEJBQVAsTUFBTywyQkFBeUI7TUFJdEI7TUFDQTtNQUpMLGNBQWM7TUFFckIsWUFDWSxNQUNBLG1CQUFvQztBQURwQyxhQUFBLE9BQUE7QUFDQSxhQUFBLG9CQUFBO01BQ1Q7TUFPSCxPQUFPLG9CQUF3QyxZQUFrQjtBQUM3RCxjQUFNLE9BQU8sS0FBSyxrQkFBa0IsUUFBUSxrQkFBa0I7QUFDOUQsZUFBTyxLQUFLLEtBQ1AsS0FBeUIsaUJBQWlCLFVBQVUseUJBQXlCLGtCQUFrQixJQUFJLEdBQUc7VUFDbkcsU0FBUyxFQUFFLGdCQUFnQixtQkFBa0I7VUFDN0MsU0FBUztTQUNaLEVBQ0EsS0FBSyxJQUFJLENBQUMsUUFBNEIsS0FBSyxrQkFBa0IsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO01BQzNGO01BT0EsT0FBTyxvQkFBd0MsWUFBa0I7QUFDN0QsY0FBTSxPQUFPLEtBQUssa0JBQWtCLFFBQVEsa0JBQWtCO0FBQzlELGVBQU8sS0FBSyxLQUNQLElBQXdCLGlCQUFpQixVQUFVLHlCQUF5QixrQkFBa0IsSUFBSSxHQUFHO1VBQ2xHLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQWtCO1VBQzdDLFNBQVM7U0FDWixFQUNBLEtBQUssSUFBSSxDQUFDLFFBQTRCLEtBQUssa0JBQWtCLGdCQUFnQixHQUFHLENBQUMsQ0FBQztNQUMzRjtNQVFBLGVBQWUsWUFBb0IsS0FBVyxrQkFBa0IsR0FBQztBQUM3RCxjQUFNLE1BQU0sR0FBRyxLQUFLLFdBQVcsY0FBYyxVQUFVO0FBQ3ZELFlBQUksU0FBUyxvQkFBb0IsR0FBRztBQUNwQyxZQUFJLG9CQUFvQixHQUFHO0FBQ3ZCLG1CQUFTLE9BQU8sSUFBSSxvQkFBb0IsZ0JBQWdCLFNBQVEsQ0FBRTs7QUFFdEUsZUFBTyxLQUFLLEtBQ1AsSUFBMEIsS0FBSztVQUM1QjtVQUNBLFNBQVM7U0FDWixFQUNBLEtBQUssSUFBSSxDQUFDLFFBQTRDLEtBQUssa0JBQWtCLHFCQUFxQixHQUFHLENBQUMsQ0FBQztNQUNoSDtNQVFBLCtCQUErQixZQUFvQixNQUFnQixrQkFBa0IsR0FBQztBQUNsRixjQUFNLE1BQU0saUJBQWlCLFVBQVU7QUFDdkMsWUFBSSxTQUFTLElBQUksV0FBVTtBQUMzQixZQUFJLG9CQUFvQixHQUFHO0FBQ3ZCLG1CQUFTLE9BQU8sSUFBSSxvQkFBb0IsZ0JBQWdCLFNBQVEsQ0FBRTs7QUFFdEUsWUFBSSxNQUFNO0FBQ04sbUJBQVMsT0FBTyxJQUFJLFFBQVEsTUFBTTs7QUFFdEMsZUFBTyxLQUFLLEtBQUssSUFBb0MsS0FBSyxFQUFFLE9BQU0sQ0FBRSxFQUFFLEtBQ2xFLElBQUksQ0FBQyxRQUE0QjtBQUM3QixjQUFJLENBQUMsS0FBSztBQUNOLG1CQUFPOztBQUVYLGlCQUFPLEtBQUssa0JBQWtCLDRCQUE0QixHQUFHO1FBQ2pFLENBQUMsQ0FBQztNQUVWO01BUUEsY0FBYyxjQUFzQixrQkFBa0IsR0FBRyxVQUFpQjtBQUN0RSxjQUFNLE1BQU0sNEJBQTRCLFlBQVk7QUFDcEQsWUFBSSxTQUFTLElBQUksV0FBVTtBQUMzQixZQUFJLG9CQUFvQixHQUFHO0FBQ3ZCLG1CQUFTLE9BQU8sSUFBSSxvQkFBb0IsZ0JBQWdCLFNBQVEsQ0FBRTs7QUFFdEUsWUFBSSxZQUFZLFdBQVcsR0FBRztBQUMxQixtQkFBUyxPQUFPLElBQUksWUFBWSxTQUFTLFNBQVEsQ0FBRTs7QUFFdkQsZUFBTyxLQUFLLEtBQUssSUFBd0IsS0FBSyxFQUFFLE9BQU0sQ0FBRSxFQUFFLEtBQUssSUFBSSxDQUFDLFFBQTRCLEtBQUssa0JBQWtCLDRCQUE0QixHQUFHLENBQUMsQ0FBQztNQUM1SjtNQU1BLHlCQUF5QixjQUFvQjtBQUN6QyxjQUFNLE1BQU0sNEJBQTRCLFlBQVk7QUFDcEQsWUFBSSxTQUFTLElBQUksV0FBVTtBQUMzQixpQkFBUyxPQUFPLElBQUksa0JBQWtCLE1BQU07QUFDNUMsZUFBTyxLQUFLLEtBQUssSUFBd0IsS0FBSyxFQUFFLE9BQU0sQ0FBRSxFQUFFLEtBQUssSUFBSSxDQUFDLFFBQTRCLEtBQUssa0JBQWtCLDRCQUE0QixHQUFHLENBQUMsQ0FBQztNQUM1SjtNQU1BLHFDQUFxQyxpQkFBdUI7QUFDeEQsZUFBTyxLQUFLLEtBQ1AsSUFBd0Isc0JBQXNCLGVBQWUsK0JBQStCLEVBQUUsY0FBYyxPQUFNLENBQUUsRUFDcEgsS0FBSyxJQUFJLENBQUMsUUFBNEIsS0FBSyxrQkFBa0IsNEJBQTRCLEdBQUcsQ0FBQyxDQUFDO01BQ3ZHOzt5QkF4SFMsNEJBQXlCLHNCQUFBLGFBQUEsR0FBQSxzQkFBQSxpQkFBQSxDQUFBO01BQUE7bUVBQXpCLDRCQUF5QixTQUF6QiwyQkFBeUIsV0FBQSxZQURaLE9BQU0sQ0FBQTs7Ozs7O0FDWmhDLElBUVksZ0JBY0M7QUF0QmI7OztBQUVBO0FBTUEsS0FBQSxTQUFZQSxpQkFBYztBQUN0QixNQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxNQUFBQSxnQkFBQSxlQUFBLElBQUE7QUFDQSxNQUFBQSxnQkFBQSxpQkFBQSxJQUFBO0FBQ0EsTUFBQUEsZ0JBQUEsZ0JBQUEsSUFBQTtBQUNBLE1BQUFBLGdCQUFBLHNCQUFBLElBQUE7QUFDQSxNQUFBQSxnQkFBQSxrQkFBQSxJQUFBO0FBQ0EsTUFBQUEsZ0JBQUEsbUJBQUEsSUFBQTtBQUNBLE1BQUFBLGdCQUFBLFVBQUEsSUFBQTtBQUNBLE1BQUFBLGdCQUFBLFlBQUEsSUFBQTtBQUNBLE1BQUFBLGdCQUFBLFdBQUEsSUFBQTtBQUNBLE1BQUFBLGdCQUFBLE1BQUEsSUFBQTtJQUNKLEdBWlksbUJBQUEsaUJBQWMsQ0FBQSxFQUFBO0FBY3BCLElBQU8sbUJBQVAsY0FBZ0MsU0FBUTtNQUNuQztNQUNBO01BQ0E7TUFFUCxZQUFZLGFBQTZCLFFBQTRCLGVBQXdDO0FBQ3pHLGNBQU0sYUFBYSxRQUFRO0FBQzNCLGFBQUssU0FBUztBQUNkLGFBQUssZ0JBQWdCO0FBQ3JCLGFBQUssY0FBYztBQUduQixhQUFLLGlCQUFpQixlQUFlO0FBQ3JDLFlBQUksS0FBSyxnQkFBZ0IsZUFBZSxnQkFBZ0IsS0FBSyxnQkFBZ0IsZUFBZSxpQkFBaUI7QUFDekcsZUFBSyxpQkFBaUIsZUFBZTs7TUFFN0M7Ozs7IiwibmFtZXMiOlsiVU1MRGlhZ3JhbVR5cGUiXX0=