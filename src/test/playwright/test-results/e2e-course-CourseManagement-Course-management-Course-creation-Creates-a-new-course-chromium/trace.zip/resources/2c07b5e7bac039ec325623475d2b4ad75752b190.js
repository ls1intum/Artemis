import {
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/util/crypto.utils.ts
import __vite__cjsImport1_cryptoJs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/crypto-js.js?v=1d0d9ead"; const SHA1 = __vite__cjsImport1_cryptoJs["SHA1"]; const enc = __vite__cjsImport1_cryptoJs["enc"];
function sha1Hex(value) {
  const hash = SHA1(value);
  return enc.Hex.stringify(hash);
}
var init_crypto_utils = __esm({
  "src/main/webapp/app/shared/util/crypto.utils.ts"() {
  }
});

export {
  sha1Hex,
  init_crypto_utils
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3V0aWwvY3J5cHRvLnV0aWxzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNIQTEsIGVuYyB9IGZyb20gJ2NyeXB0by1qcyc7XG5cbi8qKlxuICogR2VuZXJhdGVzIGFuZCByZXR1cm5zIHRoZSBoYXNoIGRpZ2VzdCB1c2luZyAnaGV4JyBhbGdvcml0aG0uXG4gKiBAcGFyYW0gdmFsdWUgVGhlIHN0cmluZyB0byB3aGljaCB0aGUgYWxnb3JpdGhtIHdpbGwgYmUgYXBwbGllZCB1cG9uLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc2hhMUhleCh2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgICBjb25zdCBoYXNoID0gU0hBMSh2YWx1ZSk7XG4gICAgcmV0dXJuIGVuYy5IZXguc3RyaW5naWZ5KGhhc2gpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7OztBQUFBLFNBQVMsTUFBTSxXQUFXO0FBTXBCLFNBQVUsUUFBUSxPQUFhO0FBQ2pDLFFBQU0sT0FBTyxLQUFLLEtBQUs7QUFDdkIsU0FBTyxJQUFJLElBQUksVUFBVSxJQUFJO0FBQ2pDO0FBVEE7Ozs7IiwibmFtZXMiOltdfQ==