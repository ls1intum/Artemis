import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NI5XS6XH.js?v=b97f8625";

// node_modules/dayjs/esm/plugin/isSameOrAfter/index.js
var isSameOrAfter_default = function(o, c) {
  c.prototype.isSameOrAfter = function(that, units) {
    return this.isSame(that, units) || this.isAfter(that, units);
  };
};
export {
  isSameOrAfter_default as default
};
//# sourceMappingURL=dayjs_esm_plugin_isSameOrAfter.js.map
