import {
  ArtemisResultModule,
  init_result_module
} from "/chunk-K5HEFVC3.js";
import {
  ExamExerciseUpdateService,
  init_exam_exercise_update_service
} from "/chunk-DYZ6VJ3M.js";
import {
  ProgrammingExerciseGradingService,
  init_programming_exercise_grading_service
} from "/chunk-KZDJAYFO.js";
import {
  ArtemisMarkdownModule,
  init_markdown_module
} from "/chunk-UF4UUZTK.js";
import {
  ArtemisMarkdownService,
  init_markdown_service
} from "/chunk-7FP3FWGI.js";
import {
  Theme,
  ThemeService,
  init_theme_service
} from "/chunk-PVIIR7SL.js";
import {
  FeedbackComponent,
  ParticipationWebsocketService,
  ProgrammingExerciseParticipationService,
  RepositoryFileService,
  ResultService,
  init_feedback_component,
  init_participation_websocket_service,
  init_programming_exercise_model,
  init_programming_exercise_participation_service,
  init_repository_service,
  init_result_model,
  init_result_service
} from "/chunk-ORYTP7RT.js";
import {
  escapeStringForUseInRegex,
  init_global_utils
} from "/chunk-LW4WH7EZ.js";
import {
  ArtemisSharedCommonModule,
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  ExerciseType,
  __esm,
  findLatestResult,
  hasParticipationChanged,
  init_artemis_translate_pipe,
  init_exercise_model,
  init_exercise_utils,
  init_participation_model,
  init_participation_utils,
  init_programming_exercise_utils,
  init_shared_common_module,
  init_shared_module,
  init_utils,
  isLegacyResult,
  problemStatementHasChanged
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exam/participate/exercises/exam-exercise-update-highlighter/exam-exercise-update-highlighter.component.ts
import { Component, EventEmitter, Input, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { DiffMatchPatch, DiffOperation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/diff-match-patch-typescript.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ExamExerciseUpdateHighlighterComponent;
var init_exam_exercise_update_highlighter_component = __esm({
  "src/main/webapp/app/exam/participate/exercises/exam-exercise-update-highlighter/exam-exercise-update-highlighter.component.ts"() {
    init_exam_exercise_update_service();
    init_exercise_model();
    init_exam_exercise_update_service();
    init_artemis_translate_pipe();
    ExamExerciseUpdateHighlighterComponent = class _ExamExerciseUpdateHighlighterComponent {
      examExerciseUpdateService;
      subscriptionToLiveExamExerciseUpdates;
      themeSubscription;
      previousProblemStatementUpdate;
      updatedProblemStatementWithHighlightedDifferences;
      updatedProblemStatement;
      showHighlightedDifferences = true;
      exercise;
      problemStatementUpdateEvent = new EventEmitter();
      constructor(examExerciseUpdateService) {
        this.examExerciseUpdateService = examExerciseUpdateService;
      }
      ngOnInit() {
        this.subscriptionToLiveExamExerciseUpdates = this.examExerciseUpdateService.currentExerciseIdAndProblemStatement.subscribe((update) => {
          this.updateExerciseProblemStatementById(update.exerciseId, update.problemStatement);
        });
      }
      ngOnDestroy() {
        this.subscriptionToLiveExamExerciseUpdates?.unsubscribe();
        this.themeSubscription?.unsubscribe();
      }
      toggleHighlightedProblemStatement() {
        if (this.showHighlightedDifferences) {
          this.exercise.problemStatement = this.updatedProblemStatement;
        } else {
          this.exercise.problemStatement = this.updatedProblemStatementWithHighlightedDifferences;
        }
        this.showHighlightedDifferences = !this.showHighlightedDifferences;
        this.problemStatementUpdateEvent.emit(this.exercise.problemStatement);
      }
      updateExerciseProblemStatementById(exerciseId, updatedProblemStatement) {
        if (updatedProblemStatement != void 0 && exerciseId === this.exercise.id) {
          this.updatedProblemStatement = updatedProblemStatement;
          this.exercise.problemStatement = this.highlightProblemStatementDifferences();
        }
        this.problemStatementUpdateEvent.emit(this.exercise.problemStatement);
      }
      highlightProblemStatementDifferences() {
        if (!this.updatedProblemStatement) {
          return;
        }
        this.showHighlightedDifferences = true;
        const dmp = new DiffMatchPatch();
        let outdatedProblemStatement;
        if (!this.previousProblemStatementUpdate) {
          outdatedProblemStatement = this.exercise.problemStatement;
        } else {
          outdatedProblemStatement = this.previousProblemStatementUpdate;
        }
        this.previousProblemStatementUpdate = this.updatedProblemStatement;
        let removedDiagrams = [];
        let diff;
        if (this.exercise.type === ExerciseType.PROGRAMMING) {
          const updatedProblemStatementAndRemovedDiagrams = this.removeAnyPlantUmlDiagramsInProblemStatement(this.updatedProblemStatement);
          const outdatedProblemStatementAndRemovedDiagrams = this.removeAnyPlantUmlDiagramsInProblemStatement(outdatedProblemStatement);
          const updatedProblemStatementWithoutDiagrams = updatedProblemStatementAndRemovedDiagrams.problemStatementWithoutPlantUmlDiagrams;
          const outdatedProblemStatementWithoutDiagrams = outdatedProblemStatementAndRemovedDiagrams.problemStatementWithoutPlantUmlDiagrams;
          removedDiagrams = updatedProblemStatementAndRemovedDiagrams.removedDiagrams;
          diff = dmp.diff_main(outdatedProblemStatementWithoutDiagrams, updatedProblemStatementWithoutDiagrams);
        } else {
          diff = dmp.diff_main(outdatedProblemStatement, this.updatedProblemStatement);
        }
        dmp.diff_cleanupEfficiency(diff);
        this.updatedProblemStatementWithHighlightedDifferences = this.diffPrettyHtml(diff);
        if (this.exercise.type === ExerciseType.PROGRAMMING) {
          this.addPlantUmlToProblemStatementWithDiffHighlightAgain(removedDiagrams);
        }
        return this.updatedProblemStatementWithHighlightedDifferences;
      }
      addPlantUmlToProblemStatementWithDiffHighlightAgain(removedDiagrams) {
        removedDiagrams.forEach((text) => {
          this.updatedProblemStatementWithHighlightedDifferences = this.updatedProblemStatementWithHighlightedDifferences.replace("@startuml", "@startuml\n" + text + "\n");
        });
      }
      removeAnyPlantUmlDiagramsInProblemStatement(problemStatement) {
        const plantUmlSequenceRegex = /@startuml([\s\S]*?)@enduml/g;
        const removedDiagrams = [];
        const problemStatementWithoutPlantUmlDiagrams = problemStatement.replace(plantUmlSequenceRegex, (match, content) => {
          removedDiagrams.push(content);
          return "@startuml\n@enduml";
        });
        return {
          problemStatementWithoutPlantUmlDiagrams,
          removedDiagrams
        };
      }
      diffPrettyHtml(diffs) {
        const html = [];
        diffs.forEach((diff, index) => {
          const op = diffs[index][0];
          const text = diffs[index][1];
          switch (op) {
            case DiffOperation.DIFF_INSERT:
              html[index] = '<ins class="bg-success" ">' + text + "</ins>";
              break;
            case DiffOperation.DIFF_DELETE:
              html[index] = '<del class="bg-danger">' + text + "</del>";
              break;
            case DiffOperation.DIFF_EQUAL:
              html[index] = text;
              break;
          }
        });
        return html.join("");
      }
      static \u0275fac = function ExamExerciseUpdateHighlighterComponent_Factory(t) {
        return new (t || _ExamExerciseUpdateHighlighterComponent)(i0.\u0275\u0275directiveInject(ExamExerciseUpdateService));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _ExamExerciseUpdateHighlighterComponent, selectors: [["jhi-exam-exercise-update-highlighter"]], inputs: { exercise: "exercise" }, outputs: { problemStatementUpdateEvent: "problemStatementUpdateEvent" }, decls: 5, vars: 6, consts: [["id", "highlightDiffButton", 1, "btn", "py-0", "px-2", "mt-0", "mb-0", "ms-2", 3, "hidden", "click"]], template: function ExamExerciseUpdateHighlighterComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "button", 0);
          i0.\u0275\u0275listener("click", function ExamExerciseUpdateHighlighterComponent_Template_button_click_0_listener() {
            return ctx.toggleHighlightedProblemStatement();
          });
          i0.\u0275\u0275text(1);
          i0.\u0275\u0275pipe(2, "artemisTranslate");
          i0.\u0275\u0275pipe(3, "artemisTranslate");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(4, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275property("hidden", ctx.previousProblemStatementUpdate === void 0);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275textInterpolate1("\n    ", ctx.showHighlightedDifferences ? i0.\u0275\u0275pipeBind1(2, 2, "artemisApp.exam.problemStatementUpdate.showNew") : i0.\u0275\u0275pipeBind1(3, 4, "artemisApp.exam.problemStatementUpdate.showDiff"), "\n");
        }
      }, dependencies: [ArtemisTranslatePipe], styles: ["\n\n#highlightDiffButton[_ngcontent-%COMP%] {\n  background-color: #fbc107;\n  border: none;\n  text-align: center;\n  text-decoration: none;\n  display: inline-block;\n  font-size: 16px;\n  color: #353d47;\n}\n#highlightDiffButton[_ngcontent-%COMP%]:hover {\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGFtL3BhcnRpY2lwYXRlL2V4ZXJjaXNlcy9leGFtLWV4ZXJjaXNlLXVwZGF0ZS1oaWdobGlnaHRlci9leGFtLWV4ZXJjaXNlLXVwZGF0ZS1oaWdobGlnaHRlci5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiI2hpZ2hsaWdodERpZmZCdXR0b24ge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmYmMxMDc7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBjb2xvcjogIzM1M2Q0NztcblxuICAgICY6aG92ZXIge1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLG9CQUFBO0FBQ0EsVUFBQTtBQUNBLGNBQUE7QUFDQSxtQkFBQTtBQUNBLFdBQUE7QUFDQSxhQUFBO0FBQ0EsU0FBQTs7QUFFQSxDQVRKLG1CQVNJO0FBQ0ksU0FBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(ExamExerciseUpdateHighlighterComponent, { className: "ExamExerciseUpdateHighlighterComponent" });
    })();
  }
});

// src/main/webapp/app/exam/participate/exercises/exam-exercise-update-highlighter/exam-exercise-update-highlighter.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ExamExerciseUpdateHighlighterModule;
var init_exam_exercise_update_highlighter_module = __esm({
  "src/main/webapp/app/exam/participate/exercises/exam-exercise-update-highlighter/exam-exercise-update-highlighter.module.ts"() {
    init_shared_common_module();
    init_exam_exercise_update_highlighter_component();
    ExamExerciseUpdateHighlighterModule = class _ExamExerciseUpdateHighlighterModule {
      static \u0275fac = function ExamExerciseUpdateHighlighterModule_Factory(t) {
        return new (t || _ExamExerciseUpdateHighlighterModule)();
      };
      static \u0275mod = i02.\u0275\u0275defineNgModule({ type: _ExamExerciseUpdateHighlighterModule });
      static \u0275inj = i02.\u0275\u0275defineInjector({ imports: [ArtemisSharedCommonModule] });
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/instructions-render/service/programming-exercise-instruction.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var TestCaseState, testIdRegex, testSplitRegex, ProgrammingExerciseInstructionService;
var init_programming_exercise_instruction_service = __esm({
  "src/main/webapp/app/exercises/programming/shared/instructions-render/service/programming-exercise-instruction.service.ts"() {
    init_programming_exercise_utils();
    (function(TestCaseState2) {
      TestCaseState2["NOT_EXECUTED"] = "NOT_EXECUTED";
      TestCaseState2["SUCCESS"] = "SUCCESS";
      TestCaseState2["FAIL"] = "FAIL";
      TestCaseState2["NO_RESULT"] = "NO_RESULT";
    })(TestCaseState || (TestCaseState = {}));
    testIdRegex = /<testid>(\d+)<\/testid>/;
    testSplitRegex = /,(?![^(]*?\))/;
    ProgrammingExerciseInstructionService = class _ProgrammingExerciseInstructionService {
      testStatusForTask = (testIds, latestResult) => {
        if (latestResult?.successful && (!latestResult.feedbacks || !latestResult.feedbacks.length) && testIds) {
          return { testCaseState: TestCaseState.SUCCESS, detailed: { successfulTests: testIds, failedTests: [], notExecutedTests: [] } };
        }
        if (latestResult?.feedbacks?.length) {
          const { failed, notExecuted, successful } = this.separateTests(testIds, latestResult);
          let testCaseState;
          if (failed.length > 0) {
            testCaseState = TestCaseState.FAIL;
          } else if (notExecuted.length > 0 || testIds.length === 0) {
            testCaseState = TestCaseState.NOT_EXECUTED;
          } else {
            testCaseState = TestCaseState.SUCCESS;
          }
          return { testCaseState, detailed: { successfulTests: successful, failedTests: failed, notExecutedTests: notExecuted } };
        } else {
          return { testCaseState: TestCaseState.NO_RESULT, detailed: { successfulTests: [], failedTests: [], notExecutedTests: testIds } };
        }
      };
      separateTests(tests, latestResult) {
        return tests.reduce((acc, testId) => {
          const feedback = latestResult?.feedbacks?.find((feedback2) => feedback2.testCase?.id === testId);
          const resultIsLegacy = isLegacyResult(latestResult);
          if (resultIsLegacy) {
            return {
              failed: feedback ? [...acc.failed, testId] : acc.failed,
              successful: feedback ? acc.successful : [...acc.successful, testId],
              notExecuted: acc.notExecuted
            };
          }
          return {
            failed: feedback?.positive === false ? [...acc.failed, testId] : acc.failed,
            successful: feedback?.positive === true ? [...acc.successful, testId] : acc.successful,
            notExecuted: feedback?.positive === void 0 ? [...acc.notExecuted, testId] : acc.notExecuted
          };
        }, { failed: [], successful: [], notExecuted: [] });
      }
      convertTestListToIds(testList, testCases) {
        return testList.split(testSplitRegex).map((text) => text.trim()).map((text) => {
          return this.convertProblemStatementTextToTestId(text, testCases) ?? -1;
        });
      }
      convertProblemStatementTextToTestId(test, testCases) {
        const match = testIdRegex.exec(test);
        if (match) {
          return parseInt(match[1]);
        }
        return testCases?.find((testCase) => testCase.testName === test)?.id;
      }
      static \u0275fac = function ProgrammingExerciseInstructionService_Factory(t) {
        return new (t || _ProgrammingExerciseInstructionService)();
      };
      static \u0275prov = i03.\u0275\u0275defineInjectable({ token: _ProgrammingExerciseInstructionService, factory: _ProgrammingExerciseInstructionService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/instructions-render/task/programming-exercise-instruction-task-status.component.ts
import { Component as Component2, Input as Input2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faCheckCircle, faTimesCircle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import { faQuestionCircle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { NgbModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ProgrammingExerciseInstructionTaskStatusComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n        ");
    i04.\u0275\u0275element(1, "fa-icon", 1);
    i04.\u0275\u0275text(2, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("icon", ctx_r0.farCheckCircle);
  }
}
function ProgrammingExerciseInstructionTaskStatusComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n        ");
    i04.\u0275\u0275element(1, "fa-icon", 2);
    i04.\u0275\u0275text(2, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("icon", ctx_r1.farTimesCircle);
  }
}
function ProgrammingExerciseInstructionTaskStatusComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n        ");
    i04.\u0275\u0275element(1, "fa-icon", 3);
    i04.\u0275\u0275text(2, "\n    ");
  }
  if (rf & 2) {
    const ctx_r2 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("icon", ctx_r2.faQuestionCircle);
  }
}
function ProgrammingExerciseInstructionTaskStatusComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n        ");
    i04.\u0275\u0275elementStart(1, "span", 4);
    i04.\u0275\u0275text(2);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(3, "\n    ");
  }
  if (rf & 2) {
    const ctx_r3 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate(ctx_r3.taskName);
  }
}
function ProgrammingExerciseInstructionTaskStatusComponent_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n        ");
    i04.\u0275\u0275elementStart(1, "span", 5);
    i04.\u0275\u0275listener("click", function ProgrammingExerciseInstructionTaskStatusComponent_Conditional_6_Template_span_click_1_listener() {
      i04.\u0275\u0275restoreView(_r7);
      const ctx_r6 = i04.\u0275\u0275nextContext();
      return i04.\u0275\u0275resetView(ctx_r6.showDetailsForTests());
    });
    i04.\u0275\u0275pipe(2, "artemisTranslate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(3, "\n    ");
  }
  if (rf & 2) {
    const ctx_r4 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275classMap((ctx_r4.testIds == null ? null : ctx_r4.testIds.length) === ctx_r4.successfulTests.length ? "text-success" : ctx_r4.failedTests.length ? "text-danger" : "text-secondary");
    i04.\u0275\u0275property("innerHTML", i04.\u0275\u0275pipeBind2(2, 3, ctx_r4.translationBasePath + "totalTestsPassing", i04.\u0275\u0275pureFunction2(6, _c0, ctx_r4.testIds.length, ctx_r4.successfulTests.length)), i04.\u0275\u0275sanitizeHtml);
  }
}
function ProgrammingExerciseInstructionTaskStatusComponent_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n        ");
    i04.\u0275\u0275element(1, "span", 6);
    i04.\u0275\u0275pipe(2, "artemisTranslate");
    i04.\u0275\u0275text(3, "\n    ");
  }
  if (rf & 2) {
    const ctx_r5 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("innerHTML", i04.\u0275\u0275pipeBind1(2, 1, ctx_r5.translationBasePath + (ctx_r5.testIds.length ? "noResult" : "noTests")), i04.\u0275\u0275sanitizeHtml);
  }
}
var _c0, ProgrammingExerciseInstructionTaskStatusComponent;
var init_programming_exercise_instruction_task_status_component = __esm({
  "src/main/webapp/app/exercises/programming/shared/instructions-render/task/programming-exercise-instruction-task-status.component.ts"() {
    init_exercise_model();
    init_result_model();
    init_programming_exercise_instruction_service();
    init_feedback_component();
    init_programming_exercise_instruction_service();
    init_artemis_translate_pipe();
    _c0 = (a0, a1) => ({ totalTests: a0, passedTests: a1 });
    ProgrammingExerciseInstructionTaskStatusComponent = class _ProgrammingExerciseInstructionTaskStatusComponent {
      programmingExerciseInstructionService;
      modalService;
      TestCaseState = TestCaseState;
      translationBasePath = "artemisApp.editor.testStatusLabels.";
      taskName;
      get testIds() {
        return this.testIdsValue;
      }
      exercise;
      latestResult;
      testIdsValue;
      testCaseState;
      successfulTests;
      notExecutedTests;
      failedTests;
      hasMessage;
      faQuestionCircle = faQuestionCircle;
      farCheckCircle = faCheckCircle;
      farTimesCircle = faTimesCircle;
      constructor(programmingExerciseInstructionService, modalService) {
        this.programmingExerciseInstructionService = programmingExerciseInstructionService;
        this.modalService = modalService;
      }
      set testIds(testIds) {
        this.testIdsValue = testIds;
        const { testCaseState, detailed: { successfulTests, notExecutedTests, failedTests } } = this.programmingExerciseInstructionService.testStatusForTask(this.testIds, this.latestResult);
        this.testCaseState = testCaseState;
        this.successfulTests = successfulTests;
        this.notExecutedTests = notExecutedTests;
        this.failedTests = failedTests;
        this.hasMessage = this.hasTestMessage(testIds);
      }
      hasTestMessage(testIds) {
        if (!this.latestResult?.feedbacks) {
          return false;
        }
        const feedbacks = this.latestResult.feedbacks;
        return testIds.some((testId) => feedbacks.find((feedback) => feedback.testCase?.id === testId && feedback.detailText));
      }
      showDetailsForTests() {
        if (!this.latestResult) {
          return;
        }
        const modalRef = this.modalService.open(FeedbackComponent, { keyboard: true, size: "lg" });
        const componentInstance = modalRef.componentInstance;
        componentInstance.exercise = this.exercise;
        componentInstance.result = this.latestResult;
        componentInstance.feedbackFilter = this.testIds;
        componentInstance.exerciseType = ExerciseType.PROGRAMMING;
        componentInstance.taskName = this.taskName;
        componentInstance.numberOfNotExecutedTests = this.notExecutedTests.length;
      }
      static \u0275fac = function ProgrammingExerciseInstructionTaskStatusComponent_Factory(t) {
        return new (t || _ProgrammingExerciseInstructionTaskStatusComponent)(i04.\u0275\u0275directiveInject(ProgrammingExerciseInstructionService), i04.\u0275\u0275directiveInject(i2.NgbModal));
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _ProgrammingExerciseInstructionTaskStatusComponent, selectors: [["jhi-programming-exercise-instructions-task-status"]], inputs: { taskName: "taskName", testIds: "testIds", exercise: "exercise", latestResult: "latestResult" }, decls: 10, vars: 9, consts: [[1, "guided-tour"], ["size", "lg", 1, "test-icon", "text-success", 3, "icon"], ["size", "lg", 1, "test-icon", "text-danger", 3, "icon"], ["size", "lg", 1, "test-icon", "text-secondary", 3, "icon"], [1, "task-name"], [1, "guided-tour", "test-status--linked", 3, "innerHTML", "click"], [1, "text-secondary", 3, "innerHTML"]], template: function ProgrammingExerciseInstructionTaskStatusComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275elementStart(0, "div", 0);
          i04.\u0275\u0275text(1, "\n    ");
          i04.\u0275\u0275template(2, ProgrammingExerciseInstructionTaskStatusComponent_Conditional_2_Template, 3, 1)(3, ProgrammingExerciseInstructionTaskStatusComponent_Conditional_3_Template, 3, 1)(4, ProgrammingExerciseInstructionTaskStatusComponent_Conditional_4_Template, 3, 1)(5, ProgrammingExerciseInstructionTaskStatusComponent_Conditional_5_Template, 4, 1)(6, ProgrammingExerciseInstructionTaskStatusComponent_Conditional_6_Template, 4, 9)(7, ProgrammingExerciseInstructionTaskStatusComponent_Conditional_7_Template, 4, 3);
          i04.\u0275\u0275text(8, "\n");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(9, "\n");
        }
        if (rf & 2) {
          i04.\u0275\u0275classProp("success", ctx.testCaseState === ctx.TestCaseState.SUCCESS)("failed", ctx.testCaseState === ctx.TestCaseState.FAIL);
          i04.\u0275\u0275advance(2);
          i04.\u0275\u0275conditional(2, ctx.testCaseState === ctx.TestCaseState.SUCCESS ? 2 : -1);
          i04.\u0275\u0275advance(1);
          i04.\u0275\u0275conditional(3, ctx.testCaseState === ctx.TestCaseState.FAIL ? 3 : -1);
          i04.\u0275\u0275advance(1);
          i04.\u0275\u0275conditional(4, ctx.testCaseState === ctx.TestCaseState.NO_RESULT || ctx.testCaseState === ctx.TestCaseState.NOT_EXECUTED ? 4 : -1);
          i04.\u0275\u0275advance(1);
          i04.\u0275\u0275conditional(5, ctx.taskName ? 5 : -1);
          i04.\u0275\u0275advance(1);
          i04.\u0275\u0275conditional(6, ctx.latestResult && ctx.latestResult.feedbacks && ctx.latestResult.feedbacks.length && ctx.testIds.length ? 6 : 7);
        }
      }, dependencies: [i3.FaIconComponent, ArtemisTranslatePipe], styles: ["\n\n.test-status--linked[_ngcontent-%COMP%] {\n  text-decoration: underline;\n  cursor: pointer;\n}\n.test-icon[_ngcontent-%COMP%], .task-name[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvdGFzay9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbi10YXNrLXN0YXR1cy5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIudGVzdC1zdGF0dXMtLWxpbmtlZCB7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xufVxuLnRlc3QtaWNvbixcbi50YXNrLW5hbWUge1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLENBQUE7QUFDSSxtQkFBQTtBQUNBLFVBQUE7O0FBRUosQ0FBQTtBQUFBLENBQUE7QUFFSSxlQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(ProgrammingExerciseInstructionTaskStatusComponent, { className: "ProgrammingExerciseInstructionTaskStatusComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/programming/shared/instructions-render/extensions/programming-exercise-task.extension.ts
import { Injectable as Injectable2, Injector } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var taskRegex, ProgrammingExerciseTaskExtensionWrapper;
var init_programming_exercise_task_extension = __esm({
  "src/main/webapp/app/exercises/programming/shared/instructions-render/extensions/programming-exercise-task.extension.ts"() {
    init_programming_exercise_instruction_service();
    init_programming_exercise_instruction_task_status_component();
    init_global_utils();
    init_programming_exercise_instruction_service();
    taskRegex = /\[task]\[([^[\]]+)]\(((?:[^(),]+(?:\([^()]*\)[^(),]*)?(?:,[^(),]+(?:\([^()]*\)[^(),]*)?)*)?)\)/g;
    ProgrammingExerciseTaskExtensionWrapper = class _ProgrammingExerciseTaskExtensionWrapper {
      programmingExerciseInstructionService;
      injector;
      viewContainerRef;
      latestResult;
      exercise;
      testCases;
      testsForTaskSubject = new Subject();
      injectableElementsFoundSubject = new Subject();
      taskIndex = 0;
      constructor(programmingExerciseInstructionService, injector) {
        this.programmingExerciseInstructionService = programmingExerciseInstructionService;
        this.injector = injector;
      }
      setLatestResult(result) {
        this.latestResult = result;
      }
      setExercise(exercise) {
        this.exercise = exercise;
      }
      setTestCases(testCases) {
        this.testCases = testCases;
      }
      subscribeForFoundTestsInTasks() {
        return this.testsForTaskSubject.asObservable();
      }
      subscribeForInjectableElementsFound() {
        return this.injectableElementsFoundSubject.asObservable();
      }
      injectTasks = (tasks) => {
        tasks.forEach(({ id, taskName, testIds }) => {
          const taskHtmlContainers = document.getElementsByClassName(`pe-task-${id}`);
          for (let i = 0; i < taskHtmlContainers.length; i++) {
            const componentRef = this.viewContainerRef.createComponent(ProgrammingExerciseInstructionTaskStatusComponent, { injector: this.injector });
            componentRef.instance.exercise = this.exercise;
            componentRef.instance.taskName = taskName;
            componentRef.instance.latestResult = this.latestResult;
            componentRef.instance.testIds = testIds;
            componentRef.changeDetectorRef.detectChanges();
            const domElem = componentRef.hostView.rootNodes[0];
            const taskHtmlContainer = taskHtmlContainers[i];
            taskHtmlContainer.replaceChildren(domElem);
          }
        });
      };
      getExtension() {
        const extension = {
          type: "lang",
          filter: (problemStatement) => {
            const tasks = Array.from(problemStatement.matchAll(taskRegex));
            if (tasks) {
              return this.createTasks(problemStatement, tasks);
            }
            return problemStatement;
          }
        };
        return extension;
      }
      createTasks(problemStatement, tasks) {
        const testsForTask = tasks.filter((testMatch) => testMatch?.length === 3).map((testMatch) => {
          const nextIndex = this.taskIndex;
          this.taskIndex++;
          return {
            id: nextIndex,
            completeString: testMatch[0],
            taskName: testMatch[1],
            testIds: testMatch[2] ? this.programmingExerciseInstructionService.convertTestListToIds(testMatch[2], this.testCases) : []
          };
        });
        const tasksWithParticipationId = {
          exerciseId: this.exercise.id,
          tasks: testsForTask
        };
        this.testsForTaskSubject.next(tasksWithParticipationId);
        this.injectableElementsFoundSubject.next(() => {
          this.injectTasks(testsForTask);
        });
        return testsForTask.reduce((acc, { completeString: task, id }) => acc.replace(new RegExp(escapeStringForUseInRegex(task), "g"), `<div class="pe-task-${id.toString()} d-flex">&#8203;</div>`), problemStatement);
      }
      static \u0275fac = function ProgrammingExerciseTaskExtensionWrapper_Factory(t) {
        return new (t || _ProgrammingExerciseTaskExtensionWrapper)(i05.\u0275\u0275inject(ProgrammingExerciseInstructionService), i05.\u0275\u0275inject(i05.Injector));
      };
      static \u0275prov = i05.\u0275\u0275defineInjectable({ token: _ProgrammingExerciseTaskExtensionWrapper, factory: _ProgrammingExerciseTaskExtensionWrapper.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/instructions-render/service/programming-exercise-plant-uml.service.ts
import { __decorate, __metadata } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/tslib.js?v=1d0d9ead";
import { Injectable as Injectable3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient, HttpParams } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { Cacheable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ts-cacheable.js?v=1d0d9ead";
import { Observable, Subject as Subject2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { map, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var themeChangedSubject, ProgrammingExercisePlantUmlService, HttpUrlCustomEncoder;
var init_programming_exercise_plant_uml_service = __esm({
  "src/main/webapp/app/exercises/programming/shared/instructions-render/service/programming-exercise-plant-uml.service.ts"() {
    init_theme_service();
    init_theme_service();
    themeChangedSubject = new Subject2();
    ProgrammingExercisePlantUmlService = class _ProgrammingExercisePlantUmlService {
      http;
      themeService;
      resourceUrl = "api/plantuml";
      encoder;
      constructor(http, themeService) {
        this.http = http;
        this.themeService = themeService;
        this.encoder = new HttpUrlCustomEncoder();
        this.themeService.getCurrentThemeObservable().pipe(tap(() => themeChangedSubject.next())).subscribe();
      }
      getPlantUmlImage(plantUml) {
        return this.http.get(`${this.resourceUrl}/png`, {
          params: new HttpParams({ encoder: this.encoder }).set("plantuml", plantUml).set("useDarkTheme", this.themeService.getCurrentTheme() === Theme.DARK),
          responseType: "arraybuffer"
        }).pipe(map((res) => this.convertPlantUmlResponseToBase64(res)));
      }
      getPlantUmlSvg(plantUml) {
        return this.http.get(`${this.resourceUrl}/svg`, {
          params: new HttpParams({ encoder: this.encoder }).set("plantuml", plantUml).set("useDarkTheme", this.themeService.getCurrentTheme() === Theme.DARK),
          responseType: "text"
        });
      }
      convertPlantUmlResponseToBase64(res) {
        return Buffer.from(res, "binary").toString("base64");
      }
      static \u0275fac = function ProgrammingExercisePlantUmlService_Factory(t) {
        return new (t || _ProgrammingExercisePlantUmlService)(i06.\u0275\u0275inject(i1.HttpClient), i06.\u0275\u0275inject(ThemeService));
      };
      static \u0275prov = i06.\u0275\u0275defineInjectable({ token: _ProgrammingExercisePlantUmlService, factory: _ProgrammingExercisePlantUmlService.\u0275fac, providedIn: "root" });
    };
    __decorate([
      Cacheable({
        maxCacheCount: 100,
        maxAge: 36e5,
        slidingExpiration: true,
        cacheBusterObserver: themeChangedSubject
      }),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [String]),
      __metadata("design:returntype", void 0)
    ], ProgrammingExercisePlantUmlService.prototype, "getPlantUmlImage", null);
    __decorate([
      Cacheable({
        maxCacheCount: 100,
        maxAge: 36e5,
        slidingExpiration: true,
        cacheBusterObserver: themeChangedSubject
      }),
      __metadata("design:type", Function),
      __metadata("design:paramtypes", [String]),
      __metadata("design:returntype", Observable)
    ], ProgrammingExercisePlantUmlService.prototype, "getPlantUmlSvg", null);
    HttpUrlCustomEncoder = class {
      encodeKey(k) {
        return encodeURIComponent(k);
      }
      encodeValue(v) {
        return encodeURIComponent(v);
      }
      decodeKey(k) {
        return decodeURIComponent(k);
      }
      decodeValue(v) {
        return decodeURIComponent(v);
      }
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/instructions-render/extensions/programming-exercise-plant-uml.extension.ts
import { Injectable as Injectable4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject as Subject3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { tap as tap2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import DOMPurify from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dompurify.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var testsColorRegex, ProgrammingExercisePlantUmlExtensionWrapper;
var init_programming_exercise_plant_uml_extension = __esm({
  "src/main/webapp/app/exercises/programming/shared/instructions-render/extensions/programming-exercise-plant-uml.extension.ts"() {
    init_global_utils();
    init_programming_exercise_instruction_service();
    init_programming_exercise_plant_uml_service();
    init_programming_exercise_instruction_service();
    init_programming_exercise_plant_uml_service();
    testsColorRegex = /testsColor\((\s*[^()\s]+(\([^()]*\))?)\)/g;
    ProgrammingExercisePlantUmlExtensionWrapper = class _ProgrammingExercisePlantUmlExtensionWrapper {
      programmingExerciseInstructionService;
      plantUmlService;
      latestResult;
      testCases;
      injectableElementsFoundSubject = new Subject3();
      plantUmlIndex = 0;
      constructor(programmingExerciseInstructionService, plantUmlService) {
        this.programmingExerciseInstructionService = programmingExerciseInstructionService;
        this.plantUmlService = plantUmlService;
      }
      setLatestResult(result) {
        this.latestResult = result;
      }
      setTestCases(testCases) {
        this.testCases = testCases;
      }
      subscribeForInjectableElementsFound() {
        return this.injectableElementsFoundSubject.asObservable();
      }
      loadAndInjectPlantUml(plantUml, index) {
        this.plantUmlService.getPlantUmlSvg(plantUml).pipe(tap2((plantUmlSvg) => {
          const plantUmlHtmlContainer = document.getElementById(`plantUml-${index}`);
          if (plantUmlHtmlContainer) {
            plantUmlHtmlContainer.innerHTML = DOMPurify.sanitize(plantUmlSvg);
          }
        })).subscribe();
      }
      getExtension() {
        const extension = {
          type: "lang",
          filter: (text) => {
            const idPlaceholder = "%idPlaceholder%";
            const plantUmlRegex = /@startuml([^@]*)@enduml/g;
            const plantUmlContainer = `<div class="mb-4" id="plantUml-${idPlaceholder}"></div>`;
            const plantUmls = text.match(plantUmlRegex) ?? [];
            const plantUmlsIndexed = plantUmls.map((plantUml) => {
              const nextIndex = this.plantUmlIndex;
              this.plantUmlIndex++;
              return { plantUmlId: nextIndex, plantUml };
            });
            const replacedText = plantUmlsIndexed.reduce((acc, umlIndexed) => {
              return acc.replace(new RegExp(escapeStringForUseInRegex(umlIndexed.plantUml), "g"), plantUmlContainer.replace(idPlaceholder, umlIndexed.plantUmlId.toString()));
            }, text);
            const plantUmlsValidated = plantUmlsIndexed.map((plantUmlIndexed) => {
              plantUmlIndexed.plantUml = plantUmlIndexed.plantUml.replace(testsColorRegex, (match, capture) => {
                const tests = this.programmingExerciseInstructionService.convertTestListToIds(capture, this.testCases);
                const { testCaseState } = this.programmingExerciseInstructionService.testStatusForTask(tests, this.latestResult);
                switch (testCaseState) {
                  case TestCaseState.SUCCESS:
                    return "green";
                  case TestCaseState.FAIL:
                    return "red";
                  default:
                    return "grey";
                }
              });
              return plantUmlIndexed;
            });
            this.injectableElementsFoundSubject.next(() => {
              plantUmlsValidated.forEach((plantUmlIndexed) => {
                this.loadAndInjectPlantUml(plantUmlIndexed.plantUml, plantUmlIndexed.plantUmlId);
              });
            });
            return replacedText;
          }
        };
        return extension;
      }
      static \u0275fac = function ProgrammingExercisePlantUmlExtensionWrapper_Factory(t) {
        return new (t || _ProgrammingExercisePlantUmlExtensionWrapper)(i07.\u0275\u0275inject(ProgrammingExerciseInstructionService), i07.\u0275\u0275inject(ProgrammingExercisePlantUmlService));
      };
      static \u0275prov = i07.\u0275\u0275defineInjectable({ token: _ProgrammingExercisePlantUmlExtensionWrapper, factory: _ProgrammingExercisePlantUmlExtensionWrapper.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/instructions-render/step-wizard/programming-exercise-instruction-step-wizard.component.ts
import { Component as Component3, Input as Input3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgbModal as NgbModal3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { faCheck, faQuestion, faTimes } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i08 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ProgrammingExerciseInstructionStepWizardComponent_For_11_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                            ");
    i08.\u0275\u0275element(1, "fa-icon", 6);
    i08.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r6 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("icon", ctx_r6.faCheck);
  }
}
function ProgrammingExerciseInstructionStepWizardComponent_For_11_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                            ");
    i08.\u0275\u0275element(1, "fa-icon", 7);
    i08.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r7 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("icon", ctx_r7.faTimes);
  }
}
function ProgrammingExerciseInstructionStepWizardComponent_For_11_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                            ");
    i08.\u0275\u0275element(1, "fa-icon", 8);
    i08.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r8 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("icon", ctx_r8.faQuestion);
  }
}
function ProgrammingExerciseInstructionStepWizardComponent_For_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275elementStart(1, "div", 4);
    i08.\u0275\u0275text(2, "\n                    ");
    i08.\u0275\u0275text(3, "\n                    ");
    i08.\u0275\u0275elementStart(4, "div", 5);
    i08.\u0275\u0275listener("click", function ProgrammingExerciseInstructionStepWizardComponent_For_11_Template_div_click_4_listener() {
      const restoredCtx = i08.\u0275\u0275restoreView(_r10);
      const step_r1 = restoredCtx.$implicit;
      const ctx_r9 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r9.showDetailsForTests(step_r1.testIds, step_r1.title));
    });
    i08.\u0275\u0275text(5, "\n                        ");
    i08.\u0275\u0275template(6, ProgrammingExerciseInstructionStepWizardComponent_For_11_Conditional_6_Template, 3, 1)(7, ProgrammingExerciseInstructionStepWizardComponent_For_11_Conditional_7_Template, 3, 1)(8, ProgrammingExerciseInstructionStepWizardComponent_For_11_Conditional_8_Template, 3, 1);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(9, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(10, "\n            ");
  }
  if (rf & 2) {
    const step_r1 = ctx.$implicit;
    const ctx_r0 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(4);
    i08.\u0275\u0275classProp("stepwizard-step--success", step_r1.done === ctx_r0.TestCaseState.SUCCESS)("stepwizard-step--failed", step_r1.done === ctx_r0.TestCaseState.FAIL)("stepwizard-step--not-executed", step_r1.done === ctx_r0.TestCaseState.NOT_EXECUTED)("stepwizard-step--no-result", step_r1.done === ctx_r0.TestCaseState.NO_RESULT);
    i08.\u0275\u0275property("ngbTooltip", step_r1.title);
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275conditional(6, step_r1.done === ctx_r0.TestCaseState.SUCCESS ? 6 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275conditional(7, step_r1.done === ctx_r0.TestCaseState.FAIL ? 7 : -1);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275conditional(8, step_r1.done === ctx_r0.TestCaseState.NOT_EXECUTED || step_r1.done === ctx_r0.TestCaseState.NO_RESULT ? 8 : -1);
  }
}
var ProgrammingExerciseInstructionStepWizardComponent;
var init_programming_exercise_instruction_step_wizard_component = __esm({
  "src/main/webapp/app/exercises/programming/shared/instructions-render/step-wizard/programming-exercise-instruction-step-wizard.component.ts"() {
    init_programming_exercise_instruction_service();
    init_feedback_component();
    init_exercise_model();
    init_result_model();
    init_programming_exercise_instruction_service();
    init_artemis_translate_pipe();
    ProgrammingExerciseInstructionStepWizardComponent = class _ProgrammingExerciseInstructionStepWizardComponent {
      modalService;
      instructionService;
      TestCaseState = TestCaseState;
      exercise;
      latestResult;
      tasks;
      steps;
      faTimes = faTimes;
      faCheck = faCheck;
      faQuestion = faQuestion;
      constructor(modalService, instructionService) {
        this.modalService = modalService;
        this.instructionService = instructionService;
      }
      ngOnChanges(changes) {
        if (changes.tasks && this.tasks || this.tasks && changes.latestResult) {
          this.steps = this.tasks.map(({ taskName, testIds }) => ({
            done: this.instructionService.testStatusForTask(testIds, this.latestResult).testCaseState,
            title: taskName,
            testIds
          }));
        }
      }
      showDetailsForTests(tests, taskName) {
        if (!this.latestResult || !tests.length) {
          return;
        }
        const { detailed: { notExecutedTests } } = this.instructionService.testStatusForTask(tests, this.latestResult);
        const modalRef = this.modalService.open(FeedbackComponent, { keyboard: true, size: "lg" });
        const componentInstance = modalRef.componentInstance;
        componentInstance.exercise = this.exercise;
        componentInstance.result = this.latestResult;
        componentInstance.feedbackFilter = tests;
        componentInstance.exerciseType = ExerciseType.PROGRAMMING;
        componentInstance.taskName = taskName;
        componentInstance.numberOfNotExecutedTests = notExecutedTests.length;
      }
      static \u0275fac = function ProgrammingExerciseInstructionStepWizardComponent_Factory(t) {
        return new (t || _ProgrammingExerciseInstructionStepWizardComponent)(i08.\u0275\u0275directiveInject(i12.NgbModal), i08.\u0275\u0275directiveInject(ProgrammingExerciseInstructionService));
      };
      static \u0275cmp = i08.\u0275\u0275defineComponent({ type: _ProgrammingExerciseInstructionStepWizardComponent, selectors: [["jhi-programming-exercise-instructions-step-wizard"]], inputs: { exercise: "exercise", latestResult: "latestResult", tasks: "tasks" }, features: [i08.\u0275\u0275NgOnChangesFeature], decls: 15, vars: 4, consts: [[1, "card-second-header", 3, "hidden"], [1, "stepwizard"], [1, "stepwizard-title"], [1, "stepwizard-row"], [1, "stepwizard-step"], [1, "btn", "btn-circle", 3, "ngbTooltip", "click"], ["size", "lg", 1, "text-success", 3, "icon"], ["size", "lg", 1, "text-danger", 3, "icon"], ["size", "lg", 1, "not-done", 3, "icon"]], template: function ProgrammingExerciseInstructionStepWizardComponent_Template(rf, ctx) {
        if (rf & 1) {
          i08.\u0275\u0275elementStart(0, "div", 0);
          i08.\u0275\u0275text(1, "\n    ");
          i08.\u0275\u0275elementStart(2, "div", 1);
          i08.\u0275\u0275text(3, "\n        ");
          i08.\u0275\u0275elementStart(4, "div", 2);
          i08.\u0275\u0275text(5);
          i08.\u0275\u0275pipe(6, "artemisTranslate");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(7, "\n        ");
          i08.\u0275\u0275elementStart(8, "div", 3);
          i08.\u0275\u0275text(9, "\n            ");
          i08.\u0275\u0275repeaterCreate(10, ProgrammingExerciseInstructionStepWizardComponent_For_11_Template, 11, 12, null, null, i08.\u0275\u0275repeaterTrackByIdentity);
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(12, "\n    ");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(13, "\n");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(14, "\n");
        }
        if (rf & 2) {
          i08.\u0275\u0275property("hidden", !(ctx.steps == null ? null : ctx.steps.length));
          i08.\u0275\u0275advance(5);
          i08.\u0275\u0275textInterpolate1("\n            ", i08.\u0275\u0275pipeBind1(6, 2, "artemisApp.programmingExercise.problemStatement.tasksOfExercise"), "\n        ");
          i08.\u0275\u0275advance(5);
          i08.\u0275\u0275repeater(ctx.steps);
        }
      }, dependencies: [i12.NgbTooltip, i32.FaIconComponent, ArtemisTranslatePipe], styles: ["\n\n.card-second-header[_ngcontent-%COMP%] {\n  padding: 1rem;\n  background-color: var(--programming-exercise-instruction-step-wizard-card-header-background);\n  border-bottom: 1px solid var(--programming-exercise-instruction-step-wizard-card-header-border);\n}\n.stepwizard[_ngcontent-%COMP%] {\n  display: table;\n  width: 100%;\n  position: relative;\n}\n.stepwizard-title[_ngcontent-%COMP%] {\n  display: table-cell;\n  width: 1%;\n}\n.stepwizard-row[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: space-evenly;\n}\n.stepwizard-step[_ngcontent-%COMP%] {\n  display: table-cell;\n  text-align: center;\n  position: relative;\n}\n.stepwizard-step[_ngcontent-%COMP%]   .fa[_ngcontent-%COMP%] {\n  vertical-align: initial;\n}\n.stepwizard-step[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin-top: 10px;\n}\n.stepwizard-step[_ngcontent-%COMP%]   button[disabled][_ngcontent-%COMP%] {\n  opacity: 1 !important;\n  filter: alpha(opacity=100) !important;\n  cursor: default;\n}\n.stepwizard-step--no-result.btn[_ngcontent-%COMP%] {\n  cursor: default;\n}\n.stepwizard-step--failed.btn[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\n.stepwizard-step[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\n  cursor: default;\n  background-color: var(--programming-exercise-instruction-step-wizard-card-header-background);\n  width: 30px;\n  height: 30px;\n  text-align: center;\n  padding: 6px 0;\n  font-size: 12px;\n  line-height: 1.428571429;\n  border-radius: 15px;\n  border-color: var(--programming-exercise-instruction-step-wizard-btn-border-color);\n}\n.stepwizard-step[_ngcontent-%COMP%]   .btn.not-done[_ngcontent-%COMP%] {\n  color: var(--programming-exercise-instruction-step-wizard-circle-not-done-color);\n}\n.test-passing[_ngcontent-%COMP%] {\n  cursor: default !important;\n}\n.test-passing[_ngcontent-%COMP%]:hover {\n  background-color: var(--programming-exercise-instruction-step-wizard-test-passing-hover-color);\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvc3RlcC13aXphcmQvcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rpb24tc3RlcC13aXphcmQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmNhcmQtc2Vjb25kLWhlYWRlciB7XG4gICAgcGFkZGluZzogMXJlbTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbi1zdGVwLXdpemFyZC1jYXJkLWhlYWRlci1iYWNrZ3JvdW5kKTtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0tcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rpb24tc3RlcC13aXphcmQtY2FyZC1oZWFkZXItYm9yZGVyKTtcbn1cblxuLnN0ZXB3aXphcmQge1xuICAgIGRpc3BsYXk6IHRhYmxlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLnN0ZXB3aXphcmQtdGl0bGUge1xuICAgIGRpc3BsYXk6IHRhYmxlLWNlbGw7XG4gICAgd2lkdGg6IDElO1xufVxuXG4uc3RlcHdpemFyZC1yb3cge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC13cmFwOiB3cmFwO1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xufVxuXG4uc3RlcHdpemFyZC1zdGVwIHtcbiAgICBkaXNwbGF5OiB0YWJsZS1jZWxsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgICAuZmEge1xuICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogaW5pdGlhbDtcbiAgICB9XG5cbiAgICBwIHtcbiAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICB9XG5cbiAgICBidXR0b25bZGlzYWJsZWRdIHtcbiAgICAgICAgb3BhY2l0eTogMSAhaW1wb3J0YW50O1xuICAgICAgICBmaWx0ZXI6IGFscGhhKG9wYWNpdHk9MTAwKSAhaW1wb3J0YW50O1xuICAgICAgICBjdXJzb3I6IGRlZmF1bHQ7XG4gICAgfVxuXG4gICAgJi0tbm8tcmVzdWx0LmJ0biB7XG4gICAgICAgIGN1cnNvcjogZGVmYXVsdDtcbiAgICB9XG5cbiAgICAmLS1mYWlsZWQuYnRuIHtcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIH1cblxuICAgIC5idG4ge1xuICAgICAgICBjdXJzb3I6IGRlZmF1bHQ7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXByb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9uLXN0ZXAtd2l6YXJkLWNhcmQtaGVhZGVyLWJhY2tncm91bmQpO1xuICAgICAgICB3aWR0aDogMzBweDtcbiAgICAgICAgaGVpZ2h0OiAzMHB4O1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIHBhZGRpbmc6IDZweCAwO1xuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxLjQyODU3MTQyOTtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTVweDtcbiAgICAgICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbi1zdGVwLXdpemFyZC1idG4tYm9yZGVyLWNvbG9yKTtcbiAgICB9XG5cbiAgICAuYnRuLm5vdC1kb25lIHtcbiAgICAgICAgY29sb3I6IHZhcigtLXByb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9uLXN0ZXAtd2l6YXJkLWNpcmNsZS1ub3QtZG9uZS1jb2xvcik7XG4gICAgfVxufVxuXG4udGVzdC1wYXNzaW5nIHtcbiAgICBjdXJzb3I6IGRlZmF1bHQgIWltcG9ydGFudDtcbn1cblxuLnRlc3QtcGFzc2luZzpob3ZlciB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rpb24tc3RlcC13aXphcmQtdGVzdC1wYXNzaW5nLWhvdmVyLWNvbG9yKTtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksV0FBQTtBQUNBLG9CQUFBLElBQUE7QUFDQSxpQkFBQSxJQUFBLE1BQUEsSUFBQTs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLFNBQUE7QUFDQSxZQUFBOztBQUdKLENBQUE7QUFDSSxXQUFBO0FBQ0EsU0FBQTs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLGFBQUE7QUFDQSxtQkFBQTs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLGNBQUE7QUFDQSxZQUFBOztBQUVBLENBTEosZ0JBS0ksQ0FBQTtBQUNJLGtCQUFBOztBQUdKLENBVEosZ0JBU0k7QUFDSSxjQUFBOztBQUdKLENBYkosZ0JBYUksTUFBQSxDQUFBO0FBQ0ksV0FBQTtBQUNBLFVBQUEsTUFBQSxPQUFBLENBQUE7QUFDQSxVQUFBOztBQUdKLENBQUEsMEJBQUEsQ0FBQTtBQUNJLFVBQUE7O0FBR0osQ0FBQSx1QkFBQSxDQUpBO0FBS0ksVUFBQTs7QUFHSixDQTNCSixnQkEyQkksQ0FSQTtBQVNJLFVBQUE7QUFDQSxvQkFBQSxJQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxjQUFBO0FBQ0EsV0FBQSxJQUFBO0FBQ0EsYUFBQTtBQUNBLGVBQUE7QUFDQSxpQkFBQTtBQUNBLGdCQUFBLElBQUE7O0FBR0osQ0F4Q0osZ0JBd0NJLENBckJBLEdBcUJBLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBSVIsQ0FBQTtBQUNJLFVBQUE7O0FBR0osQ0FKQSxZQUlBO0FBQ0ksb0JBQUEsSUFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassDebugInfo(ProgrammingExerciseInstructionStepWizardComponent, { className: "ProgrammingExerciseInstructionStepWizardComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/programming/shared/instructions-render/programming-exercise-instruction.component.ts
import { Component as Component4, EventEmitter as EventEmitter2, Input as Input4, Output as Output2, ViewContainerRef } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { catchError, filter, map as map2, mergeMap, switchMap, tap as tap3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { Observable as Observable2, merge, of } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { faSpinner } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i09 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i10 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ProgrammingExerciseInstructionComponent_Conditional_0_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i09.\u0275\u0275getCurrentView();
    i09.\u0275\u0275text(0, "\n            ");
    i09.\u0275\u0275elementStart(1, "jhi-exam-exercise-update-highlighter", 3);
    i09.\u0275\u0275listener("problemStatementUpdateEvent", function ProgrammingExerciseInstructionComponent_Conditional_0_Conditional_6_Template_jhi_exam_exercise_update_highlighter_problemStatementUpdateEvent_1_listener() {
      i09.\u0275\u0275restoreView(_r4);
      const ctx_r3 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r3.renderUpdatedProblemStatement());
    });
    i09.\u0275\u0275text(2, " ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(3, "\n        ");
  }
  if (rf & 2) {
    const ctx_r2 = i09.\u0275\u0275nextContext(2);
    i09.\u0275\u0275advance(1);
    i09.\u0275\u0275property("exercise", ctx_r2.exercise);
  }
}
function ProgrammingExerciseInstructionComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n    ");
    i09.\u0275\u0275elementStart(1, "div", 0);
    i09.\u0275\u0275text(2, "\n        ");
    i09.\u0275\u0275element(3, "jhi-programming-exercise-instructions-step-wizard", 1);
    i09.\u0275\u0275text(4, "\n        ");
    i09.\u0275\u0275text(5, "\n        ");
    i09.\u0275\u0275template(6, ProgrammingExerciseInstructionComponent_Conditional_0_Conditional_6_Template, 4, 1);
    i09.\u0275\u0275text(7, "\n        ");
    i09.\u0275\u0275element(8, "div", 2);
    i09.\u0275\u0275text(9, "\n    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(10, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("exercise", ctx_r0.exercise)("latestResult", ctx_r0.latestResult)("tasks", ctx_r0.tasks);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275conditional(6, ctx_r0.exercise && ctx_r0.exercise.exerciseGroup ? 6 : -1);
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275property("hidden", !ctx_r0.renderedMarkdown)("innerHtml", ctx_r0.renderedMarkdown, i09.\u0275\u0275sanitizeHtml);
  }
}
function ProgrammingExerciseInstructionComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n    ");
    i09.\u0275\u0275elementStart(1, "span", 4);
    i09.\u0275\u0275element(2, "fa-icon", 5);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(3, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275property("icon", ctx_r1.faSpinner)("spin", true);
  }
}
var ProgrammingExerciseInstructionComponent;
var init_programming_exercise_instruction_component = __esm({
  "src/main/webapp/app/exercises/programming/shared/instructions-render/programming-exercise-instruction.component.ts"() {
    init_theme_service();
    init_programming_exercise_grading_service();
    init_programming_exercise_model();
    init_participation_websocket_service();
    init_markdown_service();
    init_programming_exercise_task_extension();
    init_programming_exercise_plant_uml_extension();
    init_participation_model();
    init_result_service();
    init_repository_service();
    init_exercise_utils();
    init_programming_exercise_participation_service();
    init_utils();
    init_participation_utils();
    init_result_service();
    init_repository_service();
    init_participation_websocket_service();
    init_markdown_service();
    init_programming_exercise_task_extension();
    init_programming_exercise_plant_uml_extension();
    init_programming_exercise_participation_service();
    init_programming_exercise_grading_service();
    init_theme_service();
    init_exam_exercise_update_highlighter_component();
    init_programming_exercise_instruction_step_wizard_component();
    ProgrammingExerciseInstructionComponent = class _ProgrammingExerciseInstructionComponent {
      viewContainerRef;
      resultService;
      repositoryFileService;
      participationWebsocketService;
      markdownService;
      programmingExerciseTaskWrapper;
      programmingExercisePlantUmlWrapper;
      programmingExerciseParticipationService;
      programmingExerciseGradingService;
      exercise;
      participation;
      generateHtmlEvents;
      personalParticipation;
      onNoInstructionsAvailable = new EventEmitter2();
      problemStatement;
      participationSubscription;
      testCasesSubscription;
      isInitial = true;
      isLoading;
      latestResultValue;
      get latestResult() {
        return this.latestResultValue;
      }
      set latestResult(result) {
        this.latestResultValue = result;
        this.programmingExerciseTaskWrapper.setExercise(this.exercise);
        this.programmingExerciseTaskWrapper.setLatestResult(this.latestResult);
        this.programmingExercisePlantUmlWrapper.setLatestResult(this.latestResult);
        this.programmingExerciseTaskWrapper.setTestCases(this.testCases);
        this.programmingExercisePlantUmlWrapper.setTestCases(this.testCases);
      }
      tasks;
      renderedMarkdown;
      injectableContentForMarkdownCallbacks = [];
      markdownExtensions;
      injectableContentFoundSubscription;
      tasksSubscription;
      generateHtmlSubscription;
      themeChangeSubscription;
      testCases;
      faSpinner = faSpinner;
      constructor(viewContainerRef, resultService, repositoryFileService, participationWebsocketService, markdownService, programmingExerciseTaskWrapper, programmingExercisePlantUmlWrapper, programmingExerciseParticipationService, programmingExerciseGradingService, themeService) {
        this.viewContainerRef = viewContainerRef;
        this.resultService = resultService;
        this.repositoryFileService = repositoryFileService;
        this.participationWebsocketService = participationWebsocketService;
        this.markdownService = markdownService;
        this.programmingExerciseTaskWrapper = programmingExerciseTaskWrapper;
        this.programmingExercisePlantUmlWrapper = programmingExercisePlantUmlWrapper;
        this.programmingExerciseParticipationService = programmingExerciseParticipationService;
        this.programmingExerciseGradingService = programmingExerciseGradingService;
        this.programmingExerciseTaskWrapper.viewContainerRef = this.viewContainerRef;
        this.themeChangeSubscription = themeService.getCurrentThemeObservable().subscribe(() => {
          this.updateMarkdown();
        });
      }
      ngOnChanges(changes) {
        of(!!this.markdownExtensions).pipe(tap3((markdownExtensionsInitialized) => !markdownExtensionsInitialized && this.setupMarkdownSubscriptions()), map2(() => hasParticipationChanged(changes)), tap3((participationHasChanged) => {
          if (participationHasChanged) {
            this.isInitial = true;
            if (this.generateHtmlSubscription) {
              this.generateHtmlSubscription.unsubscribe();
            }
            if (this.generateHtmlEvents) {
              this.generateHtmlEvents.subscribe(() => {
                this.updateMarkdown();
              });
            }
            this.setupResultWebsocket();
          }
        }), switchMap((participationHasChanged) => {
          if (!this.isLoading && this.exercise && this.participation && (this.isInitial || participationHasChanged)) {
            this.isLoading = true;
            return this.loadInstructions().pipe(tap3((problemStatement) => {
              if (!problemStatement) {
                this.onNoInstructionsAvailable.emit();
                this.isLoading = false;
                this.isInitial = false;
                return of(void 0);
              }
            }), filter((problemStatement) => !!problemStatement), tap3((problemStatement) => this.problemStatement = problemStatement), switchMap(() => this.loadInitialResult()), tap3((latestResult) => {
              this.latestResult = latestResult;
            }), tap3(() => {
              this.updateMarkdown();
              this.isInitial = false;
              this.isLoading = false;
            }));
          } else if (problemStatementHasChanged(changes) && this.problemStatement === void 0) {
            this.latestResult = this.latestResultValue;
            this.problemStatement = this.exercise.problemStatement;
            this.updateMarkdown();
            return of(void 0);
          } else if (this.exercise && problemStatementHasChanged(changes)) {
            this.latestResult = this.latestResultValue;
            this.problemStatement = this.exercise.problemStatement;
            return of(void 0);
          } else {
            return of(void 0);
          }
        })).subscribe();
      }
      ngOnInit() {
        if (this.exercise?.isAtLeastTutor) {
          this.testCasesSubscription = this.programmingExerciseGradingService.getTestCases(this.exercise.id).pipe(tap3((testCases) => {
            this.testCases = testCases;
          })).subscribe();
        }
      }
      setupMarkdownSubscriptions() {
        this.markdownExtensions = [this.programmingExerciseTaskWrapper.getExtension(), this.programmingExercisePlantUmlWrapper.getExtension()];
        if (this.injectableContentFoundSubscription) {
          this.injectableContentFoundSubscription.unsubscribe();
        }
        this.injectableContentFoundSubscription = merge(this.programmingExerciseTaskWrapper.subscribeForInjectableElementsFound(), this.programmingExercisePlantUmlWrapper.subscribeForInjectableElementsFound()).subscribe((injectableCallback) => {
          this.injectableContentForMarkdownCallbacks = [...this.injectableContentForMarkdownCallbacks, injectableCallback];
        });
        if (this.tasksSubscription) {
          this.tasksSubscription.unsubscribe();
        }
        this.tasksSubscription = this.programmingExerciseTaskWrapper.subscribeForFoundTestsInTasks().subscribe((tasks) => {
          if (tasks.exerciseId === this.exercise.id) {
            this.tasks = tasks.tasks;
          }
        });
      }
      setupResultWebsocket() {
        if (this.participationSubscription) {
          this.participationSubscription.unsubscribe();
        }
        this.participationSubscription = this.participationWebsocketService.subscribeForLatestResultOfParticipation(this.participation.id, this.personalParticipation, this.exercise.id).pipe(filter((result) => !!result)).subscribe((result) => {
          this.latestResult = result;
          this.programmingExerciseTaskWrapper.setLatestResult(this.latestResult);
          this.programmingExercisePlantUmlWrapper.setLatestResult(this.latestResult);
          this.updateMarkdown();
        });
      }
      updateMarkdown() {
        this.latestResult = this.latestResult;
        this.injectableContentForMarkdownCallbacks = [];
        this.renderedMarkdown = this.markdownService.safeHtmlForMarkdown(this.problemStatement, this.markdownExtensions);
        setTimeout(() => this.injectableContentForMarkdownCallbacks.forEach((callback) => {
          callback();
        }), 0);
      }
      renderUpdatedProblemStatement() {
        this.problemStatement = this.exercise.problemStatement;
        this.updateMarkdown();
      }
      loadInitialResult() {
        if (this.participation?.id && this.participation?.results?.length) {
          const latestResult = findLatestResult(this.participation.results);
          if (!latestResult) {
            return of(void 0);
          }
          latestResult.participation = this.participation;
          return latestResult.feedbacks ? of(latestResult) : this.loadAndAttachResultDetails(latestResult);
        } else if (this.participation && this.participation.id) {
          return this.loadLatestResult();
        } else {
          return of(void 0);
        }
      }
      loadLatestResult() {
        return this.programmingExerciseParticipationService.getLatestResultWithFeedback(this.participation.id, true).pipe(catchError(() => of(void 0)), mergeMap((latestResult) => latestResult && !latestResult.feedbacks ? this.loadAndAttachResultDetails(latestResult) : of(latestResult)));
      }
      loadAndAttachResultDetails(result) {
        const currentParticipation = result.participation ? result.participation : this.participation;
        return this.resultService.getFeedbackDetailsForResult(currentParticipation.id, result).pipe(map2((res) => res && res.body), map2((feedbacks) => {
          result.feedbacks = feedbacks;
          return result;
        }), catchError(() => of(result)));
      }
      loadInstructions() {
        if (this.exercise.problemStatement) {
          return of(this.exercise.problemStatement);
        } else {
          if (!this.participation.id) {
            return of(void 0);
          }
          return this.repositoryFileService.get(this.participation.id, "README.md").pipe(catchError(() => of(void 0)), map2((fileObj) => fileObj && fileObj.fileContent.replace(new RegExp(/✅/, "g"), "[task]")));
        }
      }
      ngOnDestroy() {
        if (this.participationSubscription) {
          this.participationSubscription.unsubscribe();
        }
        if (this.generateHtmlSubscription) {
          this.generateHtmlSubscription.unsubscribe();
        }
        if (this.injectableContentFoundSubscription) {
          this.injectableContentFoundSubscription.unsubscribe();
        }
        if (this.tasksSubscription) {
          this.tasksSubscription.unsubscribe();
        }
        if (this.testCasesSubscription) {
          this.testCasesSubscription.unsubscribe();
        }
        if (this.themeChangeSubscription) {
          this.themeChangeSubscription.unsubscribe();
        }
      }
      static \u0275fac = function ProgrammingExerciseInstructionComponent_Factory(t) {
        return new (t || _ProgrammingExerciseInstructionComponent)(i09.\u0275\u0275directiveInject(i09.ViewContainerRef), i09.\u0275\u0275directiveInject(ResultService), i09.\u0275\u0275directiveInject(RepositoryFileService), i09.\u0275\u0275directiveInject(ParticipationWebsocketService), i09.\u0275\u0275directiveInject(ArtemisMarkdownService), i09.\u0275\u0275directiveInject(ProgrammingExerciseTaskExtensionWrapper), i09.\u0275\u0275directiveInject(ProgrammingExercisePlantUmlExtensionWrapper), i09.\u0275\u0275directiveInject(ProgrammingExerciseParticipationService), i09.\u0275\u0275directiveInject(ProgrammingExerciseGradingService), i09.\u0275\u0275directiveInject(ThemeService));
      };
      static \u0275cmp = i09.\u0275\u0275defineComponent({ type: _ProgrammingExerciseInstructionComponent, selectors: [["jhi-programming-exercise-instructions"]], inputs: { exercise: "exercise", participation: "participation", generateHtmlEvents: "generateHtmlEvents", personalParticipation: "personalParticipation" }, outputs: { onNoInstructionsAvailable: "onNoInstructionsAvailable" }, features: [i09.\u0275\u0275NgOnChangesFeature], decls: 2, vars: 1, consts: [[1, "instructions__content", "border-0"], [3, "exercise", "latestResult", "tasks"], ["id", "programming-exercise-instructions-content", 1, "guided-tour", "instructions__content__markdown", "markdown-preview", 3, "hidden", "innerHtml"], [3, "exercise", "problemStatementUpdateEvent"], ["id", "programming-exercise-instructions-loading", 1, "d-flex", "justify-content-center", "mt-2"], ["size", "lg", 3, "icon", "spin"]], template: function ProgrammingExerciseInstructionComponent_Template(rf, ctx) {
        if (rf & 1) {
          i09.\u0275\u0275template(0, ProgrammingExerciseInstructionComponent_Conditional_0_Template, 11, 6)(1, ProgrammingExerciseInstructionComponent_Conditional_1_Template, 4, 2);
        }
        if (rf & 2) {
          i09.\u0275\u0275conditional(0, !ctx.isLoading ? 0 : 1);
        }
      }, dependencies: [i10.FaIconComponent, ExamExerciseUpdateHighlighterComponent, ProgrammingExerciseInstructionStepWizardComponent], styles: ["\n\n.instructions[_ngcontent-%COMP%] {\n  display: flex;\n  flex-flow: column nowrap;\n  flex: 1 1 auto;\n  height: 100%;\n}\n.instructions__content[_ngcontent-%COMP%] {\n  display: flex;\n  flex-flow: column nowrap;\n  flex: 1 1 auto;\n  height: 100%;\n}\n.instructions__content__markdown[_ngcontent-%COMP%] {\n  height: inherit;\n  overflow: auto;\n  padding: 1rem;\n}\n\n\n\n\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rpb24uc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyohKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuSW5zdHJ1Y3Rpb25zIHdyYXBwZXIgc3R5bGVzXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqISovXG5cbi5pbnN0cnVjdGlvbnMge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1mbG93OiBjb2x1bW4gbm93cmFwO1xuICAgIGZsZXg6IDEgMSBhdXRvO1xuICAgIGhlaWdodDogMTAwJTtcblxuICAgICZfX2NvbnRlbnQge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWZsb3c6IGNvbHVtbiBub3dyYXA7XG4gICAgICAgIGZsZXg6IDEgMSBhdXRvO1xuICAgICAgICBoZWlnaHQ6IDEwMCU7XG5cbiAgICAgICAgJl9fbWFya2Rvd24ge1xuICAgICAgICAgICAgaGVpZ2h0OiBpbmhlcml0O1xuICAgICAgICAgICAgb3ZlcmZsb3c6IGF1dG87XG4gICAgICAgICAgICBwYWRkaW5nOiAxcmVtO1xuICAgICAgICB9XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUlBLENBQUE7QUFDSSxXQUFBO0FBQ0EsYUFBQSxPQUFBO0FBQ0EsUUFBQSxFQUFBLEVBQUE7QUFDQSxVQUFBOztBQUVBLENBQUE7QUFDSSxXQUFBO0FBQ0EsYUFBQSxPQUFBO0FBQ0EsUUFBQSxFQUFBLEVBQUE7QUFDQSxVQUFBOztBQUVBLENBQUE7QUFDSSxVQUFBO0FBQ0EsWUFBQTtBQUNBLFdBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i09.\u0275setClassDebugInfo(ProgrammingExerciseInstructionComponent, { className: "ProgrammingExerciseInstructionComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/programming/shared/instructions-render/programming-exercise-instructions-render.module.ts
import { NgModule as NgModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i010 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisProgrammingExerciseInstructionsRenderModule;
var init_programming_exercise_instructions_render_module = __esm({
  "src/main/webapp/app/exercises/programming/shared/instructions-render/programming-exercise-instructions-render.module.ts"() {
    init_shared_module();
    init_result_module();
    init_programming_exercise_instruction_component();
    init_programming_exercise_instruction_step_wizard_component();
    init_programming_exercise_instruction_task_status_component();
    init_markdown_module();
    init_exam_exercise_update_highlighter_module();
    ArtemisProgrammingExerciseInstructionsRenderModule = class _ArtemisProgrammingExerciseInstructionsRenderModule {
      static \u0275fac = function ArtemisProgrammingExerciseInstructionsRenderModule_Factory(t) {
        return new (t || _ArtemisProgrammingExerciseInstructionsRenderModule)();
      };
      static \u0275mod = i010.\u0275\u0275defineNgModule({ type: _ArtemisProgrammingExerciseInstructionsRenderModule });
      static \u0275inj = i010.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, ArtemisResultModule, ArtemisMarkdownModule, ExamExerciseUpdateHighlighterModule] });
    };
  }
});

export {
  ExamExerciseUpdateHighlighterComponent,
  init_exam_exercise_update_highlighter_component,
  ProgrammingExerciseInstructionComponent,
  init_programming_exercise_instruction_component,
  ExamExerciseUpdateHighlighterModule,
  init_exam_exercise_update_highlighter_module,
  ArtemisProgrammingExerciseInstructionsRenderModule,
  init_programming_exercise_instructions_render_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhhbS9wYXJ0aWNpcGF0ZS9leGVyY2lzZXMvZXhhbS1leGVyY2lzZS11cGRhdGUtaGlnaGxpZ2h0ZXIvZXhhbS1leGVyY2lzZS11cGRhdGUtaGlnaGxpZ2h0ZXIuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGFtL3BhcnRpY2lwYXRlL2V4ZXJjaXNlcy9leGFtLWV4ZXJjaXNlLXVwZGF0ZS1oaWdobGlnaHRlci9leGFtLWV4ZXJjaXNlLXVwZGF0ZS1oaWdobGlnaHRlci5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhhbS9wYXJ0aWNpcGF0ZS9leGVyY2lzZXMvZXhhbS1leGVyY2lzZS11cGRhdGUtaGlnaGxpZ2h0ZXIvZXhhbS1leGVyY2lzZS11cGRhdGUtaGlnaGxpZ2h0ZXIubW9kdWxlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvc2VydmljZS9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbi5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvdGFzay9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbi10YXNrLXN0YXR1cy5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvaW5zdHJ1Y3Rpb25zLXJlbmRlci90YXNrL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9uLXRhc2stc3RhdHVzLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvZXh0ZW5zaW9ucy9wcm9ncmFtbWluZy1leGVyY2lzZS10YXNrLmV4dGVuc2lvbi50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9pbnN0cnVjdGlvbnMtcmVuZGVyL3NlcnZpY2UvcHJvZ3JhbW1pbmctZXhlcmNpc2UtcGxhbnQtdW1sLnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvaW5zdHJ1Y3Rpb25zLXJlbmRlci9leHRlbnNpb25zL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXBsYW50LXVtbC5leHRlbnNpb24udHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvaW5zdHJ1Y3Rpb25zLXJlbmRlci9zdGVwLXdpemFyZC9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbi1zdGVwLXdpemFyZC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvaW5zdHJ1Y3Rpb25zLXJlbmRlci9zdGVwLXdpemFyZC9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbi1zdGVwLXdpemFyZC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9pbnN0cnVjdGlvbnMtcmVuZGVyL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9uLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9pbnN0cnVjdGlvbnMtcmVuZGVyL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9uLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rpb25zLXJlbmRlci5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIElucHV0LCBPbkRlc3Ryb3ksIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEV4YW1FeGVyY2lzZVVwZGF0ZVNlcnZpY2UgfSBmcm9tICdhcHAvZXhhbS9tYW5hZ2UvZXhhbS1leGVyY2lzZS11cGRhdGUuc2VydmljZSc7XG5pbXBvcnQgeyBFeGVyY2lzZSwgRXhlcmNpc2VUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IERpZmYsIERpZmZNYXRjaFBhdGNoLCBEaWZmT3BlcmF0aW9uIH0gZnJvbSAnZGlmZi1tYXRjaC1wYXRjaC10eXBlc2NyaXB0JztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktZXhhbS1leGVyY2lzZS11cGRhdGUtaGlnaGxpZ2h0ZXInLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9leGFtLWV4ZXJjaXNlLXVwZGF0ZS1oaWdobGlnaHRlci5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vZXhhbS1leGVyY2lzZS11cGRhdGUtaGlnaGxpZ2h0ZXIuY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgRXhhbUV4ZXJjaXNlVXBkYXRlSGlnaGxpZ2h0ZXJDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gICAgc3Vic2NyaXB0aW9uVG9MaXZlRXhhbUV4ZXJjaXNlVXBkYXRlczogU3Vic2NyaXB0aW9uO1xuICAgIHRoZW1lU3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb247XG4gICAgcHJldmlvdXNQcm9ibGVtU3RhdGVtZW50VXBkYXRlPzogc3RyaW5nO1xuICAgIHVwZGF0ZWRQcm9ibGVtU3RhdGVtZW50V2l0aEhpZ2hsaWdodGVkRGlmZmVyZW5jZXM6IHN0cmluZztcbiAgICB1cGRhdGVkUHJvYmxlbVN0YXRlbWVudDogc3RyaW5nO1xuICAgIHNob3dIaWdobGlnaHRlZERpZmZlcmVuY2VzID0gdHJ1ZTtcbiAgICBASW5wdXQoKSBleGVyY2lzZTogRXhlcmNpc2U7XG5cbiAgICBAT3V0cHV0KCkgcHJvYmxlbVN0YXRlbWVudFVwZGF0ZUV2ZW50OiBFdmVudEVtaXR0ZXI8c3RyaW5nPiA9IG5ldyBFdmVudEVtaXR0ZXI8c3RyaW5nPigpO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBleGFtRXhlcmNpc2VVcGRhdGVTZXJ2aWNlOiBFeGFtRXhlcmNpc2VVcGRhdGVTZXJ2aWNlKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuc3Vic2NyaXB0aW9uVG9MaXZlRXhhbUV4ZXJjaXNlVXBkYXRlcyA9IHRoaXMuZXhhbUV4ZXJjaXNlVXBkYXRlU2VydmljZS5jdXJyZW50RXhlcmNpc2VJZEFuZFByb2JsZW1TdGF0ZW1lbnQuc3Vic2NyaWJlKCh1cGRhdGUpID0+IHtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlRXhlcmNpc2VQcm9ibGVtU3RhdGVtZW50QnlJZCh1cGRhdGUuZXhlcmNpc2VJZCwgdXBkYXRlLnByb2JsZW1TdGF0ZW1lbnQpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5zdWJzY3JpcHRpb25Ub0xpdmVFeGFtRXhlcmNpc2VVcGRhdGVzPy51bnN1YnNjcmliZSgpO1xuICAgICAgICB0aGlzLnRoZW1lU3Vic2NyaXB0aW9uPy51bnN1YnNjcmliZSgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFN3aXRjaGVzIHRoZSB2aWV3IGJldHdlZW4gdGhlIG5ldyh1cGRhdGVkKSBwcm9ibGVtIHN0YXRlbWVudCB3aXRob3V0IHRoZSBkaWZmZXJlbmNlXG4gICAgICogd2l0aCB0aGUgdmlldyBzaG93aW5nIHRoZSBkaWZmZXJlbmNlIGJldHdlZW4gdGhlIG5ldyBhbmQgb2xkIHByb2JsZW0gc3RhdGVtZW50IGFuZCB2aWNlIHZlcnNhLlxuICAgICAqL1xuICAgIHRvZ2dsZUhpZ2hsaWdodGVkUHJvYmxlbVN0YXRlbWVudCgpOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMuc2hvd0hpZ2hsaWdodGVkRGlmZmVyZW5jZXMpIHtcbiAgICAgICAgICAgIHRoaXMuZXhlcmNpc2UucHJvYmxlbVN0YXRlbWVudCA9IHRoaXMudXBkYXRlZFByb2JsZW1TdGF0ZW1lbnQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmV4ZXJjaXNlLnByb2JsZW1TdGF0ZW1lbnQgPSB0aGlzLnVwZGF0ZWRQcm9ibGVtU3RhdGVtZW50V2l0aEhpZ2hsaWdodGVkRGlmZmVyZW5jZXM7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zaG93SGlnaGxpZ2h0ZWREaWZmZXJlbmNlcyA9ICF0aGlzLnNob3dIaWdobGlnaHRlZERpZmZlcmVuY2VzO1xuICAgICAgICB0aGlzLnByb2JsZW1TdGF0ZW1lbnRVcGRhdGVFdmVudC5lbWl0KHRoaXMuZXhlcmNpc2UucHJvYmxlbVN0YXRlbWVudCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlcyB0aGUgcHJvYmxlbSBzdGF0ZW1lbnQgb2YgdGhlIHByb3ZpZGVkIGV4ZXJjaXNlcyBiYXNlZCBvbiBpdHMgaWQuXG4gICAgICogQWxzbyBjYWxscyB0aGUgbWV0aG9kIHRvIGhpZ2hsaWdodCB0aGUgZGlmZmVyZW5jZXMgYmV0d2VlbiB0aGUgb2xkIGFuZCBuZXcgcHJvYmxlbSBzdGF0ZW1lbnQuXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlSWQgaXMgdGhlIGlkIG9mIHRoZSBleGVyY2lzZSB3aGljaCBwcm9ibGVtIHN0YXRlbWVudCBzaG91bGQgYmUgdXBkYXRlZC5cbiAgICAgKiBAcGFyYW0gdXBkYXRlZFByb2JsZW1TdGF0ZW1lbnQgaXMgdGhlIG5ldyBwcm9ibGVtIHN0YXRlbWVudCB0aGF0IHNob3VsZCByZXBsYWNlIHRoZSBvbGQgb25lLlxuICAgICAqL1xuICAgIHVwZGF0ZUV4ZXJjaXNlUHJvYmxlbVN0YXRlbWVudEJ5SWQoZXhlcmNpc2VJZDogbnVtYmVyLCB1cGRhdGVkUHJvYmxlbVN0YXRlbWVudDogc3RyaW5nKSB7XG4gICAgICAgIGlmICh1cGRhdGVkUHJvYmxlbVN0YXRlbWVudCAhPSB1bmRlZmluZWQgJiYgZXhlcmNpc2VJZCA9PT0gdGhpcy5leGVyY2lzZS5pZCkge1xuICAgICAgICAgICAgdGhpcy51cGRhdGVkUHJvYmxlbVN0YXRlbWVudCA9IHVwZGF0ZWRQcm9ibGVtU3RhdGVtZW50O1xuICAgICAgICAgICAgdGhpcy5leGVyY2lzZS5wcm9ibGVtU3RhdGVtZW50ID0gdGhpcy5oaWdobGlnaHRQcm9ibGVtU3RhdGVtZW50RGlmZmVyZW5jZXMoKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnByb2JsZW1TdGF0ZW1lbnRVcGRhdGVFdmVudC5lbWl0KHRoaXMuZXhlcmNpc2UucHJvYmxlbVN0YXRlbWVudCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ29tcHV0ZXMgdGhlIGRpZmZlcmVuY2UgYmV0d2VlbiB0aGUgb2xkIGFuZCBuZXcgKHVwZGF0ZWQpIHByb2JsZW0gc3RhdGVtZW50IGFuZCBkaXNwbGF5cyB0aGlzIGRpZmZlcmVuY2UuXG4gICAgICovXG4gICAgaGlnaGxpZ2h0UHJvYmxlbVN0YXRlbWVudERpZmZlcmVuY2VzKCkge1xuICAgICAgICBpZiAoIXRoaXMudXBkYXRlZFByb2JsZW1TdGF0ZW1lbnQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuc2hvd0hpZ2hsaWdodGVkRGlmZmVyZW5jZXMgPSB0cnVlO1xuXG4gICAgICAgIC8vIGNyZWF0ZXMgdGhlIGRpZmZNYXRjaFBhdGNoIGxpYnJhcnkgb2JqZWN0IHRvIGJlIGFibGUgdG8gbW9kaWZ5IHN0cmluZ3NcbiAgICAgICAgY29uc3QgZG1wID0gbmV3IERpZmZNYXRjaFBhdGNoKCk7XG4gICAgICAgIGxldCBvdXRkYXRlZFByb2JsZW1TdGF0ZW1lbnQ6IHN0cmluZztcblxuICAgICAgICAvLyBjaGVja3MgaWYgZmlyc3QgdXBkYXRlIGkuZS4gbm8gaGlnaGxpZ2h0XG4gICAgICAgIGlmICghdGhpcy5wcmV2aW91c1Byb2JsZW1TdGF0ZW1lbnRVcGRhdGUpIHtcbiAgICAgICAgICAgIG91dGRhdGVkUHJvYmxlbVN0YXRlbWVudCA9IHRoaXMuZXhlcmNpc2UucHJvYmxlbVN0YXRlbWVudCE7XG4gICAgICAgICAgICAvLyBlbHNlIHVzZSBwcmV2aW91c1Byb2JsZW1TdGF0ZW1lbnRVcGRhdGUgYXMgbmV3IG91dGRhdGVkUHJvYmxlbVN0YXRlbWVudCB0byBhdm9pZCBpbnNlcnRlZCBIVE1MIGVsZW1lbnRzXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBvdXRkYXRlZFByb2JsZW1TdGF0ZW1lbnQgPSB0aGlzLnByZXZpb3VzUHJvYmxlbVN0YXRlbWVudFVwZGF0ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMucHJldmlvdXNQcm9ibGVtU3RhdGVtZW50VXBkYXRlID0gdGhpcy51cGRhdGVkUHJvYmxlbVN0YXRlbWVudDtcbiAgICAgICAgbGV0IHJlbW92ZWREaWFncmFtczogc3RyaW5nW10gPSBbXTtcbiAgICAgICAgbGV0IGRpZmY6IERpZmZbXTtcbiAgICAgICAgaWYgKHRoaXMuZXhlcmNpc2UudHlwZSA9PT0gRXhlcmNpc2VUeXBlLlBST0dSQU1NSU5HKSB7XG4gICAgICAgICAgICBjb25zdCB1cGRhdGVkUHJvYmxlbVN0YXRlbWVudEFuZFJlbW92ZWREaWFncmFtcyA9IHRoaXMucmVtb3ZlQW55UGxhbnRVbWxEaWFncmFtc0luUHJvYmxlbVN0YXRlbWVudCh0aGlzLnVwZGF0ZWRQcm9ibGVtU3RhdGVtZW50KTtcbiAgICAgICAgICAgIGNvbnN0IG91dGRhdGVkUHJvYmxlbVN0YXRlbWVudEFuZFJlbW92ZWREaWFncmFtcyA9IHRoaXMucmVtb3ZlQW55UGxhbnRVbWxEaWFncmFtc0luUHJvYmxlbVN0YXRlbWVudChvdXRkYXRlZFByb2JsZW1TdGF0ZW1lbnQpO1xuICAgICAgICAgICAgY29uc3QgdXBkYXRlZFByb2JsZW1TdGF0ZW1lbnRXaXRob3V0RGlhZ3JhbXMgPSB1cGRhdGVkUHJvYmxlbVN0YXRlbWVudEFuZFJlbW92ZWREaWFncmFtcy5wcm9ibGVtU3RhdGVtZW50V2l0aG91dFBsYW50VW1sRGlhZ3JhbXM7XG4gICAgICAgICAgICBjb25zdCBvdXRkYXRlZFByb2JsZW1TdGF0ZW1lbnRXaXRob3V0RGlhZ3JhbXMgPSBvdXRkYXRlZFByb2JsZW1TdGF0ZW1lbnRBbmRSZW1vdmVkRGlhZ3JhbXMucHJvYmxlbVN0YXRlbWVudFdpdGhvdXRQbGFudFVtbERpYWdyYW1zO1xuICAgICAgICAgICAgcmVtb3ZlZERpYWdyYW1zID0gdXBkYXRlZFByb2JsZW1TdGF0ZW1lbnRBbmRSZW1vdmVkRGlhZ3JhbXMucmVtb3ZlZERpYWdyYW1zO1xuICAgICAgICAgICAgZGlmZiA9IGRtcC5kaWZmX21haW4ob3V0ZGF0ZWRQcm9ibGVtU3RhdGVtZW50V2l0aG91dERpYWdyYW1zISwgdXBkYXRlZFByb2JsZW1TdGF0ZW1lbnRXaXRob3V0RGlhZ3JhbXMpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZGlmZiA9IGRtcC5kaWZmX21haW4ob3V0ZGF0ZWRQcm9ibGVtU3RhdGVtZW50ISwgdGhpcy51cGRhdGVkUHJvYmxlbVN0YXRlbWVudCk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gZmluZHMgdGhlIGluaXRpYWwgZGlmZmVyZW5jZSB0aGVuIGNsZWFucyB0aGUgdGV4dCB3aXRoIGFkZGVkIGh0bWwgJiBjc3MgZWxlbWVudHNcbiAgICAgICAgZG1wLmRpZmZfY2xlYW51cEVmZmljaWVuY3koZGlmZik7XG4gICAgICAgIHRoaXMudXBkYXRlZFByb2JsZW1TdGF0ZW1lbnRXaXRoSGlnaGxpZ2h0ZWREaWZmZXJlbmNlcyA9IHRoaXMuZGlmZlByZXR0eUh0bWwoZGlmZik7XG5cbiAgICAgICAgaWYgKHRoaXMuZXhlcmNpc2UudHlwZSA9PT0gRXhlcmNpc2VUeXBlLlBST0dSQU1NSU5HKSB7XG4gICAgICAgICAgICB0aGlzLmFkZFBsYW50VW1sVG9Qcm9ibGVtU3RhdGVtZW50V2l0aERpZmZIaWdobGlnaHRBZ2FpbihyZW1vdmVkRGlhZ3JhbXMpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLnVwZGF0ZWRQcm9ibGVtU3RhdGVtZW50V2l0aEhpZ2hsaWdodGVkRGlmZmVyZW5jZXM7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBhZGRQbGFudFVtbFRvUHJvYmxlbVN0YXRlbWVudFdpdGhEaWZmSGlnaGxpZ2h0QWdhaW4ocmVtb3ZlZERpYWdyYW1zOiBzdHJpbmdbXSkge1xuICAgICAgICByZW1vdmVkRGlhZ3JhbXMuZm9yRWFjaCgodGV4dCkgPT4ge1xuICAgICAgICAgICAgdGhpcy51cGRhdGVkUHJvYmxlbVN0YXRlbWVudFdpdGhIaWdobGlnaHRlZERpZmZlcmVuY2VzID0gdGhpcy51cGRhdGVkUHJvYmxlbVN0YXRlbWVudFdpdGhIaWdobGlnaHRlZERpZmZlcmVuY2VzLnJlcGxhY2UoJ0BzdGFydHVtbCcsICdAc3RhcnR1bWxcXG4nICsgdGV4dCArICdcXG4nKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSByZW1vdmVBbnlQbGFudFVtbERpYWdyYW1zSW5Qcm9ibGVtU3RhdGVtZW50KHByb2JsZW1TdGF0ZW1lbnQ6IHN0cmluZyk6IHtcbiAgICAgICAgcHJvYmxlbVN0YXRlbWVudFdpdGhvdXRQbGFudFVtbERpYWdyYW1zOiBzdHJpbmc7XG4gICAgICAgIHJlbW92ZWREaWFncmFtczogc3RyaW5nW107XG4gICAgfSB7XG4gICAgICAgIC8vIFJlZ3VsYXIgZXhwcmVzc2lvbiB0byBtYXRjaCBjb250ZW50IGJldHdlZW4gQHN0YXJ0dW1sIGFuZCBAZW5kdW1sXG4gICAgICAgIGNvbnN0IHBsYW50VW1sU2VxdWVuY2VSZWdleCA9IC9Ac3RhcnR1bWwoW1xcc1xcU10qPylAZW5kdW1sL2c7XG4gICAgICAgIGNvbnN0IHJlbW92ZWREaWFncmFtczogc3RyaW5nW10gPSBbXTtcbiAgICAgICAgY29uc3QgcHJvYmxlbVN0YXRlbWVudFdpdGhvdXRQbGFudFVtbERpYWdyYW1zID0gcHJvYmxlbVN0YXRlbWVudC5yZXBsYWNlKHBsYW50VW1sU2VxdWVuY2VSZWdleCwgKG1hdGNoLCBjb250ZW50KSA9PiB7XG4gICAgICAgICAgICByZW1vdmVkRGlhZ3JhbXMucHVzaChjb250ZW50KTtcbiAgICAgICAgICAgIC8vIHdlIGhhdmUgdG8ga2VlcCB0aGUgbWFya2Vycywgb3RoZXJ3aXNlIHdlIGNhbm5vdCBhZGQgdGhlIGRpYWdyYW1zIGJhY2sgbGF0ZXJcbiAgICAgICAgICAgIHJldHVybiAnQHN0YXJ0dW1sXFxuQGVuZHVtbCc7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcHJvYmxlbVN0YXRlbWVudFdpdGhvdXRQbGFudFVtbERpYWdyYW1zLFxuICAgICAgICAgICAgcmVtb3ZlZERpYWdyYW1zLFxuICAgICAgICB9O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENvbnZlcnQgYSBkaWZmIGFycmF5IGludG8gYSBwcmV0dHkgSFRNTCByZXBvcnQuXG4gICAgICogS2VlcHMgbWFya2Rvd24gc3R5bGluZyBpbnRhY3QgKG5vdCBsaWtlIHRoZSBvcmlnaW5hbCBtZXRob2QpXG4gICAgICogTW9kaWZpZWQgZGlmZl9wcmV0dEh0bWwoKSBtZXRob2QgZnJvbSBEaWZmTWF0Y2hQYXRjaFxuICAgICAqIFRoZSBvcmlnaW5hbCBsaWJyYXJ5IG1ldGhvZCBpcyBpbnRlbmRlZCB0byBiZSBtb2RpZmllZFxuICAgICAqIGZvciBtb3JlIGluZm86IGh0dHBzOi8vd3d3Lm5wbWpzLmNvbS9wYWNrYWdlL2RpZmYtbWF0Y2gtcGF0Y2gsXG4gICAgICogaHR0cHM6Ly9naXRodWIuY29tL2dvb2dsZS9kaWZmLW1hdGNoLXBhdGNoL2Jsb2IvbWFzdGVyL2phdmFzY3JpcHQvZGlmZl9tYXRjaF9wYXRjaF91bmNvbXByZXNzZWQuanNcbiAgICAgKlxuICAgICAqIEBwYXJhbSBkaWZmcyBBcnJheSBvZiBkaWZmIHR1cGxlcy4gKGZyb20gRGlmZk1hdGNoUGF0Y2gpXG4gICAgICogQHJldHVybiB0aGUgSFRNTCByZXByZXNlbnRhdGlvbiBhcyBzdHJpbmcgd2l0aCBtYXJrZG93biBpbnRhY3QuXG4gICAgICovXG4gICAgcHJpdmF0ZSBkaWZmUHJldHR5SHRtbChkaWZmczogRGlmZltdKTogc3RyaW5nIHtcbiAgICAgICAgY29uc3QgaHRtbDogYW55W10gPSBbXTtcbiAgICAgICAgZGlmZnMuZm9yRWFjaCgoZGlmZjogRGlmZiwgaW5kZXg6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgY29uc3Qgb3AgPSBkaWZmc1tpbmRleF1bMF07IC8vIE9wZXJhdGlvbiAoaW5zZXJ0LCBkZWxldGUsIGVxdWFsKVxuICAgICAgICAgICAgY29uc3QgdGV4dCA9IGRpZmZzW2luZGV4XVsxXTsgLy8gVGV4dCBvZiBjaGFuZ2UuXG4gICAgICAgICAgICBzd2l0Y2ggKG9wKSB7XG4gICAgICAgICAgICAgICAgY2FzZSBEaWZmT3BlcmF0aW9uLkRJRkZfSU5TRVJUOlxuICAgICAgICAgICAgICAgICAgICBodG1sW2luZGV4XSA9ICc8aW5zIGNsYXNzPVwiYmctc3VjY2Vzc1wiIFwiPicgKyB0ZXh0ICsgJzwvaW5zPic7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgRGlmZk9wZXJhdGlvbi5ESUZGX0RFTEVURTpcbiAgICAgICAgICAgICAgICAgICAgaHRtbFtpbmRleF0gPSAnPGRlbCBjbGFzcz1cImJnLWRhbmdlclwiPicgKyB0ZXh0ICsgJzwvZGVsPic7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgRGlmZk9wZXJhdGlvbi5ESUZGX0VRVUFMOlxuICAgICAgICAgICAgICAgICAgICBodG1sW2luZGV4XSA9IHRleHQ7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIGh0bWwuam9pbignJyk7XG4gICAgfVxufVxuIiwiPGJ1dHRvbiBpZD1cImhpZ2hsaWdodERpZmZCdXR0b25cIiBjbGFzcz1cImJ0biBweS0wIHB4LTIgbXQtMCBtYi0wIG1zLTJcIiBbaGlkZGVuXT1cInByZXZpb3VzUHJvYmxlbVN0YXRlbWVudFVwZGF0ZSA9PT0gdW5kZWZpbmVkXCIgKGNsaWNrKT1cInRvZ2dsZUhpZ2hsaWdodGVkUHJvYmxlbVN0YXRlbWVudCgpXCI+XG4gICAge3tcbiAgICAgICAgc2hvd0hpZ2hsaWdodGVkRGlmZmVyZW5jZXMgPyAoJ2FydGVtaXNBcHAuZXhhbS5wcm9ibGVtU3RhdGVtZW50VXBkYXRlLnNob3dOZXcnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSkgOiAoJ2FydGVtaXNBcHAuZXhhbS5wcm9ibGVtU3RhdGVtZW50VXBkYXRlLnNob3dEaWZmJyB8IGFydGVtaXNUcmFuc2xhdGUpXG4gICAgfX1cbjwvYnV0dG9uPlxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRDb21tb25Nb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC1jb21tb24ubW9kdWxlJztcbmltcG9ydCB7IEV4YW1FeGVyY2lzZVVwZGF0ZUhpZ2hsaWdodGVyQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4YW0vcGFydGljaXBhdGUvZXhlcmNpc2VzL2V4YW0tZXhlcmNpc2UtdXBkYXRlLWhpZ2hsaWdodGVyL2V4YW0tZXhlcmNpc2UtdXBkYXRlLWhpZ2hsaWdodGVyLmNvbXBvbmVudCc7XG5cbkBOZ01vZHVsZSh7XG4gICAgZGVjbGFyYXRpb25zOiBbRXhhbUV4ZXJjaXNlVXBkYXRlSGlnaGxpZ2h0ZXJDb21wb25lbnRdLFxuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkQ29tbW9uTW9kdWxlXSxcbiAgICBleHBvcnRzOiBbRXhhbUV4ZXJjaXNlVXBkYXRlSGlnaGxpZ2h0ZXJDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBFeGFtRXhlcmNpc2VVcGRhdGVIaWdobGlnaHRlck1vZHVsZSB7fVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXRlc3QtY2FzZS5tb2RlbCc7XG5pbXBvcnQgeyBSZXN1bHQgfSBmcm9tICdhcHAvZW50aXRpZXMvcmVzdWx0Lm1vZGVsJztcbmltcG9ydCB7IGlzTGVnYWN5UmVzdWx0IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvdXRpbHMvcHJvZ3JhbW1pbmctZXhlcmNpc2UudXRpbHMnO1xuXG4vKipcbiAqIEVudW1lcmF0aW9uIGRlZmluaW5nIHN0YXRlIG9mIHRoZSB0ZXN0IGNhc2UuXG4gKi9cbmV4cG9ydCBlbnVtIFRlc3RDYXNlU3RhdGUge1xuICAgIE5PVF9FWEVDVVRFRCA9ICdOT1RfRVhFQ1VURUQnLFxuICAgIFNVQ0NFU1MgPSAnU1VDQ0VTUycsXG4gICAgRkFJTCA9ICdGQUlMJyxcbiAgICBOT19SRVNVTFQgPSAnTk9fUkVTVUxUJyxcbn1cblxuZXhwb3J0IHR5cGUgVGFza1Jlc3VsdCA9IHtcbiAgICB0ZXN0Q2FzZVN0YXRlOiBUZXN0Q2FzZVN0YXRlO1xuICAgIGRldGFpbGVkOiB7XG4gICAgICAgIHN1Y2Nlc3NmdWxUZXN0czogbnVtYmVyW107XG4gICAgICAgIGZhaWxlZFRlc3RzOiBudW1iZXJbXTtcbiAgICAgICAgbm90RXhlY3V0ZWRUZXN0czogbnVtYmVyW107XG4gICAgfTtcbn07XG5cbmNvbnN0IHRlc3RJZFJlZ2V4ID0gLzx0ZXN0aWQ+KFxcZCspPFxcL3Rlc3RpZD4vO1xuY29uc3QgdGVzdFNwbGl0UmVnZXggPSAvLCg/IVteKF0qP1xcKSkvO1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIFByb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdGlvblNlcnZpY2Uge1xuICAgIC8qKlxuICAgICAqIEBmdW5jdGlvbiB0ZXN0U3RhdHVzRm9yVGFza1xuICAgICAqIEBkZXNjIENhbGxiYWNrIGZ1bmN0aW9uIGZvciByZW5kZXJlcnMgdG8gc2V0IHRoZSBhcHByb3ByaWF0ZSB0ZXN0IHN0YXR1cy5cbiAgICAgKiBAcGFyYW0gdGVzdElkcyBhbGwgdGVzdCBjYXNlIGlkcyB0aGF0IGFyZSBpbmNsdWRlZCBpbnRvIHRoZSB0YXNrLlxuICAgICAqIEBwYXJhbSBsYXRlc3RSZXN1bHQgdGhlIHJlc3VsdCB0byBjaGVjayBmb3IgaWYgdGhlIHRlc3RzIHdlcmUgc3VjY2Vzc2Z1bC5cbiAgICAgKi9cbiAgICBwdWJsaWMgdGVzdFN0YXR1c0ZvclRhc2sgPSAodGVzdElkczogbnVtYmVyW10sIGxhdGVzdFJlc3VsdD86IFJlc3VsdCk6IFRhc2tSZXN1bHQgPT4ge1xuICAgICAgICBpZiAobGF0ZXN0UmVzdWx0Py5zdWNjZXNzZnVsICYmICghbGF0ZXN0UmVzdWx0LmZlZWRiYWNrcyB8fCAhbGF0ZXN0UmVzdWx0LmZlZWRiYWNrcy5sZW5ndGgpICYmIHRlc3RJZHMpIHtcbiAgICAgICAgICAgIC8vIENhc2UgMTogU3VibWlzc2lvbiBmdWxmaWxscyBhbGwgdGVzdCBjYXNlcyBhbmQgdGhlcmUgYXJlIG5vIGZlZWRiYWNrcyAobGVnYWN5IGNhc2UpLCBubyBmdXJ0aGVyIGNoZWNraW5nIG5lZWRlZC5cbiAgICAgICAgICAgIHJldHVybiB7IHRlc3RDYXNlU3RhdGU6IFRlc3RDYXNlU3RhdGUuU1VDQ0VTUywgZGV0YWlsZWQ6IHsgc3VjY2Vzc2Z1bFRlc3RzOiB0ZXN0SWRzLCBmYWlsZWRUZXN0czogW10sIG5vdEV4ZWN1dGVkVGVzdHM6IFtdIH0gfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChsYXRlc3RSZXN1bHQ/LmZlZWRiYWNrcz8ubGVuZ3RoKSB7XG4gICAgICAgICAgICAvLyBDYXNlIDI6IEF0IGxlYXN0IG9uZSB0ZXN0IGNhc2UgaXMgbm90IHN1Y2Nlc3NmdWwsIHRlc3RzIG5lZWQgdG8gY2hlY2tlZCB0byBmaW5kIG91dCBpZiB0aGV5IHdlcmUgbm90IGZ1bGZpbGxlZFxuICAgICAgICAgICAgY29uc3QgeyBmYWlsZWQsIG5vdEV4ZWN1dGVkLCBzdWNjZXNzZnVsIH0gPSB0aGlzLnNlcGFyYXRlVGVzdHModGVzdElkcywgbGF0ZXN0UmVzdWx0KTtcblxuICAgICAgICAgICAgbGV0IHRlc3RDYXNlU3RhdGU7XG4gICAgICAgICAgICBpZiAoZmFpbGVkLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICB0ZXN0Q2FzZVN0YXRlID0gVGVzdENhc2VTdGF0ZS5GQUlMO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChub3RFeGVjdXRlZC5sZW5ndGggPiAwIHx8IHRlc3RJZHMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgdGVzdENhc2VTdGF0ZSA9IFRlc3RDYXNlU3RhdGUuTk9UX0VYRUNVVEVEO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0ZXN0Q2FzZVN0YXRlID0gVGVzdENhc2VTdGF0ZS5TVUNDRVNTO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHsgdGVzdENhc2VTdGF0ZSwgZGV0YWlsZWQ6IHsgc3VjY2Vzc2Z1bFRlc3RzOiBzdWNjZXNzZnVsLCBmYWlsZWRUZXN0czogZmFpbGVkLCBub3RFeGVjdXRlZFRlc3RzOiBub3RFeGVjdXRlZCB9IH07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBDYXNlIDM6IFRoZXJlIGFyZSBubyByZXN1bHRzXG4gICAgICAgICAgICByZXR1cm4geyB0ZXN0Q2FzZVN0YXRlOiBUZXN0Q2FzZVN0YXRlLk5PX1JFU1VMVCwgZGV0YWlsZWQ6IHsgc3VjY2Vzc2Z1bFRlc3RzOiBbXSwgZmFpbGVkVGVzdHM6IFtdLCBub3RFeGVjdXRlZFRlc3RzOiB0ZXN0SWRzIH0gfTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBwcml2YXRlIHNlcGFyYXRlVGVzdHModGVzdHM6IG51bWJlcltdLCBsYXRlc3RSZXN1bHQ6IFJlc3VsdCkge1xuICAgICAgICByZXR1cm4gdGVzdHMucmVkdWNlKFxuICAgICAgICAgICAgKGFjYywgdGVzdElkKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmVlZGJhY2sgPSBsYXRlc3RSZXN1bHQ/LmZlZWRiYWNrcz8uZmluZCgoZmVlZGJhY2spID0+IGZlZWRiYWNrLnRlc3RDYXNlPy5pZCA9PT0gdGVzdElkKTtcbiAgICAgICAgICAgICAgICBjb25zdCByZXN1bHRJc0xlZ2FjeSA9IGlzTGVnYWN5UmVzdWx0KGxhdGVzdFJlc3VsdCEpO1xuXG4gICAgICAgICAgICAgICAgLy8gSWYgdGhlcmUgaXMgbm8gZmVlZGJhY2sgaXRlbSwgd2UgYXNzdW1lIHRoYXQgdGhlIHRlc3Qgd2FzIHN1Y2Nlc3NmdWwgKGxlZ2FjeSBjaGVjaykuXG4gICAgICAgICAgICAgICAgaWYgKHJlc3VsdElzTGVnYWN5KSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmYWlsZWQ6IGZlZWRiYWNrID8gWy4uLmFjYy5mYWlsZWQsIHRlc3RJZF0gOiBhY2MuZmFpbGVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgc3VjY2Vzc2Z1bDogZmVlZGJhY2sgPyBhY2Muc3VjY2Vzc2Z1bCA6IFsuLi5hY2Muc3VjY2Vzc2Z1bCwgdGVzdElkXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vdEV4ZWN1dGVkOiBhY2Mubm90RXhlY3V0ZWQsXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgZmFpbGVkOiBmZWVkYmFjaz8ucG9zaXRpdmUgPT09IGZhbHNlID8gWy4uLmFjYy5mYWlsZWQsIHRlc3RJZF0gOiBhY2MuZmFpbGVkLFxuICAgICAgICAgICAgICAgICAgICBzdWNjZXNzZnVsOiBmZWVkYmFjaz8ucG9zaXRpdmUgPT09IHRydWUgPyBbLi4uYWNjLnN1Y2Nlc3NmdWwsIHRlc3RJZF0gOiBhY2Muc3VjY2Vzc2Z1bCxcbiAgICAgICAgICAgICAgICAgICAgbm90RXhlY3V0ZWQ6IGZlZWRiYWNrPy5wb3NpdGl2ZSA9PT0gdW5kZWZpbmVkID8gWy4uLmFjYy5ub3RFeGVjdXRlZCwgdGVzdElkXSA6IGFjYy5ub3RFeGVjdXRlZCxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHsgZmFpbGVkOiBbXSwgc3VjY2Vzc2Z1bDogW10sIG5vdEV4ZWN1dGVkOiBbXSB9LFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHB1YmxpYyBjb252ZXJ0VGVzdExpc3RUb0lkcyh0ZXN0TGlzdDogc3RyaW5nLCB0ZXN0Q2FzZXM6IFByb2dyYW1taW5nRXhlcmNpc2VUZXN0Q2FzZVtdIHwgdW5kZWZpbmVkKTogbnVtYmVyW10ge1xuICAgICAgICAvLyBJZiB0aGVyZSBhcmUgdGVzdCBuYW1lcywgZS5nLiwgZHVyaW5nIHRoZSBtYXJrZG93biBwcmV2aWV3LCBtYXAgdGhlIHRlc3QgdG8gaXRzIGNvcnJlc3BvbmRpbmcgaWQgdXNpbmcgdGhlIGdpdmVuIHRlc3RDYXNlcyBhcnJheS5cbiAgICAgICAgLy8gT3RoZXJ3aXNlLCB1c2UgdGhlIGlkIGRpcmVjdGx5IHByb3ZpZGVkIHdpdGhpbiB0aGUgPHRlc3RpZD4gc2VjdGlvbi5cbiAgICAgICAgLy8gc3BsaXQgdGhlIHRlc3RzIGJ5IFwiLFwiIG9ubHkgd2hlbiB0aGVyZSBpcyBub3QgYSBjbG9zaW5nIGJyYWNrZXQgd2l0aG91dCBhIHByZXZpb3VzIG9wZW5pbmcgYnJhY2tldFxuICAgICAgICByZXR1cm4gdGVzdExpc3RcbiAgICAgICAgICAgIC5zcGxpdCh0ZXN0U3BsaXRSZWdleClcbiAgICAgICAgICAgIC5tYXAoKHRleHQpID0+IHRleHQudHJpbSgpKVxuICAgICAgICAgICAgLm1hcCgodGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIC8vIC0xIHRvIGluZGljYXRlIGEgbm90IGZvdW5kIHRlc3RcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5jb252ZXJ0UHJvYmxlbVN0YXRlbWVudFRleHRUb1Rlc3RJZCh0ZXh0LCB0ZXN0Q2FzZXMpID8/IC0xO1xuICAgICAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcHVibGljIGNvbnZlcnRQcm9ibGVtU3RhdGVtZW50VGV4dFRvVGVzdElkKHRlc3Q6IHN0cmluZywgdGVzdENhc2VzPzogUHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlW10pOiBudW1iZXIgfCB1bmRlZmluZWQge1xuICAgICAgICAvLyBJZiB0aGUgdGV4dCBjb250YWlucyA8dGVzdGlkPiBhbmQgPC90ZXN0aWQ+LCBkaXJlY3RseSB1c2UgdGhlIG51bWJlciBpbnNpZGVcbiAgICAgICAgY29uc3QgbWF0Y2ggPSB0ZXN0SWRSZWdleC5leGVjKHRlc3QpO1xuICAgICAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgICAgIC8vIElmIHRoZXJlIGFscmVhZHkgaXMgYW4gaWQsIHJldHVybiBpdCBkaXJlY3RseVxuICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KG1hdGNoWzFdKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBvdGhlcndpc2UgZmluZCBpdHMgY29ycmVzcG9uZGluZyBpZCBieSB0aGUgdGVzdCBjYXNlIG5hbWVcbiAgICAgICAgcmV0dXJuIHRlc3RDYXNlcz8uZmluZCgodGVzdENhc2UpID0+IHRlc3RDYXNlLnRlc3ROYW1lID09PSB0ZXN0KT8uaWQ7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZmFDaGVja0NpcmNsZSwgZmFUaW1lc0NpcmNsZSB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXJlZ3VsYXItc3ZnLWljb25zJztcbmltcG9ydCB7IGZhUXVlc3Rpb25DaXJjbGUgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgTmdiTW9kYWwgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgeyBFeGVyY2lzZSwgRXhlcmNpc2VUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IFJlc3VsdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9yZXN1bHQubW9kZWwnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0aW9uU2VydmljZSwgVGVzdENhc2VTdGF0ZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvc2VydmljZS9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbi5zZXJ2aWNlJztcbmltcG9ydCB7IEZlZWRiYWNrQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZmVlZGJhY2svZmVlZGJhY2suY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rpb25zLXRhc2stc3RhdHVzJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rpb24tdGFzay1zdGF0dXMuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9uLXRhc2stc3RhdHVzLnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0aW9uVGFza1N0YXR1c0NvbXBvbmVudCB7XG4gICAgVGVzdENhc2VTdGF0ZSA9IFRlc3RDYXNlU3RhdGU7XG4gICAgdHJhbnNsYXRpb25CYXNlUGF0aCA9ICdhcnRlbWlzQXBwLmVkaXRvci50ZXN0U3RhdHVzTGFiZWxzLic7XG5cbiAgICBASW5wdXQoKSB0YXNrTmFtZTogc3RyaW5nO1xuXG4gICAgLyoqXG4gICAgICogYXJyYXkgb2YgdGVzdCBpZHNcbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIGdldCB0ZXN0SWRzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy50ZXN0SWRzVmFsdWU7XG4gICAgfVxuICAgIEBJbnB1dCgpIGV4ZXJjaXNlOiBFeGVyY2lzZTtcbiAgICBASW5wdXQoKSBsYXRlc3RSZXN1bHQ/OiBSZXN1bHQ7XG5cbiAgICB0ZXN0SWRzVmFsdWU6IG51bWJlcltdO1xuICAgIHRlc3RDYXNlU3RhdGU6IFRlc3RDYXNlU3RhdGU7XG5cbiAgICAvKipcbiAgICAgKiBBcnJheXMgb2YgdGVzdCBjYXNlIGlkcywgZ3JvdXBlZCBieSB0aGVpciBzdGF0dXMgaW4gdGhlIGdpdmVuIHJlc3VsdC5cbiAgICAgKi9cbiAgICBzdWNjZXNzZnVsVGVzdHM6IG51bWJlcltdO1xuICAgIG5vdEV4ZWN1dGVkVGVzdHM6IG51bWJlcltdO1xuICAgIGZhaWxlZFRlc3RzOiBudW1iZXJbXTtcblxuICAgIGhhc01lc3NhZ2U6IGJvb2xlYW47XG5cbiAgICAvLyBJY29uc1xuICAgIGZhUXVlc3Rpb25DaXJjbGUgPSBmYVF1ZXN0aW9uQ2lyY2xlO1xuICAgIGZhckNoZWNrQ2lyY2xlID0gZmFDaGVja0NpcmNsZTtcbiAgICBmYXJUaW1lc0NpcmNsZSA9IGZhVGltZXNDaXJjbGU7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBwcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3Rpb25TZXJ2aWNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3Rpb25TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIG1vZGFsU2VydmljZTogTmdiTW9kYWwsXG4gICAgKSB7fVxuXG4gICAgc2V0IHRlc3RJZHModGVzdElkczogbnVtYmVyW10pIHtcbiAgICAgICAgdGhpcy50ZXN0SWRzVmFsdWUgPSB0ZXN0SWRzO1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgICB0ZXN0Q2FzZVN0YXRlLFxuICAgICAgICAgICAgZGV0YWlsZWQ6IHsgc3VjY2Vzc2Z1bFRlc3RzLCBub3RFeGVjdXRlZFRlc3RzLCBmYWlsZWRUZXN0cyB9LFxuICAgICAgICB9ID0gdGhpcy5wcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3Rpb25TZXJ2aWNlLnRlc3RTdGF0dXNGb3JUYXNrKHRoaXMudGVzdElkcywgdGhpcy5sYXRlc3RSZXN1bHQpO1xuICAgICAgICB0aGlzLnRlc3RDYXNlU3RhdGUgPSB0ZXN0Q2FzZVN0YXRlO1xuICAgICAgICB0aGlzLnN1Y2Nlc3NmdWxUZXN0cyA9IHN1Y2Nlc3NmdWxUZXN0cztcbiAgICAgICAgdGhpcy5ub3RFeGVjdXRlZFRlc3RzID0gbm90RXhlY3V0ZWRUZXN0cztcbiAgICAgICAgdGhpcy5mYWlsZWRUZXN0cyA9IGZhaWxlZFRlc3RzO1xuICAgICAgICB0aGlzLmhhc01lc3NhZ2UgPSB0aGlzLmhhc1Rlc3RNZXNzYWdlKHRlc3RJZHMpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENoZWNrcyBpZiBhbnkgb2YgdGhlIGZlZWRiYWNrcyBoYXZlIGEgZGV0YWlsVGV4dCBhc3NvY2lhdGVkIHRvIHRoZW0uXG4gICAgICogQHBhcmFtIHRlc3RJZHMgdGhlIHRlc3QgY2FzZSBpZHMgdGhhdCBzaG91bGQgYmUgY2hlY2tlZCBmb3JcbiAgICAgKi9cbiAgICBwcml2YXRlIGhhc1Rlc3RNZXNzYWdlKHRlc3RJZHM6IG51bWJlcltdKTogYm9vbGVhbiB7XG4gICAgICAgIGlmICghdGhpcy5sYXRlc3RSZXN1bHQ/LmZlZWRiYWNrcykge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZlZWRiYWNrcyA9IHRoaXMubGF0ZXN0UmVzdWx0LmZlZWRiYWNrcztcbiAgICAgICAgcmV0dXJuIHRlc3RJZHMuc29tZSgodGVzdElkOiBudW1iZXIpID0+IGZlZWRiYWNrcy5maW5kKChmZWVkYmFjaykgPT4gZmVlZGJhY2sudGVzdENhc2U/LmlkID09PSB0ZXN0SWQgJiYgZmVlZGJhY2suZGV0YWlsVGV4dCkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE9wZW5zIHRoZSBGZWVkYmFja0NvbXBvbmVudCBhcyBwb3B1cC4gRGlzcGxheXMgdGVzdCByZXN1bHRzLlxuICAgICAqL1xuICAgIHB1YmxpYyBzaG93RGV0YWlsc0ZvclRlc3RzKCkge1xuICAgICAgICBpZiAoIXRoaXMubGF0ZXN0UmVzdWx0KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbW9kYWxSZWYgPSB0aGlzLm1vZGFsU2VydmljZS5vcGVuKEZlZWRiYWNrQ29tcG9uZW50LCB7IGtleWJvYXJkOiB0cnVlLCBzaXplOiAnbGcnIH0pO1xuICAgICAgICBjb25zdCBjb21wb25lbnRJbnN0YW5jZSA9IG1vZGFsUmVmLmNvbXBvbmVudEluc3RhbmNlIGFzIEZlZWRiYWNrQ29tcG9uZW50O1xuICAgICAgICBjb21wb25lbnRJbnN0YW5jZS5leGVyY2lzZSA9IHRoaXMuZXhlcmNpc2U7XG4gICAgICAgIGNvbXBvbmVudEluc3RhbmNlLnJlc3VsdCA9IHRoaXMubGF0ZXN0UmVzdWx0O1xuICAgICAgICBjb21wb25lbnRJbnN0YW5jZS5mZWVkYmFja0ZpbHRlciA9IHRoaXMudGVzdElkcztcbiAgICAgICAgY29tcG9uZW50SW5zdGFuY2UuZXhlcmNpc2VUeXBlID0gRXhlcmNpc2VUeXBlLlBST0dSQU1NSU5HO1xuICAgICAgICBjb21wb25lbnRJbnN0YW5jZS50YXNrTmFtZSA9IHRoaXMudGFza05hbWU7XG4gICAgICAgIGNvbXBvbmVudEluc3RhbmNlLm51bWJlck9mTm90RXhlY3V0ZWRUZXN0cyA9IHRoaXMubm90RXhlY3V0ZWRUZXN0cy5sZW5ndGg7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cImd1aWRlZC10b3VyXCIgW2NsYXNzLnN1Y2Nlc3NdPVwidGVzdENhc2VTdGF0ZSA9PT0gVGVzdENhc2VTdGF0ZS5TVUNDRVNTXCIgW2NsYXNzLmZhaWxlZF09XCJ0ZXN0Q2FzZVN0YXRlID09PSBUZXN0Q2FzZVN0YXRlLkZBSUxcIj5cbiAgICBAaWYgKHRlc3RDYXNlU3RhdGUgPT09IFRlc3RDYXNlU3RhdGUuU1VDQ0VTUykge1xuICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYXJDaGVja0NpcmNsZVwiIHNpemU9XCJsZ1wiIGNsYXNzPVwidGVzdC1pY29uIHRleHQtc3VjY2Vzc1wiPjwvZmEtaWNvbj5cbiAgICB9XG4gICAgQGlmICh0ZXN0Q2FzZVN0YXRlID09PSBUZXN0Q2FzZVN0YXRlLkZBSUwpIHtcbiAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFyVGltZXNDaXJjbGVcIiBzaXplPVwibGdcIiBjbGFzcz1cInRlc3QtaWNvbiB0ZXh0LWRhbmdlclwiPjwvZmEtaWNvbj5cbiAgICB9XG4gICAgQGlmICh0ZXN0Q2FzZVN0YXRlID09PSBUZXN0Q2FzZVN0YXRlLk5PX1JFU1VMVCB8fCB0ZXN0Q2FzZVN0YXRlID09PSBUZXN0Q2FzZVN0YXRlLk5PVF9FWEVDVVRFRCkge1xuICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVF1ZXN0aW9uQ2lyY2xlXCIgc2l6ZT1cImxnXCIgY2xhc3M9XCJ0ZXN0LWljb24gdGV4dC1zZWNvbmRhcnlcIj48L2ZhLWljb24+XG4gICAgfVxuICAgIEBpZiAodGFza05hbWUpIHtcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJ0YXNrLW5hbWVcIj57eyB0YXNrTmFtZSB9fTwvc3Bhbj5cbiAgICB9XG4gICAgQGlmIChsYXRlc3RSZXN1bHQgJiYgbGF0ZXN0UmVzdWx0LmZlZWRiYWNrcyAmJiBsYXRlc3RSZXN1bHQuZmVlZGJhY2tzLmxlbmd0aCAmJiB0ZXN0SWRzLmxlbmd0aCkge1xuICAgICAgICA8c3BhblxuICAgICAgICAgICAgY2xhc3M9XCJndWlkZWQtdG91ciB0ZXN0LXN0YXR1cy0tbGlua2VkXCJcbiAgICAgICAgICAgIFtjbGFzc109XCJ0ZXN0SWRzPy5sZW5ndGggPT09IHN1Y2Nlc3NmdWxUZXN0cy5sZW5ndGggPyAndGV4dC1zdWNjZXNzJyA6IGZhaWxlZFRlc3RzLmxlbmd0aCA/ICd0ZXh0LWRhbmdlcicgOiAndGV4dC1zZWNvbmRhcnknXCJcbiAgICAgICAgICAgIFtpbm5lckhUTUxdPVwidHJhbnNsYXRpb25CYXNlUGF0aCArICd0b3RhbFRlc3RzUGFzc2luZycgfCBhcnRlbWlzVHJhbnNsYXRlOiB7IHRvdGFsVGVzdHM6IHRlc3RJZHMubGVuZ3RoLCBwYXNzZWRUZXN0czogc3VjY2Vzc2Z1bFRlc3RzLmxlbmd0aCB9XCJcbiAgICAgICAgICAgIChjbGljayk9XCJzaG93RGV0YWlsc0ZvclRlc3RzKClcIlxuICAgICAgICA+PC9zcGFuPlxuICAgIH0gQGVsc2Uge1xuICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtc2Vjb25kYXJ5XCIgW2lubmVySFRNTF09XCJ0cmFuc2xhdGlvbkJhc2VQYXRoICsgKHRlc3RJZHMubGVuZ3RoID8gJ25vUmVzdWx0JyA6ICdub1Rlc3RzJykgfCBhcnRlbWlzVHJhbnNsYXRlXCI+PC9zcGFuPlxuICAgIH1cbiAgICA8IS0tIFRoZXJlIGFyZSBubyByZXN1bHRzIGF0IGFsbCwgYnVpbGQgZXJyb3Igb3IgbmV2ZXIgZXhlY3V0ZWQuLS0+XG48L2Rpdj5cbiIsImltcG9ydCB7IEVtYmVkZGVkVmlld1JlZiwgSW5qZWN0YWJsZSwgSW5qZWN0b3IsIFZpZXdDb250YWluZXJSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEV4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2VUZXN0Q2FzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9wcm9ncmFtbWluZy1leGVyY2lzZS10ZXN0LWNhc2UubW9kZWwnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9wcm9ncmFtbWluZy1leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBSZXN1bHQgfSBmcm9tICdhcHAvZW50aXRpZXMvcmVzdWx0Lm1vZGVsJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdGlvblNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9pbnN0cnVjdGlvbnMtcmVuZGVyL3NlcnZpY2UvcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rpb24uc2VydmljZSc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3Rpb25UYXNrU3RhdHVzQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvaW5zdHJ1Y3Rpb25zLXJlbmRlci90YXNrL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9uLXRhc2stc3RhdHVzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBUYXNrQXJyYXksIFRhc2tBcnJheVdpdGhFeGVyY2lzZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvdGFzay9wcm9ncmFtbWluZy1leGVyY2lzZS10YXNrLm1vZGVsJztcbmltcG9ydCB7IEFydGVtaXNTaG93ZG93bkV4dGVuc2lvbldyYXBwZXIgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9leHRlbnNpb25zL2FydGVtaXMtc2hvd2Rvd24tZXh0ZW5zaW9uLXdyYXBwZXInO1xuaW1wb3J0IHsgZXNjYXBlU3RyaW5nRm9yVXNlSW5SZWdleCB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC9nbG9iYWwudXRpbHMnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgU2hvd2Rvd25FeHRlbnNpb24gfSBmcm9tICdzaG93ZG93bic7XG5cbi8qKlxuICogUmVndWxhciBleHByZXNzaW9uIGZvciBmaW5kaW5nIHRhc2tzLlxuICogQSBUYXNrIHN0YXJ0cyB3aXRoIHRoZSBpZGVudGlmaWVyIGBbdGFza11gIGFuZCB0aGUgdGFzayBuYW1lIGluIHNxdWFyZSBicmFja2V0cy5cbiAqIFRoaXMgZ2V0cyBmb2xsb3dlZCBieSBhIGxpc3Qgb2YgdGVzdCBjYXNlcyBpbiBwYXJlbnRoZXNlcy5cbiAqIEBleGFtcGxlIFt0YXNrXVtJbXBsZW1lbnQgQnViYmxlU29ydF0odGVzdEJ1YmJsZVNvcnQpXG4gKlxuICogVGhlIHJlZ3VsYXIgZXhwcmVzc2lvbiBpcyB1c2VkIHRvIGZpbmQgYWxsIHRhc2tzIGluc2lkZSBhIHByb2JsZW0gc3RhdGVtZW50IGFuZCB0aGVyZWZvcmUgdXNlcyB0aGUgZ2xvYmFsIGZsYWcuXG4gKlxuICogVGhpcyBpcyBjb3VwbGVkIHRvIHRoZSB2YWx1ZSB1c2VkIGluIGBQcm9ncmFtbWluZ0V4ZXJjaXNlVGFza1NlcnZpY2VgIGluIHRoZSBzZXJ2ZXIuXG4gKiBJZiB5b3UgY2hhbmdlIHRoZSByZWdleCwgbWFrZSBzdXJlIHRvIGNoYW5nZSBpdCBpbiBhbGwgcGxhY2VzIVxuICovXG5jb25zdCB0YXNrUmVnZXggPSAvXFxbdGFza11cXFsoW15bXFxdXSspXVxcKCgoPzpbXigpLF0rKD86XFwoW14oKV0qXFwpW14oKSxdKik/KD86LFteKCksXSsoPzpcXChbXigpXSpcXClbXigpLF0qKT8pKik/KVxcKS9nO1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIFByb2dyYW1taW5nRXhlcmNpc2VUYXNrRXh0ZW5zaW9uV3JhcHBlciBpbXBsZW1lbnRzIEFydGVtaXNTaG93ZG93bkV4dGVuc2lvbldyYXBwZXIge1xuICAgIC8vIFdlIGRvbid0IGhhdmUgYSBwcm92aWRlciBmb3IgVmlld0NvbnRhaW5lclJlZiwgc28gd2UgcGFzcyBpdCBmcm9tIFByb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdGlvbkNvbXBvbmVudFxuICAgIHZpZXdDb250YWluZXJSZWY6IFZpZXdDb250YWluZXJSZWY7XG5cbiAgICBwcml2YXRlIGxhdGVzdFJlc3VsdD86IFJlc3VsdDtcbiAgICBwcml2YXRlIGV4ZXJjaXNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlO1xuICAgIHByaXZhdGUgdGVzdENhc2VzPzogUHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlW107XG5cbiAgICBwcml2YXRlIHRlc3RzRm9yVGFza1N1YmplY3QgPSBuZXcgU3ViamVjdDxUYXNrQXJyYXlXaXRoRXhlcmNpc2U+KCk7XG4gICAgcHJpdmF0ZSBpbmplY3RhYmxlRWxlbWVudHNGb3VuZFN1YmplY3QgPSBuZXcgU3ViamVjdDwoKSA9PiB2b2lkPigpO1xuXG4gICAgLy8gdW5pcXVlIGluZGV4LCBldmVuIGlmIG11bHRpcGxlIHRhc2tzIGFyZSBzaG93biBmcm9tIGRpZmZlcmVudCBwcm9ibGVtIHN0YXRlbWVudHMgb24gdGhlIHNhbWUgcGFnZSAoaW4gZGlmZmVyZW50IHRhYnMpXG4gICAgcHJpdmF0ZSB0YXNrSW5kZXggPSAwO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgcHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0aW9uU2VydmljZTogUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0aW9uU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBpbmplY3RvcjogSW5qZWN0b3IsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogU2V0cyBsYXRlc3QgcmVzdWx0IGFjY29yZGluZyB0byBwYXJhbWV0ZXIuXG4gICAgICogQHBhcmFtIHJlc3VsdCAtIGVpdGhlciBhIHJlc3VsdCBvciB1bmRlZmluZWQuXG4gICAgICovXG4gICAgcHVibGljIHNldExhdGVzdFJlc3VsdChyZXN1bHQ6IFJlc3VsdCB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLmxhdGVzdFJlc3VsdCA9IHJlc3VsdDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXRzIHRoZSBleGVyY2lzZS4gVGhpcyBpcyBuZWVkZWQgYXMgbXVsdGlwbGUgaW5zdHJ1Y3Rpb25zIGNvbXBvbmVudHMgdXNlIHRoaXMgc2VydmljZSBpbiBwYXJhbGxlbCBhbmQgd2UgaGF2ZSB0b1xuICAgICAqIGFzc29jaWF0ZSB0YXNrcyB3aXRoIGFuIGV4ZXJjaXNlIHRvIGlkZW50aWZ5IHRhc2tzIHByb3Blcmx5XG4gICAgICogQHBhcmFtIGV4ZXJjaXNlIC0gdGhlIGN1cnJlbnQgZXhlcmNpc2UuXG4gICAgICovXG4gICAgcHVibGljIHNldEV4ZXJjaXNlKGV4ZXJjaXNlOiBFeGVyY2lzZSkge1xuICAgICAgICB0aGlzLmV4ZXJjaXNlID0gZXhlcmNpc2U7XG4gICAgfVxuXG4gICAgcHVibGljIHNldFRlc3RDYXNlcyh0ZXN0Q2FzZXM/OiBQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VbXSkge1xuICAgICAgICB0aGlzLnRlc3RDYXNlcyA9IHRlc3RDYXNlcztcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTdWJzY3JpYmVzIHRvIHRlc3RzRm9yVGFza1N1YmplY3QuXG4gICAgICovXG4gICAgcHVibGljIHN1YnNjcmliZUZvckZvdW5kVGVzdHNJblRhc2tzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy50ZXN0c0ZvclRhc2tTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFN1YnNjcmliZXMgdG8gaW5qZWN0YWJsZUVsZW1lbnRzRm91bmRTdWJqZWN0LlxuICAgICAqL1xuICAgIHB1YmxpYyBzdWJzY3JpYmVGb3JJbmplY3RhYmxlRWxlbWVudHNGb3VuZCgpOiBPYnNlcnZhYmxlPCgpID0+IHZvaWQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5qZWN0YWJsZUVsZW1lbnRzRm91bmRTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEZvciBlYWNoIHRhc2sgcHJvdmlkZWQsIGluamVjdCBhIFByb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdGlvblRhc2tTdGF0dXNDb21wb25lbnQgaW50byB0aGUgY29udGFpbmVyIGRpdi5cbiAgICAgKiBAcGFyYW0gdGFza3MgdG8gaW5qZWN0IGludG8gdGhlIGh0bWwuXG4gICAgICovXG4gICAgcHJpdmF0ZSBpbmplY3RUYXNrcyA9ICh0YXNrczogVGFza0FycmF5KSA9PiB7XG4gICAgICAgIHRhc2tzLmZvckVhY2goKHsgaWQsIHRhc2tOYW1lLCB0ZXN0SWRzIH0pID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHRhc2tIdG1sQ29udGFpbmVycyA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoYHBlLXRhc2stJHtpZH1gKTtcblxuICAgICAgICAgICAgLy8gVGhlIHNhbWUgdGFzayBjb3VsZCBhcHBlYXIgbXVsdGlwbGUgdGltZXMgaW4gdGhlIGluc3RydWN0aW9ucyAoZWRnZSBjYXNlKS5cbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGFza0h0bWxDb250YWluZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgLy8gVE9ETzogUmVwbGFjZSB0aGlzIHdvcmthcm91bmQgd2l0aCBvZmZpY2lhbCBBbmd1bGFyIEFQSSByZXBsYWNlbWVudCBmb3IgQ29tcG9uZW50RmFjdG9yeVJlc29sdmVyIG9uY2UgYXZhaWxhYmxlXG4gICAgICAgICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvaXNzdWVzLzQ1MjYzI2lzc3VlY29tbWVudC0xMDgyNTMwMzU3XG4gICAgICAgICAgICAgICAgY29uc3QgY29tcG9uZW50UmVmID0gdGhpcy52aWV3Q29udGFpbmVyUmVmLmNyZWF0ZUNvbXBvbmVudChQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3Rpb25UYXNrU3RhdHVzQ29tcG9uZW50LCB7IGluamVjdG9yOiB0aGlzLmluamVjdG9yIH0pO1xuICAgICAgICAgICAgICAgIGNvbXBvbmVudFJlZi5pbnN0YW5jZS5leGVyY2lzZSA9IHRoaXMuZXhlcmNpc2U7XG4gICAgICAgICAgICAgICAgY29tcG9uZW50UmVmLmluc3RhbmNlLnRhc2tOYW1lID0gdGFza05hbWU7XG4gICAgICAgICAgICAgICAgY29tcG9uZW50UmVmLmluc3RhbmNlLmxhdGVzdFJlc3VsdCA9IHRoaXMubGF0ZXN0UmVzdWx0O1xuICAgICAgICAgICAgICAgIGNvbXBvbmVudFJlZi5pbnN0YW5jZS50ZXN0SWRzID0gdGVzdElkcztcbiAgICAgICAgICAgICAgICAvLyB3YWl0IGZvciBpbml0IGFuZCByZW5kZXIgdG8gY29tcGxldGVcbiAgICAgICAgICAgICAgICBjb21wb25lbnRSZWYuY2hhbmdlRGV0ZWN0b3JSZWYuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGRvbUVsZW0gPSAoY29tcG9uZW50UmVmLmhvc3RWaWV3IGFzIEVtYmVkZGVkVmlld1JlZjxhbnk+KS5yb290Tm9kZXNbMF0gYXMgSFRNTEVsZW1lbnQ7XG4gICAgICAgICAgICAgICAgY29uc3QgdGFza0h0bWxDb250YWluZXIgPSB0YXNrSHRtbENvbnRhaW5lcnNbaV07XG4gICAgICAgICAgICAgICAgdGFza0h0bWxDb250YWluZXIucmVwbGFjZUNoaWxkcmVuKGRvbUVsZW0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhbmQgcmV0dXJucyBhbiBleHRlbnNpb24gdG8gY3VycmVudCBleGVyY2lzZS5cbiAgICAgKiBUaGUgdGFzayByZWdleCBpcyBjb3VwbGVkIHRvIHRoZSB2YWx1ZSB1c2VkIGluIFByb2dyYW1taW5nRXhlcmNpc2VUYXNrU2VydmljZSBpbiB0aGUgc2VydmVyIGFuZFxuICAgICAqIGBUYXNrQ29tbWFuZGAgaW4gdGhlIGNsaWVudFxuICAgICAqIElmIHlvdSBjaGFuZ2UgdGhlIHJlZ2V4LCBtYWtlIHN1cmUgdG8gY2hhbmdlIGl0IGluIGFsbCBwbGFjZXMhXG4gICAgICovXG4gICAgZ2V0RXh0ZW5zaW9uKCkge1xuICAgICAgICBjb25zdCBleHRlbnNpb246IFNob3dkb3duRXh0ZW5zaW9uID0ge1xuICAgICAgICAgICAgdHlwZTogJ2xhbmcnLFxuICAgICAgICAgICAgZmlsdGVyOiAocHJvYmxlbVN0YXRlbWVudDogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdGFza3MgPSBBcnJheS5mcm9tKHByb2JsZW1TdGF0ZW1lbnQubWF0Y2hBbGwodGFza1JlZ2V4KSk7XG4gICAgICAgICAgICAgICAgaWYgKHRhc2tzKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNyZWF0ZVRhc2tzKHByb2JsZW1TdGF0ZW1lbnQsIHRhc2tzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHByb2JsZW1TdGF0ZW1lbnQ7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgICAgICByZXR1cm4gZXh0ZW5zaW9uO1xuICAgIH1cblxuICAgIHByaXZhdGUgY3JlYXRlVGFza3MocHJvYmxlbVN0YXRlbWVudDogc3RyaW5nLCB0YXNrczogUmVnRXhwTWF0Y2hBcnJheVtdKTogc3RyaW5nIHtcbiAgICAgICAgY29uc3QgdGVzdHNGb3JUYXNrOiBUYXNrQXJyYXkgPSB0YXNrc1xuICAgICAgICAgICAgLy8gY2hlY2sgdGhhdCBhbGwgZ3JvdXBzIChmdWxsIG1hdGNoLCBuYW1lLCB0ZXN0cykgYXJlIHByZXNlbnRcbiAgICAgICAgICAgIC5maWx0ZXIoKHRlc3RNYXRjaCkgPT4gdGVzdE1hdGNoPy5sZW5ndGggPT09IDMpXG4gICAgICAgICAgICAubWFwKCh0ZXN0TWF0Y2g6IFJlZ0V4cE1hdGNoQXJyYXkgfCBudWxsKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgbmV4dEluZGV4ID0gdGhpcy50YXNrSW5kZXg7XG4gICAgICAgICAgICAgICAgdGhpcy50YXNrSW5kZXgrKztcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICBpZDogbmV4dEluZGV4LFxuICAgICAgICAgICAgICAgICAgICBjb21wbGV0ZVN0cmluZzogdGVzdE1hdGNoIVswXSxcbiAgICAgICAgICAgICAgICAgICAgdGFza05hbWU6IHRlc3RNYXRjaCFbMV0sXG4gICAgICAgICAgICAgICAgICAgIHRlc3RJZHM6IHRlc3RNYXRjaCFbMl0gPyB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdGlvblNlcnZpY2UuY29udmVydFRlc3RMaXN0VG9JZHModGVzdE1hdGNoIVsyXSwgdGhpcy50ZXN0Q2FzZXMpIDogW10sXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICBjb25zdCB0YXNrc1dpdGhQYXJ0aWNpcGF0aW9uSWQ6IFRhc2tBcnJheVdpdGhFeGVyY2lzZSA9IHtcbiAgICAgICAgICAgIGV4ZXJjaXNlSWQ6IHRoaXMuZXhlcmNpc2UuaWQhLFxuICAgICAgICAgICAgdGFza3M6IHRlc3RzRm9yVGFzayxcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy50ZXN0c0ZvclRhc2tTdWJqZWN0Lm5leHQodGFza3NXaXRoUGFydGljaXBhdGlvbklkKTtcbiAgICAgICAgLy8gRW1pdCBuZXcgZm91bmQgZWxlbWVudHMgdGhhdCBuZWVkIHRvIGJlIGluamVjdGVkIGludG8gaHRtbCBhZnRlciBpdCBpcyByZW5kZXJlZC5cbiAgICAgICAgdGhpcy5pbmplY3RhYmxlRWxlbWVudHNGb3VuZFN1YmplY3QubmV4dCgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmluamVjdFRhc2tzKHRlc3RzRm9yVGFzayk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdGVzdHNGb3JUYXNrLnJlZHVjZShcbiAgICAgICAgICAgIChhY2M6IHN0cmluZywgeyBjb21wbGV0ZVN0cmluZzogdGFzaywgaWQgfSk6IHN0cmluZyA9PlxuICAgICAgICAgICAgICAgIC8vIEluc2VydCBhbmNob3IgZGl2cyBpbnRvIHRoZSB0ZXh0IHNvIHRoYXQgaW5qZWN0YWJsZSBlbGVtZW50cyBjYW4gYmUgaW5zZXJ0ZWQgaW50byB0aGVtLlxuICAgICAgICAgICAgICAgIC8vIFdpdGhvdXQgY2xhc3M9XCJkLWZsZXhcIiB0aGUgaW5qZWN0ZWQgY29tcG9uZW50cyBoZWlnaHQgd291bGQgYmUgMC5cbiAgICAgICAgICAgICAgICAvLyBBZGRlZCB6ZXJvLXdpZHRoIHNwYWNlIGFzIGNvbnRlbnQgc28gdGhlIGRpdiBhY3R1YWxseSBjb25zdW1lcyBhIGxpbmUgdG8gcHJldmVudCBhIDxvbD4gZGlzcGxheSBidWcgaW4gU2FmYXJpXG4gICAgICAgICAgICAgICAgYWNjLnJlcGxhY2UobmV3IFJlZ0V4cChlc2NhcGVTdHJpbmdGb3JVc2VJblJlZ2V4KHRhc2spLCAnZycpLCBgPGRpdiBjbGFzcz1cInBlLXRhc2stJHtpZC50b1N0cmluZygpfSBkLWZsZXhcIj4mIzgyMDM7PC9kaXY+YCksXG4gICAgICAgICAgICBwcm9ibGVtU3RhdGVtZW50LFxuICAgICAgICApO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBQYXJhbWV0ZXJDb2RlYywgSHR0cFBhcmFtcyB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IENhY2hlYWJsZSB9IGZyb20gJ3RzLWNhY2hlYWJsZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBtYXAsIHRhcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IFRoZW1lLCBUaGVtZVNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS90aGVtZS90aGVtZS5zZXJ2aWNlJztcblxuY29uc3QgdGhlbWVDaGFuZ2VkU3ViamVjdCA9IG5ldyBTdWJqZWN0PHZvaWQ+KCk7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgUHJvZ3JhbW1pbmdFeGVyY2lzZVBsYW50VW1sU2VydmljZSB7XG4gICAgcHJpdmF0ZSByZXNvdXJjZVVybCA9ICdhcGkvcGxhbnR1bWwnO1xuICAgIHByaXZhdGUgZW5jb2RlcjogSHR0cFBhcmFtZXRlckNvZGVjO1xuXG4gICAgLyoqXG4gICAgICogQ2FjaGVhYmxlIGNvbmZpZ3VyYXRpb25cbiAgICAgKi9cblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQsXG4gICAgICAgIHByaXZhdGUgdGhlbWVTZXJ2aWNlOiBUaGVtZVNlcnZpY2UsXG4gICAgKSB7XG4gICAgICAgIHRoaXMuZW5jb2RlciA9IG5ldyBIdHRwVXJsQ3VzdG9tRW5jb2RlcigpO1xuICAgICAgICB0aGlzLnRoZW1lU2VydmljZVxuICAgICAgICAgICAgLmdldEN1cnJlbnRUaGVtZU9ic2VydmFibGUoKVxuICAgICAgICAgICAgLnBpcGUodGFwKCgpID0+IHRoZW1lQ2hhbmdlZFN1YmplY3QubmV4dCgpKSlcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXF1ZXN0cyB0aGUgcGxhbnR1bWwgcG5nIGZpbGUgYXMgYXJyYXlidWZmZXIgYW5kIGNvbnZlcnRzIGl0IHRvIGJhc2U2NC5cbiAgICAgKiBAcGFyYW0gcGxhbnRVbWwgLSBkZWZpbml0aW9uIG9idGFpbmVkIGJ5IHBhcnNpbmcgdGhlIFJFQURNRSBtYXJrZG93biBmaWxlLlxuICAgICAqXG4gICAgICogTm90ZTogd2UgY2FjaGUgdXAgdG8gMTAwIHJlc3VsdHMgaW4gMSBob3VyIHNvIHRoYXQgdGhleSBkbyBub3QgbmVlZCB0byBiZSBsb2FkZWQgc2V2ZXJhbCB0aW1lXG4gICAgICovXG4gICAgQENhY2hlYWJsZSh7XG4gICAgICAgIC8qKiBDYWNoZWFibGUgY29uZmlndXJhdGlvbiAqKi9cbiAgICAgICAgbWF4Q2FjaGVDb3VudDogMTAwLFxuICAgICAgICBtYXhBZ2U6IDM2MDAwMDAsIC8vIG1zXG4gICAgICAgIHNsaWRpbmdFeHBpcmF0aW9uOiB0cnVlLFxuICAgICAgICBjYWNoZUJ1c3Rlck9ic2VydmVyOiB0aGVtZUNoYW5nZWRTdWJqZWN0LCAvLyBldmljdCBjYWNoZSBvbiB0aGVtZSBjaGFuZ2VcbiAgICB9KVxuICAgIGdldFBsYW50VW1sSW1hZ2UocGxhbnRVbWw6IHN0cmluZykge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAuZ2V0KGAke3RoaXMucmVzb3VyY2VVcmx9L3BuZ2AsIHtcbiAgICAgICAgICAgICAgICBwYXJhbXM6IG5ldyBIdHRwUGFyYW1zKHsgZW5jb2RlcjogdGhpcy5lbmNvZGVyIH0pLnNldCgncGxhbnR1bWwnLCBwbGFudFVtbCkuc2V0KCd1c2VEYXJrVGhlbWUnLCB0aGlzLnRoZW1lU2VydmljZS5nZXRDdXJyZW50VGhlbWUoKSA9PT0gVGhlbWUuREFSSyksXG4gICAgICAgICAgICAgICAgcmVzcG9uc2VUeXBlOiAnYXJyYXlidWZmZXInLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzKSA9PiB0aGlzLmNvbnZlcnRQbGFudFVtbFJlc3BvbnNlVG9CYXNlNjQocmVzKSkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlcXVlc3RzIHRoZSBwbGFudHVtbCBzdmcgYXMgc3RyaW5nLlxuICAgICAqIEBwYXJhbSBwbGFudFVtbCAtIGRlZmluaXRpb24gb2J0YWluZWQgYnkgcGFyc2luZyB0aGUgUkVBRE1FIG1hcmtkb3duIGZpbGUuXG4gICAgICpcbiAgICAgKiBOb3RlOiB3ZSBjYWNoZSB1cCB0byAxMDAgcmVzdWx0cyBpbiAxIGhvdXIgc28gdGhhdCB0aGV5IGRvIG5vdCBuZWVkIHRvIGJlIGxvYWRlZCBzZXZlcmFsIHRpbWVcbiAgICAgKi9cbiAgICBAQ2FjaGVhYmxlKHtcbiAgICAgICAgLyoqIENhY2hlYWJsZSBjb25maWd1cmF0aW9uICoqL1xuICAgICAgICBtYXhDYWNoZUNvdW50OiAxMDAsXG4gICAgICAgIG1heEFnZTogMzYwMDAwMCwgLy8gbXNcbiAgICAgICAgc2xpZGluZ0V4cGlyYXRpb246IHRydWUsXG4gICAgICAgIGNhY2hlQnVzdGVyT2JzZXJ2ZXI6IHRoZW1lQ2hhbmdlZFN1YmplY3QsIC8vIGV2aWN0IGNhY2hlIG9uIHRoZW1lIGNoYW5nZVxuICAgIH0pXG4gICAgZ2V0UGxhbnRVbWxTdmcocGxhbnRVbWw6IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KGAke3RoaXMucmVzb3VyY2VVcmx9L3N2Z2AsIHtcbiAgICAgICAgICAgIHBhcmFtczogbmV3IEh0dHBQYXJhbXMoeyBlbmNvZGVyOiB0aGlzLmVuY29kZXIgfSkuc2V0KCdwbGFudHVtbCcsIHBsYW50VW1sKS5zZXQoJ3VzZURhcmtUaGVtZScsIHRoaXMudGhlbWVTZXJ2aWNlLmdldEN1cnJlbnRUaGVtZSgpID09PSBUaGVtZS5EQVJLKSxcbiAgICAgICAgICAgIHJlc3BvbnNlVHlwZTogJ3RleHQnLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGNvbnZlcnRQbGFudFVtbFJlc3BvbnNlVG9CYXNlNjQocmVzOiBhbnkpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gQnVmZmVyLmZyb20ocmVzLCAnYmluYXJ5JykudG9TdHJpbmcoJ2Jhc2U2NCcpO1xuICAgIH1cbn1cblxuLyoqXG4gKiBAY2xhc3MgSHR0cFVybEN1c3RvbUVuY29kZXJcbiAqIEBkZXNjIEN1c3RvbSBIdHRwUGFyYW1FbmNvZGVyIGltcGxlbWVudGF0aW9uIHdoaWNoIGRlZmF1bHRzIHRvIHVzaW5nIGVuY29kZVVSSUNvbXBvbmVudCB0byBlbmNvZGUgcGFyYW1zXG4gKi9cbmV4cG9ydCBjbGFzcyBIdHRwVXJsQ3VzdG9tRW5jb2RlciBpbXBsZW1lbnRzIEh0dHBQYXJhbWV0ZXJDb2RlYyB7XG4gICAgLyoqXG4gICAgICogRW5jb2RlcyBrZXkuXG4gICAgICogQHBhcmFtIGsgLSBrZXkgdG8gYmUgZW5jb2RlZC5cbiAgICAgKi9cbiAgICBlbmNvZGVLZXkoazogc3RyaW5nKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudChrKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBFbmNvZGVzIHZhbHVlLlxuICAgICAqIEBwYXJhbSB2IC0gdmFsdWUgdG8gYmUgZW5jb2RlZC5cbiAgICAgKi9cbiAgICBlbmNvZGVWYWx1ZSh2OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHYpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERlY29kZXMga2V5LlxuICAgICAqIEBwYXJhbSBrIC0ga2V5IHRvIGJlIGRlY29kZWQuXG4gICAgICovXG4gICAgZGVjb2RlS2V5KGs6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiBkZWNvZGVVUklDb21wb25lbnQoayk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGVjb2RlcyB2YWx1ZS5cbiAgICAgKiBAcGFyYW0gdiAtIHZhbHVlIHRvIGJlIGRlY29kZWQuXG4gICAgICovXG4gICAgZGVjb2RlVmFsdWUodjogc3RyaW5nKSB7XG4gICAgICAgIHJldHVybiBkZWNvZGVVUklDb21wb25lbnQodik7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXRlc3QtY2FzZS5tb2RlbCc7XG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyB0YXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBlc2NhcGVTdHJpbmdGb3JVc2VJblJlZ2V4IH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2dsb2JhbC51dGlscyc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3Rpb25TZXJ2aWNlLCBUZXN0Q2FzZVN0YXRlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvaW5zdHJ1Y3Rpb25zLXJlbmRlci9zZXJ2aWNlL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZVBsYW50VW1sU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvc2VydmljZS9wcm9ncmFtbWluZy1leGVyY2lzZS1wbGFudC11bWwuc2VydmljZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hvd2Rvd25FeHRlbnNpb25XcmFwcGVyIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvZXh0ZW5zaW9ucy9hcnRlbWlzLXNob3dkb3duLWV4dGVuc2lvbi13cmFwcGVyJztcbmltcG9ydCB7IFJlc3VsdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9yZXN1bHQubW9kZWwnO1xuaW1wb3J0IHsgU2hvd2Rvd25FeHRlbnNpb24gfSBmcm9tICdzaG93ZG93bic7XG5pbXBvcnQgRE9NUHVyaWZ5IGZyb20gJ2RvbXB1cmlmeSc7XG5cbi8vIFRoaXMgcmVnZXggaXMgdGhlIHNhbWUgYXMgaW4gdGhlIHNlcnZlcjogUHJvZ3JhbW1pbmdFeGVyY2lzZVRhc2tTZXJ2aWNlLmphdmFcbmNvbnN0IHRlc3RzQ29sb3JSZWdleCA9IC90ZXN0c0NvbG9yXFwoKFxccypbXigpXFxzXSsoXFwoW14oKV0qXFwpKT8pXFwpL2c7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgUHJvZ3JhbW1pbmdFeGVyY2lzZVBsYW50VW1sRXh0ZW5zaW9uV3JhcHBlciBpbXBsZW1lbnRzIEFydGVtaXNTaG93ZG93bkV4dGVuc2lvbldyYXBwZXIge1xuICAgIHByaXZhdGUgbGF0ZXN0UmVzdWx0PzogUmVzdWx0O1xuICAgIHByaXZhdGUgdGVzdENhc2VzPzogUHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlW107XG4gICAgcHJpdmF0ZSBpbmplY3RhYmxlRWxlbWVudHNGb3VuZFN1YmplY3QgPSBuZXcgU3ViamVjdDwoKSA9PiB2b2lkPigpO1xuXG4gICAgLy8gdW5pcXVlIGluZGV4LCBldmVuIGlmIG11bHRpcGxlIHBsYW50IHVtbCBkaWFncmFtcyBhcmUgc2hvd24gZnJvbSBkaWZmZXJlbnQgcHJvYmxlbSBzdGF0ZW1lbnRzIG9uIHRoZSBzYW1lIHBhZ2UgKGluIGRpZmZlcmVudCB0YWJzKVxuICAgIHByaXZhdGUgcGxhbnRVbWxJbmRleCA9IDA7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBwcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3Rpb25TZXJ2aWNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3Rpb25TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHBsYW50VW1sU2VydmljZTogUHJvZ3JhbW1pbmdFeGVyY2lzZVBsYW50VW1sU2VydmljZSxcbiAgICApIHt9XG5cbiAgICAvKipcbiAgICAgKiBTZXRzIGxhdGVzdCByZXN1bHQgYWNjb3JkaW5nIHRvIHBhcmFtZXRlci5cbiAgICAgKiBAcGFyYW0gcmVzdWx0IC0gZWl0aGVyIGEgcmVzdWx0IG9yIHVuZGVmaW5lZC5cbiAgICAgKi9cbiAgICBwdWJsaWMgc2V0TGF0ZXN0UmVzdWx0KHJlc3VsdD86IFJlc3VsdCkge1xuICAgICAgICB0aGlzLmxhdGVzdFJlc3VsdCA9IHJlc3VsdDtcbiAgICB9XG5cbiAgICBwdWJsaWMgc2V0VGVzdENhc2VzKHRlc3RDYXNlcz86IFByb2dyYW1taW5nRXhlcmNpc2VUZXN0Q2FzZVtdKSB7XG4gICAgICAgIHRoaXMudGVzdENhc2VzID0gdGVzdENhc2VzO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFN1YnNjcmliZXMgdG8gaW5qZWN0YWJsZUVsZW1lbnRzRm91bmRTdWJqZWN0LlxuICAgICAqL1xuICAgIHN1YnNjcmliZUZvckluamVjdGFibGVFbGVtZW50c0ZvdW5kKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbmplY3RhYmxlRWxlbWVudHNGb3VuZFN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRm9yIHRoZSBzdHJpbmdpZmllZCBwbGFudFVtbCBwcm92aWRlZCwgcmVuZGVyIHRoZSBwbGFudFVtbCBvbiB0aGUgc2VydmVyIGFuZCBpbmplY3QgaXQgaW50byB0aGUgaHRtbC5cbiAgICAgKiBAcGFyYW0gcGxhbnRVbWwgYSBzdHJpbmdpZmllZCB2ZXJzaW9uIG9mIG9uZSBwbGFudFVtbC5cbiAgICAgKiBAcGFyYW0gaW5kZXggdGhlIGluZGV4IG9mIHRoZSBwbGFudFVtbCBpbiBodG1sXG4gICAgICovXG4gICAgcHJpdmF0ZSBsb2FkQW5kSW5qZWN0UGxhbnRVbWwocGxhbnRVbWw6IHN0cmluZywgaW5kZXg6IG51bWJlcikge1xuICAgICAgICB0aGlzLnBsYW50VW1sU2VydmljZVxuICAgICAgICAgICAgLmdldFBsYW50VW1sU3ZnKHBsYW50VW1sKVxuICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgdGFwKChwbGFudFVtbFN2Zzogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHBsYW50VW1sSHRtbENvbnRhaW5lciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGBwbGFudFVtbC0ke2luZGV4fWApO1xuICAgICAgICAgICAgICAgICAgICBpZiAocGxhbnRVbWxIdG1sQ29udGFpbmVyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBXZSBuZWVkIHRvIHNhbml0aXplIHRoZSByZWNlaXZlZCBzdmcgYXMgaXQgY291bGQgY29udGFpbiBtYWxpY2lvdXMgY29kZSBpbiBhIHNjcmlwdCB0YWcuXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFudFVtbEh0bWxDb250YWluZXIuaW5uZXJIVE1MID0gRE9NUHVyaWZ5LnNhbml0aXplKHBsYW50VW1sU3ZnKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYW5kIHJldHVybnMgYW4gZXh0ZW5zaW9uIHRvIGN1cnJlbnQgZXhlcmNpc2UuXG4gICAgICogVGhlIGV4dGVuc2lvbiBwcm92aWRlcyBhIGN1c3RvbSByZW5kZXJpbmcgbWVjaGFuaXNtIGZvciBlbWJlZGRlZCBwbGFudFVtbCBkaWFncmFtcy5cbiAgICAgKiBUaGUgbWVjaGFuaXNtIHdvcmtzIGFzIGZvbGxvd3M6XG4gICAgICogMSkgRmluZCAobXVsdGlwbGUpIGVtYmVkZGVkIHBsYW50VW1sIGRpYWdyYW1zIGJhc2VkIG9uIGEgcmVnZXggKHN0YXJ0dW1sLCBlbmR1bWwpLlxuICAgICAqIDIpIFJlcGxhY2UgdGhlIHdob2xlIHBsYW50VW1sIHdpdGggYSBzaW1wbGUgcGxhbnRVbWwgZGl2IGNvbnRhaW5lciBhbmQgYSB1bmlxdWUgcGxhY2Vob2xkZXIgaWRcbiAgICAgKiAzKSBBZGQgY29sb3JzIGZvciB0ZXN0IHJlc3VsdHMgaW4gdGhlIHBsYW50VW1sIChyZWQsIGdyZWVuLCBncmV5KVxuICAgICAqIDQpIFNlbmQgdGhlIHBsYW50VW1sIGNvbnRlbnQgdG8gdGhlIHNlcnZlciBmb3IgcmVuZGVyaW5nIGEgc3ZnICh0aGUgcmVzdWx0IHdpbGwgYmUgY2FjaGVkIGZvciBwZXJmb3JtYW5jZSByZWFzb25zKVxuICAgICAqIDUpIEluamVjdCB0aGUgY29tcHV0ZWQgc3ZnIGZvciB0aGUgcGxhbnRVbWwgKGZyb20gdGhlIHNlcnZlcikgaW50byB0aGUgcGxhbnRVbWwgZGl2IGNvbnRhaW5lciBiYXNlZCBvbiB0aGUgdW5pcXVlIHBsYWNlaG9sZGVyIGlkIChzZWUgc3RlcCAyKVxuICAgICAqL1xuICAgIGdldEV4dGVuc2lvbigpIHtcbiAgICAgICAgY29uc3QgZXh0ZW5zaW9uOiBTaG93ZG93bkV4dGVuc2lvbiA9IHtcbiAgICAgICAgICAgIHR5cGU6ICdsYW5nJyxcbiAgICAgICAgICAgIGZpbHRlcjogKHRleHQ6IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkUGxhY2Vob2xkZXIgPSAnJWlkUGxhY2Vob2xkZXIlJztcbiAgICAgICAgICAgICAgICAvLyBFLmcuIFt0YXNrXVtJbXBsZW1lbnQgQnViYmxlU29ydF0odGVzdEJ1YmJsZVNvcnQpXG4gICAgICAgICAgICAgICAgY29uc3QgcGxhbnRVbWxSZWdleCA9IC9Ac3RhcnR1bWwoW15AXSopQGVuZHVtbC9nO1xuICAgICAgICAgICAgICAgIC8vIEUuZy4gSW1wbGVtZW50IEJ1YmJsZVNvcnQsIHRlc3RCdWJibGVTb3J0XG4gICAgICAgICAgICAgICAgY29uc3QgcGxhbnRVbWxDb250YWluZXIgPSBgPGRpdiBjbGFzcz1cIm1iLTRcIiBpZD1cInBsYW50VW1sLSR7aWRQbGFjZWhvbGRlcn1cIj48L2Rpdj5gO1xuICAgICAgICAgICAgICAgIC8vIFJlcGxhY2UgdGVzdCBzdGF0dXMgbWFya2Vycy5cbiAgICAgICAgICAgICAgICBjb25zdCBwbGFudFVtbHMgPSB0ZXh0Lm1hdGNoKHBsYW50VW1sUmVnZXgpID8/IFtdO1xuICAgICAgICAgICAgICAgIC8vIEFzc2lnbiB1bmlxdWUgaWRzIHRvIHVtbCBkYXRhIHN0cnVjdHVyZSBhdCB0aGUgYmVnaW5uaW5nLlxuICAgICAgICAgICAgICAgIGNvbnN0IHBsYW50VW1sc0luZGV4ZWQgPSBwbGFudFVtbHMubWFwKChwbGFudFVtbCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXh0SW5kZXggPSB0aGlzLnBsYW50VW1sSW5kZXg7XG4gICAgICAgICAgICAgICAgICAgIC8vIGluY3JlYXNlIHRoZSBnbG9iYWwgdW5pcXVlIGluZGV4IHNvIHRoYXQgdGhlIG5leHQgcGxhbnRVbWwgZ2V0cyBhIHVuaXF1ZSBnbG9iYWwgaWRcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wbGFudFVtbEluZGV4Kys7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7IHBsYW50VW1sSWQ6IG5leHRJbmRleCwgcGxhbnRVbWwgfTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAvLyBjdXN0b20gbWFya2Rvd24gdG8gaHRtbCByZW5kZXJpbmc6IHJlcGxhY2UgdGhlIHBsYW50VW1sIGluIHRoZSBtYXJrZG93biB3aXRoIGEgc2ltcGxlIDxkaXY+PC9kaXY+IGNvbnRhaW5lciB3aXRoIGEgdW5pcXVlIGlkIHBsYWNlaG9sZGVyXG4gICAgICAgICAgICAgICAgLy8gd2l0aCB0aGUgZ2xvYmFsIHVuaXF1ZSBpZCBzbyB0aGF0IHdlIGNhbiBmaW5kIHRoZSBwbGFudFVtbCBsYXRlciBvbiwgd2hlbiBpdCB3YXMgcmVuZGVyZWQsIGFuZCB0aGVuIGluamVjdCB0aGUgJ2FjdHVhbCcgaW5uZXIgaHRtbCAoYWN0dWFsbHkgYSBzdmcgaW1hZ2UpXG4gICAgICAgICAgICAgICAgY29uc3QgcmVwbGFjZWRUZXh0ID0gcGxhbnRVbWxzSW5kZXhlZC5yZWR1Y2UoKGFjYzogc3RyaW5nLCB1bWxJbmRleGVkOiB7IHBsYW50VW1sSWQ6IG51bWJlcjsgcGxhbnRVbWw6IHN0cmluZyB9KTogc3RyaW5nID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFjYy5yZXBsYWNlKG5ldyBSZWdFeHAoZXNjYXBlU3RyaW5nRm9yVXNlSW5SZWdleCh1bWxJbmRleGVkLnBsYW50VW1sKSwgJ2cnKSwgcGxhbnRVbWxDb250YWluZXIucmVwbGFjZShpZFBsYWNlaG9sZGVyLCB1bWxJbmRleGVkLnBsYW50VW1sSWQudG9TdHJpbmcoKSkpO1xuICAgICAgICAgICAgICAgIH0sIHRleHQpO1xuICAgICAgICAgICAgICAgIC8vIGJlZm9yZSB3ZSBzZW5kIHRoZSBwbGFudFVtbCB0byB0aGUgc2VydmVyIGZvciByZW5kZXJpbmcsIHdlIG5lZWQgdG8gaW5qZWN0IHRoZSBjdXJyZW50IHRlc3Qgc3RhdHVzIHNvIHRoYXQgdGhlIGNvbG9ycyBjYW4gYmUgYWRhcHRlZFxuICAgICAgICAgICAgICAgIC8vIChncmVlbiA9PSBpbXBsZW1lbnRlZCwgcmVkID09IG5vdCB5ZXQgaW1wbGVtZW50ZWQsIGdyZXkgPT0gdW5rbm93bilcbiAgICAgICAgICAgICAgICBjb25zdCBwbGFudFVtbHNWYWxpZGF0ZWQgPSBwbGFudFVtbHNJbmRleGVkLm1hcCgocGxhbnRVbWxJbmRleGVkOiB7IHBsYW50VW1sSWQ6IG51bWJlcjsgcGxhbnRVbWw6IHN0cmluZyB9KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHBsYW50VW1sSW5kZXhlZC5wbGFudFVtbCA9IHBsYW50VW1sSW5kZXhlZC5wbGFudFVtbC5yZXBsYWNlKHRlc3RzQ29sb3JSZWdleCwgKG1hdGNoOiBhbnksIGNhcHR1cmU6IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGVzdHMgPSB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdGlvblNlcnZpY2UuY29udmVydFRlc3RMaXN0VG9JZHMoY2FwdHVyZSwgdGhpcy50ZXN0Q2FzZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeyB0ZXN0Q2FzZVN0YXRlIH0gPSB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdGlvblNlcnZpY2UudGVzdFN0YXR1c0ZvclRhc2sodGVzdHMsIHRoaXMubGF0ZXN0UmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN3aXRjaCAodGVzdENhc2VTdGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgVGVzdENhc2VTdGF0ZS5TVUNDRVNTOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJ2dyZWVuJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFRlc3RDYXNlU3RhdGUuRkFJTDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICdyZWQnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAnZ3JleSc7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcGxhbnRVbWxJbmRleGVkO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIC8vIHNlbmQgdGhlIGFkYXB0ZWQgcGxhbnRVbWwgdG8gdGhlIHNlcnZlciBmb3IgcmVuZGVyaW5nIGFuZCBpbmplY3QgdGhlIHJlc3VsdCBpbnRvIHRoZSBodG1sIERPTSBiYXNlZCBvbiB0aGUgdW5pcXVlIHBsYW50VW1sIGlkXG4gICAgICAgICAgICAgICAgdGhpcy5pbmplY3RhYmxlRWxlbWVudHNGb3VuZFN1YmplY3QubmV4dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHBsYW50VW1sc1ZhbGlkYXRlZC5mb3JFYWNoKChwbGFudFVtbEluZGV4ZWQ6IHsgcGxhbnRVbWxJZDogbnVtYmVyOyBwbGFudFVtbDogc3RyaW5nIH0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZEFuZEluamVjdFBsYW50VW1sKHBsYW50VW1sSW5kZXhlZC5wbGFudFVtbCwgcGxhbnRVbWxJbmRleGVkLnBsYW50VW1sSWQpO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVwbGFjZWRUZXh0O1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICAgICAgcmV0dXJuIGV4dGVuc2lvbjtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkNoYW5nZXMsIFNpbXBsZUNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE5nYk1vZGFsIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0aW9uU2VydmljZSwgVGVzdENhc2VTdGF0ZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvc2VydmljZS9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbi5zZXJ2aWNlJztcbmltcG9ydCB7IFRhc2tBcnJheSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvdGFzay9wcm9ncmFtbWluZy1leGVyY2lzZS10YXNrLm1vZGVsJztcbmltcG9ydCB7IEZlZWRiYWNrQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZmVlZGJhY2svZmVlZGJhY2suY29tcG9uZW50JztcbmltcG9ydCB7IEV4ZXJjaXNlLCBFeGVyY2lzZVR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgUmVzdWx0IH0gZnJvbSAnYXBwL2VudGl0aWVzL3Jlc3VsdC5tb2RlbCc7XG5pbXBvcnQgeyBmYUNoZWNrLCBmYVF1ZXN0aW9uLCBmYVRpbWVzIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rpb25zLXN0ZXAtd2l6YXJkJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rpb24tc3RlcC13aXphcmQuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9uLXN0ZXAtd2l6YXJkLnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0aW9uU3RlcFdpemFyZENvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gICAgVGVzdENhc2VTdGF0ZSA9IFRlc3RDYXNlU3RhdGU7XG5cbiAgICBASW5wdXQoKSBleGVyY2lzZTogRXhlcmNpc2U7XG4gICAgQElucHV0KCkgbGF0ZXN0UmVzdWx0PzogUmVzdWx0O1xuICAgIEBJbnB1dCgpIHRhc2tzOiBUYXNrQXJyYXk7XG5cbiAgICBzdGVwczogQXJyYXk8eyBkb25lOiBUZXN0Q2FzZVN0YXRlOyB0aXRsZTogc3RyaW5nOyB0ZXN0SWRzOiBudW1iZXJbXSB9PjtcblxuICAgIC8vIEljb25zXG4gICAgZmFUaW1lcyA9IGZhVGltZXM7XG4gICAgZmFDaGVjayA9IGZhQ2hlY2s7XG4gICAgZmFRdWVzdGlvbiA9IGZhUXVlc3Rpb247XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBtb2RhbFNlcnZpY2U6IE5nYk1vZGFsLFxuICAgICAgICBwcml2YXRlIGluc3RydWN0aW9uU2VydmljZTogUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0aW9uU2VydmljZSxcbiAgICApIHt9XG5cbiAgICAvKipcbiAgICAgKiBMaWZlIGN5Y2xlIGhvb2sgY2FsbGVkIGJ5IEFuZ3VsYXIgdG8gaW5kaWNhdGUgdGhhdCBjaGFuZ2VzIGFyZSBkZXRlY3RlZC5cbiAgICAgKiBAcGFyYW0gY2hhbmdlcyAtIGNoYW5nZSB0aGF0IGlzIGRldGVjdGVkLlxuICAgICAqL1xuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcbiAgICAgICAgaWYgKChjaGFuZ2VzLnRhc2tzICYmIHRoaXMudGFza3MpIHx8ICh0aGlzLnRhc2tzICYmIGNoYW5nZXMubGF0ZXN0UmVzdWx0KSkge1xuICAgICAgICAgICAgdGhpcy5zdGVwcyA9IHRoaXMudGFza3MubWFwKCh7IHRhc2tOYW1lLCB0ZXN0SWRzIH0pID0+ICh7XG4gICAgICAgICAgICAgICAgZG9uZTogdGhpcy5pbnN0cnVjdGlvblNlcnZpY2UudGVzdFN0YXR1c0ZvclRhc2sodGVzdElkcywgdGhpcy5sYXRlc3RSZXN1bHQpLnRlc3RDYXNlU3RhdGUsXG4gICAgICAgICAgICAgICAgdGl0bGU6IHRhc2tOYW1lLFxuICAgICAgICAgICAgICAgIHRlc3RJZHMsXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBPcGVucyB0aGUgRmVlZGJhY2tDb21wb25lbnQgYXMgcG9wdXA7IGRpc3BsYXlzIHRlc3QgcmVzdWx0c1xuICAgICAqIEBwYXJhbSB7c3RyaW5nW119IHRlc3RzIC0gSWRlbnRpZmllcyB0aGUgdGVzdGNhc2VcbiAgICAgKiBAcGFyYW0gdGFza05hbWUgLSB0aGUgbmFtZSBvZiB0aGUgc2VsZWN0ZWQgdGFza1xuICAgICAqL1xuICAgIHB1YmxpYyBzaG93RGV0YWlsc0ZvclRlc3RzKHRlc3RzOiBudW1iZXJbXSwgdGFza05hbWU6IHN0cmluZykge1xuICAgICAgICBpZiAoIXRoaXMubGF0ZXN0UmVzdWx0IHx8ICF0ZXN0cy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgICBkZXRhaWxlZDogeyBub3RFeGVjdXRlZFRlc3RzIH0sXG4gICAgICAgIH0gPSB0aGlzLmluc3RydWN0aW9uU2VydmljZS50ZXN0U3RhdHVzRm9yVGFzayh0ZXN0cywgdGhpcy5sYXRlc3RSZXN1bHQpO1xuICAgICAgICBjb25zdCBtb2RhbFJlZiA9IHRoaXMubW9kYWxTZXJ2aWNlLm9wZW4oRmVlZGJhY2tDb21wb25lbnQsIHsga2V5Ym9hcmQ6IHRydWUsIHNpemU6ICdsZycgfSk7XG4gICAgICAgIGNvbnN0IGNvbXBvbmVudEluc3RhbmNlID0gbW9kYWxSZWYuY29tcG9uZW50SW5zdGFuY2UgYXMgRmVlZGJhY2tDb21wb25lbnQ7XG4gICAgICAgIGNvbXBvbmVudEluc3RhbmNlLmV4ZXJjaXNlID0gdGhpcy5leGVyY2lzZTtcbiAgICAgICAgY29tcG9uZW50SW5zdGFuY2UucmVzdWx0ID0gdGhpcy5sYXRlc3RSZXN1bHQ7XG4gICAgICAgIGNvbXBvbmVudEluc3RhbmNlLmZlZWRiYWNrRmlsdGVyID0gdGVzdHM7XG4gICAgICAgIGNvbXBvbmVudEluc3RhbmNlLmV4ZXJjaXNlVHlwZSA9IEV4ZXJjaXNlVHlwZS5QUk9HUkFNTUlORztcbiAgICAgICAgY29tcG9uZW50SW5zdGFuY2UudGFza05hbWUgPSB0YXNrTmFtZTtcbiAgICAgICAgY29tcG9uZW50SW5zdGFuY2UubnVtYmVyT2ZOb3RFeGVjdXRlZFRlc3RzID0gbm90RXhlY3V0ZWRUZXN0cy5sZW5ndGg7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cImNhcmQtc2Vjb25kLWhlYWRlclwiIFtoaWRkZW5dPVwiIXN0ZXBzPy5sZW5ndGhcIj5cbiAgICA8ZGl2IGNsYXNzPVwic3RlcHdpemFyZFwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3RlcHdpemFyZC10aXRsZVwiPlxuICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAucHJvZ3JhbW1pbmdFeGVyY2lzZS5wcm9ibGVtU3RhdGVtZW50LnRhc2tzT2ZFeGVyY2lzZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwic3RlcHdpemFyZC1yb3dcIj5cbiAgICAgICAgICAgIEBmb3IgKHN0ZXAgb2Ygc3RlcHM7IHRyYWNrIHN0ZXA7IGxldCBpID0gJGluZGV4KSB7XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN0ZXB3aXphcmQtc3RlcFwiPlxuICAgICAgICAgICAgICAgICAgICA8IS0tVGhlIGNzcyBjbGFzcyB0ZXN0LXBhc3NpbmcgcmVtb3ZlcyB0aGUgY3Vyc29yIGljb24gYW5kIHRoZSBob3ZlciBlZmZlY3RzIGZyb20gcGFzc2luZyB0ZXN0IGNpcmNsZXMtLT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgW25nYlRvb2x0aXBdPVwic3RlcC50aXRsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tY2lyY2xlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5zdGVwd2l6YXJkLXN0ZXAtLXN1Y2Nlc3NdPVwic3RlcC5kb25lID09PSBUZXN0Q2FzZVN0YXRlLlNVQ0NFU1NcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnN0ZXB3aXphcmQtc3RlcC0tZmFpbGVkXT1cInN0ZXAuZG9uZSA9PT0gVGVzdENhc2VTdGF0ZS5GQUlMXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5zdGVwd2l6YXJkLXN0ZXAtLW5vdC1leGVjdXRlZF09XCJzdGVwLmRvbmUgPT09IFRlc3RDYXNlU3RhdGUuTk9UX0VYRUNVVEVEXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5zdGVwd2l6YXJkLXN0ZXAtLW5vLXJlc3VsdF09XCJzdGVwLmRvbmUgPT09IFRlc3RDYXNlU3RhdGUuTk9fUkVTVUxUXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJzaG93RGV0YWlsc0ZvclRlc3RzKHN0ZXAudGVzdElkcywgc3RlcC50aXRsZSlcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHN0ZXAuZG9uZSA9PT0gVGVzdENhc2VTdGF0ZS5TVUNDRVNTKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFDaGVja1wiIHNpemU9XCJsZ1wiIGNsYXNzPVwidGV4dC1zdWNjZXNzXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChzdGVwLmRvbmUgPT09IFRlc3RDYXNlU3RhdGUuRkFJTCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhVGltZXNcIiBzaXplPVwibGdcIiBjbGFzcz1cInRleHQtZGFuZ2VyXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChzdGVwLmRvbmUgPT09IFRlc3RDYXNlU3RhdGUuTk9UX0VYRUNVVEVEIHx8IHN0ZXAuZG9uZSA9PT0gVGVzdENhc2VTdGF0ZS5OT19SRVNVTFQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVF1ZXN0aW9uXCIgc2l6ZT1cImxnXCIgY2xhc3M9XCJub3QtZG9uZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uQ2hhbmdlcywgT25EZXN0cm95LCBPbkluaXQsIE91dHB1dCwgU2ltcGxlQ2hhbmdlcywgVmlld0NvbnRhaW5lclJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU2FmZUh0bWwgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcbmltcG9ydCB7IFRoZW1lU2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3RoZW1lL3RoZW1lLnNlcnZpY2UnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXRlc3QtY2FzZS5tb2RlbCc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlR3JhZGluZ1NlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL21hbmFnZS9zZXJ2aWNlcy9wcm9ncmFtbWluZy1leGVyY2lzZS1ncmFkaW5nLnNlcnZpY2UnO1xuaW1wb3J0IHsgU2hvd2Rvd25FeHRlbnNpb24gfSBmcm9tICdzaG93ZG93bic7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBmaWx0ZXIsIG1hcCwgbWVyZ2VNYXAsIHN3aXRjaE1hcCwgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgU3Vic2NyaXB0aW9uLCBtZXJnZSwgb2YgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvcHJvZ3JhbW1pbmctZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgUGFydGljaXBhdGlvbldlYnNvY2tldFNlcnZpY2UgfSBmcm9tICdhcHAvb3ZlcnZpZXcvcGFydGljaXBhdGlvbi13ZWJzb2NrZXQuc2VydmljZSc7XG5pbXBvcnQgeyBBcnRlbWlzTWFya2Rvd25TZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi5zZXJ2aWNlJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2VUYXNrRXh0ZW5zaW9uV3JhcHBlciB9IGZyb20gJy4vZXh0ZW5zaW9ucy9wcm9ncmFtbWluZy1leGVyY2lzZS10YXNrLmV4dGVuc2lvbic7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlUGxhbnRVbWxFeHRlbnNpb25XcmFwcGVyIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvaW5zdHJ1Y3Rpb25zLXJlbmRlci9leHRlbnNpb25zL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXBsYW50LXVtbC5leHRlbnNpb24nO1xuaW1wb3J0IHsgVGFza0FycmF5LCBUYXNrQXJyYXlXaXRoRXhlcmNpc2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9pbnN0cnVjdGlvbnMtcmVuZGVyL3Rhc2svcHJvZ3JhbW1pbmctZXhlcmNpc2UtdGFzay5tb2RlbCc7XG5pbXBvcnQgeyBQYXJ0aWNpcGF0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3BhcnRpY2lwYXRpb24vcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBGZWVkYmFjayB9IGZyb20gJ2FwcC9lbnRpdGllcy9mZWVkYmFjay5tb2RlbCc7XG5pbXBvcnQgeyBSZXN1bHRTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcmVzdWx0L3Jlc3VsdC5zZXJ2aWNlJztcbmltcG9ydCB7IFJlcG9zaXRvcnlGaWxlU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3Jlc3VsdC9yZXBvc2l0b3J5LnNlcnZpY2UnO1xuaW1wb3J0IHsgcHJvYmxlbVN0YXRlbWVudEhhc0NoYW5nZWQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS9leGVyY2lzZS51dGlscyc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlUGFydGljaXBhdGlvblNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL21hbmFnZS9zZXJ2aWNlcy9wcm9ncmFtbWluZy1leGVyY2lzZS1wYXJ0aWNpcGF0aW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgUmVzdWx0IH0gZnJvbSAnYXBwL2VudGl0aWVzL3Jlc3VsdC5tb2RlbCc7XG5pbXBvcnQgeyBmaW5kTGF0ZXN0UmVzdWx0IH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL3V0aWxzJztcbmltcG9ydCB7IGZhU3Bpbm5lciB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBoYXNQYXJ0aWNpcGF0aW9uQ2hhbmdlZCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BhcnRpY2lwYXRpb24vcGFydGljaXBhdGlvbi51dGlscyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXByb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9ucycsXG4gICAgdGVtcGxhdGVVcmw6ICcuL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9uLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbi5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIFByb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdGlvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcywgT25Jbml0LCBPbkRlc3Ryb3kge1xuICAgIEBJbnB1dCgpIHB1YmxpYyBleGVyY2lzZTogUHJvZ3JhbW1pbmdFeGVyY2lzZTtcbiAgICBASW5wdXQoKSBwdWJsaWMgcGFydGljaXBhdGlvbjogUGFydGljaXBhdGlvbjtcbiAgICBASW5wdXQoKSBnZW5lcmF0ZUh0bWxFdmVudHM6IE9ic2VydmFibGU8dm9pZD47XG4gICAgQElucHV0KCkgcGVyc29uYWxQYXJ0aWNpcGF0aW9uOiBib29sZWFuO1xuICAgIC8vIElmIHRoZXJlIGFyZSBubyBpbnN0cnVjdGlvbnMgYXZhaWxhYmxlIChuZWl0aGVyIGluIHRoZSBleGVyY2lzZSBwcm9ibGVtU3RhdGVtZW50IG5vciB0aGUgbGVnYWN5IFJFQURNRS5tZCkgZW1pdHMgYW4gZXZlbnRcbiAgICBAT3V0cHV0KClcbiAgICBwdWJsaWMgb25Ob0luc3RydWN0aW9uc0F2YWlsYWJsZSA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICAgIHB1YmxpYyBwcm9ibGVtU3RhdGVtZW50OiBzdHJpbmc7XG4gICAgcHVibGljIHBhcnRpY2lwYXRpb25TdWJzY3JpcHRpb24/OiBTdWJzY3JpcHRpb247XG4gICAgcHJpdmF0ZSB0ZXN0Q2FzZXNTdWJzY3JpcHRpb24/OiBTdWJzY3JpcHRpb247XG5cbiAgICBwdWJsaWMgaXNJbml0aWFsID0gdHJ1ZTtcbiAgICBwdWJsaWMgaXNMb2FkaW5nOiBib29sZWFuO1xuICAgIHB1YmxpYyBsYXRlc3RSZXN1bHRWYWx1ZT86IFJlc3VsdDtcblxuICAgIGdldCBsYXRlc3RSZXN1bHQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmxhdGVzdFJlc3VsdFZhbHVlO1xuICAgIH1cblxuICAgIHNldCBsYXRlc3RSZXN1bHQocmVzdWx0OiBSZXN1bHQgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5sYXRlc3RSZXN1bHRWYWx1ZSA9IHJlc3VsdDtcbiAgICAgICAgdGhpcy5wcm9ncmFtbWluZ0V4ZXJjaXNlVGFza1dyYXBwZXIuc2V0RXhlcmNpc2UodGhpcy5leGVyY2lzZSk7XG4gICAgICAgIHRoaXMucHJvZ3JhbW1pbmdFeGVyY2lzZVRhc2tXcmFwcGVyLnNldExhdGVzdFJlc3VsdCh0aGlzLmxhdGVzdFJlc3VsdCk7XG4gICAgICAgIHRoaXMucHJvZ3JhbW1pbmdFeGVyY2lzZVBsYW50VW1sV3JhcHBlci5zZXRMYXRlc3RSZXN1bHQodGhpcy5sYXRlc3RSZXN1bHQpO1xuICAgICAgICB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2VUYXNrV3JhcHBlci5zZXRUZXN0Q2FzZXModGhpcy50ZXN0Q2FzZXMpO1xuICAgICAgICB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2VQbGFudFVtbFdyYXBwZXIuc2V0VGVzdENhc2VzKHRoaXMudGVzdENhc2VzKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgdGFza3M6IFRhc2tBcnJheTtcbiAgICBwdWJsaWMgcmVuZGVyZWRNYXJrZG93bjogU2FmZUh0bWw7XG4gICAgcHJpdmF0ZSBpbmplY3RhYmxlQ29udGVudEZvck1hcmtkb3duQ2FsbGJhY2tzOiBBcnJheTwoKSA9PiB2b2lkPiA9IFtdO1xuXG4gICAgbWFya2Rvd25FeHRlbnNpb25zOiBTaG93ZG93bkV4dGVuc2lvbltdO1xuICAgIHByaXZhdGUgaW5qZWN0YWJsZUNvbnRlbnRGb3VuZFN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xuICAgIHByaXZhdGUgdGFza3NTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcbiAgICBwcml2YXRlIGdlbmVyYXRlSHRtbFN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xuICAgIHByaXZhdGUgdGhlbWVDaGFuZ2VTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcbiAgICBwcml2YXRlIHRlc3RDYXNlcz86IFByb2dyYW1taW5nRXhlcmNpc2VUZXN0Q2FzZVtdO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYVNwaW5uZXIgPSBmYVNwaW5uZXI7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHVibGljIHZpZXdDb250YWluZXJSZWY6IFZpZXdDb250YWluZXJSZWYsXG4gICAgICAgIHByaXZhdGUgcmVzdWx0U2VydmljZTogUmVzdWx0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSByZXBvc2l0b3J5RmlsZVNlcnZpY2U6IFJlcG9zaXRvcnlGaWxlU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBwYXJ0aWNpcGF0aW9uV2Vic29ja2V0U2VydmljZTogUGFydGljaXBhdGlvbldlYnNvY2tldFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgbWFya2Rvd25TZXJ2aWNlOiBBcnRlbWlzTWFya2Rvd25TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHByb2dyYW1taW5nRXhlcmNpc2VUYXNrV3JhcHBlcjogUHJvZ3JhbW1pbmdFeGVyY2lzZVRhc2tFeHRlbnNpb25XcmFwcGVyLFxuICAgICAgICBwcml2YXRlIHByb2dyYW1taW5nRXhlcmNpc2VQbGFudFVtbFdyYXBwZXI6IFByb2dyYW1taW5nRXhlcmNpc2VQbGFudFVtbEV4dGVuc2lvbldyYXBwZXIsXG4gICAgICAgIHByaXZhdGUgcHJvZ3JhbW1pbmdFeGVyY2lzZVBhcnRpY2lwYXRpb25TZXJ2aWNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlUGFydGljaXBhdGlvblNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgcHJvZ3JhbW1pbmdFeGVyY2lzZUdyYWRpbmdTZXJ2aWNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlR3JhZGluZ1NlcnZpY2UsXG4gICAgICAgIHRoZW1lU2VydmljZTogVGhlbWVTZXJ2aWNlLFxuICAgICkge1xuICAgICAgICB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2VUYXNrV3JhcHBlci52aWV3Q29udGFpbmVyUmVmID0gdGhpcy52aWV3Q29udGFpbmVyUmVmO1xuICAgICAgICB0aGlzLnRoZW1lQ2hhbmdlU3Vic2NyaXB0aW9uID0gdGhlbWVTZXJ2aWNlLmdldEN1cnJlbnRUaGVtZU9ic2VydmFibGUoKS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy51cGRhdGVNYXJrZG93bigpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBJZiB0aGUgcGFydGljaXBhdGlvbiBjaGFuZ2VzLCB0aGUgcGFydGljaXBhdGlvbidzIGluc3RydWN0aW9ucyBuZWVkIHRvIGJlIGxvYWRlZCBhbmQgdGhlXG4gICAgICogc3Vic2NyaXB0aW9uIGZvciB0aGUgcGFydGljaXBhdGlvbidzIHJlc3VsdCBuZWVkcyB0byBiZSBzZXQgdXAuXG4gICAgICogQHBhcmFtIGNoYW5nZXNcbiAgICAgKi9cbiAgICBwdWJsaWMgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBvZighIXRoaXMubWFya2Rvd25FeHRlbnNpb25zKVxuICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgLy8gU2V0IHVwIHRoZSBtYXJrZG93biBleHRlbnNpb25zIGlmIHRoZXkgYXJlIG5vdCBzZXQgdXAgeWV0IHNvIHRoYXQgdGFza3MsIFVNTHMsIGV0Yy4gY2FuIGJlIHBhcnNlZC5cbiAgICAgICAgICAgICAgICB0YXAoKG1hcmtkb3duRXh0ZW5zaW9uc0luaXRpYWxpemVkOiBib29sZWFuKSA9PiAhbWFya2Rvd25FeHRlbnNpb25zSW5pdGlhbGl6ZWQgJiYgdGhpcy5zZXR1cE1hcmtkb3duU3Vic2NyaXB0aW9ucygpKSxcbiAgICAgICAgICAgICAgICAvLyBJZiB0aGUgcGFydGljaXBhdGlvbiBoYXMgY2hhbmdlZCwgc2V0IHVwIHRoZSB3ZWJzb2NrZXQgc3Vic2NyaXB0aW9ucy5cbiAgICAgICAgICAgICAgICBtYXAoKCkgPT4gaGFzUGFydGljaXBhdGlvbkNoYW5nZWQoY2hhbmdlcykpLFxuICAgICAgICAgICAgICAgIHRhcCgocGFydGljaXBhdGlvbkhhc0NoYW5nZWQ6IGJvb2xlYW4pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhcnRpY2lwYXRpb25IYXNDaGFuZ2VkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmlzSW5pdGlhbCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5nZW5lcmF0ZUh0bWxTdWJzY3JpcHRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdlbmVyYXRlSHRtbFN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuZ2VuZXJhdGVIdG1sRXZlbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5nZW5lcmF0ZUh0bWxFdmVudHMuc3Vic2NyaWJlKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy51cGRhdGVNYXJrZG93bigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXR1cFJlc3VsdFdlYnNvY2tldCgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgc3dpdGNoTWFwKChwYXJ0aWNpcGF0aW9uSGFzQ2hhbmdlZDogYm9vbGVhbikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAvLyBJZiB0aGUgZXhlcmNpc2UgaXMgbm90IGxvYWRlZCwgdGhlIGluc3RydWN0aW9ucyBjYW4ndCBiZSBsb2FkZWQgYW5kIHNvIHRoZXJlIGlzIG5vIHBvaW50IGluIGxvYWRpbmcgdGhlIHJlc3VsdHMsIGV0YywgeWV0LlxuICAgICAgICAgICAgICAgICAgICBpZiAoIXRoaXMuaXNMb2FkaW5nICYmIHRoaXMuZXhlcmNpc2UgJiYgdGhpcy5wYXJ0aWNpcGF0aW9uICYmICh0aGlzLmlzSW5pdGlhbCB8fCBwYXJ0aWNpcGF0aW9uSGFzQ2hhbmdlZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaXNMb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmxvYWRJbnN0cnVjdGlvbnMoKS5waXBlKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIElmIG5vIGluc3RydWN0aW9ucyBjYW4gYmUgbG9hZGVkLCBhYm9ydCBwaXBlIGFuZCBoaWRlIHRoZSBpbnN0cnVjdGlvbiBwYW5lbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcCgocHJvYmxlbVN0YXRlbWVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXByb2JsZW1TdGF0ZW1lbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub25Ob0luc3RydWN0aW9uc0F2YWlsYWJsZS5lbWl0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5pc0luaXRpYWwgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvZih1bmRlZmluZWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyKChwcm9ibGVtU3RhdGVtZW50KSA9PiAhIXByb2JsZW1TdGF0ZW1lbnQpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcCgocHJvYmxlbVN0YXRlbWVudCkgPT4gKHRoaXMucHJvYmxlbVN0YXRlbWVudCA9IHByb2JsZW1TdGF0ZW1lbnQhKSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoTWFwKCgpID0+IHRoaXMubG9hZEluaXRpYWxSZXN1bHQoKSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFwKChsYXRlc3RSZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sYXRlc3RSZXN1bHQgPSBsYXRlc3RSZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFwKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy51cGRhdGVNYXJrZG93bigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmlzSW5pdGlhbCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChwcm9ibGVtU3RhdGVtZW50SGFzQ2hhbmdlZChjaGFuZ2VzKSAmJiB0aGlzLnByb2JsZW1TdGF0ZW1lbnQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVmcmVzaGVzIHRoZSBzdGF0ZSBpbiB0aGUgc2luZ2xldG9uIHRhc2sgYW5kIHVtbCBleHRlbnNpb24gc2VydmljZVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sYXRlc3RSZXN1bHQgPSB0aGlzLmxhdGVzdFJlc3VsdFZhbHVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5wcm9ibGVtU3RhdGVtZW50ID0gdGhpcy5leGVyY2lzZS5wcm9ibGVtU3RhdGVtZW50ITtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlTWFya2Rvd24oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvZih1bmRlZmluZWQpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuZXhlcmNpc2UgJiYgcHJvYmxlbVN0YXRlbWVudEhhc0NoYW5nZWQoY2hhbmdlcykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFJlZnJlc2hlcyB0aGUgc3RhdGUgaW4gdGhlIHNpbmdsZXRvbiB0YXNrIGFuZCB1bWwgZXh0ZW5zaW9uIHNlcnZpY2VcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubGF0ZXN0UmVzdWx0ID0gdGhpcy5sYXRlc3RSZXN1bHRWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucHJvYmxlbVN0YXRlbWVudCA9IHRoaXMuZXhlcmNpc2UucHJvYmxlbVN0YXRlbWVudCE7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gb2YodW5kZWZpbmVkKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvZih1bmRlZmluZWQpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAuc3Vic2NyaWJlKCk7XG4gICAgfVxuXG4gICAgcHVibGljIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICBpZiAodGhpcy5leGVyY2lzZT8uaXNBdExlYXN0VHV0b3IpIHtcbiAgICAgICAgICAgIHRoaXMudGVzdENhc2VzU3Vic2NyaXB0aW9uID0gdGhpcy5wcm9ncmFtbWluZ0V4ZXJjaXNlR3JhZGluZ1NlcnZpY2VcbiAgICAgICAgICAgICAgICAuZ2V0VGVzdENhc2VzKHRoaXMuZXhlcmNpc2UuaWQhKVxuICAgICAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgICAgICB0YXAoKHRlc3RDYXNlcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy50ZXN0Q2FzZXMgPSB0ZXN0Q2FzZXM7XG4gICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXR1cCB0aGUgbWFya2Rvd24gZXh0ZW5zaW9ucyBmb3IgcGFyc2luZyB0aGUgdGFza3MgYW5kIHRlc3RzIGFuZCBzdWJzY3JpcHRpb25zIG5lY2Vzc2FyeSB0byByZWNlaXZlIGluamVjdGFibGUgY29udGVudC5cbiAgICAgKi9cbiAgICBwcml2YXRlIHNldHVwTWFya2Rvd25TdWJzY3JpcHRpb25zKCkge1xuICAgICAgICB0aGlzLm1hcmtkb3duRXh0ZW5zaW9ucyA9IFt0aGlzLnByb2dyYW1taW5nRXhlcmNpc2VUYXNrV3JhcHBlci5nZXRFeHRlbnNpb24oKSwgdGhpcy5wcm9ncmFtbWluZ0V4ZXJjaXNlUGxhbnRVbWxXcmFwcGVyLmdldEV4dGVuc2lvbigpXTtcbiAgICAgICAgaWYgKHRoaXMuaW5qZWN0YWJsZUNvbnRlbnRGb3VuZFN1YnNjcmlwdGlvbikge1xuICAgICAgICAgICAgdGhpcy5pbmplY3RhYmxlQ29udGVudEZvdW5kU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5pbmplY3RhYmxlQ29udGVudEZvdW5kU3Vic2NyaXB0aW9uID0gbWVyZ2UoXG4gICAgICAgICAgICB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2VUYXNrV3JhcHBlci5zdWJzY3JpYmVGb3JJbmplY3RhYmxlRWxlbWVudHNGb3VuZCgpLFxuICAgICAgICAgICAgdGhpcy5wcm9ncmFtbWluZ0V4ZXJjaXNlUGxhbnRVbWxXcmFwcGVyLnN1YnNjcmliZUZvckluamVjdGFibGVFbGVtZW50c0ZvdW5kKCksXG4gICAgICAgICkuc3Vic2NyaWJlKChpbmplY3RhYmxlQ2FsbGJhY2spID0+IHtcbiAgICAgICAgICAgIHRoaXMuaW5qZWN0YWJsZUNvbnRlbnRGb3JNYXJrZG93bkNhbGxiYWNrcyA9IFsuLi50aGlzLmluamVjdGFibGVDb250ZW50Rm9yTWFya2Rvd25DYWxsYmFja3MsIGluamVjdGFibGVDYWxsYmFja107XG4gICAgICAgIH0pO1xuICAgICAgICBpZiAodGhpcy50YXNrc1N1YnNjcmlwdGlvbikge1xuICAgICAgICAgICAgdGhpcy50YXNrc1N1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMudGFza3NTdWJzY3JpcHRpb24gPSB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2VUYXNrV3JhcHBlci5zdWJzY3JpYmVGb3JGb3VuZFRlc3RzSW5UYXNrcygpLnN1YnNjcmliZSgodGFza3M6IFRhc2tBcnJheVdpdGhFeGVyY2lzZSkgPT4ge1xuICAgICAgICAgICAgLy8gTXVsdGlwbGUgaW5zdGFuY2VzIG9mIHRoZSBjb2RlIGVkaXRvciB1c2UgdGhlIFRhc2tXcmFwcGVyU2VydmljZS4gV2UgaGF2ZSB0byBjaGVjaywgdGhhdCB0aGUgcmV0dXJuZWQgdGFza3MgYmVsb25nIHRvIHRoaXMgZXhlcmNpc2VcbiAgICAgICAgICAgIGlmICh0YXNrcy5leGVyY2lzZUlkID09PSB0aGlzLmV4ZXJjaXNlLmlkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy50YXNrcyA9IHRhc2tzLnRhc2tzO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZXQgdXAgdGhlIHdlYnNvY2tldCBmb3IgcmV0cmlldmluZyBidWlsZCByZXN1bHRzLlxuICAgICAqIE9ubGluZSB1cGRhdGVzIHRoZSBidWlsZCBsb2dzIGlmIHRoZSByZXN1bHQgaXMgbmV3LCBvdGhlcndpc2UgZG9lc24ndCByZWFjdC5cbiAgICAgKi9cbiAgICBwcml2YXRlIHNldHVwUmVzdWx0V2Vic29ja2V0KCkge1xuICAgICAgICBpZiAodGhpcy5wYXJ0aWNpcGF0aW9uU3Vic2NyaXB0aW9uKSB7XG4gICAgICAgICAgICB0aGlzLnBhcnRpY2lwYXRpb25TdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnBhcnRpY2lwYXRpb25TdWJzY3JpcHRpb24gPSB0aGlzLnBhcnRpY2lwYXRpb25XZWJzb2NrZXRTZXJ2aWNlXG4gICAgICAgICAgICAuc3Vic2NyaWJlRm9yTGF0ZXN0UmVzdWx0T2ZQYXJ0aWNpcGF0aW9uKHRoaXMucGFydGljaXBhdGlvbi5pZCEsIHRoaXMucGVyc29uYWxQYXJ0aWNpcGF0aW9uLCB0aGlzLmV4ZXJjaXNlLmlkISlcbiAgICAgICAgICAgIC5waXBlKGZpbHRlcigocmVzdWx0KSA9PiAhIXJlc3VsdCkpXG4gICAgICAgICAgICAuc3Vic2NyaWJlKChyZXN1bHQ6IFJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMubGF0ZXN0UmVzdWx0ID0gcmVzdWx0O1xuICAgICAgICAgICAgICAgIHRoaXMucHJvZ3JhbW1pbmdFeGVyY2lzZVRhc2tXcmFwcGVyLnNldExhdGVzdFJlc3VsdCh0aGlzLmxhdGVzdFJlc3VsdCk7XG4gICAgICAgICAgICAgICAgdGhpcy5wcm9ncmFtbWluZ0V4ZXJjaXNlUGxhbnRVbWxXcmFwcGVyLnNldExhdGVzdFJlc3VsdCh0aGlzLmxhdGVzdFJlc3VsdCk7XG4gICAgICAgICAgICAgICAgdGhpcy51cGRhdGVNYXJrZG93bigpO1xuICAgICAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmVuZGVyIHRoZSBtYXJrZG93biBpbnRvIGh0bWwuXG4gICAgICovXG4gICAgdXBkYXRlTWFya2Rvd24oKTogdm9pZCB7XG4gICAgICAgIC8vIG1ha2Ugc3VyZSB0aGF0IGFsd2F5cyB0aGUgY29ycmVjdCByZXN1bHQgaXMgc2V0LCBiZWZvcmUgdXBkYXRpbmcgbWFya2Rvd25cbiAgICAgICAgLy8gbG9va3Mgd2VpcmQsIGJ1dCBpbiBzZXR0ZXIgb2YgbGF0ZXN0UmVzdWx0IGFyZSBzZXR0ZXJzIG9mIHN1YiBjb21wb25lbnRzIGludm9rZWRcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXNlbGYtYXNzaWduXG4gICAgICAgIHRoaXMubGF0ZXN0UmVzdWx0ID0gdGhpcy5sYXRlc3RSZXN1bHQ7XG5cbiAgICAgICAgdGhpcy5pbmplY3RhYmxlQ29udGVudEZvck1hcmtkb3duQ2FsbGJhY2tzID0gW107XG4gICAgICAgIHRoaXMucmVuZGVyZWRNYXJrZG93biA9IHRoaXMubWFya2Rvd25TZXJ2aWNlLnNhZmVIdG1sRm9yTWFya2Rvd24odGhpcy5wcm9ibGVtU3RhdGVtZW50LCB0aGlzLm1hcmtkb3duRXh0ZW5zaW9ucyk7XG4gICAgICAgIC8vIFdhaXQgYSB0aWNrIGZvciB0aGUgdGVtcGxhdGUgdG8gcmVuZGVyIGJlZm9yZSBpbmplY3RpbmcgdGhlIGNvbnRlbnQuXG4gICAgICAgIHNldFRpbWVvdXQoXG4gICAgICAgICAgICAoKSA9PlxuICAgICAgICAgICAgICAgIHRoaXMuaW5qZWN0YWJsZUNvbnRlbnRGb3JNYXJrZG93bkNhbGxiYWNrcy5mb3JFYWNoKChjYWxsYmFjaykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgMCxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICByZW5kZXJVcGRhdGVkUHJvYmxlbVN0YXRlbWVudCgpIHtcbiAgICAgICAgdGhpcy5wcm9ibGVtU3RhdGVtZW50ID0gdGhpcy5leGVyY2lzZS5wcm9ibGVtU3RhdGVtZW50ITtcbiAgICAgICAgdGhpcy51cGRhdGVNYXJrZG93bigpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFRoaXMgbWV0aG9kIGlzIHVzZWQgZm9yIGluaXRpYWxseSBsb2FkaW5nIHRoZSByZXN1bHRzIHNvIHRoYXQgdGhlIGluc3RydWN0aW9ucyBjYW4gYmUgcmVuZGVyZWQuXG4gICAgICovXG4gICAgbG9hZEluaXRpYWxSZXN1bHQoKTogT2JzZXJ2YWJsZTxSZXN1bHQgfCB1bmRlZmluZWQ+IHtcbiAgICAgICAgaWYgKHRoaXMucGFydGljaXBhdGlvbj8uaWQgJiYgdGhpcy5wYXJ0aWNpcGF0aW9uPy5yZXN1bHRzPy5sZW5ndGgpIHtcbiAgICAgICAgICAgIC8vIEdldCB0aGUgcmVzdWx0IHdpdGggdGhlIGhpZ2hlc3QgaWQgKG1vc3QgcmVjZW50IHJlc3VsdClcbiAgICAgICAgICAgIGNvbnN0IGxhdGVzdFJlc3VsdCA9IGZpbmRMYXRlc3RSZXN1bHQodGhpcy5wYXJ0aWNpcGF0aW9uLnJlc3VsdHMpO1xuICAgICAgICAgICAgaWYgKCFsYXRlc3RSZXN1bHQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gb2YodW5kZWZpbmVkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxhdGVzdFJlc3VsdC5wYXJ0aWNpcGF0aW9uID0gdGhpcy5wYXJ0aWNpcGF0aW9uO1xuICAgICAgICAgICAgcmV0dXJuIGxhdGVzdFJlc3VsdC5mZWVkYmFja3MgPyBvZihsYXRlc3RSZXN1bHQpIDogdGhpcy5sb2FkQW5kQXR0YWNoUmVzdWx0RGV0YWlscyhsYXRlc3RSZXN1bHQpO1xuICAgICAgICB9IGVsc2UgaWYgKHRoaXMucGFydGljaXBhdGlvbiAmJiB0aGlzLnBhcnRpY2lwYXRpb24uaWQpIHtcbiAgICAgICAgICAgIC8vIE9ubHkgbG9hZCByZXN1bHRzIGlmIHRoZSBleGVyY2lzZSBhbHJlYWR5IGlzIGluIG91ciBkYXRhYmFzZSwgb3RoZXJ3aXNlIHRoZXJlIGNhbiBiZSBubyBidWlsZCByZXN1bHQgYW55d2F5XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5sb2FkTGF0ZXN0UmVzdWx0KCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gb2YodW5kZWZpbmVkKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHJpZXZlIGxhdGVzdCByZXN1bHQgZm9yIHRoZSBwYXJ0aWNpcGF0aW9uL2V4ZXJjaXNlL2NvdXJzZSBjb21iaW5hdGlvbi5cbiAgICAgKiBJZiB0aGVyZSBpcyBubyByZXN1bHQsIHJldHVybiB1bmRlZmluZWQuXG4gICAgICovXG4gICAgbG9hZExhdGVzdFJlc3VsdCgpOiBPYnNlcnZhYmxlPFJlc3VsdCB8IHVuZGVmaW5lZD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5wcm9ncmFtbWluZ0V4ZXJjaXNlUGFydGljaXBhdGlvblNlcnZpY2UuZ2V0TGF0ZXN0UmVzdWx0V2l0aEZlZWRiYWNrKHRoaXMucGFydGljaXBhdGlvbi5pZCEsIHRydWUpLnBpcGUoXG4gICAgICAgICAgICBjYXRjaEVycm9yKCgpID0+IG9mKHVuZGVmaW5lZCkpLFxuICAgICAgICAgICAgbWVyZ2VNYXAoKGxhdGVzdFJlc3VsdDogUmVzdWx0KSA9PiAobGF0ZXN0UmVzdWx0ICYmICFsYXRlc3RSZXN1bHQuZmVlZGJhY2tzID8gdGhpcy5sb2FkQW5kQXR0YWNoUmVzdWx0RGV0YWlscyhsYXRlc3RSZXN1bHQpIDogb2YobGF0ZXN0UmVzdWx0KSkpLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEZldGNoZXMgZGV0YWlscyBmb3IgdGhlIHJlc3VsdCAoaWYgd2UgcmVjZWl2ZWQgb25lKSBhbmQgYXR0YWNoIHRoZW0gdG8gdGhlIHJlc3VsdC5cbiAgICAgKiBNdXRhdGVzIHRoZSBpbnB1dCBwYXJhbWV0ZXIgcmVzdWx0LlxuICAgICAqIEBwYXJhbSByZXN1bHQgLSByZXN1bHQgdG8gd2hpY2ggaW5zdHJ1Y3Rpb25zIHdpbGwgYmUgYXR0YWNoZWQuXG4gICAgICovXG4gICAgbG9hZEFuZEF0dGFjaFJlc3VsdERldGFpbHMocmVzdWx0OiBSZXN1bHQpOiBPYnNlcnZhYmxlPFJlc3VsdD4ge1xuICAgICAgICBjb25zdCBjdXJyZW50UGFydGljaXBhdGlvbiA9IHJlc3VsdC5wYXJ0aWNpcGF0aW9uID8gcmVzdWx0LnBhcnRpY2lwYXRpb24gOiB0aGlzLnBhcnRpY2lwYXRpb247XG4gICAgICAgIHJldHVybiB0aGlzLnJlc3VsdFNlcnZpY2UuZ2V0RmVlZGJhY2tEZXRhaWxzRm9yUmVzdWx0KGN1cnJlbnRQYXJ0aWNpcGF0aW9uLmlkISwgcmVzdWx0KS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXMpID0+IHJlcyAmJiByZXMuYm9keSksXG4gICAgICAgICAgICBtYXAoKGZlZWRiYWNrczogRmVlZGJhY2tbXSkgPT4ge1xuICAgICAgICAgICAgICAgIHJlc3VsdC5mZWVkYmFja3MgPSBmZWVkYmFja3M7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcigoKSA9PiBvZihyZXN1bHQpKSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBMb2FkcyB0aGUgaW5zdHJ1Y3Rpb25zIGZvciB0aGUgcHJvZ3JhbW1pbmcgZXhlcmNpc2UuXG4gICAgICogV2UgYWRkZWQgdGhlIHByb2JsZW1TdGF0ZW1lbnQgbGF0ZXIsIGhpc3RvcmljYWxseSB0aGUgaW5zdHJ1Y3Rpb25zIHdoZXJlIGEgZmlsZSBpbiB0aGUgc3R1ZGVudCdzIHJlcG9zaXRvcnlcbiAgICAgKiBUaGlzIGlzIHdoeSB3ZSBub3cgcHJlZmVyIHRoZSBwcm9ibGVtU3RhdGVtZW50IGFuZCBpZiBpdCBkb2Vzbid0IGV4aXN0IHRyeSB0byBsb2FkIHRoZSByZWFkbWUuXG4gICAgICovXG4gICAgbG9hZEluc3RydWN0aW9ucygpOiBPYnNlcnZhYmxlPHN0cmluZyB8IHVuZGVmaW5lZD4ge1xuICAgICAgICBpZiAodGhpcy5leGVyY2lzZS5wcm9ibGVtU3RhdGVtZW50KSB7XG4gICAgICAgICAgICByZXR1cm4gb2YodGhpcy5leGVyY2lzZS5wcm9ibGVtU3RhdGVtZW50KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmICghdGhpcy5wYXJ0aWNpcGF0aW9uLmlkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG9mKHVuZGVmaW5lZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5yZXBvc2l0b3J5RmlsZVNlcnZpY2UuZ2V0KHRoaXMucGFydGljaXBhdGlvbi5pZCwgJ1JFQURNRS5tZCcpLnBpcGUoXG4gICAgICAgICAgICAgICAgY2F0Y2hFcnJvcigoKSA9PiBvZih1bmRlZmluZWQpKSxcbiAgICAgICAgICAgICAgICAvLyBPbGQgcmVhZG1lIGZpbGVzIGNvbnRhaW4gY2hhcnMgaW5zdGVhZCBvZiBvdXIgZG9tYWluIGNvbW1hbmQgdGFncyAtIHJlcGxhY2UgdGhlbSB3aGVuIGxvYWRpbmcgdGhlIGZpbGVcbiAgICAgICAgICAgICAgICBtYXAoKGZpbGVPYmopID0+IGZpbGVPYmogJiYgZmlsZU9iai5maWxlQ29udGVudC5yZXBsYWNlKG5ldyBSZWdFeHAoL+KchS8sICdnJyksICdbdGFza10nKSksXG4gICAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVW5zdWJzY3JpYmVzIGZyb20gYWxsIHN1YnNjcmlwdGlvbnMuXG4gICAgICovXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIGlmICh0aGlzLnBhcnRpY2lwYXRpb25TdWJzY3JpcHRpb24pIHtcbiAgICAgICAgICAgIHRoaXMucGFydGljaXBhdGlvblN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmdlbmVyYXRlSHRtbFN1YnNjcmlwdGlvbikge1xuICAgICAgICAgICAgdGhpcy5nZW5lcmF0ZUh0bWxTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5pbmplY3RhYmxlQ29udGVudEZvdW5kU3Vic2NyaXB0aW9uKSB7XG4gICAgICAgICAgICB0aGlzLmluamVjdGFibGVDb250ZW50Rm91bmRTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy50YXNrc1N1YnNjcmlwdGlvbikge1xuICAgICAgICAgICAgdGhpcy50YXNrc1N1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLnRlc3RDYXNlc1N1YnNjcmlwdGlvbikge1xuICAgICAgICAgICAgdGhpcy50ZXN0Q2FzZXNTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy50aGVtZUNoYW5nZVN1YnNjcmlwdGlvbikge1xuICAgICAgICAgICAgdGhpcy50aGVtZUNoYW5nZVN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiQGlmICghaXNMb2FkaW5nKSB7XG4gICAgPGRpdiBjbGFzcz1cImluc3RydWN0aW9uc19fY29udGVudCBib3JkZXItMFwiPlxuICAgICAgICA8amhpLXByb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9ucy1zdGVwLXdpemFyZCBbZXhlcmNpc2VdPVwiZXhlcmNpc2VcIiBbbGF0ZXN0UmVzdWx0XT1cImxhdGVzdFJlc3VsdFwiIFt0YXNrc109XCJ0YXNrc1wiPjwvamhpLXByb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9ucy1zdGVwLXdpemFyZD5cbiAgICAgICAgPCEtLSBwcm9ibGVtIHN0YXRlbWVudCB1cGRhdGUgJiBkaWZmZXJlbmNlIGhpZ2hsaWdodGVyIC0tPlxuICAgICAgICBAaWYgKGV4ZXJjaXNlICYmIGV4ZXJjaXNlLmV4ZXJjaXNlR3JvdXApIHtcbiAgICAgICAgICAgIDxqaGktZXhhbS1leGVyY2lzZS11cGRhdGUtaGlnaGxpZ2h0ZXIgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCIgKHByb2JsZW1TdGF0ZW1lbnRVcGRhdGVFdmVudCk9XCJyZW5kZXJVcGRhdGVkUHJvYmxlbVN0YXRlbWVudCgpXCI+IDwvamhpLWV4YW0tZXhlcmNpc2UtdXBkYXRlLWhpZ2hsaWdodGVyPlxuICAgICAgICB9XG4gICAgICAgIDwhLS0gUmVuZGVyZWQgbWFya2Rvd24gd2lsbCBiZSBpbnNlcnRlZCBpbiB0aGlzIGRpdiAtLT5cbiAgICAgICAgPGRpdlxuICAgICAgICAgICAgaWQ9XCJwcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbnMtY29udGVudFwiXG4gICAgICAgICAgICBjbGFzcz1cImd1aWRlZC10b3VyIGluc3RydWN0aW9uc19fY29udGVudF9fbWFya2Rvd24gbWFya2Rvd24tcHJldmlld1wiXG4gICAgICAgICAgICBbaGlkZGVuXT1cIiFyZW5kZXJlZE1hcmtkb3duXCJcbiAgICAgICAgICAgIFtpbm5lckh0bWxdPVwicmVuZGVyZWRNYXJrZG93blwiXG4gICAgICAgID48L2Rpdj5cbiAgICA8L2Rpdj5cbn0gQGVsc2Uge1xuICAgIDxzcGFuIGlkPVwicHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rpb25zLWxvYWRpbmdcIiBjbGFzcz1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIG10LTJcIj48ZmEtaWNvbiBzaXplPVwibGdcIiBbaWNvbl09XCJmYVNwaW5uZXJcIiBbc3Bpbl09XCJ0cnVlXCI+PC9mYS1pY29uPjwvc3Bhbj5cbn1cbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNSZXN1bHRNb2R1bGUgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9yZXN1bHQvcmVzdWx0Lm1vZHVsZSc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3Rpb25Db21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9pbnN0cnVjdGlvbnMtcmVuZGVyL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0aW9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3Rpb25TdGVwV2l6YXJkQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvaW5zdHJ1Y3Rpb25zLXJlbmRlci9zdGVwLXdpemFyZC9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbi1zdGVwLXdpemFyZC5jb21wb25lbnQnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0aW9uVGFza1N0YXR1c0NvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2luc3RydWN0aW9ucy1yZW5kZXIvdGFzay9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdGlvbi10YXNrLXN0YXR1cy5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc01hcmtkb3duTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi5tb2R1bGUnO1xuaW1wb3J0IHsgRXhhbUV4ZXJjaXNlVXBkYXRlSGlnaGxpZ2h0ZXJNb2R1bGUgfSBmcm9tICdhcHAvZXhhbS9wYXJ0aWNpcGF0ZS9leGVyY2lzZXMvZXhhbS1leGVyY2lzZS11cGRhdGUtaGlnaGxpZ2h0ZXIvZXhhbS1leGVyY2lzZS11cGRhdGUtaGlnaGxpZ2h0ZXIubW9kdWxlJztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZSwgQXJ0ZW1pc1Jlc3VsdE1vZHVsZSwgQXJ0ZW1pc01hcmtkb3duTW9kdWxlLCBFeGFtRXhlcmNpc2VVcGRhdGVIaWdobGlnaHRlck1vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0aW9uQ29tcG9uZW50LCBQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3Rpb25TdGVwV2l6YXJkQ29tcG9uZW50LCBQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3Rpb25UYXNrU3RhdHVzQ29tcG9uZW50XSxcbiAgICBleHBvcnRzOiBbUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0aW9uQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc1Byb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdGlvbnNSZW5kZXJNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLFdBQVcsY0FBYyxPQUEwQixjQUFjO0FBSTFFLFNBQWUsZ0JBQWdCLHFCQUFxQjs7QUFKcEQsSUFXYTtBQVhiOztBQUVBO0FBQ0E7OztBQVFNLElBQU8seUNBQVAsTUFBTyx3Q0FBc0M7TUFXM0I7TUFWcEI7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLDZCQUE2QjtNQUNwQjtNQUVDLDhCQUFvRCxJQUFJLGFBQVk7TUFFOUUsWUFBb0IsMkJBQW9EO0FBQXBELGFBQUEsNEJBQUE7TUFBdUQ7TUFFM0UsV0FBUTtBQUNKLGFBQUssd0NBQXdDLEtBQUssMEJBQTBCLHFDQUFxQyxVQUFVLENBQUMsV0FBVTtBQUNsSSxlQUFLLG1DQUFtQyxPQUFPLFlBQVksT0FBTyxnQkFBZ0I7UUFDdEYsQ0FBQztNQUNMO01BRUEsY0FBVztBQUNQLGFBQUssdUNBQXVDLFlBQVc7QUFDdkQsYUFBSyxtQkFBbUIsWUFBVztNQUN2QztNQU1BLG9DQUFpQztBQUM3QixZQUFJLEtBQUssNEJBQTRCO0FBQ2pDLGVBQUssU0FBUyxtQkFBbUIsS0FBSztlQUNuQztBQUNILGVBQUssU0FBUyxtQkFBbUIsS0FBSzs7QUFFMUMsYUFBSyw2QkFBNkIsQ0FBQyxLQUFLO0FBQ3hDLGFBQUssNEJBQTRCLEtBQUssS0FBSyxTQUFTLGdCQUFnQjtNQUN4RTtNQVFBLG1DQUFtQyxZQUFvQix5QkFBK0I7QUFDbEYsWUFBSSwyQkFBMkIsVUFBYSxlQUFlLEtBQUssU0FBUyxJQUFJO0FBQ3pFLGVBQUssMEJBQTBCO0FBQy9CLGVBQUssU0FBUyxtQkFBbUIsS0FBSyxxQ0FBb0M7O0FBRTlFLGFBQUssNEJBQTRCLEtBQUssS0FBSyxTQUFTLGdCQUFnQjtNQUN4RTtNQUtBLHVDQUFvQztBQUNoQyxZQUFJLENBQUMsS0FBSyx5QkFBeUI7QUFDL0I7O0FBR0osYUFBSyw2QkFBNkI7QUFHbEMsY0FBTSxNQUFNLElBQUksZUFBYztBQUM5QixZQUFJO0FBR0osWUFBSSxDQUFDLEtBQUssZ0NBQWdDO0FBQ3RDLHFDQUEyQixLQUFLLFNBQVM7ZUFFdEM7QUFDSCxxQ0FBMkIsS0FBSzs7QUFHcEMsYUFBSyxpQ0FBaUMsS0FBSztBQUMzQyxZQUFJLGtCQUE0QixDQUFBO0FBQ2hDLFlBQUk7QUFDSixZQUFJLEtBQUssU0FBUyxTQUFTLGFBQWEsYUFBYTtBQUNqRCxnQkFBTSw0Q0FBNEMsS0FBSyw0Q0FBNEMsS0FBSyx1QkFBdUI7QUFDL0gsZ0JBQU0sNkNBQTZDLEtBQUssNENBQTRDLHdCQUF3QjtBQUM1SCxnQkFBTSx5Q0FBeUMsMENBQTBDO0FBQ3pGLGdCQUFNLDBDQUEwQywyQ0FBMkM7QUFDM0YsNEJBQWtCLDBDQUEwQztBQUM1RCxpQkFBTyxJQUFJLFVBQVUseUNBQTBDLHNDQUFzQztlQUNsRztBQUNILGlCQUFPLElBQUksVUFBVSwwQkFBMkIsS0FBSyx1QkFBdUI7O0FBR2hGLFlBQUksdUJBQXVCLElBQUk7QUFDL0IsYUFBSyxvREFBb0QsS0FBSyxlQUFlLElBQUk7QUFFakYsWUFBSSxLQUFLLFNBQVMsU0FBUyxhQUFhLGFBQWE7QUFDakQsZUFBSyxvREFBb0QsZUFBZTs7QUFFNUUsZUFBTyxLQUFLO01BQ2hCO01BRVEsb0RBQW9ELGlCQUF5QjtBQUNqRix3QkFBZ0IsUUFBUSxDQUFDLFNBQVE7QUFDN0IsZUFBSyxvREFBb0QsS0FBSyxrREFBa0QsUUFBUSxhQUFhLGdCQUFnQixPQUFPLElBQUk7UUFDcEssQ0FBQztNQUNMO01BRVEsNENBQTRDLGtCQUF3QjtBQUt4RSxjQUFNLHdCQUF3QjtBQUM5QixjQUFNLGtCQUE0QixDQUFBO0FBQ2xDLGNBQU0sMENBQTBDLGlCQUFpQixRQUFRLHVCQUF1QixDQUFDLE9BQU8sWUFBVztBQUMvRywwQkFBZ0IsS0FBSyxPQUFPO0FBRTVCLGlCQUFPO1FBQ1gsQ0FBQztBQUNELGVBQU87VUFDSDtVQUNBOztNQUVSO01BYVEsZUFBZSxPQUFhO0FBQ2hDLGNBQU0sT0FBYyxDQUFBO0FBQ3BCLGNBQU0sUUFBUSxDQUFDLE1BQVksVUFBaUI7QUFDeEMsZ0JBQU0sS0FBSyxNQUFNLEtBQUssRUFBRSxDQUFDO0FBQ3pCLGdCQUFNLE9BQU8sTUFBTSxLQUFLLEVBQUUsQ0FBQztBQUMzQixrQkFBUSxJQUFJO1lBQ1IsS0FBSyxjQUFjO0FBQ2YsbUJBQUssS0FBSyxJQUFJLCtCQUErQixPQUFPO0FBQ3BEO1lBQ0osS0FBSyxjQUFjO0FBQ2YsbUJBQUssS0FBSyxJQUFJLDRCQUE0QixPQUFPO0FBQ2pEO1lBQ0osS0FBSyxjQUFjO0FBQ2YsbUJBQUssS0FBSyxJQUFJO0FBQ2Q7O1FBRVosQ0FBQztBQUNELGVBQU8sS0FBSyxLQUFLLEVBQUU7TUFDdkI7O3lCQXRKUyx5Q0FBc0MsK0JBQUEseUJBQUEsQ0FBQTtNQUFBO2dFQUF0Qyx5Q0FBc0MsV0FBQSxDQUFBLENBQUEsc0NBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFdBQUEsR0FBQSxTQUFBLEVBQUEsNkJBQUEsOEJBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLE1BQUEsdUJBQUEsR0FBQSxPQUFBLFFBQUEsUUFBQSxRQUFBLFFBQUEsUUFBQSxHQUFBLFVBQUEsT0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGdEQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDWG5ELFVBQUEsNEJBQUEsR0FBQSxVQUFBLENBQUE7QUFBOEgsVUFBQSx3QkFBQSxTQUFBLFNBQUEsMEVBQUE7QUFBQSxtQkFBUyxJQUFBLGtDQUFBO1VBQW1DLENBQUE7QUFDdEssVUFBQSxvQkFBQSxDQUFBOzs7QUFHSixVQUFBLDBCQUFBO0FBQ0EsVUFBQSxvQkFBQSxHQUFBLElBQUE7OztBQUxzRSxVQUFBLHdCQUFBLFVBQUEsSUFBQSxtQ0FBQSxNQUFBO0FBQ2xFLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsZ0NBQUEsVUFBQSxJQUFBLDZCQUFBLHlCQUFBLEdBQUEsR0FBQSxnREFBQSxJQUFBLHlCQUFBLEdBQUEsR0FBQSxpREFBQSxHQUFBLElBQUE7Ozs7O29GRFVTLHdDQUFzQyxFQUFBLFdBQUEseUNBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFWG5ELFNBQVMsZ0JBQWdCOztBQUF6QixJQVNhO0FBVGI7O0FBQ0E7QUFDQTtBQU9NLElBQU8sc0NBQVAsTUFBTyxxQ0FBbUM7O3lCQUFuQyxzQ0FBbUM7TUFBQTtnRUFBbkMscUNBQW1DLENBQUE7b0VBSGxDLHlCQUF5QixFQUFBLENBQUE7Ozs7OztBQ052QyxTQUFTLGtCQUFrQjs7QUFBM0IsSUFRWSxlQWdCTixhQUNBLGdCQUdPO0FBNUJiOztBQUdBO0FBS0EsS0FBQSxTQUFZQSxnQkFBYTtBQUNyQixNQUFBQSxlQUFBLGNBQUEsSUFBQTtBQUNBLE1BQUFBLGVBQUEsU0FBQSxJQUFBO0FBQ0EsTUFBQUEsZUFBQSxNQUFBLElBQUE7QUFDQSxNQUFBQSxlQUFBLFdBQUEsSUFBQTtJQUNKLEdBTFksa0JBQUEsZ0JBQWEsQ0FBQSxFQUFBO0FBZ0J6QixJQUFNLGNBQWM7QUFDcEIsSUFBTSxpQkFBaUI7QUFHakIsSUFBTyx3Q0FBUCxNQUFPLHVDQUFxQztNQU92QyxvQkFBb0IsQ0FBQyxTQUFtQixpQkFBcUM7QUFDaEYsWUFBSSxjQUFjLGVBQWUsQ0FBQyxhQUFhLGFBQWEsQ0FBQyxhQUFhLFVBQVUsV0FBVyxTQUFTO0FBRXBHLGlCQUFPLEVBQUUsZUFBZSxjQUFjLFNBQVMsVUFBVSxFQUFFLGlCQUFpQixTQUFTLGFBQWEsQ0FBQSxHQUFJLGtCQUFrQixDQUFBLEVBQUUsRUFBRTs7QUFHaEksWUFBSSxjQUFjLFdBQVcsUUFBUTtBQUVqQyxnQkFBTSxFQUFFLFFBQVEsYUFBYSxXQUFVLElBQUssS0FBSyxjQUFjLFNBQVMsWUFBWTtBQUVwRixjQUFJO0FBQ0osY0FBSSxPQUFPLFNBQVMsR0FBRztBQUNuQiw0QkFBZ0IsY0FBYztxQkFDdkIsWUFBWSxTQUFTLEtBQUssUUFBUSxXQUFXLEdBQUc7QUFDdkQsNEJBQWdCLGNBQWM7aUJBQzNCO0FBQ0gsNEJBQWdCLGNBQWM7O0FBRWxDLGlCQUFPLEVBQUUsZUFBZSxVQUFVLEVBQUUsaUJBQWlCLFlBQVksYUFBYSxRQUFRLGtCQUFrQixZQUFXLEVBQUU7ZUFDbEg7QUFFSCxpQkFBTyxFQUFFLGVBQWUsY0FBYyxXQUFXLFVBQVUsRUFBRSxpQkFBaUIsQ0FBQSxHQUFJLGFBQWEsQ0FBQSxHQUFJLGtCQUFrQixRQUFPLEVBQUU7O01BRXRJO01BRVEsY0FBYyxPQUFpQixjQUFvQjtBQUN2RCxlQUFPLE1BQU0sT0FDVCxDQUFDLEtBQUssV0FBVTtBQUNaLGdCQUFNLFdBQVcsY0FBYyxXQUFXLEtBQUssQ0FBQ0MsY0FBYUEsVUFBUyxVQUFVLE9BQU8sTUFBTTtBQUM3RixnQkFBTSxpQkFBaUIsZUFBZSxZQUFhO0FBR25ELGNBQUksZ0JBQWdCO0FBQ2hCLG1CQUFPO2NBQ0gsUUFBUSxXQUFXLENBQUMsR0FBRyxJQUFJLFFBQVEsTUFBTSxJQUFJLElBQUk7Y0FDakQsWUFBWSxXQUFXLElBQUksYUFBYSxDQUFDLEdBQUcsSUFBSSxZQUFZLE1BQU07Y0FDbEUsYUFBYSxJQUFJOzs7QUFJekIsaUJBQU87WUFDSCxRQUFRLFVBQVUsYUFBYSxRQUFRLENBQUMsR0FBRyxJQUFJLFFBQVEsTUFBTSxJQUFJLElBQUk7WUFDckUsWUFBWSxVQUFVLGFBQWEsT0FBTyxDQUFDLEdBQUcsSUFBSSxZQUFZLE1BQU0sSUFBSSxJQUFJO1lBQzVFLGFBQWEsVUFBVSxhQUFhLFNBQVksQ0FBQyxHQUFHLElBQUksYUFBYSxNQUFNLElBQUksSUFBSTs7UUFFM0YsR0FDQSxFQUFFLFFBQVEsQ0FBQSxHQUFJLFlBQVksQ0FBQSxHQUFJLGFBQWEsQ0FBQSxFQUFFLENBQUU7TUFFdkQ7TUFFTyxxQkFBcUIsVUFBa0IsV0FBb0Q7QUFJOUYsZUFBTyxTQUNGLE1BQU0sY0FBYyxFQUNwQixJQUFJLENBQUMsU0FBUyxLQUFLLEtBQUksQ0FBRSxFQUN6QixJQUFJLENBQUMsU0FBUTtBQUVWLGlCQUFPLEtBQUssb0NBQW9DLE1BQU0sU0FBUyxLQUFLO1FBQ3hFLENBQUM7TUFDVDtNQUVPLG9DQUFvQyxNQUFjLFdBQXlDO0FBRTlGLGNBQU0sUUFBUSxZQUFZLEtBQUssSUFBSTtBQUNuQyxZQUFJLE9BQU87QUFFUCxpQkFBTyxTQUFTLE1BQU0sQ0FBQyxDQUFDOztBQUc1QixlQUFPLFdBQVcsS0FBSyxDQUFDLGFBQWEsU0FBUyxhQUFhLElBQUksR0FBRztNQUN0RTs7eUJBL0VTLHdDQUFxQztNQUFBO29FQUFyQyx3Q0FBcUMsU0FBckMsdUNBQXFDLFdBQUEsWUFEeEIsT0FBTSxDQUFBOzs7Ozs7QUMzQmhDLFNBQVMsYUFBQUMsWUFBVyxTQUFBQyxjQUFhO0FBQ2pDLFNBQVMsZUFBZSxxQkFBcUI7QUFDN0MsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxnQkFBZ0I7Ozs7OztBQ0RqQixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQURhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLGNBQUE7Ozs7O0FBR1QsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7QUFEYSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxjQUFBOzs7OztBQUdULElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsZ0JBQUE7Ozs7O0FBR1QsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQXdCLElBQUEscUJBQUEsQ0FBQTtBQUFjLElBQUEsMkJBQUE7QUFDMUMsSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7QUFENEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxPQUFBLFFBQUE7Ozs7OztBQUd4QixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFJSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSxpR0FBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsT0FBQSxvQkFBQSxDQUFxQjtJQUFBLENBQUE7O0FBQ2pDLElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQUpRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsT0FBQSxXQUFBLE9BQUEsT0FBQSxPQUFBLFFBQUEsWUFBQSxPQUFBLGdCQUFBLFNBQUEsaUJBQUEsT0FBQSxZQUFBLFNBQUEsZ0JBQUEsZ0JBQUE7QUFDQSxJQUFBLHlCQUFBLGFBQUEsMEJBQUEsR0FBQSxHQUFBLE9BQUEsc0JBQUEscUJBQUEsOEJBQUEsR0FBQSxLQUFBLE9BQUEsUUFBQSxRQUFBLE9BQUEsZ0JBQUEsTUFBQSxDQUFBLEdBQUEsNEJBQUE7Ozs7O0FBSUosSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxDQUFBOztBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBRGlDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSwwQkFBQSxHQUFBLEdBQUEsT0FBQSx1QkFBQSxPQUFBLFFBQUEsU0FBQSxhQUFBLFVBQUEsR0FBQSw0QkFBQTs7O0FEckJyQyxTQWNhO0FBZGI7O0FBSUE7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFPTSxJQUFPLG9EQUFQLE1BQU8sbURBQWlEO01Ba0M5QztNQUNBO01BbENaLGdCQUFnQjtNQUNoQixzQkFBc0I7TUFFYjtNQUtULElBQ0ksVUFBTztBQUNQLGVBQU8sS0FBSztNQUNoQjtNQUNTO01BQ0E7TUFFVDtNQUNBO01BS0E7TUFDQTtNQUNBO01BRUE7TUFHQSxtQkFBbUI7TUFDbkIsaUJBQWlCO01BQ2pCLGlCQUFpQjtNQUVqQixZQUNZLHVDQUNBLGNBQXNCO0FBRHRCLGFBQUEsd0NBQUE7QUFDQSxhQUFBLGVBQUE7TUFDVDtNQUVILElBQUksUUFBUSxTQUFpQjtBQUN6QixhQUFLLGVBQWU7QUFDcEIsY0FBTSxFQUNGLGVBQ0EsVUFBVSxFQUFFLGlCQUFpQixrQkFBa0IsWUFBVyxFQUFFLElBQzVELEtBQUssc0NBQXNDLGtCQUFrQixLQUFLLFNBQVMsS0FBSyxZQUFZO0FBQ2hHLGFBQUssZ0JBQWdCO0FBQ3JCLGFBQUssa0JBQWtCO0FBQ3ZCLGFBQUssbUJBQW1CO0FBQ3hCLGFBQUssY0FBYztBQUNuQixhQUFLLGFBQWEsS0FBSyxlQUFlLE9BQU87TUFDakQ7TUFNUSxlQUFlLFNBQWlCO0FBQ3BDLFlBQUksQ0FBQyxLQUFLLGNBQWMsV0FBVztBQUMvQixpQkFBTzs7QUFFWCxjQUFNLFlBQVksS0FBSyxhQUFhO0FBQ3BDLGVBQU8sUUFBUSxLQUFLLENBQUMsV0FBbUIsVUFBVSxLQUFLLENBQUMsYUFBYSxTQUFTLFVBQVUsT0FBTyxVQUFVLFNBQVMsVUFBVSxDQUFDO01BQ2pJO01BS08sc0JBQW1CO0FBQ3RCLFlBQUksQ0FBQyxLQUFLLGNBQWM7QUFDcEI7O0FBRUosY0FBTSxXQUFXLEtBQUssYUFBYSxLQUFLLG1CQUFtQixFQUFFLFVBQVUsTUFBTSxNQUFNLEtBQUksQ0FBRTtBQUN6RixjQUFNLG9CQUFvQixTQUFTO0FBQ25DLDBCQUFrQixXQUFXLEtBQUs7QUFDbEMsMEJBQWtCLFNBQVMsS0FBSztBQUNoQywwQkFBa0IsaUJBQWlCLEtBQUs7QUFDeEMsMEJBQWtCLGVBQWUsYUFBYTtBQUM5QywwQkFBa0IsV0FBVyxLQUFLO0FBQ2xDLDBCQUFrQiwyQkFBMkIsS0FBSyxpQkFBaUI7TUFDdkU7O3lCQTlFUyxvREFBaUQsZ0NBQUEscUNBQUEsR0FBQSxnQ0FBQSxXQUFBLENBQUE7TUFBQTtpRUFBakQsb0RBQWlELFdBQUEsQ0FBQSxDQUFBLG1EQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLFNBQUEsV0FBQSxVQUFBLFlBQUEsY0FBQSxlQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxHQUFBLGFBQUEsZ0JBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxRQUFBLE1BQUEsR0FBQSxhQUFBLGVBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxRQUFBLE1BQUEsR0FBQSxhQUFBLGtCQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsdUJBQUEsR0FBQSxhQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxXQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsMkRBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNkOUQsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLDBFQUFBLEdBQUEsQ0FBQSxFQUVDLEdBQUEsMEVBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSwwRUFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLDBFQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsMEVBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSwwRUFBQSxHQUFBLENBQUE7QUFxQkwsVUFBQSxxQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLElBQUE7OztBQXpCeUIsVUFBQSwwQkFBQSxXQUFBLElBQUEsa0JBQUEsSUFBQSxjQUFBLE9BQUEsRUFBeUQsVUFBQSxJQUFBLGtCQUFBLElBQUEsY0FBQSxJQUFBO0FBQzlFLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLGtCQUFBLElBQUEsY0FBQSxVQUFBLElBQUEsRUFBQTtBQUdBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLGtCQUFBLElBQUEsY0FBQSxPQUFBLElBQUEsRUFBQTtBQUdBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLGtCQUFBLElBQUEsY0FBQSxhQUFBLElBQUEsa0JBQUEsSUFBQSxjQUFBLGVBQUEsSUFBQSxFQUFBO0FBR0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsV0FBQSxJQUFBLEVBQUE7QUFHQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxnQkFBQSxJQUFBLGFBQUEsYUFBQSxJQUFBLGFBQUEsVUFBQSxVQUFBLElBQUEsUUFBQSxTQUFBLElBQUEsQ0FBQTs7Ozs7cUZEQ1MsbURBQWlELEVBQUEsV0FBQSxvREFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVkOUQsU0FBMEIsY0FBQUMsYUFBWSxnQkFBa0M7QUFVeEUsU0FBcUIsZUFBZTs7QUFWcEMsSUF3Qk0sV0FHTztBQTNCYjs7QUFLQTtBQUNBO0FBR0E7O0FBZUEsSUFBTSxZQUFZO0FBR1osSUFBTywwQ0FBUCxNQUFPLHlDQUF1QztNQWVwQztNQUNBO01BZFo7TUFFUTtNQUNBO01BQ0E7TUFFQSxzQkFBc0IsSUFBSSxRQUFPO01BQ2pDLGlDQUFpQyxJQUFJLFFBQU87TUFHNUMsWUFBWTtNQUVwQixZQUNZLHVDQUNBLFVBQWtCO0FBRGxCLGFBQUEsd0NBQUE7QUFDQSxhQUFBLFdBQUE7TUFDVDtNQU1JLGdCQUFnQixRQUEwQjtBQUM3QyxhQUFLLGVBQWU7TUFDeEI7TUFPTyxZQUFZLFVBQWtCO0FBQ2pDLGFBQUssV0FBVztNQUNwQjtNQUVPLGFBQWEsV0FBeUM7QUFDekQsYUFBSyxZQUFZO01BQ3JCO01BS08sZ0NBQTZCO0FBQ2hDLGVBQU8sS0FBSyxvQkFBb0IsYUFBWTtNQUNoRDtNQUtPLHNDQUFtQztBQUN0QyxlQUFPLEtBQUssK0JBQStCLGFBQVk7TUFDM0Q7TUFNUSxjQUFjLENBQUMsVUFBb0I7QUFDdkMsY0FBTSxRQUFRLENBQUMsRUFBRSxJQUFJLFVBQVUsUUFBTyxNQUFNO0FBQ3hDLGdCQUFNLHFCQUFxQixTQUFTLHVCQUF1QixXQUFXLEVBQUUsRUFBRTtBQUcxRSxtQkFBUyxJQUFJLEdBQUcsSUFBSSxtQkFBbUIsUUFBUSxLQUFLO0FBR2hELGtCQUFNLGVBQWUsS0FBSyxpQkFBaUIsZ0JBQWdCLG1EQUFtRCxFQUFFLFVBQVUsS0FBSyxTQUFRLENBQUU7QUFDekkseUJBQWEsU0FBUyxXQUFXLEtBQUs7QUFDdEMseUJBQWEsU0FBUyxXQUFXO0FBQ2pDLHlCQUFhLFNBQVMsZUFBZSxLQUFLO0FBQzFDLHlCQUFhLFNBQVMsVUFBVTtBQUVoQyx5QkFBYSxrQkFBa0IsY0FBYTtBQUM1QyxrQkFBTSxVQUFXLGFBQWEsU0FBa0MsVUFBVSxDQUFDO0FBQzNFLGtCQUFNLG9CQUFvQixtQkFBbUIsQ0FBQztBQUM5Qyw4QkFBa0IsZ0JBQWdCLE9BQU87O1FBRWpELENBQUM7TUFDTDtNQVFBLGVBQVk7QUFDUixjQUFNLFlBQStCO1VBQ2pDLE1BQU07VUFDTixRQUFRLENBQUMscUJBQTRCO0FBQ2pDLGtCQUFNLFFBQVEsTUFBTSxLQUFLLGlCQUFpQixTQUFTLFNBQVMsQ0FBQztBQUM3RCxnQkFBSSxPQUFPO0FBQ1AscUJBQU8sS0FBSyxZQUFZLGtCQUFrQixLQUFLOztBQUVuRCxtQkFBTztVQUNYOztBQUVKLGVBQU87TUFDWDtNQUVRLFlBQVksa0JBQTBCLE9BQXlCO0FBQ25FLGNBQU0sZUFBMEIsTUFFM0IsT0FBTyxDQUFDLGNBQWMsV0FBVyxXQUFXLENBQUMsRUFDN0MsSUFBSSxDQUFDLGNBQXNDO0FBQ3hDLGdCQUFNLFlBQVksS0FBSztBQUN2QixlQUFLO0FBQ0wsaUJBQU87WUFDSCxJQUFJO1lBQ0osZ0JBQWdCLFVBQVcsQ0FBQztZQUM1QixVQUFVLFVBQVcsQ0FBQztZQUN0QixTQUFTLFVBQVcsQ0FBQyxJQUFJLEtBQUssc0NBQXNDLHFCQUFxQixVQUFXLENBQUMsR0FBRyxLQUFLLFNBQVMsSUFBSSxDQUFBOztRQUVsSSxDQUFDO0FBQ0wsY0FBTSwyQkFBa0Q7VUFDcEQsWUFBWSxLQUFLLFNBQVM7VUFDMUIsT0FBTzs7QUFFWCxhQUFLLG9CQUFvQixLQUFLLHdCQUF3QjtBQUV0RCxhQUFLLCtCQUErQixLQUFLLE1BQUs7QUFDMUMsZUFBSyxZQUFZLFlBQVk7UUFDakMsQ0FBQztBQUNELGVBQU8sYUFBYSxPQUNoQixDQUFDLEtBQWEsRUFBRSxnQkFBZ0IsTUFBTSxHQUFFLE1BSXBDLElBQUksUUFBUSxJQUFJLE9BQU8sMEJBQTBCLElBQUksR0FBRyxHQUFHLEdBQUcsdUJBQXVCLEdBQUcsU0FBUSxDQUFFLHdCQUF3QixHQUM5SCxnQkFBZ0I7TUFFeEI7O3lCQW5JUywwQ0FBdUMsdUJBQUEscUNBQUEsR0FBQSx1QkFBQSxZQUFBLENBQUE7TUFBQTtvRUFBdkMsMENBQXVDLFNBQXZDLHlDQUF1QyxXQUFBLFlBRDFCLE9BQU0sQ0FBQTs7Ozs7OztBQzFCaEMsU0FBUyxjQUFBQyxtQkFBa0I7QUFDM0IsU0FBUyxZQUFnQyxrQkFBa0I7QUFDM0QsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxZQUFZLFdBQUFDLGdCQUFlO0FBQ3BDLFNBQVMsS0FBSyxXQUFXOzs7SUFHbkIscUJBR08sb0NBc0VBOzs7QUEzRWI7O0FBRUEsSUFBTSxzQkFBc0IsSUFBSUEsU0FBTztBQUdqQyxJQUFPLHFDQUFQLE1BQU8sb0NBQWtDO01BUy9CO01BQ0E7TUFUSixjQUFjO01BQ2Q7TUFNUixZQUNZLE1BQ0EsY0FBMEI7QUFEMUIsYUFBQSxPQUFBO0FBQ0EsYUFBQSxlQUFBO0FBRVIsYUFBSyxVQUFVLElBQUkscUJBQW9CO0FBQ3ZDLGFBQUssYUFDQSwwQkFBeUIsRUFDekIsS0FBSyxJQUFJLE1BQU0sb0JBQW9CLEtBQUksQ0FBRSxDQUFDLEVBQzFDLFVBQVM7TUFDbEI7TUFlQSxpQkFBaUIsVUFBZ0I7QUFDN0IsZUFBTyxLQUFLLEtBQ1AsSUFBSSxHQUFHLEtBQUssV0FBVyxRQUFRO1VBQzVCLFFBQVEsSUFBSSxXQUFXLEVBQUUsU0FBUyxLQUFLLFFBQU8sQ0FBRSxFQUFFLElBQUksWUFBWSxRQUFRLEVBQUUsSUFBSSxnQkFBZ0IsS0FBSyxhQUFhLGdCQUFlLE1BQU8sTUFBTSxJQUFJO1VBQ2xKLGNBQWM7U0FDakIsRUFDQSxLQUFLLElBQUksQ0FBQyxRQUFRLEtBQUssZ0NBQWdDLEdBQUcsQ0FBQyxDQUFDO01BQ3JFO01BZUEsZUFBZSxVQUFnQjtBQUMzQixlQUFPLEtBQUssS0FBSyxJQUFJLEdBQUcsS0FBSyxXQUFXLFFBQVE7VUFDNUMsUUFBUSxJQUFJLFdBQVcsRUFBRSxTQUFTLEtBQUssUUFBTyxDQUFFLEVBQUUsSUFBSSxZQUFZLFFBQVEsRUFBRSxJQUFJLGdCQUFnQixLQUFLLGFBQWEsZ0JBQWUsTUFBTyxNQUFNLElBQUk7VUFDbEosY0FBYztTQUNqQjtNQUNMO01BRVEsZ0NBQWdDLEtBQVE7QUFDNUMsZUFBTyxPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUUsU0FBUyxRQUFRO01BQ3ZEOzt5QkEvRFMscUNBQWtDLHVCQUFBLGFBQUEsR0FBQSx1QkFBQSxZQUFBLENBQUE7TUFBQTtvRUFBbEMscUNBQWtDLFNBQWxDLG9DQUFrQyxXQUFBLFlBRHJCLE9BQU0sQ0FBQTs7QUFpQzVCLGVBQUE7TUFQQyxVQUFVO1FBRVAsZUFBZTtRQUNmLFFBQVE7UUFDUixtQkFBbUI7UUFDbkIscUJBQXFCO09BQ3hCOzs7OztBQXVCRCxlQUFBO01BUEMsVUFBVTtRQUVQLGVBQWU7UUFDZixRQUFRO1FBQ1IsbUJBQW1CO1FBQ25CLHFCQUFxQjtPQUN4Qjs7O3NDQUNpQyxVQUFVOztBQWdCMUMsSUFBTyx1QkFBUCxNQUEyQjtNQUs3QixVQUFVLEdBQVM7QUFDZixlQUFPLG1CQUFtQixDQUFDO01BQy9CO01BTUEsWUFBWSxHQUFTO0FBQ2pCLGVBQU8sbUJBQW1CLENBQUM7TUFDL0I7TUFNQSxVQUFVLEdBQVM7QUFDZixlQUFPLG1CQUFtQixDQUFDO01BQy9CO01BTUEsWUFBWSxHQUFTO0FBQ2pCLGVBQU8sbUJBQW1CLENBQUM7TUFDL0I7Ozs7OztBQy9HSixTQUFTLGNBQUFDLG1CQUFrQjtBQUUzQixTQUFTLFdBQUFDLGdCQUFlO0FBQ3hCLFNBQVMsT0FBQUMsWUFBVztBQU9wQixPQUFPLGVBQWU7O0FBVnRCLElBYU0saUJBR087QUFoQmI7O0FBSUE7QUFDQTtBQUNBOzs7QUFPQSxJQUFNLGtCQUFrQjtBQUdsQixJQUFPLDhDQUFQLE1BQU8sNkNBQTJDO01BU3hDO01BQ0E7TUFUSjtNQUNBO01BQ0EsaUNBQWlDLElBQUlELFNBQU87TUFHNUMsZ0JBQWdCO01BRXhCLFlBQ1ksdUNBQ0EsaUJBQW1EO0FBRG5ELGFBQUEsd0NBQUE7QUFDQSxhQUFBLGtCQUFBO01BQ1Q7TUFNSSxnQkFBZ0IsUUFBZTtBQUNsQyxhQUFLLGVBQWU7TUFDeEI7TUFFTyxhQUFhLFdBQXlDO0FBQ3pELGFBQUssWUFBWTtNQUNyQjtNQUtBLHNDQUFtQztBQUMvQixlQUFPLEtBQUssK0JBQStCLGFBQVk7TUFDM0Q7TUFPUSxzQkFBc0IsVUFBa0IsT0FBYTtBQUN6RCxhQUFLLGdCQUNBLGVBQWUsUUFBUSxFQUN2QixLQUNHQyxLQUFJLENBQUMsZ0JBQXVCO0FBQ3hCLGdCQUFNLHdCQUF3QixTQUFTLGVBQWUsWUFBWSxLQUFLLEVBQUU7QUFDekUsY0FBSSx1QkFBdUI7QUFFdkIsa0NBQXNCLFlBQVksVUFBVSxTQUFTLFdBQVc7O1FBRXhFLENBQUMsQ0FBQyxFQUVMLFVBQVM7TUFDbEI7TUFZQSxlQUFZO0FBQ1IsY0FBTSxZQUErQjtVQUNqQyxNQUFNO1VBQ04sUUFBUSxDQUFDLFNBQWdCO0FBQ3JCLGtCQUFNLGdCQUFnQjtBQUV0QixrQkFBTSxnQkFBZ0I7QUFFdEIsa0JBQU0sb0JBQW9CLGtDQUFrQyxhQUFhO0FBRXpFLGtCQUFNLFlBQVksS0FBSyxNQUFNLGFBQWEsS0FBSyxDQUFBO0FBRS9DLGtCQUFNLG1CQUFtQixVQUFVLElBQUksQ0FBQyxhQUFZO0FBQ2hELG9CQUFNLFlBQVksS0FBSztBQUV2QixtQkFBSztBQUNMLHFCQUFPLEVBQUUsWUFBWSxXQUFXLFNBQVE7WUFDNUMsQ0FBQztBQUdELGtCQUFNLGVBQWUsaUJBQWlCLE9BQU8sQ0FBQyxLQUFhLGVBQWdFO0FBQ3ZILHFCQUFPLElBQUksUUFBUSxJQUFJLE9BQU8sMEJBQTBCLFdBQVcsUUFBUSxHQUFHLEdBQUcsR0FBRyxrQkFBa0IsUUFBUSxlQUFlLFdBQVcsV0FBVyxTQUFRLENBQUUsQ0FBQztZQUNsSyxHQUFHLElBQUk7QUFHUCxrQkFBTSxxQkFBcUIsaUJBQWlCLElBQUksQ0FBQyxvQkFBNkQ7QUFDMUcsOEJBQWdCLFdBQVcsZ0JBQWdCLFNBQVMsUUFBUSxpQkFBaUIsQ0FBQyxPQUFZLFlBQW1CO0FBQ3pHLHNCQUFNLFFBQVEsS0FBSyxzQ0FBc0MscUJBQXFCLFNBQVMsS0FBSyxTQUFTO0FBQ3JHLHNCQUFNLEVBQUUsY0FBYSxJQUFLLEtBQUssc0NBQXNDLGtCQUFrQixPQUFPLEtBQUssWUFBWTtBQUMvRyx3QkFBUSxlQUFlO2tCQUNuQixLQUFLLGNBQWM7QUFDZiwyQkFBTztrQkFDWCxLQUFLLGNBQWM7QUFDZiwyQkFBTztrQkFDWDtBQUNJLDJCQUFPOztjQUVuQixDQUFDO0FBQ0QscUJBQU87WUFDWCxDQUFDO0FBRUQsaUJBQUssK0JBQStCLEtBQUssTUFBSztBQUMxQyxpQ0FBbUIsUUFBUSxDQUFDLG9CQUE2RDtBQUNyRixxQkFBSyxzQkFBc0IsZ0JBQWdCLFVBQVUsZ0JBQWdCLFVBQVU7Y0FDbkYsQ0FBQztZQUNMLENBQUM7QUFDRCxtQkFBTztVQUNYOztBQUVKLGVBQU87TUFDWDs7eUJBaEhTLDhDQUEyQyx1QkFBQSxxQ0FBQSxHQUFBLHVCQUFBLGtDQUFBLENBQUE7TUFBQTtvRUFBM0MsOENBQTJDLFNBQTNDLDZDQUEyQyxXQUFBLFlBRDlCLE9BQU0sQ0FBQTs7Ozs7O0FDZmhDLFNBQVMsYUFBQUMsWUFBVyxTQUFBQyxjQUF1QztBQUMzRCxTQUFTLFlBQUFDLGlCQUFnQjtBQU16QixTQUFTLFNBQVMsWUFBWSxlQUFlOzs7Ozs7QUNZakIsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQURhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLE9BQUE7Ozs7O0FBR1QsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQURhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLE9BQUE7Ozs7O0FBR1QsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQURhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLFVBQUE7Ozs7OztBQWxCckIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFPSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSx5RkFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLFlBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFTLDBCQUFBLE9BQUEsb0JBQUEsUUFBQSxTQUFBLFFBQUEsS0FBQSxDQUE2QztJQUFBLENBQUE7QUFFdEQsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLGlGQUFBLEdBQUEsQ0FBQSxFQUVDLEdBQUEsaUZBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSxpRkFBQSxHQUFBLENBQUE7QUFPTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTs7Ozs7QUFqQlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSw0QkFBQSxRQUFBLFNBQUEsT0FBQSxjQUFBLE9BQUEsRUFBc0UsMkJBQUEsUUFBQSxTQUFBLE9BQUEsY0FBQSxJQUFBLEVBQUEsaUNBQUEsUUFBQSxTQUFBLE9BQUEsY0FBQSxZQUFBLEVBQUEsOEJBQUEsUUFBQSxTQUFBLE9BQUEsY0FBQSxTQUFBO0FBRnRFLElBQUEseUJBQUEsY0FBQSxRQUFBLEtBQUE7QUFRQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxTQUFBLE9BQUEsY0FBQSxVQUFBLElBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLFNBQUEsT0FBQSxjQUFBLE9BQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsU0FBQSxPQUFBLGNBQUEsZ0JBQUEsUUFBQSxTQUFBLE9BQUEsY0FBQSxZQUFBLElBQUEsRUFBQTs7O0FEeEJ4QixJQWNhO0FBZGI7O0FBRUE7QUFFQTtBQUNBO0FBQ0E7OztBQVFNLElBQU8sb0RBQVAsTUFBTyxtREFBaUQ7TUFlOUM7TUFDQTtNQWZaLGdCQUFnQjtNQUVQO01BQ0E7TUFDQTtNQUVUO01BR0EsVUFBVTtNQUNWLFVBQVU7TUFDVixhQUFhO01BRWIsWUFDWSxjQUNBLG9CQUF5RDtBQUR6RCxhQUFBLGVBQUE7QUFDQSxhQUFBLHFCQUFBO01BQ1Q7TUFNSCxZQUFZLFNBQXNCO0FBQzlCLFlBQUssUUFBUSxTQUFTLEtBQUssU0FBVyxLQUFLLFNBQVMsUUFBUSxjQUFlO0FBQ3ZFLGVBQUssUUFBUSxLQUFLLE1BQU0sSUFBSSxDQUFDLEVBQUUsVUFBVSxRQUFPLE9BQVE7WUFDcEQsTUFBTSxLQUFLLG1CQUFtQixrQkFBa0IsU0FBUyxLQUFLLFlBQVksRUFBRTtZQUM1RSxPQUFPO1lBQ1A7WUFDRjs7TUFFVjtNQU9PLG9CQUFvQixPQUFpQixVQUFnQjtBQUN4RCxZQUFJLENBQUMsS0FBSyxnQkFBZ0IsQ0FBQyxNQUFNLFFBQVE7QUFDckM7O0FBRUosY0FBTSxFQUNGLFVBQVUsRUFBRSxpQkFBZ0IsRUFBRSxJQUM5QixLQUFLLG1CQUFtQixrQkFBa0IsT0FBTyxLQUFLLFlBQVk7QUFDdEUsY0FBTSxXQUFXLEtBQUssYUFBYSxLQUFLLG1CQUFtQixFQUFFLFVBQVUsTUFBTSxNQUFNLEtBQUksQ0FBRTtBQUN6RixjQUFNLG9CQUFvQixTQUFTO0FBQ25DLDBCQUFrQixXQUFXLEtBQUs7QUFDbEMsMEJBQWtCLFNBQVMsS0FBSztBQUNoQywwQkFBa0IsaUJBQWlCO0FBQ25DLDBCQUFrQixlQUFlLGFBQWE7QUFDOUMsMEJBQWtCLFdBQVc7QUFDN0IsMEJBQWtCLDJCQUEyQixpQkFBaUI7TUFDbEU7O3lCQXJEUyxvREFBaUQsZ0NBQUEsWUFBQSxHQUFBLGdDQUFBLHFDQUFBLENBQUE7TUFBQTtpRUFBakQsb0RBQWlELFdBQUEsQ0FBQSxDQUFBLG1EQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLGNBQUEsZ0JBQUEsT0FBQSxRQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLHNCQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsY0FBQSxHQUFBLGNBQUEsT0FBQSxHQUFBLENBQUEsUUFBQSxNQUFBLEdBQUEsZ0JBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxRQUFBLE1BQUEsR0FBQSxlQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsUUFBQSxNQUFBLEdBQUEsWUFBQSxHQUFBLE1BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSwyREFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ2Q5RCxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxDQUFBOztBQUNKLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLCtCQUFBLElBQUEsbUVBQUEsSUFBQSxJQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQXdCSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQWpDZ0MsVUFBQSx5QkFBQSxVQUFBLEVBQUEsSUFBQSxTQUFBLE9BQUEsT0FBQSxJQUFBLE1BQUEsT0FBQTtBQUdwQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLGtCQUFBLDBCQUFBLEdBQUEsR0FBQSxpRUFBQSxHQUFBLFlBQUE7QUFHQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsS0FBQTs7Ozs7cUZEUUMsbURBQWlELEVBQUEsV0FBQSxvREFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVkOUQsU0FBUyxhQUFBQyxZQUFXLGdCQUFBQyxlQUFjLFNBQUFDLFFBQXFDLFVBQUFDLFNBQXVCLHdCQUF3QjtBQU10SCxTQUFTLFlBQVksUUFBUSxPQUFBQyxNQUFLLFVBQVUsV0FBVyxPQUFBQyxZQUFXO0FBQ2xFLFNBQVMsY0FBQUMsYUFBMEIsT0FBTyxVQUFVO0FBZXBELFNBQVMsaUJBQWlCOzs7Ozs7QUNqQmQsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLHdDQUFBLENBQUE7QUFBNEQsSUFBQSx5QkFBQSwrQkFBQSxTQUFBLDJKQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUErQiwwQkFBQSxPQUFBLDhCQUFBLENBQStCO0lBQUEsQ0FBQTtBQUFHLElBQUEscUJBQUEsR0FBQSxHQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNqSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTs7OztBQUQwQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsT0FBQSxRQUFBOzs7OztBQUo5QyxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxxREFBQSxDQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSw4RUFBQSxHQUFBLENBQUE7QUFJQSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxPQUFBLENBQUE7QUFNSixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsSUFBQTs7OztBQWIyRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsT0FBQSxRQUFBLEVBQXFCLGdCQUFBLE9BQUEsWUFBQSxFQUFBLFNBQUEsT0FBQSxLQUFBO0FBRXhFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLFlBQUEsT0FBQSxTQUFBLGdCQUFBLElBQUEsRUFBQTtBQU9JLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsVUFBQSxDQUFBLE9BQUEsZ0JBQUEsRUFBNEIsYUFBQSxPQUFBLGtCQUFBLDRCQUFBOzs7OztBQUtwQyxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFBZ0csSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUE4RCxJQUFBLDJCQUFBO0FBQ2xLLElBQUEscUJBQUEsR0FBQSxJQUFBOzs7O0FBRHVILElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLFNBQUEsRUFBa0IsUUFBQSxJQUFBOzs7QURoQnpJLElBOEJhO0FBOUJiOztBQUVBO0FBRUE7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7Ozs7Ozs7Ozs7OztBQU9NLElBQU8sMENBQVAsTUFBTyx5Q0FBdUM7TUE2Q3JDO01BQ0M7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQXBESTtNQUNBO01BQ1A7TUFDQTtNQUdGLDRCQUE0QixJQUFJTCxjQUFZO01BRTVDO01BQ0E7TUFDQztNQUVELFlBQVk7TUFDWjtNQUNBO01BRVAsSUFBSSxlQUFZO0FBQ1osZUFBTyxLQUFLO01BQ2hCO01BRUEsSUFBSSxhQUFhLFFBQTBCO0FBQ3ZDLGFBQUssb0JBQW9CO0FBQ3pCLGFBQUssK0JBQStCLFlBQVksS0FBSyxRQUFRO0FBQzdELGFBQUssK0JBQStCLGdCQUFnQixLQUFLLFlBQVk7QUFDckUsYUFBSyxtQ0FBbUMsZ0JBQWdCLEtBQUssWUFBWTtBQUN6RSxhQUFLLCtCQUErQixhQUFhLEtBQUssU0FBUztBQUMvRCxhQUFLLG1DQUFtQyxhQUFhLEtBQUssU0FBUztNQUN2RTtNQUVPO01BQ0E7TUFDQyx3Q0FBMkQsQ0FBQTtNQUVuRTtNQUNRO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFHUixZQUFZO01BRVosWUFDVyxrQkFDQyxlQUNBLHVCQUNBLCtCQUNBLGlCQUNBLGdDQUNBLG9DQUNBLHlDQUNBLG1DQUNSLGNBQTBCO0FBVG5CLGFBQUEsbUJBQUE7QUFDQyxhQUFBLGdCQUFBO0FBQ0EsYUFBQSx3QkFBQTtBQUNBLGFBQUEsZ0NBQUE7QUFDQSxhQUFBLGtCQUFBO0FBQ0EsYUFBQSxpQ0FBQTtBQUNBLGFBQUEscUNBQUE7QUFDQSxhQUFBLDBDQUFBO0FBQ0EsYUFBQSxvQ0FBQTtBQUdSLGFBQUssK0JBQStCLG1CQUFtQixLQUFLO0FBQzVELGFBQUssMEJBQTBCLGFBQWEsMEJBQXlCLEVBQUcsVUFBVSxNQUFLO0FBQ25GLGVBQUssZUFBYztRQUN2QixDQUFDO01BQ0w7TUFPTyxZQUFZLFNBQXNCO0FBQ3JDLFdBQUcsQ0FBQyxDQUFDLEtBQUssa0JBQWtCLEVBQ3ZCLEtBRUdJLEtBQUksQ0FBQyxrQ0FBMkMsQ0FBQyxpQ0FBaUMsS0FBSywyQkFBMEIsQ0FBRSxHQUVuSEQsS0FBSSxNQUFNLHdCQUF3QixPQUFPLENBQUMsR0FDMUNDLEtBQUksQ0FBQyw0QkFBb0M7QUFDckMsY0FBSSx5QkFBeUI7QUFDekIsaUJBQUssWUFBWTtBQUNqQixnQkFBSSxLQUFLLDBCQUEwQjtBQUMvQixtQkFBSyx5QkFBeUIsWUFBVzs7QUFFN0MsZ0JBQUksS0FBSyxvQkFBb0I7QUFDekIsbUJBQUssbUJBQW1CLFVBQVUsTUFBSztBQUNuQyxxQkFBSyxlQUFjO2NBQ3ZCLENBQUM7O0FBRUwsaUJBQUsscUJBQW9COztRQUVqQyxDQUFDLEdBQ0QsVUFBVSxDQUFDLDRCQUFvQztBQUUzQyxjQUFJLENBQUMsS0FBSyxhQUFhLEtBQUssWUFBWSxLQUFLLGtCQUFrQixLQUFLLGFBQWEsMEJBQTBCO0FBQ3ZHLGlCQUFLLFlBQVk7QUFDakIsbUJBQU8sS0FBSyxpQkFBZ0IsRUFBRyxLQUUzQkEsS0FBSSxDQUFDLHFCQUFvQjtBQUNyQixrQkFBSSxDQUFDLGtCQUFrQjtBQUNuQixxQkFBSywwQkFBMEIsS0FBSTtBQUNuQyxxQkFBSyxZQUFZO0FBQ2pCLHFCQUFLLFlBQVk7QUFDakIsdUJBQU8sR0FBRyxNQUFTOztZQUUzQixDQUFDLEdBQ0QsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUMsZ0JBQWdCLEdBQy9DQSxLQUFJLENBQUMscUJBQXNCLEtBQUssbUJBQW1CLGdCQUFrQixHQUNyRSxVQUFVLE1BQU0sS0FBSyxrQkFBaUIsQ0FBRSxHQUN4Q0EsS0FBSSxDQUFDLGlCQUFnQjtBQUNqQixtQkFBSyxlQUFlO1lBQ3hCLENBQUMsR0FDREEsS0FBSSxNQUFLO0FBQ0wsbUJBQUssZUFBYztBQUNuQixtQkFBSyxZQUFZO0FBQ2pCLG1CQUFLLFlBQVk7WUFDckIsQ0FBQyxDQUFDO3FCQUVDLDJCQUEyQixPQUFPLEtBQUssS0FBSyxxQkFBcUIsUUFBVztBQUVuRixpQkFBSyxlQUFlLEtBQUs7QUFDekIsaUJBQUssbUJBQW1CLEtBQUssU0FBUztBQUN0QyxpQkFBSyxlQUFjO0FBQ25CLG1CQUFPLEdBQUcsTUFBUztxQkFDWixLQUFLLFlBQVksMkJBQTJCLE9BQU8sR0FBRztBQUU3RCxpQkFBSyxlQUFlLEtBQUs7QUFDekIsaUJBQUssbUJBQW1CLEtBQUssU0FBUztBQUN0QyxtQkFBTyxHQUFHLE1BQVM7aUJBQ2hCO0FBQ0gsbUJBQU8sR0FBRyxNQUFTOztRQUUzQixDQUFDLENBQUMsRUFFTCxVQUFTO01BQ2xCO01BRU8sV0FBUTtBQUNYLFlBQUksS0FBSyxVQUFVLGdCQUFnQjtBQUMvQixlQUFLLHdCQUF3QixLQUFLLGtDQUM3QixhQUFhLEtBQUssU0FBUyxFQUFHLEVBQzlCLEtBQ0dBLEtBQUksQ0FBQyxjQUFhO0FBQ2QsaUJBQUssWUFBWTtVQUNyQixDQUFDLENBQUMsRUFFTCxVQUFTOztNQUV0QjtNQUtRLDZCQUEwQjtBQUM5QixhQUFLLHFCQUFxQixDQUFDLEtBQUssK0JBQStCLGFBQVksR0FBSSxLQUFLLG1DQUFtQyxhQUFZLENBQUU7QUFDckksWUFBSSxLQUFLLG9DQUFvQztBQUN6QyxlQUFLLG1DQUFtQyxZQUFXOztBQUV2RCxhQUFLLHFDQUFxQyxNQUN0QyxLQUFLLCtCQUErQixvQ0FBbUMsR0FDdkUsS0FBSyxtQ0FBbUMsb0NBQW1DLENBQUUsRUFDL0UsVUFBVSxDQUFDLHVCQUFzQjtBQUMvQixlQUFLLHdDQUF3QyxDQUFDLEdBQUcsS0FBSyx1Q0FBdUMsa0JBQWtCO1FBQ25ILENBQUM7QUFDRCxZQUFJLEtBQUssbUJBQW1CO0FBQ3hCLGVBQUssa0JBQWtCLFlBQVc7O0FBRXRDLGFBQUssb0JBQW9CLEtBQUssK0JBQStCLDhCQUE2QixFQUFHLFVBQVUsQ0FBQyxVQUFnQztBQUVwSSxjQUFJLE1BQU0sZUFBZSxLQUFLLFNBQVMsSUFBSTtBQUN2QyxpQkFBSyxRQUFRLE1BQU07O1FBRTNCLENBQUM7TUFDTDtNQU1RLHVCQUFvQjtBQUN4QixZQUFJLEtBQUssMkJBQTJCO0FBQ2hDLGVBQUssMEJBQTBCLFlBQVc7O0FBRTlDLGFBQUssNEJBQTRCLEtBQUssOEJBQ2pDLHdDQUF3QyxLQUFLLGNBQWMsSUFBSyxLQUFLLHVCQUF1QixLQUFLLFNBQVMsRUFBRyxFQUM3RyxLQUFLLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFDakMsVUFBVSxDQUFDLFdBQWtCO0FBQzFCLGVBQUssZUFBZTtBQUNwQixlQUFLLCtCQUErQixnQkFBZ0IsS0FBSyxZQUFZO0FBQ3JFLGVBQUssbUNBQW1DLGdCQUFnQixLQUFLLFlBQVk7QUFDekUsZUFBSyxlQUFjO1FBQ3ZCLENBQUM7TUFDVDtNQUtBLGlCQUFjO0FBSVYsYUFBSyxlQUFlLEtBQUs7QUFFekIsYUFBSyx3Q0FBd0MsQ0FBQTtBQUM3QyxhQUFLLG1CQUFtQixLQUFLLGdCQUFnQixvQkFBb0IsS0FBSyxrQkFBa0IsS0FBSyxrQkFBa0I7QUFFL0csbUJBQ0ksTUFDSSxLQUFLLHNDQUFzQyxRQUFRLENBQUMsYUFBWTtBQUM1RCxtQkFBUTtRQUNaLENBQUMsR0FDTCxDQUFDO01BRVQ7TUFFQSxnQ0FBNkI7QUFDekIsYUFBSyxtQkFBbUIsS0FBSyxTQUFTO0FBQ3RDLGFBQUssZUFBYztNQUN2QjtNQUtBLG9CQUFpQjtBQUNiLFlBQUksS0FBSyxlQUFlLE1BQU0sS0FBSyxlQUFlLFNBQVMsUUFBUTtBQUUvRCxnQkFBTSxlQUFlLGlCQUFpQixLQUFLLGNBQWMsT0FBTztBQUNoRSxjQUFJLENBQUMsY0FBYztBQUNmLG1CQUFPLEdBQUcsTUFBUzs7QUFFdkIsdUJBQWEsZ0JBQWdCLEtBQUs7QUFDbEMsaUJBQU8sYUFBYSxZQUFZLEdBQUcsWUFBWSxJQUFJLEtBQUssMkJBQTJCLFlBQVk7bUJBQ3hGLEtBQUssaUJBQWlCLEtBQUssY0FBYyxJQUFJO0FBRXBELGlCQUFPLEtBQUssaUJBQWdCO2VBQ3pCO0FBQ0gsaUJBQU8sR0FBRyxNQUFTOztNQUUzQjtNQU1BLG1CQUFnQjtBQUNaLGVBQU8sS0FBSyx3Q0FBd0MsNEJBQTRCLEtBQUssY0FBYyxJQUFLLElBQUksRUFBRSxLQUMxRyxXQUFXLE1BQU0sR0FBRyxNQUFTLENBQUMsR0FDOUIsU0FBUyxDQUFDLGlCQUEwQixnQkFBZ0IsQ0FBQyxhQUFhLFlBQVksS0FBSywyQkFBMkIsWUFBWSxJQUFJLEdBQUcsWUFBWSxDQUFFLENBQUM7TUFFeEo7TUFPQSwyQkFBMkIsUUFBYztBQUNyQyxjQUFNLHVCQUF1QixPQUFPLGdCQUFnQixPQUFPLGdCQUFnQixLQUFLO0FBQ2hGLGVBQU8sS0FBSyxjQUFjLDRCQUE0QixxQkFBcUIsSUFBSyxNQUFNLEVBQUUsS0FDcEZELEtBQUksQ0FBQyxRQUFRLE9BQU8sSUFBSSxJQUFJLEdBQzVCQSxLQUFJLENBQUMsY0FBeUI7QUFDMUIsaUJBQU8sWUFBWTtBQUNuQixpQkFBTztRQUNYLENBQUMsR0FDRCxXQUFXLE1BQU0sR0FBRyxNQUFNLENBQUMsQ0FBQztNQUVwQztNQU9BLG1CQUFnQjtBQUNaLFlBQUksS0FBSyxTQUFTLGtCQUFrQjtBQUNoQyxpQkFBTyxHQUFHLEtBQUssU0FBUyxnQkFBZ0I7ZUFDckM7QUFDSCxjQUFJLENBQUMsS0FBSyxjQUFjLElBQUk7QUFDeEIsbUJBQU8sR0FBRyxNQUFTOztBQUV2QixpQkFBTyxLQUFLLHNCQUFzQixJQUFJLEtBQUssY0FBYyxJQUFJLFdBQVcsRUFBRSxLQUN0RSxXQUFXLE1BQU0sR0FBRyxNQUFTLENBQUMsR0FFOUJBLEtBQUksQ0FBQyxZQUFZLFdBQVcsUUFBUSxZQUFZLFFBQVEsSUFBSSxPQUFPLEtBQUssR0FBRyxHQUFHLFFBQVEsQ0FBQyxDQUFDOztNQUdwRztNQUtBLGNBQVc7QUFDUCxZQUFJLEtBQUssMkJBQTJCO0FBQ2hDLGVBQUssMEJBQTBCLFlBQVc7O0FBRTlDLFlBQUksS0FBSywwQkFBMEI7QUFDL0IsZUFBSyx5QkFBeUIsWUFBVzs7QUFFN0MsWUFBSSxLQUFLLG9DQUFvQztBQUN6QyxlQUFLLG1DQUFtQyxZQUFXOztBQUV2RCxZQUFJLEtBQUssbUJBQW1CO0FBQ3hCLGVBQUssa0JBQWtCLFlBQVc7O0FBRXRDLFlBQUksS0FBSyx1QkFBdUI7QUFDNUIsZUFBSyxzQkFBc0IsWUFBVzs7QUFFMUMsWUFBSSxLQUFLLHlCQUF5QjtBQUM5QixlQUFLLHdCQUF3QixZQUFXOztNQUVoRDs7eUJBbFRTLDBDQUF1QyxnQ0FBQSxvQkFBQSxHQUFBLGdDQUFBLGFBQUEsR0FBQSxnQ0FBQSxxQkFBQSxHQUFBLGdDQUFBLDZCQUFBLEdBQUEsZ0NBQUEsc0JBQUEsR0FBQSxnQ0FBQSx1Q0FBQSxHQUFBLGdDQUFBLDJDQUFBLEdBQUEsZ0NBQUEsdUNBQUEsR0FBQSxnQ0FBQSxpQ0FBQSxHQUFBLGdDQUFBLFlBQUEsQ0FBQTtNQUFBO2lFQUF2QywwQ0FBdUMsV0FBQSxDQUFBLENBQUEsdUNBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsZUFBQSxpQkFBQSxvQkFBQSxzQkFBQSx1QkFBQSx3QkFBQSxHQUFBLFNBQUEsRUFBQSwyQkFBQSw0QkFBQSxHQUFBLFVBQUEsQ0FBQSxrQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSx5QkFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsZ0JBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSw2Q0FBQSxHQUFBLGVBQUEsbUNBQUEsb0JBQUEsR0FBQSxVQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSw2QkFBQSxHQUFBLENBQUEsTUFBQSw2Q0FBQSxHQUFBLFVBQUEsMEJBQUEsTUFBQSxHQUFBLENBQUEsUUFBQSxNQUFBLEdBQUEsUUFBQSxNQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsaURBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUM5QnBELFVBQUEseUJBQUEsR0FBQSxnRUFBQSxJQUFBLENBQUEsRUFlQyxHQUFBLGdFQUFBLEdBQUEsQ0FBQTs7O0FBZkQsVUFBQSw0QkFBQSxHQUFBLENBQUEsSUFBQSxZQUFBLElBQUEsQ0FBQTs7Ozs7cUZEOEJhLHlDQUF1QyxFQUFBLFdBQUEsMENBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFOUJwRCxTQUFTLFlBQUFHLGlCQUFnQjs7QUFBekIsSUFjYTtBQWRiOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBT00sSUFBTyxxREFBUCxNQUFPLG9EQUFrRDs7eUJBQWxELHFEQUFrRDtNQUFBO2lFQUFsRCxvREFBa0QsQ0FBQTtxRUFKakQscUJBQXFCLHFCQUFxQix1QkFBdUIsbUNBQW1DLEVBQUEsQ0FBQTs7OzsiLCJuYW1lcyI6WyJUZXN0Q2FzZVN0YXRlIiwiZmVlZGJhY2siLCJDb21wb25lbnQiLCJJbnB1dCIsIkluamVjdGFibGUiLCJJbmplY3RhYmxlIiwiU3ViamVjdCIsIkluamVjdGFibGUiLCJTdWJqZWN0IiwidGFwIiwiQ29tcG9uZW50IiwiSW5wdXQiLCJOZ2JNb2RhbCIsIkNvbXBvbmVudCIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwibWFwIiwidGFwIiwiT2JzZXJ2YWJsZSIsIk5nTW9kdWxlIl19