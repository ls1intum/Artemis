import {
  StringCountService,
  init_string_count_service
} from "/chunk-DBGVWL5C.js";
import {
  Result,
  init_result_model
} from "/chunk-ORYTP7RT.js";
import {
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  ExerciseService,
  ExerciseType,
  __esm,
  getLatestSubmissionResult,
  init_artemis_translate_pipe,
  init_exercise_model,
  init_exercise_service,
  init_shared_module,
  init_submission_model
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/shared/assessment-progress-label/assessment-progress-label.component.ts
import { Component, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
function AssessmentProgressLabelComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "small", 0);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n    ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", i0.\u0275\u0275pipeBind2(3, 1, "artemisApp.assessmentDashboard.noSubmissionFound", i0.\u0275\u0275pureFunction0(4, _c0)), " ");
  }
}
function AssessmentProgressLabelComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "small", 1);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275pipe(4, "number");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("ngClass", ctx_r1.numberAssessedSubmissions === ctx_r1.submissions.length ? "text-success" : "text-warning");
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate1("\n            ", i0.\u0275\u0275pipeBind2(3, 2, "artemisApp.assessmentDashboard.progressDescription", i0.\u0275\u0275pureFunction3(8, _c1, i0.\u0275\u0275pipeBind2(4, 5, ctx_r1.numberAssessedSubmissions / ctx_r1.submissions.length * 100, "0.0-0"), ctx_r1.numberAssessedSubmissions, ctx_r1.submissions.length)), "\n        ");
  }
}
var _c0, _c1, AssessmentProgressLabelComponent;
var init_assessment_progress_label_component = __esm({
  "src/main/webapp/app/exercises/shared/assessment-progress-label/assessment-progress-label.component.ts"() {
    init_submission_model();
    init_result_model();
    init_artemis_translate_pipe();
    _c0 = () => ({});
    _c1 = (a0, a1, a2) => ({ percentageAssessed: a0, numberAssessed: a1, numberSubmissions: a2 });
    AssessmentProgressLabelComponent = class _AssessmentProgressLabelComponent {
      submissions = [];
      numberAssessedSubmissions;
      ngOnChanges() {
        this.numberAssessedSubmissions = this.submissions.filter((submission) => {
          const result = getLatestSubmissionResult(submission);
          return result?.rated && Result.isManualResult(result) && result?.completionDate;
        }).length;
      }
      static \u0275fac = function AssessmentProgressLabelComponent_Factory(t) {
        return new (t || _AssessmentProgressLabelComponent)();
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _AssessmentProgressLabelComponent, selectors: [["jhi-assessment-progress-label"]], inputs: { submissions: "submissions" }, features: [i0.\u0275\u0275NgOnChangesFeature], decls: 5, vars: 2, consts: [[1, "text-warning"], [3, "ngClass"]], template: function AssessmentProgressLabelComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "h4");
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275template(2, AssessmentProgressLabelComponent_Conditional_2_Template, 5, 5)(3, AssessmentProgressLabelComponent_Conditional_3_Template, 6, 12);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(4, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275conditional(2, ctx.submissions && ctx.submissions.length === 0 ? 2 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275conditional(3, ctx.submissions && ctx.submissions.length > 0 ? 3 : -1);
        }
      }, dependencies: [i1.NgClass, i1.DecimalPipe, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(AssessmentProgressLabelComponent, { className: "AssessmentProgressLabelComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/assessment-progress-label/assessment-progress-label.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisAssessmentProgressLabelModule;
var init_assessment_progress_label_module = __esm({
  "src/main/webapp/app/exercises/shared/assessment-progress-label/assessment-progress-label.module.ts"() {
    init_shared_module();
    init_assessment_progress_label_component();
    ArtemisAssessmentProgressLabelModule = class _ArtemisAssessmentProgressLabelModule {
      static \u0275fac = function ArtemisAssessmentProgressLabelModule_Factory(t) {
        return new (t || _ArtemisAssessmentProgressLabelModule)();
      };
      static \u0275mod = i02.\u0275\u0275defineNgModule({ type: _ArtemisAssessmentProgressLabelModule });
      static \u0275inj = i02.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule] });
    };
  }
});

// src/main/webapp/app/exercises/shared/example-submission/example-submission.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var ExampleSubmissionService;
var init_example_submission_service = __esm({
  "src/main/webapp/app/exercises/shared/example-submission/example-submission.service.ts"() {
    init_exercise_service();
    init_exercise_model();
    init_string_count_service();
    init_string_count_service();
    ExampleSubmissionService = class _ExampleSubmissionService {
      http;
      stringCountService;
      constructor(http, stringCountService) {
        this.http = http;
        this.stringCountService = stringCountService;
      }
      create(exampleSubmission, exerciseId) {
        const copy = this.convert(exampleSubmission);
        return this.http.post(`api/exercises/${exerciseId}/example-submissions`, copy, {
          observe: "response"
        }).pipe(map((res) => this.convertResponse(res)));
      }
      update(exampleSubmission, exerciseId) {
        const copy = this.convert(exampleSubmission);
        return this.http.put(`api/exercises/${exerciseId}/example-submissions`, copy, {
          observe: "response"
        }).pipe(map((res) => this.convertResponse(res)));
      }
      prepareForAssessment(exerciseId, exampleSubmissionId) {
        return this.http.post(`api/exercises/${exerciseId}/example-submissions/${exampleSubmissionId}/prepare-assessment`, {}, { observe: "response" });
      }
      get(exampleSubmissionId) {
        return this.http.get(`api/example-submissions/${exampleSubmissionId}`, { observe: "response" }).pipe(map((res) => this.convertResponse(res)));
      }
      delete(exampleSubmissionId) {
        return this.http.delete(`api/example-submissions/${exampleSubmissionId}`, { observe: "response" });
      }
      import(submissionId, exerciseId) {
        return this.http.post(`api/exercises/${exerciseId}/example-submissions/import/${submissionId}`, {}, {
          observe: "response"
        }).pipe(map((res) => this.convertResponse(res)));
      }
      convertResponse(res) {
        const body = this.convertItemFromServer(res.body);
        return res.clone({ body });
      }
      convertItemFromServer(exampleSubmission) {
        return Object.assign({}, exampleSubmission);
      }
      convert(exampleSubmission) {
        const jsonCopy = Object.assign({}, exampleSubmission);
        if (jsonCopy.exercise) {
          jsonCopy.exercise = ExerciseService.convertExerciseDatesFromClient(jsonCopy.exercise);
          jsonCopy.exercise = ExerciseService.setBonusPointsConstrainedByIncludedInOverallScore(jsonCopy.exercise);
          jsonCopy.exercise.categories = ExerciseService.stringifyExerciseCategories(jsonCopy.exercise);
        }
        return jsonCopy;
      }
      getSubmissionSize(submission, exercise) {
        if (submission && exercise && exercise.type === ExerciseType.TEXT) {
          return this.stringCountService.countWords(submission.text);
        } else if (submission && exercise && exercise.type === ExerciseType.MODELING) {
          const umlModel = JSON.parse(submission.model);
          return umlModel ? umlModel.elements?.length + umlModel.relationships?.length : 0;
        }
        return 0;
      }
      static \u0275fac = function ExampleSubmissionService_Factory(t) {
        return new (t || _ExampleSubmissionService)(i03.\u0275\u0275inject(i12.HttpClient), i03.\u0275\u0275inject(StringCountService));
      };
      static \u0275prov = i03.\u0275\u0275defineInjectable({ token: _ExampleSubmissionService, factory: _ExampleSubmissionService.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  ExampleSubmissionService,
  init_example_submission_service,
  ArtemisAssessmentProgressLabelModule,
  init_assessment_progress_label_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9hc3Nlc3NtZW50LXByb2dyZXNzLWxhYmVsL2Fzc2Vzc21lbnQtcHJvZ3Jlc3MtbGFiZWwuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2Fzc2Vzc21lbnQtcHJvZ3Jlc3MtbGFiZWwvYXNzZXNzbWVudC1wcm9ncmVzcy1sYWJlbC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9hc3Nlc3NtZW50LXByb2dyZXNzLWxhYmVsL2Fzc2Vzc21lbnQtcHJvZ3Jlc3MtbGFiZWwubW9kdWxlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4YW1wbGUtc3VibWlzc2lvbi9leGFtcGxlLXN1Ym1pc3Npb24uc2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFN1Ym1pc3Npb24sIGdldExhdGVzdFN1Ym1pc3Npb25SZXN1bHQgfSBmcm9tICdhcHAvZW50aXRpZXMvc3VibWlzc2lvbi5tb2RlbCc7XG5pbXBvcnQgeyBSZXN1bHQgfSBmcm9tICdhcHAvZW50aXRpZXMvcmVzdWx0Lm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktYXNzZXNzbWVudC1wcm9ncmVzcy1sYWJlbCcsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2Fzc2Vzc21lbnQtcHJvZ3Jlc3MtbGFiZWwuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBBc3Nlc3NtZW50UHJvZ3Jlc3NMYWJlbENvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gICAgQElucHV0KClcbiAgICBzdWJtaXNzaW9uczogU3VibWlzc2lvbltdID0gW107XG4gICAgbnVtYmVyQXNzZXNzZWRTdWJtaXNzaW9uczogbnVtYmVyO1xuXG4gICAgbmdPbkNoYW5nZXMoKSB7XG4gICAgICAgIHRoaXMubnVtYmVyQXNzZXNzZWRTdWJtaXNzaW9ucyA9IHRoaXMuc3VibWlzc2lvbnMuZmlsdGVyKChzdWJtaXNzaW9uKSA9PiB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBnZXRMYXRlc3RTdWJtaXNzaW9uUmVzdWx0KHN1Ym1pc3Npb24pO1xuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdD8ucmF0ZWQgJiYgUmVzdWx0LmlzTWFudWFsUmVzdWx0KHJlc3VsdCkgJiYgcmVzdWx0Py5jb21wbGV0aW9uRGF0ZTtcbiAgICAgICAgfSkubGVuZ3RoO1xuICAgIH1cbn1cbiIsIjxoND5cbiAgICBAaWYgKHN1Ym1pc3Npb25zICYmIHN1Ym1pc3Npb25zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICA8c21hbGwgY2xhc3M9XCJ0ZXh0LXdhcm5pbmdcIj4ge3sgJ2FydGVtaXNBcHAuYXNzZXNzbWVudERhc2hib2FyZC5ub1N1Ym1pc3Npb25Gb3VuZCcgfCBhcnRlbWlzVHJhbnNsYXRlOiB7fSB9fSA8L3NtYWxsPlxuICAgIH1cbiAgICBAaWYgKHN1Ym1pc3Npb25zICYmIHN1Ym1pc3Npb25zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgPHNtYWxsIFtuZ0NsYXNzXT1cIm51bWJlckFzc2Vzc2VkU3VibWlzc2lvbnMgPT09IHN1Ym1pc3Npb25zLmxlbmd0aCA/ICd0ZXh0LXN1Y2Nlc3MnIDogJ3RleHQtd2FybmluZydcIj5cbiAgICAgICAgICAgIHt7XG4gICAgICAgICAgICAgICAgJ2FydGVtaXNBcHAuYXNzZXNzbWVudERhc2hib2FyZC5wcm9ncmVzc0Rlc2NyaXB0aW9uJ1xuICAgICAgICAgICAgICAgICAgICB8IGFydGVtaXNUcmFuc2xhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgIDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVyY2VudGFnZUFzc2Vzc2VkOiAobnVtYmVyQXNzZXNzZWRTdWJtaXNzaW9ucyAvIHN1Ym1pc3Npb25zLmxlbmd0aCkgKiAxMDAgfCBudW1iZXI6ICcwLjAtMCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1iZXJBc3Nlc3NlZDogbnVtYmVyQXNzZXNzZWRTdWJtaXNzaW9ucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bWJlclN1Ym1pc3Npb25zOiBzdWJtaXNzaW9ucy5sZW5ndGhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfX1cbiAgICAgICAgPC9zbWFsbD5cbiAgICB9XG48L2g0PlxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgQXNzZXNzbWVudFByb2dyZXNzTGFiZWxDb21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9hc3Nlc3NtZW50LXByb2dyZXNzLWxhYmVsL2Fzc2Vzc21lbnQtcHJvZ3Jlc3MtbGFiZWwuY29tcG9uZW50JztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbQXNzZXNzbWVudFByb2dyZXNzTGFiZWxDb21wb25lbnRdLFxuICAgIGV4cG9ydHM6IFtBc3Nlc3NtZW50UHJvZ3Jlc3NMYWJlbENvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNBc3Nlc3NtZW50UHJvZ3Jlc3NMYWJlbE1vZHVsZSB7fVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgRXhhbXBsZVN1Ym1pc3Npb24gfSBmcm9tICdhcHAvZW50aXRpZXMvZXhhbXBsZS1zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IEV4ZXJjaXNlU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlL2V4ZXJjaXNlLnNlcnZpY2UnO1xuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgU3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IEV4ZXJjaXNlLCBFeGVyY2lzZVR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgVGV4dFN1Ym1pc3Npb24gfSBmcm9tICdhcHAvZW50aXRpZXMvdGV4dC1zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IE1vZGVsaW5nU3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9tb2RlbGluZy1zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IFN0cmluZ0NvdW50U2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvdGV4dC9wYXJ0aWNpcGF0ZS9zdHJpbmctY291bnQuc2VydmljZSc7XG5cbmV4cG9ydCB0eXBlIEVudGl0eVJlc3BvbnNlVHlwZSA9IEh0dHBSZXNwb25zZTxFeGFtcGxlU3VibWlzc2lvbj47XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgRXhhbXBsZVN1Ym1pc3Npb25TZXJ2aWNlIHtcbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50LFxuICAgICAgICBwcml2YXRlIHN0cmluZ0NvdW50U2VydmljZTogU3RyaW5nQ291bnRTZXJ2aWNlLFxuICAgICkge31cblxuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYW4gZXhhbXBsZSBzdWJtaXNzaW9uXG4gICAgICogQHBhcmFtIGV4YW1wbGVTdWJtaXNzaW9uIEV4YW1wbGUgc3VibWlzc2lvbiB0byBjcmVhdGVcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCBJZCBvZiB0aGUgZXhlcmNpc2UgdG8gd2hpY2ggaXQgYmVsb25nc1xuICAgICAqL1xuICAgIGNyZWF0ZShleGFtcGxlU3VibWlzc2lvbjogRXhhbXBsZVN1Ym1pc3Npb24sIGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIGNvbnN0IGNvcHkgPSB0aGlzLmNvbnZlcnQoZXhhbXBsZVN1Ym1pc3Npb24pO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAucG9zdDxFeGFtcGxlU3VibWlzc2lvbj4oYGFwaS9leGVyY2lzZXMvJHtleGVyY2lzZUlkfS9leGFtcGxlLXN1Ym1pc3Npb25zYCwgY29weSwge1xuICAgICAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEVudGl0eVJlc3BvbnNlVHlwZSkgPT4gdGhpcy5jb252ZXJ0UmVzcG9uc2UocmVzKSkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZXMgYW4gZXhhbXBsZSBzdWJtaXNzaW9uXG4gICAgICogQHBhcmFtIGV4YW1wbGVTdWJtaXNzaW9uIEV4YW1wbGUgc3VibWlzc2lvbiB0byB1cGRhdGVcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCBJZCBvZiB0aGUgZXhlcmNpc2UgdG8gd2hpY2ggaXQgYmVsb25nc1xuICAgICAqL1xuICAgIHVwZGF0ZShleGFtcGxlU3VibWlzc2lvbjogRXhhbXBsZVN1Ym1pc3Npb24sIGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIGNvbnN0IGNvcHkgPSB0aGlzLmNvbnZlcnQoZXhhbXBsZVN1Ym1pc3Npb24pO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAucHV0PEV4YW1wbGVTdWJtaXNzaW9uPihgYXBpL2V4ZXJjaXNlcy8ke2V4ZXJjaXNlSWR9L2V4YW1wbGUtc3VibWlzc2lvbnNgLCBjb3B5LCB7XG4gICAgICAgICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlczogRW50aXR5UmVzcG9uc2VUeXBlKSA9PiB0aGlzLmNvbnZlcnRSZXNwb25zZShyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUHJlcGFyZSBhbiBleGFtcGxlIHN1Ym1pc3Npb24gZm9yIGFzc2Vzc21lbnRcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCBJZCBvZiB0aGUgZXhlcmNpc2UgdG8gd2hpY2ggaXQgYmVsb25nc1xuICAgICAqIEBwYXJhbSBleGFtcGxlU3VibWlzc2lvbklkIElkIG9mIHRoZSBleGFtcGxlIHN1Ym1pc3Npb24gdG8gcHJlcGFyZVxuICAgICAqL1xuICAgIHByZXBhcmVGb3JBc3Nlc3NtZW50KGV4ZXJjaXNlSWQ6IG51bWJlciwgZXhhbXBsZVN1Ym1pc3Npb25JZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8dm9pZD4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PHZvaWQ+KGBhcGkvZXhlcmNpc2VzLyR7ZXhlcmNpc2VJZH0vZXhhbXBsZS1zdWJtaXNzaW9ucy8ke2V4YW1wbGVTdWJtaXNzaW9uSWR9L3ByZXBhcmUtYXNzZXNzbWVudGAsIHt9LCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0cyBhbiBleGFtcGxlIHN1Ym1pc3Npb25cbiAgICAgKiBAcGFyYW0gZXhhbXBsZVN1Ym1pc3Npb25JZCBJZCBvZiBleGFtcGxlIHN1Ym1pc3Npb24gdG8gZ2V0XG4gICAgICovXG4gICAgZ2V0KGV4YW1wbGVTdWJtaXNzaW9uSWQ6IG51bWJlcik6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5nZXQ8RXhhbXBsZVN1Ym1pc3Npb24+KGBhcGkvZXhhbXBsZS1zdWJtaXNzaW9ucy8ke2V4YW1wbGVTdWJtaXNzaW9uSWR9YCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlczogSHR0cFJlc3BvbnNlPEV4YW1wbGVTdWJtaXNzaW9uPikgPT4gdGhpcy5jb252ZXJ0UmVzcG9uc2UocmVzKSkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIERlbGV0ZXMgYW4gZXhhbXBsZSBzdWJtaXNzaW9uXG4gICAgICogQHBhcmFtIGV4YW1wbGVTdWJtaXNzaW9uSWQgSWQgb2YgZXhhbXBsZSBzdWJtaXNzaW9uIHRvIGRlbGV0ZVxuICAgICAqL1xuICAgIGRlbGV0ZShleGFtcGxlU3VibWlzc2lvbklkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTx2b2lkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmRlbGV0ZTx2b2lkPihgYXBpL2V4YW1wbGUtc3VibWlzc2lvbnMvJHtleGFtcGxlU3VibWlzc2lvbklkfWAsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBJbXBvcnRzIGFuIGV4YW1wbGUgc3VibWlzc2lvblxuICAgICAqIEBwYXJhbSBzdWJtaXNzaW9uSWQgdGhlIGlkIG9kIHRoZSBzdWJtaXNzaW9uIHRvIGJlIGltcG9ydGVkIGFzIGFuIGV4YW1wbGUgc3VibWlzc2lvblxuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkIHRoZSBpZCBvZiB0aGUgY29ycmVzcG9uZGluZyBleGVyY2lzZVxuICAgICAqL1xuICAgIGltcG9ydChzdWJtaXNzaW9uSWQ6IG51bWJlciwgZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxFbnRpdHlSZXNwb25zZVR5cGU+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLnBvc3Q8RXhhbXBsZVN1Ym1pc3Npb24+KFxuICAgICAgICAgICAgICAgIGBhcGkvZXhlcmNpc2VzLyR7ZXhlcmNpc2VJZH0vZXhhbXBsZS1zdWJtaXNzaW9ucy9pbXBvcnQvJHtzdWJtaXNzaW9uSWR9YCxcbiAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIClcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpID0+IHRoaXMuY29udmVydFJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGNvbnZlcnRSZXNwb25zZShyZXM6IEVudGl0eVJlc3BvbnNlVHlwZSk6IEVudGl0eVJlc3BvbnNlVHlwZSB7XG4gICAgICAgIGNvbnN0IGJvZHk6IEV4YW1wbGVTdWJtaXNzaW9uID0gdGhpcy5jb252ZXJ0SXRlbUZyb21TZXJ2ZXIocmVzLmJvZHkhKTtcbiAgICAgICAgcmV0dXJuIHJlcy5jbG9uZSh7IGJvZHkgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ29udmVydCBhIHJldHVybmVkIEpTT04gb2JqZWN0IHRvIEV4YW1wbGVTdWJtaXNzaW9uLlxuICAgICAqL1xuICAgIHByaXZhdGUgY29udmVydEl0ZW1Gcm9tU2VydmVyKGV4YW1wbGVTdWJtaXNzaW9uOiBFeGFtcGxlU3VibWlzc2lvbik6IEV4YW1wbGVTdWJtaXNzaW9uIHtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oe30sIGV4YW1wbGVTdWJtaXNzaW9uKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDb252ZXJ0IGEgRXhhbXBsZVN1Ym1pc3Npb24gdG8gYSBKU09OIHdoaWNoIGNhbiBiZSBzZW50IHRvIHRoZSBzZXJ2ZXIuXG4gICAgICovXG4gICAgcHJpdmF0ZSBjb252ZXJ0KGV4YW1wbGVTdWJtaXNzaW9uOiBFeGFtcGxlU3VibWlzc2lvbik6IEV4YW1wbGVTdWJtaXNzaW9uIHtcbiAgICAgICAgY29uc3QganNvbkNvcHkgPSBPYmplY3QuYXNzaWduKHt9LCBleGFtcGxlU3VibWlzc2lvbik7XG4gICAgICAgIGlmIChqc29uQ29weS5leGVyY2lzZSkge1xuICAgICAgICAgICAganNvbkNvcHkuZXhlcmNpc2UgPSBFeGVyY2lzZVNlcnZpY2UuY29udmVydEV4ZXJjaXNlRGF0ZXNGcm9tQ2xpZW50KGpzb25Db3B5LmV4ZXJjaXNlKTtcbiAgICAgICAgICAgIGpzb25Db3B5LmV4ZXJjaXNlID0gRXhlcmNpc2VTZXJ2aWNlLnNldEJvbnVzUG9pbnRzQ29uc3RyYWluZWRCeUluY2x1ZGVkSW5PdmVyYWxsU2NvcmUoanNvbkNvcHkuZXhlcmNpc2UhKTtcbiAgICAgICAgICAgIGpzb25Db3B5LmV4ZXJjaXNlLmNhdGVnb3JpZXMgPSBFeGVyY2lzZVNlcnZpY2Uuc3RyaW5naWZ5RXhlcmNpc2VDYXRlZ29yaWVzKGpzb25Db3B5LmV4ZXJjaXNlKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ganNvbkNvcHk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2FsY3VsYXRlcyB0aGUgbnVtYmVyIG9mIGVsZW1lbnRzIGZvciB0aGUgZXhhbXBsZSBzdWJtaXNzaW9uXG4gICAgICpcbiAgICAgKiBAcGFyYW0gc3VibWlzc2lvbiBhc3NvY2lhdGVkIHdpdGggdGhlIGV4YW1wbGUgc3VibWlzc2lvblxuICAgICAqIEBwYXJhbSBleGVyY2lzZSAgIG5lZWRlZCB0byBkZWNpZGUgc3VibWlzc2lvbiB0eXBlXG4gICAgICogQHJldHVybnMgbnVtYmVyIG9mIHdvcmRzIGZvciB0ZXh0IHN1Ym1pc3Npb24sIG9yIG51bWJlciBvZiBlbGVtZW50IGZvciB0aGUgbW9kZWxpbmcgc3VibWlzc2lvblxuICAgICAqL1xuICAgIGdldFN1Ym1pc3Npb25TaXplKHN1Ym1pc3Npb24/OiBTdWJtaXNzaW9uLCBleGVyY2lzZT86IEV4ZXJjaXNlKTogbnVtYmVyIHtcbiAgICAgICAgaWYgKHN1Ym1pc3Npb24gJiYgZXhlcmNpc2UgJiYgZXhlcmNpc2UudHlwZSA9PT0gRXhlcmNpc2VUeXBlLlRFWFQpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnN0cmluZ0NvdW50U2VydmljZS5jb3VudFdvcmRzKChzdWJtaXNzaW9uIGFzIFRleHRTdWJtaXNzaW9uKS50ZXh0KTtcbiAgICAgICAgfSBlbHNlIGlmIChzdWJtaXNzaW9uICYmIGV4ZXJjaXNlICYmIGV4ZXJjaXNlLnR5cGUgPT09IEV4ZXJjaXNlVHlwZS5NT0RFTElORykge1xuICAgICAgICAgICAgY29uc3QgdW1sTW9kZWwgPSBKU09OLnBhcnNlKChzdWJtaXNzaW9uIGFzIE1vZGVsaW5nU3VibWlzc2lvbikubW9kZWwhKTtcbiAgICAgICAgICAgIHJldHVybiB1bWxNb2RlbCA/IHVtbE1vZGVsLmVsZW1lbnRzPy5sZW5ndGggKyB1bWxNb2RlbC5yZWxhdGlvbnNoaXBzPy5sZW5ndGggOiAwO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAwO1xuICAgIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLFdBQVcsYUFBd0I7Ozs7O0FDRXBDLElBQUEsb0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQUE2QixJQUFBLG9CQUFBLENBQUE7O0FBQWdGLElBQUEsMEJBQUE7QUFDakgsSUFBQSxvQkFBQSxHQUFBLFFBQUE7OztBQURpQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEseUJBQUEsR0FBQSxHQUFBLG9EQUFBLDZCQUFBLEdBQUEsR0FBQSxDQUFBLEdBQUEsR0FBQTs7Ozs7QUFHN0IsSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxDQUFBOzs7QUFTSixJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFFBQUE7Ozs7QUFYVyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFdBQUEsT0FBQSw4QkFBQSxPQUFBLFlBQUEsU0FBQSxpQkFBQSxjQUFBO0FBQ0gsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxrQkFBQSx5QkFBQSxHQUFBLEdBQUEsc0RBQUEsNkJBQUEsR0FBQSxLQUFBLHlCQUFBLEdBQUEsR0FBQSxPQUFBLDRCQUFBLE9BQUEsWUFBQSxTQUFBLEtBQUEsT0FBQSxHQUFBLE9BQUEsMkJBQUEsT0FBQSxZQUFBLE1BQUEsQ0FBQSxHQUFBLFlBQUE7OztBRE5aLGNBUWE7QUFSYjs7QUFDQTtBQUNBOzs7O0FBTU0sSUFBTyxtQ0FBUCxNQUFPLGtDQUFnQztNQUV6QyxjQUE0QixDQUFBO01BQzVCO01BRUEsY0FBVztBQUNQLGFBQUssNEJBQTRCLEtBQUssWUFBWSxPQUFPLENBQUMsZUFBYztBQUNwRSxnQkFBTSxTQUFTLDBCQUEwQixVQUFVO0FBQ25ELGlCQUFPLFFBQVEsU0FBUyxPQUFPLGVBQWUsTUFBTSxLQUFLLFFBQVE7UUFDckUsQ0FBQyxFQUFFO01BQ1A7O3lCQVZTLG1DQUFnQztNQUFBO2dFQUFoQyxtQ0FBZ0MsV0FBQSxDQUFBLENBQUEsK0JBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxhQUFBLGNBQUEsR0FBQSxVQUFBLENBQUEsaUNBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsMENBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNSN0MsVUFBQSw0QkFBQSxHQUFBLElBQUE7QUFDSSxVQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsd0JBQUEsR0FBQSx5REFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLHlEQUFBLEdBQUEsRUFBQTtBQWNMLFVBQUEsMEJBQUE7QUFDQSxVQUFBLG9CQUFBLEdBQUEsSUFBQTs7O0FBakJJLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsMkJBQUEsR0FBQSxJQUFBLGVBQUEsSUFBQSxZQUFBLFdBQUEsSUFBQSxJQUFBLEVBQUE7QUFHQSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLDJCQUFBLEdBQUEsSUFBQSxlQUFBLElBQUEsWUFBQSxTQUFBLElBQUEsSUFBQSxFQUFBOzs7OztvRkRJUyxrQ0FBZ0MsRUFBQSxXQUFBLG1DQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVI3QyxTQUFTLGdCQUFnQjs7QUFBekIsSUFTYTtBQVRiOztBQUNBO0FBQ0E7QUFPTSxJQUFPLHVDQUFQLE1BQU8sc0NBQW9DOzt5QkFBcEMsdUNBQW9DO01BQUE7Z0VBQXBDLHNDQUFvQyxDQUFBO29FQUpuQyxtQkFBbUIsRUFBQSxDQUFBOzs7Ozs7QUNMakMsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBZ0M7QUFJekMsU0FBUyxXQUFXOzs7QUFMcEIsSUFlYTtBQWZiOztBQUlBO0FBR0E7QUFHQTs7QUFLTSxJQUFPLDJCQUFQLE1BQU8sMEJBQXdCO01BRXJCO01BQ0E7TUFGWixZQUNZLE1BQ0Esb0JBQXNDO0FBRHRDLGFBQUEsT0FBQTtBQUNBLGFBQUEscUJBQUE7TUFDVDtNQU9ILE9BQU8sbUJBQXNDLFlBQWtCO0FBQzNELGNBQU0sT0FBTyxLQUFLLFFBQVEsaUJBQWlCO0FBQzNDLGVBQU8sS0FBSyxLQUNQLEtBQXdCLGlCQUFpQixVQUFVLHdCQUF3QixNQUFNO1VBQzlFLFNBQVM7U0FDWixFQUNBLEtBQUssSUFBSSxDQUFDLFFBQTRCLEtBQUssZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO01BQ3pFO01BT0EsT0FBTyxtQkFBc0MsWUFBa0I7QUFDM0QsY0FBTSxPQUFPLEtBQUssUUFBUSxpQkFBaUI7QUFDM0MsZUFBTyxLQUFLLEtBQ1AsSUFBdUIsaUJBQWlCLFVBQVUsd0JBQXdCLE1BQU07VUFDN0UsU0FBUztTQUNaLEVBQ0EsS0FBSyxJQUFJLENBQUMsUUFBNEIsS0FBSyxnQkFBZ0IsR0FBRyxDQUFDLENBQUM7TUFDekU7TUFPQSxxQkFBcUIsWUFBb0IscUJBQTJCO0FBQ2hFLGVBQU8sS0FBSyxLQUFLLEtBQVcsaUJBQWlCLFVBQVUsd0JBQXdCLG1CQUFtQix1QkFBdUIsQ0FBQSxHQUFJLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDeEo7TUFNQSxJQUFJLHFCQUEyQjtBQUMzQixlQUFPLEtBQUssS0FDUCxJQUF1QiwyQkFBMkIsbUJBQW1CLElBQUksRUFBRSxTQUFTLFdBQVUsQ0FBRSxFQUNoRyxLQUFLLElBQUksQ0FBQyxRQUF5QyxLQUFLLGdCQUFnQixHQUFHLENBQUMsQ0FBQztNQUN0RjtNQU1BLE9BQU8scUJBQTJCO0FBQzlCLGVBQU8sS0FBSyxLQUFLLE9BQWEsMkJBQTJCLG1CQUFtQixJQUFJLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDM0c7TUFPQSxPQUFPLGNBQXNCLFlBQWtCO0FBQzNDLGVBQU8sS0FBSyxLQUNQLEtBQ0csaUJBQWlCLFVBQVUsK0JBQStCLFlBQVksSUFDdEUsQ0FBQSxHQUNBO1VBQ0ksU0FBUztTQUNaLEVBRUosS0FBSyxJQUFJLENBQUMsUUFBNEIsS0FBSyxnQkFBZ0IsR0FBRyxDQUFDLENBQUM7TUFDekU7TUFFUSxnQkFBZ0IsS0FBdUI7QUFDM0MsY0FBTSxPQUEwQixLQUFLLHNCQUFzQixJQUFJLElBQUs7QUFDcEUsZUFBTyxJQUFJLE1BQU0sRUFBRSxLQUFJLENBQUU7TUFDN0I7TUFLUSxzQkFBc0IsbUJBQW9DO0FBQzlELGVBQU8sT0FBTyxPQUFPLENBQUEsR0FBSSxpQkFBaUI7TUFDOUM7TUFLUSxRQUFRLG1CQUFvQztBQUNoRCxjQUFNLFdBQVcsT0FBTyxPQUFPLENBQUEsR0FBSSxpQkFBaUI7QUFDcEQsWUFBSSxTQUFTLFVBQVU7QUFDbkIsbUJBQVMsV0FBVyxnQkFBZ0IsK0JBQStCLFNBQVMsUUFBUTtBQUNwRixtQkFBUyxXQUFXLGdCQUFnQixrREFBa0QsU0FBUyxRQUFTO0FBQ3hHLG1CQUFTLFNBQVMsYUFBYSxnQkFBZ0IsNEJBQTRCLFNBQVMsUUFBUTs7QUFFaEcsZUFBTztNQUNYO01BU0Esa0JBQWtCLFlBQXlCLFVBQW1CO0FBQzFELFlBQUksY0FBYyxZQUFZLFNBQVMsU0FBUyxhQUFhLE1BQU07QUFDL0QsaUJBQU8sS0FBSyxtQkFBbUIsV0FBWSxXQUE4QixJQUFJO21CQUN0RSxjQUFjLFlBQVksU0FBUyxTQUFTLGFBQWEsVUFBVTtBQUMxRSxnQkFBTSxXQUFXLEtBQUssTUFBTyxXQUFrQyxLQUFNO0FBQ3JFLGlCQUFPLFdBQVcsU0FBUyxVQUFVLFNBQVMsU0FBUyxlQUFlLFNBQVM7O0FBRW5GLGVBQU87TUFDWDs7eUJBdEhTLDJCQUF3Qix1QkFBQSxjQUFBLEdBQUEsdUJBQUEsa0JBQUEsQ0FBQTtNQUFBO29FQUF4QiwyQkFBd0IsU0FBeEIsMEJBQXdCLFdBQUEsWUFEWCxPQUFNLENBQUE7Ozs7IiwibmFtZXMiOltdfQ==