import {
  require_showdown
} from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-EHACWY3D.js?v=b97f8625";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NI5XS6XH.js?v=b97f8625";
export default require_showdown();
//# sourceMappingURL=showdown.js.map
