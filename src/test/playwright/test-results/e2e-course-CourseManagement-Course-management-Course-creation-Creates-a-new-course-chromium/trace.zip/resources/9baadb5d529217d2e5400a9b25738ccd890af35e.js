import {
  __commonJS
} from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NI5XS6XH.js?v=b97f8625";

// node_modules/showdown-katex/dist/showdown-katex.js
var require_showdown_katex = __commonJS({
  "node_modules/showdown-katex/dist/showdown-katex.js"(exports, module) {
    (function(global2, factory) {
      typeof exports === "object" && typeof module !== "undefined" ? module.exports = factory() : typeof define === "function" && define.amd ? define(factory) : global2.showdownKatex = factory();
    })(exports, function() {
      "use strict";
      var commonjsGlobal = typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
      function unwrapExports(x) {
        return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
      }
      function createCommonjsModule(fn, module2) {
        return module2 = { exports: {} }, fn(module2, module2.exports), module2.exports;
      }
      var katex = createCommonjsModule(function(module2, exports2) {
        (function webpackUniversalModuleDefinition(root, factory) {
          module2.exports = factory();
        })(typeof self !== "undefined" ? self : commonjsGlobal, function() {
          return (
            /******/
            function(modules) {
              var installedModules = {};
              function __webpack_require__(moduleId) {
                if (installedModules[moduleId]) {
                  return installedModules[moduleId].exports;
                }
                var module3 = installedModules[moduleId] = {
                  /******/
                  i: moduleId,
                  /******/
                  l: false,
                  /******/
                  exports: {}
                  /******/
                };
                modules[moduleId].call(module3.exports, module3, module3.exports, __webpack_require__);
                module3.l = true;
                return module3.exports;
              }
              __webpack_require__.m = modules;
              __webpack_require__.c = installedModules;
              __webpack_require__.d = function(exports3, name, getter) {
                if (!__webpack_require__.o(exports3, name)) {
                  Object.defineProperty(exports3, name, { enumerable: true, get: getter });
                }
              };
              __webpack_require__.r = function(exports3) {
                if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
                  Object.defineProperty(exports3, Symbol.toStringTag, { value: "Module" });
                }
                Object.defineProperty(exports3, "__esModule", { value: true });
              };
              __webpack_require__.t = function(value, mode) {
                if (mode & 1)
                  value = __webpack_require__(value);
                if (mode & 8)
                  return value;
                if (mode & 4 && typeof value === "object" && value && value.__esModule)
                  return value;
                var ns = /* @__PURE__ */ Object.create(null);
                __webpack_require__.r(ns);
                Object.defineProperty(ns, "default", { enumerable: true, value });
                if (mode & 2 && typeof value != "string")
                  for (var key in value)
                    __webpack_require__.d(ns, key, (function(key2) {
                      return value[key2];
                    }).bind(null, key));
                return ns;
              };
              __webpack_require__.n = function(module3) {
                var getter = module3 && module3.__esModule ? (
                  /******/
                  function getDefault() {
                    return module3["default"];
                  }
                ) : (
                  /******/
                  function getModuleExports() {
                    return module3;
                  }
                );
                __webpack_require__.d(getter, "a", getter);
                return getter;
              };
              __webpack_require__.o = function(object, property) {
                return Object.prototype.hasOwnProperty.call(object, property);
              };
              __webpack_require__.p = "";
              return __webpack_require__(__webpack_require__.s = 2);
            }([
              /* 0 */
              /***/
              function(module3, exports3, __webpack_require__) {
              },
              ,
              /* 2 */
              /***/
              function(module3, __webpack_exports__, __webpack_require__) {
                "use strict";
                __webpack_require__.r(__webpack_exports__);
                var katex2 = __webpack_require__(0);
                var SourceLocation = function() {
                  function SourceLocation2(lexer, start, end) {
                    this.lexer = void 0;
                    this.start = void 0;
                    this.end = void 0;
                    this.lexer = lexer;
                    this.start = start;
                    this.end = end;
                  }
                  var _proto = SourceLocation2.prototype;
                  _proto.getSource = function getSource() {
                    return this.lexer.input.slice(this.start, this.end);
                  };
                  SourceLocation2.range = function range(first, second) {
                    if (!second) {
                      return first && first.loc;
                    } else if (!first || !first.loc || !second.loc || first.loc.lexer !== second.loc.lexer) {
                      return null;
                    } else {
                      return new SourceLocation2(first.loc.lexer, first.loc.start, second.loc.end);
                    }
                  };
                  return SourceLocation2;
                }();
                var Token_Token = function() {
                  function Token(text, loc) {
                    this.text = void 0;
                    this.loc = void 0;
                    this.text = text;
                    this.loc = loc;
                  }
                  var _proto = Token.prototype;
                  _proto.range = function range(endToken, text) {
                    return new Token(text, SourceLocation.range(this, endToken));
                  };
                  return Token;
                }();
                var ParseError = (
                  // Error position based on passed-in Token or ParseNode.
                  function ParseError2(message, token) {
                    this.position = void 0;
                    var error = "KaTeX parse error: " + message;
                    var start;
                    var loc = token && token.loc;
                    if (loc && loc.start <= loc.end) {
                      var input = loc.lexer.input;
                      start = loc.start;
                      var end = loc.end;
                      if (start === input.length) {
                        error += " at end of input: ";
                      } else {
                        error += " at position " + (start + 1) + ": ";
                      }
                      var underlined = input.slice(start, end).replace(/[^]/g, "$&̲");
                      var left;
                      if (start > 15) {
                        left = "…" + input.slice(start - 15, start);
                      } else {
                        left = input.slice(0, start);
                      }
                      var right;
                      if (end + 15 < input.length) {
                        right = input.slice(end, end + 15) + "…";
                      } else {
                        right = input.slice(end);
                      }
                      error += left + underlined + right;
                    }
                    var self2 = new Error(error);
                    self2.name = "ParseError";
                    self2.__proto__ = ParseError2.prototype;
                    self2.position = start;
                    return self2;
                  }
                );
                ParseError.prototype.__proto__ = Error.prototype;
                var src_ParseError = ParseError;
                var contains = function contains2(list, elem) {
                  return list.indexOf(elem) !== -1;
                };
                var deflt = function deflt2(setting, defaultIfUndefined) {
                  return setting === void 0 ? defaultIfUndefined : setting;
                };
                var uppercase = /([A-Z])/g;
                var hyphenate = function hyphenate2(str) {
                  return str.replace(uppercase, "-$1").toLowerCase();
                };
                var ESCAPE_LOOKUP = {
                  "&": "&amp;",
                  ">": "&gt;",
                  "<": "&lt;",
                  '"': "&quot;",
                  "'": "&#x27;"
                };
                var ESCAPE_REGEX = /[&><"']/g;
                function utils_escape(text) {
                  return String(text).replace(ESCAPE_REGEX, function(match) {
                    return ESCAPE_LOOKUP[match];
                  });
                }
                var getBaseElem = function getBaseElem2(group) {
                  if (group.type === "ordgroup") {
                    if (group.body.length === 1) {
                      return getBaseElem2(group.body[0]);
                    } else {
                      return group;
                    }
                  } else if (group.type === "color") {
                    if (group.body.length === 1) {
                      return getBaseElem2(group.body[0]);
                    } else {
                      return group;
                    }
                  } else if (group.type === "font") {
                    return getBaseElem2(group.body);
                  } else {
                    return group;
                  }
                };
                var utils_isCharacterBox = function isCharacterBox(group) {
                  var baseElem = getBaseElem(group);
                  return baseElem.type === "mathord" || baseElem.type === "textord" || baseElem.type === "atom";
                };
                var assert = function assert2(value) {
                  if (!value) {
                    throw new Error("Expected non-null, but got " + String(value));
                  }
                  return value;
                };
                var utils = {
                  contains,
                  deflt,
                  escape: utils_escape,
                  hyphenate,
                  getBaseElem,
                  isCharacterBox: utils_isCharacterBox
                };
                var Settings_Settings = function() {
                  function Settings(options) {
                    this.displayMode = void 0;
                    this.throwOnError = void 0;
                    this.errorColor = void 0;
                    this.macros = void 0;
                    this.colorIsTextColor = void 0;
                    this.strict = void 0;
                    this.maxSize = void 0;
                    this.maxExpand = void 0;
                    this.allowedProtocols = void 0;
                    options = options || {};
                    this.displayMode = utils.deflt(options.displayMode, false);
                    this.throwOnError = utils.deflt(options.throwOnError, true);
                    this.errorColor = utils.deflt(options.errorColor, "#cc0000");
                    this.macros = options.macros || {};
                    this.colorIsTextColor = utils.deflt(options.colorIsTextColor, false);
                    this.strict = utils.deflt(options.strict, "warn");
                    this.maxSize = Math.max(0, utils.deflt(options.maxSize, Infinity));
                    this.maxExpand = Math.max(0, utils.deflt(options.maxExpand, 1e3));
                    this.allowedProtocols = utils.deflt(options.allowedProtocols, ["http", "https", "mailto", "_relative"]);
                  }
                  var _proto = Settings.prototype;
                  _proto.reportNonstrict = function reportNonstrict(errorCode, errorMsg, token) {
                    var strict = this.strict;
                    if (typeof strict === "function") {
                      strict = strict(errorCode, errorMsg, token);
                    }
                    if (!strict || strict === "ignore") {
                      return;
                    } else if (strict === true || strict === "error") {
                      throw new src_ParseError("LaTeX-incompatible input and strict mode is set to 'error': " + (errorMsg + " [" + errorCode + "]"), token);
                    } else if (strict === "warn") {
                      typeof console !== "undefined" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (errorMsg + " [" + errorCode + "]"));
                    } else {
                      typeof console !== "undefined" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + strict + "': " + errorMsg + " [" + errorCode + "]"));
                    }
                  };
                  _proto.useStrictBehavior = function useStrictBehavior(errorCode, errorMsg, token) {
                    var strict = this.strict;
                    if (typeof strict === "function") {
                      try {
                        strict = strict(errorCode, errorMsg, token);
                      } catch (error) {
                        strict = "error";
                      }
                    }
                    if (!strict || strict === "ignore") {
                      return false;
                    } else if (strict === true || strict === "error") {
                      return true;
                    } else if (strict === "warn") {
                      typeof console !== "undefined" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (errorMsg + " [" + errorCode + "]"));
                      return false;
                    } else {
                      typeof console !== "undefined" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + strict + "': " + errorMsg + " [" + errorCode + "]"));
                      return false;
                    }
                  };
                  return Settings;
                }();
                var src_Settings = Settings_Settings;
                var Style = function() {
                  function Style2(id, size, cramped) {
                    this.id = void 0;
                    this.size = void 0;
                    this.cramped = void 0;
                    this.id = id;
                    this.size = size;
                    this.cramped = cramped;
                  }
                  var _proto = Style2.prototype;
                  _proto.sup = function sup() {
                    return Style_styles[_sup[this.id]];
                  };
                  _proto.sub = function sub() {
                    return Style_styles[_sub[this.id]];
                  };
                  _proto.fracNum = function fracNum() {
                    return Style_styles[_fracNum[this.id]];
                  };
                  _proto.fracDen = function fracDen() {
                    return Style_styles[_fracDen[this.id]];
                  };
                  _proto.cramp = function cramp() {
                    return Style_styles[_cramp[this.id]];
                  };
                  _proto.text = function text() {
                    return Style_styles[_text[this.id]];
                  };
                  _proto.isTight = function isTight() {
                    return this.size >= 2;
                  };
                  return Style2;
                }();
                var D = 0;
                var Dc = 1;
                var T = 2;
                var Tc = 3;
                var S = 4;
                var Sc = 5;
                var SS = 6;
                var SSc = 7;
                var Style_styles = [new Style(D, 0, false), new Style(Dc, 0, true), new Style(T, 1, false), new Style(Tc, 1, true), new Style(S, 2, false), new Style(Sc, 2, true), new Style(SS, 3, false), new Style(SSc, 3, true)];
                var _sup = [S, Sc, S, Sc, SS, SSc, SS, SSc];
                var _sub = [Sc, Sc, Sc, Sc, SSc, SSc, SSc, SSc];
                var _fracNum = [T, Tc, S, Sc, SS, SSc, SS, SSc];
                var _fracDen = [Tc, Tc, Sc, Sc, SSc, SSc, SSc, SSc];
                var _cramp = [Dc, Dc, Tc, Tc, Sc, Sc, SSc, SSc];
                var _text = [D, Dc, T, Tc, T, Tc, T, Tc];
                var src_Style = {
                  DISPLAY: Style_styles[D],
                  TEXT: Style_styles[T],
                  SCRIPT: Style_styles[S],
                  SCRIPTSCRIPT: Style_styles[SS]
                };
                var scriptData = [{
                  // Latin characters beyond the Latin-1 characters we have metrics for.
                  // Needed for Czech, Hungarian and Turkish text, for example.
                  name: "latin",
                  blocks: [
                    [256, 591],
                    // Latin Extended-A and Latin Extended-B
                    [768, 879]
                  ]
                }, {
                  // The Cyrillic script used by Russian and related languages.
                  // A Cyrillic subset used to be supported as explicitly defined
                  // symbols in symbols.js
                  name: "cyrillic",
                  blocks: [[1024, 1279]]
                }, {
                  // The Brahmic scripts of South and Southeast Asia
                  // Devanagari (0900–097F)
                  // Bengali (0980–09FF)
                  // Gurmukhi (0A00–0A7F)
                  // Gujarati (0A80–0AFF)
                  // Oriya (0B00–0B7F)
                  // Tamil (0B80–0BFF)
                  // Telugu (0C00–0C7F)
                  // Kannada (0C80–0CFF)
                  // Malayalam (0D00–0D7F)
                  // Sinhala (0D80–0DFF)
                  // Thai (0E00–0E7F)
                  // Lao (0E80–0EFF)
                  // Tibetan (0F00–0FFF)
                  // Myanmar (1000–109F)
                  name: "brahmic",
                  blocks: [[2304, 4255]]
                }, {
                  name: "georgian",
                  blocks: [[4256, 4351]]
                }, {
                  // Chinese and Japanese.
                  // The "k" in cjk is for Korean, but we've separated Korean out
                  name: "cjk",
                  blocks: [
                    [12288, 12543],
                    // CJK symbols and punctuation, Hiragana, Katakana
                    [19968, 40879],
                    // CJK ideograms
                    [65280, 65376]
                  ]
                }, {
                  // Korean
                  name: "hangul",
                  blocks: [[44032, 55215]]
                }];
                function scriptFromCodepoint(codepoint) {
                  for (var i = 0; i < scriptData.length; i++) {
                    var script = scriptData[i];
                    for (var _i = 0; _i < script.blocks.length; _i++) {
                      var block = script.blocks[_i];
                      if (codepoint >= block[0] && codepoint <= block[1]) {
                        return script.name;
                      }
                    }
                  }
                  return null;
                }
                var allBlocks = [];
                scriptData.forEach(function(s) {
                  return s.blocks.forEach(function(b) {
                    return allBlocks.push.apply(allBlocks, b);
                  });
                });
                function supportedCodepoint(codepoint) {
                  for (var i = 0; i < allBlocks.length; i += 2) {
                    if (codepoint >= allBlocks[i] && codepoint <= allBlocks[i + 1]) {
                      return true;
                    }
                  }
                  return false;
                }
                var hLinePad = 80;
                var svgGeometry_path = {
                  // sqrtMain path geometry is from glyph U221A in the font KaTeX Main
                  // All surds have 80 units padding above the viniculumn.
                  sqrtMain: "M95," + (622 + hLinePad) + "c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,\n-10,-9.5,-14c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54c44.2,-33.3,65.8,\n-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10s173,378,173,378c0.7,0,\n35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429c69,-144,104.5,-217.7,106.5,\n-221c5.3,-9.3,12,-14,20,-14H400000v40H845.2724s-225.272,467,-225.272,467\ns-235,486,-235,486c-2.7,4.7,-9,7,-19,7c-6,0,-10,-1,-12,-3s-194,-422,-194,-422\ns-65,47,-65,47z M834 " + hLinePad + "H400000v40H845z",
                  // size1 is from glyph U221A in the font KaTeX_Size1-Regular
                  sqrtSize1: "M263," + (601 + hLinePad) + "c0.7,0,18,39.7,52,119c34,79.3,68.167,\n158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120c340,-704.7,510.7,-1060.3,512,-1067\nc4.7,-7.3,11,-11,19,-11H40000v40H1012.3s-271.3,567,-271.3,567c-38.7,80.7,-84,\n175,-136,283c-52,108,-89.167,185.3,-111.5,232c-22.3,46.7,-33.8,70.3,-34.5,71\nc-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1s-109,-253,-109,-253c-72.7,-168,-109.3,\n-252,-110,-252c-10.7,8,-22,16.7,-34,26c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26\ns76,-59,76,-59s76,-60,76,-60z M1001 " + hLinePad + "H40000v40H1012z",
                  // size2 is from glyph U221A in the font KaTeX_Size2-Regular
                  // The 80 units padding is most obvious here. Note start node at M1001 80.
                  sqrtSize2: "M1001," + hLinePad + "H400000v40H1013.1s-83.4,268,-264.1,840c-180.7,\n572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,\n-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744c-10,12,-21,25,-33,39s-32,39,-32,39\nc-6,-5.3,-15,-14,-27,-26s25,-30,25,-30c26.7,-32.7,52,-63,76,-91s52,-60,52,-60\ns208,722,208,722c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,\n-658.5c53.7,-170.3,84.5,-266.8,92.5,-289.5c4,-6.7,10,-10,18,-10z\nM1001 " + hLinePad + "H400000v40H1013z",
                  // size3 is from glyph U221A in the font KaTeX_Size3-Regular
                  sqrtSize3: "M424," + (2398 + hLinePad) + "c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,\n-342,-109.8,-513.3,-110.5,-514c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,\n25c-5.7,9.3,-9.8,16,-12.5,20s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,\n-13s76,-122,76,-122s77,-121,77,-121s209,968,209,968c0,-2,84.7,-361.7,254,-1079\nc169.3,-717.3,254.7,-1077.7,256,-1081c4,-6.7,10,-10,18,-10H400000v40H1014.6\ns-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185c-2,6,-10,9,-24,9\nc-8,0,-12,-0.7,-12,-2z M1001 " + hLinePad + "H400000v40H1014z",
                  // size4 is from glyph U221A in the font KaTeX_Size4-Regular
                  sqrtSize4: "M473," + (2713 + hLinePad) + "c339.3,-1799.3,509.3,-2700,510,-2702\nc3.3,-7.3,9.3,-11,18,-11H400000v40H1017.7s-90.5,478,-276.2,1466c-185.7,988,\n-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,\n-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200c0,-1.3,-5.3,8.7,-16,30c-10.7,\n21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26s76,-153,76,-153s77,-151,\n77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,606z\nM1001 " + hLinePad + "H400000v40H1017z",
                  // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
                  doubleleftarrow: "M262 157\nl10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3\n 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28\n 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5\nc2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5\n 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87\n-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7\n-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z\nm8 0v40h399730v-40zm0 194v40h399730v-40z",
                  // doublerightarrow is from glyph U+21D2 in font KaTeX Main
                  doublerightarrow: "M399738 392l\n-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5\n 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88\n-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68\n-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18\n-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782\nc-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3\n-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z",
                  // leftarrow is from glyph U+2190 in font KaTeX Main
                  leftarrow: "M400000 241H110l3-3c68.7-52.7 113.7-120\n 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8\n-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247\nc-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208\n 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3\n 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202\n l-3-3h399890zM100 241v40h399900v-40z",
                  // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
                  leftbrace: "M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117\n-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7\n 5-6 9-10 13-.7 1-7.3 1-20 1H6z",
                  leftbraceunder: "M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13\n 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688\n 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7\n-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z",
                  // overgroup is from the MnSymbol package (public domain)
                  leftgroup: "M400000 80\nH435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0\n 435 0h399565z",
                  leftgroupunder: "M400000 262\nH435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219\n 435 219h399565z",
                  // Harpoons are from glyph U+21BD in font KaTeX Main
                  leftharpoon: "M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3\n-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5\n-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7\n-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z",
                  leftharpoonplus: "M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5\n 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3\n-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7\n-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z\nm0 0v40h400000v-40z",
                  leftharpoondown: "M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333\n 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5\n 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667\n-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z",
                  leftharpoondownplus: "M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12\n 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7\n-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0\nv40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z",
                  // hook is from glyph U+21A9 in font KaTeX Main
                  lefthook: "M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5\n-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3\n-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21\n 71.5 23h399859zM103 281v-40h399897v40z",
                  leftlinesegment: "M40 281 V428 H0 V94 H40 V241 H400000 v40z\nM40 281 V428 H0 V94 H40 V241 H400000 v40z",
                  leftmapsto: "M40 281 V448H0V74H40V241H400000v40z\nM40 281 V448H0V74H40V241H400000v40z",
                  // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
                  leftToFrom: "M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23\n-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8\nc28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3\n 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z",
                  longequal: "M0 50 h400000 v40H0z m0 194h40000v40H0z\nM0 50 h400000 v40H0z m0 194h40000v40H0z",
                  midbrace: "M200428 334\nc-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14\n-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7\n 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11\n 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z",
                  midbraceunder: "M199572 214\nc100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14\n 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3\n 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0\n-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z",
                  oiintSize1: "M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6\n-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z\nm368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8\n60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z",
                  oiintSize2: "M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8\n-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z\nm502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2\nc0 110 84 276 504 276s502.4-166 502.4-276z",
                  oiiintSize1: "M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6\n-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z\nm525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0\n85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z",
                  oiiintSize2: "M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8\n-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z\nm770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1\nc0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z",
                  rightarrow: "M0 241v40h399891c-47.3 35.3-84 78-110 128\n-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20\n 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7\n 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85\n-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5\n-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67\n 151.7 139 205zm0 0v40h399900v-40z",
                  rightbrace: "M400000 542l\n-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5\ns-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1\nc124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z",
                  rightbraceunder: "M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3\n 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237\n-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z",
                  rightgroup: "M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0\n 3-1 3-3v-38c-76-158-257-219-435-219H0z",
                  rightgroupunder: "M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18\n 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z",
                  rightharpoon: "M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3\n-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2\n-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58\n 69.2 92 94.5zm0 0v40h399900v-40z",
                  rightharpoonplus: "M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11\n-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7\n 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z\nm0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z",
                  rightharpoondown: "M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8\n 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5\n-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95\n-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z",
                  rightharpoondownplus: "M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8\n 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3\n 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3\n-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z\nm0-194v40h400000v-40zm0 0v40h400000v-40z",
                  righthook: "M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3\n 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0\n-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21\n 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z",
                  rightlinesegment: "M399960 241 V94 h40 V428 h-40 V281 H0 v-40z\nM399960 241 V94 h40 V428 h-40 V281 H0 v-40z",
                  rightToFrom: "M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23\n 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32\n-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142\n-167z M100 147v40h399900v-40zM0 341v40h399900v-40z",
                  // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
                  twoheadleftarrow: "M0 167c68 40\n 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69\n-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3\n-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19\n-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101\n 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z",
                  twoheadrightarrow: "M400000 167\nc-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3\n 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42\n 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333\n-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70\n 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z",
                  // tilde1 is a modified version of a glyph from the MnSymbol package
                  tilde1: "M200 55.538c-77 0-168 73.953-177 73.953-3 0-7\n-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0\n 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0\n 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128\n-68.267.847-113-73.952-191-73.952z",
                  // ditto tilde2, tilde3, & tilde4
                  tilde2: "M344 55.266c-142 0-300.638 81.316-311.5 86.418\n-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9\n 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114\nc1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751\n 181.476 676 181.476c-149 0-189-126.21-332-126.21z",
                  tilde3: "M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457\n-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0\n 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697\n 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696\n -338 0-409-156.573-744-156.573z",
                  tilde4: "M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345\n-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409\n 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9\n 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409\n -175.236-744-175.236z",
                  // vec is from glyph U+20D7 in font KaTeX Main
                  vec: "M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5\n3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11\n10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63\n-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1\n-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59\nH213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359\nc-16-25.333-24-45-24-59z",
                  // widehat1 is a modified version of a glyph from the MnSymbol package
                  widehat1: "M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22\nc-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z",
                  // ditto widehat2, widehat3, & widehat4
                  widehat2: "M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
                  widehat3: "M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
                  widehat4: "M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
                  // widecheck paths are all inverted versions of widehat
                  widecheck1: "M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,\n-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z",
                  widecheck2: "M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
                  widecheck3: "M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
                  widecheck4: "M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
                  // The next ten paths support reaction arrows from the mhchem package.
                  // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
                  // baraboveleftarrow is mostly from from glyph U+2190 in font KaTeX Main
                  baraboveleftarrow: "M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202\nc4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5\nc-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130\ns-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47\n121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6\ns2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11\nc0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z\nM100 241v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z",
                  // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
                  rightarrowabovebar: "M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32\n-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0\n13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39\n-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5\n-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5\n-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67\n151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z",
                  // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
                  // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
                  baraboveshortleftharpoon: "M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11\nc1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17\nc2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21\nc-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40\nc-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z\nM0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z",
                  rightharpoonaboveshortbar: "M0,241 l0,40c399126,0,399993,0,399993,0\nc4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,\n-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6\nc-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z\nM0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z",
                  shortbaraboveleftharpoon: "M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11\nc1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,\n1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,\n-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z\nM93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z",
                  shortrightharpoonabovebar: "M53,241l0,40c398570,0,399437,0,399437,0\nc4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,\n-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6\nc-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z\nM500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z"
                };
                var svgGeometry = {
                  path: svgGeometry_path
                };
                var tree_DocumentFragment = function() {
                  function DocumentFragment(children) {
                    this.children = void 0;
                    this.classes = void 0;
                    this.height = void 0;
                    this.depth = void 0;
                    this.maxFontSize = void 0;
                    this.style = void 0;
                    this.children = children;
                    this.classes = [];
                    this.height = 0;
                    this.depth = 0;
                    this.maxFontSize = 0;
                    this.style = {};
                  }
                  var _proto = DocumentFragment.prototype;
                  _proto.hasClass = function hasClass(className) {
                    return utils.contains(this.classes, className);
                  };
                  _proto.toNode = function toNode() {
                    var frag = document.createDocumentFragment();
                    for (var i = 0; i < this.children.length; i++) {
                      frag.appendChild(this.children[i].toNode());
                    }
                    return frag;
                  };
                  _proto.toMarkup = function toMarkup() {
                    var markup = "";
                    for (var i = 0; i < this.children.length; i++) {
                      markup += this.children[i].toMarkup();
                    }
                    return markup;
                  };
                  _proto.toText = function toText() {
                    var toText2 = function toText3(child) {
                      return child.toText();
                    };
                    return this.children.map(toText2).join("");
                  };
                  return DocumentFragment;
                }();
                var createClass = function createClass2(classes) {
                  return classes.filter(function(cls) {
                    return cls;
                  }).join(" ");
                };
                var initNode = function initNode2(classes, options, style) {
                  this.classes = classes || [];
                  this.attributes = {};
                  this.height = 0;
                  this.depth = 0;
                  this.maxFontSize = 0;
                  this.style = style || {};
                  if (options) {
                    if (options.style.isTight()) {
                      this.classes.push("mtight");
                    }
                    var color = options.getColor();
                    if (color) {
                      this.style.color = color;
                    }
                  }
                };
                var _toNode = function toNode(tagName) {
                  var node = document.createElement(tagName);
                  node.className = createClass(this.classes);
                  for (var style in this.style) {
                    if (this.style.hasOwnProperty(style)) {
                      node.style[style] = this.style[style];
                    }
                  }
                  for (var attr in this.attributes) {
                    if (this.attributes.hasOwnProperty(attr)) {
                      node.setAttribute(attr, this.attributes[attr]);
                    }
                  }
                  for (var i = 0; i < this.children.length; i++) {
                    node.appendChild(this.children[i].toNode());
                  }
                  return node;
                };
                var _toMarkup = function toMarkup(tagName) {
                  var markup = "<" + tagName;
                  if (this.classes.length) {
                    markup += ' class="' + utils.escape(createClass(this.classes)) + '"';
                  }
                  var styles = "";
                  for (var style in this.style) {
                    if (this.style.hasOwnProperty(style)) {
                      styles += utils.hyphenate(style) + ":" + this.style[style] + ";";
                    }
                  }
                  if (styles) {
                    markup += ' style="' + utils.escape(styles) + '"';
                  }
                  for (var attr in this.attributes) {
                    if (this.attributes.hasOwnProperty(attr)) {
                      markup += " " + attr + '="' + utils.escape(this.attributes[attr]) + '"';
                    }
                  }
                  markup += ">";
                  for (var i = 0; i < this.children.length; i++) {
                    markup += this.children[i].toMarkup();
                  }
                  markup += "</" + tagName + ">";
                  return markup;
                };
                var domTree_Span = function() {
                  function Span(classes, children, options, style) {
                    this.children = void 0;
                    this.attributes = void 0;
                    this.classes = void 0;
                    this.height = void 0;
                    this.depth = void 0;
                    this.width = void 0;
                    this.maxFontSize = void 0;
                    this.style = void 0;
                    initNode.call(this, classes, options, style);
                    this.children = children || [];
                  }
                  var _proto = Span.prototype;
                  _proto.setAttribute = function setAttribute(attribute, value) {
                    this.attributes[attribute] = value;
                  };
                  _proto.hasClass = function hasClass(className) {
                    return utils.contains(this.classes, className);
                  };
                  _proto.toNode = function toNode() {
                    return _toNode.call(this, "span");
                  };
                  _proto.toMarkup = function toMarkup() {
                    return _toMarkup.call(this, "span");
                  };
                  return Span;
                }();
                var domTree_Anchor = function() {
                  function Anchor(href, classes, children, options) {
                    this.children = void 0;
                    this.attributes = void 0;
                    this.classes = void 0;
                    this.height = void 0;
                    this.depth = void 0;
                    this.maxFontSize = void 0;
                    this.style = void 0;
                    initNode.call(this, classes, options);
                    this.children = children || [];
                    this.setAttribute("href", href);
                  }
                  var _proto2 = Anchor.prototype;
                  _proto2.setAttribute = function setAttribute(attribute, value) {
                    this.attributes[attribute] = value;
                  };
                  _proto2.hasClass = function hasClass(className) {
                    return utils.contains(this.classes, className);
                  };
                  _proto2.toNode = function toNode() {
                    return _toNode.call(this, "a");
                  };
                  _proto2.toMarkup = function toMarkup() {
                    return _toMarkup.call(this, "a");
                  };
                  return Anchor;
                }();
                var iCombinations = {
                  "î": "ı̂",
                  "ï": "ı̈",
                  "í": "ı́",
                  // 'ī': '\u0131\u0304', // enable when we add Extended Latin
                  "ì": "ı̀"
                };
                var domTree_SymbolNode = function() {
                  function SymbolNode(text, height, depth, italic, skew, width, classes, style) {
                    this.text = void 0;
                    this.height = void 0;
                    this.depth = void 0;
                    this.italic = void 0;
                    this.skew = void 0;
                    this.width = void 0;
                    this.maxFontSize = void 0;
                    this.classes = void 0;
                    this.style = void 0;
                    this.text = text;
                    this.height = height || 0;
                    this.depth = depth || 0;
                    this.italic = italic || 0;
                    this.skew = skew || 0;
                    this.width = width || 0;
                    this.classes = classes || [];
                    this.style = style || {};
                    this.maxFontSize = 0;
                    var script = scriptFromCodepoint(this.text.charCodeAt(0));
                    if (script) {
                      this.classes.push(script + "_fallback");
                    }
                    if (/[îïíì]/.test(this.text)) {
                      this.text = iCombinations[this.text];
                    }
                  }
                  var _proto3 = SymbolNode.prototype;
                  _proto3.hasClass = function hasClass(className) {
                    return utils.contains(this.classes, className);
                  };
                  _proto3.toNode = function toNode() {
                    var node = document.createTextNode(this.text);
                    var span = null;
                    if (this.italic > 0) {
                      span = document.createElement("span");
                      span.style.marginRight = this.italic + "em";
                    }
                    if (this.classes.length > 0) {
                      span = span || document.createElement("span");
                      span.className = createClass(this.classes);
                    }
                    for (var style in this.style) {
                      if (this.style.hasOwnProperty(style)) {
                        span = span || document.createElement("span");
                        span.style[style] = this.style[style];
                      }
                    }
                    if (span) {
                      span.appendChild(node);
                      return span;
                    } else {
                      return node;
                    }
                  };
                  _proto3.toMarkup = function toMarkup() {
                    var needsSpan = false;
                    var markup = "<span";
                    if (this.classes.length) {
                      needsSpan = true;
                      markup += ' class="';
                      markup += utils.escape(createClass(this.classes));
                      markup += '"';
                    }
                    var styles = "";
                    if (this.italic > 0) {
                      styles += "margin-right:" + this.italic + "em;";
                    }
                    for (var style in this.style) {
                      if (this.style.hasOwnProperty(style)) {
                        styles += utils.hyphenate(style) + ":" + this.style[style] + ";";
                      }
                    }
                    if (styles) {
                      needsSpan = true;
                      markup += ' style="' + utils.escape(styles) + '"';
                    }
                    var escaped = utils.escape(this.text);
                    if (needsSpan) {
                      markup += ">";
                      markup += escaped;
                      markup += "</span>";
                      return markup;
                    } else {
                      return escaped;
                    }
                  };
                  return SymbolNode;
                }();
                var SvgNode = function() {
                  function SvgNode2(children, attributes) {
                    this.children = void 0;
                    this.attributes = void 0;
                    this.children = children || [];
                    this.attributes = attributes || {};
                  }
                  var _proto4 = SvgNode2.prototype;
                  _proto4.toNode = function toNode() {
                    var svgNS = "http://www.w3.org/2000/svg";
                    var node = document.createElementNS(svgNS, "svg");
                    for (var attr in this.attributes) {
                      if (Object.prototype.hasOwnProperty.call(this.attributes, attr)) {
                        node.setAttribute(attr, this.attributes[attr]);
                      }
                    }
                    for (var i = 0; i < this.children.length; i++) {
                      node.appendChild(this.children[i].toNode());
                    }
                    return node;
                  };
                  _proto4.toMarkup = function toMarkup() {
                    var markup = "<svg";
                    for (var attr in this.attributes) {
                      if (Object.prototype.hasOwnProperty.call(this.attributes, attr)) {
                        markup += " " + attr + "='" + this.attributes[attr] + "'";
                      }
                    }
                    markup += ">";
                    for (var i = 0; i < this.children.length; i++) {
                      markup += this.children[i].toMarkup();
                    }
                    markup += "</svg>";
                    return markup;
                  };
                  return SvgNode2;
                }();
                var domTree_PathNode = function() {
                  function PathNode(pathName, alternate) {
                    this.pathName = void 0;
                    this.alternate = void 0;
                    this.pathName = pathName;
                    this.alternate = alternate;
                  }
                  var _proto5 = PathNode.prototype;
                  _proto5.toNode = function toNode() {
                    var svgNS = "http://www.w3.org/2000/svg";
                    var node = document.createElementNS(svgNS, "path");
                    if (this.alternate) {
                      node.setAttribute("d", this.alternate);
                    } else {
                      node.setAttribute("d", svgGeometry.path[this.pathName]);
                    }
                    return node;
                  };
                  _proto5.toMarkup = function toMarkup() {
                    if (this.alternate) {
                      return "<path d='" + this.alternate + "'/>";
                    } else {
                      return "<path d='" + svgGeometry.path[this.pathName] + "'/>";
                    }
                  };
                  return PathNode;
                }();
                var LineNode = function() {
                  function LineNode2(attributes) {
                    this.attributes = void 0;
                    this.attributes = attributes || {};
                  }
                  var _proto6 = LineNode2.prototype;
                  _proto6.toNode = function toNode() {
                    var svgNS = "http://www.w3.org/2000/svg";
                    var node = document.createElementNS(svgNS, "line");
                    for (var attr in this.attributes) {
                      if (Object.prototype.hasOwnProperty.call(this.attributes, attr)) {
                        node.setAttribute(attr, this.attributes[attr]);
                      }
                    }
                    return node;
                  };
                  _proto6.toMarkup = function toMarkup() {
                    var markup = "<line";
                    for (var attr in this.attributes) {
                      if (Object.prototype.hasOwnProperty.call(this.attributes, attr)) {
                        markup += " " + attr + "='" + this.attributes[attr] + "'";
                      }
                    }
                    markup += "/>";
                    return markup;
                  };
                  return LineNode2;
                }();
                function assertSymbolDomNode(group) {
                  if (group instanceof domTree_SymbolNode) {
                    return group;
                  } else {
                    throw new Error("Expected symbolNode but got " + String(group) + ".");
                  }
                }
                function assertSpan(group) {
                  if (group instanceof domTree_Span) {
                    return group;
                  } else {
                    throw new Error("Expected span<HtmlDomNode> but got " + String(group) + ".");
                  }
                }
                var fontMetricsData = {
                  "AMS-Regular": {
                    "65": [0, 0.68889, 0, 0, 0.72222],
                    "66": [0, 0.68889, 0, 0, 0.66667],
                    "67": [0, 0.68889, 0, 0, 0.72222],
                    "68": [0, 0.68889, 0, 0, 0.72222],
                    "69": [0, 0.68889, 0, 0, 0.66667],
                    "70": [0, 0.68889, 0, 0, 0.61111],
                    "71": [0, 0.68889, 0, 0, 0.77778],
                    "72": [0, 0.68889, 0, 0, 0.77778],
                    "73": [0, 0.68889, 0, 0, 0.38889],
                    "74": [0.16667, 0.68889, 0, 0, 0.5],
                    "75": [0, 0.68889, 0, 0, 0.77778],
                    "76": [0, 0.68889, 0, 0, 0.66667],
                    "77": [0, 0.68889, 0, 0, 0.94445],
                    "78": [0, 0.68889, 0, 0, 0.72222],
                    "79": [0.16667, 0.68889, 0, 0, 0.77778],
                    "80": [0, 0.68889, 0, 0, 0.61111],
                    "81": [0.16667, 0.68889, 0, 0, 0.77778],
                    "82": [0, 0.68889, 0, 0, 0.72222],
                    "83": [0, 0.68889, 0, 0, 0.55556],
                    "84": [0, 0.68889, 0, 0, 0.66667],
                    "85": [0, 0.68889, 0, 0, 0.72222],
                    "86": [0, 0.68889, 0, 0, 0.72222],
                    "87": [0, 0.68889, 0, 0, 1],
                    "88": [0, 0.68889, 0, 0, 0.72222],
                    "89": [0, 0.68889, 0, 0, 0.72222],
                    "90": [0, 0.68889, 0, 0, 0.66667],
                    "107": [0, 0.68889, 0, 0, 0.55556],
                    "165": [0, 0.675, 0.025, 0, 0.75],
                    "174": [0.15559, 0.69224, 0, 0, 0.94666],
                    "240": [0, 0.68889, 0, 0, 0.55556],
                    "295": [0, 0.68889, 0, 0, 0.54028],
                    "710": [0, 0.825, 0, 0, 2.33334],
                    "732": [0, 0.9, 0, 0, 2.33334],
                    "770": [0, 0.825, 0, 0, 2.33334],
                    "771": [0, 0.9, 0, 0, 2.33334],
                    "989": [0.08167, 0.58167, 0, 0, 0.77778],
                    "1008": [0, 0.43056, 0.04028, 0, 0.66667],
                    "8245": [0, 0.54986, 0, 0, 0.275],
                    "8463": [0, 0.68889, 0, 0, 0.54028],
                    "8487": [0, 0.68889, 0, 0, 0.72222],
                    "8498": [0, 0.68889, 0, 0, 0.55556],
                    "8502": [0, 0.68889, 0, 0, 0.66667],
                    "8503": [0, 0.68889, 0, 0, 0.44445],
                    "8504": [0, 0.68889, 0, 0, 0.66667],
                    "8513": [0, 0.68889, 0, 0, 0.63889],
                    "8592": [-0.03598, 0.46402, 0, 0, 0.5],
                    "8594": [-0.03598, 0.46402, 0, 0, 0.5],
                    "8602": [-0.13313, 0.36687, 0, 0, 1],
                    "8603": [-0.13313, 0.36687, 0, 0, 1],
                    "8606": [0.01354, 0.52239, 0, 0, 1],
                    "8608": [0.01354, 0.52239, 0, 0, 1],
                    "8610": [0.01354, 0.52239, 0, 0, 1.11111],
                    "8611": [0.01354, 0.52239, 0, 0, 1.11111],
                    "8619": [0, 0.54986, 0, 0, 1],
                    "8620": [0, 0.54986, 0, 0, 1],
                    "8621": [-0.13313, 0.37788, 0, 0, 1.38889],
                    "8622": [-0.13313, 0.36687, 0, 0, 1],
                    "8624": [0, 0.69224, 0, 0, 0.5],
                    "8625": [0, 0.69224, 0, 0, 0.5],
                    "8630": [0, 0.43056, 0, 0, 1],
                    "8631": [0, 0.43056, 0, 0, 1],
                    "8634": [0.08198, 0.58198, 0, 0, 0.77778],
                    "8635": [0.08198, 0.58198, 0, 0, 0.77778],
                    "8638": [0.19444, 0.69224, 0, 0, 0.41667],
                    "8639": [0.19444, 0.69224, 0, 0, 0.41667],
                    "8642": [0.19444, 0.69224, 0, 0, 0.41667],
                    "8643": [0.19444, 0.69224, 0, 0, 0.41667],
                    "8644": [0.1808, 0.675, 0, 0, 1],
                    "8646": [0.1808, 0.675, 0, 0, 1],
                    "8647": [0.1808, 0.675, 0, 0, 1],
                    "8648": [0.19444, 0.69224, 0, 0, 0.83334],
                    "8649": [0.1808, 0.675, 0, 0, 1],
                    "8650": [0.19444, 0.69224, 0, 0, 0.83334],
                    "8651": [0.01354, 0.52239, 0, 0, 1],
                    "8652": [0.01354, 0.52239, 0, 0, 1],
                    "8653": [-0.13313, 0.36687, 0, 0, 1],
                    "8654": [-0.13313, 0.36687, 0, 0, 1],
                    "8655": [-0.13313, 0.36687, 0, 0, 1],
                    "8666": [0.13667, 0.63667, 0, 0, 1],
                    "8667": [0.13667, 0.63667, 0, 0, 1],
                    "8669": [-0.13313, 0.37788, 0, 0, 1],
                    "8672": [-0.064, 0.437, 0, 0, 1.334],
                    "8674": [-0.064, 0.437, 0, 0, 1.334],
                    "8705": [0, 0.825, 0, 0, 0.5],
                    "8708": [0, 0.68889, 0, 0, 0.55556],
                    "8709": [0.08167, 0.58167, 0, 0, 0.77778],
                    "8717": [0, 0.43056, 0, 0, 0.42917],
                    "8722": [-0.03598, 0.46402, 0, 0, 0.5],
                    "8724": [0.08198, 0.69224, 0, 0, 0.77778],
                    "8726": [0.08167, 0.58167, 0, 0, 0.77778],
                    "8733": [0, 0.69224, 0, 0, 0.77778],
                    "8736": [0, 0.69224, 0, 0, 0.72222],
                    "8737": [0, 0.69224, 0, 0, 0.72222],
                    "8738": [0.03517, 0.52239, 0, 0, 0.72222],
                    "8739": [0.08167, 0.58167, 0, 0, 0.22222],
                    "8740": [0.25142, 0.74111, 0, 0, 0.27778],
                    "8741": [0.08167, 0.58167, 0, 0, 0.38889],
                    "8742": [0.25142, 0.74111, 0, 0, 0.5],
                    "8756": [0, 0.69224, 0, 0, 0.66667],
                    "8757": [0, 0.69224, 0, 0, 0.66667],
                    "8764": [-0.13313, 0.36687, 0, 0, 0.77778],
                    "8765": [-0.13313, 0.37788, 0, 0, 0.77778],
                    "8769": [-0.13313, 0.36687, 0, 0, 0.77778],
                    "8770": [-0.03625, 0.46375, 0, 0, 0.77778],
                    "8774": [0.30274, 0.79383, 0, 0, 0.77778],
                    "8776": [-0.01688, 0.48312, 0, 0, 0.77778],
                    "8778": [0.08167, 0.58167, 0, 0, 0.77778],
                    "8782": [0.06062, 0.54986, 0, 0, 0.77778],
                    "8783": [0.06062, 0.54986, 0, 0, 0.77778],
                    "8785": [0.08198, 0.58198, 0, 0, 0.77778],
                    "8786": [0.08198, 0.58198, 0, 0, 0.77778],
                    "8787": [0.08198, 0.58198, 0, 0, 0.77778],
                    "8790": [0, 0.69224, 0, 0, 0.77778],
                    "8791": [0.22958, 0.72958, 0, 0, 0.77778],
                    "8796": [0.08198, 0.91667, 0, 0, 0.77778],
                    "8806": [0.25583, 0.75583, 0, 0, 0.77778],
                    "8807": [0.25583, 0.75583, 0, 0, 0.77778],
                    "8808": [0.25142, 0.75726, 0, 0, 0.77778],
                    "8809": [0.25142, 0.75726, 0, 0, 0.77778],
                    "8812": [0.25583, 0.75583, 0, 0, 0.5],
                    "8814": [0.20576, 0.70576, 0, 0, 0.77778],
                    "8815": [0.20576, 0.70576, 0, 0, 0.77778],
                    "8816": [0.30274, 0.79383, 0, 0, 0.77778],
                    "8817": [0.30274, 0.79383, 0, 0, 0.77778],
                    "8818": [0.22958, 0.72958, 0, 0, 0.77778],
                    "8819": [0.22958, 0.72958, 0, 0, 0.77778],
                    "8822": [0.1808, 0.675, 0, 0, 0.77778],
                    "8823": [0.1808, 0.675, 0, 0, 0.77778],
                    "8828": [0.13667, 0.63667, 0, 0, 0.77778],
                    "8829": [0.13667, 0.63667, 0, 0, 0.77778],
                    "8830": [0.22958, 0.72958, 0, 0, 0.77778],
                    "8831": [0.22958, 0.72958, 0, 0, 0.77778],
                    "8832": [0.20576, 0.70576, 0, 0, 0.77778],
                    "8833": [0.20576, 0.70576, 0, 0, 0.77778],
                    "8840": [0.30274, 0.79383, 0, 0, 0.77778],
                    "8841": [0.30274, 0.79383, 0, 0, 0.77778],
                    "8842": [0.13597, 0.63597, 0, 0, 0.77778],
                    "8843": [0.13597, 0.63597, 0, 0, 0.77778],
                    "8847": [0.03517, 0.54986, 0, 0, 0.77778],
                    "8848": [0.03517, 0.54986, 0, 0, 0.77778],
                    "8858": [0.08198, 0.58198, 0, 0, 0.77778],
                    "8859": [0.08198, 0.58198, 0, 0, 0.77778],
                    "8861": [0.08198, 0.58198, 0, 0, 0.77778],
                    "8862": [0, 0.675, 0, 0, 0.77778],
                    "8863": [0, 0.675, 0, 0, 0.77778],
                    "8864": [0, 0.675, 0, 0, 0.77778],
                    "8865": [0, 0.675, 0, 0, 0.77778],
                    "8872": [0, 0.69224, 0, 0, 0.61111],
                    "8873": [0, 0.69224, 0, 0, 0.72222],
                    "8874": [0, 0.69224, 0, 0, 0.88889],
                    "8876": [0, 0.68889, 0, 0, 0.61111],
                    "8877": [0, 0.68889, 0, 0, 0.61111],
                    "8878": [0, 0.68889, 0, 0, 0.72222],
                    "8879": [0, 0.68889, 0, 0, 0.72222],
                    "8882": [0.03517, 0.54986, 0, 0, 0.77778],
                    "8883": [0.03517, 0.54986, 0, 0, 0.77778],
                    "8884": [0.13667, 0.63667, 0, 0, 0.77778],
                    "8885": [0.13667, 0.63667, 0, 0, 0.77778],
                    "8888": [0, 0.54986, 0, 0, 1.11111],
                    "8890": [0.19444, 0.43056, 0, 0, 0.55556],
                    "8891": [0.19444, 0.69224, 0, 0, 0.61111],
                    "8892": [0.19444, 0.69224, 0, 0, 0.61111],
                    "8901": [0, 0.54986, 0, 0, 0.27778],
                    "8903": [0.08167, 0.58167, 0, 0, 0.77778],
                    "8905": [0.08167, 0.58167, 0, 0, 0.77778],
                    "8906": [0.08167, 0.58167, 0, 0, 0.77778],
                    "8907": [0, 0.69224, 0, 0, 0.77778],
                    "8908": [0, 0.69224, 0, 0, 0.77778],
                    "8909": [-0.03598, 0.46402, 0, 0, 0.77778],
                    "8910": [0, 0.54986, 0, 0, 0.76042],
                    "8911": [0, 0.54986, 0, 0, 0.76042],
                    "8912": [0.03517, 0.54986, 0, 0, 0.77778],
                    "8913": [0.03517, 0.54986, 0, 0, 0.77778],
                    "8914": [0, 0.54986, 0, 0, 0.66667],
                    "8915": [0, 0.54986, 0, 0, 0.66667],
                    "8916": [0, 0.69224, 0, 0, 0.66667],
                    "8918": [0.0391, 0.5391, 0, 0, 0.77778],
                    "8919": [0.0391, 0.5391, 0, 0, 0.77778],
                    "8920": [0.03517, 0.54986, 0, 0, 1.33334],
                    "8921": [0.03517, 0.54986, 0, 0, 1.33334],
                    "8922": [0.38569, 0.88569, 0, 0, 0.77778],
                    "8923": [0.38569, 0.88569, 0, 0, 0.77778],
                    "8926": [0.13667, 0.63667, 0, 0, 0.77778],
                    "8927": [0.13667, 0.63667, 0, 0, 0.77778],
                    "8928": [0.30274, 0.79383, 0, 0, 0.77778],
                    "8929": [0.30274, 0.79383, 0, 0, 0.77778],
                    "8934": [0.23222, 0.74111, 0, 0, 0.77778],
                    "8935": [0.23222, 0.74111, 0, 0, 0.77778],
                    "8936": [0.23222, 0.74111, 0, 0, 0.77778],
                    "8937": [0.23222, 0.74111, 0, 0, 0.77778],
                    "8938": [0.20576, 0.70576, 0, 0, 0.77778],
                    "8939": [0.20576, 0.70576, 0, 0, 0.77778],
                    "8940": [0.30274, 0.79383, 0, 0, 0.77778],
                    "8941": [0.30274, 0.79383, 0, 0, 0.77778],
                    "8994": [0.19444, 0.69224, 0, 0, 0.77778],
                    "8995": [0.19444, 0.69224, 0, 0, 0.77778],
                    "9416": [0.15559, 0.69224, 0, 0, 0.90222],
                    "9484": [0, 0.69224, 0, 0, 0.5],
                    "9488": [0, 0.69224, 0, 0, 0.5],
                    "9492": [0, 0.37788, 0, 0, 0.5],
                    "9496": [0, 0.37788, 0, 0, 0.5],
                    "9585": [0.19444, 0.68889, 0, 0, 0.88889],
                    "9586": [0.19444, 0.74111, 0, 0, 0.88889],
                    "9632": [0, 0.675, 0, 0, 0.77778],
                    "9633": [0, 0.675, 0, 0, 0.77778],
                    "9650": [0, 0.54986, 0, 0, 0.72222],
                    "9651": [0, 0.54986, 0, 0, 0.72222],
                    "9654": [0.03517, 0.54986, 0, 0, 0.77778],
                    "9660": [0, 0.54986, 0, 0, 0.72222],
                    "9661": [0, 0.54986, 0, 0, 0.72222],
                    "9664": [0.03517, 0.54986, 0, 0, 0.77778],
                    "9674": [0.11111, 0.69224, 0, 0, 0.66667],
                    "9733": [0.19444, 0.69224, 0, 0, 0.94445],
                    "10003": [0, 0.69224, 0, 0, 0.83334],
                    "10016": [0, 0.69224, 0, 0, 0.83334],
                    "10731": [0.11111, 0.69224, 0, 0, 0.66667],
                    "10846": [0.19444, 0.75583, 0, 0, 0.61111],
                    "10877": [0.13667, 0.63667, 0, 0, 0.77778],
                    "10878": [0.13667, 0.63667, 0, 0, 0.77778],
                    "10885": [0.25583, 0.75583, 0, 0, 0.77778],
                    "10886": [0.25583, 0.75583, 0, 0, 0.77778],
                    "10887": [0.13597, 0.63597, 0, 0, 0.77778],
                    "10888": [0.13597, 0.63597, 0, 0, 0.77778],
                    "10889": [0.26167, 0.75726, 0, 0, 0.77778],
                    "10890": [0.26167, 0.75726, 0, 0, 0.77778],
                    "10891": [0.48256, 0.98256, 0, 0, 0.77778],
                    "10892": [0.48256, 0.98256, 0, 0, 0.77778],
                    "10901": [0.13667, 0.63667, 0, 0, 0.77778],
                    "10902": [0.13667, 0.63667, 0, 0, 0.77778],
                    "10933": [0.25142, 0.75726, 0, 0, 0.77778],
                    "10934": [0.25142, 0.75726, 0, 0, 0.77778],
                    "10935": [0.26167, 0.75726, 0, 0, 0.77778],
                    "10936": [0.26167, 0.75726, 0, 0, 0.77778],
                    "10937": [0.26167, 0.75726, 0, 0, 0.77778],
                    "10938": [0.26167, 0.75726, 0, 0, 0.77778],
                    "10949": [0.25583, 0.75583, 0, 0, 0.77778],
                    "10950": [0.25583, 0.75583, 0, 0, 0.77778],
                    "10955": [0.28481, 0.79383, 0, 0, 0.77778],
                    "10956": [0.28481, 0.79383, 0, 0, 0.77778],
                    "57350": [0.08167, 0.58167, 0, 0, 0.22222],
                    "57351": [0.08167, 0.58167, 0, 0, 0.38889],
                    "57352": [0.08167, 0.58167, 0, 0, 0.77778],
                    "57353": [0, 0.43056, 0.04028, 0, 0.66667],
                    "57356": [0.25142, 0.75726, 0, 0, 0.77778],
                    "57357": [0.25142, 0.75726, 0, 0, 0.77778],
                    "57358": [0.41951, 0.91951, 0, 0, 0.77778],
                    "57359": [0.30274, 0.79383, 0, 0, 0.77778],
                    "57360": [0.30274, 0.79383, 0, 0, 0.77778],
                    "57361": [0.41951, 0.91951, 0, 0, 0.77778],
                    "57366": [0.25142, 0.75726, 0, 0, 0.77778],
                    "57367": [0.25142, 0.75726, 0, 0, 0.77778],
                    "57368": [0.25142, 0.75726, 0, 0, 0.77778],
                    "57369": [0.25142, 0.75726, 0, 0, 0.77778],
                    "57370": [0.13597, 0.63597, 0, 0, 0.77778],
                    "57371": [0.13597, 0.63597, 0, 0, 0.77778]
                  },
                  "Caligraphic-Regular": {
                    "48": [0, 0.43056, 0, 0, 0.5],
                    "49": [0, 0.43056, 0, 0, 0.5],
                    "50": [0, 0.43056, 0, 0, 0.5],
                    "51": [0.19444, 0.43056, 0, 0, 0.5],
                    "52": [0.19444, 0.43056, 0, 0, 0.5],
                    "53": [0.19444, 0.43056, 0, 0, 0.5],
                    "54": [0, 0.64444, 0, 0, 0.5],
                    "55": [0.19444, 0.43056, 0, 0, 0.5],
                    "56": [0, 0.64444, 0, 0, 0.5],
                    "57": [0.19444, 0.43056, 0, 0, 0.5],
                    "65": [0, 0.68333, 0, 0.19445, 0.79847],
                    "66": [0, 0.68333, 0.03041, 0.13889, 0.65681],
                    "67": [0, 0.68333, 0.05834, 0.13889, 0.52653],
                    "68": [0, 0.68333, 0.02778, 0.08334, 0.77139],
                    "69": [0, 0.68333, 0.08944, 0.11111, 0.52778],
                    "70": [0, 0.68333, 0.09931, 0.11111, 0.71875],
                    "71": [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
                    "72": [0, 0.68333, 965e-5, 0.11111, 0.84452],
                    "73": [0, 0.68333, 0.07382, 0, 0.54452],
                    "74": [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
                    "75": [0, 0.68333, 0.01445, 0.05556, 0.76195],
                    "76": [0, 0.68333, 0, 0.13889, 0.68972],
                    "77": [0, 0.68333, 0, 0.13889, 1.2009],
                    "78": [0, 0.68333, 0.14736, 0.08334, 0.82049],
                    "79": [0, 0.68333, 0.02778, 0.11111, 0.79611],
                    "80": [0, 0.68333, 0.08222, 0.08334, 0.69556],
                    "81": [0.09722, 0.68333, 0, 0.11111, 0.81667],
                    "82": [0, 0.68333, 0, 0.08334, 0.8475],
                    "83": [0, 0.68333, 0.075, 0.13889, 0.60556],
                    "84": [0, 0.68333, 0.25417, 0, 0.54464],
                    "85": [0, 0.68333, 0.09931, 0.08334, 0.62583],
                    "86": [0, 0.68333, 0.08222, 0, 0.61278],
                    "87": [0, 0.68333, 0.08222, 0.08334, 0.98778],
                    "88": [0, 0.68333, 0.14643, 0.13889, 0.7133],
                    "89": [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
                    "90": [0, 0.68333, 0.07944, 0.13889, 0.72473]
                  },
                  "Fraktur-Regular": {
                    "33": [0, 0.69141, 0, 0, 0.29574],
                    "34": [0, 0.69141, 0, 0, 0.21471],
                    "38": [0, 0.69141, 0, 0, 0.73786],
                    "39": [0, 0.69141, 0, 0, 0.21201],
                    "40": [0.24982, 0.74947, 0, 0, 0.38865],
                    "41": [0.24982, 0.74947, 0, 0, 0.38865],
                    "42": [0, 0.62119, 0, 0, 0.27764],
                    "43": [0.08319, 0.58283, 0, 0, 0.75623],
                    "44": [0, 0.10803, 0, 0, 0.27764],
                    "45": [0.08319, 0.58283, 0, 0, 0.75623],
                    "46": [0, 0.10803, 0, 0, 0.27764],
                    "47": [0.24982, 0.74947, 0, 0, 0.50181],
                    "48": [0, 0.47534, 0, 0, 0.50181],
                    "49": [0, 0.47534, 0, 0, 0.50181],
                    "50": [0, 0.47534, 0, 0, 0.50181],
                    "51": [0.18906, 0.47534, 0, 0, 0.50181],
                    "52": [0.18906, 0.47534, 0, 0, 0.50181],
                    "53": [0.18906, 0.47534, 0, 0, 0.50181],
                    "54": [0, 0.69141, 0, 0, 0.50181],
                    "55": [0.18906, 0.47534, 0, 0, 0.50181],
                    "56": [0, 0.69141, 0, 0, 0.50181],
                    "57": [0.18906, 0.47534, 0, 0, 0.50181],
                    "58": [0, 0.47534, 0, 0, 0.21606],
                    "59": [0.12604, 0.47534, 0, 0, 0.21606],
                    "61": [-0.13099, 0.36866, 0, 0, 0.75623],
                    "63": [0, 0.69141, 0, 0, 0.36245],
                    "65": [0, 0.69141, 0, 0, 0.7176],
                    "66": [0, 0.69141, 0, 0, 0.88397],
                    "67": [0, 0.69141, 0, 0, 0.61254],
                    "68": [0, 0.69141, 0, 0, 0.83158],
                    "69": [0, 0.69141, 0, 0, 0.66278],
                    "70": [0.12604, 0.69141, 0, 0, 0.61119],
                    "71": [0, 0.69141, 0, 0, 0.78539],
                    "72": [0.06302, 0.69141, 0, 0, 0.7203],
                    "73": [0, 0.69141, 0, 0, 0.55448],
                    "74": [0.12604, 0.69141, 0, 0, 0.55231],
                    "75": [0, 0.69141, 0, 0, 0.66845],
                    "76": [0, 0.69141, 0, 0, 0.66602],
                    "77": [0, 0.69141, 0, 0, 1.04953],
                    "78": [0, 0.69141, 0, 0, 0.83212],
                    "79": [0, 0.69141, 0, 0, 0.82699],
                    "80": [0.18906, 0.69141, 0, 0, 0.82753],
                    "81": [0.03781, 0.69141, 0, 0, 0.82699],
                    "82": [0, 0.69141, 0, 0, 0.82807],
                    "83": [0, 0.69141, 0, 0, 0.82861],
                    "84": [0, 0.69141, 0, 0, 0.66899],
                    "85": [0, 0.69141, 0, 0, 0.64576],
                    "86": [0, 0.69141, 0, 0, 0.83131],
                    "87": [0, 0.69141, 0, 0, 1.04602],
                    "88": [0, 0.69141, 0, 0, 0.71922],
                    "89": [0.18906, 0.69141, 0, 0, 0.83293],
                    "90": [0.12604, 0.69141, 0, 0, 0.60201],
                    "91": [0.24982, 0.74947, 0, 0, 0.27764],
                    "93": [0.24982, 0.74947, 0, 0, 0.27764],
                    "94": [0, 0.69141, 0, 0, 0.49965],
                    "97": [0, 0.47534, 0, 0, 0.50046],
                    "98": [0, 0.69141, 0, 0, 0.51315],
                    "99": [0, 0.47534, 0, 0, 0.38946],
                    "100": [0, 0.62119, 0, 0, 0.49857],
                    "101": [0, 0.47534, 0, 0, 0.40053],
                    "102": [0.18906, 0.69141, 0, 0, 0.32626],
                    "103": [0.18906, 0.47534, 0, 0, 0.5037],
                    "104": [0.18906, 0.69141, 0, 0, 0.52126],
                    "105": [0, 0.69141, 0, 0, 0.27899],
                    "106": [0, 0.69141, 0, 0, 0.28088],
                    "107": [0, 0.69141, 0, 0, 0.38946],
                    "108": [0, 0.69141, 0, 0, 0.27953],
                    "109": [0, 0.47534, 0, 0, 0.76676],
                    "110": [0, 0.47534, 0, 0, 0.52666],
                    "111": [0, 0.47534, 0, 0, 0.48885],
                    "112": [0.18906, 0.52396, 0, 0, 0.50046],
                    "113": [0.18906, 0.47534, 0, 0, 0.48912],
                    "114": [0, 0.47534, 0, 0, 0.38919],
                    "115": [0, 0.47534, 0, 0, 0.44266],
                    "116": [0, 0.62119, 0, 0, 0.33301],
                    "117": [0, 0.47534, 0, 0, 0.5172],
                    "118": [0, 0.52396, 0, 0, 0.5118],
                    "119": [0, 0.52396, 0, 0, 0.77351],
                    "120": [0.18906, 0.47534, 0, 0, 0.38865],
                    "121": [0.18906, 0.47534, 0, 0, 0.49884],
                    "122": [0.18906, 0.47534, 0, 0, 0.39054],
                    "8216": [0, 0.69141, 0, 0, 0.21471],
                    "8217": [0, 0.69141, 0, 0, 0.21471],
                    "58112": [0, 0.62119, 0, 0, 0.49749],
                    "58113": [0, 0.62119, 0, 0, 0.4983],
                    "58114": [0.18906, 0.69141, 0, 0, 0.33328],
                    "58115": [0.18906, 0.69141, 0, 0, 0.32923],
                    "58116": [0.18906, 0.47534, 0, 0, 0.50343],
                    "58117": [0, 0.69141, 0, 0, 0.33301],
                    "58118": [0, 0.62119, 0, 0, 0.33409],
                    "58119": [0, 0.47534, 0, 0, 0.50073]
                  },
                  "Main-Bold": {
                    "33": [0, 0.69444, 0, 0, 0.35],
                    "34": [0, 0.69444, 0, 0, 0.60278],
                    "35": [0.19444, 0.69444, 0, 0, 0.95833],
                    "36": [0.05556, 0.75, 0, 0, 0.575],
                    "37": [0.05556, 0.75, 0, 0, 0.95833],
                    "38": [0, 0.69444, 0, 0, 0.89444],
                    "39": [0, 0.69444, 0, 0, 0.31944],
                    "40": [0.25, 0.75, 0, 0, 0.44722],
                    "41": [0.25, 0.75, 0, 0, 0.44722],
                    "42": [0, 0.75, 0, 0, 0.575],
                    "43": [0.13333, 0.63333, 0, 0, 0.89444],
                    "44": [0.19444, 0.15556, 0, 0, 0.31944],
                    "45": [0, 0.44444, 0, 0, 0.38333],
                    "46": [0, 0.15556, 0, 0, 0.31944],
                    "47": [0.25, 0.75, 0, 0, 0.575],
                    "48": [0, 0.64444, 0, 0, 0.575],
                    "49": [0, 0.64444, 0, 0, 0.575],
                    "50": [0, 0.64444, 0, 0, 0.575],
                    "51": [0, 0.64444, 0, 0, 0.575],
                    "52": [0, 0.64444, 0, 0, 0.575],
                    "53": [0, 0.64444, 0, 0, 0.575],
                    "54": [0, 0.64444, 0, 0, 0.575],
                    "55": [0, 0.64444, 0, 0, 0.575],
                    "56": [0, 0.64444, 0, 0, 0.575],
                    "57": [0, 0.64444, 0, 0, 0.575],
                    "58": [0, 0.44444, 0, 0, 0.31944],
                    "59": [0.19444, 0.44444, 0, 0, 0.31944],
                    "60": [0.08556, 0.58556, 0, 0, 0.89444],
                    "61": [-0.10889, 0.39111, 0, 0, 0.89444],
                    "62": [0.08556, 0.58556, 0, 0, 0.89444],
                    "63": [0, 0.69444, 0, 0, 0.54305],
                    "64": [0, 0.69444, 0, 0, 0.89444],
                    "65": [0, 0.68611, 0, 0, 0.86944],
                    "66": [0, 0.68611, 0, 0, 0.81805],
                    "67": [0, 0.68611, 0, 0, 0.83055],
                    "68": [0, 0.68611, 0, 0, 0.88194],
                    "69": [0, 0.68611, 0, 0, 0.75555],
                    "70": [0, 0.68611, 0, 0, 0.72361],
                    "71": [0, 0.68611, 0, 0, 0.90416],
                    "72": [0, 0.68611, 0, 0, 0.9],
                    "73": [0, 0.68611, 0, 0, 0.43611],
                    "74": [0, 0.68611, 0, 0, 0.59444],
                    "75": [0, 0.68611, 0, 0, 0.90138],
                    "76": [0, 0.68611, 0, 0, 0.69166],
                    "77": [0, 0.68611, 0, 0, 1.09166],
                    "78": [0, 0.68611, 0, 0, 0.9],
                    "79": [0, 0.68611, 0, 0, 0.86388],
                    "80": [0, 0.68611, 0, 0, 0.78611],
                    "81": [0.19444, 0.68611, 0, 0, 0.86388],
                    "82": [0, 0.68611, 0, 0, 0.8625],
                    "83": [0, 0.68611, 0, 0, 0.63889],
                    "84": [0, 0.68611, 0, 0, 0.8],
                    "85": [0, 0.68611, 0, 0, 0.88472],
                    "86": [0, 0.68611, 0.01597, 0, 0.86944],
                    "87": [0, 0.68611, 0.01597, 0, 1.18888],
                    "88": [0, 0.68611, 0, 0, 0.86944],
                    "89": [0, 0.68611, 0.02875, 0, 0.86944],
                    "90": [0, 0.68611, 0, 0, 0.70277],
                    "91": [0.25, 0.75, 0, 0, 0.31944],
                    "92": [0.25, 0.75, 0, 0, 0.575],
                    "93": [0.25, 0.75, 0, 0, 0.31944],
                    "94": [0, 0.69444, 0, 0, 0.575],
                    "95": [0.31, 0.13444, 0.03194, 0, 0.575],
                    "97": [0, 0.44444, 0, 0, 0.55902],
                    "98": [0, 0.69444, 0, 0, 0.63889],
                    "99": [0, 0.44444, 0, 0, 0.51111],
                    "100": [0, 0.69444, 0, 0, 0.63889],
                    "101": [0, 0.44444, 0, 0, 0.52708],
                    "102": [0, 0.69444, 0.10903, 0, 0.35139],
                    "103": [0.19444, 0.44444, 0.01597, 0, 0.575],
                    "104": [0, 0.69444, 0, 0, 0.63889],
                    "105": [0, 0.69444, 0, 0, 0.31944],
                    "106": [0.19444, 0.69444, 0, 0, 0.35139],
                    "107": [0, 0.69444, 0, 0, 0.60694],
                    "108": [0, 0.69444, 0, 0, 0.31944],
                    "109": [0, 0.44444, 0, 0, 0.95833],
                    "110": [0, 0.44444, 0, 0, 0.63889],
                    "111": [0, 0.44444, 0, 0, 0.575],
                    "112": [0.19444, 0.44444, 0, 0, 0.63889],
                    "113": [0.19444, 0.44444, 0, 0, 0.60694],
                    "114": [0, 0.44444, 0, 0, 0.47361],
                    "115": [0, 0.44444, 0, 0, 0.45361],
                    "116": [0, 0.63492, 0, 0, 0.44722],
                    "117": [0, 0.44444, 0, 0, 0.63889],
                    "118": [0, 0.44444, 0.01597, 0, 0.60694],
                    "119": [0, 0.44444, 0.01597, 0, 0.83055],
                    "120": [0, 0.44444, 0, 0, 0.60694],
                    "121": [0.19444, 0.44444, 0.01597, 0, 0.60694],
                    "122": [0, 0.44444, 0, 0, 0.51111],
                    "123": [0.25, 0.75, 0, 0, 0.575],
                    "124": [0.25, 0.75, 0, 0, 0.31944],
                    "125": [0.25, 0.75, 0, 0, 0.575],
                    "126": [0.35, 0.34444, 0, 0, 0.575],
                    "168": [0, 0.69444, 0, 0, 0.575],
                    "172": [0, 0.44444, 0, 0, 0.76666],
                    "176": [0, 0.69444, 0, 0, 0.86944],
                    "177": [0.13333, 0.63333, 0, 0, 0.89444],
                    "184": [0.17014, 0, 0, 0, 0.51111],
                    "198": [0, 0.68611, 0, 0, 1.04166],
                    "215": [0.13333, 0.63333, 0, 0, 0.89444],
                    "216": [0.04861, 0.73472, 0, 0, 0.89444],
                    "223": [0, 0.69444, 0, 0, 0.59722],
                    "230": [0, 0.44444, 0, 0, 0.83055],
                    "247": [0.13333, 0.63333, 0, 0, 0.89444],
                    "248": [0.09722, 0.54167, 0, 0, 0.575],
                    "305": [0, 0.44444, 0, 0, 0.31944],
                    "338": [0, 0.68611, 0, 0, 1.16944],
                    "339": [0, 0.44444, 0, 0, 0.89444],
                    "567": [0.19444, 0.44444, 0, 0, 0.35139],
                    "710": [0, 0.69444, 0, 0, 0.575],
                    "711": [0, 0.63194, 0, 0, 0.575],
                    "713": [0, 0.59611, 0, 0, 0.575],
                    "714": [0, 0.69444, 0, 0, 0.575],
                    "715": [0, 0.69444, 0, 0, 0.575],
                    "728": [0, 0.69444, 0, 0, 0.575],
                    "729": [0, 0.69444, 0, 0, 0.31944],
                    "730": [0, 0.69444, 0, 0, 0.86944],
                    "732": [0, 0.69444, 0, 0, 0.575],
                    "733": [0, 0.69444, 0, 0, 0.575],
                    "824": [0.19444, 0.69444, 0, 0, 0],
                    "915": [0, 0.68611, 0, 0, 0.69166],
                    "916": [0, 0.68611, 0, 0, 0.95833],
                    "920": [0, 0.68611, 0, 0, 0.89444],
                    "923": [0, 0.68611, 0, 0, 0.80555],
                    "926": [0, 0.68611, 0, 0, 0.76666],
                    "928": [0, 0.68611, 0, 0, 0.9],
                    "931": [0, 0.68611, 0, 0, 0.83055],
                    "933": [0, 0.68611, 0, 0, 0.89444],
                    "934": [0, 0.68611, 0, 0, 0.83055],
                    "936": [0, 0.68611, 0, 0, 0.89444],
                    "937": [0, 0.68611, 0, 0, 0.83055],
                    "8211": [0, 0.44444, 0.03194, 0, 0.575],
                    "8212": [0, 0.44444, 0.03194, 0, 1.14999],
                    "8216": [0, 0.69444, 0, 0, 0.31944],
                    "8217": [0, 0.69444, 0, 0, 0.31944],
                    "8220": [0, 0.69444, 0, 0, 0.60278],
                    "8221": [0, 0.69444, 0, 0, 0.60278],
                    "8224": [0.19444, 0.69444, 0, 0, 0.51111],
                    "8225": [0.19444, 0.69444, 0, 0, 0.51111],
                    "8242": [0, 0.55556, 0, 0, 0.34444],
                    "8407": [0, 0.72444, 0.15486, 0, 0.575],
                    "8463": [0, 0.69444, 0, 0, 0.66759],
                    "8465": [0, 0.69444, 0, 0, 0.83055],
                    "8467": [0, 0.69444, 0, 0, 0.47361],
                    "8472": [0.19444, 0.44444, 0, 0, 0.74027],
                    "8476": [0, 0.69444, 0, 0, 0.83055],
                    "8501": [0, 0.69444, 0, 0, 0.70277],
                    "8592": [-0.10889, 0.39111, 0, 0, 1.14999],
                    "8593": [0.19444, 0.69444, 0, 0, 0.575],
                    "8594": [-0.10889, 0.39111, 0, 0, 1.14999],
                    "8595": [0.19444, 0.69444, 0, 0, 0.575],
                    "8596": [-0.10889, 0.39111, 0, 0, 1.14999],
                    "8597": [0.25, 0.75, 0, 0, 0.575],
                    "8598": [0.19444, 0.69444, 0, 0, 1.14999],
                    "8599": [0.19444, 0.69444, 0, 0, 1.14999],
                    "8600": [0.19444, 0.69444, 0, 0, 1.14999],
                    "8601": [0.19444, 0.69444, 0, 0, 1.14999],
                    "8636": [-0.10889, 0.39111, 0, 0, 1.14999],
                    "8637": [-0.10889, 0.39111, 0, 0, 1.14999],
                    "8640": [-0.10889, 0.39111, 0, 0, 1.14999],
                    "8641": [-0.10889, 0.39111, 0, 0, 1.14999],
                    "8656": [-0.10889, 0.39111, 0, 0, 1.14999],
                    "8657": [0.19444, 0.69444, 0, 0, 0.70277],
                    "8658": [-0.10889, 0.39111, 0, 0, 1.14999],
                    "8659": [0.19444, 0.69444, 0, 0, 0.70277],
                    "8660": [-0.10889, 0.39111, 0, 0, 1.14999],
                    "8661": [0.25, 0.75, 0, 0, 0.70277],
                    "8704": [0, 0.69444, 0, 0, 0.63889],
                    "8706": [0, 0.69444, 0.06389, 0, 0.62847],
                    "8707": [0, 0.69444, 0, 0, 0.63889],
                    "8709": [0.05556, 0.75, 0, 0, 0.575],
                    "8711": [0, 0.68611, 0, 0, 0.95833],
                    "8712": [0.08556, 0.58556, 0, 0, 0.76666],
                    "8715": [0.08556, 0.58556, 0, 0, 0.76666],
                    "8722": [0.13333, 0.63333, 0, 0, 0.89444],
                    "8723": [0.13333, 0.63333, 0, 0, 0.89444],
                    "8725": [0.25, 0.75, 0, 0, 0.575],
                    "8726": [0.25, 0.75, 0, 0, 0.575],
                    "8727": [-0.02778, 0.47222, 0, 0, 0.575],
                    "8728": [-0.02639, 0.47361, 0, 0, 0.575],
                    "8729": [-0.02639, 0.47361, 0, 0, 0.575],
                    "8730": [0.18, 0.82, 0, 0, 0.95833],
                    "8733": [0, 0.44444, 0, 0, 0.89444],
                    "8734": [0, 0.44444, 0, 0, 1.14999],
                    "8736": [0, 0.69224, 0, 0, 0.72222],
                    "8739": [0.25, 0.75, 0, 0, 0.31944],
                    "8741": [0.25, 0.75, 0, 0, 0.575],
                    "8743": [0, 0.55556, 0, 0, 0.76666],
                    "8744": [0, 0.55556, 0, 0, 0.76666],
                    "8745": [0, 0.55556, 0, 0, 0.76666],
                    "8746": [0, 0.55556, 0, 0, 0.76666],
                    "8747": [0.19444, 0.69444, 0.12778, 0, 0.56875],
                    "8764": [-0.10889, 0.39111, 0, 0, 0.89444],
                    "8768": [0.19444, 0.69444, 0, 0, 0.31944],
                    "8771": [222e-5, 0.50222, 0, 0, 0.89444],
                    "8776": [0.02444, 0.52444, 0, 0, 0.89444],
                    "8781": [222e-5, 0.50222, 0, 0, 0.89444],
                    "8801": [222e-5, 0.50222, 0, 0, 0.89444],
                    "8804": [0.19667, 0.69667, 0, 0, 0.89444],
                    "8805": [0.19667, 0.69667, 0, 0, 0.89444],
                    "8810": [0.08556, 0.58556, 0, 0, 1.14999],
                    "8811": [0.08556, 0.58556, 0, 0, 1.14999],
                    "8826": [0.08556, 0.58556, 0, 0, 0.89444],
                    "8827": [0.08556, 0.58556, 0, 0, 0.89444],
                    "8834": [0.08556, 0.58556, 0, 0, 0.89444],
                    "8835": [0.08556, 0.58556, 0, 0, 0.89444],
                    "8838": [0.19667, 0.69667, 0, 0, 0.89444],
                    "8839": [0.19667, 0.69667, 0, 0, 0.89444],
                    "8846": [0, 0.55556, 0, 0, 0.76666],
                    "8849": [0.19667, 0.69667, 0, 0, 0.89444],
                    "8850": [0.19667, 0.69667, 0, 0, 0.89444],
                    "8851": [0, 0.55556, 0, 0, 0.76666],
                    "8852": [0, 0.55556, 0, 0, 0.76666],
                    "8853": [0.13333, 0.63333, 0, 0, 0.89444],
                    "8854": [0.13333, 0.63333, 0, 0, 0.89444],
                    "8855": [0.13333, 0.63333, 0, 0, 0.89444],
                    "8856": [0.13333, 0.63333, 0, 0, 0.89444],
                    "8857": [0.13333, 0.63333, 0, 0, 0.89444],
                    "8866": [0, 0.69444, 0, 0, 0.70277],
                    "8867": [0, 0.69444, 0, 0, 0.70277],
                    "8868": [0, 0.69444, 0, 0, 0.89444],
                    "8869": [0, 0.69444, 0, 0, 0.89444],
                    "8900": [-0.02639, 0.47361, 0, 0, 0.575],
                    "8901": [-0.02639, 0.47361, 0, 0, 0.31944],
                    "8902": [-0.02778, 0.47222, 0, 0, 0.575],
                    "8968": [0.25, 0.75, 0, 0, 0.51111],
                    "8969": [0.25, 0.75, 0, 0, 0.51111],
                    "8970": [0.25, 0.75, 0, 0, 0.51111],
                    "8971": [0.25, 0.75, 0, 0, 0.51111],
                    "8994": [-0.13889, 0.36111, 0, 0, 1.14999],
                    "8995": [-0.13889, 0.36111, 0, 0, 1.14999],
                    "9651": [0.19444, 0.69444, 0, 0, 1.02222],
                    "9657": [-0.02778, 0.47222, 0, 0, 0.575],
                    "9661": [0.19444, 0.69444, 0, 0, 1.02222],
                    "9667": [-0.02778, 0.47222, 0, 0, 0.575],
                    "9711": [0.19444, 0.69444, 0, 0, 1.14999],
                    "9824": [0.12963, 0.69444, 0, 0, 0.89444],
                    "9825": [0.12963, 0.69444, 0, 0, 0.89444],
                    "9826": [0.12963, 0.69444, 0, 0, 0.89444],
                    "9827": [0.12963, 0.69444, 0, 0, 0.89444],
                    "9837": [0, 0.75, 0, 0, 0.44722],
                    "9838": [0.19444, 0.69444, 0, 0, 0.44722],
                    "9839": [0.19444, 0.69444, 0, 0, 0.44722],
                    "10216": [0.25, 0.75, 0, 0, 0.44722],
                    "10217": [0.25, 0.75, 0, 0, 0.44722],
                    "10815": [0, 0.68611, 0, 0, 0.9],
                    "10927": [0.19667, 0.69667, 0, 0, 0.89444],
                    "10928": [0.19667, 0.69667, 0, 0, 0.89444]
                  },
                  "Main-BoldItalic": {
                    "33": [0, 0.69444, 0.11417, 0, 0.38611],
                    "34": [0, 0.69444, 0.07939, 0, 0.62055],
                    "35": [0.19444, 0.69444, 0.06833, 0, 0.94444],
                    "37": [0.05556, 0.75, 0.12861, 0, 0.94444],
                    "38": [0, 0.69444, 0.08528, 0, 0.88555],
                    "39": [0, 0.69444, 0.12945, 0, 0.35555],
                    "40": [0.25, 0.75, 0.15806, 0, 0.47333],
                    "41": [0.25, 0.75, 0.03306, 0, 0.47333],
                    "42": [0, 0.75, 0.14333, 0, 0.59111],
                    "43": [0.10333, 0.60333, 0.03306, 0, 0.88555],
                    "44": [0.19444, 0.14722, 0, 0, 0.35555],
                    "45": [0, 0.44444, 0.02611, 0, 0.41444],
                    "46": [0, 0.14722, 0, 0, 0.35555],
                    "47": [0.25, 0.75, 0.15806, 0, 0.59111],
                    "48": [0, 0.64444, 0.13167, 0, 0.59111],
                    "49": [0, 0.64444, 0.13167, 0, 0.59111],
                    "50": [0, 0.64444, 0.13167, 0, 0.59111],
                    "51": [0, 0.64444, 0.13167, 0, 0.59111],
                    "52": [0.19444, 0.64444, 0.13167, 0, 0.59111],
                    "53": [0, 0.64444, 0.13167, 0, 0.59111],
                    "54": [0, 0.64444, 0.13167, 0, 0.59111],
                    "55": [0.19444, 0.64444, 0.13167, 0, 0.59111],
                    "56": [0, 0.64444, 0.13167, 0, 0.59111],
                    "57": [0, 0.64444, 0.13167, 0, 0.59111],
                    "58": [0, 0.44444, 0.06695, 0, 0.35555],
                    "59": [0.19444, 0.44444, 0.06695, 0, 0.35555],
                    "61": [-0.10889, 0.39111, 0.06833, 0, 0.88555],
                    "63": [0, 0.69444, 0.11472, 0, 0.59111],
                    "64": [0, 0.69444, 0.09208, 0, 0.88555],
                    "65": [0, 0.68611, 0, 0, 0.86555],
                    "66": [0, 0.68611, 0.0992, 0, 0.81666],
                    "67": [0, 0.68611, 0.14208, 0, 0.82666],
                    "68": [0, 0.68611, 0.09062, 0, 0.87555],
                    "69": [0, 0.68611, 0.11431, 0, 0.75666],
                    "70": [0, 0.68611, 0.12903, 0, 0.72722],
                    "71": [0, 0.68611, 0.07347, 0, 0.89527],
                    "72": [0, 0.68611, 0.17208, 0, 0.8961],
                    "73": [0, 0.68611, 0.15681, 0, 0.47166],
                    "74": [0, 0.68611, 0.145, 0, 0.61055],
                    "75": [0, 0.68611, 0.14208, 0, 0.89499],
                    "76": [0, 0.68611, 0, 0, 0.69777],
                    "77": [0, 0.68611, 0.17208, 0, 1.07277],
                    "78": [0, 0.68611, 0.17208, 0, 0.8961],
                    "79": [0, 0.68611, 0.09062, 0, 0.85499],
                    "80": [0, 0.68611, 0.0992, 0, 0.78721],
                    "81": [0.19444, 0.68611, 0.09062, 0, 0.85499],
                    "82": [0, 0.68611, 0.02559, 0, 0.85944],
                    "83": [0, 0.68611, 0.11264, 0, 0.64999],
                    "84": [0, 0.68611, 0.12903, 0, 0.7961],
                    "85": [0, 0.68611, 0.17208, 0, 0.88083],
                    "86": [0, 0.68611, 0.18625, 0, 0.86555],
                    "87": [0, 0.68611, 0.18625, 0, 1.15999],
                    "88": [0, 0.68611, 0.15681, 0, 0.86555],
                    "89": [0, 0.68611, 0.19803, 0, 0.86555],
                    "90": [0, 0.68611, 0.14208, 0, 0.70888],
                    "91": [0.25, 0.75, 0.1875, 0, 0.35611],
                    "93": [0.25, 0.75, 0.09972, 0, 0.35611],
                    "94": [0, 0.69444, 0.06709, 0, 0.59111],
                    "95": [0.31, 0.13444, 0.09811, 0, 0.59111],
                    "97": [0, 0.44444, 0.09426, 0, 0.59111],
                    "98": [0, 0.69444, 0.07861, 0, 0.53222],
                    "99": [0, 0.44444, 0.05222, 0, 0.53222],
                    "100": [0, 0.69444, 0.10861, 0, 0.59111],
                    "101": [0, 0.44444, 0.085, 0, 0.53222],
                    "102": [0.19444, 0.69444, 0.21778, 0, 0.4],
                    "103": [0.19444, 0.44444, 0.105, 0, 0.53222],
                    "104": [0, 0.69444, 0.09426, 0, 0.59111],
                    "105": [0, 0.69326, 0.11387, 0, 0.35555],
                    "106": [0.19444, 0.69326, 0.1672, 0, 0.35555],
                    "107": [0, 0.69444, 0.11111, 0, 0.53222],
                    "108": [0, 0.69444, 0.10861, 0, 0.29666],
                    "109": [0, 0.44444, 0.09426, 0, 0.94444],
                    "110": [0, 0.44444, 0.09426, 0, 0.64999],
                    "111": [0, 0.44444, 0.07861, 0, 0.59111],
                    "112": [0.19444, 0.44444, 0.07861, 0, 0.59111],
                    "113": [0.19444, 0.44444, 0.105, 0, 0.53222],
                    "114": [0, 0.44444, 0.11111, 0, 0.50167],
                    "115": [0, 0.44444, 0.08167, 0, 0.48694],
                    "116": [0, 0.63492, 0.09639, 0, 0.385],
                    "117": [0, 0.44444, 0.09426, 0, 0.62055],
                    "118": [0, 0.44444, 0.11111, 0, 0.53222],
                    "119": [0, 0.44444, 0.11111, 0, 0.76777],
                    "120": [0, 0.44444, 0.12583, 0, 0.56055],
                    "121": [0.19444, 0.44444, 0.105, 0, 0.56166],
                    "122": [0, 0.44444, 0.13889, 0, 0.49055],
                    "126": [0.35, 0.34444, 0.11472, 0, 0.59111],
                    "163": [0, 0.69444, 0, 0, 0.86853],
                    "168": [0, 0.69444, 0.11473, 0, 0.59111],
                    "176": [0, 0.69444, 0, 0, 0.94888],
                    "184": [0.17014, 0, 0, 0, 0.53222],
                    "198": [0, 0.68611, 0.11431, 0, 1.02277],
                    "216": [0.04861, 0.73472, 0.09062, 0, 0.88555],
                    "223": [0.19444, 0.69444, 0.09736, 0, 0.665],
                    "230": [0, 0.44444, 0.085, 0, 0.82666],
                    "248": [0.09722, 0.54167, 0.09458, 0, 0.59111],
                    "305": [0, 0.44444, 0.09426, 0, 0.35555],
                    "338": [0, 0.68611, 0.11431, 0, 1.14054],
                    "339": [0, 0.44444, 0.085, 0, 0.82666],
                    "567": [0.19444, 0.44444, 0.04611, 0, 0.385],
                    "710": [0, 0.69444, 0.06709, 0, 0.59111],
                    "711": [0, 0.63194, 0.08271, 0, 0.59111],
                    "713": [0, 0.59444, 0.10444, 0, 0.59111],
                    "714": [0, 0.69444, 0.08528, 0, 0.59111],
                    "715": [0, 0.69444, 0, 0, 0.59111],
                    "728": [0, 0.69444, 0.10333, 0, 0.59111],
                    "729": [0, 0.69444, 0.12945, 0, 0.35555],
                    "730": [0, 0.69444, 0, 0, 0.94888],
                    "732": [0, 0.69444, 0.11472, 0, 0.59111],
                    "733": [0, 0.69444, 0.11472, 0, 0.59111],
                    "915": [0, 0.68611, 0.12903, 0, 0.69777],
                    "916": [0, 0.68611, 0, 0, 0.94444],
                    "920": [0, 0.68611, 0.09062, 0, 0.88555],
                    "923": [0, 0.68611, 0, 0, 0.80666],
                    "926": [0, 0.68611, 0.15092, 0, 0.76777],
                    "928": [0, 0.68611, 0.17208, 0, 0.8961],
                    "931": [0, 0.68611, 0.11431, 0, 0.82666],
                    "933": [0, 0.68611, 0.10778, 0, 0.88555],
                    "934": [0, 0.68611, 0.05632, 0, 0.82666],
                    "936": [0, 0.68611, 0.10778, 0, 0.88555],
                    "937": [0, 0.68611, 0.0992, 0, 0.82666],
                    "8211": [0, 0.44444, 0.09811, 0, 0.59111],
                    "8212": [0, 0.44444, 0.09811, 0, 1.18221],
                    "8216": [0, 0.69444, 0.12945, 0, 0.35555],
                    "8217": [0, 0.69444, 0.12945, 0, 0.35555],
                    "8220": [0, 0.69444, 0.16772, 0, 0.62055],
                    "8221": [0, 0.69444, 0.07939, 0, 0.62055]
                  },
                  "Main-Italic": {
                    "33": [0, 0.69444, 0.12417, 0, 0.30667],
                    "34": [0, 0.69444, 0.06961, 0, 0.51444],
                    "35": [0.19444, 0.69444, 0.06616, 0, 0.81777],
                    "37": [0.05556, 0.75, 0.13639, 0, 0.81777],
                    "38": [0, 0.69444, 0.09694, 0, 0.76666],
                    "39": [0, 0.69444, 0.12417, 0, 0.30667],
                    "40": [0.25, 0.75, 0.16194, 0, 0.40889],
                    "41": [0.25, 0.75, 0.03694, 0, 0.40889],
                    "42": [0, 0.75, 0.14917, 0, 0.51111],
                    "43": [0.05667, 0.56167, 0.03694, 0, 0.76666],
                    "44": [0.19444, 0.10556, 0, 0, 0.30667],
                    "45": [0, 0.43056, 0.02826, 0, 0.35778],
                    "46": [0, 0.10556, 0, 0, 0.30667],
                    "47": [0.25, 0.75, 0.16194, 0, 0.51111],
                    "48": [0, 0.64444, 0.13556, 0, 0.51111],
                    "49": [0, 0.64444, 0.13556, 0, 0.51111],
                    "50": [0, 0.64444, 0.13556, 0, 0.51111],
                    "51": [0, 0.64444, 0.13556, 0, 0.51111],
                    "52": [0.19444, 0.64444, 0.13556, 0, 0.51111],
                    "53": [0, 0.64444, 0.13556, 0, 0.51111],
                    "54": [0, 0.64444, 0.13556, 0, 0.51111],
                    "55": [0.19444, 0.64444, 0.13556, 0, 0.51111],
                    "56": [0, 0.64444, 0.13556, 0, 0.51111],
                    "57": [0, 0.64444, 0.13556, 0, 0.51111],
                    "58": [0, 0.43056, 0.0582, 0, 0.30667],
                    "59": [0.19444, 0.43056, 0.0582, 0, 0.30667],
                    "61": [-0.13313, 0.36687, 0.06616, 0, 0.76666],
                    "63": [0, 0.69444, 0.1225, 0, 0.51111],
                    "64": [0, 0.69444, 0.09597, 0, 0.76666],
                    "65": [0, 0.68333, 0, 0, 0.74333],
                    "66": [0, 0.68333, 0.10257, 0, 0.70389],
                    "67": [0, 0.68333, 0.14528, 0, 0.71555],
                    "68": [0, 0.68333, 0.09403, 0, 0.755],
                    "69": [0, 0.68333, 0.12028, 0, 0.67833],
                    "70": [0, 0.68333, 0.13305, 0, 0.65277],
                    "71": [0, 0.68333, 0.08722, 0, 0.77361],
                    "72": [0, 0.68333, 0.16389, 0, 0.74333],
                    "73": [0, 0.68333, 0.15806, 0, 0.38555],
                    "74": [0, 0.68333, 0.14028, 0, 0.525],
                    "75": [0, 0.68333, 0.14528, 0, 0.76888],
                    "76": [0, 0.68333, 0, 0, 0.62722],
                    "77": [0, 0.68333, 0.16389, 0, 0.89666],
                    "78": [0, 0.68333, 0.16389, 0, 0.74333],
                    "79": [0, 0.68333, 0.09403, 0, 0.76666],
                    "80": [0, 0.68333, 0.10257, 0, 0.67833],
                    "81": [0.19444, 0.68333, 0.09403, 0, 0.76666],
                    "82": [0, 0.68333, 0.03868, 0, 0.72944],
                    "83": [0, 0.68333, 0.11972, 0, 0.56222],
                    "84": [0, 0.68333, 0.13305, 0, 0.71555],
                    "85": [0, 0.68333, 0.16389, 0, 0.74333],
                    "86": [0, 0.68333, 0.18361, 0, 0.74333],
                    "87": [0, 0.68333, 0.18361, 0, 0.99888],
                    "88": [0, 0.68333, 0.15806, 0, 0.74333],
                    "89": [0, 0.68333, 0.19383, 0, 0.74333],
                    "90": [0, 0.68333, 0.14528, 0, 0.61333],
                    "91": [0.25, 0.75, 0.1875, 0, 0.30667],
                    "93": [0.25, 0.75, 0.10528, 0, 0.30667],
                    "94": [0, 0.69444, 0.06646, 0, 0.51111],
                    "95": [0.31, 0.12056, 0.09208, 0, 0.51111],
                    "97": [0, 0.43056, 0.07671, 0, 0.51111],
                    "98": [0, 0.69444, 0.06312, 0, 0.46],
                    "99": [0, 0.43056, 0.05653, 0, 0.46],
                    "100": [0, 0.69444, 0.10333, 0, 0.51111],
                    "101": [0, 0.43056, 0.07514, 0, 0.46],
                    "102": [0.19444, 0.69444, 0.21194, 0, 0.30667],
                    "103": [0.19444, 0.43056, 0.08847, 0, 0.46],
                    "104": [0, 0.69444, 0.07671, 0, 0.51111],
                    "105": [0, 0.65536, 0.1019, 0, 0.30667],
                    "106": [0.19444, 0.65536, 0.14467, 0, 0.30667],
                    "107": [0, 0.69444, 0.10764, 0, 0.46],
                    "108": [0, 0.69444, 0.10333, 0, 0.25555],
                    "109": [0, 0.43056, 0.07671, 0, 0.81777],
                    "110": [0, 0.43056, 0.07671, 0, 0.56222],
                    "111": [0, 0.43056, 0.06312, 0, 0.51111],
                    "112": [0.19444, 0.43056, 0.06312, 0, 0.51111],
                    "113": [0.19444, 0.43056, 0.08847, 0, 0.46],
                    "114": [0, 0.43056, 0.10764, 0, 0.42166],
                    "115": [0, 0.43056, 0.08208, 0, 0.40889],
                    "116": [0, 0.61508, 0.09486, 0, 0.33222],
                    "117": [0, 0.43056, 0.07671, 0, 0.53666],
                    "118": [0, 0.43056, 0.10764, 0, 0.46],
                    "119": [0, 0.43056, 0.10764, 0, 0.66444],
                    "120": [0, 0.43056, 0.12042, 0, 0.46389],
                    "121": [0.19444, 0.43056, 0.08847, 0, 0.48555],
                    "122": [0, 0.43056, 0.12292, 0, 0.40889],
                    "126": [0.35, 0.31786, 0.11585, 0, 0.51111],
                    "163": [0, 0.69444, 0, 0, 0.76909],
                    "168": [0, 0.66786, 0.10474, 0, 0.51111],
                    "176": [0, 0.69444, 0, 0, 0.83129],
                    "184": [0.17014, 0, 0, 0, 0.46],
                    "198": [0, 0.68333, 0.12028, 0, 0.88277],
                    "216": [0.04861, 0.73194, 0.09403, 0, 0.76666],
                    "223": [0.19444, 0.69444, 0.10514, 0, 0.53666],
                    "230": [0, 0.43056, 0.07514, 0, 0.71555],
                    "248": [0.09722, 0.52778, 0.09194, 0, 0.51111],
                    "305": [0, 0.43056, 0, 0.02778, 0.32246],
                    "338": [0, 0.68333, 0.12028, 0, 0.98499],
                    "339": [0, 0.43056, 0.07514, 0, 0.71555],
                    "567": [0.19444, 0.43056, 0, 0.08334, 0.38403],
                    "710": [0, 0.69444, 0.06646, 0, 0.51111],
                    "711": [0, 0.62847, 0.08295, 0, 0.51111],
                    "713": [0, 0.56167, 0.10333, 0, 0.51111],
                    "714": [0, 0.69444, 0.09694, 0, 0.51111],
                    "715": [0, 0.69444, 0, 0, 0.51111],
                    "728": [0, 0.69444, 0.10806, 0, 0.51111],
                    "729": [0, 0.66786, 0.11752, 0, 0.30667],
                    "730": [0, 0.69444, 0, 0, 0.83129],
                    "732": [0, 0.66786, 0.11585, 0, 0.51111],
                    "733": [0, 0.69444, 0.1225, 0, 0.51111],
                    "915": [0, 0.68333, 0.13305, 0, 0.62722],
                    "916": [0, 0.68333, 0, 0, 0.81777],
                    "920": [0, 0.68333, 0.09403, 0, 0.76666],
                    "923": [0, 0.68333, 0, 0, 0.69222],
                    "926": [0, 0.68333, 0.15294, 0, 0.66444],
                    "928": [0, 0.68333, 0.16389, 0, 0.74333],
                    "931": [0, 0.68333, 0.12028, 0, 0.71555],
                    "933": [0, 0.68333, 0.11111, 0, 0.76666],
                    "934": [0, 0.68333, 0.05986, 0, 0.71555],
                    "936": [0, 0.68333, 0.11111, 0, 0.76666],
                    "937": [0, 0.68333, 0.10257, 0, 0.71555],
                    "8211": [0, 0.43056, 0.09208, 0, 0.51111],
                    "8212": [0, 0.43056, 0.09208, 0, 1.02222],
                    "8216": [0, 0.69444, 0.12417, 0, 0.30667],
                    "8217": [0, 0.69444, 0.12417, 0, 0.30667],
                    "8220": [0, 0.69444, 0.1685, 0, 0.51444],
                    "8221": [0, 0.69444, 0.06961, 0, 0.51444],
                    "8463": [0, 0.68889, 0, 0, 0.54028]
                  },
                  "Main-Regular": {
                    "32": [0, 0, 0, 0, 0.25],
                    "33": [0, 0.69444, 0, 0, 0.27778],
                    "34": [0, 0.69444, 0, 0, 0.5],
                    "35": [0.19444, 0.69444, 0, 0, 0.83334],
                    "36": [0.05556, 0.75, 0, 0, 0.5],
                    "37": [0.05556, 0.75, 0, 0, 0.83334],
                    "38": [0, 0.69444, 0, 0, 0.77778],
                    "39": [0, 0.69444, 0, 0, 0.27778],
                    "40": [0.25, 0.75, 0, 0, 0.38889],
                    "41": [0.25, 0.75, 0, 0, 0.38889],
                    "42": [0, 0.75, 0, 0, 0.5],
                    "43": [0.08333, 0.58333, 0, 0, 0.77778],
                    "44": [0.19444, 0.10556, 0, 0, 0.27778],
                    "45": [0, 0.43056, 0, 0, 0.33333],
                    "46": [0, 0.10556, 0, 0, 0.27778],
                    "47": [0.25, 0.75, 0, 0, 0.5],
                    "48": [0, 0.64444, 0, 0, 0.5],
                    "49": [0, 0.64444, 0, 0, 0.5],
                    "50": [0, 0.64444, 0, 0, 0.5],
                    "51": [0, 0.64444, 0, 0, 0.5],
                    "52": [0, 0.64444, 0, 0, 0.5],
                    "53": [0, 0.64444, 0, 0, 0.5],
                    "54": [0, 0.64444, 0, 0, 0.5],
                    "55": [0, 0.64444, 0, 0, 0.5],
                    "56": [0, 0.64444, 0, 0, 0.5],
                    "57": [0, 0.64444, 0, 0, 0.5],
                    "58": [0, 0.43056, 0, 0, 0.27778],
                    "59": [0.19444, 0.43056, 0, 0, 0.27778],
                    "60": [0.0391, 0.5391, 0, 0, 0.77778],
                    "61": [-0.13313, 0.36687, 0, 0, 0.77778],
                    "62": [0.0391, 0.5391, 0, 0, 0.77778],
                    "63": [0, 0.69444, 0, 0, 0.47222],
                    "64": [0, 0.69444, 0, 0, 0.77778],
                    "65": [0, 0.68333, 0, 0, 0.75],
                    "66": [0, 0.68333, 0, 0, 0.70834],
                    "67": [0, 0.68333, 0, 0, 0.72222],
                    "68": [0, 0.68333, 0, 0, 0.76389],
                    "69": [0, 0.68333, 0, 0, 0.68056],
                    "70": [0, 0.68333, 0, 0, 0.65278],
                    "71": [0, 0.68333, 0, 0, 0.78472],
                    "72": [0, 0.68333, 0, 0, 0.75],
                    "73": [0, 0.68333, 0, 0, 0.36111],
                    "74": [0, 0.68333, 0, 0, 0.51389],
                    "75": [0, 0.68333, 0, 0, 0.77778],
                    "76": [0, 0.68333, 0, 0, 0.625],
                    "77": [0, 0.68333, 0, 0, 0.91667],
                    "78": [0, 0.68333, 0, 0, 0.75],
                    "79": [0, 0.68333, 0, 0, 0.77778],
                    "80": [0, 0.68333, 0, 0, 0.68056],
                    "81": [0.19444, 0.68333, 0, 0, 0.77778],
                    "82": [0, 0.68333, 0, 0, 0.73611],
                    "83": [0, 0.68333, 0, 0, 0.55556],
                    "84": [0, 0.68333, 0, 0, 0.72222],
                    "85": [0, 0.68333, 0, 0, 0.75],
                    "86": [0, 0.68333, 0.01389, 0, 0.75],
                    "87": [0, 0.68333, 0.01389, 0, 1.02778],
                    "88": [0, 0.68333, 0, 0, 0.75],
                    "89": [0, 0.68333, 0.025, 0, 0.75],
                    "90": [0, 0.68333, 0, 0, 0.61111],
                    "91": [0.25, 0.75, 0, 0, 0.27778],
                    "92": [0.25, 0.75, 0, 0, 0.5],
                    "93": [0.25, 0.75, 0, 0, 0.27778],
                    "94": [0, 0.69444, 0, 0, 0.5],
                    "95": [0.31, 0.12056, 0.02778, 0, 0.5],
                    "97": [0, 0.43056, 0, 0, 0.5],
                    "98": [0, 0.69444, 0, 0, 0.55556],
                    "99": [0, 0.43056, 0, 0, 0.44445],
                    "100": [0, 0.69444, 0, 0, 0.55556],
                    "101": [0, 0.43056, 0, 0, 0.44445],
                    "102": [0, 0.69444, 0.07778, 0, 0.30556],
                    "103": [0.19444, 0.43056, 0.01389, 0, 0.5],
                    "104": [0, 0.69444, 0, 0, 0.55556],
                    "105": [0, 0.66786, 0, 0, 0.27778],
                    "106": [0.19444, 0.66786, 0, 0, 0.30556],
                    "107": [0, 0.69444, 0, 0, 0.52778],
                    "108": [0, 0.69444, 0, 0, 0.27778],
                    "109": [0, 0.43056, 0, 0, 0.83334],
                    "110": [0, 0.43056, 0, 0, 0.55556],
                    "111": [0, 0.43056, 0, 0, 0.5],
                    "112": [0.19444, 0.43056, 0, 0, 0.55556],
                    "113": [0.19444, 0.43056, 0, 0, 0.52778],
                    "114": [0, 0.43056, 0, 0, 0.39167],
                    "115": [0, 0.43056, 0, 0, 0.39445],
                    "116": [0, 0.61508, 0, 0, 0.38889],
                    "117": [0, 0.43056, 0, 0, 0.55556],
                    "118": [0, 0.43056, 0.01389, 0, 0.52778],
                    "119": [0, 0.43056, 0.01389, 0, 0.72222],
                    "120": [0, 0.43056, 0, 0, 0.52778],
                    "121": [0.19444, 0.43056, 0.01389, 0, 0.52778],
                    "122": [0, 0.43056, 0, 0, 0.44445],
                    "123": [0.25, 0.75, 0, 0, 0.5],
                    "124": [0.25, 0.75, 0, 0, 0.27778],
                    "125": [0.25, 0.75, 0, 0, 0.5],
                    "126": [0.35, 0.31786, 0, 0, 0.5],
                    "160": [0, 0, 0, 0, 0.25],
                    "167": [0.19444, 0.69444, 0, 0, 0.44445],
                    "168": [0, 0.66786, 0, 0, 0.5],
                    "172": [0, 0.43056, 0, 0, 0.66667],
                    "176": [0, 0.69444, 0, 0, 0.75],
                    "177": [0.08333, 0.58333, 0, 0, 0.77778],
                    "182": [0.19444, 0.69444, 0, 0, 0.61111],
                    "184": [0.17014, 0, 0, 0, 0.44445],
                    "198": [0, 0.68333, 0, 0, 0.90278],
                    "215": [0.08333, 0.58333, 0, 0, 0.77778],
                    "216": [0.04861, 0.73194, 0, 0, 0.77778],
                    "223": [0, 0.69444, 0, 0, 0.5],
                    "230": [0, 0.43056, 0, 0, 0.72222],
                    "247": [0.08333, 0.58333, 0, 0, 0.77778],
                    "248": [0.09722, 0.52778, 0, 0, 0.5],
                    "305": [0, 0.43056, 0, 0, 0.27778],
                    "338": [0, 0.68333, 0, 0, 1.01389],
                    "339": [0, 0.43056, 0, 0, 0.77778],
                    "567": [0.19444, 0.43056, 0, 0, 0.30556],
                    "710": [0, 0.69444, 0, 0, 0.5],
                    "711": [0, 0.62847, 0, 0, 0.5],
                    "713": [0, 0.56778, 0, 0, 0.5],
                    "714": [0, 0.69444, 0, 0, 0.5],
                    "715": [0, 0.69444, 0, 0, 0.5],
                    "728": [0, 0.69444, 0, 0, 0.5],
                    "729": [0, 0.66786, 0, 0, 0.27778],
                    "730": [0, 0.69444, 0, 0, 0.75],
                    "732": [0, 0.66786, 0, 0, 0.5],
                    "733": [0, 0.69444, 0, 0, 0.5],
                    "824": [0.19444, 0.69444, 0, 0, 0],
                    "915": [0, 0.68333, 0, 0, 0.625],
                    "916": [0, 0.68333, 0, 0, 0.83334],
                    "920": [0, 0.68333, 0, 0, 0.77778],
                    "923": [0, 0.68333, 0, 0, 0.69445],
                    "926": [0, 0.68333, 0, 0, 0.66667],
                    "928": [0, 0.68333, 0, 0, 0.75],
                    "931": [0, 0.68333, 0, 0, 0.72222],
                    "933": [0, 0.68333, 0, 0, 0.77778],
                    "934": [0, 0.68333, 0, 0, 0.72222],
                    "936": [0, 0.68333, 0, 0, 0.77778],
                    "937": [0, 0.68333, 0, 0, 0.72222],
                    "8211": [0, 0.43056, 0.02778, 0, 0.5],
                    "8212": [0, 0.43056, 0.02778, 0, 1],
                    "8216": [0, 0.69444, 0, 0, 0.27778],
                    "8217": [0, 0.69444, 0, 0, 0.27778],
                    "8220": [0, 0.69444, 0, 0, 0.5],
                    "8221": [0, 0.69444, 0, 0, 0.5],
                    "8224": [0.19444, 0.69444, 0, 0, 0.44445],
                    "8225": [0.19444, 0.69444, 0, 0, 0.44445],
                    "8230": [0, 0.12, 0, 0, 1.172],
                    "8242": [0, 0.55556, 0, 0, 0.275],
                    "8407": [0, 0.71444, 0.15382, 0, 0.5],
                    "8463": [0, 0.68889, 0, 0, 0.54028],
                    "8465": [0, 0.69444, 0, 0, 0.72222],
                    "8467": [0, 0.69444, 0, 0.11111, 0.41667],
                    "8472": [0.19444, 0.43056, 0, 0.11111, 0.63646],
                    "8476": [0, 0.69444, 0, 0, 0.72222],
                    "8501": [0, 0.69444, 0, 0, 0.61111],
                    "8592": [-0.13313, 0.36687, 0, 0, 1],
                    "8593": [0.19444, 0.69444, 0, 0, 0.5],
                    "8594": [-0.13313, 0.36687, 0, 0, 1],
                    "8595": [0.19444, 0.69444, 0, 0, 0.5],
                    "8596": [-0.13313, 0.36687, 0, 0, 1],
                    "8597": [0.25, 0.75, 0, 0, 0.5],
                    "8598": [0.19444, 0.69444, 0, 0, 1],
                    "8599": [0.19444, 0.69444, 0, 0, 1],
                    "8600": [0.19444, 0.69444, 0, 0, 1],
                    "8601": [0.19444, 0.69444, 0, 0, 1],
                    "8614": [0.011, 0.511, 0, 0, 1],
                    "8617": [0.011, 0.511, 0, 0, 1.126],
                    "8618": [0.011, 0.511, 0, 0, 1.126],
                    "8636": [-0.13313, 0.36687, 0, 0, 1],
                    "8637": [-0.13313, 0.36687, 0, 0, 1],
                    "8640": [-0.13313, 0.36687, 0, 0, 1],
                    "8641": [-0.13313, 0.36687, 0, 0, 1],
                    "8652": [0.011, 0.671, 0, 0, 1],
                    "8656": [-0.13313, 0.36687, 0, 0, 1],
                    "8657": [0.19444, 0.69444, 0, 0, 0.61111],
                    "8658": [-0.13313, 0.36687, 0, 0, 1],
                    "8659": [0.19444, 0.69444, 0, 0, 0.61111],
                    "8660": [-0.13313, 0.36687, 0, 0, 1],
                    "8661": [0.25, 0.75, 0, 0, 0.61111],
                    "8704": [0, 0.69444, 0, 0, 0.55556],
                    "8706": [0, 0.69444, 0.05556, 0.08334, 0.5309],
                    "8707": [0, 0.69444, 0, 0, 0.55556],
                    "8709": [0.05556, 0.75, 0, 0, 0.5],
                    "8711": [0, 0.68333, 0, 0, 0.83334],
                    "8712": [0.0391, 0.5391, 0, 0, 0.66667],
                    "8715": [0.0391, 0.5391, 0, 0, 0.66667],
                    "8722": [0.08333, 0.58333, 0, 0, 0.77778],
                    "8723": [0.08333, 0.58333, 0, 0, 0.77778],
                    "8725": [0.25, 0.75, 0, 0, 0.5],
                    "8726": [0.25, 0.75, 0, 0, 0.5],
                    "8727": [-0.03472, 0.46528, 0, 0, 0.5],
                    "8728": [-0.05555, 0.44445, 0, 0, 0.5],
                    "8729": [-0.05555, 0.44445, 0, 0, 0.5],
                    "8730": [0.2, 0.8, 0, 0, 0.83334],
                    "8733": [0, 0.43056, 0, 0, 0.77778],
                    "8734": [0, 0.43056, 0, 0, 1],
                    "8736": [0, 0.69224, 0, 0, 0.72222],
                    "8739": [0.25, 0.75, 0, 0, 0.27778],
                    "8741": [0.25, 0.75, 0, 0, 0.5],
                    "8743": [0, 0.55556, 0, 0, 0.66667],
                    "8744": [0, 0.55556, 0, 0, 0.66667],
                    "8745": [0, 0.55556, 0, 0, 0.66667],
                    "8746": [0, 0.55556, 0, 0, 0.66667],
                    "8747": [0.19444, 0.69444, 0.11111, 0, 0.41667],
                    "8764": [-0.13313, 0.36687, 0, 0, 0.77778],
                    "8768": [0.19444, 0.69444, 0, 0, 0.27778],
                    "8771": [-0.03625, 0.46375, 0, 0, 0.77778],
                    "8773": [-0.022, 0.589, 0, 0, 1],
                    "8776": [-0.01688, 0.48312, 0, 0, 0.77778],
                    "8781": [-0.03625, 0.46375, 0, 0, 0.77778],
                    "8784": [-0.133, 0.67, 0, 0, 0.778],
                    "8800": [0.215, 0.716, 0, 0, 0.778],
                    "8801": [-0.03625, 0.46375, 0, 0, 0.77778],
                    "8804": [0.13597, 0.63597, 0, 0, 0.77778],
                    "8805": [0.13597, 0.63597, 0, 0, 0.77778],
                    "8810": [0.0391, 0.5391, 0, 0, 1],
                    "8811": [0.0391, 0.5391, 0, 0, 1],
                    "8826": [0.0391, 0.5391, 0, 0, 0.77778],
                    "8827": [0.0391, 0.5391, 0, 0, 0.77778],
                    "8834": [0.0391, 0.5391, 0, 0, 0.77778],
                    "8835": [0.0391, 0.5391, 0, 0, 0.77778],
                    "8838": [0.13597, 0.63597, 0, 0, 0.77778],
                    "8839": [0.13597, 0.63597, 0, 0, 0.77778],
                    "8846": [0, 0.55556, 0, 0, 0.66667],
                    "8849": [0.13597, 0.63597, 0, 0, 0.77778],
                    "8850": [0.13597, 0.63597, 0, 0, 0.77778],
                    "8851": [0, 0.55556, 0, 0, 0.66667],
                    "8852": [0, 0.55556, 0, 0, 0.66667],
                    "8853": [0.08333, 0.58333, 0, 0, 0.77778],
                    "8854": [0.08333, 0.58333, 0, 0, 0.77778],
                    "8855": [0.08333, 0.58333, 0, 0, 0.77778],
                    "8856": [0.08333, 0.58333, 0, 0, 0.77778],
                    "8857": [0.08333, 0.58333, 0, 0, 0.77778],
                    "8866": [0, 0.69444, 0, 0, 0.61111],
                    "8867": [0, 0.69444, 0, 0, 0.61111],
                    "8868": [0, 0.69444, 0, 0, 0.77778],
                    "8869": [0, 0.69444, 0, 0, 0.77778],
                    "8872": [0.249, 0.75, 0, 0, 0.867],
                    "8900": [-0.05555, 0.44445, 0, 0, 0.5],
                    "8901": [-0.05555, 0.44445, 0, 0, 0.27778],
                    "8902": [-0.03472, 0.46528, 0, 0, 0.5],
                    "8904": [5e-3, 0.505, 0, 0, 0.9],
                    "8942": [0.03, 0.9, 0, 0, 0.278],
                    "8943": [-0.19, 0.31, 0, 0, 1.172],
                    "8945": [-0.1, 0.82, 0, 0, 1.282],
                    "8968": [0.25, 0.75, 0, 0, 0.44445],
                    "8969": [0.25, 0.75, 0, 0, 0.44445],
                    "8970": [0.25, 0.75, 0, 0, 0.44445],
                    "8971": [0.25, 0.75, 0, 0, 0.44445],
                    "8994": [-0.14236, 0.35764, 0, 0, 1],
                    "8995": [-0.14236, 0.35764, 0, 0, 1],
                    "9136": [0.244, 0.744, 0, 0, 0.412],
                    "9137": [0.244, 0.744, 0, 0, 0.412],
                    "9651": [0.19444, 0.69444, 0, 0, 0.88889],
                    "9657": [-0.03472, 0.46528, 0, 0, 0.5],
                    "9661": [0.19444, 0.69444, 0, 0, 0.88889],
                    "9667": [-0.03472, 0.46528, 0, 0, 0.5],
                    "9711": [0.19444, 0.69444, 0, 0, 1],
                    "9824": [0.12963, 0.69444, 0, 0, 0.77778],
                    "9825": [0.12963, 0.69444, 0, 0, 0.77778],
                    "9826": [0.12963, 0.69444, 0, 0, 0.77778],
                    "9827": [0.12963, 0.69444, 0, 0, 0.77778],
                    "9837": [0, 0.75, 0, 0, 0.38889],
                    "9838": [0.19444, 0.69444, 0, 0, 0.38889],
                    "9839": [0.19444, 0.69444, 0, 0, 0.38889],
                    "10216": [0.25, 0.75, 0, 0, 0.38889],
                    "10217": [0.25, 0.75, 0, 0, 0.38889],
                    "10222": [0.244, 0.744, 0, 0, 0.412],
                    "10223": [0.244, 0.744, 0, 0, 0.412],
                    "10229": [0.011, 0.511, 0, 0, 1.609],
                    "10230": [0.011, 0.511, 0, 0, 1.638],
                    "10231": [0.011, 0.511, 0, 0, 1.859],
                    "10232": [0.024, 0.525, 0, 0, 1.609],
                    "10233": [0.024, 0.525, 0, 0, 1.638],
                    "10234": [0.024, 0.525, 0, 0, 1.858],
                    "10236": [0.011, 0.511, 0, 0, 1.638],
                    "10815": [0, 0.68333, 0, 0, 0.75],
                    "10927": [0.13597, 0.63597, 0, 0, 0.77778],
                    "10928": [0.13597, 0.63597, 0, 0, 0.77778]
                  },
                  "Math-BoldItalic": {
                    "47": [0.19444, 0.69444, 0, 0, 0],
                    "65": [0, 0.68611, 0, 0, 0.86944],
                    "66": [0, 0.68611, 0.04835, 0, 0.8664],
                    "67": [0, 0.68611, 0.06979, 0, 0.81694],
                    "68": [0, 0.68611, 0.03194, 0, 0.93812],
                    "69": [0, 0.68611, 0.05451, 0, 0.81007],
                    "70": [0, 0.68611, 0.15972, 0, 0.68889],
                    "71": [0, 0.68611, 0, 0, 0.88673],
                    "72": [0, 0.68611, 0.08229, 0, 0.98229],
                    "73": [0, 0.68611, 0.07778, 0, 0.51111],
                    "74": [0, 0.68611, 0.10069, 0, 0.63125],
                    "75": [0, 0.68611, 0.06979, 0, 0.97118],
                    "76": [0, 0.68611, 0, 0, 0.75555],
                    "77": [0, 0.68611, 0.11424, 0, 1.14201],
                    "78": [0, 0.68611, 0.11424, 0, 0.95034],
                    "79": [0, 0.68611, 0.03194, 0, 0.83666],
                    "80": [0, 0.68611, 0.15972, 0, 0.72309],
                    "81": [0.19444, 0.68611, 0, 0, 0.86861],
                    "82": [0, 0.68611, 421e-5, 0, 0.87235],
                    "83": [0, 0.68611, 0.05382, 0, 0.69271],
                    "84": [0, 0.68611, 0.15972, 0, 0.63663],
                    "85": [0, 0.68611, 0.11424, 0, 0.80027],
                    "86": [0, 0.68611, 0.25555, 0, 0.67778],
                    "87": [0, 0.68611, 0.15972, 0, 1.09305],
                    "88": [0, 0.68611, 0.07778, 0, 0.94722],
                    "89": [0, 0.68611, 0.25555, 0, 0.67458],
                    "90": [0, 0.68611, 0.06979, 0, 0.77257],
                    "97": [0, 0.44444, 0, 0, 0.63287],
                    "98": [0, 0.69444, 0, 0, 0.52083],
                    "99": [0, 0.44444, 0, 0, 0.51342],
                    "100": [0, 0.69444, 0, 0, 0.60972],
                    "101": [0, 0.44444, 0, 0, 0.55361],
                    "102": [0.19444, 0.69444, 0.11042, 0, 0.56806],
                    "103": [0.19444, 0.44444, 0.03704, 0, 0.5449],
                    "104": [0, 0.69444, 0, 0, 0.66759],
                    "105": [0, 0.69326, 0, 0, 0.4048],
                    "106": [0.19444, 0.69326, 0.0622, 0, 0.47083],
                    "107": [0, 0.69444, 0.01852, 0, 0.6037],
                    "108": [0, 0.69444, 88e-4, 0, 0.34815],
                    "109": [0, 0.44444, 0, 0, 1.0324],
                    "110": [0, 0.44444, 0, 0, 0.71296],
                    "111": [0, 0.44444, 0, 0, 0.58472],
                    "112": [0.19444, 0.44444, 0, 0, 0.60092],
                    "113": [0.19444, 0.44444, 0.03704, 0, 0.54213],
                    "114": [0, 0.44444, 0.03194, 0, 0.5287],
                    "115": [0, 0.44444, 0, 0, 0.53125],
                    "116": [0, 0.63492, 0, 0, 0.41528],
                    "117": [0, 0.44444, 0, 0, 0.68102],
                    "118": [0, 0.44444, 0.03704, 0, 0.56666],
                    "119": [0, 0.44444, 0.02778, 0, 0.83148],
                    "120": [0, 0.44444, 0, 0, 0.65903],
                    "121": [0.19444, 0.44444, 0.03704, 0, 0.59028],
                    "122": [0, 0.44444, 0.04213, 0, 0.55509],
                    "915": [0, 0.68611, 0.15972, 0, 0.65694],
                    "916": [0, 0.68611, 0, 0, 0.95833],
                    "920": [0, 0.68611, 0.03194, 0, 0.86722],
                    "923": [0, 0.68611, 0, 0, 0.80555],
                    "926": [0, 0.68611, 0.07458, 0, 0.84125],
                    "928": [0, 0.68611, 0.08229, 0, 0.98229],
                    "931": [0, 0.68611, 0.05451, 0, 0.88507],
                    "933": [0, 0.68611, 0.15972, 0, 0.67083],
                    "934": [0, 0.68611, 0, 0, 0.76666],
                    "936": [0, 0.68611, 0.11653, 0, 0.71402],
                    "937": [0, 0.68611, 0.04835, 0, 0.8789],
                    "945": [0, 0.44444, 0, 0, 0.76064],
                    "946": [0.19444, 0.69444, 0.03403, 0, 0.65972],
                    "947": [0.19444, 0.44444, 0.06389, 0, 0.59003],
                    "948": [0, 0.69444, 0.03819, 0, 0.52222],
                    "949": [0, 0.44444, 0, 0, 0.52882],
                    "950": [0.19444, 0.69444, 0.06215, 0, 0.50833],
                    "951": [0.19444, 0.44444, 0.03704, 0, 0.6],
                    "952": [0, 0.69444, 0.03194, 0, 0.5618],
                    "953": [0, 0.44444, 0, 0, 0.41204],
                    "954": [0, 0.44444, 0, 0, 0.66759],
                    "955": [0, 0.69444, 0, 0, 0.67083],
                    "956": [0.19444, 0.44444, 0, 0, 0.70787],
                    "957": [0, 0.44444, 0.06898, 0, 0.57685],
                    "958": [0.19444, 0.69444, 0.03021, 0, 0.50833],
                    "959": [0, 0.44444, 0, 0, 0.58472],
                    "960": [0, 0.44444, 0.03704, 0, 0.68241],
                    "961": [0.19444, 0.44444, 0, 0, 0.6118],
                    "962": [0.09722, 0.44444, 0.07917, 0, 0.42361],
                    "963": [0, 0.44444, 0.03704, 0, 0.68588],
                    "964": [0, 0.44444, 0.13472, 0, 0.52083],
                    "965": [0, 0.44444, 0.03704, 0, 0.63055],
                    "966": [0.19444, 0.44444, 0, 0, 0.74722],
                    "967": [0.19444, 0.44444, 0, 0, 0.71805],
                    "968": [0.19444, 0.69444, 0.03704, 0, 0.75833],
                    "969": [0, 0.44444, 0.03704, 0, 0.71782],
                    "977": [0, 0.69444, 0, 0, 0.69155],
                    "981": [0.19444, 0.69444, 0, 0, 0.7125],
                    "982": [0, 0.44444, 0.03194, 0, 0.975],
                    "1009": [0.19444, 0.44444, 0, 0, 0.6118],
                    "1013": [0, 0.44444, 0, 0, 0.48333]
                  },
                  "Math-Italic": {
                    "47": [0.19444, 0.69444, 0, 0, 0],
                    "65": [0, 0.68333, 0, 0.13889, 0.75],
                    "66": [0, 0.68333, 0.05017, 0.08334, 0.75851],
                    "67": [0, 0.68333, 0.07153, 0.08334, 0.71472],
                    "68": [0, 0.68333, 0.02778, 0.05556, 0.82792],
                    "69": [0, 0.68333, 0.05764, 0.08334, 0.7382],
                    "70": [0, 0.68333, 0.13889, 0.08334, 0.64306],
                    "71": [0, 0.68333, 0, 0.08334, 0.78625],
                    "72": [0, 0.68333, 0.08125, 0.05556, 0.83125],
                    "73": [0, 0.68333, 0.07847, 0.11111, 0.43958],
                    "74": [0, 0.68333, 0.09618, 0.16667, 0.55451],
                    "75": [0, 0.68333, 0.07153, 0.05556, 0.84931],
                    "76": [0, 0.68333, 0, 0.02778, 0.68056],
                    "77": [0, 0.68333, 0.10903, 0.08334, 0.97014],
                    "78": [0, 0.68333, 0.10903, 0.08334, 0.80347],
                    "79": [0, 0.68333, 0.02778, 0.08334, 0.76278],
                    "80": [0, 0.68333, 0.13889, 0.08334, 0.64201],
                    "81": [0.19444, 0.68333, 0, 0.08334, 0.79056],
                    "82": [0, 0.68333, 773e-5, 0.08334, 0.75929],
                    "83": [0, 0.68333, 0.05764, 0.08334, 0.6132],
                    "84": [0, 0.68333, 0.13889, 0.08334, 0.58438],
                    "85": [0, 0.68333, 0.10903, 0.02778, 0.68278],
                    "86": [0, 0.68333, 0.22222, 0, 0.58333],
                    "87": [0, 0.68333, 0.13889, 0, 0.94445],
                    "88": [0, 0.68333, 0.07847, 0.08334, 0.82847],
                    "89": [0, 0.68333, 0.22222, 0, 0.58056],
                    "90": [0, 0.68333, 0.07153, 0.08334, 0.68264],
                    "97": [0, 0.43056, 0, 0, 0.52859],
                    "98": [0, 0.69444, 0, 0, 0.42917],
                    "99": [0, 0.43056, 0, 0.05556, 0.43276],
                    "100": [0, 0.69444, 0, 0.16667, 0.52049],
                    "101": [0, 0.43056, 0, 0.05556, 0.46563],
                    "102": [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
                    "103": [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
                    "104": [0, 0.69444, 0, 0, 0.57616],
                    "105": [0, 0.65952, 0, 0, 0.34451],
                    "106": [0.19444, 0.65952, 0.05724, 0, 0.41181],
                    "107": [0, 0.69444, 0.03148, 0, 0.5206],
                    "108": [0, 0.69444, 0.01968, 0.08334, 0.29838],
                    "109": [0, 0.43056, 0, 0, 0.87801],
                    "110": [0, 0.43056, 0, 0, 0.60023],
                    "111": [0, 0.43056, 0, 0.05556, 0.48472],
                    "112": [0.19444, 0.43056, 0, 0.08334, 0.50313],
                    "113": [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
                    "114": [0, 0.43056, 0.02778, 0.05556, 0.45116],
                    "115": [0, 0.43056, 0, 0.05556, 0.46875],
                    "116": [0, 0.61508, 0, 0.08334, 0.36111],
                    "117": [0, 0.43056, 0, 0.02778, 0.57246],
                    "118": [0, 0.43056, 0.03588, 0.02778, 0.48472],
                    "119": [0, 0.43056, 0.02691, 0.08334, 0.71592],
                    "120": [0, 0.43056, 0, 0.02778, 0.57153],
                    "121": [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
                    "122": [0, 0.43056, 0.04398, 0.05556, 0.46505],
                    "915": [0, 0.68333, 0.13889, 0.08334, 0.61528],
                    "916": [0, 0.68333, 0, 0.16667, 0.83334],
                    "920": [0, 0.68333, 0.02778, 0.08334, 0.76278],
                    "923": [0, 0.68333, 0, 0.16667, 0.69445],
                    "926": [0, 0.68333, 0.07569, 0.08334, 0.74236],
                    "928": [0, 0.68333, 0.08125, 0.05556, 0.83125],
                    "931": [0, 0.68333, 0.05764, 0.08334, 0.77986],
                    "933": [0, 0.68333, 0.13889, 0.05556, 0.58333],
                    "934": [0, 0.68333, 0, 0.08334, 0.66667],
                    "936": [0, 0.68333, 0.11, 0.05556, 0.61222],
                    "937": [0, 0.68333, 0.05017, 0.08334, 0.7724],
                    "945": [0, 0.43056, 37e-4, 0.02778, 0.6397],
                    "946": [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
                    "947": [0.19444, 0.43056, 0.05556, 0, 0.51773],
                    "948": [0, 0.69444, 0.03785, 0.05556, 0.44444],
                    "949": [0, 0.43056, 0, 0.08334, 0.46632],
                    "950": [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
                    "951": [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
                    "952": [0, 0.69444, 0.02778, 0.08334, 0.46944],
                    "953": [0, 0.43056, 0, 0.05556, 0.35394],
                    "954": [0, 0.43056, 0, 0, 0.57616],
                    "955": [0, 0.69444, 0, 0, 0.58334],
                    "956": [0.19444, 0.43056, 0, 0.02778, 0.60255],
                    "957": [0, 0.43056, 0.06366, 0.02778, 0.49398],
                    "958": [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
                    "959": [0, 0.43056, 0, 0.05556, 0.48472],
                    "960": [0, 0.43056, 0.03588, 0, 0.57003],
                    "961": [0.19444, 0.43056, 0, 0.08334, 0.51702],
                    "962": [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
                    "963": [0, 0.43056, 0.03588, 0, 0.57141],
                    "964": [0, 0.43056, 0.1132, 0.02778, 0.43715],
                    "965": [0, 0.43056, 0.03588, 0.02778, 0.54028],
                    "966": [0.19444, 0.43056, 0, 0.08334, 0.65417],
                    "967": [0.19444, 0.43056, 0, 0.05556, 0.62569],
                    "968": [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
                    "969": [0, 0.43056, 0.03588, 0, 0.62245],
                    "977": [0, 0.69444, 0, 0.08334, 0.59144],
                    "981": [0.19444, 0.69444, 0, 0.08334, 0.59583],
                    "982": [0, 0.43056, 0.02778, 0, 0.82813],
                    "1009": [0.19444, 0.43056, 0, 0.08334, 0.51702],
                    "1013": [0, 0.43056, 0, 0.05556, 0.4059]
                  },
                  "Math-Regular": {
                    "65": [0, 0.68333, 0, 0.13889, 0.75],
                    "66": [0, 0.68333, 0.05017, 0.08334, 0.75851],
                    "67": [0, 0.68333, 0.07153, 0.08334, 0.71472],
                    "68": [0, 0.68333, 0.02778, 0.05556, 0.82792],
                    "69": [0, 0.68333, 0.05764, 0.08334, 0.7382],
                    "70": [0, 0.68333, 0.13889, 0.08334, 0.64306],
                    "71": [0, 0.68333, 0, 0.08334, 0.78625],
                    "72": [0, 0.68333, 0.08125, 0.05556, 0.83125],
                    "73": [0, 0.68333, 0.07847, 0.11111, 0.43958],
                    "74": [0, 0.68333, 0.09618, 0.16667, 0.55451],
                    "75": [0, 0.68333, 0.07153, 0.05556, 0.84931],
                    "76": [0, 0.68333, 0, 0.02778, 0.68056],
                    "77": [0, 0.68333, 0.10903, 0.08334, 0.97014],
                    "78": [0, 0.68333, 0.10903, 0.08334, 0.80347],
                    "79": [0, 0.68333, 0.02778, 0.08334, 0.76278],
                    "80": [0, 0.68333, 0.13889, 0.08334, 0.64201],
                    "81": [0.19444, 0.68333, 0, 0.08334, 0.79056],
                    "82": [0, 0.68333, 773e-5, 0.08334, 0.75929],
                    "83": [0, 0.68333, 0.05764, 0.08334, 0.6132],
                    "84": [0, 0.68333, 0.13889, 0.08334, 0.58438],
                    "85": [0, 0.68333, 0.10903, 0.02778, 0.68278],
                    "86": [0, 0.68333, 0.22222, 0, 0.58333],
                    "87": [0, 0.68333, 0.13889, 0, 0.94445],
                    "88": [0, 0.68333, 0.07847, 0.08334, 0.82847],
                    "89": [0, 0.68333, 0.22222, 0, 0.58056],
                    "90": [0, 0.68333, 0.07153, 0.08334, 0.68264],
                    "97": [0, 0.43056, 0, 0, 0.52859],
                    "98": [0, 0.69444, 0, 0, 0.42917],
                    "99": [0, 0.43056, 0, 0.05556, 0.43276],
                    "100": [0, 0.69444, 0, 0.16667, 0.52049],
                    "101": [0, 0.43056, 0, 0.05556, 0.46563],
                    "102": [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
                    "103": [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
                    "104": [0, 0.69444, 0, 0, 0.57616],
                    "105": [0, 0.65952, 0, 0, 0.34451],
                    "106": [0.19444, 0.65952, 0.05724, 0, 0.41181],
                    "107": [0, 0.69444, 0.03148, 0, 0.5206],
                    "108": [0, 0.69444, 0.01968, 0.08334, 0.29838],
                    "109": [0, 0.43056, 0, 0, 0.87801],
                    "110": [0, 0.43056, 0, 0, 0.60023],
                    "111": [0, 0.43056, 0, 0.05556, 0.48472],
                    "112": [0.19444, 0.43056, 0, 0.08334, 0.50313],
                    "113": [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
                    "114": [0, 0.43056, 0.02778, 0.05556, 0.45116],
                    "115": [0, 0.43056, 0, 0.05556, 0.46875],
                    "116": [0, 0.61508, 0, 0.08334, 0.36111],
                    "117": [0, 0.43056, 0, 0.02778, 0.57246],
                    "118": [0, 0.43056, 0.03588, 0.02778, 0.48472],
                    "119": [0, 0.43056, 0.02691, 0.08334, 0.71592],
                    "120": [0, 0.43056, 0, 0.02778, 0.57153],
                    "121": [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
                    "122": [0, 0.43056, 0.04398, 0.05556, 0.46505],
                    "915": [0, 0.68333, 0.13889, 0.08334, 0.61528],
                    "916": [0, 0.68333, 0, 0.16667, 0.83334],
                    "920": [0, 0.68333, 0.02778, 0.08334, 0.76278],
                    "923": [0, 0.68333, 0, 0.16667, 0.69445],
                    "926": [0, 0.68333, 0.07569, 0.08334, 0.74236],
                    "928": [0, 0.68333, 0.08125, 0.05556, 0.83125],
                    "931": [0, 0.68333, 0.05764, 0.08334, 0.77986],
                    "933": [0, 0.68333, 0.13889, 0.05556, 0.58333],
                    "934": [0, 0.68333, 0, 0.08334, 0.66667],
                    "936": [0, 0.68333, 0.11, 0.05556, 0.61222],
                    "937": [0, 0.68333, 0.05017, 0.08334, 0.7724],
                    "945": [0, 0.43056, 37e-4, 0.02778, 0.6397],
                    "946": [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
                    "947": [0.19444, 0.43056, 0.05556, 0, 0.51773],
                    "948": [0, 0.69444, 0.03785, 0.05556, 0.44444],
                    "949": [0, 0.43056, 0, 0.08334, 0.46632],
                    "950": [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
                    "951": [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
                    "952": [0, 0.69444, 0.02778, 0.08334, 0.46944],
                    "953": [0, 0.43056, 0, 0.05556, 0.35394],
                    "954": [0, 0.43056, 0, 0, 0.57616],
                    "955": [0, 0.69444, 0, 0, 0.58334],
                    "956": [0.19444, 0.43056, 0, 0.02778, 0.60255],
                    "957": [0, 0.43056, 0.06366, 0.02778, 0.49398],
                    "958": [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
                    "959": [0, 0.43056, 0, 0.05556, 0.48472],
                    "960": [0, 0.43056, 0.03588, 0, 0.57003],
                    "961": [0.19444, 0.43056, 0, 0.08334, 0.51702],
                    "962": [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
                    "963": [0, 0.43056, 0.03588, 0, 0.57141],
                    "964": [0, 0.43056, 0.1132, 0.02778, 0.43715],
                    "965": [0, 0.43056, 0.03588, 0.02778, 0.54028],
                    "966": [0.19444, 0.43056, 0, 0.08334, 0.65417],
                    "967": [0.19444, 0.43056, 0, 0.05556, 0.62569],
                    "968": [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
                    "969": [0, 0.43056, 0.03588, 0, 0.62245],
                    "977": [0, 0.69444, 0, 0.08334, 0.59144],
                    "981": [0.19444, 0.69444, 0, 0.08334, 0.59583],
                    "982": [0, 0.43056, 0.02778, 0, 0.82813],
                    "1009": [0.19444, 0.43056, 0, 0.08334, 0.51702],
                    "1013": [0, 0.43056, 0, 0.05556, 0.4059]
                  },
                  "SansSerif-Bold": {
                    "33": [0, 0.69444, 0, 0, 0.36667],
                    "34": [0, 0.69444, 0, 0, 0.55834],
                    "35": [0.19444, 0.69444, 0, 0, 0.91667],
                    "36": [0.05556, 0.75, 0, 0, 0.55],
                    "37": [0.05556, 0.75, 0, 0, 1.02912],
                    "38": [0, 0.69444, 0, 0, 0.83056],
                    "39": [0, 0.69444, 0, 0, 0.30556],
                    "40": [0.25, 0.75, 0, 0, 0.42778],
                    "41": [0.25, 0.75, 0, 0, 0.42778],
                    "42": [0, 0.75, 0, 0, 0.55],
                    "43": [0.11667, 0.61667, 0, 0, 0.85556],
                    "44": [0.10556, 0.13056, 0, 0, 0.30556],
                    "45": [0, 0.45833, 0, 0, 0.36667],
                    "46": [0, 0.13056, 0, 0, 0.30556],
                    "47": [0.25, 0.75, 0, 0, 0.55],
                    "48": [0, 0.69444, 0, 0, 0.55],
                    "49": [0, 0.69444, 0, 0, 0.55],
                    "50": [0, 0.69444, 0, 0, 0.55],
                    "51": [0, 0.69444, 0, 0, 0.55],
                    "52": [0, 0.69444, 0, 0, 0.55],
                    "53": [0, 0.69444, 0, 0, 0.55],
                    "54": [0, 0.69444, 0, 0, 0.55],
                    "55": [0, 0.69444, 0, 0, 0.55],
                    "56": [0, 0.69444, 0, 0, 0.55],
                    "57": [0, 0.69444, 0, 0, 0.55],
                    "58": [0, 0.45833, 0, 0, 0.30556],
                    "59": [0.10556, 0.45833, 0, 0, 0.30556],
                    "61": [-0.09375, 0.40625, 0, 0, 0.85556],
                    "63": [0, 0.69444, 0, 0, 0.51945],
                    "64": [0, 0.69444, 0, 0, 0.73334],
                    "65": [0, 0.69444, 0, 0, 0.73334],
                    "66": [0, 0.69444, 0, 0, 0.73334],
                    "67": [0, 0.69444, 0, 0, 0.70278],
                    "68": [0, 0.69444, 0, 0, 0.79445],
                    "69": [0, 0.69444, 0, 0, 0.64167],
                    "70": [0, 0.69444, 0, 0, 0.61111],
                    "71": [0, 0.69444, 0, 0, 0.73334],
                    "72": [0, 0.69444, 0, 0, 0.79445],
                    "73": [0, 0.69444, 0, 0, 0.33056],
                    "74": [0, 0.69444, 0, 0, 0.51945],
                    "75": [0, 0.69444, 0, 0, 0.76389],
                    "76": [0, 0.69444, 0, 0, 0.58056],
                    "77": [0, 0.69444, 0, 0, 0.97778],
                    "78": [0, 0.69444, 0, 0, 0.79445],
                    "79": [0, 0.69444, 0, 0, 0.79445],
                    "80": [0, 0.69444, 0, 0, 0.70278],
                    "81": [0.10556, 0.69444, 0, 0, 0.79445],
                    "82": [0, 0.69444, 0, 0, 0.70278],
                    "83": [0, 0.69444, 0, 0, 0.61111],
                    "84": [0, 0.69444, 0, 0, 0.73334],
                    "85": [0, 0.69444, 0, 0, 0.76389],
                    "86": [0, 0.69444, 0.01528, 0, 0.73334],
                    "87": [0, 0.69444, 0.01528, 0, 1.03889],
                    "88": [0, 0.69444, 0, 0, 0.73334],
                    "89": [0, 0.69444, 0.0275, 0, 0.73334],
                    "90": [0, 0.69444, 0, 0, 0.67223],
                    "91": [0.25, 0.75, 0, 0, 0.34306],
                    "93": [0.25, 0.75, 0, 0, 0.34306],
                    "94": [0, 0.69444, 0, 0, 0.55],
                    "95": [0.35, 0.10833, 0.03056, 0, 0.55],
                    "97": [0, 0.45833, 0, 0, 0.525],
                    "98": [0, 0.69444, 0, 0, 0.56111],
                    "99": [0, 0.45833, 0, 0, 0.48889],
                    "100": [0, 0.69444, 0, 0, 0.56111],
                    "101": [0, 0.45833, 0, 0, 0.51111],
                    "102": [0, 0.69444, 0.07639, 0, 0.33611],
                    "103": [0.19444, 0.45833, 0.01528, 0, 0.55],
                    "104": [0, 0.69444, 0, 0, 0.56111],
                    "105": [0, 0.69444, 0, 0, 0.25556],
                    "106": [0.19444, 0.69444, 0, 0, 0.28611],
                    "107": [0, 0.69444, 0, 0, 0.53056],
                    "108": [0, 0.69444, 0, 0, 0.25556],
                    "109": [0, 0.45833, 0, 0, 0.86667],
                    "110": [0, 0.45833, 0, 0, 0.56111],
                    "111": [0, 0.45833, 0, 0, 0.55],
                    "112": [0.19444, 0.45833, 0, 0, 0.56111],
                    "113": [0.19444, 0.45833, 0, 0, 0.56111],
                    "114": [0, 0.45833, 0.01528, 0, 0.37222],
                    "115": [0, 0.45833, 0, 0, 0.42167],
                    "116": [0, 0.58929, 0, 0, 0.40417],
                    "117": [0, 0.45833, 0, 0, 0.56111],
                    "118": [0, 0.45833, 0.01528, 0, 0.5],
                    "119": [0, 0.45833, 0.01528, 0, 0.74445],
                    "120": [0, 0.45833, 0, 0, 0.5],
                    "121": [0.19444, 0.45833, 0.01528, 0, 0.5],
                    "122": [0, 0.45833, 0, 0, 0.47639],
                    "126": [0.35, 0.34444, 0, 0, 0.55],
                    "168": [0, 0.69444, 0, 0, 0.55],
                    "176": [0, 0.69444, 0, 0, 0.73334],
                    "180": [0, 0.69444, 0, 0, 0.55],
                    "184": [0.17014, 0, 0, 0, 0.48889],
                    "305": [0, 0.45833, 0, 0, 0.25556],
                    "567": [0.19444, 0.45833, 0, 0, 0.28611],
                    "710": [0, 0.69444, 0, 0, 0.55],
                    "711": [0, 0.63542, 0, 0, 0.55],
                    "713": [0, 0.63778, 0, 0, 0.55],
                    "728": [0, 0.69444, 0, 0, 0.55],
                    "729": [0, 0.69444, 0, 0, 0.30556],
                    "730": [0, 0.69444, 0, 0, 0.73334],
                    "732": [0, 0.69444, 0, 0, 0.55],
                    "733": [0, 0.69444, 0, 0, 0.55],
                    "915": [0, 0.69444, 0, 0, 0.58056],
                    "916": [0, 0.69444, 0, 0, 0.91667],
                    "920": [0, 0.69444, 0, 0, 0.85556],
                    "923": [0, 0.69444, 0, 0, 0.67223],
                    "926": [0, 0.69444, 0, 0, 0.73334],
                    "928": [0, 0.69444, 0, 0, 0.79445],
                    "931": [0, 0.69444, 0, 0, 0.79445],
                    "933": [0, 0.69444, 0, 0, 0.85556],
                    "934": [0, 0.69444, 0, 0, 0.79445],
                    "936": [0, 0.69444, 0, 0, 0.85556],
                    "937": [0, 0.69444, 0, 0, 0.79445],
                    "8211": [0, 0.45833, 0.03056, 0, 0.55],
                    "8212": [0, 0.45833, 0.03056, 0, 1.10001],
                    "8216": [0, 0.69444, 0, 0, 0.30556],
                    "8217": [0, 0.69444, 0, 0, 0.30556],
                    "8220": [0, 0.69444, 0, 0, 0.55834],
                    "8221": [0, 0.69444, 0, 0, 0.55834]
                  },
                  "SansSerif-Italic": {
                    "33": [0, 0.69444, 0.05733, 0, 0.31945],
                    "34": [0, 0.69444, 316e-5, 0, 0.5],
                    "35": [0.19444, 0.69444, 0.05087, 0, 0.83334],
                    "36": [0.05556, 0.75, 0.11156, 0, 0.5],
                    "37": [0.05556, 0.75, 0.03126, 0, 0.83334],
                    "38": [0, 0.69444, 0.03058, 0, 0.75834],
                    "39": [0, 0.69444, 0.07816, 0, 0.27778],
                    "40": [0.25, 0.75, 0.13164, 0, 0.38889],
                    "41": [0.25, 0.75, 0.02536, 0, 0.38889],
                    "42": [0, 0.75, 0.11775, 0, 0.5],
                    "43": [0.08333, 0.58333, 0.02536, 0, 0.77778],
                    "44": [0.125, 0.08333, 0, 0, 0.27778],
                    "45": [0, 0.44444, 0.01946, 0, 0.33333],
                    "46": [0, 0.08333, 0, 0, 0.27778],
                    "47": [0.25, 0.75, 0.13164, 0, 0.5],
                    "48": [0, 0.65556, 0.11156, 0, 0.5],
                    "49": [0, 0.65556, 0.11156, 0, 0.5],
                    "50": [0, 0.65556, 0.11156, 0, 0.5],
                    "51": [0, 0.65556, 0.11156, 0, 0.5],
                    "52": [0, 0.65556, 0.11156, 0, 0.5],
                    "53": [0, 0.65556, 0.11156, 0, 0.5],
                    "54": [0, 0.65556, 0.11156, 0, 0.5],
                    "55": [0, 0.65556, 0.11156, 0, 0.5],
                    "56": [0, 0.65556, 0.11156, 0, 0.5],
                    "57": [0, 0.65556, 0.11156, 0, 0.5],
                    "58": [0, 0.44444, 0.02502, 0, 0.27778],
                    "59": [0.125, 0.44444, 0.02502, 0, 0.27778],
                    "61": [-0.13, 0.37, 0.05087, 0, 0.77778],
                    "63": [0, 0.69444, 0.11809, 0, 0.47222],
                    "64": [0, 0.69444, 0.07555, 0, 0.66667],
                    "65": [0, 0.69444, 0, 0, 0.66667],
                    "66": [0, 0.69444, 0.08293, 0, 0.66667],
                    "67": [0, 0.69444, 0.11983, 0, 0.63889],
                    "68": [0, 0.69444, 0.07555, 0, 0.72223],
                    "69": [0, 0.69444, 0.11983, 0, 0.59722],
                    "70": [0, 0.69444, 0.13372, 0, 0.56945],
                    "71": [0, 0.69444, 0.11983, 0, 0.66667],
                    "72": [0, 0.69444, 0.08094, 0, 0.70834],
                    "73": [0, 0.69444, 0.13372, 0, 0.27778],
                    "74": [0, 0.69444, 0.08094, 0, 0.47222],
                    "75": [0, 0.69444, 0.11983, 0, 0.69445],
                    "76": [0, 0.69444, 0, 0, 0.54167],
                    "77": [0, 0.69444, 0.08094, 0, 0.875],
                    "78": [0, 0.69444, 0.08094, 0, 0.70834],
                    "79": [0, 0.69444, 0.07555, 0, 0.73611],
                    "80": [0, 0.69444, 0.08293, 0, 0.63889],
                    "81": [0.125, 0.69444, 0.07555, 0, 0.73611],
                    "82": [0, 0.69444, 0.08293, 0, 0.64584],
                    "83": [0, 0.69444, 0.09205, 0, 0.55556],
                    "84": [0, 0.69444, 0.13372, 0, 0.68056],
                    "85": [0, 0.69444, 0.08094, 0, 0.6875],
                    "86": [0, 0.69444, 0.1615, 0, 0.66667],
                    "87": [0, 0.69444, 0.1615, 0, 0.94445],
                    "88": [0, 0.69444, 0.13372, 0, 0.66667],
                    "89": [0, 0.69444, 0.17261, 0, 0.66667],
                    "90": [0, 0.69444, 0.11983, 0, 0.61111],
                    "91": [0.25, 0.75, 0.15942, 0, 0.28889],
                    "93": [0.25, 0.75, 0.08719, 0, 0.28889],
                    "94": [0, 0.69444, 0.0799, 0, 0.5],
                    "95": [0.35, 0.09444, 0.08616, 0, 0.5],
                    "97": [0, 0.44444, 981e-5, 0, 0.48056],
                    "98": [0, 0.69444, 0.03057, 0, 0.51667],
                    "99": [0, 0.44444, 0.08336, 0, 0.44445],
                    "100": [0, 0.69444, 0.09483, 0, 0.51667],
                    "101": [0, 0.44444, 0.06778, 0, 0.44445],
                    "102": [0, 0.69444, 0.21705, 0, 0.30556],
                    "103": [0.19444, 0.44444, 0.10836, 0, 0.5],
                    "104": [0, 0.69444, 0.01778, 0, 0.51667],
                    "105": [0, 0.67937, 0.09718, 0, 0.23889],
                    "106": [0.19444, 0.67937, 0.09162, 0, 0.26667],
                    "107": [0, 0.69444, 0.08336, 0, 0.48889],
                    "108": [0, 0.69444, 0.09483, 0, 0.23889],
                    "109": [0, 0.44444, 0.01778, 0, 0.79445],
                    "110": [0, 0.44444, 0.01778, 0, 0.51667],
                    "111": [0, 0.44444, 0.06613, 0, 0.5],
                    "112": [0.19444, 0.44444, 0.0389, 0, 0.51667],
                    "113": [0.19444, 0.44444, 0.04169, 0, 0.51667],
                    "114": [0, 0.44444, 0.10836, 0, 0.34167],
                    "115": [0, 0.44444, 0.0778, 0, 0.38333],
                    "116": [0, 0.57143, 0.07225, 0, 0.36111],
                    "117": [0, 0.44444, 0.04169, 0, 0.51667],
                    "118": [0, 0.44444, 0.10836, 0, 0.46111],
                    "119": [0, 0.44444, 0.10836, 0, 0.68334],
                    "120": [0, 0.44444, 0.09169, 0, 0.46111],
                    "121": [0.19444, 0.44444, 0.10836, 0, 0.46111],
                    "122": [0, 0.44444, 0.08752, 0, 0.43472],
                    "126": [0.35, 0.32659, 0.08826, 0, 0.5],
                    "168": [0, 0.67937, 0.06385, 0, 0.5],
                    "176": [0, 0.69444, 0, 0, 0.73752],
                    "184": [0.17014, 0, 0, 0, 0.44445],
                    "305": [0, 0.44444, 0.04169, 0, 0.23889],
                    "567": [0.19444, 0.44444, 0.04169, 0, 0.26667],
                    "710": [0, 0.69444, 0.0799, 0, 0.5],
                    "711": [0, 0.63194, 0.08432, 0, 0.5],
                    "713": [0, 0.60889, 0.08776, 0, 0.5],
                    "714": [0, 0.69444, 0.09205, 0, 0.5],
                    "715": [0, 0.69444, 0, 0, 0.5],
                    "728": [0, 0.69444, 0.09483, 0, 0.5],
                    "729": [0, 0.67937, 0.07774, 0, 0.27778],
                    "730": [0, 0.69444, 0, 0, 0.73752],
                    "732": [0, 0.67659, 0.08826, 0, 0.5],
                    "733": [0, 0.69444, 0.09205, 0, 0.5],
                    "915": [0, 0.69444, 0.13372, 0, 0.54167],
                    "916": [0, 0.69444, 0, 0, 0.83334],
                    "920": [0, 0.69444, 0.07555, 0, 0.77778],
                    "923": [0, 0.69444, 0, 0, 0.61111],
                    "926": [0, 0.69444, 0.12816, 0, 0.66667],
                    "928": [0, 0.69444, 0.08094, 0, 0.70834],
                    "931": [0, 0.69444, 0.11983, 0, 0.72222],
                    "933": [0, 0.69444, 0.09031, 0, 0.77778],
                    "934": [0, 0.69444, 0.04603, 0, 0.72222],
                    "936": [0, 0.69444, 0.09031, 0, 0.77778],
                    "937": [0, 0.69444, 0.08293, 0, 0.72222],
                    "8211": [0, 0.44444, 0.08616, 0, 0.5],
                    "8212": [0, 0.44444, 0.08616, 0, 1],
                    "8216": [0, 0.69444, 0.07816, 0, 0.27778],
                    "8217": [0, 0.69444, 0.07816, 0, 0.27778],
                    "8220": [0, 0.69444, 0.14205, 0, 0.5],
                    "8221": [0, 0.69444, 316e-5, 0, 0.5]
                  },
                  "SansSerif-Regular": {
                    "33": [0, 0.69444, 0, 0, 0.31945],
                    "34": [0, 0.69444, 0, 0, 0.5],
                    "35": [0.19444, 0.69444, 0, 0, 0.83334],
                    "36": [0.05556, 0.75, 0, 0, 0.5],
                    "37": [0.05556, 0.75, 0, 0, 0.83334],
                    "38": [0, 0.69444, 0, 0, 0.75834],
                    "39": [0, 0.69444, 0, 0, 0.27778],
                    "40": [0.25, 0.75, 0, 0, 0.38889],
                    "41": [0.25, 0.75, 0, 0, 0.38889],
                    "42": [0, 0.75, 0, 0, 0.5],
                    "43": [0.08333, 0.58333, 0, 0, 0.77778],
                    "44": [0.125, 0.08333, 0, 0, 0.27778],
                    "45": [0, 0.44444, 0, 0, 0.33333],
                    "46": [0, 0.08333, 0, 0, 0.27778],
                    "47": [0.25, 0.75, 0, 0, 0.5],
                    "48": [0, 0.65556, 0, 0, 0.5],
                    "49": [0, 0.65556, 0, 0, 0.5],
                    "50": [0, 0.65556, 0, 0, 0.5],
                    "51": [0, 0.65556, 0, 0, 0.5],
                    "52": [0, 0.65556, 0, 0, 0.5],
                    "53": [0, 0.65556, 0, 0, 0.5],
                    "54": [0, 0.65556, 0, 0, 0.5],
                    "55": [0, 0.65556, 0, 0, 0.5],
                    "56": [0, 0.65556, 0, 0, 0.5],
                    "57": [0, 0.65556, 0, 0, 0.5],
                    "58": [0, 0.44444, 0, 0, 0.27778],
                    "59": [0.125, 0.44444, 0, 0, 0.27778],
                    "61": [-0.13, 0.37, 0, 0, 0.77778],
                    "63": [0, 0.69444, 0, 0, 0.47222],
                    "64": [0, 0.69444, 0, 0, 0.66667],
                    "65": [0, 0.69444, 0, 0, 0.66667],
                    "66": [0, 0.69444, 0, 0, 0.66667],
                    "67": [0, 0.69444, 0, 0, 0.63889],
                    "68": [0, 0.69444, 0, 0, 0.72223],
                    "69": [0, 0.69444, 0, 0, 0.59722],
                    "70": [0, 0.69444, 0, 0, 0.56945],
                    "71": [0, 0.69444, 0, 0, 0.66667],
                    "72": [0, 0.69444, 0, 0, 0.70834],
                    "73": [0, 0.69444, 0, 0, 0.27778],
                    "74": [0, 0.69444, 0, 0, 0.47222],
                    "75": [0, 0.69444, 0, 0, 0.69445],
                    "76": [0, 0.69444, 0, 0, 0.54167],
                    "77": [0, 0.69444, 0, 0, 0.875],
                    "78": [0, 0.69444, 0, 0, 0.70834],
                    "79": [0, 0.69444, 0, 0, 0.73611],
                    "80": [0, 0.69444, 0, 0, 0.63889],
                    "81": [0.125, 0.69444, 0, 0, 0.73611],
                    "82": [0, 0.69444, 0, 0, 0.64584],
                    "83": [0, 0.69444, 0, 0, 0.55556],
                    "84": [0, 0.69444, 0, 0, 0.68056],
                    "85": [0, 0.69444, 0, 0, 0.6875],
                    "86": [0, 0.69444, 0.01389, 0, 0.66667],
                    "87": [0, 0.69444, 0.01389, 0, 0.94445],
                    "88": [0, 0.69444, 0, 0, 0.66667],
                    "89": [0, 0.69444, 0.025, 0, 0.66667],
                    "90": [0, 0.69444, 0, 0, 0.61111],
                    "91": [0.25, 0.75, 0, 0, 0.28889],
                    "93": [0.25, 0.75, 0, 0, 0.28889],
                    "94": [0, 0.69444, 0, 0, 0.5],
                    "95": [0.35, 0.09444, 0.02778, 0, 0.5],
                    "97": [0, 0.44444, 0, 0, 0.48056],
                    "98": [0, 0.69444, 0, 0, 0.51667],
                    "99": [0, 0.44444, 0, 0, 0.44445],
                    "100": [0, 0.69444, 0, 0, 0.51667],
                    "101": [0, 0.44444, 0, 0, 0.44445],
                    "102": [0, 0.69444, 0.06944, 0, 0.30556],
                    "103": [0.19444, 0.44444, 0.01389, 0, 0.5],
                    "104": [0, 0.69444, 0, 0, 0.51667],
                    "105": [0, 0.67937, 0, 0, 0.23889],
                    "106": [0.19444, 0.67937, 0, 0, 0.26667],
                    "107": [0, 0.69444, 0, 0, 0.48889],
                    "108": [0, 0.69444, 0, 0, 0.23889],
                    "109": [0, 0.44444, 0, 0, 0.79445],
                    "110": [0, 0.44444, 0, 0, 0.51667],
                    "111": [0, 0.44444, 0, 0, 0.5],
                    "112": [0.19444, 0.44444, 0, 0, 0.51667],
                    "113": [0.19444, 0.44444, 0, 0, 0.51667],
                    "114": [0, 0.44444, 0.01389, 0, 0.34167],
                    "115": [0, 0.44444, 0, 0, 0.38333],
                    "116": [0, 0.57143, 0, 0, 0.36111],
                    "117": [0, 0.44444, 0, 0, 0.51667],
                    "118": [0, 0.44444, 0.01389, 0, 0.46111],
                    "119": [0, 0.44444, 0.01389, 0, 0.68334],
                    "120": [0, 0.44444, 0, 0, 0.46111],
                    "121": [0.19444, 0.44444, 0.01389, 0, 0.46111],
                    "122": [0, 0.44444, 0, 0, 0.43472],
                    "126": [0.35, 0.32659, 0, 0, 0.5],
                    "168": [0, 0.67937, 0, 0, 0.5],
                    "176": [0, 0.69444, 0, 0, 0.66667],
                    "184": [0.17014, 0, 0, 0, 0.44445],
                    "305": [0, 0.44444, 0, 0, 0.23889],
                    "567": [0.19444, 0.44444, 0, 0, 0.26667],
                    "710": [0, 0.69444, 0, 0, 0.5],
                    "711": [0, 0.63194, 0, 0, 0.5],
                    "713": [0, 0.60889, 0, 0, 0.5],
                    "714": [0, 0.69444, 0, 0, 0.5],
                    "715": [0, 0.69444, 0, 0, 0.5],
                    "728": [0, 0.69444, 0, 0, 0.5],
                    "729": [0, 0.67937, 0, 0, 0.27778],
                    "730": [0, 0.69444, 0, 0, 0.66667],
                    "732": [0, 0.67659, 0, 0, 0.5],
                    "733": [0, 0.69444, 0, 0, 0.5],
                    "915": [0, 0.69444, 0, 0, 0.54167],
                    "916": [0, 0.69444, 0, 0, 0.83334],
                    "920": [0, 0.69444, 0, 0, 0.77778],
                    "923": [0, 0.69444, 0, 0, 0.61111],
                    "926": [0, 0.69444, 0, 0, 0.66667],
                    "928": [0, 0.69444, 0, 0, 0.70834],
                    "931": [0, 0.69444, 0, 0, 0.72222],
                    "933": [0, 0.69444, 0, 0, 0.77778],
                    "934": [0, 0.69444, 0, 0, 0.72222],
                    "936": [0, 0.69444, 0, 0, 0.77778],
                    "937": [0, 0.69444, 0, 0, 0.72222],
                    "8211": [0, 0.44444, 0.02778, 0, 0.5],
                    "8212": [0, 0.44444, 0.02778, 0, 1],
                    "8216": [0, 0.69444, 0, 0, 0.27778],
                    "8217": [0, 0.69444, 0, 0, 0.27778],
                    "8220": [0, 0.69444, 0, 0, 0.5],
                    "8221": [0, 0.69444, 0, 0, 0.5]
                  },
                  "Script-Regular": {
                    "65": [0, 0.7, 0.22925, 0, 0.80253],
                    "66": [0, 0.7, 0.04087, 0, 0.90757],
                    "67": [0, 0.7, 0.1689, 0, 0.66619],
                    "68": [0, 0.7, 0.09371, 0, 0.77443],
                    "69": [0, 0.7, 0.18583, 0, 0.56162],
                    "70": [0, 0.7, 0.13634, 0, 0.89544],
                    "71": [0, 0.7, 0.17322, 0, 0.60961],
                    "72": [0, 0.7, 0.29694, 0, 0.96919],
                    "73": [0, 0.7, 0.19189, 0, 0.80907],
                    "74": [0.27778, 0.7, 0.19189, 0, 1.05159],
                    "75": [0, 0.7, 0.31259, 0, 0.91364],
                    "76": [0, 0.7, 0.19189, 0, 0.87373],
                    "77": [0, 0.7, 0.15981, 0, 1.08031],
                    "78": [0, 0.7, 0.3525, 0, 0.9015],
                    "79": [0, 0.7, 0.08078, 0, 0.73787],
                    "80": [0, 0.7, 0.08078, 0, 1.01262],
                    "81": [0, 0.7, 0.03305, 0, 0.88282],
                    "82": [0, 0.7, 0.06259, 0, 0.85],
                    "83": [0, 0.7, 0.19189, 0, 0.86767],
                    "84": [0, 0.7, 0.29087, 0, 0.74697],
                    "85": [0, 0.7, 0.25815, 0, 0.79996],
                    "86": [0, 0.7, 0.27523, 0, 0.62204],
                    "87": [0, 0.7, 0.27523, 0, 0.80532],
                    "88": [0, 0.7, 0.26006, 0, 0.94445],
                    "89": [0, 0.7, 0.2939, 0, 0.70961],
                    "90": [0, 0.7, 0.24037, 0, 0.8212]
                  },
                  "Size1-Regular": {
                    "40": [0.35001, 0.85, 0, 0, 0.45834],
                    "41": [0.35001, 0.85, 0, 0, 0.45834],
                    "47": [0.35001, 0.85, 0, 0, 0.57778],
                    "91": [0.35001, 0.85, 0, 0, 0.41667],
                    "92": [0.35001, 0.85, 0, 0, 0.57778],
                    "93": [0.35001, 0.85, 0, 0, 0.41667],
                    "123": [0.35001, 0.85, 0, 0, 0.58334],
                    "125": [0.35001, 0.85, 0, 0, 0.58334],
                    "710": [0, 0.72222, 0, 0, 0.55556],
                    "732": [0, 0.72222, 0, 0, 0.55556],
                    "770": [0, 0.72222, 0, 0, 0.55556],
                    "771": [0, 0.72222, 0, 0, 0.55556],
                    "8214": [-99e-5, 0.601, 0, 0, 0.77778],
                    "8593": [1e-5, 0.6, 0, 0, 0.66667],
                    "8595": [1e-5, 0.6, 0, 0, 0.66667],
                    "8657": [1e-5, 0.6, 0, 0, 0.77778],
                    "8659": [1e-5, 0.6, 0, 0, 0.77778],
                    "8719": [0.25001, 0.75, 0, 0, 0.94445],
                    "8720": [0.25001, 0.75, 0, 0, 0.94445],
                    "8721": [0.25001, 0.75, 0, 0, 1.05556],
                    "8730": [0.35001, 0.85, 0, 0, 1],
                    "8739": [-599e-5, 0.606, 0, 0, 0.33333],
                    "8741": [-599e-5, 0.606, 0, 0, 0.55556],
                    "8747": [0.30612, 0.805, 0.19445, 0, 0.47222],
                    "8748": [0.306, 0.805, 0.19445, 0, 0.47222],
                    "8749": [0.306, 0.805, 0.19445, 0, 0.47222],
                    "8750": [0.30612, 0.805, 0.19445, 0, 0.47222],
                    "8896": [0.25001, 0.75, 0, 0, 0.83334],
                    "8897": [0.25001, 0.75, 0, 0, 0.83334],
                    "8898": [0.25001, 0.75, 0, 0, 0.83334],
                    "8899": [0.25001, 0.75, 0, 0, 0.83334],
                    "8968": [0.35001, 0.85, 0, 0, 0.47222],
                    "8969": [0.35001, 0.85, 0, 0, 0.47222],
                    "8970": [0.35001, 0.85, 0, 0, 0.47222],
                    "8971": [0.35001, 0.85, 0, 0, 0.47222],
                    "9168": [-99e-5, 0.601, 0, 0, 0.66667],
                    "10216": [0.35001, 0.85, 0, 0, 0.47222],
                    "10217": [0.35001, 0.85, 0, 0, 0.47222],
                    "10752": [0.25001, 0.75, 0, 0, 1.11111],
                    "10753": [0.25001, 0.75, 0, 0, 1.11111],
                    "10754": [0.25001, 0.75, 0, 0, 1.11111],
                    "10756": [0.25001, 0.75, 0, 0, 0.83334],
                    "10758": [0.25001, 0.75, 0, 0, 0.83334]
                  },
                  "Size2-Regular": {
                    "40": [0.65002, 1.15, 0, 0, 0.59722],
                    "41": [0.65002, 1.15, 0, 0, 0.59722],
                    "47": [0.65002, 1.15, 0, 0, 0.81111],
                    "91": [0.65002, 1.15, 0, 0, 0.47222],
                    "92": [0.65002, 1.15, 0, 0, 0.81111],
                    "93": [0.65002, 1.15, 0, 0, 0.47222],
                    "123": [0.65002, 1.15, 0, 0, 0.66667],
                    "125": [0.65002, 1.15, 0, 0, 0.66667],
                    "710": [0, 0.75, 0, 0, 1],
                    "732": [0, 0.75, 0, 0, 1],
                    "770": [0, 0.75, 0, 0, 1],
                    "771": [0, 0.75, 0, 0, 1],
                    "8719": [0.55001, 1.05, 0, 0, 1.27778],
                    "8720": [0.55001, 1.05, 0, 0, 1.27778],
                    "8721": [0.55001, 1.05, 0, 0, 1.44445],
                    "8730": [0.65002, 1.15, 0, 0, 1],
                    "8747": [0.86225, 1.36, 0.44445, 0, 0.55556],
                    "8748": [0.862, 1.36, 0.44445, 0, 0.55556],
                    "8749": [0.862, 1.36, 0.44445, 0, 0.55556],
                    "8750": [0.86225, 1.36, 0.44445, 0, 0.55556],
                    "8896": [0.55001, 1.05, 0, 0, 1.11111],
                    "8897": [0.55001, 1.05, 0, 0, 1.11111],
                    "8898": [0.55001, 1.05, 0, 0, 1.11111],
                    "8899": [0.55001, 1.05, 0, 0, 1.11111],
                    "8968": [0.65002, 1.15, 0, 0, 0.52778],
                    "8969": [0.65002, 1.15, 0, 0, 0.52778],
                    "8970": [0.65002, 1.15, 0, 0, 0.52778],
                    "8971": [0.65002, 1.15, 0, 0, 0.52778],
                    "10216": [0.65002, 1.15, 0, 0, 0.61111],
                    "10217": [0.65002, 1.15, 0, 0, 0.61111],
                    "10752": [0.55001, 1.05, 0, 0, 1.51112],
                    "10753": [0.55001, 1.05, 0, 0, 1.51112],
                    "10754": [0.55001, 1.05, 0, 0, 1.51112],
                    "10756": [0.55001, 1.05, 0, 0, 1.11111],
                    "10758": [0.55001, 1.05, 0, 0, 1.11111]
                  },
                  "Size3-Regular": {
                    "40": [0.95003, 1.45, 0, 0, 0.73611],
                    "41": [0.95003, 1.45, 0, 0, 0.73611],
                    "47": [0.95003, 1.45, 0, 0, 1.04445],
                    "91": [0.95003, 1.45, 0, 0, 0.52778],
                    "92": [0.95003, 1.45, 0, 0, 1.04445],
                    "93": [0.95003, 1.45, 0, 0, 0.52778],
                    "123": [0.95003, 1.45, 0, 0, 0.75],
                    "125": [0.95003, 1.45, 0, 0, 0.75],
                    "710": [0, 0.75, 0, 0, 1.44445],
                    "732": [0, 0.75, 0, 0, 1.44445],
                    "770": [0, 0.75, 0, 0, 1.44445],
                    "771": [0, 0.75, 0, 0, 1.44445],
                    "8730": [0.95003, 1.45, 0, 0, 1],
                    "8968": [0.95003, 1.45, 0, 0, 0.58334],
                    "8969": [0.95003, 1.45, 0, 0, 0.58334],
                    "8970": [0.95003, 1.45, 0, 0, 0.58334],
                    "8971": [0.95003, 1.45, 0, 0, 0.58334],
                    "10216": [0.95003, 1.45, 0, 0, 0.75],
                    "10217": [0.95003, 1.45, 0, 0, 0.75]
                  },
                  "Size4-Regular": {
                    "40": [1.25003, 1.75, 0, 0, 0.79167],
                    "41": [1.25003, 1.75, 0, 0, 0.79167],
                    "47": [1.25003, 1.75, 0, 0, 1.27778],
                    "91": [1.25003, 1.75, 0, 0, 0.58334],
                    "92": [1.25003, 1.75, 0, 0, 1.27778],
                    "93": [1.25003, 1.75, 0, 0, 0.58334],
                    "123": [1.25003, 1.75, 0, 0, 0.80556],
                    "125": [1.25003, 1.75, 0, 0, 0.80556],
                    "710": [0, 0.825, 0, 0, 1.8889],
                    "732": [0, 0.825, 0, 0, 1.8889],
                    "770": [0, 0.825, 0, 0, 1.8889],
                    "771": [0, 0.825, 0, 0, 1.8889],
                    "8730": [1.25003, 1.75, 0, 0, 1],
                    "8968": [1.25003, 1.75, 0, 0, 0.63889],
                    "8969": [1.25003, 1.75, 0, 0, 0.63889],
                    "8970": [1.25003, 1.75, 0, 0, 0.63889],
                    "8971": [1.25003, 1.75, 0, 0, 0.63889],
                    "9115": [0.64502, 1.155, 0, 0, 0.875],
                    "9116": [1e-5, 0.6, 0, 0, 0.875],
                    "9117": [0.64502, 1.155, 0, 0, 0.875],
                    "9118": [0.64502, 1.155, 0, 0, 0.875],
                    "9119": [1e-5, 0.6, 0, 0, 0.875],
                    "9120": [0.64502, 1.155, 0, 0, 0.875],
                    "9121": [0.64502, 1.155, 0, 0, 0.66667],
                    "9122": [-99e-5, 0.601, 0, 0, 0.66667],
                    "9123": [0.64502, 1.155, 0, 0, 0.66667],
                    "9124": [0.64502, 1.155, 0, 0, 0.66667],
                    "9125": [-99e-5, 0.601, 0, 0, 0.66667],
                    "9126": [0.64502, 1.155, 0, 0, 0.66667],
                    "9127": [1e-5, 0.9, 0, 0, 0.88889],
                    "9128": [0.65002, 1.15, 0, 0, 0.88889],
                    "9129": [0.90001, 0, 0, 0, 0.88889],
                    "9130": [0, 0.3, 0, 0, 0.88889],
                    "9131": [1e-5, 0.9, 0, 0, 0.88889],
                    "9132": [0.65002, 1.15, 0, 0, 0.88889],
                    "9133": [0.90001, 0, 0, 0, 0.88889],
                    "9143": [0.88502, 0.915, 0, 0, 1.05556],
                    "10216": [1.25003, 1.75, 0, 0, 0.80556],
                    "10217": [1.25003, 1.75, 0, 0, 0.80556],
                    "57344": [-499e-5, 0.605, 0, 0, 1.05556],
                    "57345": [-499e-5, 0.605, 0, 0, 1.05556],
                    "57680": [0, 0.12, 0, 0, 0.45],
                    "57681": [0, 0.12, 0, 0, 0.45],
                    "57682": [0, 0.12, 0, 0, 0.45],
                    "57683": [0, 0.12, 0, 0, 0.45]
                  },
                  "Typewriter-Regular": {
                    "32": [0, 0, 0, 0, 0.525],
                    "33": [0, 0.61111, 0, 0, 0.525],
                    "34": [0, 0.61111, 0, 0, 0.525],
                    "35": [0, 0.61111, 0, 0, 0.525],
                    "36": [0.08333, 0.69444, 0, 0, 0.525],
                    "37": [0.08333, 0.69444, 0, 0, 0.525],
                    "38": [0, 0.61111, 0, 0, 0.525],
                    "39": [0, 0.61111, 0, 0, 0.525],
                    "40": [0.08333, 0.69444, 0, 0, 0.525],
                    "41": [0.08333, 0.69444, 0, 0, 0.525],
                    "42": [0, 0.52083, 0, 0, 0.525],
                    "43": [-0.08056, 0.53055, 0, 0, 0.525],
                    "44": [0.13889, 0.125, 0, 0, 0.525],
                    "45": [-0.08056, 0.53055, 0, 0, 0.525],
                    "46": [0, 0.125, 0, 0, 0.525],
                    "47": [0.08333, 0.69444, 0, 0, 0.525],
                    "48": [0, 0.61111, 0, 0, 0.525],
                    "49": [0, 0.61111, 0, 0, 0.525],
                    "50": [0, 0.61111, 0, 0, 0.525],
                    "51": [0, 0.61111, 0, 0, 0.525],
                    "52": [0, 0.61111, 0, 0, 0.525],
                    "53": [0, 0.61111, 0, 0, 0.525],
                    "54": [0, 0.61111, 0, 0, 0.525],
                    "55": [0, 0.61111, 0, 0, 0.525],
                    "56": [0, 0.61111, 0, 0, 0.525],
                    "57": [0, 0.61111, 0, 0, 0.525],
                    "58": [0, 0.43056, 0, 0, 0.525],
                    "59": [0.13889, 0.43056, 0, 0, 0.525],
                    "60": [-0.05556, 0.55556, 0, 0, 0.525],
                    "61": [-0.19549, 0.41562, 0, 0, 0.525],
                    "62": [-0.05556, 0.55556, 0, 0, 0.525],
                    "63": [0, 0.61111, 0, 0, 0.525],
                    "64": [0, 0.61111, 0, 0, 0.525],
                    "65": [0, 0.61111, 0, 0, 0.525],
                    "66": [0, 0.61111, 0, 0, 0.525],
                    "67": [0, 0.61111, 0, 0, 0.525],
                    "68": [0, 0.61111, 0, 0, 0.525],
                    "69": [0, 0.61111, 0, 0, 0.525],
                    "70": [0, 0.61111, 0, 0, 0.525],
                    "71": [0, 0.61111, 0, 0, 0.525],
                    "72": [0, 0.61111, 0, 0, 0.525],
                    "73": [0, 0.61111, 0, 0, 0.525],
                    "74": [0, 0.61111, 0, 0, 0.525],
                    "75": [0, 0.61111, 0, 0, 0.525],
                    "76": [0, 0.61111, 0, 0, 0.525],
                    "77": [0, 0.61111, 0, 0, 0.525],
                    "78": [0, 0.61111, 0, 0, 0.525],
                    "79": [0, 0.61111, 0, 0, 0.525],
                    "80": [0, 0.61111, 0, 0, 0.525],
                    "81": [0.13889, 0.61111, 0, 0, 0.525],
                    "82": [0, 0.61111, 0, 0, 0.525],
                    "83": [0, 0.61111, 0, 0, 0.525],
                    "84": [0, 0.61111, 0, 0, 0.525],
                    "85": [0, 0.61111, 0, 0, 0.525],
                    "86": [0, 0.61111, 0, 0, 0.525],
                    "87": [0, 0.61111, 0, 0, 0.525],
                    "88": [0, 0.61111, 0, 0, 0.525],
                    "89": [0, 0.61111, 0, 0, 0.525],
                    "90": [0, 0.61111, 0, 0, 0.525],
                    "91": [0.08333, 0.69444, 0, 0, 0.525],
                    "92": [0.08333, 0.69444, 0, 0, 0.525],
                    "93": [0.08333, 0.69444, 0, 0, 0.525],
                    "94": [0, 0.61111, 0, 0, 0.525],
                    "95": [0.09514, 0, 0, 0, 0.525],
                    "96": [0, 0.61111, 0, 0, 0.525],
                    "97": [0, 0.43056, 0, 0, 0.525],
                    "98": [0, 0.61111, 0, 0, 0.525],
                    "99": [0, 0.43056, 0, 0, 0.525],
                    "100": [0, 0.61111, 0, 0, 0.525],
                    "101": [0, 0.43056, 0, 0, 0.525],
                    "102": [0, 0.61111, 0, 0, 0.525],
                    "103": [0.22222, 0.43056, 0, 0, 0.525],
                    "104": [0, 0.61111, 0, 0, 0.525],
                    "105": [0, 0.61111, 0, 0, 0.525],
                    "106": [0.22222, 0.61111, 0, 0, 0.525],
                    "107": [0, 0.61111, 0, 0, 0.525],
                    "108": [0, 0.61111, 0, 0, 0.525],
                    "109": [0, 0.43056, 0, 0, 0.525],
                    "110": [0, 0.43056, 0, 0, 0.525],
                    "111": [0, 0.43056, 0, 0, 0.525],
                    "112": [0.22222, 0.43056, 0, 0, 0.525],
                    "113": [0.22222, 0.43056, 0, 0, 0.525],
                    "114": [0, 0.43056, 0, 0, 0.525],
                    "115": [0, 0.43056, 0, 0, 0.525],
                    "116": [0, 0.55358, 0, 0, 0.525],
                    "117": [0, 0.43056, 0, 0, 0.525],
                    "118": [0, 0.43056, 0, 0, 0.525],
                    "119": [0, 0.43056, 0, 0, 0.525],
                    "120": [0, 0.43056, 0, 0, 0.525],
                    "121": [0.22222, 0.43056, 0, 0, 0.525],
                    "122": [0, 0.43056, 0, 0, 0.525],
                    "123": [0.08333, 0.69444, 0, 0, 0.525],
                    "124": [0.08333, 0.69444, 0, 0, 0.525],
                    "125": [0.08333, 0.69444, 0, 0, 0.525],
                    "126": [0, 0.61111, 0, 0, 0.525],
                    "127": [0, 0.61111, 0, 0, 0.525],
                    "160": [0, 0, 0, 0, 0.525],
                    "176": [0, 0.61111, 0, 0, 0.525],
                    "184": [0.19445, 0, 0, 0, 0.525],
                    "305": [0, 0.43056, 0, 0, 0.525],
                    "567": [0.22222, 0.43056, 0, 0, 0.525],
                    "711": [0, 0.56597, 0, 0, 0.525],
                    "713": [0, 0.56555, 0, 0, 0.525],
                    "714": [0, 0.61111, 0, 0, 0.525],
                    "715": [0, 0.61111, 0, 0, 0.525],
                    "728": [0, 0.61111, 0, 0, 0.525],
                    "730": [0, 0.61111, 0, 0, 0.525],
                    "770": [0, 0.61111, 0, 0, 0.525],
                    "771": [0, 0.61111, 0, 0, 0.525],
                    "776": [0, 0.61111, 0, 0, 0.525],
                    "915": [0, 0.61111, 0, 0, 0.525],
                    "916": [0, 0.61111, 0, 0, 0.525],
                    "920": [0, 0.61111, 0, 0, 0.525],
                    "923": [0, 0.61111, 0, 0, 0.525],
                    "926": [0, 0.61111, 0, 0, 0.525],
                    "928": [0, 0.61111, 0, 0, 0.525],
                    "931": [0, 0.61111, 0, 0, 0.525],
                    "933": [0, 0.61111, 0, 0, 0.525],
                    "934": [0, 0.61111, 0, 0, 0.525],
                    "936": [0, 0.61111, 0, 0, 0.525],
                    "937": [0, 0.61111, 0, 0, 0.525],
                    "8216": [0, 0.61111, 0, 0, 0.525],
                    "8217": [0, 0.61111, 0, 0, 0.525],
                    "8242": [0, 0.61111, 0, 0, 0.525],
                    "9251": [0.11111, 0.21944, 0, 0, 0.525]
                  }
                };
                var sigmasAndXis = {
                  slant: [0.25, 0.25, 0.25],
                  // sigma1
                  space: [0, 0, 0],
                  // sigma2
                  stretch: [0, 0, 0],
                  // sigma3
                  shrink: [0, 0, 0],
                  // sigma4
                  xHeight: [0.431, 0.431, 0.431],
                  // sigma5
                  quad: [1, 1.171, 1.472],
                  // sigma6
                  extraSpace: [0, 0, 0],
                  // sigma7
                  num1: [0.677, 0.732, 0.925],
                  // sigma8
                  num2: [0.394, 0.384, 0.387],
                  // sigma9
                  num3: [0.444, 0.471, 0.504],
                  // sigma10
                  denom1: [0.686, 0.752, 1.025],
                  // sigma11
                  denom2: [0.345, 0.344, 0.532],
                  // sigma12
                  sup1: [0.413, 0.503, 0.504],
                  // sigma13
                  sup2: [0.363, 0.431, 0.404],
                  // sigma14
                  sup3: [0.289, 0.286, 0.294],
                  // sigma15
                  sub1: [0.15, 0.143, 0.2],
                  // sigma16
                  sub2: [0.247, 0.286, 0.4],
                  // sigma17
                  supDrop: [0.386, 0.353, 0.494],
                  // sigma18
                  subDrop: [0.05, 0.071, 0.1],
                  // sigma19
                  delim1: [2.39, 1.7, 1.98],
                  // sigma20
                  delim2: [1.01, 1.157, 1.42],
                  // sigma21
                  axisHeight: [0.25, 0.25, 0.25],
                  // sigma22
                  // These font metrics are extracted from TeX by using tftopl on cmex10.tfm;
                  // they correspond to the font parameters of the extension fonts (family 3).
                  // See the TeXbook, page 441. In AMSTeX, the extension fonts scale; to
                  // match cmex7, we'd use cmex7.tfm values for script and scriptscript
                  // values.
                  defaultRuleThickness: [0.04, 0.049, 0.049],
                  // xi8; cmex7: 0.049
                  bigOpSpacing1: [0.111, 0.111, 0.111],
                  // xi9
                  bigOpSpacing2: [0.166, 0.166, 0.166],
                  // xi10
                  bigOpSpacing3: [0.2, 0.2, 0.2],
                  // xi11
                  bigOpSpacing4: [0.6, 0.611, 0.611],
                  // xi12; cmex7: 0.611
                  bigOpSpacing5: [0.1, 0.143, 0.143],
                  // xi13; cmex7: 0.143
                  // The \sqrt rule width is taken from the height of the surd character.
                  // Since we use the same font at all sizes, this thickness doesn't scale.
                  sqrtRuleThickness: [0.04, 0.04, 0.04],
                  // This value determines how large a pt is, for metrics which are defined
                  // in terms of pts.
                  // This value is also used in katex.less; if you change it make sure the
                  // values match.
                  ptPerEm: [10, 10, 10],
                  // The space between adjacent `|` columns in an array definition. From
                  // `\showthe\doublerulesep` in LaTeX. Equals 2.0 / ptPerEm.
                  doubleRuleSep: [0.2, 0.2, 0.2]
                };
                var extraCharacterMap = {
                  // Latin-1
                  "Å": "A",
                  "Ç": "C",
                  "Ð": "D",
                  "Þ": "o",
                  "å": "a",
                  "ç": "c",
                  "ð": "d",
                  "þ": "o",
                  // Cyrillic
                  "А": "A",
                  "Б": "B",
                  "В": "B",
                  "Г": "F",
                  "Д": "A",
                  "Е": "E",
                  "Ж": "K",
                  "З": "3",
                  "И": "N",
                  "Й": "N",
                  "К": "K",
                  "Л": "N",
                  "М": "M",
                  "Н": "H",
                  "О": "O",
                  "П": "N",
                  "Р": "P",
                  "С": "C",
                  "Т": "T",
                  "У": "y",
                  "Ф": "O",
                  "Х": "X",
                  "Ц": "U",
                  "Ч": "h",
                  "Ш": "W",
                  "Щ": "W",
                  "Ъ": "B",
                  "Ы": "X",
                  "Ь": "B",
                  "Э": "3",
                  "Ю": "X",
                  "Я": "R",
                  "а": "a",
                  "б": "b",
                  "в": "a",
                  "г": "r",
                  "д": "y",
                  "е": "e",
                  "ж": "m",
                  "з": "e",
                  "и": "n",
                  "й": "n",
                  "к": "n",
                  "л": "n",
                  "м": "m",
                  "н": "n",
                  "о": "o",
                  "п": "n",
                  "р": "p",
                  "с": "c",
                  "т": "o",
                  "у": "y",
                  "ф": "b",
                  "х": "x",
                  "ц": "n",
                  "ч": "n",
                  "ш": "w",
                  "щ": "w",
                  "ъ": "a",
                  "ы": "m",
                  "ь": "a",
                  "э": "e",
                  "ю": "m",
                  "я": "r"
                };
                function setFontMetrics(fontName, metrics) {
                  fontMetricsData[fontName] = metrics;
                }
                function getCharacterMetrics(character, font, mode) {
                  if (!fontMetricsData[font]) {
                    throw new Error("Font metrics not found for font: " + font + ".");
                  }
                  var ch = character.charCodeAt(0);
                  if (character[0] in extraCharacterMap) {
                    ch = extraCharacterMap[character[0]].charCodeAt(0);
                  }
                  var metrics = fontMetricsData[font][ch];
                  if (!metrics && mode === "text") {
                    if (supportedCodepoint(ch)) {
                      metrics = fontMetricsData[font][77];
                    }
                  }
                  if (metrics) {
                    return {
                      depth: metrics[0],
                      height: metrics[1],
                      italic: metrics[2],
                      skew: metrics[3],
                      width: metrics[4]
                    };
                  }
                }
                var fontMetricsBySizeIndex = {};
                function getGlobalMetrics(size) {
                  var sizeIndex;
                  if (size >= 5) {
                    sizeIndex = 0;
                  } else if (size >= 3) {
                    sizeIndex = 1;
                  } else {
                    sizeIndex = 2;
                  }
                  if (!fontMetricsBySizeIndex[sizeIndex]) {
                    var metrics = fontMetricsBySizeIndex[sizeIndex] = {
                      cssEmPerMu: sigmasAndXis.quad[sizeIndex] / 18
                    };
                    for (var key in sigmasAndXis) {
                      if (sigmasAndXis.hasOwnProperty(key)) {
                        metrics[key] = sigmasAndXis[key][sizeIndex];
                      }
                    }
                  }
                  return fontMetricsBySizeIndex[sizeIndex];
                }
                var ATOMS = {
                  "bin": 1,
                  "close": 1,
                  "inner": 1,
                  "open": 1,
                  "punct": 1,
                  "rel": 1
                };
                var NON_ATOMS = {
                  "accent-token": 1,
                  "mathord": 1,
                  "op-token": 1,
                  "spacing": 1,
                  "textord": 1
                };
                var symbols2 = {
                  "math": {},
                  "text": {}
                };
                var src_symbols = symbols2;
                function defineSymbol(mode, font, group, replace, name, acceptUnicodeChar) {
                  symbols2[mode][name] = {
                    font,
                    group,
                    replace
                  };
                  if (acceptUnicodeChar && replace) {
                    symbols2[mode][replace] = symbols2[mode][name];
                  }
                }
                var symbols_math = "math";
                var symbols_text = "text";
                var main = "main";
                var ams = "ams";
                var symbols_accent = "accent-token";
                var bin = "bin";
                var symbols_close = "close";
                var symbols_inner = "inner";
                var mathord = "mathord";
                var op = "op-token";
                var symbols_open = "open";
                var punct = "punct";
                var rel = "rel";
                var spacing = "spacing";
                var symbols_textord = "textord";
                defineSymbol(symbols_math, main, rel, "≡", "\\equiv", true);
                defineSymbol(symbols_math, main, rel, "≺", "\\prec", true);
                defineSymbol(symbols_math, main, rel, "≻", "\\succ", true);
                defineSymbol(symbols_math, main, rel, "∼", "\\sim", true);
                defineSymbol(symbols_math, main, rel, "⊥", "\\perp");
                defineSymbol(symbols_math, main, rel, "⪯", "\\preceq", true);
                defineSymbol(symbols_math, main, rel, "⪰", "\\succeq", true);
                defineSymbol(symbols_math, main, rel, "≃", "\\simeq", true);
                defineSymbol(symbols_math, main, rel, "∣", "\\mid", true);
                defineSymbol(symbols_math, main, rel, "≪", "\\ll", true);
                defineSymbol(symbols_math, main, rel, "≫", "\\gg", true);
                defineSymbol(symbols_math, main, rel, "≍", "\\asymp", true);
                defineSymbol(symbols_math, main, rel, "∥", "\\parallel");
                defineSymbol(symbols_math, main, rel, "⋈", "\\bowtie", true);
                defineSymbol(symbols_math, main, rel, "⌣", "\\smile", true);
                defineSymbol(symbols_math, main, rel, "⊑", "\\sqsubseteq", true);
                defineSymbol(symbols_math, main, rel, "⊒", "\\sqsupseteq", true);
                defineSymbol(symbols_math, main, rel, "≐", "\\doteq", true);
                defineSymbol(symbols_math, main, rel, "⌢", "\\frown", true);
                defineSymbol(symbols_math, main, rel, "∋", "\\ni", true);
                defineSymbol(symbols_math, main, rel, "∝", "\\propto", true);
                defineSymbol(symbols_math, main, rel, "⊢", "\\vdash", true);
                defineSymbol(symbols_math, main, rel, "⊣", "\\dashv", true);
                defineSymbol(symbols_math, main, rel, "∋", "\\owns");
                defineSymbol(symbols_math, main, punct, ".", "\\ldotp");
                defineSymbol(symbols_math, main, punct, "⋅", "\\cdotp");
                defineSymbol(symbols_math, main, symbols_textord, "#", "\\#");
                defineSymbol(symbols_text, main, symbols_textord, "#", "\\#");
                defineSymbol(symbols_math, main, symbols_textord, "&", "\\&");
                defineSymbol(symbols_text, main, symbols_textord, "&", "\\&");
                defineSymbol(symbols_math, main, symbols_textord, "ℵ", "\\aleph", true);
                defineSymbol(symbols_math, main, symbols_textord, "∀", "\\forall", true);
                defineSymbol(symbols_math, main, symbols_textord, "ℏ", "\\hbar", true);
                defineSymbol(symbols_math, main, symbols_textord, "∃", "\\exists", true);
                defineSymbol(symbols_math, main, symbols_textord, "∇", "\\nabla", true);
                defineSymbol(symbols_math, main, symbols_textord, "♭", "\\flat", true);
                defineSymbol(symbols_math, main, symbols_textord, "ℓ", "\\ell", true);
                defineSymbol(symbols_math, main, symbols_textord, "♮", "\\natural", true);
                defineSymbol(symbols_math, main, symbols_textord, "♣", "\\clubsuit", true);
                defineSymbol(symbols_math, main, symbols_textord, "℘", "\\wp", true);
                defineSymbol(symbols_math, main, symbols_textord, "♯", "\\sharp", true);
                defineSymbol(symbols_math, main, symbols_textord, "♢", "\\diamondsuit", true);
                defineSymbol(symbols_math, main, symbols_textord, "ℜ", "\\Re", true);
                defineSymbol(symbols_math, main, symbols_textord, "♡", "\\heartsuit", true);
                defineSymbol(symbols_math, main, symbols_textord, "ℑ", "\\Im", true);
                defineSymbol(symbols_math, main, symbols_textord, "♠", "\\spadesuit", true);
                defineSymbol(symbols_text, main, symbols_textord, "§", "\\S", true);
                defineSymbol(symbols_text, main, symbols_textord, "¶", "\\P", true);
                defineSymbol(symbols_math, main, symbols_textord, "†", "\\dag");
                defineSymbol(symbols_text, main, symbols_textord, "†", "\\dag");
                defineSymbol(symbols_text, main, symbols_textord, "†", "\\textdagger");
                defineSymbol(symbols_math, main, symbols_textord, "‡", "\\ddag");
                defineSymbol(symbols_text, main, symbols_textord, "‡", "\\ddag");
                defineSymbol(symbols_text, main, symbols_textord, "‡", "\\textdaggerdbl");
                defineSymbol(symbols_math, main, symbols_close, "⎱", "\\rmoustache", true);
                defineSymbol(symbols_math, main, symbols_open, "⎰", "\\lmoustache", true);
                defineSymbol(symbols_math, main, symbols_close, "⟯", "\\rgroup", true);
                defineSymbol(symbols_math, main, symbols_open, "⟮", "\\lgroup", true);
                defineSymbol(symbols_math, main, bin, "∓", "\\mp", true);
                defineSymbol(symbols_math, main, bin, "⊖", "\\ominus", true);
                defineSymbol(symbols_math, main, bin, "⊎", "\\uplus", true);
                defineSymbol(symbols_math, main, bin, "⊓", "\\sqcap", true);
                defineSymbol(symbols_math, main, bin, "∗", "\\ast");
                defineSymbol(symbols_math, main, bin, "⊔", "\\sqcup", true);
                defineSymbol(symbols_math, main, bin, "◯", "\\bigcirc");
                defineSymbol(symbols_math, main, bin, "∙", "\\bullet");
                defineSymbol(symbols_math, main, bin, "‡", "\\ddagger");
                defineSymbol(symbols_math, main, bin, "≀", "\\wr", true);
                defineSymbol(symbols_math, main, bin, "⨿", "\\amalg");
                defineSymbol(symbols_math, main, bin, "&", "\\And");
                defineSymbol(symbols_math, main, rel, "⟵", "\\longleftarrow", true);
                defineSymbol(symbols_math, main, rel, "⇐", "\\Leftarrow", true);
                defineSymbol(symbols_math, main, rel, "⟸", "\\Longleftarrow", true);
                defineSymbol(symbols_math, main, rel, "⟶", "\\longrightarrow", true);
                defineSymbol(symbols_math, main, rel, "⇒", "\\Rightarrow", true);
                defineSymbol(symbols_math, main, rel, "⟹", "\\Longrightarrow", true);
                defineSymbol(symbols_math, main, rel, "↔", "\\leftrightarrow", true);
                defineSymbol(symbols_math, main, rel, "⟷", "\\longleftrightarrow", true);
                defineSymbol(symbols_math, main, rel, "⇔", "\\Leftrightarrow", true);
                defineSymbol(symbols_math, main, rel, "⟺", "\\Longleftrightarrow", true);
                defineSymbol(symbols_math, main, rel, "↦", "\\mapsto", true);
                defineSymbol(symbols_math, main, rel, "⟼", "\\longmapsto", true);
                defineSymbol(symbols_math, main, rel, "↗", "\\nearrow", true);
                defineSymbol(symbols_math, main, rel, "↩", "\\hookleftarrow", true);
                defineSymbol(symbols_math, main, rel, "↪", "\\hookrightarrow", true);
                defineSymbol(symbols_math, main, rel, "↘", "\\searrow", true);
                defineSymbol(symbols_math, main, rel, "↼", "\\leftharpoonup", true);
                defineSymbol(symbols_math, main, rel, "⇀", "\\rightharpoonup", true);
                defineSymbol(symbols_math, main, rel, "↙", "\\swarrow", true);
                defineSymbol(symbols_math, main, rel, "↽", "\\leftharpoondown", true);
                defineSymbol(symbols_math, main, rel, "⇁", "\\rightharpoondown", true);
                defineSymbol(symbols_math, main, rel, "↖", "\\nwarrow", true);
                defineSymbol(symbols_math, main, rel, "⇌", "\\rightleftharpoons", true);
                defineSymbol(symbols_math, ams, rel, "≮", "\\nless", true);
                defineSymbol(symbols_math, ams, rel, "", "\\nleqslant");
                defineSymbol(symbols_math, ams, rel, "", "\\nleqq");
                defineSymbol(symbols_math, ams, rel, "⪇", "\\lneq", true);
                defineSymbol(symbols_math, ams, rel, "≨", "\\lneqq", true);
                defineSymbol(symbols_math, ams, rel, "", "\\lvertneqq");
                defineSymbol(symbols_math, ams, rel, "⋦", "\\lnsim", true);
                defineSymbol(symbols_math, ams, rel, "⪉", "\\lnapprox", true);
                defineSymbol(symbols_math, ams, rel, "⊀", "\\nprec", true);
                defineSymbol(symbols_math, ams, rel, "⋠", "\\npreceq", true);
                defineSymbol(symbols_math, ams, rel, "⋨", "\\precnsim", true);
                defineSymbol(symbols_math, ams, rel, "⪹", "\\precnapprox", true);
                defineSymbol(symbols_math, ams, rel, "≁", "\\nsim", true);
                defineSymbol(symbols_math, ams, rel, "", "\\nshortmid");
                defineSymbol(symbols_math, ams, rel, "∤", "\\nmid", true);
                defineSymbol(symbols_math, ams, rel, "⊬", "\\nvdash", true);
                defineSymbol(symbols_math, ams, rel, "⊭", "\\nvDash", true);
                defineSymbol(symbols_math, ams, rel, "⋪", "\\ntriangleleft");
                defineSymbol(symbols_math, ams, rel, "⋬", "\\ntrianglelefteq", true);
                defineSymbol(symbols_math, ams, rel, "⊊", "\\subsetneq", true);
                defineSymbol(symbols_math, ams, rel, "", "\\varsubsetneq");
                defineSymbol(symbols_math, ams, rel, "⫋", "\\subsetneqq", true);
                defineSymbol(symbols_math, ams, rel, "", "\\varsubsetneqq");
                defineSymbol(symbols_math, ams, rel, "≯", "\\ngtr", true);
                defineSymbol(symbols_math, ams, rel, "", "\\ngeqslant");
                defineSymbol(symbols_math, ams, rel, "", "\\ngeqq");
                defineSymbol(symbols_math, ams, rel, "⪈", "\\gneq", true);
                defineSymbol(symbols_math, ams, rel, "≩", "\\gneqq", true);
                defineSymbol(symbols_math, ams, rel, "", "\\gvertneqq");
                defineSymbol(symbols_math, ams, rel, "⋧", "\\gnsim", true);
                defineSymbol(symbols_math, ams, rel, "⪊", "\\gnapprox", true);
                defineSymbol(symbols_math, ams, rel, "⊁", "\\nsucc", true);
                defineSymbol(symbols_math, ams, rel, "⋡", "\\nsucceq", true);
                defineSymbol(symbols_math, ams, rel, "⋩", "\\succnsim", true);
                defineSymbol(symbols_math, ams, rel, "⪺", "\\succnapprox", true);
                defineSymbol(symbols_math, ams, rel, "≆", "\\ncong", true);
                defineSymbol(symbols_math, ams, rel, "", "\\nshortparallel");
                defineSymbol(symbols_math, ams, rel, "∦", "\\nparallel", true);
                defineSymbol(symbols_math, ams, rel, "⊯", "\\nVDash", true);
                defineSymbol(symbols_math, ams, rel, "⋫", "\\ntriangleright");
                defineSymbol(symbols_math, ams, rel, "⋭", "\\ntrianglerighteq", true);
                defineSymbol(symbols_math, ams, rel, "", "\\nsupseteqq");
                defineSymbol(symbols_math, ams, rel, "⊋", "\\supsetneq", true);
                defineSymbol(symbols_math, ams, rel, "", "\\varsupsetneq");
                defineSymbol(symbols_math, ams, rel, "⫌", "\\supsetneqq", true);
                defineSymbol(symbols_math, ams, rel, "", "\\varsupsetneqq");
                defineSymbol(symbols_math, ams, rel, "⊮", "\\nVdash", true);
                defineSymbol(symbols_math, ams, rel, "⪵", "\\precneqq", true);
                defineSymbol(symbols_math, ams, rel, "⪶", "\\succneqq", true);
                defineSymbol(symbols_math, ams, rel, "", "\\nsubseteqq");
                defineSymbol(symbols_math, ams, bin, "⊴", "\\unlhd");
                defineSymbol(symbols_math, ams, bin, "⊵", "\\unrhd");
                defineSymbol(symbols_math, ams, rel, "↚", "\\nleftarrow", true);
                defineSymbol(symbols_math, ams, rel, "↛", "\\nrightarrow", true);
                defineSymbol(symbols_math, ams, rel, "⇍", "\\nLeftarrow", true);
                defineSymbol(symbols_math, ams, rel, "⇏", "\\nRightarrow", true);
                defineSymbol(symbols_math, ams, rel, "↮", "\\nleftrightarrow", true);
                defineSymbol(symbols_math, ams, rel, "⇎", "\\nLeftrightarrow", true);
                defineSymbol(symbols_math, ams, rel, "△", "\\vartriangle");
                defineSymbol(symbols_math, ams, symbols_textord, "ℏ", "\\hslash");
                defineSymbol(symbols_math, ams, symbols_textord, "▽", "\\triangledown");
                defineSymbol(symbols_math, ams, symbols_textord, "◊", "\\lozenge");
                defineSymbol(symbols_math, ams, symbols_textord, "Ⓢ", "\\circledS");
                defineSymbol(symbols_math, ams, symbols_textord, "®", "\\circledR");
                defineSymbol(symbols_text, ams, symbols_textord, "®", "\\circledR");
                defineSymbol(symbols_math, ams, symbols_textord, "∡", "\\measuredangle", true);
                defineSymbol(symbols_math, ams, symbols_textord, "∄", "\\nexists");
                defineSymbol(symbols_math, ams, symbols_textord, "℧", "\\mho");
                defineSymbol(symbols_math, ams, symbols_textord, "Ⅎ", "\\Finv", true);
                defineSymbol(symbols_math, ams, symbols_textord, "⅁", "\\Game", true);
                defineSymbol(symbols_math, ams, symbols_textord, "k", "\\Bbbk");
                defineSymbol(symbols_math, ams, symbols_textord, "‵", "\\backprime");
                defineSymbol(symbols_math, ams, symbols_textord, "▲", "\\blacktriangle");
                defineSymbol(symbols_math, ams, symbols_textord, "▼", "\\blacktriangledown");
                defineSymbol(symbols_math, ams, symbols_textord, "■", "\\blacksquare");
                defineSymbol(symbols_math, ams, symbols_textord, "⧫", "\\blacklozenge");
                defineSymbol(symbols_math, ams, symbols_textord, "★", "\\bigstar");
                defineSymbol(symbols_math, ams, symbols_textord, "∢", "\\sphericalangle", true);
                defineSymbol(symbols_math, ams, symbols_textord, "∁", "\\complement", true);
                defineSymbol(symbols_math, ams, symbols_textord, "ð", "\\eth", true);
                defineSymbol(symbols_math, ams, symbols_textord, "╱", "\\diagup");
                defineSymbol(symbols_math, ams, symbols_textord, "╲", "\\diagdown");
                defineSymbol(symbols_math, ams, symbols_textord, "□", "\\square");
                defineSymbol(symbols_math, ams, symbols_textord, "□", "\\Box");
                defineSymbol(symbols_math, ams, symbols_textord, "◊", "\\Diamond");
                defineSymbol(symbols_math, ams, symbols_textord, "¥", "\\yen", true);
                defineSymbol(symbols_text, ams, symbols_textord, "¥", "\\yen", true);
                defineSymbol(symbols_math, ams, symbols_textord, "✓", "\\checkmark", true);
                defineSymbol(symbols_text, ams, symbols_textord, "✓", "\\checkmark");
                defineSymbol(symbols_math, ams, symbols_textord, "ℶ", "\\beth", true);
                defineSymbol(symbols_math, ams, symbols_textord, "ℸ", "\\daleth", true);
                defineSymbol(symbols_math, ams, symbols_textord, "ℷ", "\\gimel", true);
                defineSymbol(symbols_math, ams, symbols_textord, "ϝ", "\\digamma");
                defineSymbol(symbols_math, ams, symbols_textord, "ϰ", "\\varkappa");
                defineSymbol(symbols_math, ams, symbols_open, "┌", "\\ulcorner", true);
                defineSymbol(symbols_math, ams, symbols_close, "┐", "\\urcorner", true);
                defineSymbol(symbols_math, ams, symbols_open, "└", "\\llcorner", true);
                defineSymbol(symbols_math, ams, symbols_close, "┘", "\\lrcorner", true);
                defineSymbol(symbols_math, ams, rel, "≦", "\\leqq", true);
                defineSymbol(symbols_math, ams, rel, "⩽", "\\leqslant", true);
                defineSymbol(symbols_math, ams, rel, "⪕", "\\eqslantless", true);
                defineSymbol(symbols_math, ams, rel, "≲", "\\lesssim", true);
                defineSymbol(symbols_math, ams, rel, "⪅", "\\lessapprox", true);
                defineSymbol(symbols_math, ams, rel, "≊", "\\approxeq", true);
                defineSymbol(symbols_math, ams, bin, "⋖", "\\lessdot");
                defineSymbol(symbols_math, ams, rel, "⋘", "\\lll", true);
                defineSymbol(symbols_math, ams, rel, "≶", "\\lessgtr", true);
                defineSymbol(symbols_math, ams, rel, "⋚", "\\lesseqgtr", true);
                defineSymbol(symbols_math, ams, rel, "⪋", "\\lesseqqgtr", true);
                defineSymbol(symbols_math, ams, rel, "≑", "\\doteqdot");
                defineSymbol(symbols_math, ams, rel, "≓", "\\risingdotseq", true);
                defineSymbol(symbols_math, ams, rel, "≒", "\\fallingdotseq", true);
                defineSymbol(symbols_math, ams, rel, "∽", "\\backsim", true);
                defineSymbol(symbols_math, ams, rel, "⋍", "\\backsimeq", true);
                defineSymbol(symbols_math, ams, rel, "⫅", "\\subseteqq", true);
                defineSymbol(symbols_math, ams, rel, "⋐", "\\Subset", true);
                defineSymbol(symbols_math, ams, rel, "⊏", "\\sqsubset", true);
                defineSymbol(symbols_math, ams, rel, "≼", "\\preccurlyeq", true);
                defineSymbol(symbols_math, ams, rel, "⋞", "\\curlyeqprec", true);
                defineSymbol(symbols_math, ams, rel, "≾", "\\precsim", true);
                defineSymbol(symbols_math, ams, rel, "⪷", "\\precapprox", true);
                defineSymbol(symbols_math, ams, rel, "⊲", "\\vartriangleleft");
                defineSymbol(symbols_math, ams, rel, "⊴", "\\trianglelefteq");
                defineSymbol(symbols_math, ams, rel, "⊨", "\\vDash", true);
                defineSymbol(symbols_math, ams, rel, "⊪", "\\Vvdash", true);
                defineSymbol(symbols_math, ams, rel, "⌣", "\\smallsmile");
                defineSymbol(symbols_math, ams, rel, "⌢", "\\smallfrown");
                defineSymbol(symbols_math, ams, rel, "≏", "\\bumpeq", true);
                defineSymbol(symbols_math, ams, rel, "≎", "\\Bumpeq", true);
                defineSymbol(symbols_math, ams, rel, "≧", "\\geqq", true);
                defineSymbol(symbols_math, ams, rel, "⩾", "\\geqslant", true);
                defineSymbol(symbols_math, ams, rel, "⪖", "\\eqslantgtr", true);
                defineSymbol(symbols_math, ams, rel, "≳", "\\gtrsim", true);
                defineSymbol(symbols_math, ams, rel, "⪆", "\\gtrapprox", true);
                defineSymbol(symbols_math, ams, bin, "⋗", "\\gtrdot");
                defineSymbol(symbols_math, ams, rel, "⋙", "\\ggg", true);
                defineSymbol(symbols_math, ams, rel, "≷", "\\gtrless", true);
                defineSymbol(symbols_math, ams, rel, "⋛", "\\gtreqless", true);
                defineSymbol(symbols_math, ams, rel, "⪌", "\\gtreqqless", true);
                defineSymbol(symbols_math, ams, rel, "≖", "\\eqcirc", true);
                defineSymbol(symbols_math, ams, rel, "≗", "\\circeq", true);
                defineSymbol(symbols_math, ams, rel, "≜", "\\triangleq", true);
                defineSymbol(symbols_math, ams, rel, "∼", "\\thicksim");
                defineSymbol(symbols_math, ams, rel, "≈", "\\thickapprox");
                defineSymbol(symbols_math, ams, rel, "⫆", "\\supseteqq", true);
                defineSymbol(symbols_math, ams, rel, "⋑", "\\Supset", true);
                defineSymbol(symbols_math, ams, rel, "⊐", "\\sqsupset", true);
                defineSymbol(symbols_math, ams, rel, "≽", "\\succcurlyeq", true);
                defineSymbol(symbols_math, ams, rel, "⋟", "\\curlyeqsucc", true);
                defineSymbol(symbols_math, ams, rel, "≿", "\\succsim", true);
                defineSymbol(symbols_math, ams, rel, "⪸", "\\succapprox", true);
                defineSymbol(symbols_math, ams, rel, "⊳", "\\vartriangleright");
                defineSymbol(symbols_math, ams, rel, "⊵", "\\trianglerighteq");
                defineSymbol(symbols_math, ams, rel, "⊩", "\\Vdash", true);
                defineSymbol(symbols_math, ams, rel, "∣", "\\shortmid");
                defineSymbol(symbols_math, ams, rel, "∥", "\\shortparallel");
                defineSymbol(symbols_math, ams, rel, "≬", "\\between", true);
                defineSymbol(symbols_math, ams, rel, "⋔", "\\pitchfork", true);
                defineSymbol(symbols_math, ams, rel, "∝", "\\varpropto");
                defineSymbol(symbols_math, ams, rel, "◀", "\\blacktriangleleft");
                defineSymbol(symbols_math, ams, rel, "∴", "\\therefore", true);
                defineSymbol(symbols_math, ams, rel, "∍", "\\backepsilon");
                defineSymbol(symbols_math, ams, rel, "▶", "\\blacktriangleright");
                defineSymbol(symbols_math, ams, rel, "∵", "\\because", true);
                defineSymbol(symbols_math, ams, rel, "⋘", "\\llless");
                defineSymbol(symbols_math, ams, rel, "⋙", "\\gggtr");
                defineSymbol(symbols_math, ams, bin, "⊲", "\\lhd");
                defineSymbol(symbols_math, ams, bin, "⊳", "\\rhd");
                defineSymbol(symbols_math, ams, rel, "≂", "\\eqsim", true);
                defineSymbol(symbols_math, main, rel, "⋈", "\\Join");
                defineSymbol(symbols_math, ams, rel, "≑", "\\Doteq", true);
                defineSymbol(symbols_math, ams, bin, "∔", "\\dotplus", true);
                defineSymbol(symbols_math, ams, bin, "∖", "\\smallsetminus");
                defineSymbol(symbols_math, ams, bin, "⋒", "\\Cap", true);
                defineSymbol(symbols_math, ams, bin, "⋓", "\\Cup", true);
                defineSymbol(symbols_math, ams, bin, "⩞", "\\doublebarwedge", true);
                defineSymbol(symbols_math, ams, bin, "⊟", "\\boxminus", true);
                defineSymbol(symbols_math, ams, bin, "⊞", "\\boxplus", true);
                defineSymbol(symbols_math, ams, bin, "⋇", "\\divideontimes", true);
                defineSymbol(symbols_math, ams, bin, "⋉", "\\ltimes", true);
                defineSymbol(symbols_math, ams, bin, "⋊", "\\rtimes", true);
                defineSymbol(symbols_math, ams, bin, "⋋", "\\leftthreetimes", true);
                defineSymbol(symbols_math, ams, bin, "⋌", "\\rightthreetimes", true);
                defineSymbol(symbols_math, ams, bin, "⋏", "\\curlywedge", true);
                defineSymbol(symbols_math, ams, bin, "⋎", "\\curlyvee", true);
                defineSymbol(symbols_math, ams, bin, "⊝", "\\circleddash", true);
                defineSymbol(symbols_math, ams, bin, "⊛", "\\circledast", true);
                defineSymbol(symbols_math, ams, bin, "⋅", "\\centerdot");
                defineSymbol(symbols_math, ams, bin, "⊺", "\\intercal", true);
                defineSymbol(symbols_math, ams, bin, "⋒", "\\doublecap");
                defineSymbol(symbols_math, ams, bin, "⋓", "\\doublecup");
                defineSymbol(symbols_math, ams, bin, "⊠", "\\boxtimes", true);
                defineSymbol(symbols_math, ams, rel, "⇢", "\\dashrightarrow", true);
                defineSymbol(symbols_math, ams, rel, "⇠", "\\dashleftarrow", true);
                defineSymbol(symbols_math, ams, rel, "⇇", "\\leftleftarrows", true);
                defineSymbol(symbols_math, ams, rel, "⇆", "\\leftrightarrows", true);
                defineSymbol(symbols_math, ams, rel, "⇚", "\\Lleftarrow", true);
                defineSymbol(symbols_math, ams, rel, "↞", "\\twoheadleftarrow", true);
                defineSymbol(symbols_math, ams, rel, "↢", "\\leftarrowtail", true);
                defineSymbol(symbols_math, ams, rel, "↫", "\\looparrowleft", true);
                defineSymbol(symbols_math, ams, rel, "⇋", "\\leftrightharpoons", true);
                defineSymbol(symbols_math, ams, rel, "↶", "\\curvearrowleft", true);
                defineSymbol(symbols_math, ams, rel, "↺", "\\circlearrowleft", true);
                defineSymbol(symbols_math, ams, rel, "↰", "\\Lsh", true);
                defineSymbol(symbols_math, ams, rel, "⇈", "\\upuparrows", true);
                defineSymbol(symbols_math, ams, rel, "↿", "\\upharpoonleft", true);
                defineSymbol(symbols_math, ams, rel, "⇃", "\\downharpoonleft", true);
                defineSymbol(symbols_math, ams, rel, "⊸", "\\multimap", true);
                defineSymbol(symbols_math, ams, rel, "↭", "\\leftrightsquigarrow", true);
                defineSymbol(symbols_math, ams, rel, "⇉", "\\rightrightarrows", true);
                defineSymbol(symbols_math, ams, rel, "⇄", "\\rightleftarrows", true);
                defineSymbol(symbols_math, ams, rel, "↠", "\\twoheadrightarrow", true);
                defineSymbol(symbols_math, ams, rel, "↣", "\\rightarrowtail", true);
                defineSymbol(symbols_math, ams, rel, "↬", "\\looparrowright", true);
                defineSymbol(symbols_math, ams, rel, "↷", "\\curvearrowright", true);
                defineSymbol(symbols_math, ams, rel, "↻", "\\circlearrowright", true);
                defineSymbol(symbols_math, ams, rel, "↱", "\\Rsh", true);
                defineSymbol(symbols_math, ams, rel, "⇊", "\\downdownarrows", true);
                defineSymbol(symbols_math, ams, rel, "↾", "\\upharpoonright", true);
                defineSymbol(symbols_math, ams, rel, "⇂", "\\downharpoonright", true);
                defineSymbol(symbols_math, ams, rel, "⇝", "\\rightsquigarrow", true);
                defineSymbol(symbols_math, ams, rel, "⇝", "\\leadsto");
                defineSymbol(symbols_math, ams, rel, "⇛", "\\Rrightarrow", true);
                defineSymbol(symbols_math, ams, rel, "↾", "\\restriction");
                defineSymbol(symbols_math, main, symbols_textord, "‘", "`");
                defineSymbol(symbols_math, main, symbols_textord, "$", "\\$");
                defineSymbol(symbols_text, main, symbols_textord, "$", "\\$");
                defineSymbol(symbols_text, main, symbols_textord, "$", "\\textdollar");
                defineSymbol(symbols_math, main, symbols_textord, "%", "\\%");
                defineSymbol(symbols_text, main, symbols_textord, "%", "\\%");
                defineSymbol(symbols_math, main, symbols_textord, "_", "\\_");
                defineSymbol(symbols_text, main, symbols_textord, "_", "\\_");
                defineSymbol(symbols_text, main, symbols_textord, "_", "\\textunderscore");
                defineSymbol(symbols_math, main, symbols_textord, "∠", "\\angle", true);
                defineSymbol(symbols_math, main, symbols_textord, "∞", "\\infty", true);
                defineSymbol(symbols_math, main, symbols_textord, "′", "\\prime");
                defineSymbol(symbols_math, main, symbols_textord, "△", "\\triangle");
                defineSymbol(symbols_math, main, symbols_textord, "Γ", "\\Gamma", true);
                defineSymbol(symbols_math, main, symbols_textord, "Δ", "\\Delta", true);
                defineSymbol(symbols_math, main, symbols_textord, "Θ", "\\Theta", true);
                defineSymbol(symbols_math, main, symbols_textord, "Λ", "\\Lambda", true);
                defineSymbol(symbols_math, main, symbols_textord, "Ξ", "\\Xi", true);
                defineSymbol(symbols_math, main, symbols_textord, "Π", "\\Pi", true);
                defineSymbol(symbols_math, main, symbols_textord, "Σ", "\\Sigma", true);
                defineSymbol(symbols_math, main, symbols_textord, "Υ", "\\Upsilon", true);
                defineSymbol(symbols_math, main, symbols_textord, "Φ", "\\Phi", true);
                defineSymbol(symbols_math, main, symbols_textord, "Ψ", "\\Psi", true);
                defineSymbol(symbols_math, main, symbols_textord, "Ω", "\\Omega", true);
                defineSymbol(symbols_math, main, symbols_textord, "A", "Α");
                defineSymbol(symbols_math, main, symbols_textord, "B", "Β");
                defineSymbol(symbols_math, main, symbols_textord, "E", "Ε");
                defineSymbol(symbols_math, main, symbols_textord, "Z", "Ζ");
                defineSymbol(symbols_math, main, symbols_textord, "H", "Η");
                defineSymbol(symbols_math, main, symbols_textord, "I", "Ι");
                defineSymbol(symbols_math, main, symbols_textord, "K", "Κ");
                defineSymbol(symbols_math, main, symbols_textord, "M", "Μ");
                defineSymbol(symbols_math, main, symbols_textord, "N", "Ν");
                defineSymbol(symbols_math, main, symbols_textord, "O", "Ο");
                defineSymbol(symbols_math, main, symbols_textord, "P", "Ρ");
                defineSymbol(symbols_math, main, symbols_textord, "T", "Τ");
                defineSymbol(symbols_math, main, symbols_textord, "X", "Χ");
                defineSymbol(symbols_math, main, symbols_textord, "¬", "\\neg", true);
                defineSymbol(symbols_math, main, symbols_textord, "¬", "\\lnot");
                defineSymbol(symbols_math, main, symbols_textord, "⊤", "\\top");
                defineSymbol(symbols_math, main, symbols_textord, "⊥", "\\bot");
                defineSymbol(symbols_math, main, symbols_textord, "∅", "\\emptyset");
                defineSymbol(symbols_math, ams, symbols_textord, "∅", "\\varnothing");
                defineSymbol(symbols_math, main, mathord, "α", "\\alpha", true);
                defineSymbol(symbols_math, main, mathord, "β", "\\beta", true);
                defineSymbol(symbols_math, main, mathord, "γ", "\\gamma", true);
                defineSymbol(symbols_math, main, mathord, "δ", "\\delta", true);
                defineSymbol(symbols_math, main, mathord, "ϵ", "\\epsilon", true);
                defineSymbol(symbols_math, main, mathord, "ζ", "\\zeta", true);
                defineSymbol(symbols_math, main, mathord, "η", "\\eta", true);
                defineSymbol(symbols_math, main, mathord, "θ", "\\theta", true);
                defineSymbol(symbols_math, main, mathord, "ι", "\\iota", true);
                defineSymbol(symbols_math, main, mathord, "κ", "\\kappa", true);
                defineSymbol(symbols_math, main, mathord, "λ", "\\lambda", true);
                defineSymbol(symbols_math, main, mathord, "μ", "\\mu", true);
                defineSymbol(symbols_math, main, mathord, "ν", "\\nu", true);
                defineSymbol(symbols_math, main, mathord, "ξ", "\\xi", true);
                defineSymbol(symbols_math, main, mathord, "ο", "\\omicron", true);
                defineSymbol(symbols_math, main, mathord, "π", "\\pi", true);
                defineSymbol(symbols_math, main, mathord, "ρ", "\\rho", true);
                defineSymbol(symbols_math, main, mathord, "σ", "\\sigma", true);
                defineSymbol(symbols_math, main, mathord, "τ", "\\tau", true);
                defineSymbol(symbols_math, main, mathord, "υ", "\\upsilon", true);
                defineSymbol(symbols_math, main, mathord, "ϕ", "\\phi", true);
                defineSymbol(symbols_math, main, mathord, "χ", "\\chi", true);
                defineSymbol(symbols_math, main, mathord, "ψ", "\\psi", true);
                defineSymbol(symbols_math, main, mathord, "ω", "\\omega", true);
                defineSymbol(symbols_math, main, mathord, "ε", "\\varepsilon", true);
                defineSymbol(symbols_math, main, mathord, "ϑ", "\\vartheta", true);
                defineSymbol(symbols_math, main, mathord, "ϖ", "\\varpi", true);
                defineSymbol(symbols_math, main, mathord, "ϱ", "\\varrho", true);
                defineSymbol(symbols_math, main, mathord, "ς", "\\varsigma", true);
                defineSymbol(symbols_math, main, mathord, "φ", "\\varphi", true);
                defineSymbol(symbols_math, main, bin, "∗", "*");
                defineSymbol(symbols_math, main, bin, "+", "+");
                defineSymbol(symbols_math, main, bin, "−", "-");
                defineSymbol(symbols_math, main, bin, "⋅", "\\cdot", true);
                defineSymbol(symbols_math, main, bin, "∘", "\\circ");
                defineSymbol(symbols_math, main, bin, "÷", "\\div", true);
                defineSymbol(symbols_math, main, bin, "±", "\\pm", true);
                defineSymbol(symbols_math, main, bin, "×", "\\times", true);
                defineSymbol(symbols_math, main, bin, "∩", "\\cap", true);
                defineSymbol(symbols_math, main, bin, "∪", "\\cup", true);
                defineSymbol(symbols_math, main, bin, "∖", "\\setminus");
                defineSymbol(symbols_math, main, bin, "∧", "\\land");
                defineSymbol(symbols_math, main, bin, "∨", "\\lor");
                defineSymbol(symbols_math, main, bin, "∧", "\\wedge", true);
                defineSymbol(symbols_math, main, bin, "∨", "\\vee", true);
                defineSymbol(symbols_math, main, symbols_textord, "√", "\\surd");
                defineSymbol(symbols_math, main, symbols_open, "(", "(");
                defineSymbol(symbols_math, main, symbols_open, "[", "[");
                defineSymbol(symbols_math, main, symbols_open, "⟨", "\\langle", true);
                defineSymbol(symbols_math, main, symbols_open, "∣", "\\lvert");
                defineSymbol(symbols_math, main, symbols_open, "∥", "\\lVert");
                defineSymbol(symbols_math, main, symbols_close, ")", ")");
                defineSymbol(symbols_math, main, symbols_close, "]", "]");
                defineSymbol(symbols_math, main, symbols_close, "?", "?");
                defineSymbol(symbols_math, main, symbols_close, "!", "!");
                defineSymbol(symbols_math, main, symbols_close, "⟩", "\\rangle", true);
                defineSymbol(symbols_math, main, symbols_close, "∣", "\\rvert");
                defineSymbol(symbols_math, main, symbols_close, "∥", "\\rVert");
                defineSymbol(symbols_math, main, rel, "=", "=");
                defineSymbol(symbols_math, main, rel, "<", "<");
                defineSymbol(symbols_math, main, rel, ">", ">");
                defineSymbol(symbols_math, main, rel, ":", ":");
                defineSymbol(symbols_math, main, rel, "≈", "\\approx", true);
                defineSymbol(symbols_math, main, rel, "≅", "\\cong", true);
                defineSymbol(symbols_math, main, rel, "≥", "\\ge");
                defineSymbol(symbols_math, main, rel, "≥", "\\geq", true);
                defineSymbol(symbols_math, main, rel, "←", "\\gets");
                defineSymbol(symbols_math, main, rel, ">", "\\gt");
                defineSymbol(symbols_math, main, rel, "∈", "\\in", true);
                defineSymbol(symbols_math, main, rel, "̸", "\\@not");
                defineSymbol(symbols_math, main, rel, "⊂", "\\subset", true);
                defineSymbol(symbols_math, main, rel, "⊃", "\\supset", true);
                defineSymbol(symbols_math, main, rel, "⊆", "\\subseteq", true);
                defineSymbol(symbols_math, main, rel, "⊇", "\\supseteq", true);
                defineSymbol(symbols_math, ams, rel, "⊈", "\\nsubseteq", true);
                defineSymbol(symbols_math, ams, rel, "⊉", "\\nsupseteq", true);
                defineSymbol(symbols_math, main, rel, "⊨", "\\models");
                defineSymbol(symbols_math, main, rel, "←", "\\leftarrow", true);
                defineSymbol(symbols_math, main, rel, "≤", "\\le");
                defineSymbol(symbols_math, main, rel, "≤", "\\leq", true);
                defineSymbol(symbols_math, main, rel, "<", "\\lt");
                defineSymbol(symbols_math, main, rel, "→", "\\rightarrow", true);
                defineSymbol(symbols_math, main, rel, "→", "\\to");
                defineSymbol(symbols_math, ams, rel, "≱", "\\ngeq", true);
                defineSymbol(symbols_math, ams, rel, "≰", "\\nleq", true);
                defineSymbol(symbols_math, main, spacing, " ", "\\ ");
                defineSymbol(symbols_math, main, spacing, " ", "~");
                defineSymbol(symbols_math, main, spacing, " ", "\\space");
                defineSymbol(symbols_math, main, spacing, " ", "\\nobreakspace");
                defineSymbol(symbols_text, main, spacing, " ", "\\ ");
                defineSymbol(symbols_text, main, spacing, " ", "~");
                defineSymbol(symbols_text, main, spacing, " ", "\\space");
                defineSymbol(symbols_text, main, spacing, " ", "\\nobreakspace");
                defineSymbol(symbols_math, main, spacing, null, "\\nobreak");
                defineSymbol(symbols_math, main, spacing, null, "\\allowbreak");
                defineSymbol(symbols_math, main, punct, ",", ",");
                defineSymbol(symbols_math, main, punct, ";", ";");
                defineSymbol(symbols_math, ams, bin, "⊼", "\\barwedge", true);
                defineSymbol(symbols_math, ams, bin, "⊻", "\\veebar", true);
                defineSymbol(symbols_math, main, bin, "⊙", "\\odot", true);
                defineSymbol(symbols_math, main, bin, "⊕", "\\oplus", true);
                defineSymbol(symbols_math, main, bin, "⊗", "\\otimes", true);
                defineSymbol(symbols_math, main, symbols_textord, "∂", "\\partial", true);
                defineSymbol(symbols_math, main, bin, "⊘", "\\oslash", true);
                defineSymbol(symbols_math, ams, bin, "⊚", "\\circledcirc", true);
                defineSymbol(symbols_math, ams, bin, "⊡", "\\boxdot", true);
                defineSymbol(symbols_math, main, bin, "△", "\\bigtriangleup");
                defineSymbol(symbols_math, main, bin, "▽", "\\bigtriangledown");
                defineSymbol(symbols_math, main, bin, "†", "\\dagger");
                defineSymbol(symbols_math, main, bin, "⋄", "\\diamond");
                defineSymbol(symbols_math, main, bin, "⋆", "\\star");
                defineSymbol(symbols_math, main, bin, "◃", "\\triangleleft");
                defineSymbol(symbols_math, main, bin, "▹", "\\triangleright");
                defineSymbol(symbols_math, main, symbols_open, "{", "\\{");
                defineSymbol(symbols_text, main, symbols_textord, "{", "\\{");
                defineSymbol(symbols_text, main, symbols_textord, "{", "\\textbraceleft");
                defineSymbol(symbols_math, main, symbols_close, "}", "\\}");
                defineSymbol(symbols_text, main, symbols_textord, "}", "\\}");
                defineSymbol(symbols_text, main, symbols_textord, "}", "\\textbraceright");
                defineSymbol(symbols_math, main, symbols_open, "{", "\\lbrace");
                defineSymbol(symbols_math, main, symbols_close, "}", "\\rbrace");
                defineSymbol(symbols_math, main, symbols_open, "[", "\\lbrack");
                defineSymbol(symbols_text, main, symbols_textord, "[", "\\lbrack");
                defineSymbol(symbols_math, main, symbols_close, "]", "\\rbrack");
                defineSymbol(symbols_text, main, symbols_textord, "]", "\\rbrack");
                defineSymbol(symbols_math, main, symbols_open, "(", "\\lparen");
                defineSymbol(symbols_math, main, symbols_close, ")", "\\rparen");
                defineSymbol(symbols_text, main, symbols_textord, "<", "\\textless");
                defineSymbol(symbols_text, main, symbols_textord, ">", "\\textgreater");
                defineSymbol(symbols_math, main, symbols_open, "⌊", "\\lfloor", true);
                defineSymbol(symbols_math, main, symbols_close, "⌋", "\\rfloor", true);
                defineSymbol(symbols_math, main, symbols_open, "⌈", "\\lceil", true);
                defineSymbol(symbols_math, main, symbols_close, "⌉", "\\rceil", true);
                defineSymbol(symbols_math, main, symbols_textord, "\\", "\\backslash");
                defineSymbol(symbols_math, main, symbols_textord, "∣", "|");
                defineSymbol(symbols_math, main, symbols_textord, "∣", "\\vert");
                defineSymbol(symbols_text, main, symbols_textord, "|", "\\textbar");
                defineSymbol(symbols_math, main, symbols_textord, "∥", "\\|");
                defineSymbol(symbols_math, main, symbols_textord, "∥", "\\Vert");
                defineSymbol(symbols_text, main, symbols_textord, "∥", "\\textbardbl");
                defineSymbol(symbols_text, main, symbols_textord, "~", "\\textasciitilde");
                defineSymbol(symbols_math, main, rel, "↑", "\\uparrow", true);
                defineSymbol(symbols_math, main, rel, "⇑", "\\Uparrow", true);
                defineSymbol(symbols_math, main, rel, "↓", "\\downarrow", true);
                defineSymbol(symbols_math, main, rel, "⇓", "\\Downarrow", true);
                defineSymbol(symbols_math, main, rel, "↕", "\\updownarrow", true);
                defineSymbol(symbols_math, main, rel, "⇕", "\\Updownarrow", true);
                defineSymbol(symbols_math, main, op, "∐", "\\coprod");
                defineSymbol(symbols_math, main, op, "⋁", "\\bigvee");
                defineSymbol(symbols_math, main, op, "⋀", "\\bigwedge");
                defineSymbol(symbols_math, main, op, "⨄", "\\biguplus");
                defineSymbol(symbols_math, main, op, "⋂", "\\bigcap");
                defineSymbol(symbols_math, main, op, "⋃", "\\bigcup");
                defineSymbol(symbols_math, main, op, "∫", "\\int");
                defineSymbol(symbols_math, main, op, "∫", "\\intop");
                defineSymbol(symbols_math, main, op, "∬", "\\iint");
                defineSymbol(symbols_math, main, op, "∭", "\\iiint");
                defineSymbol(symbols_math, main, op, "∏", "\\prod");
                defineSymbol(symbols_math, main, op, "∑", "\\sum");
                defineSymbol(symbols_math, main, op, "⨂", "\\bigotimes");
                defineSymbol(symbols_math, main, op, "⨁", "\\bigoplus");
                defineSymbol(symbols_math, main, op, "⨀", "\\bigodot");
                defineSymbol(symbols_math, main, op, "∮", "\\oint");
                defineSymbol(symbols_math, main, op, "∯", "\\oiint");
                defineSymbol(symbols_math, main, op, "∰", "\\oiiint");
                defineSymbol(symbols_math, main, op, "⨆", "\\bigsqcup");
                defineSymbol(symbols_math, main, op, "∫", "\\smallint");
                defineSymbol(symbols_text, main, symbols_inner, "…", "\\textellipsis");
                defineSymbol(symbols_math, main, symbols_inner, "…", "\\mathellipsis");
                defineSymbol(symbols_text, main, symbols_inner, "…", "\\ldots", true);
                defineSymbol(symbols_math, main, symbols_inner, "…", "\\ldots", true);
                defineSymbol(symbols_math, main, symbols_inner, "⋯", "\\@cdots", true);
                defineSymbol(symbols_math, main, symbols_inner, "⋱", "\\ddots", true);
                defineSymbol(symbols_math, main, symbols_textord, "⋮", "\\varvdots");
                defineSymbol(symbols_math, main, symbols_accent, "ˊ", "\\acute");
                defineSymbol(symbols_math, main, symbols_accent, "ˋ", "\\grave");
                defineSymbol(symbols_math, main, symbols_accent, "¨", "\\ddot");
                defineSymbol(symbols_math, main, symbols_accent, "~", "\\tilde");
                defineSymbol(symbols_math, main, symbols_accent, "ˉ", "\\bar");
                defineSymbol(symbols_math, main, symbols_accent, "˘", "\\breve");
                defineSymbol(symbols_math, main, symbols_accent, "ˇ", "\\check");
                defineSymbol(symbols_math, main, symbols_accent, "^", "\\hat");
                defineSymbol(symbols_math, main, symbols_accent, "⃗", "\\vec");
                defineSymbol(symbols_math, main, symbols_accent, "˙", "\\dot");
                defineSymbol(symbols_math, main, symbols_accent, "˚", "\\mathring");
                defineSymbol(symbols_math, main, mathord, "ı", "\\imath", true);
                defineSymbol(symbols_math, main, mathord, "ȷ", "\\jmath", true);
                defineSymbol(symbols_text, main, symbols_textord, "ı", "\\i", true);
                defineSymbol(symbols_text, main, symbols_textord, "ȷ", "\\j", true);
                defineSymbol(symbols_text, main, symbols_textord, "ß", "\\ss", true);
                defineSymbol(symbols_text, main, symbols_textord, "æ", "\\ae", true);
                defineSymbol(symbols_text, main, symbols_textord, "æ", "\\ae", true);
                defineSymbol(symbols_text, main, symbols_textord, "œ", "\\oe", true);
                defineSymbol(symbols_text, main, symbols_textord, "ø", "\\o", true);
                defineSymbol(symbols_text, main, symbols_textord, "Æ", "\\AE", true);
                defineSymbol(symbols_text, main, symbols_textord, "Œ", "\\OE", true);
                defineSymbol(symbols_text, main, symbols_textord, "Ø", "\\O", true);
                defineSymbol(symbols_text, main, symbols_accent, "ˊ", "\\'");
                defineSymbol(symbols_text, main, symbols_accent, "ˋ", "\\`");
                defineSymbol(symbols_text, main, symbols_accent, "ˆ", "\\^");
                defineSymbol(symbols_text, main, symbols_accent, "˜", "\\~");
                defineSymbol(symbols_text, main, symbols_accent, "ˉ", "\\=");
                defineSymbol(symbols_text, main, symbols_accent, "˘", "\\u");
                defineSymbol(symbols_text, main, symbols_accent, "˙", "\\.");
                defineSymbol(symbols_text, main, symbols_accent, "˚", "\\r");
                defineSymbol(symbols_text, main, symbols_accent, "ˇ", "\\v");
                defineSymbol(symbols_text, main, symbols_accent, "¨", '\\"');
                defineSymbol(symbols_text, main, symbols_accent, "˝", "\\H");
                defineSymbol(symbols_text, main, symbols_accent, "◯", "\\textcircled");
                var ligatures = {
                  "--": true,
                  "---": true,
                  "``": true,
                  "''": true
                };
                defineSymbol(symbols_text, main, symbols_textord, "–", "--");
                defineSymbol(symbols_text, main, symbols_textord, "–", "\\textendash");
                defineSymbol(symbols_text, main, symbols_textord, "—", "---");
                defineSymbol(symbols_text, main, symbols_textord, "—", "\\textemdash");
                defineSymbol(symbols_text, main, symbols_textord, "‘", "`");
                defineSymbol(symbols_text, main, symbols_textord, "‘", "\\textquoteleft");
                defineSymbol(symbols_text, main, symbols_textord, "’", "'");
                defineSymbol(symbols_text, main, symbols_textord, "’", "\\textquoteright");
                defineSymbol(symbols_text, main, symbols_textord, "“", "``");
                defineSymbol(symbols_text, main, symbols_textord, "“", "\\textquotedblleft");
                defineSymbol(symbols_text, main, symbols_textord, "”", "''");
                defineSymbol(symbols_text, main, symbols_textord, "”", "\\textquotedblright");
                defineSymbol(symbols_math, main, symbols_textord, "°", "\\degree", true);
                defineSymbol(symbols_text, main, symbols_textord, "°", "\\degree");
                defineSymbol(symbols_text, main, symbols_textord, "°", "\\textdegree", true);
                defineSymbol(symbols_math, main, mathord, "£", "\\pounds");
                defineSymbol(symbols_math, main, mathord, "£", "\\mathsterling", true);
                defineSymbol(symbols_text, main, mathord, "£", "\\pounds");
                defineSymbol(symbols_text, main, mathord, "£", "\\textsterling", true);
                defineSymbol(symbols_math, ams, symbols_textord, "✠", "\\maltese");
                defineSymbol(symbols_text, ams, symbols_textord, "✠", "\\maltese");
                defineSymbol(symbols_text, main, spacing, " ", "\\ ");
                defineSymbol(symbols_text, main, spacing, " ", " ");
                defineSymbol(symbols_text, main, spacing, " ", "~");
                var mathTextSymbols = '0123456789/@."';
                for (var symbols_i = 0; symbols_i < mathTextSymbols.length; symbols_i++) {
                  var symbols_ch = mathTextSymbols.charAt(symbols_i);
                  defineSymbol(symbols_math, main, symbols_textord, symbols_ch, symbols_ch);
                }
                var textSymbols = '0123456789!@*()-=+[]<>|";:?/.,';
                for (var src_symbols_i = 0; src_symbols_i < textSymbols.length; src_symbols_i++) {
                  var _ch = textSymbols.charAt(src_symbols_i);
                  defineSymbol(symbols_text, main, symbols_textord, _ch, _ch);
                }
                var letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
                for (var symbols_i2 = 0; symbols_i2 < letters.length; symbols_i2++) {
                  var _ch2 = letters.charAt(symbols_i2);
                  defineSymbol(symbols_math, main, mathord, _ch2, _ch2);
                  defineSymbol(symbols_text, main, symbols_textord, _ch2, _ch2);
                }
                var symbols_wideChar = "";
                for (var _i3 = 0; _i3 < letters.length; _i3++) {
                  var _ch3 = letters.charAt(_i3);
                  symbols_wideChar = String.fromCharCode(55349, 56320 + _i3);
                  defineSymbol(symbols_math, main, mathord, _ch3, symbols_wideChar);
                  defineSymbol(symbols_text, main, symbols_textord, _ch3, symbols_wideChar);
                  symbols_wideChar = String.fromCharCode(55349, 56372 + _i3);
                  defineSymbol(symbols_math, main, mathord, _ch3, symbols_wideChar);
                  defineSymbol(symbols_text, main, symbols_textord, _ch3, symbols_wideChar);
                  symbols_wideChar = String.fromCharCode(55349, 56424 + _i3);
                  defineSymbol(symbols_math, main, mathord, _ch3, symbols_wideChar);
                  defineSymbol(symbols_text, main, symbols_textord, _ch3, symbols_wideChar);
                  symbols_wideChar = String.fromCharCode(55349, 56580 + _i3);
                  defineSymbol(symbols_math, main, mathord, _ch3, symbols_wideChar);
                  defineSymbol(symbols_text, main, symbols_textord, _ch3, symbols_wideChar);
                  symbols_wideChar = String.fromCharCode(55349, 56736 + _i3);
                  defineSymbol(symbols_math, main, mathord, _ch3, symbols_wideChar);
                  defineSymbol(symbols_text, main, symbols_textord, _ch3, symbols_wideChar);
                  symbols_wideChar = String.fromCharCode(55349, 56788 + _i3);
                  defineSymbol(symbols_math, main, mathord, _ch3, symbols_wideChar);
                  defineSymbol(symbols_text, main, symbols_textord, _ch3, symbols_wideChar);
                  symbols_wideChar = String.fromCharCode(55349, 56840 + _i3);
                  defineSymbol(symbols_math, main, mathord, _ch3, symbols_wideChar);
                  defineSymbol(symbols_text, main, symbols_textord, _ch3, symbols_wideChar);
                  symbols_wideChar = String.fromCharCode(55349, 56944 + _i3);
                  defineSymbol(symbols_math, main, mathord, _ch3, symbols_wideChar);
                  defineSymbol(symbols_text, main, symbols_textord, _ch3, symbols_wideChar);
                  if (_i3 < 26) {
                    symbols_wideChar = String.fromCharCode(55349, 56632 + _i3);
                    defineSymbol(symbols_math, main, mathord, _ch3, symbols_wideChar);
                    defineSymbol(symbols_text, main, symbols_textord, _ch3, symbols_wideChar);
                    symbols_wideChar = String.fromCharCode(55349, 56476 + _i3);
                    defineSymbol(symbols_math, main, mathord, _ch3, symbols_wideChar);
                    defineSymbol(symbols_text, main, symbols_textord, _ch3, symbols_wideChar);
                  }
                }
                symbols_wideChar = String.fromCharCode(55349, 56668);
                defineSymbol(symbols_math, main, mathord, "k", symbols_wideChar);
                defineSymbol(symbols_text, main, symbols_textord, "k", symbols_wideChar);
                for (var _i4 = 0; _i4 < 10; _i4++) {
                  var _ch4 = _i4.toString();
                  symbols_wideChar = String.fromCharCode(55349, 57294 + _i4);
                  defineSymbol(symbols_math, main, mathord, _ch4, symbols_wideChar);
                  defineSymbol(symbols_text, main, symbols_textord, _ch4, symbols_wideChar);
                  symbols_wideChar = String.fromCharCode(55349, 57314 + _i4);
                  defineSymbol(symbols_math, main, mathord, _ch4, symbols_wideChar);
                  defineSymbol(symbols_text, main, symbols_textord, _ch4, symbols_wideChar);
                  symbols_wideChar = String.fromCharCode(55349, 57324 + _i4);
                  defineSymbol(symbols_math, main, mathord, _ch4, symbols_wideChar);
                  defineSymbol(symbols_text, main, symbols_textord, _ch4, symbols_wideChar);
                  symbols_wideChar = String.fromCharCode(55349, 57334 + _i4);
                  defineSymbol(symbols_math, main, mathord, _ch4, symbols_wideChar);
                  defineSymbol(symbols_text, main, symbols_textord, _ch4, symbols_wideChar);
                }
                var extraLatin = "ÇÐÞçþ";
                for (var _i5 = 0; _i5 < extraLatin.length; _i5++) {
                  var _ch5 = extraLatin.charAt(_i5);
                  defineSymbol(symbols_math, main, mathord, _ch5, _ch5);
                  defineSymbol(symbols_text, main, symbols_textord, _ch5, _ch5);
                }
                defineSymbol(symbols_text, main, symbols_textord, "ð", "ð");
                defineSymbol(symbols_text, main, symbols_textord, "–", "–");
                defineSymbol(symbols_text, main, symbols_textord, "—", "—");
                defineSymbol(symbols_text, main, symbols_textord, "‘", "‘");
                defineSymbol(symbols_text, main, symbols_textord, "’", "’");
                defineSymbol(symbols_text, main, symbols_textord, "“", "“");
                defineSymbol(symbols_text, main, symbols_textord, "”", "”");
                var wideLatinLetterData = [
                  ["mathbf", "textbf", "Main-Bold"],
                  // A-Z bold upright
                  ["mathbf", "textbf", "Main-Bold"],
                  // a-z bold upright
                  ["mathdefault", "textit", "Math-Italic"],
                  // A-Z italic
                  ["mathdefault", "textit", "Math-Italic"],
                  // a-z italic
                  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
                  // A-Z bold italic
                  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
                  // a-z bold italic
                  // Map fancy A-Z letters to script, not calligraphic.
                  // This aligns with unicode-math and math fonts (except Cambria Math).
                  ["mathscr", "textscr", "Script-Regular"],
                  // A-Z script
                  ["", "", ""],
                  // a-z script.  No font
                  ["", "", ""],
                  // A-Z bold script. No font
                  ["", "", ""],
                  // a-z bold script. No font
                  ["mathfrak", "textfrak", "Fraktur-Regular"],
                  // A-Z Fraktur
                  ["mathfrak", "textfrak", "Fraktur-Regular"],
                  // a-z Fraktur
                  ["mathbb", "textbb", "AMS-Regular"],
                  // A-Z double-struck
                  ["mathbb", "textbb", "AMS-Regular"],
                  // k double-struck
                  ["", "", ""],
                  // A-Z bold Fraktur No font metrics
                  ["", "", ""],
                  // a-z bold Fraktur.   No font.
                  ["mathsf", "textsf", "SansSerif-Regular"],
                  // A-Z sans-serif
                  ["mathsf", "textsf", "SansSerif-Regular"],
                  // a-z sans-serif
                  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
                  // A-Z bold sans-serif
                  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
                  // a-z bold sans-serif
                  ["mathitsf", "textitsf", "SansSerif-Italic"],
                  // A-Z italic sans-serif
                  ["mathitsf", "textitsf", "SansSerif-Italic"],
                  // a-z italic sans-serif
                  ["", "", ""],
                  // A-Z bold italic sans. No font
                  ["", "", ""],
                  // a-z bold italic sans. No font
                  ["mathtt", "texttt", "Typewriter-Regular"],
                  // A-Z monospace
                  ["mathtt", "texttt", "Typewriter-Regular"]
                ];
                var wideNumeralData = [
                  ["mathbf", "textbf", "Main-Bold"],
                  // 0-9 bold
                  ["", "", ""],
                  // 0-9 double-struck. No KaTeX font.
                  ["mathsf", "textsf", "SansSerif-Regular"],
                  // 0-9 sans-serif
                  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
                  // 0-9 bold sans-serif
                  ["mathtt", "texttt", "Typewriter-Regular"]
                ];
                var wide_character_wideCharacterFont = function wideCharacterFont(wideChar, mode) {
                  var H = wideChar.charCodeAt(0);
                  var L = wideChar.charCodeAt(1);
                  var codePoint = (H - 55296) * 1024 + (L - 56320) + 65536;
                  var j = mode === "math" ? 0 : 1;
                  if (119808 <= codePoint && codePoint < 120484) {
                    var i = Math.floor((codePoint - 119808) / 26);
                    return [wideLatinLetterData[i][2], wideLatinLetterData[i][j]];
                  } else if (120782 <= codePoint && codePoint <= 120831) {
                    var _i = Math.floor((codePoint - 120782) / 10);
                    return [wideNumeralData[_i][2], wideNumeralData[_i][j]];
                  } else if (codePoint === 120485 || codePoint === 120486) {
                    return [wideLatinLetterData[0][2], wideLatinLetterData[0][j]];
                  } else if (120486 < codePoint && codePoint < 120782) {
                    return ["", ""];
                  } else {
                    throw new src_ParseError("Unsupported character: " + wideChar);
                  }
                };
                var sizeStyleMap = [
                  // Each element contains [textsize, scriptsize, scriptscriptsize].
                  // The size mappings are taken from TeX with \normalsize=10pt.
                  [1, 1, 1],
                  // size1: [5, 5, 5]              \tiny
                  [2, 1, 1],
                  // size2: [6, 5, 5]
                  [3, 1, 1],
                  // size3: [7, 5, 5]              \scriptsize
                  [4, 2, 1],
                  // size4: [8, 6, 5]              \footnotesize
                  [5, 2, 1],
                  // size5: [9, 6, 5]              \small
                  [6, 3, 1],
                  // size6: [10, 7, 5]             \normalsize
                  [7, 4, 2],
                  // size7: [12, 8, 6]             \large
                  [8, 6, 3],
                  // size8: [14.4, 10, 7]          \Large
                  [9, 7, 6],
                  // size9: [17.28, 12, 10]        \LARGE
                  [10, 8, 7],
                  // size10: [20.74, 14.4, 12]     \huge
                  [11, 10, 9]
                ];
                var sizeMultipliers = [
                  // fontMetrics.js:getGlobalMetrics also uses size indexes, so if
                  // you change size indexes, change that function.
                  0.5,
                  0.6,
                  0.7,
                  0.8,
                  0.9,
                  1,
                  1.2,
                  1.44,
                  1.728,
                  2.074,
                  2.488
                ];
                var sizeAtStyle = function sizeAtStyle2(size, style) {
                  return style.size < 2 ? size : sizeStyleMap[size - 1][style.size - 1];
                };
                var Options_Options = function() {
                  function Options(data) {
                    this.style = void 0;
                    this.color = void 0;
                    this.size = void 0;
                    this.textSize = void 0;
                    this.phantom = void 0;
                    this.font = void 0;
                    this.fontFamily = void 0;
                    this.fontWeight = void 0;
                    this.fontShape = void 0;
                    this.sizeMultiplier = void 0;
                    this.maxSize = void 0;
                    this._fontMetrics = void 0;
                    this.style = data.style;
                    this.color = data.color;
                    this.size = data.size || Options.BASESIZE;
                    this.textSize = data.textSize || this.size;
                    this.phantom = !!data.phantom;
                    this.font = data.font || "";
                    this.fontFamily = data.fontFamily || "";
                    this.fontWeight = data.fontWeight || "";
                    this.fontShape = data.fontShape || "";
                    this.sizeMultiplier = sizeMultipliers[this.size - 1];
                    this.maxSize = data.maxSize;
                    this._fontMetrics = void 0;
                  }
                  var _proto = Options.prototype;
                  _proto.extend = function extend(extension) {
                    var data = {
                      style: this.style,
                      size: this.size,
                      textSize: this.textSize,
                      color: this.color,
                      phantom: this.phantom,
                      font: this.font,
                      fontFamily: this.fontFamily,
                      fontWeight: this.fontWeight,
                      fontShape: this.fontShape,
                      maxSize: this.maxSize
                    };
                    for (var key in extension) {
                      if (extension.hasOwnProperty(key)) {
                        data[key] = extension[key];
                      }
                    }
                    return new Options(data);
                  };
                  _proto.havingStyle = function havingStyle(style) {
                    if (this.style === style) {
                      return this;
                    } else {
                      return this.extend({
                        style,
                        size: sizeAtStyle(this.textSize, style)
                      });
                    }
                  };
                  _proto.havingCrampedStyle = function havingCrampedStyle() {
                    return this.havingStyle(this.style.cramp());
                  };
                  _proto.havingSize = function havingSize(size) {
                    if (this.size === size && this.textSize === size) {
                      return this;
                    } else {
                      return this.extend({
                        style: this.style.text(),
                        size,
                        textSize: size,
                        sizeMultiplier: sizeMultipliers[size - 1]
                      });
                    }
                  };
                  _proto.havingBaseStyle = function havingBaseStyle(style) {
                    style = style || this.style.text();
                    var wantSize = sizeAtStyle(Options.BASESIZE, style);
                    if (this.size === wantSize && this.textSize === Options.BASESIZE && this.style === style) {
                      return this;
                    } else {
                      return this.extend({
                        style,
                        size: wantSize
                      });
                    }
                  };
                  _proto.havingBaseSizing = function havingBaseSizing() {
                    var size;
                    switch (this.style.id) {
                      case 4:
                      case 5:
                        size = 3;
                        break;
                      case 6:
                      case 7:
                        size = 1;
                        break;
                      default:
                        size = 6;
                    }
                    return this.extend({
                      style: this.style.text(),
                      size
                    });
                  };
                  _proto.withColor = function withColor(color) {
                    return this.extend({
                      color
                    });
                  };
                  _proto.withPhantom = function withPhantom() {
                    return this.extend({
                      phantom: true
                    });
                  };
                  _proto.withFont = function withFont(font) {
                    return this.extend({
                      font
                    });
                  };
                  _proto.withTextFontFamily = function withTextFontFamily(fontFamily) {
                    return this.extend({
                      fontFamily,
                      font: ""
                    });
                  };
                  _proto.withTextFontWeight = function withTextFontWeight(fontWeight) {
                    return this.extend({
                      fontWeight,
                      font: ""
                    });
                  };
                  _proto.withTextFontShape = function withTextFontShape(fontShape) {
                    return this.extend({
                      fontShape,
                      font: ""
                    });
                  };
                  _proto.sizingClasses = function sizingClasses(oldOptions) {
                    if (oldOptions.size !== this.size) {
                      return ["sizing", "reset-size" + oldOptions.size, "size" + this.size];
                    } else {
                      return [];
                    }
                  };
                  _proto.baseSizingClasses = function baseSizingClasses() {
                    if (this.size !== Options.BASESIZE) {
                      return ["sizing", "reset-size" + this.size, "size" + Options.BASESIZE];
                    } else {
                      return [];
                    }
                  };
                  _proto.fontMetrics = function fontMetrics() {
                    if (!this._fontMetrics) {
                      this._fontMetrics = getGlobalMetrics(this.size);
                    }
                    return this._fontMetrics;
                  };
                  _proto.getColor = function getColor() {
                    if (this.phantom) {
                      return "transparent";
                    } else if (this.color != null && Options.colorMap.hasOwnProperty(this.color)) {
                      return Options.colorMap[this.color];
                    } else {
                      return this.color;
                    }
                  };
                  return Options;
                }();
                Options_Options.BASESIZE = 6;
                Options_Options.colorMap = {
                  "katex-blue": "#6495ed",
                  "katex-orange": "#ffa500",
                  "katex-pink": "#ff00af",
                  "katex-red": "#df0030",
                  "katex-green": "#28ae7b",
                  "katex-gray": "gray",
                  "katex-purple": "#9d38bd",
                  "katex-blueA": "#ccfaff",
                  "katex-blueB": "#80f6ff",
                  "katex-blueC": "#63d9ea",
                  "katex-blueD": "#11accd",
                  "katex-blueE": "#0c7f99",
                  "katex-tealA": "#94fff5",
                  "katex-tealB": "#26edd5",
                  "katex-tealC": "#01d1c1",
                  "katex-tealD": "#01a995",
                  "katex-tealE": "#208170",
                  "katex-greenA": "#b6ffb0",
                  "katex-greenB": "#8af281",
                  "katex-greenC": "#74cf70",
                  "katex-greenD": "#1fab54",
                  "katex-greenE": "#0d923f",
                  "katex-goldA": "#ffd0a9",
                  "katex-goldB": "#ffbb71",
                  "katex-goldC": "#ff9c39",
                  "katex-goldD": "#e07d10",
                  "katex-goldE": "#a75a05",
                  "katex-redA": "#fca9a9",
                  "katex-redB": "#ff8482",
                  "katex-redC": "#f9685d",
                  "katex-redD": "#e84d39",
                  "katex-redE": "#bc2612",
                  "katex-maroonA": "#ffbde0",
                  "katex-maroonB": "#ff92c6",
                  "katex-maroonC": "#ed5fa6",
                  "katex-maroonD": "#ca337c",
                  "katex-maroonE": "#9e034e",
                  "katex-purpleA": "#ddd7ff",
                  "katex-purpleB": "#c6b9fc",
                  "katex-purpleC": "#aa87ff",
                  "katex-purpleD": "#7854ab",
                  "katex-purpleE": "#543b78",
                  "katex-mintA": "#f5f9e8",
                  "katex-mintB": "#edf2df",
                  "katex-mintC": "#e0e5cc",
                  "katex-grayA": "#f6f7f7",
                  "katex-grayB": "#f0f1f2",
                  "katex-grayC": "#e3e5e6",
                  "katex-grayD": "#d6d8da",
                  "katex-grayE": "#babec2",
                  "katex-grayF": "#888d93",
                  "katex-grayG": "#626569",
                  "katex-grayH": "#3b3e40",
                  "katex-grayI": "#21242c",
                  "katex-kaBlue": "#314453",
                  "katex-kaGreen": "#71B307"
                };
                var src_Options = Options_Options;
                var ptPerUnit = {
                  // https://en.wikibooks.org/wiki/LaTeX/Lengths and
                  // https://tex.stackexchange.com/a/8263
                  "pt": 1,
                  // TeX point
                  "mm": 7227 / 2540,
                  // millimeter
                  "cm": 7227 / 254,
                  // centimeter
                  "in": 72.27,
                  // inch
                  "bp": 803 / 800,
                  // big (PostScript) points
                  "pc": 12,
                  // pica
                  "dd": 1238 / 1157,
                  // didot
                  "cc": 14856 / 1157,
                  // cicero (12 didot)
                  "nd": 685 / 642,
                  // new didot
                  "nc": 1370 / 107,
                  // new cicero (12 new didot)
                  "sp": 1 / 65536,
                  // scaled point (TeX's internal smallest unit)
                  // https://tex.stackexchange.com/a/41371
                  "px": 803 / 800
                  // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
                };
                var relativeUnit = {
                  "ex": true,
                  "em": true,
                  "mu": true
                };
                var validUnit = function validUnit2(unit) {
                  if (typeof unit !== "string") {
                    unit = unit.unit;
                  }
                  return unit in ptPerUnit || unit in relativeUnit || unit === "ex";
                };
                var units_calculateSize = function calculateSize(sizeValue, options) {
                  var scale;
                  if (sizeValue.unit in ptPerUnit) {
                    scale = ptPerUnit[sizeValue.unit] / options.fontMetrics().ptPerEm / options.sizeMultiplier;
                  } else if (sizeValue.unit === "mu") {
                    scale = options.fontMetrics().cssEmPerMu;
                  } else {
                    var unitOptions;
                    if (options.style.isTight()) {
                      unitOptions = options.havingStyle(options.style.text());
                    } else {
                      unitOptions = options;
                    }
                    if (sizeValue.unit === "ex") {
                      scale = unitOptions.fontMetrics().xHeight;
                    } else if (sizeValue.unit === "em") {
                      scale = unitOptions.fontMetrics().quad;
                    } else {
                      throw new src_ParseError("Invalid unit: '" + sizeValue.unit + "'");
                    }
                    if (unitOptions !== options) {
                      scale *= unitOptions.sizeMultiplier / options.sizeMultiplier;
                    }
                  }
                  return Math.min(sizeValue.number * scale, options.maxSize);
                };
                var mathitLetters = [
                  "\\imath",
                  "ı",
                  // dotless i
                  "\\jmath",
                  "ȷ",
                  // dotless j
                  "\\pounds",
                  "\\mathsterling",
                  "\\textsterling",
                  "£"
                ];
                var buildCommon_lookupSymbol = function lookupSymbol(value, fontName, mode) {
                  if (src_symbols[mode][value] && src_symbols[mode][value].replace) {
                    value = src_symbols[mode][value].replace;
                  }
                  return {
                    value,
                    metrics: getCharacterMetrics(value, fontName, mode)
                  };
                };
                var buildCommon_makeSymbol = function makeSymbol(value, fontName, mode, options, classes) {
                  var lookup = buildCommon_lookupSymbol(value, fontName, mode);
                  var metrics = lookup.metrics;
                  value = lookup.value;
                  var symbolNode;
                  if (metrics) {
                    var italic = metrics.italic;
                    if (mode === "text" || options && options.font === "mathit") {
                      italic = 0;
                    }
                    symbolNode = new domTree_SymbolNode(value, metrics.height, metrics.depth, italic, metrics.skew, metrics.width, classes);
                  } else {
                    typeof console !== "undefined" && console.warn("No character metrics for '" + value + "' in style '" + fontName + "'");
                    symbolNode = new domTree_SymbolNode(value, 0, 0, 0, 0, 0, classes);
                  }
                  if (options) {
                    symbolNode.maxFontSize = options.sizeMultiplier;
                    if (options.style.isTight()) {
                      symbolNode.classes.push("mtight");
                    }
                    var color = options.getColor();
                    if (color) {
                      symbolNode.style.color = color;
                    }
                  }
                  return symbolNode;
                };
                var buildCommon_mathsym = function mathsym(value, mode, options, classes) {
                  if (classes === void 0) {
                    classes = [];
                  }
                  if (options && options.font && options.font === "boldsymbol" && buildCommon_lookupSymbol(value, "Main-Bold", mode).metrics) {
                    return buildCommon_makeSymbol(value, "Main-Bold", mode, options, classes.concat(["mathbf"]));
                  } else if (value === "\\" || src_symbols[mode][value].font === "main") {
                    return buildCommon_makeSymbol(value, "Main-Regular", mode, options, classes);
                  } else {
                    return buildCommon_makeSymbol(value, "AMS-Regular", mode, options, classes.concat(["amsrm"]));
                  }
                };
                var buildCommon_mathdefault = function mathdefault(value, mode, options, classes) {
                  if (/[0-9]/.test(value.charAt(0)) || // glyphs for \imath and \jmath do not exist in Math-Italic so we
                  // need to use Main-Italic instead
                  utils.contains(mathitLetters, value)) {
                    return {
                      fontName: "Main-Italic",
                      fontClass: "mathit"
                    };
                  } else {
                    return {
                      fontName: "Math-Italic",
                      fontClass: "mathdefault"
                    };
                  }
                };
                var buildCommon_mathnormal = function mathnormal(value, mode, options, classes) {
                  if (utils.contains(mathitLetters, value)) {
                    return {
                      fontName: "Main-Italic",
                      fontClass: "mathit"
                    };
                  } else if (/[0-9]/.test(value.charAt(0))) {
                    return {
                      fontName: "Caligraphic-Regular",
                      fontClass: "mathcal"
                    };
                  } else {
                    return {
                      fontName: "Math-Italic",
                      fontClass: "mathdefault"
                    };
                  }
                };
                var boldsymbol = function boldsymbol2(value, mode, options, classes) {
                  if (buildCommon_lookupSymbol(value, "Math-BoldItalic", mode).metrics) {
                    return {
                      fontName: "Math-BoldItalic",
                      fontClass: "boldsymbol"
                    };
                  } else {
                    return {
                      fontName: "Main-Bold",
                      fontClass: "mathbf"
                    };
                  }
                };
                var buildCommon_makeOrd = function makeOrd(group, options, type) {
                  var mode = group.mode;
                  var text = group.text;
                  var classes = ["mord"];
                  var isFont = mode === "math" || mode === "text" && options.font;
                  var fontOrFamily = isFont ? options.font : options.fontFamily;
                  if (text.charCodeAt(0) === 55349) {
                    var _wideCharacterFont = wide_character_wideCharacterFont(text, mode), wideFontName = _wideCharacterFont[0], wideFontClass = _wideCharacterFont[1];
                    return buildCommon_makeSymbol(text, wideFontName, mode, options, classes.concat(wideFontClass));
                  } else if (fontOrFamily) {
                    var fontName;
                    var fontClasses;
                    if (fontOrFamily === "boldsymbol" || fontOrFamily === "mathnormal") {
                      var fontData = fontOrFamily === "boldsymbol" ? boldsymbol(text, mode, options, classes) : buildCommon_mathnormal(text, mode, options, classes);
                      fontName = fontData.fontName;
                      fontClasses = [fontData.fontClass];
                    } else if (utils.contains(mathitLetters, text)) {
                      fontName = "Main-Italic";
                      fontClasses = ["mathit"];
                    } else if (isFont) {
                      fontName = fontMap[fontOrFamily].fontName;
                      fontClasses = [fontOrFamily];
                    } else {
                      fontName = retrieveTextFontName(fontOrFamily, options.fontWeight, options.fontShape);
                      fontClasses = [fontOrFamily, options.fontWeight, options.fontShape];
                    }
                    if (buildCommon_lookupSymbol(text, fontName, mode).metrics) {
                      return buildCommon_makeSymbol(text, fontName, mode, options, classes.concat(fontClasses));
                    } else if (ligatures.hasOwnProperty(text) && fontName.substr(0, 10) === "Typewriter") {
                      var parts = [];
                      for (var i = 0; i < text.length; i++) {
                        parts.push(buildCommon_makeSymbol(text[i], fontName, mode, options, classes.concat(fontClasses)));
                      }
                      return buildCommon_makeFragment(parts);
                    }
                  }
                  if (type === "mathord") {
                    var fontLookup = buildCommon_mathdefault(text, mode, options, classes);
                    return buildCommon_makeSymbol(text, fontLookup.fontName, mode, options, classes.concat([fontLookup.fontClass]));
                  } else if (type === "textord") {
                    var font = src_symbols[mode][text] && src_symbols[mode][text].font;
                    if (font === "ams") {
                      var _fontName = retrieveTextFontName("amsrm", options.fontWeight, options.fontShape);
                      return buildCommon_makeSymbol(text, _fontName, mode, options, classes.concat("amsrm", options.fontWeight, options.fontShape));
                    } else if (font === "main" || !font) {
                      var _fontName2 = retrieveTextFontName("textrm", options.fontWeight, options.fontShape);
                      return buildCommon_makeSymbol(text, _fontName2, mode, options, classes.concat(options.fontWeight, options.fontShape));
                    } else {
                      var _fontName3 = retrieveTextFontName(font, options.fontWeight, options.fontShape);
                      return buildCommon_makeSymbol(text, _fontName3, mode, options, classes.concat(_fontName3, options.fontWeight, options.fontShape));
                    }
                  } else {
                    throw new Error("unexpected type: " + type + " in makeOrd");
                  }
                };
                var buildCommon_canCombine = function canCombine(prev, next) {
                  if (createClass(prev.classes) !== createClass(next.classes) || prev.skew !== next.skew || prev.maxFontSize !== next.maxFontSize) {
                    return false;
                  }
                  for (var style in prev.style) {
                    if (prev.style.hasOwnProperty(style) && prev.style[style] !== next.style[style]) {
                      return false;
                    }
                  }
                  for (var _style in next.style) {
                    if (next.style.hasOwnProperty(_style) && prev.style[_style] !== next.style[_style]) {
                      return false;
                    }
                  }
                  return true;
                };
                var buildCommon_tryCombineChars = function tryCombineChars(chars) {
                  for (var i = 0; i < chars.length - 1; i++) {
                    var prev = chars[i];
                    var next = chars[i + 1];
                    if (prev instanceof domTree_SymbolNode && next instanceof domTree_SymbolNode && buildCommon_canCombine(prev, next)) {
                      prev.text += next.text;
                      prev.height = Math.max(prev.height, next.height);
                      prev.depth = Math.max(prev.depth, next.depth);
                      prev.italic = next.italic;
                      chars.splice(i + 1, 1);
                      i--;
                    }
                  }
                  return chars;
                };
                var sizeElementFromChildren = function sizeElementFromChildren2(elem) {
                  var height = 0;
                  var depth = 0;
                  var maxFontSize = 0;
                  for (var i = 0; i < elem.children.length; i++) {
                    var child = elem.children[i];
                    if (child.height > height) {
                      height = child.height;
                    }
                    if (child.depth > depth) {
                      depth = child.depth;
                    }
                    if (child.maxFontSize > maxFontSize) {
                      maxFontSize = child.maxFontSize;
                    }
                  }
                  elem.height = height;
                  elem.depth = depth;
                  elem.maxFontSize = maxFontSize;
                };
                var buildCommon_makeSpan = function makeSpan(classes, children, options, style) {
                  var span = new domTree_Span(classes, children, options, style);
                  sizeElementFromChildren(span);
                  return span;
                };
                var buildCommon_makeSvgSpan = function makeSvgSpan(classes, children, options, style) {
                  return new domTree_Span(classes, children, options, style);
                };
                var makeLineSpan = function makeLineSpan2(className, options, thickness) {
                  var line = buildCommon_makeSpan([className], [], options);
                  line.height = thickness || options.fontMetrics().defaultRuleThickness;
                  line.style.borderBottomWidth = line.height + "em";
                  line.maxFontSize = 1;
                  return line;
                };
                var buildCommon_makeAnchor = function makeAnchor(href, classes, children, options) {
                  var anchor = new domTree_Anchor(href, classes, children, options);
                  sizeElementFromChildren(anchor);
                  return anchor;
                };
                var buildCommon_makeFragment = function makeFragment(children) {
                  var fragment = new tree_DocumentFragment(children);
                  sizeElementFromChildren(fragment);
                  return fragment;
                };
                var buildCommon_wrapFragment = function wrapFragment(group, options) {
                  if (group instanceof tree_DocumentFragment) {
                    return buildCommon_makeSpan([], [group], options);
                  }
                  return group;
                };
                var getVListChildrenAndDepth = function getVListChildrenAndDepth2(params) {
                  if (params.positionType === "individualShift") {
                    var oldChildren = params.children;
                    var children = [oldChildren[0]];
                    var _depth = -oldChildren[0].shift - oldChildren[0].elem.depth;
                    var currPos = _depth;
                    for (var i = 1; i < oldChildren.length; i++) {
                      var diff = -oldChildren[i].shift - currPos - oldChildren[i].elem.depth;
                      var size = diff - (oldChildren[i - 1].elem.height + oldChildren[i - 1].elem.depth);
                      currPos = currPos + diff;
                      children.push({
                        type: "kern",
                        size
                      });
                      children.push(oldChildren[i]);
                    }
                    return {
                      children,
                      depth: _depth
                    };
                  }
                  var depth;
                  if (params.positionType === "top") {
                    var bottom = params.positionData;
                    for (var _i = 0; _i < params.children.length; _i++) {
                      var child = params.children[_i];
                      bottom -= child.type === "kern" ? child.size : child.elem.height + child.elem.depth;
                    }
                    depth = bottom;
                  } else if (params.positionType === "bottom") {
                    depth = -params.positionData;
                  } else {
                    var firstChild = params.children[0];
                    if (firstChild.type !== "elem") {
                      throw new Error('First child must have type "elem".');
                    }
                    if (params.positionType === "shift") {
                      depth = -firstChild.elem.depth - params.positionData;
                    } else if (params.positionType === "firstBaseline") {
                      depth = -firstChild.elem.depth;
                    } else {
                      throw new Error("Invalid positionType " + params.positionType + ".");
                    }
                  }
                  return {
                    children: params.children,
                    depth
                  };
                };
                var buildCommon_makeVList = function makeVList(params, options) {
                  var _getVListChildrenAndD = getVListChildrenAndDepth(params), children = _getVListChildrenAndD.children, depth = _getVListChildrenAndD.depth;
                  var pstrutSize = 0;
                  for (var i = 0; i < children.length; i++) {
                    var child = children[i];
                    if (child.type === "elem") {
                      var elem = child.elem;
                      pstrutSize = Math.max(pstrutSize, elem.maxFontSize, elem.height);
                    }
                  }
                  pstrutSize += 2;
                  var pstrut = buildCommon_makeSpan(["pstrut"], []);
                  pstrut.style.height = pstrutSize + "em";
                  var realChildren = [];
                  var minPos = depth;
                  var maxPos = depth;
                  var currPos = depth;
                  for (var _i2 = 0; _i2 < children.length; _i2++) {
                    var _child = children[_i2];
                    if (_child.type === "kern") {
                      currPos += _child.size;
                    } else {
                      var _elem = _child.elem;
                      var classes = _child.wrapperClasses || [];
                      var style = _child.wrapperStyle || {};
                      var childWrap = buildCommon_makeSpan(classes, [pstrut, _elem], void 0, style);
                      childWrap.style.top = -pstrutSize - currPos - _elem.depth + "em";
                      if (_child.marginLeft) {
                        childWrap.style.marginLeft = _child.marginLeft;
                      }
                      if (_child.marginRight) {
                        childWrap.style.marginRight = _child.marginRight;
                      }
                      realChildren.push(childWrap);
                      currPos += _elem.height + _elem.depth;
                    }
                    minPos = Math.min(minPos, currPos);
                    maxPos = Math.max(maxPos, currPos);
                  }
                  var vlist = buildCommon_makeSpan(["vlist"], realChildren);
                  vlist.style.height = maxPos + "em";
                  var rows;
                  if (minPos < 0) {
                    var emptySpan = buildCommon_makeSpan([], []);
                    var depthStrut = buildCommon_makeSpan(["vlist"], [emptySpan]);
                    depthStrut.style.height = -minPos + "em";
                    var topStrut = buildCommon_makeSpan(["vlist-s"], [new domTree_SymbolNode("​")]);
                    rows = [buildCommon_makeSpan(["vlist-r"], [vlist, topStrut]), buildCommon_makeSpan(["vlist-r"], [depthStrut])];
                  } else {
                    rows = [buildCommon_makeSpan(["vlist-r"], [vlist])];
                  }
                  var vtable = buildCommon_makeSpan(["vlist-t"], rows);
                  if (rows.length === 2) {
                    vtable.classes.push("vlist-t2");
                  }
                  vtable.height = maxPos;
                  vtable.depth = -minPos;
                  return vtable;
                };
                var buildCommon_makeGlue = function makeGlue(measurement, options) {
                  var rule = buildCommon_makeSpan(["mspace"], [], options);
                  var size = units_calculateSize(measurement, options);
                  rule.style.marginRight = size + "em";
                  return rule;
                };
                var retrieveTextFontName = function retrieveTextFontName2(fontFamily, fontWeight, fontShape) {
                  var baseFontName = "";
                  switch (fontFamily) {
                    case "amsrm":
                      baseFontName = "AMS";
                      break;
                    case "textrm":
                      baseFontName = "Main";
                      break;
                    case "textsf":
                      baseFontName = "SansSerif";
                      break;
                    case "texttt":
                      baseFontName = "Typewriter";
                      break;
                    default:
                      baseFontName = fontFamily;
                  }
                  var fontStylesName;
                  if (fontWeight === "textbf" && fontShape === "textit") {
                    fontStylesName = "BoldItalic";
                  } else if (fontWeight === "textbf") {
                    fontStylesName = "Bold";
                  } else if (fontWeight === "textit") {
                    fontStylesName = "Italic";
                  } else {
                    fontStylesName = "Regular";
                  }
                  return baseFontName + "-" + fontStylesName;
                };
                var fontMap = {
                  // styles
                  "mathbf": {
                    variant: "bold",
                    fontName: "Main-Bold"
                  },
                  "mathrm": {
                    variant: "normal",
                    fontName: "Main-Regular"
                  },
                  "textit": {
                    variant: "italic",
                    fontName: "Main-Italic"
                  },
                  "mathit": {
                    variant: "italic",
                    fontName: "Main-Italic"
                  },
                  // Default math font, "mathnormal" and "boldsymbol" are missing because they
                  // require the use of several fonts: Main-Italic and Math-Italic for default
                  // math font, Main-Italic, Math-Italic, Caligraphic for "mathnormal", and
                  // Math-BoldItalic and Main-Bold for "boldsymbol".  This is handled by a
                  // special case in makeOrd which ends up calling mathdefault, mathnormal,
                  // and boldsymbol.
                  // families
                  "mathbb": {
                    variant: "double-struck",
                    fontName: "AMS-Regular"
                  },
                  "mathcal": {
                    variant: "script",
                    fontName: "Caligraphic-Regular"
                  },
                  "mathfrak": {
                    variant: "fraktur",
                    fontName: "Fraktur-Regular"
                  },
                  "mathscr": {
                    variant: "script",
                    fontName: "Script-Regular"
                  },
                  "mathsf": {
                    variant: "sans-serif",
                    fontName: "SansSerif-Regular"
                  },
                  "mathtt": {
                    variant: "monospace",
                    fontName: "Typewriter-Regular"
                  }
                };
                var svgData = {
                  //   path, width, height
                  vec: ["vec", 0.471, 0.714],
                  // values from the font glyph
                  oiintSize1: ["oiintSize1", 0.957, 0.499],
                  // oval to overlay the integrand
                  oiintSize2: ["oiintSize2", 1.472, 0.659],
                  oiiintSize1: ["oiiintSize1", 1.304, 0.499],
                  oiiintSize2: ["oiiintSize2", 1.98, 0.659]
                };
                var buildCommon_staticSvg = function staticSvg(value, options) {
                  var _svgData$value = svgData[value], pathName = _svgData$value[0], width = _svgData$value[1], height = _svgData$value[2];
                  var path = new domTree_PathNode(pathName);
                  var svgNode = new SvgNode([path], {
                    "width": width + "em",
                    "height": height + "em",
                    // Override CSS rule `.katex svg { width: 100% }`
                    "style": "width:" + width + "em",
                    "viewBox": "0 0 " + 1e3 * width + " " + 1e3 * height,
                    "preserveAspectRatio": "xMinYMin"
                  });
                  var span = buildCommon_makeSvgSpan(["overlay"], [svgNode], options);
                  span.height = height;
                  span.style.height = height + "em";
                  span.style.width = width + "em";
                  return span;
                };
                var buildCommon = {
                  fontMap,
                  makeSymbol: buildCommon_makeSymbol,
                  mathsym: buildCommon_mathsym,
                  makeSpan: buildCommon_makeSpan,
                  makeSvgSpan: buildCommon_makeSvgSpan,
                  makeLineSpan,
                  makeAnchor: buildCommon_makeAnchor,
                  makeFragment: buildCommon_makeFragment,
                  wrapFragment: buildCommon_wrapFragment,
                  makeVList: buildCommon_makeVList,
                  makeOrd: buildCommon_makeOrd,
                  makeGlue: buildCommon_makeGlue,
                  staticSvg: buildCommon_staticSvg,
                  svgData,
                  tryCombineChars: buildCommon_tryCombineChars
                };
                function assertNodeType(node, type) {
                  var typedNode = checkNodeType(node, type);
                  if (!typedNode) {
                    throw new Error("Expected node of type " + type + ", but got " + (node ? "node of type " + node.type : String(node)));
                  }
                  return typedNode;
                }
                function checkNodeType(node, type) {
                  if (node && node.type === type) {
                    return node;
                  }
                  return null;
                }
                function assertAtomFamily(node, family) {
                  var typedNode = checkAtomFamily(node, family);
                  if (!typedNode) {
                    throw new Error('Expected node of type "atom" and family "' + family + '", but got ' + (node ? node.type === "atom" ? "atom of family " + node.family : "node of type " + node.type : String(node)));
                  }
                  return typedNode;
                }
                function checkAtomFamily(node, family) {
                  return node && node.type === "atom" && node.family === family ? node : null;
                }
                function assertSymbolNodeType(node) {
                  var typedNode = checkSymbolNodeType(node);
                  if (!typedNode) {
                    throw new Error("Expected node of symbol group type, but got " + (node ? "node of type " + node.type : String(node)));
                  }
                  return typedNode;
                }
                function checkSymbolNodeType(node) {
                  if (node && (node.type === "atom" || NON_ATOMS.hasOwnProperty(node.type))) {
                    return node;
                  }
                  return null;
                }
                var thinspace = {
                  number: 3,
                  unit: "mu"
                };
                var mediumspace = {
                  number: 4,
                  unit: "mu"
                };
                var thickspace = {
                  number: 5,
                  unit: "mu"
                };
                var spacings = {
                  mord: {
                    mop: thinspace,
                    mbin: mediumspace,
                    mrel: thickspace,
                    minner: thinspace
                  },
                  mop: {
                    mord: thinspace,
                    mop: thinspace,
                    mrel: thickspace,
                    minner: thinspace
                  },
                  mbin: {
                    mord: mediumspace,
                    mop: mediumspace,
                    mopen: mediumspace,
                    minner: mediumspace
                  },
                  mrel: {
                    mord: thickspace,
                    mop: thickspace,
                    mopen: thickspace,
                    minner: thickspace
                  },
                  mopen: {},
                  mclose: {
                    mop: thinspace,
                    mbin: mediumspace,
                    mrel: thickspace,
                    minner: thinspace
                  },
                  mpunct: {
                    mord: thinspace,
                    mop: thinspace,
                    mrel: thickspace,
                    mopen: thinspace,
                    mclose: thinspace,
                    mpunct: thinspace,
                    minner: thinspace
                  },
                  minner: {
                    mord: thinspace,
                    mop: thinspace,
                    mbin: mediumspace,
                    mrel: thickspace,
                    mopen: thinspace,
                    mpunct: thinspace,
                    minner: thinspace
                  }
                };
                var tightSpacings = {
                  mord: {
                    mop: thinspace
                  },
                  mop: {
                    mord: thinspace,
                    mop: thinspace
                  },
                  mbin: {},
                  mrel: {},
                  mopen: {},
                  mclose: {
                    mop: thinspace
                  },
                  mpunct: {},
                  minner: {
                    mop: thinspace
                  }
                };
                var _functions = {};
                var _htmlGroupBuilders = {};
                var _mathmlGroupBuilders = {};
                function defineFunction(_ref) {
                  var type = _ref.type, nodeType = _ref.nodeType, names = _ref.names, props = _ref.props, handler = _ref.handler, htmlBuilder = _ref.htmlBuilder, mathmlBuilder = _ref.mathmlBuilder;
                  var data = {
                    type,
                    numArgs: props.numArgs,
                    argTypes: props.argTypes,
                    greediness: props.greediness === void 0 ? 1 : props.greediness,
                    allowedInText: !!props.allowedInText,
                    allowedInMath: props.allowedInMath === void 0 ? true : props.allowedInMath,
                    numOptionalArgs: props.numOptionalArgs || 0,
                    infix: !!props.infix,
                    consumeMode: props.consumeMode,
                    handler
                  };
                  for (var i = 0; i < names.length; ++i) {
                    _functions[names[i]] = data;
                  }
                  if (type) {
                    if (htmlBuilder) {
                      _htmlGroupBuilders[type] = htmlBuilder;
                    }
                    if (mathmlBuilder) {
                      _mathmlGroupBuilders[type] = mathmlBuilder;
                    }
                  }
                }
                function defineFunctionBuilders(_ref2) {
                  var type = _ref2.type, htmlBuilder = _ref2.htmlBuilder, mathmlBuilder = _ref2.mathmlBuilder;
                  defineFunction({
                    type,
                    names: [],
                    props: {
                      numArgs: 0
                    },
                    handler: function handler() {
                      throw new Error("Should never be called.");
                    },
                    htmlBuilder,
                    mathmlBuilder
                  });
                }
                var defineFunction_ordargument = function ordargument(arg) {
                  var node = checkNodeType(arg, "ordgroup");
                  return node ? node.body : [arg];
                };
                var buildHTML_makeSpan = buildCommon.makeSpan;
                var buildHTML_isBinLeftCanceller = function isBinLeftCanceller(node, isRealGroup) {
                  if (node) {
                    return utils.contains(["mbin", "mopen", "mrel", "mop", "mpunct"], getTypeOfDomTree(node, "right"));
                  } else {
                    return isRealGroup;
                  }
                };
                var buildHTML_isBinRightCanceller = function isBinRightCanceller(node, isRealGroup) {
                  if (node) {
                    return utils.contains(["mrel", "mclose", "mpunct"], getTypeOfDomTree(node, "left"));
                  } else {
                    return isRealGroup;
                  }
                };
                var buildHTML_styleMap = {
                  "display": src_Style.DISPLAY,
                  "text": src_Style.TEXT,
                  "script": src_Style.SCRIPT,
                  "scriptscript": src_Style.SCRIPTSCRIPT
                };
                var DomEnum = {
                  mord: "mord",
                  mop: "mop",
                  mbin: "mbin",
                  mrel: "mrel",
                  mopen: "mopen",
                  mclose: "mclose",
                  mpunct: "mpunct",
                  minner: "minner"
                };
                var buildHTML_buildExpression = function buildExpression(expression, options, isRealGroup, surrounding) {
                  if (surrounding === void 0) {
                    surrounding = [null, null];
                  }
                  var rawGroups = [];
                  for (var i = 0; i < expression.length; i++) {
                    var output = buildHTML_buildGroup(expression[i], options);
                    if (output instanceof tree_DocumentFragment) {
                      var children = output.children;
                      rawGroups.push.apply(rawGroups, children);
                    } else {
                      rawGroups.push(output);
                    }
                  }
                  var nonSpaces = [surrounding[0] ? buildHTML_makeSpan([surrounding[0]], [], options) : null].concat(rawGroups.filter(function(group) {
                    return group && group.classes[0] !== "mspace";
                  }), [surrounding[1] ? buildHTML_makeSpan([surrounding[1]], [], options) : null]);
                  for (var _i = 1; _i < nonSpaces.length - 1; _i++) {
                    var nonSpacesI = assert(nonSpaces[_i]);
                    var left = buildHTML_getOutermostNode(nonSpacesI, "left");
                    if (left.classes[0] === "mbin" && buildHTML_isBinLeftCanceller(nonSpaces[_i - 1], isRealGroup)) {
                      left.classes[0] = "mord";
                    }
                    var right = buildHTML_getOutermostNode(nonSpacesI, "right");
                    if (right.classes[0] === "mbin" && buildHTML_isBinRightCanceller(nonSpaces[_i + 1], isRealGroup)) {
                      right.classes[0] = "mord";
                    }
                  }
                  var groups = [];
                  var j = 0;
                  for (var _i2 = 0; _i2 < rawGroups.length; _i2++) {
                    groups.push(rawGroups[_i2]);
                    if (rawGroups[_i2].classes[0] !== "mspace" && j < nonSpaces.length - 1) {
                      if (j === 0) {
                        groups.pop();
                        _i2--;
                      }
                      var _left = getTypeOfDomTree(nonSpaces[j], "right");
                      var _right = getTypeOfDomTree(nonSpaces[j + 1], "left");
                      if (_left && _right && isRealGroup) {
                        var nonSpacesJp1 = assert(nonSpaces[j + 1]);
                        var space = isLeftTight(nonSpacesJp1) ? tightSpacings[_left][_right] : spacings[_left][_right];
                        if (space) {
                          var glueOptions = options;
                          if (expression.length === 1) {
                            var node = checkNodeType(expression[0], "sizing") || checkNodeType(expression[0], "styling");
                            if (!node) {
                            } else if (node.type === "sizing") {
                              glueOptions = options.havingSize(node.size);
                            } else if (node.type === "styling") {
                              glueOptions = options.havingStyle(buildHTML_styleMap[node.style]);
                            }
                          }
                          groups.push(buildCommon.makeGlue(space, glueOptions));
                        }
                      }
                      j++;
                    }
                  }
                  return groups;
                };
                var buildHTML_getOutermostNode = function getOutermostNode(node, side) {
                  if (node instanceof tree_DocumentFragment || node instanceof domTree_Anchor) {
                    var children = node.children;
                    if (children.length) {
                      if (side === "right") {
                        return getOutermostNode(children[children.length - 1], "right");
                      } else if (side === "left") {
                        return getOutermostNode(children[0], "right");
                      }
                    }
                  }
                  return node;
                };
                var getTypeOfDomTree = function getTypeOfDomTree2(node, side) {
                  if (!node) {
                    return null;
                  }
                  node = buildHTML_getOutermostNode(node, side);
                  return DomEnum[node.classes[0]] || null;
                };
                var isLeftTight = function isLeftTight2(node) {
                  node = buildHTML_getOutermostNode(node, "left");
                  return node.hasClass("mtight");
                };
                var makeNullDelimiter = function makeNullDelimiter2(options, classes) {
                  var moreClasses = ["nulldelimiter"].concat(options.baseSizingClasses());
                  return buildHTML_makeSpan(classes.concat(moreClasses));
                };
                var buildHTML_buildGroup = function buildGroup(group, options, baseOptions) {
                  if (!group) {
                    return buildHTML_makeSpan();
                  }
                  if (_htmlGroupBuilders[group.type]) {
                    var groupNode = _htmlGroupBuilders[group.type](group, options);
                    if (baseOptions && options.size !== baseOptions.size) {
                      groupNode = buildHTML_makeSpan(options.sizingClasses(baseOptions), [groupNode], options);
                      var multiplier = options.sizeMultiplier / baseOptions.sizeMultiplier;
                      groupNode.height *= multiplier;
                      groupNode.depth *= multiplier;
                    }
                    return groupNode;
                  } else {
                    throw new src_ParseError("Got group of unknown type: '" + group.type + "'");
                  }
                };
                function buildHTMLUnbreakable(children, options) {
                  var body = buildHTML_makeSpan(["base"], children, options);
                  var strut = buildHTML_makeSpan(["strut"]);
                  strut.style.height = body.height + body.depth + "em";
                  strut.style.verticalAlign = -body.depth + "em";
                  body.children.unshift(strut);
                  return body;
                }
                function buildHTML(tree, options) {
                  var tag = null;
                  if (tree.length === 1 && tree[0].type === "tag") {
                    tag = tree[0].tag;
                    tree = tree[0].body;
                  }
                  var expression = buildHTML_buildExpression(tree, options, true);
                  var children = [];
                  var parts = [];
                  for (var i = 0; i < expression.length; i++) {
                    parts.push(expression[i]);
                    if (expression[i].hasClass("mbin") || expression[i].hasClass("mrel") || expression[i].hasClass("allowbreak")) {
                      var nobreak = false;
                      while (i < expression.length - 1 && expression[i + 1].hasClass("mspace")) {
                        i++;
                        parts.push(expression[i]);
                        if (expression[i].hasClass("nobreak")) {
                          nobreak = true;
                        }
                      }
                      if (!nobreak) {
                        children.push(buildHTMLUnbreakable(parts, options));
                        parts = [];
                      }
                    } else if (expression[i].hasClass("newline")) {
                      parts.pop();
                      if (parts.length > 0) {
                        children.push(buildHTMLUnbreakable(parts, options));
                        parts = [];
                      }
                      children.push(expression[i]);
                    }
                  }
                  if (parts.length > 0) {
                    children.push(buildHTMLUnbreakable(parts, options));
                  }
                  var tagChild;
                  if (tag) {
                    tagChild = buildHTMLUnbreakable(buildHTML_buildExpression(tag, options, true));
                    tagChild.classes = ["tag"];
                    children.push(tagChild);
                  }
                  var htmlNode = buildHTML_makeSpan(["katex-html"], children);
                  htmlNode.setAttribute("aria-hidden", "true");
                  if (tagChild) {
                    var strut = tagChild.children[0];
                    strut.style.height = htmlNode.height + htmlNode.depth + "em";
                    strut.style.verticalAlign = -htmlNode.depth + "em";
                  }
                  return htmlNode;
                }
                function newDocumentFragment(children) {
                  return new tree_DocumentFragment(children);
                }
                var mathMLTree_MathNode = function() {
                  function MathNode(type, children) {
                    this.type = void 0;
                    this.attributes = void 0;
                    this.children = void 0;
                    this.type = type;
                    this.attributes = {};
                    this.children = children || [];
                  }
                  var _proto = MathNode.prototype;
                  _proto.setAttribute = function setAttribute(name, value) {
                    this.attributes[name] = value;
                  };
                  _proto.getAttribute = function getAttribute(name) {
                    return this.attributes[name];
                  };
                  _proto.toNode = function toNode() {
                    var node = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
                    for (var attr in this.attributes) {
                      if (Object.prototype.hasOwnProperty.call(this.attributes, attr)) {
                        node.setAttribute(attr, this.attributes[attr]);
                      }
                    }
                    for (var i = 0; i < this.children.length; i++) {
                      node.appendChild(this.children[i].toNode());
                    }
                    return node;
                  };
                  _proto.toMarkup = function toMarkup() {
                    var markup = "<" + this.type;
                    for (var attr in this.attributes) {
                      if (Object.prototype.hasOwnProperty.call(this.attributes, attr)) {
                        markup += " " + attr + '="';
                        markup += utils.escape(this.attributes[attr]);
                        markup += '"';
                      }
                    }
                    markup += ">";
                    for (var i = 0; i < this.children.length; i++) {
                      markup += this.children[i].toMarkup();
                    }
                    markup += "</" + this.type + ">";
                    return markup;
                  };
                  _proto.toText = function toText() {
                    return this.children.map(function(child) {
                      return child.toText();
                    }).join("");
                  };
                  return MathNode;
                }();
                var mathMLTree_TextNode = function() {
                  function TextNode(text, needsEscape) {
                    if (needsEscape === void 0) {
                      needsEscape = true;
                    }
                    this.text = void 0;
                    this.needsEscape = void 0;
                    this.text = text;
                    this.needsEscape = needsEscape;
                  }
                  var _proto2 = TextNode.prototype;
                  _proto2.toNode = function toNode() {
                    return document.createTextNode(this.toText());
                  };
                  _proto2.toMarkup = function toMarkup() {
                    return this.toText();
                  };
                  _proto2.toText = function toText() {
                    return this.needsEscape ? utils.escape(this.text) : this.text;
                  };
                  return TextNode;
                }();
                var SpaceNode = function() {
                  function SpaceNode2(width) {
                    this.width = void 0;
                    this.character = void 0;
                    this.width = width;
                    if (width >= 0.05555 && width <= 0.05556) {
                      this.character = "&VeryThinSpace;";
                    } else if (width >= 0.1666 && width <= 0.1667) {
                      this.character = "&ThinSpace;";
                    } else if (width >= 0.2222 && width <= 0.2223) {
                      this.character = "&MediumSpace;";
                    } else if (width >= 0.2777 && width <= 0.2778) {
                      this.character = "&ThickSpace;";
                    } else if (width >= -0.05556 && width <= -0.05555) {
                      this.character = "&NegativeVeryThinSpace;";
                    } else if (width >= -0.1667 && width <= -0.1666) {
                      this.character = "&NegativeThinSpace;";
                    } else if (width >= -0.2223 && width <= -0.2222) {
                      this.character = "&NegativeMediumSpace;";
                    } else if (width >= -0.2778 && width <= -0.2777) {
                      this.character = "&NegativeThickSpace;";
                    } else {
                      this.character = null;
                    }
                  }
                  var _proto3 = SpaceNode2.prototype;
                  _proto3.toNode = function toNode() {
                    if (this.character) {
                      return document.createTextNode(this.character);
                    } else {
                      var node = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
                      node.setAttribute("width", this.width + "em");
                      return node;
                    }
                  };
                  _proto3.toMarkup = function toMarkup() {
                    if (this.character) {
                      return "<mtext>" + this.character + "</mtext>";
                    } else {
                      return '<mspace width="' + this.width + 'em"/>';
                    }
                  };
                  _proto3.toText = function toText() {
                    if (this.character) {
                      return this.character;
                    } else {
                      return " ";
                    }
                  };
                  return SpaceNode2;
                }();
                var mathMLTree = {
                  MathNode: mathMLTree_MathNode,
                  TextNode: mathMLTree_TextNode,
                  SpaceNode,
                  newDocumentFragment
                };
                var buildMathML_makeText = function makeText(text, mode, options) {
                  if (src_symbols[mode][text] && src_symbols[mode][text].replace && text.charCodeAt(0) !== 55349 && !(ligatures.hasOwnProperty(text) && options && (options.fontFamily && options.fontFamily.substr(4, 2) === "tt" || options.font && options.font.substr(4, 2) === "tt"))) {
                    text = src_symbols[mode][text].replace;
                  }
                  return new mathMLTree.TextNode(text);
                };
                var buildMathML_makeRow = function makeRow(body) {
                  if (body.length === 1) {
                    return body[0];
                  } else {
                    return new mathMLTree.MathNode("mrow", body);
                  }
                };
                var buildMathML_getVariant = function getVariant(group, options) {
                  if (options.fontFamily === "texttt") {
                    return "monospace";
                  } else if (options.fontFamily === "textsf") {
                    if (options.fontShape === "textit" && options.fontWeight === "textbf") {
                      return "sans-serif-bold-italic";
                    } else if (options.fontShape === "textit") {
                      return "sans-serif-italic";
                    } else if (options.fontWeight === "textbf") {
                      return "bold-sans-serif";
                    } else {
                      return "sans-serif";
                    }
                  } else if (options.fontShape === "textit" && options.fontWeight === "textbf") {
                    return "bold-italic";
                  } else if (options.fontShape === "textit") {
                    return "italic";
                  } else if (options.fontWeight === "textbf") {
                    return "bold";
                  }
                  var font = options.font;
                  if (!font || font === "mathnormal") {
                    return null;
                  }
                  var mode = group.mode;
                  if (font === "mathit") {
                    return "italic";
                  } else if (font === "boldsymbol") {
                    return "bold-italic";
                  }
                  var text = group.text;
                  if (utils.contains(["\\imath", "\\jmath"], text)) {
                    return null;
                  }
                  if (src_symbols[mode][text] && src_symbols[mode][text].replace) {
                    text = src_symbols[mode][text].replace;
                  }
                  var fontName = buildCommon.fontMap[font].fontName;
                  if (getCharacterMetrics(text, fontName, mode)) {
                    return buildCommon.fontMap[font].variant;
                  }
                  return null;
                };
                var buildMathML_buildExpression = function buildExpression(expression, options) {
                  var groups = [];
                  var lastGroup;
                  for (var i = 0; i < expression.length; i++) {
                    var group = buildMathML_buildGroup(expression[i], options);
                    if (group instanceof mathMLTree_MathNode && lastGroup instanceof mathMLTree_MathNode) {
                      if (group.type === "mtext" && lastGroup.type === "mtext" && group.getAttribute("mathvariant") === lastGroup.getAttribute("mathvariant")) {
                        var _lastGroup$children;
                        (_lastGroup$children = lastGroup.children).push.apply(_lastGroup$children, group.children);
                        continue;
                      } else if (group.type === "mn" && lastGroup.type === "mn") {
                        var _lastGroup$children2;
                        (_lastGroup$children2 = lastGroup.children).push.apply(_lastGroup$children2, group.children);
                        continue;
                      } else if (group.type === "mi" && group.children.length === 1 && lastGroup.type === "mn") {
                        var child = group.children[0];
                        if (child instanceof mathMLTree_TextNode && child.text === ".") {
                          var _lastGroup$children3;
                          (_lastGroup$children3 = lastGroup.children).push.apply(_lastGroup$children3, group.children);
                          continue;
                        }
                      }
                    }
                    groups.push(group);
                    lastGroup = group;
                  }
                  return groups;
                };
                var buildExpressionRow = function buildExpressionRow2(expression, options) {
                  return buildMathML_makeRow(buildMathML_buildExpression(expression, options));
                };
                var buildMathML_buildGroup = function buildGroup(group, options) {
                  if (!group) {
                    return new mathMLTree.MathNode("mrow");
                  }
                  if (_mathmlGroupBuilders[group.type]) {
                    var result = _mathmlGroupBuilders[group.type](group, options);
                    return result;
                  } else {
                    throw new src_ParseError("Got group of unknown type: '" + group.type + "'");
                  }
                };
                function buildMathML(tree, texExpression, options) {
                  var expression = buildMathML_buildExpression(tree, options);
                  var wrapper;
                  if (expression.length === 1 && expression[0] instanceof mathMLTree_MathNode && utils.contains(["mrow", "mtable"], expression[0].type)) {
                    wrapper = expression[0];
                  } else {
                    wrapper = new mathMLTree.MathNode("mrow", expression);
                  }
                  var annotation = new mathMLTree.MathNode("annotation", [new mathMLTree.TextNode(texExpression)]);
                  annotation.setAttribute("encoding", "application/x-tex");
                  var semantics = new mathMLTree.MathNode("semantics", [wrapper, annotation]);
                  var math = new mathMLTree.MathNode("math", [semantics]);
                  return buildCommon.makeSpan(["katex-mathml"], [math]);
                }
                var buildTree_optionsFromSettings = function optionsFromSettings(settings) {
                  return new src_Options({
                    style: settings.displayMode ? src_Style.DISPLAY : src_Style.TEXT,
                    maxSize: settings.maxSize
                  });
                };
                var buildTree_buildTree = function buildTree(tree, expression, settings) {
                  var options = buildTree_optionsFromSettings(settings);
                  var mathMLNode = buildMathML(tree, expression, options);
                  var htmlNode = buildHTML(tree, options);
                  var katexNode = buildCommon.makeSpan(["katex"], [mathMLNode, htmlNode]);
                  if (settings.displayMode) {
                    return buildCommon.makeSpan(["katex-display"], [katexNode]);
                  } else {
                    return katexNode;
                  }
                };
                var buildTree_buildHTMLTree = function buildHTMLTree(tree, expression, settings) {
                  var options = buildTree_optionsFromSettings(settings);
                  var htmlNode = buildHTML(tree, options);
                  var katexNode = buildCommon.makeSpan(["katex"], [htmlNode]);
                  if (settings.displayMode) {
                    return buildCommon.makeSpan(["katex-display"], [katexNode]);
                  } else {
                    return katexNode;
                  }
                };
                var stretchyCodePoint = {
                  widehat: "^",
                  widecheck: "ˇ",
                  widetilde: "~",
                  utilde: "~",
                  overleftarrow: "←",
                  underleftarrow: "←",
                  xleftarrow: "←",
                  overrightarrow: "→",
                  underrightarrow: "→",
                  xrightarrow: "→",
                  underbrace: "⎵",
                  overbrace: "⏞",
                  overleftrightarrow: "↔",
                  underleftrightarrow: "↔",
                  xleftrightarrow: "↔",
                  Overrightarrow: "⇒",
                  xRightarrow: "⇒",
                  overleftharpoon: "↼",
                  xleftharpoonup: "↼",
                  overrightharpoon: "⇀",
                  xrightharpoonup: "⇀",
                  xLeftarrow: "⇐",
                  xLeftrightarrow: "⇔",
                  xhookleftarrow: "↩",
                  xhookrightarrow: "↪",
                  xmapsto: "↦",
                  xrightharpoondown: "⇁",
                  xleftharpoondown: "↽",
                  xrightleftharpoons: "⇌",
                  xleftrightharpoons: "⇋",
                  xtwoheadleftarrow: "↞",
                  xtwoheadrightarrow: "↠",
                  xlongequal: "=",
                  xtofrom: "⇄",
                  xrightleftarrows: "⇄",
                  xrightequilibrium: "⇌",
                  // Not a perfect match.
                  xleftequilibrium: "⇋"
                  // None better available.
                };
                var stretchy_mathMLnode = function mathMLnode(label) {
                  var node = new mathMLTree.MathNode("mo", [new mathMLTree.TextNode(stretchyCodePoint[label.substr(1)])]);
                  node.setAttribute("stretchy", "true");
                  return node;
                };
                var katexImagesData = {
                  //   path(s), minWidth, height, align
                  overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
                  overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
                  underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
                  underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
                  xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
                  xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
                  Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
                  xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
                  xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
                  overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
                  xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
                  xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
                  overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
                  xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
                  xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
                  xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
                  xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
                  xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
                  overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
                  overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
                  underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
                  underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
                  xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
                  xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
                  xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
                  xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
                  xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
                  xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
                  overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
                  underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
                  overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
                  undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
                  xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
                  xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
                  // The next three arrows are from the mhchem package.
                  // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
                  // document as \xrightarrow or \xrightleftharpoons. Those have
                  // min-length = 1.75em, so we set min-length on these next three to match.
                  xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
                  xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
                  xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
                };
                var groupLength = function groupLength2(arg) {
                  if (arg.type === "ordgroup") {
                    return arg.body.length;
                  } else {
                    return 1;
                  }
                };
                var stretchy_svgSpan = function svgSpan(group, options) {
                  function buildSvgSpan_() {
                    var viewBoxWidth = 4e5;
                    var label = group.label.substr(1);
                    if (utils.contains(["widehat", "widecheck", "widetilde", "utilde"], label)) {
                      var grp = group;
                      var numChars = groupLength(grp.base);
                      var viewBoxHeight;
                      var pathName;
                      var _height;
                      if (numChars > 5) {
                        if (label === "widehat" || label === "widecheck") {
                          viewBoxHeight = 420;
                          viewBoxWidth = 2364;
                          _height = 0.42;
                          pathName = label + "4";
                        } else {
                          viewBoxHeight = 312;
                          viewBoxWidth = 2340;
                          _height = 0.34;
                          pathName = "tilde4";
                        }
                      } else {
                        var imgIndex = [1, 1, 2, 2, 3, 3][numChars];
                        if (label === "widehat" || label === "widecheck") {
                          viewBoxWidth = [0, 1062, 2364, 2364, 2364][imgIndex];
                          viewBoxHeight = [0, 239, 300, 360, 420][imgIndex];
                          _height = [0, 0.24, 0.3, 0.3, 0.36, 0.42][imgIndex];
                          pathName = label + imgIndex;
                        } else {
                          viewBoxWidth = [0, 600, 1033, 2339, 2340][imgIndex];
                          viewBoxHeight = [0, 260, 286, 306, 312][imgIndex];
                          _height = [0, 0.26, 0.286, 0.3, 0.306, 0.34][imgIndex];
                          pathName = "tilde" + imgIndex;
                        }
                      }
                      var path = new domTree_PathNode(pathName);
                      var svgNode = new SvgNode([path], {
                        "width": "100%",
                        "height": _height + "em",
                        "viewBox": "0 0 " + viewBoxWidth + " " + viewBoxHeight,
                        "preserveAspectRatio": "none"
                      });
                      return {
                        span: buildCommon.makeSvgSpan([], [svgNode], options),
                        minWidth: 0,
                        height: _height
                      };
                    } else {
                      var spans = [];
                      var data = katexImagesData[label];
                      var paths = data[0], _minWidth = data[1], _viewBoxHeight = data[2];
                      var _height2 = _viewBoxHeight / 1e3;
                      var numSvgChildren = paths.length;
                      var widthClasses;
                      var aligns;
                      if (numSvgChildren === 1) {
                        var align1 = data[3];
                        widthClasses = ["hide-tail"];
                        aligns = [align1];
                      } else if (numSvgChildren === 2) {
                        widthClasses = ["halfarrow-left", "halfarrow-right"];
                        aligns = ["xMinYMin", "xMaxYMin"];
                      } else if (numSvgChildren === 3) {
                        widthClasses = ["brace-left", "brace-center", "brace-right"];
                        aligns = ["xMinYMin", "xMidYMin", "xMaxYMin"];
                      } else {
                        throw new Error("Correct katexImagesData or update code here to support\n                    " + numSvgChildren + " children.");
                      }
                      for (var i = 0; i < numSvgChildren; i++) {
                        var _path = new domTree_PathNode(paths[i]);
                        var _svgNode = new SvgNode([_path], {
                          "width": "400em",
                          "height": _height2 + "em",
                          "viewBox": "0 0 " + viewBoxWidth + " " + _viewBoxHeight,
                          "preserveAspectRatio": aligns[i] + " slice"
                        });
                        var _span = buildCommon.makeSvgSpan([widthClasses[i]], [_svgNode], options);
                        if (numSvgChildren === 1) {
                          return {
                            span: _span,
                            minWidth: _minWidth,
                            height: _height2
                          };
                        } else {
                          _span.style.height = _height2 + "em";
                          spans.push(_span);
                        }
                      }
                      return {
                        span: buildCommon.makeSpan(["stretchy"], spans, options),
                        minWidth: _minWidth,
                        height: _height2
                      };
                    }
                  }
                  var _buildSvgSpan_ = buildSvgSpan_(), span = _buildSvgSpan_.span, minWidth = _buildSvgSpan_.minWidth, height = _buildSvgSpan_.height;
                  span.height = height;
                  span.style.height = height + "em";
                  if (minWidth > 0) {
                    span.style.minWidth = minWidth + "em";
                  }
                  return span;
                };
                var stretchy_encloseSpan = function encloseSpan(inner, label, pad, options) {
                  var img;
                  var totalHeight = inner.height + inner.depth + 2 * pad;
                  if (/fbox|color/.test(label)) {
                    img = buildCommon.makeSpan(["stretchy", label], [], options);
                    if (label === "fbox") {
                      var color = options.color && options.getColor();
                      if (color) {
                        img.style.borderColor = color;
                      }
                    }
                  } else {
                    var lines = [];
                    if (/^[bx]cancel$/.test(label)) {
                      lines.push(new LineNode({
                        "x1": "0",
                        "y1": "0",
                        "x2": "100%",
                        "y2": "100%",
                        "stroke-width": "0.046em"
                      }));
                    }
                    if (/^x?cancel$/.test(label)) {
                      lines.push(new LineNode({
                        "x1": "0",
                        "y1": "100%",
                        "x2": "100%",
                        "y2": "0",
                        "stroke-width": "0.046em"
                      }));
                    }
                    var svgNode = new SvgNode(lines, {
                      "width": "100%",
                      "height": totalHeight + "em"
                    });
                    img = buildCommon.makeSvgSpan([], [svgNode], options);
                  }
                  img.height = totalHeight;
                  img.style.height = totalHeight + "em";
                  return img;
                };
                var stretchy = {
                  encloseSpan: stretchy_encloseSpan,
                  mathMLnode: stretchy_mathMLnode,
                  svgSpan: stretchy_svgSpan
                };
                var accent_htmlBuilder = function htmlBuilder(grp, options) {
                  var base;
                  var group;
                  var supSub = checkNodeType(grp, "supsub");
                  var supSubGroup;
                  if (supSub) {
                    group = assertNodeType(supSub.base, "accent");
                    base = group.base;
                    supSub.base = base;
                    supSubGroup = assertSpan(buildHTML_buildGroup(supSub, options));
                    supSub.base = group;
                  } else {
                    group = assertNodeType(grp, "accent");
                    base = group.base;
                  }
                  var body = buildHTML_buildGroup(base, options.havingCrampedStyle());
                  var mustShift = group.isShifty && utils.isCharacterBox(base);
                  var skew = 0;
                  if (mustShift) {
                    var baseChar = utils.getBaseElem(base);
                    var baseGroup = buildHTML_buildGroup(baseChar, options.havingCrampedStyle());
                    skew = assertSymbolDomNode(baseGroup).skew;
                  }
                  var clearance = Math.min(body.height, options.fontMetrics().xHeight);
                  var accentBody;
                  if (!group.isStretchy) {
                    var accent;
                    var width;
                    if (group.label === "\\vec") {
                      accent = buildCommon.staticSvg("vec", options);
                      width = buildCommon.svgData.vec[1];
                    } else {
                      accent = buildCommon.makeSymbol(group.label, "Main-Regular", group.mode, options);
                      accent.italic = 0;
                      width = accent.width;
                    }
                    accentBody = buildCommon.makeSpan(["accent-body"], [accent]);
                    var accentFull = group.label === "\\textcircled";
                    if (accentFull) {
                      accentBody.classes.push("accent-full");
                      clearance = body.height;
                    }
                    var left = skew;
                    if (!accentFull) {
                      left -= width / 2;
                    }
                    accentBody.style.left = left + "em";
                    if (group.label === "\\textcircled") {
                      accentBody.style.top = ".2em";
                    }
                    accentBody = buildCommon.makeVList({
                      positionType: "firstBaseline",
                      children: [{
                        type: "elem",
                        elem: body
                      }, {
                        type: "kern",
                        size: -clearance
                      }, {
                        type: "elem",
                        elem: accentBody
                      }]
                    }, options);
                  } else {
                    accentBody = stretchy.svgSpan(group, options);
                    accentBody = buildCommon.makeVList({
                      positionType: "firstBaseline",
                      children: [{
                        type: "elem",
                        elem: body
                      }, {
                        type: "elem",
                        elem: accentBody,
                        wrapperClasses: ["svg-align"],
                        wrapperStyle: skew > 0 ? {
                          width: "calc(100% - " + 2 * skew + "em)",
                          marginLeft: 2 * skew + "em"
                        } : void 0
                      }]
                    }, options);
                  }
                  var accentWrap = buildCommon.makeSpan(["mord", "accent"], [accentBody], options);
                  if (supSubGroup) {
                    supSubGroup.children[0] = accentWrap;
                    supSubGroup.height = Math.max(accentWrap.height, supSubGroup.height);
                    supSubGroup.classes[0] = "mord";
                    return supSubGroup;
                  } else {
                    return accentWrap;
                  }
                };
                var accent_mathmlBuilder = function mathmlBuilder(group, options) {
                  var accentNode = group.isStretchy ? stretchy.mathMLnode(group.label) : new mathMLTree.MathNode("mo", [buildMathML_makeText(group.label, group.mode)]);
                  var node = new mathMLTree.MathNode("mover", [buildMathML_buildGroup(group.base, options), accentNode]);
                  node.setAttribute("accent", "true");
                  return node;
                };
                var NON_STRETCHY_ACCENT_REGEX = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map(function(accent) {
                  return "\\" + accent;
                }).join("|"));
                defineFunction({
                  type: "accent",
                  names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(context, args) {
                    var base = args[0];
                    var isStretchy = !NON_STRETCHY_ACCENT_REGEX.test(context.funcName);
                    var isShifty = !isStretchy || context.funcName === "\\widehat" || context.funcName === "\\widetilde" || context.funcName === "\\widecheck";
                    return {
                      type: "accent",
                      mode: context.parser.mode,
                      label: context.funcName,
                      isStretchy,
                      isShifty,
                      base
                    };
                  },
                  htmlBuilder: accent_htmlBuilder,
                  mathmlBuilder: accent_mathmlBuilder
                });
                defineFunction({
                  type: "accent",
                  names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\r", "\\H", "\\v", "\\textcircled"],
                  props: {
                    numArgs: 1,
                    allowedInText: true,
                    allowedInMath: false
                  },
                  handler: function handler(context, args) {
                    var base = args[0];
                    return {
                      type: "accent",
                      mode: context.parser.mode,
                      label: context.funcName,
                      isStretchy: false,
                      isShifty: true,
                      base
                    };
                  },
                  htmlBuilder: accent_htmlBuilder,
                  mathmlBuilder: accent_mathmlBuilder
                });
                defineFunction({
                  type: "accentUnder",
                  names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    var base = args[0];
                    return {
                      type: "accentUnder",
                      mode: parser.mode,
                      label: funcName,
                      base
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var innerGroup = buildHTML_buildGroup(group.base, options);
                    var accentBody = stretchy.svgSpan(group, options);
                    var kern = group.label === "\\utilde" ? 0.12 : 0;
                    var vlist = buildCommon.makeVList({
                      positionType: "bottom",
                      positionData: accentBody.height + kern,
                      children: [{
                        type: "elem",
                        elem: accentBody,
                        wrapperClasses: ["svg-align"]
                      }, {
                        type: "kern",
                        size: kern
                      }, {
                        type: "elem",
                        elem: innerGroup
                      }]
                    }, options);
                    return buildCommon.makeSpan(["mord", "accentunder"], [vlist], options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var accentNode = stretchy.mathMLnode(group.label);
                    var node = new mathMLTree.MathNode("munder", [buildMathML_buildGroup(group.base, options), accentNode]);
                    node.setAttribute("accentunder", "true");
                    return node;
                  }
                });
                defineFunction({
                  type: "xArrow",
                  names: [
                    "\\xleftarrow",
                    "\\xrightarrow",
                    "\\xLeftarrow",
                    "\\xRightarrow",
                    "\\xleftrightarrow",
                    "\\xLeftrightarrow",
                    "\\xhookleftarrow",
                    "\\xhookrightarrow",
                    "\\xmapsto",
                    "\\xrightharpoondown",
                    "\\xrightharpoonup",
                    "\\xleftharpoondown",
                    "\\xleftharpoonup",
                    "\\xrightleftharpoons",
                    "\\xleftrightharpoons",
                    "\\xlongequal",
                    "\\xtwoheadrightarrow",
                    "\\xtwoheadleftarrow",
                    "\\xtofrom",
                    // The next 3 functions are here to support the mhchem extension.
                    // Direct use of these functions is discouraged and may break someday.
                    "\\xrightleftarrows",
                    "\\xrightequilibrium",
                    "\\xleftequilibrium"
                  ],
                  props: {
                    numArgs: 1,
                    numOptionalArgs: 1
                  },
                  handler: function handler(_ref, args, optArgs) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    return {
                      type: "xArrow",
                      mode: parser.mode,
                      label: funcName,
                      body: args[0],
                      below: optArgs[0]
                    };
                  },
                  // Flow is unable to correctly infer the type of `group`, even though it's
                  // unamibiguously determined from the passed-in `type` above.
                  htmlBuilder: function htmlBuilder(group, options) {
                    var style = options.style;
                    var newOptions = options.havingStyle(style.sup());
                    var upperGroup = buildCommon.wrapFragment(buildHTML_buildGroup(group.body, newOptions, options), options);
                    upperGroup.classes.push("x-arrow-pad");
                    var lowerGroup;
                    if (group.below) {
                      newOptions = options.havingStyle(style.sub());
                      lowerGroup = buildCommon.wrapFragment(buildHTML_buildGroup(group.below, newOptions, options), options);
                      lowerGroup.classes.push("x-arrow-pad");
                    }
                    var arrowBody = stretchy.svgSpan(group, options);
                    var arrowShift = -options.fontMetrics().axisHeight + 0.5 * arrowBody.height;
                    var upperShift = -options.fontMetrics().axisHeight - 0.5 * arrowBody.height - 0.111;
                    if (upperGroup.depth > 0.25 || group.label === "\\xleftequilibrium") {
                      upperShift -= upperGroup.depth;
                    }
                    var vlist;
                    if (lowerGroup) {
                      var lowerShift = -options.fontMetrics().axisHeight + lowerGroup.height + 0.5 * arrowBody.height + 0.111;
                      vlist = buildCommon.makeVList({
                        positionType: "individualShift",
                        children: [{
                          type: "elem",
                          elem: upperGroup,
                          shift: upperShift
                        }, {
                          type: "elem",
                          elem: arrowBody,
                          shift: arrowShift
                        }, {
                          type: "elem",
                          elem: lowerGroup,
                          shift: lowerShift
                        }]
                      }, options);
                    } else {
                      vlist = buildCommon.makeVList({
                        positionType: "individualShift",
                        children: [{
                          type: "elem",
                          elem: upperGroup,
                          shift: upperShift
                        }, {
                          type: "elem",
                          elem: arrowBody,
                          shift: arrowShift
                        }]
                      }, options);
                    }
                    vlist.children[0].children[0].children[1].classes.push("svg-align");
                    return buildCommon.makeSpan(["mrel", "x-arrow"], [vlist], options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var arrowNode = stretchy.mathMLnode(group.label);
                    var node;
                    var lowerNode;
                    if (group.body) {
                      var upperNode = buildMathML_buildGroup(group.body, options);
                      if (group.below) {
                        lowerNode = buildMathML_buildGroup(group.below, options);
                        node = new mathMLTree.MathNode("munderover", [arrowNode, lowerNode, upperNode]);
                      } else {
                        node = new mathMLTree.MathNode("mover", [arrowNode, upperNode]);
                      }
                    } else if (group.below) {
                      lowerNode = buildMathML_buildGroup(group.below, options);
                      node = new mathMLTree.MathNode("munder", [arrowNode, lowerNode]);
                    } else {
                      node = new mathMLTree.MathNode("mover", [arrowNode]);
                    }
                    return node;
                  }
                });
                defineFunction({
                  type: "textord",
                  names: ["\\@char"],
                  props: {
                    numArgs: 1,
                    allowedInText: true
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser;
                    var arg = assertNodeType(args[0], "ordgroup");
                    var group = arg.body;
                    var number = "";
                    for (var i = 0; i < group.length; i++) {
                      var node = assertNodeType(group[i], "textord");
                      number += node.text;
                    }
                    var code = parseInt(number);
                    if (isNaN(code)) {
                      throw new src_ParseError("\\@char has non-numeric argument " + number);
                    }
                    return {
                      type: "textord",
                      mode: parser.mode,
                      text: String.fromCharCode(code)
                    };
                  }
                });
                var color_htmlBuilder = function htmlBuilder(group, options) {
                  var elements = buildHTML_buildExpression(group.body, options.withColor(group.color), false);
                  return buildCommon.makeFragment(elements);
                };
                var color_mathmlBuilder = function mathmlBuilder(group, options) {
                  var inner = buildMathML_buildExpression(group.body, options);
                  var node = new mathMLTree.MathNode("mstyle", inner);
                  node.setAttribute("mathcolor", group.color);
                  return node;
                };
                defineFunction({
                  type: "color",
                  names: ["\\textcolor"],
                  props: {
                    numArgs: 2,
                    allowedInText: true,
                    greediness: 3,
                    argTypes: ["color", "original"]
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser;
                    var color = assertNodeType(args[0], "color-token").color;
                    var body = args[1];
                    return {
                      type: "color",
                      mode: parser.mode,
                      color,
                      body: defineFunction_ordargument(body)
                    };
                  },
                  htmlBuilder: color_htmlBuilder,
                  mathmlBuilder: color_mathmlBuilder
                });
                defineFunction({
                  type: "color",
                  names: ["\\blue", "\\orange", "\\pink", "\\red", "\\green", "\\gray", "\\purple", "\\blueA", "\\blueB", "\\blueC", "\\blueD", "\\blueE", "\\tealA", "\\tealB", "\\tealC", "\\tealD", "\\tealE", "\\greenA", "\\greenB", "\\greenC", "\\greenD", "\\greenE", "\\goldA", "\\goldB", "\\goldC", "\\goldD", "\\goldE", "\\redA", "\\redB", "\\redC", "\\redD", "\\redE", "\\maroonA", "\\maroonB", "\\maroonC", "\\maroonD", "\\maroonE", "\\purpleA", "\\purpleB", "\\purpleC", "\\purpleD", "\\purpleE", "\\mintA", "\\mintB", "\\mintC", "\\grayA", "\\grayB", "\\grayC", "\\grayD", "\\grayE", "\\grayF", "\\grayG", "\\grayH", "\\grayI", "\\kaBlue", "\\kaGreen"],
                  props: {
                    numArgs: 1,
                    allowedInText: true,
                    greediness: 3
                  },
                  handler: function handler(_ref2, args) {
                    var parser = _ref2.parser, funcName = _ref2.funcName;
                    var body = args[0];
                    return {
                      type: "color",
                      mode: parser.mode,
                      color: "katex-" + funcName.slice(1),
                      body: defineFunction_ordargument(body)
                    };
                  },
                  htmlBuilder: color_htmlBuilder,
                  mathmlBuilder: color_mathmlBuilder
                });
                defineFunction({
                  type: "color",
                  names: ["\\color"],
                  props: {
                    numArgs: 1,
                    allowedInText: true,
                    greediness: 3,
                    argTypes: ["color"]
                  },
                  handler: function handler(_ref3, args) {
                    var parser = _ref3.parser, breakOnTokenText = _ref3.breakOnTokenText;
                    var color = assertNodeType(args[0], "color-token").color;
                    var body = parser.parseExpression(true, breakOnTokenText);
                    return {
                      type: "color",
                      mode: parser.mode,
                      color,
                      body
                    };
                  },
                  htmlBuilder: color_htmlBuilder,
                  mathmlBuilder: color_mathmlBuilder
                });
                defineFunction({
                  type: "cr",
                  names: ["\\cr", "\\newline"],
                  props: {
                    numArgs: 0,
                    numOptionalArgs: 1,
                    argTypes: ["size"],
                    allowedInText: true
                  },
                  handler: function handler(_ref, args, optArgs) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    var size = optArgs[0];
                    var newRow = funcName === "\\cr";
                    var newLine = false;
                    if (!newRow) {
                      if (parser.settings.displayMode && parser.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode")) {
                        newLine = false;
                      } else {
                        newLine = true;
                      }
                    }
                    return {
                      type: "cr",
                      mode: parser.mode,
                      newLine,
                      newRow,
                      size: size && assertNodeType(size, "size").value
                    };
                  },
                  // The following builders are called only at the top level,
                  // not within tabular/array environments.
                  htmlBuilder: function htmlBuilder(group, options) {
                    if (group.newRow) {
                      throw new src_ParseError("\\cr valid only within a tabular/array environment");
                    }
                    var span = buildCommon.makeSpan(["mspace"], [], options);
                    if (group.newLine) {
                      span.classes.push("newline");
                      if (group.size) {
                        span.style.marginTop = units_calculateSize(group.size, options) + "em";
                      }
                    }
                    return span;
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var node = new mathMLTree.MathNode("mspace");
                    if (group.newLine) {
                      node.setAttribute("linebreak", "newline");
                      if (group.size) {
                        node.setAttribute("height", units_calculateSize(group.size, options) + "em");
                      }
                    }
                    return node;
                  }
                });
                var delimiter_getMetrics = function getMetrics(symbol, font, mode) {
                  var replace = src_symbols.math[symbol] && src_symbols.math[symbol].replace;
                  var metrics = getCharacterMetrics(replace || symbol, font, mode);
                  if (!metrics) {
                    throw new Error("Unsupported symbol " + symbol + " and font size " + font + ".");
                  }
                  return metrics;
                };
                var delimiter_styleWrap = function styleWrap(delim, toStyle, options, classes) {
                  var newOptions = options.havingBaseStyle(toStyle);
                  var span = buildCommon.makeSpan(classes.concat(newOptions.sizingClasses(options)), [delim], options);
                  var delimSizeMultiplier = newOptions.sizeMultiplier / options.sizeMultiplier;
                  span.height *= delimSizeMultiplier;
                  span.depth *= delimSizeMultiplier;
                  span.maxFontSize = newOptions.sizeMultiplier;
                  return span;
                };
                var centerSpan = function centerSpan2(span, options, style) {
                  var newOptions = options.havingBaseStyle(style);
                  var shift = (1 - options.sizeMultiplier / newOptions.sizeMultiplier) * options.fontMetrics().axisHeight;
                  span.classes.push("delimcenter");
                  span.style.top = shift + "em";
                  span.height -= shift;
                  span.depth += shift;
                };
                var delimiter_makeSmallDelim = function makeSmallDelim(delim, style, center, options, mode, classes) {
                  var text = buildCommon.makeSymbol(delim, "Main-Regular", mode, options);
                  var span = delimiter_styleWrap(text, style, options, classes);
                  if (center) {
                    centerSpan(span, options, style);
                  }
                  return span;
                };
                var delimiter_mathrmSize = function mathrmSize(value, size, mode, options) {
                  return buildCommon.makeSymbol(value, "Size" + size + "-Regular", mode, options);
                };
                var delimiter_makeLargeDelim = function makeLargeDelim(delim, size, center, options, mode, classes) {
                  var inner = delimiter_mathrmSize(delim, size, mode, options);
                  var span = delimiter_styleWrap(buildCommon.makeSpan(["delimsizing", "size" + size], [inner], options), src_Style.TEXT, options, classes);
                  if (center) {
                    centerSpan(span, options, src_Style.TEXT);
                  }
                  return span;
                };
                var delimiter_makeInner = function makeInner(symbol, font, mode) {
                  var sizeClass;
                  if (font === "Size1-Regular") {
                    sizeClass = "delim-size1";
                  } else {
                    sizeClass = "delim-size4";
                  }
                  var inner = buildCommon.makeSpan(["delimsizinginner", sizeClass], [buildCommon.makeSpan([], [buildCommon.makeSymbol(symbol, font, mode)])]);
                  return {
                    type: "elem",
                    elem: inner
                  };
                };
                var delimiter_makeStackedDelim = function makeStackedDelim(delim, heightTotal, center, options, mode, classes) {
                  var top;
                  var middle;
                  var repeat;
                  var bottom;
                  top = repeat = bottom = delim;
                  middle = null;
                  var font = "Size1-Regular";
                  if (delim === "\\uparrow") {
                    repeat = bottom = "⏐";
                  } else if (delim === "\\Uparrow") {
                    repeat = bottom = "‖";
                  } else if (delim === "\\downarrow") {
                    top = repeat = "⏐";
                  } else if (delim === "\\Downarrow") {
                    top = repeat = "‖";
                  } else if (delim === "\\updownarrow") {
                    top = "\\uparrow";
                    repeat = "⏐";
                    bottom = "\\downarrow";
                  } else if (delim === "\\Updownarrow") {
                    top = "\\Uparrow";
                    repeat = "‖";
                    bottom = "\\Downarrow";
                  } else if (delim === "[" || delim === "\\lbrack") {
                    top = "⎡";
                    repeat = "⎢";
                    bottom = "⎣";
                    font = "Size4-Regular";
                  } else if (delim === "]" || delim === "\\rbrack") {
                    top = "⎤";
                    repeat = "⎥";
                    bottom = "⎦";
                    font = "Size4-Regular";
                  } else if (delim === "\\lfloor" || delim === "⌊") {
                    repeat = top = "⎢";
                    bottom = "⎣";
                    font = "Size4-Regular";
                  } else if (delim === "\\lceil" || delim === "⌈") {
                    top = "⎡";
                    repeat = bottom = "⎢";
                    font = "Size4-Regular";
                  } else if (delim === "\\rfloor" || delim === "⌋") {
                    repeat = top = "⎥";
                    bottom = "⎦";
                    font = "Size4-Regular";
                  } else if (delim === "\\rceil" || delim === "⌉") {
                    top = "⎤";
                    repeat = bottom = "⎥";
                    font = "Size4-Regular";
                  } else if (delim === "(" || delim === "\\lparen") {
                    top = "⎛";
                    repeat = "⎜";
                    bottom = "⎝";
                    font = "Size4-Regular";
                  } else if (delim === ")" || delim === "\\rparen") {
                    top = "⎞";
                    repeat = "⎟";
                    bottom = "⎠";
                    font = "Size4-Regular";
                  } else if (delim === "\\{" || delim === "\\lbrace") {
                    top = "⎧";
                    middle = "⎨";
                    bottom = "⎩";
                    repeat = "⎪";
                    font = "Size4-Regular";
                  } else if (delim === "\\}" || delim === "\\rbrace") {
                    top = "⎫";
                    middle = "⎬";
                    bottom = "⎭";
                    repeat = "⎪";
                    font = "Size4-Regular";
                  } else if (delim === "\\lgroup" || delim === "⟮") {
                    top = "⎧";
                    bottom = "⎩";
                    repeat = "⎪";
                    font = "Size4-Regular";
                  } else if (delim === "\\rgroup" || delim === "⟯") {
                    top = "⎫";
                    bottom = "⎭";
                    repeat = "⎪";
                    font = "Size4-Regular";
                  } else if (delim === "\\lmoustache" || delim === "⎰") {
                    top = "⎧";
                    bottom = "⎭";
                    repeat = "⎪";
                    font = "Size4-Regular";
                  } else if (delim === "\\rmoustache" || delim === "⎱") {
                    top = "⎫";
                    bottom = "⎩";
                    repeat = "⎪";
                    font = "Size4-Regular";
                  }
                  var topMetrics = delimiter_getMetrics(top, font, mode);
                  var topHeightTotal = topMetrics.height + topMetrics.depth;
                  var repeatMetrics = delimiter_getMetrics(repeat, font, mode);
                  var repeatHeightTotal = repeatMetrics.height + repeatMetrics.depth;
                  var bottomMetrics = delimiter_getMetrics(bottom, font, mode);
                  var bottomHeightTotal = bottomMetrics.height + bottomMetrics.depth;
                  var middleHeightTotal = 0;
                  var middleFactor = 1;
                  if (middle !== null) {
                    var middleMetrics = delimiter_getMetrics(middle, font, mode);
                    middleHeightTotal = middleMetrics.height + middleMetrics.depth;
                    middleFactor = 2;
                  }
                  var minHeight = topHeightTotal + bottomHeightTotal + middleHeightTotal;
                  var repeatCount = Math.ceil((heightTotal - minHeight) / (middleFactor * repeatHeightTotal));
                  var realHeightTotal = minHeight + repeatCount * middleFactor * repeatHeightTotal;
                  var axisHeight = options.fontMetrics().axisHeight;
                  if (center) {
                    axisHeight *= options.sizeMultiplier;
                  }
                  var depth = realHeightTotal / 2 - axisHeight;
                  var inners = [];
                  inners.push(delimiter_makeInner(bottom, font, mode));
                  if (middle === null) {
                    for (var i = 0; i < repeatCount; i++) {
                      inners.push(delimiter_makeInner(repeat, font, mode));
                    }
                  } else {
                    for (var _i = 0; _i < repeatCount; _i++) {
                      inners.push(delimiter_makeInner(repeat, font, mode));
                    }
                    inners.push(delimiter_makeInner(middle, font, mode));
                    for (var _i2 = 0; _i2 < repeatCount; _i2++) {
                      inners.push(delimiter_makeInner(repeat, font, mode));
                    }
                  }
                  inners.push(delimiter_makeInner(top, font, mode));
                  var newOptions = options.havingBaseStyle(src_Style.TEXT);
                  var inner = buildCommon.makeVList({
                    positionType: "bottom",
                    positionData: depth,
                    children: inners
                  }, newOptions);
                  return delimiter_styleWrap(buildCommon.makeSpan(["delimsizing", "mult"], [inner], newOptions), src_Style.TEXT, options, classes);
                };
                var vbPad = 80;
                var emPad = 0.08;
                var delimiter_sqrtSvg = function sqrtSvg(sqrtName, height, viewBoxHeight, options) {
                  var alternate;
                  if (sqrtName === "sqrtTall") {
                    var vertSegment = viewBoxHeight - 54 - vbPad;
                    alternate = "M702 " + vbPad + "H400000v40H742v" + vertSegment + "l-4 4-4 4c-.667.7\n-2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1h-12l-28-84c-16.667-52-96.667\n-294.333-240-727l-212 -643 -85 170c-4-3.333-8.333-7.667-13 -13l-13-13l77-155\n 77-156c66 199.333 139 419.667 219 661 l218 661zM702 " + vbPad + "H400000v40H742z";
                  }
                  var pathNode = new domTree_PathNode(sqrtName, alternate);
                  var svg = new SvgNode([pathNode], {
                    // Note: 1000:1 ratio of viewBox to document em width.
                    "width": "400em",
                    "height": height + "em",
                    "viewBox": "0 0 400000 " + viewBoxHeight,
                    "preserveAspectRatio": "xMinYMin slice"
                  });
                  return buildCommon.makeSvgSpan(["hide-tail"], [svg], options);
                };
                var makeSqrtImage = function makeSqrtImage2(height, options) {
                  var newOptions = options.havingBaseSizing();
                  var delim = traverseSequence("\\surd", height * newOptions.sizeMultiplier, stackLargeDelimiterSequence, newOptions);
                  var sizeMultiplier = newOptions.sizeMultiplier;
                  var span;
                  var spanHeight = 0;
                  var texHeight = 0;
                  var viewBoxHeight = 0;
                  var advanceWidth;
                  if (delim.type === "small") {
                    viewBoxHeight = 1e3 + vbPad;
                    if (height < 1) {
                      sizeMultiplier = 1;
                    } else if (height < 1.4) {
                      sizeMultiplier = 0.7;
                    }
                    spanHeight = (1 + emPad) / sizeMultiplier;
                    texHeight = 1 / sizeMultiplier;
                    span = delimiter_sqrtSvg("sqrtMain", spanHeight, viewBoxHeight, options);
                    span.style.minWidth = "0.853em";
                    advanceWidth = 0.833 / sizeMultiplier;
                  } else if (delim.type === "large") {
                    viewBoxHeight = (1e3 + vbPad) * sizeToMaxHeight[delim.size];
                    texHeight = sizeToMaxHeight[delim.size] / sizeMultiplier;
                    spanHeight = (sizeToMaxHeight[delim.size] + emPad) / sizeMultiplier;
                    span = delimiter_sqrtSvg("sqrtSize" + delim.size, spanHeight, viewBoxHeight, options);
                    span.style.minWidth = "1.02em";
                    advanceWidth = 1 / sizeMultiplier;
                  } else {
                    spanHeight = height + emPad;
                    texHeight = height;
                    viewBoxHeight = Math.floor(1e3 * height) + vbPad;
                    span = delimiter_sqrtSvg("sqrtTall", spanHeight, viewBoxHeight, options);
                    span.style.minWidth = "0.742em";
                    advanceWidth = 1.056;
                  }
                  span.height = texHeight;
                  span.style.height = spanHeight + "em";
                  return {
                    span,
                    advanceWidth,
                    // Calculate the actual line width.
                    // This actually should depend on the chosen font -- e.g. \boldmath
                    // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
                    // have thicker rules.
                    ruleWidth: options.fontMetrics().sqrtRuleThickness * sizeMultiplier
                  };
                };
                var stackLargeDelimiters = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"];
                var stackAlwaysDelimiters = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"];
                var stackNeverDelimiters = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"];
                var sizeToMaxHeight = [0, 1.2, 1.8, 2.4, 3];
                var delimiter_makeSizedDelim = function makeSizedDelim(delim, size, options, mode, classes) {
                  if (delim === "<" || delim === "\\lt" || delim === "⟨") {
                    delim = "\\langle";
                  } else if (delim === ">" || delim === "\\gt" || delim === "⟩") {
                    delim = "\\rangle";
                  }
                  if (utils.contains(stackLargeDelimiters, delim) || utils.contains(stackNeverDelimiters, delim)) {
                    return delimiter_makeLargeDelim(delim, size, false, options, mode, classes);
                  } else if (utils.contains(stackAlwaysDelimiters, delim)) {
                    return delimiter_makeStackedDelim(delim, sizeToMaxHeight[size], false, options, mode, classes);
                  } else {
                    throw new src_ParseError("Illegal delimiter: '" + delim + "'");
                  }
                };
                var stackNeverDelimiterSequence = [{
                  type: "small",
                  style: src_Style.SCRIPTSCRIPT
                }, {
                  type: "small",
                  style: src_Style.SCRIPT
                }, {
                  type: "small",
                  style: src_Style.TEXT
                }, {
                  type: "large",
                  size: 1
                }, {
                  type: "large",
                  size: 2
                }, {
                  type: "large",
                  size: 3
                }, {
                  type: "large",
                  size: 4
                }];
                var stackAlwaysDelimiterSequence = [{
                  type: "small",
                  style: src_Style.SCRIPTSCRIPT
                }, {
                  type: "small",
                  style: src_Style.SCRIPT
                }, {
                  type: "small",
                  style: src_Style.TEXT
                }, {
                  type: "stack"
                }];
                var stackLargeDelimiterSequence = [{
                  type: "small",
                  style: src_Style.SCRIPTSCRIPT
                }, {
                  type: "small",
                  style: src_Style.SCRIPT
                }, {
                  type: "small",
                  style: src_Style.TEXT
                }, {
                  type: "large",
                  size: 1
                }, {
                  type: "large",
                  size: 2
                }, {
                  type: "large",
                  size: 3
                }, {
                  type: "large",
                  size: 4
                }, {
                  type: "stack"
                }];
                var delimTypeToFont = function delimTypeToFont2(type) {
                  if (type.type === "small") {
                    return "Main-Regular";
                  } else if (type.type === "large") {
                    return "Size" + type.size + "-Regular";
                  } else if (type.type === "stack") {
                    return "Size4-Regular";
                  } else {
                    throw new Error("Add support for delim type '" + type.type + "' here.");
                  }
                };
                var traverseSequence = function traverseSequence2(delim, height, sequence, options) {
                  var start = Math.min(2, 3 - options.style.size);
                  for (var i = start; i < sequence.length; i++) {
                    if (sequence[i].type === "stack") {
                      break;
                    }
                    var metrics = delimiter_getMetrics(delim, delimTypeToFont(sequence[i]), "math");
                    var heightDepth = metrics.height + metrics.depth;
                    if (sequence[i].type === "small") {
                      var newOptions = options.havingBaseStyle(sequence[i].style);
                      heightDepth *= newOptions.sizeMultiplier;
                    }
                    if (heightDepth > height) {
                      return sequence[i];
                    }
                  }
                  return sequence[sequence.length - 1];
                };
                var delimiter_makeCustomSizedDelim = function makeCustomSizedDelim(delim, height, center, options, mode, classes) {
                  if (delim === "<" || delim === "\\lt" || delim === "⟨") {
                    delim = "\\langle";
                  } else if (delim === ">" || delim === "\\gt" || delim === "⟩") {
                    delim = "\\rangle";
                  }
                  var sequence;
                  if (utils.contains(stackNeverDelimiters, delim)) {
                    sequence = stackNeverDelimiterSequence;
                  } else if (utils.contains(stackLargeDelimiters, delim)) {
                    sequence = stackLargeDelimiterSequence;
                  } else {
                    sequence = stackAlwaysDelimiterSequence;
                  }
                  var delimType = traverseSequence(delim, height, sequence, options);
                  if (delimType.type === "small") {
                    return delimiter_makeSmallDelim(delim, delimType.style, center, options, mode, classes);
                  } else if (delimType.type === "large") {
                    return delimiter_makeLargeDelim(delim, delimType.size, center, options, mode, classes);
                  } else {
                    return delimiter_makeStackedDelim(delim, height, center, options, mode, classes);
                  }
                };
                var makeLeftRightDelim = function makeLeftRightDelim2(delim, height, depth, options, mode, classes) {
                  var axisHeight = options.fontMetrics().axisHeight * options.sizeMultiplier;
                  var delimiterFactor = 901;
                  var delimiterExtend = 5 / options.fontMetrics().ptPerEm;
                  var maxDistFromAxis = Math.max(height - axisHeight, depth + axisHeight);
                  var totalHeight = Math.max(
                    // In real TeX, calculations are done using integral values which are
                    // 65536 per pt, or 655360 per em. So, the division here truncates in
                    // TeX but doesn't here, producing different results. If we wanted to
                    // exactly match TeX's calculation, we could do
                    //   Math.floor(655360 * maxDistFromAxis / 500) *
                    //    delimiterFactor / 655360
                    // (To see the difference, compare
                    //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
                    // in TeX and KaTeX)
                    maxDistFromAxis / 500 * delimiterFactor,
                    2 * maxDistFromAxis - delimiterExtend
                  );
                  return delimiter_makeCustomSizedDelim(delim, totalHeight, true, options, mode, classes);
                };
                var delimiter = {
                  sqrtImage: makeSqrtImage,
                  sizedDelim: delimiter_makeSizedDelim,
                  customSizedDelim: delimiter_makeCustomSizedDelim,
                  leftRightDelim: makeLeftRightDelim
                };
                var delimiterSizes = {
                  "\\bigl": {
                    mclass: "mopen",
                    size: 1
                  },
                  "\\Bigl": {
                    mclass: "mopen",
                    size: 2
                  },
                  "\\biggl": {
                    mclass: "mopen",
                    size: 3
                  },
                  "\\Biggl": {
                    mclass: "mopen",
                    size: 4
                  },
                  "\\bigr": {
                    mclass: "mclose",
                    size: 1
                  },
                  "\\Bigr": {
                    mclass: "mclose",
                    size: 2
                  },
                  "\\biggr": {
                    mclass: "mclose",
                    size: 3
                  },
                  "\\Biggr": {
                    mclass: "mclose",
                    size: 4
                  },
                  "\\bigm": {
                    mclass: "mrel",
                    size: 1
                  },
                  "\\Bigm": {
                    mclass: "mrel",
                    size: 2
                  },
                  "\\biggm": {
                    mclass: "mrel",
                    size: 3
                  },
                  "\\Biggm": {
                    mclass: "mrel",
                    size: 4
                  },
                  "\\big": {
                    mclass: "mord",
                    size: 1
                  },
                  "\\Big": {
                    mclass: "mord",
                    size: 2
                  },
                  "\\bigg": {
                    mclass: "mord",
                    size: 3
                  },
                  "\\Bigg": {
                    mclass: "mord",
                    size: 4
                  }
                };
                var delimiters = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
                function checkDelimiter(delim, context) {
                  var symDelim = checkSymbolNodeType(delim);
                  if (symDelim && utils.contains(delimiters, symDelim.text)) {
                    return symDelim;
                  } else {
                    throw new src_ParseError("Invalid delimiter: '" + (symDelim ? symDelim.text : JSON.stringify(delim)) + "' after '" + context.funcName + "'", delim);
                  }
                }
                defineFunction({
                  type: "delimsizing",
                  names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(context, args) {
                    var delim = checkDelimiter(args[0], context);
                    return {
                      type: "delimsizing",
                      mode: context.parser.mode,
                      size: delimiterSizes[context.funcName].size,
                      mclass: delimiterSizes[context.funcName].mclass,
                      delim: delim.text
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    if (group.delim === ".") {
                      return buildCommon.makeSpan([group.mclass]);
                    }
                    return delimiter.sizedDelim(group.delim, group.size, options, group.mode, [group.mclass]);
                  },
                  mathmlBuilder: function mathmlBuilder(group) {
                    var children = [];
                    if (group.delim !== ".") {
                      children.push(buildMathML_makeText(group.delim, group.mode));
                    }
                    var node = new mathMLTree.MathNode("mo", children);
                    if (group.mclass === "mopen" || group.mclass === "mclose") {
                      node.setAttribute("fence", "true");
                    } else {
                      node.setAttribute("fence", "false");
                    }
                    return node;
                  }
                });
                function assertParsed(group) {
                  if (!group.body) {
                    throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
                  }
                }
                defineFunction({
                  type: "leftright-right",
                  names: ["\\right"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(context, args) {
                    return {
                      type: "leftright-right",
                      mode: context.parser.mode,
                      delim: checkDelimiter(args[0], context).text
                    };
                  }
                });
                defineFunction({
                  type: "leftright",
                  names: ["\\left"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(context, args) {
                    var delim = checkDelimiter(args[0], context);
                    var parser = context.parser;
                    ++parser.leftrightDepth;
                    var body = parser.parseExpression(false);
                    --parser.leftrightDepth;
                    parser.expect("\\right", false);
                    var right = assertNodeType(parser.parseFunction(), "leftright-right");
                    return {
                      type: "leftright",
                      mode: parser.mode,
                      body,
                      left: delim.text,
                      right: right.delim
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    assertParsed(group);
                    var inner = buildHTML_buildExpression(group.body, options, true, [null, "mclose"]);
                    var innerHeight = 0;
                    var innerDepth = 0;
                    var hadMiddle = false;
                    for (var i = 0; i < inner.length; i++) {
                      if (inner[i].isMiddle) {
                        hadMiddle = true;
                      } else {
                        innerHeight = Math.max(inner[i].height, innerHeight);
                        innerDepth = Math.max(inner[i].depth, innerDepth);
                      }
                    }
                    innerHeight *= options.sizeMultiplier;
                    innerDepth *= options.sizeMultiplier;
                    var leftDelim;
                    if (group.left === ".") {
                      leftDelim = makeNullDelimiter(options, ["mopen"]);
                    } else {
                      leftDelim = delimiter.leftRightDelim(group.left, innerHeight, innerDepth, options, group.mode, ["mopen"]);
                    }
                    inner.unshift(leftDelim);
                    if (hadMiddle) {
                      for (var _i = 1; _i < inner.length; _i++) {
                        var middleDelim = inner[_i];
                        var isMiddle = middleDelim.isMiddle;
                        if (isMiddle) {
                          inner[_i] = delimiter.leftRightDelim(isMiddle.delim, innerHeight, innerDepth, isMiddle.options, group.mode, []);
                        }
                      }
                    }
                    var rightDelim;
                    if (group.right === ".") {
                      rightDelim = makeNullDelimiter(options, ["mclose"]);
                    } else {
                      rightDelim = delimiter.leftRightDelim(group.right, innerHeight, innerDepth, options, group.mode, ["mclose"]);
                    }
                    inner.push(rightDelim);
                    return buildCommon.makeSpan(["minner"], inner, options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    assertParsed(group);
                    var inner = buildMathML_buildExpression(group.body, options);
                    if (group.left !== ".") {
                      var leftNode = new mathMLTree.MathNode("mo", [buildMathML_makeText(group.left, group.mode)]);
                      leftNode.setAttribute("fence", "true");
                      inner.unshift(leftNode);
                    }
                    if (group.right !== ".") {
                      var rightNode = new mathMLTree.MathNode("mo", [buildMathML_makeText(group.right, group.mode)]);
                      rightNode.setAttribute("fence", "true");
                      inner.push(rightNode);
                    }
                    return buildMathML_makeRow(inner);
                  }
                });
                defineFunction({
                  type: "middle",
                  names: ["\\middle"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(context, args) {
                    var delim = checkDelimiter(args[0], context);
                    if (!context.parser.leftrightDepth) {
                      throw new src_ParseError("\\middle without preceding \\left", delim);
                    }
                    return {
                      type: "middle",
                      mode: context.parser.mode,
                      delim: delim.text
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var middleDelim;
                    if (group.delim === ".") {
                      middleDelim = makeNullDelimiter(options, []);
                    } else {
                      middleDelim = delimiter.sizedDelim(group.delim, 1, options, group.mode, []);
                      var isMiddle = {
                        delim: group.delim,
                        options
                      };
                      middleDelim.isMiddle = isMiddle;
                    }
                    return middleDelim;
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var middleNode = new mathMLTree.MathNode("mo", [buildMathML_makeText(group.delim, group.mode)]);
                    middleNode.setAttribute("fence", "true");
                    return middleNode;
                  }
                });
                var enclose_htmlBuilder = function htmlBuilder(group, options) {
                  var inner = buildCommon.wrapFragment(buildHTML_buildGroup(group.body, options), options);
                  var label = group.label.substr(1);
                  var scale = options.sizeMultiplier;
                  var img;
                  var imgShift = 0;
                  var isSingleChar = utils.isCharacterBox(group.body);
                  if (label === "sout") {
                    img = buildCommon.makeSpan(["stretchy", "sout"]);
                    img.height = options.fontMetrics().defaultRuleThickness / scale;
                    imgShift = -0.5 * options.fontMetrics().xHeight;
                  } else {
                    if (/cancel/.test(label)) {
                      if (!isSingleChar) {
                        inner.classes.push("cancel-pad");
                      }
                    } else {
                      inner.classes.push("boxpad");
                    }
                    var vertPad = 0;
                    if (/box/.test(label)) {
                      vertPad = label === "colorbox" ? 0.3 : 0.34;
                    } else {
                      vertPad = isSingleChar ? 0.2 : 0;
                    }
                    img = stretchy.encloseSpan(inner, label, vertPad, options);
                    imgShift = inner.depth + vertPad;
                    if (group.backgroundColor) {
                      img.style.backgroundColor = group.backgroundColor;
                      if (group.borderColor) {
                        img.style.borderColor = group.borderColor;
                      }
                    }
                  }
                  var vlist;
                  if (group.backgroundColor) {
                    vlist = buildCommon.makeVList({
                      positionType: "individualShift",
                      children: [
                        // Put the color background behind inner;
                        {
                          type: "elem",
                          elem: img,
                          shift: imgShift
                        },
                        {
                          type: "elem",
                          elem: inner,
                          shift: 0
                        }
                      ]
                    }, options);
                  } else {
                    vlist = buildCommon.makeVList({
                      positionType: "individualShift",
                      children: [
                        // Write the \cancel stroke on top of inner.
                        {
                          type: "elem",
                          elem: inner,
                          shift: 0
                        },
                        {
                          type: "elem",
                          elem: img,
                          shift: imgShift,
                          wrapperClasses: /cancel/.test(label) ? ["svg-align"] : []
                        }
                      ]
                    }, options);
                  }
                  if (/cancel/.test(label)) {
                    vlist.height = inner.height;
                    vlist.depth = inner.depth;
                  }
                  if (/cancel/.test(label) && !isSingleChar) {
                    return buildCommon.makeSpan(["mord", "cancel-lap"], [vlist], options);
                  } else {
                    return buildCommon.makeSpan(["mord"], [vlist], options);
                  }
                };
                var enclose_mathmlBuilder = function mathmlBuilder(group, options) {
                  var node = new mathMLTree.MathNode("menclose", [buildMathML_buildGroup(group.body, options)]);
                  switch (group.label) {
                    case "\\cancel":
                      node.setAttribute("notation", "updiagonalstrike");
                      break;
                    case "\\bcancel":
                      node.setAttribute("notation", "downdiagonalstrike");
                      break;
                    case "\\sout":
                      node.setAttribute("notation", "horizontalstrike");
                      break;
                    case "\\fbox":
                      node.setAttribute("notation", "box");
                      break;
                    case "\\fcolorbox":
                      node.setAttribute("notation", "box");
                      break;
                    case "\\xcancel":
                      node.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
                      break;
                  }
                  if (group.backgroundColor) {
                    node.setAttribute("mathbackground", group.backgroundColor);
                  }
                  return node;
                };
                defineFunction({
                  type: "enclose",
                  names: ["\\colorbox"],
                  props: {
                    numArgs: 2,
                    allowedInText: true,
                    greediness: 3,
                    argTypes: ["color", "text"]
                  },
                  handler: function handler(_ref, args, optArgs) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    var color = assertNodeType(args[0], "color-token").color;
                    var body = args[1];
                    return {
                      type: "enclose",
                      mode: parser.mode,
                      label: funcName,
                      backgroundColor: color,
                      body
                    };
                  },
                  htmlBuilder: enclose_htmlBuilder,
                  mathmlBuilder: enclose_mathmlBuilder
                });
                defineFunction({
                  type: "enclose",
                  names: ["\\fcolorbox"],
                  props: {
                    numArgs: 3,
                    allowedInText: true,
                    greediness: 3,
                    argTypes: ["color", "color", "text"]
                  },
                  handler: function handler(_ref2, args, optArgs) {
                    var parser = _ref2.parser, funcName = _ref2.funcName;
                    var borderColor = assertNodeType(args[0], "color-token").color;
                    var backgroundColor = assertNodeType(args[1], "color-token").color;
                    var body = args[2];
                    return {
                      type: "enclose",
                      mode: parser.mode,
                      label: funcName,
                      backgroundColor,
                      borderColor,
                      body
                    };
                  },
                  htmlBuilder: enclose_htmlBuilder,
                  mathmlBuilder: enclose_mathmlBuilder
                });
                defineFunction({
                  type: "enclose",
                  names: ["\\fbox"],
                  props: {
                    numArgs: 1,
                    argTypes: ["text"],
                    allowedInText: true
                  },
                  handler: function handler(_ref3, args) {
                    var parser = _ref3.parser;
                    return {
                      type: "enclose",
                      mode: parser.mode,
                      label: "\\fbox",
                      body: args[0]
                    };
                  }
                });
                defineFunction({
                  type: "enclose",
                  names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(_ref4, args, optArgs) {
                    var parser = _ref4.parser, funcName = _ref4.funcName;
                    var body = args[0];
                    return {
                      type: "enclose",
                      mode: parser.mode,
                      label: funcName,
                      body
                    };
                  },
                  htmlBuilder: enclose_htmlBuilder,
                  mathmlBuilder: enclose_mathmlBuilder
                });
                var _environments = {};
                function defineEnvironment(_ref) {
                  var type = _ref.type, names = _ref.names, props = _ref.props, handler = _ref.handler, htmlBuilder = _ref.htmlBuilder, mathmlBuilder = _ref.mathmlBuilder;
                  var data = {
                    type,
                    numArgs: props.numArgs || 0,
                    greediness: 1,
                    allowedInText: false,
                    numOptionalArgs: 0,
                    handler
                  };
                  for (var i = 0; i < names.length; ++i) {
                    _environments[names[i]] = data;
                  }
                  if (htmlBuilder) {
                    _htmlGroupBuilders[type] = htmlBuilder;
                  }
                  if (mathmlBuilder) {
                    _mathmlGroupBuilders[type] = mathmlBuilder;
                  }
                }
                function getHLines(parser) {
                  var hlineInfo = [];
                  parser.consumeSpaces();
                  var nxt = parser.nextToken.text;
                  while (nxt === "\\hline" || nxt === "\\hdashline") {
                    parser.consume();
                    hlineInfo.push(nxt === "\\hdashline");
                    parser.consumeSpaces();
                    nxt = parser.nextToken.text;
                  }
                  return hlineInfo;
                }
                function parseArray(parser, _ref, style) {
                  var hskipBeforeAndAfter = _ref.hskipBeforeAndAfter, addJot = _ref.addJot, cols = _ref.cols, arraystretch = _ref.arraystretch;
                  parser.gullet.beginGroup();
                  parser.gullet.macros.set("\\\\", "\\cr");
                  if (!arraystretch) {
                    var stretch = parser.gullet.expandMacroAsText("\\arraystretch");
                    if (stretch == null) {
                      arraystretch = 1;
                    } else {
                      arraystretch = parseFloat(stretch);
                      if (!arraystretch || arraystretch < 0) {
                        throw new src_ParseError("Invalid \\arraystretch: " + stretch);
                      }
                    }
                  }
                  var row = [];
                  var body = [row];
                  var rowGaps = [];
                  var hLinesBeforeRow = [];
                  hLinesBeforeRow.push(getHLines(parser));
                  while (true) {
                    var cell = parser.parseExpression(false, "\\cr");
                    cell = {
                      type: "ordgroup",
                      mode: parser.mode,
                      body: cell
                    };
                    if (style) {
                      cell = {
                        type: "styling",
                        mode: parser.mode,
                        style,
                        body: [cell]
                      };
                    }
                    row.push(cell);
                    var next = parser.nextToken.text;
                    if (next === "&") {
                      parser.consume();
                    } else if (next === "\\end") {
                      if (row.length === 1 && cell.type === "styling" && cell.body[0].body.length === 0) {
                        body.pop();
                      }
                      if (hLinesBeforeRow.length < body.length + 1) {
                        hLinesBeforeRow.push([]);
                      }
                      break;
                    } else if (next === "\\cr") {
                      var cr = assertNodeType(parser.parseFunction(), "cr");
                      rowGaps.push(cr.size);
                      hLinesBeforeRow.push(getHLines(parser));
                      row = [];
                      body.push(row);
                    } else {
                      throw new src_ParseError("Expected & or \\\\ or \\cr or \\end", parser.nextToken);
                    }
                  }
                  parser.gullet.endGroup();
                  return {
                    type: "array",
                    mode: parser.mode,
                    addJot,
                    arraystretch,
                    body,
                    cols,
                    rowGaps,
                    hskipBeforeAndAfter,
                    hLinesBeforeRow
                  };
                }
                function dCellStyle(envName) {
                  if (envName.substr(0, 1) === "d") {
                    return "display";
                  } else {
                    return "text";
                  }
                }
                var array_htmlBuilder = function htmlBuilder(group, options) {
                  var r;
                  var c;
                  var nr = group.body.length;
                  var hLinesBeforeRow = group.hLinesBeforeRow;
                  var nc = 0;
                  var body = new Array(nr);
                  var hlines = [];
                  var pt = 1 / options.fontMetrics().ptPerEm;
                  var arraycolsep = 5 * pt;
                  var baselineskip = 12 * pt;
                  var jot = 3 * pt;
                  var arrayskip = group.arraystretch * baselineskip;
                  var arstrutHeight = 0.7 * arrayskip;
                  var arstrutDepth = 0.3 * arrayskip;
                  var totalHeight = 0;
                  function setHLinePos(hlinesInGap) {
                    for (var i = 0; i < hlinesInGap.length; ++i) {
                      if (i > 0) {
                        totalHeight += 0.25;
                      }
                      hlines.push({
                        pos: totalHeight,
                        isDashed: hlinesInGap[i]
                      });
                    }
                  }
                  setHLinePos(hLinesBeforeRow[0]);
                  for (r = 0; r < group.body.length; ++r) {
                    var inrow = group.body[r];
                    var height = arstrutHeight;
                    var depth = arstrutDepth;
                    if (nc < inrow.length) {
                      nc = inrow.length;
                    }
                    var outrow = new Array(inrow.length);
                    for (c = 0; c < inrow.length; ++c) {
                      var elt = buildHTML_buildGroup(inrow[c], options);
                      if (depth < elt.depth) {
                        depth = elt.depth;
                      }
                      if (height < elt.height) {
                        height = elt.height;
                      }
                      outrow[c] = elt;
                    }
                    var rowGap = group.rowGaps[r];
                    var gap = 0;
                    if (rowGap) {
                      gap = units_calculateSize(rowGap, options);
                      if (gap > 0) {
                        gap += arstrutDepth;
                        if (depth < gap) {
                          depth = gap;
                        }
                        gap = 0;
                      }
                    }
                    if (group.addJot) {
                      depth += jot;
                    }
                    outrow.height = height;
                    outrow.depth = depth;
                    totalHeight += height;
                    outrow.pos = totalHeight;
                    totalHeight += depth + gap;
                    body[r] = outrow;
                    setHLinePos(hLinesBeforeRow[r + 1]);
                  }
                  var offset = totalHeight / 2 + options.fontMetrics().axisHeight;
                  var colDescriptions = group.cols || [];
                  var cols = [];
                  var colSep;
                  var colDescrNum;
                  for (
                    c = 0, colDescrNum = 0;
                    // Continue while either there are more columns or more column
                    // descriptions, so trailing separators don't get lost.
                    c < nc || colDescrNum < colDescriptions.length;
                    ++c, ++colDescrNum
                  ) {
                    var colDescr = colDescriptions[colDescrNum] || {};
                    var firstSeparator = true;
                    while (colDescr.type === "separator") {
                      if (!firstSeparator) {
                        colSep = buildCommon.makeSpan(["arraycolsep"], []);
                        colSep.style.width = options.fontMetrics().doubleRuleSep + "em";
                        cols.push(colSep);
                      }
                      if (colDescr.separator === "|") {
                        var separator = buildCommon.makeSpan(["vertical-separator"], [], options);
                        separator.style.height = totalHeight + "em";
                        separator.style.verticalAlign = -(totalHeight - offset) + "em";
                        cols.push(separator);
                      } else if (colDescr.separator === ":") {
                        var _separator = buildCommon.makeSpan(["vertical-separator", "vs-dashed"], [], options);
                        _separator.style.height = totalHeight + "em";
                        _separator.style.verticalAlign = -(totalHeight - offset) + "em";
                        cols.push(_separator);
                      } else {
                        throw new src_ParseError("Invalid separator type: " + colDescr.separator);
                      }
                      colDescrNum++;
                      colDescr = colDescriptions[colDescrNum] || {};
                      firstSeparator = false;
                    }
                    if (c >= nc) {
                      continue;
                    }
                    var sepwidth = void 0;
                    if (c > 0 || group.hskipBeforeAndAfter) {
                      sepwidth = utils.deflt(colDescr.pregap, arraycolsep);
                      if (sepwidth !== 0) {
                        colSep = buildCommon.makeSpan(["arraycolsep"], []);
                        colSep.style.width = sepwidth + "em";
                        cols.push(colSep);
                      }
                    }
                    var col = [];
                    for (r = 0; r < nr; ++r) {
                      var row = body[r];
                      var elem = row[c];
                      if (!elem) {
                        continue;
                      }
                      var shift = row.pos - offset;
                      elem.depth = row.depth;
                      elem.height = row.height;
                      col.push({
                        type: "elem",
                        elem,
                        shift
                      });
                    }
                    col = buildCommon.makeVList({
                      positionType: "individualShift",
                      children: col
                    }, options);
                    col = buildCommon.makeSpan(["col-align-" + (colDescr.align || "c")], [col]);
                    cols.push(col);
                    if (c < nc - 1 || group.hskipBeforeAndAfter) {
                      sepwidth = utils.deflt(colDescr.postgap, arraycolsep);
                      if (sepwidth !== 0) {
                        colSep = buildCommon.makeSpan(["arraycolsep"], []);
                        colSep.style.width = sepwidth + "em";
                        cols.push(colSep);
                      }
                    }
                  }
                  body = buildCommon.makeSpan(["mtable"], cols);
                  if (hlines.length > 0) {
                    var line = buildCommon.makeLineSpan("hline", options, 0.05);
                    var dashes = buildCommon.makeLineSpan("hdashline", options, 0.05);
                    var vListElems = [{
                      type: "elem",
                      elem: body,
                      shift: 0
                    }];
                    while (hlines.length > 0) {
                      var hline = hlines.pop();
                      var lineShift = hline.pos - offset;
                      if (hline.isDashed) {
                        vListElems.push({
                          type: "elem",
                          elem: dashes,
                          shift: lineShift
                        });
                      } else {
                        vListElems.push({
                          type: "elem",
                          elem: line,
                          shift: lineShift
                        });
                      }
                    }
                    body = buildCommon.makeVList({
                      positionType: "individualShift",
                      children: vListElems
                    }, options);
                  }
                  return buildCommon.makeSpan(["mord"], [body], options);
                };
                var array_mathmlBuilder = function mathmlBuilder(group, options) {
                  return new mathMLTree.MathNode("mtable", group.body.map(function(row) {
                    return new mathMLTree.MathNode("mtr", row.map(function(cell) {
                      return new mathMLTree.MathNode("mtd", [buildMathML_buildGroup(cell, options)]);
                    }));
                  }));
                };
                var array_alignedHandler = function alignedHandler(context, args) {
                  var cols = [];
                  var res = parseArray(context.parser, {
                    cols,
                    addJot: true
                  }, "display");
                  var numMaths;
                  var numCols = 0;
                  var emptyGroup = {
                    type: "ordgroup",
                    mode: context.mode,
                    body: []
                  };
                  var ordgroup = checkNodeType(args[0], "ordgroup");
                  if (ordgroup) {
                    var arg0 = "";
                    for (var i = 0; i < ordgroup.body.length; i++) {
                      var textord = assertNodeType(ordgroup.body[i], "textord");
                      arg0 += textord.text;
                    }
                    numMaths = Number(arg0);
                    numCols = numMaths * 2;
                  }
                  var isAligned = !numCols;
                  res.body.forEach(function(row) {
                    for (var _i = 1; _i < row.length; _i += 2) {
                      var styling = assertNodeType(row[_i], "styling");
                      var _ordgroup = assertNodeType(styling.body[0], "ordgroup");
                      _ordgroup.body.unshift(emptyGroup);
                    }
                    if (!isAligned) {
                      var curMaths = row.length / 2;
                      if (numMaths < curMaths) {
                        throw new src_ParseError("Too many math in a row: " + ("expected " + numMaths + ", but got " + curMaths), row[0]);
                      }
                    } else if (numCols < row.length) {
                      numCols = row.length;
                    }
                  });
                  for (var _i2 = 0; _i2 < numCols; ++_i2) {
                    var align = "r";
                    var pregap = 0;
                    if (_i2 % 2 === 1) {
                      align = "l";
                    } else if (_i2 > 0 && isAligned) {
                      pregap = 1;
                    }
                    cols[_i2] = {
                      type: "align",
                      align,
                      pregap,
                      postgap: 0
                    };
                  }
                  return res;
                };
                defineEnvironment({
                  type: "array",
                  names: ["array", "darray"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(context, args) {
                    var symNode = checkSymbolNodeType(args[0]);
                    var colalign = symNode ? [args[0]] : assertNodeType(args[0], "ordgroup").body;
                    var cols = colalign.map(function(nde) {
                      var node = assertSymbolNodeType(nde);
                      var ca = node.text;
                      if ("lcr".indexOf(ca) !== -1) {
                        return {
                          type: "align",
                          align: ca
                        };
                      } else if (ca === "|") {
                        return {
                          type: "separator",
                          separator: "|"
                        };
                      } else if (ca === ":") {
                        return {
                          type: "separator",
                          separator: ":"
                        };
                      }
                      throw new src_ParseError("Unknown column alignment: " + ca, nde);
                    });
                    var res = {
                      cols,
                      hskipBeforeAndAfter: true
                      // \@preamble in lttab.dtx
                    };
                    return parseArray(context.parser, res, dCellStyle(context.envName));
                  },
                  htmlBuilder: array_htmlBuilder,
                  mathmlBuilder: array_mathmlBuilder
                });
                defineEnvironment({
                  type: "array",
                  names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix"],
                  props: {
                    numArgs: 0
                  },
                  handler: function handler(context) {
                    var delimiters2 = {
                      "matrix": null,
                      "pmatrix": ["(", ")"],
                      "bmatrix": ["[", "]"],
                      "Bmatrix": ["\\{", "\\}"],
                      "vmatrix": ["|", "|"],
                      "Vmatrix": ["\\Vert", "\\Vert"]
                    }[context.envName];
                    var payload = {
                      hskipBeforeAndAfter: false
                    };
                    var res = parseArray(context.parser, payload, dCellStyle(context.envName));
                    return delimiters2 ? {
                      type: "leftright",
                      mode: context.mode,
                      body: [res],
                      left: delimiters2[0],
                      right: delimiters2[1]
                    } : res;
                  },
                  htmlBuilder: array_htmlBuilder,
                  mathmlBuilder: array_mathmlBuilder
                });
                defineEnvironment({
                  type: "array",
                  names: ["cases", "dcases"],
                  props: {
                    numArgs: 0
                  },
                  handler: function handler(context) {
                    var payload = {
                      arraystretch: 1.2,
                      cols: [{
                        type: "align",
                        align: "l",
                        pregap: 0,
                        // TODO(kevinb) get the current style.
                        // For now we use the metrics for TEXT style which is what we were
                        // doing before.  Before attempting to get the current style we
                        // should look at TeX's behavior especially for \over and matrices.
                        postgap: 1
                        /* 1em quad */
                      }, {
                        type: "align",
                        align: "l",
                        pregap: 0,
                        postgap: 0
                      }]
                    };
                    var res = parseArray(context.parser, payload, dCellStyle(context.envName));
                    return {
                      type: "leftright",
                      mode: context.mode,
                      body: [res],
                      left: "\\{",
                      right: "."
                    };
                  },
                  htmlBuilder: array_htmlBuilder,
                  mathmlBuilder: array_mathmlBuilder
                });
                defineEnvironment({
                  type: "array",
                  names: ["aligned"],
                  props: {
                    numArgs: 0
                  },
                  handler: array_alignedHandler,
                  htmlBuilder: array_htmlBuilder,
                  mathmlBuilder: array_mathmlBuilder
                });
                defineEnvironment({
                  type: "array",
                  names: ["gathered"],
                  props: {
                    numArgs: 0
                  },
                  handler: function handler(context) {
                    var res = {
                      cols: [{
                        type: "align",
                        align: "c"
                      }],
                      addJot: true
                    };
                    return parseArray(context.parser, res, "display");
                  },
                  htmlBuilder: array_htmlBuilder,
                  mathmlBuilder: array_mathmlBuilder
                });
                defineEnvironment({
                  type: "array",
                  names: ["alignedat"],
                  // One for numbered and for unnumbered;
                  // but, KaTeX doesn't supports math numbering yet,
                  // they make no difference for now.
                  props: {
                    numArgs: 1
                  },
                  handler: array_alignedHandler,
                  htmlBuilder: array_htmlBuilder,
                  mathmlBuilder: array_mathmlBuilder
                });
                defineFunction({
                  type: "text",
                  // Doesn't matter what this is.
                  names: ["\\hline", "\\hdashline"],
                  props: {
                    numArgs: 0,
                    allowedInText: true,
                    allowedInMath: true
                  },
                  handler: function handler(context, args) {
                    throw new src_ParseError(context.funcName + " valid only within array environment");
                  }
                });
                var environments = _environments;
                var src_environments = environments;
                defineFunction({
                  type: "environment",
                  names: ["\\begin", "\\end"],
                  props: {
                    numArgs: 1,
                    argTypes: ["text"]
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    var nameGroup = args[0];
                    if (nameGroup.type !== "ordgroup") {
                      throw new src_ParseError("Invalid environment name", nameGroup);
                    }
                    var envName = "";
                    for (var i = 0; i < nameGroup.body.length; ++i) {
                      envName += assertNodeType(nameGroup.body[i], "textord").text;
                    }
                    if (funcName === "\\begin") {
                      if (!src_environments.hasOwnProperty(envName)) {
                        throw new src_ParseError("No such environment: " + envName, nameGroup);
                      }
                      var env = src_environments[envName];
                      var _parser$parseArgument = parser.parseArguments("\\begin{" + envName + "}", env), _args = _parser$parseArgument.args, optArgs = _parser$parseArgument.optArgs;
                      var context = {
                        mode: parser.mode,
                        envName,
                        parser
                      };
                      var result = env.handler(context, _args, optArgs);
                      parser.expect("\\end", false);
                      var endNameToken = parser.nextToken;
                      var end = assertNodeType(parser.parseFunction(), "environment");
                      if (end.name !== envName) {
                        throw new src_ParseError("Mismatch: \\begin{" + envName + "} matched by \\end{" + end.name + "}", endNameToken);
                      }
                      return result;
                    }
                    return {
                      type: "environment",
                      mode: parser.mode,
                      name: envName,
                      nameGroup
                    };
                  }
                });
                var mclass_makeSpan = buildCommon.makeSpan;
                function mclass_htmlBuilder(group, options) {
                  var elements = buildHTML_buildExpression(group.body, options, true);
                  return mclass_makeSpan([group.mclass], elements, options);
                }
                function mclass_mathmlBuilder(group, options) {
                  var inner = buildMathML_buildExpression(group.body, options);
                  return mathMLTree.newDocumentFragment(inner);
                }
                defineFunction({
                  type: "mclass",
                  names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    var body = args[0];
                    return {
                      type: "mclass",
                      mode: parser.mode,
                      mclass: "m" + funcName.substr(5),
                      body: defineFunction_ordargument(body)
                    };
                  },
                  htmlBuilder: mclass_htmlBuilder,
                  mathmlBuilder: mclass_mathmlBuilder
                });
                var binrelClass = function binrelClass2(arg) {
                  var atom = arg.type === "ordgroup" && arg.body.length ? arg.body[0] : arg;
                  if (atom.type === "atom" && (atom.family === "bin" || atom.family === "rel")) {
                    return "m" + atom.family;
                  } else {
                    return "mord";
                  }
                };
                defineFunction({
                  type: "mclass",
                  names: ["\\@binrel"],
                  props: {
                    numArgs: 2
                  },
                  handler: function handler(_ref2, args) {
                    var parser = _ref2.parser;
                    return {
                      type: "mclass",
                      mode: parser.mode,
                      mclass: binrelClass(args[0]),
                      body: [args[1]]
                    };
                  }
                });
                defineFunction({
                  type: "mclass",
                  names: ["\\stackrel", "\\overset", "\\underset"],
                  props: {
                    numArgs: 2
                  },
                  handler: function handler(_ref3, args) {
                    var parser = _ref3.parser, funcName = _ref3.funcName;
                    var baseArg = args[1];
                    var shiftedArg = args[0];
                    var mclass;
                    if (funcName !== "\\stackrel") {
                      mclass = binrelClass(baseArg);
                    } else {
                      mclass = "mrel";
                    }
                    var baseOp = {
                      type: "op",
                      mode: baseArg.mode,
                      limits: true,
                      alwaysHandleSupSub: true,
                      symbol: false,
                      suppressBaseShift: funcName !== "\\stackrel",
                      body: defineFunction_ordargument(baseArg)
                    };
                    var supsub = {
                      type: "supsub",
                      mode: shiftedArg.mode,
                      base: baseOp,
                      sup: funcName === "\\underset" ? null : shiftedArg,
                      sub: funcName === "\\underset" ? shiftedArg : null
                    };
                    return {
                      type: "mclass",
                      mode: parser.mode,
                      mclass,
                      body: [supsub]
                    };
                  },
                  htmlBuilder: mclass_htmlBuilder,
                  mathmlBuilder: mclass_mathmlBuilder
                });
                var font_htmlBuilder = function htmlBuilder(group, options) {
                  var font = group.font;
                  var newOptions = options.withFont(font);
                  return buildHTML_buildGroup(group.body, newOptions);
                };
                var font_mathmlBuilder = function mathmlBuilder(group, options) {
                  var font = group.font;
                  var newOptions = options.withFont(font);
                  return buildMathML_buildGroup(group.body, newOptions);
                };
                var fontAliases = {
                  "\\Bbb": "\\mathbb",
                  "\\bold": "\\mathbf",
                  "\\frak": "\\mathfrak",
                  "\\bm": "\\boldsymbol"
                };
                defineFunction({
                  type: "font",
                  names: [
                    // styles, except \boldsymbol defined below
                    "\\mathrm",
                    "\\mathit",
                    "\\mathbf",
                    "\\mathnormal",
                    // families
                    "\\mathbb",
                    "\\mathcal",
                    "\\mathfrak",
                    "\\mathscr",
                    "\\mathsf",
                    "\\mathtt",
                    // aliases, except \bm defined below
                    "\\Bbb",
                    "\\bold",
                    "\\frak"
                  ],
                  props: {
                    numArgs: 1,
                    greediness: 2
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    var body = args[0];
                    var func = funcName;
                    if (func in fontAliases) {
                      func = fontAliases[func];
                    }
                    return {
                      type: "font",
                      mode: parser.mode,
                      font: func.slice(1),
                      body
                    };
                  },
                  htmlBuilder: font_htmlBuilder,
                  mathmlBuilder: font_mathmlBuilder
                });
                defineFunction({
                  type: "mclass",
                  names: ["\\boldsymbol", "\\bm"],
                  props: {
                    numArgs: 1,
                    greediness: 2
                  },
                  handler: function handler(_ref2, args) {
                    var parser = _ref2.parser;
                    var body = args[0];
                    return {
                      type: "mclass",
                      mode: parser.mode,
                      mclass: binrelClass(body),
                      body: [{
                        type: "font",
                        mode: parser.mode,
                        font: "boldsymbol",
                        body
                      }]
                    };
                  }
                });
                defineFunction({
                  type: "font",
                  names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it"],
                  props: {
                    numArgs: 0,
                    allowedInText: true
                  },
                  handler: function handler(_ref3, args) {
                    var parser = _ref3.parser, funcName = _ref3.funcName, breakOnTokenText = _ref3.breakOnTokenText;
                    var mode = parser.mode;
                    parser.consumeSpaces();
                    var body = parser.parseExpression(true, breakOnTokenText);
                    var style = "math" + funcName.slice(1);
                    return {
                      type: "font",
                      mode,
                      font: style,
                      body: {
                        type: "ordgroup",
                        mode: parser.mode,
                        body
                      }
                    };
                  },
                  htmlBuilder: font_htmlBuilder,
                  mathmlBuilder: font_mathmlBuilder
                });
                var genfrac_htmlBuilder = function htmlBuilder(group, options) {
                  var style = options.style;
                  if (group.size === "display") {
                    style = src_Style.DISPLAY;
                  } else if (group.size === "text" && style.size === src_Style.DISPLAY.size) {
                    style = src_Style.TEXT;
                  } else if (group.size === "script") {
                    style = src_Style.SCRIPT;
                  } else if (group.size === "scriptscript") {
                    style = src_Style.SCRIPTSCRIPT;
                  }
                  var nstyle = style.fracNum();
                  var dstyle = style.fracDen();
                  var newOptions;
                  newOptions = options.havingStyle(nstyle);
                  var numerm = buildHTML_buildGroup(group.numer, newOptions, options);
                  if (group.continued) {
                    var hStrut = 8.5 / options.fontMetrics().ptPerEm;
                    var dStrut = 3.5 / options.fontMetrics().ptPerEm;
                    numerm.height = numerm.height < hStrut ? hStrut : numerm.height;
                    numerm.depth = numerm.depth < dStrut ? dStrut : numerm.depth;
                  }
                  newOptions = options.havingStyle(dstyle);
                  var denomm = buildHTML_buildGroup(group.denom, newOptions, options);
                  var rule;
                  var ruleWidth;
                  var ruleSpacing;
                  if (group.hasBarLine) {
                    if (group.barSize) {
                      ruleWidth = units_calculateSize(group.barSize, options);
                      rule = buildCommon.makeLineSpan("frac-line", options, ruleWidth);
                    } else {
                      rule = buildCommon.makeLineSpan("frac-line", options);
                    }
                    ruleWidth = rule.height;
                    ruleSpacing = rule.height;
                  } else {
                    rule = null;
                    ruleWidth = 0;
                    ruleSpacing = options.fontMetrics().defaultRuleThickness;
                  }
                  var numShift;
                  var clearance;
                  var denomShift;
                  if (style.size === src_Style.DISPLAY.size) {
                    numShift = options.fontMetrics().num1;
                    if (ruleWidth > 0) {
                      clearance = 3 * ruleSpacing;
                    } else {
                      clearance = 7 * ruleSpacing;
                    }
                    denomShift = options.fontMetrics().denom1;
                  } else {
                    if (ruleWidth > 0) {
                      numShift = options.fontMetrics().num2;
                      clearance = ruleSpacing;
                    } else {
                      numShift = options.fontMetrics().num3;
                      clearance = 3 * ruleSpacing;
                    }
                    denomShift = options.fontMetrics().denom2;
                  }
                  var frac;
                  if (!rule) {
                    var candidateClearance = numShift - numerm.depth - (denomm.height - denomShift);
                    if (candidateClearance < clearance) {
                      numShift += 0.5 * (clearance - candidateClearance);
                      denomShift += 0.5 * (clearance - candidateClearance);
                    }
                    frac = buildCommon.makeVList({
                      positionType: "individualShift",
                      children: [{
                        type: "elem",
                        elem: denomm,
                        shift: denomShift
                      }, {
                        type: "elem",
                        elem: numerm,
                        shift: -numShift
                      }]
                    }, options);
                  } else {
                    var axisHeight = options.fontMetrics().axisHeight;
                    if (numShift - numerm.depth - (axisHeight + 0.5 * ruleWidth) < clearance) {
                      numShift += clearance - (numShift - numerm.depth - (axisHeight + 0.5 * ruleWidth));
                    }
                    if (axisHeight - 0.5 * ruleWidth - (denomm.height - denomShift) < clearance) {
                      denomShift += clearance - (axisHeight - 0.5 * ruleWidth - (denomm.height - denomShift));
                    }
                    var midShift = -(axisHeight - 0.5 * ruleWidth);
                    frac = buildCommon.makeVList({
                      positionType: "individualShift",
                      children: [{
                        type: "elem",
                        elem: denomm,
                        shift: denomShift
                      }, {
                        type: "elem",
                        elem: rule,
                        shift: midShift
                      }, {
                        type: "elem",
                        elem: numerm,
                        shift: -numShift
                      }]
                    }, options);
                  }
                  newOptions = options.havingStyle(style);
                  frac.height *= newOptions.sizeMultiplier / options.sizeMultiplier;
                  frac.depth *= newOptions.sizeMultiplier / options.sizeMultiplier;
                  var delimSize;
                  if (style.size === src_Style.DISPLAY.size) {
                    delimSize = options.fontMetrics().delim1;
                  } else {
                    delimSize = options.fontMetrics().delim2;
                  }
                  var leftDelim;
                  var rightDelim;
                  if (group.leftDelim == null) {
                    leftDelim = makeNullDelimiter(options, ["mopen"]);
                  } else {
                    leftDelim = delimiter.customSizedDelim(group.leftDelim, delimSize, true, options.havingStyle(style), group.mode, ["mopen"]);
                  }
                  if (group.continued) {
                    rightDelim = buildCommon.makeSpan([]);
                  } else if (group.rightDelim == null) {
                    rightDelim = makeNullDelimiter(options, ["mclose"]);
                  } else {
                    rightDelim = delimiter.customSizedDelim(group.rightDelim, delimSize, true, options.havingStyle(style), group.mode, ["mclose"]);
                  }
                  return buildCommon.makeSpan(["mord"].concat(newOptions.sizingClasses(options)), [leftDelim, buildCommon.makeSpan(["mfrac"], [frac]), rightDelim], options);
                };
                var genfrac_mathmlBuilder = function mathmlBuilder(group, options) {
                  var node = new mathMLTree.MathNode("mfrac", [buildMathML_buildGroup(group.numer, options), buildMathML_buildGroup(group.denom, options)]);
                  if (!group.hasBarLine) {
                    node.setAttribute("linethickness", "0px");
                  } else if (group.barSize) {
                    var ruleWidth = units_calculateSize(group.barSize, options);
                    node.setAttribute("linethickness", ruleWidth + "em");
                  }
                  if (group.leftDelim != null || group.rightDelim != null) {
                    var withDelims = [];
                    if (group.leftDelim != null) {
                      var leftOp = new mathMLTree.MathNode("mo", [new mathMLTree.TextNode(group.leftDelim)]);
                      leftOp.setAttribute("fence", "true");
                      withDelims.push(leftOp);
                    }
                    withDelims.push(node);
                    if (group.rightDelim != null) {
                      var rightOp = new mathMLTree.MathNode("mo", [new mathMLTree.TextNode(group.rightDelim)]);
                      rightOp.setAttribute("fence", "true");
                      withDelims.push(rightOp);
                    }
                    return buildMathML_makeRow(withDelims);
                  }
                  return node;
                };
                defineFunction({
                  type: "genfrac",
                  names: [
                    "\\cfrac",
                    "\\dfrac",
                    "\\frac",
                    "\\tfrac",
                    "\\dbinom",
                    "\\binom",
                    "\\tbinom",
                    "\\\\atopfrac",
                    // can’t be entered directly
                    "\\\\bracefrac",
                    "\\\\brackfrac"
                  ],
                  props: {
                    numArgs: 2,
                    greediness: 2
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    var numer = args[0];
                    var denom = args[1];
                    var hasBarLine;
                    var leftDelim = null;
                    var rightDelim = null;
                    var size = "auto";
                    switch (funcName) {
                      case "\\cfrac":
                      case "\\dfrac":
                      case "\\frac":
                      case "\\tfrac":
                        hasBarLine = true;
                        break;
                      case "\\\\atopfrac":
                        hasBarLine = false;
                        break;
                      case "\\dbinom":
                      case "\\binom":
                      case "\\tbinom":
                        hasBarLine = false;
                        leftDelim = "(";
                        rightDelim = ")";
                        break;
                      case "\\\\bracefrac":
                        hasBarLine = false;
                        leftDelim = "\\{";
                        rightDelim = "\\}";
                        break;
                      case "\\\\brackfrac":
                        hasBarLine = false;
                        leftDelim = "[";
                        rightDelim = "]";
                        break;
                      default:
                        throw new Error("Unrecognized genfrac command");
                    }
                    switch (funcName) {
                      case "\\cfrac":
                      case "\\dfrac":
                      case "\\dbinom":
                        size = "display";
                        break;
                      case "\\tfrac":
                      case "\\tbinom":
                        size = "text";
                        break;
                    }
                    return {
                      type: "genfrac",
                      mode: parser.mode,
                      continued: funcName === "\\cfrac",
                      numer,
                      denom,
                      hasBarLine,
                      leftDelim,
                      rightDelim,
                      size,
                      barSize: null
                    };
                  },
                  htmlBuilder: genfrac_htmlBuilder,
                  mathmlBuilder: genfrac_mathmlBuilder
                });
                defineFunction({
                  type: "infix",
                  names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
                  props: {
                    numArgs: 0,
                    infix: true
                  },
                  handler: function handler(_ref2) {
                    var parser = _ref2.parser, funcName = _ref2.funcName, token = _ref2.token;
                    var replaceWith;
                    switch (funcName) {
                      case "\\over":
                        replaceWith = "\\frac";
                        break;
                      case "\\choose":
                        replaceWith = "\\binom";
                        break;
                      case "\\atop":
                        replaceWith = "\\\\atopfrac";
                        break;
                      case "\\brace":
                        replaceWith = "\\\\bracefrac";
                        break;
                      case "\\brack":
                        replaceWith = "\\\\brackfrac";
                        break;
                      default:
                        throw new Error("Unrecognized infix genfrac command");
                    }
                    return {
                      type: "infix",
                      mode: parser.mode,
                      replaceWith,
                      token
                    };
                  }
                });
                var stylArray = ["display", "text", "script", "scriptscript"];
                var delimFromValue = function delimFromValue2(delimString) {
                  var delim = null;
                  if (delimString.length > 0) {
                    delim = delimString;
                    delim = delim === "." ? null : delim;
                  }
                  return delim;
                };
                defineFunction({
                  type: "genfrac",
                  names: ["\\genfrac"],
                  props: {
                    numArgs: 6,
                    greediness: 6,
                    argTypes: ["math", "math", "size", "text", "math", "math"]
                  },
                  handler: function handler(_ref3, args) {
                    var parser = _ref3.parser;
                    var numer = args[4];
                    var denom = args[5];
                    var leftNode = checkNodeType(args[0], "ordgroup");
                    if (leftNode) {
                      leftNode = assertAtomFamily(leftNode.body[0], "open");
                    } else {
                      leftNode = assertAtomFamily(args[0], "open");
                    }
                    var leftDelim = delimFromValue(leftNode.text);
                    var rightNode = checkNodeType(args[1], "ordgroup");
                    if (rightNode) {
                      rightNode = assertAtomFamily(rightNode.body[0], "close");
                    } else {
                      rightNode = assertAtomFamily(args[1], "close");
                    }
                    var rightDelim = delimFromValue(rightNode.text);
                    var barNode = assertNodeType(args[2], "size");
                    var hasBarLine;
                    var barSize = null;
                    if (barNode.isBlank) {
                      hasBarLine = true;
                    } else {
                      barSize = barNode.value;
                      hasBarLine = barSize.number > 0;
                    }
                    var size = "auto";
                    var styl = checkNodeType(args[3], "ordgroup");
                    if (styl) {
                      if (styl.body.length > 0) {
                        var textOrd = assertNodeType(styl.body[0], "textord");
                        size = stylArray[Number(textOrd.text)];
                      }
                    } else {
                      styl = assertNodeType(args[3], "textord");
                      size = stylArray[Number(styl.text)];
                    }
                    return {
                      type: "genfrac",
                      mode: parser.mode,
                      numer,
                      denom,
                      continued: false,
                      hasBarLine,
                      barSize,
                      leftDelim,
                      rightDelim,
                      size
                    };
                  },
                  htmlBuilder: genfrac_htmlBuilder,
                  mathmlBuilder: genfrac_mathmlBuilder
                });
                defineFunction({
                  type: "infix",
                  names: ["\\above"],
                  props: {
                    numArgs: 1,
                    argTypes: ["size"],
                    infix: true
                  },
                  handler: function handler(_ref4, args) {
                    var parser = _ref4.parser, funcName = _ref4.funcName, token = _ref4.token;
                    return {
                      type: "infix",
                      mode: parser.mode,
                      replaceWith: "\\\\abovefrac",
                      size: assertNodeType(args[0], "size").value,
                      token
                    };
                  }
                });
                defineFunction({
                  type: "genfrac",
                  names: ["\\\\abovefrac"],
                  props: {
                    numArgs: 3,
                    argTypes: ["math", "size", "math"]
                  },
                  handler: function handler(_ref5, args) {
                    var parser = _ref5.parser;
                    var numer = args[0];
                    var barSize = assert(assertNodeType(args[1], "infix").size);
                    var denom = args[2];
                    var hasBarLine = barSize.number > 0;
                    return {
                      type: "genfrac",
                      mode: parser.mode,
                      numer,
                      denom,
                      continued: false,
                      hasBarLine,
                      barSize,
                      leftDelim: null,
                      rightDelim: null,
                      size: "auto"
                    };
                  },
                  htmlBuilder: genfrac_htmlBuilder,
                  mathmlBuilder: genfrac_mathmlBuilder
                });
                var horizBrace_htmlBuilder = function htmlBuilder(grp, options) {
                  var style = options.style;
                  var supSubGroup;
                  var group;
                  var supSub = checkNodeType(grp, "supsub");
                  if (supSub) {
                    supSubGroup = supSub.sup ? buildHTML_buildGroup(supSub.sup, options.havingStyle(style.sup()), options) : buildHTML_buildGroup(supSub.sub, options.havingStyle(style.sub()), options);
                    group = assertNodeType(supSub.base, "horizBrace");
                  } else {
                    group = assertNodeType(grp, "horizBrace");
                  }
                  var body = buildHTML_buildGroup(group.base, options.havingBaseStyle(src_Style.DISPLAY));
                  var braceBody = stretchy.svgSpan(group, options);
                  var vlist;
                  if (group.isOver) {
                    vlist = buildCommon.makeVList({
                      positionType: "firstBaseline",
                      children: [{
                        type: "elem",
                        elem: body
                      }, {
                        type: "kern",
                        size: 0.1
                      }, {
                        type: "elem",
                        elem: braceBody
                      }]
                    }, options);
                    vlist.children[0].children[0].children[1].classes.push("svg-align");
                  } else {
                    vlist = buildCommon.makeVList({
                      positionType: "bottom",
                      positionData: body.depth + 0.1 + braceBody.height,
                      children: [{
                        type: "elem",
                        elem: braceBody
                      }, {
                        type: "kern",
                        size: 0.1
                      }, {
                        type: "elem",
                        elem: body
                      }]
                    }, options);
                    vlist.children[0].children[0].children[0].classes.push("svg-align");
                  }
                  if (supSubGroup) {
                    var vSpan = buildCommon.makeSpan(["mord", group.isOver ? "mover" : "munder"], [vlist], options);
                    if (group.isOver) {
                      vlist = buildCommon.makeVList({
                        positionType: "firstBaseline",
                        children: [{
                          type: "elem",
                          elem: vSpan
                        }, {
                          type: "kern",
                          size: 0.2
                        }, {
                          type: "elem",
                          elem: supSubGroup
                        }]
                      }, options);
                    } else {
                      vlist = buildCommon.makeVList({
                        positionType: "bottom",
                        positionData: vSpan.depth + 0.2 + supSubGroup.height + supSubGroup.depth,
                        children: [{
                          type: "elem",
                          elem: supSubGroup
                        }, {
                          type: "kern",
                          size: 0.2
                        }, {
                          type: "elem",
                          elem: vSpan
                        }]
                      }, options);
                    }
                  }
                  return buildCommon.makeSpan(["mord", group.isOver ? "mover" : "munder"], [vlist], options);
                };
                var horizBrace_mathmlBuilder = function mathmlBuilder(group, options) {
                  var accentNode = stretchy.mathMLnode(group.label);
                  return new mathMLTree.MathNode(group.isOver ? "mover" : "munder", [buildMathML_buildGroup(group.base, options), accentNode]);
                };
                defineFunction({
                  type: "horizBrace",
                  names: ["\\overbrace", "\\underbrace"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    return {
                      type: "horizBrace",
                      mode: parser.mode,
                      label: funcName,
                      isOver: /^\\over/.test(funcName),
                      base: args[0]
                    };
                  },
                  htmlBuilder: horizBrace_htmlBuilder,
                  mathmlBuilder: horizBrace_mathmlBuilder
                });
                defineFunction({
                  type: "href",
                  names: ["\\href"],
                  props: {
                    numArgs: 2,
                    argTypes: ["url", "original"],
                    allowedInText: true
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser;
                    var body = args[1];
                    var href = assertNodeType(args[0], "url").url;
                    return {
                      type: "href",
                      mode: parser.mode,
                      href,
                      body: defineFunction_ordargument(body)
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var elements = buildHTML_buildExpression(group.body, options, false);
                    return buildCommon.makeAnchor(group.href, [], elements, options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var math = buildExpressionRow(group.body, options);
                    if (!(math instanceof mathMLTree_MathNode)) {
                      math = new mathMLTree_MathNode("mrow", [math]);
                    }
                    math.setAttribute("href", group.href);
                    return math;
                  }
                });
                defineFunction({
                  type: "href",
                  names: ["\\url"],
                  props: {
                    numArgs: 1,
                    argTypes: ["url"],
                    allowedInText: true
                  },
                  handler: function handler(_ref2, args) {
                    var parser = _ref2.parser;
                    var href = assertNodeType(args[0], "url").url;
                    var chars = [];
                    for (var i = 0; i < href.length; i++) {
                      var c = href[i];
                      if (c === "~") {
                        c = "\\textasciitilde";
                      }
                      chars.push({
                        type: "textord",
                        mode: "text",
                        text: c
                      });
                    }
                    var body = {
                      type: "text",
                      mode: parser.mode,
                      font: "\\texttt",
                      body: chars
                    };
                    return {
                      type: "href",
                      mode: parser.mode,
                      href,
                      body: defineFunction_ordargument(body)
                    };
                  }
                });
                defineFunction({
                  type: "htmlmathml",
                  names: ["\\html@mathml"],
                  props: {
                    numArgs: 2,
                    allowedInText: true
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser;
                    return {
                      type: "htmlmathml",
                      mode: parser.mode,
                      html: defineFunction_ordargument(args[0]),
                      mathml: defineFunction_ordargument(args[1])
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var elements = buildHTML_buildExpression(group.html, options, false);
                    return buildCommon.makeFragment(elements);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    return buildExpressionRow(group.mathml, options);
                  }
                });
                defineFunction({
                  type: "kern",
                  names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
                  props: {
                    numArgs: 1,
                    argTypes: ["size"],
                    allowedInText: true
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    var size = assertNodeType(args[0], "size");
                    if (parser.settings.strict) {
                      var mathFunction = funcName[1] === "m";
                      var muUnit = size.value.unit === "mu";
                      if (mathFunction) {
                        if (!muUnit) {
                          parser.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + funcName + " supports only mu units, " + ("not " + size.value.unit + " units"));
                        }
                        if (parser.mode !== "math") {
                          parser.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + funcName + " works only in math mode");
                        }
                      } else {
                        if (muUnit) {
                          parser.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + funcName + " doesn't support mu units");
                        }
                      }
                    }
                    return {
                      type: "kern",
                      mode: parser.mode,
                      dimension: size.value
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    return buildCommon.makeGlue(group.dimension, options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var dimension = units_calculateSize(group.dimension, options);
                    return new mathMLTree.SpaceNode(dimension);
                  }
                });
                defineFunction({
                  type: "lap",
                  names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
                  props: {
                    numArgs: 1,
                    allowedInText: true
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    var body = args[0];
                    return {
                      type: "lap",
                      mode: parser.mode,
                      alignment: funcName.slice(5),
                      body
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var inner;
                    if (group.alignment === "clap") {
                      inner = buildCommon.makeSpan([], [buildHTML_buildGroup(group.body, options)]);
                      inner = buildCommon.makeSpan(["inner"], [inner], options);
                    } else {
                      inner = buildCommon.makeSpan(["inner"], [buildHTML_buildGroup(group.body, options)]);
                    }
                    var fix = buildCommon.makeSpan(["fix"], []);
                    var node = buildCommon.makeSpan([group.alignment], [inner, fix], options);
                    var strut = buildCommon.makeSpan(["strut"]);
                    strut.style.height = node.height + node.depth + "em";
                    strut.style.verticalAlign = -node.depth + "em";
                    node.children.unshift(strut);
                    node = buildCommon.makeVList({
                      positionType: "firstBaseline",
                      children: [{
                        type: "elem",
                        elem: node
                      }]
                    }, options);
                    return buildCommon.makeSpan(["mord"], [node], options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var node = new mathMLTree.MathNode("mpadded", [buildMathML_buildGroup(group.body, options)]);
                    if (group.alignment !== "rlap") {
                      var offset = group.alignment === "llap" ? "-1" : "-0.5";
                      node.setAttribute("lspace", offset + "width");
                    }
                    node.setAttribute("width", "0px");
                    return node;
                  }
                });
                defineFunction({
                  type: "styling",
                  names: ["\\(", "$"],
                  props: {
                    numArgs: 0,
                    allowedInText: true,
                    allowedInMath: false,
                    consumeMode: "math"
                  },
                  handler: function handler(_ref, args) {
                    var funcName = _ref.funcName, parser = _ref.parser;
                    var outerMode = parser.mode;
                    parser.switchMode("math");
                    var close = funcName === "\\(" ? "\\)" : "$";
                    var body = parser.parseExpression(false, close);
                    parser.expect(close, false);
                    parser.switchMode(outerMode);
                    parser.consume();
                    return {
                      type: "styling",
                      mode: parser.mode,
                      style: "text",
                      body
                    };
                  }
                });
                defineFunction({
                  type: "text",
                  // Doesn't matter what this is.
                  names: ["\\)", "\\]"],
                  props: {
                    numArgs: 0,
                    allowedInText: true,
                    allowedInMath: false
                  },
                  handler: function handler(context, args) {
                    throw new src_ParseError("Mismatched " + context.funcName);
                  }
                });
                var mathchoice_chooseMathStyle = function chooseMathStyle(group, options) {
                  switch (options.style.size) {
                    case src_Style.DISPLAY.size:
                      return group.display;
                    case src_Style.TEXT.size:
                      return group.text;
                    case src_Style.SCRIPT.size:
                      return group.script;
                    case src_Style.SCRIPTSCRIPT.size:
                      return group.scriptscript;
                    default:
                      return group.text;
                  }
                };
                defineFunction({
                  type: "mathchoice",
                  names: ["\\mathchoice"],
                  props: {
                    numArgs: 4
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser;
                    return {
                      type: "mathchoice",
                      mode: parser.mode,
                      display: defineFunction_ordargument(args[0]),
                      text: defineFunction_ordargument(args[1]),
                      script: defineFunction_ordargument(args[2]),
                      scriptscript: defineFunction_ordargument(args[3])
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var body = mathchoice_chooseMathStyle(group, options);
                    var elements = buildHTML_buildExpression(body, options, false);
                    return buildCommon.makeFragment(elements);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var body = mathchoice_chooseMathStyle(group, options);
                    return buildExpressionRow(body, options);
                  }
                });
                var op_htmlBuilder = function htmlBuilder(grp, options) {
                  var supGroup;
                  var subGroup;
                  var hasLimits = false;
                  var group;
                  var supSub = checkNodeType(grp, "supsub");
                  if (supSub) {
                    supGroup = supSub.sup;
                    subGroup = supSub.sub;
                    group = assertNodeType(supSub.base, "op");
                    hasLimits = true;
                  } else {
                    group = assertNodeType(grp, "op");
                  }
                  var style = options.style;
                  var noSuccessor = ["\\smallint"];
                  var large = false;
                  if (style.size === src_Style.DISPLAY.size && group.symbol && !utils.contains(noSuccessor, group.name)) {
                    large = true;
                  }
                  var base;
                  if (group.symbol) {
                    var fontName = large ? "Size2-Regular" : "Size1-Regular";
                    var stash = "";
                    if (group.name === "\\oiint" || group.name === "\\oiiint") {
                      stash = group.name.substr(1);
                      group.name = stash === "oiint" ? "\\iint" : "\\iiint";
                    }
                    base = buildCommon.makeSymbol(group.name, fontName, "math", options, ["mop", "op-symbol", large ? "large-op" : "small-op"]);
                    if (stash.length > 0) {
                      var italic = base.italic;
                      var oval = buildCommon.staticSvg(stash + "Size" + (large ? "2" : "1"), options);
                      base = buildCommon.makeVList({
                        positionType: "individualShift",
                        children: [{
                          type: "elem",
                          elem: base,
                          shift: 0
                        }, {
                          type: "elem",
                          elem: oval,
                          shift: large ? 0.08 : 0
                        }]
                      }, options);
                      group.name = "\\" + stash;
                      base.classes.unshift("mop");
                      base.italic = italic;
                    }
                  } else if (group.body) {
                    var inner = buildHTML_buildExpression(group.body, options, true);
                    if (inner.length === 1 && inner[0] instanceof domTree_SymbolNode) {
                      base = inner[0];
                      base.classes[0] = "mop";
                    } else {
                      base = buildCommon.makeSpan(["mop"], buildCommon.tryCombineChars(inner), options);
                    }
                  } else {
                    var output = [];
                    for (var i = 1; i < group.name.length; i++) {
                      output.push(buildCommon.mathsym(group.name[i], group.mode));
                    }
                    base = buildCommon.makeSpan(["mop"], output, options);
                  }
                  var baseShift = 0;
                  var slant = 0;
                  if ((base instanceof domTree_SymbolNode || group.name === "\\oiint" || group.name === "\\oiiint") && !group.suppressBaseShift) {
                    baseShift = (base.height - base.depth) / 2 - options.fontMetrics().axisHeight;
                    slant = base.italic;
                  }
                  if (hasLimits) {
                    base = buildCommon.makeSpan([], [base]);
                    var sub;
                    var sup;
                    if (supGroup) {
                      var elem = buildHTML_buildGroup(supGroup, options.havingStyle(style.sup()), options);
                      sup = {
                        elem,
                        kern: Math.max(options.fontMetrics().bigOpSpacing1, options.fontMetrics().bigOpSpacing3 - elem.depth)
                      };
                    }
                    if (subGroup) {
                      var _elem = buildHTML_buildGroup(subGroup, options.havingStyle(style.sub()), options);
                      sub = {
                        elem: _elem,
                        kern: Math.max(options.fontMetrics().bigOpSpacing2, options.fontMetrics().bigOpSpacing4 - _elem.height)
                      };
                    }
                    var finalGroup;
                    if (sup && sub) {
                      var bottom = options.fontMetrics().bigOpSpacing5 + sub.elem.height + sub.elem.depth + sub.kern + base.depth + baseShift;
                      finalGroup = buildCommon.makeVList({
                        positionType: "bottom",
                        positionData: bottom,
                        children: [{
                          type: "kern",
                          size: options.fontMetrics().bigOpSpacing5
                        }, {
                          type: "elem",
                          elem: sub.elem,
                          marginLeft: -slant + "em"
                        }, {
                          type: "kern",
                          size: sub.kern
                        }, {
                          type: "elem",
                          elem: base
                        }, {
                          type: "kern",
                          size: sup.kern
                        }, {
                          type: "elem",
                          elem: sup.elem,
                          marginLeft: slant + "em"
                        }, {
                          type: "kern",
                          size: options.fontMetrics().bigOpSpacing5
                        }]
                      }, options);
                    } else if (sub) {
                      var top = base.height - baseShift;
                      finalGroup = buildCommon.makeVList({
                        positionType: "top",
                        positionData: top,
                        children: [{
                          type: "kern",
                          size: options.fontMetrics().bigOpSpacing5
                        }, {
                          type: "elem",
                          elem: sub.elem,
                          marginLeft: -slant + "em"
                        }, {
                          type: "kern",
                          size: sub.kern
                        }, {
                          type: "elem",
                          elem: base
                        }]
                      }, options);
                    } else if (sup) {
                      var _bottom = base.depth + baseShift;
                      finalGroup = buildCommon.makeVList({
                        positionType: "bottom",
                        positionData: _bottom,
                        children: [{
                          type: "elem",
                          elem: base
                        }, {
                          type: "kern",
                          size: sup.kern
                        }, {
                          type: "elem",
                          elem: sup.elem,
                          marginLeft: slant + "em"
                        }, {
                          type: "kern",
                          size: options.fontMetrics().bigOpSpacing5
                        }]
                      }, options);
                    } else {
                      return base;
                    }
                    return buildCommon.makeSpan(["mop", "op-limits"], [finalGroup], options);
                  } else {
                    if (baseShift) {
                      base.style.position = "relative";
                      base.style.top = baseShift + "em";
                    }
                    return base;
                  }
                };
                var op_mathmlBuilder = function mathmlBuilder(group, options) {
                  var node;
                  if (group.symbol) {
                    node = new mathMLTree_MathNode("mo", [buildMathML_makeText(group.name, group.mode)]);
                  } else if (group.body) {
                    node = new mathMLTree_MathNode("mo", buildMathML_buildExpression(group.body, options));
                  } else {
                    node = new mathMLTree_MathNode("mi", [new mathMLTree_TextNode(group.name.slice(1))]);
                    var operator = new mathMLTree_MathNode("mo", [buildMathML_makeText("⁡", "text")]);
                    return newDocumentFragment([node, operator]);
                  }
                  return node;
                };
                var singleCharBigOps = {
                  "∏": "\\prod",
                  "∐": "\\coprod",
                  "∑": "\\sum",
                  "⋀": "\\bigwedge",
                  "⋁": "\\bigvee",
                  "⋂": "\\bigcap",
                  "⋃": "\\bigcap",
                  "⨀": "\\bigodot",
                  "⨁": "\\bigoplus",
                  "⨂": "\\bigotimes",
                  "⨄": "\\biguplus",
                  "⨆": "\\bigsqcup"
                };
                defineFunction({
                  type: "op",
                  names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
                  props: {
                    numArgs: 0
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    var fName = funcName;
                    if (fName.length === 1) {
                      fName = singleCharBigOps[fName];
                    }
                    return {
                      type: "op",
                      mode: parser.mode,
                      limits: true,
                      symbol: true,
                      name: fName
                    };
                  },
                  htmlBuilder: op_htmlBuilder,
                  mathmlBuilder: op_mathmlBuilder
                });
                defineFunction({
                  type: "op",
                  names: ["\\mathop"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(_ref2, args) {
                    var parser = _ref2.parser;
                    var body = args[0];
                    return {
                      type: "op",
                      mode: parser.mode,
                      limits: false,
                      symbol: false,
                      body: defineFunction_ordargument(body)
                    };
                  },
                  htmlBuilder: op_htmlBuilder,
                  mathmlBuilder: op_mathmlBuilder
                });
                var singleCharIntegrals = {
                  "∫": "\\int",
                  "∬": "\\iint",
                  "∭": "\\iiint",
                  "∮": "\\oint",
                  "∯": "\\oiint",
                  "∰": "\\oiiint"
                };
                defineFunction({
                  type: "op",
                  names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
                  props: {
                    numArgs: 0
                  },
                  handler: function handler(_ref3) {
                    var parser = _ref3.parser, funcName = _ref3.funcName;
                    return {
                      type: "op",
                      mode: parser.mode,
                      limits: false,
                      symbol: false,
                      name: funcName
                    };
                  },
                  htmlBuilder: op_htmlBuilder,
                  mathmlBuilder: op_mathmlBuilder
                });
                defineFunction({
                  type: "op",
                  names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
                  props: {
                    numArgs: 0
                  },
                  handler: function handler(_ref4) {
                    var parser = _ref4.parser, funcName = _ref4.funcName;
                    return {
                      type: "op",
                      mode: parser.mode,
                      limits: true,
                      symbol: false,
                      name: funcName
                    };
                  },
                  htmlBuilder: op_htmlBuilder,
                  mathmlBuilder: op_mathmlBuilder
                });
                defineFunction({
                  type: "op",
                  names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
                  props: {
                    numArgs: 0
                  },
                  handler: function handler(_ref5) {
                    var parser = _ref5.parser, funcName = _ref5.funcName;
                    var fName = funcName;
                    if (fName.length === 1) {
                      fName = singleCharIntegrals[fName];
                    }
                    return {
                      type: "op",
                      mode: parser.mode,
                      limits: false,
                      symbol: true,
                      name: fName
                    };
                  },
                  htmlBuilder: op_htmlBuilder,
                  mathmlBuilder: op_mathmlBuilder
                });
                defineFunction({
                  type: "operatorname",
                  names: ["\\operatorname"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser;
                    var body = args[0];
                    return {
                      type: "operatorname",
                      mode: parser.mode,
                      body: defineFunction_ordargument(body)
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    if (group.body.length > 0) {
                      var body = group.body.map(function(child2) {
                        var childText = child2.text;
                        if (typeof childText === "string") {
                          return {
                            type: "textord",
                            mode: child2.mode,
                            text: childText
                          };
                        } else {
                          return child2;
                        }
                      });
                      var expression = buildHTML_buildExpression(body, options.withFont("mathrm"), true);
                      for (var i = 0; i < expression.length; i++) {
                        var child = expression[i];
                        if (child instanceof domTree_SymbolNode) {
                          child.text = child.text.replace(/\u2212/, "-").replace(/\u2217/, "*");
                        }
                      }
                      return buildCommon.makeSpan(["mop"], expression, options);
                    } else {
                      return buildCommon.makeSpan(["mop"], [], options);
                    }
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var expression = buildMathML_buildExpression(group.body, options.withFont("mathrm"));
                    var isAllString = true;
                    for (var i = 0; i < expression.length; i++) {
                      var node = expression[i];
                      if (node instanceof mathMLTree.SpaceNode) {
                      } else if (node instanceof mathMLTree.MathNode) {
                        switch (node.type) {
                          case "mi":
                          case "mn":
                          case "ms":
                          case "mspace":
                          case "mtext":
                            break;
                          case "mo": {
                            var child = node.children[0];
                            if (node.children.length === 1 && child instanceof mathMLTree.TextNode) {
                              child.text = child.text.replace(/\u2212/, "-").replace(/\u2217/, "*");
                            } else {
                              isAllString = false;
                            }
                            break;
                          }
                          default:
                            isAllString = false;
                        }
                      } else {
                        isAllString = false;
                      }
                    }
                    if (isAllString) {
                      var word = expression.map(function(node2) {
                        return node2.toText();
                      }).join("");
                      expression = [new mathMLTree.TextNode(word, false)];
                    }
                    var identifier = new mathMLTree.MathNode("mi", expression);
                    identifier.setAttribute("mathvariant", "normal");
                    var operator = new mathMLTree.MathNode("mo", [buildMathML_makeText("⁡", "text")]);
                    return mathMLTree.newDocumentFragment([identifier, operator]);
                  }
                });
                defineFunctionBuilders({
                  type: "ordgroup",
                  htmlBuilder: function htmlBuilder(group, options) {
                    return buildCommon.makeSpan(["mord"], buildHTML_buildExpression(group.body, options, true), options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    return buildExpressionRow(group.body, options);
                  }
                });
                defineFunction({
                  type: "overline",
                  names: ["\\overline"],
                  props: {
                    numArgs: 1
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser;
                    var body = args[0];
                    return {
                      type: "overline",
                      mode: parser.mode,
                      body
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var innerGroup = buildHTML_buildGroup(group.body, options.havingCrampedStyle());
                    var line = buildCommon.makeLineSpan("overline-line", options);
                    var vlist = buildCommon.makeVList({
                      positionType: "firstBaseline",
                      children: [{
                        type: "elem",
                        elem: innerGroup
                      }, {
                        type: "kern",
                        size: 3 * line.height
                      }, {
                        type: "elem",
                        elem: line
                      }, {
                        type: "kern",
                        size: line.height
                      }]
                    }, options);
                    return buildCommon.makeSpan(["mord", "overline"], [vlist], options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var operator = new mathMLTree.MathNode("mo", [new mathMLTree.TextNode("‾")]);
                    operator.setAttribute("stretchy", "true");
                    var node = new mathMLTree.MathNode("mover", [buildMathML_buildGroup(group.body, options), operator]);
                    node.setAttribute("accent", "true");
                    return node;
                  }
                });
                defineFunction({
                  type: "phantom",
                  names: ["\\phantom"],
                  props: {
                    numArgs: 1,
                    allowedInText: true
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser;
                    var body = args[0];
                    return {
                      type: "phantom",
                      mode: parser.mode,
                      body: defineFunction_ordargument(body)
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var elements = buildHTML_buildExpression(group.body, options.withPhantom(), false);
                    return buildCommon.makeFragment(elements);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var inner = buildMathML_buildExpression(group.body, options);
                    return new mathMLTree.MathNode("mphantom", inner);
                  }
                });
                defineFunction({
                  type: "hphantom",
                  names: ["\\hphantom"],
                  props: {
                    numArgs: 1,
                    allowedInText: true
                  },
                  handler: function handler(_ref2, args) {
                    var parser = _ref2.parser;
                    var body = args[0];
                    return {
                      type: "hphantom",
                      mode: parser.mode,
                      body
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var node = buildCommon.makeSpan([], [buildHTML_buildGroup(group.body, options.withPhantom())]);
                    node.height = 0;
                    node.depth = 0;
                    if (node.children) {
                      for (var i = 0; i < node.children.length; i++) {
                        node.children[i].height = 0;
                        node.children[i].depth = 0;
                      }
                    }
                    node = buildCommon.makeVList({
                      positionType: "firstBaseline",
                      children: [{
                        type: "elem",
                        elem: node
                      }]
                    }, options);
                    return node;
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var inner = buildMathML_buildExpression(defineFunction_ordargument(group.body), options);
                    var node = new mathMLTree.MathNode("mphantom", inner);
                    node.setAttribute("height", "0px");
                    return node;
                  }
                });
                defineFunction({
                  type: "vphantom",
                  names: ["\\vphantom"],
                  props: {
                    numArgs: 1,
                    allowedInText: true
                  },
                  handler: function handler(_ref3, args) {
                    var parser = _ref3.parser;
                    var body = args[0];
                    return {
                      type: "vphantom",
                      mode: parser.mode,
                      body
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var inner = buildCommon.makeSpan(["inner"], [buildHTML_buildGroup(group.body, options.withPhantom())]);
                    var fix = buildCommon.makeSpan(["fix"], []);
                    return buildCommon.makeSpan(["mord", "rlap"], [inner, fix], options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var inner = buildMathML_buildExpression(defineFunction_ordargument(group.body), options);
                    var node = new mathMLTree.MathNode("mphantom", inner);
                    node.setAttribute("width", "0px");
                    return node;
                  }
                });
                function sizingGroup(value, options, baseOptions) {
                  var inner = buildHTML_buildExpression(value, options, false);
                  var multiplier = options.sizeMultiplier / baseOptions.sizeMultiplier;
                  for (var i = 0; i < inner.length; i++) {
                    var pos = inner[i].classes.indexOf("sizing");
                    if (pos < 0) {
                      Array.prototype.push.apply(inner[i].classes, options.sizingClasses(baseOptions));
                    } else if (inner[i].classes[pos + 1] === "reset-size" + options.size) {
                      inner[i].classes[pos + 1] = "reset-size" + baseOptions.size;
                    }
                    inner[i].height *= multiplier;
                    inner[i].depth *= multiplier;
                  }
                  return buildCommon.makeFragment(inner);
                }
                var sizeFuncs = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"];
                var sizing_htmlBuilder = function htmlBuilder(group, options) {
                  var newOptions = options.havingSize(group.size);
                  return sizingGroup(group.body, newOptions, options);
                };
                defineFunction({
                  type: "sizing",
                  names: sizeFuncs,
                  props: {
                    numArgs: 0,
                    allowedInText: true
                  },
                  handler: function handler(_ref, args) {
                    var breakOnTokenText = _ref.breakOnTokenText, funcName = _ref.funcName, parser = _ref.parser;
                    parser.consumeSpaces();
                    var body = parser.parseExpression(false, breakOnTokenText);
                    return {
                      type: "sizing",
                      mode: parser.mode,
                      // Figure out what size to use based on the list of functions above
                      size: sizeFuncs.indexOf(funcName) + 1,
                      body
                    };
                  },
                  htmlBuilder: sizing_htmlBuilder,
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var newOptions = options.havingSize(group.size);
                    var inner = buildMathML_buildExpression(group.body, newOptions);
                    var node = new mathMLTree.MathNode("mstyle", inner);
                    node.setAttribute("mathsize", newOptions.sizeMultiplier + "em");
                    return node;
                  }
                });
                defineFunction({
                  type: "raisebox",
                  names: ["\\raisebox"],
                  props: {
                    numArgs: 2,
                    argTypes: ["size", "text"],
                    allowedInText: true
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser;
                    var amount = assertNodeType(args[0], "size").value;
                    var body = args[1];
                    return {
                      type: "raisebox",
                      mode: parser.mode,
                      dy: amount,
                      body
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var text = {
                      type: "text",
                      mode: group.mode,
                      body: defineFunction_ordargument(group.body),
                      font: "mathrm"
                      // simulate \textrm
                    };
                    var sizedText = {
                      type: "sizing",
                      mode: group.mode,
                      body: [text],
                      size: 6
                      // simulate \normalsize
                    };
                    var body = sizing_htmlBuilder(sizedText, options);
                    var dy = units_calculateSize(group.dy, options);
                    return buildCommon.makeVList({
                      positionType: "shift",
                      positionData: -dy,
                      children: [{
                        type: "elem",
                        elem: body
                      }]
                    }, options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var node = new mathMLTree.MathNode("mpadded", [buildMathML_buildGroup(group.body, options)]);
                    var dy = group.dy.number + group.dy.unit;
                    node.setAttribute("voffset", dy);
                    return node;
                  }
                });
                defineFunction({
                  type: "rule",
                  names: ["\\rule"],
                  props: {
                    numArgs: 2,
                    numOptionalArgs: 1,
                    argTypes: ["size", "size", "size"]
                  },
                  handler: function handler(_ref, args, optArgs) {
                    var parser = _ref.parser;
                    var shift = optArgs[0];
                    var width = assertNodeType(args[0], "size");
                    var height = assertNodeType(args[1], "size");
                    return {
                      type: "rule",
                      mode: parser.mode,
                      shift: shift && assertNodeType(shift, "size").value,
                      width: width.value,
                      height: height.value
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var rule = buildCommon.makeSpan(["mord", "rule"], [], options);
                    var shift = 0;
                    if (group.shift) {
                      shift = units_calculateSize(group.shift, options);
                    }
                    var width = units_calculateSize(group.width, options);
                    var height = units_calculateSize(group.height, options);
                    rule.style.borderRightWidth = width + "em";
                    rule.style.borderTopWidth = height + "em";
                    rule.style.bottom = shift + "em";
                    rule.width = width;
                    rule.height = height + shift;
                    rule.depth = -shift;
                    rule.maxFontSize = height * 1.125 * options.sizeMultiplier;
                    return rule;
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var node = new mathMLTree.MathNode("mrow");
                    return node;
                  }
                });
                defineFunction({
                  type: "smash",
                  names: ["\\smash"],
                  props: {
                    numArgs: 1,
                    numOptionalArgs: 1,
                    allowedInText: true
                  },
                  handler: function handler(_ref, args, optArgs) {
                    var parser = _ref.parser;
                    var smashHeight = false;
                    var smashDepth = false;
                    var tbArg = optArgs[0] && assertNodeType(optArgs[0], "ordgroup");
                    if (tbArg) {
                      var letter = "";
                      for (var i = 0; i < tbArg.body.length; ++i) {
                        var node = tbArg.body[i];
                        letter = node.text;
                        if (letter === "t") {
                          smashHeight = true;
                        } else if (letter === "b") {
                          smashDepth = true;
                        } else {
                          smashHeight = false;
                          smashDepth = false;
                          break;
                        }
                      }
                    } else {
                      smashHeight = true;
                      smashDepth = true;
                    }
                    var body = args[0];
                    return {
                      type: "smash",
                      mode: parser.mode,
                      body,
                      smashHeight,
                      smashDepth
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var node = buildCommon.makeSpan(["mord"], [buildHTML_buildGroup(group.body, options)]);
                    if (!group.smashHeight && !group.smashDepth) {
                      return node;
                    }
                    if (group.smashHeight) {
                      node.height = 0;
                      if (node.children) {
                        for (var i = 0; i < node.children.length; i++) {
                          node.children[i].height = 0;
                        }
                      }
                    }
                    if (group.smashDepth) {
                      node.depth = 0;
                      if (node.children) {
                        for (var _i = 0; _i < node.children.length; _i++) {
                          node.children[_i].depth = 0;
                        }
                      }
                    }
                    return buildCommon.makeVList({
                      positionType: "firstBaseline",
                      children: [{
                        type: "elem",
                        elem: node
                      }]
                    }, options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var node = new mathMLTree.MathNode("mpadded", [buildMathML_buildGroup(group.body, options)]);
                    if (group.smashHeight) {
                      node.setAttribute("height", "0px");
                    }
                    if (group.smashDepth) {
                      node.setAttribute("depth", "0px");
                    }
                    return node;
                  }
                });
                defineFunction({
                  type: "sqrt",
                  names: ["\\sqrt"],
                  props: {
                    numArgs: 1,
                    numOptionalArgs: 1
                  },
                  handler: function handler(_ref, args, optArgs) {
                    var parser = _ref.parser;
                    var index = optArgs[0];
                    var body = args[0];
                    return {
                      type: "sqrt",
                      mode: parser.mode,
                      body,
                      index
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var inner = buildHTML_buildGroup(group.body, options.havingCrampedStyle());
                    if (inner.height === 0) {
                      inner.height = options.fontMetrics().xHeight;
                    }
                    inner = buildCommon.wrapFragment(inner, options);
                    var metrics = options.fontMetrics();
                    var theta = metrics.defaultRuleThickness;
                    var phi = theta;
                    if (options.style.id < src_Style.TEXT.id) {
                      phi = options.fontMetrics().xHeight;
                    }
                    var lineClearance = theta + phi / 4;
                    var minDelimiterHeight = inner.height + inner.depth + lineClearance + theta;
                    var _delimiter$sqrtImage = delimiter.sqrtImage(minDelimiterHeight, options), img = _delimiter$sqrtImage.span, ruleWidth = _delimiter$sqrtImage.ruleWidth, advanceWidth = _delimiter$sqrtImage.advanceWidth;
                    var delimDepth = img.height - ruleWidth;
                    if (delimDepth > inner.height + inner.depth + lineClearance) {
                      lineClearance = (lineClearance + delimDepth - inner.height - inner.depth) / 2;
                    }
                    var imgShift = img.height - inner.height - lineClearance - ruleWidth;
                    inner.style.paddingLeft = advanceWidth + "em";
                    var body = buildCommon.makeVList({
                      positionType: "firstBaseline",
                      children: [{
                        type: "elem",
                        elem: inner,
                        wrapperClasses: ["svg-align"]
                      }, {
                        type: "kern",
                        size: -(inner.height + imgShift)
                      }, {
                        type: "elem",
                        elem: img
                      }, {
                        type: "kern",
                        size: ruleWidth
                      }]
                    }, options);
                    if (!group.index) {
                      return buildCommon.makeSpan(["mord", "sqrt"], [body], options);
                    } else {
                      var newOptions = options.havingStyle(src_Style.SCRIPTSCRIPT);
                      var rootm = buildHTML_buildGroup(group.index, newOptions, options);
                      var toShift = 0.6 * (body.height - body.depth);
                      var rootVList = buildCommon.makeVList({
                        positionType: "shift",
                        positionData: -toShift,
                        children: [{
                          type: "elem",
                          elem: rootm
                        }]
                      }, options);
                      var rootVListWrap = buildCommon.makeSpan(["root"], [rootVList]);
                      return buildCommon.makeSpan(["mord", "sqrt"], [rootVListWrap, body], options);
                    }
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var body = group.body, index = group.index;
                    return index ? new mathMLTree.MathNode("mroot", [buildMathML_buildGroup(body, options), buildMathML_buildGroup(index, options)]) : new mathMLTree.MathNode("msqrt", [buildMathML_buildGroup(body, options)]);
                  }
                });
                var styling_styleMap = {
                  "display": src_Style.DISPLAY,
                  "text": src_Style.TEXT,
                  "script": src_Style.SCRIPT,
                  "scriptscript": src_Style.SCRIPTSCRIPT
                };
                defineFunction({
                  type: "styling",
                  names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
                  props: {
                    numArgs: 0,
                    allowedInText: true
                  },
                  handler: function handler(_ref, args) {
                    var breakOnTokenText = _ref.breakOnTokenText, funcName = _ref.funcName, parser = _ref.parser;
                    parser.consumeSpaces();
                    var body = parser.parseExpression(true, breakOnTokenText);
                    var style = funcName.slice(1, funcName.length - 5);
                    return {
                      type: "styling",
                      mode: parser.mode,
                      // Figure out what style to use by pulling out the style from
                      // the function name
                      style,
                      body
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var newStyle = styling_styleMap[group.style];
                    var newOptions = options.havingStyle(newStyle).withFont("");
                    return sizingGroup(group.body, newOptions, options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var styleMap = {
                      "display": src_Style.DISPLAY,
                      "text": src_Style.TEXT,
                      "script": src_Style.SCRIPT,
                      "scriptscript": src_Style.SCRIPTSCRIPT
                    };
                    var newStyle = styleMap[group.style];
                    var newOptions = options.havingStyle(newStyle);
                    var inner = buildMathML_buildExpression(group.body, newOptions);
                    var node = new mathMLTree.MathNode("mstyle", inner);
                    var styleAttributes = {
                      "display": ["0", "true"],
                      "text": ["0", "false"],
                      "script": ["1", "false"],
                      "scriptscript": ["2", "false"]
                    };
                    var attr = styleAttributes[group.style];
                    node.setAttribute("scriptlevel", attr[0]);
                    node.setAttribute("displaystyle", attr[1]);
                    return node;
                  }
                });
                var supsub_htmlBuilderDelegate = function htmlBuilderDelegate(group, options) {
                  var base = group.base;
                  if (!base) {
                    return null;
                  } else if (base.type === "op") {
                    var delegate = base.limits && (options.style.size === src_Style.DISPLAY.size || base.alwaysHandleSupSub);
                    return delegate ? op_htmlBuilder : null;
                  } else if (base.type === "accent") {
                    return utils.isCharacterBox(base.base) ? accent_htmlBuilder : null;
                  } else if (base.type === "horizBrace") {
                    var isSup = !group.sub;
                    return isSup === base.isOver ? horizBrace_htmlBuilder : null;
                  } else {
                    return null;
                  }
                };
                defineFunctionBuilders({
                  type: "supsub",
                  htmlBuilder: function htmlBuilder(group, options) {
                    var builderDelegate = supsub_htmlBuilderDelegate(group, options);
                    if (builderDelegate) {
                      return builderDelegate(group, options);
                    }
                    var valueBase = group.base, valueSup = group.sup, valueSub = group.sub;
                    var base = buildHTML_buildGroup(valueBase, options);
                    var supm;
                    var subm;
                    var metrics = options.fontMetrics();
                    var supShift = 0;
                    var subShift = 0;
                    var isCharacterBox = valueBase && utils.isCharacterBox(valueBase);
                    if (valueSup) {
                      var newOptions = options.havingStyle(options.style.sup());
                      supm = buildHTML_buildGroup(valueSup, newOptions, options);
                      if (!isCharacterBox) {
                        supShift = base.height - newOptions.fontMetrics().supDrop * newOptions.sizeMultiplier / options.sizeMultiplier;
                      }
                    }
                    if (valueSub) {
                      var _newOptions = options.havingStyle(options.style.sub());
                      subm = buildHTML_buildGroup(valueSub, _newOptions, options);
                      if (!isCharacterBox) {
                        subShift = base.depth + _newOptions.fontMetrics().subDrop * _newOptions.sizeMultiplier / options.sizeMultiplier;
                      }
                    }
                    var minSupShift;
                    if (options.style === src_Style.DISPLAY) {
                      minSupShift = metrics.sup1;
                    } else if (options.style.cramped) {
                      minSupShift = metrics.sup3;
                    } else {
                      minSupShift = metrics.sup2;
                    }
                    var multiplier = options.sizeMultiplier;
                    var marginRight = 0.5 / metrics.ptPerEm / multiplier + "em";
                    var marginLeft = null;
                    if (subm) {
                      var isOiint = group.base && group.base.type === "op" && group.base.name && (group.base.name === "\\oiint" || group.base.name === "\\oiiint");
                      if (base instanceof domTree_SymbolNode || isOiint) {
                        marginLeft = -base.italic + "em";
                      }
                    }
                    var supsub;
                    if (supm && subm) {
                      supShift = Math.max(supShift, minSupShift, supm.depth + 0.25 * metrics.xHeight);
                      subShift = Math.max(subShift, metrics.sub2);
                      var ruleWidth = metrics.defaultRuleThickness;
                      var maxWidth = 4 * ruleWidth;
                      if (supShift - supm.depth - (subm.height - subShift) < maxWidth) {
                        subShift = maxWidth - (supShift - supm.depth) + subm.height;
                        var psi = 0.8 * metrics.xHeight - (supShift - supm.depth);
                        if (psi > 0) {
                          supShift += psi;
                          subShift -= psi;
                        }
                      }
                      var vlistElem = [{
                        type: "elem",
                        elem: subm,
                        shift: subShift,
                        marginRight,
                        marginLeft
                      }, {
                        type: "elem",
                        elem: supm,
                        shift: -supShift,
                        marginRight
                      }];
                      supsub = buildCommon.makeVList({
                        positionType: "individualShift",
                        children: vlistElem
                      }, options);
                    } else if (subm) {
                      subShift = Math.max(subShift, metrics.sub1, subm.height - 0.8 * metrics.xHeight);
                      var _vlistElem = [{
                        type: "elem",
                        elem: subm,
                        marginLeft,
                        marginRight
                      }];
                      supsub = buildCommon.makeVList({
                        positionType: "shift",
                        positionData: subShift,
                        children: _vlistElem
                      }, options);
                    } else if (supm) {
                      supShift = Math.max(supShift, minSupShift, supm.depth + 0.25 * metrics.xHeight);
                      supsub = buildCommon.makeVList({
                        positionType: "shift",
                        positionData: -supShift,
                        children: [{
                          type: "elem",
                          elem: supm,
                          marginRight
                        }]
                      }, options);
                    } else {
                      throw new Error("supsub must have either sup or sub.");
                    }
                    var mclass = getTypeOfDomTree(base, "right") || "mord";
                    return buildCommon.makeSpan([mclass], [base, buildCommon.makeSpan(["msupsub"], [supsub])], options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var isBrace = false;
                    var isOver;
                    var isSup;
                    var horizBrace = checkNodeType(group.base, "horizBrace");
                    if (horizBrace) {
                      isSup = !!group.sup;
                      if (isSup === horizBrace.isOver) {
                        isBrace = true;
                        isOver = horizBrace.isOver;
                      }
                    }
                    var children = [buildMathML_buildGroup(group.base, options)];
                    if (group.sub) {
                      children.push(buildMathML_buildGroup(group.sub, options));
                    }
                    if (group.sup) {
                      children.push(buildMathML_buildGroup(group.sup, options));
                    }
                    var nodeType;
                    if (isBrace) {
                      nodeType = isOver ? "mover" : "munder";
                    } else if (!group.sub) {
                      var base = group.base;
                      if (base && base.type === "op" && base.limits && options.style === src_Style.DISPLAY) {
                        nodeType = "mover";
                      } else {
                        nodeType = "msup";
                      }
                    } else if (!group.sup) {
                      var _base = group.base;
                      if (_base && _base.type === "op" && _base.limits && options.style === src_Style.DISPLAY) {
                        nodeType = "munder";
                      } else {
                        nodeType = "msub";
                      }
                    } else {
                      var _base2 = group.base;
                      if (_base2 && _base2.type === "op" && _base2.limits && options.style === src_Style.DISPLAY) {
                        nodeType = "munderover";
                      } else {
                        nodeType = "msubsup";
                      }
                    }
                    var node = new mathMLTree.MathNode(nodeType, children);
                    return node;
                  }
                });
                defineFunctionBuilders({
                  type: "atom",
                  htmlBuilder: function htmlBuilder(group, options) {
                    return buildCommon.mathsym(group.text, group.mode, options, ["m" + group.family]);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var node = new mathMLTree.MathNode("mo", [buildMathML_makeText(group.text, group.mode)]);
                    if (group.family === "bin") {
                      var variant = buildMathML_getVariant(group, options);
                      if (variant === "bold-italic") {
                        node.setAttribute("mathvariant", variant);
                      }
                    } else if (group.family === "punct") {
                      node.setAttribute("separator", "true");
                    }
                    return node;
                  }
                });
                var defaultVariant = {
                  "mi": "italic",
                  "mn": "normal",
                  "mtext": "normal"
                };
                defineFunctionBuilders({
                  type: "mathord",
                  htmlBuilder: function htmlBuilder(group, options) {
                    return buildCommon.makeOrd(group, options, "mathord");
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var node = new mathMLTree.MathNode("mi", [buildMathML_makeText(group.text, group.mode, options)]);
                    var variant = buildMathML_getVariant(group, options) || "italic";
                    if (variant !== defaultVariant[node.type]) {
                      node.setAttribute("mathvariant", variant);
                    }
                    return node;
                  }
                });
                defineFunctionBuilders({
                  type: "textord",
                  htmlBuilder: function htmlBuilder(group, options) {
                    return buildCommon.makeOrd(group, options, "textord");
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var text = buildMathML_makeText(group.text, group.mode, options);
                    var variant = buildMathML_getVariant(group, options) || "normal";
                    var node;
                    if (group.mode === "text") {
                      node = new mathMLTree.MathNode("mtext", [text]);
                    } else if (/[0-9]/.test(group.text)) {
                      node = new mathMLTree.MathNode("mn", [text]);
                    } else if (group.text === "\\prime") {
                      node = new mathMLTree.MathNode("mo", [text]);
                    } else {
                      node = new mathMLTree.MathNode("mi", [text]);
                    }
                    if (variant !== defaultVariant[node.type]) {
                      node.setAttribute("mathvariant", variant);
                    }
                    return node;
                  }
                });
                var cssSpace = {
                  "\\nobreak": "nobreak",
                  "\\allowbreak": "allowbreak"
                };
                var regularSpace = {
                  " ": {},
                  "\\ ": {},
                  "~": {
                    className: "nobreak"
                  },
                  "\\space": {},
                  "\\nobreakspace": {
                    className: "nobreak"
                  }
                };
                defineFunctionBuilders({
                  type: "spacing",
                  htmlBuilder: function htmlBuilder(group, options) {
                    if (regularSpace.hasOwnProperty(group.text)) {
                      var className = regularSpace[group.text].className || "";
                      if (group.mode === "text") {
                        var ord = buildCommon.makeOrd(group, options, "textord");
                        ord.classes.push(className);
                        return ord;
                      } else {
                        return buildCommon.makeSpan(["mspace", className], [buildCommon.mathsym(group.text, group.mode, options)], options);
                      }
                    } else if (cssSpace.hasOwnProperty(group.text)) {
                      return buildCommon.makeSpan(["mspace", cssSpace[group.text]], [], options);
                    } else {
                      throw new src_ParseError('Unknown type of space "' + group.text + '"');
                    }
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var node;
                    if (regularSpace.hasOwnProperty(group.text)) {
                      node = new mathMLTree.MathNode("mtext", [new mathMLTree.TextNode(" ")]);
                    } else if (cssSpace.hasOwnProperty(group.text)) {
                      return new mathMLTree.MathNode("mspace");
                    } else {
                      throw new src_ParseError('Unknown type of space "' + group.text + '"');
                    }
                    return node;
                  }
                });
                defineFunctionBuilders({
                  type: "tag",
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var table = new mathMLTree.MathNode("mtable", [new mathMLTree.MathNode("mlabeledtr", [new mathMLTree.MathNode("mtd", [buildExpressionRow(group.tag, options)]), new mathMLTree.MathNode("mtd", [buildExpressionRow(group.body, options)])])]);
                    table.setAttribute("side", "right");
                    return table;
                  }
                });
                var textFontFamilies = {
                  "\\text": void 0,
                  "\\textrm": "textrm",
                  "\\textsf": "textsf",
                  "\\texttt": "texttt",
                  "\\textnormal": "textrm"
                };
                var textFontWeights = {
                  "\\textbf": "textbf"
                };
                var textFontShapes = {
                  "\\textit": "textit"
                };
                var optionsWithFont = function optionsWithFont2(group, options) {
                  var font = group.font;
                  if (!font) {
                    return options;
                  } else if (textFontFamilies[font]) {
                    return options.withTextFontFamily(textFontFamilies[font]);
                  } else if (textFontWeights[font]) {
                    return options.withTextFontWeight(textFontWeights[font]);
                  } else {
                    return options.withTextFontShape(textFontShapes[font]);
                  }
                };
                defineFunction({
                  type: "text",
                  names: [
                    // Font families
                    "\\text",
                    "\\textrm",
                    "\\textsf",
                    "\\texttt",
                    "\\textnormal",
                    // Font weights
                    "\\textbf",
                    // Font Shapes
                    "\\textit"
                  ],
                  props: {
                    numArgs: 1,
                    argTypes: ["text"],
                    greediness: 2,
                    allowedInText: true,
                    consumeMode: "text"
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser, funcName = _ref.funcName;
                    var body = args[0];
                    return {
                      type: "text",
                      mode: parser.mode,
                      body: defineFunction_ordargument(body),
                      font: funcName
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var newOptions = optionsWithFont(group, options);
                    var inner = buildHTML_buildExpression(group.body, newOptions, true);
                    return buildCommon.makeSpan(["mord", "text"], buildCommon.tryCombineChars(inner), newOptions);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var newOptions = optionsWithFont(group, options);
                    return buildExpressionRow(group.body, newOptions);
                  }
                });
                defineFunction({
                  type: "underline",
                  names: ["\\underline"],
                  props: {
                    numArgs: 1,
                    allowedInText: true
                  },
                  handler: function handler(_ref, args) {
                    var parser = _ref.parser;
                    return {
                      type: "underline",
                      mode: parser.mode,
                      body: args[0]
                    };
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var innerGroup = buildHTML_buildGroup(group.body, options);
                    var line = buildCommon.makeLineSpan("underline-line", options);
                    var vlist = buildCommon.makeVList({
                      positionType: "top",
                      positionData: innerGroup.height,
                      children: [{
                        type: "kern",
                        size: line.height
                      }, {
                        type: "elem",
                        elem: line
                      }, {
                        type: "kern",
                        size: 3 * line.height
                      }, {
                        type: "elem",
                        elem: innerGroup
                      }]
                    }, options);
                    return buildCommon.makeSpan(["mord", "underline"], [vlist], options);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var operator = new mathMLTree.MathNode("mo", [new mathMLTree.TextNode("‾")]);
                    operator.setAttribute("stretchy", "true");
                    var node = new mathMLTree.MathNode("munder", [buildMathML_buildGroup(group.body, options), operator]);
                    node.setAttribute("accentunder", "true");
                    return node;
                  }
                });
                defineFunction({
                  type: "verb",
                  names: ["\\verb"],
                  props: {
                    numArgs: 0,
                    allowedInText: true
                  },
                  handler: function handler(context, args, optArgs) {
                    throw new src_ParseError("\\verb ended by end of line instead of matching delimiter");
                  },
                  htmlBuilder: function htmlBuilder(group, options) {
                    var text = makeVerb(group);
                    var body = [];
                    var newOptions = options.havingStyle(options.style.text());
                    for (var i = 0; i < text.length; i++) {
                      var c = text[i];
                      if (c === "~") {
                        c = "\\textasciitilde";
                      }
                      body.push(buildCommon.makeSymbol(c, "Typewriter-Regular", group.mode, newOptions, ["mord", "texttt"]));
                    }
                    return buildCommon.makeSpan(["mord", "text"].concat(newOptions.sizingClasses(options)), buildCommon.tryCombineChars(body), newOptions);
                  },
                  mathmlBuilder: function mathmlBuilder(group, options) {
                    var text = new mathMLTree.TextNode(makeVerb(group));
                    var node = new mathMLTree.MathNode("mtext", [text]);
                    node.setAttribute("mathvariant", "monospace");
                    return node;
                  }
                });
                var makeVerb = function makeVerb2(group) {
                  return group.body.replace(/ /g, group.star ? "␣" : " ");
                };
                var functions = _functions;
                var src_functions = functions;
                var spaceRegexString = "[ \r\n	]";
                var controlWordRegexString = "\\\\[a-zA-Z@]+";
                var controlSymbolRegexString = "\\\\[^\uD800-\uDFFF]";
                var controlWordWhitespaceRegexString = "" + controlWordRegexString + spaceRegexString + "*";
                var controlWordWhitespaceRegex = new RegExp("^(" + controlWordRegexString + ")" + spaceRegexString + "*$");
                var combiningDiacriticalMarkString = "[̀-ͯ]";
                var combiningDiacriticalMarksEndRegex = new RegExp(combiningDiacriticalMarkString + "+$");
                var tokenRegexString = "(" + spaceRegexString + "+)|([!-\\[\\]-‧‪-퟿豈-￿]" + // single codepoint
                (combiningDiacriticalMarkString + "*") + // ...plus accents
                "|[\uD800-\uDBFF][\uDC00-\uDFFF]" + // surrogate pair
                (combiningDiacriticalMarkString + "*") + // ...plus accents
                "|\\\\verb\\*([^]).*?\\3|\\\\verb([^*a-zA-Z]).*?\\4" + // \verb unstarred
                ("|" + controlWordWhitespaceRegexString) + // \macroName + spaces
                ("|" + controlSymbolRegexString + ")");
                var Lexer_Lexer = function() {
                  function Lexer(input) {
                    this.input = void 0;
                    this.tokenRegex = void 0;
                    this.input = input;
                    this.tokenRegex = new RegExp(tokenRegexString, "g");
                  }
                  var _proto = Lexer.prototype;
                  _proto.lex = function lex() {
                    var input = this.input;
                    var pos = this.tokenRegex.lastIndex;
                    if (pos === input.length) {
                      return new Token_Token("EOF", new SourceLocation(this, pos, pos));
                    }
                    var match = this.tokenRegex.exec(input);
                    if (match === null || match.index !== pos) {
                      throw new src_ParseError("Unexpected character: '" + input[pos] + "'", new Token_Token(input[pos], new SourceLocation(this, pos, pos + 1)));
                    }
                    var text = match[2] || " ";
                    var controlMatch = text.match(controlWordWhitespaceRegex);
                    if (controlMatch) {
                      text = controlMatch[1];
                    }
                    return new Token_Token(text, new SourceLocation(this, pos, this.tokenRegex.lastIndex));
                  };
                  return Lexer;
                }();
                var Namespace_Namespace = function() {
                  function Namespace(builtins, globalMacros) {
                    if (builtins === void 0) {
                      builtins = {};
                    }
                    if (globalMacros === void 0) {
                      globalMacros = {};
                    }
                    this.current = void 0;
                    this.builtins = void 0;
                    this.undefStack = void 0;
                    this.current = globalMacros;
                    this.builtins = builtins;
                    this.undefStack = [];
                  }
                  var _proto = Namespace.prototype;
                  _proto.beginGroup = function beginGroup() {
                    this.undefStack.push({});
                  };
                  _proto.endGroup = function endGroup() {
                    if (this.undefStack.length === 0) {
                      throw new src_ParseError("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");
                    }
                    var undefs = this.undefStack.pop();
                    for (var undef in undefs) {
                      if (undefs.hasOwnProperty(undef)) {
                        if (undefs[undef] === void 0) {
                          delete this.current[undef];
                        } else {
                          this.current[undef] = undefs[undef];
                        }
                      }
                    }
                  };
                  _proto.has = function has(name) {
                    return this.current.hasOwnProperty(name) || this.builtins.hasOwnProperty(name);
                  };
                  _proto.get = function get(name) {
                    if (this.current.hasOwnProperty(name)) {
                      return this.current[name];
                    } else {
                      return this.builtins[name];
                    }
                  };
                  _proto.set = function set(name, value, global2) {
                    if (global2 === void 0) {
                      global2 = false;
                    }
                    if (global2) {
                      for (var i = 0; i < this.undefStack.length; i++) {
                        delete this.undefStack[i][name];
                      }
                      if (this.undefStack.length > 0) {
                        this.undefStack[this.undefStack.length - 1][name] = value;
                      }
                    } else {
                      var top = this.undefStack[this.undefStack.length - 1];
                      if (top && !top.hasOwnProperty(name)) {
                        top[name] = this.current[name];
                      }
                    }
                    this.current[name] = value;
                  };
                  return Namespace;
                }();
                var builtinMacros = {};
                var macros = builtinMacros;
                function defineMacro(name, body) {
                  builtinMacros[name] = body;
                }
                defineMacro("\\@firstoftwo", function(context) {
                  var args = context.consumeArgs(2);
                  return {
                    tokens: args[0],
                    numArgs: 0
                  };
                });
                defineMacro("\\@secondoftwo", function(context) {
                  var args = context.consumeArgs(2);
                  return {
                    tokens: args[1],
                    numArgs: 0
                  };
                });
                defineMacro("\\@ifnextchar", function(context) {
                  var args = context.consumeArgs(3);
                  var nextToken = context.future();
                  if (args[0].length === 1 && args[0][0].text === nextToken.text) {
                    return {
                      tokens: args[1],
                      numArgs: 0
                    };
                  } else {
                    return {
                      tokens: args[2],
                      numArgs: 0
                    };
                  }
                });
                defineMacro("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
                defineMacro("\\TextOrMath", function(context) {
                  var args = context.consumeArgs(2);
                  if (context.mode === "text") {
                    return {
                      tokens: args[0],
                      numArgs: 0
                    };
                  } else {
                    return {
                      tokens: args[1],
                      numArgs: 0
                    };
                  }
                });
                var digitToNumber = {
                  "0": 0,
                  "1": 1,
                  "2": 2,
                  "3": 3,
                  "4": 4,
                  "5": 5,
                  "6": 6,
                  "7": 7,
                  "8": 8,
                  "9": 9,
                  "a": 10,
                  "A": 10,
                  "b": 11,
                  "B": 11,
                  "c": 12,
                  "C": 12,
                  "d": 13,
                  "D": 13,
                  "e": 14,
                  "E": 14,
                  "f": 15,
                  "F": 15
                };
                defineMacro("\\char", function(context) {
                  var token = context.popToken();
                  var base;
                  var number = "";
                  if (token.text === "'") {
                    base = 8;
                    token = context.popToken();
                  } else if (token.text === '"') {
                    base = 16;
                    token = context.popToken();
                  } else if (token.text === "`") {
                    token = context.popToken();
                    if (token.text[0] === "\\") {
                      number = token.text.charCodeAt(1);
                    } else if (token.text === "EOF") {
                      throw new src_ParseError("\\char` missing argument");
                    } else {
                      number = token.text.charCodeAt(0);
                    }
                  } else {
                    base = 10;
                  }
                  if (base) {
                    number = digitToNumber[token.text];
                    if (number == null || number >= base) {
                      throw new src_ParseError("Invalid base-" + base + " digit " + token.text);
                    }
                    var digit;
                    while ((digit = digitToNumber[context.future().text]) != null && digit < base) {
                      number *= base;
                      number += digit;
                      context.popToken();
                    }
                  }
                  return "\\@char{" + number + "}";
                });
                var macros_def = function def(context, global2) {
                  var arg = context.consumeArgs(1)[0];
                  if (arg.length !== 1) {
                    throw new src_ParseError("\\gdef's first argument must be a macro name");
                  }
                  var name = arg[0].text;
                  var numArgs = 0;
                  arg = context.consumeArgs(1)[0];
                  while (arg.length === 1 && arg[0].text === "#") {
                    arg = context.consumeArgs(1)[0];
                    if (arg.length !== 1) {
                      throw new src_ParseError('Invalid argument number length "' + arg.length + '"');
                    }
                    if (!/^[1-9]$/.test(arg[0].text)) {
                      throw new src_ParseError('Invalid argument number "' + arg[0].text + '"');
                    }
                    numArgs++;
                    if (parseInt(arg[0].text) !== numArgs) {
                      throw new src_ParseError('Argument number "' + arg[0].text + '" out of order');
                    }
                    arg = context.consumeArgs(1)[0];
                  }
                  context.macros.set(name, {
                    tokens: arg,
                    numArgs
                  }, global2);
                  return "";
                };
                defineMacro("\\gdef", function(context) {
                  return macros_def(context, true);
                });
                defineMacro("\\def", function(context) {
                  return macros_def(context, false);
                });
                defineMacro("\\global", function(context) {
                  var next = context.consumeArgs(1)[0];
                  if (next.length !== 1) {
                    throw new src_ParseError("Invalid command after \\global");
                  }
                  var command = next[0].text;
                  if (command === "\\def") {
                    return macros_def(context, true);
                  } else {
                    throw new src_ParseError("Invalid command '" + command + "' after \\global");
                  }
                });
                var macros_newcommand = function newcommand(context, existsOK, nonexistsOK) {
                  var arg = context.consumeArgs(1)[0];
                  if (arg.length !== 1) {
                    throw new src_ParseError("\\newcommand's first argument must be a macro name");
                  }
                  var name = arg[0].text;
                  var exists = context.isDefined(name);
                  if (exists && !existsOK) {
                    throw new src_ParseError("\\newcommand{" + name + "} attempting to redefine " + (name + "; use \\renewcommand"));
                  }
                  if (!exists && !nonexistsOK) {
                    throw new src_ParseError("\\renewcommand{" + name + "} when command " + name + " does not yet exist; use \\newcommand");
                  }
                  var numArgs = 0;
                  arg = context.consumeArgs(1)[0];
                  if (arg.length === 1 && arg[0].text === "[") {
                    var argText = "";
                    var token = context.expandNextToken();
                    while (token.text !== "]" && token.text !== "EOF") {
                      argText += token.text;
                      token = context.expandNextToken();
                    }
                    if (!argText.match(/^\s*[0-9]+\s*$/)) {
                      throw new src_ParseError("Invalid number of arguments: " + argText);
                    }
                    numArgs = parseInt(argText);
                    arg = context.consumeArgs(1)[0];
                  }
                  context.macros.set(name, {
                    tokens: arg,
                    numArgs
                  });
                  return "";
                };
                defineMacro("\\newcommand", function(context) {
                  return macros_newcommand(context, false, true);
                });
                defineMacro("\\renewcommand", function(context) {
                  return macros_newcommand(context, true, false);
                });
                defineMacro("\\providecommand", function(context) {
                  return macros_newcommand(context, true, true);
                });
                defineMacro("\\bgroup", "{");
                defineMacro("\\egroup", "}");
                defineMacro("\\begingroup", "{");
                defineMacro("\\endgroup", "}");
                defineMacro("\\lq", "`");
                defineMacro("\\rq", "'");
                defineMacro("\\aa", "\\r a");
                defineMacro("\\AA", "\\r A");
                defineMacro("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}");
                defineMacro("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
                defineMacro("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}");
                defineMacro("ℂ", "\\mathbb{C}");
                defineMacro("ℍ", "\\mathbb{H}");
                defineMacro("ℕ", "\\mathbb{N}");
                defineMacro("ℙ", "\\mathbb{P}");
                defineMacro("ℚ", "\\mathbb{Q}");
                defineMacro("ℝ", "\\mathbb{R}");
                defineMacro("ℤ", "\\mathbb{Z}");
                defineMacro("ℎ", "\\mathit{h}");
                defineMacro("ℬ", "\\mathscr{B}");
                defineMacro("ℰ", "\\mathscr{E}");
                defineMacro("ℱ", "\\mathscr{F}");
                defineMacro("ℋ", "\\mathscr{H}");
                defineMacro("ℐ", "\\mathscr{I}");
                defineMacro("ℒ", "\\mathscr{L}");
                defineMacro("ℳ", "\\mathscr{M}");
                defineMacro("ℛ", "\\mathscr{R}");
                defineMacro("ℭ", "\\mathfrak{C}");
                defineMacro("ℌ", "\\mathfrak{H}");
                defineMacro("ℨ", "\\mathfrak{Z}");
                defineMacro("·", "\\cdotp");
                defineMacro("\\llap", "\\mathllap{\\textrm{#1}}");
                defineMacro("\\rlap", "\\mathrlap{\\textrm{#1}}");
                defineMacro("\\clap", "\\mathclap{\\textrm{#1}}");
                defineMacro("\\not", "\\mathrel{\\mathrlap\\@not}");
                defineMacro("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}");
                defineMacro("\\ne", "\\neq");
                defineMacro("≠", "\\neq");
                defineMacro("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}");
                defineMacro("∉", "\\notin");
                defineMacro("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}");
                defineMacro("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}");
                defineMacro("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}");
                defineMacro("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}");
                defineMacro("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}");
                defineMacro("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}");
                defineMacro("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}");
                defineMacro("⟂", "\\perp");
                defineMacro("‼", "\\mathclose{!\\mkern-0.8mu!}");
                defineMacro("∌", "\\notni");
                defineMacro("⌜", "\\ulcorner");
                defineMacro("⌝", "\\urcorner");
                defineMacro("⌞", "\\llcorner");
                defineMacro("⌟", "\\lrcorner");
                defineMacro("©", "\\copyright");
                defineMacro("®", "\\textregistered");
                defineMacro("️", "\\textregistered");
                defineMacro("\\vdots", "\\mathord{\\varvdots\\rule{0pt}{15pt}}");
                defineMacro("⋮", "\\vdots");
                defineMacro("\\varGamma", "\\mathit{\\Gamma}");
                defineMacro("\\varDelta", "\\mathit{\\Delta}");
                defineMacro("\\varTheta", "\\mathit{\\Theta}");
                defineMacro("\\varLambda", "\\mathit{\\Lambda}");
                defineMacro("\\varXi", "\\mathit{\\Xi}");
                defineMacro("\\varPi", "\\mathit{\\Pi}");
                defineMacro("\\varSigma", "\\mathit{\\Sigma}");
                defineMacro("\\varUpsilon", "\\mathit{\\Upsilon}");
                defineMacro("\\varPhi", "\\mathit{\\Phi}");
                defineMacro("\\varPsi", "\\mathit{\\Psi}");
                defineMacro("\\varOmega", "\\mathit{\\Omega}");
                defineMacro("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu");
                defineMacro("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
                defineMacro("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
                defineMacro("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
                defineMacro("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
                var dotsByToken = {
                  ",": "\\dotsc",
                  "\\not": "\\dotsb",
                  // \keybin@ checks for the following:
                  "+": "\\dotsb",
                  "=": "\\dotsb",
                  "<": "\\dotsb",
                  ">": "\\dotsb",
                  "-": "\\dotsb",
                  "*": "\\dotsb",
                  ":": "\\dotsb",
                  // Symbols whose definition starts with \DOTSB:
                  "\\DOTSB": "\\dotsb",
                  "\\coprod": "\\dotsb",
                  "\\bigvee": "\\dotsb",
                  "\\bigwedge": "\\dotsb",
                  "\\biguplus": "\\dotsb",
                  "\\bigcap": "\\dotsb",
                  "\\bigcup": "\\dotsb",
                  "\\prod": "\\dotsb",
                  "\\sum": "\\dotsb",
                  "\\bigotimes": "\\dotsb",
                  "\\bigoplus": "\\dotsb",
                  "\\bigodot": "\\dotsb",
                  "\\bigsqcup": "\\dotsb",
                  "\\And": "\\dotsb",
                  "\\longrightarrow": "\\dotsb",
                  "\\Longrightarrow": "\\dotsb",
                  "\\longleftarrow": "\\dotsb",
                  "\\Longleftarrow": "\\dotsb",
                  "\\longleftrightarrow": "\\dotsb",
                  "\\Longleftrightarrow": "\\dotsb",
                  "\\mapsto": "\\dotsb",
                  "\\longmapsto": "\\dotsb",
                  "\\hookrightarrow": "\\dotsb",
                  "\\doteq": "\\dotsb",
                  // Symbols whose definition starts with \mathbin:
                  "\\mathbin": "\\dotsb",
                  // Symbols whose definition starts with \mathrel:
                  "\\mathrel": "\\dotsb",
                  "\\relbar": "\\dotsb",
                  "\\Relbar": "\\dotsb",
                  "\\xrightarrow": "\\dotsb",
                  "\\xleftarrow": "\\dotsb",
                  // Symbols whose definition starts with \DOTSI:
                  "\\DOTSI": "\\dotsi",
                  "\\int": "\\dotsi",
                  "\\oint": "\\dotsi",
                  "\\iint": "\\dotsi",
                  "\\iiint": "\\dotsi",
                  "\\iiiint": "\\dotsi",
                  "\\idotsint": "\\dotsi",
                  // Symbols whose definition starts with \DOTSX:
                  "\\DOTSX": "\\dotsx"
                };
                defineMacro("\\dots", function(context) {
                  var thedots = "\\dotso";
                  var next = context.expandAfterFuture().text;
                  if (next in dotsByToken) {
                    thedots = dotsByToken[next];
                  } else if (next.substr(0, 4) === "\\not") {
                    thedots = "\\dotsb";
                  } else if (next in src_symbols.math) {
                    if (utils.contains(["bin", "rel"], src_symbols.math[next].group)) {
                      thedots = "\\dotsb";
                    }
                  }
                  return thedots;
                });
                var spaceAfterDots = {
                  // \rightdelim@ checks for the following:
                  ")": true,
                  "]": true,
                  "\\rbrack": true,
                  "\\}": true,
                  "\\rbrace": true,
                  "\\rangle": true,
                  "\\rceil": true,
                  "\\rfloor": true,
                  "\\rgroup": true,
                  "\\rmoustache": true,
                  "\\right": true,
                  "\\bigr": true,
                  "\\biggr": true,
                  "\\Bigr": true,
                  "\\Biggr": true,
                  // \extra@ also tests for the following:
                  "$": true,
                  // \extrap@ checks for the following:
                  ";": true,
                  ".": true,
                  ",": true
                };
                defineMacro("\\dotso", function(context) {
                  var next = context.future().text;
                  if (next in spaceAfterDots) {
                    return "\\ldots\\,";
                  } else {
                    return "\\ldots";
                  }
                });
                defineMacro("\\dotsc", function(context) {
                  var next = context.future().text;
                  if (next in spaceAfterDots && next !== ",") {
                    return "\\ldots\\,";
                  } else {
                    return "\\ldots";
                  }
                });
                defineMacro("\\cdots", function(context) {
                  var next = context.future().text;
                  if (next in spaceAfterDots) {
                    return "\\@cdots\\,";
                  } else {
                    return "\\@cdots";
                  }
                });
                defineMacro("\\dotsb", "\\cdots");
                defineMacro("\\dotsm", "\\cdots");
                defineMacro("\\dotsi", "\\!\\cdots");
                defineMacro("\\dotsx", "\\ldots\\,");
                defineMacro("\\DOTSI", "\\relax");
                defineMacro("\\DOTSB", "\\relax");
                defineMacro("\\DOTSX", "\\relax");
                defineMacro("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
                defineMacro("\\,", "\\tmspace+{3mu}{.1667em}");
                defineMacro("\\thinspace", "\\,");
                defineMacro("\\>", "\\mskip{4mu}");
                defineMacro("\\:", "\\tmspace+{4mu}{.2222em}");
                defineMacro("\\medspace", "\\:");
                defineMacro("\\;", "\\tmspace+{5mu}{.2777em}");
                defineMacro("\\thickspace", "\\;");
                defineMacro("\\!", "\\tmspace-{3mu}{.1667em}");
                defineMacro("\\negthinspace", "\\!");
                defineMacro("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
                defineMacro("\\negthickspace", "\\tmspace-{5mu}{.277em}");
                defineMacro("\\enspace", "\\kern.5em ");
                defineMacro("\\enskip", "\\hskip.5em\\relax");
                defineMacro("\\quad", "\\hskip1em\\relax");
                defineMacro("\\qquad", "\\hskip2em\\relax");
                defineMacro("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
                defineMacro("\\tag@paren", "\\tag@literal{({#1})}");
                defineMacro("\\tag@literal", function(context) {
                  if (context.macros.get("\\df@tag")) {
                    throw new src_ParseError("Multiple \\tag");
                  }
                  return "\\gdef\\df@tag{\\text{#1}}";
                });
                defineMacro("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
                defineMacro("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
                defineMacro("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
                defineMacro("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
                defineMacro("\\pmb", "\\html@mathml{\\@binrel{#1}{\\mathrlap{#1}\\mathrlap{\\mkern0.4mu\\raisebox{0.4mu}{$#1$}}{\\mkern0.8mu#1}}}{\\mathbf{#1}}");
                defineMacro("\\\\", "\\newline");
                defineMacro("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
                var latexRaiseA = fontMetricsData["Main-Regular"]["T".charCodeAt(0)][1] - 0.7 * fontMetricsData["Main-Regular"]["A".charCodeAt(0)][1] + "em";
                defineMacro("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + latexRaiseA + "}{\\scriptsize A}") + "\\kern-.15em\\TeX}{LaTeX}}");
                defineMacro("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + latexRaiseA + "}{\\scriptsize A}") + "\\kern-.15em\\TeX}{KaTeX}}");
                defineMacro("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
                defineMacro("\\@hspace", "\\hskip #1\\relax");
                defineMacro("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
                defineMacro("\\ordinarycolon", ":");
                defineMacro("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
                defineMacro("\\dblcolon", "\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}");
                defineMacro("\\coloneqq", "\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}");
                defineMacro("\\Coloneqq", "\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}");
                defineMacro("\\coloneq", "\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}");
                defineMacro("\\Coloneq", "\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}");
                defineMacro("\\eqqcolon", "\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
                defineMacro("\\Eqqcolon", "\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}");
                defineMacro("\\eqcolon", "\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
                defineMacro("\\Eqcolon", "\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}");
                defineMacro("\\colonapprox", "\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}");
                defineMacro("\\Colonapprox", "\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}");
                defineMacro("\\colonsim", "\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}");
                defineMacro("\\Colonsim", "\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}");
                defineMacro("≔", "\\coloneqq");
                defineMacro("≕", "\\eqqcolon");
                defineMacro("⩴", "\\Coloneqq");
                defineMacro("\\ratio", "\\vcentcolon");
                defineMacro("\\coloncolon", "\\dblcolon");
                defineMacro("\\colonequals", "\\coloneqq");
                defineMacro("\\coloncolonequals", "\\Coloneqq");
                defineMacro("\\equalscolon", "\\eqqcolon");
                defineMacro("\\equalscoloncolon", "\\Eqqcolon");
                defineMacro("\\colonminus", "\\coloneq");
                defineMacro("\\coloncolonminus", "\\Coloneq");
                defineMacro("\\minuscolon", "\\eqcolon");
                defineMacro("\\minuscoloncolon", "\\Eqcolon");
                defineMacro("\\coloncolonapprox", "\\Colonapprox");
                defineMacro("\\coloncolonsim", "\\Colonsim");
                defineMacro("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
                defineMacro("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
                defineMacro("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
                defineMacro("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
                defineMacro("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}");
                defineMacro("\\limsup", "\\DOTSB\\mathop{\\operatorname{lim\\,sup}}\\limits");
                defineMacro("\\liminf", "\\DOTSB\\mathop{\\operatorname{lim\\,inf}}\\limits");
                defineMacro("⟦", "\\mathopen{[\\mkern-3.2mu[}");
                defineMacro("⟧", "\\mathclose{]\\mkern-3.2mu]}");
                defineMacro("\\darr", "\\downarrow");
                defineMacro("\\dArr", "\\Downarrow");
                defineMacro("\\Darr", "\\Downarrow");
                defineMacro("\\lang", "\\langle");
                defineMacro("\\rang", "\\rangle");
                defineMacro("\\uarr", "\\uparrow");
                defineMacro("\\uArr", "\\Uparrow");
                defineMacro("\\Uarr", "\\Uparrow");
                defineMacro("\\N", "\\mathbb{N}");
                defineMacro("\\R", "\\mathbb{R}");
                defineMacro("\\Z", "\\mathbb{Z}");
                defineMacro("\\alef", "\\aleph");
                defineMacro("\\alefsym", "\\aleph");
                defineMacro("\\Alpha", "\\mathrm{A}");
                defineMacro("\\Beta", "\\mathrm{B}");
                defineMacro("\\bull", "\\bullet");
                defineMacro("\\Chi", "\\mathrm{X}");
                defineMacro("\\clubs", "\\clubsuit");
                defineMacro("\\cnums", "\\mathbb{C}");
                defineMacro("\\Complex", "\\mathbb{C}");
                defineMacro("\\Dagger", "\\ddagger");
                defineMacro("\\diamonds", "\\diamondsuit");
                defineMacro("\\empty", "\\emptyset");
                defineMacro("\\Epsilon", "\\mathrm{E}");
                defineMacro("\\Eta", "\\mathrm{H}");
                defineMacro("\\exist", "\\exists");
                defineMacro("\\harr", "\\leftrightarrow");
                defineMacro("\\hArr", "\\Leftrightarrow");
                defineMacro("\\Harr", "\\Leftrightarrow");
                defineMacro("\\hearts", "\\heartsuit");
                defineMacro("\\image", "\\Im");
                defineMacro("\\infin", "\\infty");
                defineMacro("\\Iota", "\\mathrm{I}");
                defineMacro("\\isin", "\\in");
                defineMacro("\\Kappa", "\\mathrm{K}");
                defineMacro("\\larr", "\\leftarrow");
                defineMacro("\\lArr", "\\Leftarrow");
                defineMacro("\\Larr", "\\Leftarrow");
                defineMacro("\\lrarr", "\\leftrightarrow");
                defineMacro("\\lrArr", "\\Leftrightarrow");
                defineMacro("\\Lrarr", "\\Leftrightarrow");
                defineMacro("\\Mu", "\\mathrm{M}");
                defineMacro("\\natnums", "\\mathbb{N}");
                defineMacro("\\Nu", "\\mathrm{N}");
                defineMacro("\\Omicron", "\\mathrm{O}");
                defineMacro("\\plusmn", "\\pm");
                defineMacro("\\rarr", "\\rightarrow");
                defineMacro("\\rArr", "\\Rightarrow");
                defineMacro("\\Rarr", "\\Rightarrow");
                defineMacro("\\real", "\\Re");
                defineMacro("\\reals", "\\mathbb{R}");
                defineMacro("\\Reals", "\\mathbb{R}");
                defineMacro("\\Rho", "\\mathrm{R}");
                defineMacro("\\sdot", "\\cdot");
                defineMacro("\\sect", "\\S");
                defineMacro("\\spades", "\\spadesuit");
                defineMacro("\\sub", "\\subset");
                defineMacro("\\sube", "\\subseteq");
                defineMacro("\\supe", "\\supseteq");
                defineMacro("\\Tau", "\\mathrm{T}");
                defineMacro("\\thetasym", "\\vartheta");
                defineMacro("\\weierp", "\\wp");
                defineMacro("\\Zeta", "\\mathrm{Z}");
                var implicitCommands = {
                  "\\relax": true,
                  // MacroExpander.js
                  "^": true,
                  // Parser.js
                  "_": true,
                  // Parser.js
                  "\\limits": true,
                  // Parser.js
                  "\\nolimits": true
                  // Parser.js
                };
                var MacroExpander_MacroExpander = function() {
                  function MacroExpander(input, settings, mode) {
                    this.settings = void 0;
                    this.expansionCount = void 0;
                    this.lexer = void 0;
                    this.macros = void 0;
                    this.stack = void 0;
                    this.mode = void 0;
                    this.settings = settings;
                    this.expansionCount = 0;
                    this.feed(input);
                    this.macros = new Namespace_Namespace(macros, settings.macros);
                    this.mode = mode;
                    this.stack = [];
                  }
                  var _proto = MacroExpander.prototype;
                  _proto.feed = function feed(input) {
                    this.lexer = new Lexer_Lexer(input);
                  };
                  _proto.switchMode = function switchMode(newMode) {
                    this.mode = newMode;
                  };
                  _proto.beginGroup = function beginGroup() {
                    this.macros.beginGroup();
                  };
                  _proto.endGroup = function endGroup() {
                    this.macros.endGroup();
                  };
                  _proto.future = function future() {
                    if (this.stack.length === 0) {
                      this.pushToken(this.lexer.lex());
                    }
                    return this.stack[this.stack.length - 1];
                  };
                  _proto.popToken = function popToken() {
                    this.future();
                    return this.stack.pop();
                  };
                  _proto.pushToken = function pushToken(token) {
                    this.stack.push(token);
                  };
                  _proto.pushTokens = function pushTokens(tokens2) {
                    var _this$stack;
                    (_this$stack = this.stack).push.apply(_this$stack, tokens2);
                  };
                  _proto.consumeSpaces = function consumeSpaces() {
                    for (; ; ) {
                      var token = this.future();
                      if (token.text === " ") {
                        this.stack.pop();
                      } else {
                        break;
                      }
                    }
                  };
                  _proto.consumeArgs = function consumeArgs(numArgs) {
                    var args = [];
                    for (var i = 0; i < numArgs; ++i) {
                      this.consumeSpaces();
                      var startOfArg = this.popToken();
                      if (startOfArg.text === "{") {
                        var arg = [];
                        var depth = 1;
                        while (depth !== 0) {
                          var tok = this.popToken();
                          arg.push(tok);
                          if (tok.text === "{") {
                            ++depth;
                          } else if (tok.text === "}") {
                            --depth;
                          } else if (tok.text === "EOF") {
                            throw new src_ParseError("End of input in macro argument", startOfArg);
                          }
                        }
                        arg.pop();
                        arg.reverse();
                        args[i] = arg;
                      } else if (startOfArg.text === "EOF") {
                        throw new src_ParseError("End of input expecting macro argument");
                      } else {
                        args[i] = [startOfArg];
                      }
                    }
                    return args;
                  };
                  _proto.expandOnce = function expandOnce() {
                    var topToken = this.popToken();
                    var name = topToken.text;
                    var expansion = this._getExpansion(name);
                    if (expansion == null) {
                      this.pushToken(topToken);
                      return topToken;
                    }
                    this.expansionCount++;
                    if (this.expansionCount > this.settings.maxExpand) {
                      throw new src_ParseError("Too many expansions: infinite loop or need to increase maxExpand setting");
                    }
                    var tokens2 = expansion.tokens;
                    if (expansion.numArgs) {
                      var args = this.consumeArgs(expansion.numArgs);
                      tokens2 = tokens2.slice();
                      for (var i = tokens2.length - 1; i >= 0; --i) {
                        var tok = tokens2[i];
                        if (tok.text === "#") {
                          if (i === 0) {
                            throw new src_ParseError("Incomplete placeholder at end of macro body", tok);
                          }
                          tok = tokens2[--i];
                          if (tok.text === "#") {
                            tokens2.splice(i + 1, 1);
                          } else if (/^[1-9]$/.test(tok.text)) {
                            var _tokens;
                            (_tokens = tokens2).splice.apply(_tokens, [i, 2].concat(args[+tok.text - 1]));
                          } else {
                            throw new src_ParseError("Not a valid argument number", tok);
                          }
                        }
                      }
                    }
                    this.pushTokens(tokens2);
                    return tokens2;
                  };
                  _proto.expandAfterFuture = function expandAfterFuture() {
                    this.expandOnce();
                    return this.future();
                  };
                  _proto.expandNextToken = function expandNextToken() {
                    for (; ; ) {
                      var expanded = this.expandOnce();
                      if (expanded instanceof Token_Token) {
                        if (expanded.text === "\\relax") {
                          this.stack.pop();
                        } else {
                          return this.stack.pop();
                        }
                      }
                    }
                    throw new Error();
                  };
                  _proto.expandMacro = function expandMacro(name) {
                    if (!this.macros.get(name)) {
                      return void 0;
                    }
                    var output = [];
                    var oldStackLength = this.stack.length;
                    this.pushToken(new Token_Token(name));
                    while (this.stack.length > oldStackLength) {
                      var expanded = this.expandOnce();
                      if (expanded instanceof Token_Token) {
                        output.push(this.stack.pop());
                      }
                    }
                    return output;
                  };
                  _proto.expandMacroAsText = function expandMacroAsText(name) {
                    var tokens2 = this.expandMacro(name);
                    if (tokens2) {
                      return tokens2.map(function(token) {
                        return token.text;
                      }).join("");
                    } else {
                      return tokens2;
                    }
                  };
                  _proto._getExpansion = function _getExpansion(name) {
                    var definition = this.macros.get(name);
                    if (definition == null) {
                      return definition;
                    }
                    var expansion = typeof definition === "function" ? definition(this) : definition;
                    if (typeof expansion === "string") {
                      var numArgs = 0;
                      if (expansion.indexOf("#") !== -1) {
                        var stripped = expansion.replace(/##/g, "");
                        while (stripped.indexOf("#" + (numArgs + 1)) !== -1) {
                          ++numArgs;
                        }
                      }
                      var bodyLexer = new Lexer_Lexer(expansion);
                      var tokens2 = [];
                      var tok = bodyLexer.lex();
                      while (tok.text !== "EOF") {
                        tokens2.push(tok);
                        tok = bodyLexer.lex();
                      }
                      tokens2.reverse();
                      var expanded = {
                        tokens: tokens2,
                        numArgs
                      };
                      return expanded;
                    }
                    return expansion;
                  };
                  _proto.isDefined = function isDefined(name) {
                    return this.macros.has(name) || src_functions.hasOwnProperty(name) || src_symbols.math.hasOwnProperty(name) || src_symbols.text.hasOwnProperty(name) || implicitCommands.hasOwnProperty(name);
                  };
                  return MacroExpander;
                }();
                var unicodeAccents = {
                  "́": {
                    text: "\\'",
                    math: "\\acute"
                  },
                  "̀": {
                    text: "\\`",
                    math: "\\grave"
                  },
                  "̈": {
                    text: '\\"',
                    math: "\\ddot"
                  },
                  "̃": {
                    text: "\\~",
                    math: "\\tilde"
                  },
                  "̄": {
                    text: "\\=",
                    math: "\\bar"
                  },
                  "̆": {
                    text: "\\u",
                    math: "\\breve"
                  },
                  "̌": {
                    text: "\\v",
                    math: "\\check"
                  },
                  "̂": {
                    text: "\\^",
                    math: "\\hat"
                  },
                  "̇": {
                    text: "\\.",
                    math: "\\dot"
                  },
                  "̊": {
                    text: "\\r",
                    math: "\\mathring"
                  },
                  "̋": {
                    text: "\\H"
                  }
                };
                var unicodeSymbols = {
                  "á": "á",
                  // á = \'{a}
                  "à": "à",
                  // à = \`{a}
                  "ä": "ä",
                  // ä = \"{a}
                  "ǟ": "ǟ",
                  // ǟ = \"\={a}
                  "ã": "ã",
                  // ã = \~{a}
                  "ā": "ā",
                  // ā = \={a}
                  "ă": "ă",
                  // ă = \u{a}
                  "ắ": "ắ",
                  // ắ = \u\'{a}
                  "ằ": "ằ",
                  // ằ = \u\`{a}
                  "ẵ": "ẵ",
                  // ẵ = \u\~{a}
                  "ǎ": "ǎ",
                  // ǎ = \v{a}
                  "â": "â",
                  // â = \^{a}
                  "ấ": "ấ",
                  // ấ = \^\'{a}
                  "ầ": "ầ",
                  // ầ = \^\`{a}
                  "ẫ": "ẫ",
                  // ẫ = \^\~{a}
                  "ȧ": "ȧ",
                  // ȧ = \.{a}
                  "ǡ": "ǡ",
                  // ǡ = \.\={a}
                  "å": "å",
                  // å = \r{a}
                  "ǻ": "ǻ",
                  // ǻ = \r\'{a}
                  "ḃ": "ḃ",
                  // ḃ = \.{b}
                  "ć": "ć",
                  // ć = \'{c}
                  "č": "č",
                  // č = \v{c}
                  "ĉ": "ĉ",
                  // ĉ = \^{c}
                  "ċ": "ċ",
                  // ċ = \.{c}
                  "ď": "ď",
                  // ď = \v{d}
                  "ḋ": "ḋ",
                  // ḋ = \.{d}
                  "é": "é",
                  // é = \'{e}
                  "è": "è",
                  // è = \`{e}
                  "ë": "ë",
                  // ë = \"{e}
                  "ẽ": "ẽ",
                  // ẽ = \~{e}
                  "ē": "ē",
                  // ē = \={e}
                  "ḗ": "ḗ",
                  // ḗ = \=\'{e}
                  "ḕ": "ḕ",
                  // ḕ = \=\`{e}
                  "ĕ": "ĕ",
                  // ĕ = \u{e}
                  "ě": "ě",
                  // ě = \v{e}
                  "ê": "ê",
                  // ê = \^{e}
                  "ế": "ế",
                  // ế = \^\'{e}
                  "ề": "ề",
                  // ề = \^\`{e}
                  "ễ": "ễ",
                  // ễ = \^\~{e}
                  "ė": "ė",
                  // ė = \.{e}
                  "ḟ": "ḟ",
                  // ḟ = \.{f}
                  "ǵ": "ǵ",
                  // ǵ = \'{g}
                  "ḡ": "ḡ",
                  // ḡ = \={g}
                  "ğ": "ğ",
                  // ğ = \u{g}
                  "ǧ": "ǧ",
                  // ǧ = \v{g}
                  "ĝ": "ĝ",
                  // ĝ = \^{g}
                  "ġ": "ġ",
                  // ġ = \.{g}
                  "ḧ": "ḧ",
                  // ḧ = \"{h}
                  "ȟ": "ȟ",
                  // ȟ = \v{h}
                  "ĥ": "ĥ",
                  // ĥ = \^{h}
                  "ḣ": "ḣ",
                  // ḣ = \.{h}
                  "í": "í",
                  // í = \'{i}
                  "ì": "ì",
                  // ì = \`{i}
                  "ï": "ï",
                  // ï = \"{i}
                  "ḯ": "ḯ",
                  // ḯ = \"\'{i}
                  "ĩ": "ĩ",
                  // ĩ = \~{i}
                  "ī": "ī",
                  // ī = \={i}
                  "ĭ": "ĭ",
                  // ĭ = \u{i}
                  "ǐ": "ǐ",
                  // ǐ = \v{i}
                  "î": "î",
                  // î = \^{i}
                  "ǰ": "ǰ",
                  // ǰ = \v{j}
                  "ĵ": "ĵ",
                  // ĵ = \^{j}
                  "ḱ": "ḱ",
                  // ḱ = \'{k}
                  "ǩ": "ǩ",
                  // ǩ = \v{k}
                  "ĺ": "ĺ",
                  // ĺ = \'{l}
                  "ľ": "ľ",
                  // ľ = \v{l}
                  "ḿ": "ḿ",
                  // ḿ = \'{m}
                  "ṁ": "ṁ",
                  // ṁ = \.{m}
                  "ń": "ń",
                  // ń = \'{n}
                  "ǹ": "ǹ",
                  // ǹ = \`{n}
                  "ñ": "ñ",
                  // ñ = \~{n}
                  "ň": "ň",
                  // ň = \v{n}
                  "ṅ": "ṅ",
                  // ṅ = \.{n}
                  "ó": "ó",
                  // ó = \'{o}
                  "ò": "ò",
                  // ò = \`{o}
                  "ö": "ö",
                  // ö = \"{o}
                  "ȫ": "ȫ",
                  // ȫ = \"\={o}
                  "õ": "õ",
                  // õ = \~{o}
                  "ṍ": "ṍ",
                  // ṍ = \~\'{o}
                  "ṏ": "ṏ",
                  // ṏ = \~\"{o}
                  "ȭ": "ȭ",
                  // ȭ = \~\={o}
                  "ō": "ō",
                  // ō = \={o}
                  "ṓ": "ṓ",
                  // ṓ = \=\'{o}
                  "ṑ": "ṑ",
                  // ṑ = \=\`{o}
                  "ŏ": "ŏ",
                  // ŏ = \u{o}
                  "ǒ": "ǒ",
                  // ǒ = \v{o}
                  "ô": "ô",
                  // ô = \^{o}
                  "ố": "ố",
                  // ố = \^\'{o}
                  "ồ": "ồ",
                  // ồ = \^\`{o}
                  "ỗ": "ỗ",
                  // ỗ = \^\~{o}
                  "ȯ": "ȯ",
                  // ȯ = \.{o}
                  "ȱ": "ȱ",
                  // ȱ = \.\={o}
                  "ő": "ő",
                  // ő = \H{o}
                  "ṕ": "ṕ",
                  // ṕ = \'{p}
                  "ṗ": "ṗ",
                  // ṗ = \.{p}
                  "ŕ": "ŕ",
                  // ŕ = \'{r}
                  "ř": "ř",
                  // ř = \v{r}
                  "ṙ": "ṙ",
                  // ṙ = \.{r}
                  "ś": "ś",
                  // ś = \'{s}
                  "ṥ": "ṥ",
                  // ṥ = \'\.{s}
                  "š": "š",
                  // š = \v{s}
                  "ṧ": "ṧ",
                  // ṧ = \v\.{s}
                  "ŝ": "ŝ",
                  // ŝ = \^{s}
                  "ṡ": "ṡ",
                  // ṡ = \.{s}
                  "ẗ": "ẗ",
                  // ẗ = \"{t}
                  "ť": "ť",
                  // ť = \v{t}
                  "ṫ": "ṫ",
                  // ṫ = \.{t}
                  "ú": "ú",
                  // ú = \'{u}
                  "ù": "ù",
                  // ù = \`{u}
                  "ü": "ü",
                  // ü = \"{u}
                  "ǘ": "ǘ",
                  // ǘ = \"\'{u}
                  "ǜ": "ǜ",
                  // ǜ = \"\`{u}
                  "ǖ": "ǖ",
                  // ǖ = \"\={u}
                  "ǚ": "ǚ",
                  // ǚ = \"\v{u}
                  "ũ": "ũ",
                  // ũ = \~{u}
                  "ṹ": "ṹ",
                  // ṹ = \~\'{u}
                  "ū": "ū",
                  // ū = \={u}
                  "ṻ": "ṻ",
                  // ṻ = \=\"{u}
                  "ŭ": "ŭ",
                  // ŭ = \u{u}
                  "ǔ": "ǔ",
                  // ǔ = \v{u}
                  "û": "û",
                  // û = \^{u}
                  "ů": "ů",
                  // ů = \r{u}
                  "ű": "ű",
                  // ű = \H{u}
                  "ṽ": "ṽ",
                  // ṽ = \~{v}
                  "ẃ": "ẃ",
                  // ẃ = \'{w}
                  "ẁ": "ẁ",
                  // ẁ = \`{w}
                  "ẅ": "ẅ",
                  // ẅ = \"{w}
                  "ŵ": "ŵ",
                  // ŵ = \^{w}
                  "ẇ": "ẇ",
                  // ẇ = \.{w}
                  "ẘ": "ẘ",
                  // ẘ = \r{w}
                  "ẍ": "ẍ",
                  // ẍ = \"{x}
                  "ẋ": "ẋ",
                  // ẋ = \.{x}
                  "ý": "ý",
                  // ý = \'{y}
                  "ỳ": "ỳ",
                  // ỳ = \`{y}
                  "ÿ": "ÿ",
                  // ÿ = \"{y}
                  "ỹ": "ỹ",
                  // ỹ = \~{y}
                  "ȳ": "ȳ",
                  // ȳ = \={y}
                  "ŷ": "ŷ",
                  // ŷ = \^{y}
                  "ẏ": "ẏ",
                  // ẏ = \.{y}
                  "ẙ": "ẙ",
                  // ẙ = \r{y}
                  "ź": "ź",
                  // ź = \'{z}
                  "ž": "ž",
                  // ž = \v{z}
                  "ẑ": "ẑ",
                  // ẑ = \^{z}
                  "ż": "ż",
                  // ż = \.{z}
                  "Á": "Á",
                  // Á = \'{A}
                  "À": "À",
                  // À = \`{A}
                  "Ä": "Ä",
                  // Ä = \"{A}
                  "Ǟ": "Ǟ",
                  // Ǟ = \"\={A}
                  "Ã": "Ã",
                  // Ã = \~{A}
                  "Ā": "Ā",
                  // Ā = \={A}
                  "Ă": "Ă",
                  // Ă = \u{A}
                  "Ắ": "Ắ",
                  // Ắ = \u\'{A}
                  "Ằ": "Ằ",
                  // Ằ = \u\`{A}
                  "Ẵ": "Ẵ",
                  // Ẵ = \u\~{A}
                  "Ǎ": "Ǎ",
                  // Ǎ = \v{A}
                  "Â": "Â",
                  // Â = \^{A}
                  "Ấ": "Ấ",
                  // Ấ = \^\'{A}
                  "Ầ": "Ầ",
                  // Ầ = \^\`{A}
                  "Ẫ": "Ẫ",
                  // Ẫ = \^\~{A}
                  "Ȧ": "Ȧ",
                  // Ȧ = \.{A}
                  "Ǡ": "Ǡ",
                  // Ǡ = \.\={A}
                  "Å": "Å",
                  // Å = \r{A}
                  "Ǻ": "Ǻ",
                  // Ǻ = \r\'{A}
                  "Ḃ": "Ḃ",
                  // Ḃ = \.{B}
                  "Ć": "Ć",
                  // Ć = \'{C}
                  "Č": "Č",
                  // Č = \v{C}
                  "Ĉ": "Ĉ",
                  // Ĉ = \^{C}
                  "Ċ": "Ċ",
                  // Ċ = \.{C}
                  "Ď": "Ď",
                  // Ď = \v{D}
                  "Ḋ": "Ḋ",
                  // Ḋ = \.{D}
                  "É": "É",
                  // É = \'{E}
                  "È": "È",
                  // È = \`{E}
                  "Ë": "Ë",
                  // Ë = \"{E}
                  "Ẽ": "Ẽ",
                  // Ẽ = \~{E}
                  "Ē": "Ē",
                  // Ē = \={E}
                  "Ḗ": "Ḗ",
                  // Ḗ = \=\'{E}
                  "Ḕ": "Ḕ",
                  // Ḕ = \=\`{E}
                  "Ĕ": "Ĕ",
                  // Ĕ = \u{E}
                  "Ě": "Ě",
                  // Ě = \v{E}
                  "Ê": "Ê",
                  // Ê = \^{E}
                  "Ế": "Ế",
                  // Ế = \^\'{E}
                  "Ề": "Ề",
                  // Ề = \^\`{E}
                  "Ễ": "Ễ",
                  // Ễ = \^\~{E}
                  "Ė": "Ė",
                  // Ė = \.{E}
                  "Ḟ": "Ḟ",
                  // Ḟ = \.{F}
                  "Ǵ": "Ǵ",
                  // Ǵ = \'{G}
                  "Ḡ": "Ḡ",
                  // Ḡ = \={G}
                  "Ğ": "Ğ",
                  // Ğ = \u{G}
                  "Ǧ": "Ǧ",
                  // Ǧ = \v{G}
                  "Ĝ": "Ĝ",
                  // Ĝ = \^{G}
                  "Ġ": "Ġ",
                  // Ġ = \.{G}
                  "Ḧ": "Ḧ",
                  // Ḧ = \"{H}
                  "Ȟ": "Ȟ",
                  // Ȟ = \v{H}
                  "Ĥ": "Ĥ",
                  // Ĥ = \^{H}
                  "Ḣ": "Ḣ",
                  // Ḣ = \.{H}
                  "Í": "Í",
                  // Í = \'{I}
                  "Ì": "Ì",
                  // Ì = \`{I}
                  "Ï": "Ï",
                  // Ï = \"{I}
                  "Ḯ": "Ḯ",
                  // Ḯ = \"\'{I}
                  "Ĩ": "Ĩ",
                  // Ĩ = \~{I}
                  "Ī": "Ī",
                  // Ī = \={I}
                  "Ĭ": "Ĭ",
                  // Ĭ = \u{I}
                  "Ǐ": "Ǐ",
                  // Ǐ = \v{I}
                  "Î": "Î",
                  // Î = \^{I}
                  "İ": "İ",
                  // İ = \.{I}
                  "Ĵ": "Ĵ",
                  // Ĵ = \^{J}
                  "Ḱ": "Ḱ",
                  // Ḱ = \'{K}
                  "Ǩ": "Ǩ",
                  // Ǩ = \v{K}
                  "Ĺ": "Ĺ",
                  // Ĺ = \'{L}
                  "Ľ": "Ľ",
                  // Ľ = \v{L}
                  "Ḿ": "Ḿ",
                  // Ḿ = \'{M}
                  "Ṁ": "Ṁ",
                  // Ṁ = \.{M}
                  "Ń": "Ń",
                  // Ń = \'{N}
                  "Ǹ": "Ǹ",
                  // Ǹ = \`{N}
                  "Ñ": "Ñ",
                  // Ñ = \~{N}
                  "Ň": "Ň",
                  // Ň = \v{N}
                  "Ṅ": "Ṅ",
                  // Ṅ = \.{N}
                  "Ó": "Ó",
                  // Ó = \'{O}
                  "Ò": "Ò",
                  // Ò = \`{O}
                  "Ö": "Ö",
                  // Ö = \"{O}
                  "Ȫ": "Ȫ",
                  // Ȫ = \"\={O}
                  "Õ": "Õ",
                  // Õ = \~{O}
                  "Ṍ": "Ṍ",
                  // Ṍ = \~\'{O}
                  "Ṏ": "Ṏ",
                  // Ṏ = \~\"{O}
                  "Ȭ": "Ȭ",
                  // Ȭ = \~\={O}
                  "Ō": "Ō",
                  // Ō = \={O}
                  "Ṓ": "Ṓ",
                  // Ṓ = \=\'{O}
                  "Ṑ": "Ṑ",
                  // Ṑ = \=\`{O}
                  "Ŏ": "Ŏ",
                  // Ŏ = \u{O}
                  "Ǒ": "Ǒ",
                  // Ǒ = \v{O}
                  "Ô": "Ô",
                  // Ô = \^{O}
                  "Ố": "Ố",
                  // Ố = \^\'{O}
                  "Ồ": "Ồ",
                  // Ồ = \^\`{O}
                  "Ỗ": "Ỗ",
                  // Ỗ = \^\~{O}
                  "Ȯ": "Ȯ",
                  // Ȯ = \.{O}
                  "Ȱ": "Ȱ",
                  // Ȱ = \.\={O}
                  "Ő": "Ő",
                  // Ő = \H{O}
                  "Ṕ": "Ṕ",
                  // Ṕ = \'{P}
                  "Ṗ": "Ṗ",
                  // Ṗ = \.{P}
                  "Ŕ": "Ŕ",
                  // Ŕ = \'{R}
                  "Ř": "Ř",
                  // Ř = \v{R}
                  "Ṙ": "Ṙ",
                  // Ṙ = \.{R}
                  "Ś": "Ś",
                  // Ś = \'{S}
                  "Ṥ": "Ṥ",
                  // Ṥ = \'\.{S}
                  "Š": "Š",
                  // Š = \v{S}
                  "Ṧ": "Ṧ",
                  // Ṧ = \v\.{S}
                  "Ŝ": "Ŝ",
                  // Ŝ = \^{S}
                  "Ṡ": "Ṡ",
                  // Ṡ = \.{S}
                  "Ť": "Ť",
                  // Ť = \v{T}
                  "Ṫ": "Ṫ",
                  // Ṫ = \.{T}
                  "Ú": "Ú",
                  // Ú = \'{U}
                  "Ù": "Ù",
                  // Ù = \`{U}
                  "Ü": "Ü",
                  // Ü = \"{U}
                  "Ǘ": "Ǘ",
                  // Ǘ = \"\'{U}
                  "Ǜ": "Ǜ",
                  // Ǜ = \"\`{U}
                  "Ǖ": "Ǖ",
                  // Ǖ = \"\={U}
                  "Ǚ": "Ǚ",
                  // Ǚ = \"\v{U}
                  "Ũ": "Ũ",
                  // Ũ = \~{U}
                  "Ṹ": "Ṹ",
                  // Ṹ = \~\'{U}
                  "Ū": "Ū",
                  // Ū = \={U}
                  "Ṻ": "Ṻ",
                  // Ṻ = \=\"{U}
                  "Ŭ": "Ŭ",
                  // Ŭ = \u{U}
                  "Ǔ": "Ǔ",
                  // Ǔ = \v{U}
                  "Û": "Û",
                  // Û = \^{U}
                  "Ů": "Ů",
                  // Ů = \r{U}
                  "Ű": "Ű",
                  // Ű = \H{U}
                  "Ṽ": "Ṽ",
                  // Ṽ = \~{V}
                  "Ẃ": "Ẃ",
                  // Ẃ = \'{W}
                  "Ẁ": "Ẁ",
                  // Ẁ = \`{W}
                  "Ẅ": "Ẅ",
                  // Ẅ = \"{W}
                  "Ŵ": "Ŵ",
                  // Ŵ = \^{W}
                  "Ẇ": "Ẇ",
                  // Ẇ = \.{W}
                  "Ẍ": "Ẍ",
                  // Ẍ = \"{X}
                  "Ẋ": "Ẋ",
                  // Ẋ = \.{X}
                  "Ý": "Ý",
                  // Ý = \'{Y}
                  "Ỳ": "Ỳ",
                  // Ỳ = \`{Y}
                  "Ÿ": "Ÿ",
                  // Ÿ = \"{Y}
                  "Ỹ": "Ỹ",
                  // Ỹ = \~{Y}
                  "Ȳ": "Ȳ",
                  // Ȳ = \={Y}
                  "Ŷ": "Ŷ",
                  // Ŷ = \^{Y}
                  "Ẏ": "Ẏ",
                  // Ẏ = \.{Y}
                  "Ź": "Ź",
                  // Ź = \'{Z}
                  "Ž": "Ž",
                  // Ž = \v{Z}
                  "Ẑ": "Ẑ",
                  // Ẑ = \^{Z}
                  "Ż": "Ż",
                  // Ż = \.{Z}
                  "ά": "ά",
                  // ά = \'{α}
                  "ὰ": "ὰ",
                  // ὰ = \`{α}
                  "ᾱ": "ᾱ",
                  // ᾱ = \={α}
                  "ᾰ": "ᾰ",
                  // ᾰ = \u{α}
                  "έ": "έ",
                  // έ = \'{ε}
                  "ὲ": "ὲ",
                  // ὲ = \`{ε}
                  "ή": "ή",
                  // ή = \'{η}
                  "ὴ": "ὴ",
                  // ὴ = \`{η}
                  "ί": "ί",
                  // ί = \'{ι}
                  "ὶ": "ὶ",
                  // ὶ = \`{ι}
                  "ϊ": "ϊ",
                  // ϊ = \"{ι}
                  "ΐ": "ΐ",
                  // ΐ = \"\'{ι}
                  "ῒ": "ῒ",
                  // ῒ = \"\`{ι}
                  "ῑ": "ῑ",
                  // ῑ = \={ι}
                  "ῐ": "ῐ",
                  // ῐ = \u{ι}
                  "ό": "ό",
                  // ό = \'{ο}
                  "ὸ": "ὸ",
                  // ὸ = \`{ο}
                  "ύ": "ύ",
                  // ύ = \'{υ}
                  "ὺ": "ὺ",
                  // ὺ = \`{υ}
                  "ϋ": "ϋ",
                  // ϋ = \"{υ}
                  "ΰ": "ΰ",
                  // ΰ = \"\'{υ}
                  "ῢ": "ῢ",
                  // ῢ = \"\`{υ}
                  "ῡ": "ῡ",
                  // ῡ = \={υ}
                  "ῠ": "ῠ",
                  // ῠ = \u{υ}
                  "ώ": "ώ",
                  // ώ = \'{ω}
                  "ὼ": "ὼ",
                  // ὼ = \`{ω}
                  "Ύ": "Ύ",
                  // Ύ = \'{Υ}
                  "Ὺ": "Ὺ",
                  // Ὺ = \`{Υ}
                  "Ϋ": "Ϋ",
                  // Ϋ = \"{Υ}
                  "Ῡ": "Ῡ",
                  // Ῡ = \={Υ}
                  "Ῠ": "Ῠ",
                  // Ῠ = \u{Υ}
                  "Ώ": "Ώ",
                  // Ώ = \'{Ω}
                  "Ὼ": "Ὼ"
                  // Ὼ = \`{Ω}
                };
                var Parser_Parser = function() {
                  function Parser(input, settings) {
                    this.mode = void 0;
                    this.gullet = void 0;
                    this.settings = void 0;
                    this.leftrightDepth = void 0;
                    this.nextToken = void 0;
                    this.mode = "math";
                    this.gullet = new MacroExpander_MacroExpander(input, settings, this.mode);
                    this.settings = settings;
                    this.leftrightDepth = 0;
                  }
                  var _proto = Parser.prototype;
                  _proto.expect = function expect(text, consume) {
                    if (consume === void 0) {
                      consume = true;
                    }
                    if (this.nextToken.text !== text) {
                      throw new src_ParseError("Expected '" + text + "', got '" + this.nextToken.text + "'", this.nextToken);
                    }
                    if (consume) {
                      this.consume();
                    }
                  };
                  _proto.consume = function consume() {
                    this.nextToken = this.gullet.expandNextToken();
                  };
                  _proto.switchMode = function switchMode(newMode) {
                    this.mode = newMode;
                    this.gullet.switchMode(newMode);
                  };
                  _proto.parse = function parse() {
                    this.gullet.beginGroup();
                    if (this.settings.colorIsTextColor) {
                      this.gullet.macros.set("\\color", "\\textcolor");
                    }
                    this.consume();
                    var parse2 = this.parseExpression(false);
                    this.expect("EOF", false);
                    this.gullet.endGroup();
                    return parse2;
                  };
                  _proto.parseExpression = function parseExpression(breakOnInfix, breakOnTokenText) {
                    var body = [];
                    while (true) {
                      if (this.mode === "math") {
                        this.consumeSpaces();
                      }
                      var lex = this.nextToken;
                      if (Parser.endOfExpression.indexOf(lex.text) !== -1) {
                        break;
                      }
                      if (breakOnTokenText && lex.text === breakOnTokenText) {
                        break;
                      }
                      if (breakOnInfix && src_functions[lex.text] && src_functions[lex.text].infix) {
                        break;
                      }
                      var atom = this.parseAtom(breakOnTokenText);
                      if (!atom) {
                        break;
                      }
                      body.push(atom);
                    }
                    if (this.mode === "text") {
                      this.formLigatures(body);
                    }
                    return this.handleInfixNodes(body);
                  };
                  _proto.handleInfixNodes = function handleInfixNodes(body) {
                    var overIndex = -1;
                    var funcName;
                    for (var i = 0; i < body.length; i++) {
                      var node = checkNodeType(body[i], "infix");
                      if (node) {
                        if (overIndex !== -1) {
                          throw new src_ParseError("only one infix operator per group", node.token);
                        }
                        overIndex = i;
                        funcName = node.replaceWith;
                      }
                    }
                    if (overIndex !== -1 && funcName) {
                      var numerNode;
                      var denomNode;
                      var numerBody = body.slice(0, overIndex);
                      var denomBody = body.slice(overIndex + 1);
                      if (numerBody.length === 1 && numerBody[0].type === "ordgroup") {
                        numerNode = numerBody[0];
                      } else {
                        numerNode = {
                          type: "ordgroup",
                          mode: this.mode,
                          body: numerBody
                        };
                      }
                      if (denomBody.length === 1 && denomBody[0].type === "ordgroup") {
                        denomNode = denomBody[0];
                      } else {
                        denomNode = {
                          type: "ordgroup",
                          mode: this.mode,
                          body: denomBody
                        };
                      }
                      var _node;
                      if (funcName === "\\\\abovefrac") {
                        _node = this.callFunction(funcName, [numerNode, body[overIndex], denomNode], []);
                      } else {
                        _node = this.callFunction(funcName, [numerNode, denomNode], []);
                      }
                      return [_node];
                    } else {
                      return body;
                    }
                  };
                  _proto.handleSupSubscript = function handleSupSubscript(name) {
                    var symbolToken = this.nextToken;
                    var symbol = symbolToken.text;
                    this.consume();
                    this.consumeSpaces();
                    var group = this.parseGroup(name, false, Parser.SUPSUB_GREEDINESS);
                    if (!group) {
                      throw new src_ParseError("Expected group after '" + symbol + "'", symbolToken);
                    }
                    return group;
                  };
                  _proto.handleUnsupportedCmd = function handleUnsupportedCmd() {
                    var text = this.nextToken.text;
                    var textordArray = [];
                    for (var i = 0; i < text.length; i++) {
                      textordArray.push({
                        type: "textord",
                        mode: "text",
                        text: text[i]
                      });
                    }
                    var textNode = {
                      type: "text",
                      mode: this.mode,
                      body: textordArray
                    };
                    var colorNode = {
                      type: "color",
                      mode: this.mode,
                      color: this.settings.errorColor,
                      body: [textNode]
                    };
                    this.consume();
                    return colorNode;
                  };
                  _proto.parseAtom = function parseAtom(breakOnTokenText) {
                    var base = this.parseGroup("atom", false, null, breakOnTokenText);
                    if (this.mode === "text") {
                      return base;
                    }
                    var superscript;
                    var subscript;
                    while (true) {
                      this.consumeSpaces();
                      var lex = this.nextToken;
                      if (lex.text === "\\limits" || lex.text === "\\nolimits") {
                        var opNode = checkNodeType(base, "op");
                        if (opNode) {
                          var limits = lex.text === "\\limits";
                          opNode.limits = limits;
                          opNode.alwaysHandleSupSub = true;
                        } else {
                          throw new src_ParseError("Limit controls must follow a math operator", lex);
                        }
                        this.consume();
                      } else if (lex.text === "^") {
                        if (superscript) {
                          throw new src_ParseError("Double superscript", lex);
                        }
                        superscript = this.handleSupSubscript("superscript");
                      } else if (lex.text === "_") {
                        if (subscript) {
                          throw new src_ParseError("Double subscript", lex);
                        }
                        subscript = this.handleSupSubscript("subscript");
                      } else if (lex.text === "'") {
                        if (superscript) {
                          throw new src_ParseError("Double superscript", lex);
                        }
                        var prime = {
                          type: "textord",
                          mode: this.mode,
                          text: "\\prime"
                        };
                        var primes = [prime];
                        this.consume();
                        while (this.nextToken.text === "'") {
                          primes.push(prime);
                          this.consume();
                        }
                        if (this.nextToken.text === "^") {
                          primes.push(this.handleSupSubscript("superscript"));
                        }
                        superscript = {
                          type: "ordgroup",
                          mode: this.mode,
                          body: primes
                        };
                      } else if (lex.text === "%") {
                        this.consumeComment();
                      } else {
                        break;
                      }
                    }
                    if (superscript || subscript) {
                      return {
                        type: "supsub",
                        mode: this.mode,
                        base,
                        sup: superscript,
                        sub: subscript
                      };
                    } else {
                      return base;
                    }
                  };
                  _proto.parseFunction = function parseFunction(breakOnTokenText, name, greediness) {
                    var token = this.nextToken;
                    var func = token.text;
                    var funcData = src_functions[func];
                    if (!funcData) {
                      return null;
                    }
                    if (greediness != null && funcData.greediness <= greediness) {
                      throw new src_ParseError("Got function '" + func + "' with no arguments" + (name ? " as " + name : ""), token);
                    } else if (this.mode === "text" && !funcData.allowedInText) {
                      throw new src_ParseError("Can't use function '" + func + "' in text mode", token);
                    } else if (this.mode === "math" && funcData.allowedInMath === false) {
                      throw new src_ParseError("Can't use function '" + func + "' in math mode", token);
                    }
                    if (funcData.consumeMode) {
                      var oldMode = this.mode;
                      this.switchMode(funcData.consumeMode);
                      this.consume();
                      this.switchMode(oldMode);
                    } else {
                      this.consume();
                    }
                    var _this$parseArguments = this.parseArguments(func, funcData), args = _this$parseArguments.args, optArgs = _this$parseArguments.optArgs;
                    return this.callFunction(func, args, optArgs, token, breakOnTokenText);
                  };
                  _proto.callFunction = function callFunction(name, args, optArgs, token, breakOnTokenText) {
                    var context = {
                      funcName: name,
                      parser: this,
                      token,
                      breakOnTokenText
                    };
                    var func = src_functions[name];
                    if (func && func.handler) {
                      return func.handler(context, args, optArgs);
                    } else {
                      throw new src_ParseError("No function handler for " + name);
                    }
                  };
                  _proto.parseArguments = function parseArguments(func, funcData) {
                    var totalArgs = funcData.numArgs + funcData.numOptionalArgs;
                    if (totalArgs === 0) {
                      return {
                        args: [],
                        optArgs: []
                      };
                    }
                    var baseGreediness = funcData.greediness;
                    var args = [];
                    var optArgs = [];
                    for (var i = 0; i < totalArgs; i++) {
                      var argType = funcData.argTypes && funcData.argTypes[i];
                      var isOptional = i < funcData.numOptionalArgs;
                      if (i > 0 && !isOptional) {
                        this.consumeSpaces();
                      }
                      if (i === 0 && !isOptional && this.mode === "math") {
                        this.consumeSpaces();
                      }
                      var nextToken = this.nextToken;
                      var arg = this.parseGroupOfType("argument to '" + func + "'", argType, isOptional, baseGreediness);
                      if (!arg) {
                        if (isOptional) {
                          optArgs.push(null);
                          continue;
                        }
                        throw new src_ParseError("Expected group after '" + func + "'", nextToken);
                      }
                      (isOptional ? optArgs : args).push(arg);
                    }
                    return {
                      args,
                      optArgs
                    };
                  };
                  _proto.parseGroupOfType = function parseGroupOfType(name, type, optional, greediness) {
                    switch (type) {
                      case "color":
                        return this.parseColorGroup(optional);
                      case "size":
                        return this.parseSizeGroup(optional);
                      case "url":
                        return this.parseUrlGroup(optional);
                      case "math":
                      case "text":
                        return this.parseGroup(name, optional, greediness, void 0, type);
                      case "original":
                      case null:
                      case void 0:
                        return this.parseGroup(name, optional, greediness);
                      default:
                        throw new src_ParseError("Unknown group type as " + name, this.nextToken);
                    }
                  };
                  _proto.consumeSpaces = function consumeSpaces() {
                    while (this.nextToken.text === " ") {
                      this.consume();
                    }
                  };
                  _proto.consumeComment = function consumeComment() {
                    while (this.nextToken.text !== "EOF" && this.nextToken.loc && this.nextToken.loc.getSource().indexOf("\n") === -1) {
                      this.consume();
                    }
                    if (this.nextToken.text === "EOF") {
                      this.settings.reportNonstrict("commentAtEnd", "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)");
                    }
                    if (this.mode === "math") {
                      this.consumeSpaces();
                    } else if (this.nextToken.loc) {
                      var source = this.nextToken.loc.getSource();
                      if (source.indexOf("\n") === source.length - 1) {
                        this.consumeSpaces();
                      }
                    }
                  };
                  _proto.parseStringGroup = function parseStringGroup(modeName, optional, raw) {
                    var groupBegin = optional ? "[" : "{";
                    var groupEnd = optional ? "]" : "}";
                    var nextToken = this.nextToken;
                    if (nextToken.text !== groupBegin) {
                      if (optional) {
                        return null;
                      } else if (raw && nextToken.text !== "EOF" && /[^{}[\]]/.test(nextToken.text)) {
                        this.consume();
                        return nextToken;
                      }
                    }
                    var outerMode = this.mode;
                    this.mode = "text";
                    this.expect(groupBegin);
                    var str = "";
                    var firstToken = this.nextToken;
                    var nested = 0;
                    var lastToken = firstToken;
                    while (raw && nested > 0 || this.nextToken.text !== groupEnd) {
                      switch (this.nextToken.text) {
                        case "EOF":
                          throw new src_ParseError("Unexpected end of input in " + modeName, firstToken.range(lastToken, str));
                        case "%":
                          if (!raw) {
                            this.consumeComment();
                            continue;
                          }
                          break;
                        case groupBegin:
                          nested++;
                          break;
                        case groupEnd:
                          nested--;
                          break;
                      }
                      lastToken = this.nextToken;
                      str += lastToken.text;
                      this.consume();
                    }
                    this.mode = outerMode;
                    this.expect(groupEnd);
                    return firstToken.range(lastToken, str);
                  };
                  _proto.parseRegexGroup = function parseRegexGroup(regex, modeName) {
                    var outerMode = this.mode;
                    this.mode = "text";
                    var firstToken = this.nextToken;
                    var lastToken = firstToken;
                    var str = "";
                    while (this.nextToken.text !== "EOF" && (regex.test(str + this.nextToken.text) || this.nextToken.text === "%")) {
                      if (this.nextToken.text === "%") {
                        this.consumeComment();
                        continue;
                      }
                      lastToken = this.nextToken;
                      str += lastToken.text;
                      this.consume();
                    }
                    if (str === "") {
                      throw new src_ParseError("Invalid " + modeName + ": '" + firstToken.text + "'", firstToken);
                    }
                    this.mode = outerMode;
                    return firstToken.range(lastToken, str);
                  };
                  _proto.parseColorGroup = function parseColorGroup(optional) {
                    var res = this.parseStringGroup("color", optional);
                    if (!res) {
                      return null;
                    }
                    var match = /^(#[a-f0-9]{3}|#?[a-f0-9]{6}|[a-z]+)$/i.exec(res.text);
                    if (!match) {
                      throw new src_ParseError("Invalid color: '" + res.text + "'", res);
                    }
                    var color = match[0];
                    if (/^[0-9a-f]{6}$/i.test(color)) {
                      color = "#" + color;
                    }
                    return {
                      type: "color-token",
                      mode: this.mode,
                      color
                    };
                  };
                  _proto.parseSizeGroup = function parseSizeGroup(optional) {
                    var res;
                    var isBlank = false;
                    if (!optional && this.nextToken.text !== "{") {
                      res = this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size");
                    } else {
                      res = this.parseStringGroup("size", optional);
                    }
                    if (!res) {
                      return null;
                    }
                    if (!optional && res.text.length === 0) {
                      res.text = "0pt";
                      isBlank = true;
                    }
                    var match = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(res.text);
                    if (!match) {
                      throw new src_ParseError("Invalid size: '" + res.text + "'", res);
                    }
                    var data = {
                      number: +(match[1] + match[2]),
                      // sign + magnitude, cast to number
                      unit: match[3]
                    };
                    if (!validUnit(data)) {
                      throw new src_ParseError("Invalid unit: '" + data.unit + "'", res);
                    }
                    return {
                      type: "size",
                      mode: this.mode,
                      value: data,
                      isBlank
                    };
                  };
                  _proto.parseUrlGroup = function parseUrlGroup(optional) {
                    var res = this.parseStringGroup("url", optional, true);
                    if (!res) {
                      return null;
                    }
                    var url = res.text.replace(/\\([#$%&~_^{}])/g, "$1");
                    var protocol = /^\s*([^\\/#]*?)(?::|&#0*58|&#x0*3a)/i.exec(url);
                    protocol = protocol != null ? protocol[1] : "_relative";
                    var allowed = this.settings.allowedProtocols;
                    if (!utils.contains(allowed, "*") && !utils.contains(allowed, protocol)) {
                      throw new src_ParseError("Forbidden protocol '" + protocol + "'", res);
                    }
                    return {
                      type: "url",
                      mode: this.mode,
                      url
                    };
                  };
                  _proto.parseGroup = function parseGroup(name, optional, greediness, breakOnTokenText, mode) {
                    var outerMode = this.mode;
                    var firstToken = this.nextToken;
                    var text = firstToken.text;
                    if (mode) {
                      this.switchMode(mode);
                    }
                    var result;
                    if (text === (optional ? "[" : "{")) {
                      this.gullet.beginGroup();
                      this.consume();
                      var expression = this.parseExpression(false, optional ? "]" : "}");
                      var lastToken = this.nextToken;
                      if (mode) {
                        this.switchMode(outerMode);
                      }
                      this.gullet.endGroup();
                      this.expect(optional ? "]" : "}");
                      return {
                        type: "ordgroup",
                        mode: this.mode,
                        loc: SourceLocation.range(firstToken, lastToken),
                        body: expression
                      };
                    } else if (optional) {
                      result = null;
                    } else {
                      result = this.parseFunction(breakOnTokenText, name, greediness) || this.parseSymbol();
                      if (result == null && text[0] === "\\" && !implicitCommands.hasOwnProperty(text)) {
                        if (this.settings.throwOnError) {
                          throw new src_ParseError("Undefined control sequence: " + text, firstToken);
                        }
                        result = this.handleUnsupportedCmd();
                      }
                    }
                    if (mode) {
                      this.switchMode(outerMode);
                    }
                    return result;
                  };
                  _proto.formLigatures = function formLigatures(group) {
                    var n = group.length - 1;
                    for (var i = 0; i < n; ++i) {
                      var a = group[i];
                      var v = a.text;
                      if (v === "-" && group[i + 1].text === "-") {
                        if (i + 1 < n && group[i + 2].text === "-") {
                          group.splice(i, 3, {
                            type: "textord",
                            mode: "text",
                            loc: SourceLocation.range(a, group[i + 2]),
                            text: "---"
                          });
                          n -= 2;
                        } else {
                          group.splice(i, 2, {
                            type: "textord",
                            mode: "text",
                            loc: SourceLocation.range(a, group[i + 1]),
                            text: "--"
                          });
                          n -= 1;
                        }
                      }
                      if ((v === "'" || v === "`") && group[i + 1].text === v) {
                        group.splice(i, 2, {
                          type: "textord",
                          mode: "text",
                          loc: SourceLocation.range(a, group[i + 1]),
                          text: v + v
                        });
                        n -= 1;
                      }
                    }
                  };
                  _proto.parseSymbol = function parseSymbol() {
                    var nucleus = this.nextToken;
                    var text = nucleus.text;
                    if (/^\\verb[^a-zA-Z]/.test(text)) {
                      this.consume();
                      var arg = text.slice(5);
                      var star = arg.charAt(0) === "*";
                      if (star) {
                        arg = arg.slice(1);
                      }
                      if (arg.length < 2 || arg.charAt(0) !== arg.slice(-1)) {
                        throw new src_ParseError("\\verb assertion failed --\n                    please report what input caused this bug");
                      }
                      arg = arg.slice(1, -1);
                      return {
                        type: "verb",
                        mode: "text",
                        body: arg,
                        star
                      };
                    } else if (text === "%") {
                      this.consumeComment();
                      return this.parseSymbol();
                    }
                    if (unicodeSymbols.hasOwnProperty(text[0]) && !src_symbols[this.mode][text[0]]) {
                      if (this.settings.strict && this.mode === "math") {
                        this.settings.reportNonstrict("unicodeTextInMathMode", 'Accented Unicode text character "' + text[0] + '" used in math mode', nucleus);
                      }
                      text = unicodeSymbols[text[0]] + text.substr(1);
                    }
                    var match = combiningDiacriticalMarksEndRegex.exec(text);
                    if (match) {
                      text = text.substring(0, match.index);
                      if (text === "i") {
                        text = "ı";
                      } else if (text === "j") {
                        text = "ȷ";
                      }
                    }
                    var symbol;
                    if (src_symbols[this.mode][text]) {
                      if (this.settings.strict && this.mode === "math" && extraLatin.indexOf(text) >= 0) {
                        this.settings.reportNonstrict("unicodeTextInMathMode", 'Latin-1/Unicode text character "' + text[0] + '" used in math mode', nucleus);
                      }
                      var group = src_symbols[this.mode][text].group;
                      var loc = SourceLocation.range(nucleus);
                      var s;
                      if (ATOMS.hasOwnProperty(group)) {
                        var family = group;
                        s = {
                          type: "atom",
                          mode: this.mode,
                          family,
                          loc,
                          text
                        };
                      } else {
                        s = {
                          type: group,
                          mode: this.mode,
                          loc,
                          text
                        };
                      }
                      symbol = s;
                    } else if (text.charCodeAt(0) >= 128) {
                      if (this.settings.strict) {
                        if (!supportedCodepoint(text.charCodeAt(0))) {
                          this.settings.reportNonstrict("unknownSymbol", 'Unrecognized Unicode character "' + text[0] + '"' + (" (" + text.charCodeAt(0) + ")"), nucleus);
                        } else if (this.mode === "math") {
                          this.settings.reportNonstrict("unicodeTextInMathMode", 'Unicode text character "' + text[0] + '" used in math mode', nucleus);
                        }
                      }
                      symbol = {
                        type: "textord",
                        mode: this.mode,
                        loc: SourceLocation.range(nucleus),
                        text
                      };
                    } else {
                      return null;
                    }
                    this.consume();
                    if (match) {
                      for (var i = 0; i < match[0].length; i++) {
                        var accent = match[0][i];
                        if (!unicodeAccents[accent]) {
                          throw new src_ParseError("Unknown accent ' " + accent + "'", nucleus);
                        }
                        var command = unicodeAccents[accent][this.mode];
                        if (!command) {
                          throw new src_ParseError("Accent " + accent + " unsupported in " + this.mode + " mode", nucleus);
                        }
                        symbol = {
                          type: "accent",
                          mode: this.mode,
                          loc: SourceLocation.range(nucleus),
                          label: command,
                          isStretchy: false,
                          isShifty: true,
                          base: symbol
                        };
                      }
                    }
                    return symbol;
                  };
                  return Parser;
                }();
                Parser_Parser.endOfExpression = ["}", "\\end", "\\right", "&"];
                Parser_Parser.SUPSUB_GREEDINESS = 1;
                var parseTree_parseTree = function parseTree(toParse, settings) {
                  if (!(typeof toParse === "string" || toParse instanceof String)) {
                    throw new TypeError("KaTeX can only parse string typed expression");
                  }
                  var parser = new Parser_Parser(toParse, settings);
                  delete parser.gullet.macros.current["\\df@tag"];
                  var tree = parser.parse();
                  if (parser.gullet.macros.get("\\df@tag")) {
                    if (!settings.displayMode) {
                      throw new src_ParseError("\\tag works only in display equations");
                    }
                    parser.gullet.feed("\\df@tag");
                    tree = [{
                      type: "tag",
                      mode: "text",
                      body: tree,
                      tag: parser.parse()
                    }];
                  }
                  return tree;
                };
                var src_parseTree = parseTree_parseTree;
                var katex_render = function render(expression, baseNode, options) {
                  baseNode.textContent = "";
                  var node = katex_renderToDomTree(expression, options).toNode();
                  baseNode.appendChild(node);
                };
                if (typeof document !== "undefined") {
                  if (document.compatMode !== "CSS1Compat") {
                    typeof console !== "undefined" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype.");
                    katex_render = function render() {
                      throw new src_ParseError("KaTeX doesn't work in quirks mode.");
                    };
                  }
                }
                var renderToString = function renderToString2(expression, options) {
                  var markup = katex_renderToDomTree(expression, options).toMarkup();
                  return markup;
                };
                var katex_generateParseTree = function generateParseTree(expression, options) {
                  var settings = new src_Settings(options);
                  return src_parseTree(expression, settings);
                };
                var katex_renderError = function renderError(error, expression, options) {
                  if (options.throwOnError || !(error instanceof src_ParseError)) {
                    throw error;
                  }
                  var node = buildCommon.makeSpan(["katex-error"], [new domTree_SymbolNode(expression)]);
                  node.setAttribute("title", error.toString());
                  node.setAttribute("style", "color:" + options.errorColor);
                  return node;
                };
                var katex_renderToDomTree = function renderToDomTree(expression, options) {
                  var settings = new src_Settings(options);
                  try {
                    var tree = src_parseTree(expression, settings);
                    return buildTree_buildTree(tree, expression, settings);
                  } catch (error) {
                    return katex_renderError(error, expression, settings);
                  }
                };
                var katex_renderToHTMLTree = function renderToHTMLTree(expression, options) {
                  var settings = new src_Settings(options);
                  try {
                    var tree = src_parseTree(expression, settings);
                    return buildTree_buildHTMLTree(tree, expression, settings);
                  } catch (error) {
                    return katex_renderError(error, expression, settings);
                  }
                };
                var katex_0 = {
                  /**
                   * Current KaTeX version
                   */
                  version: "0.10.0",
                  /**
                   * Renders the given LaTeX into an HTML+MathML combination, and adds
                   * it as a child to the specified DOM node.
                   */
                  render: katex_render,
                  /**
                   * Renders the given LaTeX into an HTML+MathML combination string,
                   * for sending to the client.
                   */
                  renderToString,
                  /**
                   * KaTeX error, usually during parsing.
                   */
                  ParseError: src_ParseError,
                  /**
                   * Parses the given LaTeX into KaTeX's internal parse tree structure,
                   * without rendering to HTML or MathML.
                   *
                   * NOTE: This method is not currently recommended for public use.
                   * The internal tree representation is unstable and is very likely
                   * to change. Use at your own risk.
                   */
                  __parse: katex_generateParseTree,
                  /**
                   * Renders the given LaTeX into an HTML+MathML internal DOM tree
                   * representation, without flattening that representation to a string.
                   *
                   * NOTE: This method is not currently recommended for public use.
                   * The internal tree representation is unstable and is very likely
                   * to change. Use at your own risk.
                   */
                  __renderToDomTree: katex_renderToDomTree,
                  /**
                   * Renders the given LaTeX into an HTML internal DOM tree representation,
                   * without MathML and without flattening that representation to a string.
                   *
                   * NOTE: This method is not currently recommended for public use.
                   * The internal tree representation is unstable and is very likely
                   * to change. Use at your own risk.
                   */
                  __renderToHTMLTree: katex_renderToHTMLTree,
                  /**
                   * extends internal font metrics object with a new object
                   * each key in the new object represents a font name
                  */
                  __setFontMetrics: setFontMetrics,
                  /**
                   * adds a new symbol to builtin symbols table
                   */
                  __defineSymbol: defineSymbol,
                  /**
                   * adds a new macro to builtin macro list
                   */
                  __defineMacro: defineMacro,
                  /**
                   * Expose the dom tree node types, which can be useful for type checking nodes.
                   *
                   * NOTE: This method is not currently recommended for public use.
                   * The internal tree representation is unstable and is very likely
                   * to change. Use at your own risk.
                   */
                  __domTree: {
                    Span: domTree_Span,
                    Anchor: domTree_Anchor,
                    SymbolNode: domTree_SymbolNode,
                    SvgNode,
                    PathNode: domTree_PathNode,
                    LineNode
                  }
                };
                var katex_webpack = __webpack_exports__["default"] = katex_0;
              }
              /******/
            ])["default"]
          );
        });
      });
      var katex$1 = unwrapExports(katex);
      var autoRender = createCommonjsModule(function(module2, exports2) {
        (function webpackUniversalModuleDefinition(root, factory) {
          module2.exports = factory(katex);
        })(typeof self !== "undefined" ? self : commonjsGlobal, function(__WEBPACK_EXTERNAL_MODULE__0__) {
          return (
            /******/
            function(modules) {
              var installedModules = {};
              function __webpack_require__(moduleId) {
                if (installedModules[moduleId]) {
                  return installedModules[moduleId].exports;
                }
                var module3 = installedModules[moduleId] = {
                  /******/
                  i: moduleId,
                  /******/
                  l: false,
                  /******/
                  exports: {}
                  /******/
                };
                modules[moduleId].call(module3.exports, module3, module3.exports, __webpack_require__);
                module3.l = true;
                return module3.exports;
              }
              __webpack_require__.m = modules;
              __webpack_require__.c = installedModules;
              __webpack_require__.d = function(exports3, name, getter) {
                if (!__webpack_require__.o(exports3, name)) {
                  Object.defineProperty(exports3, name, { enumerable: true, get: getter });
                }
              };
              __webpack_require__.r = function(exports3) {
                if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
                  Object.defineProperty(exports3, Symbol.toStringTag, { value: "Module" });
                }
                Object.defineProperty(exports3, "__esModule", { value: true });
              };
              __webpack_require__.t = function(value, mode) {
                if (mode & 1)
                  value = __webpack_require__(value);
                if (mode & 8)
                  return value;
                if (mode & 4 && typeof value === "object" && value && value.__esModule)
                  return value;
                var ns = /* @__PURE__ */ Object.create(null);
                __webpack_require__.r(ns);
                Object.defineProperty(ns, "default", { enumerable: true, value });
                if (mode & 2 && typeof value != "string")
                  for (var key in value)
                    __webpack_require__.d(ns, key, (function(key2) {
                      return value[key2];
                    }).bind(null, key));
                return ns;
              };
              __webpack_require__.n = function(module3) {
                var getter = module3 && module3.__esModule ? (
                  /******/
                  function getDefault() {
                    return module3["default"];
                  }
                ) : (
                  /******/
                  function getModuleExports() {
                    return module3;
                  }
                );
                __webpack_require__.d(getter, "a", getter);
                return getter;
              };
              __webpack_require__.o = function(object, property) {
                return Object.prototype.hasOwnProperty.call(object, property);
              };
              __webpack_require__.p = "";
              return __webpack_require__(__webpack_require__.s = 1);
            }([
              /* 0 */
              /***/
              function(module3, exports3) {
                module3.exports = __WEBPACK_EXTERNAL_MODULE__0__;
              },
              /* 1 */
              /***/
              function(module3, __webpack_exports__, __webpack_require__) {
                "use strict";
                __webpack_require__.r(__webpack_exports__);
                var external_katex_ = __webpack_require__(0);
                var external_katex_default = __webpack_require__.n(external_katex_);
                var findEndOfMath = function findEndOfMath2(delimiter, text, startIndex) {
                  var index = startIndex;
                  var braceLevel = 0;
                  var delimLength = delimiter.length;
                  while (index < text.length) {
                    var character = text[index];
                    if (braceLevel <= 0 && text.slice(index, index + delimLength) === delimiter) {
                      return index;
                    } else if (character === "\\") {
                      index++;
                    } else if (character === "{") {
                      braceLevel++;
                    } else if (character === "}") {
                      braceLevel--;
                    }
                    index++;
                  }
                  return -1;
                };
                var splitAtDelimiters = function splitAtDelimiters2(startData, leftDelim, rightDelim, display) {
                  var finalData = [];
                  for (var i = 0; i < startData.length; i++) {
                    if (startData[i].type === "text") {
                      var text = startData[i].data;
                      var lookingForLeft = true;
                      var currIndex = 0;
                      var nextIndex = void 0;
                      nextIndex = text.indexOf(leftDelim);
                      if (nextIndex !== -1) {
                        currIndex = nextIndex;
                        finalData.push({
                          type: "text",
                          data: text.slice(0, currIndex)
                        });
                        lookingForLeft = false;
                      }
                      while (true) {
                        if (lookingForLeft) {
                          nextIndex = text.indexOf(leftDelim, currIndex);
                          if (nextIndex === -1) {
                            break;
                          }
                          finalData.push({
                            type: "text",
                            data: text.slice(currIndex, nextIndex)
                          });
                          currIndex = nextIndex;
                        } else {
                          nextIndex = findEndOfMath(rightDelim, text, currIndex + leftDelim.length);
                          if (nextIndex === -1) {
                            break;
                          }
                          finalData.push({
                            type: "math",
                            data: text.slice(currIndex + leftDelim.length, nextIndex),
                            rawData: text.slice(currIndex, nextIndex + rightDelim.length),
                            display
                          });
                          currIndex = nextIndex + rightDelim.length;
                        }
                        lookingForLeft = !lookingForLeft;
                      }
                      finalData.push({
                        type: "text",
                        data: text.slice(currIndex)
                      });
                    } else {
                      finalData.push(startData[i]);
                    }
                  }
                  return finalData;
                };
                var auto_render_splitAtDelimiters = splitAtDelimiters;
                var auto_render_splitWithDelimiters = function splitWithDelimiters(text, delimiters) {
                  var data = [{
                    type: "text",
                    data: text
                  }];
                  for (var i = 0; i < delimiters.length; i++) {
                    var delimiter = delimiters[i];
                    data = auto_render_splitAtDelimiters(data, delimiter.left, delimiter.right, delimiter.display || false);
                  }
                  return data;
                };
                var auto_render_renderMathInText = function renderMathInText(text, optionsCopy) {
                  var data = auto_render_splitWithDelimiters(text, optionsCopy.delimiters);
                  var fragment = document.createDocumentFragment();
                  for (var i = 0; i < data.length; i++) {
                    if (data[i].type === "text") {
                      fragment.appendChild(document.createTextNode(data[i].data));
                    } else {
                      var span = document.createElement("span");
                      var math = data[i].data;
                      optionsCopy.displayMode = data[i].display;
                      try {
                        external_katex_default.a.render(math, span, optionsCopy);
                      } catch (e) {
                        if (!(e instanceof external_katex_default.a.ParseError)) {
                          throw e;
                        }
                        optionsCopy.errorCallback("KaTeX auto-render: Failed to parse `" + data[i].data + "` with ", e);
                        fragment.appendChild(document.createTextNode(data[i].rawData));
                        continue;
                      }
                      fragment.appendChild(span);
                    }
                  }
                  return fragment;
                };
                var renderElem = function renderElem2(elem, optionsCopy) {
                  for (var i = 0; i < elem.childNodes.length; i++) {
                    var childNode = elem.childNodes[i];
                    if (childNode.nodeType === 3) {
                      var frag = auto_render_renderMathInText(childNode.textContent, optionsCopy);
                      i += frag.childNodes.length - 1;
                      elem.replaceChild(frag, childNode);
                    } else if (childNode.nodeType === 1) {
                      (function() {
                        var className = " " + childNode.className + " ";
                        var shouldRender = optionsCopy.ignoredTags.indexOf(childNode.nodeName.toLowerCase()) === -1 && optionsCopy.ignoredClasses.every(function(x) {
                          return className.indexOf(" " + x + " ") === -1;
                        });
                        if (shouldRender) {
                          renderElem2(childNode, optionsCopy);
                        }
                      })();
                    }
                  }
                };
                var renderMathInElement2 = function renderMathInElement3(elem, options) {
                  if (!elem) {
                    throw new Error("No element provided to render");
                  }
                  var optionsCopy = {};
                  for (var option in options) {
                    if (options.hasOwnProperty(option)) {
                      optionsCopy[option] = options[option];
                    }
                  }
                  optionsCopy.delimiters = optionsCopy.delimiters || [
                    {
                      left: "$$",
                      right: "$$",
                      display: true
                    },
                    {
                      left: "\\(",
                      right: "\\)",
                      display: false
                    },
                    // LaTeX uses $…$, but it ruins the display of normal `$` in text:
                    // {left: "$", right: "$", display: false},
                    //  \[…\] must come last in this array. Otherwise, renderMathInElement
                    //  will search for \[ before it searches for $$ or  \(
                    // That makes it susceptible to finding a \\[0.3em] row delimiter and
                    // treating it as if it were the start of a KaTeX math zone.
                    {
                      left: "\\[",
                      right: "\\]",
                      display: true
                    }
                  ];
                  optionsCopy.ignoredTags = optionsCopy.ignoredTags || ["script", "noscript", "style", "textarea", "pre", "code"];
                  optionsCopy.ignoredClasses = optionsCopy.ignoredClasses || [];
                  optionsCopy.errorCallback = optionsCopy.errorCallback || console.error;
                  optionsCopy.macros = optionsCopy.macros || {};
                  renderElem(elem, optionsCopy);
                };
                var auto_render = __webpack_exports__["default"] = renderMathInElement2;
              }
              /******/
            ])["default"]
          );
        });
      });
      var renderMathInElement = unwrapExports(autoRender);
      var asyncGenerator = function() {
        function AwaitValue(value) {
          this.value = value;
        }
        function AsyncGenerator(gen) {
          var front, back;
          function send(key, arg) {
            return new Promise(function(resolve, reject) {
              var request = {
                key,
                arg,
                resolve,
                reject,
                next: null
              };
              if (back) {
                back = back.next = request;
              } else {
                front = back = request;
                resume(key, arg);
              }
            });
          }
          function resume(key, arg) {
            try {
              var result = gen[key](arg);
              var value = result.value;
              if (value instanceof AwaitValue) {
                Promise.resolve(value.value).then(function(arg2) {
                  resume("next", arg2);
                }, function(arg2) {
                  resume("throw", arg2);
                });
              } else {
                settle(result.done ? "return" : "normal", result.value);
              }
            } catch (err) {
              settle("throw", err);
            }
          }
          function settle(type, value) {
            switch (type) {
              case "return":
                front.resolve({
                  value,
                  done: true
                });
                break;
              case "throw":
                front.reject(value);
                break;
              default:
                front.resolve({
                  value,
                  done: false
                });
                break;
            }
            front = front.next;
            if (front) {
              resume(front.key, front.arg);
            } else {
              back = null;
            }
          }
          this._invoke = send;
          if (typeof gen.return !== "function") {
            this.return = void 0;
          }
        }
        if (typeof Symbol === "function" && Symbol.asyncIterator) {
          AsyncGenerator.prototype[Symbol.asyncIterator] = function() {
            return this;
          };
        }
        AsyncGenerator.prototype.next = function(arg) {
          return this._invoke("next", arg);
        };
        AsyncGenerator.prototype.throw = function(arg) {
          return this._invoke("throw", arg);
        };
        AsyncGenerator.prototype.return = function(arg) {
          return this._invoke("return", arg);
        };
        return {
          wrap: function(fn) {
            return function() {
              return new AsyncGenerator(fn.apply(this, arguments));
            };
          },
          await: function(value) {
            return new AwaitValue(value);
          }
        };
      }();
      var _extends = Object.assign || function(target) {
        for (var i = 1; i < arguments.length; i++) {
          var source = arguments[i];
          for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
              target[key] = source[key];
            }
          }
        }
        return target;
      };
      var toConsumableArray = function(arr) {
        if (Array.isArray(arr)) {
          for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++)
            arr2[i] = arr[i];
          return arr2;
        } else {
          return Array.from(arr);
        }
      };
      var tokens = {
        CONST: 0,
        UNARY: 1,
        BINARY: 2,
        INFIX: 3,
        LEFTBRACKET: 4,
        RIGHTBRACKET: 5,
        SPACE: 6,
        UNDEROVER: 7,
        DEFINITION: 8,
        LEFTRIGHT: 9,
        TEXT: 10
      };
      var quoteSymbol = {
        input: "'",
        tag: "mtext",
        output: "mbox",
        tex: null,
        ttype: tokens.TEXT
      };
      var symbols = [
        // some greek symbols
        {
          input: "alpha",
          tag: "mi",
          output: "α",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "beta",
          tag: "mi",
          output: "β",
          tex: null,
          ttype: tokens.CONST
        },
        { input: "chi", tag: "mi", output: "χ", tex: null, ttype: tokens.CONST },
        {
          input: "delta",
          tag: "mi",
          output: "δ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "Delta",
          tag: "mo",
          output: "Δ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "epsi",
          tag: "mi",
          output: "ε",
          tex: "epsilon",
          ttype: tokens.CONST
        },
        {
          input: "varepsilon",
          tag: "mi",
          output: "ɛ",
          tex: null,
          ttype: tokens.CONST
        },
        { input: "eta", tag: "mi", output: "η", tex: null, ttype: tokens.CONST },
        {
          input: "gamma",
          tag: "mi",
          output: "γ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "Gamma",
          tag: "mo",
          output: "Γ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "iota",
          tag: "mi",
          output: "ι",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "kappa",
          tag: "mi",
          output: "κ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "lambda",
          tag: "mi",
          output: "λ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "Lambda",
          tag: "mo",
          output: "Λ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "lamda",
          tag: "mi",
          output: "lambda",
          tex: null,
          ttype: tokens.DEFINITION
        },
        {
          input: "Lamda",
          tag: "mi",
          output: "Lambda",
          tex: null,
          ttype: tokens.DEFINITION
        },
        { input: "mu", tag: "mi", output: "μ", tex: null, ttype: tokens.CONST },
        { input: "nu", tag: "mi", output: "ν", tex: null, ttype: tokens.CONST },
        {
          input: "omega",
          tag: "mi",
          output: "ω",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "Omega",
          tag: "mo",
          output: "Ω",
          tex: null,
          ttype: tokens.CONST
        },
        { input: "phi", tag: "mi", output: "φ", tex: null, ttype: tokens.CONST },
        {
          input: "varphi",
          tag: "mi",
          output: "ϕ",
          tex: null,
          ttype: tokens.CONST
        },
        { input: "Phi", tag: "mo", output: "Φ", tex: null, ttype: tokens.CONST },
        { input: "pi", tag: "mi", output: "π", tex: null, ttype: tokens.CONST },
        { input: "Pi", tag: "mo", output: "Π", tex: null, ttype: tokens.CONST },
        { input: "psi", tag: "mi", output: "ψ", tex: null, ttype: tokens.CONST },
        { input: "Psi", tag: "mi", output: "Ψ", tex: null, ttype: tokens.CONST },
        { input: "rho", tag: "mi", output: "ρ", tex: null, ttype: tokens.CONST },
        {
          input: "sigma",
          tag: "mi",
          output: "σ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "Sigma",
          tag: "mo",
          output: "Σ",
          tex: null,
          ttype: tokens.CONST
        },
        { input: "tau", tag: "mi", output: "τ", tex: null, ttype: tokens.CONST },
        {
          input: "theta",
          tag: "mi",
          output: "θ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "vartheta",
          tag: "mi",
          output: "ϑ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "Theta",
          tag: "mo",
          output: "Θ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "upsilon",
          tag: "mi",
          output: "υ",
          tex: null,
          ttype: tokens.CONST
        },
        { input: "xi", tag: "mi", output: "ξ", tex: null, ttype: tokens.CONST },
        { input: "Xi", tag: "mo", output: "Ξ", tex: null, ttype: tokens.CONST },
        {
          input: "zeta",
          tag: "mi",
          output: "ζ",
          tex: null,
          ttype: tokens.CONST
        },
        // binary operation symbols
        { input: "*", tag: "mo", output: "⋅", tex: "cdot", ttype: tokens.CONST },
        { input: "**", tag: "mo", output: "∗", tex: "ast", ttype: tokens.CONST },
        {
          input: "***",
          tag: "mo",
          output: "⋆",
          tex: "star",
          ttype: tokens.CONST
        },
        {
          input: "// ",
          tag: "mo",
          output: "/",
          tex: "/",
          ttype: tokens.CONST,
          val: true,
          notexcopy: true
        },
        {
          input: "\\\\",
          tag: "mo",
          output: "\\",
          tex: "backslash",
          ttype: tokens.CONST
        },
        {
          input: "setminus",
          tag: "mo",
          output: "\\",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "xx",
          tag: "mo",
          output: "×",
          tex: "times",
          ttype: tokens.CONST
        },
        {
          input: "|><",
          tag: "mo",
          output: "⋉",
          tex: "ltimes",
          ttype: tokens.CONST
        },
        {
          input: "><|",
          tag: "mo",
          output: "⋊",
          tex: "rtimes",
          ttype: tokens.CONST
        },
        {
          input: "|><|",
          tag: "mo",
          output: "⋈",
          tex: "bowtie",
          ttype: tokens.CONST
        },
        { input: "-:", tag: "mo", output: "÷", tex: "div", ttype: tokens.CONST },
        {
          input: "divide",
          tag: "mo",
          output: "-:",
          tex: null,
          ttype: tokens.DEFINITION
        },
        { input: "@", tag: "mo", output: "∘", tex: "circ", ttype: tokens.CONST },
        {
          input: "o+",
          tag: "mo",
          output: "⊕",
          tex: "oplus",
          ttype: tokens.CONST
        },
        {
          input: "ox",
          tag: "mo",
          output: "⊗",
          tex: "otimes",
          ttype: tokens.CONST
        },
        {
          input: "o.",
          tag: "mo",
          output: "⊙",
          tex: "odot",
          ttype: tokens.CONST
        },
        {
          input: "sum",
          tag: "mo",
          output: "∑",
          tex: null,
          ttype: tokens.UNDEROVER
        },
        {
          input: "prod",
          tag: "mo",
          output: "∏",
          tex: null,
          ttype: tokens.UNDEROVER
        },
        {
          input: "^^",
          tag: "mo",
          output: "∧",
          tex: "wedge",
          ttype: tokens.CONST
        },
        {
          input: "^^^",
          tag: "mo",
          output: "⋀",
          tex: "bigwedge",
          ttype: tokens.UNDEROVER
        },
        { input: "vv", tag: "mo", output: "∨", tex: "vee", ttype: tokens.CONST },
        {
          input: "vvv",
          tag: "mo",
          output: "⋁",
          tex: "bigvee",
          ttype: tokens.UNDEROVER
        },
        { input: "nn", tag: "mo", output: "∩", tex: "cap", ttype: tokens.CONST },
        {
          input: "nnn",
          tag: "mo",
          output: "⋂",
          tex: "bigcap",
          ttype: tokens.UNDEROVER
        },
        { input: "uu", tag: "mo", output: "∪", tex: "cup", ttype: tokens.CONST },
        {
          input: "uuu",
          tag: "mo",
          output: "⋃",
          tex: "bigcup",
          ttype: tokens.UNDEROVER
        },
        {
          input: "overset",
          tag: "mover",
          output: "stackrel",
          tex: null,
          ttype: tokens.BINARY
        },
        {
          input: "underset",
          tag: "munder",
          output: "stackrel",
          tex: null,
          ttype: tokens.BINARY
        },
        // binary relation symbols
        { input: "!=", tag: "mo", output: "≠", tex: "ne", ttype: tokens.CONST },
        { input: ":=", tag: "mo", output: ":=", tex: null, ttype: tokens.CONST },
        { input: "lt", tag: "mo", output: "<", tex: null, ttype: tokens.CONST },
        { input: "gt", tag: "mo", output: ">", tex: null, ttype: tokens.CONST },
        { input: "<=", tag: "mo", output: "≤", tex: "le", ttype: tokens.CONST },
        {
          input: "lt=",
          tag: "mo",
          output: "≤",
          tex: "leq",
          ttype: tokens.CONST
        },
        {
          input: "gt=",
          tag: "mo",
          output: "≥",
          tex: "geq",
          ttype: tokens.CONST
        },
        { input: ">=", tag: "mo", output: "≥", tex: "ge", ttype: tokens.CONST },
        {
          input: "-<",
          tag: "mo",
          output: "≺",
          tex: "prec",
          ttype: tokens.CONST
        },
        { input: "-lt", tag: "mo", output: "≺", tex: null, ttype: tokens.CONST },
        {
          input: ">-",
          tag: "mo",
          output: "≻",
          tex: "succ",
          ttype: tokens.CONST
        },
        {
          input: "-<=",
          tag: "mo",
          output: "⪯",
          tex: "preceq",
          ttype: tokens.CONST
        },
        {
          input: ">-=",
          tag: "mo",
          output: "⪰",
          tex: "succeq",
          ttype: tokens.CONST
        },
        { input: "in", tag: "mo", output: "∈", tex: null, ttype: tokens.CONST },
        {
          input: "!in",
          tag: "mo",
          output: "∉",
          tex: "notin",
          ttype: tokens.CONST
        },
        {
          input: "sub",
          tag: "mo",
          output: "⊂",
          tex: "subset",
          ttype: tokens.CONST
        },
        {
          input: "sup",
          tag: "mo",
          output: "⊃",
          tex: "supset",
          ttype: tokens.CONST
        },
        {
          input: "sube",
          tag: "mo",
          output: "⊆",
          tex: "subseteq",
          ttype: tokens.CONST
        },
        {
          input: "supe",
          tag: "mo",
          output: "⊇",
          tex: "supseteq",
          ttype: tokens.CONST
        },
        {
          input: "-=",
          tag: "mo",
          output: "≡",
          tex: "equiv",
          ttype: tokens.CONST
        },
        {
          input: "~=",
          tag: "mo",
          output: "≅",
          tex: "stackrel{\\sim}{=}",
          ttype: tokens.CONST
        },
        // back hack b/c mimetex doesn't support /cong
        {
          input: "cong",
          tag: "mo",
          output: "~=",
          tex: null,
          ttype: tokens.DEFINITION
        },
        {
          input: "~~",
          tag: "mo",
          output: "≈",
          tex: "approx",
          ttype: tokens.CONST
        },
        {
          input: "prop",
          tag: "mo",
          output: "∝",
          tex: "propto",
          ttype: tokens.CONST
        },
        // logical symbols
        { input: "and", tag: "mtext", output: "and", tex: null, ttype: tokens.SPACE },
        { input: "or", tag: "mtext", output: "or", tex: null, ttype: tokens.SPACE },
        {
          input: "not",
          tag: "mo",
          output: "¬",
          tex: "neg",
          ttype: tokens.CONST
        },
        {
          input: "=>",
          tag: "mo",
          output: "⇒",
          tex: "Rightarrow",
          ttype: tokens.CONST
        },
        {
          input: "implies",
          tag: "mo",
          output: "=>",
          tex: null,
          ttype: tokens.DEFINITION
        },
        { input: "if", tag: "mo", output: "if", tex: null, ttype: tokens.SPACE },
        {
          input: "<=>",
          tag: "mo",
          output: "⇔",
          tex: "Leftrightarrow",
          ttype: tokens.CONST
        },
        {
          input: "iff",
          tag: "mo",
          output: "<=>",
          tex: null,
          ttype: tokens.DEFINITION
        },
        {
          input: "AA",
          tag: "mo",
          output: "∀",
          tex: "forall",
          ttype: tokens.CONST
        },
        {
          input: "EE",
          tag: "mo",
          output: "∃",
          tex: "exists",
          ttype: tokens.CONST
        },
        {
          input: "_|_",
          tag: "mo",
          output: "⊥",
          tex: "bot",
          ttype: tokens.CONST
        },
        { input: "TT", tag: "mo", output: "⊤", tex: "top", ttype: tokens.CONST },
        {
          input: "|--",
          tag: "mo",
          output: "⊢",
          tex: "vdash",
          ttype: tokens.CONST
        },
        {
          input: "|==",
          tag: "mo",
          output: "⊨",
          tex: "models",
          ttype: tokens.CONST
        },
        // mimetex doesn't support
        // grouping brackets
        {
          input: "(",
          tag: "mo",
          output: "(",
          tex: null,
          ttype: tokens.LEFTBRACKET,
          val: true
        },
        {
          input: ")",
          tag: "mo",
          output: ")",
          tex: null,
          ttype: tokens.RIGHTBRACKET,
          val: true
        },
        {
          input: "[",
          tag: "mo",
          output: "[",
          tex: null,
          ttype: tokens.LEFTBRACKET,
          val: true
        },
        {
          input: "]",
          tag: "mo",
          output: "]",
          tex: null,
          ttype: tokens.RIGHTBRACKET,
          val: true
        },
        {
          input: "{",
          tag: "mo",
          output: "{",
          tex: "lbrace",
          ttype: tokens.LEFTBRACKET
        },
        {
          input: "}",
          tag: "mo",
          output: "}",
          tex: "rbrace",
          ttype: tokens.RIGHTBRACKET
        },
        {
          input: "|",
          tag: "mo",
          output: "|",
          tex: null,
          ttype: tokens.LEFTRIGHT,
          val: true
        },
        // {input:'||', tag:'mo', output:'||', tex:null, ttype:LEFTRIGHT},
        {
          input: "(:",
          tag: "mo",
          output: "〈",
          tex: "langle",
          ttype: tokens.LEFTBRACKET
        },
        {
          input: ":)",
          tag: "mo",
          output: "〉",
          tex: "rangle",
          ttype: tokens.RIGHTBRACKET
        },
        {
          input: "<<",
          tag: "mo",
          output: "〈",
          tex: "langle",
          ttype: tokens.LEFTBRACKET
        },
        {
          input: ">>",
          tag: "mo",
          output: "〉",
          tex: "rangle",
          ttype: tokens.RIGHTBRACKET
        },
        {
          input: "{:",
          tag: "mo",
          output: "{:",
          tex: null,
          ttype: tokens.LEFTBRACKET,
          invisible: true
        },
        {
          input: ":}",
          tag: "mo",
          output: ":}",
          tex: null,
          ttype: tokens.RIGHTBRACKET,
          invisible: true
        },
        // miscellaneous symbols
        { input: "int", tag: "mo", output: "∫", tex: null, ttype: tokens.CONST },
        {
          input: "dx",
          tag: "mi",
          output: "{:d x:}",
          tex: null,
          ttype: tokens.DEFINITION
        },
        {
          input: "dy",
          tag: "mi",
          output: "{:d y:}",
          tex: null,
          ttype: tokens.DEFINITION
        },
        {
          input: "dz",
          tag: "mi",
          output: "{:d z:}",
          tex: null,
          ttype: tokens.DEFINITION
        },
        {
          input: "dt",
          tag: "mi",
          output: "{:d t:}",
          tex: null,
          ttype: tokens.DEFINITION
        },
        {
          input: "oint",
          tag: "mo",
          output: "∮",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "del",
          tag: "mo",
          output: "∂",
          tex: "partial",
          ttype: tokens.CONST
        },
        {
          input: "grad",
          tag: "mo",
          output: "∇",
          tex: "nabla",
          ttype: tokens.CONST
        },
        { input: "+-", tag: "mo", output: "±", tex: "pm", ttype: tokens.CONST },
        {
          input: "O/",
          tag: "mo",
          output: "∅",
          tex: "emptyset",
          ttype: tokens.CONST
        },
        {
          input: "oo",
          tag: "mo",
          output: "∞",
          tex: "infty",
          ttype: tokens.CONST
        },
        {
          input: "aleph",
          tag: "mo",
          output: "ℵ",
          tex: null,
          ttype: tokens.CONST
        },
        { input: "...", tag: "mo", output: "...", tex: "ldots", ttype: tokens.CONST },
        {
          input: ":.",
          tag: "mo",
          output: "∴",
          tex: "therefore",
          ttype: tokens.CONST
        },
        {
          input: ":'",
          tag: "mo",
          output: "∵",
          tex: "because",
          ttype: tokens.CONST
        },
        {
          input: "/_",
          tag: "mo",
          output: "∠",
          tex: "angle",
          ttype: tokens.CONST
        },
        {
          input: "/_\\",
          tag: "mo",
          output: "△",
          tex: "triangle",
          ttype: tokens.CONST
        },
        {
          input: "\\ ",
          tag: "mo",
          output: " ",
          tex: null,
          ttype: tokens.CONST,
          val: true
        },
        {
          input: "frown",
          tag: "mo",
          output: "⌢",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "%",
          tag: "mo",
          output: "%",
          tex: "%",
          ttype: tokens.CONST,
          notexcopy: true
        },
        {
          input: "quad",
          tag: "mo",
          output: "  ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "qquad",
          tag: "mo",
          output: "    ",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "cdots",
          tag: "mo",
          output: "⋯",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "vdots",
          tag: "mo",
          output: "⋮",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "ddots",
          tag: "mo",
          output: "⋱",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "diamond",
          tag: "mo",
          output: "⋄",
          tex: null,
          ttype: tokens.CONST
        },
        {
          input: "square",
          tag: "mo",
          output: "□",
          tex: "boxempty",
          ttype: tokens.CONST
        },
        {
          input: "|__",
          tag: "mo",
          output: "⌊",
          tex: "lfloor",
          ttype: tokens.CONST
        },
        {
          input: "__|",
          tag: "mo",
          output: "⌋",
          tex: "rfloor",
          ttype: tokens.CONST
        },
        {
          input: "|~",
          tag: "mo",
          output: "⌈",
          tex: "lceil",
          ttype: tokens.CONST
        },
        {
          input: "lceiling",
          tag: "mo",
          output: "|~",
          tex: null,
          ttype: tokens.DEFINITION
        },
        {
          input: "~|",
          tag: "mo",
          output: "⌉",
          tex: "rceil",
          ttype: tokens.CONST
        },
        {
          input: "rceiling",
          tag: "mo",
          output: "~|",
          tex: null,
          ttype: tokens.DEFINITION
        },
        {
          input: "CC",
          tag: "mo",
          output: "ℂ",
          tex: "mathbb{C}",
          ttype: tokens.CONST,
          notexcopy: true
        },
        {
          input: "NN",
          tag: "mo",
          output: "ℕ",
          tex: "mathbb{N}",
          ttype: tokens.CONST,
          notexcopy: true
        },
        {
          input: "QQ",
          tag: "mo",
          output: "ℚ",
          tex: "mathbb{Q}",
          ttype: tokens.CONST,
          notexcopy: true
        },
        {
          input: "RR",
          tag: "mo",
          output: "ℝ",
          tex: "mathbb{R}",
          ttype: tokens.CONST,
          notexcopy: true
        },
        {
          input: "ZZ",
          tag: "mo",
          output: "ℤ",
          tex: "mathbb{Z}",
          ttype: tokens.CONST,
          notexcopy: true
        },
        {
          input: "f",
          tag: "mi",
          output: "f",
          tex: null,
          ttype: tokens.UNARY,
          func: true,
          val: true
        },
        {
          input: "g",
          tag: "mi",
          output: "g",
          tex: null,
          ttype: tokens.UNARY,
          func: true,
          val: true
        },
        { input: "''", tag: "mo", output: "''", tex: null, val: true },
        { input: "'''", tag: "mo", output: "'''", tex: null, val: true },
        { input: "''''", tag: "mo", output: "''''", tex: null, val: true },
        // standard functions
        {
          input: "lim",
          tag: "mo",
          output: "lim",
          tex: null,
          ttype: tokens.UNDEROVER
        },
        {
          input: "Lim",
          tag: "mo",
          output: "Lim",
          tex: null,
          ttype: tokens.UNDEROVER
        },
        {
          input: "sin",
          tag: "mo",
          output: "sin",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "cos",
          tag: "mo",
          output: "cos",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "tan",
          tag: "mo",
          output: "tan",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "arcsin",
          tag: "mo",
          output: "arcsin",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "arccos",
          tag: "mo",
          output: "arccos",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "arctan",
          tag: "mo",
          output: "arctan",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "sinh",
          tag: "mo",
          output: "sinh",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "cosh",
          tag: "mo",
          output: "cosh",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "tanh",
          tag: "mo",
          output: "tanh",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "cot",
          tag: "mo",
          output: "cot",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "coth",
          tag: "mo",
          output: "coth",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "sech",
          tag: "mo",
          output: "sech",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "csch",
          tag: "mo",
          output: "csch",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "sec",
          tag: "mo",
          output: "sec",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "csc",
          tag: "mo",
          output: "csc",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "log",
          tag: "mo",
          output: "log",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "ln",
          tag: "mo",
          output: "ln",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "abs",
          tag: "mo",
          output: "abs",
          tex: null,
          ttype: tokens.UNARY,
          notexcopy: true,
          rewriteleftright: ["|", "|"]
        },
        {
          input: "norm",
          tag: "mo",
          output: "norm",
          tex: null,
          ttype: tokens.UNARY,
          notexcopy: true,
          rewriteleftright: ["\\|", "\\|"]
        },
        {
          input: "floor",
          tag: "mo",
          output: "floor",
          tex: null,
          ttype: tokens.UNARY,
          notexcopy: true,
          rewriteleftright: ["\\lfloor", "\\rfloor"]
        },
        {
          input: "ceil",
          tag: "mo",
          output: "ceil",
          tex: null,
          ttype: tokens.UNARY,
          notexcopy: true,
          rewriteleftright: ["\\lceil", "\\rceil"]
        },
        {
          input: "Sin",
          tag: "mo",
          output: "sin",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Cos",
          tag: "mo",
          output: "cos",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Tan",
          tag: "mo",
          output: "tan",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Arcsin",
          tag: "mo",
          output: "arcsin",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Arccos",
          tag: "mo",
          output: "arccos",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Arctan",
          tag: "mo",
          output: "arctan",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Sinh",
          tag: "mo",
          output: "sinh",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Sosh",
          tag: "mo",
          output: "cosh",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Tanh",
          tag: "mo",
          output: "tanh",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Cot",
          tag: "mo",
          output: "cot",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Sec",
          tag: "mo",
          output: "sec",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Csc",
          tag: "mo",
          output: "csc",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Log",
          tag: "mo",
          output: "log",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Ln",
          tag: "mo",
          output: "ln",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "Abs",
          tag: "mo",
          output: "abs",
          tex: null,
          ttype: tokens.UNARY,
          notexcopy: true,
          rewriteleftright: ["|", "|"]
        },
        {
          input: "det",
          tag: "mo",
          output: "det",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "exp",
          tag: "mo",
          output: "exp",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        { input: "dim", tag: "mo", output: "dim", tex: null, ttype: tokens.CONST },
        {
          input: "mod",
          tag: "mo",
          output: "mod",
          tex: "text{mod}",
          ttype: tokens.CONST,
          notexcopy: true
        },
        {
          input: "gcd",
          tag: "mo",
          output: "gcd",
          tex: null,
          ttype: tokens.UNARY,
          func: true
        },
        {
          input: "lcm",
          tag: "mo",
          output: "lcm",
          tex: "text{lcm}",
          ttype: tokens.UNARY,
          func: true,
          notexcopy: true
        },
        { input: "lub", tag: "mo", output: "lub", tex: null, ttype: tokens.CONST },
        { input: "glb", tag: "mo", output: "glb", tex: null, ttype: tokens.CONST },
        {
          input: "min",
          tag: "mo",
          output: "min",
          tex: null,
          ttype: tokens.UNDEROVER
        },
        {
          input: "max",
          tag: "mo",
          output: "max",
          tex: null,
          ttype: tokens.UNDEROVER
        },
        // arrows
        {
          input: "uarr",
          tag: "mo",
          output: "↑",
          tex: "uparrow",
          ttype: tokens.CONST
        },
        {
          input: "darr",
          tag: "mo",
          output: "↓",
          tex: "downarrow",
          ttype: tokens.CONST
        },
        {
          input: "rarr",
          tag: "mo",
          output: "→",
          tex: "rightarrow",
          ttype: tokens.CONST
        },
        { input: "->", tag: "mo", output: "→", tex: "to", ttype: tokens.CONST },
        {
          input: ">->",
          tag: "mo",
          output: "↣",
          tex: "rightarrowtail",
          ttype: tokens.CONST
        },
        {
          input: "->>",
          tag: "mo",
          output: "↠",
          tex: "twoheadrightarrow",
          ttype: tokens.CONST
        },
        {
          input: ">->>",
          tag: "mo",
          output: "⤖",
          tex: "twoheadrightarrowtail",
          ttype: tokens.CONST
        },
        {
          input: "|->",
          tag: "mo",
          output: "↦",
          tex: "mapsto",
          ttype: tokens.CONST
        },
        {
          input: "larr",
          tag: "mo",
          output: "←",
          tex: "leftarrow",
          ttype: tokens.CONST
        },
        {
          input: "harr",
          tag: "mo",
          output: "↔",
          tex: "leftrightarrow",
          ttype: tokens.CONST
        },
        {
          input: "rArr",
          tag: "mo",
          output: "⇒",
          tex: "Rightarrow",
          ttype: tokens.CONST
        },
        {
          input: "lArr",
          tag: "mo",
          output: "⇐",
          tex: "Leftarrow",
          ttype: tokens.CONST
        },
        {
          input: "hArr",
          tag: "mo",
          output: "⇔",
          tex: "Leftrightarrow",
          ttype: tokens.CONST
        },
        // commands with argument
        {
          input: "sqrt",
          tag: "msqrt",
          output: "sqrt",
          tex: null,
          ttype: tokens.UNARY
        },
        {
          input: "root",
          tag: "mroot",
          output: "root",
          tex: null,
          ttype: tokens.BINARY
        },
        { input: "frac", tag: "mfrac", output: "/", tex: null, ttype: tokens.BINARY },
        { input: "/", tag: "mfrac", output: "/", tex: null, ttype: tokens.INFIX },
        {
          input: "stackrel",
          tag: "mover",
          output: "stackrel",
          tex: null,
          ttype: tokens.BINARY
        },
        { input: "_", tag: "msub", output: "_", tex: null, ttype: tokens.INFIX },
        { input: "^", tag: "msup", output: "^", tex: null, ttype: tokens.INFIX },
        {
          input: "cancel",
          tag: "menclose",
          output: "cancel",
          tex: null,
          ttype: tokens.UNARY
        },
        {
          input: "Sqrt",
          tag: "msqrt",
          output: "sqrt",
          tex: null,
          ttype: tokens.UNARY
        },
        {
          input: "hat",
          tag: "mover",
          output: "^",
          tex: null,
          ttype: tokens.UNARY,
          acc: true
        },
        {
          input: "bar",
          tag: "mover",
          output: "¯",
          tex: "overline",
          ttype: tokens.UNARY,
          acc: true
        },
        {
          input: "vec",
          tag: "mover",
          output: "→",
          tex: null,
          ttype: tokens.UNARY,
          acc: true
        },
        {
          input: "tilde",
          tag: "mover",
          output: "~",
          tex: null,
          ttype: tokens.UNARY,
          acc: true
        },
        {
          input: "dot",
          tag: "mover",
          output: ".",
          tex: null,
          ttype: tokens.UNARY,
          acc: true
        },
        {
          input: "ddot",
          tag: "mover",
          output: "..",
          tex: null,
          ttype: tokens.UNARY,
          acc: true
        },
        {
          input: "ul",
          tag: "munder",
          output: "̲",
          tex: "underline",
          ttype: tokens.UNARY,
          acc: true
        },
        {
          input: "ubrace",
          tag: "munder",
          output: "⏟",
          tex: "underbrace",
          ttype: tokens.UNARY,
          acc: true
        },
        {
          input: "obrace",
          tag: "mover",
          output: "⏞",
          tex: "overbrace",
          ttype: tokens.UNARY,
          acc: true
        },
        {
          input: "text",
          tag: "mtext",
          output: "text",
          tex: null,
          ttype: tokens.TEXT
        },
        {
          input: "mbox",
          tag: "mtext",
          output: "mbox",
          tex: null,
          ttype: tokens.TEXT
        },
        quoteSymbol,
        // { input: 'var', tag: 'mstyle', atname: 'fontstyle', atval: 'italic', output: 'var', tex: null, ttype: tokens.UNARY },
        { input: "color", tag: "mstyle", ttype: tokens.BINARY },
        {
          input: "bb",
          tag: "mstyle",
          atname: "mathvariant",
          atval: "bold",
          output: "bb",
          tex: "mathbf",
          ttype: tokens.UNARY,
          notexcopy: true
        },
        {
          input: "mathbf",
          tag: "mstyle",
          atname: "mathvariant",
          atval: "bold",
          output: "mathbf",
          tex: null,
          ttype: tokens.UNARY
        },
        {
          input: "sf",
          tag: "mstyle",
          atname: "mathvariant",
          atval: "sans-serif",
          output: "sf",
          tex: "mathsf",
          ttype: tokens.UNARY,
          notexcopy: true
        },
        {
          input: "mathsf",
          tag: "mstyle",
          atname: "mathvariant",
          atval: "sans-serif",
          output: "mathsf",
          tex: null,
          ttype: tokens.UNARY
        },
        {
          input: "bbb",
          tag: "mstyle",
          atname: "mathvariant",
          atval: "double-struck",
          output: "bbb",
          tex: "mathbb",
          ttype: tokens.UNARY,
          notexcopy: true
        },
        {
          input: "mathbb",
          tag: "mstyle",
          atname: "mathvariant",
          atval: "double-struck",
          output: "mathbb",
          tex: null,
          ttype: tokens.UNARY
        },
        {
          input: "cc",
          tag: "mstyle",
          atname: "mathvariant",
          atval: "script",
          output: "cc",
          tex: "mathcal",
          ttype: tokens.UNARY,
          notexcopy: true
        },
        {
          input: "mathcal",
          tag: "mstyle",
          atname: "mathvariant",
          atval: "script",
          output: "mathcal",
          tex: null,
          ttype: tokens.UNARY
        },
        {
          input: "tt",
          tag: "mstyle",
          atname: "mathvariant",
          atval: "monospace",
          output: "tt",
          tex: "mathtt",
          ttype: tokens.UNARY,
          notexcopy: true
        },
        {
          input: "mathtt",
          tag: "mstyle",
          atname: "mathvariant",
          atval: "monospace",
          output: "mathtt",
          tex: null,
          ttype: tokens.UNARY
        },
        {
          input: "fr",
          tag: "mstyle",
          atname: "mathvariant",
          atval: "fraktur",
          output: "fr",
          tex: "mathfrak",
          ttype: tokens.UNARY,
          notexcopy: true
        },
        {
          input: "mathfrak",
          tag: "mstyle",
          atname: "mathvariant",
          atval: "fraktur",
          output: "mathfrak",
          tex: null,
          ttype: tokens.UNARY
        }
      ];
      var inputSymbols = [];
      function refreshSymbols() {
        symbols.sort(function(s1, s2) {
          return s1.input > s2.input ? 1 : -1;
        });
        inputSymbols = symbols.map(function(item) {
          return item.input;
        });
      }
      function removeCharsAndBlanks(str, n) {
        var st = void 0;
        if (str.charAt(n) === "\\" && str.charAt(n + 1) !== "\\" && str.charAt(n + 1) !== " ") {
          st = str.slice(n + 1);
        } else {
          st = str.slice(n);
        }
        var i = 0;
        while (i < st.length && st.charCodeAt(i) <= 32) {
          i++;
        }
        return st.slice(i);
      }
      function position(arr, str, n) {
        if (n === 0) {
          var len = arr.length;
          var m = void 0;
          n = -1;
          while (n + 1 < len) {
            m = n + len >> 1;
            if (arr[m] < str) {
              n = m;
            } else {
              len = m;
            }
          }
          return len;
        }
        var i = n;
        while (i < arr.length && arr[i] < str) {
          i++;
        }
        return i;
      }
      function getSymbol(str) {
        var newPos = 0;
        var oldPos = 0;
        var matchPos = void 0;
        var st = void 0;
        var tagst = void 0;
        var match = "";
        var more = true;
        for (var i = 1; i <= str.length && more; i++) {
          st = str.slice(0, i);
          oldPos = newPos;
          newPos = position(inputSymbols, st, oldPos);
          if (newPos < inputSymbols.length && str.slice(0, inputSymbols[newPos].length) === inputSymbols[newPos]) {
            match = inputSymbols[newPos];
            matchPos = newPos;
            i = match.length;
          }
          more = newPos < inputSymbols.length && str.slice(0, inputSymbols[newPos].length) >= inputSymbols[newPos];
        }
        previousSymbol = currentSymbol;
        if (match !== "") {
          currentSymbol = symbols[matchPos].ttype;
          return symbols[matchPos];
        }
        currentSymbol = tokens.CONST;
        newPos = 1;
        st = str.slice(0, 1);
        var integ = true;
        while ("0" <= st && st <= "9" && newPos <= str.length) {
          st = str.slice(newPos, newPos + 1);
          newPos++;
        }
        if (st === ".") {
          st = str.slice(newPos, newPos + 1);
          if ("0" <= st && st <= "9") {
            integ = false;
            newPos++;
            while ("0" <= st && st <= "9" && newPos <= str.length) {
              st = str.slice(newPos, newPos + 1);
              newPos++;
            }
          }
        }
        if (integ && newPos > 1 || newPos > 2) {
          st = str.slice(0, newPos - 1);
          tagst = "mn";
        } else {
          newPos = 2;
          st = str.slice(0, 1);
          tagst = ("A" > st || st > "Z") && ("a" > st || st > "z") ? "mo" : "mi";
        }
        if (st === "-" && previousSymbol === tokens.INFIX) {
          currentSymbol = tokens.INFIX;
          return {
            input: st,
            tag: tagst,
            output: st,
            ttype: tokens.UNARY,
            func: true,
            val: true
          };
        }
        return { input: st, tag: tagst, output: st, ttype: tokens.CONST, val: true };
      }
      function removeBrackets(node) {
        var st = void 0;
        if (node.charAt(0) === "{" && node.charAt(node.length - 1) === "}") {
          var leftchop = 0;
          st = node.substr(1, 5);
          if (st === "\\left") {
            st = node.charAt(6);
            if (st === "(" || st === "[" || st === "{") {
              leftchop = 7;
            } else {
              st = node.substr(6, 7);
              if (st === "\\lbrace") {
                leftchop = 13;
              }
            }
          } else {
            st = node.charAt(1);
            if (st === "(" || st === "[") {
              leftchop = 2;
            }
          }
          if (leftchop > 0) {
            st = node.substr(node.length - 8);
            if (st === "\\right)}" || st === "\\right]}" || st === "\\right.}") {
              node = "{" + node.substr(leftchop);
              node = node.substr(0, node.length - 8) + "}";
            } else if (st === "\\rbrace}") {
              node = "{" + node.substr(leftchop);
              node = node.substr(0, node.length - 14) + "}";
            }
          }
        }
        return node;
      }
      var nestingDepth = void 0;
      var previousSymbol = void 0;
      var currentSymbol = void 0;
      function getTeXsymbol(symb) {
        var pre = void 0;
        if (typeof symb.val === "boolean" && symb.val) {
          pre = "";
        } else {
          pre = "\\";
        }
        if (!symb.tex) {
          return pre + symb.input;
        } else {
          return pre + symb.tex;
        }
      }
      function parseSexpr(str) {
        var symbol = void 0;
        var node = void 0;
        var result = void 0;
        var i = void 0;
        var newFrag = "";
        str = removeCharsAndBlanks(str, 0);
        symbol = getSymbol(str);
        if (!symbol || symbol.ttype === tokens.RIGHTBRACKET && nestingDepth > 0) {
          return [null, str];
        }
        if (symbol.ttype === tokens.DEFINITION) {
          str = symbol.output + removeCharsAndBlanks(str, symbol.input.length);
          symbol = getSymbol(str);
        }
        switch (symbol.ttype) {
          case tokens.UNDEROVER:
          case tokens.CONST:
            str = removeCharsAndBlanks(str, symbol.input.length);
            var texsymbol = getTeXsymbol(symbol);
            if (texsymbol.charAt(0) === "\\" || symbol.tag === "mo") {
              return [texsymbol, str];
            } else {
              return ["{" + texsymbol + "}", str];
            }
          case tokens.LEFTBRACKET:
            nestingDepth++;
            str = removeCharsAndBlanks(str, symbol.input.length);
            result = parseExpr(str, true);
            nestingDepth--;
            var leftchop = 0;
            if (result[0].substr(0, 6) === "\\right") {
              st = result[0].charAt(6);
              if (st === ")" || st === "]" || st === "}") {
                leftchop = 6;
              } else if (st === ".") {
                leftchop = 7;
              } else {
                st = result[0].substr(6, 7);
                if (st === "\\rbrace") {
                  leftchop = 13;
                }
              }
            }
            if (leftchop > 0) {
              result[0] = result[0].substr(leftchop);
              if (symbol.invisible) {
                node = "{" + result[0] + "}";
              } else {
                node = "{" + getTeXsymbol(symbol) + result[0] + "}";
              }
            } else {
              if (symbol.invisible) {
                node = "{\\left." + result[0] + "}";
              } else {
                node = "{\\left" + getTeXsymbol(symbol) + result[0] + "}";
              }
            }
            return [node, result[1]];
          case tokens.TEXT:
            if (symbol !== quoteSymbol) {
              str = removeCharsAndBlanks(str, symbol.input.length);
            }
            if (str.charAt(0) === "{") {
              i = str.indexOf("}");
            } else if (str.charAt(0) === "(") {
              i = str.indexOf(")");
            } else if (str.charAt(0) === "[") {
              i = str.indexOf("]");
            } else if (symbol === quoteSymbol) {
              i = str.slice(1).indexOf("'") + 1;
            } else {
              i = 0;
            }
            if (i === -1) {
              i = str.length;
            }
            st = str.slice(1, i);
            if (st.charAt(0) === " ") {
              newFrag = "\\ ";
            }
            newFrag += "\\text{" + st + "}";
            if (st.charAt(st.length - 1) === " ") {
              newFrag += "\\ ";
            }
            str = removeCharsAndBlanks(str, i + 1);
            return [newFrag, str];
          case tokens.UNARY:
            str = removeCharsAndBlanks(str, symbol.input.length);
            result = parseSexpr(str);
            if (result[0] === null) {
              return ["{" + getTeXsymbol(symbol) + "}", str];
            }
            if (symbol.func === true) {
              st = str.charAt(0);
              if (st === "^" || st === "_" || st === "/" || st === "|" || st === "," || symbol.input.length === 1 && symbol.input.match(/\w/) && st !== "(") {
                return ["{" + getTeXsymbol(symbol) + "}", str];
              } else {
                node = "{" + getTeXsymbol(symbol) + "{" + result[0] + "}}";
                return [node, result[1]];
              }
            }
            result[0] = removeBrackets(result[0]);
            if (symbol.input === "sqrt") {
              return ["\\sqrt{" + result[0] + "}", result[1]];
            } else if (symbol.input === "cancel") {
              return ["\\cancel{" + result[0] + "}", result[1]];
            } else if (typeof symbol.rewriteleftright !== "undefined") {
              return ["{\\left" + symbol.rewriteleftright[0] + result[0] + "\\right" + symbol.rewriteleftright[1] + "}", result[1]];
            } else if (symbol.acc === true) {
              return [getTeXsymbol(symbol) + "{" + result[0] + "}", result[1]];
            } else {
              return ["{" + getTeXsymbol(symbol) + "{" + result[0] + "}}", result[1]];
            }
          case tokens.BINARY:
            str = removeCharsAndBlanks(str, symbol.input.length);
            result = parseSexpr(str);
            if (result[0] === null) {
              return ["{" + getTeXsymbol(symbol) + "}", str];
            }
            result[0] = removeBrackets(result[0]);
            var result2 = parseSexpr(result[1]);
            if (result2[0] === null) {
              return ["{" + getTeXsymbol(symbol) + "}", str];
            }
            result2[0] = removeBrackets(result2[0]);
            if (symbol.input === "color") {
              newFrag = "{\\color{" + result[0].replace(/[{}]/g, "") + "}" + result2[0] + "}";
            } else if (symbol.input === "root") {
              newFrag = "{\\sqrt[" + result[0] + "]{" + result2[0] + "}}";
            } else {
              newFrag = "{" + getTeXsymbol(symbol) + "{" + result[0] + "}{" + result2[0] + "}}";
            }
            return [newFrag, result2[1]];
          case tokens.INFIX:
            str = removeCharsAndBlanks(str, symbol.input.length);
            return [symbol.output, str];
          case tokens.SPACE:
            str = removeCharsAndBlanks(str, symbol.input.length);
            return ["{\\quad\\text{" + symbol.input + "}\\quad}", str];
          case tokens.LEFTRIGHT:
            nestingDepth++;
            str = removeCharsAndBlanks(str, symbol.input.length);
            result = parseExpr(str, false);
            nestingDepth--;
            var st = "";
            st = result[0].charAt(result[0].length - 1);
            if (st === "|") {
              node = "{\\left|" + result[0] + "}";
              return [node, result[1]];
            } else {
              node = "{\\mid}";
              return [node, str];
            }
          default:
            str = removeCharsAndBlanks(str, symbol.input.length);
            return ["{" + getTeXsymbol(symbol) + "}", str];
        }
      }
      function parseIexpr(str) {
        var sym2 = void 0;
        var node = void 0;
        var result = void 0;
        str = removeCharsAndBlanks(str, 0);
        var sym1 = getSymbol(str);
        result = parseSexpr(str);
        node = result[0];
        str = result[1];
        var symbol = getSymbol(str);
        if (symbol.ttype === tokens.INFIX && symbol.input !== "/") {
          str = removeCharsAndBlanks(str, symbol.input.length);
          result = parseSexpr(str);
          if (result[0] === null) {
            result[0] = "{}";
          } else {
            result[0] = removeBrackets(result[0]);
          }
          str = result[1];
          if (symbol.input === "_") {
            sym2 = getSymbol(str);
            if (sym2.input === "^") {
              str = removeCharsAndBlanks(str, sym2.input.length);
              var res2 = parseSexpr(str);
              res2[0] = removeBrackets(res2[0]);
              str = res2[1];
              node = "{" + node;
              node += "_{" + result[0] + "}";
              node += "^{" + res2[0] + "}";
              node += "}";
            } else {
              node += "_{" + result[0] + "}";
            }
          } else {
            node = node + "^{" + result[0] + "}";
          }
          if (typeof sym1.func !== "undefined" && sym1.func) {
            sym2 = getSymbol(str);
            if (sym2.ttype !== tokens.INFIX && sym2.ttype !== tokens.RIGHTBRACKET) {
              result = parseIexpr(str);
              node = "{" + node + result[0] + "}";
              str = result[1];
            }
          }
        }
        return [node, str];
      }
      function parseExpr(str, rightbracket) {
        var symbol = void 0;
        var node = void 0;
        var result = void 0;
        var i = void 0;
        var newFrag = "";
        var addedright = false;
        do {
          str = removeCharsAndBlanks(str, 0);
          result = parseIexpr(str);
          node = result[0];
          str = result[1];
          symbol = getSymbol(str);
          if (symbol.ttype === tokens.INFIX && symbol.input === "/") {
            str = removeCharsAndBlanks(str, symbol.input.length);
            result = parseIexpr(str);
            if (result[0] === null) {
              result[0] = "{}";
            } else {
              result[0] = removeBrackets(result[0]);
            }
            str = result[1];
            node = removeBrackets(node);
            node = "\\frac{" + node + "}";
            node += "{" + result[0] + "}";
            newFrag += node;
            symbol = getSymbol(str);
          } else if (node) {
            newFrag += node;
          }
        } while ((symbol.ttype !== tokens.RIGHTBRACKET && (symbol.ttype !== tokens.LEFTRIGHT || rightbracket) || nestingDepth === 0) && symbol && symbol.output);
        if (symbol.ttype === tokens.RIGHTBRACKET || symbol.ttype === tokens.LEFTRIGHT) {
          var len = newFrag.length;
          if (len > 2 && newFrag.charAt(0) === "{" && newFrag.indexOf(",") > 0) {
            var right = newFrag.charAt(len - 2);
            if (right === ")" || right === "]") {
              var left = newFrag.charAt(6);
              if (left === "(" && right === ")" && symbol.output !== "}" || left === "[" && right === "]") {
                var mxout = "\\matrix{";
                var pos = new Array();
                pos.push(0);
                var matrix = true;
                var mxnestingd = 0;
                var subpos = [];
                subpos[0] = [0];
                var lastsubposstart = 0;
                var mxanynestingd = 0;
                for (i = 1; i < len - 1; i++) {
                  if (newFrag.charAt(i) === left) {
                    mxnestingd++;
                  }
                  if (newFrag.charAt(i) === right) {
                    mxnestingd--;
                    if (mxnestingd === 0 && newFrag.charAt(i + 2) === "," && newFrag.charAt(i + 3) === "{") {
                      pos.push(i + 2);
                      lastsubposstart = i + 2;
                      subpos[lastsubposstart] = [i + 2];
                    }
                  }
                  if (newFrag.charAt(i) === "[" || newFrag.charAt(i) === "(" || newFrag.charAt(i) === "{") {
                    mxanynestingd++;
                  }
                  if (newFrag.charAt(i) === "]" || newFrag.charAt(i) === ")" || newFrag.charAt(i) === "}") {
                    mxanynestingd--;
                  }
                  if (newFrag.charAt(i) === "," && mxanynestingd === 1) {
                    subpos[lastsubposstart].push(i);
                  }
                  if (mxanynestingd < 0) {
                    if (lastsubposstart === i + 1) {
                      i++;
                    } else {
                      matrix = false;
                    }
                  }
                }
                pos.push(len);
                var lastmxsubcnt = -1;
                if (mxnestingd === 0 && pos.length > 0 && matrix) {
                  for (i = 0; i < pos.length - 1; i++) {
                    if (i > 0) {
                      mxout += "\\\\";
                    }
                    var subarr = void 0;
                    if (i === 0) {
                      if (subpos[pos[i]].length === 1) {
                        subarr = [newFrag.substr(pos[i] + 7, pos[i + 1] - pos[i] - 15)];
                      } else {
                        var _subarr = [newFrag.substring(pos[i] + 7, subpos[pos[i]][1])];
                        for (var j = 2; j < subpos[pos[i]].length; j++) {
                          _subarr.push(newFrag.substring(subpos[pos[i]][j - 1] + 1, subpos[pos[i]][j]));
                        }
                        _subarr.push(newFrag.substring(subpos[pos[i]][subpos[pos[i]].length - 1] + 1, pos[i + 1] - 8));
                      }
                    } else {
                      if (subpos[pos[i]].length === 1) {
                        subarr = [newFrag.substr(pos[i] + 8, pos[i + 1] - pos[i] - 16)];
                      } else {
                        subarr = [newFrag.substring(pos[i] + 8, subpos[pos[i]][1])];
                        for (var _j = 2; _j < subpos[pos[i]].length; _j++) {
                          subarr.push(newFrag.substring(subpos[pos[i]][_j - 1] + 1, subpos[pos[i]][_j]));
                        }
                        subarr.push(newFrag.substring(subpos[pos[i]][subpos[pos[i]].length - 1] + 1, pos[i + 1] - 8));
                      }
                    }
                    if (lastmxsubcnt > 0 && subarr.length !== lastmxsubcnt) {
                      matrix = false;
                    } else if (lastmxsubcnt === -1) {
                      lastmxsubcnt = subarr.length;
                    }
                    mxout += subarr.join("&");
                  }
                }
                mxout += "}";
                if (matrix) {
                  newFrag = mxout;
                }
              }
            }
          }
          str = removeCharsAndBlanks(str, symbol.input.length);
          if (typeof symbol.invisible !== "boolean" || !symbol.invisible) {
            node = "\\right" + getTeXsymbol(symbol);
            newFrag += node;
            addedright = true;
          } else {
            newFrag += "\\right.";
            addedright = true;
          }
        }
        if (nestingDepth > 0 && !addedright) {
          newFrag += "\\right.";
        }
        return [newFrag, str];
      }
      function asciimathToTex(str) {
        nestingDepth = 0;
        str = str.replace(/(&nbsp;|\u00a0|&#160;)/g, "").replace(/&gt;/g, ">").replace(/&lt;/g, "<");
        if (!str.match(/\S/)) {
          return "";
        }
        return parseExpr(str.replace(/^\s+/g, ""), false)[0];
      }
      {
        var otherSymbols = symbols.filter(function(item) {
          return item.tex && item.notexcopy !== true;
        }).map(function(item) {
          return {
            input: item.tex,
            tag: item.tag,
            output: item.output,
            ttype: item.ttype,
            acc: item.acc || false
          };
        });
        symbols.push.apply(symbols, toConsumableArray(otherSymbols));
        refreshSymbols();
      }
      function renderBlockElements(_ref) {
        var elements = _ref.elements, config = _ref.config, isAsciimath = _ref.isAsciimath;
        if (!elements.length) {
          return;
        }
        elements.forEach(function(element) {
          var input = element.textContent;
          var latex = isAsciimath ? asciimathToTex(input) : input;
          var html = katex$1.renderToString(latex, config);
          element.parentNode.outerHTML = '<span title="' + input.trim() + '">' + html + "</span>";
        });
      }
      function escapeRegExp(str) {
        return str.replace(/[-[\]/{}()*+?.\\$^|]/g, "\\$&");
      }
      var getConfig = function getConfig2() {
        var config = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return _extends({
          displayMode: true,
          throwOnError: false,
          // fail silently
          errorColor: "#ff0000"
        }, config, {
          delimiters: [{ left: "$$", right: "$$", display: false }, { left: "~", right: "~", display: false, asciimath: true }].concat(config.delimiters || [])
        });
      };
      var showdownKatex = function showdownKatex2(userConfig) {
        return function() {
          var parser = new DOMParser();
          var config = getConfig(userConfig);
          var asciimathDelimiters = config.delimiters.filter(function(item) {
            return item.asciimath;
          }).map(function(_ref2) {
            var left = _ref2.left, right = _ref2.right;
            var test = new RegExp(escapeRegExp(left) + "(.*?)" + escapeRegExp(right), "g");
            var replacer = function replacer2(match, asciimath) {
              return "" + left + asciimathToTex(asciimath) + right;
            };
            return { test, replacer };
          });
          return [{
            type: "output",
            filter: function filter() {
              var html = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
              var wrapper = parser.parseFromString(html, "text/html").body;
              if (asciimathDelimiters.length) {
                wrapper.querySelectorAll(":not(code):not(pre)").forEach(function(el) {
                  var textNodes = [].concat(toConsumableArray(el.childNodes)).filter(
                    // skip "empty" text nodes
                    function(node) {
                      return node.nodeName === "#text" && node.nodeValue.trim();
                    }
                  );
                  textNodes.forEach(function(node) {
                    var newText = asciimathDelimiters.reduce(function(acc, _ref3) {
                      var test = _ref3.test, replacer = _ref3.replacer;
                      return acc.replace(test, replacer);
                    }, node.nodeValue);
                    node.nodeValue = newText;
                  });
                });
              }
              var latex = wrapper.querySelectorAll("code.latex.language-latex");
              var asciimath = wrapper.querySelectorAll("code.asciimath.language-asciimath");
              renderBlockElements({ elements: latex, config });
              renderBlockElements({ elements: asciimath, config, isAsciimath: true });
              renderMathInElement(wrapper, config);
              return wrapper.innerHTML;
            }
          }];
        };
      };
      if (typeof window.showdown !== "undefined") {
        window.showdown.extension("showdown-katex", showdownKatex());
      }
      return showdownKatex;
    });
  }
});
export default require_showdown_katex();
/*! Bundled license information:

showdown-katex/dist/showdown-katex.js:
  (** !
   * @file showdown-katex: markdown + ( latex and/or asciimath )
   * @author obedm503
   * @git https://github.com/obedm503/showdown-katex.git
   * @examples https://obedm503.github.io/showdown-katex/
   * @license MIT
   *)
*/
//# sourceMappingURL=showdown-katex.js.map
