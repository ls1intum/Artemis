import {
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/entities/hestia/exercise-hint.model.ts
var HintType, ExerciseHint;
var init_exercise_hint_model = __esm({
  "src/main/webapp/app/entities/hestia/exercise-hint.model.ts"() {
    (function(HintType2) {
      HintType2["TEXT"] = "text";
      HintType2["CODE"] = "code";
    })(HintType || (HintType = {}));
    ExerciseHint = class {
      id;
      title;
      description;
      content;
      exercise;
      type;
      programmingExerciseTask;
      displayThreshold;
      currentUserRating;
    };
  }
});

export {
  HintType,
  ExerciseHint,
  init_exercise_hint_model
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvaGVzdGlhL2V4ZXJjaXNlLWhpbnQubW9kZWwudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9wcm9ncmFtbWluZy1leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBCYXNlRW50aXR5IH0gZnJvbSAnYXBwL3NoYXJlZC9tb2RlbC9iYXNlLWVudGl0eSc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlU2VydmVyU2lkZVRhc2sgfSBmcm9tICdhcHAvZW50aXRpZXMvaGVzdGlhL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXRhc2subW9kZWwnO1xuXG5leHBvcnQgZW51bSBIaW50VHlwZSB7XG4gICAgVEVYVCA9ICd0ZXh0JyxcbiAgICBDT0RFID0gJ2NvZGUnLFxufVxuXG5leHBvcnQgY2xhc3MgRXhlcmNpc2VIaW50IGltcGxlbWVudHMgQmFzZUVudGl0eSB7XG4gICAgcHVibGljIGlkPzogbnVtYmVyO1xuICAgIHB1YmxpYyB0aXRsZT86IHN0cmluZztcbiAgICBwdWJsaWMgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gICAgcHVibGljIGNvbnRlbnQ/OiBzdHJpbmc7XG4gICAgcHVibGljIGV4ZXJjaXNlPzogUHJvZ3JhbW1pbmdFeGVyY2lzZTtcbiAgICBwdWJsaWMgdHlwZT86IEhpbnRUeXBlO1xuICAgIHB1YmxpYyBwcm9ncmFtbWluZ0V4ZXJjaXNlVGFzaz86IFByb2dyYW1taW5nRXhlcmNpc2VTZXJ2ZXJTaWRlVGFzaztcbiAgICBwdWJsaWMgZGlzcGxheVRocmVzaG9sZD86IG51bWJlcjtcbiAgICBwdWJsaWMgY3VycmVudFVzZXJSYXRpbmc/OiBudW1iZXI7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7O0FBSUEsSUFBWSxVQUtDO0FBTGI7O0FBQUEsS0FBQSxTQUFZQSxXQUFRO0FBQ2hCLE1BQUFBLFVBQUEsTUFBQSxJQUFBO0FBQ0EsTUFBQUEsVUFBQSxNQUFBLElBQUE7SUFDSixHQUhZLGFBQUEsV0FBUSxDQUFBLEVBQUE7QUFLZCxJQUFPLGVBQVAsTUFBbUI7TUFDZDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7Ozs7IiwibmFtZXMiOlsiSGludFR5cGUiXX0=