import {
  ArtemisNavigationUtilService,
  init_navigation_utils
} from "/chunk-QOKTVWNZ.js";
import {
  IrisSettingsService,
  IrisSubSettingsType,
  init_iris_settings_service,
  init_iris_sub_settings_model
} from "/chunk-VUYHOQDW.js";
import {
  GraphColors,
  Graphs,
  SpanType,
  StatisticsView,
  axisTickFormattingWithPercentageSign,
  init_statistics_graph_utils,
  init_statistics_model,
  yAxisTickFormatting
} from "/chunk-ORYTP7RT.js";
import {
  PROFILE_LTI,
  init_app_constants
} from "/chunk-FM4KGV2V.js";
import {
  init_global_utils,
  onError
} from "/chunk-LW4WH7EZ.js";
import {
  AccountService,
  AlertService,
  ArtemisTranslatePipe,
  CourseManagementService,
  EventManager,
  FeatureToggle,
  OrganizationManagementService,
  ProfileService,
  __esm,
  convertDateFromServer,
  init_account_service,
  init_alert_service,
  init_artemis_translate_pipe,
  init_course_management_service,
  init_course_model,
  init_date_utils,
  init_event_manager_service,
  init_exercise_model,
  init_feature_toggle_service,
  init_organization_management_service,
  init_profile_service,
  init_utils,
  round,
  roundValueSpecifiedByCourseSettings
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/course/manage/detail/course-detail.component.ts
import { Component } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { faChartBar, faClipboard, faEye, faFlag, faListAlt, faTable, faTimes, faWrench } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function CourseDetailComponent_Conditional_2_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275element(1, "jhi-course-detail-doughnut-chart", 4);
    i0.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("course", ctx_r1.course)("contentType", ctx_r1.DoughnutChartType.COMPLAINTS)("currentPercentage", ctx_r1.courseDTO == null ? null : ctx_r1.courseDTO.currentPercentageComplaints)("currentAbsolute", ctx_r1.courseDTO == null ? null : ctx_r1.courseDTO.currentAbsoluteComplaints)("currentMax", ctx_r1.courseDTO == null ? null : ctx_r1.courseDTO.currentMaxComplaints);
  }
}
function CourseDetailComponent_Conditional_2_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275element(1, "jhi-course-detail-doughnut-chart", 4);
    i0.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r2 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("course", ctx_r2.course)("contentType", ctx_r2.DoughnutChartType.FEEDBACK)("currentPercentage", ctx_r2.courseDTO == null ? null : ctx_r2.courseDTO.currentPercentageMoreFeedbacks)("currentAbsolute", ctx_r2.courseDTO == null ? null : ctx_r2.courseDTO.currentAbsoluteMoreFeedbacks)("currentMax", ctx_r2.courseDTO == null ? null : ctx_r2.courseDTO.currentMaxMoreFeedbacks);
  }
}
function CourseDetailComponent_Conditional_2_Conditional_53_For_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275elementStart(1, "span", 33);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const organization_r25 = ctx.$implicit;
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(organization_r25.name);
  }
}
function CourseDetailComponent_Conditional_2_Conditional_53_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "dt")(2, "span", 31);
    i0.\u0275\u0275text(3, "Course Organizations");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275elementStart(5, "dd", 32);
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275repeaterCreate(7, CourseDetailComponent_Conditional_2_Conditional_53_For_8_Template, 4, 1, null, null, i0.\u0275\u0275repeaterTrackByIdentity);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                ");
  }
  if (rf & 2) {
    const ctx_r3 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275repeater(ctx_r3.course.organizations);
  }
}
function CourseDetailComponent_Conditional_2_Conditional_55_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275elementStart(3, "dt")(4, "span", 34);
    i0.\u0275\u0275text(5, "Student Group Name");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "dd", 35);
    i0.\u0275\u0275text(8, "\n                            ");
    i0.\u0275\u0275elementStart(9, "a", 36);
    i0.\u0275\u0275text(10);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12, "\n                        ");
    i0.\u0275\u0275elementStart(13, "dt")(14, "span", 37);
    i0.\u0275\u0275text(15, "Teaching Assistant Group Name");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(16, "\n                        ");
    i0.\u0275\u0275elementStart(17, "dd", 38);
    i0.\u0275\u0275text(18, "\n                            ");
    i0.\u0275\u0275elementStart(19, "a", 39);
    i0.\u0275\u0275text(20);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(21, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(22, "\n                        ");
    i0.\u0275\u0275elementStart(23, "dt")(24, "span", 40);
    i0.\u0275\u0275text(25, "Editor Group Name");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(26, "\n                        ");
    i0.\u0275\u0275elementStart(27, "dd", 41);
    i0.\u0275\u0275text(28, "\n                            ");
    i0.\u0275\u0275elementStart(29, "a", 42);
    i0.\u0275\u0275text(30);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(31, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(32, "\n                        ");
    i0.\u0275\u0275elementStart(33, "dt")(34, "span", 43);
    i0.\u0275\u0275text(35, "Instructor Group Name");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(36, "\n                        ");
    i0.\u0275\u0275elementStart(37, "dd", 44);
    i0.\u0275\u0275text(38, "\n                            ");
    i0.\u0275\u0275elementStart(39, "a", 45);
    i0.\u0275\u0275text(40);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(41, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(42, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(43, "\n                ");
  }
  if (rf & 2) {
    const ctx_r4 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction1(12, _c0, ctx_r4.course.id));
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate2("\n                                ", ctx_r4.course.studentGroupName, " (", ctx_r4.course.numberOfStudents, ")");
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction1(14, _c1, ctx_r4.course.id));
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate2("\n                                ", ctx_r4.course.teachingAssistantGroupName, " (", ctx_r4.course.numberOfTeachingAssistants, ")");
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction1(16, _c2, ctx_r4.course.id));
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate2("\n                                ", ctx_r4.course.editorGroupName, " (", ctx_r4.course.numberOfEditors, ")");
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction1(18, _c3, ctx_r4.course.id));
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate2("\n                                ", ctx_r4.course.instructorGroupName, " (", ctx_r4.course.numberOfInstructors, ")");
  }
}
function CourseDetailComponent_Conditional_2_Conditional_56_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275elementStart(3, "dt")(4, "span", 34);
    i0.\u0275\u0275text(5, "Student Group Name");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "dd");
    i0.\u0275\u0275text(8, "\n                            ");
    i0.\u0275\u0275elementStart(9, "span");
    i0.\u0275\u0275text(10);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12, "\n                        ");
    i0.\u0275\u0275elementStart(13, "dt")(14, "span", 37);
    i0.\u0275\u0275text(15, "Teaching Assistant Group Name");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(16, "\n                        ");
    i0.\u0275\u0275elementStart(17, "dd");
    i0.\u0275\u0275text(18, "\n                            ");
    i0.\u0275\u0275elementStart(19, "span");
    i0.\u0275\u0275text(20);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(21, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(22, "\n                        ");
    i0.\u0275\u0275elementStart(23, "dt")(24, "span", 40);
    i0.\u0275\u0275text(25, "Editor Group Name");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(26, "\n                        ");
    i0.\u0275\u0275elementStart(27, "dd");
    i0.\u0275\u0275text(28, "\n                            ");
    i0.\u0275\u0275elementStart(29, "span");
    i0.\u0275\u0275text(30);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(31, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(32, "\n                        ");
    i0.\u0275\u0275elementStart(33, "dt")(34, "span", 43);
    i0.\u0275\u0275text(35, "Instructor Group Name");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(36, "\n                        ");
    i0.\u0275\u0275elementStart(37, "dd");
    i0.\u0275\u0275text(38, "\n                            ");
    i0.\u0275\u0275elementStart(39, "span");
    i0.\u0275\u0275text(40);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(41, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(42, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(43, "\n                ");
  }
  if (rf & 2) {
    const ctx_r5 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(ctx_r5.course.studentGroupName);
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(ctx_r5.course.teachingAssistantGroupName);
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(ctx_r5.course.editorGroupName);
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(ctx_r5.course.instructorGroupName);
  }
}
function CourseDetailComponent_Conditional_2_Conditional_126_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(3, 1, "global.generic.yes"));
  }
}
function CourseDetailComponent_Conditional_2_Conditional_127_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(3, 1, "global.generic.no"));
  }
}
function CourseDetailComponent_Conditional_2_Conditional_129_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(3, 1, "global.generic.yes"));
  }
}
function CourseDetailComponent_Conditional_2_Conditional_129_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(3, 1, "global.generic.no"));
  }
}
function CourseDetailComponent_Conditional_2_Conditional_129_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "dt")(2, "span", 46);
    i0.\u0275\u0275text(3, "Online Course");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275elementStart(5, "dd", 47);
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275template(7, CourseDetailComponent_Conditional_2_Conditional_129_Conditional_7_Template, 5, 3)(8, CourseDetailComponent_Conditional_2_Conditional_129_Conditional_8_Template, 5, 3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                ");
  }
  if (rf & 2) {
    const ctx_r8 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275conditional(7, ctx_r8.course.onlineCourse ? 7 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(8, !ctx_r8.course.onlineCourse ? 8 : -1);
  }
}
function CourseDetailComponent_Conditional_2_Conditional_130_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "dd");
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275elementStart(3, "a", 48);
    i0.\u0275\u0275text(4, "LTI Configuration");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n                ");
  }
  if (rf & 2) {
    const ctx_r9 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction1(1, _c4, ctx_r9.course == null ? null : ctx_r9.course.id));
  }
}
function CourseDetailComponent_Conditional_2_Conditional_131_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "dt")(2, "span", 49);
    i0.\u0275\u0275text(3, "Enrollment Start");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275elementStart(5, "dd", 50);
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "span");
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275pipe(9, "artemisDate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                    ");
    i0.\u0275\u0275elementStart(12, "dt")(13, "span", 51);
    i0.\u0275\u0275text(14, "Enrollment End");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(15, "\n                    ");
    i0.\u0275\u0275elementStart(16, "dd", 52);
    i0.\u0275\u0275text(17, "\n                        ");
    i0.\u0275\u0275elementStart(18, "span");
    i0.\u0275\u0275text(19);
    i0.\u0275\u0275pipe(20, "artemisDate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(21, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(22, "\n                    ");
    i0.\u0275\u0275elementStart(23, "dt")(24, "span", 53);
    i0.\u0275\u0275text(25, "Registration Confirmation Message");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(26, "\n                    ");
    i0.\u0275\u0275element(27, "dd", 54);
    i0.\u0275\u0275pipe(28, "htmlForMarkdown");
    i0.\u0275\u0275text(29, "\n                ");
  }
  if (rf & 2) {
    const ctx_r10 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(9, 3, ctx_r10.course.enrollmentStartDate) || "-");
    i0.\u0275\u0275advance(11);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(20, 5, ctx_r10.course.enrollmentEndDate) || "-");
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275property("innerHTML", i0.\u0275\u0275pipeBind1(28, 7, ctx_r10.course.enrollmentConfirmationMessage), i0.\u0275\u0275sanitizeHtml);
  }
}
function CourseDetailComponent_Conditional_2_Conditional_132_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "dt")(2, "span", 55);
    i0.\u0275\u0275text(3, "Latest date to unenroll");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275elementStart(5, "dd", 56);
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "span");
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275pipe(9, "artemisDate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                ");
  }
  if (rf & 2) {
    const ctx_r11 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(9, 1, ctx_r11.course.unenrollmentEndDate) || "-");
  }
}
function CourseDetailComponent_Conditional_2_Conditional_147_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r12 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(ctx_r12.course.timeZone);
  }
}
function CourseDetailComponent_Conditional_2_Conditional_148_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(3, 1, "global.generic.unset"));
  }
}
function CourseDetailComponent_Conditional_2_Conditional_155_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "dt")(2, "span", 57);
    i0.\u0275\u0275text(3, "Maximum amount of complaints per student");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275elementStart(5, "dd", 58);
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "span");
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                    ");
    i0.\u0275\u0275elementStart(11, "dt")(12, "span", 59);
    i0.\u0275\u0275text(13, "Maximum amount of complaints per team");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(14, "\n                    ");
    i0.\u0275\u0275elementStart(15, "dd", 60);
    i0.\u0275\u0275text(16, "\n                        ");
    i0.\u0275\u0275elementStart(17, "span");
    i0.\u0275\u0275text(18);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(19, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(20, "\n                    ");
    i0.\u0275\u0275elementStart(21, "dt")(22, "span", 61);
    i0.\u0275\u0275text(23, "Due date for complaints in days after result date");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(24, "\n                    ");
    i0.\u0275\u0275elementStart(25, "dd", 62);
    i0.\u0275\u0275text(26, "\n                        ");
    i0.\u0275\u0275elementStart(27, "span");
    i0.\u0275\u0275text(28);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(29, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(30, "\n                    ");
    i0.\u0275\u0275elementStart(31, "dt")(32, "span", 63);
    i0.\u0275\u0275text(33, "Maximum number of characters per complaint");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(34, "\n                    ");
    i0.\u0275\u0275elementStart(35, "dd", 64);
    i0.\u0275\u0275text(36, "\n                        ");
    i0.\u0275\u0275elementStart(37, "span");
    i0.\u0275\u0275text(38);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(39, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(40, "\n                    ");
    i0.\u0275\u0275elementStart(41, "dt")(42, "span", 65);
    i0.\u0275\u0275text(43, "Maximum number of characters per complaint response");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(44, "\n                    ");
    i0.\u0275\u0275elementStart(45, "dd", 66);
    i0.\u0275\u0275text(46, "\n                        ");
    i0.\u0275\u0275elementStart(47, "span");
    i0.\u0275\u0275text(48);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(49, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(50, "\n                ");
  }
  if (rf & 2) {
    const ctx_r14 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275textInterpolate(ctx_r14.course.maxComplaints || "-");
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(ctx_r14.course.maxTeamComplaints || "-");
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(ctx_r14.course.maxComplaintTimeDays || "-");
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(ctx_r14.course.maxComplaintTextLimit || "-");
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(ctx_r14.course.maxComplaintResponseTextLimit || "-");
  }
}
function CourseDetailComponent_Conditional_2_Conditional_156_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "dt")(2, "span", 67);
    i0.\u0275\u0275text(3, "Due date for more feedback requests in days after result date");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275elementStart(5, "dd", 68);
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "span");
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n                ");
  }
  if (rf & 2) {
    const ctx_r15 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275textInterpolate(ctx_r15.course.maxRequestMoreFeedbackTimeDays || "-");
  }
}
function CourseDetailComponent_Conditional_2_Conditional_163_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(3, 1, "global.generic.yes"));
  }
}
function CourseDetailComponent_Conditional_2_Conditional_164_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(3, 1, "global.generic.no"));
  }
}
function CourseDetailComponent_Conditional_2_Conditional_172_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(3, 1, "global.generic.yes"));
  }
}
function CourseDetailComponent_Conditional_2_Conditional_173_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "span");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(3, 1, "global.generic.no"));
  }
}
function CourseDetailComponent_Conditional_2_Conditional_175_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "dt")(2, "span", 69);
    i0.\u0275\u0275text(3, "Messaging Code of Conduct");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(4, "\n                    ");
    i0.\u0275\u0275element(5, "dd", 70);
    i0.\u0275\u0275pipe(6, "htmlForMarkdown");
    i0.\u0275\u0275text(7, "\n                ");
  }
  if (rf & 2) {
    const ctx_r20 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275property("innerHTML", i0.\u0275\u0275pipeBind1(6, 1, ctx_r20.course.courseInformationSharingMessagingCodeOfConduct), i0.\u0275\u0275sanitizeHtml);
  }
}
function CourseDetailComponent_Conditional_2_Conditional_176_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275elementStart(3, "dt")(4, "span", 71);
    i0.\u0275\u0275text(5, "Iris Chat");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "dd");
    i0.\u0275\u0275text(8, "\n                            ");
    i0.\u0275\u0275element(9, "jhi-iris-enabled", 72);
    i0.\u0275\u0275text(10, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12, "\n                ");
  }
  if (rf & 2) {
    const ctx_r21 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275property("course", ctx_r21.course)("irisSubSettingsType", ctx_r21.CHAT)("disabled", !ctx_r21.isAdmin);
  }
}
function CourseDetailComponent_Conditional_2_Conditional_178_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275elementStart(3, "dt")(4, "span", 73);
    i0.\u0275\u0275text(5, "Iris Hestia");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "dd");
    i0.\u0275\u0275text(8, "\n                            ");
    i0.\u0275\u0275element(9, "jhi-iris-enabled", 72);
    i0.\u0275\u0275text(10, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12, "\n                ");
  }
  if (rf & 2) {
    const ctx_r22 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275property("course", ctx_r22.course)("irisSubSettingsType", ctx_r22.HESTIA)("disabled", !ctx_r22.isAdmin);
  }
}
function CourseDetailComponent_Conditional_2_Conditional_180_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                    ");
    i0.\u0275\u0275elementStart(1, "div");
    i0.\u0275\u0275text(2, "\n                        ");
    i0.\u0275\u0275elementStart(3, "dt")(4, "span", 74);
    i0.\u0275\u0275text(5, "Iris CodeEditor");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(6, "\n                        ");
    i0.\u0275\u0275elementStart(7, "dd");
    i0.\u0275\u0275text(8, "\n                            ");
    i0.\u0275\u0275element(9, "jhi-iris-enabled", 72);
    i0.\u0275\u0275text(10, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12, "\n                ");
  }
  if (rf & 2) {
    const ctx_r23 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275property("course", ctx_r23.course)("irisSubSettingsType", ctx_r23.CODE_EDITOR)("disabled", !ctx_r23.isAdmin);
  }
}
function CourseDetailComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "div", 1);
    i0.\u0275\u0275text(2, "\n            ");
    i0.\u0275\u0275elementStart(3, "div", 2);
    i0.\u0275\u0275text(4, "\n                ");
    i0.\u0275\u0275elementStart(5, "div", 3);
    i0.\u0275\u0275text(6, "\n                    ");
    i0.\u0275\u0275elementStart(7, "div", 2);
    i0.\u0275\u0275text(8, "\n                        ");
    i0.\u0275\u0275element(9, "jhi-course-detail-doughnut-chart", 4);
    i0.\u0275\u0275text(10, "\n                        ");
    i0.\u0275\u0275template(11, CourseDetailComponent_Conditional_2_Conditional_11_Template, 3, 5)(12, CourseDetailComponent_Conditional_2_Conditional_12_Template, 3, 5);
    i0.\u0275\u0275element(13, "jhi-course-detail-doughnut-chart", 4);
    i0.\u0275\u0275text(14, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(15, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(16, "\n                ");
    i0.\u0275\u0275element(17, "jhi-course-detail-line-chart", 5);
    i0.\u0275\u0275text(18, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(19, "\n            ");
    i0.\u0275\u0275element(20, "hr");
    i0.\u0275\u0275text(21, "\n            ");
    i0.\u0275\u0275elementStart(22, "div");
    i0.\u0275\u0275text(23, "\n                ");
    i0.\u0275\u0275elementStart(24, "h2")(25, "span", 6);
    i0.\u0275\u0275text(26, "Course Details:");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(27, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(28, "\n            ");
    i0.\u0275\u0275element(29, "hr");
    i0.\u0275\u0275text(30, "\n            ");
    i0.\u0275\u0275elementStart(31, "dl", 7);
    i0.\u0275\u0275text(32, "\n                ");
    i0.\u0275\u0275elementStart(33, "dt")(34, "span", 8);
    i0.\u0275\u0275text(35, "Title");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(36, "\n                ");
    i0.\u0275\u0275elementStart(37, "dd", 9);
    i0.\u0275\u0275text(38, "\n                    ");
    i0.\u0275\u0275elementStart(39, "span");
    i0.\u0275\u0275text(40);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(41, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(42, "\n                ");
    i0.\u0275\u0275elementStart(43, "dt")(44, "span", 10);
    i0.\u0275\u0275text(45, "Short Name");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(46, "\n                ");
    i0.\u0275\u0275elementStart(47, "dd", 11);
    i0.\u0275\u0275text(48, "\n                    ");
    i0.\u0275\u0275elementStart(49, "span");
    i0.\u0275\u0275text(50);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(51, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(52, "\n                ");
    i0.\u0275\u0275template(53, CourseDetailComponent_Conditional_2_Conditional_53_Template, 10, 0);
    i0.\u0275\u0275text(54, "\n                ");
    i0.\u0275\u0275template(55, CourseDetailComponent_Conditional_2_Conditional_55_Template, 44, 20)(56, CourseDetailComponent_Conditional_2_Conditional_56_Template, 44, 4);
    i0.\u0275\u0275text(57, "\n                ");
    i0.\u0275\u0275elementStart(58, "dt")(59, "span", 12);
    i0.\u0275\u0275text(60, "Max. Number of Points");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(61, "\n                ");
    i0.\u0275\u0275elementStart(62, "dd");
    i0.\u0275\u0275text(63, "\n                    ");
    i0.\u0275\u0275elementStart(64, "span");
    i0.\u0275\u0275text(65);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(66, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(67, "\n                ");
    i0.\u0275\u0275elementStart(68, "dt")(69, "span", 13);
    i0.\u0275\u0275text(70, "Number of decimal places used for calculating the scores");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(71, "\n                ");
    i0.\u0275\u0275elementStart(72, "dd");
    i0.\u0275\u0275text(73, "\n                    ");
    i0.\u0275\u0275elementStart(74, "span");
    i0.\u0275\u0275text(75);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(76, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(77, "\n                ");
    i0.\u0275\u0275elementStart(78, "dt")(79, "span", 14);
    i0.\u0275\u0275text(80, "Start Date");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(81, "\n                ");
    i0.\u0275\u0275elementStart(82, "dd", 15);
    i0.\u0275\u0275text(83, "\n                    ");
    i0.\u0275\u0275elementStart(84, "span");
    i0.\u0275\u0275text(85);
    i0.\u0275\u0275pipe(86, "artemisDate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(87, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(88, "\n                ");
    i0.\u0275\u0275elementStart(89, "dt")(90, "span", 16);
    i0.\u0275\u0275text(91, "End Date");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(92, "\n                ");
    i0.\u0275\u0275elementStart(93, "dd", 17);
    i0.\u0275\u0275text(94, "\n                    ");
    i0.\u0275\u0275elementStart(95, "span");
    i0.\u0275\u0275text(96);
    i0.\u0275\u0275pipe(97, "artemisDate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(98, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(99, "\n                ");
    i0.\u0275\u0275elementStart(100, "dt")(101, "span", 18);
    i0.\u0275\u0275text(102, "Semester");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(103, "\n                ");
    i0.\u0275\u0275elementStart(104, "dd", 19);
    i0.\u0275\u0275text(105, "\n                    ");
    i0.\u0275\u0275elementStart(106, "span");
    i0.\u0275\u0275text(107);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(108, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(109, "\n                ");
    i0.\u0275\u0275elementStart(110, "dt")(111, "span", 20);
    i0.\u0275\u0275text(112, "Default Programming Language");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(113, "\n                ");
    i0.\u0275\u0275elementStart(114, "dd", 21);
    i0.\u0275\u0275text(115, "\n                    ");
    i0.\u0275\u0275elementStart(116, "span");
    i0.\u0275\u0275text(117);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(118, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(119, "\n                ");
    i0.\u0275\u0275elementStart(120, "dt")(121, "span", 22);
    i0.\u0275\u0275text(122, "Test Course");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(123, "\n                ");
    i0.\u0275\u0275elementStart(124, "dd", 23);
    i0.\u0275\u0275text(125, "\n                    ");
    i0.\u0275\u0275template(126, CourseDetailComponent_Conditional_2_Conditional_126_Template, 5, 3)(127, CourseDetailComponent_Conditional_2_Conditional_127_Template, 5, 3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(128, "\n                ");
    i0.\u0275\u0275template(129, CourseDetailComponent_Conditional_2_Conditional_129_Template, 10, 2)(130, CourseDetailComponent_Conditional_2_Conditional_130_Template, 7, 3)(131, CourseDetailComponent_Conditional_2_Conditional_131_Template, 30, 9)(132, CourseDetailComponent_Conditional_2_Conditional_132_Template, 12, 3);
    i0.\u0275\u0275elementContainerStart(133, 24);
    i0.\u0275\u0275text(134, "\n                    ");
    i0.\u0275\u0275elementStart(135, "dt");
    i0.\u0275\u0275text(136, "\n                        ");
    i0.\u0275\u0275elementStart(137, "span");
    i0.\u0275\u0275text(138);
    i0.\u0275\u0275pipe(139, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(140, "\n                        ");
    i0.\u0275\u0275elementStart(141, "span", 25);
    i0.\u0275\u0275text(142, "BETA");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(143, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(144, "\n                    ");
    i0.\u0275\u0275elementStart(145, "dd");
    i0.\u0275\u0275text(146, "\n                        ");
    i0.\u0275\u0275template(147, CourseDetailComponent_Conditional_2_Conditional_147_Template, 4, 1)(148, CourseDetailComponent_Conditional_2_Conditional_148_Template, 5, 3);
    i0.\u0275\u0275elementStart(149, "div", 26);
    i0.\u0275\u0275text(150);
    i0.\u0275\u0275pipe(151, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(152, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(153, "\n                ");
    i0.\u0275\u0275elementContainerEnd();
    i0.\u0275\u0275text(154, "\n                ");
    i0.\u0275\u0275template(155, CourseDetailComponent_Conditional_2_Conditional_155_Template, 51, 5)(156, CourseDetailComponent_Conditional_2_Conditional_156_Template, 11, 1);
    i0.\u0275\u0275elementStart(157, "dt")(158, "span", 27);
    i0.\u0275\u0275text(159, "Communication Enabled");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(160, "\n                ");
    i0.\u0275\u0275elementStart(161, "dd", 28);
    i0.\u0275\u0275text(162, "\n                    ");
    i0.\u0275\u0275template(163, CourseDetailComponent_Conditional_2_Conditional_163_Template, 5, 3)(164, CourseDetailComponent_Conditional_2_Conditional_164_Template, 5, 3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(165, "\n                ");
    i0.\u0275\u0275elementStart(166, "dt")(167, "span", 29);
    i0.\u0275\u0275text(168, "Messaging Enabled");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275text(169, "\n                ");
    i0.\u0275\u0275elementStart(170, "dd", 30);
    i0.\u0275\u0275text(171, "\n                    ");
    i0.\u0275\u0275template(172, CourseDetailComponent_Conditional_2_Conditional_172_Template, 5, 3)(173, CourseDetailComponent_Conditional_2_Conditional_173_Template, 5, 3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(174, "\n                ");
    i0.\u0275\u0275template(175, CourseDetailComponent_Conditional_2_Conditional_175_Template, 8, 3)(176, CourseDetailComponent_Conditional_2_Conditional_176_Template, 13, 3);
    i0.\u0275\u0275text(177, "\n                ");
    i0.\u0275\u0275template(178, CourseDetailComponent_Conditional_2_Conditional_178_Template, 13, 3);
    i0.\u0275\u0275text(179, "\n                ");
    i0.\u0275\u0275template(180, CourseDetailComponent_Conditional_2_Conditional_180_Template, 13, 3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(181, "\n        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(182, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275property("course", ctx_r0.course)("contentType", ctx_r0.DoughnutChartType.ASSESSMENT)("currentPercentage", ctx_r0.courseDTO == null ? null : ctx_r0.courseDTO.currentPercentageAssessments)("currentAbsolute", ctx_r0.courseDTO == null ? null : ctx_r0.courseDTO.currentAbsoluteAssessments)("currentMax", ctx_r0.courseDTO == null ? null : ctx_r0.courseDTO.currentMaxAssessments);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(11, ctx_r0.course.complaintsEnabled ? 11 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(12, ctx_r0.course.requestMoreFeedbackEnabled ? 12 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("course", ctx_r0.course)("contentType", ctx_r0.DoughnutChartType.AVERAGE_COURSE_SCORE)("currentPercentage", ctx_r0.courseDTO == null ? null : ctx_r0.courseDTO.currentPercentageAverageScore)("currentAbsolute", ctx_r0.courseDTO == null ? null : ctx_r0.courseDTO.currentAbsoluteAverageScore)("currentMax", ctx_r0.courseDTO == null ? null : ctx_r0.courseDTO.currentMaxAverageScore);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275property("course", ctx_r0.course)("numberOfStudentsInCourse", ctx_r0.course.numberOfStudents)("initialStats", ctx_r0.activeStudents);
    i0.\u0275\u0275advance(23);
    i0.\u0275\u0275textInterpolate(ctx_r0.course.title);
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(ctx_r0.course.shortName);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(53, !!(ctx_r0.course.organizations == null ? null : ctx_r0.course.organizations.length) ? 53 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(55, ctx_r0.course.isAtLeastInstructor ? 55 : 56);
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(ctx_r0.course.maxPoints || "-");
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(ctx_r0.course.accuracyOfScores || "-");
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(86, 46, ctx_r0.course.startDate) || "-");
    i0.\u0275\u0275advance(11);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(97, 48, ctx_r0.course.endDate) || "-");
    i0.\u0275\u0275advance(11);
    i0.\u0275\u0275textInterpolate(ctx_r0.course.semester || "-");
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275textInterpolate(ctx_r0.course.defaultProgrammingLanguage || "-");
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275conditional(126, ctx_r0.course.testCourse ? 126 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(127, !ctx_r0.course.testCourse ? 127 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(129, ctx_r0.ltiEnabled ? 129 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(130, ctx_r0.ltiEnabled && ctx_r0.course.onlineCourse && ctx_r0.course.isAtLeastInstructor ? 130 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(131, ctx_r0.course.enrollmentEnabled ? 131 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(132, ctx_r0.course.unenrollmentEnabled ? 132 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("jhiFeatureToggleLink", ctx_r0.FeatureToggle.TutorialGroups);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate1("", i0.\u0275\u0275pipeBind1(139, 50, "artemisApp.forms.configurationForm.timeZoneInput.label"), " ");
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275conditional(147, ctx_r0.course.timeZone ? 147 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(148, !ctx_r0.course.timeZone ? 148 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n                            ", i0.\u0275\u0275pipeBind1(151, 52, "artemisApp.forms.configurationForm.timeZoneInput.beta"), "\n                        ");
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275conditional(155, ctx_r0.course.complaintsEnabled ? 155 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(156, ctx_r0.course.requestMoreFeedbackEnabled ? 156 : -1);
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275conditional(163, ctx_r0.communicationEnabled ? 163 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(164, !ctx_r0.communicationEnabled ? 164 : -1);
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275conditional(172, ctx_r0.messagingEnabled ? 172 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(173, !ctx_r0.messagingEnabled ? 173 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(175, ctx_r0.messagingEnabled ? 175 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(176, ctx_r0.irisEnabled && ctx_r0.irisChatEnabled ? 176 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(178, false ? 178 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(180, false ? 180 : -1);
  }
}
var _c0, _c1, _c2, _c3, _c4, DoughnutChartType, CourseDetailComponent;
var init_course_detail_component = __esm({
  "src/main/webapp/app/course/manage/detail/course-detail.component.ts"() {
    init_app_constants();
    init_profile_service();
    init_course_management_service();
    init_global_utils();
    init_alert_service();
    init_event_manager_service();
    init_feature_toggle_service();
    init_organization_management_service();
    init_iris_sub_settings_model();
    init_iris_settings_service();
    init_account_service();
    init_event_manager_service();
    init_course_management_service();
    init_organization_management_service();
    init_alert_service();
    init_profile_service();
    init_account_service();
    init_iris_settings_service();
    _c0 = (a1) => ["/course-management", a1, "groups", "students"];
    _c1 = (a1) => ["/course-management", a1, "groups", "tutors"];
    _c2 = (a1) => ["/course-management", a1, "groups", "editors"];
    _c3 = (a1) => ["/course-management", a1, "groups", "instructors"];
    _c4 = (a1) => ["/course-management", a1, "lti-configuration"];
    (function(DoughnutChartType2) {
      DoughnutChartType2["ASSESSMENT"] = "ASSESSMENT";
      DoughnutChartType2["COMPLAINTS"] = "COMPLAINTS";
      DoughnutChartType2["FEEDBACK"] = "FEEDBACK";
      DoughnutChartType2["AVERAGE_COURSE_SCORE"] = "AVERAGE_COURSE_SCORE";
      DoughnutChartType2["AVERAGE_EXERCISE_SCORE"] = "AVERAGE_EXERCISE_SCORE";
      DoughnutChartType2["PARTICIPATIONS"] = "PARTICIPATIONS";
      DoughnutChartType2["QUESTIONS"] = "QUESTIONS";
    })(DoughnutChartType || (DoughnutChartType = {}));
    CourseDetailComponent = class _CourseDetailComponent {
      eventManager;
      courseManagementService;
      organizationService;
      route;
      alertService;
      profileService;
      accountService;
      irisSettingsService;
      DoughnutChartType = DoughnutChartType;
      FeatureToggle = FeatureToggle;
      CHAT = IrisSubSettingsType.CHAT;
      HESTIA = IrisSubSettingsType.HESTIA;
      CODE_EDITOR = IrisSubSettingsType.CODE_EDITOR;
      courseDTO;
      activeStudents;
      course;
      messagingEnabled;
      communicationEnabled;
      irisEnabled = false;
      irisChatEnabled = false;
      irisHestiaEnabled = false;
      irisCodeEditorEnabled = false;
      ltiEnabled = false;
      isAdmin = false;
      eventSubscriber;
      paramSub;
      faTimes = faTimes;
      faEye = faEye;
      faWrench = faWrench;
      faTable = faTable;
      faFlag = faFlag;
      faListAlt = faListAlt;
      faChartBar = faChartBar;
      faClipboard = faClipboard;
      constructor(eventManager, courseManagementService, organizationService, route, alertService, profileService, accountService, irisSettingsService) {
        this.eventManager = eventManager;
        this.courseManagementService = courseManagementService;
        this.organizationService = organizationService;
        this.route = route;
        this.alertService = alertService;
        this.profileService = profileService;
        this.accountService = accountService;
        this.irisSettingsService = irisSettingsService;
      }
      ngOnInit() {
        this.profileService.getProfileInfo().subscribe((profileInfo) => {
          this.ltiEnabled = profileInfo.activeProfiles.includes(PROFILE_LTI);
          this.irisEnabled = profileInfo.activeProfiles.includes("iris");
          if (this.irisEnabled) {
            this.irisSettingsService.getGlobalSettings().subscribe((settings) => {
              this.irisChatEnabled = settings?.irisChatSettings?.enabled ?? false;
              this.irisHestiaEnabled = settings?.irisHestiaSettings?.enabled ?? false;
              this.irisCodeEditorEnabled = settings?.irisCodeEditorSettings?.enabled ?? false;
            });
          }
        });
        this.route.data.subscribe(({ course }) => {
          if (course) {
            this.course = course;
            this.messagingEnabled = !!this.course.courseInformationSharingConfiguration?.includes("MESSAGING");
            this.communicationEnabled = !!this.course.courseInformationSharingConfiguration?.includes("COMMUNICATION");
          }
          this.isAdmin = this.accountService.isAdmin();
        });
        let courseId = 0;
        this.paramSub = this.route.params.subscribe((params) => {
          courseId = params["courseId"];
        });
        this.fetchCourseStatistics(courseId);
        this.registerChangeInCourses(courseId);
        this.fetchOrganizations(courseId);
      }
      registerChangeInCourses(courseId) {
        this.eventSubscriber = this.eventManager.subscribe("courseListModification", () => {
          this.courseManagementService.find(courseId).subscribe((courseResponse) => {
            this.course = courseResponse.body;
          });
          this.fetchCourseStatistics(courseId);
        });
      }
      ngOnDestroy() {
        if (this.paramSub) {
          this.paramSub.unsubscribe();
        }
        this.eventManager.destroy(this.eventSubscriber);
      }
      fetchCourseStatistics(courseId) {
        this.courseManagementService.getCourseStatisticsForDetailView(courseId).subscribe({
          next: (courseResponse) => {
            this.courseDTO = courseResponse.body;
            this.activeStudents = courseResponse.body.activeStudents;
          },
          error: (error) => onError(this.alertService, error)
        });
      }
      fetchOrganizations(courseId) {
        this.organizationService.getOrganizationsByCourse(courseId).subscribe((organizations) => {
          this.course.organizations = organizations;
        });
      }
      static \u0275fac = function CourseDetailComponent_Factory(t) {
        return new (t || _CourseDetailComponent)(i0.\u0275\u0275directiveInject(EventManager), i0.\u0275\u0275directiveInject(CourseManagementService), i0.\u0275\u0275directiveInject(OrganizationManagementService), i0.\u0275\u0275directiveInject(i4.ActivatedRoute), i0.\u0275\u0275directiveInject(AlertService), i0.\u0275\u0275directiveInject(ProfileService), i0.\u0275\u0275directiveInject(AccountService), i0.\u0275\u0275directiveInject(IrisSettingsService));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _CourseDetailComponent, selectors: [["jhi-course-detail"]], decls: 4, vars: 1, consts: [[1, "row", "justify-content-center"], [1, "col-12"], [1, "row"], [1, "col-xxl-4"], [1, "doughnut-container", "col-sm-6", "my-3", 3, "course", "contentType", "currentPercentage", "currentAbsolute", "currentMax"], [1, "col-xxl-8", 3, "course", "numberOfStudentsInCourse", "initialStats"], ["jhiTranslate", "artemisApp.course.detail.title"], [1, "row-md", "jh-entity-details"], ["jhiTranslate", "artemisApp.course.title"], ["id", "course-title"], ["jhiTranslate", "artemisApp.course.shortName"], ["id", "course-short-name"], ["jhiTranslate", "artemisApp.course.maxPoints.title"], ["jhiTranslate", "artemisApp.course.accuracyOfScores"], ["jhiTranslate", "artemisApp.course.startDate"], ["id", "course-start-date"], ["jhiTranslate", "artemisApp.course.endDate"], ["id", "course-end-date"], ["jhiTranslate", "artemisApp.course.semester"], ["id", "course-semester"], ["jhiTranslate", "artemisApp.course.defaultProgrammingLanguage"], ["id", "course-programming-language"], ["jhiTranslate", "artemisApp.course.testCourse.title"], ["id", "course-test-course"], [3, "jhiFeatureToggleLink"], [1, "badge", "rounded-pill", "text-bg-warning", "ms-1"], [1, "form-text"], ["jhiTranslate", "artemisApp.course.courseCommunicationSetting.communicationEnabled.label"], ["id", "course-communication-enabled"], ["jhiTranslate", "artemisApp.course.courseCommunicationSetting.messagingEnabled.label"], ["id", "course-messaging-enabled"], ["jhiTranslate", "artemisApp.course.organizations"], ["id", "course-organisations"], [1, "badge", "bg-primary", "font-weight-normal", "m-1", "ps-3"], ["jhiTranslate", "artemisApp.course.studentGroupName"], ["id", "course-student-group-name"], ["id", "add-students", 3, "routerLink"], ["jhiTranslate", "artemisApp.course.teachingAssistantGroupName"], ["id", "course-tutor-group-name"], ["id", "add-tutors", 3, "routerLink"], ["jhiTranslate", "artemisApp.course.editorGroupName"], ["id", "course-editor-group-name"], ["id", "add-editors", 3, "routerLink"], ["jhiTranslate", "artemisApp.course.instructorGroupName"], ["id", "course-instructor-group-name"], ["id", "add-instructors", 3, "routerLink"], ["jhiTranslate", "artemisApp.course.onlineCourse.title"], ["id", "course-online-course"], [3, "routerLink"], ["jhiTranslate", "artemisApp.course.enrollmentStartDate"], ["id", "course-enrollment-start-date"], ["jhiTranslate", "artemisApp.course.enrollmentEndDate"], ["id", "course-enrollment-end-date"], ["jhiTranslate", "artemisApp.course.registrationConfirmationMessage"], ["id", "course-enrollment-confirmation", 1, "markdown-preview", "editor-outline-background", 3, "innerHTML"], ["jhiTranslate", "artemisApp.course.unenrollmentEndDate"], ["id", "course-unenrollment-end-date"], ["jhiTranslate", "artemisApp.course.maxComplaints.title"], ["id", "course-max-complaints"], ["jhiTranslate", "artemisApp.course.maxTeamComplaints.title"], ["id", "course-max-team-complaints"], ["jhiTranslate", "artemisApp.course.maxComplaintTimeDays.title"], ["id", "course-max-time-days"], ["jhiTranslate", "artemisApp.course.maxComplaintTextLimit.title"], ["id", "course-max-complaint-text-limit"], ["jhiTranslate", "artemisApp.course.maxComplaintResponseTextLimit.title"], ["id", "course-max-complaint-response-text-limit"], ["jhiTranslate", "artemisApp.course.maxRequestMoreFeedbackTimeDays.title"], ["id", "course-max-request-more-feedback-days"], ["jhiTranslate", "artemisApp.course.courseCommunicationSetting.messagingEnabled.codeOfConduct"], ["id", "course-code-of-conduct", 1, "markdown-preview", "editor-outline-background", 3, "innerHTML"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.enabled.chat"], [3, "course", "irisSubSettingsType", "disabled"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.enabled.hesita"], ["jhiTranslate", "artemisApp.iris.settings.subSettings.enabled.codeEditor"]], template: function CourseDetailComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "div", 0);
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275template(2, CourseDetailComponent_Conditional_2_Template, 183, 54);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(3, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275conditional(2, ctx.course ? 2 : -1);
        }
      }, styles: ["\n\njhi-secured-image[_ngcontent-%COMP%] {\n  padding-right: 20px;\n}\njhi-secured-image[_ngcontent-%COMP%]     img {\n  border-radius: 50%;\n  height: 100px;\n  width: auto;\n  margin-bottom: 10px;\n}\njhi-secured-image[_ngcontent-%COMP%]    + h2[_ngcontent-%COMP%] {\n  display: inline;\n}\n.doughnut-container[_ngcontent-%COMP%] {\n  min-width: 200px;\n}\n.fullscreen[_ngcontent-%COMP%] {\n  margin-top: 4px;\n}\n@media (min-width: 1400px) {\n  .col-xxl-4[_ngcontent-%COMP%] {\n    width: 1/3%;\n  }\n  .col-xxl-8[_ngcontent-%COMP%] {\n    width: 2/3%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbWFuYWdlL2RldGFpbC9jb3Vyc2UtZGV0YWlsLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJqaGktc2VjdXJlZC1pbWFnZSB7XG4gICAgcGFkZGluZy1yaWdodDogMjBweDtcblxuICAgIDo6bmctZGVlcCBpbWcge1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgIGhlaWdodDogMTAwcHg7XG4gICAgICAgIHdpZHRoOiBhdXRvO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgIH1cblxuICAgICsgaDIge1xuICAgICAgICBkaXNwbGF5OiBpbmxpbmU7XG4gICAgfVxufVxuXG4uZG91Z2hudXQtY29udGFpbmVyIHtcbiAgICBtaW4td2lkdGg6IDIwMHB4O1xufVxuXG4uZnVsbHNjcmVlbiB7XG4gICAgbWFyZ2luLXRvcDogNHB4O1xufVxuXG5AbWVkaWEgKG1pbi13aWR0aDogMTQwMHB4KSB7XG4gICAgLmNvbC14eGwtNCB7XG4gICAgICAgIHdpZHRoOiAxLzMlO1xuICAgIH1cblxuICAgIC5jb2wteHhsLTgge1xuICAgICAgICB3aWR0aDogMi8zJTtcbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUE7QUFDSSxpQkFBQTs7QUFFQSxrQkFBQSxVQUFBO0FBQ0ksaUJBQUE7QUFDQSxVQUFBO0FBQ0EsU0FBQTtBQUNBLGlCQUFBOztBQUdKLGtCQUFBLEVBQUE7QUFDSSxXQUFBOztBQUlSLENBQUE7QUFDSSxhQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBOztBQUdKLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFDSSxHQUFBO0FBQ0ksV0FBQSxDQUFBLENBQUE7O0FBR0osR0FBQTtBQUNJLFdBQUEsQ0FBQSxDQUFBOzs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(CourseDetailComponent, { className: "CourseDetailComponent" });
    })();
  }
});

// src/main/webapp/app/shared/statistics-graph/statistics.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient, HttpParams } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var StatisticsService;
var init_statistics_service = __esm({
  "src/main/webapp/app/shared/statistics-graph/statistics.service.ts"() {
    init_utils();
    init_date_utils();
    StatisticsService = class _StatisticsService {
      http;
      basePath = "management/statistics/";
      resourceUrl = "api/" + this.basePath;
      adminResourceUrl = "api/admin/" + this.basePath;
      constructor(http) {
        this.http = http;
      }
      getChartData(span, periodIndex, graphType) {
        const params = new HttpParams().set("span", "" + span).set("periodIndex", "" + periodIndex).set("graphType", "" + graphType);
        return this.http.get(`${this.adminResourceUrl}data`, { params });
      }
      getChartDataForContent(span, periodIndex, graphType, view, entityId) {
        const params = new HttpParams().set("span", "" + span).set("periodIndex", "" + periodIndex).set("graphType", "" + graphType).set("view", "" + view).set("entityId", "" + entityId);
        return this.http.get(`${this.resourceUrl}data-for-content`, { params });
      }
      getCourseStatistics(courseId) {
        const params = new HttpParams().set("courseId", "" + courseId);
        return this.http.get(`${this.resourceUrl}course-statistics`, { params }).pipe(map((res) => {
          _StatisticsService.convertExerciseCategoriesOfrCourseManagementStatisticsFromServer(res);
          return _StatisticsService.convertCourseManagementStatisticDatesFromServer(res);
        }));
      }
      getExerciseStatistics(exerciseId) {
        const params = new HttpParams().set("exerciseId", "" + exerciseId);
        return this.http.get(`${this.resourceUrl}exercise-statistics`, { params }).pipe(map((res) => _StatisticsService.calculatePercentagesForExerciseStatistics(res)));
      }
      static calculatePercentagesForExerciseStatistics(stats) {
        stats.participationsInPercent = stats.numberOfStudentsOrTeamsInCourse > 0 ? round(stats.numberOfParticipations / stats.numberOfStudentsOrTeamsInCourse * 100, 1) : 0;
        stats.resolvedPostsInPercent = stats.numberOfPosts > 0 ? round(stats.numberOfResolvedPosts / stats.numberOfPosts * 100, 1) : 0;
        stats.absoluteAveragePoints = round(stats.averageScoreOfExercise * stats.maxPointsOfExercise / 100, 1);
        return stats;
      }
      static convertCourseManagementStatisticDatesFromServer(dto) {
        dto.averageScoresOfExercises.forEach((averageScores) => {
          averageScores.releaseDate = convertDateFromServer(averageScores.releaseDate);
        });
        return dto;
      }
      static convertExerciseCategoriesOfrCourseManagementStatisticsFromServer(res) {
        res.averageScoresOfExercises.forEach((avgScoresOfExercise) => {
          avgScoresOfExercise.categories = avgScoresOfExercise.categories?.map((category) => JSON.parse(category));
        });
        return res;
      }
      static \u0275fac = function StatisticsService_Factory(t) {
        return new (t || _StatisticsService)(i02.\u0275\u0275inject(i1.HttpClient));
      };
      static \u0275prov = i02.\u0275\u0275defineInjectable({ token: _StatisticsService, factory: _StatisticsService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/shared/statistics/doughnut-chart.component.ts
import { Component as Component2, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { faSpinner } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { ScaleType } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i42 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
function DoughnutChartComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275elementStart(1, "a", 4);
    i03.\u0275\u0275text(2, "\n            ");
    i03.\u0275\u0275elementStart(3, "h4", 5);
    i03.\u0275\u0275text(4);
    i03.\u0275\u0275pipe(5, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(6, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(7, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("routerLink", ctx_r0.titleLink);
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(5, 2, "exercise-statistics." + ctx_r0.doughnutChartTitle));
  }
}
function DoughnutChartComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275elementStart(1, "h4", 5);
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275pipe(3, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(4, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(3, 1, "exercise-statistics." + ctx_r1.doughnutChartTitle));
  }
}
function DoughnutChartComponent_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275elementStart(1, "h2", 5);
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n            ");
  }
  if (rf & 2) {
    const ctx_r2 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275textInterpolate1("", ctx_r2.currentPercentage, "%");
  }
}
function DoughnutChartComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275elementStart(1, "h4", 5);
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n            ");
  }
  if (rf & 2) {
    const ctx_r3 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275textInterpolate2("", ctx_r3.currentAbsolute, " / ", ctx_r3.currentMax, "");
  }
}
function DoughnutChartComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275elementStart(1, "h1", 6);
    i03.\u0275\u0275text(2, "\n                    ");
    i03.\u0275\u0275elementStart(3, "fa-icon", 7);
    i03.\u0275\u0275text(4, "\xA0");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(6, "\n            ");
  }
  if (rf & 2) {
    const ctx_r4 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("icon", ctx_r4.faSpinner)("spin", true);
  }
}
var _c02, PIE_CHART_NA_FALLBACK_VALUE, DoughnutChartComponent;
var init_doughnut_chart_component = __esm({
  "src/main/webapp/app/exercises/shared/statistics/doughnut-chart.component.ts"() {
    init_course_detail_component();
    init_utils();
    init_exercise_model();
    init_course_model();
    init_statistics_model();
    init_artemis_translate_pipe();
    _c02 = () => [200, 200];
    PIE_CHART_NA_FALLBACK_VALUE = [0, 0, 1];
    DoughnutChartComponent = class _DoughnutChartComponent {
      router;
      course;
      contentType;
      exerciseId;
      exerciseType;
      currentPercentage;
      currentAbsolute;
      currentMax;
      receivedStats = false;
      doughnutChartTitle;
      stats;
      titleLink;
      faSpinner = faSpinner;
      constructor(router) {
        this.router = router;
      }
      ngxDoughnutData = [
        { name: "Done", value: 0 },
        { name: "Not done", value: 0 },
        { name: "N/A", value: 0 }
      ];
      ngxColor = {
        name: "vivid",
        selectable: true,
        group: ScaleType.Ordinal,
        domain: [GraphColors.GREEN, GraphColors.RED, GraphColors.LIGHT_GREY]
      };
      bindFormatting = this.valueFormatting.bind(this);
      ngOnChanges() {
        if (this.currentAbsolute == void 0 && !this.receivedStats) {
          this.updatePieChartData(PIE_CHART_NA_FALLBACK_VALUE);
        } else {
          this.receivedStats = true;
          const remaining = roundValueSpecifiedByCourseSettings(this.currentMax - this.currentAbsolute, this.course);
          this.stats = [this.currentAbsolute, remaining, 0];
          return this.currentMax === 0 ? this.updatePieChartData(PIE_CHART_NA_FALLBACK_VALUE) : this.updatePieChartData(this.stats);
        }
      }
      ngOnInit() {
        switch (this.contentType) {
          case DoughnutChartType.AVERAGE_EXERCISE_SCORE:
            this.doughnutChartTitle = "averageScore";
            this.titleLink = [`/course-management/${this.course.id}/${this.exerciseType}-exercises/${this.exerciseId}/scores`];
            break;
          case DoughnutChartType.PARTICIPATIONS:
            this.doughnutChartTitle = "participationRate";
            this.titleLink = [`/course-management/${this.course.id}/${this.exerciseType}-exercises/${this.exerciseId}/participations`];
            break;
          case DoughnutChartType.QUESTIONS:
            this.doughnutChartTitle = "resolved_posts";
            this.titleLink = [`/courses/${this.course.id}/exercises/${this.exerciseId}`];
            break;
          default:
            this.doughnutChartTitle = "";
            this.titleLink = void 0;
        }
      }
      openCorrespondingPage() {
        if (this.course.id && this.exerciseId && this.titleLink) {
          this.router.navigate(this.titleLink);
        }
      }
      updatePieChartData(values) {
        this.ngxDoughnutData.forEach((entry, index) => entry.value = values[index]);
        this.ngxDoughnutData = [...this.ngxDoughnutData];
      }
      valueFormatting(data) {
        return this.currentMax === 0 ? "0" : data.value;
      }
      static \u0275fac = function DoughnutChartComponent_Factory(t) {
        return new (t || _DoughnutChartComponent)(i03.\u0275\u0275directiveInject(i12.Router));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _DoughnutChartComponent, selectors: [["jhi-doughnut-chart"]], inputs: { course: "course", contentType: "contentType", exerciseId: "exerciseId", exerciseType: "exerciseType", currentPercentage: "currentPercentage", currentAbsolute: "currentAbsolute", currentMax: "currentMax" }, features: [i03.\u0275\u0275NgOnChangesFeature], decls: 17, vars: 12, consts: [[1, "mx-2", "d-flex", "flex-column", "justify-content-between", "h-100"], [1, "doughnut-chart-container", 3, "ngClass", "click"], [1, "doughnut-chart-text"], [3, "view", "results", "scheme", "doughnut", "tooltipText"], [3, "routerLink"], [1, "text-center"], [1, "text-center", 2, "z-index", "1"], [3, "icon", "spin"]], template: function DoughnutChartComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "div", 0);
          i03.\u0275\u0275text(1, "\n    ");
          i03.\u0275\u0275template(2, DoughnutChartComponent_Conditional_2_Template, 8, 4)(3, DoughnutChartComponent_Conditional_3_Template, 5, 3);
          i03.\u0275\u0275elementStart(4, "div", 1);
          i03.\u0275\u0275listener("click", function DoughnutChartComponent_Template_div_click_4_listener() {
            return ctx.openCorrespondingPage();
          });
          i03.\u0275\u0275text(5, "\n        ");
          i03.\u0275\u0275elementStart(6, "div", 2);
          i03.\u0275\u0275text(7, "\n            ");
          i03.\u0275\u0275template(8, DoughnutChartComponent_Conditional_8_Template, 4, 1)(9, DoughnutChartComponent_Conditional_9_Template, 4, 2)(10, DoughnutChartComponent_Conditional_10_Template, 7, 2);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(11, "\n        ");
          i03.\u0275\u0275elementStart(12, "ngx-charts-pie-chart", 3);
          i03.\u0275\u0275text(13, " ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(14, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(15, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(16, "\n");
        }
        if (rf & 2) {
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275conditional(2, ctx.titleLink ? 2 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(3, !ctx.titleLink ? 3 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275property("ngClass", ctx.titleLink ? "clickable" : "");
          i03.\u0275\u0275advance(4);
          i03.\u0275\u0275conditional(8, ctx.receivedStats ? 8 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(9, ctx.receivedStats ? 9 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(10, !ctx.receivedStats ? 10 : -1);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275property("view", i03.\u0275\u0275pureFunction0(11, _c02))("results", ctx.ngxDoughnutData)("scheme", ctx.ngxColor)("doughnut", true)("tooltipText", ctx.bindFormatting);
        }
      }, dependencies: [i2.NgClass, i3.FaIconComponent, i12.RouterLink, i42.PieChartComponent, ArtemisTranslatePipe], styles: ["\n\n.doughnut-chart-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n}\n.doughnut-chart-container[_ngcontent-%COMP%]   .doughnut-chart-text[_ngcontent-%COMP%] {\n  position: absolute;\n  min-height: 50px;\n}\n.clickable[_ngcontent-%COMP%] {\n  cursor: pointer;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3N0YXRpc3RpY3MvZG91Z2hudXQtY2hhcnQuY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5kb3VnaG51dC1jaGFydC1jb250YWluZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICB3aWR0aDogMTAwJTtcblxuICAgIC5kb3VnaG51dC1jaGFydC10ZXh0IHtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBtaW4taGVpZ2h0OiA1MHB4O1xuICAgIH1cbn1cblxuLmNsaWNrYWJsZSB7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLENBQUE7QUFDSSxXQUFBO0FBQ0EsZUFBQTtBQUNBLG1CQUFBO0FBQ0EsU0FBQTs7QUFFQSxDQU5KLHlCQU1JLENBQUE7QUFDSSxZQUFBO0FBQ0EsY0FBQTs7QUFJUixDQUFBO0FBQ0ksVUFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(DoughnutChartComponent, { className: "DoughnutChartComponent" });
    })();
  }
});

// src/main/webapp/app/shared/statistics-graph/statistics-graph.component.ts
import { Component as Component3, Input as Input2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import { faArrowLeft, faArrowRight } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { ScaleType as ScaleType2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i43 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
function StatisticsGraphComponent_ng_template_18_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275elementStart(1, "b");
    i04.\u0275\u0275text(2);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(3, " ");
    i04.\u0275\u0275element(4, "br");
    i04.\u0275\u0275text(5, "\n                    ");
    i04.\u0275\u0275elementStart(6, "span");
    i04.\u0275\u0275text(7);
    i04.\u0275\u0275pipe(8, "artemisTranslate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(9, "\n                ");
  }
  if (rf & 2) {
    const model_r3 = ctx.model;
    const ctx_r1 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate(model_r3.name);
    i04.\u0275\u0275advance(5);
    i04.\u0275\u0275textInterpolate2("", i04.\u0275\u0275pipeBind1(8, 3, ctx_r1.tooltipTranslation), ": ", model_r3.value, "");
  }
}
var _c03, StatisticsGraphComponent;
var init_statistics_graph_component = __esm({
  "src/main/webapp/app/shared/statistics-graph/statistics-graph.component.ts"() {
    init_statistics_service();
    init_statistics_model();
    init_statistics_graph_utils();
    init_statistics_service();
    init_artemis_translate_pipe();
    _c03 = (a0) => [a0, 250];
    StatisticsGraphComponent = class _StatisticsGraphComponent {
      service;
      translateService;
      graphType;
      currentSpan;
      statisticsView;
      entityId;
      LEFT = false;
      RIGHT = true;
      SpanType = SpanType;
      Graphs = Graphs;
      chartName;
      barChartLegend = false;
      chartTime;
      barChartLabels = [];
      dataForSpanType;
      ngxData = [];
      ngxColor = {
        name: "Statistics",
        selectable: true,
        group: ScaleType2.Ordinal,
        domain: [GraphColors.DARK_BLUE]
      };
      tooltipTranslation;
      yScaleMax;
      yAxisTickFormatting = yAxisTickFormatting;
      currentPeriod = 0;
      faArrowLeft = faArrowLeft;
      faArrowRight = faArrowRight;
      constructor(service, translateService) {
        this.service = service;
        this.translateService = translateService;
        this.translateService.onLangChange.subscribe(() => {
          this.onSystemLanguageChange();
        });
      }
      ngOnChanges(changes) {
        this.currentSpan = changes.currentSpan?.currentValue;
        this.barChartLabels = [];
        this.currentPeriod = 0;
        this.chartName = `statistics.${this.graphType.toString().toLowerCase()}`;
        this.tooltipTranslation = `statistics.${this.graphType.toString().toLowerCase()}Title`;
        this.initializeChart();
      }
      initializeChart() {
        this.createLabels();
        if (this.statisticsView === StatisticsView.ARTEMIS) {
          this.service.getChartData(this.currentSpan, this.currentPeriod, this.graphType).subscribe((res) => {
            this.dataForSpanType = res;
            this.pushToData();
          });
        } else {
          this.service.getChartDataForContent(this.currentSpan, this.currentPeriod, this.graphType, this.statisticsView, this.entityId).subscribe((res) => {
            this.dataForSpanType = res;
            this.pushToData();
          });
        }
      }
      createLabels() {
        const now = dayjs();
        let startDate;
        let endDate;
        switch (this.currentSpan) {
          case SpanType.DAY:
            for (let i = 0; i < 24; i++) {
              this.barChartLabels[i] = `${i}:00-${i + 1}:00`;
            }
            this.chartTime = now.add(this.currentPeriod, "days").format("DD.MM.YYYY");
            break;
          case SpanType.WEEK:
            this.barChartLabels = this.getWeekdays();
            startDate = dayjs().add(this.currentPeriod, "weeks").subtract(6, "days").format("DD.MM.YYYY");
            endDate = dayjs().add(this.currentPeriod, "weeks").format("DD.MM.YYYY");
            this.chartTime = startDate + " - " + endDate;
            break;
          case SpanType.MONTH:
            startDate = dayjs().subtract(1 - this.currentPeriod, "months");
            endDate = dayjs().subtract(-this.currentPeriod, "months");
            this.barChartLabels = this.getLabelsForMonth(endDate.diff(startDate, "days"));
            this.chartTime = now.add(this.currentPeriod, "months").subtract(Math.floor(this.barChartLabels.length / 2) - 1, "days").format("MMMM YYYY");
            break;
          case SpanType.QUARTER:
            startDate = dayjs().subtract(11 + 12 * -this.currentPeriod, "weeks");
            endDate = this.currentPeriod !== 0 ? dayjs().subtract(12 * -this.currentPeriod, "weeks") : dayjs();
            let currentWeek;
            for (let i = 0; i < 12; i++) {
              currentWeek = dayjs().subtract(11 + 12 * -this.currentPeriod - i, "weeks").isoWeekday(1).isoWeek();
              this.barChartLabels[i] = this.translateService.instant("calendar_week") + " " + currentWeek;
            }
            this.chartTime = startDate.isoWeekday(1).format("DD.MM.YYYY") + " - " + endDate.isoWeekday(7).format("DD.MM.YYYY");
            break;
          case SpanType.YEAR:
            this.barChartLabels = this.getMonths();
            this.chartTime = now.add(this.currentPeriod, "years").subtract(5, "months").format("YYYY");
            break;
        }
      }
      getMonths() {
        const currentMonth = dayjs().month();
        const year = [
          this.translateService.instant("months.january"),
          this.translateService.instant("months.february"),
          this.translateService.instant("months.march"),
          this.translateService.instant("months.april"),
          this.translateService.instant("months.may"),
          this.translateService.instant("months.june"),
          this.translateService.instant("months.july"),
          this.translateService.instant("months.august"),
          this.translateService.instant("months.september"),
          this.translateService.instant("months.october"),
          this.translateService.instant("months.november"),
          this.translateService.instant("months.december")
        ];
        const back = year.slice(currentMonth + 1, year.length);
        const front = year.slice(0, currentMonth + 1);
        return back.concat(front);
      }
      getLabelsForMonth(daysInMonth) {
        const days = [];
        for (let i = 0; i < daysInMonth; i++) {
          days.push(dayjs().subtract(-this.currentPeriod, "months").subtract(daysInMonth - 1 - i, "days").format("DD.MM"));
        }
        return days;
      }
      getWeekdays() {
        const currentDay = dayjs().day();
        const days = [
          this.translateService.instant("weekdays.monday"),
          this.translateService.instant("weekdays.tuesday"),
          this.translateService.instant("weekdays.wednesday"),
          this.translateService.instant("weekdays.thursday"),
          this.translateService.instant("weekdays.friday"),
          this.translateService.instant("weekdays.saturday"),
          this.translateService.instant("weekdays.sunday")
        ];
        const back = days.slice(currentDay, days.length);
        const front = days.slice(0, currentDay);
        return back.concat(front);
      }
      switchTimeSpan(index) {
        index ? this.currentPeriod += 1 : this.currentPeriod -= 1;
        this.initializeChart();
      }
      pushToData() {
        this.ngxData = this.dataForSpanType.map((score, index) => ({ name: this.barChartLabels[index], value: score }));
        this.yScaleMax = Math.max(3, ...this.dataForSpanType);
      }
      onSystemLanguageChange() {
        this.createLabels();
        this.ngxData.forEach((dataPack, index) => {
          dataPack.name = this.barChartLabels[index];
        });
        this.ngxData = [...this.ngxData];
      }
      static \u0275fac = function StatisticsGraphComponent_Factory(t) {
        return new (t || _StatisticsGraphComponent)(i04.\u0275\u0275directiveInject(StatisticsService), i04.\u0275\u0275directiveInject(i22.TranslateService));
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _StatisticsGraphComponent, selectors: [["jhi-statistics-graph"]], inputs: { graphType: "graphType", currentSpan: "currentSpan", statisticsView: "statisticsView", entityId: "entityId" }, features: [i04.\u0275\u0275NgOnChangesFeature], decls: 30, vars: 18, consts: [[1, "row", "d-flex", "justify-content-center"], [1, "row"], ["size", "2x", "role", "button", 1, "col-1", "d-flex", "justify-content-end", "align-items-center", "px-0", 3, "icon", "click"], [1, "chart", "col-10", "px-0"], ["containerRef", ""], [3, "view", "results", "scheme", "xAxis", "yAxis", "showDataLabel", "yScaleMax", "yAxisTickFormatting", "animations", "roundEdges"], ["tooltipTemplate", ""], ["size", "2x", "role", "button", 1, "col-1", "d-flex", "justify-content-start", "align-items-center", "px-0", 3, "icon", "click"], [1, "col-xl-9", "offset-xl-2", "text-center", "mt-3", "mb-5"]], template: function StatisticsGraphComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275elementStart(0, "div", 0);
          i04.\u0275\u0275text(1, "\n    ");
          i04.\u0275\u0275elementStart(2, "div");
          i04.\u0275\u0275text(3, "\n        ");
          i04.\u0275\u0275elementStart(4, "h3");
          i04.\u0275\u0275text(5);
          i04.\u0275\u0275pipe(6, "artemisTranslate");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(7, "\n    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(8, "\n    ");
          i04.\u0275\u0275elementStart(9, "div", 1);
          i04.\u0275\u0275text(10, "\n        ");
          i04.\u0275\u0275elementStart(11, "fa-icon", 2);
          i04.\u0275\u0275listener("click", function StatisticsGraphComponent_Template_fa_icon_click_11_listener() {
            return ctx.switchTimeSpan(ctx.LEFT);
          });
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(12, "\n        ");
          i04.\u0275\u0275elementStart(13, "div", 3, 4);
          i04.\u0275\u0275text(15, "\n            ");
          i04.\u0275\u0275elementStart(16, "ngx-charts-bar-vertical", 5);
          i04.\u0275\u0275text(17, "\n                ");
          i04.\u0275\u0275template(18, StatisticsGraphComponent_ng_template_18_Template, 10, 5, "ng-template", null, 6, i04.\u0275\u0275templateRefExtractor);
          i04.\u0275\u0275text(20, "\n            ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(21, "\n        ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(22, "\n        ");
          i04.\u0275\u0275elementStart(23, "fa-icon", 7);
          i04.\u0275\u0275listener("click", function StatisticsGraphComponent_Template_fa_icon_click_23_listener() {
            return ctx.switchTimeSpan(ctx.RIGHT);
          });
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(24, "\n    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(25, "\n");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(26, "\n");
          i04.\u0275\u0275elementStart(27, "h4", 8);
          i04.\u0275\u0275text(28);
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(29, "\n");
        }
        if (rf & 2) {
          const _r0 = i04.\u0275\u0275reference(14);
          i04.\u0275\u0275advance(5);
          i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(6, 14, ctx.chartName));
          i04.\u0275\u0275advance(6);
          i04.\u0275\u0275property("icon", ctx.faArrowLeft);
          i04.\u0275\u0275advance(5);
          i04.\u0275\u0275property("view", i04.\u0275\u0275pureFunction1(16, _c03, _r0.offsetWidth))("results", ctx.ngxData)("scheme", ctx.ngxColor)("xAxis", true)("yAxis", true)("showDataLabel", true)("yScaleMax", ctx.yScaleMax)("yAxisTickFormatting", ctx.yAxisTickFormatting)("animations", false)("roundEdges", false);
          i04.\u0275\u0275advance(7);
          i04.\u0275\u0275property("icon", ctx.faArrowRight);
          i04.\u0275\u0275advance(5);
          i04.\u0275\u0275textInterpolate(ctx.chartTime);
        }
      }, dependencies: [i32.FaIconComponent, i43.BarVerticalComponent, ArtemisTranslatePipe], styles: ["\n\n[_nghost-%COMP%]  .textDataLabel {\n  font-weight: bolder;\n  font-size: small !important;\n  alignment-baseline: middle;\n  text-anchor: start;\n}\n@media (min-width: 1420px) {\n  [_nghost-%COMP%]  .textDataLabel {\n    transform: rotate(0deg);\n    font-size: medium !important;\n    alignment-baseline: baseline;\n    text-anchor: middle;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvY2hhcnQvdmVydGljYWwtYmFyLWNoYXJ0LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIjpob3N0OjpuZy1kZWVwIC50ZXh0RGF0YUxhYmVsIHtcbiAgICBmb250LXdlaWdodDogYm9sZGVyO1xuICAgIGZvbnQtc2l6ZTogc21hbGwgIWltcG9ydGFudDtcbiAgICBhbGlnbm1lbnQtYmFzZWxpbmU6IG1pZGRsZTtcbiAgICB0ZXh0LWFuY2hvcjogc3RhcnQ7XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiAxNDIwcHgpIHtcbiAgICA6aG9zdDo6bmctZGVlcCAudGV4dERhdGFMYWJlbCB7XG4gICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xuICAgICAgICBmb250LXNpemU6IG1lZGl1bSAhaW1wb3J0YW50O1xuICAgICAgICBhbGlnbm1lbnQtYmFzZWxpbmU6IGJhc2VsaW5lO1xuICAgICAgICB0ZXh0LWFuY2hvcjogbWlkZGxlO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxLQUFBLFVBQUEsQ0FBQTtBQUNJLGVBQUE7QUFDQSxhQUFBO0FBQ0Esc0JBQUE7QUFDQSxlQUFBOztBQUdKLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFDSSxPQUFBLFVBQUEsQ0FSSjtBQVNRLGVBQUEsT0FBQTtBQUNBLGVBQUE7QUFDQSx3QkFBQTtBQUNBLGlCQUFBOzs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(StatisticsGraphComponent, { className: "StatisticsGraphComponent" });
    })();
  }
});

// src/main/webapp/app/shared/statistics-graph/statistics-score-distribution-graph.component.ts
import { Component as Component4, Input as Input3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ScaleType as ScaleType3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i23 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
function StatisticsScoreDistributionGraphComponent_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                ");
    i05.\u0275\u0275elementStart(1, "b");
    i05.\u0275\u0275text(2);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(3, " ");
    i05.\u0275\u0275element(4, "br");
    i05.\u0275\u0275text(5, "\n                ");
    i05.\u0275\u0275elementStart(6, "span");
    i05.\u0275\u0275text(7);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(8, "\n            ");
  }
  if (rf & 2) {
    const model_r3 = ctx.model;
    const ctx_r1 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate(model_r3.name);
    i05.\u0275\u0275advance(5);
    i05.\u0275\u0275textInterpolate(ctx_r1.lookUpAbsoluteValue(model_r3.name));
  }
}
var _c04, StatisticsScoreDistributionGraphComponent;
var init_statistics_score_distribution_graph_component = __esm({
  "src/main/webapp/app/shared/statistics-graph/statistics-score-distribution-graph.component.ts"() {
    init_utils();
    init_statistics_model();
    init_statistics_graph_utils();
    init_exercise_model();
    init_navigation_utils();
    init_navigation_utils();
    init_artemis_translate_pipe();
    _c04 = (a0) => [a0, 250];
    StatisticsScoreDistributionGraphComponent = class _StatisticsScoreDistributionGraphComponent {
      navigationService;
      averageScoreOfExercise;
      scoreDistribution;
      numberOfExerciseScores;
      exerciseType;
      courseId;
      exerciseId;
      ngxData = [];
      ngxColor = {
        name: "Statistics",
        selectable: true,
        group: ScaleType3.Ordinal,
        domain: [GraphColors.DARK_BLUE]
      };
      yAxisTickFormatting = axisTickFormattingWithPercentageSign;
      barChartLabels = [];
      relativeChartData = [];
      constructor(navigationService) {
        this.navigationService = navigationService;
      }
      ngOnInit() {
        this.initializeChart();
      }
      initializeChart() {
        this.barChartLabels = ["[0, 10)", "[10, 20)", "[20, 30)", "[30, 40)", "[40, 50)", "[50, 60)", "[60, 70)", "[70, 80)", "[80, 90)", "[90, 100]"];
        if (this.numberOfExerciseScores && this.numberOfExerciseScores > 0) {
          this.relativeChartData = [];
          for (const value of this.scoreDistribution) {
            this.relativeChartData.push(round(value * 100 / this.numberOfExerciseScores));
          }
        } else {
          this.relativeChartData = new Array(10).fill(0);
        }
        this.ngxData = this.relativeChartData.map((data, index) => ({ name: this.barChartLabels[index], value: data }));
      }
      lookUpAbsoluteValue(bucket) {
        const index = this.barChartLabels.indexOf(bucket);
        return this.scoreDistribution[index];
      }
      selectChartBar(event) {
        const index = this.barChartLabels.indexOf(event.name);
        const route = [`/course-management/${this.courseId}/${this.exerciseType}-exercises/${this.exerciseId}/scores`];
        this.navigationService.routeInNewTab(route, { queryParams: { scoreRangeFilter: index } });
      }
      static \u0275fac = function StatisticsScoreDistributionGraphComponent_Factory(t) {
        return new (t || _StatisticsScoreDistributionGraphComponent)(i05.\u0275\u0275directiveInject(ArtemisNavigationUtilService));
      };
      static \u0275cmp = i05.\u0275\u0275defineComponent({ type: _StatisticsScoreDistributionGraphComponent, selectors: [["jhi-statistics-score-distribution-graph"]], inputs: { averageScoreOfExercise: "averageScoreOfExercise", scoreDistribution: "scoreDistribution", numberOfExerciseScores: "numberOfExerciseScores", exerciseType: "exerciseType", courseId: "courseId", exerciseId: "exerciseId" }, decls: 20, vars: 14, consts: [[1, "row", "mb-3"], [1, "col-xl-2"], [1, "col-xl-9"], ["containerRef", ""], [3, "roundEdges", "view", "results", "scheme", "xAxis", "yAxis", "yScaleMax", "showDataLabel", "yAxisTickFormatting", "select"], ["tooltipTemplate", ""]], template: function StatisticsScoreDistributionGraphComponent_Template(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275elementStart(0, "div", 0);
          i05.\u0275\u0275text(1, "\n    ");
          i05.\u0275\u0275elementStart(2, "div", 1);
          i05.\u0275\u0275text(3, "\n        ");
          i05.\u0275\u0275elementStart(4, "h3");
          i05.\u0275\u0275text(5);
          i05.\u0275\u0275pipe(6, "artemisTranslate");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(7, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(8, "\n    ");
          i05.\u0275\u0275elementStart(9, "div", 2, 3);
          i05.\u0275\u0275text(11, "\n        ");
          i05.\u0275\u0275elementStart(12, "ngx-charts-bar-vertical", 4);
          i05.\u0275\u0275listener("select", function StatisticsScoreDistributionGraphComponent_Template_ngx_charts_bar_vertical_select_12_listener($event) {
            return ctx.selectChartBar($event);
          });
          i05.\u0275\u0275text(13, "\n            ");
          i05.\u0275\u0275template(14, StatisticsScoreDistributionGraphComponent_ng_template_14_Template, 9, 2, "ng-template", null, 5, i05.\u0275\u0275templateRefExtractor);
          i05.\u0275\u0275text(16, "\n        ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(17, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(18, "\n");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(19, "\n");
        }
        if (rf & 2) {
          const _r0 = i05.\u0275\u0275reference(10);
          i05.\u0275\u0275advance(5);
          i05.\u0275\u0275textInterpolate(i05.\u0275\u0275pipeBind1(6, 10, "statistics.score_distribution"));
          i05.\u0275\u0275advance(7);
          i05.\u0275\u0275property("roundEdges", false)("view", i05.\u0275\u0275pureFunction1(12, _c04, _r0.offsetWidth))("results", ctx.ngxData)("scheme", ctx.ngxColor)("xAxis", true)("yAxis", true)("yScaleMax", 100)("showDataLabel", true)("yAxisTickFormatting", ctx.yAxisTickFormatting);
        }
      }, dependencies: [i23.BarVerticalComponent, ArtemisTranslatePipe], styles: ["\n\n[_nghost-%COMP%]  .textDataLabel {\n  font-weight: bolder;\n  font-size: small !important;\n  alignment-baseline: middle;\n  text-anchor: start;\n}\n@media (min-width: 1420px) {\n  [_nghost-%COMP%]  .textDataLabel {\n    transform: rotate(0deg);\n    font-size: medium !important;\n    alignment-baseline: baseline;\n    text-anchor: middle;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvY2hhcnQvdmVydGljYWwtYmFyLWNoYXJ0LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIjpob3N0OjpuZy1kZWVwIC50ZXh0RGF0YUxhYmVsIHtcbiAgICBmb250LXdlaWdodDogYm9sZGVyO1xuICAgIGZvbnQtc2l6ZTogc21hbGwgIWltcG9ydGFudDtcbiAgICBhbGlnbm1lbnQtYmFzZWxpbmU6IG1pZGRsZTtcbiAgICB0ZXh0LWFuY2hvcjogc3RhcnQ7XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiAxNDIwcHgpIHtcbiAgICA6aG9zdDo6bmctZGVlcCAudGV4dERhdGFMYWJlbCB7XG4gICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xuICAgICAgICBmb250LXNpemU6IG1lZGl1bSAhaW1wb3J0YW50O1xuICAgICAgICBhbGlnbm1lbnQtYmFzZWxpbmU6IGJhc2VsaW5lO1xuICAgICAgICB0ZXh0LWFuY2hvcjogbWlkZGxlO1xuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxLQUFBLFVBQUEsQ0FBQTtBQUNJLGVBQUE7QUFDQSxhQUFBO0FBQ0Esc0JBQUE7QUFDQSxlQUFBOztBQUdKLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFDSSxPQUFBLFVBQUEsQ0FSSjtBQVNRLGVBQUEsT0FBQTtBQUNBLGVBQUE7QUFDQSx3QkFBQTtBQUNBLGlCQUFBOzs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(StatisticsScoreDistributionGraphComponent, { className: "StatisticsScoreDistributionGraphComponent" });
    })();
  }
});

export {
  StatisticsService,
  init_statistics_service,
  DoughnutChartType,
  CourseDetailComponent,
  init_course_detail_component,
  DoughnutChartComponent,
  init_doughnut_chart_component,
  StatisticsGraphComponent,
  init_statistics_graph_component,
  StatisticsScoreDistributionGraphComponent,
  init_statistics_score_distribution_graph_component
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL21hbmFnZS9kZXRhaWwvY291cnNlLWRldGFpbC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9tYW5hZ2UvZGV0YWlsL2NvdXJzZS1kZXRhaWwuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9zdGF0aXN0aWNzLWdyYXBoL3N0YXRpc3RpY3Muc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9zdGF0aXN0aWNzL2RvdWdobnV0LWNoYXJ0LmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9zdGF0aXN0aWNzL2RvdWdobnV0LWNoYXJ0LmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvc3RhdGlzdGljcy1ncmFwaC9zdGF0aXN0aWNzLWdyYXBoLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3N0YXRpc3RpY3MtZ3JhcGgvc3RhdGlzdGljcy1ncmFwaC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3N0YXRpc3RpY3MtZ3JhcGgvc3RhdGlzdGljcy1zY29yZS1kaXN0cmlidXRpb24tZ3JhcGguY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvc3RhdGlzdGljcy1ncmFwaC9zdGF0aXN0aWNzLXNjb3JlLWRpc3RyaWJ1dGlvbi1ncmFwaC5jb21wb25lbnQuaHRtbCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uRGVzdHJveSwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgUFJPRklMRV9MVEkgfSBmcm9tICdhcHAvYXBwLmNvbnN0YW50cyc7XG5pbXBvcnQgeyBQcm9maWxlU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvbGF5b3V0cy9wcm9maWxlcy9wcm9maWxlLnNlcnZpY2UnO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBDb3Vyc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvY291cnNlLm1vZGVsJztcbmltcG9ydCB7IENvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlIH0gZnJvbSAnLi4vY291cnNlLW1hbmFnZW1lbnQuc2VydmljZSc7XG5pbXBvcnQgeyBDb3Vyc2VNYW5hZ2VtZW50RGV0YWlsVmlld0R0byB9IGZyb20gJ2FwcC9jb3Vyc2UvbWFuYWdlL2NvdXJzZS1tYW5hZ2VtZW50LWRldGFpbC12aWV3LWR0by5tb2RlbCc7XG5pbXBvcnQgeyBvbkVycm9yIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2dsb2JhbC51dGlscyc7XG5pbXBvcnQgeyBBbGVydFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuaW1wb3J0IHsgRXZlbnRNYW5hZ2VyIH0gZnJvbSAnYXBwL2NvcmUvdXRpbC9ldmVudC1tYW5hZ2VyLnNlcnZpY2UnO1xuaW1wb3J0IHsgZmFDaGFydEJhciwgZmFDbGlwYm9hcmQsIGZhRXllLCBmYUZsYWcsIGZhTGlzdEFsdCwgZmFUYWJsZSwgZmFUaW1lcywgZmFXcmVuY2ggfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgRmVhdHVyZVRvZ2dsZSB9IGZyb20gJ2FwcC9zaGFyZWQvZmVhdHVyZS10b2dnbGUvZmVhdHVyZS10b2dnbGUuc2VydmljZSc7XG5pbXBvcnQgeyBPcmdhbml6YXRpb25NYW5hZ2VtZW50U2VydmljZSB9IGZyb20gJ2FwcC9hZG1pbi9vcmdhbml6YXRpb24tbWFuYWdlbWVudC9vcmdhbml6YXRpb24tbWFuYWdlbWVudC5zZXJ2aWNlJztcbmltcG9ydCB7IElyaXNTdWJTZXR0aW5nc1R5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvaXJpcy9zZXR0aW5ncy9pcmlzLXN1Yi1zZXR0aW5ncy5tb2RlbCc7XG5pbXBvcnQgeyBJcmlzU2V0dGluZ3NTZXJ2aWNlIH0gZnJvbSAnYXBwL2lyaXMvc2V0dGluZ3Mvc2hhcmVkL2lyaXMtc2V0dGluZ3Muc2VydmljZSc7XG5pbXBvcnQgeyBBY2NvdW50U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL2F1dGgvYWNjb3VudC5zZXJ2aWNlJztcblxuZXhwb3J0IGVudW0gRG91Z2hudXRDaGFydFR5cGUge1xuICAgIEFTU0VTU01FTlQgPSAnQVNTRVNTTUVOVCcsXG4gICAgQ09NUExBSU5UUyA9ICdDT01QTEFJTlRTJyxcbiAgICBGRUVEQkFDSyA9ICdGRUVEQkFDSycsXG4gICAgQVZFUkFHRV9DT1VSU0VfU0NPUkUgPSAnQVZFUkFHRV9DT1VSU0VfU0NPUkUnLFxuICAgIEFWRVJBR0VfRVhFUkNJU0VfU0NPUkUgPSAnQVZFUkFHRV9FWEVSQ0lTRV9TQ09SRScsXG4gICAgUEFSVElDSVBBVElPTlMgPSAnUEFSVElDSVBBVElPTlMnLFxuICAgIFFVRVNUSU9OUyA9ICdRVUVTVElPTlMnLFxufVxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1jb3Vyc2UtZGV0YWlsJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vY291cnNlLWRldGFpbC5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vY291cnNlLWRldGFpbC5jb21wb25lbnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBDb3Vyc2VEZXRhaWxDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gICAgcmVhZG9ubHkgRG91Z2hudXRDaGFydFR5cGUgPSBEb3VnaG51dENoYXJ0VHlwZTtcbiAgICByZWFkb25seSBGZWF0dXJlVG9nZ2xlID0gRmVhdHVyZVRvZ2dsZTtcbiAgICByZWFkb25seSBDSEFUID0gSXJpc1N1YlNldHRpbmdzVHlwZS5DSEFUO1xuICAgIHJlYWRvbmx5IEhFU1RJQSA9IElyaXNTdWJTZXR0aW5nc1R5cGUuSEVTVElBO1xuICAgIHJlYWRvbmx5IENPREVfRURJVE9SID0gSXJpc1N1YlNldHRpbmdzVHlwZS5DT0RFX0VESVRPUjtcblxuICAgIGNvdXJzZURUTzogQ291cnNlTWFuYWdlbWVudERldGFpbFZpZXdEdG87XG4gICAgYWN0aXZlU3R1ZGVudHM/OiBudW1iZXJbXTtcbiAgICBjb3Vyc2U6IENvdXJzZTtcblxuICAgIG1lc3NhZ2luZ0VuYWJsZWQ6IGJvb2xlYW47XG4gICAgY29tbXVuaWNhdGlvbkVuYWJsZWQ6IGJvb2xlYW47XG4gICAgaXJpc0VuYWJsZWQgPSBmYWxzZTtcbiAgICBpcmlzQ2hhdEVuYWJsZWQgPSBmYWxzZTtcbiAgICBpcmlzSGVzdGlhRW5hYmxlZCA9IGZhbHNlO1xuICAgIGlyaXNDb2RlRWRpdG9yRW5hYmxlZCA9IGZhbHNlO1xuICAgIGx0aUVuYWJsZWQgPSBmYWxzZTtcblxuICAgIGlzQWRtaW4gPSBmYWxzZTtcblxuICAgIHByaXZhdGUgZXZlbnRTdWJzY3JpYmVyOiBTdWJzY3JpcHRpb247XG4gICAgcGFyYW1TdWI6IFN1YnNjcmlwdGlvbjtcblxuICAgIC8vIEljb25zXG4gICAgZmFUaW1lcyA9IGZhVGltZXM7XG4gICAgZmFFeWUgPSBmYUV5ZTtcbiAgICBmYVdyZW5jaCA9IGZhV3JlbmNoO1xuICAgIGZhVGFibGUgPSBmYVRhYmxlO1xuICAgIGZhRmxhZyA9IGZhRmxhZztcbiAgICBmYUxpc3RBbHQgPSBmYUxpc3RBbHQ7XG4gICAgZmFDaGFydEJhciA9IGZhQ2hhcnRCYXI7XG4gICAgZmFDbGlwYm9hcmQgPSBmYUNsaXBib2FyZDtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGV2ZW50TWFuYWdlcjogRXZlbnRNYW5hZ2VyLFxuICAgICAgICBwcml2YXRlIGNvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlOiBDb3Vyc2VNYW5hZ2VtZW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBvcmdhbml6YXRpb25TZXJ2aWNlOiBPcmdhbml6YXRpb25NYW5hZ2VtZW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSByb3V0ZTogQWN0aXZhdGVkUm91dGUsXG4gICAgICAgIHByaXZhdGUgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgcHJvZmlsZVNlcnZpY2U6IFByb2ZpbGVTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFjY291bnRTZXJ2aWNlOiBBY2NvdW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBpcmlzU2V0dGluZ3NTZXJ2aWNlOiBJcmlzU2V0dGluZ3NTZXJ2aWNlLFxuICAgICkge31cblxuICAgIC8qKlxuICAgICAqIE9uIGluaXQgbG9hZCB0aGUgY291cnNlIGluZm9ybWF0aW9uIGFuZCBzdWJzY3JpYmUgdG8gbGlzdGVuIGZvciBjaGFuZ2VzIGluIGNvdXJzZXMuXG4gICAgICovXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMucHJvZmlsZVNlcnZpY2UuZ2V0UHJvZmlsZUluZm8oKS5zdWJzY3JpYmUoKHByb2ZpbGVJbmZvKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmx0aUVuYWJsZWQgPSBwcm9maWxlSW5mby5hY3RpdmVQcm9maWxlcy5pbmNsdWRlcyhQUk9GSUxFX0xUSSk7XG4gICAgICAgICAgICB0aGlzLmlyaXNFbmFibGVkID0gcHJvZmlsZUluZm8uYWN0aXZlUHJvZmlsZXMuaW5jbHVkZXMoJ2lyaXMnKTtcbiAgICAgICAgICAgIGlmICh0aGlzLmlyaXNFbmFibGVkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5pcmlzU2V0dGluZ3NTZXJ2aWNlLmdldEdsb2JhbFNldHRpbmdzKCkuc3Vic2NyaWJlKChzZXR0aW5ncykgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlyaXNDaGF0RW5hYmxlZCA9IHNldHRpbmdzPy5pcmlzQ2hhdFNldHRpbmdzPy5lbmFibGVkID8/IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlyaXNIZXN0aWFFbmFibGVkID0gc2V0dGluZ3M/LmlyaXNIZXN0aWFTZXR0aW5ncz8uZW5hYmxlZCA/PyBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pcmlzQ29kZUVkaXRvckVuYWJsZWQgPSBzZXR0aW5ncz8uaXJpc0NvZGVFZGl0b3JTZXR0aW5ncz8uZW5hYmxlZCA/PyBmYWxzZTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMucm91dGUuZGF0YS5zdWJzY3JpYmUoKHsgY291cnNlIH0pID0+IHtcbiAgICAgICAgICAgIGlmIChjb3Vyc2UpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZSA9IGNvdXJzZTtcbiAgICAgICAgICAgICAgICB0aGlzLm1lc3NhZ2luZ0VuYWJsZWQgPSAhIXRoaXMuY291cnNlLmNvdXJzZUluZm9ybWF0aW9uU2hhcmluZ0NvbmZpZ3VyYXRpb24/LmluY2x1ZGVzKCdNRVNTQUdJTkcnKTtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbW11bmljYXRpb25FbmFibGVkID0gISF0aGlzLmNvdXJzZS5jb3Vyc2VJbmZvcm1hdGlvblNoYXJpbmdDb25maWd1cmF0aW9uPy5pbmNsdWRlcygnQ09NTVVOSUNBVElPTicpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5pc0FkbWluID0gdGhpcy5hY2NvdW50U2VydmljZS5pc0FkbWluKCk7XG4gICAgICAgIH0pO1xuICAgICAgICAvLyBUaGVyZSBpcyBubyBjb3Vyc2UgMCAtPiB3aWxsIGZldGNoIG5vIGNvdXJzZSBpZiByb3V0ZSBkb2VzIG5vdCBwcm92aWRlIGRpZmZlcmVudCBjb3Vyc2VJZFxuICAgICAgICBsZXQgY291cnNlSWQgPSAwO1xuICAgICAgICB0aGlzLnBhcmFtU3ViID0gdGhpcy5yb3V0ZS5wYXJhbXMuc3Vic2NyaWJlKChwYXJhbXMpID0+IHtcbiAgICAgICAgICAgIGNvdXJzZUlkID0gcGFyYW1zWydjb3Vyc2VJZCddO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5mZXRjaENvdXJzZVN0YXRpc3RpY3MoY291cnNlSWQpO1xuICAgICAgICB0aGlzLnJlZ2lzdGVyQ2hhbmdlSW5Db3Vyc2VzKGNvdXJzZUlkKTtcbiAgICAgICAgdGhpcy5mZXRjaE9yZ2FuaXphdGlvbnMoY291cnNlSWQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFN1YnNjcmliZSB0byBjaGFuZ2VzIGluIGNvdXJzZXMgYW5kIHJlbG9hZCB0aGUgY291cnNlIGFmdGVyIGEgY2hhbmdlLlxuICAgICAqL1xuICAgIHJlZ2lzdGVyQ2hhbmdlSW5Db3Vyc2VzKGNvdXJzZUlkOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5ldmVudFN1YnNjcmliZXIgPSB0aGlzLmV2ZW50TWFuYWdlci5zdWJzY3JpYmUoJ2NvdXJzZUxpc3RNb2RpZmljYXRpb24nLCAoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmNvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlLmZpbmQoY291cnNlSWQpLnN1YnNjcmliZSgoY291cnNlUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZSA9IGNvdXJzZVJlc3BvbnNlLmJvZHkhO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmZldGNoQ291cnNlU3RhdGlzdGljcyhjb3Vyc2VJZCk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE9uIGRlc3Ryb3kgdW5zdWJzY3JpYmUgYWxsIHN1YnNjcmlwdGlvbnMuXG4gICAgICovXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIGlmICh0aGlzLnBhcmFtU3ViKSB7XG4gICAgICAgICAgICB0aGlzLnBhcmFtU3ViLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5ldmVudE1hbmFnZXIuZGVzdHJveSh0aGlzLmV2ZW50U3Vic2NyaWJlcik7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZmV0Y2ggdGhlIGNvdXJzZSBzcGVjaWZpYyBzdGF0aXN0aWNzIHNlcGFyYXRlbHkgYmVjYXVzZSBpdCB0YWtlcyBxdWl0ZSBsb25nIGZvciBsYXJnZXIgY291cnNlc1xuICAgICAqL1xuICAgIHByaXZhdGUgZmV0Y2hDb3Vyc2VTdGF0aXN0aWNzKGNvdXJzZUlkOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5jb3Vyc2VNYW5hZ2VtZW50U2VydmljZS5nZXRDb3Vyc2VTdGF0aXN0aWNzRm9yRGV0YWlsVmlldyhjb3Vyc2VJZCkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5leHQ6IChjb3Vyc2VSZXNwb25zZTogSHR0cFJlc3BvbnNlPENvdXJzZU1hbmFnZW1lbnREZXRhaWxWaWV3RHRvPikgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY291cnNlRFRPID0gY291cnNlUmVzcG9uc2UuYm9keSE7XG4gICAgICAgICAgICAgICAgdGhpcy5hY3RpdmVTdHVkZW50cyA9IGNvdXJzZVJlc3BvbnNlLmJvZHkhLmFjdGl2ZVN0dWRlbnRzO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yOiAoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiBvbkVycm9yKHRoaXMuYWxlcnRTZXJ2aWNlLCBlcnJvciksXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHByaXZhdGUgZmV0Y2hPcmdhbml6YXRpb25zKGNvdXJzZUlkOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5vcmdhbml6YXRpb25TZXJ2aWNlLmdldE9yZ2FuaXphdGlvbnNCeUNvdXJzZShjb3Vyc2VJZCkuc3Vic2NyaWJlKChvcmdhbml6YXRpb25zKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmNvdXJzZS5vcmdhbml6YXRpb25zID0gb3JnYW5pemF0aW9ucztcbiAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInJvdyBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyXCI+XG4gICAgQGlmIChjb3Vyc2UpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cImNvbC0xMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wteHhsLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1jb3Vyc2UtZGV0YWlsLWRvdWdobnV0LWNoYXJ0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJkb3VnaG51dC1jb250YWluZXIgY29sLXNtLTYgbXktM1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NvdXJzZV09XCJjb3Vyc2VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjb250ZW50VHlwZV09XCJEb3VnaG51dENoYXJ0VHlwZS5BU1NFU1NNRU5UXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY3VycmVudFBlcmNlbnRhZ2VdPVwiY291cnNlRFRPPy5jdXJyZW50UGVyY2VudGFnZUFzc2Vzc21lbnRzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY3VycmVudEFic29sdXRlXT1cImNvdXJzZURUTz8uY3VycmVudEFic29sdXRlQXNzZXNzbWVudHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjdXJyZW50TWF4XT1cImNvdXJzZURUTz8uY3VycmVudE1heEFzc2Vzc21lbnRzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID48L2poaS1jb3Vyc2UtZGV0YWlsLWRvdWdobnV0LWNoYXJ0PlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjb3Vyc2UuY29tcGxhaW50c0VuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLWNvdXJzZS1kZXRhaWwtZG91Z2hudXQtY2hhcnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJkb3VnaG51dC1jb250YWluZXIgY29sLXNtLTYgbXktM1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjb3Vyc2VdPVwiY291cnNlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NvbnRlbnRUeXBlXT1cIkRvdWdobnV0Q2hhcnRUeXBlLkNPTVBMQUlOVFNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY3VycmVudFBlcmNlbnRhZ2VdPVwiY291cnNlRFRPPy5jdXJyZW50UGVyY2VudGFnZUNvbXBsYWludHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY3VycmVudEFic29sdXRlXT1cImNvdXJzZURUTz8uY3VycmVudEFic29sdXRlQ29tcGxhaW50c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjdXJyZW50TWF4XT1cImNvdXJzZURUTz8uY3VycmVudE1heENvbXBsYWludHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2poaS1jb3Vyc2UtZGV0YWlsLWRvdWdobnV0LWNoYXJ0PlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjb3Vyc2UucmVxdWVzdE1vcmVGZWVkYmFja0VuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLWNvdXJzZS1kZXRhaWwtZG91Z2hudXQtY2hhcnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJkb3VnaG51dC1jb250YWluZXIgY29sLXNtLTYgbXktM1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjb3Vyc2VdPVwiY291cnNlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NvbnRlbnRUeXBlXT1cIkRvdWdobnV0Q2hhcnRUeXBlLkZFRURCQUNLXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2N1cnJlbnRQZXJjZW50YWdlXT1cImNvdXJzZURUTz8uY3VycmVudFBlcmNlbnRhZ2VNb3JlRmVlZGJhY2tzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2N1cnJlbnRBYnNvbHV0ZV09XCJjb3Vyc2VEVE8/LmN1cnJlbnRBYnNvbHV0ZU1vcmVGZWVkYmFja3NcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY3VycmVudE1heF09XCJjb3Vyc2VEVE8/LmN1cnJlbnRNYXhNb3JlRmVlZGJhY2tzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9qaGktY291cnNlLWRldGFpbC1kb3VnaG51dC1jaGFydD5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktY291cnNlLWRldGFpbC1kb3VnaG51dC1jaGFydFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZG91Z2hudXQtY29udGFpbmVyIGNvbC1zbS02IG15LTNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjb3Vyc2VdPVwiY291cnNlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY29udGVudFR5cGVdPVwiRG91Z2hudXRDaGFydFR5cGUuQVZFUkFHRV9DT1VSU0VfU0NPUkVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjdXJyZW50UGVyY2VudGFnZV09XCJjb3Vyc2VEVE8/LmN1cnJlbnRQZXJjZW50YWdlQXZlcmFnZVNjb3JlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY3VycmVudEFic29sdXRlXT1cImNvdXJzZURUTz8uY3VycmVudEFic29sdXRlQXZlcmFnZVNjb3JlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY3VycmVudE1heF09XCJjb3Vyc2VEVE8/LmN1cnJlbnRNYXhBdmVyYWdlU2NvcmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvamhpLWNvdXJzZS1kZXRhaWwtZG91Z2hudXQtY2hhcnQ+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxqaGktY291cnNlLWRldGFpbC1saW5lLWNoYXJ0XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiY29sLXh4bC04XCJcbiAgICAgICAgICAgICAgICAgICAgW2NvdXJzZV09XCJjb3Vyc2VcIlxuICAgICAgICAgICAgICAgICAgICBbbnVtYmVyT2ZTdHVkZW50c0luQ291cnNlXT1cImNvdXJzZS5udW1iZXJPZlN0dWRlbnRzIVwiXG4gICAgICAgICAgICAgICAgICAgIFtpbml0aWFsU3RhdHNdPVwiYWN0aXZlU3R1ZGVudHNcIlxuICAgICAgICAgICAgICAgID48L2poaS1jb3Vyc2UtZGV0YWlsLWxpbmUtY2hhcnQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxociAvPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDI+PHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb3Vyc2UuZGV0YWlsLnRpdGxlXCI+Q291cnNlIERldGFpbHM6PC9zcGFuPjwvaDI+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxociAvPlxuICAgICAgICAgICAgPGRsIGNsYXNzPVwicm93LW1kIGpoLWVudGl0eS1kZXRhaWxzXCI+XG4gICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLnRpdGxlXCI+VGl0bGU8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICA8ZGQgaWQ9XCJjb3Vyc2UtdGl0bGVcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgY291cnNlLnRpdGxlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLnNob3J0TmFtZVwiPlNob3J0IE5hbWU8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICA8ZGQgaWQ9XCJjb3Vyc2Utc2hvcnQtbmFtZVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyBjb3Vyc2Uuc2hvcnROYW1lIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgQGlmICghIWNvdXJzZS5vcmdhbml6YXRpb25zPy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLm9yZ2FuaXphdGlvbnNcIj5Db3Vyc2UgT3JnYW5pemF0aW9uczwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgaWQ9XCJjb3Vyc2Utb3JnYW5pc2F0aW9uc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAob3JnYW5pemF0aW9uIG9mIGNvdXJzZS5vcmdhbml6YXRpb25zOyB0cmFjayBvcmdhbml6YXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLXByaW1hcnkgZm9udC13ZWlnaHQtbm9ybWFsIG0tMSBwcy0zXCI+e3sgb3JnYW5pemF0aW9uLm5hbWUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwhLS1cbiAgICAgICAgRm9yIHVzZXJzIHdoaWNoIGFyZSBhdCBsZWFzdCBpbnN0cnVjdG9yIHdlIHNob3cgdGhlIGdyb3VwIG5hbWUgaW5jbHVkaW5nIGEgbGluayB0byB0aGUgY291cnNlIHVzZXIgZ3JvdXAgbWFuYWdlbWVudCxcbiAgICAgICAgd2hlcmUgbmV3IHVzZXJzIGNhbiBiZSBhZGRlZCB0byB0aGUgZ3JvdXAsIHNpbmNlIHRoZXkgaGF2ZSB0aGUgcGVybWlzc2lvbiB0byBhZGQvcmVtb3ZlIHVzZXJzIHRvL2Zyb20gdGhlIGdyb3VwXG4gICAgICAgIC0tPlxuICAgICAgICAgICAgICAgIEBpZiAoY291cnNlLmlzQXRMZWFzdEluc3RydWN0b3IpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkdD48c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvdXJzZS5zdHVkZW50R3JvdXBOYW1lXCI+U3R1ZGVudCBHcm91cCBOYW1lPC9zcGFuPjwvZHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGQgaWQ9XCJjb3Vyc2Utc3R1ZGVudC1ncm91cC1uYW1lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWycvY291cnNlLW1hbmFnZW1lbnQnLCBjb3Vyc2UuaWQsICdncm91cHMnLCAnc3R1ZGVudHMnXVwiIGlkPVwiYWRkLXN0dWRlbnRzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGNvdXJzZS5zdHVkZW50R3JvdXBOYW1lIH19ICh7eyBjb3Vyc2UubnVtYmVyT2ZTdHVkZW50cyB9fSk8L2FcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLnRlYWNoaW5nQXNzaXN0YW50R3JvdXBOYW1lXCI+VGVhY2hpbmcgQXNzaXN0YW50IEdyb3VwIE5hbWU8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkZCBpZD1cImNvdXJzZS10dXRvci1ncm91cC1uYW1lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWycvY291cnNlLW1hbmFnZW1lbnQnLCBjb3Vyc2UuaWQsICdncm91cHMnLCAndHV0b3JzJ11cIiBpZD1cImFkZC10dXRvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgY291cnNlLnRlYWNoaW5nQXNzaXN0YW50R3JvdXBOYW1lIH19ICh7eyBjb3Vyc2UubnVtYmVyT2ZUZWFjaGluZ0Fzc2lzdGFudHMgfX0pPC9hXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkdD48c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvdXJzZS5lZGl0b3JHcm91cE5hbWVcIj5FZGl0b3IgR3JvdXAgTmFtZTwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRkIGlkPVwiY291cnNlLWVkaXRvci1ncm91cC1uYW1lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWycvY291cnNlLW1hbmFnZW1lbnQnLCBjb3Vyc2UuaWQsICdncm91cHMnLCAnZWRpdG9ycyddXCIgaWQ9XCJhZGQtZWRpdG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBjb3Vyc2UuZWRpdG9yR3JvdXBOYW1lIH19ICh7eyBjb3Vyc2UubnVtYmVyT2ZFZGl0b3JzIH19KTwvYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZHQ+PHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb3Vyc2UuaW5zdHJ1Y3Rvckdyb3VwTmFtZVwiPkluc3RydWN0b3IgR3JvdXAgTmFtZTwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRkIGlkPVwiY291cnNlLWluc3RydWN0b3ItZ3JvdXAtbmFtZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIFtyb3V0ZXJMaW5rXT1cIlsnL2NvdXJzZS1tYW5hZ2VtZW50JywgY291cnNlLmlkLCAnZ3JvdXBzJywgJ2luc3RydWN0b3JzJ11cIiBpZD1cImFkZC1pbnN0cnVjdG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBjb3Vyc2UuaW5zdHJ1Y3Rvckdyb3VwTmFtZSB9fSAoe3sgY291cnNlLm51bWJlck9mSW5zdHJ1Y3RvcnMgfX0pPC9hXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfSBAZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZHQ+PHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb3Vyc2Uuc3R1ZGVudEdyb3VwTmFtZVwiPlN0dWRlbnQgR3JvdXAgTmFtZTwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGNvdXJzZS5zdHVkZW50R3JvdXBOYW1lIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkdD48c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvdXJzZS50ZWFjaGluZ0Fzc2lzdGFudEdyb3VwTmFtZVwiPlRlYWNoaW5nIEFzc2lzdGFudCBHcm91cCBOYW1lPC9zcGFuPjwvZHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgY291cnNlLnRlYWNoaW5nQXNzaXN0YW50R3JvdXBOYW1lIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkdD48c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvdXJzZS5lZGl0b3JHcm91cE5hbWVcIj5FZGl0b3IgR3JvdXAgTmFtZTwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGNvdXJzZS5lZGl0b3JHcm91cE5hbWUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLmluc3RydWN0b3JHcm91cE5hbWVcIj5JbnN0cnVjdG9yIEdyb3VwIE5hbWU8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyBjb3Vyc2UuaW5zdHJ1Y3Rvckdyb3VwTmFtZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8IS0tXG4gICAgICAgICAgICBGb3IgdXNlcnMgd2hpY2ggYXJlIG5vdCBhdCBsZWFzdCBpbnN0cnVjdG9yIHdlIGp1c3Qgc2hvdyB0aGUgZ3JvdXAgbmFtZXMgd2l0aG91dCB0aGUgbGluayB0byB0aGUgY291cnNlIHVzZXIgbWFuYWdlbWVudCBwYWdlLFxuICAgICAgICAgICAgc2luY2UgdGhleSBkb24ndCBoYXZlIHRoZSBwZXJtaXNzaW9uIHRvIGFkZC9yZW1vdmUgdXNlcnMgdG8vZnJvbSB0aGUgZ3JvdXBcbiAgICAgICAgICAgIC0tPlxuICAgICAgICAgICAgICAgIDxkdD48c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvdXJzZS5tYXhQb2ludHMudGl0bGVcIj5NYXguIE51bWJlciBvZiBQb2ludHM8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICA8ZGQ+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGNvdXJzZS5tYXhQb2ludHMgfHwgJy0nIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLmFjY3VyYWN5T2ZTY29yZXNcIj5OdW1iZXIgb2YgZGVjaW1hbCBwbGFjZXMgdXNlZCBmb3IgY2FsY3VsYXRpbmcgdGhlIHNjb3Jlczwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgIDxkZD5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgY291cnNlLmFjY3VyYWN5T2ZTY29yZXMgfHwgJy0nIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLnN0YXJ0RGF0ZVwiPlN0YXJ0IERhdGU8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICA8ZGQgaWQ9XCJjb3Vyc2Utc3RhcnQtZGF0ZVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAoY291cnNlLnN0YXJ0RGF0ZSB8IGFydGVtaXNEYXRlKSB8fCAnLScgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICA8ZHQ+PHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb3Vyc2UuZW5kRGF0ZVwiPkVuZCBEYXRlPC9zcGFuPjwvZHQ+XG4gICAgICAgICAgICAgICAgPGRkIGlkPVwiY291cnNlLWVuZC1kYXRlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IChjb3Vyc2UuZW5kRGF0ZSB8IGFydGVtaXNEYXRlKSB8fCAnLScgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICA8ZHQ+PHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb3Vyc2Uuc2VtZXN0ZXJcIj5TZW1lc3Rlcjwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgIDxkZCBpZD1cImNvdXJzZS1zZW1lc3RlclwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyBjb3Vyc2Uuc2VtZXN0ZXIgfHwgJy0nIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLmRlZmF1bHRQcm9ncmFtbWluZ0xhbmd1YWdlXCI+RGVmYXVsdCBQcm9ncmFtbWluZyBMYW5ndWFnZTwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgIDxkZCBpZD1cImNvdXJzZS1wcm9ncmFtbWluZy1sYW5ndWFnZVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyBjb3Vyc2UuZGVmYXVsdFByb2dyYW1taW5nTGFuZ3VhZ2UgfHwgJy0nIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLnRlc3RDb3Vyc2UudGl0bGVcIj5UZXN0IENvdXJzZTwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgIDxkZCBpZD1cImNvdXJzZS10ZXN0LWNvdXJzZVwiPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKGNvdXJzZS50ZXN0Q291cnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAnZ2xvYmFsLmdlbmVyaWMueWVzJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQGlmICghY291cnNlLnRlc3RDb3Vyc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7ICdnbG9iYWwuZ2VuZXJpYy5ubycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICBAaWYgKGx0aUVuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLm9ubGluZUNvdXJzZS50aXRsZVwiPk9ubGluZSBDb3Vyc2U8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGlkPVwiY291cnNlLW9ubGluZS1jb3Vyc2VcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY291cnNlLm9ubGluZUNvdXJzZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7ICdnbG9iYWwuZ2VuZXJpYy55ZXMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWNvdXJzZS5vbmxpbmVDb3Vyc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAnZ2xvYmFsLmdlbmVyaWMubm8nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmIChsdGlFbmFibGVkICYmIGNvdXJzZS5vbmxpbmVDb3Vyc2UgJiYgY291cnNlLmlzQXRMZWFzdEluc3RydWN0b3IpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWycvY291cnNlLW1hbmFnZW1lbnQnLCBjb3Vyc2U/LmlkLCAnbHRpLWNvbmZpZ3VyYXRpb24nXVwiPkxUSSBDb25maWd1cmF0aW9uPC9hPlxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKGNvdXJzZS5lbnJvbGxtZW50RW5hYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICA8ZHQ+PHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb3Vyc2UuZW5yb2xsbWVudFN0YXJ0RGF0ZVwiPkVucm9sbG1lbnQgU3RhcnQ8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGlkPVwiY291cnNlLWVucm9sbG1lbnQtc3RhcnQtZGF0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgKGNvdXJzZS5lbnJvbGxtZW50U3RhcnREYXRlIHwgYXJ0ZW1pc0RhdGUpIHx8ICctJyB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLmVucm9sbG1lbnRFbmREYXRlXCI+RW5yb2xsbWVudCBFbmQ8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGlkPVwiY291cnNlLWVucm9sbG1lbnQtZW5kLWRhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IChjb3Vyc2UuZW5yb2xsbWVudEVuZERhdGUgfCBhcnRlbWlzRGF0ZSkgfHwgJy0nIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgICAgICA8ZHQ+PHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb3Vyc2UucmVnaXN0cmF0aW9uQ29uZmlybWF0aW9uTWVzc2FnZVwiPlJlZ2lzdHJhdGlvbiBDb25maXJtYXRpb24gTWVzc2FnZTwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY291cnNlLWVucm9sbG1lbnQtY29uZmlybWF0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwibWFya2Rvd24tcHJldmlldyBlZGl0b3Itb3V0bGluZS1iYWNrZ3JvdW5kXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtpbm5lckhUTUxdPVwiY291cnNlLmVucm9sbG1lbnRDb25maXJtYXRpb25NZXNzYWdlIHwgaHRtbEZvck1hcmtkb3duXCJcbiAgICAgICAgICAgICAgICAgICAgPjwvZGQ+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoY291cnNlLnVuZW5yb2xsbWVudEVuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLnVuZW5yb2xsbWVudEVuZERhdGVcIj5MYXRlc3QgZGF0ZSB0byB1bmVucm9sbDwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgaWQ9XCJjb3Vyc2UtdW5lbnJvbGxtZW50LWVuZC1kYXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAoY291cnNlLnVuZW5yb2xsbWVudEVuZERhdGUgfCBhcnRlbWlzRGF0ZSkgfHwgJy0nIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8bmctY29udGFpbmVyIFtqaGlGZWF0dXJlVG9nZ2xlTGlua109XCJGZWF0dXJlVG9nZ2xlLlR1dG9yaWFsR3JvdXBzXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7ICdhcnRlbWlzQXBwLmZvcm1zLmNvbmZpZ3VyYXRpb25Gb3JtLnRpbWVab25lSW5wdXQubGFiZWwnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fSA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIHJvdW5kZWQtcGlsbCB0ZXh0LWJnLXdhcm5pbmcgbXMtMVwiPkJFVEE8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY291cnNlLnRpbWVab25lKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgY291cnNlLnRpbWVab25lIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghY291cnNlLnRpbWVab25lKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgJ2dsb2JhbC5nZW5lcmljLnVuc2V0JyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS10ZXh0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuZm9ybXMuY29uZmlndXJhdGlvbkZvcm0udGltZVpvbmVJbnB1dC5iZXRhJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgIDwvbmctY29udGFpbmVyPlxuICAgICAgICAgICAgICAgIEBpZiAoY291cnNlLmNvbXBsYWludHNFbmFibGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkdD48c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvdXJzZS5tYXhDb21wbGFpbnRzLnRpdGxlXCI+TWF4aW11bSBhbW91bnQgb2YgY29tcGxhaW50cyBwZXIgc3R1ZGVudDwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgaWQ9XCJjb3Vyc2UtbWF4LWNvbXBsYWludHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGNvdXJzZS5tYXhDb21wbGFpbnRzIHx8ICctJyB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLm1heFRlYW1Db21wbGFpbnRzLnRpdGxlXCI+TWF4aW11bSBhbW91bnQgb2YgY29tcGxhaW50cyBwZXIgdGVhbTwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgaWQ9XCJjb3Vyc2UtbWF4LXRlYW0tY29tcGxhaW50c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgY291cnNlLm1heFRlYW1Db21wbGFpbnRzIHx8ICctJyB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLm1heENvbXBsYWludFRpbWVEYXlzLnRpdGxlXCI+RHVlIGRhdGUgZm9yIGNvbXBsYWludHMgaW4gZGF5cyBhZnRlciByZXN1bHQgZGF0ZTwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgaWQ9XCJjb3Vyc2UtbWF4LXRpbWUtZGF5c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgY291cnNlLm1heENvbXBsYWludFRpbWVEYXlzIHx8ICctJyB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLm1heENvbXBsYWludFRleHRMaW1pdC50aXRsZVwiPk1heGltdW0gbnVtYmVyIG9mIGNoYXJhY3RlcnMgcGVyIGNvbXBsYWludDwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgaWQ9XCJjb3Vyc2UtbWF4LWNvbXBsYWludC10ZXh0LWxpbWl0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyBjb3Vyc2UubWF4Q29tcGxhaW50VGV4dExpbWl0IHx8ICctJyB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLm1heENvbXBsYWludFJlc3BvbnNlVGV4dExpbWl0LnRpdGxlXCI+TWF4aW11bSBudW1iZXIgb2YgY2hhcmFjdGVycyBwZXIgY29tcGxhaW50IHJlc3BvbnNlPC9zcGFuPjwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBpZD1cImNvdXJzZS1tYXgtY29tcGxhaW50LXJlc3BvbnNlLXRleHQtbGltaXRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGNvdXJzZS5tYXhDb21wbGFpbnRSZXNwb25zZVRleHRMaW1pdCB8fCAnLScgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoY291cnNlLnJlcXVlc3RNb3JlRmVlZGJhY2tFbmFibGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkdD48c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvdXJzZS5tYXhSZXF1ZXN0TW9yZUZlZWRiYWNrVGltZURheXMudGl0bGVcIj5EdWUgZGF0ZSBmb3IgbW9yZSBmZWVkYmFjayByZXF1ZXN0cyBpbiBkYXlzIGFmdGVyIHJlc3VsdCBkYXRlPC9zcGFuPjwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBpZD1cImNvdXJzZS1tYXgtcmVxdWVzdC1tb3JlLWZlZWRiYWNrLWRheXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGNvdXJzZS5tYXhSZXF1ZXN0TW9yZUZlZWRiYWNrVGltZURheXMgfHwgJy0nIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8ZHQ+PHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb3Vyc2UuY291cnNlQ29tbXVuaWNhdGlvblNldHRpbmcuY29tbXVuaWNhdGlvbkVuYWJsZWQubGFiZWxcIj5Db21tdW5pY2F0aW9uIEVuYWJsZWQ8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICA8ZGQgaWQ9XCJjb3Vyc2UtY29tbXVuaWNhdGlvbi1lbmFibGVkXCI+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAodGhpcy5jb21tdW5pY2F0aW9uRW5hYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgJ2dsb2JhbC5nZW5lcmljLnllcycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoIXRoaXMuY29tbXVuaWNhdGlvbkVuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7ICdnbG9iYWwuZ2VuZXJpYy5ubycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICA8ZHQ+PHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb3Vyc2UuY291cnNlQ29tbXVuaWNhdGlvblNldHRpbmcubWVzc2FnaW5nRW5hYmxlZC5sYWJlbFwiPk1lc3NhZ2luZyBFbmFibGVkPC9zcGFuPjwvZHQ+XG4gICAgICAgICAgICAgICAgPGRkIGlkPVwiY291cnNlLW1lc3NhZ2luZy1lbmFibGVkXCI+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAodGhpcy5tZXNzYWdpbmdFbmFibGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAnZ2xvYmFsLmdlbmVyaWMueWVzJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQGlmICghdGhpcy5tZXNzYWdpbmdFbmFibGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAnZ2xvYmFsLmdlbmVyaWMubm8nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgQGlmICh0aGlzLm1lc3NhZ2luZ0VuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY291cnNlLmNvdXJzZUNvbW11bmljYXRpb25TZXR0aW5nLm1lc3NhZ2luZ0VuYWJsZWQuY29kZU9mQ29uZHVjdFwiPk1lc3NhZ2luZyBDb2RlIG9mIENvbmR1Y3Q8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNvdXJzZS1jb2RlLW9mLWNvbmR1Y3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJtYXJrZG93bi1wcmV2aWV3IGVkaXRvci1vdXRsaW5lLWJhY2tncm91bmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW2lubmVySFRNTF09XCJjb3Vyc2UuY291cnNlSW5mb3JtYXRpb25TaGFyaW5nTWVzc2FnaW5nQ29kZU9mQ29uZHVjdCB8IGh0bWxGb3JNYXJrZG93blwiXG4gICAgICAgICAgICAgICAgICAgID48L2RkPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKGlyaXNFbmFibGVkICYmIGlyaXNDaGF0RW5hYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuaXJpcy5zZXR0aW5ncy5zdWJTZXR0aW5ncy5lbmFibGVkLmNoYXRcIj5JcmlzIENoYXQ8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLWlyaXMtZW5hYmxlZCBbY291cnNlXT1cImNvdXJzZVwiIFtpcmlzU3ViU2V0dGluZ3NUeXBlXT1cIkNIQVRcIiBbZGlzYWJsZWRdPVwiIWlzQWRtaW5cIj48L2poaS1pcmlzLWVuYWJsZWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPCEtLSBUT0RPOiBFbmFibGUgaW4gZnV0dXJlIFBSIC0tPlxuICAgICAgICAgICAgICAgIEBpZiAoZmFsc2UgJiYgaXJpc0VuYWJsZWQgJiYgaXJpc0hlc3RpYUVuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkdD48c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3Muc3ViU2V0dGluZ3MuZW5hYmxlZC5oZXNpdGFcIj5JcmlzIEhlc3RpYTwvc3Bhbj48L2R0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktaXJpcy1lbmFibGVkIFtjb3Vyc2VdPVwiY291cnNlXCIgW2lyaXNTdWJTZXR0aW5nc1R5cGVdPVwiSEVTVElBXCIgW2Rpc2FibGVkXT1cIiFpc0FkbWluXCI+PC9qaGktaXJpcy1lbmFibGVkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwhLS0gVE9ETzogRW5hYmxlIGluIGZ1dHVyZSBQUiAtLT5cbiAgICAgICAgICAgICAgICBAaWYgKGZhbHNlICYmIGlyaXNFbmFibGVkICYmIGlyaXNDb2RlRWRpdG9yRW5hYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGR0PjxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuaXJpcy5zZXR0aW5ncy5zdWJTZXR0aW5ncy5lbmFibGVkLmNvZGVFZGl0b3JcIj5JcmlzIENvZGVFZGl0b3I8L3NwYW4+PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLWlyaXMtZW5hYmxlZCBbY291cnNlXT1cImNvdXJzZVwiIFtpcmlzU3ViU2V0dGluZ3NUeXBlXT1cIkNPREVfRURJVE9SXCIgW2Rpc2FibGVkXT1cIiFpc0FkbWluXCI+PC9qaGktaXJpcy1lbmFibGVkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kbD5cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuPC9kaXY+XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50LCBIdHRwUGFyYW1zIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgR3JhcGhzLCBTcGFuVHlwZSwgU3RhdGlzdGljc1ZpZXcgfSBmcm9tICdhcHAvZW50aXRpZXMvc3RhdGlzdGljcy5tb2RlbCc7XG5pbXBvcnQgeyBDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc0RUTyB9IGZyb20gJ2FwcC9jb3Vyc2UvbWFuYWdlL2NvdXJzZS1tYW5hZ2VtZW50LXN0YXRpc3RpY3MtZHRvJztcbmltcG9ydCB7IEV4ZXJjaXNlTWFuYWdlbWVudFN0YXRpc3RpY3NEdG8gfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9zdGF0aXN0aWNzL2V4ZXJjaXNlLW1hbmFnZW1lbnQtc3RhdGlzdGljcy1kdG8nO1xuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgcm91bmQgfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvdXRpbHMnO1xuaW1wb3J0IHsgY29udmVydERhdGVGcm9tU2VydmVyIH0gZnJvbSAnYXBwL3V0aWxzL2RhdGUudXRpbHMnO1xuaW1wb3J0IHsgRXhlcmNpc2VDYXRlZ29yeSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS1jYXRlZ29yeS5tb2RlbCc7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgU3RhdGlzdGljc1NlcnZpY2Uge1xuICAgIHByaXZhdGUgYmFzZVBhdGggPSAnbWFuYWdlbWVudC9zdGF0aXN0aWNzLyc7XG4gICAgcHJpdmF0ZSByZXNvdXJjZVVybCA9ICdhcGkvJyArIHRoaXMuYmFzZVBhdGg7XG4gICAgcHJpdmF0ZSBhZG1pblJlc291cmNlVXJsID0gJ2FwaS9hZG1pbi8nICsgdGhpcy5iYXNlUGF0aDtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cENsaWVudCkge31cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgR0VUIHJlcXVlc3QgdG8gcmV0cmlldmUgdGhlIGRhdGEgZm9yIGEgZ3JhcGggYmFzZWQgb24gdGhlIGdyYXBoVHlwZSBpbiB0aGUgbGFzdCAqc3BhbiogZGF5cyBhbmQgdGhlIGdpdmVuIHBlcmlvZFxuICAgICAqL1xuICAgIGdldENoYXJ0RGF0YShzcGFuOiBTcGFuVHlwZSwgcGVyaW9kSW5kZXg6IG51bWJlciwgZ3JhcGhUeXBlOiBHcmFwaHMpOiBPYnNlcnZhYmxlPG51bWJlcltdPiB7XG4gICAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKClcbiAgICAgICAgICAgIC5zZXQoJ3NwYW4nLCAnJyArIHNwYW4pXG4gICAgICAgICAgICAuc2V0KCdwZXJpb2RJbmRleCcsICcnICsgcGVyaW9kSW5kZXgpXG4gICAgICAgICAgICAuc2V0KCdncmFwaFR5cGUnLCAnJyArIGdyYXBoVHlwZSk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PG51bWJlcltdPihgJHt0aGlzLmFkbWluUmVzb3VyY2VVcmx9ZGF0YWAsIHsgcGFyYW1zIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmRzIGEgR0VUIHJlcXVlc3QgdG8gcmV0cmlldmUgdGhlIGRhdGEgZm9yIGEgZ3JhcGggYmFzZWQgb24gdGhlIGdyYXBoVHlwZSBpbiB0aGUgbGFzdCAqc3BhbiogZGF5cywgdGhlIGdpdmVuIHBlcmlvZCBhbmQgdGhlIGlkIG9mIHRoZSBlbnRpdHkgKGUuZy4gY291cnNlLCBleGVyY2lzZSlcbiAgICAgKi9cbiAgICBnZXRDaGFydERhdGFGb3JDb250ZW50KHNwYW46IFNwYW5UeXBlLCBwZXJpb2RJbmRleDogbnVtYmVyLCBncmFwaFR5cGU6IEdyYXBocywgdmlldzogU3RhdGlzdGljc1ZpZXcsIGVudGl0eUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPG51bWJlcltdPiB7XG4gICAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKClcbiAgICAgICAgICAgIC5zZXQoJ3NwYW4nLCAnJyArIHNwYW4pXG4gICAgICAgICAgICAuc2V0KCdwZXJpb2RJbmRleCcsICcnICsgcGVyaW9kSW5kZXgpXG4gICAgICAgICAgICAuc2V0KCdncmFwaFR5cGUnLCAnJyArIGdyYXBoVHlwZSlcbiAgICAgICAgICAgIC5zZXQoJ3ZpZXcnLCAnJyArIHZpZXcpXG4gICAgICAgICAgICAuc2V0KCdlbnRpdHlJZCcsICcnICsgZW50aXR5SWQpO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxudW1iZXJbXT4oYCR7dGhpcy5yZXNvdXJjZVVybH1kYXRhLWZvci1jb250ZW50YCwgeyBwYXJhbXMgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBHRVQgcmVxdWVzdCB0byByZXRyaWV2ZSBkYXRhIG5lZWRlZCBmb3IgdGhlIGNvdXJzZSBzdGF0aXN0aWNzXG4gICAgICovXG4gICAgZ2V0Q291cnNlU3RhdGlzdGljcyhjb3Vyc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc0RUTz4ge1xuICAgICAgICBjb25zdCBwYXJhbXMgPSBuZXcgSHR0cFBhcmFtcygpLnNldCgnY291cnNlSWQnLCAnJyArIGNvdXJzZUlkKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8Q291cnNlTWFuYWdlbWVudFN0YXRpc3RpY3NEVE8+KGAke3RoaXMucmVzb3VyY2VVcmx9Y291cnNlLXN0YXRpc3RpY3NgLCB7IHBhcmFtcyB9KS5waXBlKFxuICAgICAgICAgICAgbWFwKChyZXM6IENvdXJzZU1hbmFnZW1lbnRTdGF0aXN0aWNzRFRPKSA9PiB7XG4gICAgICAgICAgICAgICAgU3RhdGlzdGljc1NlcnZpY2UuY29udmVydEV4ZXJjaXNlQ2F0ZWdvcmllc09mckNvdXJzZU1hbmFnZW1lbnRTdGF0aXN0aWNzRnJvbVNlcnZlcihyZXMpO1xuICAgICAgICAgICAgICAgIHJldHVybiBTdGF0aXN0aWNzU2VydmljZS5jb252ZXJ0Q291cnNlTWFuYWdlbWVudFN0YXRpc3RpY0RhdGVzRnJvbVNlcnZlcihyZXMpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZHMgYSBHRVQgcmVxdWVzdCB0byByZXRyaWV2ZSBkYXRhIG5lZWRlZCBmb3IgdGhlIGV4ZXJjaXNlIHN0YXRpc3RpY3NcbiAgICAgKi9cbiAgICBnZXRFeGVyY2lzZVN0YXRpc3RpY3MoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxFeGVyY2lzZU1hbmFnZW1lbnRTdGF0aXN0aWNzRHRvPiB7XG4gICAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKCkuc2V0KCdleGVyY2lzZUlkJywgJycgKyBleGVyY2lzZUlkKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLmdldDxFeGVyY2lzZU1hbmFnZW1lbnRTdGF0aXN0aWNzRHRvPihgJHt0aGlzLnJlc291cmNlVXJsfWV4ZXJjaXNlLXN0YXRpc3RpY3NgLCB7IHBhcmFtcyB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEV4ZXJjaXNlTWFuYWdlbWVudFN0YXRpc3RpY3NEdG8pID0+IFN0YXRpc3RpY3NTZXJ2aWNlLmNhbGN1bGF0ZVBlcmNlbnRhZ2VzRm9yRXhlcmNpc2VTdGF0aXN0aWNzKHJlcykpKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHN0YXRpYyBjYWxjdWxhdGVQZXJjZW50YWdlc0ZvckV4ZXJjaXNlU3RhdGlzdGljcyhzdGF0czogRXhlcmNpc2VNYW5hZ2VtZW50U3RhdGlzdGljc0R0byk6IEV4ZXJjaXNlTWFuYWdlbWVudFN0YXRpc3RpY3NEdG8ge1xuICAgICAgICBzdGF0cy5wYXJ0aWNpcGF0aW9uc0luUGVyY2VudCA9IHN0YXRzLm51bWJlck9mU3R1ZGVudHNPclRlYW1zSW5Db3Vyc2UgPiAwID8gcm91bmQoKHN0YXRzLm51bWJlck9mUGFydGljaXBhdGlvbnMgLyBzdGF0cy5udW1iZXJPZlN0dWRlbnRzT3JUZWFtc0luQ291cnNlKSAqIDEwMCwgMSkgOiAwO1xuICAgICAgICBzdGF0cy5yZXNvbHZlZFBvc3RzSW5QZXJjZW50ID0gc3RhdHMubnVtYmVyT2ZQb3N0cyA+IDAgPyByb3VuZCgoc3RhdHMubnVtYmVyT2ZSZXNvbHZlZFBvc3RzIC8gc3RhdHMubnVtYmVyT2ZQb3N0cykgKiAxMDAsIDEpIDogMDtcbiAgICAgICAgc3RhdHMuYWJzb2x1dGVBdmVyYWdlUG9pbnRzID0gcm91bmQoKHN0YXRzLmF2ZXJhZ2VTY29yZU9mRXhlcmNpc2UgKiBzdGF0cy5tYXhQb2ludHNPZkV4ZXJjaXNlKSAvIDEwMCwgMSk7XG4gICAgICAgIHJldHVybiBzdGF0cztcbiAgICB9XG5cbiAgICBwcml2YXRlIHN0YXRpYyBjb252ZXJ0Q291cnNlTWFuYWdlbWVudFN0YXRpc3RpY0RhdGVzRnJvbVNlcnZlcihkdG86IENvdXJzZU1hbmFnZW1lbnRTdGF0aXN0aWNzRFRPKTogQ291cnNlTWFuYWdlbWVudFN0YXRpc3RpY3NEVE8ge1xuICAgICAgICBkdG8uYXZlcmFnZVNjb3Jlc09mRXhlcmNpc2VzLmZvckVhY2goKGF2ZXJhZ2VTY29yZXMpID0+IHtcbiAgICAgICAgICAgIGF2ZXJhZ2VTY29yZXMucmVsZWFzZURhdGUgPSBjb252ZXJ0RGF0ZUZyb21TZXJ2ZXIoYXZlcmFnZVNjb3Jlcy5yZWxlYXNlRGF0ZSk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gZHRvO1xuICAgIH1cblxuICAgIHByaXZhdGUgc3RhdGljIGNvbnZlcnRFeGVyY2lzZUNhdGVnb3JpZXNPZnJDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc0Zyb21TZXJ2ZXIocmVzOiBDb3Vyc2VNYW5hZ2VtZW50U3RhdGlzdGljc0RUTyk6IENvdXJzZU1hbmFnZW1lbnRTdGF0aXN0aWNzRFRPIHtcbiAgICAgICAgcmVzLmF2ZXJhZ2VTY29yZXNPZkV4ZXJjaXNlcy5mb3JFYWNoKChhdmdTY29yZXNPZkV4ZXJjaXNlKSA9PiB7XG4gICAgICAgICAgICBhdmdTY29yZXNPZkV4ZXJjaXNlLmNhdGVnb3JpZXMgPSBhdmdTY29yZXNPZkV4ZXJjaXNlLmNhdGVnb3JpZXM/Lm1hcCgoY2F0ZWdvcnkpID0+IEpTT04ucGFyc2UoY2F0ZWdvcnkgYXMgc3RyaW5nKSBhcyBFeGVyY2lzZUNhdGVnb3J5KTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXM7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25DaGFuZ2VzLCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBEb3VnaG51dENoYXJ0VHlwZSB9IGZyb20gJ2FwcC9jb3Vyc2UvbWFuYWdlL2RldGFpbC9jb3Vyc2UtZGV0YWlsLmNvbXBvbmVudCc7XG5pbXBvcnQgeyByb3VuZFZhbHVlU3BlY2lmaWVkQnlDb3Vyc2VTZXR0aW5ncyB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC91dGlscyc7XG5pbXBvcnQgeyBFeGVyY2lzZVR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgZmFTcGlubmVyIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IENvdXJzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb3Vyc2UubW9kZWwnO1xuaW1wb3J0IHsgQ29sb3IsIFNjYWxlVHlwZSB9IGZyb20gJ0Bzd2ltbGFuZS9uZ3gtY2hhcnRzJztcbmltcG9ydCB7IE5neENoYXJ0c1NpbmdsZVNlcmllc0RhdGFFbnRyeSB9IGZyb20gJ2FwcC9zaGFyZWQvY2hhcnQvbmd4LWNoYXJ0cy1kYXRhdHlwZXMnO1xuaW1wb3J0IHsgR3JhcGhDb2xvcnMgfSBmcm9tICdhcHAvZW50aXRpZXMvc3RhdGlzdGljcy5tb2RlbCc7XG5cbmNvbnN0IFBJRV9DSEFSVF9OQV9GQUxMQkFDS19WQUxVRSA9IFswLCAwLCAxXTtcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktZG91Z2hudXQtY2hhcnQnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9kb3VnaG51dC1jaGFydC5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vZG91Z2hudXQtY2hhcnQuY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgRG91Z2hudXRDaGFydENvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcywgT25Jbml0IHtcbiAgICBASW5wdXQoKSBjb3Vyc2U6IENvdXJzZTtcbiAgICBASW5wdXQoKSBjb250ZW50VHlwZTogRG91Z2hudXRDaGFydFR5cGU7XG4gICAgQElucHV0KCkgZXhlcmNpc2VJZDogbnVtYmVyO1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlVHlwZTogRXhlcmNpc2VUeXBlO1xuICAgIEBJbnB1dCgpIGN1cnJlbnRQZXJjZW50YWdlOiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgQElucHV0KCkgY3VycmVudEFic29sdXRlOiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgQElucHV0KCkgY3VycmVudE1heDogbnVtYmVyIHwgdW5kZWZpbmVkO1xuXG4gICAgcmVjZWl2ZWRTdGF0cyA9IGZhbHNlO1xuICAgIGRvdWdobnV0Q2hhcnRUaXRsZTogc3RyaW5nO1xuICAgIHN0YXRzOiBudW1iZXJbXTtcbiAgICB0aXRsZUxpbms6IHN0cmluZ1tdIHwgdW5kZWZpbmVkO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYVNwaW5uZXIgPSBmYVNwaW5uZXI7XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJvdXRlcjogUm91dGVyKSB7fVxuXG4gICAgLy8gbmd4XG4gICAgbmd4RG91Z2hudXREYXRhOiBOZ3hDaGFydHNTaW5nbGVTZXJpZXNEYXRhRW50cnlbXSA9IFtcbiAgICAgICAgeyBuYW1lOiAnRG9uZScsIHZhbHVlOiAwIH0sXG4gICAgICAgIHsgbmFtZTogJ05vdCBkb25lJywgdmFsdWU6IDAgfSxcbiAgICAgICAgeyBuYW1lOiAnTi9BJywgdmFsdWU6IDAgfSwgLy8gZmFsbGJhY2sgdG8gZGlzcGxheSBncmV5IGNpcmNsZSBpZiB0aGVyZSBpcyBubyBtYXhWYWx1ZVxuICAgIF07XG4gICAgbmd4Q29sb3IgPSB7XG4gICAgICAgIG5hbWU6ICd2aXZpZCcsXG4gICAgICAgIHNlbGVjdGFibGU6IHRydWUsXG4gICAgICAgIGdyb3VwOiBTY2FsZVR5cGUuT3JkaW5hbCxcbiAgICAgICAgZG9tYWluOiBbR3JhcGhDb2xvcnMuR1JFRU4sIEdyYXBoQ29sb3JzLlJFRCwgR3JhcGhDb2xvcnMuTElHSFRfR1JFWV0sXG4gICAgfSBhcyBDb2xvcjtcbiAgICBiaW5kRm9ybWF0dGluZyA9IHRoaXMudmFsdWVGb3JtYXR0aW5nLmJpbmQodGhpcyk7XG5cbiAgICBuZ09uQ2hhbmdlcygpOiB2b2lkIHtcbiAgICAgICAgLy8gWzAsIDAsIDBdIHdpbGwgbGVhZCB0byB0aGUgY2hhcnQgbm90IGJlaW5nIGRpc3BsYXllZCxcbiAgICAgICAgLy8gYXNzaWduaW5nIFswLCAwLCAwXSAoUElFX0NIQVJUX05BX0ZBTExCQUNLX1ZBTFVFKSB3b3JrcyBhcm91bmQgdGhpcyBpc3N1ZSBhbmQgZGlzcGxheXMgMCAlLCAwIC8gMCB3aXRoIGEgZ3JleSBjaXJjbGVcbiAgICAgICAgaWYgKHRoaXMuY3VycmVudEFic29sdXRlID09IHVuZGVmaW5lZCAmJiAhdGhpcy5yZWNlaXZlZFN0YXRzKSB7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVBpZUNoYXJ0RGF0YShQSUVfQ0hBUlRfTkFfRkFMTEJBQ0tfVkFMVUUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5yZWNlaXZlZFN0YXRzID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbnN0IHJlbWFpbmluZyA9IHJvdW5kVmFsdWVTcGVjaWZpZWRCeUNvdXJzZVNldHRpbmdzKHRoaXMuY3VycmVudE1heCEgLSB0aGlzLmN1cnJlbnRBYnNvbHV0ZSEsIHRoaXMuY291cnNlKTtcbiAgICAgICAgICAgIHRoaXMuc3RhdHMgPSBbdGhpcy5jdXJyZW50QWJzb2x1dGUhLCByZW1haW5pbmcsIDBdOyAvLyBkb25lLCBub3QgZG9uZSwgbmFcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmN1cnJlbnRNYXggPT09IDAgPyB0aGlzLnVwZGF0ZVBpZUNoYXJ0RGF0YShQSUVfQ0hBUlRfTkFfRkFMTEJBQ0tfVkFMVUUpIDogdGhpcy51cGRhdGVQaWVDaGFydERhdGEodGhpcy5zdGF0cyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEZXBlbmRpbmcgb24gdGhlIGluZm9ybWF0aW9uIHdlIHdhbnQgdG8gZGlzcGxheSBpbiB0aGUgZG91Z2hudXQgY2hhcnQsIHdlIG5lZWQgZGlmZmVyZW50IHRpdGxlcyBhbmQgbGlua3NcbiAgICAgKi9cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgc3dpdGNoICh0aGlzLmNvbnRlbnRUeXBlKSB7XG4gICAgICAgICAgICBjYXNlIERvdWdobnV0Q2hhcnRUeXBlLkFWRVJBR0VfRVhFUkNJU0VfU0NPUkU6XG4gICAgICAgICAgICAgICAgdGhpcy5kb3VnaG51dENoYXJ0VGl0bGUgPSAnYXZlcmFnZVNjb3JlJztcbiAgICAgICAgICAgICAgICB0aGlzLnRpdGxlTGluayA9IFtgL2NvdXJzZS1tYW5hZ2VtZW50LyR7dGhpcy5jb3Vyc2UuaWR9LyR7dGhpcy5leGVyY2lzZVR5cGV9LWV4ZXJjaXNlcy8ke3RoaXMuZXhlcmNpc2VJZH0vc2NvcmVzYF07XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIERvdWdobnV0Q2hhcnRUeXBlLlBBUlRJQ0lQQVRJT05TOlxuICAgICAgICAgICAgICAgIHRoaXMuZG91Z2hudXRDaGFydFRpdGxlID0gJ3BhcnRpY2lwYXRpb25SYXRlJztcbiAgICAgICAgICAgICAgICB0aGlzLnRpdGxlTGluayA9IFtgL2NvdXJzZS1tYW5hZ2VtZW50LyR7dGhpcy5jb3Vyc2UuaWR9LyR7dGhpcy5leGVyY2lzZVR5cGV9LWV4ZXJjaXNlcy8ke3RoaXMuZXhlcmNpc2VJZH0vcGFydGljaXBhdGlvbnNgXTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgRG91Z2hudXRDaGFydFR5cGUuUVVFU1RJT05TOlxuICAgICAgICAgICAgICAgIHRoaXMuZG91Z2hudXRDaGFydFRpdGxlID0gJ3Jlc29sdmVkX3Bvc3RzJztcbiAgICAgICAgICAgICAgICB0aGlzLnRpdGxlTGluayA9IFtgL2NvdXJzZXMvJHt0aGlzLmNvdXJzZS5pZH0vZXhlcmNpc2VzLyR7dGhpcy5leGVyY2lzZUlkfWBdO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICB0aGlzLmRvdWdobnV0Q2hhcnRUaXRsZSA9ICcnO1xuICAgICAgICAgICAgICAgIHRoaXMudGl0bGVMaW5rID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogaGFuZGxlcyBjbGlja3Mgb250byB0aGUgZ3JhcGgsIHdoaWNoIHRoZW4gcmVkaXJlY3RzIHRoZSB1c2VyIHRvIHRoZSBjb3JyZXNwb25kaW5nIHBhZ2UsXG4gICAgICogZS5nLiBwYXJ0aWNpcGF0aW9ucyB0byB0aGUgcGFydGljaXBhdGlvbnMgcGFnZVxuICAgICAqL1xuICAgIG9wZW5Db3JyZXNwb25kaW5nUGFnZSgpIHtcbiAgICAgICAgaWYgKHRoaXMuY291cnNlLmlkICYmIHRoaXMuZXhlcmNpc2VJZCAmJiB0aGlzLnRpdGxlTGluaykge1xuICAgICAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUodGhpcy50aXRsZUxpbmspO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQXNzaWducyBhIGdpdmVuIGFycmF5IG9mIG51bWJlcnMgdG8gbmd4RGF0YVxuICAgICAqIEBwYXJhbSB2YWx1ZXMgdGhlIHZhbHVlcyB0aGF0IHNob3VsZCBiZSBkaXNwbGF5ZWQgYnkgdGhlIGNoYXJ0XG4gICAgICovXG4gICAgcHJpdmF0ZSB1cGRhdGVQaWVDaGFydERhdGEodmFsdWVzOiBudW1iZXJbXSkge1xuICAgICAgICB0aGlzLm5neERvdWdobnV0RGF0YS5mb3JFYWNoKChlbnRyeTogTmd4Q2hhcnRzU2luZ2xlU2VyaWVzRGF0YUVudHJ5LCBpbmRleDogbnVtYmVyKSA9PiAoZW50cnkudmFsdWUgPSB2YWx1ZXNbaW5kZXhdKSk7XG4gICAgICAgIHRoaXMubmd4RG91Z2hudXREYXRhID0gWy4uLnRoaXMubmd4RG91Z2hudXREYXRhXTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBNb2RpZmllcyB0aGUgdG9vbHRpcCBjb250ZW50IG9mIHRoZSBjaGFydC5cbiAgICAgKiBAcGFyYW0gZGF0YSBhIGRlZGljYXRlZCBvYmplY3QgcGFzc2VkIGJ5IG5neC1jaGFydHNcbiAgICAgKiBAcmV0dXJucyBhYnNvbHV0ZSB2YWx1ZSByZXByZXNlbnRlZCBieSBkb3VnaG51dCBwaWVjZSBvciAwIGlmIHRoZSBjdXJyZW50TWF4IGlzIDAuXG4gICAgICogVGhpcyBpcyBuZWNlc3NhcnkgaW4gb3JkZXIgdG8gY29tcGVuc2F0ZSB0aGUgd29ya2Fyb3VuZCBmb3JcbiAgICAgKiBkaXNwbGF5aW5nIGEgY2hhcnQgZXZlbiBpZiBubyB2YWx1ZXMgYXJlIHRoZXJlIHRvIGRpc3BsYXkgKGkuZS4gY3VycmVudE1heCBpcyAwKVxuICAgICAqL1xuICAgIHZhbHVlRm9ybWF0dGluZyhkYXRhOiBhbnkpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5jdXJyZW50TWF4ID09PSAwID8gJzAnIDogZGF0YS52YWx1ZTtcbiAgICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwibXgtMiBkLWZsZXggZmxleC1jb2x1bW4ganVzdGlmeS1jb250ZW50LWJldHdlZW4gaC0xMDBcIj5cbiAgICBAaWYgKHRpdGxlTGluaykge1xuICAgICAgICA8YSBbcm91dGVyTGlua109XCJ0aXRsZUxpbmtcIj5cbiAgICAgICAgICAgIDxoNCBjbGFzcz1cInRleHQtY2VudGVyXCI+e3sgJ2V4ZXJjaXNlLXN0YXRpc3RpY3MuJyArIGRvdWdobnV0Q2hhcnRUaXRsZSB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2g0PlxuICAgICAgICA8L2E+XG4gICAgfVxuICAgIEBpZiAoIXRpdGxlTGluaykge1xuICAgICAgICA8aDQgY2xhc3M9XCJ0ZXh0LWNlbnRlclwiPnt7ICdleGVyY2lzZS1zdGF0aXN0aWNzLicgKyBkb3VnaG51dENoYXJ0VGl0bGUgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9oND5cbiAgICB9XG4gICAgPGRpdiBjbGFzcz1cImRvdWdobnV0LWNoYXJ0LWNvbnRhaW5lclwiIFtuZ0NsYXNzXT1cInRpdGxlTGluayA/ICdjbGlja2FibGUnIDogJydcIiAoY2xpY2spPVwib3BlbkNvcnJlc3BvbmRpbmdQYWdlKClcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImRvdWdobnV0LWNoYXJ0LXRleHRcIj5cbiAgICAgICAgICAgIEBpZiAocmVjZWl2ZWRTdGF0cykge1xuICAgICAgICAgICAgICAgIDxoMiBjbGFzcz1cInRleHQtY2VudGVyXCI+e3sgY3VycmVudFBlcmNlbnRhZ2UgfX0lPC9oMj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAocmVjZWl2ZWRTdGF0cykge1xuICAgICAgICAgICAgICAgIDxoNCBjbGFzcz1cInRleHQtY2VudGVyXCI+e3sgY3VycmVudEFic29sdXRlIH19IC8ge3sgY3VycmVudE1heCB9fTwvaDQ+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKCFyZWNlaXZlZFN0YXRzKSB7XG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzPVwidGV4dC1jZW50ZXJcIiBzdHlsZT1cInotaW5kZXg6IDFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFTcGlubmVyXCIgW3NwaW5dPVwidHJ1ZVwiPiZuYnNwOzwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPG5neC1jaGFydHMtcGllLWNoYXJ0IFt2aWV3XT1cIlsyMDAsIDIwMF1cIiBbcmVzdWx0c109XCJuZ3hEb3VnaG51dERhdGFcIiBbc2NoZW1lXT1cIm5neENvbG9yXCIgW2RvdWdobnV0XT1cInRydWVcIiBbdG9vbHRpcFRleHRdPVwiYmluZEZvcm1hdHRpbmdcIj4gPC9uZ3gtY2hhcnRzLXBpZS1jaGFydD5cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25DaGFuZ2VzLCBTaW1wbGVDaGFuZ2VzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTdGF0aXN0aWNzU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvc3RhdGlzdGljcy1ncmFwaC9zdGF0aXN0aWNzLnNlcnZpY2UnO1xuaW1wb3J0IGRheWpzIGZyb20gJ2RheWpzL2VzbSc7XG5pbXBvcnQgeyBHcmFwaENvbG9ycywgR3JhcGhzLCBTcGFuVHlwZSwgU3RhdGlzdGljc1ZpZXcgfSBmcm9tICdhcHAvZW50aXRpZXMvc3RhdGlzdGljcy5tb2RlbCc7XG5pbXBvcnQgeyBmYUFycm93TGVmdCwgZmFBcnJvd1JpZ2h0IH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IHlBeGlzVGlja0Zvcm1hdHRpbmcgfSBmcm9tICdhcHAvc2hhcmVkL3N0YXRpc3RpY3MtZ3JhcGgvc3RhdGlzdGljcy1ncmFwaC51dGlscyc7XG5pbXBvcnQgeyBDb2xvciwgU2NhbGVUeXBlIH0gZnJvbSAnQHN3aW1sYW5lL25neC1jaGFydHMnO1xuaW1wb3J0IHsgVHJhbnNsYXRlU2VydmljZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xuaW1wb3J0IHsgTmd4Q2hhcnRzU2luZ2xlU2VyaWVzRGF0YUVudHJ5IH0gZnJvbSAnYXBwL3NoYXJlZC9jaGFydC9uZ3gtY2hhcnRzLWRhdGF0eXBlcyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXN0YXRpc3RpY3MtZ3JhcGgnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9zdGF0aXN0aWNzLWdyYXBoLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi4vY2hhcnQvdmVydGljYWwtYmFyLWNoYXJ0LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgU3RhdGlzdGljc0dyYXBoQ29tcG9uZW50IGltcGxlbWVudHMgT25DaGFuZ2VzIHtcbiAgICBASW5wdXQoKVxuICAgIGdyYXBoVHlwZTogR3JhcGhzO1xuICAgIEBJbnB1dCgpXG4gICAgY3VycmVudFNwYW46IFNwYW5UeXBlO1xuICAgIEBJbnB1dCgpXG4gICAgc3RhdGlzdGljc1ZpZXc6IFN0YXRpc3RpY3NWaWV3O1xuICAgIEBJbnB1dCgpXG4gICAgZW50aXR5SWQ/OiBudW1iZXI7XG5cbiAgICAvLyBIdG1sIHByb3BlcnRpZXNcbiAgICBMRUZUID0gZmFsc2U7XG4gICAgUklHSFQgPSB0cnVlO1xuICAgIFNwYW5UeXBlID0gU3BhblR5cGU7XG4gICAgR3JhcGhzID0gR3JhcGhzO1xuXG4gICAgLy8gSGlzdG9ncmFtIHJlbGF0ZWQgcHJvcGVydGllc1xuICAgIGNoYXJ0TmFtZTogc3RyaW5nO1xuICAgIGJhckNoYXJ0TGVnZW5kID0gZmFsc2U7XG4gICAgY2hhcnRUaW1lOiBhbnk7XG4gICAgLy8gRGF0YVxuICAgIGJhckNoYXJ0TGFiZWxzOiBzdHJpbmdbXSA9IFtdO1xuICAgIGRhdGFGb3JTcGFuVHlwZTogbnVtYmVyW107XG5cbiAgICAvLyBuZ3hcbiAgICBuZ3hEYXRhOiBOZ3hDaGFydHNTaW5nbGVTZXJpZXNEYXRhRW50cnlbXSA9IFtdO1xuICAgIG5neENvbG9yOiBDb2xvciA9IHtcbiAgICAgICAgbmFtZTogJ1N0YXRpc3RpY3MnLFxuICAgICAgICBzZWxlY3RhYmxlOiB0cnVlLFxuICAgICAgICBncm91cDogU2NhbGVUeXBlLk9yZGluYWwsXG4gICAgICAgIGRvbWFpbjogW0dyYXBoQ29sb3JzLkRBUktfQkxVRV0sXG4gICAgfTtcbiAgICB0b29sdGlwVHJhbnNsYXRpb246IHN0cmluZztcbiAgICB5U2NhbGVNYXg6IG51bWJlcjtcbiAgICB5QXhpc1RpY2tGb3JtYXR0aW5nID0geUF4aXNUaWNrRm9ybWF0dGluZztcblxuICAgIC8vIExlZnQgYXJyb3cgLT4gZGVjcmVhc2UsIHJpZ2h0IGFycm93IC0+IGluY3JlYXNlXG4gICAgcHJpdmF0ZSBjdXJyZW50UGVyaW9kID0gMDtcblxuICAgIC8vIEljb25zXG4gICAgZmFBcnJvd0xlZnQgPSBmYUFycm93TGVmdDtcbiAgICBmYUFycm93UmlnaHQgPSBmYUFycm93UmlnaHQ7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBzZXJ2aWNlOiBTdGF0aXN0aWNzU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSB0cmFuc2xhdGVTZXJ2aWNlOiBUcmFuc2xhdGVTZXJ2aWNlLFxuICAgICkge1xuICAgICAgICB0aGlzLnRyYW5zbGF0ZVNlcnZpY2Uub25MYW5nQ2hhbmdlLnN1YnNjcmliZSgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLm9uU3lzdGVtTGFuZ3VhZ2VDaGFuZ2UoKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTGlmZSBjeWNsZSBob29rIHRvIGluZGljYXRlIGNvbXBvbmVudCBjaGFuZ2VzXG4gICAgICogQHBhcmFtIHtTaW1wbGVDaGFuZ2VzfSBjaGFuZ2VzIC0gQ2hhbmdlcyBiZWluZyBtYWRlIHRvIHRoZSBjb21wb25lbnRcbiAgICAgKi9cbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XG4gICAgICAgIHRoaXMuY3VycmVudFNwYW4gPSBjaGFuZ2VzLmN1cnJlbnRTcGFuPy5jdXJyZW50VmFsdWU7XG4gICAgICAgIHRoaXMuYmFyQ2hhcnRMYWJlbHMgPSBbXTtcbiAgICAgICAgdGhpcy5jdXJyZW50UGVyaW9kID0gMDtcbiAgICAgICAgdGhpcy5jaGFydE5hbWUgPSBgc3RhdGlzdGljcy4ke3RoaXMuZ3JhcGhUeXBlLnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKX1gO1xuICAgICAgICB0aGlzLnRvb2x0aXBUcmFuc2xhdGlvbiA9IGBzdGF0aXN0aWNzLiR7dGhpcy5ncmFwaFR5cGUudG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpfVRpdGxlYDtcbiAgICAgICAgdGhpcy5pbml0aWFsaXplQ2hhcnQoKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGluaXRpYWxpemVDaGFydCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5jcmVhdGVMYWJlbHMoKTtcbiAgICAgICAgaWYgKHRoaXMuc3RhdGlzdGljc1ZpZXcgPT09IFN0YXRpc3RpY3NWaWV3LkFSVEVNSVMpIHtcbiAgICAgICAgICAgIHRoaXMuc2VydmljZS5nZXRDaGFydERhdGEodGhpcy5jdXJyZW50U3BhbiwgdGhpcy5jdXJyZW50UGVyaW9kLCB0aGlzLmdyYXBoVHlwZSkuc3Vic2NyaWJlKChyZXM6IG51bWJlcltdKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5kYXRhRm9yU3BhblR5cGUgPSByZXM7XG4gICAgICAgICAgICAgICAgdGhpcy5wdXNoVG9EYXRhKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuc2VydmljZS5nZXRDaGFydERhdGFGb3JDb250ZW50KHRoaXMuY3VycmVudFNwYW4sIHRoaXMuY3VycmVudFBlcmlvZCwgdGhpcy5ncmFwaFR5cGUsIHRoaXMuc3RhdGlzdGljc1ZpZXcsIHRoaXMuZW50aXR5SWQhKS5zdWJzY3JpYmUoKHJlczogbnVtYmVyW10pID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmRhdGFGb3JTcGFuVHlwZSA9IHJlcztcbiAgICAgICAgICAgICAgICB0aGlzLnB1c2hUb0RhdGEoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBjcmVhdGVMYWJlbHMoKTogdm9pZCB7XG4gICAgICAgIGNvbnN0IG5vdyA9IGRheWpzKCk7XG4gICAgICAgIGxldCBzdGFydERhdGU7XG4gICAgICAgIGxldCBlbmREYXRlO1xuICAgICAgICBzd2l0Y2ggKHRoaXMuY3VycmVudFNwYW4pIHtcbiAgICAgICAgICAgIGNhc2UgU3BhblR5cGUuREFZOlxuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgMjQ7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmJhckNoYXJ0TGFiZWxzW2ldID0gYCR7aX06MDAtJHtpICsgMX06MDBgO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0aGlzLmNoYXJ0VGltZSA9IG5vdy5hZGQodGhpcy5jdXJyZW50UGVyaW9kLCAnZGF5cycpLmZvcm1hdCgnREQuTU0uWVlZWScpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBTcGFuVHlwZS5XRUVLOlxuICAgICAgICAgICAgICAgIHRoaXMuYmFyQ2hhcnRMYWJlbHMgPSB0aGlzLmdldFdlZWtkYXlzKCk7XG4gICAgICAgICAgICAgICAgc3RhcnREYXRlID0gZGF5anMoKS5hZGQodGhpcy5jdXJyZW50UGVyaW9kLCAnd2Vla3MnKS5zdWJ0cmFjdCg2LCAnZGF5cycpLmZvcm1hdCgnREQuTU0uWVlZWScpO1xuICAgICAgICAgICAgICAgIGVuZERhdGUgPSBkYXlqcygpLmFkZCh0aGlzLmN1cnJlbnRQZXJpb2QsICd3ZWVrcycpLmZvcm1hdCgnREQuTU0uWVlZWScpO1xuICAgICAgICAgICAgICAgIHRoaXMuY2hhcnRUaW1lID0gc3RhcnREYXRlICsgJyAtICcgKyBlbmREYXRlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBTcGFuVHlwZS5NT05USDpcbiAgICAgICAgICAgICAgICBzdGFydERhdGUgPSBkYXlqcygpLnN1YnRyYWN0KDEgLSB0aGlzLmN1cnJlbnRQZXJpb2QsICdtb250aHMnKTtcbiAgICAgICAgICAgICAgICBlbmREYXRlID0gZGF5anMoKS5zdWJ0cmFjdCgtdGhpcy5jdXJyZW50UGVyaW9kLCAnbW9udGhzJyk7XG4gICAgICAgICAgICAgICAgdGhpcy5iYXJDaGFydExhYmVscyA9IHRoaXMuZ2V0TGFiZWxzRm9yTW9udGgoZW5kRGF0ZS5kaWZmKHN0YXJ0RGF0ZSwgJ2RheXMnKSk7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGFydFRpbWUgPSBub3dcbiAgICAgICAgICAgICAgICAgICAgLmFkZCh0aGlzLmN1cnJlbnRQZXJpb2QsICdtb250aHMnKVxuICAgICAgICAgICAgICAgICAgICAuc3VidHJhY3QoTWF0aC5mbG9vcih0aGlzLmJhckNoYXJ0TGFiZWxzLmxlbmd0aCAvIDIuMCkgLSAxLCAnZGF5cycpXG4gICAgICAgICAgICAgICAgICAgIC5mb3JtYXQoJ01NTU0gWVlZWScpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBTcGFuVHlwZS5RVUFSVEVSOlxuICAgICAgICAgICAgICAgIHN0YXJ0RGF0ZSA9IGRheWpzKCkuc3VidHJhY3QoMTEgKyAxMiAqIC10aGlzLmN1cnJlbnRQZXJpb2QsICd3ZWVrcycpO1xuICAgICAgICAgICAgICAgIGVuZERhdGUgPSB0aGlzLmN1cnJlbnRQZXJpb2QgIT09IDAgPyBkYXlqcygpLnN1YnRyYWN0KDEyICogLXRoaXMuY3VycmVudFBlcmlvZCwgJ3dlZWtzJykgOiBkYXlqcygpO1xuXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRXZWVrO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgMTI7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICBjdXJyZW50V2VlayA9IGRheWpzKClcbiAgICAgICAgICAgICAgICAgICAgICAgIC5zdWJ0cmFjdCgxMSArIDEyICogLXRoaXMuY3VycmVudFBlcmlvZCAtIGksICd3ZWVrcycpXG4gICAgICAgICAgICAgICAgICAgICAgICAuaXNvV2Vla2RheSgxKVxuICAgICAgICAgICAgICAgICAgICAgICAgLmlzb1dlZWsoKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5iYXJDaGFydExhYmVsc1tpXSA9IHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KCdjYWxlbmRhcl93ZWVrJykgKyAnICcgKyBjdXJyZW50V2VlaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5jaGFydFRpbWUgPSBzdGFydERhdGUuaXNvV2Vla2RheSgxKS5mb3JtYXQoJ0RELk1NLllZWVknKSArICcgLSAnICsgZW5kRGF0ZS5pc29XZWVrZGF5KDcpLmZvcm1hdCgnREQuTU0uWVlZWScpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBTcGFuVHlwZS5ZRUFSOlxuICAgICAgICAgICAgICAgIHRoaXMuYmFyQ2hhcnRMYWJlbHMgPSB0aGlzLmdldE1vbnRocygpO1xuICAgICAgICAgICAgICAgIHRoaXMuY2hhcnRUaW1lID0gbm93LmFkZCh0aGlzLmN1cnJlbnRQZXJpb2QsICd5ZWFycycpLnN1YnRyYWN0KDUsICdtb250aHMnKS5mb3JtYXQoJ1lZWVknKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgZ2V0TW9udGhzKCk6IHN0cmluZ1tdIHtcbiAgICAgICAgY29uc3QgY3VycmVudE1vbnRoID0gZGF5anMoKS5tb250aCgpO1xuICAgICAgICBjb25zdCB5ZWFyID0gW1xuICAgICAgICAgICAgdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQoJ21vbnRocy5qYW51YXJ5JyksXG4gICAgICAgICAgICB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnbW9udGhzLmZlYnJ1YXJ5JyksXG4gICAgICAgICAgICB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnbW9udGhzLm1hcmNoJyksXG4gICAgICAgICAgICB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnbW9udGhzLmFwcmlsJyksXG4gICAgICAgICAgICB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnbW9udGhzLm1heScpLFxuICAgICAgICAgICAgdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQoJ21vbnRocy5qdW5lJyksXG4gICAgICAgICAgICB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnbW9udGhzLmp1bHknKSxcbiAgICAgICAgICAgIHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KCdtb250aHMuYXVndXN0JyksXG4gICAgICAgICAgICB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnbW9udGhzLnNlcHRlbWJlcicpLFxuICAgICAgICAgICAgdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQoJ21vbnRocy5vY3RvYmVyJyksXG4gICAgICAgICAgICB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnbW9udGhzLm5vdmVtYmVyJyksXG4gICAgICAgICAgICB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnbW9udGhzLmRlY2VtYmVyJyksXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGJhY2sgPSB5ZWFyLnNsaWNlKGN1cnJlbnRNb250aCArIDEsIHllYXIubGVuZ3RoKTtcbiAgICAgICAgY29uc3QgZnJvbnQgPSB5ZWFyLnNsaWNlKDAsIGN1cnJlbnRNb250aCArIDEpO1xuICAgICAgICByZXR1cm4gYmFjay5jb25jYXQoZnJvbnQpO1xuICAgIH1cblxuICAgIHByaXZhdGUgZ2V0TGFiZWxzRm9yTW9udGgoZGF5c0luTW9udGg6IG51bWJlcik6IHN0cmluZ1tdIHtcbiAgICAgICAgY29uc3QgZGF5czogc3RyaW5nW10gPSBbXTtcblxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRheXNJbk1vbnRoOyBpKyspIHtcbiAgICAgICAgICAgIGRheXMucHVzaChcbiAgICAgICAgICAgICAgICBkYXlqcygpXG4gICAgICAgICAgICAgICAgICAgIC5zdWJ0cmFjdCgtdGhpcy5jdXJyZW50UGVyaW9kLCAnbW9udGhzJylcbiAgICAgICAgICAgICAgICAgICAgLnN1YnRyYWN0KGRheXNJbk1vbnRoIC0gMSAtIGksICdkYXlzJylcbiAgICAgICAgICAgICAgICAgICAgLmZvcm1hdCgnREQuTU0nKSxcbiAgICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGRheXM7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBnZXRXZWVrZGF5cygpOiBzdHJpbmdbXSB7XG4gICAgICAgIGNvbnN0IGN1cnJlbnREYXkgPSBkYXlqcygpLmRheSgpO1xuICAgICAgICBjb25zdCBkYXlzID0gW1xuICAgICAgICAgICAgdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQoJ3dlZWtkYXlzLm1vbmRheScpLFxuICAgICAgICAgICAgdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQoJ3dlZWtkYXlzLnR1ZXNkYXknKSxcbiAgICAgICAgICAgIHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KCd3ZWVrZGF5cy53ZWRuZXNkYXknKSxcbiAgICAgICAgICAgIHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KCd3ZWVrZGF5cy50aHVyc2RheScpLFxuICAgICAgICAgICAgdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQoJ3dlZWtkYXlzLmZyaWRheScpLFxuICAgICAgICAgICAgdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQoJ3dlZWtkYXlzLnNhdHVyZGF5JyksXG4gICAgICAgICAgICB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnd2Vla2RheXMuc3VuZGF5JyksXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGJhY2sgPSBkYXlzLnNsaWNlKGN1cnJlbnREYXksIGRheXMubGVuZ3RoKTtcbiAgICAgICAgY29uc3QgZnJvbnQgPSBkYXlzLnNsaWNlKDAsIGN1cnJlbnREYXkpO1xuICAgICAgICByZXR1cm4gYmFjay5jb25jYXQoZnJvbnQpO1xuICAgIH1cblxuICAgIHB1YmxpYyBzd2l0Y2hUaW1lU3BhbihpbmRleDogYm9vbGVhbik6IHZvaWQge1xuICAgICAgICBpbmRleCA/ICh0aGlzLmN1cnJlbnRQZXJpb2QgKz0gMSkgOiAodGhpcy5jdXJyZW50UGVyaW9kIC09IDEpO1xuICAgICAgICB0aGlzLmluaXRpYWxpemVDaGFydCgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENvbnZlcnRzIHRoZSBkYXRhIHJldHJpZXZlZCBmcm9tIHRoZSBzZXJ2aWNlIHRvIGRlZGljYXRlZCBvYmplY3RzIHRoYXQgY2FuIGJlIGludGVycHJldGVkIGJ5IG5neC1jaGFydHNcbiAgICAgKiBhbmQgcHVzaGVzIHRoZW0gdG8gbmd4RGF0YS5cbiAgICAgKiBUaGVuLCBjb21wdXRlcyB0aGUgdXBwZXIgbGltaXQgZm9yIHRoZSB5LWF4aXMgb2YgdGhlIGNoYXJ0LlxuICAgICAqL1xuICAgIHByaXZhdGUgcHVzaFRvRGF0YSgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5uZ3hEYXRhID0gdGhpcy5kYXRhRm9yU3BhblR5cGUubWFwKChzY29yZSwgaW5kZXgpID0+ICh7IG5hbWU6IHRoaXMuYmFyQ2hhcnRMYWJlbHNbaW5kZXhdLCB2YWx1ZTogc2NvcmUgfSkpO1xuICAgICAgICB0aGlzLnlTY2FsZU1heCA9IE1hdGgubWF4KDMsIC4uLnRoaXMuZGF0YUZvclNwYW5UeXBlKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIYW5kbGVzIHRoZSB1cGRhdGUgb2YgdGhlIGRhdGEgbGFiZWxzIGlmIHRoZSB1c2VyIGNoYW5nZXMgdGhlIHN5c3RlbSBsYW5ndWFnZVxuICAgICAqL1xuICAgIHByaXZhdGUgb25TeXN0ZW1MYW5ndWFnZUNoYW5nZSgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5jcmVhdGVMYWJlbHMoKTtcbiAgICAgICAgdGhpcy5uZ3hEYXRhLmZvckVhY2goKGRhdGFQYWNrLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgZGF0YVBhY2submFtZSA9IHRoaXMuYmFyQ2hhcnRMYWJlbHNbaW5kZXhdO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5uZ3hEYXRhID0gWy4uLnRoaXMubmd4RGF0YV07XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInJvdyBkLWZsZXgganVzdGlmeS1jb250ZW50LWNlbnRlclwiPlxuICAgIDxkaXY+XG4gICAgICAgIDxoMz57eyBjaGFydE5hbWUgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9oMz5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQXJyb3dMZWZ0XCIgc2l6ZT1cIjJ4XCIgY2xhc3M9XCJjb2wtMSBkLWZsZXgganVzdGlmeS1jb250ZW50LWVuZCBhbGlnbi1pdGVtcy1jZW50ZXIgcHgtMFwiIHJvbGU9XCJidXR0b25cIiAoY2xpY2spPVwic3dpdGNoVGltZVNwYW4oTEVGVClcIj48L2ZhLWljb24+XG4gICAgICAgIDxkaXYgI2NvbnRhaW5lclJlZiBjbGFzcz1cImNoYXJ0IGNvbC0xMCBweC0wXCI+XG4gICAgICAgICAgICA8bmd4LWNoYXJ0cy1iYXItdmVydGljYWxcbiAgICAgICAgICAgICAgICBbdmlld109XCJbY29udGFpbmVyUmVmLm9mZnNldFdpZHRoLCAyNTBdXCJcbiAgICAgICAgICAgICAgICBbcmVzdWx0c109XCJuZ3hEYXRhXCJcbiAgICAgICAgICAgICAgICBbc2NoZW1lXT1cIm5neENvbG9yXCJcbiAgICAgICAgICAgICAgICBbeEF4aXNdPVwidHJ1ZVwiXG4gICAgICAgICAgICAgICAgW3lBeGlzXT1cInRydWVcIlxuICAgICAgICAgICAgICAgIFtzaG93RGF0YUxhYmVsXT1cInRydWVcIlxuICAgICAgICAgICAgICAgIFt5U2NhbGVNYXhdPVwieVNjYWxlTWF4XCJcbiAgICAgICAgICAgICAgICBbeUF4aXNUaWNrRm9ybWF0dGluZ109XCJ5QXhpc1RpY2tGb3JtYXR0aW5nXCJcbiAgICAgICAgICAgICAgICBbYW5pbWF0aW9uc109XCJmYWxzZVwiXG4gICAgICAgICAgICAgICAgW3JvdW5kRWRnZXNdPVwiZmFsc2VcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSAjdG9vbHRpcFRlbXBsYXRlIGxldC1tb2RlbD1cIm1vZGVsXCI+XG4gICAgICAgICAgICAgICAgICAgIDxiPnt7IG1vZGVsLm5hbWUgfX08L2I+IDxiciAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyB0b29sdGlwVHJhbnNsYXRpb24gfCBhcnRlbWlzVHJhbnNsYXRlIH19OiB7eyBtb2RlbC52YWx1ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgPC9uZ3gtY2hhcnRzLWJhci12ZXJ0aWNhbD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQXJyb3dSaWdodFwiIHNpemU9XCIyeFwiIGNsYXNzPVwiY29sLTEgZC1mbGV4IGp1c3RpZnktY29udGVudC1zdGFydCBhbGlnbi1pdGVtcy1jZW50ZXIgcHgtMFwiIHJvbGU9XCJidXR0b25cIiAoY2xpY2spPVwic3dpdGNoVGltZVNwYW4oUklHSFQpXCI+PC9mYS1pY29uPlxuICAgIDwvZGl2PlxuPC9kaXY+XG48aDQgY2xhc3M9XCJjb2wteGwtOSBvZmZzZXQteGwtMiB0ZXh0LWNlbnRlciBtdC0zIG1iLTVcIj57eyBjaGFydFRpbWUgfX08L2g0PlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyByb3VuZCB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC91dGlscyc7XG5pbXBvcnQgeyBHcmFwaENvbG9ycyB9IGZyb20gJ2FwcC9lbnRpdGllcy9zdGF0aXN0aWNzLm1vZGVsJztcbmltcG9ydCB7IGF4aXNUaWNrRm9ybWF0dGluZ1dpdGhQZXJjZW50YWdlU2lnbiB9IGZyb20gJ2FwcC9zaGFyZWQvc3RhdGlzdGljcy1ncmFwaC9zdGF0aXN0aWNzLWdyYXBoLnV0aWxzJztcbmltcG9ydCB7IENvbG9yLCBTY2FsZVR5cGUgfSBmcm9tICdAc3dpbWxhbmUvbmd4LWNoYXJ0cyc7XG5pbXBvcnQgeyBFeGVyY2lzZVR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgQXJ0ZW1pc05hdmlnYXRpb25VdGlsU2VydmljZSB9IGZyb20gJ2FwcC91dGlscy9uYXZpZ2F0aW9uLnV0aWxzJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktc3RhdGlzdGljcy1zY29yZS1kaXN0cmlidXRpb24tZ3JhcGgnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9zdGF0aXN0aWNzLXNjb3JlLWRpc3RyaWJ1dGlvbi1ncmFwaC5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4uL2NoYXJ0L3ZlcnRpY2FsLWJhci1jaGFydC5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIFN0YXRpc3RpY3NTY29yZURpc3RyaWJ1dGlvbkdyYXBoQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICBASW5wdXQoKVxuICAgIGF2ZXJhZ2VTY29yZU9mRXhlcmNpc2U6IG51bWJlciB8IHVuZGVmaW5lZDtcbiAgICBASW5wdXQoKVxuICAgIHNjb3JlRGlzdHJpYnV0aW9uOiBudW1iZXJbXSB8IHVuZGVmaW5lZDtcbiAgICBASW5wdXQoKVxuICAgIG51bWJlck9mRXhlcmNpc2VTY29yZXM6IG51bWJlciB8IHVuZGVmaW5lZDtcbiAgICBASW5wdXQoKVxuICAgIGV4ZXJjaXNlVHlwZTogRXhlcmNpc2VUeXBlO1xuICAgIEBJbnB1dCgpXG4gICAgY291cnNlSWQ6IG51bWJlcjtcbiAgICBASW5wdXQoKVxuICAgIGV4ZXJjaXNlSWQ6IG51bWJlcjtcblxuICAgIC8vIG5neFxuICAgIG5neERhdGE6IGFueVtdID0gW107XG4gICAgbmd4Q29sb3I6IENvbG9yID0ge1xuICAgICAgICBuYW1lOiAnU3RhdGlzdGljcycsXG4gICAgICAgIHNlbGVjdGFibGU6IHRydWUsXG4gICAgICAgIGdyb3VwOiBTY2FsZVR5cGUuT3JkaW5hbCxcbiAgICAgICAgZG9tYWluOiBbR3JhcGhDb2xvcnMuREFSS19CTFVFXSxcbiAgICB9O1xuICAgIHlBeGlzVGlja0Zvcm1hdHRpbmcgPSBheGlzVGlja0Zvcm1hdHRpbmdXaXRoUGVyY2VudGFnZVNpZ247XG5cbiAgICAvLyBEYXRhXG4gICAgYmFyQ2hhcnRMYWJlbHM6IHN0cmluZ1tdID0gW107XG4gICAgcmVsYXRpdmVDaGFydERhdGE6IG51bWJlcltdID0gW107XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIG5hdmlnYXRpb25TZXJ2aWNlOiBBcnRlbWlzTmF2aWdhdGlvblV0aWxTZXJ2aWNlKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuaW5pdGlhbGl6ZUNoYXJ0KCk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBpbml0aWFsaXplQ2hhcnQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuYmFyQ2hhcnRMYWJlbHMgPSBbJ1swLCAxMCknLCAnWzEwLCAyMCknLCAnWzIwLCAzMCknLCAnWzMwLCA0MCknLCAnWzQwLCA1MCknLCAnWzUwLCA2MCknLCAnWzYwLCA3MCknLCAnWzcwLCA4MCknLCAnWzgwLCA5MCknLCAnWzkwLCAxMDBdJ107XG4gICAgICAgIGlmICh0aGlzLm51bWJlck9mRXhlcmNpc2VTY29yZXMgJiYgdGhpcy5udW1iZXJPZkV4ZXJjaXNlU2NvcmVzID4gMCkge1xuICAgICAgICAgICAgdGhpcy5yZWxhdGl2ZUNoYXJ0RGF0YSA9IFtdO1xuICAgICAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiB0aGlzLnNjb3JlRGlzdHJpYnV0aW9uISkge1xuICAgICAgICAgICAgICAgIHRoaXMucmVsYXRpdmVDaGFydERhdGEucHVzaChyb3VuZCgodmFsdWUgKiAxMDApIC8gdGhpcy5udW1iZXJPZkV4ZXJjaXNlU2NvcmVzKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnJlbGF0aXZlQ2hhcnREYXRhID0gbmV3IEFycmF5KDEwKS5maWxsKDApO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubmd4RGF0YSA9IHRoaXMucmVsYXRpdmVDaGFydERhdGEubWFwKChkYXRhLCBpbmRleCkgPT4gKHsgbmFtZTogdGhpcy5iYXJDaGFydExhYmVsc1tpbmRleF0sIHZhbHVlOiBkYXRhIH0pKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBGaW5kcyBnaXZlbiB0aGUgZGlzdHJpYnV0aW9uIGJ1Y2tldCB0aGUgY29ycmVzcG9uZGluZyBhYnNvbHV0ZSB2YWx1ZVxuICAgICAqIEBwYXJhbSBidWNrZXQgdGhlIGRpc3RyaWJ1dGlvbiBidWNrZXQgdG8gZGV0ZXJtaW5lIHRoZSBhYnNvbHV0ZSBWYWx1ZSBmb3JcbiAgICAgKiBAcmV0dXJucyBhbW91bnQgb2Ygc3VibWlzc2lvbnMgdGhhdCBhY2hpZXZlZCBhIHNjb3JlIGluIHRoZSBidWNrZXRzIHJhbmdlXG4gICAgICovXG4gICAgbG9va1VwQWJzb2x1dGVWYWx1ZShidWNrZXQ6IHN0cmluZykge1xuICAgICAgICBjb25zdCBpbmRleCA9IHRoaXMuYmFyQ2hhcnRMYWJlbHMuaW5kZXhPZihidWNrZXQpO1xuICAgICAgICByZXR1cm4gdGhpcy5zY29yZURpc3RyaWJ1dGlvbiFbaW5kZXhdO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEhhbmRsZXMgdGhlIGV2ZW50IGlmIGEgdXNlciBjbGlja3Mgb24gYSBjZXJ0YWluIGNoYXJ0IGJhclxuICAgICAqIEBwYXJhbSBldmVudCB0aGUgZXZlbnQgcGFzc2VkIGJ5IG5neC1jaGFydHNcbiAgICAgKi9cbiAgICBzZWxlY3RDaGFydEJhcihldmVudDogYW55KTogdm9pZCB7XG4gICAgICAgIGNvbnN0IGluZGV4ID0gdGhpcy5iYXJDaGFydExhYmVscy5pbmRleE9mKGV2ZW50Lm5hbWUpO1xuICAgICAgICBjb25zdCByb3V0ZSA9IFtgL2NvdXJzZS1tYW5hZ2VtZW50LyR7dGhpcy5jb3Vyc2VJZH0vJHt0aGlzLmV4ZXJjaXNlVHlwZX0tZXhlcmNpc2VzLyR7dGhpcy5leGVyY2lzZUlkfS9zY29yZXNgXTtcbiAgICAgICAgdGhpcy5uYXZpZ2F0aW9uU2VydmljZS5yb3V0ZUluTmV3VGFiKHJvdXRlLCB7IHF1ZXJ5UGFyYW1zOiB7IHNjb3JlUmFuZ2VGaWx0ZXI6IGluZGV4IH0gfSk7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInJvdyBtYi0zXCI+XG4gICAgPGRpdiBjbGFzcz1cImNvbC14bC0yXCI+XG4gICAgICAgIDxoMz57eyAnc3RhdGlzdGljcy5zY29yZV9kaXN0cmlidXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvaDM+XG4gICAgPC9kaXY+XG4gICAgPGRpdiAjY29udGFpbmVyUmVmIGNsYXNzPVwiY29sLXhsLTlcIj5cbiAgICAgICAgPG5neC1jaGFydHMtYmFyLXZlcnRpY2FsXG4gICAgICAgICAgICBbcm91bmRFZGdlc109XCJmYWxzZVwiXG4gICAgICAgICAgICBbdmlld109XCJbY29udGFpbmVyUmVmLm9mZnNldFdpZHRoLCAyNTBdXCJcbiAgICAgICAgICAgIFtyZXN1bHRzXT1cIm5neERhdGFcIlxuICAgICAgICAgICAgW3NjaGVtZV09XCJuZ3hDb2xvclwiXG4gICAgICAgICAgICBbeEF4aXNdPVwidHJ1ZVwiXG4gICAgICAgICAgICBbeUF4aXNdPVwidHJ1ZVwiXG4gICAgICAgICAgICBbeVNjYWxlTWF4XT1cIjEwMFwiXG4gICAgICAgICAgICBbc2hvd0RhdGFMYWJlbF09XCJ0cnVlXCJcbiAgICAgICAgICAgIFt5QXhpc1RpY2tGb3JtYXR0aW5nXT1cInlBeGlzVGlja0Zvcm1hdHRpbmdcIlxuICAgICAgICAgICAgKHNlbGVjdCk9XCJzZWxlY3RDaGFydEJhcigkZXZlbnQpXCJcbiAgICAgICAgPlxuICAgICAgICAgICAgPG5nLXRlbXBsYXRlICN0b29sdGlwVGVtcGxhdGUgbGV0LW1vZGVsPVwibW9kZWxcIj5cbiAgICAgICAgICAgICAgICA8Yj57eyBtb2RlbC5uYW1lIH19PC9iPiA8YnIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj57eyBsb29rVXBBYnNvbHV0ZVZhbHVlKG1vZGVsLm5hbWUpIH19PC9zcGFuPlxuICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgPC9uZ3gtY2hhcnRzLWJhci12ZXJ0aWNhbD5cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsaUJBQW9DO0FBQzdDLFNBQVMsc0JBQXNCO0FBVy9CLFNBQVMsWUFBWSxhQUFhLE9BQU8sUUFBUSxXQUFXLFNBQVMsU0FBUyxnQkFBZ0I7Ozs7O0FDR2xFLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsdUJBQUEsR0FBQSxvQ0FBQSxDQUFBO0FBUUosSUFBQSxvQkFBQSxHQUFBLDRCQUFBOzs7O0FBTlEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxVQUFBLE9BQUEsTUFBQSxFQUFpQixlQUFBLE9BQUEsa0JBQUEsVUFBQSxFQUFBLHFCQUFBLE9BQUEsYUFBQSxPQUFBLE9BQUEsT0FBQSxVQUFBLDJCQUFBLEVBQUEsbUJBQUEsT0FBQSxhQUFBLE9BQUEsT0FBQSxPQUFBLFVBQUEseUJBQUEsRUFBQSxjQUFBLE9BQUEsYUFBQSxPQUFBLE9BQUEsT0FBQSxVQUFBLG9CQUFBOzs7OztBQVFyQixJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsb0NBQUEsQ0FBQTtBQVFKLElBQUEsb0JBQUEsR0FBQSw0QkFBQTs7OztBQU5RLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsVUFBQSxPQUFBLE1BQUEsRUFBaUIsZUFBQSxPQUFBLGtCQUFBLFFBQUEsRUFBQSxxQkFBQSxPQUFBLGFBQUEsT0FBQSxPQUFBLE9BQUEsVUFBQSw4QkFBQSxFQUFBLG1CQUFBLE9BQUEsYUFBQSxPQUFBLE9BQUEsT0FBQSxVQUFBLDRCQUFBLEVBQUEsY0FBQSxPQUFBLGFBQUEsT0FBQSxPQUFBLE9BQUEsVUFBQSx1QkFBQTs7Ozs7QUEwQ3JCLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBMkQsSUFBQSxvQkFBQSxDQUFBO0FBQXVCLElBQUEsMEJBQUE7QUFDdEYsSUFBQSxvQkFBQSxHQUFBLDRCQUFBOzs7O0FBRCtELElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsaUJBQUEsSUFBQTs7Ozs7QUFIbkUsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUEsRUFBSSxHQUFBLFFBQUEsRUFBQTtBQUFxRCxJQUFBLG9CQUFBLEdBQUEsc0JBQUE7QUFBb0IsSUFBQSwwQkFBQSxFQUFPO0FBQ3BGLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsbUVBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSxzQ0FBQTtBQUdKLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsb0JBQUE7Ozs7QUFKUSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLE9BQUEsT0FBQSxhQUFBOzs7OztBQVVKLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUEsRUFBSSxHQUFBLFFBQUEsRUFBQTtBQUF3RCxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBa0IsSUFBQSwwQkFBQSxFQUFPO0FBQ3JGLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxFQUFBO0FBQTZELElBQUEsMEJBQUE7QUFFckUsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLEVBQUE7QUFBa0UsSUFBQSxvQkFBQSxJQUFBLCtCQUFBO0FBQTZCLElBQUEsMEJBQUEsRUFBTztBQUMxRyxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsRUFBQTtBQUFpRixJQUFBLDBCQUFBO0FBRXpGLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxFQUFBO0FBQXVELElBQUEsb0JBQUEsSUFBQSxtQkFBQTtBQUFpQixJQUFBLDBCQUFBLEVBQU87QUFDbkYsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxLQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEVBQUE7QUFBMkQsSUFBQSwwQkFBQTtBQUVuRSxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUEsRUFBSSxJQUFBLFFBQUEsRUFBQTtBQUEyRCxJQUFBLG9CQUFBLElBQUEsdUJBQUE7QUFBcUIsSUFBQSwwQkFBQSxFQUFPO0FBQzNGLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsS0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxFQUFBO0FBQW1FLElBQUEsMEJBQUE7QUFFM0UsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7Ozs7QUF2QmUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxjQUFBLDZCQUFBLElBQUEsS0FBQSxPQUFBLE9BQUEsRUFBQSxDQUFBO0FBQ0MsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxzQ0FBQSxPQUFBLE9BQUEsa0JBQUEsTUFBQSxPQUFBLE9BQUEsa0JBQUEsR0FBQTtBQUtELElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsY0FBQSw2QkFBQSxJQUFBLEtBQUEsT0FBQSxPQUFBLEVBQUEsQ0FBQTtBQUNDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsc0NBQUEsT0FBQSxPQUFBLDRCQUFBLE1BQUEsT0FBQSxPQUFBLDRCQUFBLEdBQUE7QUFLRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGNBQUEsNkJBQUEsSUFBQSxLQUFBLE9BQUEsT0FBQSxFQUFBLENBQUE7QUFDQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLHNDQUFBLE9BQUEsT0FBQSxpQkFBQSxNQUFBLE9BQUEsT0FBQSxpQkFBQSxHQUFBO0FBS0QsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxjQUFBLDZCQUFBLElBQUEsS0FBQSxPQUFBLE9BQUEsRUFBQSxDQUFBO0FBQ0MsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxzQ0FBQSxPQUFBLE9BQUEscUJBQUEsTUFBQSxPQUFBLE9BQUEscUJBQUEsR0FBQTs7Ozs7QUFLWixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBLEVBQUksR0FBQSxRQUFBLEVBQUE7QUFBd0QsSUFBQSxvQkFBQSxHQUFBLG9CQUFBO0FBQWtCLElBQUEsMEJBQUEsRUFBTztBQUNyRixJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxFQUFBO0FBQTZCLElBQUEsMEJBQUE7QUFDdkMsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLEVBQUE7QUFBa0UsSUFBQSxvQkFBQSxJQUFBLCtCQUFBO0FBQTZCLElBQUEsMEJBQUEsRUFBTztBQUMxRyxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxFQUFBO0FBQXVDLElBQUEsMEJBQUE7QUFDakQsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLEVBQUE7QUFBdUQsSUFBQSxvQkFBQSxJQUFBLG1CQUFBO0FBQWlCLElBQUEsMEJBQUEsRUFBTztBQUNuRixJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxFQUFBO0FBQTRCLElBQUEsMEJBQUE7QUFDdEMsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLEVBQUE7QUFBMkQsSUFBQSxvQkFBQSxJQUFBLHVCQUFBO0FBQXFCLElBQUEsMEJBQUEsRUFBTztBQUMzRixJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxFQUFBO0FBQWdDLElBQUEsMEJBQUE7QUFDMUMsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7Ozs7QUFma0IsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSwrQkFBQSxPQUFBLE9BQUEsZ0JBQUE7QUFJQSxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsT0FBQSwwQkFBQTtBQUlBLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsK0JBQUEsT0FBQSxPQUFBLGVBQUE7QUFJQSxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsT0FBQSxtQkFBQTs7Ozs7QUFtQ1YsSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLENBQUE7O0FBQTZDLElBQUEsMEJBQUE7QUFDdkQsSUFBQSxvQkFBQSxHQUFBLHdCQUFBOzs7QUFEVSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLEdBQUEsR0FBQSxvQkFBQSxDQUFBOzs7OztBQUdOLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxDQUFBOztBQUE0QyxJQUFBLDBCQUFBO0FBQ3RELElBQUEsb0JBQUEsR0FBQSx3QkFBQTs7O0FBRFUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxHQUFBLEdBQUEsbUJBQUEsQ0FBQTs7Ozs7QUFPRixJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsQ0FBQTs7QUFBNkMsSUFBQSwwQkFBQTtBQUN2RCxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7OztBQURVLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsR0FBQSxHQUFBLG9CQUFBLENBQUE7Ozs7O0FBR04sSUFBQSxvQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLENBQUE7O0FBQTRDLElBQUEsMEJBQUE7QUFDdEQsSUFBQSxvQkFBQSxHQUFBLDRCQUFBOzs7QUFEVSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLEdBQUEsR0FBQSxtQkFBQSxDQUFBOzs7OztBQU5kLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBLEVBQUksR0FBQSxRQUFBLEVBQUE7QUFBMEQsSUFBQSxvQkFBQSxHQUFBLGVBQUE7QUFBYSxJQUFBLDBCQUFBLEVBQU87QUFDbEYsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSw0RUFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLDRFQUFBLEdBQUEsQ0FBQTtBQUlMLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsb0JBQUE7Ozs7QUFQUSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLEdBQUEsT0FBQSxPQUFBLGVBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLENBQUEsT0FBQSxPQUFBLGVBQUEsSUFBQSxFQUFBOzs7OztBQU1KLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUEwRSxJQUFBLG9CQUFBLEdBQUEsbUJBQUE7QUFBaUIsSUFBQSwwQkFBQTtBQUMvRixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLG9CQUFBOzs7O0FBRlcsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxjQUFBLDZCQUFBLEdBQUEsS0FBQSxPQUFBLFVBQUEsT0FBQSxPQUFBLE9BQUEsT0FBQSxFQUFBLENBQUE7Ozs7O0FBSVAsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUEsRUFBSSxHQUFBLFFBQUEsRUFBQTtBQUEyRCxJQUFBLG9CQUFBLEdBQUEsa0JBQUE7QUFBZ0IsSUFBQSwwQkFBQSxFQUFPO0FBQ3RGLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsQ0FBQTs7QUFBdUQsSUFBQSwwQkFBQTtBQUNqRSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUEsRUFBSSxJQUFBLFFBQUEsRUFBQTtBQUF5RCxJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBYyxJQUFBLDBCQUFBLEVBQU87QUFDbEYsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxFQUFBOztBQUFxRCxJQUFBLDBCQUFBO0FBQy9ELElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxFQUFBO0FBQXVFLElBQUEsb0JBQUEsSUFBQSxtQ0FBQTtBQUFpQyxJQUFBLDBCQUFBLEVBQU87QUFDbkgsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLE1BQUEsRUFBQTs7QUFLSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7Ozs7QUFaYyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLEdBQUEsR0FBQSxRQUFBLE9BQUEsbUJBQUEsS0FBQSxHQUFBO0FBSUEsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxJQUFBLEdBQUEsUUFBQSxPQUFBLGlCQUFBLEtBQUEsR0FBQTtBQU1OLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsYUFBQSx5QkFBQSxJQUFBLEdBQUEsUUFBQSxPQUFBLDZCQUFBLEdBQUEsMkJBQUE7Ozs7O0FBSUosSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUEsRUFBSSxHQUFBLFFBQUEsRUFBQTtBQUEyRCxJQUFBLG9CQUFBLEdBQUEseUJBQUE7QUFBdUIsSUFBQSwwQkFBQSxFQUFPO0FBQzdGLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsQ0FBQTs7QUFBdUQsSUFBQSwwQkFBQTtBQUNqRSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLG9CQUFBOzs7O0FBRmMsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxHQUFBLEdBQUEsUUFBQSxPQUFBLG1CQUFBLEtBQUEsR0FBQTs7Ozs7QUFVRixJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsQ0FBQTtBQUFxQixJQUFBLDBCQUFBO0FBQy9CLElBQUEsb0JBQUEsR0FBQSw0QkFBQTs7OztBQURVLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsUUFBQSxPQUFBLFFBQUE7Ozs7O0FBR04sSUFBQSxvQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLENBQUE7O0FBQStDLElBQUEsMEJBQUE7QUFDekQsSUFBQSxvQkFBQSxHQUFBLDRCQUFBOzs7QUFEVSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLEdBQUEsR0FBQSxzQkFBQSxDQUFBOzs7OztBQVFkLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBLEVBQUksR0FBQSxRQUFBLEVBQUE7QUFBMkQsSUFBQSxvQkFBQSxHQUFBLDBDQUFBO0FBQXdDLElBQUEsMEJBQUEsRUFBTztBQUM5RyxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLENBQUE7QUFBaUMsSUFBQSwwQkFBQTtBQUMzQyxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUEsRUFBSSxJQUFBLFFBQUEsRUFBQTtBQUErRCxJQUFBLG9CQUFBLElBQUEsdUNBQUE7QUFBcUMsSUFBQSwwQkFBQSxFQUFPO0FBQy9HLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsRUFBQTtBQUFxQyxJQUFBLDBCQUFBO0FBQy9DLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxFQUFBO0FBQWtFLElBQUEsb0JBQUEsSUFBQSxtREFBQTtBQUFpRCxJQUFBLDBCQUFBLEVBQU87QUFDOUgsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxFQUFBO0FBQXdDLElBQUEsMEJBQUE7QUFDbEQsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLEVBQUE7QUFBbUUsSUFBQSxvQkFBQSxJQUFBLDRDQUFBO0FBQTBDLElBQUEsMEJBQUEsRUFBTztBQUN4SCxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLEVBQUE7QUFBeUMsSUFBQSwwQkFBQTtBQUNuRCxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUEsRUFBSSxJQUFBLFFBQUEsRUFBQTtBQUEyRSxJQUFBLG9CQUFBLElBQUEscURBQUE7QUFBbUQsSUFBQSwwQkFBQSxFQUFPO0FBQ3pJLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsRUFBQTtBQUFpRCxJQUFBLDBCQUFBO0FBQzNELElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7Ozs7QUFsQmMsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxRQUFBLE9BQUEsaUJBQUEsR0FBQTtBQUlBLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsK0JBQUEsUUFBQSxPQUFBLHFCQUFBLEdBQUE7QUFJQSxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLCtCQUFBLFFBQUEsT0FBQSx3QkFBQSxHQUFBO0FBSUEsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSwrQkFBQSxRQUFBLE9BQUEseUJBQUEsR0FBQTtBQUlBLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsK0JBQUEsUUFBQSxPQUFBLGlDQUFBLEdBQUE7Ozs7O0FBSVYsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUEsRUFBSSxHQUFBLFFBQUEsRUFBQTtBQUE0RSxJQUFBLG9CQUFBLEdBQUEsK0RBQUE7QUFBNkQsSUFBQSwwQkFBQSxFQUFPO0FBQ3BKLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsQ0FBQTtBQUFrRCxJQUFBLDBCQUFBO0FBQzVELElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7Ozs7QUFGYyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFFBQUEsT0FBQSxrQ0FBQSxHQUFBOzs7OztBQU1OLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxDQUFBOztBQUE2QyxJQUFBLDBCQUFBO0FBQ3ZELElBQUEsb0JBQUEsR0FBQSx3QkFBQTs7O0FBRFUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxHQUFBLEdBQUEsb0JBQUEsQ0FBQTs7Ozs7QUFHTixJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsQ0FBQTs7QUFBNEMsSUFBQSwwQkFBQTtBQUN0RCxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7OztBQURVLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsR0FBQSxHQUFBLG1CQUFBLENBQUE7Ozs7O0FBTU4sSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLENBQUE7O0FBQTZDLElBQUEsMEJBQUE7QUFDdkQsSUFBQSxvQkFBQSxHQUFBLHdCQUFBOzs7QUFEVSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLEdBQUEsR0FBQSxvQkFBQSxDQUFBOzs7OztBQUdOLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxDQUFBOztBQUE0QyxJQUFBLDBCQUFBO0FBQ3RELElBQUEsb0JBQUEsR0FBQSx3QkFBQTs7O0FBRFUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxHQUFBLEdBQUEsbUJBQUEsQ0FBQTs7Ozs7QUFJVixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQSxFQUFJLEdBQUEsUUFBQSxFQUFBO0FBQWlHLElBQUEsb0JBQUEsR0FBQSwyQkFBQTtBQUF5QixJQUFBLDBCQUFBLEVBQU87QUFDckksSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx1QkFBQSxHQUFBLE1BQUEsRUFBQTs7QUFLSixJQUFBLG9CQUFBLEdBQUEsb0JBQUE7Ozs7QUFGUSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGFBQUEseUJBQUEsR0FBQSxHQUFBLFFBQUEsT0FBQSw4Q0FBQSxHQUFBLDJCQUFBOzs7OztBQUlKLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUEsRUFBSSxHQUFBLFFBQUEsRUFBQTtBQUF1RSxJQUFBLG9CQUFBLEdBQUEsV0FBQTtBQUFTLElBQUEsMEJBQUEsRUFBTztBQUMzRixJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsdUJBQUEsR0FBQSxvQkFBQSxFQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7Ozs7QUFIOEIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxVQUFBLFFBQUEsTUFBQSxFQUFpQix1QkFBQSxRQUFBLElBQUEsRUFBQSxZQUFBLENBQUEsUUFBQSxPQUFBOzs7OztBQU0zQyxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBLEVBQUksR0FBQSxRQUFBLEVBQUE7QUFBeUUsSUFBQSxvQkFBQSxHQUFBLGFBQUE7QUFBVyxJQUFBLDBCQUFBLEVBQU87QUFDL0YsSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsb0JBQUEsRUFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLG9CQUFBOzs7O0FBSDhCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsVUFBQSxRQUFBLE1BQUEsRUFBaUIsdUJBQUEsUUFBQSxNQUFBLEVBQUEsWUFBQSxDQUFBLFFBQUEsT0FBQTs7Ozs7QUFNM0MsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQSxFQUFJLEdBQUEsUUFBQSxFQUFBO0FBQTZFLElBQUEsb0JBQUEsR0FBQSxpQkFBQTtBQUFlLElBQUEsMEJBQUEsRUFBTztBQUN2RyxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsdUJBQUEsR0FBQSxvQkFBQSxFQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7Ozs7QUFIOEIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxVQUFBLFFBQUEsTUFBQSxFQUFpQix1QkFBQSxRQUFBLFdBQUEsRUFBQSxZQUFBLENBQUEsUUFBQSxPQUFBOzs7OztBQWxTdkQsSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx1QkFBQSxHQUFBLG9DQUFBLENBQUE7QUFRQSxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsNkRBQUEsR0FBQSxDQUFBLEVBU0MsSUFBQSw2REFBQSxHQUFBLENBQUE7QUFXRCxJQUFBLHVCQUFBLElBQUEsb0NBQUEsQ0FBQTtBQVFKLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLGdDQUFBLENBQUE7QUFNSixJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSx1QkFBQSxJQUFBLElBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsS0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLENBQUE7QUFBb0QsSUFBQSxvQkFBQSxJQUFBLGlCQUFBO0FBQWUsSUFBQSwwQkFBQSxFQUFPO0FBQ2xGLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHVCQUFBLElBQUEsSUFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxDQUFBO0FBQTZDLElBQUEsb0JBQUEsSUFBQSxPQUFBO0FBQUssSUFBQSwwQkFBQSxFQUFPO0FBQzdELElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsRUFBQTtBQUFrQixJQUFBLDBCQUFBO0FBQzVCLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxFQUFBO0FBQWlELElBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQVUsSUFBQSwwQkFBQSxFQUFPO0FBQ3RFLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsRUFBQTtBQUFzQixJQUFBLDBCQUFBO0FBQ2hDLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsNkRBQUEsSUFBQSxDQUFBO0FBWUEsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLDZEQUFBLElBQUEsRUFBQSxFQTJCQyxJQUFBLDZEQUFBLElBQUEsQ0FBQTtBQXdCRCxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxFQUFBO0FBQXVELElBQUEsb0JBQUEsSUFBQSx1QkFBQTtBQUFxQixJQUFBLDBCQUFBLEVBQU87QUFDdkYsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsRUFBQTtBQUE2QixJQUFBLDBCQUFBO0FBQ3ZDLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxFQUFBO0FBQXdELElBQUEsb0JBQUEsSUFBQSwwREFBQTtBQUF3RCxJQUFBLDBCQUFBLEVBQU87QUFDM0gsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsRUFBQTtBQUFvQyxJQUFBLDBCQUFBO0FBQzlDLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxFQUFBO0FBQWlELElBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQVUsSUFBQSwwQkFBQSxFQUFPO0FBQ3RFLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsRUFBQTs7QUFBNkMsSUFBQSwwQkFBQTtBQUN2RCxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLElBQUEsRUFBSSxJQUFBLFFBQUEsRUFBQTtBQUErQyxJQUFBLG9CQUFBLElBQUEsVUFBQTtBQUFRLElBQUEsMEJBQUEsRUFBTztBQUNsRSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLEVBQUE7O0FBQTJDLElBQUEsMEJBQUE7QUFDckQsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsS0FBQSxJQUFBLEVBQUksS0FBQSxRQUFBLEVBQUE7QUFBZ0QsSUFBQSxvQkFBQSxLQUFBLFVBQUE7QUFBUSxJQUFBLDBCQUFBLEVBQU87QUFDbkUsSUFBQSxvQkFBQSxLQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxLQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsS0FBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxHQUFBO0FBQTRCLElBQUEsMEJBQUE7QUFDdEMsSUFBQSxvQkFBQSxLQUFBLG9CQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsS0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsS0FBQSxJQUFBLEVBQUksS0FBQSxRQUFBLEVBQUE7QUFBa0UsSUFBQSxvQkFBQSxLQUFBLDhCQUFBO0FBQTRCLElBQUEsMEJBQUEsRUFBTztBQUN6RyxJQUFBLG9CQUFBLEtBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLEtBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxLQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxLQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLEdBQUE7QUFBOEMsSUFBQSwwQkFBQTtBQUN4RCxJQUFBLG9CQUFBLEtBQUEsb0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxLQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxLQUFBLElBQUEsRUFBSSxLQUFBLFFBQUEsRUFBQTtBQUF3RCxJQUFBLG9CQUFBLEtBQUEsYUFBQTtBQUFXLElBQUEsMEJBQUEsRUFBTztBQUM5RSxJQUFBLG9CQUFBLEtBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLEtBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxLQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxLQUFBLDhEQUFBLEdBQUEsQ0FBQSxFQUVDLEtBQUEsOERBQUEsR0FBQSxDQUFBO0FBSUwsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsS0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsS0FBQSw4REFBQSxJQUFBLENBQUEsRUFVQyxLQUFBLDhEQUFBLEdBQUEsQ0FBQSxFQUFBLEtBQUEsOERBQUEsSUFBQSxDQUFBLEVBQUEsS0FBQSw4REFBQSxJQUFBLENBQUE7QUE0QkQsSUFBQSxxQ0FBQSxLQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEtBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEtBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsS0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsS0FBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxHQUFBOztBQUFrRixJQUFBLDBCQUFBO0FBQ3hGLElBQUEsb0JBQUEsS0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsS0FBQSxRQUFBLEVBQUE7QUFBc0QsSUFBQSxvQkFBQSxLQUFBLE1BQUE7QUFBSSxJQUFBLDBCQUFBO0FBQzlELElBQUEsb0JBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLEtBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLEtBQUEsSUFBQTtBQUNJLElBQUEsb0JBQUEsS0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsS0FBQSw4REFBQSxHQUFBLENBQUEsRUFFQyxLQUFBLDhEQUFBLEdBQUEsQ0FBQTtBQUlELElBQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUE7O0FBQ0osSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLEtBQUEsb0JBQUE7QUFBQSxJQUFBLG1DQUFBO0FBQ0EsSUFBQSxvQkFBQSxLQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxLQUFBLDhEQUFBLElBQUEsQ0FBQSxFQXFCQyxLQUFBLDhEQUFBLElBQUEsQ0FBQTtBQU9ELElBQUEsNEJBQUEsS0FBQSxJQUFBLEVBQUksS0FBQSxRQUFBLEVBQUE7QUFBNkYsSUFBQSxvQkFBQSxLQUFBLHVCQUFBO0FBQXFCLElBQUEsMEJBQUEsRUFBTztBQUM3SCxJQUFBLG9CQUFBLEtBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLEtBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxLQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxLQUFBLDhEQUFBLEdBQUEsQ0FBQSxFQUVDLEtBQUEsOERBQUEsR0FBQSxDQUFBO0FBSUwsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsS0FBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUEsS0FBQSxJQUFBLEVBQUksS0FBQSxRQUFBLEVBQUE7QUFBeUYsSUFBQSxvQkFBQSxLQUFBLG1CQUFBO0FBQWlCLElBQUEsMEJBQUEsRUFBTztBQUNySCxJQUFBLG9CQUFBLEtBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLEtBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxLQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxLQUFBLDhEQUFBLEdBQUEsQ0FBQSxFQUVDLEtBQUEsOERBQUEsR0FBQSxDQUFBO0FBSUwsSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsS0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsS0FBQSw4REFBQSxHQUFBLENBQUEsRUFPQyxLQUFBLDhEQUFBLElBQUEsQ0FBQTtBQVVELElBQUEsb0JBQUEsS0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsS0FBQSw4REFBQSxJQUFBLENBQUE7QUFTQSxJQUFBLG9CQUFBLEtBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEtBQUEsOERBQUEsSUFBQSxDQUFBO0FBUUosSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsS0FBQSxZQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsS0FBQSxRQUFBOzs7O0FBbFN3QixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFVBQUEsT0FBQSxNQUFBLEVBQWlCLGVBQUEsT0FBQSxrQkFBQSxVQUFBLEVBQUEscUJBQUEsT0FBQSxhQUFBLE9BQUEsT0FBQSxPQUFBLFVBQUEsNEJBQUEsRUFBQSxtQkFBQSxPQUFBLGFBQUEsT0FBQSxPQUFBLE9BQUEsVUFBQSwwQkFBQSxFQUFBLGNBQUEsT0FBQSxhQUFBLE9BQUEsT0FBQSxPQUFBLFVBQUEscUJBQUE7QUFNckIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxJQUFBLE9BQUEsT0FBQSxvQkFBQSxLQUFBLEVBQUE7QUFVQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLElBQUEsT0FBQSxPQUFBLDZCQUFBLEtBQUEsRUFBQTtBQVlJLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsVUFBQSxPQUFBLE1BQUEsRUFBaUIsZUFBQSxPQUFBLGtCQUFBLG9CQUFBLEVBQUEscUJBQUEsT0FBQSxhQUFBLE9BQUEsT0FBQSxPQUFBLFVBQUEsNkJBQUEsRUFBQSxtQkFBQSxPQUFBLGFBQUEsT0FBQSxPQUFBLE9BQUEsVUFBQSwyQkFBQSxFQUFBLGNBQUEsT0FBQSxhQUFBLE9BQUEsT0FBQSxPQUFBLFVBQUEsc0JBQUE7QUFVekIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxVQUFBLE9BQUEsTUFBQSxFQUFpQiw0QkFBQSxPQUFBLE9BQUEsZ0JBQUEsRUFBQSxnQkFBQSxPQUFBLGNBQUE7QUFhWCxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsT0FBQSxLQUFBO0FBSUEsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSwrQkFBQSxPQUFBLE9BQUEsU0FBQTtBQUVWLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsSUFBQSxDQUFBLEVBQUEsT0FBQSxPQUFBLGlCQUFBLE9BQUEsT0FBQSxPQUFBLE9BQUEsY0FBQSxVQUFBLEtBQUEsRUFBQTtBQVlBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsSUFBQSxPQUFBLE9BQUEsc0JBQUEsS0FBQSxFQUFBO0FBcURVLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsK0JBQUEsT0FBQSxPQUFBLGFBQUEsR0FBQTtBQUlBLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsK0JBQUEsT0FBQSxPQUFBLG9CQUFBLEdBQUE7QUFJQSxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLElBQUEsSUFBQSxPQUFBLE9BQUEsU0FBQSxLQUFBLEdBQUE7QUFJQSxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLElBQUEsSUFBQSxPQUFBLE9BQUEsT0FBQSxLQUFBLEdBQUE7QUFJQSxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsT0FBQSxZQUFBLEdBQUE7QUFJQSxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsT0FBQSw4QkFBQSxHQUFBO0FBSU4sSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxLQUFBLE9BQUEsT0FBQSxhQUFBLE1BQUEsRUFBQTtBQUdBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsS0FBQSxDQUFBLE9BQUEsT0FBQSxhQUFBLE1BQUEsRUFBQTtBQUlKLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsS0FBQSxPQUFBLGFBQUEsTUFBQSxFQUFBO0FBV0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxLQUFBLE9BQUEsY0FBQSxPQUFBLE9BQUEsZ0JBQUEsT0FBQSxPQUFBLHNCQUFBLE1BQUEsRUFBQTtBQUtBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsS0FBQSxPQUFBLE9BQUEsb0JBQUEsTUFBQSxFQUFBO0FBZ0JBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsS0FBQSxPQUFBLE9BQUEsc0JBQUEsTUFBQSxFQUFBO0FBTWMsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSx3QkFBQSxPQUFBLGNBQUEsY0FBQTtBQUVBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsSUFBQSx5QkFBQSxLQUFBLElBQUEsd0RBQUEsR0FBQSxHQUFBO0FBSU4sSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxLQUFBLE9BQUEsT0FBQSxXQUFBLE1BQUEsRUFBQTtBQUdBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsS0FBQSxDQUFBLE9BQUEsT0FBQSxXQUFBLE1BQUEsRUFBQTtBQUlJLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsa0NBQUEseUJBQUEsS0FBQSxJQUFBLHVEQUFBLEdBQUEsNEJBQUE7QUFJWixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLEtBQUEsT0FBQSxPQUFBLG9CQUFBLE1BQUEsRUFBQTtBQXNCQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLEtBQUEsT0FBQSxPQUFBLDZCQUFBLE1BQUEsRUFBQTtBQVFJLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsS0FBQSxPQUFBLHVCQUFBLE1BQUEsRUFBQTtBQUdBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsS0FBQSxDQUFBLE9BQUEsdUJBQUEsTUFBQSxFQUFBO0FBTUEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxLQUFBLE9BQUEsbUJBQUEsTUFBQSxFQUFBO0FBR0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxLQUFBLENBQUEsT0FBQSxtQkFBQSxNQUFBLEVBQUE7QUFJSixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLEtBQUEsT0FBQSxtQkFBQSxNQUFBLEVBQUE7QUFRQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLEtBQUEsT0FBQSxlQUFBLE9BQUEsa0JBQUEsTUFBQSxFQUFBO0FBU0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxLQUFBLFFBQUEsTUFBQSxFQUFBO0FBU0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxLQUFBLFFBQUEsTUFBQSxFQUFBOzs7QURoU2hCLDZCQW1CWSxtQkFlQztBQWxDYjs7QUFHQTtBQUNBO0FBR0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FBRUEsS0FBQSxTQUFZQSxvQkFBaUI7QUFDekIsTUFBQUEsbUJBQUEsWUFBQSxJQUFBO0FBQ0EsTUFBQUEsbUJBQUEsWUFBQSxJQUFBO0FBQ0EsTUFBQUEsbUJBQUEsVUFBQSxJQUFBO0FBQ0EsTUFBQUEsbUJBQUEsc0JBQUEsSUFBQTtBQUNBLE1BQUFBLG1CQUFBLHdCQUFBLElBQUE7QUFDQSxNQUFBQSxtQkFBQSxnQkFBQSxJQUFBO0FBQ0EsTUFBQUEsbUJBQUEsV0FBQSxJQUFBO0lBQ0osR0FSWSxzQkFBQSxvQkFBaUIsQ0FBQSxFQUFBO0FBZXZCLElBQU8sd0JBQVAsTUFBTyx1QkFBcUI7TUFtQ2xCO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUF6Q0gsb0JBQW9CO01BQ3BCLGdCQUFnQjtNQUNoQixPQUFPLG9CQUFvQjtNQUMzQixTQUFTLG9CQUFvQjtNQUM3QixjQUFjLG9CQUFvQjtNQUUzQztNQUNBO01BQ0E7TUFFQTtNQUNBO01BQ0EsY0FBYztNQUNkLGtCQUFrQjtNQUNsQixvQkFBb0I7TUFDcEIsd0JBQXdCO01BQ3hCLGFBQWE7TUFFYixVQUFVO01BRUY7TUFDUjtNQUdBLFVBQVU7TUFDVixRQUFRO01BQ1IsV0FBVztNQUNYLFVBQVU7TUFDVixTQUFTO01BQ1QsWUFBWTtNQUNaLGFBQWE7TUFDYixjQUFjO01BRWQsWUFDWSxjQUNBLHlCQUNBLHFCQUNBLE9BQ0EsY0FDQSxnQkFDQSxnQkFDQSxxQkFBd0M7QUFQeEMsYUFBQSxlQUFBO0FBQ0EsYUFBQSwwQkFBQTtBQUNBLGFBQUEsc0JBQUE7QUFDQSxhQUFBLFFBQUE7QUFDQSxhQUFBLGVBQUE7QUFDQSxhQUFBLGlCQUFBO0FBQ0EsYUFBQSxpQkFBQTtBQUNBLGFBQUEsc0JBQUE7TUFDVDtNQUtILFdBQVE7QUFDSixhQUFLLGVBQWUsZUFBYyxFQUFHLFVBQVUsQ0FBQyxnQkFBZTtBQUMzRCxlQUFLLGFBQWEsWUFBWSxlQUFlLFNBQVMsV0FBVztBQUNqRSxlQUFLLGNBQWMsWUFBWSxlQUFlLFNBQVMsTUFBTTtBQUM3RCxjQUFJLEtBQUssYUFBYTtBQUNsQixpQkFBSyxvQkFBb0Isa0JBQWlCLEVBQUcsVUFBVSxDQUFDLGFBQVk7QUFDaEUsbUJBQUssa0JBQWtCLFVBQVUsa0JBQWtCLFdBQVc7QUFDOUQsbUJBQUssb0JBQW9CLFVBQVUsb0JBQW9CLFdBQVc7QUFDbEUsbUJBQUssd0JBQXdCLFVBQVUsd0JBQXdCLFdBQVc7WUFDOUUsQ0FBQzs7UUFFVCxDQUFDO0FBQ0QsYUFBSyxNQUFNLEtBQUssVUFBVSxDQUFDLEVBQUUsT0FBTSxNQUFNO0FBQ3JDLGNBQUksUUFBUTtBQUNSLGlCQUFLLFNBQVM7QUFDZCxpQkFBSyxtQkFBbUIsQ0FBQyxDQUFDLEtBQUssT0FBTyx1Q0FBdUMsU0FBUyxXQUFXO0FBQ2pHLGlCQUFLLHVCQUF1QixDQUFDLENBQUMsS0FBSyxPQUFPLHVDQUF1QyxTQUFTLGVBQWU7O0FBRTdHLGVBQUssVUFBVSxLQUFLLGVBQWUsUUFBTztRQUM5QyxDQUFDO0FBRUQsWUFBSSxXQUFXO0FBQ2YsYUFBSyxXQUFXLEtBQUssTUFBTSxPQUFPLFVBQVUsQ0FBQyxXQUFVO0FBQ25ELHFCQUFXLE9BQU8sVUFBVTtRQUNoQyxDQUFDO0FBQ0QsYUFBSyxzQkFBc0IsUUFBUTtBQUNuQyxhQUFLLHdCQUF3QixRQUFRO0FBQ3JDLGFBQUssbUJBQW1CLFFBQVE7TUFDcEM7TUFLQSx3QkFBd0IsVUFBZ0I7QUFDcEMsYUFBSyxrQkFBa0IsS0FBSyxhQUFhLFVBQVUsMEJBQTBCLE1BQUs7QUFDOUUsZUFBSyx3QkFBd0IsS0FBSyxRQUFRLEVBQUUsVUFBVSxDQUFDLG1CQUFrQjtBQUNyRSxpQkFBSyxTQUFTLGVBQWU7VUFDakMsQ0FBQztBQUNELGVBQUssc0JBQXNCLFFBQVE7UUFDdkMsQ0FBQztNQUNMO01BS0EsY0FBVztBQUNQLFlBQUksS0FBSyxVQUFVO0FBQ2YsZUFBSyxTQUFTLFlBQVc7O0FBRTdCLGFBQUssYUFBYSxRQUFRLEtBQUssZUFBZTtNQUNsRDtNQUtRLHNCQUFzQixVQUFnQjtBQUMxQyxhQUFLLHdCQUF3QixpQ0FBaUMsUUFBUSxFQUFFLFVBQVU7VUFDOUUsTUFBTSxDQUFDLG1CQUErRDtBQUNsRSxpQkFBSyxZQUFZLGVBQWU7QUFDaEMsaUJBQUssaUJBQWlCLGVBQWUsS0FBTTtVQUMvQztVQUNBLE9BQU8sQ0FBQyxVQUE2QixRQUFRLEtBQUssY0FBYyxLQUFLO1NBQ3hFO01BQ0w7TUFFUSxtQkFBbUIsVUFBZ0I7QUFDdkMsYUFBSyxvQkFBb0IseUJBQXlCLFFBQVEsRUFBRSxVQUFVLENBQUMsa0JBQWlCO0FBQ3BGLGVBQUssT0FBTyxnQkFBZ0I7UUFDaEMsQ0FBQztNQUNMOzt5QkFySFMsd0JBQXFCLCtCQUFBLFlBQUEsR0FBQSwrQkFBQSx1QkFBQSxHQUFBLCtCQUFBLDZCQUFBLEdBQUEsK0JBQUEsaUJBQUEsR0FBQSwrQkFBQSxZQUFBLEdBQUEsK0JBQUEsY0FBQSxHQUFBLCtCQUFBLGNBQUEsR0FBQSwrQkFBQSxtQkFBQSxDQUFBO01BQUE7Z0VBQXJCLHdCQUFxQixXQUFBLENBQUEsQ0FBQSxtQkFBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLE9BQUEsd0JBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsc0JBQUEsWUFBQSxRQUFBLEdBQUEsVUFBQSxlQUFBLHFCQUFBLG1CQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLFVBQUEsNEJBQUEsY0FBQSxHQUFBLENBQUEsZ0JBQUEsZ0NBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxtQkFBQSxHQUFBLENBQUEsZ0JBQUEseUJBQUEsR0FBQSxDQUFBLE1BQUEsY0FBQSxHQUFBLENBQUEsZ0JBQUEsNkJBQUEsR0FBQSxDQUFBLE1BQUEsbUJBQUEsR0FBQSxDQUFBLGdCQUFBLG1DQUFBLEdBQUEsQ0FBQSxnQkFBQSxvQ0FBQSxHQUFBLENBQUEsZ0JBQUEsNkJBQUEsR0FBQSxDQUFBLE1BQUEsbUJBQUEsR0FBQSxDQUFBLGdCQUFBLDJCQUFBLEdBQUEsQ0FBQSxNQUFBLGlCQUFBLEdBQUEsQ0FBQSxnQkFBQSw0QkFBQSxHQUFBLENBQUEsTUFBQSxpQkFBQSxHQUFBLENBQUEsZ0JBQUEsOENBQUEsR0FBQSxDQUFBLE1BQUEsNkJBQUEsR0FBQSxDQUFBLGdCQUFBLG9DQUFBLEdBQUEsQ0FBQSxNQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsZ0JBQUEsbUJBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxnQkFBQSx5RUFBQSxHQUFBLENBQUEsTUFBQSw4QkFBQSxHQUFBLENBQUEsZ0JBQUEscUVBQUEsR0FBQSxDQUFBLE1BQUEsMEJBQUEsR0FBQSxDQUFBLGdCQUFBLGlDQUFBLEdBQUEsQ0FBQSxNQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsY0FBQSxzQkFBQSxPQUFBLE1BQUEsR0FBQSxDQUFBLGdCQUFBLG9DQUFBLEdBQUEsQ0FBQSxNQUFBLDJCQUFBLEdBQUEsQ0FBQSxNQUFBLGdCQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsZ0JBQUEsOENBQUEsR0FBQSxDQUFBLE1BQUEseUJBQUEsR0FBQSxDQUFBLE1BQUEsY0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLGdCQUFBLG1DQUFBLEdBQUEsQ0FBQSxNQUFBLDBCQUFBLEdBQUEsQ0FBQSxNQUFBLGVBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxnQkFBQSx1Q0FBQSxHQUFBLENBQUEsTUFBQSw4QkFBQSxHQUFBLENBQUEsTUFBQSxtQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLGdCQUFBLHNDQUFBLEdBQUEsQ0FBQSxNQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLGdCQUFBLHVDQUFBLEdBQUEsQ0FBQSxNQUFBLDhCQUFBLEdBQUEsQ0FBQSxnQkFBQSxxQ0FBQSxHQUFBLENBQUEsTUFBQSw0QkFBQSxHQUFBLENBQUEsZ0JBQUEsbURBQUEsR0FBQSxDQUFBLE1BQUEsa0NBQUEsR0FBQSxvQkFBQSw2QkFBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLGdCQUFBLHVDQUFBLEdBQUEsQ0FBQSxNQUFBLDhCQUFBLEdBQUEsQ0FBQSxnQkFBQSx1Q0FBQSxHQUFBLENBQUEsTUFBQSx1QkFBQSxHQUFBLENBQUEsZ0JBQUEsMkNBQUEsR0FBQSxDQUFBLE1BQUEsNEJBQUEsR0FBQSxDQUFBLGdCQUFBLDhDQUFBLEdBQUEsQ0FBQSxNQUFBLHNCQUFBLEdBQUEsQ0FBQSxnQkFBQSwrQ0FBQSxHQUFBLENBQUEsTUFBQSxpQ0FBQSxHQUFBLENBQUEsZ0JBQUEsdURBQUEsR0FBQSxDQUFBLE1BQUEsMENBQUEsR0FBQSxDQUFBLGdCQUFBLHdEQUFBLEdBQUEsQ0FBQSxNQUFBLHVDQUFBLEdBQUEsQ0FBQSxnQkFBQSw2RUFBQSxHQUFBLENBQUEsTUFBQSwwQkFBQSxHQUFBLG9CQUFBLDZCQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsZ0JBQUEsbURBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSx1QkFBQSxVQUFBLEdBQUEsQ0FBQSxnQkFBQSxxREFBQSxHQUFBLENBQUEsZ0JBQUEseURBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSwrQkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ2xDbEMsVUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx3QkFBQSxHQUFBLDhDQUFBLEtBQUEsRUFBQTtBQTBTSixVQUFBLDBCQUFBO0FBQ0EsVUFBQSxvQkFBQSxHQUFBLElBQUE7OztBQTNTSSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLDJCQUFBLEdBQUEsSUFBQSxTQUFBLElBQUEsRUFBQTs7Ozs7b0ZEaUNTLHVCQUFxQixFQUFBLFdBQUEsd0JBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFbENsQyxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLFlBQVksa0JBQWtCO0FBS3ZDLFNBQVMsV0FBVzs7O0FBTnBCLElBWWE7QUFaYjs7QUFPQTtBQUNBO0FBSU0sSUFBTyxvQkFBUCxNQUFPLG1CQUFpQjtNQUtOO01BSlosV0FBVztNQUNYLGNBQWMsU0FBUyxLQUFLO01BQzVCLG1CQUFtQixlQUFlLEtBQUs7TUFFL0MsWUFBb0IsTUFBZ0I7QUFBaEIsYUFBQSxPQUFBO01BQW1CO01BS3ZDLGFBQWEsTUFBZ0IsYUFBcUIsV0FBaUI7QUFDL0QsY0FBTSxTQUFTLElBQUksV0FBVSxFQUN4QixJQUFJLFFBQVEsS0FBSyxJQUFJLEVBQ3JCLElBQUksZUFBZSxLQUFLLFdBQVcsRUFDbkMsSUFBSSxhQUFhLEtBQUssU0FBUztBQUNwQyxlQUFPLEtBQUssS0FBSyxJQUFjLEdBQUcsS0FBSyxnQkFBZ0IsUUFBUSxFQUFFLE9BQU0sQ0FBRTtNQUM3RTtNQUtBLHVCQUF1QixNQUFnQixhQUFxQixXQUFtQixNQUFzQixVQUFnQjtBQUNqSCxjQUFNLFNBQVMsSUFBSSxXQUFVLEVBQ3hCLElBQUksUUFBUSxLQUFLLElBQUksRUFDckIsSUFBSSxlQUFlLEtBQUssV0FBVyxFQUNuQyxJQUFJLGFBQWEsS0FBSyxTQUFTLEVBQy9CLElBQUksUUFBUSxLQUFLLElBQUksRUFDckIsSUFBSSxZQUFZLEtBQUssUUFBUTtBQUNsQyxlQUFPLEtBQUssS0FBSyxJQUFjLEdBQUcsS0FBSyxXQUFXLG9CQUFvQixFQUFFLE9BQU0sQ0FBRTtNQUNwRjtNQUtBLG9CQUFvQixVQUFnQjtBQUNoQyxjQUFNLFNBQVMsSUFBSSxXQUFVLEVBQUcsSUFBSSxZQUFZLEtBQUssUUFBUTtBQUM3RCxlQUFPLEtBQUssS0FBSyxJQUFtQyxHQUFHLEtBQUssV0FBVyxxQkFBcUIsRUFBRSxPQUFNLENBQUUsRUFBRSxLQUNwRyxJQUFJLENBQUMsUUFBc0M7QUFDdkMsNkJBQWtCLGlFQUFpRSxHQUFHO0FBQ3RGLGlCQUFPLG1CQUFrQixnREFBZ0QsR0FBRztRQUNoRixDQUFDLENBQUM7TUFFVjtNQUtBLHNCQUFzQixZQUFrQjtBQUNwQyxjQUFNLFNBQVMsSUFBSSxXQUFVLEVBQUcsSUFBSSxjQUFjLEtBQUssVUFBVTtBQUNqRSxlQUFPLEtBQUssS0FDUCxJQUFxQyxHQUFHLEtBQUssV0FBVyx1QkFBdUIsRUFBRSxPQUFNLENBQUUsRUFDekYsS0FBSyxJQUFJLENBQUMsUUFBeUMsbUJBQWtCLDBDQUEwQyxHQUFHLENBQUMsQ0FBQztNQUM3SDtNQUVRLE9BQU8sMENBQTBDLE9BQXNDO0FBQzNGLGNBQU0sMEJBQTBCLE1BQU0sa0NBQWtDLElBQUksTUFBTyxNQUFNLHlCQUF5QixNQUFNLGtDQUFtQyxLQUFLLENBQUMsSUFBSTtBQUNySyxjQUFNLHlCQUF5QixNQUFNLGdCQUFnQixJQUFJLE1BQU8sTUFBTSx3QkFBd0IsTUFBTSxnQkFBaUIsS0FBSyxDQUFDLElBQUk7QUFDL0gsY0FBTSx3QkFBd0IsTUFBTyxNQUFNLHlCQUF5QixNQUFNLHNCQUF1QixLQUFLLENBQUM7QUFDdkcsZUFBTztNQUNYO01BRVEsT0FBTyxnREFBZ0QsS0FBa0M7QUFDN0YsWUFBSSx5QkFBeUIsUUFBUSxDQUFDLGtCQUFpQjtBQUNuRCx3QkFBYyxjQUFjLHNCQUFzQixjQUFjLFdBQVc7UUFDL0UsQ0FBQztBQUNELGVBQU87TUFDWDtNQUVRLE9BQU8saUVBQWlFLEtBQWtDO0FBQzlHLFlBQUkseUJBQXlCLFFBQVEsQ0FBQyx3QkFBdUI7QUFDekQsOEJBQW9CLGFBQWEsb0JBQW9CLFlBQVksSUFBSSxDQUFDLGFBQWEsS0FBSyxNQUFNLFFBQWtCLENBQXFCO1FBQ3pJLENBQUM7QUFDRCxlQUFPO01BQ1g7O3lCQXpFUyxvQkFBaUIsdUJBQUEsYUFBQSxDQUFBO01BQUE7b0VBQWpCLG9CQUFpQixTQUFqQixtQkFBaUIsV0FBQSxZQURKLE9BQU0sQ0FBQTs7Ozs7O0FDWGhDLFNBQVMsYUFBQUMsWUFBVyxhQUFnQztBQUNwRCxTQUFTLGNBQWM7QUFJdkIsU0FBUyxpQkFBaUI7QUFFMUIsU0FBZ0IsaUJBQWlCOzs7Ozs7OztBQ0x6QixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQXdCLElBQUEscUJBQUEsQ0FBQTs7QUFBb0UsSUFBQSwyQkFBQTtBQUNoRyxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQUhPLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSxPQUFBLFNBQUE7QUFDeUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEseUJBQUEsT0FBQSxrQkFBQSxDQUFBOzs7OztBQUk1QixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFBd0IsSUFBQSxxQkFBQSxDQUFBOztBQUFvRSxJQUFBLDJCQUFBO0FBQ2hHLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBRDRCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLHlCQUFBLE9BQUEsa0JBQUEsQ0FBQTs7Ozs7QUFLaEIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUF3QixJQUFBLHFCQUFBLENBQUE7QUFBd0IsSUFBQSwyQkFBQTtBQUNwRCxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFENEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxJQUFBLE9BQUEsbUJBQUEsR0FBQTs7Ozs7QUFHeEIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUF3QixJQUFBLHFCQUFBLENBQUE7QUFBd0MsSUFBQSwyQkFBQTtBQUNwRSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFENEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxJQUFBLE9BQUEsaUJBQUEsT0FBQSxPQUFBLFlBQUEsRUFBQTs7Ozs7QUFHeEIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxXQUFBLENBQUE7QUFBMEMsSUFBQSxxQkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLDJCQUFBO0FBQ3BELElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFGaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsU0FBQSxFQUFrQixRQUFBLElBQUE7OztBRG5CL0MsVUFXTSw2QkFPTztBQWxCYjs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUdBOzs7QUFFQSxJQUFNLDhCQUE4QixDQUFDLEdBQUcsR0FBRyxDQUFDO0FBT3RDLElBQU8seUJBQVAsTUFBTyx3QkFBc0I7TUFpQlg7TUFoQlg7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFFVCxnQkFBZ0I7TUFDaEI7TUFDQTtNQUNBO01BR0EsWUFBWTtNQUVaLFlBQW9CLFFBQWM7QUFBZCxhQUFBLFNBQUE7TUFBaUI7TUFHckMsa0JBQW9EO1FBQ2hELEVBQUUsTUFBTSxRQUFRLE9BQU8sRUFBQztRQUN4QixFQUFFLE1BQU0sWUFBWSxPQUFPLEVBQUM7UUFDNUIsRUFBRSxNQUFNLE9BQU8sT0FBTyxFQUFDOztNQUUzQixXQUFXO1FBQ1AsTUFBTTtRQUNOLFlBQVk7UUFDWixPQUFPLFVBQVU7UUFDakIsUUFBUSxDQUFDLFlBQVksT0FBTyxZQUFZLEtBQUssWUFBWSxVQUFVOztNQUV2RSxpQkFBaUIsS0FBSyxnQkFBZ0IsS0FBSyxJQUFJO01BRS9DLGNBQVc7QUFHUCxZQUFJLEtBQUssbUJBQW1CLFVBQWEsQ0FBQyxLQUFLLGVBQWU7QUFDMUQsZUFBSyxtQkFBbUIsMkJBQTJCO2VBQ2hEO0FBQ0gsZUFBSyxnQkFBZ0I7QUFDckIsZ0JBQU0sWUFBWSxvQ0FBb0MsS0FBSyxhQUFjLEtBQUssaUJBQWtCLEtBQUssTUFBTTtBQUMzRyxlQUFLLFFBQVEsQ0FBQyxLQUFLLGlCQUFrQixXQUFXLENBQUM7QUFDakQsaUJBQU8sS0FBSyxlQUFlLElBQUksS0FBSyxtQkFBbUIsMkJBQTJCLElBQUksS0FBSyxtQkFBbUIsS0FBSyxLQUFLOztNQUVoSTtNQUtBLFdBQVE7QUFDSixnQkFBUSxLQUFLLGFBQWE7VUFDdEIsS0FBSyxrQkFBa0I7QUFDbkIsaUJBQUsscUJBQXFCO0FBQzFCLGlCQUFLLFlBQVksQ0FBQyxzQkFBc0IsS0FBSyxPQUFPLEVBQUUsSUFBSSxLQUFLLFlBQVksY0FBYyxLQUFLLFVBQVUsU0FBUztBQUNqSDtVQUNKLEtBQUssa0JBQWtCO0FBQ25CLGlCQUFLLHFCQUFxQjtBQUMxQixpQkFBSyxZQUFZLENBQUMsc0JBQXNCLEtBQUssT0FBTyxFQUFFLElBQUksS0FBSyxZQUFZLGNBQWMsS0FBSyxVQUFVLGlCQUFpQjtBQUN6SDtVQUNKLEtBQUssa0JBQWtCO0FBQ25CLGlCQUFLLHFCQUFxQjtBQUMxQixpQkFBSyxZQUFZLENBQUMsWUFBWSxLQUFLLE9BQU8sRUFBRSxjQUFjLEtBQUssVUFBVSxFQUFFO0FBQzNFO1VBQ0o7QUFDSSxpQkFBSyxxQkFBcUI7QUFDMUIsaUJBQUssWUFBWTs7TUFFN0I7TUFNQSx3QkFBcUI7QUFDakIsWUFBSSxLQUFLLE9BQU8sTUFBTSxLQUFLLGNBQWMsS0FBSyxXQUFXO0FBQ3JELGVBQUssT0FBTyxTQUFTLEtBQUssU0FBUzs7TUFFM0M7TUFNUSxtQkFBbUIsUUFBZ0I7QUFDdkMsYUFBSyxnQkFBZ0IsUUFBUSxDQUFDLE9BQXVDLFVBQW1CLE1BQU0sUUFBUSxPQUFPLEtBQUssQ0FBRTtBQUNwSCxhQUFLLGtCQUFrQixDQUFDLEdBQUcsS0FBSyxlQUFlO01BQ25EO01BU0EsZ0JBQWdCLE1BQVM7QUFDckIsZUFBTyxLQUFLLGVBQWUsSUFBSSxNQUFNLEtBQUs7TUFDOUM7O3lCQWpHUyx5QkFBc0IsZ0NBQUEsVUFBQSxDQUFBO01BQUE7aUVBQXRCLHlCQUFzQixXQUFBLENBQUEsQ0FBQSxvQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFFBQUEsVUFBQSxhQUFBLGVBQUEsWUFBQSxjQUFBLGNBQUEsZ0JBQUEsbUJBQUEscUJBQUEsaUJBQUEsbUJBQUEsWUFBQSxhQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFFBQUEsVUFBQSxlQUFBLDJCQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsNEJBQUEsR0FBQSxXQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEscUJBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxXQUFBLFVBQUEsWUFBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLEdBQUEsV0FBQSxHQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsTUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGdDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDbEJuQyxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLHlCQUFBLEdBQUEsK0NBQUEsR0FBQSxDQUFBLEVBSUMsR0FBQSwrQ0FBQSxHQUFBLENBQUE7QUFJRCxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQStFLFVBQUEseUJBQUEsU0FBQSxTQUFBLHVEQUFBO0FBQUEsbUJBQVMsSUFBQSxzQkFBQTtVQUF1QixDQUFBO0FBQzNHLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSwrQ0FBQSxHQUFBLENBQUEsRUFFQyxHQUFBLCtDQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsZ0RBQUEsR0FBQSxDQUFBO0FBU0wsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLHdCQUFBLENBQUE7QUFBNEksVUFBQSxxQkFBQSxJQUFBLEdBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ2hKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUF6QkksVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsWUFBQSxJQUFBLEVBQUE7QUFLQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsQ0FBQSxJQUFBLFlBQUEsSUFBQSxFQUFBO0FBR3NDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsV0FBQSxJQUFBLFlBQUEsY0FBQSxFQUFBO0FBRTlCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLGdCQUFBLElBQUEsRUFBQTtBQUdBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLGdCQUFBLElBQUEsRUFBQTtBQUdBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxDQUFBLElBQUEsZ0JBQUEsS0FBQSxFQUFBO0FBTWtCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSw4QkFBQSxJQUFBQyxJQUFBLENBQUEsRUFBbUIsV0FBQSxJQUFBLGVBQUEsRUFBQSxVQUFBLElBQUEsUUFBQSxFQUFBLFlBQUEsSUFBQSxFQUFBLGVBQUEsSUFBQSxjQUFBOzs7OztxRkRMcEMsd0JBQXNCLEVBQUEsV0FBQSx5QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVsQm5DLFNBQVMsYUFBQUMsWUFBVyxTQUFBQyxjQUF1QztBQUUzRCxPQUFPLFdBQVc7QUFFbEIsU0FBUyxhQUFhLG9CQUFvQjtBQUUxQyxTQUFnQixhQUFBQyxrQkFBaUI7QUFDakMsU0FBUyx3QkFBd0I7Ozs7Ozs7QUNhYixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsR0FBQTtBQUFHLElBQUEscUJBQUEsQ0FBQTtBQUFnQixJQUFBLDJCQUFBO0FBQUssSUFBQSxxQkFBQSxHQUFBLEdBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsSUFBQTtBQUN4QixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTs7QUFBOEQsSUFBQSwyQkFBQTtBQUN4RSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7O0FBRk8sSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxTQUFBLElBQUE7QUFDRyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLElBQUEsMEJBQUEsR0FBQSxHQUFBLE9BQUEsa0JBQUEsR0FBQSxNQUFBLFNBQUEsT0FBQSxFQUFBOzs7QURyQjFCLFVBZWE7QUFmYjs7QUFDQTtBQUVBO0FBRUE7Ozs7QUFVTSxJQUFPLDJCQUFQLE1BQU8sMEJBQXdCO01BNENyQjtNQUNBO01BM0NaO01BRUE7TUFFQTtNQUVBO01BR0EsT0FBTztNQUNQLFFBQVE7TUFDUixXQUFXO01BQ1gsU0FBUztNQUdUO01BQ0EsaUJBQWlCO01BQ2pCO01BRUEsaUJBQTJCLENBQUE7TUFDM0I7TUFHQSxVQUE0QyxDQUFBO01BQzVDLFdBQWtCO1FBQ2QsTUFBTTtRQUNOLFlBQVk7UUFDWixPQUFPQSxXQUFVO1FBQ2pCLFFBQVEsQ0FBQyxZQUFZLFNBQVM7O01BRWxDO01BQ0E7TUFDQSxzQkFBc0I7TUFHZCxnQkFBZ0I7TUFHeEIsY0FBYztNQUNkLGVBQWU7TUFFZixZQUNZLFNBQ0Esa0JBQWtDO0FBRGxDLGFBQUEsVUFBQTtBQUNBLGFBQUEsbUJBQUE7QUFFUixhQUFLLGlCQUFpQixhQUFhLFVBQVUsTUFBSztBQUM5QyxlQUFLLHVCQUFzQjtRQUMvQixDQUFDO01BQ0w7TUFNQSxZQUFZLFNBQXNCO0FBQzlCLGFBQUssY0FBYyxRQUFRLGFBQWE7QUFDeEMsYUFBSyxpQkFBaUIsQ0FBQTtBQUN0QixhQUFLLGdCQUFnQjtBQUNyQixhQUFLLFlBQVksY0FBYyxLQUFLLFVBQVUsU0FBUSxFQUFHLFlBQVcsQ0FBRTtBQUN0RSxhQUFLLHFCQUFxQixjQUFjLEtBQUssVUFBVSxTQUFRLEVBQUcsWUFBVyxDQUFFO0FBQy9FLGFBQUssZ0JBQWU7TUFDeEI7TUFFUSxrQkFBZTtBQUNuQixhQUFLLGFBQVk7QUFDakIsWUFBSSxLQUFLLG1CQUFtQixlQUFlLFNBQVM7QUFDaEQsZUFBSyxRQUFRLGFBQWEsS0FBSyxhQUFhLEtBQUssZUFBZSxLQUFLLFNBQVMsRUFBRSxVQUFVLENBQUMsUUFBaUI7QUFDeEcsaUJBQUssa0JBQWtCO0FBQ3ZCLGlCQUFLLFdBQVU7VUFDbkIsQ0FBQztlQUNFO0FBQ0gsZUFBSyxRQUFRLHVCQUF1QixLQUFLLGFBQWEsS0FBSyxlQUFlLEtBQUssV0FBVyxLQUFLLGdCQUFnQixLQUFLLFFBQVMsRUFBRSxVQUFVLENBQUMsUUFBaUI7QUFDdkosaUJBQUssa0JBQWtCO0FBQ3ZCLGlCQUFLLFdBQVU7VUFDbkIsQ0FBQzs7TUFFVDtNQUVRLGVBQVk7QUFDaEIsY0FBTSxNQUFNLE1BQUs7QUFDakIsWUFBSTtBQUNKLFlBQUk7QUFDSixnQkFBUSxLQUFLLGFBQWE7VUFDdEIsS0FBSyxTQUFTO0FBQ1YscUJBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0FBQ3pCLG1CQUFLLGVBQWUsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQzs7QUFFN0MsaUJBQUssWUFBWSxJQUFJLElBQUksS0FBSyxlQUFlLE1BQU0sRUFBRSxPQUFPLFlBQVk7QUFDeEU7VUFDSixLQUFLLFNBQVM7QUFDVixpQkFBSyxpQkFBaUIsS0FBSyxZQUFXO0FBQ3RDLHdCQUFZLE1BQUssRUFBRyxJQUFJLEtBQUssZUFBZSxPQUFPLEVBQUUsU0FBUyxHQUFHLE1BQU0sRUFBRSxPQUFPLFlBQVk7QUFDNUYsc0JBQVUsTUFBSyxFQUFHLElBQUksS0FBSyxlQUFlLE9BQU8sRUFBRSxPQUFPLFlBQVk7QUFDdEUsaUJBQUssWUFBWSxZQUFZLFFBQVE7QUFDckM7VUFDSixLQUFLLFNBQVM7QUFDVix3QkFBWSxNQUFLLEVBQUcsU0FBUyxJQUFJLEtBQUssZUFBZSxRQUFRO0FBQzdELHNCQUFVLE1BQUssRUFBRyxTQUFTLENBQUMsS0FBSyxlQUFlLFFBQVE7QUFDeEQsaUJBQUssaUJBQWlCLEtBQUssa0JBQWtCLFFBQVEsS0FBSyxXQUFXLE1BQU0sQ0FBQztBQUM1RSxpQkFBSyxZQUFZLElBQ1osSUFBSSxLQUFLLGVBQWUsUUFBUSxFQUNoQyxTQUFTLEtBQUssTUFBTSxLQUFLLGVBQWUsU0FBUyxDQUFHLElBQUksR0FBRyxNQUFNLEVBQ2pFLE9BQU8sV0FBVztBQUN2QjtVQUNKLEtBQUssU0FBUztBQUNWLHdCQUFZLE1BQUssRUFBRyxTQUFTLEtBQUssS0FBSyxDQUFDLEtBQUssZUFBZSxPQUFPO0FBQ25FLHNCQUFVLEtBQUssa0JBQWtCLElBQUksTUFBSyxFQUFHLFNBQVMsS0FBSyxDQUFDLEtBQUssZUFBZSxPQUFPLElBQUksTUFBSztBQUVoRyxnQkFBSTtBQUNKLHFCQUFTLElBQUksR0FBRyxJQUFJLElBQUksS0FBSztBQUN6Qiw0QkFBYyxNQUFLLEVBQ2QsU0FBUyxLQUFLLEtBQUssQ0FBQyxLQUFLLGdCQUFnQixHQUFHLE9BQU8sRUFDbkQsV0FBVyxDQUFDLEVBQ1osUUFBTztBQUNaLG1CQUFLLGVBQWUsQ0FBQyxJQUFJLEtBQUssaUJBQWlCLFFBQVEsZUFBZSxJQUFJLE1BQU07O0FBRXBGLGlCQUFLLFlBQVksVUFBVSxXQUFXLENBQUMsRUFBRSxPQUFPLFlBQVksSUFBSSxRQUFRLFFBQVEsV0FBVyxDQUFDLEVBQUUsT0FBTyxZQUFZO0FBQ2pIO1VBQ0osS0FBSyxTQUFTO0FBQ1YsaUJBQUssaUJBQWlCLEtBQUssVUFBUztBQUNwQyxpQkFBSyxZQUFZLElBQUksSUFBSSxLQUFLLGVBQWUsT0FBTyxFQUFFLFNBQVMsR0FBRyxRQUFRLEVBQUUsT0FBTyxNQUFNO0FBQ3pGOztNQUVaO01BRVEsWUFBUztBQUNiLGNBQU0sZUFBZSxNQUFLLEVBQUcsTUFBSztBQUNsQyxjQUFNLE9BQU87VUFDVCxLQUFLLGlCQUFpQixRQUFRLGdCQUFnQjtVQUM5QyxLQUFLLGlCQUFpQixRQUFRLGlCQUFpQjtVQUMvQyxLQUFLLGlCQUFpQixRQUFRLGNBQWM7VUFDNUMsS0FBSyxpQkFBaUIsUUFBUSxjQUFjO1VBQzVDLEtBQUssaUJBQWlCLFFBQVEsWUFBWTtVQUMxQyxLQUFLLGlCQUFpQixRQUFRLGFBQWE7VUFDM0MsS0FBSyxpQkFBaUIsUUFBUSxhQUFhO1VBQzNDLEtBQUssaUJBQWlCLFFBQVEsZUFBZTtVQUM3QyxLQUFLLGlCQUFpQixRQUFRLGtCQUFrQjtVQUNoRCxLQUFLLGlCQUFpQixRQUFRLGdCQUFnQjtVQUM5QyxLQUFLLGlCQUFpQixRQUFRLGlCQUFpQjtVQUMvQyxLQUFLLGlCQUFpQixRQUFRLGlCQUFpQjs7QUFFbkQsY0FBTSxPQUFPLEtBQUssTUFBTSxlQUFlLEdBQUcsS0FBSyxNQUFNO0FBQ3JELGNBQU0sUUFBUSxLQUFLLE1BQU0sR0FBRyxlQUFlLENBQUM7QUFDNUMsZUFBTyxLQUFLLE9BQU8sS0FBSztNQUM1QjtNQUVRLGtCQUFrQixhQUFtQjtBQUN6QyxjQUFNLE9BQWlCLENBQUE7QUFFdkIsaUJBQVMsSUFBSSxHQUFHLElBQUksYUFBYSxLQUFLO0FBQ2xDLGVBQUssS0FDRCxNQUFLLEVBQ0EsU0FBUyxDQUFDLEtBQUssZUFBZSxRQUFRLEVBQ3RDLFNBQVMsY0FBYyxJQUFJLEdBQUcsTUFBTSxFQUNwQyxPQUFPLE9BQU8sQ0FBQzs7QUFHNUIsZUFBTztNQUNYO01BRVEsY0FBVztBQUNmLGNBQU0sYUFBYSxNQUFLLEVBQUcsSUFBRztBQUM5QixjQUFNLE9BQU87VUFDVCxLQUFLLGlCQUFpQixRQUFRLGlCQUFpQjtVQUMvQyxLQUFLLGlCQUFpQixRQUFRLGtCQUFrQjtVQUNoRCxLQUFLLGlCQUFpQixRQUFRLG9CQUFvQjtVQUNsRCxLQUFLLGlCQUFpQixRQUFRLG1CQUFtQjtVQUNqRCxLQUFLLGlCQUFpQixRQUFRLGlCQUFpQjtVQUMvQyxLQUFLLGlCQUFpQixRQUFRLG1CQUFtQjtVQUNqRCxLQUFLLGlCQUFpQixRQUFRLGlCQUFpQjs7QUFFbkQsY0FBTSxPQUFPLEtBQUssTUFBTSxZQUFZLEtBQUssTUFBTTtBQUMvQyxjQUFNLFFBQVEsS0FBSyxNQUFNLEdBQUcsVUFBVTtBQUN0QyxlQUFPLEtBQUssT0FBTyxLQUFLO01BQzVCO01BRU8sZUFBZSxPQUFjO0FBQ2hDLGdCQUFTLEtBQUssaUJBQWlCLElBQU0sS0FBSyxpQkFBaUI7QUFDM0QsYUFBSyxnQkFBZTtNQUN4QjtNQU9RLGFBQVU7QUFDZCxhQUFLLFVBQVUsS0FBSyxnQkFBZ0IsSUFBSSxDQUFDLE9BQU8sV0FBVyxFQUFFLE1BQU0sS0FBSyxlQUFlLEtBQUssR0FBRyxPQUFPLE1BQUssRUFBRztBQUM5RyxhQUFLLFlBQVksS0FBSyxJQUFJLEdBQUcsR0FBRyxLQUFLLGVBQWU7TUFDeEQ7TUFLUSx5QkFBc0I7QUFDMUIsYUFBSyxhQUFZO0FBQ2pCLGFBQUssUUFBUSxRQUFRLENBQUMsVUFBVSxVQUFTO0FBQ3JDLG1CQUFTLE9BQU8sS0FBSyxlQUFlLEtBQUs7UUFDN0MsQ0FBQztBQUNELGFBQUssVUFBVSxDQUFDLEdBQUcsS0FBSyxPQUFPO01BQ25DOzt5QkExTVMsMkJBQXdCLGdDQUFBLGlCQUFBLEdBQUEsZ0NBQUEsb0JBQUEsQ0FBQTtNQUFBO2lFQUF4QiwyQkFBd0IsV0FBQSxDQUFBLENBQUEsc0JBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxXQUFBLGFBQUEsYUFBQSxlQUFBLGdCQUFBLGtCQUFBLFVBQUEsV0FBQSxHQUFBLFVBQUEsQ0FBQSxrQ0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxPQUFBLFVBQUEsd0JBQUEsR0FBQSxDQUFBLEdBQUEsS0FBQSxHQUFBLENBQUEsUUFBQSxNQUFBLFFBQUEsVUFBQSxHQUFBLFNBQUEsVUFBQSx1QkFBQSxzQkFBQSxRQUFBLEdBQUEsUUFBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsVUFBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSxFQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsV0FBQSxVQUFBLFNBQUEsU0FBQSxpQkFBQSxhQUFBLHVCQUFBLGNBQUEsWUFBQSxHQUFBLENBQUEsbUJBQUEsRUFBQSxHQUFBLENBQUEsUUFBQSxNQUFBLFFBQUEsVUFBQSxHQUFBLFNBQUEsVUFBQSx5QkFBQSxzQkFBQSxRQUFBLEdBQUEsUUFBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsZUFBQSxlQUFBLFFBQUEsTUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGtDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDZnJDLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUFJLFVBQUEscUJBQUEsQ0FBQTs7QUFBa0MsVUFBQSwyQkFBQTtBQUMxQyxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxXQUFBLENBQUE7QUFBdUgsVUFBQSx5QkFBQSxTQUFBLFNBQUEsOERBQUE7QUFBQSxtQkFBUyxJQUFBLGVBQUEsSUFBQSxJQUFBO1VBQW9CLENBQUE7QUFBRSxVQUFBLDJCQUFBO0FBQ3RKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsR0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLDJCQUFBLENBQUE7QUFZSSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsa0RBQUEsSUFBQSxHQUFBLGVBQUEsTUFBQSxHQUFBLG9DQUFBO0FBSUosVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUEwSCxVQUFBLHlCQUFBLFNBQUEsU0FBQSw4REFBQTtBQUFBLG1CQUFTLElBQUEsZUFBQSxJQUFBLEtBQUE7VUFBcUIsQ0FBQTtBQUFFLFVBQUEsMkJBQUE7QUFDOUosVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsTUFBQSxDQUFBO0FBQXVELFVBQUEscUJBQUEsRUFBQTtBQUFlLFVBQUEsMkJBQUE7QUFDdEUsVUFBQSxxQkFBQSxJQUFBLElBQUE7Ozs7QUEzQlksVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSwwQkFBQSxHQUFBLElBQUEsSUFBQSxTQUFBLENBQUE7QUFHSyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxXQUFBO0FBR0QsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLDhCQUFBLElBQUFDLE1BQUEsSUFBQSxXQUFBLENBQUEsRUFBd0MsV0FBQSxJQUFBLE9BQUEsRUFBQSxVQUFBLElBQUEsUUFBQSxFQUFBLFNBQUEsSUFBQSxFQUFBLFNBQUEsSUFBQSxFQUFBLGlCQUFBLElBQUEsRUFBQSxhQUFBLElBQUEsU0FBQSxFQUFBLHVCQUFBLElBQUEsbUJBQUEsRUFBQSxjQUFBLEtBQUEsRUFBQSxjQUFBLEtBQUE7QUFpQnZDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLFlBQUE7QUFHc0MsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSxJQUFBLFNBQUE7Ozs7O3FGRGIxQywwQkFBd0IsRUFBQSxXQUFBLDJCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRWZyQyxTQUFTLGFBQUFDLFlBQVcsU0FBQUMsY0FBcUI7QUFJekMsU0FBZ0IsYUFBQUMsa0JBQWlCOzs7OztBQ2NqQixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsR0FBQTtBQUFHLElBQUEscUJBQUEsQ0FBQTtBQUFnQixJQUFBLDJCQUFBO0FBQUssSUFBQSxxQkFBQSxHQUFBLEdBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsSUFBQTtBQUN4QixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUFxQyxJQUFBLDJCQUFBO0FBQy9DLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7Ozs7QUFGTyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFNBQUEsSUFBQTtBQUNHLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsT0FBQSxvQkFBQSxTQUFBLElBQUEsQ0FBQTs7O0FEbkJ0QixVQWFhO0FBYmI7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7OztBQU9NLElBQU8sNENBQVAsTUFBTywyQ0FBeUM7TUE0QjlCO01BMUJwQjtNQUVBO01BRUE7TUFFQTtNQUVBO01BRUE7TUFHQSxVQUFpQixDQUFBO01BQ2pCLFdBQWtCO1FBQ2QsTUFBTTtRQUNOLFlBQVk7UUFDWixPQUFPQSxXQUFVO1FBQ2pCLFFBQVEsQ0FBQyxZQUFZLFNBQVM7O01BRWxDLHNCQUFzQjtNQUd0QixpQkFBMkIsQ0FBQTtNQUMzQixvQkFBOEIsQ0FBQTtNQUU5QixZQUFvQixtQkFBK0M7QUFBL0MsYUFBQSxvQkFBQTtNQUFrRDtNQUV0RSxXQUFRO0FBQ0osYUFBSyxnQkFBZTtNQUN4QjtNQUVRLGtCQUFlO0FBQ25CLGFBQUssaUJBQWlCLENBQUMsV0FBVyxZQUFZLFlBQVksWUFBWSxZQUFZLFlBQVksWUFBWSxZQUFZLFlBQVksV0FBVztBQUM3SSxZQUFJLEtBQUssMEJBQTBCLEtBQUsseUJBQXlCLEdBQUc7QUFDaEUsZUFBSyxvQkFBb0IsQ0FBQTtBQUN6QixxQkFBVyxTQUFTLEtBQUssbUJBQW9CO0FBQ3pDLGlCQUFLLGtCQUFrQixLQUFLLE1BQU8sUUFBUSxNQUFPLEtBQUssc0JBQXNCLENBQUM7O2VBRS9FO0FBQ0gsZUFBSyxvQkFBb0IsSUFBSSxNQUFNLEVBQUUsRUFBRSxLQUFLLENBQUM7O0FBRWpELGFBQUssVUFBVSxLQUFLLGtCQUFrQixJQUFJLENBQUMsTUFBTSxXQUFXLEVBQUUsTUFBTSxLQUFLLGVBQWUsS0FBSyxHQUFHLE9BQU8sS0FBSSxFQUFHO01BQ2xIO01BT0Esb0JBQW9CLFFBQWM7QUFDOUIsY0FBTSxRQUFRLEtBQUssZUFBZSxRQUFRLE1BQU07QUFDaEQsZUFBTyxLQUFLLGtCQUFtQixLQUFLO01BQ3hDO01BTUEsZUFBZSxPQUFVO0FBQ3JCLGNBQU0sUUFBUSxLQUFLLGVBQWUsUUFBUSxNQUFNLElBQUk7QUFDcEQsY0FBTSxRQUFRLENBQUMsc0JBQXNCLEtBQUssUUFBUSxJQUFJLEtBQUssWUFBWSxjQUFjLEtBQUssVUFBVSxTQUFTO0FBQzdHLGFBQUssa0JBQWtCLGNBQWMsT0FBTyxFQUFFLGFBQWEsRUFBRSxrQkFBa0IsTUFBSyxFQUFFLENBQUU7TUFDNUY7O3lCQWpFUyw0Q0FBeUMsZ0NBQUEsNEJBQUEsQ0FBQTtNQUFBO2lFQUF6Qyw0Q0FBeUMsV0FBQSxDQUFBLENBQUEseUNBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSx3QkFBQSwwQkFBQSxtQkFBQSxxQkFBQSx3QkFBQSwwQkFBQSxjQUFBLGdCQUFBLFVBQUEsWUFBQSxZQUFBLGFBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsT0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsZ0JBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLFFBQUEsV0FBQSxVQUFBLFNBQUEsU0FBQSxhQUFBLGlCQUFBLHVCQUFBLFFBQUEsR0FBQSxDQUFBLG1CQUFBLEVBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxtREFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ2J0RCxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUFJLFVBQUEscUJBQUEsQ0FBQTs7QUFBd0QsVUFBQSwyQkFBQTtBQUNoRSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLDJCQUFBLENBQUE7QUFVSSxVQUFBLHlCQUFBLFVBQUEsU0FBQSw4RkFBQSxRQUFBO0FBQUEsbUJBQVUsSUFBQSxlQUFBLE1BQUE7VUFBc0IsQ0FBQTtBQUVoQyxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsbUVBQUEsR0FBQSxHQUFBLGVBQUEsTUFBQSxHQUFBLG9DQUFBO0FBSUosVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7Ozs7QUF0QlksVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSwwQkFBQSxHQUFBLElBQUEsK0JBQUEsQ0FBQTtBQUlBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsY0FBQSxLQUFBLEVBQW9CLFFBQUEsOEJBQUEsSUFBQUMsTUFBQSxJQUFBLFdBQUEsQ0FBQSxFQUFBLFdBQUEsSUFBQSxPQUFBLEVBQUEsVUFBQSxJQUFBLFFBQUEsRUFBQSxTQUFBLElBQUEsRUFBQSxTQUFBLElBQUEsRUFBQSxhQUFBLEdBQUEsRUFBQSxpQkFBQSxJQUFBLEVBQUEsdUJBQUEsSUFBQSxtQkFBQTs7Ozs7cUZET25CLDJDQUF5QyxFQUFBLFdBQUEsNENBQUEsQ0FBQTtJQUFBLEdBQUE7OzsiLCJuYW1lcyI6WyJEb3VnaG51dENoYXJ0VHlwZSIsIkNvbXBvbmVudCIsIl9jMCIsIkNvbXBvbmVudCIsIklucHV0IiwiU2NhbGVUeXBlIiwiX2MwIiwiQ29tcG9uZW50IiwiSW5wdXQiLCJTY2FsZVR5cGUiLCJfYzAiXX0=