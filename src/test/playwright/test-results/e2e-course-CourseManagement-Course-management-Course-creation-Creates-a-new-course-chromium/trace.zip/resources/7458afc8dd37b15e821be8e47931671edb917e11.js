import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NI5XS6XH.js?v=b97f8625";

// node_modules/dayjs/esm/plugin/isLeapYear/index.js
var isLeapYear_default = function(o, c) {
  var proto = c.prototype;
  proto.isLeapYear = function() {
    return this.$y % 4 === 0 && this.$y % 100 !== 0 || this.$y % 400 === 0;
  };
};
export {
  isLeapYear_default as default
};
//# sourceMappingURL=dayjs_esm_plugin_isLeapYear.js.map
