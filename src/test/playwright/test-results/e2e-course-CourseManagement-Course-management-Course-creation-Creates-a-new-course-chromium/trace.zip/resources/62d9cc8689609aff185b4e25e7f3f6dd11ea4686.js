import {
  ArtemisSharedComponentModule,
  ConfirmAutofocusModalComponent,
  FeatureToggleModule,
  ParticipationWebsocketService,
  ProgrammingExerciseTriggerBuildButtonComponent,
  ProgrammingSubmissionService,
  ProgrammingSubmissionState,
  init_confirm_autofocus_modal_component,
  init_feature_toggle_module,
  init_participation_websocket_service,
  init_programming_exercise_model,
  init_programming_exercise_student_trigger_build_button_component,
  init_programming_exercise_trigger_build_button_component,
  init_programming_submission_service,
  init_result_component,
  init_shared_component_module,
  init_submission_result_status_component,
  init_updating_result_component
} from "/chunk-ORYTP7RT.js";
import {
  AlertService,
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  ButtonComponent,
  ButtonType,
  DurationPipe,
  FeatureToggle,
  JhiWebsocketService,
  TranslateDirective,
  __esm,
  __spreadProps,
  __spreadValues,
  hasDueDatePassed,
  hasExerciseChanged,
  init_alert_service,
  init_artemis_translate_pipe,
  init_button_component,
  init_duration_pipe,
  init_exercise_utils,
  init_feature_toggle_service,
  init_programming_exercise_utils,
  init_shared_module,
  init_translate_directive,
  init_websocket_service
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/programming/shared/actions/programming-exercise-instructor-trigger-build-button.component.ts
import { Component } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import { NgbModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { faRedo } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
function ProgrammingExerciseInstructorTriggerBuildButtonComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "jhi-button", 0);
    i0.\u0275\u0275listener("onClick", function ProgrammingExerciseInstructorTriggerBuildButtonComponent_Conditional_0_Template_jhi_button_onClick_1_listener($event) {
      i0.\u0275\u0275restoreView(_r2);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.triggerBuild($event));
    });
    i0.\u0275\u0275text(2, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(3, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("btnSize", ctx_r0.btnSize)("btnType", ctx_r0.participationHasLatestSubmissionWithoutResult ? ctx_r0.ButtonType.ERROR : ctx_r0.ButtonType.PRIMARY)("icon", ctx_r0.faRedo)("disabled", ctx_r0.isRetrievingBuildStatus)("isLoading", ctx_r0.isBuilding)("tooltip", ctx_r0.participationHasLatestSubmissionWithoutResult ? "artemisApp.programmingExercise.resubmitOnFailedSubmission" : "artemisApp.programmingExercise.resubmit")("featureToggle", ctx_r0.FeatureToggle.ProgrammingExercises);
  }
}
var ProgrammingExerciseInstructorTriggerBuildButtonComponent;
var init_programming_exercise_instructor_trigger_build_button_component = __esm({
  "src/main/webapp/app/exercises/programming/shared/actions/programming-exercise-instructor-trigger-build-button.component.ts"() {
    init_programming_exercise_trigger_build_button_component();
    init_programming_submission_service();
    init_participation_websocket_service();
    init_alert_service();
    init_confirm_autofocus_modal_component();
    init_programming_submission_service();
    init_alert_service();
    init_participation_websocket_service();
    init_button_component();
    ProgrammingExerciseInstructorTriggerBuildButtonComponent = class _ProgrammingExerciseInstructorTriggerBuildButtonComponent extends ProgrammingExerciseTriggerBuildButtonComponent {
      translateService;
      modalService;
      faRedo = faRedo;
      constructor(submissionService, alertService, participationWebsocketService, translateService, modalService) {
        super(submissionService, participationWebsocketService, alertService);
        this.translateService = translateService;
        this.modalService = modalService;
        this.showForSuccessfulSubmissions = true;
        this.personalParticipation = false;
      }
      triggerBuild = (event) => {
        event.stopPropagation();
        if (this.participationHasLatestSubmissionWithoutResult) {
          super.triggerFailed().subscribe();
        } else {
          super.triggerWithType("INSTRUCTOR").subscribe();
        }
        if (!this.lastResultIsManual) {
          super.triggerWithType("INSTRUCTOR");
          return;
        }
        const modalRef = this.modalService.open(ConfirmAutofocusModalComponent, { keyboard: true, size: "lg" });
        modalRef.componentInstance.title = "artemisApp.programmingExercise.resubmitSingle";
        modalRef.componentInstance.text = this.translateService.instant("artemisApp.programmingExercise.resubmitConfirmManualResultOverride");
        modalRef.result.then(() => {
          super.triggerWithType("INSTRUCTOR");
        });
      };
      static \u0275fac = function ProgrammingExerciseInstructorTriggerBuildButtonComponent_Factory(t) {
        return new (t || _ProgrammingExerciseInstructorTriggerBuildButtonComponent)(i0.\u0275\u0275directiveInject(ProgrammingSubmissionService), i0.\u0275\u0275directiveInject(AlertService), i0.\u0275\u0275directiveInject(ParticipationWebsocketService), i0.\u0275\u0275directiveInject(i4.TranslateService), i0.\u0275\u0275directiveInject(i5.NgbModal));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _ProgrammingExerciseInstructorTriggerBuildButtonComponent, selectors: [["jhi-programming-exercise-instructor-trigger-build-button"]], features: [i0.\u0275\u0275InheritDefinitionFeature], decls: 1, vars: 1, consts: [[3, "btnSize", "btnType", "icon", "disabled", "isLoading", "tooltip", "featureToggle", "onClick"]], template: function ProgrammingExerciseInstructorTriggerBuildButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275template(0, ProgrammingExerciseInstructorTriggerBuildButtonComponent_Conditional_0_Template, 4, 7);
        }
        if (rf & 2) {
          i0.\u0275\u0275conditional(0, ctx.participationBuildCanBeTriggered && (ctx.showForSuccessfulSubmissions || ctx.participationHasLatestSubmissionWithoutResult) ? 0 : -1);
        }
      }, dependencies: [ButtonComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(ProgrammingExerciseInstructorTriggerBuildButtonComponent, { className: "ProgrammingExerciseInstructorTriggerBuildButtonComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/programming/participate/programming-build-run.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { BehaviorSubject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { filter, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var BuildRunState, ProgrammingBuildRunService;
var init_programming_build_run_service = __esm({
  "src/main/webapp/app/exercises/programming/participate/programming-build-run.service.ts"() {
    init_websocket_service();
    init_websocket_service();
    (function(BuildRunState2) {
      BuildRunState2["RUNNING"] = "RUNNING";
      BuildRunState2["COMPLETED"] = "COMPLETED";
    })(BuildRunState || (BuildRunState = {}));
    ProgrammingBuildRunService = class _ProgrammingBuildRunService {
      websocketService;
      buildRunSubjects = {};
      buildRunTopics = {};
      BUILD_RUN_TEMPLATE_TOPIC = "/topic/programming-exercises/%programmingExerciseId%/all-builds-triggered";
      constructor(websocketService) {
        this.websocketService = websocketService;
      }
      ngOnDestroy() {
        Object.values(this.buildRunSubjects).forEach((subject) => subject.unsubscribe());
      }
      notifySubscribers(programmingExerciseId, buildRunState) {
        const subject = this.buildRunSubjects[programmingExerciseId];
        if (subject) {
          subject.next(buildRunState);
        } else {
          this.buildRunSubjects[programmingExerciseId] = new BehaviorSubject(buildRunState);
        }
      }
      subscribeWebsocket(programmingExerciseId) {
        if (!this.buildRunTopics[programmingExerciseId]) {
          const newSubmissionTopic = this.BUILD_RUN_TEMPLATE_TOPIC.replace("%programmingExerciseId%", programmingExerciseId.toString());
          this.buildRunTopics[programmingExerciseId] = newSubmissionTopic;
          this.websocketService.subscribe(newSubmissionTopic);
          this.websocketService.receive(newSubmissionTopic).pipe(tap((buildRunState) => this.notifySubscribers(programmingExerciseId, buildRunState))).subscribe();
        }
      }
      getBuildRunUpdates(programmingExerciseId) {
        const subject = this.buildRunSubjects[programmingExerciseId];
        if (subject) {
          return subject.asObservable().pipe(filter((stateObj) => stateObj !== void 0));
        }
        const newSubject = new BehaviorSubject(void 0);
        this.buildRunSubjects[programmingExerciseId] = newSubject;
        this.subscribeWebsocket(programmingExerciseId);
        return newSubject.pipe(filter((stateObj) => stateObj !== void 0));
      }
      static \u0275fac = function ProgrammingBuildRunService_Factory(t) {
        return new (t || _ProgrammingBuildRunService)(i02.\u0275\u0275inject(JhiWebsocketService));
      };
      static \u0275prov = i02.\u0275\u0275defineInjectable({ token: _ProgrammingBuildRunService, factory: _ProgrammingBuildRunService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/actions/programming-exercise-trigger-all-button.component.ts
import { Component as Component2, EventEmitter, Input, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { catchError, tap as tap2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { of } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { NgbActiveModal, NgbModal as NgbModal3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { faBan, faRedo as faRedo2, faTimes } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i52 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i6 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ProgrammingExerciseInstructorTriggerAllDialogComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "p", 12);
    i03.\u0275\u0275text(2, "\n                        The due date has passed, some of the student submissions might have received manual results created by teaching assistants. Newly generated automatic\n                        results would replace the manual results as the latest result for the participation.\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                ");
  }
}
var ProgrammingExerciseTriggerAllButtonComponent, ProgrammingExerciseInstructorTriggerAllDialogComponent;
var init_programming_exercise_trigger_all_button_component = __esm({
  "src/main/webapp/app/exercises/programming/shared/actions/programming-exercise-trigger-all-button.component.ts"() {
    init_programming_submission_service();
    init_programming_exercise_utils();
    init_programming_build_run_service();
    init_feature_toggle_service();
    init_programming_exercise_model();
    init_button_component();
    init_programming_submission_service();
    init_programming_build_run_service();
    init_button_component();
    init_translate_directive();
    ProgrammingExerciseTriggerAllButtonComponent = class _ProgrammingExerciseTriggerAllButtonComponent {
      submissionService;
      programmingBuildRunService;
      modalService;
      FeatureToggle = FeatureToggle;
      ButtonType = ButtonType;
      exercise;
      disabled = false;
      onBuildTriggered = new EventEmitter();
      isTriggeringBuildAll = false;
      faRedo = faRedo2;
      constructor(submissionService, programmingBuildRunService, modalService) {
        this.submissionService = submissionService;
        this.programmingBuildRunService = programmingBuildRunService;
        this.modalService = modalService;
      }
      ngOnInit() {
        this.subscribeBuildRunUpdates();
      }
      openTriggerAllModal() {
        const modalRef = this.modalService.open(ProgrammingExerciseInstructorTriggerAllDialogComponent, { size: "lg", backdrop: "static" });
        modalRef.componentInstance.exerciseId = this.exercise.id;
        modalRef.componentInstance.dueDatePassed = hasDueDatePassed(this.exercise);
        modalRef.result.then(() => {
          this.submissionService.triggerInstructorBuildForAllParticipationsOfExercise(this.exercise.id).pipe(catchError(() => of(void 0))).subscribe(() => {
            this.onBuildTriggered.emit();
          });
        });
      }
      subscribeBuildRunUpdates() {
        this.programmingBuildRunService.getBuildRunUpdates(this.exercise.id).pipe(tap2((buildRunState) => this.isTriggeringBuildAll = buildRunState === BuildRunState.RUNNING)).subscribe();
      }
      static \u0275fac = function ProgrammingExerciseTriggerAllButtonComponent_Factory(t) {
        return new (t || _ProgrammingExerciseTriggerAllButtonComponent)(i03.\u0275\u0275directiveInject(ProgrammingSubmissionService), i03.\u0275\u0275directiveInject(ProgrammingBuildRunService), i03.\u0275\u0275directiveInject(i3.NgbModal));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _ProgrammingExerciseTriggerAllButtonComponent, selectors: [["jhi-programming-exercise-trigger-all-button"]], inputs: { exercise: "exercise", disabled: "disabled" }, outputs: { onBuildTriggered: "onBuildTriggered" }, decls: 4, vars: 7, consts: [["id", "trigger-all-button", 1, "ms-3", 3, "disabled", "btnType", "isLoading", "tooltip", "icon", "title", "featureToggle", "onClick"]], template: function ProgrammingExerciseTriggerAllButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275text(0, "\n        ");
          i03.\u0275\u0275elementStart(1, "jhi-button", 0);
          i03.\u0275\u0275listener("onClick", function ProgrammingExerciseTriggerAllButtonComponent_Template_jhi_button_onClick_1_listener() {
            return ctx.openTriggerAllModal();
          });
          i03.\u0275\u0275text(2, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(3, "\n    ");
        }
        if (rf & 2) {
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275property("disabled", ctx.disabled)("btnType", ctx.ButtonType.ERROR)("isLoading", ctx.isTriggeringBuildAll)("tooltip", "artemisApp.programmingExercise.resubmitAllTooltip")("icon", ctx.faRedo)("title", "artemisApp.programmingExercise.resubmitAll")("featureToggle", ctx.FeatureToggle.ProgrammingExercises);
        }
      }, dependencies: [ButtonComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(ProgrammingExerciseTriggerAllButtonComponent, { className: "ProgrammingExerciseTriggerAllButtonComponent" });
    })();
    ProgrammingExerciseInstructorTriggerAllDialogComponent = class _ProgrammingExerciseInstructorTriggerAllDialogComponent {
      activeModal;
      exerciseId;
      dueDatePassed;
      faBan = faBan;
      faTimes = faTimes;
      constructor(activeModal) {
        this.activeModal = activeModal;
      }
      cancel() {
        this.activeModal.dismiss("cancel");
      }
      confirmTrigger() {
        this.activeModal.close();
      }
      static \u0275fac = function ProgrammingExerciseInstructorTriggerAllDialogComponent_Factory(t) {
        return new (t || _ProgrammingExerciseInstructorTriggerAllDialogComponent)(i03.\u0275\u0275directiveInject(i3.NgbActiveModal));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _ProgrammingExerciseInstructorTriggerAllDialogComponent, selectors: [["ng-component"]], inputs: { exerciseId: "exerciseId", dueDatePassed: "dueDatePassed" }, decls: 38, vars: 3, consts: [["name", "triggerAllForm", 3, "ngSubmit"], [1, "modal-header"], ["jhiTranslate", "artemisApp.programmingExercise.resubmitAll", 1, "modal-title"], ["type", "button", "data-dismiss", "modal", "aria-hidden", "true", 1, "btn-close", 3, "click"], [1, "modal-body"], ["jhiTranslate", "artemisApp.programmingExercise.resubmitAllDialog"], [1, "modal-footer"], ["type", "button", "data-dismiss", "modal", 1, "btn", "btn-secondary", 3, "click"], [3, "icon"], ["jhiTranslate", "entity.action.cancel"], ["type", "submit", 1, "btn", "btn-danger"], ["jhiTranslate", "entity.action.confirm"], ["jhiTranslate", "artemisApp.programmingExercise.resubmitAllConfirmAfterDueDate", 1, "text-danger", "font-weight-bold"]], template: function ProgrammingExerciseInstructorTriggerAllDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275text(0, "\n        ");
          i03.\u0275\u0275elementStart(1, "form", 0);
          i03.\u0275\u0275listener("ngSubmit", function ProgrammingExerciseInstructorTriggerAllDialogComponent_Template_form_ngSubmit_1_listener() {
            return ctx.confirmTrigger();
          });
          i03.\u0275\u0275text(2, "\n            ");
          i03.\u0275\u0275elementStart(3, "div", 1);
          i03.\u0275\u0275text(4, "\n                ");
          i03.\u0275\u0275elementStart(5, "h4", 2);
          i03.\u0275\u0275text(6, "Trigger all");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(7, "\n                ");
          i03.\u0275\u0275elementStart(8, "button", 3);
          i03.\u0275\u0275listener("click", function ProgrammingExerciseInstructorTriggerAllDialogComponent_Template_button_click_8_listener() {
            return ctx.cancel();
          });
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(9, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(10, "\n            ");
          i03.\u0275\u0275elementStart(11, "div", 4);
          i03.\u0275\u0275text(12, "\n                ");
          i03.\u0275\u0275template(13, ProgrammingExerciseInstructorTriggerAllDialogComponent_Conditional_13_Template, 4, 0);
          i03.\u0275\u0275elementStart(14, "p", 5);
          i03.\u0275\u0275text(15, "\n                    WARNING: Triggering all participations again is a very expensive operation. This action will start a CI build for every participation in this exercise!\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(16, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(17, "\n            ");
          i03.\u0275\u0275elementStart(18, "div", 6);
          i03.\u0275\u0275text(19, "\n                ");
          i03.\u0275\u0275elementStart(20, "button", 7);
          i03.\u0275\u0275listener("click", function ProgrammingExerciseInstructorTriggerAllDialogComponent_Template_button_click_20_listener() {
            return ctx.cancel();
          });
          i03.\u0275\u0275text(21, "\n                    ");
          i03.\u0275\u0275element(22, "fa-icon", 8);
          i03.\u0275\u0275text(23, "\xA0");
          i03.\u0275\u0275elementStart(24, "span", 9);
          i03.\u0275\u0275text(25, "Cancel");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(26, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(27, "\n                ");
          i03.\u0275\u0275elementStart(28, "button", 10);
          i03.\u0275\u0275text(29, "\n                    ");
          i03.\u0275\u0275element(30, "fa-icon", 8);
          i03.\u0275\u0275text(31, "\xA0\n                    ");
          i03.\u0275\u0275elementStart(32, "span", 11);
          i03.\u0275\u0275text(33, "Confirm");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(34, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(35, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(36, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(37, "\n    ");
        }
        if (rf & 2) {
          i03.\u0275\u0275advance(13);
          i03.\u0275\u0275conditional(13, ctx.dueDatePassed ? 13 : -1);
          i03.\u0275\u0275advance(9);
          i03.\u0275\u0275property("icon", ctx.faBan);
          i03.\u0275\u0275advance(8);
          i03.\u0275\u0275property("icon", ctx.faTimes);
        }
      }, dependencies: [i52.\u0275NgNoValidate, i52.NgControlStatusGroup, i52.NgForm, i6.FaIconComponent, TranslateDirective], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(ProgrammingExerciseInstructorTriggerAllDialogComponent, { className: "ProgrammingExerciseInstructorTriggerAllDialogComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/programming/shared/actions/programming-exercise-instructor-submission-state.component.ts
import { Component as Component3, Input as Input2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { debounceTime, map, tap as tap3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { faCircleNotch, faClock, faRedo as faRedo3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i42 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ProgrammingExerciseInstructorSubmissionStateComponent_Conditional_0_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n            ");
    i04.\u0275\u0275elementStart(1, "div", 6);
    i04.\u0275\u0275text(2, "\n                ");
    i04.\u0275\u0275element(3, "fa-icon", 7);
    i04.\u0275\u0275text(4, "\n                ");
    i04.\u0275\u0275elementStart(5, "span", 8);
    i04.\u0275\u0275pipe(6, "artemisTranslate");
    i04.\u0275\u0275pipe(7, "artemisTranslate");
    i04.\u0275\u0275pipe(8, "duration");
    i04.\u0275\u0275text(9);
    i04.\u0275\u0275pipe(10, "duration");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(11, "\n            ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(12, "\n        ");
  }
  if (rf & 2) {
    const ctx_r2 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("icon", ctx_r2.faClock);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275property("ngbTooltip", i04.\u0275\u0275pipeBind1(6, 4, "artemisApp.programmingExercise.resultETATooltip"))("innerHTML", i04.\u0275\u0275pipeBind2(7, 6, "artemisApp.programmingExercise.resultETA", i04.\u0275\u0275pureFunction1(13, _c0, i04.\u0275\u0275pipeBind1(8, 9, ctx_r2.resultEtaInMs))), i04.\u0275\u0275sanitizeHtml);
    i04.\u0275\u0275advance(4);
    i04.\u0275\u0275textInterpolate1("Result ETA: ", i04.\u0275\u0275pipeBind1(10, 11, ctx_r2.resultEtaInMs), "");
  }
}
function ProgrammingExerciseInstructorSubmissionStateComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n    ");
    i04.\u0275\u0275elementStart(1, "div", 0);
    i04.\u0275\u0275text(2, "\n        ");
    i04.\u0275\u0275template(3, ProgrammingExerciseInstructorSubmissionStateComponent_Conditional_0_Conditional_3_Template, 13, 15);
    i04.\u0275\u0275elementStart(4, "div", 1);
    i04.\u0275\u0275text(5, "\n            ");
    i04.\u0275\u0275elementStart(6, "span", 2);
    i04.\u0275\u0275pipe(7, "artemisTranslate");
    i04.\u0275\u0275text(8);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(9, "\n            ");
    i04.\u0275\u0275elementStart(10, "span", 3);
    i04.\u0275\u0275pipe(11, "artemisTranslate");
    i04.\u0275\u0275text(12);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(13, "\n        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(14, "\n        ");
    i04.\u0275\u0275element(15, "jhi-programming-exercise-trigger-all-button", 4);
    i04.\u0275\u0275text(16, "\n        ");
    i04.\u0275\u0275elementStart(17, "jhi-button", 5);
    i04.\u0275\u0275listener("onClick", function ProgrammingExerciseInstructorSubmissionStateComponent_Conditional_0_Template_jhi_button_onClick_17_listener() {
      i04.\u0275\u0275restoreView(_r4);
      const ctx_r3 = i04.\u0275\u0275nextContext();
      return i04.\u0275\u0275resetView(ctx_r3.triggerBuildOfFailedSubmissions());
    });
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(18, "\n    ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(19, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, ctx_r0.hasBuildingSubmissions ? 3 : -1);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("innerHTML", i04.\u0275\u0275pipeBind2(7, 13, "artemisApp.programmingExercise.buildingSubmissions", i04.\u0275\u0275pureFunction1(19, _c1, ctx_r0.buildingSummary[ctx_r0.ProgrammingSubmissionState.IS_BUILDING_PENDING_SUBMISSION] || 0)), i04.\u0275\u0275sanitizeHtml);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate1("\n                Building submissions: ", ctx_r0.buildingSummary[ctx_r0.ProgrammingSubmissionState.IS_BUILDING_PENDING_SUBMISSION] || 0, "\n            ");
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275property("ngClass", i04.\u0275\u0275pureFunction1(21, _c2, ctx_r0.buildingSummary[ctx_r0.ProgrammingSubmissionState.HAS_FAILED_SUBMISSION] > 0 ? "bg-danger" : "bg-success"))("innerHTML", i04.\u0275\u0275pipeBind2(11, 16, "artemisApp.programmingExercise.failedSubmissions", i04.\u0275\u0275pureFunction1(23, _c1, ctx_r0.buildingSummary[ctx_r0.ProgrammingSubmissionState.HAS_FAILED_SUBMISSION] || 0)), i04.\u0275\u0275sanitizeHtml);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate1("\n                Failed submissions: ", ctx_r0.buildingSummary[ctx_r0.ProgrammingSubmissionState.HAS_FAILED_SUBMISSION] || 0, "\n            ");
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("exercise", ctx_r0.exercise);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275property("disabled", !ctx_r0.hasFailedSubmissions)("isLoading", ctx_r0.isBuildingFailedSubmissions)("icon", ctx_r0.faRedo)("title", "artemisApp.programmingExercise.resubmitFailed")("tooltip", "artemisApp.programmingExercise.resubmitFailedTooltip")("featureToggle", ctx_r0.FeatureToggle.ProgrammingExercises);
  }
}
function ProgrammingExerciseInstructorSubmissionStateComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n    ");
    i04.\u0275\u0275element(1, "fa-icon", 9);
    i04.\u0275\u0275text(2, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("icon", ctx_r1.faCircleNotch)("spin", true);
  }
}
var _c0, _c1, _c2, ProgrammingExerciseInstructorSubmissionStateComponent;
var init_programming_exercise_instructor_submission_state_component = __esm({
  "src/main/webapp/app/exercises/programming/shared/actions/programming-exercise-instructor-submission-state.component.ts"() {
    init_programming_submission_service();
    init_feature_toggle_service();
    init_programming_exercise_model();
    init_exercise_utils();
    init_button_component();
    init_programming_submission_service();
    init_button_component();
    init_programming_exercise_trigger_all_button_component();
    init_artemis_translate_pipe();
    init_duration_pipe();
    _c0 = (a0) => ({ eta: a0 });
    _c1 = (a0) => ({ number: a0 });
    _c2 = (a1) => ["badge", a1, "flex-grow-0"];
    ProgrammingExerciseInstructorSubmissionStateComponent = class _ProgrammingExerciseInstructorSubmissionStateComponent {
      programmingSubmissionService;
      FeatureToggle = FeatureToggle;
      ButtonType = ButtonType;
      ProgrammingSubmissionState = ProgrammingSubmissionState;
      exercise;
      hasFailedSubmissions = false;
      hasBuildingSubmissions = false;
      buildingSummary;
      isBuildingFailedSubmissions = false;
      resultEtaInMs;
      submissionStateSubscription;
      resultEtaSubscription;
      faClock = faClock;
      faCircleNotch = faCircleNotch;
      faRedo = faRedo3;
      constructor(programmingSubmissionService) {
        this.programmingSubmissionService = programmingSubmissionService;
      }
      ngOnInit() {
        this.resultEtaSubscription = this.programmingSubmissionService.getResultEtaInMs().subscribe((resultEta) => this.resultEtaInMs = resultEta);
      }
      ngOnChanges(changes) {
        if (hasExerciseChanged(changes)) {
          this.submissionStateSubscription = this.programmingSubmissionService.getSubmissionStateOfExercise(this.exercise.id).pipe(map(this.sumSubmissionStates), debounceTime(500), tap3((buildingSummary) => {
            this.buildingSummary = buildingSummary;
            this.hasFailedSubmissions = this.buildingSummary[ProgrammingSubmissionState.HAS_FAILED_SUBMISSION] > 0;
            this.hasBuildingSubmissions = this.buildingSummary[ProgrammingSubmissionState.IS_BUILDING_PENDING_SUBMISSION] > 0;
          })).subscribe();
        }
      }
      triggerBuildOfFailedSubmissions() {
        this.isBuildingFailedSubmissions = true;
        const failedSubmissionParticipations = this.programmingSubmissionService.getSubmissionCountByType(this.exercise.id, ProgrammingSubmissionState.HAS_FAILED_SUBMISSION);
        this.programmingSubmissionService.triggerInstructorBuildForParticipationsOfExercise(this.exercise.id, failedSubmissionParticipations).subscribe(() => this.isBuildingFailedSubmissions = false);
      }
      sumSubmissionStates = (buildState) => Object.values(buildState).reduce((acc, { submissionState }) => {
        return __spreadProps(__spreadValues({}, acc), { [submissionState]: (acc[submissionState] || 0) + 1 });
      }, {});
      static \u0275fac = function ProgrammingExerciseInstructorSubmissionStateComponent_Factory(t) {
        return new (t || _ProgrammingExerciseInstructorSubmissionStateComponent)(i04.\u0275\u0275directiveInject(ProgrammingSubmissionService));
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _ProgrammingExerciseInstructorSubmissionStateComponent, selectors: [["jhi-programming-exercise-instructor-submission-state"]], inputs: { exercise: "exercise" }, features: [i04.\u0275\u0275NgOnChangesFeature], decls: 2, vars: 1, consts: [[1, "d-flex"], ["id", "build-state", 1, "d-flex", "flex-column", "justify-content-between"], ["id", "build-state-building", 1, "badge", "bg-primary", "flex-grow-0", 3, "innerHTML"], ["id", "build-state-failed", 3, "ngClass", "innerHTML"], [3, "exercise"], ["id", "trigger-failed-button", 1, "ms-3", 3, "disabled", "isLoading", "icon", "title", "tooltip", "featureToggle", "onClick"], ["id", "result-eta", 1, "badge", "bg-secondary", "d-flex", "flex-column", "justify-content-between", "me-3"], [3, "icon"], [3, "ngbTooltip", "innerHTML"], [3, "icon", "spin"]], template: function ProgrammingExerciseInstructorSubmissionStateComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275template(0, ProgrammingExerciseInstructorSubmissionStateComponent_Conditional_0_Template, 20, 25)(1, ProgrammingExerciseInstructorSubmissionStateComponent_Conditional_1_Template, 3, 2);
        }
        if (rf & 2) {
          i04.\u0275\u0275conditional(0, ctx.buildingSummary ? 0 : 1);
        }
      }, dependencies: [i2.NgClass, i32.NgbTooltip, i42.FaIconComponent, ButtonComponent, ProgrammingExerciseTriggerAllButtonComponent, ArtemisTranslatePipe, DurationPipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(ProgrammingExerciseInstructorSubmissionStateComponent, { className: "ProgrammingExerciseInstructorSubmissionStateComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/programming/manage/services/programming-exercise-grading.service.ts
import { Injectable as Injectable2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient, HttpParams } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { BehaviorSubject as BehaviorSubject2, of as of2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { catchError as catchError2, map as map2, switchMap, tap as tap4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var ProgrammingExerciseTestCaseUpdate, StaticCodeAnalysisCategoryUpdate, ProgrammingExerciseGradingService;
var init_programming_exercise_grading_service = __esm({
  "src/main/webapp/app/exercises/programming/manage/services/programming-exercise-grading.service.ts"() {
    init_websocket_service();
    init_websocket_service();
    ProgrammingExerciseTestCaseUpdate = class _ProgrammingExerciseTestCaseUpdate {
      id;
      weight;
      bonusPoints;
      bonusMultiplier;
      visibility;
      constructor(id, weight, bonusPoints, bonusMultiplier, visibility) {
        this.id = id;
        this.weight = weight;
        this.bonusPoints = bonusPoints;
        this.bonusMultiplier = bonusMultiplier;
        this.visibility = visibility;
      }
      static from(testCase) {
        return new _ProgrammingExerciseTestCaseUpdate(testCase.id, testCase.weight, testCase.bonusPoints, testCase.bonusMultiplier, testCase.visibility);
      }
    };
    StaticCodeAnalysisCategoryUpdate = class _StaticCodeAnalysisCategoryUpdate {
      id;
      penalty;
      maxPenalty;
      state;
      constructor(id, penalty, maxPenalty, state) {
        this.id = id;
        this.penalty = penalty;
        this.maxPenalty = maxPenalty;
        this.state = state;
      }
      static from(category) {
        return new _StaticCodeAnalysisCategoryUpdate(category.id, category.penalty, category.maxPenalty, category.state);
      }
    };
    ProgrammingExerciseGradingService = class _ProgrammingExerciseGradingService {
      jhiWebsocketService;
      http;
      resourceUrl = "api/programming-exercises";
      connections = {};
      subjects = {};
      testCases = /* @__PURE__ */ new Map();
      constructor(jhiWebsocketService, http) {
        this.jhiWebsocketService = jhiWebsocketService;
        this.http = http;
      }
      ngOnDestroy() {
        Object.values(this.connections).forEach((connection) => this.jhiWebsocketService.unsubscribe(connection));
      }
      subscribeForTestCases(exerciseId) {
        if (this.subjects[exerciseId]) {
          return this.subjects[exerciseId];
        }
        return this.getTestCases(exerciseId).pipe(map2((testCases) => testCases.length ? testCases : void 0), catchError2(() => of2(void 0)), switchMap((testCases) => {
          if (testCases) {
            this.testCases.set(exerciseId, testCases);
          }
          return this.initTestCaseSubscription(exerciseId, testCases);
        }));
      }
      notifyTestCases(exerciseId, testCases) {
        if (this.subjects[exerciseId]) {
          this.subjects[exerciseId].next(testCases);
        }
      }
      getTestCases(exerciseId) {
        if (this.testCases.has(exerciseId)) {
          return of2(this.testCases.get(exerciseId));
        }
        return this.http.get(`${this.resourceUrl}/${exerciseId}/test-cases`).pipe(tap4((testCases) => {
          this.testCases.set(exerciseId, testCases);
        }));
      }
      updateTestCase(exerciseId, updates) {
        return this.http.patch(`${this.resourceUrl}/${exerciseId}/update-test-cases`, updates);
      }
      getGradingStatistics(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/grading/statistics`);
      }
      resetTestCases(exerciseId) {
        return this.http.patch(`${this.resourceUrl}/${exerciseId}/test-cases/reset`, {});
      }
      reEvaluate(exerciseId) {
        return this.http.put(`${this.resourceUrl}/${exerciseId}/grading/re-evaluate`, {});
      }
      initTestCaseSubscription(exerciseId, initialValue) {
        const testCaseTopic = `/topic/programming-exercises/${exerciseId}/test-cases`;
        this.jhiWebsocketService.subscribe(testCaseTopic);
        this.connections[exerciseId] = testCaseTopic;
        this.subjects[exerciseId] = new BehaviorSubject2(initialValue);
        this.jhiWebsocketService.receive(testCaseTopic).pipe(map2((testCases) => testCases.length ? testCases : void 0), tap4((testCases) => {
          if (testCases) {
            this.testCases.set(exerciseId, testCases);
          }
          this.notifySubscribers(exerciseId, testCases);
        })).subscribe();
        return this.subjects[exerciseId];
      }
      notifySubscribers(exerciseId, testCases) {
        this.subjects[exerciseId].next(testCases);
      }
      getCodeAnalysisCategories(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/static-code-analysis-categories`);
      }
      updateCodeAnalysisCategories(exerciseId, updates) {
        return this.http.patch(`${this.resourceUrl}/${exerciseId}/static-code-analysis-categories`, updates);
      }
      resetCategories(exerciseId) {
        return this.http.patch(`${this.resourceUrl}/${exerciseId}/static-code-analysis-categories/reset`, {});
      }
      importCategoriesFromExercise(targetExerciseId, sourceExerciseId) {
        const params = new HttpParams().set("sourceExerciseId", sourceExerciseId);
        return this.http.patch(`${this.resourceUrl}/${targetExerciseId}/static-code-analysis-categories/import`, {}, { params });
      }
      static \u0275fac = function ProgrammingExerciseGradingService_Factory(t) {
        return new (t || _ProgrammingExerciseGradingService)(i05.\u0275\u0275inject(JhiWebsocketService), i05.\u0275\u0275inject(i22.HttpClient));
      };
      static \u0275prov = i05.\u0275\u0275defineInjectable({ token: _ProgrammingExerciseGradingService, factory: _ProgrammingExerciseGradingService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/actions/programming-exercise-re-evaluate-button.component.ts
import { Component as Component4, Input as Input3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faRedo as faRedo4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ProgrammingExerciseReEvaluateButtonComponent;
var init_programming_exercise_re_evaluate_button_component = __esm({
  "src/main/webapp/app/exercises/programming/shared/actions/programming-exercise-re-evaluate-button.component.ts"() {
    init_alert_service();
    init_programming_exercise_grading_service();
    init_feature_toggle_service();
    init_programming_exercise_model();
    init_button_component();
    init_programming_exercise_grading_service();
    init_alert_service();
    init_button_component();
    ProgrammingExerciseReEvaluateButtonComponent = class _ProgrammingExerciseReEvaluateButtonComponent {
      testCaseService;
      alertService;
      FeatureToggle = FeatureToggle;
      ButtonType = ButtonType;
      exercise;
      disabled = false;
      isReEvaluationRunning = false;
      faRedo = faRedo4;
      constructor(testCaseService, alertService) {
        this.testCaseService = testCaseService;
        this.alertService = alertService;
      }
      triggerReEvaluate() {
        this.isReEvaluationRunning = true;
        this.testCaseService.reEvaluate(this.exercise.id).subscribe({
          next: (updatedResultsCount) => {
            this.isReEvaluationRunning = false;
            this.alertService.success(`artemisApp.programmingExercise.reEvaluateSuccessful`, { number: updatedResultsCount });
          },
          error: (error) => {
            this.isReEvaluationRunning = false;
            this.alertService.error(`artemisApp.programmingExercise.reEvaluateFailed`, { message: error.message });
          }
        });
      }
      static \u0275fac = function ProgrammingExerciseReEvaluateButtonComponent_Factory(t) {
        return new (t || _ProgrammingExerciseReEvaluateButtonComponent)(i06.\u0275\u0275directiveInject(ProgrammingExerciseGradingService), i06.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i06.\u0275\u0275defineComponent({ type: _ProgrammingExerciseReEvaluateButtonComponent, selectors: [["jhi-programming-exercise-re-evaluate-button"]], inputs: { exercise: "exercise", disabled: "disabled" }, decls: 4, vars: 7, consts: [["id", "re-evaluate-button", 1, "ms-3", 3, "disabled", "btnType", "isLoading", "tooltip", "icon", "title", "featureToggle", "onClick"]], template: function ProgrammingExerciseReEvaluateButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          i06.\u0275\u0275text(0, "\n        ");
          i06.\u0275\u0275elementStart(1, "jhi-button", 0);
          i06.\u0275\u0275listener("onClick", function ProgrammingExerciseReEvaluateButtonComponent_Template_jhi_button_onClick_1_listener() {
            return ctx.triggerReEvaluate();
          });
          i06.\u0275\u0275text(2, "\n        ");
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(3, "\n    ");
        }
        if (rf & 2) {
          i06.\u0275\u0275advance(1);
          i06.\u0275\u0275property("disabled", ctx.disabled || ctx.isReEvaluationRunning)("btnType", ctx.ButtonType.ERROR)("isLoading", ctx.isReEvaluationRunning)("tooltip", "artemisApp.programmingExercise.reEvaluateTooltip")("icon", ctx.faRedo)("title", "artemisApp.programmingExercise.reEvaluate")("featureToggle", ctx.FeatureToggle.ProgrammingExercises);
        }
      }, dependencies: [ButtonComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i06.\u0275setClassDebugInfo(ProgrammingExerciseReEvaluateButtonComponent, { className: "ProgrammingExerciseReEvaluateButtonComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/programming/shared/actions/programming-exercise-actions.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisProgrammingExerciseActionsModule;
var init_programming_exercise_actions_module = __esm({
  "src/main/webapp/app/exercises/programming/shared/actions/programming-exercise-actions.module.ts"() {
    init_shared_module();
    init_programming_exercise_instructor_trigger_build_button_component();
    init_programming_exercise_student_trigger_build_button_component();
    init_programming_exercise_instructor_submission_state_component();
    init_programming_exercise_trigger_all_button_component();
    init_programming_exercise_re_evaluate_button_component();
    init_shared_component_module();
    init_feature_toggle_module();
    ArtemisProgrammingExerciseActionsModule = class _ArtemisProgrammingExerciseActionsModule {
      static \u0275fac = function ArtemisProgrammingExerciseActionsModule_Factory(t) {
        return new (t || _ArtemisProgrammingExerciseActionsModule)();
      };
      static \u0275mod = i07.\u0275\u0275defineNgModule({ type: _ArtemisProgrammingExerciseActionsModule });
      static \u0275inj = i07.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, ArtemisSharedComponentModule, FeatureToggleModule] });
    };
  }
});

// src/main/webapp/app/overview/submission-result-status.module.ts
import { NgModule as NgModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i08 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var SubmissionResultStatusModule;
var init_submission_result_status_module = __esm({
  "src/main/webapp/app/overview/submission-result-status.module.ts"() {
    init_shared_module();
    init_submission_result_status_component();
    init_updating_result_component();
    init_programming_exercise_actions_module();
    init_result_component();
    SubmissionResultStatusModule = class _SubmissionResultStatusModule {
      static \u0275fac = function SubmissionResultStatusModule_Factory(t) {
        return new (t || _SubmissionResultStatusModule)();
      };
      static \u0275mod = i08.\u0275\u0275defineNgModule({ type: _SubmissionResultStatusModule });
      static \u0275inj = i08.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, ArtemisProgrammingExerciseActionsModule] });
    };
  }
});

export {
  ProgrammingExerciseInstructorTriggerBuildButtonComponent,
  init_programming_exercise_instructor_trigger_build_button_component,
  ProgrammingExerciseTriggerAllButtonComponent,
  init_programming_exercise_trigger_all_button_component,
  ProgrammingExerciseInstructorSubmissionStateComponent,
  init_programming_exercise_instructor_submission_state_component,
  ProgrammingExerciseTestCaseUpdate,
  StaticCodeAnalysisCategoryUpdate,
  ProgrammingExerciseGradingService,
  init_programming_exercise_grading_service,
  ProgrammingExerciseReEvaluateButtonComponent,
  init_programming_exercise_re_evaluate_button_component,
  ArtemisProgrammingExerciseActionsModule,
  init_programming_exercise_actions_module,
  SubmissionResultStatusModule,
  init_submission_result_status_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9hY3Rpb25zL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWluc3RydWN0b3ItdHJpZ2dlci1idWlsZC1idXR0b24uY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2FjdGlvbnMvcHJvZ3JhbW1pbmctZXhlcmNpc2UtdHJpZ2dlci1idWlsZC1idXR0b24uY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9wYXJ0aWNpcGF0ZS9wcm9ncmFtbWluZy1idWlsZC1ydW4uc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9hY3Rpb25zL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXRyaWdnZXItYWxsLWJ1dHRvbi5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvYWN0aW9ucy9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdG9yLXN1Ym1pc3Npb24tc3RhdGUuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2FjdGlvbnMvcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rvci1zdWJtaXNzaW9uLXN0YXRlLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvbWFuYWdlL3NlcnZpY2VzL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWdyYWRpbmcuc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9hY3Rpb25zL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXJlLWV2YWx1YXRlLWJ1dHRvbi5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvYWN0aW9ucy9wcm9ncmFtbWluZy1leGVyY2lzZS1hY3Rpb25zLm1vZHVsZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvb3ZlcnZpZXcvc3VibWlzc2lvbi1yZXN1bHQtc3RhdHVzLm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFRyYW5zbGF0ZVNlcnZpY2UgfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2VUcmlnZ2VyQnVpbGRCdXR0b25Db21wb25lbnQgfSBmcm9tICcuL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXRyaWdnZXItYnVpbGQtYnV0dG9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ1N1Ym1pc3Npb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9wYXJ0aWNpcGF0ZS9wcm9ncmFtbWluZy1zdWJtaXNzaW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgTmdiTW9kYWwgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgeyBQYXJ0aWNpcGF0aW9uV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9vdmVydmlldy9wYXJ0aWNpcGF0aW9uLXdlYnNvY2tldC5zZXJ2aWNlJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5pbXBvcnQgeyBTdWJtaXNzaW9uVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IENvbmZpcm1BdXRvZm9jdXNNb2RhbENvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9jb25maXJtLWF1dG9mb2N1cy1tb2RhbC5jb21wb25lbnQnO1xuaW1wb3J0IHsgZmFSZWRvIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rvci10cmlnZ2VyLWJ1aWxkLWJ1dHRvbicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXRyaWdnZXItYnVpbGQtYnV0dG9uLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0b3JUcmlnZ2VyQnVpbGRCdXR0b25Db21wb25lbnQgZXh0ZW5kcyBQcm9ncmFtbWluZ0V4ZXJjaXNlVHJpZ2dlckJ1aWxkQnV0dG9uQ29tcG9uZW50IHtcbiAgICAvLyBJY29uc1xuICAgIGZhUmVkbyA9IGZhUmVkbztcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBzdWJtaXNzaW9uU2VydmljZTogUHJvZ3JhbW1pbmdTdWJtaXNzaW9uU2VydmljZSxcbiAgICAgICAgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgICAgIHBhcnRpY2lwYXRpb25XZWJzb2NrZXRTZXJ2aWNlOiBQYXJ0aWNpcGF0aW9uV2Vic29ja2V0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSB0cmFuc2xhdGVTZXJ2aWNlOiBUcmFuc2xhdGVTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIG1vZGFsU2VydmljZTogTmdiTW9kYWwsXG4gICAgKSB7XG4gICAgICAgIHN1cGVyKHN1Ym1pc3Npb25TZXJ2aWNlLCBwYXJ0aWNpcGF0aW9uV2Vic29ja2V0U2VydmljZSwgYWxlcnRTZXJ2aWNlKTtcbiAgICAgICAgdGhpcy5zaG93Rm9yU3VjY2Vzc2Z1bFN1Ym1pc3Npb25zID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5wZXJzb25hbFBhcnRpY2lwYXRpb24gPSBmYWxzZTtcbiAgICB9XG5cbiAgICB0cmlnZ2VyQnVpbGQgPSAoZXZlbnQ6IGFueSkgPT4ge1xuICAgICAgICAvLyBUaGUgYnV0dG9uIG1pZ2h0IGJlIHBsYWNlZCBpbiBvdGhlciBlbGVtZW50cyB0aGF0IGhhdmUgYSBjbGljayBsaXN0ZW5lciwgc28gY2F0Y2ggdGhlIGNsaWNrIGhlcmUuXG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBpZiAodGhpcy5wYXJ0aWNpcGF0aW9uSGFzTGF0ZXN0U3VibWlzc2lvbldpdGhvdXRSZXN1bHQpIHtcbiAgICAgICAgICAgIHN1cGVyLnRyaWdnZXJGYWlsZWQoKS5zdWJzY3JpYmUoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHN1cGVyLnRyaWdnZXJXaXRoVHlwZShTdWJtaXNzaW9uVHlwZS5JTlNUUlVDVE9SKS5zdWJzY3JpYmUoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMubGFzdFJlc3VsdElzTWFudWFsKSB7XG4gICAgICAgICAgICBzdXBlci50cmlnZ2VyV2l0aFR5cGUoU3VibWlzc2lvblR5cGUuSU5TVFJVQ1RPUik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gVGhlIGluc3RydWN0b3IgbmVlZHMgdG8gY29uZmlybSBvdmVycmlkaW5nIGEgbWFudWFsIHJlc3VsdC5cbiAgICAgICAgY29uc3QgbW9kYWxSZWYgPSB0aGlzLm1vZGFsU2VydmljZS5vcGVuKENvbmZpcm1BdXRvZm9jdXNNb2RhbENvbXBvbmVudCwgeyBrZXlib2FyZDogdHJ1ZSwgc2l6ZTogJ2xnJyB9KTtcbiAgICAgICAgbW9kYWxSZWYuY29tcG9uZW50SW5zdGFuY2UudGl0bGUgPSAnYXJ0ZW1pc0FwcC5wcm9ncmFtbWluZ0V4ZXJjaXNlLnJlc3VibWl0U2luZ2xlJztcbiAgICAgICAgbW9kYWxSZWYuY29tcG9uZW50SW5zdGFuY2UudGV4dCA9IHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KCdhcnRlbWlzQXBwLnByb2dyYW1taW5nRXhlcmNpc2UucmVzdWJtaXRDb25maXJtTWFudWFsUmVzdWx0T3ZlcnJpZGUnKTtcbiAgICAgICAgbW9kYWxSZWYucmVzdWx0LnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgc3VwZXIudHJpZ2dlcldpdGhUeXBlKFN1Ym1pc3Npb25UeXBlLklOU1RSVUNUT1IpO1xuICAgICAgICB9KTtcbiAgICB9O1xufVxuIiwiQGlmIChwYXJ0aWNpcGF0aW9uQnVpbGRDYW5CZVRyaWdnZXJlZCAmJiAoc2hvd0ZvclN1Y2Nlc3NmdWxTdWJtaXNzaW9ucyB8fCBwYXJ0aWNpcGF0aW9uSGFzTGF0ZXN0U3VibWlzc2lvbldpdGhvdXRSZXN1bHQpKSB7XG4gICAgPGpoaS1idXR0b25cbiAgICAgICAgW2J0blNpemVdPVwiYnRuU2l6ZVwiXG4gICAgICAgIFtidG5UeXBlXT1cInBhcnRpY2lwYXRpb25IYXNMYXRlc3RTdWJtaXNzaW9uV2l0aG91dFJlc3VsdCA/IEJ1dHRvblR5cGUuRVJST1IgOiBCdXR0b25UeXBlLlBSSU1BUllcIlxuICAgICAgICBbaWNvbl09XCJmYVJlZG9cIlxuICAgICAgICBbZGlzYWJsZWRdPVwiaXNSZXRyaWV2aW5nQnVpbGRTdGF0dXNcIlxuICAgICAgICBbaXNMb2FkaW5nXT1cImlzQnVpbGRpbmdcIlxuICAgICAgICAob25DbGljayk9XCJ0cmlnZ2VyQnVpbGQoJGV2ZW50KVwiXG4gICAgICAgIFt0b29sdGlwXT1cInBhcnRpY2lwYXRpb25IYXNMYXRlc3RTdWJtaXNzaW9uV2l0aG91dFJlc3VsdCA/ICdhcnRlbWlzQXBwLnByb2dyYW1taW5nRXhlcmNpc2UucmVzdWJtaXRPbkZhaWxlZFN1Ym1pc3Npb24nIDogJ2FydGVtaXNBcHAucHJvZ3JhbW1pbmdFeGVyY2lzZS5yZXN1Ym1pdCdcIlxuICAgICAgICBbZmVhdHVyZVRvZ2dsZV09XCJGZWF0dXJlVG9nZ2xlLlByb2dyYW1taW5nRXhlcmNpc2VzXCJcbiAgICA+XG4gICAgPC9qaGktYnV0dG9uPlxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgT25EZXN0cm95IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBCZWhhdmlvclN1YmplY3QsIE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IGZpbHRlciwgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgSmhpV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3dlYnNvY2tldC93ZWJzb2NrZXQuc2VydmljZSc7XG5cbi8qKlxuICogRGVzY3JpYmVzIHRoZSBidWlsZCBydW4gc3RhdGVcbiAqL1xuZXhwb3J0IGVudW0gQnVpbGRSdW5TdGF0ZSB7XG4gICAgUlVOTklORyA9ICdSVU5OSU5HJyxcbiAgICBDT01QTEVURUQgPSAnQ09NUExFVEVEJyxcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJUHJvZ3JhbW1pbmdCdWlsZFJ1blNlcnZpY2Uge1xuICAgIC8qKlxuICAgICAqIFN1YnNjcmliZSBmb3IgdXBkYXRlcyBvbiBydW5uaW5nIGJ1aWxkIHJ1bnMuIEF0bSB3ZSBhc3N1bWUgdGhhdCBvbmx5IGJ1aWxkIHJ1biBpcyBydW5uaW5nIGZvciB0aGUgd2hvbGUgZXhlcmNpc2UuXG4gICAgICogQHBhcmFtIHByb2dyYW1taW5nRXhlcmNpc2VJZFxuICAgICAqL1xuICAgIGdldEJ1aWxkUnVuVXBkYXRlcyhwcm9ncmFtbWluZ0V4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8QnVpbGRSdW5TdGF0ZT47XG59XG5cbi8qKlxuICogUHJvdmlkZXMgbWV0aG9kcyB0byByZXRyaWV2ZSBpbmZvcm1hdGlvbiBhYm91dCBydW5uaW5nIGV4ZXJjaXNlIGJ1aWxkcy5cbiAqL1xuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBQcm9ncmFtbWluZ0J1aWxkUnVuU2VydmljZSBpbXBsZW1lbnRzIE9uRGVzdHJveSB7XG4gICAgLy8gQm9vbGVhbiBzdWJqZWN0OiB0cnVlID09IGJ1aWxkIGlzIHJ1bm5pbmcsIGZhbHNlID09IGJ1aWxkIGlzIG5vdCBydW5uaW5nLlxuICAgIHByaXZhdGUgYnVpbGRSdW5TdWJqZWN0czogeyBbcHJvZ3JhbW1pbmdFeGVyY2lzZUlkOiBudW1iZXJdOiBCZWhhdmlvclN1YmplY3Q8QnVpbGRSdW5TdGF0ZSB8IHVuZGVmaW5lZD4gfSA9IHt9O1xuICAgIHByaXZhdGUgYnVpbGRSdW5Ub3BpY3M6IHsgW3Byb2dyYW1taW5nRXhlcmNpc2VJZDogbnVtYmVyXTogc3RyaW5nIH0gPSB7fTtcblxuICAgIHByaXZhdGUgQlVJTERfUlVOX1RFTVBMQVRFX1RPUElDID0gJy90b3BpYy9wcm9ncmFtbWluZy1leGVyY2lzZXMvJXByb2dyYW1taW5nRXhlcmNpc2VJZCUvYWxsLWJ1aWxkcy10cmlnZ2VyZWQnO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSB3ZWJzb2NrZXRTZXJ2aWNlOiBKaGlXZWJzb2NrZXRTZXJ2aWNlKSB7fVxuXG4gICAgLyoqXG4gICAgICogVW5zdWJzY3JpYmUgYWxsIGJ1aWxkUnVuU3ViamVjdHNcbiAgICAgKi9cbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcbiAgICAgICAgT2JqZWN0LnZhbHVlcyh0aGlzLmJ1aWxkUnVuU3ViamVjdHMpLmZvckVhY2goKHN1YmplY3QpID0+IHN1YmplY3QudW5zdWJzY3JpYmUoKSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBub3RpZnlTdWJzY3JpYmVycyhwcm9ncmFtbWluZ0V4ZXJjaXNlSWQ6IG51bWJlciwgYnVpbGRSdW5TdGF0ZTogQnVpbGRSdW5TdGF0ZSkge1xuICAgICAgICBjb25zdCBzdWJqZWN0ID0gdGhpcy5idWlsZFJ1blN1YmplY3RzW3Byb2dyYW1taW5nRXhlcmNpc2VJZF07XG4gICAgICAgIGlmIChzdWJqZWN0KSB7XG4gICAgICAgICAgICBzdWJqZWN0Lm5leHQoYnVpbGRSdW5TdGF0ZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmJ1aWxkUnVuU3ViamVjdHNbcHJvZ3JhbW1pbmdFeGVyY2lzZUlkXSA9IG5ldyBCZWhhdmlvclN1YmplY3Q8QnVpbGRSdW5TdGF0ZSB8IHVuZGVmaW5lZD4oYnVpbGRSdW5TdGF0ZSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIHN1YnNjcmliZVdlYnNvY2tldChwcm9ncmFtbWluZ0V4ZXJjaXNlSWQ6IG51bWJlcikge1xuICAgICAgICBpZiAoIXRoaXMuYnVpbGRSdW5Ub3BpY3NbcHJvZ3JhbW1pbmdFeGVyY2lzZUlkXSkge1xuICAgICAgICAgICAgY29uc3QgbmV3U3VibWlzc2lvblRvcGljID0gdGhpcy5CVUlMRF9SVU5fVEVNUExBVEVfVE9QSUMucmVwbGFjZSgnJXByb2dyYW1taW5nRXhlcmNpc2VJZCUnLCBwcm9ncmFtbWluZ0V4ZXJjaXNlSWQudG9TdHJpbmcoKSk7XG4gICAgICAgICAgICB0aGlzLmJ1aWxkUnVuVG9waWNzW3Byb2dyYW1taW5nRXhlcmNpc2VJZF0gPSBuZXdTdWJtaXNzaW9uVG9waWM7XG4gICAgICAgICAgICB0aGlzLndlYnNvY2tldFNlcnZpY2Uuc3Vic2NyaWJlKG5ld1N1Ym1pc3Npb25Ub3BpYyk7XG4gICAgICAgICAgICB0aGlzLndlYnNvY2tldFNlcnZpY2VcbiAgICAgICAgICAgICAgICAucmVjZWl2ZShuZXdTdWJtaXNzaW9uVG9waWMpXG4gICAgICAgICAgICAgICAgLy8gQXRtIHdlIG9ubHkgZ2V0IHRoZSBtZXNzYWdlIGFib3V0IGNvbXBsZXRlZCBidWlsZHMgZnJvbSB0aGUgc2VydmVyLlxuICAgICAgICAgICAgICAgIC5waXBlKHRhcCgoYnVpbGRSdW5TdGF0ZTogQnVpbGRSdW5TdGF0ZSkgPT4gdGhpcy5ub3RpZnlTdWJzY3JpYmVycyhwcm9ncmFtbWluZ0V4ZXJjaXNlSWQsIGJ1aWxkUnVuU3RhdGUpKSlcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTdWJzY3JpYmUgZm9yIHVwZGF0ZXMgb24gcnVubmluZyBidWlsZCBydW5zLiBBdG0gd2UgYXNzdW1lIHRoYXQgb25seSBidWlsZCBydW4gaXMgcnVubmluZyBmb3IgdGhlIHdob2xlIGV4ZXJjaXNlLlxuICAgICAqXG4gICAgICogQHBhcmFtIHByb2dyYW1taW5nRXhlcmNpc2VJZFxuICAgICAqL1xuICAgIGdldEJ1aWxkUnVuVXBkYXRlcyhwcm9ncmFtbWluZ0V4ZXJjaXNlSWQ6IG51bWJlcikge1xuICAgICAgICBjb25zdCBzdWJqZWN0ID0gdGhpcy5idWlsZFJ1blN1YmplY3RzW3Byb2dyYW1taW5nRXhlcmNpc2VJZF07XG4gICAgICAgIGlmIChzdWJqZWN0KSB7XG4gICAgICAgICAgICByZXR1cm4gc3ViamVjdC5hc09ic2VydmFibGUoKS5waXBlKGZpbHRlcigoc3RhdGVPYmopID0+IHN0YXRlT2JqICE9PSB1bmRlZmluZWQpKSBhcyBPYnNlcnZhYmxlPEJ1aWxkUnVuU3RhdGU+O1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5ld1N1YmplY3QgPSBuZXcgQmVoYXZpb3JTdWJqZWN0PEJ1aWxkUnVuU3RhdGUgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gICAgICAgIHRoaXMuYnVpbGRSdW5TdWJqZWN0c1twcm9ncmFtbWluZ0V4ZXJjaXNlSWRdID0gbmV3U3ViamVjdDtcbiAgICAgICAgdGhpcy5zdWJzY3JpYmVXZWJzb2NrZXQocHJvZ3JhbW1pbmdFeGVyY2lzZUlkKTtcbiAgICAgICAgcmV0dXJuIG5ld1N1YmplY3QucGlwZShmaWx0ZXIoKHN0YXRlT2JqKSA9PiBzdGF0ZU9iaiAhPT0gdW5kZWZpbmVkKSkgYXMgT2JzZXJ2YWJsZTxCdWlsZFJ1blN0YXRlPjtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCB0YXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ1N1Ym1pc3Npb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9wYXJ0aWNpcGF0ZS9wcm9ncmFtbWluZy1zdWJtaXNzaW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgb2YgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IE5nYkFjdGl2ZU1vZGFsLCBOZ2JNb2RhbCB9IGZyb20gJ0BuZy1ib290c3RyYXAvbmctYm9vdHN0cmFwJztcbmltcG9ydCB7IGhhc0R1ZURhdGVQYXNzZWQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC91dGlscy9wcm9ncmFtbWluZy1leGVyY2lzZS51dGlscyc7XG5pbXBvcnQgeyBCdWlsZFJ1blN0YXRlLCBQcm9ncmFtbWluZ0J1aWxkUnVuU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvcGFydGljaXBhdGUvcHJvZ3JhbW1pbmctYnVpbGQtcnVuLnNlcnZpY2UnO1xuaW1wb3J0IHsgRmVhdHVyZVRvZ2dsZSB9IGZyb20gJ2FwcC9zaGFyZWQvZmVhdHVyZS10b2dnbGUvZmVhdHVyZS10b2dnbGUuc2VydmljZSc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3Byb2dyYW1taW5nLWV4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IEJ1dHRvblR5cGUgfSBmcm9tICdhcHAvc2hhcmVkL2NvbXBvbmVudHMvYnV0dG9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBmYUJhbiwgZmFSZWRvLCBmYVRpbWVzIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcblxuLyoqXG4gKiBBIGJ1dHRvbiB0aGF0IHRyaWdnZXJzIHRoZSBidWlsZCBmb3IgYWxsIHBhcnRpY2lwYXRpb25zIG9mIHRoZSBnaXZlbiBwcm9ncmFtbWluZyBleGVyY2lzZS5cbiAqL1xuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktcHJvZ3JhbW1pbmctZXhlcmNpc2UtdHJpZ2dlci1hbGwtYnV0dG9uJyxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICA8amhpLWJ1dHRvblxuICAgICAgICAgICAgaWQ9XCJ0cmlnZ2VyLWFsbC1idXR0b25cIlxuICAgICAgICAgICAgY2xhc3M9XCJtcy0zXCJcbiAgICAgICAgICAgIFtkaXNhYmxlZF09XCJkaXNhYmxlZFwiXG4gICAgICAgICAgICBbYnRuVHlwZV09XCJCdXR0b25UeXBlLkVSUk9SXCJcbiAgICAgICAgICAgIFtpc0xvYWRpbmddPVwiaXNUcmlnZ2VyaW5nQnVpbGRBbGxcIlxuICAgICAgICAgICAgW3Rvb2x0aXBdPVwiJ2FydGVtaXNBcHAucHJvZ3JhbW1pbmdFeGVyY2lzZS5yZXN1Ym1pdEFsbFRvb2x0aXAnXCJcbiAgICAgICAgICAgIFtpY29uXT1cImZhUmVkb1wiXG4gICAgICAgICAgICBbdGl0bGVdPVwiJ2FydGVtaXNBcHAucHJvZ3JhbW1pbmdFeGVyY2lzZS5yZXN1Ym1pdEFsbCdcIlxuICAgICAgICAgICAgW2ZlYXR1cmVUb2dnbGVdPVwiRmVhdHVyZVRvZ2dsZS5Qcm9ncmFtbWluZ0V4ZXJjaXNlc1wiXG4gICAgICAgICAgICAob25DbGljayk9XCJvcGVuVHJpZ2dlckFsbE1vZGFsKClcIlxuICAgICAgICA+XG4gICAgICAgIDwvamhpLWJ1dHRvbj5cbiAgICBgLFxufSlcbmV4cG9ydCBjbGFzcyBQcm9ncmFtbWluZ0V4ZXJjaXNlVHJpZ2dlckFsbEJ1dHRvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgRmVhdHVyZVRvZ2dsZSA9IEZlYXR1cmVUb2dnbGU7XG4gICAgQnV0dG9uVHlwZSA9IEJ1dHRvblR5cGU7XG4gICAgQElucHV0KCkgZXhlcmNpc2U6IFByb2dyYW1taW5nRXhlcmNpc2U7XG4gICAgQElucHV0KCkgZGlzYWJsZWQgPSBmYWxzZTtcbiAgICBAT3V0cHV0KCkgb25CdWlsZFRyaWdnZXJlZCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgICBpc1RyaWdnZXJpbmdCdWlsZEFsbCA9IGZhbHNlO1xuICAgIC8vIEljb25zXG4gICAgZmFSZWRvID0gZmFSZWRvO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgc3VibWlzc2lvblNlcnZpY2U6IFByb2dyYW1taW5nU3VibWlzc2lvblNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgcHJvZ3JhbW1pbmdCdWlsZFJ1blNlcnZpY2U6IFByb2dyYW1taW5nQnVpbGRSdW5TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIG1vZGFsU2VydmljZTogTmdiTW9kYWwsXG4gICAgKSB7fVxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIC8vIFRoZSBpbmZvIHRoYXQgdGhlIGJ1aWxkcyB3ZXJlIHRyaWdnZXJlZCBjb21lcyBmcm9tIGEgd2Vic29ja2V0IGNoYW5uZWwuXG4gICAgICAgIHRoaXMuc3Vic2NyaWJlQnVpbGRSdW5VcGRhdGVzKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogT3BlbnMgYSBtb2RhbCBpbiB0aGF0IHRoZSB1c2VyIGhhcyB0byBjb25maXJtIHRvIHRyaWdnZXIgYWxsIHBhcnRpY2lwYXRpb25zLlxuICAgICAqIFRoaXMgY29uZmlybWF0aW9uIGlzIG5lZWRlZCBhcyB0aGlzIGlzIGEgcGVyZm9ybWFuY2UgaW50ZW5zaXZlIGFjdGlvbiBhbmQgcHV0cyBoZWF2eSBsb2FkIG9uIG91ciBidWlsZCBzeXN0ZW1cbiAgICAgKiBhbmQgd2lsbCBjcmVhdGUgbmV3IHJlc3VsdHMgZm9yIHRoZSBzdHVkZW50cyAod2hpY2ggY291bGQgYmUgY29uZnVzaW5nIHRvIHRoZW0pLlxuICAgICAqL1xuICAgIG9wZW5UcmlnZ2VyQWxsTW9kYWwoKSB7XG4gICAgICAgIGNvbnN0IG1vZGFsUmVmID0gdGhpcy5tb2RhbFNlcnZpY2Uub3BlbihQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3RvclRyaWdnZXJBbGxEaWFsb2dDb21wb25lbnQsIHsgc2l6ZTogJ2xnJywgYmFja2Ryb3A6ICdzdGF0aWMnIH0pO1xuICAgICAgICBtb2RhbFJlZi5jb21wb25lbnRJbnN0YW5jZS5leGVyY2lzZUlkID0gdGhpcy5leGVyY2lzZS5pZDtcbiAgICAgICAgbW9kYWxSZWYuY29tcG9uZW50SW5zdGFuY2UuZHVlRGF0ZVBhc3NlZCA9IGhhc0R1ZURhdGVQYXNzZWQodGhpcy5leGVyY2lzZSk7XG4gICAgICAgIG1vZGFsUmVmLnJlc3VsdC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuc3VibWlzc2lvblNlcnZpY2VcbiAgICAgICAgICAgICAgICAudHJpZ2dlckluc3RydWN0b3JCdWlsZEZvckFsbFBhcnRpY2lwYXRpb25zT2ZFeGVyY2lzZSh0aGlzLmV4ZXJjaXNlLmlkISlcbiAgICAgICAgICAgICAgICAucGlwZShjYXRjaEVycm9yKCgpID0+IG9mKHVuZGVmaW5lZCkpKVxuICAgICAgICAgICAgICAgIC5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uQnVpbGRUcmlnZ2VyZWQuZW1pdCgpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHN1YnNjcmliZUJ1aWxkUnVuVXBkYXRlcygpIHtcbiAgICAgICAgdGhpcy5wcm9ncmFtbWluZ0J1aWxkUnVuU2VydmljZVxuICAgICAgICAgICAgLmdldEJ1aWxkUnVuVXBkYXRlcyh0aGlzLmV4ZXJjaXNlLmlkISlcbiAgICAgICAgICAgIC5waXBlKHRhcCgoYnVpbGRSdW5TdGF0ZSkgPT4gKHRoaXMuaXNUcmlnZ2VyaW5nQnVpbGRBbGwgPSBidWlsZFJ1blN0YXRlID09PSBCdWlsZFJ1blN0YXRlLlJVTk5JTkcpKSlcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoKTtcbiAgICB9XG59XG5cbi8qKlxuICogVGhlIHdhcm5pbmcgbW9kYWwgb2YgdGhlIHRyaWdnZXIgYWxsIGJ1dHRvbiB0aGF0IGluZm9ybXMgdGhlIHVzZXIgYWJvdXQgdGhlIGNvc3QgYW5kIGVmZmVjdHMgb2YgdGhlIG9wZXJhdGlvbi5cbiAqL1xuQENvbXBvbmVudCh7XG4gICAgdGVtcGxhdGU6IGBcbiAgICAgICAgPGZvcm0gbmFtZT1cInRyaWdnZXJBbGxGb3JtXCIgKG5nU3VibWl0KT1cImNvbmZpcm1UcmlnZ2VyKClcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3M9XCJtb2RhbC10aXRsZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucHJvZ3JhbW1pbmdFeGVyY2lzZS5yZXN1Ym1pdEFsbFwiPlRyaWdnZXIgYWxsPC9oND5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1jbG9zZVwiIGRhdGEtZGlzbWlzcz1cIm1vZGFsXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgKGNsaWNrKT1cImNhbmNlbCgpXCI+PC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1ib2R5XCI+XG4gICAgICAgICAgICAgICAgQGlmIChkdWVEYXRlUGFzc2VkKSB7XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1kYW5nZXIgZm9udC13ZWlnaHQtYm9sZFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAucHJvZ3JhbW1pbmdFeGVyY2lzZS5yZXN1Ym1pdEFsbENvbmZpcm1BZnRlckR1ZURhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFRoZSBkdWUgZGF0ZSBoYXMgcGFzc2VkLCBzb21lIG9mIHRoZSBzdHVkZW50IHN1Ym1pc3Npb25zIG1pZ2h0IGhhdmUgcmVjZWl2ZWQgbWFudWFsIHJlc3VsdHMgY3JlYXRlZCBieSB0ZWFjaGluZyBhc3Npc3RhbnRzLiBOZXdseSBnZW5lcmF0ZWQgYXV0b21hdGljXG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRzIHdvdWxkIHJlcGxhY2UgdGhlIG1hbnVhbCByZXN1bHRzIGFzIHRoZSBsYXRlc3QgcmVzdWx0IGZvciB0aGUgcGFydGljaXBhdGlvbi5cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8cCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnByb2dyYW1taW5nRXhlcmNpc2UucmVzdWJtaXRBbGxEaWFsb2dcIj5cbiAgICAgICAgICAgICAgICAgICAgV0FSTklORzogVHJpZ2dlcmluZyBhbGwgcGFydGljaXBhdGlvbnMgYWdhaW4gaXMgYSB2ZXJ5IGV4cGVuc2l2ZSBvcGVyYXRpb24uIFRoaXMgYWN0aW9uIHdpbGwgc3RhcnQgYSBDSSBidWlsZCBmb3IgZXZlcnkgcGFydGljaXBhdGlvbiBpbiB0aGlzIGV4ZXJjaXNlIVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWZvb3RlclwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnlcIiBkYXRhLWRpc21pc3M9XCJtb2RhbFwiIChjbGljayk9XCJjYW5jZWwoKVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUJhblwiPjwvZmEtaWNvbj4mbmJzcDs8c3BhbiBqaGlUcmFuc2xhdGU9XCJlbnRpdHkuYWN0aW9uLmNhbmNlbFwiPkNhbmNlbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzcz1cImJ0biBidG4tZGFuZ2VyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhVGltZXNcIj48L2ZhLWljb24+Jm5ic3A7XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImVudGl0eS5hY3Rpb24uY29uZmlybVwiPkNvbmZpcm08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9mb3JtPlxuICAgIGAsXG59KVxuZXhwb3J0IGNsYXNzIFByb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdG9yVHJpZ2dlckFsbERpYWxvZ0NvbXBvbmVudCB7XG4gICAgQElucHV0KCkgZXhlcmNpc2VJZDogbnVtYmVyO1xuICAgIEBJbnB1dCgpIGR1ZURhdGVQYXNzZWQ6IGJvb2xlYW47XG5cbiAgICAvLyBJY29uc1xuICAgIGZhQmFuID0gZmFCYW47XG4gICAgZmFUaW1lcyA9IGZhVGltZXM7XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGFjdGl2ZU1vZGFsOiBOZ2JBY3RpdmVNb2RhbCkge31cblxuICAgIGNhbmNlbCgpIHtcbiAgICAgICAgdGhpcy5hY3RpdmVNb2RhbC5kaXNtaXNzKCdjYW5jZWwnKTtcbiAgICB9XG5cbiAgICBjb25maXJtVHJpZ2dlcigpIHtcbiAgICAgICAgdGhpcy5hY3RpdmVNb2RhbC5jbG9zZSgpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uQ2hhbmdlcywgT25Jbml0LCBTaW1wbGVDaGFuZ2VzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBkZWJvdW5jZVRpbWUsIG1hcCwgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgRXhlcmNpc2VTdWJtaXNzaW9uU3RhdGUsIFByb2dyYW1taW5nU3VibWlzc2lvblNlcnZpY2UsIFByb2dyYW1taW5nU3VibWlzc2lvblN0YXRlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9wYXJ0aWNpcGF0ZS9wcm9ncmFtbWluZy1zdWJtaXNzaW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBGZWF0dXJlVG9nZ2xlIH0gZnJvbSAnYXBwL3NoYXJlZC9mZWF0dXJlLXRvZ2dsZS9mZWF0dXJlLXRvZ2dsZS5zZXJ2aWNlJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvcHJvZ3JhbW1pbmctZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgaGFzRXhlcmNpc2VDaGFuZ2VkIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhlcmNpc2UvZXhlcmNpc2UudXRpbHMnO1xuaW1wb3J0IHsgQnV0dG9uVHlwZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9idXR0b24uY29tcG9uZW50JztcbmltcG9ydCB7IGZhQ2lyY2xlTm90Y2gsIGZhQ2xvY2ssIGZhUmVkbyB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5cbi8qKlxuICogVGhpcyBjb21wb25lbnRzIHByb3ZpZGVzIHR3byBidXR0b25zIHRvIHRoZSBpbnN0cnVjdG9yIHRvIGludGVyYWN0IHdpdGggdGhlIHN0dWRlbnRzJyBzdWJtaXNzaW9uczpcbiAqIC0gVHJpZ2dlciBidWlsZHMgZm9yIGFsbCBzdHVkZW50IHBhcnRpY2lwYXRpb25zXG4gKiAtIFRyaWdnZXIgYnVpbGRzIGZvciBmYWlsZWQgc3R1ZGVudCBwYXJ0aWNpcGF0aW9uc1xuICpcbiAqIEFsc28gc2hvd3MgYW4gaW5mbyBzZWN0aW9uIG5leHQgdG8gdGhlIGJ1dHRvbnMgYWJvdXQgdGhlIG51bWJlciBvZiBidWlsZGluZyBhbmQgZmFpbGVkIHN1Ym1pc3Npb25zLlxuICovXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdG9yLXN1Ym1pc3Npb24tc3RhdGUnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdG9yLXN1Ym1pc3Npb24tc3RhdGUuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3RvclN1Ym1pc3Npb25TdGF0ZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcywgT25Jbml0IHtcbiAgICBGZWF0dXJlVG9nZ2xlID0gRmVhdHVyZVRvZ2dsZTtcbiAgICBCdXR0b25UeXBlID0gQnV0dG9uVHlwZTtcbiAgICBQcm9ncmFtbWluZ1N1Ym1pc3Npb25TdGF0ZSA9IFByb2dyYW1taW5nU3VibWlzc2lvblN0YXRlO1xuXG4gICAgQElucHV0KCkgZXhlcmNpc2U6IFByb2dyYW1taW5nRXhlcmNpc2U7XG5cbiAgICBoYXNGYWlsZWRTdWJtaXNzaW9ucyA9IGZhbHNlO1xuICAgIGhhc0J1aWxkaW5nU3VibWlzc2lvbnMgPSBmYWxzZTtcbiAgICBidWlsZGluZ1N1bW1hcnk6IHsgW3N1Ym1pc3Npb25TdGF0ZTogc3RyaW5nXTogbnVtYmVyIH07XG4gICAgaXNCdWlsZGluZ0ZhaWxlZFN1Ym1pc3Npb25zID0gZmFsc2U7XG5cbiAgICByZXN1bHRFdGFJbk1zOiBudW1iZXI7XG5cbiAgICBzdWJtaXNzaW9uU3RhdGVTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcbiAgICByZXN1bHRFdGFTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcblxuICAgIC8vIEljb25zXG4gICAgZmFDbG9jayA9IGZhQ2xvY2s7XG4gICAgZmFDaXJjbGVOb3RjaCA9IGZhQ2lyY2xlTm90Y2g7XG4gICAgZmFSZWRvID0gZmFSZWRvO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBwcm9ncmFtbWluZ1N1Ym1pc3Npb25TZXJ2aWNlOiBQcm9ncmFtbWluZ1N1Ym1pc3Npb25TZXJ2aWNlKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMucmVzdWx0RXRhU3Vic2NyaXB0aW9uID0gdGhpcy5wcm9ncmFtbWluZ1N1Ym1pc3Npb25TZXJ2aWNlLmdldFJlc3VsdEV0YUluTXMoKS5zdWJzY3JpYmUoKHJlc3VsdEV0YSkgPT4gKHRoaXMucmVzdWx0RXRhSW5NcyA9IHJlc3VsdEV0YSkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFdoZW4gdGhlIHNlbGVjdGVkIGV4ZXJjaXNlIGNoYW5nZXMsIGNyZWF0ZSBhIHN1YnNjcmlwdGlvbiB0byB0aGUgY29tcGxldGUgc3VibWlzc2lvbiBzdGF0ZSBvZiB0aGUgZXhlcmNpc2UuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gY2hhbmdlcyBvbmx5IHJlbGV2YW50IGZvciBjaGFuZ2Ugb2YgZXhlcmNpc2VJZC5cbiAgICAgKi9cbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XG4gICAgICAgIGlmIChoYXNFeGVyY2lzZUNoYW5nZWQoY2hhbmdlcykpIHtcbiAgICAgICAgICAgIHRoaXMuc3VibWlzc2lvblN0YXRlU3Vic2NyaXB0aW9uID0gdGhpcy5wcm9ncmFtbWluZ1N1Ym1pc3Npb25TZXJ2aWNlXG4gICAgICAgICAgICAgICAgLmdldFN1Ym1pc3Npb25TdGF0ZU9mRXhlcmNpc2UodGhpcy5leGVyY2lzZS5pZCEpXG4gICAgICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgICAgIG1hcCh0aGlzLnN1bVN1Ym1pc3Npb25TdGF0ZXMpLFxuICAgICAgICAgICAgICAgICAgICAvLyBJZiB3ZSB3b3VsZCB1cGRhdGUgdGhlIFVJIHdpdGggZXZlcnkgc21hbGwgY2hhbmdlLCBpdCB3b3VsZCBzZWVtIHZlcnkgaGVjdGljLiBTbyB3ZSBhbHdheXMgdGFrZSB0aGUgbGF0ZXN0IHZhbHVlIGFmdGVyIDEgc2Vjb25kLlxuICAgICAgICAgICAgICAgICAgICBkZWJvdW5jZVRpbWUoNTAwKSxcbiAgICAgICAgICAgICAgICAgICAgdGFwKChidWlsZGluZ1N1bW1hcnk6IHsgW3N1Ym1pc3Npb25TdGF0ZTogc3RyaW5nXTogbnVtYmVyIH0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYnVpbGRpbmdTdW1tYXJ5ID0gYnVpbGRpbmdTdW1tYXJ5O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5oYXNGYWlsZWRTdWJtaXNzaW9ucyA9IHRoaXMuYnVpbGRpbmdTdW1tYXJ5W1Byb2dyYW1taW5nU3VibWlzc2lvblN0YXRlLkhBU19GQUlMRURfU1VCTUlTU0lPTl0gPiAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5oYXNCdWlsZGluZ1N1Ym1pc3Npb25zID0gdGhpcy5idWlsZGluZ1N1bW1hcnlbUHJvZ3JhbW1pbmdTdWJtaXNzaW9uU3RhdGUuSVNfQlVJTERJTkdfUEVORElOR19TVUJNSVNTSU9OXSA+IDA7XG4gICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXRyaWV2ZSB0aGUgcGFydGljaXBhdGlvbiBpZHMgdGhhdCBoYXZlIGEgZmFpbGVkIHN1Ym1pc3Npb24gYW5kIHJldHJ5IHRoZWlyIGJ1aWxkLlxuICAgICAqL1xuICAgIHRyaWdnZXJCdWlsZE9mRmFpbGVkU3VibWlzc2lvbnMoKSB7XG4gICAgICAgIHRoaXMuaXNCdWlsZGluZ0ZhaWxlZFN1Ym1pc3Npb25zID0gdHJ1ZTtcbiAgICAgICAgY29uc3QgZmFpbGVkU3VibWlzc2lvblBhcnRpY2lwYXRpb25zID0gdGhpcy5wcm9ncmFtbWluZ1N1Ym1pc3Npb25TZXJ2aWNlLmdldFN1Ym1pc3Npb25Db3VudEJ5VHlwZSh0aGlzLmV4ZXJjaXNlLmlkISwgUHJvZ3JhbW1pbmdTdWJtaXNzaW9uU3RhdGUuSEFTX0ZBSUxFRF9TVUJNSVNTSU9OKTtcbiAgICAgICAgdGhpcy5wcm9ncmFtbWluZ1N1Ym1pc3Npb25TZXJ2aWNlXG4gICAgICAgICAgICAudHJpZ2dlckluc3RydWN0b3JCdWlsZEZvclBhcnRpY2lwYXRpb25zT2ZFeGVyY2lzZSh0aGlzLmV4ZXJjaXNlLmlkISwgZmFpbGVkU3VibWlzc2lvblBhcnRpY2lwYXRpb25zKVxuICAgICAgICAgICAgLnN1YnNjcmliZSgoKSA9PiAodGhpcy5pc0J1aWxkaW5nRmFpbGVkU3VibWlzc2lvbnMgPSBmYWxzZSkpO1xuICAgIH1cblxuICAgIHByaXZhdGUgc3VtU3VibWlzc2lvblN0YXRlcyA9IChidWlsZFN0YXRlOiBFeGVyY2lzZVN1Ym1pc3Npb25TdGF0ZSkgPT5cbiAgICAgICAgT2JqZWN0LnZhbHVlcyhidWlsZFN0YXRlKS5yZWR1Y2UoKGFjYzogeyBbc3RhdGU6IHN0cmluZ106IG51bWJlciB9LCB7IHN1Ym1pc3Npb25TdGF0ZSB9KSA9PiB7XG4gICAgICAgICAgICByZXR1cm4geyAuLi5hY2MsIFtzdWJtaXNzaW9uU3RhdGVdOiAoYWNjW3N1Ym1pc3Npb25TdGF0ZV0gfHwgMCkgKyAxIH07XG4gICAgICAgIH0sIHt9KTtcbn1cbiIsIkBpZiAoYnVpbGRpbmdTdW1tYXJ5KSB7XG4gICAgPGRpdiBjbGFzcz1cImQtZmxleFwiPlxuICAgICAgICBAaWYgKGhhc0J1aWxkaW5nU3VibWlzc2lvbnMpIHtcbiAgICAgICAgICAgIDxkaXYgaWQ9XCJyZXN1bHQtZXRhXCIgY2xhc3M9XCJiYWRnZSBiZy1zZWNvbmRhcnkgZC1mbGV4IGZsZXgtY29sdW1uIGp1c3RpZnktY29udGVudC1iZXR3ZWVuIG1lLTNcIj5cbiAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUNsb2NrXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgIFtuZ2JUb29sdGlwXT1cIidhcnRlbWlzQXBwLnByb2dyYW1taW5nRXhlcmNpc2UucmVzdWx0RVRBVG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgW2lubmVySFRNTF09XCInYXJ0ZW1pc0FwcC5wcm9ncmFtbWluZ0V4ZXJjaXNlLnJlc3VsdEVUQScgfCBhcnRlbWlzVHJhbnNsYXRlOiB7IGV0YTogcmVzdWx0RXRhSW5NcyB8IGR1cmF0aW9uIH1cIlxuICAgICAgICAgICAgICAgICAgICA+UmVzdWx0IEVUQToge3sgcmVzdWx0RXRhSW5NcyB8IGR1cmF0aW9uIH19PC9zcGFuXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgPGRpdiBpZD1cImJ1aWxkLXN0YXRlXCIgY2xhc3M9XCJkLWZsZXggZmxleC1jb2x1bW4ganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgaWQ9XCJidWlsZC1zdGF0ZS1idWlsZGluZ1wiXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJiYWRnZSBiZy1wcmltYXJ5IGZsZXgtZ3Jvdy0wXCJcbiAgICAgICAgICAgICAgICBbaW5uZXJIVE1MXT1cIlxuICAgICAgICAgICAgICAgICAgICAnYXJ0ZW1pc0FwcC5wcm9ncmFtbWluZ0V4ZXJjaXNlLmJ1aWxkaW5nU3VibWlzc2lvbnMnXG4gICAgICAgICAgICAgICAgICAgICAgICB8IGFydGVtaXNUcmFuc2xhdGU6IHsgbnVtYmVyOiBidWlsZGluZ1N1bW1hcnlbUHJvZ3JhbW1pbmdTdWJtaXNzaW9uU3RhdGUuSVNfQlVJTERJTkdfUEVORElOR19TVUJNSVNTSU9OXSB8fCAwIH1cbiAgICAgICAgICAgICAgICBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEJ1aWxkaW5nIHN1Ym1pc3Npb25zOiB7eyBidWlsZGluZ1N1bW1hcnlbUHJvZ3JhbW1pbmdTdWJtaXNzaW9uU3RhdGUuSVNfQlVJTERJTkdfUEVORElOR19TVUJNSVNTSU9OXSB8fCAwIH19XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgIGlkPVwiYnVpbGQtc3RhdGUtZmFpbGVkXCJcbiAgICAgICAgICAgICAgICBbbmdDbGFzc109XCJbJ2JhZGdlJywgYnVpbGRpbmdTdW1tYXJ5W1Byb2dyYW1taW5nU3VibWlzc2lvblN0YXRlLkhBU19GQUlMRURfU1VCTUlTU0lPTl0gPiAwID8gJ2JnLWRhbmdlcicgOiAnYmctc3VjY2VzcycsICdmbGV4LWdyb3ctMCddXCJcbiAgICAgICAgICAgICAgICBbaW5uZXJIVE1MXT1cIlxuICAgICAgICAgICAgICAgICAgICAnYXJ0ZW1pc0FwcC5wcm9ncmFtbWluZ0V4ZXJjaXNlLmZhaWxlZFN1Ym1pc3Npb25zJyB8IGFydGVtaXNUcmFuc2xhdGU6IHsgbnVtYmVyOiBidWlsZGluZ1N1bW1hcnlbUHJvZ3JhbW1pbmdTdWJtaXNzaW9uU3RhdGUuSEFTX0ZBSUxFRF9TVUJNSVNTSU9OXSB8fCAwIH1cbiAgICAgICAgICAgICAgICBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEZhaWxlZCBzdWJtaXNzaW9uczoge3sgYnVpbGRpbmdTdW1tYXJ5W1Byb2dyYW1taW5nU3VibWlzc2lvblN0YXRlLkhBU19GQUlMRURfU1VCTUlTU0lPTl0gfHwgMCB9fVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGpoaS1wcm9ncmFtbWluZy1leGVyY2lzZS10cmlnZ2VyLWFsbC1idXR0b24gW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCI+PC9qaGktcHJvZ3JhbW1pbmctZXhlcmNpc2UtdHJpZ2dlci1hbGwtYnV0dG9uPlxuICAgICAgICA8amhpLWJ1dHRvblxuICAgICAgICAgICAgaWQ9XCJ0cmlnZ2VyLWZhaWxlZC1idXR0b25cIlxuICAgICAgICAgICAgY2xhc3M9XCJtcy0zXCJcbiAgICAgICAgICAgIFtkaXNhYmxlZF09XCIhaGFzRmFpbGVkU3VibWlzc2lvbnNcIlxuICAgICAgICAgICAgW2lzTG9hZGluZ109XCJpc0J1aWxkaW5nRmFpbGVkU3VibWlzc2lvbnNcIlxuICAgICAgICAgICAgW2ljb25dPVwiZmFSZWRvXCJcbiAgICAgICAgICAgIFt0aXRsZV09XCInYXJ0ZW1pc0FwcC5wcm9ncmFtbWluZ0V4ZXJjaXNlLnJlc3VibWl0RmFpbGVkJ1wiXG4gICAgICAgICAgICBbdG9vbHRpcF09XCInYXJ0ZW1pc0FwcC5wcm9ncmFtbWluZ0V4ZXJjaXNlLnJlc3VibWl0RmFpbGVkVG9vbHRpcCdcIlxuICAgICAgICAgICAgW2ZlYXR1cmVUb2dnbGVdPVwiRmVhdHVyZVRvZ2dsZS5Qcm9ncmFtbWluZ0V4ZXJjaXNlc1wiXG4gICAgICAgICAgICAob25DbGljayk9XCJ0cmlnZ2VyQnVpbGRPZkZhaWxlZFN1Ym1pc3Npb25zKClcIlxuICAgICAgICA+PC9qaGktYnV0dG9uPlxuICAgIDwvZGl2PlxufSBAZWxzZSB7XG4gICAgPGZhLWljb24gW2ljb25dPVwiZmFDaXJjbGVOb3RjaFwiIFtzcGluXT1cInRydWVcIj48L2ZhLWljb24+XG59XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlLCBPbkRlc3Ryb3kgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBQYXJhbXMgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBCZWhhdmlvclN1YmplY3QsIE9ic2VydmFibGUsIG9mIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBtYXAsIHN3aXRjaE1hcCwgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgSmhpV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3dlYnNvY2tldC93ZWJzb2NrZXQuc2VydmljZSc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2UsIFZpc2liaWxpdHkgfSBmcm9tICdhcHAvZW50aXRpZXMvcHJvZ3JhbW1pbmctZXhlcmNpc2UtdGVzdC1jYXNlLm1vZGVsJztcbmltcG9ydCB7IFN0YXRpY0NvZGVBbmFseXNpc0NhdGVnb3J5IH0gZnJvbSAnYXBwL2VudGl0aWVzL3N0YXRpYy1jb2RlLWFuYWx5c2lzLWNhdGVnb3J5Lm1vZGVsJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2VHcmFkaW5nU3RhdGlzdGljcyB9IGZyb20gJ2FwcC9lbnRpdGllcy9wcm9ncmFtbWluZy1leGVyY2lzZS10ZXN0LWNhc2Utc3RhdGlzdGljcy5tb2RlbCc7XG5cbmV4cG9ydCBjbGFzcyBQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VVcGRhdGUge1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwdWJsaWMgaWQ/OiBudW1iZXIsXG4gICAgICAgIHB1YmxpYyB3ZWlnaHQ/OiBudW1iZXIsXG4gICAgICAgIHB1YmxpYyBib251c1BvaW50cz86IG51bWJlcixcbiAgICAgICAgcHVibGljIGJvbnVzTXVsdGlwbGllcj86IG51bWJlcixcbiAgICAgICAgcHVibGljIHZpc2liaWxpdHk/OiBWaXNpYmlsaXR5LFxuICAgICkge31cblxuICAgIHN0YXRpYyBmcm9tKHRlc3RDYXNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2UpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VVcGRhdGUodGVzdENhc2UuaWQsIHRlc3RDYXNlLndlaWdodCwgdGVzdENhc2UuYm9udXNQb2ludHMsIHRlc3RDYXNlLmJvbnVzTXVsdGlwbGllciwgdGVzdENhc2UudmlzaWJpbGl0eSk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFN0YXRpY0NvZGVBbmFseXNpc0NhdGVnb3J5VXBkYXRlIHtcbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHVibGljIGlkPzogbnVtYmVyLFxuICAgICAgICBwdWJsaWMgcGVuYWx0eT86IG51bWJlcixcbiAgICAgICAgcHVibGljIG1heFBlbmFsdHk/OiBudW1iZXIsXG4gICAgICAgIHB1YmxpYyBzdGF0ZT86IHN0cmluZyxcbiAgICApIHt9XG5cbiAgICBzdGF0aWMgZnJvbShjYXRlZ29yeTogU3RhdGljQ29kZUFuYWx5c2lzQ2F0ZWdvcnkpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBTdGF0aWNDb2RlQW5hbHlzaXNDYXRlZ29yeVVwZGF0ZShjYXRlZ29yeS5pZCwgY2F0ZWdvcnkucGVuYWx0eSwgY2F0ZWdvcnkubWF4UGVuYWx0eSwgY2F0ZWdvcnkuc3RhdGUpO1xuICAgIH1cbn1cblxuZXhwb3J0IGludGVyZmFjZSBJUHJvZ3JhbW1pbmdFeGVyY2lzZUdyYWRpbmdTZXJ2aWNlIHtcbiAgICBzdWJzY3JpYmVGb3JUZXN0Q2FzZXMoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VbXSB8IHVuZGVmaW5lZD47XG4gICAgbm90aWZ5VGVzdENhc2VzKGV4ZXJjaXNlSWQ6IG51bWJlciwgdGVzdENhc2VzOiBQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VbXSk6IHZvaWQ7XG4gICAgdXBkYXRlVGVzdENhc2UoZXhlcmNpc2VJZDogbnVtYmVyLCB0ZXN0Q2FzZVVwZGF0ZXM6IFByb2dyYW1taW5nRXhlcmNpc2VUZXN0Q2FzZVVwZGF0ZVtdKTogT2JzZXJ2YWJsZTxQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VbXT47XG4gICAgcmVzZXRUZXN0Q2FzZXMoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VbXT47XG4gICAgZ2V0Q29kZUFuYWx5c2lzQ2F0ZWdvcmllcyhleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPFN0YXRpY0NvZGVBbmFseXNpc0NhdGVnb3J5W10+O1xuICAgIHVwZGF0ZUNvZGVBbmFseXNpc0NhdGVnb3JpZXMoZXhlcmNpc2VJZDogbnVtYmVyLCB1cGRhdGVzOiBTdGF0aWNDb2RlQW5hbHlzaXNDYXRlZ29yeVVwZGF0ZVtdKTogT2JzZXJ2YWJsZTxTdGF0aWNDb2RlQW5hbHlzaXNDYXRlZ29yeVVwZGF0ZVtdPjtcbiAgICByZXNldENhdGVnb3JpZXMoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxTdGF0aWNDb2RlQW5hbHlzaXNDYXRlZ29yeVtdPjtcbiAgICBnZXRHcmFkaW5nU3RhdGlzdGljcyhleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPFByb2dyYW1taW5nRXhlcmNpc2VHcmFkaW5nU3RhdGlzdGljcz47XG4gICAgaW1wb3J0Q2F0ZWdvcmllc0Zyb21FeGVyY2lzZSh0YXJnZXRFeGVyY2lzZUlkOiBudW1iZXIsIHNvdXJjZUV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8U3RhdGljQ29kZUFuYWx5c2lzQ2F0ZWdvcnlbXT47XG59XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgUHJvZ3JhbW1pbmdFeGVyY2lzZUdyYWRpbmdTZXJ2aWNlIGltcGxlbWVudHMgSVByb2dyYW1taW5nRXhlcmNpc2VHcmFkaW5nU2VydmljZSwgT25EZXN0cm95IHtcbiAgICBwdWJsaWMgcmVzb3VyY2VVcmwgPSAnYXBpL3Byb2dyYW1taW5nLWV4ZXJjaXNlcyc7XG5cbiAgICBwcml2YXRlIGNvbm5lY3Rpb25zOiB7IFtleGVyY2lzZUlkOiBzdHJpbmddOiBzdHJpbmcgfSA9IHt9O1xuICAgIHByaXZhdGUgc3ViamVjdHM6IHsgW2V4ZXJjaXNlSWQ6IHN0cmluZ106IEJlaGF2aW9yU3ViamVjdDxQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VbXSB8IHVuZGVmaW5lZD4gfSA9IHt9O1xuICAgIHByaXZhdGUgdGVzdENhc2VzOiBNYXA8bnVtYmVyLCBQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VbXT4gPSBuZXcgTWFwKCk7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBqaGlXZWJzb2NrZXRTZXJ2aWNlOiBKaGlXZWJzb2NrZXRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogT24gZGVzdHJveSB1bnN1YnNjcmliZSBhbGwgY29ubmVjdGlvbnMuXG4gICAgICovXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgICAgIE9iamVjdC52YWx1ZXModGhpcy5jb25uZWN0aW9ucykuZm9yRWFjaCgoY29ubmVjdGlvbikgPT4gdGhpcy5qaGlXZWJzb2NrZXRTZXJ2aWNlLnVuc3Vic2NyaWJlKGNvbm5lY3Rpb24pKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTdWJzY3JpYmUgdG8gdGVzdCBjYXNlIGNoYW5nZXMgb24gdGhlIHNlcnZlci5cbiAgICAgKiBFeGVjdXRlcyBhIFJFU1QgcmVxdWVzdCBpbml0aWFsbHkgdG8gZ2V0IHRoZSBjdXJyZW50IHZhbHVlLCBzbyB0aGF0IGlkZWFsbHkgbm8gbnVsbCB2YWx1ZSBpcyBlbWl0dGVkIHRvIHRoZSBzdWJzY3JpYmVyLlxuICAgICAqXG4gICAgICogSWYgdGhlIHJlc3VsdCBpcyBhbiBlbXB0eSBhcnJheSwgdGhpcyB3aWxsIGJlIHRyYW5zbGF0ZWQgaW50byBhIG51bGwgdmFsdWUuXG4gICAgICogVGhpcyBpcyBkb25lIG9uIHB1cnBvc2UgbW9zdCBsaWtlbHkgdGhpcyBpcyBhbiBlcnJvciBhcyBtb3N0IHByb2dyYW1taW5nIGV4ZXJjaXNlcyBoYXZlIGF0IGxlYXN0IG9uZSB0ZXN0IGNhc2UuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZFxuICAgICAqL1xuICAgIHN1YnNjcmliZUZvclRlc3RDYXNlcyhleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPFByb2dyYW1taW5nRXhlcmNpc2VUZXN0Q2FzZVtdIHwgdW5kZWZpbmVkPiB7XG4gICAgICAgIGlmICh0aGlzLnN1YmplY3RzW2V4ZXJjaXNlSWRdKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zdWJqZWN0c1tleGVyY2lzZUlkXSBhcyBPYnNlcnZhYmxlPFByb2dyYW1taW5nRXhlcmNpc2VUZXN0Q2FzZVtdIHwgdW5kZWZpbmVkPjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5nZXRUZXN0Q2FzZXMoZXhlcmNpc2VJZCkucGlwZShcbiAgICAgICAgICAgIG1hcCgodGVzdENhc2VzKSA9PiAodGVzdENhc2VzLmxlbmd0aCA/IHRlc3RDYXNlcyA6IHVuZGVmaW5lZCkpLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcigoKSA9PiBvZih1bmRlZmluZWQpKSxcbiAgICAgICAgICAgIHN3aXRjaE1hcCgodGVzdENhc2VzOiBQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VbXSB8IHVuZGVmaW5lZCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICh0ZXN0Q2FzZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy50ZXN0Q2FzZXMuc2V0KGV4ZXJjaXNlSWQsIHRlc3RDYXNlcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmluaXRUZXN0Q2FzZVN1YnNjcmlwdGlvbihleGVyY2lzZUlkLCB0ZXN0Q2FzZXMpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VuZCBuZXcgdmFsdWVzIGZvciB0aGUgdGVzdCBjYXNlcyBvZiBhbiBleGVyY2lzZSB0byBhbGwgc3Vic2NyaWJlcnMuXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlSWRcbiAgICAgKiBAcGFyYW0gdGVzdENhc2VzXG4gICAgICovXG4gICAgcHVibGljIG5vdGlmeVRlc3RDYXNlcyhleGVyY2lzZUlkOiBudW1iZXIsIHRlc3RDYXNlczogUHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlW10pOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMuc3ViamVjdHNbZXhlcmNpc2VJZF0pIHtcbiAgICAgICAgICAgIHRoaXMuc3ViamVjdHNbZXhlcmNpc2VJZF0ubmV4dCh0ZXN0Q2FzZXMpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRXhlY3V0ZXMgYSBSRVNUIHJlcXVlc3QgdG8gdGhlIHRlc3QgY2FzZSBlbmRwb2ludC5cbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZFxuICAgICAqL1xuICAgIHB1YmxpYyBnZXRUZXN0Q2FzZXMoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VbXT4ge1xuICAgICAgICBpZiAodGhpcy50ZXN0Q2FzZXMuaGFzKGV4ZXJjaXNlSWQpKSB7XG4gICAgICAgICAgICByZXR1cm4gb2YodGhpcy50ZXN0Q2FzZXMuZ2V0KGV4ZXJjaXNlSWQpISk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8UHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlW10+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7ZXhlcmNpc2VJZH0vdGVzdC1jYXNlc2ApLnBpcGUoXG4gICAgICAgICAgICB0YXAoKHRlc3RDYXNlcykgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMudGVzdENhc2VzLnNldChleGVyY2lzZUlkLCB0ZXN0Q2FzZXMpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlIHRoZSB3ZWlnaHRzIHdpdGggdGhlIHByb3ZpZGVkIHZhbHVlcyBvZiB0aGUgdGVzdCBjYXNlcy5cbiAgICAgKiBOZWVkcyB0aGUgZXhlcmNpc2UgdG8gdmVyaWZ5IHBlcm1pc3Npb25zIG9uIHRoZSBzZXJ2ZXIuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZFxuICAgICAqIEBwYXJhbSB1cGRhdGVzIGR0byBmb3IgdXBkYXRpbmcgdGVzdCBjYXNlcyB0byBhdm9pZCBzZXR0aW5nIGF1dG9tYXRpYyBwYXJhbWV0ZXJzIChlLmcuIGFjdGl2ZSBvciB0ZXN0TmFtZSlcbiAgICAgKi9cbiAgICBwdWJsaWMgdXBkYXRlVGVzdENhc2UoZXhlcmNpc2VJZDogbnVtYmVyLCB1cGRhdGVzOiBQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VVcGRhdGVbXSk6IE9ic2VydmFibGU8UHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlW10+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wYXRjaDxQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VbXT4oYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtleGVyY2lzZUlkfS91cGRhdGUtdGVzdC1jYXNlc2AsIHVwZGF0ZXMpO1xuICAgIH1cblxuICAgIHB1YmxpYyBnZXRHcmFkaW5nU3RhdGlzdGljcyhleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPFByb2dyYW1taW5nRXhlcmNpc2VHcmFkaW5nU3RhdGlzdGljcz4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxQcm9ncmFtbWluZ0V4ZXJjaXNlR3JhZGluZ1N0YXRpc3RpY3M+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7ZXhlcmNpc2VJZH0vZ3JhZGluZy9zdGF0aXN0aWNzYCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXNlIHdpdGggY2FyZTogUmVzZXRzIGFsbCB0ZXN0IGNhc2VzIG9mIGFuIGV4ZXJjaXNlIHRvIHRoZWlyIGluaXRpYWwgY29uZmlndXJhdGlvblxuICAgICAqIFNldCBhbGwgdGVzdCBjYXNlIHdlaWdodHMgdG8gMSwgYWxsIGJvbnVzIG11bHRpcGxpZXJzIHRvIDEsIGFsbCBib251cyBwb2ludHMgdG8gMCBhbmQgdmlzaWJpbGl0eSB0byBhbHdheXMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCB0aGUgaWQgb2YgdGhlIGV4ZXJjaXNlIHRvIHJlc2V0IHRoZSB0ZXN0IGNhc2Ugd2VpZ2h0cyBvZi5cbiAgICAgKi9cbiAgICBwdWJsaWMgcmVzZXRUZXN0Q2FzZXMoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VbXT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBhdGNoPFByb2dyYW1taW5nRXhlcmNpc2VUZXN0Q2FzZVtdPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L3Rlc3QtY2FzZXMvcmVzZXRgLCB7fSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXNlIHdpdGggY2FyZTogUmUtZXZhbHVhdGUgdGhlIGxhdGVzdCBhdXRvbWF0aWMgcmVzdWx0cyBvZiBhbGwgc3R1ZGVudCBwYXJ0aWNpcGF0aW9ucy5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkXG4gICAgICovXG4gICAgcHVibGljIHJlRXZhbHVhdGUoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxudW1iZXI+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8bnVtYmVyPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L2dyYWRpbmcvcmUtZXZhbHVhdGVgLCB7fSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2V0IHVwIHRoZSBpbmZyYXN0cnVjdHVyZSBmb3IgaGFuZGxpbmcgYW5kIHJldXNpbmcgYSBuZXcgdGVzdCBjYXNlIHN1YnNjcmlwdGlvbi5cbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZFxuICAgICAqIEBwYXJhbSBpbml0aWFsVmFsdWVcbiAgICAgKi9cbiAgICBwcml2YXRlIGluaXRUZXN0Q2FzZVN1YnNjcmlwdGlvbihleGVyY2lzZUlkOiBudW1iZXIsIGluaXRpYWxWYWx1ZTogUHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlW10gfCB1bmRlZmluZWQpIHtcbiAgICAgICAgY29uc3QgdGVzdENhc2VUb3BpYyA9IGAvdG9waWMvcHJvZ3JhbW1pbmctZXhlcmNpc2VzLyR7ZXhlcmNpc2VJZH0vdGVzdC1jYXNlc2A7XG4gICAgICAgIHRoaXMuamhpV2Vic29ja2V0U2VydmljZS5zdWJzY3JpYmUodGVzdENhc2VUb3BpYyk7XG4gICAgICAgIHRoaXMuY29ubmVjdGlvbnNbZXhlcmNpc2VJZF0gPSB0ZXN0Q2FzZVRvcGljO1xuICAgICAgICB0aGlzLnN1YmplY3RzW2V4ZXJjaXNlSWRdID0gbmV3IEJlaGF2aW9yU3ViamVjdChpbml0aWFsVmFsdWUpO1xuICAgICAgICB0aGlzLmpoaVdlYnNvY2tldFNlcnZpY2VcbiAgICAgICAgICAgIC5yZWNlaXZlKHRlc3RDYXNlVG9waWMpXG4gICAgICAgICAgICAucGlwZShcbiAgICAgICAgICAgICAgICBtYXAoKHRlc3RDYXNlcykgPT4gKHRlc3RDYXNlcy5sZW5ndGggPyB0ZXN0Q2FzZXMgOiB1bmRlZmluZWQpKSxcbiAgICAgICAgICAgICAgICB0YXAoKHRlc3RDYXNlcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAodGVzdENhc2VzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnRlc3RDYXNlcy5zZXQoZXhlcmNpc2VJZCwgdGVzdENhc2VzKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB0aGlzLm5vdGlmeVN1YnNjcmliZXJzKGV4ZXJjaXNlSWQsIHRlc3RDYXNlcyk7XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAuc3Vic2NyaWJlKCk7XG4gICAgICAgIHJldHVybiB0aGlzLnN1YmplY3RzW2V4ZXJjaXNlSWRdO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE5vdGlmeSB0aGUgc3Vic2NyaWJlcnMgb2YgdGhlIGV4ZXJjaXNlIHNwZWNpZmljIHRlc3QgY2FzZXMuXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlSWRcbiAgICAgKiBAcGFyYW0gdGVzdENhc2VzXG4gICAgICovXG4gICAgcHJpdmF0ZSBub3RpZnlTdWJzY3JpYmVycyhleGVyY2lzZUlkOiBudW1iZXIsIHRlc3RDYXNlczogUHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlW10gfCB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5zdWJqZWN0c1tleGVyY2lzZUlkXS5uZXh0KHRlc3RDYXNlcyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRXhlY3V0ZXMgYSBSRVNUIHJlcXVlc3QgdG8gdGhlIHN0YXRpYyBjb2RlIGFuYWx5c2lzIGVuZHBvaW50LlxuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkXG4gICAgICovXG4gICAgcHVibGljIGdldENvZGVBbmFseXNpc0NhdGVnb3JpZXMoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxTdGF0aWNDb2RlQW5hbHlzaXNDYXRlZ29yeVtdPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFN0YXRpY0NvZGVBbmFseXNpc0NhdGVnb3J5W10+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7ZXhlcmNpc2VJZH0vc3RhdGljLWNvZGUtYW5hbHlzaXMtY2F0ZWdvcmllc2ApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZSB0aGUgZmllbGRzIHdpdGggdGhlIHByb3ZpZGVkIHZhbHVlcyBvZiB0aGUgc2NhIGNhdGVnb3JpZXMuXG4gICAgICogTmVlZHMgdGhlIGV4ZXJjaXNlIHRvIHZlcmlmeSBwZXJtaXNzaW9ucyBvbiB0aGUgc2VydmVyLlxuICAgICAqXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlSWRcbiAgICAgKiBAcGFyYW0gdXBkYXRlcyBkdG8gZm9yIHVwZGF0aW5nIHNjYSBjYXRlZ29yaWVzIHRvIGF2b2lkIHNldHRpbmcgYXV0b21hdGljIHBhcmFtZXRlcnNcbiAgICAgKi9cbiAgICBwdWJsaWMgdXBkYXRlQ29kZUFuYWx5c2lzQ2F0ZWdvcmllcyhleGVyY2lzZUlkOiBudW1iZXIsIHVwZGF0ZXM6IFN0YXRpY0NvZGVBbmFseXNpc0NhdGVnb3J5VXBkYXRlW10pOiBPYnNlcnZhYmxlPFN0YXRpY0NvZGVBbmFseXNpc0NhdGVnb3J5W10+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wYXRjaDxTdGF0aWNDb2RlQW5hbHlzaXNDYXRlZ29yeVtdPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L3N0YXRpYy1jb2RlLWFuYWx5c2lzLWNhdGVnb3JpZXNgLCB1cGRhdGVzKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXN0b3JlcyB0aGUgZGVmYXVsdCBzdGF0aWMgY29kZSBhbmFseXNpcyBjb25maWd1cmF0aW9uIGZvciB0aGUgZ2l2ZW4gZXhlcmNpc2UuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZFxuICAgICAqL1xuICAgIHB1YmxpYyByZXNldENhdGVnb3JpZXMoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxTdGF0aWNDb2RlQW5hbHlzaXNDYXRlZ29yeVtdPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucGF0Y2g8U3RhdGljQ29kZUFuYWx5c2lzQ2F0ZWdvcnlbXT4oYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtleGVyY2lzZUlkfS9zdGF0aWMtY29kZS1hbmFseXNpcy1jYXRlZ29yaWVzL3Jlc2V0YCwge30pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEltcG9ydHMgYW4gZXhpc3RpbmcgU0NBIGNvbmZpZ3VyYXRpb24gKGRlZmluZWQgaW4gdGhlIHNvdXJjZUV4ZXJjaXNlKSBpbnRvIHRoZSB0YXJnZXRFeGVyY2lzZVxuICAgICAqIGJ5IGNvbXBpbmcgYWxsIGNhdGVnb3JpZXMuXG4gICAgICogQHBhcmFtIHRhcmdldEV4ZXJjaXNlSWQgVGhlIGV4ZXJjaXNlIHRvIGNvcHkgdGhlIGNhdGVnb3JpZXMgaW5cbiAgICAgKiBAcGFyYW0gc291cmNlRXhlcmNpc2VJZCBUaGUgZXhlcmNpc2UgZnJvbSB3aGVyZSB0byBjb3B5IHRoZSBjYXRlZ29yaWVzXG4gICAgICogQHJldHVybiBUaGUgbmV3IGNhdGVnb3JpZXNcbiAgICAgKi9cbiAgICBwdWJsaWMgaW1wb3J0Q2F0ZWdvcmllc0Zyb21FeGVyY2lzZSh0YXJnZXRFeGVyY2lzZUlkOiBudW1iZXIsIHNvdXJjZUV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8U3RhdGljQ29kZUFuYWx5c2lzQ2F0ZWdvcnlbXT4ge1xuICAgICAgICBjb25zdCBwYXJhbXMgPSBuZXcgSHR0cFBhcmFtcygpLnNldCgnc291cmNlRXhlcmNpc2VJZCcsIHNvdXJjZUV4ZXJjaXNlSWQpO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBhdGNoPFN0YXRpY0NvZGVBbmFseXNpc0NhdGVnb3J5W10+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7dGFyZ2V0RXhlcmNpc2VJZH0vc3RhdGljLWNvZGUtYW5hbHlzaXMtY2F0ZWdvcmllcy9pbXBvcnRgLCB7fSwgeyBwYXJhbXMgfSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBBbGVydFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZUdyYWRpbmdTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9tYW5hZ2Uvc2VydmljZXMvcHJvZ3JhbW1pbmctZXhlcmNpc2UtZ3JhZGluZy5zZXJ2aWNlJztcbmltcG9ydCB7IEZlYXR1cmVUb2dnbGUgfSBmcm9tICdhcHAvc2hhcmVkL2ZlYXR1cmUtdG9nZ2xlL2ZlYXR1cmUtdG9nZ2xlLnNlcnZpY2UnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9wcm9ncmFtbWluZy1leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBCdXR0b25UeXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL2J1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgZmFSZWRvIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcblxuLyoqXG4gKiBBIGJ1dHRvbiB0aGF0IHJlLWV2YWx1YXRlcyBhbGwgbGF0ZXN0IGF1dG9tYXRpYyByZXN1bHRzIG9mIHRoZSBnaXZlbiBwcm9ncmFtbWluZyBleGVyY2lzZS5cbiAqL1xuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktcHJvZ3JhbW1pbmctZXhlcmNpc2UtcmUtZXZhbHVhdGUtYnV0dG9uJyxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICA8amhpLWJ1dHRvblxuICAgICAgICAgICAgaWQ9XCJyZS1ldmFsdWF0ZS1idXR0b25cIlxuICAgICAgICAgICAgY2xhc3M9XCJtcy0zXCJcbiAgICAgICAgICAgIFtkaXNhYmxlZF09XCJkaXNhYmxlZCB8fCBpc1JlRXZhbHVhdGlvblJ1bm5pbmdcIlxuICAgICAgICAgICAgW2J0blR5cGVdPVwiQnV0dG9uVHlwZS5FUlJPUlwiXG4gICAgICAgICAgICBbaXNMb2FkaW5nXT1cImlzUmVFdmFsdWF0aW9uUnVubmluZ1wiXG4gICAgICAgICAgICBbdG9vbHRpcF09XCInYXJ0ZW1pc0FwcC5wcm9ncmFtbWluZ0V4ZXJjaXNlLnJlRXZhbHVhdGVUb29sdGlwJ1wiXG4gICAgICAgICAgICBbaWNvbl09XCJmYVJlZG9cIlxuICAgICAgICAgICAgW3RpdGxlXT1cIidhcnRlbWlzQXBwLnByb2dyYW1taW5nRXhlcmNpc2UucmVFdmFsdWF0ZSdcIlxuICAgICAgICAgICAgW2ZlYXR1cmVUb2dnbGVdPVwiRmVhdHVyZVRvZ2dsZS5Qcm9ncmFtbWluZ0V4ZXJjaXNlc1wiXG4gICAgICAgICAgICAob25DbGljayk9XCJ0cmlnZ2VyUmVFdmFsdWF0ZSgpXCJcbiAgICAgICAgPlxuICAgICAgICA8L2poaS1idXR0b24+XG4gICAgYCxcbn0pXG5leHBvcnQgY2xhc3MgUHJvZ3JhbW1pbmdFeGVyY2lzZVJlRXZhbHVhdGVCdXR0b25Db21wb25lbnQge1xuICAgIEZlYXR1cmVUb2dnbGUgPSBGZWF0dXJlVG9nZ2xlO1xuICAgIEJ1dHRvblR5cGUgPSBCdXR0b25UeXBlO1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlO1xuICAgIEBJbnB1dCgpIGRpc2FibGVkID0gZmFsc2U7XG5cbiAgICBpc1JlRXZhbHVhdGlvblJ1bm5pbmcgPSBmYWxzZTtcblxuICAgIC8vIEljb25zXG4gICAgZmFSZWRvID0gZmFSZWRvO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgdGVzdENhc2VTZXJ2aWNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlR3JhZGluZ1NlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogVHJpZ2dlcnMgdGhlIHJlLWV2YWx1YXRpb24gb2YgdGhlIHByb2dyYW1taW5nIGV4ZXJjaXNlIGFuZCBkaXNwbGF5cyB0aGUgcmVzdWx0IGluIHRoZSBlbmQgdXNpbmcgYW4gYWxlcnQuXG4gICAgICovXG4gICAgdHJpZ2dlclJlRXZhbHVhdGUoKSB7XG4gICAgICAgIHRoaXMuaXNSZUV2YWx1YXRpb25SdW5uaW5nID0gdHJ1ZTtcbiAgICAgICAgdGhpcy50ZXN0Q2FzZVNlcnZpY2UucmVFdmFsdWF0ZSh0aGlzLmV4ZXJjaXNlLmlkISkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5leHQ6ICh1cGRhdGVkUmVzdWx0c0NvdW50OiBudW1iZXIpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmlzUmVFdmFsdWF0aW9uUnVubmluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLnN1Y2Nlc3MoYGFydGVtaXNBcHAucHJvZ3JhbW1pbmdFeGVyY2lzZS5yZUV2YWx1YXRlU3VjY2Vzc2Z1bGAsIHsgbnVtYmVyOiB1cGRhdGVkUmVzdWx0c0NvdW50IH0pO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yOiAoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5pc1JlRXZhbHVhdGlvblJ1bm5pbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5lcnJvcihgYXJ0ZW1pc0FwcC5wcm9ncmFtbWluZ0V4ZXJjaXNlLnJlRXZhbHVhdGVGYWlsZWRgLCB7IG1lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3RvclRyaWdnZXJCdWlsZEJ1dHRvbkNvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2FjdGlvbnMvcHJvZ3JhbW1pbmctZXhlcmNpc2UtaW5zdHJ1Y3Rvci10cmlnZ2VyLWJ1aWxkLWJ1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZVN0dWRlbnRUcmlnZ2VyQnVpbGRCdXR0b25Db21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9hY3Rpb25zL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXN0dWRlbnQtdHJpZ2dlci1idWlsZC1idXR0b24uY29tcG9uZW50JztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdG9yU3VibWlzc2lvblN0YXRlQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvYWN0aW9ucy9wcm9ncmFtbWluZy1leGVyY2lzZS1pbnN0cnVjdG9yLXN1Ym1pc3Npb24tc3RhdGUuY29tcG9uZW50JztcbmltcG9ydCB7XG4gICAgUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0b3JUcmlnZ2VyQWxsRGlhbG9nQ29tcG9uZW50LFxuICAgIFByb2dyYW1taW5nRXhlcmNpc2VUcmlnZ2VyQWxsQnV0dG9uQ29tcG9uZW50LFxufSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9hY3Rpb25zL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXRyaWdnZXItYWxsLWJ1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZVJlRXZhbHVhdGVCdXR0b25Db21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9hY3Rpb25zL3Byb2dyYW1taW5nLWV4ZXJjaXNlLXJlLWV2YWx1YXRlLWJ1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9zaGFyZWQtY29tcG9uZW50Lm1vZHVsZSc7XG5pbXBvcnQgeyBGZWF0dXJlVG9nZ2xlTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9mZWF0dXJlLXRvZ2dsZS9mZWF0dXJlLXRvZ2dsZS5tb2R1bGUnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlLCBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlLCBGZWF0dXJlVG9nZ2xlTW9kdWxlXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtcbiAgICAgICAgUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0b3JUcmlnZ2VyQnVpbGRCdXR0b25Db21wb25lbnQsXG4gICAgICAgIFByb2dyYW1taW5nRXhlcmNpc2VTdHVkZW50VHJpZ2dlckJ1aWxkQnV0dG9uQ29tcG9uZW50LFxuICAgICAgICBQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3RvclN1Ym1pc3Npb25TdGF0ZUNvbXBvbmVudCxcbiAgICAgICAgUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0b3JUcmlnZ2VyQWxsRGlhbG9nQ29tcG9uZW50LFxuICAgICAgICBQcm9ncmFtbWluZ0V4ZXJjaXNlVHJpZ2dlckFsbEJ1dHRvbkNvbXBvbmVudCxcbiAgICAgICAgUHJvZ3JhbW1pbmdFeGVyY2lzZVJlRXZhbHVhdGVCdXR0b25Db21wb25lbnQsXG4gICAgXSxcbiAgICBleHBvcnRzOiBbXG4gICAgICAgIFByb2dyYW1taW5nRXhlcmNpc2VJbnN0cnVjdG9yVHJpZ2dlckJ1aWxkQnV0dG9uQ29tcG9uZW50LFxuICAgICAgICBQcm9ncmFtbWluZ0V4ZXJjaXNlU3R1ZGVudFRyaWdnZXJCdWlsZEJ1dHRvbkNvbXBvbmVudCxcbiAgICAgICAgUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0b3JTdWJtaXNzaW9uU3RhdGVDb21wb25lbnQsXG4gICAgICAgIFByb2dyYW1taW5nRXhlcmNpc2VUcmlnZ2VyQWxsQnV0dG9uQ29tcG9uZW50LFxuICAgICAgICBQcm9ncmFtbWluZ0V4ZXJjaXNlUmVFdmFsdWF0ZUJ1dHRvbkNvbXBvbmVudCxcbiAgICBdLFxufSlcbmV4cG9ydCBjbGFzcyBBcnRlbWlzUHJvZ3JhbW1pbmdFeGVyY2lzZUFjdGlvbnNNb2R1bGUge31cbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IFN1Ym1pc3Npb25SZXN1bHRTdGF0dXNDb21wb25lbnQgfSBmcm9tICdhcHAvb3ZlcnZpZXcvc3VibWlzc2lvbi1yZXN1bHQtc3RhdHVzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBVcGRhdGluZ1Jlc3VsdENvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3Jlc3VsdC91cGRhdGluZy1yZXN1bHQuY29tcG9uZW50JztcbmltcG9ydCB7IEFydGVtaXNQcm9ncmFtbWluZ0V4ZXJjaXNlQWN0aW9uc01vZHVsZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2FjdGlvbnMvcHJvZ3JhbW1pbmctZXhlcmNpc2UtYWN0aW9ucy5tb2R1bGUnO1xuaW1wb3J0IHsgUmVzdWx0Q29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcmVzdWx0L3Jlc3VsdC5jb21wb25lbnQnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlLCBBcnRlbWlzUHJvZ3JhbW1pbmdFeGVyY2lzZUFjdGlvbnNNb2R1bGVdLFxuICAgIGRlY2xhcmF0aW9uczogW1N1Ym1pc3Npb25SZXN1bHRTdGF0dXNDb21wb25lbnQsIFVwZGF0aW5nUmVzdWx0Q29tcG9uZW50LCBSZXN1bHRDb21wb25lbnRdLFxuICAgIGV4cG9ydHM6IFtTdWJtaXNzaW9uUmVzdWx0U3RhdHVzQ29tcG9uZW50LCBVcGRhdGluZ1Jlc3VsdENvbXBvbmVudCwgUmVzdWx0Q29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgU3VibWlzc2lvblJlc3VsdFN0YXR1c01vZHVsZSB7fVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLGlCQUFpQjtBQUMxQixTQUFTLHdCQUF3QjtBQUdqQyxTQUFTLGdCQUFnQjtBQUt6QixTQUFTLGNBQWM7Ozs7Ozs7QUNSbkIsSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsY0FBQSxDQUFBO0FBTUksSUFBQSx3QkFBQSxXQUFBLFNBQUEsOEdBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQVcseUJBQUEsT0FBQSxhQUFBLE1BQUEsQ0FBb0I7SUFBQSxDQUFBO0FBSW5DLElBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxJQUFBOzs7O0FBVlEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxXQUFBLE9BQUEsT0FBQSxFQUFtQixXQUFBLE9BQUEsZ0RBQUEsT0FBQSxXQUFBLFFBQUEsT0FBQSxXQUFBLE9BQUEsRUFBQSxRQUFBLE9BQUEsTUFBQSxFQUFBLFlBQUEsT0FBQSx1QkFBQSxFQUFBLGFBQUEsT0FBQSxVQUFBLEVBQUEsV0FBQSxPQUFBLGdEQUFBLDhEQUFBLHlDQUFBLEVBQUEsaUJBQUEsT0FBQSxjQUFBLG9CQUFBOzs7QURGM0IsSUFlYTtBQWZiOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7Ozs7O0FBT00sSUFBTywyREFBUCxNQUFPLGtFQUFpRSwrQ0FBOEM7TUFRNUc7TUFDQTtNQVBaLFNBQVM7TUFFVCxZQUNJLG1CQUNBLGNBQ0EsK0JBQ1Esa0JBQ0EsY0FBc0I7QUFFOUIsY0FBTSxtQkFBbUIsK0JBQStCLFlBQVk7QUFINUQsYUFBQSxtQkFBQTtBQUNBLGFBQUEsZUFBQTtBQUdSLGFBQUssK0JBQStCO0FBQ3BDLGFBQUssd0JBQXdCO01BQ2pDO01BRUEsZUFBZSxDQUFDLFVBQWM7QUFFMUIsY0FBTSxnQkFBZTtBQUNyQixZQUFJLEtBQUssK0NBQStDO0FBQ3BELGdCQUFNLGNBQWEsRUFBRyxVQUFTO2VBQzVCO0FBQ0gsZ0JBQU0sZ0JBQWUsWUFBQSxFQUE0QixVQUFTOztBQUU5RCxZQUFJLENBQUMsS0FBSyxvQkFBb0I7QUFDMUIsZ0JBQU0sZ0JBQWUsWUFBQTtBQUNyQjs7QUFHSixjQUFNLFdBQVcsS0FBSyxhQUFhLEtBQUssZ0NBQWdDLEVBQUUsVUFBVSxNQUFNLE1BQU0sS0FBSSxDQUFFO0FBQ3RHLGlCQUFTLGtCQUFrQixRQUFRO0FBQ25DLGlCQUFTLGtCQUFrQixPQUFPLEtBQUssaUJBQWlCLFFBQVEsb0VBQW9FO0FBQ3BJLGlCQUFTLE9BQU8sS0FBSyxNQUFLO0FBQ3RCLGdCQUFNLGdCQUFlLFlBQUE7UUFDekIsQ0FBQztNQUNMOzt5QkFuQ1MsMkRBQXdELCtCQUFBLDRCQUFBLEdBQUEsK0JBQUEsWUFBQSxHQUFBLCtCQUFBLDZCQUFBLEdBQUEsK0JBQUEsbUJBQUEsR0FBQSwrQkFBQSxXQUFBLENBQUE7TUFBQTtnRUFBeEQsMkRBQXdELFdBQUEsQ0FBQSxDQUFBLDBEQUFBLENBQUEsR0FBQSxVQUFBLENBQUEsdUNBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsV0FBQSxXQUFBLFFBQUEsWUFBQSxhQUFBLFdBQUEsaUJBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGtFQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDZnJFLFVBQUEsd0JBQUEsR0FBQSxpRkFBQSxHQUFBLENBQUE7OztBQUFBLFVBQUEsMkJBQUEsR0FBQSxJQUFBLHFDQUFBLElBQUEsZ0NBQUEsSUFBQSxpREFBQSxJQUFBLEVBQUE7Ozs7O29GRGVhLDBEQUF3RCxFQUFBLFdBQUEsMkRBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFZnJFLFNBQVMsa0JBQTZCO0FBQ3RDLFNBQVMsdUJBQW1DO0FBQzVDLFNBQVMsUUFBUSxXQUFXOztBQUY1QixJQVFZLGVBaUJDO0FBekJiOztBQUdBOztBQUtBLEtBQUEsU0FBWUEsZ0JBQWE7QUFDckIsTUFBQUEsZUFBQSxTQUFBLElBQUE7QUFDQSxNQUFBQSxlQUFBLFdBQUEsSUFBQTtJQUNKLEdBSFksa0JBQUEsZ0JBQWEsQ0FBQSxFQUFBO0FBaUJuQixJQUFPLDZCQUFQLE1BQU8sNEJBQTBCO01BT2Y7TUFMWixtQkFBb0csQ0FBQTtNQUNwRyxpQkFBOEQsQ0FBQTtNQUU5RCwyQkFBMkI7TUFFbkMsWUFBb0Isa0JBQXFDO0FBQXJDLGFBQUEsbUJBQUE7TUFBd0M7TUFLNUQsY0FBVztBQUNQLGVBQU8sT0FBTyxLQUFLLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxZQUFZLFFBQVEsWUFBVyxDQUFFO01BQ25GO01BRVEsa0JBQWtCLHVCQUErQixlQUE0QjtBQUNqRixjQUFNLFVBQVUsS0FBSyxpQkFBaUIscUJBQXFCO0FBQzNELFlBQUksU0FBUztBQUNULGtCQUFRLEtBQUssYUFBYTtlQUN2QjtBQUNILGVBQUssaUJBQWlCLHFCQUFxQixJQUFJLElBQUksZ0JBQTJDLGFBQWE7O01BRW5IO01BRVEsbUJBQW1CLHVCQUE2QjtBQUNwRCxZQUFJLENBQUMsS0FBSyxlQUFlLHFCQUFxQixHQUFHO0FBQzdDLGdCQUFNLHFCQUFxQixLQUFLLHlCQUF5QixRQUFRLDJCQUEyQixzQkFBc0IsU0FBUSxDQUFFO0FBQzVILGVBQUssZUFBZSxxQkFBcUIsSUFBSTtBQUM3QyxlQUFLLGlCQUFpQixVQUFVLGtCQUFrQjtBQUNsRCxlQUFLLGlCQUNBLFFBQVEsa0JBQWtCLEVBRTFCLEtBQUssSUFBSSxDQUFDLGtCQUFpQyxLQUFLLGtCQUFrQix1QkFBdUIsYUFBYSxDQUFDLENBQUMsRUFDeEcsVUFBUzs7TUFFdEI7TUFPQSxtQkFBbUIsdUJBQTZCO0FBQzVDLGNBQU0sVUFBVSxLQUFLLGlCQUFpQixxQkFBcUI7QUFDM0QsWUFBSSxTQUFTO0FBQ1QsaUJBQU8sUUFBUSxhQUFZLEVBQUcsS0FBSyxPQUFPLENBQUMsYUFBYSxhQUFhLE1BQVMsQ0FBQzs7QUFFbkYsY0FBTSxhQUFhLElBQUksZ0JBQTJDLE1BQVM7QUFDM0UsYUFBSyxpQkFBaUIscUJBQXFCLElBQUk7QUFDL0MsYUFBSyxtQkFBbUIscUJBQXFCO0FBQzdDLGVBQU8sV0FBVyxLQUFLLE9BQU8sQ0FBQyxhQUFhLGFBQWEsTUFBUyxDQUFDO01BQ3ZFOzt5QkFwRFMsNkJBQTBCLHVCQUFBLG1CQUFBLENBQUE7TUFBQTtvRUFBMUIsNkJBQTBCLFNBQTFCLDRCQUEwQixXQUFBLFlBRGIsT0FBTSxDQUFBOzs7Ozs7QUN4QmhDLFNBQVMsYUFBQUMsWUFBVyxjQUFjLE9BQWUsY0FBYztBQUMvRCxTQUFTLFlBQVksT0FBQUMsWUFBVztBQUVoQyxTQUFTLFVBQVU7QUFDbkIsU0FBUyxnQkFBZ0IsWUFBQUMsaUJBQWdCO0FBTXpDLFNBQVMsT0FBTyxVQUFBQyxTQUFRLGVBQWU7Ozs7Ozs7QUFtRm5CLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEscVRBQUE7QUFFSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7QUFqR2hCLElBaUNhLDhDQWlGQTtBQWxIYjs7QUFFQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7O0FBd0JNLElBQU8sK0NBQVAsTUFBTyw4Q0FBNEM7TUFXekM7TUFDQTtNQUNBO01BWlosZ0JBQWdCO01BQ2hCLGFBQWE7TUFDSjtNQUNBLFdBQVc7TUFDVixtQkFBbUIsSUFBSSxhQUFZO01BQzdDLHVCQUF1QjtNQUV2QixTQUFTQTtNQUVULFlBQ1ksbUJBQ0EsNEJBQ0EsY0FBc0I7QUFGdEIsYUFBQSxvQkFBQTtBQUNBLGFBQUEsNkJBQUE7QUFDQSxhQUFBLGVBQUE7TUFDVDtNQUVILFdBQVE7QUFFSixhQUFLLHlCQUF3QjtNQUNqQztNQU9BLHNCQUFtQjtBQUNmLGNBQU0sV0FBVyxLQUFLLGFBQWEsS0FBSyx3REFBd0QsRUFBRSxNQUFNLE1BQU0sVUFBVSxTQUFRLENBQUU7QUFDbEksaUJBQVMsa0JBQWtCLGFBQWEsS0FBSyxTQUFTO0FBQ3RELGlCQUFTLGtCQUFrQixnQkFBZ0IsaUJBQWlCLEtBQUssUUFBUTtBQUN6RSxpQkFBUyxPQUFPLEtBQUssTUFBSztBQUN0QixlQUFLLGtCQUNBLHFEQUFxRCxLQUFLLFNBQVMsRUFBRyxFQUN0RSxLQUFLLFdBQVcsTUFBTSxHQUFHLE1BQVMsQ0FBQyxDQUFDLEVBQ3BDLFVBQVUsTUFBSztBQUNaLGlCQUFLLGlCQUFpQixLQUFJO1VBQzlCLENBQUM7UUFDVCxDQUFDO01BQ0w7TUFFUSwyQkFBd0I7QUFDNUIsYUFBSywyQkFDQSxtQkFBbUIsS0FBSyxTQUFTLEVBQUcsRUFDcEMsS0FBS0YsS0FBSSxDQUFDLGtCQUFtQixLQUFLLHVCQUF1QixrQkFBa0IsY0FBYyxPQUFRLENBQUMsRUFDbEcsVUFBUztNQUNsQjs7eUJBN0NTLCtDQUE0QyxnQ0FBQSw0QkFBQSxHQUFBLGdDQUFBLDBCQUFBLEdBQUEsZ0NBQUEsV0FBQSxDQUFBO01BQUE7aUVBQTVDLCtDQUE0QyxXQUFBLENBQUEsQ0FBQSw2Q0FBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFVBQUEsWUFBQSxVQUFBLFdBQUEsR0FBQSxTQUFBLEVBQUEsa0JBQUEsbUJBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLE1BQUEsc0JBQUEsR0FBQSxRQUFBLEdBQUEsWUFBQSxXQUFBLGFBQUEsV0FBQSxRQUFBLFNBQUEsaUJBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHNEQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FBZmpELFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLGNBQUEsQ0FBQTtBQVVJLFVBQUEseUJBQUEsV0FBQSxTQUFBLHNGQUFBO0FBQUEsbUJBQVcsSUFBQSxvQkFBQTtVQUFxQixDQUFBO0FBRXBDLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsR0FBQSxRQUFBOzs7QUFWUSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFlBQUEsSUFBQSxRQUFBLEVBQXFCLFdBQUEsSUFBQSxXQUFBLEtBQUEsRUFBQSxhQUFBLElBQUEsb0JBQUEsRUFBQSxXQUFBLG1EQUFBLEVBQUEsUUFBQSxJQUFBLE1BQUEsRUFBQSxTQUFBLDRDQUFBLEVBQUEsaUJBQUEsSUFBQSxjQUFBLG9CQUFBOzs7OztxRkFZcEIsOENBQTRDLEVBQUEsV0FBQSwrQ0FBQSxDQUFBO0lBQUEsR0FBQTtBQWlGbkQsSUFBTyx5REFBUCxNQUFPLHdEQUFzRDtNQVEzQztNQVBYO01BQ0E7TUFHVCxRQUFRO01BQ1IsVUFBVTtNQUVWLFlBQW9CLGFBQTJCO0FBQTNCLGFBQUEsY0FBQTtNQUE4QjtNQUVsRCxTQUFNO0FBQ0YsYUFBSyxZQUFZLFFBQVEsUUFBUTtNQUNyQztNQUVBLGlCQUFjO0FBQ1YsYUFBSyxZQUFZLE1BQUs7TUFDMUI7O3lCQWhCUyx5REFBc0QsZ0NBQUEsaUJBQUEsQ0FBQTtNQUFBO2lFQUF0RCx5REFBc0QsV0FBQSxDQUFBLENBQUEsY0FBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFlBQUEsY0FBQSxlQUFBLGdCQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxRQUFBLGtCQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxnQkFBQSw4Q0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxnQkFBQSxTQUFBLGVBQUEsUUFBQSxHQUFBLGFBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLGdCQUFBLGtEQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxnQkFBQSxTQUFBLEdBQUEsT0FBQSxpQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsc0JBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLE9BQUEsWUFBQSxHQUFBLENBQUEsZ0JBQUEsdUJBQUEsR0FBQSxDQUFBLGdCQUFBLGlFQUFBLEdBQUEsZUFBQSxrQkFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGdFQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FBNUIzRCxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFBNEIsVUFBQSx5QkFBQSxZQUFBLFNBQUEsMkZBQUE7QUFBQSxtQkFBWSxJQUFBLGVBQUE7VUFBZ0IsQ0FBQTtBQUNwRCxVQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUFrRixVQUFBLHFCQUFBLEdBQUEsYUFBQTtBQUFXLFVBQUEsMkJBQUE7QUFDN0YsVUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUFnRixVQUFBLHlCQUFBLFNBQUEsU0FBQSwwRkFBQTtBQUFBLG1CQUFTLElBQUEsT0FBQTtVQUFRLENBQUE7QUFBRSxVQUFBLDJCQUFBO0FBQ3ZHLFVBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLGdGQUFBLEdBQUEsQ0FBQTtBQU1BLFVBQUEsNkJBQUEsSUFBQSxLQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsaU1BQUE7QUFDSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsVUFBQSxDQUFBO0FBQXFFLFVBQUEseUJBQUEsU0FBQSxTQUFBLDJGQUFBO0FBQUEsbUJBQVMsSUFBQSxPQUFBO1VBQVEsQ0FBQTtBQUNsRixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsV0FBQSxDQUFBO0FBQWtDLFVBQUEscUJBQUEsSUFBQSxNQUFBO0FBQU0sVUFBQSw2QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUEwQyxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFNLFVBQUEsMkJBQUE7QUFDNUYsVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsV0FBQSxDQUFBO0FBQW9DLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUNwQyxVQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQTJDLFVBQUEscUJBQUEsSUFBQSxTQUFBO0FBQU8sVUFBQSwyQkFBQTtBQUN0RCxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBOzs7QUFwQlksVUFBQSx3QkFBQSxFQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsZ0JBQUEsS0FBQSxFQUFBO0FBWWEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsS0FBQTtBQUdBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLE9BQUE7Ozs7O3FGQU9oQix3REFBc0QsRUFBQSxXQUFBLHlEQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBQ2xIbkUsU0FBUyxhQUFBRyxZQUFXLFNBQUFDLGNBQStDO0FBQ25FLFNBQVMsY0FBYyxLQUFLLE9BQUFDLFlBQVc7QUFPdkMsU0FBUyxlQUFlLFNBQVMsVUFBQUMsZUFBYzs7Ozs7OztBQ0xuQyxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7Ozs7QUFHSyxJQUFBLHFCQUFBLENBQUE7O0FBQTBDLElBQUEsMkJBQUE7QUFFbkQsSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBOzs7O0FBUGlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLE9BQUE7QUFFTCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGNBQUEsMEJBQUEsR0FBQSxHQUFBLGlEQUFBLENBQUEsRUFBbUYsYUFBQSwwQkFBQSxHQUFBLEdBQUEsNENBQUEsOEJBQUEsSUFBQSxLQUFBLDBCQUFBLEdBQUEsR0FBQSxPQUFBLGFBQUEsQ0FBQSxDQUFBLEdBQUEsNEJBQUE7QUFFbEYsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxnQkFBQSwwQkFBQSxJQUFBLElBQUEsT0FBQSxhQUFBLEdBQUEsRUFBQTs7Ozs7O0FBUGpCLElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDRGQUFBLElBQUEsRUFBQTtBQVVBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBOztBQVFJLElBQUEscUJBQUEsQ0FBQTtBQUNKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsUUFBQSxDQUFBOztBQU9JLElBQUEscUJBQUEsRUFBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSwrQ0FBQSxDQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsY0FBQSxDQUFBO0FBU0ksSUFBQSx5QkFBQSxXQUFBLFNBQUEsOEdBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFXLDBCQUFBLE9BQUEsZ0NBQUEsQ0FBaUM7SUFBQSxDQUFBO0FBQy9DLElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsSUFBQTs7OztBQTVDUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSx5QkFBQSxJQUFBLEVBQUE7QUFjUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGFBQUEsMEJBQUEsR0FBQSxJQUFBLHNEQUFBLDhCQUFBLElBQUEsS0FBQSxPQUFBLGdCQUFBLE9BQUEsMkJBQUEsOEJBQUEsS0FBQSxDQUFBLENBQUEsR0FBQSw0QkFBQTtBQUtBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsNENBQUEsT0FBQSxnQkFBQSxPQUFBLDJCQUFBLDhCQUFBLEtBQUEsR0FBQSxnQkFBQTtBQUlBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSw4QkFBQSxJQUFBLEtBQUEsT0FBQSxnQkFBQSxPQUFBLDJCQUFBLHFCQUFBLElBQUEsSUFBQSxjQUFBLFlBQUEsQ0FBQSxFQUF3SSxhQUFBLDBCQUFBLElBQUEsSUFBQSxvREFBQSw4QkFBQSxJQUFBLEtBQUEsT0FBQSxnQkFBQSxPQUFBLDJCQUFBLHFCQUFBLEtBQUEsQ0FBQSxDQUFBLEdBQUEsNEJBQUE7QUFLeEksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQ0FBQSxPQUFBLGdCQUFBLE9BQUEsMkJBQUEscUJBQUEsS0FBQSxHQUFBLGdCQUFBO0FBR3FDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxPQUFBLFFBQUE7QUFJekMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLENBQUEsT0FBQSxvQkFBQSxFQUFrQyxhQUFBLE9BQUEsMkJBQUEsRUFBQSxRQUFBLE9BQUEsTUFBQSxFQUFBLFNBQUEsK0NBQUEsRUFBQSxXQUFBLHNEQUFBLEVBQUEsaUJBQUEsT0FBQSxjQUFBLG9CQUFBOzs7OztBQVUxQyxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsSUFBQTs7OztBQURhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLGFBQUEsRUFBc0IsUUFBQSxJQUFBOzs7QUQvQ25DLG1CQXFCYTtBQXJCYjs7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUFjTSxJQUFPLHdEQUFQLE1BQU8sdURBQXFEO01Bc0IxQztNQXJCcEIsZ0JBQWdCO01BQ2hCLGFBQWE7TUFDYiw2QkFBNkI7TUFFcEI7TUFFVCx1QkFBdUI7TUFDdkIseUJBQXlCO01BQ3pCO01BQ0EsOEJBQThCO01BRTlCO01BRUE7TUFDQTtNQUdBLFVBQVU7TUFDVixnQkFBZ0I7TUFDaEIsU0FBU0E7TUFFVCxZQUFvQiw4QkFBMEQ7QUFBMUQsYUFBQSwrQkFBQTtNQUE2RDtNQUVqRixXQUFRO0FBQ0osYUFBSyx3QkFBd0IsS0FBSyw2QkFBNkIsaUJBQWdCLEVBQUcsVUFBVSxDQUFDLGNBQWUsS0FBSyxnQkFBZ0IsU0FBVTtNQUMvSTtNQU9BLFlBQVksU0FBc0I7QUFDOUIsWUFBSSxtQkFBbUIsT0FBTyxHQUFHO0FBQzdCLGVBQUssOEJBQThCLEtBQUssNkJBQ25DLDZCQUE2QixLQUFLLFNBQVMsRUFBRyxFQUM5QyxLQUNHLElBQUksS0FBSyxtQkFBbUIsR0FFNUIsYUFBYSxHQUFHLEdBQ2hCRCxLQUFJLENBQUMsb0JBQTBEO0FBQzNELGlCQUFLLGtCQUFrQjtBQUN2QixpQkFBSyx1QkFBdUIsS0FBSyxnQkFBZ0IsMkJBQTJCLHFCQUFxQixJQUFJO0FBQ3JHLGlCQUFLLHlCQUF5QixLQUFLLGdCQUFnQiwyQkFBMkIsOEJBQThCLElBQUk7VUFDcEgsQ0FBQyxDQUFDLEVBRUwsVUFBUzs7TUFFdEI7TUFLQSxrQ0FBK0I7QUFDM0IsYUFBSyw4QkFBOEI7QUFDbkMsY0FBTSxpQ0FBaUMsS0FBSyw2QkFBNkIseUJBQXlCLEtBQUssU0FBUyxJQUFLLDJCQUEyQixxQkFBcUI7QUFDckssYUFBSyw2QkFDQSxrREFBa0QsS0FBSyxTQUFTLElBQUssOEJBQThCLEVBQ25HLFVBQVUsTUFBTyxLQUFLLDhCQUE4QixLQUFNO01BQ25FO01BRVEsc0JBQXNCLENBQUMsZUFDM0IsT0FBTyxPQUFPLFVBQVUsRUFBRSxPQUFPLENBQUMsS0FBa0MsRUFBRSxnQkFBZSxNQUFNO0FBQ3ZGLGVBQU8saUNBQUssTUFBTCxFQUFVLENBQUMsZUFBZSxJQUFJLElBQUksZUFBZSxLQUFLLEtBQUssRUFBQztNQUN2RSxHQUFHLENBQUEsQ0FBRTs7eUJBakVBLHdEQUFxRCxnQ0FBQSw0QkFBQSxDQUFBO01BQUE7aUVBQXJELHdEQUFxRCxXQUFBLENBQUEsQ0FBQSxzREFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFVBQUEsV0FBQSxHQUFBLFVBQUEsQ0FBQSxrQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxRQUFBLEdBQUEsQ0FBQSxNQUFBLGVBQUEsR0FBQSxVQUFBLGVBQUEseUJBQUEsR0FBQSxDQUFBLE1BQUEsd0JBQUEsR0FBQSxTQUFBLGNBQUEsZUFBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLE1BQUEsc0JBQUEsR0FBQSxXQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsTUFBQSx5QkFBQSxHQUFBLFFBQUEsR0FBQSxZQUFBLGFBQUEsUUFBQSxTQUFBLFdBQUEsaUJBQUEsU0FBQSxHQUFBLENBQUEsTUFBQSxjQUFBLEdBQUEsU0FBQSxnQkFBQSxVQUFBLGVBQUEsMkJBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLE1BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSwrREFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ3JCbEUsVUFBQSx5QkFBQSxHQUFBLDhFQUFBLElBQUEsRUFBQSxFQThDQyxHQUFBLDhFQUFBLEdBQUEsQ0FBQTs7O0FBOUNELFVBQUEsNEJBQUEsR0FBQSxJQUFBLGtCQUFBLElBQUEsQ0FBQTs7Ozs7cUZEcUJhLHVEQUFxRCxFQUFBLFdBQUEsd0RBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFckJsRSxTQUFTLGNBQUFFLG1CQUE2QjtBQUN0QyxTQUFTLFlBQVksa0JBQWtCO0FBQ3ZDLFNBQVMsbUJBQUFDLGtCQUE2QixNQUFBQyxXQUFVO0FBQ2hELFNBQVMsY0FBQUMsYUFBWSxPQUFBQyxNQUFLLFdBQVcsT0FBQUMsWUFBVzs7O0FBSGhELElBU2EsbUNBYUEsa0NBMEJBO0FBaERiOztBQUlBOztBQUtNLElBQU8sb0NBQVAsTUFBTyxtQ0FBaUM7TUFFL0I7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUxYLFlBQ1csSUFDQSxRQUNBLGFBQ0EsaUJBQ0EsWUFBdUI7QUFKdkIsYUFBQSxLQUFBO0FBQ0EsYUFBQSxTQUFBO0FBQ0EsYUFBQSxjQUFBO0FBQ0EsYUFBQSxrQkFBQTtBQUNBLGFBQUEsYUFBQTtNQUNSO01BRUgsT0FBTyxLQUFLLFVBQXFDO0FBQzdDLGVBQU8sSUFBSSxtQ0FBa0MsU0FBUyxJQUFJLFNBQVMsUUFBUSxTQUFTLGFBQWEsU0FBUyxpQkFBaUIsU0FBUyxVQUFVO01BQ2xKOztBQUVFLElBQU8sbUNBQVAsTUFBTyxrQ0FBZ0M7TUFFOUI7TUFDQTtNQUNBO01BQ0E7TUFKWCxZQUNXLElBQ0EsU0FDQSxZQUNBLE9BQWM7QUFIZCxhQUFBLEtBQUE7QUFDQSxhQUFBLFVBQUE7QUFDQSxhQUFBLGFBQUE7QUFDQSxhQUFBLFFBQUE7TUFDUjtNQUVILE9BQU8sS0FBSyxVQUFvQztBQUM1QyxlQUFPLElBQUksa0NBQWlDLFNBQVMsSUFBSSxTQUFTLFNBQVMsU0FBUyxZQUFZLFNBQVMsS0FBSztNQUNsSDs7QUFnQkUsSUFBTyxvQ0FBUCxNQUFPLG1DQUFpQztNQVE5QjtNQUNBO01BUkwsY0FBYztNQUViLGNBQWdELENBQUE7TUFDaEQsV0FBaUcsQ0FBQTtNQUNqRyxZQUF3RCxvQkFBSSxJQUFHO01BRXZFLFlBQ1kscUJBQ0EsTUFBZ0I7QUFEaEIsYUFBQSxzQkFBQTtBQUNBLGFBQUEsT0FBQTtNQUNUO01BS0gsY0FBVztBQUNQLGVBQU8sT0FBTyxLQUFLLFdBQVcsRUFBRSxRQUFRLENBQUMsZUFBZSxLQUFLLG9CQUFvQixZQUFZLFVBQVUsQ0FBQztNQUM1RztNQVdBLHNCQUFzQixZQUFrQjtBQUNwQyxZQUFJLEtBQUssU0FBUyxVQUFVLEdBQUc7QUFDM0IsaUJBQU8sS0FBSyxTQUFTLFVBQVU7O0FBRW5DLGVBQU8sS0FBSyxhQUFhLFVBQVUsRUFBRSxLQUNqQ0QsS0FBSSxDQUFDLGNBQWUsVUFBVSxTQUFTLFlBQVksTUFBVSxHQUM3REQsWUFBVyxNQUFNRCxJQUFHLE1BQVMsQ0FBQyxHQUM5QixVQUFVLENBQUMsY0FBd0Q7QUFDL0QsY0FBSSxXQUFXO0FBQ1gsaUJBQUssVUFBVSxJQUFJLFlBQVksU0FBUzs7QUFFNUMsaUJBQU8sS0FBSyx5QkFBeUIsWUFBWSxTQUFTO1FBQzlELENBQUMsQ0FBQztNQUVWO01BT08sZ0JBQWdCLFlBQW9CLFdBQXdDO0FBQy9FLFlBQUksS0FBSyxTQUFTLFVBQVUsR0FBRztBQUMzQixlQUFLLFNBQVMsVUFBVSxFQUFFLEtBQUssU0FBUzs7TUFFaEQ7TUFNTyxhQUFhLFlBQWtCO0FBQ2xDLFlBQUksS0FBSyxVQUFVLElBQUksVUFBVSxHQUFHO0FBQ2hDLGlCQUFPQSxJQUFHLEtBQUssVUFBVSxJQUFJLFVBQVUsQ0FBRTs7QUFFN0MsZUFBTyxLQUFLLEtBQUssSUFBbUMsR0FBRyxLQUFLLFdBQVcsSUFBSSxVQUFVLGFBQWEsRUFBRSxLQUNoR0csS0FBSSxDQUFDLGNBQWE7QUFDZCxlQUFLLFVBQVUsSUFBSSxZQUFZLFNBQVM7UUFDNUMsQ0FBQyxDQUFDO01BRVY7TUFTTyxlQUFlLFlBQW9CLFNBQTRDO0FBQ2xGLGVBQU8sS0FBSyxLQUFLLE1BQXFDLEdBQUcsS0FBSyxXQUFXLElBQUksVUFBVSxzQkFBc0IsT0FBTztNQUN4SDtNQUVPLHFCQUFxQixZQUFrQjtBQUMxQyxlQUFPLEtBQUssS0FBSyxJQUEwQyxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUscUJBQXFCO01BQ3JIO01BUU8sZUFBZSxZQUFrQjtBQUNwQyxlQUFPLEtBQUssS0FBSyxNQUFxQyxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUscUJBQXFCLENBQUEsQ0FBRTtNQUNsSDtNQU9PLFdBQVcsWUFBa0I7QUFDaEMsZUFBTyxLQUFLLEtBQUssSUFBWSxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUsd0JBQXdCLENBQUEsQ0FBRTtNQUM1RjtNQU9RLHlCQUF5QixZQUFvQixjQUF1RDtBQUN4RyxjQUFNLGdCQUFnQixnQ0FBZ0MsVUFBVTtBQUNoRSxhQUFLLG9CQUFvQixVQUFVLGFBQWE7QUFDaEQsYUFBSyxZQUFZLFVBQVUsSUFBSTtBQUMvQixhQUFLLFNBQVMsVUFBVSxJQUFJLElBQUlKLGlCQUFnQixZQUFZO0FBQzVELGFBQUssb0JBQ0EsUUFBUSxhQUFhLEVBQ3JCLEtBQ0dHLEtBQUksQ0FBQyxjQUFlLFVBQVUsU0FBUyxZQUFZLE1BQVUsR0FDN0RDLEtBQUksQ0FBQyxjQUFhO0FBQ2QsY0FBSSxXQUFXO0FBQ1gsaUJBQUssVUFBVSxJQUFJLFlBQVksU0FBUzs7QUFFNUMsZUFBSyxrQkFBa0IsWUFBWSxTQUFTO1FBQ2hELENBQUMsQ0FBQyxFQUVMLFVBQVM7QUFDZCxlQUFPLEtBQUssU0FBUyxVQUFVO01BQ25DO01BT1Esa0JBQWtCLFlBQW9CLFdBQW9EO0FBQzlGLGFBQUssU0FBUyxVQUFVLEVBQUUsS0FBSyxTQUFTO01BQzVDO01BTU8sMEJBQTBCLFlBQWtCO0FBQy9DLGVBQU8sS0FBSyxLQUFLLElBQWtDLEdBQUcsS0FBSyxXQUFXLElBQUksVUFBVSxrQ0FBa0M7TUFDMUg7TUFTTyw2QkFBNkIsWUFBb0IsU0FBMkM7QUFDL0YsZUFBTyxLQUFLLEtBQUssTUFBb0MsR0FBRyxLQUFLLFdBQVcsSUFBSSxVQUFVLG9DQUFvQyxPQUFPO01BQ3JJO01BT08sZ0JBQWdCLFlBQWtCO0FBQ3JDLGVBQU8sS0FBSyxLQUFLLE1BQW9DLEdBQUcsS0FBSyxXQUFXLElBQUksVUFBVSwwQ0FBMEMsQ0FBQSxDQUFFO01BQ3RJO01BU08sNkJBQTZCLGtCQUEwQixrQkFBd0I7QUFDbEYsY0FBTSxTQUFTLElBQUksV0FBVSxFQUFHLElBQUksb0JBQW9CLGdCQUFnQjtBQUN4RSxlQUFPLEtBQUssS0FBSyxNQUFvQyxHQUFHLEtBQUssV0FBVyxJQUFJLGdCQUFnQiwyQ0FBMkMsQ0FBQSxHQUFJLEVBQUUsT0FBTSxDQUFFO01BQ3pKOzt5QkFoTFMsb0NBQWlDLHVCQUFBLG1CQUFBLEdBQUEsdUJBQUEsY0FBQSxDQUFBO01BQUE7b0VBQWpDLG9DQUFpQyxTQUFqQyxtQ0FBaUMsV0FBQSxZQURwQixPQUFNLENBQUE7Ozs7OztBQy9DaEMsU0FBUyxhQUFBQyxZQUFXLFNBQUFDLGNBQWE7QUFPakMsU0FBUyxVQUFBQyxlQUFjOztBQVB2QixJQThCYTtBQTlCYjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7O0FBd0JNLElBQU8sK0NBQVAsTUFBTyw4Q0FBNEM7TUFZekM7TUFDQTtNQVpaLGdCQUFnQjtNQUNoQixhQUFhO01BQ0o7TUFDQSxXQUFXO01BRXBCLHdCQUF3QjtNQUd4QixTQUFTQTtNQUVULFlBQ1ksaUJBQ0EsY0FBMEI7QUFEMUIsYUFBQSxrQkFBQTtBQUNBLGFBQUEsZUFBQTtNQUNUO01BS0gsb0JBQWlCO0FBQ2IsYUFBSyx3QkFBd0I7QUFDN0IsYUFBSyxnQkFBZ0IsV0FBVyxLQUFLLFNBQVMsRUFBRyxFQUFFLFVBQVU7VUFDekQsTUFBTSxDQUFDLHdCQUErQjtBQUNsQyxpQkFBSyx3QkFBd0I7QUFDN0IsaUJBQUssYUFBYSxRQUFRLHVEQUF1RCxFQUFFLFFBQVEsb0JBQW1CLENBQUU7VUFDcEg7VUFDQSxPQUFPLENBQUMsVUFBNEI7QUFDaEMsaUJBQUssd0JBQXdCO0FBQzdCLGlCQUFLLGFBQWEsTUFBTSxtREFBbUQsRUFBRSxTQUFTLE1BQU0sUUFBTyxDQUFFO1VBQ3pHO1NBQ0g7TUFDTDs7eUJBL0JTLCtDQUE0QyxnQ0FBQSxpQ0FBQSxHQUFBLGdDQUFBLFlBQUEsQ0FBQTtNQUFBO2lFQUE1QywrQ0FBNEMsV0FBQSxDQUFBLENBQUEsNkNBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsVUFBQSxXQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxNQUFBLHNCQUFBLEdBQUEsUUFBQSxHQUFBLFlBQUEsV0FBQSxhQUFBLFdBQUEsUUFBQSxTQUFBLGlCQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxzREFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQWZqRCxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxjQUFBLENBQUE7QUFVSSxVQUFBLHlCQUFBLFdBQUEsU0FBQSxzRkFBQTtBQUFBLG1CQUFXLElBQUEsa0JBQUE7VUFBbUIsQ0FBQTtBQUVsQyxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLEdBQUEsUUFBQTs7O0FBVlEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxZQUFBLElBQUEsWUFBQSxJQUFBLHFCQUFBLEVBQThDLFdBQUEsSUFBQSxXQUFBLEtBQUEsRUFBQSxhQUFBLElBQUEscUJBQUEsRUFBQSxXQUFBLGtEQUFBLEVBQUEsUUFBQSxJQUFBLE1BQUEsRUFBQSxTQUFBLDJDQUFBLEVBQUEsaUJBQUEsSUFBQSxjQUFBLG9CQUFBOzs7OztxRkFZN0MsOENBQTRDLEVBQUEsV0FBQSwrQ0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUM5QnpELFNBQVMsZ0JBQWdCOztBQUF6QixJQStCYTtBQS9CYjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSUE7QUFDQTtBQUNBO0FBb0JNLElBQU8sMENBQVAsTUFBTyx5Q0FBdUM7O3lCQUF2QywwQ0FBdUM7TUFBQTtnRUFBdkMseUNBQXVDLENBQUE7b0VBakJ0QyxxQkFBcUIsOEJBQThCLG1CQUFtQixFQUFBLENBQUE7Ozs7OztBQ2RwRixTQUFTLFlBQUFDLGlCQUFnQjs7QUFBekIsSUFZYTtBQVpiOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFPTSxJQUFPLCtCQUFQLE1BQU8sOEJBQTRCOzt5QkFBNUIsK0JBQTRCO01BQUE7Z0VBQTVCLDhCQUE0QixDQUFBO29FQUozQixxQkFBcUIsdUNBQXVDLEVBQUEsQ0FBQTs7OzsiLCJuYW1lcyI6WyJCdWlsZFJ1blN0YXRlIiwiQ29tcG9uZW50IiwidGFwIiwiTmdiTW9kYWwiLCJmYVJlZG8iLCJDb21wb25lbnQiLCJJbnB1dCIsInRhcCIsImZhUmVkbyIsIkluamVjdGFibGUiLCJCZWhhdmlvclN1YmplY3QiLCJvZiIsImNhdGNoRXJyb3IiLCJtYXAiLCJ0YXAiLCJDb21wb25lbnQiLCJJbnB1dCIsImZhUmVkbyIsIk5nTW9kdWxlIl19