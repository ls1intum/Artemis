import {
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/core/user/user.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var UserService;
var init_user_service = __esm({
  "src/main/webapp/app/core/user/user.service.ts"() {
    UserService = class _UserService {
      http;
      resourceUrl = "api/users";
      constructor(http) {
        this.http = http;
      }
      syncLdap(userId) {
        return this.http.put(`${this.resourceUrl}/${userId}/sync-ldap`, { observe: "response" });
      }
      find(login) {
        return this.http.get(`${this.resourceUrl}/${login}`);
      }
      search(loginOrName) {
        return this.http.get(`${this.resourceUrl}/search?loginOrName=${loginOrName}`, { observe: "response" });
      }
      updateLastNotificationRead() {
        return this.http.put(`${this.resourceUrl}/notification-date`, null, { observe: "response" });
      }
      updateNotificationVisibility(showAllNotifications) {
        return this.http.put(`${this.resourceUrl}/notification-visibility`, showAllNotifications, { observe: "response" });
      }
      initializeLTIUser() {
        return this.http.put(`${this.resourceUrl}/initialize`, null, { observe: "response" });
      }
      acceptIris() {
        return this.http.put(`${this.resourceUrl}/accept-iris`, { observe: "response" });
      }
      getIrisAcceptedAt() {
        return this.http.get(`${this.resourceUrl}/accept-iris`);
      }
      static \u0275fac = function UserService_Factory(t) {
        return new (t || _UserService)(i0.\u0275\u0275inject(i1.HttpClient));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _UserService, factory: _UserService.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  UserService,
  init_user_service
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvY29yZS91c2VyL3VzZXIuc2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZGF5anMgZnJvbSAnZGF5anMvZXNtJztcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IFVzZXIgfSBmcm9tICdhcHAvY29yZS91c2VyL3VzZXIubW9kZWwnO1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIFVzZXJTZXJ2aWNlIHtcbiAgICBwdWJsaWMgcmVzb3VyY2VVcmwgPSAnYXBpL3VzZXJzJztcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cENsaWVudCkge31cblxuICAgIC8qKlxuICAgICAqIENhbGwgdGhlIExEQVAgc2VydmVyIHRvIHVwZGF0ZSB0aGUgaW5mbyBvZiBhIHVzZXIgb24gdGhlIHNlcnZlci5cbiAgICAgKiBAcGFyYW0gdXNlcklkIFRoZSBpZCBvZiB0aGUgdXNlciB0byBiZSB1cGRhdGVkIGZyb20gdGhlIExEQVAgc2VydmVyLlxuICAgICAqIEByZXR1cm4gT2JzZXJ2YWJsZTxVc2VyPiB3aXRoIHRoZSB1cGRhdGVkIHVzZXIgYXMgYm9keS5cbiAgICAgKi9cbiAgICBzeW5jTGRhcCh1c2VySWQ6IG51bWJlcik6IE9ic2VydmFibGU8VXNlcj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnB1dDxVc2VyPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke3VzZXJJZH0vc3luYy1sZGFwYCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEZpbmQgYSB1c2VyIG9uIHRoZSBzZXJ2ZXIuXG4gICAgICogQHBhcmFtIGxvZ2luIFRoZSBsb2dpbiBvZiB0aGUgdXNlciB0byBmaW5kLlxuICAgICAqIEByZXR1cm4gT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VXNlcj4+IHdpdGggdGhlIGZvdW5kIHVzZXIgYXMgYm9keS5cbiAgICAgKi9cbiAgICBmaW5kKGxvZ2luOiBzdHJpbmcpOiBPYnNlcnZhYmxlPFVzZXI+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8VXNlcj4oYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtsb2dpbn1gKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTZWFyY2ggZm9yIGEgdXNlciBvbiB0aGUgc2VydmVyIGJ5IGxvZ2luIG9yIG5hbWUuXG4gICAgICogQHBhcmFtIGxvZ2luT3JOYW1lIFRoZSBsb2dpbiBvciBuYW1lIHRvIHNlYXJjaCBmb3IuXG4gICAgICogQHJldHVybiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxVc2VyW10+PiB3aXRoIHRoZSBsaXN0IG9mIGZvdW5kIHVzZXJzIGFzIGJvZHkuXG4gICAgICovXG4gICAgc2VhcmNoKGxvZ2luT3JOYW1lOiBzdHJpbmcpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxVc2VyW10+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFVzZXJbXT4oYCR7dGhpcy5yZXNvdXJjZVVybH0vc2VhcmNoP2xvZ2luT3JOYW1lPSR7bG9naW5Pck5hbWV9YCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZSB0aGUgdXNlciBub3RpZmljYXRpb24gZGF0ZS5cbiAgICAgKi9cbiAgICB1cGRhdGVMYXN0Tm90aWZpY2F0aW9uUmVhZCgpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTx2b2lkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnB1dDx2b2lkPihgJHt0aGlzLnJlc291cmNlVXJsfS9ub3RpZmljYXRpb24tZGF0ZWAsIG51bGwsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVcGRhdGVzIHRoZSBwcm9wZXJ0eSB0aGF0IGRlY2lkZXMgd2hhdCBub3RpZmljYXRpb25zIHNob3VsZCBiZSBkaXNwbGF5ZWQgb3IgaGlkZGVuIGluIHRoZSBub3RpZmljYXRpb24gc2lkZWJhciBiYXNlZCBvbiBub3RpZmljYXRpb24gZGF0ZS5cbiAgICAgKiBJZiB0aGUgdmFsdWUgaXMgc2V0IHRvIG51bGwgLT4gc2hvdyBhbGwgbm90aWZpY2F0aW9uc1xuICAgICAqIChOb3QgdG8gYmUgY29uZnVzZWQgd2l0aCB0aGUgbm90aWZpY2F0aW9uIHNldHRpbmdzLiBUaGlzIGZpbHRlciBpcyBvbmx5IGJhc2VkIG9uIHRoZSBkYXRlIGEgbm90aWZpY2F0aW9uIHdhcyBjcmVhdGVkKVxuICAgICAqL1xuICAgIHVwZGF0ZU5vdGlmaWNhdGlvblZpc2liaWxpdHkoc2hvd0FsbE5vdGlmaWNhdGlvbnM6IGJvb2xlYW4pOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTx2b2lkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnB1dDx2b2lkPihgJHt0aGlzLnJlc291cmNlVXJsfS9ub3RpZmljYXRpb24tdmlzaWJpbGl0eWAsIHNob3dBbGxOb3RpZmljYXRpb25zLCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSW5pdGlhbGl6ZXMgYW4gTFRJIHVzZXIgYW5kIHJldHVybnMgdGhlIG5ld2x5IGdlbmVyYXRlZCBwYXNzd29yZC5cbiAgICAgKi9cbiAgICBpbml0aWFsaXplTFRJVXNlcigpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTx7IHBhc3N3b3JkOiBzdHJpbmcgfT4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8eyBwYXNzd29yZDogc3RyaW5nIH0+KGAke3RoaXMucmVzb3VyY2VVcmx9L2luaXRpYWxpemVgLCBudWxsLCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQWNjZXB0IElyaXMgcG9saWN5LlxuICAgICAqL1xuICAgIGFjY2VwdElyaXMoKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8dm9pZD4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8SHR0cFJlc3BvbnNlPHZvaWQ+PihgJHt0aGlzLnJlc291cmNlVXJsfS9hY2NlcHQtaXJpc2AsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgdGhlIHRpbWVzdGFtcCB0aGF0IElyaXMgaXMgYWNjZXB0ZWQuXG4gICAgICogQHJldHVybiBPYnNlcnZhYmxlPGRheWpzLkRheWpzPiB3aXRoIHRoZSBhY2NlcHRlZCBkYXRlLlxuICAgICAqL1xuICAgIGdldElyaXNBY2NlcHRlZEF0KCk6IE9ic2VydmFibGU8ZGF5anMuRGF5anMgfCBudWxsPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PGRheWpzLkRheWpzIHwgbnVsbD4oYCR7dGhpcy5yZXNvdXJjZVVybH0vYWNjZXB0LWlyaXNgKTtcbiAgICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7O0FBQ0EsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBZ0M7OztBQUR6QyxJQU1hO0FBTmI7O0FBTU0sSUFBTyxjQUFQLE1BQU8sYUFBVztNQUdBO01BRmIsY0FBYztNQUVyQixZQUFvQixNQUFnQjtBQUFoQixhQUFBLE9BQUE7TUFBbUI7TUFPdkMsU0FBUyxRQUFjO0FBQ25CLGVBQU8sS0FBSyxLQUFLLElBQVUsR0FBRyxLQUFLLFdBQVcsSUFBSSxNQUFNLGNBQWMsRUFBRSxTQUFTLFdBQVUsQ0FBRTtNQUNqRztNQU9BLEtBQUssT0FBYTtBQUNkLGVBQU8sS0FBSyxLQUFLLElBQVUsR0FBRyxLQUFLLFdBQVcsSUFBSSxLQUFLLEVBQUU7TUFDN0Q7TUFPQSxPQUFPLGFBQW1CO0FBQ3RCLGVBQU8sS0FBSyxLQUFLLElBQVksR0FBRyxLQUFLLFdBQVcsdUJBQXVCLFdBQVcsSUFBSSxFQUFFLFNBQVMsV0FBVSxDQUFFO01BQ2pIO01BS0EsNkJBQTBCO0FBQ3RCLGVBQU8sS0FBSyxLQUFLLElBQVUsR0FBRyxLQUFLLFdBQVcsc0JBQXNCLE1BQU0sRUFBRSxTQUFTLFdBQVUsQ0FBRTtNQUNyRztNQU9BLDZCQUE2QixzQkFBNkI7QUFDdEQsZUFBTyxLQUFLLEtBQUssSUFBVSxHQUFHLEtBQUssV0FBVyw0QkFBNEIsc0JBQXNCLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDM0g7TUFLQSxvQkFBaUI7QUFDYixlQUFPLEtBQUssS0FBSyxJQUEwQixHQUFHLEtBQUssV0FBVyxlQUFlLE1BQU0sRUFBRSxTQUFTLFdBQVUsQ0FBRTtNQUM5RztNQUtBLGFBQVU7QUFDTixlQUFPLEtBQUssS0FBSyxJQUF3QixHQUFHLEtBQUssV0FBVyxnQkFBZ0IsRUFBRSxTQUFTLFdBQVUsQ0FBRTtNQUN2RztNQU1BLG9CQUFpQjtBQUNiLGVBQU8sS0FBSyxLQUFLLElBQXdCLEdBQUcsS0FBSyxXQUFXLGNBQWM7TUFDOUU7O3lCQXBFUyxjQUFXLHNCQUFBLGFBQUEsQ0FBQTtNQUFBO21FQUFYLGNBQVcsU0FBWCxhQUFXLFdBQUEsWUFERSxPQUFNLENBQUE7Ozs7IiwibmFtZXMiOltdfQ==