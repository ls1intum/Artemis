import {
  AlertType,
  __esm,
  init_alert_service
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/util/global.utils.ts
var escapeStringForUseInRegex, getStringSegmentPositions, matchRegexWithLineNumbers, onError, notUndefined;
var init_global_utils = __esm({
  "src/main/webapp/app/shared/util/global.utils.ts"() {
    init_alert_service();
    escapeStringForUseInRegex = (text) => {
      return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    };
    getStringSegmentPositions = (stringToSegment, delimiter, result = []) => {
      if (stringToSegment === "") {
        return [...result, { start: 0, end: 0, word: "" }];
      }
      const nextComma = stringToSegment.indexOf(delimiter);
      const lastElement = result.last();
      if (nextComma === -1) {
        return [
          ...result,
          {
            start: lastElement ? lastElement.end + delimiter.length + 1 : 0,
            end: (lastElement && lastElement.end + delimiter.length + 1 || 0) + stringToSegment.length - 1,
            word: stringToSegment
          }
        ];
      }
      const nextWord = stringToSegment.slice(0, nextComma);
      const newResult = [
        ...result,
        {
          start: lastElement ? lastElement.end + delimiter.length + 1 : 0,
          end: (lastElement && lastElement.end + delimiter.length + 1 || 0) + nextComma - 1,
          word: nextWord
        }
      ];
      const restString = stringToSegment.slice(nextComma + delimiter.length);
      return getStringSegmentPositions(restString, delimiter, newResult);
    };
    matchRegexWithLineNumbers = (multiLineText, regex) => {
      if (!regex.flags.includes("g")) {
        throw new Error("Regex must contain global flag, otherwise this function will run out of memory.");
      }
      const result = [];
      let match = regex.exec(multiLineText);
      while (match) {
        const lineNumber = multiLineText.substring(0, match.index + match[1].length + 1).split("\n").length - 1;
        result.push([lineNumber, match[1]]);
        match = regex.exec(multiLineText);
      }
      return result;
    };
    onError = (alertService, error) => {
      switch (error.status) {
        case 400:
          alertService.error("error.http.400");
          break;
        case 403:
          alertService.error("error.http.403");
          break;
        case 404:
          alertService.error("error.http.404");
          break;
        case 405:
          alertService.error("error.http.405");
          break;
        case 500:
          break;
        default:
          alertService.addAlert({
            type: AlertType.DANGER,
            message: error.message,
            disableTranslation: true
          });
          break;
      }
    };
    notUndefined = (anyValue) => anyValue !== void 0;
  }
});

export {
  escapeStringForUseInRegex,
  getStringSegmentPositions,
  matchRegexWithLineNumbers,
  onError,
  notUndefined,
  init_global_utils
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3V0aWwvZ2xvYmFsLnV0aWxzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEh0dHBFcnJvclJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgQWxlcnRTZXJ2aWNlLCBBbGVydFR5cGUgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuXG4vKipcbiAqIFByZXBhcmVzIGEgc3RyaW5nIGZvciBpbnNlcnRpb24gaW50byBhIHJlZ2V4LlxuICogRXhhbXBsZTogW3Rlc3RdLipbL3Rlc3RdIC0+IFxcW3Rlc3RcXF0uKlxcW1xcL3Rlc3RcXF1cbiAqIEBwYXJhbSB0ZXh0XG4gKi9cbmV4cG9ydCBjb25zdCBlc2NhcGVTdHJpbmdGb3JVc2VJblJlZ2V4ID0gKHRleHQ6IHN0cmluZykgPT4ge1xuICAgIHJldHVybiB0ZXh0LnJlcGxhY2UoL1suKis/XiR7fSgpfFtcXF1cXFxcXS9nLCAnXFxcXCQmJyk7XG59O1xuXG50eXBlIFN0cmluZ1Bvc2l0aW9ucyA9IEFycmF5PHsgc3RhcnQ6IG51bWJlcjsgZW5kOiBudW1iZXI7IHdvcmQ6IHN0cmluZyB9Pjtcbi8qKlxuICogSW5zZXJ0IGEgc3RyaW5nIHRoYXQgaXMgc2VnbWVudGVkIGJ5IGEgc3BlY2lmaWVkIGRlbGltaXRlciwgYW5kIGEgZGljdGlvbmFyeSB0aGF0IHByb3ZpZGVzIHRoZVxuICogc3RhcnQgYW5kIGVuZCBwb3NpdGlvbnMgb2YgdGhlIHNlZ21lbnRzLlxuICogRS5nLjogXCJ3b3JkMSwgd29yZDJcIiAtPiBbe3N0YXJ0OiAwLCBlbmQ6IDQsIHdvcmQ6IFwid29yZDFcIn0sIHtzdGFydDogNiwgZW5kOiAxMCwgd29yZDogXCJ3b3JkMlwifV1cbiAqIEBwYXJhbSBzdHJpbmdUb1NlZ21lbnQgc3RyaW5nIHdoaWNoIHNob3VsZCBiZSBwcm92aWRlZCBzZWdtZW50IGluZm9ybWF0aW9uIGFib3V0XG4gKiBAcGFyYW0gZGVsaW1pdGVyIGRlbGltaXRlciBieSB3aGljaCB0aGUgc3RyaW5nIGlzIHNlZ21lbnRlZCAoZS5nLiBcIiwgXCIpXG4gKiBAcGFyYW0gcmVzdWx0IHJldHVybnMgYSBsaXN0IG9mIFN0cmluZ1Bvc2l0aW9uc1xuICovXG5leHBvcnQgY29uc3QgZ2V0U3RyaW5nU2VnbWVudFBvc2l0aW9ucyA9IChzdHJpbmdUb1NlZ21lbnQ6IHN0cmluZywgZGVsaW1pdGVyOiBzdHJpbmcsIHJlc3VsdDogU3RyaW5nUG9zaXRpb25zID0gW10pOiBTdHJpbmdQb3NpdGlvbnMgPT4ge1xuICAgIGlmIChzdHJpbmdUb1NlZ21lbnQgPT09ICcnKSB7XG4gICAgICAgIHJldHVybiBbLi4ucmVzdWx0LCB7IHN0YXJ0OiAwLCBlbmQ6IDAsIHdvcmQ6ICcnIH1dO1xuICAgIH1cbiAgICBjb25zdCBuZXh0Q29tbWEgPSBzdHJpbmdUb1NlZ21lbnQuaW5kZXhPZihkZWxpbWl0ZXIpO1xuICAgIGNvbnN0IGxhc3RFbGVtZW50ID0gcmVzdWx0Lmxhc3QoKTtcbiAgICAvLyBFbmQgY29uZGl0aW9uOiB0aGUgc3RyaW5nIGRvZXMgbm90IGhhdmUgYW55IG1vcmUgc2VnbWVudHMuXG4gICAgaWYgKG5leHRDb21tYSA9PT0gLTEpIHtcbiAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgIC4uLnJlc3VsdCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBzdGFydDogbGFzdEVsZW1lbnQgPyBsYXN0RWxlbWVudC5lbmQgKyBkZWxpbWl0ZXIubGVuZ3RoICsgMSA6IDAsXG4gICAgICAgICAgICAgICAgZW5kOiAoKGxhc3RFbGVtZW50ICYmIGxhc3RFbGVtZW50LmVuZCArIGRlbGltaXRlci5sZW5ndGggKyAxKSB8fCAwKSArIHN0cmluZ1RvU2VnbWVudC5sZW5ndGggLSAxLFxuICAgICAgICAgICAgICAgIHdvcmQ6IHN0cmluZ1RvU2VnbWVudCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF07XG4gICAgfVxuICAgIGNvbnN0IG5leHRXb3JkID0gc3RyaW5nVG9TZWdtZW50LnNsaWNlKDAsIG5leHRDb21tYSk7XG4gICAgY29uc3QgbmV3UmVzdWx0ID0gW1xuICAgICAgICAuLi5yZXN1bHQsXG4gICAgICAgIHtcbiAgICAgICAgICAgIHN0YXJ0OiBsYXN0RWxlbWVudCA/IGxhc3RFbGVtZW50LmVuZCArIGRlbGltaXRlci5sZW5ndGggKyAxIDogMCxcbiAgICAgICAgICAgIGVuZDogKChsYXN0RWxlbWVudCAmJiBsYXN0RWxlbWVudC5lbmQgKyBkZWxpbWl0ZXIubGVuZ3RoICsgMSkgfHwgMCkgKyBuZXh0Q29tbWEgLSAxLFxuICAgICAgICAgICAgd29yZDogbmV4dFdvcmQsXG4gICAgICAgIH0sXG4gICAgXTtcbiAgICBjb25zdCByZXN0U3RyaW5nID0gc3RyaW5nVG9TZWdtZW50LnNsaWNlKG5leHRDb21tYSArIGRlbGltaXRlci5sZW5ndGgpO1xuICAgIHJldHVybiBnZXRTdHJpbmdTZWdtZW50UG9zaXRpb25zKHJlc3RTdHJpbmcsIGRlbGltaXRlciwgbmV3UmVzdWx0KTtcbn07XG5cbmV4cG9ydCB0eXBlIFJlZ0V4cExpbmVOdW1iZXJNYXRjaEFycmF5ID0gQXJyYXk8W251bWJlciwgc3RyaW5nXT47XG4vKipcbiAqIEV4ZWN1dGVzIGEgcmVnZXggb24gYSBtdWx0aSBsaW5lIHRleHQgKFwidGV4dCBcXG4gbW9yZSB0ZXh0XCIpIGFuZCByZXR1cm5zIHRoZSBbbGluZU51bWJlciBvZiB0aGUgbWF0Y2gsIG1hdGNoZWQgb2JqZWN0XSBpbiBhIHR1cGxlLlxuICogVGhlIGdpdmVuIHJlZ2V4IG11c3QgaGF2ZSB0aGUgZ2xvYmFsIGZsYWcsIG90aGVyd2lzZSB0aGUgbXVsdGlsaW5lIG1hdGNoIHdpbGwgY2F1c2UgYW4gb3V0IG9mIG1lbW9yeSBleGNlcHRpb24uXG4gKlxuICogQHBhcmFtIG11bHRpTGluZVRleHQgaW4gd2hpY2ggdG8gc2VhcmNoIGZvciBtYXRjaGVzIG9mIHRoZSByZWdleC5cbiAqIEBwYXJhbSByZWdleCBSZWdFeHAgb2JqZWN0LlxuICogQHJldHVybiB0aGUgbWF0Y2hlcyBmb3VuZCBpbiB0aGUgbXVsdGlsaW5lIHN0cmluZy5cbiAqIEB0aHJvd3MgRXJyb3IgaWYgYSByZWdleCBpcyBwcm92aWRlZCB3aXRob3V0IGEgZ2xvYmFsIGZsYWcuXG4gKi9cbmV4cG9ydCBjb25zdCBtYXRjaFJlZ2V4V2l0aExpbmVOdW1iZXJzID0gKG11bHRpTGluZVRleHQ6IHN0cmluZywgcmVnZXg6IFJlZ0V4cCk6IFJlZ0V4cExpbmVOdW1iZXJNYXRjaEFycmF5ID0+IHtcbiAgICBpZiAoIXJlZ2V4LmZsYWdzLmluY2x1ZGVzKCdnJykpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdSZWdleCBtdXN0IGNvbnRhaW4gZ2xvYmFsIGZsYWcsIG90aGVyd2lzZSB0aGlzIGZ1bmN0aW9uIHdpbGwgcnVuIG91dCBvZiBtZW1vcnkuJyk7XG4gICAgfVxuICAgIGNvbnN0IHJlc3VsdDogUmVnRXhwTGluZU51bWJlck1hdGNoQXJyYXkgPSBbXTtcbiAgICBsZXQgbWF0Y2ggPSByZWdleC5leGVjKG11bHRpTGluZVRleHQpO1xuICAgIHdoaWxlIChtYXRjaCkge1xuICAgICAgICBjb25zdCBsaW5lTnVtYmVyID0gbXVsdGlMaW5lVGV4dC5zdWJzdHJpbmcoMCwgbWF0Y2guaW5kZXggKyBtYXRjaFsxXS5sZW5ndGggKyAxKS5zcGxpdCgnXFxuJykubGVuZ3RoIC0gMTtcbiAgICAgICAgcmVzdWx0LnB1c2goW2xpbmVOdW1iZXIsIG1hdGNoWzFdXSk7XG4gICAgICAgIG1hdGNoID0gcmVnZXguZXhlYyhtdWx0aUxpbmVUZXh0KTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbn07XG5cbi8qKlxuICogVXNlIGFsZXJ0IHNlcnZpY2UgdG8gc2hvdyB0aGUgZXJyb3IgbWVzc2FnZSBmcm9tIHRoZSBlcnJvciByZXNwb25zZVxuICogQHBhcmFtIGFsZXJ0U2VydmljZSB0aGUgc2VydmljZSB1c2VkIHRvIHNob3cgdGhlIGV4Y2VwdGlvbiBtZXNzYWdlcyB0byB0aGUgdXNlclxuICogQHBhcmFtIGVycm9yIHRoZSBlcnJvciByZXNwb25zZSB0aGF0J3Mgc3RhdHVzIGlzIHVzZWQgdG8gZGV0ZXJtaW5lIHRoZSBlcnJvciBtZXNzYWdlXG4gKi9cbmV4cG9ydCBjb25zdCBvbkVycm9yID0gKGFsZXJ0U2VydmljZTogQWxlcnRTZXJ2aWNlLCBlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpID0+IHtcbiAgICBzd2l0Y2ggKGVycm9yLnN0YXR1cykge1xuICAgICAgICBjYXNlIDQwMDpcbiAgICAgICAgICAgIGFsZXJ0U2VydmljZS5lcnJvcignZXJyb3IuaHR0cC40MDAnKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIDQwMzpcbiAgICAgICAgICAgIGFsZXJ0U2VydmljZS5lcnJvcignZXJyb3IuaHR0cC40MDMnKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIDQwNDpcbiAgICAgICAgICAgIGFsZXJ0U2VydmljZS5lcnJvcignZXJyb3IuaHR0cC40MDQnKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIDQwNTpcbiAgICAgICAgICAgIGFsZXJ0U2VydmljZS5lcnJvcignZXJyb3IuaHR0cC40MDUnKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIDUwMDpcbiAgICAgICAgICAgIC8vIFJlbW92ZWQgdG8gYXZvaWQgYWxlcnRzIGFib3V0IGludGVybmFsIGVycm9ycyBhcyB0aGUgdXNlciBjYW4ndCBkbyBhbnl0aGluZyBhYm91dCBpdFxuICAgICAgICAgICAgLy8gYW5kIHRoZSBhbGVydCBkb2VzIG5vdCBwcm92aWRlIGFueSBvdGhlciB2YWx1ZVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICBhbGVydFNlcnZpY2UuYWRkQWxlcnQoe1xuICAgICAgICAgICAgICAgIHR5cGU6IEFsZXJ0VHlwZS5EQU5HRVIsXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogZXJyb3IubWVzc2FnZSxcbiAgICAgICAgICAgICAgICBkaXNhYmxlVHJhbnNsYXRpb246IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbn07XG5cbi8qKlxuICogQ2hlY2tzIGlmIHByb3ZpZGVkIHZhbHVlIGlzIHVuZGVmaW5lZC4gQ2FuIGJlIHVzZWQgdG8gZmlsdGVyIGFuIGFycmF5OlxuICogW10uZmlsdGVyKG5vdFVuZGVmaW5lZClcbiAqXG4gKiBAcGFyYW0gYW55VmFsdWVcbiAqIEByZXR1cm4gYm9vbGVhblxuICovXG5leHBvcnQgY29uc3Qgbm90VW5kZWZpbmVkID0gKGFueVZhbHVlOiBhbnkpOiBib29sZWFuID0+IGFueVZhbHVlICE9PSB1bmRlZmluZWQ7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFDQSxJQU9hLDJCQWFBLDJCQXdDQSwyQkFtQkEsU0FtQ0E7QUFsSGI7OztBQU9PLElBQU0sNEJBQTRCLENBQUMsU0FBZ0I7QUFDdEQsYUFBTyxLQUFLLFFBQVEsdUJBQXVCLE1BQU07SUFDckQ7QUFXTyxJQUFNLDRCQUE0QixDQUFDLGlCQUF5QixXQUFtQixTQUEwQixDQUFBLE1BQXVCO0FBQ25JLFVBQUksb0JBQW9CLElBQUk7QUFDeEIsZUFBTyxDQUFDLEdBQUcsUUFBUSxFQUFFLE9BQU8sR0FBRyxLQUFLLEdBQUcsTUFBTSxHQUFFLENBQUU7O0FBRXJELFlBQU0sWUFBWSxnQkFBZ0IsUUFBUSxTQUFTO0FBQ25ELFlBQU0sY0FBYyxPQUFPLEtBQUk7QUFFL0IsVUFBSSxjQUFjLElBQUk7QUFDbEIsZUFBTztVQUNILEdBQUc7VUFDSDtZQUNJLE9BQU8sY0FBYyxZQUFZLE1BQU0sVUFBVSxTQUFTLElBQUk7WUFDOUQsTUFBTyxlQUFlLFlBQVksTUFBTSxVQUFVLFNBQVMsS0FBTSxLQUFLLGdCQUFnQixTQUFTO1lBQy9GLE1BQU07Ozs7QUFJbEIsWUFBTSxXQUFXLGdCQUFnQixNQUFNLEdBQUcsU0FBUztBQUNuRCxZQUFNLFlBQVk7UUFDZCxHQUFHO1FBQ0g7VUFDSSxPQUFPLGNBQWMsWUFBWSxNQUFNLFVBQVUsU0FBUyxJQUFJO1VBQzlELE1BQU8sZUFBZSxZQUFZLE1BQU0sVUFBVSxTQUFTLEtBQU0sS0FBSyxZQUFZO1VBQ2xGLE1BQU07OztBQUdkLFlBQU0sYUFBYSxnQkFBZ0IsTUFBTSxZQUFZLFVBQVUsTUFBTTtBQUNyRSxhQUFPLDBCQUEwQixZQUFZLFdBQVcsU0FBUztJQUNyRTtBQVlPLElBQU0sNEJBQTRCLENBQUMsZUFBdUIsVUFBNkM7QUFDMUcsVUFBSSxDQUFDLE1BQU0sTUFBTSxTQUFTLEdBQUcsR0FBRztBQUM1QixjQUFNLElBQUksTUFBTSxpRkFBaUY7O0FBRXJHLFlBQU0sU0FBcUMsQ0FBQTtBQUMzQyxVQUFJLFFBQVEsTUFBTSxLQUFLLGFBQWE7QUFDcEMsYUFBTyxPQUFPO0FBQ1YsY0FBTSxhQUFhLGNBQWMsVUFBVSxHQUFHLE1BQU0sUUFBUSxNQUFNLENBQUMsRUFBRSxTQUFTLENBQUMsRUFBRSxNQUFNLElBQUksRUFBRSxTQUFTO0FBQ3RHLGVBQU8sS0FBSyxDQUFDLFlBQVksTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNsQyxnQkFBUSxNQUFNLEtBQUssYUFBYTs7QUFFcEMsYUFBTztJQUNYO0FBT08sSUFBTSxVQUFVLENBQUMsY0FBNEIsVUFBNEI7QUFDNUUsY0FBUSxNQUFNLFFBQVE7UUFDbEIsS0FBSztBQUNELHVCQUFhLE1BQU0sZ0JBQWdCO0FBQ25DO1FBQ0osS0FBSztBQUNELHVCQUFhLE1BQU0sZ0JBQWdCO0FBQ25DO1FBQ0osS0FBSztBQUNELHVCQUFhLE1BQU0sZ0JBQWdCO0FBQ25DO1FBQ0osS0FBSztBQUNELHVCQUFhLE1BQU0sZ0JBQWdCO0FBQ25DO1FBQ0osS0FBSztBQUdEO1FBQ0o7QUFDSSx1QkFBYSxTQUFTO1lBQ2xCLE1BQU0sVUFBVTtZQUNoQixTQUFTLE1BQU07WUFDZixvQkFBb0I7V0FDdkI7QUFDRDs7SUFFWjtBQVNPLElBQU0sZUFBZSxDQUFDLGFBQTJCLGFBQWE7OzsiLCJuYW1lcyI6W119