import {
  BuildLogService,
  downloadFile,
  init_build_log_service,
  init_download_util
} from "/chunk-ORYTP7RT.js";
import {
  SortService,
  init_sort_service
} from "/chunk-H46RESQY.js";
import {
  ExerciseService,
  JhiWebsocketService,
  __esm,
  __spreadProps,
  __spreadValues,
  convertDateFromClient,
  convertDateFromServer,
  createRequestOption,
  init_date_utils,
  init_exercise_service,
  init_request_util,
  init_websocket_service
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/programming/manage/services/programming-exercise.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient, HttpParams } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { omit as _omit } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var ProgrammingExerciseService;
var init_programming_exercise_service = __esm({
  "src/main/webapp/app/exercises/programming/manage/services/programming-exercise.service.ts"() {
    init_request_util();
    init_exercise_service();
    init_date_utils();
    init_sort_service();
    init_exercise_service();
    init_sort_service();
    ProgrammingExerciseService = class _ProgrammingExerciseService {
      http;
      exerciseService;
      sortService;
      resourceUrl = "api/programming-exercises";
      constructor(http, exerciseService, sortService) {
        this.http = http;
        this.exerciseService = exerciseService;
        this.sortService = sortService;
      }
      automaticSetup(programmingExercise) {
        let copy = this.convertDataFromClient(programmingExercise);
        copy = ExerciseService.setBonusPointsConstrainedByIncludedInOverallScore(copy);
        copy.categories = ExerciseService.stringifyExerciseCategories(copy);
        return this.http.post(this.resourceUrl + "/setup", copy, { observe: "response" }).pipe(map((res) => this.processProgrammingExerciseEntityResponse(res)));
      }
      generateStructureOracle(exerciseId) {
        return this.http.put(`${this.resourceUrl}/${exerciseId}/generate-tests`, { responseType: "text" });
      }
      reset(exerciseId, options) {
        return this.http.put(`${this.resourceUrl}/${exerciseId}/reset`, options, { responseType: "text" });
      }
      checkPlagiarism(exerciseId, options) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/check-plagiarism`, {
          observe: "response",
          params: __spreadValues({}, options?.toParams())
        }).pipe(map((response) => response.body));
      }
      checkPlagiarismJPlagReport(exerciseId, options) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/check-plagiarism-jplag-report`, {
          observe: "response",
          responseType: "blob",
          params: __spreadValues({}, options?.toParams())
        });
      }
      getLatestPlagiarismResult(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/plagiarism-result`, {
          observe: "response"
        }).pipe(map((response) => response.body));
      }
      combineTemplateRepositoryCommits(exerciseId) {
        return this.http.put(`${this.resourceUrl}/${exerciseId}/combine-template-commits`, { responseType: "text" });
      }
      importExercise(adaptedSourceProgrammingExercise, recreateBuildPlans, updateTemplate) {
        const options = createRequestOption({ recreateBuildPlans, updateTemplate });
        const exercise = ExerciseService.setBonusPointsConstrainedByIncludedInOverallScore(adaptedSourceProgrammingExercise);
        exercise.categories = ExerciseService.stringifyExerciseCategories(exercise);
        return this.http.post(`${this.resourceUrl}/import/${adaptedSourceProgrammingExercise.id}`, exercise, {
          params: options,
          observe: "response"
        }).pipe(map((res) => this.processProgrammingExerciseEntityResponse(res)));
      }
      update(programmingExercise, req) {
        const options = createRequestOption(req);
        let copy = this.convertDataFromClient(programmingExercise);
        copy = ExerciseService.setBonusPointsConstrainedByIncludedInOverallScore(copy);
        copy.categories = ExerciseService.stringifyExerciseCategories(copy);
        return this.http.put(this.resourceUrl, copy, { params: options, observe: "response" }).pipe(map((res) => this.processProgrammingExerciseEntityResponse(res)));
      }
      updateTimeline(programmingExercise, req) {
        const options = createRequestOption(req);
        const copy = this.convertDataFromClient(programmingExercise);
        return this.http.put(`${this.resourceUrl}/timeline`, copy, { params: options, observe: "response" }).pipe(map((res) => this.processProgrammingExerciseEntityResponse(res)));
      }
      updateProblemStatement(programmingExerciseId, problemStatement, req) {
        const options = createRequestOption(req);
        return this.http.patch(`${this.resourceUrl}/${programmingExerciseId}/problem-statement`, problemStatement, {
          params: options,
          observe: "response"
        }).pipe(map((res) => this.processProgrammingExerciseEntityResponse(res)));
      }
      find(programmingExerciseId, withPlagiarismDetectionConfig = false) {
        return this.http.get(`${this.resourceUrl}/${programmingExerciseId}`, {
          observe: "response",
          params: { withPlagiarismDetectionConfig }
        }).pipe(map((res) => this.processProgrammingExerciseEntityResponse(res)));
      }
      findWithTemplateAndSolutionParticipationAndResults(programmingExerciseId) {
        return this.http.get(`${this.resourceUrl}/${programmingExerciseId}/with-participations`, { observe: "response" }).pipe(map((res) => this.processProgrammingExerciseEntityResponse(res)));
      }
      findWithTemplateAndSolutionParticipation(programmingExerciseId, withSubmissionResults = false) {
        let params = new HttpParams();
        params = params.set("withSubmissionResults", withSubmissionResults.toString());
        return this.http.get(`${this.resourceUrl}/${programmingExerciseId}/with-template-and-solution-participation`, {
          params,
          observe: "response"
        }).pipe(map((res) => {
          if (res.body && withSubmissionResults) {
            const templateSubmissions = res.body.templateParticipation?.submissions;
            this.reconnectSubmissionAndResult(templateSubmissions);
            const solutionSubmissions = res.body.solutionParticipation?.submissions;
            this.reconnectSubmissionAndResult(solutionSubmissions);
            this.processProgrammingExerciseEntityResponse(res);
          }
          return res;
        }));
      }
      findWithTemplateAndSolutionParticipationAndLatestResults(programmingExerciseId) {
        return this.findWithTemplateAndSolutionParticipation(programmingExerciseId, true).pipe(map((response) => {
          if (response.body) {
            this.setLatestResultForTemplateAndSolution(response.body);
          }
          return response;
        }));
      }
      setLatestResultForTemplateAndSolution(programmingExercise) {
        if (programmingExercise.templateParticipation) {
          const latestTemplateResult = this.getLatestResult(programmingExercise.templateParticipation);
          if (latestTemplateResult) {
            programmingExercise.templateParticipation.results = [latestTemplateResult];
          }
          programmingExercise.templateParticipation.programmingExercise = programmingExercise;
        }
        if (programmingExercise.solutionParticipation) {
          const latestSolutionResult = this.getLatestResult(programmingExercise.solutionParticipation);
          if (latestSolutionResult) {
            programmingExercise.solutionParticipation.results = [latestSolutionResult];
          }
          programmingExercise.solutionParticipation.programmingExercise = programmingExercise;
        }
      }
      getLatestResult(participation) {
        const submissions = participation.submissions;
        if (!submissions || submissions.length === 0) {
          return;
        }
        this.sortService.sortByProperty(submissions, "submissionDate", true);
        const results = submissions.sort().last()?.results;
        if (results && results.length > 0) {
          return results.last();
        }
      }
      reconnectSubmissionAndResult(submissions) {
        if (submissions) {
          submissions.forEach((submission) => {
            if (submission.results) {
              submission.results.forEach((result) => {
                result.submission = submission;
              });
            }
          });
        }
      }
      getProgrammingExerciseTestCaseState(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/test-case-state`, { observe: "response" });
      }
      query(req) {
        const options = createRequestOption(req);
        return this.http.get(this.resourceUrl, { params: options, observe: "response" }).pipe(map((res) => this.exerciseService.processExerciseEntityArrayResponse(res)));
      }
      delete(programmingExerciseId, deleteStudentReposBuildPlans, deleteBaseReposBuildPlans) {
        let params = new HttpParams();
        params = params.set("deleteStudentReposBuildPlans", deleteStudentReposBuildPlans.toString());
        params = params.set("deleteBaseReposBuildPlans", deleteBaseReposBuildPlans.toString());
        return this.http.delete(`${this.resourceUrl}/${programmingExerciseId}`, { params, observe: "response" });
      }
      convertDataFromClient(exercise) {
        const copy = __spreadProps(__spreadValues({}, ExerciseService.convertExerciseDatesFromClient(exercise)), {
          buildAndTestStudentSubmissionsAfterDueDate: convertDateFromClient(exercise.buildAndTestStudentSubmissionsAfterDueDate)
        });
        if (copy.templateParticipation) {
          copy.templateParticipation = _omit(copy.templateParticipation, ["exercise", "results"]);
        }
        if (copy.solutionParticipation) {
          copy.solutionParticipation = _omit(copy.solutionParticipation, ["exercise", "results"]);
        }
        return copy;
      }
      static convertProgrammingExerciseResponseDatesFromServer(entity) {
        const res = ExerciseService.convertExerciseResponseDatesFromServer(entity);
        if (!res.body) {
          return res;
        }
        res.body.buildAndTestStudentSubmissionsAfterDueDate = convertDateFromServer(res.body.buildAndTestStudentSubmissionsAfterDueDate);
        return res;
      }
      unlockAllRepositories(exerciseId) {
        return this.http.put(`${this.resourceUrl}/${exerciseId}/unlock-all-repositories`, {}, { observe: "response" });
      }
      lockAllRepositories(exerciseId) {
        return this.http.put(`${this.resourceUrl}/${exerciseId}/lock-all-repositories`, {}, { observe: "response" });
      }
      exportInstructorRepository(exerciseId, repositoryType, auxiliaryRepositoryId) {
        if (repositoryType === "AUXILIARY" && auxiliaryRepositoryId !== void 0) {
          return this.http.get(`${this.resourceUrl}/${exerciseId}/export-instructor-auxiliary-repository/${auxiliaryRepositoryId}`, {
            observe: "response",
            responseType: "blob"
          });
        } else {
          return this.http.get(`${this.resourceUrl}/${exerciseId}/export-instructor-repository/${repositoryType}`, {
            observe: "response",
            responseType: "blob"
          });
        }
      }
      exportInstructorExercise(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/export-instructor-exercise`, {
          observe: "response",
          responseType: "blob"
        });
      }
      exportStudentRequestedRepository(exerciseId, includeTests) {
        let params = new HttpParams();
        params = params.set("includeTests", includeTests.toString());
        return this.http.get(`${this.resourceUrl}/${exerciseId}/export-student-requested-repository`, {
          params,
          observe: "response",
          responseType: "blob"
        });
      }
      reevaluateAndUpdate(programmingExercise, req) {
        const options = createRequestOption(req);
        let copy = this.convertDataFromClient(programmingExercise);
        copy = ExerciseService.setBonusPointsConstrainedByIncludedInOverallScore(copy);
        copy.categories = ExerciseService.stringifyExerciseCategories(copy);
        return this.http.put(`${this.resourceUrl}/${programmingExercise.id}/re-evaluate`, copy, {
          params: options,
          observe: "response"
        }).pipe(map((res) => this.exerciseService.processExerciseEntityResponse(res)));
      }
      processProgrammingExerciseEntityResponse(exerciseRes) {
        _ProgrammingExerciseService.convertProgrammingExerciseResponseDatesFromServer(exerciseRes);
        ExerciseService.convertExerciseCategoriesFromServer(exerciseRes);
        this.exerciseService.setAccessRightsExerciseEntityResponseType(exerciseRes);
        this.exerciseService.sendExerciseTitleToTitleService(exerciseRes?.body);
        return exerciseRes;
      }
      getTasksAndTestsExtractedFromProblemStatement(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/tasks`, { observe: "response" }).pipe(map((res) => res.body ?? []));
      }
      getDiffReport(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/diff-report`, { observe: "response" }).pipe(map((res) => res.body ?? void 0));
      }
      getDiffReportForSubmissions(exerciseId, olderSubmissionId, newerSubmissionId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/submissions/${olderSubmissionId}/diff-report/${newerSubmissionId}`, { observe: "response" }).pipe(map((res) => res.body ?? void 0));
      }
      getDiffReportForSubmissionWithTemplate(exerciseId, submissionId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/submissions/${submissionId}/diff-report-with-template`, { observe: "response" }).pipe(map((res) => res.body ?? void 0));
      }
      getLatestFullTestwiseCoverageReport(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/full-testwise-coverage-report`);
      }
      getLatestTestwiseCoverageReport(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/full-testwise-coverage-report`);
      }
      getSolutionRepositoryTestFilesWithContent(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/solution-files-content`).pipe(map((res) => {
          return res && new Map(Object.entries(res));
        }));
      }
      getTemplateRepositoryTestFilesWithContent(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/template-files-content`).pipe(map((res) => {
          return res && new Map(Object.entries(res));
        }));
      }
      getSolutionFileNames(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/file-names`);
      }
      getCodeHintsForExercise(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/exercise-hints`);
      }
      createStructuralSolutionEntries(exerciseId) {
        return this.http.post(`${this.resourceUrl}/${exerciseId}/structural-solution-entries`, null);
      }
      createBehavioralSolutionEntries(exerciseId) {
        return this.http.post(`${this.resourceUrl}/${exerciseId}/behavioral-solution-entries`, null);
      }
      getAllTestCases(exerciseId) {
        return this.http.get(`api/programming-exercises/${exerciseId}/test-cases`);
      }
      getBuildLogStatistics(exerciseId) {
        return this.http.get(`${this.resourceUrl}/${exerciseId}/build-log-statistics`);
      }
      importFromFile(exercise, courseId) {
        let copy = this.convertDataFromClient(exercise);
        copy = ExerciseService.setBonusPointsConstrainedByIncludedInOverallScore(copy);
        copy.categories = ExerciseService.stringifyExerciseCategories(copy);
        const formData = new FormData();
        formData.append("file", exercise.zipFileForImport);
        const exerciseBlob = new Blob([JSON.stringify(copy)], { type: "application/json" });
        formData.append("programmingExercise", exerciseBlob);
        const url = `api/courses/${courseId}/programming-exercises/import-from-file`;
        return this.http.post(url, formData, { observe: "response" }).pipe(map((res) => this.processProgrammingExerciseEntityResponse(res)));
      }
      static \u0275fac = function ProgrammingExerciseService_Factory(t) {
        return new (t || _ProgrammingExerciseService)(i0.\u0275\u0275inject(i1.HttpClient), i0.\u0275\u0275inject(ExerciseService), i0.\u0275\u0275inject(SortService));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _ProgrammingExerciseService, factory: _ProgrammingExerciseService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/code-editor/model/code-editor.model.ts
var FileType, FileChange, CreateFileChange, DeleteFileChange, RenameFileChange, DomainType, RepositoryError, CommitState, EditorState, ResizeType, GitConflictState, FileBadgeType, FileBadge;
var init_code_editor_model = __esm({
  "src/main/webapp/app/exercises/programming/shared/code-editor/model/code-editor.model.ts"() {
    (function(FileType2) {
      FileType2["FILE"] = "FILE";
      FileType2["FOLDER"] = "FOLDER";
    })(FileType || (FileType = {}));
    FileChange = class {
    };
    CreateFileChange = class extends FileChange {
      fileType;
      fileName;
      constructor(fileType, fileName) {
        super();
        this.fileType = fileType;
        this.fileName = fileName;
      }
    };
    DeleteFileChange = class extends FileChange {
      fileType;
      fileName;
      constructor(fileType, fileName) {
        super();
        this.fileType = fileType;
        this.fileName = fileName;
      }
    };
    RenameFileChange = class extends FileChange {
      fileType;
      oldFileName;
      newFileName;
      constructor(fileType, oldFileName, newFileName) {
        super();
        this.fileType = fileType;
        this.oldFileName = oldFileName;
        this.newFileName = newFileName;
      }
    };
    (function(DomainType2) {
      DomainType2["PARTICIPATION"] = "PARTICIPATION";
      DomainType2["TEST_REPOSITORY"] = "TEST_REPOSITORY";
    })(DomainType || (DomainType = {}));
    (function(RepositoryError2) {
      RepositoryError2["CHECKOUT_CONFLICT"] = "checkoutConflict";
    })(RepositoryError || (RepositoryError = {}));
    (function(CommitState2) {
      CommitState2["UNDEFINED"] = "UNDEFINED";
      CommitState2["COULD_NOT_BE_RETRIEVED"] = "COULD_NOT_BE_RETRIEVED";
      CommitState2["CLEAN"] = "CLEAN";
      CommitState2["UNCOMMITTED_CHANGES"] = "UNCOMMITTED_CHANGES";
      CommitState2["COMMITTING"] = "COMMITTING";
      CommitState2["CONFLICT"] = "CONFLICT";
    })(CommitState || (CommitState = {}));
    (function(EditorState2) {
      EditorState2["CLEAN"] = "CLEAN";
      EditorState2["UNSAVED_CHANGES"] = "UNSAVED_CHANGES";
      EditorState2["SAVING"] = "SAVING";
      EditorState2["REFRESHING"] = "REFRESHING";
    })(EditorState || (EditorState = {}));
    (function(ResizeType2) {
      ResizeType2["SIDEBAR_LEFT"] = "SIDEBAR_LEFT";
      ResizeType2["SIDEBAR_RIGHT"] = "SIDEBAR_RIGHT";
      ResizeType2["MAIN_BOTTOM"] = "MAIN_BOTTOM";
      ResizeType2["BOTTOM"] = "BOTTOM";
    })(ResizeType || (ResizeType = {}));
    (function(GitConflictState2) {
      GitConflictState2["CHECKOUT_CONFLICT"] = "CHECKOUT_CONFLICT";
      GitConflictState2["OK"] = "OK";
    })(GitConflictState || (GitConflictState = {}));
    (function(FileBadgeType2) {
      FileBadgeType2["FEEDBACK_SUGGESTION"] = "FEEDBACK_SUGGESTION";
    })(FileBadgeType || (FileBadgeType = {}));
    FileBadge = class {
      type;
      count;
      constructor(type, count) {
        this.type = type;
        this.count = count;
      }
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/code-editor/service/code-editor-domain.service.ts
import { Injectable as Injectable2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { BehaviorSubject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var DomainService;
var init_code_editor_domain_service = __esm({
  "src/main/webapp/app/exercises/programming/shared/code-editor/service/code-editor-domain.service.ts"() {
    DomainService = class _DomainService {
      domain;
      subject = new BehaviorSubject(void 0);
      constructor() {
      }
      setDomain(domain) {
        this.domain = domain;
        this.subject.next(domain);
      }
      subscribeDomainChange() {
        return this.subject;
      }
      static \u0275fac = function DomainService_Factory(t) {
        return new (t || _DomainService)();
      };
      static \u0275prov = i02.\u0275\u0275defineInjectable({ token: _DomainService, factory: _DomainService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/code-editor/service/code-editor-domain-dependent.service.ts
import { Injectable as Injectable3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { filter, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var DomainDependentService;
var init_code_editor_domain_dependent_service = __esm({
  "src/main/webapp/app/exercises/programming/shared/code-editor/service/code-editor-domain-dependent.service.ts"() {
    init_code_editor_domain_service();
    init_code_editor_domain_service();
    DomainDependentService = class _DomainDependentService {
      domainService;
      domain;
      domainChangeSubscription;
      constructor(domainService) {
        this.domainService = domainService;
      }
      initDomainSubscription() {
        this.domainChangeSubscription = this.domainService.subscribeDomainChange().pipe(filter((domain) => !!domain), tap((domain) => {
          this.setDomain(domain);
        })).subscribe();
      }
      setDomain(domain) {
        this.domain = domain;
      }
      ngOnDestroy() {
        if (this.domainChangeSubscription) {
          this.domainChangeSubscription.unsubscribe();
        }
      }
      static \u0275fac = function DomainDependentService_Factory(t) {
        return new (t || _DomainDependentService)(i03.\u0275\u0275inject(DomainService));
      };
      static \u0275prov = i03.\u0275\u0275defineInjectable({ token: _DomainDependentService, factory: _DomainDependentService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/code-editor/service/code-editor-conflict-state.service.ts
import { BehaviorSubject as BehaviorSubject2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { Injectable as Injectable4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { distinctUntilChanged } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var CodeEditorConflictStateService;
var init_code_editor_conflict_state_service = __esm({
  "src/main/webapp/app/exercises/programming/shared/code-editor/service/code-editor-conflict-state.service.ts"() {
    init_websocket_service();
    init_code_editor_domain_service();
    init_code_editor_model();
    init_code_editor_domain_dependent_service();
    init_code_editor_domain_service();
    init_websocket_service();
    CodeEditorConflictStateService = class _CodeEditorConflictStateService extends DomainDependentService {
      jhiWebsocketService;
      conflictSubjects = /* @__PURE__ */ new Map();
      websocketConnections = /* @__PURE__ */ new Map();
      constructor(domainService, jhiWebsocketService) {
        super(domainService);
        this.jhiWebsocketService = jhiWebsocketService;
        this.initDomainSubscription();
      }
      ngOnDestroy() {
        Object.values(this.websocketConnections).forEach((channel) => this.jhiWebsocketService.unsubscribe(channel));
      }
      subscribeConflictState = () => {
        const domainKey = this.getDomainKey();
        const subject = this.conflictSubjects.get(domainKey);
        if (!subject) {
          const repoSubject = new BehaviorSubject2(GitConflictState.OK);
          this.conflictSubjects.set(domainKey, repoSubject);
          return repoSubject.pipe(distinctUntilChanged());
        } else {
          return subject.pipe(distinctUntilChanged());
        }
      };
      notifyConflictState = (gitConflictState) => {
        const domainKey = this.getDomainKey();
        const subject = this.conflictSubjects.get(domainKey);
        if (subject) {
          subject.next(gitConflictState);
        }
      };
      getDomainKey = () => {
        const [domainType, domainValue] = this.domain;
        return `${domainType === DomainType.PARTICIPATION ? "participation" : "test"}-${domainValue.id.toString()}`;
      };
      static \u0275fac = function CodeEditorConflictStateService_Factory(t) {
        return new (t || _CodeEditorConflictStateService)(i04.\u0275\u0275inject(DomainService), i04.\u0275\u0275inject(JhiWebsocketService));
      };
      static \u0275prov = i04.\u0275\u0275defineInjectable({ token: _CodeEditorConflictStateService, factory: _CodeEditorConflictStateService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/code-editor/service/code-editor-domain-dependent-endpoint.service.ts
var DomainDependentEndpointService;
var init_code_editor_domain_dependent_endpoint_service = __esm({
  "src/main/webapp/app/exercises/programming/shared/code-editor/service/code-editor-domain-dependent-endpoint.service.ts"() {
    init_code_editor_domain_dependent_service();
    init_code_editor_model();
    DomainDependentEndpointService = class extends DomainDependentService {
      http;
      jhiWebsocketService;
      restResourceUrl;
      constructor(http, jhiWebsocketService, domainService) {
        super(domainService);
        this.http = http;
        this.jhiWebsocketService = jhiWebsocketService;
        this.initDomainSubscription();
      }
      setDomain(domain) {
        super.setDomain(domain);
        this.restResourceUrl = this.calculateRestResourceURL(domain);
      }
      calculateRestResourceURL(domain) {
        const [domainType, domainValue] = domain;
        switch (domainType) {
          case DomainType.PARTICIPATION:
            return `api/repository/${domainValue.id}`;
          case DomainType.TEST_REPOSITORY:
            return `api/test-repository/${domainValue.id}`;
        }
      }
    };
  }
});

// src/main/webapp/app/exercises/programming/shared/code-editor/service/code-editor-repository.service.ts
import { HttpClient as HttpClient3, HttpParams as HttpParams2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { Injectable as Injectable5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject, of, pipe, throwError } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { catchError, map as map2, tap as tap2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var ConnectionError, checkIfSubmissionIsError, handleErrorResponse, CodeEditorRepositoryService, CodeEditorBuildLogService, CodeEditorRepositoryFileService;
var init_code_editor_repository_service = __esm({
  "src/main/webapp/app/exercises/programming/shared/code-editor/service/code-editor-repository.service.ts"() {
    init_code_editor_model();
    init_code_editor_conflict_state_service();
    init_build_log_service();
    init_websocket_service();
    init_code_editor_domain_service();
    init_code_editor_domain_dependent_endpoint_service();
    init_download_util();
    init_websocket_service();
    init_code_editor_domain_service();
    init_code_editor_conflict_state_service();
    init_build_log_service();
    ConnectionError = class _ConnectionError extends Error {
      constructor() {
        super("InternetDisconnected");
        Object.setPrototypeOf(this, _ConnectionError.prototype);
      }
      static get message() {
        return "InternetDisconnected";
      }
    };
    checkIfSubmissionIsError = (toBeDetermined) => {
      return !!toBeDetermined.error;
    };
    handleErrorResponse = (conflictService) => pipe(catchError((err) => {
      if (err.status === 409) {
        conflictService.notifyConflictState(GitConflictState.CHECKOUT_CONFLICT);
      }
      if (err.status === 0 || err.status === 504) {
        return throwError(() => new ConnectionError());
      }
      return throwError(() => err);
    }));
    CodeEditorRepositoryService = class _CodeEditorRepositoryService extends DomainDependentEndpointService {
      conflictService;
      constructor(http, jhiWebsocketService, domainService, conflictService) {
        super(http, jhiWebsocketService, domainService);
        this.conflictService = conflictService;
      }
      getStatus = () => {
        return this.http.get(this.restResourceUrl).pipe(handleErrorResponse(this.conflictService), tap2(({ repositoryStatus }) => {
          if (repositoryStatus !== CommitState.CONFLICT) {
            this.conflictService.notifyConflictState(GitConflictState.OK);
          }
        }));
      };
      commit = () => {
        return this.http.post(`${this.restResourceUrl}/commit`, {}).pipe(handleErrorResponse(this.conflictService));
      };
      pull = () => {
        return this.http.get(`${this.restResourceUrl}/pull`, {}).pipe(handleErrorResponse(this.conflictService));
      };
      resetRepository = () => {
        return this.http.post(`${this.restResourceUrl}/reset`, {});
      };
      static \u0275fac = function CodeEditorRepositoryService_Factory(t) {
        return new (t || _CodeEditorRepositoryService)(i05.\u0275\u0275inject(i12.HttpClient), i05.\u0275\u0275inject(JhiWebsocketService), i05.\u0275\u0275inject(DomainService), i05.\u0275\u0275inject(CodeEditorConflictStateService));
      };
      static \u0275prov = i05.\u0275\u0275defineInjectable({ token: _CodeEditorRepositoryService, factory: _CodeEditorRepositoryService.\u0275fac, providedIn: "root" });
    };
    CodeEditorBuildLogService = class _CodeEditorBuildLogService extends DomainDependentEndpointService {
      buildLogService;
      constructor(buildLogService, http, jhiWebsocketService, domainService) {
        super(http, jhiWebsocketService, domainService);
        this.buildLogService = buildLogService;
      }
      getBuildLogs = () => {
        const [domainType, domainValue] = this.domain;
        if (domainType === DomainType.PARTICIPATION) {
          return this.buildLogService.getBuildLogs(domainValue.id);
        }
        return of([]);
      };
      static \u0275fac = function CodeEditorBuildLogService_Factory(t) {
        return new (t || _CodeEditorBuildLogService)(i05.\u0275\u0275inject(BuildLogService), i05.\u0275\u0275inject(i12.HttpClient), i05.\u0275\u0275inject(JhiWebsocketService), i05.\u0275\u0275inject(DomainService));
      };
      static \u0275prov = i05.\u0275\u0275defineInjectable({ token: _CodeEditorBuildLogService, factory: _CodeEditorBuildLogService.\u0275fac, providedIn: "root" });
    };
    CodeEditorRepositoryFileService = class _CodeEditorRepositoryFileService extends DomainDependentEndpointService {
      conflictService;
      fileUpdateSubject = new Subject();
      constructor(http, jhiWebsocketService, domainService, conflictService) {
        super(http, jhiWebsocketService, domainService);
        this.conflictService = conflictService;
      }
      ngOnDestroy() {
        super.ngOnDestroy();
      }
      downloadFile(fileName, downloadName) {
        this.http.get(`${this.restResourceUrl}/file`, { params: new HttpParams2().set("file", fileName), responseType: "blob" }).pipe(handleErrorResponse(this.conflictService)).subscribe((res) => {
          downloadFile(res, downloadName);
        });
      }
      setDomain(domain) {
        super.setDomain(domain);
        if (this.fileUpdateSubject) {
          this.fileUpdateSubject.complete();
        }
      }
      getRepositoryContent = (domain) => {
        const restResourceUrl = domain ? this.calculateRestResourceURL(domain) : this.restResourceUrl;
        return this.http.get(`${restResourceUrl}/files`).pipe(handleErrorResponse(this.conflictService));
      };
      getFilesWithInformationAboutChange = (domain) => {
        const restResourceUrl = domain ? this.calculateRestResourceURL(domain) : this.restResourceUrl;
        return this.http.get(`${restResourceUrl}/files-change`).pipe(handleErrorResponse(this.conflictService));
      };
      getFile = (fileName, domain) => {
        const restResourceUrl = domain ? this.calculateRestResourceURL(domain) : this.restResourceUrl;
        return this.http.get(`${restResourceUrl}/file`, { params: new HttpParams2().set("file", fileName), responseType: "text" }).pipe(map2((data) => ({ fileContent: data })), handleErrorResponse(this.conflictService));
      };
      getFileHeaders = (fileName, domain) => {
        const restResourceUrl = domain ? this.calculateRestResourceURL(domain) : this.restResourceUrl;
        return this.http.head(`${restResourceUrl}/file`, { observe: "response", params: new HttpParams2().set("file", fileName) }).pipe(handleErrorResponse(this.conflictService));
      };
      getFilesWithContent = (domain) => {
        const restResourceUrl = domain ? this.calculateRestResourceURL(domain) : this.restResourceUrl;
        return this.http.get(`${restResourceUrl}/files-content`).pipe(handleErrorResponse(this.conflictService));
      };
      createFile = (fileName) => {
        return this.http.post(`${this.restResourceUrl}/file`, "", { params: new HttpParams2().set("file", fileName) }).pipe(handleErrorResponse(this.conflictService));
      };
      createFolder = (folderName) => {
        return this.http.post(`${this.restResourceUrl}/folder`, "", { params: new HttpParams2().set("folder", folderName) }).pipe(handleErrorResponse(this.conflictService));
      };
      updateFileContent = (fileName, fileContent) => {
        return this.http.put(`${this.restResourceUrl}/file`, fileContent, {
          params: new HttpParams2().set("file", fileName)
        }).pipe(handleErrorResponse(this.conflictService));
      };
      updateFiles(fileUpdates, thenCommit = false) {
        if (this.fileUpdateSubject) {
          this.fileUpdateSubject.complete();
        }
        this.fileUpdateSubject = new Subject();
        return this.http.put(`${this.restResourceUrl}/files`, fileUpdates, {
          params: { commit: thenCommit ? "yes" : "no" }
        }).pipe(handleErrorResponse(this.conflictService), tap2((fileSubmission) => {
          if (checkIfSubmissionIsError(fileSubmission)) {
            this.fileUpdateSubject.error(fileSubmission);
            if (fileSubmission.error === RepositoryError.CHECKOUT_CONFLICT) {
              this.conflictService.notifyConflictState(GitConflictState.CHECKOUT_CONFLICT);
            }
            return;
          }
          this.fileUpdateSubject.next(fileSubmission);
        }));
      }
      renameFile = (currentFilePath, newFilename) => {
        return this.http.post(`${this.restResourceUrl}/rename-file`, { currentFilePath, newFilename }).pipe(handleErrorResponse(this.conflictService));
      };
      deleteFile = (fileName) => {
        return this.http.delete(`${this.restResourceUrl}/file`, { params: new HttpParams2().set("file", fileName) }).pipe(handleErrorResponse(this.conflictService));
      };
      static \u0275fac = function CodeEditorRepositoryFileService_Factory(t) {
        return new (t || _CodeEditorRepositoryFileService)(i05.\u0275\u0275inject(i12.HttpClient), i05.\u0275\u0275inject(JhiWebsocketService), i05.\u0275\u0275inject(DomainService), i05.\u0275\u0275inject(CodeEditorConflictStateService));
      };
      static \u0275prov = i05.\u0275\u0275defineInjectable({ token: _CodeEditorRepositoryFileService, factory: _CodeEditorRepositoryFileService.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  ProgrammingExerciseService,
  init_programming_exercise_service,
  FileType,
  CreateFileChange,
  DeleteFileChange,
  RenameFileChange,
  DomainType,
  CommitState,
  EditorState,
  ResizeType,
  GitConflictState,
  FileBadgeType,
  FileBadge,
  init_code_editor_model,
  DomainService,
  init_code_editor_domain_service,
  DomainDependentService,
  init_code_editor_domain_dependent_service,
  CodeEditorConflictStateService,
  init_code_editor_conflict_state_service,
  ConnectionError,
  CodeEditorRepositoryService,
  CodeEditorBuildLogService,
  CodeEditorRepositoryFileService,
  init_code_editor_repository_service
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL21hbmFnZS9zZXJ2aWNlcy9wcm9ncmFtbWluZy1leGVyY2lzZS5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2NvZGUtZWRpdG9yL21vZGVsL2NvZGUtZWRpdG9yLm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2NvZGUtZWRpdG9yL3NlcnZpY2UvY29kZS1lZGl0b3ItZG9tYWluLnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvY29kZS1lZGl0b3Ivc2VydmljZS9jb2RlLWVkaXRvci1kb21haW4tZGVwZW5kZW50LnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvY29kZS1lZGl0b3Ivc2VydmljZS9jb2RlLWVkaXRvci1jb25mbGljdC1zdGF0ZS5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2NvZGUtZWRpdG9yL3NlcnZpY2UvY29kZS1lZGl0b3ItZG9tYWluLWRlcGVuZGVudC1lbmRwb2ludC5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2NvZGUtZWRpdG9yL3NlcnZpY2UvY29kZS1lZGl0b3ItcmVwb3NpdG9yeS5zZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCBkYXlqcyBmcm9tICdkYXlqcy9lc20nO1xuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cFBhcmFtcywgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgb21pdCBhcyBfb21pdCB9IGZyb20gJ2xvZGFzaC1lcyc7XG5cbmltcG9ydCB7IGNyZWF0ZVJlcXVlc3RPcHRpb24gfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvcmVxdWVzdC51dGlsJztcbmltcG9ydCB7IEV4ZXJjaXNlU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlL2V4ZXJjaXNlLnNlcnZpY2UnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9wcm9ncmFtbWluZy1leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBUZW1wbGF0ZVByb2dyYW1taW5nRXhlcmNpc2VQYXJ0aWNpcGF0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3BhcnRpY2lwYXRpb24vdGVtcGxhdGUtcHJvZ3JhbW1pbmctZXhlcmNpc2UtcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBTb2x1dGlvblByb2dyYW1taW5nRXhlcmNpc2VQYXJ0aWNpcGF0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3BhcnRpY2lwYXRpb24vc29sdXRpb24tcHJvZ3JhbW1pbmctZXhlcmNpc2UtcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBUZXh0UGxhZ2lhcmlzbVJlc3VsdCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvdGV4dC9UZXh0UGxhZ2lhcmlzbVJlc3VsdCc7XG5pbXBvcnQgeyBQbGFnaWFyaXNtT3B0aW9ucyB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbU9wdGlvbnMnO1xuaW1wb3J0IHsgU3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2VHaXREaWZmUmVwb3J0IH0gZnJvbSAnYXBwL2VudGl0aWVzL2hlc3RpYS9wcm9ncmFtbWluZy1leGVyY2lzZS1naXQtZGlmZi1yZXBvcnQubW9kZWwnO1xuaW1wb3J0IHsgQ292ZXJhZ2VSZXBvcnQgfSBmcm9tICdhcHAvZW50aXRpZXMvaGVzdGlhL2NvdmVyYWdlLXJlcG9ydC5tb2RlbCc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlU29sdXRpb25FbnRyeSB9IGZyb20gJ2FwcC9lbnRpdGllcy9oZXN0aWEvcHJvZ3JhbW1pbmctZXhlcmNpc2Utc29sdXRpb24tZW50cnkubW9kZWwnO1xuaW1wb3J0IHsgUHJvZ3JhbW1pbmdFeGVyY2lzZVNlcnZlclNpZGVUYXNrIH0gZnJvbSAnYXBwL2VudGl0aWVzL2hlc3RpYS9wcm9ncmFtbWluZy1leGVyY2lzZS10YXNrLm1vZGVsJztcbmltcG9ydCB7IGNvbnZlcnREYXRlRnJvbUNsaWVudCwgY29udmVydERhdGVGcm9tU2VydmVyIH0gZnJvbSAnYXBwL3V0aWxzL2RhdGUudXRpbHMnO1xuaW1wb3J0IHsgRXhlcmNpc2VIaW50IH0gZnJvbSAnYXBwL2VudGl0aWVzL2hlc3RpYS9leGVyY2lzZS1oaW50Lm1vZGVsJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2VUZXN0Q2FzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9wcm9ncmFtbWluZy1leGVyY2lzZS10ZXN0LWNhc2UubW9kZWwnO1xuaW1wb3J0IHsgQnVpbGRMb2dTdGF0aXN0aWNzRFRPIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9tYW5hZ2UvYnVpbGQtbG9nLXN0YXRpc3RpY3MtZHRvJztcbmltcG9ydCB7IFNvcnRTZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9zZXJ2aWNlL3NvcnQuc2VydmljZSc7XG5pbXBvcnQgeyBSZXN1bHQgfSBmcm9tICdhcHAvZW50aXRpZXMvcmVzdWx0Lm1vZGVsJztcbmltcG9ydCB7IFBhcnRpY2lwYXRpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvcGFydGljaXBhdGlvbi9wYXJ0aWNpcGF0aW9uLm1vZGVsJztcbmltcG9ydCB7IFBsYWdpYXJpc21SZXN1bHREVE8gfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wbGFnaWFyaXNtL3R5cGVzL1BsYWdpYXJpc21SZXN1bHREVE8nO1xuXG5leHBvcnQgdHlwZSBFbnRpdHlSZXNwb25zZVR5cGUgPSBIdHRwUmVzcG9uc2U8UHJvZ3JhbW1pbmdFeGVyY2lzZT47XG5leHBvcnQgdHlwZSBFbnRpdHlBcnJheVJlc3BvbnNlVHlwZSA9IEh0dHBSZXNwb25zZTxQcm9ncmFtbWluZ0V4ZXJjaXNlW10+O1xuXG5leHBvcnQgdHlwZSBQcm9ncmFtbWluZ0V4ZXJjaXNlVGVzdENhc2VTdGF0ZURUTyA9IHtcbiAgICByZWxlYXNlZDogYm9vbGVhbjtcbiAgICBoYXNTdHVkZW50UmVzdWx0OiBib29sZWFuO1xuICAgIHRlc3RDYXNlc0NoYW5nZWQ6IGJvb2xlYW47XG4gICAgYnVpbGRBbmRUZXN0U3R1ZGVudFN1Ym1pc3Npb25zQWZ0ZXJEdWVEYXRlPzogZGF5anMuRGF5anM7XG59O1xuXG5leHBvcnQgdHlwZSBQcm9ncmFtbWluZ0V4ZXJjaXNlUmVzZXRPcHRpb25zID0ge1xuICAgIGRlbGV0ZUJ1aWxkUGxhbnM6IGJvb2xlYW47XG4gICAgZGVsZXRlUmVwb3NpdG9yaWVzOiBib29sZWFuO1xuICAgIGRlbGV0ZVBhcnRpY2lwYXRpb25zU3VibWlzc2lvbnNBbmRSZXN1bHRzOiBib29sZWFuO1xuICAgIHJlY3JlYXRlQnVpbGRQbGFuczogYm9vbGVhbjtcbn07XG5cbi8vIFRPRE86IHdlIHNob3VsZCB1c2UgYSBwcm9wZXIgZW51bSBoZXJlXG5leHBvcnQgdHlwZSBQcm9ncmFtbWluZ0V4ZXJjaXNlSW5zdHJ1Y3RvclJlcG9zaXRvcnlUeXBlID0gJ1RFTVBMQVRFJyB8ICdTT0xVVElPTicgfCAnVEVTVFMnIHwgJ0FVWElMSUFSWSc7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgUHJvZ3JhbW1pbmdFeGVyY2lzZVNlcnZpY2Uge1xuICAgIHB1YmxpYyByZXNvdXJjZVVybCA9ICdhcGkvcHJvZ3JhbW1pbmctZXhlcmNpc2VzJztcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQsXG4gICAgICAgIHByaXZhdGUgZXhlcmNpc2VTZXJ2aWNlOiBFeGVyY2lzZVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgc29ydFNlcnZpY2U6IFNvcnRTZXJ2aWNlLFxuICAgICkge31cblxuICAgIC8qKlxuICAgICAqIFNldHMgYSBuZXcgcHJvZ3JhbW1pbmcgZXhlcmNpc2UgdXBcbiAgICAgKiBAcGFyYW0gcHJvZ3JhbW1pbmdFeGVyY2lzZSB3aGljaCBzaG91bGQgYmUgc2V0dXBcbiAgICAgKi9cbiAgICBhdXRvbWF0aWNTZXR1cChwcm9ncmFtbWluZ0V4ZXJjaXNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlKTogT2JzZXJ2YWJsZTxFbnRpdHlSZXNwb25zZVR5cGU+IHtcbiAgICAgICAgbGV0IGNvcHkgPSB0aGlzLmNvbnZlcnREYXRhRnJvbUNsaWVudChwcm9ncmFtbWluZ0V4ZXJjaXNlKTtcbiAgICAgICAgY29weSA9IEV4ZXJjaXNlU2VydmljZS5zZXRCb251c1BvaW50c0NvbnN0cmFpbmVkQnlJbmNsdWRlZEluT3ZlcmFsbFNjb3JlKGNvcHkpO1xuICAgICAgICBjb3B5LmNhdGVnb3JpZXMgPSBFeGVyY2lzZVNlcnZpY2Uuc3RyaW5naWZ5RXhlcmNpc2VDYXRlZ29yaWVzKGNvcHkpO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAucG9zdDxQcm9ncmFtbWluZ0V4ZXJjaXNlPih0aGlzLnJlc291cmNlVXJsICsgJy9zZXR1cCcsIGNvcHksIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEVudGl0eVJlc3BvbnNlVHlwZSkgPT4gdGhpcy5wcm9jZXNzUHJvZ3JhbW1pbmdFeGVyY2lzZUVudGl0eVJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZW5lcmF0ZXMgdGhlIHN0cnVjdHVyZSBvcmFjbGVcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCBvZiB0aGUgcHJvZ3JhbW1pbmcgZXhlcmNpc2UgZm9yIHdoaWNoIHRoZSBzdHJ1Y3R1cmUgb3JhY2xlIHNob3VsZCBiZSBjcmVhdGVkXG4gICAgICovXG4gICAgZ2VuZXJhdGVTdHJ1Y3R1cmVPcmFjbGUoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8c3RyaW5nPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L2dlbmVyYXRlLXRlc3RzYCwgeyByZXNwb25zZVR5cGU6ICd0ZXh0JyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXNldHMgYSBwcm9ncmFtbWluZyBleGVyY2lzZSB3aXRoIHRoZSBnaXZlbiBleGVyY2lzZUlkIGJ5IHBlcmZvcm1pbmcgYSBzZXQgb2Ygb3BlcmF0aW9uc1xuICAgICAqIGFzIHNwZWNpZmllZCBpbiB0aGUgUHJvZ3JhbW1pbmdFeGVyY2lzZVJlc2V0T3B0aW9ucy4gVGhlIGF2YWlsYWJsZSBvcGVyYXRpb25zIGluY2x1ZGU6XG4gICAgICogMS4gUmVjcmVhdGluZyB0aGUgQkFTRSBhbmQgU09MVVRJT04gYnVpbGQgcGxhbnMgZm9yIHRoZSBleGVyY2lzZS5cbiAgICAgKiAyLiBEZWxldGluZyBhbGwgc3R1ZGVudCBwYXJ0aWNpcGF0aW9ucyBhc3NvY2lhdGVkIHdpdGggdGhlIGV4ZXJjaXNlLlxuICAgICAqIDMuIERlbGV0aW5nIHN0dWRlbnQgYnVpbGQgcGxhbnMgKGV4Y2VwdCBCQVNFL1NPTFVUSU9OKSBhbmQgb3B0aW9uYWxseSBnaXQgcmVwb3NpdG9yaWVzIG9mIGFsbCBleGVyY2lzZSBzdHVkZW50IHBhcnRpY2lwYXRpb25zLlxuICAgICAqXG4gICAgICogQHBhcmFtIHsgbnVtYmVyIH0gZXhlcmNpc2VJZCAtIElkIG9mIHRoZSBwcm9ncmFtbWluZyBleGVyY2lzZSB0aGF0IHNob3VsZCBiZSByZXNldC5cbiAgICAgKiBAcGFyYW0geyBQcm9ncmFtbWluZ0V4ZXJjaXNlUmVzZXRPcHRpb25zIH0gb3B0aW9ucyAtIENvbmZpZ3VyYXRpb24gb3B0aW9ucyBzcGVjaWZ5aW5nIHdoaWNoIG9wZXJhdGlvbnMgdG8gcGVyZm9ybSBkdXJpbmcgdGhlIGV4ZXJjaXNlIHJlc2V0LlxuICAgICAqIEByZXR1cm5zIHsgT2JzZXJ2YWJsZTxzdHJpbmc+IH0gLSBBbiBPYnNlcnZhYmxlIHRoYXQgcmV0dXJucyBhIHN0cmluZyByZXNwb25zZS5cbiAgICAgKi9cbiAgICByZXNldChleGVyY2lzZUlkOiBudW1iZXIsIG9wdGlvbnM6IFByb2dyYW1taW5nRXhlcmNpc2VSZXNldE9wdGlvbnMpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnB1dChgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L3Jlc2V0YCwgb3B0aW9ucywgeyByZXNwb25zZVR5cGU6ICd0ZXh0JyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVjayBwbGFnaWFyaXNtIHdpdGggSlBsYWdcbiAgICAgKlxuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkXG4gICAgICogQHBhcmFtIG9wdGlvbnNcbiAgICAgKi9cbiAgICBjaGVja1BsYWdpYXJpc20oZXhlcmNpc2VJZDogbnVtYmVyLCBvcHRpb25zPzogUGxhZ2lhcmlzbU9wdGlvbnMpOiBPYnNlcnZhYmxlPFBsYWdpYXJpc21SZXN1bHREVE88VGV4dFBsYWdpYXJpc21SZXN1bHQ+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5nZXQ8UGxhZ2lhcmlzbVJlc3VsdERUTzxUZXh0UGxhZ2lhcmlzbVJlc3VsdD4+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7ZXhlcmNpc2VJZH0vY2hlY2stcGxhZ2lhcmlzbWAsIHtcbiAgICAgICAgICAgICAgICBvYnNlcnZlOiAncmVzcG9uc2UnLFxuICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICAuLi5vcHRpb25zPy50b1BhcmFtcygpLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXNwb25zZTogSHR0cFJlc3BvbnNlPFBsYWdpYXJpc21SZXN1bHREVE88VGV4dFBsYWdpYXJpc21SZXN1bHQ+PikgPT4gcmVzcG9uc2UuYm9keSEpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGVjayBmb3IgcGxhZ2lhcmlzbVxuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkIG9mIHRoZSBwcm9ncmFtbWluZyBleGVyY2lzZVxuICAgICAqIEBwYXJhbSBvcHRpb25zXG4gICAgICovXG4gICAgY2hlY2tQbGFnaWFyaXNtSlBsYWdSZXBvcnQoZXhlcmNpc2VJZDogbnVtYmVyLCBvcHRpb25zPzogUGxhZ2lhcmlzbU9wdGlvbnMpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxCbG9iPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L2NoZWNrLXBsYWdpYXJpc20tanBsYWctcmVwb3J0YCwge1xuICAgICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyxcbiAgICAgICAgICAgIHJlc3BvbnNlVHlwZTogJ2Jsb2InLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgLi4ub3B0aW9ucz8udG9QYXJhbXMoKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCB0aGUgbGF0ZXN0IHBsYWdpYXJpc20gcmVzdWx0IGZvciB0aGUgZXhlcmNpc2Ugd2l0aCB0aGUgZ2l2ZW4gSUQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZFxuICAgICAqL1xuICAgIGdldExhdGVzdFBsYWdpYXJpc21SZXN1bHQoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxQbGFnaWFyaXNtUmVzdWx0RFRPPFRleHRQbGFnaWFyaXNtUmVzdWx0Pj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAuZ2V0PFBsYWdpYXJpc21SZXN1bHREVE88VGV4dFBsYWdpYXJpc21SZXN1bHQ+PihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L3BsYWdpYXJpc20tcmVzdWx0YCwge1xuICAgICAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXNwb25zZTogSHR0cFJlc3BvbnNlPFBsYWdpYXJpc21SZXN1bHREVE88VGV4dFBsYWdpYXJpc21SZXN1bHQ+PikgPT4gcmVzcG9uc2UuYm9keSEpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDb21iaW5lcyBhbGwgY29tbWl0cyBvZiB0aGUgdGVtcGxhdGUgcmVwb3NpdG9yeSB0byBvbmVcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCBvZiB0aGUgcGFydGljdWxhciBwcm9ncmFtbWluZyBleGVyY2lzZVxuICAgICAqL1xuICAgIGNvbWJpbmVUZW1wbGF0ZVJlcG9zaXRvcnlDb21taXRzKGV4ZXJjaXNlSWQ6IG51bWJlcikge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnB1dChgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L2NvbWJpbmUtdGVtcGxhdGUtY29tbWl0c2AsIHsgcmVzcG9uc2VUeXBlOiAndGV4dCcgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSW1wb3J0cyBhIHByb2dyYW1taW5nIGV4ZXJjaXNlIGJ5IGNsb25pbmcgdGhlIGVudGl0eSBpdHNlbGYgcGx1cyBhbGwgYmFzaWMgYnVpbGQgcGxhbnMgYW5kIHJlcG9zaXRvcmllc1xuICAgICAqICh0ZW1wbGF0ZSwgc29sdXRpb24sIHRlc3QpLlxuICAgICAqXG4gICAgICogQHBhcmFtIGFkYXB0ZWRTb3VyY2VQcm9ncmFtbWluZ0V4ZXJjaXNlIFRoZSBleGVyY2lzZSB0aGF0IHNob3VsZCBiZSBpbXBvcnRlZCwgaW5jbHVkaW5nIGFkYXB0ZWQgdmFsdWVzIGZvciB0aGVcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IGV4ZXJjaXNlLiBFLmcuIHdpdGggYW5vdGhlciB0aXRsZSB0aGFuIHRoZSBvcmlnaW5hbCBleGVyY2lzZS4gT2xkXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlcyB0aGF0IHNob3VsZCBnZXQgZGlzY2FyZGVkIChsaWtlIHRoZSBvbGQgSUQpIHdpbGwgYmUgaGFuZGxlZCBieSB0aGVcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VydmVyLlxuICAgICAqIEBwYXJhbSByZWNyZWF0ZUJ1aWxkUGxhbnMgT3B0aW9uIGRldGVybWluaW5nIHdoZXRoZXIgdGhlIGJ1aWxkIHBsYW5zIHNob3VsZCBiZSByZWNyZWF0ZWQgb3IgY29waWVkIGZyb20gdGhlIGltcG9ydGVkIGV4ZXJjaXNlXG4gICAgICogQHBhcmFtIHVwZGF0ZVRlbXBsYXRlIE9wdGlvbiBkZXRlcm1pbmluZyB3aGV0aGVyIHRoZSB0ZW1wbGF0ZSBmaWxlcyBpbiB0aGUgcmVwb3NpdG9yaWVzIHNob3VsZCBiZSB1cGRhdGVkXG4gICAgICovXG4gICAgaW1wb3J0RXhlcmNpc2UoYWRhcHRlZFNvdXJjZVByb2dyYW1taW5nRXhlcmNpc2U6IFByb2dyYW1taW5nRXhlcmNpc2UsIHJlY3JlYXRlQnVpbGRQbGFuczogYm9vbGVhbiwgdXBkYXRlVGVtcGxhdGU6IGJvb2xlYW4pOiBPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT4ge1xuICAgICAgICBjb25zdCBvcHRpb25zID0gY3JlYXRlUmVxdWVzdE9wdGlvbih7IHJlY3JlYXRlQnVpbGRQbGFucywgdXBkYXRlVGVtcGxhdGUgfSk7XG4gICAgICAgIGNvbnN0IGV4ZXJjaXNlID0gRXhlcmNpc2VTZXJ2aWNlLnNldEJvbnVzUG9pbnRzQ29uc3RyYWluZWRCeUluY2x1ZGVkSW5PdmVyYWxsU2NvcmUoYWRhcHRlZFNvdXJjZVByb2dyYW1taW5nRXhlcmNpc2UpO1xuICAgICAgICBleGVyY2lzZS5jYXRlZ29yaWVzID0gRXhlcmNpc2VTZXJ2aWNlLnN0cmluZ2lmeUV4ZXJjaXNlQ2F0ZWdvcmllcyhleGVyY2lzZSk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5wb3N0PFByb2dyYW1taW5nRXhlcmNpc2U+KGAke3RoaXMucmVzb3VyY2VVcmx9L2ltcG9ydC8ke2FkYXB0ZWRTb3VyY2VQcm9ncmFtbWluZ0V4ZXJjaXNlLmlkfWAsIGV4ZXJjaXNlLCB7XG4gICAgICAgICAgICAgICAgcGFyYW1zOiBvcHRpb25zLFxuICAgICAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEVudGl0eVJlc3BvbnNlVHlwZSkgPT4gdGhpcy5wcm9jZXNzUHJvZ3JhbW1pbmdFeGVyY2lzZUVudGl0eVJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVcGRhdGVzIGFuIGV4aXN0aW5nIHByb2dyYW1taW5nIGV4ZXJjaXNlXG4gICAgICogQHBhcmFtIHByb2dyYW1taW5nRXhlcmNpc2Ugd2hpY2ggc2hvdWxkIGJlIHVwZGF0ZWRcbiAgICAgKiBAcGFyYW0gcmVxIG9wdGlvbmFsIHJlcXVlc3Qgb3B0aW9uc1xuICAgICAqL1xuICAgIHVwZGF0ZShwcm9ncmFtbWluZ0V4ZXJjaXNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlLCByZXE/OiBhbnkpOiBPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT4ge1xuICAgICAgICBjb25zdCBvcHRpb25zID0gY3JlYXRlUmVxdWVzdE9wdGlvbihyZXEpO1xuICAgICAgICBsZXQgY29weSA9IHRoaXMuY29udmVydERhdGFGcm9tQ2xpZW50KHByb2dyYW1taW5nRXhlcmNpc2UpO1xuICAgICAgICBjb3B5ID0gRXhlcmNpc2VTZXJ2aWNlLnNldEJvbnVzUG9pbnRzQ29uc3RyYWluZWRCeUluY2x1ZGVkSW5PdmVyYWxsU2NvcmUoY29weSk7XG4gICAgICAgIGNvcHkuY2F0ZWdvcmllcyA9IEV4ZXJjaXNlU2VydmljZS5zdHJpbmdpZnlFeGVyY2lzZUNhdGVnb3JpZXMoY29weSk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5wdXQ8UHJvZ3JhbW1pbmdFeGVyY2lzZT4odGhpcy5yZXNvdXJjZVVybCwgY29weSwgeyBwYXJhbXM6IG9wdGlvbnMsIG9ic2VydmU6ICdyZXNwb25zZScgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpID0+IHRoaXMucHJvY2Vzc1Byb2dyYW1taW5nRXhlcmNpc2VFbnRpdHlSZXNwb25zZShyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlcyB0aGUgdGltZWxpbmUgb2YgYSBwcm9ncmFtbWluZyBleGVyY2lzZVxuICAgICAqIEBwYXJhbSBwcm9ncmFtbWluZ0V4ZXJjaXNlIHRvIHVwZGF0ZVxuICAgICAqIEBwYXJhbSByZXEgb3B0aW9uYWwgcmVxdWVzdCBvcHRpb25zXG4gICAgICovXG4gICAgdXBkYXRlVGltZWxpbmUocHJvZ3JhbW1pbmdFeGVyY2lzZTogUHJvZ3JhbW1pbmdFeGVyY2lzZSwgcmVxPzogYW55KTogT2JzZXJ2YWJsZTxFbnRpdHlSZXNwb25zZVR5cGU+IHtcbiAgICAgICAgY29uc3Qgb3B0aW9ucyA9IGNyZWF0ZVJlcXVlc3RPcHRpb24ocmVxKTtcbiAgICAgICAgY29uc3QgY29weSA9IHRoaXMuY29udmVydERhdGFGcm9tQ2xpZW50KHByb2dyYW1taW5nRXhlcmNpc2UpO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAucHV0PFByb2dyYW1taW5nRXhlcmNpc2U+KGAke3RoaXMucmVzb3VyY2VVcmx9L3RpbWVsaW5lYCwgY29weSwgeyBwYXJhbXM6IG9wdGlvbnMsIG9ic2VydmU6ICdyZXNwb25zZScgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpID0+IHRoaXMucHJvY2Vzc1Byb2dyYW1taW5nRXhlcmNpc2VFbnRpdHlSZXNwb25zZShyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlcyB0aGUgcHJvYmxlbSBzdGF0ZW1lbnRcbiAgICAgKiBAcGFyYW0gcHJvZ3JhbW1pbmdFeGVyY2lzZUlkIG9mIHRoZSBwcm9ncmFtbWluZyBleGVyY2lzZSBmb3Igd2hpY2ggdG8gY2hhbmdlIHRoZSBwcm9ibGVtIHN0YXRlbWVudFxuICAgICAqIEBwYXJhbSBwcm9ibGVtU3RhdGVtZW50IHRoZSBuZXcgcHJvYmxlbSBzdGF0ZW1lbnRcbiAgICAgKiBAcGFyYW0gcmVxIG9wdGlvbmFsIHJlcXVlc3Qgb3B0aW9uc1xuICAgICAqL1xuICAgIHVwZGF0ZVByb2JsZW1TdGF0ZW1lbnQocHJvZ3JhbW1pbmdFeGVyY2lzZUlkOiBudW1iZXIsIHByb2JsZW1TdGF0ZW1lbnQ6IHN0cmluZywgcmVxPzogYW55KSB7XG4gICAgICAgIGNvbnN0IG9wdGlvbnMgPSBjcmVhdGVSZXF1ZXN0T3B0aW9uKHJlcSk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5wYXRjaDxQcm9ncmFtbWluZ0V4ZXJjaXNlPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke3Byb2dyYW1taW5nRXhlcmNpc2VJZH0vcHJvYmxlbS1zdGF0ZW1lbnRgLCBwcm9ibGVtU3RhdGVtZW50LCB7XG4gICAgICAgICAgICAgICAgcGFyYW1zOiBvcHRpb25zLFxuICAgICAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEVudGl0eVJlc3BvbnNlVHlwZSkgPT4gdGhpcy5wcm9jZXNzUHJvZ3JhbW1pbmdFeGVyY2lzZUVudGl0eVJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBGaW5kcyB0aGUgcHJvZ3JhbW1pbmcgZXhlcmNpc2UgZm9yIHRoZSBnaXZlbiBleGVyY2lzZUlkXG4gICAgICogQHBhcmFtIHByb2dyYW1taW5nRXhlcmNpc2VJZCBvZiB0aGUgcHJvZ3JhbW1pbmcgZXhlcmNpc2UgdG8gcmV0cmlldmVcbiAgICAgKiBAcGFyYW0gd2l0aFBsYWdpYXJpc21EZXRlY3Rpb25Db25maWcgdHJ1ZSBpZiBwbGFnaWFyaXNtIGRldGVjdGlvbiBjb250ZXh0IHNob3VsZCBiZSBmZXRjaGVkIHdpdGggdGhlIGV4ZXJjaXNlXG4gICAgICovXG4gICAgZmluZChwcm9ncmFtbWluZ0V4ZXJjaXNlSWQ6IG51bWJlciwgd2l0aFBsYWdpYXJpc21EZXRlY3Rpb25Db25maWc6IGJvb2xlYW4gPSBmYWxzZSk6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5nZXQ8UHJvZ3JhbW1pbmdFeGVyY2lzZT4oYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtwcm9ncmFtbWluZ0V4ZXJjaXNlSWR9YCwge1xuICAgICAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7IHdpdGhQbGFnaWFyaXNtRGV0ZWN0aW9uQ29uZmlnOiB3aXRoUGxhZ2lhcmlzbURldGVjdGlvbkNvbmZpZyB9LFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpID0+IHRoaXMucHJvY2Vzc1Byb2dyYW1taW5nRXhlcmNpc2VFbnRpdHlSZXNwb25zZShyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRmluZHMgdGhlIHByb2dyYW1taW5nIGV4ZXJjaXNlIGZvciB0aGUgZ2l2ZW4gZXhlcmNpc2VJZCB3aXRoIHRoZSBjb3JyZXNwb25kaW5nIHBhcnRpY2lwYXRpb24ncyB3aXRoIHJlc3VsdHNcbiAgICAgKiBAcGFyYW0gcHJvZ3JhbW1pbmdFeGVyY2lzZUlkIG9mIHRoZSBwcm9ncmFtbWluZyBleGVyY2lzZSB0byByZXRyaWV2ZVxuICAgICAqL1xuICAgIGZpbmRXaXRoVGVtcGxhdGVBbmRTb2x1dGlvblBhcnRpY2lwYXRpb25BbmRSZXN1bHRzKHByb2dyYW1taW5nRXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxFbnRpdHlSZXNwb25zZVR5cGU+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLmdldDxQcm9ncmFtbWluZ0V4ZXJjaXNlPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke3Byb2dyYW1taW5nRXhlcmNpc2VJZH0vd2l0aC1wYXJ0aWNpcGF0aW9uc2AsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEVudGl0eVJlc3BvbnNlVHlwZSkgPT4gdGhpcy5wcm9jZXNzUHJvZ3JhbW1pbmdFeGVyY2lzZUVudGl0eVJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBGaW5kcyB0aGUgcHJvZ3JhbW1pbmcgZXhlcmNpc2UgZm9yIHRoZSBnaXZlbiBleGVyY2lzZUlkIHdpdGggdGhlIHRlbXBsYXRlIGFuZCBzb2x1dGlvbiBwYXJ0aWNpcGF0aW9uXG4gICAgICogQHBhcmFtIHByb2dyYW1taW5nRXhlcmNpc2VJZCBvZiB0aGUgcHJvZ3JhbW1pbmcgZXhlcmNpc2UgdG8gcmV0cmlldmVcbiAgICAgKiBAcGFyYW0gd2l0aFN1Ym1pc3Npb25SZXN1bHRzIGdldCByZXN1bHRzIGF0dGFjaGVkIHRvIHN1Ym1pc3Npb25zXG4gICAgICovXG4gICAgZmluZFdpdGhUZW1wbGF0ZUFuZFNvbHV0aW9uUGFydGljaXBhdGlvbihwcm9ncmFtbWluZ0V4ZXJjaXNlSWQ6IG51bWJlciwgd2l0aFN1Ym1pc3Npb25SZXN1bHRzID0gZmFsc2UpOiBPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT4ge1xuICAgICAgICBsZXQgcGFyYW1zID0gbmV3IEh0dHBQYXJhbXMoKTtcbiAgICAgICAgcGFyYW1zID0gcGFyYW1zLnNldCgnd2l0aFN1Ym1pc3Npb25SZXN1bHRzJywgd2l0aFN1Ym1pc3Npb25SZXN1bHRzLnRvU3RyaW5nKCkpO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAuZ2V0PFByb2dyYW1taW5nRXhlcmNpc2U+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7cHJvZ3JhbW1pbmdFeGVyY2lzZUlkfS93aXRoLXRlbXBsYXRlLWFuZC1zb2x1dGlvbi1wYXJ0aWNpcGF0aW9uYCwge1xuICAgICAgICAgICAgICAgIHBhcmFtcyxcbiAgICAgICAgICAgICAgICBvYnNlcnZlOiAncmVzcG9uc2UnLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIG1hcCgocmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5ib2R5ICYmIHdpdGhTdWJtaXNzaW9uUmVzdWx0cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gV2UgbmVlZCB0byByZWNvbm5lY3QgdGhlIHN1Ym1pc3Npb25zIHdpdGggdGhlIHJlc3VsdHMuIFRoZXkgZ290IHJlbW92ZWQgYmVjYXVzZSBvZiB0aGUgY2lyY3VsYXIgZGVwZW5kZW5jeVxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGVtcGxhdGVTdWJtaXNzaW9ucyA9IHJlcy5ib2R5LnRlbXBsYXRlUGFydGljaXBhdGlvbj8uc3VibWlzc2lvbnM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlY29ubmVjdFN1Ym1pc3Npb25BbmRSZXN1bHQodGVtcGxhdGVTdWJtaXNzaW9ucyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzb2x1dGlvblN1Ym1pc3Npb25zID0gcmVzLmJvZHkuc29sdXRpb25QYXJ0aWNpcGF0aW9uPy5zdWJtaXNzaW9ucztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVjb25uZWN0U3VibWlzc2lvbkFuZFJlc3VsdChzb2x1dGlvblN1Ym1pc3Npb25zKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5wcm9jZXNzUHJvZ3JhbW1pbmdFeGVyY2lzZUVudGl0eVJlc3BvbnNlKHJlcyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlcztcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRmluZHMgdGhlIHByb2dyYW1taW5nIGV4ZXJjaXNlIGZvciB0aGUgZ2l2ZW4gZXhlcmNpc2VJZCB3aXRoIHRoZSB0ZW1wbGF0ZSBhbmQgc29sdXRpb24gcGFydGljaXBhdGlvbiBhbmQgdGhlaXIgbGF0ZXN0IHJlc3VsdCBlYWNoLlxuICAgICAqIEBwYXJhbSBwcm9ncmFtbWluZ0V4ZXJjaXNlSWQgb2YgdGhlIHByb2dyYW1taW5nIGV4ZXJjaXNlIHRvIHJldHJpZXZlXG4gICAgICovXG4gICAgZmluZFdpdGhUZW1wbGF0ZUFuZFNvbHV0aW9uUGFydGljaXBhdGlvbkFuZExhdGVzdFJlc3VsdHMocHJvZ3JhbW1pbmdFeGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5maW5kV2l0aFRlbXBsYXRlQW5kU29sdXRpb25QYXJ0aWNpcGF0aW9uKHByb2dyYW1taW5nRXhlcmNpc2VJZCwgdHJ1ZSkucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuYm9keSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNldExhdGVzdFJlc3VsdEZvclRlbXBsYXRlQW5kU29sdXRpb24ocmVzcG9uc2UuYm9keSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHByaXZhdGUgc2V0TGF0ZXN0UmVzdWx0Rm9yVGVtcGxhdGVBbmRTb2x1dGlvbihwcm9ncmFtbWluZ0V4ZXJjaXNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlKSB7XG4gICAgICAgIGlmIChwcm9ncmFtbWluZ0V4ZXJjaXNlLnRlbXBsYXRlUGFydGljaXBhdGlvbikge1xuICAgICAgICAgICAgY29uc3QgbGF0ZXN0VGVtcGxhdGVSZXN1bHQgPSB0aGlzLmdldExhdGVzdFJlc3VsdChwcm9ncmFtbWluZ0V4ZXJjaXNlLnRlbXBsYXRlUGFydGljaXBhdGlvbik7XG4gICAgICAgICAgICBpZiAobGF0ZXN0VGVtcGxhdGVSZXN1bHQpIHtcbiAgICAgICAgICAgICAgICBwcm9ncmFtbWluZ0V4ZXJjaXNlLnRlbXBsYXRlUGFydGljaXBhdGlvbi5yZXN1bHRzID0gW2xhdGVzdFRlbXBsYXRlUmVzdWx0XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFRoaXMgaXMgbmVlZGVkIHRvIGFjY2VzcyB0aGUgZXhlcmNpc2UgaW4gdGhlIHJlc3VsdCBkZXRhaWxzXG4gICAgICAgICAgICBwcm9ncmFtbWluZ0V4ZXJjaXNlLnRlbXBsYXRlUGFydGljaXBhdGlvbi5wcm9ncmFtbWluZ0V4ZXJjaXNlID0gcHJvZ3JhbW1pbmdFeGVyY2lzZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChwcm9ncmFtbWluZ0V4ZXJjaXNlLnNvbHV0aW9uUGFydGljaXBhdGlvbikge1xuICAgICAgICAgICAgY29uc3QgbGF0ZXN0U29sdXRpb25SZXN1bHQgPSB0aGlzLmdldExhdGVzdFJlc3VsdChwcm9ncmFtbWluZ0V4ZXJjaXNlLnNvbHV0aW9uUGFydGljaXBhdGlvbik7XG4gICAgICAgICAgICBpZiAobGF0ZXN0U29sdXRpb25SZXN1bHQpIHtcbiAgICAgICAgICAgICAgICBwcm9ncmFtbWluZ0V4ZXJjaXNlLnNvbHV0aW9uUGFydGljaXBhdGlvbi5yZXN1bHRzID0gW2xhdGVzdFNvbHV0aW9uUmVzdWx0XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFRoaXMgaXMgbmVlZGVkIHRvIGFjY2VzcyB0aGUgZXhlcmNpc2UgaW4gdGhlIHJlc3VsdCBkZXRhaWxzXG4gICAgICAgICAgICBwcm9ncmFtbWluZ0V4ZXJjaXNlLnNvbHV0aW9uUGFydGljaXBhdGlvbi5wcm9ncmFtbWluZ0V4ZXJjaXNlID0gcHJvZ3JhbW1pbmdFeGVyY2lzZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEZpbmRzIHRoZSByZXN1bHQgdGhhdCBoYXMgdGhlIGxhdGVzdCBzdWJtaXNzaW9uIGRhdGUuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gcGFydGljaXBhdGlvbiBTb21lIHBhcnRpY2lwYXRpb24uXG4gICAgICovXG4gICAgZ2V0TGF0ZXN0UmVzdWx0KHBhcnRpY2lwYXRpb246IFBhcnRpY2lwYXRpb24pOiBSZXN1bHQgfCB1bmRlZmluZWQge1xuICAgICAgICBjb25zdCBzdWJtaXNzaW9ucyA9IHBhcnRpY2lwYXRpb24uc3VibWlzc2lvbnM7XG4gICAgICAgIGlmICghc3VibWlzc2lvbnMgfHwgc3VibWlzc2lvbnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBpbXBvcnRhbnQ6IHNvcnQgdG8gZ2V0IHRoZSBsYXRlc3Qgc3VibWlzc2lvbiAodGhlIG9yZGVyIG9mIHRoZSBzZXJ2ZXIgY2FuIGJlIHJhbmRvbSlcbiAgICAgICAgdGhpcy5zb3J0U2VydmljZS5zb3J0QnlQcm9wZXJ0eShzdWJtaXNzaW9ucywgJ3N1Ym1pc3Npb25EYXRlJywgdHJ1ZSk7XG4gICAgICAgIGNvbnN0IHJlc3VsdHMgPSBzdWJtaXNzaW9ucy5zb3J0KCkubGFzdCgpPy5yZXN1bHRzO1xuICAgICAgICBpZiAocmVzdWx0cyAmJiByZXN1bHRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiByZXN1bHRzLmxhc3QoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlY29ubmVjdGluZyB0aGUgbWlzc2luZyBzdWJtaXNzaW9uIG9mIGEgc3VibWlzc2lvbidzIHJlc3VsdFxuICAgICAqXG4gICAgICogQHBhcmFtIHN1Ym1pc3Npb25zIHdoZXJlIHRoZSByZXN1bHRzIGhhdmUgbm8gcmVmZXJlbmNlIHRvIGl0cyBzdWJtaXNzaW9uXG4gICAgICovXG4gICAgcHJpdmF0ZSByZWNvbm5lY3RTdWJtaXNzaW9uQW5kUmVzdWx0KHN1Ym1pc3Npb25zOiBTdWJtaXNzaW9uW10gfCB1bmRlZmluZWQpIHtcbiAgICAgICAgaWYgKHN1Ym1pc3Npb25zKSB7XG4gICAgICAgICAgICBzdWJtaXNzaW9ucy5mb3JFYWNoKChzdWJtaXNzaW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHN1Ym1pc3Npb24ucmVzdWx0cykge1xuICAgICAgICAgICAgICAgICAgICBzdWJtaXNzaW9uLnJlc3VsdHMuZm9yRWFjaCgocmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQuc3VibWlzc2lvbiA9IHN1Ym1pc3Npb247XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhbiBlbnRpdHkgd2l0aCB0cnVlIGluIHRoZSBib2R5IGlmIHRoZXJlIGlzIGEgcHJvZ3JhbW1pbmcgZXhlcmNpc2Ugd2l0aCB0aGUgZ2l2ZW4gaWQsIGl0IGlzIHJlbGVhc2VkIChyZWxlYXNlIGRhdGUgPCBub3cpIGFuZCB0aGVyZSBpcyBhdCBsZWFzdCBvbmUgc3R1ZGVudCByZXN1bHQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCBQcm9ncmFtbWluZ0V4ZXJjaXNlIGlkXG4gICAgICovXG4gICAgZ2V0UHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlU3RhdGUoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8UHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlU3RhdGVEVE8+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFByb2dyYW1taW5nRXhlcmNpc2VUZXN0Q2FzZVN0YXRlRFRPPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L3Rlc3QtY2FzZS1zdGF0ZWAsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZWNlaXZlcyBhbGwgcHJvZ3JhbW1pbmcgZXhlcmNpc2VzIGZvciB0aGUgcGFydGljdWxhciBxdWVyeVxuICAgICAqIEBwYXJhbSByZXEgb3B0aW9uYWwgcmVxdWVzdCBvcHRpb25zXG4gICAgICovXG4gICAgcXVlcnkocmVxPzogYW55KTogT2JzZXJ2YWJsZTxFbnRpdHlBcnJheVJlc3BvbnNlVHlwZT4ge1xuICAgICAgICBjb25zdCBvcHRpb25zID0gY3JlYXRlUmVxdWVzdE9wdGlvbihyZXEpO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAuZ2V0PFByb2dyYW1taW5nRXhlcmNpc2VbXT4odGhpcy5yZXNvdXJjZVVybCwgeyBwYXJhbXM6IG9wdGlvbnMsIG9ic2VydmU6ICdyZXNwb25zZScgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBFbnRpdHlBcnJheVJlc3BvbnNlVHlwZSkgPT4gdGhpcy5leGVyY2lzZVNlcnZpY2UucHJvY2Vzc0V4ZXJjaXNlRW50aXR5QXJyYXlSZXNwb25zZShyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGVsZXRlcyB0aGUgcHJvZ3JhbW1pbmcgZXhlcmNpc2Ugd2l0aCB0aGUgY29ycmVzcG9uZGluZyBwcm9ncmFtbWluZyBleGVyY2lzZSBJZFxuICAgICAqIEBwYXJhbSBwcm9ncmFtbWluZ0V4ZXJjaXNlSWQgb2YgdGhlIHByb2dyYW1taW5nIGV4ZXJjaXNlIHRvIGRlbGV0ZVxuICAgICAqIEBwYXJhbSBkZWxldGVTdHVkZW50UmVwb3NCdWlsZFBsYW5zIGluZGljYXRlcyBpZiB0aGUgU3R1ZGVudFJlcG9zQnVpbGRQbGFucyBzaG91bGQgYmUgYWxzbyBkZWxldGVkIG9yIG5vdFxuICAgICAqIEBwYXJhbSBkZWxldGVCYXNlUmVwb3NCdWlsZFBsYW5zIGluZGljYXRlcyBpZiB0aGUgQmFzZVJlcG9zQnVpbGRQbGFucyBzaG91bGQgYmUgYWxzbyBkZWxldGVkIG9yIG5vdFxuICAgICAqL1xuICAgIGRlbGV0ZShwcm9ncmFtbWluZ0V4ZXJjaXNlSWQ6IG51bWJlciwgZGVsZXRlU3R1ZGVudFJlcG9zQnVpbGRQbGFuczogYm9vbGVhbiwgZGVsZXRlQmFzZVJlcG9zQnVpbGRQbGFuczogYm9vbGVhbik6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPGFueT4+IHtcbiAgICAgICAgbGV0IHBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKCk7XG4gICAgICAgIHBhcmFtcyA9IHBhcmFtcy5zZXQoJ2RlbGV0ZVN0dWRlbnRSZXBvc0J1aWxkUGxhbnMnLCBkZWxldGVTdHVkZW50UmVwb3NCdWlsZFBsYW5zLnRvU3RyaW5nKCkpO1xuICAgICAgICBwYXJhbXMgPSBwYXJhbXMuc2V0KCdkZWxldGVCYXNlUmVwb3NCdWlsZFBsYW5zJywgZGVsZXRlQmFzZVJlcG9zQnVpbGRQbGFucy50b1N0cmluZygpKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5kZWxldGUoYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtwcm9ncmFtbWluZ0V4ZXJjaXNlSWR9YCwgeyBwYXJhbXMsIG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ29udmVydHMgdGhlIGRhdGEgZnJvbSB0aGUgY2xpZW50XG4gICAgICogaWYgdGVtcGxhdGUgJiBzb2x1dGlvbiBwYXJ0aWNpcGF0aW9uIGV4aXN0IHJlbW92ZXMgdGhlIGV4ZXJjaXNlIGFuZCByZXN1bHRzIGZyb20gdGhlbVxuICAgICAqIEBwYXJhbSBleGVyY2lzZSBmb3Igd2hpY2ggdGhlIGRhdGEgc2hvdWxkIGJlIGNvbnZlcnRlZFxuICAgICAqL1xuICAgIGNvbnZlcnREYXRhRnJvbUNsaWVudChleGVyY2lzZTogUHJvZ3JhbW1pbmdFeGVyY2lzZSkge1xuICAgICAgICBjb25zdCBjb3B5ID0ge1xuICAgICAgICAgICAgLi4uRXhlcmNpc2VTZXJ2aWNlLmNvbnZlcnRFeGVyY2lzZURhdGVzRnJvbUNsaWVudChleGVyY2lzZSksXG4gICAgICAgICAgICBidWlsZEFuZFRlc3RTdHVkZW50U3VibWlzc2lvbnNBZnRlckR1ZURhdGU6IGNvbnZlcnREYXRlRnJvbUNsaWVudChleGVyY2lzZS5idWlsZEFuZFRlc3RTdHVkZW50U3VibWlzc2lvbnNBZnRlckR1ZURhdGUpLFxuICAgICAgICB9O1xuICAgICAgICAvLyBSZW1vdmUgZXhlcmNpc2UgZnJvbSB0ZW1wbGF0ZSAmIHNvbHV0aW9uIHBhcnRpY2lwYXRpb24gdG8gYXZvaWQgY2lyY3VsYXIgZGVwZW5kZW5jeSBpc3N1ZXMuXG4gICAgICAgIC8vIEFsc28gcmVtb3ZlIHRoZSByZXN1bHRzLCBhcyB0aGV5IGNhbiBoYXZlIGNpcmN1bGFyIHN0cnVjdHVyZXMgYXMgd2VsbCBhbmQgZG9uJ3QgaGF2ZSB0byBiZSBzYXZlZCBoZXJlLlxuICAgICAgICBpZiAoY29weS50ZW1wbGF0ZVBhcnRpY2lwYXRpb24pIHtcbiAgICAgICAgICAgIGNvcHkudGVtcGxhdGVQYXJ0aWNpcGF0aW9uID0gX29taXQoY29weS50ZW1wbGF0ZVBhcnRpY2lwYXRpb24sIFsnZXhlcmNpc2UnLCAncmVzdWx0cyddKSBhcyBUZW1wbGF0ZVByb2dyYW1taW5nRXhlcmNpc2VQYXJ0aWNpcGF0aW9uO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjb3B5LnNvbHV0aW9uUGFydGljaXBhdGlvbikge1xuICAgICAgICAgICAgY29weS5zb2x1dGlvblBhcnRpY2lwYXRpb24gPSBfb21pdChjb3B5LnNvbHV0aW9uUGFydGljaXBhdGlvbiwgWydleGVyY2lzZScsICdyZXN1bHRzJ10pIGFzIFNvbHV0aW9uUHJvZ3JhbW1pbmdFeGVyY2lzZVBhcnRpY2lwYXRpb247XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gY29weSBhcyBQcm9ncmFtbWluZ0V4ZXJjaXNlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENvbnZlcnQgYWxsIGRhdGUgZmllbGRzIG9mIHRoZSBwcm9ncmFtbWluZyBleGVyY2lzZSB0byBkYXlqcyBkYXRlIG9iamVjdHMuXG4gICAgICogTm90ZTogVGhpcyBjb252ZXJzaW9uIGNvdWxkIHByb2R1Y2UgYW4gaW52YWxpZCBkYXRlIGlmIHRoZSBkYXRlIGlzIG1hbGZvcm1hdHRlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBlbnRpdHkgUHJvZ3JhbW1pbmdFeGVyY2lzZVxuICAgICAqL1xuICAgIHN0YXRpYyBjb252ZXJ0UHJvZ3JhbW1pbmdFeGVyY2lzZVJlc3BvbnNlRGF0ZXNGcm9tU2VydmVyKGVudGl0eTogRW50aXR5UmVzcG9uc2VUeXBlKSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IEV4ZXJjaXNlU2VydmljZS5jb252ZXJ0RXhlcmNpc2VSZXNwb25zZURhdGVzRnJvbVNlcnZlcihlbnRpdHkpO1xuICAgICAgICBpZiAoIXJlcy5ib2R5KSB7XG4gICAgICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgICB9XG4gICAgICAgIHJlcy5ib2R5LmJ1aWxkQW5kVGVzdFN0dWRlbnRTdWJtaXNzaW9uc0FmdGVyRHVlRGF0ZSA9IGNvbnZlcnREYXRlRnJvbVNlcnZlcihyZXMuYm9keS5idWlsZEFuZFRlc3RTdHVkZW50U3VibWlzc2lvbnNBZnRlckR1ZURhdGUpO1xuICAgICAgICByZXR1cm4gcmVzO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVubG9jayBhbGwgdGhlIHN0dWRlbnQgcmVwb3NpdG9yaWVzIG9mIHRoZSBnaXZlbiBleGVyY2lzZSBzbyB0aGF0IHN0dWRlbnQgY2FuIHBlcmZvcm0gY29tbWl0c1xuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkIG9mIHRoZSBwYXJ0aWN1bGFyIHByb2dyYW1taW5nIGV4ZXJjaXNlXG4gICAgICovXG4gICAgdW5sb2NrQWxsUmVwb3NpdG9yaWVzKGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPGFueT4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8YW55PihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L3VubG9jay1hbGwtcmVwb3NpdG9yaWVzYCwge30sIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBMb2NrIGFsbCB0aGUgc3R1ZGVudCByZXBvc2l0b3JpZXMgb2YgdGhlIGdpdmVuIGV4ZXJjaXNlIHNvIHRoYXQgc3R1ZGVudCBjYW4gcGVyZm9ybSBjb21taXRzXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlSWQgb2YgdGhlIHBhcnRpY3VsYXIgcHJvZ3JhbW1pbmcgZXhlcmNpc2VcbiAgICAgKi9cbiAgICBsb2NrQWxsUmVwb3NpdG9yaWVzKGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPGFueT4+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8YW55PihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L2xvY2stYWxsLXJlcG9zaXRvcmllc2AsIHt9LCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRXhwb3J0cyB0aGUgc29sdXRpb24sIHRlbXBsYXRlIG9yIHRlc3QgcmVwb3NpdG9yeSBmb3IgYSBnaXZlbiBleGVyY2lzZS5cbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZFxuICAgICAqIEBwYXJhbSByZXBvc2l0b3J5VHlwZVxuICAgICAqIEBwYXJhbSBhdXhpbGlhcnlSZXBvc2l0b3J5SWRcbiAgICAgKi9cbiAgICBleHBvcnRJbnN0cnVjdG9yUmVwb3NpdG9yeShcbiAgICAgICAgZXhlcmNpc2VJZDogbnVtYmVyLFxuICAgICAgICByZXBvc2l0b3J5VHlwZTogUHJvZ3JhbW1pbmdFeGVyY2lzZUluc3RydWN0b3JSZXBvc2l0b3J5VHlwZSxcbiAgICAgICAgYXV4aWxpYXJ5UmVwb3NpdG9yeUlkOiBudW1iZXIgfCB1bmRlZmluZWQsXG4gICAgKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8QmxvYj4+IHtcbiAgICAgICAgaWYgKHJlcG9zaXRvcnlUeXBlID09PSAnQVVYSUxJQVJZJyAmJiBhdXhpbGlhcnlSZXBvc2l0b3J5SWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQoYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtleGVyY2lzZUlkfS9leHBvcnQtaW5zdHJ1Y3Rvci1hdXhpbGlhcnktcmVwb3NpdG9yeS8ke2F1eGlsaWFyeVJlcG9zaXRvcnlJZH1gLCB7XG4gICAgICAgICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyxcbiAgICAgICAgICAgICAgICByZXNwb25zZVR5cGU6ICdibG9iJyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQoYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtleGVyY2lzZUlkfS9leHBvcnQtaW5zdHJ1Y3Rvci1yZXBvc2l0b3J5LyR7cmVwb3NpdG9yeVR5cGV9YCwge1xuICAgICAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICAgICAgcmVzcG9uc2VUeXBlOiAnYmxvYicsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEV4cG9ydHMgYWxsIGluc3RydWN0b3IgcmVwb3NpdG9yaWVzIChzb2x1dGlvbiwgdGVtcGxhdGUsIHRlc3QpLCB0aGUgcHJvYmxlbSBzdGF0ZW1lbnQgYW5kIHRoZSBleGVyY2lzZSBkZXRhaWxzLlxuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkXG4gICAgICovXG4gICAgZXhwb3J0SW5zdHJ1Y3RvckV4ZXJjaXNlKGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPEJsb2I+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7ZXhlcmNpc2VJZH0vZXhwb3J0LWluc3RydWN0b3ItZXhlcmNpc2VgLCB7XG4gICAgICAgICAgICBvYnNlcnZlOiAncmVzcG9uc2UnLFxuICAgICAgICAgICAgcmVzcG9uc2VUeXBlOiAnYmxvYicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEV4cG9ydHMgdGhlIGV4YW1wbGUgc29sdXRpb24gcmVwb3NpdG9yeSBmb3IgYSBnaXZlbiBleGVyY2lzZSwgc3VpdGFibGUgZm9yIGRpc3RyaWJ1dGluZyB0byBzdHVkZW50cy5cbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZFxuICAgICAqIEBwYXJhbSBpbmNsdWRlVGVzdHMgZmxhZyB0aGF0IGluZGljYXRlcyB3aGV0aGVyIHRoZSB0ZXN0cyBzaG91bGQgYWxzbyBiZSBleHBvcnRlZFxuICAgICAqL1xuICAgIGV4cG9ydFN0dWRlbnRSZXF1ZXN0ZWRSZXBvc2l0b3J5KGV4ZXJjaXNlSWQ6IG51bWJlciwgaW5jbHVkZVRlc3RzOiBib29sZWFuKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8QmxvYj4+IHtcbiAgICAgICAgbGV0IHBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKCk7XG4gICAgICAgIHBhcmFtcyA9IHBhcmFtcy5zZXQoJ2luY2x1ZGVUZXN0cycsIGluY2x1ZGVUZXN0cy50b1N0cmluZygpKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQoYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtleGVyY2lzZUlkfS9leHBvcnQtc3R1ZGVudC1yZXF1ZXN0ZWQtcmVwb3NpdG9yeWAsIHtcbiAgICAgICAgICAgIHBhcmFtcyxcbiAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICByZXNwb25zZVR5cGU6ICdibG9iJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmUtZXZhbHVhdGVzIGFuZCB1cGRhdGVzIGFuIGV4aXN0aW5nIHByb2dyYW1taW5nIGV4ZXJjaXNlLlxuICAgICAqXG4gICAgICogQHBhcmFtIHByb2dyYW1taW5nRXhlcmNpc2UgdGhhdCBzaG91bGQgYmUgdXBkYXRlZCBvZiB0eXBlIHtQcm9ncmFtbWluZ0V4ZXJjaXNlfVxuICAgICAqIEBwYXJhbSByZXEgb3B0aW9uYWwgcmVxdWVzdCBvcHRpb25zXG4gICAgICovXG4gICAgcmVldmFsdWF0ZUFuZFVwZGF0ZShwcm9ncmFtbWluZ0V4ZXJjaXNlOiBQcm9ncmFtbWluZ0V4ZXJjaXNlLCByZXE/OiBhbnkpOiBPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT4ge1xuICAgICAgICBjb25zdCBvcHRpb25zID0gY3JlYXRlUmVxdWVzdE9wdGlvbihyZXEpO1xuICAgICAgICBsZXQgY29weSA9IHRoaXMuY29udmVydERhdGFGcm9tQ2xpZW50KHByb2dyYW1taW5nRXhlcmNpc2UpO1xuICAgICAgICBjb3B5ID0gRXhlcmNpc2VTZXJ2aWNlLnNldEJvbnVzUG9pbnRzQ29uc3RyYWluZWRCeUluY2x1ZGVkSW5PdmVyYWxsU2NvcmUoY29weSk7XG4gICAgICAgIGNvcHkuY2F0ZWdvcmllcyA9IEV4ZXJjaXNlU2VydmljZS5zdHJpbmdpZnlFeGVyY2lzZUNhdGVnb3JpZXMoY29weSk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5wdXQ8UHJvZ3JhbW1pbmdFeGVyY2lzZT4oYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtwcm9ncmFtbWluZ0V4ZXJjaXNlLmlkfS9yZS1ldmFsdWF0ZWAsIGNvcHksIHtcbiAgICAgICAgICAgICAgICBwYXJhbXM6IG9wdGlvbnMsXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlczogRW50aXR5UmVzcG9uc2VUeXBlKSA9PiB0aGlzLmV4ZXJjaXNlU2VydmljZS5wcm9jZXNzRXhlcmNpc2VFbnRpdHlSZXNwb25zZShyZXMpKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVGhpcyBtZXRob2QgYnVuZGxlcyByZWN1cnJpbmcgY29udmVyc2lvbiBzdGVwcyBmb3IgUHJvZ3JhbW1pbmdFeGVyY2lzZSBFbnRpdHlSZXNwb25zZXMuXG4gICAgICpcbiAgICAgKiBOT1RFOiBUaGlzIG1ldGhvZCBpcyB1c2VkIGluc3RlYWQgb2Yge0BsaW5rIGV4ZXJjaXNlU2VydmljZS5wcm9jZXNzRXhlcmNpc2VFbnRpdHlSZXNwb25zZX0gZHVlIHRvIHRoZVxuICAgICAqICAgICAgIGRpZmZlcmVudCBoYW5kbGluZyBvZiB0aGUgZGF0ZSBjb252ZXJzaW9uXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlUmVzXG4gICAgICovXG4gICAgcHJpdmF0ZSBwcm9jZXNzUHJvZ3JhbW1pbmdFeGVyY2lzZUVudGl0eVJlc3BvbnNlKGV4ZXJjaXNlUmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpOiBFbnRpdHlSZXNwb25zZVR5cGUge1xuICAgICAgICBQcm9ncmFtbWluZ0V4ZXJjaXNlU2VydmljZS5jb252ZXJ0UHJvZ3JhbW1pbmdFeGVyY2lzZVJlc3BvbnNlRGF0ZXNGcm9tU2VydmVyKGV4ZXJjaXNlUmVzKTtcbiAgICAgICAgRXhlcmNpc2VTZXJ2aWNlLmNvbnZlcnRFeGVyY2lzZUNhdGVnb3JpZXNGcm9tU2VydmVyKGV4ZXJjaXNlUmVzKTtcbiAgICAgICAgdGhpcy5leGVyY2lzZVNlcnZpY2Uuc2V0QWNjZXNzUmlnaHRzRXhlcmNpc2VFbnRpdHlSZXNwb25zZVR5cGUoZXhlcmNpc2VSZXMpO1xuICAgICAgICB0aGlzLmV4ZXJjaXNlU2VydmljZS5zZW5kRXhlcmNpc2VUaXRsZVRvVGl0bGVTZXJ2aWNlKGV4ZXJjaXNlUmVzPy5ib2R5KTtcbiAgICAgICAgcmV0dXJuIGV4ZXJjaXNlUmVzO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCB0YXNrcyBhbmQgdGVzdHMgY2FzZXMgZXh0cmFjdGVkIGZyb20gdGhlIHByb2JsZW0gc3RhdGVtZW50IGZvciBhIHByb2dyYW1taW5nIGV4ZXJjaXNlLlxuICAgICAqIFRoaXMgbWV0aG9kIGFuZCBhbGwgaGVscGVyIG1ldGhvZHMgYXJlIG9ubHkgZm9yIHRlc3RpbmcgcmVhc29uIGFuZCB3aWxsIGJlIHJlbW92ZWQgbGF0ZXIgb24uXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlSWQgdGhlIGV4ZXJjaXNlIGlkXG4gICAgICovXG4gICAgZ2V0VGFza3NBbmRUZXN0c0V4dHJhY3RlZEZyb21Qcm9ibGVtU3RhdGVtZW50KGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8UHJvZ3JhbW1pbmdFeGVyY2lzZVNlcnZlclNpZGVUYXNrW10+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLmdldChgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L3Rhc2tzYCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlczogSHR0cFJlc3BvbnNlPFByb2dyYW1taW5nRXhlcmNpc2VTZXJ2ZXJTaWRlVGFza1tdPikgPT4gcmVzLmJvZHkgPz8gW10pKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXRzIHRoZSBnaXQtZGlmZiByZXBvcnQgb2YgYSBwcm9ncmFtbWluZyBleGVyY2lzZVxuICAgICAqXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlSWQgVGhlIGlkIG9mIGEgcHJvZ3JhbW1pbmcgZXhlcmNpc2VcbiAgICAgKi9cbiAgICBnZXREaWZmUmVwb3J0KGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8UHJvZ3JhbW1pbmdFeGVyY2lzZUdpdERpZmZSZXBvcnQgfCB1bmRlZmluZWQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLmdldDxQcm9ncmFtbWluZ0V4ZXJjaXNlR2l0RGlmZlJlcG9ydD4oYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtleGVyY2lzZUlkfS9kaWZmLXJlcG9ydGAsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEh0dHBSZXNwb25zZTxQcm9ncmFtbWluZ0V4ZXJjaXNlR2l0RGlmZlJlcG9ydD4pID0+IHJlcy5ib2R5ID8/IHVuZGVmaW5lZCkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldHMgdGhlIGdpdC1kaWZmIHJlcG9ydCBvZiBhIHByb2dyYW1taW5nIGV4ZXJjaXNlIGZvciB0d28gc3BlY2lmaWMgc3VibWlzc2lvbnNcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCBUaGUgaWQgb2YgYSBwcm9ncmFtbWluZyBleGVyY2lzZVxuICAgICAqIEBwYXJhbSBvbGRlclN1Ym1pc3Npb25JZCBUaGUgaWQgb2YgdGhlIG9sZGVyIHN1Ym1pc3Npb25cbiAgICAgKiBAcGFyYW0gbmV3ZXJTdWJtaXNzaW9uSWQgVGhlIGlkIG9mIHRoZSBuZXdlciBzdWJtaXNzaW9uXG4gICAgICovXG4gICAgZ2V0RGlmZlJlcG9ydEZvclN1Ym1pc3Npb25zKGV4ZXJjaXNlSWQ6IG51bWJlciwgb2xkZXJTdWJtaXNzaW9uSWQ6IG51bWJlciwgbmV3ZXJTdWJtaXNzaW9uSWQ6IG51bWJlcik6IE9ic2VydmFibGU8UHJvZ3JhbW1pbmdFeGVyY2lzZUdpdERpZmZSZXBvcnQgfCB1bmRlZmluZWQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLmdldDxQcm9ncmFtbWluZ0V4ZXJjaXNlR2l0RGlmZlJlcG9ydD4oYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtleGVyY2lzZUlkfS9zdWJtaXNzaW9ucy8ke29sZGVyU3VibWlzc2lvbklkfS9kaWZmLXJlcG9ydC8ke25ld2VyU3VibWlzc2lvbklkfWAsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEh0dHBSZXNwb25zZTxQcm9ncmFtbWluZ0V4ZXJjaXNlR2l0RGlmZlJlcG9ydD4pID0+IHJlcy5ib2R5ID8/IHVuZGVmaW5lZCkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldHMgdGhlIGdpdC1kaWZmIHJlcG9ydCBvZiBhIHByb2dyYW1taW5nIGV4ZXJjaXNlIGZvciBhIHNwZWNpZmljIHN1Ym1pc3Npb24gd2l0aCB0aGUgdGVtcGxhdGVcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCBUaGUgaWQgb2YgYSBwcm9ncmFtbWluZyBleGVyY2lzZVxuICAgICAqIEBwYXJhbSBzdWJtaXNzaW9uSWQgVGhlIGlkIG9mIGEgc3VibWlzc2lvblxuICAgICAqL1xuICAgIGdldERpZmZSZXBvcnRGb3JTdWJtaXNzaW9uV2l0aFRlbXBsYXRlKGV4ZXJjaXNlSWQ6IG51bWJlciwgc3VibWlzc2lvbklkOiBudW1iZXIpOiBPYnNlcnZhYmxlPFByb2dyYW1taW5nRXhlcmNpc2VHaXREaWZmUmVwb3J0IHwgdW5kZWZpbmVkPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5nZXQ8UHJvZ3JhbW1pbmdFeGVyY2lzZUdpdERpZmZSZXBvcnQ+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7ZXhlcmNpc2VJZH0vc3VibWlzc2lvbnMvJHtzdWJtaXNzaW9uSWR9L2RpZmYtcmVwb3J0LXdpdGgtdGVtcGxhdGVgLCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSlcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzOiBIdHRwUmVzcG9uc2U8UHJvZ3JhbW1pbmdFeGVyY2lzZUdpdERpZmZSZXBvcnQ+KSA9PiByZXMuYm9keSA/PyB1bmRlZmluZWQpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXRzIHRoZSB0ZXN0d2lzZSBjb3ZlcmFnZSByZXBvcnQgb2YgYSBwcm9ncmFtbWluZyBleGVyY2lzZSBmb3IgdGhlIGxhdGVzdCBzb2x1dGlvbiBzdWJtaXNzaW9uIHdpdGggYWxsIGRlc2NlbmRpbmcgcmVwb3J0c1xuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkIFRoZSBpZCBvZiBhIHByb2dyYW1taW5nIGV4ZXJjaXNlXG4gICAgICovXG4gICAgZ2V0TGF0ZXN0RnVsbFRlc3R3aXNlQ292ZXJhZ2VSZXBvcnQoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxDb3ZlcmFnZVJlcG9ydD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxDb3ZlcmFnZVJlcG9ydD4oYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtleGVyY2lzZUlkfS9mdWxsLXRlc3R3aXNlLWNvdmVyYWdlLXJlcG9ydGApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldHMgdGhlIHRlc3R3aXNlIGNvdmVyYWdlIHJlcG9ydCBvZiBhIHByb2dyYW1taW5nIGV4ZXJjaXNlIGZvciB0aGUgbGF0ZXN0IHNvbHV0aW9uIHN1Ym1pc3Npb24gd2l0aG91dCB0aGUgYWN0dWFsIHJlcG9ydHNcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2VJZCBUaGUgaWQgb2YgYSBwcm9ncmFtbWluZyBleGVyY2lzZVxuICAgICAqL1xuICAgIGdldExhdGVzdFRlc3R3aXNlQ292ZXJhZ2VSZXBvcnQoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxDb3ZlcmFnZVJlcG9ydD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxDb3ZlcmFnZVJlcG9ydD4oYCR7dGhpcy5yZXNvdXJjZVVybH0vJHtleGVyY2lzZUlkfS9mdWxsLXRlc3R3aXNlLWNvdmVyYWdlLXJlcG9ydGApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldHMgYWxsIGZpbGVzIGZyb20gdGhlIGxhc3Qgc29sdXRpb24gcGFydGljaXBhdGlvbiByZXBvc2l0b3J5XG4gICAgICovXG4gICAgZ2V0U29sdXRpb25SZXBvc2l0b3J5VGVzdEZpbGVzV2l0aENvbnRlbnQoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxNYXA8c3RyaW5nLCBzdHJpbmc+IHwgdW5kZWZpbmVkPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7ZXhlcmNpc2VJZH0vc29sdXRpb24tZmlsZXMtY29udGVudGApLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlczogSHR0cFJlc3BvbnNlPGFueT4pID0+IHtcbiAgICAgICAgICAgICAgICAvLyB0aGlzIG1hcHBpbmcgaXMgcmVxdWlyZWQgYmVjYXVzZSBvdGhlcndpc2UgdGhlIEh0dHBSZXNwb25zZSBvYmplY3Qgd291bGQgYmUgcGFyc2VkXG4gICAgICAgICAgICAgICAgLy8gdG8gYW4gYXJiaXRyYXJ5IG9iamVjdCAoYW5kIG5vdCBhIG1hcClcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzICYmIG5ldyBNYXAoT2JqZWN0LmVudHJpZXMocmVzKSk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXRzIGFsbCBmaWxlcyBmcm9tIHRoZSBsYXN0IGNvbW1pdCBpbiB0aGUgdGVtcGxhdGUgcGFydGljaXBhdGlvbiByZXBvc2l0b3J5XG4gICAgICovXG4gICAgZ2V0VGVtcGxhdGVSZXBvc2l0b3J5VGVzdEZpbGVzV2l0aENvbnRlbnQoZXhlcmNpc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxNYXA8c3RyaW5nLCBzdHJpbmc+IHwgdW5kZWZpbmVkPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7ZXhlcmNpc2VJZH0vdGVtcGxhdGUtZmlsZXMtY29udGVudGApLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHJlczogSHR0cFJlc3BvbnNlPGFueT4pID0+IHtcbiAgICAgICAgICAgICAgICAvLyB0aGlzIG1hcHBpbmcgaXMgcmVxdWlyZWQgYmVjYXVzZSBvdGhlcndpc2UgdGhlIEh0dHBSZXNwb25zZSBvYmplY3Qgd291bGQgYmUgcGFyc2VkXG4gICAgICAgICAgICAgICAgLy8gdG8gYW4gYXJiaXRyYXJ5IG9iamVjdCAoYW5kIG5vdCBhIG1hcClcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzICYmIG5ldyBNYXAoT2JqZWN0LmVudHJpZXMocmVzKSk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBnZXRTb2x1dGlvbkZpbGVOYW1lcyhleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPHN0cmluZ1tdPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PHN0cmluZ1tdPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L2ZpbGUtbmFtZXNgKTtcbiAgICB9XG5cbiAgICBnZXRDb2RlSGludHNGb3JFeGVyY2lzZShleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEV4ZXJjaXNlSGludFtdPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PEV4ZXJjaXNlSGludFtdPihgJHt0aGlzLnJlc291cmNlVXJsfS8ke2V4ZXJjaXNlSWR9L2V4ZXJjaXNlLWhpbnRzYCk7XG4gICAgfVxuXG4gICAgY3JlYXRlU3RydWN0dXJhbFNvbHV0aW9uRW50cmllcyhleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPFByb2dyYW1taW5nRXhlcmNpc2VTb2x1dGlvbkVudHJ5W10+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PFByb2dyYW1taW5nRXhlcmNpc2VTb2x1dGlvbkVudHJ5W10+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7ZXhlcmNpc2VJZH0vc3RydWN0dXJhbC1zb2x1dGlvbi1lbnRyaWVzYCwgbnVsbCk7XG4gICAgfVxuXG4gICAgY3JlYXRlQmVoYXZpb3JhbFNvbHV0aW9uRW50cmllcyhleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPFByb2dyYW1taW5nRXhlcmNpc2VTb2x1dGlvbkVudHJ5W10+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PFByb2dyYW1taW5nRXhlcmNpc2VTb2x1dGlvbkVudHJ5W10+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7ZXhlcmNpc2VJZH0vYmVoYXZpb3JhbC1zb2x1dGlvbi1lbnRyaWVzYCwgbnVsbCk7XG4gICAgfVxuXG4gICAgZ2V0QWxsVGVzdENhc2VzKGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8UHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlW10+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8UHJvZ3JhbW1pbmdFeGVyY2lzZVRlc3RDYXNlW10+KGBhcGkvcHJvZ3JhbW1pbmctZXhlcmNpc2VzLyR7ZXhlcmNpc2VJZH0vdGVzdC1jYXNlc2ApO1xuICAgIH1cblxuICAgIGdldEJ1aWxkTG9nU3RhdGlzdGljcyhleGVyY2lzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEJ1aWxkTG9nU3RhdGlzdGljc0RUTz4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxCdWlsZExvZ1N0YXRpc3RpY3NEVE8+KGAke3RoaXMucmVzb3VyY2VVcmx9LyR7ZXhlcmNpc2VJZH0vYnVpbGQtbG9nLXN0YXRpc3RpY3NgKTtcbiAgICB9XG5cbiAgICAvKiogSW1wb3J0cyBhIHByb2dyYW1taW5nIGV4ZXJjaXNlIGZyb20gYSBnaXZlbiB6aXAgZmlsZSAqKi9cbiAgICBpbXBvcnRGcm9tRmlsZShleGVyY2lzZTogUHJvZ3JhbW1pbmdFeGVyY2lzZSwgY291cnNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIGxldCBjb3B5ID0gdGhpcy5jb252ZXJ0RGF0YUZyb21DbGllbnQoZXhlcmNpc2UpO1xuICAgICAgICBjb3B5ID0gRXhlcmNpc2VTZXJ2aWNlLnNldEJvbnVzUG9pbnRzQ29uc3RyYWluZWRCeUluY2x1ZGVkSW5PdmVyYWxsU2NvcmUoY29weSk7XG4gICAgICAgIGNvcHkuY2F0ZWdvcmllcyA9IEV4ZXJjaXNlU2VydmljZS5zdHJpbmdpZnlFeGVyY2lzZUNhdGVnb3JpZXMoY29weSk7XG4gICAgICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZmlsZScsIGV4ZXJjaXNlLnppcEZpbGVGb3JJbXBvcnQhKTtcbiAgICAgICAgY29uc3QgZXhlcmNpc2VCbG9iID0gbmV3IEJsb2IoW0pTT04uc3RyaW5naWZ5KGNvcHkpXSwgeyB0eXBlOiAnYXBwbGljYXRpb24vanNvbicgfSk7XG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgncHJvZ3JhbW1pbmdFeGVyY2lzZScsIGV4ZXJjaXNlQmxvYik7XG4gICAgICAgIGNvbnN0IHVybCA9IGBhcGkvY291cnNlcy8ke2NvdXJzZUlkfS9wcm9ncmFtbWluZy1leGVyY2lzZXMvaW1wb3J0LWZyb20tZmlsZWA7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5wb3N0PFByb2dyYW1taW5nRXhlcmNpc2U+KHVybCwgZm9ybURhdGEsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEVudGl0eVJlc3BvbnNlVHlwZSkgPT4gdGhpcy5wcm9jZXNzUHJvZ3JhbW1pbmdFeGVyY2lzZUVudGl0eVJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBTdHVkZW50UGFydGljaXBhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9wYXJ0aWNpcGF0aW9uL3N0dWRlbnQtcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBUZW1wbGF0ZVByb2dyYW1taW5nRXhlcmNpc2VQYXJ0aWNpcGF0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3BhcnRpY2lwYXRpb24vdGVtcGxhdGUtcHJvZ3JhbW1pbmctZXhlcmNpc2UtcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBTb2x1dGlvblByb2dyYW1taW5nRXhlcmNpc2VQYXJ0aWNpcGF0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3BhcnRpY2lwYXRpb24vc29sdXRpb24tcHJvZ3JhbW1pbmctZXhlcmNpc2UtcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3Byb2dyYW1taW5nLWV4ZXJjaXNlLm1vZGVsJztcblxuLyoqXG4gKiBFbnVtZXJhdGlvbiBkZWZpbmluZyB0eXBlIG9mIHRoZSBleHBvcnRlZCBmaWxlLlxuICovXG5leHBvcnQgZW51bSBGaWxlVHlwZSB7XG4gICAgRklMRSA9ICdGSUxFJyxcbiAgICBGT0xERVIgPSAnRk9MREVSJyxcbn1cblxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEZpbGVDaGFuZ2Uge31cblxuZXhwb3J0IGNsYXNzIENyZWF0ZUZpbGVDaGFuZ2UgZXh0ZW5kcyBGaWxlQ2hhbmdlIHtcbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHVibGljIGZpbGVUeXBlOiBGaWxlVHlwZSxcbiAgICAgICAgcHVibGljIGZpbGVOYW1lOiBzdHJpbmcsXG4gICAgKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgfVxufVxuXG5leHBvcnQgY2xhc3MgRGVsZXRlRmlsZUNoYW5nZSBleHRlbmRzIEZpbGVDaGFuZ2Uge1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwdWJsaWMgZmlsZVR5cGU6IEZpbGVUeXBlLFxuICAgICAgICBwdWJsaWMgZmlsZU5hbWU6IHN0cmluZyxcbiAgICApIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICB9XG59XG5cbmV4cG9ydCBjbGFzcyBSZW5hbWVGaWxlQ2hhbmdlIGV4dGVuZHMgRmlsZUNoYW5nZSB7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHB1YmxpYyBmaWxlVHlwZTogRmlsZVR5cGUsXG4gICAgICAgIHB1YmxpYyBvbGRGaWxlTmFtZTogc3RyaW5nLFxuICAgICAgICBwdWJsaWMgbmV3RmlsZU5hbWU6IHN0cmluZyxcbiAgICApIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICB9XG59XG5cbmV4cG9ydCB0eXBlIEZpbGVTdWJtaXNzaW9uID0geyBbZmlsZU5hbWU6IHN0cmluZ106IHN0cmluZyB8IHVuZGVmaW5lZCB9O1xuXG4vKipcbiAqIEVudW1lcmF0aW9uIGRlZmluaW5nIGRvbWFpbiB0eXBlLlxuICovXG5leHBvcnQgZW51bSBEb21haW5UeXBlIHtcbiAgICBQQVJUSUNJUEFUSU9OID0gJ1BBUlRJQ0lQQVRJT04nLFxuICAgIFRFU1RfUkVQT1NJVE9SWSA9ICdURVNUX1JFUE9TSVRPUlknLFxufVxuXG4vKipcbiAqIEVudW1lcmF0aW9uIGRlZmluaW5nIHdoZXRoZXIgdGhlcmUgaXMgYSBjb25mbGljdCB3aGlsZSBjaGVja2luZyBvdXQuXG4gKi9cbmV4cG9ydCBlbnVtIFJlcG9zaXRvcnlFcnJvciB7XG4gICAgQ0hFQ0tPVVRfQ09ORkxJQ1QgPSAnY2hlY2tvdXRDb25mbGljdCcsXG59XG5cbmV4cG9ydCB0eXBlIEZpbGVTdWJtaXNzaW9uRXJyb3IgPSB7IGVycm9yOiBSZXBvc2l0b3J5RXJyb3I7IHBhcnRpY2lwYXRpb25JZDogbnVtYmVyOyBmaWxlTmFtZTogc3RyaW5nIH07XG5cbi8qKlxuICogRW51bWVyYXRpb24gZGVmaW5pbmcgdGhlIHN0YXRlIG9mIHRoZSBjb21taXQuXG4gKi9cbmV4cG9ydCBlbnVtIENvbW1pdFN0YXRlIHtcbiAgICBVTkRFRklORUQgPSAnVU5ERUZJTkVEJyxcbiAgICBDT1VMRF9OT1RfQkVfUkVUUklFVkVEID0gJ0NPVUxEX05PVF9CRV9SRVRSSUVWRUQnLFxuICAgIENMRUFOID0gJ0NMRUFOJyxcbiAgICBVTkNPTU1JVFRFRF9DSEFOR0VTID0gJ1VOQ09NTUlUVEVEX0NIQU5HRVMnLFxuICAgIENPTU1JVFRJTkcgPSAnQ09NTUlUVElORycsXG4gICAgQ09ORkxJQ1QgPSAnQ09ORkxJQ1QnLFxufVxuXG4vKipcbiAqIEVudW1lcmF0aW9uIGRlZmluaW5nIHRoZSBzdGF0ZSBvZiB0aGUgZWRpdG9yLlxuICovXG5leHBvcnQgZW51bSBFZGl0b3JTdGF0ZSB7XG4gICAgQ0xFQU4gPSAnQ0xFQU4nLFxuICAgIFVOU0FWRURfQ0hBTkdFUyA9ICdVTlNBVkVEX0NIQU5HRVMnLFxuICAgIFNBVklORyA9ICdTQVZJTkcnLFxuICAgIFJFRlJFU0hJTkcgPSAnUkVGUkVTSElORycsXG59XG5cbi8qKlxuICogRW51bWVyYXRpb24gZGVmaW5pbmcgdHlwZSBvZiB0aGUgcmVzaXplIG9wZXJhdGlvbi5cbiAqL1xuZXhwb3J0IGVudW0gUmVzaXplVHlwZSB7XG4gICAgU0lERUJBUl9MRUZUID0gJ1NJREVCQVJfTEVGVCcsXG4gICAgU0lERUJBUl9SSUdIVCA9ICdTSURFQkFSX1JJR0hUJyxcbiAgICBNQUlOX0JPVFRPTSA9ICdNQUlOX0JPVFRPTScsXG4gICAgQk9UVE9NID0gJ0JPVFRPTScsXG59XG5cbmV4cG9ydCB0eXBlIERvbWFpblBhcnRpY2lwYXRpb25DaGFuZ2UgPSBbRG9tYWluVHlwZS5QQVJUSUNJUEFUSU9OLCBTdHVkZW50UGFydGljaXBhdGlvbiB8IFRlbXBsYXRlUHJvZ3JhbW1pbmdFeGVyY2lzZVBhcnRpY2lwYXRpb24gfCBTb2x1dGlvblByb2dyYW1taW5nRXhlcmNpc2VQYXJ0aWNpcGF0aW9uXTtcbmV4cG9ydCB0eXBlIERvbWFpblRlc3RSZXBvc2l0b3J5Q2hhbmdlID0gW0RvbWFpblR5cGUuVEVTVF9SRVBPU0lUT1JZLCBQcm9ncmFtbWluZ0V4ZXJjaXNlXTtcbmV4cG9ydCB0eXBlIERvbWFpbkNoYW5nZSA9IERvbWFpblBhcnRpY2lwYXRpb25DaGFuZ2UgfCBEb21haW5UZXN0UmVwb3NpdG9yeUNoYW5nZTtcblxuLyoqXG4gKiBFbnVtZXJhdGlvbiBkZWZpbmluZyB0aGUgc3RhdGUgb2YgZ2l0LlxuICovXG5leHBvcnQgZW51bSBHaXRDb25mbGljdFN0YXRlIHtcbiAgICBDSEVDS09VVF9DT05GTElDVCA9ICdDSEVDS09VVF9DT05GTElDVCcsXG4gICAgT0sgPSAnT0snLFxufVxuXG4vKipcbiAqIEVudW1lcmF0aW9uIGRlZmluaW5nIHRoZSBpY29uIGluIGEgZmlsZSBiYWRnZS5cbiAqL1xuZXhwb3J0IGVudW0gRmlsZUJhZGdlVHlwZSB7XG4gICAgRkVFREJBQ0tfU1VHR0VTVElPTiA9ICdGRUVEQkFDS19TVUdHRVNUSU9OJyxcbn1cblxuLyoqXG4gKiBBIGZpbGUgYmFkZ2UgaXMgYSBiYWRnZSBpbiB0aGUgZmlsZSB0cmVlIG9mIHRoZSBjb2RlIGVkaXRvciB3aXRoIGFuIGljb24gYW5kIGEgY291bnQuXG4gKi9cbmV4cG9ydCBjbGFzcyBGaWxlQmFkZ2Uge1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwdWJsaWMgdHlwZTogRmlsZUJhZGdlVHlwZSxcbiAgICAgICAgcHVibGljIGNvdW50OiBudW1iZXIsXG4gICAgKSB7fVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmVoYXZpb3JTdWJqZWN0LCBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBEb21haW5DaGFuZ2UsIERvbWFpblBhcnRpY2lwYXRpb25DaGFuZ2UsIERvbWFpblRlc3RSZXBvc2l0b3J5Q2hhbmdlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvY29kZS1lZGl0b3IvbW9kZWwvY29kZS1lZGl0b3IubW9kZWwnO1xuXG4vKipcbiAqIFRoaXMgc2VydmljZSBwcm92aWRlcyBzdWJzY3JpYmluZyBzZXJ2aWNlcyB3aXRoIHRoZSBtb3N0IHJlY2VudGx5IHNlbGVjdGVkIGRvbWFpbiAocGFydGljaXBhdGlvbiB2cyByZXBvc2l0b3J5KS5cbiAqIFRoaXMgaXMgdXNlZCB0byBtYWtlIGNvbXBvbmVudHMgaW5kZXBlbmRlbnQgb2YgdGhlIGRvbWFpbnMsIGFzIHRoZXkgY2FuIGp1c3QgY2FsbCB0aGUgbWV0aG9kIG9mIGFuIGluamVjdGVkIHNlcnZpY2Ugd2l0aG91dCBwYXNzaW5nIHRoZSBkb21haW4uXG4gKi9cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgRG9tYWluU2VydmljZSB7XG4gICAgcHJvdGVjdGVkIGRvbWFpbjogRG9tYWluQ2hhbmdlO1xuICAgIHByaXZhdGUgc3ViamVjdCA9IG5ldyBCZWhhdmlvclN1YmplY3Q8RG9tYWluUGFydGljaXBhdGlvbkNoYW5nZSB8IERvbWFpblRlc3RSZXBvc2l0b3J5Q2hhbmdlIHwgdW5kZWZpbmVkPih1bmRlZmluZWQpO1xuXG4gICAgY29uc3RydWN0b3IoKSB7fVxuXG4gICAgLyoqXG4gICAgICogU2V0cyBkb21haW4gYW5kIHN1YmplY3QubmV4dCBhY2NvcmRpbmcgdG8gcGFyYW1ldGVyLlxuICAgICAqIEBwYXJhbSBkb21haW4gLSBkZWZpbmVzIG5ldyBkb21haW4gb2YgdGhlIHNlcnZpY2UuXG4gICAgICovXG4gICAgcHVibGljIHNldERvbWFpbihkb21haW46IERvbWFpbkNoYW5nZSkge1xuICAgICAgICB0aGlzLmRvbWFpbiA9IGRvbWFpbjtcbiAgICAgICAgdGhpcy5zdWJqZWN0Lm5leHQoZG9tYWluKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTdWJzY3JpYmVzIHRvIGN1cnJlbnQgc3ViamVjdC5cbiAgICAgKi9cbiAgICBwdWJsaWMgc3Vic2NyaWJlRG9tYWluQ2hhbmdlKCk6IE9ic2VydmFibGU8RG9tYWluQ2hhbmdlIHwgdW5kZWZpbmVkPiB7XG4gICAgICAgIHJldHVybiB0aGlzLnN1YmplY3Q7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgT25EZXN0cm95IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEb21haW5DaGFuZ2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9jb2RlLWVkaXRvci9tb2RlbC9jb2RlLWVkaXRvci5tb2RlbCc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IGZpbHRlciwgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgRG9tYWluU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2NvZGUtZWRpdG9yL3NlcnZpY2UvY29kZS1lZGl0b3ItZG9tYWluLnNlcnZpY2UnO1xuXG4vKipcbiAqIFNlcnZpY2UgdGhhdCBjYW4gYmUgZXh0ZW5kZWQgdG8gYXV0b21hdGljYWxseSByZWNlaXZlIHVwZGF0ZXMgb24gY2hhbmdlZCBkb21haW5zLlxuICovXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIERvbWFpbkRlcGVuZGVudFNlcnZpY2UgaW1wbGVtZW50cyBPbkRlc3Ryb3kge1xuICAgIHByb3RlY3RlZCBkb21haW46IERvbWFpbkNoYW5nZTtcbiAgICBwcm90ZWN0ZWQgZG9tYWluQ2hhbmdlU3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb247XG5cbiAgICBwcm90ZWN0ZWQgY29uc3RydWN0b3IocHJpdmF0ZSBkb21haW5TZXJ2aWNlOiBEb21haW5TZXJ2aWNlKSB7fVxuXG4gICAgLyoqXG4gICAgICogSW5pdGlhbGl6ZXMgYSBkb21haW4gc3Vic2NyaXB0aW9uLlxuICAgICAqL1xuICAgIGluaXREb21haW5TdWJzY3JpcHRpb24oKSB7XG4gICAgICAgIHRoaXMuZG9tYWluQ2hhbmdlU3Vic2NyaXB0aW9uID0gdGhpcy5kb21haW5TZXJ2aWNlXG4gICAgICAgICAgICAuc3Vic2NyaWJlRG9tYWluQ2hhbmdlKClcbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIGZpbHRlcigoZG9tYWluKSA9PiAhIWRvbWFpbiksXG4gICAgICAgICAgICAgICAgdGFwKChkb21haW46IERvbWFpbkNoYW5nZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNldERvbWFpbihkb21haW4pO1xuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNldHMgZG9tYWluIGFjY29yZGluZyB0byB0aGUgcGFyYW1ldGVyLlxuICAgICAqIEBwYXJhbSBkb21haW4gLSBlbnVtIHRoYXQgZGVmaW5lcyB0aGUgdHlwZSBvZiB0aGUgZG9tYWluLlxuICAgICAqL1xuICAgIHNldERvbWFpbihkb21haW46IERvbWFpbkNoYW5nZSkge1xuICAgICAgICB0aGlzLmRvbWFpbiA9IGRvbWFpbjtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVbnN1YnNjcmliZSBmcm9tIGN1cnJlbnQgc3Vic2NyaXB0aW9uLlxuICAgICAqL1xuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICBpZiAodGhpcy5kb21haW5DaGFuZ2VTdWJzY3JpcHRpb24pIHtcbiAgICAgICAgICAgIHRoaXMuZG9tYWluQ2hhbmdlU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgeyBCZWhhdmlvclN1YmplY3QsIE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEluamVjdGFibGUsIE9uRGVzdHJveSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZGlzdGluY3RVbnRpbENoYW5nZWQgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBKaGlXZWJzb2NrZXRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvd2Vic29ja2V0L3dlYnNvY2tldC5zZXJ2aWNlJztcbmltcG9ydCB7IERvbWFpblNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9jb2RlLWVkaXRvci9zZXJ2aWNlL2NvZGUtZWRpdG9yLWRvbWFpbi5zZXJ2aWNlJztcbmltcG9ydCB7IERvbWFpblR5cGUsIEdpdENvbmZsaWN0U3RhdGUgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9jb2RlLWVkaXRvci9tb2RlbC9jb2RlLWVkaXRvci5tb2RlbCc7XG5pbXBvcnQgeyBEb21haW5EZXBlbmRlbnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvY29kZS1lZGl0b3Ivc2VydmljZS9jb2RlLWVkaXRvci1kb21haW4tZGVwZW5kZW50LnNlcnZpY2UnO1xuXG5leHBvcnQgaW50ZXJmYWNlIElDb25mbGljdFN0YXRlU2VydmljZSB7XG4gICAgc3Vic2NyaWJlQ29uZmxpY3RTdGF0ZTogKCkgPT4gT2JzZXJ2YWJsZTxHaXRDb25mbGljdFN0YXRlPjtcbiAgICBub3RpZnlDb25mbGljdFN0YXRlOiAoZ2l0Q29uZmxpY3RTdGF0ZTogR2l0Q29uZmxpY3RTdGF0ZSkgPT4gdm9pZDtcbn1cblxuLyoqXG4gKiBUaGlzIHNlcnZpY2UgbWFuYWdlcyB0aGUgaW5mb3JtYXRpb24gYWJvdXQgZ2l0IGNvbmZsaWN0cyBvZiByZXBvc2l0b3JpZXMuXG4gKiBJdCBvZmZlcnMgbWV0aG9kcyB0byBib3RoIHN1YnNjcmliZSBhbmQgbm90aWZ5IG9uIGNvbmZsaWN0cy5cbiAqL1xuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBDb2RlRWRpdG9yQ29uZmxpY3RTdGF0ZVNlcnZpY2UgZXh0ZW5kcyBEb21haW5EZXBlbmRlbnRTZXJ2aWNlIGltcGxlbWVudHMgSUNvbmZsaWN0U3RhdGVTZXJ2aWNlLCBPbkRlc3Ryb3kge1xuICAgIHByaXZhdGUgY29uZmxpY3RTdWJqZWN0czogTWFwPHN0cmluZywgQmVoYXZpb3JTdWJqZWN0PEdpdENvbmZsaWN0U3RhdGU+PiA9IG5ldyBNYXAoKTtcbiAgICBwcml2YXRlIHdlYnNvY2tldENvbm5lY3Rpb25zOiBNYXA8c3RyaW5nLCBzdHJpbmc+ID0gbmV3IE1hcCgpO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIGRvbWFpblNlcnZpY2U6IERvbWFpblNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgamhpV2Vic29ja2V0U2VydmljZTogSmhpV2Vic29ja2V0U2VydmljZSxcbiAgICApIHtcbiAgICAgICAgc3VwZXIoZG9tYWluU2VydmljZSk7XG4gICAgICAgIHRoaXMuaW5pdERvbWFpblN1YnNjcmlwdGlvbigpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVuc3Vic2NyaWJlIGZyb21tIGFsbCBzdWJzY3JpcHRpb25zLlxuICAgICAqL1xuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgICAgICBPYmplY3QudmFsdWVzKHRoaXMud2Vic29ja2V0Q29ubmVjdGlvbnMpLmZvckVhY2goKGNoYW5uZWwpID0+IHRoaXMuamhpV2Vic29ja2V0U2VydmljZS51bnN1YnNjcmliZShjaGFubmVsKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU3Vic2NyaWJlIHRvIGdpdCBjb25mbGljdCBub3RpZmljYXRpb25zLiBEb2VzIG5vdCBlbWl0IHRoZSBzYW1lIHZhbHVlIHR3aWNlIGluIGEgcm93IChkaXN0aW5jdFVudGlsQ2hhbmdlZCkuXG4gICAgICogRW1pdHMgYW4gT0sgYXMgYSBmaXJzdCB2YWx1ZS5cbiAgICAgKi9cbiAgICBzdWJzY3JpYmVDb25mbGljdFN0YXRlID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBkb21haW5LZXkgPSB0aGlzLmdldERvbWFpbktleSgpO1xuICAgICAgICBjb25zdCBzdWJqZWN0ID0gdGhpcy5jb25mbGljdFN1YmplY3RzLmdldChkb21haW5LZXkpO1xuICAgICAgICBpZiAoIXN1YmplY3QpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlcG9TdWJqZWN0ID0gbmV3IEJlaGF2aW9yU3ViamVjdChHaXRDb25mbGljdFN0YXRlLk9LKTtcbiAgICAgICAgICAgIHRoaXMuY29uZmxpY3RTdWJqZWN0cy5zZXQoZG9tYWluS2V5LCByZXBvU3ViamVjdCk7XG4gICAgICAgICAgICByZXR1cm4gcmVwb1N1YmplY3QucGlwZShkaXN0aW5jdFVudGlsQ2hhbmdlZCgpKSBhcyBPYnNlcnZhYmxlPEdpdENvbmZsaWN0U3RhdGU+O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIHN1YmplY3QucGlwZShkaXN0aW5jdFVudGlsQ2hhbmdlZCgpKSBhcyBPYnNlcnZhYmxlPEdpdENvbmZsaWN0U3RhdGU+O1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIE5vdGlmeSBhbGwgc3Vic2NyaWJlcnMgYWJvdXQgYSBnaXZlbiBjb25mbGljdFN0YXRlLlxuICAgICAqXG4gICAgICogQHBhcmFtIGdpdENvbmZsaWN0U3RhdGVcbiAgICAgKi9cbiAgICBub3RpZnlDb25mbGljdFN0YXRlID0gKGdpdENvbmZsaWN0U3RhdGU6IEdpdENvbmZsaWN0U3RhdGUpID0+IHtcbiAgICAgICAgY29uc3QgZG9tYWluS2V5ID0gdGhpcy5nZXREb21haW5LZXkoKTtcbiAgICAgICAgY29uc3Qgc3ViamVjdCA9IHRoaXMuY29uZmxpY3RTdWJqZWN0cy5nZXQoZG9tYWluS2V5KTtcbiAgICAgICAgaWYgKHN1YmplY3QpIHtcbiAgICAgICAgICAgIHN1YmplY3QubmV4dChnaXRDb25mbGljdFN0YXRlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBwcml2YXRlIGdldERvbWFpbktleSA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgW2RvbWFpblR5cGUsIGRvbWFpblZhbHVlXSA9IHRoaXMuZG9tYWluO1xuICAgICAgICByZXR1cm4gYCR7ZG9tYWluVHlwZSA9PT0gRG9tYWluVHlwZS5QQVJUSUNJUEFUSU9OID8gJ3BhcnRpY2lwYXRpb24nIDogJ3Rlc3QnfS0ke2RvbWFpblZhbHVlLmlkIS50b1N0cmluZygpfWA7XG4gICAgfTtcbn1cbiIsImltcG9ydCB7IERvbWFpbkRlcGVuZGVudFNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9jb2RlLWVkaXRvci9zZXJ2aWNlL2NvZGUtZWRpdG9yLWRvbWFpbi1kZXBlbmRlbnQuc2VydmljZSc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgSmhpV2Vic29ja2V0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3dlYnNvY2tldC93ZWJzb2NrZXQuc2VydmljZSc7XG5pbXBvcnQgeyBEb21haW5DaGFuZ2UsIERvbWFpblR5cGUgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9jb2RlLWVkaXRvci9tb2RlbC9jb2RlLWVkaXRvci5tb2RlbCc7XG5pbXBvcnQgeyBEb21haW5TZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvY29kZS1lZGl0b3Ivc2VydmljZS9jb2RlLWVkaXRvci1kb21haW4uc2VydmljZSc7XG5cbi8qKlxuICogU2VydmljZSB0aGF0IGNhbiBiZSBleHRlbmRlZCB0byB1cGRhdGUgcmVzdCBlbmRwb2ludCB1cmxzIHdpdGggdGhlIHJlY2VpdmVkIGRvbWFpbiBpbmZvcm1hdGlvbi5cbiAqL1xuZXhwb3J0IGFic3RyYWN0IGNsYXNzIERvbWFpbkRlcGVuZGVudEVuZHBvaW50U2VydmljZSBleHRlbmRzIERvbWFpbkRlcGVuZGVudFNlcnZpY2Uge1xuICAgIHByb3RlY3RlZCByZXN0UmVzb3VyY2VVcmw/OiBzdHJpbmc7XG5cbiAgICBwcm90ZWN0ZWQgY29uc3RydWN0b3IoXG4gICAgICAgIHByb3RlY3RlZCBodHRwOiBIdHRwQ2xpZW50LFxuICAgICAgICBwcm90ZWN0ZWQgamhpV2Vic29ja2V0U2VydmljZTogSmhpV2Vic29ja2V0U2VydmljZSxcbiAgICAgICAgZG9tYWluU2VydmljZTogRG9tYWluU2VydmljZSxcbiAgICApIHtcbiAgICAgICAgc3VwZXIoZG9tYWluU2VydmljZSk7XG4gICAgICAgIHRoaXMuaW5pdERvbWFpblN1YnNjcmlwdGlvbigpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNldHMgcmVzb3VyY2VVcmxzIGFjY29yZGluZyB0byB0aGUgcGFyYW1ldGVyLlxuICAgICAqIEBwYXJhbSBkb21haW4gLSBlbnVtIHRoYXQgZGVmaW5lcyB0aGUgdHlwZSBvZiB0aGUgZG9tYWluLlxuICAgICAqL1xuICAgIHNldERvbWFpbihkb21haW46IERvbWFpbkNoYW5nZSkge1xuICAgICAgICBzdXBlci5zZXREb21haW4oZG9tYWluKTtcbiAgICAgICAgdGhpcy5yZXN0UmVzb3VyY2VVcmwgPSB0aGlzLmNhbGN1bGF0ZVJlc3RSZXNvdXJjZVVSTChkb21haW4pO1xuICAgIH1cblxuICAgIGNhbGN1bGF0ZVJlc3RSZXNvdXJjZVVSTChkb21haW46IERvbWFpbkNoYW5nZSk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICAgIGNvbnN0IFtkb21haW5UeXBlLCBkb21haW5WYWx1ZV0gPSBkb21haW47XG4gICAgICAgIHN3aXRjaCAoZG9tYWluVHlwZSkge1xuICAgICAgICAgICAgY2FzZSBEb21haW5UeXBlLlBBUlRJQ0lQQVRJT046XG4gICAgICAgICAgICAgICAgcmV0dXJuIGBhcGkvcmVwb3NpdG9yeS8ke2RvbWFpblZhbHVlLmlkfWA7XG4gICAgICAgICAgICBjYXNlIERvbWFpblR5cGUuVEVTVF9SRVBPU0lUT1JZOlxuICAgICAgICAgICAgICAgIHJldHVybiBgYXBpL3Rlc3QtcmVwb3NpdG9yeS8ke2RvbWFpblZhbHVlLmlkfWA7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgeyBIdHRwQ2xpZW50LCBIdHRwRXJyb3JSZXNwb25zZSwgSHR0cFBhcmFtcyB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IEluamVjdGFibGUsIE9uRGVzdHJveSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgU3ViamVjdCwgVW5hcnlGdW5jdGlvbiwgb2YsIHBpcGUsIHRocm93RXJyb3IgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IGNhdGNoRXJyb3IsIG1hcCwgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHtcbiAgICBDb21taXRTdGF0ZSxcbiAgICBEb21haW5DaGFuZ2UsXG4gICAgRG9tYWluVHlwZSxcbiAgICBGaWxlU3VibWlzc2lvbixcbiAgICBGaWxlU3VibWlzc2lvbkVycm9yLFxuICAgIEZpbGVUeXBlLFxuICAgIEdpdENvbmZsaWN0U3RhdGUsXG4gICAgUmVwb3NpdG9yeUVycm9yLFxufSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9jb2RlLWVkaXRvci9tb2RlbC9jb2RlLWVkaXRvci5tb2RlbCc7XG5pbXBvcnQgeyBDb2RlRWRpdG9yQ29uZmxpY3RTdGF0ZVNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9jb2RlLWVkaXRvci9zZXJ2aWNlL2NvZGUtZWRpdG9yLWNvbmZsaWN0LXN0YXRlLnNlcnZpY2UnO1xuaW1wb3J0IHsgQnVpbGRMb2dTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvc2VydmljZS9idWlsZC1sb2cuc2VydmljZSc7XG5pbXBvcnQgeyBKaGlXZWJzb2NrZXRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvd2Vic29ja2V0L3dlYnNvY2tldC5zZXJ2aWNlJztcbmltcG9ydCB7IERvbWFpblNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9jb2RlLWVkaXRvci9zZXJ2aWNlL2NvZGUtZWRpdG9yLWRvbWFpbi5zZXJ2aWNlJztcbmltcG9ydCB7IERvbWFpbkRlcGVuZGVudEVuZHBvaW50U2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcHJvZ3JhbW1pbmcvc2hhcmVkL2NvZGUtZWRpdG9yL3NlcnZpY2UvY29kZS1lZGl0b3ItZG9tYWluLWRlcGVuZGVudC1lbmRwb2ludC5zZXJ2aWNlJztcbmltcG9ydCB7IGRvd25sb2FkRmlsZSB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC9kb3dubG9hZC51dGlsJztcblxuZXhwb3J0IGludGVyZmFjZSBJQ29kZUVkaXRvclJlcG9zaXRvcnlGaWxlU2VydmljZSB7XG4gICAgZ2V0UmVwb3NpdG9yeUNvbnRlbnQ6ICgpID0+IE9ic2VydmFibGU8eyBbZmlsZU5hbWU6IHN0cmluZ106IEZpbGVUeXBlIH0+O1xuICAgIGdldEZpbGU6IChmaWxlTmFtZTogc3RyaW5nKSA9PiBPYnNlcnZhYmxlPHsgZmlsZUNvbnRlbnQ6IHN0cmluZyB9PjtcbiAgICBjcmVhdGVGaWxlOiAoZmlsZU5hbWU6IHN0cmluZykgPT4gT2JzZXJ2YWJsZTx2b2lkPjtcbiAgICBjcmVhdGVGb2xkZXI6IChmb2xkZXJOYW1lOiBzdHJpbmcpID0+IE9ic2VydmFibGU8dm9pZD47XG4gICAgdXBkYXRlRmlsZUNvbnRlbnQ6IChmaWxlTmFtZTogc3RyaW5nLCBmaWxlQ29udGVudDogc3RyaW5nKSA9PiBPYnNlcnZhYmxlPGFueT47XG4gICAgdXBkYXRlRmlsZXM6IChmaWxlVXBkYXRlczogQXJyYXk8eyBmaWxlTmFtZTogc3RyaW5nOyBmaWxlQ29udGVudDogc3RyaW5nIH0+KSA9PiBPYnNlcnZhYmxlPEZpbGVTdWJtaXNzaW9uIHwgRmlsZVN1Ym1pc3Npb25FcnJvcj47XG4gICAgcmVuYW1lRmlsZTogKGZpbGVQYXRoOiBzdHJpbmcsIG5ld0ZpbGVOYW1lOiBzdHJpbmcpID0+IE9ic2VydmFibGU8dm9pZD47XG4gICAgZGVsZXRlRmlsZTogKGZpbGVQYXRoOiBzdHJpbmcpID0+IE9ic2VydmFibGU8dm9pZD47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSUNvZGVFZGl0b3JSZXBvc2l0b3J5U2VydmljZSB7XG4gICAgZ2V0U3RhdHVzOiAoKSA9PiBPYnNlcnZhYmxlPHsgcmVwb3NpdG9yeVN0YXR1czogc3RyaW5nIH0+O1xuICAgIGNvbW1pdDogKCkgPT4gT2JzZXJ2YWJsZTx2b2lkPjtcbiAgICBwdWxsOiAoKSA9PiBPYnNlcnZhYmxlPHZvaWQ+O1xuICAgIHJlc2V0UmVwb3NpdG9yeTogKCkgPT4gT2JzZXJ2YWJsZTx2b2lkPjtcbn1cblxuZXhwb3J0IGNsYXNzIENvbm5lY3Rpb25FcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoJ0ludGVybmV0RGlzY29ubmVjdGVkJyk7XG4gICAgICAgIC8vIFNldCB0aGUgcHJvdG90eXBlIGV4cGxpY2l0bHkuXG4gICAgICAgIE9iamVjdC5zZXRQcm90b3R5cGVPZih0aGlzLCBDb25uZWN0aW9uRXJyb3IucHJvdG90eXBlKTtcbiAgICB9XG5cbiAgICBzdGF0aWMgZ2V0IG1lc3NhZ2UoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuICdJbnRlcm5ldERpc2Nvbm5lY3RlZCc7XG4gICAgfVxufVxuXG4vKipcbiAqIFR5cGUgZ3VhcmQgZm9yIGNoZWNraW5nIGlmIHRoZSBmaWxlIHN1Ym1pc3Npb24gcmVjZWl2ZWQgdGhyb3VnaCB0aGUgd2Vic29ja2V0IGlzIGFuIGVycm9yIG9iamVjdC5cbiAqIEBwYXJhbSB0b0JlRGV0ZXJtaW5lZCBlaXRoZXIgYSBGaWxlU3VibWlzc2lvbiBvciBhIEZpbGVTdWJtaXNzaW9uRXJyb3IuXG4gKi9cbmNvbnN0IGNoZWNrSWZTdWJtaXNzaW9uSXNFcnJvciA9ICh0b0JlRGV0ZXJtaW5lZDogRmlsZVN1Ym1pc3Npb24gfCBGaWxlU3VibWlzc2lvbkVycm9yKTogdG9CZURldGVybWluZWQgaXMgRmlsZVN1Ym1pc3Npb25FcnJvciA9PiB7XG4gICAgcmV0dXJuICEhKHRvQmVEZXRlcm1pbmVkIGFzIEZpbGVTdWJtaXNzaW9uRXJyb3IpLmVycm9yO1xufTtcblxuLy8gVE9ETzogVGhlIFJlcG9zaXRvcnkgJiBSZXBvc2l0b3J5RmlsZSBzZXJ2aWNlcyBzaG91bGQgYmUgbWVyZ2VkIGludG8gMSBzZXJ2aWNlLCB0aGlzIHdvdWxkIG1ha2UgaGFuZGxpbmcgZXJyb3JzIGVhc2llci5cbi8qKlxuICogQ2hlY2sgYSBIdHRwRXJyb3JSZXNwb25zZSBmb3Igc3BlY2lmaWMgc3RhdHVzIGNvZGVzIHRoYXQgYXJlIHJlbGV2YW50IGZvciB0aGUgY29kZS1lZGl0b3IuXG4gKiBBdG0gd2Ugb25seSBjaGVjayB0aGUgY29uZmxpY3Qgc3RhdHVzIGNvZGUgKDQwOSkgJiBpbmZvcm0gdGhlIGNvbmZsaWN0U2VydmljZSBhYm91dCBpdCwgYW5kICdpbnRlcm5ldCBkaXNjb25uZWN0ZWQnIHN0YXR1cyBjb2RlICgwKS5cbiAqXG4gKiBAcGFyYW0gY29uZmxpY3RTZXJ2aWNlXG4gKi9cbmNvbnN0IGhhbmRsZUVycm9yUmVzcG9uc2UgPSA8VD4oY29uZmxpY3RTZXJ2aWNlOiBDb2RlRWRpdG9yQ29uZmxpY3RTdGF0ZVNlcnZpY2UpOiBVbmFyeUZ1bmN0aW9uPE9ic2VydmFibGU8VD4sIE9ic2VydmFibGU8VD4+ID0+XG4gICAgcGlwZShcbiAgICAgICAgY2F0Y2hFcnJvcigoZXJyOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgaWYgKGVyci5zdGF0dXMgPT09IDQwOSkge1xuICAgICAgICAgICAgICAgIGNvbmZsaWN0U2VydmljZS5ub3RpZnlDb25mbGljdFN0YXRlKEdpdENvbmZsaWN0U3RhdGUuQ0hFQ0tPVVRfQ09ORkxJQ1QpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGVyci5zdGF0dXMgPT09IDAgfHwgZXJyLnN0YXR1cyA9PT0gNTA0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoKCkgPT4gbmV3IENvbm5lY3Rpb25FcnJvcigpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0aHJvd0Vycm9yKCgpID0+IGVycik7XG4gICAgICAgIH0pLFxuICAgICk7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgQ29kZUVkaXRvclJlcG9zaXRvcnlTZXJ2aWNlIGV4dGVuZHMgRG9tYWluRGVwZW5kZW50RW5kcG9pbnRTZXJ2aWNlIGltcGxlbWVudHMgSUNvZGVFZGl0b3JSZXBvc2l0b3J5U2VydmljZSB7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIGh0dHA6IEh0dHBDbGllbnQsXG4gICAgICAgIGpoaVdlYnNvY2tldFNlcnZpY2U6IEpoaVdlYnNvY2tldFNlcnZpY2UsXG4gICAgICAgIGRvbWFpblNlcnZpY2U6IERvbWFpblNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgY29uZmxpY3RTZXJ2aWNlOiBDb2RlRWRpdG9yQ29uZmxpY3RTdGF0ZVNlcnZpY2UsXG4gICAgKSB7XG4gICAgICAgIHN1cGVyKGh0dHAsIGpoaVdlYnNvY2tldFNlcnZpY2UsIGRvbWFpblNlcnZpY2UpO1xuICAgIH1cblxuICAgIGdldFN0YXR1cyA9ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8YW55Pih0aGlzLnJlc3RSZXNvdXJjZVVybCEpLnBpcGUoXG4gICAgICAgICAgICBoYW5kbGVFcnJvclJlc3BvbnNlPHsgcmVwb3NpdG9yeVN0YXR1czogc3RyaW5nIH0+KHRoaXMuY29uZmxpY3RTZXJ2aWNlKSxcbiAgICAgICAgICAgIHRhcCgoeyByZXBvc2l0b3J5U3RhdHVzIH0pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVwb3NpdG9yeVN0YXR1cyAhPT0gQ29tbWl0U3RhdGUuQ09ORkxJQ1QpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25mbGljdFNlcnZpY2Uubm90aWZ5Q29uZmxpY3RTdGF0ZShHaXRDb25mbGljdFN0YXRlLk9LKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgKTtcbiAgICB9O1xuXG4gICAgY29tbWl0ID0gKCkgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8dm9pZD4oYCR7dGhpcy5yZXN0UmVzb3VyY2VVcmx9L2NvbW1pdGAsIHt9KS5waXBlKGhhbmRsZUVycm9yUmVzcG9uc2UodGhpcy5jb25mbGljdFNlcnZpY2UpKTtcbiAgICB9O1xuXG4gICAgcHVsbCA9ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8dm9pZD4oYCR7dGhpcy5yZXN0UmVzb3VyY2VVcmx9L3B1bGxgLCB7fSkucGlwZShoYW5kbGVFcnJvclJlc3BvbnNlKHRoaXMuY29uZmxpY3RTZXJ2aWNlKSk7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIFdlIGRvbid0IGNoZWNrIGZvciBjb25mbGljdCBlcnJvcnMgaGVyZSBvbiBwdXJwb3NlIVxuICAgICAqIFRoaXMgaXMgdGhlIG1ldGhvZCB0aGF0IGlzIHVzZWQgdG8gcmVzb2x2ZSBjb25mbGljdHMuXG4gICAgICovXG4gICAgcmVzZXRSZXBvc2l0b3J5ID0gKCkgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8dm9pZD4oYCR7dGhpcy5yZXN0UmVzb3VyY2VVcmx9L3Jlc2V0YCwge30pO1xuICAgIH07XG59XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgQ29kZUVkaXRvckJ1aWxkTG9nU2VydmljZSBleHRlbmRzIERvbWFpbkRlcGVuZGVudEVuZHBvaW50U2VydmljZSB7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgYnVpbGRMb2dTZXJ2aWNlOiBCdWlsZExvZ1NlcnZpY2UsXG4gICAgICAgIGh0dHA6IEh0dHBDbGllbnQsXG4gICAgICAgIGpoaVdlYnNvY2tldFNlcnZpY2U6IEpoaVdlYnNvY2tldFNlcnZpY2UsXG4gICAgICAgIGRvbWFpblNlcnZpY2U6IERvbWFpblNlcnZpY2UsXG4gICAgKSB7XG4gICAgICAgIHN1cGVyKGh0dHAsIGpoaVdlYnNvY2tldFNlcnZpY2UsIGRvbWFpblNlcnZpY2UpO1xuICAgIH1cblxuICAgIGdldEJ1aWxkTG9ncyA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgW2RvbWFpblR5cGUsIGRvbWFpblZhbHVlXSA9IHRoaXMuZG9tYWluO1xuICAgICAgICBpZiAoZG9tYWluVHlwZSA9PT0gRG9tYWluVHlwZS5QQVJUSUNJUEFUSU9OKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5idWlsZExvZ1NlcnZpY2UuZ2V0QnVpbGRMb2dzKGRvbWFpblZhbHVlLmlkISk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG9mKFtdKTtcbiAgICB9O1xufVxuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIENvZGVFZGl0b3JSZXBvc2l0b3J5RmlsZVNlcnZpY2UgZXh0ZW5kcyBEb21haW5EZXBlbmRlbnRFbmRwb2ludFNlcnZpY2UgaW1wbGVtZW50cyBJQ29kZUVkaXRvclJlcG9zaXRvcnlGaWxlU2VydmljZSwgT25EZXN0cm95IHtcbiAgICBmaWxlVXBkYXRlU3ViamVjdCA9IG5ldyBTdWJqZWN0PEZpbGVTdWJtaXNzaW9uPigpO1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBodHRwOiBIdHRwQ2xpZW50LFxuICAgICAgICBqaGlXZWJzb2NrZXRTZXJ2aWNlOiBKaGlXZWJzb2NrZXRTZXJ2aWNlLFxuICAgICAgICBkb21haW5TZXJ2aWNlOiBEb21haW5TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGNvbmZsaWN0U2VydmljZTogQ29kZUVkaXRvckNvbmZsaWN0U3RhdGVTZXJ2aWNlLFxuICAgICkge1xuICAgICAgICBzdXBlcihodHRwLCBqaGlXZWJzb2NrZXRTZXJ2aWNlLCBkb21haW5TZXJ2aWNlKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDYWxscyBuZ09uRGVzdHJveSBvZiBzdXBlciB0byB1bnN1YnNjcmliZSBmcm9tIGRvbWFpbi9wYXJ0aWNpcGF0aW9uIGNoYW5nZXMuXG4gICAgICovXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHN1cGVyLm5nT25EZXN0cm95KCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZG93bmxvYWRzIGEgZmlsZSBmcm9tIHRoZSByZXBvc2l0b3J5IHRvIHRoZSB1c2VycyBkZXZpY2UuXG4gICAgICogQHBhcmFtIGZpbGVOYW1lIHRoZSBuYW1lIG9mIHRoZSBmaWxlIGluIHRoZSByZXBvc2l0b3J5XG4gICAgICogQHBhcmFtIGRvd25sb2FkTmFtZSB0aGUgbmFtZSBvZiB0aGUgZmlsZSBhcyBzdWdnZXN0ZWQgdG8gdGhlIGJyb3dzZXJcbiAgICAgKi9cbiAgICBkb3dubG9hZEZpbGUoZmlsZU5hbWU6IHN0cmluZywgZG93bmxvYWROYW1lOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5odHRwXG4gICAgICAgICAgICAuZ2V0KGAke3RoaXMucmVzdFJlc291cmNlVXJsfS9maWxlYCwgeyBwYXJhbXM6IG5ldyBIdHRwUGFyYW1zKCkuc2V0KCdmaWxlJywgZmlsZU5hbWUpLCByZXNwb25zZVR5cGU6ICdibG9iJyB9KVxuICAgICAgICAgICAgLnBpcGUoaGFuZGxlRXJyb3JSZXNwb25zZSh0aGlzLmNvbmZsaWN0U2VydmljZSkpXG4gICAgICAgICAgICAuc3Vic2NyaWJlKChyZXMpID0+IHtcbiAgICAgICAgICAgICAgICBkb3dubG9hZEZpbGUocmVzLCBkb3dubG9hZE5hbWUpO1xuICAgICAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2FsbHMgc2V0RG9tYWluIG9mIHN1cGVyIGFuZCB1cGRhdGVzIGZpbGVVcGRhdGVVcmwuIElmIHRoaXMgc2VydmljZSBpcyB1c2VkIGF0IHRoZSB0aW1lIGNvbXBsZXRlIHVzYWdlIGFuZCB1bnN1YnNjcmliZS5cbiAgICAgKiBAcGFyYW0gZG9tYWluIC0gZGVmaW5lcyBuZXcgZG9tYWluIG9mIHN1cGVyLlxuICAgICAqL1xuICAgIHNldERvbWFpbihkb21haW46IERvbWFpbkNoYW5nZSkge1xuICAgICAgICBzdXBlci5zZXREb21haW4oZG9tYWluKTtcbiAgICAgICAgaWYgKHRoaXMuZmlsZVVwZGF0ZVN1YmplY3QpIHtcbiAgICAgICAgICAgIHRoaXMuZmlsZVVwZGF0ZVN1YmplY3QuY29tcGxldGUoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGdldFJlcG9zaXRvcnlDb250ZW50ID0gKGRvbWFpbj86IERvbWFpbkNoYW5nZSkgPT4ge1xuICAgICAgICBjb25zdCByZXN0UmVzb3VyY2VVcmwgPSBkb21haW4gPyB0aGlzLmNhbGN1bGF0ZVJlc3RSZXNvdXJjZVVSTChkb21haW4pIDogdGhpcy5yZXN0UmVzb3VyY2VVcmw7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PHsgW2ZpbGVOYW1lOiBzdHJpbmddOiBGaWxlVHlwZSB9PihgJHtyZXN0UmVzb3VyY2VVcmx9L2ZpbGVzYCkucGlwZShoYW5kbGVFcnJvclJlc3BvbnNlPHsgW2ZpbGVOYW1lOiBzdHJpbmddOiBGaWxlVHlwZSB9Pih0aGlzLmNvbmZsaWN0U2VydmljZSkpO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBHZXRzIHRoZSBmaWxlcyBvZiB0aGUgcmVwb3NpdG9yeSBhbmQgY2hlY2tzIHdoZXRoZXIgdGhleSB3ZXJlIGNoYW5nZWQgZHVyaW5nIGEgc3R1ZGVudCBwYXJ0aWNpcGF0aW9uLlxuICAgICAqL1xuICAgIGdldEZpbGVzV2l0aEluZm9ybWF0aW9uQWJvdXRDaGFuZ2UgPSAoZG9tYWluPzogRG9tYWluQ2hhbmdlKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlc3RSZXNvdXJjZVVybCA9IGRvbWFpbiA/IHRoaXMuY2FsY3VsYXRlUmVzdFJlc291cmNlVVJMKGRvbWFpbikgOiB0aGlzLnJlc3RSZXNvdXJjZVVybDtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8eyBbZmlsZU5hbWU6IHN0cmluZ106IGJvb2xlYW4gfT4oYCR7cmVzdFJlc291cmNlVXJsfS9maWxlcy1jaGFuZ2VgKS5waXBlKGhhbmRsZUVycm9yUmVzcG9uc2U8eyBbZmlsZU5hbWU6IHN0cmluZ106IGJvb2xlYW4gfT4odGhpcy5jb25mbGljdFNlcnZpY2UpKTtcbiAgICB9O1xuXG4gICAgZ2V0RmlsZSA9IChmaWxlTmFtZTogc3RyaW5nLCBkb21haW4/OiBEb21haW5DaGFuZ2UpID0+IHtcbiAgICAgICAgY29uc3QgcmVzdFJlc291cmNlVXJsID0gZG9tYWluID8gdGhpcy5jYWxjdWxhdGVSZXN0UmVzb3VyY2VVUkwoZG9tYWluKSA6IHRoaXMucmVzdFJlc291cmNlVXJsO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChgJHtyZXN0UmVzb3VyY2VVcmx9L2ZpbGVgLCB7IHBhcmFtczogbmV3IEh0dHBQYXJhbXMoKS5zZXQoJ2ZpbGUnLCBmaWxlTmFtZSksIHJlc3BvbnNlVHlwZTogJ3RleHQnIH0pLnBpcGUoXG4gICAgICAgICAgICBtYXAoKGRhdGEpID0+ICh7IGZpbGVDb250ZW50OiBkYXRhIH0pKSxcbiAgICAgICAgICAgIGhhbmRsZUVycm9yUmVzcG9uc2U8eyBmaWxlQ29udGVudDogc3RyaW5nIH0+KHRoaXMuY29uZmxpY3RTZXJ2aWNlKSxcbiAgICAgICAgKTtcbiAgICB9O1xuXG4gICAgZ2V0RmlsZUhlYWRlcnMgPSAoZmlsZU5hbWU6IHN0cmluZywgZG9tYWluPzogRG9tYWluQ2hhbmdlKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlc3RSZXNvdXJjZVVybCA9IGRvbWFpbiA/IHRoaXMuY2FsY3VsYXRlUmVzdFJlc291cmNlVVJMKGRvbWFpbikgOiB0aGlzLnJlc3RSZXNvdXJjZVVybDtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLmhlYWQ8QmxvYj4oYCR7cmVzdFJlc291cmNlVXJsfS9maWxlYCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnLCBwYXJhbXM6IG5ldyBIdHRwUGFyYW1zKCkuc2V0KCdmaWxlJywgZmlsZU5hbWUpIH0pXG4gICAgICAgICAgICAucGlwZShoYW5kbGVFcnJvclJlc3BvbnNlKHRoaXMuY29uZmxpY3RTZXJ2aWNlKSk7XG4gICAgfTtcblxuICAgIGdldEZpbGVzV2l0aENvbnRlbnQgPSAoZG9tYWluPzogRG9tYWluQ2hhbmdlKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlc3RSZXNvdXJjZVVybCA9IGRvbWFpbiA/IHRoaXMuY2FsY3VsYXRlUmVzdFJlc291cmNlVVJMKGRvbWFpbikgOiB0aGlzLnJlc3RSZXNvdXJjZVVybDtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQoYCR7cmVzdFJlc291cmNlVXJsfS9maWxlcy1jb250ZW50YCkucGlwZShoYW5kbGVFcnJvclJlc3BvbnNlPHsgW2ZpbGVOYW1lOiBzdHJpbmddOiBzdHJpbmcgfT4odGhpcy5jb25mbGljdFNlcnZpY2UpKTtcbiAgICB9O1xuXG4gICAgY3JlYXRlRmlsZSA9IChmaWxlTmFtZTogc3RyaW5nKSA9PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDx2b2lkPihgJHt0aGlzLnJlc3RSZXNvdXJjZVVybH0vZmlsZWAsICcnLCB7IHBhcmFtczogbmV3IEh0dHBQYXJhbXMoKS5zZXQoJ2ZpbGUnLCBmaWxlTmFtZSkgfSkucGlwZShoYW5kbGVFcnJvclJlc3BvbnNlKHRoaXMuY29uZmxpY3RTZXJ2aWNlKSk7XG4gICAgfTtcblxuICAgIGNyZWF0ZUZvbGRlciA9IChmb2xkZXJOYW1lOiBzdHJpbmcpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PHZvaWQ+KGAke3RoaXMucmVzdFJlc291cmNlVXJsfS9mb2xkZXJgLCAnJywgeyBwYXJhbXM6IG5ldyBIdHRwUGFyYW1zKCkuc2V0KCdmb2xkZXInLCBmb2xkZXJOYW1lKSB9KS5waXBlKGhhbmRsZUVycm9yUmVzcG9uc2UodGhpcy5jb25mbGljdFNlcnZpY2UpKTtcbiAgICB9O1xuXG4gICAgdXBkYXRlRmlsZUNvbnRlbnQgPSAoZmlsZU5hbWU6IHN0cmluZywgZmlsZUNvbnRlbnQ6IHN0cmluZykgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAucHV0KGAke3RoaXMucmVzdFJlc291cmNlVXJsfS9maWxlYCwgZmlsZUNvbnRlbnQsIHtcbiAgICAgICAgICAgICAgICBwYXJhbXM6IG5ldyBIdHRwUGFyYW1zKCkuc2V0KCdmaWxlJywgZmlsZU5hbWUpLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5waXBlKGhhbmRsZUVycm9yUmVzcG9uc2UodGhpcy5jb25mbGljdFNlcnZpY2UpKTtcbiAgICB9O1xuXG4gICAgLyoqIENhbGwgdG8gc2VydmVyIHRvIHVwZGF0ZSBmaWxlcy5cbiAgICAgKiBDaGVja3MgYWxsIHJldHVybmVkIGZpbGVzIHN1Ym1pc3Npb25zIGZvciBzdWJtaXNzaW9uIGVycm9ycywgc2VlIHtAbGluayBjaGVja0lmU3VibWlzc2lvbklzRXJyb3J9XG4gICAgICogQ3VycmVudGx5IHdlIG9ubHkgaGFuZGxlIHtAbGluayBHaXRDb25mbGljdFN0YXRlI0NIRUNLT1VUX0NPTkZMSUNUfVxuICAgICAqXG4gICAgICogQHBhcmFtIGZpbGVVcGRhdGVzIHRoZSBBcnJheSBvZiB1cGRhdGVkIGZpbGVzXG4gICAgICogQHBhcmFtIHRoZW5Db21taXQgaW5kaWNhdGVzIHRoZSBzZXJ2ZXIgdG8gYWxzbyBjb21taXQgdGhlIHNhdmVkIGNoYW5nZXNcbiAgICAgKi9cbiAgICB1cGRhdGVGaWxlcyhmaWxlVXBkYXRlczogQXJyYXk8eyBmaWxlTmFtZTogc3RyaW5nOyBmaWxlQ29udGVudDogc3RyaW5nIH0+LCB0aGVuQ29tbWl0ID0gZmFsc2UpIHtcbiAgICAgICAgaWYgKHRoaXMuZmlsZVVwZGF0ZVN1YmplY3QpIHtcbiAgICAgICAgICAgIHRoaXMuZmlsZVVwZGF0ZVN1YmplY3QuY29tcGxldGUoKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmZpbGVVcGRhdGVTdWJqZWN0ID0gbmV3IFN1YmplY3Q8RmlsZVN1Ym1pc3Npb24+KCk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBcbiAgICAgICAgICAgIC5wdXQ8RmlsZVN1Ym1pc3Npb24+KGAke3RoaXMucmVzdFJlc291cmNlVXJsfS9maWxlc2AsIGZpbGVVcGRhdGVzLCB7XG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7IGNvbW1pdDogdGhlbkNvbW1pdCA/ICd5ZXMnIDogJ25vJyB9LFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIGhhbmRsZUVycm9yUmVzcG9uc2UodGhpcy5jb25mbGljdFNlcnZpY2UpLFxuICAgICAgICAgICAgICAgIHRhcCgoZmlsZVN1Ym1pc3Npb246IEZpbGVTdWJtaXNzaW9uIHwgRmlsZVN1Ym1pc3Npb25FcnJvcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoY2hlY2tJZlN1Ym1pc3Npb25Jc0Vycm9yKGZpbGVTdWJtaXNzaW9uKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5maWxlVXBkYXRlU3ViamVjdC5lcnJvcihmaWxlU3VibWlzc2lvbik7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlsZVN1Ym1pc3Npb24uZXJyb3IgPT09IFJlcG9zaXRvcnlFcnJvci5DSEVDS09VVF9DT05GTElDVCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmxpY3RTZXJ2aWNlLm5vdGlmeUNvbmZsaWN0U3RhdGUoR2l0Q29uZmxpY3RTdGF0ZS5DSEVDS09VVF9DT05GTElDVCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5maWxlVXBkYXRlU3ViamVjdC5uZXh0KGZpbGVTdWJtaXNzaW9uKTtcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICk7XG4gICAgfVxuXG4gICAgcmVuYW1lRmlsZSA9IChjdXJyZW50RmlsZVBhdGg6IHN0cmluZywgbmV3RmlsZW5hbWU6IHN0cmluZykgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8dm9pZD4oYCR7dGhpcy5yZXN0UmVzb3VyY2VVcmx9L3JlbmFtZS1maWxlYCwgeyBjdXJyZW50RmlsZVBhdGgsIG5ld0ZpbGVuYW1lIH0pLnBpcGUoaGFuZGxlRXJyb3JSZXNwb25zZSh0aGlzLmNvbmZsaWN0U2VydmljZSkpO1xuICAgIH07XG5cbiAgICBkZWxldGVGaWxlID0gKGZpbGVOYW1lOiBzdHJpbmcpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5kZWxldGU8dm9pZD4oYCR7dGhpcy5yZXN0UmVzb3VyY2VVcmx9L2ZpbGVgLCB7IHBhcmFtczogbmV3IEh0dHBQYXJhbXMoKS5zZXQoJ2ZpbGUnLCBmaWxlTmFtZSkgfSkucGlwZShoYW5kbGVFcnJvclJlc3BvbnNlKHRoaXMuY29uZmxpY3RTZXJ2aWNlKSk7XG4gICAgfTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLGtCQUFrQjtBQUUzQixTQUFTLFlBQVksa0JBQWdDO0FBRXJELFNBQVMsV0FBVztBQUNwQixTQUFTLFFBQVEsYUFBYTs7O0FBTDlCLElBaURhO0FBakRiOztBQU9BO0FBQ0E7QUFXQTtBQUlBOzs7QUEwQk0sSUFBTyw2QkFBUCxNQUFPLDRCQUEwQjtNQUl2QjtNQUNBO01BQ0E7TUFMTCxjQUFjO01BRXJCLFlBQ1ksTUFDQSxpQkFDQSxhQUF3QjtBQUZ4QixhQUFBLE9BQUE7QUFDQSxhQUFBLGtCQUFBO0FBQ0EsYUFBQSxjQUFBO01BQ1Q7TUFNSCxlQUFlLHFCQUF3QztBQUNuRCxZQUFJLE9BQU8sS0FBSyxzQkFBc0IsbUJBQW1CO0FBQ3pELGVBQU8sZ0JBQWdCLGtEQUFrRCxJQUFJO0FBQzdFLGFBQUssYUFBYSxnQkFBZ0IsNEJBQTRCLElBQUk7QUFDbEUsZUFBTyxLQUFLLEtBQ1AsS0FBMEIsS0FBSyxjQUFjLFVBQVUsTUFBTSxFQUFFLFNBQVMsV0FBVSxDQUFFLEVBQ3BGLEtBQUssSUFBSSxDQUFDLFFBQTRCLEtBQUsseUNBQXlDLEdBQUcsQ0FBQyxDQUFDO01BQ2xHO01BTUEsd0JBQXdCLFlBQWtCO0FBQ3RDLGVBQU8sS0FBSyxLQUFLLElBQVksR0FBRyxLQUFLLFdBQVcsSUFBSSxVQUFVLG1CQUFtQixFQUFFLGNBQWMsT0FBTSxDQUFFO01BQzdHO01BYUEsTUFBTSxZQUFvQixTQUF3QztBQUM5RCxlQUFPLEtBQUssS0FBSyxJQUFJLEdBQUcsS0FBSyxXQUFXLElBQUksVUFBVSxVQUFVLFNBQVMsRUFBRSxjQUFjLE9BQU0sQ0FBRTtNQUNyRztNQVFBLGdCQUFnQixZQUFvQixTQUEyQjtBQUMzRCxlQUFPLEtBQUssS0FDUCxJQUErQyxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUscUJBQXFCO1VBQ2xHLFNBQVM7VUFDVCxRQUFRLG1CQUNELFNBQVMsU0FBUTtTQUUzQixFQUNBLEtBQUssSUFBSSxDQUFDLGFBQXNFLFNBQVMsSUFBSyxDQUFDO01BQ3hHO01BT0EsMkJBQTJCLFlBQW9CLFNBQTJCO0FBQ3RFLGVBQU8sS0FBSyxLQUFLLElBQUksR0FBRyxLQUFLLFdBQVcsSUFBSSxVQUFVLGtDQUFrQztVQUNwRixTQUFTO1VBQ1QsY0FBYztVQUNkLFFBQVEsbUJBQ0QsU0FBUyxTQUFRO1NBRTNCO01BQ0w7TUFPQSwwQkFBMEIsWUFBa0I7QUFDeEMsZUFBTyxLQUFLLEtBQ1AsSUFBK0MsR0FBRyxLQUFLLFdBQVcsSUFBSSxVQUFVLHNCQUFzQjtVQUNuRyxTQUFTO1NBQ1osRUFDQSxLQUFLLElBQUksQ0FBQyxhQUFzRSxTQUFTLElBQUssQ0FBQztNQUN4RztNQU1BLGlDQUFpQyxZQUFrQjtBQUMvQyxlQUFPLEtBQUssS0FBSyxJQUFJLEdBQUcsS0FBSyxXQUFXLElBQUksVUFBVSw2QkFBNkIsRUFBRSxjQUFjLE9BQU0sQ0FBRTtNQUMvRztNQWFBLGVBQWUsa0NBQXVELG9CQUE2QixnQkFBdUI7QUFDdEgsY0FBTSxVQUFVLG9CQUFvQixFQUFFLG9CQUFvQixlQUFjLENBQUU7QUFDMUUsY0FBTSxXQUFXLGdCQUFnQixrREFBa0QsZ0NBQWdDO0FBQ25ILGlCQUFTLGFBQWEsZ0JBQWdCLDRCQUE0QixRQUFRO0FBQzFFLGVBQU8sS0FBSyxLQUNQLEtBQTBCLEdBQUcsS0FBSyxXQUFXLFdBQVcsaUNBQWlDLEVBQUUsSUFBSSxVQUFVO1VBQ3RHLFFBQVE7VUFDUixTQUFTO1NBQ1osRUFDQSxLQUFLLElBQUksQ0FBQyxRQUE0QixLQUFLLHlDQUF5QyxHQUFHLENBQUMsQ0FBQztNQUNsRztNQU9BLE9BQU8scUJBQTBDLEtBQVM7QUFDdEQsY0FBTSxVQUFVLG9CQUFvQixHQUFHO0FBQ3ZDLFlBQUksT0FBTyxLQUFLLHNCQUFzQixtQkFBbUI7QUFDekQsZUFBTyxnQkFBZ0Isa0RBQWtELElBQUk7QUFDN0UsYUFBSyxhQUFhLGdCQUFnQiw0QkFBNEIsSUFBSTtBQUNsRSxlQUFPLEtBQUssS0FDUCxJQUF5QixLQUFLLGFBQWEsTUFBTSxFQUFFLFFBQVEsU0FBUyxTQUFTLFdBQVUsQ0FBRSxFQUN6RixLQUFLLElBQUksQ0FBQyxRQUE0QixLQUFLLHlDQUF5QyxHQUFHLENBQUMsQ0FBQztNQUNsRztNQU9BLGVBQWUscUJBQTBDLEtBQVM7QUFDOUQsY0FBTSxVQUFVLG9CQUFvQixHQUFHO0FBQ3ZDLGNBQU0sT0FBTyxLQUFLLHNCQUFzQixtQkFBbUI7QUFDM0QsZUFBTyxLQUFLLEtBQ1AsSUFBeUIsR0FBRyxLQUFLLFdBQVcsYUFBYSxNQUFNLEVBQUUsUUFBUSxTQUFTLFNBQVMsV0FBVSxDQUFFLEVBQ3ZHLEtBQUssSUFBSSxDQUFDLFFBQTRCLEtBQUsseUNBQXlDLEdBQUcsQ0FBQyxDQUFDO01BQ2xHO01BUUEsdUJBQXVCLHVCQUErQixrQkFBMEIsS0FBUztBQUNyRixjQUFNLFVBQVUsb0JBQW9CLEdBQUc7QUFDdkMsZUFBTyxLQUFLLEtBQ1AsTUFBMkIsR0FBRyxLQUFLLFdBQVcsSUFBSSxxQkFBcUIsc0JBQXNCLGtCQUFrQjtVQUM1RyxRQUFRO1VBQ1IsU0FBUztTQUNaLEVBQ0EsS0FBSyxJQUFJLENBQUMsUUFBNEIsS0FBSyx5Q0FBeUMsR0FBRyxDQUFDLENBQUM7TUFDbEc7TUFPQSxLQUFLLHVCQUErQixnQ0FBeUMsT0FBSztBQUM5RSxlQUFPLEtBQUssS0FDUCxJQUF5QixHQUFHLEtBQUssV0FBVyxJQUFJLHFCQUFxQixJQUFJO1VBQ3RFLFNBQVM7VUFDVCxRQUFRLEVBQUUsOEJBQTREO1NBQ3pFLEVBQ0EsS0FBSyxJQUFJLENBQUMsUUFBNEIsS0FBSyx5Q0FBeUMsR0FBRyxDQUFDLENBQUM7TUFDbEc7TUFNQSxtREFBbUQsdUJBQTZCO0FBQzVFLGVBQU8sS0FBSyxLQUNQLElBQXlCLEdBQUcsS0FBSyxXQUFXLElBQUkscUJBQXFCLHdCQUF3QixFQUFFLFNBQVMsV0FBVSxDQUFFLEVBQ3BILEtBQUssSUFBSSxDQUFDLFFBQTRCLEtBQUsseUNBQXlDLEdBQUcsQ0FBQyxDQUFDO01BQ2xHO01BT0EseUNBQXlDLHVCQUErQix3QkFBd0IsT0FBSztBQUNqRyxZQUFJLFNBQVMsSUFBSSxXQUFVO0FBQzNCLGlCQUFTLE9BQU8sSUFBSSx5QkFBeUIsc0JBQXNCLFNBQVEsQ0FBRTtBQUM3RSxlQUFPLEtBQUssS0FDUCxJQUF5QixHQUFHLEtBQUssV0FBVyxJQUFJLHFCQUFxQiw2Q0FBNkM7VUFDL0c7VUFDQSxTQUFTO1NBQ1osRUFDQSxLQUNHLElBQUksQ0FBQyxRQUEyQjtBQUM1QixjQUFJLElBQUksUUFBUSx1QkFBdUI7QUFFbkMsa0JBQU0sc0JBQXNCLElBQUksS0FBSyx1QkFBdUI7QUFDNUQsaUJBQUssNkJBQTZCLG1CQUFtQjtBQUNyRCxrQkFBTSxzQkFBc0IsSUFBSSxLQUFLLHVCQUF1QjtBQUM1RCxpQkFBSyw2QkFBNkIsbUJBQW1CO0FBRXJELGlCQUFLLHlDQUF5QyxHQUFHOztBQUVyRCxpQkFBTztRQUNYLENBQUMsQ0FBQztNQUVkO01BTUEseURBQXlELHVCQUE2QjtBQUNsRixlQUFPLEtBQUsseUNBQXlDLHVCQUF1QixJQUFJLEVBQUUsS0FDOUUsSUFBSSxDQUFDLGFBQVk7QUFDYixjQUFJLFNBQVMsTUFBTTtBQUNmLGlCQUFLLHNDQUFzQyxTQUFTLElBQUk7O0FBRTVELGlCQUFPO1FBQ1gsQ0FBQyxDQUFDO01BRVY7TUFFUSxzQ0FBc0MscUJBQXdDO0FBQ2xGLFlBQUksb0JBQW9CLHVCQUF1QjtBQUMzQyxnQkFBTSx1QkFBdUIsS0FBSyxnQkFBZ0Isb0JBQW9CLHFCQUFxQjtBQUMzRixjQUFJLHNCQUFzQjtBQUN0QixnQ0FBb0Isc0JBQXNCLFVBQVUsQ0FBQyxvQkFBb0I7O0FBRzdFLDhCQUFvQixzQkFBc0Isc0JBQXNCOztBQUdwRSxZQUFJLG9CQUFvQix1QkFBdUI7QUFDM0MsZ0JBQU0sdUJBQXVCLEtBQUssZ0JBQWdCLG9CQUFvQixxQkFBcUI7QUFDM0YsY0FBSSxzQkFBc0I7QUFDdEIsZ0NBQW9CLHNCQUFzQixVQUFVLENBQUMsb0JBQW9COztBQUc3RSw4QkFBb0Isc0JBQXNCLHNCQUFzQjs7TUFFeEU7TUFPQSxnQkFBZ0IsZUFBNEI7QUFDeEMsY0FBTSxjQUFjLGNBQWM7QUFDbEMsWUFBSSxDQUFDLGVBQWUsWUFBWSxXQUFXLEdBQUc7QUFDMUM7O0FBSUosYUFBSyxZQUFZLGVBQWUsYUFBYSxrQkFBa0IsSUFBSTtBQUNuRSxjQUFNLFVBQVUsWUFBWSxLQUFJLEVBQUcsS0FBSSxHQUFJO0FBQzNDLFlBQUksV0FBVyxRQUFRLFNBQVMsR0FBRztBQUMvQixpQkFBTyxRQUFRLEtBQUk7O01BRTNCO01BT1EsNkJBQTZCLGFBQXFDO0FBQ3RFLFlBQUksYUFBYTtBQUNiLHNCQUFZLFFBQVEsQ0FBQyxlQUFjO0FBQy9CLGdCQUFJLFdBQVcsU0FBUztBQUNwQix5QkFBVyxRQUFRLFFBQVEsQ0FBQyxXQUFVO0FBQ2xDLHVCQUFPLGFBQWE7Y0FDeEIsQ0FBQzs7VUFFVCxDQUFDOztNQUVUO01BT0Esb0NBQW9DLFlBQWtCO0FBQ2xELGVBQU8sS0FBSyxLQUFLLElBQXlDLEdBQUcsS0FBSyxXQUFXLElBQUksVUFBVSxvQkFBb0IsRUFBRSxTQUFTLFdBQVUsQ0FBRTtNQUMxSTtNQU1BLE1BQU0sS0FBUztBQUNYLGNBQU0sVUFBVSxvQkFBb0IsR0FBRztBQUN2QyxlQUFPLEtBQUssS0FDUCxJQUEyQixLQUFLLGFBQWEsRUFBRSxRQUFRLFNBQVMsU0FBUyxXQUFVLENBQUUsRUFDckYsS0FBSyxJQUFJLENBQUMsUUFBaUMsS0FBSyxnQkFBZ0IsbUNBQW1DLEdBQUcsQ0FBQyxDQUFDO01BQ2pIO01BUUEsT0FBTyx1QkFBK0IsOEJBQXVDLDJCQUFrQztBQUMzRyxZQUFJLFNBQVMsSUFBSSxXQUFVO0FBQzNCLGlCQUFTLE9BQU8sSUFBSSxnQ0FBZ0MsNkJBQTZCLFNBQVEsQ0FBRTtBQUMzRixpQkFBUyxPQUFPLElBQUksNkJBQTZCLDBCQUEwQixTQUFRLENBQUU7QUFDckYsZUFBTyxLQUFLLEtBQUssT0FBTyxHQUFHLEtBQUssV0FBVyxJQUFJLHFCQUFxQixJQUFJLEVBQUUsUUFBUSxTQUFTLFdBQVUsQ0FBRTtNQUMzRztNQU9BLHNCQUFzQixVQUE2QjtBQUMvQyxjQUFNLE9BQU8saUNBQ04sZ0JBQWdCLCtCQUErQixRQUFRLElBRGpEO1VBRVQsNENBQTRDLHNCQUFzQixTQUFTLDBDQUEwQzs7QUFJekgsWUFBSSxLQUFLLHVCQUF1QjtBQUM1QixlQUFLLHdCQUF3QixNQUFNLEtBQUssdUJBQXVCLENBQUMsWUFBWSxTQUFTLENBQUM7O0FBRTFGLFlBQUksS0FBSyx1QkFBdUI7QUFDNUIsZUFBSyx3QkFBd0IsTUFBTSxLQUFLLHVCQUF1QixDQUFDLFlBQVksU0FBUyxDQUFDOztBQUcxRixlQUFPO01BQ1g7TUFRQSxPQUFPLGtEQUFrRCxRQUEwQjtBQUMvRSxjQUFNLE1BQU0sZ0JBQWdCLHVDQUF1QyxNQUFNO0FBQ3pFLFlBQUksQ0FBQyxJQUFJLE1BQU07QUFDWCxpQkFBTzs7QUFFWCxZQUFJLEtBQUssNkNBQTZDLHNCQUFzQixJQUFJLEtBQUssMENBQTBDO0FBQy9ILGVBQU87TUFDWDtNQU1BLHNCQUFzQixZQUFrQjtBQUNwQyxlQUFPLEtBQUssS0FBSyxJQUFTLEdBQUcsS0FBSyxXQUFXLElBQUksVUFBVSw0QkFBNEIsQ0FBQSxHQUFJLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDdEg7TUFNQSxvQkFBb0IsWUFBa0I7QUFDbEMsZUFBTyxLQUFLLEtBQUssSUFBUyxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUsMEJBQTBCLENBQUEsR0FBSSxFQUFFLFNBQVMsV0FBVSxDQUFFO01BQ3BIO01BUUEsMkJBQ0ksWUFDQSxnQkFDQSx1QkFBeUM7QUFFekMsWUFBSSxtQkFBbUIsZUFBZSwwQkFBMEIsUUFBVztBQUN2RSxpQkFBTyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUsMkNBQTJDLHFCQUFxQixJQUFJO1lBQ3RILFNBQVM7WUFDVCxjQUFjO1dBQ2pCO2VBQ0U7QUFDSCxpQkFBTyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUsaUNBQWlDLGNBQWMsSUFBSTtZQUNyRyxTQUFTO1lBQ1QsY0FBYztXQUNqQjs7TUFFVDtNQU1BLHlCQUF5QixZQUFrQjtBQUN2QyxlQUFPLEtBQUssS0FBSyxJQUFJLEdBQUcsS0FBSyxXQUFXLElBQUksVUFBVSwrQkFBK0I7VUFDakYsU0FBUztVQUNULGNBQWM7U0FDakI7TUFDTDtNQU9BLGlDQUFpQyxZQUFvQixjQUFxQjtBQUN0RSxZQUFJLFNBQVMsSUFBSSxXQUFVO0FBQzNCLGlCQUFTLE9BQU8sSUFBSSxnQkFBZ0IsYUFBYSxTQUFRLENBQUU7QUFDM0QsZUFBTyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUsd0NBQXdDO1VBQzFGO1VBQ0EsU0FBUztVQUNULGNBQWM7U0FDakI7TUFDTDtNQVFBLG9CQUFvQixxQkFBMEMsS0FBUztBQUNuRSxjQUFNLFVBQVUsb0JBQW9CLEdBQUc7QUFDdkMsWUFBSSxPQUFPLEtBQUssc0JBQXNCLG1CQUFtQjtBQUN6RCxlQUFPLGdCQUFnQixrREFBa0QsSUFBSTtBQUM3RSxhQUFLLGFBQWEsZ0JBQWdCLDRCQUE0QixJQUFJO0FBQ2xFLGVBQU8sS0FBSyxLQUNQLElBQXlCLEdBQUcsS0FBSyxXQUFXLElBQUksb0JBQW9CLEVBQUUsZ0JBQWdCLE1BQU07VUFDekYsUUFBUTtVQUNSLFNBQVM7U0FDWixFQUNBLEtBQUssSUFBSSxDQUFDLFFBQTRCLEtBQUssZ0JBQWdCLDhCQUE4QixHQUFHLENBQUMsQ0FBQztNQUN2RztNQVNRLHlDQUF5QyxhQUErQjtBQUM1RSxvQ0FBMkIsa0RBQWtELFdBQVc7QUFDeEYsd0JBQWdCLG9DQUFvQyxXQUFXO0FBQy9ELGFBQUssZ0JBQWdCLDBDQUEwQyxXQUFXO0FBQzFFLGFBQUssZ0JBQWdCLGdDQUFnQyxhQUFhLElBQUk7QUFDdEUsZUFBTztNQUNYO01BT0EsOENBQThDLFlBQWtCO0FBQzVELGVBQU8sS0FBSyxLQUNQLElBQUksR0FBRyxLQUFLLFdBQVcsSUFBSSxVQUFVLFVBQVUsRUFBRSxTQUFTLFdBQVUsQ0FBRSxFQUN0RSxLQUFLLElBQUksQ0FBQyxRQUEyRCxJQUFJLFFBQVEsQ0FBQSxDQUFFLENBQUM7TUFDN0Y7TUFPQSxjQUFjLFlBQWtCO0FBQzVCLGVBQU8sS0FBSyxLQUNQLElBQXNDLEdBQUcsS0FBSyxXQUFXLElBQUksVUFBVSxnQkFBZ0IsRUFBRSxTQUFTLFdBQVUsQ0FBRSxFQUM5RyxLQUFLLElBQUksQ0FBQyxRQUF3RCxJQUFJLFFBQVEsTUFBUyxDQUFDO01BQ2pHO01BUUEsNEJBQTRCLFlBQW9CLG1CQUEyQixtQkFBeUI7QUFDaEcsZUFBTyxLQUFLLEtBQ1AsSUFBc0MsR0FBRyxLQUFLLFdBQVcsSUFBSSxVQUFVLGdCQUFnQixpQkFBaUIsZ0JBQWdCLGlCQUFpQixJQUFJLEVBQUUsU0FBUyxXQUFVLENBQUUsRUFDcEssS0FBSyxJQUFJLENBQUMsUUFBd0QsSUFBSSxRQUFRLE1BQVMsQ0FBQztNQUNqRztNQU9BLHVDQUF1QyxZQUFvQixjQUFvQjtBQUMzRSxlQUFPLEtBQUssS0FDUCxJQUFzQyxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUsZ0JBQWdCLFlBQVksOEJBQThCLEVBQUUsU0FBUyxXQUFVLENBQUUsRUFDeEosS0FBSyxJQUFJLENBQUMsUUFBd0QsSUFBSSxRQUFRLE1BQVMsQ0FBQztNQUNqRztNQU1BLG9DQUFvQyxZQUFrQjtBQUNsRCxlQUFPLEtBQUssS0FBSyxJQUFvQixHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUsZ0NBQWdDO01BQzFHO01BTUEsZ0NBQWdDLFlBQWtCO0FBQzlDLGVBQU8sS0FBSyxLQUFLLElBQW9CLEdBQUcsS0FBSyxXQUFXLElBQUksVUFBVSxnQ0FBZ0M7TUFDMUc7TUFLQSwwQ0FBMEMsWUFBa0I7QUFDeEQsZUFBTyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUseUJBQXlCLEVBQUUsS0FDN0UsSUFBSSxDQUFDLFFBQTBCO0FBRzNCLGlCQUFPLE9BQU8sSUFBSSxJQUFJLE9BQU8sUUFBUSxHQUFHLENBQUM7UUFDN0MsQ0FBQyxDQUFDO01BRVY7TUFLQSwwQ0FBMEMsWUFBa0I7QUFDeEQsZUFBTyxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUseUJBQXlCLEVBQUUsS0FDN0UsSUFBSSxDQUFDLFFBQTBCO0FBRzNCLGlCQUFPLE9BQU8sSUFBSSxJQUFJLE9BQU8sUUFBUSxHQUFHLENBQUM7UUFDN0MsQ0FBQyxDQUFDO01BRVY7TUFFQSxxQkFBcUIsWUFBa0I7QUFDbkMsZUFBTyxLQUFLLEtBQUssSUFBYyxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUsYUFBYTtNQUNqRjtNQUVBLHdCQUF3QixZQUFrQjtBQUN0QyxlQUFPLEtBQUssS0FBSyxJQUFvQixHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUsaUJBQWlCO01BQzNGO01BRUEsZ0NBQWdDLFlBQWtCO0FBQzlDLGVBQU8sS0FBSyxLQUFLLEtBQXlDLEdBQUcsS0FBSyxXQUFXLElBQUksVUFBVSxnQ0FBZ0MsSUFBSTtNQUNuSTtNQUVBLGdDQUFnQyxZQUFrQjtBQUM5QyxlQUFPLEtBQUssS0FBSyxLQUF5QyxHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUsZ0NBQWdDLElBQUk7TUFDbkk7TUFFQSxnQkFBZ0IsWUFBa0I7QUFDOUIsZUFBTyxLQUFLLEtBQUssSUFBbUMsNkJBQTZCLFVBQVUsYUFBYTtNQUM1RztNQUVBLHNCQUFzQixZQUFrQjtBQUNwQyxlQUFPLEtBQUssS0FBSyxJQUEyQixHQUFHLEtBQUssV0FBVyxJQUFJLFVBQVUsdUJBQXVCO01BQ3hHO01BR0EsZUFBZSxVQUErQixVQUFnQjtBQUMxRCxZQUFJLE9BQU8sS0FBSyxzQkFBc0IsUUFBUTtBQUM5QyxlQUFPLGdCQUFnQixrREFBa0QsSUFBSTtBQUM3RSxhQUFLLGFBQWEsZ0JBQWdCLDRCQUE0QixJQUFJO0FBQ2xFLGNBQU0sV0FBVyxJQUFJLFNBQVE7QUFDN0IsaUJBQVMsT0FBTyxRQUFRLFNBQVMsZ0JBQWlCO0FBQ2xELGNBQU0sZUFBZSxJQUFJLEtBQUssQ0FBQyxLQUFLLFVBQVUsSUFBSSxDQUFDLEdBQUcsRUFBRSxNQUFNLG1CQUFrQixDQUFFO0FBQ2xGLGlCQUFTLE9BQU8sdUJBQXVCLFlBQVk7QUFDbkQsY0FBTSxNQUFNLGVBQWUsUUFBUTtBQUNuQyxlQUFPLEtBQUssS0FDUCxLQUEwQixLQUFLLFVBQVUsRUFBRSxTQUFTLFdBQVUsQ0FBRSxFQUNoRSxLQUFLLElBQUksQ0FBQyxRQUE0QixLQUFLLHlDQUF5QyxHQUFHLENBQUMsQ0FBQztNQUNsRzs7eUJBdmtCUyw2QkFBMEIsc0JBQUEsYUFBQSxHQUFBLHNCQUFBLGVBQUEsR0FBQSxzQkFBQSxXQUFBLENBQUE7TUFBQTttRUFBMUIsNkJBQTBCLFNBQTFCLDRCQUEwQixXQUFBLFlBRGIsT0FBTSxDQUFBOzs7Ozs7QUN4Q2hDLElBQVksVUFLVSxZQUVULGtCQVNBLGtCQVNBLGtCQWVELFlBUUEsaUJBU0EsYUFZQSxhQVVBLFlBY0Esa0JBUUEsZUFPQztBQTVHYjs7QUFBQSxLQUFBLFNBQVlBLFdBQVE7QUFDaEIsTUFBQUEsVUFBQSxNQUFBLElBQUE7QUFDQSxNQUFBQSxVQUFBLFFBQUEsSUFBQTtJQUNKLEdBSFksYUFBQSxXQUFRLENBQUEsRUFBQTtBQUtkLElBQWdCLGFBQWhCLE1BQTBCOztBQUUxQixJQUFPLG1CQUFQLGNBQWdDLFdBQVU7TUFFakM7TUFDQTtNQUZYLFlBQ1csVUFDQSxVQUFnQjtBQUV2QixjQUFLO0FBSEUsYUFBQSxXQUFBO0FBQ0EsYUFBQSxXQUFBO01BR1g7O0FBR0UsSUFBTyxtQkFBUCxjQUFnQyxXQUFVO01BRWpDO01BQ0E7TUFGWCxZQUNXLFVBQ0EsVUFBZ0I7QUFFdkIsY0FBSztBQUhFLGFBQUEsV0FBQTtBQUNBLGFBQUEsV0FBQTtNQUdYOztBQUdFLElBQU8sbUJBQVAsY0FBZ0MsV0FBVTtNQUVqQztNQUNBO01BQ0E7TUFIWCxZQUNXLFVBQ0EsYUFDQSxhQUFtQjtBQUUxQixjQUFLO0FBSkUsYUFBQSxXQUFBO0FBQ0EsYUFBQSxjQUFBO0FBQ0EsYUFBQSxjQUFBO01BR1g7O0FBUUosS0FBQSxTQUFZQyxhQUFVO0FBQ2xCLE1BQUFBLFlBQUEsZUFBQSxJQUFBO0FBQ0EsTUFBQUEsWUFBQSxpQkFBQSxJQUFBO0lBQ0osR0FIWSxlQUFBLGFBQVUsQ0FBQSxFQUFBO0FBUXRCLEtBQUEsU0FBWUMsa0JBQWU7QUFDdkIsTUFBQUEsaUJBQUEsbUJBQUEsSUFBQTtJQUNKLEdBRlksb0JBQUEsa0JBQWUsQ0FBQSxFQUFBO0FBUzNCLEtBQUEsU0FBWUMsY0FBVztBQUNuQixNQUFBQSxhQUFBLFdBQUEsSUFBQTtBQUNBLE1BQUFBLGFBQUEsd0JBQUEsSUFBQTtBQUNBLE1BQUFBLGFBQUEsT0FBQSxJQUFBO0FBQ0EsTUFBQUEsYUFBQSxxQkFBQSxJQUFBO0FBQ0EsTUFBQUEsYUFBQSxZQUFBLElBQUE7QUFDQSxNQUFBQSxhQUFBLFVBQUEsSUFBQTtJQUNKLEdBUFksZ0JBQUEsY0FBVyxDQUFBLEVBQUE7QUFZdkIsS0FBQSxTQUFZQyxjQUFXO0FBQ25CLE1BQUFBLGFBQUEsT0FBQSxJQUFBO0FBQ0EsTUFBQUEsYUFBQSxpQkFBQSxJQUFBO0FBQ0EsTUFBQUEsYUFBQSxRQUFBLElBQUE7QUFDQSxNQUFBQSxhQUFBLFlBQUEsSUFBQTtJQUNKLEdBTFksZ0JBQUEsY0FBVyxDQUFBLEVBQUE7QUFVdkIsS0FBQSxTQUFZQyxhQUFVO0FBQ2xCLE1BQUFBLFlBQUEsY0FBQSxJQUFBO0FBQ0EsTUFBQUEsWUFBQSxlQUFBLElBQUE7QUFDQSxNQUFBQSxZQUFBLGFBQUEsSUFBQTtBQUNBLE1BQUFBLFlBQUEsUUFBQSxJQUFBO0lBQ0osR0FMWSxlQUFBLGFBQVUsQ0FBQSxFQUFBO0FBY3RCLEtBQUEsU0FBWUMsbUJBQWdCO0FBQ3hCLE1BQUFBLGtCQUFBLG1CQUFBLElBQUE7QUFDQSxNQUFBQSxrQkFBQSxJQUFBLElBQUE7SUFDSixHQUhZLHFCQUFBLG1CQUFnQixDQUFBLEVBQUE7QUFRNUIsS0FBQSxTQUFZQyxnQkFBYTtBQUNyQixNQUFBQSxlQUFBLHFCQUFBLElBQUE7SUFDSixHQUZZLGtCQUFBLGdCQUFhLENBQUEsRUFBQTtBQU9uQixJQUFPLFlBQVAsTUFBZ0I7TUFFUDtNQUNBO01BRlgsWUFDVyxNQUNBLE9BQWE7QUFEYixhQUFBLE9BQUE7QUFDQSxhQUFBLFFBQUE7TUFDUjs7Ozs7O0FDeEhQLFNBQVMsY0FBQUMsbUJBQWtCO0FBQzNCLFNBQVMsdUJBQW1DOztBQUQ1QyxJQVNhO0FBVGI7O0FBU00sSUFBTyxnQkFBUCxNQUFPLGVBQWE7TUFDWjtNQUNGLFVBQVUsSUFBSSxnQkFBb0YsTUFBUztNQUVuSCxjQUFBO01BQWU7TUFNUixVQUFVLFFBQW9CO0FBQ2pDLGFBQUssU0FBUztBQUNkLGFBQUssUUFBUSxLQUFLLE1BQU07TUFDNUI7TUFLTyx3QkFBcUI7QUFDeEIsZUFBTyxLQUFLO01BQ2hCOzt5QkFwQlMsZ0JBQWE7TUFBQTtvRUFBYixnQkFBYSxTQUFiLGVBQWEsV0FBQSxZQURBLE9BQU0sQ0FBQTs7Ozs7O0FDUmhDLFNBQVMsY0FBQUMsbUJBQTZCO0FBR3RDLFNBQVMsUUFBUSxXQUFXOztBQUg1QixJQVVzQjtBQVZ0Qjs7QUFJQTs7QUFNTSxJQUFnQix5QkFBaEIsTUFBZ0Isd0JBQXNCO01BSVY7TUFIcEI7TUFDQTtNQUVWLFlBQThCLGVBQTRCO0FBQTVCLGFBQUEsZ0JBQUE7TUFBK0I7TUFLN0QseUJBQXNCO0FBQ2xCLGFBQUssMkJBQTJCLEtBQUssY0FDaEMsc0JBQXFCLEVBQ3JCLEtBQ0csT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sR0FDM0IsSUFBSSxDQUFDLFdBQXdCO0FBQ3pCLGVBQUssVUFBVSxNQUFNO1FBQ3pCLENBQUMsQ0FBQyxFQUVMLFVBQVM7TUFDbEI7TUFNQSxVQUFVLFFBQW9CO0FBQzFCLGFBQUssU0FBUztNQUNsQjtNQUtBLGNBQVc7QUFDUCxZQUFJLEtBQUssMEJBQTBCO0FBQy9CLGVBQUsseUJBQXlCLFlBQVc7O01BRWpEOzt5QkFwQ2tCLHlCQUFzQix1QkFBQSxhQUFBLENBQUE7TUFBQTtvRUFBdEIseUJBQXNCLFNBQXRCLHdCQUFzQixXQUFBLFlBRGxCLE9BQU0sQ0FBQTs7Ozs7O0FDVGhDLFNBQVMsbUJBQUFDLHdCQUFtQztBQUM1QyxTQUFTLGNBQUFDLG1CQUE2QjtBQUN0QyxTQUFTLDRCQUE0Qjs7QUFGckMsSUFrQmE7QUFsQmI7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7OztBQVlNLElBQU8saUNBQVAsTUFBTyx3Q0FBdUMsdUJBQXNCO01BTTFEO01BTEosbUJBQW1FLG9CQUFJLElBQUc7TUFDMUUsdUJBQTRDLG9CQUFJLElBQUc7TUFFM0QsWUFDSSxlQUNRLHFCQUF3QztBQUVoRCxjQUFNLGFBQWE7QUFGWCxhQUFBLHNCQUFBO0FBR1IsYUFBSyx1QkFBc0I7TUFDL0I7TUFLQSxjQUFXO0FBQ1AsZUFBTyxPQUFPLEtBQUssb0JBQW9CLEVBQUUsUUFBUSxDQUFDLFlBQVksS0FBSyxvQkFBb0IsWUFBWSxPQUFPLENBQUM7TUFDL0c7TUFNQSx5QkFBeUIsTUFBSztBQUMxQixjQUFNLFlBQVksS0FBSyxhQUFZO0FBQ25DLGNBQU0sVUFBVSxLQUFLLGlCQUFpQixJQUFJLFNBQVM7QUFDbkQsWUFBSSxDQUFDLFNBQVM7QUFDVixnQkFBTSxjQUFjLElBQUlELGlCQUFnQixpQkFBaUIsRUFBRTtBQUMzRCxlQUFLLGlCQUFpQixJQUFJLFdBQVcsV0FBVztBQUNoRCxpQkFBTyxZQUFZLEtBQUsscUJBQW9CLENBQUU7ZUFDM0M7QUFDSCxpQkFBTyxRQUFRLEtBQUsscUJBQW9CLENBQUU7O01BRWxEO01BT0Esc0JBQXNCLENBQUMscUJBQXNDO0FBQ3pELGNBQU0sWUFBWSxLQUFLLGFBQVk7QUFDbkMsY0FBTSxVQUFVLEtBQUssaUJBQWlCLElBQUksU0FBUztBQUNuRCxZQUFJLFNBQVM7QUFDVCxrQkFBUSxLQUFLLGdCQUFnQjs7TUFFckM7TUFFUSxlQUFlLE1BQUs7QUFDeEIsY0FBTSxDQUFDLFlBQVksV0FBVyxJQUFJLEtBQUs7QUFDdkMsZUFBTyxHQUFHLGVBQWUsV0FBVyxnQkFBZ0Isa0JBQWtCLE1BQU0sSUFBSSxZQUFZLEdBQUksU0FBUSxDQUFFO01BQzlHOzt5QkFuRFMsaUNBQThCLHVCQUFBLGFBQUEsR0FBQSx1QkFBQSxtQkFBQSxDQUFBO01BQUE7b0VBQTlCLGlDQUE4QixTQUE5QixnQ0FBOEIsV0FBQSxZQURqQixPQUFNLENBQUE7Ozs7OztBQ2pCaEMsSUFTc0I7QUFUdEI7OztBQUdBO0FBTU0sSUFBZ0IsaUNBQWhCLGNBQXVELHVCQUFzQjtNQUlqRTtNQUNBO01BSko7TUFFVixZQUNjLE1BQ0EscUJBQ1YsZUFBNEI7QUFFNUIsY0FBTSxhQUFhO0FBSlQsYUFBQSxPQUFBO0FBQ0EsYUFBQSxzQkFBQTtBQUlWLGFBQUssdUJBQXNCO01BQy9CO01BTUEsVUFBVSxRQUFvQjtBQUMxQixjQUFNLFVBQVUsTUFBTTtBQUN0QixhQUFLLGtCQUFrQixLQUFLLHlCQUF5QixNQUFNO01BQy9EO01BRUEseUJBQXlCLFFBQW9CO0FBQ3pDLGNBQU0sQ0FBQyxZQUFZLFdBQVcsSUFBSTtBQUNsQyxnQkFBUSxZQUFZO1VBQ2hCLEtBQUssV0FBVztBQUNaLG1CQUFPLGtCQUFrQixZQUFZLEVBQUU7VUFDM0MsS0FBSyxXQUFXO0FBQ1osbUJBQU8sdUJBQXVCLFlBQVksRUFBRTs7TUFFeEQ7Ozs7OztBQ3RDSixTQUFTLGNBQUFFLGFBQStCLGNBQUFDLG1CQUFrQjtBQUMxRCxTQUFTLGNBQUFDLG1CQUE2QjtBQUN0QyxTQUFxQixTQUF3QixJQUFJLE1BQU0sa0JBQWtCO0FBQ3pFLFNBQVMsWUFBWSxPQUFBQyxNQUFLLE9BQUFDLFlBQVc7OztBQUhyQyxJQXVDYSxpQkFnQlAsMEJBV0EscUJBY08sNkJBdUNBLDJCQW9CQTtBQTNJYjs7QUFJQTtBQVVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7QUFvQk0sSUFBTyxrQkFBUCxNQUFPLHlCQUF3QixNQUFLO01BQ3RDLGNBQUE7QUFDSSxjQUFNLHNCQUFzQjtBQUU1QixlQUFPLGVBQWUsTUFBTSxpQkFBZ0IsU0FBUztNQUN6RDtNQUVBLFdBQVcsVUFBTztBQUNkLGVBQU87TUFDWDs7QUFPSixJQUFNLDJCQUEyQixDQUFDLG1CQUErRjtBQUM3SCxhQUFPLENBQUMsQ0FBRSxlQUF1QztJQUNyRDtBQVNBLElBQU0sc0JBQXNCLENBQUksb0JBQzVCLEtBQ0ksV0FBVyxDQUFDLFFBQTBCO0FBQ2xDLFVBQUksSUFBSSxXQUFXLEtBQUs7QUFDcEIsd0JBQWdCLG9CQUFvQixpQkFBaUIsaUJBQWlCOztBQUUxRSxVQUFJLElBQUksV0FBVyxLQUFLLElBQUksV0FBVyxLQUFLO0FBQ3hDLGVBQU8sV0FBVyxNQUFNLElBQUksZ0JBQWUsQ0FBRTs7QUFFakQsYUFBTyxXQUFXLE1BQU0sR0FBRztJQUMvQixDQUFDLENBQUM7QUFJSixJQUFPLDhCQUFQLE1BQU8scUNBQW9DLCtCQUE4QjtNQUsvRDtNQUpaLFlBQ0ksTUFDQSxxQkFDQSxlQUNRLGlCQUErQztBQUV2RCxjQUFNLE1BQU0scUJBQXFCLGFBQWE7QUFGdEMsYUFBQSxrQkFBQTtNQUdaO01BRUEsWUFBWSxNQUFLO0FBQ2IsZUFBTyxLQUFLLEtBQUssSUFBUyxLQUFLLGVBQWdCLEVBQUUsS0FDN0Msb0JBQWtELEtBQUssZUFBZSxHQUN0RUEsS0FBSSxDQUFDLEVBQUUsaUJBQWdCLE1BQU07QUFDekIsY0FBSSxxQkFBcUIsWUFBWSxVQUFVO0FBQzNDLGlCQUFLLGdCQUFnQixvQkFBb0IsaUJBQWlCLEVBQUU7O1FBRXBFLENBQUMsQ0FBQztNQUVWO01BRUEsU0FBUyxNQUFLO0FBQ1YsZUFBTyxLQUFLLEtBQUssS0FBVyxHQUFHLEtBQUssZUFBZSxXQUFXLENBQUEsQ0FBRSxFQUFFLEtBQUssb0JBQW9CLEtBQUssZUFBZSxDQUFDO01BQ3BIO01BRUEsT0FBTyxNQUFLO0FBQ1IsZUFBTyxLQUFLLEtBQUssSUFBVSxHQUFHLEtBQUssZUFBZSxTQUFTLENBQUEsQ0FBRSxFQUFFLEtBQUssb0JBQW9CLEtBQUssZUFBZSxDQUFDO01BQ2pIO01BTUEsa0JBQWtCLE1BQUs7QUFDbkIsZUFBTyxLQUFLLEtBQUssS0FBVyxHQUFHLEtBQUssZUFBZSxVQUFVLENBQUEsQ0FBRTtNQUNuRTs7eUJBbkNTLDhCQUEyQix1QkFBQSxjQUFBLEdBQUEsdUJBQUEsbUJBQUEsR0FBQSx1QkFBQSxhQUFBLEdBQUEsdUJBQUEsOEJBQUEsQ0FBQTtNQUFBO29FQUEzQiw4QkFBMkIsU0FBM0IsNkJBQTJCLFdBQUEsWUFEZCxPQUFNLENBQUE7O0FBd0MxQixJQUFPLDRCQUFQLE1BQU8sbUNBQWtDLCtCQUE4QjtNQUU3RDtNQURaLFlBQ1ksaUJBQ1IsTUFDQSxxQkFDQSxlQUE0QjtBQUU1QixjQUFNLE1BQU0scUJBQXFCLGFBQWE7QUFMdEMsYUFBQSxrQkFBQTtNQU1aO01BRUEsZUFBZSxNQUFLO0FBQ2hCLGNBQU0sQ0FBQyxZQUFZLFdBQVcsSUFBSSxLQUFLO0FBQ3ZDLFlBQUksZUFBZSxXQUFXLGVBQWU7QUFDekMsaUJBQU8sS0FBSyxnQkFBZ0IsYUFBYSxZQUFZLEVBQUc7O0FBRTVELGVBQU8sR0FBRyxDQUFBLENBQUU7TUFDaEI7O3lCQWhCUyw0QkFBeUIsdUJBQUEsZUFBQSxHQUFBLHVCQUFBLGNBQUEsR0FBQSx1QkFBQSxtQkFBQSxHQUFBLHVCQUFBLGFBQUEsQ0FBQTtNQUFBO29FQUF6Qiw0QkFBeUIsU0FBekIsMkJBQXlCLFdBQUEsWUFEWixPQUFNLENBQUE7O0FBcUIxQixJQUFPLGtDQUFQLE1BQU8seUNBQXdDLCtCQUE4QjtNQU1uRTtNQUxaLG9CQUFvQixJQUFJLFFBQU87TUFDL0IsWUFDSSxNQUNBLHFCQUNBLGVBQ1EsaUJBQStDO0FBRXZELGNBQU0sTUFBTSxxQkFBcUIsYUFBYTtBQUZ0QyxhQUFBLGtCQUFBO01BR1o7TUFLQSxjQUFXO0FBQ1AsY0FBTSxZQUFXO01BQ3JCO01BT0EsYUFBYSxVQUFrQixjQUFvQjtBQUMvQyxhQUFLLEtBQ0EsSUFBSSxHQUFHLEtBQUssZUFBZSxTQUFTLEVBQUUsUUFBUSxJQUFJSCxZQUFVLEVBQUcsSUFBSSxRQUFRLFFBQVEsR0FBRyxjQUFjLE9BQU0sQ0FBRSxFQUM1RyxLQUFLLG9CQUFvQixLQUFLLGVBQWUsQ0FBQyxFQUM5QyxVQUFVLENBQUMsUUFBTztBQUNmLHVCQUFhLEtBQUssWUFBWTtRQUNsQyxDQUFDO01BQ1Q7TUFNQSxVQUFVLFFBQW9CO0FBQzFCLGNBQU0sVUFBVSxNQUFNO0FBQ3RCLFlBQUksS0FBSyxtQkFBbUI7QUFDeEIsZUFBSyxrQkFBa0IsU0FBUTs7TUFFdkM7TUFFQSx1QkFBdUIsQ0FBQyxXQUF5QjtBQUM3QyxjQUFNLGtCQUFrQixTQUFTLEtBQUsseUJBQXlCLE1BQU0sSUFBSSxLQUFLO0FBQzlFLGVBQU8sS0FBSyxLQUFLLElBQXNDLEdBQUcsZUFBZSxRQUFRLEVBQUUsS0FBSyxvQkFBc0QsS0FBSyxlQUFlLENBQUM7TUFDdks7TUFLQSxxQ0FBcUMsQ0FBQyxXQUF5QjtBQUMzRCxjQUFNLGtCQUFrQixTQUFTLEtBQUsseUJBQXlCLE1BQU0sSUFBSSxLQUFLO0FBQzlFLGVBQU8sS0FBSyxLQUFLLElBQXFDLEdBQUcsZUFBZSxlQUFlLEVBQUUsS0FBSyxvQkFBcUQsS0FBSyxlQUFlLENBQUM7TUFDNUs7TUFFQSxVQUFVLENBQUMsVUFBa0IsV0FBeUI7QUFDbEQsY0FBTSxrQkFBa0IsU0FBUyxLQUFLLHlCQUF5QixNQUFNLElBQUksS0FBSztBQUM5RSxlQUFPLEtBQUssS0FBSyxJQUFJLEdBQUcsZUFBZSxTQUFTLEVBQUUsUUFBUSxJQUFJQSxZQUFVLEVBQUcsSUFBSSxRQUFRLFFBQVEsR0FBRyxjQUFjLE9BQU0sQ0FBRSxFQUFFLEtBQ3RIRSxLQUFJLENBQUMsVUFBVSxFQUFFLGFBQWEsS0FBSSxFQUFHLEdBQ3JDLG9CQUE2QyxLQUFLLGVBQWUsQ0FBQztNQUUxRTtNQUVBLGlCQUFpQixDQUFDLFVBQWtCLFdBQXlCO0FBQ3pELGNBQU0sa0JBQWtCLFNBQVMsS0FBSyx5QkFBeUIsTUFBTSxJQUFJLEtBQUs7QUFDOUUsZUFBTyxLQUFLLEtBQ1AsS0FBVyxHQUFHLGVBQWUsU0FBUyxFQUFFLFNBQVMsWUFBWSxRQUFRLElBQUlGLFlBQVUsRUFBRyxJQUFJLFFBQVEsUUFBUSxFQUFDLENBQUUsRUFDN0csS0FBSyxvQkFBb0IsS0FBSyxlQUFlLENBQUM7TUFDdkQ7TUFFQSxzQkFBc0IsQ0FBQyxXQUF5QjtBQUM1QyxjQUFNLGtCQUFrQixTQUFTLEtBQUsseUJBQXlCLE1BQU0sSUFBSSxLQUFLO0FBQzlFLGVBQU8sS0FBSyxLQUFLLElBQUksR0FBRyxlQUFlLGdCQUFnQixFQUFFLEtBQUssb0JBQW9ELEtBQUssZUFBZSxDQUFDO01BQzNJO01BRUEsYUFBYSxDQUFDLGFBQW9CO0FBQzlCLGVBQU8sS0FBSyxLQUFLLEtBQVcsR0FBRyxLQUFLLGVBQWUsU0FBUyxJQUFJLEVBQUUsUUFBUSxJQUFJQSxZQUFVLEVBQUcsSUFBSSxRQUFRLFFBQVEsRUFBQyxDQUFFLEVBQUUsS0FBSyxvQkFBb0IsS0FBSyxlQUFlLENBQUM7TUFDdEs7TUFFQSxlQUFlLENBQUMsZUFBc0I7QUFDbEMsZUFBTyxLQUFLLEtBQUssS0FBVyxHQUFHLEtBQUssZUFBZSxXQUFXLElBQUksRUFBRSxRQUFRLElBQUlBLFlBQVUsRUFBRyxJQUFJLFVBQVUsVUFBVSxFQUFDLENBQUUsRUFBRSxLQUFLLG9CQUFvQixLQUFLLGVBQWUsQ0FBQztNQUM1SztNQUVBLG9CQUFvQixDQUFDLFVBQWtCLGdCQUF1QjtBQUMxRCxlQUFPLEtBQUssS0FDUCxJQUFJLEdBQUcsS0FBSyxlQUFlLFNBQVMsYUFBYTtVQUM5QyxRQUFRLElBQUlBLFlBQVUsRUFBRyxJQUFJLFFBQVEsUUFBUTtTQUNoRCxFQUNBLEtBQUssb0JBQW9CLEtBQUssZUFBZSxDQUFDO01BQ3ZEO01BU0EsWUFBWSxhQUErRCxhQUFhLE9BQUs7QUFDekYsWUFBSSxLQUFLLG1CQUFtQjtBQUN4QixlQUFLLGtCQUFrQixTQUFROztBQUVuQyxhQUFLLG9CQUFvQixJQUFJLFFBQU87QUFDcEMsZUFBTyxLQUFLLEtBQ1AsSUFBb0IsR0FBRyxLQUFLLGVBQWUsVUFBVSxhQUFhO1VBQy9ELFFBQVEsRUFBRSxRQUFRLGFBQWEsUUFBUSxLQUFJO1NBQzlDLEVBQ0EsS0FDRyxvQkFBb0IsS0FBSyxlQUFlLEdBQ3hDRyxLQUFJLENBQUMsbUJBQXdEO0FBQ3pELGNBQUkseUJBQXlCLGNBQWMsR0FBRztBQUMxQyxpQkFBSyxrQkFBa0IsTUFBTSxjQUFjO0FBQzNDLGdCQUFJLGVBQWUsVUFBVSxnQkFBZ0IsbUJBQW1CO0FBQzVELG1CQUFLLGdCQUFnQixvQkFBb0IsaUJBQWlCLGlCQUFpQjs7QUFFL0U7O0FBRUosZUFBSyxrQkFBa0IsS0FBSyxjQUFjO1FBQzlDLENBQUMsQ0FBQztNQUVkO01BRUEsYUFBYSxDQUFDLGlCQUF5QixnQkFBdUI7QUFDMUQsZUFBTyxLQUFLLEtBQUssS0FBVyxHQUFHLEtBQUssZUFBZSxnQkFBZ0IsRUFBRSxpQkFBaUIsWUFBVyxDQUFFLEVBQUUsS0FBSyxvQkFBb0IsS0FBSyxlQUFlLENBQUM7TUFDdko7TUFFQSxhQUFhLENBQUMsYUFBb0I7QUFDOUIsZUFBTyxLQUFLLEtBQUssT0FBYSxHQUFHLEtBQUssZUFBZSxTQUFTLEVBQUUsUUFBUSxJQUFJSCxZQUFVLEVBQUcsSUFBSSxRQUFRLFFBQVEsRUFBQyxDQUFFLEVBQUUsS0FBSyxvQkFBb0IsS0FBSyxlQUFlLENBQUM7TUFDcEs7O3lCQWpJUyxrQ0FBK0IsdUJBQUEsY0FBQSxHQUFBLHVCQUFBLG1CQUFBLEdBQUEsdUJBQUEsYUFBQSxHQUFBLHVCQUFBLDhCQUFBLENBQUE7TUFBQTtvRUFBL0Isa0NBQStCLFNBQS9CLGlDQUErQixXQUFBLFlBRGxCLE9BQU0sQ0FBQTs7OzsiLCJuYW1lcyI6WyJGaWxlVHlwZSIsIkRvbWFpblR5cGUiLCJSZXBvc2l0b3J5RXJyb3IiLCJDb21taXRTdGF0ZSIsIkVkaXRvclN0YXRlIiwiUmVzaXplVHlwZSIsIkdpdENvbmZsaWN0U3RhdGUiLCJGaWxlQmFkZ2VUeXBlIiwiSW5qZWN0YWJsZSIsIkluamVjdGFibGUiLCJCZWhhdmlvclN1YmplY3QiLCJJbmplY3RhYmxlIiwiSHR0cENsaWVudCIsIkh0dHBQYXJhbXMiLCJJbmplY3RhYmxlIiwibWFwIiwidGFwIl19