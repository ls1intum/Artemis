import {
  init_result_model
} from "/chunk-ORYTP7RT.js";
import {
  SortService,
  init_sort_service
} from "/chunk-H46RESQY.js";
import {
  AccountService,
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  ExerciseType,
  SortByDirective,
  SortDirective,
  TranslateDirective,
  __esm,
  init_account_service,
  init_artemis_translate_pipe,
  init_exercise_model,
  init_shared_module,
  init_sort_by_directive,
  init_sort_directive,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/shared/rating/rating.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var RatingService;
var init_rating_service = __esm({
  "src/main/webapp/app/exercises/shared/rating/rating.service.ts"() {
    RatingService = class _RatingService {
      http;
      ratingResourceUrl = "api/results/";
      constructor(http) {
        this.http = http;
      }
      createRating(rating, resultId) {
        return this.http.post(this.ratingResourceUrl + `${resultId}/rating/${rating}`, null);
      }
      getRating(resultId) {
        return this.http.get(this.ratingResourceUrl + `${resultId}/rating`);
      }
      updateRating(rating, resultId) {
        return this.http.put(this.ratingResourceUrl + `${resultId}/rating/${rating}`, null);
      }
      getRatingsForDashboard(courseId) {
        return this.http.get(`api/course/${courseId}/rating`);
      }
      static \u0275fac = function RatingService_Factory(t) {
        return new (t || _RatingService)(i0.\u0275\u0275inject(i1.HttpClient));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _RatingService, factory: _RatingService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/exercises/shared/rating/star-rating/star-rating.component.ts
import { Component, ElementRef, EventEmitter, Input, Output, ViewChild, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var _c0, StarRatingComponent;
var init_star_rating_component = __esm({
  "src/main/webapp/app/exercises/shared/rating/star-rating/star-rating.component.ts"() {
    _c0 = ["starMain"];
    StarRatingComponent = class _StarRatingComponent {
      stars = [];
      _checkedColor;
      _unCheckedColor;
      _value;
      _size;
      _readOnly = false;
      _totalStars = 5;
      onStarsCountChange;
      onValueChange;
      onCheckedColorChange;
      onUnCheckedColorChange;
      onSizeChange;
      onReadOnlyChange;
      static VAR_CHECKED_COLOR = "--checkedColor";
      static VAR_UNCHECKED_COLOR = "--unCheckedColor";
      static VAR_SIZE = "--size";
      static VAR_HALF_WIDTH = "--halfWidth";
      static VAR_HALF_MARGIN = "--halfMargin";
      static CLS_CHECKED_STAR = "on";
      static CLS_DEFAULT_STAR = "star";
      static CLS_HALF_STAR = "half";
      mainElement;
      constructor() {
        this.onStarsCountChange = new Subject();
        this.onStarsCountChange.subscribe(() => {
          this.setStars();
          this.generateRating(true);
          this.applySizeAllStars();
          this.applyColorStyleAllStars(false);
          this.addEvents();
        });
        this.onValueChange = new Subject();
        this.onValueChange.subscribe(() => {
          this.generateRating();
          this.applySizeAllStars();
        });
        this.onCheckedColorChange = new Subject();
        this.onCheckedColorChange.subscribe(() => {
          this.applyColorStyleAllStars(true);
        });
        this.onUnCheckedColorChange = new Subject();
        this.onUnCheckedColorChange.subscribe(() => {
          this.applyColorStyleAllStars(false);
        });
        this.onSizeChange = new Subject();
        this.onSizeChange.subscribe(() => {
          this.applySizeAllStars();
        });
        this.onReadOnlyChange = new Subject();
        this.onReadOnlyChange.subscribe(() => {
          if (this.readOnly) {
            this.makeReadOnly();
          } else {
            this.makeEditable();
          }
        });
      }
      rate = new EventEmitter();
      set checkedColor(value) {
        this._checkedColor = value;
        if (this._checkedColor) {
          this.onCheckedColorChange.next(this._checkedColor);
        }
      }
      get checkedColor() {
        return this._checkedColor;
      }
      set uncheckedColor(value) {
        this._unCheckedColor = value;
        if (this._unCheckedColor) {
          this.onUnCheckedColorChange.next(this._unCheckedColor);
        }
      }
      get uncheckedColor() {
        return this._unCheckedColor;
      }
      set value(value) {
        value = !value ? 0 : value;
        this._value = value;
        if (this._value >= 0) {
          this.onValueChange.next(this._value);
        }
      }
      get value() {
        return this._value;
      }
      set size(value) {
        value = !value || value === "0px" ? "24px" : value;
        this._size = value;
        this.onSizeChange.next(this._size);
      }
      get size() {
        return this._size.concat(!this._size.includes("px") ? "px" : "");
      }
      set readOnly(value) {
        this._readOnly = value;
        this.onReadOnlyChange.next(value);
      }
      get readonly() {
        return String(this._readOnly) === "true";
      }
      set totalStars(value) {
        this._totalStars = value <= 0 ? 5 : Math.round(value);
        this.onStarsCountChange.next(this._totalStars);
      }
      get totalStars() {
        return this._totalStars;
      }
      makeEditable() {
        if (!this.mainElement) {
          return;
        }
        this.mainElement.nativeElement.style.cursor = "pointer";
        this.mainElement.nativeElement.title = this.value;
        this.stars.forEach((star) => {
          star.style.cursor = "pointer";
          star.title = star.dataset.index;
        });
      }
      makeReadOnly() {
        if (!this.mainElement) {
          return;
        }
        this.mainElement.nativeElement.style.cursor = "default";
        this.mainElement.nativeElement.title = this.value;
        this.stars.forEach((star) => {
          star.style.cursor = "default";
          star.title = "";
        });
      }
      addEvents() {
        if (!this.mainElement) {
          return;
        }
        this.mainElement.nativeElement.addEventListener("mouseleave", this.offStar.bind(this));
        this.mainElement.nativeElement.style.cursor = "pointer";
        this.mainElement.nativeElement.title = this.value;
        this.stars.forEach((star) => {
          star.addEventListener("click", this.onRate.bind(this));
          star.addEventListener("mouseenter", this.onStar.bind(this));
          star.style.cursor = "pointer";
          star.title = star.dataset.index;
        });
      }
      onRate(event) {
        if (this.readOnly) {
          return;
        }
        const star = event.target;
        const oldValue = this.value;
        this.value = parseInt(star.dataset.index, 10);
        const rateValues = { oldValue, newValue: this.value, starRating: this };
        this.rate.emit(rateValues);
      }
      onStar(event) {
        if (this.readOnly) {
          return;
        }
        const star = event.target;
        const currentIndex = parseInt(star.dataset.index, 10);
        for (let index = 0; index < currentIndex; index++) {
          this.stars[index].className = "";
          _StarRatingComponent.addDefaultClass(this.stars[index]);
          _StarRatingComponent.addCheckedStarClass(this.stars[index]);
        }
        for (let index = currentIndex; index < this.stars.length; index++) {
          this.stars[index].className = "";
          _StarRatingComponent.addDefaultClass(this.stars[index]);
        }
      }
      offStar() {
        this.generateRating();
      }
      static addDefaultClass(star) {
        star.classList.add(_StarRatingComponent.CLS_DEFAULT_STAR);
      }
      static addCheckedStarClass(star) {
        star.classList.add(_StarRatingComponent.CLS_CHECKED_STAR);
      }
      static addHalfStarClass(star) {
        star.classList.add(_StarRatingComponent.CLS_HALF_STAR);
      }
      setStars() {
        if (!this.mainElement) {
          return;
        }
        const starContainer = this.mainElement.nativeElement;
        const maxStars = [...Array(this._totalStars).keys()];
        this.stars.length = 0;
        starContainer.innerHTML = "";
        maxStars.forEach((starNumber) => {
          const starElement = document.createElement("span");
          starElement.dataset.index = (starNumber + 1).toString();
          starElement.title = starElement.dataset.index;
          starContainer.appendChild(starElement);
          this.stars.push(starElement);
        });
      }
      applySizeAllStars() {
        if (this._size) {
          if (this.stars.length === 0) {
            this.setStars();
          }
          const newSize = this.size.match(/\d+/)[0];
          const halfSize = parseInt(newSize, 10) * 10 / 24;
          const halfMargin = 0 - parseInt(newSize, 10) * 20 / 24;
          this.stars.forEach((star) => {
            star.style.setProperty(_StarRatingComponent.VAR_SIZE, this.size);
            if (star.classList.contains(_StarRatingComponent.CLS_HALF_STAR)) {
              star.style.setProperty(_StarRatingComponent.VAR_HALF_WIDTH, `${halfSize}px`);
              star.style.setProperty(_StarRatingComponent.VAR_HALF_MARGIN, `${halfMargin}px`);
            }
          });
        }
      }
      applyColorStyleAllStars(setChecked) {
        if (this.stars.length === 0) {
          this.setStars();
        }
        this.stars.forEach((star) => {
          if (setChecked) {
            this.applyCheckedColorStyle(star);
          } else {
            this.applyUnCheckedColorStyle(star);
          }
        });
      }
      applyColorStyle(starElement) {
        this.applyCheckedColorStyle(starElement);
        this.applyUnCheckedColorStyle(starElement);
      }
      applyCheckedColorStyle(starElement) {
        starElement.style.setProperty(_StarRatingComponent.VAR_CHECKED_COLOR, this._checkedColor);
      }
      applyUnCheckedColorStyle(starElement) {
        starElement.style.setProperty(_StarRatingComponent.VAR_UNCHECKED_COLOR, this._unCheckedColor);
      }
      generateRating(forceGenerate = false) {
        if (!this.mainElement) {
          return;
        }
        if (this.readOnly && !forceGenerate) {
          return;
        }
        if (this.stars.length === 0) {
          this.setStars();
        }
        this.mainElement.nativeElement.title = this.value;
        let hasDecimals = !!(Number.parseFloat(this.value.toString()) % 1).toString().substring(3, 2);
        this.stars.forEach((star, i) => {
          star.className = "";
          this.applyColorStyle(star);
          _StarRatingComponent.addDefaultClass(star);
          if (this.value > i) {
            _StarRatingComponent.addCheckedStarClass(star);
          } else {
            if (hasDecimals) {
              _StarRatingComponent.addHalfStarClass(star);
              hasDecimals = false;
            }
          }
        });
      }
      static \u0275fac = function StarRatingComponent_Factory(t) {
        return new (t || _StarRatingComponent)();
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _StarRatingComponent, selectors: [["star-rating"]], viewQuery: function StarRatingComponent_Query(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275viewQuery(_c0, 7);
        }
        if (rf & 2) {
          let _t;
          i02.\u0275\u0275queryRefresh(_t = i02.\u0275\u0275loadQuery()) && (ctx.mainElement = _t.first);
        }
      }, inputs: { checkedColor: "checkedColor", uncheckedColor: "uncheckedColor", value: "value", size: "size", readOnly: "readOnly", totalStars: "totalStars" }, outputs: { rate: "rate" }, decls: 2, vars: 0, consts: [["starMain", ""]], template: function StarRatingComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275element(0, "div", null, 0);
        }
      }, styles: ['@charset "UTF-8";\n\n/* src/main/webapp/app/exercises/shared/rating/star-rating/star-rating.component.scss */\n:root {\n  --checkedcolor: gold;\n  --uncheckedcolor: gray;\n  --size: 24px;\n  --halfwidth: 10px;\n  --halfmargin: -20px;\n}\n.star {\n  cursor: pointer;\n  color: var(--unCheckedColor);\n  font-size: var(--size);\n  width: var(--size);\n  display: inline-block;\n}\n.star:last-child {\n  margin-right: 0;\n}\n.star::before {\n  content: "\\2605";\n}\n.star.on {\n  color: var(--checkedColor);\n}\n.star.half::after {\n  content: "\\2605";\n  color: var(--checkedColor);\n  position: absolute;\n  margin-left: var(--halfMargin);\n  width: var(--halfWidth);\n  overflow: hidden;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3JhdGluZy9zdGFyLXJhdGluZy9zdGFyLXJhdGluZy5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiOnJvb3Qge1xuICAgIC0tY2hlY2tlZGNvbG9yOiBnb2xkO1xuICAgIC0tdW5jaGVja2VkY29sb3I6IGdyYXk7XG4gICAgLS1zaXplOiAyNHB4O1xuICAgIC0taGFsZndpZHRoOiAxMHB4O1xuICAgIC0taGFsZm1hcmdpbjogLTIwcHg7XG59XG5cbi5zdGFyIHtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgY29sb3I6IHZhcigtLXVuQ2hlY2tlZENvbG9yKTtcbiAgICBmb250LXNpemU6IHZhcigtLXNpemUpO1xuICAgIHdpZHRoOiB2YXIoLS1zaXplKTtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG5cbiAgICAmOmxhc3QtY2hpbGQge1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDA7XG4gICAgfVxuXG4gICAgJjo6YmVmb3JlIHtcbiAgICAgICAgY29udGVudDogJ1xcMjYwNSc7XG4gICAgfVxufVxuXG4uc3Rhci5vbiB7XG4gICAgY29sb3I6IHZhcigtLWNoZWNrZWRDb2xvcik7XG59XG5cbi5zdGFyLmhhbGYge1xuICAgICY6OmFmdGVyIHtcbiAgICAgICAgY29udGVudDogJ1xcMjYwNSc7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1jaGVja2VkQ29sb3IpO1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiB2YXIoLS1oYWxmTWFyZ2luKTtcbiAgICAgICAgd2lkdGg6IHZhcigtLWhhbGZXaWR0aCk7XG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjs7O0FBQUE7QUFDSSxrQkFBQTtBQUNBLG9CQUFBO0FBQ0EsVUFBQTtBQUNBLGVBQUE7QUFDQSxnQkFBQTs7QUFHSixDQUFBO0FBQ0ksVUFBQTtBQUNBLFNBQUEsSUFBQTtBQUNBLGFBQUEsSUFBQTtBQUNBLFNBQUEsSUFBQTtBQUNBLFdBQUE7O0FBRUEsQ0FQSixJQU9JO0FBQ0ksZ0JBQUE7O0FBR0osQ0FYSixJQVdJO0FBQ0ksV0FBQTs7QUFJUixDQWhCQSxJQWdCQSxDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUlBLENBckJKLElBcUJJLENBQUEsSUFBQTtBQUNJLFdBQUE7QUFDQSxTQUFBLElBQUE7QUFDQSxZQUFBO0FBQ0EsZUFBQSxJQUFBO0FBQ0EsU0FBQSxJQUFBO0FBQ0EsWUFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */\n'], encapsulation: 3 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(StarRatingComponent, { className: "StarRatingComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/rating/rating.component.ts
import { Component as Component2, Input as Input2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var RatingComponent;
var init_rating_component = __esm({
  "src/main/webapp/app/exercises/shared/rating/rating.component.ts"() {
    init_rating_service();
    init_result_model();
    init_account_service();
    init_rating_service();
    init_account_service();
    init_translate_directive();
    init_star_rating_component();
    RatingComponent = class _RatingComponent {
      ratingService;
      accountService;
      rating;
      disableRating = false;
      result;
      constructor(ratingService, accountService) {
        this.ratingService = ratingService;
        this.accountService = accountService;
      }
      ngOnInit() {
        if (!this.result?.id || !this.result.participation || !this.accountService.isOwnerOfParticipation(this.result.participation)) {
          return;
        }
        this.ratingService.getRating(this.result.id).subscribe((rating) => {
          this.rating = rating ?? 0;
        });
      }
      onRate(event) {
        if (this.disableRating || !this.result) {
          return;
        }
        const oldRating = this.rating;
        this.rating = event.newValue;
        this.disableRating = true;
        let observable;
        if (oldRating) {
          observable = this.ratingService.updateRating(this.rating, this.result.id);
        } else {
          observable = this.ratingService.createRating(this.rating, this.result.id);
        }
        observable.subscribe((rating) => this.rating = rating).add(() => this.disableRating = false);
      }
      static \u0275fac = function RatingComponent_Factory(t) {
        return new (t || _RatingComponent)(i03.\u0275\u0275directiveInject(RatingService), i03.\u0275\u0275directiveInject(AccountService));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _RatingComponent, selectors: [["jhi-rating"]], inputs: { result: "result" }, decls: 11, vars: 6, consts: [["jhiTranslate", "artemisApp.rating.label"], ["checkedColor", "gold", "uncheckedColor", "grey", 3, "value", "size", "readOnly", "totalStars", "rate"]], template: function RatingComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "div");
          i03.\u0275\u0275text(1, "\n    ");
          i03.\u0275\u0275elementStart(2, "b");
          i03.\u0275\u0275text(3, "\n        ");
          i03.\u0275\u0275element(4, "span", 0);
          i03.\u0275\u0275text(5, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(6, "\n    ");
          i03.\u0275\u0275elementStart(7, "star-rating", 1);
          i03.\u0275\u0275listener("rate", function RatingComponent_Template_star_rating_rate_7_listener($event) {
            return ctx.onRate($event);
          });
          i03.\u0275\u0275text(8, " ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(9, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(10, "\n");
        }
        if (rf & 2) {
          i03.\u0275\u0275classProp("non-clickable", ctx.disableRating);
          i03.\u0275\u0275advance(7);
          i03.\u0275\u0275property("value", ctx.rating || 0)("size", "24")("readOnly", false)("totalStars", 5);
        }
      }, dependencies: [TranslateDirective, StarRatingComponent], styles: ["\n\n.non-clickable[_ngcontent-%COMP%]   *[_ngcontent-%COMP%] {\n  cursor: default;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3JhdGluZy9yYXRpbmcuY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5ub24tY2xpY2thYmxlICoge1xuICAgIGN1cnNvcjogZGVmYXVsdDtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBLGNBQUE7QUFDSSxVQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(RatingComponent, { className: "RatingComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/rating/rating-list/rating-list.component.ts
import { Component as Component3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute, Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { faFolderOpen, faSort } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function RatingListComponent_For_104_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275elementStart(1, "tr");
    i04.\u0275\u0275text(2, "\n                        ");
    i04.\u0275\u0275elementStart(3, "td");
    i04.\u0275\u0275text(4);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n                        ");
    i04.\u0275\u0275elementStart(6, "td");
    i04.\u0275\u0275text(7, "\n                            ");
    i04.\u0275\u0275elementStart(8, "span");
    i04.\u0275\u0275text(9);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(11, "\n                        ");
    i04.\u0275\u0275elementStart(12, "td");
    i04.\u0275\u0275text(13, "\n                            ");
    i04.\u0275\u0275elementStart(14, "span");
    i04.\u0275\u0275text(15);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(16, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(17, "\n                        ");
    i04.\u0275\u0275elementStart(18, "td");
    i04.\u0275\u0275text(19, "\n                            ");
    i04.\u0275\u0275elementStart(20, "span");
    i04.\u0275\u0275text(21);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(22, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(23, "\n                        ");
    i04.\u0275\u0275elementStart(24, "td");
    i04.\u0275\u0275text(25, "\n                            ");
    i04.\u0275\u0275elementStart(26, "span");
    i04.\u0275\u0275text(27);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(28, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(29, "\n                        ");
    i04.\u0275\u0275elementStart(30, "td");
    i04.\u0275\u0275text(31, "\n                            ");
    i04.\u0275\u0275elementStart(32, "span");
    i04.\u0275\u0275text(33);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(34, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(35, "\n                        ");
    i04.\u0275\u0275elementStart(36, "td");
    i04.\u0275\u0275text(37, "\n                            ");
    i04.\u0275\u0275elementStart(38, "span")(39, "star-rating", 18);
    i04.\u0275\u0275text(40, " ");
    i04.\u0275\u0275elementEnd()();
    i04.\u0275\u0275text(41, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(42, "\n                        ");
    i04.\u0275\u0275elementStart(43, "td", 17);
    i04.\u0275\u0275text(44, "\n                            ");
    i04.\u0275\u0275elementStart(45, "button", 19);
    i04.\u0275\u0275listener("click", function RatingListComponent_For_104_Template_button_click_45_listener() {
      const restoredCtx = i04.\u0275\u0275restoreView(_r7);
      const rating_r1 = restoredCtx.$implicit;
      const ctx_r6 = i04.\u0275\u0275nextContext();
      return i04.\u0275\u0275resetView(ctx_r6.openResult(rating_r1));
    });
    i04.\u0275\u0275text(46, "\n                                ");
    i04.\u0275\u0275element(47, "fa-icon", 20);
    i04.\u0275\u0275text(48, "\n                                ");
    i04.\u0275\u0275elementStart(49, "span");
    i04.\u0275\u0275text(50);
    i04.\u0275\u0275pipe(51, "artemisTranslate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(52, "\n                            ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(53, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(54, "\n                    ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(55, "\n                ");
  }
  if (rf & 2) {
    const rating_r1 = ctx.$implicit;
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(4);
    i04.\u0275\u0275textInterpolate1("\n                            ", rating_r1.id, "\n                        ");
    i04.\u0275\u0275advance(5);
    i04.\u0275\u0275textInterpolate(rating_r1.result == null ? null : rating_r1.result.participation == null ? null : rating_r1.result.participation.exercise == null ? null : rating_r1.result.participation.exercise.title);
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275textInterpolate(rating_r1.result == null ? null : rating_r1.result.participation == null ? null : rating_r1.result.participation.exercise == null ? null : rating_r1.result.participation.exercise.type);
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275textInterpolate(rating_r1.result == null ? null : rating_r1.result.assessor == null ? null : rating_r1.result.assessor.login);
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275textInterpolate(rating_r1.result == null ? null : rating_r1.result.assessor == null ? null : rating_r1.result.assessor.name);
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275textInterpolate(rating_r1.result == null ? null : rating_r1.result.assessmentType);
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275property("value", rating_r1.rating || 0)("readOnly", true)("totalStars", 5);
    i04.\u0275\u0275advance(8);
    i04.\u0275\u0275property("icon", ctx_r0.faFolderOpen)("fixedWidth", true);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(51, 12, "artemisApp.ratingList.openSubmission"));
  }
}
var RatingListComponent;
var init_rating_list_component = __esm({
  "src/main/webapp/app/exercises/shared/rating/rating-list/rating-list.component.ts"() {
    init_rating_service();
    init_sort_service();
    init_exercise_model();
    init_rating_service();
    init_sort_service();
    init_sort_by_directive();
    init_sort_directive();
    init_star_rating_component();
    init_artemis_translate_pipe();
    RatingListComponent = class _RatingListComponent {
      ratingService;
      route;
      sortService;
      router;
      ratings = [];
      courseId;
      ratingsSortingPredicate = "id";
      ratingsReverseOrder = false;
      faSort = faSort;
      faFolderOpen = faFolderOpen;
      constructor(ratingService, route, sortService, router) {
        this.ratingService = ratingService;
        this.route = route;
        this.sortService = sortService;
        this.router = router;
      }
      ngOnInit() {
        this.route.parent.params.subscribe((params) => {
          this.courseId = Number(params["courseId"]);
        });
        this.ratingService.getRatingsForDashboard(this.courseId).subscribe((ratings) => {
          this.ratings = ratings;
        });
      }
      sortRows() {
        this.sortService.sortByProperty(this.ratings, this.ratingsSortingPredicate, this.ratingsReverseOrder);
      }
      openResult(rating) {
        const participation = rating.result?.participation;
        const exercise = rating.result?.participation?.exercise;
        if (participation && exercise) {
          if (exercise.type === ExerciseType.PROGRAMMING) {
            this.router.navigate(["/courses", this.courseId, `${exercise.type}-exercises`, exercise.id, "code-editor", participation.id]);
          } else {
            this.router.navigate(["/courses", this.courseId, `${exercise.type}-exercises`, exercise.id, "participate", participation.id]);
          }
        }
      }
      static \u0275fac = function RatingListComponent_Factory(t) {
        return new (t || _RatingListComponent)(i04.\u0275\u0275directiveInject(RatingService), i04.\u0275\u0275directiveInject(i2.ActivatedRoute), i04.\u0275\u0275directiveInject(SortService), i04.\u0275\u0275directiveInject(i2.Router));
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _RatingListComponent, selectors: [["jhi-rating-list"]], decls: 109, vars: 38, consts: [[1, "course-info-bar"], [1, "row", "justify-content-between"], [1, "col-md-8"], [1, "col-12", "mt-4"], [1, "row", "table-responsive"], [3, "hidden"], [1, "table", 3, "hidden"], ["jhiSort", "", 3, "predicate", "ascending", "predicateChange", "ascendingChange", "sortChange"], ["jhiSortBy", "id"], [1, "th-link"], [3, "icon"], ["jhiSortBy", "result.participation.exercise.title"], ["jhiSortBy", "result.participation.exercise.type"], ["jhiSortBy", "result.assessor.login"], ["jhiSortBy", "result.assessor.name"], ["jhiSortBy", "rating.result.assessmentType"], ["jhiSortBy", "rating"], [1, "text-center"], ["checkedColor", "gold", "uncheckedColor", "grey", "size", "24", 3, "value", "readOnly", "totalStars"], [1, "btn", "btn-primary", "btn-sm", 3, "click"], [3, "icon", "fixedWidth"]], template: function RatingListComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275elementStart(0, "div", 0);
          i04.\u0275\u0275text(1, "\n    ");
          i04.\u0275\u0275elementStart(2, "div", 1);
          i04.\u0275\u0275text(3, "\n        ");
          i04.\u0275\u0275elementStart(4, "div", 2);
          i04.\u0275\u0275text(5, "\n            ");
          i04.\u0275\u0275elementStart(6, "h2");
          i04.\u0275\u0275text(7, "\n                ");
          i04.\u0275\u0275elementStart(8, "span");
          i04.\u0275\u0275text(9);
          i04.\u0275\u0275pipe(10, "artemisTranslate");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(11, "\n            ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(12, "\n        ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(13, "\n    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(14, "\n");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(15, "\n");
          i04.\u0275\u0275elementStart(16, "div", 3);
          i04.\u0275\u0275text(17, "\n    ");
          i04.\u0275\u0275elementStart(18, "div", 4);
          i04.\u0275\u0275text(19, "\n        ");
          i04.\u0275\u0275elementStart(20, "div", 5);
          i04.\u0275\u0275text(21, "\n            ");
          i04.\u0275\u0275elementStart(22, "span");
          i04.\u0275\u0275text(23);
          i04.\u0275\u0275pipe(24, "artemisTranslate");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(25, "\n        ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(26, "\n        ");
          i04.\u0275\u0275elementStart(27, "table", 6);
          i04.\u0275\u0275text(28, "\n            ");
          i04.\u0275\u0275elementStart(29, "thead");
          i04.\u0275\u0275text(30, "\n                ");
          i04.\u0275\u0275elementStart(31, "tr", 7);
          i04.\u0275\u0275listener("predicateChange", function RatingListComponent_Template_tr_predicateChange_31_listener($event) {
            return ctx.ratingsSortingPredicate = $event;
          })("ascendingChange", function RatingListComponent_Template_tr_ascendingChange_31_listener($event) {
            return ctx.ratingsReverseOrder = $event;
          })("sortChange", function RatingListComponent_Template_tr_sortChange_31_listener() {
            return ctx.sortRows();
          });
          i04.\u0275\u0275text(32, "\n                    ");
          i04.\u0275\u0275elementStart(33, "th", 8);
          i04.\u0275\u0275text(34, "\n                        ");
          i04.\u0275\u0275elementStart(35, "a", 9);
          i04.\u0275\u0275text(36, "#");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(37, "\n                        ");
          i04.\u0275\u0275element(38, "fa-icon", 10);
          i04.\u0275\u0275text(39, "\n                    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(40, "\n                    ");
          i04.\u0275\u0275elementStart(41, "th", 11);
          i04.\u0275\u0275text(42, "\n                        ");
          i04.\u0275\u0275elementStart(43, "a", 9);
          i04.\u0275\u0275text(44);
          i04.\u0275\u0275pipe(45, "artemisTranslate");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(46, "\n                        ");
          i04.\u0275\u0275element(47, "fa-icon", 10);
          i04.\u0275\u0275text(48, "\n                    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(49, "\n                    ");
          i04.\u0275\u0275elementStart(50, "th", 12);
          i04.\u0275\u0275text(51, "\n                        ");
          i04.\u0275\u0275elementStart(52, "a", 9);
          i04.\u0275\u0275text(53);
          i04.\u0275\u0275pipe(54, "artemisTranslate");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(55, "\n                        ");
          i04.\u0275\u0275element(56, "fa-icon", 10);
          i04.\u0275\u0275text(57, "\n                    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(58, "\n                    ");
          i04.\u0275\u0275elementStart(59, "th", 13);
          i04.\u0275\u0275text(60, "\n                        ");
          i04.\u0275\u0275elementStart(61, "a", 9);
          i04.\u0275\u0275text(62);
          i04.\u0275\u0275pipe(63, "artemisTranslate");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(64, "\n                        ");
          i04.\u0275\u0275element(65, "fa-icon", 10);
          i04.\u0275\u0275text(66, "\n                    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(67, "\n                    ");
          i04.\u0275\u0275elementStart(68, "th", 14);
          i04.\u0275\u0275text(69, "\n                        ");
          i04.\u0275\u0275elementStart(70, "a", 9);
          i04.\u0275\u0275text(71);
          i04.\u0275\u0275pipe(72, "artemisTranslate");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(73, "\n                        ");
          i04.\u0275\u0275element(74, "fa-icon", 10);
          i04.\u0275\u0275text(75, "\n                    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(76, "\n                    ");
          i04.\u0275\u0275elementStart(77, "th", 15);
          i04.\u0275\u0275text(78, "\n                        ");
          i04.\u0275\u0275elementStart(79, "a", 9);
          i04.\u0275\u0275text(80);
          i04.\u0275\u0275pipe(81, "artemisTranslate");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(82, "\n                        ");
          i04.\u0275\u0275element(83, "fa-icon", 10);
          i04.\u0275\u0275text(84, "\n                    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(85, "\n                    ");
          i04.\u0275\u0275elementStart(86, "th", 16);
          i04.\u0275\u0275text(87, "\n                        ");
          i04.\u0275\u0275elementStart(88, "a", 9);
          i04.\u0275\u0275text(89);
          i04.\u0275\u0275pipe(90, "artemisTranslate");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(91, "\n                        ");
          i04.\u0275\u0275element(92, "fa-icon", 10);
          i04.\u0275\u0275text(93, "\n                    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(94, "\n                    ");
          i04.\u0275\u0275elementStart(95, "th", 17);
          i04.\u0275\u0275text(96);
          i04.\u0275\u0275pipe(97, "artemisTranslate");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(98, "\n                ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(99, "\n            ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(100, "\n            ");
          i04.\u0275\u0275elementStart(101, "tbody");
          i04.\u0275\u0275text(102, "\n                ");
          i04.\u0275\u0275repeaterCreate(103, RatingListComponent_For_104_Template, 56, 14, null, null, i04.\u0275\u0275repeaterTrackByIdentity);
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(105, "\n        ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(106, "\n    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(107, "\n");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(108, "\n");
        }
        if (rf & 2) {
          i04.\u0275\u0275advance(9);
          i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(10, 20, "artemisApp.ratingList.title"));
          i04.\u0275\u0275advance(11);
          i04.\u0275\u0275property("hidden", ctx.ratings.length !== 0);
          i04.\u0275\u0275advance(3);
          i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(24, 22, "artemisApp.ratingList.noRatingToShow"));
          i04.\u0275\u0275advance(4);
          i04.\u0275\u0275property("hidden", ctx.ratings.length === 0);
          i04.\u0275\u0275advance(4);
          i04.\u0275\u0275property("predicate", ctx.ratingsSortingPredicate)("ascending", ctx.ratingsReverseOrder);
          i04.\u0275\u0275advance(7);
          i04.\u0275\u0275property("icon", ctx.faSort);
          i04.\u0275\u0275advance(6);
          i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(45, 24, "artemisApp.ratingList.exercise"));
          i04.\u0275\u0275advance(3);
          i04.\u0275\u0275property("icon", ctx.faSort);
          i04.\u0275\u0275advance(6);
          i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(54, 26, "artemisApp.ratingList.exerciseType"));
          i04.\u0275\u0275advance(3);
          i04.\u0275\u0275property("icon", ctx.faSort);
          i04.\u0275\u0275advance(6);
          i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(63, 28, "artemisApp.complaint.listOfComplaints.assessorLogin"));
          i04.\u0275\u0275advance(3);
          i04.\u0275\u0275property("icon", ctx.faSort);
          i04.\u0275\u0275advance(6);
          i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(72, 30, "artemisApp.complaint.listOfComplaints.assessorName"));
          i04.\u0275\u0275advance(3);
          i04.\u0275\u0275property("icon", ctx.faSort);
          i04.\u0275\u0275advance(6);
          i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(81, 32, "artemisApp.ratingList.assessmentType"));
          i04.\u0275\u0275advance(3);
          i04.\u0275\u0275property("icon", ctx.faSort);
          i04.\u0275\u0275advance(6);
          i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(90, 34, "artemisApp.ratingList.rating"));
          i04.\u0275\u0275advance(3);
          i04.\u0275\u0275property("icon", ctx.faSort);
          i04.\u0275\u0275advance(4);
          i04.\u0275\u0275textInterpolate(i04.\u0275\u0275pipeBind1(97, 36, "artemisApp.ratingList.actions"));
          i04.\u0275\u0275advance(7);
          i04.\u0275\u0275repeater(ctx.ratings);
        }
      }, dependencies: [i4.FaIconComponent, SortByDirective, SortDirective, StarRatingComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(RatingListComponent, { className: "RatingListComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/rating/rating.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { CommonModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var RatingModule;
var init_rating_module = __esm({
  "src/main/webapp/app/exercises/shared/rating/rating.module.ts"() {
    init_shared_module();
    init_rating_component();
    init_rating_list_component();
    init_star_rating_component();
    RatingModule = class _RatingModule {
      static \u0275fac = function RatingModule_Factory(t) {
        return new (t || _RatingModule)();
      };
      static \u0275mod = i05.\u0275\u0275defineNgModule({ type: _RatingModule });
      static \u0275inj = i05.\u0275\u0275defineInjector({ imports: [CommonModule, ArtemisSharedModule] });
    };
  }
});

export {
  StarRatingComponent,
  init_star_rating_component,
  RatingComponent,
  init_rating_component,
  RatingListComponent,
  init_rating_list_component,
  RatingModule,
  init_rating_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9yYXRpbmcvcmF0aW5nLnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcmF0aW5nL3N0YXItcmF0aW5nL3N0YXItcmF0aW5nLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9yYXRpbmcvcmF0aW5nLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9yYXRpbmcvcmF0aW5nLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3JhdGluZy9yYXRpbmctbGlzdC9yYXRpbmctbGlzdC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcmF0aW5nL3JhdGluZy1saXN0L3JhdGluZy1saXN0LmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3JhdGluZy9yYXRpbmcubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBSYXRpbmcgfSBmcm9tICdhcHAvZW50aXRpZXMvcmF0aW5nLm1vZGVsJztcblxuQEluamVjdGFibGUoe1xuICAgIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgUmF0aW5nU2VydmljZSB7XG4gICAgcHJpdmF0ZSByYXRpbmdSZXNvdXJjZVVybCA9ICdhcGkvcmVzdWx0cy8nO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50KSB7fVxuXG4gICAgLyoqXG4gICAgICogQ3JlYXRlIHRoZSBzdHVkZW50IHJhdGluZyBmb3IgZmVlZGJhY2sgb24gdGhlIHNlcnZlci5cbiAgICAgKiBAcGFyYW0gcmF0aW5nIC0gc3RhciByYXRpbmcgZm9yIHRoZSByZXN1bHRcbiAgICAgKiBAcGFyYW0gcmVzdWx0SWQgLSBpZCBvZiB0aGUgbGlua2VkIHJlc3VsdFxuICAgICAqL1xuICAgIGNyZWF0ZVJhdGluZyhyYXRpbmc6IG51bWJlciwgcmVzdWx0SWQ6IG51bWJlcik6IE9ic2VydmFibGU8bnVtYmVyPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxudW1iZXI+KHRoaXMucmF0aW5nUmVzb3VyY2VVcmwgKyBgJHtyZXN1bHRJZH0vcmF0aW5nLyR7cmF0aW5nfWAsIG51bGwpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCByYXRpbmcgZm9yIFwicmVzdWx0SWRcIiBSZXN1bHRcbiAgICAgKiBAcGFyYW0gcmVzdWx0SWQgLSBpZCBvZiByZXN1bHQgd2hvJ3MgcmF0aW5nIGlzIHJlY2VpdmVkXG4gICAgICovXG4gICAgZ2V0UmF0aW5nKHJlc3VsdElkOiBudW1iZXIpOiBPYnNlcnZhYmxlPG51bWJlciB8IG51bGw+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8bnVtYmVyIHwgbnVsbD4odGhpcy5yYXRpbmdSZXNvdXJjZVVybCArIGAke3Jlc3VsdElkfS9yYXRpbmdgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVcGRhdGUgcmF0aW5nIGZvciBcInJlc3VsdElkXCIgUmVzdWx0XG4gICAgICogQHBhcmFtIHJhdGluZyAtIHN0YXIgcmF0aW5nIGZvciB0aGUgcmVzdWx0XG4gICAgICogQHBhcmFtIHJlc3VsdElkIC0gaWQgb2YgdGhlIGxpbmtlZCByZXN1bHRcbiAgICAgKi9cbiAgICB1cGRhdGVSYXRpbmcocmF0aW5nOiBudW1iZXIsIHJlc3VsdElkOiBudW1iZXIpOiBPYnNlcnZhYmxlPG51bWJlcj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnB1dDxudW1iZXI+KHRoaXMucmF0aW5nUmVzb3VyY2VVcmwgKyBgJHtyZXN1bHRJZH0vcmF0aW5nLyR7cmF0aW5nfWAsIG51bGwpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBhbGwgcmF0aW5ncyBmb3IgdGhlIFwiY291cnNlSWRcIiBjb3Vyc2VcbiAgICAgKiBAcGFyYW0gY291cnNlSWQgLSBJZCBvZiB0aGUgY291cnNlXG4gICAgICovXG4gICAgZ2V0UmF0aW5nc0ZvckRhc2hib2FyZChjb3Vyc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxSYXRpbmdbXT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxSYXRpbmdbXT4oYGFwaS9jb3Vyc2UvJHtjb3Vyc2VJZH0vcmF0aW5nYCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBFbGVtZW50UmVmLCBFdmVudEVtaXR0ZXIsIElucHV0LCBPdXRwdXQsIFZpZXdDaGlsZCwgVmlld0VuY2Fwc3VsYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFN1YmplY3QgfSBmcm9tICdyeGpzJztcblxuQENvbXBvbmVudCh7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEBhbmd1bGFyLWVzbGludC9jb21wb25lbnQtc2VsZWN0b3JcbiAgICBzZWxlY3RvcjogJ3N0YXItcmF0aW5nJyxcbiAgICB0ZW1wbGF0ZTogYDxkaXYgI3N0YXJNYWluPjwvZGl2PmAsXG4gICAgc3R5bGVVcmxzOiBbJy4vc3Rhci1yYXRpbmcuY29tcG9uZW50LnNjc3MnXSxcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5TaGFkb3dEb20sXG59KVxuZXhwb3J0IGNsYXNzIFN0YXJSYXRpbmdDb21wb25lbnQge1xuICAgIHByaXZhdGUgc3RhcnM6IEFycmF5PEhUTUxFbGVtZW50PiA9IFtdO1xuXG4gICAgcHJpdmF0ZSBfY2hlY2tlZENvbG9yOiBzdHJpbmc7XG4gICAgcHJpdmF0ZSBfdW5DaGVja2VkQ29sb3I6IHN0cmluZztcbiAgICBwcml2YXRlIF92YWx1ZTogbnVtYmVyO1xuICAgIHByaXZhdGUgX3NpemU6IHN0cmluZztcbiAgICBwcml2YXRlIF9yZWFkT25seSA9IGZhbHNlO1xuICAgIHByaXZhdGUgX3RvdGFsU3RhcnMgPSA1O1xuXG4gICAgcHJpdmF0ZSBvblN0YXJzQ291bnRDaGFuZ2U6IFN1YmplY3Q8bnVtYmVyPjtcbiAgICBwcml2YXRlIG9uVmFsdWVDaGFuZ2U6IFN1YmplY3Q8bnVtYmVyPjtcbiAgICBwcml2YXRlIG9uQ2hlY2tlZENvbG9yQ2hhbmdlOiBTdWJqZWN0PHN0cmluZz47XG4gICAgcHJpdmF0ZSBvblVuQ2hlY2tlZENvbG9yQ2hhbmdlOiBTdWJqZWN0PHN0cmluZz47XG4gICAgcHJpdmF0ZSBvblNpemVDaGFuZ2U6IFN1YmplY3Q8c3RyaW5nPjtcbiAgICBwcml2YXRlIG9uUmVhZE9ubHlDaGFuZ2U6IFN1YmplY3Q8Ym9vbGVhbj47XG5cbiAgICBwcml2YXRlIHN0YXRpYyByZWFkb25seSBWQVJfQ0hFQ0tFRF9DT0xPUjogc3RyaW5nID0gJy0tY2hlY2tlZENvbG9yJztcbiAgICBwcml2YXRlIHN0YXRpYyByZWFkb25seSBWQVJfVU5DSEVDS0VEX0NPTE9SOiBzdHJpbmcgPSAnLS11bkNoZWNrZWRDb2xvcic7XG4gICAgcHJpdmF0ZSBzdGF0aWMgcmVhZG9ubHkgVkFSX1NJWkU6IHN0cmluZyA9ICctLXNpemUnO1xuICAgIHByaXZhdGUgc3RhdGljIHJlYWRvbmx5IFZBUl9IQUxGX1dJRFRIOiBzdHJpbmcgPSAnLS1oYWxmV2lkdGgnO1xuICAgIHByaXZhdGUgc3RhdGljIHJlYWRvbmx5IFZBUl9IQUxGX01BUkdJTjogc3RyaW5nID0gJy0taGFsZk1hcmdpbic7XG4gICAgcHJpdmF0ZSBzdGF0aWMgcmVhZG9ubHkgQ0xTX0NIRUNLRURfU1RBUjogc3RyaW5nID0gJ29uJztcbiAgICBwcml2YXRlIHN0YXRpYyByZWFkb25seSBDTFNfREVGQVVMVF9TVEFSOiBzdHJpbmcgPSAnc3Rhcic7XG4gICAgcHJpdmF0ZSBzdGF0aWMgcmVhZG9ubHkgQ0xTX0hBTEZfU1RBUjogc3RyaW5nID0gJ2hhbGYnO1xuXG4gICAgQFZpZXdDaGlsZCgnc3Rhck1haW4nLCB7IHN0YXRpYzogdHJ1ZSB9KSBwcml2YXRlIG1haW5FbGVtZW50OiBFbGVtZW50UmVmO1xuXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMub25TdGFyc0NvdW50Q2hhbmdlID0gbmV3IFN1YmplY3QoKTtcbiAgICAgICAgdGhpcy5vblN0YXJzQ291bnRDaGFuZ2Uuc3Vic2NyaWJlKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuc2V0U3RhcnMoKTtcbiAgICAgICAgICAgIHRoaXMuZ2VuZXJhdGVSYXRpbmcodHJ1ZSk7XG4gICAgICAgICAgICB0aGlzLmFwcGx5U2l6ZUFsbFN0YXJzKCk7XG4gICAgICAgICAgICB0aGlzLmFwcGx5Q29sb3JTdHlsZUFsbFN0YXJzKGZhbHNlKTtcbiAgICAgICAgICAgIHRoaXMuYWRkRXZlbnRzKCk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMub25WYWx1ZUNoYW5nZSA9IG5ldyBTdWJqZWN0KCk7XG4gICAgICAgIHRoaXMub25WYWx1ZUNoYW5nZS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5nZW5lcmF0ZVJhdGluZygpO1xuICAgICAgICAgICAgdGhpcy5hcHBseVNpemVBbGxTdGFycygpO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLm9uQ2hlY2tlZENvbG9yQ2hhbmdlID0gbmV3IFN1YmplY3QoKTtcbiAgICAgICAgdGhpcy5vbkNoZWNrZWRDb2xvckNoYW5nZS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5hcHBseUNvbG9yU3R5bGVBbGxTdGFycyh0cnVlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5vblVuQ2hlY2tlZENvbG9yQ2hhbmdlID0gbmV3IFN1YmplY3QoKTtcbiAgICAgICAgdGhpcy5vblVuQ2hlY2tlZENvbG9yQ2hhbmdlLnN1YnNjcmliZSgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmFwcGx5Q29sb3JTdHlsZUFsbFN0YXJzKGZhbHNlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5vblNpemVDaGFuZ2UgPSBuZXcgU3ViamVjdCgpO1xuICAgICAgICB0aGlzLm9uU2l6ZUNoYW5nZS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5hcHBseVNpemVBbGxTdGFycygpO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLm9uUmVhZE9ubHlDaGFuZ2UgPSBuZXcgU3ViamVjdCgpO1xuICAgICAgICB0aGlzLm9uUmVhZE9ubHlDaGFuZ2Uuc3Vic2NyaWJlKCgpID0+IHtcbiAgICAgICAgICAgIGlmICh0aGlzLnJlYWRPbmx5KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5tYWtlUmVhZE9ubHkoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5tYWtlRWRpdGFibGUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgQE91dHB1dCgpIHJhdGU6IEV2ZW50RW1pdHRlcjx7IG9sZFZhbHVlOiBudW1iZXI7IG5ld1ZhbHVlOiBudW1iZXI7IHN0YXJSYXRpbmc6IFN0YXJSYXRpbmdDb21wb25lbnQgfT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5cbiAgICBASW5wdXQoKSBzZXQgY2hlY2tlZENvbG9yKHZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fY2hlY2tlZENvbG9yID0gdmFsdWU7XG4gICAgICAgIGlmICh0aGlzLl9jaGVja2VkQ29sb3IpIHtcbiAgICAgICAgICAgIHRoaXMub25DaGVja2VkQ29sb3JDaGFuZ2UubmV4dCh0aGlzLl9jaGVja2VkQ29sb3IpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZ2V0IGNoZWNrZWRDb2xvcigpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2hlY2tlZENvbG9yO1xuICAgIH1cblxuICAgIEBJbnB1dCgpIHNldCB1bmNoZWNrZWRDb2xvcih2YWx1ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuX3VuQ2hlY2tlZENvbG9yID0gdmFsdWU7XG4gICAgICAgIGlmICh0aGlzLl91bkNoZWNrZWRDb2xvcikge1xuICAgICAgICAgICAgdGhpcy5vblVuQ2hlY2tlZENvbG9yQ2hhbmdlLm5leHQodGhpcy5fdW5DaGVja2VkQ29sb3IpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZ2V0IHVuY2hlY2tlZENvbG9yKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl91bkNoZWNrZWRDb2xvcjtcbiAgICB9XG5cbiAgICBASW5wdXQoKSBzZXQgdmFsdWUodmFsdWU6IG51bWJlcikge1xuICAgICAgICB2YWx1ZSA9ICF2YWx1ZSA/IDAgOiB2YWx1ZTtcbiAgICAgICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgaWYgKHRoaXMuX3ZhbHVlID49IDApIHtcbiAgICAgICAgICAgIHRoaXMub25WYWx1ZUNoYW5nZS5uZXh0KHRoaXMuX3ZhbHVlKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGdldCB2YWx1ZSgpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gICAgfVxuXG4gICAgQElucHV0KCkgc2V0IHNpemUodmFsdWU6IHN0cmluZykge1xuICAgICAgICB2YWx1ZSA9ICF2YWx1ZSB8fCB2YWx1ZSA9PT0gJzBweCcgPyAnMjRweCcgOiB2YWx1ZTtcbiAgICAgICAgdGhpcy5fc2l6ZSA9IHZhbHVlO1xuICAgICAgICB0aGlzLm9uU2l6ZUNoYW5nZS5uZXh0KHRoaXMuX3NpemUpO1xuICAgIH1cblxuICAgIGdldCBzaXplKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLl9zaXplLmNvbmNhdCghdGhpcy5fc2l6ZS5pbmNsdWRlcygncHgnKSA/ICdweCcgOiAnJyk7XG4gICAgfVxuXG4gICAgQElucHV0KCkgc2V0IHJlYWRPbmx5KHZhbHVlOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuX3JlYWRPbmx5ID0gdmFsdWU7XG4gICAgICAgIHRoaXMub25SZWFkT25seUNoYW5nZS5uZXh0KHZhbHVlKTtcbiAgICB9XG5cbiAgICBnZXQgcmVhZG9ubHkoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiBTdHJpbmcodGhpcy5fcmVhZE9ubHkpID09PSAndHJ1ZSc7XG4gICAgfVxuXG4gICAgQElucHV0KCkgc2V0IHRvdGFsU3RhcnModmFsdWU6IG51bWJlcikge1xuICAgICAgICB0aGlzLl90b3RhbFN0YXJzID0gdmFsdWUgPD0gMCA/IDUgOiBNYXRoLnJvdW5kKHZhbHVlKTtcbiAgICAgICAgdGhpcy5vblN0YXJzQ291bnRDaGFuZ2UubmV4dCh0aGlzLl90b3RhbFN0YXJzKTtcbiAgICB9XG5cbiAgICBnZXQgdG90YWxTdGFycygpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fdG90YWxTdGFycztcbiAgICB9XG5cbiAgICBwcml2YXRlIG1ha2VFZGl0YWJsZSgpIHtcbiAgICAgICAgaWYgKCF0aGlzLm1haW5FbGVtZW50KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5tYWluRWxlbWVudC5uYXRpdmVFbGVtZW50LnN0eWxlLmN1cnNvciA9ICdwb2ludGVyJztcbiAgICAgICAgdGhpcy5tYWluRWxlbWVudC5uYXRpdmVFbGVtZW50LnRpdGxlID0gdGhpcy52YWx1ZTtcbiAgICAgICAgdGhpcy5zdGFycy5mb3JFYWNoKChzdGFyOiBIVE1MRWxlbWVudCkgPT4ge1xuICAgICAgICAgICAgc3Rhci5zdHlsZS5jdXJzb3IgPSAncG9pbnRlcic7XG4gICAgICAgICAgICBzdGFyLnRpdGxlID0gc3Rhci5kYXRhc2V0LmluZGV4ITtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBtYWtlUmVhZE9ubHkoKSB7XG4gICAgICAgIGlmICghdGhpcy5tYWluRWxlbWVudCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubWFpbkVsZW1lbnQubmF0aXZlRWxlbWVudC5zdHlsZS5jdXJzb3IgPSAnZGVmYXVsdCc7XG4gICAgICAgIHRoaXMubWFpbkVsZW1lbnQubmF0aXZlRWxlbWVudC50aXRsZSA9IHRoaXMudmFsdWU7XG4gICAgICAgIHRoaXMuc3RhcnMuZm9yRWFjaCgoc3RhcjogSFRNTEVsZW1lbnQpID0+IHtcbiAgICAgICAgICAgIHN0YXIuc3R5bGUuY3Vyc29yID0gJ2RlZmF1bHQnO1xuICAgICAgICAgICAgc3Rhci50aXRsZSA9ICcnO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGFkZEV2ZW50cygpIHtcbiAgICAgICAgaWYgKCF0aGlzLm1haW5FbGVtZW50KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5tYWluRWxlbWVudC5uYXRpdmVFbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlbGVhdmUnLCB0aGlzLm9mZlN0YXIuYmluZCh0aGlzKSk7XG4gICAgICAgIHRoaXMubWFpbkVsZW1lbnQubmF0aXZlRWxlbWVudC5zdHlsZS5jdXJzb3IgPSAncG9pbnRlcic7XG4gICAgICAgIHRoaXMubWFpbkVsZW1lbnQubmF0aXZlRWxlbWVudC50aXRsZSA9IHRoaXMudmFsdWU7XG4gICAgICAgIHRoaXMuc3RhcnMuZm9yRWFjaCgoc3RhcjogSFRNTEVsZW1lbnQpID0+IHtcbiAgICAgICAgICAgIHN0YXIuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLm9uUmF0ZS5iaW5kKHRoaXMpKTtcbiAgICAgICAgICAgIHN0YXIuYWRkRXZlbnRMaXN0ZW5lcignbW91c2VlbnRlcicsIHRoaXMub25TdGFyLmJpbmQodGhpcykpO1xuICAgICAgICAgICAgc3Rhci5zdHlsZS5jdXJzb3IgPSAncG9pbnRlcic7XG4gICAgICAgICAgICBzdGFyLnRpdGxlID0gc3Rhci5kYXRhc2V0LmluZGV4ITtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBvblJhdGUoZXZlbnQ6IE1vdXNlRXZlbnQpIHtcbiAgICAgICAgaWYgKHRoaXMucmVhZE9ubHkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzdGFyOiBIVE1MRWxlbWVudCA9IDxIVE1MRWxlbWVudD5ldmVudC50YXJnZXQ7XG4gICAgICAgIGNvbnN0IG9sZFZhbHVlID0gdGhpcy52YWx1ZTtcbiAgICAgICAgdGhpcy52YWx1ZSA9IHBhcnNlSW50KHN0YXIuZGF0YXNldC5pbmRleCEsIDEwKTtcbiAgICAgICAgY29uc3QgcmF0ZVZhbHVlcyA9IHsgb2xkVmFsdWUsIG5ld1ZhbHVlOiB0aGlzLnZhbHVlLCBzdGFyUmF0aW5nOiB0aGlzIH07XG4gICAgICAgIHRoaXMucmF0ZS5lbWl0KHJhdGVWYWx1ZXMpO1xuICAgIH1cblxuICAgIHByaXZhdGUgb25TdGFyKGV2ZW50OiBNb3VzZUV2ZW50KSB7XG4gICAgICAgIGlmICh0aGlzLnJlYWRPbmx5KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3RhcjogSFRNTEVsZW1lbnQgPSA8SFRNTEVsZW1lbnQ+ZXZlbnQudGFyZ2V0O1xuICAgICAgICBjb25zdCBjdXJyZW50SW5kZXggPSBwYXJzZUludChzdGFyLmRhdGFzZXQuaW5kZXghLCAxMCk7XG5cbiAgICAgICAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGN1cnJlbnRJbmRleDsgaW5kZXgrKykge1xuICAgICAgICAgICAgdGhpcy5zdGFyc1tpbmRleF0uY2xhc3NOYW1lID0gJyc7XG4gICAgICAgICAgICBTdGFyUmF0aW5nQ29tcG9uZW50LmFkZERlZmF1bHRDbGFzcyh0aGlzLnN0YXJzW2luZGV4XSk7XG4gICAgICAgICAgICBTdGFyUmF0aW5nQ29tcG9uZW50LmFkZENoZWNrZWRTdGFyQ2xhc3ModGhpcy5zdGFyc1tpbmRleF0pO1xuICAgICAgICB9XG5cbiAgICAgICAgZm9yIChsZXQgaW5kZXggPSBjdXJyZW50SW5kZXg7IGluZGV4IDwgdGhpcy5zdGFycy5sZW5ndGg7IGluZGV4KyspIHtcbiAgICAgICAgICAgIHRoaXMuc3RhcnNbaW5kZXhdLmNsYXNzTmFtZSA9ICcnO1xuICAgICAgICAgICAgU3RhclJhdGluZ0NvbXBvbmVudC5hZGREZWZhdWx0Q2xhc3ModGhpcy5zdGFyc1tpbmRleF0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBvZmZTdGFyKCkge1xuICAgICAgICB0aGlzLmdlbmVyYXRlUmF0aW5nKCk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzdGF0aWMgYWRkRGVmYXVsdENsYXNzKHN0YXI6IEVsZW1lbnQpIHtcbiAgICAgICAgc3Rhci5jbGFzc0xpc3QuYWRkKFN0YXJSYXRpbmdDb21wb25lbnQuQ0xTX0RFRkFVTFRfU1RBUik7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzdGF0aWMgYWRkQ2hlY2tlZFN0YXJDbGFzcyhzdGFyOiBFbGVtZW50KSB7XG4gICAgICAgIHN0YXIuY2xhc3NMaXN0LmFkZChTdGFyUmF0aW5nQ29tcG9uZW50LkNMU19DSEVDS0VEX1NUQVIpO1xuICAgIH1cblxuICAgIHByaXZhdGUgc3RhdGljIGFkZEhhbGZTdGFyQ2xhc3Moc3RhcjogRWxlbWVudCkge1xuICAgICAgICBzdGFyLmNsYXNzTGlzdC5hZGQoU3RhclJhdGluZ0NvbXBvbmVudC5DTFNfSEFMRl9TVEFSKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHNldFN0YXJzKCkge1xuICAgICAgICBpZiAoIXRoaXMubWFpbkVsZW1lbnQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzdGFyQ29udGFpbmVyOiBIVE1MRGl2RWxlbWVudCA9IHRoaXMubWFpbkVsZW1lbnQubmF0aXZlRWxlbWVudDtcbiAgICAgICAgY29uc3QgbWF4U3RhcnMgPSBbLi4uQXJyYXkodGhpcy5fdG90YWxTdGFycykua2V5cygpXTtcbiAgICAgICAgdGhpcy5zdGFycy5sZW5ndGggPSAwO1xuICAgICAgICBzdGFyQ29udGFpbmVyLmlubmVySFRNTCA9ICcnO1xuICAgICAgICBtYXhTdGFycy5mb3JFYWNoKChzdGFyTnVtYmVyKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBzdGFyRWxlbWVudDogSFRNTFNwYW5FbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgICAgICAgICAgc3RhckVsZW1lbnQuZGF0YXNldC5pbmRleCA9IChzdGFyTnVtYmVyICsgMSkudG9TdHJpbmcoKTtcbiAgICAgICAgICAgIHN0YXJFbGVtZW50LnRpdGxlID0gc3RhckVsZW1lbnQuZGF0YXNldC5pbmRleDtcbiAgICAgICAgICAgIHN0YXJDb250YWluZXIuYXBwZW5kQ2hpbGQoc3RhckVsZW1lbnQpO1xuICAgICAgICAgICAgdGhpcy5zdGFycy5wdXNoKHN0YXJFbGVtZW50KTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBhcHBseVNpemVBbGxTdGFycygpIHtcbiAgICAgICAgaWYgKHRoaXMuX3NpemUpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLnN0YXJzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0U3RhcnMoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgbmV3U2l6ZSA9IHRoaXMuc2l6ZS5tYXRjaCgvXFxkKy8pIVswXTtcbiAgICAgICAgICAgIGNvbnN0IGhhbGZTaXplID0gKHBhcnNlSW50KG5ld1NpemUsIDEwKSAqIDEwKSAvIDI0O1xuICAgICAgICAgICAgY29uc3QgaGFsZk1hcmdpbiA9IDAgLSAocGFyc2VJbnQobmV3U2l6ZSwgMTApICogMjApIC8gMjQ7XG5cbiAgICAgICAgICAgIHRoaXMuc3RhcnMuZm9yRWFjaCgoc3RhcjogSFRNTEVsZW1lbnQpID0+IHtcbiAgICAgICAgICAgICAgICBzdGFyLnN0eWxlLnNldFByb3BlcnR5KFN0YXJSYXRpbmdDb21wb25lbnQuVkFSX1NJWkUsIHRoaXMuc2l6ZSk7XG4gICAgICAgICAgICAgICAgaWYgKHN0YXIuY2xhc3NMaXN0LmNvbnRhaW5zKFN0YXJSYXRpbmdDb21wb25lbnQuQ0xTX0hBTEZfU1RBUikpIHtcbiAgICAgICAgICAgICAgICAgICAgc3Rhci5zdHlsZS5zZXRQcm9wZXJ0eShTdGFyUmF0aW5nQ29tcG9uZW50LlZBUl9IQUxGX1dJRFRILCBgJHtoYWxmU2l6ZX1weGApO1xuICAgICAgICAgICAgICAgICAgICBzdGFyLnN0eWxlLnNldFByb3BlcnR5KFN0YXJSYXRpbmdDb21wb25lbnQuVkFSX0hBTEZfTUFSR0lOLCBgJHtoYWxmTWFyZ2lufXB4YCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIGFwcGx5Q29sb3JTdHlsZUFsbFN0YXJzKHNldENoZWNrZWQ6IGJvb2xlYW4pIHtcbiAgICAgICAgaWYgKHRoaXMuc3RhcnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICB0aGlzLnNldFN0YXJzKCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zdGFycy5mb3JFYWNoKChzdGFyOiBIVE1MRWxlbWVudCkgPT4ge1xuICAgICAgICAgICAgaWYgKHNldENoZWNrZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmFwcGx5Q2hlY2tlZENvbG9yU3R5bGUoc3Rhcik7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMuYXBwbHlVbkNoZWNrZWRDb2xvclN0eWxlKHN0YXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGFwcGx5Q29sb3JTdHlsZShzdGFyRWxlbWVudDogSFRNTFNwYW5FbGVtZW50KSB7XG4gICAgICAgIHRoaXMuYXBwbHlDaGVja2VkQ29sb3JTdHlsZShzdGFyRWxlbWVudCk7XG4gICAgICAgIHRoaXMuYXBwbHlVbkNoZWNrZWRDb2xvclN0eWxlKHN0YXJFbGVtZW50KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGFwcGx5Q2hlY2tlZENvbG9yU3R5bGUoc3RhckVsZW1lbnQ6IEhUTUxTcGFuRWxlbWVudCkge1xuICAgICAgICBzdGFyRWxlbWVudC5zdHlsZS5zZXRQcm9wZXJ0eShTdGFyUmF0aW5nQ29tcG9uZW50LlZBUl9DSEVDS0VEX0NPTE9SLCB0aGlzLl9jaGVja2VkQ29sb3IpO1xuICAgIH1cblxuICAgIHByaXZhdGUgYXBwbHlVbkNoZWNrZWRDb2xvclN0eWxlKHN0YXJFbGVtZW50OiBIVE1MU3BhbkVsZW1lbnQpIHtcbiAgICAgICAgc3RhckVsZW1lbnQuc3R5bGUuc2V0UHJvcGVydHkoU3RhclJhdGluZ0NvbXBvbmVudC5WQVJfVU5DSEVDS0VEX0NPTE9SLCB0aGlzLl91bkNoZWNrZWRDb2xvcik7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBnZW5lcmF0ZVJhdGluZyhmb3JjZUdlbmVyYXRlID0gZmFsc2UpIHtcbiAgICAgICAgaWYgKCF0aGlzLm1haW5FbGVtZW50KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMucmVhZE9ubHkgJiYgIWZvcmNlR2VuZXJhdGUpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLnN0YXJzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgdGhpcy5zZXRTdGFycygpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubWFpbkVsZW1lbnQubmF0aXZlRWxlbWVudC50aXRsZSA9IHRoaXMudmFsdWU7XG5cbiAgICAgICAgbGV0IGhhc0RlY2ltYWxzID0gISEoTnVtYmVyLnBhcnNlRmxvYXQodGhpcy52YWx1ZS50b1N0cmluZygpKSAlIDEpLnRvU3RyaW5nKCkuc3Vic3RyaW5nKDMsIDIpO1xuXG4gICAgICAgIHRoaXMuc3RhcnMuZm9yRWFjaCgoc3RhcjogSFRNTEVsZW1lbnQsIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgc3Rhci5jbGFzc05hbWUgPSAnJztcbiAgICAgICAgICAgIHRoaXMuYXBwbHlDb2xvclN0eWxlKHN0YXIpO1xuICAgICAgICAgICAgU3RhclJhdGluZ0NvbXBvbmVudC5hZGREZWZhdWx0Q2xhc3Moc3Rhcik7XG5cbiAgICAgICAgICAgIGlmICh0aGlzLnZhbHVlID4gaSkge1xuICAgICAgICAgICAgICAgIC8vIHN0YXIgb25cbiAgICAgICAgICAgICAgICBTdGFyUmF0aW5nQ29tcG9uZW50LmFkZENoZWNrZWRTdGFyQ2xhc3Moc3Rhcik7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIGhhbGYgc3RhclxuICAgICAgICAgICAgICAgIGlmIChoYXNEZWNpbWFscykge1xuICAgICAgICAgICAgICAgICAgICBTdGFyUmF0aW5nQ29tcG9uZW50LmFkZEhhbGZTdGFyQ2xhc3Moc3Rhcik7XG4gICAgICAgICAgICAgICAgICAgIGhhc0RlY2ltYWxzID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJhdGluZ1NlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9yYXRpbmcvcmF0aW5nLnNlcnZpY2UnO1xuaW1wb3J0IHsgU3RhclJhdGluZ0NvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3JhdGluZy9zdGFyLXJhdGluZy9zdGFyLXJhdGluZy5jb21wb25lbnQnO1xuaW1wb3J0IHsgUmVzdWx0IH0gZnJvbSAnYXBwL2VudGl0aWVzL3Jlc3VsdC5tb2RlbCc7XG5pbXBvcnQgeyBTdHVkZW50UGFydGljaXBhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9wYXJ0aWNpcGF0aW9uL3N0dWRlbnQtcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBBY2NvdW50U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL2F1dGgvYWNjb3VudC5zZXJ2aWNlJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktcmF0aW5nJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vcmF0aW5nLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9yYXRpbmcuY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgUmF0aW5nQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICBwdWJsaWMgcmF0aW5nOiBudW1iZXI7XG4gICAgcHVibGljIGRpc2FibGVSYXRpbmcgPSBmYWxzZTtcbiAgICBASW5wdXQoKSByZXN1bHQ/OiBSZXN1bHQ7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSByYXRpbmdTZXJ2aWNlOiBSYXRpbmdTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFjY291bnRTZXJ2aWNlOiBBY2NvdW50U2VydmljZSxcbiAgICApIHt9XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgaWYgKCF0aGlzLnJlc3VsdD8uaWQgfHwgIXRoaXMucmVzdWx0LnBhcnRpY2lwYXRpb24gfHwgIXRoaXMuYWNjb3VudFNlcnZpY2UuaXNPd25lck9mUGFydGljaXBhdGlvbih0aGlzLnJlc3VsdC5wYXJ0aWNpcGF0aW9uIGFzIFN0dWRlbnRQYXJ0aWNpcGF0aW9uKSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5yYXRpbmdTZXJ2aWNlLmdldFJhdGluZyh0aGlzLnJlc3VsdC5pZCkuc3Vic2NyaWJlKChyYXRpbmcpID0+IHtcbiAgICAgICAgICAgIHRoaXMucmF0aW5nID0gcmF0aW5nID8/IDA7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZS9DcmVhdGUgbmV3IFJhdGluZyBmb3IgdGhlIHJlc3VsdFxuICAgICAqIEBwYXJhbSBldmVudCAtIHN0YXJSYXRpbmcgY29tcG9uZW50IHRoYXQgaG9sZHMgbmV3IHJhdGluZyB2YWx1ZVxuICAgICAqL1xuICAgIG9uUmF0ZShldmVudDogeyBvbGRWYWx1ZTogbnVtYmVyOyBuZXdWYWx1ZTogbnVtYmVyOyBzdGFyUmF0aW5nOiBTdGFyUmF0aW5nQ29tcG9uZW50IH0pIHtcbiAgICAgICAgLy8gYmxvY2sgcmF0aW5nIHRvIHByZXZlbnQgZG91YmxlIHNlbmRpbmcgb2YgcG9zdCByZXF1ZXN0XG4gICAgICAgIGlmICh0aGlzLmRpc2FibGVSYXRpbmcgfHwgIXRoaXMucmVzdWx0KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBvbGRSYXRpbmcgPSB0aGlzLnJhdGluZztcbiAgICAgICAgdGhpcy5yYXRpbmcgPSBldmVudC5uZXdWYWx1ZTtcblxuICAgICAgICB0aGlzLmRpc2FibGVSYXRpbmcgPSB0cnVlO1xuICAgICAgICBsZXQgb2JzZXJ2YWJsZTogT2JzZXJ2YWJsZTxudW1iZXI+O1xuICAgICAgICAvLyBzZXQvdXBkYXRlIGZlZWRiYWNrIG9uIHRoZSBzZXJ2ZXJcbiAgICAgICAgaWYgKG9sZFJhdGluZykge1xuICAgICAgICAgICAgb2JzZXJ2YWJsZSA9IHRoaXMucmF0aW5nU2VydmljZS51cGRhdGVSYXRpbmcodGhpcy5yYXRpbmcsIHRoaXMucmVzdWx0LmlkISk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBvYnNlcnZhYmxlID0gdGhpcy5yYXRpbmdTZXJ2aWNlLmNyZWF0ZVJhdGluZyh0aGlzLnJhdGluZywgdGhpcy5yZXN1bHQuaWQhKTtcbiAgICAgICAgfVxuXG4gICAgICAgIG9ic2VydmFibGUuc3Vic2NyaWJlKChyYXRpbmcpID0+ICh0aGlzLnJhdGluZyA9IHJhdGluZykpLmFkZCgoKSA9PiAodGhpcy5kaXNhYmxlUmF0aW5nID0gZmFsc2UpKTtcbiAgICB9XG59XG4iLCI8ZGl2IFtjbGFzcy5ub24tY2xpY2thYmxlXT1cImRpc2FibGVSYXRpbmdcIj5cbiAgICA8Yj5cbiAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5yYXRpbmcubGFiZWxcIj48L3NwYW4+XG4gICAgPC9iPlxuICAgIDxzdGFyLXJhdGluZyBjaGVja2VkQ29sb3I9XCJnb2xkXCIgdW5jaGVja2VkQ29sb3I9XCJncmV5XCIgW3ZhbHVlXT1cInJhdGluZyB8fCAwXCIgW3NpemVdPVwiJzI0J1wiIFtyZWFkT25seV09XCJmYWxzZVwiIFt0b3RhbFN0YXJzXT1cIjVcIiAocmF0ZSk9XCJvblJhdGUoJGV2ZW50KVwiPiA8L3N0YXItcmF0aW5nPlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUmF0aW5nU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3JhdGluZy9yYXRpbmcuc2VydmljZSc7XG5pbXBvcnQgeyBSYXRpbmcgfSBmcm9tICdhcHAvZW50aXRpZXMvcmF0aW5nLm1vZGVsJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlLCBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgU29ydFNlcnZpY2UgfSBmcm9tICdhcHAvc2hhcmVkL3NlcnZpY2Uvc29ydC5zZXJ2aWNlJztcbmltcG9ydCB7IEV4ZXJjaXNlVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBmYUZvbGRlck9wZW4sIGZhU29ydCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXJhdGluZy1saXN0JyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vcmF0aW5nLWxpc3QuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogW10sXG59KVxuZXhwb3J0IGNsYXNzIFJhdGluZ0xpc3RDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIHB1YmxpYyByYXRpbmdzOiBSYXRpbmdbXSA9IFtdO1xuXG4gICAgcHJpdmF0ZSBjb3Vyc2VJZDogbnVtYmVyO1xuXG4gICAgcmF0aW5nc1NvcnRpbmdQcmVkaWNhdGUgPSAnaWQnO1xuICAgIHJhdGluZ3NSZXZlcnNlT3JkZXIgPSBmYWxzZTtcblxuICAgIC8vIEljb25zXG4gICAgZmFTb3J0ID0gZmFTb3J0O1xuICAgIGZhRm9sZGVyT3BlbiA9IGZhRm9sZGVyT3BlbjtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIHJhdGluZ1NlcnZpY2U6IFJhdGluZ1NlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgICAgICBwcml2YXRlIHNvcnRTZXJ2aWNlOiBTb3J0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcbiAgICApIHt9XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5yb3V0ZS5wYXJlbnQhLnBhcmFtcy5zdWJzY3JpYmUoKHBhcmFtcykgPT4ge1xuICAgICAgICAgICAgdGhpcy5jb3Vyc2VJZCA9IE51bWJlcihwYXJhbXNbJ2NvdXJzZUlkJ10pO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLnJhdGluZ1NlcnZpY2UuZ2V0UmF0aW5nc0ZvckRhc2hib2FyZCh0aGlzLmNvdXJzZUlkKS5zdWJzY3JpYmUoKHJhdGluZ3MpID0+IHtcbiAgICAgICAgICAgIHRoaXMucmF0aW5ncyA9IHJhdGluZ3M7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHNvcnRSb3dzKCkge1xuICAgICAgICB0aGlzLnNvcnRTZXJ2aWNlLnNvcnRCeVByb3BlcnR5KHRoaXMucmF0aW5ncywgdGhpcy5yYXRpbmdzU29ydGluZ1ByZWRpY2F0ZSwgdGhpcy5yYXRpbmdzUmV2ZXJzZU9yZGVyKTtcbiAgICB9XG5cbiAgICBvcGVuUmVzdWx0KHJhdGluZzogUmF0aW5nKSB7XG4gICAgICAgIGNvbnN0IHBhcnRpY2lwYXRpb24gPSByYXRpbmcucmVzdWx0Py5wYXJ0aWNpcGF0aW9uO1xuICAgICAgICBjb25zdCBleGVyY2lzZSA9IHJhdGluZy5yZXN1bHQ/LnBhcnRpY2lwYXRpb24/LmV4ZXJjaXNlO1xuXG4gICAgICAgIGlmIChwYXJ0aWNpcGF0aW9uICYmIGV4ZXJjaXNlKSB7XG4gICAgICAgICAgICBpZiAoZXhlcmNpc2UudHlwZSA9PT0gRXhlcmNpc2VUeXBlLlBST0dSQU1NSU5HKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvY291cnNlcycsIHRoaXMuY291cnNlSWQsIGAke2V4ZXJjaXNlLnR5cGV9LWV4ZXJjaXNlc2AsIGV4ZXJjaXNlLmlkLCAnY29kZS1lZGl0b3InLCBwYXJ0aWNpcGF0aW9uLmlkXSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFsnL2NvdXJzZXMnLCB0aGlzLmNvdXJzZUlkLCBgJHtleGVyY2lzZS50eXBlfS1leGVyY2lzZXNgLCBleGVyY2lzZS5pZCwgJ3BhcnRpY2lwYXRlJywgcGFydGljaXBhdGlvbi5pZF0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cImNvdXJzZS1pbmZvLWJhclwiPlxuICAgIDxkaXYgY2xhc3M9XCJyb3cganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1tZC04XCI+XG4gICAgICAgICAgICA8aDI+XG4gICAgICAgICAgICAgICAgPHNwYW4+e3sgJ2FydGVtaXNBcHAucmF0aW5nTGlzdC50aXRsZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG48L2Rpdj5cbjxkaXYgY2xhc3M9XCJjb2wtMTIgbXQtNFwiPlxuICAgIDxkaXYgY2xhc3M9XCJyb3cgdGFibGUtcmVzcG9uc2l2ZVwiPlxuICAgICAgICA8ZGl2IFtoaWRkZW5dPVwicmF0aW5ncy5sZW5ndGggIT09IDBcIj5cbiAgICAgICAgICAgIDxzcGFuPnt7ICdhcnRlbWlzQXBwLnJhdGluZ0xpc3Qubm9SYXRpbmdUb1Nob3cnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxlXCIgW2hpZGRlbl09XCJyYXRpbmdzLmxlbmd0aCA9PT0gMFwiPlxuICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgIDx0ciBqaGlTb3J0IFsocHJlZGljYXRlKV09XCJyYXRpbmdzU29ydGluZ1ByZWRpY2F0ZVwiIFsoYXNjZW5kaW5nKV09XCJyYXRpbmdzUmV2ZXJzZU9yZGVyXCIgKHNvcnRDaGFuZ2UpPVwic29ydFJvd3MoKVwiPlxuICAgICAgICAgICAgICAgICAgICA8dGggamhpU29ydEJ5PVwiaWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwidGgtbGlua1wiPiM8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVNvcnRcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBqaGlTb3J0Qnk9XCJyZXN1bHQucGFydGljaXBhdGlvbi5leGVyY2lzZS50aXRsZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJ0aC1saW5rXCI+e3sgJ2FydGVtaXNBcHAucmF0aW5nTGlzdC5leGVyY2lzZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFTb3J0XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggamhpU29ydEJ5PVwicmVzdWx0LnBhcnRpY2lwYXRpb24uZXhlcmNpc2UudHlwZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJ0aC1saW5rXCI+e3sgJ2FydGVtaXNBcHAucmF0aW5nTGlzdC5leGVyY2lzZVR5cGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhU29ydFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGpoaVNvcnRCeT1cInJlc3VsdC5hc3Nlc3Nvci5sb2dpblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJ0aC1saW5rXCI+e3sgJ2FydGVtaXNBcHAuY29tcGxhaW50Lmxpc3RPZkNvbXBsYWludHMuYXNzZXNzb3JMb2dpbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFTb3J0XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggamhpU29ydEJ5PVwicmVzdWx0LmFzc2Vzc29yLm5hbWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzPVwidGgtbGlua1wiPnt7ICdhcnRlbWlzQXBwLmNvbXBsYWludC5saXN0T2ZDb21wbGFpbnRzLmFzc2Vzc29yTmFtZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFTb3J0XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggamhpU29ydEJ5PVwicmF0aW5nLnJlc3VsdC5hc3Nlc3NtZW50VHlwZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgY2xhc3M9XCJ0aC1saW5rXCI+e3sgJ2FydGVtaXNBcHAucmF0aW5nTGlzdC5hc3Nlc3NtZW50VHlwZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFTb3J0XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggamhpU29ydEJ5PVwicmF0aW5nXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cInRoLWxpbmtcIj57eyAnYXJ0ZW1pc0FwcC5yYXRpbmdMaXN0LnJhdGluZycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFTb3J0XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3M9XCJ0ZXh0LWNlbnRlclwiPnt7ICdhcnRlbWlzQXBwLnJhdGluZ0xpc3QuYWN0aW9ucycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC90aD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICBAZm9yIChyYXRpbmcgb2YgcmF0aW5nczsgdHJhY2sgcmF0aW5nKSB7XG4gICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyByYXRpbmcuaWQgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgcmF0aW5nLnJlc3VsdD8ucGFydGljaXBhdGlvbj8uZXhlcmNpc2U/LnRpdGxlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyByYXRpbmcucmVzdWx0Py5wYXJ0aWNpcGF0aW9uPy5leGVyY2lzZT8udHlwZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgcmF0aW5nLnJlc3VsdD8uYXNzZXNzb3I/LmxvZ2luIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyByYXRpbmcucmVzdWx0Py5hc3Nlc3Nvcj8ubmFtZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgcmF0aW5nLnJlc3VsdD8uYXNzZXNzbWVudFR5cGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48c3Rhci1yYXRpbmcgY2hlY2tlZENvbG9yPVwiZ29sZFwiIHVuY2hlY2tlZENvbG9yPVwiZ3JleVwiIFt2YWx1ZV09XCJyYXRpbmcucmF0aW5nIHx8IDBcIiBzaXplPVwiMjRcIiBbcmVhZE9ubHldPVwidHJ1ZVwiIFt0b3RhbFN0YXJzXT1cIjVcIj4gPC9zdGFyLXJhdGluZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbVwiIChjbGljayk9XCJvcGVuUmVzdWx0KHJhdGluZylcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFGb2xkZXJPcGVuXCIgW2ZpeGVkV2lkdGhdPVwidHJ1ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgJ2FydGVtaXNBcHAucmF0aW5nTGlzdC5vcGVuU3VibWlzc2lvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICA8L3RhYmxlPlxuICAgIDwvZGl2PlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgUmF0aW5nQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcmF0aW5nL3JhdGluZy5jb21wb25lbnQnO1xuaW1wb3J0IHsgUmF0aW5nTGlzdENvbXBvbmVudCB9IGZyb20gJy4vcmF0aW5nLWxpc3QvcmF0aW5nLWxpc3QuY29tcG9uZW50JztcbmltcG9ydCB7IFN0YXJSYXRpbmdDb21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9yYXRpbmcvc3Rhci1yYXRpbmcvc3Rhci1yYXRpbmcuY29tcG9uZW50JztcblxuQE5nTW9kdWxlKHtcbiAgICBkZWNsYXJhdGlvbnM6IFtSYXRpbmdDb21wb25lbnQsIFJhdGluZ0xpc3RDb21wb25lbnQsIFN0YXJSYXRpbmdDb21wb25lbnRdLFxuICAgIGV4cG9ydHM6IFtSYXRpbmdDb21wb25lbnQsIFN0YXJSYXRpbmdDb21wb25lbnRdLFxuICAgIGltcG9ydHM6IFtDb21tb25Nb2R1bGUsIEFydGVtaXNTaGFyZWRNb2R1bGVdLFxufSlcbmV4cG9ydCBjbGFzcyBSYXRpbmdNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLGtCQUFrQjs7O0FBRDNCLElBUWE7QUFSYjs7QUFRTSxJQUFPLGdCQUFQLE1BQU8sZUFBYTtNQUdGO01BRlosb0JBQW9CO01BRTVCLFlBQW9CLE1BQWdCO0FBQWhCLGFBQUEsT0FBQTtNQUFtQjtNQU92QyxhQUFhLFFBQWdCLFVBQWdCO0FBQ3pDLGVBQU8sS0FBSyxLQUFLLEtBQWEsS0FBSyxvQkFBb0IsR0FBRyxRQUFRLFdBQVcsTUFBTSxJQUFJLElBQUk7TUFDL0Y7TUFNQSxVQUFVLFVBQWdCO0FBQ3RCLGVBQU8sS0FBSyxLQUFLLElBQW1CLEtBQUssb0JBQW9CLEdBQUcsUUFBUSxTQUFTO01BQ3JGO01BT0EsYUFBYSxRQUFnQixVQUFnQjtBQUN6QyxlQUFPLEtBQUssS0FBSyxJQUFZLEtBQUssb0JBQW9CLEdBQUcsUUFBUSxXQUFXLE1BQU0sSUFBSSxJQUFJO01BQzlGO01BTUEsdUJBQXVCLFVBQWdCO0FBQ25DLGVBQU8sS0FBSyxLQUFLLElBQWMsY0FBYyxRQUFRLFNBQVM7TUFDbEU7O3lCQXJDUyxnQkFBYSxzQkFBQSxhQUFBLENBQUE7TUFBQTttRUFBYixnQkFBYSxTQUFiLGVBQWEsV0FBQSxZQUZWLE9BQU0sQ0FBQTs7Ozs7O0FDTnRCLFNBQVMsV0FBVyxZQUFZLGNBQWMsT0FBTyxRQUFRLFdBQVcseUJBQXlCO0FBQ2pHLFNBQVMsZUFBZTs7QUFEeEIsU0FVYTtBQVZiOzs7QUFVTSxJQUFPLHNCQUFQLE1BQU8scUJBQW1CO01BQ3BCLFFBQTRCLENBQUE7TUFFNUI7TUFDQTtNQUNBO01BQ0E7TUFDQSxZQUFZO01BQ1osY0FBYztNQUVkO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUVBLE9BQWdCLG9CQUE0QjtNQUM1QyxPQUFnQixzQkFBOEI7TUFDOUMsT0FBZ0IsV0FBbUI7TUFDbkMsT0FBZ0IsaUJBQXlCO01BQ3pDLE9BQWdCLGtCQUEwQjtNQUMxQyxPQUFnQixtQkFBMkI7TUFDM0MsT0FBZ0IsbUJBQTJCO01BQzNDLE9BQWdCLGdCQUF3QjtNQUVDO01BRWpELGNBQUE7QUFDSSxhQUFLLHFCQUFxQixJQUFJLFFBQU87QUFDckMsYUFBSyxtQkFBbUIsVUFBVSxNQUFLO0FBQ25DLGVBQUssU0FBUTtBQUNiLGVBQUssZUFBZSxJQUFJO0FBQ3hCLGVBQUssa0JBQWlCO0FBQ3RCLGVBQUssd0JBQXdCLEtBQUs7QUFDbEMsZUFBSyxVQUFTO1FBQ2xCLENBQUM7QUFFRCxhQUFLLGdCQUFnQixJQUFJLFFBQU87QUFDaEMsYUFBSyxjQUFjLFVBQVUsTUFBSztBQUM5QixlQUFLLGVBQWM7QUFDbkIsZUFBSyxrQkFBaUI7UUFDMUIsQ0FBQztBQUVELGFBQUssdUJBQXVCLElBQUksUUFBTztBQUN2QyxhQUFLLHFCQUFxQixVQUFVLE1BQUs7QUFDckMsZUFBSyx3QkFBd0IsSUFBSTtRQUNyQyxDQUFDO0FBRUQsYUFBSyx5QkFBeUIsSUFBSSxRQUFPO0FBQ3pDLGFBQUssdUJBQXVCLFVBQVUsTUFBSztBQUN2QyxlQUFLLHdCQUF3QixLQUFLO1FBQ3RDLENBQUM7QUFFRCxhQUFLLGVBQWUsSUFBSSxRQUFPO0FBQy9CLGFBQUssYUFBYSxVQUFVLE1BQUs7QUFDN0IsZUFBSyxrQkFBaUI7UUFDMUIsQ0FBQztBQUVELGFBQUssbUJBQW1CLElBQUksUUFBTztBQUNuQyxhQUFLLGlCQUFpQixVQUFVLE1BQUs7QUFDakMsY0FBSSxLQUFLLFVBQVU7QUFDZixpQkFBSyxhQUFZO2lCQUNkO0FBQ0gsaUJBQUssYUFBWTs7UUFFekIsQ0FBQztNQUNMO01BRVUsT0FBOEYsSUFBSSxhQUFZO01BRXhILElBQWEsYUFBYSxPQUFhO0FBQ25DLGFBQUssZ0JBQWdCO0FBQ3JCLFlBQUksS0FBSyxlQUFlO0FBQ3BCLGVBQUsscUJBQXFCLEtBQUssS0FBSyxhQUFhOztNQUV6RDtNQUVBLElBQUksZUFBWTtBQUNaLGVBQU8sS0FBSztNQUNoQjtNQUVBLElBQWEsZUFBZSxPQUFhO0FBQ3JDLGFBQUssa0JBQWtCO0FBQ3ZCLFlBQUksS0FBSyxpQkFBaUI7QUFDdEIsZUFBSyx1QkFBdUIsS0FBSyxLQUFLLGVBQWU7O01BRTdEO01BRUEsSUFBSSxpQkFBYztBQUNkLGVBQU8sS0FBSztNQUNoQjtNQUVBLElBQWEsTUFBTSxPQUFhO0FBQzVCLGdCQUFRLENBQUMsUUFBUSxJQUFJO0FBQ3JCLGFBQUssU0FBUztBQUNkLFlBQUksS0FBSyxVQUFVLEdBQUc7QUFDbEIsZUFBSyxjQUFjLEtBQUssS0FBSyxNQUFNOztNQUUzQztNQUVBLElBQUksUUFBSztBQUNMLGVBQU8sS0FBSztNQUNoQjtNQUVBLElBQWEsS0FBSyxPQUFhO0FBQzNCLGdCQUFRLENBQUMsU0FBUyxVQUFVLFFBQVEsU0FBUztBQUM3QyxhQUFLLFFBQVE7QUFDYixhQUFLLGFBQWEsS0FBSyxLQUFLLEtBQUs7TUFDckM7TUFFQSxJQUFJLE9BQUk7QUFDSixlQUFPLEtBQUssTUFBTSxPQUFPLENBQUMsS0FBSyxNQUFNLFNBQVMsSUFBSSxJQUFJLE9BQU8sRUFBRTtNQUNuRTtNQUVBLElBQWEsU0FBUyxPQUFjO0FBQ2hDLGFBQUssWUFBWTtBQUNqQixhQUFLLGlCQUFpQixLQUFLLEtBQUs7TUFDcEM7TUFFQSxJQUFJLFdBQVE7QUFDUixlQUFPLE9BQU8sS0FBSyxTQUFTLE1BQU07TUFDdEM7TUFFQSxJQUFhLFdBQVcsT0FBYTtBQUNqQyxhQUFLLGNBQWMsU0FBUyxJQUFJLElBQUksS0FBSyxNQUFNLEtBQUs7QUFDcEQsYUFBSyxtQkFBbUIsS0FBSyxLQUFLLFdBQVc7TUFDakQ7TUFFQSxJQUFJLGFBQVU7QUFDVixlQUFPLEtBQUs7TUFDaEI7TUFFUSxlQUFZO0FBQ2hCLFlBQUksQ0FBQyxLQUFLLGFBQWE7QUFDbkI7O0FBRUosYUFBSyxZQUFZLGNBQWMsTUFBTSxTQUFTO0FBQzlDLGFBQUssWUFBWSxjQUFjLFFBQVEsS0FBSztBQUM1QyxhQUFLLE1BQU0sUUFBUSxDQUFDLFNBQXFCO0FBQ3JDLGVBQUssTUFBTSxTQUFTO0FBQ3BCLGVBQUssUUFBUSxLQUFLLFFBQVE7UUFDOUIsQ0FBQztNQUNMO01BRVEsZUFBWTtBQUNoQixZQUFJLENBQUMsS0FBSyxhQUFhO0FBQ25COztBQUVKLGFBQUssWUFBWSxjQUFjLE1BQU0sU0FBUztBQUM5QyxhQUFLLFlBQVksY0FBYyxRQUFRLEtBQUs7QUFDNUMsYUFBSyxNQUFNLFFBQVEsQ0FBQyxTQUFxQjtBQUNyQyxlQUFLLE1BQU0sU0FBUztBQUNwQixlQUFLLFFBQVE7UUFDakIsQ0FBQztNQUNMO01BRVEsWUFBUztBQUNiLFlBQUksQ0FBQyxLQUFLLGFBQWE7QUFDbkI7O0FBRUosYUFBSyxZQUFZLGNBQWMsaUJBQWlCLGNBQWMsS0FBSyxRQUFRLEtBQUssSUFBSSxDQUFDO0FBQ3JGLGFBQUssWUFBWSxjQUFjLE1BQU0sU0FBUztBQUM5QyxhQUFLLFlBQVksY0FBYyxRQUFRLEtBQUs7QUFDNUMsYUFBSyxNQUFNLFFBQVEsQ0FBQyxTQUFxQjtBQUNyQyxlQUFLLGlCQUFpQixTQUFTLEtBQUssT0FBTyxLQUFLLElBQUksQ0FBQztBQUNyRCxlQUFLLGlCQUFpQixjQUFjLEtBQUssT0FBTyxLQUFLLElBQUksQ0FBQztBQUMxRCxlQUFLLE1BQU0sU0FBUztBQUNwQixlQUFLLFFBQVEsS0FBSyxRQUFRO1FBQzlCLENBQUM7TUFDTDtNQUVRLE9BQU8sT0FBaUI7QUFDNUIsWUFBSSxLQUFLLFVBQVU7QUFDZjs7QUFFSixjQUFNLE9BQWlDLE1BQU07QUFDN0MsY0FBTSxXQUFXLEtBQUs7QUFDdEIsYUFBSyxRQUFRLFNBQVMsS0FBSyxRQUFRLE9BQVEsRUFBRTtBQUM3QyxjQUFNLGFBQWEsRUFBRSxVQUFVLFVBQVUsS0FBSyxPQUFPLFlBQVksS0FBSTtBQUNyRSxhQUFLLEtBQUssS0FBSyxVQUFVO01BQzdCO01BRVEsT0FBTyxPQUFpQjtBQUM1QixZQUFJLEtBQUssVUFBVTtBQUNmOztBQUVKLGNBQU0sT0FBaUMsTUFBTTtBQUM3QyxjQUFNLGVBQWUsU0FBUyxLQUFLLFFBQVEsT0FBUSxFQUFFO0FBRXJELGlCQUFTLFFBQVEsR0FBRyxRQUFRLGNBQWMsU0FBUztBQUMvQyxlQUFLLE1BQU0sS0FBSyxFQUFFLFlBQVk7QUFDOUIsK0JBQW9CLGdCQUFnQixLQUFLLE1BQU0sS0FBSyxDQUFDO0FBQ3JELCtCQUFvQixvQkFBb0IsS0FBSyxNQUFNLEtBQUssQ0FBQzs7QUFHN0QsaUJBQVMsUUFBUSxjQUFjLFFBQVEsS0FBSyxNQUFNLFFBQVEsU0FBUztBQUMvRCxlQUFLLE1BQU0sS0FBSyxFQUFFLFlBQVk7QUFDOUIsK0JBQW9CLGdCQUFnQixLQUFLLE1BQU0sS0FBSyxDQUFDOztNQUU3RDtNQUVRLFVBQU87QUFDWCxhQUFLLGVBQWM7TUFDdkI7TUFFUSxPQUFPLGdCQUFnQixNQUFhO0FBQ3hDLGFBQUssVUFBVSxJQUFJLHFCQUFvQixnQkFBZ0I7TUFDM0Q7TUFFUSxPQUFPLG9CQUFvQixNQUFhO0FBQzVDLGFBQUssVUFBVSxJQUFJLHFCQUFvQixnQkFBZ0I7TUFDM0Q7TUFFUSxPQUFPLGlCQUFpQixNQUFhO0FBQ3pDLGFBQUssVUFBVSxJQUFJLHFCQUFvQixhQUFhO01BQ3hEO01BRVEsV0FBUTtBQUNaLFlBQUksQ0FBQyxLQUFLLGFBQWE7QUFDbkI7O0FBRUosY0FBTSxnQkFBZ0MsS0FBSyxZQUFZO0FBQ3ZELGNBQU0sV0FBVyxDQUFDLEdBQUcsTUFBTSxLQUFLLFdBQVcsRUFBRSxLQUFJLENBQUU7QUFDbkQsYUFBSyxNQUFNLFNBQVM7QUFDcEIsc0JBQWMsWUFBWTtBQUMxQixpQkFBUyxRQUFRLENBQUMsZUFBYztBQUM1QixnQkFBTSxjQUErQixTQUFTLGNBQWMsTUFBTTtBQUNsRSxzQkFBWSxRQUFRLFNBQVMsYUFBYSxHQUFHLFNBQVE7QUFDckQsc0JBQVksUUFBUSxZQUFZLFFBQVE7QUFDeEMsd0JBQWMsWUFBWSxXQUFXO0FBQ3JDLGVBQUssTUFBTSxLQUFLLFdBQVc7UUFDL0IsQ0FBQztNQUNMO01BRVEsb0JBQWlCO0FBQ3JCLFlBQUksS0FBSyxPQUFPO0FBQ1osY0FBSSxLQUFLLE1BQU0sV0FBVyxHQUFHO0FBQ3pCLGlCQUFLLFNBQVE7O0FBR2pCLGdCQUFNLFVBQVUsS0FBSyxLQUFLLE1BQU0sS0FBSyxFQUFHLENBQUM7QUFDekMsZ0JBQU0sV0FBWSxTQUFTLFNBQVMsRUFBRSxJQUFJLEtBQU07QUFDaEQsZ0JBQU0sYUFBYSxJQUFLLFNBQVMsU0FBUyxFQUFFLElBQUksS0FBTTtBQUV0RCxlQUFLLE1BQU0sUUFBUSxDQUFDLFNBQXFCO0FBQ3JDLGlCQUFLLE1BQU0sWUFBWSxxQkFBb0IsVUFBVSxLQUFLLElBQUk7QUFDOUQsZ0JBQUksS0FBSyxVQUFVLFNBQVMscUJBQW9CLGFBQWEsR0FBRztBQUM1RCxtQkFBSyxNQUFNLFlBQVkscUJBQW9CLGdCQUFnQixHQUFHLFFBQVEsSUFBSTtBQUMxRSxtQkFBSyxNQUFNLFlBQVkscUJBQW9CLGlCQUFpQixHQUFHLFVBQVUsSUFBSTs7VUFFckYsQ0FBQzs7TUFFVDtNQUVRLHdCQUF3QixZQUFtQjtBQUMvQyxZQUFJLEtBQUssTUFBTSxXQUFXLEdBQUc7QUFDekIsZUFBSyxTQUFROztBQUVqQixhQUFLLE1BQU0sUUFBUSxDQUFDLFNBQXFCO0FBQ3JDLGNBQUksWUFBWTtBQUNaLGlCQUFLLHVCQUF1QixJQUFJO2lCQUM3QjtBQUNILGlCQUFLLHlCQUF5QixJQUFJOztRQUUxQyxDQUFDO01BQ0w7TUFFUSxnQkFBZ0IsYUFBNEI7QUFDaEQsYUFBSyx1QkFBdUIsV0FBVztBQUN2QyxhQUFLLHlCQUF5QixXQUFXO01BQzdDO01BRVEsdUJBQXVCLGFBQTRCO0FBQ3ZELG9CQUFZLE1BQU0sWUFBWSxxQkFBb0IsbUJBQW1CLEtBQUssYUFBYTtNQUMzRjtNQUVRLHlCQUF5QixhQUE0QjtBQUN6RCxvQkFBWSxNQUFNLFlBQVkscUJBQW9CLHFCQUFxQixLQUFLLGVBQWU7TUFDL0Y7TUFFUSxlQUFlLGdCQUFnQixPQUFLO0FBQ3hDLFlBQUksQ0FBQyxLQUFLLGFBQWE7QUFDbkI7O0FBRUosWUFBSSxLQUFLLFlBQVksQ0FBQyxlQUFlO0FBQ2pDOztBQUdKLFlBQUksS0FBSyxNQUFNLFdBQVcsR0FBRztBQUN6QixlQUFLLFNBQVE7O0FBRWpCLGFBQUssWUFBWSxjQUFjLFFBQVEsS0FBSztBQUU1QyxZQUFJLGNBQWMsQ0FBQyxFQUFFLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUSxDQUFFLElBQUksR0FBRyxTQUFRLEVBQUcsVUFBVSxHQUFHLENBQUM7QUFFNUYsYUFBSyxNQUFNLFFBQVEsQ0FBQyxNQUFtQixNQUFhO0FBQ2hELGVBQUssWUFBWTtBQUNqQixlQUFLLGdCQUFnQixJQUFJO0FBQ3pCLCtCQUFvQixnQkFBZ0IsSUFBSTtBQUV4QyxjQUFJLEtBQUssUUFBUSxHQUFHO0FBRWhCLGlDQUFvQixvQkFBb0IsSUFBSTtpQkFDekM7QUFFSCxnQkFBSSxhQUFhO0FBQ2IsbUNBQW9CLGlCQUFpQixJQUFJO0FBQ3pDLDRCQUFjOzs7UUFHMUIsQ0FBQztNQUNMOzt5QkF4VFMsc0JBQW1CO01BQUE7aUVBQW5CLHNCQUFtQixXQUFBLENBQUEsQ0FBQSxhQUFBLENBQUEsR0FBQSxXQUFBLFNBQUEsMEJBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7Ozs7Ozs7OztBQUpqQixVQUFBLHdCQUFBLEdBQUEsT0FBQSxNQUFBLENBQUE7Ozs7O3FGQUlGLHFCQUFtQixFQUFBLFdBQUEsc0JBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FDVmhDLFNBQVMsYUFBQUEsWUFBVyxTQUFBQyxjQUFxQjs7QUFBekMsSUFhYTtBQWJiOztBQUNBO0FBRUE7QUFFQTs7Ozs7QUFRTSxJQUFPLGtCQUFQLE1BQU8saUJBQWU7TUFNWjtNQUNBO01BTkw7TUFDQSxnQkFBZ0I7TUFDZDtNQUVULFlBQ1ksZUFDQSxnQkFBOEI7QUFEOUIsYUFBQSxnQkFBQTtBQUNBLGFBQUEsaUJBQUE7TUFDVDtNQUVILFdBQVE7QUFDSixZQUFJLENBQUMsS0FBSyxRQUFRLE1BQU0sQ0FBQyxLQUFLLE9BQU8saUJBQWlCLENBQUMsS0FBSyxlQUFlLHVCQUF1QixLQUFLLE9BQU8sYUFBcUMsR0FBRztBQUNsSjs7QUFHSixhQUFLLGNBQWMsVUFBVSxLQUFLLE9BQU8sRUFBRSxFQUFFLFVBQVUsQ0FBQyxXQUFVO0FBQzlELGVBQUssU0FBUyxVQUFVO1FBQzVCLENBQUM7TUFDTDtNQU1BLE9BQU8sT0FBOEU7QUFFakYsWUFBSSxLQUFLLGlCQUFpQixDQUFDLEtBQUssUUFBUTtBQUNwQzs7QUFHSixjQUFNLFlBQVksS0FBSztBQUN2QixhQUFLLFNBQVMsTUFBTTtBQUVwQixhQUFLLGdCQUFnQjtBQUNyQixZQUFJO0FBRUosWUFBSSxXQUFXO0FBQ1gsdUJBQWEsS0FBSyxjQUFjLGFBQWEsS0FBSyxRQUFRLEtBQUssT0FBTyxFQUFHO2VBQ3RFO0FBQ0gsdUJBQWEsS0FBSyxjQUFjLGFBQWEsS0FBSyxRQUFRLEtBQUssT0FBTyxFQUFHOztBQUc3RSxtQkFBVyxVQUFVLENBQUMsV0FBWSxLQUFLLFNBQVMsTUFBTyxFQUFFLElBQUksTUFBTyxLQUFLLGdCQUFnQixLQUFNO01BQ25HOzt5QkEzQ1Msa0JBQWUsZ0NBQUEsYUFBQSxHQUFBLGdDQUFBLGNBQUEsQ0FBQTtNQUFBO2lFQUFmLGtCQUFlLFdBQUEsQ0FBQSxDQUFBLFlBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxRQUFBLFNBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLGdCQUFBLHlCQUFBLEdBQUEsQ0FBQSxnQkFBQSxRQUFBLGtCQUFBLFFBQUEsR0FBQSxTQUFBLFFBQUEsWUFBQSxjQUFBLE1BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSx5QkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ2I1QixVQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLEdBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsd0JBQUEsR0FBQSxRQUFBLENBQUE7QUFDSixVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxlQUFBLENBQUE7QUFBK0gsVUFBQSx5QkFBQSxRQUFBLFNBQUEscURBQUEsUUFBQTtBQUFBLG1CQUFRLElBQUEsT0FBQSxNQUFBO1VBQWMsQ0FBQTtBQUFHLFVBQUEscUJBQUEsR0FBQSxHQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUM1SixVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBTkssVUFBQSwwQkFBQSxpQkFBQSxJQUFBLGFBQUE7QUFJc0QsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxTQUFBLElBQUEsVUFBQSxDQUFBLEVBQXFCLFFBQUEsSUFBQSxFQUFBLFlBQUEsS0FBQSxFQUFBLGNBQUEsQ0FBQTs7Ozs7cUZEU25FLGlCQUFlLEVBQUEsV0FBQSxrQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUViNUIsU0FBUyxhQUFBQyxrQkFBeUI7QUFHbEMsU0FBUyxnQkFBZ0IsY0FBYztBQUd2QyxTQUFTLGNBQWMsY0FBYzs7Ozs7OztBQzRDakIsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUNKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBO0FBQW1ELElBQUEsMkJBQUE7QUFDN0QsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEVBQUE7QUFBa0QsSUFBQSwyQkFBQTtBQUM1RCxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsRUFBQTtBQUFvQyxJQUFBLDJCQUFBO0FBQzlDLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxFQUFBO0FBQW1DLElBQUEsMkJBQUE7QUFDN0MsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEVBQUE7QUFBbUMsSUFBQSwyQkFBQTtBQUM3QyxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUNLLElBQUEsZUFBQSxFQUFBO0FBQWtJLElBQUEscUJBQUEsSUFBQSxHQUFBO0FBQUEsSUFBQSwyQkFBQSxFQUN0STtBQUNMLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUF1QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSxnRUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxZQUFBLFlBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFTLDBCQUFBLE9BQUEsV0FBQSxTQUFBLENBQWtCO0lBQUEsQ0FBQTtBQUM5RCxJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEVBQUE7O0FBQStELElBQUEsMkJBQUE7QUFDekUsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBOzs7OztBQTdCWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtDQUFBLFVBQUEsSUFBQSw0QkFBQTtBQUdNLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsVUFBQSxVQUFBLE9BQUEsT0FBQSxVQUFBLE9BQUEsaUJBQUEsT0FBQSxPQUFBLFVBQUEsT0FBQSxjQUFBLFlBQUEsT0FBQSxPQUFBLFVBQUEsT0FBQSxjQUFBLFNBQUEsS0FBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsVUFBQSxVQUFBLE9BQUEsT0FBQSxVQUFBLE9BQUEsaUJBQUEsT0FBQSxPQUFBLFVBQUEsT0FBQSxjQUFBLFlBQUEsT0FBQSxPQUFBLFVBQUEsT0FBQSxjQUFBLFNBQUEsSUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsVUFBQSxVQUFBLE9BQUEsT0FBQSxVQUFBLE9BQUEsWUFBQSxPQUFBLE9BQUEsVUFBQSxPQUFBLFNBQUEsS0FBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsVUFBQSxVQUFBLE9BQUEsT0FBQSxVQUFBLE9BQUEsWUFBQSxPQUFBLE9BQUEsVUFBQSxPQUFBLFNBQUEsSUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsVUFBQSxVQUFBLE9BQUEsT0FBQSxVQUFBLE9BQUEsY0FBQTtBQUlzRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFNBQUEsVUFBQSxVQUFBLENBQUEsRUFBNEIsWUFBQSxJQUFBLEVBQUEsY0FBQSxDQUFBO0FBSzNFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLFlBQUEsRUFBcUIsY0FBQSxJQUFBO0FBQ3hCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLHNDQUFBLENBQUE7OztBRDdFdEMsSUFhYTtBQWJiOztBQUNBO0FBR0E7QUFDQTs7Ozs7OztBQVFNLElBQU8sc0JBQVAsTUFBTyxxQkFBbUI7TUFhaEI7TUFDQTtNQUNBO01BQ0E7TUFmTCxVQUFvQixDQUFBO01BRW5CO01BRVIsMEJBQTBCO01BQzFCLHNCQUFzQjtNQUd0QixTQUFTO01BQ1QsZUFBZTtNQUVmLFlBQ1ksZUFDQSxPQUNBLGFBQ0EsUUFBYztBQUhkLGFBQUEsZ0JBQUE7QUFDQSxhQUFBLFFBQUE7QUFDQSxhQUFBLGNBQUE7QUFDQSxhQUFBLFNBQUE7TUFDVDtNQUVILFdBQVE7QUFDSixhQUFLLE1BQU0sT0FBUSxPQUFPLFVBQVUsQ0FBQyxXQUFVO0FBQzNDLGVBQUssV0FBVyxPQUFPLE9BQU8sVUFBVSxDQUFDO1FBQzdDLENBQUM7QUFFRCxhQUFLLGNBQWMsdUJBQXVCLEtBQUssUUFBUSxFQUFFLFVBQVUsQ0FBQyxZQUFXO0FBQzNFLGVBQUssVUFBVTtRQUNuQixDQUFDO01BQ0w7TUFFQSxXQUFRO0FBQ0osYUFBSyxZQUFZLGVBQWUsS0FBSyxTQUFTLEtBQUsseUJBQXlCLEtBQUssbUJBQW1CO01BQ3hHO01BRUEsV0FBVyxRQUFjO0FBQ3JCLGNBQU0sZ0JBQWdCLE9BQU8sUUFBUTtBQUNyQyxjQUFNLFdBQVcsT0FBTyxRQUFRLGVBQWU7QUFFL0MsWUFBSSxpQkFBaUIsVUFBVTtBQUMzQixjQUFJLFNBQVMsU0FBUyxhQUFhLGFBQWE7QUFDNUMsaUJBQUssT0FBTyxTQUFTLENBQUMsWUFBWSxLQUFLLFVBQVUsR0FBRyxTQUFTLElBQUksY0FBYyxTQUFTLElBQUksZUFBZSxjQUFjLEVBQUUsQ0FBQztpQkFDekg7QUFDSCxpQkFBSyxPQUFPLFNBQVMsQ0FBQyxZQUFZLEtBQUssVUFBVSxHQUFHLFNBQVMsSUFBSSxjQUFjLFNBQVMsSUFBSSxlQUFlLGNBQWMsRUFBRSxDQUFDOzs7TUFHeEk7O3lCQTVDUyxzQkFBbUIsZ0NBQUEsYUFBQSxHQUFBLGdDQUFBLGlCQUFBLEdBQUEsZ0NBQUEsV0FBQSxHQUFBLGdDQUFBLFNBQUEsQ0FBQTtNQUFBO2lFQUFuQixzQkFBbUIsV0FBQSxDQUFBLENBQUEsaUJBQUEsQ0FBQSxHQUFBLE9BQUEsS0FBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLHlCQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsV0FBQSxJQUFBLEdBQUEsYUFBQSxhQUFBLG1CQUFBLG1CQUFBLFlBQUEsR0FBQSxDQUFBLGFBQUEsSUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLGFBQUEscUNBQUEsR0FBQSxDQUFBLGFBQUEsb0NBQUEsR0FBQSxDQUFBLGFBQUEsdUJBQUEsR0FBQSxDQUFBLGFBQUEsc0JBQUEsR0FBQSxDQUFBLGFBQUEsOEJBQUEsR0FBQSxDQUFBLGFBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxnQkFBQSxRQUFBLGtCQUFBLFFBQUEsUUFBQSxNQUFBLEdBQUEsU0FBQSxZQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxlQUFBLFVBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsWUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDZCQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDYmhDLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sVUFBQSxxQkFBQSxDQUFBOztBQUFzRCxVQUFBLDJCQUFBO0FBQ2hFLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLFVBQUEscUJBQUEsRUFBQTs7QUFBK0QsVUFBQSwyQkFBQTtBQUN6RSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxNQUFBLENBQUE7QUFBWSxVQUFBLHlCQUFBLG1CQUFBLFNBQUEsNERBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsMEJBQUE7VUFBQSxDQUFBLEVBQXVDLG1CQUFBLFNBQUEsNERBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsc0JBQUE7VUFBQSxDQUFBLEVBQUEsY0FBQSxTQUFBLHlEQUFBO0FBQUEsbUJBQW1ELElBQUEsU0FBQTtVQUFVLENBQUE7QUFDNUcsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBLENBQUE7QUFBbUIsVUFBQSxxQkFBQSxJQUFBLEdBQUE7QUFBQyxVQUFBLDJCQUFBO0FBQ3BCLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBLENBQUE7QUFBbUIsVUFBQSxxQkFBQSxFQUFBOztBQUF5RCxVQUFBLDJCQUFBO0FBQzVFLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBLENBQUE7QUFBbUIsVUFBQSxxQkFBQSxFQUFBOztBQUE2RCxVQUFBLDJCQUFBO0FBQ2hGLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBLENBQUE7QUFBbUIsVUFBQSxxQkFBQSxFQUFBOztBQUE4RSxVQUFBLDJCQUFBO0FBQ2pHLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBLENBQUE7QUFBbUIsVUFBQSxxQkFBQSxFQUFBOztBQUE2RSxVQUFBLDJCQUFBO0FBQ2hHLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBLENBQUE7QUFBbUIsVUFBQSxxQkFBQSxFQUFBOztBQUErRCxVQUFBLDJCQUFBO0FBQ2xGLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBLENBQUE7QUFBbUIsVUFBQSxxQkFBQSxFQUFBOztBQUF1RCxVQUFBLDJCQUFBO0FBQzFFLFVBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUF3QixVQUFBLHFCQUFBLEVBQUE7O0FBQXdELFVBQUEsMkJBQUE7QUFDcEYsVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEtBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLEtBQUEsT0FBQTtBQUNJLFVBQUEscUJBQUEsS0FBQSxvQkFBQTtBQUFBLFVBQUEsK0JBQUEsS0FBQSxzQ0FBQSxJQUFBLElBQUEsTUFBQSxNQUFBLHVDQUFBO0FBaUNKLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLEtBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLEtBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLEtBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEtBQUEsSUFBQTs7O0FBbEZzQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSw2QkFBQSxDQUFBO0FBT1QsVUFBQSx3QkFBQSxFQUFBO0FBQUEsVUFBQSx5QkFBQSxVQUFBLElBQUEsUUFBQSxXQUFBLENBQUE7QUFDSyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSxzQ0FBQSxDQUFBO0FBRVcsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxVQUFBLElBQUEsUUFBQSxXQUFBLENBQUE7QUFFRCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLGFBQUEsSUFBQSx1QkFBQSxFQUF1QyxhQUFBLElBQUEsbUJBQUE7QUFHbEMsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsTUFBQTtBQUdVLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLGdDQUFBLENBQUE7QUFDVixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxNQUFBO0FBR1UsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSwwQkFBQSxJQUFBLElBQUEsb0NBQUEsQ0FBQTtBQUNWLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLE1BQUE7QUFHVSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSxxREFBQSxDQUFBO0FBQ1YsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsTUFBQTtBQUdVLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLG9EQUFBLENBQUE7QUFDVixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxNQUFBO0FBR1UsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSwwQkFBQSxJQUFBLElBQUEsc0NBQUEsQ0FBQTtBQUNWLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLE1BQUE7QUFHVSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSw4QkFBQSxDQUFBO0FBQ1YsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsTUFBQTtBQUVXLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLCtCQUFBLENBQUE7QUFJNUIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLE9BQUE7Ozs7O3FGRHBDSCxxQkFBbUIsRUFBQSxXQUFBLHNCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRWJoQyxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLG9CQUFvQjs7QUFEN0IsSUFZYTtBQVpiOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBT00sSUFBTyxlQUFQLE1BQU8sY0FBWTs7eUJBQVosZUFBWTtNQUFBO2dFQUFaLGNBQVksQ0FBQTtvRUFGWCxjQUFjLG1CQUFtQixFQUFBLENBQUE7Ozs7IiwibmFtZXMiOlsiQ29tcG9uZW50IiwiSW5wdXQiLCJDb21wb25lbnQiXX0=