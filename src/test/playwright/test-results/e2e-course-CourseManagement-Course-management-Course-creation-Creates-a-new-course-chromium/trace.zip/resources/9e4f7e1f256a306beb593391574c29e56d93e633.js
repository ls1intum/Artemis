import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NI5XS6XH.js?v=b97f8625";

// node_modules/dayjs/esm/plugin/isoWeeksInYear/index.js
var isoWeeksInYear_default = function(o, c) {
  var proto = c.prototype;
  proto.isoWeeksInYear = function() {
    var isLeapYear = this.isLeapYear();
    var last = this.endOf("y");
    var day = last.day();
    if (day === 4 || isLeapYear && day === 5) {
      return 53;
    }
    return 52;
  };
};
export {
  isoWeeksInYear_default as default
};
//# sourceMappingURL=dayjs_esm_plugin_isoWeeksInYear.js.map
