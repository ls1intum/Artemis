import {
  TeamStudentsListComponent,
  init_team_students_list_component
} from "/chunk-NLZGJEV2.js";
import {
  formatTeamAsSearchResult,
  init_team_utils
} from "/chunk-4IATQ5I4.js";
import {
  DataTableComponent,
  init_data_table_component
} from "/chunk-KUURZL6B.js";
import {
  User,
  init_user_model
} from "/chunk-J4XZ2MC2.js";
import {
  TeamService,
  init_team_service
} from "/chunk-ORYTP7RT.js";
import {
  SHORT_NAME_PATTERN,
  init_input_constants
} from "/chunk-HFO42WCR.js";
import {
  AccountService,
  ActionType,
  AlertService,
  ArtemisDatePipe,
  ArtemisTranslatePipe,
  ButtonComponent,
  ButtonSize,
  ButtonType,
  CourseManagementService,
  DeleteButtonDirective,
  EventManager,
  ExerciseService,
  HelpIconComponent,
  ParticipationService,
  RemoveKeysPipe,
  TranslateDirective,
  __async,
  __esm,
  __spreadProps,
  __spreadValues,
  init_account_service,
  init_alert_service,
  init_artemis_date_pipe,
  init_artemis_translate_pipe,
  init_button_component,
  init_course_management_service,
  init_course_model,
  init_delete_button_directive,
  init_delete_dialog_model,
  init_event_manager_service,
  init_exercise_model,
  init_exercise_service,
  init_help_icon_component,
  init_participation_service,
  init_remove_keys_pipe,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/entities/team.model.ts
var TeamImportStrategyType, Team;
var init_team_model = __esm({
  "src/main/webapp/app/entities/team.model.ts"() {
    (function(TeamImportStrategyType2) {
      TeamImportStrategyType2["PURGE_EXISTING"] = "PURGE_EXISTING";
      TeamImportStrategyType2["CREATE_ONLY"] = "CREATE_ONLY";
    })(TeamImportStrategyType || (TeamImportStrategyType = {}));
    Team = class {
      id;
      name;
      shortName;
      image;
      students;
      owner;
      createdBy;
      createdDate;
      lastModifiedBy;
      lastModifiedDate;
      constructor() {
        this.students = [];
      }
    };
  }
});

// src/main/webapp/app/exercises/shared/team/team-student-search/team-student-search.component.ts
import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { combineLatest, of } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { catchError, debounceTime, distinctUntilChanged, map, switchMap, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { get } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
var _c0, TeamStudentSearchComponent;
var init_team_student_search_component = __esm({
  "src/main/webapp/app/exercises/shared/team/team-student-search/team-student-search.component.ts"() {
    init_course_model();
    init_exercise_model();
    init_team_service();
    init_team_model();
    init_team_service();
    init_artemis_translate_pipe();
    _c0 = ["ngbTypeahead"];
    TeamStudentSearchComponent = class _TeamStudentSearchComponent {
      teamService;
      ngbTypeahead;
      course;
      exercise;
      team;
      studentsFromPendingTeam = [];
      selectStudent = new EventEmitter();
      searching = new EventEmitter();
      searchQueryTooShort = new EventEmitter();
      searchFailed = new EventEmitter();
      searchNoResults = new EventEmitter();
      inputDisplayValue;
      constructor(teamService) {
        this.teamService = teamService;
      }
      onAutocompleteSelect = (student) => {
        this.inputDisplayValue = "";
        this.selectStudent.emit(student);
      };
      searchInputFormatter = () => {
        return this.inputDisplayValue;
      };
      searchResultFormatter = (student) => {
        const { login, name } = student;
        return `${name} (${login})`;
      };
      onSearch = (text$) => {
        return text$.pipe(debounceTime(200), distinctUntilChanged(), tap(() => {
          this.searchQueryTooShort.emit(false);
          this.searchFailed.emit(false);
          this.searchNoResults.emit(void 0);
        }), tap(() => this.searching.emit(true)), switchMap((loginOrName) => {
          if (loginOrName.length < 3) {
            this.searchQueryTooShort.emit(true);
            return combineLatest([of(loginOrName), of(void 0)]);
          }
          return combineLatest([
            of(loginOrName),
            this.teamService.searchInCourseForExerciseTeam(this.course, this.exercise, loginOrName).pipe(map((usersResponse) => usersResponse.body)).pipe(catchError(() => {
              this.searchFailed.emit(true);
              return of(void 0);
            }))
          ]);
        }), tap(() => this.searching.emit(false)), tap(([loginOrName, users]) => {
          if (users && users.length === 0) {
            this.searchNoResults.emit(loginOrName);
          }
        }), map(([, users]) => users || []), tap((users) => {
          setTimeout(() => {
            for (let i = 0; i < this.typeaheadButtons.length; i++) {
              if (!this.userCanBeAddedToPendingTeam(users[i])) {
                this.typeaheadButtons[i].setAttribute("disabled", "");
              }
            }
          });
        }));
      };
      userCanBeAddedToPendingTeam(user) {
        if (this.studentsFromPendingTeam.map((s) => s.id).includes(user.id)) {
          return false;
        } else if (!user.assignedTeamId) {
          return true;
        } else if (!this.team.id) {
          return false;
        }
        return user.assignedTeamId === this.team.id;
      }
      get typeaheadButtons() {
        return get(this.ngbTypeahead, "nativeElement.nextSibling.children", []);
      }
      static \u0275fac = function TeamStudentSearchComponent_Factory(t) {
        return new (t || _TeamStudentSearchComponent)(i0.\u0275\u0275directiveInject(TeamService));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _TeamStudentSearchComponent, selectors: [["jhi-team-student-search"]], viewQuery: function TeamStudentSearchComponent_Query(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275viewQuery(_c0, 5);
        }
        if (rf & 2) {
          let _t;
          i0.\u0275\u0275queryRefresh(_t = i0.\u0275\u0275loadQuery()) && (ctx.ngbTypeahead = _t.first);
        }
      }, inputs: { course: "course", exercise: "exercise", team: "team", studentsFromPendingTeam: "studentsFromPendingTeam" }, outputs: { selectStudent: "selectStudent", searching: "searching", searchQueryTooShort: "searchQueryTooShort", searchFailed: "searchFailed", searchNoResults: "searchNoResults" }, decls: 4, vars: 6, consts: [["id", "student-search-input", "type", "text", 1, "form-control", 3, "placeholder", "ngbTypeahead", "resultFormatter", "inputFormatter", "selectItem"], ["ngbTypeahead", ""]], template: function TeamStudentSearchComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "input", 0, 1);
          i0.\u0275\u0275listener("selectItem", function TeamStudentSearchComponent_Template_input_selectItem_0_listener($event) {
            return ctx.onAutocompleteSelect($event.item);
          });
          i0.\u0275\u0275pipe(2, "artemisTranslate");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(3, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275property("placeholder", i0.\u0275\u0275pipeBind1(2, 4, "artemisApp.team.addStudentToTeam"))("ngbTypeahead", ctx.onSearch)("resultFormatter", ctx.searchResultFormatter)("inputFormatter", ctx.searchInputFormatter);
        }
      }, dependencies: [i2.NgbTypeahead, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(TeamStudentSearchComponent, { className: "TeamStudentSearchComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/team-owner-search/team-owner-search.component.ts
import { Component as Component2, EventEmitter as EventEmitter2, Input as Input2, Output as Output2, ViewChild as ViewChild2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject, combineLatest as combineLatest2, merge, of as of2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { catchError as catchError2, filter, map as map2, switchMap as switchMap2, tap as tap2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { cloneDeep } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import { NgbTypeahead as NgbTypeahead2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
var _c02, TeamOwnerSearchComponent;
var init_team_owner_search_component = __esm({
  "src/main/webapp/app/exercises/shared/team/team-owner-search/team-owner-search.component.ts"() {
    init_course_model();
    init_exercise_model();
    init_team_model();
    init_course_management_service();
    init_course_management_service();
    init_artemis_translate_pipe();
    _c02 = ["instance"];
    TeamOwnerSearchComponent = class _TeamOwnerSearchComponent {
      courseService;
      ngbTypeahead;
      focus = new Subject();
      click = new Subject();
      inputDisabled;
      course;
      exercise;
      team;
      selectOwner = new EventEmitter2();
      searching = new EventEmitter2();
      searchQueryTooShort = new EventEmitter2();
      searchFailed = new EventEmitter2();
      searchNoResults = new EventEmitter2();
      owner;
      ownerOptions = [];
      ownerOptionsLoaded = false;
      inputDisplayValue;
      constructor(courseService) {
        this.courseService = courseService;
      }
      ngOnInit() {
        if (this.team.owner) {
          this.owner = cloneDeep(this.team.owner);
          this.inputDisplayValue = this.searchResultFormatter(this.owner);
        }
      }
      onAutocompleteSelect = (owner) => {
        this.inputDisplayValue = this.searchResultFormatter(owner);
        this.selectOwner.emit(owner);
      };
      searchInputFormatter = () => {
        return this.inputDisplayValue;
      };
      searchResultFormatter = (owner) => {
        const { login, name } = owner;
        return `${name} (${login})`;
      };
      searchMatchesUser(loginOrName, user) {
        return [user.login, user.name].some((field) => {
          return (field || "").toLowerCase().includes(loginOrName.toLowerCase());
        });
      }
      onSearch = (text$) => {
        const clicksWithClosedPopup$ = this.click.pipe(filter(() => !this.ngbTypeahead.isPopupOpen()));
        const inputFocus$ = this.focus;
        return merge(text$, inputFocus$, clicksWithClosedPopup$).pipe(tap2(() => {
          this.searchNoResults.emit(void 0);
        }), switchMap2((loginOrName) => {
          this.searchFailed.emit(false);
          this.searching.emit(true);
          const ownerOptionsSource$ = this.ownerOptionsLoaded ? of2(this.ownerOptions) : this.loadOwnerOptions();
          return combineLatest2([of2(loginOrName), ownerOptionsSource$]);
        }), tap2(() => this.searching.emit(false)), switchMap2(([loginOrName, ownerOptions]) => {
          const match = (user) => this.searchMatchesUser(loginOrName, user);
          return combineLatest2([of2(loginOrName), of2(!ownerOptions ? ownerOptions : ownerOptions.filter(match))]);
        }), tap2(([loginOrName, ownerOptions]) => {
          if (ownerOptions && ownerOptions.length === 0) {
            this.searchNoResults.emit(loginOrName);
          }
        }), map2(([, ownerOptions]) => ownerOptions || []));
      };
      loadOwnerOptions() {
        return this.courseService.getAllUsersInCourseGroup(this.course.id, "tutors").pipe(map2((usersResponse) => usersResponse.body), tap2((ownerOptions) => {
          this.ownerOptions = ownerOptions;
          this.ownerOptionsLoaded = true;
        }), catchError2(() => {
          this.ownerOptionsLoaded = false;
          this.searchFailed.emit(true);
          return of2(void 0);
        }));
      }
      static \u0275fac = function TeamOwnerSearchComponent_Factory(t) {
        return new (t || _TeamOwnerSearchComponent)(i02.\u0275\u0275directiveInject(CourseManagementService));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _TeamOwnerSearchComponent, selectors: [["jhi-team-owner-search"]], viewQuery: function TeamOwnerSearchComponent_Query(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275viewQuery(_c02, 7);
        }
        if (rf & 2) {
          let _t;
          i02.\u0275\u0275queryRefresh(_t = i02.\u0275\u0275loadQuery()) && (ctx.ngbTypeahead = _t.first);
        }
      }, inputs: { inputDisabled: "inputDisabled", course: "course", exercise: "exercise", team: "team" }, outputs: { selectOwner: "selectOwner", searching: "searching", searchQueryTooShort: "searchQueryTooShort", searchFailed: "searchFailed", searchNoResults: "searchNoResults" }, decls: 4, vars: 8, consts: [["id", "owner-search-input", "type", "text", 1, "form-control", 3, "disabled", "placeholder", "ngModel", "ngbTypeahead", "resultFormatter", "inputFormatter", "ngModelChange", "selectItem", "focus", "click"], ["instance", "ngbTypeahead"]], template: function TeamOwnerSearchComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "input", 0, 1);
          i02.\u0275\u0275listener("ngModelChange", function TeamOwnerSearchComponent_Template_input_ngModelChange_0_listener($event) {
            return ctx.owner = $event;
          })("selectItem", function TeamOwnerSearchComponent_Template_input_selectItem_0_listener($event) {
            return ctx.onAutocompleteSelect($event.item);
          })("focus", function TeamOwnerSearchComponent_Template_input_focus_0_listener() {
            return ctx.focus.next("");
          })("click", function TeamOwnerSearchComponent_Template_input_click_0_listener() {
            return ctx.click.next("");
          });
          i02.\u0275\u0275pipe(2, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(3, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275property("disabled", ctx.inputDisabled)("placeholder", i02.\u0275\u0275pipeBind1(2, 6, "artemisApp.team.selectOwnerForTeam"))("ngModel", ctx.owner)("ngbTypeahead", ctx.onSearch)("resultFormatter", ctx.searchResultFormatter)("inputFormatter", ctx.searchInputFormatter);
        }
      }, dependencies: [i22.DefaultValueAccessor, i22.NgControlStatus, i22.NgModel, i3.NgbTypeahead, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(TeamOwnerSearchComponent, { className: "TeamOwnerSearchComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/team-update-dialog/team-update-dialog.component.ts
import { Component as Component3, Input as Input3, ViewChild as ViewChild3, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgForm } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import { NgbActiveModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { Subject as Subject2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { cloneDeep as cloneDeep2, isEmpty, omit } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import { debounceTime as debounceTime2, switchMap as switchMap3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { faBan, faExclamationTriangle, faSave, faSpinner, faTrashAlt } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i10 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
function TeamUpdateDialogComponent_For_28_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "div", 32);
    i03.\u0275\u0275text(2, "\n                        ");
    i03.\u0275\u0275element(3, "span", 4);
    i03.\u0275\u0275text(4, "\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const e_r17 = i03.\u0275\u0275nextContext().$implicit;
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("jhiTranslate", "artemisApp.team.name." + e_r17.key);
  }
}
function TeamUpdateDialogComponent_For_28_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275template(1, TeamUpdateDialogComponent_For_28_Conditional_1_Template, 6, 1);
  }
  if (rf & 2) {
    i03.\u0275\u0275nextContext();
    const _r1 = i03.\u0275\u0275reference(25);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(1, _r1.invalid && (_r1.dirty || _r1.touched) ? 1 : -1);
  }
}
function TeamUpdateDialogComponent_For_46_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "div", 32);
    i03.\u0275\u0275text(2, "\n                        ");
    i03.\u0275\u0275element(3, "span", 4);
    i03.\u0275\u0275text(4, "\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const e_r24 = i03.\u0275\u0275nextContext().$implicit;
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("jhiTranslate", "artemisApp.team.shortName." + e_r24.key);
  }
}
function TeamUpdateDialogComponent_For_46_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275template(1, TeamUpdateDialogComponent_For_46_Conditional_1_Template, 6, 1);
  }
  if (rf & 2) {
    i03.\u0275\u0275nextContext();
    const _r3 = i03.\u0275\u0275reference(43);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(1, _r3.invalid && (_r3.dirty || _r3.touched) ? 1 : -1);
  }
}
function TeamUpdateDialogComponent_Conditional_62_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275element(1, "fa-icon", 33);
    i03.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    const ctx_r5 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("icon", ctx_r5.faSpinner)("spin", true);
  }
}
function TeamUpdateDialogComponent_Conditional_63_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "span", 34);
    i03.\u0275\u0275text(2, " Please enter at least 3 characters. ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                ");
  }
}
function TeamUpdateDialogComponent_Conditional_64_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "span", 35);
    i03.\u0275\u0275text(2, "\n                        ");
    i03.\u0275\u0275elementStart(3, "span", 36);
    i03.\u0275\u0275text(4, "No tutors found in course for search:");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                        ");
    i03.\u0275\u0275elementStart(6, "strong");
    i03.\u0275\u0275text(7);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(9, "\n                ");
  }
  if (rf & 2) {
    const ctx_r7 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(7);
    i03.\u0275\u0275textInterpolate(ctx_r7.searchingOwnerNoResultsForQuery);
  }
}
function TeamUpdateDialogComponent_Conditional_65_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "span", 37);
    i03.\u0275\u0275text(2, " Search failed. Please try again. ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                ");
  }
}
function TeamUpdateDialogComponent_Conditional_66_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "span", 38);
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                ");
  }
  if (rf & 2) {
    const ctx_r9 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("translateValues", i03.\u0275\u0275pureFunction1(2, _c1, ctx_r9.team.shortName));
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275textInterpolate1("\n                        This will change the tutor for the team ", ctx_r9.team.shortName, " in the whole course!\n                    ");
  }
}
function TeamUpdateDialogComponent_Conditional_79_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275element(1, "fa-icon", 33);
    i03.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    const ctx_r10 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("icon", ctx_r10.faSpinner)("spin", true);
  }
}
function TeamUpdateDialogComponent_Conditional_80_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "span", 39);
    i03.\u0275\u0275text(2, " Please enter at least 3 characters. ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                ");
  }
}
function TeamUpdateDialogComponent_Conditional_81_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "span", 35);
    i03.\u0275\u0275text(2, "\n                        ");
    i03.\u0275\u0275elementStart(3, "span", 40);
    i03.\u0275\u0275text(4, "No students found in course for search:");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                        ");
    i03.\u0275\u0275elementStart(6, "strong");
    i03.\u0275\u0275text(7);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(9, "\n                ");
  }
  if (rf & 2) {
    const ctx_r12 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(7);
    i03.\u0275\u0275textInterpolate(ctx_r12.searchingStudentsNoResultsForQuery);
  }
}
function TeamUpdateDialogComponent_Conditional_82_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "span", 41);
    i03.\u0275\u0275text(2, " Search failed. Please try again. ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                ");
  }
}
function TeamUpdateDialogComponent_For_90_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                            ");
    i03.\u0275\u0275elementStart(1, "div", 47);
    i03.\u0275\u0275text(2, "\n                                ");
    i03.\u0275\u0275element(3, "fa-icon", 48);
    i03.\u0275\u0275text(4);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                        ");
  }
  if (rf & 2) {
    const student_r31 = i03.\u0275\u0275nextContext().$implicit;
    const ctx_r36 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("icon", ctx_r36.faExclamationTriangle);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275textInterpolate1("\n                                Already assigned to team with id ", ctx_r36.getConflictingTeam(student_r31), ".\n                            ");
  }
}
function TeamUpdateDialogComponent_For_90_Template(rf, ctx) {
  if (rf & 1) {
    const _r39 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "li", 42);
    i03.\u0275\u0275text(2, "\n                        ");
    i03.\u0275\u0275elementStart(3, "div", 43);
    i03.\u0275\u0275text(4);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                        ");
    i03.\u0275\u0275elementStart(6, "div", 44);
    i03.\u0275\u0275text(7, "\n                            ");
    i03.\u0275\u0275elementStart(8, "div", 45);
    i03.\u0275\u0275text(9);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(10, "\n                            ");
    i03.\u0275\u0275elementStart(11, "button", 46);
    i03.\u0275\u0275listener("click", function TeamUpdateDialogComponent_For_90_Template_button_click_11_listener() {
      const restoredCtx = i03.\u0275\u0275restoreView(_r39);
      const student_r31 = restoredCtx.$implicit;
      const ctx_r38 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r38.onRemoveStudent(student_r31));
    });
    i03.\u0275\u0275text(12, "\n                                ");
    i03.\u0275\u0275element(13, "fa-icon", 28);
    i03.\u0275\u0275text(14, "\n                            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(15, "\n                        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(16, "\n                        ");
    i03.\u0275\u0275template(17, TeamUpdateDialogComponent_For_90_Conditional_17_Template, 6, 2);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(18, "\n                ");
  }
  if (rf & 2) {
    const student_r31 = ctx.$implicit;
    const i_r32 = ctx.$index;
    const ctx_r14 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(4);
    i03.\u0275\u0275textInterpolate1("\n                            ", i_r32 + 1, "\n                        ");
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275classProp("has-error", ctx_r14.hasConflictingTeam(student_r31));
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275textInterpolate2("", student_r31.name, " (", student_r31.login, ")");
    i03.\u0275\u0275advance(4);
    i03.\u0275\u0275property("icon", ctx_r14.faTrashAlt);
    i03.\u0275\u0275advance(4);
    i03.\u0275\u0275conditional(17, ctx_r14.hasConflictingTeam(student_r31) ? 17 : -1);
  }
}
function TeamUpdateDialogComponent_Conditional_91_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "li", 42);
    i03.\u0275\u0275text(2, "\n                        ");
    i03.\u0275\u0275elementStart(3, "div", 49);
    i03.\u0275\u0275text(4, "1");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                        ");
    i03.\u0275\u0275elementStart(6, "div", 44);
    i03.\u0275\u0275text(7, "\n                            ");
    i03.\u0275\u0275elementStart(8, "div", 50);
    i03.\u0275\u0275text(9, "No students added yet.");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(10, "\n                        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(11, "\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(12, "\n                ");
  }
}
function TeamUpdateDialogComponent_Conditional_106_Template(rf, ctx) {
  if (rf & 1) {
    const _r41 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n                        ");
    i03.\u0275\u0275elementStart(1, "div", 51);
    i03.\u0275\u0275text(2, "\n                            ");
    i03.\u0275\u0275elementStart(3, "input", 52);
    i03.\u0275\u0275listener("ngModelChange", function TeamUpdateDialogComponent_Conditional_106_Template_input_ngModelChange_3_listener($event) {
      i03.\u0275\u0275restoreView(_r41);
      const ctx_r40 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r40.ignoreTeamSizeRecommendation = $event);
    });
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(4, "\n                            ");
    i03.\u0275\u0275elementStart(5, "label", 53);
    i03.\u0275\u0275text(6, "\n                                ");
    i03.\u0275\u0275elementStart(7, "span", 54);
    i03.\u0275\u0275text(8, "Proceed against recommendation");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(9, "\n                                ");
    i03.\u0275\u0275element(10, "fa-icon", 55);
    i03.\u0275\u0275text(11, "\n                            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(12, "\n                        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(13, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r16 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("ngModel", ctx_r16.ignoreTeamSizeRecommendation)("ngModelOptions", i03.\u0275\u0275pureFunction0(3, _c2));
    i03.\u0275\u0275advance(7);
    i03.\u0275\u0275property("icon", ctx_r16.faExclamationTriangle);
  }
}
var _c03, _c1, _c2, _c3, _c4, TeamUpdateDialogComponent;
var init_team_update_dialog_component = __esm({
  "src/main/webapp/app/exercises/shared/team/team-update-dialog/team-update-dialog.component.ts"() {
    init_participation_service();
    init_team_service();
    init_team_model();
    init_exercise_model();
    init_input_constants();
    init_participation_service();
    init_team_service();
    init_translate_directive();
    init_help_icon_component();
    init_team_student_search_component();
    init_team_owner_search_component();
    init_remove_keys_pipe();
    _c03 = ["editForm"];
    _c1 = (a0) => ({ shortName: a0 });
    _c2 = () => ({ standalone: true });
    _c3 = () => ["required"];
    _c4 = () => [];
    TeamUpdateDialogComponent = class _TeamUpdateDialogComponent {
      participationService;
      teamService;
      activeModal;
      editForm;
      team;
      exercise;
      pendingTeam;
      isSaving = false;
      searchingStudents = false;
      searchingStudentsQueryTooShort = false;
      searchingStudentsFailed = false;
      searchingStudentsNoResultsForQuery;
      searchingOwner = false;
      searchingOwnerQueryTooShort = false;
      searchingOwnerFailed = false;
      searchingOwnerNoResultsForQuery;
      studentTeamConflicts = [];
      ignoreTeamSizeRecommendation = false;
      shortNameValidator = new Subject2();
      shortNameAlreadyTakenErrorCode = "alreadyTaken";
      shortNamePattern = SHORT_NAME_PATTERN;
      faSave = faSave;
      faBan = faBan;
      faSpinner = faSpinner;
      faExclamationTriangle = faExclamationTriangle;
      faTrashAlt = faTrashAlt;
      constructor(participationService, teamService, activeModal) {
        this.participationService = participationService;
        this.teamService = teamService;
        this.activeModal = activeModal;
      }
      ngOnInit() {
        this.initPendingTeam();
        this.shortNameValidation(this.shortNameValidator);
      }
      initPendingTeam() {
        this.pendingTeam = cloneDeep2(this.team);
      }
      onTeamShortNameChanged(shortName) {
        this.pendingTeam.shortName = shortName.toLowerCase();
        this.shortNameValidator.next(this.pendingTeam.shortName);
      }
      onTeamNameChanged(name) {
        if (!this.shortNameReadOnly) {
          const shortName = name.replace(/[^0-9a-z]/gi, "");
          this.onTeamShortNameChanged(shortName);
          this.shortNameControl.markAsTouched();
        }
      }
      get shortNameReadOnly() {
        return !!this.pendingTeam.id;
      }
      get shortNameControl() {
        return this.editForm.control.get("shortName");
      }
      get config() {
        return this.exercise.teamAssignmentConfig;
      }
      get showIgnoreTeamSizeRecommendationOption() {
        return !this.recommendedTeamSize;
      }
      get teamSizeViolationUnconfirmed() {
        return this.showIgnoreTeamSizeRecommendationOption && !this.ignoreTeamSizeRecommendation;
      }
      get recommendedTeamSize() {
        const pendingTeamSize = this.pendingTeam.students.length;
        return pendingTeamSize >= this.config.minTeamSize && pendingTeamSize <= this.config.maxTeamSize;
      }
      hasConflictingTeam(student) {
        return this.findStudentTeamConflict(student) !== void 0;
      }
      getConflictingTeam(student) {
        const conflict = this.findStudentTeamConflict(student);
        return conflict ? conflict["teamId"] : void 0;
      }
      findStudentTeamConflict(student) {
        return this.studentTeamConflicts.find((conflict) => conflict.studentLogin === student.login);
      }
      resetStudentTeamConflict(student) {
        return this.studentTeamConflicts = this.studentTeamConflicts.filter((conflict) => conflict.studentLogin !== student.login);
      }
      isStudentAlreadyInPendingTeam(student) {
        return this.pendingTeam.students?.find((stud) => stud.id === student.id) !== void 0;
      }
      onAddStudent(student) {
        if (!this.isStudentAlreadyInPendingTeam(student)) {
          this.pendingTeam.students.push(student);
        }
      }
      onRemoveStudent(student) {
        this.pendingTeam.students = this.pendingTeam.students?.filter((user) => user.id !== student.id);
        this.resetStudentTeamConflict(student);
      }
      onSelectOwner(owner) {
        this.pendingTeam.owner = owner;
      }
      clear() {
        this.activeModal.dismiss("cancel");
      }
      save() {
        if (this.teamSizeViolationUnconfirmed) {
          return;
        }
        this.team = cloneDeep2(this.pendingTeam);
        if (this.team.id !== void 0) {
          this.subscribeToSaveResponse(this.teamService.update(this.exercise, this.team));
        } else {
          this.subscribeToSaveResponse(this.teamService.create(this.exercise, this.team));
        }
      }
      subscribeToSaveResponse(team) {
        this.isSaving = true;
        team.subscribe({
          next: (res) => this.onSaveSuccess(res),
          error: (error) => this.onSaveError(error)
        });
      }
      onSaveSuccess(team) {
        this.activeModal.close(team.body);
        this.isSaving = false;
      }
      onSaveError(httpErrorResponse) {
        this.isSaving = false;
        const { errorKey, params } = httpErrorResponse.error;
        switch (errorKey) {
          case "studentsAlreadyAssignedToTeams":
            const { conflicts } = params;
            this.studentTeamConflicts = conflicts;
            break;
          default:
            break;
        }
      }
      shortNameValidation(shortName$) {
        shortName$.pipe(debounceTime2(500), switchMap3((shortName) => this.teamService.existsByShortName(this.exercise.course, shortName))).subscribe((alreadyTakenResponse) => {
          const alreadyTaken = alreadyTakenResponse.body;
          const errors = alreadyTaken ? __spreadProps(__spreadValues({}, this.shortNameControl.errors), { [this.shortNameAlreadyTakenErrorCode]: alreadyTaken }) : omit(this.shortNameControl.errors, this.shortNameAlreadyTakenErrorCode);
          this.shortNameControl.setErrors(isEmpty(errors) ? null : errors);
        });
      }
      static \u0275fac = function TeamUpdateDialogComponent_Factory(t) {
        return new (t || _TeamUpdateDialogComponent)(i03.\u0275\u0275directiveInject(ParticipationService), i03.\u0275\u0275directiveInject(TeamService), i03.\u0275\u0275directiveInject(i32.NgbActiveModal));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _TeamUpdateDialogComponent, selectors: [["jhi-team-update-dialog"]], viewQuery: function TeamUpdateDialogComponent_Query(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275viewQuery(_c03, 5);
        }
        if (rf & 2) {
          let _t;
          i03.\u0275\u0275queryRefresh(_t = i03.\u0275\u0275loadQuery()) && (ctx.editForm = _t.first);
        }
      }, inputs: { team: "team", exercise: "exercise" }, decls: 131, vars: 48, consts: [["id", "teamUpdateDialogForm", "name", "editForm", "role", "form", "novalidate", "", 3, "ngSubmit"], ["editForm", "ngForm"], [1, "modal-header"], [1, "modal-title"], [3, "jhiTranslate"], ["type", "button", "data-dismiss", "modal", "aria-hidden", "true", 1, "btn-close", 3, "click"], [1, "modal-body"], [1, "form-group"], ["jhiTranslate", "artemisApp.team.name.label", "for", "teamName", 1, "label-narrow"], ["type", "text", "name", "name", "id", "teamName", "required", "", "minlength", "3", 1, "form-control", 3, "ngModel", "ngModelChange"], ["name", "ngModel"], ["jhiTranslate", "artemisApp.team.shortName.label", "for", "teamShortName", 1, "label-narrow"], ["text", "artemisApp.team.shortName.tooltip"], ["type", "text", "name", "shortName", "id", "teamShortName", "required", "", "minlength", "3", 1, "form-control", 3, "pattern", "ngModel", "readonly", "ngModelChange"], ["shortName", "ngModel"], [1, "d-flex", "align-items-end"], ["jhiTranslate", "artemisApp.team.owner.label", 1, "label-narrow"], ["text", "artemisApp.team.owner.tooltip", 1, "me-1"], ["id", "teamOwner", 3, "inputDisabled", "course", "exercise", "team", "selectOwner", "searching", "searchQueryTooShort", "searchNoResults", "searchFailed"], ["jhiTranslate", "artemisApp.team.students", 1, "label-narrow", "me-1"], ["id", "teamStudents", 3, "course", "exercise", "team", "studentsFromPendingTeam", "selectStudent", "searching", "searchQueryTooShort", "searchNoResults", "searchFailed"], [1, "list-group", "list-group--students", "my-3"], ["role", "alert", 1, "alert", "mt-3"], [1, "d-flex", "justify-content-between"], ["jhiTranslate", "artemisApp.team.teamSizeNote", 1, "font-weight-bold"], ["jhiTranslate", "artemisApp.team.teamSizeUnit"], [1, "modal-footer"], ["type", "button", "data-dismiss", "modal", 1, "btn", "btn-default", "cancel", 3, "click"], [3, "icon"], ["jhiTranslate", "entity.action.cancel"], ["type", "submit", 1, "btn", "btn-primary", 3, "disabled"], ["jhiTranslate", "entity.action.save"], [1, "form-control-error", "text-danger"], [1, "search-searching", 3, "icon", "spin"], ["jhiTranslate", "artemisApp.team.ownerSearch.queryTooShort", 1, "label-inline-message", "text-danger"], [1, "label-inline-message", "text-danger"], ["jhiTranslate", "artemisApp.team.ownerSearch.noResults"], ["jhiTranslate", "artemisApp.team.ownerSearch.failed", 1, "label-inline-message", "text-danger"], ["jhiTranslate", "artemisApp.team.ownerChangeWarning", 1, "label-inline-message", "text-danger", 3, "translateValues"], ["jhiTranslate", "artemisApp.team.studentSearch.queryTooShort", 1, "label-inline-message", "text-danger"], ["jhiTranslate", "artemisApp.team.studentSearch.noResults"], ["jhiTranslate", "artemisApp.team.studentSearch.failed", 1, "label-inline-message", "text-danger"], [1, "list-group-item-container", "d-flex", "align-items-center"], [1, "list-group-item-index"], [1, "list-group-item", "d-flex", "align-items-center"], [1, "student-name"], [1, "jest-student-remove-link", "student-remove-link", "ms-4", 3, "click"], [1, "list-group-item-error", "hidden-md-down"], [1, "me-1", 3, "icon"], [1, "list-group-item-index", "text-body-secondary"], ["jhiTranslate", "artemisApp.team.noStudentsAddedYet", 1, "text-body-secondary"], [1, "form-check"], ["id", "ignoreTeamSizeRecommendation", "type", "checkbox", "value", "", 1, "form-check-input", 3, "ngModel", "ngModelOptions", "ngModelChange"], ["for", "ignoreTeamSizeRecommendation", 1, "form-check-label"], ["jhiTranslate", "artemisApp.team.ignoreTeamSizeRecommendation"], [1, "ms-1", 3, "icon"]], template: function TeamUpdateDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "form", 0, 1);
          i03.\u0275\u0275listener("ngSubmit", function TeamUpdateDialogComponent_Template_form_ngSubmit_0_listener() {
            return ctx.save();
          });
          i03.\u0275\u0275text(2, "\n    ");
          i03.\u0275\u0275elementStart(3, "div", 2);
          i03.\u0275\u0275text(4, "\n        ");
          i03.\u0275\u0275elementStart(5, "h4", 3);
          i03.\u0275\u0275text(6, "\n            ");
          i03.\u0275\u0275elementStart(7, "span", 4);
          i03.\u0275\u0275text(8);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(9, "\n            ");
          i03.\u0275\u0275elementStart(10, "span");
          i03.\u0275\u0275text(11);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(12, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(13, "\n        ");
          i03.\u0275\u0275elementStart(14, "button", 5);
          i03.\u0275\u0275listener("click", function TeamUpdateDialogComponent_Template_button_click_14_listener() {
            return ctx.clear();
          });
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(15, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(16, "\n    ");
          i03.\u0275\u0275elementStart(17, "div", 6);
          i03.\u0275\u0275text(18, "\n        ");
          i03.\u0275\u0275elementStart(19, "div", 7);
          i03.\u0275\u0275text(20, "\n            ");
          i03.\u0275\u0275elementStart(21, "label", 8);
          i03.\u0275\u0275text(22, "Name");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(23, "\n            ");
          i03.\u0275\u0275elementStart(24, "input", 9, 10);
          i03.\u0275\u0275listener("ngModelChange", function TeamUpdateDialogComponent_Template_input_ngModelChange_24_listener($event) {
            return ctx.pendingTeam.name = $event;
          })("ngModelChange", function TeamUpdateDialogComponent_Template_input_ngModelChange_24_listener($event) {
            return ctx.onTeamNameChanged($event);
          });
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(26, "\n            ");
          i03.\u0275\u0275repeaterCreate(27, TeamUpdateDialogComponent_For_28_Template, 2, 1, null, null, i03.\u0275\u0275repeaterTrackByIdentity);
          i03.\u0275\u0275pipe(29, "removekeys");
          i03.\u0275\u0275pipe(30, "keyvalue");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(31, "\n        ");
          i03.\u0275\u0275elementStart(32, "div", 7);
          i03.\u0275\u0275text(33, "\n            ");
          i03.\u0275\u0275elementStart(34, "div");
          i03.\u0275\u0275text(35, "\n                ");
          i03.\u0275\u0275elementStart(36, "label", 11);
          i03.\u0275\u0275text(37, "Short Name");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(38, "\n                ");
          i03.\u0275\u0275element(39, "jhi-help-icon", 12);
          i03.\u0275\u0275text(40, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(41, "\n            ");
          i03.\u0275\u0275elementStart(42, "input", 13, 14);
          i03.\u0275\u0275listener("ngModelChange", function TeamUpdateDialogComponent_Template_input_ngModelChange_42_listener($event) {
            return ctx.pendingTeam.shortName = $event;
          })("ngModelChange", function TeamUpdateDialogComponent_Template_input_ngModelChange_42_listener($event) {
            return ctx.onTeamShortNameChanged($event);
          });
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(44, "\n            ");
          i03.\u0275\u0275repeaterCreate(45, TeamUpdateDialogComponent_For_46_Template, 2, 1, null, null, i03.\u0275\u0275repeaterTrackByIdentity);
          i03.\u0275\u0275pipe(47, "removekeys");
          i03.\u0275\u0275pipe(48, "keyvalue");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(49, "\n        ");
          i03.\u0275\u0275elementStart(50, "div", 7);
          i03.\u0275\u0275text(51, "\n            ");
          i03.\u0275\u0275elementStart(52, "div", 15);
          i03.\u0275\u0275text(53, "\n                ");
          i03.\u0275\u0275elementStart(54, "div");
          i03.\u0275\u0275text(55, "\n                    ");
          i03.\u0275\u0275elementStart(56, "label", 16);
          i03.\u0275\u0275text(57, "Tutor");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(58, "\n                    ");
          i03.\u0275\u0275element(59, "jhi-help-icon", 17);
          i03.\u0275\u0275text(60, "\n                ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(61, "\n                ");
          i03.\u0275\u0275template(62, TeamUpdateDialogComponent_Conditional_62_Template, 3, 2)(63, TeamUpdateDialogComponent_Conditional_63_Template, 4, 0)(64, TeamUpdateDialogComponent_Conditional_64_Template, 10, 1)(65, TeamUpdateDialogComponent_Conditional_65_Template, 4, 0)(66, TeamUpdateDialogComponent_Conditional_66_Template, 4, 4);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(67, "\n            ");
          i03.\u0275\u0275elementStart(68, "jhi-team-owner-search", 18);
          i03.\u0275\u0275listener("selectOwner", function TeamUpdateDialogComponent_Template_jhi_team_owner_search_selectOwner_68_listener($event) {
            return ctx.onSelectOwner($event);
          })("searching", function TeamUpdateDialogComponent_Template_jhi_team_owner_search_searching_68_listener($event) {
            return ctx.searchingOwner = $event;
          })("searchQueryTooShort", function TeamUpdateDialogComponent_Template_jhi_team_owner_search_searchQueryTooShort_68_listener($event) {
            return ctx.searchingOwnerQueryTooShort = $event;
          })("searchNoResults", function TeamUpdateDialogComponent_Template_jhi_team_owner_search_searchNoResults_68_listener($event) {
            return ctx.searchingOwnerNoResultsForQuery = $event;
          })("searchFailed", function TeamUpdateDialogComponent_Template_jhi_team_owner_search_searchFailed_68_listener($event) {
            return ctx.searchingOwnerFailed = $event;
          });
          i03.\u0275\u0275text(69, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(70, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(71, "\n        ");
          i03.\u0275\u0275elementStart(72, "div", 7);
          i03.\u0275\u0275text(73, "\n            ");
          i03.\u0275\u0275elementStart(74, "div", 15);
          i03.\u0275\u0275text(75, "\n                ");
          i03.\u0275\u0275elementStart(76, "label", 19);
          i03.\u0275\u0275text(77, "Students");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(78, "\n                ");
          i03.\u0275\u0275template(79, TeamUpdateDialogComponent_Conditional_79_Template, 3, 2)(80, TeamUpdateDialogComponent_Conditional_80_Template, 4, 0)(81, TeamUpdateDialogComponent_Conditional_81_Template, 10, 1)(82, TeamUpdateDialogComponent_Conditional_82_Template, 4, 0);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(83, "\n            ");
          i03.\u0275\u0275elementStart(84, "jhi-team-student-search", 20);
          i03.\u0275\u0275listener("selectStudent", function TeamUpdateDialogComponent_Template_jhi_team_student_search_selectStudent_84_listener($event) {
            return ctx.onAddStudent($event);
          })("searching", function TeamUpdateDialogComponent_Template_jhi_team_student_search_searching_84_listener($event) {
            return ctx.searchingStudents = $event;
          })("searchQueryTooShort", function TeamUpdateDialogComponent_Template_jhi_team_student_search_searchQueryTooShort_84_listener($event) {
            return ctx.searchingStudentsQueryTooShort = $event;
          })("searchNoResults", function TeamUpdateDialogComponent_Template_jhi_team_student_search_searchNoResults_84_listener($event) {
            return ctx.searchingStudentsNoResultsForQuery = $event;
          })("searchFailed", function TeamUpdateDialogComponent_Template_jhi_team_student_search_searchFailed_84_listener($event) {
            return ctx.searchingStudentsFailed = $event;
          });
          i03.\u0275\u0275text(85, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(86, "\n            ");
          i03.\u0275\u0275elementStart(87, "ul", 21);
          i03.\u0275\u0275text(88, "\n                ");
          i03.\u0275\u0275repeaterCreate(89, TeamUpdateDialogComponent_For_90_Template, 19, 7, null, null, i03.\u0275\u0275repeaterTrackByIdentity);
          i03.\u0275\u0275template(91, TeamUpdateDialogComponent_Conditional_91_Template, 13, 0);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(92, "\n            ");
          i03.\u0275\u0275elementStart(93, "div", 22);
          i03.\u0275\u0275text(94, "\n                ");
          i03.\u0275\u0275elementStart(95, "div", 23);
          i03.\u0275\u0275text(96, "\n                    ");
          i03.\u0275\u0275elementStart(97, "div");
          i03.\u0275\u0275text(98, "\n                        ");
          i03.\u0275\u0275elementStart(99, "span", 24);
          i03.\u0275\u0275text(100, "Recommended team size:");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(101);
          i03.\u0275\u0275elementStart(102, "span", 25);
          i03.\u0275\u0275text(103, "students");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(104, "\n                    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(105, "\n                    ");
          i03.\u0275\u0275template(106, TeamUpdateDialogComponent_Conditional_106_Template, 14, 4);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(107, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(108, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(109, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(110, "\n    ");
          i03.\u0275\u0275elementStart(111, "div", 26);
          i03.\u0275\u0275text(112, "\n        ");
          i03.\u0275\u0275elementStart(113, "button", 27);
          i03.\u0275\u0275listener("click", function TeamUpdateDialogComponent_Template_button_click_113_listener() {
            return ctx.clear();
          });
          i03.\u0275\u0275text(114, "\n            ");
          i03.\u0275\u0275element(115, "fa-icon", 28);
          i03.\u0275\u0275text(116, "\xA0");
          i03.\u0275\u0275elementStart(117, "span", 29);
          i03.\u0275\u0275text(118, "Cancel");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(119, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(120, "\n        ");
          i03.\u0275\u0275elementStart(121, "button", 30);
          i03.\u0275\u0275text(122, "\n            ");
          i03.\u0275\u0275element(123, "fa-icon", 28);
          i03.\u0275\u0275text(124, "\xA0");
          i03.\u0275\u0275elementStart(125, "span", 31);
          i03.\u0275\u0275text(126, "Save");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(127, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(128, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(129, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(130, "\n");
        }
        if (rf & 2) {
          const _r0 = i03.\u0275\u0275reference(1);
          const _r1 = i03.\u0275\u0275reference(25);
          const _r3 = i03.\u0275\u0275reference(43);
          i03.\u0275\u0275advance(7);
          i03.\u0275\u0275property("jhiTranslate", ctx.pendingTeam.id ? "artemisApp.team.updateTeam.label" : "artemisApp.team.createTeam.label");
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275textInterpolate1("\n                ", ctx.pendingTeam.id ? "Update Team" : "Create Team", "\n            ");
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275textInterpolate1("(", ctx.exercise.title, ")");
          i03.\u0275\u0275advance(13);
          i03.\u0275\u0275property("ngModel", ctx.pendingTeam.name);
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275repeater(i03.\u0275\u0275pipeBind2(29, 35, i03.\u0275\u0275pipeBind1(30, 38, _r1.errors), i03.\u0275\u0275pureFunction0(45, _c3)));
          i03.\u0275\u0275advance(15);
          i03.\u0275\u0275property("pattern", ctx.shortNamePattern)("ngModel", ctx.pendingTeam.shortName)("readonly", ctx.shortNameReadOnly);
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275repeater(i03.\u0275\u0275pipeBind2(47, 40, i03.\u0275\u0275pipeBind1(48, 43, _r3.errors), i03.\u0275\u0275pureFunction0(46, _c3)));
          i03.\u0275\u0275advance(17);
          i03.\u0275\u0275conditional(62, ctx.searchingOwner ? 62 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(63, ctx.searchingOwnerQueryTooShort ? 63 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(64, ctx.searchingOwnerNoResultsForQuery ? 64 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(65, ctx.searchingOwnerFailed ? 65 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(66, ctx.team.id && (ctx.team.owner == null ? null : ctx.team.owner.id) !== (ctx.pendingTeam.owner == null ? null : ctx.pendingTeam.owner.id) ? 66 : -1);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275property("inputDisabled", !ctx.exercise.isAtLeastInstructor)("course", ctx.exercise.course)("exercise", ctx.exercise)("team", ctx.team);
          i03.\u0275\u0275advance(11);
          i03.\u0275\u0275conditional(79, ctx.searchingStudents ? 79 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(80, ctx.searchingStudentsQueryTooShort ? 80 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(81, ctx.searchingStudentsNoResultsForQuery ? 81 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(82, ctx.searchingStudentsFailed ? 82 : -1);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275property("course", ctx.exercise.course)("exercise", ctx.exercise)("team", ctx.team)("studentsFromPendingTeam", ctx.pendingTeam.students || i03.\u0275\u0275pureFunction0(47, _c4));
          i03.\u0275\u0275advance(5);
          i03.\u0275\u0275repeater(ctx.pendingTeam.students);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275conditional(91, ctx.pendingTeam.students && ctx.pendingTeam.students.length === 0 ? 91 : -1);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275classProp("alert-info", !ctx.showIgnoreTeamSizeRecommendationOption)("alert-warning", ctx.showIgnoreTeamSizeRecommendationOption);
          i03.\u0275\u0275advance(8);
          i03.\u0275\u0275textInterpolate2("\n                        ", ctx.config.minTeamSize, " - ", ctx.config.maxTeamSize, "\n                        ");
          i03.\u0275\u0275advance(5);
          i03.\u0275\u0275conditional(106, ctx.showIgnoreTeamSizeRecommendationOption ? 106 : -1);
          i03.\u0275\u0275advance(9);
          i03.\u0275\u0275property("icon", ctx.faBan);
          i03.\u0275\u0275advance(6);
          i03.\u0275\u0275property("disabled", _r0.invalid || ctx.isSaving || ctx.teamSizeViolationUnconfirmed);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275property("icon", ctx.faSave);
        }
      }, dependencies: [i4.\u0275NgNoValidate, i4.DefaultValueAccessor, i4.CheckboxControlValueAccessor, i4.NgControlStatus, i4.NgControlStatusGroup, i4.RequiredValidator, i4.MinLengthValidator, i4.PatternValidator, i4.NgModel, i4.NgForm, i5.FaIconComponent, TranslateDirective, HelpIconComponent, TeamStudentSearchComponent, TeamOwnerSearchComponent, i10.KeyValuePipe, RemoveKeysPipe], styles: ["/* src/main/webapp/app/exercises/shared/team/team-update-dialog/team-update-dialog.component.scss */\n.form-control-error {\n  margin-top: 0.35rem;\n}\n.form-control-error + .form-control-error {\n  margin-top: 0;\n}\n.search-searching {\n  position: relative;\n  top: -2px;\n}\n.label-inline-message {\n  position: relative;\n  top: -4.5px;\n  line-height: 1rem;\n  font-size: 0.8rem;\n  margin-left: 5px;\n}\n.list-group--students {\n  max-width: 450px;\n}\n.list-group--students .list-group-item-container {\n  position: relative;\n}\n.list-group--students .list-group-item-container:not(:last-child) {\n  margin-bottom: 0.15rem;\n}\n.list-group--students .list-group-item-index {\n  font-size: 1.1rem;\n  margin-left: 1.5rem;\n  margin-right: 1rem;\n  font-weight: 500;\n}\n.list-group--students .list-group-item {\n  flex-grow: 1;\n}\n.list-group--students .list-group-item.has-error {\n  background-color: var(--artemis-alert-danger-background);\n}\n.list-group--students .list-group-item-error {\n  width: 280px;\n  position: absolute;\n  left: 100%;\n  margin-left: 2rem;\n  color: var(--danger);\n}\n.list-group--students .student-name {\n  flex-grow: 1;\n  width: 0;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.list-group--students .student-remove-link {\n  background-color: transparent;\n  border: none;\n  -webkit-appearance: none;\n  color: var(--bs-body-color);\n}\n.modal-footer button[disabled] {\n  cursor: not-allowed;\n}\n.hidden-md-down {\n  display: none !important;\n}\n@media (min-width: 992px) {\n  .hidden-md-down {\n    display: block !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbS11cGRhdGUtZGlhbG9nL3RlYW0tdXBkYXRlLWRpYWxvZy5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmZvcm0tY29udHJvbC1lcnJvciB7XG4gICAgbWFyZ2luLXRvcDogMC4zNXJlbTtcblxuICAgICYgKyAmIHtcbiAgICAgICAgbWFyZ2luLXRvcDogMDtcbiAgICB9XG59XG5cbi5zZWFyY2gtc2VhcmNoaW5nIHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgdG9wOiAtMnB4O1xufVxuXG4ubGFiZWwtaW5saW5lLW1lc3NhZ2Uge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB0b3A6IC00LjVweDtcbiAgICBsaW5lLWhlaWdodDogMXJlbTtcbiAgICBmb250LXNpemU6IDAuOHJlbTtcbiAgICBtYXJnaW4tbGVmdDogNXB4O1xufVxuXG4ubGlzdC1ncm91cC0tc3R1ZGVudHMge1xuICAgIG1heC13aWR0aDogNDUwcHg7XG5cbiAgICAubGlzdC1ncm91cC1pdGVtLWNvbnRhaW5lciB7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICAgICAmOm5vdCg6bGFzdC1jaGlsZCkge1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMC4xNXJlbTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5saXN0LWdyb3VwLWl0ZW0taW5kZXgge1xuICAgICAgICBmb250LXNpemU6IDEuMXJlbTtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDEuNXJlbTtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxcmVtO1xuICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgIH1cblxuICAgIC5saXN0LWdyb3VwLWl0ZW0ge1xuICAgICAgICBmbGV4LWdyb3c6IDE7XG5cbiAgICAgICAgJi5oYXMtZXJyb3Ige1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYXJ0ZW1pcy1hbGVydC1kYW5nZXItYmFja2dyb3VuZCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAubGlzdC1ncm91cC1pdGVtLWVycm9yIHtcbiAgICAgICAgd2lkdGg6IDI4MHB4O1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIGxlZnQ6IDEwMCU7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAycmVtO1xuICAgICAgICBjb2xvcjogdmFyKC0tZGFuZ2VyKTtcbiAgICB9XG5cbiAgICAuc3R1ZGVudC1uYW1lIHtcbiAgICAgICAgZmxleC1ncm93OiAxO1xuICAgICAgICB3aWR0aDogMDtcbiAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gICAgfVxuXG4gICAgLnN0dWRlbnQtcmVtb3ZlLWxpbmsge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICAgICAgYm9yZGVyOiBub25lO1xuICAgICAgICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1icy1ib2R5LWNvbG9yKTtcbiAgICB9XG59XG5cbi5tb2RhbC1mb290ZXIge1xuICAgIGJ1dHRvbltkaXNhYmxlZF0ge1xuICAgICAgICBjdXJzb3I6IG5vdC1hbGxvd2VkO1xuICAgIH1cbn1cblxuLmhpZGRlbi1tZC1kb3duIHtcbiAgICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XG5cbiAgICBAbWVkaWEgKG1pbi13aWR0aDogOTkycHgpIHtcbiAgICAgICAgZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLGNBQUE7O0FBRUEsQ0FISixtQkFHSSxFQUFBLENBSEo7QUFJUSxjQUFBOztBQUlSLENBQUE7QUFDSSxZQUFBO0FBQ0EsT0FBQTs7QUFHSixDQUFBO0FBQ0ksWUFBQTtBQUNBLE9BQUE7QUFDQSxlQUFBO0FBQ0EsYUFBQTtBQUNBLGVBQUE7O0FBR0osQ0FBQTtBQUNJLGFBQUE7O0FBRUEsQ0FISixxQkFHSSxDQUFBO0FBQ0ksWUFBQTs7QUFFQSxDQU5SLHFCQU1RLENBSEoseUJBR0ksS0FBQTtBQUNJLGlCQUFBOztBQUlSLENBWEoscUJBV0ksQ0FBQTtBQUNJLGFBQUE7QUFDQSxlQUFBO0FBQ0EsZ0JBQUE7QUFDQSxlQUFBOztBQUdKLENBbEJKLHFCQWtCSSxDQUFBO0FBQ0ksYUFBQTs7QUFFQSxDQXJCUixxQkFxQlEsQ0FISixlQUdJLENBQUE7QUFDSSxvQkFBQSxJQUFBOztBQUlSLENBMUJKLHFCQTBCSSxDQUFBO0FBQ0ksU0FBQTtBQUNBLFlBQUE7QUFDQSxRQUFBO0FBQ0EsZUFBQTtBQUNBLFNBQUEsSUFBQTs7QUFHSixDQWxDSixxQkFrQ0ksQ0FBQTtBQUNJLGFBQUE7QUFDQSxTQUFBO0FBQ0EsZUFBQTtBQUNBLFlBQUE7QUFDQSxpQkFBQTs7QUFHSixDQTFDSixxQkEwQ0ksQ0FBQTtBQUNJLG9CQUFBO0FBQ0EsVUFBQTtBQUNBLHNCQUFBO0FBQ0EsU0FBQSxJQUFBOztBQUtKLENBQUEsYUFBQSxNQUFBLENBQUE7QUFDSSxVQUFBOztBQUlSLENBQUE7QUFDSSxXQUFBOztBQUVBLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFISixHQUFBO0FBSVEsYUFBQTs7OyIsCiAgIm5hbWVzIjogW10KfQo= */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(TeamUpdateDialogComponent, { className: "TeamUpdateDialogComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/team-update-dialog/team-update-button.component.ts
import { Component as Component4, EventEmitter as EventEmitter3, Input as Input4, Output as Output3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgbModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { faPencilAlt, faPlus } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
var TeamUpdateButtonComponent;
var init_team_update_button_component = __esm({
  "src/main/webapp/app/exercises/shared/team/team-update-dialog/team-update-button.component.ts"() {
    init_team_update_dialog_component();
    init_team_model();
    init_exercise_model();
    init_button_component();
    init_button_component();
    TeamUpdateButtonComponent = class _TeamUpdateButtonComponent {
      modalService;
      ButtonType = ButtonType;
      ButtonSize = ButtonSize;
      team;
      exercise;
      buttonSize = ButtonSize.SMALL;
      save = new EventEmitter3();
      faPencilAlt = faPencilAlt;
      faPlus = faPlus;
      constructor(modalService) {
        this.modalService = modalService;
      }
      openTeamCreateDialog(event) {
        event.stopPropagation();
        const modalRef = this.modalService.open(TeamUpdateDialogComponent, { keyboard: true, size: "lg", backdrop: "static" });
        modalRef.componentInstance.team = this.team || new Team();
        modalRef.componentInstance.exercise = this.exercise;
        modalRef.result.then((team) => this.save.emit(team), () => {
        });
      }
      static \u0275fac = function TeamUpdateButtonComponent_Factory(t) {
        return new (t || _TeamUpdateButtonComponent)(i04.\u0275\u0275directiveInject(i1.NgbModal));
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _TeamUpdateButtonComponent, selectors: [["jhi-team-update-button"]], inputs: { team: "team", exercise: "exercise", buttonSize: "buttonSize" }, outputs: { save: "save" }, decls: 3, vars: 4, consts: [[3, "btnType", "btnSize", "icon", "title", "onClick"]], template: function TeamUpdateButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275text(0, "\n        ");
          i04.\u0275\u0275elementStart(1, "jhi-button", 0);
          i04.\u0275\u0275listener("onClick", function TeamUpdateButtonComponent_Template_jhi_button_onClick_1_listener($event) {
            return ctx.openTeamCreateDialog($event);
          });
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(2, "\n    ");
        }
        if (rf & 2) {
          i04.\u0275\u0275advance(1);
          i04.\u0275\u0275property("btnType", ctx.ButtonType.PRIMARY)("btnSize", ctx.buttonSize)("icon", ctx.team ? ctx.faPencilAlt : ctx.faPlus)("title", ctx.team ? "artemisApp.team.updateTeam.label" : "artemisApp.team.createTeam.label");
        }
      }, dependencies: [ButtonComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(TeamUpdateButtonComponent, { className: "TeamUpdateButtonComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/team-exercise-search/team-exercise-search.component.ts
import { Component as Component5, EventEmitter as EventEmitter4, Input as Input5, Output as Output4, ViewChild as ViewChild4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject as Subject3, combineLatest as combineLatest3, merge as merge2, of as of3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { catchError as catchError3, filter as filter2, map as map3, switchMap as switchMap4, tap as tap3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import { NgbTypeahead as NgbTypeahead4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { orderBy } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i23 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i33 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i42 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
var _c04, TeamExerciseSearchComponent;
var init_team_exercise_search_component = __esm({
  "src/main/webapp/app/exercises/shared/team/team-exercise-search/team-exercise-search.component.ts"() {
    init_course_model();
    init_course_management_service();
    init_artemis_date_pipe();
    init_course_management_service();
    init_artemis_translate_pipe();
    _c04 = ["instance"];
    TeamExerciseSearchComponent = class _TeamExerciseSearchComponent {
      courseService;
      translateService;
      ngbTypeahead;
      focus$ = new Subject3();
      click$ = new Subject3();
      course;
      ignoreExercises;
      selectExercise = new EventEmitter4();
      searching = new EventEmitter4();
      searchQueryTooShort = new EventEmitter4();
      searchFailed = new EventEmitter4();
      searchNoResults = new EventEmitter4();
      exercise;
      exerciseOptions = [];
      exerciseOptionsLoaded = false;
      inputDisplayValue;
      constructor(courseService, translateService) {
        this.courseService = courseService;
        this.translateService = translateService;
      }
      onAutocompleteSelect = (exercise) => {
        this.inputDisplayValue = this.searchResultFormatter(exercise);
        this.selectExercise.emit(exercise);
      };
      searchInputFormatter = () => {
        return this.inputDisplayValue;
      };
      searchResultFormatter = (exercise) => {
        const { title, releaseDate } = exercise;
        const date = releaseDate ? releaseDate.format(ArtemisDatePipe.format(this.translateService.currentLang, "short-date")) : "";
        return title + (releaseDate ? ` (${date})` : "");
      };
      searchMatchesExercise(searchTerm, exercise) {
        return exercise.title.toLowerCase().includes(searchTerm.toLowerCase());
      }
      onSearch = (text$) => {
        const clicksWithClosedPopup$ = this.click$.pipe(filter2(() => !this.ngbTypeahead.isPopupOpen()));
        const inputFocus$ = this.focus$;
        return merge2(text$, inputFocus$, clicksWithClosedPopup$).pipe(tap3(() => {
          this.searchNoResults.emit(void 0);
        }), switchMap4((searchTerm) => {
          this.searchFailed.emit(false);
          this.searching.emit(true);
          const exerciseOptionsSource$ = this.exerciseOptionsLoaded ? of3(this.exerciseOptions) : this.loadExerciseOptions();
          return combineLatest3([of3(searchTerm), exerciseOptionsSource$]);
        }), tap3(() => this.searching.emit(false)), switchMap4(([searchTerm, exerciseOptions]) => {
          const match = (exercise) => this.searchMatchesExercise(searchTerm, exercise);
          return combineLatest3([of3(searchTerm), of3(!exerciseOptions ? exerciseOptions : exerciseOptions.filter(match))]);
        }), tap3(([searchTerm, exerciseOptions]) => {
          if (exerciseOptions && exerciseOptions.length === 0) {
            this.searchNoResults.emit(searchTerm);
          }
        }), map3(([, exerciseOptions]) => exerciseOptions || []), map3((exerciseOptions) => orderBy(exerciseOptions, ["releaseDate", "id"])));
      };
      loadExerciseOptions() {
        return this.courseService.findWithExercises(this.course.id).pipe(map3((courseResponse) => courseResponse.body.exercises || [])).pipe(map3((exercises) => exercises.filter((exercise) => exercise.teamMode))).pipe(map3((exercises) => exercises.filter((exercise) => !this.ignoreExercises.map((e) => e.id).includes(exercise.id)))).pipe(tap3((exerciseOptions) => {
          this.exerciseOptions = exerciseOptions;
          this.exerciseOptionsLoaded = true;
        })).pipe(catchError3(() => {
          this.exerciseOptionsLoaded = false;
          this.searchFailed.emit(true);
          return of3(null);
        }));
      }
      static \u0275fac = function TeamExerciseSearchComponent_Factory(t) {
        return new (t || _TeamExerciseSearchComponent)(i05.\u0275\u0275directiveInject(CourseManagementService), i05.\u0275\u0275directiveInject(i23.TranslateService));
      };
      static \u0275cmp = i05.\u0275\u0275defineComponent({ type: _TeamExerciseSearchComponent, selectors: [["jhi-team-exercise-search"]], viewQuery: function TeamExerciseSearchComponent_Query(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275viewQuery(_c04, 7);
        }
        if (rf & 2) {
          let _t;
          i05.\u0275\u0275queryRefresh(_t = i05.\u0275\u0275loadQuery()) && (ctx.ngbTypeahead = _t.first);
        }
      }, inputs: { course: "course", ignoreExercises: "ignoreExercises" }, outputs: { selectExercise: "selectExercise", searching: "searching", searchQueryTooShort: "searchQueryTooShort", searchFailed: "searchFailed", searchNoResults: "searchNoResults" }, decls: 4, vars: 7, consts: [["id", "exercise-search-input", "type", "text", 1, "form-control", 3, "placeholder", "ngModel", "ngbTypeahead", "resultFormatter", "inputFormatter", "ngModelChange", "selectItem", "focus", "click"], ["instance", "ngbTypeahead"]], template: function TeamExerciseSearchComponent_Template(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275elementStart(0, "input", 0, 1);
          i05.\u0275\u0275listener("ngModelChange", function TeamExerciseSearchComponent_Template_input_ngModelChange_0_listener($event) {
            return ctx.exercise = $event;
          })("selectItem", function TeamExerciseSearchComponent_Template_input_selectItem_0_listener($event) {
            return ctx.onAutocompleteSelect($event.item);
          })("focus", function TeamExerciseSearchComponent_Template_input_focus_0_listener() {
            return ctx.focus$.next("");
          })("click", function TeamExerciseSearchComponent_Template_input_click_0_listener() {
            return ctx.click$.next("");
          });
          i05.\u0275\u0275pipe(2, "artemisTranslate");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(3, "\n");
        }
        if (rf & 2) {
          i05.\u0275\u0275property("placeholder", i05.\u0275\u0275pipeBind1(2, 5, "artemisApp.team.selectExerciseForImport"))("ngModel", ctx.exercise)("ngbTypeahead", ctx.onSearch)("resultFormatter", ctx.searchResultFormatter)("inputFormatter", ctx.searchInputFormatter);
        }
      }, dependencies: [i33.DefaultValueAccessor, i33.NgControlStatus, i33.NgModel, i42.NgbTypeahead, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(TeamExerciseSearchComponent, { className: "TeamExerciseSearchComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/teams-import-dialog/teams-import-from-file-form.component.ts
import { ChangeDetectorRef, Component as Component6, EventEmitter as EventEmitter5, Output as Output5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faSpinner as faSpinner2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { TranslateService as TranslateService3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import __vite__cjsImport51_papaparse from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/papaparse.js?v=1d0d9ead"; const parse = __vite__cjsImport51_papaparse["parse"];
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i24 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function TeamsImportFromFileFormComponent_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275element(1, "fa-icon", 4);
    i06.\u0275\u0275text(2, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r0.faSpinner)("spin", true);
  }
}
var csvColumns, TeamsImportFromFileFormComponent;
var init_teams_import_from_file_form_component = __esm({
  "src/main/webapp/app/exercises/shared/team/teams-import-dialog/teams-import-from-file-form.component.ts"() {
    init_user_model();
    init_team_model();
    init_input_constants();
    init_translate_directive();
    init_help_icon_component();
    csvColumns = Object.freeze({
      registrationNumber: "registrationnumber",
      matrikelNummer: "matrikelnummer",
      matriculationNumber: "matriculationnumber",
      name: "name",
      vorname: "vorname",
      nachname: "nachname",
      firstName: "firstname",
      familyName: "familyname",
      lastName: "lastname",
      surname: "surname",
      login: "login",
      username: "username",
      user: "user",
      benutzer: "benutzer",
      benutzerName: "benutzername",
      team: "team",
      teamName: "teamname",
      gruppe: "gruppe"
    });
    TeamsImportFromFileFormComponent = class _TeamsImportFromFileFormComponent {
      changeDetector;
      translateService;
      teamsChanged = new EventEmitter5();
      sourceTeams;
      importedTeams = [];
      importFile;
      importFileName;
      loading;
      faSpinner = faSpinner2;
      constructor(changeDetector, translateService) {
        this.changeDetector = changeDetector;
        this.translateService = translateService;
      }
      generateFileReader() {
        return new FileReader();
      }
      onFileLoadImport(fileReader) {
        return __async(this, null, function* () {
          try {
            if (this.importFile?.type === "application/json") {
              this.importedTeams = JSON.parse(fileReader.result);
            } else if (this.importFile?.type === "text/csv") {
              const csvEntries = yield this.parseCSVFile(fileReader.result);
              this.importedTeams = this.convertCsvEntries(csvEntries);
            } else {
              throw new Error(this.translateService.instant("artemisApp.team.invalidFileType", { fileType: this.importFile?.type }));
            }
            this.sourceTeams = this.convertTeams(this.importedTeams);
            this.teamsChanged.emit(this.sourceTeams);
            this.loading = false;
            this.importFile = void 0;
            this.importFileName = "";
            const control = document.getElementById("importFileInput");
            if (control) {
              control.value = "";
            }
          } catch (e) {
            this.loading = false;
            const message = `${this.translateService.instant("artemisApp.team.errors.importFailed")} ${e}`;
            alert(message);
          }
        });
      }
      setImportFile(event) {
        if (event.target.files.length) {
          const fileList = event.target.files;
          this.importFile = fileList[0];
          this.importFileName = this.importFile.name;
          this.loading = true;
        }
        if (!this.importFile) {
          return;
        }
        const fileReader = this.generateFileReader();
        fileReader.onload = () => this.onFileLoadImport(fileReader);
        fileReader.readAsText(this.importFile);
        this.changeDetector.detectChanges();
      }
      parseCSVFile(csv) {
        return new Promise((resolve, reject) => {
          parse(csv, {
            download: false,
            header: true,
            transformHeader: (header) => header.toLowerCase().replace(" ", "").replace("_", ""),
            skipEmptyLines: true,
            complete: (results) => resolve(results.data),
            error: (error) => reject(error)
          });
        });
      }
      convertCsvEntries(entries) {
        return entries.map((entry) => ({
          registrationNumber: entry[csvColumns.registrationNumber] || entry[csvColumns.matrikelNummer] || entry[csvColumns.matriculationNumber] || void 0,
          username: entry[csvColumns.login] || entry[csvColumns.username] || entry[csvColumns.user] || entry[csvColumns.benutzer] || entry[csvColumns.benutzerName] || void 0,
          firstName: entry[csvColumns.firstName] || entry[csvColumns.vorname] || void 0,
          lastName: entry[csvColumns.lastName] || entry[csvColumns.familyName] || entry[csvColumns.surname] || entry[csvColumns.name] || entry[csvColumns.nachname] || void 0,
          teamName: entry[csvColumns.teamName] || entry[csvColumns.team] || entry[csvColumns.gruppe] || void 0
        }));
      }
      convertTeams(importTeam) {
        const teams = [];
        importTeam.forEach((student, index) => {
          const newStudent = new User();
          newStudent.firstName = student.firstName ?? "";
          newStudent.lastName = student.lastName ?? "";
          newStudent.visibleRegistrationNumber = student.registrationNumber;
          newStudent.login = student.username;
          const entryNr = index + 1;
          if ((typeof student.username !== "string" || !student.username.trim()) && (typeof student.registrationNumber !== "string" || !student.registrationNumber.trim())) {
            throw new Error(this.translateService.instant("artemisApp.team.missingUserNameOrId", { entryNr }));
          }
          newStudent.name = `${newStudent.firstName} ${newStudent.lastName}`.trim();
          if (typeof student.teamName !== "string" || !student.teamName.trim()) {
            throw new Error(this.translateService.instant("artemisApp.team.teamName.missingTeamName", { entryNr, studentName: newStudent.name }));
          }
          const shortName = student.teamName.replace(/[^0-9a-z]/gi, "").toLowerCase();
          if (!shortName.match(SHORT_NAME_PATTERN)) {
            throw new Error(this.translateService.instant("artemisApp.team.teamName.pattern", { entryNr, teamName: shortName }));
          }
          const teamIndex = teams.findIndex((team) => team.name === student.teamName);
          if (teamIndex === -1) {
            const newTeam = new Team();
            newTeam.name = student.teamName;
            newTeam.shortName = shortName;
            newTeam.students = [newStudent];
            teams.push(newTeam);
          } else {
            teams[teamIndex].students = [...teams[teamIndex].students, newStudent];
          }
        });
        return teams;
      }
      static \u0275fac = function TeamsImportFromFileFormComponent_Factory(t) {
        return new (t || _TeamsImportFromFileFormComponent)(i06.\u0275\u0275directiveInject(i06.ChangeDetectorRef), i06.\u0275\u0275directiveInject(i12.TranslateService));
      };
      static \u0275cmp = i06.\u0275\u0275defineComponent({ type: _TeamsImportFromFileFormComponent, selectors: [["jhi-teams-import-from-file-form"]], outputs: { teamsChanged: "teamsChanged" }, decls: 14, vars: 1, consts: [["jhiTranslate", "artemisApp.team.sourceFile.label", 1, "label-narrow"], ["text", "artemisApp.team.sourceFile.tooltip", 1, "me-1"], [1, "custom-file"], ["id", "importFileInput", "type", "file", "accept", ".json,.csv", "placeholder", "Upload file...", 1, "custom-file-input", 3, "change"], [1, "loading-spinner", 3, "icon", "spin"]], template: function TeamsImportFromFileFormComponent_Template(rf, ctx) {
        if (rf & 1) {
          i06.\u0275\u0275elementStart(0, "div");
          i06.\u0275\u0275text(1, "\n    ");
          i06.\u0275\u0275elementStart(2, "label", 0);
          i06.\u0275\u0275text(3, "Source file");
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(4, "\n    ");
          i06.\u0275\u0275element(5, "jhi-help-icon", 1);
          i06.\u0275\u0275text(6, "\n    ");
          i06.\u0275\u0275template(7, TeamsImportFromFileFormComponent_Conditional_7_Template, 3, 2);
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(8, "\n");
          i06.\u0275\u0275elementStart(9, "div", 2);
          i06.\u0275\u0275text(10, "\n    ");
          i06.\u0275\u0275elementStart(11, "input", 3);
          i06.\u0275\u0275listener("change", function TeamsImportFromFileFormComponent_Template_input_change_11_listener($event) {
            return ctx.setImportFile($event);
          });
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(12, "\n");
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(13, "\n");
        }
        if (rf & 2) {
          i06.\u0275\u0275advance(7);
          i06.\u0275\u0275conditional(7, ctx.loading ? 7 : -1);
        }
      }, dependencies: [i24.FaIconComponent, TranslateDirective, HelpIconComponent], styles: ["\n\n[_nghost-%COMP%] {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbXMtaW1wb3J0LWRpYWxvZy90ZWFtcy1pbXBvcnQtZnJvbS1maWxlLWZvcm0uY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIjpob3N0IHtcbiAgICB3aWR0aDogMTAwJTtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQTtBQUNJLFNBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i06.\u0275setClassDebugInfo(TeamsImportFromFileFormComponent, { className: "TeamsImportFromFileFormComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/teams-import-dialog/teams-import-dialog.component.ts
import { Component as Component7, Input as Input6, ViewChild as ViewChild5, ViewEncapsulation as ViewEncapsulation2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgForm as NgForm3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import { NgbActiveModal as NgbActiveModal3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { Subject as Subject4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { flatMap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import { faBan as faBan2, faCircleNotch, faSpinner as faSpinner3, faUpload } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i25 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i43 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i52 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i6 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function TeamsImportDialogComponent_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275elementStart(1, "p", 18);
    i07.\u0275\u0275text(2, "This dialog can be used to import teams from another exercise.");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n            ");
  }
}
function TeamsImportDialogComponent_Conditional_38_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275elementStart(1, "p", 19);
    i07.\u0275\u0275text(2, "This dialog can be used to import teams from a file into this exercise.");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n            ");
  }
}
function TeamsImportDialogComponent_Conditional_40_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n            ");
    i07.\u0275\u0275elementStart(1, "div", 12);
    i07.\u0275\u0275text(2, "\n                ");
    i07.\u0275\u0275elementStart(3, "div", 20);
    i07.\u0275\u0275text(4, "\n                    ");
    i07.\u0275\u0275elementStart(5, "jhi-teams-import-from-file-form", 21);
    i07.\u0275\u0275listener("teamsChanged", function TeamsImportDialogComponent_Conditional_40_Template_jhi_teams_import_from_file_form_teamsChanged_5_listener($event) {
      i07.\u0275\u0275restoreView(_r11);
      const ctx_r10 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r10.onTeamsChanged($event));
    });
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(7, "\n            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(8, "\n        ");
  }
}
function TeamsImportDialogComponent_Conditional_41_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                        ");
    i07.\u0275\u0275element(1, "fa-icon", 25);
    i07.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r12 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("icon", ctx_r12.faSpinner)("spin", true);
  }
}
function TeamsImportDialogComponent_Conditional_41_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                        ");
    i07.\u0275\u0275elementStart(1, "span", 26);
    i07.\u0275\u0275text(2, "\n                            ");
    i07.\u0275\u0275elementStart(3, "span", 27);
    i07.\u0275\u0275text(4, "There are no other team-based exercises in this course.");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(5, "\n                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n                    ");
  }
}
function TeamsImportDialogComponent_Conditional_41_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                        ");
    i07.\u0275\u0275elementStart(1, "span", 26);
    i07.\u0275\u0275text(2, "\n                            ");
    i07.\u0275\u0275elementStart(3, "span", 28);
    i07.\u0275\u0275text(4, "No other team-based exercise found in course for search:");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(5, "\n                            ");
    i07.\u0275\u0275elementStart(6, "strong");
    i07.\u0275\u0275text(7);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(8, "\n                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(9, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r14 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(7);
    i07.\u0275\u0275textInterpolate(ctx_r14.searchingExercisesNoResultsForQuery);
  }
}
function TeamsImportDialogComponent_Conditional_41_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                        ");
    i07.\u0275\u0275elementStart(1, "span", 29);
    i07.\u0275\u0275text(2, " Search failed. Please try again. ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                    ");
  }
}
function TeamsImportDialogComponent_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n            ");
    i07.\u0275\u0275elementStart(1, "div", 12);
    i07.\u0275\u0275text(2, "\n                ");
    i07.\u0275\u0275elementStart(3, "div", 20);
    i07.\u0275\u0275text(4, "\n                    ");
    i07.\u0275\u0275elementStart(5, "div");
    i07.\u0275\u0275text(6, "\n                        ");
    i07.\u0275\u0275elementStart(7, "label", 22);
    i07.\u0275\u0275text(8, "Source exercise");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(9, "\n                        ");
    i07.\u0275\u0275element(10, "jhi-help-icon", 23);
    i07.\u0275\u0275text(11, "\n                    ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(12, "\n                    ");
    i07.\u0275\u0275template(13, TeamsImportDialogComponent_Conditional_41_Conditional_13_Template, 3, 2)(14, TeamsImportDialogComponent_Conditional_41_Conditional_14_Template, 7, 0)(15, TeamsImportDialogComponent_Conditional_41_Conditional_15_Template, 10, 1)(16, TeamsImportDialogComponent_Conditional_41_Conditional_16_Template, 4, 0);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(17, "\n                ");
    i07.\u0275\u0275elementStart(18, "jhi-team-exercise-search", 24);
    i07.\u0275\u0275listener("selectExercise", function TeamsImportDialogComponent_Conditional_41_Template_jhi_team_exercise_search_selectExercise_18_listener($event) {
      i07.\u0275\u0275restoreView(_r17);
      const ctx_r16 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r16.onSelectSourceExercise($event));
    })("searching", function TeamsImportDialogComponent_Conditional_41_Template_jhi_team_exercise_search_searching_18_listener($event) {
      i07.\u0275\u0275restoreView(_r17);
      const ctx_r18 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r18.searchingExercises = $event);
    })("searchNoResults", function TeamsImportDialogComponent_Conditional_41_Template_jhi_team_exercise_search_searchNoResults_18_listener($event) {
      i07.\u0275\u0275restoreView(_r17);
      const ctx_r19 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r19.searchingExercisesNoResultsForQuery = $event);
    })("searchFailed", function TeamsImportDialogComponent_Conditional_41_Template_jhi_team_exercise_search_searchFailed_18_listener($event) {
      i07.\u0275\u0275restoreView(_r17);
      const ctx_r20 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r20.searchingExercisesFailed = $event);
    });
    i07.\u0275\u0275text(19, "\n                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(20, "\n            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(21, "\n        ");
  }
  if (rf & 2) {
    const ctx_r4 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(13);
    i07.\u0275\u0275conditional(13, ctx_r4.searchingExercises ? 13 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(14, ctx_r4.searchingExercisesNoResultsForQuery === "" ? 14 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(15, ctx_r4.searchingExercisesNoResultsForQuery ? 15 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(16, ctx_r4.searchingExercisesFailed ? 16 : -1);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275property("course", ctx_r4.exercise.course)("ignoreExercises", i07.\u0275\u0275pureFunction1(6, _c12, ctx_r4.exercise));
  }
}
function TeamsImportDialogComponent_Conditional_42_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                        ");
    i07.\u0275\u0275element(1, "fa-icon", 25);
    i07.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r21 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("icon", ctx_r21.faSpinner)("spin", true);
  }
}
function TeamsImportDialogComponent_Conditional_42_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                        ");
    i07.\u0275\u0275elementStart(1, "span", 33);
    i07.\u0275\u0275text(2, " Loading teams failed. Please try again. ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                    ");
  }
}
function TeamsImportDialogComponent_Conditional_42_Conditional_16_For_6_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                ");
    i07.\u0275\u0275elementStart(1, "li", 35);
    i07.\u0275\u0275text(2, "\n                                    ");
    i07.\u0275\u0275elementStart(3, "div", 36);
    i07.\u0275\u0275text(4);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(5, "\n                                    ");
    i07.\u0275\u0275elementStart(6, "div", 37);
    i07.\u0275\u0275text(7, "\n                                        ");
    i07.\u0275\u0275elementStart(8, "div", 38);
    i07.\u0275\u0275text(9);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(10, "\n                                        ");
    i07.\u0275\u0275elementStart(11, "jhi-team-students-list", 39);
    i07.\u0275\u0275text(12, "\n                                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(13, "\n                                    ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(14, "\n                                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(15, "\n                            ");
  }
  if (rf & 2) {
    const team_r27 = ctx.$implicit;
    const i_r28 = ctx.$index;
    const ctx_r24 = i07.\u0275\u0275nextContext(3);
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275textInterpolate1("\n                                        ", i_r28 + 1, "\n                                    ");
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275classProp("has-error", ctx_r24.teamShortNamesAlreadyExistingInExercise.includes(team_r27.shortName))("has-success", ctx_r24.isSourceTeamFreeOfAnyConflicts(team_r27));
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275textInterpolate(team_r27.shortName);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275property("students", team_r27.students || i07.\u0275\u0275pureFunction0(10, _c22))("errorStudentLogins", ctx_r24.problematicLogins)("withRegistrationNumber", true)("errorStudentRegistrationNumbers", ctx_r24.problematicRegistrationNumbers);
  }
}
function TeamsImportDialogComponent_Conditional_42_Conditional_16_Conditional_7_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                            ");
    i07.\u0275\u0275elementStart(1, "span", 42);
    i07.\u0275\u0275text(2, " The source exercise has no teams. ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                                        ");
  }
}
function TeamsImportDialogComponent_Conditional_42_Conditional_16_Conditional_7_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                            ");
    i07.\u0275\u0275elementStart(1, "span", 43);
    i07.\u0275\u0275text(2, " File has no teams. ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                                        ");
  }
}
function TeamsImportDialogComponent_Conditional_42_Conditional_16_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                ");
    i07.\u0275\u0275elementStart(1, "li", 35);
    i07.\u0275\u0275text(2, "\n                                    ");
    i07.\u0275\u0275elementStart(3, "div", 40);
    i07.\u0275\u0275text(4, "1");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(5, "\n                                    ");
    i07.\u0275\u0275elementStart(6, "div", 41);
    i07.\u0275\u0275text(7, "\n                                        ");
    i07.\u0275\u0275template(8, TeamsImportDialogComponent_Conditional_42_Conditional_16_Conditional_7_Conditional_8_Template, 4, 0)(9, TeamsImportDialogComponent_Conditional_42_Conditional_16_Conditional_7_Conditional_9_Template, 4, 0);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(10, "\n                                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(11, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r25 = i07.\u0275\u0275nextContext(3);
    i07.\u0275\u0275advance(6);
    i07.\u0275\u0275classProp("has-warning", (ctx_r25.sourceTeams == null ? null : ctx_r25.sourceTeams.length) === 0);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275conditional(8, ctx_r25.showImportFromExercise && (ctx_r25.sourceTeams == null ? null : ctx_r25.sourceTeams.length) === 0 ? 8 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(9, !ctx_r25.showImportFromExercise && (ctx_r25.sourceTeams == null ? null : ctx_r25.sourceTeams.length) === 0 ? 9 : -1);
  }
}
function TeamsImportDialogComponent_Conditional_42_Conditional_16_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                            ");
    i07.\u0275\u0275elementStart(1, "div", 44);
    i07.\u0275\u0275text(2, "\n                                ");
    i07.\u0275\u0275element(3, "hr", 45);
    i07.\u0275\u0275text(4, "\n                                ");
    i07.\u0275\u0275elementStart(5, "div");
    i07.\u0275\u0275text(6, "\n                                    ");
    i07.\u0275\u0275elementStart(7, "label", 46);
    i07.\u0275\u0275text(8, "Legend");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(9, "\n                                    ");
    i07.\u0275\u0275element(10, "jhi-help-icon", 47);
    i07.\u0275\u0275text(11, "\n                                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(12, "\n                                ");
    i07.\u0275\u0275elementStart(13, "div", 48);
    i07.\u0275\u0275text(14, "\n                                    ");
    i07.\u0275\u0275elementStart(15, "div", 49);
    i07.\u0275\u0275text(16, "\n                                        ");
    i07.\u0275\u0275elementStart(17, "div");
    i07.\u0275\u0275text(18, "\n                                            ");
    i07.\u0275\u0275elementStart(19, "div", 50);
    i07.\u0275\u0275text(20, "\n                                                ");
    i07.\u0275\u0275elementStart(21, "div", 38);
    i07.\u0275\u0275text(22);
    i07.\u0275\u0275pipe(23, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(24, "\n                                                ");
    i07.\u0275\u0275elementStart(25, "jhi-team-students-list", 51);
    i07.\u0275\u0275text(26, " ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(27, "\n                                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(28, "\n                                            ");
    i07.\u0275\u0275elementStart(29, "div", 52);
    i07.\u0275\u0275text(30, "\n                                                ");
    i07.\u0275\u0275elementStart(31, "label", 53);
    i07.\u0275\u0275text(32, "Conflict-free team");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(33, "\n                                                ");
    i07.\u0275\u0275element(34, "jhi-help-icon", 54);
    i07.\u0275\u0275text(35, "\n                                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(36, "\n                                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(37, "\n                                        ");
    i07.\u0275\u0275elementStart(38, "div");
    i07.\u0275\u0275text(39, "\n                                            ");
    i07.\u0275\u0275elementStart(40, "div", 50);
    i07.\u0275\u0275text(41, "\n                                                ");
    i07.\u0275\u0275elementStart(42, "div", 38);
    i07.\u0275\u0275text(43);
    i07.\u0275\u0275pipe(44, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(45, "\n                                                ");
    i07.\u0275\u0275elementStart(46, "jhi-team-students-list", 51);
    i07.\u0275\u0275text(47, " ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(48, "\n                                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(49, "\n                                            ");
    i07.\u0275\u0275elementStart(50, "div", 52);
    i07.\u0275\u0275text(51, "\n                                                ");
    i07.\u0275\u0275elementStart(52, "label", 55);
    i07.\u0275\u0275text(53, "Team short name conflict");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(54, "\n                                                ");
    i07.\u0275\u0275element(55, "jhi-help-icon", 56);
    i07.\u0275\u0275text(56, "\n                                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(57, "\n                                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(58, "\n                                        ");
    i07.\u0275\u0275elementStart(59, "div");
    i07.\u0275\u0275text(60, "\n                                            ");
    i07.\u0275\u0275elementStart(61, "div", 50);
    i07.\u0275\u0275text(62, "\n                                                ");
    i07.\u0275\u0275elementStart(63, "div", 38);
    i07.\u0275\u0275text(64);
    i07.\u0275\u0275pipe(65, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(66, "\n                                                ");
    i07.\u0275\u0275elementStart(67, "jhi-team-students-list", 57);
    i07.\u0275\u0275text(68, "\n                                                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(69, "\n                                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(70, "\n                                            ");
    i07.\u0275\u0275elementStart(71, "div", 52);
    i07.\u0275\u0275text(72, "\n                                                ");
    i07.\u0275\u0275elementStart(73, "label", 58);
    i07.\u0275\u0275text(74, "Student conflict");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(75, "\n                                                ");
    i07.\u0275\u0275element(76, "jhi-help-icon", 59);
    i07.\u0275\u0275text(77, "\n                                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(78, "\n                                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(79, "\n                                    ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(80, "\n                                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(81, "\n                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(82, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r26 = i07.\u0275\u0275nextContext(3);
    i07.\u0275\u0275advance(19);
    i07.\u0275\u0275classProp("has-success", true);
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275textInterpolate1("", i07.\u0275\u0275pipeBind1(23, 11, "artemisApp.team.sourceTeams.legend.teamShortName"), "1");
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275property("students", ctx_r26.sampleTeamForLegend.students || i07.\u0275\u0275pureFunction0(17, _c22));
    i07.\u0275\u0275advance(15);
    i07.\u0275\u0275classProp("has-error", true);
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275textInterpolate1("", i07.\u0275\u0275pipeBind1(44, 13, "artemisApp.team.sourceTeams.legend.teamShortName"), "2");
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275property("students", ctx_r26.sampleTeamForLegend.students || i07.\u0275\u0275pureFunction0(18, _c22));
    i07.\u0275\u0275advance(18);
    i07.\u0275\u0275textInterpolate1("", i07.\u0275\u0275pipeBind1(65, 15, "artemisApp.team.sourceTeams.legend.teamShortName"), "3");
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275property("students", ctx_r26.sampleTeamForLegend.students || i07.\u0275\u0275pureFunction0(19, _c22))("errorStudentLogins", ctx_r26.sampleErrorStudentLoginsForLegend);
  }
}
function TeamsImportDialogComponent_Conditional_42_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                    ");
    i07.\u0275\u0275elementStart(1, "div");
    i07.\u0275\u0275text(2, "\n                        ");
    i07.\u0275\u0275elementStart(3, "ul", 34);
    i07.\u0275\u0275text(4, "\n                            ");
    i07.\u0275\u0275repeaterCreate(5, TeamsImportDialogComponent_Conditional_42_Conditional_16_For_6_Template, 16, 11, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275template(7, TeamsImportDialogComponent_Conditional_42_Conditional_16_Conditional_7_Template, 12, 4);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(8, "\n                        ");
    i07.\u0275\u0275template(9, TeamsImportDialogComponent_Conditional_42_Conditional_16_Conditional_9_Template, 83, 20);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(10, "\n                ");
  }
  if (rf & 2) {
    const ctx_r23 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275repeater(ctx_r23.sourceTeams);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275conditional(7, !ctx_r23.sourceTeams || ctx_r23.sourceTeams.length === 0 ? 7 : -1);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275conditional(9, ctx_r23.showLegend ? 9 : -1);
  }
}
function TeamsImportDialogComponent_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n            ");
    i07.\u0275\u0275elementStart(1, "div", 30);
    i07.\u0275\u0275text(2, "\n                ");
    i07.\u0275\u0275elementStart(3, "div", 20);
    i07.\u0275\u0275text(4, "\n                    ");
    i07.\u0275\u0275elementStart(5, "div");
    i07.\u0275\u0275text(6, "\n                        ");
    i07.\u0275\u0275elementStart(7, "label", 31);
    i07.\u0275\u0275text(8, "Source teams");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(9, "\n                        ");
    i07.\u0275\u0275element(10, "jhi-help-icon", 32);
    i07.\u0275\u0275text(11, "\n                    ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(12, "\n                    ");
    i07.\u0275\u0275template(13, TeamsImportDialogComponent_Conditional_42_Conditional_13_Template, 3, 2)(14, TeamsImportDialogComponent_Conditional_42_Conditional_14_Template, 4, 0);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(15, "\n                ");
    i07.\u0275\u0275template(16, TeamsImportDialogComponent_Conditional_42_Conditional_16_Template, 11, 2);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(17, "\n        ");
  }
  if (rf & 2) {
    const ctx_r5 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(13);
    i07.\u0275\u0275conditional(13, ctx_r5.loadingSourceTeams ? 13 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(14, ctx_r5.loadingSourceTeamsFailed ? 14 : -1);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275conditional(16, ctx_r5.sourceTeams ? 16 : -1);
  }
}
function TeamsImportDialogComponent_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    const _r35 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n            ");
    i07.\u0275\u0275element(1, "hr", 60);
    i07.\u0275\u0275text(2, "\n            ");
    i07.\u0275\u0275elementStart(3, "div", 61);
    i07.\u0275\u0275text(4, "\n                ");
    i07.\u0275\u0275elementStart(5, "div");
    i07.\u0275\u0275text(6, "\n                    ");
    i07.\u0275\u0275elementStart(7, "label", 62);
    i07.\u0275\u0275text(8, "Import conflict strategy");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(9, "\n                    ");
    i07.\u0275\u0275element(10, "jhi-help-icon", 63);
    i07.\u0275\u0275text(11, "\n                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(12, "\n                ");
    i07.\u0275\u0275elementStart(13, "div", 64);
    i07.\u0275\u0275text(14, "\n                    ");
    i07.\u0275\u0275elementStart(15, "label", 65);
    i07.\u0275\u0275text(16, "\n                        ");
    i07.\u0275\u0275elementStart(17, "input", 66);
    i07.\u0275\u0275listener("click", function TeamsImportDialogComponent_Conditional_43_Template_input_click_17_listener() {
      i07.\u0275\u0275restoreView(_r35);
      const ctx_r34 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r34.updateImportStrategy(ctx_r34.ImportStrategy.PURGE_EXISTING));
    });
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(18, "\n                        ");
    i07.\u0275\u0275elementStart(19, "div", 67);
    i07.\u0275\u0275text(20, "\n                            ");
    i07.\u0275\u0275elementStart(21, "strong");
    i07.\u0275\u0275text(22);
    i07.\u0275\u0275pipe(23, "artemisTranslate");
    i07.\u0275\u0275elementStart(24, "span", 68);
    i07.\u0275\u0275text(25);
    i07.\u0275\u0275pipe(26, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(27, "\n                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(28, "\n                            ");
    i07.\u0275\u0275elementStart(29, "p", 69);
    i07.\u0275\u0275text(30);
    i07.\u0275\u0275pipe(31, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(32, "\n                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(33, "\n                    ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(34, "\n                    ");
    i07.\u0275\u0275elementStart(35, "label", 65);
    i07.\u0275\u0275text(36, "\n                        ");
    i07.\u0275\u0275elementStart(37, "input", 66);
    i07.\u0275\u0275listener("click", function TeamsImportDialogComponent_Conditional_43_Template_input_click_37_listener() {
      i07.\u0275\u0275restoreView(_r35);
      const ctx_r36 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r36.updateImportStrategy(ctx_r36.ImportStrategy.CREATE_ONLY));
    });
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(38, "\n                        ");
    i07.\u0275\u0275elementStart(39, "div", 67);
    i07.\u0275\u0275text(40, "\n                            ");
    i07.\u0275\u0275elementStart(41, "strong");
    i07.\u0275\u0275text(42);
    i07.\u0275\u0275pipe(43, "artemisTranslate");
    i07.\u0275\u0275elementStart(44, "span", 70);
    i07.\u0275\u0275text(45);
    i07.\u0275\u0275pipe(46, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(47, "\n                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(48, "\n                            ");
    i07.\u0275\u0275elementStart(49, "p", 71);
    i07.\u0275\u0275text(50);
    i07.\u0275\u0275pipe(51, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(52, "\n                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(53, "\n                    ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(54, "\n                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(55, "\n            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(56, "\n        ");
  }
  if (rf & 2) {
    const ctx_r6 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(17);
    i07.\u0275\u0275property("ngModel", ctx_r6.importStrategy)("value", ctx_r6.ImportStrategy.PURGE_EXISTING);
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275textInterpolate1("\n                                ", i07.\u0275\u0275pipeBind1(23, 14, "artemisApp.team.importStrategy.options.purgeExisting.label"), "\n                                ");
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(26, 16, "artemisApp.team.importStrategy.options.purgeExisting.badge"));
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275classProp("text-body-secondary", ctx_r6.importStrategy !== ctx_r6.ImportStrategy.PURGE_EXISTING);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275textInterpolate1("\n                                ", i07.\u0275\u0275pipeBind1(31, 18, "artemisApp.team.importStrategy.options.purgeExisting.explanation"), "\n                            ");
    i07.\u0275\u0275advance(7);
    i07.\u0275\u0275property("ngModel", ctx_r6.importStrategy)("value", ctx_r6.ImportStrategy.CREATE_ONLY);
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275textInterpolate1("\n                                ", i07.\u0275\u0275pipeBind1(43, 20, "artemisApp.team.importStrategy.options.createOnly.label"), "\n                                ");
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(46, 22, "artemisApp.team.importStrategy.options.createOnly.badge"));
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275classProp("text-body-secondary", ctx_r6.importStrategy !== ctx_r6.ImportStrategy.CREATE_ONLY);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275textInterpolate1("\n                                ", i07.\u0275\u0275pipeBind1(51, 24, "artemisApp.team.importStrategy.options.createOnly.explanation"), "\n                            ");
  }
}
function TeamsImportDialogComponent_Conditional_47_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                    ");
    i07.\u0275\u0275elementStart(1, "div");
    i07.\u0275\u0275text(2, "\n                        ");
    i07.\u0275\u0275elementStart(3, "strong");
    i07.\u0275\u0275text(4);
    i07.\u0275\u0275pipe(5, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n                    ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(7, "\n                ");
  }
  if (rf & 2) {
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(5, 1, "artemisApp.team.importPreview.studentsInMultipleTeams"));
  }
}
function TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_1_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                ");
    i07.\u0275\u0275elementStart(1, "strong");
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275pipe(3, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(3, 1, "artemisApp.team.importPreview.noTeamsToImport"));
  }
}
function TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_1_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                ");
    i07.\u0275\u0275elementStart(1, "strong");
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275pipe(3, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(3, 1, "artemisApp.team.importPreview.noConflictFreeTeamsToImport"));
  }
}
function TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                        ");
    i07.\u0275\u0275elementStart(1, "div");
    i07.\u0275\u0275text(2, "\n                            ");
    i07.\u0275\u0275template(3, TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_1_Conditional_3_Template, 5, 3)(4, TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_1_Conditional_4_Template, 5, 3);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r39 = i07.\u0275\u0275nextContext(3);
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275conditional(3, ctx_r39.sourceTeams.length === 0 ? 3 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(4, ctx_r39.sourceTeams.length > 0 ? 4 : -1);
  }
}
function TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_2_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                            ");
    i07.\u0275\u0275elementStart(1, "div", 73);
    i07.\u0275\u0275text(2, "\n                                ");
    i07.\u0275\u0275elementStart(3, "strong");
    i07.\u0275\u0275text(4);
    i07.\u0275\u0275pipe(5, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(7, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r43 = i07.\u0275\u0275nextContext(4);
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(5, 2, "artemisApp.team.importPreview.teamsToBeDeleted"));
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate1(" ", ctx_r43.numberOfTeamsToBeDeleted, "\n                            ");
  }
}
function TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_2_Conditional_2_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                    ");
    i07.\u0275\u0275elementStart(1, "span", 74);
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r45 = i07.\u0275\u0275nextContext(5);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("translateValues", i07.\u0275\u0275pureFunction1(2, _c32, ctx_r45.sourceTeams.length));
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275textInterpolate1("\n                                        (out of ", ctx_r45.sourceTeams.length, ")\n                                    ");
  }
}
function TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_2_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                            ");
    i07.\u0275\u0275elementStart(1, "div", 73);
    i07.\u0275\u0275text(2, "\n                                ");
    i07.\u0275\u0275elementStart(3, "strong");
    i07.\u0275\u0275text(4);
    i07.\u0275\u0275pipe(5, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6);
    i07.\u0275\u0275template(7, TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_2_Conditional_2_Conditional_7_Template, 4, 4);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(8, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r44 = i07.\u0275\u0275nextContext(4);
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(5, 3, "artemisApp.team.importPreview.teamsToBeImported"));
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate1(" ", ctx_r44.numberOfTeamsToBeImported, "\n                                ");
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(7, ctx_r44.numberOfTeamsToBeImported < ctx_r44.sourceTeams.length ? 7 : -1);
  }
}
function TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                        ");
    i07.\u0275\u0275template(1, TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_2_Conditional_1_Template, 8, 4)(2, TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_2_Conditional_2_Template, 9, 5);
    i07.\u0275\u0275elementStart(3, "div");
    i07.\u0275\u0275text(4, "\n                            ");
    i07.\u0275\u0275elementStart(5, "strong");
    i07.\u0275\u0275text(6);
    i07.\u0275\u0275pipe(7, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(8);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(9, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r40 = i07.\u0275\u0275nextContext(3);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(1, ctx_r40.numberOfTeamsToBeDeleted > 0 ? 1 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(2, ctx_r40.numberOfTeamsToBeImported !== ctx_r40.numberOfTeamsAfterImport ? 2 : -1);
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(7, 4, "artemisApp.team.importPreview.totalTeamsAfterImport"));
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate1(" ", ctx_r40.numberOfTeamsAfterImport, "\n                        ");
  }
}
function TeamsImportDialogComponent_Conditional_47_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                    ");
    i07.\u0275\u0275template(1, TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_1_Template, 6, 2)(2, TeamsImportDialogComponent_Conditional_47_Conditional_4_Conditional_2_Template, 10, 6);
  }
  if (rf & 2) {
    const ctx_r38 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(1, ctx_r38.numberOfTeamsToBeImported === 0 ? 1 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(2, ctx_r38.numberOfTeamsToBeImported > 0 ? 2 : -1);
  }
}
function TeamsImportDialogComponent_Conditional_47_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n            ");
    i07.\u0275\u0275elementStart(1, "div", 72);
    i07.\u0275\u0275text(2, "\n                ");
    i07.\u0275\u0275template(3, TeamsImportDialogComponent_Conditional_47_Conditional_3_Template, 8, 3)(4, TeamsImportDialogComponent_Conditional_47_Conditional_4_Template, 3, 2);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r7 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275conditional(3, ctx_r7.studentsAppearInMultipleTeams ? 3 : 4);
  }
}
function TeamsImportDialogComponent_Conditional_58_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275elementStart(1, "button", 75);
    i07.\u0275\u0275text(2, "\n                    ");
    i07.\u0275\u0275element(3, "fa-icon", 76);
    i07.\u0275\u0275text(4, "\n                    ");
    i07.\u0275\u0275elementStart(5, "span", 77);
    i07.\u0275\u0275text(6, "Import");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(7, "\n                    ");
    i07.\u0275\u0275element(8, "fa-icon", 78);
    i07.\u0275\u0275text(9, "\n                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(10, "\n            ");
  }
  if (rf & 2) {
    const ctx_r8 = i07.\u0275\u0275nextContext();
    const _r0 = i07.\u0275\u0275reference(1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("disabled", _r0.invalid || ctx_r8.isSubmitDisabled);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275property("icon", ctx_r8.faUpload);
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275property("hidden", !ctx_r8.isImporting)("spin", true)("icon", ctx_r8.faCircleNotch);
  }
}
function TeamsImportDialogComponent_Conditional_59_Template(rf, ctx) {
  if (rf & 1) {
    const _r47 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275elementStart(1, "button", 79);
    i07.\u0275\u0275listener("delete", function TeamsImportDialogComponent_Conditional_59_Template_button_delete_1_listener() {
      i07.\u0275\u0275restoreView(_r47);
      const ctx_r46 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r46.purgeAndImportTeams());
    });
    i07.\u0275\u0275text(2, "\n                    ");
    i07.\u0275\u0275element(3, "fa-icon", 80);
    i07.\u0275\u0275text(4, "\n                    ");
    i07.\u0275\u0275elementStart(5, "span", 81);
    i07.\u0275\u0275text(6, "Purge");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(7, " +\n                    ");
    i07.\u0275\u0275elementStart(8, "span", 77);
    i07.\u0275\u0275text(9, "Import");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(10, "\n                    ");
    i07.\u0275\u0275element(11, "fa-icon", 78);
    i07.\u0275\u0275text(12, "\n                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(13, "\n            ");
  }
  if (rf & 2) {
    const ctx_r9 = i07.\u0275\u0275nextContext();
    const _r0 = i07.\u0275\u0275reference(1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("disabled", _r0.invalid || ctx_r9.isSubmitDisabled)("renderButtonText", false)("renderButtonStyle", false)("entityTitle", ctx_r9.exercise.title || "")("dialogError", ctx_r9.dialogError$);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275property("icon", ctx_r9.faUpload);
    i07.\u0275\u0275advance(8);
    i07.\u0275\u0275property("hidden", !ctx_r9.isImporting)("spin", true)("icon", ctx_r9.faCircleNotch);
  }
}
var _c05, _c12, _c22, _c32, _c42, TeamsImportDialogComponent;
var init_teams_import_dialog_component = __esm({
  "src/main/webapp/app/exercises/shared/team/teams-import-dialog/teams-import-dialog.component.ts"() {
    init_alert_service();
    init_team_service();
    init_team_model();
    init_exercise_model();
    init_delete_dialog_model();
    init_user_model();
    init_team_service();
    init_alert_service();
    init_translate_directive();
    init_delete_button_directive();
    init_help_icon_component();
    init_team_students_list_component();
    init_team_exercise_search_component();
    init_teams_import_from_file_form_component();
    init_artemis_translate_pipe();
    _c05 = ["importForm"];
    _c12 = (a0) => [a0];
    _c22 = () => [];
    _c32 = (a0) => ({ number: a0 });
    _c42 = (a0, a1) => ({ "btn-primary": a0, "btn-default": a1 });
    TeamsImportDialogComponent = class _TeamsImportDialogComponent {
      teamService;
      activeModal;
      alertService;
      ImportStrategy = TeamImportStrategyType;
      ActionType = ActionType;
      importForm;
      exercise;
      teams;
      sourceExercise;
      searchingExercises = false;
      searchingExercisesFailed = false;
      searchingExercisesNoResultsForQuery;
      sourceTeams;
      loadingSourceTeams = false;
      loadingSourceTeamsFailed = false;
      importStrategy;
      defaultImportStrategy = TeamImportStrategyType.CREATE_ONLY;
      isImporting = false;
      showImportFromExercise = true;
      teamShortNamesAlreadyExistingInExercise = [];
      sourceTeamsFreeOfConflicts = [];
      conflictingRegistrationNumbersSet = /* @__PURE__ */ new Set();
      conflictingLoginsSet = /* @__PURE__ */ new Set();
      studentsAppearInMultipleTeams = false;
      dialogErrorSource = new Subject4();
      dialogError$ = this.dialogErrorSource.asObservable();
      faBan = faBan2;
      faSpinner = faSpinner3;
      faCircleNotch = faCircleNotch;
      faUpload = faUpload;
      constructor(teamService, activeModal, alertService) {
        this.teamService = teamService;
        this.activeModal = activeModal;
        this.alertService = alertService;
      }
      ngOnInit() {
        this.computePotentialConflictsBasedOnExistingTeams();
      }
      ngOnDestroy() {
        this.dialogErrorSource.unsubscribe();
      }
      loadSourceTeams(sourceExercise) {
        this.sourceTeams = void 0;
        this.loadingSourceTeams = true;
        this.loadingSourceTeamsFailed = false;
        this.teamService.findAllByExerciseId(sourceExercise.id).subscribe({
          next: (teamsResponse) => {
            this.sourceTeams = teamsResponse.body;
            this.computeSourceTeamsFreeOfConflicts();
            this.loadingSourceTeams = false;
          },
          error: () => {
            this.loadingSourceTeams = false;
            this.loadingSourceTeamsFailed = true;
          }
        });
      }
      onSelectSourceExercise(exercise) {
        this.sourceExercise = exercise;
        this.initImportStrategy();
        this.loadSourceTeams(exercise);
      }
      initImportStrategy() {
        this.importStrategy = this.teams.length === 0 ? this.defaultImportStrategy : void 0;
      }
      computePotentialConflictsBasedOnExistingTeams() {
        this.teamShortNamesAlreadyExistingInExercise = this.teams.map((team) => team.shortName);
        const studentLoginsAlreadyExistingInExercise = flatMap(this.teams, (team) => team.students.map((student) => student.login));
        const studentRegistrationNumbersAlreadyExistingInExercise = flatMap(this.teams, (team) => team.students.map((student) => student.visibleRegistrationNumber || ""));
        this.conflictingRegistrationNumbersSet = this.addArrayToSet(this.conflictingRegistrationNumbersSet, studentRegistrationNumbersAlreadyExistingInExercise);
        this.conflictingLoginsSet = this.addArrayToSet(this.conflictingLoginsSet, studentLoginsAlreadyExistingInExercise);
      }
      computeSourceTeamsFreeOfConflicts() {
        this.sourceTeamsFreeOfConflicts = this.sourceTeams.filter((team) => this.isSourceTeamFreeOfAnyConflicts(team));
      }
      isSourceTeamFreeOfAnyConflicts(sourceTeam) {
        if (this.teamShortNamesAlreadyExistingInExercise.includes(sourceTeam.shortName)) {
          return false;
        }
        if (sourceTeam.students.some((student) => student.login && this.conflictingLoginsSet.has(student.login))) {
          return false;
        }
        if (!this.showImportFromExercise) {
          if (sourceTeam.students.some((student) => student.visibleRegistrationNumber && this.conflictingRegistrationNumbersSet.has(student.visibleRegistrationNumber))) {
            return false;
          }
        }
        return true;
      }
      get numberOfConflictFreeSourceTeams() {
        return this.sourceTeamsFreeOfConflicts.length;
      }
      get numberOfTeamsToBeDeleted() {
        switch (this.importStrategy) {
          case TeamImportStrategyType.PURGE_EXISTING:
            return this.teams.length;
          case TeamImportStrategyType.CREATE_ONLY:
            return 0;
        }
      }
      get numberOfTeamsToBeImported() {
        switch (this.importStrategy) {
          case TeamImportStrategyType.PURGE_EXISTING:
            return this.sourceTeams.length;
          case TeamImportStrategyType.CREATE_ONLY:
            return this.numberOfConflictFreeSourceTeams;
        }
      }
      get numberOfTeamsAfterImport() {
        switch (this.importStrategy) {
          case TeamImportStrategyType.PURGE_EXISTING:
            return this.sourceTeams.length;
          case TeamImportStrategyType.CREATE_ONLY:
            return this.teams.length + this.numberOfConflictFreeSourceTeams;
        }
      }
      get showImportStrategyChoices() {
        if (this.showImportFromExercise) {
          return this.sourceExercise !== void 0 && this.sourceTeams !== void 0 && this.sourceTeams.length > 0 && this.teams.length > 0;
        }
        return this.sourceTeams !== void 0 && this.sourceTeams.length > 0 && this.teams.length > 0;
      }
      updateImportStrategy(importStrategy) {
        this.importStrategy = importStrategy;
      }
      get showImportPreviewNumbers() {
        if (this.showImportFromExercise) {
          return this.sourceExercise !== void 0 && this.sourceTeams !== void 0 && this.sourceTeams.length > 0 && Boolean(this.importStrategy);
        }
        return this.studentsAppearInMultipleTeams || this.sourceTeams !== void 0 && this.sourceTeams.length > 0 && Boolean(this.importStrategy);
      }
      get isSubmitDisabled() {
        if (this.showImportFromExercise) {
          return this.isImporting || !this.sourceExercise || !this.sourceTeams || !this.importStrategy || !this.numberOfTeamsToBeImported;
        }
        return !this.sourceTeams || this.sourceTeams.length === 0 || !this.importStrategy || !this.numberOfTeamsToBeImported || this.studentsAppearInMultipleTeams;
      }
      clear() {
        this.activeModal.dismiss("cancel");
      }
      purgeAndImportTeams() {
        this.dialogErrorSource.next("");
        this.importTeams();
      }
      importTeams() {
        if (this.isSubmitDisabled) {
          return;
        }
        if (this.showImportFromExercise) {
          this.isImporting = true;
          this.teamService.importTeamsFromSourceExercise(this.exercise, this.sourceExercise, this.importStrategy).subscribe({
            next: (res) => this.onSaveSuccess(res),
            error: (error) => this.onSaveError(error)
          });
        } else if (this.sourceTeams) {
          this.resetConflictingSets();
          this.teamService.importTeams(this.exercise, this.sourceTeams, this.importStrategy).subscribe({
            next: (res) => this.onSaveSuccess(res),
            error: (error) => this.onSaveError(error)
          });
        }
      }
      onTeamsChanged(fileTeams) {
        this.initImportStrategy();
        this.sourceTeams = fileTeams;
        this.resetConflictingSets();
        const students = flatMap(fileTeams, (fileTeam) => fileTeam.students ?? []);
        const studentLoginsAlreadyExistingInOtherTeams = this.findIdentifiersWhichAppearsMultipleTimes(students, "login");
        const studentRegistrationNumbersAlreadyExistingInOtherTeams = this.findIdentifiersWhichAppearsMultipleTimes(students, "visibleRegistrationNumber");
        this.studentsAppearInMultipleTeams = studentLoginsAlreadyExistingInOtherTeams.length > 0 || studentRegistrationNumbersAlreadyExistingInOtherTeams.length > 0;
        this.conflictingRegistrationNumbersSet = this.addArrayToSet(this.conflictingRegistrationNumbersSet, studentRegistrationNumbersAlreadyExistingInOtherTeams);
        this.conflictingLoginsSet = this.addArrayToSet(this.conflictingLoginsSet, studentLoginsAlreadyExistingInOtherTeams);
        this.computeSourceTeamsFreeOfConflicts();
      }
      findIdentifiersWhichAppearsMultipleTimes(users, identifier) {
        const occurrenceMap = /* @__PURE__ */ new Map();
        users.forEach((user) => {
          const identifierValue = user[identifier];
          if (identifierValue) {
            if (occurrenceMap.get(identifierValue)) {
              occurrenceMap.set(identifierValue, occurrenceMap.get(identifierValue) + 1);
            } else {
              occurrenceMap.set(identifierValue, 1);
            }
          }
        });
        return [...occurrenceMap.keys()].filter((key) => occurrenceMap.get(key) > 1);
      }
      onSaveSuccess(teams) {
        this.activeModal.close(teams.body);
        this.isImporting = false;
        setTimeout(() => {
          this.alertService.success("artemisApp.team.importSuccess", { numberOfImportedTeams: this.numberOfTeamsToBeImported });
        }, 500);
      }
      onSaveError(httpErrorResponse) {
        const { errorKey, params } = httpErrorResponse.error;
        switch (errorKey) {
          case "studentsNotFound":
            const { registrationNumbers, logins } = params;
            this.onStudentsNotFoundError(registrationNumbers, logins);
            break;
          case "studentsAppearMultipleTimes":
            const { students } = params;
            this.onStudentsAppearMultipleTimesError(students);
            break;
          default:
            this.alertService.error("artemisApp.team.importError");
            break;
        }
        this.isImporting = false;
      }
      onStudentsNotFoundError(registrationNumbers, logins) {
        const notFoundRegistrationNumbers = registrationNumbers;
        const notFoundLogins = logins;
        if (notFoundRegistrationNumbers.length > 0) {
          this.alertService.error("artemisApp.team.errors.registrationNumbersNotFound", { registrationNumbers: notFoundRegistrationNumbers });
          this.conflictingRegistrationNumbersSet = this.addArrayToSet(this.conflictingRegistrationNumbersSet, notFoundRegistrationNumbers);
        }
        if (notFoundLogins.length > 0) {
          this.alertService.error("artemisApp.team.errors.loginsNotFound", { logins: notFoundLogins });
          this.conflictingLoginsSet = this.addArrayToSet(this.conflictingLoginsSet, notFoundLogins);
        }
      }
      onStudentsAppearMultipleTimesError(studentsAppearMultipleTimes) {
        if (studentsAppearMultipleTimes.length > 0) {
          this.studentsAppearInMultipleTeams = true;
          const studentLoginsAlreadyExistingInOtherTeams = studentsAppearMultipleTimes.map((student) => student.first);
          this.conflictingLoginsSet = this.addArrayToSet(this.conflictingLoginsSet, studentLoginsAlreadyExistingInOtherTeams);
          const studentRegistrationNumbersAlreadyExistingInOtherTeams = studentsAppearMultipleTimes.map((student) => student.second);
          this.conflictingRegistrationNumbersSet = this.addArrayToSet(this.conflictingRegistrationNumbersSet, studentRegistrationNumbersAlreadyExistingInOtherTeams);
          this.alertService.error("artemisApp.team.errors.studentsAppearMultipleTimes", {
            students: studentsAppearMultipleTimes.map((student) => `${student.first}:${student.second}`).join(",")
          });
        }
      }
      setShowImportFromExercise(showFromExercise) {
        this.showImportFromExercise = showFromExercise;
        this.sourceTeams = void 0;
        this.sourceExercise = void 0;
        this.initImportStrategy();
        this.isImporting = false;
        this.resetConflictingSets();
      }
      get sampleTeamForLegend() {
        const team = new Team();
        const student = new User(1, "ga12abc", "John", "Doe", "john.doe@tum.de");
        student.name = `${student.firstName} ${student.lastName}`;
        team.students = [student];
        return team;
      }
      get sampleErrorStudentLoginsForLegend() {
        return this.sampleTeamForLegend.students.map((student) => student.login).filter((login) => login !== void 0);
      }
      get showLegend() {
        return Boolean(this.sourceTeams && this.numberOfConflictFreeSourceTeams !== this.sourceTeams.length);
      }
      get problematicRegistrationNumbers() {
        return [...this.conflictingRegistrationNumbersSet];
      }
      get problematicLogins() {
        return [...this.conflictingLoginsSet];
      }
      addArrayToSet(set, array) {
        return /* @__PURE__ */ new Set([...array, ...set.values()]);
      }
      resetConflictingSets() {
        this.conflictingLoginsSet = /* @__PURE__ */ new Set();
        this.conflictingRegistrationNumbersSet = /* @__PURE__ */ new Set();
        this.studentsAppearInMultipleTeams = false;
        this.computePotentialConflictsBasedOnExistingTeams();
      }
      static \u0275fac = function TeamsImportDialogComponent_Factory(t) {
        return new (t || _TeamsImportDialogComponent)(i07.\u0275\u0275directiveInject(TeamService), i07.\u0275\u0275directiveInject(i25.NgbActiveModal), i07.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i07.\u0275\u0275defineComponent({ type: _TeamsImportDialogComponent, selectors: [["jhi-teams-import-dialog"]], viewQuery: function TeamsImportDialogComponent_Query(rf, ctx) {
        if (rf & 1) {
          i07.\u0275\u0275viewQuery(_c05, 5);
        }
        if (rf & 2) {
          let _t;
          i07.\u0275\u0275queryRefresh(_t = i07.\u0275\u0275loadQuery()) && (ctx.importForm = _t.first);
        }
      }, inputs: { exercise: "exercise", teams: "teams" }, decls: 63, vars: 20, consts: [["id", "teamsImportDialogForm", "name", "importForm", "role", "form", "novalidate", "", 3, "ngSubmit"], ["editForm", "ngForm"], [1, "modal-header"], [1, "modal-title"], [3, "jhiTranslate"], ["type", "button", "data-dismiss", "modal", "aria-hidden", "true", 1, "btn-close", 3, "click"], [1, "modal-body"], [1, "w100", "row", "justify-content-center", "card-header"], [1, "btn-group"], [1, "btn", 3, "ngClass", "click"], ["jhiTranslate", "artemisApp.team.importTeams.fromAnExercise"], ["jhiTranslate", "artemisApp.team.importTeams.fromAFile"], [1, "form-group"], [1, "modal-footer"], [1, "flex-grow-1", "d-flex", "justify-content-end"], ["type", "button", "data-dismiss", "modal", 1, "btn", "btn-default", "cancel", 3, "click"], [3, "icon"], ["jhiTranslate", "entity.action.cancel"], ["jhiTranslate", "artemisApp.team.importTeams.introTextExercise", 1, "intro-text"], ["jhiTranslate", "artemisApp.team.importTeams.introTextFile", 1, "intro-text"], [1, "d-flex", "align-items-end"], [3, "teamsChanged"], ["jhiTranslate", "artemisApp.team.sourceExercise.label", 1, "label-narrow"], ["text", "artemisApp.team.sourceExercise.tooltip", 1, "me-1"], ["id", "teamExercises", 3, "course", "ignoreExercises", "selectExercise", "searching", "searchNoResults", "searchFailed"], [1, "loading-spinner", 3, "icon", "spin"], [1, "error-message", "text-danger"], ["jhiTranslate", "artemisApp.team.exerciseSearch.noResults"], ["jhiTranslate", "artemisApp.team.exerciseSearch.noResultsForSearchTerm"], ["jhiTranslate", "artemisApp.team.exerciseSearch.failed", 1, "error-message", "text-danger"], [1, "form-group", "mt-2"], ["jhiTranslate", "artemisApp.team.sourceTeams.label", 1, "label-narrow"], ["text", "artemisApp.team.sourceTeams.tooltip", 1, "me-1"], ["jhiTranslate", "artemisApp.team.loadSourceTeams.failed", 1, "error-message", "text-danger"], [1, "list-group", "list-group--teams", "mt-2"], [1, "list-group-item-container", "d-flex", "align-items-center"], [1, "list-group-item-index"], [1, "list-group-item", "list-group-item--teams"], [1, "team-name"], [1, "team-students", 3, "students", "errorStudentLogins", "withRegistrationNumber", "errorStudentRegistrationNumbers"], [1, "list-group-item-index", "text-body-secondary"], [1, "list-group-item", "list-group-item--teams", "py-5"], ["jhiTranslate", "artemisApp.team.noTeamsInSourceExercise"], ["jhiTranslate", "artemisApp.team.noTeamsInFile"], [1, "source-teams-legend-container", "mt-4"], [1, "mt-3", "mb-2"], ["jhiTranslate", "artemisApp.team.sourceTeams.legend.label"], ["text", "artemisApp.team.sourceTeams.legend.tooltip", 1, "me-1"], [1, "source-teams-legend-box"], [1, "source-teams-legend", "d-flex", "justify-content-between"], [1, "list-group-item--teams"], [1, "team-students", 3, "students"], [1, "label-with-tooltip"], ["jhiTranslate", "artemisApp.team.sourceTeams.legend.items.conflictFreeTeam.label"], ["text", "artemisApp.team.sourceTeams.legend.items.conflictFreeTeam.tooltip", 1, "me-1"], ["jhiTranslate", "artemisApp.team.sourceTeams.legend.items.teamShortNameConflict.label"], ["text", "artemisApp.team.sourceTeams.legend.items.teamShortNameConflict.tooltip", 1, "me-1"], [1, "team-students", 3, "students", "errorStudentLogins"], ["jhiTranslate", "artemisApp.team.sourceTeams.legend.items.studentConflict.label"], ["text", "artemisApp.team.sourceTeams.legend.items.studentConflict.tooltip", 1, "me-1"], [1, "my-4"], [1, "form-group", "mb-0"], ["jhiTranslate", "artemisApp.team.importStrategy.label", 1, "label-narrow"], ["text", "artemisApp.team.importStrategy.tooltip", 1, "me-1"], [1, "d-flex", "flex-column", "mt-2", "ps-2"], [1, "d-flex", "align-items-start"], ["type", "radio", "name", "importStrategy", 1, "radio-input-with-explanation", 3, "ngModel", "value", "click"], [1, "ms-2", "radio-label-with-explanation"], [1, "badge", "bg-danger", "ms-1"], [1, "explanation", "mb-2"], [1, "badge", "bg-success", "ms-1"], [1, "explanation", "mb-0"], [1, "flex-shrink-0", "me-2", "d-flex"], [1, "me-3"], ["jhiTranslate", "artemisApp.team.importPreview.outOf", 3, "translateValues"], ["type", "submit", 1, "btn", "btn-warning", 3, "disabled"], [1, "me-2", 3, "icon"], ["jhiTranslate", "entity.action.to-import"], [1, "ms-1", 3, "hidden", "spin", "icon"], ["jhiDeleteButton", "", "deleteQuestion", "artemisApp.team.purgeConfirmationDialog.question", "deleteConfirmationText", "artemisApp.team.purgeConfirmationDialog.typeNameToConfirm", 1, "btn", "btn-warning", 3, "disabled", "renderButtonText", "renderButtonStyle", "entityTitle", "dialogError", "delete"], [1, "me-1", 3, "icon"], ["jhiTranslate", "entity.action.purge"]], template: function TeamsImportDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
          i07.\u0275\u0275elementStart(0, "form", 0, 1);
          i07.\u0275\u0275listener("ngSubmit", function TeamsImportDialogComponent_Template_form_ngSubmit_0_listener() {
            return ctx.importTeams();
          });
          i07.\u0275\u0275text(2, "\n    ");
          i07.\u0275\u0275elementStart(3, "div", 2);
          i07.\u0275\u0275text(4, "\n        ");
          i07.\u0275\u0275elementStart(5, "h4", 3);
          i07.\u0275\u0275text(6, "\n            ");
          i07.\u0275\u0275elementStart(7, "span", 4);
          i07.\u0275\u0275text(8, " Import teams into: ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(9, "\n            ");
          i07.\u0275\u0275elementStart(10, "span");
          i07.\u0275\u0275text(11);
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(12, "\n        ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(13, "\n        ");
          i07.\u0275\u0275elementStart(14, "button", 5);
          i07.\u0275\u0275listener("click", function TeamsImportDialogComponent_Template_button_click_14_listener() {
            return ctx.clear();
          });
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(15, "\n    ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(16, "\n    ");
          i07.\u0275\u0275elementStart(17, "div", 6);
          i07.\u0275\u0275text(18, "\n        ");
          i07.\u0275\u0275elementStart(19, "div", 7);
          i07.\u0275\u0275text(20, "\n            ");
          i07.\u0275\u0275elementStart(21, "div", 8);
          i07.\u0275\u0275text(22, "\n                ");
          i07.\u0275\u0275elementStart(23, "div", 9);
          i07.\u0275\u0275listener("click", function TeamsImportDialogComponent_Template_div_click_23_listener() {
            return ctx.setShowImportFromExercise(true);
          });
          i07.\u0275\u0275text(24, "\n                    ");
          i07.\u0275\u0275element(25, "span", 10);
          i07.\u0275\u0275text(26, "\n                ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(27, "\n                ");
          i07.\u0275\u0275elementStart(28, "div", 9);
          i07.\u0275\u0275listener("click", function TeamsImportDialogComponent_Template_div_click_28_listener() {
            return ctx.setShowImportFromExercise(false);
          });
          i07.\u0275\u0275text(29, "\n                    ");
          i07.\u0275\u0275element(30, "span", 11);
          i07.\u0275\u0275text(31, "\n                ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(32, "\n            ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(33, "\n        ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(34, "\n        ");
          i07.\u0275\u0275elementStart(35, "div", 12);
          i07.\u0275\u0275text(36, "\n            ");
          i07.\u0275\u0275template(37, TeamsImportDialogComponent_Conditional_37_Template, 4, 0)(38, TeamsImportDialogComponent_Conditional_38_Template, 4, 0);
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(39, "\n        ");
          i07.\u0275\u0275template(40, TeamsImportDialogComponent_Conditional_40_Template, 9, 0)(41, TeamsImportDialogComponent_Conditional_41_Template, 22, 8)(42, TeamsImportDialogComponent_Conditional_42_Template, 18, 3)(43, TeamsImportDialogComponent_Conditional_43_Template, 57, 26);
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(44, "\n    ");
          i07.\u0275\u0275elementStart(45, "div", 13);
          i07.\u0275\u0275text(46, "\n        ");
          i07.\u0275\u0275template(47, TeamsImportDialogComponent_Conditional_47_Template, 6, 1);
          i07.\u0275\u0275elementStart(48, "div", 14);
          i07.\u0275\u0275text(49, "\n            ");
          i07.\u0275\u0275elementStart(50, "button", 15);
          i07.\u0275\u0275listener("click", function TeamsImportDialogComponent_Template_button_click_50_listener() {
            return ctx.clear();
          });
          i07.\u0275\u0275text(51, "\n                ");
          i07.\u0275\u0275element(52, "fa-icon", 16);
          i07.\u0275\u0275text(53, "\xA0");
          i07.\u0275\u0275elementStart(54, "span", 17);
          i07.\u0275\u0275text(55, "Cancel");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(56, "\n            ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(57, "\n            ");
          i07.\u0275\u0275template(58, TeamsImportDialogComponent_Conditional_58_Template, 11, 5)(59, TeamsImportDialogComponent_Conditional_59_Template, 14, 9);
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(60, "\n    ");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(61, "\n");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(62, "\n");
        }
        if (rf & 2) {
          i07.\u0275\u0275advance(7);
          i07.\u0275\u0275property("jhiTranslate", "artemisApp.team.importTeams.dialogTitle");
          i07.\u0275\u0275advance(4);
          i07.\u0275\u0275textInterpolate(ctx.exercise.title);
          i07.\u0275\u0275advance(12);
          i07.\u0275\u0275property("ngClass", i07.\u0275\u0275pureFunction2(14, _c42, ctx.showImportFromExercise, !ctx.showImportFromExercise));
          i07.\u0275\u0275advance(5);
          i07.\u0275\u0275property("ngClass", i07.\u0275\u0275pureFunction2(17, _c42, !ctx.showImportFromExercise, ctx.showImportFromExercise));
          i07.\u0275\u0275advance(9);
          i07.\u0275\u0275conditional(37, ctx.showImportFromExercise ? 37 : -1);
          i07.\u0275\u0275advance(1);
          i07.\u0275\u0275conditional(38, !ctx.showImportFromExercise ? 38 : -1);
          i07.\u0275\u0275advance(2);
          i07.\u0275\u0275conditional(40, !ctx.showImportFromExercise ? 40 : -1);
          i07.\u0275\u0275advance(1);
          i07.\u0275\u0275conditional(41, ctx.showImportFromExercise ? 41 : -1);
          i07.\u0275\u0275advance(1);
          i07.\u0275\u0275conditional(42, ctx.sourceExercise || ctx.sourceTeams ? 42 : -1);
          i07.\u0275\u0275advance(1);
          i07.\u0275\u0275conditional(43, ctx.showImportStrategyChoices ? 43 : -1);
          i07.\u0275\u0275advance(4);
          i07.\u0275\u0275conditional(47, ctx.showImportPreviewNumbers && ctx.sourceTeams ? 47 : -1);
          i07.\u0275\u0275advance(5);
          i07.\u0275\u0275property("icon", ctx.faBan);
          i07.\u0275\u0275advance(6);
          i07.\u0275\u0275conditional(58, ctx.importStrategy !== ctx.ImportStrategy.PURGE_EXISTING ? 58 : -1);
          i07.\u0275\u0275advance(1);
          i07.\u0275\u0275conditional(59, ctx.importStrategy === ctx.ImportStrategy.PURGE_EXISTING ? 59 : -1);
        }
      }, dependencies: [i43.\u0275NgNoValidate, i43.DefaultValueAccessor, i43.RadioControlValueAccessor, i43.NgControlStatus, i43.NgControlStatusGroup, i43.NgModel, i43.NgForm, i52.NgClass, i6.FaIconComponent, TranslateDirective, DeleteButtonDirective, HelpIconComponent, TeamStudentsListComponent, TeamExerciseSearchComponent, TeamsImportFromFileFormComponent, ArtemisTranslatePipe], styles: ["/* src/main/webapp/app/exercises/shared/team/teams-import-dialog/teams-import-dialog.component.scss */\n:host {\n  display: block;\n}\n.loading-spinner {\n  position: relative;\n  top: -2px;\n}\n.error-message {\n  position: relative;\n  top: -4.5px;\n  line-height: 1rem;\n  font-size: 0.8rem;\n  margin-left: 5px;\n}\n.intro-text {\n  color: var(--secondary);\n}\n.list-group--teams {\n  max-height: max(240px, 100vh - 740px);\n  overflow-y: auto;\n}\n.list-group--teams .list-group-item-container {\n  position: relative;\n  margin-bottom: 0.15rem;\n}\n.list-group--teams .list-group-item-index {\n  min-width: 30px;\n  text-align: right;\n  margin-left: 0.5rem;\n  margin-right: 1rem;\n  font-size: 1.1rem;\n  font-weight: 500;\n}\n.list-group-item--teams {\n  display: flex !important;\n  align-items: center;\n  flex-grow: 1;\n  overflow-x: hidden;\n  padding: 0.3rem 1rem;\n  border-radius: 0.15rem !important;\n  background-color: var(--bs-body-bg);\n}\n.list-group-item--teams.has-success {\n  color: var(--artemis-alert-success-color);\n  background-color: var(--artemis-alert-success-background);\n}\n.list-group-item--teams.has-warning {\n  color: var(--artemis-alert-warning-color);\n  background-color: var(--artemis-alert-warning-background);\n}\n.list-group-item--teams.has-error {\n  background-color: var(--artemis-alert-danger-background);\n}\n.list-group-item--teams.has-error .team-name {\n  color: var(--artemis-alert-danger-color);\n}\n.source-teams-legend-container {\n  margin-left: calc(30px + 1.5rem);\n  opacity: 0.4;\n  transition: 0.2s ease-out opacity;\n}\n.source-teams-legend-container:hover {\n  opacity: 1;\n  transition: 0.1s ease-in opacity;\n  transition-delay: 0.2s;\n}\n.source-teams-legend-box {\n  background: rgba(0, 100, 220, 0.04);\n  padding: 12px 15px 0;\n  border-radius: 0.2rem;\n  border: 1px solid rgba(0, 0, 0, 0.075);\n}\n.source-teams-legend {\n  cursor: default;\n  font-size: 12.5px;\n}\n.source-teams-legend > * {\n  flex-grow: 1;\n}\n.source-teams-legend > *:not(:first-child) {\n  margin-left: 25px;\n}\n.source-teams-legend .list-group-item--teams {\n  padding: 0 0.5rem;\n  font-size: 11px;\n  border: 1px solid rgba(0, 0, 0, 0.125);\n  border-radius: 0.15rem;\n}\n.source-teams-legend .list-group-item--teams .team-name {\n  width: unset;\n}\n.source-teams-legend .list-group-item--teams .team-students {\n  font-size: 11px;\n}\n.source-teams-legend .list-group-item--teams .team-students .student-group-item {\n  padding-top: 0;\n  padding-bottom: 0;\n}\n.source-teams-legend .label-with-tooltip {\n  margin-top: 3px;\n}\n.source-teams-legend .label-with-tooltip label {\n  color: var(--secondary);\n}\n.team-name {\n  width: 135px;\n  margin-right: 15px;\n  flex-shrink: 0;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.team-students {\n  flex-grow: 1;\n  overflow-x: hidden;\n  font-size: 12.5px;\n}\n.label-narrow {\n  display: inline-block;\n  margin-bottom: 0.1rem;\n}\n.radio-input-with-explanation {\n  height: 1.35rem;\n}\n.radio-label-with-explanation .badge {\n  position: relative;\n  top: -1px;\n  font-size: 85%;\n}\n.radio-label-with-explanation .explanation {\n  max-width: 66%;\n}\n.modal-footer {\n  justify-content: space-between;\n}\n.modal-footer button[disabled] {\n  cursor: not-allowed;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbXMtaW1wb3J0LWRpYWxvZy90ZWFtcy1pbXBvcnQtZGlhbG9nLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyI6aG9zdCB7XG4gICAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5sb2FkaW5nLXNwaW5uZXIge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB0b3A6IC0ycHg7XG59XG5cbi5lcnJvci1tZXNzYWdlIHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgdG9wOiAtNC41cHg7XG4gICAgbGluZS1oZWlnaHQ6IDFyZW07XG4gICAgZm9udC1zaXplOiAwLjhyZW07XG4gICAgbWFyZ2luLWxlZnQ6IDVweDtcbn1cblxuLmludHJvLXRleHQge1xuICAgIGNvbG9yOiB2YXIoLS1zZWNvbmRhcnkpO1xufVxuXG4ubGlzdC1ncm91cC0tdGVhbXMge1xuICAgIG1heC1oZWlnaHQ6IG1heCgyNDBweCwgMTAwdmggLSA3NDBweCk7XG4gICAgb3ZlcmZsb3cteTogYXV0bztcblxuICAgIC5saXN0LWdyb3VwLWl0ZW0tY29udGFpbmVyIHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAwLjE1cmVtO1xuICAgIH1cblxuICAgIC5saXN0LWdyb3VwLWl0ZW0taW5kZXgge1xuICAgICAgICBtaW4td2lkdGg6IDMwcHg7XG4gICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgICAgICBtYXJnaW4tbGVmdDogMC41cmVtO1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDFyZW07XG4gICAgICAgIGZvbnQtc2l6ZTogMS4xcmVtO1xuICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgIH1cbn1cblxuLmxpc3QtZ3JvdXAtaXRlbS0tdGVhbXMge1xuICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgZmxleC1ncm93OiAxO1xuICAgIG92ZXJmbG93LXg6IGhpZGRlbjtcbiAgICBwYWRkaW5nOiAwLjNyZW0gMXJlbTtcbiAgICBib3JkZXItcmFkaXVzOiAwLjE1cmVtICFpbXBvcnRhbnQ7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYnMtYm9keS1iZyk7XG5cbiAgICAmLmhhcy1zdWNjZXNzIHtcbiAgICAgICAgY29sb3I6IHZhcigtLWFydGVtaXMtYWxlcnQtc3VjY2Vzcy1jb2xvcik7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWFydGVtaXMtYWxlcnQtc3VjY2Vzcy1iYWNrZ3JvdW5kKTtcbiAgICB9XG5cbiAgICAmLmhhcy13YXJuaW5nIHtcbiAgICAgICAgY29sb3I6IHZhcigtLWFydGVtaXMtYWxlcnQtd2FybmluZy1jb2xvcik7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWFydGVtaXMtYWxlcnQtd2FybmluZy1iYWNrZ3JvdW5kKTtcbiAgICB9XG5cbiAgICAmLmhhcy1lcnJvciB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWFydGVtaXMtYWxlcnQtZGFuZ2VyLWJhY2tncm91bmQpO1xuXG4gICAgICAgIC50ZWFtLW5hbWUge1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLWFydGVtaXMtYWxlcnQtZGFuZ2VyLWNvbG9yKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnNvdXJjZS10ZWFtcy1sZWdlbmQtY29udGFpbmVyIHtcbiAgICBtYXJnaW4tbGVmdDogY2FsYygzMHB4ICsgMS41cmVtKTtcbiAgICBvcGFjaXR5OiAwLjQ7XG4gICAgdHJhbnNpdGlvbjogMC4ycyBlYXNlLW91dCBvcGFjaXR5O1xuXG4gICAgJjpob3ZlciB7XG4gICAgICAgIG9wYWNpdHk6IDE7XG4gICAgICAgIHRyYW5zaXRpb246IDAuMXMgZWFzZS1pbiBvcGFjaXR5O1xuICAgICAgICB0cmFuc2l0aW9uLWRlbGF5OiAwLjJzO1xuICAgIH1cbn1cblxuLnNvdXJjZS10ZWFtcy1sZWdlbmQtYm94IHtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDEwMCwgMjIwLCAwLjA0KTtcbiAgICBwYWRkaW5nOiAxMnB4IDE1cHggMDtcbiAgICBib3JkZXItcmFkaXVzOiAwLjJyZW07XG4gICAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgwLCAwLCAwLCAwLjA3NSk7XG59XG5cbi5zb3VyY2UtdGVhbXMtbGVnZW5kIHtcbiAgICBjdXJzb3I6IGRlZmF1bHQ7XG4gICAgZm9udC1zaXplOiAxMi41cHg7XG5cbiAgICAmID4gKiB7XG4gICAgICAgIGZsZXgtZ3JvdzogMTtcblxuICAgICAgICAmOm5vdCg6Zmlyc3QtY2hpbGQpIHtcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAyNXB4O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmxpc3QtZ3JvdXAtaXRlbS0tdGVhbXMge1xuICAgICAgICAkbGVnZW5kLWZvbnQtc2l6ZTogMTFweDtcblxuICAgICAgICBwYWRkaW5nOiAwIDAuNXJlbTtcbiAgICAgICAgZm9udC1zaXplOiAkbGVnZW5kLWZvbnQtc2l6ZTtcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgwLCAwLCAwLCAwLjEyNSk7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDAuMTVyZW07XG5cbiAgICAgICAgLnRlYW0tbmFtZSB7XG4gICAgICAgICAgICB3aWR0aDogdW5zZXQ7XG4gICAgICAgIH1cblxuICAgICAgICAudGVhbS1zdHVkZW50cyB7XG4gICAgICAgICAgICBmb250LXNpemU6ICRsZWdlbmQtZm9udC1zaXplO1xuXG4gICAgICAgICAgICAuc3R1ZGVudC1ncm91cC1pdGVtIHtcbiAgICAgICAgICAgICAgICBwYWRkaW5nLXRvcDogMDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5sYWJlbC13aXRoLXRvb2x0aXAge1xuICAgICAgICBtYXJnaW4tdG9wOiAzcHg7XG5cbiAgICAgICAgbGFiZWwge1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLXNlY29uZGFyeSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi50ZWFtLW5hbWUge1xuICAgIHdpZHRoOiAxMzVweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDE1cHg7XG4gICAgZmxleC1zaHJpbms6IDA7XG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xufVxuXG4udGVhbS1zdHVkZW50cyB7XG4gICAgZmxleC1ncm93OiAxO1xuICAgIG92ZXJmbG93LXg6IGhpZGRlbjtcbiAgICBmb250LXNpemU6IDEyLjVweDtcbn1cblxuLmxhYmVsLW5hcnJvdyB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIG1hcmdpbi1ib3R0b206IDAuMXJlbTtcbn1cblxuLnJhZGlvLWlucHV0LXdpdGgtZXhwbGFuYXRpb24ge1xuICAgIGhlaWdodDogMC45cmVtICogMS41O1xufVxuXG4ucmFkaW8tbGFiZWwtd2l0aC1leHBsYW5hdGlvbiB7XG4gICAgLmJhZGdlIHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB0b3A6IC0xcHg7XG4gICAgICAgIGZvbnQtc2l6ZTogODUlO1xuICAgIH1cblxuICAgIC5leHBsYW5hdGlvbiB7XG4gICAgICAgIG1heC13aWR0aDogNjYlO1xuICAgIH1cbn1cblxuLm1vZGFsLWZvb3RlciB7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXG4gICAgYnV0dG9uW2Rpc2FibGVkXSB7XG4gICAgICAgIGN1cnNvcjogbm90LWFsbG93ZWQ7XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBO0FBQ0ksV0FBQTs7QUFHSixDQUFBO0FBQ0ksWUFBQTtBQUNBLE9BQUE7O0FBR0osQ0FBQTtBQUNJLFlBQUE7QUFDQSxPQUFBO0FBQ0EsZUFBQTtBQUNBLGFBQUE7QUFDQSxlQUFBOztBQUdKLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUEsSUFBQSxLQUFBLEVBQUEsTUFBQSxFQUFBO0FBQ0EsY0FBQTs7QUFFQSxDQUpKLGtCQUlJLENBQUE7QUFDSSxZQUFBO0FBQ0EsaUJBQUE7O0FBR0osQ0FUSixrQkFTSSxDQUFBO0FBQ0ksYUFBQTtBQUNBLGNBQUE7QUFDQSxlQUFBO0FBQ0EsZ0JBQUE7QUFDQSxhQUFBO0FBQ0EsZUFBQTs7QUFJUixDQUFBO0FBQ0ksV0FBQTtBQUNBLGVBQUE7QUFFQSxhQUFBO0FBQ0EsY0FBQTtBQUNBLFdBQUEsT0FBQTtBQUNBLGlCQUFBO0FBQ0Esb0JBQUEsSUFBQTs7QUFFQSxDQVZKLHNCQVVJLENBQUE7QUFDSSxTQUFBLElBQUE7QUFDQSxvQkFBQSxJQUFBOztBQUdKLENBZkosc0JBZUksQ0FBQTtBQUNJLFNBQUEsSUFBQTtBQUNBLG9CQUFBLElBQUE7O0FBR0osQ0FwQkosc0JBb0JJLENBQUE7QUFDSSxvQkFBQSxJQUFBOztBQUVBLENBdkJSLHNCQXVCUSxDQUhKLFVBR0ksQ0FBQTtBQUNJLFNBQUEsSUFBQTs7QUFLWixDQUFBO0FBQ0ksZUFBQSxLQUFBLEtBQUEsRUFBQTtBQUNBLFdBQUE7QUFDQSxjQUFBLEtBQUEsU0FBQTs7QUFFQSxDQUxKLDZCQUtJO0FBQ0ksV0FBQTtBQUNBLGNBQUEsS0FBQSxRQUFBO0FBQ0Esb0JBQUE7O0FBSVIsQ0FBQTtBQUNJLGNBQUEsS0FBQSxDQUFBLEVBQUEsR0FBQSxFQUFBLEdBQUEsRUFBQTtBQUNBLFdBQUEsS0FBQSxLQUFBO0FBQ0EsaUJBQUE7QUFDQSxVQUFBLElBQUEsTUFBQSxLQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBOztBQUdKLENBQUE7QUFDSSxVQUFBO0FBQ0EsYUFBQTs7QUFFQSxDQUpKLG9CQUlJLEVBQUE7QUFDSSxhQUFBOztBQUVBLENBUFIsb0JBT1EsRUFBQSxDQUFBLEtBQUE7QUFDSSxlQUFBOztBQUlSLENBWkosb0JBWUksQ0E1REo7QUErRFEsV0FBQSxFQUFBO0FBQ0EsYUFIbUI7QUFJbkIsVUFBQSxJQUFBLE1BQUEsS0FBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQTtBQUNBLGlCQUFBOztBQUVBLENBcEJSLG9CQW9CUSxDQXBFUix1QkFvRVEsQ0E3Q0E7QUE4Q0ksU0FBQTs7QUFHSixDQXhCUixvQkF3QlEsQ0F4RVIsdUJBd0VRLENBQUE7QUFDSSxhQVplOztBQWNmLENBM0JaLG9CQTJCWSxDQTNFWix1QkEyRVksQ0FISixjQUdJLENBQUE7QUFDSSxlQUFBO0FBQ0Esa0JBQUE7O0FBS1osQ0FsQ0osb0JBa0NJLENBQUE7QUFDSSxjQUFBOztBQUVBLENBckNSLG9CQXFDUSxDQUhKLG1CQUdJO0FBQ0ksU0FBQSxJQUFBOztBQUtaLENBcEVRO0FBcUVKLFNBQUE7QUFDQSxnQkFBQTtBQUNBLGVBQUE7QUFDQSxlQUFBO0FBQ0EsWUFBQTtBQUNBLGlCQUFBOztBQUdKLENBNUJRO0FBNkJKLGFBQUE7QUFDQSxjQUFBO0FBQ0EsYUFBQTs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLGlCQUFBOztBQUdKLENBQUE7QUFDSSxVQUFBOztBQUlBLENBQUEsNkJBQUEsQ0FBQTtBQUNJLFlBQUE7QUFDQSxPQUFBO0FBQ0EsYUFBQTs7QUFHSixDQU5BLDZCQU1BLENBQUE7QUFDSSxhQUFBOztBQUlSLENBQUE7QUFDSSxtQkFBQTs7QUFFQSxDQUhKLGFBR0ksTUFBQSxDQUFBO0FBQ0ksVUFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i07.\u0275setClassDebugInfo(TeamsImportDialogComponent, { className: "TeamsImportDialogComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/teams-import-dialog/teams-import-button.component.ts
import { Component as Component8, EventEmitter as EventEmitter6, Input as Input7, Output as Output6 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgbModal as NgbModal3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { faPlus as faPlus2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i08 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
var TeamsImportButtonComponent;
var init_teams_import_button_component = __esm({
  "src/main/webapp/app/exercises/shared/team/teams-import-dialog/teams-import-button.component.ts"() {
    init_exercise_model();
    init_button_component();
    init_teams_import_dialog_component();
    init_button_component();
    TeamsImportButtonComponent = class _TeamsImportButtonComponent {
      modalService;
      ButtonType = ButtonType;
      ButtonSize = ButtonSize;
      exercise;
      teams;
      buttonSize = ButtonSize.SMALL;
      save = new EventEmitter6();
      faPlus = faPlus2;
      constructor(modalService) {
        this.modalService = modalService;
      }
      openTeamsImportDialog(event) {
        event.stopPropagation();
        const modalRef = this.modalService.open(TeamsImportDialogComponent, { keyboard: true, size: "lg", backdrop: "static" });
        modalRef.componentInstance.exercise = this.exercise;
        modalRef.componentInstance.teams = this.teams;
        modalRef.result.then((teams) => this.save.emit(teams), () => {
        });
      }
      static \u0275fac = function TeamsImportButtonComponent_Factory(t) {
        return new (t || _TeamsImportButtonComponent)(i08.\u0275\u0275directiveInject(i13.NgbModal));
      };
      static \u0275cmp = i08.\u0275\u0275defineComponent({ type: _TeamsImportButtonComponent, selectors: [["jhi-teams-import-button"]], inputs: { exercise: "exercise", teams: "teams", buttonSize: "buttonSize" }, outputs: { save: "save" }, decls: 3, vars: 4, consts: [[3, "btnType", "btnSize", "icon", "title", "onClick"]], template: function TeamsImportButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          i08.\u0275\u0275text(0, "\n        ");
          i08.\u0275\u0275elementStart(1, "jhi-button", 0);
          i08.\u0275\u0275listener("onClick", function TeamsImportButtonComponent_Template_jhi_button_onClick_1_listener($event) {
            return ctx.openTeamsImportDialog($event);
          });
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(2, "\n    ");
        }
        if (rf & 2) {
          i08.\u0275\u0275advance(1);
          i08.\u0275\u0275property("btnType", ctx.ButtonType.PRIMARY)("btnSize", ctx.buttonSize)("icon", ctx.faPlus)("title", "artemisApp.team.importTeams.buttonLabel");
        }
      }, dependencies: [ButtonComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassDebugInfo(TeamsImportButtonComponent, { className: "TeamsImportButtonComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/teams-import-dialog/teams-export-button.component.ts
import { Component as Component9, Input as Input8 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faFileExport } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i09 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var TeamsExportButtonComponent;
var init_teams_export_button_component = __esm({
  "src/main/webapp/app/exercises/shared/team/teams-import-dialog/teams-export-button.component.ts"() {
    init_button_component();
    init_alert_service();
    init_team_service();
    init_team_service();
    init_alert_service();
    init_button_component();
    TeamsExportButtonComponent = class _TeamsExportButtonComponent {
      teamService;
      alertService;
      ButtonType = ButtonType;
      ButtonSize = ButtonSize;
      teams;
      buttonSize = ButtonSize.SMALL;
      faFileExport = faFileExport;
      constructor(teamService, alertService) {
        this.teamService = teamService;
        this.alertService = alertService;
      }
      exportTeams(event) {
        event.stopPropagation();
        this.teamService.exportTeams(this.teams);
      }
      static \u0275fac = function TeamsExportButtonComponent_Factory(t) {
        return new (t || _TeamsExportButtonComponent)(i09.\u0275\u0275directiveInject(TeamService), i09.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i09.\u0275\u0275defineComponent({ type: _TeamsExportButtonComponent, selectors: [["jhi-teams-export-button"]], inputs: { teams: "teams", buttonSize: "buttonSize" }, decls: 3, vars: 4, consts: [[3, "btnType", "btnSize", "icon", "title", "onClick"]], template: function TeamsExportButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          i09.\u0275\u0275text(0, "\n        ");
          i09.\u0275\u0275elementStart(1, "jhi-button", 0);
          i09.\u0275\u0275listener("onClick", function TeamsExportButtonComponent_Template_jhi_button_onClick_1_listener($event) {
            return ctx.exportTeams($event);
          });
          i09.\u0275\u0275elementEnd();
          i09.\u0275\u0275text(2, "\n    ");
        }
        if (rf & 2) {
          i09.\u0275\u0275advance(1);
          i09.\u0275\u0275property("btnType", ctx.ButtonType.PRIMARY)("btnSize", ctx.buttonSize)("icon", ctx.faFileExport)("title", "artemisApp.team.exportTeams.buttonLabel");
        }
      }, dependencies: [ButtonComponent], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i09.\u0275setClassDebugInfo(TeamsExportButtonComponent, { className: "TeamsExportButtonComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/team-update-dialog/team-delete-button.component.ts
import { Component as Component10, EventEmitter as EventEmitter7, Input as Input9, Output as Output7 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject as Subject5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { faTrashAlt as faTrashAlt2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i010 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i34 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function TeamDeleteButtonComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = i010.\u0275\u0275getCurrentView();
    i010.\u0275\u0275text(0, "\n            ");
    i010.\u0275\u0275elementStart(1, "button", 0);
    i010.\u0275\u0275listener("delete", function TeamDeleteButtonComponent_Conditional_1_Template_button_delete_1_listener() {
      i010.\u0275\u0275restoreView(_r2);
      const ctx_r1 = i010.\u0275\u0275nextContext();
      return i010.\u0275\u0275resetView(ctx_r1.removeTeam());
    });
    i010.\u0275\u0275text(2, "\n                ");
    i010.\u0275\u0275element(3, "fa-icon", 1);
    i010.\u0275\u0275text(4, "\n            ");
    i010.\u0275\u0275elementEnd();
    i010.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i010.\u0275\u0275nextContext();
    i010.\u0275\u0275advance(1);
    i010.\u0275\u0275property("buttonSize", ctx_r0.buttonSize)("entityTitle", ctx_r0.team.shortName || "")("dialogError", ctx_r0.dialogError$);
    i010.\u0275\u0275advance(2);
    i010.\u0275\u0275property("icon", ctx_r0.faTrashAlt);
  }
}
var TeamDeleteButtonComponent;
var init_team_delete_button_component = __esm({
  "src/main/webapp/app/exercises/shared/team/team-update-dialog/team-delete-button.component.ts"() {
    init_team_model();
    init_button_component();
    init_team_service();
    init_exercise_model();
    init_alert_service();
    init_alert_service();
    init_team_service();
    init_delete_button_directive();
    TeamDeleteButtonComponent = class _TeamDeleteButtonComponent {
      alertService;
      teamService;
      ButtonType = ButtonType;
      ButtonSize = ButtonSize;
      team;
      exercise;
      buttonSize = ButtonSize.SMALL;
      delete = new EventEmitter7();
      dialogErrorSource = new Subject5();
      dialogError$ = this.dialogErrorSource.asObservable();
      faTrashAlt = faTrashAlt2;
      constructor(alertService, teamService) {
        this.alertService = alertService;
        this.teamService = teamService;
      }
      ngOnDestroy() {
        this.dialogErrorSource.unsubscribe();
      }
      removeTeam = () => {
        this.teamService.delete(this.exercise, this.team.id).subscribe({
          next: () => {
            this.delete.emit(this.team);
            this.dialogErrorSource.next("");
          },
          error: () => this.alertService.error("artemisApp.team.removeTeam.error")
        });
      };
      static \u0275fac = function TeamDeleteButtonComponent_Factory(t) {
        return new (t || _TeamDeleteButtonComponent)(i010.\u0275\u0275directiveInject(AlertService), i010.\u0275\u0275directiveInject(TeamService));
      };
      static \u0275cmp = i010.\u0275\u0275defineComponent({ type: _TeamDeleteButtonComponent, selectors: [["jhi-team-delete-button"]], inputs: { team: "team", exercise: "exercise", buttonSize: "buttonSize" }, outputs: { delete: "delete" }, decls: 2, vars: 1, consts: [["jhiDeleteButton", "", "deleteQuestion", "artemisApp.team.delete.question", "deleteConfirmationText", "artemisApp.team.delete.typeNameToConfirm", 3, "buttonSize", "entityTitle", "dialogError", "delete"], [1, "me-1", 3, "icon"]], template: function TeamDeleteButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          i010.\u0275\u0275text(0, "\n        ");
          i010.\u0275\u0275template(1, TeamDeleteButtonComponent_Conditional_1_Template, 6, 4);
        }
        if (rf & 2) {
          i010.\u0275\u0275advance(1);
          i010.\u0275\u0275conditional(1, ctx.exercise.isAtLeastInstructor ? 1 : -1);
        }
      }, dependencies: [i34.FaIconComponent, DeleteButtonDirective], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i010.\u0275setClassDebugInfo(TeamDeleteButtonComponent, { className: "TeamDeleteButtonComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/team/teams.component.ts
import { Component as Component11 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute, Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { Subject as Subject6 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i011 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i14 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i8 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i9 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i11 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@flaviosantoro92_ngx-datatable.js?v=1d0d9ead";
function TeamsComponent_Conditional_39_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                ");
    i011.\u0275\u0275element(1, "jhi-teams-export-button", 12);
    i011.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r0 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("teams", ctx_r0.teams)("buttonSize", ctx_r0.ButtonSize.MEDIUM);
  }
}
function TeamsComponent_Conditional_40_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i011.\u0275\u0275getCurrentView();
    i011.\u0275\u0275text(0, "\n                ");
    i011.\u0275\u0275elementStart(1, "jhi-teams-import-button", 13);
    i011.\u0275\u0275listener("save", function TeamsComponent_Conditional_40_Template_jhi_teams_import_button_save_1_listener($event) {
      i011.\u0275\u0275restoreView(_r4);
      const ctx_r3 = i011.\u0275\u0275nextContext();
      return i011.\u0275\u0275resetView(ctx_r3.onTeamsImport($event));
    });
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r1 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("exercise", ctx_r1.exercise)("teams", ctx_r1.teams)("buttonSize", ctx_r1.ButtonSize.MEDIUM);
  }
}
function TeamsComponent_ng_template_47_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = i011.\u0275\u0275getCurrentView();
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275elementStart(1, "span", 23);
    i011.\u0275\u0275listener("click", function TeamsComponent_ng_template_47_ng_template_5_Template_span_click_1_listener() {
      i011.\u0275\u0275restoreView(_r20);
      const controls_r6 = i011.\u0275\u0275nextContext().controls;
      return i011.\u0275\u0275resetView(controls_r6.onSort("id"));
    });
    i011.\u0275\u0275text(2, "\n                            ");
    i011.\u0275\u0275elementStart(3, "span", 24);
    i011.\u0275\u0275text(4, " ID ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(5, "\n                            ");
    i011.\u0275\u0275element(6, "fa-icon", 25);
    i011.\u0275\u0275text(7, "\n                        ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r6 = i011.\u0275\u0275nextContext().controls;
    i011.\u0275\u0275advance(6);
    i011.\u0275\u0275property("icon", controls_r6.iconForSortPropField("id"));
  }
}
function TeamsComponent_ng_template_47_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275elementStart(1, "a", 26);
    i011.\u0275\u0275text(2);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r22 = ctx.value;
    const ctx_r8 = i011.\u0275\u0275nextContext(2);
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("routerLink", i011.\u0275\u0275pureFunction3(2, _c06, ctx_r8.exercise == null ? null : ctx_r8.exercise.course == null ? null : ctx_r8.exercise.course.id, ctx_r8.exercise == null ? null : ctx_r8.exercise.id, value_r22));
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275textInterpolate1("\n                            ", value_r22, "\n                        ");
  }
}
function TeamsComponent_ng_template_47_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r25 = i011.\u0275\u0275getCurrentView();
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275elementStart(1, "span", 23);
    i011.\u0275\u0275listener("click", function TeamsComponent_ng_template_47_ng_template_12_Template_span_click_1_listener() {
      i011.\u0275\u0275restoreView(_r25);
      const controls_r6 = i011.\u0275\u0275nextContext().controls;
      return i011.\u0275\u0275resetView(controls_r6.onSort("name"));
    });
    i011.\u0275\u0275text(2, "\n                            ");
    i011.\u0275\u0275elementStart(3, "span", 27);
    i011.\u0275\u0275text(4, " Name ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(5, "\n                            ");
    i011.\u0275\u0275element(6, "fa-icon", 25);
    i011.\u0275\u0275text(7, "\n                        ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r6 = i011.\u0275\u0275nextContext().controls;
    i011.\u0275\u0275advance(6);
    i011.\u0275\u0275property("icon", controls_r6.iconForSortPropField("name"));
  }
}
function TeamsComponent_ng_template_47_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275elementStart(1, "span");
    i011.\u0275\u0275text(2);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r27 = ctx.value;
    i011.\u0275\u0275advance(2);
    i011.\u0275\u0275textInterpolate(value_r27);
  }
}
function TeamsComponent_ng_template_47_ng_template_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r30 = i011.\u0275\u0275getCurrentView();
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275elementStart(1, "span", 23);
    i011.\u0275\u0275listener("click", function TeamsComponent_ng_template_47_ng_template_19_Template_span_click_1_listener() {
      i011.\u0275\u0275restoreView(_r30);
      const controls_r6 = i011.\u0275\u0275nextContext().controls;
      return i011.\u0275\u0275resetView(controls_r6.onSort("shortName"));
    });
    i011.\u0275\u0275text(2, "\n                            ");
    i011.\u0275\u0275elementStart(3, "span", 28);
    i011.\u0275\u0275text(4, " Short Name ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(5, "\n                            ");
    i011.\u0275\u0275element(6, "fa-icon", 25);
    i011.\u0275\u0275text(7, "\n                        ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r6 = i011.\u0275\u0275nextContext().controls;
    i011.\u0275\u0275advance(6);
    i011.\u0275\u0275property("icon", controls_r6.iconForSortPropField("shortName"));
  }
}
function TeamsComponent_ng_template_47_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275elementStart(1, "a", 26);
    i011.\u0275\u0275text(2);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r32 = ctx.row;
    const ctx_r12 = i011.\u0275\u0275nextContext(2);
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("routerLink", i011.\u0275\u0275pureFunction3(2, _c06, ctx_r12.exercise == null ? null : ctx_r12.exercise.course == null ? null : ctx_r12.exercise.course.id, ctx_r12.exercise == null ? null : ctx_r12.exercise.id, value_r32.id));
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275textInterpolate1("\n                            ", value_r32.shortName, "\n                        ");
  }
}
function TeamsComponent_ng_template_47_ng_template_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r35 = i011.\u0275\u0275getCurrentView();
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275elementStart(1, "span", 23);
    i011.\u0275\u0275listener("click", function TeamsComponent_ng_template_47_ng_template_26_Template_span_click_1_listener() {
      i011.\u0275\u0275restoreView(_r35);
      const controls_r6 = i011.\u0275\u0275nextContext().controls;
      return i011.\u0275\u0275resetView(controls_r6.onSort("owner.name"));
    });
    i011.\u0275\u0275text(2, "\n                            ");
    i011.\u0275\u0275elementStart(3, "span", 29);
    i011.\u0275\u0275text(4, " Tutor ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(5, "\n                            ");
    i011.\u0275\u0275element(6, "fa-icon", 25);
    i011.\u0275\u0275text(7, "\n                        ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r6 = i011.\u0275\u0275nextContext().controls;
    i011.\u0275\u0275advance(6);
    i011.\u0275\u0275property("icon", controls_r6.iconForSortPropField("owner.name"));
  }
}
function TeamsComponent_ng_template_47_ng_template_28_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                            ");
    i011.\u0275\u0275elementStart(1, "a", 26);
    i011.\u0275\u0275text(2);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const value_r37 = i011.\u0275\u0275nextContext().value;
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("routerLink", i011.\u0275\u0275pureFunction1(2, _c13, value_r37 == null ? null : value_r37.login));
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275textInterpolate1(" ", value_r37 == null ? null : value_r37.name, "");
  }
}
function TeamsComponent_ng_template_47_ng_template_28_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                            ");
    i011.\u0275\u0275elementStart(1, "a", 30);
    i011.\u0275\u0275text(2);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const value_r37 = i011.\u0275\u0275nextContext().value;
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("href", "mailto:" + (value_r37 == null ? null : value_r37.email), i011.\u0275\u0275sanitizeUrl);
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275textInterpolate(value_r37 == null ? null : value_r37.name);
  }
}
function TeamsComponent_ng_template_47_ng_template_28_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                            ");
    i011.\u0275\u0275elementStart(1, "span", 31);
    i011.\u0275\u0275text(2, "No tutor");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(3, "\n                        ");
  }
}
function TeamsComponent_ng_template_47_ng_template_28_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275template(1, TeamsComponent_ng_template_47_ng_template_28_Conditional_1_Template, 4, 4)(2, TeamsComponent_ng_template_47_ng_template_28_Conditional_2_Template, 4, 2)(3, TeamsComponent_ng_template_47_ng_template_28_Conditional_3_Template, 4, 0);
  }
  if (rf & 2) {
    const value_r37 = ctx.value;
    const ctx_r14 = i011.\u0275\u0275nextContext(2);
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275conditional(1, ctx_r14.isAdmin ? 1 : -1);
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275conditional(2, !ctx_r14.isAdmin && value_r37 ? 2 : -1);
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275conditional(3, !ctx_r14.isAdmin && !value_r37 ? 3 : -1);
  }
}
function TeamsComponent_ng_template_47_ng_template_33_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275elementStart(1, "span", 32);
    i011.\u0275\u0275text(2, "\n                            ");
    i011.\u0275\u0275elementStart(3, "span", 33);
    i011.\u0275\u0275text(4, " Students ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(5, "\n                        ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(6, "\n                    ");
  }
}
function TeamsComponent_ng_template_47_ng_template_35_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275element(1, "jhi-team-students-list", 34);
    i011.\u0275\u0275text(2, "\n                    ");
  }
  if (rf & 2) {
    const value_r43 = ctx.value;
    const ctx_r16 = i011.\u0275\u0275nextContext(2);
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("students", value_r43)("renderLinks", ctx_r16.isAdmin);
  }
}
function TeamsComponent_ng_template_47_ng_template_40_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r48 = i011.\u0275\u0275getCurrentView();
    i011.\u0275\u0275text(0, "\n                                ");
    i011.\u0275\u0275elementStart(1, "jhi-team-update-button", 36);
    i011.\u0275\u0275listener("save", function TeamsComponent_ng_template_47_ng_template_40_Conditional_3_Template_jhi_team_update_button_save_1_listener($event) {
      i011.\u0275\u0275restoreView(_r48);
      const ctx_r47 = i011.\u0275\u0275nextContext(3);
      return i011.\u0275\u0275resetView(ctx_r47.onTeamUpdate($event));
    });
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(2, "\n                            ");
  }
  if (rf & 2) {
    const value_r44 = i011.\u0275\u0275nextContext().row;
    const ctx_r45 = i011.\u0275\u0275nextContext(2);
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("exercise", ctx_r45.exercise)("team", value_r44);
  }
}
function TeamsComponent_ng_template_47_ng_template_40_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r51 = i011.\u0275\u0275getCurrentView();
    i011.\u0275\u0275text(0, "\n                                ");
    i011.\u0275\u0275elementStart(1, "jhi-team-delete-button", 37);
    i011.\u0275\u0275listener("delete", function TeamsComponent_ng_template_47_ng_template_40_Conditional_4_Template_jhi_team_delete_button_delete_1_listener($event) {
      i011.\u0275\u0275restoreView(_r51);
      const ctx_r50 = i011.\u0275\u0275nextContext(3);
      return i011.\u0275\u0275resetView(ctx_r50.onTeamDelete($event));
    });
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(2, "\n                            ");
  }
  if (rf & 2) {
    const value_r44 = i011.\u0275\u0275nextContext().row;
    const ctx_r46 = i011.\u0275\u0275nextContext(2);
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("exercise", ctx_r46.exercise)("team", value_r44);
  }
}
function TeamsComponent_ng_template_47_ng_template_40_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n                        ");
    i011.\u0275\u0275elementStart(1, "div", 35);
    i011.\u0275\u0275text(2, "\n                            ");
    i011.\u0275\u0275template(3, TeamsComponent_ng_template_47_ng_template_40_Conditional_3_Template, 3, 2)(4, TeamsComponent_ng_template_47_ng_template_40_Conditional_4_Template, 3, 2);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const value_r44 = ctx.row;
    const ctx_r17 = i011.\u0275\u0275nextContext(2);
    i011.\u0275\u0275advance(3);
    i011.\u0275\u0275conditional(3, ctx_r17.exercise.isAtLeastInstructor || (value_r44.owner == null ? null : value_r44.owner.id) === ctx_r17.currentUser.id ? 3 : -1);
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275conditional(4, ctx_r17.exercise.isAtLeastInstructor ? 4 : -1);
  }
}
function TeamsComponent_ng_template_47_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n            ");
    i011.\u0275\u0275elementStart(1, "ngx-datatable", 14);
    i011.\u0275\u0275text(2, "\n                ");
    i011.\u0275\u0275elementStart(3, "ngx-datatable-column", 15);
    i011.\u0275\u0275text(4, "\n                    ");
    i011.\u0275\u0275template(5, TeamsComponent_ng_template_47_ng_template_5_Template, 9, 1, "ng-template", 16);
    i011.\u0275\u0275text(6, "\n                    ");
    i011.\u0275\u0275template(7, TeamsComponent_ng_template_47_ng_template_7_Template, 4, 6, "ng-template", 17);
    i011.\u0275\u0275text(8, "\n                ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(9, "\n                ");
    i011.\u0275\u0275elementStart(10, "ngx-datatable-column", 18);
    i011.\u0275\u0275text(11, "\n                    ");
    i011.\u0275\u0275template(12, TeamsComponent_ng_template_47_ng_template_12_Template, 9, 1, "ng-template", 16);
    i011.\u0275\u0275text(13, "\n                    ");
    i011.\u0275\u0275template(14, TeamsComponent_ng_template_47_ng_template_14_Template, 4, 1, "ng-template", 17);
    i011.\u0275\u0275text(15, "\n                ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(16, "\n                ");
    i011.\u0275\u0275elementStart(17, "ngx-datatable-column", 19);
    i011.\u0275\u0275text(18, "\n                    ");
    i011.\u0275\u0275template(19, TeamsComponent_ng_template_47_ng_template_19_Template, 9, 1, "ng-template", 16);
    i011.\u0275\u0275text(20, "\n                    ");
    i011.\u0275\u0275template(21, TeamsComponent_ng_template_47_ng_template_21_Template, 4, 6, "ng-template", 17);
    i011.\u0275\u0275text(22, "\n                ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(23, "\n                ");
    i011.\u0275\u0275elementStart(24, "ngx-datatable-column", 20);
    i011.\u0275\u0275text(25, "\n                    ");
    i011.\u0275\u0275template(26, TeamsComponent_ng_template_47_ng_template_26_Template, 9, 1, "ng-template", 16);
    i011.\u0275\u0275text(27, "\n                    ");
    i011.\u0275\u0275template(28, TeamsComponent_ng_template_47_ng_template_28_Template, 4, 3, "ng-template", 17);
    i011.\u0275\u0275text(29, "\n                ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(30, "\n                ");
    i011.\u0275\u0275elementStart(31, "ngx-datatable-column", 21);
    i011.\u0275\u0275text(32, "\n                    ");
    i011.\u0275\u0275template(33, TeamsComponent_ng_template_47_ng_template_33_Template, 7, 0, "ng-template", 16);
    i011.\u0275\u0275text(34, "\n                    ");
    i011.\u0275\u0275template(35, TeamsComponent_ng_template_47_ng_template_35_Template, 3, 2, "ng-template", 17);
    i011.\u0275\u0275text(36, "\n                ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(37, "\n                ");
    i011.\u0275\u0275elementStart(38, "ngx-datatable-column", 22);
    i011.\u0275\u0275text(39, "\n                    ");
    i011.\u0275\u0275template(40, TeamsComponent_ng_template_47_ng_template_40_Template, 6, 2, "ng-template", 17);
    i011.\u0275\u0275text(41, "\n                ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(42, "\n            ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(43, "\n        ");
  }
  if (rf & 2) {
    const settings_r5 = ctx.settings;
    i011.\u0275\u0275advance(1);
    i011.\u0275\u0275property("limit", settings_r5.limit)("sortType", settings_r5.sortType)("columnMode", settings_r5.columnMode)("headerHeight", settings_r5.headerHeight)("footerHeight", settings_r5.footerHeight)("rowHeight", settings_r5.rowHeight)("rows", settings_r5.rows)("rowClass", settings_r5.rowClass)("scrollbarH", settings_r5.scrollbarH);
    i011.\u0275\u0275advance(2);
    i011.\u0275\u0275property("minWidth", 60)("width", 60)("maxWidth", 60);
    i011.\u0275\u0275advance(7);
    i011.\u0275\u0275property("minWidth", 100)("width", 120)("maxWidth", 160);
    i011.\u0275\u0275advance(7);
    i011.\u0275\u0275property("minWidth", 100)("width", 120)("maxWidth", 160);
    i011.\u0275\u0275advance(7);
    i011.\u0275\u0275property("minWidth", 140)("width", 160);
    i011.\u0275\u0275advance(7);
    i011.\u0275\u0275property("minWidth", 200)("width", 600);
    i011.\u0275\u0275advance(7);
    i011.\u0275\u0275property("minWidth", 220)("width", 220)("maxWidth", 220);
  }
}
var _c06, _c13, _c23, FilterProp, TeamsComponent;
var init_teams_component = __esm({
  "src/main/webapp/app/exercises/shared/team/teams.component.ts"() {
    init_participation_service();
    init_team_service();
    init_button_component();
    init_exercise_service();
    init_team_utils();
    init_account_service();
    init_alert_service();
    init_event_manager_service();
    init_participation_service();
    init_alert_service();
    init_event_manager_service();
    init_exercise_service();
    init_team_service();
    init_account_service();
    init_translate_directive();
    init_data_table_component();
    init_team_students_list_component();
    init_team_update_button_component();
    init_teams_import_button_component();
    init_teams_export_button_component();
    init_team_delete_button_component();
    init_artemis_translate_pipe();
    _c06 = (a1, a3, a5) => ["/course-management", a1, "exercises", a3, "teams", a5];
    _c13 = (a2) => ["/admin", "user-management", a2];
    _c23 = () => ["name", "shortName", "students.name", "students.login", "owner.name", "owner.login"];
    (function(FilterProp2) {
      FilterProp2["ALL"] = "all";
      FilterProp2["OWN"] = "own";
    })(FilterProp || (FilterProp = {}));
    TeamsComponent = class _TeamsComponent {
      route;
      router;
      participationService;
      alertService;
      eventManager;
      exerciseService;
      teamService;
      accountService;
      FilterProp = FilterProp;
      ButtonSize = ButtonSize;
      teams = [];
      teamCriteria = { filterProp: FilterProp.ALL };
      filteredTeamsSize = 0;
      exercise;
      dialogErrorSource = new Subject6();
      dialogError$ = this.dialogErrorSource.asObservable();
      isLoading;
      currentUser;
      isAdmin = false;
      constructor(route, router, participationService, alertService, eventManager, exerciseService, teamService, accountService) {
        this.route = route;
        this.router = router;
        this.participationService = participationService;
        this.alertService = alertService;
        this.eventManager = eventManager;
        this.exerciseService = exerciseService;
        this.teamService = teamService;
        this.accountService = accountService;
        this.accountService.identity().then((user) => {
          this.currentUser = user;
          this.isAdmin = this.accountService.isAdmin();
        });
      }
      ngOnInit() {
        this.initTeamFilter();
        this.loadAll();
      }
      ngOnDestroy() {
        this.dialogErrorSource.unsubscribe();
      }
      loadAll() {
        this.route.params.subscribe((params) => {
          this.isLoading = true;
          this.exerciseService.find(params["exerciseId"]).subscribe((exerciseResponse) => {
            this.exercise = exerciseResponse.body;
            const teamOwnerId = this.teamCriteria.filterProp === FilterProp.OWN ? this.currentUser.id : void 0;
            this.teamService.findAllByExerciseId(params["exerciseId"], teamOwnerId).subscribe((teamsResponse) => {
              this.teams = teamsResponse.body;
              this.isLoading = false;
            });
          });
        });
      }
      initTeamFilter() {
        switch (this.route.snapshot.queryParamMap.get("filter")) {
          case FilterProp.OWN:
            this.teamCriteria.filterProp = FilterProp.OWN;
            break;
          default:
            this.teamCriteria.filterProp = FilterProp.ALL;
            break;
        }
      }
      updateTeamFilter(filter3) {
        this.teamCriteria.filterProp = filter3;
        this.router.navigate([], { relativeTo: this.route, queryParams: { filter: filter3 }, queryParamsHandling: "merge", replaceUrl: true });
        this.loadAll();
      }
      onTeamUpdate(team) {
        this.upsertTeam(team);
      }
      onTeamDelete(team) {
        this.deleteTeam(team);
      }
      onTeamsImport(teams) {
        this.teams = teams;
      }
      handleTeamsSizeChange = (filteredTeamsSize) => {
        this.filteredTeamsSize = filteredTeamsSize;
      };
      searchResultFormatter = formatTeamAsSearchResult;
      searchTextFromTeam = (team) => {
        return team.shortName;
      };
      upsertTeam(team) {
        const index = this.teams.findIndex((t) => t.id === team.id);
        if (index === -1) {
          this.teams = [...this.teams, team];
        } else {
          this.teams = Object.assign([], this.teams, { [index]: team });
        }
      }
      deleteTeam(team) {
        this.teams = this.teams.filter((t) => t.id !== team.id);
      }
      static \u0275fac = function TeamsComponent_Factory(t) {
        return new (t || _TeamsComponent)(i011.\u0275\u0275directiveInject(i14.ActivatedRoute), i011.\u0275\u0275directiveInject(i14.Router), i011.\u0275\u0275directiveInject(ParticipationService), i011.\u0275\u0275directiveInject(AlertService), i011.\u0275\u0275directiveInject(EventManager), i011.\u0275\u0275directiveInject(ExerciseService), i011.\u0275\u0275directiveInject(TeamService), i011.\u0275\u0275directiveInject(AccountService));
      };
      static \u0275cmp = i011.\u0275\u0275defineComponent({ type: _TeamsComponent, selectors: [["jhi-teams"]], decls: 51, vars: 22, consts: [[1, "d-flex"], [1, "mb-3"], [1, "mb-1"], ["jhiTranslate", "artemisApp.team.home.title"], [1, "d-flex", "align-items-center"], [1, "radio-inline", "mb-0", "d-flex", "align-items-center"], ["type", "radio", 3, "ngModel", "value", "click"], [1, "ms-1"], [1, "radio-inline", "ms-2", "mb-0", "d-flex", "align-items-center"], [1, "d-flex", "ms-auto"], [3, "exercise", "buttonSize", "save"], ["entityType", "team", "entitiesPerPageTranslation", "artemisApp.exercise.resultsPerPage", "showAllEntitiesTranslation", "artemisApp.exercise.showAllResults", "searchPlaceholderTranslation", "artemisApp.exercise.searchForTeams", 3, "isLoading", "allEntities", "searchFields", "searchTextFromEntity", "searchResultFormatter", "entitiesSizeChange"], [1, "me-2", 3, "teams", "buttonSize"], [1, "me-2", 3, "exercise", "teams", "buttonSize", "save"], [1, "bootstrap", 3, "limit", "sortType", "columnMode", "headerHeight", "footerHeight", "rowHeight", "rows", "rowClass", "scrollbarH"], ["prop", "id", 3, "minWidth", "width", "maxWidth"], ["ngx-datatable-header-template", ""], ["ngx-datatable-cell-template", ""], ["prop", "name", 3, "minWidth", "width", "maxWidth"], [3, "minWidth", "width", "maxWidth"], ["prop", "owner", 3, "minWidth", "width"], ["prop", "students", 3, "minWidth", "width"], ["prop", "", 3, "minWidth", "width", "maxWidth"], [1, "datatable-header-cell-wrapper", 3, "click"], ["jhiTranslate", "global.field.id", 1, "datatable-header-cell-label", "bold", "sortable"], [3, "icon"], [3, "routerLink"], ["jhiTranslate", "artemisApp.team.name.label", 1, "datatable-header-cell-label", "bold", "sortable"], ["jhiTranslate", "artemisApp.team.shortName.label", 1, "datatable-header-cell-label", "bold", "sortable"], ["jhiTranslate", "artemisApp.team.tutor", 1, "datatable-header-cell-label", "bold", "sortable"], [3, "href"], ["jhiTranslate", "artemisApp.team.detail.noOwner", 1, "font-weight-bold"], [1, "datatable-header-cell-wrapper", 2, "cursor", "text"], ["jhiTranslate", "artemisApp.team.students", 1, "datatable-header-cell-label", "bold"], [3, "students", "renderLinks"], [1, "w-100", "text-end"], [3, "exercise", "team", "save"], [1, "ms-1", 3, "exercise", "team", "delete"]], template: function TeamsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i011.\u0275\u0275elementStart(0, "div");
          i011.\u0275\u0275text(1, "\n    ");
          i011.\u0275\u0275elementStart(2, "div", 0);
          i011.\u0275\u0275text(3, "\n        ");
          i011.\u0275\u0275elementStart(4, "div", 1);
          i011.\u0275\u0275text(5, "\n            ");
          i011.\u0275\u0275elementStart(6, "h2", 2);
          i011.\u0275\u0275text(7, "\n                ");
          i011.\u0275\u0275elementStart(8, "span");
          i011.\u0275\u0275text(9);
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(10);
          i011.\u0275\u0275elementStart(11, "span", 3);
          i011.\u0275\u0275text(12, "Teams");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(13, "\n            ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(14, "\n            ");
          i011.\u0275\u0275elementStart(15, "div", 4);
          i011.\u0275\u0275text(16, "\n                ");
          i011.\u0275\u0275elementStart(17, "label", 5);
          i011.\u0275\u0275text(18, "\n                    ");
          i011.\u0275\u0275elementStart(19, "input", 6);
          i011.\u0275\u0275listener("click", function TeamsComponent_Template_input_click_19_listener() {
            return ctx.updateTeamFilter(ctx.FilterProp.ALL);
          });
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(20, "\n                    ");
          i011.\u0275\u0275elementStart(21, "span", 7);
          i011.\u0275\u0275text(22);
          i011.\u0275\u0275pipe(23, "artemisTranslate");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(24, "\n                ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(25, "\n                ");
          i011.\u0275\u0275elementStart(26, "label", 8);
          i011.\u0275\u0275text(27, "\n                    ");
          i011.\u0275\u0275elementStart(28, "input", 6);
          i011.\u0275\u0275listener("click", function TeamsComponent_Template_input_click_28_listener() {
            return ctx.updateTeamFilter(ctx.FilterProp.OWN);
          });
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(29, "\n                    ");
          i011.\u0275\u0275elementStart(30, "span", 7);
          i011.\u0275\u0275text(31);
          i011.\u0275\u0275pipe(32, "artemisTranslate");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(33, "\n                ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(34, "\n            ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(35, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(36, "\n        ");
          i011.\u0275\u0275elementStart(37, "div", 9);
          i011.\u0275\u0275text(38, "\n            ");
          i011.\u0275\u0275template(39, TeamsComponent_Conditional_39_Template, 3, 2)(40, TeamsComponent_Conditional_40_Template, 3, 3);
          i011.\u0275\u0275elementStart(41, "jhi-team-update-button", 10);
          i011.\u0275\u0275listener("save", function TeamsComponent_Template_jhi_team_update_button_save_41_listener($event) {
            return ctx.onTeamUpdate($event);
          });
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(42, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(43, "\n    ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(44, "\n    ");
          i011.\u0275\u0275elementStart(45, "jhi-data-table", 11);
          i011.\u0275\u0275listener("entitiesSizeChange", function TeamsComponent_Template_jhi_data_table_entitiesSizeChange_45_listener($event) {
            return ctx.handleTeamsSizeChange($event);
          });
          i011.\u0275\u0275text(46, "\n        ");
          i011.\u0275\u0275template(47, TeamsComponent_ng_template_47_Template, 44, 25, "ng-template");
          i011.\u0275\u0275text(48, "\n    ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(49, "\n");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(50, "\n");
        }
        if (rf & 2) {
          i011.\u0275\u0275advance(9);
          i011.\u0275\u0275textInterpolate1("", ctx.exercise == null ? null : ctx.exercise.title, " - ");
          i011.\u0275\u0275advance(1);
          i011.\u0275\u0275textInterpolate1("", ctx.filteredTeamsSize, " ");
          i011.\u0275\u0275advance(9);
          i011.\u0275\u0275property("ngModel", ctx.teamCriteria.filterProp)("value", ctx.FilterProp.ALL);
          i011.\u0275\u0275advance(3);
          i011.\u0275\u0275textInterpolate(i011.\u0275\u0275pipeBind1(23, 17, "artemisApp.team.filters.all"));
          i011.\u0275\u0275advance(6);
          i011.\u0275\u0275property("ngModel", ctx.teamCriteria.filterProp)("value", ctx.FilterProp.OWN);
          i011.\u0275\u0275advance(3);
          i011.\u0275\u0275textInterpolate(i011.\u0275\u0275pipeBind1(32, 19, "artemisApp.team.filters.own"));
          i011.\u0275\u0275advance(8);
          i011.\u0275\u0275conditional(39, (ctx.exercise == null ? null : ctx.exercise.isAtLeastEditor) && ctx.teams && ctx.teams.length > 0 ? 39 : -1);
          i011.\u0275\u0275advance(1);
          i011.\u0275\u0275conditional(40, (ctx.exercise == null ? null : ctx.exercise.isAtLeastEditor) ? 40 : -1);
          i011.\u0275\u0275advance(1);
          i011.\u0275\u0275property("exercise", ctx.exercise)("buttonSize", ctx.ButtonSize.MEDIUM);
          i011.\u0275\u0275advance(4);
          i011.\u0275\u0275property("isLoading", ctx.isLoading)("allEntities", ctx.teams)("searchFields", i011.\u0275\u0275pureFunction0(21, _c23))("searchTextFromEntity", ctx.searchTextFromTeam)("searchResultFormatter", ctx.searchResultFormatter);
        }
      }, dependencies: [i14.RouterLink, i8.DefaultValueAccessor, i8.RadioControlValueAccessor, i8.NgControlStatus, i8.NgModel, i9.FaIconComponent, TranslateDirective, i11.DatatableComponent, i11.DataTableColumnDirective, i11.DataTableColumnHeaderDirective, i11.DataTableColumnCellDirective, DataTableComponent, TeamStudentsListComponent, TeamUpdateButtonComponent, TeamsImportButtonComponent, TeamsExportButtonComponent, TeamDeleteButtonComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i011.\u0275setClassDebugInfo(TeamsComponent, { className: "TeamsComponent" });
    })();
  }
});

export {
  init_team_model,
  init_team_student_search_component,
  init_team_owner_search_component,
  init_team_update_dialog_component,
  TeamUpdateButtonComponent,
  init_team_update_button_component,
  init_team_exercise_search_component,
  init_teams_import_from_file_form_component,
  init_teams_import_dialog_component,
  init_teams_import_button_component,
  init_teams_export_button_component,
  TeamDeleteButtonComponent,
  init_team_delete_button_component,
  FilterProp,
  TeamsComponent,
  init_teams_component
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvdGVhbS5tb2RlbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0tc3R1ZGVudC1zZWFyY2gvdGVhbS1zdHVkZW50LXNlYXJjaC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtLXN0dWRlbnQtc2VhcmNoL3RlYW0tc3R1ZGVudC1zZWFyY2guY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtLW93bmVyLXNlYXJjaC90ZWFtLW93bmVyLXNlYXJjaC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtLW93bmVyLXNlYXJjaC90ZWFtLW93bmVyLXNlYXJjaC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0tdXBkYXRlLWRpYWxvZy90ZWFtLXVwZGF0ZS1kaWFsb2cuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbS11cGRhdGUtZGlhbG9nL3RlYW0tdXBkYXRlLWRpYWxvZy5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0tdXBkYXRlLWRpYWxvZy90ZWFtLXVwZGF0ZS1idXR0b24uY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbS1leGVyY2lzZS1zZWFyY2gvdGVhbS1leGVyY2lzZS1zZWFyY2guY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbS1leGVyY2lzZS1zZWFyY2gvdGVhbS1leGVyY2lzZS1zZWFyY2guY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtcy1pbXBvcnQtZGlhbG9nL3RlYW1zLWltcG9ydC1mcm9tLWZpbGUtZm9ybS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtcy1pbXBvcnQtZGlhbG9nL3RlYW1zLWltcG9ydC1mcm9tLWZpbGUtZm9ybS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW1zLWltcG9ydC1kaWFsb2cvdGVhbXMtaW1wb3J0LWRpYWxvZy5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtcy1pbXBvcnQtZGlhbG9nL3RlYW1zLWltcG9ydC1kaWFsb2cuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtcy1pbXBvcnQtZGlhbG9nL3RlYW1zLWltcG9ydC1idXR0b24uY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbXMtaW1wb3J0LWRpYWxvZy90ZWFtcy1leHBvcnQtYnV0dG9uLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0tdXBkYXRlLWRpYWxvZy90ZWFtLWRlbGV0ZS1idXR0b24uY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbXMuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbXMuY29tcG9uZW50Lmh0bWwiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgVXNlciB9IGZyb20gJ2FwcC9jb3JlL3VzZXIvdXNlci5tb2RlbCc7XG5pbXBvcnQgeyBTdHVkZW50UGFydGljaXBhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9wYXJ0aWNpcGF0aW9uL3N0dWRlbnQtcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBCYXNlRW50aXR5IH0gZnJvbSAnYXBwL3NoYXJlZC9tb2RlbC9iYXNlLWVudGl0eSc7XG5pbXBvcnQgZGF5anMgZnJvbSAnZGF5anMvZXNtJztcblxuZXhwb3J0IGVudW0gVGVhbUltcG9ydFN0cmF0ZWd5VHlwZSB7XG4gICAgUFVSR0VfRVhJU1RJTkcgPSAnUFVSR0VfRVhJU1RJTkcnLFxuICAgIENSRUFURV9PTkxZID0gJ0NSRUFURV9PTkxZJyxcbn1cblxuZXhwb3J0IGNsYXNzIE9ubGluZVRlYW1TdHVkZW50IHtcbiAgICBwdWJsaWMgbG9naW46IHN0cmluZztcbiAgICBwdWJsaWMgbGFzdFR5cGluZ0RhdGU6IGRheWpzLkRheWpzO1xuICAgIHB1YmxpYyBsYXN0QWN0aW9uRGF0ZTogZGF5anMuRGF5anM7XG59XG5cbmV4cG9ydCBjbGFzcyBUZWFtQXNzaWdubWVudFBheWxvYWQge1xuICAgIHB1YmxpYyBleGVyY2lzZUlkOiBudW1iZXI7XG4gICAgcHVibGljIHRlYW1JZD86IG51bWJlcjtcbiAgICBwdWJsaWMgc3R1ZGVudFBhcnRpY2lwYXRpb25zOiBTdHVkZW50UGFydGljaXBhdGlvbltdO1xufVxuXG5leHBvcnQgY2xhc3MgVGVhbSBpbXBsZW1lbnRzIEJhc2VFbnRpdHkge1xuICAgIHB1YmxpYyBpZD86IG51bWJlcjtcbiAgICBwdWJsaWMgbmFtZT86IHN0cmluZztcbiAgICBwdWJsaWMgc2hvcnROYW1lPzogc3RyaW5nO1xuICAgIHB1YmxpYyBpbWFnZT86IHN0cmluZztcbiAgICBwdWJsaWMgc3R1ZGVudHM/OiBVc2VyW107XG4gICAgcHVibGljIG93bmVyPzogVXNlcjtcblxuICAgIHB1YmxpYyBjcmVhdGVkQnk/OiBzdHJpbmc7XG4gICAgcHVibGljIGNyZWF0ZWREYXRlPzogZGF5anMuRGF5anM7XG4gICAgcHVibGljIGxhc3RNb2RpZmllZEJ5Pzogc3RyaW5nO1xuICAgIHB1YmxpYyBsYXN0TW9kaWZpZWREYXRlPzogZGF5anMuRGF5anM7XG5cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5zdHVkZW50cyA9IFtdOyAvLyBkZWZhdWx0IHZhbHVlXG4gICAgfVxufVxuXG4vKipcbiAqIFRoaXMgY2xhc3MgaXMgdXNlZCBmb3IgaW1wb3J0aW5nIHRlYW1zIGZyb20gYSBmaWxlXG4gKiBFaXRoZXIgcmVnaXN0cmF0aW9uIG51bWJlciBvciBsb2dpbiBtdXN0IGJlIHNldFxuICogQWRkaXRpb25hbGx5IHN0dWRlbnQgaGFzIHRlYW1OYW1lIHRvIGlkZW50aWZ5IHdoaWNoIHRlYW0gaGUvc2hlIGJlbG9uZ3MgdG9cbiAqL1xuZXhwb3J0IGNsYXNzIFN0dWRlbnRXaXRoVGVhbSB7XG4gICAgcHVibGljIGZpcnN0TmFtZT86IHN0cmluZztcbiAgICBwdWJsaWMgbGFzdE5hbWU/OiBzdHJpbmc7XG4gICAgcHVibGljIHJlZ2lzdHJhdGlvbk51bWJlcj86IHN0cmluZztcbiAgICBwdWJsaWMgdGVhbU5hbWU6IHN0cmluZztcbiAgICBwdWJsaWMgdXNlcm5hbWU/OiBzdHJpbmc7XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEVsZW1lbnRSZWYsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE91dHB1dCwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBjb21iaW5lTGF0ZXN0LCBvZiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgVXNlciB9IGZyb20gJ2FwcC9jb3JlL3VzZXIvdXNlci5tb2RlbCc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBkZWJvdW5jZVRpbWUsIGRpc3RpbmN0VW50aWxDaGFuZ2VkLCBtYXAsIHN3aXRjaE1hcCwgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgZ2V0IH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IENvdXJzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb3Vyc2UubW9kZWwnO1xuaW1wb3J0IHsgRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgVGVhbVNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0uc2VydmljZSc7XG5pbXBvcnQgeyBUZWFtU2VhcmNoVXNlciB9IGZyb20gJ2FwcC9lbnRpdGllcy90ZWFtLXNlYXJjaC11c2VyLm1vZGVsJztcbmltcG9ydCB7IFRlYW0gfSBmcm9tICdhcHAvZW50aXRpZXMvdGVhbS5tb2RlbCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXRlYW0tc3R1ZGVudC1zZWFyY2gnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi90ZWFtLXN0dWRlbnQtc2VhcmNoLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgVGVhbVN0dWRlbnRTZWFyY2hDb21wb25lbnQge1xuICAgIEBWaWV3Q2hpbGQoJ25nYlR5cGVhaGVhZCcsIHsgc3RhdGljOiBmYWxzZSB9KSBuZ2JUeXBlYWhlYWQ6IEVsZW1lbnRSZWY7XG5cbiAgICBASW5wdXQoKSBjb3Vyc2U6IENvdXJzZTtcbiAgICBASW5wdXQoKSBleGVyY2lzZTogRXhlcmNpc2U7XG4gICAgQElucHV0KCkgdGVhbTogVGVhbTtcbiAgICBASW5wdXQoKSBzdHVkZW50c0Zyb21QZW5kaW5nVGVhbTogVXNlcltdID0gW107XG5cbiAgICBAT3V0cHV0KCkgc2VsZWN0U3R1ZGVudCA9IG5ldyBFdmVudEVtaXR0ZXI8VXNlcj4oKTtcbiAgICBAT3V0cHV0KCkgc2VhcmNoaW5nID0gbmV3IEV2ZW50RW1pdHRlcjxib29sZWFuPigpO1xuICAgIEBPdXRwdXQoKSBzZWFyY2hRdWVyeVRvb1Nob3J0ID0gbmV3IEV2ZW50RW1pdHRlcjxib29sZWFuPigpO1xuICAgIEBPdXRwdXQoKSBzZWFyY2hGYWlsZWQgPSBuZXcgRXZlbnRFbWl0dGVyPGJvb2xlYW4+KCk7XG4gICAgQE91dHB1dCgpIHNlYXJjaE5vUmVzdWx0cyA9IG5ldyBFdmVudEVtaXR0ZXI8c3RyaW5nIHwgdW5kZWZpbmVkPigpO1xuXG4gICAgaW5wdXREaXNwbGF5VmFsdWU6IHN0cmluZztcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgdGVhbVNlcnZpY2U6IFRlYW1TZXJ2aWNlKSB7fVxuXG4gICAgb25BdXRvY29tcGxldGVTZWxlY3QgPSAoc3R1ZGVudDogVXNlcikgPT4ge1xuICAgICAgICB0aGlzLmlucHV0RGlzcGxheVZhbHVlID0gJyc7XG4gICAgICAgIHRoaXMuc2VsZWN0U3R1ZGVudC5lbWl0KHN0dWRlbnQpO1xuICAgIH07XG5cbiAgICBzZWFyY2hJbnB1dEZvcm1hdHRlciA9ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXREaXNwbGF5VmFsdWU7XG4gICAgfTtcblxuICAgIHNlYXJjaFJlc3VsdEZvcm1hdHRlciA9IChzdHVkZW50OiBVc2VyKSA9PiB7XG4gICAgICAgIGNvbnN0IHsgbG9naW4sIG5hbWUgfSA9IHN0dWRlbnQ7XG4gICAgICAgIHJldHVybiBgJHtuYW1lfSAoJHtsb2dpbn0pYDtcbiAgICB9O1xuXG4gICAgb25TZWFyY2ggPSAodGV4dCQ6IE9ic2VydmFibGU8c3RyaW5nPikgPT4ge1xuICAgICAgICByZXR1cm4gdGV4dCQucGlwZShcbiAgICAgICAgICAgIGRlYm91bmNlVGltZSgyMDApLFxuICAgICAgICAgICAgZGlzdGluY3RVbnRpbENoYW5nZWQoKSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZWFyY2hRdWVyeVRvb1Nob3J0LmVtaXQoZmFsc2UpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoRmFpbGVkLmVtaXQoZmFsc2UpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoTm9SZXN1bHRzLmVtaXQodW5kZWZpbmVkKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKCgpID0+IHRoaXMuc2VhcmNoaW5nLmVtaXQodHJ1ZSkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKChsb2dpbk9yTmFtZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChsb2dpbk9yTmFtZS5sZW5ndGggPCAzKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoUXVlcnlUb29TaG9ydC5lbWl0KHRydWUpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY29tYmluZUxhdGVzdChbb2YobG9naW5Pck5hbWUpLCBvZih1bmRlZmluZWQpXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBjb21iaW5lTGF0ZXN0KFtcbiAgICAgICAgICAgICAgICAgICAgb2YobG9naW5Pck5hbWUpLFxuICAgICAgICAgICAgICAgICAgICB0aGlzLnRlYW1TZXJ2aWNlXG4gICAgICAgICAgICAgICAgICAgICAgICAuc2VhcmNoSW5Db3Vyc2VGb3JFeGVyY2lzZVRlYW0odGhpcy5jb3Vyc2UsIHRoaXMuZXhlcmNpc2UsIGxvZ2luT3JOYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgLnBpcGUobWFwKCh1c2Vyc1Jlc3BvbnNlKSA9PiB1c2Vyc1Jlc3BvbnNlLmJvZHkhKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhdGNoRXJyb3IoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNlYXJjaEZhaWxlZC5lbWl0KHRydWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gb2YodW5kZWZpbmVkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgXSk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiB0aGlzLnNlYXJjaGluZy5lbWl0KGZhbHNlKSksXG4gICAgICAgICAgICB0YXAoKFtsb2dpbk9yTmFtZSwgdXNlcnNdKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gXCJRdWVyeSB0b28gc2hvcnRcIiAobm8gcmVxdWVzdCBwZXJmb3JtZWQpIG9yIFwiU2VhcmNoIHJlcXVlc3QgZmFpbGVkXCIgPT4ge3VzZXJzfSB3aWxsIGJlIHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgIC8vIFwiU3VjY2Vzc2Z1bCBzZWFyY2ggcmVxdWVzdFwiID0+IHt1c2Vyc30gd2lsbCBiZSBhbiBhcnJheSAobGVuZ3RoIDAgaWYgbm8gc3R1ZGVudHMgd2VyZSBmb3VuZClcbiAgICAgICAgICAgICAgICBpZiAodXNlcnMgJiYgdXNlcnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoTm9SZXN1bHRzLmVtaXQobG9naW5Pck5hbWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgbWFwKChbLCB1c2Vyc10pID0+IHVzZXJzIHx8IFtdKSxcbiAgICAgICAgICAgIHRhcCgodXNlcnMpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLnR5cGVhaGVhZEJ1dHRvbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy51c2VyQ2FuQmVBZGRlZFRvUGVuZGluZ1RlYW0odXNlcnNbaV0pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy50eXBlYWhlYWRCdXR0b25zW2ldLnNldEF0dHJpYnV0ZSgnZGlzYWJsZWQnLCAnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH07XG5cbiAgICBwcml2YXRlIHVzZXJDYW5CZUFkZGVkVG9QZW5kaW5nVGVhbSh1c2VyOiBUZWFtU2VhcmNoVXNlcik6IGJvb2xlYW4ge1xuICAgICAgICBpZiAodGhpcy5zdHVkZW50c0Zyb21QZW5kaW5nVGVhbS5tYXAoKHMpID0+IHMuaWQpLmluY2x1ZGVzKHVzZXIuaWQpKSB7XG4gICAgICAgICAgICAvLyBJZiBhIHN0dWRlbnQgaXMgYWxyZWFkeSBwYXJ0IG9mIHRoZSBwZW5kaW5nIHRlYW0sIHRoZXkgY2Fubm90ICghKSBiZSBhZGRlZCBhZ2FpblxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9IGVsc2UgaWYgKCF1c2VyLmFzc2lnbmVkVGVhbUlkKSB7XG4gICAgICAgICAgICAvLyBJZiBhIHN0dWRlbnQgaXMgbm90IHlldCBhc3NpZ25lZCB0byBhbnkgdGVhbSwgdGhleSBjYW4gYmUgYWRkZWRcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9IGVsc2UgaWYgKCF0aGlzLnRlYW0uaWQpIHtcbiAgICAgICAgICAgIC8vIElmIGEgc3R1ZGVudCBpcyBhc3NpZ25lZCB0byBhbiBleGlzdGluZyB0ZWFtIGJ1dCB0aGlzIHRlYW0gaXMganVzdCBiZWluZyBjcmVhdGVkLCB0aGV5IGNhbm5vdCAoISkgYmUgYWRkZWRcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBJZiBhIHN0dWRlbnQgaXMgYXNzaWduZWQgdG8gYSB0ZWFtLCB0aGV5IGNhbiBvbmx5IGJlIGFkZGVkIGlmIHRoZXkgYXJlIGFzc2lnbmVkIHRvIHRoaXMgdGVhbSBpdHNlbGZcbiAgICAgICAgLy8gVGhpcyBjYW4gaGFwcGVuIGlmIHRoZXkgd2VyZSByZW1vdmVkIGZyb20gdGhlIHBlbmRpbmcgdGVhbSBhbmQgYXJlIHRoZW4gYWRkZWQgYmFjayBhZ2FpblxuICAgICAgICByZXR1cm4gdXNlci5hc3NpZ25lZFRlYW1JZCA9PT0gdGhpcy50ZWFtLmlkO1xuICAgIH1cblxuICAgIHByaXZhdGUgZ2V0IHR5cGVhaGVhZEJ1dHRvbnMoKSB7XG4gICAgICAgIHJldHVybiBnZXQodGhpcy5uZ2JUeXBlYWhlYWQsICduYXRpdmVFbGVtZW50Lm5leHRTaWJsaW5nLmNoaWxkcmVuJywgW10pO1xuICAgIH1cbn1cbiIsIjxpbnB1dFxuICAgICNuZ2JUeXBlYWhlYWRcbiAgICBpZD1cInN0dWRlbnQtc2VhcmNoLWlucHV0XCJcbiAgICB0eXBlPVwidGV4dFwiXG4gICAgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIlxuICAgIFtwbGFjZWhvbGRlcl09XCInYXJ0ZW1pc0FwcC50ZWFtLmFkZFN0dWRlbnRUb1RlYW0nIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiXG4gICAgKHNlbGVjdEl0ZW0pPVwib25BdXRvY29tcGxldGVTZWxlY3QoJGV2ZW50Lml0ZW0pXCJcbiAgICBbbmdiVHlwZWFoZWFkXT1cIm9uU2VhcmNoXCJcbiAgICBbcmVzdWx0Rm9ybWF0dGVyXT1cInNlYXJjaFJlc3VsdEZvcm1hdHRlclwiXG4gICAgW2lucHV0Rm9ybWF0dGVyXT1cInNlYXJjaElucHV0Rm9ybWF0dGVyXCJcbi8+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0LCBWaWV3Q2hpbGQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE9ic2VydmFibGUsIFN1YmplY3QsIGNvbWJpbmVMYXRlc3QsIG1lcmdlLCBvZiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgVXNlciB9IGZyb20gJ2FwcC9jb3JlL3VzZXIvdXNlci5tb2RlbCc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBmaWx0ZXIsIG1hcCwgc3dpdGNoTWFwLCB0YXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBDb3Vyc2UsIENvdXJzZUdyb3VwIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvdXJzZS5tb2RlbCc7XG5pbXBvcnQgeyBFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBUZWFtIH0gZnJvbSAnYXBwL2VudGl0aWVzL3RlYW0ubW9kZWwnO1xuaW1wb3J0IHsgQ291cnNlTWFuYWdlbWVudFNlcnZpY2UgfSBmcm9tICdhcHAvY291cnNlL21hbmFnZS9jb3Vyc2UtbWFuYWdlbWVudC5zZXJ2aWNlJztcbmltcG9ydCB7IGNsb25lRGVlcCB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBOZ2JUeXBlYWhlYWQgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXRlYW0tb3duZXItc2VhcmNoJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vdGVhbS1vd25lci1zZWFyY2guY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBUZWFtT3duZXJTZWFyY2hDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEBWaWV3Q2hpbGQoJ2luc3RhbmNlJywgeyBzdGF0aWM6IHRydWUgfSkgbmdiVHlwZWFoZWFkOiBOZ2JUeXBlYWhlYWQ7XG4gICAgZm9jdXMgPSBuZXcgU3ViamVjdDxzdHJpbmc+KCk7XG4gICAgY2xpY2sgPSBuZXcgU3ViamVjdDxzdHJpbmc+KCk7XG5cbiAgICBASW5wdXQoKSBpbnB1dERpc2FibGVkOiBib29sZWFuO1xuXG4gICAgQElucHV0KCkgY291cnNlOiBDb3Vyc2U7XG4gICAgQElucHV0KCkgZXhlcmNpc2U6IEV4ZXJjaXNlO1xuICAgIEBJbnB1dCgpIHRlYW06IFRlYW07XG5cbiAgICBAT3V0cHV0KCkgc2VsZWN0T3duZXIgPSBuZXcgRXZlbnRFbWl0dGVyPFVzZXI+KCk7XG4gICAgQE91dHB1dCgpIHNlYXJjaGluZyA9IG5ldyBFdmVudEVtaXR0ZXI8Ym9vbGVhbj4oKTtcbiAgICBAT3V0cHV0KCkgc2VhcmNoUXVlcnlUb29TaG9ydCA9IG5ldyBFdmVudEVtaXR0ZXI8Ym9vbGVhbj4oKTtcbiAgICBAT3V0cHV0KCkgc2VhcmNoRmFpbGVkID0gbmV3IEV2ZW50RW1pdHRlcjxib29sZWFuPigpO1xuICAgIEBPdXRwdXQoKSBzZWFyY2hOb1Jlc3VsdHMgPSBuZXcgRXZlbnRFbWl0dGVyPHN0cmluZyB8IHVuZGVmaW5lZD4oKTtcblxuICAgIG93bmVyOiBVc2VyO1xuICAgIG93bmVyT3B0aW9uczogVXNlcltdID0gW107XG4gICAgb3duZXJPcHRpb25zTG9hZGVkID0gZmFsc2U7XG5cbiAgICBpbnB1dERpc3BsYXlWYWx1ZTogc3RyaW5nO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBjb3Vyc2VTZXJ2aWNlOiBDb3Vyc2VNYW5hZ2VtZW50U2VydmljZSkge31cblxuICAgIC8qKlxuICAgICAqIExpZmUgY3ljbGUgaG9vayB0byBpbmRpY2F0ZSBjb21wb25lbnQgY3JlYXRpb24gaXMgZG9uZVxuICAgICAqL1xuICAgIG5nT25Jbml0KCkge1xuICAgICAgICBpZiAodGhpcy50ZWFtLm93bmVyKSB7XG4gICAgICAgICAgICB0aGlzLm93bmVyID0gY2xvbmVEZWVwKHRoaXMudGVhbS5vd25lcik7XG4gICAgICAgICAgICB0aGlzLmlucHV0RGlzcGxheVZhbHVlID0gdGhpcy5zZWFyY2hSZXN1bHRGb3JtYXR0ZXIodGhpcy5vd25lcik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBvbkF1dG9jb21wbGV0ZVNlbGVjdCA9IChvd25lcjogVXNlcikgPT4ge1xuICAgICAgICB0aGlzLmlucHV0RGlzcGxheVZhbHVlID0gdGhpcy5zZWFyY2hSZXN1bHRGb3JtYXR0ZXIob3duZXIpO1xuICAgICAgICB0aGlzLnNlbGVjdE93bmVyLmVtaXQob3duZXIpO1xuICAgIH07XG5cbiAgICBzZWFyY2hJbnB1dEZvcm1hdHRlciA9ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXREaXNwbGF5VmFsdWU7XG4gICAgfTtcblxuICAgIHNlYXJjaFJlc3VsdEZvcm1hdHRlciA9IChvd25lcjogVXNlcik6IHN0cmluZyA9PiB7XG4gICAgICAgIGNvbnN0IHsgbG9naW4sIG5hbWUgfSA9IG93bmVyO1xuICAgICAgICByZXR1cm4gYCR7bmFtZX0gKCR7bG9naW59KWA7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIGEgZ2l2ZW4gbG9naW4vbmFtZSBpcyBpbmNsdWRlZCBpbiBhIGdpdmVuIHVzZXJcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gbG9naW5Pck5hbWUgLSBsb2dpbi9uYW1lIHRvIHNlYXJjaCBmb3JcbiAgICAgKiBAcGFyYW0ge1VzZXJ9IHVzZXIgLSBVc2VyIHRvIHNlYXJjaCB0aHJvdWdoXG4gICAgICovXG4gICAgc2VhcmNoTWF0Y2hlc1VzZXIobG9naW5Pck5hbWU6IHN0cmluZywgdXNlcjogVXNlcikge1xuICAgICAgICByZXR1cm4gW3VzZXIubG9naW4sIHVzZXIubmFtZV0uc29tZSgoZmllbGQpID0+IHtcbiAgICAgICAgICAgIHJldHVybiAoZmllbGQgfHwgJycpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMobG9naW5Pck5hbWUudG9Mb3dlckNhc2UoKSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIG9uU2VhcmNoID0gKHRleHQkOiBPYnNlcnZhYmxlPHN0cmluZz4pID0+IHtcbiAgICAgICAgY29uc3QgY2xpY2tzV2l0aENsb3NlZFBvcHVwJCA9IHRoaXMuY2xpY2sucGlwZShmaWx0ZXIoKCkgPT4gIXRoaXMubmdiVHlwZWFoZWFkLmlzUG9wdXBPcGVuKCkpKTtcbiAgICAgICAgY29uc3QgaW5wdXRGb2N1cyQgPSB0aGlzLmZvY3VzO1xuXG4gICAgICAgIHJldHVybiBtZXJnZSh0ZXh0JCwgaW5wdXRGb2N1cyQsIGNsaWNrc1dpdGhDbG9zZWRQb3B1cCQpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoTm9SZXN1bHRzLmVtaXQodW5kZWZpbmVkKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgc3dpdGNoTWFwKChsb2dpbk9yTmFtZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoRmFpbGVkLmVtaXQoZmFsc2UpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoaW5nLmVtaXQodHJ1ZSk7XG4gICAgICAgICAgICAgICAgLy8gSWYgb3duZXIgb3B0aW9ucyBoYXZlIGFscmVhZHkgYmVlbiBsb2FkZWQgb25jZSwgZG8gbm90IGxvYWQgdGhlbSBhZ2FpbiBhbmQgcmV1c2UgdGhlIGFscmVhZHkgbG9hZGVkIG9uZXNcbiAgICAgICAgICAgICAgICBjb25zdCBvd25lck9wdGlvbnNTb3VyY2UkID0gdGhpcy5vd25lck9wdGlvbnNMb2FkZWQgPyBvZih0aGlzLm93bmVyT3B0aW9ucykgOiB0aGlzLmxvYWRPd25lck9wdGlvbnMoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29tYmluZUxhdGVzdChbb2YobG9naW5Pck5hbWUpLCBvd25lck9wdGlvbnNTb3VyY2UkXSk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgoKSA9PiB0aGlzLnNlYXJjaGluZy5lbWl0KGZhbHNlKSksXG4gICAgICAgICAgICBzd2l0Y2hNYXAoKFtsb2dpbk9yTmFtZSwgb3duZXJPcHRpb25zXSkgPT4ge1xuICAgICAgICAgICAgICAgIC8vIEZpbHRlciBsaXN0IG9mIGFsbCBvd25lciBvcHRpb25zIGJ5IHRoZSBzZWFyY2ggdGVybVxuICAgICAgICAgICAgICAgIGNvbnN0IG1hdGNoID0gKHVzZXI6IFVzZXIpID0+IHRoaXMuc2VhcmNoTWF0Y2hlc1VzZXIobG9naW5Pck5hbWUsIHVzZXIpO1xuICAgICAgICAgICAgICAgIHJldHVybiBjb21iaW5lTGF0ZXN0KFtvZihsb2dpbk9yTmFtZSksIG9mKCFvd25lck9wdGlvbnMgPyBvd25lck9wdGlvbnMgOiBvd25lck9wdGlvbnMuZmlsdGVyKG1hdGNoKSldKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKChbbG9naW5Pck5hbWUsIG93bmVyT3B0aW9uc10pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAob3duZXJPcHRpb25zICYmIG93bmVyT3B0aW9ucy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZWFyY2hOb1Jlc3VsdHMuZW1pdChsb2dpbk9yTmFtZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKFssIG93bmVyT3B0aW9uc10pID0+IG93bmVyT3B0aW9ucyB8fCBbXSksXG4gICAgICAgICk7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIExvYWQgb3B0aW9ucyBvZiB0ZWFtIG93bmVyXG4gICAgICovXG4gICAgbG9hZE93bmVyT3B0aW9ucygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY291cnNlU2VydmljZS5nZXRBbGxVc2Vyc0luQ291cnNlR3JvdXAodGhpcy5jb3Vyc2UuaWQhLCBDb3Vyc2VHcm91cC5UVVRPUlMpLnBpcGUoXG4gICAgICAgICAgICBtYXAoKHVzZXJzUmVzcG9uc2UpID0+IHVzZXJzUmVzcG9uc2UuYm9keSEpLFxuICAgICAgICAgICAgdGFwKChvd25lck9wdGlvbnMpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLm93bmVyT3B0aW9ucyA9IG93bmVyT3B0aW9ucztcbiAgICAgICAgICAgICAgICB0aGlzLm93bmVyT3B0aW9uc0xvYWRlZCA9IHRydWU7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMub3duZXJPcHRpb25zTG9hZGVkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhpcy5zZWFyY2hGYWlsZWQuZW1pdCh0cnVlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gb2YodW5kZWZpbmVkKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cbn1cbiIsIjxpbnB1dFxuICAgICNpbnN0YW5jZT1cIm5nYlR5cGVhaGVhZFwiXG4gICAgaWQ9XCJvd25lci1zZWFyY2gtaW5wdXRcIlxuICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiXG4gICAgW2Rpc2FibGVkXT1cImlucHV0RGlzYWJsZWRcIlxuICAgIFtwbGFjZWhvbGRlcl09XCInYXJ0ZW1pc0FwcC50ZWFtLnNlbGVjdE93bmVyRm9yVGVhbScgfCBhcnRlbWlzVHJhbnNsYXRlXCJcbiAgICBbKG5nTW9kZWwpXT1cIm93bmVyXCJcbiAgICAoc2VsZWN0SXRlbSk9XCJvbkF1dG9jb21wbGV0ZVNlbGVjdCgkZXZlbnQuaXRlbSlcIlxuICAgIChmb2N1cyk9XCJmb2N1cy5uZXh0KCcnKVwiXG4gICAgKGNsaWNrKT1cImNsaWNrLm5leHQoJycpXCJcbiAgICBbbmdiVHlwZWFoZWFkXT1cIm9uU2VhcmNoXCJcbiAgICBbcmVzdWx0Rm9ybWF0dGVyXT1cInNlYXJjaFJlc3VsdEZvcm1hdHRlclwiXG4gICAgW2lucHV0Rm9ybWF0dGVyXT1cInNlYXJjaElucHV0Rm9ybWF0dGVyXCJcbi8+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQsIFZpZXdDaGlsZCwgVmlld0VuY2Fwc3VsYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFic3RyYWN0Q29udHJvbCwgTmdGb3JtIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgTmdiQWN0aXZlTW9kYWwgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgUGFydGljaXBhdGlvblNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9wYXJ0aWNpcGF0aW9uL3BhcnRpY2lwYXRpb24uc2VydmljZSc7XG5pbXBvcnQgeyBUZWFtU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3RlYW0vdGVhbS5zZXJ2aWNlJztcbmltcG9ydCB7IFRlYW0gfSBmcm9tICdhcHAvZW50aXRpZXMvdGVhbS5tb2RlbCc7XG5pbXBvcnQgeyBVc2VyIH0gZnJvbSAnYXBwL2NvcmUvdXNlci91c2VyLm1vZGVsJztcbmltcG9ydCB7IGNsb25lRGVlcCwgaXNFbXB0eSwgb21pdCB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBUZWFtQXNzaWdubWVudENvbmZpZyB9IGZyb20gJ2FwcC9lbnRpdGllcy90ZWFtLWFzc2lnbm1lbnQtY29uZmlnLm1vZGVsJztcbmltcG9ydCB7IGRlYm91bmNlVGltZSwgc3dpdGNoTWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgU0hPUlRfTkFNRV9QQVRURVJOIH0gZnJvbSAnYXBwL3NoYXJlZC9jb25zdGFudHMvaW5wdXQuY29uc3RhbnRzJztcbmltcG9ydCB7IGZhQmFuLCBmYUV4Y2xhbWF0aW9uVHJpYW5nbGUsIGZhU2F2ZSwgZmFTcGlubmVyLCBmYVRyYXNoQWx0IH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcblxuZXhwb3J0IHR5cGUgU3R1ZGVudFRlYW1Db25mbGljdCA9IHsgc3R1ZGVudExvZ2luOiBzdHJpbmc7IHRlYW1JZDogc3RyaW5nIH07XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXRlYW0tdXBkYXRlLWRpYWxvZycsXG4gICAgdGVtcGxhdGVVcmw6ICcuL3RlYW0tdXBkYXRlLWRpYWxvZy5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vdGVhbS11cGRhdGUtZGlhbG9nLmNvbXBvbmVudC5zY3NzJ10sXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcbn0pXG5leHBvcnQgY2xhc3MgVGVhbVVwZGF0ZURpYWxvZ0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgQFZpZXdDaGlsZCgnZWRpdEZvcm0nLCB7IHN0YXRpYzogZmFsc2UgfSkgZWRpdEZvcm06IE5nRm9ybTtcblxuICAgIEBJbnB1dCgpIHRlYW06IFRlYW07XG4gICAgQElucHV0KCkgZXhlcmNpc2U6IEV4ZXJjaXNlO1xuXG4gICAgcGVuZGluZ1RlYW06IFRlYW07XG4gICAgaXNTYXZpbmcgPSBmYWxzZTtcblxuICAgIHNlYXJjaGluZ1N0dWRlbnRzID0gZmFsc2U7XG4gICAgc2VhcmNoaW5nU3R1ZGVudHNRdWVyeVRvb1Nob3J0ID0gZmFsc2U7XG4gICAgc2VhcmNoaW5nU3R1ZGVudHNGYWlsZWQgPSBmYWxzZTtcbiAgICBzZWFyY2hpbmdTdHVkZW50c05vUmVzdWx0c0ZvclF1ZXJ5Pzogc3RyaW5nO1xuXG4gICAgc2VhcmNoaW5nT3duZXIgPSBmYWxzZTtcbiAgICBzZWFyY2hpbmdPd25lclF1ZXJ5VG9vU2hvcnQgPSBmYWxzZTtcbiAgICBzZWFyY2hpbmdPd25lckZhaWxlZCA9IGZhbHNlO1xuICAgIHNlYXJjaGluZ093bmVyTm9SZXN1bHRzRm9yUXVlcnk/OiBzdHJpbmc7XG5cbiAgICBzdHVkZW50VGVhbUNvbmZsaWN0czogU3R1ZGVudFRlYW1Db25mbGljdFtdID0gW107XG4gICAgaWdub3JlVGVhbVNpemVSZWNvbW1lbmRhdGlvbiA9IGZhbHNlO1xuXG4gICAgcHJpdmF0ZSBzaG9ydE5hbWVWYWxpZGF0b3IgPSBuZXcgU3ViamVjdDxzdHJpbmc+KCk7XG4gICAgcmVhZG9ubHkgc2hvcnROYW1lQWxyZWFkeVRha2VuRXJyb3JDb2RlID0gJ2FscmVhZHlUYWtlbic7XG4gICAgcmVhZG9ubHkgc2hvcnROYW1lUGF0dGVybiA9IFNIT1JUX05BTUVfUEFUVEVSTjsgLy8gbXVzdCBzdGFydCB3aXRoIGEgbGV0dGVyIGFuZCBjYW5ub3QgY29udGFpbiBzcGVjaWFsIGNoYXJhY3RlcnNcblxuICAgIC8vIEljb25zXG4gICAgZmFTYXZlID0gZmFTYXZlO1xuICAgIGZhQmFuID0gZmFCYW47XG4gICAgZmFTcGlubmVyID0gZmFTcGlubmVyO1xuICAgIGZhRXhjbGFtYXRpb25UcmlhbmdsZSA9IGZhRXhjbGFtYXRpb25UcmlhbmdsZTtcbiAgICBmYVRyYXNoQWx0ID0gZmFUcmFzaEFsdDtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIHBhcnRpY2lwYXRpb25TZXJ2aWNlOiBQYXJ0aWNpcGF0aW9uU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSB0ZWFtU2VydmljZTogVGVhbVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgYWN0aXZlTW9kYWw6IE5nYkFjdGl2ZU1vZGFsLFxuICAgICkge31cblxuICAgIC8qKlxuICAgICAqIExpZmUgY3ljbGUgaG9vayB0byBpbmRpY2F0ZSBjb21wb25lbnQgY3JlYXRpb24gaXMgZG9uZVxuICAgICAqL1xuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICB0aGlzLmluaXRQZW5kaW5nVGVhbSgpO1xuICAgICAgICB0aGlzLnNob3J0TmFtZVZhbGlkYXRpb24odGhpcy5zaG9ydE5hbWVWYWxpZGF0b3IpO1xuICAgIH1cblxuICAgIHByaXZhdGUgaW5pdFBlbmRpbmdUZWFtKCkge1xuICAgICAgICB0aGlzLnBlbmRpbmdUZWFtID0gY2xvbmVEZWVwKHRoaXMudGVhbSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSG9vayB0byBpbmRpY2F0ZSBhIHNob3J0IHRlYW0gbmFtZSBjaGFuZ2VcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gc2hvcnROYW1lIC0gbmV3IHNob3J0IG5hbWUgb2YgdGhlIHRlYW1cbiAgICAgKi9cbiAgICBvblRlYW1TaG9ydE5hbWVDaGFuZ2VkKHNob3J0TmFtZTogc3RyaW5nKSB7XG4gICAgICAgIC8vIGF1dG9tYXRpY2FsbHkgY29udmVydCBzaG9ydE5hbWUgdG8gbG93ZXJjYXNlIGNoYXJhY3RlcnNcbiAgICAgICAgdGhpcy5wZW5kaW5nVGVhbS5zaG9ydE5hbWUgPSBzaG9ydE5hbWUudG9Mb3dlckNhc2UoKTtcblxuICAgICAgICAvLyBjaGVjayB0aGF0IG5vIG90aGVyIHRlYW0gYWxyZWFkeSB1c2VzIHRoaXMgc2hvcnQgbmFtZVxuICAgICAgICB0aGlzLnNob3J0TmFtZVZhbGlkYXRvci5uZXh0KHRoaXMucGVuZGluZ1RlYW0uc2hvcnROYW1lKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIb29rIHRvIGluZGljYXRlIGEgdGVhbSBuYW1lIGNoYW5nZVxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBuYW1lIC0gbmV3IHRlYW0gbmFtZVxuICAgICAqL1xuICAgIG9uVGVhbU5hbWVDaGFuZ2VkKG5hbWU6IHN0cmluZykge1xuICAgICAgICBpZiAoIXRoaXMuc2hvcnROYW1lUmVhZE9ubHkpIHtcbiAgICAgICAgICAgIC8vIGF1dG9tYXRpY2FsbHkgc2V0IHRoZSBzaG9ydE5hbWUgYmFzZWQgb24gdGhlIG5hbWUgKHN0cmlwcGluZyBhbGwgbm9uLWFscGhhbnVtZXJpYyBjaGFyYWN0ZXJzKVxuICAgICAgICAgICAgY29uc3Qgc2hvcnROYW1lID0gbmFtZS5yZXBsYWNlKC9bXjAtOWEtel0vZ2ksICcnKTtcbiAgICAgICAgICAgIHRoaXMub25UZWFtU2hvcnROYW1lQ2hhbmdlZChzaG9ydE5hbWUpO1xuICAgICAgICAgICAgdGhpcy5zaG9ydE5hbWVDb250cm9sLm1hcmtBc1RvdWNoZWQoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGdldCBzaG9ydE5hbWVSZWFkT25seSgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuICEhdGhpcy5wZW5kaW5nVGVhbS5pZDtcbiAgICB9XG5cbiAgICBnZXQgc2hvcnROYW1lQ29udHJvbCgpOiBBYnN0cmFjdENvbnRyb2wge1xuICAgICAgICByZXR1cm4gdGhpcy5lZGl0Rm9ybS5jb250cm9sLmdldCgnc2hvcnROYW1lJykhO1xuICAgIH1cblxuICAgIGdldCBjb25maWcoKTogVGVhbUFzc2lnbm1lbnRDb25maWcge1xuICAgICAgICByZXR1cm4gdGhpcy5leGVyY2lzZS50ZWFtQXNzaWdubWVudENvbmZpZyE7XG4gICAgfVxuXG4gICAgZ2V0IHNob3dJZ25vcmVUZWFtU2l6ZVJlY29tbWVuZGF0aW9uT3B0aW9uKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gIXRoaXMucmVjb21tZW5kZWRUZWFtU2l6ZTtcbiAgICB9XG5cbiAgICBnZXQgdGVhbVNpemVWaW9sYXRpb25VbmNvbmZpcm1lZCgpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2hvd0lnbm9yZVRlYW1TaXplUmVjb21tZW5kYXRpb25PcHRpb24gJiYgIXRoaXMuaWdub3JlVGVhbVNpemVSZWNvbW1lbmRhdGlvbjtcbiAgICB9XG5cbiAgICBwcml2YXRlIGdldCByZWNvbW1lbmRlZFRlYW1TaXplKCk6IGJvb2xlYW4ge1xuICAgICAgICBjb25zdCBwZW5kaW5nVGVhbVNpemUgPSB0aGlzLnBlbmRpbmdUZWFtLnN0dWRlbnRzIS5sZW5ndGg7XG4gICAgICAgIHJldHVybiBwZW5kaW5nVGVhbVNpemUgPj0gdGhpcy5jb25maWcubWluVGVhbVNpemUhICYmIHBlbmRpbmdUZWFtU2l6ZSA8PSB0aGlzLmNvbmZpZy5tYXhUZWFtU2l6ZSE7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgYSBnaXZlbiB1c2VyIGhhcyBhIGNvbmZsaWN0aW5nIHRlYW1cbiAgICAgKiBAcGFyYW0ge1VzZXJ9IHN0dWRlbnQgLSBVc2VyIHRvIHNlYXJjaCBmb3JcbiAgICAgKi9cbiAgICBoYXNDb25mbGljdGluZ1RlYW0oc3R1ZGVudDogVXNlcik6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5maW5kU3R1ZGVudFRlYW1Db25mbGljdChzdHVkZW50KSAhPT0gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBjb25mbGljdGluZyB0ZWFtIG9mIGEgZ2l2ZW4gdXNlclxuICAgICAqIEBwYXJhbSB7VXNlcn0gc3R1ZGVudCAtIFVzZXIgdG8gc2VhcmNoIGZvclxuICAgICAqL1xuICAgIGdldENvbmZsaWN0aW5nVGVhbShzdHVkZW50OiBVc2VyKSB7XG4gICAgICAgIGNvbnN0IGNvbmZsaWN0ID0gdGhpcy5maW5kU3R1ZGVudFRlYW1Db25mbGljdChzdHVkZW50KTtcbiAgICAgICAgcmV0dXJuIGNvbmZsaWN0ID8gY29uZmxpY3RbJ3RlYW1JZCddIDogdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIHByaXZhdGUgZmluZFN0dWRlbnRUZWFtQ29uZmxpY3Qoc3R1ZGVudDogVXNlcikge1xuICAgICAgICByZXR1cm4gdGhpcy5zdHVkZW50VGVhbUNvbmZsaWN0cy5maW5kKChjb25mbGljdCkgPT4gY29uZmxpY3Quc3R1ZGVudExvZ2luID09PSBzdHVkZW50LmxvZ2luKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHJlc2V0U3R1ZGVudFRlYW1Db25mbGljdChzdHVkZW50OiBVc2VyKSB7XG4gICAgICAgIHJldHVybiAodGhpcy5zdHVkZW50VGVhbUNvbmZsaWN0cyA9IHRoaXMuc3R1ZGVudFRlYW1Db25mbGljdHMuZmlsdGVyKChjb25mbGljdCkgPT4gY29uZmxpY3Quc3R1ZGVudExvZ2luICE9PSBzdHVkZW50LmxvZ2luKSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBpc1N0dWRlbnRBbHJlYWR5SW5QZW5kaW5nVGVhbShzdHVkZW50OiBVc2VyKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLnBlbmRpbmdUZWFtLnN0dWRlbnRzPy5maW5kKChzdHVkKSA9PiBzdHVkLmlkID09PSBzdHVkZW50LmlkKSAhPT0gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEhvb2sgdG8gaW5kaWNhdGUgYSBzdHVkZW50IHdhcyBhZGRlZCB0byBhIHRlYW1cbiAgICAgKiBAcGFyYW0ge1VzZXJ9IHN0dWRlbnQgLSBBZGRlZCB1c2VyXG4gICAgICovXG4gICAgb25BZGRTdHVkZW50KHN0dWRlbnQ6IFVzZXIpIHtcbiAgICAgICAgaWYgKCF0aGlzLmlzU3R1ZGVudEFscmVhZHlJblBlbmRpbmdUZWFtKHN0dWRlbnQpKSB7XG4gICAgICAgICAgICB0aGlzLnBlbmRpbmdUZWFtLnN0dWRlbnRzIS5wdXNoKHN0dWRlbnQpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSG9vayB0byBpbmRpY2F0ZSBhIHN0dWRlbnQgd2FzIHJlbW92ZWQgb2YgYSB0ZWFtXG4gICAgICogQHBhcmFtIHtVc2VyfSBzdHVkZW50IC0gcmVtb3ZlZCB1c2VyXG4gICAgICovXG4gICAgb25SZW1vdmVTdHVkZW50KHN0dWRlbnQ6IFVzZXIpIHtcbiAgICAgICAgdGhpcy5wZW5kaW5nVGVhbS5zdHVkZW50cyA9IHRoaXMucGVuZGluZ1RlYW0uc3R1ZGVudHM/LmZpbHRlcigodXNlcikgPT4gdXNlci5pZCAhPT0gc3R1ZGVudC5pZCk7XG4gICAgICAgIHRoaXMucmVzZXRTdHVkZW50VGVhbUNvbmZsaWN0KHN0dWRlbnQpOyAvLyBjb25mbGljdCBtaWdodCBubyBsb25nZXIgZXhpc3Qgd2hlbiB0aGUgc3R1ZGVudCBpcyBhZGRlZCBhZ2FpblxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEhvb2sgdG8gaW5kaWNhdGUgdGhlIHRlYW0gb3duZXIgd2FzIHNlbGVjdGVkXG4gICAgICogQHBhcmFtIHtVc2VyfSBvd25lciAtIFVzZXIgdG8gc2VsZWN0IGFzIG93bmVyXG4gICAgICovXG4gICAgb25TZWxlY3RPd25lcihvd25lcjogVXNlcikge1xuICAgICAgICB0aGlzLnBlbmRpbmdUZWFtLm93bmVyID0gb3duZXI7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2FuY2VsIHRoZSB1cGRhdGUtZGlhbG9nXG4gICAgICovXG4gICAgY2xlYXIoKSB7XG4gICAgICAgIHRoaXMuYWN0aXZlTW9kYWwuZGlzbWlzcygnY2FuY2VsJyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2F2ZSBjaGFuZ2VzIG1hZGUgdG8gdGhlIHRlYW1cbiAgICAgKi9cbiAgICBzYXZlKCkge1xuICAgICAgICBpZiAodGhpcy50ZWFtU2l6ZVZpb2xhdGlvblVuY29uZmlybWVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLnRlYW0gPSBjbG9uZURlZXAodGhpcy5wZW5kaW5nVGVhbSk7XG5cbiAgICAgICAgaWYgKHRoaXMudGVhbS5pZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0aGlzLnN1YnNjcmliZVRvU2F2ZVJlc3BvbnNlKHRoaXMudGVhbVNlcnZpY2UudXBkYXRlKHRoaXMuZXhlcmNpc2UsIHRoaXMudGVhbSkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5zdWJzY3JpYmVUb1NhdmVSZXNwb25zZSh0aGlzLnRlYW1TZXJ2aWNlLmNyZWF0ZSh0aGlzLmV4ZXJjaXNlLCB0aGlzLnRlYW0pKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgc3Vic2NyaWJlVG9TYXZlUmVzcG9uc2UodGVhbTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VGVhbT4+KSB7XG4gICAgICAgIHRoaXMuaXNTYXZpbmcgPSB0cnVlO1xuICAgICAgICB0ZWFtLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAocmVzKSA9PiB0aGlzLm9uU2F2ZVN1Y2Nlc3MocmVzKSxcbiAgICAgICAgICAgIGVycm9yOiAoZXJyb3IpID0+IHRoaXMub25TYXZlRXJyb3IoZXJyb3IpLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIb29rIHRvIGluZGljYXRlIHRoZSBzYXZpbmcgd2FzIHN1Y2Nlc3NmdWxcbiAgICAgKiBAcGFyYW0ge0h0dHBSZXNwb25zZTxUZWFtPn10ZWFtIC0gVGhlIHN1Y2Nlc3NmdWwgdXBkYXRlZCB0ZWFtXG4gICAgICovXG4gICAgb25TYXZlU3VjY2Vzcyh0ZWFtOiBIdHRwUmVzcG9uc2U8VGVhbT4pIHtcbiAgICAgICAgdGhpcy5hY3RpdmVNb2RhbC5jbG9zZSh0ZWFtLmJvZHkpO1xuICAgICAgICB0aGlzLmlzU2F2aW5nID0gZmFsc2U7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSG9vayB0byBpbmRpY2F0ZSBhIHNhdmUgZXJyb3Igb2NjdXJyZWRcbiAgICAgKiBAcGFyYW0ge0h0dHBFcnJvclJlc3BvbnNlfSBodHRwRXJyb3JSZXNwb25zZSAtIFRoZSBvY2N1cnJlZCBlcnJvclxuICAgICAqL1xuICAgIG9uU2F2ZUVycm9yKGh0dHBFcnJvclJlc3BvbnNlOiBIdHRwRXJyb3JSZXNwb25zZSkge1xuICAgICAgICB0aGlzLmlzU2F2aW5nID0gZmFsc2U7XG5cbiAgICAgICAgY29uc3QgeyBlcnJvcktleSwgcGFyYW1zIH0gPSBodHRwRXJyb3JSZXNwb25zZS5lcnJvcjtcblxuICAgICAgICBzd2l0Y2ggKGVycm9yS2V5KSB7XG4gICAgICAgICAgICBjYXNlICdzdHVkZW50c0FscmVhZHlBc3NpZ25lZFRvVGVhbXMnOlxuICAgICAgICAgICAgICAgIGNvbnN0IHsgY29uZmxpY3RzIH0gPSBwYXJhbXM7XG4gICAgICAgICAgICAgICAgdGhpcy5zdHVkZW50VGVhbUNvbmZsaWN0cyA9IGNvbmZsaWN0cztcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIHNob3J0TmFtZVZhbGlkYXRpb24oc2hvcnROYW1lJDogU3ViamVjdDxzdHJpbmc+KSB7XG4gICAgICAgIHNob3J0TmFtZSRcbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIGRlYm91bmNlVGltZSg1MDApLFxuICAgICAgICAgICAgICAgIHN3aXRjaE1hcCgoc2hvcnROYW1lKSA9PiB0aGlzLnRlYW1TZXJ2aWNlLmV4aXN0c0J5U2hvcnROYW1lKHRoaXMuZXhlcmNpc2UuY291cnNlISwgc2hvcnROYW1lKSksXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAuc3Vic2NyaWJlKChhbHJlYWR5VGFrZW5SZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGFscmVhZHlUYWtlbiA9IGFscmVhZHlUYWtlblJlc3BvbnNlLmJvZHk7XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyb3JzID0gYWxyZWFkeVRha2VuXG4gICAgICAgICAgICAgICAgICAgID8geyAuLi50aGlzLnNob3J0TmFtZUNvbnRyb2wuZXJyb3JzLCBbdGhpcy5zaG9ydE5hbWVBbHJlYWR5VGFrZW5FcnJvckNvZGVdOiBhbHJlYWR5VGFrZW4gfVxuICAgICAgICAgICAgICAgICAgICA6IG9taXQodGhpcy5zaG9ydE5hbWVDb250cm9sLmVycm9ycywgdGhpcy5zaG9ydE5hbWVBbHJlYWR5VGFrZW5FcnJvckNvZGUpO1xuICAgICAgICAgICAgICAgIHRoaXMuc2hvcnROYW1lQ29udHJvbC5zZXRFcnJvcnMoaXNFbXB0eShlcnJvcnMpID8gbnVsbCA6IGVycm9ycyk7XG4gICAgICAgICAgICB9KTtcbiAgICB9XG59XG4iLCI8Zm9ybSBpZD1cInRlYW1VcGRhdGVEaWFsb2dGb3JtXCIgbmFtZT1cImVkaXRGb3JtXCIgcm9sZT1cImZvcm1cIiBub3ZhbGlkYXRlIChuZ1N1Ym1pdCk9XCJzYXZlKClcIiAjZWRpdEZvcm09XCJuZ0Zvcm1cIj5cbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtaGVhZGVyXCI+XG4gICAgICAgIDxoNCBjbGFzcz1cIm1vZGFsLXRpdGxlXCI+XG4gICAgICAgICAgICA8c3BhbiBbamhpVHJhbnNsYXRlXT1cInBlbmRpbmdUZWFtLmlkID8gJ2FydGVtaXNBcHAudGVhbS51cGRhdGVUZWFtLmxhYmVsJyA6ICdhcnRlbWlzQXBwLnRlYW0uY3JlYXRlVGVhbS5sYWJlbCdcIj5cbiAgICAgICAgICAgICAgICB7eyBwZW5kaW5nVGVhbS5pZCA/ICdVcGRhdGUgVGVhbScgOiAnQ3JlYXRlIFRlYW0nIH19XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj4oe3sgZXhlcmNpc2UudGl0bGUgfX0pPC9zcGFuPlxuICAgICAgICA8L2g0PlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1jbG9zZVwiIGRhdGEtZGlzbWlzcz1cIm1vZGFsXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgKGNsaWNrKT1cImNsZWFyKClcIj48L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtYm9keVwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwibGFiZWwtbmFycm93XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC50ZWFtLm5hbWUubGFiZWxcIiBmb3I9XCJ0ZWFtTmFtZVwiPk5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCJcbiAgICAgICAgICAgICAgICBuYW1lPVwibmFtZVwiXG4gICAgICAgICAgICAgICAgaWQ9XCJ0ZWFtTmFtZVwiXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICBtaW5sZW5ndGg9XCIzXCJcbiAgICAgICAgICAgICAgICBbKG5nTW9kZWwpXT1cInBlbmRpbmdUZWFtLm5hbWVcIlxuICAgICAgICAgICAgICAgIChuZ01vZGVsQ2hhbmdlKT1cIm9uVGVhbU5hbWVDaGFuZ2VkKCRldmVudClcIlxuICAgICAgICAgICAgICAgICNuYW1lPVwibmdNb2RlbFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgQGZvciAoZSBvZiBuYW1lLmVycm9ycyEgfCBrZXl2YWx1ZSB8IHJlbW92ZWtleXM6IFsncmVxdWlyZWQnXTsgdHJhY2sgZSkge1xuICAgICAgICAgICAgICAgIEBpZiAobmFtZS5pbnZhbGlkICYmIChuYW1lLmRpcnR5IHx8IG5hbWUudG91Y2hlZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tY29udHJvbC1lcnJvciB0ZXh0LWRhbmdlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gW2poaVRyYW5zbGF0ZV09XCInYXJ0ZW1pc0FwcC50ZWFtLm5hbWUnICsgJy4nICsgZS5rZXlcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImxhYmVsLW5hcnJvd1wiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5zaG9ydE5hbWUubGFiZWxcIiBmb3I9XCJ0ZWFtU2hvcnROYW1lXCI+U2hvcnQgTmFtZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGpoaS1oZWxwLWljb24gdGV4dD1cImFydGVtaXNBcHAudGVhbS5zaG9ydE5hbWUudG9vbHRpcFwiPjwvamhpLWhlbHAtaWNvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCJcbiAgICAgICAgICAgICAgICBuYW1lPVwic2hvcnROYW1lXCJcbiAgICAgICAgICAgICAgICBpZD1cInRlYW1TaG9ydE5hbWVcIlxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgbWlubGVuZ3RoPVwiM1wiXG4gICAgICAgICAgICAgICAgW3BhdHRlcm5dPVwic2hvcnROYW1lUGF0dGVyblwiXG4gICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJwZW5kaW5nVGVhbS5zaG9ydE5hbWVcIlxuICAgICAgICAgICAgICAgIChuZ01vZGVsQ2hhbmdlKT1cIm9uVGVhbVNob3J0TmFtZUNoYW5nZWQoJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgW3JlYWRvbmx5XT1cInNob3J0TmFtZVJlYWRPbmx5XCJcbiAgICAgICAgICAgICAgICAjc2hvcnROYW1lPVwibmdNb2RlbFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgQGZvciAoZSBvZiBzaG9ydE5hbWUuZXJyb3JzISB8IGtleXZhbHVlIHwgcmVtb3Zla2V5czogWydyZXF1aXJlZCddOyB0cmFjayBlKSB7XG4gICAgICAgICAgICAgICAgQGlmIChzaG9ydE5hbWUuaW52YWxpZCAmJiAoc2hvcnROYW1lLmRpcnR5IHx8IHNob3J0TmFtZS50b3VjaGVkKSkge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1jb250cm9sLWVycm9yIHRleHQtZGFuZ2VyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBbamhpVHJhbnNsYXRlXT1cIidhcnRlbWlzQXBwLnRlYW0uc2hvcnROYW1lJyArICcuJyArIGUua2V5XCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBhbGlnbi1pdGVtcy1lbmRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJsYWJlbC1uYXJyb3dcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0ub3duZXIubGFiZWxcIj5UdXRvcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxqaGktaGVscC1pY29uIHRleHQ9XCJhcnRlbWlzQXBwLnRlYW0ub3duZXIudG9vbHRpcFwiIGNsYXNzPVwibWUtMVwiPjwvamhpLWhlbHAtaWNvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICBAaWYgKHNlYXJjaGluZ093bmVyKSB7XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIGNsYXNzPVwic2VhcmNoLXNlYXJjaGluZ1wiIFtpY29uXT1cImZhU3Bpbm5lclwiIFtzcGluXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoc2VhcmNoaW5nT3duZXJRdWVyeVRvb1Nob3J0KSB7XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibGFiZWwtaW5saW5lLW1lc3NhZ2UgdGV4dC1kYW5nZXJcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0ub3duZXJTZWFyY2gucXVlcnlUb29TaG9ydFwiPiBQbGVhc2UgZW50ZXIgYXQgbGVhc3QgMyBjaGFyYWN0ZXJzLiA8L3NwYW4+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoc2VhcmNoaW5nT3duZXJOb1Jlc3VsdHNGb3JRdWVyeSkge1xuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImxhYmVsLWlubGluZS1tZXNzYWdlIHRleHQtZGFuZ2VyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0ub3duZXJTZWFyY2gubm9SZXN1bHRzXCI+Tm8gdHV0b3JzIGZvdW5kIGluIGNvdXJzZSBmb3Igc2VhcmNoOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e3sgc2VhcmNoaW5nT3duZXJOb1Jlc3VsdHNGb3JRdWVyeSB9fTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoc2VhcmNoaW5nT3duZXJGYWlsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsYWJlbC1pbmxpbmUtbWVzc2FnZSB0ZXh0LWRhbmdlclwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5vd25lclNlYXJjaC5mYWlsZWRcIj4gU2VhcmNoIGZhaWxlZC4gUGxlYXNlIHRyeSBhZ2Fpbi4gPC9zcGFuPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKHRlYW0uaWQgJiYgdGVhbS5vd25lcj8uaWQgIT09IHBlbmRpbmdUZWFtLm93bmVyPy5pZCkge1xuICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0ub3duZXJDaGFuZ2VXYXJuaW5nXCIgW3RyYW5zbGF0ZVZhbHVlc109XCJ7IHNob3J0TmFtZTogdGVhbS5zaG9ydE5hbWUgfVwiIGNsYXNzPVwibGFiZWwtaW5saW5lLW1lc3NhZ2UgdGV4dC1kYW5nZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFRoaXMgd2lsbCBjaGFuZ2UgdGhlIHR1dG9yIGZvciB0aGUgdGVhbSB7eyB0ZWFtLnNob3J0TmFtZSB9fSBpbiB0aGUgd2hvbGUgY291cnNlIVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8amhpLXRlYW0tb3duZXItc2VhcmNoXG4gICAgICAgICAgICAgICAgaWQ9XCJ0ZWFtT3duZXJcIlxuICAgICAgICAgICAgICAgIFtpbnB1dERpc2FibGVkXT1cIiFleGVyY2lzZS5pc0F0TGVhc3RJbnN0cnVjdG9yXCJcbiAgICAgICAgICAgICAgICBbY291cnNlXT1cImV4ZXJjaXNlLmNvdXJzZSFcIlxuICAgICAgICAgICAgICAgIFtleGVyY2lzZV09XCJleGVyY2lzZVwiXG4gICAgICAgICAgICAgICAgW3RlYW1dPVwidGVhbVwiXG4gICAgICAgICAgICAgICAgKHNlbGVjdE93bmVyKT1cIm9uU2VsZWN0T3duZXIoJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgKHNlYXJjaGluZyk9XCJzZWFyY2hpbmdPd25lciA9ICRldmVudFwiXG4gICAgICAgICAgICAgICAgKHNlYXJjaFF1ZXJ5VG9vU2hvcnQpPVwic2VhcmNoaW5nT3duZXJRdWVyeVRvb1Nob3J0ID0gJGV2ZW50XCJcbiAgICAgICAgICAgICAgICAoc2VhcmNoTm9SZXN1bHRzKT1cInNlYXJjaGluZ093bmVyTm9SZXN1bHRzRm9yUXVlcnkgPSAkZXZlbnRcIlxuICAgICAgICAgICAgICAgIChzZWFyY2hGYWlsZWQpPVwic2VhcmNoaW5nT3duZXJGYWlsZWQgPSAkZXZlbnRcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgPC9qaGktdGVhbS1vd25lci1zZWFyY2g+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBhbGlnbi1pdGVtcy1lbmRcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJsYWJlbC1uYXJyb3cgbWUtMVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5zdHVkZW50c1wiPlN0dWRlbnRzPC9sYWJlbD5cbiAgICAgICAgICAgICAgICBAaWYgKHNlYXJjaGluZ1N0dWRlbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIGNsYXNzPVwic2VhcmNoLXNlYXJjaGluZ1wiIFtpY29uXT1cImZhU3Bpbm5lclwiIFtzcGluXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoc2VhcmNoaW5nU3R1ZGVudHNRdWVyeVRvb1Nob3J0KSB7XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibGFiZWwtaW5saW5lLW1lc3NhZ2UgdGV4dC1kYW5nZXJcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0uc3R1ZGVudFNlYXJjaC5xdWVyeVRvb1Nob3J0XCI+IFBsZWFzZSBlbnRlciBhdCBsZWFzdCAzIGNoYXJhY3RlcnMuIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmIChzZWFyY2hpbmdTdHVkZW50c05vUmVzdWx0c0ZvclF1ZXJ5KSB7XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibGFiZWwtaW5saW5lLW1lc3NhZ2UgdGV4dC1kYW5nZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5zdHVkZW50U2VhcmNoLm5vUmVzdWx0c1wiPk5vIHN0dWRlbnRzIGZvdW5kIGluIGNvdXJzZSBmb3Igc2VhcmNoOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e3sgc2VhcmNoaW5nU3R1ZGVudHNOb1Jlc3VsdHNGb3JRdWVyeSB9fTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBpZiAoc2VhcmNoaW5nU3R1ZGVudHNGYWlsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsYWJlbC1pbmxpbmUtbWVzc2FnZSB0ZXh0LWRhbmdlclwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5zdHVkZW50U2VhcmNoLmZhaWxlZFwiPiBTZWFyY2ggZmFpbGVkLiBQbGVhc2UgdHJ5IGFnYWluLiA8L3NwYW4+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8amhpLXRlYW0tc3R1ZGVudC1zZWFyY2hcbiAgICAgICAgICAgICAgICBpZD1cInRlYW1TdHVkZW50c1wiXG4gICAgICAgICAgICAgICAgW2NvdXJzZV09XCJleGVyY2lzZS5jb3Vyc2UhXCJcbiAgICAgICAgICAgICAgICBbZXhlcmNpc2VdPVwiZXhlcmNpc2VcIlxuICAgICAgICAgICAgICAgIFt0ZWFtXT1cInRlYW1cIlxuICAgICAgICAgICAgICAgIFtzdHVkZW50c0Zyb21QZW5kaW5nVGVhbV09XCJwZW5kaW5nVGVhbS5zdHVkZW50cyB8fCBbXVwiXG4gICAgICAgICAgICAgICAgKHNlbGVjdFN0dWRlbnQpPVwib25BZGRTdHVkZW50KCRldmVudClcIlxuICAgICAgICAgICAgICAgIChzZWFyY2hpbmcpPVwic2VhcmNoaW5nU3R1ZGVudHMgPSAkZXZlbnRcIlxuICAgICAgICAgICAgICAgIChzZWFyY2hRdWVyeVRvb1Nob3J0KT1cInNlYXJjaGluZ1N0dWRlbnRzUXVlcnlUb29TaG9ydCA9ICRldmVudFwiXG4gICAgICAgICAgICAgICAgKHNlYXJjaE5vUmVzdWx0cyk9XCJzZWFyY2hpbmdTdHVkZW50c05vUmVzdWx0c0ZvclF1ZXJ5ID0gJGV2ZW50XCJcbiAgICAgICAgICAgICAgICAoc2VhcmNoRmFpbGVkKT1cInNlYXJjaGluZ1N0dWRlbnRzRmFpbGVkID0gJGV2ZW50XCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgIDwvamhpLXRlYW0tc3R1ZGVudC1zZWFyY2g+XG4gICAgICAgICAgICA8dWwgY2xhc3M9XCJsaXN0LWdyb3VwIGxpc3QtZ3JvdXAtLXN0dWRlbnRzIG15LTNcIj5cbiAgICAgICAgICAgICAgICBAZm9yIChzdHVkZW50IG9mIHBlbmRpbmdUZWFtLnN0dWRlbnRzOyB0cmFjayBzdHVkZW50OyBsZXQgaSA9ICRpbmRleCkge1xuICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3M9XCJsaXN0LWdyb3VwLWl0ZW0tY29udGFpbmVyIGQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsaXN0LWdyb3VwLWl0ZW0taW5kZXhcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBpICsgMSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGlzdC1ncm91cC1pdGVtIGQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXJcIiBbY2xhc3MuaGFzLWVycm9yXT1cImhhc0NvbmZsaWN0aW5nVGVhbShzdHVkZW50KVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdHVkZW50LW5hbWVcIj57eyBzdHVkZW50Lm5hbWUgfX0gKHt7IHN0dWRlbnQubG9naW4gfX0pPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImplc3Qtc3R1ZGVudC1yZW1vdmUtbGluayBzdHVkZW50LXJlbW92ZS1saW5rIG1zLTRcIiAoY2xpY2spPVwib25SZW1vdmVTdHVkZW50KHN0dWRlbnQpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhVHJhc2hBbHRcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoaGFzQ29uZmxpY3RpbmdUZWFtKHN0dWRlbnQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxpc3QtZ3JvdXAtaXRlbS1lcnJvciBoaWRkZW4tbWQtZG93blwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBjbGFzcz1cIm1lLTFcIiBbaWNvbl09XCJmYUV4Y2xhbWF0aW9uVHJpYW5nbGVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFscmVhZHkgYXNzaWduZWQgdG8gdGVhbSB3aXRoIGlkIHt7IGdldENvbmZsaWN0aW5nVGVhbShzdHVkZW50KSB9fS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmIChwZW5kaW5nVGVhbS5zdHVkZW50cyAmJiBwZW5kaW5nVGVhbS5zdHVkZW50cy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzPVwibGlzdC1ncm91cC1pdGVtLWNvbnRhaW5lciBkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGlzdC1ncm91cC1pdGVtLWluZGV4IHRleHQtYm9keS1zZWNvbmRhcnlcIj4xPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGlzdC1ncm91cC1pdGVtIGQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1ib2R5LXNlY29uZGFyeVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5ub1N0dWRlbnRzQWRkZWRZZXRcIj5ObyBzdHVkZW50cyBhZGRlZCB5ZXQuPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFsZXJ0IG10LTNcIiBbY2xhc3MuYWxlcnQtaW5mb109XCIhc2hvd0lnbm9yZVRlYW1TaXplUmVjb21tZW5kYXRpb25PcHRpb25cIiBbY2xhc3MuYWxlcnQtd2FybmluZ109XCJzaG93SWdub3JlVGVhbVNpemVSZWNvbW1lbmRhdGlvbk9wdGlvblwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC13ZWlnaHQtYm9sZFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS50ZWFtU2l6ZU5vdGVcIj5SZWNvbW1lbmRlZCB0ZWFtIHNpemU6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAge3sgY29uZmlnLm1pblRlYW1TaXplIH19IC0ge3sgY29uZmlnLm1heFRlYW1TaXplIH19XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0udGVhbVNpemVVbml0XCI+c3R1ZGVudHM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICBAaWYgKHNob3dJZ25vcmVUZWFtU2l6ZVJlY29tbWVuZGF0aW9uT3B0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1jaGVja1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImlnbm9yZVRlYW1TaXplUmVjb21tZW5kYXRpb25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZvcm0tY2hlY2staW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT1cIlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFsobmdNb2RlbCldPVwiaWdub3JlVGVhbVNpemVSZWNvbW1lbmRhdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ01vZGVsT3B0aW9uc109XCJ7IHN0YW5kYWxvbmU6IHRydWUgfVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJmb3JtLWNoZWNrLWxhYmVsXCIgZm9yPVwiaWdub3JlVGVhbVNpemVSZWNvbW1lbmRhdGlvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0uaWdub3JlVGVhbVNpemVSZWNvbW1lbmRhdGlvblwiPlByb2NlZWQgYWdhaW5zdCByZWNvbW1lbmRhdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gY2xhc3M9XCJtcy0xXCIgW2ljb25dPVwiZmFFeGNsYW1hdGlvblRyaWFuZ2xlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1mb290ZXJcIj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLWRlZmF1bHQgY2FuY2VsXCIgZGF0YS1kaXNtaXNzPVwibW9kYWxcIiAoY2xpY2spPVwiY2xlYXIoKVwiPlxuICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFCYW5cIj48L2ZhLWljb24+Jm5ic3A7PHNwYW4gamhpVHJhbnNsYXRlPVwiZW50aXR5LmFjdGlvbi5jYW5jZWxcIj5DYW5jZWw8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBbZGlzYWJsZWRdPVwiZWRpdEZvcm0uaW52YWxpZCB8fCBpc1NhdmluZyB8fCB0ZWFtU2l6ZVZpb2xhdGlvblVuY29uZmlybWVkXCIgY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIj5cbiAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhU2F2ZVwiPjwvZmEtaWNvbj4mbmJzcDs8c3BhbiBqaGlUcmFuc2xhdGU9XCJlbnRpdHkuYWN0aW9uLnNhdmVcIj5TYXZlPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbjwvZm9ybT5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOZ2JNb2RhbCwgTmdiTW9kYWxSZWYgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgeyBUZWFtVXBkYXRlRGlhbG9nQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtLXVwZGF0ZS1kaWFsb2cvdGVhbS11cGRhdGUtZGlhbG9nLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBUZWFtIH0gZnJvbSAnYXBwL2VudGl0aWVzL3RlYW0ubW9kZWwnO1xuaW1wb3J0IHsgRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgQnV0dG9uU2l6ZSwgQnV0dG9uVHlwZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9idXR0b24uY29tcG9uZW50JztcbmltcG9ydCB7IGZhUGVuY2lsQWx0LCBmYVBsdXMgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS10ZWFtLXVwZGF0ZS1idXR0b24nLFxuICAgIHRlbXBsYXRlOiBgXG4gICAgICAgIDxqaGktYnV0dG9uXG4gICAgICAgICAgICBbYnRuVHlwZV09XCJCdXR0b25UeXBlLlBSSU1BUllcIlxuICAgICAgICAgICAgW2J0blNpemVdPVwiYnV0dG9uU2l6ZVwiXG4gICAgICAgICAgICBbaWNvbl09XCJ0ZWFtID8gZmFQZW5jaWxBbHQgOiBmYVBsdXNcIlxuICAgICAgICAgICAgW3RpdGxlXT1cInRlYW0gPyAnYXJ0ZW1pc0FwcC50ZWFtLnVwZGF0ZVRlYW0ubGFiZWwnIDogJ2FydGVtaXNBcHAudGVhbS5jcmVhdGVUZWFtLmxhYmVsJ1wiXG4gICAgICAgICAgICAob25DbGljayk9XCJvcGVuVGVhbUNyZWF0ZURpYWxvZygkZXZlbnQpXCJcbiAgICAgICAgPjwvamhpLWJ1dHRvbj5cbiAgICBgLFxufSlcbmV4cG9ydCBjbGFzcyBUZWFtVXBkYXRlQnV0dG9uQ29tcG9uZW50IHtcbiAgICBCdXR0b25UeXBlID0gQnV0dG9uVHlwZTtcbiAgICBCdXR0b25TaXplID0gQnV0dG9uU2l6ZTtcblxuICAgIEBJbnB1dCgpIHRlYW06IFRlYW0gfCB1bmRlZmluZWQ7XG4gICAgQElucHV0KCkgZXhlcmNpc2U6IEV4ZXJjaXNlO1xuICAgIEBJbnB1dCgpIGJ1dHRvblNpemU6IEJ1dHRvblNpemUgPSBCdXR0b25TaXplLlNNQUxMO1xuXG4gICAgQE91dHB1dCgpIHNhdmU6IEV2ZW50RW1pdHRlcjxUZWFtPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICAgIC8vIEljb25zXG4gICAgZmFQZW5jaWxBbHQgPSBmYVBlbmNpbEFsdDtcbiAgICBmYVBsdXMgPSBmYVBsdXM7XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIG1vZGFsU2VydmljZTogTmdiTW9kYWwpIHt9XG5cbiAgICAvKipcbiAgICAgKiBPcGVuIHRoZSBkaWFsb2cgZm9yIHRlYW0gY3JlYXRpb25cbiAgICAgKiBAcGFyYW0ge01vdXNlRXZlbnR9IGV2ZW50IC0gT2NjdXJyZWQgTW91c2UgRXZlbnRcbiAgICAgKi9cbiAgICBvcGVuVGVhbUNyZWF0ZURpYWxvZyhldmVudDogTW91c2VFdmVudCkge1xuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgY29uc3QgbW9kYWxSZWY6IE5nYk1vZGFsUmVmID0gdGhpcy5tb2RhbFNlcnZpY2Uub3BlbihUZWFtVXBkYXRlRGlhbG9nQ29tcG9uZW50LCB7IGtleWJvYXJkOiB0cnVlLCBzaXplOiAnbGcnLCBiYWNrZHJvcDogJ3N0YXRpYycgfSk7XG4gICAgICAgIG1vZGFsUmVmLmNvbXBvbmVudEluc3RhbmNlLnRlYW0gPSB0aGlzLnRlYW0gfHwgbmV3IFRlYW0oKTtcbiAgICAgICAgbW9kYWxSZWYuY29tcG9uZW50SW5zdGFuY2UuZXhlcmNpc2UgPSB0aGlzLmV4ZXJjaXNlO1xuXG4gICAgICAgIG1vZGFsUmVmLnJlc3VsdC50aGVuKFxuICAgICAgICAgICAgKHRlYW06IFRlYW0pID0+IHRoaXMuc2F2ZS5lbWl0KHRlYW0pLFxuICAgICAgICAgICAgKCkgPT4ge30sXG4gICAgICAgICk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIElucHV0LCBPdXRwdXQsIFZpZXdDaGlsZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgU3ViamVjdCwgY29tYmluZUxhdGVzdCwgbWVyZ2UsIG9mIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBmaWx0ZXIsIG1hcCwgc3dpdGNoTWFwLCB0YXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBUcmFuc2xhdGVTZXJ2aWNlIH0gZnJvbSAnQG5neC10cmFuc2xhdGUvY29yZSc7XG5pbXBvcnQgeyBDb3Vyc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvY291cnNlLm1vZGVsJztcbmltcG9ydCB7IEV4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IENvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvdXJzZS9tYW5hZ2UvY291cnNlLW1hbmFnZW1lbnQuc2VydmljZSc7XG5pbXBvcnQgeyBOZ2JUeXBlYWhlYWQgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgeyBvcmRlckJ5IH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IEFydGVtaXNEYXRlUGlwZSB9IGZyb20gJ2FwcC9zaGFyZWQvcGlwZXMvYXJ0ZW1pcy1kYXRlLnBpcGUnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS10ZWFtLWV4ZXJjaXNlLXNlYXJjaCcsXG4gICAgdGVtcGxhdGVVcmw6ICcuL3RlYW0tZXhlcmNpc2Utc2VhcmNoLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgVGVhbUV4ZXJjaXNlU2VhcmNoQ29tcG9uZW50IHtcbiAgICBAVmlld0NoaWxkKCdpbnN0YW5jZScsIHsgc3RhdGljOiB0cnVlIH0pIG5nYlR5cGVhaGVhZDogTmdiVHlwZWFoZWFkO1xuICAgIGZvY3VzJCA9IG5ldyBTdWJqZWN0PHN0cmluZz4oKTtcbiAgICBjbGljayQgPSBuZXcgU3ViamVjdDxzdHJpbmc+KCk7XG5cbiAgICBASW5wdXQoKSBjb3Vyc2U6IENvdXJzZTtcbiAgICBASW5wdXQoKSBpZ25vcmVFeGVyY2lzZXM6IEV4ZXJjaXNlW107XG5cbiAgICBAT3V0cHV0KCkgc2VsZWN0RXhlcmNpc2UgPSBuZXcgRXZlbnRFbWl0dGVyPEV4ZXJjaXNlPigpO1xuICAgIEBPdXRwdXQoKSBzZWFyY2hpbmcgPSBuZXcgRXZlbnRFbWl0dGVyPGJvb2xlYW4+KCk7XG4gICAgQE91dHB1dCgpIHNlYXJjaFF1ZXJ5VG9vU2hvcnQgPSBuZXcgRXZlbnRFbWl0dGVyPGJvb2xlYW4+KCk7XG4gICAgQE91dHB1dCgpIHNlYXJjaEZhaWxlZCA9IG5ldyBFdmVudEVtaXR0ZXI8Ym9vbGVhbj4oKTtcbiAgICBAT3V0cHV0KCkgc2VhcmNoTm9SZXN1bHRzID0gbmV3IEV2ZW50RW1pdHRlcjxzdHJpbmcgfCB1bmRlZmluZWQ+KCk7XG5cbiAgICBleGVyY2lzZTogRXhlcmNpc2U7XG4gICAgZXhlcmNpc2VPcHRpb25zOiBFeGVyY2lzZVtdID0gW107XG4gICAgZXhlcmNpc2VPcHRpb25zTG9hZGVkID0gZmFsc2U7XG5cbiAgICBpbnB1dERpc3BsYXlWYWx1ZTogc3RyaW5nO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgY291cnNlU2VydmljZTogQ291cnNlTWFuYWdlbWVudFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgdHJhbnNsYXRlU2VydmljZTogVHJhbnNsYXRlU2VydmljZSxcbiAgICApIHt9XG5cbiAgICBvbkF1dG9jb21wbGV0ZVNlbGVjdCA9IChleGVyY2lzZTogRXhlcmNpc2UpID0+IHtcbiAgICAgICAgdGhpcy5pbnB1dERpc3BsYXlWYWx1ZSA9IHRoaXMuc2VhcmNoUmVzdWx0Rm9ybWF0dGVyKGV4ZXJjaXNlKTtcbiAgICAgICAgdGhpcy5zZWxlY3RFeGVyY2lzZS5lbWl0KGV4ZXJjaXNlKTtcbiAgICB9O1xuXG4gICAgc2VhcmNoSW5wdXRGb3JtYXR0ZXIgPSAoKSA9PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0RGlzcGxheVZhbHVlO1xuICAgIH07XG5cbiAgICBzZWFyY2hSZXN1bHRGb3JtYXR0ZXIgPSAoZXhlcmNpc2U6IEV4ZXJjaXNlKTogc3RyaW5nID0+IHtcbiAgICAgICAgY29uc3QgeyB0aXRsZSwgcmVsZWFzZURhdGUgfSA9IGV4ZXJjaXNlO1xuICAgICAgICBjb25zdCBkYXRlID0gcmVsZWFzZURhdGUgPyByZWxlYXNlRGF0ZS5mb3JtYXQoQXJ0ZW1pc0RhdGVQaXBlLmZvcm1hdCh0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuY3VycmVudExhbmcsICdzaG9ydC1kYXRlJykpIDogJyc7XG4gICAgICAgIHJldHVybiB0aXRsZSArIChyZWxlYXNlRGF0ZSA/IGAgKCR7ZGF0ZX0pYCA6ICcnKTtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgZ2l2ZW4gc2VhcmNoVGVybSBpcyBpbmNsdWRlZCBpbiBnaXZlbiBleGVyY2lzZVxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBzZWFyY2hUZXJtIC0gVGVybSB0byBzZWFyY2ggZm9yXG4gICAgICogQHBhcmFtIHtFeGVyY2lzZX0gZXhlcmNpc2UgLSBFeGVyY2lzZSB0byBzZWFyY2ggdGhyb3VnaFxuICAgICAqL1xuICAgIHNlYXJjaE1hdGNoZXNFeGVyY2lzZShzZWFyY2hUZXJtOiBzdHJpbmcsIGV4ZXJjaXNlOiBFeGVyY2lzZSkge1xuICAgICAgICByZXR1cm4gZXhlcmNpc2UudGl0bGUhLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKTtcbiAgICB9XG5cbiAgICBvblNlYXJjaCA9ICh0ZXh0JDogT2JzZXJ2YWJsZTxzdHJpbmc+KSA9PiB7XG4gICAgICAgIGNvbnN0IGNsaWNrc1dpdGhDbG9zZWRQb3B1cCQgPSB0aGlzLmNsaWNrJC5waXBlKGZpbHRlcigoKSA9PiAhdGhpcy5uZ2JUeXBlYWhlYWQuaXNQb3B1cE9wZW4oKSkpO1xuICAgICAgICBjb25zdCBpbnB1dEZvY3VzJCA9IHRoaXMuZm9jdXMkO1xuXG4gICAgICAgIHJldHVybiBtZXJnZSh0ZXh0JCwgaW5wdXRGb2N1cyQsIGNsaWNrc1dpdGhDbG9zZWRQb3B1cCQpLnBpcGUoXG4gICAgICAgICAgICB0YXAoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoTm9SZXN1bHRzLmVtaXQodW5kZWZpbmVkKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgc3dpdGNoTWFwKChzZWFyY2hUZXJtKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZWFyY2hGYWlsZWQuZW1pdChmYWxzZSk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZWFyY2hpbmcuZW1pdCh0cnVlKTtcbiAgICAgICAgICAgICAgICAvLyBJZiBleGVyY2lzZSBvcHRpb25zIGhhdmUgYWxyZWFkeSBiZWVuIGxvYWRlZCBvbmNlLCBkbyBub3QgbG9hZCB0aGVtIGFnYWluIGFuZCByZXVzZSB0aGUgYWxyZWFkeSBsb2FkZWQgb25lc1xuICAgICAgICAgICAgICAgIGNvbnN0IGV4ZXJjaXNlT3B0aW9uc1NvdXJjZSQgPSB0aGlzLmV4ZXJjaXNlT3B0aW9uc0xvYWRlZCA/IG9mKHRoaXMuZXhlcmNpc2VPcHRpb25zKSA6IHRoaXMubG9hZEV4ZXJjaXNlT3B0aW9ucygpO1xuICAgICAgICAgICAgICAgIHJldHVybiBjb21iaW5lTGF0ZXN0KFtvZihzZWFyY2hUZXJtKSwgZXhlcmNpc2VPcHRpb25zU291cmNlJF0pO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKCkgPT4gdGhpcy5zZWFyY2hpbmcuZW1pdChmYWxzZSkpLFxuICAgICAgICAgICAgc3dpdGNoTWFwKChbc2VhcmNoVGVybSwgZXhlcmNpc2VPcHRpb25zXSkgPT4ge1xuICAgICAgICAgICAgICAgIC8vIEZpbHRlciBsaXN0IG9mIGFsbCBleGVyY2lzZSBvcHRpb25zIGJ5IHRoZSBzZWFyY2ggdGVybVxuICAgICAgICAgICAgICAgIGNvbnN0IG1hdGNoID0gKGV4ZXJjaXNlOiBFeGVyY2lzZSkgPT4gdGhpcy5zZWFyY2hNYXRjaGVzRXhlcmNpc2Uoc2VhcmNoVGVybSwgZXhlcmNpc2UpO1xuICAgICAgICAgICAgICAgIHJldHVybiBjb21iaW5lTGF0ZXN0KFtvZihzZWFyY2hUZXJtKSwgb2YoIWV4ZXJjaXNlT3B0aW9ucyA/IGV4ZXJjaXNlT3B0aW9ucyA6IGV4ZXJjaXNlT3B0aW9ucy5maWx0ZXIobWF0Y2gpKV0pO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKFtzZWFyY2hUZXJtLCBleGVyY2lzZU9wdGlvbnNdKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGV4ZXJjaXNlT3B0aW9ucyAmJiBleGVyY2lzZU9wdGlvbnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoTm9SZXN1bHRzLmVtaXQoc2VhcmNoVGVybSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBtYXAoKFssIGV4ZXJjaXNlT3B0aW9uc10pID0+IGV4ZXJjaXNlT3B0aW9ucyB8fCBbXSksXG4gICAgICAgICAgICBtYXAoKGV4ZXJjaXNlT3B0aW9ucykgPT4gb3JkZXJCeShleGVyY2lzZU9wdGlvbnMsIFsncmVsZWFzZURhdGUnLCAnaWQnXSkpLFxuICAgICAgICApO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBMb2FkIG9wdGlvbnMgb2YgdGVhbSBleGVyY2lzZVxuICAgICAqL1xuICAgIGxvYWRFeGVyY2lzZU9wdGlvbnMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmNvdXJzZVNlcnZpY2VcbiAgICAgICAgICAgIC5maW5kV2l0aEV4ZXJjaXNlcyh0aGlzLmNvdXJzZS5pZCEpXG4gICAgICAgICAgICAucGlwZShtYXAoKGNvdXJzZVJlc3BvbnNlKSA9PiBjb3Vyc2VSZXNwb25zZS5ib2R5IS5leGVyY2lzZXMgfHwgW10pKVxuICAgICAgICAgICAgLnBpcGUobWFwKChleGVyY2lzZXMpID0+IGV4ZXJjaXNlcy5maWx0ZXIoKGV4ZXJjaXNlKSA9PiBleGVyY2lzZS50ZWFtTW9kZSkpKVxuICAgICAgICAgICAgLnBpcGUobWFwKChleGVyY2lzZXMpID0+IGV4ZXJjaXNlcy5maWx0ZXIoKGV4ZXJjaXNlKSA9PiAhdGhpcy5pZ25vcmVFeGVyY2lzZXMubWFwKChlKSA9PiBlLmlkKS5pbmNsdWRlcyhleGVyY2lzZS5pZCkpKSlcbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIHRhcCgoZXhlcmNpc2VPcHRpb25zKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZXhlcmNpc2VPcHRpb25zID0gZXhlcmNpc2VPcHRpb25zO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmV4ZXJjaXNlT3B0aW9uc0xvYWRlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAucGlwZShcbiAgICAgICAgICAgICAgICBjYXRjaEVycm9yKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5leGVyY2lzZU9wdGlvbnNMb2FkZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZWFyY2hGYWlsZWQuZW1pdCh0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9mKG51bGwpO1xuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgKTtcbiAgICB9XG59XG4iLCI8aW5wdXRcbiAgICAjaW5zdGFuY2U9XCJuZ2JUeXBlYWhlYWRcIlxuICAgIGlkPVwiZXhlcmNpc2Utc2VhcmNoLWlucHV0XCJcbiAgICB0eXBlPVwidGV4dFwiXG4gICAgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIlxuICAgIFtwbGFjZWhvbGRlcl09XCInYXJ0ZW1pc0FwcC50ZWFtLnNlbGVjdEV4ZXJjaXNlRm9ySW1wb3J0JyB8IGFydGVtaXNUcmFuc2xhdGVcIlxuICAgIFsobmdNb2RlbCldPVwiZXhlcmNpc2VcIlxuICAgIChzZWxlY3RJdGVtKT1cIm9uQXV0b2NvbXBsZXRlU2VsZWN0KCRldmVudC5pdGVtKVwiXG4gICAgKGZvY3VzKT1cImZvY3VzJC5uZXh0KCcnKVwiXG4gICAgKGNsaWNrKT1cImNsaWNrJC5uZXh0KCcnKVwiXG4gICAgW25nYlR5cGVhaGVhZF09XCJvblNlYXJjaFwiXG4gICAgW3Jlc3VsdEZvcm1hdHRlcl09XCJzZWFyY2hSZXN1bHRGb3JtYXR0ZXJcIlxuICAgIFtpbnB1dEZvcm1hdHRlcl09XCJzZWFyY2hJbnB1dEZvcm1hdHRlclwiXG4vPlxuIiwiaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0b3JSZWYsIENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBPdXRwdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGZhU3Bpbm5lciB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBUcmFuc2xhdGVTZXJ2aWNlIH0gZnJvbSAnQG5neC10cmFuc2xhdGUvY29yZSc7XG5pbXBvcnQgeyBVc2VyIH0gZnJvbSAnYXBwL2NvcmUvdXNlci91c2VyLm1vZGVsJztcbmltcG9ydCB7IFN0dWRlbnRXaXRoVGVhbSwgVGVhbSB9IGZyb20gJ2FwcC9lbnRpdGllcy90ZWFtLm1vZGVsJztcbmltcG9ydCB7IFNIT1JUX05BTUVfUEFUVEVSTiB9IGZyb20gJ2FwcC9zaGFyZWQvY29uc3RhbnRzL2lucHV0LmNvbnN0YW50cyc7XG5pbXBvcnQgeyBwYXJzZSB9IGZyb20gJ3BhcGFwYXJzZSc7XG5cbmNvbnN0IGNzdkNvbHVtbnMgPSBPYmplY3QuZnJlZXplKHtcbiAgICByZWdpc3RyYXRpb25OdW1iZXI6ICdyZWdpc3RyYXRpb25udW1iZXInLFxuICAgIG1hdHJpa2VsTnVtbWVyOiAnbWF0cmlrZWxudW1tZXInLFxuICAgIG1hdHJpY3VsYXRpb25OdW1iZXI6ICdtYXRyaWN1bGF0aW9ubnVtYmVyJyxcbiAgICBuYW1lOiAnbmFtZScsXG4gICAgdm9ybmFtZTogJ3Zvcm5hbWUnLFxuICAgIG5hY2huYW1lOiAnbmFjaG5hbWUnLFxuICAgIGZpcnN0TmFtZTogJ2ZpcnN0bmFtZScsXG4gICAgZmFtaWx5TmFtZTogJ2ZhbWlseW5hbWUnLFxuICAgIGxhc3ROYW1lOiAnbGFzdG5hbWUnLFxuICAgIHN1cm5hbWU6ICdzdXJuYW1lJyxcbiAgICBsb2dpbjogJ2xvZ2luJyxcbiAgICB1c2VybmFtZTogJ3VzZXJuYW1lJyxcbiAgICB1c2VyOiAndXNlcicsXG4gICAgYmVudXR6ZXI6ICdiZW51dHplcicsXG4gICAgYmVudXR6ZXJOYW1lOiAnYmVudXR6ZXJuYW1lJyxcbiAgICB0ZWFtOiAndGVhbScsXG4gICAgdGVhbU5hbWU6ICd0ZWFtbmFtZScsXG4gICAgZ3J1cHBlOiAnZ3J1cHBlJyxcbn0pO1xuXG50eXBlIENzdkVudHJ5ID0gb2JqZWN0O1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS10ZWFtcy1pbXBvcnQtZnJvbS1maWxlLWZvcm0nLFxuICAgIHRlbXBsYXRlVXJsOiAnLi90ZWFtcy1pbXBvcnQtZnJvbS1maWxlLWZvcm0uY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL3RlYW1zLWltcG9ydC1mcm9tLWZpbGUtZm9ybS5jb21wb25lbnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBUZWFtc0ltcG9ydEZyb21GaWxlRm9ybUNvbXBvbmVudCB7XG4gICAgQE91dHB1dCgpIHRlYW1zQ2hhbmdlZCA9IG5ldyBFdmVudEVtaXR0ZXI8VGVhbVtdPigpO1xuICAgIHNvdXJjZVRlYW1zPzogVGVhbVtdO1xuICAgIGltcG9ydGVkVGVhbXM6IFN0dWRlbnRXaXRoVGVhbVtdID0gW107XG4gICAgaW1wb3J0RmlsZT86IEZpbGU7XG4gICAgaW1wb3J0RmlsZU5hbWU6IHN0cmluZztcbiAgICBsb2FkaW5nOiBib29sZWFuO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYVNwaW5uZXIgPSBmYVNwaW5uZXI7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBjaGFuZ2VEZXRlY3RvcjogQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gICAgICAgIHByaXZhdGUgdHJhbnNsYXRlU2VydmljZTogVHJhbnNsYXRlU2VydmljZSxcbiAgICApIHt9XG5cbiAgICAvKipcbiAgICAgKiBNb3ZlIGZpbGUgcmVhZGVyIGNyZWF0aW9uIHRvIHNlcGFyYXRlIGZ1bmN0aW9uIHRvIGJlIGFibGUgdG8gbW9ja1xuICAgICAqIGh0dHBzOi8vZnJvbWFuZWdnLmNvbS9wb3N0LzIwMTUvMDQvMjIvZWFzeS10ZXN0aW5nLW9mLWNvZGUtaW52b2x2aW5nLW5hdGl2ZS1tZXRob2RzLWluLWphdmFzY3JpcHQvXG4gICAgICovXG4gICAgZ2VuZXJhdGVGaWxlUmVhZGVyKCkge1xuICAgICAgICByZXR1cm4gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDb252ZXJ0cyB0ZWFtcyBmcm9tIGZpbGUgdG8gZXhwZWN0ZWQgdGVhbSB0eXBlXG4gICAgICogQHBhcmFtIHtGaWxlUmVhZGVyfSBmaWxlUmVhZGVyIG9iamVjdCB0aGF0IGlzIGdlbmVyYXRlZCBieSBnZW5lcmF0ZUZpbGVSZWFkZXJcbiAgICAgKi9cbiAgICBhc3luYyBvbkZpbGVMb2FkSW1wb3J0KGZpbGVSZWFkZXI6IEZpbGVSZWFkZXIpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIFJlYWQgdGhlIGZpbGUgYW5kIGdldCBsaXN0IG9mIHRlYW1zIGZyb20gdGhlIGZpbGVcbiAgICAgICAgICAgIGlmICh0aGlzLmltcG9ydEZpbGU/LnR5cGUgPT09ICdhcHBsaWNhdGlvbi9qc29uJykge1xuICAgICAgICAgICAgICAgIHRoaXMuaW1wb3J0ZWRUZWFtcyA9IEpTT04ucGFyc2UoZmlsZVJlYWRlci5yZXN1bHQgYXMgc3RyaW5nKSBhcyBTdHVkZW50V2l0aFRlYW1bXTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5pbXBvcnRGaWxlPy50eXBlID09PSAndGV4dC9jc3YnKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgY3N2RW50cmllcyA9IGF3YWl0IHRoaXMucGFyc2VDU1ZGaWxlKGZpbGVSZWFkZXIucmVzdWx0IGFzIHN0cmluZyk7XG4gICAgICAgICAgICAgICAgdGhpcy5pbXBvcnRlZFRlYW1zID0gdGhpcy5jb252ZXJ0Q3N2RW50cmllcyhjc3ZFbnRyaWVzKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KCdhcnRlbWlzQXBwLnRlYW0uaW52YWxpZEZpbGVUeXBlJywgeyBmaWxlVHlwZTogdGhpcy5pbXBvcnRGaWxlPy50eXBlIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuc291cmNlVGVhbXMgPSB0aGlzLmNvbnZlcnRUZWFtcyh0aGlzLmltcG9ydGVkVGVhbXMpO1xuICAgICAgICAgICAgdGhpcy50ZWFtc0NoYW5nZWQuZW1pdCh0aGlzLnNvdXJjZVRlYW1zKTtcbiAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgLy8gQ2xlYXJpbmcgaHRtbCBlbGVtZW50cyxcbiAgICAgICAgICAgIHRoaXMuaW1wb3J0RmlsZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIHRoaXMuaW1wb3J0RmlsZU5hbWUgPSAnJztcbiAgICAgICAgICAgIGNvbnN0IGNvbnRyb2wgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnaW1wb3J0RmlsZUlucHV0JykgYXMgSFRNTElucHV0RWxlbWVudDtcbiAgICAgICAgICAgIGlmIChjb250cm9sKSB7XG4gICAgICAgICAgICAgICAgY29udHJvbC52YWx1ZSA9ICcnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBgJHt0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnYXJ0ZW1pc0FwcC50ZWFtLmVycm9ycy5pbXBvcnRGYWlsZWQnKX0gJHtlfWA7XG4gICAgICAgICAgICBhbGVydChtZXNzYWdlKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEFzc2lnbnMgdGhlIHVwbG9hZGVkIGltcG9ydCBmaWxlXG4gICAgICogQHBhcmFtIGV2ZW50IG9iamVjdCBjb250YWluaW5nIHRoZSB1cGxvYWRlZCBmaWxlXG4gICAgICovXG4gICAgc2V0SW1wb3J0RmlsZShldmVudDogYW55KTogdm9pZCB7XG4gICAgICAgIGlmIChldmVudC50YXJnZXQuZmlsZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICBjb25zdCBmaWxlTGlzdDogRmlsZUxpc3QgPSBldmVudC50YXJnZXQuZmlsZXM7XG4gICAgICAgICAgICB0aGlzLmltcG9ydEZpbGUgPSBmaWxlTGlzdFswXTtcbiAgICAgICAgICAgIHRoaXMuaW1wb3J0RmlsZU5hbWUgPSB0aGlzLmltcG9ydEZpbGUubmFtZTtcbiAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLmltcG9ydEZpbGUpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmaWxlUmVhZGVyID0gdGhpcy5nZW5lcmF0ZUZpbGVSZWFkZXIoKTtcbiAgICAgICAgZmlsZVJlYWRlci5vbmxvYWQgPSAoKSA9PiB0aGlzLm9uRmlsZUxvYWRJbXBvcnQoZmlsZVJlYWRlcik7XG4gICAgICAgIGZpbGVSZWFkZXIucmVhZEFzVGV4dCh0aGlzLmltcG9ydEZpbGUpO1xuICAgICAgICB0aGlzLmNoYW5nZURldGVjdG9yLmRldGVjdENoYW5nZXMoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBQYXJzZXMgYSBjc3YgZmlsZSBhbmQgcmV0dXJucyBhIHByb21pc2Ugd2l0aCBhIGxpc3Qgb2Ygcm93c1xuICAgICAqIEBwYXJhbSBjc3YgRmlsZSBjb250ZW50IHRoYXQgc2hvdWxkIGJlIHBhcnNlZFxuICAgICAqL1xuICAgIHByaXZhdGUgcGFyc2VDU1ZGaWxlKGNzdjogc3RyaW5nKTogUHJvbWlzZTxDc3ZFbnRyeVtdPiB7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICBwYXJzZShjc3YsIHtcbiAgICAgICAgICAgICAgICBkb3dubG9hZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgaGVhZGVyOiB0cnVlLFxuICAgICAgICAgICAgICAgIHRyYW5zZm9ybUhlYWRlcjogKGhlYWRlcjogc3RyaW5nKSA9PiBoZWFkZXIudG9Mb3dlckNhc2UoKS5yZXBsYWNlKCcgJywgJycpLnJlcGxhY2UoJ18nLCAnJyksXG4gICAgICAgICAgICAgICAgc2tpcEVtcHR5TGluZXM6IHRydWUsXG4gICAgICAgICAgICAgICAgY29tcGxldGU6IChyZXN1bHRzKSA9PiByZXNvbHZlKHJlc3VsdHMuZGF0YSBhcyBDc3ZFbnRyeVtdKSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKGVycm9yOiBhbnkpID0+IHJlamVjdChlcnJvciksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUGFyc2UgdGhlIGNvbnRlbnQgb2YgYSBjc3YgZmlsZSB0byBzdHVkZW50cyB3aXRoIHRlYW1zXG4gICAgICogQHBhcmFtIGVudHJpZXMgQWxsIGVudHJpZXMgb2YgdGhlIGNzdiBmaWxlXG4gICAgICovXG4gICAgY29udmVydENzdkVudHJpZXMoZW50cmllczogQ3N2RW50cnlbXSk6IFN0dWRlbnRXaXRoVGVhbVtdIHtcbiAgICAgICAgcmV0dXJuIGVudHJpZXMubWFwKFxuICAgICAgICAgICAgKGVudHJ5KSA9PlxuICAgICAgICAgICAgICAgICh7XG4gICAgICAgICAgICAgICAgICAgIHJlZ2lzdHJhdGlvbk51bWJlcjogZW50cnlbY3N2Q29sdW1ucy5yZWdpc3RyYXRpb25OdW1iZXJdIHx8IGVudHJ5W2NzdkNvbHVtbnMubWF0cmlrZWxOdW1tZXJdIHx8IGVudHJ5W2NzdkNvbHVtbnMubWF0cmljdWxhdGlvbk51bWJlcl0gfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICB1c2VybmFtZTpcbiAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5W2NzdkNvbHVtbnMubG9naW5dIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICBlbnRyeVtjc3ZDb2x1bW5zLnVzZXJuYW1lXSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgZW50cnlbY3N2Q29sdW1ucy51c2VyXSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgZW50cnlbY3N2Q29sdW1ucy5iZW51dHplcl0gfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5W2NzdkNvbHVtbnMuYmVudXR6ZXJOYW1lXSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICBmaXJzdE5hbWU6IGVudHJ5W2NzdkNvbHVtbnMuZmlyc3ROYW1lXSB8fCBlbnRyeVtjc3ZDb2x1bW5zLnZvcm5hbWVdIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgbGFzdE5hbWU6XG4gICAgICAgICAgICAgICAgICAgICAgICBlbnRyeVtjc3ZDb2x1bW5zLmxhc3ROYW1lXSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgZW50cnlbY3N2Q29sdW1ucy5mYW1pbHlOYW1lXSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgZW50cnlbY3N2Q29sdW1ucy5zdXJuYW1lXSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgZW50cnlbY3N2Q29sdW1ucy5uYW1lXSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgZW50cnlbY3N2Q29sdW1ucy5uYWNobmFtZV0gfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgdGVhbU5hbWU6IGVudHJ5W2NzdkNvbHVtbnMudGVhbU5hbWVdIHx8IGVudHJ5W2NzdkNvbHVtbnMudGVhbV0gfHwgZW50cnlbY3N2Q29sdW1ucy5ncnVwcGVdIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB9KSBhcyBTdHVkZW50V2l0aFRlYW0sXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ29udmVydCBpbXBvcnRlZCB0ZWFtIGxpc3QgdG8gbm9ybWFsIHRlYW1zXG4gICAgICovXG4gICAgY29udmVydFRlYW1zKGltcG9ydFRlYW06IFN0dWRlbnRXaXRoVGVhbVtdKTogVGVhbVtdIHtcbiAgICAgICAgY29uc3QgdGVhbXM6IFRlYW1bXSA9IFtdO1xuICAgICAgICBpbXBvcnRUZWFtLmZvckVhY2goKHN0dWRlbnQsIGluZGV4KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXdTdHVkZW50ID0gbmV3IFVzZXIoKTtcbiAgICAgICAgICAgIG5ld1N0dWRlbnQuZmlyc3ROYW1lID0gc3R1ZGVudC5maXJzdE5hbWUgPz8gJyc7XG4gICAgICAgICAgICBuZXdTdHVkZW50Lmxhc3ROYW1lID0gc3R1ZGVudC5sYXN0TmFtZSA/PyAnJztcbiAgICAgICAgICAgIG5ld1N0dWRlbnQudmlzaWJsZVJlZ2lzdHJhdGlvbk51bWJlciA9IHN0dWRlbnQucmVnaXN0cmF0aW9uTnVtYmVyO1xuICAgICAgICAgICAgbmV3U3R1ZGVudC5sb2dpbiA9IHN0dWRlbnQudXNlcm5hbWU7XG4gICAgICAgICAgICBjb25zdCBlbnRyeU5yID0gaW5kZXggKyAxO1xuXG4gICAgICAgICAgICBpZiAoKHR5cGVvZiBzdHVkZW50LnVzZXJuYW1lICE9PSAnc3RyaW5nJyB8fCAhc3R1ZGVudC51c2VybmFtZS50cmltKCkpICYmICh0eXBlb2Ygc3R1ZGVudC5yZWdpc3RyYXRpb25OdW1iZXIgIT09ICdzdHJpbmcnIHx8ICFzdHVkZW50LnJlZ2lzdHJhdGlvbk51bWJlci50cmltKCkpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KCdhcnRlbWlzQXBwLnRlYW0ubWlzc2luZ1VzZXJOYW1lT3JJZCcsIHsgZW50cnlOciB9KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBuZXdTdHVkZW50Lm5hbWUgPSBgJHtuZXdTdHVkZW50LmZpcnN0TmFtZX0gJHtuZXdTdHVkZW50Lmxhc3ROYW1lfWAudHJpbSgpO1xuXG4gICAgICAgICAgICBpZiAodHlwZW9mIHN0dWRlbnQudGVhbU5hbWUgIT09ICdzdHJpbmcnIHx8ICFzdHVkZW50LnRlYW1OYW1lLnRyaW0oKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcih0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnYXJ0ZW1pc0FwcC50ZWFtLnRlYW1OYW1lLm1pc3NpbmdUZWFtTmFtZScsIHsgZW50cnlOciwgc3R1ZGVudE5hbWU6IG5ld1N0dWRlbnQubmFtZSB9KSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IHNob3J0TmFtZSA9IHN0dWRlbnQudGVhbU5hbWUucmVwbGFjZSgvW14wLTlhLXpdL2dpLCAnJykudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgIGlmICghc2hvcnROYW1lLm1hdGNoKFNIT1JUX05BTUVfUEFUVEVSTikpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IodGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQoJ2FydGVtaXNBcHAudGVhbS50ZWFtTmFtZS5wYXR0ZXJuJywgeyBlbnRyeU5yLCB0ZWFtTmFtZTogc2hvcnROYW1lIH0pKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgdGVhbUluZGV4ID0gdGVhbXMuZmluZEluZGV4KCh0ZWFtKSA9PiB0ZWFtLm5hbWUgPT09IHN0dWRlbnQudGVhbU5hbWUpO1xuICAgICAgICAgICAgaWYgKHRlYW1JbmRleCA9PT0gLTEpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXdUZWFtID0gbmV3IFRlYW0oKTtcbiAgICAgICAgICAgICAgICBuZXdUZWFtLm5hbWUgPSBzdHVkZW50LnRlYW1OYW1lO1xuICAgICAgICAgICAgICAgIG5ld1RlYW0uc2hvcnROYW1lID0gc2hvcnROYW1lO1xuICAgICAgICAgICAgICAgIG5ld1RlYW0uc3R1ZGVudHMgPSBbbmV3U3R1ZGVudF07XG4gICAgICAgICAgICAgICAgdGVhbXMucHVzaChuZXdUZWFtKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGVhbXNbdGVhbUluZGV4XS5zdHVkZW50cyA9IFsuLi50ZWFtc1t0ZWFtSW5kZXhdLnN0dWRlbnRzISwgbmV3U3R1ZGVudF07XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdGVhbXM7XG4gICAgfVxufVxuIiwiPGRpdj5cbiAgICA8bGFiZWwgY2xhc3M9XCJsYWJlbC1uYXJyb3dcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0uc291cmNlRmlsZS5sYWJlbFwiPlNvdXJjZSBmaWxlPC9sYWJlbD5cbiAgICA8amhpLWhlbHAtaWNvbiB0ZXh0PVwiYXJ0ZW1pc0FwcC50ZWFtLnNvdXJjZUZpbGUudG9vbHRpcFwiIGNsYXNzPVwibWUtMVwiPjwvamhpLWhlbHAtaWNvbj5cbiAgICBAaWYgKGxvYWRpbmcpIHtcbiAgICAgICAgPGZhLWljb24gY2xhc3M9XCJsb2FkaW5nLXNwaW5uZXJcIiBbaWNvbl09XCJmYVNwaW5uZXJcIiBbc3Bpbl09XCJ0cnVlXCI+PC9mYS1pY29uPlxuICAgIH1cbjwvZGl2PlxuPGRpdiBjbGFzcz1cImN1c3RvbS1maWxlXCI+XG4gICAgPGlucHV0IGlkPVwiaW1wb3J0RmlsZUlucHV0XCIgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCIuanNvbiwuY3N2XCIgY2xhc3M9XCJjdXN0b20tZmlsZS1pbnB1dFwiIChjaGFuZ2UpPVwic2V0SW1wb3J0RmlsZSgkZXZlbnQpXCIgcGxhY2Vob2xkZXI9XCJVcGxvYWQgZmlsZS4uLlwiIC8+XG48L2Rpdj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uRGVzdHJveSwgT25Jbml0LCBWaWV3Q2hpbGQsIFZpZXdFbmNhcHN1bGF0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOZ0Zvcm0gfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBOZ2JBY3RpdmVNb2RhbCB9IGZyb20gJ0BuZy1ib290c3RyYXAvbmctYm9vdHN0cmFwJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgVGVhbVNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0uc2VydmljZSc7XG5pbXBvcnQgeyBUZWFtSW1wb3J0U3RyYXRlZ3lUeXBlIGFzIEltcG9ydFN0cmF0ZWd5LCBUZWFtIH0gZnJvbSAnYXBwL2VudGl0aWVzL3RlYW0ubW9kZWwnO1xuaW1wb3J0IHsgRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgQWN0aW9uVHlwZSB9IGZyb20gJ2FwcC9zaGFyZWQvZGVsZXRlLWRpYWxvZy9kZWxldGUtZGlhbG9nLm1vZGVsJztcbmltcG9ydCB7IGZsYXRNYXAgfSBmcm9tICdsb2Rhc2gtZXMnO1xuaW1wb3J0IHsgVXNlciB9IGZyb20gJ2FwcC9jb3JlL3VzZXIvdXNlci5tb2RlbCc7XG5pbXBvcnQgeyBmYUJhbiwgZmFDaXJjbGVOb3RjaCwgZmFTcGlubmVyLCBmYVVwbG9hZCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXRlYW1zLWltcG9ydC1kaWFsb2cnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi90ZWFtcy1pbXBvcnQtZGlhbG9nLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi90ZWFtcy1pbXBvcnQtZGlhbG9nLmNvbXBvbmVudC5zY3NzJ10sXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcbn0pXG5leHBvcnQgY2xhc3MgVGVhbXNJbXBvcnREaWFsb2dDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gICAgcmVhZG9ubHkgSW1wb3J0U3RyYXRlZ3kgPSBJbXBvcnRTdHJhdGVneTtcbiAgICByZWFkb25seSBBY3Rpb25UeXBlID0gQWN0aW9uVHlwZTtcblxuICAgIEBWaWV3Q2hpbGQoJ2ltcG9ydEZvcm0nLCB7IHN0YXRpYzogZmFsc2UgfSkgaW1wb3J0Rm9ybTogTmdGb3JtO1xuXG4gICAgQElucHV0KCkgZXhlcmNpc2U6IEV4ZXJjaXNlO1xuICAgIEBJbnB1dCgpIHRlYW1zOiBUZWFtW107IC8vIGV4aXN0aW5nIHRlYW1zIGFscmVhZHkgaW4gZXhlcmNpc2VcblxuICAgIHNvdXJjZUV4ZXJjaXNlPzogRXhlcmNpc2U7XG5cbiAgICBzZWFyY2hpbmdFeGVyY2lzZXMgPSBmYWxzZTtcbiAgICBzZWFyY2hpbmdFeGVyY2lzZXNGYWlsZWQgPSBmYWxzZTtcbiAgICBzZWFyY2hpbmdFeGVyY2lzZXNOb1Jlc3VsdHNGb3JRdWVyeT86IHN0cmluZztcblxuICAgIHNvdXJjZVRlYW1zPzogVGVhbVtdO1xuICAgIGxvYWRpbmdTb3VyY2VUZWFtcyA9IGZhbHNlO1xuICAgIGxvYWRpbmdTb3VyY2VUZWFtc0ZhaWxlZCA9IGZhbHNlO1xuXG4gICAgaW1wb3J0U3RyYXRlZ3k/OiBJbXBvcnRTdHJhdGVneTtcbiAgICByZWFkb25seSBkZWZhdWx0SW1wb3J0U3RyYXRlZ3k6IEltcG9ydFN0cmF0ZWd5ID0gSW1wb3J0U3RyYXRlZ3kuQ1JFQVRFX09OTFk7XG5cbiAgICBpc0ltcG9ydGluZyA9IGZhbHNlO1xuICAgIHNob3dJbXBvcnRGcm9tRXhlcmNpc2UgPSB0cnVlO1xuXG4gICAgLy8gY29tcHV0ZWQgcHJvcGVydGllc1xuICAgIHRlYW1TaG9ydE5hbWVzQWxyZWFkeUV4aXN0aW5nSW5FeGVyY2lzZTogc3RyaW5nW10gPSBbXTtcbiAgICBzb3VyY2VUZWFtc0ZyZWVPZkNvbmZsaWN0czogVGVhbVtdID0gW107XG5cbiAgICBjb25mbGljdGluZ1JlZ2lzdHJhdGlvbk51bWJlcnNTZXQ6IFNldDxzdHJpbmc+ID0gbmV3IFNldDxzdHJpbmc+KCk7XG5cbiAgICBjb25mbGljdGluZ0xvZ2luc1NldDogU2V0PHN0cmluZz4gPSBuZXcgU2V0PHN0cmluZz4oKTtcblxuICAgIHN0dWRlbnRzQXBwZWFySW5NdWx0aXBsZVRlYW1zID0gZmFsc2U7XG5cbiAgICBwcml2YXRlIGRpYWxvZ0Vycm9yU291cmNlID0gbmV3IFN1YmplY3Q8c3RyaW5nPigpO1xuICAgIGRpYWxvZ0Vycm9yJCA9IHRoaXMuZGlhbG9nRXJyb3JTb3VyY2UuYXNPYnNlcnZhYmxlKCk7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhQmFuID0gZmFCYW47XG4gICAgZmFTcGlubmVyID0gZmFTcGlubmVyO1xuICAgIGZhQ2lyY2xlTm90Y2ggPSBmYUNpcmNsZU5vdGNoO1xuICAgIGZhVXBsb2FkID0gZmFVcGxvYWQ7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSB0ZWFtU2VydmljZTogVGVhbVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgYWN0aXZlTW9kYWw6IE5nYkFjdGl2ZU1vZGFsLFxuICAgICAgICBwcml2YXRlIGFsZXJ0U2VydmljZTogQWxlcnRTZXJ2aWNlLFxuICAgICkge31cblxuICAgIC8qKlxuICAgICAqIExpZmUgY3ljbGUgaG9vayB0byBpbmRpY2F0ZSBjb21wb25lbnQgY3JlYXRpb24gaXMgZG9uZVxuICAgICAqL1xuICAgIG5nT25Jbml0KCkge1xuICAgICAgICB0aGlzLmNvbXB1dGVQb3RlbnRpYWxDb25mbGljdHNCYXNlZE9uRXhpc3RpbmdUZWFtcygpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIExpZmUgY3ljbGUgaG9vayB0byBpbmRpY2F0ZSBjb21wb25lbnQgZGVzdHJ1Y3Rpb24gaXMgZG9uZVxuICAgICAqL1xuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgICAgICB0aGlzLmRpYWxvZ0Vycm9yU291cmNlLnVuc3Vic2NyaWJlKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTG9hZCB0ZWFtcyBmcm9tIHNvdXJjZSBleGVyY2lzZVxuICAgICAqIEBwYXJhbSB7RXhlcmNpc2V9IHNvdXJjZUV4ZXJjaXNlIC0gU291cmNlIGV4ZXJjaXNlIHRvIGxvYWQgdGVhbXMgZnJvbVxuICAgICAqL1xuICAgIGxvYWRTb3VyY2VUZWFtcyhzb3VyY2VFeGVyY2lzZTogRXhlcmNpc2UpIHtcbiAgICAgICAgdGhpcy5zb3VyY2VUZWFtcyA9IHVuZGVmaW5lZDtcbiAgICAgICAgdGhpcy5sb2FkaW5nU291cmNlVGVhbXMgPSB0cnVlO1xuICAgICAgICB0aGlzLmxvYWRpbmdTb3VyY2VUZWFtc0ZhaWxlZCA9IGZhbHNlO1xuICAgICAgICB0aGlzLnRlYW1TZXJ2aWNlLmZpbmRBbGxCeUV4ZXJjaXNlSWQoc291cmNlRXhlcmNpc2UuaWQhKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKHRlYW1zUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnNvdXJjZVRlYW1zID0gdGVhbXNSZXNwb25zZS5ib2R5ITtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbXB1dGVTb3VyY2VUZWFtc0ZyZWVPZkNvbmZsaWN0cygpO1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZ1NvdXJjZVRlYW1zID0gZmFsc2U7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZXJyb3I6ICgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmdTb3VyY2VUZWFtcyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZ1NvdXJjZVRlYW1zRmFpbGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE1ldGhvZCBpcyBjYWxsZWQgd2hlbiB0aGUgdXNlciBoYXMgc2VsZWN0ZWQgYW4gZXhlcmNpc2UgdXNpbmcgdGhlIGF1dG9jb21wbGV0ZSBzZWxlY3QgZmllbGRcbiAgICAgKlxuICAgICAqIFRoZSBpbXBvcnQgc3RyYXRlZ3kgaXMgcmVzZXQgYW5kIHRoZSBzb3VyY2UgdGVhbXMgYXJlIGxvYWRlZCBmb3IgdGhlIHNlbGVjdGVkIGV4ZXJjaXNlXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZXhlcmNpc2UgRXhlcmNpc2UgdGhhdCB3YXMgc2VsZWN0ZWQgYXMgYSBzb3VyY2UgZXhlcmNpc2VcbiAgICAgKi9cbiAgICBvblNlbGVjdFNvdXJjZUV4ZXJjaXNlKGV4ZXJjaXNlOiBFeGVyY2lzZSkge1xuICAgICAgICB0aGlzLnNvdXJjZUV4ZXJjaXNlID0gZXhlcmNpc2U7XG4gICAgICAgIHRoaXMuaW5pdEltcG9ydFN0cmF0ZWd5KCk7XG4gICAgICAgIHRoaXMubG9hZFNvdXJjZVRlYW1zKGV4ZXJjaXNlKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBJZiB0aGUgZXhlcmNpc2UgaGFzIG5vIHRlYW1zIHlldCwgdGhlIHVzZXIgZG9lc24ndCBoYXZlIHRvIGNob29zZSBhbiBpbXBvcnQgc3RyYXRlZ3lcbiAgICAgKiBzaW5jZSB0aGVyZSBpcyBubyBuZWVkIGZvciBjb25mbGljdCBoYW5kbGluZyBkZWNpc2lvbnMgd2hlbiBubyB0ZWFtcyBleGlzdCB5ZXQuXG4gICAgICovXG4gICAgaW5pdEltcG9ydFN0cmF0ZWd5KCkge1xuICAgICAgICB0aGlzLmltcG9ydFN0cmF0ZWd5ID0gdGhpcy50ZWFtcy5sZW5ndGggPT09IDAgPyB0aGlzLmRlZmF1bHRJbXBvcnRTdHJhdGVneSA6IHVuZGVmaW5lZDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDb21wdXRlcyBsaXN0cyBvZiBwb3RlbnRpYWwgY29uZmxpY3Qgc291cmNlczpcbiAgICAgKiAxLiBUaGUgZXhpc3RpbmcgdGVhbSBzaG9ydCBuYW1lcyBvZiB0ZWFtIGFscmVhZHkgaW4gdGhpcyBleGVyY2lzZVxuICAgICAqIDIuIFRoZSBsb2dpbnMgb2Ygc3R1ZGVudHMgd2hvIGFscmVhZHkgYmVsb25nIHRvIHRlYW1zIG9mIHRoaXMgZXhlcmNpc2VcbiAgICAgKiAzLiBSZWdpc3RyYXRpb24gbnVtYmVycyBvZiBzdHVkZW50cyB3aG8gYWxyZWFkeSBiZWxvbmcgdG8gdGVhbXMgb2YgdGhpcyBleGVyY2lzZVxuICAgICAqL1xuICAgIGNvbXB1dGVQb3RlbnRpYWxDb25mbGljdHNCYXNlZE9uRXhpc3RpbmdUZWFtcygpIHtcbiAgICAgICAgdGhpcy50ZWFtU2hvcnROYW1lc0FscmVhZHlFeGlzdGluZ0luRXhlcmNpc2UgPSB0aGlzLnRlYW1zLm1hcCgodGVhbSkgPT4gdGVhbS5zaG9ydE5hbWUhKTtcbiAgICAgICAgY29uc3Qgc3R1ZGVudExvZ2luc0FscmVhZHlFeGlzdGluZ0luRXhlcmNpc2UgPSBmbGF0TWFwKHRoaXMudGVhbXMsICh0ZWFtKSA9PiB0ZWFtLnN0dWRlbnRzIS5tYXAoKHN0dWRlbnQpID0+IHN0dWRlbnQubG9naW4hKSk7XG4gICAgICAgIGNvbnN0IHN0dWRlbnRSZWdpc3RyYXRpb25OdW1iZXJzQWxyZWFkeUV4aXN0aW5nSW5FeGVyY2lzZSA9IGZsYXRNYXAodGhpcy50ZWFtcywgKHRlYW0pID0+IHRlYW0uc3R1ZGVudHMhLm1hcCgoc3R1ZGVudCkgPT4gc3R1ZGVudC52aXNpYmxlUmVnaXN0cmF0aW9uTnVtYmVyIHx8ICcnKSk7XG4gICAgICAgIHRoaXMuY29uZmxpY3RpbmdSZWdpc3RyYXRpb25OdW1iZXJzU2V0ID0gdGhpcy5hZGRBcnJheVRvU2V0KHRoaXMuY29uZmxpY3RpbmdSZWdpc3RyYXRpb25OdW1iZXJzU2V0LCBzdHVkZW50UmVnaXN0cmF0aW9uTnVtYmVyc0FscmVhZHlFeGlzdGluZ0luRXhlcmNpc2UpO1xuICAgICAgICB0aGlzLmNvbmZsaWN0aW5nTG9naW5zU2V0ID0gdGhpcy5hZGRBcnJheVRvU2V0KHRoaXMuY29uZmxpY3RpbmdMb2dpbnNTZXQsIHN0dWRlbnRMb2dpbnNBbHJlYWR5RXhpc3RpbmdJbkV4ZXJjaXNlKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDb21wdXRlcyBhIGxpc3Qgb2YgYWxsIHNvdXJjZSB0ZWFtcyB0aGF0IGFyZSBjb25mbGljdC1mcmVlIChpLmUuIGNvdWxkIGJlIGltcG9ydGVkIHdpdGhvdXQgYW55IHByb2JsZW1zKVxuICAgICAqL1xuICAgIGNvbXB1dGVTb3VyY2VUZWFtc0ZyZWVPZkNvbmZsaWN0cygpIHtcbiAgICAgICAgdGhpcy5zb3VyY2VUZWFtc0ZyZWVPZkNvbmZsaWN0cyA9IHRoaXMuc291cmNlVGVhbXMhLmZpbHRlcigodGVhbTogVGVhbSkgPT4gdGhpcy5pc1NvdXJjZVRlYW1GcmVlT2ZBbnlDb25mbGljdHModGVhbSkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFByZWRpY2F0ZSB0aGF0IHJldHVybnMgdHJ1ZSBpZmYgdGhlIGdpdmVuIHNvdXJjZSB0ZWFtIGlzIGNvbmZsaWN0LWZyZWVcbiAgICAgKlxuICAgICAqIFRoaXMgaXMgdGhlIGNhc2UgaWYgdGhlIGZvbGxvd2luZyBjb25kaXRpb25zIGFyZSBmdWxmaWxsZWQ6XG4gICAgICogMS4gTm8gdGVhbSBzaG9ydCBuYW1lIHVuaXF1ZSBjb25zdHJhaW50IHZpb2xhdGlvblxuICAgICAqIDIuIE5vIHN0dWRlbnQgaXMgaW4gdGhlIHRlYW0gdGhhdCBpcyBhbHJlYWR5IGFzc2lnbmVkIHRvIGEgdGVhbSBvZiB0aGUgZXhlcmNpc2VcbiAgICAgKiAzLiBObyBzdHVkZW50IGluIHRoZSB0ZWFtIGlzIGFsc28gaW4gYW5vdGhlciB0ZWFtXG4gICAgICpcbiAgICAgKiBAcGFyYW0gc291cmNlVGVhbSBUZWFtIHdoaWNoIGlzIGNoZWNrZWQgZm9yIGNvbmZsaWN0c1xuICAgICAqL1xuICAgIGlzU291cmNlVGVhbUZyZWVPZkFueUNvbmZsaWN0cyhzb3VyY2VUZWFtOiBUZWFtKTogYm9vbGVhbiB7XG4gICAgICAgIC8vIFNob3J0IG5hbWUgb2Ygc291cmNlIHRlYW0gYWxyZWFkeSBleGlzdHMgYW1vbmcgdGVhbXMgb2YgZGVzdGluYXRpb24gZXhlcmNpc2VcbiAgICAgICAgaWYgKHRoaXMudGVhbVNob3J0TmFtZXNBbHJlYWR5RXhpc3RpbmdJbkV4ZXJjaXNlLmluY2x1ZGVzKHNvdXJjZVRlYW0uc2hvcnROYW1lISkpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBPbmUgb2YgdGhlIHN0dWRlbnRzIG9mIHRoZSBzb3VyY2UgdGVhbSBpcyBhbHJlYWR5IHBhcnQgb2YgYSB0ZWFtIGluIHRoZSBkZXN0aW5hdGlvbiBleGVyY2lzZVxuICAgICAgICBpZiAoc291cmNlVGVhbS5zdHVkZW50cyEuc29tZSgoc3R1ZGVudCkgPT4gc3R1ZGVudC5sb2dpbiAmJiB0aGlzLmNvbmZsaWN0aW5nTG9naW5zU2V0LmhhcyhzdHVkZW50LmxvZ2luKSkpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIE9uZSBvZiB0aGUgc3R1ZGVudHMgb2YgdGhlIHNvdXJjZSB0ZWFtIGlzIGFscmVhZHkgcGFydCBvZiBhIHRlYW0gaW4gdGhlIGRlc3RpbmF0aW9uIGV4ZXJjaXNlIG9yIG9mIGFub3RoZXIgaW1wb3J0ZWQgdGVhbVxuICAgICAgICBpZiAoIXRoaXMuc2hvd0ltcG9ydEZyb21FeGVyY2lzZSkge1xuICAgICAgICAgICAgaWYgKHNvdXJjZVRlYW0uc3R1ZGVudHMhLnNvbWUoKHN0dWRlbnQpID0+IHN0dWRlbnQudmlzaWJsZVJlZ2lzdHJhdGlvbk51bWJlciAmJiB0aGlzLmNvbmZsaWN0aW5nUmVnaXN0cmF0aW9uTnVtYmVyc1NldC5oYXMoc3R1ZGVudC52aXNpYmxlUmVnaXN0cmF0aW9uTnVtYmVyKSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBUaGlzIHNvdXJjZSB0ZWFtIGNhbiBiZSBpbXBvcnRlZCB3aXRob3V0IGFueSBpc3N1ZXNcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgZ2V0IG51bWJlck9mQ29uZmxpY3RGcmVlU291cmNlVGVhbXMoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc291cmNlVGVhbXNGcmVlT2ZDb25mbGljdHMubGVuZ3RoO1xuICAgIH1cblxuICAgIGdldCBudW1iZXJPZlRlYW1zVG9CZURlbGV0ZWQoKSB7XG4gICAgICAgIHN3aXRjaCAodGhpcy5pbXBvcnRTdHJhdGVneSkge1xuICAgICAgICAgICAgY2FzZSBJbXBvcnRTdHJhdGVneS5QVVJHRV9FWElTVElORzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy50ZWFtcy5sZW5ndGg7XG4gICAgICAgICAgICBjYXNlIEltcG9ydFN0cmF0ZWd5LkNSRUFURV9PTkxZOlxuICAgICAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZ2V0IG51bWJlck9mVGVhbXNUb0JlSW1wb3J0ZWQoKSB7XG4gICAgICAgIHN3aXRjaCAodGhpcy5pbXBvcnRTdHJhdGVneSkge1xuICAgICAgICAgICAgY2FzZSBJbXBvcnRTdHJhdGVneS5QVVJHRV9FWElTVElORzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5zb3VyY2VUZWFtcyEubGVuZ3RoO1xuICAgICAgICAgICAgY2FzZSBJbXBvcnRTdHJhdGVneS5DUkVBVEVfT05MWTpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5udW1iZXJPZkNvbmZsaWN0RnJlZVNvdXJjZVRlYW1zO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZ2V0IG51bWJlck9mVGVhbXNBZnRlckltcG9ydCgpIHtcbiAgICAgICAgc3dpdGNoICh0aGlzLmltcG9ydFN0cmF0ZWd5KSB7XG4gICAgICAgICAgICBjYXNlIEltcG9ydFN0cmF0ZWd5LlBVUkdFX0VYSVNUSU5HOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnNvdXJjZVRlYW1zIS5sZW5ndGg7XG4gICAgICAgICAgICBjYXNlIEltcG9ydFN0cmF0ZWd5LkNSRUFURV9PTkxZOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnRlYW1zLmxlbmd0aCArIHRoaXMubnVtYmVyT2ZDb25mbGljdEZyZWVTb3VyY2VUZWFtcztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENvbXB1dGVkIGZsYWcgd2hldGhlciB0byBwcm9tcHQgdGhlIHVzZXIgdG8gcGljayBhbiBpbXBvcnQgc3RyYXRlZ3kuXG4gICAgICpcbiAgICAgKiBDb25kaXRpb25zIHRoYXQgbmVlZCB0byBiZSBmdWxmaWxsZWQgaW4gb3JkZXIgZm9yIHRoZSBzdHJhdGVneSBjaG9pY2VzIHRvIHNob3c6XG4gICAgICogMS4gQSBzb3VyY2UgZXhlcmNpc2UgaGFzIGJlZW4gc2VsZWN0ZWRcbiAgICAgKiAyLiBUaGUgc291cmNlIGV4ZXJjaXNlIGhhcyB0ZWFtcyB0aGF0IGNvdWxkIGJlIGltcG9ydGVkXG4gICAgICogMy4gVGhlIGN1cnJlbnQgZXhlcmNpc2UgYWxyZWFkeSBoYXMgZXhpc3RpbmcgdGVhbXMgaW4gaXRcbiAgICAgKi9cbiAgICBnZXQgc2hvd0ltcG9ydFN0cmF0ZWd5Q2hvaWNlcygpOiBib29sZWFuIHtcbiAgICAgICAgaWYgKHRoaXMuc2hvd0ltcG9ydEZyb21FeGVyY2lzZSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc291cmNlRXhlcmNpc2UgIT09IHVuZGVmaW5lZCAmJiB0aGlzLnNvdXJjZVRlYW1zICE9PSB1bmRlZmluZWQgJiYgdGhpcy5zb3VyY2VUZWFtcy5sZW5ndGggPiAwICYmIHRoaXMudGVhbXMubGVuZ3RoID4gMDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5zb3VyY2VUZWFtcyAhPT0gdW5kZWZpbmVkICYmIHRoaXMuc291cmNlVGVhbXMubGVuZ3RoID4gMCAmJiB0aGlzLnRlYW1zLmxlbmd0aCA+IDA7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlIHRoZSBzdHJhdGVneSB0byB1c2UgZm9yIGltcG9ydGluZ1xuICAgICAqIEBwYXJhbSB7SW1wb3J0U3RyYXRlZ3l9IGltcG9ydFN0cmF0ZWd5IC0gU3RyYXRlZ3kgdG8gdXNlXG4gICAgICovXG4gICAgdXBkYXRlSW1wb3J0U3RyYXRlZ3koaW1wb3J0U3RyYXRlZ3k6IEltcG9ydFN0cmF0ZWd5KSB7XG4gICAgICAgIHRoaXMuaW1wb3J0U3RyYXRlZ3kgPSBpbXBvcnRTdHJhdGVneTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDb21wdXRlZCBmbGFnIHdoZXRoZXIgdG8gc2hvdyB0aGUgaW1wb3J0IHByZXZpZXcgbnVtYmVycyBpbiB0aGUgZm9vdGVyIG9mIHRoZSBtb2RhbFxuICAgICAqL1xuICAgIGdldCBzaG93SW1wb3J0UHJldmlld051bWJlcnMoKTogYm9vbGVhbiB7XG4gICAgICAgIGlmICh0aGlzLnNob3dJbXBvcnRGcm9tRXhlcmNpc2UpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnNvdXJjZUV4ZXJjaXNlICE9PSB1bmRlZmluZWQgJiYgdGhpcy5zb3VyY2VUZWFtcyAhPT0gdW5kZWZpbmVkICYmIHRoaXMuc291cmNlVGVhbXMubGVuZ3RoID4gMCAmJiBCb29sZWFuKHRoaXMuaW1wb3J0U3RyYXRlZ3kpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLnN0dWRlbnRzQXBwZWFySW5NdWx0aXBsZVRlYW1zIHx8ICh0aGlzLnNvdXJjZVRlYW1zICE9PSB1bmRlZmluZWQgJiYgdGhpcy5zb3VyY2VUZWFtcy5sZW5ndGggPiAwICYmIEJvb2xlYW4odGhpcy5pbXBvcnRTdHJhdGVneSkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFRoZSBpbXBvcnQgYnV0dG9uIGlzIGRpc2FibGVkIGlmIG9uZSBvZiB0aGUgZm9sbG93aW5nIGNvbmRpdGlvbnMgYXBwbHk6XG4gICAgICpcbiAgICAgKiAxLiBJbXBvcnQgaXMgYWxyZWFkeSBpbiBwcm9ncmVzc1xuICAgICAqIDIuIE5vIHNvdXJjZSBleGVyY2lzZSBoYXMgYmVlbiBzZWxlY3RlZCB5ZXRcbiAgICAgKiAzLiBTb3VyY2UgdGVhbXMgaGF2ZSBub3QgYmVlbiBsb2FkZWQgeWV0XG4gICAgICogNC4gTm8gaW1wb3J0IHN0cmF0ZWd5IGhhcyBiZWVuIGNob3NlbiB5ZXRcbiAgICAgKiA1LiBUaGVyZSBhcmUgbm8gKGNvbmZsaWN0LWZyZWUgZGVwZW5kaW5nIG9uIHN0cmF0ZWd5KSBzb3VyY2UgdGVhbXMgdG8gYmUgaW1wb3J0ZWRcbiAgICAgKiA2LiBTdHVkZW50J3MgcmVnaXN0cmF0aW9uIG51bWJlciBhcHBlYXJzIG1vcmUgdGhhbiBvbmNlXG4gICAgICogNy4gU3R1ZGVudCdzIGxvZ2luIGFwcGVhcnMgbW9yZSB0aGFuIG9uY2VcbiAgICAgKi9cbiAgICBnZXQgaXNTdWJtaXREaXNhYmxlZCgpOiBib29sZWFuIHtcbiAgICAgICAgaWYgKHRoaXMuc2hvd0ltcG9ydEZyb21FeGVyY2lzZSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuaXNJbXBvcnRpbmcgfHwgIXRoaXMuc291cmNlRXhlcmNpc2UgfHwgIXRoaXMuc291cmNlVGVhbXMgfHwgIXRoaXMuaW1wb3J0U3RyYXRlZ3kgfHwgIXRoaXMubnVtYmVyT2ZUZWFtc1RvQmVJbXBvcnRlZDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gIXRoaXMuc291cmNlVGVhbXMgfHwgdGhpcy5zb3VyY2VUZWFtcy5sZW5ndGggPT09IDAgfHwgIXRoaXMuaW1wb3J0U3RyYXRlZ3kgfHwgIXRoaXMubnVtYmVyT2ZUZWFtc1RvQmVJbXBvcnRlZCB8fCB0aGlzLnN0dWRlbnRzQXBwZWFySW5NdWx0aXBsZVRlYW1zO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENhbmNlbCB0aGUgaW1wb3J0IGRpYWxvZ1xuICAgICAqL1xuICAgIGNsZWFyKCkge1xuICAgICAgICB0aGlzLmFjdGl2ZU1vZGFsLmRpc21pc3MoJ2NhbmNlbCcpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE1ldGhvZCBpcyBjYWxsZWQgaWYgdGhlIHN0cmF0ZWd5IFwiUHVyZ2UgZXhpc3RpbmdcIiBoYXMgYmVlbiBjaG9zZW4gYW5kIHRoZSB1c2VyIGhhcyBjb25maXJtZWQgdGhlIGRlbGV0ZSBhY3Rpb25cbiAgICAgKi9cbiAgICBwdXJnZUFuZEltcG9ydFRlYW1zKCkge1xuICAgICAgICB0aGlzLmRpYWxvZ0Vycm9yU291cmNlLm5leHQoJycpO1xuICAgICAgICB0aGlzLmltcG9ydFRlYW1zKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSXMgY2FsbGVkIHdoZW4gdGhlIHVzZXIgY2xpY2tzIG9uIFwiSW1wb3J0XCIgaW4gdGhlIG1vZGFsIGFuZCBzZW5kcyB0aGUgaW1wb3J0IHJlcXVlc3QgdG8gdGhlIHNlcnZlclxuICAgICAqL1xuICAgIGltcG9ydFRlYW1zKCkge1xuICAgICAgICBpZiAodGhpcy5pc1N1Ym1pdERpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuc2hvd0ltcG9ydEZyb21FeGVyY2lzZSkge1xuICAgICAgICAgICAgdGhpcy5pc0ltcG9ydGluZyA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLnRlYW1TZXJ2aWNlLmltcG9ydFRlYW1zRnJvbVNvdXJjZUV4ZXJjaXNlKHRoaXMuZXhlcmNpc2UsIHRoaXMuc291cmNlRXhlcmNpc2UhLCB0aGlzLmltcG9ydFN0cmF0ZWd5ISkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAocmVzKSA9PiB0aGlzLm9uU2F2ZVN1Y2Nlc3MocmVzKSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKGVycm9yKSA9PiB0aGlzLm9uU2F2ZUVycm9yKGVycm9yKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuc291cmNlVGVhbXMpIHtcbiAgICAgICAgICAgIHRoaXMucmVzZXRDb25mbGljdGluZ1NldHMoKTtcbiAgICAgICAgICAgIHRoaXMudGVhbVNlcnZpY2UuaW1wb3J0VGVhbXModGhpcy5leGVyY2lzZSwgdGhpcy5zb3VyY2VUZWFtcywgdGhpcy5pbXBvcnRTdHJhdGVneSEpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKHJlcykgPT4gdGhpcy5vblNhdmVTdWNjZXNzKHJlcyksXG4gICAgICAgICAgICAgICAgZXJyb3I6IChlcnJvcikgPT4gdGhpcy5vblNhdmVFcnJvcihlcnJvciksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZXMgc291cmNlIHRlYW1zIHRvIGdpdmVuIHRlYW1zXG4gICAgICogRmluZHMgbG9naW5zIGFuZCByZWdpc3RyYXRpb24gbnVtYmVycyB3aGljaCBhcHBlYXJzIG11bHRpcGxlIHRpbWVzXG4gICAgICogUmVzZXRzIGN1cnJlbnQgc3RhdGUgb2YgYXJyYXlzIG9mIHJlZ2lzdHJhdGlvbiBudW1iZXJzIGFuZCBsb2dpbnNcbiAgICAgKiBAcGFyYW0ge1RlYW1bXX0gZmlsZVRlYW1zIC0gVGVhbXMgd2hpY2ggaXRzIHN0dWRlbnRzIG9ubHkgaGF2ZSB2aXNpYmxlIHJlZ2lzdHJhdGlvbiBudW1iZXJcbiAgICAgKi9cbiAgICBvblRlYW1zQ2hhbmdlZChmaWxlVGVhbXM6IFRlYW1bXSkge1xuICAgICAgICB0aGlzLmluaXRJbXBvcnRTdHJhdGVneSgpO1xuICAgICAgICB0aGlzLnNvdXJjZVRlYW1zID0gZmlsZVRlYW1zO1xuICAgICAgICB0aGlzLnJlc2V0Q29uZmxpY3RpbmdTZXRzKCk7XG4gICAgICAgIGNvbnN0IHN0dWRlbnRzOiBVc2VyW10gPSBmbGF0TWFwKGZpbGVUZWFtcywgKGZpbGVUZWFtKSA9PiBmaWxlVGVhbS5zdHVkZW50cyA/PyBbXSk7XG4gICAgICAgIGNvbnN0IHN0dWRlbnRMb2dpbnNBbHJlYWR5RXhpc3RpbmdJbk90aGVyVGVhbXMgPSB0aGlzLmZpbmRJZGVudGlmaWVyc1doaWNoQXBwZWFyc011bHRpcGxlVGltZXMoc3R1ZGVudHMsICdsb2dpbicpO1xuICAgICAgICBjb25zdCBzdHVkZW50UmVnaXN0cmF0aW9uTnVtYmVyc0FscmVhZHlFeGlzdGluZ0luT3RoZXJUZWFtcyA9IHRoaXMuZmluZElkZW50aWZpZXJzV2hpY2hBcHBlYXJzTXVsdGlwbGVUaW1lcyhzdHVkZW50cywgJ3Zpc2libGVSZWdpc3RyYXRpb25OdW1iZXInKTtcbiAgICAgICAgdGhpcy5zdHVkZW50c0FwcGVhckluTXVsdGlwbGVUZWFtcyA9IHN0dWRlbnRMb2dpbnNBbHJlYWR5RXhpc3RpbmdJbk90aGVyVGVhbXMubGVuZ3RoID4gMCB8fCBzdHVkZW50UmVnaXN0cmF0aW9uTnVtYmVyc0FscmVhZHlFeGlzdGluZ0luT3RoZXJUZWFtcy5sZW5ndGggPiAwO1xuICAgICAgICB0aGlzLmNvbmZsaWN0aW5nUmVnaXN0cmF0aW9uTnVtYmVyc1NldCA9IHRoaXMuYWRkQXJyYXlUb1NldCh0aGlzLmNvbmZsaWN0aW5nUmVnaXN0cmF0aW9uTnVtYmVyc1NldCwgc3R1ZGVudFJlZ2lzdHJhdGlvbk51bWJlcnNBbHJlYWR5RXhpc3RpbmdJbk90aGVyVGVhbXMpO1xuICAgICAgICB0aGlzLmNvbmZsaWN0aW5nTG9naW5zU2V0ID0gdGhpcy5hZGRBcnJheVRvU2V0KHRoaXMuY29uZmxpY3RpbmdMb2dpbnNTZXQsIHN0dWRlbnRMb2dpbnNBbHJlYWR5RXhpc3RpbmdJbk90aGVyVGVhbXMpO1xuICAgICAgICB0aGlzLmNvbXB1dGVTb3VyY2VUZWFtc0ZyZWVPZkNvbmZsaWN0cygpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENhbGN1bGF0ZXMgd2hpY2ggaWRlbnRpZmllciBhcHBlYXJlZCBob3cgbWFueSB0aW1lcyBhbmQgcmV0dXJucyB0aG9zZSBhcHBlYXIgbW9yZSB0aGFuIG9uY2VcbiAgICAgKiBAcGFyYW0gdXNlcnMgVXNlcnMgYXJyYXkgdG8gZmluZCBpZGVudGlmaWVycyB0aGF0IGFwcGVhciBtdWx0aXBsZSB0aW1lcyBpblxuICAgICAqIEBwYXJhbSBpZGVudGlmaWVyIFdoaWNoIGlkZW50aWZpZXIgdG8gdXNlIHdoZW4gc2VhcmNoaW5nIGZvciBtdWx0aXBsZSBvY2N1cnJlbmNlc1xuICAgICAqIEByZXR1cm5zIElkZW50aWZpZXJzIHdoaWNoIGFwcGVhcmVkIG11bHRpcGxlIHRpbWVzIGluIHVzZXIgYXJyYXlcbiAgICAgKi9cbiAgICBwcml2YXRlIGZpbmRJZGVudGlmaWVyc1doaWNoQXBwZWFyc011bHRpcGxlVGltZXModXNlcnM6IFVzZXJbXSwgaWRlbnRpZmllcjogJ2xvZ2luJyB8ICd2aXNpYmxlUmVnaXN0cmF0aW9uTnVtYmVyJykge1xuICAgICAgICBjb25zdCBvY2N1cnJlbmNlTWFwID0gbmV3IE1hcCgpO1xuICAgICAgICB1c2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBpZGVudGlmaWVyVmFsdWUgPSB1c2VyW2lkZW50aWZpZXJdO1xuICAgICAgICAgICAgaWYgKGlkZW50aWZpZXJWYWx1ZSkge1xuICAgICAgICAgICAgICAgIGlmIChvY2N1cnJlbmNlTWFwLmdldChpZGVudGlmaWVyVmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgIG9jY3VycmVuY2VNYXAuc2V0KGlkZW50aWZpZXJWYWx1ZSwgb2NjdXJyZW5jZU1hcC5nZXQoaWRlbnRpZmllclZhbHVlKSArIDEpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIG9jY3VycmVuY2VNYXAuc2V0KGlkZW50aWZpZXJWYWx1ZSwgMSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIFsuLi5vY2N1cnJlbmNlTWFwLmtleXMoKV0uZmlsdGVyKChrZXkpID0+IG9jY3VycmVuY2VNYXAuZ2V0KGtleSkgPiAxKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIb29rIHRvIGluZGljYXRlIGEgc3VjY2VzcyBvbiBzYXZlXG4gICAgICogQHBhcmFtIHtIdHRwUmVzcG9uc2U8VGVhbVtdPn0gdGVhbXMgLSBTdWNjZXNzZnVsbHkgdXBkYXRlZCB0ZWFtc1xuICAgICAqL1xuICAgIG9uU2F2ZVN1Y2Nlc3ModGVhbXM6IEh0dHBSZXNwb25zZTxUZWFtW10+KSB7XG4gICAgICAgIHRoaXMuYWN0aXZlTW9kYWwuY2xvc2UodGVhbXMuYm9keSk7XG4gICAgICAgIHRoaXMuaXNJbXBvcnRpbmcgPSBmYWxzZTtcblxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLnN1Y2Nlc3MoJ2FydGVtaXNBcHAudGVhbS5pbXBvcnRTdWNjZXNzJywgeyBudW1iZXJPZkltcG9ydGVkVGVhbXM6IHRoaXMubnVtYmVyT2ZUZWFtc1RvQmVJbXBvcnRlZCB9KTtcbiAgICAgICAgfSwgNTAwKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBIb29rIHRvIGluZGljYXRlIGFuIGVycm9yIG9uIHNhdmVcbiAgICAgKiBIYW5kbGVzIHN0dWRlbnRzTm90Rm91bmQgYW5kIHN0dWRlbnRzQXBwZWFyTXVsdGlwbGVUaW1lcyBlcnJvcnNcbiAgICAgKiBTaG93cyBnZW5lcmljIGltcG9ydCBlcnJvciBtZXNzYWdlIGlmIGVycm9yIGlzIG5vdCBvbmUgb2YgdGhlIGFib3ZlXG4gICAgICogQHBhcmFtIHtIdHRwRXJyb3JSZXNwb25zZX0gaHR0cEVycm9yUmVzcG9uc2UgLSBUaGUgb2NjdXJyZWQgZXJyb3JcbiAgICAgKi9cbiAgICBvblNhdmVFcnJvcihodHRwRXJyb3JSZXNwb25zZTogSHR0cEVycm9yUmVzcG9uc2UpIHtcbiAgICAgICAgY29uc3QgeyBlcnJvcktleSwgcGFyYW1zIH0gPSBodHRwRXJyb3JSZXNwb25zZS5lcnJvcjtcbiAgICAgICAgc3dpdGNoIChlcnJvcktleSkge1xuICAgICAgICAgICAgY2FzZSAnc3R1ZGVudHNOb3RGb3VuZCc6XG4gICAgICAgICAgICAgICAgY29uc3QgeyByZWdpc3RyYXRpb25OdW1iZXJzLCBsb2dpbnMgfSA9IHBhcmFtcztcbiAgICAgICAgICAgICAgICB0aGlzLm9uU3R1ZGVudHNOb3RGb3VuZEVycm9yKHJlZ2lzdHJhdGlvbk51bWJlcnMsIGxvZ2lucyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdzdHVkZW50c0FwcGVhck11bHRpcGxlVGltZXMnOlxuICAgICAgICAgICAgICAgIGNvbnN0IHsgc3R1ZGVudHMgfSA9IHBhcmFtcztcbiAgICAgICAgICAgICAgICB0aGlzLm9uU3R1ZGVudHNBcHBlYXJNdWx0aXBsZVRpbWVzRXJyb3Ioc3R1ZGVudHMpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5lcnJvcignYXJ0ZW1pc0FwcC50ZWFtLmltcG9ydEVycm9yJyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5pc0ltcG9ydGluZyA9IGZhbHNlO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldHMgbm90IGZvdW5kIHJlZ2lzdHJhdGlvbiBudW1iZXJzIGFuZCBsb2dpbnNcbiAgICAgKiBBc3NpZ25zIHRoZW0gdG8gYXBwcm9wcmlhdGUgYXJyYXkgb24gdGhlIGNsYXNzXG4gICAgICogU2hvd3MgdXNlciB3aGljaCByZWdpc3RyYXRpb24gbnVtYmVycyBhbmQgbG9naW5zIGNvdWxkIG5vdCBiZSBmb3VuZFxuICAgICAqIEBwYXJhbSByZWdpc3RyYXRpb25OdW1iZXJzIHdpdGggd2hpY2ggYSBzdHVkZW50IGNvdWxkIG5vdCBiZSBmb3VuZFxuICAgICAqIEBwYXJhbSBsb2dpbnMgd2l0aCB3aGljaCBhIHN0dWRlbnQgY291bGQgbm90IGJlIGZvdW5kXG4gICAgICovXG4gICAgcHJpdmF0ZSBvblN0dWRlbnRzTm90Rm91bmRFcnJvcihyZWdpc3RyYXRpb25OdW1iZXJzOiBzdHJpbmdbXSwgbG9naW5zOiBzdHJpbmdbXSkge1xuICAgICAgICBjb25zdCBub3RGb3VuZFJlZ2lzdHJhdGlvbk51bWJlcnMgPSByZWdpc3RyYXRpb25OdW1iZXJzO1xuICAgICAgICBjb25zdCBub3RGb3VuZExvZ2lucyA9IGxvZ2lucztcbiAgICAgICAgaWYgKG5vdEZvdW5kUmVnaXN0cmF0aW9uTnVtYmVycy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5lcnJvcignYXJ0ZW1pc0FwcC50ZWFtLmVycm9ycy5yZWdpc3RyYXRpb25OdW1iZXJzTm90Rm91bmQnLCB7IHJlZ2lzdHJhdGlvbk51bWJlcnM6IG5vdEZvdW5kUmVnaXN0cmF0aW9uTnVtYmVycyB9KTtcbiAgICAgICAgICAgIHRoaXMuY29uZmxpY3RpbmdSZWdpc3RyYXRpb25OdW1iZXJzU2V0ID0gdGhpcy5hZGRBcnJheVRvU2V0KHRoaXMuY29uZmxpY3RpbmdSZWdpc3RyYXRpb25OdW1iZXJzU2V0LCBub3RGb3VuZFJlZ2lzdHJhdGlvbk51bWJlcnMpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChub3RGb3VuZExvZ2lucy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICB0aGlzLmFsZXJ0U2VydmljZS5lcnJvcignYXJ0ZW1pc0FwcC50ZWFtLmVycm9ycy5sb2dpbnNOb3RGb3VuZCcsIHsgbG9naW5zOiBub3RGb3VuZExvZ2lucyB9KTtcbiAgICAgICAgICAgIHRoaXMuY29uZmxpY3RpbmdMb2dpbnNTZXQgPSB0aGlzLmFkZEFycmF5VG9TZXQodGhpcy5jb25mbGljdGluZ0xvZ2luc1NldCwgbm90Rm91bmRMb2dpbnMpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0cyBwYWlycyBvZiBsb2dpbi1yZWdpc3RyYXRpb24gbnVtYmVyIG9mIHN0dWRlbnRzIHdoaWNoIGNvdWxkIG5vdCBiZSBmb3VuZFxuICAgICAqIEFzc2lnbnMgdGhlbSB0byBhcHByb3ByaWF0ZSBhcnJheSBvbiB0aGUgY2xhc3NcbiAgICAgKiBTaG93cyB1c2VyIHdoaWNoIHN0dWRlbnRzIGNvdWxkIG5vdCBiZSBmb3VuZFxuICAgICAqIEBwYXJhbSBzdHVkZW50c0FwcGVhck11bHRpcGxlVGltZXMgbG9naW4tcmVnaXN0cmF0aW9uIG51bWJlciBwYWlycyBvZiBzdHVkZW50cyB3aGljaCBjb3VsZCBub3QgYmUgZm91bmRcbiAgICAgKi9cbiAgICBwcml2YXRlIG9uU3R1ZGVudHNBcHBlYXJNdWx0aXBsZVRpbWVzRXJyb3Ioc3R1ZGVudHNBcHBlYXJNdWx0aXBsZVRpbWVzOiB7IGZpcnN0OiBzdHJpbmc7IHNlY29uZDogc3RyaW5nIH1bXSkge1xuICAgICAgICBpZiAoc3R1ZGVudHNBcHBlYXJNdWx0aXBsZVRpbWVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMuc3R1ZGVudHNBcHBlYXJJbk11bHRpcGxlVGVhbXMgPSB0cnVlO1xuICAgICAgICAgICAgY29uc3Qgc3R1ZGVudExvZ2luc0FscmVhZHlFeGlzdGluZ0luT3RoZXJUZWFtcyA9IHN0dWRlbnRzQXBwZWFyTXVsdGlwbGVUaW1lcy5tYXAoKHN0dWRlbnQpID0+IHN0dWRlbnQuZmlyc3QpO1xuICAgICAgICAgICAgdGhpcy5jb25mbGljdGluZ0xvZ2luc1NldCA9IHRoaXMuYWRkQXJyYXlUb1NldCh0aGlzLmNvbmZsaWN0aW5nTG9naW5zU2V0LCBzdHVkZW50TG9naW5zQWxyZWFkeUV4aXN0aW5nSW5PdGhlclRlYW1zKTtcbiAgICAgICAgICAgIGNvbnN0IHN0dWRlbnRSZWdpc3RyYXRpb25OdW1iZXJzQWxyZWFkeUV4aXN0aW5nSW5PdGhlclRlYW1zID0gc3R1ZGVudHNBcHBlYXJNdWx0aXBsZVRpbWVzLm1hcCgoc3R1ZGVudCkgPT4gc3R1ZGVudC5zZWNvbmQpO1xuICAgICAgICAgICAgdGhpcy5jb25mbGljdGluZ1JlZ2lzdHJhdGlvbk51bWJlcnNTZXQgPSB0aGlzLmFkZEFycmF5VG9TZXQodGhpcy5jb25mbGljdGluZ1JlZ2lzdHJhdGlvbk51bWJlcnNTZXQsIHN0dWRlbnRSZWdpc3RyYXRpb25OdW1iZXJzQWxyZWFkeUV4aXN0aW5nSW5PdGhlclRlYW1zKTtcbiAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLmVycm9yKCdhcnRlbWlzQXBwLnRlYW0uZXJyb3JzLnN0dWRlbnRzQXBwZWFyTXVsdGlwbGVUaW1lcycsIHtcbiAgICAgICAgICAgICAgICBzdHVkZW50czogc3R1ZGVudHNBcHBlYXJNdWx0aXBsZVRpbWVzLm1hcCgoc3R1ZGVudCkgPT4gYCR7c3R1ZGVudC5maXJzdH06JHtzdHVkZW50LnNlY29uZH1gKS5qb2luKCcsJyksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZSBzaG93aW5nIHdoZXRoZXIgdGhlIHNvdXJjZSBzZWxlY3Rpb24gb3IgZmlsZSBzZWxlY3Rpb24gYW5kIHJlc2V0IHZhbHVlc1xuICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gc2hvd0Zyb21FeGVyY2lzZSAtIE5ldyB2YWx1ZSB0byBzZXRcbiAgICAgKi9cbiAgICBzZXRTaG93SW1wb3J0RnJvbUV4ZXJjaXNlKHNob3dGcm9tRXhlcmNpc2U6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5zaG93SW1wb3J0RnJvbUV4ZXJjaXNlID0gc2hvd0Zyb21FeGVyY2lzZTtcbiAgICAgICAgdGhpcy5zb3VyY2VUZWFtcyA9IHVuZGVmaW5lZDtcbiAgICAgICAgdGhpcy5zb3VyY2VFeGVyY2lzZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgdGhpcy5pbml0SW1wb3J0U3RyYXRlZ3koKTtcbiAgICAgICAgdGhpcy5pc0ltcG9ydGluZyA9IGZhbHNlO1xuICAgICAgICB0aGlzLnJlc2V0Q29uZmxpY3RpbmdTZXRzKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQHJldHVybnMgQSBzYW1wbGUgdGVhbSB0aGF0IGNhbiBiZSB1c2VkIHRvIHJlbmRlciB0aGUgZGlmZmVyZW50IGNvbmZsaWN0IHN0YXRlcyBpbiB0aGUgbGVnZW5kIGJlbG93IHRoZSBzb3VyY2UgdGVhbXNcbiAgICAgKi9cbiAgICBnZXQgc2FtcGxlVGVhbUZvckxlZ2VuZCgpIHtcbiAgICAgICAgY29uc3QgdGVhbSA9IG5ldyBUZWFtKCk7XG4gICAgICAgIGNvbnN0IHN0dWRlbnQgPSBuZXcgVXNlcigxLCAnZ2ExMmFiYycsICdKb2huJywgJ0RvZScsICdqb2huLmRvZUB0dW0uZGUnKTtcbiAgICAgICAgc3R1ZGVudC5uYW1lID0gYCR7c3R1ZGVudC5maXJzdE5hbWV9ICR7c3R1ZGVudC5sYXN0TmFtZX1gO1xuICAgICAgICB0ZWFtLnN0dWRlbnRzID0gW3N0dWRlbnRdO1xuICAgICAgICByZXR1cm4gdGVhbTtcbiAgICB9XG5cbiAgICBnZXQgc2FtcGxlRXJyb3JTdHVkZW50TG9naW5zRm9yTGVnZW5kKCk6IHN0cmluZ1tdIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2FtcGxlVGVhbUZvckxlZ2VuZC5zdHVkZW50cyEubWFwKChzdHVkZW50KSA9PiBzdHVkZW50LmxvZ2luKS5maWx0ZXIoKGxvZ2luKSA9PiBsb2dpbiAhPT0gdW5kZWZpbmVkKSBhcyBzdHJpbmdbXTtcbiAgICB9XG5cbiAgICBnZXQgc2hvd0xlZ2VuZCgpIHtcbiAgICAgICAgcmV0dXJuIEJvb2xlYW4odGhpcy5zb3VyY2VUZWFtcyAmJiB0aGlzLm51bWJlck9mQ29uZmxpY3RGcmVlU291cmNlVGVhbXMgIT09IHRoaXMuc291cmNlVGVhbXMubGVuZ3RoKTtcbiAgICB9XG5cbiAgICBnZXQgcHJvYmxlbWF0aWNSZWdpc3RyYXRpb25OdW1iZXJzKCkge1xuICAgICAgICByZXR1cm4gWy4uLnRoaXMuY29uZmxpY3RpbmdSZWdpc3RyYXRpb25OdW1iZXJzU2V0XTtcbiAgICB9XG5cbiAgICBnZXQgcHJvYmxlbWF0aWNMb2dpbnMoKSB7XG4gICAgICAgIHJldHVybiBbLi4udGhpcy5jb25mbGljdGluZ0xvZ2luc1NldF07XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQWRkcyBnaXZlbiBhcnJheSB0byBnaXZlbiBzZXQgYW5kIHJldHVybnMgYSBuZXcgc2V0XG4gICAgICogQHBhcmFtIHNldCB0byBhZGQgYXJyYXkgdG9cbiAgICAgKiBAcGFyYW0gYXJyYXkgdGhhdCB3aWxsIGJlIGFkZGVkIHRvIHNldFxuICAgICAqIEByZXR1cm5zIEEgc2V0IHRoYXQgaGFzIHZhbHVlcyBvZiBib3RoIGdpdmVuIHNldCBhbmQgYXJyYXlcbiAgICAgKi9cbiAgICBwcml2YXRlIGFkZEFycmF5VG9TZXQoc2V0OiBTZXQ8c3RyaW5nPiwgYXJyYXk6IHN0cmluZ1tdKSB7XG4gICAgICAgIHJldHVybiBuZXcgU2V0KFsuLi5hcnJheSwgLi4uc2V0LnZhbHVlcygpXSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmVzZXQgY29uZmxpY3RpbmcgbG9naW5zIGFuZCByZWdpc3RyYXRpb24gbnVtYmVycyBzZXRcbiAgICAgKiBTZXRzIHN0dWRlbnRzIGFwcGVhciBpbiBtdWx0aXBsZSB0ZWFtcyB0byBmYWxzZVxuICAgICAqIFJlY29tcHV0ZXMgcG90ZW50aWFsIGNvbmZsaWN0c1xuICAgICAqL1xuICAgIHByaXZhdGUgcmVzZXRDb25mbGljdGluZ1NldHMoKSB7XG4gICAgICAgIHRoaXMuY29uZmxpY3RpbmdMb2dpbnNTZXQgPSBuZXcgU2V0KCk7XG4gICAgICAgIHRoaXMuY29uZmxpY3RpbmdSZWdpc3RyYXRpb25OdW1iZXJzU2V0ID0gbmV3IFNldCgpO1xuICAgICAgICB0aGlzLnN0dWRlbnRzQXBwZWFySW5NdWx0aXBsZVRlYW1zID0gZmFsc2U7XG4gICAgICAgIHRoaXMuY29tcHV0ZVBvdGVudGlhbENvbmZsaWN0c0Jhc2VkT25FeGlzdGluZ1RlYW1zKCk7XG4gICAgfVxufVxuIiwiPGZvcm0gaWQ9XCJ0ZWFtc0ltcG9ydERpYWxvZ0Zvcm1cIiBuYW1lPVwiaW1wb3J0Rm9ybVwiIHJvbGU9XCJmb3JtXCIgbm92YWxpZGF0ZSAobmdTdWJtaXQpPVwiaW1wb3J0VGVhbXMoKVwiICNlZGl0Rm9ybT1cIm5nRm9ybVwiPlxuICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1oZWFkZXJcIj5cbiAgICAgICAgPGg0IGNsYXNzPVwibW9kYWwtdGl0bGVcIj5cbiAgICAgICAgICAgIDxzcGFuIFtqaGlUcmFuc2xhdGVdPVwiJ2FydGVtaXNBcHAudGVhbS5pbXBvcnRUZWFtcy5kaWFsb2dUaXRsZSdcIj4gSW1wb3J0IHRlYW1zIGludG86IDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPnt7IGV4ZXJjaXNlLnRpdGxlIH19PC9zcGFuPlxuICAgICAgICA8L2g0PlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1jbG9zZVwiIGRhdGEtZGlzbWlzcz1cIm1vZGFsXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgKGNsaWNrKT1cImNsZWFyKClcIj48L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtYm9keVwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwidzEwMCByb3cganVzdGlmeS1jb250ZW50LWNlbnRlciBjYXJkLWhlYWRlclwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJ0bi1ncm91cFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJidG5cIiBbbmdDbGFzc109XCJ7ICdidG4tcHJpbWFyeSc6IHNob3dJbXBvcnRGcm9tRXhlcmNpc2UsICdidG4tZGVmYXVsdCc6ICFzaG93SW1wb3J0RnJvbUV4ZXJjaXNlIH1cIiAoY2xpY2spPVwic2V0U2hvd0ltcG9ydEZyb21FeGVyY2lzZSh0cnVlKVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0uaW1wb3J0VGVhbXMuZnJvbUFuRXhlcmNpc2VcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJ0blwiIFtuZ0NsYXNzXT1cInsgJ2J0bi1wcmltYXJ5JzogIXNob3dJbXBvcnRGcm9tRXhlcmNpc2UsICdidG4tZGVmYXVsdCc6IHNob3dJbXBvcnRGcm9tRXhlcmNpc2UgfVwiIChjbGljayk9XCJzZXRTaG93SW1wb3J0RnJvbUV4ZXJjaXNlKGZhbHNlKVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0uaW1wb3J0VGVhbXMuZnJvbUFGaWxlXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgQGlmIChzaG93SW1wb3J0RnJvbUV4ZXJjaXNlKSB7XG4gICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJpbnRyby10ZXh0XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC50ZWFtLmltcG9ydFRlYW1zLmludHJvVGV4dEV4ZXJjaXNlXCI+VGhpcyBkaWFsb2cgY2FuIGJlIHVzZWQgdG8gaW1wb3J0IHRlYW1zIGZyb20gYW5vdGhlciBleGVyY2lzZS48L3A+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKCFzaG93SW1wb3J0RnJvbUV4ZXJjaXNlKSB7XG4gICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJpbnRyby10ZXh0XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC50ZWFtLmltcG9ydFRlYW1zLmludHJvVGV4dEZpbGVcIj5UaGlzIGRpYWxvZyBjYW4gYmUgdXNlZCB0byBpbXBvcnQgdGVhbXMgZnJvbSBhIGZpbGUgaW50byB0aGlzIGV4ZXJjaXNlLjwvcD5cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIEBpZiAoIXNob3dJbXBvcnRGcm9tRXhlcmNpc2UpIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBhbGlnbi1pdGVtcy1lbmRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGpoaS10ZWFtcy1pbXBvcnQtZnJvbS1maWxlLWZvcm0gKHRlYW1zQ2hhbmdlZCk9XCJvblRlYW1zQ2hhbmdlZCgkZXZlbnQpXCI+PC9qaGktdGVhbXMtaW1wb3J0LWZyb20tZmlsZS1mb3JtPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChzaG93SW1wb3J0RnJvbUV4ZXJjaXNlKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXggYWxpZ24taXRlbXMtZW5kXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJsYWJlbC1uYXJyb3dcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0uc291cmNlRXhlcmNpc2UubGFiZWxcIj5Tb3VyY2UgZXhlcmNpc2U8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1oZWxwLWljb24gdGV4dD1cImFydGVtaXNBcHAudGVhbS5zb3VyY2VFeGVyY2lzZS50b29sdGlwXCIgY2xhc3M9XCJtZS0xXCI+PC9qaGktaGVscC1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgQGlmIChzZWFyY2hpbmdFeGVyY2lzZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIGNsYXNzPVwibG9hZGluZy1zcGlubmVyXCIgW2ljb25dPVwiZmFTcGlubmVyXCIgW3NwaW5dPVwidHJ1ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKHNlYXJjaGluZ0V4ZXJjaXNlc05vUmVzdWx0c0ZvclF1ZXJ5ID09PSAnJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJlcnJvci1tZXNzYWdlIHRleHQtZGFuZ2VyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC50ZWFtLmV4ZXJjaXNlU2VhcmNoLm5vUmVzdWx0c1wiPlRoZXJlIGFyZSBubyBvdGhlciB0ZWFtLWJhc2VkIGV4ZXJjaXNlcyBpbiB0aGlzIGNvdXJzZS48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQGlmIChzZWFyY2hpbmdFeGVyY2lzZXNOb1Jlc3VsdHNGb3JRdWVyeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJlcnJvci1tZXNzYWdlIHRleHQtZGFuZ2VyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC50ZWFtLmV4ZXJjaXNlU2VhcmNoLm5vUmVzdWx0c0ZvclNlYXJjaFRlcm1cIj5ObyBvdGhlciB0ZWFtLWJhc2VkIGV4ZXJjaXNlIGZvdW5kIGluIGNvdXJzZSBmb3Igc2VhcmNoOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPnt7IHNlYXJjaGluZ0V4ZXJjaXNlc05vUmVzdWx0c0ZvclF1ZXJ5IH19PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQGlmIChzZWFyY2hpbmdFeGVyY2lzZXNGYWlsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZXJyb3ItbWVzc2FnZSB0ZXh0LWRhbmdlclwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5leGVyY2lzZVNlYXJjaC5mYWlsZWRcIj4gU2VhcmNoIGZhaWxlZC4gUGxlYXNlIHRyeSBhZ2Fpbi4gPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGpoaS10ZWFtLWV4ZXJjaXNlLXNlYXJjaFxuICAgICAgICAgICAgICAgICAgICBpZD1cInRlYW1FeGVyY2lzZXNcIlxuICAgICAgICAgICAgICAgICAgICBbY291cnNlXT1cImV4ZXJjaXNlLmNvdXJzZSFcIlxuICAgICAgICAgICAgICAgICAgICBbaWdub3JlRXhlcmNpc2VzXT1cIltleGVyY2lzZV1cIlxuICAgICAgICAgICAgICAgICAgICAoc2VsZWN0RXhlcmNpc2UpPVwib25TZWxlY3RTb3VyY2VFeGVyY2lzZSgkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAgICAgKHNlYXJjaGluZyk9XCJzZWFyY2hpbmdFeGVyY2lzZXMgPSAkZXZlbnRcIlxuICAgICAgICAgICAgICAgICAgICAoc2VhcmNoTm9SZXN1bHRzKT1cInNlYXJjaGluZ0V4ZXJjaXNlc05vUmVzdWx0c0ZvclF1ZXJ5ID0gJGV2ZW50XCJcbiAgICAgICAgICAgICAgICAgICAgKHNlYXJjaEZhaWxlZCk9XCJzZWFyY2hpbmdFeGVyY2lzZXNGYWlsZWQgPSAkZXZlbnRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8L2poaS10ZWFtLWV4ZXJjaXNlLXNlYXJjaD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICAgIEBpZiAoc291cmNlRXhlcmNpc2UgfHwgc291cmNlVGVhbXMpIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwIG10LTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGFsaWduLWl0ZW1zLWVuZFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwibGFiZWwtbmFycm93XCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC50ZWFtLnNvdXJjZVRlYW1zLmxhYmVsXCI+U291cmNlIHRlYW1zPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktaGVscC1pY29uIHRleHQ9XCJhcnRlbWlzQXBwLnRlYW0uc291cmNlVGVhbXMudG9vbHRpcFwiIGNsYXNzPVwibWUtMVwiPjwvamhpLWhlbHAtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAobG9hZGluZ1NvdXJjZVRlYW1zKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBjbGFzcz1cImxvYWRpbmctc3Bpbm5lclwiIFtpY29uXT1cImZhU3Bpbm5lclwiIFtzcGluXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQGlmIChsb2FkaW5nU291cmNlVGVhbXNGYWlsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZXJyb3ItbWVzc2FnZSB0ZXh0LWRhbmdlclwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5sb2FkU291cmNlVGVhbXMuZmFpbGVkXCI+IExvYWRpbmcgdGVhbXMgZmFpbGVkLiBQbGVhc2UgdHJ5IGFnYWluLiA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICBAaWYgKHNvdXJjZVRlYW1zKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3M9XCJsaXN0LWdyb3VwIGxpc3QtZ3JvdXAtLXRlYW1zIG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAZm9yICh0ZWFtIG9mIHNvdXJjZVRlYW1zOyB0cmFjayB0ZWFtOyBsZXQgaSA9ICRpbmRleCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3M9XCJsaXN0LWdyb3VwLWl0ZW0tY29udGFpbmVyIGQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsaXN0LWdyb3VwLWl0ZW0taW5kZXhcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBpICsgMSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJsaXN0LWdyb3VwLWl0ZW0gbGlzdC1ncm91cC1pdGVtLS10ZWFtc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmhhcy1lcnJvcl09XCJ0ZWFtU2hvcnROYW1lc0FscmVhZHlFeGlzdGluZ0luRXhlcmNpc2UuaW5jbHVkZXModGVhbS5zaG9ydE5hbWUhKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmhhcy1zdWNjZXNzXT1cImlzU291cmNlVGVhbUZyZWVPZkFueUNvbmZsaWN0cyh0ZWFtKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRlYW0tbmFtZVwiPnt7IHRlYW0uc2hvcnROYW1lIH19PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS10ZWFtLXN0dWRlbnRzLWxpc3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJ0ZWFtLXN0dWRlbnRzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3N0dWRlbnRzXT1cInRlYW0uc3R1ZGVudHMgfHwgW11cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbZXJyb3JTdHVkZW50TG9naW5zXT1cInByb2JsZW1hdGljTG9naW5zXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3dpdGhSZWdpc3RyYXRpb25OdW1iZXJdPVwidHJ1ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtlcnJvclN0dWRlbnRSZWdpc3RyYXRpb25OdW1iZXJzXT1cInByb2JsZW1hdGljUmVnaXN0cmF0aW9uTnVtYmVyc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvamhpLXRlYW0tc3R1ZGVudHMtbGlzdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKCFzb3VyY2VUZWFtcyB8fCBzb3VyY2VUZWFtcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzPVwibGlzdC1ncm91cC1pdGVtLWNvbnRhaW5lciBkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGlzdC1ncm91cC1pdGVtLWluZGV4IHRleHQtYm9keS1zZWNvbmRhcnlcIj4xPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGlzdC1ncm91cC1pdGVtIGxpc3QtZ3JvdXAtaXRlbS0tdGVhbXMgcHktNVwiIFtjbGFzcy5oYXMtd2FybmluZ109XCJzb3VyY2VUZWFtcz8ubGVuZ3RoID09PSAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChzaG93SW1wb3J0RnJvbUV4ZXJjaXNlICYmIHNvdXJjZVRlYW1zPy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC50ZWFtLm5vVGVhbXNJblNvdXJjZUV4ZXJjaXNlXCI+IFRoZSBzb3VyY2UgZXhlcmNpc2UgaGFzIG5vIHRlYW1zLiA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIXNob3dJbXBvcnRGcm9tRXhlcmNpc2UgJiYgc291cmNlVGVhbXM/Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0ubm9UZWFtc0luRmlsZVwiPiBGaWxlIGhhcyBubyB0ZWFtcy4gPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHNob3dMZWdlbmQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic291cmNlLXRlYW1zLWxlZ2VuZC1jb250YWluZXIgbXQtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aHIgY2xhc3M9XCJtdC0zIG1iLTJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5zb3VyY2VUZWFtcy5sZWdlbmQubGFiZWxcIj5MZWdlbmQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1oZWxwLWljb24gdGV4dD1cImFydGVtaXNBcHAudGVhbS5zb3VyY2VUZWFtcy5sZWdlbmQudG9vbHRpcFwiIGNsYXNzPVwibWUtMVwiPjwvamhpLWhlbHAtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzb3VyY2UtdGVhbXMtbGVnZW5kLWJveFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNvdXJjZS10ZWFtcy1sZWdlbmQgZC1mbGV4IGp1c3RpZnktY29udGVudC1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxpc3QtZ3JvdXAtaXRlbS0tdGVhbXNcIiBbY2xhc3MuaGFzLXN1Y2Nlc3NdPVwidHJ1ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRlYW0tbmFtZVwiPnt7ICdhcnRlbWlzQXBwLnRlYW0uc291cmNlVGVhbXMubGVnZW5kLnRlYW1TaG9ydE5hbWUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTE8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktdGVhbS1zdHVkZW50cy1saXN0IGNsYXNzPVwidGVhbS1zdHVkZW50c1wiIFtzdHVkZW50c109XCJzYW1wbGVUZWFtRm9yTGVnZW5kLnN0dWRlbnRzIHx8IFtdXCI+IDwvamhpLXRlYW0tc3R1ZGVudHMtbGlzdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbC13aXRoLXRvb2x0aXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0uc291cmNlVGVhbXMubGVnZW5kLml0ZW1zLmNvbmZsaWN0RnJlZVRlYW0ubGFiZWxcIj5Db25mbGljdC1mcmVlIHRlYW08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1oZWxwLWljb24gdGV4dD1cImFydGVtaXNBcHAudGVhbS5zb3VyY2VUZWFtcy5sZWdlbmQuaXRlbXMuY29uZmxpY3RGcmVlVGVhbS50b29sdGlwXCIgY2xhc3M9XCJtZS0xXCI+PC9qaGktaGVscC1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGlzdC1ncm91cC1pdGVtLS10ZWFtc1wiIFtjbGFzcy5oYXMtZXJyb3JdPVwidHJ1ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRlYW0tbmFtZVwiPnt7ICdhcnRlbWlzQXBwLnRlYW0uc291cmNlVGVhbXMubGVnZW5kLnRlYW1TaG9ydE5hbWUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTI8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktdGVhbS1zdHVkZW50cy1saXN0IGNsYXNzPVwidGVhbS1zdHVkZW50c1wiIFtzdHVkZW50c109XCJzYW1wbGVUZWFtRm9yTGVnZW5kLnN0dWRlbnRzIHx8IFtdXCI+IDwvamhpLXRlYW0tc3R1ZGVudHMtbGlzdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbC13aXRoLXRvb2x0aXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0uc291cmNlVGVhbXMubGVnZW5kLml0ZW1zLnRlYW1TaG9ydE5hbWVDb25mbGljdC5sYWJlbFwiPlRlYW0gc2hvcnQgbmFtZSBjb25mbGljdDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLWhlbHAtaWNvbiB0ZXh0PVwiYXJ0ZW1pc0FwcC50ZWFtLnNvdXJjZVRlYW1zLmxlZ2VuZC5pdGVtcy50ZWFtU2hvcnROYW1lQ29uZmxpY3QudG9vbHRpcFwiIGNsYXNzPVwibWUtMVwiPjwvamhpLWhlbHAtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxpc3QtZ3JvdXAtaXRlbS0tdGVhbXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZWFtLW5hbWVcIj57eyAnYXJ0ZW1pc0FwcC50ZWFtLnNvdXJjZVRlYW1zLmxlZ2VuZC50ZWFtU2hvcnROYW1lJyB8IGFydGVtaXNUcmFuc2xhdGUgfX0zPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLXRlYW0tc3R1ZGVudHMtbGlzdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwidGVhbS1zdHVkZW50c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3N0dWRlbnRzXT1cInNhbXBsZVRlYW1Gb3JMZWdlbmQuc3R1ZGVudHMgfHwgW11cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtlcnJvclN0dWRlbnRMb2dpbnNdPVwic2FtcGxlRXJyb3JTdHVkZW50TG9naW5zRm9yTGVnZW5kXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvamhpLXRlYW0tc3R1ZGVudHMtbGlzdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbC13aXRoLXRvb2x0aXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0uc291cmNlVGVhbXMubGVnZW5kLml0ZW1zLnN0dWRlbnRDb25mbGljdC5sYWJlbFwiPlN0dWRlbnQgY29uZmxpY3Q8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1oZWxwLWljb24gdGV4dD1cImFydGVtaXNBcHAudGVhbS5zb3VyY2VUZWFtcy5sZWdlbmQuaXRlbXMuc3R1ZGVudENvbmZsaWN0LnRvb2x0aXBcIiBjbGFzcz1cIm1lLTFcIj48L2poaS1oZWxwLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgICBAaWYgKHNob3dJbXBvcnRTdHJhdGVneUNob2ljZXMpIHtcbiAgICAgICAgICAgIDxociBjbGFzcz1cIm15LTRcIiAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXAgbWItMFwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImxhYmVsLW5hcnJvd1wiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5pbXBvcnRTdHJhdGVneS5sYWJlbFwiPkltcG9ydCBjb25mbGljdCBzdHJhdGVneTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxqaGktaGVscC1pY29uIHRleHQ9XCJhcnRlbWlzQXBwLnRlYW0uaW1wb3J0U3RyYXRlZ3kudG9vbHRpcFwiIGNsYXNzPVwibWUtMVwiPjwvamhpLWhlbHAtaWNvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGZsZXgtY29sdW1uIG10LTIgcHMtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJkLWZsZXggYWxpZ24taXRlbXMtc3RhcnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImltcG9ydFN0cmF0ZWd5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInJhZGlvLWlucHV0LXdpdGgtZXhwbGFuYXRpb25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ01vZGVsXT1cImltcG9ydFN0cmF0ZWd5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwidXBkYXRlSW1wb3J0U3RyYXRlZ3koSW1wb3J0U3RyYXRlZ3kuUFVSR0VfRVhJU1RJTkcpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdmFsdWVdPVwiSW1wb3J0U3RyYXRlZ3kuUFVSR0VfRVhJU1RJTkdcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtcy0yIHJhZGlvLWxhYmVsLXdpdGgtZXhwbGFuYXRpb25cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC50ZWFtLmltcG9ydFN0cmF0ZWd5Lm9wdGlvbnMucHVyZ2VFeGlzdGluZy5sYWJlbCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctZGFuZ2VyIG1zLTFcIj57eyAnYXJ0ZW1pc0FwcC50ZWFtLmltcG9ydFN0cmF0ZWd5Lm9wdGlvbnMucHVyZ2VFeGlzdGluZy5iYWRnZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIFtjbGFzcy50ZXh0LWJvZHktc2Vjb25kYXJ5XT1cImltcG9ydFN0cmF0ZWd5ICE9PSBJbXBvcnRTdHJhdGVneS5QVVJHRV9FWElTVElOR1wiIGNsYXNzPVwiZXhwbGFuYXRpb24gbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC50ZWFtLmltcG9ydFN0cmF0ZWd5Lm9wdGlvbnMucHVyZ2VFeGlzdGluZy5leHBsYW5hdGlvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImQtZmxleCBhbGlnbi1pdGVtcy1zdGFydFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiaW1wb3J0U3RyYXRlZ3lcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwicmFkaW8taW5wdXQtd2l0aC1leHBsYW5hdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nTW9kZWxdPVwiaW1wb3J0U3RyYXRlZ3lcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJ1cGRhdGVJbXBvcnRTdHJhdGVneShJbXBvcnRTdHJhdGVneS5DUkVBVEVfT05MWSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt2YWx1ZV09XCJJbXBvcnRTdHJhdGVneS5DUkVBVEVfT05MWVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1zLTIgcmFkaW8tbGFiZWwtd2l0aC1leHBsYW5hdGlvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLnRlYW0uaW1wb3J0U3RyYXRlZ3kub3B0aW9ucy5jcmVhdGVPbmx5LmxhYmVsJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSBiZy1zdWNjZXNzIG1zLTFcIj57eyAnYXJ0ZW1pc0FwcC50ZWFtLmltcG9ydFN0cmF0ZWd5Lm9wdGlvbnMuY3JlYXRlT25seS5iYWRnZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIFtjbGFzcy50ZXh0LWJvZHktc2Vjb25kYXJ5XT1cImltcG9ydFN0cmF0ZWd5ICE9PSBJbXBvcnRTdHJhdGVneS5DUkVBVEVfT05MWVwiIGNsYXNzPVwiZXhwbGFuYXRpb24gbWItMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC50ZWFtLmltcG9ydFN0cmF0ZWd5Lm9wdGlvbnMuY3JlYXRlT25seS5leHBsYW5hdGlvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1mb290ZXJcIj5cbiAgICAgICAgQGlmIChzaG93SW1wb3J0UHJldmlld051bWJlcnMgJiYgc291cmNlVGVhbXMpIHtcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4LXNocmluay0wIG1lLTIgZC1mbGV4XCI+XG4gICAgICAgICAgICAgICAgQGlmIChzdHVkZW50c0FwcGVhckluTXVsdGlwbGVUZWFtcykge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57eyAnYXJ0ZW1pc0FwcC50ZWFtLmltcG9ydFByZXZpZXcuc3R1ZGVudHNJbk11bHRpcGxlVGVhbXMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgQGlmIChudW1iZXJPZlRlYW1zVG9CZUltcG9ydGVkISA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHNvdXJjZVRlYW1zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPnt7ICdhcnRlbWlzQXBwLnRlYW0uaW1wb3J0UHJldmlldy5ub1RlYW1zVG9JbXBvcnQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHNvdXJjZVRlYW1zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57eyAnYXJ0ZW1pc0FwcC50ZWFtLmltcG9ydFByZXZpZXcubm9Db25mbGljdEZyZWVUZWFtc1RvSW1wb3J0JyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKG51bWJlck9mVGVhbXNUb0JlSW1wb3J0ZWQhID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChudW1iZXJPZlRlYW1zVG9CZURlbGV0ZWQhID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtZS0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e3sgJ2FydGVtaXNBcHAudGVhbS5pbXBvcnRQcmV2aWV3LnRlYW1zVG9CZURlbGV0ZWQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Ryb25nPiB7eyBudW1iZXJPZlRlYW1zVG9CZURlbGV0ZWQhIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKG51bWJlck9mVGVhbXNUb0JlSW1wb3J0ZWQhICE9PSBudW1iZXJPZlRlYW1zQWZ0ZXJJbXBvcnQhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1lLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57eyAnYXJ0ZW1pc0FwcC50ZWFtLmltcG9ydFByZXZpZXcudGVhbXNUb0JlSW1wb3J0ZWQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Ryb25nPiB7eyBudW1iZXJPZlRlYW1zVG9CZUltcG9ydGVkISB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKG51bWJlck9mVGVhbXNUb0JlSW1wb3J0ZWQhIDwgc291cmNlVGVhbXMubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLnRlYW0uaW1wb3J0UHJldmlldy5vdXRPZlwiIFt0cmFuc2xhdGVWYWx1ZXNdPVwieyBudW1iZXI6IHNvdXJjZVRlYW1zLmxlbmd0aCB9XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKG91dCBvZiB7eyBzb3VyY2VUZWFtcy5sZW5ndGggfX0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57eyAnYXJ0ZW1pc0FwcC50ZWFtLmltcG9ydFByZXZpZXcudG90YWxUZWFtc0FmdGVySW1wb3J0JyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3N0cm9uZz4ge3sgbnVtYmVyT2ZUZWFtc0FmdGVySW1wb3J0ISB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleC1ncm93LTEgZC1mbGV4IGp1c3RpZnktY29udGVudC1lbmRcIj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0IGNhbmNlbFwiIGRhdGEtZGlzbWlzcz1cIm1vZGFsXCIgKGNsaWNrKT1cImNsZWFyKClcIj5cbiAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUJhblwiPjwvZmEtaWNvbj4mbmJzcDs8c3BhbiBqaGlUcmFuc2xhdGU9XCJlbnRpdHkuYWN0aW9uLmNhbmNlbFwiPkNhbmNlbDwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgQGlmIChpbXBvcnRTdHJhdGVneSAhPT0gSW1wb3J0U3RyYXRlZ3kuUFVSR0VfRVhJU1RJTkcpIHtcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzcz1cImJ0biBidG4td2FybmluZ1wiIFtkaXNhYmxlZF09XCJlZGl0Rm9ybS5pbnZhbGlkIHx8IGlzU3VibWl0RGlzYWJsZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFVcGxvYWRcIiBjbGFzcz1cIm1lLTJcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImVudGl0eS5hY3Rpb24udG8taW1wb3J0XCI+SW1wb3J0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBjbGFzcz1cIm1zLTFcIiBbaGlkZGVuXT1cIiFpc0ltcG9ydGluZ1wiIFtzcGluXT1cInRydWVcIiBbaWNvbl09XCJmYUNpcmNsZU5vdGNoXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmIChpbXBvcnRTdHJhdGVneSA9PT0gSW1wb3J0U3RyYXRlZ3kuUFVSR0VfRVhJU1RJTkcpIHtcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYnRuIGJ0bi13YXJuaW5nXCJcbiAgICAgICAgICAgICAgICAgICAgW2Rpc2FibGVkXT1cImVkaXRGb3JtLmludmFsaWQgfHwgaXNTdWJtaXREaXNhYmxlZFwiXG4gICAgICAgICAgICAgICAgICAgIGpoaURlbGV0ZUJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBbcmVuZGVyQnV0dG9uVGV4dF09XCJmYWxzZVwiXG4gICAgICAgICAgICAgICAgICAgIFtyZW5kZXJCdXR0b25TdHlsZV09XCJmYWxzZVwiXG4gICAgICAgICAgICAgICAgICAgIFtlbnRpdHlUaXRsZV09XCJleGVyY2lzZS50aXRsZSB8fCAnJ1wiXG4gICAgICAgICAgICAgICAgICAgIGRlbGV0ZVF1ZXN0aW9uPVwiYXJ0ZW1pc0FwcC50ZWFtLnB1cmdlQ29uZmlybWF0aW9uRGlhbG9nLnF1ZXN0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlQ29uZmlybWF0aW9uVGV4dD1cImFydGVtaXNBcHAudGVhbS5wdXJnZUNvbmZpcm1hdGlvbkRpYWxvZy50eXBlTmFtZVRvQ29uZmlybVwiXG4gICAgICAgICAgICAgICAgICAgIChkZWxldGUpPVwicHVyZ2VBbmRJbXBvcnRUZWFtcygpXCJcbiAgICAgICAgICAgICAgICAgICAgW2RpYWxvZ0Vycm9yXT1cImRpYWxvZ0Vycm9yJFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVVwbG9hZFwiIGNsYXNzPVwibWUtMVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiZW50aXR5LmFjdGlvbi5wdXJnZVwiPlB1cmdlPC9zcGFuPiArXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImVudGl0eS5hY3Rpb24udG8taW1wb3J0XCI+SW1wb3J0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBjbGFzcz1cIm1zLTFcIiBbaGlkZGVuXT1cIiFpc0ltcG9ydGluZ1wiIFtzcGluXT1cInRydWVcIiBbaWNvbl09XCJmYUNpcmNsZU5vdGNoXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbjwvZm9ybT5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOZ2JNb2RhbCwgTmdiTW9kYWxSZWYgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgeyBUZWFtIH0gZnJvbSAnYXBwL2VudGl0aWVzL3RlYW0ubW9kZWwnO1xuaW1wb3J0IHsgRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgQnV0dG9uU2l6ZSwgQnV0dG9uVHlwZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9idXR0b24uY29tcG9uZW50JztcbmltcG9ydCB7IFRlYW1zSW1wb3J0RGlhbG9nQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvdGVhbS90ZWFtcy1pbXBvcnQtZGlhbG9nL3RlYW1zLWltcG9ydC1kaWFsb2cuY29tcG9uZW50JztcbmltcG9ydCB7IGZhUGx1cyB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXRlYW1zLWltcG9ydC1idXR0b24nLFxuICAgIHRlbXBsYXRlOiBgXG4gICAgICAgIDxqaGktYnV0dG9uXG4gICAgICAgICAgICBbYnRuVHlwZV09XCJCdXR0b25UeXBlLlBSSU1BUllcIlxuICAgICAgICAgICAgW2J0blNpemVdPVwiYnV0dG9uU2l6ZVwiXG4gICAgICAgICAgICBbaWNvbl09XCJmYVBsdXNcIlxuICAgICAgICAgICAgW3RpdGxlXT1cIidhcnRlbWlzQXBwLnRlYW0uaW1wb3J0VGVhbXMuYnV0dG9uTGFiZWwnXCJcbiAgICAgICAgICAgIChvbkNsaWNrKT1cIm9wZW5UZWFtc0ltcG9ydERpYWxvZygkZXZlbnQpXCJcbiAgICAgICAgPjwvamhpLWJ1dHRvbj5cbiAgICBgLFxufSlcbmV4cG9ydCBjbGFzcyBUZWFtc0ltcG9ydEJ1dHRvbkNvbXBvbmVudCB7XG4gICAgQnV0dG9uVHlwZSA9IEJ1dHRvblR5cGU7XG4gICAgQnV0dG9uU2l6ZSA9IEJ1dHRvblNpemU7XG5cbiAgICBASW5wdXQoKSBleGVyY2lzZTogRXhlcmNpc2U7XG4gICAgQElucHV0KCkgdGVhbXM6IFRlYW1bXTtcbiAgICBASW5wdXQoKSBidXR0b25TaXplOiBCdXR0b25TaXplID0gQnV0dG9uU2l6ZS5TTUFMTDtcblxuICAgIEBPdXRwdXQoKSBzYXZlOiBFdmVudEVtaXR0ZXI8VGVhbVtdPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICAgIC8vIEljb25zXG4gICAgZmFQbHVzID0gZmFQbHVzO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBtb2RhbFNlcnZpY2U6IE5nYk1vZGFsKSB7fVxuXG4gICAgLyoqXG4gICAgICogT3BlbiB1cCBpbXBvcnQgZGlhbG9nIGZvciB0ZWFtc1xuICAgICAqIEBwYXJhbSB7RXZlbnR9IGV2ZW50IC0gTW91c2UgRXZlbnQgd2hpY2ggaW52b2tlZCB0aGUgb3BlbmluZ1xuICAgICAqL1xuICAgIG9wZW5UZWFtc0ltcG9ydERpYWxvZyhldmVudDogTW91c2VFdmVudCkge1xuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgY29uc3QgbW9kYWxSZWY6IE5nYk1vZGFsUmVmID0gdGhpcy5tb2RhbFNlcnZpY2Uub3BlbihUZWFtc0ltcG9ydERpYWxvZ0NvbXBvbmVudCwgeyBrZXlib2FyZDogdHJ1ZSwgc2l6ZTogJ2xnJywgYmFja2Ryb3A6ICdzdGF0aWMnIH0pO1xuICAgICAgICBtb2RhbFJlZi5jb21wb25lbnRJbnN0YW5jZS5leGVyY2lzZSA9IHRoaXMuZXhlcmNpc2U7XG4gICAgICAgIG1vZGFsUmVmLmNvbXBvbmVudEluc3RhbmNlLnRlYW1zID0gdGhpcy50ZWFtcztcblxuICAgICAgICBtb2RhbFJlZi5yZXN1bHQudGhlbihcbiAgICAgICAgICAgICh0ZWFtczogVGVhbVtdKSA9PiB0aGlzLnNhdmUuZW1pdCh0ZWFtcyksXG4gICAgICAgICAgICAoKSA9PiB7fSxcbiAgICAgICAgKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBUZWFtIH0gZnJvbSAnYXBwL2VudGl0aWVzL3RlYW0ubW9kZWwnO1xuaW1wb3J0IHsgQnV0dG9uU2l6ZSwgQnV0dG9uVHlwZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9idXR0b24uY29tcG9uZW50JztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5pbXBvcnQgeyBUZWFtU2VydmljZSB9IGZyb20gJy4uL3RlYW0uc2VydmljZSc7XG5pbXBvcnQgeyBmYUZpbGVFeHBvcnQgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS10ZWFtcy1leHBvcnQtYnV0dG9uJyxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICA8amhpLWJ1dHRvblxuICAgICAgICAgICAgW2J0blR5cGVdPVwiQnV0dG9uVHlwZS5QUklNQVJZXCJcbiAgICAgICAgICAgIFtidG5TaXplXT1cImJ1dHRvblNpemVcIlxuICAgICAgICAgICAgW2ljb25dPVwiZmFGaWxlRXhwb3J0XCJcbiAgICAgICAgICAgIFt0aXRsZV09XCInYXJ0ZW1pc0FwcC50ZWFtLmV4cG9ydFRlYW1zLmJ1dHRvbkxhYmVsJ1wiXG4gICAgICAgICAgICAob25DbGljayk9XCJleHBvcnRUZWFtcygkZXZlbnQpXCJcbiAgICAgICAgPjwvamhpLWJ1dHRvbj5cbiAgICBgLFxufSlcbmV4cG9ydCBjbGFzcyBUZWFtc0V4cG9ydEJ1dHRvbkNvbXBvbmVudCB7XG4gICAgQnV0dG9uVHlwZSA9IEJ1dHRvblR5cGU7XG4gICAgQnV0dG9uU2l6ZSA9IEJ1dHRvblNpemU7XG5cbiAgICBASW5wdXQoKSB0ZWFtczogVGVhbVtdO1xuICAgIEBJbnB1dCgpIGJ1dHRvblNpemU6IEJ1dHRvblNpemUgPSBCdXR0b25TaXplLlNNQUxMO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUZpbGVFeHBvcnQgPSBmYUZpbGVFeHBvcnQ7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSB0ZWFtU2VydmljZTogVGVhbVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogRXhwb3J0IHRlYW1zIG9yIHNob3cgc3R1ZGVudHMgaWYgdGhlcmUgaXMgYW4gZXJyb3JcbiAgICAgKiBAcGFyYW0ge01vdXNlRXZlbnR9IGV2ZW50IC0gVG8gc3RvcCBwcm9wYWdhdGlvblxuICAgICAqL1xuICAgIGV4cG9ydFRlYW1zKGV2ZW50OiBNb3VzZUV2ZW50KSB7XG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICB0aGlzLnRlYW1TZXJ2aWNlLmV4cG9ydFRlYW1zKHRoaXMudGVhbXMpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT25EZXN0cm95LCBPdXRwdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFRlYW0gfSBmcm9tICdhcHAvZW50aXRpZXMvdGVhbS5tb2RlbCc7XG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBCdXR0b25TaXplLCBCdXR0b25UeXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL2J1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgVGVhbVNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0uc2VydmljZSc7XG5pbXBvcnQgeyBFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBBbGVydFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuaW1wb3J0IHsgZmFUcmFzaEFsdCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXRlYW0tZGVsZXRlLWJ1dHRvbicsXG4gICAgdGVtcGxhdGU6IGBcbiAgICAgICAgQGlmIChleGVyY2lzZS5pc0F0TGVhc3RJbnN0cnVjdG9yKSB7XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgamhpRGVsZXRlQnV0dG9uXG4gICAgICAgICAgICAgICAgW2J1dHRvblNpemVdPVwiYnV0dG9uU2l6ZVwiXG4gICAgICAgICAgICAgICAgW2VudGl0eVRpdGxlXT1cInRlYW0uc2hvcnROYW1lIHx8ICcnXCJcbiAgICAgICAgICAgICAgICBkZWxldGVRdWVzdGlvbj1cImFydGVtaXNBcHAudGVhbS5kZWxldGUucXVlc3Rpb25cIlxuICAgICAgICAgICAgICAgIGRlbGV0ZUNvbmZpcm1hdGlvblRleHQ9XCJhcnRlbWlzQXBwLnRlYW0uZGVsZXRlLnR5cGVOYW1lVG9Db25maXJtXCJcbiAgICAgICAgICAgICAgICAoZGVsZXRlKT1cInJlbW92ZVRlYW0oKVwiXG4gICAgICAgICAgICAgICAgW2RpYWxvZ0Vycm9yXT1cImRpYWxvZ0Vycm9yJFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFUcmFzaEFsdFwiIGNsYXNzPVwibWUtMVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICB9XG4gICAgYCxcbn0pXG5leHBvcnQgY2xhc3MgVGVhbURlbGV0ZUJ1dHRvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uRGVzdHJveSB7XG4gICAgQnV0dG9uVHlwZSA9IEJ1dHRvblR5cGU7XG4gICAgQnV0dG9uU2l6ZSA9IEJ1dHRvblNpemU7XG5cbiAgICBASW5wdXQoKSB0ZWFtOiBUZWFtO1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlOiBFeGVyY2lzZTtcbiAgICBASW5wdXQoKSBidXR0b25TaXplOiBCdXR0b25TaXplID0gQnV0dG9uU2l6ZS5TTUFMTDtcblxuICAgIEBPdXRwdXQoKSBkZWxldGUgPSBuZXcgRXZlbnRFbWl0dGVyPFRlYW0+KCk7XG5cbiAgICBwcml2YXRlIGRpYWxvZ0Vycm9yU291cmNlID0gbmV3IFN1YmplY3Q8c3RyaW5nPigpO1xuICAgIGRpYWxvZ0Vycm9yJCA9IHRoaXMuZGlhbG9nRXJyb3JTb3VyY2UuYXNPYnNlcnZhYmxlKCk7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhVHJhc2hBbHQgPSBmYVRyYXNoQWx0O1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgdGVhbVNlcnZpY2U6IFRlYW1TZXJ2aWNlLFxuICAgICkge31cblxuICAgIC8qKlxuICAgICAqIExpZmUgY3ljbGUgaG9vayB0byBpbmRpY2F0ZSBjb21wb25lbnQgY3JlYXRpb24gaXMgZG9uZVxuICAgICAqL1xuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgICAgICB0aGlzLmRpYWxvZ0Vycm9yU291cmNlLnVuc3Vic2NyaWJlKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGVsZXRlcyB0aGUgcHJvdmlkZWQgdGVhbSBvbiB0aGUgc2VydmVyIGFuZCBlbWl0cyB0aGUgZGVsZXRlIGV2ZW50XG4gICAgICpcbiAgICAgKi9cbiAgICByZW1vdmVUZWFtID0gKCkgPT4ge1xuICAgICAgICB0aGlzLnRlYW1TZXJ2aWNlLmRlbGV0ZSh0aGlzLmV4ZXJjaXNlLCB0aGlzLnRlYW0uaWQhKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuZGVsZXRlLmVtaXQodGhpcy50ZWFtKTtcbiAgICAgICAgICAgICAgICB0aGlzLmRpYWxvZ0Vycm9yU291cmNlLm5leHQoJycpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yOiAoKSA9PiB0aGlzLmFsZXJ0U2VydmljZS5lcnJvcignYXJ0ZW1pc0FwcC50ZWFtLnJlbW92ZVRlYW0uZXJyb3InKSxcbiAgICAgICAgfSk7XG4gICAgfTtcbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25EZXN0cm95LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFBhcnRpY2lwYXRpb25TZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcGFydGljaXBhdGlvbi9wYXJ0aWNpcGF0aW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUsIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBUZWFtIH0gZnJvbSAnYXBwL2VudGl0aWVzL3RlYW0ubW9kZWwnO1xuaW1wb3J0IHsgVGVhbVNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0uc2VydmljZSc7XG5pbXBvcnQgeyBCdXR0b25TaXplIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL2J1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgRXhlcmNpc2VTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhlcmNpc2UvZXhlcmNpc2Uuc2VydmljZSc7XG5pbXBvcnQgeyBmb3JtYXRUZWFtQXNTZWFyY2hSZXN1bHQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC90ZWFtL3RlYW0udXRpbHMnO1xuaW1wb3J0IHsgQWNjb3VudFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS9hdXRoL2FjY291bnQuc2VydmljZSc7XG5pbXBvcnQgeyBVc2VyIH0gZnJvbSAnYXBwL2NvcmUvdXNlci91c2VyLm1vZGVsJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5pbXBvcnQgeyBFdmVudE1hbmFnZXIgfSBmcm9tICdhcHAvY29yZS91dGlsL2V2ZW50LW1hbmFnZXIuc2VydmljZSc7XG5cbmV4cG9ydCBlbnVtIEZpbHRlclByb3Age1xuICAgIEFMTCA9ICdhbGwnLFxuICAgIE9XTiA9ICdvd24nLFxufVxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS10ZWFtcycsXG4gICAgdGVtcGxhdGVVcmw6ICcuL3RlYW1zLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgVGVhbXNDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gICAgcmVhZG9ubHkgRmlsdGVyUHJvcCA9IEZpbHRlclByb3A7XG4gICAgcmVhZG9ubHkgQnV0dG9uU2l6ZSA9IEJ1dHRvblNpemU7XG5cbiAgICB0ZWFtczogVGVhbVtdID0gW107XG4gICAgdGVhbUNyaXRlcmlhOiB7IGZpbHRlclByb3A6IEZpbHRlclByb3AgfSA9IHsgZmlsdGVyUHJvcDogRmlsdGVyUHJvcC5BTEwgfTtcbiAgICBmaWx0ZXJlZFRlYW1zU2l6ZSA9IDA7XG4gICAgZXhlcmNpc2U6IEV4ZXJjaXNlO1xuXG4gICAgcHJpdmF0ZSBkaWFsb2dFcnJvclNvdXJjZSA9IG5ldyBTdWJqZWN0PHN0cmluZz4oKTtcbiAgICBkaWFsb2dFcnJvciQgPSB0aGlzLmRpYWxvZ0Vycm9yU291cmNlLmFzT2JzZXJ2YWJsZSgpO1xuXG4gICAgaXNMb2FkaW5nOiBib29sZWFuO1xuXG4gICAgY3VycmVudFVzZXI6IFVzZXI7XG4gICAgaXNBZG1pbiA9IGZhbHNlO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgICAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgICAgICBwcml2YXRlIHBhcnRpY2lwYXRpb25TZXJ2aWNlOiBQYXJ0aWNpcGF0aW9uU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBhbGVydFNlcnZpY2U6IEFsZXJ0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBldmVudE1hbmFnZXI6IEV2ZW50TWFuYWdlcixcbiAgICAgICAgcHJpdmF0ZSBleGVyY2lzZVNlcnZpY2U6IEV4ZXJjaXNlU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSB0ZWFtU2VydmljZTogVGVhbVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgYWNjb3VudFNlcnZpY2U6IEFjY291bnRTZXJ2aWNlLFxuICAgICkge1xuICAgICAgICB0aGlzLmFjY291bnRTZXJ2aWNlLmlkZW50aXR5KCkudGhlbigodXNlcjogVXNlcikgPT4ge1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50VXNlciA9IHVzZXI7XG4gICAgICAgICAgICB0aGlzLmlzQWRtaW4gPSB0aGlzLmFjY291bnRTZXJ2aWNlLmlzQWRtaW4oKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTGlmZSBjeWNsZSBob29rIHRvIGluZGljYXRlIGNvbXBvbmVudCBjcmVhdGlvbiBpcyBkb25lXG4gICAgICovXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMuaW5pdFRlYW1GaWx0ZXIoKTtcbiAgICAgICAgdGhpcy5sb2FkQWxsKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTGlmZSBjeWNsZSBob29rIHRvIGluZGljYXRlIGNvbXBvbmVudCBkZXN0cnVjdGlvbiBpcyBkb25lXG4gICAgICovXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuZGlhbG9nRXJyb3JTb3VyY2UudW5zdWJzY3JpYmUoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBMb2FkIGFsbCB0ZWFtIGNvbXBvbmVudHNcbiAgICAgKi9cbiAgICBsb2FkQWxsKCkge1xuICAgICAgICB0aGlzLnJvdXRlLnBhcmFtcy5zdWJzY3JpYmUoKHBhcmFtcykgPT4ge1xuICAgICAgICAgICAgdGhpcy5pc0xvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgdGhpcy5leGVyY2lzZVNlcnZpY2UuZmluZChwYXJhbXNbJ2V4ZXJjaXNlSWQnXSkuc3Vic2NyaWJlKChleGVyY2lzZVJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5leGVyY2lzZSA9IGV4ZXJjaXNlUmVzcG9uc2UuYm9keSE7XG4gICAgICAgICAgICAgICAgY29uc3QgdGVhbU93bmVySWQgPSB0aGlzLnRlYW1Dcml0ZXJpYS5maWx0ZXJQcm9wID09PSBGaWx0ZXJQcm9wLk9XTiA/IHRoaXMuY3VycmVudFVzZXIuaWQhIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIHRoaXMudGVhbVNlcnZpY2UuZmluZEFsbEJ5RXhlcmNpc2VJZChwYXJhbXNbJ2V4ZXJjaXNlSWQnXSwgdGVhbU93bmVySWQpLnN1YnNjcmliZSgodGVhbXNSZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnRlYW1zID0gdGVhbXNSZXNwb25zZS5ib2R5ITtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pc0xvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBJbml0aWFsaXplcyB0aGUgdGVhbSBmaWx0ZXIgYmFzZWQgb24gdGhlIHF1ZXJ5IHBhcmFtIFwiZmlsdGVyXCJcbiAgICAgKi9cbiAgICBpbml0VGVhbUZpbHRlcigpIHtcbiAgICAgICAgc3dpdGNoICh0aGlzLnJvdXRlLnNuYXBzaG90LnF1ZXJ5UGFyYW1NYXAuZ2V0KCdmaWx0ZXInKSkge1xuICAgICAgICAgICAgY2FzZSBGaWx0ZXJQcm9wLk9XTjpcbiAgICAgICAgICAgICAgICB0aGlzLnRlYW1Dcml0ZXJpYS5maWx0ZXJQcm9wID0gRmlsdGVyUHJvcC5PV047XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHRoaXMudGVhbUNyaXRlcmlhLmZpbHRlclByb3AgPSBGaWx0ZXJQcm9wLkFMTDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZXMgdGhlIGNyaXRlcmlhIGJ5IHdoaWNoIHRvIGZpbHRlciB0ZWFtcyBhbmQgdGhlIGZpbHRlciBxdWVyeSBwYXJhbSwgdGhlbiByZWxvYWRzIHRlYW1zXG4gICAgICogQHBhcmFtIGZpbHRlciBOZXcgZmlsdGVyIHByb3AgdmFsdWVcbiAgICAgKi9cbiAgICB1cGRhdGVUZWFtRmlsdGVyKGZpbHRlcjogRmlsdGVyUHJvcCkge1xuICAgICAgICB0aGlzLnRlYW1Dcml0ZXJpYS5maWx0ZXJQcm9wID0gZmlsdGVyO1xuICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbXSwgeyByZWxhdGl2ZVRvOiB0aGlzLnJvdXRlLCBxdWVyeVBhcmFtczogeyBmaWx0ZXIgfSwgcXVlcnlQYXJhbXNIYW5kbGluZzogJ21lcmdlJywgcmVwbGFjZVVybDogdHJ1ZSB9KTtcbiAgICAgICAgdGhpcy5sb2FkQWxsKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2FsbGVkIHdoZW4gYSB0ZWFtIGhhcyBiZWVuIGFkZGVkIG9yIHdhcyB1cGRhdGVkIGJ5IFRlYW1VcGRhdGVCdXR0b25Db21wb25lbnRcbiAgICAgKlxuICAgICAqIEBwYXJhbSB0ZWFtIFRlYW0gdGhhdCB3YXMgYWRkZWQgb3IgdXBkYXRlZFxuICAgICAqL1xuICAgIG9uVGVhbVVwZGF0ZSh0ZWFtOiBUZWFtKSB7XG4gICAgICAgIHRoaXMudXBzZXJ0VGVhbSh0ZWFtKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDYWxsZWQgd2hlbiBhIHRlYW0gaGFzIGJlZW4gZGVsZXRlZCBieSBUZWFtRGVsZXRlQnV0dG9uQ29tcG9uZW50XG4gICAgICpcbiAgICAgKiBAcGFyYW0gdGVhbSBUZWFtIHRoYXQgd2FzIGRlbGV0ZWRcbiAgICAgKi9cbiAgICBvblRlYW1EZWxldGUodGVhbTogVGVhbSkge1xuICAgICAgICB0aGlzLmRlbGV0ZVRlYW0odGVhbSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2FsbGVkIHdoZW4gdGVhbXMgd2VyZSBpbXBvcnRlZCBmcm9tIGFub3RoZXIgdGVhbSBleGVyY2lzZVxuICAgICAqXG4gICAgICogQHBhcmFtIHRlYW1zIEFsbCB0ZWFtcyB0aGF0IHRoaXMgZXhlcmNpc2UgaGFzIG5vdyBhZnRlciB0aGUgaW1wb3J0XG4gICAgICovXG4gICAgb25UZWFtc0ltcG9ydCh0ZWFtczogVGVhbVtdKSB7XG4gICAgICAgIHRoaXMudGVhbXMgPSB0ZWFtcztcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVcGRhdGUgdGhlIG51bWJlciBvZiBmaWx0ZXJlZCB0ZWFtc1xuICAgICAqXG4gICAgICogQHBhcmFtIGZpbHRlcmVkVGVhbXNTaXplIFRvdGFsIG51bWJlciBvZiB0ZWFtcyBhZnRlciBmaWx0ZXJzIGhhdmUgYmVlbiBhcHBsaWVkXG4gICAgICovXG4gICAgaGFuZGxlVGVhbXNTaXplQ2hhbmdlID0gKGZpbHRlcmVkVGVhbXNTaXplOiBudW1iZXIpID0+IHtcbiAgICAgICAgdGhpcy5maWx0ZXJlZFRlYW1zU2l6ZSA9IGZpbHRlcmVkVGVhbXNTaXplO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBGb3JtYXRzIHRoZSByZXN1bHRzIGluIHRoZSBhdXRvY29tcGxldGUgb3ZlcmxheS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB0ZWFtXG4gICAgICovXG4gICAgc2VhcmNoUmVzdWx0Rm9ybWF0dGVyID0gZm9ybWF0VGVhbUFzU2VhcmNoUmVzdWx0O1xuXG4gICAgLyoqXG4gICAgICogQ29udmVydHMgYSB0ZWFtIG9iamVjdCB0byBhIHN0cmluZyB0aGF0IGNhbiBiZSBzZWFyY2hlZCBmb3IuIFRoaXMgaXNcbiAgICAgKiB1c2VkIGJ5IHRoZSBhdXRvY29tcGxldGUgc2VsZWN0IGluc2lkZSB0aGUgZGF0YSB0YWJsZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB0ZWFtIFRlYW0gdGhhdCB3YXMgc2VsZWN0ZWRcbiAgICAgKi9cbiAgICBzZWFyY2hUZXh0RnJvbVRlYW0gPSAodGVhbTogVGVhbSk6IHN0cmluZyA9PiB7XG4gICAgICAgIHJldHVybiB0ZWFtLnNob3J0TmFtZSE7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIElmIHRlYW0gZG9lcyBub3QgeWV0IGV4aXN0cyBpbiB0ZWFtcywgaXQgaXMgYXBwZW5kZWQuXG4gICAgICogSWYgdGVhbSBhbHJlYWR5IGV4aXN0cyBpbiB0ZWFtcywgaXQgaXMgdXBkYXRlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB0ZWFtIFRlYW0gdGhhdCBpcyBhZGRlZCBvciB1cGRhdGVkXG4gICAgICovXG4gICAgcHJpdmF0ZSB1cHNlcnRUZWFtKHRlYW06IFRlYW0pIHtcbiAgICAgICAgY29uc3QgaW5kZXggPSB0aGlzLnRlYW1zLmZpbmRJbmRleCgodCkgPT4gdC5pZCA9PT0gdGVhbS5pZCk7XG4gICAgICAgIGlmIChpbmRleCA9PT0gLTEpIHtcbiAgICAgICAgICAgIHRoaXMudGVhbXMgPSBbLi4udGhpcy50ZWFtcywgdGVhbV07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnRlYW1zID0gT2JqZWN0LmFzc2lnbihbXSwgdGhpcy50ZWFtcywgeyBbaW5kZXhdOiB0ZWFtIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGVsZXRlZCBhbiBleGlzdGluZyB0ZWFtIGZyb20gdGVhbXMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdGVhbSBUZWFtIHRoYXQgaXMgZGVsZXRlZFxuICAgICAqL1xuICAgIHByaXZhdGUgZGVsZXRlVGVhbSh0ZWFtOiBUZWFtKSB7XG4gICAgICAgIHRoaXMudGVhbXMgPSB0aGlzLnRlYW1zLmZpbHRlcigodCkgPT4gdC5pZCAhPT0gdGVhbS5pZCk7XG4gICAgfVxufVxuIiwiPGRpdj5cbiAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJtYi0zXCI+XG4gICAgICAgICAgICA8aDIgY2xhc3M9XCJtYi0xXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+e3sgZXhlcmNpc2U/LnRpdGxlIH19IC0gPC9zcGFuPnt7IGZpbHRlcmVkVGVhbXNTaXplIH19IDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5ob21lLnRpdGxlXCI+VGVhbXM8L3NwYW4+XG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJyYWRpby1pbmxpbmUgbWItMCBkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicmFkaW9cIiBbbmdNb2RlbF09XCJ0ZWFtQ3JpdGVyaWEuZmlsdGVyUHJvcFwiIChjbGljayk9XCJ1cGRhdGVUZWFtRmlsdGVyKEZpbHRlclByb3AuQUxMKVwiIFt2YWx1ZV09XCJGaWx0ZXJQcm9wLkFMTFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibXMtMVwiPnt7ICdhcnRlbWlzQXBwLnRlYW0uZmlsdGVycy5hbGwnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cInJhZGlvLWlubGluZSBtcy0yIG1iLTAgZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInJhZGlvXCIgW25nTW9kZWxdPVwidGVhbUNyaXRlcmlhLmZpbHRlclByb3BcIiAoY2xpY2spPVwidXBkYXRlVGVhbUZpbHRlcihGaWx0ZXJQcm9wLk9XTilcIiBbdmFsdWVdPVwiRmlsdGVyUHJvcC5PV05cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cIm1zLTFcIj57eyAnYXJ0ZW1pc0FwcC50ZWFtLmZpbHRlcnMub3duJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBtcy1hdXRvXCI+XG4gICAgICAgICAgICBAaWYgKGV4ZXJjaXNlPy5pc0F0TGVhc3RFZGl0b3IgJiYgdGVhbXMgJiYgdGVhbXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIDxqaGktdGVhbXMtZXhwb3J0LWJ1dHRvbiBjbGFzcz1cIm1lLTJcIiBbdGVhbXNdPVwidGVhbXNcIiBbYnV0dG9uU2l6ZV09XCJCdXR0b25TaXplLk1FRElVTVwiPjwvamhpLXRlYW1zLWV4cG9ydC1idXR0b24+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKGV4ZXJjaXNlPy5pc0F0TGVhc3RFZGl0b3IpIHtcbiAgICAgICAgICAgICAgICA8amhpLXRlYW1zLWltcG9ydC1idXR0b25cbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJtZS0yXCJcbiAgICAgICAgICAgICAgICAgICAgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCJcbiAgICAgICAgICAgICAgICAgICAgW3RlYW1zXT1cInRlYW1zXCJcbiAgICAgICAgICAgICAgICAgICAgW2J1dHRvblNpemVdPVwiQnV0dG9uU2l6ZS5NRURJVU1cIlxuICAgICAgICAgICAgICAgICAgICAoc2F2ZSk9XCJvblRlYW1zSW1wb3J0KCRldmVudClcIlxuICAgICAgICAgICAgICAgID48L2poaS10ZWFtcy1pbXBvcnQtYnV0dG9uPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgPGpoaS10ZWFtLXVwZGF0ZS1idXR0b24gW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCIgW2J1dHRvblNpemVdPVwiQnV0dG9uU2l6ZS5NRURJVU1cIiAoc2F2ZSk9XCJvblRlYW1VcGRhdGUoJGV2ZW50KVwiPjwvamhpLXRlYW0tdXBkYXRlLWJ1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgPGpoaS1kYXRhLXRhYmxlXG4gICAgICAgIFtpc0xvYWRpbmddPVwiaXNMb2FkaW5nXCJcbiAgICAgICAgZW50aXR5VHlwZT1cInRlYW1cIlxuICAgICAgICBbYWxsRW50aXRpZXNdPVwidGVhbXNcIlxuICAgICAgICBlbnRpdGllc1BlclBhZ2VUcmFuc2xhdGlvbj1cImFydGVtaXNBcHAuZXhlcmNpc2UucmVzdWx0c1BlclBhZ2VcIlxuICAgICAgICBzaG93QWxsRW50aXRpZXNUcmFuc2xhdGlvbj1cImFydGVtaXNBcHAuZXhlcmNpc2Uuc2hvd0FsbFJlc3VsdHNcIlxuICAgICAgICBzZWFyY2hQbGFjZWhvbGRlclRyYW5zbGF0aW9uPVwiYXJ0ZW1pc0FwcC5leGVyY2lzZS5zZWFyY2hGb3JUZWFtc1wiXG4gICAgICAgIFtzZWFyY2hGaWVsZHNdPVwiWyduYW1lJywgJ3Nob3J0TmFtZScsICdzdHVkZW50cy5uYW1lJywgJ3N0dWRlbnRzLmxvZ2luJywgJ293bmVyLm5hbWUnLCAnb3duZXIubG9naW4nXVwiXG4gICAgICAgIFtzZWFyY2hUZXh0RnJvbUVudGl0eV09XCJzZWFyY2hUZXh0RnJvbVRlYW1cIlxuICAgICAgICBbc2VhcmNoUmVzdWx0Rm9ybWF0dGVyXT1cInNlYXJjaFJlc3VsdEZvcm1hdHRlclwiXG4gICAgICAgIChlbnRpdGllc1NpemVDaGFuZ2UpPVwiaGFuZGxlVGVhbXNTaXplQ2hhbmdlKCRldmVudClcIlxuICAgID5cbiAgICAgICAgPG5nLXRlbXBsYXRlIGxldC1zZXR0aW5ncz1cInNldHRpbmdzXCIgbGV0LWNvbnRyb2xzPVwiY29udHJvbHNcIj5cbiAgICAgICAgICAgIDxuZ3gtZGF0YXRhYmxlXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJib290c3RyYXBcIlxuICAgICAgICAgICAgICAgIFtsaW1pdF09XCJzZXR0aW5ncy5saW1pdFwiXG4gICAgICAgICAgICAgICAgW3NvcnRUeXBlXT1cInNldHRpbmdzLnNvcnRUeXBlXCJcbiAgICAgICAgICAgICAgICBbY29sdW1uTW9kZV09XCJzZXR0aW5ncy5jb2x1bW5Nb2RlXCJcbiAgICAgICAgICAgICAgICBbaGVhZGVySGVpZ2h0XT1cInNldHRpbmdzLmhlYWRlckhlaWdodFwiXG4gICAgICAgICAgICAgICAgW2Zvb3RlckhlaWdodF09XCJzZXR0aW5ncy5mb290ZXJIZWlnaHRcIlxuICAgICAgICAgICAgICAgIFtyb3dIZWlnaHRdPVwic2V0dGluZ3Mucm93SGVpZ2h0XCJcbiAgICAgICAgICAgICAgICBbcm93c109XCJzZXR0aW5ncy5yb3dzXCJcbiAgICAgICAgICAgICAgICBbcm93Q2xhc3NdPVwic2V0dGluZ3Mucm93Q2xhc3NcIlxuICAgICAgICAgICAgICAgIFtzY3JvbGxiYXJIXT1cInNldHRpbmdzLnNjcm9sbGJhckhcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxuZ3gtZGF0YXRhYmxlLWNvbHVtbiBwcm9wPVwiaWRcIiBbbWluV2lkdGhdPVwiNjBcIiBbd2lkdGhdPVwiNjBcIiBbbWF4V2lkdGhdPVwiNjBcIj5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtaGVhZGVyLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtd3JhcHBlclwiIChjbGljayk9XCJjb250cm9scy5vblNvcnQoJ2lkJylcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC1sYWJlbCBib2xkIHNvcnRhYmxlXCIgamhpVHJhbnNsYXRlPVwiZ2xvYmFsLmZpZWxkLmlkXCI+IElEIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJjb250cm9scy5pY29uRm9yU29ydFByb3BGaWVsZCgnaWQnKVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZSBsZXQtdmFsdWU9XCJ2YWx1ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWycvY291cnNlLW1hbmFnZW1lbnQnLCBleGVyY2lzZT8uY291cnNlPy5pZCwgJ2V4ZXJjaXNlcycsIGV4ZXJjaXNlPy5pZCwgJ3RlYW1zJywgdmFsdWVdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgdmFsdWUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICA8L25neC1kYXRhdGFibGUtY29sdW1uPlxuICAgICAgICAgICAgICAgIDxuZ3gtZGF0YXRhYmxlLWNvbHVtbiBwcm9wPVwibmFtZVwiIFttaW5XaWR0aF09XCIxMDBcIiBbd2lkdGhdPVwiMTIwXCIgW21heFdpZHRoXT1cIjE2MFwiPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVyXCIgKGNsaWNrKT1cImNvbnRyb2xzLm9uU29ydCgnbmFtZScpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtbGFiZWwgYm9sZCBzb3J0YWJsZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5uYW1lLmxhYmVsXCI+IE5hbWUgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImNvbnRyb2xzLmljb25Gb3JTb3J0UHJvcEZpZWxkKCduYW1lJylcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwidmFsdWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IHZhbHVlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XG4gICAgICAgICAgICAgICAgPG5neC1kYXRhdGFibGUtY29sdW1uIFttaW5XaWR0aF09XCIxMDBcIiBbd2lkdGhdPVwiMTIwXCIgW21heFdpZHRoXT1cIjE2MFwiPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVyXCIgKGNsaWNrKT1cImNvbnRyb2xzLm9uU29ydCgnc2hvcnROYW1lJylcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC1sYWJlbCBib2xkIHNvcnRhYmxlXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC50ZWFtLnNob3J0TmFtZS5sYWJlbFwiPiBTaG9ydCBOYW1lIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJjb250cm9scy5pY29uRm9yU29ydFByb3BGaWVsZCgnc2hvcnROYW1lJylcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwicm93XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YSBbcm91dGVyTGlua109XCJbJy9jb3Vyc2UtbWFuYWdlbWVudCcsIGV4ZXJjaXNlPy5jb3Vyc2U/LmlkLCAnZXhlcmNpc2VzJywgZXhlcmNpc2U/LmlkLCAndGVhbXMnLCB2YWx1ZS5pZF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyB2YWx1ZS5zaG9ydE5hbWUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICA8L25neC1kYXRhdGFibGUtY29sdW1uPlxuICAgICAgICAgICAgICAgIDxuZ3gtZGF0YXRhYmxlLWNvbHVtbiBwcm9wPVwib3duZXJcIiBbbWluV2lkdGhdPVwiMTQwXCIgW3dpZHRoXT1cIjE2MFwiPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVyXCIgKGNsaWNrKT1cImNvbnRyb2xzLm9uU29ydCgnb3duZXIubmFtZScpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtbGFiZWwgYm9sZCBzb3J0YWJsZVwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS50dXRvclwiPiBUdXRvciA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiY29udHJvbHMuaWNvbkZvclNvcnRQcm9wRmllbGQoJ293bmVyLm5hbWUnKVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZSBsZXQtdmFsdWU9XCJ2YWx1ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChpc0FkbWluKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWycvYWRtaW4nLCAndXNlci1tYW5hZ2VtZW50JywgdmFsdWU/LmxvZ2luXVwiPiB7eyB2YWx1ZT8ubmFtZSB9fTwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWlzQWRtaW4gJiYgdmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBbaHJlZl09XCInbWFpbHRvOicgKyB2YWx1ZT8uZW1haWxcIj57eyB2YWx1ZT8ubmFtZSB9fTwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWlzQWRtaW4gJiYgIXZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmb250LXdlaWdodC1ib2xkXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC50ZWFtLmRldGFpbC5ub093bmVyXCI+Tm8gdHV0b3I8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgPC9uZ3gtZGF0YXRhYmxlLWNvbHVtbj5cbiAgICAgICAgICAgICAgICA8bmd4LWRhdGF0YWJsZS1jb2x1bW4gcHJvcD1cInN0dWRlbnRzXCIgW21pbldpZHRoXT1cIjIwMFwiIFt3aWR0aF09XCI2MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtaGVhZGVyLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtd3JhcHBlclwiIHN0eWxlPVwiY3Vyc29yOiB0ZXh0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtbGFiZWwgYm9sZFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAudGVhbS5zdHVkZW50c1wiPiBTdHVkZW50cyA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwidmFsdWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktdGVhbS1zdHVkZW50cy1saXN0IFtzdHVkZW50c109XCJ2YWx1ZVwiIFtyZW5kZXJMaW5rc109XCJpc0FkbWluXCI+PC9qaGktdGVhbS1zdHVkZW50cy1saXN0PlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XG4gICAgICAgICAgICAgICAgPG5neC1kYXRhdGFibGUtY29sdW1uIHByb3A9XCJcIiBbbWluV2lkdGhdPVwiMjIwXCIgW3dpZHRoXT1cIjIyMFwiIFttYXhXaWR0aF09XCIyMjBcIj5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZSBsZXQtdmFsdWU9XCJyb3dcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LTEwMCB0ZXh0LWVuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2UuaXNBdExlYXN0SW5zdHJ1Y3RvciB8fCB2YWx1ZS5vd25lcj8uaWQgPT09IGN1cnJlbnRVc2VyLmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktdGVhbS11cGRhdGUtYnV0dG9uIFtleGVyY2lzZV09XCJleGVyY2lzZVwiIFt0ZWFtXT1cInZhbHVlXCIgKHNhdmUpPVwib25UZWFtVXBkYXRlKCRldmVudClcIj48L2poaS10ZWFtLXVwZGF0ZS1idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2UuaXNBdExlYXN0SW5zdHJ1Y3Rvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLXRlYW0tZGVsZXRlLWJ1dHRvbiBjbGFzcz1cIm1zLTFcIiBbZXhlcmNpc2VdPVwiZXhlcmNpc2VcIiBbdGVhbV09XCJ2YWx1ZVwiIChkZWxldGUpPVwib25UZWFtRGVsZXRlKCRldmVudClcIj48L2poaS10ZWFtLWRlbGV0ZS1idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgPC9uZ3gtZGF0YXRhYmxlLWNvbHVtbj5cbiAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZT5cbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICA8L2poaS1kYXRhLXRhYmxlPlxuPC9kaXY+XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLQSxJQUFZLHdCQWlCQztBQWpCYjs7QUFBQSxLQUFBLFNBQVlBLHlCQUFzQjtBQUM5QixNQUFBQSx3QkFBQSxnQkFBQSxJQUFBO0FBQ0EsTUFBQUEsd0JBQUEsYUFBQSxJQUFBO0lBQ0osR0FIWSwyQkFBQSx5QkFBc0IsQ0FBQSxFQUFBO0FBaUI1QixJQUFPLE9BQVAsTUFBVztNQUNOO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUVBO01BQ0E7TUFDQTtNQUNBO01BRVAsY0FBQTtBQUNJLGFBQUssV0FBVyxDQUFBO01BQ3BCOzs7Ozs7QUNyQ0osU0FBUyxXQUFXLFlBQVksY0FBYyxPQUFPLFFBQVEsaUJBQWlCO0FBQzlFLFNBQXFCLGVBQWUsVUFBVTtBQUU5QyxTQUFTLFlBQVksY0FBYyxzQkFBc0IsS0FBSyxXQUFXLFdBQVc7QUFDcEYsU0FBUyxXQUFXOzs7QUFKcEIsU0FlYTtBQWZiOztBQUtBO0FBQ0E7QUFDQTtBQUVBOzs7O0FBTU0sSUFBTyw2QkFBUCxNQUFPLDRCQUEwQjtNQWdCZjtNQWYwQjtNQUVyQztNQUNBO01BQ0E7TUFDQSwwQkFBa0MsQ0FBQTtNQUVqQyxnQkFBZ0IsSUFBSSxhQUFZO01BQ2hDLFlBQVksSUFBSSxhQUFZO01BQzVCLHNCQUFzQixJQUFJLGFBQVk7TUFDdEMsZUFBZSxJQUFJLGFBQVk7TUFDL0Isa0JBQWtCLElBQUksYUFBWTtNQUU1QztNQUVBLFlBQW9CLGFBQXdCO0FBQXhCLGFBQUEsY0FBQTtNQUEyQjtNQUUvQyx1QkFBdUIsQ0FBQyxZQUFpQjtBQUNyQyxhQUFLLG9CQUFvQjtBQUN6QixhQUFLLGNBQWMsS0FBSyxPQUFPO01BQ25DO01BRUEsdUJBQXVCLE1BQUs7QUFDeEIsZUFBTyxLQUFLO01BQ2hCO01BRUEsd0JBQXdCLENBQUMsWUFBaUI7QUFDdEMsY0FBTSxFQUFFLE9BQU8sS0FBSSxJQUFLO0FBQ3hCLGVBQU8sR0FBRyxJQUFJLEtBQUssS0FBSztNQUM1QjtNQUVBLFdBQVcsQ0FBQyxVQUE2QjtBQUNyQyxlQUFPLE1BQU0sS0FDVCxhQUFhLEdBQUcsR0FDaEIscUJBQW9CLEdBQ3BCLElBQUksTUFBSztBQUNMLGVBQUssb0JBQW9CLEtBQUssS0FBSztBQUNuQyxlQUFLLGFBQWEsS0FBSyxLQUFLO0FBQzVCLGVBQUssZ0JBQWdCLEtBQUssTUFBUztRQUN2QyxDQUFDLEdBQ0QsSUFBSSxNQUFNLEtBQUssVUFBVSxLQUFLLElBQUksQ0FBQyxHQUNuQyxVQUFVLENBQUMsZ0JBQWU7QUFDdEIsY0FBSSxZQUFZLFNBQVMsR0FBRztBQUN4QixpQkFBSyxvQkFBb0IsS0FBSyxJQUFJO0FBQ2xDLG1CQUFPLGNBQWMsQ0FBQyxHQUFHLFdBQVcsR0FBRyxHQUFHLE1BQVMsQ0FBQyxDQUFDOztBQUV6RCxpQkFBTyxjQUFjO1lBQ2pCLEdBQUcsV0FBVztZQUNkLEtBQUssWUFDQSw4QkFBOEIsS0FBSyxRQUFRLEtBQUssVUFBVSxXQUFXLEVBQ3JFLEtBQUssSUFBSSxDQUFDLGtCQUFrQixjQUFjLElBQUssQ0FBQyxFQUNoRCxLQUNHLFdBQVcsTUFBSztBQUNaLG1CQUFLLGFBQWEsS0FBSyxJQUFJO0FBQzNCLHFCQUFPLEdBQUcsTUFBUztZQUN2QixDQUFDLENBQUM7V0FFYjtRQUNMLENBQUMsR0FDRCxJQUFJLE1BQU0sS0FBSyxVQUFVLEtBQUssS0FBSyxDQUFDLEdBQ3BDLElBQUksQ0FBQyxDQUFDLGFBQWEsS0FBSyxNQUFLO0FBR3pCLGNBQUksU0FBUyxNQUFNLFdBQVcsR0FBRztBQUM3QixpQkFBSyxnQkFBZ0IsS0FBSyxXQUFXOztRQUU3QyxDQUFDLEdBQ0QsSUFBSSxDQUFDLENBQUMsRUFBRSxLQUFLLE1BQU0sU0FBUyxDQUFBLENBQUUsR0FDOUIsSUFBSSxDQUFDLFVBQVM7QUFDVixxQkFBVyxNQUFLO0FBQ1oscUJBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxpQkFBaUIsUUFBUSxLQUFLO0FBQ25ELGtCQUFJLENBQUMsS0FBSyw0QkFBNEIsTUFBTSxDQUFDLENBQUMsR0FBRztBQUM3QyxxQkFBSyxpQkFBaUIsQ0FBQyxFQUFFLGFBQWEsWUFBWSxFQUFFOzs7VUFHaEUsQ0FBQztRQUNMLENBQUMsQ0FBQztNQUVWO01BRVEsNEJBQTRCLE1BQW9CO0FBQ3BELFlBQUksS0FBSyx3QkFBd0IsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLEVBQUUsU0FBUyxLQUFLLEVBQUUsR0FBRztBQUVqRSxpQkFBTzttQkFDQSxDQUFDLEtBQUssZ0JBQWdCO0FBRTdCLGlCQUFPO21CQUNBLENBQUMsS0FBSyxLQUFLLElBQUk7QUFFdEIsaUJBQU87O0FBSVgsZUFBTyxLQUFLLG1CQUFtQixLQUFLLEtBQUs7TUFDN0M7TUFFQSxJQUFZLG1CQUFnQjtBQUN4QixlQUFPLElBQUksS0FBSyxjQUFjLHNDQUFzQyxDQUFBLENBQUU7TUFDMUU7O3lCQW5HUyw2QkFBMEIsK0JBQUEsV0FBQSxDQUFBO01BQUE7Z0VBQTFCLDZCQUEwQixXQUFBLENBQUEsQ0FBQSx5QkFBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLGlDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBOzs7Ozs7Ozs7QUNmdkMsVUFBQSw0QkFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBO0FBTUksVUFBQSx3QkFBQSxjQUFBLFNBQUEsZ0VBQUEsUUFBQTtBQUFBLG1CQUFjLElBQUEscUJBQUEsT0FBQSxJQUFBO1VBQWlDLENBQUE7O0FBTm5ELFVBQUEsMEJBQUE7QUFXQSxVQUFBLG9CQUFBLEdBQUEsSUFBQTs7O0FBTkksVUFBQSx3QkFBQSxlQUFBLHlCQUFBLEdBQUEsR0FBQSxrQ0FBQSxDQUFBLEVBQXFFLGdCQUFBLElBQUEsUUFBQSxFQUFBLG1CQUFBLElBQUEscUJBQUEsRUFBQSxrQkFBQSxJQUFBLG9CQUFBOzs7OztvRkRVNUQsNEJBQTBCLEVBQUEsV0FBQSw2QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVmdkMsU0FBUyxhQUFBQyxZQUFXLGdCQUFBQyxlQUFjLFNBQUFDLFFBQWUsVUFBQUMsU0FBUSxhQUFBQyxrQkFBaUI7QUFDMUUsU0FBcUIsU0FBUyxpQkFBQUMsZ0JBQWUsT0FBTyxNQUFBQyxXQUFVO0FBRTlELFNBQVMsY0FBQUMsYUFBWSxRQUFRLE9BQUFDLE1BQUssYUFBQUMsWUFBVyxPQUFBQyxZQUFXO0FBS3hELFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsZ0JBQUFDLHFCQUFvQjs7OztBQVQ3QixVQWVhO0FBZmI7O0FBSUE7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFRTSxJQUFPLDJCQUFQLE1BQU8sMEJBQXdCO01BdUJiO01BdEJxQjtNQUN6QyxRQUFRLElBQUksUUFBTztNQUNuQixRQUFRLElBQUksUUFBTztNQUVWO01BRUE7TUFDQTtNQUNBO01BRUMsY0FBYyxJQUFJVixjQUFZO01BQzlCLFlBQVksSUFBSUEsY0FBWTtNQUM1QixzQkFBc0IsSUFBSUEsY0FBWTtNQUN0QyxlQUFlLElBQUlBLGNBQVk7TUFDL0Isa0JBQWtCLElBQUlBLGNBQVk7TUFFNUM7TUFDQSxlQUF1QixDQUFBO01BQ3ZCLHFCQUFxQjtNQUVyQjtNQUVBLFlBQW9CLGVBQXNDO0FBQXRDLGFBQUEsZ0JBQUE7TUFBeUM7TUFLN0QsV0FBUTtBQUNKLFlBQUksS0FBSyxLQUFLLE9BQU87QUFDakIsZUFBSyxRQUFRLFVBQVUsS0FBSyxLQUFLLEtBQUs7QUFDdEMsZUFBSyxvQkFBb0IsS0FBSyxzQkFBc0IsS0FBSyxLQUFLOztNQUV0RTtNQUVBLHVCQUF1QixDQUFDLFVBQWU7QUFDbkMsYUFBSyxvQkFBb0IsS0FBSyxzQkFBc0IsS0FBSztBQUN6RCxhQUFLLFlBQVksS0FBSyxLQUFLO01BQy9CO01BRUEsdUJBQXVCLE1BQUs7QUFDeEIsZUFBTyxLQUFLO01BQ2hCO01BRUEsd0JBQXdCLENBQUMsVUFBdUI7QUFDNUMsY0FBTSxFQUFFLE9BQU8sS0FBSSxJQUFLO0FBQ3hCLGVBQU8sR0FBRyxJQUFJLEtBQUssS0FBSztNQUM1QjtNQU9BLGtCQUFrQixhQUFxQixNQUFVO0FBQzdDLGVBQU8sQ0FBQyxLQUFLLE9BQU8sS0FBSyxJQUFJLEVBQUUsS0FBSyxDQUFDLFVBQVM7QUFDMUMsa0JBQVEsU0FBUyxJQUFJLFlBQVcsRUFBRyxTQUFTLFlBQVksWUFBVyxDQUFFO1FBQ3pFLENBQUM7TUFDTDtNQUVBLFdBQVcsQ0FBQyxVQUE2QjtBQUNyQyxjQUFNLHlCQUF5QixLQUFLLE1BQU0sS0FBSyxPQUFPLE1BQU0sQ0FBQyxLQUFLLGFBQWEsWUFBVyxDQUFFLENBQUM7QUFDN0YsY0FBTSxjQUFjLEtBQUs7QUFFekIsZUFBTyxNQUFNLE9BQU8sYUFBYSxzQkFBc0IsRUFBRSxLQUNyRFMsS0FBSSxNQUFLO0FBQ0wsZUFBSyxnQkFBZ0IsS0FBSyxNQUFTO1FBQ3ZDLENBQUMsR0FDREQsV0FBVSxDQUFDLGdCQUFlO0FBQ3RCLGVBQUssYUFBYSxLQUFLLEtBQUs7QUFDNUIsZUFBSyxVQUFVLEtBQUssSUFBSTtBQUV4QixnQkFBTSxzQkFBc0IsS0FBSyxxQkFBcUJILElBQUcsS0FBSyxZQUFZLElBQUksS0FBSyxpQkFBZ0I7QUFDbkcsaUJBQU9ELGVBQWMsQ0FBQ0MsSUFBRyxXQUFXLEdBQUcsbUJBQW1CLENBQUM7UUFDL0QsQ0FBQyxHQUNESSxLQUFJLE1BQU0sS0FBSyxVQUFVLEtBQUssS0FBSyxDQUFDLEdBQ3BDRCxXQUFVLENBQUMsQ0FBQyxhQUFhLFlBQVksTUFBSztBQUV0QyxnQkFBTSxRQUFRLENBQUMsU0FBZSxLQUFLLGtCQUFrQixhQUFhLElBQUk7QUFDdEUsaUJBQU9KLGVBQWMsQ0FBQ0MsSUFBRyxXQUFXLEdBQUdBLElBQUcsQ0FBQyxlQUFlLGVBQWUsYUFBYSxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDekcsQ0FBQyxHQUNESSxLQUFJLENBQUMsQ0FBQyxhQUFhLFlBQVksTUFBSztBQUNoQyxjQUFJLGdCQUFnQixhQUFhLFdBQVcsR0FBRztBQUMzQyxpQkFBSyxnQkFBZ0IsS0FBSyxXQUFXOztRQUU3QyxDQUFDLEdBQ0RGLEtBQUksQ0FBQyxDQUFDLEVBQUUsWUFBWSxNQUFNLGdCQUFnQixDQUFBLENBQUUsQ0FBQztNQUVyRDtNQUtBLG1CQUFnQjtBQUNaLGVBQU8sS0FBSyxjQUFjLHlCQUF5QixLQUFLLE9BQU8sSUFBRyxRQUFBLEVBQXNCLEtBQ3BGQSxLQUFJLENBQUMsa0JBQWtCLGNBQWMsSUFBSyxHQUMxQ0UsS0FBSSxDQUFDLGlCQUFnQjtBQUNqQixlQUFLLGVBQWU7QUFDcEIsZUFBSyxxQkFBcUI7UUFDOUIsQ0FBQyxHQUNESCxZQUFXLE1BQUs7QUFDWixlQUFLLHFCQUFxQjtBQUMxQixlQUFLLGFBQWEsS0FBSyxJQUFJO0FBQzNCLGlCQUFPRCxJQUFHLE1BQVM7UUFDdkIsQ0FBQyxDQUFDO01BRVY7O3lCQTFHUywyQkFBd0IsZ0NBQUEsdUJBQUEsQ0FBQTtNQUFBO2lFQUF4QiwyQkFBd0IsV0FBQSxDQUFBLENBQUEsdUJBQUEsQ0FBQSxHQUFBLFdBQUEsU0FBQSwrQkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7Ozs7Ozs7O0FDZnJDLFVBQUEsNkJBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQTtBQU9JLFVBQUEseUJBQUEsaUJBQUEsU0FBQSxpRUFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSxRQUFBO1VBQUEsQ0FBQSxFQUFtQixjQUFBLFNBQUEsOERBQUEsUUFBQTtBQUFBLG1CQUNMLElBQUEscUJBQUEsT0FBQSxJQUFBO1VBQWlDLENBQUEsRUFENUIsU0FBQSxTQUFBLDJEQUFBO0FBQUEsbUJBRVYsSUFBQSxNQUFBLEtBQVcsRUFBRTtVQUFDLENBQUEsRUFGSixTQUFBLFNBQUEsMkRBQUE7QUFBQSxtQkFHVixJQUFBLE1BQUEsS0FBVyxFQUFFO1VBQUMsQ0FBQTs7QUFWM0IsVUFBQSwyQkFBQTtBQWVBLFVBQUEscUJBQUEsR0FBQSxJQUFBOzs7QUFWSSxVQUFBLHlCQUFBLFlBQUEsSUFBQSxhQUFBLEVBQTBCLGVBQUEsMEJBQUEsR0FBQSxHQUFBLG9DQUFBLENBQUEsRUFBQSxXQUFBLElBQUEsS0FBQSxFQUFBLGdCQUFBLElBQUEsUUFBQSxFQUFBLG1CQUFBLElBQUEscUJBQUEsRUFBQSxrQkFBQSxJQUFBLG9CQUFBOzs7OztxRkRVakIsMEJBQXdCLEVBQUEsV0FBQSwyQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVmckMsU0FBUyxhQUFBTSxZQUFXLFNBQUFDLFFBQWUsYUFBQUMsWUFBVyx5QkFBeUI7QUFDdkUsU0FBMEIsY0FBYztBQUN4QyxTQUFTLHNCQUFzQjtBQUUvQixTQUFxQixXQUFBQyxnQkFBZTtBQUtwQyxTQUFTLGFBQUFDLFlBQVcsU0FBUyxZQUFZO0FBRXpDLFNBQVMsZ0JBQUFDLGVBQWMsYUFBQUMsa0JBQWlCO0FBR3hDLFNBQVMsT0FBTyx1QkFBdUIsUUFBUSxXQUFXLGtCQUFrQjs7Ozs7Ozs7QUNZeEQsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7O0FBRmMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxnQkFBQSwwQkFBQSxNQUFBLEdBQUE7Ozs7O0FBRmQsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLHlEQUFBLEdBQUEsQ0FBQTs7Ozs7QUFBQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsSUFBQSxZQUFBLElBQUEsU0FBQSxJQUFBLFdBQUEsSUFBQSxFQUFBOzs7OztBQTJCSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUFGYyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGdCQUFBLCtCQUFBLE1BQUEsR0FBQTs7Ozs7QUFGZCxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEseURBQUEsR0FBQSxDQUFBOzs7OztBQUFBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxJQUFBLFlBQUEsSUFBQSxTQUFBLElBQUEsV0FBQSxJQUFBLEVBQUE7Ozs7O0FBY0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQURzQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxTQUFBLEVBQWtCLFFBQUEsSUFBQTs7Ozs7QUFHcEQsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUF5RyxJQUFBLHFCQUFBLEdBQUEsdUNBQUE7QUFBb0MsSUFBQSwyQkFBQTtBQUNqSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBMkQsSUFBQSxxQkFBQSxHQUFBLHVDQUFBO0FBQXFDLElBQUEsMkJBQUE7QUFDaEcsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUE7QUFBUSxJQUFBLHFCQUFBLENBQUE7QUFBcUMsSUFBQSwyQkFBQTtBQUNqRCxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7O0FBRmdCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsT0FBQSwrQkFBQTs7Ozs7QUFJWixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQWtHLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFpQyxJQUFBLDJCQUFBO0FBQ3ZJLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7Ozs7QUFFSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQUg0RCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLG1CQUFBLDhCQUFBLEdBQUEsS0FBQSxPQUFBLEtBQUEsU0FBQSxDQUFBO0FBQ3BELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsc0VBQUEsT0FBQSxLQUFBLFdBQUEsNkNBQUE7Ozs7O0FBc0JKLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUFEc0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsU0FBQSxFQUFrQixRQUFBLElBQUE7Ozs7O0FBR3BELElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBMkcsSUFBQSxxQkFBQSxHQUFBLHVDQUFBO0FBQW9DLElBQUEsMkJBQUE7QUFDbkosSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTZELElBQUEscUJBQUEsR0FBQSx5Q0FBQTtBQUF1QyxJQUFBLDJCQUFBO0FBQ3BHLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBO0FBQVEsSUFBQSxxQkFBQSxDQUFBO0FBQXdDLElBQUEsMkJBQUE7QUFDcEQsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQUZnQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFFBQUEsa0NBQUE7Ozs7O0FBSVosSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFvRyxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBaUMsSUFBQSwyQkFBQTtBQUN6SSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7O0FBNEJZLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxDQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7Ozs7QUFIOEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEscUJBQUE7QUFDdEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSx1RUFBQSxRQUFBLG1CQUFBLFdBQUEsR0FBQSxpQ0FBQTs7Ozs7O0FBYlosSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7QUFDSixJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBMEIsSUFBQSxxQkFBQSxDQUFBO0FBQXdDLElBQUEsMkJBQUE7QUFDbEUsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUFrRSxJQUFBLHlCQUFBLFNBQUEsU0FBQSxxRUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxjQUFBLFlBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsZ0JBQUEsV0FBQSxDQUF3QjtJQUFBLENBQUE7QUFDL0YsSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDBEQUFBLEdBQUEsQ0FBQTtBQU1KLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7Ozs7OztBQWZZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsa0NBQUEsUUFBQSxHQUFBLDRCQUFBO0FBRW1ELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsYUFBQSxRQUFBLG1CQUFBLFdBQUEsQ0FBQTtBQUN6QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLElBQUEsWUFBQSxNQUFBLE1BQUEsWUFBQSxPQUFBLEdBQUE7QUFFYixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxVQUFBO0FBR2pCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLG1CQUFBLFdBQUEsSUFBQSxLQUFBLEVBQUE7Ozs7O0FBU0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBdUQsSUFBQSxxQkFBQSxHQUFBLEdBQUE7QUFBQyxJQUFBLDJCQUFBO0FBQ3hELElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQW1GLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFzQixJQUFBLDJCQUFBO0FBQzdHLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBOzs7Ozs7QUFVUSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUtJLElBQUEseUJBQUEsaUJBQUEsU0FBQSxrRkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBQSwwQkFBQSxRQUFBLCtCQUFBLE1BQUE7SUFBQSxDQUFBO0FBTEosSUFBQSwyQkFBQTtBQVFBLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxTQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQWtFLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUE4QixJQUFBLDJCQUFBO0FBQ2hHLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTs7OztBQVJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxRQUFBLDRCQUFBLEVBQTBDLGtCQUFBLDhCQUFBLEdBQUEsR0FBQSxDQUFBO0FBS3BCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLHFCQUFBOzs7QURuTHRELDhCQXdCYTtBQXhCYjs7QUFLQTtBQUNBO0FBQ0E7QUFLQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FBV00sSUFBTyw0QkFBUCxNQUFPLDJCQUF5QjtNQWtDdEI7TUFDQTtNQUNBO01BbkM4QjtNQUVqQztNQUNBO01BRVQ7TUFDQSxXQUFXO01BRVgsb0JBQW9CO01BQ3BCLGlDQUFpQztNQUNqQywwQkFBMEI7TUFDMUI7TUFFQSxpQkFBaUI7TUFDakIsOEJBQThCO01BQzlCLHVCQUF1QjtNQUN2QjtNQUVBLHVCQUE4QyxDQUFBO01BQzlDLCtCQUErQjtNQUV2QixxQkFBcUIsSUFBSUgsU0FBTztNQUMvQixpQ0FBaUM7TUFDakMsbUJBQW1CO01BRzVCLFNBQVM7TUFDVCxRQUFRO01BQ1IsWUFBWTtNQUNaLHdCQUF3QjtNQUN4QixhQUFhO01BRWIsWUFDWSxzQkFDQSxhQUNBLGFBQTJCO0FBRjNCLGFBQUEsdUJBQUE7QUFDQSxhQUFBLGNBQUE7QUFDQSxhQUFBLGNBQUE7TUFDVDtNQUtILFdBQVE7QUFDSixhQUFLLGdCQUFlO0FBQ3BCLGFBQUssb0JBQW9CLEtBQUssa0JBQWtCO01BQ3BEO01BRVEsa0JBQWU7QUFDbkIsYUFBSyxjQUFjQyxXQUFVLEtBQUssSUFBSTtNQUMxQztNQU1BLHVCQUF1QixXQUFpQjtBQUVwQyxhQUFLLFlBQVksWUFBWSxVQUFVLFlBQVc7QUFHbEQsYUFBSyxtQkFBbUIsS0FBSyxLQUFLLFlBQVksU0FBUztNQUMzRDtNQU1BLGtCQUFrQixNQUFZO0FBQzFCLFlBQUksQ0FBQyxLQUFLLG1CQUFtQjtBQUV6QixnQkFBTSxZQUFZLEtBQUssUUFBUSxlQUFlLEVBQUU7QUFDaEQsZUFBSyx1QkFBdUIsU0FBUztBQUNyQyxlQUFLLGlCQUFpQixjQUFhOztNQUUzQztNQUVBLElBQUksb0JBQWlCO0FBQ2pCLGVBQU8sQ0FBQyxDQUFDLEtBQUssWUFBWTtNQUM5QjtNQUVBLElBQUksbUJBQWdCO0FBQ2hCLGVBQU8sS0FBSyxTQUFTLFFBQVEsSUFBSSxXQUFXO01BQ2hEO01BRUEsSUFBSSxTQUFNO0FBQ04sZUFBTyxLQUFLLFNBQVM7TUFDekI7TUFFQSxJQUFJLHlDQUFzQztBQUN0QyxlQUFPLENBQUMsS0FBSztNQUNqQjtNQUVBLElBQUksK0JBQTRCO0FBQzVCLGVBQU8sS0FBSywwQ0FBMEMsQ0FBQyxLQUFLO01BQ2hFO01BRUEsSUFBWSxzQkFBbUI7QUFDM0IsY0FBTSxrQkFBa0IsS0FBSyxZQUFZLFNBQVU7QUFDbkQsZUFBTyxtQkFBbUIsS0FBSyxPQUFPLGVBQWdCLG1CQUFtQixLQUFLLE9BQU87TUFDekY7TUFNQSxtQkFBbUIsU0FBYTtBQUM1QixlQUFPLEtBQUssd0JBQXdCLE9BQU8sTUFBTTtNQUNyRDtNQU1BLG1CQUFtQixTQUFhO0FBQzVCLGNBQU0sV0FBVyxLQUFLLHdCQUF3QixPQUFPO0FBQ3JELGVBQU8sV0FBVyxTQUFTLFFBQVEsSUFBSTtNQUMzQztNQUVRLHdCQUF3QixTQUFhO0FBQ3pDLGVBQU8sS0FBSyxxQkFBcUIsS0FBSyxDQUFDLGFBQWEsU0FBUyxpQkFBaUIsUUFBUSxLQUFLO01BQy9GO01BRVEseUJBQXlCLFNBQWE7QUFDMUMsZUFBUSxLQUFLLHVCQUF1QixLQUFLLHFCQUFxQixPQUFPLENBQUMsYUFBYSxTQUFTLGlCQUFpQixRQUFRLEtBQUs7TUFDOUg7TUFFUSw4QkFBOEIsU0FBYTtBQUMvQyxlQUFPLEtBQUssWUFBWSxVQUFVLEtBQUssQ0FBQyxTQUFTLEtBQUssT0FBTyxRQUFRLEVBQUUsTUFBTTtNQUNqRjtNQU1BLGFBQWEsU0FBYTtBQUN0QixZQUFJLENBQUMsS0FBSyw4QkFBOEIsT0FBTyxHQUFHO0FBQzlDLGVBQUssWUFBWSxTQUFVLEtBQUssT0FBTzs7TUFFL0M7TUFNQSxnQkFBZ0IsU0FBYTtBQUN6QixhQUFLLFlBQVksV0FBVyxLQUFLLFlBQVksVUFBVSxPQUFPLENBQUMsU0FBUyxLQUFLLE9BQU8sUUFBUSxFQUFFO0FBQzlGLGFBQUsseUJBQXlCLE9BQU87TUFDekM7TUFNQSxjQUFjLE9BQVc7QUFDckIsYUFBSyxZQUFZLFFBQVE7TUFDN0I7TUFLQSxRQUFLO0FBQ0QsYUFBSyxZQUFZLFFBQVEsUUFBUTtNQUNyQztNQUtBLE9BQUk7QUFDQSxZQUFJLEtBQUssOEJBQThCO0FBQ25DOztBQUdKLGFBQUssT0FBT0EsV0FBVSxLQUFLLFdBQVc7QUFFdEMsWUFBSSxLQUFLLEtBQUssT0FBTyxRQUFXO0FBQzVCLGVBQUssd0JBQXdCLEtBQUssWUFBWSxPQUFPLEtBQUssVUFBVSxLQUFLLElBQUksQ0FBQztlQUMzRTtBQUNILGVBQUssd0JBQXdCLEtBQUssWUFBWSxPQUFPLEtBQUssVUFBVSxLQUFLLElBQUksQ0FBQzs7TUFFdEY7TUFFUSx3QkFBd0IsTUFBb0M7QUFDaEUsYUFBSyxXQUFXO0FBQ2hCLGFBQUssVUFBVTtVQUNYLE1BQU0sQ0FBQyxRQUFRLEtBQUssY0FBYyxHQUFHO1VBQ3JDLE9BQU8sQ0FBQyxVQUFVLEtBQUssWUFBWSxLQUFLO1NBQzNDO01BQ0w7TUFNQSxjQUFjLE1BQXdCO0FBQ2xDLGFBQUssWUFBWSxNQUFNLEtBQUssSUFBSTtBQUNoQyxhQUFLLFdBQVc7TUFDcEI7TUFNQSxZQUFZLG1CQUFvQztBQUM1QyxhQUFLLFdBQVc7QUFFaEIsY0FBTSxFQUFFLFVBQVUsT0FBTSxJQUFLLGtCQUFrQjtBQUUvQyxnQkFBUSxVQUFVO1VBQ2QsS0FBSztBQUNELGtCQUFNLEVBQUUsVUFBUyxJQUFLO0FBQ3RCLGlCQUFLLHVCQUF1QjtBQUM1QjtVQUNKO0FBQ0k7O01BRVo7TUFFUSxvQkFBb0IsWUFBMkI7QUFDbkQsbUJBQ0ssS0FDR0MsY0FBYSxHQUFHLEdBQ2hCQyxXQUFVLENBQUMsY0FBYyxLQUFLLFlBQVksa0JBQWtCLEtBQUssU0FBUyxRQUFTLFNBQVMsQ0FBQyxDQUFDLEVBRWpHLFVBQVUsQ0FBQyx5QkFBd0I7QUFDaEMsZ0JBQU0sZUFBZSxxQkFBcUI7QUFDMUMsZ0JBQU0sU0FBUyxlQUNULGlDQUFLLEtBQUssaUJBQWlCLFNBQTNCLEVBQW1DLENBQUMsS0FBSyw4QkFBOEIsR0FBRyxhQUFZLEtBQ3RGLEtBQUssS0FBSyxpQkFBaUIsUUFBUSxLQUFLLDhCQUE4QjtBQUM1RSxlQUFLLGlCQUFpQixVQUFVLFFBQVEsTUFBTSxJQUFJLE9BQU8sTUFBTTtRQUNuRSxDQUFDO01BQ1Q7O3lCQXRPUyw0QkFBeUIsZ0NBQUEsb0JBQUEsR0FBQSxnQ0FBQSxXQUFBLEdBQUEsZ0NBQUEsa0JBQUEsQ0FBQTtNQUFBO2lFQUF6Qiw0QkFBeUIsV0FBQSxDQUFBLENBQUEsd0JBQUEsQ0FBQSxHQUFBLFdBQUEsU0FBQSxnQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7Ozs7Ozs7O0FDeEJ0QyxVQUFBLDZCQUFBLEdBQUEsUUFBQSxHQUFBLENBQUE7QUFBdUUsVUFBQSx5QkFBQSxZQUFBLFNBQUEsOERBQUE7QUFBQSxtQkFBWSxJQUFBLEtBQUE7VUFBTSxDQUFBO0FBQ3JGLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLENBQUE7QUFDSixVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFBTSxVQUFBLHFCQUFBLEVBQUE7QUFBc0IsVUFBQSwyQkFBQTtBQUNoQyxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxVQUFBLENBQUE7QUFBZ0YsVUFBQSx5QkFBQSxTQUFBLFNBQUEsOERBQUE7QUFBQSxtQkFBUyxJQUFBLE1BQUE7VUFBTyxDQUFBO0FBQUUsVUFBQSwyQkFBQTtBQUN0RyxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsU0FBQSxDQUFBO0FBQXFGLFVBQUEscUJBQUEsSUFBQSxNQUFBO0FBQUksVUFBQSwyQkFBQTtBQUN6RixVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsU0FBQSxHQUFBLEVBQUE7QUFPSSxVQUFBLHlCQUFBLGlCQUFBLFNBQUEsbUVBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsWUFBQSxPQUFBO1VBQUEsQ0FBQSxFQUE4QixpQkFBQSxTQUFBLG1FQUFBLFFBQUE7QUFBQSxtQkFDYixJQUFBLGtCQUFBLE1BQUE7VUFBeUIsQ0FBQTtBQVI5QyxVQUFBLDJCQUFBO0FBV0EsVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwrQkFBQSxJQUFBLDJDQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7OztBQU9KLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsS0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBK0YsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBVSxVQUFBLDJCQUFBO0FBQ3pHLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxpQkFBQSxFQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLElBQUEsRUFBQTtBQVFJLFVBQUEseUJBQUEsaUJBQUEsU0FBQSxtRUFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSxZQUFBLFlBQUE7VUFBQSxDQUFBLEVBQW1DLGlCQUFBLFNBQUEsbUVBQUEsUUFBQTtBQUFBLG1CQUNsQixJQUFBLHVCQUFBLE1BQUE7VUFBOEIsQ0FBQTtBQVRuRCxVQUFBLDJCQUFBO0FBYUEsVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwrQkFBQSxJQUFBLDJDQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7OztBQU9KLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLEtBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsU0FBQSxFQUFBO0FBQXVFLFVBQUEscUJBQUEsSUFBQSxPQUFBO0FBQUssVUFBQSwyQkFBQTtBQUM1RSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsaUJBQUEsRUFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsbURBQUEsR0FBQSxDQUFBLEVBRUMsSUFBQSxtREFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLG1EQUFBLElBQUEsQ0FBQSxFQUFBLElBQUEsbURBQUEsR0FBQSxDQUFBLEVBQUEsSUFBQSxtREFBQSxHQUFBLENBQUE7QUFrQkwsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSx5QkFBQSxFQUFBO0FBTUksVUFBQSx5QkFBQSxlQUFBLFNBQUEsaUZBQUEsUUFBQTtBQUFBLG1CQUFlLElBQUEsY0FBQSxNQUFBO1VBQXFCLENBQUEsRUFBQyxhQUFBLFNBQUEsK0VBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsaUJBQUE7VUFBQSxDQUFBLEVBQUEsdUJBQUEsU0FBQSx5RkFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSw4QkFBQTtVQUFBLENBQUEsRUFBQSxtQkFBQSxTQUFBLHFGQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLGtDQUFBO1VBQUEsQ0FBQSxFQUFBLGdCQUFBLFNBQUEsa0ZBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsdUJBQUE7VUFBQSxDQUFBO0FBTXpDLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUF5RSxVQUFBLHFCQUFBLElBQUEsVUFBQTtBQUFRLFVBQUEsMkJBQUE7QUFDakYsVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLG1EQUFBLEdBQUEsQ0FBQSxFQUVDLElBQUEsbURBQUEsR0FBQSxDQUFBLEVBQUEsSUFBQSxtREFBQSxJQUFBLENBQUEsRUFBQSxJQUFBLG1EQUFBLEdBQUEsQ0FBQTtBQWFMLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsMkJBQUEsRUFBQTtBQU1JLFVBQUEseUJBQUEsaUJBQUEsU0FBQSxxRkFBQSxRQUFBO0FBQUEsbUJBQWlCLElBQUEsYUFBQSxNQUFBO1VBQW9CLENBQUEsRUFBQyxhQUFBLFNBQUEsaUZBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsb0JBQUE7VUFBQSxDQUFBLEVBQUEsdUJBQUEsU0FBQSwyRkFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSxpQ0FBQTtVQUFBLENBQUEsRUFBQSxtQkFBQSxTQUFBLHVGQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLHFDQUFBO1VBQUEsQ0FBQSxFQUFBLGdCQUFBLFNBQUEsb0ZBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsMEJBQUE7VUFBQSxDQUFBO0FBTTFDLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSwrQkFBQSxJQUFBLDJDQUFBLElBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7QUFtQkEsVUFBQSx5QkFBQSxJQUFBLG1EQUFBLElBQUEsQ0FBQTtBQVFKLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUEyRSxVQUFBLHFCQUFBLEtBQUEsd0JBQUE7QUFBc0IsVUFBQSwyQkFBQTtBQUNqRyxVQUFBLHFCQUFBLEdBQUE7QUFDQSxVQUFBLDZCQUFBLEtBQUEsUUFBQSxFQUFBO0FBQWtELFVBQUEscUJBQUEsS0FBQSxVQUFBO0FBQVEsVUFBQSwyQkFBQTtBQUM5RCxVQUFBLHFCQUFBLEtBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxLQUFBLHdCQUFBO0FBQUEsVUFBQSx5QkFBQSxLQUFBLG9EQUFBLElBQUEsQ0FBQTtBQWdCSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxLQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsS0FBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsS0FBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsS0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxLQUFBLE9BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsS0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxLQUFBLFVBQUEsRUFBQTtBQUEwRSxVQUFBLHlCQUFBLFNBQUEsU0FBQSwrREFBQTtBQUFBLG1CQUFTLElBQUEsTUFBQTtVQUFPLENBQUE7QUFDdEYsVUFBQSxxQkFBQSxLQUFBLGdCQUFBO0FBQUEsVUFBQSx3QkFBQSxLQUFBLFdBQUEsRUFBQTtBQUFrQyxVQUFBLHFCQUFBLEtBQUEsTUFBQTtBQUFNLFVBQUEsNkJBQUEsS0FBQSxRQUFBLEVBQUE7QUFBMEMsVUFBQSxxQkFBQSxLQUFBLFFBQUE7QUFBTSxVQUFBLDJCQUFBO0FBQzVGLFVBQUEscUJBQUEsS0FBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsS0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxLQUFBLFVBQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsS0FBQSxnQkFBQTtBQUFBLFVBQUEsd0JBQUEsS0FBQSxXQUFBLEVBQUE7QUFBbUMsVUFBQSxxQkFBQSxLQUFBLE1BQUE7QUFBTSxVQUFBLDZCQUFBLEtBQUEsUUFBQSxFQUFBO0FBQXdDLFVBQUEscUJBQUEsS0FBQSxNQUFBO0FBQUksVUFBQSwyQkFBQTtBQUN6RixVQUFBLHFCQUFBLEtBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLEtBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLEtBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEtBQUEsSUFBQTs7Ozs7O0FBak1rQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLGdCQUFBLElBQUEsWUFBQSxLQUFBLHFDQUFBLGtDQUFBO0FBQ0YsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSxzQkFBQSxJQUFBLFlBQUEsS0FBQSxnQkFBQSxlQUFBLGdCQUFBO0FBRUUsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSxLQUFBLElBQUEsU0FBQSxPQUFBLEdBQUE7QUFjRixVQUFBLHdCQUFBLEVBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsSUFBQSxZQUFBLElBQUE7QUFJSixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLDBCQUFBLElBQUEsSUFBQSwwQkFBQSxJQUFBLElBQUEsSUFBQSxNQUFBLEdBQUEsOEJBQUEsSUFBQSxHQUFBLENBQUEsQ0FBQTtBQW9CSSxVQUFBLHdCQUFBLEVBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsSUFBQSxnQkFBQSxFQUE0QixXQUFBLElBQUEsWUFBQSxTQUFBLEVBQUEsWUFBQSxJQUFBLGlCQUFBO0FBTWhDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsMEJBQUEsSUFBQSxJQUFBLDBCQUFBLElBQUEsSUFBQSxJQUFBLE1BQUEsR0FBQSw4QkFBQSxJQUFBLEdBQUEsQ0FBQSxDQUFBO0FBY0ksVUFBQSx3QkFBQSxFQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsaUJBQUEsS0FBQSxFQUFBO0FBR0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsOEJBQUEsS0FBQSxFQUFBO0FBR0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsa0NBQUEsS0FBQSxFQUFBO0FBTUEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsdUJBQUEsS0FBQSxFQUFBO0FBR0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsS0FBQSxPQUFBLElBQUEsS0FBQSxTQUFBLE9BQUEsT0FBQSxJQUFBLEtBQUEsTUFBQSxTQUFBLElBQUEsWUFBQSxTQUFBLE9BQUEsT0FBQSxJQUFBLFlBQUEsTUFBQSxNQUFBLEtBQUEsRUFBQTtBQVFBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsaUJBQUEsQ0FBQSxJQUFBLFNBQUEsbUJBQUEsRUFBK0MsVUFBQSxJQUFBLFNBQUEsTUFBQSxFQUFBLFlBQUEsSUFBQSxRQUFBLEVBQUEsUUFBQSxJQUFBLElBQUE7QUFlL0MsVUFBQSx3QkFBQSxFQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsb0JBQUEsS0FBQSxFQUFBO0FBR0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsaUNBQUEsS0FBQSxFQUFBO0FBR0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEscUNBQUEsS0FBQSxFQUFBO0FBTUEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsMEJBQUEsS0FBQSxFQUFBO0FBTUEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxVQUFBLElBQUEsU0FBQSxNQUFBLEVBQTJCLFlBQUEsSUFBQSxRQUFBLEVBQUEsUUFBQSxJQUFBLElBQUEsRUFBQSwyQkFBQSxJQUFBLFlBQUEsWUFBQSw4QkFBQSxJQUFBLEdBQUEsQ0FBQTtBQVkzQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsWUFBQSxRQUFBO0FBbUJBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLFlBQUEsWUFBQSxJQUFBLFlBQUEsU0FBQSxXQUFBLElBQUEsS0FBQSxFQUFBO0FBU29CLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsY0FBQSxDQUFBLElBQUEsc0NBQUEsRUFBNEQsaUJBQUEsSUFBQSxzQ0FBQTtBQUl4RSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLDhCQUFBLElBQUEsT0FBQSxhQUFBLE9BQUEsSUFBQSxPQUFBLGFBQUEsNEJBQUE7QUFHSixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEtBQUEsSUFBQSx5Q0FBQSxNQUFBLEVBQUE7QUFzQkMsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsS0FBQTtBQUVTLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsWUFBQSxJQUFBLFdBQUEsSUFBQSxZQUFBLElBQUEsNEJBQUE7QUFDVCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxNQUFBOzs7OztxRkR4S1IsMkJBQXlCLEVBQUEsV0FBQSw0QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUV4QnRDLFNBQVMsYUFBQUMsWUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFPLFVBQUFDLGVBQWM7QUFDdkQsU0FBUyxnQkFBNkI7QUFLdEMsU0FBUyxhQUFhLGNBQWM7OztBQU5wQyxJQW9CYTtBQXBCYjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFlTSxJQUFPLDRCQUFQLE1BQU8sMkJBQXlCO01BY2Q7TUFicEIsYUFBYTtNQUNiLGFBQWE7TUFFSjtNQUNBO01BQ0EsYUFBeUIsV0FBVztNQUVuQyxPQUEyQixJQUFJRixjQUFZO01BR3JELGNBQWM7TUFDZCxTQUFTO01BRVQsWUFBb0IsY0FBc0I7QUFBdEIsYUFBQSxlQUFBO01BQXlCO01BTTdDLHFCQUFxQixPQUFpQjtBQUNsQyxjQUFNLGdCQUFlO0FBQ3JCLGNBQU0sV0FBd0IsS0FBSyxhQUFhLEtBQUssMkJBQTJCLEVBQUUsVUFBVSxNQUFNLE1BQU0sTUFBTSxVQUFVLFNBQVEsQ0FBRTtBQUNsSSxpQkFBUyxrQkFBa0IsT0FBTyxLQUFLLFFBQVEsSUFBSSxLQUFJO0FBQ3ZELGlCQUFTLGtCQUFrQixXQUFXLEtBQUs7QUFFM0MsaUJBQVMsT0FBTyxLQUNaLENBQUMsU0FBZSxLQUFLLEtBQUssS0FBSyxJQUFJLEdBQ25DLE1BQUs7UUFBRSxDQUFDO01BRWhCOzt5QkE5QlMsNEJBQXlCLGdDQUFBLFdBQUEsQ0FBQTtNQUFBO2lFQUF6Qiw0QkFBeUIsV0FBQSxDQUFBLENBQUEsd0JBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxNQUFBLFFBQUEsVUFBQSxZQUFBLFlBQUEsYUFBQSxHQUFBLFNBQUEsRUFBQSxNQUFBLE9BQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsV0FBQSxXQUFBLFFBQUEsU0FBQSxTQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsbUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUFUOUIsVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsY0FBQSxDQUFBO0FBS0ksVUFBQSx5QkFBQSxXQUFBLFNBQUEsaUVBQUEsUUFBQTtBQUFBLG1CQUFXLElBQUEscUJBQUEsTUFBQTtVQUE0QixDQUFBO0FBQzFDLFVBQUEsMkJBQUE7QUFDTCxVQUFBLHFCQUFBLEdBQUEsUUFBQTs7O0FBTlEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxXQUFBLElBQUEsV0FBQSxPQUFBLEVBQThCLFdBQUEsSUFBQSxVQUFBLEVBQUEsUUFBQSxJQUFBLE9BQUEsSUFBQSxjQUFBLElBQUEsTUFBQSxFQUFBLFNBQUEsSUFBQSxPQUFBLHFDQUFBLGtDQUFBOzs7OztxRkFRN0IsMkJBQXlCLEVBQUEsV0FBQSw0QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUNwQnRDLFNBQVMsYUFBQUcsWUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFPLFVBQUFDLFNBQVEsYUFBQUMsa0JBQWlCO0FBQ2xFLFNBQXFCLFdBQUFDLFVBQVMsaUJBQUFDLGdCQUFlLFNBQUFDLFFBQU8sTUFBQUMsV0FBVTtBQUM5RCxTQUFTLGNBQUFDLGFBQVksVUFBQUMsU0FBUSxPQUFBQyxNQUFLLGFBQUFDLFlBQVcsT0FBQUMsWUFBVztBQUN4RCxTQUFTLHdCQUF3QjtBQUlqQyxTQUFTLGdCQUFBQyxxQkFBb0I7QUFDN0IsU0FBUyxlQUFlOzs7OztBQVJ4QixVQWVhO0FBZmI7O0FBSUE7QUFFQTtBQUdBOzs7O0FBTU0sSUFBTyw4QkFBUCxNQUFPLDZCQUEyQjtNQXFCeEI7TUFDQTtNQXJCNkI7TUFDekMsU0FBUyxJQUFJVCxTQUFPO01BQ3BCLFNBQVMsSUFBSUEsU0FBTztNQUVYO01BQ0E7TUFFQyxpQkFBaUIsSUFBSUosY0FBWTtNQUNqQyxZQUFZLElBQUlBLGNBQVk7TUFDNUIsc0JBQXNCLElBQUlBLGNBQVk7TUFDdEMsZUFBZSxJQUFJQSxjQUFZO01BQy9CLGtCQUFrQixJQUFJQSxjQUFZO01BRTVDO01BQ0Esa0JBQThCLENBQUE7TUFDOUIsd0JBQXdCO01BRXhCO01BRUEsWUFDWSxlQUNBLGtCQUFrQztBQURsQyxhQUFBLGdCQUFBO0FBQ0EsYUFBQSxtQkFBQTtNQUNUO01BRUgsdUJBQXVCLENBQUMsYUFBc0I7QUFDMUMsYUFBSyxvQkFBb0IsS0FBSyxzQkFBc0IsUUFBUTtBQUM1RCxhQUFLLGVBQWUsS0FBSyxRQUFRO01BQ3JDO01BRUEsdUJBQXVCLE1BQUs7QUFDeEIsZUFBTyxLQUFLO01BQ2hCO01BRUEsd0JBQXdCLENBQUMsYUFBOEI7QUFDbkQsY0FBTSxFQUFFLE9BQU8sWUFBVyxJQUFLO0FBQy9CLGNBQU0sT0FBTyxjQUFjLFlBQVksT0FBTyxnQkFBZ0IsT0FBTyxLQUFLLGlCQUFpQixhQUFhLFlBQVksQ0FBQyxJQUFJO0FBQ3pILGVBQU8sU0FBUyxjQUFjLEtBQUssSUFBSSxNQUFNO01BQ2pEO01BT0Esc0JBQXNCLFlBQW9CLFVBQWtCO0FBQ3hELGVBQU8sU0FBUyxNQUFPLFlBQVcsRUFBRyxTQUFTLFdBQVcsWUFBVyxDQUFFO01BQzFFO01BRUEsV0FBVyxDQUFDLFVBQTZCO0FBQ3JDLGNBQU0seUJBQXlCLEtBQUssT0FBTyxLQUFLUyxRQUFPLE1BQU0sQ0FBQyxLQUFLLGFBQWEsWUFBVyxDQUFFLENBQUM7QUFDOUYsY0FBTSxjQUFjLEtBQUs7QUFFekIsZUFBT0gsT0FBTSxPQUFPLGFBQWEsc0JBQXNCLEVBQUUsS0FDckRNLEtBQUksTUFBSztBQUNMLGVBQUssZ0JBQWdCLEtBQUssTUFBUztRQUN2QyxDQUFDLEdBQ0RELFdBQVUsQ0FBQyxlQUFjO0FBQ3JCLGVBQUssYUFBYSxLQUFLLEtBQUs7QUFDNUIsZUFBSyxVQUFVLEtBQUssSUFBSTtBQUV4QixnQkFBTSx5QkFBeUIsS0FBSyx3QkFBd0JKLElBQUcsS0FBSyxlQUFlLElBQUksS0FBSyxvQkFBbUI7QUFDL0csaUJBQU9GLGVBQWMsQ0FBQ0UsSUFBRyxVQUFVLEdBQUcsc0JBQXNCLENBQUM7UUFDakUsQ0FBQyxHQUNESyxLQUFJLE1BQU0sS0FBSyxVQUFVLEtBQUssS0FBSyxDQUFDLEdBQ3BDRCxXQUFVLENBQUMsQ0FBQyxZQUFZLGVBQWUsTUFBSztBQUV4QyxnQkFBTSxRQUFRLENBQUMsYUFBdUIsS0FBSyxzQkFBc0IsWUFBWSxRQUFRO0FBQ3JGLGlCQUFPTixlQUFjLENBQUNFLElBQUcsVUFBVSxHQUFHQSxJQUFHLENBQUMsa0JBQWtCLGtCQUFrQixnQkFBZ0IsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQ2pILENBQUMsR0FDREssS0FBSSxDQUFDLENBQUMsWUFBWSxlQUFlLE1BQUs7QUFDbEMsY0FBSSxtQkFBbUIsZ0JBQWdCLFdBQVcsR0FBRztBQUNqRCxpQkFBSyxnQkFBZ0IsS0FBSyxVQUFVOztRQUU1QyxDQUFDLEdBQ0RGLEtBQUksQ0FBQyxDQUFDLEVBQUUsZUFBZSxNQUFNLG1CQUFtQixDQUFBLENBQUUsR0FDbERBLEtBQUksQ0FBQyxvQkFBb0IsUUFBUSxpQkFBaUIsQ0FBQyxlQUFlLElBQUksQ0FBQyxDQUFDLENBQUM7TUFFakY7TUFLQSxzQkFBbUI7QUFDZixlQUFPLEtBQUssY0FDUCxrQkFBa0IsS0FBSyxPQUFPLEVBQUcsRUFDakMsS0FBS0EsS0FBSSxDQUFDLG1CQUFtQixlQUFlLEtBQU0sYUFBYSxDQUFBLENBQUUsQ0FBQyxFQUNsRSxLQUFLQSxLQUFJLENBQUMsY0FBYyxVQUFVLE9BQU8sQ0FBQyxhQUFhLFNBQVMsUUFBUSxDQUFDLENBQUMsRUFDMUUsS0FBS0EsS0FBSSxDQUFDLGNBQWMsVUFBVSxPQUFPLENBQUMsYUFBYSxDQUFDLEtBQUssZ0JBQWdCLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLFNBQVMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQ3JILEtBQ0dFLEtBQUksQ0FBQyxvQkFBbUI7QUFDcEIsZUFBSyxrQkFBa0I7QUFDdkIsZUFBSyx3QkFBd0I7UUFDakMsQ0FBQyxDQUFDLEVBRUwsS0FDR0osWUFBVyxNQUFLO0FBQ1osZUFBSyx3QkFBd0I7QUFDN0IsZUFBSyxhQUFhLEtBQUssSUFBSTtBQUMzQixpQkFBT0QsSUFBRyxJQUFJO1FBQ2xCLENBQUMsQ0FBQztNQUVkOzt5QkF0R1MsOEJBQTJCLGdDQUFBLHVCQUFBLEdBQUEsZ0NBQUEsb0JBQUEsQ0FBQTtNQUFBO2lFQUEzQiw4QkFBMkIsV0FBQSxDQUFBLENBQUEsMEJBQUEsQ0FBQSxHQUFBLFdBQUEsU0FBQSxrQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7Ozs7Ozs7O0FDZnhDLFVBQUEsNkJBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQTtBQU1JLFVBQUEseUJBQUEsaUJBQUEsU0FBQSxvRUFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSxXQUFBO1VBQUEsQ0FBQSxFQUFzQixjQUFBLFNBQUEsaUVBQUEsUUFBQTtBQUFBLG1CQUNSLElBQUEscUJBQUEsT0FBQSxJQUFBO1VBQWlDLENBQUEsRUFEekIsU0FBQSxTQUFBLDhEQUFBO0FBQUEsbUJBRWIsSUFBQSxPQUFBLEtBQVksRUFBRTtVQUFDLENBQUEsRUFGRixTQUFBLFNBQUEsOERBQUE7QUFBQSxtQkFHYixJQUFBLE9BQUEsS0FBWSxFQUFFO1VBQUMsQ0FBQTs7QUFUNUIsVUFBQSwyQkFBQTtBQWNBLFVBQUEscUJBQUEsR0FBQSxJQUFBOzs7QUFUSSxVQUFBLHlCQUFBLGVBQUEsMEJBQUEsR0FBQSxHQUFBLHlDQUFBLENBQUEsRUFBNEUsV0FBQSxJQUFBLFFBQUEsRUFBQSxnQkFBQSxJQUFBLFFBQUEsRUFBQSxtQkFBQSxJQUFBLHFCQUFBLEVBQUEsa0JBQUEsSUFBQSxvQkFBQTs7Ozs7cUZEVW5FLDZCQUEyQixFQUFBLFdBQUEsOEJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFZnhDLFNBQVMsbUJBQW1CLGFBQUFPLFlBQVcsZ0JBQUFDLGVBQWMsVUFBQUMsZUFBYztBQUNuRSxTQUFTLGFBQUFDLGtCQUFpQjtBQUMxQixTQUFTLG9CQUFBQyx5QkFBd0I7QUFJakMsU0FBUyxhQUFhOzs7Ozs7QUNGZCxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQURxQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxTQUFBLEVBQWtCLFFBQUEsSUFBQTs7O0FESjNELElBUU0sWUE0Qk87QUFwQ2I7O0FBR0E7QUFDQTtBQUNBOzs7QUFHQSxJQUFNLGFBQWEsT0FBTyxPQUFPO01BQzdCLG9CQUFvQjtNQUNwQixnQkFBZ0I7TUFDaEIscUJBQXFCO01BQ3JCLE1BQU07TUFDTixTQUFTO01BQ1QsVUFBVTtNQUNWLFdBQVc7TUFDWCxZQUFZO01BQ1osVUFBVTtNQUNWLFNBQVM7TUFDVCxPQUFPO01BQ1AsVUFBVTtNQUNWLE1BQU07TUFDTixVQUFVO01BQ1YsY0FBYztNQUNkLE1BQU07TUFDTixVQUFVO01BQ1YsUUFBUTtLQUNYO0FBU0ssSUFBTyxtQ0FBUCxNQUFPLGtDQUFnQztNQVk3QjtNQUNBO01BWkYsZUFBZSxJQUFJSCxjQUFZO01BQ3pDO01BQ0EsZ0JBQW1DLENBQUE7TUFDbkM7TUFDQTtNQUNBO01BR0EsWUFBWUU7TUFFWixZQUNZLGdCQUNBLGtCQUFrQztBQURsQyxhQUFBLGlCQUFBO0FBQ0EsYUFBQSxtQkFBQTtNQUNUO01BTUgscUJBQWtCO0FBQ2QsZUFBTyxJQUFJLFdBQVU7TUFDekI7TUFNTSxpQkFBaUIsWUFBc0I7O0FBQ3pDLGNBQUk7QUFFQSxnQkFBSSxLQUFLLFlBQVksU0FBUyxvQkFBb0I7QUFDOUMsbUJBQUssZ0JBQWdCLEtBQUssTUFBTSxXQUFXLE1BQWdCO3VCQUNwRCxLQUFLLFlBQVksU0FBUyxZQUFZO0FBQzdDLG9CQUFNLGFBQWEsTUFBTSxLQUFLLGFBQWEsV0FBVyxNQUFnQjtBQUN0RSxtQkFBSyxnQkFBZ0IsS0FBSyxrQkFBa0IsVUFBVTttQkFDbkQ7QUFDSCxvQkFBTSxJQUFJLE1BQU0sS0FBSyxpQkFBaUIsUUFBUSxtQ0FBbUMsRUFBRSxVQUFVLEtBQUssWUFBWSxLQUFJLENBQUUsQ0FBQzs7QUFFekgsaUJBQUssY0FBYyxLQUFLLGFBQWEsS0FBSyxhQUFhO0FBQ3ZELGlCQUFLLGFBQWEsS0FBSyxLQUFLLFdBQVc7QUFDdkMsaUJBQUssVUFBVTtBQUVmLGlCQUFLLGFBQWE7QUFDbEIsaUJBQUssaUJBQWlCO0FBQ3RCLGtCQUFNLFVBQVUsU0FBUyxlQUFlLGlCQUFpQjtBQUN6RCxnQkFBSSxTQUFTO0FBQ1Qsc0JBQVEsUUFBUTs7bUJBRWYsR0FBRztBQUNSLGlCQUFLLFVBQVU7QUFDZixrQkFBTSxVQUFVLEdBQUcsS0FBSyxpQkFBaUIsUUFBUSxxQ0FBcUMsQ0FBQyxJQUFJLENBQUM7QUFDNUYsa0JBQU0sT0FBTzs7UUFFckI7O01BTUEsY0FBYyxPQUFVO0FBQ3BCLFlBQUksTUFBTSxPQUFPLE1BQU0sUUFBUTtBQUMzQixnQkFBTSxXQUFxQixNQUFNLE9BQU87QUFDeEMsZUFBSyxhQUFhLFNBQVMsQ0FBQztBQUM1QixlQUFLLGlCQUFpQixLQUFLLFdBQVc7QUFDdEMsZUFBSyxVQUFVOztBQUVuQixZQUFJLENBQUMsS0FBSyxZQUFZO0FBQ2xCOztBQUVKLGNBQU0sYUFBYSxLQUFLLG1CQUFrQjtBQUMxQyxtQkFBVyxTQUFTLE1BQU0sS0FBSyxpQkFBaUIsVUFBVTtBQUMxRCxtQkFBVyxXQUFXLEtBQUssVUFBVTtBQUNyQyxhQUFLLGVBQWUsY0FBYTtNQUNyQztNQU1RLGFBQWEsS0FBVztBQUM1QixlQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVTtBQUNuQyxnQkFBTSxLQUFLO1lBQ1AsVUFBVTtZQUNWLFFBQVE7WUFDUixpQkFBaUIsQ0FBQyxXQUFtQixPQUFPLFlBQVcsRUFBRyxRQUFRLEtBQUssRUFBRSxFQUFFLFFBQVEsS0FBSyxFQUFFO1lBQzFGLGdCQUFnQjtZQUNoQixVQUFVLENBQUMsWUFBWSxRQUFRLFFBQVEsSUFBa0I7WUFDekQsT0FBTyxDQUFDLFVBQWUsT0FBTyxLQUFLO1dBQ3RDO1FBQ0wsQ0FBQztNQUNMO01BTUEsa0JBQWtCLFNBQW1CO0FBQ2pDLGVBQU8sUUFBUSxJQUNYLENBQUMsV0FDSTtVQUNHLG9CQUFvQixNQUFNLFdBQVcsa0JBQWtCLEtBQUssTUFBTSxXQUFXLGNBQWMsS0FBSyxNQUFNLFdBQVcsbUJBQW1CLEtBQUs7VUFDekksVUFDSSxNQUFNLFdBQVcsS0FBSyxLQUN0QixNQUFNLFdBQVcsUUFBUSxLQUN6QixNQUFNLFdBQVcsSUFBSSxLQUNyQixNQUFNLFdBQVcsUUFBUSxLQUN6QixNQUFNLFdBQVcsWUFBWSxLQUM3QjtVQUNKLFdBQVcsTUFBTSxXQUFXLFNBQVMsS0FBSyxNQUFNLFdBQVcsT0FBTyxLQUFLO1VBQ3ZFLFVBQ0ksTUFBTSxXQUFXLFFBQVEsS0FDekIsTUFBTSxXQUFXLFVBQVUsS0FDM0IsTUFBTSxXQUFXLE9BQU8sS0FDeEIsTUFBTSxXQUFXLElBQUksS0FDckIsTUFBTSxXQUFXLFFBQVEsS0FDekI7VUFDSixVQUFVLE1BQU0sV0FBVyxRQUFRLEtBQUssTUFBTSxXQUFXLElBQUksS0FBSyxNQUFNLFdBQVcsTUFBTSxLQUFLO1VBQzdFO01BRWpDO01BS0EsYUFBYSxZQUE2QjtBQUN0QyxjQUFNLFFBQWdCLENBQUE7QUFDdEIsbUJBQVcsUUFBUSxDQUFDLFNBQVMsVUFBUztBQUNsQyxnQkFBTSxhQUFhLElBQUksS0FBSTtBQUMzQixxQkFBVyxZQUFZLFFBQVEsYUFBYTtBQUM1QyxxQkFBVyxXQUFXLFFBQVEsWUFBWTtBQUMxQyxxQkFBVyw0QkFBNEIsUUFBUTtBQUMvQyxxQkFBVyxRQUFRLFFBQVE7QUFDM0IsZ0JBQU0sVUFBVSxRQUFRO0FBRXhCLGVBQUssT0FBTyxRQUFRLGFBQWEsWUFBWSxDQUFDLFFBQVEsU0FBUyxLQUFJLE9BQVEsT0FBTyxRQUFRLHVCQUF1QixZQUFZLENBQUMsUUFBUSxtQkFBbUIsS0FBSSxJQUFLO0FBQzlKLGtCQUFNLElBQUksTUFBTSxLQUFLLGlCQUFpQixRQUFRLHVDQUF1QyxFQUFFLFFBQU8sQ0FBRSxDQUFDOztBQUVyRyxxQkFBVyxPQUFPLEdBQUcsV0FBVyxTQUFTLElBQUksV0FBVyxRQUFRLEdBQUcsS0FBSTtBQUV2RSxjQUFJLE9BQU8sUUFBUSxhQUFhLFlBQVksQ0FBQyxRQUFRLFNBQVMsS0FBSSxHQUFJO0FBQ2xFLGtCQUFNLElBQUksTUFBTSxLQUFLLGlCQUFpQixRQUFRLDRDQUE0QyxFQUFFLFNBQVMsYUFBYSxXQUFXLEtBQUksQ0FBRSxDQUFDOztBQUd4SSxnQkFBTSxZQUFZLFFBQVEsU0FBUyxRQUFRLGVBQWUsRUFBRSxFQUFFLFlBQVc7QUFDekUsY0FBSSxDQUFDLFVBQVUsTUFBTSxrQkFBa0IsR0FBRztBQUN0QyxrQkFBTSxJQUFJLE1BQU0sS0FBSyxpQkFBaUIsUUFBUSxvQ0FBb0MsRUFBRSxTQUFTLFVBQVUsVUFBUyxDQUFFLENBQUM7O0FBR3ZILGdCQUFNLFlBQVksTUFBTSxVQUFVLENBQUMsU0FBUyxLQUFLLFNBQVMsUUFBUSxRQUFRO0FBQzFFLGNBQUksY0FBYyxJQUFJO0FBQ2xCLGtCQUFNLFVBQVUsSUFBSSxLQUFJO0FBQ3hCLG9CQUFRLE9BQU8sUUFBUTtBQUN2QixvQkFBUSxZQUFZO0FBQ3BCLG9CQUFRLFdBQVcsQ0FBQyxVQUFVO0FBQzlCLGtCQUFNLEtBQUssT0FBTztpQkFDZjtBQUNILGtCQUFNLFNBQVMsRUFBRSxXQUFXLENBQUMsR0FBRyxNQUFNLFNBQVMsRUFBRSxVQUFXLFVBQVU7O1FBRTlFLENBQUM7QUFDRCxlQUFPO01BQ1g7O3lCQWpLUyxtQ0FBZ0MsZ0NBQUEscUJBQUEsR0FBQSxnQ0FBQSxvQkFBQSxDQUFBO01BQUE7aUVBQWhDLG1DQUFnQyxXQUFBLENBQUEsQ0FBQSxpQ0FBQSxDQUFBLEdBQUEsU0FBQSxFQUFBLGNBQUEsZUFBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsZ0JBQUEsb0NBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxRQUFBLHNDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxNQUFBLG1CQUFBLFFBQUEsUUFBQSxVQUFBLGNBQUEsZUFBQSxrQkFBQSxHQUFBLHFCQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxHQUFBLFFBQUEsTUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDBDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDcEM3QyxVQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQUE0RSxVQUFBLHFCQUFBLEdBQUEsYUFBQTtBQUFXLFVBQUEsMkJBQUE7QUFDdkYsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLHdCQUFBLEdBQUEsaUJBQUEsQ0FBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLHlEQUFBLEdBQUEsQ0FBQTtBQUdKLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLENBQUE7QUFBc0YsVUFBQSx5QkFBQSxVQUFBLFNBQUEsbUVBQUEsUUFBQTtBQUFBLG1CQUFVLElBQUEsY0FBQSxNQUFBO1VBQXFCLENBQUE7QUFBckgsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUFQSSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxVQUFBLElBQUEsRUFBQTs7Ozs7cUZEaUNTLGtDQUFnQyxFQUFBLFdBQUEsbUNBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFcEM3QyxTQUFTLGFBQUFFLFlBQVcsU0FBQUMsUUFBMEIsYUFBQUMsWUFBVyxxQkFBQUMsMEJBQXlCO0FBQ2xGLFNBQVMsVUFBQUMsZUFBYztBQUN2QixTQUFTLGtCQUFBQyx1QkFBc0I7QUFHL0IsU0FBUyxXQUFBQyxnQkFBZTtBQUt4QixTQUFTLGVBQWU7QUFFeEIsU0FBUyxTQUFBQyxRQUFPLGVBQWUsYUFBQUMsWUFBVyxnQkFBZ0I7Ozs7Ozs7O0FDUzFDLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBbUYsSUFBQSxxQkFBQSxHQUFBLGdFQUFBO0FBQThELElBQUEsMkJBQUE7QUFDckosSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBK0UsSUFBQSxxQkFBQSxHQUFBLHlFQUFBO0FBQXVFLElBQUEsMkJBQUE7QUFDMUosSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7Ozs7QUFHQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxtQ0FBQSxFQUFBO0FBQWlDLElBQUEseUJBQUEsZ0JBQUEsU0FBQSwyR0FBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBZ0IsMEJBQUEsUUFBQSxlQUFBLE1BQUEsQ0FBc0I7SUFBQSxDQUFBO0FBQUUsSUFBQSwyQkFBQTtBQUM3RSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxZQUFBOzs7OztBQVNnQixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRHFDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLFNBQUEsRUFBa0IsUUFBQSxJQUFBOzs7OztBQUduRCxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE4RCxJQUFBLHFCQUFBLEdBQUEseURBQUE7QUFBdUQsSUFBQSwyQkFBQTtBQUN6SCxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTJFLElBQUEscUJBQUEsR0FBQSwwREFBQTtBQUF3RCxJQUFBLDJCQUFBO0FBQ25JLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBO0FBQVEsSUFBQSxxQkFBQSxDQUFBO0FBQXlDLElBQUEsMkJBQUE7QUFDckQsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQUZnQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFFBQUEsbUNBQUE7Ozs7O0FBSVosSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE4RixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBaUMsSUFBQSwyQkFBQTtBQUNuSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7OztBQXRCUixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUFnRixJQUFBLHFCQUFBLEdBQUEsaUJBQUE7QUFBZSxJQUFBLDJCQUFBO0FBQy9GLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxpQkFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxtRUFBQSxHQUFBLENBQUEsRUFFQyxJQUFBLG1FQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsbUVBQUEsSUFBQSxDQUFBLEVBQUEsSUFBQSxtRUFBQSxHQUFBLENBQUE7QUFlTCxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLDRCQUFBLEVBQUE7QUFJSSxJQUFBLHlCQUFBLGtCQUFBLFNBQUEsdUdBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQWtCLDBCQUFBLFFBQUEsdUJBQUEsTUFBQSxDQUE4QjtJQUFBLENBQUEsRUFBQyxhQUFBLFNBQUEsa0dBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQUEsUUFBQSxxQkFBQSxNQUFBO0lBQUEsQ0FBQSxFQUFBLG1CQUFBLFNBQUEsd0dBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQUEsUUFBQSxzQ0FBQSxNQUFBO0lBQUEsQ0FBQSxFQUFBLGdCQUFBLFNBQUEscUdBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQUEsUUFBQSwyQkFBQSxNQUFBO0lBQUEsQ0FBQTtBQUtyRCxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBOzs7O0FBN0JZLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLHFCQUFBLEtBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLHdDQUFBLEtBQUEsS0FBQSxFQUFBO0FBS0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsc0NBQUEsS0FBQSxFQUFBO0FBTUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsMkJBQUEsS0FBQSxFQUFBO0FBTUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxVQUFBLE9BQUEsU0FBQSxNQUFBLEVBQTJCLG1CQUFBLDhCQUFBLEdBQUFDLE1BQUEsT0FBQSxRQUFBLENBQUE7Ozs7O0FBa0J2QixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRHFDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLFNBQUEsRUFBa0IsUUFBQSxJQUFBOzs7OztBQUduRCxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQStGLElBQUEscUJBQUEsR0FBQSwyQ0FBQTtBQUF3QyxJQUFBLDJCQUFBO0FBQzNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7Ozs7QUFNWSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUNKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBS0ksSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUF1QixJQUFBLHFCQUFBLENBQUE7QUFBb0IsSUFBQSwyQkFBQTtBQUMzQyxJQUFBLHFCQUFBLElBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsMEJBQUEsRUFBQTtBQU9BLElBQUEscUJBQUEsSUFBQSw0Q0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQ0FBQTs7Ozs7O0FBbEJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsOENBQUEsUUFBQSxHQUFBLHdDQUFBO0FBSUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxhQUFBLFFBQUEsd0NBQUEsU0FBQSxTQUFBLFNBQUEsQ0FBQSxFQUFxRixlQUFBLFFBQUEsK0JBQUEsUUFBQSxDQUFBO0FBRzlELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsU0FBQSxTQUFBO0FBR25CLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxTQUFBLFlBQUEsOEJBQUEsSUFBQUMsSUFBQSxDQUFBLEVBQWdDLHNCQUFBLFFBQUEsaUJBQUEsRUFBQSwwQkFBQSxJQUFBLEVBQUEsbUNBQUEsUUFBQSw4QkFBQTs7Ozs7QUFjaEMsSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE4RCxJQUFBLHFCQUFBLEdBQUEscUNBQUE7QUFBa0MsSUFBQSwyQkFBQTtBQUNwRyxJQUFBLHFCQUFBLEdBQUEsNENBQUE7Ozs7O0FBRUksSUFBQSxxQkFBQSxHQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFvRCxJQUFBLHFCQUFBLEdBQUEsc0JBQUE7QUFBbUIsSUFBQSwyQkFBQTtBQUMzRSxJQUFBLHFCQUFBLEdBQUEsNENBQUE7Ozs7O0FBUlIsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBdUQsSUFBQSxxQkFBQSxHQUFBLEdBQUE7QUFBQyxJQUFBLDJCQUFBO0FBQ3hELElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsK0ZBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSwrRkFBQSxHQUFBLENBQUE7QUFJTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQ0FBQTs7OztBQVRpRSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGdCQUFBLFFBQUEsZUFBQSxPQUFBLE9BQUEsUUFBQSxZQUFBLFlBQUEsQ0FBQTtBQUNyRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSwyQkFBQSxRQUFBLGVBQUEsT0FBQSxPQUFBLFFBQUEsWUFBQSxZQUFBLElBQUEsSUFBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsUUFBQSwyQkFBQSxRQUFBLGVBQUEsT0FBQSxPQUFBLFFBQUEsWUFBQSxZQUFBLElBQUEsSUFBQSxFQUFBOzs7OztBQVFaLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQStELElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQU0sSUFBQSwyQkFBQTtBQUNyRSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsaUJBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSw0Q0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxvREFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFBdUIsSUFBQSxxQkFBQSxFQUFBOztBQUE0RSxJQUFBLDJCQUFBO0FBQ25HLElBQUEscUJBQUEsSUFBQSxvREFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSwwQkFBQSxFQUFBO0FBQStGLElBQUEscUJBQUEsSUFBQSxHQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNuRyxJQUFBLHFCQUFBLElBQUEsZ0RBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxvREFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBc0YsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQWtCLElBQUEsMkJBQUE7QUFDeEcsSUFBQSxxQkFBQSxJQUFBLG9EQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLGlCQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0RBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSw0Q0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxvREFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFBdUIsSUFBQSxxQkFBQSxFQUFBOztBQUE0RSxJQUFBLDJCQUFBO0FBQ25HLElBQUEscUJBQUEsSUFBQSxvREFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSwwQkFBQSxFQUFBO0FBQStGLElBQUEscUJBQUEsSUFBQSxHQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNuRyxJQUFBLHFCQUFBLElBQUEsZ0RBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxvREFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBMkYsSUFBQSxxQkFBQSxJQUFBLDBCQUFBO0FBQXdCLElBQUEsMkJBQUE7QUFDbkgsSUFBQSxxQkFBQSxJQUFBLG9EQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLGlCQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0RBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSw0Q0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdEQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxvREFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFBdUIsSUFBQSxxQkFBQSxFQUFBOztBQUE0RSxJQUFBLDJCQUFBO0FBQ25HLElBQUEscUJBQUEsSUFBQSxvREFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSwwQkFBQSxFQUFBO0FBS0EsSUFBQSxxQkFBQSxJQUFBLG9EQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnREFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0RBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLG9EQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFxRixJQUFBLHFCQUFBLElBQUEsa0JBQUE7QUFBZ0IsSUFBQSwyQkFBQTtBQUNyRyxJQUFBLHFCQUFBLElBQUEsb0RBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsaUJBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnREFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsNENBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRCQUFBOzs7O0FBckN3RCxJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLDBCQUFBLGVBQUEsSUFBQTtBQUNULElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsSUFBQSwwQkFBQSxJQUFBLElBQUEsa0RBQUEsR0FBQSxHQUFBO0FBQ3VCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxRQUFBLG9CQUFBLFlBQUEsOEJBQUEsSUFBQUEsSUFBQSxDQUFBO0FBUWQsSUFBQSx3QkFBQSxFQUFBO0FBQUEsSUFBQSwwQkFBQSxhQUFBLElBQUE7QUFDVCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLElBQUEsMEJBQUEsSUFBQSxJQUFBLGtEQUFBLEdBQUEsR0FBQTtBQUN1QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsUUFBQSxvQkFBQSxZQUFBLDhCQUFBLElBQUFBLElBQUEsQ0FBQTtBQVN2QixJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLGlDQUFBLElBQUEsMEJBQUEsSUFBQSxJQUFBLGtEQUFBLEdBQUEsR0FBQTtBQUduQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsUUFBQSxvQkFBQSxZQUFBLDhCQUFBLElBQUFBLElBQUEsQ0FBQSxFQUErQyxzQkFBQSxRQUFBLGlDQUFBOzs7OztBQXhFL0UsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSwrQkFBQSxHQUFBLHlFQUFBLElBQUEsSUFBQSxNQUFBLE1BQUEsdUNBQUE7QUFzQkEsSUFBQSx5QkFBQSxHQUFBLGlGQUFBLElBQUEsQ0FBQTtBQWFKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsaUZBQUEsSUFBQSxFQUFBO0FBZ0RKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7Ozs7QUFyRlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFdBQUE7QUFzQkEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLENBQUEsUUFBQSxlQUFBLFFBQUEsWUFBQSxXQUFBLElBQUEsSUFBQSxFQUFBO0FBY0osSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsYUFBQSxJQUFBLEVBQUE7Ozs7O0FBcERaLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQTZFLElBQUEscUJBQUEsR0FBQSxjQUFBO0FBQVksSUFBQSwyQkFBQTtBQUN6RixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsaUJBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsbUVBQUEsR0FBQSxDQUFBLEVBRUMsSUFBQSxtRUFBQSxHQUFBLENBQUE7QUFJTCxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLG1FQUFBLElBQUEsQ0FBQTtBQXlGSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7Ozs7QUFqR1ksSUFBQSx3QkFBQSxFQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEscUJBQUEsS0FBQSxFQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsMkJBQUEsS0FBQSxFQUFBO0FBSUosSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsY0FBQSxLQUFBLEVBQUE7Ozs7OztBQTRGSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUFnRixJQUFBLHFCQUFBLEdBQUEsMEJBQUE7QUFBd0IsSUFBQSwyQkFBQTtBQUN4RyxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsaUJBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxTQUFBLEVBQUE7QUFLSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSw2RUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxxQkFBQSxRQUFBLGVBQUEsY0FBQSxDQUFtRDtJQUFBLENBQUE7QUFMaEUsSUFBQSwyQkFBQTtBQVFBLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsUUFBQTtBQUNJLElBQUEscUJBQUEsRUFBQTs7QUFDQSxJQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQW1DLElBQUEscUJBQUEsRUFBQTs7QUFBcUYsSUFBQSwyQkFBQTtBQUM1SCxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsRUFBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUtJLElBQUEseUJBQUEsU0FBQSxTQUFBLDZFQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLHFCQUFBLFFBQUEsZUFBQSxXQUFBLENBQWdEO0lBQUEsQ0FBQTtBQUw3RCxJQUFBLDJCQUFBO0FBUUEsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxRQUFBO0FBQ0ksSUFBQSxxQkFBQSxFQUFBOztBQUNBLElBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBb0MsSUFBQSxxQkFBQSxFQUFBOztBQUFrRixJQUFBLDJCQUFBO0FBQzFILElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsS0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxFQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7Ozs7QUFuQ29CLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxPQUFBLGNBQUEsRUFBMEIsU0FBQSxPQUFBLGVBQUEsY0FBQTtBQU10QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLHNDQUFBLDBCQUFBLElBQUEsSUFBQSw0REFBQSxHQUFBLG9DQUFBO0FBQ21DLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLDREQUFBLENBQUE7QUFFcEMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSx1QkFBQSxPQUFBLG1CQUFBLE9BQUEsZUFBQSxjQUFBO0FBQ0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxzQ0FBQSwwQkFBQSxJQUFBLElBQUEsa0VBQUEsR0FBQSxnQ0FBQTtBQVNKLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxPQUFBLGNBQUEsRUFBMEIsU0FBQSxPQUFBLGVBQUEsV0FBQTtBQU10QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLHNDQUFBLDBCQUFBLElBQUEsSUFBQSx5REFBQSxHQUFBLG9DQUFBO0FBQ29DLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLHlEQUFBLENBQUE7QUFFckMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSx1QkFBQSxPQUFBLG1CQUFBLE9BQUEsZUFBQSxXQUFBO0FBQ0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxzQ0FBQSwwQkFBQSxJQUFBLElBQUEsK0RBQUEsR0FBQSxnQ0FBQTs7Ozs7QUFZWixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBO0FBQVEsSUFBQSxxQkFBQSxDQUFBOztBQUFnRixJQUFBLDJCQUFBO0FBQzVGLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7OztBQUZnQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsR0FBQSx1REFBQSxDQUFBOzs7OztBQU1BLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBO0FBQVEsSUFBQSxxQkFBQSxDQUFBOztBQUF3RSxJQUFBLDJCQUFBO0FBQ3BGLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7O0FBRFksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsK0NBQUEsQ0FBQTs7Ozs7QUFHUixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQTtBQUFRLElBQUEscUJBQUEsQ0FBQTs7QUFBb0YsSUFBQSwyQkFBQTtBQUNoRyxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7OztBQURZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLDJEQUFBLENBQUE7Ozs7O0FBTGhCLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDhGQUFBLEdBQUEsQ0FBQSxFQUVDLEdBQUEsOEZBQUEsR0FBQSxDQUFBO0FBSUwsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQVBRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLFlBQUEsV0FBQSxJQUFBLElBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLFlBQUEsU0FBQSxJQUFBLElBQUEsRUFBQTs7Ozs7QUFPQSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUE7QUFBUSxJQUFBLHFCQUFBLENBQUE7O0FBQXlFLElBQUEsMkJBQUE7QUFBVSxJQUFBLHFCQUFBLENBQUE7QUFDL0YsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQUZnQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsR0FBQSxnREFBQSxDQUFBO0FBQW1GLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSxRQUFBLDBCQUFBLGdDQUFBOzs7OztBQU92RixJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTs7OztBQUg2RCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLG1CQUFBLDhCQUFBLEdBQUFDLE1BQUEsUUFBQSxZQUFBLE1BQUEsQ0FBQTtBQUNyRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLHNEQUFBLFFBQUEsWUFBQSxRQUFBLHlDQUFBOzs7OztBQUpaLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQTtBQUFRLElBQUEscUJBQUEsQ0FBQTs7QUFBMEUsSUFBQSwyQkFBQTtBQUFVLElBQUEscUJBQUEsQ0FBQTtBQUM1RixJQUFBLHlCQUFBLEdBQUEsNEdBQUEsR0FBQSxDQUFBO0FBS0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQVBnQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsR0FBQSxpREFBQSxDQUFBO0FBQW9GLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSxRQUFBLDJCQUFBLG9DQUFBO0FBQzVGLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLDRCQUFBLFFBQUEsWUFBQSxTQUFBLElBQUEsRUFBQTs7Ozs7QUFSUixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsOEZBQUEsR0FBQSxDQUFBLEVBSUMsR0FBQSw4RkFBQSxHQUFBLENBQUE7QUFXRCxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBO0FBQVEsSUFBQSxxQkFBQSxDQUFBOztBQUE4RSxJQUFBLDJCQUFBO0FBQVUsSUFBQSxxQkFBQSxDQUFBO0FBQ3BHLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFsQkksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFFBQUEsMkJBQUEsSUFBQSxJQUFBLEVBQUE7QUFLQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSw4QkFBQSxRQUFBLDJCQUFBLElBQUEsRUFBQTtBQVdZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLHFEQUFBLENBQUE7QUFBd0YsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxLQUFBLFFBQUEsMEJBQUEsNEJBQUE7Ozs7O0FBM0J4RyxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsZ0ZBQUEsR0FBQSxDQUFBLEVBU0MsR0FBQSxnRkFBQSxJQUFBLENBQUE7Ozs7QUFURCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSw4QkFBQSxJQUFBLElBQUEsRUFBQTtBQVVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLDRCQUFBLElBQUEsSUFBQSxFQUFBOzs7OztBQWhCUixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLGtFQUFBLEdBQUEsQ0FBQSxFQUlDLEdBQUEsa0VBQUEsR0FBQSxDQUFBO0FBZ0NMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7OztBQXJDUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxnQ0FBQSxJQUFBLENBQUE7Ozs7O0FBMkNBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE2QyxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUE7QUFDbkQsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7Ozs7O0FBTGtELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxJQUFBLFdBQUEsT0FBQSxnQkFBQTtBQUNqQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxRQUFBO0FBRWEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxVQUFBLENBQUEsT0FBQSxXQUFBLEVBQXVCLFFBQUEsSUFBQSxFQUFBLFFBQUEsT0FBQSxhQUFBOzs7Ozs7QUFJakQsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQVNJLElBQUEseUJBQUEsVUFBQSxTQUFBLDhFQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBVSwwQkFBQSxRQUFBLG9CQUFBLENBQXFCO0lBQUEsQ0FBQTtBQUcvQixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUF5QyxJQUFBLHFCQUFBLEdBQUEsT0FBQTtBQUFLLElBQUEsMkJBQUE7QUFBUSxJQUFBLHFCQUFBLEdBQUEsMEJBQUE7QUFDdEQsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE2QyxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUE7QUFDbkQsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7Ozs7O0FBZlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLElBQUEsV0FBQSxPQUFBLGdCQUFBLEVBQWlELG9CQUFBLEtBQUEsRUFBQSxxQkFBQSxLQUFBLEVBQUEsZUFBQSxPQUFBLFNBQUEsU0FBQSxFQUFBLEVBQUEsZUFBQSxPQUFBLFlBQUE7QUFVeEMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsUUFBQTtBQUdhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsVUFBQSxDQUFBLE9BQUEsV0FBQSxFQUF1QixRQUFBLElBQUEsRUFBQSxRQUFBLE9BQUEsYUFBQTs7O0FEdFNqRSxrQ0FvQmE7QUFwQmI7O0FBR0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUVBOzs7Ozs7Ozs7Ozs7Ozs7QUFTTSxJQUFPLDZCQUFQLE1BQU8sNEJBQTBCO01BNkN2QjtNQUNBO01BQ0E7TUE5Q0gsaUJBQWlCO01BQ2pCLGFBQWE7TUFFc0I7TUFFbkM7TUFDQTtNQUVUO01BRUEscUJBQXFCO01BQ3JCLDJCQUEyQjtNQUMzQjtNQUVBO01BQ0EscUJBQXFCO01BQ3JCLDJCQUEyQjtNQUUzQjtNQUNTLHdCQUF3Qyx1QkFBZTtNQUVoRSxjQUFjO01BQ2QseUJBQXlCO01BR3pCLDBDQUFvRCxDQUFBO01BQ3BELDZCQUFxQyxDQUFBO01BRXJDLG9DQUFpRCxvQkFBSSxJQUFHO01BRXhELHVCQUFvQyxvQkFBSSxJQUFHO01BRTNDLGdDQUFnQztNQUV4QixvQkFBb0IsSUFBSUwsU0FBTztNQUN2QyxlQUFlLEtBQUssa0JBQWtCLGFBQVk7TUFHbEQsUUFBUUM7TUFDUixZQUFZQztNQUNaLGdCQUFnQjtNQUNoQixXQUFXO01BRVgsWUFDWSxhQUNBLGFBQ0EsY0FBMEI7QUFGMUIsYUFBQSxjQUFBO0FBQ0EsYUFBQSxjQUFBO0FBQ0EsYUFBQSxlQUFBO01BQ1Q7TUFLSCxXQUFRO0FBQ0osYUFBSyw4Q0FBNkM7TUFDdEQ7TUFLQSxjQUFXO0FBQ1AsYUFBSyxrQkFBa0IsWUFBVztNQUN0QztNQU1BLGdCQUFnQixnQkFBd0I7QUFDcEMsYUFBSyxjQUFjO0FBQ25CLGFBQUsscUJBQXFCO0FBQzFCLGFBQUssMkJBQTJCO0FBQ2hDLGFBQUssWUFBWSxvQkFBb0IsZUFBZSxFQUFHLEVBQUUsVUFBVTtVQUMvRCxNQUFNLENBQUMsa0JBQWlCO0FBQ3BCLGlCQUFLLGNBQWMsY0FBYztBQUNqQyxpQkFBSyxrQ0FBaUM7QUFDdEMsaUJBQUsscUJBQXFCO1VBQzlCO1VBQ0EsT0FBTyxNQUFLO0FBQ1IsaUJBQUsscUJBQXFCO0FBQzFCLGlCQUFLLDJCQUEyQjtVQUNwQztTQUNIO01BQ0w7TUFTQSx1QkFBdUIsVUFBa0I7QUFDckMsYUFBSyxpQkFBaUI7QUFDdEIsYUFBSyxtQkFBa0I7QUFDdkIsYUFBSyxnQkFBZ0IsUUFBUTtNQUNqQztNQU1BLHFCQUFrQjtBQUNkLGFBQUssaUJBQWlCLEtBQUssTUFBTSxXQUFXLElBQUksS0FBSyx3QkFBd0I7TUFDakY7TUFRQSxnREFBNkM7QUFDekMsYUFBSywwQ0FBMEMsS0FBSyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssU0FBVTtBQUN2RixjQUFNLHlDQUF5QyxRQUFRLEtBQUssT0FBTyxDQUFDLFNBQVMsS0FBSyxTQUFVLElBQUksQ0FBQyxZQUFZLFFBQVEsS0FBTSxDQUFDO0FBQzVILGNBQU0sc0RBQXNELFFBQVEsS0FBSyxPQUFPLENBQUMsU0FBUyxLQUFLLFNBQVUsSUFBSSxDQUFDLFlBQVksUUFBUSw2QkFBNkIsRUFBRSxDQUFDO0FBQ2xLLGFBQUssb0NBQW9DLEtBQUssY0FBYyxLQUFLLG1DQUFtQyxtREFBbUQ7QUFDdkosYUFBSyx1QkFBdUIsS0FBSyxjQUFjLEtBQUssc0JBQXNCLHNDQUFzQztNQUNwSDtNQUtBLG9DQUFpQztBQUM3QixhQUFLLDZCQUE2QixLQUFLLFlBQWEsT0FBTyxDQUFDLFNBQWUsS0FBSywrQkFBK0IsSUFBSSxDQUFDO01BQ3hIO01BWUEsK0JBQStCLFlBQWdCO0FBRTNDLFlBQUksS0FBSyx3Q0FBd0MsU0FBUyxXQUFXLFNBQVUsR0FBRztBQUM5RSxpQkFBTzs7QUFHWCxZQUFJLFdBQVcsU0FBVSxLQUFLLENBQUMsWUFBWSxRQUFRLFNBQVMsS0FBSyxxQkFBcUIsSUFBSSxRQUFRLEtBQUssQ0FBQyxHQUFHO0FBQ3ZHLGlCQUFPOztBQUlYLFlBQUksQ0FBQyxLQUFLLHdCQUF3QjtBQUM5QixjQUFJLFdBQVcsU0FBVSxLQUFLLENBQUMsWUFBWSxRQUFRLDZCQUE2QixLQUFLLGtDQUFrQyxJQUFJLFFBQVEseUJBQXlCLENBQUMsR0FBRztBQUM1SixtQkFBTzs7O0FBS2YsZUFBTztNQUNYO01BRUEsSUFBSSxrQ0FBK0I7QUFDL0IsZUFBTyxLQUFLLDJCQUEyQjtNQUMzQztNQUVBLElBQUksMkJBQXdCO0FBQ3hCLGdCQUFRLEtBQUssZ0JBQWdCO1VBQ3pCLEtBQUssdUJBQWU7QUFDaEIsbUJBQU8sS0FBSyxNQUFNO1VBQ3RCLEtBQUssdUJBQWU7QUFDaEIsbUJBQU87O01BRW5CO01BRUEsSUFBSSw0QkFBeUI7QUFDekIsZ0JBQVEsS0FBSyxnQkFBZ0I7VUFDekIsS0FBSyx1QkFBZTtBQUNoQixtQkFBTyxLQUFLLFlBQWE7VUFDN0IsS0FBSyx1QkFBZTtBQUNoQixtQkFBTyxLQUFLOztNQUV4QjtNQUVBLElBQUksMkJBQXdCO0FBQ3hCLGdCQUFRLEtBQUssZ0JBQWdCO1VBQ3pCLEtBQUssdUJBQWU7QUFDaEIsbUJBQU8sS0FBSyxZQUFhO1VBQzdCLEtBQUssdUJBQWU7QUFDaEIsbUJBQU8sS0FBSyxNQUFNLFNBQVMsS0FBSzs7TUFFNUM7TUFVQSxJQUFJLDRCQUF5QjtBQUN6QixZQUFJLEtBQUssd0JBQXdCO0FBQzdCLGlCQUFPLEtBQUssbUJBQW1CLFVBQWEsS0FBSyxnQkFBZ0IsVUFBYSxLQUFLLFlBQVksU0FBUyxLQUFLLEtBQUssTUFBTSxTQUFTOztBQUVySSxlQUFPLEtBQUssZ0JBQWdCLFVBQWEsS0FBSyxZQUFZLFNBQVMsS0FBSyxLQUFLLE1BQU0sU0FBUztNQUNoRztNQU1BLHFCQUFxQixnQkFBOEI7QUFDL0MsYUFBSyxpQkFBaUI7TUFDMUI7TUFLQSxJQUFJLDJCQUF3QjtBQUN4QixZQUFJLEtBQUssd0JBQXdCO0FBQzdCLGlCQUFPLEtBQUssbUJBQW1CLFVBQWEsS0FBSyxnQkFBZ0IsVUFBYSxLQUFLLFlBQVksU0FBUyxLQUFLLFFBQVEsS0FBSyxjQUFjOztBQUU1SSxlQUFPLEtBQUssaUNBQWtDLEtBQUssZ0JBQWdCLFVBQWEsS0FBSyxZQUFZLFNBQVMsS0FBSyxRQUFRLEtBQUssY0FBYztNQUM5STtNQWFBLElBQUksbUJBQWdCO0FBQ2hCLFlBQUksS0FBSyx3QkFBd0I7QUFDN0IsaUJBQU8sS0FBSyxlQUFlLENBQUMsS0FBSyxrQkFBa0IsQ0FBQyxLQUFLLGVBQWUsQ0FBQyxLQUFLLGtCQUFrQixDQUFDLEtBQUs7O0FBRTFHLGVBQU8sQ0FBQyxLQUFLLGVBQWUsS0FBSyxZQUFZLFdBQVcsS0FBSyxDQUFDLEtBQUssa0JBQWtCLENBQUMsS0FBSyw2QkFBNkIsS0FBSztNQUNqSTtNQUtBLFFBQUs7QUFDRCxhQUFLLFlBQVksUUFBUSxRQUFRO01BQ3JDO01BS0Esc0JBQW1CO0FBQ2YsYUFBSyxrQkFBa0IsS0FBSyxFQUFFO0FBQzlCLGFBQUssWUFBVztNQUNwQjtNQUtBLGNBQVc7QUFDUCxZQUFJLEtBQUssa0JBQWtCO0FBQ3ZCOztBQUVKLFlBQUksS0FBSyx3QkFBd0I7QUFDN0IsZUFBSyxjQUFjO0FBQ25CLGVBQUssWUFBWSw4QkFBOEIsS0FBSyxVQUFVLEtBQUssZ0JBQWlCLEtBQUssY0FBZSxFQUFFLFVBQVU7WUFDaEgsTUFBTSxDQUFDLFFBQVEsS0FBSyxjQUFjLEdBQUc7WUFDckMsT0FBTyxDQUFDLFVBQVUsS0FBSyxZQUFZLEtBQUs7V0FDM0M7bUJBQ00sS0FBSyxhQUFhO0FBQ3pCLGVBQUsscUJBQW9CO0FBQ3pCLGVBQUssWUFBWSxZQUFZLEtBQUssVUFBVSxLQUFLLGFBQWEsS0FBSyxjQUFlLEVBQUUsVUFBVTtZQUMxRixNQUFNLENBQUMsUUFBUSxLQUFLLGNBQWMsR0FBRztZQUNyQyxPQUFPLENBQUMsVUFBVSxLQUFLLFlBQVksS0FBSztXQUMzQzs7TUFFVDtNQVFBLGVBQWUsV0FBaUI7QUFDNUIsYUFBSyxtQkFBa0I7QUFDdkIsYUFBSyxjQUFjO0FBQ25CLGFBQUsscUJBQW9CO0FBQ3pCLGNBQU0sV0FBbUIsUUFBUSxXQUFXLENBQUMsYUFBYSxTQUFTLFlBQVksQ0FBQSxDQUFFO0FBQ2pGLGNBQU0sMkNBQTJDLEtBQUsseUNBQXlDLFVBQVUsT0FBTztBQUNoSCxjQUFNLHdEQUF3RCxLQUFLLHlDQUF5QyxVQUFVLDJCQUEyQjtBQUNqSixhQUFLLGdDQUFnQyx5Q0FBeUMsU0FBUyxLQUFLLHNEQUFzRCxTQUFTO0FBQzNKLGFBQUssb0NBQW9DLEtBQUssY0FBYyxLQUFLLG1DQUFtQyxxREFBcUQ7QUFDekosYUFBSyx1QkFBdUIsS0FBSyxjQUFjLEtBQUssc0JBQXNCLHdDQUF3QztBQUNsSCxhQUFLLGtDQUFpQztNQUMxQztNQVFRLHlDQUF5QyxPQUFlLFlBQWlEO0FBQzdHLGNBQU0sZ0JBQWdCLG9CQUFJLElBQUc7QUFDN0IsY0FBTSxRQUFRLENBQUMsU0FBUTtBQUNuQixnQkFBTSxrQkFBa0IsS0FBSyxVQUFVO0FBQ3ZDLGNBQUksaUJBQWlCO0FBQ2pCLGdCQUFJLGNBQWMsSUFBSSxlQUFlLEdBQUc7QUFDcEMsNEJBQWMsSUFBSSxpQkFBaUIsY0FBYyxJQUFJLGVBQWUsSUFBSSxDQUFDO21CQUN0RTtBQUNILDRCQUFjLElBQUksaUJBQWlCLENBQUM7OztRQUdoRCxDQUFDO0FBQ0QsZUFBTyxDQUFDLEdBQUcsY0FBYyxLQUFJLENBQUUsRUFBRSxPQUFPLENBQUMsUUFBUSxjQUFjLElBQUksR0FBRyxJQUFJLENBQUM7TUFDL0U7TUFNQSxjQUFjLE9BQTJCO0FBQ3JDLGFBQUssWUFBWSxNQUFNLE1BQU0sSUFBSTtBQUNqQyxhQUFLLGNBQWM7QUFFbkIsbUJBQVcsTUFBSztBQUNaLGVBQUssYUFBYSxRQUFRLGlDQUFpQyxFQUFFLHVCQUF1QixLQUFLLDBCQUF5QixDQUFFO1FBQ3hILEdBQUcsR0FBRztNQUNWO01BUUEsWUFBWSxtQkFBb0M7QUFDNUMsY0FBTSxFQUFFLFVBQVUsT0FBTSxJQUFLLGtCQUFrQjtBQUMvQyxnQkFBUSxVQUFVO1VBQ2QsS0FBSztBQUNELGtCQUFNLEVBQUUscUJBQXFCLE9BQU0sSUFBSztBQUN4QyxpQkFBSyx3QkFBd0IscUJBQXFCLE1BQU07QUFDeEQ7VUFDSixLQUFLO0FBQ0Qsa0JBQU0sRUFBRSxTQUFRLElBQUs7QUFDckIsaUJBQUssbUNBQW1DLFFBQVE7QUFDaEQ7VUFDSjtBQUNJLGlCQUFLLGFBQWEsTUFBTSw2QkFBNkI7QUFDckQ7O0FBRVIsYUFBSyxjQUFjO01BQ3ZCO01BU1Esd0JBQXdCLHFCQUErQixRQUFnQjtBQUMzRSxjQUFNLDhCQUE4QjtBQUNwQyxjQUFNLGlCQUFpQjtBQUN2QixZQUFJLDRCQUE0QixTQUFTLEdBQUc7QUFDeEMsZUFBSyxhQUFhLE1BQU0sc0RBQXNELEVBQUUscUJBQXFCLDRCQUEyQixDQUFFO0FBQ2xJLGVBQUssb0NBQW9DLEtBQUssY0FBYyxLQUFLLG1DQUFtQywyQkFBMkI7O0FBRW5JLFlBQUksZUFBZSxTQUFTLEdBQUc7QUFDM0IsZUFBSyxhQUFhLE1BQU0seUNBQXlDLEVBQUUsUUFBUSxlQUFjLENBQUU7QUFDM0YsZUFBSyx1QkFBdUIsS0FBSyxjQUFjLEtBQUssc0JBQXNCLGNBQWM7O01BRWhHO01BUVEsbUNBQW1DLDZCQUFnRTtBQUN2RyxZQUFJLDRCQUE0QixTQUFTLEdBQUc7QUFDeEMsZUFBSyxnQ0FBZ0M7QUFDckMsZ0JBQU0sMkNBQTJDLDRCQUE0QixJQUFJLENBQUMsWUFBWSxRQUFRLEtBQUs7QUFDM0csZUFBSyx1QkFBdUIsS0FBSyxjQUFjLEtBQUssc0JBQXNCLHdDQUF3QztBQUNsSCxnQkFBTSx3REFBd0QsNEJBQTRCLElBQUksQ0FBQyxZQUFZLFFBQVEsTUFBTTtBQUN6SCxlQUFLLG9DQUFvQyxLQUFLLGNBQWMsS0FBSyxtQ0FBbUMscURBQXFEO0FBQ3pKLGVBQUssYUFBYSxNQUFNLHNEQUFzRDtZQUMxRSxVQUFVLDRCQUE0QixJQUFJLENBQUMsWUFBWSxHQUFHLFFBQVEsS0FBSyxJQUFJLFFBQVEsTUFBTSxFQUFFLEVBQUUsS0FBSyxHQUFHO1dBQ3hHOztNQUVUO01BTUEsMEJBQTBCLGtCQUF5QjtBQUMvQyxhQUFLLHlCQUF5QjtBQUM5QixhQUFLLGNBQWM7QUFDbkIsYUFBSyxpQkFBaUI7QUFDdEIsYUFBSyxtQkFBa0I7QUFDdkIsYUFBSyxjQUFjO0FBQ25CLGFBQUsscUJBQW9CO01BQzdCO01BS0EsSUFBSSxzQkFBbUI7QUFDbkIsY0FBTSxPQUFPLElBQUksS0FBSTtBQUNyQixjQUFNLFVBQVUsSUFBSSxLQUFLLEdBQUcsV0FBVyxRQUFRLE9BQU8saUJBQWlCO0FBQ3ZFLGdCQUFRLE9BQU8sR0FBRyxRQUFRLFNBQVMsSUFBSSxRQUFRLFFBQVE7QUFDdkQsYUFBSyxXQUFXLENBQUMsT0FBTztBQUN4QixlQUFPO01BQ1g7TUFFQSxJQUFJLG9DQUFpQztBQUNqQyxlQUFPLEtBQUssb0JBQW9CLFNBQVUsSUFBSSxDQUFDLFlBQVksUUFBUSxLQUFLLEVBQUUsT0FBTyxDQUFDLFVBQVUsVUFBVSxNQUFTO01BQ25IO01BRUEsSUFBSSxhQUFVO0FBQ1YsZUFBTyxRQUFRLEtBQUssZUFBZSxLQUFLLG9DQUFvQyxLQUFLLFlBQVksTUFBTTtNQUN2RztNQUVBLElBQUksaUNBQThCO0FBQzlCLGVBQU8sQ0FBQyxHQUFHLEtBQUssaUNBQWlDO01BQ3JEO01BRUEsSUFBSSxvQkFBaUI7QUFDakIsZUFBTyxDQUFDLEdBQUcsS0FBSyxvQkFBb0I7TUFDeEM7TUFRUSxjQUFjLEtBQWtCLE9BQWU7QUFDbkQsZUFBTyxvQkFBSSxJQUFJLENBQUMsR0FBRyxPQUFPLEdBQUcsSUFBSSxPQUFNLENBQUUsQ0FBQztNQUM5QztNQU9RLHVCQUFvQjtBQUN4QixhQUFLLHVCQUF1QixvQkFBSSxJQUFHO0FBQ25DLGFBQUssb0NBQW9DLG9CQUFJLElBQUc7QUFDaEQsYUFBSyxnQ0FBZ0M7QUFDckMsYUFBSyw4Q0FBNkM7TUFDdEQ7O3lCQXJjUyw2QkFBMEIsZ0NBQUEsV0FBQSxHQUFBLGdDQUFBLGtCQUFBLEdBQUEsZ0NBQUEsWUFBQSxDQUFBO01BQUE7aUVBQTFCLDZCQUEwQixXQUFBLENBQUEsQ0FBQSx5QkFBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLGlDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBOzs7Ozs7Ozs7QUNwQnZDLFVBQUEsNkJBQUEsR0FBQSxRQUFBLEdBQUEsQ0FBQTtBQUEwRSxVQUFBLHlCQUFBLFlBQUEsU0FBQSwrREFBQTtBQUFBLG1CQUFZLElBQUEsWUFBQTtVQUFhLENBQUE7QUFDL0YsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUFrRSxVQUFBLHFCQUFBLEdBQUEsc0JBQUE7QUFBbUIsVUFBQSwyQkFBQTtBQUNyRixVQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLFVBQUEscUJBQUEsRUFBQTtBQUFvQixVQUFBLDJCQUFBO0FBQzlCLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUFnRixVQUFBLHlCQUFBLFNBQUEsU0FBQSwrREFBQTtBQUFBLG1CQUFTLElBQUEsTUFBQTtVQUFPLENBQUE7QUFBRSxVQUFBLDJCQUFBO0FBQ3RHLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQStHLFVBQUEseUJBQUEsU0FBQSxTQUFBLDREQUFBO0FBQUEsbUJBQVMsSUFBQSwwQkFBMEIsSUFBSTtVQUFDLENBQUE7QUFDbkosVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQStHLFVBQUEseUJBQUEsU0FBQSxTQUFBLDREQUFBO0FBQUEsbUJBQVMsSUFBQSwwQkFBMEIsS0FBSztVQUFDLENBQUE7QUFDcEosVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLG9EQUFBLEdBQUEsQ0FBQSxFQUVDLElBQUEsb0RBQUEsR0FBQSxDQUFBO0FBSUwsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLG9EQUFBLEdBQUEsQ0FBQSxFQU1DLElBQUEsb0RBQUEsSUFBQSxDQUFBLEVBQUEsSUFBQSxvREFBQSxJQUFBLENBQUEsRUFBQSxJQUFBLG9EQUFBLElBQUEsRUFBQTtBQWdNTCxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsb0RBQUEsR0FBQSxDQUFBO0FBd0NBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQTBFLFVBQUEseUJBQUEsU0FBQSxTQUFBLCtEQUFBO0FBQUEsbUJBQVMsSUFBQSxNQUFBO1VBQU8sQ0FBQTtBQUN0RixVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsV0FBQSxFQUFBO0FBQWtDLFVBQUEscUJBQUEsSUFBQSxNQUFBO0FBQU0sVUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUEwQyxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFNLFVBQUEsMkJBQUE7QUFDNUYsVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxvREFBQSxJQUFBLENBQUEsRUFNQyxJQUFBLG9EQUFBLElBQUEsQ0FBQTtBQW9CTCxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQXpTa0IsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxnQkFBQSx5Q0FBQTtBQUNBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsZ0NBQUEsSUFBQSxTQUFBLEtBQUE7QUFPZSxVQUFBLHdCQUFBLEVBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsOEJBQUEsSUFBQUksTUFBQSxJQUFBLHdCQUFBLENBQUEsSUFBQSxzQkFBQSxDQUFBO0FBR0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxXQUFBLDhCQUFBLElBQUFBLE1BQUEsQ0FBQSxJQUFBLHdCQUFBLElBQUEsc0JBQUEsQ0FBQTtBQU1yQixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSx5QkFBQSxLQUFBLEVBQUE7QUFHQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLHlCQUFBLEtBQUEsRUFBQTtBQUlKLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxDQUFBLElBQUEseUJBQUEsS0FBQSxFQUFBO0FBT0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEseUJBQUEsS0FBQSxFQUFBO0FBcUNBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLGtCQUFBLElBQUEsY0FBQSxLQUFBLEVBQUE7QUF5R0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsNEJBQUEsS0FBQSxFQUFBO0FBbURBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLDRCQUFBLElBQUEsY0FBQSxLQUFBLEVBQUE7QUEwQ2lCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLEtBQUE7QUFFYixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxtQkFBQSxJQUFBLGVBQUEsaUJBQUEsS0FBQSxFQUFBO0FBT0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsbUJBQUEsSUFBQSxlQUFBLGlCQUFBLEtBQUEsRUFBQTs7Ozs7cUZEbFFDLDRCQUEwQixFQUFBLFdBQUEsNkJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFcEJ2QyxTQUFTLGFBQUFDLFlBQVcsZ0JBQUFDLGVBQWMsU0FBQUMsUUFBTyxVQUFBQyxlQUFjO0FBQ3ZELFNBQVMsWUFBQUMsaUJBQTZCO0FBS3RDLFNBQVMsVUFBQUMsZUFBYzs7O0FBTnZCLElBb0JhO0FBcEJiOztBQUdBO0FBQ0E7QUFDQTs7QUFlTSxJQUFPLDZCQUFQLE1BQU8sNEJBQTBCO01BYWY7TUFacEIsYUFBYTtNQUNiLGFBQWE7TUFFSjtNQUNBO01BQ0EsYUFBeUIsV0FBVztNQUVuQyxPQUE2QixJQUFJSixjQUFZO01BR3ZELFNBQVNJO01BRVQsWUFBb0IsY0FBc0I7QUFBdEIsYUFBQSxlQUFBO01BQXlCO01BTTdDLHNCQUFzQixPQUFpQjtBQUNuQyxjQUFNLGdCQUFlO0FBQ3JCLGNBQU0sV0FBd0IsS0FBSyxhQUFhLEtBQUssNEJBQTRCLEVBQUUsVUFBVSxNQUFNLE1BQU0sTUFBTSxVQUFVLFNBQVEsQ0FBRTtBQUNuSSxpQkFBUyxrQkFBa0IsV0FBVyxLQUFLO0FBQzNDLGlCQUFTLGtCQUFrQixRQUFRLEtBQUs7QUFFeEMsaUJBQVMsT0FBTyxLQUNaLENBQUMsVUFBa0IsS0FBSyxLQUFLLEtBQUssS0FBSyxHQUN2QyxNQUFLO1FBQUUsQ0FBQztNQUVoQjs7eUJBN0JTLDZCQUEwQixnQ0FBQSxZQUFBLENBQUE7TUFBQTtpRUFBMUIsNkJBQTBCLFdBQUEsQ0FBQSxDQUFBLHlCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLE9BQUEsU0FBQSxZQUFBLGFBQUEsR0FBQSxTQUFBLEVBQUEsTUFBQSxPQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFdBQUEsV0FBQSxRQUFBLFNBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLG9DQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FBVC9CLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLGNBQUEsQ0FBQTtBQUtJLFVBQUEseUJBQUEsV0FBQSxTQUFBLGtFQUFBLFFBQUE7QUFBQSxtQkFBVyxJQUFBLHNCQUFBLE1BQUE7VUFBNkIsQ0FBQTtBQUMzQyxVQUFBLDJCQUFBO0FBQ0wsVUFBQSxxQkFBQSxHQUFBLFFBQUE7OztBQU5RLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsV0FBQSxJQUFBLFdBQUEsT0FBQSxFQUE4QixXQUFBLElBQUEsVUFBQSxFQUFBLFFBQUEsSUFBQSxNQUFBLEVBQUEsU0FBQSx5Q0FBQTs7Ozs7cUZBUTdCLDRCQUEwQixFQUFBLFdBQUEsNkJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FDcEJ2QyxTQUFTLGFBQUFDLFlBQVcsU0FBQUMsY0FBYTtBQUtqQyxTQUFTLG9CQUFvQjs7QUFMN0IsSUFtQmE7QUFuQmI7O0FBRUE7QUFDQTtBQUNBOzs7O0FBZU0sSUFBTyw2QkFBUCxNQUFPLDRCQUEwQjtNQVd2QjtNQUNBO01BWFosYUFBYTtNQUNiLGFBQWE7TUFFSjtNQUNBLGFBQXlCLFdBQVc7TUFHN0MsZUFBZTtNQUVmLFlBQ1ksYUFDQSxjQUEwQjtBQUQxQixhQUFBLGNBQUE7QUFDQSxhQUFBLGVBQUE7TUFDVDtNQU1ILFlBQVksT0FBaUI7QUFDekIsY0FBTSxnQkFBZTtBQUNyQixhQUFLLFlBQVksWUFBWSxLQUFLLEtBQUs7TUFDM0M7O3lCQXRCUyw2QkFBMEIsZ0NBQUEsV0FBQSxHQUFBLGdDQUFBLFlBQUEsQ0FBQTtNQUFBO2lFQUExQiw2QkFBMEIsV0FBQSxDQUFBLENBQUEseUJBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxPQUFBLFNBQUEsWUFBQSxhQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFdBQUEsV0FBQSxRQUFBLFNBQUEsU0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLG9DQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FBVC9CLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLGNBQUEsQ0FBQTtBQUtJLFVBQUEseUJBQUEsV0FBQSxTQUFBLGtFQUFBLFFBQUE7QUFBQSxtQkFBVyxJQUFBLFlBQUEsTUFBQTtVQUFtQixDQUFBO0FBQ2pDLFVBQUEsMkJBQUE7QUFDTCxVQUFBLHFCQUFBLEdBQUEsUUFBQTs7O0FBTlEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxXQUFBLElBQUEsV0FBQSxPQUFBLEVBQThCLFdBQUEsSUFBQSxVQUFBLEVBQUEsUUFBQSxJQUFBLFlBQUEsRUFBQSxTQUFBLHlDQUFBOzs7OztxRkFRN0IsNEJBQTBCLEVBQUEsV0FBQSw2QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUNuQnZDLFNBQVMsYUFBQUMsYUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFrQixVQUFBQyxlQUFjO0FBRWxFLFNBQVMsV0FBQUMsZ0JBQWU7QUFLeEIsU0FBUyxjQUFBQyxtQkFBa0I7Ozs7OztBQU1mLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxVQUFBLENBQUE7QUFNSSxJQUFBLDBCQUFBLFVBQUEsU0FBQSw0RUFBQTtBQUFBLE1BQUEsNkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQTtBQUFBLGFBQVUsMkJBQUEsT0FBQSxXQUFBLENBQVk7SUFBQSxDQUFBO0FBR3RCLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLFlBQUE7Ozs7QUFUUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGNBQUEsT0FBQSxVQUFBLEVBQXlCLGVBQUEsT0FBQSxLQUFBLGFBQUEsRUFBQSxFQUFBLGVBQUEsT0FBQSxZQUFBO0FBT2hCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxPQUFBLFVBQUE7OztBQXRCekIsSUEyQmE7QUEzQmI7O0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7OztBQXFCTSxJQUFPLDRCQUFQLE1BQU8sMkJBQXlCO01BaUJ0QjtNQUNBO01BakJaLGFBQWE7TUFDYixhQUFhO01BRUo7TUFDQTtNQUNBLGFBQXlCLFdBQVc7TUFFbkMsU0FBUyxJQUFJSixjQUFZO01BRTNCLG9CQUFvQixJQUFJRyxTQUFPO01BQ3ZDLGVBQWUsS0FBSyxrQkFBa0IsYUFBWTtNQUdsRCxhQUFhQztNQUViLFlBQ1ksY0FDQSxhQUF3QjtBQUR4QixhQUFBLGVBQUE7QUFDQSxhQUFBLGNBQUE7TUFDVDtNQUtILGNBQVc7QUFDUCxhQUFLLGtCQUFrQixZQUFXO01BQ3RDO01BTUEsYUFBYSxNQUFLO0FBQ2QsYUFBSyxZQUFZLE9BQU8sS0FBSyxVQUFVLEtBQUssS0FBSyxFQUFHLEVBQUUsVUFBVTtVQUM1RCxNQUFNLE1BQUs7QUFDUCxpQkFBSyxPQUFPLEtBQUssS0FBSyxJQUFJO0FBQzFCLGlCQUFLLGtCQUFrQixLQUFLLEVBQUU7VUFDbEM7VUFDQSxPQUFPLE1BQU0sS0FBSyxhQUFhLE1BQU0sa0NBQWtDO1NBQzFFO01BQ0w7O3lCQXhDUyw0QkFBeUIsaUNBQUEsWUFBQSxHQUFBLGlDQUFBLFdBQUEsQ0FBQTtNQUFBO2tFQUF6Qiw0QkFBeUIsV0FBQSxDQUFBLENBQUEsd0JBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxNQUFBLFFBQUEsVUFBQSxZQUFBLFlBQUEsYUFBQSxHQUFBLFNBQUEsRUFBQSxRQUFBLFNBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLG1CQUFBLElBQUEsa0JBQUEsbUNBQUEsMEJBQUEsNENBQUEsR0FBQSxjQUFBLGVBQUEsZUFBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsR0FBQSxNQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsbUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUFmOUIsVUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDBCQUFBLEdBQUEsa0RBQUEsR0FBQSxDQUFBOzs7QUFBQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsSUFBQSxTQUFBLHNCQUFBLElBQUEsRUFBQTs7Ozs7c0ZBZUssMkJBQXlCLEVBQUEsV0FBQSw0QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUMzQnRDLFNBQVMsYUFBQUMsbUJBQW9DO0FBRTdDLFNBQVMsZ0JBQWdCLGNBQWM7QUFDdkMsU0FBUyxXQUFBQyxnQkFBZTs7Ozs7Ozs7QUNnQlIsSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDJCQUFBLEVBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFEMEMsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxTQUFBLE9BQUEsS0FBQSxFQUFlLGNBQUEsT0FBQSxXQUFBLE1BQUE7Ozs7OztBQUdyRCxJQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsMkJBQUEsRUFBQTtBQUtJLElBQUEsMEJBQUEsUUFBQSxTQUFBLCtFQUFBLFFBQUE7QUFBQSxNQUFBLDZCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUE7QUFBQSxhQUFRLDJCQUFBLE9BQUEsY0FBQSxNQUFBLENBQXFCO0lBQUEsQ0FBQTtBQUNoQyxJQUFBLDRCQUFBO0FBQ0wsSUFBQSxzQkFBQSxHQUFBLGdCQUFBOzs7O0FBTFEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxZQUFBLE9BQUEsUUFBQSxFQUFxQixTQUFBLE9BQUEsS0FBQSxFQUFBLGNBQUEsT0FBQSxXQUFBLE1BQUE7Ozs7OztBQW9DakIsSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE0QyxJQUFBLDBCQUFBLFNBQUEsU0FBQSw2RUFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsY0FBQSw2QkFBQSxFQUFBO0FBQUEsYUFBUywyQkFBQSxZQUFBLE9BQWdCLElBQUksQ0FBQztJQUFBLENBQUE7QUFDdEUsSUFBQSxzQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUF3RixJQUFBLHNCQUFBLEdBQUEsTUFBQTtBQUFHLElBQUEsNEJBQUE7QUFDM0YsSUFBQSxzQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7Ozs7QUFGaUIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxRQUFBLFlBQUEscUJBQUEsSUFBQSxDQUFBOzs7OztBQUliLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLENBQUE7QUFDSixJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLHdCQUFBOzs7OztBQUhPLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsY0FBQSwrQkFBQSxHQUFBQyxNQUFBLE9BQUEsWUFBQSxPQUFBLE9BQUEsT0FBQSxTQUFBLFVBQUEsT0FBQSxPQUFBLE9BQUEsU0FBQSxPQUFBLElBQUEsT0FBQSxZQUFBLE9BQUEsT0FBQSxPQUFBLFNBQUEsSUFBQSxTQUFBLENBQUE7QUFDQyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLGtDQUFBLFdBQUEsNEJBQUE7Ozs7OztBQU1KLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEMsSUFBQSwwQkFBQSxTQUFBLFNBQUEsOEVBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLGNBQUEsNkJBQUEsRUFBQTtBQUFBLGFBQVMsMkJBQUEsWUFBQSxPQUFnQixNQUFNLENBQUM7SUFBQSxDQUFBO0FBQ3hFLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBbUcsSUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBSyxJQUFBLDRCQUFBO0FBQ3hHLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLHdCQUFBOzs7O0FBRmlCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxZQUFBLHFCQUFBLE1BQUEsQ0FBQTs7Ozs7QUFJYixJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsc0JBQUEsQ0FBQTtBQUFXLElBQUEsNEJBQUE7QUFDckIsSUFBQSxzQkFBQSxHQUFBLHdCQUFBOzs7O0FBRFUsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxTQUFBOzs7Ozs7QUFLTixJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTRDLElBQUEsMEJBQUEsU0FBQSxTQUFBLDhFQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxjQUFBLDZCQUFBLEVBQUE7QUFBQSxhQUFTLDJCQUFBLFlBQUEsT0FBZ0IsV0FBVyxDQUFDO0lBQUEsQ0FBQTtBQUM3RSxJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXdHLElBQUEsc0JBQUEsR0FBQSxjQUFBO0FBQVcsSUFBQSw0QkFBQTtBQUNuSCxJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsR0FBQSx3QkFBQTs7OztBQUZpQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsWUFBQSxxQkFBQSxXQUFBLENBQUE7Ozs7O0FBSWIsSUFBQSxzQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsQ0FBQTtBQUNKLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsd0JBQUE7Ozs7O0FBSE8sSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxjQUFBLCtCQUFBLEdBQUFBLE1BQUEsUUFBQSxZQUFBLE9BQUEsT0FBQSxRQUFBLFNBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxTQUFBLE9BQUEsSUFBQSxRQUFBLFlBQUEsT0FBQSxPQUFBLFFBQUEsU0FBQSxJQUFBLFVBQUEsRUFBQSxDQUFBO0FBQ0MsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSxrQ0FBQSxVQUFBLFdBQUEsNEJBQUE7Ozs7OztBQU1KLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEMsSUFBQSwwQkFBQSxTQUFBLFNBQUEsOEVBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLGNBQUEsNkJBQUEsRUFBQTtBQUFBLGFBQVMsMkJBQUEsWUFBQSxPQUFnQixZQUFZLENBQUM7SUFBQSxDQUFBO0FBQzlFLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBOEYsSUFBQSxzQkFBQSxHQUFBLFNBQUE7QUFBTSxJQUFBLDRCQUFBO0FBQ3BHLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLHdCQUFBOzs7O0FBRmlCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsUUFBQSxZQUFBLHFCQUFBLFlBQUEsQ0FBQTs7Ozs7QUFLVCxJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQStELElBQUEsc0JBQUEsQ0FBQTtBQUFpQixJQUFBLDRCQUFBO0FBQ3BGLElBQUEsc0JBQUEsR0FBQSw0QkFBQTs7OztBQURPLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsY0FBQSwrQkFBQSxHQUFBQyxNQUFBLGFBQUEsT0FBQSxPQUFBLFVBQUEsS0FBQSxDQUFBO0FBQTRELElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsS0FBQSxhQUFBLE9BQUEsT0FBQSxVQUFBLE1BQUEsRUFBQTs7Ozs7QUFHL0QsSUFBQSxzQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUFxQyxJQUFBLHNCQUFBLENBQUE7QUFBaUIsSUFBQSw0QkFBQTtBQUMxRCxJQUFBLHNCQUFBLEdBQUEsNEJBQUE7Ozs7QUFETyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFFBQUEsYUFBQSxhQUFBLE9BQUEsT0FBQSxVQUFBLFFBQUEsNEJBQUE7QUFBa0MsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxhQUFBLE9BQUEsT0FBQSxVQUFBLElBQUE7Ozs7O0FBR3JDLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNkUsSUFBQSxzQkFBQSxHQUFBLFVBQUE7QUFBUSxJQUFBLDRCQUFBO0FBQ3pGLElBQUEsc0JBQUEsR0FBQSw0QkFBQTs7Ozs7QUFSQSxJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDBCQUFBLEdBQUEscUVBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSxxRUFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLHFFQUFBLEdBQUEsQ0FBQTs7Ozs7QUFGRCxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxVQUFBLElBQUEsRUFBQTtBQUdBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxDQUFBLFFBQUEsV0FBQSxZQUFBLElBQUEsRUFBQTtBQUdBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxDQUFBLFFBQUEsV0FBQSxDQUFBLFlBQUEsSUFBQSxFQUFBOzs7OztBQU9BLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXdGLElBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQVMsSUFBQSw0QkFBQTtBQUNyRyxJQUFBLHNCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLHdCQUFBOzs7OztBQUVJLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwwQkFBQSxFQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLHdCQUFBOzs7OztBQUQ0QixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFlBQUEsU0FBQSxFQUFrQixlQUFBLFFBQUEsT0FBQTs7Ozs7O0FBT2xDLElBQUEsc0JBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSwwQkFBQSxFQUFBO0FBQTZELElBQUEsMEJBQUEsUUFBQSxTQUFBLDJHQUFBLFFBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUEsQ0FBQTtBQUFBLGFBQVEsMkJBQUEsUUFBQSxhQUFBLE1BQUEsQ0FBb0I7SUFBQSxDQUFBO0FBQUUsSUFBQSw0QkFBQTtBQUMvRixJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7Ozs7O0FBRDRCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsWUFBQSxRQUFBLFFBQUEsRUFBcUIsUUFBQSxTQUFBOzs7Ozs7QUFHN0MsSUFBQSxzQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLDBCQUFBLEVBQUE7QUFBMEUsSUFBQSwwQkFBQSxVQUFBLFNBQUEsNkdBQUEsUUFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw2QkFBQSxDQUFBO0FBQUEsYUFBVSwyQkFBQSxRQUFBLGFBQUEsTUFBQSxDQUFvQjtJQUFBLENBQUE7QUFBRSxJQUFBLDRCQUFBO0FBQzlHLElBQUEsc0JBQUEsR0FBQSxnQ0FBQTs7Ozs7QUFEeUMsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxZQUFBLFFBQUEsUUFBQSxFQUFxQixRQUFBLFNBQUE7Ozs7O0FBTGxFLElBQUEsc0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDBCQUFBLEdBQUEscUVBQUEsR0FBQSxDQUFBLEVBRUMsR0FBQSxxRUFBQSxHQUFBLENBQUE7QUFJTCxJQUFBLDRCQUFBO0FBQ0osSUFBQSxzQkFBQSxHQUFBLHdCQUFBOzs7OztBQVBRLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLFNBQUEsd0JBQUEsVUFBQSxTQUFBLE9BQUEsT0FBQSxVQUFBLE1BQUEsUUFBQSxRQUFBLFlBQUEsS0FBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxTQUFBLHNCQUFBLElBQUEsRUFBQTs7Ozs7QUFwRmhCLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxpQkFBQSxFQUFBO0FBWUksSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw4QkFBQSxHQUFBLHdCQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBLEdBQUEsc0RBQUEsR0FBQSxHQUFBLGVBQUEsRUFBQTtBQU1BLElBQUEsc0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUEsR0FBQSxzREFBQSxHQUFBLEdBQUEsZUFBQSxFQUFBO0FBS0osSUFBQSxzQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSx3QkFBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQSxJQUFBLHVEQUFBLEdBQUEsR0FBQSxlQUFBLEVBQUE7QUFNQSxJQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBLElBQUEsdURBQUEsR0FBQSxHQUFBLGVBQUEsRUFBQTtBQUdKLElBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsd0JBQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUEsSUFBQSx1REFBQSxHQUFBLEdBQUEsZUFBQSxFQUFBO0FBTUEsSUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQSxJQUFBLHVEQUFBLEdBQUEsR0FBQSxlQUFBLEVBQUE7QUFLSixJQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBO0FBQ0EsSUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw4QkFBQSxJQUFBLHdCQUFBLEVBQUE7QUFDSSxJQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBLElBQUEsdURBQUEsR0FBQSxHQUFBLGVBQUEsRUFBQTtBQU1BLElBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUEsSUFBQSx1REFBQSxHQUFBLEdBQUEsZUFBQSxFQUFBO0FBV0osSUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNBLElBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsOEJBQUEsSUFBQSx3QkFBQSxFQUFBO0FBQ0ksSUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwwQkFBQSxJQUFBLHVEQUFBLEdBQUEsR0FBQSxlQUFBLEVBQUE7QUFLQSxJQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBLElBQUEsdURBQUEsR0FBQSxHQUFBLGVBQUEsRUFBQTtBQUdKLElBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDQSxJQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDhCQUFBLElBQUEsd0JBQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUEsSUFBQSx1REFBQSxHQUFBLEdBQUEsZUFBQSxFQUFBO0FBVUosSUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQTtBQUNKLElBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUE7QUFDSixJQUFBLHNCQUFBLElBQUEsWUFBQTs7OztBQXpGUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFNBQUEsWUFBQSxLQUFBLEVBQXdCLFlBQUEsWUFBQSxRQUFBLEVBQUEsY0FBQSxZQUFBLFVBQUEsRUFBQSxnQkFBQSxZQUFBLFlBQUEsRUFBQSxnQkFBQSxZQUFBLFlBQUEsRUFBQSxhQUFBLFlBQUEsU0FBQSxFQUFBLFFBQUEsWUFBQSxJQUFBLEVBQUEsWUFBQSxZQUFBLFFBQUEsRUFBQSxjQUFBLFlBQUEsVUFBQTtBQVVRLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsWUFBQSxFQUFBLEVBQWUsU0FBQSxFQUFBLEVBQUEsWUFBQSxFQUFBO0FBYWIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxZQUFBLEdBQUEsRUFBZ0IsU0FBQSxHQUFBLEVBQUEsWUFBQSxHQUFBO0FBVzVCLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsWUFBQSxHQUFBLEVBQWdCLFNBQUEsR0FBQSxFQUFBLFlBQUEsR0FBQTtBQWFILElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsWUFBQSxHQUFBLEVBQWdCLFNBQUEsR0FBQTtBQW1CYixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFlBQUEsR0FBQSxFQUFnQixTQUFBLEdBQUE7QUFVeEIsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxZQUFBLEdBQUEsRUFBZ0IsU0FBQSxHQUFBLEVBQUEsWUFBQSxHQUFBOzs7QUQ1SDlELHNCQWVZLFlBU0M7QUF4QmI7O0FBQ0E7QUFJQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUEsS0FBQSxTQUFZQyxhQUFVO0FBQ2xCLE1BQUFBLFlBQUEsS0FBQSxJQUFBO0FBQ0EsTUFBQUEsWUFBQSxLQUFBLElBQUE7SUFDSixHQUhZLGVBQUEsYUFBVSxDQUFBLEVBQUE7QUFTaEIsSUFBTyxpQkFBUCxNQUFPLGdCQUFjO01Ba0JYO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUF4QkgsYUFBYTtNQUNiLGFBQWE7TUFFdEIsUUFBZ0IsQ0FBQTtNQUNoQixlQUEyQyxFQUFFLFlBQVksV0FBVyxJQUFHO01BQ3ZFLG9CQUFvQjtNQUNwQjtNQUVRLG9CQUFvQixJQUFJSCxTQUFPO01BQ3ZDLGVBQWUsS0FBSyxrQkFBa0IsYUFBWTtNQUVsRDtNQUVBO01BQ0EsVUFBVTtNQUVWLFlBQ1ksT0FDQSxRQUNBLHNCQUNBLGNBQ0EsY0FDQSxpQkFDQSxhQUNBLGdCQUE4QjtBQVA5QixhQUFBLFFBQUE7QUFDQSxhQUFBLFNBQUE7QUFDQSxhQUFBLHVCQUFBO0FBQ0EsYUFBQSxlQUFBO0FBQ0EsYUFBQSxlQUFBO0FBQ0EsYUFBQSxrQkFBQTtBQUNBLGFBQUEsY0FBQTtBQUNBLGFBQUEsaUJBQUE7QUFFUixhQUFLLGVBQWUsU0FBUSxFQUFHLEtBQUssQ0FBQyxTQUFjO0FBQy9DLGVBQUssY0FBYztBQUNuQixlQUFLLFVBQVUsS0FBSyxlQUFlLFFBQU87UUFDOUMsQ0FBQztNQUNMO01BS0EsV0FBUTtBQUNKLGFBQUssZUFBYztBQUNuQixhQUFLLFFBQU87TUFDaEI7TUFLQSxjQUFXO0FBQ1AsYUFBSyxrQkFBa0IsWUFBVztNQUN0QztNQUtBLFVBQU87QUFDSCxhQUFLLE1BQU0sT0FBTyxVQUFVLENBQUMsV0FBVTtBQUNuQyxlQUFLLFlBQVk7QUFDakIsZUFBSyxnQkFBZ0IsS0FBSyxPQUFPLFlBQVksQ0FBQyxFQUFFLFVBQVUsQ0FBQyxxQkFBb0I7QUFDM0UsaUJBQUssV0FBVyxpQkFBaUI7QUFDakMsa0JBQU0sY0FBYyxLQUFLLGFBQWEsZUFBZSxXQUFXLE1BQU0sS0FBSyxZQUFZLEtBQU07QUFDN0YsaUJBQUssWUFBWSxvQkFBb0IsT0FBTyxZQUFZLEdBQUcsV0FBVyxFQUFFLFVBQVUsQ0FBQyxrQkFBaUI7QUFDaEcsbUJBQUssUUFBUSxjQUFjO0FBQzNCLG1CQUFLLFlBQVk7WUFDckIsQ0FBQztVQUNMLENBQUM7UUFDTCxDQUFDO01BQ0w7TUFLQSxpQkFBYztBQUNWLGdCQUFRLEtBQUssTUFBTSxTQUFTLGNBQWMsSUFBSSxRQUFRLEdBQUc7VUFDckQsS0FBSyxXQUFXO0FBQ1osaUJBQUssYUFBYSxhQUFhLFdBQVc7QUFDMUM7VUFDSjtBQUNJLGlCQUFLLGFBQWEsYUFBYSxXQUFXO0FBQzFDOztNQUVaO01BTUEsaUJBQWlCSSxTQUFrQjtBQUMvQixhQUFLLGFBQWEsYUFBYUE7QUFDL0IsYUFBSyxPQUFPLFNBQVMsQ0FBQSxHQUFJLEVBQUUsWUFBWSxLQUFLLE9BQU8sYUFBYSxFQUFFLFFBQUFBLFFBQU0sR0FBSSxxQkFBcUIsU0FBUyxZQUFZLEtBQUksQ0FBRTtBQUM1SCxhQUFLLFFBQU87TUFDaEI7TUFPQSxhQUFhLE1BQVU7QUFDbkIsYUFBSyxXQUFXLElBQUk7TUFDeEI7TUFPQSxhQUFhLE1BQVU7QUFDbkIsYUFBSyxXQUFXLElBQUk7TUFDeEI7TUFPQSxjQUFjLE9BQWE7QUFDdkIsYUFBSyxRQUFRO01BQ2pCO01BT0Esd0JBQXdCLENBQUMsc0JBQTZCO0FBQ2xELGFBQUssb0JBQW9CO01BQzdCO01BT0Esd0JBQXdCO01BUXhCLHFCQUFxQixDQUFDLFNBQXNCO0FBQ3hDLGVBQU8sS0FBSztNQUNoQjtNQVFRLFdBQVcsTUFBVTtBQUN6QixjQUFNLFFBQVEsS0FBSyxNQUFNLFVBQVUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxLQUFLLEVBQUU7QUFDMUQsWUFBSSxVQUFVLElBQUk7QUFDZCxlQUFLLFFBQVEsQ0FBQyxHQUFHLEtBQUssT0FBTyxJQUFJO2VBQzlCO0FBQ0gsZUFBSyxRQUFRLE9BQU8sT0FBTyxDQUFBLEdBQUksS0FBSyxPQUFPLEVBQUUsQ0FBQyxLQUFLLEdBQUcsS0FBSSxDQUFFOztNQUVwRTtNQU9RLFdBQVcsTUFBVTtBQUN6QixhQUFLLFFBQVEsS0FBSyxNQUFNLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxLQUFLLEVBQUU7TUFDMUQ7O3lCQXBLUyxpQkFBYyxpQ0FBQSxrQkFBQSxHQUFBLGlDQUFBLFVBQUEsR0FBQSxpQ0FBQSxvQkFBQSxHQUFBLGlDQUFBLFlBQUEsR0FBQSxpQ0FBQSxZQUFBLEdBQUEsaUNBQUEsZUFBQSxHQUFBLGlDQUFBLFdBQUEsR0FBQSxpQ0FBQSxjQUFBLENBQUE7TUFBQTtrRUFBZCxpQkFBYyxXQUFBLENBQUEsQ0FBQSxXQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLGdCQUFBLDRCQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsb0JBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsUUFBQSxVQUFBLG9CQUFBLEdBQUEsQ0FBQSxRQUFBLFNBQUEsR0FBQSxXQUFBLFNBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLFFBQUEsUUFBQSxVQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGNBQUEsTUFBQSxHQUFBLENBQUEsY0FBQSxRQUFBLDhCQUFBLHNDQUFBLDhCQUFBLHNDQUFBLGdDQUFBLHNDQUFBLEdBQUEsYUFBQSxlQUFBLGdCQUFBLHdCQUFBLHlCQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsR0FBQSxTQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLFlBQUEsU0FBQSxjQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLFNBQUEsWUFBQSxjQUFBLGdCQUFBLGdCQUFBLGFBQUEsUUFBQSxZQUFBLFlBQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxHQUFBLFlBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxpQ0FBQSxFQUFBLEdBQUEsQ0FBQSwrQkFBQSxFQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsR0FBQSxZQUFBLFNBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFNBQUEsVUFBQSxHQUFBLENBQUEsUUFBQSxTQUFBLEdBQUEsWUFBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLFlBQUEsR0FBQSxZQUFBLE9BQUEsR0FBQSxDQUFBLFFBQUEsSUFBQSxHQUFBLFlBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLGlDQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEsbUJBQUEsR0FBQSwrQkFBQSxRQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxnQkFBQSw4QkFBQSxHQUFBLCtCQUFBLFFBQUEsVUFBQSxHQUFBLENBQUEsZ0JBQUEsbUNBQUEsR0FBQSwrQkFBQSxRQUFBLFVBQUEsR0FBQSxDQUFBLGdCQUFBLHlCQUFBLEdBQUEsK0JBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLGdCQUFBLGtDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsaUNBQUEsR0FBQSxVQUFBLE1BQUEsR0FBQSxDQUFBLGdCQUFBLDRCQUFBLEdBQUEsK0JBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsUUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsR0FBQSxZQUFBLFFBQUEsUUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHdCQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDeEIzQixVQUFBLDhCQUFBLEdBQUEsS0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxNQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsb0JBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsTUFBQTtBQUFNLFVBQUEsc0JBQUEsQ0FBQTtBQUF3QixVQUFBLDRCQUFBO0FBQU8sVUFBQSxzQkFBQSxFQUFBO0FBQXdCLFVBQUEsOEJBQUEsSUFBQSxRQUFBLENBQUE7QUFBZ0QsVUFBQSxzQkFBQSxJQUFBLE9BQUE7QUFBSyxVQUFBLDRCQUFBO0FBQ3RILFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxTQUFBLENBQUE7QUFBd0QsVUFBQSwwQkFBQSxTQUFBLFNBQUEsa0RBQUE7QUFBQSxtQkFBUyxJQUFBLGlCQUFBLElBQUEsV0FBQSxHQUFBO1VBQWdDLENBQUE7QUFBakcsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxRQUFBLENBQUE7QUFBbUIsVUFBQSxzQkFBQSxFQUFBOztBQUFzRCxVQUFBLDRCQUFBO0FBQzdFLFVBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsU0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUF3RCxVQUFBLDBCQUFBLFNBQUEsU0FBQSxrREFBQTtBQUFBLG1CQUFTLElBQUEsaUJBQUEsSUFBQSxXQUFBLEdBQUE7VUFBZ0MsQ0FBQTtBQUFqRyxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUFtQixVQUFBLHNCQUFBLEVBQUE7O0FBQXNELFVBQUEsNEJBQUE7QUFDN0UsVUFBQSxzQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDBCQUFBLElBQUEsd0NBQUEsR0FBQSxDQUFBLEVBRUMsSUFBQSx3Q0FBQSxHQUFBLENBQUE7QUFVRCxVQUFBLDhCQUFBLElBQUEsMEJBQUEsRUFBQTtBQUErRSxVQUFBLDBCQUFBLFFBQUEsU0FBQSxnRUFBQSxRQUFBO0FBQUEsbUJBQVEsSUFBQSxhQUFBLE1BQUE7VUFBb0IsQ0FBQTtBQUFFLFVBQUEsNEJBQUE7QUFDakgsVUFBQSxzQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDhCQUFBLElBQUEsa0JBQUEsRUFBQTtBQVVJLFVBQUEsMEJBQUEsc0JBQUEsU0FBQSxzRUFBQSxRQUFBO0FBQUEsbUJBQXNCLElBQUEsc0JBQUEsTUFBQTtVQUE2QixDQUFBO0FBRW5ELFVBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwwQkFBQSxJQUFBLHdDQUFBLElBQUEsSUFBQSxhQUFBO0FBNkZKLFVBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNKLFVBQUEsc0JBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxJQUFBOzs7QUF4SXNCLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsa0NBQUEsSUFBQSxJQUFBLFlBQUEsT0FBQSxPQUFBLElBQUEsU0FBQSxPQUFBLEtBQUE7QUFBK0IsVUFBQSx5QkFBQSxDQUFBO0FBQUEsVUFBQSxrQ0FBQSxJQUFBLElBQUEsbUJBQUEsR0FBQTtBQUliLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsV0FBQSxJQUFBLGFBQUEsVUFBQSxFQUFtQyxTQUFBLElBQUEsV0FBQSxHQUFBO0FBQ3BDLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsaUNBQUEsMkJBQUEsSUFBQSxJQUFBLDZCQUFBLENBQUE7QUFHQyxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLFdBQUEsSUFBQSxhQUFBLFVBQUEsRUFBbUMsU0FBQSxJQUFBLFdBQUEsR0FBQTtBQUNwQyxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLDJCQUFBLElBQUEsSUFBQSw2QkFBQSxDQUFBO0FBSzNCLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsS0FBQSxJQUFBLFlBQUEsT0FBQSxPQUFBLElBQUEsU0FBQSxvQkFBQSxJQUFBLFNBQUEsSUFBQSxNQUFBLFNBQUEsSUFBQSxLQUFBLEVBQUE7QUFHQSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDZCQUFBLEtBQUEsSUFBQSxZQUFBLE9BQUEsT0FBQSxJQUFBLFNBQUEsbUJBQUEsS0FBQSxFQUFBO0FBU3dCLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsWUFBQSxJQUFBLFFBQUEsRUFBcUIsY0FBQSxJQUFBLFdBQUEsTUFBQTtBQUlqRCxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLGFBQUEsSUFBQSxTQUFBLEVBQXVCLGVBQUEsSUFBQSxLQUFBLEVBQUEsZ0JBQUEsK0JBQUEsSUFBQUMsSUFBQSxDQUFBLEVBQUEsd0JBQUEsSUFBQSxrQkFBQSxFQUFBLHlCQUFBLElBQUEscUJBQUE7Ozs7O3NGRFZsQixnQkFBYyxFQUFBLFdBQUEsaUJBQUEsQ0FBQTtJQUFBLEdBQUE7OzsiLCJuYW1lcyI6WyJUZWFtSW1wb3J0U3RyYXRlZ3lUeXBlIiwiQ29tcG9uZW50IiwiRXZlbnRFbWl0dGVyIiwiSW5wdXQiLCJPdXRwdXQiLCJWaWV3Q2hpbGQiLCJjb21iaW5lTGF0ZXN0Iiwib2YiLCJjYXRjaEVycm9yIiwibWFwIiwic3dpdGNoTWFwIiwidGFwIiwiTmdiVHlwZWFoZWFkIiwiQ29tcG9uZW50IiwiSW5wdXQiLCJWaWV3Q2hpbGQiLCJTdWJqZWN0IiwiY2xvbmVEZWVwIiwiZGVib3VuY2VUaW1lIiwic3dpdGNoTWFwIiwiQ29tcG9uZW50IiwiRXZlbnRFbWl0dGVyIiwiSW5wdXQiLCJPdXRwdXQiLCJDb21wb25lbnQiLCJFdmVudEVtaXR0ZXIiLCJJbnB1dCIsIk91dHB1dCIsIlZpZXdDaGlsZCIsIlN1YmplY3QiLCJjb21iaW5lTGF0ZXN0IiwibWVyZ2UiLCJvZiIsImNhdGNoRXJyb3IiLCJmaWx0ZXIiLCJtYXAiLCJzd2l0Y2hNYXAiLCJ0YXAiLCJOZ2JUeXBlYWhlYWQiLCJDb21wb25lbnQiLCJFdmVudEVtaXR0ZXIiLCJPdXRwdXQiLCJmYVNwaW5uZXIiLCJUcmFuc2xhdGVTZXJ2aWNlIiwiQ29tcG9uZW50IiwiSW5wdXQiLCJWaWV3Q2hpbGQiLCJWaWV3RW5jYXBzdWxhdGlvbiIsIk5nRm9ybSIsIk5nYkFjdGl2ZU1vZGFsIiwiU3ViamVjdCIsImZhQmFuIiwiZmFTcGlubmVyIiwiX2MxIiwiX2MyIiwiX2MzIiwiX2M0IiwiQ29tcG9uZW50IiwiRXZlbnRFbWl0dGVyIiwiSW5wdXQiLCJPdXRwdXQiLCJOZ2JNb2RhbCIsImZhUGx1cyIsIkNvbXBvbmVudCIsIklucHV0IiwiQ29tcG9uZW50IiwiRXZlbnRFbWl0dGVyIiwiSW5wdXQiLCJPdXRwdXQiLCJTdWJqZWN0IiwiZmFUcmFzaEFsdCIsIkNvbXBvbmVudCIsIlN1YmplY3QiLCJfYzAiLCJfYzEiLCJGaWx0ZXJQcm9wIiwiZmlsdGVyIiwiX2MyIl19