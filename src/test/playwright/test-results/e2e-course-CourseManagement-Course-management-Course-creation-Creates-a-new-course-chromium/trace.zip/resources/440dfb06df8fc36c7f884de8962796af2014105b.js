import {
  ArtemisMarkdownService,
  init_markdown_service
} from "/chunk-7FP3FWGI.js";
import {
  ThemeService,
  init_theme_service
} from "/chunk-PVIIR7SL.js";
import {
  MAX_FILE_SIZE,
  QuizQuestion,
  QuizQuestionType,
  init_input_constants,
  init_quiz_question_model
} from "/chunk-HFO42WCR.js";
import {
  ARTEMIS_DEFAULT_COLOR,
  init_app_constants
} from "/chunk-FM4KGV2V.js";
import {
  escapeStringForUseInRegex,
  init_global_utils,
  onError
} from "/chunk-LW4WH7EZ.js";
import {
  AlertService,
  AlertType,
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  NegatedTypeCheckPipe,
  TranslateDirective,
  TypeCheckPipe,
  __esm,
  init_alert_service,
  init_artemis_translate_pipe,
  init_negated_type_check_pipe,
  init_shared_module,
  init_translate_directive,
  init_type_check_pipe
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/color-selector/color-selector.component.ts
import { Component, ElementRef, EventEmitter, Input, Output, Renderer2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
function ColorSelectorComponent_Conditional_0_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n            ");
    i0.\u0275\u0275elementStart(1, "div", 1);
    i0.\u0275\u0275listener("click", function ColorSelectorComponent_Conditional_0_For_4_Template_div_click_1_listener() {
      const restoredCtx = i0.\u0275\u0275restoreView(_r8);
      const tagColor_r2 = restoredCtx.$implicit;
      const ctx_r7 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r7.selectColorForTag(tagColor_r2));
    });
    i0.\u0275\u0275text(2, "\n                ");
    i0.\u0275\u0275element(3, "div", 2);
    i0.\u0275\u0275text(4, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const tagColor_r2 = ctx.$implicit;
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("ngStyle", i0.\u0275\u0275pureFunction1(1, _c0, tagColor_r2));
  }
}
function ColorSelectorComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "div", 0);
    i0.\u0275\u0275text(2, "\n        ");
    i0.\u0275\u0275repeaterCreate(3, ColorSelectorComponent_Conditional_0_For_4_Template, 6, 3, null, null, i0.\u0275\u0275repeaterTrackByIdentity);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275styleProp("top", ctx_r0.colorSelectorPosition.top, "px")("left", ctx_r0.colorSelectorPosition.left, "px")("height", ctx_r0.height, "px");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275repeater(ctx_r0.tagColors);
  }
}
var _c0, DEFAULT_COLORS, ColorSelectorComponent;
var init_color_selector_component = __esm({
  "src/main/webapp/app/shared/color-selector/color-selector.component.ts"() {
    init_app_constants();
    _c0 = (a0) => ({ backgroundColor: a0 });
    DEFAULT_COLORS = [
      ARTEMIS_DEFAULT_COLOR,
      "#1b97ca",
      "#0d3cc2",
      "#009999",
      "#0ab84f",
      "#94a11c",
      "#9dca53",
      "#ffd014",
      "#c6aa1c",
      "#ffa500",
      "#ffb2b2",
      "#ca94bd",
      "#a95292",
      "#691b0b",
      "#ad5658",
      "#ff1a35"
    ];
    ColorSelectorComponent = class _ColorSelectorComponent {
      elementRef;
      renderer;
      colorSelectorPosition;
      showColorSelector = false;
      height = 220;
      tagColors = DEFAULT_COLORS;
      selectedColor = new EventEmitter();
      constructor(elementRef, renderer) {
        this.elementRef = elementRef;
        this.renderer = renderer;
      }
      ngOnInit() {
        this.colorSelectorPosition = { left: 0, top: 0 };
        this.addEventListenerToCloseComponentOnClickOutside();
      }
      addEventListenerToCloseComponentOnClickOutside() {
        this.renderer.listen("document", "click", (event) => {
          if (this.showColorSelector) {
            const target = event.target;
            const isClickOutsideOfComponent = !this.elementRef.nativeElement.contains(target);
            if (isClickOutsideOfComponent) {
              this.showColorSelector = false;
            }
          }
        });
      }
      openColorSelector(event, marginTop, height) {
        event.stopPropagation();
        const parentElement = event.target.closest(".ng-trigger");
        this.colorSelectorPosition.left = parentElement ? parentElement.offsetLeft : 0;
        this.colorSelectorPosition.top = marginTop ?? 65;
        if (height !== void 0) {
          this.height = height;
        }
        this.showColorSelector = !this.showColorSelector;
      }
      selectColorForTag(selectedColor) {
        this.showColorSelector = false;
        this.selectedColor.emit(selectedColor);
      }
      cancelColorSelector() {
        this.showColorSelector = false;
      }
      static \u0275fac = function ColorSelectorComponent_Factory(t) {
        return new (t || _ColorSelectorComponent)(i0.\u0275\u0275directiveInject(i0.ElementRef), i0.\u0275\u0275directiveInject(i0.Renderer2));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _ColorSelectorComponent, selectors: [["jhi-color-selector"]], inputs: { tagColors: "tagColors" }, outputs: { selectedColor: "selectedColor" }, decls: 1, vars: 1, consts: [[1, "color-selector"], [1, "tag-color-selector", 3, "click"], [1, "color-element", 3, "ngStyle"]], template: function ColorSelectorComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275template(0, ColorSelectorComponent_Conditional_0_Template, 6, 6);
        }
        if (rf & 2) {
          i0.\u0275\u0275conditional(0, ctx.showColorSelector ? 0 : -1);
        }
      }, dependencies: [i1.NgStyle], styles: ["\n\n.color-selector[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  width: 220px;\n  background-color: var(--color-selector-background);\n  z-index: 1000;\n  display: flex;\n  flex-wrap: wrap;\n  padding: 4px;\n  border-radius: 3px;\n  border: 1px solid var(--color-selector-border);\n  box-shadow: 0 6px 12px var(--color-selector-box-shadow);\n}\n.color-selector[_ngcontent-%COMP%]   .tag-color-selector[_ngcontent-%COMP%] {\n  height: 50px;\n  width: 50px;\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: center;\n  padding: 4px;\n  flex: 1 0 25%;\n  border-radius: 3px;\n}\n.color-selector[_ngcontent-%COMP%]   .tag-color-selector[_ngcontent-%COMP%]:hover {\n  border: 1px solid var(--color-selector-border);\n  padding: 3px;\n}\n.color-selector[_ngcontent-%COMP%]   .tag-color-selector[_ngcontent-%COMP%]   .color-element[_ngcontent-%COMP%] {\n  width: 42px;\n  height: 42px;\n  cursor: pointer;\n  border-radius: 3px;\n  border: 1px solid var(--color-selector-border);\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvY29sb3Itc2VsZWN0b3IvY29sb3Itc2VsZWN0b3Iuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmNvbG9yLXNlbGVjdG9yIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgYm90dG9tOiAwO1xuICAgIGxlZnQ6IDA7XG5cbiAgICB3aWR0aDogMjIwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tY29sb3Itc2VsZWN0b3ItYmFja2dyb3VuZCk7XG4gICAgei1pbmRleDogMTAwMDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtd3JhcDogd3JhcDtcbiAgICBwYWRkaW5nOiA0cHg7XG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWNvbG9yLXNlbGVjdG9yLWJvcmRlcik7XG4gICAgYm94LXNoYWRvdzogMCA2cHggMTJweCB2YXIoLS1jb2xvci1zZWxlY3Rvci1ib3gtc2hhZG93KTtcblxuICAgIC50YWctY29sb3Itc2VsZWN0b3Ige1xuICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgIHdpZHRoOiA1MHB4O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LXdyYXA6IHdyYXA7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBwYWRkaW5nOiA0cHg7XG4gICAgICAgIGZsZXg6IDEgMCAyNSU7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcblxuICAgICAgICAmOmhvdmVyIHtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWNvbG9yLXNlbGVjdG9yLWJvcmRlcik7XG4gICAgICAgICAgICBwYWRkaW5nOiAzcHg7XG4gICAgICAgIH1cblxuICAgICAgICAuY29sb3ItZWxlbWVudCB7XG4gICAgICAgICAgICB3aWR0aDogNDJweDtcbiAgICAgICAgICAgIGhlaWdodDogNDJweDtcbiAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWNvbG9yLXNlbGVjdG9yLWJvcmRlcik7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFlBQUE7QUFDQSxVQUFBO0FBQ0EsUUFBQTtBQUVBLFNBQUE7QUFDQSxvQkFBQSxJQUFBO0FBQ0EsV0FBQTtBQUNBLFdBQUE7QUFDQSxhQUFBO0FBQ0EsV0FBQTtBQUNBLGlCQUFBO0FBQ0EsVUFBQSxJQUFBLE1BQUEsSUFBQTtBQUNBLGNBQUEsRUFBQSxJQUFBLEtBQUEsSUFBQTs7QUFFQSxDQWZKLGVBZUksQ0FBQTtBQUNJLFVBQUE7QUFDQSxTQUFBO0FBQ0EsV0FBQTtBQUNBLGFBQUE7QUFDQSxtQkFBQTtBQUNBLFdBQUE7QUFDQSxRQUFBLEVBQUEsRUFBQTtBQUNBLGlCQUFBOztBQUVBLENBekJSLGVBeUJRLENBVkosa0JBVUk7QUFDSSxVQUFBLElBQUEsTUFBQSxJQUFBO0FBQ0EsV0FBQTs7QUFHSixDQTlCUixlQThCUSxDQWZKLG1CQWVJLENBQUE7QUFDSSxTQUFBO0FBQ0EsVUFBQTtBQUNBLFVBQUE7QUFDQSxpQkFBQTtBQUNBLFVBQUEsSUFBQSxNQUFBLElBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(ColorSelectorComponent, { className: "ColorSelectorComponent" });
    })();
  }
});

// src/main/webapp/app/shared/color-selector/color-selector.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisColorSelectorModule;
var init_color_selector_module = __esm({
  "src/main/webapp/app/shared/color-selector/color-selector.module.ts"() {
    init_shared_module();
    init_color_selector_component();
    ArtemisColorSelectorModule = class _ArtemisColorSelectorModule {
      static \u0275fac = function ArtemisColorSelectorModule_Factory(t) {
        return new (t || _ArtemisColorSelectorModule)();
      };
      static \u0275mod = i02.\u0275\u0275defineNgModule({ type: _ArtemisColorSelectorModule });
      static \u0275inj = i02.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule] });
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/ace-editor/ace-editor.component.ts
import { Component as Component2, ElementRef as ElementRef3, EventEmitter as EventEmitter2, Input as Input2, NgZone, Output as Output2, forwardRef } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NG_VALUE_ACCESSOR } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/brace.js?v=1d0d9ead";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/brace_theme_monokai.js?v=1d0d9ead";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/brace_theme_chrome.js?v=1d0d9ead";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/brace_theme_dreamweaver.js?v=1d0d9ead";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/brace_theme_dracula.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var MAX_TAB_SIZE, AceEditorComponent;
var init_ace_editor_component = __esm({
  "src/main/webapp/app/shared/markdown-editor/ace-editor/ace-editor.component.ts"() {
    init_theme_service();
    init_theme_service();
    MAX_TAB_SIZE = 8;
    AceEditorComponent = class _AceEditorComponent {
      elementRef;
      zone;
      themeService;
      textChanged = new EventEmitter2();
      textChange = new EventEmitter2();
      style = {};
      set tabSize(value) {
        if (value > 0 && value <= MAX_TAB_SIZE) {
          this._editor.session.setTabSize(value);
        }
      }
      oldText;
      timeoutSaving;
      _options = {};
      _readOnly = false;
      _theme = "dreamweaver";
      _mode = "java";
      _autoUpdateContent = true;
      _editor;
      _durationBeforeCallback = 0;
      _text = "";
      themeSubscription;
      constructor(elementRef, zone, themeService) {
        this.elementRef = elementRef;
        this.zone = zone;
        this.themeService = themeService;
        const el = elementRef.nativeElement;
        this.zone.runOutsideAngular(() => {
          this._editor = ace["edit"](el);
        });
        this._editor.$blockScrolling = Infinity;
      }
      ngOnInit() {
        this.init();
        this.initEvents();
      }
      ngOnDestroy() {
        this._editor.destroy();
        this.themeSubscription?.unsubscribe();
      }
      init() {
        this.setOptions(this._options || {});
        this.setMode(this._mode);
        this.setReadOnly(this._readOnly);
      }
      initEvents() {
        this._editor.on("change", () => this.updateText());
        this._editor.on("paste", () => this.updateText());
        this.themeSubscription = this.themeService.getCurrentThemeObservable().subscribe(() => this.setThemeFromMode());
      }
      updateText() {
        const newVal = this._editor.getValue();
        if (newVal === this.oldText) {
          return;
        }
        if (!this._durationBeforeCallback) {
          this._text = newVal;
          this.zone.run(() => {
            this.textChange.emit(newVal);
            this.textChanged.emit(newVal);
          });
          this._onChange(newVal);
        } else {
          if (this.timeoutSaving) {
            clearTimeout(this.timeoutSaving);
          }
          this.timeoutSaving = setTimeout(() => {
            this._text = newVal;
            this.zone.run(() => {
              this.textChange.emit(newVal);
              this.textChanged.emit(newVal);
            });
            this.timeoutSaving = null;
          }, this._durationBeforeCallback);
        }
        this.oldText = newVal;
      }
      set options(options) {
        this.setOptions(options);
      }
      setOptions(options) {
        this._options = options;
        this._editor.setOptions(options || {});
      }
      set readOnly(readOnly) {
        this.setReadOnly(readOnly);
      }
      setReadOnly(readOnly) {
        this._readOnly = readOnly;
        this._editor.setReadOnly(readOnly);
      }
      set mode(mode) {
        this.setMode(mode);
      }
      setMode(mode) {
        this._mode = mode;
        if (typeof this._mode === "object") {
          this._editor.getSession().setMode(this._mode);
        } else {
          this._editor.getSession().setMode(`ace/mode/${this._mode}`);
        }
        this.setThemeFromMode();
      }
      setThemeFromMode() {
        const currentApplicationTheme = this.themeService.getCurrentTheme();
        this._theme = this._mode.toLowerCase() === "markdown" ? currentApplicationTheme.markdownAceTheme : currentApplicationTheme.codeAceTheme;
        this._editor.setTheme(`ace/theme/${this._theme}`);
      }
      get value() {
        return this.text;
      }
      set value(value) {
        this.setText(value);
      }
      writeValue(value) {
        this.setText(value);
      }
      _onChange = (_) => {
      };
      registerOnChange(fn) {
        this._onChange = fn;
      }
      _onTouched = () => {
      };
      registerOnTouched(fn) {
        this._onTouched = fn;
      }
      get text() {
        return this._text;
      }
      set text(text) {
        this.setText(text);
      }
      setText(text) {
        if (text == void 0) {
          text = "";
        }
        if (this._text !== text && this._autoUpdateContent) {
          this._text = text;
          this._editor.setValue(text);
          this._onChange(text);
          this._editor.clearSelection();
        }
      }
      set autoUpdateContent(status) {
        this.setAutoUpdateContent(status);
      }
      setAutoUpdateContent(status) {
        this._autoUpdateContent = status;
      }
      set durationBeforeCallback(num) {
        this.setDurationBeforeCallback(num);
      }
      setDurationBeforeCallback(num) {
        this._durationBeforeCallback = num;
      }
      getEditor() {
        return this._editor;
      }
      static \u0275fac = function AceEditorComponent_Factory(t) {
        return new (t || _AceEditorComponent)(i03.\u0275\u0275directiveInject(i03.ElementRef), i03.\u0275\u0275directiveInject(i03.NgZone), i03.\u0275\u0275directiveInject(ThemeService));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _AceEditorComponent, selectors: [["jhi-ace-editor"]], inputs: { style: "style", tabSize: "tabSize", options: "options", readOnly: "readOnly", mode: "mode", value: "value", text: "text", autoUpdateContent: "autoUpdateContent", durationBeforeCallback: "durationBeforeCallback" }, outputs: { textChanged: "textChanged", textChange: "textChange" }, features: [i03.\u0275\u0275ProvidersFeature([
        {
          provide: NG_VALUE_ACCESSOR,
          useExisting: forwardRef(() => _AceEditorComponent),
          multi: true
        }
      ])], decls: 0, vars: 0, template: function AceEditorComponent_Template(rf, ctx) {
      }, styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiYWNlLWVkaXRvci5jb21wb25lbnQudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIjpob3N0IHsgZGlzcGxheTpibG9jazt3aWR0aDoxMDAlOyB9Il0sCiAgIm1hcHBpbmdzIjogIjtBQUFBO0FBQVEsV0FBQTtBQUFjLFNBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(AceEditorComponent, { className: "AceEditorComponent" });
    })();
  }
});

// src/main/webapp/app/shared/constants/file-extensions.constants.ts
var MARKDOWN_FILE_EXTENSIONS, FILE_EXTENSIONS;
var init_file_extensions_constants = __esm({
  "src/main/webapp/app/shared/constants/file-extensions.constants.ts"() {
    MARKDOWN_FILE_EXTENSIONS = ["png", "jpg", "jpeg", "gif", "svg", "pdf"];
    FILE_EXTENSIONS = [
      "png",
      "jpg",
      "jpeg",
      "gif",
      "svg",
      "pdf",
      "zip",
      "tar",
      "txt",
      "rtf",
      "md",
      "htm",
      "html",
      "json",
      "doc",
      "docx",
      "csv",
      "xls",
      "xlsx",
      "ppt",
      "pptx",
      "pages",
      "pages-tef",
      "numbers",
      "key",
      "odt",
      "ods",
      "odp",
      "odg",
      "odc",
      "odi",
      "odf"
    ];
  }
});

// src/main/webapp/app/shared/http/file-uploader.service.ts
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { lastValueFrom } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var FileUploaderService;
var init_file_uploader_service = __esm({
  "src/main/webapp/app/shared/http/file-uploader.service.ts"() {
    init_input_constants();
    init_file_extensions_constants();
    FileUploaderService = class _FileUploaderService {
      http;
      acceptedMarkdownFileExtensions = MARKDOWN_FILE_EXTENSIONS;
      constructor(http) {
        this.http = http;
      }
      uploadMarkdownFile(file, fileName, options) {
        const fileExtension = fileName ? fileName.split(".").pop().toLocaleLowerCase() : file.name.split(".").pop().toLocaleLowerCase();
        if (!this.acceptedMarkdownFileExtensions.includes(fileExtension)) {
          return Promise.reject(new Error("Unsupported file type! Only the following file extensions are allowed: " + this.acceptedMarkdownFileExtensions.map((extension) => `.${extension}`).join(", ")));
        }
        if (file.size > MAX_FILE_SIZE) {
          return Promise.reject(new Error("File is too big! Maximum allowed file size: " + MAX_FILE_SIZE / (1024 * 1024) + " MB."));
        }
        const keepFileName = !!options?.keepFileName;
        const formData = new FormData();
        formData.append("file", file, fileName);
        return lastValueFrom(this.http.post(`/api/markdown-file-upload?keepFileName=${keepFileName}`, formData));
      }
      static \u0275fac = function FileUploaderService_Factory(t) {
        return new (t || _FileUploaderService)(i04.\u0275\u0275inject(i12.HttpClient));
      };
      static \u0275prov = i04.\u0275\u0275defineInjectable({ token: _FileUploaderService, factory: _FileUploaderService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/command.ts
import __vite__cjsImport24_brace from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/brace.js?v=1d0d9ead"; const acequire = __vite__cjsImport24_brace["acequire"];
var RangeCtor, Command;
var init_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/command.ts"() {
    RangeCtor = acequire("ace/range").Range;
    Command = class {
      buttonIcon;
      buttonTranslationString;
      aceEditor;
      markdownWrapper;
      setEditor(aceEditor) {
        this.aceEditor = aceEditor;
      }
      setMarkdownWrapper(ref) {
        this.markdownWrapper = ref;
      }
      getSelectedText() {
        return this.aceEditor.getSelectedText();
      }
      getExtendedSelectedText() {
        const text = this.getText();
        const lines = text.split("\n");
        const range = this.getRange();
        this.aceEditor.selection.setRange(new RangeCtor(range.start.row, 0, range.end.row, lines[range.end.row].length));
        return lines.slice(range.start.row, range.end.row + 1);
      }
      getText() {
        return this.aceEditor.getValue();
      }
      insertText(text) {
        this.aceEditor.insert(text);
      }
      focus() {
        this.aceEditor.focus();
      }
      getRange() {
        return this.aceEditor.selection.getRange();
      }
      replace(range, text) {
        this.aceEditor.session.replace(range, text);
      }
      clearSelection() {
        this.aceEditor.clearSelection();
      }
      moveCursorTo(row, column) {
        this.aceEditor.moveCursorTo(row, column);
      }
      getCursorPosition() {
        return this.aceEditor.getCursorPosition();
      }
      getLine(row) {
        return this.aceEditor.getSession().getLine(row);
      }
      getCurrentLine() {
        const cursor = this.getCursorPosition();
        return this.getLine(cursor.row);
      }
      moveCursorToEndOfRow() {
        const cursor = this.getCursorPosition();
        const currentLine = this.aceEditor.getSession().getLine(cursor.row);
        this.clearSelection();
        this.moveCursorTo(cursor.row, currentLine.length);
      }
      addCompleter(completer) {
        this.aceEditor.completers = [...this.aceEditor.completers || [], completer];
      }
      deleteWhiteSpace(text) {
        return text.trim();
      }
      addRefinedText(selectedText, textToAdd) {
        if (selectedText.charAt(0) === " " && selectedText.charAt(selectedText.length - 1) === " ") {
          return this.insertText(" " + textToAdd + " ");
        } else if (selectedText.charAt(0) === " ") {
          return this.insertText(" " + textToAdd);
        } else if (selectedText.charAt(selectedText.length - 1) === " ") {
          return this.insertText(textToAdd + " ");
        } else {
          return this.insertText(textToAdd);
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/domainCommands/domainCommand.ts
var DomainCommand;
var init_domainCommand = __esm({
  "src/main/webapp/app/shared/markdown-editor/domainCommands/domainCommand.ts"() {
    init_command();
    init_global_utils();
    DomainCommand = class extends Command {
      displayCommandButton = true;
      getTagRegex(flags = "") {
        const escapedOpeningIdentifier = escapeStringForUseInRegex(this.getOpeningIdentifier()), escapedClosingIdentifier = escapeStringForUseInRegex(this.getClosingIdentifier());
        return new RegExp(`${escapedOpeningIdentifier}(.*)${escapedClosingIdentifier}`, flags);
      }
      isCursorWithinTag() {
        const { row, column } = this.aceEditor.getCursorPosition(), line = this.aceEditor.getSession().getLine(row), regex = this.getTagRegex("g");
        const indexes = [];
        let match = regex.exec(line);
        while (match != void 0) {
          indexes.push({ matchStart: match.index, matchEnd: match.index + match[0].length, innerTagContent: match[1] });
          match = regex.exec(line);
        }
        const matchOnCursor = indexes.find(({ matchStart, matchEnd }) => column > matchStart && column <= matchEnd);
        return matchOnCursor || null;
      }
      isTagInRow(row) {
        const line = this.aceEditor.getSession().getLine(row), regex = this.getTagRegex();
        if (!line) {
          return null;
        }
        const match = line.match(regex);
        if (!match) {
          return null;
        }
        return { matchStart: match.index, matchEnd: match.index + match[0].length, innerTagContent: match[1] };
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/domainCommands/domainTag.command.ts
var DomainTagCommand;
var init_domainTag_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/domainCommands/domainTag.command.ts"() {
    init_domainCommand();
    DomainTagCommand = class extends DomainCommand {
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/underline.command.ts
import { faUnderline } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var UnderlineCommand;
var init_underline_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/underline.command.ts"() {
    init_command();
    UnderlineCommand = class extends Command {
      buttonIcon = faUnderline;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.underline";
      execute() {
        const chosenText = this.getSelectedText();
        if (chosenText.includes("<ins>")) {
          const textToAdd = chosenText.slice(5, -6);
          this.insertText(textToAdd);
        } else {
          const textToAdd = `<ins>${chosenText}</ins>`;
          this.insertText(textToAdd);
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/colorPicker.command.ts
var ColorPickerCommand;
var init_colorPicker_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/colorPicker.command.ts"() {
    init_command();
    ColorPickerCommand = class extends Command {
      buttonIcon = "";
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.color";
      execute(color) {
        const selectedText = this.getSelectedText();
        if (selectedText.includes('class="green"') || selectedText.includes('class="white"')) {
          const textToAdd = selectedText.slice(20, -7);
          this.insertText(textToAdd);
        } else if (selectedText.includes('class="yellow"') || selectedText.includes('class="orange"')) {
          const textToAdd = selectedText.slice(21, -7);
          this.insertText(textToAdd);
        } else if (selectedText.includes('class="red"')) {
          const textToAdd = selectedText.slice(18, -7);
          this.insertText(textToAdd);
        } else if (selectedText.includes('class="blue"') || selectedText.includes('class="lila"')) {
          const textToAdd = selectedText.slice(19, -7);
          this.insertText(textToAdd);
        } else {
          this.insertHTMLForColorChange(selectedText, color);
        }
      }
      insertHTMLForColorChange(selectedText, color) {
        let textToAdd = "";
        switch (color) {
          case "#ca2024":
            textToAdd = `<span class="red">${selectedText}</span>`;
            this.insertText(textToAdd);
            break;
          case "#3ea119":
            textToAdd = `<span class="green">${selectedText}</span>`;
            this.insertText(textToAdd);
            break;
          case "#ffffff":
            textToAdd = `<span class="white">${selectedText}</span>`;
            this.insertText(textToAdd);
            break;
          case "#000000":
            textToAdd = `${selectedText}`;
            this.insertText(textToAdd);
            break;
          case "#fffa5c":
            textToAdd = `<span class="yellow">${selectedText}</span>`;
            this.insertText(textToAdd);
            break;
          case "#0d3cc2":
            textToAdd = `<span class="blue">${selectedText}</span>`;
            this.insertText(textToAdd);
            break;
          case "#b05db8":
            textToAdd = `<span class="lila">${selectedText}</span>`;
            this.insertText(textToAdd);
            break;
          case "#d86b1f":
            textToAdd = `<span class="orange">${selectedText}</span>`;
            this.insertText(textToAdd);
            break;
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/bold.command.ts
import { faBold } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var BoldCommand;
var init_bold_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/bold.command.ts"() {
    init_command();
    BoldCommand = class extends Command {
      buttonIcon = faBold;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.bold";
      execute() {
        const selectedText = this.getSelectedText();
        let textToAdd = "";
        if (selectedText.slice(0, 2) === "**" && selectedText.slice(selectedText.length - 2, selectedText.length) === "**") {
          textToAdd = selectedText.slice(2, -2);
          this.insertText(textToAdd);
        } else {
          const trimmedText = this.deleteWhiteSpace(selectedText);
          textToAdd = `**${trimmedText}**`;
          this.addRefinedText(selectedText, textToAdd);
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/attachmentCommand.ts
import { faImage } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var AttachmentCommand;
var init_attachmentCommand = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/attachmentCommand.ts"() {
    init_command();
    AttachmentCommand = class extends Command {
      buttonIcon = faImage;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.imageUpload";
      execute() {
        let selectedText = this.getSelectedText();
        if (selectedText.includes("![](http://)")) {
          const textToAdd = selectedText.slice(12);
          this.insertText(textToAdd);
        } else {
          const range = this.getRange();
          selectedText = `![](http://)`;
          this.replace(range, selectedText);
          this.focus();
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/reference.command.ts
import { faQuoteLeft } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var ReferenceCommand;
var init_reference_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/reference.command.ts"() {
    init_command();
    ReferenceCommand = class extends Command {
      buttonIcon = faQuoteLeft;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.quote";
      execute() {
        let selectedText = this.getSelectedText();
        if (selectedText.includes(">") && !selectedText.includes("Reference")) {
          const textToAdd = selectedText.slice(2);
          this.insertText(textToAdd);
        } else if (selectedText.includes(">") && selectedText.includes("Reference")) {
          const textToAdd = selectedText.slice(2, -9);
          this.insertText(textToAdd);
        } else {
          const range = this.getRange();
          const initText = "Reference";
          selectedText = `> ${selectedText || initText}`;
          this.replace(range, selectedText);
          this.focus();
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/domainCommands/domainMultiOptionCommand.ts
var DomainMultiOptionCommand;
var init_domainMultiOptionCommand = __esm({
  "src/main/webapp/app/shared/markdown-editor/domainCommands/domainMultiOptionCommand.ts"() {
    init_domainCommand();
    DomainMultiOptionCommand = class extends DomainCommand {
      values = [];
      setValues(values) {
        this.values = values;
      }
      getValues() {
        return this.values;
      }
    };
  }
});

// src/main/webapp/app/shared/util/fullscreen.util.ts
function isFullScreen() {
  const docElement = document;
  if (docElement.fullscreenElement !== void 0) {
    return docElement.fullscreenElement;
  } else if (docElement.webkitFullscreenElement !== void 0) {
    return docElement.webkitFullscreenElement;
  } else if (docElement.mozFullScreenElement !== void 0) {
    return docElement.mozFullScreenElement;
  } else if (docElement.msFullscreenElement !== void 0) {
    return docElement.msFullscreenElement;
  }
  return false;
}
function exitFullscreen() {
  const docElement = document;
  if (document.exitFullscreen) {
    document.exitFullscreen();
  } else if (docElement.mozCancelFullScreen) {
    docElement.mozCancelFullScreen();
  } else if (docElement.msRequestFullscreen) {
    docElement.msRequestFullscreen();
  } else if (docElement.webkitExitFullscreen) {
    docElement.webkitExitFullscreen();
  }
}
function enterFullscreen(element) {
  if (element.requestFullscreen) {
    element.requestFullscreen();
  } else if (element.mozRequestFullScreen) {
    element.mozRequestFullScreen();
  } else if (element.msRequestFullscreen) {
    element.msRequestFullscreen();
  } else if (element.webkitRequestFullscreen) {
    element.webkitRequestFullscreen();
  }
}
var init_fullscreen_util = __esm({
  "src/main/webapp/app/shared/util/fullscreen.util.ts"() {
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/fullscreen.command.ts
import { faCompress } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var FullscreenCommand;
var init_fullscreen_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/fullscreen.command.ts"() {
    init_command();
    init_fullscreen_util();
    FullscreenCommand = class extends Command {
      buttonIcon = faCompress;
      buttonTranslationString = "artemisApp.markdownEditor.commands.fullscreen";
      execute() {
        if (isFullScreen()) {
          exitFullscreen();
        } else {
          const element = this.markdownWrapper.nativeElement;
          enterFullscreen(element);
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/headingOne.command.ts
import { faHeading } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var HeadingOneCommand;
var init_headingOne_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/headingOne.command.ts"() {
    init_command();
    HeadingOneCommand = class extends Command {
      buttonIcon = faHeading;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.headingOne";
      execute() {
        let selectedText = this.getSelectedText();
        if (selectedText.includes("#") && !selectedText.includes("Heading 1")) {
          const textToAdd = selectedText.slice(2);
          this.insertText(textToAdd);
        } else if (selectedText.includes("#") && selectedText.includes("Heading 1")) {
          const textToAdd = selectedText.slice(2, -9);
          this.insertText(textToAdd);
        } else {
          const initText = "Heading 1";
          const range = this.getRange();
          selectedText = `# ${selectedText || initText}`;
          this.replace(range, selectedText);
          this.focus();
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/italic.command.ts
import { faItalic } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var ItalicCommand;
var init_italic_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/italic.command.ts"() {
    init_command();
    ItalicCommand = class extends Command {
      buttonIcon = faItalic;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.italic";
      execute() {
        const selectedText = this.getSelectedText();
        let textToAdd = "";
        if (selectedText.charAt(0) === "*" && selectedText.charAt(selectedText.length - 1) === "*") {
          textToAdd = selectedText.slice(1, -1);
          this.insertText(textToAdd);
        } else {
          const trimmedText = this.deleteWhiteSpace(selectedText);
          textToAdd = `*${trimmedText}*`;
          this.addRefinedText(selectedText, textToAdd);
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/orderedListCommand.ts
import { faListOl } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var OrderedListCommand;
var init_orderedListCommand = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/orderedListCommand.ts"() {
    init_command();
    OrderedListCommand = class extends Command {
      buttonIcon = faListOl;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.orderedList";
      execute() {
        const extendedText = this.getExtendedSelectedText();
        this.handleManipulation(extendedText);
      }
      handleManipulation(extendedText) {
        let manipulatedText = "";
        let position = 1;
        extendedText.forEach((line, index) => {
          if (line === "") {
            if (extendedText.length === 1) {
              manipulatedText = "1. ";
              return;
            }
          } else {
            manipulatedText += this.manipulateLine(line, position);
            position++;
          }
          if (index !== extendedText.length - 1) {
            manipulatedText += "\n";
          }
        });
        this.replace(this.getRange(), manipulatedText);
      }
      manipulateLine(line, position) {
        const index = line.indexOf(".");
        const whitespaces = line.search(/\S|$/);
        if (index !== -1) {
          const elements = [line.slice(whitespaces, index), line.slice(index + 1)];
          if (elements[0] !== "" && !isNaN(Number(elements[0]))) {
            return " ".repeat(whitespaces) + elements[1].substring(1);
          }
        }
        return " ".repeat(whitespaces) + `${position}. ${line.substring(whitespaces)}`;
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/headingTwo.command.ts
import { faHeading as faHeading2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var HeadingTwoCommand;
var init_headingTwo_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/headingTwo.command.ts"() {
    init_command();
    HeadingTwoCommand = class extends Command {
      buttonIcon = faHeading2;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.headingTwo";
      execute() {
        let selectedText = this.getSelectedText();
        if (selectedText.includes("##") && !selectedText.includes("Heading 2")) {
          const textToAdd = selectedText.slice(3);
          this.insertText(textToAdd);
        } else if (selectedText.includes("##") && selectedText.includes("Heading 2")) {
          const textToAdd = selectedText.slice(3, -9);
          this.insertText(textToAdd);
        } else {
          const initText = "Heading 2";
          const range = this.getRange();
          selectedText = `## ${selectedText || initText}`;
          this.replace(range, selectedText);
          this.focus();
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/link.command.ts
import { faLink } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var LinkCommand;
var init_link_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/link.command.ts"() {
    init_command();
    LinkCommand = class extends Command {
      buttonIcon = faLink;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.link";
      execute() {
        let selectedText = this.getSelectedText();
        if (selectedText.includes("[](http://)")) {
          const textToAdd = selectedText.slice(11);
          this.insertText(textToAdd);
        } else {
          const range = this.getRange();
          selectedText = `[](http://)`;
          this.replace(range, selectedText);
          this.focus();
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/code.command.ts
import { faCode } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var CodeCommand;
var init_code_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/code.command.ts"() {
    init_command();
    CodeCommand = class extends Command {
      buttonIcon = faCode;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.code";
      execute() {
        let selectedText = this.getSelectedText();
        if (selectedText.startsWith("`") && selectedText.endsWith("`")) {
          const textToAdd = selectedText.slice(1, -1);
          this.insertText(textToAdd);
        } else {
          const range = this.getRange();
          selectedText = "`" + selectedText + "`";
          this.replace(range, selectedText);
          this.focus();
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/unorderedListCommand.ts
import { faListUl } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var UnorderedListCommand;
var init_unorderedListCommand = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/unorderedListCommand.ts"() {
    init_command();
    UnorderedListCommand = class extends Command {
      buttonIcon = faListUl;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.unorderedList";
      execute() {
        const extendedText = this.getExtendedSelectedText();
        this.handleManipulation(extendedText);
      }
      handleManipulation(extendedText) {
        let manipulatedText = "";
        extendedText.forEach((line, index) => {
          if (line === "") {
            if (extendedText.length === 1) {
              manipulatedText = "- ";
              return;
            }
          } else {
            manipulatedText += this.manipulateLine(line);
          }
          if (index !== extendedText.length - 1) {
            manipulatedText += "\n";
          }
        });
        this.replace(this.getRange(), manipulatedText);
      }
      manipulateLine(line) {
        const index = line.indexOf("-");
        const whitespaces = line.search(/\S|$/);
        if (index !== -1) {
          const elements = [line.slice(whitespaces, index), line.slice(index + 1)];
          if (elements[0] === "" && elements[1].length >= 1 && elements[1].startsWith(" ")) {
            return " ".repeat(whitespaces) + elements[1].substring(1);
          }
        }
        return " ".repeat(whitespaces) + `- ${line.substring(whitespaces)}`;
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/headingThree.command.ts
import { faHeading as faHeading3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var HeadingThreeCommand;
var init_headingThree_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/headingThree.command.ts"() {
    init_command();
    HeadingThreeCommand = class extends Command {
      buttonIcon = faHeading3;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.headingThree";
      execute() {
        let selectedText = this.getSelectedText();
        if (selectedText.includes("###") && !selectedText.includes("Heading 3")) {
          const textToAdd = selectedText.slice(4);
          this.insertText(textToAdd);
        } else if (selectedText.includes("###") && selectedText.includes("Heading 3")) {
          const textToAdd = selectedText.slice(4, -9);
          this.insertText(textToAdd);
        } else {
          const initText = "Heading 3";
          const range = this.getRange();
          selectedText = `### ${selectedText || initText}`;
          this.replace(range, selectedText);
          this.focus();
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/codeblock.command.ts
import { faFileCode } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
var CodeBlockCommand;
var init_codeblock_command = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/codeblock.command.ts"() {
    init_command();
    CodeBlockCommand = class extends Command {
      buttonIcon = faFileCode;
      buttonTranslationString = "artemisApp.multipleChoiceQuestion.editor.codeBlock";
      execute() {
        let selectedText = this.getSelectedText();
        const range = this.getRange();
        const initText = "Source Code";
        selectedText = "```java\n" + (selectedText || initText) + "\n```";
        this.replace(range, selectedText);
        this.focus();
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/multiOptionCommand.ts
var MultiOptionCommand;
var init_multiOptionCommand = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/multiOptionCommand.ts"() {
    init_command();
    MultiOptionCommand = class extends Command {
      values = [];
      getValues() {
        return this.values;
      }
      setValues(values) {
        this.values = values;
      }
    };
  }
});

// src/main/webapp/app/entities/quiz/multiple-choice-question.model.ts
var MultipleChoiceQuestion;
var init_multiple_choice_question_model = __esm({
  "src/main/webapp/app/entities/quiz/multiple-choice-question.model.ts"() {
    init_quiz_question_model();
    MultipleChoiceQuestion = class extends QuizQuestion {
      answerOptions;
      hasCorrectOption;
      singleChoice;
      constructor() {
        super(QuizQuestionType.MULTIPLE_CHOICE);
      }
    };
  }
});

// src/main/webapp/app/entities/quiz/answer-option.model.ts
var AnswerOption;
var init_answer_option_model = __esm({
  "src/main/webapp/app/entities/quiz/answer-option.model.ts"() {
    AnswerOption = class {
      id;
      text;
      hint;
      explanation;
      isCorrect;
      question;
      invalid = false;
      constructor() {
        this.isCorrect = false;
        this.text = "";
      }
    };
  }
});

// src/main/webapp/app/exercises/quiz/shared/questions/multiple-choice-question/multiple-choice-visual-question.component.ts
import { Component as Component3, EventEmitter as EventEmitter3, Input as Input3, Output as Output3, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faCheck, faExclamationCircle, faExclamationTriangle, faPlus, faQuestionCircle, faTrash, faXmark } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { faCircle, faSquare } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function MultipleChoiceVisualQuestionComponent_For_32_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n        ");
    i05.\u0275\u0275elementStart(1, "div", 9);
    i05.\u0275\u0275text(2, "\n            ");
    i05.\u0275\u0275elementStart(3, "div", 10);
    i05.\u0275\u0275text(4, "\n                ");
    i05.\u0275\u0275elementStart(5, "div", 11);
    i05.\u0275\u0275listener("click", function MultipleChoiceVisualQuestionComponent_For_32_Template_div_click_5_listener() {
      const restoredCtx = i05.\u0275\u0275restoreView(_r7);
      const answerOption_r1 = restoredCtx.$implicit;
      const ctx_r6 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r6.toggleIsCorrect(answerOption_r1));
    });
    i05.\u0275\u0275text(6, "\n                    ");
    i05.\u0275\u0275element(7, "fa-icon", 7);
    i05.\u0275\u0275text(8, "\n                ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(9, "\n                ");
    i05.\u0275\u0275elementStart(10, "input", 4);
    i05.\u0275\u0275listener("ngModelChange", function MultipleChoiceVisualQuestionComponent_For_32_Template_input_ngModelChange_10_listener($event) {
      const restoredCtx = i05.\u0275\u0275restoreView(_r7);
      const answerOption_r1 = restoredCtx.$implicit;
      return i05.\u0275\u0275resetView(answerOption_r1.text = $event);
    })("input", function MultipleChoiceVisualQuestionComponent_For_32_Template_input_input_10_listener() {
      i05.\u0275\u0275restoreView(_r7);
      const ctx_r9 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r9.questionChanged.emit());
    });
    i05.\u0275\u0275pipe(11, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(12, "\n                ");
    i05.\u0275\u0275elementStart(13, "div", 12);
    i05.\u0275\u0275listener("click", function MultipleChoiceVisualQuestionComponent_For_32_Template_div_click_13_listener() {
      const restoredCtx = i05.\u0275\u0275restoreView(_r7);
      const i_r2 = restoredCtx.$index;
      const ctx_r10 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r10.deleteAnswer(i_r2));
    });
    i05.\u0275\u0275text(14, "\n                    ");
    i05.\u0275\u0275element(15, "fa-icon", 7);
    i05.\u0275\u0275text(16, "\n                ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(17, "\n            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(18, "\n            ");
    i05.\u0275\u0275elementStart(19, "div", 2);
    i05.\u0275\u0275text(20, "\n                ");
    i05.\u0275\u0275element(21, "fa-icon", 3);
    i05.\u0275\u0275pipe(22, "artemisTranslate");
    i05.\u0275\u0275text(23, "\n                ");
    i05.\u0275\u0275elementStart(24, "input", 4);
    i05.\u0275\u0275listener("ngModelChange", function MultipleChoiceVisualQuestionComponent_For_32_Template_input_ngModelChange_24_listener($event) {
      const restoredCtx = i05.\u0275\u0275restoreView(_r7);
      const answerOption_r1 = restoredCtx.$implicit;
      return i05.\u0275\u0275resetView(answerOption_r1.hint = $event);
    })("input", function MultipleChoiceVisualQuestionComponent_For_32_Template_input_input_24_listener() {
      i05.\u0275\u0275restoreView(_r7);
      const ctx_r12 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r12.questionChanged.emit());
    });
    i05.\u0275\u0275pipe(25, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(26, "\n            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(27, "\n            ");
    i05.\u0275\u0275elementStart(28, "div", 13);
    i05.\u0275\u0275text(29, "\n                ");
    i05.\u0275\u0275element(30, "fa-icon", 3);
    i05.\u0275\u0275pipe(31, "artemisTranslate");
    i05.\u0275\u0275text(32, "\n                ");
    i05.\u0275\u0275elementStart(33, "input", 4);
    i05.\u0275\u0275listener("ngModelChange", function MultipleChoiceVisualQuestionComponent_For_32_Template_input_ngModelChange_33_listener($event) {
      const restoredCtx = i05.\u0275\u0275restoreView(_r7);
      const answerOption_r1 = restoredCtx.$implicit;
      return i05.\u0275\u0275resetView(answerOption_r1.explanation = $event);
    })("input", function MultipleChoiceVisualQuestionComponent_For_32_Template_input_input_33_listener() {
      i05.\u0275\u0275restoreView(_r7);
      const ctx_r14 = i05.\u0275\u0275nextContext();
      return i05.\u0275\u0275resetView(ctx_r14.questionChanged.emit());
    });
    i05.\u0275\u0275pipe(34, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(35, "\n            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(36, "\n        ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(37, "\n    ");
  }
  if (rf & 2) {
    const answerOption_r1 = ctx.$implicit;
    const i_r2 = ctx.$index;
    const ctx_r0 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275propertyInterpolate1("id", "answer-option-", i_r2, "");
    i05.\u0275\u0275advance(4);
    i05.\u0275\u0275property("ngClass", answerOption_r1.isCorrect ? "visual-answer-correct-container" : "visual-answer-wrong-container");
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275property("icon", answerOption_r1.isCorrect ? ctx_r0.faCheck : ctx_r0.faXmark);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275propertyInterpolate("placeholder", i05.\u0275\u0275pipeBind1(11, 14, "artemisApp.multipleChoiceQuestion.visualEditor.textPlaceholder"));
    i05.\u0275\u0275property("ngModel", answerOption_r1.text);
    i05.\u0275\u0275advance(5);
    i05.\u0275\u0275property("icon", ctx_r0.faTrash);
    i05.\u0275\u0275advance(6);
    i05.\u0275\u0275propertyInterpolate("ngbTooltip", i05.\u0275\u0275pipeBind1(22, 16, "artemisApp.multipleChoiceQuestion.visualEditor.hintTooltip"));
    i05.\u0275\u0275property("icon", ctx_r0.faQuestionCircle);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275propertyInterpolate("placeholder", i05.\u0275\u0275pipeBind1(25, 18, "artemisApp.multipleChoiceQuestion.visualEditor.hintPlaceholder"));
    i05.\u0275\u0275property("ngModel", answerOption_r1.hint);
    i05.\u0275\u0275advance(6);
    i05.\u0275\u0275propertyInterpolate("ngbTooltip", i05.\u0275\u0275pipeBind1(31, 20, "artemisApp.multipleChoiceQuestion.visualEditor.explanationTooltip"));
    i05.\u0275\u0275property("icon", ctx_r0.faExclamationCircle);
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275propertyInterpolate("placeholder", i05.\u0275\u0275pipeBind1(34, 22, "artemisApp.multipleChoiceQuestion.visualEditor.explanationPlaceholder"));
    i05.\u0275\u0275property("ngModel", answerOption_r1.explanation);
  }
}
var MultipleChoiceVisualQuestionComponent;
var init_multiple_choice_visual_question_component = __esm({
  "src/main/webapp/app/exercises/quiz/shared/questions/multiple-choice-question/multiple-choice-visual-question.component.ts"() {
    init_multiple_choice_question_model();
    init_answer_option_model();
    init_translate_directive();
    init_artemis_translate_pipe();
    MultipleChoiceVisualQuestionComponent = class _MultipleChoiceVisualQuestionComponent {
      _question;
      set question(question) {
        this._question = question;
      }
      get question() {
        return this._question;
      }
      questionChanged = new EventEmitter3();
      faQuestionCircle = faQuestionCircle;
      faExclamationTriangle = faExclamationTriangle;
      faExclamationCircle = faExclamationCircle;
      faSquare = faSquare;
      faCheck = faCheck;
      faCircle = faCircle;
      faPlus = faPlus;
      faTrash = faTrash;
      faXmark = faXmark;
      constructor() {
      }
      parseQuestion() {
        let markdown = this.question.text ?? "";
        if (this.question.hint) {
          markdown += "\n	[hint] " + this.question.hint;
        }
        if (this.question.explanation) {
          markdown += "\n	[exp] " + this.question.explanation;
        }
        if (this.question.answerOptions && this.question.answerOptions.length > 0) {
          markdown += "\n";
          this.question.answerOptions.forEach((answerOption) => {
            markdown += "\n" + (answerOption.isCorrect ? "[correct] " : "[wrong] ") + answerOption.text;
            if (answerOption.hint) {
              markdown += "\n	[hint] " + answerOption.hint;
            }
            if (answerOption.explanation) {
              markdown += "\n	[exp] " + answerOption.explanation;
            }
          });
        }
        return markdown;
      }
      deleteAnswer(index) {
        this.question.answerOptions?.splice(index, 1);
        this.questionChanged.emit();
      }
      toggleIsCorrect(answerOption) {
        if (this.correctToggleDisabled() && !answerOption.isCorrect) {
          return;
        }
        answerOption.isCorrect = !answerOption.isCorrect;
        this.questionChanged.emit();
      }
      correctToggleDisabled() {
        return this.question.singleChoice && this.question.answerOptions?.some((option) => option.isCorrect);
      }
      addNewAnswer() {
        if (this.question.answerOptions === void 0) {
          this.question.answerOptions = [];
        }
        this.question.answerOptions?.push(new AnswerOption());
        this.questionChanged.emit();
      }
      static \u0275fac = function MultipleChoiceVisualQuestionComponent_Factory(t) {
        return new (t || _MultipleChoiceVisualQuestionComponent)();
      };
      static \u0275cmp = i05.\u0275\u0275defineComponent({ type: _MultipleChoiceVisualQuestionComponent, selectors: [["jhi-multiple-choice-visual-question"]], inputs: { question: "question" }, outputs: { questionChanged: "questionChanged" }, decls: 41, vars: 27, consts: [[1, "markdown-preview", "visual-mode"], ["id", "mc-question", "rows", "5", 1, "form-control", "form-group-narrow", 3, "ngModel", "placeholder", "ngModelChange", "input"], [1, "form-group-narrow", "visual-question-hint"], [1, "text-secondary", "me-1", 3, "icon", "ngbTooltip"], [1, "form-control", 3, "ngModel", "placeholder", "ngModelChange", "input"], [1, "form-group", "visual-question-hint"], ["id", "quiz-add-mc-question", 1, "btn", "btn-block", "btn-success", "mt-2", 3, "click"], [3, "icon"], ["jhiTranslate", "artemisApp.multipleChoiceQuestion.visualEditor.newAnswerTitle"], [1, "visual-answer-option", "form-group-narrow", 3, "id"], [1, "form-group-narrow", "visual-answer-question-container"], [1, "visual-answer", 3, "ngClass", "click"], [1, "visual-answer-delete-container", 3, "click"], [1, "visual-question-hint"]], template: function MultipleChoiceVisualQuestionComponent_Template(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275elementStart(0, "div", 0);
          i05.\u0275\u0275text(1, "\n    ");
          i05.\u0275\u0275elementStart(2, "h4");
          i05.\u0275\u0275text(3);
          i05.\u0275\u0275pipe(4, "artemisTranslate");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(5, "\n    ");
          i05.\u0275\u0275elementStart(6, "textarea", 1);
          i05.\u0275\u0275listener("ngModelChange", function MultipleChoiceVisualQuestionComponent_Template_textarea_ngModelChange_6_listener($event) {
            return ctx.question.text = $event;
          })("input", function MultipleChoiceVisualQuestionComponent_Template_textarea_input_6_listener() {
            return ctx.questionChanged.emit();
          });
          i05.\u0275\u0275pipe(7, "artemisTranslate");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(8, "\n    ");
          i05.\u0275\u0275elementStart(9, "div", 2);
          i05.\u0275\u0275text(10, "\n        ");
          i05.\u0275\u0275element(11, "fa-icon", 3);
          i05.\u0275\u0275pipe(12, "artemisTranslate");
          i05.\u0275\u0275text(13, "\n        ");
          i05.\u0275\u0275elementStart(14, "input", 4);
          i05.\u0275\u0275listener("ngModelChange", function MultipleChoiceVisualQuestionComponent_Template_input_ngModelChange_14_listener($event) {
            return ctx.question.hint = $event;
          })("input", function MultipleChoiceVisualQuestionComponent_Template_input_input_14_listener() {
            return ctx.questionChanged.emit();
          });
          i05.\u0275\u0275pipe(15, "artemisTranslate");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(16, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(17, "\n    ");
          i05.\u0275\u0275elementStart(18, "div", 5);
          i05.\u0275\u0275text(19, "\n        ");
          i05.\u0275\u0275element(20, "fa-icon", 3);
          i05.\u0275\u0275pipe(21, "artemisTranslate");
          i05.\u0275\u0275text(22, "\n        ");
          i05.\u0275\u0275elementStart(23, "input", 4);
          i05.\u0275\u0275listener("ngModelChange", function MultipleChoiceVisualQuestionComponent_Template_input_ngModelChange_23_listener($event) {
            return ctx.question.explanation = $event;
          })("input", function MultipleChoiceVisualQuestionComponent_Template_input_input_23_listener() {
            return ctx.questionChanged.emit();
          });
          i05.\u0275\u0275pipe(24, "artemisTranslate");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(25, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(26, "\n    ");
          i05.\u0275\u0275elementStart(27, "h4");
          i05.\u0275\u0275text(28);
          i05.\u0275\u0275pipe(29, "artemisTranslate");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(30, "\n    ");
          i05.\u0275\u0275repeaterCreate(31, MultipleChoiceVisualQuestionComponent_For_32_Template, 38, 24, null, null, i05.\u0275\u0275repeaterTrackByIdentity);
          i05.\u0275\u0275elementStart(33, "button", 6);
          i05.\u0275\u0275listener("click", function MultipleChoiceVisualQuestionComponent_Template_button_click_33_listener() {
            return ctx.addNewAnswer();
          });
          i05.\u0275\u0275text(34, "\n        ");
          i05.\u0275\u0275element(35, "fa-icon", 7);
          i05.\u0275\u0275text(36, "\n        ");
          i05.\u0275\u0275element(37, "span", 8);
          i05.\u0275\u0275text(38, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(39, "\n");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(40, "\n");
        }
        if (rf & 2) {
          i05.\u0275\u0275advance(3);
          i05.\u0275\u0275textInterpolate(i05.\u0275\u0275pipeBind1(4, 13, "artemisApp.multipleChoiceQuestion.visualEditor.questionTitle"));
          i05.\u0275\u0275advance(3);
          i05.\u0275\u0275propertyInterpolate("placeholder", i05.\u0275\u0275pipeBind1(7, 15, "artemisApp.multipleChoiceQuestion.visualEditor.textPlaceholder"));
          i05.\u0275\u0275property("ngModel", ctx.question.text);
          i05.\u0275\u0275advance(5);
          i05.\u0275\u0275propertyInterpolate("ngbTooltip", i05.\u0275\u0275pipeBind1(12, 17, "artemisApp.multipleChoiceQuestion.visualEditor.hintTooltip"));
          i05.\u0275\u0275property("icon", ctx.faQuestionCircle);
          i05.\u0275\u0275advance(3);
          i05.\u0275\u0275propertyInterpolate("placeholder", i05.\u0275\u0275pipeBind1(15, 19, "artemisApp.multipleChoiceQuestion.visualEditor.hintPlaceholder"));
          i05.\u0275\u0275property("ngModel", ctx.question.hint);
          i05.\u0275\u0275advance(6);
          i05.\u0275\u0275propertyInterpolate("ngbTooltip", i05.\u0275\u0275pipeBind1(21, 21, "artemisApp.multipleChoiceQuestion.visualEditor.explanationTooltip"));
          i05.\u0275\u0275property("icon", ctx.faExclamationCircle);
          i05.\u0275\u0275advance(3);
          i05.\u0275\u0275propertyInterpolate("placeholder", i05.\u0275\u0275pipeBind1(24, 23, "artemisApp.multipleChoiceQuestion.visualEditor.explanationPlaceholder"));
          i05.\u0275\u0275property("ngModel", ctx.question.explanation);
          i05.\u0275\u0275advance(5);
          i05.\u0275\u0275textInterpolate(i05.\u0275\u0275pipeBind1(29, 25, "artemisApp.multipleChoiceQuestion.visualEditor.answersTitle"));
          i05.\u0275\u0275advance(3);
          i05.\u0275\u0275repeater(ctx.question.answerOptions);
          i05.\u0275\u0275advance(4);
          i05.\u0275\u0275property("icon", ctx.faPlus);
        }
      }, dependencies: [i13.DefaultValueAccessor, i13.NgControlStatus, i13.NgModel, i2.NgClass, i3.NgbTooltip, i4.FaIconComponent, TranslateDirective, ArtemisTranslatePipe], styles: ["/* src/main/webapp/app/exercises/quiz/shared/questions/multiple-choice-question/multiple-choice-question.component.scss */\n.mc-question {\n  background: var(--quiz-question-background);\n  border: 1px solid var(--quiz-question-border-color);\n  box-sizing: border-box;\n  margin-bottom: 18px;\n  padding: 20px;\n  position: relative;\n  width: 100%;\n}\n.mc-question .answer-option {\n  display: flex;\n  align-items: center;\n  outline: none !important;\n  border: 1px solid var(--mc-question-answer-option-border);\n  margin: 4px 0;\n  padding: 6px 10px;\n}\n.mc-question .answer-option .selection {\n  width: 36px;\n  margin-left: 16px;\n}\n.mc-question .answer-option .content {\n  display: flex;\n  flex: 1;\n  align-items: center;\n}\n.mc-question .answer-option .content .text {\n  flex: 1;\n  padding-right: 8px;\n  font-size: 16px;\n}\n.mc-question .answer-option .content .hint {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-end;\n  font-size: 18px;\n}\n.mc-question .answer-options {\n  margin-top: 20px;\n}\n.mc-question .answer-options .answer-option {\n  cursor: pointer;\n  user-select: none;\n  -webkit-touch-callout: none;\n  -webkit-user-select: none;\n}\n.mc-question .answer-options .answer-option:hover {\n  background: var(--mc-question-answer-option-hover-background);\n}\n.mc-question .answer-options .answer-option:not(.click-disabled).selected {\n  animation: on-select 0.6s ease;\n  animation-fill-mode: forwards;\n  background: var(--mc-question-answer-option-selected-background);\n}\n@keyframes on-select {\n  0%, 100% {\n    transform: scale(1);\n  }\n  33% {\n    transform: scale(1.012);\n  }\n}\n.mc-question .answer-options .answer-option.click-disabled {\n  cursor: not-allowed;\n}\n.mc-question .answer-options .answer-option.click-disabled:hover {\n  background: inherit;\n}\n.mc-question table.answer-options-result {\n  width: 100%;\n}\n.mc-question table.answer-options-result .answer-option {\n  display: table-row;\n}\n.mc-question table.answer-options-result th {\n  color: var(--gray-600);\n}\n.mc-question table.answer-options-result th,\n.mc-question table.answer-options-result td {\n  padding: 6px 10px;\n}\n.mc-question table.answer-options-result .solution {\n  width: 100px;\n}\n.mc-question table.answer-options-result .result-symbol {\n  padding: 0;\n  color: var(--warning);\n  width: 50px;\n}\n.mc-question table.answer-options-result .selection {\n  width: 36px;\n  margin-left: 0;\n}\n.mc-question table.answer-options-result .correct {\n  color: var(--success);\n}\n.mc-question table.answer-options-result .wrong {\n  color: var(--danger);\n}\n.visual-mode {\n  margin-top: 20px;\n}\n.visual-question {\n  border-radius: 4px;\n  border: 1px solid var(--quiz-visual-question-border-color);\n  padding: 6px;\n}\n.visual-question-hint {\n  display: flex;\n  align-items: center;\n  font-size: 18px;\n}\n.visual-answer-option {\n  outline: none !important;\n  border: 1px solid var(--mc-question-answer-option-border);\n  margin: 4px 0;\n  padding: 6px 10px;\n}\n.visual-answer-question-container {\n  display: flex;\n}\n.visual-answer-delete-container {\n  background: var(--red);\n  align-items: center;\n  display: flex;\n  justify-content: center;\n  cursor: pointer;\n  width: 2.5%;\n  min-width: 35px;\n  margin-left: 0.2rem;\n  border-radius: 2px;\n}\n.visual-answer-correct-container {\n  background: var(--quiz-visual-answer-correct-container-color);\n  align-items: center;\n  display: flex;\n  justify-content: center;\n  cursor: pointer;\n  width: 2.5%;\n  min-width: 35px;\n  margin-right: 0.2rem;\n  border-radius: 2px;\n}\n.visual-answer-wrong-container {\n  background: var(--red);\n  align-items: center;\n  display: flex;\n  justify-content: center;\n  cursor: pointer;\n  width: 2.5%;\n  min-width: 35px;\n  margin-right: 0.2rem;\n  border-radius: 2px;\n}\n.visual-answer-add-container {\n  background: var(--quiz-visual-answer-add-container-color);\n  align-items: center;\n  display: flex;\n  justify-content: center;\n  cursor: pointer;\n  width: 2.5%;\n  min-width: 35px;\n  margin-left: 0.2rem;\n  border-radius: 2px;\n  color: var(--white);\n}\n.visual-answer-add-container:hover {\n  background: var(--quiz-visual-answer-add-container-hover-color);\n}\n.visual-answer-add-container-disabled {\n  background: var(--quiz-visual-answer-add-container-hover-color);\n  align-items: center;\n  display: flex;\n  justify-content: center;\n  cursor: pointer;\n  width: 2.5%;\n  min-width: 35px;\n  margin-left: 0.2rem;\n  border-radius: 2px;\n  color: var(--white);\n}\n.visual-answer-delete-container:hover {\n  color: var(--white);\n}\n.visual-answer-correct-container:hover {\n  background: var(--quiz-visual-answer-correct-container-hover-color);\n}\n.visual-answer-wrong-container:hover {\n  background: var(--quiz-visual-answer-wrong-container-hover-color);\n}\n.visual-answer {\n  color: var(--white);\n}\n.visual-new-answer-title {\n  margin-top: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL211bHRpcGxlLWNob2ljZS1xdWVzdGlvbi9tdWx0aXBsZS1jaG9pY2UtcXVlc3Rpb24uY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5tYy1xdWVzdGlvbiB7XG4gICAgYmFja2dyb3VuZDogdmFyKC0tcXVpei1xdWVzdGlvbi1iYWNrZ3JvdW5kKTtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1xdWl6LXF1ZXN0aW9uLWJvcmRlci1jb2xvcik7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICBtYXJnaW4tYm90dG9tOiAxOHB4O1xuICAgIHBhZGRpbmc6IDIwcHg7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHdpZHRoOiAxMDAlO1xuXG4gICAgLmFuc3dlci1vcHRpb24ge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBvdXRsaW5lOiBub25lICFpbXBvcnRhbnQ7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLW1jLXF1ZXN0aW9uLWFuc3dlci1vcHRpb24tYm9yZGVyKTtcbiAgICAgICAgbWFyZ2luOiA0cHggMDtcbiAgICAgICAgcGFkZGluZzogNnB4IDEwcHg7XG5cbiAgICAgICAgLnNlbGVjdGlvbiB7XG4gICAgICAgICAgICB3aWR0aDogMzZweDtcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxNnB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLmNvbnRlbnQge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGZsZXg6IDE7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgICAgICAgICAudGV4dCB7XG4gICAgICAgICAgICAgICAgZmxleDogMTtcbiAgICAgICAgICAgICAgICBwYWRkaW5nLXJpZ2h0OiA4cHg7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuaGludCB7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBmbGV4LWVuZDtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKiBVc2VkIHdoZW4gdGhlIHN0dWRlbnQgY2FuIHdvcmsgb24gdGhlIGV4ZXJjaXNlLiBTZWUgYW5zd2VyLW9wdGlvbnMtcmVzdWx0IGNsYXNzIGZvciByZXN1bHQgZGlzcGxheS4gKi9cbiAgICAuYW5zd2VyLW9wdGlvbnMge1xuICAgICAgICBtYXJnaW4tdG9wOiAyMHB4O1xuXG4gICAgICAgIC5hbnN3ZXItb3B0aW9uIHtcbiAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgICAgIHVzZXItc2VsZWN0OiBub25lO1xuICAgICAgICAgICAgLXdlYmtpdC10b3VjaC1jYWxsb3V0OiBub25lOyAvKiBpT1MgU2FmYXJpICovXG4gICAgICAgICAgICAtd2Via2l0LXVzZXItc2VsZWN0OiBub25lOyAvKiBTYWZhcmkgKi9cblxuICAgICAgICAgICAgJjpob3ZlciB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tbWMtcXVlc3Rpb24tYW5zd2VyLW9wdGlvbi1ob3Zlci1iYWNrZ3JvdW5kKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgJjpub3QoLmNsaWNrLWRpc2FibGVkKS5zZWxlY3RlZCB7XG4gICAgICAgICAgICAgICAgYW5pbWF0aW9uOiBvbi1zZWxlY3QgMC42cyBlYXNlO1xuICAgICAgICAgICAgICAgIGFuaW1hdGlvbi1maWxsLW1vZGU6IGZvcndhcmRzO1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLW1jLXF1ZXN0aW9uLWFuc3dlci1vcHRpb24tc2VsZWN0ZWQtYmFja2dyb3VuZCk7XG5cbiAgICAgICAgICAgICAgICBAa2V5ZnJhbWVzIG9uLXNlbGVjdCB7XG4gICAgICAgICAgICAgICAgICAgIDAlLFxuICAgICAgICAgICAgICAgICAgICAxMDAlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAzMyUge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjAxMik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICYuY2xpY2stZGlzYWJsZWQge1xuICAgICAgICAgICAgICAgIGN1cnNvcjogbm90LWFsbG93ZWQ7XG5cbiAgICAgICAgICAgICAgICAmOmhvdmVyIHtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogaW5oZXJpdDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICB0YWJsZS5hbnN3ZXItb3B0aW9ucy1yZXN1bHQge1xuICAgICAgICB3aWR0aDogMTAwJTtcblxuICAgICAgICAuYW5zd2VyLW9wdGlvbiB7XG4gICAgICAgICAgICBkaXNwbGF5OiB0YWJsZS1yb3c7XG4gICAgICAgIH1cblxuICAgICAgICB0aCB7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0tZ3JheS02MDApO1xuICAgICAgICB9XG5cbiAgICAgICAgdGgsXG4gICAgICAgIHRkIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDZweCAxMHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLnNvbHV0aW9uIHtcbiAgICAgICAgICAgIHdpZHRoOiAxMDBweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5yZXN1bHQtc3ltYm9sIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0td2FybmluZyk7XG4gICAgICAgICAgICB3aWR0aDogNTBweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5zZWxlY3Rpb24ge1xuICAgICAgICAgICAgd2lkdGg6IDM2cHg7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5jb3JyZWN0IHtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1zdWNjZXNzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC53cm9uZyB7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0tZGFuZ2VyKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnZpc3VhbC1tb2RlIHtcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuXG4udmlzdWFsLXF1ZXN0aW9uIHtcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tcXVpei12aXN1YWwtcXVlc3Rpb24tYm9yZGVyLWNvbG9yKTtcbiAgICBwYWRkaW5nOiA2cHg7XG59XG5cbi52aXN1YWwtcXVlc3Rpb24taGludCB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbn1cblxuLnZpc3VhbC1hbnN3ZXItb3B0aW9uIHtcbiAgICBvdXRsaW5lOiBub25lICFpbXBvcnRhbnQ7XG4gICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tbWMtcXVlc3Rpb24tYW5zd2VyLW9wdGlvbi1ib3JkZXIpO1xuICAgIG1hcmdpbjogNHB4IDA7XG4gICAgcGFkZGluZzogNnB4IDEwcHg7XG59XG5cbi52aXN1YWwtYW5zd2VyLXF1ZXN0aW9uLWNvbnRhaW5lciB7XG4gICAgZGlzcGxheTogZmxleDtcbn1cblxuLnZpc3VhbC1hbnN3ZXItZGVsZXRlLWNvbnRhaW5lciB7XG4gICAgYmFja2dyb3VuZDogdmFyKC0tcmVkKTtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHdpZHRoOiAyLjUlO1xuICAgIG1pbi13aWR0aDogMzVweDtcbiAgICBtYXJnaW4tbGVmdDogMC4ycmVtO1xuICAgIGJvcmRlci1yYWRpdXM6IDJweDtcbn1cblxuLnZpc3VhbC1hbnN3ZXItY29ycmVjdC1jb250YWluZXIge1xuICAgIGJhY2tncm91bmQ6IHZhcigtLXF1aXotdmlzdWFsLWFuc3dlci1jb3JyZWN0LWNvbnRhaW5lci1jb2xvcik7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB3aWR0aDogMi41JTtcbiAgICBtaW4td2lkdGg6IDM1cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAwLjJyZW07XG4gICAgYm9yZGVyLXJhZGl1czogMnB4O1xufVxuXG4udmlzdWFsLWFuc3dlci13cm9uZy1jb250YWluZXIge1xuICAgIGJhY2tncm91bmQ6IHZhcigtLXJlZCk7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB3aWR0aDogMi41JTtcbiAgICBtaW4td2lkdGg6IDM1cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAwLjJyZW07XG4gICAgYm9yZGVyLXJhZGl1czogMnB4O1xufVxuXG4udmlzdWFsLWFuc3dlci1hZGQtY29udGFpbmVyIHtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1xdWl6LXZpc3VhbC1hbnN3ZXItYWRkLWNvbnRhaW5lci1jb2xvcik7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB3aWR0aDogMi41JTtcbiAgICBtaW4td2lkdGg6IDM1cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDAuMnJlbTtcbiAgICBib3JkZXItcmFkaXVzOiAycHg7XG4gICAgY29sb3I6IHZhcigtLXdoaXRlKTtcbn1cblxuLnZpc3VhbC1hbnN3ZXItYWRkLWNvbnRhaW5lcjpob3ZlciB7XG4gICAgYmFja2dyb3VuZDogdmFyKC0tcXVpei12aXN1YWwtYW5zd2VyLWFkZC1jb250YWluZXItaG92ZXItY29sb3IpO1xufVxuXG4udmlzdWFsLWFuc3dlci1hZGQtY29udGFpbmVyLWRpc2FibGVkIHtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1xdWl6LXZpc3VhbC1hbnN3ZXItYWRkLWNvbnRhaW5lci1ob3Zlci1jb2xvcik7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB3aWR0aDogMi41JTtcbiAgICBtaW4td2lkdGg6IDM1cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDAuMnJlbTtcbiAgICBib3JkZXItcmFkaXVzOiAycHg7XG4gICAgY29sb3I6IHZhcigtLXdoaXRlKTtcbn1cblxuLnZpc3VhbC1hbnN3ZXItZGVsZXRlLWNvbnRhaW5lcjpob3ZlciB7XG4gICAgY29sb3I6IHZhcigtLXdoaXRlKTtcbn1cblxuLnZpc3VhbC1hbnN3ZXItY29ycmVjdC1jb250YWluZXI6aG92ZXIge1xuICAgIGJhY2tncm91bmQ6IHZhcigtLXF1aXotdmlzdWFsLWFuc3dlci1jb3JyZWN0LWNvbnRhaW5lci1ob3Zlci1jb2xvcik7XG59XG5cbi52aXN1YWwtYW5zd2VyLXdyb25nLWNvbnRhaW5lcjpob3ZlciB7XG4gICAgYmFja2dyb3VuZDogdmFyKC0tcXVpei12aXN1YWwtYW5zd2VyLXdyb25nLWNvbnRhaW5lci1ob3Zlci1jb2xvcik7XG59XG5cbi52aXN1YWwtYW5zd2VyIHtcbiAgICBjb2xvcjogdmFyKC0td2hpdGUpO1xufVxuXG4udmlzdWFsLW5ldy1hbnN3ZXItdGl0bGUge1xuICAgIG1hcmdpbi10b3A6IDFyZW07XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLGNBQUEsSUFBQTtBQUNBLFVBQUEsSUFBQSxNQUFBLElBQUE7QUFDQSxjQUFBO0FBQ0EsaUJBQUE7QUFDQSxXQUFBO0FBQ0EsWUFBQTtBQUNBLFNBQUE7O0FBRUEsQ0FUSixZQVNJLENBQUE7QUFDSSxXQUFBO0FBQ0EsZUFBQTtBQUNBLFdBQUE7QUFDQSxVQUFBLElBQUEsTUFBQSxJQUFBO0FBQ0EsVUFBQSxJQUFBO0FBQ0EsV0FBQSxJQUFBOztBQUVBLENBakJSLFlBaUJRLENBUkosY0FRSSxDQUFBO0FBQ0ksU0FBQTtBQUNBLGVBQUE7O0FBR0osQ0F0QlIsWUFzQlEsQ0FiSixjQWFJLENBQUE7QUFDSSxXQUFBO0FBQ0EsUUFBQTtBQUNBLGVBQUE7O0FBRUEsQ0EzQlosWUEyQlksQ0FsQlIsY0FrQlEsQ0FMSixRQUtJLENBQUE7QUFDSSxRQUFBO0FBQ0EsaUJBQUE7QUFDQSxhQUFBOztBQUdKLENBakNaLFlBaUNZLENBeEJSLGNBd0JRLENBWEosUUFXSSxDQUFBO0FBQ0ksV0FBQTtBQUNBLGtCQUFBO0FBQ0EsZUFBQTtBQUNBLGFBQUE7O0FBTVosQ0EzQ0osWUEyQ0ksQ0FBQTtBQUNJLGNBQUE7O0FBRUEsQ0E5Q1IsWUE4Q1EsQ0FISixlQUdJLENBckNKO0FBc0NRLFVBQUE7QUFDQSxlQUFBO0FBQ0EseUJBQUE7QUFDQSx1QkFBQTs7QUFFQSxDQXBEWixZQW9EWSxDQVRSLGVBU1EsQ0EzQ1IsYUEyQ1E7QUFDSSxjQUFBLElBQUE7O0FBR0osQ0F4RFosWUF3RFksQ0FiUixlQWFRLENBL0NSLGFBK0NRLEtBQUEsQ0FBQSxlQUFBLENBQUE7QUFDSSxhQUFBLFVBQUEsS0FBQTtBQUNBLHVCQUFBO0FBQ0EsY0FBQSxJQUFBOztBQUVBLFdBSkE7QUFLSTtBQUVJLGVBQUEsTUFBQTs7QUFHSjtBQUNJLGVBQUEsTUFBQTs7O0FBS1osQ0F6RVosWUF5RVksQ0E5QlIsZUE4QlEsQ0FoRVIsYUFnRVEsQ0FqQkE7QUFrQkksVUFBQTs7QUFFQSxDQTVFaEIsWUE0RWdCLENBakNaLGVBaUNZLENBbkVaLGFBbUVZLENBcEJKLGNBb0JJO0FBQ0ksY0FBQTs7QUFNaEIsQ0FuRkosWUFtRkksS0FBQSxDQUFBO0FBQ0ksU0FBQTs7QUFFQSxDQXRGUixZQXNGUSxLQUFBLENBSEosc0JBR0ksQ0E3RUo7QUE4RVEsV0FBQTs7QUFHSixDQTFGUixZQTBGUSxLQUFBLENBUEosc0JBT0k7QUFDSSxTQUFBLElBQUE7O0FBR0osQ0E5RlIsWUE4RlEsS0FBQSxDQVhKLHNCQVdJO0FBQUEsQ0E5RlIsWUE4RlEsS0FBQSxDQVhKLHNCQVdJO0FBRUksV0FBQSxJQUFBOztBQUdKLENBbkdSLFlBbUdRLEtBQUEsQ0FoQkosc0JBZ0JJLENBQUE7QUFDSSxTQUFBOztBQUdKLENBdkdSLFlBdUdRLEtBQUEsQ0FwQkosc0JBb0JJLENBQUE7QUFDSSxXQUFBO0FBQ0EsU0FBQSxJQUFBO0FBQ0EsU0FBQTs7QUFHSixDQTdHUixZQTZHUSxLQUFBLENBMUJKLHNCQTBCSSxDQTVGQTtBQTZGSSxTQUFBO0FBQ0EsZUFBQTs7QUFHSixDQWxIUixZQWtIUSxLQUFBLENBL0JKLHNCQStCSSxDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUdKLENBdEhSLFlBc0hRLEtBQUEsQ0FuQ0osc0JBbUNJLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBS1osQ0FBQTtBQUNJLGNBQUE7O0FBR0osQ0FBQTtBQUNJLGlCQUFBO0FBQ0EsVUFBQSxJQUFBLE1BQUEsSUFBQTtBQUNBLFdBQUE7O0FBR0osQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBO0FBQ0EsYUFBQTs7QUFHSixDQUFBO0FBQ0ksV0FBQTtBQUNBLFVBQUEsSUFBQSxNQUFBLElBQUE7QUFDQSxVQUFBLElBQUE7QUFDQSxXQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLFdBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUEsSUFBQTtBQUNBLGVBQUE7QUFDQSxXQUFBO0FBQ0EsbUJBQUE7QUFDQSxVQUFBO0FBQ0EsU0FBQTtBQUNBLGFBQUE7QUFDQSxlQUFBO0FBQ0EsaUJBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUEsSUFBQTtBQUNBLGVBQUE7QUFDQSxXQUFBO0FBQ0EsbUJBQUE7QUFDQSxVQUFBO0FBQ0EsU0FBQTtBQUNBLGFBQUE7QUFDQSxnQkFBQTtBQUNBLGlCQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBLElBQUE7QUFDQSxlQUFBO0FBQ0EsV0FBQTtBQUNBLG1CQUFBO0FBQ0EsVUFBQTtBQUNBLFNBQUE7QUFDQSxhQUFBO0FBQ0EsZ0JBQUE7QUFDQSxpQkFBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQSxJQUFBO0FBQ0EsZUFBQTtBQUNBLFdBQUE7QUFDQSxtQkFBQTtBQUNBLFVBQUE7QUFDQSxTQUFBO0FBQ0EsYUFBQTtBQUNBLGVBQUE7QUFDQSxpQkFBQTtBQUNBLFNBQUEsSUFBQTs7QUFHSixDQWJBLDJCQWFBO0FBQ0ksY0FBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBLElBQUE7QUFDQSxlQUFBO0FBQ0EsV0FBQTtBQUNBLG1CQUFBO0FBQ0EsVUFBQTtBQUNBLFNBQUE7QUFDQSxhQUFBO0FBQ0EsZUFBQTtBQUNBLGlCQUFBO0FBQ0EsU0FBQSxJQUFBOztBQUdKLENBbEVBLDhCQWtFQTtBQUNJLFNBQUEsSUFBQTs7QUFHSixDQTFEQSwrQkEwREE7QUFDSSxjQUFBLElBQUE7O0FBR0osQ0FsREEsNkJBa0RBO0FBQ0ksY0FBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxTQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLGNBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */\n", "/* src/main/webapp/app/exercises/quiz/participate/quiz-participation.scss */\n.dnd-question,\n.mc-question,\n.sa-question {\n}\n.dnd-question.disabled,\n.mc-question.disabled,\n.sa-question.disabled {\n  color: var(--quiz-participation-question-disabled-color);\n  background: var(--quiz-participation-question-disabled-background);\n}\n.dnd-question.result,\n.mc-question.result,\n.sa-question.result {\n  border-color: var(--quiz-participation-question-result-border-color);\n}\n.dnd-question.result .show-explanation,\n.mc-question.result .show-explanation,\n.sa-question.result .show-explanation {\n  display: inline-block;\n}\n.dnd-question.result.incorrect,\n.mc-question.result.incorrect,\n.sa-question.result.incorrect {\n  border-color: var(--quiz-participation-question-result-incorrect-border-color);\n}\n.dnd-question h2,\n.mc-question h2,\n.sa-question h2 {\n  margin: 0 90px 0 0;\n}\n.dnd-question h2 span,\n.mc-question h2 span,\n.sa-question h2 span {\n  color: var(--quiz-participation-question-h2-span-color);\n}\n.dnd-question p,\n.mc-question p,\n.sa-question p {\n  margin: 10px 0;\n  font-size: 16px;\n}\n.dnd-question .question-title-display,\n.mc-question .question-title-display,\n.sa-question .question-title-display {\n  max-width: 80%;\n}\n.dnd-question .question-score,\n.mc-question .question-score,\n.sa-question .question-score {\n  position: absolute;\n  top: 20px;\n  right: 20px;\n  max-width: 30%;\n}\n@media (max-width: 900px) {\n  .dnd-question .question-score,\n  .mc-question .question-score,\n  .sa-question .question-score {\n    position: relative;\n    top: 0;\n    right: 0;\n    max-width: 100%;\n  }\n}\n.dnd-question .question-score.result,\n.mc-question .question-score.result,\n.sa-question .question-score.result {\n  font-weight: bold;\n  color: var(--quiz-participation-question-score-result);\n}\n.dnd-question .question-score.result.incorrect,\n.mc-question .question-score.result.incorrect,\n.sa-question .question-score.result.incorrect {\n  color: var(--quiz-participation-question-score-incorrect-result);\n}\n.dnd-question .label,\n.mc-question .label,\n.sa-question .label {\n  cursor: pointer;\n  margin: 2px 0;\n}\n.dnd-question .label + ngb-popover-window,\n.mc-question .label + ngb-popover-window,\n.sa-question .label + ngb-popover-window {\n  max-width: 500px;\n}\n.dnd-question ngb-popover-window,\n.mc-question ngb-popover-window,\n.sa-question ngb-popover-window {\n  max-width: 500px;\n}\n@media (max-width: 991.98px) {\n  .dnd-question ngb-popover-window,\n  .mc-question ngb-popover-window,\n  .sa-question ngb-popover-window {\n    max-width: 300px !important;\n  }\n}\n@media (max-width: 575.98px) {\n  .dnd-question ngb-popover-window,\n  .mc-question ngb-popover-window,\n  .sa-question ngb-popover-window {\n    max-width: 200px !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9wYXJ0aWNpcGF0ZS9xdWl6LXBhcnRpY2lwYXRpb24uc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmRuZC1xdWVzdGlvbixcbi5tYy1xdWVzdGlvbixcbi5zYS1xdWVzdGlvbiB7XG4gICAgJi5kaXNhYmxlZCB7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tcXVlc3Rpb24tZGlzYWJsZWQtY29sb3IpO1xuICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tcXVlc3Rpb24tZGlzYWJsZWQtYmFja2dyb3VuZCk7XG4gICAgfVxuXG4gICAgJi5yZXN1bHQge1xuICAgICAgICBib3JkZXItY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1yZXN1bHQtYm9yZGVyLWNvbG9yKTtcblxuICAgICAgICAuc2hvdy1leHBsYW5hdGlvbiB7XG4gICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgIH1cblxuICAgICAgICAmLmluY29ycmVjdCB7XG4gICAgICAgICAgICBib3JkZXItY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1yZXN1bHQtaW5jb3JyZWN0LWJvcmRlci1jb2xvcik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBoMiB7XG4gICAgICAgIG1hcmdpbjogMCA5MHB4IDAgMDtcblxuICAgICAgICBzcGFuIHtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1xdWl6LXBhcnRpY2lwYXRpb24tcXVlc3Rpb24taDItc3Bhbi1jb2xvcik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwIHtcbiAgICAgICAgbWFyZ2luOiAxMHB4IDA7XG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICB9XG5cbiAgICAucXVlc3Rpb24tdGl0bGUtZGlzcGxheSB7XG4gICAgICAgIG1heC13aWR0aDogODAlO1xuICAgIH1cblxuICAgIC5xdWVzdGlvbi1zY29yZSB7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdG9wOiAyMHB4O1xuICAgICAgICByaWdodDogMjBweDtcbiAgICAgICAgbWF4LXdpZHRoOiAzMCU7XG5cbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDkwMHB4KSB7XG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICB0b3A6IDA7XG4gICAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgICAgIG1heC13aWR0aDogMTAwJTtcbiAgICAgICAgfVxuXG4gICAgICAgICYucmVzdWx0IHtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1zY29yZS1yZXN1bHQpO1xuXG4gICAgICAgICAgICAmLmluY29ycmVjdCB7XG4gICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLXF1aXotcGFydGljaXBhdGlvbi1xdWVzdGlvbi1zY29yZS1pbmNvcnJlY3QtcmVzdWx0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5sYWJlbCB7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgbWFyZ2luOiAycHggMDtcblxuICAgICAgICAvKiBhZGp1c3QgW25nYlBvcG92ZXJdIHdpbmRvdyBzdHlsZSAqL1xuICAgICAgICAmICsgbmdiLXBvcG92ZXItd2luZG93IHtcbiAgICAgICAgICAgIG1heC13aWR0aDogNTAwcHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKiBhZGp1c3QgW25nYlBvcG92ZXJdIHdpbmRvdyBzdHlsZSAqL1xuICAgIG5nYi1wb3BvdmVyLXdpbmRvdyB7XG4gICAgICAgIG1heC13aWR0aDogNTAwcHg7XG5cbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDk5MS45OHB4KSB7XG4gICAgICAgICAgICBtYXgtd2lkdGg6IDMwMHB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIH1cblxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNTc1Ljk4cHgpIHtcbiAgICAgICAgICAgIG1heC13aWR0aDogMjAwcHggIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQUEsQ0FBQTtBQUFBLENBQUE7O0FBR0ksQ0FISixZQUdJLENBQUE7QUFBQSxDQUhKLFdBR0ksQ0FBQTtBQUFBLENBSEosV0FHSSxDQUFBO0FBQ0ksU0FBQSxJQUFBO0FBQ0EsY0FBQSxJQUFBOztBQUdKLENBUkosWUFRSSxDQUFBO0FBQUEsQ0FSSixXQVFJLENBQUE7QUFBQSxDQVJKLFdBUUksQ0FBQTtBQUNJLGdCQUFBLElBQUE7O0FBRUEsQ0FYUixZQVdRLENBSEosT0FHSSxDQUFBO0FBQUEsQ0FYUixXQVdRLENBSEosT0FHSSxDQUFBO0FBQUEsQ0FYUixXQVdRLENBSEosT0FHSSxDQUFBO0FBQ0ksV0FBQTs7QUFHSixDQWZSLFlBZVEsQ0FQSixNQU9JLENBQUE7QUFBQSxDQWZSLFdBZVEsQ0FQSixNQU9JLENBQUE7QUFBQSxDQWZSLFdBZVEsQ0FQSixNQU9JLENBQUE7QUFDSSxnQkFBQSxJQUFBOztBQUlSLENBcEJKLGFBb0JJO0FBQUEsQ0FwQkosWUFvQkk7QUFBQSxDQXBCSixZQW9CSTtBQUNJLFVBQUEsRUFBQSxLQUFBLEVBQUE7O0FBRUEsQ0F2QlIsYUF1QlEsR0FBQTtBQUFBLENBdkJSLFlBdUJRLEdBQUE7QUFBQSxDQXZCUixZQXVCUSxHQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUlSLENBNUJKLGFBNEJJO0FBQUEsQ0E1QkosWUE0Qkk7QUFBQSxDQTVCSixZQTRCSTtBQUNJLFVBQUEsS0FBQTtBQUNBLGFBQUE7O0FBR0osQ0FqQ0osYUFpQ0ksQ0FBQTtBQUFBLENBakNKLFlBaUNJLENBQUE7QUFBQSxDQWpDSixZQWlDSSxDQUFBO0FBQ0ksYUFBQTs7QUFHSixDQXJDSixhQXFDSSxDQUFBO0FBQUEsQ0FyQ0osWUFxQ0ksQ0FBQTtBQUFBLENBckNKLFlBcUNJLENBQUE7QUFDSSxZQUFBO0FBQ0EsT0FBQTtBQUNBLFNBQUE7QUFDQSxhQUFBOztBQUVBLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFOSixHQXJDSixhQXFDSSxDQUFBO0VBQUEsQ0FyQ0osWUFxQ0ksQ0FBQTtFQUFBLENBckNKLFlBcUNJLENBQUE7QUFPUSxjQUFBO0FBQ0EsU0FBQTtBQUNBLFdBQUE7QUFDQSxlQUFBOzs7QUFHSixDQWxEUixhQWtEUSxDQWJKLGNBYUksQ0ExQ0o7QUEwQ0ksQ0FsRFIsWUFrRFEsQ0FiSixjQWFJLENBMUNKO0FBMENJLENBbERSLFlBa0RRLENBYkosY0FhSSxDQTFDSjtBQTJDUSxlQUFBO0FBQ0EsU0FBQSxJQUFBOztBQUVBLENBdERaLGFBc0RZLENBakJSLGNBaUJRLENBOUNSLE1BOENRLENBdkNKO0FBdUNJLENBdERaLFlBc0RZLENBakJSLGNBaUJRLENBOUNSLE1BOENRLENBdkNKO0FBdUNJLENBdERaLFlBc0RZLENBakJSLGNBaUJRLENBOUNSLE1BOENRLENBdkNKO0FBd0NRLFNBQUEsSUFBQTs7QUFLWixDQTVESixhQTRESSxDQUFBO0FBQUEsQ0E1REosWUE0REksQ0FBQTtBQUFBLENBNURKLFlBNERJLENBQUE7QUFDSSxVQUFBO0FBQ0EsVUFBQSxJQUFBOztBQUdBLENBakVSLGFBaUVRLENBTEosTUFLSSxFQUFBO0FBQUEsQ0FqRVIsWUFpRVEsQ0FMSixNQUtJLEVBQUE7QUFBQSxDQWpFUixZQWlFUSxDQUxKLE1BS0ksRUFBQTtBQUNJLGFBQUE7O0FBS1IsQ0F2RUosYUF1RUk7QUFBQSxDQXZFSixZQXVFSTtBQUFBLENBdkVKLFlBdUVJO0FBQ0ksYUFBQTs7QUFFQSxPQUFBLENBQUEsU0FBQSxFQUFBO0FBSEosR0F2RUosYUF1RUk7RUFBQSxDQXZFSixZQXVFSTtFQUFBLENBdkVKLFlBdUVJO0FBSVEsZUFBQTs7O0FBR0osT0FBQSxDQUFBLFNBQUEsRUFBQTtBQVBKLEdBdkVKLGFBdUVJO0VBQUEsQ0F2RUosWUF1RUk7RUFBQSxDQXZFSixZQXVFSTtBQVFRLGVBQUE7OzsiLAogICJuYW1lcyI6IFtdCn0K */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(MultipleChoiceVisualQuestionComponent, { className: "MultipleChoiceVisualQuestionComponent" });
    })();
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/courseArtifactReferenceCommands/exerciseReferenceCommand.ts
var ExerciseReferenceCommand;
var init_exerciseReferenceCommand = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/courseArtifactReferenceCommands/exerciseReferenceCommand.ts"() {
    init_multiOptionCommand();
    ExerciseReferenceCommand = class extends MultiOptionCommand {
      metisService;
      buttonTranslationString = "artemisApp.metis.editor.exercise";
      constructor(metisService) {
        super();
        this.metisService = metisService;
        this.setValues(this.metisService.getCourse().exercises?.map((exercise) => ({
          id: exercise.id.toString(),
          value: exercise.title,
          type: exercise.type
        })));
      }
      execute(selectedExerciseId) {
        const selectedExercise = this.getValues().find((value) => value.id.toString() === selectedExerciseId);
        const referenceLink = `[${selectedExercise.type}]${selectedExercise.value}(${this.metisService.getLinkForExercise(selectedExercise.id)})[/${selectedExercise.type}]`;
        this.insertText(referenceLink);
        this.focus();
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/commands/interactiveSearchCommand.ts
var InteractiveSearchCommand;
var init_interactiveSearchCommand = __esm({
  "src/main/webapp/app/shared/markdown-editor/commands/interactiveSearchCommand.ts"() {
    init_multiOptionCommand();
    InteractiveSearchCommand = class extends MultiOptionCommand {
      selectWithSearchComponent;
      execute() {
        this.aceEditor.execCommand(this.getAssociatedInputCharacter());
      }
      searchPositionStart;
      setEditor(aceEditor) {
        super.setEditor(aceEditor);
        this.aceEditor.commands.addCommand({
          name: this.getAssociatedInputCharacter(),
          bindKey: { win: this.getAssociatedInputCharacter(), mac: this.getAssociatedInputCharacter() },
          exec: (editor) => {
            if (this.searchPositionStart) {
              return;
            }
            const cursorPosition = this.getCursorPosition();
            const lineContent = editor.session.getLine(cursorPosition.row).substring(0, cursorPosition.column);
            editor.insert(this.getAssociatedInputCharacter());
            if (cursorPosition.column === 0 || lineContent.slice(-1).match(/\s/)) {
              this.searchPositionStart = cursorPosition;
              this.selectWithSearchComponent?.open();
              this.aceEditor.focus();
            }
          }
        });
      }
      setSelectWithSearchComponent(component) {
        this.selectWithSearchComponent = component;
      }
      insertSelection(selected) {
        if (selected !== void 0) {
          const cursorPosition = this.aceEditor.getCursorPosition();
          this.aceEditor.session.getDocument().removeInLine(cursorPosition.row, this.searchPositionStart?.row === cursorPosition.row ? this.searchPositionStart.column : 0, cursorPosition.column);
          this.searchPositionStart = void 0;
          this.insertText(this.selectionToText(selected));
        }
        this.searchPositionStart = void 0;
        this.aceEditor.focus();
      }
      getCursorScreenPosition() {
        const cursorPosition = super.getCursorPosition();
        return this.aceEditor.renderer.textToScreenCoordinates(cursorPosition.row, cursorPosition.column);
      }
      updateSearchTerm() {
        if (!this.searchPositionStart) {
          return;
        }
        const cursorPosition = this.aceEditor.getCursorPosition();
        const lineContent = this.aceEditor.session.getLine(cursorPosition.row);
        const lastAtIndex = lineContent.substring(cursorPosition.row === this.searchPositionStart.row ? this.searchPositionStart.column : 0, cursorPosition.column + 1).lastIndexOf(this.getAssociatedInputCharacter());
        if (lastAtIndex >= 0) {
          const searchTerm = lineContent.substring(0, cursorPosition.column + 1).split(this.getAssociatedInputCharacter()).pop();
          this.selectWithSearchComponent.updateSearchTerm(searchTerm);
        } else {
          this.selectWithSearchComponent.close();
        }
      }
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/select-with-search/select-with-search.component.ts
import { ChangeDetectorRef, Component as Component4, ElementRef as ElementRef5, Input as Input4, ViewChild } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject, debounce, distinctUntilChanged, switchMap, takeUntil, timer } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { NgbDropdown, NgbDropdownConfig } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function SelectWithSearchComponent_For_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n            ");
    i06.\u0275\u0275elementStart(1, "button", 6);
    i06.\u0275\u0275listener("click", function SelectWithSearchComponent_For_13_Template_button_click_1_listener() {
      const restoredCtx = i06.\u0275\u0275restoreView(_r8);
      const value_r2 = restoredCtx.$implicit;
      const ctx_r7 = i06.\u0275\u0275nextContext();
      return i06.\u0275\u0275resetView(ctx_r7.setSelection(value_r2));
    });
    i06.\u0275\u0275text(2);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(3, "\n        ");
  }
  if (rf & 2) {
    const value_r2 = ctx.$implicit;
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275textInterpolate(value_r2.name);
  }
}
var _c02, _c1, SelectWithSearchComponent;
var init_select_with_search_component = __esm({
  "src/main/webapp/app/shared/markdown-editor/select-with-search/select-with-search.component.ts"() {
    init_interactiveSearchCommand();
    init_alert_service();
    init_global_utils();
    init_alert_service();
    _c02 = ["dropdown"];
    _c1 = () => ["top-start"];
    SelectWithSearchComponent = class _SelectWithSearchComponent {
      alertService;
      cdr;
      command;
      editorContentString;
      dropdown;
      dropdownRef;
      ngUnsubscribe = new Subject();
      search$ = new Subject();
      values = [];
      selectedValue;
      offsetX;
      offsetY;
      constructor(alertService, cdr) {
        this.alertService = alertService;
        this.cdr = cdr;
      }
      ngOnInit() {
        this.command.setSelectWithSearchComponent(this);
        this.search$.pipe(debounce((searchQuery) => {
          return timer(searchQuery.noDebounce ? 0 : 200);
        }), distinctUntilChanged((prev, curr) => {
          return prev === curr;
        }), switchMap((searchQuery) => this.command.performSearch(searchQuery.searchTerm)), takeUntil(this.ngUnsubscribe)).subscribe({
          next: (res) => {
            this.values = res.body;
            this.cdr.detectChanges();
          },
          error: (errorResponse) => {
            onError(this.alertService, errorResponse);
          }
        });
      }
      ngOnChanges(changes) {
        if (changes.editorContentString) {
          this.command.updateSearchTerm();
        }
      }
      ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
      }
      open() {
        this.dropdown.open();
      }
      close() {
        this.dropdown.close();
      }
      updateSearchTerm(searchInput, noDebounce = false) {
        const searchTerm = searchInput?.trim().toLowerCase() ?? "";
        this.search$.next({ searchTerm, noDebounce });
      }
      handleMenuOpen() {
        const cursorPosition = this.command.getCursorScreenPosition();
        const dropdownPosition = this.dropdownRef.nativeElement.getBoundingClientRect();
        this.offsetX = cursorPosition.pageX - dropdownPosition.left + "px";
        this.offsetY = cursorPosition.pageY - dropdownPosition.top + "px";
        this.updateSearchTerm("", true);
        this.cdr.detectChanges();
      }
      handleMenuClosed() {
        this.command.insertSelection(this.selectedValue);
        this.selectedValue = void 0;
      }
      setSelection(value) {
        this.selectedValue = value;
        this.dropdown.close();
      }
      handleToggle() {
        if (this.dropdown.isOpen()) {
          this.close();
        } else {
          this.command.execute();
        }
      }
      static \u0275fac = function SelectWithSearchComponent_Factory(t) {
        return new (t || _SelectWithSearchComponent)(i06.\u0275\u0275directiveInject(AlertService), i06.\u0275\u0275directiveInject(i06.ChangeDetectorRef));
      };
      static \u0275cmp = i06.\u0275\u0275defineComponent({ type: _SelectWithSearchComponent, selectors: [["jhi-select-with-search"]], viewQuery: function SelectWithSearchComponent_Query(rf, ctx) {
        if (rf & 1) {
          i06.\u0275\u0275viewQuery(NgbDropdown, 5);
          i06.\u0275\u0275viewQuery(_c02, 5);
        }
        if (rf & 2) {
          let _t;
          i06.\u0275\u0275queryRefresh(_t = i06.\u0275\u0275loadQuery()) && (ctx.dropdown = _t.first);
          i06.\u0275\u0275queryRefresh(_t = i06.\u0275\u0275loadQuery()) && (ctx.dropdownRef = _t.first);
        }
      }, inputs: { command: "command", editorContentString: "editorContentString" }, features: [i06.\u0275\u0275ProvidersFeature([NgbDropdownConfig]), i06.\u0275\u0275NgOnChangesFeature], decls: 16, vars: 7, consts: [["ngbDropdown", "", "autoClose", "inside", 1, "d-inline-block", 3, "placement", "openChange"], ["dropdown", ""], ["type", "button", 1, "btn", "btn-sm", "py-0", 3, "click"], [3, "icon"], ["ngbDropdownAnchor", "", "id", "anchor", 1, "invisible-anchor"], ["ngbDropdownMenu", ""], ["ngbDropdownItem", "", "type", "button", 3, "click"]], template: function SelectWithSearchComponent_Template(rf, ctx) {
        if (rf & 1) {
          i06.\u0275\u0275elementStart(0, "div", 0, 1);
          i06.\u0275\u0275listener("openChange", function SelectWithSearchComponent_Template_div_openChange_0_listener($event) {
            return $event ? ctx.handleMenuOpen() : ctx.handleMenuClosed();
          });
          i06.\u0275\u0275text(2, "\n    ");
          i06.\u0275\u0275elementStart(3, "button", 2);
          i06.\u0275\u0275listener("click", function SelectWithSearchComponent_Template_button_click_3_listener() {
            return ctx.handleToggle();
          });
          i06.\u0275\u0275text(4, "\n        ");
          i06.\u0275\u0275element(5, "fa-icon", 3);
          i06.\u0275\u0275text(6, "\n    ");
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(7, "\n    ");
          i06.\u0275\u0275element(8, "div", 4);
          i06.\u0275\u0275text(9, "\n    ");
          i06.\u0275\u0275elementStart(10, "div", 5);
          i06.\u0275\u0275text(11, "\n        ");
          i06.\u0275\u0275repeaterCreate(12, SelectWithSearchComponent_For_13_Template, 4, 1, null, null, i06.\u0275\u0275repeaterTrackByIdentity);
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(14, "\n");
          i06.\u0275\u0275elementEnd();
          i06.\u0275\u0275text(15, "\n");
        }
        if (rf & 2) {
          i06.\u0275\u0275property("placement", i06.\u0275\u0275pureFunction0(6, _c1));
          i06.\u0275\u0275advance(5);
          i06.\u0275\u0275property("icon", ctx.command.buttonIcon);
          i06.\u0275\u0275advance(3);
          i06.\u0275\u0275styleProp("top", ctx.offsetY)("left", ctx.offsetX);
          i06.\u0275\u0275advance(4);
          i06.\u0275\u0275repeater(ctx.values);
        }
      }, dependencies: [i22.NgbDropdown, i22.NgbDropdownAnchor, i22.NgbDropdownMenu, i22.NgbDropdownItem, i22.NgbDropdownButtonItem, i32.FaIconComponent], styles: ["\n\n.invisible-anchor[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 0;\n  height: 0;\n}\n#anchor[_ngcontent-%COMP%]::after {\n  display: none;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL3NlbGVjdC13aXRoLXNlYXJjaC9zZWxlY3Qtd2l0aC1zZWFyY2guY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5pbnZpc2libGUtYW5jaG9yIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgd2lkdGg6IDA7XG4gICAgaGVpZ2h0OiAwO1xufVxuXG4jYW5jaG9yOjphZnRlciB7XG4gICAgZGlzcGxheTogbm9uZTtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksWUFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBOztBQUdKLENBQUEsTUFBQTtBQUNJLFdBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i06.\u0275setClassDebugInfo(SelectWithSearchComponent, { className: "SelectWithSearchComponent" });
    })();
  }
});

// src/main/webapp/app/shared/markdown-editor/markdown-editor.component.ts
import { Component as Component5, ContentChild, ElementRef as ElementRef6, EventEmitter as EventEmitter4, Input as Input5, Output as Output4, ViewChild as ViewChild2, ViewEncapsulation as ViewEncapsulation2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/brace_theme_chrome.js?v=1d0d9ead";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/brace_mode_markdown.js?v=1d0d9ead";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/brace_mode_latex.js?v=1d0d9ead";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/brace_ext_language_tools.js?v=1d0d9ead";
import __vite__cjsImport58_interactjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/interactjs.js?v=1d0d9ead"; const interact = __vite__cjsImport58_interactjs.__esModule ? __vite__cjsImport58_interactjs.default : __vite__cjsImport58_interactjs;
import { faAngleDown, faAngleRight, faGripLines, faQuestionCircle as faQuestionCircle2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { v4 as uuid } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/uuid.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i42 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i6 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i10 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_menu.js?v=1d0d9ead";
import * as i11 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_button.js?v=1d0d9ead";
function MarkdownEditorComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275elementStart(1, "a", 9);
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275pipe(3, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(3, 1, "entity.action.edit"));
  }
}
function MarkdownEditorComponent_ng_template_10_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                        ");
    i07.\u0275\u0275elementStart(1, "input", 13);
    i07.\u0275\u0275listener("change", function MarkdownEditorComponent_ng_template_10_Conditional_8_Template_input_change_1_listener($event) {
      i07.\u0275\u0275restoreView(_r13);
      const ctx_r12 = i07.\u0275\u0275nextContext(2);
      return i07.\u0275\u0275resetView(ctx_r12.onFileUpload($event));
    });
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(2, "\n                        ");
    i07.\u0275\u0275elementStart(3, "label", 14);
    i07.\u0275\u0275text(4, "\n                            ");
    i07.\u0275\u0275elementStart(5, "div", 15);
    i07.\u0275\u0275text(6, "\n                                ");
    i07.\u0275\u0275elementStart(7, "span", 16);
    i07.\u0275\u0275text(8);
    i07.\u0275\u0275pipe(9, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(10, "\n                                ");
    i07.\u0275\u0275elementStart(11, "a", 17);
    i07.\u0275\u0275text(12, "\n                                    ");
    i07.\u0275\u0275element(13, "fa-icon", 18);
    i07.\u0275\u0275pipe(14, "artemisTranslate");
    i07.\u0275\u0275text(15, "\n                                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(16, "\n                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(17, "\n                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(18, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r10 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("multiple", true);
    i07.\u0275\u0275advance(7);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(9, 4, "artemisApp.markdownEditor.fileUpload"));
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275property("icon", ctx_r10.faQuestionCircle)("ngbTooltip", i07.\u0275\u0275pipeBind1(14, 6, "artemisApp.markdownEditor.guide"));
  }
}
function MarkdownEditorComponent_ng_template_10_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                        ");
    i07.\u0275\u0275elementStart(1, "fa-icon", 19);
    i07.\u0275\u0275element(2, "span");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r11 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("icon", ctx_r11.faGripLines);
  }
}
function MarkdownEditorComponent_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275elementStart(1, "div", 10);
    i07.\u0275\u0275text(2, "\n                    ");
    i07.\u0275\u0275elementStart(3, "jhi-ace-editor", 11, 12);
    i07.\u0275\u0275listener("textChange", function MarkdownEditorComponent_ng_template_10_Template_jhi_ace_editor_textChange_3_listener($event) {
      i07.\u0275\u0275restoreView(_r15);
      const ctx_r14 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r14.markdownTextChange($event));
    })("textChanged", function MarkdownEditorComponent_ng_template_10_Template_jhi_ace_editor_textChanged_3_listener($event) {
      i07.\u0275\u0275restoreView(_r15);
      const ctx_r16 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r16.editorContentString = $event);
    })("dragover", function MarkdownEditorComponent_ng_template_10_Template_jhi_ace_editor_dragover_3_listener($event) {
      i07.\u0275\u0275restoreView(_r15);
      const ctx_r17 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r17.enableFileUpload ? $event.preventDefault() : "");
    })("drop", function MarkdownEditorComponent_ng_template_10_Template_jhi_ace_editor_drop_3_listener($event) {
      i07.\u0275\u0275restoreView(_r15);
      const ctx_r18 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r18.enableFileUpload ? ctx_r18.onFileDrop($event) : "");
    })("paste", function MarkdownEditorComponent_ng_template_10_Template_jhi_ace_editor_paste_3_listener($event) {
      i07.\u0275\u0275restoreView(_r15);
      const ctx_r19 = i07.\u0275\u0275nextContext();
      return i07.\u0275\u0275resetView(ctx_r19.enableFileUpload ? ctx_r19.onFilePaste($event) : "");
    });
    i07.\u0275\u0275text(5, "\n                    ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n                    ");
    i07.\u0275\u0275text(7, "\n                    ");
    i07.\u0275\u0275template(8, MarkdownEditorComponent_ng_template_10_Conditional_8_Template, 19, 8);
    i07.\u0275\u0275text(9, "\n                    ");
    i07.\u0275\u0275template(10, MarkdownEditorComponent_ng_template_10_Conditional_10_Template, 4, 1);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(11, "\n            ");
  }
  if (rf & 2) {
    const ctx_r3 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("ngStyle", i07.\u0275\u0275pureFunction1(9, _c2, ctx_r3.minHeightEditor))("id", ctx_r3.uniqueMarkdownEditorId);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275classProp("file-input", ctx_r3.enableFileUpload);
    i07.\u0275\u0275property("mode", ctx_r3.aceEditorOptions.mode)("autoUpdateContent", ctx_r3.aceEditorOptions.autoUpdateContent)("text", ctx_r3.markdown || "");
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275conditional(8, ctx_r3.enableFileUpload ? 8 : -1);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275conditional(10, ctx_r3.enableResize ? 10 : -1);
  }
}
function MarkdownEditorComponent_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275elementStart(1, "a", 9);
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275pipe(3, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(3, 1, "entity.action.visual"));
  }
}
function MarkdownEditorComponent_ng_template_17_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275projection(1);
    i07.\u0275\u0275text(2, "\n            ");
  }
}
function MarkdownEditorComponent_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275elementStart(1, "a", 9);
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275pipe(3, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(4, "\n            ");
  }
  if (rf & 2) {
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(3, 1, "entity.action.preview"));
  }
}
function MarkdownEditorComponent_ng_template_24_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                    ");
    i07.\u0275\u0275elementStart(1, "div", 20);
    i07.\u0275\u0275text(2, "Preview");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                ");
  }
  if (rf & 2) {
    const ctx_r20 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("innerHTML", ctx_r20.previewTextAsHtml, i07.\u0275\u0275sanitizeHtml)("ngStyle", i07.\u0275\u0275pureFunction1(2, _c2, 0.75 * ctx_r20.minHeightEditor));
  }
}
function MarkdownEditorComponent_ng_template_24_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                ");
    i07.\u0275\u0275projection(1, 1);
    i07.\u0275\u0275text(2, "\n                ");
    i07.\u0275\u0275template(3, MarkdownEditorComponent_ng_template_24_Conditional_3_Template, 4, 4);
  }
  if (rf & 2) {
    const ctx_r7 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275conditional(3, ctx_r7.showDefaultPreview ? 3 : -1);
  }
}
function MarkdownEditorComponent_Conditional_28_For_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                            ");
    i07.\u0275\u0275elementStart(1, "button", 25);
    i07.\u0275\u0275listener("click", function MarkdownEditorComponent_Conditional_28_For_9_Template_button_click_1_listener() {
      const restoredCtx = i07.\u0275\u0275restoreView(_r34);
      const command_r28 = restoredCtx.$implicit;
      return i07.\u0275\u0275resetView(command_r28.execute());
    });
    i07.\u0275\u0275pipe(2, "artemisTranslate");
    i07.\u0275\u0275text(3, "\n                                ");
    i07.\u0275\u0275element(4, "fa-icon", 26);
    i07.\u0275\u0275text(5, "\n                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n                        ");
  }
  if (rf & 2) {
    const command_r28 = ctx.$implicit;
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("ngbTooltip", i07.\u0275\u0275pipeBind1(2, 2, command_r28.buttonTranslationString));
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275property("icon", command_r28.buttonIcon);
  }
}
function MarkdownEditorComponent_Conditional_28_Conditional_12_For_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r42 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                                        ");
    i07.\u0275\u0275elementStart(1, "button", 30);
    i07.\u0275\u0275listener("click", function MarkdownEditorComponent_Conditional_28_Conditional_12_For_10_Template_button_click_1_listener() {
      const restoredCtx = i07.\u0275\u0275restoreView(_r42);
      const command_r36 = restoredCtx.$implicit;
      return i07.\u0275\u0275resetView(command_r36.execute());
    });
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275pipe(3, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(4, "\n                                    ");
  }
  if (rf & 2) {
    const command_r36 = ctx.$implicit;
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate1("\n                                            ", i07.\u0275\u0275pipeBind1(3, 1, command_r36.buttonTranslationString), "\n                                        ");
  }
}
function MarkdownEditorComponent_Conditional_28_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                            ");
    i07.\u0275\u0275elementStart(1, "div", 27);
    i07.\u0275\u0275text(2, "\n                                ");
    i07.\u0275\u0275elementStart(3, "button", 28);
    i07.\u0275\u0275text(4);
    i07.\u0275\u0275pipe(5, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n                                ");
    i07.\u0275\u0275elementStart(7, "div", 29);
    i07.\u0275\u0275text(8, "\n                                    ");
    i07.\u0275\u0275repeaterCreate(9, MarkdownEditorComponent_Conditional_28_Conditional_12_For_10_Template, 5, 3, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(11, "\n                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(12, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r22 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275textInterpolate1("\n                                    ", i07.\u0275\u0275pipeBind1(5, 1, "artemisApp.multipleChoiceQuestion.editor.style"), "\n                                ");
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275repeater(ctx_r22.headerCommands);
  }
}
function MarkdownEditorComponent_Conditional_28_For_14_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                            ");
    i07.\u0275\u0275element(1, "jhi-select-with-search", 31);
    i07.\u0275\u0275text(2, "\n                        ");
  }
  if (rf & 2) {
    const command_r43 = ctx.$implicit;
    const ctx_r23 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("command", command_r43)("editorContentString", ctx_r23.editorContentString);
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                        ");
    i07.\u0275\u0275elementStart(1, "button", 38);
    i07.\u0275\u0275text(2, "No items available");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                                    ");
  }
  if (rf & 2) {
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("disabled", true);
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_For_17_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r67 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                                            ");
    i07.\u0275\u0275elementStart(1, "button", 39);
    i07.\u0275\u0275listener("click", function MarkdownEditorComponent_Conditional_28_For_17_For_17_Conditional_1_Template_button_click_1_listener() {
      i07.\u0275\u0275restoreView(_r67);
      const item_r59 = i07.\u0275\u0275nextContext().$implicit;
      const command_r48 = i07.\u0275\u0275nextContext().$implicit;
      return i07.\u0275\u0275resetView(command_r48.execute(item_r59.id, item_r59.type));
    });
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                                        ");
  }
  if (rf & 2) {
    const item_r59 = i07.\u0275\u0275nextContext().$implicit;
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate(item_r59.value);
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_For_17_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                        ");
    i07.\u0275\u0275template(1, MarkdownEditorComponent_Conditional_28_For_17_For_17_Conditional_1_Template, 4, 1);
  }
  if (rf & 2) {
    const item_r59 = ctx.$implicit;
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(1, item_r59.type !== "LECTURE" ? 1 : -1);
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                        ");
    i07.\u0275\u0275elementStart(1, "button", 38);
    i07.\u0275\u0275text(2, "No items available");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                                    ");
  }
  if (rf & 2) {
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("disabled", true);
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_For_24_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                            ");
    i07.\u0275\u0275elementStart(1, "button", 41);
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                                        ");
  }
  if (rf & 2) {
    const lecture_r70 = i07.\u0275\u0275nextContext().$implicit;
    const _r76 = i07.\u0275\u0275reference(3);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("matMenuTriggerFor", _r76);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275textInterpolate1("\n                                                ", lecture_r70.value, "\n                                            ");
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_For_24_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r83 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                                                ");
    i07.\u0275\u0275elementStart(1, "button", 42);
    i07.\u0275\u0275listener("click", function MarkdownEditorComponent_Conditional_28_For_17_For_24_Conditional_5_Template_button_click_1_listener() {
      i07.\u0275\u0275restoreView(_r83);
      const lecture_r70 = i07.\u0275\u0275nextContext().$implicit;
      const command_r48 = i07.\u0275\u0275nextContext().$implicit;
      return i07.\u0275\u0275resetView(command_r48.execute(lecture_r70.id, lecture_r70.type));
    });
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                                            ");
  }
  if (rf & 2) {
    const lecture_r70 = i07.\u0275\u0275nextContext().$implicit;
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate1("\n                                                    ", lecture_r70.value, "\n                                                ");
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_For_24_For_7_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                                    ");
    i07.\u0275\u0275elementStart(1, "button", 41);
    i07.\u0275\u0275text(2, "\n                                                        ");
    i07.\u0275\u0275elementStart(3, "span");
    i07.\u0275\u0275text(4);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(5, "\n                                                    ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n                                                ");
  }
  if (rf & 2) {
    const unit_r86 = i07.\u0275\u0275nextContext().$implicit;
    const _r92 = i07.\u0275\u0275reference(3);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("matMenuTriggerFor", _r92);
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275textInterpolate(unit_r86.value);
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_For_24_For_7_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                                        ");
    i07.\u0275\u0275elementStart(1, "button", 38);
    i07.\u0275\u0275text(2, "No items available");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                                                    ");
  }
  if (rf & 2) {
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("disabled", true);
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_For_24_For_7_For_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r103 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                                                        ");
    i07.\u0275\u0275elementStart(1, "button", 39);
    i07.\u0275\u0275listener("click", function MarkdownEditorComponent_Conditional_28_For_17_For_24_For_7_For_10_Template_button_click_1_listener() {
      const restoredCtx = i07.\u0275\u0275restoreView(_r103);
      const slide_r96 = restoredCtx.$implicit;
      const unit_r86 = i07.\u0275\u0275nextContext().$implicit;
      const lecture_r70 = i07.\u0275\u0275nextContext().$implicit;
      const command_r48 = i07.\u0275\u0275nextContext().$implicit;
      return i07.\u0275\u0275resetView(command_r48.execute(lecture_r70.id, lecture_r70.type, void 0, unit_r86.id, slide_r96.id));
    });
    i07.\u0275\u0275text(2, "\n                                                            ");
    i07.\u0275\u0275elementStart(3, "span");
    i07.\u0275\u0275text(4);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(5, "\n                                                        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n                                                    ");
  }
  if (rf & 2) {
    const slide_r96 = ctx.$implicit;
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275textInterpolate1("Slide ", slide_r96.slideNumber, "");
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_For_24_For_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r108 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                                                ");
    i07.\u0275\u0275template(1, MarkdownEditorComponent_Conditional_28_For_17_For_24_For_7_Conditional_1_Template, 7, 2);
    i07.\u0275\u0275elementStart(2, "mat-menu", 35, 43);
    i07.\u0275\u0275text(4, "\n                                                    ");
    i07.\u0275\u0275elementStart(5, "button", 42);
    i07.\u0275\u0275listener("click", function MarkdownEditorComponent_Conditional_28_For_17_For_24_For_7_Template_button_click_5_listener() {
      const restoredCtx = i07.\u0275\u0275restoreView(_r108);
      const unit_r86 = restoredCtx.$implicit;
      const lecture_r70 = i07.\u0275\u0275nextContext().$implicit;
      const command_r48 = i07.\u0275\u0275nextContext().$implicit;
      return i07.\u0275\u0275resetView(command_r48.execute(lecture_r70.id, lecture_r70.type, void 0, unit_r86.id));
    });
    i07.\u0275\u0275text(6);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(7, "\n                                                    ");
    i07.\u0275\u0275template(8, MarkdownEditorComponent_Conditional_28_For_17_For_24_For_7_Conditional_8_Template, 4, 1);
    i07.\u0275\u0275repeaterCreate(9, MarkdownEditorComponent_Conditional_28_For_17_For_24_For_7_For_10_Template, 7, 1, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(11, "\n                                            ");
  }
  if (rf & 2) {
    const unit_r86 = ctx.$implicit;
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(1, unit_r86.courseArtifactType === "ATTACHMENT_UNITS" ? 1 : -1);
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275textInterpolate1("\n                                                        ", unit_r86.value, "\n                                                    ");
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275conditional(8, !unit_r86.slides || unit_r86.slides.length === 0 ? 8 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275repeater(unit_r86.slides);
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_For_24_For_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r117 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                                                ");
    i07.\u0275\u0275elementStart(1, "button", 39);
    i07.\u0275\u0275listener("click", function MarkdownEditorComponent_Conditional_28_For_17_For_24_For_9_Template_button_click_1_listener() {
      const restoredCtx = i07.\u0275\u0275restoreView(_r117);
      const attachment_r110 = restoredCtx.$implicit;
      const lecture_r70 = i07.\u0275\u0275nextContext().$implicit;
      const command_r48 = i07.\u0275\u0275nextContext().$implicit;
      return i07.\u0275\u0275resetView(command_r48.execute(lecture_r70.id, attachment_r110.type, attachment_r110.id));
    });
    i07.\u0275\u0275text(2, "\n                                                    ");
    i07.\u0275\u0275elementStart(3, "span");
    i07.\u0275\u0275text(4);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(5, "\n                                                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n                                            ");
  }
  if (rf & 2) {
    const attachment_r110 = ctx.$implicit;
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275textInterpolate(attachment_r110.value);
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_For_24_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                        ");
    i07.\u0275\u0275template(1, MarkdownEditorComponent_Conditional_28_For_17_For_24_Conditional_1_Template, 4, 2);
    i07.\u0275\u0275elementStart(2, "mat-menu", 35, 40);
    i07.\u0275\u0275text(4, "\n                                            ");
    i07.\u0275\u0275template(5, MarkdownEditorComponent_Conditional_28_For_17_For_24_Conditional_5_Template, 4, 1);
    i07.\u0275\u0275repeaterCreate(6, MarkdownEditorComponent_Conditional_28_For_17_For_24_For_7_Template, 12, 3, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275repeaterCreate(8, MarkdownEditorComponent_Conditional_28_For_17_For_24_For_9_Template, 7, 1, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(10, "\n                                    ");
  }
  if (rf & 2) {
    const lecture_r70 = ctx.$implicit;
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(1, lecture_r70.type === "LECTURE" ? 1 : -1);
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275conditional(5, lecture_r70.type === "LECTURE" ? 5 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275repeater(lecture_r70.attachmentUnits);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275repeater(lecture_r70.elements);
  }
}
function MarkdownEditorComponent_Conditional_28_For_17_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                            ");
    i07.\u0275\u0275elementStart(1, "div");
    i07.\u0275\u0275text(2, "\n                                ");
    i07.\u0275\u0275elementStart(3, "button", 32);
    i07.\u0275\u0275text(4, "\n                                    ");
    i07.\u0275\u0275elementStart(5, "span", 33);
    i07.\u0275\u0275text(6);
    i07.\u0275\u0275pipe(7, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(8, "\n                                    ");
    i07.\u0275\u0275element(9, "fa-icon", 34);
    i07.\u0275\u0275text(10, "\n                                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(11, "\n                                ");
    i07.\u0275\u0275elementStart(12, "mat-menu", 35, 36);
    i07.\u0275\u0275text(14, "\n                                    ");
    i07.\u0275\u0275template(15, MarkdownEditorComponent_Conditional_28_For_17_Conditional_15_Template, 4, 1);
    i07.\u0275\u0275repeaterCreate(16, MarkdownEditorComponent_Conditional_28_For_17_For_17_Template, 2, 1, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(18, "\n                                ");
    i07.\u0275\u0275elementStart(19, "mat-menu", 35, 37);
    i07.\u0275\u0275text(21, "\n                                    ");
    i07.\u0275\u0275template(22, MarkdownEditorComponent_Conditional_28_For_17_Conditional_22_Template, 4, 1);
    i07.\u0275\u0275repeaterCreate(23, MarkdownEditorComponent_Conditional_28_For_17_For_24_Template, 11, 2, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(25, "\n                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(26, "\n                        ");
  }
  if (rf & 2) {
    const command_r48 = ctx.$implicit;
    const _r53 = i07.\u0275\u0275reference(13);
    const _r56 = i07.\u0275\u0275reference(20);
    const ctx_r24 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275property("matMenuTriggerFor", ctx_r24.isTypeOfExerciseReferenceCommand(command_r48) ? _r53 : _r56);
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(7, 5, command_r48.buttonTranslationString));
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275property("icon", ctx_r24.faAngleDown);
    i07.\u0275\u0275advance(6);
    i07.\u0275\u0275conditional(15, !command_r48.getValues() || command_r48.getValues().length === 0 ? 15 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275repeater(command_r48.getValues());
    i07.\u0275\u0275advance(6);
    i07.\u0275\u0275conditional(22, !command_r48.getValues() || command_r48.getValues().length === 0 ? 22 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275repeater(command_r48.getValues());
  }
}
function MarkdownEditorComponent_Conditional_28_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    const _r120 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                            ");
    i07.\u0275\u0275elementStart(1, "div", 44);
    i07.\u0275\u0275text(2, "\n                                ");
    i07.\u0275\u0275elementStart(3, "div", 45);
    i07.\u0275\u0275listener("click", function MarkdownEditorComponent_Conditional_28_Conditional_21_Template_div_click_3_listener($event) {
      i07.\u0275\u0275restoreView(_r120);
      const ctx_r119 = i07.\u0275\u0275nextContext(2);
      return i07.\u0275\u0275resetView(ctx_r119.openColorSelector($event));
    });
    i07.\u0275\u0275text(4);
    i07.\u0275\u0275pipe(5, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n                                ");
    i07.\u0275\u0275elementStart(7, "jhi-color-selector", 46);
    i07.\u0275\u0275listener("selectedColor", function MarkdownEditorComponent_Conditional_28_Conditional_21_Template_jhi_color_selector_selectedColor_7_listener($event) {
      i07.\u0275\u0275restoreView(_r120);
      const ctx_r121 = i07.\u0275\u0275nextContext(2);
      return i07.\u0275\u0275resetView(ctx_r121.onSelectedColor($event));
    });
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(8, "\n                            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(9, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r25 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275textInterpolate(i07.\u0275\u0275pipeBind1(5, 2, "artemisApp.markdownEditor.color"));
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275property("tagColors", ctx_r25.markdownColors);
  }
}
function MarkdownEditorComponent_Conditional_28_Conditional_23_For_4_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r132 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                                        ");
    i07.\u0275\u0275elementStart(1, "div", 48);
    i07.\u0275\u0275listener("click", function MarkdownEditorComponent_Conditional_28_Conditional_23_For_4_Conditional_1_Template_div_click_1_listener() {
      i07.\u0275\u0275restoreView(_r132);
      const command_r124 = i07.\u0275\u0275nextContext().$implicit;
      return i07.\u0275\u0275resetView(command_r124.execute());
    });
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275pipe(3, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(4, "\n                                    ");
  }
  if (rf & 2) {
    const command_r124 = i07.\u0275\u0275nextContext().$implicit;
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate1("\n                                            ", i07.\u0275\u0275pipeBind1(3, 1, command_r124.buttonTranslationString), "\n                                        ");
  }
}
function MarkdownEditorComponent_Conditional_28_Conditional_23_For_4_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                    ");
    i07.\u0275\u0275template(1, MarkdownEditorComponent_Conditional_28_Conditional_23_For_4_Conditional_1_Template, 5, 3);
  }
  if (rf & 2) {
    const command_r124 = ctx.$implicit;
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275conditional(1, command_r124.displayCommandButton ? 1 : -1);
  }
}
function MarkdownEditorComponent_Conditional_28_Conditional_23_For_7_For_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r147 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                                                ");
    i07.\u0275\u0275elementStart(1, "button", 52);
    i07.\u0275\u0275listener("click", function MarkdownEditorComponent_Conditional_28_Conditional_23_For_7_For_10_Template_button_click_1_listener() {
      const restoredCtx = i07.\u0275\u0275restoreView(_r147);
      const item_r141 = restoredCtx.$implicit;
      const command_r134 = i07.\u0275\u0275nextContext().$implicit;
      return i07.\u0275\u0275resetView(command_r134.execute(item_r141.id));
    });
    i07.\u0275\u0275text(2);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                                            ");
  }
  if (rf & 2) {
    const item_r141 = ctx.$implicit;
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate1("\n                                                    ", item_r141.value, "\n                                                ");
  }
}
function MarkdownEditorComponent_Conditional_28_Conditional_23_For_7_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                                ");
    i07.\u0275\u0275elementStart(1, "button", 53);
    i07.\u0275\u0275text(2, "No items available");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(3, "\n                                            ");
  }
  if (rf & 2) {
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("disabled", true);
  }
}
function MarkdownEditorComponent_Conditional_28_Conditional_23_For_7_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                                    ");
    i07.\u0275\u0275elementStart(1, "div", 49);
    i07.\u0275\u0275text(2, "\n                                        ");
    i07.\u0275\u0275elementStart(3, "button", 50);
    i07.\u0275\u0275text(4);
    i07.\u0275\u0275pipe(5, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n                                        ");
    i07.\u0275\u0275elementStart(7, "div", 51);
    i07.\u0275\u0275text(8, "\n                                            ");
    i07.\u0275\u0275repeaterCreate(9, MarkdownEditorComponent_Conditional_28_Conditional_23_For_7_For_10_Template, 4, 1, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275template(11, MarkdownEditorComponent_Conditional_28_Conditional_23_For_7_Conditional_11_Template, 4, 1);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(12, "\n                                    ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(13, "\n                                ");
  }
  if (rf & 2) {
    const command_r134 = ctx.$implicit;
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275textInterpolate1("\n                                            ", i07.\u0275\u0275pipeBind1(5, 2, command_r134.buttonTranslationString), "\n                                        ");
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275repeater(command_r134.getValues());
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275conditional(11, !command_r134.getValues().length ? 11 : -1);
  }
}
function MarkdownEditorComponent_Conditional_28_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n                            ");
    i07.\u0275\u0275elementStart(1, "div", 47);
    i07.\u0275\u0275text(2, "\n                                ");
    i07.\u0275\u0275repeaterCreate(3, MarkdownEditorComponent_Conditional_28_Conditional_23_For_4_Template, 2, 1, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275pipe(5, "typeCheck");
    i07.\u0275\u0275repeaterCreate(6, MarkdownEditorComponent_Conditional_28_Conditional_23_For_7_Template, 14, 4, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275pipe(8, "typeCheck");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(9, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r26 = i07.\u0275\u0275nextContext(2);
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275repeater(i07.\u0275\u0275pipeBind2(5, 0, ctx_r26.domainCommands, ctx_r26.DomainTagCommand));
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275repeater(i07.\u0275\u0275pipeBind2(8, 3, ctx_r26.domainCommands, ctx_r26.DomainMultiOptionCommand));
  }
}
function MarkdownEditorComponent_Conditional_28_For_27_Template(rf, ctx) {
  if (rf & 1) {
    const _r155 = i07.\u0275\u0275getCurrentView();
    i07.\u0275\u0275text(0, "\n                                ");
    i07.\u0275\u0275elementStart(1, "button", 54);
    i07.\u0275\u0275listener("click", function MarkdownEditorComponent_Conditional_28_For_27_Template_button_click_1_listener() {
      const restoredCtx = i07.\u0275\u0275restoreView(_r155);
      const command_r149 = restoredCtx.$implicit;
      return i07.\u0275\u0275resetView(command_r149.execute());
    });
    i07.\u0275\u0275pipe(2, "artemisTranslate");
    i07.\u0275\u0275text(3, "\n                                    ");
    i07.\u0275\u0275element(4, "fa-icon", 26);
    i07.\u0275\u0275text(5, "\n                                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n                            ");
  }
  if (rf & 2) {
    const command_r149 = ctx.$implicit;
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275property("ngbTooltip", i07.\u0275\u0275pipeBind1(2, 2, command_r149.buttonTranslationString));
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275property("icon", command_r149.buttonIcon);
  }
}
function MarkdownEditorComponent_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n            ");
    i07.\u0275\u0275elementContainerStart(1, 21);
    i07.\u0275\u0275text(2, "\n                ");
    i07.\u0275\u0275elementStart(3, "div", 22);
    i07.\u0275\u0275text(4, "\n                    ");
    i07.\u0275\u0275elementStart(5, "div", 23);
    i07.\u0275\u0275text(6, "\n                        ");
    i07.\u0275\u0275text(7, "\n                        ");
    i07.\u0275\u0275repeaterCreate(8, MarkdownEditorComponent_Conditional_28_For_9_Template, 7, 4, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275pipe(10, "negatedTypeCheck");
    i07.\u0275\u0275text(11, "\n                        ");
    i07.\u0275\u0275template(12, MarkdownEditorComponent_Conditional_28_Conditional_12_Template, 13, 3);
    i07.\u0275\u0275repeaterCreate(13, MarkdownEditorComponent_Conditional_28_For_14_Template, 3, 2, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275pipe(15, "typeCheck");
    i07.\u0275\u0275repeaterCreate(16, MarkdownEditorComponent_Conditional_28_For_17_Template, 27, 7, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275pipe(18, "negatedTypeCheck");
    i07.\u0275\u0275pipe(19, "typeCheck");
    i07.\u0275\u0275text(20, "\n                        ");
    i07.\u0275\u0275template(21, MarkdownEditorComponent_Conditional_28_Conditional_21_Template, 10, 4);
    i07.\u0275\u0275text(22, "\n                        ");
    i07.\u0275\u0275template(23, MarkdownEditorComponent_Conditional_28_Conditional_23_Template, 10, 6);
    i07.\u0275\u0275elementStart(24, "div", 24);
    i07.\u0275\u0275text(25, "\n                            ");
    i07.\u0275\u0275repeaterCreate(26, MarkdownEditorComponent_Conditional_28_For_27_Template, 7, 4, null, null, i07.\u0275\u0275repeaterTrackByIdentity);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(28, "\n                    ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(29, "\n                ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(30, "\n            ");
    i07.\u0275\u0275elementContainerEnd();
    i07.\u0275\u0275text(31, "\n        ");
  }
  if (rf & 2) {
    const ctx_r8 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(8);
    i07.\u0275\u0275repeater(i07.\u0275\u0275pipeBind2(10, 3, ctx_r8.defaultCommands, ctx_r8.MultiOptionCommand));
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275conditional(12, ctx_r8.headerCommands.length > 0 ? 12 : -1);
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275repeater(i07.\u0275\u0275pipeBind2(15, 6, ctx_r8.defaultCommands, ctx_r8.InteractiveSearchCommand));
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275repeater(i07.\u0275\u0275pipeBind2(18, 9, i07.\u0275\u0275pipeBind2(19, 12, ctx_r8.defaultCommands, ctx_r8.MultiOptionCommand), ctx_r8.InteractiveSearchCommand));
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275conditional(21, ctx_r8.colorCommands.length > 0 ? 21 : -1);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275conditional(23, ctx_r8.domainCommands && ctx_r8.domainCommands.length != 0 ? 23 : -1);
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275repeater(ctx_r8.metaCommands);
  }
}
var _c03, _c12, _c2, _c3, _c4, MarkdownEditorHeight, EditorMode, getAceMode, MarkdownEditorComponent;
var init_markdown_editor_component = __esm({
  "src/main/webapp/app/shared/markdown-editor/markdown-editor.component.ts"() {
    init_ace_editor_component();
    init_markdown_service();
    init_file_uploader_service();
    init_alert_service();
    init_color_selector_component();
    init_domainTag_command();
    init_global_utils();
    init_underline_command();
    init_colorPicker_command();
    init_bold_command();
    init_attachmentCommand();
    init_reference_command();
    init_domainMultiOptionCommand();
    init_fullscreen_command();
    init_headingOne_command();
    init_italic_command();
    init_orderedListCommand();
    init_headingTwo_command();
    init_link_command();
    init_code_command();
    init_unorderedListCommand();
    init_headingThree_command();
    init_codeblock_command();
    init_multiOptionCommand();
    init_multiple_choice_visual_question_component();
    init_exerciseReferenceCommand();
    init_interactiveSearchCommand();
    init_markdown_service();
    init_file_uploader_service();
    init_alert_service();
    init_translate_directive();
    init_ace_editor_component();
    init_color_selector_component();
    init_select_with_search_component();
    init_artemis_translate_pipe();
    init_type_check_pipe();
    init_negated_type_check_pipe();
    _c03 = ["wrapper"];
    _c12 = ["aceEditor"];
    _c2 = (a0) => ({ "minHeight.px": a0 });
    _c3 = [[["", "id", "visual"]], [["", "id", "preview"]]];
    _c4 = ["[#visual]", "[#preview]"];
    (function(MarkdownEditorHeight2) {
      MarkdownEditorHeight2[MarkdownEditorHeight2["INLINE"] = 100] = "INLINE";
      MarkdownEditorHeight2[MarkdownEditorHeight2["SMALL"] = 200] = "SMALL";
      MarkdownEditorHeight2[MarkdownEditorHeight2["MEDIUM"] = 500] = "MEDIUM";
      MarkdownEditorHeight2[MarkdownEditorHeight2["LARGE"] = 1e3] = "LARGE";
      MarkdownEditorHeight2[MarkdownEditorHeight2["EXTRA_LARGE"] = 1500] = "EXTRA_LARGE";
    })(MarkdownEditorHeight || (MarkdownEditorHeight = {}));
    (function(EditorMode2) {
      EditorMode2["NONE"] = "none";
      EditorMode2["LATEX"] = "latex";
    })(EditorMode || (EditorMode = {}));
    getAceMode = (mode) => {
      switch (mode) {
        case EditorMode.LATEX:
          return "ace/mode/latex";
        case EditorMode.NONE:
          return null;
        default:
          return null;
      }
    };
    MarkdownEditorComponent = class _MarkdownEditorComponent {
      artemisMarkdown;
      fileUploaderService;
      alertService;
      MultiOptionCommand = MultiOptionCommand;
      DomainMultiOptionCommand = DomainMultiOptionCommand;
      DomainTagCommand = DomainTagCommand;
      InteractiveSearchCommand = InteractiveSearchCommand;
      wrapper;
      aceEditorContainer;
      aceEditorOptions = {
        autoUpdateContent: true,
        mode: "markdown"
      };
      colorSelector;
      markdown;
      editorMode = EditorMode.NONE;
      showLineNumbers = false;
      markdownChange = new EventEmitter4();
      html = new EventEmitter4();
      markdownColors = ["#ca2024", "#3ea119", "#ffffff", "#000000", "#fffa5c", "#0d3cc2", "#b05db8", "#d86b1f"];
      selectedColor = "#000000";
      colorCommands = [new ColorPickerCommand()];
      metaCommands = [new FullscreenCommand()];
      defaultCommands = [
        new BoldCommand(),
        new ItalicCommand(),
        new UnderlineCommand(),
        new ReferenceCommand(),
        new CodeCommand(),
        new CodeBlockCommand(),
        new LinkCommand(),
        new AttachmentCommand(),
        new OrderedListCommand(),
        new UnorderedListCommand()
      ];
      headerCommands = [new HeadingOneCommand(), new HeadingTwoCommand(), new HeadingThreeCommand()];
      domainCommands;
      textWithDomainCommandsFound = new EventEmitter4();
      onPreviewSelect = new EventEmitter4();
      onEditSelect = new EventEmitter4();
      showPreviewButton = true;
      showDefaultPreview = true;
      showEditButton = true;
      showVisualModeButton = false;
      previewTextAsHtml;
      previewMode = false;
      visualMode = false;
      minHeightEditor = MarkdownEditorHeight.SMALL.valueOf();
      visualChild;
      enableResize = true;
      resizableMaxHeight = MarkdownEditorHeight.LARGE;
      resizableMinHeight = MarkdownEditorHeight.SMALL;
      interactResizable;
      enableFileUpload = true;
      faQuestionCircle = faQuestionCircle2;
      faGripLines = faGripLines;
      faAngleRight = faAngleRight;
      faAngleDown = faAngleDown;
      uniqueMarkdownEditorId;
      editorContentString;
      constructor(artemisMarkdown, fileUploaderService, alertService) {
        this.artemisMarkdown = artemisMarkdown;
        this.fileUploaderService = fileUploaderService;
        this.alertService = alertService;
        this.uniqueMarkdownEditorId = "markdown-editor-" + uuid();
      }
      openColorSelector(event) {
        const marginTop = 35;
        const height = 110;
        this.colorSelector.openColorSelector(event, marginTop, height);
      }
      onSelectedColor(selectedColor) {
        this.selectedColor = selectedColor;
        this.colorCommands[0].execute(selectedColor);
      }
      addCommand(command) {
        this.defaultCommands.push(command);
      }
      removeCommand(classRef) {
        setTimeout(() => this.defaultCommands = this.defaultCommands.filter((element) => !(element instanceof classRef)));
      }
      isTypeOfExerciseReferenceCommand(commandToCheck) {
        return commandToCheck instanceof ExerciseReferenceCommand;
      }
      ngAfterViewInit() {
        this.aceEditorContainer.getEditor().setOptions({
          enableBasicAutocompletion: true,
          enableLiveAutocompletion: true
        });
        this.aceEditorContainer.getEditor().completers = [];
        if (this.domainCommands == void 0 || this.domainCommands.length === 0) {
          [...this.defaultCommands, ...this.colorCommands, ...this.headerCommands || [], ...this.metaCommands].forEach((command) => {
            command.setEditor(this.aceEditorContainer.getEditor());
            command.setMarkdownWrapper(this.wrapper);
          });
        } else {
          [...this.defaultCommands, ...this.domainCommands, ...this.colorCommands, ...this.headerCommands || [], ...this.metaCommands].forEach((command) => {
            command.setEditor(this.aceEditorContainer.getEditor());
            command.setMarkdownWrapper(this.wrapper);
          });
        }
        this.setupMarkdownEditor();
        const selectedAceMode = getAceMode(this.editorMode);
        if (selectedAceMode) {
          this.aceEditorContainer.getEditor().getSession().setMode(selectedAceMode);
        }
        if (this.enableResize) {
          this.setupResizable();
        }
      }
      setupMarkdownEditor() {
        this.aceEditorContainer.getEditor().renderer.setShowGutter(this.showLineNumbers);
        this.aceEditorContainer.getEditor().renderer.setPadding(10);
        this.aceEditorContainer.getEditor().renderer.setScrollMargin(8, 8);
        this.aceEditorContainer.getEditor().setHighlightActiveLine(false);
        this.aceEditorContainer.getEditor().setShowPrintMargin(false);
        this.aceEditorContainer.getEditor().clearSelection();
        this.aceEditorContainer.getEditor().setAutoScrollEditorIntoView(true);
        this.aceEditorContainer.getEditor().setOptions({ wrap: true });
      }
      setupResizable() {
        const selector = "#" + this.uniqueMarkdownEditorId;
        interact(selector).unset();
        this.interactResizable = interact(selector).resizable({
          edges: { left: false, right: false, bottom: ".rg-bottom", top: false },
          modifiers: [
            interact.modifiers.restrictSize({
              min: { width: 0, height: this.resizableMinHeight },
              max: { width: 2e3, height: this.resizableMaxHeight }
            })
          ],
          inertia: true
        }).on("resizestart", function(event) {
          event.target.classList.add("card-resizable");
        }).on("resizeend", (event) => {
          event.target.classList.remove("card-resizable");
        }).on("resizemove", (event) => {
          const target = event.target;
          target.style.height = event.rect.height + "px";
          this.aceEditorContainer.getEditor().resize();
        });
      }
      parse() {
        if (this.showDefaultPreview) {
          this.previewTextAsHtml = this.artemisMarkdown.safeHtmlForMarkdown(this.markdown);
          this.html.emit(this.previewTextAsHtml);
        }
        if (this.domainCommands && this.domainCommands.length && this.markdown) {
          const domainCommandIdentifiersToParse = this.domainCommands.map((command) => command.getOpeningIdentifier());
          const commandTextsMappedToCommandIdentifiers = [];
          let remainingMarkdownText = this.markdown.slice(0);
          const commandIdentifiersString = domainCommandIdentifiersToParse.map((tag) => tag.replace("[", "").replace("]", "")).map(escapeStringForUseInRegex).join("|");
          const regex = new RegExp(`(?=\\[(${commandIdentifiersString})\\])`, "gmi");
          while (remainingMarkdownText.length) {
            const [textWithCommandIdentifier] = remainingMarkdownText.split(regex, 1);
            remainingMarkdownText = remainingMarkdownText.substring(textWithCommandIdentifier.length);
            const commandTextWithCommandIdentifier = this.parseLineForDomainCommand(textWithCommandIdentifier.trim());
            commandTextsMappedToCommandIdentifiers.push(commandTextWithCommandIdentifier);
          }
          this.textWithDomainCommandsFound.emit(commandTextsMappedToCommandIdentifiers);
        }
      }
      parseLineForDomainCommand = (text) => {
        for (const domainCommand of this.domainCommands) {
          const possibleOpeningCommandIdentifier = [
            domainCommand.getOpeningIdentifier(),
            domainCommand.getOpeningIdentifier().toLowerCase(),
            domainCommand.getOpeningIdentifier().toUpperCase()
          ];
          if (possibleOpeningCommandIdentifier.some((identifier) => text.indexOf(identifier) !== -1)) {
            const trimmedLineWithoutIdentifier = possibleOpeningCommandIdentifier.reduce((line, identifier) => line.replace(identifier, ""), text).trim();
            return [trimmedLineWithoutIdentifier, domainCommand];
          }
        }
        return [text.trim(), null];
      };
      changeNavigation(event) {
        this.previewMode = event.nextId === "editor_preview";
        this.visualMode = event.nextId === "editor_visual";
        if (this.previewMode) {
          this.onPreviewSelect.emit();
        } else {
          this.onEditSelect.emit();
        }
        if (event.activeId === "editor_visual" && this.visualChild) {
          this.markdown = this.visualChild.parseQuestion();
          if (this.previewMode) {
            this.parse();
          }
        }
        if (event.activeId === "editor_edit") {
          this.parse();
        }
      }
      onFileUpload(event) {
        if (event.target.files.length >= 1) {
          this.embedFiles(Array.from(event.target.files));
        }
      }
      onFileDrop(event) {
        event.preventDefault();
        if (event.dataTransfer?.items) {
          const files = new Array();
          for (let i = 0; i < event.dataTransfer.items.length; i++) {
            if (event.dataTransfer.items[i].kind === "file") {
              const file = event.dataTransfer.items[i].getAsFile();
              if (file) {
                files.push(file);
              }
            }
          }
          this.embedFiles(files);
        } else if (event.dataTransfer?.files) {
          this.embedFiles(Array.from(event.dataTransfer.files));
        }
      }
      onFilePaste(event) {
        if (event.clipboardData?.items) {
          const images = new Array();
          for (let i = 0; i < event.clipboardData.items.length; i++) {
            if (event.clipboardData.items[i].kind === "file") {
              const file = event.clipboardData.items[i].getAsFile();
              if (file) {
                images.push(file);
              }
            }
          }
          this.embedFiles(images);
        }
      }
      embedFiles(files) {
        const aceEditor = this.aceEditorContainer.getEditor();
        files.forEach((file) => {
          this.fileUploaderService.uploadMarkdownFile(file).then((res) => {
            const extension = file.name.split(".").pop().toLocaleLowerCase();
            let textToAdd = `[${file.name}](${res.path})
`;
            if (extension !== "pdf") {
              textToAdd = "!" + textToAdd;
            }
            aceEditor.insert(textToAdd);
          }, (error) => {
            this.alertService.addAlert({
              type: AlertType.DANGER,
              message: error.message,
              disableTranslation: true
            });
          });
        });
      }
      markdownTextChange(value) {
        this.markdown = value;
        this.markdownChange.emit(value);
      }
      static \u0275fac = function MarkdownEditorComponent_Factory(t) {
        return new (t || _MarkdownEditorComponent)(i07.\u0275\u0275directiveInject(ArtemisMarkdownService), i07.\u0275\u0275directiveInject(FileUploaderService), i07.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i07.\u0275\u0275defineComponent({ type: _MarkdownEditorComponent, selectors: [["jhi-markdown-editor"]], contentQueries: function MarkdownEditorComponent_ContentQueries(rf, ctx, dirIndex) {
        if (rf & 1) {
          i07.\u0275\u0275contentQuery(dirIndex, MultipleChoiceVisualQuestionComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i07.\u0275\u0275queryRefresh(_t = i07.\u0275\u0275loadQuery()) && (ctx.visualChild = _t.first);
        }
      }, viewQuery: function MarkdownEditorComponent_Query(rf, ctx) {
        if (rf & 1) {
          i07.\u0275\u0275viewQuery(_c03, 5, ElementRef6);
          i07.\u0275\u0275viewQuery(_c12, 5);
          i07.\u0275\u0275viewQuery(ColorSelectorComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i07.\u0275\u0275queryRefresh(_t = i07.\u0275\u0275loadQuery()) && (ctx.wrapper = _t.first);
          i07.\u0275\u0275queryRefresh(_t = i07.\u0275\u0275loadQuery()) && (ctx.aceEditorContainer = _t.first);
          i07.\u0275\u0275queryRefresh(_t = i07.\u0275\u0275loadQuery()) && (ctx.colorSelector = _t.first);
        }
      }, inputs: { markdown: "markdown", editorMode: "editorMode", showLineNumbers: "showLineNumbers", colorCommands: "colorCommands", metaCommands: "metaCommands", defaultCommands: "defaultCommands", headerCommands: "headerCommands", domainCommands: "domainCommands", showPreviewButton: "showPreviewButton", showDefaultPreview: "showDefaultPreview", showEditButton: "showEditButton", showVisualModeButton: "showVisualModeButton", minHeightEditor: "minHeightEditor", enableResize: "enableResize", resizableMaxHeight: "resizableMaxHeight", resizableMinHeight: "resizableMinHeight", enableFileUpload: "enableFileUpload" }, outputs: { markdownChange: "markdownChange", html: "html", textWithDomainCommandsFound: "textWithDomainCommandsFound", onPreviewSelect: "onPreviewSelect", onEditSelect: "onEditSelect" }, ngContentSelectors: _c4, decls: 33, vars: 6, consts: [[1, "markdown-editor-wrapper"], ["wrapper", ""], ["ngbNav", "", 1, "nav-tabs", 3, "destroyOnHide", "navChange"], ["nav", "ngbNav"], ["ngbNavItem", "editor_edit"], ["ngbNavContent", ""], ["ngbNavItem", "editor_visual"], ["ngbNavItem", "editor_preview"], [3, "ngbNavOutlet"], ["ngbNavLink", "", 1, "btn-sm", "text-normal", "px-2", "py-0", "m-0"], [1, "height-100", "markdown-editor", "d-flex", "flex-column", 3, "ngStyle", "id"], [1, "form-control", "markdown-editor__content", 3, "mode", "autoUpdateContent", "text", "textChange", "textChanged", "dragover", "drop", "paste"], ["aceEditor", ""], ["id", "file-upload", "type", "file", "accept", "image/*", 1, "markdown-editor__file-input", 3, "multiple", "change"], ["for", "file-upload", 1, "markdown-editor__file-label", "d-inline"], [1, "row", "mx-0", "align-items-baseline"], [1, "col", "upload-subtitle"], ["href", "http://demo.showdownjs.com", 1, "col-auto"], [3, "icon", "ngbTooltip"], [1, "rg-bottom", "md-resize-icon", 3, "icon"], [1, "pt-1", "background-editor-high", "markdown-preview", 3, "innerHTML", "ngStyle"], ["ngbNavItem", ""], [1, "markdown-editor__commands"], [1, "markdown-editor__commands-default"], [1, "ms-auto"], ["type", "button", 1, "btn", "btn-sm", "py-0", 3, "ngbTooltip", "click"], [3, "icon"], ["ngbDropdown", "", "role", "group", "aria-label", "Button group with nested dropdown", 1, "btn-group"], ["type", "button", "id", "dropdownBasic1", "ngbDropdownToggle", "", 1, "btn", "btn-sm", "px-2", "py-0"], ["ngbDropdownMenu", "", 1, "dropdown-menu"], ["type", "button", 1, "dropdown-item", 3, "click"], [3, "command", "editorContentString"], ["mat-button", "", "type", "button", 1, "btn", "btn-sm", "m-0", "ml-1", "py-0", 3, "matMenuTriggerFor"], [1, "default-font-size"], [1, "ms-1", 3, "icon"], ["type", "button"], ["subMenuExercise", "matMenu"], ["subMenuLecture", "matMenu"], ["mat-button", "", "jhiTranslate", "global.generic.emptyList", "type", "button", 3, "disabled"], ["mat-menu-item", "", "type", "button", 3, "click"], ["lectureMenuUnits", "matMenu"], ["mat-menu-item", "", "type", "button", 3, "matMenuTriggerFor"], ["mat-menu-item", "", "type", "button", 1, "border-bottom", 3, "click"], ["lectureMenuUnitsSlide", "matMenu"], [1, "btn-group", "col-xs-6"], [1, "color-preview", "btn", "btn-sm", "px-2", "py-0", 3, "click"], [3, "tagColors", "selectedColor"], [1, "markdown-editor__commands-domain"], [1, "btn", "btn-sm", "px-2", "py-0", 3, "click"], ["ngbDropdown", "", 1, "btn-group"], ["type", "button", "ngbDropdownToggle", "", 1, "btn", "btn-sm", "px-2", "py-0"], ["ngbDropdownMenu", ""], ["type", "button", "ngbDropdownItem", "", 1, "btn-sm", 3, "click"], ["ngbDropdownItem", "", "jhiTranslate", "global.generic.emptyList", 3, "disabled"], ["type", "button", 1, "btn", "btn-sm", "px-2", "py-0", 3, "ngbTooltip", "click"]], template: function MarkdownEditorComponent_Template(rf, ctx) {
        if (rf & 1) {
          i07.\u0275\u0275projectionDef(_c3);
          i07.\u0275\u0275elementStart(0, "div", 0, 1);
          i07.\u0275\u0275text(2, "\n    ");
          i07.\u0275\u0275elementStart(3, "nav", 2, 3);
          i07.\u0275\u0275listener("navChange", function MarkdownEditorComponent_Template_nav_navChange_3_listener($event) {
            return ctx.changeNavigation($event);
          });
          i07.\u0275\u0275text(5, "\n        ");
          i07.\u0275\u0275text(6, "\n        ");
          i07.\u0275\u0275elementContainerStart(7, 4);
          i07.\u0275\u0275text(8, "\n            ");
          i07.\u0275\u0275template(9, MarkdownEditorComponent_Conditional_9_Template, 5, 3)(10, MarkdownEditorComponent_ng_template_10_Template, 12, 11, "ng-template", 5);
          i07.\u0275\u0275text(11, "\n        ");
          i07.\u0275\u0275elementContainerEnd();
          i07.\u0275\u0275text(12, "\n        ");
          i07.\u0275\u0275text(13, "\n        ");
          i07.\u0275\u0275elementContainerStart(14, 6);
          i07.\u0275\u0275text(15, "\n            ");
          i07.\u0275\u0275template(16, MarkdownEditorComponent_Conditional_16_Template, 5, 3)(17, MarkdownEditorComponent_ng_template_17_Template, 3, 0, "ng-template", 5);
          i07.\u0275\u0275text(18, "\n        ");
          i07.\u0275\u0275elementContainerEnd();
          i07.\u0275\u0275text(19, "\n        ");
          i07.\u0275\u0275text(20, "\n        ");
          i07.\u0275\u0275elementContainerStart(21, 7);
          i07.\u0275\u0275text(22, "\n            ");
          i07.\u0275\u0275template(23, MarkdownEditorComponent_Conditional_23_Template, 5, 3)(24, MarkdownEditorComponent_ng_template_24_Template, 4, 1, "ng-template", 5);
          i07.\u0275\u0275text(25, "\n        ");
          i07.\u0275\u0275elementContainerEnd();
          i07.\u0275\u0275text(26, "\n        ");
          i07.\u0275\u0275text(27, "\n        ");
          i07.\u0275\u0275template(28, MarkdownEditorComponent_Conditional_28_Template, 32, 15);
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(29, "\n    ");
          i07.\u0275\u0275element(30, "div", 8);
          i07.\u0275\u0275text(31, "\n");
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(32, "\n");
        }
        if (rf & 2) {
          const _r1 = i07.\u0275\u0275reference(4);
          i07.\u0275\u0275advance(3);
          i07.\u0275\u0275property("destroyOnHide", false);
          i07.\u0275\u0275advance(6);
          i07.\u0275\u0275conditional(9, ctx.showEditButton ? 9 : -1);
          i07.\u0275\u0275advance(7);
          i07.\u0275\u0275conditional(16, ctx.showVisualModeButton ? 16 : -1);
          i07.\u0275\u0275advance(7);
          i07.\u0275\u0275conditional(23, ctx.showPreviewButton ? 23 : -1);
          i07.\u0275\u0275advance(5);
          i07.\u0275\u0275conditional(28, !ctx.previewMode && !ctx.visualMode ? 28 : -1);
          i07.\u0275\u0275advance(2);
          i07.\u0275\u0275property("ngbNavOutlet", _r1);
        }
      }, dependencies: [i42.NgStyle, i5.NgbDropdown, i5.NgbDropdownToggle, i5.NgbDropdownMenu, i5.NgbDropdownItem, i5.NgbDropdownButtonItem, i5.NgbNavContent, i5.NgbNav, i5.NgbNavItem, i5.NgbNavLink, i5.NgbNavLinkBase, i5.NgbNavOutlet, i5.NgbTooltip, i6.FaIconComponent, TranslateDirective, AceEditorComponent, ColorSelectorComponent, i10.MatMenu, i10.MatMenuItem, i10.MatMenuTrigger, i11.MatButton, SelectWithSearchComponent, ArtemisTranslatePipe, TypeCheckPipe, NegatedTypeCheckPipe], styles: ["/* src/main/webapp/app/shared/markdown-editor/markdown-editor.component.scss */\n.markdown-editor-wrapper {\n  display: flex;\n  flex-flow: column nowrap;\n  flex: 1 1 auto;\n  height: inherit;\n  color: var(--md-wrapper-color);\n}\n.markdown-editor-wrapper:-webkit-full-screen {\n  width: 100%;\n  height: 100%;\n}\n.markdown-editor-wrapper .md-resize-icon {\n  color: var(--md-resize-icon-color);\n}\n.markdown-editor-wrapper .tab-list {\n  background: var(--md-tab-list-bg);\n}\n.markdown-editor-wrapper .tab-content,\n.markdown-editor-wrapper .tab-content > .active {\n  display: flex;\n  flex-flow: column nowrap;\n  flex: 1 1 auto;\n  height: 100%;\n}\n.markdown-editor-wrapper .no-dropdown-indicator::after {\n  display: none;\n}\n.markdown-editor-wrapper .markdown-editor {\n  display: flex;\n  flex-flow: column nowrap;\n  flex: 1 1 auto;\n  touch-action: none;\n  background-color: var(--md-editor-background);\n}\n.markdown-editor-wrapper .markdown-editor__content {\n  height: 100% !important;\n  width: 100%;\n  flex: 1 1 auto;\n  overflow: auto;\n}\n.markdown-editor-wrapper .markdown-editor .file-input {\n  border-bottom: 1px dotted var(--md-file-input-border-color);\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n}\n.markdown-editor-wrapper .markdown-editor__file-input {\n  width: 0.1px;\n  height: 0.1px;\n  opacity: 0;\n  overflow: hidden;\n  position: absolute;\n  z-index: -1;\n}\n.markdown-editor-wrapper .markdown-editor__file-input:focus,\n.markdown-editor-wrapper .markdown-editor__file-label:focus {\n  outline: 1px dotted #000;\n  outline: -webkit-focus-ring-color auto 5px;\n}\n.markdown-editor-wrapper .markdown-editor__file-label {\n  cursor: pointer;\n  width: 100%;\n  border: 1px solid var(--border-color);\n  border-top: none;\n  border-radius: 0 0.15em 0.15em 0;\n}\n.markdown-editor-wrapper .markdown-editor__file-label .upload-subtitle {\n  font-size: 12px;\n  color: var(--bs-secondary);\n}\n.markdown-editor-wrapper .markdown-editor__markdown {\n  height: inherit;\n  overflow: auto;\n  padding: 1rem;\n}\n.markdown-editor-wrapper .markdown-editor__commands-default,\n.markdown-editor-wrapper .markdown-editor__commands-domain {\n  display: flex;\n  flex-flow: row wrap;\n  align-items: center;\n}\n.markdown-editor-wrapper .markdown-editor__commands .mat-mdc-button {\n  height: fit-content;\n}\n.markdown-editor-wrapper .markdown-editor .rg-bottom {\n  align-self: center;\n}\n.background-editor-high {\n  overflow: scroll;\n}\n.dropdown-menu {\n  max-height: 300px;\n  overflow-y: auto;\n}\n.dropdown-menu li {\n  position: relative;\n}\n.nested {\n  padding-left: 30px;\n}\n.nested-slide {\n  padding-left: 50px;\n}\n.default-font-size {\n  font-size: var(--bs-body-font-size);\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL21hcmtkb3duLWVkaXRvci5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLm1hcmtkb3duLWVkaXRvci13cmFwcGVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZmxvdzogY29sdW1uIG5vd3JhcDtcbiAgICBmbGV4OiAxIDEgYXV0bztcbiAgICBoZWlnaHQ6IGluaGVyaXQ7XG4gICAgY29sb3I6IHZhcigtLW1kLXdyYXBwZXItY29sb3IpO1xuXG4gICAgLy8gVGhpcyBpcyBhIGZpeCBmb3IgdXNpbmcgdGhlIGZ1bGxzY3JlZW4gbW9kZSBvbiBTYWZhcmkuXG4gICAgJjotd2Via2l0LWZ1bGwtc2NyZWVuIHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogMTAwJTtcbiAgICB9XG5cbiAgICAubWQtcmVzaXplLWljb24ge1xuICAgICAgICBjb2xvcjogdmFyKC0tbWQtcmVzaXplLWljb24tY29sb3IpO1xuICAgIH1cblxuICAgIC50YWItbGlzdCB7XG4gICAgICAgIGJhY2tncm91bmQ6IHZhcigtLW1kLXRhYi1saXN0LWJnKTtcbiAgICB9XG4gICAgLnRhYi1jb250ZW50LFxuICAgIC50YWItY29udGVudCA+IC5hY3RpdmUge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWZsb3c6IGNvbHVtbiBub3dyYXA7XG4gICAgICAgIGZsZXg6IDEgMSBhdXRvO1xuICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgfVxuXG4gICAgLm5vLWRyb3Bkb3duLWluZGljYXRvcjo6YWZ0ZXIge1xuICAgICAgICBkaXNwbGF5OiBub25lO1xuICAgIH1cblxuICAgIC5tYXJrZG93bi1lZGl0b3Ige1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWZsb3c6IGNvbHVtbiBub3dyYXA7XG4gICAgICAgIGZsZXg6IDEgMSBhdXRvO1xuICAgICAgICB0b3VjaC1hY3Rpb246IG5vbmU7XG5cbiAgICAgICAgLy8gRml4IGZvciBmdWxsIHNjcmVlbiBtb2RlLCBvdGhlcndpc2UgdGhlIGNvbG9yIGlzIGJsYWNrLlxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1tZC1lZGl0b3ItYmFja2dyb3VuZCk7XG5cbiAgICAgICAgJl9fY29udGVudCB7XG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgZmxleDogMSAxIGF1dG87XG4gICAgICAgICAgICBvdmVyZmxvdzogYXV0bztcbiAgICAgICAgfVxuXG4gICAgICAgIC5maWxlLWlucHV0IHtcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDFweCBkb3R0ZWQgdmFyKC0tbWQtZmlsZS1pbnB1dC1ib3JkZXItY29sb3IpO1xuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMDtcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwO1xuICAgICAgICB9XG5cbiAgICAgICAgJl9fZmlsZS1pbnB1dCB7XG4gICAgICAgICAgICAvLyBjYW5ub3QgYmUgc2V0IHRvICdkaXNwbGF5OiBmYWxzZScgb3Igc2ltaWxhclxuICAgICAgICAgICAgLy8gaW5wdXQgdmFsdWUgd291bGQgbm90IGJlIHNlbnRcbiAgICAgICAgICAgIHdpZHRoOiAwLjFweDtcbiAgICAgICAgICAgIGhlaWdodDogMC4xcHg7XG4gICAgICAgICAgICBvcGFjaXR5OiAwO1xuICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIHotaW5kZXg6IC0xO1xuICAgICAgICB9XG5cbiAgICAgICAgJl9fZmlsZS1pbnB1dDpmb2N1cyxcbiAgICAgICAgJl9fZmlsZS1sYWJlbDpmb2N1cyB7XG4gICAgICAgICAgICBvdXRsaW5lOiAxcHggZG90dGVkICMwMDA7XG4gICAgICAgICAgICBvdXRsaW5lOiAtd2Via2l0LWZvY3VzLXJpbmctY29sb3IgYXV0byA1cHg7XG4gICAgICAgIH1cblxuICAgICAgICAmX19maWxlLWxhYmVsIHtcbiAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tYm9yZGVyLWNvbG9yKTtcbiAgICAgICAgICAgIGJvcmRlci10b3A6IG5vbmU7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAwIDAuMTVlbSAwLjE1ZW0gMDtcblxuICAgICAgICAgICAgLnVwbG9hZC1zdWJ0aXRsZSB7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1icy1zZWNvbmRhcnkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgJl9fbWFya2Rvd24ge1xuICAgICAgICAgICAgaGVpZ2h0OiBpbmhlcml0O1xuICAgICAgICAgICAgb3ZlcmZsb3c6IGF1dG87XG4gICAgICAgICAgICBwYWRkaW5nOiAxcmVtO1xuICAgICAgICB9XG5cbiAgICAgICAgJl9fY29tbWFuZHMge1xuICAgICAgICAgICAgJi1kZWZhdWx0LFxuICAgICAgICAgICAgJi1kb21haW4ge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgZmxleC1mbG93OiByb3cgd3JhcDtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAubWF0LW1kYy1idXR0b24ge1xuICAgICAgICAgICAgICAgIGhlaWdodDogZml0LWNvbnRlbnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAucmctYm90dG9tIHtcbiAgICAgICAgICAgIGFsaWduLXNlbGY6IGNlbnRlcjtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLmJhY2tncm91bmQtZWRpdG9yLWhpZ2gge1xuICAgIG92ZXJmbG93OiBzY3JvbGw7XG59XG5cbi5kcm9wZG93bi1tZW51IHtcbiAgICBtYXgtaGVpZ2h0OiAzMDBweDtcbiAgICBvdmVyZmxvdy15OiBhdXRvO1xuXG4gICAgbGkge1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgfVxufVxuXG4ubmVzdGVkIHtcbiAgICBwYWRkaW5nLWxlZnQ6IDMwcHg7XG59XG4ubmVzdGVkLXNsaWRlIHtcbiAgICBwYWRkaW5nLWxlZnQ6IDUwcHg7XG59XG5cbi5kZWZhdWx0LWZvbnQtc2l6ZSB7XG4gICAgZm9udC1zaXplOiB2YXIoLS1icy1ib2R5LWZvbnQtc2l6ZSk7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxhQUFBLE9BQUE7QUFDQSxRQUFBLEVBQUEsRUFBQTtBQUNBLFVBQUE7QUFDQSxTQUFBLElBQUE7O0FBR0EsQ0FSSix1QkFRSTtBQUNJLFNBQUE7QUFDQSxVQUFBOztBQUdKLENBYkosd0JBYUksQ0FBQTtBQUNJLFNBQUEsSUFBQTs7QUFHSixDQWpCSix3QkFpQkksQ0FBQTtBQUNJLGNBQUEsSUFBQTs7QUFFSixDQXBCSix3QkFvQkksQ0FBQTtBQUFBLENBcEJKLHdCQW9CSSxDQUFBLFlBQUEsRUFBQSxDQUFBO0FBRUksV0FBQTtBQUNBLGFBQUEsT0FBQTtBQUNBLFFBQUEsRUFBQSxFQUFBO0FBQ0EsVUFBQTs7QUFHSixDQTVCSix3QkE0QkksQ0FBQSxxQkFBQTtBQUNJLFdBQUE7O0FBR0osQ0FoQ0osd0JBZ0NJLENBQUE7QUFDSSxXQUFBO0FBQ0EsYUFBQSxPQUFBO0FBQ0EsUUFBQSxFQUFBLEVBQUE7QUFDQSxnQkFBQTtBQUdBLG9CQUFBLElBQUE7O0FBRUEsQ0F6Q1Isd0JBeUNRLENBQUE7QUFDSSxVQUFBO0FBQ0EsU0FBQTtBQUNBLFFBQUEsRUFBQSxFQUFBO0FBQ0EsWUFBQTs7QUFHSixDQWhEUix3QkFnRFEsQ0FoQkosZ0JBZ0JJLENBQUE7QUFDSSxpQkFBQSxJQUFBLE9BQUEsSUFBQTtBQUNBLDZCQUFBO0FBQ0EsOEJBQUE7O0FBR0osQ0F0RFIsd0JBc0RRLENBQUE7QUFHSSxTQUFBO0FBQ0EsVUFBQTtBQUNBLFdBQUE7QUFDQSxZQUFBO0FBQ0EsWUFBQTtBQUNBLFdBQUE7O0FBR0osQ0FqRVIsd0JBaUVRLENBWEEsMkJBV0E7QUFBQSxDQWpFUix3QkFpRVEsQ0FBQSwyQkFBQTtBQUVJLFdBQUEsSUFBQSxPQUFBO0FBQ0EsV0FBQSx5QkFBQSxLQUFBOztBQUdKLENBdkVSLHdCQXVFUSxDQU5BO0FBT0ksVUFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBLElBQUEsTUFBQSxJQUFBO0FBQ0EsY0FBQTtBQUNBLGlCQUFBLEVBQUEsT0FBQSxPQUFBOztBQUVBLENBOUVaLHdCQThFWSxDQWJKLDRCQWFJLENBQUE7QUFDSSxhQUFBO0FBQ0EsU0FBQSxJQUFBOztBQUlSLENBcEZSLHdCQW9GUSxDQUFBO0FBQ0ksVUFBQTtBQUNBLFlBQUE7QUFDQSxXQUFBOztBQUlBLENBM0ZaLHdCQTJGWSxDQUFBO0FBQUEsQ0EzRlosd0JBMkZZLENBQUE7QUFFSSxXQUFBO0FBQ0EsYUFBQSxJQUFBO0FBQ0EsZUFBQTs7QUFHSixDQWxHWix3QkFrR1ksQ0FBQSwwQkFBQSxDQUFBO0FBQ0ksVUFBQTs7QUFJUixDQXZHUix3QkF1R1EsQ0F2RUosZ0JBdUVJLENBQUE7QUFDSSxjQUFBOztBQUtaLENBQUE7QUFDSSxZQUFBOztBQUdKLENBQUE7QUFDSSxjQUFBO0FBQ0EsY0FBQTs7QUFFQSxDQUpKLGNBSUk7QUFDSSxZQUFBOztBQUlSLENBQUE7QUFDSSxnQkFBQTs7QUFFSixDQUFBO0FBQ0ksZ0JBQUE7O0FBR0osQ0FBQTtBQUNJLGFBQUEsSUFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i07.\u0275setClassDebugInfo(MarkdownEditorComponent, { className: "MarkdownEditorComponent" });
    })();
  }
});

// src/main/webapp/app/shared/markdown-editor/ace-editor/ace-editor.module.ts
import { NgModule as NgModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i08 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var AceEditorModule;
var init_ace_editor_module = __esm({
  "src/main/webapp/app/shared/markdown-editor/ace-editor/ace-editor.module.ts"() {
    init_ace_editor_component();
    AceEditorModule = class _AceEditorModule {
      static \u0275fac = function AceEditorModule_Factory(t) {
        return new (t || _AceEditorModule)();
      };
      static \u0275mod = i08.\u0275\u0275defineNgModule({ type: _AceEditorModule });
      static \u0275inj = i08.\u0275\u0275defineInjector({});
    };
  }
});

// src/main/webapp/app/shared/markdown-editor/markdown-editor.module.ts
import { NgModule as NgModule3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { FormsModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import { MatMenuModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_menu.js?v=1d0d9ead";
import { MatButtonModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_material_button.js?v=1d0d9ead";
import * as i09 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisMarkdownEditorModule;
var init_markdown_editor_module = __esm({
  "src/main/webapp/app/shared/markdown-editor/markdown-editor.module.ts"() {
    init_markdown_editor_component();
    init_ace_editor_module();
    init_color_selector_module();
    init_shared_module();
    init_select_with_search_component();
    ArtemisMarkdownEditorModule = class _ArtemisMarkdownEditorModule {
      static \u0275fac = function ArtemisMarkdownEditorModule_Factory(t) {
        return new (t || _ArtemisMarkdownEditorModule)();
      };
      static \u0275mod = i09.\u0275\u0275defineNgModule({ type: _ArtemisMarkdownEditorModule });
      static \u0275inj = i09.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, AceEditorModule, FormsModule, ArtemisColorSelectorModule, MatMenuModule, MatButtonModule] });
    };
  }
});

export {
  MAX_TAB_SIZE,
  AceEditorComponent,
  init_ace_editor_component,
  FILE_EXTENSIONS,
  init_file_extensions_constants,
  FileUploaderService,
  init_file_uploader_service,
  ColorSelectorComponent,
  init_color_selector_component,
  DomainTagCommand,
  init_domainTag_command,
  UnderlineCommand,
  init_underline_command,
  BoldCommand,
  init_bold_command,
  ReferenceCommand,
  init_reference_command,
  DomainMultiOptionCommand,
  init_domainMultiOptionCommand,
  isFullScreen,
  exitFullscreen,
  enterFullscreen,
  init_fullscreen_util,
  ItalicCommand,
  init_italic_command,
  OrderedListCommand,
  init_orderedListCommand,
  LinkCommand,
  init_link_command,
  CodeCommand,
  init_code_command,
  UnorderedListCommand,
  init_unorderedListCommand,
  CodeBlockCommand,
  init_codeblock_command,
  MultiOptionCommand,
  init_multiOptionCommand,
  MultipleChoiceQuestion,
  init_multiple_choice_question_model,
  AnswerOption,
  init_answer_option_model,
  MultipleChoiceVisualQuestionComponent,
  init_multiple_choice_visual_question_component,
  ExerciseReferenceCommand,
  init_exerciseReferenceCommand,
  InteractiveSearchCommand,
  init_interactiveSearchCommand,
  MarkdownEditorHeight,
  EditorMode,
  MarkdownEditorComponent,
  init_markdown_editor_component,
  AceEditorModule,
  init_ace_editor_module,
  ArtemisColorSelectorModule,
  init_color_selector_module,
  ArtemisMarkdownEditorModule,
  init_markdown_editor_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2NvbG9yLXNlbGVjdG9yL2NvbG9yLXNlbGVjdG9yLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2NvbG9yLXNlbGVjdG9yL2NvbG9yLXNlbGVjdG9yLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvY29sb3Itc2VsZWN0b3IvY29sb3Itc2VsZWN0b3IubW9kdWxlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2FjZS1lZGl0b3IvYWNlLWVkaXRvci5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9jb25zdGFudHMvZmlsZS1leHRlbnNpb25zLmNvbnN0YW50cy50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2h0dHAvZmlsZS11cGxvYWRlci5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2NvbW1hbmQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvZG9tYWluQ29tbWFuZHMvZG9tYWluQ29tbWFuZC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9kb21haW5Db21tYW5kcy9kb21haW5UYWcuY29tbWFuZC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy91bmRlcmxpbmUuY29tbWFuZC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9jb2xvclBpY2tlci5jb21tYW5kLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2JvbGQuY29tbWFuZC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9hdHRhY2htZW50Q29tbWFuZC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9yZWZlcmVuY2UuY29tbWFuZC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9kb21haW5Db21tYW5kcy9kb21haW5NdWx0aU9wdGlvbkNvbW1hbmQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC91dGlsL2Z1bGxzY3JlZW4udXRpbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9mdWxsc2NyZWVuLmNvbW1hbmQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvaGVhZGluZ09uZS5jb21tYW5kLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2l0YWxpYy5jb21tYW5kLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL29yZGVyZWRMaXN0Q29tbWFuZC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9oZWFkaW5nVHdvLmNvbW1hbmQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvbGluay5jb21tYW5kLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2NvZGUuY29tbWFuZC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy91bm9yZGVyZWRMaXN0Q29tbWFuZC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9oZWFkaW5nVGhyZWUuY29tbWFuZC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9jb2RlYmxvY2suY29tbWFuZC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9tdWx0aU9wdGlvbkNvbW1hbmQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2VudGl0aWVzL3F1aXovbXVsdGlwbGUtY2hvaWNlLXF1ZXN0aW9uLm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9xdWl6L2Fuc3dlci1vcHRpb24ubW9kZWwudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9xdWl6L3NoYXJlZC9xdWVzdGlvbnMvbXVsdGlwbGUtY2hvaWNlLXF1ZXN0aW9uL211bHRpcGxlLWNob2ljZS12aXN1YWwtcXVlc3Rpb24uY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL211bHRpcGxlLWNob2ljZS1xdWVzdGlvbi9tdWx0aXBsZS1jaG9pY2UtdmlzdWFsLXF1ZXN0aW9uLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2NvdXJzZUFydGlmYWN0UmVmZXJlbmNlQ29tbWFuZHMvZXhlcmNpc2VSZWZlcmVuY2VDb21tYW5kLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2ludGVyYWN0aXZlU2VhcmNoQ29tbWFuZC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9zZWxlY3Qtd2l0aC1zZWFyY2gvc2VsZWN0LXdpdGgtc2VhcmNoLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9zZWxlY3Qtd2l0aC1zZWFyY2gvc2VsZWN0LXdpdGgtc2VhcmNoLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL21hcmtkb3duLWVkaXRvci5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvbWFya2Rvd24tZWRpdG9yLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2FjZS1lZGl0b3IvYWNlLWVkaXRvci5tb2R1bGUudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvbWFya2Rvd24tZWRpdG9yLm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIEVsZW1lbnRSZWYsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0LCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFSVEVNSVNfREVGQVVMVF9DT0xPUiB9IGZyb20gJ2FwcC9hcHAuY29uc3RhbnRzJztcblxuZXhwb3J0IGludGVyZmFjZSBDb29yZGluYXRlcyB7XG4gICAgbGVmdDogbnVtYmVyO1xuICAgIHRvcDogbnVtYmVyO1xufVxuXG5jb25zdCBERUZBVUxUX0NPTE9SUyA9IFtcbiAgICBBUlRFTUlTX0RFRkFVTFRfQ09MT1IsXG4gICAgJyMxYjk3Y2EnLFxuICAgICcjMGQzY2MyJyxcbiAgICAnIzAwOTk5OScsXG4gICAgJyMwYWI4NGYnLFxuICAgICcjOTRhMTFjJyxcbiAgICAnIzlkY2E1MycsXG4gICAgJyNmZmQwMTQnLFxuICAgICcjYzZhYTFjJyxcbiAgICAnI2ZmYTUwMCcsXG4gICAgJyNmZmIyYjInLFxuICAgICcjY2E5NGJkJyxcbiAgICAnI2E5NTI5MicsXG4gICAgJyM2OTFiMGInLFxuICAgICcjYWQ1NjU4JyxcbiAgICAnI2ZmMWEzNScsXG5dO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1jb2xvci1zZWxlY3RvcicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2NvbG9yLXNlbGVjdG9yLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9jb2xvci1zZWxlY3Rvci5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIENvbG9yU2VsZWN0b3JDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIGNvbG9yU2VsZWN0b3JQb3NpdGlvbjogQ29vcmRpbmF0ZXM7XG4gICAgc2hvd0NvbG9yU2VsZWN0b3IgPSBmYWxzZTtcbiAgICBoZWlnaHQgPSAyMjA7XG4gICAgQElucHV0KCkgdGFnQ29sb3JzOiBzdHJpbmdbXSA9IERFRkFVTFRfQ09MT1JTO1xuICAgIEBPdXRwdXQoKSBzZWxlY3RlZENvbG9yID0gbmV3IEV2ZW50RW1pdHRlcjxzdHJpbmc+KCk7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBlbGVtZW50UmVmOiBFbGVtZW50UmVmLFxuICAgICAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjIsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogc2V0IGRlZmF1bHQgcG9zaXRpb24gb24gaW5pdFxuICAgICAqL1xuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICB0aGlzLmNvbG9yU2VsZWN0b3JQb3NpdGlvbiA9IHsgbGVmdDogMCwgdG9wOiAwIH07XG5cbiAgICAgICAgdGhpcy5hZGRFdmVudExpc3RlbmVyVG9DbG9zZUNvbXBvbmVudE9uQ2xpY2tPdXRzaWRlKCk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBhZGRFdmVudExpc3RlbmVyVG9DbG9zZUNvbXBvbmVudE9uQ2xpY2tPdXRzaWRlKCkge1xuICAgICAgICB0aGlzLnJlbmRlcmVyLmxpc3RlbignZG9jdW1lbnQnLCAnY2xpY2snLCAoZXZlbnQ6IEV2ZW50KSA9PiB7XG4gICAgICAgICAgICBpZiAodGhpcy5zaG93Q29sb3JTZWxlY3Rvcikge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LnRhcmdldCBhcyBIVE1MRWxlbWVudDtcblxuICAgICAgICAgICAgICAgIGNvbnN0IGlzQ2xpY2tPdXRzaWRlT2ZDb21wb25lbnQgPSAhdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY29udGFpbnModGFyZ2V0KTtcbiAgICAgICAgICAgICAgICBpZiAoaXNDbGlja091dHNpZGVPZkNvbXBvbmVudCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNob3dDb2xvclNlbGVjdG9yID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBvcGVuIGNvbG9yU2VsZWN0b3IgYW5kIHBvc2l0aW9uIGNvcnJlY3RseVxuICAgICAqIEBwYXJhbSB7TW91c2VFdmVudH0gZXZlbnRcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gbWFyZ2luVG9wXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IGhlaWdodFxuICAgICAqL1xuICAgIG9wZW5Db2xvclNlbGVjdG9yKGV2ZW50OiBNb3VzZUV2ZW50LCBtYXJnaW5Ub3A/OiBudW1iZXIsIGhlaWdodD86IG51bWJlcikge1xuICAgICAgICAvKipcbiAgICAgICAgICogd2l0aG91dCB7QGxpbmsgZXZlbnQjc3RvcFByb3BhZ2F0aW9ufSB0aGUgY29sb3IgcGlja2VyIHdvdWxkIGNsb3NlIGltbWVkaWF0ZWx5IGFzIHRoZSBtb3VzZUV2ZW50XG4gICAgICAgICAqIGlzIHRyaWdnZXJlZCBhZ2FpbiBmb3IgdGhlIGNoaWxkIGNvbXBvbmVudCB7QGxpbmsgQ29sb3JTZWxlY3RvckNvbXBvbmVudH0gd2hpY2ggd291bGQgaW50ZXJwcmV0XG4gICAgICAgICAqIGl0IGFzIGEgY2xpY2sgb3V0c2lkZSB0aGUgY29sb3JwaWNrZXJcbiAgICAgICAgICovXG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuXG4gICAgICAgIGNvbnN0IHBhcmVudEVsZW1lbnQgPSAoZXZlbnQudGFyZ2V0IGFzIEVsZW1lbnQpLmNsb3Nlc3QoJy5uZy10cmlnZ2VyJykgYXMgSFRNTEVsZW1lbnQ7XG5cbiAgICAgICAgdGhpcy5jb2xvclNlbGVjdG9yUG9zaXRpb24ubGVmdCA9IHBhcmVudEVsZW1lbnQgPyBwYXJlbnRFbGVtZW50Lm9mZnNldExlZnQgOiAwO1xuICAgICAgICB0aGlzLmNvbG9yU2VsZWN0b3JQb3NpdGlvbi50b3AgPSBtYXJnaW5Ub3AgPz8gNjU7XG4gICAgICAgIGlmIChoZWlnaHQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhpcy5oZWlnaHQgPSBoZWlnaHQ7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLnNob3dDb2xvclNlbGVjdG9yID0gIXRoaXMuc2hvd0NvbG9yU2VsZWN0b3I7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY2xvc2UgY29sb3JTZWxlY3RvciBhbmQgZW1pdCBpdCB0byBiZSBzZXRcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gc2VsZWN0ZWRDb2xvclxuICAgICAqL1xuICAgIHNlbGVjdENvbG9yRm9yVGFnKHNlbGVjdGVkQ29sb3I6IHN0cmluZykge1xuICAgICAgICB0aGlzLnNob3dDb2xvclNlbGVjdG9yID0gZmFsc2U7XG4gICAgICAgIHRoaXMuc2VsZWN0ZWRDb2xvci5lbWl0KHNlbGVjdGVkQ29sb3IpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGNsb3NlIGNvbG9yU2VsZWN0b3JcbiAgICAgKi9cbiAgICBjYW5jZWxDb2xvclNlbGVjdG9yKCkge1xuICAgICAgICB0aGlzLnNob3dDb2xvclNlbGVjdG9yID0gZmFsc2U7XG4gICAgfVxufVxuIiwiQGlmIChzaG93Q29sb3JTZWxlY3Rvcikge1xuICAgIDxkaXYgY2xhc3M9XCJjb2xvci1zZWxlY3RvclwiIFtzdHlsZS50b3AucHhdPVwiY29sb3JTZWxlY3RvclBvc2l0aW9uLnRvcFwiIFtzdHlsZS5sZWZ0LnB4XT1cImNvbG9yU2VsZWN0b3JQb3NpdGlvbi5sZWZ0XCIgW3N0eWxlLmhlaWdodC5weF09XCJoZWlnaHRcIj5cbiAgICAgICAgQGZvciAodGFnQ29sb3Igb2YgdGFnQ29sb3JzOyB0cmFjayB0YWdDb2xvcikge1xuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRhZy1jb2xvci1zZWxlY3RvclwiIChjbGljayk9XCJzZWxlY3RDb2xvckZvclRhZyh0YWdDb2xvcilcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sb3ItZWxlbWVudFwiIFtuZ1N0eWxlXT1cInsgYmFja2dyb3VuZENvbG9yOiB0YWdDb2xvciB9XCI+PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgIDwvZGl2PlxufVxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBDb2xvclNlbGVjdG9yQ29tcG9uZW50IH0gZnJvbSAnLi9jb2xvci1zZWxlY3Rvci5jb21wb25lbnQnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtDb2xvclNlbGVjdG9yQ29tcG9uZW50XSxcbiAgICBleHBvcnRzOiBbQ29sb3JTZWxlY3RvckNvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNDb2xvclNlbGVjdG9yTW9kdWxlIHt9XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEVsZW1lbnRSZWYsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE5nWm9uZSwgT25EZXN0cm95LCBPbkluaXQsIE91dHB1dCwgZm9yd2FyZFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIE5HX1ZBTFVFX0FDQ0VTU09SIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0ICdicmFjZSc7XG5pbXBvcnQgJ2JyYWNlL3RoZW1lL21vbm9rYWknO1xuaW1wb3J0ICdicmFjZS90aGVtZS9jaHJvbWUnO1xuaW1wb3J0ICdicmFjZS90aGVtZS9kcmVhbXdlYXZlcic7XG5pbXBvcnQgJ2JyYWNlL3RoZW1lL2RyYWN1bGEnO1xuaW1wb3J0IHsgVGhlbWVTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvdGhlbWUvdGhlbWUuc2VydmljZSc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcblxuZGVjbGFyZSBsZXQgYWNlOiBhbnk7XG5cbmV4cG9ydCBjb25zdCBNQVhfVEFCX1NJWkUgPSA4O1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1hY2UtZWRpdG9yJyxcbiAgICB0ZW1wbGF0ZTogJycsXG4gICAgc3R5bGVzOiBbJzpob3N0IHsgZGlzcGxheTpibG9jazt3aWR0aDoxMDAlOyB9J10sXG4gICAgcHJvdmlkZXJzOiBbXG4gICAgICAgIHtcbiAgICAgICAgICAgIHByb3ZpZGU6IE5HX1ZBTFVFX0FDQ0VTU09SLFxuICAgICAgICAgICAgdXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gQWNlRWRpdG9yQ29tcG9uZW50KSxcbiAgICAgICAgICAgIG11bHRpOiB0cnVlLFxuICAgICAgICB9LFxuICAgIF0sXG59KVxuZXhwb3J0IGNsYXNzIEFjZUVkaXRvckNvbXBvbmVudCBpbXBsZW1lbnRzIENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBPbkluaXQsIE9uRGVzdHJveSB7XG4gICAgQE91dHB1dCgpIHRleHRDaGFuZ2VkID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICAgIEBPdXRwdXQoKSB0ZXh0Q2hhbmdlID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICAgIEBJbnB1dCgpIHN0eWxlOiBhbnkgPSB7fTtcblxuICAgIC8qKlxuICAgICAqIFNldHMgdGhlIHNpemUgaW4gc3BhY2VzIG9mIG5ld2x5IGluc2VydGVkIHRhYnMgYW5kIHRoZSBkaXNwbGF5IHNpemUgb2YgZXhpc3RpbmcgdHJ1ZSB0YWJzLlxuICAgICAqXG4gICAgICogQHBhcmFtIHZhbHVlIFRoZSBkaXNwbGF5IHdpZHRoIGJldHdlZW4gMSBhbmQge0BsaW5rIE1BWF9UQUJfU0laRX0gKGJvdGggaW5jbHVzaXZlKS5cbiAgICAgKi9cbiAgICBASW5wdXQoKVxuICAgIHB1YmxpYyBzZXQgdGFiU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgICAgIGlmICh2YWx1ZSA+IDAgJiYgdmFsdWUgPD0gTUFYX1RBQl9TSVpFKSB7XG4gICAgICAgICAgICB0aGlzLl9lZGl0b3Iuc2Vzc2lvbi5zZXRUYWJTaXplKHZhbHVlKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG9sZFRleHQ6IHN0cmluZztcbiAgICB0aW1lb3V0U2F2aW5nOiBhbnk7XG5cbiAgICBwcml2YXRlIF9vcHRpb25zOiBhbnkgPSB7fTtcbiAgICBwcml2YXRlIF9yZWFkT25seSA9IGZhbHNlO1xuICAgIHByaXZhdGUgX3RoZW1lID0gJ2RyZWFtd2VhdmVyJztcbiAgICBwcml2YXRlIF9tb2RlID0gJ2phdmEnO1xuICAgIHByaXZhdGUgX2F1dG9VcGRhdGVDb250ZW50ID0gdHJ1ZTtcbiAgICBwcml2YXRlIF9lZGl0b3I6IGFueTsgLy8gVE9ETzogdXNlIEVkaXRvciAoZGVmaW5lZCBpbiBicmFjZSkgb3IgRWRpdG9yIChkZWZpbmVkIGluIGFjZS1idWlsZHMpIGFuZCBtYWtlIHN1cmUgdG8gdXNlIHR5cGluZ3MgY29uc2lzdGVudGx5XG4gICAgcHJpdmF0ZSBfZHVyYXRpb25CZWZvcmVDYWxsYmFjayA9IDA7XG4gICAgcHJpdmF0ZSBfdGV4dCA9ICcnO1xuXG4gICAgcHJpdmF0ZSB0aGVtZVN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHB1YmxpYyBlbGVtZW50UmVmOiBFbGVtZW50UmVmLCAvLyBuZWVkZWQgZm9yIHJlc2l6ZSBkZXRlY3Rpb24gaW4gY29kZS1lZGl0b3ItYWNlLmNvbXBvbmVudC50c1xuICAgICAgICBwcml2YXRlIHpvbmU6IE5nWm9uZSxcbiAgICAgICAgcHJpdmF0ZSB0aGVtZVNlcnZpY2U6IFRoZW1lU2VydmljZSxcbiAgICApIHtcbiAgICAgICAgY29uc3QgZWwgPSBlbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQ7XG4gICAgICAgIHRoaXMuem9uZS5ydW5PdXRzaWRlQW5ndWxhcigoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLl9lZGl0b3IgPSBhY2VbJ2VkaXQnXShlbCk7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLl9lZGl0b3IuJGJsb2NrU2Nyb2xsaW5nID0gSW5maW5pdHk7XG4gICAgfVxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMuaW5pdCgpO1xuICAgICAgICB0aGlzLmluaXRFdmVudHMoKTtcbiAgICB9XG5cbiAgICBuZ09uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5fZWRpdG9yLmRlc3Ryb3koKTtcbiAgICAgICAgdGhpcy50aGVtZVN1YnNjcmlwdGlvbj8udW5zdWJzY3JpYmUoKTtcbiAgICB9XG5cbiAgICBpbml0KCkge1xuICAgICAgICB0aGlzLnNldE9wdGlvbnModGhpcy5fb3B0aW9ucyB8fCB7fSk7XG4gICAgICAgIHRoaXMuc2V0TW9kZSh0aGlzLl9tb2RlKTtcbiAgICAgICAgdGhpcy5zZXRSZWFkT25seSh0aGlzLl9yZWFkT25seSk7XG4gICAgfVxuXG4gICAgaW5pdEV2ZW50cygpIHtcbiAgICAgICAgdGhpcy5fZWRpdG9yLm9uKCdjaGFuZ2UnLCAoKSA9PiB0aGlzLnVwZGF0ZVRleHQoKSk7XG4gICAgICAgIHRoaXMuX2VkaXRvci5vbigncGFzdGUnLCAoKSA9PiB0aGlzLnVwZGF0ZVRleHQoKSk7XG5cbiAgICAgICAgdGhpcy50aGVtZVN1YnNjcmlwdGlvbiA9IHRoaXMudGhlbWVTZXJ2aWNlLmdldEN1cnJlbnRUaGVtZU9ic2VydmFibGUoKS5zdWJzY3JpYmUoKCkgPT4gdGhpcy5zZXRUaGVtZUZyb21Nb2RlKCkpO1xuICAgIH1cblxuICAgIHVwZGF0ZVRleHQoKSB7XG4gICAgICAgIGNvbnN0IG5ld1ZhbCA9IHRoaXMuX2VkaXRvci5nZXRWYWx1ZSgpO1xuICAgICAgICBpZiAobmV3VmFsID09PSB0aGlzLm9sZFRleHQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuX2R1cmF0aW9uQmVmb3JlQ2FsbGJhY2spIHtcbiAgICAgICAgICAgIHRoaXMuX3RleHQgPSBuZXdWYWw7XG4gICAgICAgICAgICB0aGlzLnpvbmUucnVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnRleHRDaGFuZ2UuZW1pdChuZXdWYWwpO1xuICAgICAgICAgICAgICAgIHRoaXMudGV4dENoYW5nZWQuZW1pdChuZXdWYWwpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLl9vbkNoYW5nZShuZXdWYWwpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKHRoaXMudGltZW91dFNhdmluZykge1xuICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLnRpbWVvdXRTYXZpbmcpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLnRpbWVvdXRTYXZpbmcgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLl90ZXh0ID0gbmV3VmFsO1xuICAgICAgICAgICAgICAgIHRoaXMuem9uZS5ydW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnRleHRDaGFuZ2UuZW1pdChuZXdWYWwpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnRleHRDaGFuZ2VkLmVtaXQobmV3VmFsKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB0aGlzLnRpbWVvdXRTYXZpbmcgPSBudWxsO1xuICAgICAgICAgICAgfSwgdGhpcy5fZHVyYXRpb25CZWZvcmVDYWxsYmFjayk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5vbGRUZXh0ID0gbmV3VmFsO1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgc2V0IG9wdGlvbnMob3B0aW9uczogYW55KSB7XG4gICAgICAgIHRoaXMuc2V0T3B0aW9ucyhvcHRpb25zKTtcbiAgICB9XG5cbiAgICBzZXRPcHRpb25zKG9wdGlvbnM6IGFueSkge1xuICAgICAgICB0aGlzLl9vcHRpb25zID0gb3B0aW9ucztcbiAgICAgICAgdGhpcy5fZWRpdG9yLnNldE9wdGlvbnMob3B0aW9ucyB8fCB7fSk7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBzZXQgcmVhZE9ubHkocmVhZE9ubHk6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5zZXRSZWFkT25seShyZWFkT25seSk7XG4gICAgfVxuXG4gICAgc2V0UmVhZE9ubHkocmVhZE9ubHk6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fcmVhZE9ubHkgPSByZWFkT25seTtcbiAgICAgICAgdGhpcy5fZWRpdG9yLnNldFJlYWRPbmx5KHJlYWRPbmx5KTtcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIHNldCBtb2RlKG1vZGU6IHN0cmluZykge1xuICAgICAgICB0aGlzLnNldE1vZGUobW9kZSk7XG4gICAgfVxuXG4gICAgc2V0TW9kZShtb2RlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5fbW9kZSA9IG1vZGU7XG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbW9kZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgIHRoaXMuX2VkaXRvci5nZXRTZXNzaW9uKCkuc2V0TW9kZSh0aGlzLl9tb2RlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuX2VkaXRvci5nZXRTZXNzaW9uKCkuc2V0TW9kZShgYWNlL21vZGUvJHt0aGlzLl9tb2RlfWApO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5zZXRUaGVtZUZyb21Nb2RlKCk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzZXRUaGVtZUZyb21Nb2RlKCkge1xuICAgICAgICBjb25zdCBjdXJyZW50QXBwbGljYXRpb25UaGVtZSA9IHRoaXMudGhlbWVTZXJ2aWNlLmdldEN1cnJlbnRUaGVtZSgpO1xuICAgICAgICB0aGlzLl90aGVtZSA9IHRoaXMuX21vZGUudG9Mb3dlckNhc2UoKSA9PT0gJ21hcmtkb3duJyA/IGN1cnJlbnRBcHBsaWNhdGlvblRoZW1lLm1hcmtkb3duQWNlVGhlbWUgOiBjdXJyZW50QXBwbGljYXRpb25UaGVtZS5jb2RlQWNlVGhlbWU7XG4gICAgICAgIHRoaXMuX2VkaXRvci5zZXRUaGVtZShgYWNlL3RoZW1lLyR7dGhpcy5fdGhlbWV9YCk7XG4gICAgfVxuXG4gICAgZ2V0IHZhbHVlKCkge1xuICAgICAgICByZXR1cm4gdGhpcy50ZXh0O1xuICAgIH1cblxuICAgIEBJbnB1dCgpXG4gICAgc2V0IHZhbHVlKHZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5zZXRUZXh0KHZhbHVlKTtcbiAgICB9XG5cbiAgICB3cml0ZVZhbHVlKHZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5zZXRUZXh0KHZhbHVlKTtcbiAgICB9XG5cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVudXNlZC12YXJzXG4gICAgcHJpdmF0ZSBfb25DaGFuZ2UgPSAoXzogYW55KSA9PiB7fTtcblxuICAgIHJlZ2lzdGVyT25DaGFuZ2UoZm46IGFueSkge1xuICAgICAgICB0aGlzLl9vbkNoYW5nZSA9IGZuO1xuICAgIH1cblxuICAgIHByaXZhdGUgX29uVG91Y2hlZCA9ICgpID0+IHt9O1xuXG4gICAgcmVnaXN0ZXJPblRvdWNoZWQoZm46IGFueSkge1xuICAgICAgICB0aGlzLl9vblRvdWNoZWQgPSBmbjtcbiAgICB9XG5cbiAgICBnZXQgdGV4dCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3RleHQ7XG4gICAgfVxuXG4gICAgQElucHV0KClcbiAgICBzZXQgdGV4dCh0ZXh0OiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5zZXRUZXh0KHRleHQpO1xuICAgIH1cblxuICAgIHNldFRleHQodGV4dDogc3RyaW5nKSB7XG4gICAgICAgIGlmICh0ZXh0ID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGV4dCA9ICcnO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLl90ZXh0ICE9PSB0ZXh0ICYmIHRoaXMuX2F1dG9VcGRhdGVDb250ZW50KSB7XG4gICAgICAgICAgICB0aGlzLl90ZXh0ID0gdGV4dDtcbiAgICAgICAgICAgIHRoaXMuX2VkaXRvci5zZXRWYWx1ZSh0ZXh0KTtcbiAgICAgICAgICAgIHRoaXMuX29uQ2hhbmdlKHRleHQpO1xuICAgICAgICAgICAgdGhpcy5fZWRpdG9yLmNsZWFyU2VsZWN0aW9uKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIHNldCBhdXRvVXBkYXRlQ29udGVudChzdGF0dXM6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5zZXRBdXRvVXBkYXRlQ29udGVudChzdGF0dXMpO1xuICAgIH1cblxuICAgIHNldEF1dG9VcGRhdGVDb250ZW50KHN0YXR1czogYm9vbGVhbikge1xuICAgICAgICB0aGlzLl9hdXRvVXBkYXRlQ29udGVudCA9IHN0YXR1cztcbiAgICB9XG5cbiAgICBASW5wdXQoKVxuICAgIHNldCBkdXJhdGlvbkJlZm9yZUNhbGxiYWNrKG51bTogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuc2V0RHVyYXRpb25CZWZvcmVDYWxsYmFjayhudW0pO1xuICAgIH1cblxuICAgIHNldER1cmF0aW9uQmVmb3JlQ2FsbGJhY2sobnVtOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5fZHVyYXRpb25CZWZvcmVDYWxsYmFjayA9IG51bTtcbiAgICB9XG5cbiAgICBnZXRFZGl0b3IoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9lZGl0b3I7XG4gICAgfVxufVxuIiwiLyoqXG4gKiBUaGUgbGlzdCBvZiBmaWxlIGV4dGVuc2lvbnMgdGhhdCBhcmUgYWxsb3dlZCB0byBiZSB1cGxvYWRlZCBpbiBhIE1hcmtkb3duIGVkaXRvci5cbiAqIEV4dGVuc2lvbnMgbXVzdCBiZSBsb3dlci1jYXNlIHdpdGhvdXQgbGVhZGluZyBkb3RzLlxuICogTk9URTogSGFzIHRvIGJlIGtlcHQgaW4gc3luYyB3aXRoIHRoZSBzZXJ2ZXItc2lkZSBkZWZpbml0aW9ucyBpbiBGaWxlUmVzb3VyY2UuamF2YVxuICovXG5leHBvcnQgY29uc3QgTUFSS0RPV05fRklMRV9FWFRFTlNJT05TID0gWydwbmcnLCAnanBnJywgJ2pwZWcnLCAnZ2lmJywgJ3N2ZycsICdwZGYnXTtcblxuLyoqXG4gKiBUaGUgZ2xvYmFsIGxpc3Qgb2YgZmlsZSBleHRlbnNpb25zIHRoYXQgYXJlIGFsbG93ZWQgdG8gYmUgdXBsb2FkZWQuXG4gKiBFeHRlbnNpb25zIG11c3QgYmUgbG93ZXItY2FzZSB3aXRob3V0IGxlYWRpbmcgZG90cy5cbiAqIE5PVEU6IEhhcyB0byBiZSBrZXB0IGluIHN5bmMgd2l0aCB0aGUgc2VydmVyLXNpZGUgZGVmaW5pdGlvbnMgaW4gRmlsZVJlc291cmNlLmphdmFcbiAqL1xuZXhwb3J0IGNvbnN0IEZJTEVfRVhURU5TSU9OUyA9IFtcbiAgICAncG5nJyxcbiAgICAnanBnJyxcbiAgICAnanBlZycsXG4gICAgJ2dpZicsXG4gICAgJ3N2ZycsXG4gICAgJ3BkZicsXG4gICAgJ3ppcCcsXG4gICAgJ3RhcicsXG4gICAgJ3R4dCcsXG4gICAgJ3J0ZicsXG4gICAgJ21kJyxcbiAgICAnaHRtJyxcbiAgICAnaHRtbCcsXG4gICAgJ2pzb24nLFxuICAgICdkb2MnLFxuICAgICdkb2N4JyxcbiAgICAnY3N2JyxcbiAgICAneGxzJyxcbiAgICAneGxzeCcsXG4gICAgJ3BwdCcsXG4gICAgJ3BwdHgnLFxuICAgICdwYWdlcycsXG4gICAgJ3BhZ2VzLXRlZicsXG4gICAgJ251bWJlcnMnLFxuICAgICdrZXknLFxuICAgICdvZHQnLFxuICAgICdvZHMnLFxuICAgICdvZHAnLFxuICAgICdvZGcnLFxuICAgICdvZGMnLFxuICAgICdvZGknLFxuICAgICdvZGYnLFxuXTtcbiIsImltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNQVhfRklMRV9TSVpFIH0gZnJvbSAnYXBwL3NoYXJlZC9jb25zdGFudHMvaW5wdXQuY29uc3RhbnRzJztcbmltcG9ydCB7IGxhc3RWYWx1ZUZyb20gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IE1BUktET1dOX0ZJTEVfRVhURU5TSU9OUyB9IGZyb20gJ2FwcC9zaGFyZWQvY29uc3RhbnRzL2ZpbGUtZXh0ZW5zaW9ucy5jb25zdGFudHMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEZpbGVVcGxvYWRSZXNwb25zZSB7XG4gICAgcGF0aD86IHN0cmluZztcbn1cblxudHlwZSBPcHRpb25zID0ge1xuICAgIGtlZXBGaWxlTmFtZTogYm9vbGVhbjtcbn07XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgRmlsZVVwbG9hZGVyU2VydmljZSB7XG4gICAgcmVhZG9ubHkgYWNjZXB0ZWRNYXJrZG93bkZpbGVFeHRlbnNpb25zID0gTUFSS0RPV05fRklMRV9FWFRFTlNJT05TO1xuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cENsaWVudCkge31cblxuICAgIC8qKlxuICAgICAqIFVwbG9hZHMgYSBmaWxlIGZvciB0aGUgbWFya2Rvd24gZWRpdG9yIHRvIHRoZSBzZXJ2ZXIuXG4gICAgICogQHBhcmFtIGZpbGUgVGhlIGZpbGUgdG8gdXBsb2FkXG4gICAgICogQHBhcmFtIGZpbGVOYW1lIFRoZSBuYW1lIG9mIHRoZSBmaWxlXG4gICAgICogQHBhcmFtIG9wdGlvbnMgVGhlIG9wdGlvbnMgZGljdGlvbmFyeSAoZS5nLCB7IGtlZXBGaWxlTmFtZTogdHJ1ZSB9KVxuICAgICAqIEByZXR1cm4gQSBwcm9taXNlIHdpdGggdGhlIHJlc3BvbnNlIGZyb20gdGhlIHNlcnZlciBvciBhbiBlcnJvclxuICAgICAqL1xuICAgIHVwbG9hZE1hcmtkb3duRmlsZShmaWxlOiBCbG9iIHwgRmlsZSwgZmlsZU5hbWU/OiBzdHJpbmcsIG9wdGlvbnM/OiBPcHRpb25zKTogUHJvbWlzZTxGaWxlVXBsb2FkUmVzcG9uc2U+IHtcbiAgICAgICAgY29uc3QgZmlsZUV4dGVuc2lvbiA9IGZpbGVOYW1lID8gZmlsZU5hbWUuc3BsaXQoJy4nKS5wb3AoKSEudG9Mb2NhbGVMb3dlckNhc2UoKSA6IChmaWxlIGFzIEZpbGUpLm5hbWUuc3BsaXQoJy4nKS5wb3AoKSEudG9Mb2NhbGVMb3dlckNhc2UoKTtcbiAgICAgICAgaWYgKCF0aGlzLmFjY2VwdGVkTWFya2Rvd25GaWxlRXh0ZW5zaW9ucy5pbmNsdWRlcyhmaWxlRXh0ZW5zaW9uKSkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KFxuICAgICAgICAgICAgICAgIG5ldyBFcnJvcihcbiAgICAgICAgICAgICAgICAgICAgJ1Vuc3VwcG9ydGVkIGZpbGUgdHlwZSEgT25seSB0aGUgZm9sbG93aW5nIGZpbGUgZXh0ZW5zaW9ucyBhcmUgYWxsb3dlZDogJyArIHRoaXMuYWNjZXB0ZWRNYXJrZG93bkZpbGVFeHRlbnNpb25zLm1hcCgoZXh0ZW5zaW9uKSA9PiBgLiR7ZXh0ZW5zaW9ufWApLmpvaW4oJywgJyksXG4gICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZmlsZS5zaXplID4gTUFYX0ZJTEVfU0laRSkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcignRmlsZSBpcyB0b28gYmlnISBNYXhpbXVtIGFsbG93ZWQgZmlsZSBzaXplOiAnICsgTUFYX0ZJTEVfU0laRSAvICgxMDI0ICogMTAyNCkgKyAnIE1CLicpKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGtlZXBGaWxlTmFtZSA9ICEhb3B0aW9ucz8ua2VlcEZpbGVOYW1lO1xuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ZpbGUnLCBmaWxlLCBmaWxlTmFtZSk7XG4gICAgICAgIHJldHVybiBsYXN0VmFsdWVGcm9tKHRoaXMuaHR0cC5wb3N0PEZpbGVVcGxvYWRSZXNwb25zZT4oYC9hcGkvbWFya2Rvd24tZmlsZS11cGxvYWQ/a2VlcEZpbGVOYW1lPSR7a2VlcEZpbGVOYW1lfWAsIGZvcm1EYXRhKSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSWNvblByb3AgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuaW1wb3J0IHsgUmFuZ2UsIGFjZXF1aXJlIH0gZnJvbSAnYnJhY2UnO1xuXG4vLyBXb3JrIGFyb3VuZCB0byB1cGRhdGUgdGhlIHJhbmdlXG5jb25zdCBSYW5nZUN0b3IgPSBhY2VxdWlyZSgnYWNlL3JhbmdlJykuUmFuZ2UgYXMgdHlwZW9mIFJhbmdlO1xuXG4vKipcbiAqIGFic3RyYWN0IGNsYXNzIGZvciBhbGwgY29tbWFuZHMgLSBkZWZhdWx0IGFuZCBkb21haW4gY29tbWFuZHMgb2YgQXJ0ZW1pc1xuICogZGVmYXVsdCBjb21tYW5kczogbWFya2Rvd24gY29tbWFuZHMgZS5nLiBib2xkLCBpdGFsaWNcbiAqIGRvbWFpbiBjb21tYW5kczogQXJ0ZW1pcyBjdXN0b21pemVkIGNvbW1hbmRzXG4gKi9cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBDb21tYW5kIHtcbiAgICBidXR0b25JY29uOiBJY29uUHJvcDtcbiAgICBidXR0b25UcmFuc2xhdGlvblN0cmluZzogc3RyaW5nO1xuICAgIHByb3RlY3RlZCBhY2VFZGl0b3I6IGFueTtcbiAgICBwcm90ZWN0ZWQgbWFya2Rvd25XcmFwcGVyOiBFbGVtZW50UmVmO1xuXG4gICAgcHVibGljIHNldEVkaXRvcihhY2VFZGl0b3I6IGFueSk6IHZvaWQge1xuICAgICAgICB0aGlzLmFjZUVkaXRvciA9IGFjZUVkaXRvcjtcbiAgICB9XG5cbiAgICBwdWJsaWMgc2V0TWFya2Rvd25XcmFwcGVyKHJlZjogRWxlbWVudFJlZikge1xuICAgICAgICB0aGlzLm1hcmtkb3duV3JhcHBlciA9IHJlZjtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgZ2V0U2VsZWN0ZWRUZXh0KCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLmFjZUVkaXRvci5nZXRTZWxlY3RlZFRleHQoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBFeHRlbmRzIHRoZSBjdXJyZW50IHNlbGVjdGlvbiB0byBmdWxsIGxpbmVzLlxuICAgICAqXG4gICAgICogQHJldHVybiBUaGUgY29tcGxldGUgbGluZXMgb2YgdGhlIHNlbGVjdGVkIHRleHQuXG4gICAgICovXG4gICAgcHJvdGVjdGVkIGdldEV4dGVuZGVkU2VsZWN0ZWRUZXh0KCk6IHN0cmluZ1tdIHtcbiAgICAgICAgY29uc3QgdGV4dCA9IHRoaXMuZ2V0VGV4dCgpO1xuXG4gICAgICAgIC8vIFNwbGl0IHRleHQgYnkgbGluZSBicmVha3NcbiAgICAgICAgY29uc3QgbGluZXMgPSB0ZXh0LnNwbGl0KCdcXG4nKTtcblxuICAgICAgICBjb25zdCByYW5nZSA9IHRoaXMuZ2V0UmFuZ2UoKTtcblxuICAgICAgICAvLyBVcGRhdGUgdGhlIHJhbmdlXG4gICAgICAgIHRoaXMuYWNlRWRpdG9yLnNlbGVjdGlvbi5zZXRSYW5nZShuZXcgUmFuZ2VDdG9yKHJhbmdlLnN0YXJ0LnJvdywgMCwgcmFuZ2UuZW5kLnJvdywgbGluZXNbcmFuZ2UuZW5kLnJvd10ubGVuZ3RoKSk7XG5cbiAgICAgICAgLy8gUmV0dXJuIGV4dGVuZGVkIHNlbGVjdGlvbiBhcyBhcnJheVxuICAgICAgICByZXR1cm4gbGluZXMuc2xpY2UocmFuZ2Uuc3RhcnQucm93LCByYW5nZS5lbmQucm93ICsgMSk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIGdldFRleHQoKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuYWNlRWRpdG9yLmdldFZhbHVlKCk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIGluc2VydFRleHQodGV4dDogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuYWNlRWRpdG9yLmluc2VydCh0ZXh0KTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgZm9jdXMoKSB7XG4gICAgICAgIHRoaXMuYWNlRWRpdG9yLmZvY3VzKCk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIGdldFJhbmdlKCk6IFJhbmdlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuYWNlRWRpdG9yLnNlbGVjdGlvbi5nZXRSYW5nZSgpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCByZXBsYWNlKHJhbmdlOiBSYW5nZSwgdGV4dDogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuYWNlRWRpdG9yLnNlc3Npb24ucmVwbGFjZShyYW5nZSwgdGV4dCk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIGNsZWFyU2VsZWN0aW9uKCkge1xuICAgICAgICB0aGlzLmFjZUVkaXRvci5jbGVhclNlbGVjdGlvbigpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBtb3ZlQ3Vyc29yVG8ocm93OiBudW1iZXIsIGNvbHVtbjogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuYWNlRWRpdG9yLm1vdmVDdXJzb3JUbyhyb3csIGNvbHVtbik7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIGdldEN1cnNvclBvc2l0aW9uKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5hY2VFZGl0b3IuZ2V0Q3Vyc29yUG9zaXRpb24oKTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgZ2V0TGluZShyb3c6IG51bWJlcikge1xuICAgICAgICByZXR1cm4gdGhpcy5hY2VFZGl0b3IuZ2V0U2Vzc2lvbigpLmdldExpbmUocm93KTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgZ2V0Q3VycmVudExpbmUoKSB7XG4gICAgICAgIGNvbnN0IGN1cnNvciA9IHRoaXMuZ2V0Q3Vyc29yUG9zaXRpb24oKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0TGluZShjdXJzb3Iucm93KTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgbW92ZUN1cnNvclRvRW5kT2ZSb3coKSB7XG4gICAgICAgIGNvbnN0IGN1cnNvciA9IHRoaXMuZ2V0Q3Vyc29yUG9zaXRpb24oKTtcbiAgICAgICAgY29uc3QgY3VycmVudExpbmUgPSB0aGlzLmFjZUVkaXRvci5nZXRTZXNzaW9uKCkuZ2V0TGluZShjdXJzb3Iucm93KTtcbiAgICAgICAgdGhpcy5jbGVhclNlbGVjdGlvbigpO1xuICAgICAgICB0aGlzLm1vdmVDdXJzb3JUbyhjdXJzb3Iucm93LCBjdXJyZW50TGluZS5sZW5ndGgpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBhZGRDb21wbGV0ZXIoY29tcGxldGVyOiBhbnkpIHtcbiAgICAgICAgdGhpcy5hY2VFZGl0b3IuY29tcGxldGVycyA9IFsuLi4odGhpcy5hY2VFZGl0b3IuY29tcGxldGVycyB8fCBbXSksIGNvbXBsZXRlcl07XG4gICAgfVxuXG4gICAgYWJzdHJhY3QgZXhlY3V0ZShpbnB1dD86IHN0cmluZyk6IHZvaWQ7XG5cbiAgICBwcm90ZWN0ZWQgZGVsZXRlV2hpdGVTcGFjZSh0ZXh0OiBzdHJpbmcpIHtcbiAgICAgICAgcmV0dXJuIHRleHQudHJpbSgpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBhZGRSZWZpbmVkVGV4dChzZWxlY3RlZFRleHQ6IHN0cmluZywgdGV4dFRvQWRkOiBzdHJpbmcpIHtcbiAgICAgICAgaWYgKHNlbGVjdGVkVGV4dC5jaGFyQXQoMCkgPT09ICcgJyAmJiBzZWxlY3RlZFRleHQuY2hhckF0KHNlbGVjdGVkVGV4dC5sZW5ndGggLSAxKSA9PT0gJyAnKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5pbnNlcnRUZXh0KCcgJyArIHRleHRUb0FkZCArICcgJyk7XG4gICAgICAgIH0gZWxzZSBpZiAoc2VsZWN0ZWRUZXh0LmNoYXJBdCgwKSA9PT0gJyAnKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5pbnNlcnRUZXh0KCcgJyArIHRleHRUb0FkZCk7XG4gICAgICAgIH0gZWxzZSBpZiAoc2VsZWN0ZWRUZXh0LmNoYXJBdChzZWxlY3RlZFRleHQubGVuZ3RoIC0gMSkgPT09ICcgJykge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuaW5zZXJ0VGV4dCh0ZXh0VG9BZGQgKyAnICcpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuaW5zZXJ0VGV4dCh0ZXh0VG9BZGQpO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2NvbW1hbmQnO1xuaW1wb3J0IHsgZXNjYXBlU3RyaW5nRm9yVXNlSW5SZWdleCB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC9nbG9iYWwudXRpbHMnO1xuXG4vKiogYWJzdHJhY3QgY2xhc3MgZm9yIGFsbCBkb21haW5Db21tYW5kcyAtIGN1c3RvbWl6ZWQgY29tbWFuZHMgZm9yIEFydGVtaXMgc3BlY2lmaWMgdXNlIGNhc2VzXG4gKiBlLmcuIG11bHRpcGxlIGNob2ljZSBxdWVzdGlvbnMsIGRyYWcgYW5kIGRyb3AgcXVlc3Rpb25zXG4gKiBFYWNoIGRvbWFpbiBjb21tYW5kIGhhcyBpdHMgb3duIGxvZ2ljIGFuZCBhIHVuaXF1ZSBpZGVudGlmaWVyKiovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgRG9tYWluQ29tbWFuZCBleHRlbmRzIENvbW1hbmQge1xuICAgIGFic3RyYWN0IGdldE9wZW5pbmdJZGVudGlmaWVyKCk6IHN0cmluZzsgLy8gZS5nLiBbZXhwXVxuICAgIGFic3RyYWN0IGdldENsb3NpbmdJZGVudGlmaWVyKCk6IHN0cmluZzsgLy8gZS5nLiBbL2V4cF1cbiAgICBkaXNwbGF5Q29tbWFuZEJ1dHRvbiA9IHRydWU7XG5cbiAgICAvKipcbiAgICAgKiBHZW5lcmF0ZSBhIHJlZ2V4IHRoYXQgY2FuIGJlIHVzZWQgdG8gZ2V0IHRoZSBjb250ZW50IGFsb25lIG9yIGluY2x1ZGluZyB0aGUgdGFncy5cbiAgICAgKiBpbmRleCAwOiBHZXQgY29udGVudCB3aXRoIHRhZ3MgYXJvdW5kIGl0LlxuICAgICAqIGluZGV4IDE6IEdldCBjb250ZW50IHdpdGhvdXQgdGhlIHRhZ3MuXG4gICAgICovXG4gICAgZ2V0VGFnUmVnZXgoZmxhZ3MgPSAnJyk6IFJlZ0V4cCB7XG4gICAgICAgIGNvbnN0IGVzY2FwZWRPcGVuaW5nSWRlbnRpZmllciA9IGVzY2FwZVN0cmluZ0ZvclVzZUluUmVnZXgodGhpcy5nZXRPcGVuaW5nSWRlbnRpZmllcigpKSxcbiAgICAgICAgICAgIGVzY2FwZWRDbG9zaW5nSWRlbnRpZmllciA9IGVzY2FwZVN0cmluZ0ZvclVzZUluUmVnZXgodGhpcy5nZXRDbG9zaW5nSWRlbnRpZmllcigpKTtcbiAgICAgICAgcmV0dXJuIG5ldyBSZWdFeHAoYCR7ZXNjYXBlZE9wZW5pbmdJZGVudGlmaWVyfSguKikke2VzY2FwZWRDbG9zaW5nSWRlbnRpZmllcn1gLCBmbGFncyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2tzIGlmIHRoZSBjdXJzb3IgaXMgcGxhY2VkIHdpdGhpbiB0aGUgaWRlbnRpZmllcnMgb2YgYSBkb21haW4gY29tbWFuZC5cbiAgICAgKiBSZXR1cm5zIHRoZSBjb250ZW50IGJldHdlZW4gdGhlIGlkZW50aWZpZXJzIGlmIHRoZXJlIGlzIG1hdGNoLCBvdGhlcndpc2UgcmV0dXJucyBudWxsLlxuICAgICAqL1xuICAgIGlzQ3Vyc29yV2l0aGluVGFnKCk6IHsgbWF0Y2hTdGFydDogbnVtYmVyOyBtYXRjaEVuZDogbnVtYmVyOyBpbm5lclRhZ0NvbnRlbnQ6IHN0cmluZyB9IHwgbnVsbCB7XG4gICAgICAgIGNvbnN0IHsgcm93LCBjb2x1bW4gfSA9IHRoaXMuYWNlRWRpdG9yLmdldEN1cnNvclBvc2l0aW9uKCksXG4gICAgICAgICAgICBsaW5lID0gdGhpcy5hY2VFZGl0b3IuZ2V0U2Vzc2lvbigpLmdldExpbmUocm93KSxcbiAgICAgICAgICAgIHJlZ2V4ID0gdGhpcy5nZXRUYWdSZWdleCgnZycpO1xuXG4gICAgICAgIGNvbnN0IGluZGV4ZXM6IEFycmF5PHsgbWF0Y2hTdGFydDogbnVtYmVyOyBtYXRjaEVuZDogbnVtYmVyOyBpbm5lclRhZ0NvbnRlbnQ6IHN0cmluZyB9PiA9IFtdO1xuXG4gICAgICAgIC8vIEEgbGluZSBjYW4gaGF2ZSBtdWx0aXBsZSB0YWdzIGluIGl0LCBzbyB3ZSBuZWVkIHRvIGNoZWNrIGZvciBtdWx0aXBsZSBtYXRjaGVzLlxuICAgICAgICBsZXQgbWF0Y2ggPSByZWdleC5leGVjKGxpbmUpO1xuICAgICAgICB3aGlsZSAobWF0Y2ggIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBpbmRleGVzLnB1c2goeyBtYXRjaFN0YXJ0OiBtYXRjaC5pbmRleCwgbWF0Y2hFbmQ6IG1hdGNoLmluZGV4ICsgbWF0Y2hbMF0ubGVuZ3RoLCBpbm5lclRhZ0NvbnRlbnQ6IG1hdGNoWzFdIH0pO1xuICAgICAgICAgICAgbWF0Y2ggPSByZWdleC5leGVjKGxpbmUpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG1hdGNoT25DdXJzb3IgPSBpbmRleGVzLmZpbmQoKHsgbWF0Y2hTdGFydCwgbWF0Y2hFbmQgfSkgPT4gY29sdW1uID4gbWF0Y2hTdGFydCAmJiBjb2x1bW4gPD0gbWF0Y2hFbmQpO1xuICAgICAgICByZXR1cm4gbWF0Y2hPbkN1cnNvciB8fCBudWxsO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENoZWNrcyBpZiB0aGVyZSBpcyBhIHRhZyBpbiB0aGUgbGluZSBvZiB0aGUgY3Vyc29yLlxuICAgICAqIFJldHVybnMgdGhlIGNvbnRlbnQgYmV0d2VlbiB0aGUgaWRlbnRpZmllcnMgaWYgdGhlcmUgaXMgbWF0Y2gsIG90aGVyd2lzZSByZXR1cm5zIG51bGwuXG4gICAgICovXG4gICAgaXNUYWdJblJvdyhyb3c6IG51bWJlcik6IHsgbWF0Y2hTdGFydDogbnVtYmVyOyBtYXRjaEVuZDogbnVtYmVyOyBpbm5lclRhZ0NvbnRlbnQ6IHN0cmluZyB9IHwgbnVsbCB7XG4gICAgICAgIGNvbnN0IGxpbmUgPSB0aGlzLmFjZUVkaXRvci5nZXRTZXNzaW9uKCkuZ2V0TGluZShyb3cpLFxuICAgICAgICAgICAgcmVnZXggPSB0aGlzLmdldFRhZ1JlZ2V4KCk7XG5cbiAgICAgICAgaWYgKCFsaW5lKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG1hdGNoID0gbGluZS5tYXRjaChyZWdleCk7XG4gICAgICAgIGlmICghbWF0Y2gpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7IG1hdGNoU3RhcnQ6IG1hdGNoLmluZGV4LCBtYXRjaEVuZDogbWF0Y2guaW5kZXggKyBtYXRjaFswXS5sZW5ndGgsIGlubmVyVGFnQ29udGVudDogbWF0Y2hbMV0gfTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBEb21haW5Db21tYW5kIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvZG9tYWluQ29tbWFuZHMvZG9tYWluQ29tbWFuZCc7XG5cbi8qKlxuICogVGhpcyBkb21haW4gY29tbWFuZCB3aWxsIGJlIHVzZWQgYXMgYSBidXR0b24gaW4gdGhlIG1hcmtkb3duIGVkaXRvci5cbiAqL1xuZXhwb3J0IGFic3RyYWN0IGNsYXNzIERvbWFpblRhZ0NvbW1hbmQgZXh0ZW5kcyBEb21haW5Db21tYW5kIHt9XG4iLCJpbXBvcnQgeyBJY29uUHJvcCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1zdmctY29yZSc7XG5pbXBvcnQgeyBmYVVuZGVybGluZSB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSAnLi9jb21tYW5kJztcblxuZXhwb3J0IGNsYXNzIFVuZGVybGluZUNvbW1hbmQgZXh0ZW5kcyBDb21tYW5kIHtcbiAgICBidXR0b25JY29uID0gZmFVbmRlcmxpbmUgYXMgSWNvblByb3A7XG4gICAgYnV0dG9uVHJhbnNsYXRpb25TdHJpbmcgPSAnYXJ0ZW1pc0FwcC5tdWx0aXBsZUNob2ljZVF1ZXN0aW9uLmVkaXRvci51bmRlcmxpbmUnO1xuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGV4ZWN1dGVcbiAgICAgKiBAZGVzYyBBZGQvUmVtb3ZlIHVuZGVybGluZSB0ZXh0XG4gICAgICogICAgICAgMS4gQ2hlY2sgaWYgdGhlIHNlbGVjdGVkIHRleHQgaW5jbHVkZXMgKDxpbnM+KVxuICAgICAqICAgICAgIDIuIElmIGluY2x1ZGVkIChpbnMpIHJlZHVjZSB0aGUgc2VsZWN0ZWQgdGV4dCBieSB0aGVzZSBlbGVtZW50cyBhbmQgcmVwbGFjZSB0aGUgc2VsZWN0ZWQgdGV4dCBieSB0ZXh0VG9BZGRcbiAgICAgKiAgICAgICAzLiBJZiBub3QgaW5jbHVkZWQsIGFkZCAoPGlucz4pIGJlZm9yZSBhbmQgYWZ0ZXIgdGhlIHNlbGVjdGVkIHRleHQgYW5kIGluc2VydCB0aGVtIGludG8gdGhlIGVkaXRvclxuICAgICAqICAgICAgIDQuIFVuZGVybGluZSBpbiBtYXJrZG93biBsYW5ndWFnZSBhcHBlYXJzXG4gICAgICovXG4gICAgZXhlY3V0ZSgpOiB2b2lkIHtcbiAgICAgICAgY29uc3QgY2hvc2VuVGV4dCA9IHRoaXMuZ2V0U2VsZWN0ZWRUZXh0KCk7XG5cbiAgICAgICAgaWYgKGNob3NlblRleHQuaW5jbHVkZXMoJzxpbnM+JykpIHtcbiAgICAgICAgICAgIGNvbnN0IHRleHRUb0FkZCA9IGNob3NlblRleHQuc2xpY2UoNSwgLTYpO1xuICAgICAgICAgICAgdGhpcy5pbnNlcnRUZXh0KHRleHRUb0FkZCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0VG9BZGQgPSBgPGlucz4ke2Nob3NlblRleHR9PC9pbnM+YDtcbiAgICAgICAgICAgIHRoaXMuaW5zZXJ0VGV4dCh0ZXh0VG9BZGQpO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSWNvblByb3AgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gJy4vY29tbWFuZCc7XG5cbmV4cG9ydCBjbGFzcyBDb2xvclBpY2tlckNvbW1hbmQgZXh0ZW5kcyBDb21tYW5kIHtcbiAgICBidXR0b25JY29uID0gJycgYXMgSWNvblByb3A7XG4gICAgYnV0dG9uVHJhbnNsYXRpb25TdHJpbmcgPSAnYXJ0ZW1pc0FwcC5tdWx0aXBsZUNob2ljZVF1ZXN0aW9uLmVkaXRvci5jb2xvcic7XG5cbiAgICAvKipcbiAgICAgKiBAZnVuY3Rpb24gZXhlY3V0ZVxuICAgICAqIEBkZXNjIFNldC8gUmVtb3ZlIGNvbG9yXG4gICAgICogICAgICAgMS4gQ2hlY2sgaWYgdGhlIHNlbGVjdGVkIHRleHQgaW5jbHVkZXMgKDxzcGFuKVxuICAgICAqICAgICAgIDIuIElmIGluY2x1ZGVkIHJlZHVjZSB0aGUgc2VsZWN0ZWQgdGV4dCBieSB0aGUgaHRtbCBlbGVtZW50cyBmb3Igc2V0dGluZyB0aGUgY29sb3IgYW5kIHJlcGxhY2UgdGhlIHNlbGVjdGVkIHRleHQgYnkgdGV4dFRvQWRkXG4gICAgICogICAgICAgMy4gSWYgbm90IGluY2x1ZGVkIGluc2VydCB0aGUgaHRtbCBlbGVtZW50IHRoYXQgY2hhbmdlIHRoZSBzdHlsZSBvZiB0aGUgc2VsZWN0ZWRUZXh0IGJ5IHNldHRpbmcgdGhlIGNob3NlbiBjb2xvclxuICAgICAqICAgICAgIDQuIENvbG9yIGNoYW5nZXMgb2NjdXJcbiAgICAgKi9cbiAgICBleGVjdXRlKGNvbG9yOiBzdHJpbmcpOiB2b2lkIHtcbiAgICAgICAgY29uc3Qgc2VsZWN0ZWRUZXh0ID0gdGhpcy5nZXRTZWxlY3RlZFRleHQoKTtcblxuICAgICAgICBpZiAoc2VsZWN0ZWRUZXh0LmluY2x1ZGVzKCdjbGFzcz1cImdyZWVuXCInKSB8fCBzZWxlY3RlZFRleHQuaW5jbHVkZXMoJ2NsYXNzPVwid2hpdGVcIicpKSB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0VG9BZGQgPSBzZWxlY3RlZFRleHQuc2xpY2UoMjAsIC03KTtcbiAgICAgICAgICAgIHRoaXMuaW5zZXJ0VGV4dCh0ZXh0VG9BZGQpO1xuICAgICAgICB9IGVsc2UgaWYgKHNlbGVjdGVkVGV4dC5pbmNsdWRlcygnY2xhc3M9XCJ5ZWxsb3dcIicpIHx8IHNlbGVjdGVkVGV4dC5pbmNsdWRlcygnY2xhc3M9XCJvcmFuZ2VcIicpKSB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0VG9BZGQgPSBzZWxlY3RlZFRleHQuc2xpY2UoMjEsIC03KTtcbiAgICAgICAgICAgIHRoaXMuaW5zZXJ0VGV4dCh0ZXh0VG9BZGQpO1xuICAgICAgICB9IGVsc2UgaWYgKHNlbGVjdGVkVGV4dC5pbmNsdWRlcygnY2xhc3M9XCJyZWRcIicpKSB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0VG9BZGQgPSBzZWxlY3RlZFRleHQuc2xpY2UoMTgsIC03KTtcbiAgICAgICAgICAgIHRoaXMuaW5zZXJ0VGV4dCh0ZXh0VG9BZGQpO1xuICAgICAgICB9IGVsc2UgaWYgKHNlbGVjdGVkVGV4dC5pbmNsdWRlcygnY2xhc3M9XCJibHVlXCInKSB8fCBzZWxlY3RlZFRleHQuaW5jbHVkZXMoJ2NsYXNzPVwibGlsYVwiJykpIHtcbiAgICAgICAgICAgIGNvbnN0IHRleHRUb0FkZCA9IHNlbGVjdGVkVGV4dC5zbGljZSgxOSwgLTcpO1xuICAgICAgICAgICAgdGhpcy5pbnNlcnRUZXh0KHRleHRUb0FkZCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmluc2VydEhUTUxGb3JDb2xvckNoYW5nZShzZWxlY3RlZFRleHQsIGNvbG9yKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEBmdW5jdGlvbiBpbnNlcnRIVE1MRm9yQ29sb3JDaGFuZ2VcbiAgICAgKiBAZGVzYyBJbnNlcnQgYSBodG1sIHNwYW4gd2l0aCB0aGUgY29sb3IgY2hhbmdlc1xuICAgICAqIE5vdGU6IE1hcmtkb3duIGRvZXMgbm90IHN1cHBvcnQgY29sb3IgY2hhbmdlcyAtIHRoaXMgaXMgd2h5IGh0bWwgaW5qZWN0aW9uIGlzIHVzZWRcbiAgICAgKi9cbiAgICBpbnNlcnRIVE1MRm9yQ29sb3JDaGFuZ2Uoc2VsZWN0ZWRUZXh0OiBzdHJpbmcsIGNvbG9yOiBzdHJpbmcpIHtcbiAgICAgICAgbGV0IHRleHRUb0FkZCA9ICcnO1xuICAgICAgICBzd2l0Y2ggKGNvbG9yKSB7XG4gICAgICAgICAgICBjYXNlICcjY2EyMDI0JzpcbiAgICAgICAgICAgICAgICB0ZXh0VG9BZGQgPSBgPHNwYW4gY2xhc3M9XCJyZWRcIj5gICsgYCR7c2VsZWN0ZWRUZXh0fWAgKyBgPC9zcGFuPmA7XG4gICAgICAgICAgICAgICAgdGhpcy5pbnNlcnRUZXh0KHRleHRUb0FkZCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICcjM2VhMTE5JzpcbiAgICAgICAgICAgICAgICB0ZXh0VG9BZGQgPSBgPHNwYW4gY2xhc3M9XCJncmVlblwiPmAgKyBgJHtzZWxlY3RlZFRleHR9YCArIGA8L3NwYW4+YDtcbiAgICAgICAgICAgICAgICB0aGlzLmluc2VydFRleHQodGV4dFRvQWRkKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJyNmZmZmZmYnOlxuICAgICAgICAgICAgICAgIHRleHRUb0FkZCA9IGA8c3BhbiBjbGFzcz1cIndoaXRlXCI+YCArIGAke3NlbGVjdGVkVGV4dH1gICsgYDwvc3Bhbj5gO1xuICAgICAgICAgICAgICAgIHRoaXMuaW5zZXJ0VGV4dCh0ZXh0VG9BZGQpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnIzAwMDAwMCc6XG4gICAgICAgICAgICAgICAgdGV4dFRvQWRkID0gYCR7c2VsZWN0ZWRUZXh0fWA7XG4gICAgICAgICAgICAgICAgLy8gdGhpcy5leGVjdXRlKCcjMDAwMDAwJyk7XG4gICAgICAgICAgICAgICAgLy8gdGV4dFRvQWRkID0gYDxzcGFuIGNsYXNzPVwiYmxhY2tcIj5gICsgYCR7c2VsZWN0ZWRUZXh0fWAgKyBgPC9zcGFuPmA7XG4gICAgICAgICAgICAgICAgdGhpcy5pbnNlcnRUZXh0KHRleHRUb0FkZCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICcjZmZmYTVjJzpcbiAgICAgICAgICAgICAgICB0ZXh0VG9BZGQgPSBgPHNwYW4gY2xhc3M9XCJ5ZWxsb3dcIj5gICsgYCR7c2VsZWN0ZWRUZXh0fWAgKyBgPC9zcGFuPmA7XG4gICAgICAgICAgICAgICAgdGhpcy5pbnNlcnRUZXh0KHRleHRUb0FkZCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICcjMGQzY2MyJzpcbiAgICAgICAgICAgICAgICB0ZXh0VG9BZGQgPSBgPHNwYW4gY2xhc3M9XCJibHVlXCI+YCArIGAke3NlbGVjdGVkVGV4dH1gICsgYDwvc3Bhbj5gO1xuICAgICAgICAgICAgICAgIHRoaXMuaW5zZXJ0VGV4dCh0ZXh0VG9BZGQpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnI2IwNWRiOCc6XG4gICAgICAgICAgICAgICAgdGV4dFRvQWRkID0gYDxzcGFuIGNsYXNzPVwibGlsYVwiPmAgKyBgJHtzZWxlY3RlZFRleHR9YCArIGA8L3NwYW4+YDtcbiAgICAgICAgICAgICAgICB0aGlzLmluc2VydFRleHQodGV4dFRvQWRkKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJyNkODZiMWYnOlxuICAgICAgICAgICAgICAgIHRleHRUb0FkZCA9IGA8c3BhbiBjbGFzcz1cIm9yYW5nZVwiPmAgKyBgJHtzZWxlY3RlZFRleHR9YCArIGA8L3NwYW4+YDtcbiAgICAgICAgICAgICAgICB0aGlzLmluc2VydFRleHQodGV4dFRvQWRkKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImltcG9ydCB7IEljb25Qcm9wIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcbmltcG9ydCB7IGZhQm9sZCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSAnLi9jb21tYW5kJztcblxuZXhwb3J0IGNsYXNzIEJvbGRDb21tYW5kIGV4dGVuZHMgQ29tbWFuZCB7XG4gICAgYnV0dG9uSWNvbiA9IGZhQm9sZCBhcyBJY29uUHJvcDtcbiAgICBidXR0b25UcmFuc2xhdGlvblN0cmluZyA9ICdhcnRlbWlzQXBwLm11bHRpcGxlQ2hvaWNlUXVlc3Rpb24uZWRpdG9yLmJvbGQnO1xuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGV4ZWN1dGVcbiAgICAgKiBAZGVzYyBNYWtlL1JlbW92ZSBib2xkIHRleHRcbiAgICAgKiAgICAgICAxLiBDaGVjayBpZiB0aGUgc2VsZWN0ZWQgdGV4dCBpbmNsdWRlcyAoKiopXG4gICAgICogICAgICAgMi4gSWYgaW5jbHVkZWQgcmVkdWNlIHRoZSBzZWxlY3RlZCB0ZXh0IGJ5IHRoZXNlIGVsZW1lbnRzIGFuZCByZXBsYWNlIHRoZSBzZWxlY3RlZCB0ZXh0IGJ5IHRleHRUb0FkZFxuICAgICAqICAgICAgIDMuIElmIG5vdCBpbmNsdWRlZCwgYWRkICgqKikgYmVmb3JlIGFuZCBhZnRlciB0aGUgc2VsZWN0ZWQgdGV4dCBhbmQgaW5zZXJ0IHRoZW0gaW50byB0aGUgZWRpdG9yXG4gICAgICogICAgICAgNC4gQm9sZCBtYXJrZG93biBhcHBlYXJzXG4gICAgICovXG4gICAgZXhlY3V0ZSgpOiB2b2lkIHtcbiAgICAgICAgY29uc3Qgc2VsZWN0ZWRUZXh0ID0gdGhpcy5nZXRTZWxlY3RlZFRleHQoKTtcbiAgICAgICAgbGV0IHRleHRUb0FkZCA9ICcnO1xuXG4gICAgICAgIGlmIChzZWxlY3RlZFRleHQuc2xpY2UoMCwgMikgPT09ICcqKicgJiYgc2VsZWN0ZWRUZXh0LnNsaWNlKHNlbGVjdGVkVGV4dC5sZW5ndGggLSAyLCBzZWxlY3RlZFRleHQubGVuZ3RoKSA9PT0gJyoqJykge1xuICAgICAgICAgICAgdGV4dFRvQWRkID0gc2VsZWN0ZWRUZXh0LnNsaWNlKDIsIC0yKTtcbiAgICAgICAgICAgIHRoaXMuaW5zZXJ0VGV4dCh0ZXh0VG9BZGQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgdHJpbW1lZFRleHQgPSB0aGlzLmRlbGV0ZVdoaXRlU3BhY2Uoc2VsZWN0ZWRUZXh0KTtcbiAgICAgICAgICAgIHRleHRUb0FkZCA9IGAqKiR7dHJpbW1lZFRleHR9KipgO1xuICAgICAgICAgICAgdGhpcy5hZGRSZWZpbmVkVGV4dChzZWxlY3RlZFRleHQsIHRleHRUb0FkZCk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgeyBJY29uUHJvcCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1zdmctY29yZSc7XG5pbXBvcnQgeyBmYUltYWdlIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IENvbW1hbmQgfSBmcm9tICcuL2NvbW1hbmQnO1xuXG5leHBvcnQgY2xhc3MgQXR0YWNobWVudENvbW1hbmQgZXh0ZW5kcyBDb21tYW5kIHtcbiAgICBidXR0b25JY29uID0gZmFJbWFnZSBhcyBJY29uUHJvcDtcbiAgICBidXR0b25UcmFuc2xhdGlvblN0cmluZyA9ICdhcnRlbWlzQXBwLm11bHRpcGxlQ2hvaWNlUXVlc3Rpb24uZWRpdG9yLmltYWdlVXBsb2FkJztcblxuICAgIC8qKlxuICAgICAqIEBmdW5jdGlvbiBleGVjdXRlXG4gICAgICogQGRlc2MgaW5zZXJ0L3JlbW92ZSB0aGUgbWFya2Rvd24gY29tbWFuZCBmb3IgdXBsb2FkaW5nIGFuIGF0dGFjaG1lbnRcbiAgICAgKiAgICAgICAxLiBDaGVjayBpZiB0aGUgc2VsZWN0ZWQgdGV4dCBpbmNsdWRlcyAoJyFbXShodHRwOi8vKScpXG4gICAgICogICAgICAgMi4gSWYgaW5jbHVkZWQgcmVkdWNlIHRoZSBzZWxlY3RlZCB0ZXh0IGJ5IHRoaXMgZWxlbWVudHMgYW5kIHJlcGxhY2UgdGhlIHNlbGVjdGVkIHRleHQgYnkgdGV4dFRvQWRkXG4gICAgICogICAgICAgMy4gSWYgbm90IGluY2x1ZGVkIGFkZCAoJyFbXShodHRwOi8vKScpIGF0IHRoZSBjdXJzb3IgcG9zaXRpb24gaW4gdGhlIGVkaXRvclxuICAgICAqICAgICAgIDQuIEF0dGFjaG1lbnQgaW4gTWFya2Rvd24gbGFuZ3VhZ2UgYXBwZWFyc1xuICAgICAqL1xuICAgIGV4ZWN1dGUoKTogdm9pZCB7XG4gICAgICAgIGxldCBzZWxlY3RlZFRleHQgPSB0aGlzLmdldFNlbGVjdGVkVGV4dCgpO1xuXG4gICAgICAgIGlmIChzZWxlY3RlZFRleHQuaW5jbHVkZXMoJyFbXShodHRwOi8vKScpKSB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0VG9BZGQgPSBzZWxlY3RlZFRleHQuc2xpY2UoMTIpO1xuICAgICAgICAgICAgdGhpcy5pbnNlcnRUZXh0KHRleHRUb0FkZCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCByYW5nZSA9IHRoaXMuZ2V0UmFuZ2UoKTtcbiAgICAgICAgICAgIHNlbGVjdGVkVGV4dCA9IGAhW10oaHR0cDovLylgO1xuICAgICAgICAgICAgdGhpcy5yZXBsYWNlKHJhbmdlLCBzZWxlY3RlZFRleHQpO1xuICAgICAgICAgICAgdGhpcy5mb2N1cygpO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSWNvblByb3AgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuaW1wb3J0IHsgZmFRdW90ZUxlZnQgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gJy4vY29tbWFuZCc7XG5cbmV4cG9ydCBjbGFzcyBSZWZlcmVuY2VDb21tYW5kIGV4dGVuZHMgQ29tbWFuZCB7XG4gICAgYnV0dG9uSWNvbiA9IGZhUXVvdGVMZWZ0IGFzIEljb25Qcm9wO1xuICAgIGJ1dHRvblRyYW5zbGF0aW9uU3RyaW5nID0gJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi5lZGl0b3IucXVvdGUnO1xuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGV4ZWN1dGVcbiAgICAgKiBAZGVzYyBBZGQvUmVtb3ZlIGEgcmVmZXJlbmNlIGluIG1hcmtkb3duIGxhbmd1YWdlXG4gICAgICogICAgICAgMS4gQ2hlY2sgaWYgdGhlIHNlbGVjdGVkIHRleHQgaW5jbHVkZXMgKCc+JykgYW5kL29yICgnUmVmZXJlbmNlJylcbiAgICAgKiAgICAgICAyLiBJZiBpbmNsdWRlZCByZWR1Y2UgdGhlIHNlbGVjdGVkIHRleHQgYnkgdGhpcyBlbGVtZW50cyBhbmQgYWRkIHJlcGxhY2UgdGhlIHNlbGVjdGVkIHRleHQgYnkgdGV4dFRvQWRkXG4gICAgICogICAgICAgMy4gSWYgbm90IGluY2x1ZGVkIGFkZCAoJz4nKSBiZWZvcmUgdGhlIHNlbGVjdGVkIHRleHQgYW5kIGluc2VydCBpbnRvIGVkaXRvclxuICAgICAqICAgICAgIDQuIFJlZmVyZW5jZSBpbiBtYXJrZG93biBhcHBlYXJzXG4gICAgICovXG4gICAgZXhlY3V0ZSgpOiB2b2lkIHtcbiAgICAgICAgbGV0IHNlbGVjdGVkVGV4dCA9IHRoaXMuZ2V0U2VsZWN0ZWRUZXh0KCk7XG5cbiAgICAgICAgaWYgKHNlbGVjdGVkVGV4dC5pbmNsdWRlcygnPicpICYmICFzZWxlY3RlZFRleHQuaW5jbHVkZXMoJ1JlZmVyZW5jZScpKSB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0VG9BZGQgPSBzZWxlY3RlZFRleHQuc2xpY2UoMik7XG4gICAgICAgICAgICB0aGlzLmluc2VydFRleHQodGV4dFRvQWRkKTtcbiAgICAgICAgfSBlbHNlIGlmIChzZWxlY3RlZFRleHQuaW5jbHVkZXMoJz4nKSAmJiBzZWxlY3RlZFRleHQuaW5jbHVkZXMoJ1JlZmVyZW5jZScpKSB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0VG9BZGQgPSBzZWxlY3RlZFRleHQuc2xpY2UoMiwgLTkpO1xuICAgICAgICAgICAgdGhpcy5pbnNlcnRUZXh0KHRleHRUb0FkZCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCByYW5nZSA9IHRoaXMuZ2V0UmFuZ2UoKTtcbiAgICAgICAgICAgIGNvbnN0IGluaXRUZXh0ID0gJ1JlZmVyZW5jZSc7XG4gICAgICAgICAgICBzZWxlY3RlZFRleHQgPSBgPiAke3NlbGVjdGVkVGV4dCB8fCBpbml0VGV4dH1gO1xuICAgICAgICAgICAgdGhpcy5yZXBsYWNlKHJhbmdlLCBzZWxlY3RlZFRleHQpO1xuICAgICAgICAgICAgdGhpcy5mb2N1cygpO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgRG9tYWluQ29tbWFuZCB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2RvbWFpbkNvbW1hbmRzL2RvbWFpbkNvbW1hbmQnO1xuaW1wb3J0IHsgVmFsdWVJdGVtIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZC1jb25zdGFudHMnO1xuXG4vKipcbiAqIFRoaXMgZG9tYWluIGNvbW1hbmQgd2lsbCBiZSB1c2VkIGFzIGEgZHJvcGRvd24gaW4gdGhlIG1hcmtkb3duIGVkaXRvci5cbiAqL1xuZXhwb3J0IGFic3RyYWN0IGNsYXNzIERvbWFpbk11bHRpT3B0aW9uQ29tbWFuZCBleHRlbmRzIERvbWFpbkNvbW1hbmQge1xuICAgIHByb3RlY3RlZCB2YWx1ZXM6IFZhbHVlSXRlbVtdID0gW107XG4gICAgc2V0VmFsdWVzKHZhbHVlczogVmFsdWVJdGVtW10pIHtcbiAgICAgICAgdGhpcy52YWx1ZXMgPSB2YWx1ZXM7XG4gICAgfVxuICAgIGdldFZhbHVlcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudmFsdWVzO1xuICAgIH1cbn1cbiIsIi8qKlxuICogY2hlY2tzIGlmIHRoaXMgY29tcG9uZW50IGlzIHRoZSBjdXJyZW50IGZ1bGxzY3JlZW4gY29tcG9uZW50XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc0Z1bGxTY3JlZW4oKTogYm9vbGVhbiB7XG4gICAgY29uc3QgZG9jRWxlbWVudCA9IGRvY3VtZW50IGFzIGFueTtcbiAgICAvLyBjaGVjayBpZiB0aGlzIGNvbXBvbmVudCBpcyB0aGUgY3VycmVudCBmdWxsc2NyZWVuIGNvbXBvbmVudCBmb3IgZGlmZmVyZW50IGJyb3dzZXIgdHlwZXNcbiAgICBpZiAoZG9jRWxlbWVudC5mdWxsc2NyZWVuRWxlbWVudCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiBkb2NFbGVtZW50LmZ1bGxzY3JlZW5FbGVtZW50O1xuICAgIH0gZWxzZSBpZiAoZG9jRWxlbWVudC53ZWJraXRGdWxsc2NyZWVuRWxlbWVudCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiBkb2NFbGVtZW50LndlYmtpdEZ1bGxzY3JlZW5FbGVtZW50O1xuICAgIH0gZWxzZSBpZiAoZG9jRWxlbWVudC5tb3pGdWxsU2NyZWVuRWxlbWVudCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiBkb2NFbGVtZW50Lm1vekZ1bGxTY3JlZW5FbGVtZW50O1xuICAgIH0gZWxzZSBpZiAoZG9jRWxlbWVudC5tc0Z1bGxzY3JlZW5FbGVtZW50ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuIGRvY0VsZW1lbnQubXNGdWxsc2NyZWVuRWxlbWVudDtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xufVxuXG4vKipcbiAqIGV4aXQgZnVsbHNjcmVlblxuICovXG5leHBvcnQgZnVuY3Rpb24gZXhpdEZ1bGxzY3JlZW4oKSB7XG4gICAgY29uc3QgZG9jRWxlbWVudCA9IGRvY3VtZW50IGFzIGFueTtcbiAgICAvLyBleGl0IGZ1bGxzY3JlZW4gZm9yIGRpZmZlcmVudCBicm93c2VyIHR5cGVzXG4gICAgaWYgKGRvY3VtZW50LmV4aXRGdWxsc2NyZWVuKSB7XG4gICAgICAgIGRvY3VtZW50LmV4aXRGdWxsc2NyZWVuKCk7XG4gICAgfSBlbHNlIGlmIChkb2NFbGVtZW50Lm1vekNhbmNlbEZ1bGxTY3JlZW4pIHtcbiAgICAgICAgZG9jRWxlbWVudC5tb3pDYW5jZWxGdWxsU2NyZWVuKCk7XG4gICAgfSBlbHNlIGlmIChkb2NFbGVtZW50Lm1zUmVxdWVzdEZ1bGxzY3JlZW4pIHtcbiAgICAgICAgZG9jRWxlbWVudC5tc1JlcXVlc3RGdWxsc2NyZWVuKCk7XG4gICAgfSBlbHNlIGlmIChkb2NFbGVtZW50LndlYmtpdEV4aXRGdWxsc2NyZWVuKSB7XG4gICAgICAgIGRvY0VsZW1lbnQud2Via2l0RXhpdEZ1bGxzY3JlZW4oKTtcbiAgICB9XG59XG5cbi8qKlxuICogZW50ZXIgZnVsbCBzY3JlZW5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVudGVyRnVsbHNjcmVlbihlbGVtZW50OiBhbnkpIHtcbiAgICAvLyByZXF1ZXN0RnVsbHNjcmVlbiBmb3IgZGlmZmVyZW50IGJyb3dzZXIgdHlwZXNcbiAgICBpZiAoZWxlbWVudC5yZXF1ZXN0RnVsbHNjcmVlbikge1xuICAgICAgICBlbGVtZW50LnJlcXVlc3RGdWxsc2NyZWVuKCk7XG4gICAgfSBlbHNlIGlmIChlbGVtZW50Lm1velJlcXVlc3RGdWxsU2NyZWVuKSB7XG4gICAgICAgIGVsZW1lbnQubW96UmVxdWVzdEZ1bGxTY3JlZW4oKTtcbiAgICB9IGVsc2UgaWYgKGVsZW1lbnQubXNSZXF1ZXN0RnVsbHNjcmVlbikge1xuICAgICAgICBlbGVtZW50Lm1zUmVxdWVzdEZ1bGxzY3JlZW4oKTtcbiAgICB9IGVsc2UgaWYgKGVsZW1lbnQud2Via2l0UmVxdWVzdEZ1bGxzY3JlZW4pIHtcbiAgICAgICAgZWxlbWVudC53ZWJraXRSZXF1ZXN0RnVsbHNjcmVlbigpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEljb25Qcm9wIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcbmltcG9ydCB7IGZhQ29tcHJlc3MgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2NvbW1hbmQnO1xuaW1wb3J0IHsgZW50ZXJGdWxsc2NyZWVuLCBleGl0RnVsbHNjcmVlbiwgaXNGdWxsU2NyZWVuIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2Z1bGxzY3JlZW4udXRpbCc7XG5cbi8qKlxuICogVG9nZ2xlcyBmdWxsc2NyZWVuIG9uIGJ1dHRvbiBwcmVzcy5cbiAqIFVzZXMgdGhlIG1hcmtkb3duIGVkaXRvciB3cmFwcGVyIGluY2x1ZGluZyB0YWJzIGFzIGVsZW1lbnQgZm9yIGZ1bGxzY3JlZW4uXG4gKlxuICogVGhlIGNvbW1hbmQgbmVlZHMgdG8gY2hlY2sgZGlmZmVyZW50IGJyb3dzZXIgaW1wbGVtZW50YXRpb25zIG9mIHRoZSBmdWxsc2NyZWVuIG1vZGUgc28gaXQgaXMgaGFuZGxlZCBjb3JyZWN0bHkuXG4gKi9cbmV4cG9ydCBjbGFzcyBGdWxsc2NyZWVuQ29tbWFuZCBleHRlbmRzIENvbW1hbmQge1xuICAgIGJ1dHRvbkljb24gPSBmYUNvbXByZXNzIGFzIEljb25Qcm9wO1xuICAgIGJ1dHRvblRyYW5zbGF0aW9uU3RyaW5nID0gJ2FydGVtaXNBcHAubWFya2Rvd25FZGl0b3IuY29tbWFuZHMuZnVsbHNjcmVlbic7XG5cbiAgICBleGVjdXRlKCk6IHZvaWQge1xuICAgICAgICBpZiAoaXNGdWxsU2NyZWVuKCkpIHtcbiAgICAgICAgICAgIGV4aXRGdWxsc2NyZWVuKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBlbGVtZW50ID0gdGhpcy5tYXJrZG93bldyYXBwZXIubmF0aXZlRWxlbWVudDtcbiAgICAgICAgICAgIGVudGVyRnVsbHNjcmVlbihlbGVtZW50KTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImltcG9ydCB7IEljb25Qcm9wIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcbmltcG9ydCB7IGZhSGVhZGluZyB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvY29tbWFuZCc7XG5cbmV4cG9ydCBjbGFzcyBIZWFkaW5nT25lQ29tbWFuZCBleHRlbmRzIENvbW1hbmQge1xuICAgIGJ1dHRvbkljb24gPSBmYUhlYWRpbmcgYXMgSWNvblByb3A7XG4gICAgYnV0dG9uVHJhbnNsYXRpb25TdHJpbmcgPSAnYXJ0ZW1pc0FwcC5tdWx0aXBsZUNob2ljZVF1ZXN0aW9uLmVkaXRvci5oZWFkaW5nT25lJztcblxuICAgIC8qKlxuICAgICAqIEBmdW5jdGlvbiBleGVjdXRlXG4gICAgICogQGRlc2MgQ3JlYXRlL3JlbW92ZSBoZWFkaW5nIG9uZSBpbiBtYXJrZG93biBsYW5ndWFnZVxuICAgICAqICAgICAgIDEuIENoZWNrIGlmIHRoZSBzZWxlY3RlZCB0ZXh0IGluY2x1ZGVzICgjKSBhbmQvb3IgKCdIZWFkaW5nIDEnKVxuICAgICAqICAgICAgIDIuIElmIGluY2x1ZGVkICByZWR1Y2UgdGhlIHNlbGVjdGVkIHRleHQgYnkgdGhpcyBlbGVtZW50cyBhbmQgYWRkIHJlcGxhY2UgdGhlIHNlbGVjdGVkIHRleHQgYnkgdGV4dFRvQWRkXG4gICAgICogICAgICAgMy4gSWYgbm90IGluY2x1ZGVkIGFkZCAoIykgYmVmb3JlIHRoZSBzZWxlY3RlZCB0ZXh0IGFuZCBpbnNlcnQgdGhlbSBpbnRvIHRoZSBlZGl0b3JcbiAgICAgKiAgICAgICA0LiBIZWFkaW5nIG9uZSBpbiBtYXJrZG93biBsYW5ndWFnZSBhcHBlYXJzXG4gICAgICovXG4gICAgZXhlY3V0ZSgpOiB2b2lkIHtcbiAgICAgICAgbGV0IHNlbGVjdGVkVGV4dCA9IHRoaXMuZ2V0U2VsZWN0ZWRUZXh0KCk7XG5cbiAgICAgICAgaWYgKHNlbGVjdGVkVGV4dC5pbmNsdWRlcygnIycpICYmICFzZWxlY3RlZFRleHQuaW5jbHVkZXMoJ0hlYWRpbmcgMScpKSB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0VG9BZGQgPSBzZWxlY3RlZFRleHQuc2xpY2UoMik7XG4gICAgICAgICAgICB0aGlzLmluc2VydFRleHQodGV4dFRvQWRkKTtcbiAgICAgICAgfSBlbHNlIGlmIChzZWxlY3RlZFRleHQuaW5jbHVkZXMoJyMnKSAmJiBzZWxlY3RlZFRleHQuaW5jbHVkZXMoJ0hlYWRpbmcgMScpKSB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0VG9BZGQgPSBzZWxlY3RlZFRleHQuc2xpY2UoMiwgLTkpO1xuICAgICAgICAgICAgdGhpcy5pbnNlcnRUZXh0KHRleHRUb0FkZCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBpbml0VGV4dCA9ICdIZWFkaW5nIDEnO1xuICAgICAgICAgICAgY29uc3QgcmFuZ2UgPSB0aGlzLmdldFJhbmdlKCk7XG4gICAgICAgICAgICBzZWxlY3RlZFRleHQgPSBgIyAke3NlbGVjdGVkVGV4dCB8fCBpbml0VGV4dH1gO1xuICAgICAgICAgICAgdGhpcy5yZXBsYWNlKHJhbmdlLCBzZWxlY3RlZFRleHQpO1xuICAgICAgICAgICAgdGhpcy5mb2N1cygpO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSWNvblByb3AgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuaW1wb3J0IHsgZmFJdGFsaWMgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gJy4vY29tbWFuZCc7XG5cbmV4cG9ydCBjbGFzcyBJdGFsaWNDb21tYW5kIGV4dGVuZHMgQ29tbWFuZCB7XG4gICAgYnV0dG9uSWNvbiA9IGZhSXRhbGljIGFzIEljb25Qcm9wO1xuICAgIGJ1dHRvblRyYW5zbGF0aW9uU3RyaW5nID0gJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi5lZGl0b3IuaXRhbGljJztcblxuICAgIC8qKlxuICAgICAqIEBmdW5jdGlvbiBleGVjdXRlXG4gICAgICogQGRlc2MgTWFrZS9SZW1vdmUgaXRhbGljIHRleHRcbiAgICAgKiAgICAgICAxLiBDaGVjayBpZiB0aGUgc2VsZWN0ZWQgdGV4dCBpbmNsdWRlcyAoKilcbiAgICAgKiAgICAgICAyLiBJZiBpbmNsdWRlZCByZWR1Y2UgdGhlIHNlbGVjdGVkIHRleHQgYnkgdGhpcyBlbGVtZW50cyBhbmQgcmVwbGFjZSB0aGUgc2VsZWN0ZWQgdGV4dCBieSB0ZXh0VG9BZGRcbiAgICAgKiAgICAgICAzLiBJZiBub3QgaW5jbHVkZWQgYWRkICgqKSBiZWZvcmUgYW5kIGFmdGVyIHRoZSBzZWxlY3RlZCB0ZXh0IGFuZCBpbnNlcnQgdGhlbSBpbnRvIHRoZSBlZGl0b3JcbiAgICAgKiAgICAgICA0LiBJdGFsaWMgaW4gbWFya2Rvd24gbGFuZ3VhZ2UgYXBwZWFyc1xuICAgICAqL1xuICAgIGV4ZWN1dGUoKTogdm9pZCB7XG4gICAgICAgIGNvbnN0IHNlbGVjdGVkVGV4dCA9IHRoaXMuZ2V0U2VsZWN0ZWRUZXh0KCk7XG4gICAgICAgIGxldCB0ZXh0VG9BZGQgPSAnJztcblxuICAgICAgICBpZiAoc2VsZWN0ZWRUZXh0LmNoYXJBdCgwKSA9PT0gJyonICYmIHNlbGVjdGVkVGV4dC5jaGFyQXQoc2VsZWN0ZWRUZXh0Lmxlbmd0aCAtIDEpID09PSAnKicpIHtcbiAgICAgICAgICAgIHRleHRUb0FkZCA9IHNlbGVjdGVkVGV4dC5zbGljZSgxLCAtMSk7XG4gICAgICAgICAgICB0aGlzLmluc2VydFRleHQodGV4dFRvQWRkKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IHRyaW1tZWRUZXh0ID0gdGhpcy5kZWxldGVXaGl0ZVNwYWNlKHNlbGVjdGVkVGV4dCk7XG4gICAgICAgICAgICB0ZXh0VG9BZGQgPSBgKiR7dHJpbW1lZFRleHR9KmA7XG4gICAgICAgICAgICB0aGlzLmFkZFJlZmluZWRUZXh0KHNlbGVjdGVkVGV4dCwgdGV4dFRvQWRkKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImltcG9ydCB7IEljb25Qcm9wIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcbmltcG9ydCB7IGZhTGlzdE9sIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IENvbW1hbmQgfSBmcm9tICcuL2NvbW1hbmQnO1xuXG5leHBvcnQgY2xhc3MgT3JkZXJlZExpc3RDb21tYW5kIGV4dGVuZHMgQ29tbWFuZCB7XG4gICAgYnV0dG9uSWNvbiA9IGZhTGlzdE9sIGFzIEljb25Qcm9wO1xuICAgIGJ1dHRvblRyYW5zbGF0aW9uU3RyaW5nID0gJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi5lZGl0b3Iub3JkZXJlZExpc3QnO1xuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGV4ZWN1dGVcbiAgICAgKiBAZGVzYyBVc2UgdGhlIE1hcmtkb3duIGxhbmd1YWdlIGZvciBjcmVhdGluZy9yZW1vdmluZyBhbiBvcmRlcmVkIGxpc3RcbiAgICAgKi9cbiAgICBleGVjdXRlKCk6IHZvaWQge1xuICAgICAgICBjb25zdCBleHRlbmRlZFRleHQgPSB0aGlzLmdldEV4dGVuZGVkU2VsZWN0ZWRUZXh0KCk7XG4gICAgICAgIHRoaXMuaGFuZGxlTWFuaXB1bGF0aW9uKGV4dGVuZGVkVGV4dCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUGVyZm9ybXMgdGhlIG5lY2Vzc2FyeSBtYW5pcHVsYXRpb25zLlxuICAgICAqIEBwYXJhbSBleHRlbmRlZFRleHQgdGhlIGV4dGVuZGVkIHRleHRcbiAgICAgKi9cbiAgICBoYW5kbGVNYW5pcHVsYXRpb24oZXh0ZW5kZWRUZXh0OiBzdHJpbmdbXSk6IHZvaWQge1xuICAgICAgICBsZXQgbWFuaXB1bGF0ZWRUZXh0ID0gJyc7XG4gICAgICAgIGxldCBwb3NpdGlvbiA9IDE7XG5cbiAgICAgICAgZXh0ZW5kZWRUZXh0LmZvckVhY2goKGxpbmUsIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAvLyBTcGVjaWFsIGNhc2U6IFNpbmdsZSBlbXB0eSBsaW5lXG4gICAgICAgICAgICBpZiAobGluZSA9PT0gJycpIHtcbiAgICAgICAgICAgICAgICBpZiAoZXh0ZW5kZWRUZXh0Lmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICBtYW5pcHVsYXRlZFRleHQgPSAnMS4gJztcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gTWFuaXB1bGF0ZSB0aGUgbGluZSwgZS5nLiByZW1vdmUgdGhlIG51bWJlciBvciBhZGQgdGhlIG51bWJlci5cbiAgICAgICAgICAgICAgICBtYW5pcHVsYXRlZFRleHQgKz0gdGhpcy5tYW5pcHVsYXRlTGluZShsaW5lLCBwb3NpdGlvbik7XG4gICAgICAgICAgICAgICAgcG9zaXRpb24rKztcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKGluZGV4ICE9PSBleHRlbmRlZFRleHQubGVuZ3RoIC0gMSkge1xuICAgICAgICAgICAgICAgIG1hbmlwdWxhdGVkVGV4dCArPSAnXFxuJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMucmVwbGFjZSh0aGlzLmdldFJhbmdlKCksIG1hbmlwdWxhdGVkVGV4dCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTWFuaXB1bGF0ZXMgYSBnaXZlbiBsaW5lIGFuZCBhZGRzIG9yIHJlbW92ZXMgdGhlIG51bWJlcnMgYXQgdGhlIGJlZ2lubmluZy5cbiAgICAgKiBAcGFyYW0gbGluZSB0byBtYW5pcHVsYXRlXG4gICAgICogQHBhcmFtIHBvc2l0aW9uIG9mIHRoZSBsaW5lIGluIHRoZSBvcmRlcmVkIGxpc3RcbiAgICAgKiBAcmV0dXJuIG1hbmlwdWxhdGVkIGxpbmVcbiAgICAgKi9cbiAgICBtYW5pcHVsYXRlTGluZShsaW5lOiBzdHJpbmcsIHBvc2l0aW9uOiBudW1iZXIpOiBzdHJpbmcge1xuICAgICAgICBjb25zdCBpbmRleCA9IGxpbmUuaW5kZXhPZignLicpO1xuXG4gICAgICAgIC8vIENhbGMgbGVhZGluZyB3aGl0ZXNwYWNlc1xuICAgICAgICBjb25zdCB3aGl0ZXNwYWNlcyA9IGxpbmUuc2VhcmNoKC9cXFN8JC8pO1xuXG4gICAgICAgIC8vIFRoZXJlIGlzIGEgZG90IGluIHRoaXMgbGluZVxuICAgICAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICAgICAgICBjb25zdCBlbGVtZW50cyA9IFtsaW5lLnNsaWNlKHdoaXRlc3BhY2VzLCBpbmRleCksIGxpbmUuc2xpY2UoaW5kZXggKyAxKV07XG5cbiAgICAgICAgICAgIC8vIENoZWNrIGlmIHRoaXMgaXMgcmVhbGx5IGEgbnVtYmVyXG4gICAgICAgICAgICBpZiAoZWxlbWVudHNbMF0gIT09ICcnICYmICFpc05hTihOdW1iZXIoZWxlbWVudHNbMF0pKSkge1xuICAgICAgICAgICAgICAgIC8vIEFkZCB3aGl0ZXNwYWNlcyBhbmQgcmVtb3ZlIGZpcnN0IHdoaXRlc3BhY2UgYWZ0ZXIgdGhlIGRvdFxuICAgICAgICAgICAgICAgIHJldHVybiAnICcucmVwZWF0KHdoaXRlc3BhY2VzKSArIGVsZW1lbnRzWzFdLnN1YnN0cmluZygxKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEFkZCB0aGUgcG9zaXRpb24gb2YgdGhlIGxpc3QgZWxlbWVudFxuICAgICAgICByZXR1cm4gJyAnLnJlcGVhdCh3aGl0ZXNwYWNlcykgKyBgJHtwb3NpdGlvbn0uICR7bGluZS5zdWJzdHJpbmcod2hpdGVzcGFjZXMpfWA7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSWNvblByb3AgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuaW1wb3J0IHsgZmFIZWFkaW5nIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IENvbW1hbmQgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9jb21tYW5kJztcblxuZXhwb3J0IGNsYXNzIEhlYWRpbmdUd29Db21tYW5kIGV4dGVuZHMgQ29tbWFuZCB7XG4gICAgYnV0dG9uSWNvbiA9IGZhSGVhZGluZyBhcyBJY29uUHJvcDtcbiAgICBidXR0b25UcmFuc2xhdGlvblN0cmluZyA9ICdhcnRlbWlzQXBwLm11bHRpcGxlQ2hvaWNlUXVlc3Rpb24uZWRpdG9yLmhlYWRpbmdUd28nO1xuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGV4ZWN1dGVcbiAgICAgKiBAZGVzYyBDcmVhdGUvUmVtb3ZlIGhlYWRpbmcgdHdvIGxhbmd1YWdlXG4gICAgICogICAgICAgMS4gQ2hlY2sgaWYgdGhlIHNlbGVjdGVkIHRleHQgaW5jbHVkZXMgKCMjKSBhbmQvb3IgKCdIZWFkaW5nIDInKVxuICAgICAqICAgICAgIDIuIElmIGluY2x1ZGVkICByZWR1Y2UgdGhlIHNlbGVjdGVkIHRleHQgYnkgdGhpcyBlbGVtZW50cyBhbmQgYWRkIHJlcGxhY2UgdGhlIHNlbGVjdGVkIHRleHQgYnkgdGV4dFRvQWRkXG4gICAgICogICAgICAgMy4gSWYgbm90IGluY2x1ZGVkIGFkZCAoIyMpIGJlZm9yZSB0aGUgc2VsZWN0ZWQgdGV4dCBhbmQgaW5zZXJ0IHRoZW0gaW50byB0aGUgZWRpdG9yXG4gICAgICogICAgICAgNC4gSGVhZGluZyB0d28gaW4gbWFya2Rvd24gbGFuZ3VhZ2UgYXBwZWFyc1xuICAgICAqL1xuICAgIGV4ZWN1dGUoKTogdm9pZCB7XG4gICAgICAgIGxldCBzZWxlY3RlZFRleHQgPSB0aGlzLmdldFNlbGVjdGVkVGV4dCgpO1xuXG4gICAgICAgIGlmIChzZWxlY3RlZFRleHQuaW5jbHVkZXMoJyMjJykgJiYgIXNlbGVjdGVkVGV4dC5pbmNsdWRlcygnSGVhZGluZyAyJykpIHtcbiAgICAgICAgICAgIGNvbnN0IHRleHRUb0FkZCA9IHNlbGVjdGVkVGV4dC5zbGljZSgzKTtcbiAgICAgICAgICAgIHRoaXMuaW5zZXJ0VGV4dCh0ZXh0VG9BZGQpO1xuICAgICAgICB9IGVsc2UgaWYgKHNlbGVjdGVkVGV4dC5pbmNsdWRlcygnIyMnKSAmJiBzZWxlY3RlZFRleHQuaW5jbHVkZXMoJ0hlYWRpbmcgMicpKSB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0VG9BZGQgPSBzZWxlY3RlZFRleHQuc2xpY2UoMywgLTkpO1xuICAgICAgICAgICAgdGhpcy5pbnNlcnRUZXh0KHRleHRUb0FkZCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBpbml0VGV4dCA9ICdIZWFkaW5nIDInO1xuICAgICAgICAgICAgY29uc3QgcmFuZ2UgPSB0aGlzLmdldFJhbmdlKCk7XG4gICAgICAgICAgICBzZWxlY3RlZFRleHQgPSBgIyMgJHtzZWxlY3RlZFRleHQgfHwgaW5pdFRleHR9YDtcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZShyYW5nZSwgc2VsZWN0ZWRUZXh0KTtcbiAgICAgICAgICAgIHRoaXMuZm9jdXMoKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImltcG9ydCB7IEljb25Qcm9wIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcbmltcG9ydCB7IGZhTGluayB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSAnLi9jb21tYW5kJztcblxuZXhwb3J0IGNsYXNzIExpbmtDb21tYW5kIGV4dGVuZHMgQ29tbWFuZCB7XG4gICAgYnV0dG9uSWNvbiA9IGZhTGluayBhcyBJY29uUHJvcDtcbiAgICBidXR0b25UcmFuc2xhdGlvblN0cmluZyA9ICdhcnRlbWlzQXBwLm11bHRpcGxlQ2hvaWNlUXVlc3Rpb24uZWRpdG9yLmxpbmsnO1xuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGV4ZWN1dGVcbiAgICAgKiBAZGVzYyBBZGQvUmVtb3ZlIGEgbGluayBpbiBtYXJrZG93biBsYW5ndWFnZVxuICAgICAqICAgICAgIDEuIGNoZWNrIGlmIHRoZSBzZWxlY3RlZCB0ZXh0IGluY2x1ZGVzICgnW10oaHR0cDovLyknKVxuICAgICAqICAgICAgIDIuIElmIGluY2x1ZGVkIHJlZHVjZSB0aGUgc2VsZWN0ZWQgdGV4dCBieSB0aGlzIGVsZW1lbnRzIGFuZCByZXBsYWNlIHRoZSBzZWxlY3RlZCB0ZXh0IGJ5IHRleHRUb0FkZFxuICAgICAqICAgICAgIDMuIElmIG5vdCBpbmNsdWRlZCBhZGQgKCdbXShodHRwOi8vKScpIGF0IHRoZSBjdXJzb3IgaW4gdGhlIGVkaXRvclxuICAgICAqICAgICAgIDQuIExpbmsgaW4gbWFya2Rvd24gbGFuZ3VhZ2UgYXBwZWFyc1xuICAgICAqL1xuICAgIGV4ZWN1dGUoKTogdm9pZCB7XG4gICAgICAgIGxldCBzZWxlY3RlZFRleHQgPSB0aGlzLmdldFNlbGVjdGVkVGV4dCgpO1xuXG4gICAgICAgIGlmIChzZWxlY3RlZFRleHQuaW5jbHVkZXMoJ1tdKGh0dHA6Ly8pJykpIHtcbiAgICAgICAgICAgIGNvbnN0IHRleHRUb0FkZCA9IHNlbGVjdGVkVGV4dC5zbGljZSgxMSk7XG4gICAgICAgICAgICB0aGlzLmluc2VydFRleHQodGV4dFRvQWRkKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IHJhbmdlID0gdGhpcy5nZXRSYW5nZSgpO1xuICAgICAgICAgICAgc2VsZWN0ZWRUZXh0ID0gYFtdKGh0dHA6Ly8pYDtcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZShyYW5nZSwgc2VsZWN0ZWRUZXh0KTtcbiAgICAgICAgICAgIHRoaXMuZm9jdXMoKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImltcG9ydCB7IEljb25Qcm9wIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcbmltcG9ydCB7IGZhQ29kZSB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSAnLi9jb21tYW5kJztcblxuZXhwb3J0IGNsYXNzIENvZGVDb21tYW5kIGV4dGVuZHMgQ29tbWFuZCB7XG4gICAgYnV0dG9uSWNvbiA9IGZhQ29kZSBhcyBJY29uUHJvcDtcbiAgICBidXR0b25UcmFuc2xhdGlvblN0cmluZyA9ICdhcnRlbWlzQXBwLm11bHRpcGxlQ2hvaWNlUXVlc3Rpb24uZWRpdG9yLmNvZGUnO1xuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGV4ZWN1dGVcbiAgICAgKiBAZGVzYyAxLiBjaGVjayBpZiB0aGUgc2VsZWN0ZWQgdGV4dCBzdGFydHMgd2l0aCAnYCcgYW5kIGVuZHMgd2l0aCAnYCdcbiAgICAgKiAgICAgICAyLiBpZiBpdCBkb2VzIGluY2x1ZGUgdGhvc2UgZWxlbWVudHMgcmVkdWNlIHRoZSBzZWxlY3RlZCB0ZXh0IGJ5IHRoaXMgZWxlbWVudHMgYW5kIGFkZCByZXBsYWNlIHRoZSBzZWxlY3RlZCB0ZXh0IGJ5IHRoZSByZWR1Y2VkIHRleHRcbiAgICAgKiAgICAgICAzLiBpZiBpdCBkb2VzIG5vdCBpbmNsdWRlIHRob3NlIGFkZCAoYCkgYmVmb3JlIGFuZCBhZnRlciB0aGUgc2VsZWN0ZWQgdGV4dCBhbmQgYWRkIHRoZW0gdG8gdGhlIHRleHQgZWRpdG9yXG4gICAgICogICAgICAgNC4gY29kZSBtYXJrZG93biBhcHBlYXJzXG4gICAgICovXG4gICAgZXhlY3V0ZSgpOiB2b2lkIHtcbiAgICAgICAgbGV0IHNlbGVjdGVkVGV4dCA9IHRoaXMuZ2V0U2VsZWN0ZWRUZXh0KCk7XG5cbiAgICAgICAgaWYgKHNlbGVjdGVkVGV4dC5zdGFydHNXaXRoKCdgJykgJiYgc2VsZWN0ZWRUZXh0LmVuZHNXaXRoKCdgJykpIHtcbiAgICAgICAgICAgIGNvbnN0IHRleHRUb0FkZCA9IHNlbGVjdGVkVGV4dC5zbGljZSgxLCAtMSk7XG4gICAgICAgICAgICB0aGlzLmluc2VydFRleHQodGV4dFRvQWRkKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IHJhbmdlID0gdGhpcy5nZXRSYW5nZSgpO1xuICAgICAgICAgICAgc2VsZWN0ZWRUZXh0ID0gJ2AnICsgc2VsZWN0ZWRUZXh0ICsgJ2AnO1xuICAgICAgICAgICAgdGhpcy5yZXBsYWNlKHJhbmdlLCBzZWxlY3RlZFRleHQpO1xuICAgICAgICAgICAgdGhpcy5mb2N1cygpO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSWNvblByb3AgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuaW1wb3J0IHsgZmFMaXN0VWwgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gJy4vY29tbWFuZCc7XG5cbmV4cG9ydCBjbGFzcyBVbm9yZGVyZWRMaXN0Q29tbWFuZCBleHRlbmRzIENvbW1hbmQge1xuICAgIGJ1dHRvbkljb24gPSBmYUxpc3RVbCBhcyBJY29uUHJvcDtcbiAgICBidXR0b25UcmFuc2xhdGlvblN0cmluZyA9ICdhcnRlbWlzQXBwLm11bHRpcGxlQ2hvaWNlUXVlc3Rpb24uZWRpdG9yLnVub3JkZXJlZExpc3QnO1xuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGV4ZWN1dGVcbiAgICAgKiBAZGVzYyBVc2UgdGhlIE1hcmtkb3duIGxhbmd1YWdlIGZvciBjcmVhdGluZyBhbiB1bm9yZGVyZWQgbGlzdFxuICAgICAqL1xuICAgIGV4ZWN1dGUoKTogdm9pZCB7XG4gICAgICAgIGNvbnN0IGV4dGVuZGVkVGV4dCA9IHRoaXMuZ2V0RXh0ZW5kZWRTZWxlY3RlZFRleHQoKTtcbiAgICAgICAgdGhpcy5oYW5kbGVNYW5pcHVsYXRpb24oZXh0ZW5kZWRUZXh0KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBQZXJmb3JtcyB0aGUgbmVjZXNzYXJ5IG1hbmlwdWxhdGlvbnMuXG4gICAgICogQHBhcmFtIGV4dGVuZGVkVGV4dCB0aGUgZXh0ZW5kZWQgdGV4dFxuICAgICAqL1xuICAgIGhhbmRsZU1hbmlwdWxhdGlvbihleHRlbmRlZFRleHQ6IHN0cmluZ1tdKTogdm9pZCB7XG4gICAgICAgIGxldCBtYW5pcHVsYXRlZFRleHQgPSAnJztcblxuICAgICAgICBleHRlbmRlZFRleHQuZm9yRWFjaCgobGluZSwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgIC8vIFNwZWNpYWwgY2FzZTogU2luZ2xlIGVtcHR5IGxpbmVcbiAgICAgICAgICAgIGlmIChsaW5lID09PSAnJykge1xuICAgICAgICAgICAgICAgIGlmIChleHRlbmRlZFRleHQubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgIG1hbmlwdWxhdGVkVGV4dCA9ICctICc7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIG1hbmlwdWxhdGVkVGV4dCArPSB0aGlzLm1hbmlwdWxhdGVMaW5lKGxpbmUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoaW5kZXggIT09IGV4dGVuZGVkVGV4dC5sZW5ndGggLSAxKSB7XG4gICAgICAgICAgICAgICAgbWFuaXB1bGF0ZWRUZXh0ICs9ICdcXG4nO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5yZXBsYWNlKHRoaXMuZ2V0UmFuZ2UoKSwgbWFuaXB1bGF0ZWRUZXh0KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBNYW5pcHVsYXRlcyBhIGdpdmVuIGxpbmUgYW5kIGFkZHMgb3IgcmVtb3ZlcyB0aGUgLSBhdCB0aGUgYmVnaW5uaW5nLlxuICAgICAqIEBwYXJhbSBsaW5lIHRvIG1hbmlwdWxhdGVcbiAgICAgKiBAcmV0dXJuIG1hbmlwdWxhdGVkIGxpbmVcbiAgICAgKi9cbiAgICBtYW5pcHVsYXRlTGluZShsaW5lOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgICAgICBjb25zdCBpbmRleCA9IGxpbmUuaW5kZXhPZignLScpO1xuXG4gICAgICAgIC8vIENhbGMgbGVhZGluZyB3aGl0ZXNwYWNlc1xuICAgICAgICBjb25zdCB3aGl0ZXNwYWNlcyA9IGxpbmUuc2VhcmNoKC9cXFN8JC8pO1xuXG4gICAgICAgIC8vIFRoZXJlIGlzIC0gaW4gdGhpcyBsaW5lXG4gICAgICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgICAgICAgIGNvbnN0IGVsZW1lbnRzID0gW2xpbmUuc2xpY2Uod2hpdGVzcGFjZXMsIGluZGV4KSwgbGluZS5zbGljZShpbmRleCArIDEpXTtcblxuICAgICAgICAgICAgLy8gQ2hlY2sgaWYgdGhpcyBpcyB0aGUgZmlyc3QgLVxuICAgICAgICAgICAgaWYgKGVsZW1lbnRzWzBdID09PSAnJyAmJiBlbGVtZW50c1sxXS5sZW5ndGggPj0gMSAmJiBlbGVtZW50c1sxXS5zdGFydHNXaXRoKCcgJykpIHtcbiAgICAgICAgICAgICAgICAvLyBBZGQgd2hpdGVzcGFjZXMgYW5kIHJlbW92ZSBmaXJzdCB3aGl0ZXNwYWNlIGFmdGVyIHRoZSBkb3RcbiAgICAgICAgICAgICAgICByZXR1cm4gJyAnLnJlcGVhdCh3aGl0ZXNwYWNlcykgKyBlbGVtZW50c1sxXS5zdWJzdHJpbmcoMSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBBZGQgdGhlIC1cbiAgICAgICAgcmV0dXJuICcgJy5yZXBlYXQod2hpdGVzcGFjZXMpICsgYC0gJHtsaW5lLnN1YnN0cmluZyh3aGl0ZXNwYWNlcyl9YDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBJY29uUHJvcCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1zdmctY29yZSc7XG5pbXBvcnQgeyBmYUhlYWRpbmcgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2NvbW1hbmQnO1xuXG5leHBvcnQgY2xhc3MgSGVhZGluZ1RocmVlQ29tbWFuZCBleHRlbmRzIENvbW1hbmQge1xuICAgIGJ1dHRvbkljb24gPSBmYUhlYWRpbmcgYXMgSWNvblByb3A7XG4gICAgYnV0dG9uVHJhbnNsYXRpb25TdHJpbmcgPSAnYXJ0ZW1pc0FwcC5tdWx0aXBsZUNob2ljZVF1ZXN0aW9uLmVkaXRvci5oZWFkaW5nVGhyZWUnO1xuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGV4ZWN1dGVcbiAgICAgKiBAZGVzYyBDcmVhdGUvUmVtb3ZlIGhlYWRpbmcgdGhyZWUgbGFuZ3VhZ2VcbiAgICAgKiAgICAgICAxLiBjaGVjayBpZiB0aGUgc2VsZWN0ZWQgdGV4dCBpbmNsdWRlcyAoIyMjKSBhbmQvb3IgKCdIZWFkaW5nIDMnKVxuICAgICAqICAgICAgIDIuIElmIGluY2x1ZGVkIHJlZHVjZSB0aGUgc2VsZWN0ZWQgdGV4dCBieSB0aGlzIGVsZW1lbnRzIGFuZCBhZGQgcmVwbGFjZSB0aGUgc2VsZWN0ZWQgdGV4dCBieSB0ZXh0VG9BZGRcbiAgICAgKiAgICAgICAzLiBJZiBub3QgaW5jbHVkZWQgIGFkZCAoIyMjKSBiZWZvcmUgdGhlIHNlbGVjdGVkIHRleHQgYW5kIGluc2VydCB0aGVtIGludG8gdGhlIGVkaXRvclxuICAgICAqICAgICAgIDQuIEhlYWRpbmcgdGhyZWUgaW4gbWFya2Rvd24gbGFuZ3VhZ2UgYXBwZWFyc1xuICAgICAqL1xuICAgIGV4ZWN1dGUoKTogdm9pZCB7XG4gICAgICAgIGxldCBzZWxlY3RlZFRleHQgPSB0aGlzLmdldFNlbGVjdGVkVGV4dCgpO1xuXG4gICAgICAgIGlmIChzZWxlY3RlZFRleHQuaW5jbHVkZXMoJyMjIycpICYmICFzZWxlY3RlZFRleHQuaW5jbHVkZXMoJ0hlYWRpbmcgMycpKSB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0VG9BZGQgPSBzZWxlY3RlZFRleHQuc2xpY2UoNCk7XG4gICAgICAgICAgICB0aGlzLmluc2VydFRleHQodGV4dFRvQWRkKTtcbiAgICAgICAgfSBlbHNlIGlmIChzZWxlY3RlZFRleHQuaW5jbHVkZXMoJyMjIycpICYmIHNlbGVjdGVkVGV4dC5pbmNsdWRlcygnSGVhZGluZyAzJykpIHtcbiAgICAgICAgICAgIGNvbnN0IHRleHRUb0FkZCA9IHNlbGVjdGVkVGV4dC5zbGljZSg0LCAtOSk7XG4gICAgICAgICAgICB0aGlzLmluc2VydFRleHQodGV4dFRvQWRkKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGluaXRUZXh0ID0gJ0hlYWRpbmcgMyc7XG4gICAgICAgICAgICBjb25zdCByYW5nZSA9IHRoaXMuZ2V0UmFuZ2UoKTtcbiAgICAgICAgICAgIHNlbGVjdGVkVGV4dCA9IGAjIyMgJHtzZWxlY3RlZFRleHQgfHwgaW5pdFRleHR9YDtcbiAgICAgICAgICAgIHRoaXMucmVwbGFjZShyYW5nZSwgc2VsZWN0ZWRUZXh0KTtcbiAgICAgICAgICAgIHRoaXMuZm9jdXMoKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImltcG9ydCB7IEljb25Qcm9wIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcbmltcG9ydCB7IGZhRmlsZUNvZGUgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gJy4vY29tbWFuZCc7XG5cbmV4cG9ydCBjbGFzcyBDb2RlQmxvY2tDb21tYW5kIGV4dGVuZHMgQ29tbWFuZCB7XG4gICAgYnV0dG9uSWNvbiA9IGZhRmlsZUNvZGUgYXMgSWNvblByb3A7XG4gICAgYnV0dG9uVHJhbnNsYXRpb25TdHJpbmcgPSAnYXJ0ZW1pc0FwcC5tdWx0aXBsZUNob2ljZVF1ZXN0aW9uLmVkaXRvci5jb2RlQmxvY2snO1xuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGV4ZWN1dGVcbiAgICAgKiBAZGVzYyBhZGQgKGBgYGphdmEpIGJlZm9yZSBhbmQgKGBgYCkgYWZ0ZXIgdGhlIHNlbGVjdGVkIHRleHRcbiAgICAgKi9cbiAgICBleGVjdXRlKCk6IHZvaWQge1xuICAgICAgICBsZXQgc2VsZWN0ZWRUZXh0ID0gdGhpcy5nZXRTZWxlY3RlZFRleHQoKTtcbiAgICAgICAgY29uc3QgcmFuZ2UgPSB0aGlzLmdldFJhbmdlKCk7XG4gICAgICAgIGNvbnN0IGluaXRUZXh0ID0gJ1NvdXJjZSBDb2RlJztcbiAgICAgICAgc2VsZWN0ZWRUZXh0ID0gJ2BgYGphdmFcXG4nICsgKHNlbGVjdGVkVGV4dCB8fCBpbml0VGV4dCkgKyAnXFxuYGBgJztcbiAgICAgICAgdGhpcy5yZXBsYWNlKHJhbmdlLCBzZWxlY3RlZFRleHQpO1xuICAgICAgICB0aGlzLmZvY3VzKCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2NvbW1hbmQnO1xuaW1wb3J0IHsgVmFsdWVJdGVtIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZC1jb25zdGFudHMnO1xuXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgTXVsdGlPcHRpb25Db21tYW5kIGV4dGVuZHMgQ29tbWFuZCB7XG4gICAgcHJvdGVjdGVkIHZhbHVlczogVmFsdWVJdGVtW10gPSBbXTtcblxuICAgIGdldFZhbHVlcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudmFsdWVzO1xuICAgIH1cblxuICAgIHNldFZhbHVlcyh2YWx1ZXM6IFZhbHVlSXRlbVtdKSB7XG4gICAgICAgIHRoaXMudmFsdWVzID0gdmFsdWVzO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IFF1aXpRdWVzdGlvbiwgUXVpelF1ZXN0aW9uVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L3F1aXotcXVlc3Rpb24ubW9kZWwnO1xuaW1wb3J0IHsgQW5zd2VyT3B0aW9uIH0gZnJvbSAnYXBwL2VudGl0aWVzL3F1aXovYW5zd2VyLW9wdGlvbi5tb2RlbCc7XG5cbmV4cG9ydCBjbGFzcyBNdWx0aXBsZUNob2ljZVF1ZXN0aW9uIGV4dGVuZHMgUXVpelF1ZXN0aW9uIHtcbiAgICBwdWJsaWMgYW5zd2VyT3B0aW9ucz86IEFuc3dlck9wdGlvbltdO1xuICAgIHB1YmxpYyBoYXNDb3JyZWN0T3B0aW9uPzogYm9vbGVhbjtcbiAgICBwdWJsaWMgc2luZ2xlQ2hvaWNlPzogYm9vbGVhbjtcblxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihRdWl6UXVlc3Rpb25UeXBlLk1VTFRJUExFX0NIT0lDRSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQmFzZUVudGl0eSB9IGZyb20gJ2FwcC9zaGFyZWQvbW9kZWwvYmFzZS1lbnRpdHknO1xuaW1wb3J0IHsgRXhlcmNpc2VIaW50RXhwbGFuYXRpb25JbnRlcmZhY2UgfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9xdWl6LXF1ZXN0aW9uLm1vZGVsJztcbmltcG9ydCB7IE11bHRpcGxlQ2hvaWNlUXVlc3Rpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9tdWx0aXBsZS1jaG9pY2UtcXVlc3Rpb24ubW9kZWwnO1xuaW1wb3J0IHsgQ2FuQmVjb21lSW52YWxpZCB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L2Ryb3AtbG9jYXRpb24ubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgQW5zd2VyT3B0aW9uIGltcGxlbWVudHMgQmFzZUVudGl0eSwgQ2FuQmVjb21lSW52YWxpZCwgRXhlcmNpc2VIaW50RXhwbGFuYXRpb25JbnRlcmZhY2Uge1xuICAgIHB1YmxpYyBpZD86IG51bWJlcjtcbiAgICBwdWJsaWMgdGV4dD86IHN0cmluZztcbiAgICBwdWJsaWMgaGludD86IHN0cmluZztcbiAgICBwdWJsaWMgZXhwbGFuYXRpb24/OiBzdHJpbmc7XG4gICAgcHVibGljIGlzQ29ycmVjdD86IGJvb2xlYW47XG4gICAgcHVibGljIHF1ZXN0aW9uPzogTXVsdGlwbGVDaG9pY2VRdWVzdGlvbjtcbiAgICBwdWJsaWMgaW52YWxpZCA9IGZhbHNlOyAvLyBkZWZhdWx0IHZhbHVlXG5cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5pc0NvcnJlY3QgPSBmYWxzZTsgLy8gZGVmYXVsdCB2YWx1ZVxuICAgICAgICB0aGlzLnRleHQgPSAnJzsgLy8gZGVmYXVsdCB2YWx1ZVxuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT3V0cHV0LCBWaWV3RW5jYXBzdWxhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTXVsdGlwbGVDaG9pY2VRdWVzdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L211bHRpcGxlLWNob2ljZS1xdWVzdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBmYUNoZWNrLCBmYUV4Y2xhbWF0aW9uQ2lyY2xlLCBmYUV4Y2xhbWF0aW9uVHJpYW5nbGUsIGZhUGx1cywgZmFRdWVzdGlvbkNpcmNsZSwgZmFUcmFzaCwgZmFYbWFyayB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBmYUNpcmNsZSwgZmFTcXVhcmUgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1yZWd1bGFyLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBBbnN3ZXJPcHRpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvcXVpei9hbnN3ZXItb3B0aW9uLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbXVsdGlwbGUtY2hvaWNlLXZpc3VhbC1xdWVzdGlvbicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL211bHRpcGxlLWNob2ljZS12aXN1YWwtcXVlc3Rpb24uY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL211bHRpcGxlLWNob2ljZS1xdWVzdGlvbi5jb21wb25lbnQuc2NzcycsICcuLi8uLi8uLi9wYXJ0aWNpcGF0ZS9xdWl6LXBhcnRpY2lwYXRpb24uc2NzcyddLFxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXG59KVxuZXhwb3J0IGNsYXNzIE11bHRpcGxlQ2hvaWNlVmlzdWFsUXVlc3Rpb25Db21wb25lbnQge1xuICAgIF9xdWVzdGlvbjogTXVsdGlwbGVDaG9pY2VRdWVzdGlvbjtcblxuICAgIEBJbnB1dCgpXG4gICAgc2V0IHF1ZXN0aW9uKHF1ZXN0aW9uOiBNdWx0aXBsZUNob2ljZVF1ZXN0aW9uKSB7XG4gICAgICAgIHRoaXMuX3F1ZXN0aW9uID0gcXVlc3Rpb247XG4gICAgfVxuICAgIGdldCBxdWVzdGlvbigpOiBNdWx0aXBsZUNob2ljZVF1ZXN0aW9uIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3F1ZXN0aW9uO1xuICAgIH1cblxuICAgIEBPdXRwdXQoKSBxdWVzdGlvbkNoYW5nZWQgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhUXVlc3Rpb25DaXJjbGUgPSBmYVF1ZXN0aW9uQ2lyY2xlO1xuICAgIGZhRXhjbGFtYXRpb25UcmlhbmdsZSA9IGZhRXhjbGFtYXRpb25UcmlhbmdsZTtcbiAgICBmYUV4Y2xhbWF0aW9uQ2lyY2xlID0gZmFFeGNsYW1hdGlvbkNpcmNsZTtcbiAgICBmYVNxdWFyZSA9IGZhU3F1YXJlO1xuICAgIGZhQ2hlY2sgPSBmYUNoZWNrO1xuICAgIGZhQ2lyY2xlID0gZmFDaXJjbGU7XG4gICAgZmFQbHVzID0gZmFQbHVzO1xuICAgIGZhVHJhc2ggPSBmYVRyYXNoO1xuICAgIGZhWG1hcmsgPSBmYVhtYXJrO1xuXG4gICAgY29uc3RydWN0b3IoKSB7fVxuXG4gICAgcGFyc2VRdWVzdGlvbigpIHtcbiAgICAgICAgbGV0IG1hcmtkb3duID0gdGhpcy5xdWVzdGlvbi50ZXh0ID8/ICcnO1xuXG4gICAgICAgIGlmICh0aGlzLnF1ZXN0aW9uLmhpbnQpIHtcbiAgICAgICAgICAgIG1hcmtkb3duICs9ICdcXG5cXHRbaGludF0gJyArIHRoaXMucXVlc3Rpb24uaGludDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5xdWVzdGlvbi5leHBsYW5hdGlvbikge1xuICAgICAgICAgICAgbWFya2Rvd24gKz0gJ1xcblxcdFtleHBdICcgKyB0aGlzLnF1ZXN0aW9uLmV4cGxhbmF0aW9uO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMucXVlc3Rpb24uYW5zd2VyT3B0aW9ucyAmJiB0aGlzLnF1ZXN0aW9uLmFuc3dlck9wdGlvbnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgbWFya2Rvd24gKz0gJ1xcbic7XG5cbiAgICAgICAgICAgIHRoaXMucXVlc3Rpb24uYW5zd2VyT3B0aW9ucy5mb3JFYWNoKChhbnN3ZXJPcHRpb24pID0+IHtcbiAgICAgICAgICAgICAgICBtYXJrZG93biArPSAnXFxuJyArIChhbnN3ZXJPcHRpb24uaXNDb3JyZWN0ID8gJ1tjb3JyZWN0XSAnIDogJ1t3cm9uZ10gJykgKyBhbnN3ZXJPcHRpb24udGV4dDtcblxuICAgICAgICAgICAgICAgIGlmIChhbnN3ZXJPcHRpb24uaGludCkge1xuICAgICAgICAgICAgICAgICAgICBtYXJrZG93biArPSAnXFxuXFx0W2hpbnRdICcgKyBhbnN3ZXJPcHRpb24uaGludDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGFuc3dlck9wdGlvbi5leHBsYW5hdGlvbikge1xuICAgICAgICAgICAgICAgICAgICBtYXJrZG93biArPSAnXFxuXFx0W2V4cF0gJyArIGFuc3dlck9wdGlvbi5leHBsYW5hdGlvbjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBtYXJrZG93bjtcbiAgICB9XG5cbiAgICBkZWxldGVBbnN3ZXIoaW5kZXg6IG51bWJlcikge1xuICAgICAgICB0aGlzLnF1ZXN0aW9uLmFuc3dlck9wdGlvbnM/LnNwbGljZShpbmRleCwgMSk7XG5cbiAgICAgICAgdGhpcy5xdWVzdGlvbkNoYW5nZWQuZW1pdCgpO1xuICAgIH1cblxuICAgIHRvZ2dsZUlzQ29ycmVjdChhbnN3ZXJPcHRpb246IEFuc3dlck9wdGlvbikge1xuICAgICAgICBpZiAodGhpcy5jb3JyZWN0VG9nZ2xlRGlzYWJsZWQoKSAmJiAhYW5zd2VyT3B0aW9uLmlzQ29ycmVjdCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgYW5zd2VyT3B0aW9uLmlzQ29ycmVjdCA9ICFhbnN3ZXJPcHRpb24uaXNDb3JyZWN0ID8/IHRydWU7XG5cbiAgICAgICAgdGhpcy5xdWVzdGlvbkNoYW5nZWQuZW1pdCgpO1xuICAgIH1cblxuICAgIGNvcnJlY3RUb2dnbGVEaXNhYmxlZCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucXVlc3Rpb24uc2luZ2xlQ2hvaWNlICYmIHRoaXMucXVlc3Rpb24uYW5zd2VyT3B0aW9ucz8uc29tZSgob3B0aW9uKSA9PiBvcHRpb24uaXNDb3JyZWN0KTtcbiAgICB9XG5cbiAgICBhZGROZXdBbnN3ZXIoKSB7XG4gICAgICAgIGlmICh0aGlzLnF1ZXN0aW9uLmFuc3dlck9wdGlvbnMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhpcy5xdWVzdGlvbi5hbnN3ZXJPcHRpb25zID0gW107XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLnF1ZXN0aW9uLmFuc3dlck9wdGlvbnM/LnB1c2gobmV3IEFuc3dlck9wdGlvbigpKTtcblxuICAgICAgICB0aGlzLnF1ZXN0aW9uQ2hhbmdlZC5lbWl0KCk7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cIm1hcmtkb3duLXByZXZpZXcgdmlzdWFsLW1vZGVcIj5cbiAgICA8aDQ+e3sgJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi52aXN1YWxFZGl0b3IucXVlc3Rpb25UaXRsZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9oND5cbiAgICA8dGV4dGFyZWFcbiAgICAgICAgaWQ9XCJtYy1xdWVzdGlvblwiXG4gICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sIGZvcm0tZ3JvdXAtbmFycm93XCJcbiAgICAgICAgWyhuZ01vZGVsKV09XCJ0aGlzLnF1ZXN0aW9uLnRleHRcIlxuICAgICAgICByb3dzPVwiNVwiXG4gICAgICAgIChpbnB1dCk9XCJ0aGlzLnF1ZXN0aW9uQ2hhbmdlZC5lbWl0KClcIlxuICAgICAgICBwbGFjZWhvbGRlcj1cInt7ICdhcnRlbWlzQXBwLm11bHRpcGxlQ2hvaWNlUXVlc3Rpb24udmlzdWFsRWRpdG9yLnRleHRQbGFjZWhvbGRlcicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XCJcbiAgICA+PC90ZXh0YXJlYT5cbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cC1uYXJyb3cgdmlzdWFsLXF1ZXN0aW9uLWhpbnRcIj5cbiAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFRdWVzdGlvbkNpcmNsZVwiIGNsYXNzPVwidGV4dC1zZWNvbmRhcnkgbWUtMVwiIG5nYlRvb2x0aXA9XCJ7eyAnYXJ0ZW1pc0FwcC5tdWx0aXBsZUNob2ljZVF1ZXN0aW9uLnZpc3VhbEVkaXRvci5oaW50VG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XCI+PC9mYS1pY29uPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCJcbiAgICAgICAgICAgIFsobmdNb2RlbCldPVwicXVlc3Rpb24uaGludFwiXG4gICAgICAgICAgICAoaW5wdXQpPVwidGhpcy5xdWVzdGlvbkNoYW5nZWQuZW1pdCgpXCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwie3sgJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi52aXN1YWxFZGl0b3IuaGludFBsYWNlaG9sZGVyJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIlxuICAgICAgICAvPlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwIHZpc3VhbC1xdWVzdGlvbi1oaW50XCI+XG4gICAgICAgIDxmYS1pY29uXG4gICAgICAgICAgICBbaWNvbl09XCJmYUV4Y2xhbWF0aW9uQ2lyY2xlXCJcbiAgICAgICAgICAgIGNsYXNzPVwidGV4dC1zZWNvbmRhcnkgbWUtMVwiXG4gICAgICAgICAgICBuZ2JUb29sdGlwPVwie3sgJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi52aXN1YWxFZGl0b3IuZXhwbGFuYXRpb25Ub29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIlxuICAgICAgICA+PC9mYS1pY29uPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCJcbiAgICAgICAgICAgIFsobmdNb2RlbCldPVwicXVlc3Rpb24uZXhwbGFuYXRpb25cIlxuICAgICAgICAgICAgKGlucHV0KT1cInRoaXMucXVlc3Rpb25DaGFuZ2VkLmVtaXQoKVwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cInt7ICdhcnRlbWlzQXBwLm11bHRpcGxlQ2hvaWNlUXVlc3Rpb24udmlzdWFsRWRpdG9yLmV4cGxhbmF0aW9uUGxhY2Vob2xkZXInIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVwiXG4gICAgICAgIC8+XG4gICAgPC9kaXY+XG4gICAgPGg0Pnt7ICdhcnRlbWlzQXBwLm11bHRpcGxlQ2hvaWNlUXVlc3Rpb24udmlzdWFsRWRpdG9yLmFuc3dlcnNUaXRsZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9oND5cbiAgICBAZm9yIChhbnN3ZXJPcHRpb24gb2YgcXVlc3Rpb24uYW5zd2VyT3B0aW9uczsgdHJhY2sgYW5zd2VyT3B0aW9uOyBsZXQgaSA9ICRpbmRleCkge1xuICAgICAgICA8ZGl2IGlkPVwiYW5zd2VyLW9wdGlvbi17eyBpIH19XCIgY2xhc3M9XCJ2aXN1YWwtYW5zd2VyLW9wdGlvbiBmb3JtLWdyb3VwLW5hcnJvd1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXAtbmFycm93IHZpc3VhbC1hbnN3ZXItcXVlc3Rpb24tY29udGFpbmVyXCI+XG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInZpc3VhbC1hbnN3ZXJcIlxuICAgICAgICAgICAgICAgICAgICBbbmdDbGFzc109XCJhbnN3ZXJPcHRpb24uaXNDb3JyZWN0ID8gJ3Zpc3VhbC1hbnN3ZXItY29ycmVjdC1jb250YWluZXInIDogJ3Zpc3VhbC1hbnN3ZXItd3JvbmctY29udGFpbmVyJ1wiXG4gICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJ0b2dnbGVJc0NvcnJlY3QoYW5zd2VyT3B0aW9uKVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJhbnN3ZXJPcHRpb24uaXNDb3JyZWN0ID8gZmFDaGVjayA6IGZhWG1hcmtcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCJcbiAgICAgICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJhbnN3ZXJPcHRpb24udGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIChpbnB1dCk9XCJ0aGlzLnF1ZXN0aW9uQ2hhbmdlZC5lbWl0KClcIlxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInt7ICdhcnRlbWlzQXBwLm11bHRpcGxlQ2hvaWNlUXVlc3Rpb24udmlzdWFsRWRpdG9yLnRleHRQbGFjZWhvbGRlcicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ2aXN1YWwtYW5zd2VyLWRlbGV0ZS1jb250YWluZXJcIiAoY2xpY2spPVwiZGVsZXRlQW5zd2VyKGkpXCI+XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhVHJhc2hcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwLW5hcnJvdyB2aXN1YWwtcXVlc3Rpb24taGludFwiPlxuICAgICAgICAgICAgICAgIDxmYS1pY29uXG4gICAgICAgICAgICAgICAgICAgIFtpY29uXT1cImZhUXVlc3Rpb25DaXJjbGVcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInRleHQtc2Vjb25kYXJ5IG1lLTFcIlxuICAgICAgICAgICAgICAgICAgICBuZ2JUb29sdGlwPVwie3sgJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi52aXN1YWxFZGl0b3IuaGludFRvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVwiXG4gICAgICAgICAgICAgICAgPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIlxuICAgICAgICAgICAgICAgICAgICBbKG5nTW9kZWwpXT1cImFuc3dlck9wdGlvbi5oaW50XCJcbiAgICAgICAgICAgICAgICAgICAgKGlucHV0KT1cInRoaXMucXVlc3Rpb25DaGFuZ2VkLmVtaXQoKVwiXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwie3sgJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi52aXN1YWxFZGl0b3IuaGludFBsYWNlaG9sZGVyJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ2aXN1YWwtcXVlc3Rpb24taGludFwiPlxuICAgICAgICAgICAgICAgIDxmYS1pY29uXG4gICAgICAgICAgICAgICAgICAgIFtpY29uXT1cImZhRXhjbGFtYXRpb25DaXJjbGVcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInRleHQtc2Vjb25kYXJ5IG1lLTFcIlxuICAgICAgICAgICAgICAgICAgICBuZ2JUb29sdGlwPVwie3sgJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi52aXN1YWxFZGl0b3IuZXhwbGFuYXRpb25Ub29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIlxuICAgICAgICAgICAgICAgID48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCJcbiAgICAgICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09XCJhbnN3ZXJPcHRpb24uZXhwbGFuYXRpb25cIlxuICAgICAgICAgICAgICAgICAgICAoaW5wdXQpPVwidGhpcy5xdWVzdGlvbkNoYW5nZWQuZW1pdCgpXCJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJ7eyAnYXJ0ZW1pc0FwcC5tdWx0aXBsZUNob2ljZVF1ZXN0aW9uLnZpc3VhbEVkaXRvci5leHBsYW5hdGlvblBsYWNlaG9sZGVyJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuICAgIDxidXR0b24gaWQ9XCJxdWl6LWFkZC1tYy1xdWVzdGlvblwiIGNsYXNzPVwiYnRuIGJ0bi1ibG9jayBidG4tc3VjY2VzcyBtdC0yXCIgKGNsaWNrKT1cImFkZE5ld0Fuc3dlcigpXCI+XG4gICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhUGx1c1wiPjwvZmEtaWNvbj5cbiAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5tdWx0aXBsZUNob2ljZVF1ZXN0aW9uLnZpc3VhbEVkaXRvci5uZXdBbnN3ZXJUaXRsZVwiPjwvc3Bhbj5cbiAgICA8L2J1dHRvbj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgTXVsdGlPcHRpb25Db21tYW5kIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvbXVsdGlPcHRpb25Db21tYW5kJztcbmltcG9ydCB7IE1ldGlzU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvbWV0aXMvbWV0aXMuc2VydmljZSc7XG5cbmV4cG9ydCBjbGFzcyBFeGVyY2lzZVJlZmVyZW5jZUNvbW1hbmQgZXh0ZW5kcyBNdWx0aU9wdGlvbkNvbW1hbmQge1xuICAgIG1ldGlzU2VydmljZTogTWV0aXNTZXJ2aWNlO1xuXG4gICAgYnV0dG9uVHJhbnNsYXRpb25TdHJpbmcgPSAnYXJ0ZW1pc0FwcC5tZXRpcy5lZGl0b3IuZXhlcmNpc2UnO1xuXG4gICAgY29uc3RydWN0b3IobWV0aXNTZXJ2aWNlOiBNZXRpc1NlcnZpY2UpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy5tZXRpc1NlcnZpY2UgPSBtZXRpc1NlcnZpY2U7XG5cbiAgICAgICAgdGhpcy5zZXRWYWx1ZXMoXG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLW5vbi1udWxsLWFzc2VydGVkLW9wdGlvbmFsLWNoYWluXG4gICAgICAgICAgICB0aGlzLm1ldGlzU2VydmljZS5nZXRDb3Vyc2UoKS5leGVyY2lzZXM/Lm1hcCgoZXhlcmNpc2UpID0+ICh7XG4gICAgICAgICAgICAgICAgaWQ6IGV4ZXJjaXNlLmlkIS50b1N0cmluZygpLFxuICAgICAgICAgICAgICAgIHZhbHVlOiBleGVyY2lzZS50aXRsZSEsXG4gICAgICAgICAgICAgICAgdHlwZTogZXhlcmNpc2UudHlwZSxcbiAgICAgICAgICAgIH0pKSEsXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGV4ZWN1dGVcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gc2VsZWN0ZWRFeGVyY2lzZUlkICAgSUQgb2YgdGhlIGV4ZXJjaXNlIHRvIGJlIHJlZmVyZW5jZWRcbiAgICAgKiBAZGVzYyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkIGFuIGV4ZXJjaXNlIHJlZmVyZW5jZSBsaW5rIGluIG1hcmtkb3duIGxhbmd1YWdlXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDEuIEFkZCAnW3tleGVyY2lzZS10aXRsZX1dKC9jb3Vyc2VzL3tjb3Vyc2VJZH0vZXhlcmNpc2VzL3tleGVyY2lzZUlkfX0pJyBhdCB0aGUgY3Vyc29yIGluIHRoZSBlZGl0b3JcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMi4gTGluayBpbiBtYXJrZG93biBsYW5ndWFnZSBhcHBlYXJzIHdoaWNoIHdoZW4gY2xpY2tlZCBuYXZpZ2F0ZXMgdG8gdGhlIGV4ZXJjaXNlIHBhZ2VcbiAgICAgKi9cbiAgICBleGVjdXRlKHNlbGVjdGVkRXhlcmNpc2VJZDogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIGNvbnN0IHNlbGVjdGVkRXhlcmNpc2UgPSB0aGlzLmdldFZhbHVlcygpLmZpbmQoKHZhbHVlKSA9PiB2YWx1ZS5pZC50b1N0cmluZygpID09PSBzZWxlY3RlZEV4ZXJjaXNlSWQpITtcbiAgICAgICAgY29uc3QgcmVmZXJlbmNlTGluayA9IGBbJHtzZWxlY3RlZEV4ZXJjaXNlLnR5cGV9XSR7c2VsZWN0ZWRFeGVyY2lzZS52YWx1ZX0oJHt0aGlzLm1ldGlzU2VydmljZS5nZXRMaW5rRm9yRXhlcmNpc2Uoc2VsZWN0ZWRFeGVyY2lzZS5pZCl9KVsvJHtzZWxlY3RlZEV4ZXJjaXNlLnR5cGV9XWA7XG4gICAgICAgIHRoaXMuaW5zZXJ0VGV4dChyZWZlcmVuY2VMaW5rKTtcbiAgICAgICAgdGhpcy5mb2N1cygpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE11bHRpT3B0aW9uQ29tbWFuZCB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL211bHRpT3B0aW9uQ29tbWFuZCc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBTZWxlY3RXaXRoU2VhcmNoQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3Ivc2VsZWN0LXdpdGgtc2VhcmNoL3NlbGVjdC13aXRoLXNlYXJjaC5jb21wb25lbnQnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFNlbGVjdGFibGVJdGVtIHtcbiAgICBuYW1lPzogc3RyaW5nO1xufVxuXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgSW50ZXJhY3RpdmVTZWFyY2hDb21tYW5kIGV4dGVuZHMgTXVsdGlPcHRpb25Db21tYW5kIHtcbiAgICBwcml2YXRlIHNlbGVjdFdpdGhTZWFyY2hDb21wb25lbnQ6IFNlbGVjdFdpdGhTZWFyY2hDb21wb25lbnQ7XG4gICAgZXhlY3V0ZSgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5hY2VFZGl0b3IuZXhlY0NvbW1hbmQodGhpcy5nZXRBc3NvY2lhdGVkSW5wdXRDaGFyYWN0ZXIoKSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzZWFyY2hQb3NpdGlvblN0YXJ0OiB7IHJvdzogbnVtYmVyOyBjb2x1bW46IG51bWJlciB9IHwgdW5kZWZpbmVkO1xuXG4gICAgc2V0RWRpdG9yKGFjZUVkaXRvcjogYW55KSB7XG4gICAgICAgIHN1cGVyLnNldEVkaXRvcihhY2VFZGl0b3IpO1xuXG4gICAgICAgIHRoaXMuYWNlRWRpdG9yLmNvbW1hbmRzLmFkZENvbW1hbmQoe1xuICAgICAgICAgICAgbmFtZTogdGhpcy5nZXRBc3NvY2lhdGVkSW5wdXRDaGFyYWN0ZXIoKSxcbiAgICAgICAgICAgIGJpbmRLZXk6IHsgd2luOiB0aGlzLmdldEFzc29jaWF0ZWRJbnB1dENoYXJhY3RlcigpLCBtYWM6IHRoaXMuZ2V0QXNzb2NpYXRlZElucHV0Q2hhcmFjdGVyKCkgfSxcbiAgICAgICAgICAgIGV4ZWM6IChlZGl0b3I6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLnNlYXJjaFBvc2l0aW9uU3RhcnQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGNvbnN0IGN1cnNvclBvc2l0aW9uID0gdGhpcy5nZXRDdXJzb3JQb3NpdGlvbigpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVDb250ZW50ID0gZWRpdG9yLnNlc3Npb24uZ2V0TGluZShjdXJzb3JQb3NpdGlvbi5yb3cpLnN1YnN0cmluZygwLCBjdXJzb3JQb3NpdGlvbi5jb2x1bW4pO1xuXG4gICAgICAgICAgICAgICAgZWRpdG9yLmluc2VydCh0aGlzLmdldEFzc29jaWF0ZWRJbnB1dENoYXJhY3RlcigpKTtcbiAgICAgICAgICAgICAgICBpZiAoY3Vyc29yUG9zaXRpb24uY29sdW1uID09PSAwIHx8IGxpbmVDb250ZW50LnNsaWNlKC0xKS5tYXRjaCgvXFxzLykpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZWFyY2hQb3NpdGlvblN0YXJ0ID0gY3Vyc29yUG9zaXRpb247XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0V2l0aFNlYXJjaENvbXBvbmVudD8ub3BlbigpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFjZUVkaXRvci5mb2N1cygpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0gYXMgYW55KTtcbiAgICB9XG5cbiAgICBzZXRTZWxlY3RXaXRoU2VhcmNoQ29tcG9uZW50KGNvbXBvbmVudDogU2VsZWN0V2l0aFNlYXJjaENvbXBvbmVudCkge1xuICAgICAgICB0aGlzLnNlbGVjdFdpdGhTZWFyY2hDb21wb25lbnQgPSBjb21wb25lbnQ7XG4gICAgfVxuXG4gICAgaW5zZXJ0U2VsZWN0aW9uKHNlbGVjdGVkOiBTZWxlY3RhYmxlSXRlbSB8IHVuZGVmaW5lZCkge1xuICAgICAgICBpZiAoc2VsZWN0ZWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgY29uc3QgY3Vyc29yUG9zaXRpb24gPSB0aGlzLmFjZUVkaXRvci5nZXRDdXJzb3JQb3NpdGlvbigpIGFzIHsgcm93OiBudW1iZXI7IGNvbHVtbjogbnVtYmVyIH07XG5cbiAgICAgICAgICAgIHRoaXMuYWNlRWRpdG9yLnNlc3Npb25cbiAgICAgICAgICAgICAgICAuZ2V0RG9jdW1lbnQoKVxuICAgICAgICAgICAgICAgIC5yZW1vdmVJbkxpbmUoY3Vyc29yUG9zaXRpb24ucm93LCB0aGlzLnNlYXJjaFBvc2l0aW9uU3RhcnQ/LnJvdyA9PT0gY3Vyc29yUG9zaXRpb24ucm93ID8gdGhpcy5zZWFyY2hQb3NpdGlvblN0YXJ0LmNvbHVtbiA6IDAsIGN1cnNvclBvc2l0aW9uLmNvbHVtbik7XG5cbiAgICAgICAgICAgIHRoaXMuc2VhcmNoUG9zaXRpb25TdGFydCA9IHVuZGVmaW5lZDtcblxuICAgICAgICAgICAgdGhpcy5pbnNlcnRUZXh0KHRoaXMuc2VsZWN0aW9uVG9UZXh0KHNlbGVjdGVkKSk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLnNlYXJjaFBvc2l0aW9uU3RhcnQgPSB1bmRlZmluZWQ7XG4gICAgICAgIHRoaXMuYWNlRWRpdG9yLmZvY3VzKCk7XG4gICAgfVxuXG4gICAgYWJzdHJhY3QgcGVyZm9ybVNlYXJjaChzZWFyY2hUZXJtOiBzdHJpbmcpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxTZWxlY3RhYmxlSXRlbVtdPj47XG5cbiAgICBwcm90ZWN0ZWQgYWJzdHJhY3Qgc2VsZWN0aW9uVG9UZXh0KHNlbGVjdGVkOiBhbnkpOiBzdHJpbmc7XG5cbiAgICBwcm90ZWN0ZWQgYWJzdHJhY3QgZ2V0QXNzb2NpYXRlZElucHV0Q2hhcmFjdGVyKCk6IHN0cmluZztcblxuICAgIGdldEN1cnNvclNjcmVlblBvc2l0aW9uKCk6IGFueSB7XG4gICAgICAgIGNvbnN0IGN1cnNvclBvc2l0aW9uID0gc3VwZXIuZ2V0Q3Vyc29yUG9zaXRpb24oKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuYWNlRWRpdG9yLnJlbmRlcmVyLnRleHRUb1NjcmVlbkNvb3JkaW5hdGVzKGN1cnNvclBvc2l0aW9uLnJvdywgY3Vyc29yUG9zaXRpb24uY29sdW1uKTtcbiAgICB9XG5cbiAgICB1cGRhdGVTZWFyY2hUZXJtKCkge1xuICAgICAgICBpZiAoIXRoaXMuc2VhcmNoUG9zaXRpb25TdGFydCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgY3Vyc29yUG9zaXRpb24gPSB0aGlzLmFjZUVkaXRvci5nZXRDdXJzb3JQb3NpdGlvbigpO1xuICAgICAgICBjb25zdCBsaW5lQ29udGVudCA9IHRoaXMuYWNlRWRpdG9yLnNlc3Npb24uZ2V0TGluZShjdXJzb3JQb3NpdGlvbi5yb3cpO1xuXG4gICAgICAgIGNvbnN0IGxhc3RBdEluZGV4ID0gbGluZUNvbnRlbnRcbiAgICAgICAgICAgIC5zdWJzdHJpbmcoY3Vyc29yUG9zaXRpb24ucm93ID09PSB0aGlzLnNlYXJjaFBvc2l0aW9uU3RhcnQucm93ID8gdGhpcy5zZWFyY2hQb3NpdGlvblN0YXJ0LmNvbHVtbiA6IDAsIGN1cnNvclBvc2l0aW9uLmNvbHVtbiArIDEpXG4gICAgICAgICAgICAubGFzdEluZGV4T2YodGhpcy5nZXRBc3NvY2lhdGVkSW5wdXRDaGFyYWN0ZXIoKSk7XG5cbiAgICAgICAgaWYgKGxhc3RBdEluZGV4ID49IDApIHtcbiAgICAgICAgICAgIGNvbnN0IHNlYXJjaFRlcm0gPSBsaW5lQ29udGVudFxuICAgICAgICAgICAgICAgIC5zdWJzdHJpbmcoMCwgY3Vyc29yUG9zaXRpb24uY29sdW1uICsgMSlcbiAgICAgICAgICAgICAgICAuc3BsaXQodGhpcy5nZXRBc3NvY2lhdGVkSW5wdXRDaGFyYWN0ZXIoKSlcbiAgICAgICAgICAgICAgICAucG9wKCk7XG5cbiAgICAgICAgICAgIHRoaXMuc2VsZWN0V2l0aFNlYXJjaENvbXBvbmVudC51cGRhdGVTZWFyY2hUZXJtKHNlYXJjaFRlcm0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RXaXRoU2VhcmNoQ29tcG9uZW50LmNsb3NlKCk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDaGFuZ2VEZXRlY3RvclJlZiwgQ29tcG9uZW50LCBFbGVtZW50UmVmLCBJbnB1dCwgT25DaGFuZ2VzLCBPbkRlc3Ryb3ksIE9uSW5pdCwgU2ltcGxlQ2hhbmdlcywgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJbnRlcmFjdGl2ZVNlYXJjaENvbW1hbmQsIFNlbGVjdGFibGVJdGVtIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvaW50ZXJhY3RpdmVTZWFyY2hDb21tYW5kJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5pbXBvcnQgeyBvbkVycm9yIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2dsb2JhbC51dGlscyc7XG5pbXBvcnQgeyBTdWJqZWN0LCBkZWJvdW5jZSwgZGlzdGluY3RVbnRpbENoYW5nZWQsIHN3aXRjaE1hcCwgdGFrZVVudGlsLCB0aW1lciB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE5nYkRyb3Bkb3duLCBOZ2JEcm9wZG93bkNvbmZpZyB9IGZyb20gJ0BuZy1ib290c3RyYXAvbmctYm9vdHN0cmFwJztcblxuaW50ZXJmYWNlIFNlYXJjaFF1ZXJ5IHtcbiAgICBzZWFyY2hUZXJtOiBzdHJpbmc7XG4gICAgbm9EZWJvdW5jZTogYm9vbGVhbjtcbn1cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktc2VsZWN0LXdpdGgtc2VhcmNoJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vc2VsZWN0LXdpdGgtc2VhcmNoLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9zZWxlY3Qtd2l0aC1zZWFyY2guY29tcG9uZW50LnNjc3MnXSxcbiAgICBwcm92aWRlcnM6IFtOZ2JEcm9wZG93bkNvbmZpZ10sXG59KVxuZXhwb3J0IGNsYXNzIFNlbGVjdFdpdGhTZWFyY2hDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcbiAgICBASW5wdXQoKSBjb21tYW5kOiBJbnRlcmFjdGl2ZVNlYXJjaENvbW1hbmQ7XG4gICAgQElucHV0KCkgZWRpdG9yQ29udGVudFN0cmluZzogc3RyaW5nO1xuXG4gICAgQFZpZXdDaGlsZChOZ2JEcm9wZG93bikgZHJvcGRvd246IE5nYkRyb3Bkb3duO1xuICAgIEBWaWV3Q2hpbGQoJ2Ryb3Bkb3duJykgZHJvcGRvd25SZWY6IEVsZW1lbnRSZWY7XG5cbiAgICBwcml2YXRlIG5nVW5zdWJzY3JpYmUgPSBuZXcgU3ViamVjdDx2b2lkPigpO1xuICAgIHByaXZhdGUgcmVhZG9ubHkgc2VhcmNoJCA9IG5ldyBTdWJqZWN0PFNlYXJjaFF1ZXJ5PigpO1xuXG4gICAgdmFsdWVzOiBTZWxlY3RhYmxlSXRlbVtdID0gW107XG4gICAgc2VsZWN0ZWRWYWx1ZTogU2VsZWN0YWJsZUl0ZW0gfCB1bmRlZmluZWQ7XG4gICAgb2Zmc2V0WDogc3RyaW5nO1xuICAgIG9mZnNldFk6IHN0cmluZztcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIHJlYWRvbmx5IGFsZXJ0U2VydmljZTogQWxlcnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHJlYWRvbmx5IGNkcjogQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gICAgKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuY29tbWFuZC5zZXRTZWxlY3RXaXRoU2VhcmNoQ29tcG9uZW50KHRoaXMpO1xuXG4gICAgICAgIHRoaXMuc2VhcmNoJFxuICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgZGVib3VuY2UoKHNlYXJjaFF1ZXJ5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aW1lcihzZWFyY2hRdWVyeS5ub0RlYm91bmNlID8gMCA6IDIwMCk7XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgZGlzdGluY3RVbnRpbENoYW5nZWQoKHByZXYsIGN1cnIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHByZXYgPT09IGN1cnI7XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgc3dpdGNoTWFwKChzZWFyY2hRdWVyeSkgPT4gdGhpcy5jb21tYW5kLnBlcmZvcm1TZWFyY2goc2VhcmNoUXVlcnkuc2VhcmNoVGVybSkpLFxuICAgICAgICAgICAgICAgIHRha2VVbnRpbCh0aGlzLm5nVW5zdWJzY3JpYmUpLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKHJlczogSHR0cFJlc3BvbnNlPFNlbGVjdGFibGVJdGVtW10+KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMudmFsdWVzID0gcmVzLmJvZHkhO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKGVycm9yUmVzcG9uc2U6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIG9uRXJyb3IodGhpcy5hbGVydFNlcnZpY2UsIGVycm9yUmVzcG9uc2UpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XG4gICAgICAgIGlmIChjaGFuZ2VzLmVkaXRvckNvbnRlbnRTdHJpbmcpIHtcbiAgICAgICAgICAgIHRoaXMuY29tbWFuZC51cGRhdGVTZWFyY2hUZXJtKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5uZ1Vuc3Vic2NyaWJlLm5leHQoKTtcbiAgICAgICAgdGhpcy5uZ1Vuc3Vic2NyaWJlLmNvbXBsZXRlKCk7XG4gICAgfVxuXG4gICAgb3BlbigpIHtcbiAgICAgICAgdGhpcy5kcm9wZG93bi5vcGVuKCk7XG4gICAgfVxuXG4gICAgY2xvc2UoKSB7XG4gICAgICAgIHRoaXMuZHJvcGRvd24uY2xvc2UoKTtcbiAgICB9XG5cbiAgICB1cGRhdGVTZWFyY2hUZXJtKHNlYXJjaElucHV0OiBzdHJpbmcgfCB1bmRlZmluZWQsIG5vRGVib3VuY2UgPSBmYWxzZSkge1xuICAgICAgICBjb25zdCBzZWFyY2hUZXJtID0gc2VhcmNoSW5wdXQ/LnRyaW0oKS50b0xvd2VyQ2FzZSgpID8/ICcnO1xuICAgICAgICB0aGlzLnNlYXJjaCQubmV4dCh7IHNlYXJjaFRlcm0sIG5vRGVib3VuY2UgfSk7XG4gICAgfVxuXG4gICAgaGFuZGxlTWVudU9wZW4oKSB7XG4gICAgICAgIGNvbnN0IGN1cnNvclBvc2l0aW9uID0gdGhpcy5jb21tYW5kLmdldEN1cnNvclNjcmVlblBvc2l0aW9uKCk7XG4gICAgICAgIGNvbnN0IGRyb3Bkb3duUG9zaXRpb24gPSB0aGlzLmRyb3Bkb3duUmVmLm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIHRoaXMub2Zmc2V0WCA9IGN1cnNvclBvc2l0aW9uLnBhZ2VYIC0gZHJvcGRvd25Qb3NpdGlvbi5sZWZ0ICsgJ3B4JztcbiAgICAgICAgdGhpcy5vZmZzZXRZID0gY3Vyc29yUG9zaXRpb24ucGFnZVkgLSBkcm9wZG93blBvc2l0aW9uLnRvcCArICdweCc7XG4gICAgICAgIHRoaXMudXBkYXRlU2VhcmNoVGVybSgnJywgdHJ1ZSk7XG4gICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcbiAgICB9XG5cbiAgICBoYW5kbGVNZW51Q2xvc2VkKCkge1xuICAgICAgICB0aGlzLmNvbW1hbmQuaW5zZXJ0U2VsZWN0aW9uKHRoaXMuc2VsZWN0ZWRWYWx1ZSk7XG4gICAgICAgIHRoaXMuc2VsZWN0ZWRWYWx1ZSA9IHVuZGVmaW5lZDtcbiAgICB9XG5cbiAgICBzZXRTZWxlY3Rpb24odmFsdWU6IGFueSkge1xuICAgICAgICB0aGlzLnNlbGVjdGVkVmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgdGhpcy5kcm9wZG93bi5jbG9zZSgpO1xuICAgIH1cblxuICAgIGhhbmRsZVRvZ2dsZSgpIHtcbiAgICAgICAgaWYgKHRoaXMuZHJvcGRvd24uaXNPcGVuKCkpIHtcbiAgICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuY29tbWFuZC5leGVjdXRlKCk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCI8ZGl2ICNkcm9wZG93biBuZ2JEcm9wZG93biBjbGFzcz1cImQtaW5saW5lLWJsb2NrXCIgKG9wZW5DaGFuZ2UpPVwiJGV2ZW50ID8gaGFuZGxlTWVudU9wZW4oKSA6IGhhbmRsZU1lbnVDbG9zZWQoKVwiIGF1dG9DbG9zZT1cImluc2lkZVwiIFtwbGFjZW1lbnRdPVwiWyd0b3Atc3RhcnQnXVwiPlxuICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuIGJ0bi1zbSBweS0wXCIgKGNsaWNrKT1cImhhbmRsZVRvZ2dsZSgpXCI+XG4gICAgICAgIDxmYS1pY29uIFtpY29uXT1cImNvbW1hbmQuYnV0dG9uSWNvblwiPjwvZmEtaWNvbj5cbiAgICA8L2J1dHRvbj5cbiAgICA8ZGl2IG5nYkRyb3Bkb3duQW5jaG9yIGlkPVwiYW5jaG9yXCIgY2xhc3M9XCJpbnZpc2libGUtYW5jaG9yXCIgW3N0eWxlLnRvcF09XCJvZmZzZXRZXCIgW3N0eWxlLmxlZnRdPVwib2Zmc2V0WFwiPjwvZGl2PlxuICAgIDxkaXYgbmdiRHJvcGRvd25NZW51PlxuICAgICAgICBAZm9yICh2YWx1ZSBvZiB2YWx1ZXM7IHRyYWNrIHZhbHVlKSB7XG4gICAgICAgICAgICA8YnV0dG9uIG5nYkRyb3Bkb3duSXRlbSB0eXBlPVwiYnV0dG9uXCIgKGNsaWNrKT1cInNldFNlbGVjdGlvbih2YWx1ZSlcIj57eyB2YWx1ZS5uYW1lIH19PC9idXR0b24+XG4gICAgICAgIH1cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgQWZ0ZXJWaWV3SW5pdCwgQ29tcG9uZW50LCBDb250ZW50Q2hpbGQsIEVsZW1lbnRSZWYsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE91dHB1dCwgVmlld0NoaWxkLCBWaWV3RW5jYXBzdWxhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU2FmZUh0bWwgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcbi8vIE5vdGU6IHRoaXMgaW1wb3J0IGhhcyB0byBiZSBiZWZvcmUgdGhlICdicmFjZScgaW1wb3J0c1xuaW1wb3J0IHsgQWNlRWRpdG9yQ29tcG9uZW50IH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvYWNlLWVkaXRvci9hY2UtZWRpdG9yLmNvbXBvbmVudCc7XG5pbXBvcnQgJ2JyYWNlL3RoZW1lL2Nocm9tZSc7XG5pbXBvcnQgJ2JyYWNlL21vZGUvbWFya2Rvd24nO1xuaW1wb3J0ICdicmFjZS9tb2RlL2xhdGV4JztcbmltcG9ydCAnYnJhY2UvZXh0L2xhbmd1YWdlX3Rvb2xzJztcbmltcG9ydCB7IEludGVyYWN0YWJsZSB9IGZyb20gJ0BpbnRlcmFjdGpzL2NvcmUvSW50ZXJhY3RhYmxlJztcbmltcG9ydCBpbnRlcmFjdCBmcm9tICdpbnRlcmFjdGpzJztcbmltcG9ydCB7IEFydGVtaXNNYXJrZG93blNlcnZpY2UgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLnNlcnZpY2UnO1xuaW1wb3J0IHsgRmlsZVVwbG9hZGVyU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvaHR0cC9maWxlLXVwbG9hZGVyLnNlcnZpY2UnO1xuaW1wb3J0IHsgQWxlcnRTZXJ2aWNlLCBBbGVydFR5cGUgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuaW1wb3J0IHsgQ29sb3JTZWxlY3RvckNvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvY29sb3Itc2VsZWN0b3IvY29sb3Itc2VsZWN0b3IuY29tcG9uZW50JztcbmltcG9ydCB7IERvbWFpblRhZ0NvbW1hbmQgfSBmcm9tICcuL2RvbWFpbkNvbW1hbmRzL2RvbWFpblRhZy5jb21tYW5kJztcbmltcG9ydCB7IGVzY2FwZVN0cmluZ0ZvclVzZUluUmVnZXggfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvZ2xvYmFsLnV0aWxzJztcbmltcG9ydCB7IFVuZGVybGluZUNvbW1hbmQgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy91bmRlcmxpbmUuY29tbWFuZCc7XG5pbXBvcnQgeyBDb2xvclBpY2tlckNvbW1hbmQgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9jb2xvclBpY2tlci5jb21tYW5kJztcbmltcG9ydCB7IEJvbGRDb21tYW5kIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvYm9sZC5jb21tYW5kJztcbmltcG9ydCB7IEF0dGFjaG1lbnRDb21tYW5kIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvYXR0YWNobWVudENvbW1hbmQnO1xuaW1wb3J0IHsgUmVmZXJlbmNlQ29tbWFuZCB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL3JlZmVyZW5jZS5jb21tYW5kJztcbmltcG9ydCB7IERvbWFpbk11bHRpT3B0aW9uQ29tbWFuZCB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2RvbWFpbkNvbW1hbmRzL2RvbWFpbk11bHRpT3B0aW9uQ29tbWFuZCc7XG5pbXBvcnQgeyBGdWxsc2NyZWVuQ29tbWFuZCB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2Z1bGxzY3JlZW4uY29tbWFuZCc7XG5pbXBvcnQgeyBIZWFkaW5nT25lQ29tbWFuZCB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2hlYWRpbmdPbmUuY29tbWFuZCc7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvY29tbWFuZCc7XG5pbXBvcnQgeyBJdGFsaWNDb21tYW5kIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvaXRhbGljLmNvbW1hbmQnO1xuaW1wb3J0IHsgT3JkZXJlZExpc3RDb21tYW5kIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvb3JkZXJlZExpc3RDb21tYW5kJztcbmltcG9ydCB7IEhlYWRpbmdUd29Db21tYW5kIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvaGVhZGluZ1R3by5jb21tYW5kJztcbmltcG9ydCB7IExpbmtDb21tYW5kIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvbGluay5jb21tYW5kJztcbmltcG9ydCB7IENvZGVDb21tYW5kIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvY29kZS5jb21tYW5kJztcbmltcG9ydCB7IERvbWFpbkNvbW1hbmQgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9kb21haW5Db21tYW5kcy9kb21haW5Db21tYW5kJztcbmltcG9ydCB7IFVub3JkZXJlZExpc3RDb21tYW5kIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi1lZGl0b3IvY29tbWFuZHMvdW5vcmRlcmVkTGlzdENvbW1hbmQnO1xuaW1wb3J0IHsgSGVhZGluZ1RocmVlQ29tbWFuZCB9IGZyb20gJ2FwcC9zaGFyZWQvbWFya2Rvd24tZWRpdG9yL2NvbW1hbmRzL2hlYWRpbmdUaHJlZS5jb21tYW5kJztcbmltcG9ydCB7IENvZGVCbG9ja0NvbW1hbmQgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9jb2RlYmxvY2suY29tbWFuZCc7XG5pbXBvcnQgeyBmYUFuZ2xlRG93biwgZmFBbmdsZVJpZ2h0LCBmYUdyaXBMaW5lcywgZmFRdWVzdGlvbkNpcmNsZSB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBNdWx0aU9wdGlvbkNvbW1hbmQgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9tdWx0aU9wdGlvbkNvbW1hbmQnO1xuaW1wb3J0IHsgdjQgYXMgdXVpZCB9IGZyb20gJ3V1aWQnO1xuaW1wb3J0IHsgTXVsdGlwbGVDaG9pY2VWaXN1YWxRdWVzdGlvbkNvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvcXVpei9zaGFyZWQvcXVlc3Rpb25zL211bHRpcGxlLWNob2ljZS1xdWVzdGlvbi9tdWx0aXBsZS1jaG9pY2UtdmlzdWFsLXF1ZXN0aW9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBFeGVyY2lzZVJlZmVyZW5jZUNvbW1hbmQgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9jb3Vyc2VBcnRpZmFjdFJlZmVyZW5jZUNvbW1hbmRzL2V4ZXJjaXNlUmVmZXJlbmNlQ29tbWFuZCc7XG5pbXBvcnQgeyBJbnRlcmFjdGl2ZVNlYXJjaENvbW1hbmQgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9jb21tYW5kcy9pbnRlcmFjdGl2ZVNlYXJjaENvbW1hbmQnO1xuXG5leHBvcnQgZW51bSBNYXJrZG93bkVkaXRvckhlaWdodCB7XG4gICAgSU5MSU5FID0gMTAwLFxuICAgIFNNQUxMID0gMjAwLFxuICAgIE1FRElVTSA9IDUwMCxcbiAgICBMQVJHRSA9IDEwMDAsXG4gICAgRVhUUkFfTEFSR0UgPSAxNTAwLFxufVxuXG5leHBvcnQgZW51bSBFZGl0b3JNb2RlIHtcbiAgICBOT05FID0gJ25vbmUnLFxuICAgIExBVEVYID0gJ2xhdGV4Jyxcbn1cblxuY29uc3QgZ2V0QWNlTW9kZSA9IChtb2RlOiBFZGl0b3JNb2RlKSA9PiB7XG4gICAgc3dpdGNoIChtb2RlKSB7XG4gICAgICAgIGNhc2UgRWRpdG9yTW9kZS5MQVRFWDpcbiAgICAgICAgICAgIHJldHVybiAnYWNlL21vZGUvbGF0ZXgnO1xuICAgICAgICBjYXNlIEVkaXRvck1vZGUuTk9ORTpcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufTtcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbWFya2Rvd24tZWRpdG9yJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vbWFya2Rvd24tZWRpdG9yLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9tYXJrZG93bi1lZGl0b3IuY29tcG9uZW50LnNjc3MnXSxcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxufSlcbmV4cG9ydCBjbGFzcyBNYXJrZG93bkVkaXRvckNvbXBvbmVudCBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQge1xuICAgIHB1YmxpYyBNdWx0aU9wdGlvbkNvbW1hbmQgPSBNdWx0aU9wdGlvbkNvbW1hbmQ7XG4gICAgcHVibGljIERvbWFpbk11bHRpT3B0aW9uQ29tbWFuZCA9IERvbWFpbk11bHRpT3B0aW9uQ29tbWFuZDtcbiAgICBwdWJsaWMgRG9tYWluVGFnQ29tbWFuZCA9IERvbWFpblRhZ0NvbW1hbmQ7XG4gICAgcHVibGljIEludGVyYWN0aXZlU2VhcmNoQ29tbWFuZCA9IEludGVyYWN0aXZlU2VhcmNoQ29tbWFuZDtcbiAgICAvLyBUaGlzIHJlZiBpcyB1c2VkIGZvciBlbnRlcmluZyB0aGUgZnVsbHNjcmVlbiBtb2RlLlxuICAgIEBWaWV3Q2hpbGQoJ3dyYXBwZXInLCB7IHJlYWQ6IEVsZW1lbnRSZWYsIHN0YXRpYzogZmFsc2UgfSkgd3JhcHBlcjogRWxlbWVudFJlZjtcbiAgICBAVmlld0NoaWxkKCdhY2VFZGl0b3InLCB7IHN0YXRpYzogZmFsc2UgfSlcbiAgICBhY2VFZGl0b3JDb250YWluZXI6IEFjZUVkaXRvckNvbXBvbmVudDtcbiAgICBhY2VFZGl0b3JPcHRpb25zID0ge1xuICAgICAgICBhdXRvVXBkYXRlQ29udGVudDogdHJ1ZSxcbiAgICAgICAgbW9kZTogJ21hcmtkb3duJyxcbiAgICB9O1xuICAgIEBWaWV3Q2hpbGQoQ29sb3JTZWxlY3RvckNvbXBvbmVudCwgeyBzdGF0aWM6IGZhbHNlIH0pIGNvbG9yU2VsZWN0b3I6IENvbG9yU2VsZWN0b3JDb21wb25lbnQ7XG5cbiAgICAvKioge3N0cmluZ30gd2hpY2ggaXMgaW5pdGlhbGx5IGRpc3BsYXllZCBpbiB0aGUgZWRpdG9yIGdlbmVyYXRlZCBhbmQgcGFzc2VkIG9uIGZyb20gdGhlIHBhcmVudCBjb21wb25lbnQqL1xuICAgIEBJbnB1dCgpIG1hcmtkb3duPzogc3RyaW5nO1xuICAgIEBJbnB1dCgpIGVkaXRvck1vZGUgPSBFZGl0b3JNb2RlLk5PTkU7XG4gICAgQElucHV0KCkgc2hvd0xpbmVOdW1iZXJzID0gZmFsc2U7XG4gICAgQE91dHB1dCgpIG1hcmtkb3duQ2hhbmdlID0gbmV3IEV2ZW50RW1pdHRlcjxzdHJpbmc+KCk7XG4gICAgQE91dHB1dCgpIGh0bWwgPSBuZXcgRXZlbnRFbWl0dGVyPFNhZmVIdG1sIHwgbnVsbD4oKTtcblxuICAgIC8qKiBkZWZhdWx0IGNvbG9ycyBmb3IgdGhlIG1hcmtkb3duIGVkaXRvciovXG4gICAgbWFya2Rvd25Db2xvcnMgPSBbJyNjYTIwMjQnLCAnIzNlYTExOScsICcjZmZmZmZmJywgJyMwMDAwMDAnLCAnI2ZmZmE1YycsICcjMGQzY2MyJywgJyNiMDVkYjgnLCAnI2Q4NmIxZiddO1xuICAgIHNlbGVjdGVkQ29sb3IgPSAnIzAwMDAwMCc7XG4gICAgLyoqIHthcnJheX0gY29udGFpbmluZyBhbGwgY29sb3JQaWNrZXJDb21tYW5kc1xuICAgICAqIElNUE9SVEFOVDogSWYgeW91IHdhbnQgdG8gdXNlIHRoZSBjb2xvcnBpY2tlciB5b3UgaGF2ZSB0byBpbXBsZW1lbnQgPGRpdiBjbGFzcz1cIm1hcmtkb3duLXByZXZpZXdcIj48L2Rpdj5cbiAgICAgKiBiZWNhdXNlIHRoZSBjbGFzcyBkZWZpbml0aW9ucyBhcmUgc2F2ZWQgd2l0aGluIHRoYXQgbWV0aG9kKi9cbiAgICBASW5wdXQoKSBjb2xvckNvbW1hbmRzOiBDb21tYW5kW10gPSBbbmV3IENvbG9yUGlja2VyQ29tbWFuZCgpXTtcblxuICAgIC8qKlxuICAgICAqIFVzZSB0aGlzIGFycmF5IGZvciBjb21tYW5kcyB0aGF0IGFyZSBub3QgcmVsYXRlZCB0byB0aGUgbWFya2Rvd24gYnV0IHRvIHRoZSBlZGl0b3IgKGUuZy4gZnVsbHNjcmVlbiBtb2RlKS5cbiAgICAgKiBUaGVzZSBlbGVtZW50cyB3aWxsIGJlIGRpc3BsYXllZCBvbiB0aGUgcmlnaHQgc2lkZSBvZiB0aGUgY29tbWFuZCBiYXIuXG4gICAgICovXG4gICAgQElucHV0KCkgbWV0YUNvbW1hbmRzOiBDb21tYW5kW10gPSBbbmV3IEZ1bGxzY3JlZW5Db21tYW5kKCldO1xuXG4gICAgLyoqIHthcnJheX0gY29udGFpbmluZyBhbGwgZGVmYXVsdCBjb21tYW5kcyBhY2Nlc3NpYmxlIGZvciB0aGUgZWRpdG9yIHBlciBkZWZhdWx0ICovXG4gICAgQElucHV0KCkgZGVmYXVsdENvbW1hbmRzOiBDb21tYW5kW10gPSBbXG4gICAgICAgIG5ldyBCb2xkQ29tbWFuZCgpLFxuICAgICAgICBuZXcgSXRhbGljQ29tbWFuZCgpLFxuICAgICAgICBuZXcgVW5kZXJsaW5lQ29tbWFuZCgpLFxuICAgICAgICBuZXcgUmVmZXJlbmNlQ29tbWFuZCgpLFxuICAgICAgICBuZXcgQ29kZUNvbW1hbmQoKSxcbiAgICAgICAgbmV3IENvZGVCbG9ja0NvbW1hbmQoKSxcbiAgICAgICAgbmV3IExpbmtDb21tYW5kKCksXG4gICAgICAgIG5ldyBBdHRhY2htZW50Q29tbWFuZCgpLFxuICAgICAgICBuZXcgT3JkZXJlZExpc3RDb21tYW5kKCksXG4gICAgICAgIG5ldyBVbm9yZGVyZWRMaXN0Q29tbWFuZCgpLFxuICAgIF07XG5cbiAgICAvKioge2FycmF5fSBjb250YWluaW5nIGFsbCBoZWFkZXIgY29tbWFuZHMgYWNjZXNzaWJsZSBmb3IgdGhlIG1hcmtkb3duIGVkaXRvciBwZXIgZGVmYXVsdCovXG4gICAgQElucHV0KCkgaGVhZGVyQ29tbWFuZHM6IENvbW1hbmRbXSA9IFtuZXcgSGVhZGluZ09uZUNvbW1hbmQoKSwgbmV3IEhlYWRpbmdUd29Db21tYW5kKCksIG5ldyBIZWFkaW5nVGhyZWVDb21tYW5kKCldO1xuXG4gICAgLyoqIHtkb21haW5Db21tYW5kc30gY29udGFpbmluZyBhbGwgZG9tYWluIGNvbW1hbmRzIHdoaWNoIG5lZWQgdG8gYmUgc2V0IGJ5IHRoZSBwYXJlbnQgY29tcG9uZW50IHdoaWNoIGNvbnRhaW5zIHRoZSBtYXJrZG93biBlZGl0b3IgKi9cbiAgICBASW5wdXQoKSBkb21haW5Db21tYW5kczogQXJyYXk8RG9tYWluQ29tbWFuZD47XG5cbiAgICAvKioge3RleHRXaXRoRG9tYWluQ29tbWFuZHNGb3VuZH0gZW1pdHMgYW4ge2FycmF5fSBvZiB0ZXh0IGxpbmVzIHdpdGggdGhlIGNvcnJlc3BvbmRpbmcgZG9tYWluIGNvbW1hbmQgdG8gdGhlIHBhcmVudCBjb21wb25lbnQgd2hpY2ggY29udGFpbnMgdGhlIG1hcmtkb3duIGVkaXRvciAqL1xuICAgIEBPdXRwdXQoKSB0ZXh0V2l0aERvbWFpbkNvbW1hbmRzRm91bmQgPSBuZXcgRXZlbnRFbWl0dGVyPFtzdHJpbmcsIERvbWFpbkNvbW1hbmQgfCBudWxsXVtdPigpO1xuXG4gICAgQE91dHB1dCgpIG9uUHJldmlld1NlbGVjdCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgICBAT3V0cHV0KCkgb25FZGl0U2VsZWN0ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gICAgLyoqIHtzaG93UHJldmlld0J1dHRvbn1cbiAgICAgKiAxLiB0cnVlIC0+IHRoZSBwcmV2aWV3IG9mIHRoZSBlZGl0b3IgaXMgdXNlZFxuICAgICAqIDIuIGZhbHNlIC0+IHRoZSBwcmV2aWV3IG9mIHRoZSBwYXJlbnQgY29tcG9uZW50IGlzIHVzZWQsIHBhcmVudCBoYXMgdG8gc2V0IHRoaXMgdmFsdWUgdG8gZmFsc2Ugd2l0aCBhbiBpbnB1dCAqL1xuICAgIEBJbnB1dCgpIHNob3dQcmV2aWV3QnV0dG9uID0gdHJ1ZTtcblxuICAgIC8qKlxuICAgICAqIHRydWUgLT4gdGhlIG1hcmtkb3duIGNvbnRlbnQgd2lsbCBiZSByZW5kZXJlZCBhbmQgc2hvd24sIHVzZWQgd2hlbiB0aGVyZSBhcmUgbm8gc3BlY2lhbCBhZGRpdGlvbnMgKGUuZy4gdGV4dCBleGVyY2lzZXMpXG4gICAgICogZmFsc2UgLT4gdGhlIHBhcmVudCBjb21wb25lbnQgYWRkcyBpdHMgb3duIHByZXZpZXcgY29udGVudCB3aXRoIGlkPXByZXZpZXcuIFVzZWQgZS5nLiBmb3IgcHJvZ3JhbW1pbmcgZXhlcmNpc2VzXG4gICAgICovXG4gICAgQElucHV0KCkgc2hvd0RlZmF1bHRQcmV2aWV3ID0gdHJ1ZTtcblxuICAgIEBJbnB1dCgpIHNob3dFZGl0QnV0dG9uID0gdHJ1ZTtcblxuICAgIEBJbnB1dCgpIHNob3dWaXN1YWxNb2RlQnV0dG9uID0gZmFsc2U7XG5cbiAgICAvKioge3ByZXZpZXdUZXh0QXNIdG1sfSB0ZXh0IHRoYXQgaXMgZW1pdHRlZCB0byB0aGUgcGFyZW50IGNvbXBvbmVudCBpZiB0aGUgcGFyZW50IGRvZXMgbm90IHVzZSBhbnkgZG9tYWluIGNvbW1hbmRzICovXG4gICAgcHJldmlld1RleHRBc0h0bWw6IFNhZmVIdG1sIHwgbnVsbDtcblxuICAgIC8qKiB7cHJldmlld01vZGV9IHdoZW4gZWRpdG9yIGlzIGNyZWF0ZWQgdGhlIHByZXZpZXcgaXMgc2V0IHRvIGZhbHNlLCBzaW5jZSB0aGUgZWRpdCBtb2RlIGlzIHNldCBhY3RpdmUgKi9cbiAgICBwcmV2aWV3TW9kZSA9IGZhbHNlO1xuXG4gICAgLyoqIHt2aXN1YWxNb2RlfSB3aGVuIGVkaXRvciBpcyBjcmVhdGVkIHRoZSB2aXN1YWwgbW9kZSBpcyBzZXQgdG8gZmFsc2UsIHNpbmNlIHRoZSBlZGl0IG1vZGUgaXMgc2V0IGFjdGl2ZSAqL1xuICAgIHZpc3VhbE1vZGUgPSBmYWxzZTtcbiAgICBASW5wdXQoKVxuICAgIG1pbkhlaWdodEVkaXRvciA9IE1hcmtkb3duRWRpdG9ySGVpZ2h0LlNNQUxMLnZhbHVlT2YoKTtcblxuICAgIEBDb250ZW50Q2hpbGQoTXVsdGlwbGVDaG9pY2VWaXN1YWxRdWVzdGlvbkNvbXBvbmVudCwgeyBzdGF0aWM6IGZhbHNlIH0pIHZpc3VhbENoaWxkOiBNdWx0aXBsZUNob2ljZVZpc3VhbFF1ZXN0aW9uQ29tcG9uZW50O1xuXG4gICAgLyoqIFJlc2l6YWJsZSBjb25zdGFudHMgKiovXG4gICAgQElucHV0KClcbiAgICBlbmFibGVSZXNpemUgPSB0cnVlO1xuICAgIEBJbnB1dCgpXG4gICAgcmVzaXphYmxlTWF4SGVpZ2h0ID0gTWFya2Rvd25FZGl0b3JIZWlnaHQuTEFSR0U7XG4gICAgQElucHV0KClcbiAgICByZXNpemFibGVNaW5IZWlnaHQgPSBNYXJrZG93bkVkaXRvckhlaWdodC5TTUFMTDtcbiAgICBpbnRlcmFjdFJlc2l6YWJsZTogSW50ZXJhY3RhYmxlO1xuXG4gICAgLyoqIHtlbmFibGVGaWxlVXBsb2FkfVxuICAgICAqIHdoZXRoZXIgdG8gc2hvdyB0aGUgZmlsZSB1cGxvYWQgZmllbGQgYW5kIGVuYWJsZSB0aGUgZHJhZyBhbmQgZHJvcCBmdW5jdGlvbmFsaXR5XG4gICAgICogZW5hYmxlZCBieSBkZWZhdWx0XG4gICAgICovXG4gICAgQElucHV0KClcbiAgICBlbmFibGVGaWxlVXBsb2FkID0gdHJ1ZTtcblxuICAgIC8vIEljb25zXG4gICAgZmFRdWVzdGlvbkNpcmNsZSA9IGZhUXVlc3Rpb25DaXJjbGU7XG4gICAgZmFHcmlwTGluZXMgPSBmYUdyaXBMaW5lcztcbiAgICBmYUFuZ2xlUmlnaHQgPSBmYUFuZ2xlUmlnaHQ7XG4gICAgZmFBbmdsZURvd24gPSBmYUFuZ2xlRG93bjtcblxuICAgIHVuaXF1ZU1hcmtkb3duRWRpdG9ySWQ6IHN0cmluZztcblxuICAgIGVkaXRvckNvbnRlbnRTdHJpbmc6IHN0cmluZztcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGFydGVtaXNNYXJrZG93bjogQXJ0ZW1pc01hcmtkb3duU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBmaWxlVXBsb2FkZXJTZXJ2aWNlOiBGaWxlVXBsb2FkZXJTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFsZXJ0U2VydmljZTogQWxlcnRTZXJ2aWNlLFxuICAgICkge1xuICAgICAgICB0aGlzLnVuaXF1ZU1hcmtkb3duRWRpdG9ySWQgPSAnbWFya2Rvd24tZWRpdG9yLScgKyB1dWlkKCk7XG4gICAgfVxuXG4gICAgLyoqIG9wZW5zIHRoZSBidXR0b24gZm9yIHNlbGVjdGluZyB0aGUgY29sb3IgKi9cbiAgICBvcGVuQ29sb3JTZWxlY3RvcihldmVudDogTW91c2VFdmVudCkge1xuICAgICAgICBjb25zdCBtYXJnaW5Ub3AgPSAzNTtcbiAgICAgICAgY29uc3QgaGVpZ2h0ID0gMTEwO1xuICAgICAgICB0aGlzLmNvbG9yU2VsZWN0b3Iub3BlbkNvbG9yU2VsZWN0b3IoZXZlbnQsIG1hcmdpblRvcCwgaGVpZ2h0KTtcbiAgICB9XG5cbiAgICAvKiogc2VsZWN0ZWQgdGV4dCBpcyBjaGFuZ2VkIGludG8gdGhlIGNob3NlbiBjb2xvciAqL1xuICAgIG9uU2VsZWN0ZWRDb2xvcihzZWxlY3RlZENvbG9yOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5zZWxlY3RlZENvbG9yID0gc2VsZWN0ZWRDb2xvcjtcbiAgICAgICAgdGhpcy5jb2xvckNvbW1hbmRzWzBdLmV4ZWN1dGUoc2VsZWN0ZWRDb2xvcik7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGFkZENvbW1hbmRcbiAgICAgKiBAcGFyYW0gY29tbWFuZFxuICAgICAqIEBkZXNjIGN1c3RvbWl6ZSB0aGUgdXNlciBpbnRlcmZhY2Ugb2YgdGhlIG1hcmtkb3duIGVkaXRvciBieSBhZGRpbmcgYSBjb21tYW5kXG4gICAgICovXG4gICAgYWRkQ29tbWFuZChjb21tYW5kOiBDb21tYW5kKSB7XG4gICAgICAgIHRoaXMuZGVmYXVsdENvbW1hbmRzLnB1c2goY29tbWFuZCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIHJlbW92ZUNvbW1hbmRcbiAgICAgKiBAcGFyYW0gY2xhc3NSZWYgQ29tbWFuZFxuICAgICAqIEBkZXNjIGN1c3RvbWl6ZSB0aGUgdXNlciBpbnRlcmZhY2Ugb2YgdGhlIG1hcmtkb3duIGVkaXRvciBieSByZW1vdmluZyBhIGNvbW1hbmRcbiAgICAgKi9cbiAgICByZW1vdmVDb21tYW5kKGNsYXNzUmVmOiB0eXBlb2YgQ29tbWFuZCkge1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+ICh0aGlzLmRlZmF1bHRDb21tYW5kcyA9IHRoaXMuZGVmYXVsdENvbW1hbmRzLmZpbHRlcigoZWxlbWVudCkgPT4gIShlbGVtZW50IGluc3RhbmNlb2YgY2xhc3NSZWYpKSkpO1xuICAgIH1cblxuICAgIGlzVHlwZU9mRXhlcmNpc2VSZWZlcmVuY2VDb21tYW5kKGNvbW1hbmRUb0NoZWNrOiBNdWx0aU9wdGlvbkNvbW1hbmQpIHtcbiAgICAgICAgcmV0dXJuIGNvbW1hbmRUb0NoZWNrIGluc3RhbmNlb2YgRXhlcmNpc2VSZWZlcmVuY2VDb21tYW5kO1xuICAgIH1cblxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcbiAgICAgICAgLy8gQ29tbWFuZHMgbWF5IHdhbnQgdG8gYWRkIGN1c3RvbSBjb21wbGV0ZXJzIC0gcmVtb3ZlIHN0YW5kYXJkIGNvbXBsZXRlcnMgb2YgdGhlIGFjZSBlZGl0b3IuXG4gICAgICAgIHRoaXMuYWNlRWRpdG9yQ29udGFpbmVyLmdldEVkaXRvcigpLnNldE9wdGlvbnMoe1xuICAgICAgICAgICAgZW5hYmxlQmFzaWNBdXRvY29tcGxldGlvbjogdHJ1ZSxcbiAgICAgICAgICAgIGVuYWJsZUxpdmVBdXRvY29tcGxldGlvbjogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuYWNlRWRpdG9yQ29udGFpbmVyLmdldEVkaXRvcigpLmNvbXBsZXRlcnMgPSBbXTtcblxuICAgICAgICBpZiAodGhpcy5kb21haW5Db21tYW5kcyA9PSB1bmRlZmluZWQgfHwgdGhpcy5kb21haW5Db21tYW5kcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIFsuLi50aGlzLmRlZmF1bHRDb21tYW5kcywgLi4udGhpcy5jb2xvckNvbW1hbmRzLCAuLi4odGhpcy5oZWFkZXJDb21tYW5kcyB8fCBbXSksIC4uLnRoaXMubWV0YUNvbW1hbmRzXS5mb3JFYWNoKChjb21tYW5kKSA9PiB7XG4gICAgICAgICAgICAgICAgY29tbWFuZC5zZXRFZGl0b3IodGhpcy5hY2VFZGl0b3JDb250YWluZXIuZ2V0RWRpdG9yKCkpO1xuICAgICAgICAgICAgICAgIGNvbW1hbmQuc2V0TWFya2Rvd25XcmFwcGVyKHRoaXMud3JhcHBlcik7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIFsuLi50aGlzLmRlZmF1bHRDb21tYW5kcywgLi4udGhpcy5kb21haW5Db21tYW5kcywgLi4udGhpcy5jb2xvckNvbW1hbmRzLCAuLi4odGhpcy5oZWFkZXJDb21tYW5kcyB8fCBbXSksIC4uLnRoaXMubWV0YUNvbW1hbmRzXS5mb3JFYWNoKChjb21tYW5kKSA9PiB7XG4gICAgICAgICAgICAgICAgY29tbWFuZC5zZXRFZGl0b3IodGhpcy5hY2VFZGl0b3JDb250YWluZXIuZ2V0RWRpdG9yKCkpO1xuICAgICAgICAgICAgICAgIGNvbW1hbmQuc2V0TWFya2Rvd25XcmFwcGVyKHRoaXMud3JhcHBlcik7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNldHVwTWFya2Rvd25FZGl0b3IoKTtcbiAgICAgICAgY29uc3Qgc2VsZWN0ZWRBY2VNb2RlID0gZ2V0QWNlTW9kZSh0aGlzLmVkaXRvck1vZGUpO1xuICAgICAgICBpZiAoc2VsZWN0ZWRBY2VNb2RlKSB7XG4gICAgICAgICAgICB0aGlzLmFjZUVkaXRvckNvbnRhaW5lci5nZXRFZGl0b3IoKS5nZXRTZXNzaW9uKCkuc2V0TW9kZShzZWxlY3RlZEFjZU1vZGUpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMuZW5hYmxlUmVzaXplKSB7XG4gICAgICAgICAgICB0aGlzLnNldHVwUmVzaXphYmxlKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBAZnVuY3Rpb24gc2V0dXBRdWVzdGlvbkVkaXRvclxuICAgICAqIEBkZXNjIEluaXRpYWxpemVzIHRoZSBhY2UgZWRpdG9yXG4gICAgICovXG4gICAgc2V0dXBNYXJrZG93bkVkaXRvcigpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5hY2VFZGl0b3JDb250YWluZXIuZ2V0RWRpdG9yKCkucmVuZGVyZXIuc2V0U2hvd0d1dHRlcih0aGlzLnNob3dMaW5lTnVtYmVycyk7XG4gICAgICAgIHRoaXMuYWNlRWRpdG9yQ29udGFpbmVyLmdldEVkaXRvcigpLnJlbmRlcmVyLnNldFBhZGRpbmcoMTApO1xuICAgICAgICB0aGlzLmFjZUVkaXRvckNvbnRhaW5lci5nZXRFZGl0b3IoKS5yZW5kZXJlci5zZXRTY3JvbGxNYXJnaW4oOCwgOCk7XG4gICAgICAgIHRoaXMuYWNlRWRpdG9yQ29udGFpbmVyLmdldEVkaXRvcigpLnNldEhpZ2hsaWdodEFjdGl2ZUxpbmUoZmFsc2UpO1xuICAgICAgICB0aGlzLmFjZUVkaXRvckNvbnRhaW5lci5nZXRFZGl0b3IoKS5zZXRTaG93UHJpbnRNYXJnaW4oZmFsc2UpO1xuICAgICAgICB0aGlzLmFjZUVkaXRvckNvbnRhaW5lci5nZXRFZGl0b3IoKS5jbGVhclNlbGVjdGlvbigpO1xuICAgICAgICB0aGlzLmFjZUVkaXRvckNvbnRhaW5lci5nZXRFZGl0b3IoKS5zZXRBdXRvU2Nyb2xsRWRpdG9ySW50b1ZpZXcodHJ1ZSk7XG4gICAgICAgIHRoaXMuYWNlRWRpdG9yQ29udGFpbmVyLmdldEVkaXRvcigpLnNldE9wdGlvbnMoeyB3cmFwOiB0cnVlIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEBmdW5jdGlvbiBzZXR1cFJlc2l6YWJsZVxuICAgICAqIEBkZXNjIFNldHMgdXAgcmVzaXphYmxlIHRvIGVuYWJsZSByZXNpemluZyBmb3IgdGhlIHVzZXJcbiAgICAgKi9cbiAgICBzZXR1cFJlc2l6YWJsZSgpOiB2b2lkIHtcbiAgICAgICAgLy8gVXNlIGEgdW5pcXVlLCByYW5kb20gSUQgdG8gc2VsZWN0IHRoZSBlZGl0b3JcbiAgICAgICAgLy8gVGhpcyBpcyByZXF1aXJlZCB0byBzZWxlY3QgdGhlIGNvcnJlY3Qgb25lIGluIGNhc2UgbXVsdGlwbGUgZWRpdG9ycyBhcmUgdXNlZCBhdCB0aGUgc2FtZSB0aW1lXG4gICAgICAgIGNvbnN0IHNlbGVjdG9yID0gJyMnICsgdGhpcy51bmlxdWVNYXJrZG93bkVkaXRvcklkO1xuXG4gICAgICAgIC8vIHVucmVnaXN0ZXIgcHJldmlvdXNseSBzZXQgZXZlbnQgbGlzdGVuZXJzIGZvciBjbGFzcyBlbGVtZW50c1xuICAgICAgICBpbnRlcmFjdChzZWxlY3RvcikudW5zZXQoKTtcblxuICAgICAgICB0aGlzLmludGVyYWN0UmVzaXphYmxlID0gaW50ZXJhY3Qoc2VsZWN0b3IpXG4gICAgICAgICAgICAucmVzaXphYmxlKHtcbiAgICAgICAgICAgICAgICAvLyBFbmFibGUgcmVzaXplIGZyb20gdG9wIGVkZ2U7IHRyaWdnZXJlZCBieSBjbGFzcyByZy10b3BcbiAgICAgICAgICAgICAgICBlZGdlczogeyBsZWZ0OiBmYWxzZSwgcmlnaHQ6IGZhbHNlLCBib3R0b206ICcucmctYm90dG9tJywgdG9wOiBmYWxzZSB9LFxuICAgICAgICAgICAgICAgIC8vIFNldCBtaW4gYW5kIG1heCBoZWlnaHRcbiAgICAgICAgICAgICAgICBtb2RpZmllcnM6IFtcbiAgICAgICAgICAgICAgICAgICAgaW50ZXJhY3QubW9kaWZpZXJzIS5yZXN0cmljdFNpemUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgbWluOiB7IHdpZHRoOiAwLCBoZWlnaHQ6IHRoaXMucmVzaXphYmxlTWluSGVpZ2h0IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXg6IHsgd2lkdGg6IDIwMDAsIGhlaWdodDogdGhpcy5yZXNpemFibGVNYXhIZWlnaHQgfSxcbiAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICBpbmVydGlhOiB0cnVlLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5vbigncmVzaXplc3RhcnQnLCBmdW5jdGlvbiAoZXZlbnQ6IGFueSkge1xuICAgICAgICAgICAgICAgIGV2ZW50LnRhcmdldC5jbGFzc0xpc3QuYWRkKCdjYXJkLXJlc2l6YWJsZScpO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5vbigncmVzaXplZW5kJywgKGV2ZW50OiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgICBldmVudC50YXJnZXQuY2xhc3NMaXN0LnJlbW92ZSgnY2FyZC1yZXNpemFibGUnKTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAub24oJ3Jlc2l6ZW1vdmUnLCAoZXZlbnQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LnRhcmdldDtcbiAgICAgICAgICAgICAgICAvLyBVcGRhdGUgZWxlbWVudCBoZWlnaHRcbiAgICAgICAgICAgICAgICB0YXJnZXQuc3R5bGUuaGVpZ2h0ID0gZXZlbnQucmVjdC5oZWlnaHQgKyAncHgnO1xuICAgICAgICAgICAgICAgIHRoaXMuYWNlRWRpdG9yQ29udGFpbmVyLmdldEVkaXRvcigpLnJlc2l6ZSgpO1xuICAgICAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUGFyc2VzIG1hcmtkb3duIHRvIGdlbmVyYXRlIGEgcHJldmlldyBpZiB0aGUgc3RhbmRhcmQgcHJldmlldyBpcyB1c2VkIGFuZC9vciBzZWFyY2hlcyBmb3IgZG9tYWluIGNvbW1hbmQgaWRlbnRpZmllcnMuXG4gICAgICogV2lsbCBlbWl0IGV2ZW50cyBmb3IgYm90aCB0aGUgZ2VuZXJhdGVkIHByZXZpZXcgYW5kIGRvbWFpbiBjb21tYW5kcy5cbiAgICAgKlxuICAgICAqL1xuICAgIHBhcnNlKCk6IHZvaWQge1xuICAgICAgICBpZiAodGhpcy5zaG93RGVmYXVsdFByZXZpZXcpIHtcbiAgICAgICAgICAgIHRoaXMucHJldmlld1RleHRBc0h0bWwgPSB0aGlzLmFydGVtaXNNYXJrZG93bi5zYWZlSHRtbEZvck1hcmtkb3duKHRoaXMubWFya2Rvd24pO1xuICAgICAgICAgICAgdGhpcy5odG1sLmVtaXQodGhpcy5wcmV2aWV3VGV4dEFzSHRtbCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuZG9tYWluQ29tbWFuZHMgJiYgdGhpcy5kb21haW5Db21tYW5kcy5sZW5ndGggJiYgdGhpcy5tYXJrZG93bikge1xuICAgICAgICAgICAgLyoqIGNyZWF0ZSBhcnJheSB3aXRoIGRvbWFpbiBjb21tYW5kIGlkZW50aWZpZXIgKi9cbiAgICAgICAgICAgIGNvbnN0IGRvbWFpbkNvbW1hbmRJZGVudGlmaWVyc1RvUGFyc2UgPSB0aGlzLmRvbWFpbkNvbW1hbmRzLm1hcCgoY29tbWFuZCkgPT4gY29tbWFuZC5nZXRPcGVuaW5nSWRlbnRpZmllcigpKTtcbiAgICAgICAgICAgIC8qKiBjcmVhdGUgZW1wdHkgYXJyYXkgd2hpY2hcbiAgICAgICAgICAgICAqIHdpbGwgY29udGFpbiB0aGUgc3BsaXR0ZWQgdGV4dCB3aXRoIHRoZSBjb3JyZXNwb25kaW5nIGRvbWFpbkNvbW1hbmRJZGVudGlmaWVyIHdoaWNoXG4gICAgICAgICAgICAgKiB3aWxsIGJlIGVtaXR0ZWQgdG8gdGhlIHBhcmVudCBjb21wb25lbnQgKi9cbiAgICAgICAgICAgIGNvbnN0IGNvbW1hbmRUZXh0c01hcHBlZFRvQ29tbWFuZElkZW50aWZpZXJzOiBbc3RyaW5nLCBEb21haW5Db21tYW5kIHwgbnVsbF1bXSA9IFtdO1xuICAgICAgICAgICAgLyoqIGNyZWF0ZSBhIHJlbWFpbmluZ01hcmtkb3duVGV4dCBvZiB0aGUgbWFya2Rvd24gdGV4dCB0byBsb29wIHRocm91Z2ggaXQgYW5kIGZpbmQgdGhlIGRvbWFpbkNvbW1hbmRJZGVudGlmaWVyICovXG4gICAgICAgICAgICBsZXQgcmVtYWluaW5nTWFya2Rvd25UZXh0ID0gdGhpcy5tYXJrZG93bi5zbGljZSgwKTtcblxuICAgICAgICAgICAgLyoqIGNyZWF0ZSBzdHJpbmcgd2l0aCB0aGUgaWRlbnRpZmllcnMgdG8gdXNlIGZvciBSZWdFeCBieSBkZWxldGluZyB0aGUgW10gb2YgdGhlIGRvbWFpbkNvbW1hbmRJZGVudGlmaWVycyAqL1xuICAgICAgICAgICAgY29uc3QgY29tbWFuZElkZW50aWZpZXJzU3RyaW5nID0gZG9tYWluQ29tbWFuZElkZW50aWZpZXJzVG9QYXJzZVxuICAgICAgICAgICAgICAgIC5tYXAoKHRhZykgPT4gdGFnLnJlcGxhY2UoJ1snLCAnJykucmVwbGFjZSgnXScsICcnKSlcbiAgICAgICAgICAgICAgICAubWFwKGVzY2FwZVN0cmluZ0ZvclVzZUluUmVnZXgpXG4gICAgICAgICAgICAgICAgLmpvaW4oJ3wnKTtcblxuICAgICAgICAgICAgLyoqIGNyZWF0ZSBhIG5ldyByZWdleCBleHByZXNzaW9uIHdoaWNoIHNlYXJjaGVzIGZvciB0aGUgZG9tYWluQ29tbWFuZHMgaWRlbnRpZmllcnNcbiAgICAgICAgICAgICAqICg/PSAgIElmIGEgY29tbWFuZCBpcyBmb3VuZCwgYWRkIHRoZSBjb21tYW5kIGlkZW50aWZpZXIgdG8gdGhlIHJlc3VsdCBvZiB0aGUgc3BsaXRcbiAgICAgICAgICAgICAqIFxcXFxbICBsb29rIGZvciB0aGUgY2hhcmFjdGVyICdbJyB0byBkZXRlcm1pbmUgdGhlIGJlZ2lubmluZyBvZiB0aGUgY29tbWFuZCBpZGVudGlmaWVyXG4gICAgICAgICAgICAgKiAoJHtjb21tYW5kSWRlbnRpZmllcnNTdHJpbmd9KSBsb29rIGlmIGFmdGVyIHRoZSAnWycgb25lIG9mIHRoZSBlbGVtZW50IG9mIGNvbW1hbmRJZGVudGlmaWVyc1N0cmluZyBpcyBjb250YWluZWRcbiAgICAgICAgICAgICAqIFxcXFxdIGxvb2sgZm9yIHRoZSBjaGFyYWN0ZXIgJ10nIHRvIGRldGVybWluZSB0aGUgZW5kIG9mIHRoZSBjb21tYW5kIGlkZW50aWZpZXJcbiAgICAgICAgICAgICAqICkgIGNsb3NlIHRoZSBicmFja2V0XG4gICAgICAgICAgICAgKiAgZzogc2VhcmNoIGluIHRoZSB3aG9sZSBzdHJpbmdcbiAgICAgICAgICAgICAqICBpOiBjYXNlIGluc2Vuc2l0aXZlLCBuZWdsZWN0aW5nIGNhcGl0YWwgbGV0dGVyc1xuICAgICAgICAgICAgICogIG06IG1hdGNoIHRoZSByZWdleCBvdmVyIG11bHRpcGxlIGxpbmVzKi9cbiAgICAgICAgICAgIGNvbnN0IHJlZ2V4ID0gbmV3IFJlZ0V4cChgKD89XFxcXFsoJHtjb21tYW5kSWRlbnRpZmllcnNTdHJpbmd9KVxcXFxdKWAsICdnbWknKTtcblxuICAgICAgICAgICAgLyoqIGl0ZXJhdGluZyBsb29wIGFzIGxvbmcgYXMgdGhlIHJlbWFpbmluZ01hcmtkb3duVGV4dCBvZiB0aGUgbWFya2Rvd24gdGV4dCBleGlzdHMgYW5kIHNwbGl0IHRoZSByZW1haW5pbmdNYXJrZG93blRleHQgd2hlbiBhIGRvbWFpbkNvbW1hbmQgaWRlbnRpZmllciBpcyBmb3VuZCAqL1xuICAgICAgICAgICAgd2hpbGUgKHJlbWFpbmluZ01hcmtkb3duVGV4dC5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAvKiogQXMgc29vbiBhcyBhbiBpZGVudGlmaWVyIGlzIHdpdGggcmVnRXggdGhlIHJlbWFpbmluZ01hcmtkb3duVGV4dCBvZiB0aGUgbWFya2Rvd24gdGV4dCBpcyBzcGxpdCBhbmQgc2F2ZWQgaW50byB7YXJyYXl9IHRleHRXaXRoQ29tbWFuZElkZW50aWZpZXJcbiAgICAgICAgICAgICAgICAgKiAgc3BsaXQ6IHNhdmVzIGl0cyB2YWx1ZXMgaW50byBhbiB7YXJyYXl9XG4gICAgICAgICAgICAgICAgICogIGxpbWl0IDE6IGluZGljYXRlZCB0aGF0IGFzIHNvb24gYXMgYW4gaWRlbnRpZmllciBpcyBmb3VuZCByZW1haW5pbmdNYXJrZG93blRleHQgaXMgc3BsaXQgKi9cbiAgICAgICAgICAgICAgICBjb25zdCBbdGV4dFdpdGhDb21tYW5kSWRlbnRpZmllcl0gPSByZW1haW5pbmdNYXJrZG93blRleHQuc3BsaXQocmVnZXgsIDEpO1xuICAgICAgICAgICAgICAgIC8qKiBzdWJzdHJpbmc6IHJlZHVjZXMgdGhlIHtzdHJpbmd9IGJ5IHRoZSBsZW5ndGggaW4gdGhlIGJyYWNrZXRzXG4gICAgICAgICAgICAgICAgICogIFNwbGl0IHRoZSByZW1haW5pbmdNYXJrZG93blRleHQgYnkgdGhlIGxlbmd0aCBvZiB7YXJyYXl9IHRleHRXaXRoQ29tbWFuZElkZW50aWZpZXIgdG8gZ2V0IHRoZSByZW1haW5pbmcgYXJyYXlcbiAgICAgICAgICAgICAgICAgKiAgYW5kIHNhdmUgaXQgaW50byByZW1haW5pbmdNYXJrZG93blRleHQgdG8gc3RhcnQgdGhlIGxvb3AgYWdhaW4gYW5kIHNlYXJjaCBmb3IgZnVydGhlciBkb21haW5Db21tYW5kSWRlbnRpZmllcnNcbiAgICAgICAgICAgICAgICAgKiAgd2hlbiByZW1haW5pbmdNYXJrZG93blRleHQgaXMgZW1wdHkgdGhlIHdoaWxlIGxvb3Agd2lsbCB0ZXJtaW5hdGUqL1xuICAgICAgICAgICAgICAgIHJlbWFpbmluZ01hcmtkb3duVGV4dCA9IHJlbWFpbmluZ01hcmtkb3duVGV4dC5zdWJzdHJpbmcodGV4dFdpdGhDb21tYW5kSWRlbnRpZmllci5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIC8qKiBjYWxsIHRoZSBwYXJzZUxpbmVGb3JEb21haW5Db21tYW5kIGZvciBlYWNoIGV4dHJhY3RlZCB0ZXh0V2l0aENvbW1hbmRJZGVudGlmaWVyXG4gICAgICAgICAgICAgICAgICogICB0cmltOiByZWR1Y2VkIHRoZSB3aGl0ZXNwYWNpbmcgbGluZWJyZWFrcyAqL1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvbW1hbmRUZXh0V2l0aENvbW1hbmRJZGVudGlmaWVyID0gdGhpcy5wYXJzZUxpbmVGb3JEb21haW5Db21tYW5kKHRleHRXaXRoQ29tbWFuZElkZW50aWZpZXIudHJpbSgpKTtcbiAgICAgICAgICAgICAgICAvKiogcHVzaCB0aGUgY29tbWFuZFRleHRXaXRoQ29tbWFuZElkZW50aWZpZXIgaW50byB0aGUgY29tbWFuZFRleHRzTWFwcGVkVG9Db21tYW5kSWRlbnRpZmllcnMqL1xuICAgICAgICAgICAgICAgIGNvbW1hbmRUZXh0c01hcHBlZFRvQ29tbWFuZElkZW50aWZpZXJzLnB1c2goY29tbWFuZFRleHRXaXRoQ29tbWFuZElkZW50aWZpZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLyoqIGVtaXQgdGhlIHthcnJheX0gY29tbWFuZFRleHRzTWFwcGVkVG9Db21tYW5kSWRlbnRpZmllcnMgdG8gdGhlIGNsaWVudCovXG4gICAgICAgICAgICB0aGlzLnRleHRXaXRoRG9tYWluQ29tbWFuZHNGb3VuZC5lbWl0KGNvbW1hbmRUZXh0c01hcHBlZFRvQ29tbWFuZElkZW50aWZpZXJzKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEBmdW5jdGlvbiBwYXJzZUxpbmVGb3JEb21haW5Db21tYW5kXG4gICAgICogQGRlc2MgQ291cGxlIGVhY2ggdGV4dCB3aXRoIHRoZSBkb21haW5Db21tYW5kSWRlbnRpZmllciB0byBlbWl0IHRoYXQgdG8gdGhlIHBhcmVudCBjb21wb25lbnQgZm9yIHRoZSB2YWx1ZSBhc3NpZ25tZW50XG4gICAgICogICAgICAgMS4gQ2hlY2sgd2hpY2ggZG9tYWluQ29tbWFuZCBpZGVudGlmaWVyIGlzIGNvbnRhaW5lZCB3aXRoaW4gdGhlIHRleHRcbiAgICAgKiAgICAgICAyLiBSZW1vdmUgdGhlIGRvbWFpbkNvbW1hbmQgaWRlbnRpZmllciBmcm9tIHRoZSB0ZXh0XG4gICAgICogICAgICAgMy4gQ3JlYXRlIGFuIGFycmF5IHdpdGggZmlyc3QgZWxlbWVudCB0ZXh0IGFuZCBzZWNvbmQgZWxlbWVudCB0aGUgZG9tYWluQ29tbWFuZCBpZGVudGlmaWVyXG4gICAgICogQHBhcmFtIHRleHQge3N0cmluZ30gZnJvbSB0aGUgcGFyc2UgZnVuY3Rpb25cbiAgICAgKiBAcmV0dXJuIGFycmF5IG9mIHRoZSB0ZXh0IHdpdGggdGhlIGRvbWFpbkNvbW1hbmQgaWRlbnRpZmllclxuICAgICAqL1xuICAgIHByaXZhdGUgcGFyc2VMaW5lRm9yRG9tYWluQ29tbWFuZCA9ICh0ZXh0OiBzdHJpbmcpOiBbc3RyaW5nLCBEb21haW5Db21tYW5kIHwgbnVsbF0gPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IGRvbWFpbkNvbW1hbmQgb2YgdGhpcy5kb21haW5Db21tYW5kcykge1xuICAgICAgICAgICAgY29uc3QgcG9zc2libGVPcGVuaW5nQ29tbWFuZElkZW50aWZpZXIgPSBbXG4gICAgICAgICAgICAgICAgZG9tYWluQ29tbWFuZC5nZXRPcGVuaW5nSWRlbnRpZmllcigpLFxuICAgICAgICAgICAgICAgIGRvbWFpbkNvbW1hbmQuZ2V0T3BlbmluZ0lkZW50aWZpZXIoKS50b0xvd2VyQ2FzZSgpLFxuICAgICAgICAgICAgICAgIGRvbWFpbkNvbW1hbmQuZ2V0T3BlbmluZ0lkZW50aWZpZXIoKS50b1VwcGVyQ2FzZSgpLFxuICAgICAgICAgICAgXTtcbiAgICAgICAgICAgIGlmIChwb3NzaWJsZU9wZW5pbmdDb21tYW5kSWRlbnRpZmllci5zb21lKChpZGVudGlmaWVyKSA9PiB0ZXh0LmluZGV4T2YoaWRlbnRpZmllcikgIT09IC0xKSkge1xuICAgICAgICAgICAgICAgIC8vIFRPRE8gd2hlbiBjbG9zaW5nSWRlbnRpZmllcnMgYXJlIHVzZWQgd3JpdGUgYSBtZXRob2QgdG8gZXh0cmFjdCB0aGVtIGZyb20gdGhlIHRleHRcbiAgICAgICAgICAgICAgICBjb25zdCB0cmltbWVkTGluZVdpdGhvdXRJZGVudGlmaWVyID0gcG9zc2libGVPcGVuaW5nQ29tbWFuZElkZW50aWZpZXIucmVkdWNlKChsaW5lLCBpZGVudGlmaWVyKSA9PiBsaW5lLnJlcGxhY2UoaWRlbnRpZmllciwgJycpLCB0ZXh0KS50cmltKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFt0cmltbWVkTGluZVdpdGhvdXRJZGVudGlmaWVyLCBkb21haW5Db21tYW5kXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gW3RleHQudHJpbSgpLCBudWxsXTtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIHRvZ2dsZVByZXZpZXdcbiAgICAgKiBAZGVzYyBUb2dnbGUgdGhlIHByZXZpZXcgaW4gdGhlIHRlbXBsYXRlIGFuZCBwYXJzZSB0aGUgdGV4dFxuICAgICAqL1xuICAgIGNoYW5nZU5hdmlnYXRpb24oZXZlbnQ6IGFueSk6IHZvaWQge1xuICAgICAgICB0aGlzLnByZXZpZXdNb2RlID0gZXZlbnQubmV4dElkID09PSAnZWRpdG9yX3ByZXZpZXcnO1xuICAgICAgICB0aGlzLnZpc3VhbE1vZGUgPSBldmVudC5uZXh0SWQgPT09ICdlZGl0b3JfdmlzdWFsJztcblxuICAgICAgICBpZiAodGhpcy5wcmV2aWV3TW9kZSkge1xuICAgICAgICAgICAgdGhpcy5vblByZXZpZXdTZWxlY3QuZW1pdCgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5vbkVkaXRTZWxlY3QuZW1pdCgpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGV2ZW50LmFjdGl2ZUlkID09PSAnZWRpdG9yX3Zpc3VhbCcgJiYgdGhpcy52aXN1YWxDaGlsZCkge1xuICAgICAgICAgICAgdGhpcy5tYXJrZG93biA9IHRoaXMudmlzdWFsQ2hpbGQucGFyc2VRdWVzdGlvbigpO1xuXG4gICAgICAgICAgICBpZiAodGhpcy5wcmV2aWV3TW9kZSkge1xuICAgICAgICAgICAgICAgIHRoaXMucGFyc2UoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFRoZSB0ZXh0IG11c3Qgb25seSBiZSBwYXJzZWQgd2hlbiB0aGUgYWN0aXZlIHRhYiBiZWZvcmUgZXZlbnQgd2FzIGVkaXQsIG90aGVyd2lzZSB0aGUgdGV4dCBjYW4ndCBoYXZlIGNoYW5nZWQuXG4gICAgICAgIGlmIChldmVudC5hY3RpdmVJZCA9PT0gJ2VkaXRvcl9lZGl0Jykge1xuICAgICAgICAgICAgdGhpcy5wYXJzZSgpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIG9uRmlsZVVwbG9hZFxuICAgICAqIEBkZXNjIGhhbmRsZSBmaWxlIHVwbG9hZCBmb3IgaW5wdXRcbiAgICAgKiBAcGFyYW0gZXZlbnRcbiAgICAgKi9cbiAgICBvbkZpbGVVcGxvYWQoZXZlbnQ6IGFueSk6IHZvaWQge1xuICAgICAgICBpZiAoZXZlbnQudGFyZ2V0LmZpbGVzLmxlbmd0aCA+PSAxKSB7XG4gICAgICAgICAgICB0aGlzLmVtYmVkRmlsZXMoQXJyYXkuZnJvbShldmVudC50YXJnZXQuZmlsZXMpKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEBmdW5jdGlvbiBvbkZpbGVEcm9wXG4gICAgICogQGRlc2MgaGFuZGxlIGRyb3Agb2YgZmlsZXNcbiAgICAgKiBAcGFyYW0ge0RyYWdFdmVudH0gZXZlbnRcbiAgICAgKi9cbiAgICBvbkZpbGVEcm9wKGV2ZW50OiBEcmFnRXZlbnQpOiB2b2lkIHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaWYgKGV2ZW50LmRhdGFUcmFuc2Zlcj8uaXRlbXMpIHtcbiAgICAgICAgICAgIC8vIFVzZSBEYXRhVHJhbnNmZXJJdGVtTGlzdCBpbnRlcmZhY2UgdG8gYWNjZXNzIHRoZSBmaWxlKHMpXG4gICAgICAgICAgICBjb25zdCBmaWxlcyA9IG5ldyBBcnJheTxGaWxlPigpO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBldmVudC5kYXRhVHJhbnNmZXIuaXRlbXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAvLyBJZiBkcm9wcGVkIGl0ZW1zIGFyZW4ndCBmaWxlcywgcmVqZWN0IHRoZW1cbiAgICAgICAgICAgICAgICBpZiAoZXZlbnQuZGF0YVRyYW5zZmVyLml0ZW1zW2ldLmtpbmQgPT09ICdmaWxlJykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWxlID0gZXZlbnQuZGF0YVRyYW5zZmVyLml0ZW1zW2ldLmdldEFzRmlsZSgpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZmlsZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmlsZXMucHVzaChmaWxlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuZW1iZWRGaWxlcyhmaWxlcyk7XG4gICAgICAgIH0gZWxzZSBpZiAoZXZlbnQuZGF0YVRyYW5zZmVyPy5maWxlcykge1xuICAgICAgICAgICAgLy8gVXNlIERhdGFUcmFuc2ZlciBpbnRlcmZhY2UgdG8gYWNjZXNzIHRoZSBmaWxlKHMpXG4gICAgICAgICAgICB0aGlzLmVtYmVkRmlsZXMoQXJyYXkuZnJvbShldmVudC5kYXRhVHJhbnNmZXIuZmlsZXMpKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEBmdW5jdGlvbiBvbkZpbGVQYXN0ZVxuICAgICAqIEBkZXNjIGhhbmRsZSBwYXN0ZSBvZiBmaWxlc1xuICAgICAqIEBwYXJhbSB7Q2xpcGJvYXJkRXZlbnR9IGV2ZW50XG4gICAgICovXG4gICAgb25GaWxlUGFzdGUoZXZlbnQ6IENsaXBib2FyZEV2ZW50KTogdm9pZCB7XG4gICAgICAgIGlmIChldmVudC5jbGlwYm9hcmREYXRhPy5pdGVtcykge1xuICAgICAgICAgICAgY29uc3QgaW1hZ2VzID0gbmV3IEFycmF5PEZpbGU+KCk7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGV2ZW50LmNsaXBib2FyZERhdGEuaXRlbXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBpZiAoZXZlbnQuY2xpcGJvYXJkRGF0YS5pdGVtc1tpXS5raW5kID09PSAnZmlsZScpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmlsZSA9IGV2ZW50LmNsaXBib2FyZERhdGEuaXRlbXNbaV0uZ2V0QXNGaWxlKCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChmaWxlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpbWFnZXMucHVzaChmaWxlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuZW1iZWRGaWxlcyhpbWFnZXMpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQGZ1bmN0aW9uIGVtYmVkRmlsZXNcbiAgICAgKiBAZGVzYyBnZW5lcmF0ZSBhbmQgZW1iZWQgbWFya2Rvd24gY29kZSBmb3IgZmlsZXNcbiAgICAgKiBAcGFyYW0ge0ZpbGVMaXN0fSBmaWxlc1xuICAgICAqL1xuICAgIGVtYmVkRmlsZXMoZmlsZXM6IEZpbGVbXSk6IHZvaWQge1xuICAgICAgICBjb25zdCBhY2VFZGl0b3IgPSB0aGlzLmFjZUVkaXRvckNvbnRhaW5lci5nZXRFZGl0b3IoKTtcbiAgICAgICAgZmlsZXMuZm9yRWFjaCgoZmlsZTogRmlsZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5maWxlVXBsb2FkZXJTZXJ2aWNlLnVwbG9hZE1hcmtkb3duRmlsZShmaWxlKS50aGVuKFxuICAgICAgICAgICAgICAgIChyZXMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXh0ZW5zaW9uID0gZmlsZS5uYW1lLnNwbGl0KCcuJykucG9wKCkhLnRvTG9jYWxlTG93ZXJDYXNlKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgbGV0IHRleHRUb0FkZCA9IGBbJHtmaWxlLm5hbWV9XSgke3Jlcy5wYXRofSlcXG5gO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXh0ZW5zaW9uICE9PSAncGRmJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2hvdyBmaWxlIGFzIGVtYmVkZGVkIGltYWdlXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0VG9BZGQgPSAnIScgKyB0ZXh0VG9BZGQ7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBhY2VFZGl0b3IuaW5zZXJ0KHRleHRUb0FkZCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAoZXJyb3I6IEVycm9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLmFkZEFsZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IEFsZXJ0VHlwZS5EQU5HRVIsXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBlcnJvci5tZXNzYWdlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZVRyYW5zbGF0aW9uOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgbWFya2Rvd25UZXh0Q2hhbmdlKHZhbHVlOiBhbnkpIHtcbiAgICAgICAgdGhpcy5tYXJrZG93biA9IHZhbHVlO1xuICAgICAgICB0aGlzLm1hcmtkb3duQ2hhbmdlLmVtaXQodmFsdWUgYXMgc3RyaW5nKTtcbiAgICB9XG59XG4iLCI8ZGl2ICN3cmFwcGVyIGNsYXNzPVwibWFya2Rvd24tZWRpdG9yLXdyYXBwZXJcIj5cbiAgICA8bmF2IG5nYk5hdiAjbmF2PVwibmdiTmF2XCIgY2xhc3M9XCJuYXYtdGFic1wiIFtkZXN0cm95T25IaWRlXT1cImZhbHNlXCIgKG5hdkNoYW5nZSk9XCJjaGFuZ2VOYXZpZ2F0aW9uKCRldmVudClcIj5cbiAgICAgICAgPCEtLSBlZGl0b3IgLS0+XG4gICAgICAgIDxuZy1jb250YWluZXIgbmdiTmF2SXRlbT1cImVkaXRvcl9lZGl0XCI+XG4gICAgICAgICAgICBAaWYgKHNob3dFZGl0QnV0dG9uKSB7XG4gICAgICAgICAgICAgICAgPGEgbmdiTmF2TGluayBjbGFzcz1cImJ0bi1zbSB0ZXh0LW5vcm1hbCBweC0yIHB5LTAgbS0wXCI+e3sgJ2VudGl0eS5hY3Rpb24uZWRpdCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9hPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5nYk5hdkNvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPGRpdiBbbmdTdHlsZV09XCJ7ICdtaW5IZWlnaHQucHgnOiBtaW5IZWlnaHRFZGl0b3IgfVwiIGNsYXNzPVwiaGVpZ2h0LTEwMCBtYXJrZG93bi1lZGl0b3IgZC1mbGV4IGZsZXgtY29sdW1uXCIgW2lkXT1cInVuaXF1ZU1hcmtkb3duRWRpdG9ySWRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGpoaS1hY2UtZWRpdG9yXG4gICAgICAgICAgICAgICAgICAgICAgICAjYWNlRWRpdG9yXG4gICAgICAgICAgICAgICAgICAgICAgICBbbW9kZV09XCJhY2VFZGl0b3JPcHRpb25zLm1vZGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW2F1dG9VcGRhdGVDb250ZW50XT1cImFjZUVkaXRvck9wdGlvbnMuYXV0b1VwZGF0ZUNvbnRlbnRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW3RleHRdPVwibWFya2Rvd24gfHwgJydcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKHRleHRDaGFuZ2UpPVwibWFya2Rvd25UZXh0Q2hhbmdlKCRldmVudClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtLWNvbnRyb2wgbWFya2Rvd24tZWRpdG9yX19jb250ZW50XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICh0ZXh0Q2hhbmdlZCk9XCJlZGl0b3JDb250ZW50U3RyaW5nID0gJGV2ZW50XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5maWxlLWlucHV0XT1cImVuYWJsZUZpbGVVcGxvYWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKGRyYWdvdmVyKT1cImVuYWJsZUZpbGVVcGxvYWQgPyAkZXZlbnQucHJldmVudERlZmF1bHQoKSA6ICcnXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIChkcm9wKT1cImVuYWJsZUZpbGVVcGxvYWQgPyBvbkZpbGVEcm9wKCRldmVudCkgOiAnJ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAocGFzdGUpPVwiZW5hYmxlRmlsZVVwbG9hZCA/IG9uRmlsZVBhc3RlKCRldmVudCkgOiAnJ1wiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPC9qaGktYWNlLWVkaXRvcj5cbiAgICAgICAgICAgICAgICAgICAgPCEtLSBtYW51YWwgaW5wdXQgZm9yIGZpbGUgdXBsb2FkIC0tPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKGVuYWJsZUZpbGVVcGxvYWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBpZD1cImZpbGUtdXBsb2FkXCIgY2xhc3M9XCJtYXJrZG93bi1lZGl0b3JfX2ZpbGUtaW5wdXRcIiB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cImltYWdlLypcIiBbbXVsdGlwbGVdPVwidHJ1ZVwiIChjaGFuZ2UpPVwib25GaWxlVXBsb2FkKCRldmVudClcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGZvcj1cImZpbGUtdXBsb2FkXCIgY2xhc3M9XCJtYXJrZG93bi1lZGl0b3JfX2ZpbGUtbGFiZWwgZC1pbmxpbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93IG14LTAgYWxpZ24taXRlbXMtYmFzZWxpbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJjb2wgdXBsb2FkLXN1YnRpdGxlXCI+e3sgJ2FydGVtaXNBcHAubWFya2Rvd25FZGl0b3IuZmlsZVVwbG9hZCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBjbGFzcz1cImNvbC1hdXRvXCIgaHJlZj1cImh0dHA6Ly9kZW1vLnNob3dkb3duanMuY29tXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVF1ZXN0aW9uQ2lyY2xlXCIgW25nYlRvb2x0aXBdPVwiJ2FydGVtaXNBcHAubWFya2Rvd25FZGl0b3IuZ3VpZGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8IS0tIFJlcXVpcmVkIGZvciByZXNpemluZzsgZG9uJ3QgcmVtb3ZlIGVtcHR5IHNwYW4gLS0+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoZW5hYmxlUmVzaXplKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUdyaXBMaW5lc1wiIGNsYXNzPVwicmctYm90dG9tIG1kLXJlc2l6ZS1pY29uXCI+PHNwYW4+PC9zcGFuPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgPC9uZy1jb250YWluZXI+XG4gICAgICAgIDwhLS0gdmlzdWFsIE1vZGUgLS0+XG4gICAgICAgIDxuZy1jb250YWluZXIgbmdiTmF2SXRlbT1cImVkaXRvcl92aXN1YWxcIj5cbiAgICAgICAgICAgIEBpZiAoc2hvd1Zpc3VhbE1vZGVCdXR0b24pIHtcbiAgICAgICAgICAgICAgICA8YSBuZ2JOYXZMaW5rIGNsYXNzPVwiYnRuLXNtIHRleHQtbm9ybWFsIHB4LTIgcHktMCBtLTBcIj57eyAnZW50aXR5LmFjdGlvbi52aXN1YWwnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvYT5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ2JOYXZDb250ZW50PlxuICAgICAgICAgICAgICAgIDxuZy1jb250ZW50IHNlbGVjdD1cIlsjdmlzdWFsXVwiPjwvbmctY29udGVudD5cbiAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgIDwvbmctY29udGFpbmVyPlxuICAgICAgICA8IS0tIHByZXZpZXcgLS0+XG4gICAgICAgIDxuZy1jb250YWluZXIgbmdiTmF2SXRlbT1cImVkaXRvcl9wcmV2aWV3XCI+XG4gICAgICAgICAgICBAaWYgKHNob3dQcmV2aWV3QnV0dG9uKSB7XG4gICAgICAgICAgICAgICAgPGEgbmdiTmF2TGluayBjbGFzcz1cImJ0bi1zbSB0ZXh0LW5vcm1hbCBweC0yIHB5LTAgbS0wXCI+e3sgJ2VudGl0eS5hY3Rpb24ucHJldmlldycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9hPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5nYk5hdkNvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPG5nLWNvbnRlbnQgc2VsZWN0PVwiWyNwcmV2aWV3XVwiPjwvbmctY29udGVudD5cbiAgICAgICAgICAgICAgICBAaWYgKHNob3dEZWZhdWx0UHJldmlldykge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicHQtMSBiYWNrZ3JvdW5kLWVkaXRvci1oaWdoIG1hcmtkb3duLXByZXZpZXdcIiBbaW5uZXJIVE1MXT1cInByZXZpZXdUZXh0QXNIdG1sXCIgW25nU3R5bGVdPVwieyAnbWluSGVpZ2h0LnB4JzogMC43NSAqIG1pbkhlaWdodEVkaXRvciB9XCI+UHJldmlldzwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgIDwvbmctY29udGFpbmVyPlxuICAgICAgICA8IS0tIGNvbW1hbmRzIC0tPlxuICAgICAgICBAaWYgKCFwcmV2aWV3TW9kZSAmJiAhdmlzdWFsTW9kZSkge1xuICAgICAgICAgICAgPG5nLWNvbnRhaW5lciBuZ2JOYXZJdGVtPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtYXJrZG93bi1lZGl0b3JfX2NvbW1hbmRzXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtYXJrZG93bi1lZGl0b3JfX2NvbW1hbmRzLWRlZmF1bHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwhLS1kZWZhdWx0IGNvbW1hbmRzIChlLmcuIGJvbGQpLS0+XG4gICAgICAgICAgICAgICAgICAgICAgICBAZm9yIChjb21tYW5kIG9mIGRlZmF1bHRDb21tYW5kcyB8IG5lZ2F0ZWRUeXBlQ2hlY2s6IE11bHRpT3B0aW9uQ29tbWFuZDsgdHJhY2sgY29tbWFuZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuIGJ0bi1zbSBweS0wXCIgKGNsaWNrKT1cImNvbW1hbmQuZXhlY3V0ZSgpXCIgW25nYlRvb2x0aXBdPVwiY29tbWFuZC5idXR0b25UcmFuc2xhdGlvblN0cmluZyB8IGFydGVtaXNUcmFuc2xhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiY29tbWFuZC5idXR0b25JY29uXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPCEtLXN0eWxlIGNvbW1hbmQgLS0+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGhlYWRlckNvbW1hbmRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYnRuLWdyb3VwXCIgbmdiRHJvcGRvd24gcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD1cIkJ1dHRvbiBncm91cCB3aXRoIG5lc3RlZCBkcm9wZG93blwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zbSBweC0yIHB5LTBcIiB0eXBlPVwiYnV0dG9uXCIgaWQ9XCJkcm9wZG93bkJhc2ljMVwiIG5nYkRyb3Bkb3duVG9nZ2xlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAubXVsdGlwbGVDaG9pY2VRdWVzdGlvbi5lZGl0b3Iuc3R5bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImRyb3Bkb3duLW1lbnVcIiBuZ2JEcm9wZG93bk1lbnU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAZm9yIChjb21tYW5kIG9mIGhlYWRlckNvbW1hbmRzOyB0cmFjayBjb21tYW5kKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImRyb3Bkb3duLWl0ZW1cIiAoY2xpY2spPVwiY29tbWFuZC5leGVjdXRlKClcIiB0eXBlPVwiYnV0dG9uXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGNvbW1hbmQuYnV0dG9uVHJhbnNsYXRpb25TdHJpbmcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAoY29tbWFuZCBvZiBkZWZhdWx0Q29tbWFuZHMgfCB0eXBlQ2hlY2s6IEludGVyYWN0aXZlU2VhcmNoQ29tbWFuZDsgdHJhY2sgY29tbWFuZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktc2VsZWN0LXdpdGgtc2VhcmNoIFtjb21tYW5kXT1cImNvbW1hbmRcIiBbZWRpdG9yQ29udGVudFN0cmluZ109XCJlZGl0b3JDb250ZW50U3RyaW5nXCI+PC9qaGktc2VsZWN0LXdpdGgtc2VhcmNoPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAoY29tbWFuZCBvZiBkZWZhdWx0Q29tbWFuZHMgfCB0eXBlQ2hlY2s6IE11bHRpT3B0aW9uQ29tbWFuZCB8IG5lZ2F0ZWRUeXBlQ2hlY2s6IEludGVyYWN0aXZlU2VhcmNoQ29tbWFuZDsgdHJhY2sgY29tbWFuZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hdC1idXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFttYXRNZW51VHJpZ2dlckZvcl09XCJpc1R5cGVPZkV4ZXJjaXNlUmVmZXJlbmNlQ29tbWFuZChjb21tYW5kKSA/IHN1Yk1lbnVFeGVyY2lzZSA6IHN1Yk1lbnVMZWN0dXJlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gYnRuLXNtIG0tMCBtbC0xIHB5LTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRlZmF1bHQtZm9udC1zaXplXCI+e3sgY29tbWFuZC5idXR0b25UcmFuc2xhdGlvblN0cmluZyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUFuZ2xlRG93blwiIGNsYXNzPVwibXMtMVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxtYXQtbWVudSAjc3ViTWVudUV4ZXJjaXNlPVwibWF0TWVudVwiIHR5cGU9XCJidXR0b25cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWNvbW1hbmQuZ2V0VmFsdWVzKCkgfHwgY29tbWFuZC5nZXRWYWx1ZXMoKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG1hdC1idXR0b24gW2Rpc2FibGVkXT1cInRydWVcIiBqaGlUcmFuc2xhdGU9XCJnbG9iYWwuZ2VuZXJpYy5lbXB0eUxpc3RcIiB0eXBlPVwiYnV0dG9uXCI+Tm8gaXRlbXMgYXZhaWxhYmxlPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAZm9yIChpdGVtIG9mIGNvbW1hbmQuZ2V0VmFsdWVzKCk7IHRyYWNrIGl0ZW0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGl0ZW0udHlwZSAhPT0gJ0xFQ1RVUkUnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gbWF0LW1lbnUtaXRlbSAoY2xpY2spPVwiY29tbWFuZC5leGVjdXRlKGl0ZW0uaWQsIGl0ZW0udHlwZSlcIiB0eXBlPVwiYnV0dG9uXCI+e3sgaXRlbS52YWx1ZSB9fTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9tYXQtbWVudT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG1hdC1tZW51ICNzdWJNZW51TGVjdHVyZT1cIm1hdE1lbnVcIiB0eXBlPVwiYnV0dG9uXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKCFjb21tYW5kLmdldFZhbHVlcygpIHx8IGNvbW1hbmQuZ2V0VmFsdWVzKCkubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBtYXQtYnV0dG9uIFtkaXNhYmxlZF09XCJ0cnVlXCIgamhpVHJhbnNsYXRlPVwiZ2xvYmFsLmdlbmVyaWMuZW1wdHlMaXN0XCIgdHlwZT1cImJ1dHRvblwiPk5vIGl0ZW1zIGF2YWlsYWJsZTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAobGVjdHVyZSBvZiBjb21tYW5kLmdldFZhbHVlcygpOyB0cmFjayBsZWN0dXJlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChsZWN0dXJlLnR5cGUgPT09ICdMRUNUVVJFJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG1hdC1tZW51LWl0ZW0gW21hdE1lbnVUcmlnZ2VyRm9yXT1cImxlY3R1cmVNZW51VW5pdHNcIiB0eXBlPVwiYnV0dG9uXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBsZWN0dXJlLnZhbHVlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bWF0LW1lbnUgI2xlY3R1cmVNZW51VW5pdHM9XCJtYXRNZW51XCIgdHlwZT1cImJ1dHRvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGxlY3R1cmUudHlwZSA9PT0gJ0xFQ1RVUkUnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG1hdC1tZW51LWl0ZW0gKGNsaWNrKT1cImNvbW1hbmQuZXhlY3V0ZShsZWN0dXJlLmlkLCBsZWN0dXJlLnR5cGUpXCIgdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYm9yZGVyLWJvdHRvbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGxlY3R1cmUudmFsdWUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKHVuaXQgb2YgbGVjdHVyZS5hdHRhY2htZW50VW5pdHM7IHRyYWNrIHVuaXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAodW5pdC5jb3Vyc2VBcnRpZmFjdFR5cGUgPT09ICdBVFRBQ0hNRU5UX1VOSVRTJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gbWF0LW1lbnUtaXRlbSBbbWF0TWVudVRyaWdnZXJGb3JdPVwibGVjdHVyZU1lbnVVbml0c1NsaWRlXCIgdHlwZT1cImJ1dHRvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyB1bml0LnZhbHVlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG1hdC1tZW51ICNsZWN0dXJlTWVudVVuaXRzU2xpZGU9XCJtYXRNZW51XCIgdHlwZT1cImJ1dHRvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF0LW1lbnUtaXRlbVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwiY29tbWFuZC5leGVjdXRlKGxlY3R1cmUuaWQsIGxlY3R1cmUudHlwZSwgdW5kZWZpbmVkLCB1bml0LmlkKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJvcmRlci1ib3R0b21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgdW5pdC52YWx1ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIXVuaXQuc2xpZGVzIHx8IHVuaXQuc2xpZGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG1hdC1idXR0b24gW2Rpc2FibGVkXT1cInRydWVcIiBqaGlUcmFuc2xhdGU9XCJnbG9iYWwuZ2VuZXJpYy5lbXB0eUxpc3RcIiB0eXBlPVwiYnV0dG9uXCI+Tm8gaXRlbXMgYXZhaWxhYmxlPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKHNsaWRlIG9mIHVuaXQuc2xpZGVzOyB0cmFjayBzbGlkZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG1hdC1tZW51LWl0ZW0gKGNsaWNrKT1cImNvbW1hbmQuZXhlY3V0ZShsZWN0dXJlLmlkLCBsZWN0dXJlLnR5cGUsIHVuZGVmaW5lZCwgdW5pdC5pZCwgc2xpZGUuaWQpXCIgdHlwZT1cImJ1dHRvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2xpZGUge3sgc2xpZGUuc2xpZGVOdW1iZXIgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbWF0LW1lbnU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGZvciAoYXR0YWNobWVudCBvZiBsZWN0dXJlLmVsZW1lbnRzOyB0cmFjayBhdHRhY2htZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG1hdC1tZW51LWl0ZW0gdHlwZT1cImJ1dHRvblwiIChjbGljayk9XCJjb21tYW5kLmV4ZWN1dGUobGVjdHVyZS5pZCwgYXR0YWNobWVudC50eXBlLCBhdHRhY2htZW50LmlkKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGF0dGFjaG1lbnQudmFsdWUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbWF0LW1lbnU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbWF0LW1lbnU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8IS0tY29sb3IgcGlja2VyIGNvbW1hbmQgLS0+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGNvbG9yQ29tbWFuZHMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJidG4tZ3JvdXAgY29sLXhzLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbG9yLXByZXZpZXcgYnRuIGJ0bi1zbSBweC0yIHB5LTBcIiAoY2xpY2spPVwib3BlbkNvbG9yU2VsZWN0b3IoJGV2ZW50KVwiPnt7ICdhcnRlbWlzQXBwLm1hcmtkb3duRWRpdG9yLmNvbG9yJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1jb2xvci1zZWxlY3RvciBbdGFnQ29sb3JzXT1cIm1hcmtkb3duQ29sb3JzXCIgKHNlbGVjdGVkQ29sb3IpPVwib25TZWxlY3RlZENvbG9yKCRldmVudClcIj48L2poaS1jb2xvci1zZWxlY3Rvcj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gZG9tYWluIGNvbW1hbmRzIC0tPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChkb21haW5Db21tYW5kcyAmJiBkb21haW5Db21tYW5kcy5sZW5ndGggIT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtYXJrZG93bi1lZGl0b3JfX2NvbW1hbmRzLWRvbWFpblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAZm9yIChjb21tYW5kIG9mIGRvbWFpbkNvbW1hbmRzIHwgdHlwZUNoZWNrOiBEb21haW5UYWdDb21tYW5kOyB0cmFjayBjb21tYW5kKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGNvbW1hbmQuZGlzcGxheUNvbW1hbmRCdXR0b24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYnRuIGJ0bi1zbSBweC0yIHB5LTBcIiAoY2xpY2spPVwiY29tbWFuZC5leGVjdXRlKClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgY29tbWFuZC5idXR0b25UcmFuc2xhdGlvblN0cmluZyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAZm9yIChjb21tYW5kIG9mIGRvbWFpbkNvbW1hbmRzIHwgdHlwZUNoZWNrOiBEb21haW5NdWx0aU9wdGlvbkNvbW1hbmQ7IHRyYWNrIGNvbW1hbmQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgbmdiRHJvcGRvd24gY2xhc3M9XCJidG4tZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zbSBweC0yIHB5LTBcIiB0eXBlPVwiYnV0dG9uXCIgbmdiRHJvcGRvd25Ub2dnbGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGNvbW1hbmQuYnV0dG9uVHJhbnNsYXRpb25TdHJpbmcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBuZ2JEcm9wZG93bk1lbnU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKGl0ZW0gb2YgY29tbWFuZC5nZXRWYWx1ZXMoKTsgdHJhY2sgaXRlbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0bi1zbVwiIHR5cGU9XCJidXR0b25cIiAoY2xpY2spPVwiY29tbWFuZC5leGVjdXRlKGl0ZW0uaWQpXCIgbmdiRHJvcGRvd25JdGVtPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGl0ZW0udmFsdWUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIWNvbW1hbmQuZ2V0VmFsdWVzKCkubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFtkaXNhYmxlZF09XCJ0cnVlXCIgbmdiRHJvcGRvd25JdGVtIGpoaVRyYW5zbGF0ZT1cImdsb2JhbC5nZW5lcmljLmVtcHR5TGlzdFwiPk5vIGl0ZW1zIGF2YWlsYWJsZTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1zLWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAZm9yIChjb21tYW5kIG9mIG1ldGFDb21tYW5kczsgdHJhY2sgY29tbWFuZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0biBidG4tc20gcHgtMiBweS0wXCIgKGNsaWNrKT1cImNvbW1hbmQuZXhlY3V0ZSgpXCIgW25nYlRvb2x0aXBdPVwiY29tbWFuZC5idXR0b25UcmFuc2xhdGlvblN0cmluZyB8IGFydGVtaXNUcmFuc2xhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImNvbW1hbmQuYnV0dG9uSWNvblwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9uZy1jb250YWluZXI+XG4gICAgICAgIH1cbiAgICA8L25hdj5cbiAgICA8ZGl2IFtuZ2JOYXZPdXRsZXRdPVwibmF2XCI+PC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBY2VFZGl0b3JDb21wb25lbnQgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9hY2UtZWRpdG9yL2FjZS1lZGl0b3IuY29tcG9uZW50JztcblxuQE5nTW9kdWxlKHtcbiAgICBkZWNsYXJhdGlvbnM6IFtBY2VFZGl0b3JDb21wb25lbnRdLFxuICAgIGV4cG9ydHM6IFtBY2VFZGl0b3JDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBBY2VFZGl0b3JNb2R1bGUge31cbiIsImltcG9ydCB7IE1hcmtkb3duRWRpdG9yQ29tcG9uZW50IH0gZnJvbSAnLi9tYXJrZG93bi1lZGl0b3IuY29tcG9uZW50JztcbmltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBY2VFZGl0b3JNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLWVkaXRvci9hY2UtZWRpdG9yL2FjZS1lZGl0b3IubW9kdWxlJztcbmltcG9ydCB7IEZvcm1zTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgQXJ0ZW1pc0NvbG9yU2VsZWN0b3JNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL2NvbG9yLXNlbGVjdG9yL2NvbG9yLXNlbGVjdG9yLm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IE1hdE1lbnVNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9tZW51JztcbmltcG9ydCB7IE1hdEJ1dHRvbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2J1dHRvbic7XG5pbXBvcnQgeyBTZWxlY3RXaXRoU2VhcmNoQ29tcG9uZW50IH0gZnJvbSAnLi9zZWxlY3Qtd2l0aC1zZWFyY2gvc2VsZWN0LXdpdGgtc2VhcmNoLmNvbXBvbmVudCc7XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW0FydGVtaXNTaGFyZWRNb2R1bGUsIEFjZUVkaXRvck1vZHVsZSwgRm9ybXNNb2R1bGUsIEFydGVtaXNDb2xvclNlbGVjdG9yTW9kdWxlLCBNYXRNZW51TW9kdWxlLCBNYXRCdXR0b25Nb2R1bGVdLFxuICAgIGRlY2xhcmF0aW9uczogW01hcmtkb3duRWRpdG9yQ29tcG9uZW50LCBTZWxlY3RXaXRoU2VhcmNoQ29tcG9uZW50XSxcbiAgICBleHBvcnRzOiBbTWFya2Rvd25FZGl0b3JDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBBcnRlbWlzTWFya2Rvd25FZGl0b3JNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsU0FBUyxXQUFXLFlBQVksY0FBYyxPQUFlLFFBQVEsaUJBQWlCOzs7Ozs7QUNHMUUsSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUFnQyxJQUFBLHdCQUFBLFNBQUEsU0FBQSwyRUFBQTtBQUFBLFlBQUEsY0FBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxjQUFBLFlBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQVMseUJBQUEsT0FBQSxrQkFBQSxXQUFBLENBQTJCO0lBQUEsQ0FBQTtBQUNoRSxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxZQUFBOzs7O0FBRm1DLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsV0FBQSw2QkFBQSxHQUFBLEtBQUEsV0FBQSxDQUFBOzs7OztBQUh2QyxJQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSxxREFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHNDQUFBO0FBS0osSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxJQUFBOzs7O0FBUGdDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsT0FBQSxPQUFBLHNCQUFBLEtBQUEsSUFBQSxFQUEwQyxRQUFBLE9BQUEsc0JBQUEsTUFBQSxJQUFBLEVBQUEsVUFBQSxPQUFBLFFBQUEsSUFBQTtBQUNsRSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLE9BQUEsU0FBQTs7O0FERlIsU0FRTSxnQkF3Qk87QUFoQ2I7O0FBQ0E7O0FBT0EsSUFBTSxpQkFBaUI7TUFDbkI7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7O0FBUUUsSUFBTyx5QkFBUCxNQUFPLHdCQUFzQjtNQVFuQjtNQUNBO01BUlo7TUFDQSxvQkFBb0I7TUFDcEIsU0FBUztNQUNBLFlBQXNCO01BQ3JCLGdCQUFnQixJQUFJLGFBQVk7TUFFMUMsWUFDWSxZQUNBLFVBQW1CO0FBRG5CLGFBQUEsYUFBQTtBQUNBLGFBQUEsV0FBQTtNQUNUO01BS0gsV0FBUTtBQUNKLGFBQUssd0JBQXdCLEVBQUUsTUFBTSxHQUFHLEtBQUssRUFBQztBQUU5QyxhQUFLLCtDQUE4QztNQUN2RDtNQUVRLGlEQUE4QztBQUNsRCxhQUFLLFNBQVMsT0FBTyxZQUFZLFNBQVMsQ0FBQyxVQUFnQjtBQUN2RCxjQUFJLEtBQUssbUJBQW1CO0FBQ3hCLGtCQUFNLFNBQVMsTUFBTTtBQUVyQixrQkFBTSw0QkFBNEIsQ0FBQyxLQUFLLFdBQVcsY0FBYyxTQUFTLE1BQU07QUFDaEYsZ0JBQUksMkJBQTJCO0FBQzNCLG1CQUFLLG9CQUFvQjs7O1FBR3JDLENBQUM7TUFDTDtNQVFBLGtCQUFrQixPQUFtQixXQUFvQixRQUFlO0FBTXBFLGNBQU0sZ0JBQWU7QUFFckIsY0FBTSxnQkFBaUIsTUFBTSxPQUFtQixRQUFRLGFBQWE7QUFFckUsYUFBSyxzQkFBc0IsT0FBTyxnQkFBZ0IsY0FBYyxhQUFhO0FBQzdFLGFBQUssc0JBQXNCLE1BQU0sYUFBYTtBQUM5QyxZQUFJLFdBQVcsUUFBVztBQUN0QixlQUFLLFNBQVM7O0FBR2xCLGFBQUssb0JBQW9CLENBQUMsS0FBSztNQUNuQztNQU1BLGtCQUFrQixlQUFxQjtBQUNuQyxhQUFLLG9CQUFvQjtBQUN6QixhQUFLLGNBQWMsS0FBSyxhQUFhO01BQ3pDO01BS0Esc0JBQW1CO0FBQ2YsYUFBSyxvQkFBb0I7TUFDN0I7O3lCQXpFUyx5QkFBc0IsK0JBQUEsYUFBQSxHQUFBLCtCQUFBLFlBQUEsQ0FBQTtNQUFBO2dFQUF0Qix5QkFBc0IsV0FBQSxDQUFBLENBQUEsb0JBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxXQUFBLFlBQUEsR0FBQSxTQUFBLEVBQUEsZUFBQSxnQkFBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxzQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxTQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsZ0NBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNoQ25DLFVBQUEsd0JBQUEsR0FBQSwrQ0FBQSxHQUFBLENBQUE7OztBQUFBLFVBQUEsMkJBQUEsR0FBQSxJQUFBLG9CQUFBLElBQUEsRUFBQTs7Ozs7b0ZEZ0NhLHdCQUFzQixFQUFBLFdBQUEseUJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFaENuQyxTQUFTLGdCQUFnQjs7QUFBekIsSUFVYTtBQVZiOztBQUVBO0FBQ0E7QUFPTSxJQUFPLDZCQUFQLE1BQU8sNEJBQTBCOzt5QkFBMUIsNkJBQTBCO01BQUE7Z0VBQTFCLDRCQUEwQixDQUFBO29FQUp6QixtQkFBbUIsRUFBQSxDQUFBOzs7Ozs7QUNOakMsU0FBUyxhQUFBQSxZQUFXLGNBQUFDLGFBQVksZ0JBQUFDLGVBQWMsU0FBQUMsUUFBTyxRQUEyQixVQUFBQyxTQUFRLGtCQUFrQjtBQUMxRyxTQUErQix5QkFBeUI7QUFDeEQsT0FBTztBQUNQLE9BQU87QUFDUCxPQUFPO0FBQ1AsT0FBTztBQUNQLE9BQU87O0FBTlAsSUFZYSxjQWNBO0FBMUJiOztBQU9BOztBQUtPLElBQU0sZUFBZTtBQWN0QixJQUFPLHFCQUFQLE1BQU8sb0JBQWtCO01BZ0NoQjtNQUNDO01BQ0E7TUFqQ0YsY0FBYyxJQUFJRixjQUFZO01BQzlCLGFBQWEsSUFBSUEsY0FBWTtNQUM5QixRQUFhLENBQUE7TUFPdEIsSUFDVyxRQUFRLE9BQWE7QUFDNUIsWUFBSSxRQUFRLEtBQUssU0FBUyxjQUFjO0FBQ3BDLGVBQUssUUFBUSxRQUFRLFdBQVcsS0FBSzs7TUFFN0M7TUFFQTtNQUNBO01BRVEsV0FBZ0IsQ0FBQTtNQUNoQixZQUFZO01BQ1osU0FBUztNQUNULFFBQVE7TUFDUixxQkFBcUI7TUFDckI7TUFDQSwwQkFBMEI7TUFDMUIsUUFBUTtNQUVSO01BRVIsWUFDVyxZQUNDLE1BQ0EsY0FBMEI7QUFGM0IsYUFBQSxhQUFBO0FBQ0MsYUFBQSxPQUFBO0FBQ0EsYUFBQSxlQUFBO0FBRVIsY0FBTSxLQUFLLFdBQVc7QUFDdEIsYUFBSyxLQUFLLGtCQUFrQixNQUFLO0FBQzdCLGVBQUssVUFBVSxJQUFJLE1BQU0sRUFBRSxFQUFFO1FBQ2pDLENBQUM7QUFDRCxhQUFLLFFBQVEsa0JBQWtCO01BQ25DO01BRUEsV0FBUTtBQUNKLGFBQUssS0FBSTtBQUNULGFBQUssV0FBVTtNQUNuQjtNQUVBLGNBQVc7QUFDUCxhQUFLLFFBQVEsUUFBTztBQUNwQixhQUFLLG1CQUFtQixZQUFXO01BQ3ZDO01BRUEsT0FBSTtBQUNBLGFBQUssV0FBVyxLQUFLLFlBQVksQ0FBQSxDQUFFO0FBQ25DLGFBQUssUUFBUSxLQUFLLEtBQUs7QUFDdkIsYUFBSyxZQUFZLEtBQUssU0FBUztNQUNuQztNQUVBLGFBQVU7QUFDTixhQUFLLFFBQVEsR0FBRyxVQUFVLE1BQU0sS0FBSyxXQUFVLENBQUU7QUFDakQsYUFBSyxRQUFRLEdBQUcsU0FBUyxNQUFNLEtBQUssV0FBVSxDQUFFO0FBRWhELGFBQUssb0JBQW9CLEtBQUssYUFBYSwwQkFBeUIsRUFBRyxVQUFVLE1BQU0sS0FBSyxpQkFBZ0IsQ0FBRTtNQUNsSDtNQUVBLGFBQVU7QUFDTixjQUFNLFNBQVMsS0FBSyxRQUFRLFNBQVE7QUFDcEMsWUFBSSxXQUFXLEtBQUssU0FBUztBQUN6Qjs7QUFFSixZQUFJLENBQUMsS0FBSyx5QkFBeUI7QUFDL0IsZUFBSyxRQUFRO0FBQ2IsZUFBSyxLQUFLLElBQUksTUFBSztBQUNmLGlCQUFLLFdBQVcsS0FBSyxNQUFNO0FBQzNCLGlCQUFLLFlBQVksS0FBSyxNQUFNO1VBQ2hDLENBQUM7QUFDRCxlQUFLLFVBQVUsTUFBTTtlQUNsQjtBQUNILGNBQUksS0FBSyxlQUFlO0FBQ3BCLHlCQUFhLEtBQUssYUFBYTs7QUFHbkMsZUFBSyxnQkFBZ0IsV0FBVyxNQUFLO0FBQ2pDLGlCQUFLLFFBQVE7QUFDYixpQkFBSyxLQUFLLElBQUksTUFBSztBQUNmLG1CQUFLLFdBQVcsS0FBSyxNQUFNO0FBQzNCLG1CQUFLLFlBQVksS0FBSyxNQUFNO1lBQ2hDLENBQUM7QUFDRCxpQkFBSyxnQkFBZ0I7VUFDekIsR0FBRyxLQUFLLHVCQUF1Qjs7QUFFbkMsYUFBSyxVQUFVO01BQ25CO01BRUEsSUFDSSxRQUFRLFNBQVk7QUFDcEIsYUFBSyxXQUFXLE9BQU87TUFDM0I7TUFFQSxXQUFXLFNBQVk7QUFDbkIsYUFBSyxXQUFXO0FBQ2hCLGFBQUssUUFBUSxXQUFXLFdBQVcsQ0FBQSxDQUFFO01BQ3pDO01BRUEsSUFDSSxTQUFTLFVBQWlCO0FBQzFCLGFBQUssWUFBWSxRQUFRO01BQzdCO01BRUEsWUFBWSxVQUFpQjtBQUN6QixhQUFLLFlBQVk7QUFDakIsYUFBSyxRQUFRLFlBQVksUUFBUTtNQUNyQztNQUVBLElBQ0ksS0FBSyxNQUFZO0FBQ2pCLGFBQUssUUFBUSxJQUFJO01BQ3JCO01BRUEsUUFBUSxNQUFZO0FBQ2hCLGFBQUssUUFBUTtBQUNiLFlBQUksT0FBTyxLQUFLLFVBQVUsVUFBVTtBQUNoQyxlQUFLLFFBQVEsV0FBVSxFQUFHLFFBQVEsS0FBSyxLQUFLO2VBQ3pDO0FBQ0gsZUFBSyxRQUFRLFdBQVUsRUFBRyxRQUFRLFlBQVksS0FBSyxLQUFLLEVBQUU7O0FBRzlELGFBQUssaUJBQWdCO01BQ3pCO01BRVEsbUJBQWdCO0FBQ3BCLGNBQU0sMEJBQTBCLEtBQUssYUFBYSxnQkFBZTtBQUNqRSxhQUFLLFNBQVMsS0FBSyxNQUFNLFlBQVcsTUFBTyxhQUFhLHdCQUF3QixtQkFBbUIsd0JBQXdCO0FBQzNILGFBQUssUUFBUSxTQUFTLGFBQWEsS0FBSyxNQUFNLEVBQUU7TUFDcEQ7TUFFQSxJQUFJLFFBQUs7QUFDTCxlQUFPLEtBQUs7TUFDaEI7TUFFQSxJQUNJLE1BQU0sT0FBYTtBQUNuQixhQUFLLFFBQVEsS0FBSztNQUN0QjtNQUVBLFdBQVcsT0FBYTtBQUNwQixhQUFLLFFBQVEsS0FBSztNQUN0QjtNQUdRLFlBQVksQ0FBQyxNQUFVO01BQUU7TUFFakMsaUJBQWlCLElBQU87QUFDcEIsYUFBSyxZQUFZO01BQ3JCO01BRVEsYUFBYSxNQUFLO01BQUU7TUFFNUIsa0JBQWtCLElBQU87QUFDckIsYUFBSyxhQUFhO01BQ3RCO01BRUEsSUFBSSxPQUFJO0FBQ0osZUFBTyxLQUFLO01BQ2hCO01BRUEsSUFDSSxLQUFLLE1BQVk7QUFDakIsYUFBSyxRQUFRLElBQUk7TUFDckI7TUFFQSxRQUFRLE1BQVk7QUFDaEIsWUFBSSxRQUFRLFFBQVc7QUFDbkIsaUJBQU87O0FBRVgsWUFBSSxLQUFLLFVBQVUsUUFBUSxLQUFLLG9CQUFvQjtBQUNoRCxlQUFLLFFBQVE7QUFDYixlQUFLLFFBQVEsU0FBUyxJQUFJO0FBQzFCLGVBQUssVUFBVSxJQUFJO0FBQ25CLGVBQUssUUFBUSxlQUFjOztNQUVuQztNQUVBLElBQ0ksa0JBQWtCLFFBQWU7QUFDakMsYUFBSyxxQkFBcUIsTUFBTTtNQUNwQztNQUVBLHFCQUFxQixRQUFlO0FBQ2hDLGFBQUsscUJBQXFCO01BQzlCO01BRUEsSUFDSSx1QkFBdUIsS0FBVztBQUNsQyxhQUFLLDBCQUEwQixHQUFHO01BQ3RDO01BRUEsMEJBQTBCLEtBQVc7QUFDakMsYUFBSywwQkFBMEI7TUFDbkM7TUFFQSxZQUFTO0FBQ0wsZUFBTyxLQUFLO01BQ2hCOzt5QkE1TVMscUJBQWtCLGdDQUFBLGNBQUEsR0FBQSxnQ0FBQSxVQUFBLEdBQUEsZ0NBQUEsWUFBQSxDQUFBO01BQUE7aUVBQWxCLHFCQUFrQixXQUFBLENBQUEsQ0FBQSxnQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLE9BQUEsU0FBQSxTQUFBLFdBQUEsU0FBQSxXQUFBLFVBQUEsWUFBQSxNQUFBLFFBQUEsT0FBQSxTQUFBLE1BQUEsUUFBQSxtQkFBQSxxQkFBQSx3QkFBQSx5QkFBQSxHQUFBLFNBQUEsRUFBQSxhQUFBLGVBQUEsWUFBQSxhQUFBLEdBQUEsVUFBQSxDQUFBLGlDQVJoQjtRQUNQO1VBQ0ksU0FBUztVQUNULGFBQWEsV0FBVyxNQUFNLG1CQUFrQjtVQUNoRCxPQUFPOztPQUVkLENBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFVBQUEsU0FBQSw0QkFBQSxJQUFBLEtBQUE7TUFBQSxHQUFBLFFBQUEsQ0FBQSx5V0FBQSxFQUFBLENBQUE7OztxRkFFUSxvQkFBa0IsRUFBQSxXQUFBLHFCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBQ3JCL0IsSUFBYSwwQkFPQTtBQVBiOztBQUFPLElBQU0sMkJBQTJCLENBQUMsT0FBTyxPQUFPLFFBQVEsT0FBTyxPQUFPLEtBQUs7QUFPM0UsSUFBTSxrQkFBa0I7TUFDM0I7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTs7Ozs7O0FDNUNKLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsa0JBQWtCO0FBRTNCLFNBQVMscUJBQXFCOzs7QUFIOUIsSUFlYTtBQWZiOztBQUVBO0FBRUE7QUFXTSxJQUFPLHNCQUFQLE1BQU8scUJBQW1CO01BRVI7TUFEWCxpQ0FBaUM7TUFDMUMsWUFBb0IsTUFBZ0I7QUFBaEIsYUFBQSxPQUFBO01BQW1CO01BU3ZDLG1CQUFtQixNQUFtQixVQUFtQixTQUFpQjtBQUN0RSxjQUFNLGdCQUFnQixXQUFXLFNBQVMsTUFBTSxHQUFHLEVBQUUsSUFBRyxFQUFJLGtCQUFpQixJQUFNLEtBQWMsS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFHLEVBQUksa0JBQWlCO0FBQ3pJLFlBQUksQ0FBQyxLQUFLLCtCQUErQixTQUFTLGFBQWEsR0FBRztBQUM5RCxpQkFBTyxRQUFRLE9BQ1gsSUFBSSxNQUNBLDRFQUE0RSxLQUFLLCtCQUErQixJQUFJLENBQUMsY0FBYyxJQUFJLFNBQVMsRUFBRSxFQUFFLEtBQUssSUFBSSxDQUFDLENBQ2pLOztBQUlULFlBQUksS0FBSyxPQUFPLGVBQWU7QUFDM0IsaUJBQU8sUUFBUSxPQUFPLElBQUksTUFBTSxpREFBaUQsaUJBQWlCLE9BQU8sUUFBUSxNQUFNLENBQUM7O0FBRzVILGNBQU0sZUFBZSxDQUFDLENBQUMsU0FBUztBQUNoQyxjQUFNLFdBQVcsSUFBSSxTQUFRO0FBQzdCLGlCQUFTLE9BQU8sUUFBUSxNQUFNLFFBQVE7QUFDdEMsZUFBTyxjQUFjLEtBQUssS0FBSyxLQUF5QiwwQ0FBMEMsWUFBWSxJQUFJLFFBQVEsQ0FBQztNQUMvSDs7eUJBN0JTLHNCQUFtQix1QkFBQSxjQUFBLENBQUE7TUFBQTtvRUFBbkIsc0JBQW1CLFNBQW5CLHFCQUFtQixXQUFBLFlBRE4sT0FBTSxDQUFBOzs7Ozs7QUNaaEMsU0FBZ0IsZ0JBQWdCO0FBQWhDLElBR00sV0FPZ0I7QUFWdEI7O0FBR0EsSUFBTSxZQUFZLFNBQVMsV0FBVyxFQUFFO0FBT2xDLElBQWdCLFVBQWhCLE1BQXVCO01BQ3pCO01BQ0E7TUFDVTtNQUNBO01BRUgsVUFBVSxXQUFjO0FBQzNCLGFBQUssWUFBWTtNQUNyQjtNQUVPLG1CQUFtQixLQUFlO0FBQ3JDLGFBQUssa0JBQWtCO01BQzNCO01BRVUsa0JBQWU7QUFDckIsZUFBTyxLQUFLLFVBQVUsZ0JBQWU7TUFDekM7TUFPVSwwQkFBdUI7QUFDN0IsY0FBTSxPQUFPLEtBQUssUUFBTztBQUd6QixjQUFNLFFBQVEsS0FBSyxNQUFNLElBQUk7QUFFN0IsY0FBTSxRQUFRLEtBQUssU0FBUTtBQUczQixhQUFLLFVBQVUsVUFBVSxTQUFTLElBQUksVUFBVSxNQUFNLE1BQU0sS0FBSyxHQUFHLE1BQU0sSUFBSSxLQUFLLE1BQU0sTUFBTSxJQUFJLEdBQUcsRUFBRSxNQUFNLENBQUM7QUFHL0csZUFBTyxNQUFNLE1BQU0sTUFBTSxNQUFNLEtBQUssTUFBTSxJQUFJLE1BQU0sQ0FBQztNQUN6RDtNQUVVLFVBQU87QUFDYixlQUFPLEtBQUssVUFBVSxTQUFRO01BQ2xDO01BRVUsV0FBVyxNQUFZO0FBQzdCLGFBQUssVUFBVSxPQUFPLElBQUk7TUFDOUI7TUFFVSxRQUFLO0FBQ1gsYUFBSyxVQUFVLE1BQUs7TUFDeEI7TUFFVSxXQUFRO0FBQ2QsZUFBTyxLQUFLLFVBQVUsVUFBVSxTQUFRO01BQzVDO01BRVUsUUFBUSxPQUFjLE1BQVk7QUFDeEMsYUFBSyxVQUFVLFFBQVEsUUFBUSxPQUFPLElBQUk7TUFDOUM7TUFFVSxpQkFBYztBQUNwQixhQUFLLFVBQVUsZUFBYztNQUNqQztNQUVVLGFBQWEsS0FBYSxRQUFjO0FBQzlDLGFBQUssVUFBVSxhQUFhLEtBQUssTUFBTTtNQUMzQztNQUVVLG9CQUFpQjtBQUN2QixlQUFPLEtBQUssVUFBVSxrQkFBaUI7TUFDM0M7TUFFVSxRQUFRLEtBQVc7QUFDekIsZUFBTyxLQUFLLFVBQVUsV0FBVSxFQUFHLFFBQVEsR0FBRztNQUNsRDtNQUVVLGlCQUFjO0FBQ3BCLGNBQU0sU0FBUyxLQUFLLGtCQUFpQjtBQUNyQyxlQUFPLEtBQUssUUFBUSxPQUFPLEdBQUc7TUFDbEM7TUFFVSx1QkFBb0I7QUFDMUIsY0FBTSxTQUFTLEtBQUssa0JBQWlCO0FBQ3JDLGNBQU0sY0FBYyxLQUFLLFVBQVUsV0FBVSxFQUFHLFFBQVEsT0FBTyxHQUFHO0FBQ2xFLGFBQUssZUFBYztBQUNuQixhQUFLLGFBQWEsT0FBTyxLQUFLLFlBQVksTUFBTTtNQUNwRDtNQUVVLGFBQWEsV0FBYztBQUNqQyxhQUFLLFVBQVUsYUFBYSxDQUFDLEdBQUksS0FBSyxVQUFVLGNBQWMsQ0FBQSxHQUFLLFNBQVM7TUFDaEY7TUFJVSxpQkFBaUIsTUFBWTtBQUNuQyxlQUFPLEtBQUssS0FBSTtNQUNwQjtNQUVVLGVBQWUsY0FBc0IsV0FBaUI7QUFDNUQsWUFBSSxhQUFhLE9BQU8sQ0FBQyxNQUFNLE9BQU8sYUFBYSxPQUFPLGFBQWEsU0FBUyxDQUFDLE1BQU0sS0FBSztBQUN4RixpQkFBTyxLQUFLLFdBQVcsTUFBTSxZQUFZLEdBQUc7bUJBQ3JDLGFBQWEsT0FBTyxDQUFDLE1BQU0sS0FBSztBQUN2QyxpQkFBTyxLQUFLLFdBQVcsTUFBTSxTQUFTO21CQUMvQixhQUFhLE9BQU8sYUFBYSxTQUFTLENBQUMsTUFBTSxLQUFLO0FBQzdELGlCQUFPLEtBQUssV0FBVyxZQUFZLEdBQUc7ZUFDbkM7QUFDSCxpQkFBTyxLQUFLLFdBQVcsU0FBUzs7TUFFeEM7Ozs7OztBQ3RISixJQU1zQjtBQU50Qjs7O0FBQ0E7QUFLTSxJQUFnQixnQkFBaEIsY0FBc0MsUUFBTztNQUcvQyx1QkFBdUI7TUFPdkIsWUFBWSxRQUFRLElBQUU7QUFDbEIsY0FBTSwyQkFBMkIsMEJBQTBCLEtBQUsscUJBQW9CLENBQUUsR0FDbEYsMkJBQTJCLDBCQUEwQixLQUFLLHFCQUFvQixDQUFFO0FBQ3BGLGVBQU8sSUFBSSxPQUFPLEdBQUcsd0JBQXdCLE9BQU8sd0JBQXdCLElBQUksS0FBSztNQUN6RjtNQU1BLG9CQUFpQjtBQUNiLGNBQU0sRUFBRSxLQUFLLE9BQU0sSUFBSyxLQUFLLFVBQVUsa0JBQWlCLEdBQ3BELE9BQU8sS0FBSyxVQUFVLFdBQVUsRUFBRyxRQUFRLEdBQUcsR0FDOUMsUUFBUSxLQUFLLFlBQVksR0FBRztBQUVoQyxjQUFNLFVBQW9GLENBQUE7QUFHMUYsWUFBSSxRQUFRLE1BQU0sS0FBSyxJQUFJO0FBQzNCLGVBQU8sU0FBUyxRQUFXO0FBQ3ZCLGtCQUFRLEtBQUssRUFBRSxZQUFZLE1BQU0sT0FBTyxVQUFVLE1BQU0sUUFBUSxNQUFNLENBQUMsRUFBRSxRQUFRLGlCQUFpQixNQUFNLENBQUMsRUFBQyxDQUFFO0FBQzVHLGtCQUFRLE1BQU0sS0FBSyxJQUFJOztBQUUzQixjQUFNLGdCQUFnQixRQUFRLEtBQUssQ0FBQyxFQUFFLFlBQVksU0FBUSxNQUFPLFNBQVMsY0FBYyxVQUFVLFFBQVE7QUFDMUcsZUFBTyxpQkFBaUI7TUFDNUI7TUFNQSxXQUFXLEtBQVc7QUFDbEIsY0FBTSxPQUFPLEtBQUssVUFBVSxXQUFVLEVBQUcsUUFBUSxHQUFHLEdBQ2hELFFBQVEsS0FBSyxZQUFXO0FBRTVCLFlBQUksQ0FBQyxNQUFNO0FBQ1AsaUJBQU87O0FBR1gsY0FBTSxRQUFRLEtBQUssTUFBTSxLQUFLO0FBQzlCLFlBQUksQ0FBQyxPQUFPO0FBQ1IsaUJBQU87O0FBRVgsZUFBTyxFQUFFLFlBQVksTUFBTSxPQUFPLFVBQVUsTUFBTSxRQUFRLE1BQU0sQ0FBQyxFQUFFLFFBQVEsaUJBQWlCLE1BQU0sQ0FBQyxFQUFDO01BQ3hHOzs7Ozs7QUM1REosSUFLc0I7QUFMdEI7OztBQUtNLElBQWdCLG1CQUFoQixjQUF5QyxjQUFhOzs7Ozs7QUNKNUQsU0FBUyxtQkFBbUI7QUFBNUIsSUFHYTtBQUhiOztBQUNBO0FBRU0sSUFBTyxtQkFBUCxjQUFnQyxRQUFPO01BQ3pDLGFBQWE7TUFDYiwwQkFBMEI7TUFVMUIsVUFBTztBQUNILGNBQU0sYUFBYSxLQUFLLGdCQUFlO0FBRXZDLFlBQUksV0FBVyxTQUFTLE9BQU8sR0FBRztBQUM5QixnQkFBTSxZQUFZLFdBQVcsTUFBTSxHQUFHLEVBQUU7QUFDeEMsZUFBSyxXQUFXLFNBQVM7ZUFDdEI7QUFDSCxnQkFBTSxZQUFZLFFBQVEsVUFBVTtBQUNwQyxlQUFLLFdBQVcsU0FBUzs7TUFFakM7Ozs7OztBQ3pCSixJQUVhO0FBRmI7OztBQUVNLElBQU8scUJBQVAsY0FBa0MsUUFBTztNQUMzQyxhQUFhO01BQ2IsMEJBQTBCO01BVTFCLFFBQVEsT0FBYTtBQUNqQixjQUFNLGVBQWUsS0FBSyxnQkFBZTtBQUV6QyxZQUFJLGFBQWEsU0FBUyxlQUFlLEtBQUssYUFBYSxTQUFTLGVBQWUsR0FBRztBQUNsRixnQkFBTSxZQUFZLGFBQWEsTUFBTSxJQUFJLEVBQUU7QUFDM0MsZUFBSyxXQUFXLFNBQVM7bUJBQ2xCLGFBQWEsU0FBUyxnQkFBZ0IsS0FBSyxhQUFhLFNBQVMsZ0JBQWdCLEdBQUc7QUFDM0YsZ0JBQU0sWUFBWSxhQUFhLE1BQU0sSUFBSSxFQUFFO0FBQzNDLGVBQUssV0FBVyxTQUFTO21CQUNsQixhQUFhLFNBQVMsYUFBYSxHQUFHO0FBQzdDLGdCQUFNLFlBQVksYUFBYSxNQUFNLElBQUksRUFBRTtBQUMzQyxlQUFLLFdBQVcsU0FBUzttQkFDbEIsYUFBYSxTQUFTLGNBQWMsS0FBSyxhQUFhLFNBQVMsY0FBYyxHQUFHO0FBQ3ZGLGdCQUFNLFlBQVksYUFBYSxNQUFNLElBQUksRUFBRTtBQUMzQyxlQUFLLFdBQVcsU0FBUztlQUN0QjtBQUNILGVBQUsseUJBQXlCLGNBQWMsS0FBSzs7TUFFekQ7TUFPQSx5QkFBeUIsY0FBc0IsT0FBYTtBQUN4RCxZQUFJLFlBQVk7QUFDaEIsZ0JBQVEsT0FBTztVQUNYLEtBQUs7QUFDRCx3QkFBWSxxQkFBMEIsWUFBWTtBQUNsRCxpQkFBSyxXQUFXLFNBQVM7QUFDekI7VUFDSixLQUFLO0FBQ0Qsd0JBQVksdUJBQTRCLFlBQVk7QUFDcEQsaUJBQUssV0FBVyxTQUFTO0FBQ3pCO1VBQ0osS0FBSztBQUNELHdCQUFZLHVCQUE0QixZQUFZO0FBQ3BELGlCQUFLLFdBQVcsU0FBUztBQUN6QjtVQUNKLEtBQUs7QUFDRCx3QkFBWSxHQUFHLFlBQVk7QUFHM0IsaUJBQUssV0FBVyxTQUFTO0FBQ3pCO1VBQ0osS0FBSztBQUNELHdCQUFZLHdCQUE2QixZQUFZO0FBQ3JELGlCQUFLLFdBQVcsU0FBUztBQUN6QjtVQUNKLEtBQUs7QUFDRCx3QkFBWSxzQkFBMkIsWUFBWTtBQUNuRCxpQkFBSyxXQUFXLFNBQVM7QUFDekI7VUFDSixLQUFLO0FBQ0Qsd0JBQVksc0JBQTJCLFlBQVk7QUFDbkQsaUJBQUssV0FBVyxTQUFTO0FBQ3pCO1VBQ0osS0FBSztBQUNELHdCQUFZLHdCQUE2QixZQUFZO0FBQ3JELGlCQUFLLFdBQVcsU0FBUztBQUN6Qjs7TUFFWjs7Ozs7O0FDN0VKLFNBQVMsY0FBYztBQUF2QixJQUdhO0FBSGI7O0FBQ0E7QUFFTSxJQUFPLGNBQVAsY0FBMkIsUUFBTztNQUNwQyxhQUFhO01BQ2IsMEJBQTBCO01BVTFCLFVBQU87QUFDSCxjQUFNLGVBQWUsS0FBSyxnQkFBZTtBQUN6QyxZQUFJLFlBQVk7QUFFaEIsWUFBSSxhQUFhLE1BQU0sR0FBRyxDQUFDLE1BQU0sUUFBUSxhQUFhLE1BQU0sYUFBYSxTQUFTLEdBQUcsYUFBYSxNQUFNLE1BQU0sTUFBTTtBQUNoSCxzQkFBWSxhQUFhLE1BQU0sR0FBRyxFQUFFO0FBQ3BDLGVBQUssV0FBVyxTQUFTO2VBQ3RCO0FBQ0gsZ0JBQU0sY0FBYyxLQUFLLGlCQUFpQixZQUFZO0FBQ3RELHNCQUFZLEtBQUssV0FBVztBQUM1QixlQUFLLGVBQWUsY0FBYyxTQUFTOztNQUVuRDs7Ozs7O0FDM0JKLFNBQVMsZUFBZTtBQUF4QixJQUdhO0FBSGI7O0FBQ0E7QUFFTSxJQUFPLG9CQUFQLGNBQWlDLFFBQU87TUFDMUMsYUFBYTtNQUNiLDBCQUEwQjtNQVUxQixVQUFPO0FBQ0gsWUFBSSxlQUFlLEtBQUssZ0JBQWU7QUFFdkMsWUFBSSxhQUFhLFNBQVMsY0FBYyxHQUFHO0FBQ3ZDLGdCQUFNLFlBQVksYUFBYSxNQUFNLEVBQUU7QUFDdkMsZUFBSyxXQUFXLFNBQVM7ZUFDdEI7QUFDSCxnQkFBTSxRQUFRLEtBQUssU0FBUTtBQUMzQix5QkFBZTtBQUNmLGVBQUssUUFBUSxPQUFPLFlBQVk7QUFDaEMsZUFBSyxNQUFLOztNQUVsQjs7Ozs7O0FDM0JKLFNBQVMsbUJBQW1CO0FBQTVCLElBR2E7QUFIYjs7QUFDQTtBQUVNLElBQU8sbUJBQVAsY0FBZ0MsUUFBTztNQUN6QyxhQUFhO01BQ2IsMEJBQTBCO01BVTFCLFVBQU87QUFDSCxZQUFJLGVBQWUsS0FBSyxnQkFBZTtBQUV2QyxZQUFJLGFBQWEsU0FBUyxHQUFHLEtBQUssQ0FBQyxhQUFhLFNBQVMsV0FBVyxHQUFHO0FBQ25FLGdCQUFNLFlBQVksYUFBYSxNQUFNLENBQUM7QUFDdEMsZUFBSyxXQUFXLFNBQVM7bUJBQ2xCLGFBQWEsU0FBUyxHQUFHLEtBQUssYUFBYSxTQUFTLFdBQVcsR0FBRztBQUN6RSxnQkFBTSxZQUFZLGFBQWEsTUFBTSxHQUFHLEVBQUU7QUFDMUMsZUFBSyxXQUFXLFNBQVM7ZUFDdEI7QUFDSCxnQkFBTSxRQUFRLEtBQUssU0FBUTtBQUMzQixnQkFBTSxXQUFXO0FBQ2pCLHlCQUFlLEtBQUssZ0JBQWdCLFFBQVE7QUFDNUMsZUFBSyxRQUFRLE9BQU8sWUFBWTtBQUNoQyxlQUFLLE1BQUs7O01BRWxCOzs7Ozs7QUNoQ0osSUFNc0I7QUFOdEI7OztBQU1NLElBQWdCLDJCQUFoQixjQUFpRCxjQUFhO01BQ3RELFNBQXNCLENBQUE7TUFDaEMsVUFBVSxRQUFtQjtBQUN6QixhQUFLLFNBQVM7TUFDbEI7TUFDQSxZQUFTO0FBQ0wsZUFBTyxLQUFLO01BQ2hCOzs7Ozs7QUNWRSxTQUFVLGVBQVk7QUFDeEIsUUFBTSxhQUFhO0FBRW5CLE1BQUksV0FBVyxzQkFBc0IsUUFBVztBQUM1QyxXQUFPLFdBQVc7YUFDWCxXQUFXLDRCQUE0QixRQUFXO0FBQ3pELFdBQU8sV0FBVzthQUNYLFdBQVcseUJBQXlCLFFBQVc7QUFDdEQsV0FBTyxXQUFXO2FBQ1gsV0FBVyx3QkFBd0IsUUFBVztBQUNyRCxXQUFPLFdBQVc7O0FBRXRCLFNBQU87QUFDWDtBQUtNLFNBQVUsaUJBQWM7QUFDMUIsUUFBTSxhQUFhO0FBRW5CLE1BQUksU0FBUyxnQkFBZ0I7QUFDekIsYUFBUyxlQUFjO2FBQ2hCLFdBQVcscUJBQXFCO0FBQ3ZDLGVBQVcsb0JBQW1CO2FBQ3ZCLFdBQVcscUJBQXFCO0FBQ3ZDLGVBQVcsb0JBQW1CO2FBQ3ZCLFdBQVcsc0JBQXNCO0FBQ3hDLGVBQVcscUJBQW9COztBQUV2QztBQUtNLFNBQVUsZ0JBQWdCLFNBQVk7QUFFeEMsTUFBSSxRQUFRLG1CQUFtQjtBQUMzQixZQUFRLGtCQUFpQjthQUNsQixRQUFRLHNCQUFzQjtBQUNyQyxZQUFRLHFCQUFvQjthQUNyQixRQUFRLHFCQUFxQjtBQUNwQyxZQUFRLG9CQUFtQjthQUNwQixRQUFRLHlCQUF5QjtBQUN4QyxZQUFRLHdCQUF1Qjs7QUFFdkM7QUE5Q0E7Ozs7OztBQ0ZBLFNBQVMsa0JBQWtCO0FBQTNCLElBVWE7QUFWYjs7QUFDQTtBQUNBO0FBUU0sSUFBTyxvQkFBUCxjQUFpQyxRQUFPO01BQzFDLGFBQWE7TUFDYiwwQkFBMEI7TUFFMUIsVUFBTztBQUNILFlBQUksYUFBWSxHQUFJO0FBQ2hCLHlCQUFjO2VBQ1g7QUFDSCxnQkFBTSxVQUFVLEtBQUssZ0JBQWdCO0FBQ3JDLDBCQUFnQixPQUFPOztNQUUvQjs7Ozs7O0FDckJKLFNBQVMsaUJBQWlCO0FBQTFCLElBR2E7QUFIYjs7QUFDQTtBQUVNLElBQU8sb0JBQVAsY0FBaUMsUUFBTztNQUMxQyxhQUFhO01BQ2IsMEJBQTBCO01BVTFCLFVBQU87QUFDSCxZQUFJLGVBQWUsS0FBSyxnQkFBZTtBQUV2QyxZQUFJLGFBQWEsU0FBUyxHQUFHLEtBQUssQ0FBQyxhQUFhLFNBQVMsV0FBVyxHQUFHO0FBQ25FLGdCQUFNLFlBQVksYUFBYSxNQUFNLENBQUM7QUFDdEMsZUFBSyxXQUFXLFNBQVM7bUJBQ2xCLGFBQWEsU0FBUyxHQUFHLEtBQUssYUFBYSxTQUFTLFdBQVcsR0FBRztBQUN6RSxnQkFBTSxZQUFZLGFBQWEsTUFBTSxHQUFHLEVBQUU7QUFDMUMsZUFBSyxXQUFXLFNBQVM7ZUFDdEI7QUFDSCxnQkFBTSxXQUFXO0FBQ2pCLGdCQUFNLFFBQVEsS0FBSyxTQUFRO0FBQzNCLHlCQUFlLEtBQUssZ0JBQWdCLFFBQVE7QUFDNUMsZUFBSyxRQUFRLE9BQU8sWUFBWTtBQUNoQyxlQUFLLE1BQUs7O01BRWxCOzs7Ozs7QUMvQkosU0FBUyxnQkFBZ0I7QUFBekIsSUFHYTtBQUhiOztBQUNBO0FBRU0sSUFBTyxnQkFBUCxjQUE2QixRQUFPO01BQ3RDLGFBQWE7TUFDYiwwQkFBMEI7TUFVMUIsVUFBTztBQUNILGNBQU0sZUFBZSxLQUFLLGdCQUFlO0FBQ3pDLFlBQUksWUFBWTtBQUVoQixZQUFJLGFBQWEsT0FBTyxDQUFDLE1BQU0sT0FBTyxhQUFhLE9BQU8sYUFBYSxTQUFTLENBQUMsTUFBTSxLQUFLO0FBQ3hGLHNCQUFZLGFBQWEsTUFBTSxHQUFHLEVBQUU7QUFDcEMsZUFBSyxXQUFXLFNBQVM7ZUFDdEI7QUFDSCxnQkFBTSxjQUFjLEtBQUssaUJBQWlCLFlBQVk7QUFDdEQsc0JBQVksSUFBSSxXQUFXO0FBQzNCLGVBQUssZUFBZSxjQUFjLFNBQVM7O01BRW5EOzs7Ozs7QUMzQkosU0FBUyxnQkFBZ0I7QUFBekIsSUFHYTtBQUhiOztBQUNBO0FBRU0sSUFBTyxxQkFBUCxjQUFrQyxRQUFPO01BQzNDLGFBQWE7TUFDYiwwQkFBMEI7TUFNMUIsVUFBTztBQUNILGNBQU0sZUFBZSxLQUFLLHdCQUF1QjtBQUNqRCxhQUFLLG1CQUFtQixZQUFZO01BQ3hDO01BTUEsbUJBQW1CLGNBQXNCO0FBQ3JDLFlBQUksa0JBQWtCO0FBQ3RCLFlBQUksV0FBVztBQUVmLHFCQUFhLFFBQVEsQ0FBQyxNQUFNLFVBQVM7QUFFakMsY0FBSSxTQUFTLElBQUk7QUFDYixnQkFBSSxhQUFhLFdBQVcsR0FBRztBQUMzQixnQ0FBa0I7QUFDbEI7O2lCQUVEO0FBRUgsK0JBQW1CLEtBQUssZUFBZSxNQUFNLFFBQVE7QUFDckQ7O0FBR0osY0FBSSxVQUFVLGFBQWEsU0FBUyxHQUFHO0FBQ25DLCtCQUFtQjs7UUFFM0IsQ0FBQztBQUNELGFBQUssUUFBUSxLQUFLLFNBQVEsR0FBSSxlQUFlO01BQ2pEO01BUUEsZUFBZSxNQUFjLFVBQWdCO0FBQ3pDLGNBQU0sUUFBUSxLQUFLLFFBQVEsR0FBRztBQUc5QixjQUFNLGNBQWMsS0FBSyxPQUFPLE1BQU07QUFHdEMsWUFBSSxVQUFVLElBQUk7QUFDZCxnQkFBTSxXQUFXLENBQUMsS0FBSyxNQUFNLGFBQWEsS0FBSyxHQUFHLEtBQUssTUFBTSxRQUFRLENBQUMsQ0FBQztBQUd2RSxjQUFJLFNBQVMsQ0FBQyxNQUFNLE1BQU0sQ0FBQyxNQUFNLE9BQU8sU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBRW5ELG1CQUFPLElBQUksT0FBTyxXQUFXLElBQUksU0FBUyxDQUFDLEVBQUUsVUFBVSxDQUFDOzs7QUFLaEUsZUFBTyxJQUFJLE9BQU8sV0FBVyxJQUFJLEdBQUcsUUFBUSxLQUFLLEtBQUssVUFBVSxXQUFXLENBQUM7TUFDaEY7Ozs7OztBQ3JFSixTQUFTLGFBQUFHLGtCQUFpQjtBQUExQixJQUdhO0FBSGI7O0FBQ0E7QUFFTSxJQUFPLG9CQUFQLGNBQWlDLFFBQU87TUFDMUMsYUFBYUE7TUFDYiwwQkFBMEI7TUFVMUIsVUFBTztBQUNILFlBQUksZUFBZSxLQUFLLGdCQUFlO0FBRXZDLFlBQUksYUFBYSxTQUFTLElBQUksS0FBSyxDQUFDLGFBQWEsU0FBUyxXQUFXLEdBQUc7QUFDcEUsZ0JBQU0sWUFBWSxhQUFhLE1BQU0sQ0FBQztBQUN0QyxlQUFLLFdBQVcsU0FBUzttQkFDbEIsYUFBYSxTQUFTLElBQUksS0FBSyxhQUFhLFNBQVMsV0FBVyxHQUFHO0FBQzFFLGdCQUFNLFlBQVksYUFBYSxNQUFNLEdBQUcsRUFBRTtBQUMxQyxlQUFLLFdBQVcsU0FBUztlQUN0QjtBQUNILGdCQUFNLFdBQVc7QUFDakIsZ0JBQU0sUUFBUSxLQUFLLFNBQVE7QUFDM0IseUJBQWUsTUFBTSxnQkFBZ0IsUUFBUTtBQUM3QyxlQUFLLFFBQVEsT0FBTyxZQUFZO0FBQ2hDLGVBQUssTUFBSzs7TUFFbEI7Ozs7OztBQy9CSixTQUFTLGNBQWM7QUFBdkIsSUFHYTtBQUhiOztBQUNBO0FBRU0sSUFBTyxjQUFQLGNBQTJCLFFBQU87TUFDcEMsYUFBYTtNQUNiLDBCQUEwQjtNQVUxQixVQUFPO0FBQ0gsWUFBSSxlQUFlLEtBQUssZ0JBQWU7QUFFdkMsWUFBSSxhQUFhLFNBQVMsYUFBYSxHQUFHO0FBQ3RDLGdCQUFNLFlBQVksYUFBYSxNQUFNLEVBQUU7QUFDdkMsZUFBSyxXQUFXLFNBQVM7ZUFDdEI7QUFDSCxnQkFBTSxRQUFRLEtBQUssU0FBUTtBQUMzQix5QkFBZTtBQUNmLGVBQUssUUFBUSxPQUFPLFlBQVk7QUFDaEMsZUFBSyxNQUFLOztNQUVsQjs7Ozs7O0FDM0JKLFNBQVMsY0FBYztBQUF2QixJQUdhO0FBSGI7O0FBQ0E7QUFFTSxJQUFPLGNBQVAsY0FBMkIsUUFBTztNQUNwQyxhQUFhO01BQ2IsMEJBQTBCO01BUzFCLFVBQU87QUFDSCxZQUFJLGVBQWUsS0FBSyxnQkFBZTtBQUV2QyxZQUFJLGFBQWEsV0FBVyxHQUFHLEtBQUssYUFBYSxTQUFTLEdBQUcsR0FBRztBQUM1RCxnQkFBTSxZQUFZLGFBQWEsTUFBTSxHQUFHLEVBQUU7QUFDMUMsZUFBSyxXQUFXLFNBQVM7ZUFDdEI7QUFDSCxnQkFBTSxRQUFRLEtBQUssU0FBUTtBQUMzQix5QkFBZSxNQUFNLGVBQWU7QUFDcEMsZUFBSyxRQUFRLE9BQU8sWUFBWTtBQUNoQyxlQUFLLE1BQUs7O01BRWxCOzs7Ozs7QUMxQkosU0FBUyxnQkFBZ0I7QUFBekIsSUFHYTtBQUhiOztBQUNBO0FBRU0sSUFBTyx1QkFBUCxjQUFvQyxRQUFPO01BQzdDLGFBQWE7TUFDYiwwQkFBMEI7TUFNMUIsVUFBTztBQUNILGNBQU0sZUFBZSxLQUFLLHdCQUF1QjtBQUNqRCxhQUFLLG1CQUFtQixZQUFZO01BQ3hDO01BTUEsbUJBQW1CLGNBQXNCO0FBQ3JDLFlBQUksa0JBQWtCO0FBRXRCLHFCQUFhLFFBQVEsQ0FBQyxNQUFNLFVBQVM7QUFFakMsY0FBSSxTQUFTLElBQUk7QUFDYixnQkFBSSxhQUFhLFdBQVcsR0FBRztBQUMzQixnQ0FBa0I7QUFDbEI7O2lCQUVEO0FBQ0gsK0JBQW1CLEtBQUssZUFBZSxJQUFJOztBQUcvQyxjQUFJLFVBQVUsYUFBYSxTQUFTLEdBQUc7QUFDbkMsK0JBQW1COztRQUUzQixDQUFDO0FBQ0QsYUFBSyxRQUFRLEtBQUssU0FBUSxHQUFJLGVBQWU7TUFDakQ7TUFPQSxlQUFlLE1BQVk7QUFDdkIsY0FBTSxRQUFRLEtBQUssUUFBUSxHQUFHO0FBRzlCLGNBQU0sY0FBYyxLQUFLLE9BQU8sTUFBTTtBQUd0QyxZQUFJLFVBQVUsSUFBSTtBQUNkLGdCQUFNLFdBQVcsQ0FBQyxLQUFLLE1BQU0sYUFBYSxLQUFLLEdBQUcsS0FBSyxNQUFNLFFBQVEsQ0FBQyxDQUFDO0FBR3ZFLGNBQUksU0FBUyxDQUFDLE1BQU0sTUFBTSxTQUFTLENBQUMsRUFBRSxVQUFVLEtBQUssU0FBUyxDQUFDLEVBQUUsV0FBVyxHQUFHLEdBQUc7QUFFOUUsbUJBQU8sSUFBSSxPQUFPLFdBQVcsSUFBSSxTQUFTLENBQUMsRUFBRSxVQUFVLENBQUM7OztBQUtoRSxlQUFPLElBQUksT0FBTyxXQUFXLElBQUksS0FBSyxLQUFLLFVBQVUsV0FBVyxDQUFDO01BQ3JFOzs7Ozs7QUNqRUosU0FBUyxhQUFBQyxrQkFBaUI7QUFBMUIsSUFHYTtBQUhiOztBQUNBO0FBRU0sSUFBTyxzQkFBUCxjQUFtQyxRQUFPO01BQzVDLGFBQWFBO01BQ2IsMEJBQTBCO01BVTFCLFVBQU87QUFDSCxZQUFJLGVBQWUsS0FBSyxnQkFBZTtBQUV2QyxZQUFJLGFBQWEsU0FBUyxLQUFLLEtBQUssQ0FBQyxhQUFhLFNBQVMsV0FBVyxHQUFHO0FBQ3JFLGdCQUFNLFlBQVksYUFBYSxNQUFNLENBQUM7QUFDdEMsZUFBSyxXQUFXLFNBQVM7bUJBQ2xCLGFBQWEsU0FBUyxLQUFLLEtBQUssYUFBYSxTQUFTLFdBQVcsR0FBRztBQUMzRSxnQkFBTSxZQUFZLGFBQWEsTUFBTSxHQUFHLEVBQUU7QUFDMUMsZUFBSyxXQUFXLFNBQVM7ZUFDdEI7QUFDSCxnQkFBTSxXQUFXO0FBQ2pCLGdCQUFNLFFBQVEsS0FBSyxTQUFRO0FBQzNCLHlCQUFlLE9BQU8sZ0JBQWdCLFFBQVE7QUFDOUMsZUFBSyxRQUFRLE9BQU8sWUFBWTtBQUNoQyxlQUFLLE1BQUs7O01BRWxCOzs7Ozs7QUMvQkosU0FBUyxrQkFBa0I7QUFBM0IsSUFHYTtBQUhiOztBQUNBO0FBRU0sSUFBTyxtQkFBUCxjQUFnQyxRQUFPO01BQ3pDLGFBQWE7TUFDYiwwQkFBMEI7TUFNMUIsVUFBTztBQUNILFlBQUksZUFBZSxLQUFLLGdCQUFlO0FBQ3ZDLGNBQU0sUUFBUSxLQUFLLFNBQVE7QUFDM0IsY0FBTSxXQUFXO0FBQ2pCLHVCQUFlLGVBQWUsZ0JBQWdCLFlBQVk7QUFDMUQsYUFBSyxRQUFRLE9BQU8sWUFBWTtBQUNoQyxhQUFLLE1BQUs7TUFDZDs7Ozs7O0FDbkJKLElBR3NCO0FBSHRCOzs7QUFHTSxJQUFnQixxQkFBaEIsY0FBMkMsUUFBTztNQUMxQyxTQUFzQixDQUFBO01BRWhDLFlBQVM7QUFDTCxlQUFPLEtBQUs7TUFDaEI7TUFFQSxVQUFVLFFBQW1CO0FBQ3pCLGFBQUssU0FBUztNQUNsQjs7Ozs7O0FDWkosSUFHYTtBQUhiOzs7QUFHTSxJQUFPLHlCQUFQLGNBQXNDLGFBQVk7TUFDN0M7TUFDQTtNQUNBO01BRVAsY0FBQTtBQUNJLGNBQU0saUJBQWlCLGVBQWU7TUFDMUM7Ozs7OztBQ0xKLElBQWE7QUFBYjs7QUFBTSxJQUFPLGVBQVAsTUFBbUI7TUFDZDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQSxVQUFVO01BRWpCLGNBQUE7QUFDSSxhQUFLLFlBQVk7QUFDakIsYUFBSyxPQUFPO01BQ2hCOzs7Ozs7QUNqQkosU0FBUyxhQUFBQyxZQUFXLGdCQUFBQyxlQUFjLFNBQUFDLFFBQU8sVUFBQUMsU0FBUSx5QkFBeUI7QUFFMUUsU0FBUyxTQUFTLHFCQUFxQix1QkFBdUIsUUFBUSxrQkFBa0IsU0FBUyxlQUFlO0FBQ2hILFNBQVMsVUFBVSxnQkFBZ0I7Ozs7Ozs7OztBQytCM0IsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFHSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSw2RUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxrQkFBQSxZQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxPQUFBLGdCQUFBLGVBQUEsQ0FBNkI7SUFBQSxDQUFBO0FBRXRDLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUVJLElBQUEseUJBQUEsaUJBQUEsU0FBQSxzRkFBQSxRQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLGtCQUFBLFlBQUE7QUFBQSxhQUFhLDBCQUFBLGdCQUFBLE9BQUEsTUFBQTtJQUMzQixDQUFBLEVBRDZDLFNBQUEsU0FBQSxnRkFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQ3RCLDBCQUFBLE9BQUEsZ0JBQUEsS0FBQSxDQUEyQjtJQUFBLENBQUE7O0FBSHhDLElBQUEsMkJBQUE7QUFNQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQTRDLElBQUEseUJBQUEsU0FBQSxTQUFBLDhFQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLE9BQUEsWUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxhQUFBLElBQUEsQ0FBZTtJQUFBLENBQUE7QUFDaEUsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxXQUFBLENBQUE7O0FBS0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUVJLElBQUEseUJBQUEsaUJBQUEsU0FBQSxzRkFBQSxRQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLGtCQUFBLFlBQUE7QUFBQSxhQUFhLDBCQUFBLGdCQUFBLE9BQUEsTUFBQTtJQUMzQixDQUFBLEVBRDZDLFNBQUEsU0FBQSxnRkFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQ3RCLDBCQUFBLFFBQUEsZ0JBQUEsS0FBQSxDQUEyQjtJQUFBLENBQUE7O0FBSHhDLElBQUEsMkJBQUE7QUFNSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxXQUFBLENBQUE7O0FBS0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUVJLElBQUEseUJBQUEsaUJBQUEsU0FBQSxzRkFBQSxRQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLGtCQUFBLFlBQUE7QUFBQSxhQUFhLDBCQUFBLGdCQUFBLGNBQUEsTUFBQTtJQUMzQixDQUFBLEVBRG9ELFNBQUEsU0FBQSxnRkFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQzdCLDBCQUFBLFFBQUEsZ0JBQUEsS0FBQSxDQUEyQjtJQUFBLENBQUE7O0FBSHhDLElBQUEsMkJBQUE7QUFNSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7Ozs7OztBQTlDUyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHFDQUFBLE1BQUEsa0JBQUEsTUFBQSxFQUFBO0FBSU8sSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLGdCQUFBLFlBQUEsb0NBQUEsK0JBQUE7QUFHUyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsZ0JBQUEsWUFBQSxPQUFBLFVBQUEsT0FBQSxPQUFBO0FBTVQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxlQUFBLDBCQUFBLElBQUEsSUFBQSxnRUFBQSxDQUFBO0FBRkEsSUFBQSx5QkFBQSxXQUFBLGdCQUFBLElBQUE7QUFLUyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxPQUFBO0FBT1QsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxjQUFBLDBCQUFBLElBQUEsSUFBQSw0REFBQSxDQUFBO0FBRkEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsZ0JBQUE7QUFRQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLG9DQUFBLGVBQUEsMEJBQUEsSUFBQSxJQUFBLGdFQUFBLENBQUE7QUFGQSxJQUFBLHlCQUFBLFdBQUEsZ0JBQUEsSUFBQTtBQVNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsb0NBQUEsY0FBQSwwQkFBQSxJQUFBLElBQUEsbUVBQUEsQ0FBQTtBQUZBLElBQUEseUJBQUEsUUFBQSxPQUFBLG1CQUFBO0FBUUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxlQUFBLDBCQUFBLElBQUEsSUFBQSx1RUFBQSxDQUFBO0FBRkEsSUFBQSx5QkFBQSxXQUFBLGdCQUFBLFdBQUE7OztBRDFFcEIsSUFZYTtBQVpiOztBQUNBO0FBR0E7OztBQVFNLElBQU8sd0NBQVAsTUFBTyx1Q0FBcUM7TUFDOUM7TUFFQSxJQUNJLFNBQVMsVUFBZ0M7QUFDekMsYUFBSyxZQUFZO01BQ3JCO01BQ0EsSUFBSSxXQUFRO0FBQ1IsZUFBTyxLQUFLO01BQ2hCO01BRVUsa0JBQWtCLElBQUlGLGNBQVk7TUFHNUMsbUJBQW1CO01BQ25CLHdCQUF3QjtNQUN4QixzQkFBc0I7TUFDdEIsV0FBVztNQUNYLFVBQVU7TUFDVixXQUFXO01BQ1gsU0FBUztNQUNULFVBQVU7TUFDVixVQUFVO01BRVYsY0FBQTtNQUFlO01BRWYsZ0JBQWE7QUFDVCxZQUFJLFdBQVcsS0FBSyxTQUFTLFFBQVE7QUFFckMsWUFBSSxLQUFLLFNBQVMsTUFBTTtBQUNwQixzQkFBWSxlQUFnQixLQUFLLFNBQVM7O0FBRTlDLFlBQUksS0FBSyxTQUFTLGFBQWE7QUFDM0Isc0JBQVksY0FBZSxLQUFLLFNBQVM7O0FBRzdDLFlBQUksS0FBSyxTQUFTLGlCQUFpQixLQUFLLFNBQVMsY0FBYyxTQUFTLEdBQUc7QUFDdkUsc0JBQVk7QUFFWixlQUFLLFNBQVMsY0FBYyxRQUFRLENBQUMsaUJBQWdCO0FBQ2pELHdCQUFZLFFBQVEsYUFBYSxZQUFZLGVBQWUsY0FBYyxhQUFhO0FBRXZGLGdCQUFJLGFBQWEsTUFBTTtBQUNuQiwwQkFBWSxlQUFnQixhQUFhOztBQUU3QyxnQkFBSSxhQUFhLGFBQWE7QUFDMUIsMEJBQVksY0FBZSxhQUFhOztVQUVoRCxDQUFDOztBQUdMLGVBQU87TUFDWDtNQUVBLGFBQWEsT0FBYTtBQUN0QixhQUFLLFNBQVMsZUFBZSxPQUFPLE9BQU8sQ0FBQztBQUU1QyxhQUFLLGdCQUFnQixLQUFJO01BQzdCO01BRUEsZ0JBQWdCLGNBQTBCO0FBQ3RDLFlBQUksS0FBSyxzQkFBcUIsS0FBTSxDQUFDLGFBQWEsV0FBVztBQUN6RDs7QUFHSixxQkFBYSxZQUFZLENBQUMsYUFBYTtBQUV2QyxhQUFLLGdCQUFnQixLQUFJO01BQzdCO01BRUEsd0JBQXFCO0FBQ2pCLGVBQU8sS0FBSyxTQUFTLGdCQUFnQixLQUFLLFNBQVMsZUFBZSxLQUFLLENBQUMsV0FBVyxPQUFPLFNBQVM7TUFDdkc7TUFFQSxlQUFZO0FBQ1IsWUFBSSxLQUFLLFNBQVMsa0JBQWtCLFFBQVc7QUFDM0MsZUFBSyxTQUFTLGdCQUFnQixDQUFBOztBQUdsQyxhQUFLLFNBQVMsZUFBZSxLQUFLLElBQUksYUFBWSxDQUFFO0FBRXBELGFBQUssZ0JBQWdCLEtBQUk7TUFDN0I7O3lCQWxGUyx3Q0FBcUM7TUFBQTtpRUFBckMsd0NBQXFDLFdBQUEsQ0FBQSxDQUFBLHFDQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxXQUFBLEdBQUEsU0FBQSxFQUFBLGlCQUFBLGtCQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLG9CQUFBLGFBQUEsR0FBQSxDQUFBLE1BQUEsZUFBQSxRQUFBLEtBQUEsR0FBQSxnQkFBQSxxQkFBQSxHQUFBLFdBQUEsZUFBQSxpQkFBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLHFCQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLFFBQUEsR0FBQSxRQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxXQUFBLGVBQUEsaUJBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLHNCQUFBLEdBQUEsQ0FBQSxNQUFBLHdCQUFBLEdBQUEsT0FBQSxhQUFBLGVBQUEsUUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsK0RBQUEsR0FBQSxDQUFBLEdBQUEsd0JBQUEscUJBQUEsR0FBQSxJQUFBLEdBQUEsQ0FBQSxHQUFBLHFCQUFBLGtDQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsV0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGtDQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxzQkFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLCtDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDWmxELFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQUksVUFBQSxxQkFBQSxDQUFBOztBQUF1RixVQUFBLDJCQUFBO0FBQzNGLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLFlBQUEsQ0FBQTtBQUdJLFVBQUEseUJBQUEsaUJBQUEsU0FBQSxpRkFBQSxRQUFBO0FBQUEsbUJBQUEsSUFBQSxTQUFBLE9BQUE7VUFBQSxDQUFBLEVBQWdDLFNBQUEsU0FBQSwyRUFBQTtBQUFBLG1CQUV2QixJQUFBLGdCQUFBLEtBQUE7VUFBMkIsQ0FBQTs7QUFFdkMsVUFBQSwyQkFBQTtBQUNELFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTs7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxTQUFBLENBQUE7QUFFSSxVQUFBLHlCQUFBLGlCQUFBLFNBQUEsK0VBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsU0FBQSxPQUFBO1VBQUEsQ0FBQSxFQUEyQixTQUFBLFNBQUEseUVBQUE7QUFBQSxtQkFDbEIsSUFBQSxnQkFBQSxLQUFBO1VBQTJCLENBQUE7O0FBSHhDLFVBQUEsMkJBQUE7QUFNSixVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLENBQUE7O0FBS0EsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsU0FBQSxDQUFBO0FBRUksVUFBQSx5QkFBQSxpQkFBQSxTQUFBLCtFQUFBLFFBQUE7QUFBQSxtQkFBQSxJQUFBLFNBQUEsY0FBQTtVQUFBLENBQUEsRUFBa0MsU0FBQSxTQUFBLHlFQUFBO0FBQUEsbUJBQ3pCLElBQUEsZ0JBQUEsS0FBQTtVQUEyQixDQUFBOztBQUh4QyxVQUFBLDJCQUFBO0FBTUosVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsSUFBQTtBQUFJLFVBQUEscUJBQUEsRUFBQTs7QUFBc0YsVUFBQSwyQkFBQTtBQUMxRixVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsK0JBQUEsSUFBQSx1REFBQSxJQUFBLElBQUEsTUFBQSxNQUFBLHVDQUFBO0FBZ0RBLFVBQUEsNkJBQUEsSUFBQSxVQUFBLENBQUE7QUFBeUUsVUFBQSx5QkFBQSxTQUFBLFNBQUEsMEVBQUE7QUFBQSxtQkFBUyxJQUFBLGFBQUE7VUFBYyxDQUFBO0FBQzVGLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUFyRlEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSwwQkFBQSxHQUFBLElBQUEsOERBQUEsQ0FBQTtBQU9BLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsb0NBQUEsZUFBQSwwQkFBQSxHQUFBLElBQUEsZ0VBQUEsQ0FBQTtBQUhBLFVBQUEseUJBQUEsV0FBQSxJQUFBLFNBQUEsSUFBQTtBQU0rRCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLG9DQUFBLGNBQUEsMEJBQUEsSUFBQSxJQUFBLDREQUFBLENBQUE7QUFBdEQsVUFBQSx5QkFBQSxRQUFBLElBQUEsZ0JBQUE7QUFLTCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLG9DQUFBLGVBQUEsMEJBQUEsSUFBQSxJQUFBLGdFQUFBLENBQUE7QUFGQSxVQUFBLHlCQUFBLFdBQUEsSUFBQSxTQUFBLElBQUE7QUFTQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLG9DQUFBLGNBQUEsMEJBQUEsSUFBQSxJQUFBLG1FQUFBLENBQUE7QUFGQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxtQkFBQTtBQVFBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsb0NBQUEsZUFBQSwwQkFBQSxJQUFBLElBQUEsdUVBQUEsQ0FBQTtBQUZBLFVBQUEseUJBQUEsV0FBQSxJQUFBLFNBQUEsV0FBQTtBQUtKLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLDZEQUFBLENBQUE7QUFDSixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsU0FBQSxhQUFBO0FBaURhLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLE1BQUE7Ozs7O3FGRHRFSix1Q0FBcUMsRUFBQSxXQUFBLHdDQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVpsRCxJQUdhO0FBSGI7OztBQUdNLElBQU8sMkJBQVAsY0FBd0MsbUJBQWtCO01BQzVEO01BRUEsMEJBQTBCO01BRTFCLFlBQVksY0FBMEI7QUFDbEMsY0FBSztBQUNMLGFBQUssZUFBZTtBQUVwQixhQUFLLFVBRUQsS0FBSyxhQUFhLFVBQVMsRUFBRyxXQUFXLElBQUksQ0FBQyxjQUFjO1VBQ3hELElBQUksU0FBUyxHQUFJLFNBQVE7VUFDekIsT0FBTyxTQUFTO1VBQ2hCLE1BQU0sU0FBUztVQUNqQixDQUFFO01BRVo7TUFTQSxRQUFRLG9CQUEwQjtBQUM5QixjQUFNLG1CQUFtQixLQUFLLFVBQVMsRUFBRyxLQUFLLENBQUMsVUFBVSxNQUFNLEdBQUcsU0FBUSxNQUFPLGtCQUFrQjtBQUNwRyxjQUFNLGdCQUFnQixJQUFJLGlCQUFpQixJQUFJLElBQUksaUJBQWlCLEtBQUssSUFBSSxLQUFLLGFBQWEsbUJBQW1CLGlCQUFpQixFQUFFLENBQUMsTUFBTSxpQkFBaUIsSUFBSTtBQUNqSyxhQUFLLFdBQVcsYUFBYTtBQUM3QixhQUFLLE1BQUs7TUFDZDs7Ozs7O0FDakNKLElBUXNCO0FBUnRCOzs7QUFRTSxJQUFnQiwyQkFBaEIsY0FBaUQsbUJBQWtCO01BQzdEO01BQ1IsVUFBTztBQUNILGFBQUssVUFBVSxZQUFZLEtBQUssNEJBQTJCLENBQUU7TUFDakU7TUFFUTtNQUVSLFVBQVUsV0FBYztBQUNwQixjQUFNLFVBQVUsU0FBUztBQUV6QixhQUFLLFVBQVUsU0FBUyxXQUFXO1VBQy9CLE1BQU0sS0FBSyw0QkFBMkI7VUFDdEMsU0FBUyxFQUFFLEtBQUssS0FBSyw0QkFBMkIsR0FBSSxLQUFLLEtBQUssNEJBQTJCLEVBQUU7VUFDM0YsTUFBTSxDQUFDLFdBQWU7QUFDbEIsZ0JBQUksS0FBSyxxQkFBcUI7QUFDMUI7O0FBR0osa0JBQU0saUJBQWlCLEtBQUssa0JBQWlCO0FBQzdDLGtCQUFNLGNBQWMsT0FBTyxRQUFRLFFBQVEsZUFBZSxHQUFHLEVBQUUsVUFBVSxHQUFHLGVBQWUsTUFBTTtBQUVqRyxtQkFBTyxPQUFPLEtBQUssNEJBQTJCLENBQUU7QUFDaEQsZ0JBQUksZUFBZSxXQUFXLEtBQUssWUFBWSxNQUFNLEVBQUUsRUFBRSxNQUFNLElBQUksR0FBRztBQUNsRSxtQkFBSyxzQkFBc0I7QUFDM0IsbUJBQUssMkJBQTJCLEtBQUk7QUFDcEMsbUJBQUssVUFBVSxNQUFLOztVQUU1QjtTQUNJO01BQ1o7TUFFQSw2QkFBNkIsV0FBb0M7QUFDN0QsYUFBSyw0QkFBNEI7TUFDckM7TUFFQSxnQkFBZ0IsVUFBb0M7QUFDaEQsWUFBSSxhQUFhLFFBQVc7QUFDeEIsZ0JBQU0saUJBQWlCLEtBQUssVUFBVSxrQkFBaUI7QUFFdkQsZUFBSyxVQUFVLFFBQ1YsWUFBVyxFQUNYLGFBQWEsZUFBZSxLQUFLLEtBQUsscUJBQXFCLFFBQVEsZUFBZSxNQUFNLEtBQUssb0JBQW9CLFNBQVMsR0FBRyxlQUFlLE1BQU07QUFFdkosZUFBSyxzQkFBc0I7QUFFM0IsZUFBSyxXQUFXLEtBQUssZ0JBQWdCLFFBQVEsQ0FBQzs7QUFHbEQsYUFBSyxzQkFBc0I7QUFDM0IsYUFBSyxVQUFVLE1BQUs7TUFDeEI7TUFRQSwwQkFBdUI7QUFDbkIsY0FBTSxpQkFBaUIsTUFBTSxrQkFBaUI7QUFDOUMsZUFBTyxLQUFLLFVBQVUsU0FBUyx3QkFBd0IsZUFBZSxLQUFLLGVBQWUsTUFBTTtNQUNwRztNQUVBLG1CQUFnQjtBQUNaLFlBQUksQ0FBQyxLQUFLLHFCQUFxQjtBQUMzQjs7QUFHSixjQUFNLGlCQUFpQixLQUFLLFVBQVUsa0JBQWlCO0FBQ3ZELGNBQU0sY0FBYyxLQUFLLFVBQVUsUUFBUSxRQUFRLGVBQWUsR0FBRztBQUVyRSxjQUFNLGNBQWMsWUFDZixVQUFVLGVBQWUsUUFBUSxLQUFLLG9CQUFvQixNQUFNLEtBQUssb0JBQW9CLFNBQVMsR0FBRyxlQUFlLFNBQVMsQ0FBQyxFQUM5SCxZQUFZLEtBQUssNEJBQTJCLENBQUU7QUFFbkQsWUFBSSxlQUFlLEdBQUc7QUFDbEIsZ0JBQU0sYUFBYSxZQUNkLFVBQVUsR0FBRyxlQUFlLFNBQVMsQ0FBQyxFQUN0QyxNQUFNLEtBQUssNEJBQTJCLENBQUUsRUFDeEMsSUFBRztBQUVSLGVBQUssMEJBQTBCLGlCQUFpQixVQUFVO2VBQ3ZEO0FBQ0gsZUFBSywwQkFBMEIsTUFBSzs7TUFFNUM7Ozs7OztBQy9GSixTQUFTLG1CQUFtQixhQUFBRyxZQUFXLGNBQUFDLGFBQVksU0FBQUMsUUFBb0QsaUJBQWlCO0FBSXhILFNBQVMsU0FBUyxVQUFVLHNCQUFzQixXQUFXLFdBQVcsYUFBYTtBQUVyRixTQUFTLGFBQWEseUJBQXlCOzs7Ozs7O0FDQ25DLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLENBQUE7QUFBc0MsSUFBQSx5QkFBQSxTQUFBLFNBQUEsb0VBQUE7QUFBQSxZQUFBLGNBQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsV0FBQSxZQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxPQUFBLGFBQUEsUUFBQSxDQUFtQjtJQUFBLENBQUE7QUFBRSxJQUFBLHFCQUFBLENBQUE7QUFBZ0IsSUFBQSwyQkFBQTtBQUN4RixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7OztBQUR3RSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFNBQUEsSUFBQTs7O0FEUGhGLGVBbUJhO0FBbkJiOztBQUNBO0FBQ0E7QUFDQTs7OztBQWdCTSxJQUFPLDRCQUFQLE1BQU8sMkJBQXlCO01BZ0JiO01BQ0E7TUFoQlo7TUFDQTtNQUVlO01BQ0Q7TUFFZixnQkFBZ0IsSUFBSSxRQUFPO01BQ2xCLFVBQVUsSUFBSSxRQUFPO01BRXRDLFNBQTJCLENBQUE7TUFDM0I7TUFDQTtNQUNBO01BRUEsWUFDcUIsY0FDQSxLQUFzQjtBQUR0QixhQUFBLGVBQUE7QUFDQSxhQUFBLE1BQUE7TUFDbEI7TUFFSCxXQUFRO0FBQ0osYUFBSyxRQUFRLDZCQUE2QixJQUFJO0FBRTlDLGFBQUssUUFDQSxLQUNHLFNBQVMsQ0FBQyxnQkFBZTtBQUNyQixpQkFBTyxNQUFNLFlBQVksYUFBYSxJQUFJLEdBQUc7UUFDakQsQ0FBQyxHQUNELHFCQUFxQixDQUFDLE1BQU0sU0FBUTtBQUNoQyxpQkFBTyxTQUFTO1FBQ3BCLENBQUMsR0FDRCxVQUFVLENBQUMsZ0JBQWdCLEtBQUssUUFBUSxjQUFjLFlBQVksVUFBVSxDQUFDLEdBQzdFLFVBQVUsS0FBSyxhQUFhLENBQUMsRUFFaEMsVUFBVTtVQUNQLE1BQU0sQ0FBQyxRQUF1QztBQUMxQyxpQkFBSyxTQUFTLElBQUk7QUFDbEIsaUJBQUssSUFBSSxjQUFhO1VBQzFCO1VBQ0EsT0FBTyxDQUFDLGtCQUFvQztBQUN4QyxvQkFBUSxLQUFLLGNBQWMsYUFBYTtVQUM1QztTQUNIO01BQ1Q7TUFFQSxZQUFZLFNBQXNCO0FBQzlCLFlBQUksUUFBUSxxQkFBcUI7QUFDN0IsZUFBSyxRQUFRLGlCQUFnQjs7TUFFckM7TUFFQSxjQUFXO0FBQ1AsYUFBSyxjQUFjLEtBQUk7QUFDdkIsYUFBSyxjQUFjLFNBQVE7TUFDL0I7TUFFQSxPQUFJO0FBQ0EsYUFBSyxTQUFTLEtBQUk7TUFDdEI7TUFFQSxRQUFLO0FBQ0QsYUFBSyxTQUFTLE1BQUs7TUFDdkI7TUFFQSxpQkFBaUIsYUFBaUMsYUFBYSxPQUFLO0FBQ2hFLGNBQU0sYUFBYSxhQUFhLEtBQUksRUFBRyxZQUFXLEtBQU07QUFDeEQsYUFBSyxRQUFRLEtBQUssRUFBRSxZQUFZLFdBQVUsQ0FBRTtNQUNoRDtNQUVBLGlCQUFjO0FBQ1YsY0FBTSxpQkFBaUIsS0FBSyxRQUFRLHdCQUF1QjtBQUMzRCxjQUFNLG1CQUFtQixLQUFLLFlBQVksY0FBYyxzQkFBcUI7QUFDN0UsYUFBSyxVQUFVLGVBQWUsUUFBUSxpQkFBaUIsT0FBTztBQUM5RCxhQUFLLFVBQVUsZUFBZSxRQUFRLGlCQUFpQixNQUFNO0FBQzdELGFBQUssaUJBQWlCLElBQUksSUFBSTtBQUM5QixhQUFLLElBQUksY0FBYTtNQUMxQjtNQUVBLG1CQUFnQjtBQUNaLGFBQUssUUFBUSxnQkFBZ0IsS0FBSyxhQUFhO0FBQy9DLGFBQUssZ0JBQWdCO01BQ3pCO01BRUEsYUFBYSxPQUFVO0FBQ25CLGFBQUssZ0JBQWdCO0FBQ3JCLGFBQUssU0FBUyxNQUFLO01BQ3ZCO01BRUEsZUFBWTtBQUNSLFlBQUksS0FBSyxTQUFTLE9BQU0sR0FBSTtBQUN4QixlQUFLLE1BQUs7ZUFDUDtBQUNILGVBQUssUUFBUSxRQUFPOztNQUU1Qjs7eUJBOUZTLDRCQUF5QixnQ0FBQSxZQUFBLEdBQUEsZ0NBQUEscUJBQUEsQ0FBQTtNQUFBO2lFQUF6Qiw0QkFBeUIsV0FBQSxDQUFBLENBQUEsd0JBQUEsQ0FBQSxHQUFBLFdBQUEsU0FBQSxnQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtvQ0FJdkIsYUFBVyxDQUFBOzs7Ozs7OztpSUFOWCxDQUFDLGlCQUFpQixDQUFDLEdBQUEsa0NBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLGVBQUEsSUFBQSxhQUFBLFVBQUEsR0FBQSxrQkFBQSxHQUFBLGFBQUEsWUFBQSxHQUFBLENBQUEsWUFBQSxFQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxPQUFBLFVBQUEsUUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEscUJBQUEsSUFBQSxNQUFBLFVBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsbUJBQUEsRUFBQSxHQUFBLENBQUEsbUJBQUEsSUFBQSxRQUFBLFVBQUEsR0FBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsbUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNqQmxDLFVBQUEsNkJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQTtBQUFrRCxVQUFBLHlCQUFBLGNBQUEsU0FBQSw2REFBQSxRQUFBO0FBQUEsbUJBQUEsU0FBdUIsSUFBQSxlQUFBLElBQW1CLElBQUEsaUJBQUE7VUFBa0IsQ0FBQTtBQUMxRyxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxVQUFBLENBQUE7QUFBOEMsVUFBQSx5QkFBQSxTQUFBLFNBQUEsNkRBQUE7QUFBQSxtQkFBUyxJQUFBLGFBQUE7VUFBYyxDQUFBO0FBQ2pFLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNKLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx3QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwrQkFBQSxJQUFBLDJDQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7QUFHSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQVhtSSxVQUFBLHlCQUFBLGFBQUEsOEJBQUEsR0FBQSxHQUFBLENBQUE7QUFFbEgsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsUUFBQSxVQUFBO0FBRStDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsT0FBQSxJQUFBLE9BQUEsRUFBcUIsUUFBQSxJQUFBLE9BQUE7QUFFN0UsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLE1BQUE7Ozs7O3FGRGFLLDJCQUF5QixFQUFBLFdBQUEsNEJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFbkJ0QyxTQUF3QixhQUFBQyxZQUFXLGNBQWMsY0FBQUMsYUFBWSxnQkFBQUMsZUFBYyxTQUFBQyxRQUFPLFVBQUFDLFNBQVEsYUFBQUMsWUFBVyxxQkFBQUMsMEJBQXlCO0FBSTlILE9BQU87QUFDUCxPQUFPO0FBQ1AsT0FBTztBQUNQLE9BQU87QUFFUCxPQUFPLGNBQWM7QUF5QnJCLFNBQVMsYUFBYSxjQUFjLGFBQWEsb0JBQUFDLHlCQUF3QjtBQUV6RSxTQUFTLE1BQU0sWUFBWTs7Ozs7Ozs7O0FDL0JYLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLENBQUE7QUFBdUQsSUFBQSxxQkFBQSxDQUFBOztBQUE2QyxJQUFBLDJCQUFBO0FBQ3hHLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7O0FBRDJELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLG9CQUFBLENBQUE7Ozs7OztBQW9CL0MsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUEyRyxJQUFBLHlCQUFBLFVBQUEsU0FBQSxzRkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFVLDBCQUFBLFFBQUEsYUFBQSxNQUFBLENBQW9CO0lBQUEsQ0FBQTtBQUF6SSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQWtDLElBQUEscUJBQUEsQ0FBQTs7QUFBK0QsSUFBQSwyQkFBQTtBQUNqRyxJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsS0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsRUFBQTs7QUFDSixJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFUNkYsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLElBQUE7QUFHL0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsc0NBQUEsQ0FBQTtBQUVyQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxnQkFBQSxFQUF5QixjQUFBLDBCQUFBLElBQUEsR0FBQSxpQ0FBQSxDQUFBOzs7OztBQU85QyxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQStELElBQUEsd0JBQUEsR0FBQSxNQUFBO0FBQWEsSUFBQSwyQkFBQTtBQUNoRixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFEYSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxXQUFBOzs7Ozs7QUE3QmpCLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsa0JBQUEsSUFBQSxFQUFBO0FBS0ksSUFBQSx5QkFBQSxjQUFBLFNBQUEscUZBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQWMsMEJBQUEsUUFBQSxtQkFBQSxNQUFBLENBQTBCO0lBQUEsQ0FBQSxFQUFDLGVBQUEsU0FBQSxzRkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFBQSwwQkFBQSxRQUFBLHNCQUFBLE1BQUE7SUFBQSxDQUFBLEVBQUEsWUFBQSxTQUFBLG1GQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUk3QiwwQkFBQSxRQUFBLG1CQUFtQixPQUFBLGVBQUEsSUFBMEIsRUFBRTtJQUFBLENBQUEsRUFKbEIsUUFBQSxTQUFBLCtFQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUtqQywwQkFBQSxRQUFBLG1CQUFtQixRQUFBLFdBQUEsTUFBQSxJQUFxQixFQUFFO0lBQUEsQ0FBQSxFQUxULFNBQUEsU0FBQSxnRkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBO0FBQUEsYUFNaEMsMEJBQUEsUUFBQSxtQkFBbUIsUUFBQSxZQUFBLE1BQUEsSUFBc0IsRUFBRTtJQUFBLENBQUE7QUFFeEQsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwrREFBQSxJQUFBLENBQUE7QUFZQSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsZ0VBQUEsR0FBQSxDQUFBO0FBR0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTs7OztBQWhDUyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsOEJBQUEsR0FBQSxLQUFBLE9BQUEsZUFBQSxDQUFBLEVBQStDLE1BQUEsT0FBQSxzQkFBQTtBQVM1QyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGNBQUEsT0FBQSxnQkFBQTtBQU5BLElBQUEseUJBQUEsUUFBQSxPQUFBLGlCQUFBLElBQUEsRUFBOEIscUJBQUEsT0FBQSxpQkFBQSxpQkFBQSxFQUFBLFFBQUEsT0FBQSxZQUFBLEVBQUE7QUFhbEMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsbUJBQUEsSUFBQSxFQUFBO0FBWUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsZUFBQSxLQUFBLEVBQUE7Ozs7O0FBU0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUF1RCxJQUFBLHFCQUFBLENBQUE7O0FBQStDLElBQUEsMkJBQUE7QUFDMUcsSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7QUFEMkQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsc0JBQUEsQ0FBQTs7Ozs7QUFHdkQsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7OztBQUtJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBLENBQUE7QUFBdUQsSUFBQSxxQkFBQSxDQUFBOztBQUFnRCxJQUFBLDJCQUFBO0FBQzNHLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7O0FBRDJELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLHVCQUFBLENBQUE7Ozs7O0FBS25ELElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBaUosSUFBQSxxQkFBQSxHQUFBLFNBQUE7QUFBTyxJQUFBLDJCQUFBO0FBQzVKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQUQ4RCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGFBQUEsUUFBQSxtQkFBQSw0QkFBQSxFQUErQixXQUFBLDhCQUFBLEdBQUEsS0FBQSxPQUFBLFFBQUEsZUFBQSxDQUFBOzs7OztBQUY3RixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBLEdBQUEsQ0FBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwrREFBQSxHQUFBLENBQUE7Ozs7QUFBQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxxQkFBQSxJQUFBLEVBQUE7Ozs7OztBQVlZLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBOEMsSUFBQSx5QkFBQSxTQUFBLFNBQUEsZ0ZBQUE7QUFBQSxZQUFBLGNBQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsY0FBQSxZQUFBO0FBQUEsYUFBUywwQkFBQSxZQUFBLFFBQUEsQ0FBaUI7SUFBQSxDQUFBOztBQUNwRSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQUg4RSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGNBQUEsMEJBQUEsR0FBQSxHQUFBLFlBQUEsdUJBQUEsQ0FBQTtBQUM3RCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsWUFBQSxVQUFBOzs7Ozs7QUFXRCxJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQThCLElBQUEseUJBQUEsU0FBQSxTQUFBLGdHQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGNBQUEsWUFBQTtBQUFBLGFBQVMsMEJBQUEsWUFBQSxRQUFBLENBQWlCO0lBQUEsQ0FBQTtBQUNwRCxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3Q0FBQTs7OztBQUZRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsa0RBQUEsMEJBQUEsR0FBQSxHQUFBLFlBQUEsdUJBQUEsR0FBQSw0Q0FBQTs7Ozs7QUFQaEIsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEsdUVBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQUtKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRCQUFBOzs7O0FBVlksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQ0FBQSwwQkFBQSxHQUFBLEdBQUEsZ0RBQUEsR0FBQSxvQ0FBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxjQUFBOzs7OztBQVNSLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSwwQkFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7OztBQUQ0QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsV0FBQSxFQUFtQix1QkFBQSxRQUFBLG1CQUFBOzs7OztBQWUvQixJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTJGLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFrQixJQUFBLDJCQUFBO0FBQ2pILElBQUEscUJBQUEsR0FBQSx3Q0FBQTs7O0FBRHVCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxJQUFBOzs7Ozs7QUFJZixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQXNCLElBQUEseUJBQUEsU0FBQSxTQUFBLHNHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxXQUFBLDRCQUFBLEVBQUE7QUFBQSxZQUFBLGNBQUEsNEJBQUEsRUFBQTtBQUFBLGFBQVMsMEJBQUEsWUFBQSxRQUFBLFNBQUEsSUFBQSxTQUFBLElBQUEsQ0FBbUM7SUFBQSxDQUFBO0FBQWdCLElBQUEscUJBQUEsQ0FBQTtBQUFnQixJQUFBLDJCQUFBO0FBQ3RHLElBQUEscUJBQUEsR0FBQSw0Q0FBQTs7OztBQURzRixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFNBQUEsS0FBQTs7Ozs7QUFEdEYsSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDZFQUFBLEdBQUEsQ0FBQTs7OztBQUFBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxTQUFBLFNBQUEsWUFBQSxJQUFBLEVBQUE7Ozs7O0FBT0EsSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUEyRixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBa0IsSUFBQSwyQkFBQTtBQUNqSCxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7OztBQUR1QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsSUFBQTs7Ozs7QUFJZixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0Q0FBQTs7Ozs7QUFIMEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxxQkFBQSxJQUFBO0FBQ2xCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsc0RBQUEsWUFBQSxPQUFBLGdEQUFBOzs7Ozs7QUFLQSxJQUFBLHFCQUFBLEdBQUEsb0RBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQXNCLElBQUEseUJBQUEsU0FBQSxTQUFBLHNHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLEVBQUE7QUFBQSxZQUFBLGNBQUEsNEJBQUEsRUFBQTtBQUFBLGFBQVMsMEJBQUEsWUFBQSxRQUFBLFlBQUEsSUFBQSxZQUFBLElBQUEsQ0FBeUM7SUFBQSxDQUFBO0FBQ3BFLElBQUEscUJBQUEsQ0FBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7Ozs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDBEQUFBLFlBQUEsT0FBQSxvREFBQTs7Ozs7QUFLQSxJQUFBLHFCQUFBLEdBQUEsd0RBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDREQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBZ0IsSUFBQSwyQkFBQTtBQUMxQixJQUFBLHFCQUFBLEdBQUEsd0RBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9EQUFBOzs7OztBQUgwQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLHFCQUFBLElBQUE7QUFDWixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFNBQUEsS0FBQTs7Ozs7QUFhTixJQUFBLHFCQUFBLEdBQUEsNERBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTJGLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFrQixJQUFBLDJCQUFBO0FBQ2pILElBQUEscUJBQUEsR0FBQSx3REFBQTs7O0FBRHVCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxJQUFBOzs7Ozs7QUFHbkIsSUFBQSxxQkFBQSxHQUFBLDREQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFzQixJQUFBLHlCQUFBLFNBQUEsU0FBQSxxR0FBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxLQUFBO0FBQUEsWUFBQSxZQUFBLFlBQUE7QUFBQSxZQUFBLFdBQUEsNEJBQUEsRUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxFQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLEVBQUE7QUFBQSxhQUFTLDBCQUFBLFlBQUEsUUFBQSxZQUFBLElBQUEsWUFBQSxNQUEwQyxRQUFTLFNBQUEsSUFBQSxVQUFBLEVBQUEsQ0FBb0I7SUFBQSxDQUFBO0FBQ2xHLElBQUEscUJBQUEsR0FBQSxnRUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBO0FBQTZCLElBQUEsMkJBQUE7QUFDdkMsSUFBQSxxQkFBQSxHQUFBLDREQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3REFBQTs7OztBQUZjLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsVUFBQSxVQUFBLGFBQUEsRUFBQTs7Ozs7O0FBbkJsQixJQUFBLHFCQUFBLEdBQUEsb0RBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsbUZBQUEsR0FBQSxDQUFBO0FBS0EsSUFBQSw2QkFBQSxHQUFBLFlBQUEsSUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdEQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUVJLElBQUEseUJBQUEsU0FBQSxTQUFBLDhGQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLEtBQUE7QUFBQSxZQUFBLFdBQUEsWUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxFQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLEVBQUE7QUFBQSxhQUFTLDBCQUFBLFlBQUEsUUFBQSxZQUFBLElBQUEsWUFBQSxNQUEwQyxRQUFTLFNBQUEsRUFBQSxDQUFVO0lBQUEsQ0FBQTtBQUl0RSxJQUFBLHFCQUFBLENBQUE7QUFDSixJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLHdEQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLG1GQUFBLEdBQUEsQ0FBQTtBQUdBLElBQUEsK0JBQUEsR0FBQSw0RUFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBO0FBS0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnREFBQTs7OztBQXZCSSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsU0FBQSx1QkFBQSxxQkFBQSxJQUFBLEVBQUE7QUFZUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDhEQUFBLFNBQUEsT0FBQSx3REFBQTtBQUVKLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxDQUFBLFNBQUEsVUFBQSxTQUFBLE9BQUEsV0FBQSxJQUFBLElBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsU0FBQSxNQUFBOzs7Ozs7QUFRSixJQUFBLHFCQUFBLEdBQUEsb0RBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQW9DLElBQUEseUJBQUEsU0FBQSxTQUFBLDhGQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLEtBQUE7QUFBQSxZQUFBLGtCQUFBLFlBQUE7QUFBQSxZQUFBLGNBQUEsNEJBQUEsRUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxFQUFBO0FBQUEsYUFBUywwQkFBQSxZQUFBLFFBQUEsWUFBQSxJQUFBLGdCQUFBLE1BQUEsZ0JBQUEsRUFBQSxDQUEyRDtJQUFBLENBQUE7QUFDcEcsSUFBQSxxQkFBQSxHQUFBLHdEQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBc0IsSUFBQSwyQkFBQTtBQUNoQyxJQUFBLHFCQUFBLEdBQUEsb0RBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdEQUFBOzs7O0FBRmMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxnQkFBQSxLQUFBOzs7OztBQXRDbEIsSUFBQSxxQkFBQSxHQUFBLDRDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDZFQUFBLEdBQUEsQ0FBQTtBQUtBLElBQUEsNkJBQUEsR0FBQSxZQUFBLElBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnREFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSw2RUFBQSxHQUFBLENBQUE7QUFLQSxJQUFBLCtCQUFBLEdBQUEscUVBQUEsSUFBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQXlCQSxJQUFBLCtCQUFBLEdBQUEscUVBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQUtKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0NBQUE7Ozs7QUExQ0ksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFlBQUEsU0FBQSxZQUFBLElBQUEsRUFBQTtBQU1JLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxZQUFBLFNBQUEsWUFBQSxJQUFBLEVBQUE7QUFLQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsZUFBQTtBQXlCQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsUUFBQTs7Ozs7QUE3RGhCLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQU1JLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBZ0MsSUFBQSxxQkFBQSxDQUFBOztBQUF3RCxJQUFBLDJCQUFBO0FBQ3hGLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFlBQUEsSUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLHVFQUFBLEdBQUEsQ0FBQTtBQUdBLElBQUEsK0JBQUEsSUFBQSwrREFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBO0FBS0osSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxZQUFBLElBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3Q0FBQTtBQUFBLElBQUEseUJBQUEsSUFBQSx1RUFBQSxHQUFBLENBQUE7QUFHQSxJQUFBLCtCQUFBLElBQUEsK0RBQUEsSUFBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQTRDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTs7Ozs7OztBQW5FWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLHFCQUFBLFFBQUEsaUNBQUEsV0FBQSxJQUFBLE9BQUEsSUFBQTtBQUlnQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsR0FBQSxZQUFBLHVCQUFBLENBQUE7QUFDdkIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsV0FBQTtBQUdULElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxDQUFBLFlBQUEsVUFBQSxLQUFBLFlBQUEsVUFBQSxFQUFBLFdBQUEsSUFBQSxLQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsVUFBQSxDQUFBO0FBT0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLENBQUEsWUFBQSxVQUFBLEtBQUEsWUFBQSxVQUFBLEVBQUEsV0FBQSxJQUFBLEtBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxVQUFBLENBQUE7Ozs7OztBQWlEUixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUFnRCxJQUFBLHlCQUFBLFNBQUEsU0FBQSxvRkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxLQUFBO0FBQUEsWUFBQSxXQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFNBQUEsa0JBQUEsTUFBQSxDQUF5QjtJQUFBLENBQUE7QUFBRSxJQUFBLHFCQUFBLENBQUE7O0FBQTBELElBQUEsMkJBQUE7QUFDOUksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLHNCQUFBLEVBQUE7QUFBaUQsSUFBQSx5QkFBQSxpQkFBQSxTQUFBLDJHQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLEtBQUE7QUFBQSxZQUFBLFdBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQWlCLDBCQUFBLFNBQUEsZ0JBQUEsTUFBQSxDQUF1QjtJQUFBLENBQUE7QUFBRSxJQUFBLDJCQUFBO0FBQy9GLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7QUFINEYsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsaUNBQUEsQ0FBQTtBQUNoRSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGFBQUEsUUFBQSxjQUFBOzs7Ozs7QUFRWixJQUFBLHFCQUFBLEdBQUEsNENBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQWtDLElBQUEseUJBQUEsU0FBQSxTQUFBLDBHQUFBO0FBQUEsTUFBQSw0QkFBQSxLQUFBO0FBQUEsWUFBQSxlQUFBLDRCQUFBLEVBQUE7QUFBQSxhQUFTLDBCQUFBLGFBQUEsUUFBQSxDQUFpQjtJQUFBLENBQUE7QUFDeEQsSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0NBQUE7Ozs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtEQUFBLDBCQUFBLEdBQUEsR0FBQSxhQUFBLHVCQUFBLEdBQUEsNENBQUE7Ozs7O0FBRlIsSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLG9GQUFBLEdBQUEsQ0FBQTs7OztBQUFBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxhQUFBLHVCQUFBLElBQUEsRUFBQTs7Ozs7O0FBYVksSUFBQSxxQkFBQSxHQUFBLG9EQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFxQyxJQUFBLHlCQUFBLFNBQUEsU0FBQSxzR0FBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxLQUFBO0FBQUEsWUFBQSxZQUFBLFlBQUE7QUFBQSxZQUFBLGVBQUEsNEJBQUEsRUFBQTtBQUFBLGFBQVMsMEJBQUEsYUFBQSxRQUFBLFVBQUEsRUFBQSxDQUF3QjtJQUFBLENBQUE7QUFDbEUsSUFBQSxxQkFBQSxDQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnREFBQTs7OztBQUZRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMERBQUEsVUFBQSxPQUFBLG9EQUFBOzs7OztBQUlKLElBQUEscUJBQUEsR0FBQSxvREFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBa0YsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQWtCLElBQUEsMkJBQUE7QUFDeEcsSUFBQSxxQkFBQSxHQUFBLGdEQUFBOzs7QUFEWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsSUFBQTs7Ozs7QUFYcEIsSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEsNkVBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQUtBLElBQUEseUJBQUEsSUFBQSxxRkFBQSxHQUFBLENBQUE7QUFHSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQ0FBQTs7OztBQWJZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsa0RBQUEsMEJBQUEsR0FBQSxHQUFBLGFBQUEsdUJBQUEsR0FBQSw0Q0FBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxVQUFBLENBQUE7QUFLQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsQ0FBQSxhQUFBLFVBQUEsRUFBQSxTQUFBLEtBQUEsRUFBQTs7Ozs7QUFuQmhCLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEsc0VBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTs7QUFPQSxJQUFBLCtCQUFBLEdBQUEsc0VBQUEsSUFBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTs7QUFpQkosSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQXpCUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLDBCQUFBLEdBQUEsR0FBQSxRQUFBLGdCQUFBLFFBQUEsZ0JBQUEsQ0FBQTtBQU9BLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsMEJBQUEsR0FBQSxHQUFBLFFBQUEsZ0JBQUEsUUFBQSx3QkFBQSxDQUFBOzs7Ozs7QUFxQkEsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFtRCxJQUFBLHlCQUFBLFNBQUEsU0FBQSxpRkFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxLQUFBO0FBQUEsWUFBQSxlQUFBLFlBQUE7QUFBQSxhQUFTLDBCQUFBLGFBQUEsUUFBQSxDQUFpQjtJQUFBLENBQUE7O0FBQ3pFLElBQUEscUJBQUEsR0FBQSx3Q0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7O0FBSG1GLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSwwQkFBQSxHQUFBLEdBQUEsYUFBQSx1QkFBQSxDQUFBO0FBQ2xFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxhQUFBLFVBQUE7Ozs7O0FBMUlqQyxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHNDQUFBLEdBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwrQkFBQSxHQUFBLHVEQUFBLEdBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7O0FBTUEsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLGdFQUFBLElBQUEsQ0FBQTtBQWNBLElBQUEsK0JBQUEsSUFBQSx3REFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBOztBQUdBLElBQUEsK0JBQUEsSUFBQSx3REFBQSxJQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBOzs7QUF5RUEsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLGdFQUFBLElBQUEsQ0FBQTtBQU9BLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxnRUFBQSxJQUFBLENBQUE7QUE0QkEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsK0JBQUEsSUFBQSx3REFBQSxHQUFBLEdBQUEsTUFBQSxNQUFBLHVDQUFBO0FBS0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSxvQ0FBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBOzs7O0FBN0lnQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLDBCQUFBLElBQUEsR0FBQSxPQUFBLGlCQUFBLE9BQUEsa0JBQUEsQ0FBQTtBQU1BLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLGVBQUEsU0FBQSxJQUFBLEtBQUEsRUFBQTtBQWNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsMEJBQUEsSUFBQSxHQUFBLE9BQUEsaUJBQUEsT0FBQSx3QkFBQSxDQUFBO0FBR0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSwwQkFBQSxJQUFBLEdBQUEsMEJBQUEsSUFBQSxJQUFBLE9BQUEsaUJBQUEsT0FBQSxrQkFBQSxHQUFBLE9BQUEsd0JBQUEsQ0FBQTtBQXlFQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxjQUFBLFNBQUEsSUFBQSxLQUFBLEVBQUE7QUFPQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxrQkFBQSxPQUFBLGVBQUEsVUFBQSxJQUFBLEtBQUEsRUFBQTtBQTZCSSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsWUFBQTs7O0FEek01QiwrQkF5Q1ksc0JBUUEsWUFLTixZQWlCTztBQXZFYjs7QUFHQTtBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFQSxLQUFBLFNBQVlDLHVCQUFvQjtBQUM1QixNQUFBQSxzQkFBQUEsc0JBQUEsUUFBQSxJQUFBLEdBQUEsSUFBQTtBQUNBLE1BQUFBLHNCQUFBQSxzQkFBQSxPQUFBLElBQUEsR0FBQSxJQUFBO0FBQ0EsTUFBQUEsc0JBQUFBLHNCQUFBLFFBQUEsSUFBQSxHQUFBLElBQUE7QUFDQSxNQUFBQSxzQkFBQUEsc0JBQUEsT0FBQSxJQUFBLEdBQUEsSUFBQTtBQUNBLE1BQUFBLHNCQUFBQSxzQkFBQSxhQUFBLElBQUEsSUFBQSxJQUFBO0lBQ0osR0FOWSx5QkFBQSx1QkFBb0IsQ0FBQSxFQUFBO0FBUWhDLEtBQUEsU0FBWUMsYUFBVTtBQUNsQixNQUFBQSxZQUFBLE1BQUEsSUFBQTtBQUNBLE1BQUFBLFlBQUEsT0FBQSxJQUFBO0lBQ0osR0FIWSxlQUFBLGFBQVUsQ0FBQSxFQUFBO0FBS3RCLElBQU0sYUFBYSxDQUFDLFNBQW9CO0FBQ3BDLGNBQVEsTUFBTTtRQUNWLEtBQUssV0FBVztBQUNaLGlCQUFPO1FBQ1gsS0FBSyxXQUFXO0FBQ1osaUJBQU87UUFDWDtBQUNJLGlCQUFPOztJQUVuQjtBQVFNLElBQU8sMEJBQVAsTUFBTyx5QkFBdUI7TUFxSHBCO01BQ0E7TUFDQTtNQXRITCxxQkFBcUI7TUFDckIsMkJBQTJCO01BQzNCLG1CQUFtQjtNQUNuQiwyQkFBMkI7TUFFeUI7TUFFM0Q7TUFDQSxtQkFBbUI7UUFDZixtQkFBbUI7UUFDbkIsTUFBTTs7TUFFNEM7TUFHN0M7TUFDQSxhQUFhLFdBQVc7TUFDeEIsa0JBQWtCO01BQ2pCLGlCQUFpQixJQUFJUCxjQUFZO01BQ2pDLE9BQU8sSUFBSUEsY0FBWTtNQUdqQyxpQkFBaUIsQ0FBQyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFNBQVM7TUFDeEcsZ0JBQWdCO01BSVAsZ0JBQTJCLENBQUMsSUFBSSxtQkFBa0IsQ0FBRTtNQU1wRCxlQUEwQixDQUFDLElBQUksa0JBQWlCLENBQUU7TUFHbEQsa0JBQTZCO1FBQ2xDLElBQUksWUFBVztRQUNmLElBQUksY0FBYTtRQUNqQixJQUFJLGlCQUFnQjtRQUNwQixJQUFJLGlCQUFnQjtRQUNwQixJQUFJLFlBQVc7UUFDZixJQUFJLGlCQUFnQjtRQUNwQixJQUFJLFlBQVc7UUFDZixJQUFJLGtCQUFpQjtRQUNyQixJQUFJLG1CQUFrQjtRQUN0QixJQUFJLHFCQUFvQjs7TUFJbkIsaUJBQTRCLENBQUMsSUFBSSxrQkFBaUIsR0FBSSxJQUFJLGtCQUFpQixHQUFJLElBQUksb0JBQW1CLENBQUU7TUFHeEc7TUFHQyw4QkFBOEIsSUFBSUEsY0FBWTtNQUU5QyxrQkFBa0IsSUFBSUEsY0FBWTtNQUNsQyxlQUFlLElBQUlBLGNBQVk7TUFLaEMsb0JBQW9CO01BTXBCLHFCQUFxQjtNQUVyQixpQkFBaUI7TUFFakIsdUJBQXVCO01BR2hDO01BR0EsY0FBYztNQUdkLGFBQWE7TUFFYixrQkFBa0IscUJBQXFCLE1BQU0sUUFBTztNQUVvQjtNQUl4RSxlQUFlO01BRWYscUJBQXFCLHFCQUFxQjtNQUUxQyxxQkFBcUIscUJBQXFCO01BQzFDO01BT0EsbUJBQW1CO01BR25CLG1CQUFtQks7TUFDbkIsY0FBYztNQUNkLGVBQWU7TUFDZixjQUFjO01BRWQ7TUFFQTtNQUVBLFlBQ1ksaUJBQ0EscUJBQ0EsY0FBMEI7QUFGMUIsYUFBQSxrQkFBQTtBQUNBLGFBQUEsc0JBQUE7QUFDQSxhQUFBLGVBQUE7QUFFUixhQUFLLHlCQUF5QixxQkFBcUIsS0FBSTtNQUMzRDtNQUdBLGtCQUFrQixPQUFpQjtBQUMvQixjQUFNLFlBQVk7QUFDbEIsY0FBTSxTQUFTO0FBQ2YsYUFBSyxjQUFjLGtCQUFrQixPQUFPLFdBQVcsTUFBTTtNQUNqRTtNQUdBLGdCQUFnQixlQUFxQjtBQUNqQyxhQUFLLGdCQUFnQjtBQUNyQixhQUFLLGNBQWMsQ0FBQyxFQUFFLFFBQVEsYUFBYTtNQUMvQztNQU9BLFdBQVcsU0FBZ0I7QUFDdkIsYUFBSyxnQkFBZ0IsS0FBSyxPQUFPO01BQ3JDO01BT0EsY0FBYyxVQUF3QjtBQUNsQyxtQkFBVyxNQUFPLEtBQUssa0JBQWtCLEtBQUssZ0JBQWdCLE9BQU8sQ0FBQyxZQUFZLEVBQUUsbUJBQW1CLFNBQVMsQ0FBRTtNQUN0SDtNQUVBLGlDQUFpQyxnQkFBa0M7QUFDL0QsZUFBTywwQkFBMEI7TUFDckM7TUFFQSxrQkFBZTtBQUVYLGFBQUssbUJBQW1CLFVBQVMsRUFBRyxXQUFXO1VBQzNDLDJCQUEyQjtVQUMzQiwwQkFBMEI7U0FDN0I7QUFDRCxhQUFLLG1CQUFtQixVQUFTLEVBQUcsYUFBYSxDQUFBO0FBRWpELFlBQUksS0FBSyxrQkFBa0IsVUFBYSxLQUFLLGVBQWUsV0FBVyxHQUFHO0FBQ3RFLFdBQUMsR0FBRyxLQUFLLGlCQUFpQixHQUFHLEtBQUssZUFBZSxHQUFJLEtBQUssa0JBQWtCLENBQUEsR0FBSyxHQUFHLEtBQUssWUFBWSxFQUFFLFFBQVEsQ0FBQyxZQUFXO0FBQ3ZILG9CQUFRLFVBQVUsS0FBSyxtQkFBbUIsVUFBUyxDQUFFO0FBQ3JELG9CQUFRLG1CQUFtQixLQUFLLE9BQU87VUFDM0MsQ0FBQztlQUNFO0FBQ0gsV0FBQyxHQUFHLEtBQUssaUJBQWlCLEdBQUcsS0FBSyxnQkFBZ0IsR0FBRyxLQUFLLGVBQWUsR0FBSSxLQUFLLGtCQUFrQixDQUFBLEdBQUssR0FBRyxLQUFLLFlBQVksRUFBRSxRQUFRLENBQUMsWUFBVztBQUMvSSxvQkFBUSxVQUFVLEtBQUssbUJBQW1CLFVBQVMsQ0FBRTtBQUNyRCxvQkFBUSxtQkFBbUIsS0FBSyxPQUFPO1VBQzNDLENBQUM7O0FBRUwsYUFBSyxvQkFBbUI7QUFDeEIsY0FBTSxrQkFBa0IsV0FBVyxLQUFLLFVBQVU7QUFDbEQsWUFBSSxpQkFBaUI7QUFDakIsZUFBSyxtQkFBbUIsVUFBUyxFQUFHLFdBQVUsRUFBRyxRQUFRLGVBQWU7O0FBRzVFLFlBQUksS0FBSyxjQUFjO0FBQ25CLGVBQUssZUFBYzs7TUFFM0I7TUFNQSxzQkFBbUI7QUFDZixhQUFLLG1CQUFtQixVQUFTLEVBQUcsU0FBUyxjQUFjLEtBQUssZUFBZTtBQUMvRSxhQUFLLG1CQUFtQixVQUFTLEVBQUcsU0FBUyxXQUFXLEVBQUU7QUFDMUQsYUFBSyxtQkFBbUIsVUFBUyxFQUFHLFNBQVMsZ0JBQWdCLEdBQUcsQ0FBQztBQUNqRSxhQUFLLG1CQUFtQixVQUFTLEVBQUcsdUJBQXVCLEtBQUs7QUFDaEUsYUFBSyxtQkFBbUIsVUFBUyxFQUFHLG1CQUFtQixLQUFLO0FBQzVELGFBQUssbUJBQW1CLFVBQVMsRUFBRyxlQUFjO0FBQ2xELGFBQUssbUJBQW1CLFVBQVMsRUFBRyw0QkFBNEIsSUFBSTtBQUNwRSxhQUFLLG1CQUFtQixVQUFTLEVBQUcsV0FBVyxFQUFFLE1BQU0sS0FBSSxDQUFFO01BQ2pFO01BTUEsaUJBQWM7QUFHVixjQUFNLFdBQVcsTUFBTSxLQUFLO0FBRzVCLGlCQUFTLFFBQVEsRUFBRSxNQUFLO0FBRXhCLGFBQUssb0JBQW9CLFNBQVMsUUFBUSxFQUNyQyxVQUFVO1VBRVAsT0FBTyxFQUFFLE1BQU0sT0FBTyxPQUFPLE9BQU8sUUFBUSxjQUFjLEtBQUssTUFBSztVQUVwRSxXQUFXO1lBQ1AsU0FBUyxVQUFXLGFBQWE7Y0FDN0IsS0FBSyxFQUFFLE9BQU8sR0FBRyxRQUFRLEtBQUssbUJBQWtCO2NBQ2hELEtBQUssRUFBRSxPQUFPLEtBQU0sUUFBUSxLQUFLLG1CQUFrQjthQUN0RDs7VUFFTCxTQUFTO1NBQ1osRUFDQSxHQUFHLGVBQWUsU0FBVSxPQUFVO0FBQ25DLGdCQUFNLE9BQU8sVUFBVSxJQUFJLGdCQUFnQjtRQUMvQyxDQUFDLEVBQ0EsR0FBRyxhQUFhLENBQUMsVUFBYztBQUM1QixnQkFBTSxPQUFPLFVBQVUsT0FBTyxnQkFBZ0I7UUFDbEQsQ0FBQyxFQUNBLEdBQUcsY0FBYyxDQUFDLFVBQWM7QUFDN0IsZ0JBQU0sU0FBUyxNQUFNO0FBRXJCLGlCQUFPLE1BQU0sU0FBUyxNQUFNLEtBQUssU0FBUztBQUMxQyxlQUFLLG1CQUFtQixVQUFTLEVBQUcsT0FBTTtRQUM5QyxDQUFDO01BQ1Q7TUFPQSxRQUFLO0FBQ0QsWUFBSSxLQUFLLG9CQUFvQjtBQUN6QixlQUFLLG9CQUFvQixLQUFLLGdCQUFnQixvQkFBb0IsS0FBSyxRQUFRO0FBQy9FLGVBQUssS0FBSyxLQUFLLEtBQUssaUJBQWlCOztBQUV6QyxZQUFJLEtBQUssa0JBQWtCLEtBQUssZUFBZSxVQUFVLEtBQUssVUFBVTtBQUVwRSxnQkFBTSxrQ0FBa0MsS0FBSyxlQUFlLElBQUksQ0FBQyxZQUFZLFFBQVEscUJBQW9CLENBQUU7QUFJM0csZ0JBQU0seUNBQTJFLENBQUE7QUFFakYsY0FBSSx3QkFBd0IsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUdqRCxnQkFBTSwyQkFBMkIsZ0NBQzVCLElBQUksQ0FBQyxRQUFRLElBQUksUUFBUSxLQUFLLEVBQUUsRUFBRSxRQUFRLEtBQUssRUFBRSxDQUFDLEVBQ2xELElBQUkseUJBQXlCLEVBQzdCLEtBQUssR0FBRztBQVdiLGdCQUFNLFFBQVEsSUFBSSxPQUFPLFVBQVUsd0JBQXdCLFNBQVMsS0FBSztBQUd6RSxpQkFBTyxzQkFBc0IsUUFBUTtBQUlqQyxrQkFBTSxDQUFDLHlCQUF5QixJQUFJLHNCQUFzQixNQUFNLE9BQU8sQ0FBQztBQUt4RSxvQ0FBd0Isc0JBQXNCLFVBQVUsMEJBQTBCLE1BQU07QUFHeEYsa0JBQU0sbUNBQW1DLEtBQUssMEJBQTBCLDBCQUEwQixLQUFJLENBQUU7QUFFeEcsbURBQXVDLEtBQUssZ0NBQWdDOztBQUdoRixlQUFLLDRCQUE0QixLQUFLLHNDQUFzQzs7TUFFcEY7TUFXUSw0QkFBNEIsQ0FBQyxTQUFnRDtBQUNqRixtQkFBVyxpQkFBaUIsS0FBSyxnQkFBZ0I7QUFDN0MsZ0JBQU0sbUNBQW1DO1lBQ3JDLGNBQWMscUJBQW9CO1lBQ2xDLGNBQWMscUJBQW9CLEVBQUcsWUFBVztZQUNoRCxjQUFjLHFCQUFvQixFQUFHLFlBQVc7O0FBRXBELGNBQUksaUNBQWlDLEtBQUssQ0FBQyxlQUFlLEtBQUssUUFBUSxVQUFVLE1BQU0sRUFBRSxHQUFHO0FBRXhGLGtCQUFNLCtCQUErQixpQ0FBaUMsT0FBTyxDQUFDLE1BQU0sZUFBZSxLQUFLLFFBQVEsWUFBWSxFQUFFLEdBQUcsSUFBSSxFQUFFLEtBQUk7QUFDM0ksbUJBQU8sQ0FBQyw4QkFBOEIsYUFBYTs7O0FBRzNELGVBQU8sQ0FBQyxLQUFLLEtBQUksR0FBSSxJQUFJO01BQzdCO01BTUEsaUJBQWlCLE9BQVU7QUFDdkIsYUFBSyxjQUFjLE1BQU0sV0FBVztBQUNwQyxhQUFLLGFBQWEsTUFBTSxXQUFXO0FBRW5DLFlBQUksS0FBSyxhQUFhO0FBQ2xCLGVBQUssZ0JBQWdCLEtBQUk7ZUFDdEI7QUFDSCxlQUFLLGFBQWEsS0FBSTs7QUFHMUIsWUFBSSxNQUFNLGFBQWEsbUJBQW1CLEtBQUssYUFBYTtBQUN4RCxlQUFLLFdBQVcsS0FBSyxZQUFZLGNBQWE7QUFFOUMsY0FBSSxLQUFLLGFBQWE7QUFDbEIsaUJBQUssTUFBSzs7O0FBS2xCLFlBQUksTUFBTSxhQUFhLGVBQWU7QUFDbEMsZUFBSyxNQUFLOztNQUVsQjtNQU9BLGFBQWEsT0FBVTtBQUNuQixZQUFJLE1BQU0sT0FBTyxNQUFNLFVBQVUsR0FBRztBQUNoQyxlQUFLLFdBQVcsTUFBTSxLQUFLLE1BQU0sT0FBTyxLQUFLLENBQUM7O01BRXREO01BT0EsV0FBVyxPQUFnQjtBQUN2QixjQUFNLGVBQWM7QUFDcEIsWUFBSSxNQUFNLGNBQWMsT0FBTztBQUUzQixnQkFBTSxRQUFRLElBQUksTUFBSztBQUN2QixtQkFBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLGFBQWEsTUFBTSxRQUFRLEtBQUs7QUFFdEQsZ0JBQUksTUFBTSxhQUFhLE1BQU0sQ0FBQyxFQUFFLFNBQVMsUUFBUTtBQUM3QyxvQkFBTSxPQUFPLE1BQU0sYUFBYSxNQUFNLENBQUMsRUFBRSxVQUFTO0FBQ2xELGtCQUFJLE1BQU07QUFDTixzQkFBTSxLQUFLLElBQUk7Ozs7QUFJM0IsZUFBSyxXQUFXLEtBQUs7bUJBQ2QsTUFBTSxjQUFjLE9BQU87QUFFbEMsZUFBSyxXQUFXLE1BQU0sS0FBSyxNQUFNLGFBQWEsS0FBSyxDQUFDOztNQUU1RDtNQU9BLFlBQVksT0FBcUI7QUFDN0IsWUFBSSxNQUFNLGVBQWUsT0FBTztBQUM1QixnQkFBTSxTQUFTLElBQUksTUFBSztBQUN4QixtQkFBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLGNBQWMsTUFBTSxRQUFRLEtBQUs7QUFDdkQsZ0JBQUksTUFBTSxjQUFjLE1BQU0sQ0FBQyxFQUFFLFNBQVMsUUFBUTtBQUM5QyxvQkFBTSxPQUFPLE1BQU0sY0FBYyxNQUFNLENBQUMsRUFBRSxVQUFTO0FBQ25ELGtCQUFJLE1BQU07QUFDTix1QkFBTyxLQUFLLElBQUk7Ozs7QUFJNUIsZUFBSyxXQUFXLE1BQU07O01BRTlCO01BT0EsV0FBVyxPQUFhO0FBQ3BCLGNBQU0sWUFBWSxLQUFLLG1CQUFtQixVQUFTO0FBQ25ELGNBQU0sUUFBUSxDQUFDLFNBQWM7QUFDekIsZUFBSyxvQkFBb0IsbUJBQW1CLElBQUksRUFBRSxLQUM5QyxDQUFDLFFBQU87QUFDSixrQkFBTSxZQUFZLEtBQUssS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFHLEVBQUksa0JBQWlCO0FBRS9ELGdCQUFJLFlBQVksSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLElBQUk7O0FBQzFDLGdCQUFJLGNBQWMsT0FBTztBQUVyQiwwQkFBWSxNQUFNOztBQUd0QixzQkFBVSxPQUFPLFNBQVM7VUFDOUIsR0FDQSxDQUFDLFVBQWdCO0FBQ2IsaUJBQUssYUFBYSxTQUFTO2NBQ3ZCLE1BQU0sVUFBVTtjQUNoQixTQUFTLE1BQU07Y0FDZixvQkFBb0I7YUFDdkI7VUFDTCxDQUFDO1FBRVQsQ0FBQztNQUNMO01BRUEsbUJBQW1CLE9BQVU7QUFDekIsYUFBSyxXQUFXO0FBQ2hCLGFBQUssZUFBZSxLQUFLLEtBQWU7TUFDNUM7O3lCQTliUywwQkFBdUIsZ0NBQUEsc0JBQUEsR0FBQSxnQ0FBQSxtQkFBQSxHQUFBLGdDQUFBLFlBQUEsQ0FBQTtNQUFBO2lFQUF2QiwwQkFBdUIsV0FBQSxDQUFBLENBQUEscUJBQUEsQ0FBQSxHQUFBLGdCQUFBLFNBQUEsdUNBQUEsSUFBQSxLQUFBLFVBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtpREF3RmxCLHVDQUFxQyxDQUFBOzs7Ozs7Ozs2Q0FsRnJCTixXQUFVOztvQ0FPN0Isd0JBQXNCLENBQUE7Ozs7Ozs7Ozs7O0FDcEZyQyxVQUFBLDZCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQTtBQUFtRSxVQUFBLHlCQUFBLGFBQUEsU0FBQSwwREFBQSxRQUFBO0FBQUEsbUJBQWEsSUFBQSxpQkFBQSxNQUFBO1VBQXdCLENBQUE7QUFDcEcsVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsc0NBQUEsR0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLGdEQUFBLEdBQUEsQ0FBQSxFQUVDLElBQUEsaURBQUEsSUFBQSxJQUFBLGVBQUEsQ0FBQTtBQW1DTCxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsb0NBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSxzQ0FBQSxJQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsaURBQUEsR0FBQSxDQUFBLEVBRUMsSUFBQSxpREFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBO0FBSUwsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLG9DQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsc0NBQUEsSUFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLGlEQUFBLEdBQUEsQ0FBQSxFQUVDLElBQUEsaURBQUEsR0FBQSxHQUFBLGVBQUEsQ0FBQTtBQU9MLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSxvQ0FBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsaURBQUEsSUFBQSxFQUFBO0FBbUpKLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxPQUFBLENBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTs7OztBQXJOK0MsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxpQkFBQSxLQUFBO0FBR25DLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLGlCQUFBLElBQUEsRUFBQTtBQXdDQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSx1QkFBQSxLQUFBLEVBQUE7QUFTQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxvQkFBQSxLQUFBLEVBQUE7QUFXSixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLGVBQUEsQ0FBQSxJQUFBLGFBQUEsS0FBQSxFQUFBO0FBb0pDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsZ0JBQUEsR0FBQTs7Ozs7cUZEN0lJLHlCQUF1QixFQUFBLFdBQUEsMEJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFdkVwQyxTQUFTLFlBQUFTLGlCQUFnQjs7QUFBekIsSUFPYTtBQVBiOztBQUNBO0FBTU0sSUFBTyxrQkFBUCxNQUFPLGlCQUFlOzt5QkFBZixrQkFBZTtNQUFBO2dFQUFmLGlCQUFlLENBQUE7Ozs7Ozs7QUNONUIsU0FBUyxZQUFBQyxpQkFBZ0I7QUFFekIsU0FBUyxtQkFBbUI7QUFHNUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyx1QkFBdUI7O0FBUGhDLElBZWE7QUFmYjs7O0FBRUE7QUFFQTtBQUNBO0FBR0E7QUFPTSxJQUFPLDhCQUFQLE1BQU8sNkJBQTJCOzt5QkFBM0IsOEJBQTJCO01BQUE7Z0VBQTNCLDZCQUEyQixDQUFBO29FQUoxQixxQkFBcUIsaUJBQWlCLGFBQWEsNEJBQTRCLGVBQWUsZUFBZSxFQUFBLENBQUE7Ozs7IiwibmFtZXMiOlsiQ29tcG9uZW50IiwiRWxlbWVudFJlZiIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwiZmFIZWFkaW5nIiwiZmFIZWFkaW5nIiwiQ29tcG9uZW50IiwiRXZlbnRFbWl0dGVyIiwiSW5wdXQiLCJPdXRwdXQiLCJDb21wb25lbnQiLCJFbGVtZW50UmVmIiwiSW5wdXQiLCJDb21wb25lbnQiLCJFbGVtZW50UmVmIiwiRXZlbnRFbWl0dGVyIiwiSW5wdXQiLCJPdXRwdXQiLCJWaWV3Q2hpbGQiLCJWaWV3RW5jYXBzdWxhdGlvbiIsImZhUXVlc3Rpb25DaXJjbGUiLCJNYXJrZG93bkVkaXRvckhlaWdodCIsIkVkaXRvck1vZGUiLCJOZ01vZHVsZSIsIk5nTW9kdWxlIl19