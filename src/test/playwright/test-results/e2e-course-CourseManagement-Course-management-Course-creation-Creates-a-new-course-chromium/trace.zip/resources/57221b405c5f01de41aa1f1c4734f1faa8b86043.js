import {
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/service/sort.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var SortService;
var init_sort_service = __esm({
  "src/main/webapp/app/shared/service/sort.service.ts"() {
    SortService = class _SortService {
      constructor() {
      }
      sortByProperty(array, key, ascending) {
        return this.sortByFunction(array, (element) => _SortService.customGet(element, key, void 0), ascending);
      }
      sortByMultipleProperties(array, keys, ascending) {
        return array.sort((a, b) => {
          let compareValue = 0;
          for (const key of keys) {
            if (compareValue === 0) {
              const keyValueA = _SortService.customGet(a, key, void 0);
              const keyValueB = _SortService.customGet(b, key, void 0);
              compareValue = this.compareValues(keyValueA, keyValueB, ascending);
            }
          }
          return compareValue;
        });
      }
      sortByFunction(array, func, ascending) {
        return array.sort((a, b) => {
          const valueA = func(a);
          const valueB = func(b);
          return this.compareValues(valueA, valueB, ascending);
        });
      }
      compareValues(valueA, valueB, ascending) {
        let compareValue;
        if (valueA == void 0 || valueB == void 0) {
          compareValue = _SortService.compareWithUndefinedNull(valueA, valueB);
        } else if (dayjs.isDayjs(valueA) && dayjs.isDayjs(valueB)) {
          compareValue = _SortService.compareDayjs(valueA, valueB);
        } else {
          compareValue = _SortService.compareBasic(valueA, valueB);
        }
        if (!ascending) {
          compareValue = -compareValue;
        }
        return compareValue;
      }
      static compareWithUndefinedNull(valueA, valueB) {
        if ((valueA === null || valueA === void 0) && (valueB === null || valueB === void 0)) {
          return 0;
        } else if (valueA === null || valueA === void 0) {
          return 1;
        } else {
          return -1;
        }
      }
      static compareDayjs(valueA, valueB) {
        if (valueA.isSame(valueB)) {
          return 0;
        } else {
          return valueA.isBefore(valueB) ? -1 : 1;
        }
      }
      static compareBasic(valueA, valueB) {
        if (typeof valueA === "string" && typeof valueB === "string") {
          return valueA.localeCompare(valueB);
        } else if (valueA === valueB) {
          return 0;
        } else {
          return valueA < valueB ? -1 : 1;
        }
      }
      static customGet(object, path, defaultValue) {
        path = path.replaceAll("?", "").replaceAll("]", "");
        const pathArray = path.split(/\.|\[/).filter((key) => key);
        const value = pathArray.reduce((obj, key) => {
          if (!obj) {
            return obj;
          } else {
            if (obj instanceof Map) {
              return obj.get(key);
            } else {
              return obj[key];
            }
          }
        }, object);
        if (value === void 0) {
          return defaultValue;
        } else {
          return value;
        }
      }
      static \u0275fac = function SortService_Factory(t) {
        return new (t || _SortService)();
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _SortService, factory: _SortService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/shared/side-panel/side-panel.component.ts
import { Component, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function SidePanelComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n        ");
    i02.\u0275\u0275elementStart(1, "div", 3);
    i02.\u0275\u0275text(2, "\n            ");
    i02.\u0275\u0275elementStart(3, "div", 4);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n            ");
    i02.\u0275\u0275elementStart(6, "div", 5);
    i02.\u0275\u0275text(7);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate1("\n                ", ctx_r0.panelHeader, "\n            ");
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate1("\n                ", ctx_r0.panelDescriptionHeader, "\n            ");
  }
}
function SidePanelComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n        ");
    i02.\u0275\u0275elementStart(1, "div", 6);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n            ", ctx_r1.panelHeader, "\n        ");
  }
}
var _c0, SidePanelComponent;
var init_side_panel_component = __esm({
  "src/main/webapp/app/shared/side-panel/side-panel.component.ts"() {
    _c0 = ["*"];
    SidePanelComponent = class _SidePanelComponent {
      panelHeader;
      panelDescriptionHeader;
      constructor() {
      }
      static \u0275fac = function SidePanelComponent_Factory(t) {
        return new (t || _SidePanelComponent)();
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _SidePanelComponent, selectors: [["jhi-side-panel"]], inputs: { panelHeader: "panelHeader", panelDescriptionHeader: "panelDescriptionHeader" }, ngContentSelectors: _c0, decls: 12, vars: 1, consts: [[1, "guided-tour", "panel-wrapper"], [1, "vertLine"], [1, "panel-body"], [1, "row", "g-0", "panel-header"], [1, "col-7"], [1, "col-5", 2, "margin-left", "-3px"], [1, "panel-header"]], template: function SidePanelComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275projectionDef();
          i02.\u0275\u0275elementStart(0, "div", 0);
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275template(2, SidePanelComponent_Conditional_2_Template, 10, 2)(3, SidePanelComponent_Conditional_3_Template, 4, 1);
          i02.\u0275\u0275element(4, "div", 1);
          i02.\u0275\u0275text(5, "\n    ");
          i02.\u0275\u0275elementStart(6, "div", 2);
          i02.\u0275\u0275text(7, "\n        ");
          i02.\u0275\u0275projection(8);
          i02.\u0275\u0275text(9, "\n    ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(10, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(11, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(2);
          i02.\u0275\u0275conditional(2, ctx.panelDescriptionHeader !== void 0 ? 2 : 3);
        }
      }, styles: ["\n\n.panel-wrapper[_ngcontent-%COMP%] {\n  border: 1px solid var(--overview-blue-border-color);\n  border-radius: 3px;\n}\n.panel-wrapper[_ngcontent-%COMP%]   .panel-header[_ngcontent-%COMP%] {\n  padding: 10px 10px 10px 15px;\n  font-size: 16px;\n}\n.panel-wrapper[_ngcontent-%COMP%]   .panel-body[_ngcontent-%COMP%] {\n  padding: 8px 15px;\n}\n.panel-wrapper[_ngcontent-%COMP%]   .vertLine[_ngcontent-%COMP%] {\n  height: 1px;\n  background-color: var(--overview-blue-border-color);\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvc2lkZS1wYW5lbC9zaWRlLXBhbmVsLnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5wYW5lbC13cmFwcGVyIHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1vdmVydmlldy1ibHVlLWJvcmRlci1jb2xvcik7XG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xuXG4gICAgLnBhbmVsLWhlYWRlciB7XG4gICAgICAgIHBhZGRpbmc6IDEwcHggMTBweCAxMHB4IDE1cHg7XG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICB9XG5cbiAgICAucGFuZWwtYm9keSB7XG4gICAgICAgIHBhZGRpbmc6IDhweCAxNXB4O1xuICAgIH1cblxuICAgIC52ZXJ0TGluZSB7XG4gICAgICAgIGhlaWdodDogMXB4O1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1vdmVydmlldy1ibHVlLWJvcmRlci1jb2xvcik7XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLENBQUE7QUFDSSxVQUFBLElBQUEsTUFBQSxJQUFBO0FBQ0EsaUJBQUE7O0FBRUEsQ0FKSixjQUlJLENBQUE7QUFDSSxXQUFBLEtBQUEsS0FBQSxLQUFBO0FBQ0EsYUFBQTs7QUFHSixDQVRKLGNBU0ksQ0FBQTtBQUNJLFdBQUEsSUFBQTs7QUFHSixDQWJKLGNBYUksQ0FBQTtBQUNJLFVBQUE7QUFDQSxvQkFBQSxJQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(SidePanelComponent, { className: "SidePanelComponent" });
    })();
  }
});

export {
  SortService,
  init_sort_service,
  SidePanelComponent,
  init_side_panel_component
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3NlcnZpY2Uvc29ydC5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvc2lkZS1wYW5lbC9zaWRlLXBhbmVsLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL3NpZGUtcGFuZWwvc2lkZS1wYW5lbC5jb21wb25lbnQuaHRtbCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgZGF5anMgZnJvbSAnZGF5anMvZXNtJztcblxuQEluamVjdGFibGUoe1xuICAgIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgU29ydFNlcnZpY2Uge1xuICAgIGNvbnN0cnVjdG9yKCkge31cblxuICAgIC8qKlxuICAgICAqIFNvcnRzIHRoZSBnaXZlbiBhcnJheSBiYXNlZCBvbiB0aGUgZGVmaW5lZCBrZXlzXG4gICAgICogQHBhcmFtIGFycmF5IFRoZSBhcnJheSB0aGF0IHNob3VsZCBiZSBzb3J0ZWRcbiAgICAgKiBAcGFyYW0ga2V5IFRoZSBhdHRyaWJ1dGUgb2YgdGhlIGVsZW1lbnRzIHRoYXQgc2hvdWxkIGJlIHVzZWQgZm9yIGRldGVybWluaW5nIHRoZSBvcmRlclxuICAgICAqIEBwYXJhbSBhc2NlbmRpbmcgRGVjaWRlcyBpZiB0aGUgYmlnZ2VzdCB2YWx1ZSBjb21lcyBsYXN0IChhc2NlbmRpbmcpIG9yIGZpcnN0IChkZXNjZW5kaW5nKVxuICAgICAqL1xuICAgIHNvcnRCeVByb3BlcnR5PFQ+KGFycmF5OiBUW10sIGtleTogc3RyaW5nLCBhc2NlbmRpbmc6IGJvb2xlYW4pOiBUW10ge1xuICAgICAgICByZXR1cm4gdGhpcy5zb3J0QnlGdW5jdGlvbihhcnJheSwgKGVsZW1lbnQpID0+IFNvcnRTZXJ2aWNlLmN1c3RvbUdldChlbGVtZW50LCBrZXksIHVuZGVmaW5lZCksIGFzY2VuZGluZyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU29ydHMgdGhlIGdpdmVuIGFycmF5IGJhc2VkIG9uIHRoZSBkZWZpbmVkIGtleVxuICAgICAqIEBwYXJhbSBhcnJheSBUaGUgYXJyYXkgdGhhdCBzaG91bGQgYmUgc29ydGVkXG4gICAgICogQHBhcmFtIGtleXMgVGhlIGF0dHJpYnV0ZXMgb2YgdGhlIGVsZW1lbnRzIHRoYXQgc2hvdWxkIGJlIHVzZWQgZm9yIGRldGVybWluaW5nIHRoZSBvcmRlci4gV2lsbCBmaXJzdCBzb3J0IGJ5IHRoZSBmaXJzdCBrZXksIHRoZW4gdGhvc2Ugd2l0aCB0aGUgc2FtZSB2YWx1ZSBvZiB0aGUgZmlyc3Qga2V5IHdpbGwgYmUgc29ydGVkIGJ5IHRoZSBzZWNvbmQga2V5LCBldGMuXG4gICAgICogQHBhcmFtIGFzY2VuZGluZyBEZWNpZGVzIGlmIHRoZSBiaWdnZXN0IHZhbHVlIGNvbWVzIGxhc3QgKGFzY2VuZGluZykgb3IgZmlyc3QgKGRlc2NlbmRpbmcpXG4gICAgICovXG4gICAgc29ydEJ5TXVsdGlwbGVQcm9wZXJ0aWVzPFQ+KGFycmF5OiBUW10sIGtleXM6IHN0cmluZ1tdLCBhc2NlbmRpbmc6IGJvb2xlYW4pOiBUW10ge1xuICAgICAgICByZXR1cm4gYXJyYXkuc29ydCgoYTogVCwgYjogVCkgPT4ge1xuICAgICAgICAgICAgbGV0IGNvbXBhcmVWYWx1ZSA9IDA7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiBrZXlzKSB7XG4gICAgICAgICAgICAgICAgaWYgKGNvbXBhcmVWYWx1ZSA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBrZXlWYWx1ZUEgPSBTb3J0U2VydmljZS5jdXN0b21HZXQoYSwga2V5LCB1bmRlZmluZWQpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBrZXlWYWx1ZUIgPSBTb3J0U2VydmljZS5jdXN0b21HZXQoYiwga2V5LCB1bmRlZmluZWQpO1xuICAgICAgICAgICAgICAgICAgICBjb21wYXJlVmFsdWUgPSB0aGlzLmNvbXBhcmVWYWx1ZXMoa2V5VmFsdWVBLCBrZXlWYWx1ZUIsIGFzY2VuZGluZyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGNvbXBhcmVWYWx1ZTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU29ydHMgdGhlIGdpdmVuIGFycmF5IGJhc2VkIG9uIHRoZSBkZWZpbmVkIGtleVxuICAgICAqIEBwYXJhbSBhcnJheSBUaGUgYXJyYXkgdGhhdCBzaG91bGQgYmUgc29ydGVkXG4gICAgICogQHBhcmFtIGZ1bmMgVGhlIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIHZhbHVlIGJhc2VkIG9uIHdoaWNoIHRoZSBlbGVtZW50cyBzaG91bGQgYmUgc29ydGVkXG4gICAgICogQHBhcmFtIGFzY2VuZGluZyBEZWNpZGVzIGlmIHRoZSBiaWdnZXN0IHZhbHVlIGNvbWVzIGxhc3QgKGFzY2VuZGluZykgb3IgZmlyc3QgKGRlc2NlbmRpbmcpXG4gICAgICovXG4gICAgc29ydEJ5RnVuY3Rpb248VD4oYXJyYXk6IFRbXSwgZnVuYzogeyAocGFyYW1ldGVyOiBUKTogYW55IH0sIGFzY2VuZGluZzogYm9vbGVhbik6IFRbXSB7XG4gICAgICAgIHJldHVybiBhcnJheS5zb3J0KChhOiBULCBiOiBUKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZUEgPSBmdW5jKGEpO1xuICAgICAgICAgICAgY29uc3QgdmFsdWVCID0gZnVuYyhiKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbXBhcmVWYWx1ZXModmFsdWVBLCB2YWx1ZUIsIGFzY2VuZGluZyk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHByaXZhdGUgY29tcGFyZVZhbHVlcyh2YWx1ZUE6IGFueSwgdmFsdWVCOiBhbnksIGFzY2VuZGluZzogYm9vbGVhbikge1xuICAgICAgICBsZXQgY29tcGFyZVZhbHVlO1xuXG4gICAgICAgIGlmICh2YWx1ZUEgPT0gdW5kZWZpbmVkIHx8IHZhbHVlQiA9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGNvbXBhcmVWYWx1ZSA9IFNvcnRTZXJ2aWNlLmNvbXBhcmVXaXRoVW5kZWZpbmVkTnVsbCh2YWx1ZUEsIHZhbHVlQik7XG4gICAgICAgIH0gZWxzZSBpZiAoZGF5anMuaXNEYXlqcyh2YWx1ZUEpICYmIGRheWpzLmlzRGF5anModmFsdWVCKSkge1xuICAgICAgICAgICAgY29tcGFyZVZhbHVlID0gU29ydFNlcnZpY2UuY29tcGFyZURheWpzKHZhbHVlQSwgdmFsdWVCKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbXBhcmVWYWx1ZSA9IFNvcnRTZXJ2aWNlLmNvbXBhcmVCYXNpYyh2YWx1ZUEsIHZhbHVlQik7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIWFzY2VuZGluZykge1xuICAgICAgICAgICAgY29tcGFyZVZhbHVlID0gLWNvbXBhcmVWYWx1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY29tcGFyZVZhbHVlO1xuICAgIH1cblxuICAgIHB1YmxpYyBzdGF0aWMgY29tcGFyZVdpdGhVbmRlZmluZWROdWxsKHZhbHVlQTogYW55LCB2YWx1ZUI6IGFueSkge1xuICAgICAgICBpZiAoKHZhbHVlQSA9PT0gbnVsbCB8fCB2YWx1ZUEgPT09IHVuZGVmaW5lZCkgJiYgKHZhbHVlQiA9PT0gbnVsbCB8fCB2YWx1ZUIgPT09IHVuZGVmaW5lZCkpIHtcbiAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICB9IGVsc2UgaWYgKHZhbHVlQSA9PT0gbnVsbCB8fCB2YWx1ZUEgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gLTE7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIHN0YXRpYyBjb21wYXJlRGF5anModmFsdWVBOiBkYXlqcy5EYXlqcywgdmFsdWVCOiBkYXlqcy5EYXlqcykge1xuICAgICAgICBpZiAodmFsdWVBLmlzU2FtZSh2YWx1ZUIpKSB7XG4gICAgICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZUEuaXNCZWZvcmUodmFsdWVCKSA/IC0xIDogMTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgc3RhdGljIGNvbXBhcmVCYXNpYyh2YWx1ZUE6IGFueSwgdmFsdWVCOiBhbnkpIHtcbiAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZUEgPT09ICdzdHJpbmcnICYmIHR5cGVvZiB2YWx1ZUIgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWVBLmxvY2FsZUNvbXBhcmUodmFsdWVCKTtcbiAgICAgICAgfSBlbHNlIGlmICh2YWx1ZUEgPT09IHZhbHVlQikge1xuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWVBIDwgdmFsdWVCID8gLTEgOiAxO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzdGF0aWMgY3VzdG9tR2V0KG9iamVjdDogYW55LCBwYXRoOiBzdHJpbmcsIGRlZmF1bHRWYWx1ZTogYW55KSB7XG4gICAgICAgIC8vIEdldCByaWQgb2YgYWxsIG9wdGlvbmFsIGNoYWluaW5ncyBhcyB0aGV5IGFyZSBoYW5kbGVkIGRvd24gYmVsb3cuIEFmdGVyIHRoYXQgc3BsaXQgdGhlIHBhdGggaW50byBhbGwgYXJyYXkgYW5kIGF0dHJpYnV0ZSBhY2Nlc3Nlc1xuICAgICAgICAvLyBFeGFtcGxlOiBwYXRoICdzb21lPy5wYXRoWzBdLngnIHdpbGwgYmUgc3BsaXQgaW50byBwYXRoQXJyYXkgWydzb21lJywgJ3BhdGgnLCAnMCcsICd4J11cbiAgICAgICAgcGF0aCA9IHBhdGgucmVwbGFjZUFsbCgnPycsICcnKS5yZXBsYWNlQWxsKCddJywgJycpO1xuICAgICAgICBjb25zdCBwYXRoQXJyYXkgPSBwYXRoLnNwbGl0KC9cXC58XFxbLykuZmlsdGVyKChrZXkpID0+IGtleSk7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gcGF0aEFycmF5LnJlZHVjZSgob2JqLCBrZXkpID0+IHtcbiAgICAgICAgICAgIGlmICghb2JqKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iajtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgaWYgKG9iaiBpbnN0YW5jZW9mIE1hcCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gb2JqLmdldChrZXkpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBvYmpba2V5XTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIG9iamVjdCk7XG5cbiAgICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHJldHVybiBkZWZhdWx0VmFsdWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXNpZGUtcGFuZWwnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9zaWRlLXBhbmVsLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9zaWRlLXBhbmVsLnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgU2lkZVBhbmVsQ29tcG9uZW50IHtcbiAgICBASW5wdXQoKSBwYW5lbEhlYWRlcjogc3RyaW5nO1xuICAgIEBJbnB1dCgpIHBhbmVsRGVzY3JpcHRpb25IZWFkZXI/OiBzdHJpbmc7XG5cbiAgICBjb25zdHJ1Y3RvcigpIHt9XG59XG4iLCI8ZGl2IGNsYXNzPVwiZ3VpZGVkLXRvdXIgcGFuZWwtd3JhcHBlclwiPlxuICAgIEBpZiAocGFuZWxEZXNjcmlwdGlvbkhlYWRlciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJyb3cgZy0wIHBhbmVsLWhlYWRlclwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC03XCI+XG4gICAgICAgICAgICAgICAge3sgcGFuZWxIZWFkZXIgfX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC01XCIgc3R5bGU9XCJtYXJnaW4tbGVmdDogLTNweFwiPlxuICAgICAgICAgICAgICAgIHt7IHBhbmVsRGVzY3JpcHRpb25IZWFkZXIhIH19XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgfSBAZWxzZSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJwYW5lbC1oZWFkZXJcIj5cbiAgICAgICAgICAgIHt7IHBhbmVsSGVhZGVyIH19XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICA8ZGl2IGNsYXNzPVwidmVydExpbmVcIj48L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwicGFuZWwtYm9keVwiPlxuICAgICAgICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG4gICAgPC9kaXY+XG48L2Rpdj5cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxTQUFTLGtCQUFrQjtBQUMzQixPQUFPLFdBQVc7O0FBRGxCLElBTWE7QUFOYjs7QUFNTSxJQUFPLGNBQVAsTUFBTyxhQUFXO01BQ3BCLGNBQUE7TUFBZTtNQVFmLGVBQWtCLE9BQVksS0FBYSxXQUFrQjtBQUN6RCxlQUFPLEtBQUssZUFBZSxPQUFPLENBQUMsWUFBWSxhQUFZLFVBQVUsU0FBUyxLQUFLLE1BQVMsR0FBRyxTQUFTO01BQzVHO01BUUEseUJBQTRCLE9BQVksTUFBZ0IsV0FBa0I7QUFDdEUsZUFBTyxNQUFNLEtBQUssQ0FBQyxHQUFNLE1BQVE7QUFDN0IsY0FBSSxlQUFlO0FBQ25CLHFCQUFXLE9BQU8sTUFBTTtBQUNwQixnQkFBSSxpQkFBaUIsR0FBRztBQUNwQixvQkFBTSxZQUFZLGFBQVksVUFBVSxHQUFHLEtBQUssTUFBUztBQUN6RCxvQkFBTSxZQUFZLGFBQVksVUFBVSxHQUFHLEtBQUssTUFBUztBQUN6RCw2QkFBZSxLQUFLLGNBQWMsV0FBVyxXQUFXLFNBQVM7OztBQUd6RSxpQkFBTztRQUNYLENBQUM7TUFDTDtNQVFBLGVBQWtCLE9BQVksTUFBK0IsV0FBa0I7QUFDM0UsZUFBTyxNQUFNLEtBQUssQ0FBQyxHQUFNLE1BQVE7QUFDN0IsZ0JBQU0sU0FBUyxLQUFLLENBQUM7QUFDckIsZ0JBQU0sU0FBUyxLQUFLLENBQUM7QUFDckIsaUJBQU8sS0FBSyxjQUFjLFFBQVEsUUFBUSxTQUFTO1FBQ3ZELENBQUM7TUFDTDtNQUVRLGNBQWMsUUFBYSxRQUFhLFdBQWtCO0FBQzlELFlBQUk7QUFFSixZQUFJLFVBQVUsVUFBYSxVQUFVLFFBQVc7QUFDNUMseUJBQWUsYUFBWSx5QkFBeUIsUUFBUSxNQUFNO21CQUMzRCxNQUFNLFFBQVEsTUFBTSxLQUFLLE1BQU0sUUFBUSxNQUFNLEdBQUc7QUFDdkQseUJBQWUsYUFBWSxhQUFhLFFBQVEsTUFBTTtlQUNuRDtBQUNILHlCQUFlLGFBQVksYUFBYSxRQUFRLE1BQU07O0FBRzFELFlBQUksQ0FBQyxXQUFXO0FBQ1oseUJBQWUsQ0FBQzs7QUFFcEIsZUFBTztNQUNYO01BRU8sT0FBTyx5QkFBeUIsUUFBYSxRQUFXO0FBQzNELGFBQUssV0FBVyxRQUFRLFdBQVcsWUFBZSxXQUFXLFFBQVEsV0FBVyxTQUFZO0FBQ3hGLGlCQUFPO21CQUNBLFdBQVcsUUFBUSxXQUFXLFFBQVc7QUFDaEQsaUJBQU87ZUFDSjtBQUNILGlCQUFPOztNQUVmO01BRVEsT0FBTyxhQUFhLFFBQXFCLFFBQW1CO0FBQ2hFLFlBQUksT0FBTyxPQUFPLE1BQU0sR0FBRztBQUN2QixpQkFBTztlQUNKO0FBQ0gsaUJBQU8sT0FBTyxTQUFTLE1BQU0sSUFBSSxLQUFLOztNQUU5QztNQUVRLE9BQU8sYUFBYSxRQUFhLFFBQVc7QUFDaEQsWUFBSSxPQUFPLFdBQVcsWUFBWSxPQUFPLFdBQVcsVUFBVTtBQUMxRCxpQkFBTyxPQUFPLGNBQWMsTUFBTTttQkFDM0IsV0FBVyxRQUFRO0FBQzFCLGlCQUFPO2VBQ0o7QUFDSCxpQkFBTyxTQUFTLFNBQVMsS0FBSzs7TUFFdEM7TUFFUSxPQUFPLFVBQVUsUUFBYSxNQUFjLGNBQWlCO0FBR2pFLGVBQU8sS0FBSyxXQUFXLEtBQUssRUFBRSxFQUFFLFdBQVcsS0FBSyxFQUFFO0FBQ2xELGNBQU0sWUFBWSxLQUFLLE1BQU0sT0FBTyxFQUFFLE9BQU8sQ0FBQyxRQUFRLEdBQUc7QUFDekQsY0FBTSxRQUFRLFVBQVUsT0FBTyxDQUFDLEtBQUssUUFBTztBQUN4QyxjQUFJLENBQUMsS0FBSztBQUNOLG1CQUFPO2lCQUNKO0FBQ0gsZ0JBQUksZUFBZSxLQUFLO0FBQ3BCLHFCQUFPLElBQUksSUFBSSxHQUFHO21CQUNmO0FBQ0gscUJBQU8sSUFBSSxHQUFHOzs7UUFHMUIsR0FBRyxNQUFNO0FBRVQsWUFBSSxVQUFVLFFBQVc7QUFDckIsaUJBQU87ZUFDSjtBQUNILGlCQUFPOztNQUVmOzt5QkFsSFMsY0FBVztNQUFBO21FQUFYLGNBQVcsU0FBWCxhQUFXLFdBQUEsWUFGUixPQUFNLENBQUE7Ozs7OztBQ0p0QixTQUFTLFdBQVcsYUFBYTs7OztBQ0V6QixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7QUFOWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLHNCQUFBLE9BQUEsYUFBQSxnQkFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsc0JBQUEsT0FBQSx3QkFBQSxnQkFBQTs7Ozs7QUFJUixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7Ozs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtCQUFBLE9BQUEsYUFBQSxZQUFBOzs7QURaWixTQU9hO0FBUGI7OztBQU9NLElBQU8scUJBQVAsTUFBTyxvQkFBa0I7TUFDbEI7TUFDQTtNQUVULGNBQUE7TUFBZTs7eUJBSk4scUJBQWtCO01BQUE7aUVBQWxCLHFCQUFrQixXQUFBLENBQUEsQ0FBQSxnQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLGFBQUEsZUFBQSx3QkFBQSx5QkFBQSxHQUFBLG9CQUFBLEtBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLGVBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxPQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSw0QkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7QUNQL0IsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLDJDQUFBLElBQUEsQ0FBQSxFQVNDLEdBQUEsMkNBQUEsR0FBQSxDQUFBO0FBS0QsVUFBQSx3QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQSxDQUFBO0FBQ0osVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQW5CSSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSwyQkFBQSxTQUFBLElBQUEsQ0FBQTs7Ozs7cUZETVMsb0JBQWtCLEVBQUEsV0FBQSxxQkFBQSxDQUFBO0lBQUEsR0FBQTs7OyIsIm5hbWVzIjpbXX0=