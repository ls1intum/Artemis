import {
  ArtemisProgrammingExerciseActionsModule,
  SubmissionResultStatusModule,
  init_programming_exercise_actions_module,
  init_submission_result_status_module
} from "/chunk-KZDJAYFO.js";
import {
  ArtemisSharedComponentModule,
  ExerciseCacheService,
  FeedbackComponent,
  MissingResultInformation,
  ResultComponent,
  ResultTemplateStatus,
  evaluateTemplateStatus,
  getResultIconClass,
  getTextColorClass,
  init_exercise_cache_service,
  init_feedback_collapse_component,
  init_feedback_component,
  init_feedback_node_component,
  init_feedback_text_component,
  init_result_component,
  init_result_utils,
  init_shared_component_module
} from "/chunk-ORYTP7RT.js";
import {
  ArtemisSharedModule,
  ExerciseService,
  Feedback,
  FeedbackSuggestionType,
  TranslateDirective,
  __esm,
  init_exercise_model,
  init_exercise_service,
  init_feedback_model,
  init_shared_module,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/shared/feedback/standalone-feedback/standalone-feedback.component.ts
import { Component, Optional } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import { ActivatedRoute } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function StandaloneFeedbackComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275element(1, "jhi-result-detail", 0);
    i0.\u0275\u0275text(2, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("exercise", ctx_r0.exercise)("result", ctx_r0.result)("showScoreChart", true)("exerciseType", ctx_r0.exerciseType)("latestDueDate", ctx_r0.latestDueDate)("messageKey", ctx_r0.messageKey)("showMissingAutomaticFeedbackInformation", ctx_r0.showMissingAutomaticFeedbackInformation);
  }
}
var StandaloneFeedbackComponent;
var init_standalone_feedback_component = __esm({
  "src/main/webapp/app/exercises/shared/feedback/standalone-feedback/standalone-feedback.component.ts"() {
    init_exercise_service();
    init_exercise_cache_service();
    init_result_utils();
    init_exercise_service();
    init_exercise_cache_service();
    init_feedback_component();
    StandaloneFeedbackComponent = class _StandaloneFeedbackComponent {
      route;
      exerciseService;
      exerciseCacheService;
      exercise;
      result;
      showMissingAutomaticFeedbackInformation = false;
      messageKey;
      exerciseType;
      latestDueDate;
      constructor(route, exerciseService, exerciseCacheService) {
        this.route = route;
        this.exerciseService = exerciseService;
        this.exerciseCacheService = exerciseCacheService;
      }
      ngOnInit() {
        this.route.params.subscribe((params) => {
          const exerciseId = parseInt(params["exerciseId"], 10);
          const participationId = parseInt(params["participationId"], 10);
          const resultId = parseInt(params["resultId"], 10);
          this.exerciseService.getExerciseDetails(exerciseId).subscribe((exerciseResponse) => {
            this.exercise = exerciseResponse.body;
            const participation = this.exercise?.studentParticipations?.find((participation2) => participation2.id === participationId);
            if (participation) {
              participation.exercise = this.exercise;
            }
            const relevantResult = participation?.results?.find((result) => result.id == resultId);
            if (relevantResult) {
              relevantResult.participation = participation;
            }
            this.result = relevantResult;
            const templateStatus = evaluateTemplateStatus(exerciseResponse.body, participation, relevantResult, false);
            if (templateStatus == ResultTemplateStatus.MISSING) {
              this.messageKey = "artemisApp.result.notLatestSubmission";
            } else {
              this.messageKey = void 0;
            }
            this.setup();
          });
          (this.exerciseCacheService ?? this.exerciseService).getLatestDueDate(exerciseId).subscribe((latestDueDate) => {
            this.latestDueDate = latestDueDate;
            this.setup();
          });
        });
      }
      setup() {
        if (this.exercise && this.result) {
          this.exerciseType = this.exercise.type;
          if (this.latestDueDate) {
            this.showMissingAutomaticFeedbackInformation = dayjs().isBefore(this.latestDueDate);
          }
        }
      }
      static \u0275fac = function StandaloneFeedbackComponent_Factory(t) {
        return new (t || _StandaloneFeedbackComponent)(i0.\u0275\u0275directiveInject(i1.ActivatedRoute), i0.\u0275\u0275directiveInject(ExerciseService), i0.\u0275\u0275directiveInject(ExerciseCacheService, 8));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _StandaloneFeedbackComponent, selectors: [["jhi-standalone-feedback"]], decls: 1, vars: 1, consts: [[1, "modal-padding", 3, "exercise", "result", "showScoreChart", "exerciseType", "latestDueDate", "messageKey", "showMissingAutomaticFeedbackInformation"]], template: function StandaloneFeedbackComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275template(0, StandaloneFeedbackComponent_Conditional_0_Template, 3, 7);
        }
        if (rf & 2) {
          i0.\u0275\u0275conditional(0, ctx.exercise && ctx.result && ctx.exerciseType ? 0 : -1);
        }
      }, dependencies: [FeedbackComponent], styles: ["\n\n[_nghost-%COMP%]   .feedback-header[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: var(--artemis-dark);\n}\n[_nghost-%COMP%]   .feedback-header__close[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  color: #fff;\n}\n[_nghost-%COMP%]   .result-score-chart[_ngcontent-%COMP%] {\n  margin-bottom: 3rem;\n}\n[_nghost-%COMP%]   .result-score-chart[_ngcontent-%COMP%]   .chart-tooltip-space[_ngcontent-%COMP%]   .chart-tooltip-space-content[_ngcontent-%COMP%] {\n  width: 250px;\n  height: 20px;\n  top: -15px;\n  position: absolute;\n}\n[_nghost-%COMP%]   -shadowcsshost  .legend-labels {\n  background-color: transparent !important;\n  text-align: center !important;\n  font-weight: bolder;\n}\n[_nghost-%COMP%]   -shadowcsshost  .legend-label {\n  color: var(--artemis-dark) !important;\n}\n[_nghost-%COMP%]   -shadowcsshost  .legend-label-color {\n  border: 1px solid;\n}\n[_nghost-%COMP%]   .modal-footer[_ngcontent-%COMP%] {\n  min-width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2ZlZWRiYWNrL2ZlZWRiYWNrLnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIjpob3N0IHtcbiAgICAkZmVlZGJhY2staGVhZGVyLWZnOiAjZmZmO1xuXG4gICAgLmZlZWRiYWNrIHtcbiAgICAgICAgJi1oZWFkZXIge1xuICAgICAgICAgICAgY29sb3I6ICRmZWVkYmFjay1oZWFkZXItZmc7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hcnRlbWlzLWRhcmspO1xuXG4gICAgICAgICAgICAmX19jbG9zZSB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogbm9uZTtcbiAgICAgICAgICAgICAgICBib3JkZXI6IG5vbmU7XG4gICAgICAgICAgICAgICAgY29sb3I6ICRmZWVkYmFjay1oZWFkZXItZmc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAucmVzdWx0LXNjb3JlLWNoYXJ0IHtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogM3JlbTtcblxuICAgICAgICAuY2hhcnQtdG9vbHRpcC1zcGFjZSB7XG4gICAgICAgICAgICAuY2hhcnQtdG9vbHRpcC1zcGFjZS1jb250ZW50IHtcbiAgICAgICAgICAgICAgICB3aWR0aDogMjUwcHg7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAyMHB4O1xuICAgICAgICAgICAgICAgIHRvcDogLTE1cHg7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgOmhvc3Q6Om5nLWRlZXAgLmxlZ2VuZC1sYWJlbHMge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXIgIWltcG9ydGFudDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcbiAgICB9XG5cbiAgICA6aG9zdDo6bmctZGVlcCAubGVnZW5kLWxhYmVsIHtcbiAgICAgICAgY29sb3I6IHZhcigtLWFydGVtaXMtZGFyaykgIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICA6aG9zdDo6bmctZGVlcCAubGVnZW5kLWxhYmVsLWNvbG9yIHtcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQ7XG4gICAgfVxuXG4gICAgLm1vZGFsLWZvb3RlciB7XG4gICAgICAgIG1pbi13aWR0aDogMTAwJTtcbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBSVEsTUFBQSxDQUFBO0FBQ0ksU0FKYTtBQUtiLG9CQUFBLElBQUE7O0FBRUEsTUFBQSxDQUFBO0FBQ0ksY0FBQTtBQUNBLFVBQUE7QUFDQSxTQVZTOztBQWVyQixNQUFBLENBQUE7QUFDSSxpQkFBQTs7QUFHSSxNQUFBLENBSlIsbUJBSVEsQ0FBQSxvQkFBQSxDQUFBO0FBQ0ksU0FBQTtBQUNBLFVBQUE7QUFDQSxPQUFBO0FBQ0EsWUFBQTs7QUFLWixNQUFBLEtBQUEsVUFBQSxDQUFBO0FBQ0ksb0JBQUE7QUFDQSxjQUFBO0FBQ0EsZUFBQTs7QUFHSixNQUFBLEtBQUEsVUFBQSxDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUdKLE1BQUEsS0FBQSxVQUFBLENBQUE7QUFDSSxVQUFBLElBQUE7O0FBR0osTUFBQSxDQUFBO0FBQ0ksYUFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */", "\n\n.modal-padding[_ngcontent-%COMP%] {\n  --bs-modal-padding: 1rem;\n  --bs-modal-header-padding: 1rem 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2ZlZWRiYWNrL3N0YW5kYWxvbmUtZmVlZGJhY2svc3RhbmRhbG9uZS1mZWVkYmFjay5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIubW9kYWwtcGFkZGluZyB7XG4gICAgLS1icy1tb2RhbC1wYWRkaW5nOiAxcmVtO1xuICAgIC0tYnMtbW9kYWwtaGVhZGVyLXBhZGRpbmc6IDFyZW0gMXJlbTtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksc0JBQUE7QUFDQSw2QkFBQSxLQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(StandaloneFeedbackComponent, { className: "StandaloneFeedbackComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/feedback/feedback-suggestion-badge/feedback-suggestion-badge.component.ts
import { Component as Component2, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faLightbulb } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
var FeedbackSuggestionBadgeComponent;
var init_feedback_suggestion_badge_component = __esm({
  "src/main/webapp/app/exercises/shared/feedback/feedback-suggestion-badge/feedback-suggestion-badge.component.ts"() {
    init_feedback_model();
    init_translate_directive();
    FeedbackSuggestionBadgeComponent = class _FeedbackSuggestionBadgeComponent {
      translateService;
      feedback;
      useDefaultText = false;
      faLightbulb = faLightbulb;
      constructor(translateService) {
        this.translateService = translateService;
      }
      get text() {
        const feedbackSuggestionType = Feedback.getFeedbackSuggestionType(this.feedback);
        if (feedbackSuggestionType === FeedbackSuggestionType.ADAPTED) {
          return "artemisApp.assessment.suggestion.adapted";
        }
        if (this.useDefaultText) {
          return "artemisApp.assessment.suggestion.default";
        }
        switch (feedbackSuggestionType) {
          case FeedbackSuggestionType.SUGGESTED:
            return "artemisApp.assessment.suggestion.suggested";
          case FeedbackSuggestionType.ACCEPTED:
            return "artemisApp.assessment.suggestion.accepted";
          default:
            return "";
        }
      }
      get tooltip() {
        if (this.useDefaultText) {
          return this.translateService.instant("artemisApp.assessment.suggestionTitle.default");
        }
        const feedbackSuggestionType = Feedback.getFeedbackSuggestionType(this.feedback);
        switch (feedbackSuggestionType) {
          case FeedbackSuggestionType.SUGGESTED:
            return this.translateService.instant("artemisApp.assessment.suggestionTitle.suggested");
          case FeedbackSuggestionType.ACCEPTED:
            return this.translateService.instant("artemisApp.assessment.suggestionTitle.accepted");
          case FeedbackSuggestionType.ADAPTED:
            return this.translateService.instant("artemisApp.assessment.suggestionTitle.adapted");
          default:
            return "";
        }
      }
      static \u0275fac = function FeedbackSuggestionBadgeComponent_Factory(t) {
        return new (t || _FeedbackSuggestionBadgeComponent)(i02.\u0275\u0275directiveInject(i12.TranslateService));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _FeedbackSuggestionBadgeComponent, selectors: [["jhi-feedback-suggestion-badge"]], inputs: { feedback: "feedback", useDefaultText: "useDefaultText" }, decls: 8, vars: 3, consts: [[1, "badge", "suggestion-badge", 3, "ngbTooltip"], [3, "icon"], [3, "jhiTranslate"]], template: function FeedbackSuggestionBadgeComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "span", 0);
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275element(2, "fa-icon", 1);
          i02.\u0275\u0275text(3, "\n    ");
          i02.\u0275\u0275elementStart(4, "span", 2);
          i02.\u0275\u0275text(5, "Suggestion");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(6, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(7, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275property("ngbTooltip", ctx.tooltip);
          i02.\u0275\u0275advance(2);
          i02.\u0275\u0275property("icon", ctx.faLightbulb);
          i02.\u0275\u0275advance(2);
          i02.\u0275\u0275property("jhiTranslate", ctx.text);
        }
      }, dependencies: [i2.NgbTooltip, i3.FaIconComponent, TranslateDirective], styles: ["\n\n[_nghost-%COMP%] {\n  display: inline-block;\n  height: 12px;\n}\n.suggestion-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -8px;\n  vertical-align: middle;\n  background-color: var(--feedback-suggestions-primary);\n  cursor: default;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2ZlZWRiYWNrL2ZlZWRiYWNrLXN1Z2dlc3Rpb24tYmFkZ2UvZmVlZGJhY2stc3VnZ2VzdGlvbi1iYWRnZS5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiOmhvc3Qge1xuICAgIC8qIFNoaWZ0IHRoZSBmZWVkYmFjayBjb250ZW50IGRvd24gYSBiaXQgdG8gbWFrZSBzcGFjZSBmb3IgdGhlIGJhZGdlICovXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIGhlaWdodDogMTJweDtcbn1cblxuLnN1Z2dlc3Rpb24tYmFkZ2Uge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IC04cHg7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1mZWVkYmFjay1zdWdnZXN0aW9ucy1wcmltYXJ5KTtcbiAgICBjdXJzb3I6IGRlZmF1bHQ7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUE7QUFFSSxXQUFBO0FBQ0EsVUFBQTs7QUFHSixDQUFBO0FBQ0ksWUFBQTtBQUNBLE9BQUE7QUFDQSxrQkFBQTtBQUNBLG9CQUFBLElBQUE7QUFDQSxVQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(FeedbackSuggestionBadgeComponent, { className: "FeedbackSuggestionBadgeComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/feedback/feedback-suggestions-pending-confirmation-dialog/feedback-suggestions-pending-confirmation-dialog.component.ts
import { Component as Component3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faBan, faTimes } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { NgbActiveModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
var FeedbackSuggestionsPendingConfirmationDialogComponent;
var init_feedback_suggestions_pending_confirmation_dialog_component = __esm({
  "src/main/webapp/app/exercises/shared/feedback/feedback-suggestions-pending-confirmation-dialog/feedback-suggestions-pending-confirmation-dialog.component.ts"() {
    init_translate_directive();
    FeedbackSuggestionsPendingConfirmationDialogComponent = class _FeedbackSuggestionsPendingConfirmationDialogComponent {
      activeModal;
      faBan = faBan;
      faTimes = faTimes;
      constructor(activeModal) {
        this.activeModal = activeModal;
      }
      close(confirm) {
        this.activeModal.close(confirm);
      }
      static \u0275fac = function FeedbackSuggestionsPendingConfirmationDialogComponent_Factory(t) {
        return new (t || _FeedbackSuggestionsPendingConfirmationDialogComponent)(i03.\u0275\u0275directiveInject(i13.NgbActiveModal));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _FeedbackSuggestionsPendingConfirmationDialogComponent, selectors: [["jhi-feedback-suggestions-pending-confirmation-dialog"]], decls: 37, vars: 1, consts: [[1, "modal-header"], [1, "modal-title"], ["jhiTranslate", "artemisApp.assessment.suggestionPendingDialog.title"], ["type", "button", "data-dismiss", "modal", "aria-hidden", "true", 1, "btn-close", 3, "click"], [1, "modal-body"], ["jhiTranslate", "artemisApp.assessment.suggestionPendingDialog.description"], [1, "modal-footer"], ["type", "button", "data-dismiss", "modal", 1, "btn", "btn-secondary", 3, "click"], [3, "icon"], ["jhiTranslate", "entity.action.cancel"], ["type", "submit", "ngClass", "btn btn-primary", 3, "click"], ["jhiTranslate", "artemisApp.assessment.suggestionPendingDialog.discardAndSubmit"]], template: function FeedbackSuggestionsPendingConfirmationDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "form");
          i03.\u0275\u0275text(1, "\n    ");
          i03.\u0275\u0275elementStart(2, "div", 0);
          i03.\u0275\u0275text(3, "\n        ");
          i03.\u0275\u0275elementStart(4, "h4", 1);
          i03.\u0275\u0275text(5, "\n            ");
          i03.\u0275\u0275elementStart(6, "span", 2);
          i03.\u0275\u0275text(7, "Pending Feedback Suggestions");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(8, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(9, "\n        ");
          i03.\u0275\u0275elementStart(10, "button", 3);
          i03.\u0275\u0275listener("click", function FeedbackSuggestionsPendingConfirmationDialogComponent_Template_button_click_10_listener() {
            return ctx.close(false);
          });
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(11, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(12, "\n    ");
          i03.\u0275\u0275elementStart(13, "div", 4);
          i03.\u0275\u0275text(14, "\n        ");
          i03.\u0275\u0275elementStart(15, "p", 5);
          i03.\u0275\u0275text(16, "\n            There are pending feedback suggestions available. They will be discarded. Do you really want to submit?\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(17, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(18, "\n    ");
          i03.\u0275\u0275elementStart(19, "div", 6);
          i03.\u0275\u0275text(20, "\n        ");
          i03.\u0275\u0275elementStart(21, "button", 7);
          i03.\u0275\u0275listener("click", function FeedbackSuggestionsPendingConfirmationDialogComponent_Template_button_click_21_listener() {
            return ctx.close(false);
          });
          i03.\u0275\u0275text(22, "\n            ");
          i03.\u0275\u0275element(23, "fa-icon", 8);
          i03.\u0275\u0275text(24, "\xA0");
          i03.\u0275\u0275elementStart(25, "span", 9);
          i03.\u0275\u0275text(26, "Cancel");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(27, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(28, "\n        ");
          i03.\u0275\u0275elementStart(29, "button", 10);
          i03.\u0275\u0275listener("click", function FeedbackSuggestionsPendingConfirmationDialogComponent_Template_button_click_29_listener() {
            return ctx.close(true);
          });
          i03.\u0275\u0275text(30, "\n            ");
          i03.\u0275\u0275elementStart(31, "span", 11);
          i03.\u0275\u0275text(32, "Discard suggestions & submit");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(33, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(34, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(35, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(36, "\n");
        }
        if (rf & 2) {
          i03.\u0275\u0275advance(23);
          i03.\u0275\u0275property("icon", ctx.faBan);
        }
      }, dependencies: [i22.\u0275NgNoValidate, i22.NgControlStatusGroup, i22.NgForm, i32.NgClass, i4.FaIconComponent, TranslateDirective], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(FeedbackSuggestionsPendingConfirmationDialogComponent, { className: "FeedbackSuggestionsPendingConfirmationDialogComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/feedback/feedback.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { BarChartModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisFeedbackModule;
var init_feedback_module = __esm({
  "src/main/webapp/app/exercises/shared/feedback/feedback.module.ts"() {
    init_shared_module();
    init_programming_exercise_actions_module();
    init_shared_component_module();
    init_feedback_collapse_component();
    init_feedback_node_component();
    init_feedback_component();
    init_feedback_text_component();
    init_standalone_feedback_component();
    init_feedback_suggestion_badge_component();
    init_feedback_suggestions_pending_confirmation_dialog_component();
    ArtemisFeedbackModule = class _ArtemisFeedbackModule {
      static \u0275fac = function ArtemisFeedbackModule_Factory(t) {
        return new (t || _ArtemisFeedbackModule)();
      };
      static \u0275mod = i04.\u0275\u0275defineNgModule({ type: _ArtemisFeedbackModule });
      static \u0275inj = i04.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, ArtemisProgrammingExerciseActionsModule, ArtemisSharedComponentModule, BarChartModule] });
    };
  }
});

// src/main/webapp/app/overview/result-history/result-history.component.ts
import { Component as Component4, Input as Input2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i14 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i23 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ResultHistoryComponent_For_8_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n        ");
    i05.\u0275\u0275elementStart(1, "div", 1);
    i05.\u0275\u0275text(2, "\n            ");
    i05.\u0275\u0275elementStart(3, "div", 3);
    i05.\u0275\u0275text(4, "\n                ");
    i05.\u0275\u0275elementStart(5, "div", 4);
    i05.\u0275\u0275text(6, "\n                    ");
    i05.\u0275\u0275element(7, "fa-icon", 5);
    i05.\u0275\u0275text(8, "\n                ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(9, "\n                ");
    i05.\u0275\u0275elementStart(10, "jhi-result", 6);
    i05.\u0275\u0275text(11, "\n                ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(12, "\n            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(13, "\n            ");
    i05.\u0275\u0275element(14, "div", 7);
    i05.\u0275\u0275text(15, "\n        ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(16, "\n    ");
  }
  if (rf & 2) {
    const result_r1 = ctx.$implicit;
    const i_r2 = ctx.$index;
    const ctx_r0 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(5);
    i05.\u0275\u0275property("ngClass", ctx_r0.getTextColorClass(result_r1, ctx_r0.evaluateTemplateStatus(ctx_r0.exercise, result_r1.participation, result_r1, false, ctx_r0.MissingResultInfo.NONE)));
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275property("icon", ctx_r0.getResultIconClass(result_r1, ctx_r0.evaluateTemplateStatus(ctx_r0.exercise, result_r1.participation, result_r1, false, ctx_r0.MissingResultInfo.NONE)));
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275property("exercise", ctx_r0.exercise)("result", result_r1)("participation", result_r1.participation)("showUngradedResults", true)("showBadge", true)("showIcon", false);
    i05.\u0275\u0275advance(4);
    i05.\u0275\u0275property("ngStyle", i_r2 === 0 && ctx_r0.movedLastRatedResult ? i05.\u0275\u0275pureFunction0(9, _c0) : i05.\u0275\u0275pureFunction0(10, _c1));
  }
}
var _c0, _c1, MAX_RESULT_HISTORY_LENGTH, ResultHistoryComponent;
var init_result_history_component = __esm({
  "src/main/webapp/app/overview/result-history/result-history.component.ts"() {
    init_exercise_model();
    init_result_utils();
    init_result_component();
    _c0 = () => ({ "border-top": "1px dashed" });
    _c1 = () => ({});
    MAX_RESULT_HISTORY_LENGTH = 5;
    ResultHistoryComponent = class _ResultHistoryComponent {
      getTextColorClass = getTextColorClass;
      getResultIconClass = getResultIconClass;
      evaluateTemplateStatus = evaluateTemplateStatus;
      MissingResultInfo = MissingResultInformation;
      results;
      exercise;
      showPreviousDivider = false;
      displayedResults;
      movedLastRatedResult;
      ngOnChanges() {
        this.showPreviousDivider = this.results.length > MAX_RESULT_HISTORY_LENGTH;
        if (this.results.length <= MAX_RESULT_HISTORY_LENGTH) {
          this.displayedResults = this.results;
        } else {
          this.displayedResults = this.results.slice(this.results.length - MAX_RESULT_HISTORY_LENGTH);
          const lastRatedResult = this.results.filter((result) => result.rated).last();
          if (!this.displayedResults.first()?.rated && lastRatedResult) {
            this.displayedResults[0] = lastRatedResult;
            this.movedLastRatedResult = true;
          }
        }
      }
      static \u0275fac = function ResultHistoryComponent_Factory(t) {
        return new (t || _ResultHistoryComponent)();
      };
      static \u0275cmp = i05.\u0275\u0275defineComponent({ type: _ResultHistoryComponent, selectors: [["jhi-result-history"]], inputs: { results: "results", exercise: "exercise" }, features: [i05.\u0275\u0275NgOnChangesFeature], decls: 10, vars: 2, consts: [[1, "result-history-wrapper"], [1, "result-history-element"], [1, "result-divider"], [1, "result-score"], [1, "result-score-icon", 3, "ngClass"], ["size", "xl", 3, "icon"], [1, "result-score-info", "text-center", 3, "exercise", "result", "participation", "showUngradedResults", "showBadge", "showIcon"], [1, "result-divider", 3, "ngStyle"]], template: function ResultHistoryComponent_Template(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275elementStart(0, "div", 0);
          i05.\u0275\u0275text(1, "\n    ");
          i05.\u0275\u0275elementStart(2, "div", 1);
          i05.\u0275\u0275text(3, "\n        ");
          i05.\u0275\u0275element(4, "div", 2);
          i05.\u0275\u0275text(5, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(6, "\n    ");
          i05.\u0275\u0275repeaterCreate(7, ResultHistoryComponent_For_8_Template, 17, 11, null, null, i05.\u0275\u0275repeaterTrackByIdentity);
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(9, "\n");
        }
        if (rf & 2) {
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275classProp("previous-history-element", ctx.showPreviousDivider);
          i05.\u0275\u0275advance(5);
          i05.\u0275\u0275repeater(ctx.displayedResults);
        }
      }, dependencies: [i14.NgClass, i14.NgStyle, i23.FaIconComponent, ResultComponent], styles: ["\n\n.result-history-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  width: 100%;\n}\n.result-history-wrapper[_ngcontent-%COMP%]   .result-history-element[_ngcontent-%COMP%] {\n  display: flex;\n  flex: 2;\n}\n.result-history-wrapper[_ngcontent-%COMP%]   .result-history-element[_ngcontent-%COMP%]   .result-score[_ngcontent-%COMP%] {\n  width: 75px;\n}\n.result-history-wrapper[_ngcontent-%COMP%]   .result-history-element[_ngcontent-%COMP%]   .result-score[_ngcontent-%COMP%]   .result-score-icon[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 25px;\n  height: 25px;\n  border-radius: 25px;\n  background-color: transparent;\n}\n.result-history-wrapper[_ngcontent-%COMP%]   .result-history-element[_ngcontent-%COMP%]   .result-score[_ngcontent-%COMP%]   .result-score-info[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  margin-left: -39px;\n  margin-right: -39px;\n  gap: 4px;\n}\n.result-history-wrapper[_ngcontent-%COMP%]   .result-history-element[_ngcontent-%COMP%]   .result-divider[_ngcontent-%COMP%] {\n  width: 300%;\n  border-top: 1px solid;\n  margin-top: 12.5px;\n}\n.result-history-wrapper[_ngcontent-%COMP%]   .result-history-element[_ngcontent-%COMP%]:first-child {\n  flex: 1;\n}\n.result-history-wrapper[_ngcontent-%COMP%]   .result-history-element[_ngcontent-%COMP%]:last-child {\n  flex: 1;\n}\n.result-history-wrapper[_ngcontent-%COMP%]   .result-history-element[_ngcontent-%COMP%]:last-child   .result-divider[_ngcontent-%COMP%] {\n  border-top: 1px dashed;\n}\n.result-history-wrapper[_ngcontent-%COMP%]   .result-history-element.previous-history-element[_ngcontent-%COMP%]   .result-divider[_ngcontent-%COMP%] {\n  border-top: 1px dashed;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9yZXN1bHQtaGlzdG9yeS9yZXN1bHQtaGlzdG9yeS5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIkcmVzdWx0LWVsZW1lbnQtc2l6ZTogNzVweDtcbiRyZXN1bHQtaWNvbi1zaXplOiAyNXB4O1xuLnJlc3VsdC1oaXN0b3J5LXdyYXBwZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgd2lkdGg6IDEwMCU7XG5cbiAgICAucmVzdWx0LWhpc3RvcnktZWxlbWVudCB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGZsZXg6IDI7XG5cbiAgICAgICAgLnJlc3VsdC1zY29yZSB7XG4gICAgICAgICAgICB3aWR0aDogJHJlc3VsdC1lbGVtZW50LXNpemU7XG5cbiAgICAgICAgICAgIC5yZXN1bHQtc2NvcmUtaWNvbiB7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICAgICAgICAgIHdpZHRoOiAkcmVzdWx0LWljb24tc2l6ZTtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6ICRyZXN1bHQtaWNvbi1zaXplO1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6ICRyZXN1bHQtaWNvbi1zaXplO1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAucmVzdWx0LXNjb3JlLWluZm8ge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAtMzlweDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IC0zOXB4O1xuICAgICAgICAgICAgICAgIGdhcDogNHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLnJlc3VsdC1kaXZpZGVyIHtcbiAgICAgICAgICAgIHdpZHRoOiAzMDAlO1xuICAgICAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkO1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogJHJlc3VsdC1pY29uLXNpemUgKiAwLjU7XG4gICAgICAgIH1cblxuICAgICAgICAmOmZpcnN0LWNoaWxkIHtcbiAgICAgICAgICAgIGZsZXg6IDE7XG4gICAgICAgIH1cblxuICAgICAgICAmOmxhc3QtY2hpbGQge1xuICAgICAgICAgICAgZmxleDogMTtcbiAgICAgICAgICAgIC5yZXN1bHQtZGl2aWRlciB7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXRvcDogMXB4IGRhc2hlZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgICYucHJldmlvdXMtaGlzdG9yeS1lbGVtZW50IHtcbiAgICAgICAgICAgIC5yZXN1bHQtZGl2aWRlciB7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXRvcDogMXB4IGRhc2hlZDtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFFQSxDQUFBO0FBQ0ksV0FBQTtBQUNBLFNBQUE7O0FBRUEsQ0FKSix1QkFJSSxDQUFBO0FBQ0ksV0FBQTtBQUNBLFFBQUE7O0FBRUEsQ0FSUix1QkFRUSxDQUpKLHVCQUlJLENBQUE7QUFDSSxTQVhVOztBQWFWLENBWFosdUJBV1ksQ0FQUix1QkFPUSxDQUhKLGFBR0ksQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBO0FBQ0EsbUJBQUE7QUFDQSxTQWhCRztBQWlCSCxVQWpCRztBQWtCSCxpQkFsQkc7QUFtQkgsb0JBQUE7O0FBR0osQ0FyQlosdUJBcUJZLENBakJSLHVCQWlCUSxDQWJKLGFBYUksQ0FBQTtBQUNJLFdBQUE7QUFDQSxrQkFBQTtBQUNBLGVBQUE7QUFDQSxlQUFBO0FBQ0EsZ0JBQUE7QUFDQSxPQUFBOztBQUlSLENBL0JSLHVCQStCUSxDQTNCSix1QkEyQkksQ0FBQTtBQUNJLFNBQUE7QUFDQSxjQUFBLElBQUE7QUFDQSxjQUFBOztBQUdKLENBckNSLHVCQXFDUSxDQWpDSixzQkFpQ0k7QUFDSSxRQUFBOztBQUdKLENBekNSLHVCQXlDUSxDQXJDSixzQkFxQ0k7QUFDSSxRQUFBOztBQUNBLENBM0NaLHVCQTJDWSxDQXZDUixzQkF1Q1EsWUFBQSxDQVpKO0FBYVEsY0FBQSxJQUFBOztBQUtKLENBakRaLHVCQWlEWSxDQTdDUixzQkE2Q1EsQ0FBQSx5QkFBQSxDQWxCSjtBQW1CUSxjQUFBLElBQUE7QUFDQSxTQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(ResultHistoryComponent, { className: "ResultHistoryComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/result/result.module.ts
import { NgModule as NgModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { BarChartModule as BarChartModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-charts.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisResultModule;
var init_result_module = __esm({
  "src/main/webapp/app/exercises/shared/result/result.module.ts"() {
    init_shared_module();
    init_result_history_component();
    init_programming_exercise_actions_module();
    init_shared_component_module();
    init_submission_result_status_module();
    init_feedback_module();
    ArtemisResultModule = class _ArtemisResultModule {
      static \u0275fac = function ArtemisResultModule_Factory(t) {
        return new (t || _ArtemisResultModule)();
      };
      static \u0275mod = i06.\u0275\u0275defineNgModule({ type: _ArtemisResultModule });
      static \u0275inj = i06.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, ArtemisProgrammingExerciseActionsModule, ArtemisFeedbackModule, ArtemisSharedComponentModule, SubmissionResultStatusModule, BarChartModule2] });
    };
  }
});

export {
  MAX_RESULT_HISTORY_LENGTH,
  ResultHistoryComponent,
  init_result_history_component,
  StandaloneFeedbackComponent,
  init_standalone_feedback_component,
  FeedbackSuggestionBadgeComponent,
  init_feedback_suggestion_badge_component,
  FeedbackSuggestionsPendingConfirmationDialogComponent,
  init_feedback_suggestions_pending_confirmation_dialog_component,
  ArtemisFeedbackModule,
  init_feedback_module,
  ArtemisResultModule,
  init_result_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9mZWVkYmFjay9zdGFuZGFsb25lLWZlZWRiYWNrL3N0YW5kYWxvbmUtZmVlZGJhY2suY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2ZlZWRiYWNrL3N0YW5kYWxvbmUtZmVlZGJhY2svc3RhbmRhbG9uZS1mZWVkYmFjay5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9mZWVkYmFjay9mZWVkYmFjay1zdWdnZXN0aW9uLWJhZGdlL2ZlZWRiYWNrLXN1Z2dlc3Rpb24tYmFkZ2UuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2ZlZWRiYWNrL2ZlZWRiYWNrLXN1Z2dlc3Rpb24tYmFkZ2UvZmVlZGJhY2stc3VnZ2VzdGlvbi1iYWRnZS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9mZWVkYmFjay9mZWVkYmFjay1zdWdnZXN0aW9ucy1wZW5kaW5nLWNvbmZpcm1hdGlvbi1kaWFsb2cvZmVlZGJhY2stc3VnZ2VzdGlvbnMtcGVuZGluZy1jb25maXJtYXRpb24tZGlhbG9nLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9mZWVkYmFjay9mZWVkYmFjay1zdWdnZXN0aW9ucy1wZW5kaW5nLWNvbmZpcm1hdGlvbi1kaWFsb2cvZmVlZGJhY2stc3VnZ2VzdGlvbnMtcGVuZGluZy1jb25maXJtYXRpb24tZGlhbG9nLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2ZlZWRiYWNrL2ZlZWRiYWNrLm1vZHVsZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvb3ZlcnZpZXcvcmVzdWx0LWhpc3RvcnkvcmVzdWx0LWhpc3RvcnkuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9yZXN1bHQtaGlzdG9yeS9yZXN1bHQtaGlzdG9yeS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9yZXN1bHQvcmVzdWx0Lm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgT3B0aW9uYWwgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEV4ZXJjaXNlLCBFeGVyY2lzZVR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgUmVzdWx0IH0gZnJvbSAnYXBwL2VudGl0aWVzL3Jlc3VsdC5tb2RlbCc7XG5pbXBvcnQgZGF5anMgZnJvbSAnZGF5anMvZXNtJztcbmltcG9ydCB7IEV4ZXJjaXNlU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlL2V4ZXJjaXNlLnNlcnZpY2UnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgRXhlcmNpc2VDYWNoZVNlcnZpY2UgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS9leGVyY2lzZS1jYWNoZS5zZXJ2aWNlJztcbmltcG9ydCB7IFJlc3VsdFRlbXBsYXRlU3RhdHVzLCBldmFsdWF0ZVRlbXBsYXRlU3RhdHVzIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvcmVzdWx0L3Jlc3VsdC51dGlscyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXN0YW5kYWxvbmUtZmVlZGJhY2snLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9zdGFuZGFsb25lLWZlZWRiYWNrLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi8uLi9mZWVkYmFjay5zY3NzJywgJ3N0YW5kYWxvbmUtZmVlZGJhY2suc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBTdGFuZGFsb25lRmVlZGJhY2tDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIGV4ZXJjaXNlPzogRXhlcmNpc2U7XG4gICAgcmVzdWx0PzogUmVzdWx0O1xuXG4gICAgc2hvd01pc3NpbmdBdXRvbWF0aWNGZWVkYmFja0luZm9ybWF0aW9uID0gZmFsc2U7XG4gICAgbWVzc2FnZUtleT86IHN0cmluZztcbiAgICBleGVyY2lzZVR5cGU/OiBFeGVyY2lzZVR5cGU7XG5cbiAgICBsYXRlc3REdWVEYXRlPzogZGF5anMuRGF5anM7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHVibGljIHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSxcbiAgICAgICAgcHJpdmF0ZSBleGVyY2lzZVNlcnZpY2U6IEV4ZXJjaXNlU2VydmljZSxcbiAgICAgICAgQE9wdGlvbmFsKCkgcHJpdmF0ZSBleGVyY2lzZUNhY2hlU2VydmljZTogRXhlcmNpc2VDYWNoZVNlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMucm91dGUucGFyYW1zLnN1YnNjcmliZSgocGFyYW1zKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBleGVyY2lzZUlkID0gcGFyc2VJbnQocGFyYW1zWydleGVyY2lzZUlkJ10sIDEwKTtcbiAgICAgICAgICAgIGNvbnN0IHBhcnRpY2lwYXRpb25JZCA9IHBhcnNlSW50KHBhcmFtc1sncGFydGljaXBhdGlvbklkJ10sIDEwKTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdElkID0gcGFyc2VJbnQocGFyYW1zWydyZXN1bHRJZCddLCAxMCk7XG5cbiAgICAgICAgICAgIHRoaXMuZXhlcmNpc2VTZXJ2aWNlLmdldEV4ZXJjaXNlRGV0YWlscyhleGVyY2lzZUlkKS5zdWJzY3JpYmUoKGV4ZXJjaXNlUmVzcG9uc2U6IEh0dHBSZXNwb25zZTxFeGVyY2lzZT4pID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmV4ZXJjaXNlID0gZXhlcmNpc2VSZXNwb25zZS5ib2R5ITtcbiAgICAgICAgICAgICAgICBjb25zdCBwYXJ0aWNpcGF0aW9uID0gdGhpcy5leGVyY2lzZT8uc3R1ZGVudFBhcnRpY2lwYXRpb25zPy5maW5kKChwYXJ0aWNpcGF0aW9uKSA9PiBwYXJ0aWNpcGF0aW9uLmlkID09PSBwYXJ0aWNpcGF0aW9uSWQpO1xuICAgICAgICAgICAgICAgIGlmIChwYXJ0aWNpcGF0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIHBhcnRpY2lwYXRpb24uZXhlcmNpc2UgPSB0aGlzLmV4ZXJjaXNlO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGNvbnN0IHJlbGV2YW50UmVzdWx0ID0gcGFydGljaXBhdGlvbj8ucmVzdWx0cz8uZmluZCgocmVzdWx0KSA9PiByZXN1bHQuaWQgPT0gcmVzdWx0SWQpO1xuICAgICAgICAgICAgICAgIGlmIChyZWxldmFudFJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICByZWxldmFudFJlc3VsdC5wYXJ0aWNpcGF0aW9uID0gcGFydGljaXBhdGlvbjtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB0aGlzLnJlc3VsdCA9IHJlbGV2YW50UmVzdWx0O1xuXG4gICAgICAgICAgICAgICAgLy8gV2Ugc2V0IGlzQnVpbGRpbmcgaGVyZSB0byBmYWxzZS4gSXQgaXMgdGhlIG1vYmlsZSBhcHBsaWNhdGlvbnMgcmVzcG9uc2liaWxpdHkgdG8gbWFrZSB0aGUgdXNlciBhd2FyZSBpZiBhIHBhcnRpY2lwYXRpb24gaXMgYmVpbmcgYnVpbHRcbiAgICAgICAgICAgICAgICBjb25zdCB0ZW1wbGF0ZVN0YXR1cyA9IGV2YWx1YXRlVGVtcGxhdGVTdGF0dXMoZXhlcmNpc2VSZXNwb25zZS5ib2R5ISwgcGFydGljaXBhdGlvbiwgcmVsZXZhbnRSZXN1bHQsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICBpZiAodGVtcGxhdGVTdGF0dXMgPT0gUmVzdWx0VGVtcGxhdGVTdGF0dXMuTUlTU0lORykge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm1lc3NhZ2VLZXkgPSAnYXJ0ZW1pc0FwcC5yZXN1bHQubm90TGF0ZXN0U3VibWlzc2lvbic7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tZXNzYWdlS2V5ID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHRoaXMuc2V0dXAoKTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAodGhpcy5leGVyY2lzZUNhY2hlU2VydmljZSA/PyB0aGlzLmV4ZXJjaXNlU2VydmljZSkuZ2V0TGF0ZXN0RHVlRGF0ZShleGVyY2lzZUlkKS5zdWJzY3JpYmUoKGxhdGVzdER1ZURhdGUpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmxhdGVzdER1ZURhdGUgPSBsYXRlc3REdWVEYXRlO1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0dXAoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHNldHVwKCkge1xuICAgICAgICBpZiAodGhpcy5leGVyY2lzZSAmJiB0aGlzLnJlc3VsdCkge1xuICAgICAgICAgICAgdGhpcy5leGVyY2lzZVR5cGUgPSB0aGlzLmV4ZXJjaXNlLnR5cGUhO1xuXG4gICAgICAgICAgICBpZiAodGhpcy5sYXRlc3REdWVEYXRlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zaG93TWlzc2luZ0F1dG9tYXRpY0ZlZWRiYWNrSW5mb3JtYXRpb24gPSBkYXlqcygpLmlzQmVmb3JlKHRoaXMubGF0ZXN0RHVlRGF0ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJAaWYgKGV4ZXJjaXNlICYmIHJlc3VsdCAmJiBleGVyY2lzZVR5cGUpIHtcbiAgICA8amhpLXJlc3VsdC1kZXRhaWxcbiAgICAgICAgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCJcbiAgICAgICAgW3Jlc3VsdF09XCJyZXN1bHRcIlxuICAgICAgICBbc2hvd1Njb3JlQ2hhcnRdPVwidHJ1ZVwiXG4gICAgICAgIFtleGVyY2lzZVR5cGVdPVwiZXhlcmNpc2VUeXBlXCJcbiAgICAgICAgW2xhdGVzdER1ZURhdGVdPVwibGF0ZXN0RHVlRGF0ZVwiXG4gICAgICAgIFttZXNzYWdlS2V5XT1cIm1lc3NhZ2VLZXlcIlxuICAgICAgICBbc2hvd01pc3NpbmdBdXRvbWF0aWNGZWVkYmFja0luZm9ybWF0aW9uXT1cInNob3dNaXNzaW5nQXV0b21hdGljRmVlZGJhY2tJbmZvcm1hdGlvblwiXG4gICAgICAgIGNsYXNzPVwibW9kYWwtcGFkZGluZ1wiXG4gICAgLz5cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGZhTGlnaHRidWxiIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IFRyYW5zbGF0ZVNlcnZpY2UgfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcbmltcG9ydCB7IEZlZWRiYWNrLCBGZWVkYmFja1N1Z2dlc3Rpb25UeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2ZlZWRiYWNrLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktZmVlZGJhY2stc3VnZ2VzdGlvbi1iYWRnZScsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2ZlZWRiYWNrLXN1Z2dlc3Rpb24tYmFkZ2UuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL2ZlZWRiYWNrLXN1Z2dlc3Rpb24tYmFkZ2UuY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgRmVlZGJhY2tTdWdnZXN0aW9uQmFkZ2VDb21wb25lbnQge1xuICAgIEBJbnB1dCgpXG4gICAgZmVlZGJhY2s6IEZlZWRiYWNrO1xuXG4gICAgQElucHV0KClcbiAgICB1c2VEZWZhdWx0VGV4dCA9IGZhbHNlO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUxpZ2h0YnVsYiA9IGZhTGlnaHRidWxiO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSB0cmFuc2xhdGVTZXJ2aWNlOiBUcmFuc2xhdGVTZXJ2aWNlKSB7fVxuXG4gICAgZ2V0IHRleHQoKTogc3RyaW5nIHtcbiAgICAgICAgY29uc3QgZmVlZGJhY2tTdWdnZXN0aW9uVHlwZSA9IEZlZWRiYWNrLmdldEZlZWRiYWNrU3VnZ2VzdGlvblR5cGUodGhpcy5mZWVkYmFjayk7XG4gICAgICAgIGlmIChmZWVkYmFja1N1Z2dlc3Rpb25UeXBlID09PSBGZWVkYmFja1N1Z2dlc3Rpb25UeXBlLkFEQVBURUQpIHtcbiAgICAgICAgICAgIC8vIEFsd2F5cyBtYXJrIGFkYXB0ZWQgZmVlZGJhY2sgc3VnZ2VzdGlvbnMgYXMgc3VjaCwgZXZlbiB3aXRoIHRoZSBkZWZhdWx0IGJhZGdlIGluIHRleHQgbW9kZVxuICAgICAgICAgICAgcmV0dXJuICdhcnRlbWlzQXBwLmFzc2Vzc21lbnQuc3VnZ2VzdGlvbi5hZGFwdGVkJztcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy51c2VEZWZhdWx0VGV4dCkge1xuICAgICAgICAgICAgcmV0dXJuICdhcnRlbWlzQXBwLmFzc2Vzc21lbnQuc3VnZ2VzdGlvbi5kZWZhdWx0JztcbiAgICAgICAgfVxuICAgICAgICBzd2l0Y2ggKGZlZWRiYWNrU3VnZ2VzdGlvblR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgRmVlZGJhY2tTdWdnZXN0aW9uVHlwZS5TVUdHRVNURUQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuICdhcnRlbWlzQXBwLmFzc2Vzc21lbnQuc3VnZ2VzdGlvbi5zdWdnZXN0ZWQnO1xuICAgICAgICAgICAgY2FzZSBGZWVkYmFja1N1Z2dlc3Rpb25UeXBlLkFDQ0VQVEVEOlxuICAgICAgICAgICAgICAgIHJldHVybiAnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LnN1Z2dlc3Rpb24uYWNjZXB0ZWQnO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBnZXQgdG9vbHRpcCgpOiBzdHJpbmcge1xuICAgICAgICBpZiAodGhpcy51c2VEZWZhdWx0VGV4dCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KCdhcnRlbWlzQXBwLmFzc2Vzc21lbnQuc3VnZ2VzdGlvblRpdGxlLmRlZmF1bHQnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmZWVkYmFja1N1Z2dlc3Rpb25UeXBlID0gRmVlZGJhY2suZ2V0RmVlZGJhY2tTdWdnZXN0aW9uVHlwZSh0aGlzLmZlZWRiYWNrKTtcbiAgICAgICAgc3dpdGNoIChmZWVkYmFja1N1Z2dlc3Rpb25UeXBlKSB7XG4gICAgICAgICAgICBjYXNlIEZlZWRiYWNrU3VnZ2VzdGlvblR5cGUuU1VHR0VTVEVEOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LnN1Z2dlc3Rpb25UaXRsZS5zdWdnZXN0ZWQnKTtcbiAgICAgICAgICAgIGNhc2UgRmVlZGJhY2tTdWdnZXN0aW9uVHlwZS5BQ0NFUFRFRDpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQoJ2FydGVtaXNBcHAuYXNzZXNzbWVudC5zdWdnZXN0aW9uVGl0bGUuYWNjZXB0ZWQnKTtcbiAgICAgICAgICAgIGNhc2UgRmVlZGJhY2tTdWdnZXN0aW9uVHlwZS5BREFQVEVEOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuaW5zdGFudCgnYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LnN1Z2dlc3Rpb25UaXRsZS5hZGFwdGVkJyk7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHJldHVybiAnJztcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsIjxzcGFuIGNsYXNzPVwiYmFkZ2Ugc3VnZ2VzdGlvbi1iYWRnZVwiIFtuZ2JUb29sdGlwXT1cInRvb2x0aXBcIj5cbiAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUxpZ2h0YnVsYlwiPjwvZmEtaWNvbj5cbiAgICA8c3BhbiBbamhpVHJhbnNsYXRlXT1cInRleHRcIj5TdWdnZXN0aW9uPC9zcGFuPlxuPC9zcGFuPlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBmYUJhbiwgZmFUaW1lcyB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBOZ2JBY3RpdmVNb2RhbCB9IGZyb20gJ0BuZy1ib290c3RyYXAvbmctYm9vdHN0cmFwJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktZmVlZGJhY2stc3VnZ2VzdGlvbnMtcGVuZGluZy1jb25maXJtYXRpb24tZGlhbG9nJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vZmVlZGJhY2stc3VnZ2VzdGlvbnMtcGVuZGluZy1jb25maXJtYXRpb24tZGlhbG9nLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgRmVlZGJhY2tTdWdnZXN0aW9uc1BlbmRpbmdDb25maXJtYXRpb25EaWFsb2dDb21wb25lbnQge1xuICAgIC8vIEljb25zXG4gICAgZmFCYW4gPSBmYUJhbjtcbiAgICBmYVRpbWVzID0gZmFUaW1lcztcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgYWN0aXZlTW9kYWw6IE5nYkFjdGl2ZU1vZGFsKSB7fVxuXG4gICAgLyoqXG4gICAgICogQ2xvc2UgdGhlIGNvbmZpcm1hdGlvbiBkaWFsb2dcbiAgICAgKi9cbiAgICBjbG9zZShjb25maXJtOiBib29sZWFuKTogdm9pZCB7XG4gICAgICAgIHRoaXMuYWN0aXZlTW9kYWwuY2xvc2UoY29uZmlybSk7XG4gICAgfVxufVxuIiwiPGZvcm0+XG4gICAgPGRpdiBjbGFzcz1cIm1vZGFsLWhlYWRlclwiPlxuICAgICAgICA8aDQgY2xhc3M9XCJtb2RhbC10aXRsZVwiPlxuICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50LnN1Z2dlc3Rpb25QZW5kaW5nRGlhbG9nLnRpdGxlXCI+UGVuZGluZyBGZWVkYmFjayBTdWdnZXN0aW9uczwvc3Bhbj5cbiAgICAgICAgPC9oND5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tY2xvc2VcIiBkYXRhLWRpc21pc3M9XCJtb2RhbFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIChjbGljayk9XCJjbG9zZShmYWxzZSlcIj48L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtYm9keVwiPlxuICAgICAgICA8cCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnQuc3VnZ2VzdGlvblBlbmRpbmdEaWFsb2cuZGVzY3JpcHRpb25cIj5cbiAgICAgICAgICAgIFRoZXJlIGFyZSBwZW5kaW5nIGZlZWRiYWNrIHN1Z2dlc3Rpb25zIGF2YWlsYWJsZS4gVGhleSB3aWxsIGJlIGRpc2NhcmRlZC4gRG8geW91IHJlYWxseSB3YW50IHRvIHN1Ym1pdD9cbiAgICAgICAgPC9wPlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1mb290ZXJcIj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeVwiIGRhdGEtZGlzbWlzcz1cIm1vZGFsXCIgKGNsaWNrKT1cImNsb3NlKGZhbHNlKVwiPlxuICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFCYW5cIj48L2ZhLWljb24+Jm5ic3A7PHNwYW4gamhpVHJhbnNsYXRlPVwiZW50aXR5LmFjdGlvbi5jYW5jZWxcIj5DYW5jZWw8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBuZ0NsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5XCIgKGNsaWNrKT1cImNsb3NlKHRydWUpXCI+XG4gICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmFzc2Vzc21lbnQuc3VnZ2VzdGlvblBlbmRpbmdEaWFsb2cuZGlzY2FyZEFuZFN1Ym1pdFwiPkRpc2NhcmQgc3VnZ2VzdGlvbnMgJiBzdWJtaXQ8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuPC9mb3JtPlxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1Byb2dyYW1taW5nRXhlcmNpc2VBY3Rpb25zTW9kdWxlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9wcm9ncmFtbWluZy9zaGFyZWQvYWN0aW9ucy9wcm9ncmFtbWluZy1leGVyY2lzZS1hY3Rpb25zLm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL3NoYXJlZC1jb21wb25lbnQubW9kdWxlJztcbmltcG9ydCB7IEZlZWRiYWNrQ29sbGFwc2VDb21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9mZWVkYmFjay9jb2xsYXBzZS9mZWVkYmFjay1jb2xsYXBzZS5jb21wb25lbnQnO1xuaW1wb3J0IHsgQmFyQ2hhcnRNb2R1bGUgfSBmcm9tICdAc3dpbWxhbmUvbmd4LWNoYXJ0cyc7XG5pbXBvcnQgeyBGZWVkYmFja05vZGVDb21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9mZWVkYmFjay9ub2RlL2ZlZWRiYWNrLW5vZGUuY29tcG9uZW50JztcbmltcG9ydCB7IEZlZWRiYWNrQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZmVlZGJhY2svZmVlZGJhY2suY29tcG9uZW50JztcbmltcG9ydCB7IEZlZWRiYWNrVGV4dENvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL2ZlZWRiYWNrL3RleHQvZmVlZGJhY2stdGV4dC5jb21wb25lbnQnO1xuaW1wb3J0IHsgU3RhbmRhbG9uZUZlZWRiYWNrQ29tcG9uZW50IH0gZnJvbSAnLi9zdGFuZGFsb25lLWZlZWRiYWNrL3N0YW5kYWxvbmUtZmVlZGJhY2suY29tcG9uZW50JztcbmltcG9ydCB7IEZlZWRiYWNrU3VnZ2VzdGlvbkJhZGdlQ29tcG9uZW50IH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZmVlZGJhY2svZmVlZGJhY2stc3VnZ2VzdGlvbi1iYWRnZS9mZWVkYmFjay1zdWdnZXN0aW9uLWJhZGdlLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBGZWVkYmFja1N1Z2dlc3Rpb25zUGVuZGluZ0NvbmZpcm1hdGlvbkRpYWxvZ0NvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL2ZlZWRiYWNrL2ZlZWRiYWNrLXN1Z2dlc3Rpb25zLXBlbmRpbmctY29uZmlybWF0aW9uLWRpYWxvZy9mZWVkYmFjay1zdWdnZXN0aW9ucy1wZW5kaW5nLWNvbmZpcm1hdGlvbi1kaWFsb2cuY29tcG9uZW50JztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZSwgQXJ0ZW1pc1Byb2dyYW1taW5nRXhlcmNpc2VBY3Rpb25zTW9kdWxlLCBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlLCBCYXJDaGFydE1vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbXG4gICAgICAgIEZlZWRiYWNrQ29sbGFwc2VDb21wb25lbnQsXG4gICAgICAgIEZlZWRiYWNrTm9kZUNvbXBvbmVudCxcbiAgICAgICAgRmVlZGJhY2tDb21wb25lbnQsXG4gICAgICAgIEZlZWRiYWNrVGV4dENvbXBvbmVudCxcbiAgICAgICAgU3RhbmRhbG9uZUZlZWRiYWNrQ29tcG9uZW50LFxuICAgICAgICBGZWVkYmFja1N1Z2dlc3Rpb25CYWRnZUNvbXBvbmVudCxcbiAgICAgICAgRmVlZGJhY2tTdWdnZXN0aW9uc1BlbmRpbmdDb25maXJtYXRpb25EaWFsb2dDb21wb25lbnQsXG4gICAgXSxcbiAgICBleHBvcnRzOiBbRmVlZGJhY2tDb21wb25lbnQsIEZlZWRiYWNrU3VnZ2VzdGlvbkJhZGdlQ29tcG9uZW50LCBGZWVkYmFja1N1Z2dlc3Rpb25zUGVuZGluZ0NvbmZpcm1hdGlvbkRpYWxvZ0NvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNGZWVkYmFja01vZHVsZSB7fVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25DaGFuZ2VzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBSZXN1bHQgfSBmcm9tICdhcHAvZW50aXRpZXMvcmVzdWx0Lm1vZGVsJztcbmltcG9ydCB7IEV4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IE1pc3NpbmdSZXN1bHRJbmZvcm1hdGlvbiwgZXZhbHVhdGVUZW1wbGF0ZVN0YXR1cywgZ2V0UmVzdWx0SWNvbkNsYXNzLCBnZXRUZXh0Q29sb3JDbGFzcyB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3Jlc3VsdC9yZXN1bHQudXRpbHMnO1xuXG5leHBvcnQgY29uc3QgTUFYX1JFU1VMVF9ISVNUT1JZX0xFTkdUSCA9IDU7XG5cbi8vIE1vZGFsIC0+IFJlc3VsdCBkZXRhaWxzIHZpZXdcbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXJlc3VsdC1oaXN0b3J5JyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vcmVzdWx0LWhpc3RvcnkuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL3Jlc3VsdC1oaXN0b3J5LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgUmVzdWx0SGlzdG9yeUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gICAgcmVhZG9ubHkgZ2V0VGV4dENvbG9yQ2xhc3MgPSBnZXRUZXh0Q29sb3JDbGFzcztcbiAgICByZWFkb25seSBnZXRSZXN1bHRJY29uQ2xhc3MgPSBnZXRSZXN1bHRJY29uQ2xhc3M7XG4gICAgcmVhZG9ubHkgZXZhbHVhdGVUZW1wbGF0ZVN0YXR1cyA9IGV2YWx1YXRlVGVtcGxhdGVTdGF0dXM7XG4gICAgcmVhZG9ubHkgTWlzc2luZ1Jlc3VsdEluZm8gPSBNaXNzaW5nUmVzdWx0SW5mb3JtYXRpb247XG5cbiAgICBASW5wdXQoKSByZXN1bHRzOiBSZXN1bHRbXTtcbiAgICBASW5wdXQoKSBleGVyY2lzZTogRXhlcmNpc2U7XG5cbiAgICBzaG93UHJldmlvdXNEaXZpZGVyID0gZmFsc2U7XG4gICAgZGlzcGxheWVkUmVzdWx0czogUmVzdWx0W107XG4gICAgbW92ZWRMYXN0UmF0ZWRSZXN1bHQ6IGJvb2xlYW47XG5cbiAgICBuZ09uQ2hhbmdlcygpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5zaG93UHJldmlvdXNEaXZpZGVyID0gdGhpcy5yZXN1bHRzLmxlbmd0aCA+IE1BWF9SRVNVTFRfSElTVE9SWV9MRU5HVEg7XG5cbiAgICAgICAgaWYgKHRoaXMucmVzdWx0cy5sZW5ndGggPD0gTUFYX1JFU1VMVF9ISVNUT1JZX0xFTkdUSCkge1xuICAgICAgICAgICAgdGhpcy5kaXNwbGF5ZWRSZXN1bHRzID0gdGhpcy5yZXN1bHRzO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5kaXNwbGF5ZWRSZXN1bHRzID0gdGhpcy5yZXN1bHRzLnNsaWNlKHRoaXMucmVzdWx0cy5sZW5ndGggLSBNQVhfUkVTVUxUX0hJU1RPUllfTEVOR1RIKTtcblxuICAgICAgICAgICAgY29uc3QgbGFzdFJhdGVkUmVzdWx0ID0gdGhpcy5yZXN1bHRzLmZpbHRlcigocmVzdWx0KSA9PiByZXN1bHQucmF0ZWQpLmxhc3QoKTtcbiAgICAgICAgICAgIGlmICghdGhpcy5kaXNwbGF5ZWRSZXN1bHRzLmZpcnN0KCk/LnJhdGVkICYmIGxhc3RSYXRlZFJlc3VsdCkge1xuICAgICAgICAgICAgICAgIHRoaXMuZGlzcGxheWVkUmVzdWx0c1swXSA9IGxhc3RSYXRlZFJlc3VsdDtcbiAgICAgICAgICAgICAgICB0aGlzLm1vdmVkTGFzdFJhdGVkUmVzdWx0ID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJyZXN1bHQtaGlzdG9yeS13cmFwcGVyXCI+XG4gICAgPGRpdiBjbGFzcz1cInJlc3VsdC1oaXN0b3J5LWVsZW1lbnRcIiBbY2xhc3MucHJldmlvdXMtaGlzdG9yeS1lbGVtZW50XT1cInNob3dQcmV2aW91c0RpdmlkZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInJlc3VsdC1kaXZpZGVyXCI+PC9kaXY+XG4gICAgPC9kaXY+XG4gICAgQGZvciAocmVzdWx0IG9mIGRpc3BsYXllZFJlc3VsdHM7IHRyYWNrIHJlc3VsdDsgbGV0IGkgPSAkaW5kZXgpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cInJlc3VsdC1oaXN0b3J5LWVsZW1lbnRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZXN1bHQtc2NvcmVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicmVzdWx0LXNjb3JlLWljb25cIiBbbmdDbGFzc109XCJnZXRUZXh0Q29sb3JDbGFzcyhyZXN1bHQsIGV2YWx1YXRlVGVtcGxhdGVTdGF0dXMoZXhlcmNpc2UsIHJlc3VsdC5wYXJ0aWNpcGF0aW9uLCByZXN1bHQsIGZhbHNlLCBNaXNzaW5nUmVzdWx0SW5mby5OT05FKSlcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZ2V0UmVzdWx0SWNvbkNsYXNzKHJlc3VsdCwgZXZhbHVhdGVUZW1wbGF0ZVN0YXR1cyhleGVyY2lzZSwgcmVzdWx0LnBhcnRpY2lwYXRpb24sIHJlc3VsdCwgZmFsc2UsIE1pc3NpbmdSZXN1bHRJbmZvLk5PTkUpKVwiIHNpemU9XCJ4bFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8amhpLXJlc3VsdFxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInJlc3VsdC1zY29yZS1pbmZvIHRleHQtY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCJcbiAgICAgICAgICAgICAgICAgICAgW3Jlc3VsdF09XCJyZXN1bHRcIlxuICAgICAgICAgICAgICAgICAgICBbcGFydGljaXBhdGlvbl09XCJyZXN1bHQucGFydGljaXBhdGlvbiFcIlxuICAgICAgICAgICAgICAgICAgICBbc2hvd1VuZ3JhZGVkUmVzdWx0c109XCJ0cnVlXCJcbiAgICAgICAgICAgICAgICAgICAgW3Nob3dCYWRnZV09XCJ0cnVlXCJcbiAgICAgICAgICAgICAgICAgICAgW3Nob3dJY29uXT1cImZhbHNlXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPC9qaGktcmVzdWx0PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicmVzdWx0LWRpdmlkZXJcIiBbbmdTdHlsZV09XCJpID09PSAwICYmIG1vdmVkTGFzdFJhdGVkUmVzdWx0ID8geyAnYm9yZGVyLXRvcCc6ICcxcHggZGFzaGVkJyB9IDoge31cIj48L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuPC9kaXY+XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBSZXN1bHRIaXN0b3J5Q29tcG9uZW50IH0gZnJvbSAnYXBwL292ZXJ2aWV3L3Jlc3VsdC1oaXN0b3J5L3Jlc3VsdC1oaXN0b3J5LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBcnRlbWlzUHJvZ3JhbW1pbmdFeGVyY2lzZUFjdGlvbnNNb2R1bGUgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3Byb2dyYW1taW5nL3NoYXJlZC9hY3Rpb25zL3Byb2dyYW1taW5nLWV4ZXJjaXNlLWFjdGlvbnMubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRDb21wb25lbnRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL2NvbXBvbmVudHMvc2hhcmVkLWNvbXBvbmVudC5tb2R1bGUnO1xuaW1wb3J0IHsgU3VibWlzc2lvblJlc3VsdFN0YXR1c01vZHVsZSB9IGZyb20gJ2FwcC9vdmVydmlldy9zdWJtaXNzaW9uLXJlc3VsdC1zdGF0dXMubW9kdWxlJztcbmltcG9ydCB7IEJhckNoYXJ0TW9kdWxlIH0gZnJvbSAnQHN3aW1sYW5lL25neC1jaGFydHMnO1xuaW1wb3J0IHsgQXJ0ZW1pc0ZlZWRiYWNrTW9kdWxlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZmVlZGJhY2svZmVlZGJhY2subW9kdWxlJztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZSwgQXJ0ZW1pc1Byb2dyYW1taW5nRXhlcmNpc2VBY3Rpb25zTW9kdWxlLCBBcnRlbWlzRmVlZGJhY2tNb2R1bGUsIEFydGVtaXNTaGFyZWRDb21wb25lbnRNb2R1bGUsIFN1Ym1pc3Npb25SZXN1bHRTdGF0dXNNb2R1bGUsIEJhckNoYXJ0TW9kdWxlXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtSZXN1bHRIaXN0b3J5Q29tcG9uZW50XSxcbiAgICBleHBvcnRzOiBbUmVzdWx0SGlzdG9yeUNvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNSZXN1bHRNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsV0FBbUIsZ0JBQWdCO0FBRzVDLE9BQU8sV0FBVztBQUVsQixTQUFTLHNCQUFzQjs7Ozs7QUNKM0IsSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEscUJBQUEsQ0FBQTtBQVVKLElBQUEsb0JBQUEsR0FBQSxJQUFBOzs7O0FBVFEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxZQUFBLE9BQUEsUUFBQSxFQUFxQixVQUFBLE9BQUEsTUFBQSxFQUFBLGtCQUFBLElBQUEsRUFBQSxnQkFBQSxPQUFBLFlBQUEsRUFBQSxpQkFBQSxPQUFBLGFBQUEsRUFBQSxjQUFBLE9BQUEsVUFBQSxFQUFBLDJDQUFBLE9BQUEsdUNBQUE7OztBREY3QixJQWVhO0FBZmI7O0FBSUE7QUFHQTtBQUNBOzs7O0FBT00sSUFBTyw4QkFBUCxNQUFPLDZCQUEyQjtNQVd6QjtNQUNDO01BQ1k7TUFaeEI7TUFDQTtNQUVBLDBDQUEwQztNQUMxQztNQUNBO01BRUE7TUFFQSxZQUNXLE9BQ0MsaUJBQ1ksc0JBQTBDO0FBRnZELGFBQUEsUUFBQTtBQUNDLGFBQUEsa0JBQUE7QUFDWSxhQUFBLHVCQUFBO01BQ3JCO01BRUgsV0FBUTtBQUNKLGFBQUssTUFBTSxPQUFPLFVBQVUsQ0FBQyxXQUFVO0FBQ25DLGdCQUFNLGFBQWEsU0FBUyxPQUFPLFlBQVksR0FBRyxFQUFFO0FBQ3BELGdCQUFNLGtCQUFrQixTQUFTLE9BQU8saUJBQWlCLEdBQUcsRUFBRTtBQUM5RCxnQkFBTSxXQUFXLFNBQVMsT0FBTyxVQUFVLEdBQUcsRUFBRTtBQUVoRCxlQUFLLGdCQUFnQixtQkFBbUIsVUFBVSxFQUFFLFVBQVUsQ0FBQyxxQkFBNEM7QUFDdkcsaUJBQUssV0FBVyxpQkFBaUI7QUFDakMsa0JBQU0sZ0JBQWdCLEtBQUssVUFBVSx1QkFBdUIsS0FBSyxDQUFDQSxtQkFBa0JBLGVBQWMsT0FBTyxlQUFlO0FBQ3hILGdCQUFJLGVBQWU7QUFDZiw0QkFBYyxXQUFXLEtBQUs7O0FBR2xDLGtCQUFNLGlCQUFpQixlQUFlLFNBQVMsS0FBSyxDQUFDLFdBQVcsT0FBTyxNQUFNLFFBQVE7QUFDckYsZ0JBQUksZ0JBQWdCO0FBQ2hCLDZCQUFlLGdCQUFnQjs7QUFHbkMsaUJBQUssU0FBUztBQUdkLGtCQUFNLGlCQUFpQix1QkFBdUIsaUJBQWlCLE1BQU8sZUFBZSxnQkFBZ0IsS0FBSztBQUMxRyxnQkFBSSxrQkFBa0IscUJBQXFCLFNBQVM7QUFDaEQsbUJBQUssYUFBYTttQkFDZjtBQUNILG1CQUFLLGFBQWE7O0FBR3RCLGlCQUFLLE1BQUs7VUFDZCxDQUFDO0FBRUQsV0FBQyxLQUFLLHdCQUF3QixLQUFLLGlCQUFpQixpQkFBaUIsVUFBVSxFQUFFLFVBQVUsQ0FBQyxrQkFBaUI7QUFDekcsaUJBQUssZ0JBQWdCO0FBQ3JCLGlCQUFLLE1BQUs7VUFDZCxDQUFDO1FBQ0wsQ0FBQztNQUNMO01BRVEsUUFBSztBQUNULFlBQUksS0FBSyxZQUFZLEtBQUssUUFBUTtBQUM5QixlQUFLLGVBQWUsS0FBSyxTQUFTO0FBRWxDLGNBQUksS0FBSyxlQUFlO0FBQ3BCLGlCQUFLLDBDQUEwQyxNQUFLLEVBQUcsU0FBUyxLQUFLLGFBQWE7OztNQUc5Rjs7eUJBOURTLDhCQUEyQiwrQkFBQSxpQkFBQSxHQUFBLCtCQUFBLGVBQUEsR0FBQSwrQkFBQSxzQkFBQSxDQUFBLENBQUE7TUFBQTtnRUFBM0IsOEJBQTJCLFdBQUEsQ0FBQSxDQUFBLHlCQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxZQUFBLFVBQUEsa0JBQUEsZ0JBQUEsaUJBQUEsY0FBQSx5Q0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHFDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDZnhDLFVBQUEsd0JBQUEsR0FBQSxvREFBQSxHQUFBLENBQUE7OztBQUFBLFVBQUEsMkJBQUEsR0FBQSxJQUFBLFlBQUEsSUFBQSxVQUFBLElBQUEsZUFBQSxJQUFBLEVBQUE7Ozs7O29GRGVhLDZCQUEyQixFQUFBLFdBQUEsOEJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFZnhDLFNBQVMsYUFBQUMsWUFBVyxhQUFhO0FBQ2pDLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsd0JBQXdCOzs7OztBQUZqQyxJQVVhO0FBVmI7O0FBR0E7O0FBT00sSUFBTyxtQ0FBUCxNQUFPLGtDQUFnQztNQVVyQjtNQVJwQjtNQUdBLGlCQUFpQjtNQUdqQixjQUFjO01BRWQsWUFBb0Isa0JBQWtDO0FBQWxDLGFBQUEsbUJBQUE7TUFBcUM7TUFFekQsSUFBSSxPQUFJO0FBQ0osY0FBTSx5QkFBeUIsU0FBUywwQkFBMEIsS0FBSyxRQUFRO0FBQy9FLFlBQUksMkJBQTJCLHVCQUF1QixTQUFTO0FBRTNELGlCQUFPOztBQUVYLFlBQUksS0FBSyxnQkFBZ0I7QUFDckIsaUJBQU87O0FBRVgsZ0JBQVEsd0JBQXdCO1VBQzVCLEtBQUssdUJBQXVCO0FBQ3hCLG1CQUFPO1VBQ1gsS0FBSyx1QkFBdUI7QUFDeEIsbUJBQU87VUFDWDtBQUNJLG1CQUFPOztNQUVuQjtNQUVBLElBQUksVUFBTztBQUNQLFlBQUksS0FBSyxnQkFBZ0I7QUFDckIsaUJBQU8sS0FBSyxpQkFBaUIsUUFBUSwrQ0FBK0M7O0FBRXhGLGNBQU0seUJBQXlCLFNBQVMsMEJBQTBCLEtBQUssUUFBUTtBQUMvRSxnQkFBUSx3QkFBd0I7VUFDNUIsS0FBSyx1QkFBdUI7QUFDeEIsbUJBQU8sS0FBSyxpQkFBaUIsUUFBUSxpREFBaUQ7VUFDMUYsS0FBSyx1QkFBdUI7QUFDeEIsbUJBQU8sS0FBSyxpQkFBaUIsUUFBUSxnREFBZ0Q7VUFDekYsS0FBSyx1QkFBdUI7QUFDeEIsbUJBQU8sS0FBSyxpQkFBaUIsUUFBUSwrQ0FBK0M7VUFDeEY7QUFDSSxtQkFBTzs7TUFFbkI7O3lCQTlDUyxtQ0FBZ0MsZ0NBQUEsb0JBQUEsQ0FBQTtNQUFBO2lFQUFoQyxtQ0FBZ0MsV0FBQSxDQUFBLENBQUEsK0JBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsZ0JBQUEsaUJBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsU0FBQSxvQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsMENBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNWN0MsVUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUE0QixVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFVLFVBQUEsMkJBQUE7QUFDMUMsVUFBQSxxQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLElBQUE7OztBQUpxQyxVQUFBLHlCQUFBLGNBQUEsSUFBQSxPQUFBO0FBQ3hCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLFdBQUE7QUFDSCxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLGdCQUFBLElBQUEsSUFBQTs7Ozs7cUZEUUcsa0NBQWdDLEVBQUEsV0FBQSxtQ0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVWN0MsU0FBUyxhQUFBQyxrQkFBaUI7QUFDMUIsU0FBUyxPQUFPLGVBQWU7QUFDL0IsU0FBUyxzQkFBc0I7Ozs7OztBQUYvQixJQVFhO0FBUmI7OztBQVFNLElBQU8sd0RBQVAsTUFBTyx1REFBcUQ7TUFLMUM7TUFIcEIsUUFBUTtNQUNSLFVBQVU7TUFFVixZQUFvQixhQUEyQjtBQUEzQixhQUFBLGNBQUE7TUFBOEI7TUFLbEQsTUFBTSxTQUFnQjtBQUNsQixhQUFLLFlBQVksTUFBTSxPQUFPO01BQ2xDOzt5QkFaUyx3REFBcUQsZ0NBQUEsa0JBQUEsQ0FBQTtNQUFBO2lFQUFyRCx3REFBcUQsV0FBQSxDQUFBLENBQUEsc0RBQUEsQ0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLGdCQUFBLHFEQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsZ0JBQUEsU0FBQSxlQUFBLFFBQUEsR0FBQSxhQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxnQkFBQSwyREFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsZ0JBQUEsU0FBQSxHQUFBLE9BQUEsaUJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLGdCQUFBLHNCQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsV0FBQSxtQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGdCQUFBLGdFQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsK0RBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNSbEUsVUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQXlFLFVBQUEscUJBQUEsR0FBQSw4QkFBQTtBQUE0QixVQUFBLDJCQUFBO0FBQ3pHLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUFnRixVQUFBLHlCQUFBLFNBQUEsU0FBQSwwRkFBQTtBQUFBLG1CQUFTLElBQUEsTUFBTSxLQUFLO1VBQUMsQ0FBQTtBQUFFLFVBQUEsMkJBQUE7QUFDM0csVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsS0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLGlJQUFBO0FBQ0osVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUFxRSxVQUFBLHlCQUFBLFNBQUEsU0FBQSwwRkFBQTtBQUFBLG1CQUFTLElBQUEsTUFBTSxLQUFLO1VBQUMsQ0FBQTtBQUN0RixVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsV0FBQSxDQUFBO0FBQWtDLFVBQUEscUJBQUEsSUFBQSxNQUFBO0FBQU0sVUFBQSw2QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUEwQyxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFNLFVBQUEsMkJBQUE7QUFDNUYsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQWdELFVBQUEseUJBQUEsU0FBQSxTQUFBLDBGQUFBO0FBQUEsbUJBQVMsSUFBQSxNQUFNLElBQUk7VUFBQyxDQUFBO0FBQ2hFLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBb0YsVUFBQSxxQkFBQSxJQUFBLDhCQUFBO0FBQTRCLFVBQUEsMkJBQUE7QUFDcEgsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQVBxQixVQUFBLHdCQUFBLEVBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxLQUFBOzs7OztxRkROUix1REFBcUQsRUFBQSxXQUFBLHdEQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVJsRSxTQUFTLGdCQUFnQjtBQUt6QixTQUFTLHNCQUFzQjs7QUFML0IsSUEwQmE7QUExQmI7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFlTSxJQUFPLHdCQUFQLE1BQU8sdUJBQXFCOzt5QkFBckIsd0JBQXFCO01BQUE7Z0VBQXJCLHVCQUFxQixDQUFBO29FQVpwQixxQkFBcUIseUNBQXlDLDhCQUE4QixjQUFjLEVBQUEsQ0FBQTs7Ozs7O0FDZHhILFNBQVMsYUFBQUMsWUFBVyxTQUFBQyxjQUF3Qjs7Ozs7O0FDS3BDLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsY0FBQSxDQUFBO0FBU0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7Ozs7OztBQWhCMkMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLE9BQUEsa0JBQUEsV0FBQSxPQUFBLHVCQUFBLE9BQUEsVUFBQSxVQUFBLGVBQUEsV0FBQSxPQUFBLE9BQUEsa0JBQUEsSUFBQSxDQUFBLENBQUE7QUFDbEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsbUJBQUEsV0FBQSxPQUFBLHVCQUFBLE9BQUEsVUFBQSxVQUFBLGVBQUEsV0FBQSxPQUFBLE9BQUEsa0JBQUEsSUFBQSxDQUFBLENBQUE7QUFJVCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsT0FBQSxRQUFBLEVBQXFCLFVBQUEsU0FBQSxFQUFBLGlCQUFBLFVBQUEsYUFBQSxFQUFBLHVCQUFBLElBQUEsRUFBQSxhQUFBLElBQUEsRUFBQSxZQUFBLEtBQUE7QUFTRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsU0FBQSxLQUFBLE9BQUEsdUJBQUEsOEJBQUEsR0FBQSxHQUFBLElBQUEsOEJBQUEsSUFBQSxHQUFBLENBQUE7OztBRHJCeEMsY0FLYSwyQkFRQTtBQWJiOztBQUVBO0FBQ0E7Ozs7QUFFTyxJQUFNLDRCQUE0QjtBQVFuQyxJQUFPLHlCQUFQLE1BQU8sd0JBQXNCO01BQ3RCLG9CQUFvQjtNQUNwQixxQkFBcUI7TUFDckIseUJBQXlCO01BQ3pCLG9CQUFvQjtNQUVwQjtNQUNBO01BRVQsc0JBQXNCO01BQ3RCO01BQ0E7TUFFQSxjQUFXO0FBQ1AsYUFBSyxzQkFBc0IsS0FBSyxRQUFRLFNBQVM7QUFFakQsWUFBSSxLQUFLLFFBQVEsVUFBVSwyQkFBMkI7QUFDbEQsZUFBSyxtQkFBbUIsS0FBSztlQUMxQjtBQUNILGVBQUssbUJBQW1CLEtBQUssUUFBUSxNQUFNLEtBQUssUUFBUSxTQUFTLHlCQUF5QjtBQUUxRixnQkFBTSxrQkFBa0IsS0FBSyxRQUFRLE9BQU8sQ0FBQyxXQUFXLE9BQU8sS0FBSyxFQUFFLEtBQUk7QUFDMUUsY0FBSSxDQUFDLEtBQUssaUJBQWlCLE1BQUssR0FBSSxTQUFTLGlCQUFpQjtBQUMxRCxpQkFBSyxpQkFBaUIsQ0FBQyxJQUFJO0FBQzNCLGlCQUFLLHVCQUF1Qjs7O01BR3hDOzt5QkEzQlMseUJBQXNCO01BQUE7aUVBQXRCLHlCQUFzQixXQUFBLENBQUEsQ0FBQSxvQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFNBQUEsV0FBQSxVQUFBLFdBQUEsR0FBQSxVQUFBLENBQUEsa0NBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsd0JBQUEsR0FBQSxDQUFBLEdBQUEsd0JBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxxQkFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEscUJBQUEsZUFBQSxHQUFBLFlBQUEsVUFBQSxpQkFBQSx1QkFBQSxhQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxTQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsZ0NBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNibkMsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSx3QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNKLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSwrQkFBQSxHQUFBLHVDQUFBLElBQUEsSUFBQSxNQUFBLE1BQUEsdUNBQUE7QUFvQkosVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxJQUFBOzs7QUF4QndDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsMEJBQUEsNEJBQUEsSUFBQSxtQkFBQTtBQUdwQyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsZ0JBQUE7Ozs7O3FGRFNTLHdCQUFzQixFQUFBLFdBQUEseUJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFYm5DLFNBQVMsWUFBQUMsaUJBQWdCO0FBTXpCLFNBQVMsa0JBQUFDLHVCQUFzQjs7QUFOL0IsSUFjYTtBQWRiOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQU9NLElBQU8sc0JBQVAsTUFBTyxxQkFBbUI7O3lCQUFuQixzQkFBbUI7TUFBQTtnRUFBbkIscUJBQW1CLENBQUE7b0VBSmxCLHFCQUFxQix5Q0FBeUMsdUJBQXVCLDhCQUE4Qiw4QkFBOEJBLGVBQWMsRUFBQSxDQUFBOzs7OyIsIm5hbWVzIjpbInBhcnRpY2lwYXRpb24iLCJDb21wb25lbnQiLCJDb21wb25lbnQiLCJDb21wb25lbnQiLCJJbnB1dCIsIk5nTW9kdWxlIiwiQmFyQ2hhcnRNb2R1bGUiXX0=