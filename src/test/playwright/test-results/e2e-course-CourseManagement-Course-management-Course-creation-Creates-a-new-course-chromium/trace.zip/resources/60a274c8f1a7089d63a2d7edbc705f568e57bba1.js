import {
  ArtemisNavigationUtilService,
  findParamInRouteHierarchy,
  init_navigation_utils
} from "/chunk-QOKTVWNZ.js";
import {
  ThemeService,
  init_theme_service
} from "/chunk-PVIIR7SL.js";
import {
  ScoreType,
  init_score_type_constants
} from "/chunk-ORYTP7RT.js";
import {
  ArtemisTranslatePipe,
  GradeEditMode,
  GradeStepBoundsPipe,
  GradeType,
  GradingScale,
  GradingSystemService,
  HelpIconComponent,
  SafeHtmlPipe,
  ScoresStorageService,
  TranslateDirective,
  __async,
  __esm,
  __spreadProps,
  __spreadValues,
  init_artemis_translate_pipe,
  init_base_grading_system_component,
  init_grade_step_bounds_pipe,
  init_grading_scale_model,
  init_grading_system_service,
  init_help_icon_component,
  init_safe_html_pipe,
  init_scores_storage_service,
  init_translate_directive,
  init_utils,
  roundValueSpecifiedByCourseSettings
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/grading-system/grading-key-overview/grading-key-helper.ts
function loadGradingKeyUrlParams(route) {
  const courseId = Number(findParamInRouteHierarchy(route, "courseId"));
  let examId = void 0;
  let isExam = false;
  const examIdParam = findParamInRouteHierarchy(route, "examId");
  if (examIdParam) {
    examId = Number(examIdParam);
    isExam = true;
  }
  const forBonus = !!route.snapshot.data["forBonus"];
  const studentGradeOrBonusPointsOrGradeBonus = route.snapshot.queryParams["grade"];
  return {
    courseId,
    examId,
    forBonus,
    isExam,
    studentGradeOrBonusPointsOrGradeBonus
  };
}
var init_grading_key_helper = __esm({
  "src/main/webapp/app/grading-system/grading-key-overview/grading-key-helper.ts"() {
    init_navigation_utils();
  }
});

// src/main/webapp/app/entities/bonus.model.ts
var Bonus, BonusStrategy, BonusExample;
var init_bonus_model = __esm({
  "src/main/webapp/app/entities/bonus.model.ts"() {
    Bonus = class {
      id;
      bonusStrategy;
      weight;
      sourceGradingScale;
      bonusToGradingScale;
      constructor() {
      }
    };
    (function(BonusStrategy2) {
      BonusStrategy2["GRADES_CONTINUOUS"] = "GRADES_CONTINUOUS";
      BonusStrategy2["GRADES_DISCRETE"] = "GRADES_DISCRETE";
      BonusStrategy2["POINTS"] = "POINTS";
    })(BonusStrategy || (BonusStrategy = {}));
    BonusExample = class {
      studentPointsOfBonusTo;
      studentPointsOfBonusSource;
      examGrade;
      bonusGrade;
      finalPoints;
      finalGrade;
      exceedsMax = false;
      constructor(studentPointsOfBonusTo, studentPointsOfBonusSource) {
        this.studentPointsOfBonusTo = studentPointsOfBonusTo;
        this.studentPointsOfBonusSource = studentPointsOfBonusSource;
      }
    };
  }
});

// src/main/webapp/app/grading-system/bonus/bonus.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient, HttpParams } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var BonusService;
var init_bonus_service = __esm({
  "src/main/webapp/app/grading-system/bonus/bonus.service.ts"() {
    init_bonus_model();
    init_grading_system_service();
    init_utils();
    init_grading_system_service();
    BonusService = class _BonusService {
      http;
      gradingSystemService;
      resourceUrl = "api";
      constructor(http, gradingSystemService) {
        this.http = http;
        this.gradingSystemService = gradingSystemService;
      }
      deleteBonus(courseId, examId, bonusId) {
        return this.http.delete(`${this.resourceUrl}/courses/${courseId}/exams/${examId}/bonus/${bonusId}`, { observe: "response" });
      }
      createBonusForExam(courseId, examId, bonus) {
        return this.http.post(`${this.resourceUrl}/courses/${courseId}/exams/${examId}/bonus`, this.filterBonusForRequest(bonus), { observe: "response" });
      }
      updateBonus(courseId, examId, bonus) {
        return this.http.put(`${this.resourceUrl}/courses/${courseId}/exams/${examId}/bonus/${bonus.id}`, this.filterBonusForRequest(bonus), { observe: "response" });
      }
      findBonusForExam(courseId, examId, includeSourceGradeSteps) {
        const params = includeSourceGradeSteps != void 0 ? new HttpParams().set("includeSourceGradeSteps", includeSourceGradeSteps.toString()) : void 0;
        return this.http.get(`${this.resourceUrl}/courses/${courseId}/exams/${examId}/bonus`, { observe: "response", params });
      }
      generateBonusExamples(bonus, bonusTo) {
        if (!bonus.sourceGradingScale) {
          throw new Error(`Bonus.sourceGradingScale is empty: ${bonus.sourceGradingScale}`);
        }
        const bonusExamples = this.generateExampleExamAndBonusPoints(bonusTo, bonus.sourceGradingScale);
        bonusExamples.forEach((bonusExample) => this.calculateFinalGrade(bonusExample, bonus, bonusTo));
        return bonusExamples;
      }
      filterBonusForRequest(bonus) {
        return __spreadProps(__spreadValues({}, bonus), {
          sourceGradingScale: bonus.sourceGradingScale ? { id: bonus.sourceGradingScale.id } : void 0,
          bonusToGradingScale: void 0
        });
      }
      generateExampleExamAndBonusPoints(bonusTo, source) {
        const examples = [];
        examples.push(new BonusExample(0, void 0));
        let bonusToGradeStepIndex = bonusTo.gradeSteps.findIndex((gs) => gs.isPassingGrade);
        if (bonusToGradeStepIndex < 0) {
          throw Error("No passing grade was found for bonusTo grading scale");
        }
        let sourceGradeStepIndex = source.gradeSteps.length - 1;
        const sourceMaxPoints = this.gradingSystemService.getGradingScaleMaxPoints(source);
        for (let i = 0; i < 3; i++) {
          const bonusToGradeStep = bonusTo.gradeSteps[bonusToGradeStepIndex];
          const studentPointsOfBonusTo = this.getIncludedBoundaryPoints(bonusToGradeStep, bonusTo.maxPoints) ?? this.findMiddlePoint(bonusToGradeStep);
          const sourceGradeStep = source.gradeSteps[sourceGradeStepIndex];
          const studentPointsOfBonusSource = this.getIncludedBoundaryPoints(sourceGradeStep, sourceMaxPoints) ?? this.findMiddlePoint(sourceGradeStep);
          examples.push(new BonusExample(studentPointsOfBonusTo, studentPointsOfBonusSource));
          if (i === 0 && sourceGradeStep.lowerBoundPoints === sourceMaxPoints && !sourceGradeStep.lowerBoundInclusive) {
            sourceGradeStepIndex = this.modulo(sourceGradeStepIndex - 1, source.gradeSteps.length);
          }
          sourceGradeStepIndex = this.modulo(sourceGradeStepIndex - 1, source.gradeSteps.length);
          bonusToGradeStepIndex = this.modulo(bonusToGradeStepIndex + 1, bonusTo.gradeSteps.length);
        }
        bonusToGradeStepIndex = bonusTo.gradeSteps.length - 1;
        const lastBonusToGradeStep = bonusTo.gradeSteps[bonusToGradeStepIndex];
        const lastStudentPointsOfBonusTo = this.getIncludedBoundaryPoints(lastBonusToGradeStep, bonusTo.maxPoints) ?? this.findMiddlePoint(lastBonusToGradeStep);
        let lastSourceGradeStep = source.gradeSteps[sourceGradeStepIndex];
        if (this.gradingSystemService.getNumericValueForGradeName(lastSourceGradeStep.gradeName) === 0) {
          lastSourceGradeStep = source.gradeSteps[source.gradeSteps.length - 1];
        }
        const lastStudentPointsOfBonusSource = this.getIncludedBoundaryPoints(lastSourceGradeStep, sourceMaxPoints) ?? this.findMiddlePoint(lastSourceGradeStep);
        examples.push(new BonusExample(lastStudentPointsOfBonusTo, lastStudentPointsOfBonusSource));
        return examples;
      }
      findMiddlePoint(gradeStep) {
        return ((gradeStep.lowerBoundPoints ?? 0) + (gradeStep.upperBoundPoints ?? 0)) / 2;
      }
      calculateFinalGrade(bonusExample, bonus, bonusTo) {
        const examGradeStep = this.gradingSystemService.findMatchingGradeStepByPoints(bonusTo.gradeSteps, bonusExample.studentPointsOfBonusTo, bonusTo.maxPoints);
        bonusExample.examGrade = examGradeStep?.gradeName;
        if (!examGradeStep?.isPassingGrade || !bonus.sourceGradingScale) {
          bonusExample.bonusGrade = 0;
          bonusExample.finalPoints = bonusExample.studentPointsOfBonusTo;
          bonusExample.finalGrade = bonusExample.examGrade;
          return;
        }
        const bonusGradeStep = this.gradingSystemService.findMatchingGradeStepByPoints(bonus.sourceGradingScale.gradeSteps, bonusExample.studentPointsOfBonusSource ?? 0, this.gradingSystemService.getGradingScaleMaxPoints(bonus.sourceGradingScale));
        bonusExample.bonusGrade = this.gradingSystemService.getNumericValueForGradeName(bonusGradeStep?.gradeName);
        this.calculateBonusForStrategy(bonusExample, bonus, bonusTo);
      }
      calculateBonusForStrategy(bonusExample, bonus, bonusTo) {
        const course = this.gradingSystemService.getGradingScaleCourse(bonus.bonusToGradingScale);
        switch (bonus.bonusStrategy) {
          case BonusStrategy.POINTS: {
            bonusExample.finalPoints = roundValueSpecifiedByCourseSettings(bonusExample.studentPointsOfBonusTo + (bonus.weight ?? 1) * bonusExample.bonusGrade, course);
            bonusExample.exceedsMax = this.doesBonusExceedMax(bonusExample.finalPoints, bonusTo.maxPoints, bonus.weight);
            if (bonusExample.exceedsMax) {
              bonusExample.finalPoints = bonusTo.maxPoints ?? 0;
            }
            const finalGradeStep = this.gradingSystemService.findMatchingGradeStepByPoints(bonusTo.gradeSteps, bonusExample.finalPoints, bonusTo.maxPoints);
            bonusExample.finalGrade = finalGradeStep?.gradeName;
            break;
          }
          case BonusStrategy.GRADES_CONTINUOUS: {
            const examGradeNumericValue = this.gradingSystemService.getNumericValueForGradeName(bonusExample.examGrade);
            bonusExample.finalGrade = roundValueSpecifiedByCourseSettings(examGradeNumericValue + (bonus.weight ?? 1) * bonusExample.bonusGrade, course);
            const maxGrade = this.gradingSystemService.maxGrade(bonusTo.gradeSteps);
            const maxGradeNumericValue = this.gradingSystemService.getNumericValueForGradeName(maxGrade);
            bonusExample.exceedsMax = this.doesBonusExceedMax(bonusExample.finalGrade, maxGradeNumericValue, bonus.weight);
            if (bonusExample.exceedsMax) {
              bonusExample.finalGrade = maxGrade;
            }
            break;
          }
          case BonusStrategy.GRADES_DISCRETE: {
            throw new Error("GRADES_DISCRETE bonus strategy not yet implemented");
          }
        }
      }
      doesBonusExceedMax(valueWithBonus, maxValue, calculationSign) {
        return (valueWithBonus - maxValue) * calculationSign > 0;
      }
      getIncludedBoundaryPoints(gradeStep, maxPoints) {
        if (gradeStep.lowerBoundInclusive) {
          return gradeStep.lowerBoundPoints;
        }
        if (gradeStep.upperBoundInclusive) {
          return Math.min(gradeStep.upperBoundPoints, maxPoints);
        }
        return void 0;
      }
      modulo(n, m) {
        return (n % m + m) % m;
      }
      static \u0275fac = function BonusService_Factory(t) {
        return new (t || _BonusService)(i0.\u0275\u0275inject(i1.HttpClient), i0.\u0275\u0275inject(GradingSystemService));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _BonusService, factory: _BonusService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/grading-system/grading-key-overview/grading-key/grading-key-table.component.ts
import { Component, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faChevronLeft } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { map } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { ActivatedRoute } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function GradingKeyTableComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n        ");
    i02.\u0275\u0275elementStart(1, "h6");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n    ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.gradingSystem.overview.info"));
  }
}
function GradingKeyTableComponent_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "th");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.exam.examSummary.intervalPoints"));
  }
}
function GradingKeyTableComponent_Conditional_25_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "td");
    i02.\u0275\u0275text(2, "\u2014");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                        ");
  }
}
function GradingKeyTableComponent_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "tr");
    i02.\u0275\u0275text(2, "\n                        ");
    i02.\u0275\u0275elementStart(3, "td");
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275element(5, "jhi-help-icon", 2);
    i02.\u0275\u0275text(6, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275text(8, "\n                        ");
    i02.\u0275\u0275elementStart(9, "td");
    i02.\u0275\u0275text(10, "\u2014");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n                        ");
    i02.\u0275\u0275template(12, GradingKeyTableComponent_Conditional_25_Conditional_12_Template, 4, 0);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(13, "\n                ");
  }
  if (rf & 2) {
    const ctx_r2 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275classProp("highlighted", ctx_r2.plagiarismGrade === ctx_r2.studentGradeOrBonusPointsOrGradeBonus);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate1("\n                            ", ctx_r2.plagiarismGrade, "\n                            ");
    i02.\u0275\u0275advance(8);
    i02.\u0275\u0275conditional(12, ctx_r2.hasPointsSet ? 12 : -1);
  }
}
function GradingKeyTableComponent_Conditional_26_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "td");
    i02.\u0275\u0275text(2, "\u2014");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                        ");
  }
}
function GradingKeyTableComponent_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "tr");
    i02.\u0275\u0275text(2, "\n                        ");
    i02.\u0275\u0275elementStart(3, "td");
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275element(5, "jhi-help-icon", 3);
    i02.\u0275\u0275text(6, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275text(8, "\n                        ");
    i02.\u0275\u0275elementStart(9, "td");
    i02.\u0275\u0275text(10, "\u2014");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n                        ");
    i02.\u0275\u0275template(12, GradingKeyTableComponent_Conditional_26_Conditional_12_Template, 4, 0);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(13, "\n                ");
  }
  if (rf & 2) {
    const ctx_r3 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275classProp("highlighted", ctx_r3.noParticipationGrade === ctx_r3.studentGradeOrBonusPointsOrGradeBonus);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate1("\n                            ", ctx_r3.noParticipationGrade, "\n                            ");
    i02.\u0275\u0275advance(8);
    i02.\u0275\u0275conditional(12, ctx_r3.hasPointsSet ? 12 : -1);
  }
}
function GradingKeyTableComponent_For_28_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "td");
    i02.\u0275\u0275text(2, "\n                                ");
    i02.\u0275\u0275element(3, "span", 4);
    i02.\u0275\u0275pipe(4, "safeHtml");
    i02.\u0275\u0275pipe(5, "gradeStepBounds");
    i02.\u0275\u0275text(6, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r13 = i02.\u0275\u0275nextContext();
    const gradeStep_r7 = ctx_r13.$implicit;
    const \u0275$index_1_r9 = ctx_r13.$index;
    const \u0275$count_1_r11 = ctx_r13.$count;
    const ctx_r12 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("innerHTML", i02.\u0275\u0275pipeBind1(4, 1, i02.\u0275\u0275pipeBind3(5, 3, gradeStep_r7, ctx_r12.GradeEditMode.POINTS, \u0275$index_1_r9 === \u0275$count_1_r11 - 1)), i02.\u0275\u0275sanitizeHtml);
  }
}
function GradingKeyTableComponent_For_28_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "tr");
    i02.\u0275\u0275text(2, "\n                        ");
    i02.\u0275\u0275elementStart(3, "td");
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                        ");
    i02.\u0275\u0275elementStart(6, "td");
    i02.\u0275\u0275text(7, "\n                            ");
    i02.\u0275\u0275element(8, "span", 4);
    i02.\u0275\u0275pipe(9, "safeHtml");
    i02.\u0275\u0275pipe(10, "gradeStepBounds");
    i02.\u0275\u0275text(11, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(12, "\n                        ");
    i02.\u0275\u0275template(13, GradingKeyTableComponent_For_28_Conditional_13_Template, 8, 7);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(14, "\n                ");
  }
  if (rf & 2) {
    const gradeStep_r7 = ctx.$implicit;
    const $index_r8 = ctx.$index;
    const $count_r10 = ctx.$count;
    const ctx_r4 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275classProp("highlighted", gradeStep_r7.gradeName === ctx_r4.studentGradeOrBonusPointsOrGradeBonus || +gradeStep_r7.gradeName === +ctx_r4.studentGradeOrBonusPointsOrGradeBonus);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(gradeStep_r7.gradeName);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275property("innerHTML", i02.\u0275\u0275pipeBind1(9, 5, i02.\u0275\u0275pipeBind3(10, 7, gradeStep_r7, ctx_r4.GradeEditMode.PERCENTAGE, $index_r8 === $count_r10 - 1)), i02.\u0275\u0275sanitizeHtml);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275conditional(13, ctx_r4.hasPointsSet ? 13 : -1);
  }
}
var GradingKeyTableComponent;
var init_grading_key_table_component = __esm({
  "src/main/webapp/app/grading-system/grading-key-overview/grading-key/grading-key-table.component.ts"() {
    init_grading_system_service();
    init_grading_scale_model();
    init_base_grading_system_component();
    init_bonus_service();
    init_scores_storage_service();
    init_score_type_constants();
    init_grading_key_helper();
    init_grading_system_service();
    init_bonus_service();
    init_scores_storage_service();
    init_help_icon_component();
    init_artemis_translate_pipe();
    init_safe_html_pipe();
    init_grade_step_bounds_pipe();
    GradingKeyTableComponent = class _GradingKeyTableComponent {
      route;
      gradingSystemService;
      bonusService;
      scoresStorageService;
      faChevronLeft = faChevronLeft;
      GradeEditMode = GradeEditMode;
      studentGradeOrBonusPointsOrGradeBonus;
      forBonus;
      constructor(route, gradingSystemService, bonusService, scoresStorageService) {
        this.route = route;
        this.gradingSystemService = gradingSystemService;
        this.bonusService = bonusService;
        this.scoresStorageService = scoresStorageService;
      }
      plagiarismGrade;
      noParticipationGrade;
      isExam = false;
      courseId;
      examId;
      title;
      gradeSteps = [];
      isBonus = false;
      hasPointsSet = false;
      ngOnInit() {
        const { courseId, examId, forBonus, isExam, studentGradeOrBonusPointsOrGradeBonus } = loadGradingKeyUrlParams(this.route);
        this.courseId = courseId;
        this.examId = examId;
        this.forBonus = this.forBonus || forBonus;
        this.isExam = isExam;
        this.studentGradeOrBonusPointsOrGradeBonus = this.studentGradeOrBonusPointsOrGradeBonus || studentGradeOrBonusPointsOrGradeBonus;
        this.findGradeSteps(this.courseId, this.examId).subscribe((gradeSteps) => {
          if (gradeSteps) {
            this.title = gradeSteps.title;
            this.isBonus = gradeSteps.gradeType === GradeType.BONUS;
            this.gradeSteps = this.gradingSystemService.sortGradeSteps(gradeSteps.gradeSteps);
            this.plagiarismGrade = gradeSteps.plagiarismGrade;
            this.noParticipationGrade = gradeSteps.noParticipationGrade;
            if (gradeSteps.maxPoints !== void 0) {
              if (!this.isExam) {
                let maxPoints = 0;
                const totalScoresForCourse = this.scoresStorageService.getStoredTotalScores(this.courseId);
                if (totalScoresForCourse) {
                  maxPoints = totalScoresForCourse[ScoreType.REACHABLE_POINTS];
                }
                this.gradingSystemService.setGradePoints(this.gradeSteps, maxPoints);
              } else {
                this.gradingSystemService.setGradePoints(this.gradeSteps, gradeSteps.maxPoints);
              }
            }
          }
        });
        this.hasPointsSet = this.gradingSystemService.hasPointsSet(this.gradeSteps);
      }
      findGradeSteps(courseId, examId) {
        if (!this.forBonus) {
          return this.gradingSystemService.findGradeSteps(courseId, examId);
        } else {
          return this.bonusService.findBonusForExam(courseId, examId, true).pipe(map((bonusResponse) => {
            const source = bonusResponse.body?.sourceGradingScale;
            if (!source) {
              return void 0;
            }
            return {
              title: this.gradingSystemService.getGradingScaleTitle(source),
              gradeType: source.gradeType,
              gradeSteps: source.gradeSteps,
              maxPoints: this.gradingSystemService.getGradingScaleMaxPoints(source),
              plagiarismGrade: source.plagiarismGrade || GradingScale.DEFAULT_PLAGIARISM_GRADE,
              noParticipationGrade: source.noParticipationGrade || GradingScale.DEFAULT_NO_PARTICIPATION_GRADE,
              presentationsNumber: source.presentationsNumber,
              presentationsWeight: source.presentationsWeight
            };
          }));
        }
      }
      static \u0275fac = function GradingKeyTableComponent_Factory(t) {
        return new (t || _GradingKeyTableComponent)(i02.\u0275\u0275directiveInject(i12.ActivatedRoute), i02.\u0275\u0275directiveInject(GradingSystemService), i02.\u0275\u0275directiveInject(BonusService), i02.\u0275\u0275directiveInject(ScoresStorageService));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _GradingKeyTableComponent, selectors: [["jhi-grade-key-table"]], inputs: { studentGradeOrBonusPointsOrGradeBonus: "studentGradeOrBonusPointsOrGradeBonus", forBonus: "forBonus" }, decls: 61, vars: 24, consts: [[1, "table", "table-striped"], [2, "font-weight", "bold"], ["placement", "auto", "text", "artemisApp.gradingSystem.plagiarismGradeHelp"], ["placement", "auto", "text", "artemisApp.gradingSystem.noParticipationGradeHelp"], [3, "innerHTML"]], template: function GradingKeyTableComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div");
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275template(2, GradingKeyTableComponent_Conditional_2_Template, 5, 3);
          i02.\u0275\u0275elementStart(3, "div");
          i02.\u0275\u0275text(4, "\n        ");
          i02.\u0275\u0275elementStart(5, "table", 0);
          i02.\u0275\u0275text(6, "\n            ");
          i02.\u0275\u0275elementStart(7, "thead");
          i02.\u0275\u0275text(8, "\n                ");
          i02.\u0275\u0275elementStart(9, "tr");
          i02.\u0275\u0275text(10, "\n                    ");
          i02.\u0275\u0275elementStart(11, "th");
          i02.\u0275\u0275text(12);
          i02.\u0275\u0275pipe(13, "artemisTranslate");
          i02.\u0275\u0275pipe(14, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(15, "\n                    ");
          i02.\u0275\u0275elementStart(16, "th");
          i02.\u0275\u0275text(17);
          i02.\u0275\u0275pipe(18, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(19, "\n                    ");
          i02.\u0275\u0275template(20, GradingKeyTableComponent_Conditional_20_Template, 5, 3);
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(21, "\n            ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(22, "\n            ");
          i02.\u0275\u0275elementStart(23, "tbody");
          i02.\u0275\u0275text(24, "\n                ");
          i02.\u0275\u0275template(25, GradingKeyTableComponent_Conditional_25_Template, 14, 4)(26, GradingKeyTableComponent_Conditional_26_Template, 14, 4);
          i02.\u0275\u0275repeaterCreate(27, GradingKeyTableComponent_For_28_Template, 15, 11, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(29, "\n        ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(30, "\n    ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(31, "\n    ");
          i02.\u0275\u0275elementStart(32, "div");
          i02.\u0275\u0275text(33, "\n        ");
          i02.\u0275\u0275elementStart(34, "h6");
          i02.\u0275\u0275text(35);
          i02.\u0275\u0275pipe(36, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(37, "\n        ");
          i02.\u0275\u0275elementStart(38, "ul");
          i02.\u0275\u0275text(39, "\n            ");
          i02.\u0275\u0275elementStart(40, "li")(41, "span", 1);
          i02.\u0275\u0275text(42, "[a, b)");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(43);
          i02.\u0275\u0275pipe(44, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(45, "\n            ");
          i02.\u0275\u0275elementStart(46, "li")(47, "span", 1);
          i02.\u0275\u0275text(48, "(a, b]");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(49);
          i02.\u0275\u0275pipe(50, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(51, "\n            ");
          i02.\u0275\u0275elementStart(52, "li")(53, "span", 1);
          i02.\u0275\u0275text(54, "[a, b]");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(55);
          i02.\u0275\u0275pipe(56, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(57, "\n        ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(58, "\n    ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(59, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(60, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(2);
          i02.\u0275\u0275conditional(2, !ctx.isExam ? 2 : -1);
          i02.\u0275\u0275advance(10);
          i02.\u0275\u0275textInterpolate(ctx.isBonus ? i02.\u0275\u0275pipeBind1(13, 10, "artemisApp.exam.examSummary.bonus") : i02.\u0275\u0275pipeBind1(14, 12, "artemisApp.exam.examSummary.grade"));
          i02.\u0275\u0275advance(5);
          i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(18, 14, "artemisApp.exam.examSummary.interval"));
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275conditional(20, ctx.hasPointsSet ? 20 : -1);
          i02.\u0275\u0275advance(5);
          i02.\u0275\u0275conditional(25, ctx.plagiarismGrade === ctx.studentGradeOrBonusPointsOrGradeBonus ? 25 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(26, ctx.noParticipationGrade === ctx.studentGradeOrBonusPointsOrGradeBonus ? 26 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275repeater(ctx.gradeSteps);
          i02.\u0275\u0275advance(8);
          i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(36, 16, "artemisApp.gradingSystem.overview.intervals.title"));
          i02.\u0275\u0275advance(8);
          i02.\u0275\u0275textInterpolate1(": ", i02.\u0275\u0275pipeBind1(44, 18, "artemisApp.gradingSystem.overview.intervals.leftInclusiveRightExclusive"), "");
          i02.\u0275\u0275advance(6);
          i02.\u0275\u0275textInterpolate1(": ", i02.\u0275\u0275pipeBind1(50, 20, "artemisApp.gradingSystem.overview.intervals.leftExclusiveRightInclusive"), "");
          i02.\u0275\u0275advance(6);
          i02.\u0275\u0275textInterpolate1(": ", i02.\u0275\u0275pipeBind1(56, 22, "artemisApp.gradingSystem.overview.intervals.bothInclusive"), "");
        }
      }, dependencies: [HelpIconComponent, ArtemisTranslatePipe, SafeHtmlPipe, GradeStepBoundsPipe], styles: ["\n\n.highlighted[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  background-color: #0079bf;\n  color: white;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9ncmFkaW5nLXN5c3RlbS9ncmFkaW5nLWtleS1vdmVydmlldy9ncmFkaW5nLWtleS1vdmVydmlldy5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuaGlnaGxpZ2h0ZWQgdGQge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMDc5YmY7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLENBQUEsWUFBQTtBQUNJLG9CQUFBO0FBQ0EsU0FBQTtBQUNBLGVBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(GradingKeyTableComponent, { className: "GradingKeyTableComponent" });
    })();
  }
});

// src/main/webapp/app/grading-system/grading-key-overview/grading-key-overview.component.ts
import { Component as Component2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { faChevronLeft as faChevronLeft2, faPrint } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function GradingKeyOverviewComponent_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n            ");
    i03.\u0275\u0275elementStart(1, "h6");
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275pipe(3, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(4, "\n        ");
  }
  if (rf & 2) {
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(3, 1, "artemisApp.gradingSystem.overview.info"));
  }
}
var GradingKeyOverviewComponent;
var init_grading_key_overview_component = __esm({
  "src/main/webapp/app/grading-system/grading-key-overview/grading-key-overview.component.ts"() {
    init_grading_system_service();
    init_navigation_utils();
    init_theme_service();
    init_grading_key_helper();
    init_grading_system_service();
    init_navigation_utils();
    init_theme_service();
    init_translate_directive();
    init_grading_key_table_component();
    init_artemis_translate_pipe();
    GradingKeyOverviewComponent = class _GradingKeyOverviewComponent {
      route;
      gradingSystemService;
      navigationUtilService;
      themeService;
      faChevronLeft = faChevronLeft2;
      faPrint = faPrint;
      plagiarismGrade;
      noParticipationGrade;
      constructor(route, gradingSystemService, navigationUtilService, themeService) {
        this.route = route;
        this.gradingSystemService = gradingSystemService;
        this.navigationUtilService = navigationUtilService;
        this.themeService = themeService;
      }
      isExam = false;
      courseId;
      examId;
      title;
      gradeSteps = [];
      studentGradeOrBonusPointsOrGradeBonus;
      isBonus = false;
      forBonus;
      ngOnInit() {
        const { courseId, examId, forBonus, isExam, studentGradeOrBonusPointsOrGradeBonus } = loadGradingKeyUrlParams(this.route);
        this.courseId = courseId;
        this.examId = examId;
        this.forBonus = forBonus;
        this.isExam = isExam;
        this.studentGradeOrBonusPointsOrGradeBonus = studentGradeOrBonusPointsOrGradeBonus;
      }
      previousState() {
        const fallbackUrl = ["courses", this.courseId.toString()];
        if (this.isExam) {
          fallbackUrl.push("exams", this.examId.toString());
        } else {
          fallbackUrl.push("statistics");
        }
        this.navigationUtilService.navigateBack(fallbackUrl);
      }
      printPDF() {
        return __async(this, null, function* () {
          yield this.themeService.print();
        });
      }
      static \u0275fac = function GradingKeyOverviewComponent_Factory(t) {
        return new (t || _GradingKeyOverviewComponent)(i03.\u0275\u0275directiveInject(i13.ActivatedRoute), i03.\u0275\u0275directiveInject(GradingSystemService), i03.\u0275\u0275directiveInject(ArtemisNavigationUtilService), i03.\u0275\u0275directiveInject(ThemeService));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _GradingKeyOverviewComponent, selectors: [["jhi-grade-key-overview"]], decls: 29, vars: 7, consts: [[1, "row", "justify-content-center"], [1, "col-6"], [1, "text-center", "mb-3"], ["type", "button", 1, "btn", "btn-secondary", 3, "click"], [3, "icon"], ["jhiTranslate", "entity.action.back"], ["id", "exportToPDFButton", 1, "btn", "btn-primary", 2, "float", "right", 3, "click"], ["jhiTranslate", "artemisApp.exam.examSummary.exportPDF"]], template: function GradingKeyOverviewComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "div", 0);
          i03.\u0275\u0275text(1, "\n    ");
          i03.\u0275\u0275elementStart(2, "div", 1);
          i03.\u0275\u0275text(3, "\n        ");
          i03.\u0275\u0275elementStart(4, "h1", 2);
          i03.\u0275\u0275text(5);
          i03.\u0275\u0275pipe(6, "artemisTranslate");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(7, "\n        ");
          i03.\u0275\u0275template(8, GradingKeyOverviewComponent_Conditional_8_Template, 5, 3);
          i03.\u0275\u0275element(9, "jhi-grade-key-table");
          i03.\u0275\u0275text(10, "\n        ");
          i03.\u0275\u0275elementStart(11, "button", 3);
          i03.\u0275\u0275listener("click", function GradingKeyOverviewComponent_Template_button_click_11_listener() {
            return ctx.previousState();
          });
          i03.\u0275\u0275text(12, "\n            ");
          i03.\u0275\u0275element(13, "fa-icon", 4);
          i03.\u0275\u0275text(14, "\xA0");
          i03.\u0275\u0275elementStart(15, "span", 5);
          i03.\u0275\u0275text(16, " Back");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(17, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(18, "\n        ");
          i03.\u0275\u0275elementStart(19, "button", 6);
          i03.\u0275\u0275listener("click", function GradingKeyOverviewComponent_Template_button_click_19_listener() {
            return ctx.printPDF();
          });
          i03.\u0275\u0275text(20, "\n            ");
          i03.\u0275\u0275element(21, "fa-icon", 4);
          i03.\u0275\u0275text(22, "\n            ");
          i03.\u0275\u0275elementStart(23, "span", 7);
          i03.\u0275\u0275text(24, "Export PDF");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(25, "\n        ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(26, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(27, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(28, "\n");
        }
        if (rf & 2) {
          i03.\u0275\u0275advance(5);
          i03.\u0275\u0275textInterpolate2("\n            ", i03.\u0275\u0275pipeBind1(6, 5, ctx.forBonus ? "artemisApp.gradingSystem.titleBonus" : ctx.isExam ? "artemisApp.gradingSystem.titleExam" : "artemisApp.gradingSystem.titleCourse"), "\n            ", ctx.title, "\n        ");
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275conditional(8, !ctx.isExam ? 8 : -1);
          i03.\u0275\u0275advance(5);
          i03.\u0275\u0275property("icon", ctx.faChevronLeft);
          i03.\u0275\u0275advance(8);
          i03.\u0275\u0275property("icon", ctx.faPrint);
        }
      }, dependencies: [i5.FaIconComponent, TranslateDirective, GradingKeyTableComponent, ArtemisTranslatePipe], styles: ["\n\n.highlighted[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  background-color: #0079bf;\n  color: white;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9ncmFkaW5nLXN5c3RlbS9ncmFkaW5nLWtleS1vdmVydmlldy9ncmFkaW5nLWtleS1vdmVydmlldy5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuaGlnaGxpZ2h0ZWQgdGQge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMDc5YmY7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLENBQUEsWUFBQTtBQUNJLG9CQUFBO0FBQ0EsU0FBQTtBQUNBLGVBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(GradingKeyOverviewComponent, { className: "GradingKeyOverviewComponent" });
    })();
  }
});

export {
  Bonus,
  BonusStrategy,
  BonusExample,
  init_bonus_model,
  BonusService,
  init_bonus_service,
  GradingKeyTableComponent,
  init_grading_key_table_component,
  GradingKeyOverviewComponent,
  init_grading_key_overview_component
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZ3JhZGluZy1zeXN0ZW0vZ3JhZGluZy1rZXktb3ZlcnZpZXcvZ3JhZGluZy1rZXktaGVscGVyLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9ib251cy5tb2RlbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZ3JhZGluZy1zeXN0ZW0vYm9udXMvYm9udXMuc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZ3JhZGluZy1zeXN0ZW0vZ3JhZGluZy1rZXktb3ZlcnZpZXcvZ3JhZGluZy1rZXkvZ3JhZGluZy1rZXktdGFibGUuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9ncmFkaW5nLXN5c3RlbS9ncmFkaW5nLWtleS1vdmVydmlldy9ncmFkaW5nLWtleS9ncmFkaW5nLWtleS10YWJsZS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZ3JhZGluZy1zeXN0ZW0vZ3JhZGluZy1rZXktb3ZlcnZpZXcvZ3JhZGluZy1rZXktb3ZlcnZpZXcuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9ncmFkaW5nLXN5c3RlbS9ncmFkaW5nLWtleS1vdmVydmlldy9ncmFkaW5nLWtleS1vdmVydmlldy5jb21wb25lbnQuaHRtbCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmaW5kUGFyYW1JblJvdXRlSGllcmFyY2h5IH0gZnJvbSAnYXBwL3V0aWxzL25hdmlnYXRpb24udXRpbHMnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuXG5leHBvcnQgdHlwZSBHcmFkaW5nS2V5VXJsUGFyYW1zID0ge1xuICAgIGNvdXJzZUlkOiBudW1iZXI7XG4gICAgZXhhbUlkPzogbnVtYmVyO1xuICAgIGlzRXhhbTogYm9vbGVhbjtcbiAgICBmb3JCb251czogYm9vbGVhbjtcbiAgICBzdHVkZW50R3JhZGVPckJvbnVzUG9pbnRzT3JHcmFkZUJvbnVzPzogc3RyaW5nO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIGxvYWRHcmFkaW5nS2V5VXJsUGFyYW1zKHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSk6IEdyYWRpbmdLZXlVcmxQYXJhbXMge1xuICAgIC8vIE5vdGU6IFRoaXMgY29tcG9uZW50IGlzIHVzZWQgaW4gbXVsdGlwbGUgcm91dGVzLCBzbyBpdCBjYW4gYmUgbGF6eSBsb2FkZWQuIEFsc28sIGNvdXJzZUlkIGFuZCBleGFtSWQgY2FuIGJlXG4gICAgLy8gZm91bmQgb24gZGlmZmVyZW50IGxldmVscyBvZiBoaWVyYXJjaHkgdHJlZSAob24gdGhlIHNhbWUgbGV2ZWwgb3IgYSBwYXJlbnQgb3IgYSBncmFuZHBhcmVudCwgZXRjLikuXG4gICAgY29uc3QgY291cnNlSWQgPSBOdW1iZXIoZmluZFBhcmFtSW5Sb3V0ZUhpZXJhcmNoeShyb3V0ZSwgJ2NvdXJzZUlkJykpO1xuICAgIGxldCBleGFtSWQgPSB1bmRlZmluZWQ7XG4gICAgbGV0IGlzRXhhbSA9IGZhbHNlO1xuXG4gICAgY29uc3QgZXhhbUlkUGFyYW0gPSBmaW5kUGFyYW1JblJvdXRlSGllcmFyY2h5KHJvdXRlLCAnZXhhbUlkJyk7XG4gICAgaWYgKGV4YW1JZFBhcmFtKSB7XG4gICAgICAgIGV4YW1JZCA9IE51bWJlcihleGFtSWRQYXJhbSk7XG4gICAgICAgIGlzRXhhbSA9IHRydWU7XG4gICAgfVxuICAgIGNvbnN0IGZvckJvbnVzID0gISFyb3V0ZS5zbmFwc2hvdC5kYXRhWydmb3JCb251cyddO1xuXG4gICAgLyoqIElmIG5lZWRlZCBxdWVyeVBhcmFtIGlzIGF2YWlsYWJsZSwgaXQgaXMgYXZhaWxhYmxlIG9uIHtAbGluayBHcmFkaW5nS2V5T3ZlcnZpZXdDb21wb25lbnR9IHNvIG5vIG5lZWQgdG8gdHJhdmVyc2UgdGhlIGhpZXJhcmNoeSBsaWtlIHBhcmFtcyBhYm92ZS4gKi9cbiAgICBjb25zdCBzdHVkZW50R3JhZGVPckJvbnVzUG9pbnRzT3JHcmFkZUJvbnVzID0gcm91dGUuc25hcHNob3QucXVlcnlQYXJhbXNbJ2dyYWRlJ107XG5cbiAgICByZXR1cm4ge1xuICAgICAgICBjb3Vyc2VJZCxcbiAgICAgICAgZXhhbUlkLFxuICAgICAgICBmb3JCb251cyxcbiAgICAgICAgaXNFeGFtLFxuICAgICAgICBzdHVkZW50R3JhZGVPckJvbnVzUG9pbnRzT3JHcmFkZUJvbnVzOiBzdHVkZW50R3JhZGVPckJvbnVzUG9pbnRzT3JHcmFkZUJvbnVzLFxuICAgIH07XG59XG4iLCJpbXBvcnQgeyBCYXNlRW50aXR5IH0gZnJvbSAnYXBwL3NoYXJlZC9tb2RlbC9iYXNlLWVudGl0eSc7XG5pbXBvcnQgeyBHcmFkaW5nU2NhbGUgfSBmcm9tICdhcHAvZW50aXRpZXMvZ3JhZGluZy1zY2FsZS5tb2RlbCc7XG5pbXBvcnQgeyBQbGFnaWFyaXNtVmVyZGljdCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3BsYWdpYXJpc20vdHlwZXMvUGxhZ2lhcmlzbVZlcmRpY3QnO1xuXG5leHBvcnQgY2xhc3MgQm9udXMgaW1wbGVtZW50cyBCYXNlRW50aXR5IHtcbiAgICBwdWJsaWMgaWQ/OiBudW1iZXI7XG4gICAgcHVibGljIGJvbnVzU3RyYXRlZ3k/OiBCb251c1N0cmF0ZWd5O1xuICAgIHB1YmxpYyB3ZWlnaHQ/OiBudW1iZXI7XG4gICAgcHVibGljIHNvdXJjZUdyYWRpbmdTY2FsZT86IEdyYWRpbmdTY2FsZTtcbiAgICBwdWJsaWMgYm9udXNUb0dyYWRpbmdTY2FsZT86IEdyYWRpbmdTY2FsZTtcblxuICAgIGNvbnN0cnVjdG9yKCkge31cbn1cblxuZXhwb3J0IGVudW0gQm9udXNTdHJhdGVneSB7XG4gICAgR1JBREVTX0NPTlRJTlVPVVMgPSAnR1JBREVTX0NPTlRJTlVPVVMnLFxuICAgIEdSQURFU19ESVNDUkVURSA9ICdHUkFERVNfRElTQ1JFVEUnLFxuICAgIFBPSU5UUyA9ICdQT0lOVFMnLFxufVxuXG5leHBvcnQgY2xhc3MgQm9udXNFeGFtcGxlIHtcbiAgICBwdWJsaWMgZXhhbUdyYWRlPzogbnVtYmVyIHwgc3RyaW5nO1xuICAgIHB1YmxpYyBib251c0dyYWRlPzogbnVtYmVyO1xuICAgIHB1YmxpYyBmaW5hbFBvaW50cz86IG51bWJlcjtcbiAgICBwdWJsaWMgZmluYWxHcmFkZT86IG51bWJlciB8IHN0cmluZztcbiAgICBwdWJsaWMgZXhjZWVkc01heCA9IGZhbHNlO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHB1YmxpYyBzdHVkZW50UG9pbnRzT2ZCb251c1RvOiBudW1iZXIsXG4gICAgICAgIHB1YmxpYyBzdHVkZW50UG9pbnRzT2ZCb251c1NvdXJjZTogbnVtYmVyIHwgdW5kZWZpbmVkLFxuICAgICkge31cbn1cblxuZXhwb3J0IGNsYXNzIEJvbnVzUmVzdWx0IHtcbiAgICBwdWJsaWMgYm9udXNTdHJhdGVneT86IEJvbnVzU3RyYXRlZ3k7XG4gICAgcHVibGljIGJvbnVzRnJvbVRpdGxlPzogc3RyaW5nO1xuICAgIHB1YmxpYyBzdHVkZW50UG9pbnRzT2ZCb251c1NvdXJjZT86IG51bWJlciB8IHVuZGVmaW5lZDtcbiAgICBwdWJsaWMgYm9udXNHcmFkZT86IG51bWJlciB8IHN0cmluZztcbiAgICBwdWJsaWMgZmluYWxQb2ludHM/OiBudW1iZXI7XG4gICAgcHVibGljIGZpbmFsR3JhZGU/OiBudW1iZXIgfCBzdHJpbmc7XG4gICAgcHVibGljIG1vc3RTZXZlcmVQbGFnaWFyaXNtVmVyZGljdD86IFBsYWdpYXJpc21WZXJkaWN0O1xuICAgIHB1YmxpYyBhY2hpZXZlZFByZXNlbnRhdGlvblNjb3JlPzogbnVtYmVyO1xuICAgIHB1YmxpYyBwcmVzZW50YXRpb25TY29yZVRocmVzaG9sZD86IG51bWJlcjtcblxuICAgIGNvbnN0cnVjdG9yKCkge31cbn1cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBQYXJhbXMsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEdyYWRlU3RlcCwgR3JhZGVTdGVwc0RUTyB9IGZyb20gJ2FwcC9lbnRpdGllcy9ncmFkZS1zdGVwLm1vZGVsJztcbmltcG9ydCB7IEJvbnVzLCBCb251c0V4YW1wbGUsIEJvbnVzU3RyYXRlZ3kgfSBmcm9tICdhcHAvZW50aXRpZXMvYm9udXMubW9kZWwnO1xuaW1wb3J0IHsgR3JhZGluZ1NjYWxlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2dyYWRpbmctc2NhbGUubW9kZWwnO1xuaW1wb3J0IHsgR3JhZGluZ1N5c3RlbVNlcnZpY2UgfSBmcm9tICdhcHAvZ3JhZGluZy1zeXN0ZW0vZ3JhZGluZy1zeXN0ZW0uc2VydmljZSc7XG5pbXBvcnQgeyByb3VuZFZhbHVlU3BlY2lmaWVkQnlDb3Vyc2VTZXR0aW5ncyB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC91dGlscyc7XG5cbmV4cG9ydCB0eXBlIEVudGl0eVJlc3BvbnNlVHlwZSA9IEh0dHBSZXNwb25zZTxCb251cz47XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgQm9udXNTZXJ2aWNlIHtcbiAgICBwdWJsaWMgcmVzb3VyY2VVcmwgPSAnYXBpJztcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQsXG4gICAgICAgIHByaXZhdGUgZ3JhZGluZ1N5c3RlbVNlcnZpY2U6IEdyYWRpbmdTeXN0ZW1TZXJ2aWNlLFxuICAgICkge31cblxuICAgIC8qKlxuICAgICAqIERlbGV0ZXMgdGhlIGJvbnVzLlxuICAgICAqXG4gICAgICogQHBhcmFtIGNvdXJzZUlkIHRoZSBjb3Vyc2UgdG8gd2hpY2ggdGhlIGV4YW0gYmVsb25nc1xuICAgICAqIEBwYXJhbSBleGFtSWQgdGhlIGV4YW0gZm9yIHdoaWNoIHRoZSBib251cyB3aWxsIGJlIGRlbGV0ZWRcbiAgICAgKiBAcGFyYW0gYm9udXNJZCB0aGUgaWQgb2YgdGhlIGJvbnVzIHdoaWNoIHdpbGwgYmUgZGVsZXRlZFxuICAgICAqL1xuICAgIGRlbGV0ZUJvbnVzKGNvdXJzZUlkOiBudW1iZXIsIGV4YW1JZDogbnVtYmVyLCBib251c0lkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTx2b2lkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmRlbGV0ZTx2b2lkPihgJHt0aGlzLnJlc291cmNlVXJsfS9jb3Vyc2VzLyR7Y291cnNlSWR9L2V4YW1zLyR7ZXhhbUlkfS9ib251cy8ke2JvbnVzSWR9YCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFN0b3JlIGEgbmV3IGJvbnVzIGZvciBleGFtIG9uIHRoZSBzZXJ2ZXJcbiAgICAgKlxuICAgICAqIEBwYXJhbSBjb3Vyc2VJZCB0aGUgY291cnNlIHRvIHdoaWNoIHRoZSBleGFtIGJlbG9uZ3NcbiAgICAgKiBAcGFyYW0gZXhhbUlkIHRoZSBleGFtIGZvciB3aGljaCB0aGUgYm9udXMgd2lsbCBiZSBjcmVhdGVkXG4gICAgICogQHBhcmFtIGJvbnVzIHRoZSBib251cyB0byBiZSBjcmVhdGVkXG4gICAgICovXG4gICAgY3JlYXRlQm9udXNGb3JFeGFtKGNvdXJzZUlkOiBudW1iZXIsIGV4YW1JZDogbnVtYmVyLCBib251czogQm9udXMpOiBPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8Qm9udXM+KGAke3RoaXMucmVzb3VyY2VVcmx9L2NvdXJzZXMvJHtjb3Vyc2VJZH0vZXhhbXMvJHtleGFtSWR9L2JvbnVzYCwgdGhpcy5maWx0ZXJCb251c0ZvclJlcXVlc3QoYm9udXMpLCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlIGEgYm9udXMgb24gdGhlIHNlcnZlclxuICAgICAqXG4gICAgICogQHBhcmFtIGNvdXJzZUlkIHRoZSBjb3Vyc2UgdG8gd2hpY2ggdGhlIGV4YW0gYmVsb25nc1xuICAgICAqIEBwYXJhbSBleGFtSWQgdGhlIGV4YW0gZm9yIHdoaWNoIHRoZSBib251cyB3aWxsIGJlIHVwZGF0ZWRcbiAgICAgKiBAcGFyYW0gYm9udXMgdGhlIGJvbnVzIHRvIGJlIHVwZGF0ZWRcbiAgICAgKi9cbiAgICB1cGRhdGVCb251cyhjb3Vyc2VJZDogbnVtYmVyLCBleGFtSWQ6IG51bWJlciwgYm9udXM6IEJvbnVzKTogT2JzZXJ2YWJsZTxFbnRpdHlSZXNwb25zZVR5cGU+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8Qm9udXM+KGAke3RoaXMucmVzb3VyY2VVcmx9L2NvdXJzZXMvJHtjb3Vyc2VJZH0vZXhhbXMvJHtleGFtSWR9L2JvbnVzLyR7Ym9udXMuaWR9YCwgdGhpcy5maWx0ZXJCb251c0ZvclJlcXVlc3QoYm9udXMpLCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0cmlldmVzIHRoZSBib251cyBmb3IgZXhhbVxuICAgICAqXG4gICAgICogQHBhcmFtIGNvdXJzZUlkIHRoZSBjb3Vyc2UgdG8gd2hpY2ggdGhlIGV4YW0gYmVsb25nc1xuICAgICAqIEBwYXJhbSBleGFtSWQgdGhlIGV4YW0gZm9yIHdoaWNoIHRoZSBib251cyB3aWxsIGJlIHJldHJpZXZlZFxuICAgICAqIEBwYXJhbSBpbmNsdWRlU291cmNlR3JhZGVTdGVwcyBvcHRpb25hbCwgc3BlY2lmaWVzIHdoZXRoZXIgdGhlIHJldHVybmVkIHJlc3VsdCBzaG91bGQgaW5jbHVkZSB0aGUgZ3JhZGUgc3RlcHMgb2Ygc291cmNlR3JhZGluZ1NjYWxlLiBCeSBkZWZhdWx0LCB0aGV5IGFyZSBleGNsdWRlZFxuICAgICAqL1xuICAgIGZpbmRCb251c0ZvckV4YW0oY291cnNlSWQ6IG51bWJlciwgZXhhbUlkOiBudW1iZXIsIGluY2x1ZGVTb3VyY2VHcmFkZVN0ZXBzPzogYm9vbGVhbik6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIGNvbnN0IHBhcmFtcyA9IGluY2x1ZGVTb3VyY2VHcmFkZVN0ZXBzICE9IHVuZGVmaW5lZCA/IG5ldyBIdHRwUGFyYW1zKCkuc2V0KCdpbmNsdWRlU291cmNlR3JhZGVTdGVwcycsIGluY2x1ZGVTb3VyY2VHcmFkZVN0ZXBzLnRvU3RyaW5nKCkpIDogdW5kZWZpbmVkO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldDxCb251cz4oYCR7dGhpcy5yZXNvdXJjZVVybH0vY291cnNlcy8ke2NvdXJzZUlkfS9leGFtcy8ke2V4YW1JZH0vYm9udXNgLCB7IG9ic2VydmU6ICdyZXNwb25zZScsIHBhcmFtcyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZW5lcmF0ZXMgY2FsY3VsYXRpb24gZXhhbXBsZXMgdG8gZ2l2ZSB1c2VycyBhbiBpZGVhIGhvdyB0aGUgYm9udXMgd2lsbCBjb250cmlidXRlIHRvIHRoZSBmaW5hbCBncmFkZS5cbiAgICAgKiBUaGUgZ2VuZXJhdGVkIHZhbHVlcyBpbmNsdWRlcyBtYXgsIG1pbiBncmFkZXMgYW5kIHNvbWUgaW50ZXJtZWRpYXRlIGdyYWRlIHN0ZXAgYm91bmRhcmllcy5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBib251cyBib251cy5zb3VyY2VHcmFkaW5nU2NhbGUuZ3JhZGVTdGVwcyBhcmUgYXNzdW1lZCB0byBiZSBzb3J0ZWRcbiAgICAgKiBAcGFyYW0gYm9udXNUbyBncmFkZVN0ZXBzIGFyZSBhc3N1bWVkIHRvIGJlIHNvcnRlZFxuICAgICAqL1xuICAgIGdlbmVyYXRlQm9udXNFeGFtcGxlcyhib251czogQm9udXMsIGJvbnVzVG86IEdyYWRlU3RlcHNEVE8pOiBCb251c0V4YW1wbGVbXSB7XG4gICAgICAgIGlmICghYm9udXMuc291cmNlR3JhZGluZ1NjYWxlKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEJvbnVzLnNvdXJjZUdyYWRpbmdTY2FsZSBpcyBlbXB0eTogJHtib251cy5zb3VyY2VHcmFkaW5nU2NhbGV9YCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYm9udXNFeGFtcGxlcyA9IHRoaXMuZ2VuZXJhdGVFeGFtcGxlRXhhbUFuZEJvbnVzUG9pbnRzKGJvbnVzVG8sIGJvbnVzLnNvdXJjZUdyYWRpbmdTY2FsZSk7XG4gICAgICAgIGJvbnVzRXhhbXBsZXMuZm9yRWFjaCgoYm9udXNFeGFtcGxlKSA9PiB0aGlzLmNhbGN1bGF0ZUZpbmFsR3JhZGUoYm9udXNFeGFtcGxlLCBib251cywgYm9udXNUbykpO1xuICAgICAgICByZXR1cm4gYm9udXNFeGFtcGxlcztcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGEgZmlsdGVyZWQgYm9udXMgdG8gc2VuZCBpbiB0aGUgcmVxdWVzdCBib2R5IHRvIHJlZHVjZSBwYXlsb2FkIHNpemUgYW5kIG1ha2UgdHJhY2tpbmcgdGhlIGNoYW5nZXMgZWFzaWVyIGZvclxuICAgICAqIGRpYWdub3NpcyBwdXJwb3NlcyBieSBmaWx0ZXJpbmcgb3V0IGlycmVsZXZhbnQgcGFydHMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gYm9udXMgdG8gYmUgc2VudCB0byB0aGUgc2VydmVyXG4gICAgICovXG4gICAgcHJpdmF0ZSBmaWx0ZXJCb251c0ZvclJlcXVlc3QoYm9udXM6IEJvbnVzKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5ib251cyxcbiAgICAgICAgICAgIHNvdXJjZUdyYWRpbmdTY2FsZTogYm9udXMuc291cmNlR3JhZGluZ1NjYWxlID8geyBpZDogYm9udXMuc291cmNlR3JhZGluZ1NjYWxlLmlkIH0gOiB1bmRlZmluZWQsXG4gICAgICAgICAgICBib251c1RvR3JhZGluZ1NjYWxlOiB1bmRlZmluZWQsXG4gICAgICAgIH07XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGV0ZXJtaW5lcyB0aGUgZXhhbXBsZSBpbnB1dCB2YWx1ZXMgZm9yIEJvbnVzRXhhbXBsZXMgKHN0dWRlbnRQb2ludHNPZkJvbnVzVG8gYW5kIHN0dWRlbnRQb2ludHNPZkJvbnVzU291cmNlKS5cbiAgICAgKiBUaGUgZ2VuZXJhdGVkIHZhbHVlcyBpbmNsdWRlcyBwb2ludHMgY29ycmVzcG9uZGluZyB0byBtYXgsIG1pbiBncmFkZXMgYW5kIHNvbWUgaW50ZXJtZWRpYXRlIGdyYWRlIHN0ZXAgYm91bmRhcmllcy5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBib251c1RvIGdyYWRlU3RlcHMgYXJlIGFzc3VtZWQgdG8gYmUgc29ydGVkXG4gICAgICogQHBhcmFtIHNvdXJjZSBncmFkZVN0ZXBzIGFyZSBhc3N1bWVkIHRvIGJlIHNvcnRlZFxuICAgICAqL1xuICAgIHByaXZhdGUgZ2VuZXJhdGVFeGFtcGxlRXhhbUFuZEJvbnVzUG9pbnRzKGJvbnVzVG86IEdyYWRlU3RlcHNEVE8sIHNvdXJjZTogR3JhZGluZ1NjYWxlKTogQm9udXNFeGFtcGxlW10ge1xuICAgICAgICBjb25zdCBleGFtcGxlczogQm9udXNFeGFtcGxlW10gPSBbXTtcbiAgICAgICAgZXhhbXBsZXMucHVzaChuZXcgQm9udXNFeGFtcGxlKDAsIHVuZGVmaW5lZCkpO1xuXG4gICAgICAgIGxldCBib251c1RvR3JhZGVTdGVwSW5kZXggPSBib251c1RvLmdyYWRlU3RlcHMuZmluZEluZGV4KChncykgPT4gZ3MuaXNQYXNzaW5nR3JhZGUpO1xuICAgICAgICBpZiAoYm9udXNUb0dyYWRlU3RlcEluZGV4IDwgMCkge1xuICAgICAgICAgICAgdGhyb3cgRXJyb3IoJ05vIHBhc3NpbmcgZ3JhZGUgd2FzIGZvdW5kIGZvciBib251c1RvIGdyYWRpbmcgc2NhbGUnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBzb3VyY2VHcmFkZVN0ZXBJbmRleCA9IHNvdXJjZS5ncmFkZVN0ZXBzLmxlbmd0aCAtIDE7XG5cbiAgICAgICAgY29uc3Qgc291cmNlTWF4UG9pbnRzID0gdGhpcy5ncmFkaW5nU3lzdGVtU2VydmljZS5nZXRHcmFkaW5nU2NhbGVNYXhQb2ludHMoc291cmNlKTtcblxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDM7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgYm9udXNUb0dyYWRlU3RlcCA9IGJvbnVzVG8uZ3JhZGVTdGVwc1tib251c1RvR3JhZGVTdGVwSW5kZXhdO1xuICAgICAgICAgICAgY29uc3Qgc3R1ZGVudFBvaW50c09mQm9udXNUbyA9IHRoaXMuZ2V0SW5jbHVkZWRCb3VuZGFyeVBvaW50cyhib251c1RvR3JhZGVTdGVwLCBib251c1RvLm1heFBvaW50cyEpID8/IHRoaXMuZmluZE1pZGRsZVBvaW50KGJvbnVzVG9HcmFkZVN0ZXApO1xuXG4gICAgICAgICAgICBjb25zdCBzb3VyY2VHcmFkZVN0ZXAgPSBzb3VyY2UuZ3JhZGVTdGVwc1tzb3VyY2VHcmFkZVN0ZXBJbmRleF07XG4gICAgICAgICAgICBjb25zdCBzdHVkZW50UG9pbnRzT2ZCb251c1NvdXJjZSA9IHRoaXMuZ2V0SW5jbHVkZWRCb3VuZGFyeVBvaW50cyhzb3VyY2VHcmFkZVN0ZXAsIHNvdXJjZU1heFBvaW50cykgPz8gdGhpcy5maW5kTWlkZGxlUG9pbnQoc291cmNlR3JhZGVTdGVwKTtcblxuICAgICAgICAgICAgZXhhbXBsZXMucHVzaChuZXcgQm9udXNFeGFtcGxlKHN0dWRlbnRQb2ludHNPZkJvbnVzVG8hLCBzdHVkZW50UG9pbnRzT2ZCb251c1NvdXJjZSEpKTtcblxuICAgICAgICAgICAgLy8gU291cmNlIGdyYWRlIHN0ZXBzIGRlc2NlbmQgYW5kIGJvbnVzVG8gZ3JhZGUgc3RlcHMgYXNjZW5kIHRvIHByb3ZpZGUgc29tZXdoYXQgbW9yZSBiYWxhbmNlZCBleGFtcGxlc1xuICAgICAgICAgICAgLy8gYWx0aG91Z2ggdGhpcyBpcyBub3QgYSBoYXJkIHJ1bGUuXG5cbiAgICAgICAgICAgIGlmIChpID09PSAwICYmIHNvdXJjZUdyYWRlU3RlcC5sb3dlckJvdW5kUG9pbnRzID09PSBzb3VyY2VNYXhQb2ludHMgJiYgIXNvdXJjZUdyYWRlU3RlcC5sb3dlckJvdW5kSW5jbHVzaXZlKSB7XG4gICAgICAgICAgICAgICAgLy8gRWRnZSBjYXNlIG9uIGZpcnN0IGl0ZXJhdGlvbjogVGhlIGNvbmRpdGlvbiBhYm92ZSBjYXVzZXMgdGhlIHNvdXJjZU1heFBvaW50cyB0byBiZSBpbmNsdWRlZCBpbiB0aGVcbiAgICAgICAgICAgICAgICAvLyBuZXh0IHNvdXJjZSBncmFkZSBzdGVwIHNvIHdlIHNob3VsZCBza2lwIGl0IHRvIG5vdCBoYXZlIGV4YW1wbGVzIHdpdGggZHVwbGljYXRlIGJvbnVzIHZhbHVlcy5cbiAgICAgICAgICAgICAgICBzb3VyY2VHcmFkZVN0ZXBJbmRleCA9IHRoaXMubW9kdWxvKHNvdXJjZUdyYWRlU3RlcEluZGV4IC0gMSwgc291cmNlLmdyYWRlU3RlcHMubGVuZ3RoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc291cmNlR3JhZGVTdGVwSW5kZXggPSB0aGlzLm1vZHVsbyhzb3VyY2VHcmFkZVN0ZXBJbmRleCAtIDEsIHNvdXJjZS5ncmFkZVN0ZXBzLmxlbmd0aCk7XG4gICAgICAgICAgICBib251c1RvR3JhZGVTdGVwSW5kZXggPSB0aGlzLm1vZHVsbyhib251c1RvR3JhZGVTdGVwSW5kZXggKyAxLCBib251c1RvLmdyYWRlU3RlcHMubGVuZ3RoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGJvbnVzVG9HcmFkZVN0ZXBJbmRleCA9IGJvbnVzVG8uZ3JhZGVTdGVwcy5sZW5ndGggLSAxO1xuICAgICAgICBjb25zdCBsYXN0Qm9udXNUb0dyYWRlU3RlcCA9IGJvbnVzVG8uZ3JhZGVTdGVwc1tib251c1RvR3JhZGVTdGVwSW5kZXhdO1xuICAgICAgICBjb25zdCBsYXN0U3R1ZGVudFBvaW50c09mQm9udXNUbyA9IHRoaXMuZ2V0SW5jbHVkZWRCb3VuZGFyeVBvaW50cyhsYXN0Qm9udXNUb0dyYWRlU3RlcCwgYm9udXNUby5tYXhQb2ludHMhKSA/PyB0aGlzLmZpbmRNaWRkbGVQb2ludChsYXN0Qm9udXNUb0dyYWRlU3RlcCk7XG5cbiAgICAgICAgbGV0IGxhc3RTb3VyY2VHcmFkZVN0ZXAgPSBzb3VyY2UuZ3JhZGVTdGVwc1tzb3VyY2VHcmFkZVN0ZXBJbmRleF07XG4gICAgICAgIGlmICh0aGlzLmdyYWRpbmdTeXN0ZW1TZXJ2aWNlLmdldE51bWVyaWNWYWx1ZUZvckdyYWRlTmFtZShsYXN0U291cmNlR3JhZGVTdGVwLmdyYWRlTmFtZSkgPT09IDApIHtcbiAgICAgICAgICAgIC8vIEEgbm9uLXplcm8gYm9udXMgc2VydmVzIGJldHRlciBhcyBhbiBleGFtcGxlLlxuICAgICAgICAgICAgbGFzdFNvdXJjZUdyYWRlU3RlcCA9IHNvdXJjZS5ncmFkZVN0ZXBzW3NvdXJjZS5ncmFkZVN0ZXBzLmxlbmd0aCAtIDFdO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGxhc3RTdHVkZW50UG9pbnRzT2ZCb251c1NvdXJjZSA9IHRoaXMuZ2V0SW5jbHVkZWRCb3VuZGFyeVBvaW50cyhsYXN0U291cmNlR3JhZGVTdGVwLCBzb3VyY2VNYXhQb2ludHMpID8/IHRoaXMuZmluZE1pZGRsZVBvaW50KGxhc3RTb3VyY2VHcmFkZVN0ZXApO1xuXG4gICAgICAgIGV4YW1wbGVzLnB1c2gobmV3IEJvbnVzRXhhbXBsZShsYXN0U3R1ZGVudFBvaW50c09mQm9udXNUbyEsIGxhc3RTdHVkZW50UG9pbnRzT2ZCb251c1NvdXJjZSEpKTtcblxuICAgICAgICByZXR1cm4gZXhhbXBsZXM7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBmaW5kTWlkZGxlUG9pbnQoZ3JhZGVTdGVwOiBHcmFkZVN0ZXApIHtcbiAgICAgICAgcmV0dXJuICgoZ3JhZGVTdGVwLmxvd2VyQm91bmRQb2ludHMgPz8gMCkgKyAoZ3JhZGVTdGVwLnVwcGVyQm91bmRQb2ludHMgPz8gMCkpIC8gMjtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBBcHBsaWVzIGJvbnVzIGZyb20gYm9udXMuc291cmNlR3JhZGluZ1NjYWxlIHRvIGJvbnVzVG9HcmFkaW5nU2NhbGUgZ3JhZGUgc3RlcHMgd2l0aCBzdHVkZW50IHBvaW50cyBmcm9tIGJvbnVzRXhhbXBsZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBib251c0V4YW1wbGUgTW9kaWZpZWQgYnkgdGhpcyBtZXRob2QuIHN0dWRlbnRQb2ludHNPZkJvbnVzU291cmNlIGFuZCBzdHVkZW50UG9pbnRzT2ZCb251c1NvdXJjZSBmaWVsZHMgYXJlIHJlYWQsIG90aGVycyBhcmUgKG92ZXIpd3JpdHRlblxuICAgICAqIEBwYXJhbSBib251cyBDb250YWlucyBjYWxjdWxhdGlvbiBpbnN0cnVjdGlvbnMgYW5kIHNvdXJjZSBncmFkaW5nIHNjYWxlXG4gICAgICogQHBhcmFtIGJvbnVzVG8gR3JhZGluZyBzY2FsZSB0aGF0IHdpbGwgaGF2ZSBpdHMgZ3JhZGVzIGltcHJvdmVkIGJ5IGJvbnVzXG4gICAgICovXG4gICAgY2FsY3VsYXRlRmluYWxHcmFkZShib251c0V4YW1wbGU6IEJvbnVzRXhhbXBsZSwgYm9udXM6IEJvbnVzLCBib251c1RvOiBHcmFkZVN0ZXBzRFRPKSB7XG4gICAgICAgIGNvbnN0IGV4YW1HcmFkZVN0ZXAgPSB0aGlzLmdyYWRpbmdTeXN0ZW1TZXJ2aWNlLmZpbmRNYXRjaGluZ0dyYWRlU3RlcEJ5UG9pbnRzKGJvbnVzVG8uZ3JhZGVTdGVwcywgYm9udXNFeGFtcGxlLnN0dWRlbnRQb2ludHNPZkJvbnVzVG8sIGJvbnVzVG8ubWF4UG9pbnRzISk7XG4gICAgICAgIGJvbnVzRXhhbXBsZS5leGFtR3JhZGUgPSBleGFtR3JhZGVTdGVwPy5ncmFkZU5hbWU7XG5cbiAgICAgICAgaWYgKCFleGFtR3JhZGVTdGVwPy5pc1Bhc3NpbmdHcmFkZSB8fCAhYm9udXMuc291cmNlR3JhZGluZ1NjYWxlKSB7XG4gICAgICAgICAgICBib251c0V4YW1wbGUuYm9udXNHcmFkZSA9IDA7XG4gICAgICAgICAgICBib251c0V4YW1wbGUuZmluYWxQb2ludHMgPSBib251c0V4YW1wbGUuc3R1ZGVudFBvaW50c09mQm9udXNUbztcbiAgICAgICAgICAgIGJvbnVzRXhhbXBsZS5maW5hbEdyYWRlID0gYm9udXNFeGFtcGxlLmV4YW1HcmFkZTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGJvbnVzR3JhZGVTdGVwID0gdGhpcy5ncmFkaW5nU3lzdGVtU2VydmljZS5maW5kTWF0Y2hpbmdHcmFkZVN0ZXBCeVBvaW50cyhcbiAgICAgICAgICAgIGJvbnVzLnNvdXJjZUdyYWRpbmdTY2FsZS5ncmFkZVN0ZXBzLFxuICAgICAgICAgICAgYm9udXNFeGFtcGxlLnN0dWRlbnRQb2ludHNPZkJvbnVzU291cmNlID8/IDAsXG4gICAgICAgICAgICB0aGlzLmdyYWRpbmdTeXN0ZW1TZXJ2aWNlLmdldEdyYWRpbmdTY2FsZU1heFBvaW50cyhib251cy5zb3VyY2VHcmFkaW5nU2NhbGUpLFxuICAgICAgICApO1xuICAgICAgICBib251c0V4YW1wbGUuYm9udXNHcmFkZSA9IHRoaXMuZ3JhZGluZ1N5c3RlbVNlcnZpY2UuZ2V0TnVtZXJpY1ZhbHVlRm9yR3JhZGVOYW1lKGJvbnVzR3JhZGVTdGVwPy5ncmFkZU5hbWUpO1xuXG4gICAgICAgIHRoaXMuY2FsY3VsYXRlQm9udXNGb3JTdHJhdGVneShib251c0V4YW1wbGUsIGJvbnVzLCBib251c1RvKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiB7QHNlZSBjYWxjdWxhdGVGaW5hbEdyYWRlfS4gVGhpcyBtZXRob2QgY29udGFpbnMgdGhlIGNhbGN1bGF0aW9uIGxvZ2ljIGZvciBlYWNoIGJvbnVzIHN0cmF0ZWd5LiBEb2VzIG5vdCBwZXJmb3JtIHBhc3NpbmcgZ3JhZGUgY2hlY2suXG4gICAgICogQHBhcmFtIGJvbnVzRXhhbXBsZSBNb2RpZmllZCBieSB0aGlzIG1ldGhvZC4gc3R1ZGVudFBvaW50c09mQm9udXNTb3VyY2UsIHN0dWRlbnRQb2ludHNPZkJvbnVzU291cmNlIGFuZCBib251c0dyYWRlIGZpZWxkcyBhcmUgcmVhZCwgb3RoZXJzIGFyZSAob3Zlcil3cml0dGVuXG4gICAgICogQHBhcmFtIGJvbnVzIENvbnRhaW5zIGNhbGN1bGF0aW9uIGluc3RydWN0aW9ucyBhbmQgc291cmNlIGdyYWRpbmcgc2NhbGVcbiAgICAgKiBAcGFyYW0gYm9udXNUbyBHcmFkaW5nIHNjYWxlIHRoYXQgd2lsbCBoYXZlIGl0cyBncmFkZXMgaW1wcm92ZWQgYnkgYm9udXNcbiAgICAgKi9cbiAgICBwcml2YXRlIGNhbGN1bGF0ZUJvbnVzRm9yU3RyYXRlZ3koYm9udXNFeGFtcGxlOiBCb251c0V4YW1wbGUsIGJvbnVzOiBCb251cywgYm9udXNUbzogR3JhZGVTdGVwc0RUTykge1xuICAgICAgICBjb25zdCBjb3Vyc2UgPSB0aGlzLmdyYWRpbmdTeXN0ZW1TZXJ2aWNlLmdldEdyYWRpbmdTY2FsZUNvdXJzZShib251cy5ib251c1RvR3JhZGluZ1NjYWxlKTtcbiAgICAgICAgc3dpdGNoIChib251cy5ib251c1N0cmF0ZWd5KSB7XG4gICAgICAgICAgICBjYXNlIEJvbnVzU3RyYXRlZ3kuUE9JTlRTOiB7XG4gICAgICAgICAgICAgICAgYm9udXNFeGFtcGxlLmZpbmFsUG9pbnRzID0gcm91bmRWYWx1ZVNwZWNpZmllZEJ5Q291cnNlU2V0dGluZ3MoYm9udXNFeGFtcGxlLnN0dWRlbnRQb2ludHNPZkJvbnVzVG8gKyAoYm9udXMud2VpZ2h0ID8/IDEpICogYm9udXNFeGFtcGxlLmJvbnVzR3JhZGUhLCBjb3Vyc2UpO1xuXG4gICAgICAgICAgICAgICAgYm9udXNFeGFtcGxlLmV4Y2VlZHNNYXggPSB0aGlzLmRvZXNCb251c0V4Y2VlZE1heChib251c0V4YW1wbGUuZmluYWxQb2ludHMsIGJvbnVzVG8ubWF4UG9pbnRzISwgYm9udXMud2VpZ2h0ISk7XG4gICAgICAgICAgICAgICAgaWYgKGJvbnVzRXhhbXBsZS5leGNlZWRzTWF4KSB7XG4gICAgICAgICAgICAgICAgICAgIGJvbnVzRXhhbXBsZS5maW5hbFBvaW50cyA9IGJvbnVzVG8ubWF4UG9pbnRzID8/IDA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IGZpbmFsR3JhZGVTdGVwID0gdGhpcy5ncmFkaW5nU3lzdGVtU2VydmljZS5maW5kTWF0Y2hpbmdHcmFkZVN0ZXBCeVBvaW50cyhib251c1RvLmdyYWRlU3RlcHMsIGJvbnVzRXhhbXBsZS5maW5hbFBvaW50cywgYm9udXNUby5tYXhQb2ludHMhKTtcbiAgICAgICAgICAgICAgICBib251c0V4YW1wbGUuZmluYWxHcmFkZSA9IGZpbmFsR3JhZGVTdGVwPy5ncmFkZU5hbWU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIEJvbnVzU3RyYXRlZ3kuR1JBREVTX0NPTlRJTlVPVVM6IHtcbiAgICAgICAgICAgICAgICBjb25zdCBleGFtR3JhZGVOdW1lcmljVmFsdWUgPSB0aGlzLmdyYWRpbmdTeXN0ZW1TZXJ2aWNlLmdldE51bWVyaWNWYWx1ZUZvckdyYWRlTmFtZShib251c0V4YW1wbGUuZXhhbUdyYWRlIGFzIHN0cmluZykhO1xuICAgICAgICAgICAgICAgIGJvbnVzRXhhbXBsZS5maW5hbEdyYWRlID0gcm91bmRWYWx1ZVNwZWNpZmllZEJ5Q291cnNlU2V0dGluZ3MoZXhhbUdyYWRlTnVtZXJpY1ZhbHVlICsgKGJvbnVzLndlaWdodCA/PyAxKSAqIGJvbnVzRXhhbXBsZS5ib251c0dyYWRlISwgY291cnNlKTtcbiAgICAgICAgICAgICAgICBjb25zdCBtYXhHcmFkZSA9IHRoaXMuZ3JhZGluZ1N5c3RlbVNlcnZpY2UubWF4R3JhZGUoYm9udXNUby5ncmFkZVN0ZXBzKTtcbiAgICAgICAgICAgICAgICBjb25zdCBtYXhHcmFkZU51bWVyaWNWYWx1ZSA9IHRoaXMuZ3JhZGluZ1N5c3RlbVNlcnZpY2UuZ2V0TnVtZXJpY1ZhbHVlRm9yR3JhZGVOYW1lKG1heEdyYWRlKSE7XG5cbiAgICAgICAgICAgICAgICBib251c0V4YW1wbGUuZXhjZWVkc01heCA9IHRoaXMuZG9lc0JvbnVzRXhjZWVkTWF4KGJvbnVzRXhhbXBsZS5maW5hbEdyYWRlLCBtYXhHcmFkZU51bWVyaWNWYWx1ZSwgYm9udXMud2VpZ2h0ISk7XG4gICAgICAgICAgICAgICAgaWYgKGJvbnVzRXhhbXBsZS5leGNlZWRzTWF4KSB7XG4gICAgICAgICAgICAgICAgICAgIGJvbnVzRXhhbXBsZS5maW5hbEdyYWRlID0gbWF4R3JhZGU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBCb251c1N0cmF0ZWd5LkdSQURFU19ESVNDUkVURToge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignR1JBREVTX0RJU0NSRVRFIGJvbnVzIHN0cmF0ZWd5IG5vdCB5ZXQgaW1wbGVtZW50ZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdHJ1ZSBpZiB2YWx1ZVdpdGhCb251cyBleGNlZWRzIHRoZSBtYXhWYWx1ZSBpbiB0aGUgZGlyZWN0aW9uIGdpdmVuIGJ5IGNhbGN1bGF0aW9uU2lnbi5cbiAgICAgKiBAcGFyYW0gdmFsdWVXaXRoQm9udXMgYWNoaWV2ZWQgcG9pbnRzIG9yIG51bWVyaWMgZ3JhZGUgd2l0aCBib251cyBhcHBsaWVkXG4gICAgICogQHBhcmFtIG1heFZhbHVlIG1heCBwb2ludHMgb3IgbWF4IGdyYWRlIChudW1lcmljKVxuICAgICAqIEBwYXJhbSBjYWxjdWxhdGlvblNpZ24gYSBuZWdhdGl2ZSBvciBwb3NpdGl2ZSBudW1iZXIgdG8gaW5kaWNhdGUgZGVjcmVhc2luZyBvciBpbmNyZWFzaW5nIGRpcmVjdGlvbiwgcmVzcGVjdGl2ZWx5XG4gICAgICovXG4gICAgZG9lc0JvbnVzRXhjZWVkTWF4KHZhbHVlV2l0aEJvbnVzOiBudW1iZXIsIG1heFZhbHVlOiBudW1iZXIsIGNhbGN1bGF0aW9uU2lnbjogbnVtYmVyKSB7XG4gICAgICAgIHJldHVybiAodmFsdWVXaXRoQm9udXMgLSBtYXhWYWx1ZSkgKiBjYWxjdWxhdGlvblNpZ24hID4gMDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgdGhlIGluY2x1ZGVkIHBvaW50c1xuICAgICAqIEBwYXJhbSBncmFkZVN0ZXBcbiAgICAgKiBAcGFyYW0gbWF4UG9pbnRzXG4gICAgICovXG4gICAgZ2V0SW5jbHVkZWRCb3VuZGFyeVBvaW50cyhncmFkZVN0ZXA6IEdyYWRlU3RlcCwgbWF4UG9pbnRzOiBudW1iZXIpIHtcbiAgICAgICAgaWYgKGdyYWRlU3RlcC5sb3dlckJvdW5kSW5jbHVzaXZlKSB7XG4gICAgICAgICAgICByZXR1cm4gZ3JhZGVTdGVwLmxvd2VyQm91bmRQb2ludHM7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGdyYWRlU3RlcC51cHBlckJvdW5kSW5jbHVzaXZlKSB7XG4gICAgICAgICAgICByZXR1cm4gTWF0aC5taW4oZ3JhZGVTdGVwLnVwcGVyQm91bmRQb2ludHMhLCBtYXhQb2ludHMpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQXMgb3Bwb3NlZCB0byAlIG9wZXJhdG9yLCB0aGlzIG1ldGhvZCBhbHdheXMgcmV0dXJucyBhIG5vbi1uZWdhdGl2ZSBudW1iZXIuXG4gICAgICogQHBhcmFtIG4gYXMgaW4gbiBtb2QgbVxuICAgICAqIEBwYXJhbSBtIGFzIGluIG4gbW9kIG1cbiAgICAgKi9cbiAgICBwcml2YXRlIG1vZHVsbyhuOiBudW1iZXIsIG06IG51bWJlcikge1xuICAgICAgICByZXR1cm4gKChuICUgbSkgKyBtKSAlIG07XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBHcmFkaW5nU3lzdGVtU2VydmljZSB9IGZyb20gJ2FwcC9ncmFkaW5nLXN5c3RlbS9ncmFkaW5nLXN5c3RlbS5zZXJ2aWNlJztcbmltcG9ydCB7IEdyYWRlU3RlcCwgR3JhZGVTdGVwc0RUTyB9IGZyb20gJ2FwcC9lbnRpdGllcy9ncmFkZS1zdGVwLm1vZGVsJztcbmltcG9ydCB7IEdyYWRlVHlwZSwgR3JhZGluZ1NjYWxlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2dyYWRpbmctc2NhbGUubW9kZWwnO1xuaW1wb3J0IHsgZmFDaGV2cm9uTGVmdCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBHcmFkZUVkaXRNb2RlIH0gZnJvbSAnYXBwL2dyYWRpbmctc3lzdGVtL2Jhc2UtZ3JhZGluZy1zeXN0ZW0vYmFzZS1ncmFkaW5nLXN5c3RlbS5jb21wb25lbnQnO1xuaW1wb3J0IHsgQm9udXNTZXJ2aWNlIH0gZnJvbSAnYXBwL2dyYWRpbmctc3lzdGVtL2JvbnVzL2JvbnVzLnNlcnZpY2UnO1xuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgU2NvcmVzU3RvcmFnZVNlcnZpY2UgfSBmcm9tICdhcHAvY291cnNlL2NvdXJzZS1zY29yZXMvc2NvcmVzLXN0b3JhZ2Uuc2VydmljZSc7XG5pbXBvcnQgeyBTY29yZVR5cGUgfSBmcm9tICdhcHAvc2hhcmVkL2NvbnN0YW50cy9zY29yZS10eXBlLmNvbnN0YW50cyc7XG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBsb2FkR3JhZGluZ0tleVVybFBhcmFtcyB9IGZyb20gJ2FwcC9ncmFkaW5nLXN5c3RlbS9ncmFkaW5nLWtleS1vdmVydmlldy9ncmFkaW5nLWtleS1oZWxwZXInO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1ncmFkZS1rZXktdGFibGUnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9ncmFkaW5nLWtleS10YWJsZS5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4uL2dyYWRpbmcta2V5LW92ZXJ2aWV3LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgR3JhZGluZ0tleVRhYmxlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICByZWFkb25seSBmYUNoZXZyb25MZWZ0ID0gZmFDaGV2cm9uTGVmdDtcblxuICAgIHJlYWRvbmx5IEdyYWRlRWRpdE1vZGUgPSBHcmFkZUVkaXRNb2RlO1xuXG4gICAgQElucHV0KCkgc3R1ZGVudEdyYWRlT3JCb251c1BvaW50c09yR3JhZGVCb251cz86IHN0cmluZztcbiAgICBASW5wdXQoKSBmb3JCb251cz86IGJvb2xlYW47XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSByb3V0ZTogQWN0aXZhdGVkUm91dGUsXG4gICAgICAgIHByaXZhdGUgZ3JhZGluZ1N5c3RlbVNlcnZpY2U6IEdyYWRpbmdTeXN0ZW1TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGJvbnVzU2VydmljZTogQm9udXNTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHNjb3Jlc1N0b3JhZ2VTZXJ2aWNlOiBTY29yZXNTdG9yYWdlU2VydmljZSxcbiAgICApIHt9XG5cbiAgICBwbGFnaWFyaXNtR3JhZGU6IHN0cmluZztcbiAgICBub1BhcnRpY2lwYXRpb25HcmFkZTogc3RyaW5nO1xuXG4gICAgaXNFeGFtID0gZmFsc2U7XG5cbiAgICBjb3Vyc2VJZD86IG51bWJlcjtcbiAgICBleGFtSWQ/OiBudW1iZXI7XG5cbiAgICB0aXRsZT86IHN0cmluZztcbiAgICBncmFkZVN0ZXBzOiBHcmFkZVN0ZXBbXSA9IFtdO1xuICAgIGlzQm9udXMgPSBmYWxzZTtcblxuICAgIGhhc1BvaW50c1NldCA9IGZhbHNlO1xuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIGNvbnN0IHsgY291cnNlSWQsIGV4YW1JZCwgZm9yQm9udXMsIGlzRXhhbSwgc3R1ZGVudEdyYWRlT3JCb251c1BvaW50c09yR3JhZGVCb251cyB9ID0gbG9hZEdyYWRpbmdLZXlVcmxQYXJhbXModGhpcy5yb3V0ZSk7XG4gICAgICAgIHRoaXMuY291cnNlSWQgPSBjb3Vyc2VJZDtcbiAgICAgICAgdGhpcy5leGFtSWQgPSBleGFtSWQ7XG4gICAgICAgIHRoaXMuZm9yQm9udXMgPSB0aGlzLmZvckJvbnVzIHx8IGZvckJvbnVzO1xuICAgICAgICB0aGlzLmlzRXhhbSA9IGlzRXhhbTtcbiAgICAgICAgdGhpcy5zdHVkZW50R3JhZGVPckJvbnVzUG9pbnRzT3JHcmFkZUJvbnVzID0gdGhpcy5zdHVkZW50R3JhZGVPckJvbnVzUG9pbnRzT3JHcmFkZUJvbnVzIHx8IHN0dWRlbnRHcmFkZU9yQm9udXNQb2ludHNPckdyYWRlQm9udXM7XG5cbiAgICAgICAgdGhpcy5maW5kR3JhZGVTdGVwcyh0aGlzLmNvdXJzZUlkLCB0aGlzLmV4YW1JZCkuc3Vic2NyaWJlKChncmFkZVN0ZXBzKSA9PiB7XG4gICAgICAgICAgICBpZiAoZ3JhZGVTdGVwcykge1xuICAgICAgICAgICAgICAgIHRoaXMudGl0bGUgPSBncmFkZVN0ZXBzLnRpdGxlO1xuICAgICAgICAgICAgICAgIHRoaXMuaXNCb251cyA9IGdyYWRlU3RlcHMuZ3JhZGVUeXBlID09PSBHcmFkZVR5cGUuQk9OVVM7XG4gICAgICAgICAgICAgICAgdGhpcy5ncmFkZVN0ZXBzID0gdGhpcy5ncmFkaW5nU3lzdGVtU2VydmljZS5zb3J0R3JhZGVTdGVwcyhncmFkZVN0ZXBzLmdyYWRlU3RlcHMpO1xuICAgICAgICAgICAgICAgIHRoaXMucGxhZ2lhcmlzbUdyYWRlID0gZ3JhZGVTdGVwcy5wbGFnaWFyaXNtR3JhZGU7XG4gICAgICAgICAgICAgICAgdGhpcy5ub1BhcnRpY2lwYXRpb25HcmFkZSA9IGdyYWRlU3RlcHMubm9QYXJ0aWNpcGF0aW9uR3JhZGU7XG4gICAgICAgICAgICAgICAgaWYgKGdyYWRlU3RlcHMubWF4UG9pbnRzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF0aGlzLmlzRXhhbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG1heFBvaW50cyA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0b3RhbFNjb3Jlc0ZvckNvdXJzZSA9IHRoaXMuc2NvcmVzU3RvcmFnZVNlcnZpY2UuZ2V0U3RvcmVkVG90YWxTY29yZXModGhpcy5jb3Vyc2VJZCEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRvdGFsU2NvcmVzRm9yQ291cnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4UG9pbnRzID0gdG90YWxTY29yZXNGb3JDb3Vyc2VbU2NvcmVUeXBlLlJFQUNIQUJMRV9QT0lOVFNdO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5ncmFkaW5nU3lzdGVtU2VydmljZS5zZXRHcmFkZVBvaW50cyh0aGlzLmdyYWRlU3RlcHMsIG1heFBvaW50cyk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBmb3IgZXhhbXMgdGhlIG1heCBwb2ludHMgZmlsZWQgc2hvdWxkIGVxdWFsIHRoZSB0b3RhbCBtYXggcG9pbnRzIChvdGhlcndpc2UgZXhhbXMgY2FuJ3QgYmUgc3RhcnRlZClcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ3JhZGluZ1N5c3RlbVNlcnZpY2Uuc2V0R3JhZGVQb2ludHModGhpcy5ncmFkZVN0ZXBzLCBncmFkZVN0ZXBzLm1heFBvaW50cyEpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLmhhc1BvaW50c1NldCA9IHRoaXMuZ3JhZGluZ1N5c3RlbVNlcnZpY2UuaGFzUG9pbnRzU2V0KHRoaXMuZ3JhZGVTdGVwcyk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBmaW5kR3JhZGVTdGVwcyhjb3Vyc2VJZDogbnVtYmVyLCBleGFtSWQ/OiBudW1iZXIpOiBPYnNlcnZhYmxlPEdyYWRlU3RlcHNEVE8gfCB1bmRlZmluZWQ+IHtcbiAgICAgICAgaWYgKCF0aGlzLmZvckJvbnVzKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5ncmFkaW5nU3lzdGVtU2VydmljZS5maW5kR3JhZGVTdGVwcyhjb3Vyc2VJZCwgZXhhbUlkKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIGV4YW1JZCBtdXN0IGJlIHByZXNlbnQgaWYgZm9yQm9udXMgaXMgdHJ1ZS5cbiAgICAgICAgICAgIHJldHVybiB0aGlzLmJvbnVzU2VydmljZS5maW5kQm9udXNGb3JFeGFtKGNvdXJzZUlkLCBleGFtSWQhLCB0cnVlKS5waXBlKFxuICAgICAgICAgICAgICAgIG1hcCgoYm9udXNSZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzb3VyY2UgPSBib251c1Jlc3BvbnNlLmJvZHk/LnNvdXJjZUdyYWRpbmdTY2FsZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFzb3VyY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiB0aGlzLmdyYWRpbmdTeXN0ZW1TZXJ2aWNlLmdldEdyYWRpbmdTY2FsZVRpdGxlKHNvdXJjZSkhLFxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JhZGVUeXBlOiBzb3VyY2UuZ3JhZGVUeXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JhZGVTdGVwczogc291cmNlLmdyYWRlU3RlcHMsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXhQb2ludHM6IHRoaXMuZ3JhZGluZ1N5c3RlbVNlcnZpY2UuZ2V0R3JhZGluZ1NjYWxlTWF4UG9pbnRzKHNvdXJjZSksXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFnaWFyaXNtR3JhZGU6IHNvdXJjZS5wbGFnaWFyaXNtR3JhZGUgfHwgR3JhZGluZ1NjYWxlLkRFRkFVTFRfUExBR0lBUklTTV9HUkFERSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vUGFydGljaXBhdGlvbkdyYWRlOiBzb3VyY2Uubm9QYXJ0aWNpcGF0aW9uR3JhZGUgfHwgR3JhZGluZ1NjYWxlLkRFRkFVTFRfTk9fUEFSVElDSVBBVElPTl9HUkFERSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByZXNlbnRhdGlvbnNOdW1iZXI6IHNvdXJjZS5wcmVzZW50YXRpb25zTnVtYmVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJlc2VudGF0aW9uc1dlaWdodDogc291cmNlLnByZXNlbnRhdGlvbnNXZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiPGRpdj5cbiAgICBAaWYgKCFpc0V4YW0pIHtcbiAgICAgICAgPGg2Pnt7ICdhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0ub3ZlcnZpZXcuaW5mbycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9oNj5cbiAgICB9XG4gICAgPGRpdj5cbiAgICAgICAgPHRhYmxlIGNsYXNzPVwidGFibGUgdGFibGUtc3RyaXBlZFwiPlxuICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgPHRoPnt7IGlzQm9udXMgPyAoJ2FydGVtaXNBcHAuZXhhbS5leGFtU3VtbWFyeS5ib251cycgfCBhcnRlbWlzVHJhbnNsYXRlKSA6ICgnYXJ0ZW1pc0FwcC5leGFtLmV4YW1TdW1tYXJ5LmdyYWRlJyB8IGFydGVtaXNUcmFuc2xhdGUpIH19PC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoPnt7ICdhcnRlbWlzQXBwLmV4YW0uZXhhbVN1bW1hcnkuaW50ZXJ2YWwnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvdGg+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoaGFzUG9pbnRzU2V0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGg+e3sgJ2FydGVtaXNBcHAuZXhhbS5leGFtU3VtbWFyeS5pbnRlcnZhbFBvaW50cycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC90aD5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgIEBpZiAocGxhZ2lhcmlzbUdyYWRlID09PSBzdHVkZW50R3JhZGVPckJvbnVzUG9pbnRzT3JHcmFkZUJvbnVzKSB7XG4gICAgICAgICAgICAgICAgICAgIDx0ciBbY2xhc3MuaGlnaGxpZ2h0ZWRdPVwicGxhZ2lhcmlzbUdyYWRlID09PSBzdHVkZW50R3JhZGVPckJvbnVzUG9pbnRzT3JHcmFkZUJvbnVzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgcGxhZ2lhcmlzbUdyYWRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1oZWxwLWljb24gcGxhY2VtZW50PVwiYXV0b1wiIHRleHQ9XCJhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0ucGxhZ2lhcmlzbUdyYWRlSGVscFwiPjwvamhpLWhlbHAtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8IS0tICZtZGFzaDsgaXMgdXNlZCB0byBpbmRpY2F0ZSB0aGF0IHRoaXMgc3BlY2lhbCBncmFkZSBkb2VzIG5vdCBjb3JyZXNwb25kIHRvIGEgbnVtZXJpYyBpbnRlcnZhbC4gLS0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+Jm1kYXNoOzwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGhhc1BvaW50c1NldCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD4mbWRhc2g7PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmIChub1BhcnRpY2lwYXRpb25HcmFkZSA9PT0gc3R1ZGVudEdyYWRlT3JCb251c1BvaW50c09yR3JhZGVCb251cykge1xuICAgICAgICAgICAgICAgICAgICA8dHIgW2NsYXNzLmhpZ2hsaWdodGVkXT1cIm5vUGFydGljaXBhdGlvbkdyYWRlID09PSBzdHVkZW50R3JhZGVPckJvbnVzUG9pbnRzT3JHcmFkZUJvbnVzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgbm9QYXJ0aWNpcGF0aW9uR3JhZGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLWhlbHAtaWNvbiBwbGFjZW1lbnQ9XCJhdXRvXCIgdGV4dD1cImFydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5ub1BhcnRpY2lwYXRpb25HcmFkZUhlbHBcIj48L2poaS1oZWxwLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPCEtLSAmbWRhc2g7IGlzIHVzZWQgdG8gaW5kaWNhdGUgdGhhdCB0aGlzIHNwZWNpYWwgZ3JhZGUgZG9lcyBub3QgY29ycmVzcG9uZCB0byBhIG51bWVyaWMgaW50ZXJ2YWwuIC0tPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPiZtZGFzaDs8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChoYXNQb2ludHNTZXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+Jm1kYXNoOzwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEBmb3IgKGdyYWRlU3RlcCBvZiBncmFkZVN0ZXBzOyB0cmFjayBncmFkZVN0ZXA7IGxldCBsYXN0ID0gJGxhc3QpIHtcbiAgICAgICAgICAgICAgICAgICAgPHRyIFtjbGFzcy5oaWdobGlnaHRlZF09XCJncmFkZVN0ZXAuZ3JhZGVOYW1lID09PSBzdHVkZW50R3JhZGVPckJvbnVzUG9pbnRzT3JHcmFkZUJvbnVzIHx8ICtncmFkZVN0ZXAuZ3JhZGVOYW1lID09PSArc3R1ZGVudEdyYWRlT3JCb251c1BvaW50c09yR3JhZGVCb251cyFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57eyBncmFkZVN0ZXAuZ3JhZGVOYW1lIH19PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBbaW5uZXJIVE1MXT1cImdyYWRlU3RlcCB8IGdyYWRlU3RlcEJvdW5kczogR3JhZGVFZGl0TW9kZS5QRVJDRU5UQUdFIDogbGFzdCB8IHNhZmVIdG1sXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoaGFzUG9pbnRzU2V0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBbaW5uZXJIVE1MXT1cImdyYWRlU3RlcCB8IGdyYWRlU3RlcEJvdW5kczogR3JhZGVFZGl0TW9kZS5QT0lOVFMgOiBsYXN0IHwgc2FmZUh0bWxcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICA8L3RhYmxlPlxuICAgIDwvZGl2PlxuICAgIDxkaXY+XG4gICAgICAgIDxoNj57eyAnYXJ0ZW1pc0FwcC5ncmFkaW5nU3lzdGVtLm92ZXJ2aWV3LmludGVydmFscy50aXRsZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9oNj5cbiAgICAgICAgPHVsPlxuICAgICAgICAgICAgPGxpPjxzcGFuIHN0eWxlPVwiZm9udC13ZWlnaHQ6IGJvbGRcIj5bYSwgYik8L3NwYW4+OiB7eyAnYXJ0ZW1pc0FwcC5ncmFkaW5nU3lzdGVtLm92ZXJ2aWV3LmludGVydmFscy5sZWZ0SW5jbHVzaXZlUmlnaHRFeGNsdXNpdmUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvbGk+XG4gICAgICAgICAgICA8bGk+PHNwYW4gc3R5bGU9XCJmb250LXdlaWdodDogYm9sZFwiPihhLCBiXTwvc3Bhbj46IHt7ICdhcnRlbWlzQXBwLmdyYWRpbmdTeXN0ZW0ub3ZlcnZpZXcuaW50ZXJ2YWxzLmxlZnRFeGNsdXNpdmVSaWdodEluY2x1c2l2ZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9saT5cbiAgICAgICAgICAgIDxsaT48c3BhbiBzdHlsZT1cImZvbnQtd2VpZ2h0OiBib2xkXCI+W2EsIGJdPC9zcGFuPjoge3sgJ2FydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5vdmVydmlldy5pbnRlcnZhbHMuYm90aEluY2x1c2l2ZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9saT5cbiAgICAgICAgPC91bD5cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IEdyYWRpbmdTeXN0ZW1TZXJ2aWNlIH0gZnJvbSAnYXBwL2dyYWRpbmctc3lzdGVtL2dyYWRpbmctc3lzdGVtLnNlcnZpY2UnO1xuaW1wb3J0IHsgR3JhZGVTdGVwIH0gZnJvbSAnYXBwL2VudGl0aWVzL2dyYWRlLXN0ZXAubW9kZWwnO1xuaW1wb3J0IHsgQXJ0ZW1pc05hdmlnYXRpb25VdGlsU2VydmljZSB9IGZyb20gJ2FwcC91dGlscy9uYXZpZ2F0aW9uLnV0aWxzJztcbmltcG9ydCB7IGZhQ2hldnJvbkxlZnQsIGZhUHJpbnQgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgVGhlbWVTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvdGhlbWUvdGhlbWUuc2VydmljZSc7XG5pbXBvcnQgeyBsb2FkR3JhZGluZ0tleVVybFBhcmFtcyB9IGZyb20gJ2FwcC9ncmFkaW5nLXN5c3RlbS9ncmFkaW5nLWtleS1vdmVydmlldy9ncmFkaW5nLWtleS1oZWxwZXInO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1ncmFkZS1rZXktb3ZlcnZpZXcnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9ncmFkaW5nLWtleS1vdmVydmlldy5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vZ3JhZGluZy1rZXktb3ZlcnZpZXcuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBHcmFkaW5nS2V5T3ZlcnZpZXdDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIHJlYWRvbmx5IGZhQ2hldnJvbkxlZnQgPSBmYUNoZXZyb25MZWZ0O1xuICAgIHJlYWRvbmx5IGZhUHJpbnQgPSBmYVByaW50O1xuXG4gICAgcGxhZ2lhcmlzbUdyYWRlOiBzdHJpbmc7XG4gICAgbm9QYXJ0aWNpcGF0aW9uR3JhZGU6IHN0cmluZztcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSxcbiAgICAgICAgcHJpdmF0ZSBncmFkaW5nU3lzdGVtU2VydmljZTogR3JhZGluZ1N5c3RlbVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgbmF2aWdhdGlvblV0aWxTZXJ2aWNlOiBBcnRlbWlzTmF2aWdhdGlvblV0aWxTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHRoZW1lU2VydmljZTogVGhlbWVTZXJ2aWNlLFxuICAgICkge31cblxuICAgIGlzRXhhbSA9IGZhbHNlO1xuXG4gICAgY291cnNlSWQ/OiBudW1iZXI7XG4gICAgZXhhbUlkPzogbnVtYmVyO1xuXG4gICAgdGl0bGU/OiBzdHJpbmc7XG4gICAgZ3JhZGVTdGVwczogR3JhZGVTdGVwW10gPSBbXTtcbiAgICBzdHVkZW50R3JhZGVPckJvbnVzUG9pbnRzT3JHcmFkZUJvbnVzPzogc3RyaW5nO1xuICAgIGlzQm9udXMgPSBmYWxzZTtcbiAgICBmb3JCb251czogYm9vbGVhbjtcblxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICBjb25zdCB7IGNvdXJzZUlkLCBleGFtSWQsIGZvckJvbnVzLCBpc0V4YW0sIHN0dWRlbnRHcmFkZU9yQm9udXNQb2ludHNPckdyYWRlQm9udXMgfSA9IGxvYWRHcmFkaW5nS2V5VXJsUGFyYW1zKHRoaXMucm91dGUpO1xuXG4gICAgICAgIHRoaXMuY291cnNlSWQgPSBjb3Vyc2VJZDtcbiAgICAgICAgdGhpcy5leGFtSWQgPSBleGFtSWQ7XG4gICAgICAgIHRoaXMuZm9yQm9udXMgPSBmb3JCb251cztcbiAgICAgICAgdGhpcy5pc0V4YW0gPSBpc0V4YW07XG4gICAgICAgIHRoaXMuc3R1ZGVudEdyYWRlT3JCb251c1BvaW50c09yR3JhZGVCb251cyA9IHN0dWRlbnRHcmFkZU9yQm9udXNQb2ludHNPckdyYWRlQm9udXM7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTmF2aWdhdGVzIHRvIHRoZSBwcmV2aW91cyBwYWdlIChiYWNrIGJ1dHRvbiBvbiB0aGUgYnJvd3NlcilcbiAgICAgKi9cbiAgICBwcmV2aW91c1N0YXRlKCkge1xuICAgICAgICBjb25zdCBmYWxsYmFja1VybCA9IFsnY291cnNlcycsIHRoaXMuY291cnNlSWQhLnRvU3RyaW5nKCldO1xuICAgICAgICBpZiAodGhpcy5pc0V4YW0pIHtcbiAgICAgICAgICAgIGZhbGxiYWNrVXJsLnB1c2goJ2V4YW1zJywgdGhpcy5leGFtSWQhLnRvU3RyaW5nKCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZmFsbGJhY2tVcmwucHVzaCgnc3RhdGlzdGljcycpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubmF2aWdhdGlvblV0aWxTZXJ2aWNlLm5hdmlnYXRlQmFjayhmYWxsYmFja1VybCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRXhwb3J0cyBwYWdlIGFzIFBERlxuICAgICAqL1xuICAgIGFzeW5jIHByaW50UERGKCkge1xuICAgICAgICBhd2FpdCB0aGlzLnRoZW1lU2VydmljZS5wcmludCgpO1xuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJyb3cganVzdGlmeS1jb250ZW50LWNlbnRlclwiPlxuICAgIDxkaXYgY2xhc3M9XCJjb2wtNlwiPlxuICAgICAgICA8aDEgY2xhc3M9XCJ0ZXh0LWNlbnRlciBtYi0zXCI+XG4gICAgICAgICAgICB7eyAoZm9yQm9udXMgPyAnYXJ0ZW1pc0FwcC5ncmFkaW5nU3lzdGVtLnRpdGxlQm9udXMnIDogaXNFeGFtID8gJ2FydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS50aXRsZUV4YW0nIDogJ2FydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS50aXRsZUNvdXJzZScpIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAge3sgdGl0bGUgfX1cbiAgICAgICAgPC9oMT5cbiAgICAgICAgQGlmICghaXNFeGFtKSB7XG4gICAgICAgICAgICA8aDY+e3sgJ2FydGVtaXNBcHAuZ3JhZGluZ1N5c3RlbS5vdmVydmlldy5pbmZvJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2g2PlxuICAgICAgICB9XG4gICAgICAgIDxqaGktZ3JhZGUta2V5LXRhYmxlIC8+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnlcIiAoY2xpY2spPVwicHJldmlvdXNTdGF0ZSgpXCI+XG4gICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUNoZXZyb25MZWZ0XCI+PC9mYS1pY29uPiZuYnNwOzxzcGFuIGpoaVRyYW5zbGF0ZT1cImVudGl0eS5hY3Rpb24uYmFja1wiPiBCYWNrPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvbiBpZD1cImV4cG9ydFRvUERGQnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIiBzdHlsZT1cImZsb2F0OiByaWdodFwiIChjbGljayk9XCJwcmludFBERigpXCI+XG4gICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVByaW50XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5leGFtLmV4YW1TdW1tYXJ5LmV4cG9ydFBERlwiPkV4cG9ydCBQREY8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuPC9kaXY+XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVdNLFNBQVUsd0JBQXdCLE9BQXFCO0FBR3pELFFBQU0sV0FBVyxPQUFPLDBCQUEwQixPQUFPLFVBQVUsQ0FBQztBQUNwRSxNQUFJLFNBQVM7QUFDYixNQUFJLFNBQVM7QUFFYixRQUFNLGNBQWMsMEJBQTBCLE9BQU8sUUFBUTtBQUM3RCxNQUFJLGFBQWE7QUFDYixhQUFTLE9BQU8sV0FBVztBQUMzQixhQUFTOztBQUViLFFBQU0sV0FBVyxDQUFDLENBQUMsTUFBTSxTQUFTLEtBQUssVUFBVTtBQUdqRCxRQUFNLHdDQUF3QyxNQUFNLFNBQVMsWUFBWSxPQUFPO0FBRWhGLFNBQU87SUFDSDtJQUNBO0lBQ0E7SUFDQTtJQUNBOztBQUVSO0FBbkNBOzs7Ozs7O0FDSUEsSUFBYSxPQVVELGVBTUM7QUFoQmI7O0FBQU0sSUFBTyxRQUFQLE1BQVk7TUFDUDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BRVAsY0FBQTtNQUFlOztBQUduQixLQUFBLFNBQVlBLGdCQUFhO0FBQ3JCLE1BQUFBLGVBQUEsbUJBQUEsSUFBQTtBQUNBLE1BQUFBLGVBQUEsaUJBQUEsSUFBQTtBQUNBLE1BQUFBLGVBQUEsUUFBQSxJQUFBO0lBQ0osR0FKWSxrQkFBQSxnQkFBYSxDQUFBLEVBQUE7QUFNbkIsSUFBTyxlQUFQLE1BQW1CO01BUVY7TUFDQTtNQVJKO01BQ0E7TUFDQTtNQUNBO01BQ0EsYUFBYTtNQUVwQixZQUNXLHdCQUNBLDRCQUE4QztBQUQ5QyxhQUFBLHlCQUFBO0FBQ0EsYUFBQSw2QkFBQTtNQUNSOzs7Ozs7QUM5QlAsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxZQUFZLGtCQUFnQzs7O0FBRHJELElBWWE7QUFaYjs7QUFJQTtBQUVBO0FBQ0E7O0FBS00sSUFBTyxlQUFQLE1BQU8sY0FBWTtNQUlUO01BQ0E7TUFKTCxjQUFjO01BRXJCLFlBQ1ksTUFDQSxzQkFBMEM7QUFEMUMsYUFBQSxPQUFBO0FBQ0EsYUFBQSx1QkFBQTtNQUNUO01BU0gsWUFBWSxVQUFrQixRQUFnQixTQUFlO0FBQ3pELGVBQU8sS0FBSyxLQUFLLE9BQWEsR0FBRyxLQUFLLFdBQVcsWUFBWSxRQUFRLFVBQVUsTUFBTSxVQUFVLE9BQU8sSUFBSSxFQUFFLFNBQVMsV0FBVSxDQUFFO01BQ3JJO01BU0EsbUJBQW1CLFVBQWtCLFFBQWdCLE9BQVk7QUFDN0QsZUFBTyxLQUFLLEtBQUssS0FBWSxHQUFHLEtBQUssV0FBVyxZQUFZLFFBQVEsVUFBVSxNQUFNLFVBQVUsS0FBSyxzQkFBc0IsS0FBSyxHQUFHLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDNUo7TUFTQSxZQUFZLFVBQWtCLFFBQWdCLE9BQVk7QUFDdEQsZUFBTyxLQUFLLEtBQUssSUFBVyxHQUFHLEtBQUssV0FBVyxZQUFZLFFBQVEsVUFBVSxNQUFNLFVBQVUsTUFBTSxFQUFFLElBQUksS0FBSyxzQkFBc0IsS0FBSyxHQUFHLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDdks7TUFTQSxpQkFBaUIsVUFBa0IsUUFBZ0IseUJBQWlDO0FBQ2hGLGNBQU0sU0FBUywyQkFBMkIsU0FBWSxJQUFJLFdBQVUsRUFBRyxJQUFJLDJCQUEyQix3QkFBd0IsU0FBUSxDQUFFLElBQUk7QUFDNUksZUFBTyxLQUFLLEtBQUssSUFBVyxHQUFHLEtBQUssV0FBVyxZQUFZLFFBQVEsVUFBVSxNQUFNLFVBQVUsRUFBRSxTQUFTLFlBQVksT0FBTSxDQUFFO01BQ2hJO01BU0Esc0JBQXNCLE9BQWMsU0FBc0I7QUFDdEQsWUFBSSxDQUFDLE1BQU0sb0JBQW9CO0FBQzNCLGdCQUFNLElBQUksTUFBTSxzQ0FBc0MsTUFBTSxrQkFBa0IsRUFBRTs7QUFFcEYsY0FBTSxnQkFBZ0IsS0FBSyxrQ0FBa0MsU0FBUyxNQUFNLGtCQUFrQjtBQUM5RixzQkFBYyxRQUFRLENBQUMsaUJBQWlCLEtBQUssb0JBQW9CLGNBQWMsT0FBTyxPQUFPLENBQUM7QUFDOUYsZUFBTztNQUNYO01BUVEsc0JBQXNCLE9BQVk7QUFDdEMsZUFBTyxpQ0FDQSxRQURBO1VBRUgsb0JBQW9CLE1BQU0scUJBQXFCLEVBQUUsSUFBSSxNQUFNLG1CQUFtQixHQUFFLElBQUs7VUFDckYscUJBQXFCOztNQUU3QjtNQVNRLGtDQUFrQyxTQUF3QixRQUFvQjtBQUNsRixjQUFNLFdBQTJCLENBQUE7QUFDakMsaUJBQVMsS0FBSyxJQUFJLGFBQWEsR0FBRyxNQUFTLENBQUM7QUFFNUMsWUFBSSx3QkFBd0IsUUFBUSxXQUFXLFVBQVUsQ0FBQyxPQUFPLEdBQUcsY0FBYztBQUNsRixZQUFJLHdCQUF3QixHQUFHO0FBQzNCLGdCQUFNLE1BQU0sc0RBQXNEOztBQUd0RSxZQUFJLHVCQUF1QixPQUFPLFdBQVcsU0FBUztBQUV0RCxjQUFNLGtCQUFrQixLQUFLLHFCQUFxQix5QkFBeUIsTUFBTTtBQUVqRixpQkFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7QUFDeEIsZ0JBQU0sbUJBQW1CLFFBQVEsV0FBVyxxQkFBcUI7QUFDakUsZ0JBQU0seUJBQXlCLEtBQUssMEJBQTBCLGtCQUFrQixRQUFRLFNBQVUsS0FBSyxLQUFLLGdCQUFnQixnQkFBZ0I7QUFFNUksZ0JBQU0sa0JBQWtCLE9BQU8sV0FBVyxvQkFBb0I7QUFDOUQsZ0JBQU0sNkJBQTZCLEtBQUssMEJBQTBCLGlCQUFpQixlQUFlLEtBQUssS0FBSyxnQkFBZ0IsZUFBZTtBQUUzSSxtQkFBUyxLQUFLLElBQUksYUFBYSx3QkFBeUIsMEJBQTJCLENBQUM7QUFLcEYsY0FBSSxNQUFNLEtBQUssZ0JBQWdCLHFCQUFxQixtQkFBbUIsQ0FBQyxnQkFBZ0IscUJBQXFCO0FBR3pHLG1DQUF1QixLQUFLLE9BQU8sdUJBQXVCLEdBQUcsT0FBTyxXQUFXLE1BQU07O0FBR3pGLGlDQUF1QixLQUFLLE9BQU8sdUJBQXVCLEdBQUcsT0FBTyxXQUFXLE1BQU07QUFDckYsa0NBQXdCLEtBQUssT0FBTyx3QkFBd0IsR0FBRyxRQUFRLFdBQVcsTUFBTTs7QUFHNUYsZ0NBQXdCLFFBQVEsV0FBVyxTQUFTO0FBQ3BELGNBQU0sdUJBQXVCLFFBQVEsV0FBVyxxQkFBcUI7QUFDckUsY0FBTSw2QkFBNkIsS0FBSywwQkFBMEIsc0JBQXNCLFFBQVEsU0FBVSxLQUFLLEtBQUssZ0JBQWdCLG9CQUFvQjtBQUV4SixZQUFJLHNCQUFzQixPQUFPLFdBQVcsb0JBQW9CO0FBQ2hFLFlBQUksS0FBSyxxQkFBcUIsNEJBQTRCLG9CQUFvQixTQUFTLE1BQU0sR0FBRztBQUU1RixnQ0FBc0IsT0FBTyxXQUFXLE9BQU8sV0FBVyxTQUFTLENBQUM7O0FBRXhFLGNBQU0saUNBQWlDLEtBQUssMEJBQTBCLHFCQUFxQixlQUFlLEtBQUssS0FBSyxnQkFBZ0IsbUJBQW1CO0FBRXZKLGlCQUFTLEtBQUssSUFBSSxhQUFhLDRCQUE2Qiw4QkFBK0IsQ0FBQztBQUU1RixlQUFPO01BQ1g7TUFFUSxnQkFBZ0IsV0FBb0I7QUFDeEMsaUJBQVMsVUFBVSxvQkFBb0IsTUFBTSxVQUFVLG9CQUFvQixNQUFNO01BQ3JGO01BU0Esb0JBQW9CLGNBQTRCLE9BQWMsU0FBc0I7QUFDaEYsY0FBTSxnQkFBZ0IsS0FBSyxxQkFBcUIsOEJBQThCLFFBQVEsWUFBWSxhQUFhLHdCQUF3QixRQUFRLFNBQVU7QUFDekoscUJBQWEsWUFBWSxlQUFlO0FBRXhDLFlBQUksQ0FBQyxlQUFlLGtCQUFrQixDQUFDLE1BQU0sb0JBQW9CO0FBQzdELHVCQUFhLGFBQWE7QUFDMUIsdUJBQWEsY0FBYyxhQUFhO0FBQ3hDLHVCQUFhLGFBQWEsYUFBYTtBQUN2Qzs7QUFHSixjQUFNLGlCQUFpQixLQUFLLHFCQUFxQiw4QkFDN0MsTUFBTSxtQkFBbUIsWUFDekIsYUFBYSw4QkFBOEIsR0FDM0MsS0FBSyxxQkFBcUIseUJBQXlCLE1BQU0sa0JBQWtCLENBQUM7QUFFaEYscUJBQWEsYUFBYSxLQUFLLHFCQUFxQiw0QkFBNEIsZ0JBQWdCLFNBQVM7QUFFekcsYUFBSywwQkFBMEIsY0FBYyxPQUFPLE9BQU87TUFDL0Q7TUFRUSwwQkFBMEIsY0FBNEIsT0FBYyxTQUFzQjtBQUM5RixjQUFNLFNBQVMsS0FBSyxxQkFBcUIsc0JBQXNCLE1BQU0sbUJBQW1CO0FBQ3hGLGdCQUFRLE1BQU0sZUFBZTtVQUN6QixLQUFLLGNBQWMsUUFBUTtBQUN2Qix5QkFBYSxjQUFjLG9DQUFvQyxhQUFhLDBCQUEwQixNQUFNLFVBQVUsS0FBSyxhQUFhLFlBQWEsTUFBTTtBQUUzSix5QkFBYSxhQUFhLEtBQUssbUJBQW1CLGFBQWEsYUFBYSxRQUFRLFdBQVksTUFBTSxNQUFPO0FBQzdHLGdCQUFJLGFBQWEsWUFBWTtBQUN6QiwyQkFBYSxjQUFjLFFBQVEsYUFBYTs7QUFFcEQsa0JBQU0saUJBQWlCLEtBQUsscUJBQXFCLDhCQUE4QixRQUFRLFlBQVksYUFBYSxhQUFhLFFBQVEsU0FBVTtBQUMvSSx5QkFBYSxhQUFhLGdCQUFnQjtBQUMxQzs7VUFFSixLQUFLLGNBQWMsbUJBQW1CO0FBQ2xDLGtCQUFNLHdCQUF3QixLQUFLLHFCQUFxQiw0QkFBNEIsYUFBYSxTQUFtQjtBQUNwSCx5QkFBYSxhQUFhLG9DQUFvQyx5QkFBeUIsTUFBTSxVQUFVLEtBQUssYUFBYSxZQUFhLE1BQU07QUFDNUksa0JBQU0sV0FBVyxLQUFLLHFCQUFxQixTQUFTLFFBQVEsVUFBVTtBQUN0RSxrQkFBTSx1QkFBdUIsS0FBSyxxQkFBcUIsNEJBQTRCLFFBQVE7QUFFM0YseUJBQWEsYUFBYSxLQUFLLG1CQUFtQixhQUFhLFlBQVksc0JBQXNCLE1BQU0sTUFBTztBQUM5RyxnQkFBSSxhQUFhLFlBQVk7QUFDekIsMkJBQWEsYUFBYTs7QUFFOUI7O1VBRUosS0FBSyxjQUFjLGlCQUFpQjtBQUNoQyxrQkFBTSxJQUFJLE1BQU0sb0RBQW9EOzs7TUFHaEY7TUFRQSxtQkFBbUIsZ0JBQXdCLFVBQWtCLGlCQUF1QjtBQUNoRixnQkFBUSxpQkFBaUIsWUFBWSxrQkFBbUI7TUFDNUQ7TUFPQSwwQkFBMEIsV0FBc0IsV0FBaUI7QUFDN0QsWUFBSSxVQUFVLHFCQUFxQjtBQUMvQixpQkFBTyxVQUFVOztBQUVyQixZQUFJLFVBQVUscUJBQXFCO0FBQy9CLGlCQUFPLEtBQUssSUFBSSxVQUFVLGtCQUFtQixTQUFTOztBQUUxRCxlQUFPO01BQ1g7TUFPUSxPQUFPLEdBQVcsR0FBUztBQUMvQixnQkFBUyxJQUFJLElBQUssS0FBSztNQUMzQjs7eUJBblBTLGVBQVksc0JBQUEsYUFBQSxHQUFBLHNCQUFBLG9CQUFBLENBQUE7TUFBQTttRUFBWixlQUFZLFNBQVosY0FBWSxXQUFBLFlBREMsT0FBTSxDQUFBOzs7Ozs7QUNYaEMsU0FBUyxXQUFXLGFBQXFCO0FBSXpDLFNBQVMscUJBQXFCO0FBRzlCLFNBQVMsV0FBVztBQUlwQixTQUFTLHNCQUFzQjs7Ozs7QUNUdkIsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEscUJBQUEsQ0FBQTs7QUFBaUUsSUFBQSwyQkFBQTtBQUN6RSxJQUFBLHFCQUFBLEdBQUEsUUFBQTs7O0FBRFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsd0NBQUEsQ0FBQTs7Ozs7QUFTWSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEscUJBQUEsQ0FBQTs7QUFBcUUsSUFBQSwyQkFBQTtBQUM3RSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7OztBQURRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLDRDQUFBLENBQUE7Ozs7O0FBY0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFPLElBQUEsMkJBQUE7QUFDZixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7O0FBVEosSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUNBLElBQUEsd0JBQUEsR0FBQSxpQkFBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBTyxJQUFBLDJCQUFBO0FBQ1gsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLGlFQUFBLEdBQUEsQ0FBQTtBQUdKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7Ozs7QUFYUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGVBQUEsT0FBQSxvQkFBQSxPQUFBLHFDQUFBO0FBRUksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxrQ0FBQSxPQUFBLGlCQUFBLGdDQUFBO0FBS0osSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsZUFBQSxLQUFBLEVBQUE7Ozs7O0FBY0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFPLElBQUEsMkJBQUE7QUFDZixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7O0FBVEosSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUNBLElBQUEsd0JBQUEsR0FBQSxpQkFBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBTyxJQUFBLDJCQUFBO0FBQ1gsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLGlFQUFBLEdBQUEsQ0FBQTtBQUdKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7Ozs7QUFYUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGVBQUEsT0FBQSx5QkFBQSxPQUFBLHFDQUFBO0FBRUksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxrQ0FBQSxPQUFBLHNCQUFBLGdDQUFBO0FBS0osSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsZUFBQSxLQUFBLEVBQUE7Ozs7O0FBWUksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxDQUFBOzs7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7Ozs7OztBQUZjLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSwwQkFBQSxHQUFBLEdBQUEsMEJBQUEsR0FBQSxHQUFBLGNBQUEsUUFBQSxjQUFBLFFBQUEsc0JBQUEscUJBQUEsQ0FBQSxDQUFBLEdBQUEsNEJBQUE7Ozs7O0FBUGxCLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHFCQUFBLENBQUE7QUFBeUIsSUFBQSwyQkFBQTtBQUM3QixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLENBQUE7OztBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEseURBQUEsR0FBQSxDQUFBO0FBS0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTs7Ozs7OztBQVhRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsZUFBQSxhQUFBLGNBQUEsT0FBQSx5Q0FBQSxDQUFBLGFBQUEsY0FBQSxDQUFBLE9BQUEscUNBQUE7QUFDSSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLGFBQUEsU0FBQTtBQUVNLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSwwQkFBQSxHQUFBLEdBQUEsMEJBQUEsSUFBQSxHQUFBLGNBQUEsT0FBQSxjQUFBLFlBQUEsY0FBQSxhQUFBLENBQUEsQ0FBQSxHQUFBLDRCQUFBO0FBRVYsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsZUFBQSxLQUFBLEVBQUE7OztBRGhEeEIsSUFtQmE7QUFuQmI7O0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFHQTtBQUNBO0FBRUE7Ozs7Ozs7O0FBT00sSUFBTywyQkFBUCxNQUFPLDBCQUF3QjtNQVNyQjtNQUNBO01BQ0E7TUFDQTtNQVhILGdCQUFnQjtNQUVoQixnQkFBZ0I7TUFFaEI7TUFDQTtNQUVULFlBQ1ksT0FDQSxzQkFDQSxjQUNBLHNCQUEwQztBQUgxQyxhQUFBLFFBQUE7QUFDQSxhQUFBLHVCQUFBO0FBQ0EsYUFBQSxlQUFBO0FBQ0EsYUFBQSx1QkFBQTtNQUNUO01BRUg7TUFDQTtNQUVBLFNBQVM7TUFFVDtNQUNBO01BRUE7TUFDQSxhQUEwQixDQUFBO01BQzFCLFVBQVU7TUFFVixlQUFlO01BRWYsV0FBUTtBQUNKLGNBQU0sRUFBRSxVQUFVLFFBQVEsVUFBVSxRQUFRLHNDQUFxQyxJQUFLLHdCQUF3QixLQUFLLEtBQUs7QUFDeEgsYUFBSyxXQUFXO0FBQ2hCLGFBQUssU0FBUztBQUNkLGFBQUssV0FBVyxLQUFLLFlBQVk7QUFDakMsYUFBSyxTQUFTO0FBQ2QsYUFBSyx3Q0FBd0MsS0FBSyx5Q0FBeUM7QUFFM0YsYUFBSyxlQUFlLEtBQUssVUFBVSxLQUFLLE1BQU0sRUFBRSxVQUFVLENBQUMsZUFBYztBQUNyRSxjQUFJLFlBQVk7QUFDWixpQkFBSyxRQUFRLFdBQVc7QUFDeEIsaUJBQUssVUFBVSxXQUFXLGNBQWMsVUFBVTtBQUNsRCxpQkFBSyxhQUFhLEtBQUsscUJBQXFCLGVBQWUsV0FBVyxVQUFVO0FBQ2hGLGlCQUFLLGtCQUFrQixXQUFXO0FBQ2xDLGlCQUFLLHVCQUF1QixXQUFXO0FBQ3ZDLGdCQUFJLFdBQVcsY0FBYyxRQUFXO0FBQ3BDLGtCQUFJLENBQUMsS0FBSyxRQUFRO0FBQ2Qsb0JBQUksWUFBWTtBQUNoQixzQkFBTSx1QkFBdUIsS0FBSyxxQkFBcUIscUJBQXFCLEtBQUssUUFBUztBQUMxRixvQkFBSSxzQkFBc0I7QUFDdEIsOEJBQVkscUJBQXFCLFVBQVUsZ0JBQWdCOztBQUUvRCxxQkFBSyxxQkFBcUIsZUFBZSxLQUFLLFlBQVksU0FBUztxQkFDaEU7QUFFSCxxQkFBSyxxQkFBcUIsZUFBZSxLQUFLLFlBQVksV0FBVyxTQUFVOzs7O1FBSS9GLENBQUM7QUFFRCxhQUFLLGVBQWUsS0FBSyxxQkFBcUIsYUFBYSxLQUFLLFVBQVU7TUFDOUU7TUFFUSxlQUFlLFVBQWtCLFFBQWU7QUFDcEQsWUFBSSxDQUFDLEtBQUssVUFBVTtBQUNoQixpQkFBTyxLQUFLLHFCQUFxQixlQUFlLFVBQVUsTUFBTTtlQUM3RDtBQUVILGlCQUFPLEtBQUssYUFBYSxpQkFBaUIsVUFBVSxRQUFTLElBQUksRUFBRSxLQUMvRCxJQUFJLENBQUMsa0JBQWlCO0FBQ2xCLGtCQUFNLFNBQVMsY0FBYyxNQUFNO0FBQ25DLGdCQUFJLENBQUMsUUFBUTtBQUNULHFCQUFPOztBQUVYLG1CQUFPO2NBQ0gsT0FBTyxLQUFLLHFCQUFxQixxQkFBcUIsTUFBTTtjQUM1RCxXQUFXLE9BQU87Y0FDbEIsWUFBWSxPQUFPO2NBQ25CLFdBQVcsS0FBSyxxQkFBcUIseUJBQXlCLE1BQU07Y0FDcEUsaUJBQWlCLE9BQU8sbUJBQW1CLGFBQWE7Y0FDeEQsc0JBQXNCLE9BQU8sd0JBQXdCLGFBQWE7Y0FDbEUscUJBQXFCLE9BQU87Y0FDNUIscUJBQXFCLE9BQU87O1VBRXBDLENBQUMsQ0FBQzs7TUFHZDs7eUJBdkZTLDJCQUF3QixnQ0FBQSxrQkFBQSxHQUFBLGdDQUFBLG9CQUFBLEdBQUEsZ0NBQUEsWUFBQSxHQUFBLGdDQUFBLG9CQUFBLENBQUE7TUFBQTtpRUFBeEIsMkJBQXdCLFdBQUEsQ0FBQSxDQUFBLHFCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsdUNBQUEseUNBQUEsVUFBQSxXQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFNBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLE1BQUEsR0FBQSxDQUFBLGFBQUEsUUFBQSxRQUFBLDhDQUFBLEdBQUEsQ0FBQSxhQUFBLFFBQUEsUUFBQSxtREFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsa0NBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNuQnJDLFVBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLHlCQUFBLEdBQUEsaURBQUEsR0FBQSxDQUFBO0FBR0EsVUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxTQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLElBQUE7QUFBSSxVQUFBLHFCQUFBLEVBQUE7OztBQUFtSSxVQUFBLDJCQUFBO0FBQ3ZJLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQUksVUFBQSxxQkFBQSxFQUFBOztBQUErRCxVQUFBLDJCQUFBO0FBQ25FLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxrREFBQSxHQUFBLENBQUE7QUFHSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLGtEQUFBLElBQUEsQ0FBQSxFQVlDLElBQUEsa0RBQUEsSUFBQSxDQUFBO0FBY0QsVUFBQSwrQkFBQSxJQUFBLDBDQUFBLElBQUEsSUFBQSxNQUFBLE1BQUEsdUNBQUE7QUFhSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsS0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLElBQUE7QUFBSSxVQUFBLHFCQUFBLEVBQUE7O0FBQTRFLFVBQUEsMkJBQUE7QUFDaEYsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsSUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLENBQUE7QUFBZ0MsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBTSxVQUFBLDJCQUFBO0FBQU8sVUFBQSxxQkFBQSxFQUFBOztBQUFvRyxVQUFBLDJCQUFBO0FBQ3JKLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLENBQUE7QUFBZ0MsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBTSxVQUFBLDJCQUFBO0FBQU8sVUFBQSxxQkFBQSxFQUFBOztBQUFvRyxVQUFBLDJCQUFBO0FBQ3JKLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxRQUFBLENBQUE7QUFBZ0MsVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBTSxVQUFBLDJCQUFBO0FBQU8sVUFBQSxxQkFBQSxFQUFBOztBQUFzRixVQUFBLDJCQUFBO0FBQzNJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUFsRUksVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLENBQUEsSUFBQSxTQUFBLElBQUEsRUFBQTtBQU9vQixVQUFBLHdCQUFBLEVBQUE7QUFBQSxVQUFBLGdDQUFBLElBQUEsVUFBQSwwQkFBQSxJQUFBLElBQUEsbUNBQUEsSUFBQSwwQkFBQSxJQUFBLElBQUEsbUNBQUEsQ0FBQTtBQUNBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLHNDQUFBLENBQUE7QUFDSixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxlQUFBLEtBQUEsRUFBQTtBQU1KLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLG9CQUFBLElBQUEsd0NBQUEsS0FBQSxFQUFBO0FBYUEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEseUJBQUEsSUFBQSx3Q0FBQSxLQUFBLEVBQUE7QUFhQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsVUFBQTtBQWlCSixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSxtREFBQSxDQUFBO0FBRWlELFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsaUNBQUEsTUFBQSwwQkFBQSxJQUFBLElBQUEseUVBQUEsR0FBQSxFQUFBO0FBQ0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSxNQUFBLDBCQUFBLElBQUEsSUFBQSx5RUFBQSxHQUFBLEVBQUE7QUFDQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLE1BQUEsMEJBQUEsSUFBQSxJQUFBLDJEQUFBLEdBQUEsRUFBQTs7Ozs7cUZENUNoRCwwQkFBd0IsRUFBQSxXQUFBLDJCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRW5CckMsU0FBUyxhQUFBQyxrQkFBeUI7QUFDbEMsU0FBUyxrQkFBQUMsdUJBQXNCO0FBSS9CLFNBQVMsaUJBQUFDLGdCQUFlLGVBQWU7Ozs7OztBQ0UzQixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEscUJBQUEsQ0FBQTs7QUFBaUUsSUFBQSwyQkFBQTtBQUN6RSxJQUFBLHFCQUFBLEdBQUEsWUFBQTs7O0FBRFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsd0NBQUEsQ0FBQTs7O0FEUGhCLElBY2E7QUFkYjs7QUFFQTtBQUVBO0FBRUE7QUFDQTs7Ozs7OztBQU9NLElBQU8sOEJBQVAsTUFBTyw2QkFBMkI7TUFReEI7TUFDQTtNQUNBO01BQ0E7TUFWSCxnQkFBZ0JBO01BQ2hCLFVBQVU7TUFFbkI7TUFDQTtNQUVBLFlBQ1ksT0FDQSxzQkFDQSx1QkFDQSxjQUEwQjtBQUgxQixhQUFBLFFBQUE7QUFDQSxhQUFBLHVCQUFBO0FBQ0EsYUFBQSx3QkFBQTtBQUNBLGFBQUEsZUFBQTtNQUNUO01BRUgsU0FBUztNQUVUO01BQ0E7TUFFQTtNQUNBLGFBQTBCLENBQUE7TUFDMUI7TUFDQSxVQUFVO01BQ1Y7TUFFQSxXQUFRO0FBQ0osY0FBTSxFQUFFLFVBQVUsUUFBUSxVQUFVLFFBQVEsc0NBQXFDLElBQUssd0JBQXdCLEtBQUssS0FBSztBQUV4SCxhQUFLLFdBQVc7QUFDaEIsYUFBSyxTQUFTO0FBQ2QsYUFBSyxXQUFXO0FBQ2hCLGFBQUssU0FBUztBQUNkLGFBQUssd0NBQXdDO01BQ2pEO01BS0EsZ0JBQWE7QUFDVCxjQUFNLGNBQWMsQ0FBQyxXQUFXLEtBQUssU0FBVSxTQUFRLENBQUU7QUFDekQsWUFBSSxLQUFLLFFBQVE7QUFDYixzQkFBWSxLQUFLLFNBQVMsS0FBSyxPQUFRLFNBQVEsQ0FBRTtlQUM5QztBQUNILHNCQUFZLEtBQUssWUFBWTs7QUFFakMsYUFBSyxzQkFBc0IsYUFBYSxXQUFXO01BQ3ZEO01BS00sV0FBUTs7QUFDVixnQkFBTSxLQUFLLGFBQWEsTUFBSztRQUNqQzs7O3lCQXJEUyw4QkFBMkIsZ0NBQUEsa0JBQUEsR0FBQSxnQ0FBQSxvQkFBQSxHQUFBLGdDQUFBLDRCQUFBLEdBQUEsZ0NBQUEsWUFBQSxDQUFBO01BQUE7aUVBQTNCLDhCQUEyQixXQUFBLENBQUEsQ0FBQSx3QkFBQSxDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLE9BQUEsd0JBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxlQUFBLE1BQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLE9BQUEsaUJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLGdCQUFBLG9CQUFBLEdBQUEsQ0FBQSxNQUFBLHFCQUFBLEdBQUEsT0FBQSxlQUFBLEdBQUEsU0FBQSxTQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEsdUNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxxQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ2R4QyxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxDQUFBOztBQUVKLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxvREFBQSxHQUFBLENBQUE7QUFHQSxVQUFBLHdCQUFBLEdBQUEscUJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxVQUFBLENBQUE7QUFBZ0QsVUFBQSx5QkFBQSxTQUFBLFNBQUEsZ0VBQUE7QUFBQSxtQkFBUyxJQUFBLGNBQUE7VUFBZSxDQUFBO0FBQ3BFLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLENBQUE7QUFBMEMsVUFBQSxxQkFBQSxJQUFBLE1BQUE7QUFBTSxVQUFBLDZCQUFBLElBQUEsUUFBQSxDQUFBO0FBQXlDLFVBQUEscUJBQUEsSUFBQSxPQUFBO0FBQUksVUFBQSwyQkFBQTtBQUNqRyxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxVQUFBLENBQUE7QUFBNEUsVUFBQSx5QkFBQSxTQUFBLFNBQUEsZ0VBQUE7QUFBQSxtQkFBUyxJQUFBLFNBQUE7VUFBVSxDQUFBO0FBQzNGLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLENBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsUUFBQSxDQUFBO0FBQTJELFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQVUsVUFBQSwyQkFBQTtBQUN6RSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBaEJZLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsaUNBQUEsa0JBQUEsMEJBQUEsR0FBQSxHQUFBLElBQUEsV0FBQSx3Q0FBQSxJQUFBLFNBQUEsdUNBQUEsc0NBQUEsR0FBQSxrQkFBQSxJQUFBLE9BQUEsWUFBQTtBQUdKLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxDQUFBLElBQUEsU0FBQSxJQUFBLEVBQUE7QUFLYSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxhQUFBO0FBR0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsT0FBQTs7Ozs7cUZEQVIsNkJBQTJCLEVBQUEsV0FBQSw4QkFBQSxDQUFBO0lBQUEsR0FBQTs7OyIsIm5hbWVzIjpbIkJvbnVzU3RyYXRlZ3kiLCJDb21wb25lbnQiLCJBY3RpdmF0ZWRSb3V0ZSIsImZhQ2hldnJvbkxlZnQiXX0=