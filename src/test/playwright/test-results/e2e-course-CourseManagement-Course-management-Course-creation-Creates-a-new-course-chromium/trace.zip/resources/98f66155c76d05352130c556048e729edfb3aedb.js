import {
  IrisSettingsService,
  IrisSubSettingsType,
  init_iris_settings_service,
  init_iris_sub_settings_model
} from "/chunk-VUYHOQDW.js";
import {
  ArtemisTranslatePipe,
  __esm,
  init_artemis_translate_pipe,
  init_course_model,
  init_exercise_model
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/iris/settings/shared/iris-enabled.component.ts
import { Component, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
var _c0, _c1, IrisEnabledComponent;
var init_iris_enabled_component = __esm({
  "src/main/webapp/app/iris/settings/shared/iris-enabled.component.ts"() {
    init_iris_sub_settings_model();
    init_exercise_model();
    init_course_model();
    init_iris_settings_service();
    init_iris_settings_service();
    init_artemis_translate_pipe();
    _c0 = (a0, a1) => ({ "btn-success selected": a0, "btn-default": a1 });
    _c1 = (a0, a1) => ({ "btn-danger selected": a0, "btn-default": a1 });
    IrisEnabledComponent = class _IrisEnabledComponent {
      irisSettingsService;
      exercise;
      course;
      irisSubSettingsType;
      disabled = false;
      irisSettings;
      irisSubSettings;
      constructor(irisSettingsService) {
        this.irisSettingsService = irisSettingsService;
      }
      ngOnInit() {
        if (this.exercise) {
          this.irisSettingsService.getUncombinedProgrammingExerciseSettings(this.exercise.id).subscribe((settings) => {
            this.irisSettings = settings;
            this.setSubSettings();
          });
        } else if (this.course) {
          this.irisSettingsService.getUncombinedCourseSettings(this.course.id).subscribe((settings) => {
            this.irisSettings = settings;
            this.setSubSettings();
          });
        }
      }
      setEnabled(enabled) {
        if (!this.disabled && this.irisSubSettings) {
          this.irisSubSettings.enabled = enabled;
          if (this.exercise) {
            this.irisSettingsService.setProgrammingExerciseSettings(this.exercise.id, this.irisSettings).subscribe((response) => {
              this.irisSettings = response.body ?? this.irisSettings;
              this.setSubSettings();
            });
          } else if (this.course) {
            this.irisSettingsService.setCourseSettings(this.course.id, this.irisSettings).subscribe((response) => {
              this.irisSettings = response.body ?? this.irisSettings;
              this.setSubSettings();
            });
          }
        }
      }
      setSubSettings() {
        switch (this.irisSubSettingsType) {
          case IrisSubSettingsType.CHAT:
            this.irisSubSettings = this.irisSettings?.irisChatSettings;
            break;
          case IrisSubSettingsType.HESTIA:
            this.irisSubSettings = this.irisSettings?.irisHestiaSettings;
            break;
          case IrisSubSettingsType.CODE_EDITOR:
            this.irisSubSettings = this.irisSettings?.irisCodeEditorSettings;
            break;
        }
      }
      static \u0275fac = function IrisEnabledComponent_Factory(t) {
        return new (t || _IrisEnabledComponent)(i0.\u0275\u0275directiveInject(IrisSettingsService));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _IrisEnabledComponent, selectors: [["jhi-iris-enabled"]], inputs: { exercise: "exercise", course: "course", irisSubSettingsType: "irisSubSettingsType", disabled: "disabled" }, decls: 11, vars: 18, consts: [[1, "btn-group"], [1, "btn", 3, "ngClass", "click"], [1, "btn", "btn-default", 3, "ngClass", "click"]], template: function IrisEnabledComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "div", 0);
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275elementStart(2, "div", 1);
          i0.\u0275\u0275listener("click", function IrisEnabledComponent_Template_div_click_2_listener() {
            return ctx.setEnabled(true);
          });
          i0.\u0275\u0275text(3);
          i0.\u0275\u0275pipe(4, "artemisTranslate");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(5, "\n    ");
          i0.\u0275\u0275elementStart(6, "div", 2);
          i0.\u0275\u0275listener("click", function IrisEnabledComponent_Template_div_click_6_listener() {
            return ctx.setEnabled(false);
          });
          i0.\u0275\u0275text(7);
          i0.\u0275\u0275pipe(8, "artemisTranslate");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(9, "\n");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(10, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275classProp("disabled", ctx.disabled);
          i0.\u0275\u0275property("ngClass", i0.\u0275\u0275pureFunction2(12, _c0, ctx.irisSubSettings == null ? null : ctx.irisSubSettings.enabled, !(ctx.irisSubSettings == null ? null : ctx.irisSubSettings.enabled)));
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275textInterpolate1("\n        ", i0.\u0275\u0275pipeBind1(4, 8, "artemisApp.iris.settings.subSettings.enabled.on"), "\n    ");
          i0.\u0275\u0275advance(3);
          i0.\u0275\u0275classProp("disabled", ctx.disabled);
          i0.\u0275\u0275property("ngClass", i0.\u0275\u0275pureFunction2(15, _c1, !(ctx.irisSubSettings == null ? null : ctx.irisSubSettings.enabled), ctx.irisSubSettings == null ? null : ctx.irisSubSettings.enabled));
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275textInterpolate1("\n        ", i0.\u0275\u0275pipeBind1(8, 10, "artemisApp.iris.settings.subSettings.enabled.off"), "\n    ");
        }
      }, dependencies: [i2.NgClass, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(IrisEnabledComponent, { className: "IrisEnabledComponent" });
    })();
  }
});

export {
  IrisEnabledComponent,
  init_iris_enabled_component
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9zZXR0aW5ncy9zaGFyZWQvaXJpcy1lbmFibGVkLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9zZXR0aW5ncy9zaGFyZWQvaXJpcy1lbmFibGVkLmNvbXBvbmVudC5odG1sIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSXJpc1N1YlNldHRpbmdzLCBJcmlzU3ViU2V0dGluZ3NUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvc2V0dGluZ3MvaXJpcy1zdWItc2V0dGluZ3MubW9kZWwnO1xuaW1wb3J0IHsgRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgSXJpc1NldHRpbmdzIH0gZnJvbSAnYXBwL2VudGl0aWVzL2lyaXMvc2V0dGluZ3MvaXJpcy1zZXR0aW5ncy5tb2RlbCc7XG5pbXBvcnQgeyBDb3Vyc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvY291cnNlLm1vZGVsJztcbmltcG9ydCB7IElyaXNTZXR0aW5nc1NlcnZpY2UgfSBmcm9tICdhcHAvaXJpcy9zZXR0aW5ncy9zaGFyZWQvaXJpcy1zZXR0aW5ncy5zZXJ2aWNlJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktaXJpcy1lbmFibGVkJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vaXJpcy1lbmFibGVkLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgSXJpc0VuYWJsZWRDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlPzogRXhlcmNpc2U7XG4gICAgQElucHV0KCkgY291cnNlPzogQ291cnNlO1xuICAgIEBJbnB1dCgpIGlyaXNTdWJTZXR0aW5nc1R5cGU6IElyaXNTdWJTZXR0aW5nc1R5cGU7XG4gICAgQElucHV0KCkgZGlzYWJsZWQ/ID0gZmFsc2U7XG5cbiAgICBpcmlzU2V0dGluZ3M/OiBJcmlzU2V0dGluZ3M7XG4gICAgaXJpc1N1YlNldHRpbmdzPzogSXJpc1N1YlNldHRpbmdzO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBpcmlzU2V0dGluZ3NTZXJ2aWNlOiBJcmlzU2V0dGluZ3NTZXJ2aWNlKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIGlmICh0aGlzLmV4ZXJjaXNlKSB7XG4gICAgICAgICAgICB0aGlzLmlyaXNTZXR0aW5nc1NlcnZpY2UuZ2V0VW5jb21iaW5lZFByb2dyYW1taW5nRXhlcmNpc2VTZXR0aW5ncyh0aGlzLmV4ZXJjaXNlLmlkISkuc3Vic2NyaWJlKChzZXR0aW5ncykgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuaXJpc1NldHRpbmdzID0gc2V0dGluZ3M7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRTdWJTZXR0aW5ncygpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5jb3Vyc2UpIHtcbiAgICAgICAgICAgIHRoaXMuaXJpc1NldHRpbmdzU2VydmljZS5nZXRVbmNvbWJpbmVkQ291cnNlU2V0dGluZ3ModGhpcy5jb3Vyc2UuaWQhKS5zdWJzY3JpYmUoKHNldHRpbmdzKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5pcmlzU2V0dGluZ3MgPSBzZXR0aW5ncztcbiAgICAgICAgICAgICAgICB0aGlzLnNldFN1YlNldHRpbmdzKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHNldEVuYWJsZWQoZW5hYmxlZDogYm9vbGVhbikge1xuICAgICAgICBpZiAoIXRoaXMuZGlzYWJsZWQgJiYgdGhpcy5pcmlzU3ViU2V0dGluZ3MpIHtcbiAgICAgICAgICAgIHRoaXMuaXJpc1N1YlNldHRpbmdzLmVuYWJsZWQgPSBlbmFibGVkO1xuICAgICAgICAgICAgaWYgKHRoaXMuZXhlcmNpc2UpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmlyaXNTZXR0aW5nc1NlcnZpY2Uuc2V0UHJvZ3JhbW1pbmdFeGVyY2lzZVNldHRpbmdzKHRoaXMuZXhlcmNpc2UuaWQhLCB0aGlzLmlyaXNTZXR0aW5ncyEpLnN1YnNjcmliZSgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pcmlzU2V0dGluZ3MgPSByZXNwb25zZS5ib2R5ID8/IHRoaXMuaXJpc1NldHRpbmdzO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNldFN1YlNldHRpbmdzKCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuY291cnNlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5pcmlzU2V0dGluZ3NTZXJ2aWNlLnNldENvdXJzZVNldHRpbmdzKHRoaXMuY291cnNlLmlkISwgdGhpcy5pcmlzU2V0dGluZ3MhKS5zdWJzY3JpYmUoKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXJpc1NldHRpbmdzID0gcmVzcG9uc2UuYm9keSA/PyB0aGlzLmlyaXNTZXR0aW5ncztcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRTdWJTZXR0aW5ncygpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzZXRTdWJTZXR0aW5ncygpIHtcbiAgICAgICAgc3dpdGNoICh0aGlzLmlyaXNTdWJTZXR0aW5nc1R5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgSXJpc1N1YlNldHRpbmdzVHlwZS5DSEFUOlxuICAgICAgICAgICAgICAgIHRoaXMuaXJpc1N1YlNldHRpbmdzID0gdGhpcy5pcmlzU2V0dGluZ3M/LmlyaXNDaGF0U2V0dGluZ3M7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIElyaXNTdWJTZXR0aW5nc1R5cGUuSEVTVElBOlxuICAgICAgICAgICAgICAgIHRoaXMuaXJpc1N1YlNldHRpbmdzID0gdGhpcy5pcmlzU2V0dGluZ3M/LmlyaXNIZXN0aWFTZXR0aW5ncztcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgSXJpc1N1YlNldHRpbmdzVHlwZS5DT0RFX0VESVRPUjpcbiAgICAgICAgICAgICAgICB0aGlzLmlyaXNTdWJTZXR0aW5ncyA9IHRoaXMuaXJpc1NldHRpbmdzPy5pcmlzQ29kZUVkaXRvclNldHRpbmdzO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cImJ0bi1ncm91cFwiPlxuICAgIDxkaXZcbiAgICAgICAgY2xhc3M9XCJidG5cIlxuICAgICAgICBbbmdDbGFzc109XCJ7ICdidG4tc3VjY2VzcyBzZWxlY3RlZCc6IGlyaXNTdWJTZXR0aW5ncz8uZW5hYmxlZCwgJ2J0bi1kZWZhdWx0JzogIWlyaXNTdWJTZXR0aW5ncz8uZW5hYmxlZCB9XCJcbiAgICAgICAgW2NsYXNzLmRpc2FibGVkXT1cImRpc2FibGVkXCJcbiAgICAgICAgKGNsaWNrKT1cInNldEVuYWJsZWQodHJ1ZSlcIlxuICAgID5cbiAgICAgICAge3sgJ2FydGVtaXNBcHAuaXJpcy5zZXR0aW5ncy5zdWJTZXR0aW5ncy5lbmFibGVkLm9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICA8L2Rpdj5cbiAgICA8ZGl2XG4gICAgICAgIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0XCJcbiAgICAgICAgW25nQ2xhc3NdPVwieyAnYnRuLWRhbmdlciBzZWxlY3RlZCc6ICFpcmlzU3ViU2V0dGluZ3M/LmVuYWJsZWQsICdidG4tZGVmYXVsdCc6IGlyaXNTdWJTZXR0aW5ncz8uZW5hYmxlZCB9XCJcbiAgICAgICAgW2NsYXNzLmRpc2FibGVkXT1cImRpc2FibGVkXCJcbiAgICAgICAgKGNsaWNrKT1cInNldEVuYWJsZWQoZmFsc2UpXCJcbiAgICA+XG4gICAgICAgIHt7ICdhcnRlbWlzQXBwLmlyaXMuc2V0dGluZ3Muc3ViU2V0dGluZ3MuZW5hYmxlZC5vZmYnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgIDwvZGl2PlxuPC9kaXY+XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsV0FBVyxhQUFxQjs7O0FBQXpDLGNBV2E7QUFYYjs7QUFDQTtBQUNBO0FBRUE7QUFDQTs7Ozs7QUFNTSxJQUFPLHVCQUFQLE1BQU8sc0JBQW9CO01BU1Q7TUFSWDtNQUNBO01BQ0E7TUFDQSxXQUFZO01BRXJCO01BQ0E7TUFFQSxZQUFvQixxQkFBd0M7QUFBeEMsYUFBQSxzQkFBQTtNQUEyQztNQUUvRCxXQUFRO0FBQ0osWUFBSSxLQUFLLFVBQVU7QUFDZixlQUFLLG9CQUFvQix5Q0FBeUMsS0FBSyxTQUFTLEVBQUcsRUFBRSxVQUFVLENBQUMsYUFBWTtBQUN4RyxpQkFBSyxlQUFlO0FBQ3BCLGlCQUFLLGVBQWM7VUFDdkIsQ0FBQzttQkFDTSxLQUFLLFFBQVE7QUFDcEIsZUFBSyxvQkFBb0IsNEJBQTRCLEtBQUssT0FBTyxFQUFHLEVBQUUsVUFBVSxDQUFDLGFBQVk7QUFDekYsaUJBQUssZUFBZTtBQUNwQixpQkFBSyxlQUFjO1VBQ3ZCLENBQUM7O01BRVQ7TUFFQSxXQUFXLFNBQWdCO0FBQ3ZCLFlBQUksQ0FBQyxLQUFLLFlBQVksS0FBSyxpQkFBaUI7QUFDeEMsZUFBSyxnQkFBZ0IsVUFBVTtBQUMvQixjQUFJLEtBQUssVUFBVTtBQUNmLGlCQUFLLG9CQUFvQiwrQkFBK0IsS0FBSyxTQUFTLElBQUssS0FBSyxZQUFhLEVBQUUsVUFBVSxDQUFDLGFBQVk7QUFDbEgsbUJBQUssZUFBZSxTQUFTLFFBQVEsS0FBSztBQUMxQyxtQkFBSyxlQUFjO1lBQ3ZCLENBQUM7cUJBQ00sS0FBSyxRQUFRO0FBQ3BCLGlCQUFLLG9CQUFvQixrQkFBa0IsS0FBSyxPQUFPLElBQUssS0FBSyxZQUFhLEVBQUUsVUFBVSxDQUFDLGFBQVk7QUFDbkcsbUJBQUssZUFBZSxTQUFTLFFBQVEsS0FBSztBQUMxQyxtQkFBSyxlQUFjO1lBQ3ZCLENBQUM7OztNQUdiO01BRVEsaUJBQWM7QUFDbEIsZ0JBQVEsS0FBSyxxQkFBcUI7VUFDOUIsS0FBSyxvQkFBb0I7QUFDckIsaUJBQUssa0JBQWtCLEtBQUssY0FBYztBQUMxQztVQUNKLEtBQUssb0JBQW9CO0FBQ3JCLGlCQUFLLGtCQUFrQixLQUFLLGNBQWM7QUFDMUM7VUFDSixLQUFLLG9CQUFvQjtBQUNyQixpQkFBSyxrQkFBa0IsS0FBSyxjQUFjO0FBQzFDOztNQUVaOzt5QkF0RFMsdUJBQW9CLCtCQUFBLG1CQUFBLENBQUE7TUFBQTtnRUFBcEIsdUJBQW9CLFdBQUEsQ0FBQSxDQUFBLGtCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLFFBQUEsVUFBQSxxQkFBQSx1QkFBQSxVQUFBLFdBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsV0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsZUFBQSxHQUFBLFdBQUEsT0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDhCQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDWGpDLFVBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFJSSxVQUFBLHdCQUFBLFNBQUEsU0FBQSxxREFBQTtBQUFBLG1CQUFTLElBQUEsV0FBVyxJQUFJO1VBQUMsQ0FBQTtBQUV6QixVQUFBLG9CQUFBLENBQUE7O0FBQ0osVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUlJLFVBQUEsd0JBQUEsU0FBQSxTQUFBLHFEQUFBO0FBQUEsbUJBQVMsSUFBQSxXQUFXLEtBQUs7VUFBQyxDQUFBO0FBRTFCLFVBQUEsb0JBQUEsQ0FBQTs7QUFDSixVQUFBLDBCQUFBO0FBQ0osVUFBQSxvQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDBCQUFBO0FBQ0EsVUFBQSxvQkFBQSxJQUFBLElBQUE7OztBQWRRLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsWUFBQSxJQUFBLFFBQUE7QUFEQSxVQUFBLHdCQUFBLFdBQUEsNkJBQUEsSUFBQSxLQUFBLElBQUEsbUJBQUEsT0FBQSxPQUFBLElBQUEsZ0JBQUEsU0FBQSxFQUFBLElBQUEsbUJBQUEsT0FBQSxPQUFBLElBQUEsZ0JBQUEsUUFBQSxDQUFBO0FBSUEsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSxjQUFBLHlCQUFBLEdBQUEsR0FBQSxpREFBQSxHQUFBLFFBQUE7QUFLQSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFlBQUEsSUFBQSxRQUFBO0FBREEsVUFBQSx3QkFBQSxXQUFBLDZCQUFBLElBQUEsS0FBQSxFQUFBLElBQUEsbUJBQUEsT0FBQSxPQUFBLElBQUEsZ0JBQUEsVUFBQSxJQUFBLG1CQUFBLE9BQUEsT0FBQSxJQUFBLGdCQUFBLE9BQUEsQ0FBQTtBQUlBLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsZ0NBQUEsY0FBQSx5QkFBQSxHQUFBLElBQUEsa0RBQUEsR0FBQSxRQUFBOzs7OztvRkRKSyxzQkFBb0IsRUFBQSxXQUFBLHVCQUFBLENBQUE7SUFBQSxHQUFBOzs7IiwibmFtZXMiOltdfQ==