import {
  __esm,
  convertDateFromServer,
  init_date_utils
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/file-upload/assess/file-upload-assessment.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient, HttpParams } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var FileUploadAssessmentService;
var init_file_upload_assessment_service = __esm({
  "src/main/webapp/app/exercises/file-upload/assess/file-upload-assessment.service.ts"() {
    init_date_utils();
    FileUploadAssessmentService = class _FileUploadAssessmentService {
      http;
      resourceUrl = "api";
      constructor(http) {
        this.http = http;
      }
      saveAssessment(feedbacks, submissionId, submit = false) {
        let params = new HttpParams();
        if (submit) {
          params = params.set("submit", "true");
        }
        const url = `${this.resourceUrl}/file-upload-submissions/${submissionId}/feedback`;
        return this.http.put(url, feedbacks, { params });
      }
      updateAssessmentAfterComplaint(feedbacks, complaintResponse, submissionId) {
        const url = `${this.resourceUrl}/file-upload-submissions/${submissionId}/assessment-after-complaint`;
        const assessmentUpdate = {
          feedbacks,
          complaintResponse
        };
        return this.http.put(url, assessmentUpdate, { observe: "response" }).pipe(map((res) => this.convertResultEntityResponseTypeFromServer(res)));
      }
      getAssessment(submissionId) {
        return this.http.get(`${this.resourceUrl}/file-upload-submissions/${submissionId}/result`);
      }
      cancelAssessment(submissionId) {
        return this.http.put(`${this.resourceUrl}/file-upload-submissions/${submissionId}/cancel-assessment`, null);
      }
      deleteAssessment(participationId, submissionId, resultId) {
        return this.http.delete(`${this.resourceUrl}/participations/${participationId}/file-upload-submissions/${submissionId}/results/${resultId}`);
      }
      convertResultEntityResponseTypeFromServer(res) {
        const result = this.convertItemFromServer(res.body);
        result.completionDate = convertDateFromServer(result.completionDate);
        if (result.submission) {
          result.submission.submissionDate = convertDateFromServer(result.submission.submissionDate);
        }
        if (result.participation) {
          result.participation.initializationDate = convertDateFromServer(result.participation.initializationDate);
        }
        return res.clone({ body: result });
      }
      convertItemFromServer(result) {
        return Object.assign({}, result);
      }
      static \u0275fac = function FileUploadAssessmentService_Factory(t) {
        return new (t || _FileUploadAssessmentService)(i0.\u0275\u0275inject(i1.HttpClient));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _FileUploadAssessmentService, factory: _FileUploadAssessmentService.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  FileUploadAssessmentService,
  init_file_upload_assessment_service
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL2ZpbGUtdXBsb2FkL2Fzc2Vzcy9maWxlLXVwbG9hZC1hc3Nlc3NtZW50LnNlcnZpY2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cFBhcmFtcywgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgQ29tcGxhaW50UmVzcG9uc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvY29tcGxhaW50LXJlc3BvbnNlLm1vZGVsJztcbmltcG9ydCB7IEZlZWRiYWNrIH0gZnJvbSAnYXBwL2VudGl0aWVzL2ZlZWRiYWNrLm1vZGVsJztcbmltcG9ydCB7IFJlc3VsdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9yZXN1bHQubW9kZWwnO1xuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgY29udmVydERhdGVGcm9tU2VydmVyIH0gZnJvbSAnYXBwL3V0aWxzL2RhdGUudXRpbHMnO1xuXG5leHBvcnQgdHlwZSBFbnRpdHlSZXNwb25zZVR5cGUgPSBIdHRwUmVzcG9uc2U8UmVzdWx0PjtcblxuQEluamVjdGFibGUoe1xuICAgIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgRmlsZVVwbG9hZEFzc2Vzc21lbnRTZXJ2aWNlIHtcbiAgICBwcml2YXRlIHJlc291cmNlVXJsID0gJ2FwaSc7XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQpIHt9XG5cbiAgICBzYXZlQXNzZXNzbWVudChmZWVkYmFja3M6IEZlZWRiYWNrW10sIHN1Ym1pc3Npb25JZDogbnVtYmVyLCBzdWJtaXQgPSBmYWxzZSk6IE9ic2VydmFibGU8UmVzdWx0PiB7XG4gICAgICAgIGxldCBwYXJhbXMgPSBuZXcgSHR0cFBhcmFtcygpO1xuICAgICAgICBpZiAoc3VibWl0KSB7XG4gICAgICAgICAgICBwYXJhbXMgPSBwYXJhbXMuc2V0KCdzdWJtaXQnLCAndHJ1ZScpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVybCA9IGAke3RoaXMucmVzb3VyY2VVcmx9L2ZpbGUtdXBsb2FkLXN1Ym1pc3Npb25zLyR7c3VibWlzc2lvbklkfS9mZWVkYmFja2A7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucHV0PFJlc3VsdD4odXJsLCBmZWVkYmFja3MsIHsgcGFyYW1zIH0pO1xuICAgIH1cblxuICAgIHVwZGF0ZUFzc2Vzc21lbnRBZnRlckNvbXBsYWludChmZWVkYmFja3M6IEZlZWRiYWNrW10sIGNvbXBsYWludFJlc3BvbnNlOiBDb21wbGFpbnRSZXNwb25zZSwgc3VibWlzc2lvbklkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEVudGl0eVJlc3BvbnNlVHlwZT4ge1xuICAgICAgICBjb25zdCB1cmwgPSBgJHt0aGlzLnJlc291cmNlVXJsfS9maWxlLXVwbG9hZC1zdWJtaXNzaW9ucy8ke3N1Ym1pc3Npb25JZH0vYXNzZXNzbWVudC1hZnRlci1jb21wbGFpbnRgO1xuICAgICAgICBjb25zdCBhc3Nlc3NtZW50VXBkYXRlID0ge1xuICAgICAgICAgICAgZmVlZGJhY2tzLFxuICAgICAgICAgICAgY29tcGxhaW50UmVzcG9uc2UsXG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucHV0PFJlc3VsdD4odXJsLCBhc3Nlc3NtZW50VXBkYXRlLCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSkucGlwZShtYXAoKHJlczogRW50aXR5UmVzcG9uc2VUeXBlKSA9PiB0aGlzLmNvbnZlcnRSZXN1bHRFbnRpdHlSZXNwb25zZVR5cGVGcm9tU2VydmVyKHJlcykpKTtcbiAgICB9XG5cbiAgICAvLyBUT0RPIHJlZmFjdG9yIGFsbCBhc3NzZXNzbWVudC5zZXJ2aWNlIGdldEFzc2Vzc21lbnQgY2FsbHMgdG8gbWFrZSBzaW1pbGFyIFJFU1QgY2FsbHNcbiAgICBnZXRBc3Nlc3NtZW50KHN1Ym1pc3Npb25JZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxSZXN1bHQ+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8UmVzdWx0PihgJHt0aGlzLnJlc291cmNlVXJsfS9maWxlLXVwbG9hZC1zdWJtaXNzaW9ucy8ke3N1Ym1pc3Npb25JZH0vcmVzdWx0YCk7XG4gICAgfVxuXG4gICAgY2FuY2VsQXNzZXNzbWVudChzdWJtaXNzaW9uSWQ6IG51bWJlcik6IE9ic2VydmFibGU8dm9pZD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnB1dDx2b2lkPihgJHt0aGlzLnJlc291cmNlVXJsfS9maWxlLXVwbG9hZC1zdWJtaXNzaW9ucy8ke3N1Ym1pc3Npb25JZH0vY2FuY2VsLWFzc2Vzc21lbnRgLCBudWxsKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEZWxldGVzIGFuIGFzc2Vzc21lbnQuXG4gICAgICogQHBhcmFtIHBhcnRpY2lwYXRpb25JZCBpZCBvZiB0aGUgcGFydGljaXBhdGlvbiwgdG8gd2hpY2ggdGhlIGFzc2Vzc21lbnQgYW5kIHRoZSBzdWJtaXNzaW9uIGJlbG9uZyB0b1xuICAgICAqIEBwYXJhbSBzdWJtaXNzaW9uSWQgaWQgb2YgdGhlIHN1Ym1pc3Npb24sIHRvIHdoaWNoIHRoZSBhc3Nlc3NtZW50IGJlbG9uZ3MgdG9cbiAgICAgKiBAcGFyYW0gcmVzdWx0SWQgICAgIGlkIG9mIHRoZSByZXN1bHQgd2hpY2ggaXMgZGVsZXRlZFxuICAgICAqL1xuICAgIGRlbGV0ZUFzc2Vzc21lbnQocGFydGljaXBhdGlvbklkOiBudW1iZXIsIHN1Ym1pc3Npb25JZDogbnVtYmVyLCByZXN1bHRJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTx2b2lkPiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZGVsZXRlPHZvaWQ+KGAke3RoaXMucmVzb3VyY2VVcmx9L3BhcnRpY2lwYXRpb25zLyR7cGFydGljaXBhdGlvbklkfS9maWxlLXVwbG9hZC1zdWJtaXNzaW9ucy8ke3N1Ym1pc3Npb25JZH0vcmVzdWx0cy8ke3Jlc3VsdElkfWApO1xuICAgIH1cblxuICAgIHByaXZhdGUgY29udmVydFJlc3VsdEVudGl0eVJlc3BvbnNlVHlwZUZyb21TZXJ2ZXIocmVzOiBFbnRpdHlSZXNwb25zZVR5cGUpOiBFbnRpdHlSZXNwb25zZVR5cGUge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLmNvbnZlcnRJdGVtRnJvbVNlcnZlcihyZXMuYm9keSEpO1xuICAgICAgICByZXN1bHQuY29tcGxldGlvbkRhdGUgPSBjb252ZXJ0RGF0ZUZyb21TZXJ2ZXIocmVzdWx0LmNvbXBsZXRpb25EYXRlKTtcbiAgICAgICAgaWYgKHJlc3VsdC5zdWJtaXNzaW9uKSB7XG4gICAgICAgICAgICByZXN1bHQuc3VibWlzc2lvbi5zdWJtaXNzaW9uRGF0ZSA9IGNvbnZlcnREYXRlRnJvbVNlcnZlcihyZXN1bHQuc3VibWlzc2lvbi5zdWJtaXNzaW9uRGF0ZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc3VsdC5wYXJ0aWNpcGF0aW9uKSB7XG4gICAgICAgICAgICByZXN1bHQucGFydGljaXBhdGlvbi5pbml0aWFsaXphdGlvbkRhdGUgPSBjb252ZXJ0RGF0ZUZyb21TZXJ2ZXIocmVzdWx0LnBhcnRpY2lwYXRpb24uaW5pdGlhbGl6YXRpb25EYXRlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiByZXMuY2xvbmUoeyBib2R5OiByZXN1bHQgfSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBjb252ZXJ0SXRlbUZyb21TZXJ2ZXIocmVzdWx0OiBSZXN1bHQpOiBSZXN1bHQge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7fSwgcmVzdWx0KTtcbiAgICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQSxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLFlBQVksa0JBQWdDO0FBS3JELFNBQVMsV0FBVzs7O0FBTnBCLElBY2E7QUFkYjs7QUFPQTtBQU9NLElBQU8sOEJBQVAsTUFBTyw2QkFBMkI7TUFHaEI7TUFGWixjQUFjO01BRXRCLFlBQW9CLE1BQWdCO0FBQWhCLGFBQUEsT0FBQTtNQUFtQjtNQUV2QyxlQUFlLFdBQXVCLGNBQXNCLFNBQVMsT0FBSztBQUN0RSxZQUFJLFNBQVMsSUFBSSxXQUFVO0FBQzNCLFlBQUksUUFBUTtBQUNSLG1CQUFTLE9BQU8sSUFBSSxVQUFVLE1BQU07O0FBRXhDLGNBQU0sTUFBTSxHQUFHLEtBQUssV0FBVyw0QkFBNEIsWUFBWTtBQUN2RSxlQUFPLEtBQUssS0FBSyxJQUFZLEtBQUssV0FBVyxFQUFFLE9BQU0sQ0FBRTtNQUMzRDtNQUVBLCtCQUErQixXQUF1QixtQkFBc0MsY0FBb0I7QUFDNUcsY0FBTSxNQUFNLEdBQUcsS0FBSyxXQUFXLDRCQUE0QixZQUFZO0FBQ3ZFLGNBQU0sbUJBQW1CO1VBQ3JCO1VBQ0E7O0FBRUosZUFBTyxLQUFLLEtBQUssSUFBWSxLQUFLLGtCQUFrQixFQUFFLFNBQVMsV0FBVSxDQUFFLEVBQUUsS0FBSyxJQUFJLENBQUMsUUFBNEIsS0FBSywwQ0FBMEMsR0FBRyxDQUFDLENBQUM7TUFDM0s7TUFHQSxjQUFjLGNBQW9CO0FBQzlCLGVBQU8sS0FBSyxLQUFLLElBQVksR0FBRyxLQUFLLFdBQVcsNEJBQTRCLFlBQVksU0FBUztNQUNyRztNQUVBLGlCQUFpQixjQUFvQjtBQUNqQyxlQUFPLEtBQUssS0FBSyxJQUFVLEdBQUcsS0FBSyxXQUFXLDRCQUE0QixZQUFZLHNCQUFzQixJQUFJO01BQ3BIO01BUUEsaUJBQWlCLGlCQUF5QixjQUFzQixVQUFnQjtBQUM1RSxlQUFPLEtBQUssS0FBSyxPQUFhLEdBQUcsS0FBSyxXQUFXLG1CQUFtQixlQUFlLDRCQUE0QixZQUFZLFlBQVksUUFBUSxFQUFFO01BQ3JKO01BRVEsMENBQTBDLEtBQXVCO0FBQ3JFLGNBQU0sU0FBUyxLQUFLLHNCQUFzQixJQUFJLElBQUs7QUFDbkQsZUFBTyxpQkFBaUIsc0JBQXNCLE9BQU8sY0FBYztBQUNuRSxZQUFJLE9BQU8sWUFBWTtBQUNuQixpQkFBTyxXQUFXLGlCQUFpQixzQkFBc0IsT0FBTyxXQUFXLGNBQWM7O0FBRTdGLFlBQUksT0FBTyxlQUFlO0FBQ3RCLGlCQUFPLGNBQWMscUJBQXFCLHNCQUFzQixPQUFPLGNBQWMsa0JBQWtCOztBQUczRyxlQUFPLElBQUksTUFBTSxFQUFFLE1BQU0sT0FBTSxDQUFFO01BQ3JDO01BRVEsc0JBQXNCLFFBQWM7QUFDeEMsZUFBTyxPQUFPLE9BQU8sQ0FBQSxHQUFJLE1BQU07TUFDbkM7O3lCQXpEUyw4QkFBMkIsc0JBQUEsYUFBQSxDQUFBO01BQUE7bUVBQTNCLDhCQUEyQixTQUEzQiw2QkFBMkIsV0FBQSxZQUZ4QixPQUFNLENBQUE7Ozs7IiwibmFtZXMiOltdfQ==