import {
  ArtemisSharedComponentModule,
  init_shared_component_module
} from "/chunk-ORYTP7RT.js";
import {
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  __esm,
  init_artemis_translate_pipe,
  init_shared_module
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/date-time-picker/date-time-picker.component.ts
import { Component, ElementRef, EventEmitter, Input, Output, ViewChild, forwardRef } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NG_VALUE_ACCESSOR } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import { faCalendarAlt, faClock, faGlobe, faQuestionCircle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@danielmoncada_angular-datetime-picker.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function FormDateTimePickerComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "label", 7);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(3, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\n        ", ctx_r0.labelName, "\n    ");
  }
}
function FormDateTimePickerComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "fa-stack", 8);
    i0.\u0275\u0275text(2, "\n        ");
    i0.\u0275\u0275element(3, "fa-icon", 9);
    i0.\u0275\u0275text(4, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("ngbTooltip", ctx_r1.labelTooltip);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r1.faQuestionCircle);
  }
}
function FormDateTimePickerComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275elementStart(1, "fa-stack", 10);
    i0.\u0275\u0275pipe(2, "artemisTranslate");
    i0.\u0275\u0275text(3, "\n        ");
    i0.\u0275\u0275element(4, "fa-icon", 11);
    i0.\u0275\u0275text(5, "\n        ");
    i0.\u0275\u0275element(6, "fa-icon", 12);
    i0.\u0275\u0275text(7, "\n    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n");
  }
  if (rf & 2) {
    const ctx_r2 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275propertyInterpolate("ngbTooltip", i0.\u0275\u0275pipeBind2(2, 3, "entity.timeZoneWarning", i0.\u0275\u0275pureFunction1(6, _c1, ctx_r2.currentTimeZone)));
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("icon", ctx_r2.faGlobe);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r2.faClock);
  }
}
var _c0, _c1, _c2, FormDateTimePickerComponent;
var init_date_time_picker_component = __esm({
  "src/main/webapp/app/shared/date-time-picker/date-time-picker.component.ts"() {
    init_artemis_translate_pipe();
    _c0 = ["dateInput"];
    _c1 = (a0) => ({ timeZone: a0 });
    _c2 = (a0) => ({ "is-invalid": a0 });
    FormDateTimePickerComponent = class _FormDateTimePickerComponent {
      dateInput;
      labelName;
      labelTooltip;
      value;
      disabled;
      error;
      startAt;
      min;
      max;
      shouldDisplayTimeZoneWarning = true;
      valueChange = new EventEmitter();
      faCalendarAlt = faCalendarAlt;
      faGlobe = faGlobe;
      faClock = faClock;
      faQuestionCircle = faQuestionCircle;
      onChange;
      valueChanged() {
        this.valueChange.emit();
      }
      writeValue(value) {
        if (dayjs.isDayjs(value)) {
          this.value = value.toDate();
        } else {
          this.value = value;
        }
      }
      registerOnTouched(fn) {
      }
      registerOnChange(fn) {
        this.onChange = fn;
      }
      updateField(newValue) {
        this.value = newValue;
        this.onChange?.(dayjs(this.value));
        this.valueChanged();
      }
      get currentTimeZone() {
        return Intl.DateTimeFormat().resolvedOptions().timeZone;
      }
      get startDate() {
        return this.convertToDate(this.startAt ?? dayjs().startOf("minutes"));
      }
      get minDate() {
        return this.convertToDate(this.min);
      }
      get maxDate() {
        return this.convertToDate(this.max);
      }
      convertToDate(value) {
        return value != void 0 && value.isValid() ? value.toDate() : null;
      }
      static \u0275fac = function FormDateTimePickerComponent_Factory(t) {
        return new (t || _FormDateTimePickerComponent)();
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _FormDateTimePickerComponent, selectors: [["jhi-date-time-picker"]], viewQuery: function FormDateTimePickerComponent_Query(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275viewQuery(_c0, 5);
        }
        if (rf & 2) {
          let _t;
          i0.\u0275\u0275queryRefresh(_t = i0.\u0275\u0275loadQuery()) && (ctx.dateInput = _t.first);
        }
      }, inputs: { labelName: "labelName", labelTooltip: "labelTooltip", value: "value", disabled: "disabled", error: "error", startAt: "startAt", min: "min", max: "max", shouldDisplayTimeZoneWarning: "shouldDisplayTimeZoneWarning" }, outputs: { valueChange: "valueChange" }, features: [i0.\u0275\u0275ProvidersFeature([
        {
          provide: NG_VALUE_ACCESSOR,
          multi: true,
          useExisting: forwardRef(() => _FormDateTimePickerComponent)
        }
      ])], decls: 17, vars: 14, consts: [[1, "d-flex"], ["id", "date-input-field", "name", "datePicker", 1, "form-control", "position-relative", "ps-5", 3, "ngClass", "ngModel", "disabled", "min", "max", "owlDateTime", "ngModelChange"], ["dateInput", "ngModel"], ["type", "button", 1, "btn", "position-absolute", 3, "owlDateTimeTrigger"], [3, "icon"], [3, "startAt"], ["dt", ""], ["for", "date-input-field", 1, "form-control-label", "col"], [1, "text-secondary", "icon-full-size", 3, "ngbTooltip"], ["stackItemSize", "1x", 3, "icon"], [1, "icon-full-size", 3, "ngbTooltip"], ["stackItemSize", "1x", 1, "text-lightgrey", 3, "icon"], ["stackItemSize", "1x", "transform", "shrink-6 down-5 right-5", 1, "text-secondary", 3, "icon"]], template: function FormDateTimePickerComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275template(0, FormDateTimePickerComponent_Conditional_0_Template, 4, 1)(1, FormDateTimePickerComponent_Conditional_1_Template, 6, 2)(2, FormDateTimePickerComponent_Conditional_2_Template, 9, 8);
          i0.\u0275\u0275elementStart(3, "div", 0);
          i0.\u0275\u0275text(4, "\n    ");
          i0.\u0275\u0275elementStart(5, "input", 1, 2);
          i0.\u0275\u0275listener("ngModelChange", function FormDateTimePickerComponent_Template_input_ngModelChange_5_listener($event) {
            return ctx.updateField($event);
          });
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(7, "\n    ");
          i0.\u0275\u0275elementStart(8, "button", 3);
          i0.\u0275\u0275text(9, "\n        ");
          i0.\u0275\u0275element(10, "fa-icon", 4);
          i0.\u0275\u0275text(11, "\n    ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(12, "\n    ");
          i0.\u0275\u0275element(13, "owl-date-time", 5, 6);
          i0.\u0275\u0275text(15, "\n");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(16, "\n");
        }
        if (rf & 2) {
          const _r4 = i0.\u0275\u0275reference(14);
          i0.\u0275\u0275conditional(0, ctx.labelName ? 0 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275conditional(1, ctx.labelTooltip ? 1 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275conditional(2, ctx.shouldDisplayTimeZoneWarning ? 2 : -1);
          i0.\u0275\u0275advance(3);
          i0.\u0275\u0275property("ngClass", i0.\u0275\u0275pureFunction1(12, _c2, ctx.error))("ngModel", ctx.value)("disabled", ctx.disabled)("min", ctx.minDate)("max", ctx.maxDate)("owlDateTime", _r4);
          i0.\u0275\u0275advance(3);
          i0.\u0275\u0275property("owlDateTimeTrigger", _r4);
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275property("icon", ctx.faCalendarAlt);
          i0.\u0275\u0275advance(3);
          i0.\u0275\u0275property("startAt", ctx.startDate);
        }
      }, dependencies: [i1.NgClass, i2.DefaultValueAccessor, i2.NgControlStatus, i2.NgModel, i3.OwlDateTimeTriggerDirective, i3.OwlDateTimeInputDirective, i3.OwlDateTimeComponent, i4.NgbTooltip, i5.FaIconComponent, i5.FaStackComponent, i5.FaStackItemSizeDirective, ArtemisTranslatePipe], styles: ["\n\n.icon-full-size[_ngcontent-%COMP%] {\n  height: 1rem;\n  width: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvZGF0ZS10aW1lLXBpY2tlci9kYXRlLXRpbWUtcGlja2VyLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuaWNvbi1mdWxsLXNpemUge1xuICAgIGhlaWdodDogMXJlbTtcbiAgICB3aWR0aDogMXJlbTtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksVUFBQTtBQUNBLFNBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(FormDateTimePickerComponent, { className: "FormDateTimePickerComponent" });
    })();
  }
});

// src/main/webapp/app/shared/date-time-picker/date-time-picker.module.ts
import { CommonModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import { FormsModule, ReactiveFormsModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { OWL_DATE_TIME_FORMATS, OwlDateTimeModule, OwlNativeDateTimeModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@danielmoncada_angular-datetime-picker.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var MY_NATIVE_FORMATS, FormDateTimePickerModule;
var init_date_time_picker_module = __esm({
  "src/main/webapp/app/shared/date-time-picker/date-time-picker.module.ts"() {
    init_date_time_picker_component();
    init_shared_module();
    init_shared_component_module();
    MY_NATIVE_FORMATS = {
      fullPickerInput: { year: "numeric", month: "short", day: "numeric", hour: "numeric", minute: "numeric", second: "numeric" },
      datePickerInput: { year: "numeric", month: "numeric", day: "numeric" },
      timePickerInput: { hour: "numeric", minute: "numeric" },
      monthYearLabel: { year: "numeric", month: "short" },
      dateA11yLabel: { year: "numeric", month: "long", day: "numeric" },
      monthYearA11yLabel: { year: "numeric", month: "long" }
    };
    FormDateTimePickerModule = class _FormDateTimePickerModule {
      static \u0275fac = function FormDateTimePickerModule_Factory(t) {
        return new (t || _FormDateTimePickerModule)();
      };
      static \u0275mod = i02.\u0275\u0275defineNgModule({ type: _FormDateTimePickerModule });
      static \u0275inj = i02.\u0275\u0275defineInjector({ providers: [{ provide: OWL_DATE_TIME_FORMATS, useValue: MY_NATIVE_FORMATS }], imports: [CommonModule, FormsModule, OwlDateTimeModule, OwlNativeDateTimeModule, ReactiveFormsModule, ArtemisSharedModule, ArtemisSharedComponentModule] });
    };
  }
});

export {
  FormDateTimePickerComponent,
  init_date_time_picker_component,
  FormDateTimePickerModule,
  init_date_time_picker_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2RhdGUtdGltZS1waWNrZXIvZGF0ZS10aW1lLXBpY2tlci5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9kYXRlLXRpbWUtcGlja2VyL2RhdGUtdGltZS1waWNrZXIuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9kYXRlLXRpbWUtcGlja2VyL2RhdGUtdGltZS1waWNrZXIubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgRWxlbWVudFJlZiwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT3V0cHV0LCBWaWV3Q2hpbGQsIGZvcndhcmRSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBOR19WQUxVRV9BQ0NFU1NPUiB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IGZhQ2FsZW5kYXJBbHQsIGZhQ2xvY2ssIGZhR2xvYmUsIGZhUXVlc3Rpb25DaXJjbGUgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IGRheWpzIGZyb20gJ2RheWpzL2VzbSc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWRhdGUtdGltZS1waWNrZXInLFxuICAgIHRlbXBsYXRlVXJsOiBgLi9kYXRlLXRpbWUtcGlja2VyLmNvbXBvbmVudC5odG1sYCxcbiAgICBzdHlsZVVybHM6IFtgLi9kYXRlLXRpbWUtcGlja2VyLmNvbXBvbmVudC5zY3NzYF0sXG4gICAgcHJvdmlkZXJzOiBbXG4gICAgICAgIHtcbiAgICAgICAgICAgIHByb3ZpZGU6IE5HX1ZBTFVFX0FDQ0VTU09SLFxuICAgICAgICAgICAgbXVsdGk6IHRydWUsXG4gICAgICAgICAgICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBGb3JtRGF0ZVRpbWVQaWNrZXJDb21wb25lbnQpLFxuICAgICAgICB9LFxuICAgIF0sXG59KVxuZXhwb3J0IGNsYXNzIEZvcm1EYXRlVGltZVBpY2tlckNvbXBvbmVudCBpbXBsZW1lbnRzIENvbnRyb2xWYWx1ZUFjY2Vzc29yIHtcbiAgICBAVmlld0NoaWxkKCdkYXRlSW5wdXQnLCB7IHN0YXRpYzogZmFsc2UgfSkgZGF0ZUlucHV0OiBFbGVtZW50UmVmO1xuICAgIEBJbnB1dCgpIGxhYmVsTmFtZTogc3RyaW5nO1xuICAgIEBJbnB1dCgpIGxhYmVsVG9vbHRpcDogc3RyaW5nO1xuICAgIEBJbnB1dCgpIHZhbHVlOiBhbnk7XG4gICAgQElucHV0KCkgZGlzYWJsZWQ6IGJvb2xlYW47XG4gICAgQElucHV0KCkgZXJyb3I6IGJvb2xlYW47XG4gICAgQElucHV0KCkgc3RhcnRBdD86IGRheWpzLkRheWpzOyAvLyBEZWZhdWx0IHNlbGVjdGVkIGRhdGUuIEJ5IGRlZmF1bHQgdGhpcyBzZXRzIGl0IHRvIHRoZSBjdXJyZW50IHRpbWUgd2l0aG91dCBzZWNvbmRzIG9yIG1pbGxpc2Vjb25kcztcbiAgICBASW5wdXQoKSBtaW46IGRheWpzLkRheWpzOyAvLyBEYXRlcyBiZWZvcmUgdGhpcyBkYXRlIGFyZSBub3Qgc2VsZWN0YWJsZS5cbiAgICBASW5wdXQoKSBtYXg6IGRheWpzLkRheWpzOyAvLyBEYXRlcyBhZnRlciB0aGlzIGRhdGUgYXJlIG5vdCBzZWxlY3RhYmxlLlxuICAgIEBJbnB1dCgpIHNob3VsZERpc3BsYXlUaW1lWm9uZVdhcm5pbmcgPSB0cnVlOyAvLyBEaXNwbGF5cyBhIHdhcm5pbmcgdGhhdCB0aGUgY3VycmVudCB0aW1lIHpvbmUgbWlnaHQgZGlmZmVyIGZyb20gdGhlIHBhcnRpY2lwYW50cycuXG4gICAgQE91dHB1dCgpIHZhbHVlQ2hhbmdlID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUNhbGVuZGFyQWx0ID0gZmFDYWxlbmRhckFsdDtcbiAgICBmYUdsb2JlID0gZmFHbG9iZTtcbiAgICBmYUNsb2NrID0gZmFDbG9jaztcbiAgICBmYVF1ZXN0aW9uQ2lyY2xlID0gZmFRdWVzdGlvbkNpcmNsZTtcblxuICAgIHByaXZhdGUgb25DaGFuZ2U/OiAodmFsPzogZGF5anMuRGF5anMpID0+IHZvaWQ7XG5cbiAgICAvKipcbiAgICAgKiBFbWl0cyB0aGUgdmFsdWUgY2hhbmdlIGZyb20gY29tcG9uZW50LlxuICAgICAqL1xuICAgIHZhbHVlQ2hhbmdlZCgpIHtcbiAgICAgICAgdGhpcy52YWx1ZUNoYW5nZS5lbWl0KCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRnVuY3Rpb24gdGhhdCB3cml0ZXMgdGhlIHZhbHVlIHNhZmVseS5cbiAgICAgKiBAcGFyYW0gdmFsdWUgYXMgZGF5anMgb3IgZGF0ZVxuICAgICAqL1xuICAgIHdyaXRlVmFsdWUodmFsdWU6IGFueSkge1xuICAgICAgICAvLyBjb252ZXJ0IGRheWpzIHRvIGRhdGUsIGJlY2F1c2Ugb3dsLWRhdGUtdGltZSBvbmx5IHdvcmtzIGNvcnJlY3RseSB3aXRoIGRhdGUgb2JqZWN0c1xuICAgICAgICBpZiAoZGF5anMuaXNEYXlqcyh2YWx1ZSkpIHtcbiAgICAgICAgICAgIHRoaXMudmFsdWUgPSAodmFsdWUgYXMgZGF5anMuRGF5anMpLnRvRGF0ZSgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy52YWx1ZSA9IHZhbHVlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmVnaXN0ZXJzIGEgY2FsbGJhY2sgZnVuY3Rpb24gaXMgY2FsbGVkIGJ5IHRoZSBmb3JtcyBBUEkgb24gaW5pdGlhbGl6YXRpb24gdG8gdXBkYXRlIHRoZSBmb3JtIG1vZGVsIG9uIGJsdXIuXG4gICAgICogQHBhcmFtIGZuXG4gICAgICovXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICAgIHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiBhbnkpIHt9XG5cbiAgICAvKipcbiAgICAgKlxuICAgICAqIEBwYXJhbSBmblxuICAgICAqL1xuICAgIHJlZ2lzdGVyT25DaGFuZ2UoZm46IGFueSkge1xuICAgICAgICB0aGlzLm9uQ2hhbmdlID0gZm47XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbmV3VmFsdWVcbiAgICAgKi9cbiAgICB1cGRhdGVGaWVsZChuZXdWYWx1ZTogZGF5anMuRGF5anMpIHtcbiAgICAgICAgdGhpcy52YWx1ZSA9IG5ld1ZhbHVlO1xuICAgICAgICB0aGlzLm9uQ2hhbmdlPy4oZGF5anModGhpcy52YWx1ZSkpO1xuICAgICAgICB0aGlzLnZhbHVlQ2hhbmdlZCgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCB0aGUgY3VycmVudCB0aW1lIHpvbmUgb2YgdGhlIHVzZXIgLyBicm93c2VyXG4gICAgICovXG4gICAgZ2V0IGN1cnJlbnRUaW1lWm9uZSgpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gSW50bC5EYXRlVGltZUZvcm1hdCgpLnJlc29sdmVkT3B0aW9ucygpLnRpbWVab25lO1xuICAgIH1cblxuICAgIGdldCBzdGFydERhdGUoKTogRGF0ZSB8IG51bGwge1xuICAgICAgICByZXR1cm4gdGhpcy5jb252ZXJ0VG9EYXRlKHRoaXMuc3RhcnRBdCA/PyBkYXlqcygpLnN0YXJ0T2YoJ21pbnV0ZXMnKSk7XG4gICAgfVxuXG4gICAgZ2V0IG1pbkRhdGUoKTogRGF0ZSB8IG51bGwge1xuICAgICAgICByZXR1cm4gdGhpcy5jb252ZXJ0VG9EYXRlKHRoaXMubWluKTtcbiAgICB9XG5cbiAgICBnZXQgbWF4RGF0ZSgpOiBEYXRlIHwgbnVsbCB7XG4gICAgICAgIHJldHVybiB0aGlzLmNvbnZlcnRUb0RhdGUodGhpcy5tYXgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEZ1bmN0aW9uIHRoYXQgY29udmVydHMgYSBwb3NzaWJseSB1bmRlZmluZWQgZGF5anMgdmFsdWUgdG8gYSBkYXRlIG9yIG51bGwuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdmFsdWUgYXMgZGF5anNcbiAgICAgKi9cbiAgICBjb252ZXJ0VG9EYXRlKHZhbHVlPzogZGF5anMuRGF5anMpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlICE9IHVuZGVmaW5lZCAmJiB2YWx1ZS5pc1ZhbGlkKCkgPyB2YWx1ZS50b0RhdGUoKSA6IG51bGw7XG4gICAgfVxufVxuIiwiQGlmIChsYWJlbE5hbWUpIHtcbiAgICA8bGFiZWwgZm9yPVwiZGF0ZS1pbnB1dC1maWVsZFwiIGNsYXNzPVwiZm9ybS1jb250cm9sLWxhYmVsIGNvbFwiPlxuICAgICAgICB7eyBsYWJlbE5hbWUgfX1cbiAgICA8L2xhYmVsPlxufVxuQGlmIChsYWJlbFRvb2x0aXApIHtcbiAgICA8ZmEtc3RhY2sgY2xhc3M9XCJ0ZXh0LXNlY29uZGFyeSBpY29uLWZ1bGwtc2l6ZVwiIFtuZ2JUb29sdGlwXT1cImxhYmVsVG9vbHRpcFwiPlxuICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVF1ZXN0aW9uQ2lyY2xlXCIgc3RhY2tJdGVtU2l6ZT1cIjF4XCI+PC9mYS1pY29uPlxuICAgIDwvZmEtc3RhY2s+XG59XG5AaWYgKHNob3VsZERpc3BsYXlUaW1lWm9uZVdhcm5pbmcpIHtcbiAgICA8ZmEtc3RhY2sgbmdiVG9vbHRpcD1cInt7ICdlbnRpdHkudGltZVpvbmVXYXJuaW5nJyB8IGFydGVtaXNUcmFuc2xhdGU6IHsgdGltZVpvbmU6IGN1cnJlbnRUaW1lWm9uZSB9IH19XCIgY2xhc3M9XCJpY29uLWZ1bGwtc2l6ZVwiPlxuICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUdsb2JlXCIgc3RhY2tJdGVtU2l6ZT1cIjF4XCIgY2xhc3M9XCJ0ZXh0LWxpZ2h0Z3JleVwiPjwvZmEtaWNvbj5cbiAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFDbG9ja1wiIHN0YWNrSXRlbVNpemU9XCIxeFwiIHRyYW5zZm9ybT1cInNocmluay02IGRvd24tNSByaWdodC01XCIgY2xhc3M9XCJ0ZXh0LXNlY29uZGFyeVwiPjwvZmEtaWNvbj5cbiAgICA8L2ZhLXN0YWNrPlxufVxuPGRpdiBjbGFzcz1cImQtZmxleFwiPlxuICAgIDxpbnB1dFxuICAgICAgICAjZGF0ZUlucHV0PVwibmdNb2RlbFwiXG4gICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sIHBvc2l0aW9uLXJlbGF0aXZlIHBzLTVcIlxuICAgICAgICBpZD1cImRhdGUtaW5wdXQtZmllbGRcIlxuICAgICAgICBbbmdDbGFzc109XCJ7ICdpcy1pbnZhbGlkJzogZXJyb3IgfVwiXG4gICAgICAgIFtuZ01vZGVsXT1cInZhbHVlXCJcbiAgICAgICAgW2Rpc2FibGVkXT1cImRpc2FibGVkXCJcbiAgICAgICAgW21pbl09XCJtaW5EYXRlXCJcbiAgICAgICAgW21heF09XCJtYXhEYXRlXCJcbiAgICAgICAgKG5nTW9kZWxDaGFuZ2UpPVwidXBkYXRlRmllbGQoJGV2ZW50KVwiXG4gICAgICAgIFtvd2xEYXRlVGltZV09XCJkdFwiXG4gICAgICAgIG5hbWU9XCJkYXRlUGlja2VyXCJcbiAgICAvPlxuICAgIDxidXR0b24gW293bERhdGVUaW1lVHJpZ2dlcl09XCJkdFwiIGNsYXNzPVwiYnRuIHBvc2l0aW9uLWFic29sdXRlXCIgdHlwZT1cImJ1dHRvblwiPlxuICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYUNhbGVuZGFyQWx0XCI+PC9mYS1pY29uPlxuICAgIDwvYnV0dG9uPlxuICAgIDxvd2wtZGF0ZS10aW1lIFtzdGFydEF0XT1cInN0YXJ0RGF0ZVwiICNkdD48L293bC1kYXRlLXRpbWU+XG48L2Rpdj5cbiIsImltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBGb3Jtc01vZHVsZSwgUmVhY3RpdmVGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPV0xfREFURV9USU1FX0ZPUk1BVFMsIE93bERhdGVUaW1lTW9kdWxlLCBPd2xOYXRpdmVEYXRlVGltZU1vZHVsZSB9IGZyb20gJ0BkYW5pZWxtb25jYWRhL2FuZ3VsYXItZGF0ZXRpbWUtcGlja2VyJztcbmltcG9ydCB7IEZvcm1EYXRlVGltZVBpY2tlckNvbXBvbmVudCB9IGZyb20gJy4vZGF0ZS10aW1lLXBpY2tlci5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL3NoYXJlZC1jb21wb25lbnQubW9kdWxlJztcblxuZXhwb3J0IGNvbnN0IE1ZX05BVElWRV9GT1JNQVRTID0ge1xuICAgIGZ1bGxQaWNrZXJJbnB1dDogeyB5ZWFyOiAnbnVtZXJpYycsIG1vbnRoOiAnc2hvcnQnLCBkYXk6ICdudW1lcmljJywgaG91cjogJ251bWVyaWMnLCBtaW51dGU6ICdudW1lcmljJywgc2Vjb25kOiAnbnVtZXJpYycgfSxcbiAgICBkYXRlUGlja2VySW5wdXQ6IHsgeWVhcjogJ251bWVyaWMnLCBtb250aDogJ251bWVyaWMnLCBkYXk6ICdudW1lcmljJyB9LFxuICAgIHRpbWVQaWNrZXJJbnB1dDogeyBob3VyOiAnbnVtZXJpYycsIG1pbnV0ZTogJ251bWVyaWMnIH0sXG4gICAgbW9udGhZZWFyTGFiZWw6IHsgeWVhcjogJ251bWVyaWMnLCBtb250aDogJ3Nob3J0JyB9LFxuICAgIGRhdGVBMTF5TGFiZWw6IHsgeWVhcjogJ251bWVyaWMnLCBtb250aDogJ2xvbmcnLCBkYXk6ICdudW1lcmljJyB9LFxuICAgIG1vbnRoWWVhckExMXlMYWJlbDogeyB5ZWFyOiAnbnVtZXJpYycsIG1vbnRoOiAnbG9uZycgfSxcbn07XG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtDb21tb25Nb2R1bGUsIEZvcm1zTW9kdWxlLCBPd2xEYXRlVGltZU1vZHVsZSwgT3dsTmF0aXZlRGF0ZVRpbWVNb2R1bGUsIFJlYWN0aXZlRm9ybXNNb2R1bGUsIEFydGVtaXNTaGFyZWRNb2R1bGUsIEFydGVtaXNTaGFyZWRDb21wb25lbnRNb2R1bGVdLFxuICAgIGV4cG9ydHM6IFtGb3JtRGF0ZVRpbWVQaWNrZXJDb21wb25lbnRdLFxuICAgIGRlY2xhcmF0aW9uczogW0Zvcm1EYXRlVGltZVBpY2tlckNvbXBvbmVudF0sXG4gICAgcHJvdmlkZXJzOiBbeyBwcm92aWRlOiBPV0xfREFURV9USU1FX0ZPUk1BVFMsIHVzZVZhbHVlOiBNWV9OQVRJVkVfRk9STUFUUyB9XSxcbn0pXG5leHBvcnQgY2xhc3MgRm9ybURhdGVUaW1lUGlja2VyTW9kdWxlIHt9XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLFdBQVcsWUFBWSxjQUFjLE9BQU8sUUFBUSxXQUFXLGtCQUFrQjtBQUMxRixTQUErQix5QkFBeUI7QUFDeEQsU0FBUyxlQUFlLFNBQVMsU0FBUyx3QkFBd0I7QUFDbEUsT0FBTyxXQUFXOzs7Ozs7Ozs7QUNGZCxJQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxTQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLENBQUE7QUFDSixJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLElBQUE7Ozs7QUFGUSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLGNBQUEsT0FBQSxXQUFBLFFBQUE7Ozs7O0FBSUosSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsWUFBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLElBQUE7Ozs7QUFIb0QsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxjQUFBLE9BQUEsWUFBQTtBQUNuQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFFBQUEsT0FBQSxnQkFBQTs7Ozs7QUFJYixJQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxZQUFBLEVBQUE7O0FBQ0ksSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLElBQUE7Ozs7QUFKYyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLG1DQUFBLGNBQUEseUJBQUEsR0FBQSxHQUFBLDBCQUFBLDZCQUFBLEdBQUEsS0FBQSxPQUFBLGVBQUEsQ0FBQSxDQUFBO0FBQ0csSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxRQUFBLE9BQUEsT0FBQTtBQUNBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsUUFBQSxPQUFBLE9BQUE7OztBRGJqQixtQkFpQmE7QUFqQmI7Ozs7OztBQWlCTSxJQUFPLDhCQUFQLE1BQU8sNkJBQTJCO01BQ087TUFDbEM7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLCtCQUErQjtNQUM5QixjQUFjLElBQUksYUFBWTtNQUd4QyxnQkFBZ0I7TUFDaEIsVUFBVTtNQUNWLFVBQVU7TUFDVixtQkFBbUI7TUFFWDtNQUtSLGVBQVk7QUFDUixhQUFLLFlBQVksS0FBSTtNQUN6QjtNQU1BLFdBQVcsT0FBVTtBQUVqQixZQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7QUFDdEIsZUFBSyxRQUFTLE1BQXNCLE9BQU07ZUFDdkM7QUFDSCxlQUFLLFFBQVE7O01BRXJCO01BT0Esa0JBQWtCLElBQU87TUFBRztNQU01QixpQkFBaUIsSUFBTztBQUNwQixhQUFLLFdBQVc7TUFDcEI7TUFNQSxZQUFZLFVBQXFCO0FBQzdCLGFBQUssUUFBUTtBQUNiLGFBQUssV0FBVyxNQUFNLEtBQUssS0FBSyxDQUFDO0FBQ2pDLGFBQUssYUFBWTtNQUNyQjtNQUtBLElBQUksa0JBQWU7QUFDZixlQUFPLEtBQUssZUFBYyxFQUFHLGdCQUFlLEVBQUc7TUFDbkQ7TUFFQSxJQUFJLFlBQVM7QUFDVCxlQUFPLEtBQUssY0FBYyxLQUFLLFdBQVcsTUFBSyxFQUFHLFFBQVEsU0FBUyxDQUFDO01BQ3hFO01BRUEsSUFBSSxVQUFPO0FBQ1AsZUFBTyxLQUFLLGNBQWMsS0FBSyxHQUFHO01BQ3RDO01BRUEsSUFBSSxVQUFPO0FBQ1AsZUFBTyxLQUFLLGNBQWMsS0FBSyxHQUFHO01BQ3RDO01BT0EsY0FBYyxPQUFtQjtBQUM3QixlQUFPLFNBQVMsVUFBYSxNQUFNLFFBQU8sSUFBSyxNQUFNLE9BQU0sSUFBSztNQUNwRTs7eUJBNUZTLDhCQUEyQjtNQUFBO2dFQUEzQiw4QkFBMkIsV0FBQSxDQUFBLENBQUEsc0JBQUEsQ0FBQSxHQUFBLFdBQUEsU0FBQSxrQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7Ozs7OzsrVEFSekI7UUFDUDtVQUNJLFNBQVM7VUFDVCxPQUFPO1VBQ1AsYUFBYSxXQUFXLE1BQU0sNEJBQTJCOztPQUVoRSxDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLE1BQUEsb0JBQUEsUUFBQSxjQUFBLEdBQUEsZ0JBQUEscUJBQUEsUUFBQSxHQUFBLFdBQUEsV0FBQSxZQUFBLE9BQUEsT0FBQSxlQUFBLGVBQUEsR0FBQSxDQUFBLGFBQUEsU0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsT0FBQSxxQkFBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsTUFBQSxFQUFBLEdBQUEsQ0FBQSxPQUFBLG9CQUFBLEdBQUEsc0JBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxrQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLGlCQUFBLE1BQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsaUJBQUEsTUFBQSxHQUFBLGtCQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsaUJBQUEsTUFBQSxhQUFBLDJCQUFBLEdBQUEsa0JBQUEsR0FBQSxNQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEscUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNmTCxVQUFBLHdCQUFBLEdBQUEsb0RBQUEsR0FBQSxDQUFBLEVBSUMsR0FBQSxvREFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLG9EQUFBLEdBQUEsQ0FBQTtBQVlELFVBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQTtBQVNJLFVBQUEsd0JBQUEsaUJBQUEsU0FBQSxvRUFBQSxRQUFBO0FBQUEsbUJBQWlCLElBQUEsWUFBQSxNQUFBO1VBQW1CLENBQUE7QUFUeEMsVUFBQSwwQkFBQTtBQWFBLFVBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUNJLFVBQUEsb0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSx1QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNKLFVBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSx1QkFBQSxJQUFBLGlCQUFBLEdBQUEsQ0FBQTtBQUNKLFVBQUEsb0JBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsSUFBQSxJQUFBOzs7O0FBbkNBLFVBQUEsMkJBQUEsR0FBQSxJQUFBLFlBQUEsSUFBQSxFQUFBO0FBS0EsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSwyQkFBQSxHQUFBLElBQUEsZUFBQSxJQUFBLEVBQUE7QUFLQSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLDJCQUFBLEdBQUEsSUFBQSwrQkFBQSxJQUFBLEVBQUE7QUFXUSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLHdCQUFBLFdBQUEsNkJBQUEsSUFBQSxLQUFBLElBQUEsS0FBQSxDQUFBLEVBQW1DLFdBQUEsSUFBQSxLQUFBLEVBQUEsWUFBQSxJQUFBLFFBQUEsRUFBQSxPQUFBLElBQUEsT0FBQSxFQUFBLE9BQUEsSUFBQSxPQUFBLEVBQUEsZUFBQSxHQUFBO0FBUy9CLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsd0JBQUEsc0JBQUEsR0FBQTtBQUNLLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsd0JBQUEsUUFBQSxJQUFBLGFBQUE7QUFFRSxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLHdCQUFBLFdBQUEsSUFBQSxTQUFBOzs7OztvRkRoQk4sNkJBQTJCLEVBQUEsV0FBQSw4QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVqQnhDLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsYUFBYSwyQkFBMkI7QUFDakQsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyx1QkFBdUIsbUJBQW1CLCtCQUErQjs7QUFIbEYsSUFRYSxtQkFjQTtBQXRCYjs7QUFJQTtBQUNBO0FBQ0E7QUFFTyxJQUFNLG9CQUFvQjtNQUM3QixpQkFBaUIsRUFBRSxNQUFNLFdBQVcsT0FBTyxTQUFTLEtBQUssV0FBVyxNQUFNLFdBQVcsUUFBUSxXQUFXLFFBQVEsVUFBUztNQUN6SCxpQkFBaUIsRUFBRSxNQUFNLFdBQVcsT0FBTyxXQUFXLEtBQUssVUFBUztNQUNwRSxpQkFBaUIsRUFBRSxNQUFNLFdBQVcsUUFBUSxVQUFTO01BQ3JELGdCQUFnQixFQUFFLE1BQU0sV0FBVyxPQUFPLFFBQU87TUFDakQsZUFBZSxFQUFFLE1BQU0sV0FBVyxPQUFPLFFBQVEsS0FBSyxVQUFTO01BQy9ELG9CQUFvQixFQUFFLE1BQU0sV0FBVyxPQUFPLE9BQU07O0FBUWxELElBQU8sMkJBQVAsTUFBTywwQkFBd0I7O3lCQUF4QiwyQkFBd0I7TUFBQTtnRUFBeEIsMEJBQXdCLENBQUE7cUVBRnRCLENBQUMsRUFBRSxTQUFTLHVCQUF1QixVQUFVLGtCQUFpQixDQUFFLEdBQUMsU0FBQSxDQUhsRSxjQUFjLGFBQWEsbUJBQW1CLHlCQUF5QixxQkFBcUIscUJBQXFCLDRCQUE0QixFQUFBLENBQUE7Ozs7IiwibmFtZXMiOltdfQ==