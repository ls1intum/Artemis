import {
  LANGUAGES,
  init_language_constants
} from "/chunk-7UUXNRQV.js";
import {
  LocaleConversionService,
  __esm,
  init_locale_conversion_service
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/core/language/language.helper.ts
import { Injectable, RendererFactory2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Title } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_platform-browser.js?v=1d0d9ead";
import { Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import { BehaviorSubject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { captureException } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@sentry_angular-ivy.js?v=1d0d9ead";
import { SessionStorageService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_platform-browser.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
var JhiLanguageHelper;
var init_language_helper = __esm({
  "src/main/webapp/app/core/language/language.helper.ts"() {
    init_language_constants();
    init_locale_conversion_service();
    init_locale_conversion_service();
    JhiLanguageHelper = class _JhiLanguageHelper {
      translateService;
      localeConversionService;
      titleService;
      router;
      sessionStorage;
      renderer;
      _language;
      constructor(translateService, localeConversionService, titleService, router, rootRenderer, sessionStorage) {
        this.translateService = translateService;
        this.localeConversionService = localeConversionService;
        this.titleService = titleService;
        this.router = router;
        this.sessionStorage = sessionStorage;
        this._language = new BehaviorSubject(this.translateService.currentLang);
        this.renderer = rootRenderer.createRenderer(document.querySelector("html"), null);
        this.init();
      }
      getAll() {
        return LANGUAGES;
      }
      get language() {
        return this._language.asObservable();
      }
      updateTitle(titleKey) {
        if (!titleKey) {
          titleKey = this.getPageTitle(this.router.routerState.snapshot.root);
        }
        this.translateService.get(titleKey).subscribe((title) => {
          if (title) {
            this.titleService.setTitle(title);
          } else {
            captureException(new Error(`Translation key '${titleKey}' for page title not found`));
          }
        });
      }
      init() {
        this.translateService.onLangChange.subscribe(() => {
          const languageKey = this.translateService.currentLang;
          this._language.next(languageKey);
          this.localeConversionService.locale = languageKey;
          this.sessionStorage.store("locale", languageKey);
          this.renderer.setAttribute(document.querySelector("html"), "lang", this.translateService.currentLang);
          this.updateTitle();
        });
      }
      getPageTitle(routeSnapshot) {
        let title = routeSnapshot.data?.["pageTitle"] || "global.title";
        if (routeSnapshot.firstChild) {
          title = this.getPageTitle(routeSnapshot.firstChild) || title;
        }
        return title;
      }
      determinePreferredLanguage() {
        const navigator2 = this.getNavigatorReference();
        for (let i = 0; i < navigator2.languages.length; i++) {
          if (navigator2.languages[i].startsWith("en")) {
            return "en";
          }
          if (navigator2.languages[i].startsWith("de")) {
            return "de";
          }
        }
        return "en";
      }
      getNavigatorReference() {
        return navigator;
      }
      static \u0275fac = function JhiLanguageHelper_Factory(t) {
        return new (t || _JhiLanguageHelper)(i0.\u0275\u0275inject(i1.TranslateService), i0.\u0275\u0275inject(LocaleConversionService), i0.\u0275\u0275inject(i3.Title), i0.\u0275\u0275inject(i4.Router), i0.\u0275\u0275inject(i0.RendererFactory2), i0.\u0275\u0275inject(i5.SessionStorageService));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _JhiLanguageHelper, factory: _JhiLanguageHelper.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  JhiLanguageHelper,
  init_language_helper
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvY29yZS9sYW5ndWFnZS9sYW5ndWFnZS5oZWxwZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgUmVuZGVyZXIyLCBSZW5kZXJlckZhY3RvcnkyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBUaXRsZSB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGVTbmFwc2hvdCwgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IFRyYW5zbGF0ZVNlcnZpY2UgfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9jb3JlJztcblxuaW1wb3J0IHsgTEFOR1VBR0VTIH0gZnJvbSAnLi9sYW5ndWFnZS5jb25zdGFudHMnO1xuaW1wb3J0IHsgQmVoYXZpb3JTdWJqZWN0LCBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBjYXB0dXJlRXhjZXB0aW9uIH0gZnJvbSAnQHNlbnRyeS9hbmd1bGFyLWl2eSc7XG5pbXBvcnQgeyBTZXNzaW9uU3RvcmFnZVNlcnZpY2UgfSBmcm9tICduZ3gtd2Vic3RvcmFnZSc7XG5pbXBvcnQgeyBMb2NhbGVDb252ZXJzaW9uU2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2VydmljZS9sb2NhbGUtY29udmVyc2lvbi5zZXJ2aWNlJztcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBKaGlMYW5ndWFnZUhlbHBlciB7XG4gICAgcHJpdmF0ZSByZW5kZXJlcjogUmVuZGVyZXIyO1xuICAgIHByaXZhdGUgX2xhbmd1YWdlOiBCZWhhdmlvclN1YmplY3Q8c3RyaW5nPjtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIHRyYW5zbGF0ZVNlcnZpY2U6IFRyYW5zbGF0ZVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgbG9jYWxlQ29udmVyc2lvblNlcnZpY2U6IExvY2FsZUNvbnZlcnNpb25TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHRpdGxlU2VydmljZTogVGl0bGUsXG4gICAgICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgICAgIHJvb3RSZW5kZXJlcjogUmVuZGVyZXJGYWN0b3J5MixcbiAgICAgICAgcHJpdmF0ZSBzZXNzaW9uU3RvcmFnZTogU2Vzc2lvblN0b3JhZ2VTZXJ2aWNlLFxuICAgICkge1xuICAgICAgICB0aGlzLl9sYW5ndWFnZSA9IG5ldyBCZWhhdmlvclN1YmplY3Q8c3RyaW5nPih0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuY3VycmVudExhbmcpO1xuICAgICAgICB0aGlzLnJlbmRlcmVyID0gcm9vdFJlbmRlcmVyLmNyZWF0ZVJlbmRlcmVyKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2h0bWwnKSwgbnVsbCk7XG4gICAgICAgIHRoaXMuaW5pdCgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBhbGwgc3VwcG9ydGVkIElTT182MzktMSBsYW5ndWFnZSBjb2Rlcy5cbiAgICAgKi9cbiAgICBnZXRBbGwoKTogc3RyaW5nW10ge1xuICAgICAgICByZXR1cm4gTEFOR1VBR0VTO1xuICAgIH1cblxuICAgIGdldCBsYW5ndWFnZSgpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gdGhpcy5fbGFuZ3VhZ2UuYXNPYnNlcnZhYmxlKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlIHRoZSB3aW5kb3cgdGl0bGUgdXNpbmcgYSB2YWx1ZSBmcm9tIHRoZSBmb2xsb3dpbmcgb3JkZXI6XG4gICAgICogMS4gVGhlIGZ1bmN0aW9uJ3MgdGl0bGVLZXkgcGFyYW1ldGVyXG4gICAgICogMi4gVGhlIHJldHVybiB2YWx1ZSBvZiB7QGxpbmsgZ2V0UGFnZVRpdGxlfSwgZXh0cmFjdGluZyBpdCBmcm9tIHRoZSByb3V0ZXIgc3RhdGUgb3IgYSBmYWxsYmFjayB2YWx1ZVxuICAgICAqIElmIHRoZSB0cmFuc2xhdGlvbiBkb2Vzbid0IGV4aXN0LCBhIFNlbnRyeSBleGNlcHRpb24gaXMgdGhyb3duLlxuICAgICAqL1xuICAgIHVwZGF0ZVRpdGxlKHRpdGxlS2V5Pzogc3RyaW5nKSB7XG4gICAgICAgIGlmICghdGl0bGVLZXkpIHtcbiAgICAgICAgICAgIHRpdGxlS2V5ID0gdGhpcy5nZXRQYWdlVGl0bGUodGhpcy5yb3V0ZXIucm91dGVyU3RhdGUuc25hcHNob3Qucm9vdCk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuZ2V0KHRpdGxlS2V5KS5zdWJzY3JpYmUoKHRpdGxlKSA9PiB7XG4gICAgICAgICAgICBpZiAodGl0bGUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRpdGxlU2VydmljZS5zZXRUaXRsZSh0aXRsZSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGNhcHR1cmVFeGNlcHRpb24obmV3IEVycm9yKGBUcmFuc2xhdGlvbiBrZXkgJyR7dGl0bGVLZXl9JyBmb3IgcGFnZSB0aXRsZSBub3QgZm91bmRgKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHByaXZhdGUgaW5pdCgpIHtcbiAgICAgICAgdGhpcy50cmFuc2xhdGVTZXJ2aWNlLm9uTGFuZ0NoYW5nZS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgbGFuZ3VhZ2VLZXkgPSB0aGlzLnRyYW5zbGF0ZVNlcnZpY2UuY3VycmVudExhbmc7XG4gICAgICAgICAgICB0aGlzLl9sYW5ndWFnZS5uZXh0KGxhbmd1YWdlS2V5KTtcbiAgICAgICAgICAgIHRoaXMubG9jYWxlQ29udmVyc2lvblNlcnZpY2UubG9jYWxlID0gbGFuZ3VhZ2VLZXk7XG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TdG9yYWdlLnN0b3JlKCdsb2NhbGUnLCBsYW5ndWFnZUtleSk7XG4gICAgICAgICAgICB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdodG1sJyksICdsYW5nJywgdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmN1cnJlbnRMYW5nKTtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlVGl0bGUoKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IHRoZSBjdXJyZW50IHBhZ2UncyB0aXRsZSBrZXkgYmFzZWQgb24gdGhlIHJvdXRlciBzdGF0ZS5cbiAgICAgKiBGYWxsYmFjayB0byAnZ2xvYmFsLnRpdGxlJyB3aGVuIG5vIGtleSBpcyBmb3VuZC5cbiAgICAgKiBAcGFyYW0gcm91dGVTbmFwc2hvdCBUaGUgc25hcHNob3Qgb2YgdGhlIGN1cnJlbnQgcm91dGVcbiAgICAgKi9cbiAgICBnZXRQYWdlVGl0bGUocm91dGVTbmFwc2hvdDogQWN0aXZhdGVkUm91dGVTbmFwc2hvdCkge1xuICAgICAgICBsZXQgdGl0bGU6IHN0cmluZyA9IHJvdXRlU25hcHNob3QuZGF0YT8uWydwYWdlVGl0bGUnXSB8fCAnZ2xvYmFsLnRpdGxlJztcbiAgICAgICAgaWYgKHJvdXRlU25hcHNob3QuZmlyc3RDaGlsZCkge1xuICAgICAgICAgICAgdGl0bGUgPSB0aGlzLmdldFBhZ2VUaXRsZShyb3V0ZVNuYXBzaG90LmZpcnN0Q2hpbGQpIHx8IHRpdGxlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aXRsZTtcbiAgICB9XG5cbiAgICBwdWJsaWMgZGV0ZXJtaW5lUHJlZmVycmVkTGFuZ3VhZ2UoKTogc3RyaW5nIHtcbiAgICAgICAgY29uc3QgbmF2aWdhdG9yID0gdGhpcy5nZXROYXZpZ2F0b3JSZWZlcmVuY2UoKTtcbiAgICAgICAgLy8gSW4gdGhlIGxhbmd1YWdlcyBhcnJheSB0aGUgbGFuZ3VhZ2VzIGFyZSBvcmRlcmVkIGJ5IHByZWZlcmVuY2Ugd2l0aCB0aGUgbW9zdCBwcmVmZXJyZWQgbGFuZ3VhZ2UgZmlyc3QuXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbmF2aWdhdG9yLmxhbmd1YWdlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgLy8gcmV0dXJuIHRoZSBsYW5ndWFnZSB3aXRoIHRoZSBoaWdoZXN0IHByZWZlcmVuY2VcbiAgICAgICAgICAgIGlmIChuYXZpZ2F0b3IubGFuZ3VhZ2VzW2ldLnN0YXJ0c1dpdGgoJ2VuJykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2VuJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChuYXZpZ2F0b3IubGFuZ3VhZ2VzW2ldLnN0YXJ0c1dpdGgoJ2RlJykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2RlJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBlbmdsaXNoIGFzIGZhbGxiYWNrXG4gICAgICAgIHJldHVybiAnZW4nO1xuICAgIH1cblxuICAgIHB1YmxpYyBnZXROYXZpZ2F0b3JSZWZlcmVuY2UoKTogYW55IHtcbiAgICAgICAgcmV0dXJuIG5hdmlnYXRvcjtcbiAgICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUEsU0FBUyxZQUF1Qix3QkFBd0I7QUFDeEQsU0FBUyxhQUFhO0FBQ3RCLFNBQWlDLGNBQWM7QUFDL0MsU0FBUyx3QkFBd0I7QUFHakMsU0FBUyx1QkFBbUM7QUFDNUMsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyw2QkFBNkI7Ozs7OztBQVJ0QyxJQVlhO0FBWmI7O0FBS0E7QUFJQTs7QUFHTSxJQUFPLG9CQUFQLE1BQU8sbUJBQWlCO01BS2Q7TUFDQTtNQUNBO01BQ0E7TUFFQTtNQVRKO01BQ0E7TUFFUixZQUNZLGtCQUNBLHlCQUNBLGNBQ0EsUUFDUixjQUNRLGdCQUFxQztBQUxyQyxhQUFBLG1CQUFBO0FBQ0EsYUFBQSwwQkFBQTtBQUNBLGFBQUEsZUFBQTtBQUNBLGFBQUEsU0FBQTtBQUVBLGFBQUEsaUJBQUE7QUFFUixhQUFLLFlBQVksSUFBSSxnQkFBd0IsS0FBSyxpQkFBaUIsV0FBVztBQUM5RSxhQUFLLFdBQVcsYUFBYSxlQUFlLFNBQVMsY0FBYyxNQUFNLEdBQUcsSUFBSTtBQUNoRixhQUFLLEtBQUk7TUFDYjtNQUtBLFNBQU07QUFDRixlQUFPO01BQ1g7TUFFQSxJQUFJLFdBQVE7QUFDUixlQUFPLEtBQUssVUFBVSxhQUFZO01BQ3RDO01BUUEsWUFBWSxVQUFpQjtBQUN6QixZQUFJLENBQUMsVUFBVTtBQUNYLHFCQUFXLEtBQUssYUFBYSxLQUFLLE9BQU8sWUFBWSxTQUFTLElBQUk7O0FBR3RFLGFBQUssaUJBQWlCLElBQUksUUFBUSxFQUFFLFVBQVUsQ0FBQyxVQUFTO0FBQ3BELGNBQUksT0FBTztBQUNQLGlCQUFLLGFBQWEsU0FBUyxLQUFLO2lCQUM3QjtBQUNILDZCQUFpQixJQUFJLE1BQU0sb0JBQW9CLFFBQVEsNEJBQTRCLENBQUM7O1FBRTVGLENBQUM7TUFDTDtNQUVRLE9BQUk7QUFDUixhQUFLLGlCQUFpQixhQUFhLFVBQVUsTUFBSztBQUM5QyxnQkFBTSxjQUFjLEtBQUssaUJBQWlCO0FBQzFDLGVBQUssVUFBVSxLQUFLLFdBQVc7QUFDL0IsZUFBSyx3QkFBd0IsU0FBUztBQUN0QyxlQUFLLGVBQWUsTUFBTSxVQUFVLFdBQVc7QUFDL0MsZUFBSyxTQUFTLGFBQWEsU0FBUyxjQUFjLE1BQU0sR0FBRyxRQUFRLEtBQUssaUJBQWlCLFdBQVc7QUFDcEcsZUFBSyxZQUFXO1FBQ3BCLENBQUM7TUFDTDtNQU9BLGFBQWEsZUFBcUM7QUFDOUMsWUFBSSxRQUFnQixjQUFjLE9BQU8sV0FBVyxLQUFLO0FBQ3pELFlBQUksY0FBYyxZQUFZO0FBQzFCLGtCQUFRLEtBQUssYUFBYSxjQUFjLFVBQVUsS0FBSzs7QUFFM0QsZUFBTztNQUNYO01BRU8sNkJBQTBCO0FBQzdCLGNBQU1BLGFBQVksS0FBSyxzQkFBcUI7QUFFNUMsaUJBQVMsSUFBSSxHQUFHLElBQUlBLFdBQVUsVUFBVSxRQUFRLEtBQUs7QUFFakQsY0FBSUEsV0FBVSxVQUFVLENBQUMsRUFBRSxXQUFXLElBQUksR0FBRztBQUN6QyxtQkFBTzs7QUFFWCxjQUFJQSxXQUFVLFVBQVUsQ0FBQyxFQUFFLFdBQVcsSUFBSSxHQUFHO0FBQ3pDLG1CQUFPOzs7QUFJZixlQUFPO01BQ1g7TUFFTyx3QkFBcUI7QUFDeEIsZUFBTztNQUNYOzt5QkExRlMsb0JBQWlCLHNCQUFBLG1CQUFBLEdBQUEsc0JBQUEsdUJBQUEsR0FBQSxzQkFBQSxRQUFBLEdBQUEsc0JBQUEsU0FBQSxHQUFBLHNCQUFBLG1CQUFBLEdBQUEsc0JBQUEsd0JBQUEsQ0FBQTtNQUFBO21FQUFqQixvQkFBaUIsU0FBakIsbUJBQWlCLFdBQUEsWUFESixPQUFNLENBQUE7Ozs7IiwibmFtZXMiOlsibmF2aWdhdG9yIl19