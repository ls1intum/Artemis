import {
  ArtemisTranslatePipe,
  TranslateDirective,
  __esm,
  init_artemis_translate_pipe,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/iris/iris-logo/iris-logo.component.ts
import { Component, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var IrisLogoSize, IrisLogoLookDirection, IrisLogoComponent;
var init_iris_logo_component = __esm({
  "src/main/webapp/app/iris/iris-logo/iris-logo.component.ts"() {
    (function(IrisLogoSize2) {
      IrisLogoSize2["SMALL"] = "small";
      IrisLogoSize2["MEDIUM"] = "medium";
      IrisLogoSize2["BIG"] = "big";
    })(IrisLogoSize || (IrisLogoSize = {}));
    (function(IrisLogoLookDirection2) {
      IrisLogoLookDirection2["LEFT"] = "left";
      IrisLogoLookDirection2["RIGHT"] = "right";
    })(IrisLogoLookDirection || (IrisLogoLookDirection = {}));
    IrisLogoComponent = class _IrisLogoComponent {
      size = IrisLogoSize.BIG;
      look = IrisLogoLookDirection.RIGHT;
      logoUrl;
      classList;
      ngOnInit() {
        if (this.size === IrisLogoSize.SMALL) {
          this.logoUrl = "public/images/iris/iris-logo-small.png";
          this.classList = "small";
        } else if (this.size === IrisLogoSize.MEDIUM) {
          this.logoUrl = `public/images/iris/iris-logo-big-${this.look}.png`;
          this.classList = "medium";
        } else {
          this.logoUrl = `public/images/iris/iris-logo-big-${this.look}.png`;
          this.classList = "big img-fluid";
        }
      }
      static \u0275fac = function IrisLogoComponent_Factory(t) {
        return new (t || _IrisLogoComponent)();
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _IrisLogoComponent, selectors: [["jhi-iris-logo"]], inputs: { size: "size", look: "look" }, decls: 2, vars: 2, consts: [["alt", "Iris Logo", 3, "src", "classList"]], template: function IrisLogoComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275element(0, "img", 0);
          i0.\u0275\u0275text(1, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275property("src", ctx.logoUrl, i0.\u0275\u0275sanitizeUrl)("classList", "iris-logo " + ctx.classList);
        }
      }, styles: ["\n\n.small[_ngcontent-%COMP%] {\n  height: 35px;\n}\n.medium[_ngcontent-%COMP%] {\n  height: 70px;\n}\n.big[_ngcontent-%COMP%] {\n  max-height: 100px;\n}\n.iris-logo[_ngcontent-%COMP%] {\n  filter: drop-shadow(0 3px 8px rgba(0, 0, 0, 0.24));\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL2lyaXMtbG9nby9pcmlzLWxvZ28uY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi5zbWFsbCB7XG4gICAgaGVpZ2h0OiAzNXB4O1xufVxuXG4ubWVkaXVtIHtcbiAgICBoZWlnaHQ6IDcwcHg7XG59XG5cbi5iaWcge1xuICAgIG1heC1oZWlnaHQ6IDEwMHB4O1xufVxuXG4uaXJpcy1sb2dvIHtcbiAgICBmaWx0ZXI6IGRyb3Atc2hhZG93KDAgM3B4IDhweCByZ2JhKDAsIDAsIDAsIDAuMjQpKTtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksVUFBQTs7QUFHSixDQUFBO0FBQ0ksVUFBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQTs7QUFHSixDQUFBO0FBQ0ksVUFBQSxZQUFBLEVBQUEsSUFBQSxJQUFBLEtBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLEVBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(IrisLogoComponent, { className: "IrisLogoComponent" });
    })();
  }
});

// src/main/webapp/app/iris/about-iris/about-iris.component.ts
import { Component as Component2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faRobot } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function AboutIrisComponent_For_40_For_10_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "li");
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275element(3, "span", 11);
    i02.\u0275\u0275text(4, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                    ");
  }
  if (rf & 2) {
    const i_r8 = ctx.$index;
    const key_r1 = i02.\u0275\u0275nextContext().$implicit;
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("jhiTranslate", "artemisApp.exerciseChatbot.text" + key_r1 + "_" + (i_r8 + 1));
  }
}
function AboutIrisComponent_For_40_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                ");
    i02.\u0275\u0275elementStart(3, "h4", 10);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                ");
    i02.\u0275\u0275elementStart(7, "ul");
    i02.\u0275\u0275text(8, "\n                    ");
    i02.\u0275\u0275repeaterCreate(9, AboutIrisComponent_For_40_For_10_Template, 6, 1, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(12, "\n        ");
  }
  if (rf & 2) {
    const key_r1 = ctx.$implicit;
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(5, 1, "artemisApp.exerciseChatbot.subheading" + key_r1));
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275repeater(ctx_r0.array(ctx_r0.bulletPoints[key_r1]));
  }
}
var AboutIrisComponent;
var init_about_iris_component = __esm({
  "src/main/webapp/app/iris/about-iris/about-iris.component.ts"() {
    init_iris_logo_component();
    init_translate_directive();
    init_iris_logo_component();
    init_artemis_translate_pipe();
    AboutIrisComponent = class _AboutIrisComponent {
      faRobot = faRobot;
      bulletPoints = { "1": 2, "2": 5, "3": 3, "4": 5 };
      objectKeys = Object.keys;
      array = Array;
      IrisLogoSize = IrisLogoSize;
      static \u0275fac = function AboutIrisComponent_Factory(t) {
        return new (t || _AboutIrisComponent)();
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _AboutIrisComponent, selectors: [["jhi-about-iris"]], decls: 43, vars: 10, consts: [[1, "card-title", "about-iris-header", "mb-2"], [1, "row"], [1, "col-auto"], [3, "size"], [1, "col-8"], [1, "mt-2", "font-weight-bold"], [1, "ms-2", "d-none", "d-md-block"], [1, "mt-1", "font-weight-normal"], [1, "row", "d-md-none"], [1, "mb-5", "ms-2", 2, "margin-right", "70px"], [1, "mb-3", "font-weight-bold"], [3, "jhiTranslate"]], template: function AboutIrisComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div");
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275elementStart(2, "div");
          i02.\u0275\u0275text(3, "\n        ");
          i02.\u0275\u0275elementStart(4, "div", 0);
          i02.\u0275\u0275text(5, "\n            ");
          i02.\u0275\u0275elementStart(6, "div", 1);
          i02.\u0275\u0275text(7, "\n                ");
          i02.\u0275\u0275elementStart(8, "div", 2);
          i02.\u0275\u0275text(9, "\n                    ");
          i02.\u0275\u0275element(10, "jhi-iris-logo", 3);
          i02.\u0275\u0275text(11, "\n                ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(12, "\n                ");
          i02.\u0275\u0275elementStart(13, "div", 4);
          i02.\u0275\u0275text(14, "\n                    ");
          i02.\u0275\u0275elementStart(15, "h2", 5);
          i02.\u0275\u0275text(16);
          i02.\u0275\u0275pipe(17, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(18, "\n                    ");
          i02.\u0275\u0275elementStart(19, "div", 6);
          i02.\u0275\u0275text(20, "\n                        ");
          i02.\u0275\u0275elementStart(21, "p", 7);
          i02.\u0275\u0275text(22);
          i02.\u0275\u0275pipe(23, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(24, "\n                    ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(25, "\n                ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(26, "\n            ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(27, "\n            ");
          i02.\u0275\u0275elementStart(28, "div", 8);
          i02.\u0275\u0275text(29, "\n                ");
          i02.\u0275\u0275elementStart(30, "p", 7);
          i02.\u0275\u0275text(31);
          i02.\u0275\u0275pipe(32, "artemisTranslate");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(33, "\n            ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(34, "\n        ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(35, "\n    ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(36, "\n    ");
          i02.\u0275\u0275elementStart(37, "div", 9);
          i02.\u0275\u0275text(38, "\n        ");
          i02.\u0275\u0275repeaterCreate(39, AboutIrisComponent_For_40_Template, 13, 3, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(41, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(42, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(10);
          i02.\u0275\u0275property("size", ctx.IrisLogoSize.BIG);
          i02.\u0275\u0275advance(6);
          i02.\u0275\u0275textInterpolate1("\n                        ", i02.\u0275\u0275pipeBind1(17, 4, "artemisApp.exerciseChatbot.title"), "\n                    ");
          i02.\u0275\u0275advance(6);
          i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(23, 6, "artemisApp.exerciseChatbot.subtext"));
          i02.\u0275\u0275advance(9);
          i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(32, 8, "artemisApp.exerciseChatbot.subtext"));
          i02.\u0275\u0275advance(8);
          i02.\u0275\u0275repeater(ctx.objectKeys(ctx.bulletPoints));
        }
      }, dependencies: [TranslateDirective, IrisLogoComponent, ArtemisTranslatePipe], styles: ["\n\n.about-iris-header[_ngcontent-%COMP%] {\n  background-color: var(--artemis-dark);\n  color: white;\n  margin: -1rem;\n  padding: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL2Fib3V0LWlyaXMvYWJvdXQtaXJpcy5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLmFib3V0LWlyaXMtaGVhZGVyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hcnRlbWlzLWRhcmspO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBtYXJnaW46IC0xcmVtO1xuICAgIHBhZGRpbmc6IDFyZW07XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxTQUFBO0FBQ0EsVUFBQTtBQUNBLFdBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(AboutIrisComponent, { className: "AboutIrisComponent" });
    })();
  }
});

export {
  IrisLogoSize,
  IrisLogoLookDirection,
  IrisLogoComponent,
  init_iris_logo_component,
  AboutIrisComponent,
  init_about_iris_component
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9pcmlzLWxvZ28vaXJpcy1sb2dvLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvaXJpcy9pcmlzLWxvZ28vaXJpcy1sb2dvLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9pcmlzL2Fib3V0LWlyaXMvYWJvdXQtaXJpcy5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2lyaXMvYWJvdXQtaXJpcy9hYm91dC1pcmlzLmNvbXBvbmVudC5odG1sIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5leHBvcnQgZW51bSBJcmlzTG9nb1NpemUge1xuICAgIFNNQUxMID0gJ3NtYWxsJyxcbiAgICBNRURJVU0gPSAnbWVkaXVtJyxcbiAgICBCSUcgPSAnYmlnJyxcbn1cblxuZXhwb3J0IGVudW0gSXJpc0xvZ29Mb29rRGlyZWN0aW9uIHtcbiAgICBMRUZUID0gJ2xlZnQnLFxuICAgIFJJR0hUID0gJ3JpZ2h0Jyxcbn1cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktaXJpcy1sb2dvJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vaXJpcy1sb2dvLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9pcmlzLWxvZ28uY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgSXJpc0xvZ29Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEBJbnB1dCgpXG4gICAgc2l6ZTogSXJpc0xvZ29TaXplID0gSXJpc0xvZ29TaXplLkJJRztcblxuICAgIEBJbnB1dCgpXG4gICAgbG9vazogSXJpc0xvZ29Mb29rRGlyZWN0aW9uID0gSXJpc0xvZ29Mb29rRGlyZWN0aW9uLlJJR0hUO1xuXG4gICAgbG9nb1VybDogc3RyaW5nO1xuICAgIGNsYXNzTGlzdDogc3RyaW5nO1xuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIGlmICh0aGlzLnNpemUgPT09IElyaXNMb2dvU2l6ZS5TTUFMTCkge1xuICAgICAgICAgICAgdGhpcy5sb2dvVXJsID0gJ3B1YmxpYy9pbWFnZXMvaXJpcy9pcmlzLWxvZ28tc21hbGwucG5nJztcbiAgICAgICAgICAgIHRoaXMuY2xhc3NMaXN0ID0gJ3NtYWxsJztcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLnNpemUgPT09IElyaXNMb2dvU2l6ZS5NRURJVU0pIHtcbiAgICAgICAgICAgIHRoaXMubG9nb1VybCA9IGBwdWJsaWMvaW1hZ2VzL2lyaXMvaXJpcy1sb2dvLWJpZy0ke3RoaXMubG9va30ucG5nYDtcbiAgICAgICAgICAgIHRoaXMuY2xhc3NMaXN0ID0gJ21lZGl1bSc7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmxvZ29VcmwgPSBgcHVibGljL2ltYWdlcy9pcmlzL2lyaXMtbG9nby1iaWctJHt0aGlzLmxvb2t9LnBuZ2A7XG4gICAgICAgICAgICB0aGlzLmNsYXNzTGlzdCA9ICdiaWcgaW1nLWZsdWlkJztcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsIjxpbWcgW3NyY109XCJ0aGlzLmxvZ29VcmxcIiBhbHQ9XCJJcmlzIExvZ29cIiBbY2xhc3NMaXN0XT1cIidpcmlzLWxvZ28gJyArIHRoaXMuY2xhc3NMaXN0XCIgLz5cbiIsImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZmFSb2JvdCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBJcmlzTG9nb1NpemUgfSBmcm9tICcuLi9pcmlzLWxvZ28vaXJpcy1sb2dvLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWFib3V0LWlyaXMnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9hYm91dC1pcmlzLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnYWJvdXQtaXJpcy5jb21wb25lbnQuc2NzcyddLFxufSlcbmV4cG9ydCBjbGFzcyBBYm91dElyaXNDb21wb25lbnQge1xuICAgIGZhUm9ib3QgPSBmYVJvYm90O1xuICAgIC8vIEhvdyBtYW55IGJ1bGxldCBwb2ludHMgZWFjaCBoZWFkaW5nIGhhc1xuICAgIGJ1bGxldFBvaW50cyA9IHsgJzEnOiAyLCAnMic6IDUsICczJzogMywgJzQnOiA1IH07XG5cbiAgICBvYmplY3RLZXlzID0gT2JqZWN0LmtleXM7XG4gICAgYXJyYXkgPSBBcnJheTtcbiAgICBwcm90ZWN0ZWQgcmVhZG9ubHkgSXJpc0xvZ29TaXplID0gSXJpc0xvZ29TaXplO1xufVxuIiwiPGRpdj5cbiAgICA8ZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC10aXRsZSBhYm91dC1pcmlzLWhlYWRlciBtYi0yXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgIDxqaGktaXJpcy1sb2dvIFtzaXplXT1cIklyaXNMb2dvU2l6ZS5CSUdcIj48L2poaS1pcmlzLWxvZ28+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC04XCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzcz1cIm10LTIgZm9udC13ZWlnaHQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LnRpdGxlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1zLTIgZC1ub25lIGQtbWQtYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwibXQtMSBmb250LXdlaWdodC1ub3JtYWxcIj57eyAnYXJ0ZW1pc0FwcC5leGVyY2lzZUNoYXRib3Quc3VidGV4dCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvdyBkLW1kLW5vbmVcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzcz1cIm10LTEgZm9udC13ZWlnaHQtbm9ybWFsXCI+e3sgJ2FydGVtaXNBcHAuZXhlcmNpc2VDaGF0Ym90LnN1YnRleHQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwibWItNSBtcy0yXCIgc3R5bGU9XCJtYXJnaW4tcmlnaHQ6IDcwcHhcIj5cbiAgICAgICAgQGZvciAoa2V5IG9mIG9iamVjdEtleXMoYnVsbGV0UG9pbnRzKTsgdHJhY2sga2V5KSB7XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoNCBjbGFzcz1cIm1iLTMgZm9udC13ZWlnaHQtYm9sZFwiPnt7ICdhcnRlbWlzQXBwLmV4ZXJjaXNlQ2hhdGJvdC5zdWJoZWFkaW5nJyArIGtleSB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2g0PlxuICAgICAgICAgICAgICAgIDx1bD5cbiAgICAgICAgICAgICAgICAgICAgQGZvciAoaXRlbSBvZiBhcnJheShidWxsZXRQb2ludHNba2V5XSk7IHRyYWNrIGl0ZW07IGxldCBpID0gJGluZGV4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gW2poaVRyYW5zbGF0ZV09XCInYXJ0ZW1pc0FwcC5leGVyY2lzZUNoYXRib3QudGV4dCcgKyBrZXkgKyAnXycgKyAoaSArIDEpXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgIDwvZGl2PlxuPC9kaXY+XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLFNBQVMsV0FBVyxhQUFxQjs7QUFBekMsSUFFWSxjQU1BLHVCQVVDO0FBbEJiOztBQUVBLEtBQUEsU0FBWUEsZUFBWTtBQUNwQixNQUFBQSxjQUFBLE9BQUEsSUFBQTtBQUNBLE1BQUFBLGNBQUEsUUFBQSxJQUFBO0FBQ0EsTUFBQUEsY0FBQSxLQUFBLElBQUE7SUFDSixHQUpZLGlCQUFBLGVBQVksQ0FBQSxFQUFBO0FBTXhCLEtBQUEsU0FBWUMsd0JBQXFCO0FBQzdCLE1BQUFBLHVCQUFBLE1BQUEsSUFBQTtBQUNBLE1BQUFBLHVCQUFBLE9BQUEsSUFBQTtJQUNKLEdBSFksMEJBQUEsd0JBQXFCLENBQUEsRUFBQTtBQVUzQixJQUFPLG9CQUFQLE1BQU8sbUJBQWlCO01BRTFCLE9BQXFCLGFBQWE7TUFHbEMsT0FBOEIsc0JBQXNCO01BRXBEO01BQ0E7TUFFQSxXQUFRO0FBQ0osWUFBSSxLQUFLLFNBQVMsYUFBYSxPQUFPO0FBQ2xDLGVBQUssVUFBVTtBQUNmLGVBQUssWUFBWTttQkFDVixLQUFLLFNBQVMsYUFBYSxRQUFRO0FBQzFDLGVBQUssVUFBVSxvQ0FBb0MsS0FBSyxJQUFJO0FBQzVELGVBQUssWUFBWTtlQUNkO0FBQ0gsZUFBSyxVQUFVLG9DQUFvQyxLQUFLLElBQUk7QUFDNUQsZUFBSyxZQUFZOztNQUV6Qjs7eUJBckJTLG9CQUFpQjtNQUFBO2dFQUFqQixvQkFBaUIsV0FBQSxDQUFBLENBQUEsZUFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLE1BQUEsUUFBQSxNQUFBLE9BQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLE9BQUEsYUFBQSxHQUFBLE9BQUEsV0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDJCQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDbEI5QixVQUFBLHVCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0EsVUFBQSxvQkFBQSxHQUFBLElBQUE7OztBQURLLFVBQUEsd0JBQUEsT0FBQSxJQUFBLFNBQUEsMEJBQUEsRUFBb0IsYUFBQSxlQUFBLElBQUEsU0FBQTs7Ozs7b0ZEa0JaLG1CQUFpQixFQUFBLFdBQUEsb0JBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFbEI5QixTQUFTLGFBQUFDLGtCQUFpQjtBQUMxQixTQUFTLGVBQWU7Ozs7QUMwQkEsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7Ozs7QUFGYyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGdCQUFBLG9DQUFBLFNBQUEsT0FBQSxPQUFBLEVBQUE7Ozs7O0FBTHRCLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUFrQyxJQUFBLHFCQUFBLENBQUE7O0FBQXNFLElBQUEsMkJBQUE7QUFDeEcsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEsMkNBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQUtKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7Ozs7O0FBVDBDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLDBDQUFBLE1BQUEsQ0FBQTtBQUU5QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsTUFBQSxPQUFBLGFBQUEsTUFBQSxDQUFBLENBQUE7OztBRDFCcEIsSUFTYTtBQVRiOztBQUVBOzs7O0FBT00sSUFBTyxxQkFBUCxNQUFPLG9CQUFrQjtNQUMzQixVQUFVO01BRVYsZUFBZSxFQUFFLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssRUFBQztNQUUvQyxhQUFhLE9BQU87TUFDcEIsUUFBUTtNQUNXLGVBQWU7O3lCQVB6QixxQkFBa0I7TUFBQTtpRUFBbEIscUJBQWtCLFdBQUEsQ0FBQSxDQUFBLGdCQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsY0FBQSxxQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFVBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFFBQUEsR0FBQSxnQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDRCQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDVC9CLFVBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLGlCQUFBLENBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxNQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEVBQUE7O0FBQ0osVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsS0FBQSxDQUFBO0FBQW1DLFVBQUEscUJBQUEsRUFBQTs7QUFBNkQsVUFBQSwyQkFBQTtBQUNwRyxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLEtBQUEsQ0FBQTtBQUFtQyxVQUFBLHFCQUFBLEVBQUE7O0FBQTZELFVBQUEsMkJBQUE7QUFDcEcsVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwrQkFBQSxJQUFBLG9DQUFBLElBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7QUFZSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQS9CbUMsVUFBQSx3QkFBQSxFQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsYUFBQSxHQUFBO0FBSVgsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSw4QkFBQSwwQkFBQSxJQUFBLEdBQUEsa0NBQUEsR0FBQSx3QkFBQTtBQUdtQyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGdDQUFBLDBCQUFBLElBQUEsR0FBQSxvQ0FBQSxDQUFBO0FBS1IsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSwwQkFBQSxJQUFBLEdBQUEsb0NBQUEsQ0FBQTtBQUszQyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsV0FBQSxJQUFBLFlBQUEsQ0FBQTs7Ozs7cUZEYkssb0JBQWtCLEVBQUEsV0FBQSxxQkFBQSxDQUFBO0lBQUEsR0FBQTs7OyIsIm5hbWVzIjpbIklyaXNMb2dvU2l6ZSIsIklyaXNMb2dvTG9va0RpcmVjdGlvbiIsIkNvbXBvbmVudCJdfQ==