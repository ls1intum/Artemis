import {
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exam/manage/exam-exercise-update.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { BehaviorSubject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ExamExerciseUpdateService;
var init_exam_exercise_update_service = __esm({
  "src/main/webapp/app/exam/manage/exam-exercise-update.service.ts"() {
    ExamExerciseUpdateService = class _ExamExerciseUpdateService {
      examExerciseIdAndProblemStatementSource = new BehaviorSubject({ exerciseId: -1, problemStatement: "initialProblemStatementValue" });
      currentExerciseIdAndProblemStatement = this.examExerciseIdAndProblemStatementSource.asObservable();
      examExerciseIdForNavigationSource = new BehaviorSubject(-1);
      currentExerciseIdForNavigation = this.examExerciseIdForNavigationSource.asObservable();
      constructor() {
      }
      navigateToExamExercise(exerciseId) {
        this.examExerciseIdForNavigationSource.next(exerciseId);
      }
      updateLiveExamExercise(exerciseId, problemStatement) {
        this.examExerciseIdAndProblemStatementSource.next({ exerciseId, problemStatement });
      }
      static \u0275fac = function ExamExerciseUpdateService_Factory(t) {
        return new (t || _ExamExerciseUpdateService)();
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _ExamExerciseUpdateService, factory: _ExamExerciseUpdateService.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  ExamExerciseUpdateService,
  init_exam_exercise_update_service
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhhbS9tYW5hZ2UvZXhhbS1leGVyY2lzZS11cGRhdGUuc2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBCZWhhdmlvclN1YmplY3QgfSBmcm9tICdyeGpzJztcblxuZXhwb3J0IGludGVyZmFjZSBFeGFtRXhlcmNpc2VVcGRhdGUge1xuICAgIGV4ZXJjaXNlSWQ6IG51bWJlcjtcbiAgICBwcm9ibGVtU3RhdGVtZW50OiBzdHJpbmc7XG59XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgRXhhbUV4ZXJjaXNlVXBkYXRlU2VydmljZSB7XG4gICAgcHJpdmF0ZSBleGFtRXhlcmNpc2VJZEFuZFByb2JsZW1TdGF0ZW1lbnRTb3VyY2UgPSBuZXcgQmVoYXZpb3JTdWJqZWN0PEV4YW1FeGVyY2lzZVVwZGF0ZT4oeyBleGVyY2lzZUlkOiAtMSwgcHJvYmxlbVN0YXRlbWVudDogJ2luaXRpYWxQcm9ibGVtU3RhdGVtZW50VmFsdWUnIH0pO1xuICAgIGN1cnJlbnRFeGVyY2lzZUlkQW5kUHJvYmxlbVN0YXRlbWVudCA9IHRoaXMuZXhhbUV4ZXJjaXNlSWRBbmRQcm9ibGVtU3RhdGVtZW50U291cmNlLmFzT2JzZXJ2YWJsZSgpO1xuXG4gICAgcHJpdmF0ZSBleGFtRXhlcmNpc2VJZEZvck5hdmlnYXRpb25Tb3VyY2UgPSBuZXcgQmVoYXZpb3JTdWJqZWN0PG51bWJlcj4oLTEpO1xuICAgIGN1cnJlbnRFeGVyY2lzZUlkRm9yTmF2aWdhdGlvbiA9IHRoaXMuZXhhbUV4ZXJjaXNlSWRGb3JOYXZpZ2F0aW9uU291cmNlLmFzT2JzZXJ2YWJsZSgpO1xuXG4gICAgY29uc3RydWN0b3IoKSB7fVxuXG4gICAgbmF2aWdhdGVUb0V4YW1FeGVyY2lzZShleGVyY2lzZUlkOiBudW1iZXIpIHtcbiAgICAgICAgdGhpcy5leGFtRXhlcmNpc2VJZEZvck5hdmlnYXRpb25Tb3VyY2UubmV4dChleGVyY2lzZUlkKTtcbiAgICB9XG5cbiAgICB1cGRhdGVMaXZlRXhhbUV4ZXJjaXNlKGV4ZXJjaXNlSWQ6IG51bWJlciwgcHJvYmxlbVN0YXRlbWVudDogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuZXhhbUV4ZXJjaXNlSWRBbmRQcm9ibGVtU3RhdGVtZW50U291cmNlLm5leHQoeyBleGVyY2lzZUlkLCBwcm9ibGVtU3RhdGVtZW50IH0pO1xuICAgIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLHVCQUF1Qjs7QUFEaEMsSUFTYTtBQVRiOztBQVNNLElBQU8sNEJBQVAsTUFBTywyQkFBeUI7TUFDMUIsMENBQTBDLElBQUksZ0JBQW9DLEVBQUUsWUFBWSxJQUFJLGtCQUFrQiwrQkFBOEIsQ0FBRTtNQUM5Six1Q0FBdUMsS0FBSyx3Q0FBd0MsYUFBWTtNQUV4RixvQ0FBb0MsSUFBSSxnQkFBd0IsRUFBRTtNQUMxRSxpQ0FBaUMsS0FBSyxrQ0FBa0MsYUFBWTtNQUVwRixjQUFBO01BQWU7TUFFZix1QkFBdUIsWUFBa0I7QUFDckMsYUFBSyxrQ0FBa0MsS0FBSyxVQUFVO01BQzFEO01BRUEsdUJBQXVCLFlBQW9CLGtCQUF3QjtBQUMvRCxhQUFLLHdDQUF3QyxLQUFLLEVBQUUsWUFBWSxpQkFBZ0IsQ0FBRTtNQUN0Rjs7eUJBZlMsNEJBQXlCO01BQUE7bUVBQXpCLDRCQUF5QixTQUF6QiwyQkFBeUIsV0FBQSxZQURaLE9BQU0sQ0FBQTs7OzsiLCJuYW1lcyI6W119