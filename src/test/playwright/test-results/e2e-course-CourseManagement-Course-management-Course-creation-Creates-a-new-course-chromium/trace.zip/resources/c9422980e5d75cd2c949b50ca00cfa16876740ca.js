import {
  ArtemisCompetenciesModule,
  CompetencyRingsComponent,
  init_competency_module,
  init_competency_rings_component
} from "/chunk-AZR7X62R.js";
import {
  init_global_utils,
  onError
} from "/chunk-LW4WH7EZ.js";
import {
  AlertService,
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  CompetencyService,
  ExerciseService,
  LectureUnitService,
  StickyPopoverDirective,
  TranslateDirective,
  __esm,
  getConfidence,
  getIcon,
  getIcon2,
  getIcon3,
  getIconTooltip,
  getIconTooltip2,
  getIconTooltip3,
  getMastery,
  getProgress,
  init_alert_service,
  init_artemis_translate_pipe,
  init_competency_model,
  init_competency_service,
  init_exercise_model,
  init_exercise_service,
  init_lectureUnit_model,
  init_lectureUnit_service,
  init_shared_module,
  init_sticky_popover_directive,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/entities/competency/learning-path.model.ts
import { faCheckCircle, faCircle, faFlag, faFlagCheckered, faPlayCircle, faSignsPost } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
function getIcon4(node) {
  if (!node.type) {
    return faCircle;
  }
  if (node.type === NodeType.EXERCISE || node.type === NodeType.LECTURE_UNIT) {
    if (node.completed) {
      return faCheckCircle;
    } else {
      return faPlayCircle;
    }
  }
  const icons = {
    [NodeType.COMPETENCY_START]: faFlag,
    [NodeType.COMPETENCY_END]: faFlagCheckered,
    [NodeType.MATCH_START]: faSignsPost,
    [NodeType.MATCH_END]: faCircle
  };
  return icons[node.type];
}
var NodeType;
var init_learning_path_model = __esm({
  "src/main/webapp/app/entities/competency/learning-path.model.ts"() {
    (function(NodeType2) {
      NodeType2["COMPETENCY_START"] = "COMPETENCY_START";
      NodeType2["COMPETENCY_END"] = "COMPETENCY_END";
      NodeType2["MATCH_START"] = "MATCH_START";
      NodeType2["MATCH_END"] = "MATCH_END";
      NodeType2["EXERCISE"] = "EXERCISE";
      NodeType2["LECTURE_UNIT"] = "LECTURE_UNIT";
    })(NodeType || (NodeType = {}));
  }
});

// src/main/webapp/app/course/learning-paths/participate/learning-path-storage.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var LearningPathStorageService, StorageEntry, LectureUnitEntry, ExerciseEntry;
var init_learning_path_storage_service = __esm({
  "src/main/webapp/app/course/learning-paths/participate/learning-path-storage.service.ts"() {
    init_learning_path_model();
    LearningPathStorageService = class _LearningPathStorageService {
      learningPathRecommendations = /* @__PURE__ */ new Map();
      storeRecommendations(learningPathId, learningPath) {
        this.learningPathRecommendations.set(learningPathId, []);
        let currentId = learningPath.nodes.map((node) => node.id).find((id) => !learningPath.edges.find((edge) => edge.target == id));
        while (currentId) {
          const currentNode = learningPath.nodes.find((node) => node.id == currentId);
          if (currentNode.type === NodeType.LECTURE_UNIT) {
            this.learningPathRecommendations.get(learningPathId).push(new LectureUnitEntry(currentNode.linkedResourceParent, currentNode.linkedResource));
          } else if (currentNode.type === NodeType.EXERCISE) {
            this.learningPathRecommendations.get(learningPathId).push(new ExerciseEntry(currentNode.linkedResource));
          }
          const edge = learningPath.edges.find((edge2) => edge2.source == currentId);
          if (edge) {
            currentId = edge.target;
          } else {
            currentId = void 0;
          }
        }
      }
      getRecommendations(learningPathId) {
        return this.learningPathRecommendations.get(learningPathId);
      }
      hasNextRecommendation(learningPathId, entry) {
        if (!this.learningPathRecommendations.has(learningPathId)) {
          return false;
        }
        if (!entry) {
          return !!this.learningPathRecommendations.get(learningPathId)?.length;
        }
        const index = this.getIndexOf(learningPathId, entry);
        return 0 <= index && index + 1 < this.learningPathRecommendations.get(learningPathId).length;
      }
      getNextRecommendation(learningPathId, entry) {
        if (!this.hasNextRecommendation(learningPathId, entry)) {
          return void 0;
        }
        if (!entry) {
          return this.learningPathRecommendations.get(learningPathId)[0];
        }
        const nextIndex = this.getIndexOf(learningPathId, entry) + 1;
        return this.learningPathRecommendations.get(learningPathId)[nextIndex];
      }
      hasPrevRecommendation(learningPathId, entry) {
        if (!this.learningPathRecommendations.has(learningPathId) || !entry) {
          return false;
        }
        return 0 < this.getIndexOf(learningPathId, entry);
      }
      getPrevRecommendation(learningPathId, entry) {
        if (!this.hasPrevRecommendation(learningPathId, entry)) {
          return void 0;
        }
        const prevIndex = this.getIndexOf(learningPathId, entry) - 1;
        return this.learningPathRecommendations.get(learningPathId)[prevIndex];
      }
      getIndexOf(learningPathId, entry) {
        if (!this.learningPathRecommendations.has(learningPathId)) {
          return -1;
        }
        return this.learningPathRecommendations.get(learningPathId).findIndex((e) => {
          return entry.equals(e);
        });
      }
      static \u0275fac = function LearningPathStorageService_Factory(t) {
        return new (t || _LearningPathStorageService)();
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _LearningPathStorageService, factory: _LearningPathStorageService.\u0275fac, providedIn: "root" });
    };
    StorageEntry = class {
    };
    LectureUnitEntry = class _LectureUnitEntry extends StorageEntry {
      lectureUnitId;
      lectureId;
      constructor(lectureId, lectureUnitId) {
        super();
        this.lectureId = lectureId;
        this.lectureUnitId = lectureUnitId;
      }
      equals(other) {
        if (other instanceof _LectureUnitEntry) {
          return this.lectureId === other.lectureId && this.lectureUnitId === other.lectureUnitId;
        }
        return false;
      }
    };
    ExerciseEntry = class _ExerciseEntry extends StorageEntry {
      exerciseId;
      constructor(exerciseId) {
        super();
        this.exerciseId = exerciseId;
      }
      equals(other) {
        if (other instanceof _ExerciseEntry) {
          return this.exerciseId === other.exerciseId;
        }
        return false;
      }
    };
  }
});

// src/main/webapp/app/course/learning-paths/learning-path.service.ts
import { Injectable as Injectable2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var LearningPathService;
var init_learning_path_service = __esm({
  "src/main/webapp/app/course/learning-paths/learning-path.service.ts"() {
    init_learning_path_storage_service();
    init_learning_path_storage_service();
    LearningPathService = class _LearningPathService {
      httpClient;
      learningPathStorageService;
      resourceURL = "api";
      constructor(httpClient, learningPathStorageService) {
        this.httpClient = httpClient;
        this.learningPathStorageService = learningPathStorageService;
      }
      enableLearningPaths(courseId) {
        return this.httpClient.put(`${this.resourceURL}/courses/${courseId}/learning-paths/enable`, null, { observe: "response" });
      }
      generateMissingLearningPathsForCourse(courseId) {
        return this.httpClient.put(`${this.resourceURL}/courses/${courseId}/learning-paths/generate-missing`, null, { observe: "response" });
      }
      getHealthStatusForCourse(courseId) {
        return this.httpClient.get(`${this.resourceURL}/courses/${courseId}/learning-path-health`, { observe: "response" });
      }
      getLearningPath(learningPathId) {
        return this.httpClient.get(`${this.resourceURL}/learning-path/${learningPathId}`, { observe: "response" });
      }
      getLearningPathNgxGraph(learningPathId) {
        return this.httpClient.get(`${this.resourceURL}/learning-path/${learningPathId}/graph`, { observe: "response" }).pipe(map((ngxLearningPathResponse) => {
          return this.sanitizeNgxLearningPathResponse(ngxLearningPathResponse);
        }));
      }
      getLearningPathNgxPath(learningPathId) {
        return this.httpClient.get(`${this.resourceURL}/learning-path/${learningPathId}/path`, { observe: "response" }).pipe(map((ngxLearningPathResponse) => {
          return this.sanitizeNgxLearningPathResponse(ngxLearningPathResponse);
        }), tap((ngxLearningPathResponse) => {
          this.learningPathStorageService.storeRecommendations(learningPathId, ngxLearningPathResponse.body);
        }));
      }
      sanitizeNgxLearningPathResponse(ngxLearningPathResponse) {
        ngxLearningPathResponse.body.nodes ??= [];
        ngxLearningPathResponse.body.edges ??= [];
        return ngxLearningPathResponse;
      }
      getLearningPathId(courseId) {
        return this.httpClient.get(`${this.resourceURL}/courses/${courseId}/learning-path-id`, { observe: "response" });
      }
      getCompetencyProgressForLearningPath(learningPathId) {
        return this.httpClient.get(`${this.resourceURL}/learning-path/${learningPathId}/competency-progress`, { observe: "response" });
      }
      static \u0275fac = function LearningPathService_Factory(t) {
        return new (t || _LearningPathService)(i02.\u0275\u0275inject(i1.HttpClient), i02.\u0275\u0275inject(LearningPathStorageService));
      };
      static \u0275prov = i02.\u0275\u0275defineInjectable({ token: _LearningPathService, factory: _LearningPathService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/course/learning-paths/learning-path-graph/node-details/competency-node-details.component.ts
import { Component, EventEmitter, Input, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function CompetencyNodeDetailsComponent_Conditional_0_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275element(1, "fa-icon", 5);
    i03.\u0275\u0275pipe(2, "artemisTranslate");
    i03.\u0275\u0275text(3, "\n                ");
  }
  if (rf & 2) {
    const ctx_r1 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("icon", ctx_r1.getIcon(ctx_r1.competency.taxonomy))("fixedWidth", true)("ngbTooltip", i03.\u0275\u0275pipeBind1(2, 3, ctx_r1.getIconTooltip(ctx_r1.competency.taxonomy)));
  }
}
function CompetencyNodeDetailsComponent_Conditional_0_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "span", 6);
    i03.\u0275\u0275text(2, "Mastered");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                ");
  }
}
function CompetencyNodeDetailsComponent_Conditional_0_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "span", 7);
    i03.\u0275\u0275text(2, "Optional");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                ");
  }
}
function CompetencyNodeDetailsComponent_Conditional_0_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275element(1, "div", 8);
    i03.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r4 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("innerHTML", ctx_r4.competency.description, i03.\u0275\u0275sanitizeHtml);
  }
}
function CompetencyNodeDetailsComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n    ");
    i03.\u0275\u0275elementStart(1, "div", 0);
    i03.\u0275\u0275text(2, "\n        ");
    i03.\u0275\u0275elementStart(3, "div", 1);
    i03.\u0275\u0275text(4, "\n            ");
    i03.\u0275\u0275elementStart(5, "h3", 2);
    i03.\u0275\u0275text(6, "\n                ");
    i03.\u0275\u0275template(7, CompetencyNodeDetailsComponent_Conditional_0_Conditional_7_Template, 4, 5);
    i03.\u0275\u0275elementStart(8, "span");
    i03.\u0275\u0275text(9);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(10, "\n                ");
    i03.\u0275\u0275template(11, CompetencyNodeDetailsComponent_Conditional_0_Conditional_11_Template, 4, 0)(12, CompetencyNodeDetailsComponent_Conditional_0_Conditional_12_Template, 4, 0);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(13, "\n            ");
    i03.\u0275\u0275template(14, CompetencyNodeDetailsComponent_Conditional_0_Conditional_14_Template, 3, 1);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(15, "\n        ");
    i03.\u0275\u0275elementStart(16, "div", 3);
    i03.\u0275\u0275element(17, "jhi-competency-rings", 4);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(18, "\n    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(19, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(7);
    i03.\u0275\u0275conditional(7, ctx_r0.competency.taxonomy ? 7 : -1);
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275textInterpolate(ctx_r0.competency.title);
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275conditional(11, ctx_r0.mastery >= 100 ? 11 : -1);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(12, ctx_r0.competency.optional ? 12 : -1);
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275conditional(14, ctx_r0.competency.description ? 14 : -1);
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("progress", ctx_r0.progress)("confidence", ctx_r0.confidence)("mastery", ctx_r0.mastery);
  }
}
var CompetencyNodeDetailsComponent;
var init_competency_node_details_component = __esm({
  "src/main/webapp/app/course/learning-paths/learning-path-graph/node-details/competency-node-details.component.ts"() {
    init_global_utils();
    init_competency_service();
    init_competency_model();
    init_alert_service();
    init_competency_service();
    init_alert_service();
    init_translate_directive();
    init_competency_rings_component();
    init_artemis_translate_pipe();
    CompetencyNodeDetailsComponent = class _CompetencyNodeDetailsComponent {
      competencyService;
      alertService;
      courseId;
      competencyId;
      competency;
      competencyChange = new EventEmitter();
      competencyProgress;
      isLoading = false;
      getIcon = getIcon3;
      getIconTooltip = getIconTooltip3;
      constructor(competencyService, alertService) {
        this.competencyService = competencyService;
        this.alertService = alertService;
      }
      ngOnInit() {
        if (!this.competency) {
          this.loadData();
        }
      }
      loadData() {
        this.isLoading = true;
        this.competencyService.findById(this.competencyId, this.courseId).subscribe({
          next: (resp) => {
            this.competency = resp.body;
            this.isLoading = false;
            this.competencyChange.emit(this.competency);
          },
          error: (errorResponse) => onError(this.alertService, errorResponse)
        });
      }
      get progress() {
        return getProgress(this.competencyProgress);
      }
      get confidence() {
        return getConfidence(this.competencyProgress, this.competency.masteryThreshold);
      }
      get mastery() {
        return getMastery(this.competencyProgress, this.competency.masteryThreshold);
      }
      static \u0275fac = function CompetencyNodeDetailsComponent_Factory(t) {
        return new (t || _CompetencyNodeDetailsComponent)(i03.\u0275\u0275directiveInject(CompetencyService), i03.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _CompetencyNodeDetailsComponent, selectors: [["jhi-competency-node-details"]], inputs: { courseId: "courseId", competencyId: "competencyId", competency: "competency", competencyProgress: "competencyProgress" }, outputs: { competencyChange: "competencyChange" }, decls: 1, vars: 1, consts: [[1, "row"], [1, "col-9"], [1, "mb-0"], [1, "col-3"], [3, "progress", "confidence", "mastery"], ["container", "body", 3, "icon", "fixedWidth", "ngbTooltip"], ["jhiTranslate", "artemisApp.competency.mastered", 1, "badge", "text-white", "text-bg-success"], ["jhiTranslate", "artemisApp.competency.optional", 1, "badge", "text-white", "bg-warning"], [3, "innerHTML"]], template: function CompetencyNodeDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275template(0, CompetencyNodeDetailsComponent_Conditional_0_Template, 20, 8);
        }
        if (rf & 2) {
          i03.\u0275\u0275conditional(0, ctx.competency ? 0 : -1);
        }
      }, dependencies: [i3.NgbTooltip, i4.FaIconComponent, TranslateDirective, CompetencyRingsComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(CompetencyNodeDetailsComponent, { className: "CompetencyNodeDetailsComponent" });
    })();
  }
});

// src/main/webapp/app/course/learning-paths/learning-path-graph/node-details/exercise-node-details.component.ts
import { Component as Component2, EventEmitter as EventEmitter2, Input as Input2, Output as Output2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i42 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ExerciseNodeDetailsComponent_Conditional_0_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275element(1, "fa-icon", 3);
    i04.\u0275\u0275pipe(2, "artemisTranslate");
    i04.\u0275\u0275text(3, "\n                ");
  }
  if (rf & 2) {
    const ctx_r1 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("icon", ctx_r1.getIcon(ctx_r1.exercise.type))("fixedWidth", true)("ngbTooltip", i04.\u0275\u0275pipeBind1(2, 3, ctx_r1.getIconTooltip(ctx_r1.exercise.type)));
  }
}
function ExerciseNodeDetailsComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n    ");
    i04.\u0275\u0275elementStart(1, "div", 0);
    i04.\u0275\u0275text(2, "\n        ");
    i04.\u0275\u0275elementStart(3, "div", 1);
    i04.\u0275\u0275text(4, "\n            ");
    i04.\u0275\u0275elementStart(5, "h3", 2);
    i04.\u0275\u0275text(6, "\n                ");
    i04.\u0275\u0275template(7, ExerciseNodeDetailsComponent_Conditional_0_Conditional_7_Template, 4, 5);
    i04.\u0275\u0275elementStart(8, "span");
    i04.\u0275\u0275text(9);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(10, "\n            ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(11, "\n        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(12, "\n    ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(13, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(7);
    i04.\u0275\u0275conditional(7, ctx_r0.exercise.type ? 7 : -1);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate(ctx_r0.exercise.title);
  }
}
var ExerciseNodeDetailsComponent;
var init_exercise_node_details_component = __esm({
  "src/main/webapp/app/course/learning-paths/learning-path-graph/node-details/exercise-node-details.component.ts"() {
    init_global_utils();
    init_alert_service();
    init_exercise_model();
    init_exercise_service();
    init_exercise_service();
    init_alert_service();
    init_artemis_translate_pipe();
    ExerciseNodeDetailsComponent = class _ExerciseNodeDetailsComponent {
      exerciseService;
      alertService;
      exerciseId;
      exercise;
      exerciseChange = new EventEmitter2();
      isLoading = false;
      constructor(exerciseService, alertService) {
        this.exerciseService = exerciseService;
        this.alertService = alertService;
      }
      ngOnInit() {
        if (!this.exercise) {
          this.loadData();
        }
      }
      loadData() {
        this.isLoading = true;
        this.exerciseService.find(this.exerciseId).subscribe({
          next: (exerciseResponse) => {
            this.exercise = exerciseResponse.body;
            this.isLoading = false;
            this.exerciseChange.emit(this.exercise);
          },
          error: (errorResponse) => onError(this.alertService, errorResponse)
        });
      }
      getIcon = getIcon;
      getIconTooltip = getIconTooltip;
      static \u0275fac = function ExerciseNodeDetailsComponent_Factory(t) {
        return new (t || _ExerciseNodeDetailsComponent)(i04.\u0275\u0275directiveInject(ExerciseService), i04.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _ExerciseNodeDetailsComponent, selectors: [["jhi-exercise-node-details"]], inputs: { exerciseId: "exerciseId", exercise: "exercise" }, outputs: { exerciseChange: "exerciseChange" }, decls: 1, vars: 1, consts: [[1, "row"], [1, "col"], [1, "mb-0"], ["container", "body", 3, "icon", "fixedWidth", "ngbTooltip"]], template: function ExerciseNodeDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275template(0, ExerciseNodeDetailsComponent_Conditional_0_Template, 14, 2);
        }
        if (rf & 2) {
          i04.\u0275\u0275conditional(0, ctx.exercise ? 0 : -1);
        }
      }, dependencies: [i32.NgbTooltip, i42.FaIconComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(ExerciseNodeDetailsComponent, { className: "ExerciseNodeDetailsComponent" });
    })();
  }
});

// src/main/webapp/app/course/learning-paths/learning-path-graph/node-details/lecture-unit-node-details.component.ts
import { Component as Component3, EventEmitter as EventEmitter3, Input as Input3, Output as Output3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i33 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i43 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function LectureUnitNodeDetailsComponent_Conditional_0_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275element(1, "fa-icon", 3);
    i05.\u0275\u0275pipe(2, "artemisTranslate");
    i05.\u0275\u0275text(3, "\n                ");
  }
  if (rf & 2) {
    const ctx_r1 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("icon", ctx_r1.getIcon(ctx_r1.lectureUnit.type))("fixedWidth", true)("ngbTooltip", i05.\u0275\u0275pipeBind1(2, 3, ctx_r1.getIconTooltip(ctx_r1.lectureUnit.type)));
  }
}
function LectureUnitNodeDetailsComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n    ");
    i05.\u0275\u0275elementStart(1, "div", 0);
    i05.\u0275\u0275text(2, "\n        ");
    i05.\u0275\u0275elementStart(3, "div", 1);
    i05.\u0275\u0275text(4, "\n            ");
    i05.\u0275\u0275elementStart(5, "h3", 2);
    i05.\u0275\u0275text(6, "\n                ");
    i05.\u0275\u0275template(7, LectureUnitNodeDetailsComponent_Conditional_0_Conditional_7_Template, 4, 5);
    i05.\u0275\u0275elementStart(8, "span");
    i05.\u0275\u0275text(9);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(10, "\n            ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(11, "\n        ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(12, "\n    ");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(13, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(7);
    i05.\u0275\u0275conditional(7, ctx_r0.lectureUnit.type ? 7 : -1);
    i05.\u0275\u0275advance(2);
    i05.\u0275\u0275textInterpolate(ctx_r0.lectureUnit.name);
  }
}
var LectureUnitNodeDetailsComponent;
var init_lecture_unit_node_details_component = __esm({
  "src/main/webapp/app/course/learning-paths/learning-path-graph/node-details/lecture-unit-node-details.component.ts"() {
    init_global_utils();
    init_alert_service();
    init_lectureUnit_model();
    init_lectureUnit_service();
    init_lectureUnit_service();
    init_alert_service();
    init_artemis_translate_pipe();
    LectureUnitNodeDetailsComponent = class _LectureUnitNodeDetailsComponent {
      lectureUnitService;
      alertService;
      lectureUnitId;
      lectureUnit;
      lectureUnitChange = new EventEmitter3();
      isLoading = false;
      constructor(lectureUnitService, alertService) {
        this.lectureUnitService = lectureUnitService;
        this.alertService = alertService;
      }
      ngOnInit() {
        if (!this.lectureUnit) {
          this.loadData();
        }
      }
      loadData() {
        this.isLoading = true;
        this.lectureUnitService.getLectureUnitForLearningPathNodeDetails(this.lectureUnitId).subscribe({
          next: (lectureUnitResult) => {
            this.lectureUnit = lectureUnitResult.body;
            this.isLoading = false;
            this.lectureUnitChange.emit(this.lectureUnit);
          },
          error: (errorResponse) => onError(this.alertService, errorResponse)
        });
      }
      getIcon = getIcon2;
      getIconTooltip = getIconTooltip2;
      static \u0275fac = function LectureUnitNodeDetailsComponent_Factory(t) {
        return new (t || _LectureUnitNodeDetailsComponent)(i05.\u0275\u0275directiveInject(LectureUnitService), i05.\u0275\u0275directiveInject(AlertService));
      };
      static \u0275cmp = i05.\u0275\u0275defineComponent({ type: _LectureUnitNodeDetailsComponent, selectors: [["jhi-lecture-unit-node-details"]], inputs: { lectureUnitId: "lectureUnitId", lectureUnit: "lectureUnit" }, outputs: { lectureUnitChange: "lectureUnitChange" }, decls: 1, vars: 1, consts: [[1, "row"], [1, "col"], [1, "mb-0"], ["container", "body", 3, "icon", "fixedWidth", "ngbTooltip"]], template: function LectureUnitNodeDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275template(0, LectureUnitNodeDetailsComponent_Conditional_0_Template, 14, 2);
        }
        if (rf & 2) {
          i05.\u0275\u0275conditional(0, ctx.lectureUnit ? 0 : -1);
        }
      }, dependencies: [i33.NgbTooltip, i43.FaIconComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(LectureUnitNodeDetailsComponent, { className: "LectureUnitNodeDetailsComponent" });
    })();
  }
});

// src/main/webapp/app/course/learning-paths/learning-path-graph/learning-path-node.component.ts
import { Component as Component4, Input as Input4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function LearningPathNodeComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n    ");
    i06.\u0275\u0275elementStart(1, "div", 2);
    i06.\u0275\u0275text(2, "\n        ");
    i06.\u0275\u0275element(3, "fa-icon", 3);
    i06.\u0275\u0275text(4, "\n    ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(5, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i06.\u0275\u0275nextContext();
    const _r3 = i06.\u0275\u0275reference(3);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("jhiStickyPopover", _r3);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275classProp("completed", ctx_r0.node.completed);
    i06.\u0275\u0275property("icon", ctx_r0.getIcon(ctx_r0.node));
  }
}
function LearningPathNodeComponent_Conditional_1_Conditional_1_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275element(1, "jhi-competency-rings", 4);
    i06.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r8 = i06.\u0275\u0275nextContext(3);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("progress", ctx_r8.progress)("confidence", ctx_r8.confidence)("mastery", ctx_r8.mastery)("hideTooltip", true);
  }
}
function LearningPathNodeComponent_Conditional_1_Conditional_1_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n                ");
    i06.\u0275\u0275element(1, "fa-icon", 5);
    i06.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r9 = i06.\u0275\u0275nextContext(3);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("icon", ctx_r9.getIcon(ctx_r9.node));
  }
}
function LearningPathNodeComponent_Conditional_1_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "div", 2);
    i06.\u0275\u0275text(2, "\n            ");
    i06.\u0275\u0275template(3, LearningPathNodeComponent_Conditional_1_Conditional_1_Conditional_3_Template, 3, 4)(4, LearningPathNodeComponent_Conditional_1_Conditional_1_Conditional_4_Template, 3, 1);
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r6 = i06.\u0275\u0275nextContext(2);
    const _r5 = i06.\u0275\u0275reference(6);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275classProp("node-s", ctx_r6.node.type === ctx_r6.NodeType.COMPETENCY_END);
    i06.\u0275\u0275property("jhiStickyPopover", _r5);
    i06.\u0275\u0275advance(2);
    i06.\u0275\u0275conditional(3, ctx_r6.node.type === ctx_r6.NodeType.COMPETENCY_START ? 3 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(4, ctx_r6.node.type === ctx_r6.NodeType.COMPETENCY_END ? 4 : -1);
  }
}
function LearningPathNodeComponent_Conditional_1_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "div", 6);
    i06.\u0275\u0275text(2, "\n            ");
    i06.\u0275\u0275element(3, "fa-icon", 7);
    i06.\u0275\u0275text(4, "\n        ");
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r7 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(3);
    i06.\u0275\u0275property("icon", ctx_r7.getIcon(ctx_r7.node));
  }
}
function LearningPathNodeComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n    ");
    i06.\u0275\u0275template(1, LearningPathNodeComponent_Conditional_1_Conditional_1_Template, 6, 5)(2, LearningPathNodeComponent_Conditional_1_Conditional_2_Template, 6, 1);
  }
  if (rf & 2) {
    const ctx_r1 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(1, ctx_r1.node.type === ctx_r1.NodeType.COMPETENCY_START || ctx_r1.node.type === ctx_r1.NodeType.COMPETENCY_END ? 1 : 2);
  }
}
function LearningPathNodeComponent_ng_template_2_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "jhi-exercise-node-details", 8);
    i06.\u0275\u0275listener("exerciseChange", function LearningPathNodeComponent_ng_template_2_Conditional_1_Template_jhi_exercise_node_details_exerciseChange_1_listener($event) {
      i06.\u0275\u0275restoreView(_r13);
      const ctx_r12 = i06.\u0275\u0275nextContext(2);
      return i06.\u0275\u0275resetView(ctx_r12.nodeDetailsData.exercise = $event);
    });
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(2, "\n    ");
  }
  if (rf & 2) {
    const ctx_r10 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("exerciseId", ctx_r10.node.linkedResource)("exercise", ctx_r10.nodeDetailsData.exercise);
  }
}
function LearningPathNodeComponent_ng_template_2_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n        ");
    i06.\u0275\u0275elementStart(1, "jhi-lecture-unit-node-details", 9);
    i06.\u0275\u0275listener("lectureUnitChange", function LearningPathNodeComponent_ng_template_2_Conditional_2_Template_jhi_lecture_unit_node_details_lectureUnitChange_1_listener($event) {
      i06.\u0275\u0275restoreView(_r15);
      const ctx_r14 = i06.\u0275\u0275nextContext(2);
      return i06.\u0275\u0275resetView(ctx_r14.nodeDetailsData.lectureUnit = $event);
    });
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(2, "\n    ");
  }
  if (rf & 2) {
    const ctx_r11 = i06.\u0275\u0275nextContext(2);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("lectureUnitId", ctx_r11.node.linkedResource)("lectureUnit", ctx_r11.nodeDetailsData.lectureUnit);
  }
}
function LearningPathNodeComponent_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    i06.\u0275\u0275text(0, "\n    ");
    i06.\u0275\u0275template(1, LearningPathNodeComponent_ng_template_2_Conditional_1_Template, 3, 2)(2, LearningPathNodeComponent_ng_template_2_Conditional_2_Template, 3, 2);
  }
  if (rf & 2) {
    const ctx_r2 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(1, ctx_r2.node.type === ctx_r2.NodeType.EXERCISE ? 1 : -1);
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275conditional(2, ctx_r2.node.type === ctx_r2.NodeType.LECTURE_UNIT ? 2 : -1);
  }
}
function LearningPathNodeComponent_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = i06.\u0275\u0275getCurrentView();
    i06.\u0275\u0275text(0, "\n    ");
    i06.\u0275\u0275elementStart(1, "jhi-competency-node-details", 10);
    i06.\u0275\u0275listener("competencyChange", function LearningPathNodeComponent_ng_template_5_Template_jhi_competency_node_details_competencyChange_1_listener($event) {
      i06.\u0275\u0275restoreView(_r17);
      const ctx_r16 = i06.\u0275\u0275nextContext();
      return i06.\u0275\u0275resetView(ctx_r16.nodeDetailsData.competency = $event);
    });
    i06.\u0275\u0275elementEnd();
    i06.\u0275\u0275text(2, "\n");
  }
  if (rf & 2) {
    const ctx_r4 = i06.\u0275\u0275nextContext();
    i06.\u0275\u0275advance(1);
    i06.\u0275\u0275property("courseId", ctx_r4.courseId)("competencyId", ctx_r4.node.linkedResource)("competency", ctx_r4.nodeDetailsData.competency)("competencyProgress", ctx_r4.nodeDetailsData.competencyProgress);
  }
}
var NodeDetailsData, LearningPathNodeComponent;
var init_learning_path_node_component = __esm({
  "src/main/webapp/app/course/learning-paths/learning-path-graph/learning-path-node.component.ts"() {
    init_learning_path_model();
    init_competency_model();
    init_sticky_popover_directive();
    init_competency_rings_component();
    init_competency_node_details_component();
    init_exercise_node_details_component();
    init_lecture_unit_node_details_component();
    NodeDetailsData = class {
      competency;
      competencyProgress;
      exercise;
      lecture;
      lectureUnit;
    };
    LearningPathNodeComponent = class _LearningPathNodeComponent {
      courseId;
      node;
      competencyProgressDTO;
      nodeDetailsData = new NodeDetailsData();
      NodeType = NodeType;
      getIcon = getIcon4;
      constructor() {
      }
      ngOnInit() {
        if (this.competencyProgressDTO) {
          this.nodeDetailsData.competencyProgress = { progress: this.competencyProgressDTO.progress, confidence: this.competencyProgressDTO.confidence };
        }
      }
      get progress() {
        return getProgress(this.nodeDetailsData.competencyProgress);
      }
      get confidence() {
        return getConfidence(this.nodeDetailsData.competencyProgress, this.competencyProgressDTO.masteryThreshold);
      }
      get mastery() {
        return getMastery(this.nodeDetailsData.competencyProgress, this.competencyProgressDTO.masteryThreshold);
      }
      static \u0275fac = function LearningPathNodeComponent_Factory(t) {
        return new (t || _LearningPathNodeComponent)();
      };
      static \u0275cmp = i06.\u0275\u0275defineComponent({ type: _LearningPathNodeComponent, selectors: [["jhi-learning-path-graph-node"]], inputs: { courseId: "courseId", node: "node", competencyProgressDTO: "competencyProgressDTO" }, decls: 8, vars: 1, consts: [["popContentTask", ""], ["popContentCompetency", ""], ["placement", "right", "triggers", "manual", 1, "node-icon-container", 3, "jhiStickyPopover"], ["id", "learning-object", 3, "icon"], ["id", "competency-start", 1, "m-1", 3, "progress", "confidence", "mastery", "hideTooltip"], ["id", "competency-end", 3, "icon"], [1, "node-xs", "node-icon-container"], ["id", "match", 3, "icon"], [1, "node-details", 3, "exerciseId", "exercise", "exerciseChange"], [1, "node-details", 3, "lectureUnitId", "lectureUnit", "lectureUnitChange"], [1, "node-details", 3, "courseId", "competencyId", "competency", "competencyProgress", "competencyChange"]], template: function LearningPathNodeComponent_Template(rf, ctx) {
        if (rf & 1) {
          i06.\u0275\u0275template(0, LearningPathNodeComponent_Conditional_0_Template, 6, 4)(1, LearningPathNodeComponent_Conditional_1_Template, 3, 1)(2, LearningPathNodeComponent_ng_template_2_Template, 3, 2, "ng-template", null, 0, i06.\u0275\u0275templateRefExtractor);
          i06.\u0275\u0275text(4, "\n");
          i06.\u0275\u0275template(5, LearningPathNodeComponent_ng_template_5_Template, 3, 4, "ng-template", null, 1, i06.\u0275\u0275templateRefExtractor);
          i06.\u0275\u0275text(7, "\n");
        }
        if (rf & 2) {
          i06.\u0275\u0275conditional(0, ctx.node.type === ctx.NodeType.EXERCISE || ctx.node.type === ctx.NodeType.LECTURE_UNIT ? 0 : 1);
        }
      }, dependencies: [i12.FaIconComponent, StickyPopoverDirective, CompetencyRingsComponent, CompetencyNodeDetailsComponent, ExerciseNodeDetailsComponent, LectureUnitNodeDetailsComponent], styles: ["\n\n.graph-container[_ngcontent-%COMP%] {\n  display: flex;\n  width: 100%;\n  height: 100%;\n  overflow: hidden;\n}\n.graph-container[_ngcontent-%COMP%]   .node[_ngcontent-%COMP%] {\n  display: flex;\n  width: 100%;\n  height: 100%;\n}\n.graph-container[_ngcontent-%COMP%]   #arrow[_ngcontent-%COMP%] {\n  stroke: var(--body-color);\n  fill: var(--body-color);\n}\n.graph-container[_ngcontent-%COMP%]   .edge[_ngcontent-%COMP%] {\n  stroke: var(--body-color) !important;\n  marker-end: url(#arrow);\n}\n.graph-container[_ngcontent-%COMP%]   .floating-icon-button[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  padding: 0.25em;\n}\n.graph-container[_ngcontent-%COMP%]   .floating-icon-button[_ngcontent-%COMP%]:hover {\n  cursor: pointer;\n}\njhi-learning-path-graph-node[_ngcontent-%COMP%]:hover {\n  cursor: pointer;\n}\n.node-icon-container[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n}\n.node-icon-container[_ngcontent-%COMP%]   fa-icon[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n}\n[_nghost-%COMP%]  .graph-container .node-icon-container fa-icon svg {\n  margin: 10%;\n  width: 80%;\n  height: 80%;\n}\n.node-xs[_ngcontent-%COMP%] {\n  width: 40%;\n  margin: 30%;\n}\n.node-s[_ngcontent-%COMP%] {\n  width: 60%;\n  margin: 20%;\n}\n.completed[_ngcontent-%COMP%] {\n  color: var(--bs-success);\n}\n.current[_ngcontent-%COMP%] {\n  color: var(--bs-warning);\n}\n.node-details[_ngcontent-%COMP%] {\n  display: block;\n  max-width: 40vw;\n}\n.legend[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  bottom: 0;\n  margin-right: 0.5em;\n  margin-bottom: 0.5em;\n}\n.legend-wrapper[_ngcontent-%COMP%] {\n  background: var(--bs-body-bg);\n  border-radius: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC1ncmFwaC9sZWFybmluZy1wYXRoLWdyYXBoLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuZ3JhcGgtY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuXG4gICAgLm5vZGUge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgIH1cblxuICAgICNhcnJvdyB7XG4gICAgICAgIHN0cm9rZTogdmFyKC0tYm9keS1jb2xvcik7XG4gICAgICAgIGZpbGw6IHZhcigtLWJvZHktY29sb3IpO1xuICAgIH1cblxuICAgIC5lZGdlIHtcbiAgICAgICAgc3Ryb2tlOiB2YXIoLS1ib2R5LWNvbG9yKSAhaW1wb3J0YW50O1xuICAgICAgICBtYXJrZXItZW5kOiB1cmwoI2Fycm93KTtcbiAgICB9XG5cbiAgICAuZmxvYXRpbmctaWNvbi1idXR0b24ge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICBwYWRkaW5nOiAwLjI1ZW07XG4gICAgfVxuICAgIC5mbG9hdGluZy1pY29uLWJ1dHRvbjpob3ZlciB7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB9XG59XG5cbmpoaS1sZWFybmluZy1wYXRoLWdyYXBoLW5vZGU6aG92ZXIge1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLm5vZGUtaWNvbi1jb250YWluZXIge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGRpc3BsYXk6IGZsZXg7XG5cbiAgICBmYS1pY29uIHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgfVxufVxuXG46aG9zdDo6bmctZGVlcCAuZ3JhcGgtY29udGFpbmVyIC5ub2RlLWljb24tY29udGFpbmVyIGZhLWljb24gc3ZnIHtcbiAgICBtYXJnaW46IDEwJTtcbiAgICB3aWR0aDogODAlO1xuICAgIGhlaWdodDogODAlO1xufVxuXG4ubm9kZS14cyB7XG4gICAgd2lkdGg6IDQwJTtcbiAgICBtYXJnaW46IDMwJTtcbn1cblxuLm5vZGUtcyB7XG4gICAgd2lkdGg6IDYwJTtcbiAgICBtYXJnaW46IDIwJTtcbn1cblxuLmNvbXBsZXRlZCB7XG4gICAgY29sb3I6IHZhcigtLWJzLXN1Y2Nlc3MpO1xufVxuXG4uY3VycmVudCB7XG4gICAgY29sb3I6IHZhcigtLWJzLXdhcm5pbmcpO1xufVxuXG4ubm9kZS1kZXRhaWxzIHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXgtd2lkdGg6IDQwdnc7XG59XG5cbi5sZWdlbmQge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICByaWdodDogMDtcbiAgICBib3R0b206IDA7XG4gICAgbWFyZ2luLXJpZ2h0OiAwLjVlbTtcbiAgICBtYXJnaW4tYm90dG9tOiAwLjVlbTtcbn1cblxuLmxlZ2VuZC13cmFwcGVyIHtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1icy1ib2R5LWJnKTtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxTQUFBO0FBQ0EsVUFBQTtBQUNBLFlBQUE7O0FBRUEsQ0FOSixnQkFNSSxDQUFBO0FBQ0ksV0FBQTtBQUNBLFNBQUE7QUFDQSxVQUFBOztBQUdKLENBWkosZ0JBWUksQ0FBQTtBQUNJLFVBQUEsSUFBQTtBQUNBLFFBQUEsSUFBQTs7QUFHSixDQWpCSixnQkFpQkksQ0FBQTtBQUNJLFVBQUEsSUFBQTtBQUNBLGNBQUE7O0FBR0osQ0F0QkosZ0JBc0JJLENBQUE7QUFDSSxZQUFBO0FBQ0EsU0FBQTtBQUNBLFdBQUE7O0FBRUosQ0EzQkosZ0JBMkJJLENBTEEsb0JBS0E7QUFDSSxVQUFBOztBQUlSLDRCQUFBO0FBQ0ksVUFBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQTtBQUNBLFdBQUE7O0FBRUEsQ0FKSixvQkFJSTtBQUNJLFNBQUE7QUFDQSxXQUFBOztBQUlSLEtBQUEsVUFBQSxDQTlDQSxnQkE4Q0EsQ0FWQSxvQkFVQSxRQUFBO0FBQ0ksVUFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBOztBQUdKLENBQUE7QUFDSSxTQUFBO0FBQ0EsVUFBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQTtBQUNBLFVBQUE7O0FBR0osQ0FBQTtBQUNJLFNBQUEsSUFBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxXQUFBO0FBQ0EsYUFBQTs7QUFHSixDQUFBO0FBQ0ksWUFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBO0FBQ0EsZ0JBQUE7QUFDQSxpQkFBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQSxJQUFBO0FBQ0EsaUJBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i06.\u0275setClassDebugInfo(LearningPathNodeComponent, { className: "LearningPathNodeComponent" });
    })();
  }
});

// src/main/webapp/app/course/learning-paths/learning-path-graph/learning-path-legend.component.ts
import { Component as Component5, Input as Input5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function LearningPathLegendComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n        ");
    i07.\u0275\u0275elementStart(1, "div", 1);
    i07.\u0275\u0275pipe(2, "artemisTranslate");
    i07.\u0275\u0275text(3, "\n            ");
    i07.\u0275\u0275elementStart(4, "div", 2);
    i07.\u0275\u0275element(5, "fa-icon", 3);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n            ");
    i07.\u0275\u0275elementStart(7, "div", 2);
    i07.\u0275\u0275text(8, "\n                ");
    i07.\u0275\u0275elementStart(9, "span");
    i07.\u0275\u0275text(10);
    i07.\u0275\u0275pipe(11, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(12, "\n            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(13, "\n        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(14, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275propertyInterpolate("ngbTooltip", i07.\u0275\u0275pipeBind1(2, 3, "artemisApp.learningPath.graph.legend.competencyEnd.tooltip"));
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275property("icon", ctx_r0.getIcon(ctx_r0.competencyEnd));
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275textInterpolate1("\n                    ", i07.\u0275\u0275pipeBind1(11, 5, "artemisApp.learningPath.graph.legend.competencyEnd.title"), "\n                ");
  }
}
function LearningPathLegendComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n        ");
    i07.\u0275\u0275elementStart(1, "div", 4);
    i07.\u0275\u0275pipe(2, "artemisTranslate");
    i07.\u0275\u0275text(3, "\n            ");
    i07.\u0275\u0275elementStart(4, "div", 2);
    i07.\u0275\u0275element(5, "fa-icon", 3);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n            ");
    i07.\u0275\u0275elementStart(7, "div", 2);
    i07.\u0275\u0275text(8, "\n                ");
    i07.\u0275\u0275elementStart(9, "span");
    i07.\u0275\u0275text(10);
    i07.\u0275\u0275pipe(11, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(12, "\n            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(13, "\n        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(14, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275propertyInterpolate("ngbTooltip", i07.\u0275\u0275pipeBind1(2, 3, "artemisApp.learningPath.graph.legend.matchStart.tooltip"));
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275property("icon", ctx_r1.getIcon(ctx_r1.matchStart));
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275textInterpolate1("\n                    ", i07.\u0275\u0275pipeBind1(11, 5, "artemisApp.learningPath.graph.legend.matchStart.title"), "\n                ");
  }
}
function LearningPathLegendComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n        ");
    i07.\u0275\u0275elementStart(1, "div", 5);
    i07.\u0275\u0275pipe(2, "artemisTranslate");
    i07.\u0275\u0275text(3, "\n            ");
    i07.\u0275\u0275elementStart(4, "div", 2);
    i07.\u0275\u0275element(5, "fa-icon", 3);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n            ");
    i07.\u0275\u0275elementStart(7, "div", 2);
    i07.\u0275\u0275text(8, "\n                ");
    i07.\u0275\u0275elementStart(9, "span");
    i07.\u0275\u0275text(10);
    i07.\u0275\u0275pipe(11, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(12, "\n            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(13, "\n        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(14, "\n    ");
  }
  if (rf & 2) {
    const ctx_r2 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275propertyInterpolate("ngbTooltip", i07.\u0275\u0275pipeBind1(2, 3, "artemisApp.learningPath.graph.legend.matchEnd.tooltip"));
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275property("icon", ctx_r2.getIcon(ctx_r2.matchEnd));
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275textInterpolate1("\n                    ", i07.\u0275\u0275pipeBind1(11, 5, "artemisApp.learningPath.graph.legend.matchEnd.title"), "\n                ");
  }
}
function LearningPathLegendComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n        ");
    i07.\u0275\u0275elementStart(1, "div", 6);
    i07.\u0275\u0275pipe(2, "artemisTranslate");
    i07.\u0275\u0275text(3, "\n            ");
    i07.\u0275\u0275elementStart(4, "div", 2);
    i07.\u0275\u0275element(5, "fa-icon", 3);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n            ");
    i07.\u0275\u0275elementStart(7, "div", 2);
    i07.\u0275\u0275text(8, "\n                ");
    i07.\u0275\u0275elementStart(9, "span");
    i07.\u0275\u0275text(10);
    i07.\u0275\u0275pipe(11, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(12, "\n            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(13, "\n        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(14, "\n    ");
  }
  if (rf & 2) {
    const ctx_r3 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275propertyInterpolate("ngbTooltip", i07.\u0275\u0275pipeBind1(2, 3, "artemisApp.learningPath.graph.legend.learningObject.tooltip"));
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275property("icon", ctx_r3.getIcon(ctx_r3.learningObject));
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275textInterpolate1("\n                    ", i07.\u0275\u0275pipeBind1(11, 5, "artemisApp.learningPath.graph.legend.learningObject.title"), "\n                ");
  }
}
function LearningPathLegendComponent_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275text(0, "\n        ");
    i07.\u0275\u0275elementStart(1, "div", 7);
    i07.\u0275\u0275pipe(2, "artemisTranslate");
    i07.\u0275\u0275text(3, "\n            ");
    i07.\u0275\u0275elementStart(4, "div", 2);
    i07.\u0275\u0275element(5, "fa-icon", 3);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(6, "\n            ");
    i07.\u0275\u0275elementStart(7, "div", 2);
    i07.\u0275\u0275text(8, "\n                ");
    i07.\u0275\u0275elementStart(9, "span");
    i07.\u0275\u0275text(10);
    i07.\u0275\u0275pipe(11, "artemisTranslate");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(12, "\n            ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(13, "\n        ");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275text(14, "\n    ");
  }
  if (rf & 2) {
    const ctx_r4 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275advance(1);
    i07.\u0275\u0275propertyInterpolate("ngbTooltip", i07.\u0275\u0275pipeBind1(2, 3, "artemisApp.learningPath.graph.legend.completedLearningObject.tooltip"));
    i07.\u0275\u0275advance(4);
    i07.\u0275\u0275property("icon", ctx_r4.getIcon(ctx_r4.completedLearningObject));
    i07.\u0275\u0275advance(5);
    i07.\u0275\u0275textInterpolate1("\n                    ", i07.\u0275\u0275pipeBind1(11, 5, "artemisApp.learningPath.graph.legend.completedLearningObject.title"), "\n                ");
  }
}
var LearningPathLegendComponent;
var init_learning_path_legend_component = __esm({
  "src/main/webapp/app/course/learning-paths/learning-path-graph/learning-path-legend.component.ts"() {
    init_learning_path_model();
    init_artemis_translate_pipe();
    LearningPathLegendComponent = class _LearningPathLegendComponent {
      nodeTypes;
      getIcon = getIcon4;
      competencyEnd = { id: "", type: NodeType.COMPETENCY_END };
      matchStart = { id: "", type: NodeType.MATCH_START };
      matchEnd = { id: "", type: NodeType.MATCH_END };
      learningObject = { id: "", type: NodeType.LECTURE_UNIT };
      completedLearningObject = { id: "", type: NodeType.LECTURE_UNIT, completed: true };
      NodeType = NodeType;
      static \u0275fac = function LearningPathLegendComponent_Factory(t) {
        return new (t || _LearningPathLegendComponent)();
      };
      static \u0275cmp = i07.\u0275\u0275defineComponent({ type: _LearningPathLegendComponent, selectors: [["jhi-learning-path-legend"]], inputs: { nodeTypes: "nodeTypes" }, decls: 8, vars: 5, consts: [[1, "container", "legend-wrapper"], ["id", "competency-end", 1, "row", 3, "ngbTooltip"], [1, "col-auto"], [1, "legend-icon", 3, "icon"], ["id", "match-start", 1, "row", 3, "ngbTooltip"], ["id", "match-end", 1, "row", 3, "ngbTooltip"], ["id", "learning-object", 1, "row", 3, "ngbTooltip"], ["id", "completed-learning-object", 1, "row", 3, "ngbTooltip"]], template: function LearningPathLegendComponent_Template(rf, ctx) {
        if (rf & 1) {
          i07.\u0275\u0275elementStart(0, "div", 0);
          i07.\u0275\u0275text(1, "\n    ");
          i07.\u0275\u0275template(2, LearningPathLegendComponent_Conditional_2_Template, 15, 7)(3, LearningPathLegendComponent_Conditional_3_Template, 15, 7)(4, LearningPathLegendComponent_Conditional_4_Template, 15, 7)(5, LearningPathLegendComponent_Conditional_5_Template, 15, 7)(6, LearningPathLegendComponent_Conditional_6_Template, 15, 7);
          i07.\u0275\u0275elementEnd();
          i07.\u0275\u0275text(7, "\n");
        }
        if (rf & 2) {
          i07.\u0275\u0275advance(2);
          i07.\u0275\u0275conditional(2, ctx.nodeTypes.has(ctx.NodeType.COMPETENCY_END) ? 2 : -1);
          i07.\u0275\u0275advance(1);
          i07.\u0275\u0275conditional(3, ctx.nodeTypes.has(ctx.NodeType.MATCH_START) ? 3 : -1);
          i07.\u0275\u0275advance(1);
          i07.\u0275\u0275conditional(4, ctx.nodeTypes.has(ctx.NodeType.MATCH_END) ? 4 : -1);
          i07.\u0275\u0275advance(1);
          i07.\u0275\u0275conditional(5, ctx.nodeTypes.has(ctx.NodeType.LECTURE_UNIT) || ctx.nodeTypes.has(ctx.NodeType.EXERCISE) ? 5 : -1);
          i07.\u0275\u0275advance(1);
          i07.\u0275\u0275conditional(6, ctx.nodeTypes.has(ctx.NodeType.LECTURE_UNIT) || ctx.nodeTypes.has(ctx.NodeType.EXERCISE) ? 6 : -1);
        }
      }, dependencies: [i13.NgbTooltip, i2.FaIconComponent, ArtemisTranslatePipe], styles: ["\n\n.graph-container[_ngcontent-%COMP%] {\n  display: flex;\n  width: 100%;\n  height: 100%;\n  overflow: hidden;\n}\n.graph-container[_ngcontent-%COMP%]   .node[_ngcontent-%COMP%] {\n  display: flex;\n  width: 100%;\n  height: 100%;\n}\n.graph-container[_ngcontent-%COMP%]   #arrow[_ngcontent-%COMP%] {\n  stroke: var(--body-color);\n  fill: var(--body-color);\n}\n.graph-container[_ngcontent-%COMP%]   .edge[_ngcontent-%COMP%] {\n  stroke: var(--body-color) !important;\n  marker-end: url(#arrow);\n}\n.graph-container[_ngcontent-%COMP%]   .floating-icon-button[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  padding: 0.25em;\n}\n.graph-container[_ngcontent-%COMP%]   .floating-icon-button[_ngcontent-%COMP%]:hover {\n  cursor: pointer;\n}\njhi-learning-path-graph-node[_ngcontent-%COMP%]:hover {\n  cursor: pointer;\n}\n.node-icon-container[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n}\n.node-icon-container[_ngcontent-%COMP%]   fa-icon[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n}\n[_nghost-%COMP%]  .graph-container .node-icon-container fa-icon svg {\n  margin: 10%;\n  width: 80%;\n  height: 80%;\n}\n.node-xs[_ngcontent-%COMP%] {\n  width: 40%;\n  margin: 30%;\n}\n.node-s[_ngcontent-%COMP%] {\n  width: 60%;\n  margin: 20%;\n}\n.completed[_ngcontent-%COMP%] {\n  color: var(--bs-success);\n}\n.current[_ngcontent-%COMP%] {\n  color: var(--bs-warning);\n}\n.node-details[_ngcontent-%COMP%] {\n  display: block;\n  max-width: 40vw;\n}\n.legend[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  bottom: 0;\n  margin-right: 0.5em;\n  margin-bottom: 0.5em;\n}\n.legend-wrapper[_ngcontent-%COMP%] {\n  background: var(--bs-body-bg);\n  border-radius: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC1ncmFwaC9sZWFybmluZy1wYXRoLWdyYXBoLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuZ3JhcGgtY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuXG4gICAgLm5vZGUge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgIH1cblxuICAgICNhcnJvdyB7XG4gICAgICAgIHN0cm9rZTogdmFyKC0tYm9keS1jb2xvcik7XG4gICAgICAgIGZpbGw6IHZhcigtLWJvZHktY29sb3IpO1xuICAgIH1cblxuICAgIC5lZGdlIHtcbiAgICAgICAgc3Ryb2tlOiB2YXIoLS1ib2R5LWNvbG9yKSAhaW1wb3J0YW50O1xuICAgICAgICBtYXJrZXItZW5kOiB1cmwoI2Fycm93KTtcbiAgICB9XG5cbiAgICAuZmxvYXRpbmctaWNvbi1idXR0b24ge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICBwYWRkaW5nOiAwLjI1ZW07XG4gICAgfVxuICAgIC5mbG9hdGluZy1pY29uLWJ1dHRvbjpob3ZlciB7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB9XG59XG5cbmpoaS1sZWFybmluZy1wYXRoLWdyYXBoLW5vZGU6aG92ZXIge1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLm5vZGUtaWNvbi1jb250YWluZXIge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGRpc3BsYXk6IGZsZXg7XG5cbiAgICBmYS1pY29uIHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgfVxufVxuXG46aG9zdDo6bmctZGVlcCAuZ3JhcGgtY29udGFpbmVyIC5ub2RlLWljb24tY29udGFpbmVyIGZhLWljb24gc3ZnIHtcbiAgICBtYXJnaW46IDEwJTtcbiAgICB3aWR0aDogODAlO1xuICAgIGhlaWdodDogODAlO1xufVxuXG4ubm9kZS14cyB7XG4gICAgd2lkdGg6IDQwJTtcbiAgICBtYXJnaW46IDMwJTtcbn1cblxuLm5vZGUtcyB7XG4gICAgd2lkdGg6IDYwJTtcbiAgICBtYXJnaW46IDIwJTtcbn1cblxuLmNvbXBsZXRlZCB7XG4gICAgY29sb3I6IHZhcigtLWJzLXN1Y2Nlc3MpO1xufVxuXG4uY3VycmVudCB7XG4gICAgY29sb3I6IHZhcigtLWJzLXdhcm5pbmcpO1xufVxuXG4ubm9kZS1kZXRhaWxzIHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXgtd2lkdGg6IDQwdnc7XG59XG5cbi5sZWdlbmQge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICByaWdodDogMDtcbiAgICBib3R0b206IDA7XG4gICAgbWFyZ2luLXJpZ2h0OiAwLjVlbTtcbiAgICBtYXJnaW4tYm90dG9tOiAwLjVlbTtcbn1cblxuLmxlZ2VuZC13cmFwcGVyIHtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1icy1ib2R5LWJnKTtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxTQUFBO0FBQ0EsVUFBQTtBQUNBLFlBQUE7O0FBRUEsQ0FOSixnQkFNSSxDQUFBO0FBQ0ksV0FBQTtBQUNBLFNBQUE7QUFDQSxVQUFBOztBQUdKLENBWkosZ0JBWUksQ0FBQTtBQUNJLFVBQUEsSUFBQTtBQUNBLFFBQUEsSUFBQTs7QUFHSixDQWpCSixnQkFpQkksQ0FBQTtBQUNJLFVBQUEsSUFBQTtBQUNBLGNBQUE7O0FBR0osQ0F0QkosZ0JBc0JJLENBQUE7QUFDSSxZQUFBO0FBQ0EsU0FBQTtBQUNBLFdBQUE7O0FBRUosQ0EzQkosZ0JBMkJJLENBTEEsb0JBS0E7QUFDSSxVQUFBOztBQUlSLDRCQUFBO0FBQ0ksVUFBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQTtBQUNBLFdBQUE7O0FBRUEsQ0FKSixvQkFJSTtBQUNJLFNBQUE7QUFDQSxXQUFBOztBQUlSLEtBQUEsVUFBQSxDQTlDQSxnQkE4Q0EsQ0FWQSxvQkFVQSxRQUFBO0FBQ0ksVUFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBOztBQUdKLENBQUE7QUFDSSxTQUFBO0FBQ0EsVUFBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQTtBQUNBLFVBQUE7O0FBR0osQ0FBQTtBQUNJLFNBQUEsSUFBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxXQUFBO0FBQ0EsYUFBQTs7QUFHSixDQUFBO0FBQ0ksWUFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBO0FBQ0EsZ0JBQUE7QUFDQSxpQkFBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQSxJQUFBO0FBQ0EsaUJBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i07.\u0275setClassDebugInfo(LearningPathLegendComponent, { className: "LearningPathLegendComponent" });
    })();
  }
});

// src/main/webapp/app/course/learning-paths/learning-path-graph/learning-path-graph.component.ts
import { Component as Component6, EventEmitter as EventEmitter4, Input as Input6, Output as Output4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as shape from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/d3-shape.js?v=1d0d9ead";
import { Subject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i08 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-graph.js?v=1d0d9ead";
function LearningPathGraphComponent_Conditional_2_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275namespaceSVG();
    i08.\u0275\u0275elementStart(1, "marker", 7);
    i08.\u0275\u0275text(2, "\n                    ");
    i08.\u0275\u0275element(3, "path", 8);
    i08.\u0275\u0275text(4, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(5, "\n            ");
  }
}
function LearningPathGraphComponent_Conditional_2_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275namespaceSVG();
    i08.\u0275\u0275elementStart(1, "g");
    i08.\u0275\u0275text(2, "\n                    ");
    i08.\u0275\u0275elementStart(3, "foreignObject");
    i08.\u0275\u0275text(4, "\n                        ");
    i08.\u0275\u0275namespaceHTML();
    i08.\u0275\u0275elementStart(5, "jhi-learning-path-graph-node", 9);
    i08.\u0275\u0275listener("click", function LearningPathGraphComponent_Conditional_2_ng_template_6_Template_jhi_learning_path_graph_node_click_5_listener() {
      const restoredCtx = i08.\u0275\u0275restoreView(_r11);
      const node_r9 = restoredCtx.$implicit;
      const ctx_r10 = i08.\u0275\u0275nextContext(2);
      return i08.\u0275\u0275resetView(ctx_r10.nodeClicked.emit(node_r9));
    });
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(6, "\n                    ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(7, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(8, "\n            ");
  }
  if (rf & 2) {
    const node_r9 = ctx.$implicit;
    const ctx_r3 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275attribute("width", node_r9.dimension.width)("height", node_r9.dimension.height);
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275attribute("width", node_r9.dimension.width)("height", node_r9.dimension.height);
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275propertyInterpolate("id", node_r9.id);
    i08.\u0275\u0275property("courseId", ctx_r3.courseId)("node", node_r9)("competencyProgressDTO", node_r9.type === ctx_r3.NodeType.COMPETENCY_START || node_r9.type === ctx_r3.NodeType.COMPETENCY_END ? ctx_r3.competencyProgress.get(node_r9.linkedResource) : void 0);
  }
}
function LearningPathGraphComponent_Conditional_2_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275namespaceSVG();
    i08.\u0275\u0275elementStart(1, "g", 10);
    i08.\u0275\u0275text(2, "\n                    ");
    i08.\u0275\u0275element(3, "path", 11);
    i08.\u0275\u0275text(4, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(5, "\n            ");
  }
}
function LearningPathGraphComponent_Conditional_2_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n                ");
    i08.\u0275\u0275namespaceSVG();
    i08.\u0275\u0275elementStart(1, "g", 12);
    i08.\u0275\u0275text(2, "\n                    ");
    i08.\u0275\u0275element(3, "rect", 13);
    i08.\u0275\u0275text(4, "\n                ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const cluster_r13 = ctx.$implicit;
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275attribute("width", cluster_r13.dimension.width)("height", cluster_r13.dimension.height)("fill", cluster_r13.data.color);
  }
}
function LearningPathGraphComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275text(0, "\n        ");
    i08.\u0275\u0275elementStart(1, "ngx-graph", 2);
    i08.\u0275\u0275text(2, "\n            ");
    i08.\u0275\u0275template(3, LearningPathGraphComponent_Conditional_2_ng_template_3_Template, 6, 0, "ng-template", null, 3, i08.\u0275\u0275templateRefExtractor);
    i08.\u0275\u0275text(5, "\n            ");
    i08.\u0275\u0275template(6, LearningPathGraphComponent_Conditional_2_ng_template_6_Template, 9, 8, "ng-template", null, 4, i08.\u0275\u0275templateRefExtractor);
    i08.\u0275\u0275text(8, "\n            ");
    i08.\u0275\u0275template(9, LearningPathGraphComponent_Conditional_2_ng_template_9_Template, 6, 0, "ng-template", null, 5, i08.\u0275\u0275templateRefExtractor);
    i08.\u0275\u0275text(11, "\n            ");
    i08.\u0275\u0275template(12, LearningPathGraphComponent_Conditional_2_ng_template_12_Template, 6, 3, "ng-template", null, 6, i08.\u0275\u0275templateRefExtractor);
    i08.\u0275\u0275text(14, "\n        ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(15, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(1);
    i08.\u0275\u0275property("links", ctx_r0.ngxLearningPath.edges)("nodes", ctx_r0.ngxLearningPath.nodes)("layout", ctx_r0.layout)("layoutSettings", i08.\u0275\u0275pureFunction0(15, _c0))("curve", ctx_r0.curve)("draggingEnabled", ctx_r0.draggingEnabled)("panningEnabled", ctx_r0.panningEnabled)("enableZoom", ctx_r0.zoomEnabled)("panOnZoom", ctx_r0.panOnZoom)("showMiniMap", ctx_r0.showMiniMap)("miniMapMaxWidth", 250)("miniMapMaxHeight", 250)("update$", ctx_r0.update$)("center$", ctx_r0.center$)("zoomToFit$", ctx_r0.zoomToFit$);
  }
}
var _c0, LearningPathGraphComponent;
var init_learning_path_graph_component = __esm({
  "src/main/webapp/app/course/learning-paths/learning-path-graph/learning-path-graph.component.ts"() {
    init_learning_path_service();
    init_learning_path_model();
    init_learning_path_service();
    init_learning_path_node_component();
    init_learning_path_legend_component();
    _c0 = () => ({ orientation: "TB" });
    LearningPathGraphComponent = class _LearningPathGraphComponent {
      learningPathService;
      isLoading = false;
      learningPathId;
      courseId;
      nodeClicked = new EventEmitter4();
      ngxLearningPath;
      nodeTypes = /* @__PURE__ */ new Set();
      competencyProgress = /* @__PURE__ */ new Map();
      layout = "dagreCluster";
      curve = shape.curveBundle;
      _draggingEnabled = false;
      _panningEnabled = false;
      _zoomEnabled = false;
      _panOnZoom = false;
      _showMiniMap = false;
      update$ = new Subject();
      center$ = new Subject();
      zoomToFit$ = new Subject();
      NodeType = NodeType;
      constructor(learningPathService) {
        this.learningPathService = learningPathService;
      }
      ngOnInit() {
        if (this.learningPathId) {
          this.loadDataAndRender();
        }
      }
      set draggingEnabled(value) {
        this._draggingEnabled = value;
      }
      get draggingEnabled() {
        return this._draggingEnabled;
      }
      set panningEnabled(value) {
        this._panningEnabled = value;
      }
      get panningEnabled() {
        return this._panningEnabled;
      }
      set zoomEnabled(value) {
        this._zoomEnabled = value;
      }
      get zoomEnabled() {
        return this._zoomEnabled;
      }
      set panOnZoom(value) {
        this._panOnZoom = value;
      }
      get panOnZoom() {
        return this._panOnZoom;
      }
      set showMiniMap(value) {
        this._showMiniMap = value;
      }
      get showMiniMap() {
        return this._showMiniMap;
      }
      refreshData() {
        this.loadDataAndRender();
      }
      loadDataAndRender() {
        this.learningPathService.getCompetencyProgressForLearningPath(this.learningPathId).subscribe({
          next: (response) => {
            response.body.forEach((progress) => {
              this.competencyProgress.set(progress.competencyId, progress);
            });
          },
          complete: () => {
            this.loadGraphRepresentation(true);
          }
        });
      }
      loadGraphRepresentation(render) {
        this.isLoading = true;
        this.learningPathService.getLearningPathNgxGraph(this.learningPathId).subscribe((ngxLearningPathResponse) => {
          ngxLearningPathResponse.body.nodes.forEach((node) => {
            this.defineNodeDimensions(node);
          });
          this.ngxLearningPath = ngxLearningPathResponse.body;
          this.nodeTypes = /* @__PURE__ */ new Set();
          this.ngxLearningPath.nodes.forEach((node) => {
            this.nodeTypes.add(node.type);
          });
          if (render) {
            this.update$.next(true);
          }
          this.isLoading = false;
        });
      }
      defineNodeDimensions(node) {
        if (node.type === NodeType.COMPETENCY_START) {
          node.dimension = { width: 75, height: 75 };
        } else {
          node.dimension = { width: 50, height: 50 };
        }
      }
      onResize() {
        this.update$.next(true);
        this.center$.next(true);
        this.zoomToFit$.next(true);
      }
      onCenterView() {
        this.zoomToFit$.next(true);
        this.center$.next(true);
      }
      static \u0275fac = function LearningPathGraphComponent_Factory(t) {
        return new (t || _LearningPathGraphComponent)(i08.\u0275\u0275directiveInject(LearningPathService));
      };
      static \u0275cmp = i08.\u0275\u0275defineComponent({ type: _LearningPathGraphComponent, selectors: [["jhi-learning-path-graph"]], inputs: { learningPathId: "learningPathId", courseId: "courseId", draggingEnabled: "draggingEnabled", panningEnabled: "panningEnabled", zoomEnabled: "zoomEnabled", panOnZoom: "panOnZoom", showMiniMap: "showMiniMap" }, outputs: { nodeClicked: "nodeClicked" }, decls: 6, vars: 2, consts: [[1, "graph-container"], [1, "legend", 3, "nodeTypes"], [3, "links", "nodes", "layout", "layoutSettings", "curve", "draggingEnabled", "panningEnabled", "enableZoom", "panOnZoom", "showMiniMap", "miniMapMaxWidth", "miniMapMaxHeight", "update$", "center$", "zoomToFit$"], ["defsTemplate", ""], ["nodeTemplate", ""], ["linkTemplate", ""], ["clusterTemplate", ""], ["id", "arrow", "viewBox", "0 -5 10 10", "refX", "8", "refY", "0", "markerWidth", "4", "markerHeight", "4", "orient", "auto"], ["d", "M0,-5L10,0L0,5", 1, "arrow-head"], [1, "node", 3, "id", "courseId", "node", "competencyProgressDTO", "click"], [1, "edge"], ["stroke-width", "2", "marker-end", "url(#arrow)", 1, "line"], [1, "node", "cluster"], ["rx", "5", "ry", "5"]], template: function LearningPathGraphComponent_Template(rf, ctx) {
        if (rf & 1) {
          i08.\u0275\u0275elementStart(0, "div", 0);
          i08.\u0275\u0275text(1, "\n    ");
          i08.\u0275\u0275template(2, LearningPathGraphComponent_Conditional_2_Template, 16, 16);
          i08.\u0275\u0275element(3, "jhi-learning-path-legend", 1);
          i08.\u0275\u0275text(4, "\n");
          i08.\u0275\u0275elementEnd();
          i08.\u0275\u0275text(5, "\n");
        }
        if (rf & 2) {
          i08.\u0275\u0275advance(2);
          i08.\u0275\u0275conditional(2, ctx.ngxLearningPath ? 2 : -1);
          i08.\u0275\u0275advance(1);
          i08.\u0275\u0275property("nodeTypes", ctx.nodeTypes);
        }
      }, dependencies: [i22.GraphComponent, LearningPathNodeComponent, LearningPathLegendComponent], styles: ["\n\n.graph-container[_ngcontent-%COMP%] {\n  display: flex;\n  width: 100%;\n  height: 100%;\n  overflow: hidden;\n}\n.graph-container[_ngcontent-%COMP%]   .node[_ngcontent-%COMP%] {\n  display: flex;\n  width: 100%;\n  height: 100%;\n}\n.graph-container[_ngcontent-%COMP%]   #arrow[_ngcontent-%COMP%] {\n  stroke: var(--body-color);\n  fill: var(--body-color);\n}\n.graph-container[_ngcontent-%COMP%]   .edge[_ngcontent-%COMP%] {\n  stroke: var(--body-color) !important;\n  marker-end: url(#arrow);\n}\n.graph-container[_ngcontent-%COMP%]   .floating-icon-button[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  padding: 0.25em;\n}\n.graph-container[_ngcontent-%COMP%]   .floating-icon-button[_ngcontent-%COMP%]:hover {\n  cursor: pointer;\n}\njhi-learning-path-graph-node[_ngcontent-%COMP%]:hover {\n  cursor: pointer;\n}\n.node-icon-container[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n}\n.node-icon-container[_ngcontent-%COMP%]   fa-icon[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n}\n[_nghost-%COMP%]  .graph-container .node-icon-container fa-icon svg {\n  margin: 10%;\n  width: 80%;\n  height: 80%;\n}\n.node-xs[_ngcontent-%COMP%] {\n  width: 40%;\n  margin: 30%;\n}\n.node-s[_ngcontent-%COMP%] {\n  width: 60%;\n  margin: 20%;\n}\n.completed[_ngcontent-%COMP%] {\n  color: var(--bs-success);\n}\n.current[_ngcontent-%COMP%] {\n  color: var(--bs-warning);\n}\n.node-details[_ngcontent-%COMP%] {\n  display: block;\n  max-width: 40vw;\n}\n.legend[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  bottom: 0;\n  margin-right: 0.5em;\n  margin-bottom: 0.5em;\n}\n.legend-wrapper[_ngcontent-%COMP%] {\n  background: var(--bs-body-bg);\n  border-radius: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC1ncmFwaC9sZWFybmluZy1wYXRoLWdyYXBoLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuZ3JhcGgtY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuXG4gICAgLm5vZGUge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgIH1cblxuICAgICNhcnJvdyB7XG4gICAgICAgIHN0cm9rZTogdmFyKC0tYm9keS1jb2xvcik7XG4gICAgICAgIGZpbGw6IHZhcigtLWJvZHktY29sb3IpO1xuICAgIH1cblxuICAgIC5lZGdlIHtcbiAgICAgICAgc3Ryb2tlOiB2YXIoLS1ib2R5LWNvbG9yKSAhaW1wb3J0YW50O1xuICAgICAgICBtYXJrZXItZW5kOiB1cmwoI2Fycm93KTtcbiAgICB9XG5cbiAgICAuZmxvYXRpbmctaWNvbi1idXR0b24ge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICBwYWRkaW5nOiAwLjI1ZW07XG4gICAgfVxuICAgIC5mbG9hdGluZy1pY29uLWJ1dHRvbjpob3ZlciB7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB9XG59XG5cbmpoaS1sZWFybmluZy1wYXRoLWdyYXBoLW5vZGU6aG92ZXIge1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLm5vZGUtaWNvbi1jb250YWluZXIge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGRpc3BsYXk6IGZsZXg7XG5cbiAgICBmYS1pY29uIHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgfVxufVxuXG46aG9zdDo6bmctZGVlcCAuZ3JhcGgtY29udGFpbmVyIC5ub2RlLWljb24tY29udGFpbmVyIGZhLWljb24gc3ZnIHtcbiAgICBtYXJnaW46IDEwJTtcbiAgICB3aWR0aDogODAlO1xuICAgIGhlaWdodDogODAlO1xufVxuXG4ubm9kZS14cyB7XG4gICAgd2lkdGg6IDQwJTtcbiAgICBtYXJnaW46IDMwJTtcbn1cblxuLm5vZGUtcyB7XG4gICAgd2lkdGg6IDYwJTtcbiAgICBtYXJnaW46IDIwJTtcbn1cblxuLmNvbXBsZXRlZCB7XG4gICAgY29sb3I6IHZhcigtLWJzLXN1Y2Nlc3MpO1xufVxuXG4uY3VycmVudCB7XG4gICAgY29sb3I6IHZhcigtLWJzLXdhcm5pbmcpO1xufVxuXG4ubm9kZS1kZXRhaWxzIHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXgtd2lkdGg6IDQwdnc7XG59XG5cbi5sZWdlbmQge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICByaWdodDogMDtcbiAgICBib3R0b206IDA7XG4gICAgbWFyZ2luLXJpZ2h0OiAwLjVlbTtcbiAgICBtYXJnaW4tYm90dG9tOiAwLjVlbTtcbn1cblxuLmxlZ2VuZC13cmFwcGVyIHtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1icy1ib2R5LWJnKTtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxTQUFBO0FBQ0EsVUFBQTtBQUNBLFlBQUE7O0FBRUEsQ0FOSixnQkFNSSxDQUFBO0FBQ0ksV0FBQTtBQUNBLFNBQUE7QUFDQSxVQUFBOztBQUdKLENBWkosZ0JBWUksQ0FBQTtBQUNJLFVBQUEsSUFBQTtBQUNBLFFBQUEsSUFBQTs7QUFHSixDQWpCSixnQkFpQkksQ0FBQTtBQUNJLFVBQUEsSUFBQTtBQUNBLGNBQUE7O0FBR0osQ0F0QkosZ0JBc0JJLENBQUE7QUFDSSxZQUFBO0FBQ0EsU0FBQTtBQUNBLFdBQUE7O0FBRUosQ0EzQkosZ0JBMkJJLENBTEEsb0JBS0E7QUFDSSxVQUFBOztBQUlSLDRCQUFBO0FBQ0ksVUFBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQTtBQUNBLFdBQUE7O0FBRUEsQ0FKSixvQkFJSTtBQUNJLFNBQUE7QUFDQSxXQUFBOztBQUlSLEtBQUEsVUFBQSxDQTlDQSxnQkE4Q0EsQ0FWQSxvQkFVQSxRQUFBO0FBQ0ksVUFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBOztBQUdKLENBQUE7QUFDSSxTQUFBO0FBQ0EsVUFBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQTtBQUNBLFVBQUE7O0FBR0osQ0FBQTtBQUNJLFNBQUEsSUFBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUdKLENBQUE7QUFDSSxXQUFBO0FBQ0EsYUFBQTs7QUFHSixDQUFBO0FBQ0ksWUFBQTtBQUNBLFNBQUE7QUFDQSxVQUFBO0FBQ0EsZ0JBQUE7QUFDQSxpQkFBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQSxJQUFBO0FBQ0EsaUJBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassDebugInfo(LearningPathGraphComponent, { className: "LearningPathGraphComponent" });
    })();
  }
});

// src/main/webapp/app/course/learning-paths/learning-path-graph/learning-path.component.ts
import { Component as Component7, EventEmitter as EventEmitter5, Input as Input7, Output as Output5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faChevronDown } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i09 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i34 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function LearningPathComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n    ");
    i09.\u0275\u0275elementStart(1, "div", 0);
    i09.\u0275\u0275text(2, "\n        ");
    i09.\u0275\u0275elementStart(3, "div", 1);
    i09.\u0275\u0275text(4, "\n            ");
    i09.\u0275\u0275elementStart(5, "span", 2);
    i09.\u0275\u0275text(6);
    i09.\u0275\u0275pipe(7, "artemisTranslate");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(8, "\n        ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(9, "\n    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(10, "\n");
  }
  if (rf & 2) {
    i09.\u0275\u0275advance(6);
    i09.\u0275\u0275textInterpolate(i09.\u0275\u0275pipeBind1(7, 1, "loading"));
  }
}
function LearningPathComponent_Conditional_1_For_4_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n                    ");
    i09.\u0275\u0275elementStart(1, "div", 5);
    i09.\u0275\u0275text(2, "\n                        ");
    i09.\u0275\u0275element(3, "fa-icon", 6);
    i09.\u0275\u0275text(4, "\n                    ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r8 = i09.\u0275\u0275nextContext(3);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("icon", ctx_r8.faChevronDown);
  }
}
function LearningPathComponent_Conditional_1_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = i09.\u0275\u0275getCurrentView();
    i09.\u0275\u0275text(0, "\n            ");
    i09.\u0275\u0275elementStart(1, "div");
    i09.\u0275\u0275text(2, "\n                ");
    i09.\u0275\u0275elementStart(3, "div", 3);
    i09.\u0275\u0275text(4, "\n                    ");
    i09.\u0275\u0275elementStart(5, "jhi-learning-path-graph-node", 4);
    i09.\u0275\u0275listener("click", function LearningPathComponent_Conditional_1_For_4_Template_jhi_learning_path_graph_node_click_5_listener() {
      const restoredCtx = i09.\u0275\u0275restoreView(_r10);
      const node_r3 = restoredCtx.$implicit;
      const ctx_r9 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r9.nodeClicked.emit(node_r3));
    });
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(6, "\n                ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(7, "\n                ");
    i09.\u0275\u0275template(8, LearningPathComponent_Conditional_1_For_4_Conditional_8_Template, 6, 1);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(9, "\n        ");
  }
  if (rf & 2) {
    const node_r3 = ctx.$implicit;
    const $index_r4 = ctx.$index;
    const $count_r6 = ctx.$count;
    const ctx_r2 = i09.\u0275\u0275nextContext(2);
    i09.\u0275\u0275advance(5);
    i09.\u0275\u0275classProp("highlighted-node", node_r3.id === (ctx_r2.highlightedNode == null ? null : ctx_r2.highlightedNode.id));
    i09.\u0275\u0275propertyInterpolate("id", node_r3.id);
    i09.\u0275\u0275property("courseId", ctx_r2.courseId)("node", node_r3);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275conditional(8, !($index_r4 === $count_r6 - 1) ? 8 : -1);
  }
}
function LearningPathComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, "\n    ");
    i09.\u0275\u0275elementStart(1, "div");
    i09.\u0275\u0275text(2, "\n        ");
    i09.\u0275\u0275repeaterCreate(3, LearningPathComponent_Conditional_1_For_4_Template, 10, 6, null, null, i09.\u0275\u0275repeaterTrackByIdentity);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275text(5, "\n");
  }
  if (rf & 2) {
    const ctx_r1 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275repeater(ctx_r1.path);
  }
}
var LearningPathComponent;
var init_learning_path_component = __esm({
  "src/main/webapp/app/course/learning-paths/learning-path-graph/learning-path.component.ts"() {
    init_learning_path_model();
    init_learning_path_service();
    init_learning_path_storage_service();
    init_learning_path_service();
    init_learning_path_storage_service();
    init_learning_path_node_component();
    init_artemis_translate_pipe();
    LearningPathComponent = class _LearningPathComponent {
      learningPathService;
      learningPathStorageService;
      learningPathId;
      courseId;
      nodeClicked = new EventEmitter5();
      isLoading = false;
      path = [];
      highlightedNode;
      faChevronDown = faChevronDown;
      getIcon = getIcon4;
      constructor(learningPathService, learningPathStorageService) {
        this.learningPathService = learningPathService;
        this.learningPathStorageService = learningPathStorageService;
      }
      ngOnInit() {
        this.loadData();
      }
      loadData() {
        if (!this.learningPathId) {
          return;
        }
        this.isLoading = true;
        this.learningPathService.getLearningPathNgxPath(this.learningPathId).subscribe((ngxLearningPathResponse) => {
          const body = ngxLearningPathResponse.body;
          this.learningPathStorageService.getRecommendations(this.learningPathId)?.forEach((entry) => {
            let node;
            if (entry instanceof LectureUnitEntry) {
              node = body.nodes.find((node2) => {
                return node2.linkedResource === entry.lectureUnitId && node2.linkedResourceParent === entry.lectureId;
              });
            } else if (entry instanceof ExerciseEntry) {
              node = body.nodes.find((node2) => {
                return node2.linkedResource === entry.exerciseId && !node2.linkedResourceParent;
              });
            }
            if (node) {
              this.path.push(node);
            }
          });
          this.isLoading = false;
        });
      }
      highlightNode(learningObject) {
        if (learningObject instanceof LectureUnitEntry) {
          this.highlightedNode = this.path.find((node) => {
            return node.linkedResource === learningObject.lectureUnitId && node.linkedResourceParent === learningObject.lectureId;
          });
        } else {
          this.highlightedNode = this.path.find((node) => {
            return node.linkedResource === learningObject.exerciseId && !node.linkedResourceParent;
          });
        }
      }
      clearHighlighting() {
        this.highlightedNode = void 0;
      }
      static \u0275fac = function LearningPathComponent_Factory(t) {
        return new (t || _LearningPathComponent)(i09.\u0275\u0275directiveInject(LearningPathService), i09.\u0275\u0275directiveInject(LearningPathStorageService));
      };
      static \u0275cmp = i09.\u0275\u0275defineComponent({ type: _LearningPathComponent, selectors: [["jhi-learning-path"]], inputs: { learningPathId: "learningPathId", courseId: "courseId" }, outputs: { nodeClicked: "nodeClicked" }, decls: 2, vars: 2, consts: [[1, "d-flex", "justify-content-center"], ["role", "status", 1, "spinner-border"], [1, "sr-only"], [1, "path-node"], [3, "id", "courseId", "node", "click"], [1, "path-edge"], [3, "icon"]], template: function LearningPathComponent_Template(rf, ctx) {
        if (rf & 1) {
          i09.\u0275\u0275template(0, LearningPathComponent_Conditional_0_Template, 11, 3)(1, LearningPathComponent_Conditional_1_Template, 6, 0);
        }
        if (rf & 2) {
          i09.\u0275\u0275conditional(0, ctx.isLoading ? 0 : -1);
          i09.\u0275\u0275advance(1);
          i09.\u0275\u0275conditional(1, !ctx.isLoading ? 1 : -1);
        }
      }, dependencies: [i34.FaIconComponent, LearningPathNodeComponent, ArtemisTranslatePipe], styles: ["\n\n.path-edge[_ngcontent-%COMP%] {\n  display: block;\n  text-align: center;\n}\n.path-edge[_ngcontent-%COMP%]   fa-icon[_ngcontent-%COMP%] {\n  font-size: 1em;\n}\n.path-node[_ngcontent-%COMP%]   jhi-learning-path-graph-node[_ngcontent-%COMP%] {\n  display: block;\n  width: fit-content;\n  font-size: 3em;\n  margin: auto;\n}\n.highlighted-node[_ngcontent-%COMP%] {\n  color: var(--bs-warning);\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC1ncmFwaC9sZWFybmluZy1wYXRoLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIucGF0aC1lZGdlIHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgICBmYS1pY29uIHtcbiAgICAgICAgZm9udC1zaXplOiAxZW07XG4gICAgfVxufVxuXG4ucGF0aC1ub2RlIHtcbiAgICBqaGktbGVhcm5pbmctcGF0aC1ncmFwaC1ub2RlIHtcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICAgIHdpZHRoOiBmaXQtY29udGVudDtcbiAgICAgICAgZm9udC1zaXplOiAzZW07XG4gICAgICAgIG1hcmdpbjogYXV0bztcbiAgICB9XG59XG5cbi5oaWdobGlnaHRlZC1ub2RlIHtcbiAgICBjb2xvcjogdmFyKC0tYnMtd2FybmluZyk7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxjQUFBOztBQUVBLENBSkosVUFJSTtBQUNJLGFBQUE7O0FBS0osQ0FBQSxVQUFBO0FBQ0ksV0FBQTtBQUNBLFNBQUE7QUFDQSxhQUFBO0FBQ0EsVUFBQTs7QUFJUixDQUFBO0FBQ0ksU0FBQSxJQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i09.\u0275setClassDebugInfo(LearningPathComponent, { className: "LearningPathComponent" });
    })();
  }
});

// src/main/webapp/app/course/learning-paths/learning-path-graph/learning-path-graph.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgxGraphModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@swimlane_ngx-graph.js?v=1d0d9ead";
import * as i010 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisLearningPathGraphModule;
var init_learning_path_graph_module = __esm({
  "src/main/webapp/app/course/learning-paths/learning-path-graph/learning-path-graph.module.ts"() {
    init_shared_module();
    init_learning_path_graph_component();
    init_learning_path_node_component();
    init_competency_node_details_component();
    init_exercise_node_details_component();
    init_lecture_unit_node_details_component();
    init_competency_module();
    init_learning_path_component();
    init_learning_path_legend_component();
    ArtemisLearningPathGraphModule = class _ArtemisLearningPathGraphModule {
      static \u0275fac = function ArtemisLearningPathGraphModule_Factory(t) {
        return new (t || _ArtemisLearningPathGraphModule)();
      };
      static \u0275mod = i010.\u0275\u0275defineNgModule({ type: _ArtemisLearningPathGraphModule });
      static \u0275inj = i010.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, NgxGraphModule, ArtemisCompetenciesModule] });
    };
  }
});

// src/main/webapp/app/course/learning-paths/progress-modal/learning-path-progress-nav.component.ts
import { Component as Component8, EventEmitter as EventEmitter6, Input as Input8, Output as Output6 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faArrowsRotate, faArrowsToEye, faXmark } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i011 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i14 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i23 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function LearningPathProgressNavComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275text(0, "\n            ");
    i011.\u0275\u0275elementStart(1, "h3");
    i011.\u0275\u0275text(2);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275text(3, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(2);
    i011.\u0275\u0275textInterpolate2("", ctx_r0.learningPath.user == null ? null : ctx_r0.learningPath.user.name, " (", ctx_r0.learningPath.user == null ? null : ctx_r0.learningPath.user.login, ")");
  }
}
var LearningPathProgressNavComponent;
var init_learning_path_progress_nav_component = __esm({
  "src/main/webapp/app/course/learning-paths/progress-modal/learning-path-progress-nav.component.ts"() {
    init_learning_path_model();
    init_artemis_translate_pipe();
    LearningPathProgressNavComponent = class _LearningPathProgressNavComponent {
      learningPath;
      onRefresh = new EventEmitter6();
      onCenterView = new EventEmitter6();
      onClose = new EventEmitter6();
      faXmark = faXmark;
      faArrowsToEye = faArrowsToEye;
      faArrowsRotate = faArrowsRotate;
      static \u0275fac = function LearningPathProgressNavComponent_Factory(t) {
        return new (t || _LearningPathProgressNavComponent)();
      };
      static \u0275cmp = i011.\u0275\u0275defineComponent({ type: _LearningPathProgressNavComponent, selectors: [["jhi-learning-path-progress-nav"]], inputs: { learningPath: "learningPath" }, outputs: { onRefresh: "onRefresh", onCenterView: "onCenterView", onClose: "onClose" }, decls: 28, vars: 13, consts: [[1, "row"], [1, "col"], [1, "col-auto"], ["id", "refresh-button", 1, "btn", "btn-primary", "m-1", 3, "click"], [3, "icon", "ngbTooltip"], ["id", "center-button", 1, "btn", "btn-primary", "m-1", 3, "click"], ["id", "close-button", 1, "btn", "btn-danger", "m-1", 3, "click"]], template: function LearningPathProgressNavComponent_Template(rf, ctx) {
        if (rf & 1) {
          i011.\u0275\u0275elementStart(0, "div", 0);
          i011.\u0275\u0275text(1, "\n    ");
          i011.\u0275\u0275elementStart(2, "div", 1);
          i011.\u0275\u0275text(3, "\n        ");
          i011.\u0275\u0275template(4, LearningPathProgressNavComponent_Conditional_4_Template, 4, 2);
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(5, "\n    ");
          i011.\u0275\u0275elementStart(6, "div", 2);
          i011.\u0275\u0275text(7, "\n        ");
          i011.\u0275\u0275elementStart(8, "button", 3);
          i011.\u0275\u0275listener("click", function LearningPathProgressNavComponent_Template_button_click_8_listener() {
            return ctx.onRefresh.emit();
          });
          i011.\u0275\u0275text(9, "\n            ");
          i011.\u0275\u0275element(10, "fa-icon", 4);
          i011.\u0275\u0275pipe(11, "artemisTranslate");
          i011.\u0275\u0275text(12, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(13, "\n        ");
          i011.\u0275\u0275elementStart(14, "button", 5);
          i011.\u0275\u0275listener("click", function LearningPathProgressNavComponent_Template_button_click_14_listener() {
            return ctx.onCenterView.emit();
          });
          i011.\u0275\u0275text(15, "\n            ");
          i011.\u0275\u0275element(16, "fa-icon", 4);
          i011.\u0275\u0275pipe(17, "artemisTranslate");
          i011.\u0275\u0275text(18, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(19, "\n        ");
          i011.\u0275\u0275elementStart(20, "button", 6);
          i011.\u0275\u0275listener("click", function LearningPathProgressNavComponent_Template_button_click_20_listener() {
            return ctx.onClose.emit();
          });
          i011.\u0275\u0275text(21, "\n            ");
          i011.\u0275\u0275element(22, "fa-icon", 4);
          i011.\u0275\u0275pipe(23, "artemisTranslate");
          i011.\u0275\u0275text(24, "\n        ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(25, "\n    ");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(26, "\n");
          i011.\u0275\u0275elementEnd();
          i011.\u0275\u0275text(27, "\n");
        }
        if (rf & 2) {
          i011.\u0275\u0275advance(4);
          i011.\u0275\u0275conditional(4, ctx.learningPath ? 4 : -1);
          i011.\u0275\u0275advance(6);
          i011.\u0275\u0275propertyInterpolate("ngbTooltip", i011.\u0275\u0275pipeBind1(11, 7, "artemisApp.learningPath.graph.progressNav.refresh"));
          i011.\u0275\u0275property("icon", ctx.faArrowsRotate);
          i011.\u0275\u0275advance(6);
          i011.\u0275\u0275propertyInterpolate("ngbTooltip", i011.\u0275\u0275pipeBind1(17, 9, "artemisApp.learningPath.graph.progressNav.center"));
          i011.\u0275\u0275property("icon", ctx.faArrowsToEye);
          i011.\u0275\u0275advance(6);
          i011.\u0275\u0275propertyInterpolate("ngbTooltip", i011.\u0275\u0275pipeBind1(23, 11, "entity.action.close"));
          i011.\u0275\u0275property("icon", ctx.faXmark);
        }
      }, dependencies: [i14.NgbTooltip, i23.FaIconComponent, ArtemisTranslatePipe], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i011.\u0275setClassDebugInfo(LearningPathProgressNavComponent, { className: "LearningPathProgressNavComponent" });
    })();
  }
});

// src/main/webapp/app/course/learning-paths/progress-modal/learning-path-progress-modal.component.ts
import { Component as Component9, Input as Input9, ViewChild } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { NgbActiveModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i012 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i15 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i24 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function LearningPathProgressModalComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275text(0, "\n            ");
    i012.\u0275\u0275elementStart(1, "jhi-learning-path-graph", 4, 5);
    i012.\u0275\u0275listener("nodeClicked", function LearningPathProgressModalComponent_Conditional_9_Template_jhi_learning_path_graph_nodeClicked_1_listener($event) {
      i012.\u0275\u0275restoreView(_r3);
      const ctx_r2 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r2.onNodeClicked($event));
    });
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275text(3, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(1);
    i012.\u0275\u0275property("courseId", ctx_r0.courseId)("learningPathId", ctx_r0.learningPath.id)("panningEnabled", true)("zoomEnabled", true)("panOnZoom", true)("showMiniMap", true);
  }
}
var _c02, LearningPathProgressModalComponent;
var init_learning_path_progress_modal_component = __esm({
  "src/main/webapp/app/course/learning-paths/progress-modal/learning-path-progress-modal.component.ts"() {
    init_learning_path_graph_component();
    init_learning_path_model();
    init_learning_path_graph_component();
    init_learning_path_progress_nav_component();
    _c02 = ["learningPathGraphComponent"];
    LearningPathProgressModalComponent = class _LearningPathProgressModalComponent {
      activeModal;
      router;
      courseId;
      learningPath;
      learningPathGraphComponent;
      constructor(activeModal, router) {
        this.activeModal = activeModal;
        this.router = router;
      }
      close() {
        this.activeModal.close();
      }
      onNodeClicked(node) {
        if (node.type === NodeType.COMPETENCY_START || node.type === NodeType.COMPETENCY_END) {
          this.navigateToCompetency(node);
        }
      }
      navigateToCompetency(node) {
        this.router.navigate(["courses", this.courseId, "competencies", node.linkedResource]);
        this.close();
      }
      static \u0275fac = function LearningPathProgressModalComponent_Factory(t) {
        return new (t || _LearningPathProgressModalComponent)(i012.\u0275\u0275directiveInject(i15.NgbActiveModal), i012.\u0275\u0275directiveInject(i24.Router));
      };
      static \u0275cmp = i012.\u0275\u0275defineComponent({ type: _LearningPathProgressModalComponent, selectors: [["jhi-learning-path-progress-modal"]], viewQuery: function LearningPathProgressModalComponent_Query(rf, ctx) {
        if (rf & 1) {
          i012.\u0275\u0275viewQuery(_c02, 5);
        }
        if (rf & 2) {
          let _t;
          i012.\u0275\u0275queryRefresh(_t = i012.\u0275\u0275loadQuery()) && (ctx.learningPathGraphComponent = _t.first);
        }
      }, inputs: { courseId: "courseId", learningPath: "learningPath" }, decls: 12, vars: 2, consts: [[1, "modal-container"], [1, "row", "modal-nav"], [3, "learningPath", "onRefresh", "onCenterView", "onClose"], [1, "row"], [1, "graph", 3, "courseId", "learningPathId", "panningEnabled", "zoomEnabled", "panOnZoom", "showMiniMap", "nodeClicked"], ["learningPathGraphComponent", ""]], template: function LearningPathProgressModalComponent_Template(rf, ctx) {
        if (rf & 1) {
          i012.\u0275\u0275elementStart(0, "div", 0);
          i012.\u0275\u0275text(1, "\n    ");
          i012.\u0275\u0275elementStart(2, "div", 1);
          i012.\u0275\u0275text(3, "\n        ");
          i012.\u0275\u0275elementStart(4, "jhi-learning-path-progress-nav", 2);
          i012.\u0275\u0275listener("onRefresh", function LearningPathProgressModalComponent_Template_jhi_learning_path_progress_nav_onRefresh_4_listener() {
            ctx.learningPathGraphComponent.refreshData();
            return ctx.learningPathGraphComponent.onCenterView();
          })("onCenterView", function LearningPathProgressModalComponent_Template_jhi_learning_path_progress_nav_onCenterView_4_listener() {
            return ctx.learningPathGraphComponent.onCenterView();
          })("onClose", function LearningPathProgressModalComponent_Template_jhi_learning_path_progress_nav_onClose_4_listener() {
            return ctx.close();
          });
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(5, "\n    ");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(6, "\n    ");
          i012.\u0275\u0275elementStart(7, "div", 3);
          i012.\u0275\u0275text(8, "\n        ");
          i012.\u0275\u0275template(9, LearningPathProgressModalComponent_Conditional_9_Template, 4, 6);
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(10, "\n");
          i012.\u0275\u0275elementEnd();
          i012.\u0275\u0275text(11, "\n");
        }
        if (rf & 2) {
          i012.\u0275\u0275advance(4);
          i012.\u0275\u0275property("learningPath", ctx.learningPath);
          i012.\u0275\u0275advance(5);
          i012.\u0275\u0275conditional(9, ctx.courseId && ctx.learningPath ? 9 : -1);
        }
      }, dependencies: [LearningPathGraphComponent, LearningPathProgressNavComponent], styles: ["\n\n.modal-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  height: 90vh;\n  width: 100%;\n  padding-top: 8px;\n}\n.modal-container[_ngcontent-%COMP%]   .row[_ngcontent-%COMP%] {\n  width: 100%;\n  margin-left: 0;\n  margin-right: 0;\n}\n.modal-container[_ngcontent-%COMP%]   .modal-nav[_ngcontent-%COMP%] {\n  height: max-content;\n}\n.modal-container[_ngcontent-%COMP%]   .graph[_ngcontent-%COMP%] {\n  width: 100%;\n  overflow: hidden;\n}\n.learning-path-modal[_ngcontent-%COMP%]   .modal-dialog[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  min-height: 500px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvcHJvZ3Jlc3MtbW9kYWwvbGVhcm5pbmctcGF0aC1wcm9ncmVzcy1tb2RhbC5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLm1vZGFsLWNvbnRhaW5lciB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LXdyYXA6IHdyYXA7XG4gICAgaGVpZ2h0OiA5MHZoO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHBhZGRpbmctdG9wOiA4cHg7XG5cbiAgICAucm93IHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAwO1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDA7XG4gICAgfVxuXG4gICAgLm1vZGFsLW5hdiB7XG4gICAgICAgIGhlaWdodDogbWF4LWNvbnRlbnQ7XG4gICAgfVxuXG4gICAgLmdyYXBoIHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgfVxufVxuXG4ubGVhcm5pbmctcGF0aC1tb2RhbCAubW9kYWwtZGlhbG9nIC5tb2RhbC1jb250ZW50IHtcbiAgICBtaW4taGVpZ2h0OiA1MDBweDtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksV0FBQTtBQUNBLGFBQUE7QUFDQSxVQUFBO0FBQ0EsU0FBQTtBQUNBLGVBQUE7O0FBRUEsQ0FQSixnQkFPSSxDQUFBO0FBQ0ksU0FBQTtBQUNBLGVBQUE7QUFDQSxnQkFBQTs7QUFHSixDQWJKLGdCQWFJLENBQUE7QUFDSSxVQUFBOztBQUdKLENBakJKLGdCQWlCSSxDQUFBO0FBQ0ksU0FBQTtBQUNBLFlBQUE7O0FBSVIsQ0FBQSxvQkFBQSxDQUFBLGFBQUEsQ0FBQTtBQUNJLGNBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i012.\u0275setClassDebugInfo(LearningPathProgressModalComponent, { className: "LearningPathProgressModalComponent" });
    })();
  }
});

// src/main/webapp/app/course/learning-paths/progress-modal/learning-path-progress.module.ts
import { NgModule as NgModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i013 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisLearningPathProgressModule;
var init_learning_path_progress_module = __esm({
  "src/main/webapp/app/course/learning-paths/progress-modal/learning-path-progress.module.ts"() {
    init_shared_module();
    init_learning_path_progress_nav_component();
    init_learning_path_progress_modal_component();
    init_learning_path_graph_module();
    ArtemisLearningPathProgressModule = class _ArtemisLearningPathProgressModule {
      static \u0275fac = function ArtemisLearningPathProgressModule_Factory(t) {
        return new (t || _ArtemisLearningPathProgressModule)();
      };
      static \u0275mod = i013.\u0275\u0275defineNgModule({ type: _ArtemisLearningPathProgressModule });
      static \u0275inj = i013.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, ArtemisLearningPathGraphModule] });
    };
  }
});

export {
  NodeType,
  init_learning_path_model,
  LearningPathStorageService,
  LectureUnitEntry,
  ExerciseEntry,
  init_learning_path_storage_service,
  LearningPathService,
  init_learning_path_service,
  LearningPathComponent,
  init_learning_path_component,
  LearningPathProgressModalComponent,
  init_learning_path_progress_modal_component,
  ArtemisLearningPathGraphModule,
  init_learning_path_graph_module,
  ArtemisLearningPathProgressModule,
  init_learning_path_progress_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvY29tcGV0ZW5jeS9sZWFybmluZy1wYXRoLm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvcGFydGljaXBhdGUvbGVhcm5pbmctcGF0aC1zdG9yYWdlLnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9sZWFybmluZy1wYXRocy9sZWFybmluZy1wYXRoLnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9sZWFybmluZy1wYXRocy9sZWFybmluZy1wYXRoLWdyYXBoL25vZGUtZGV0YWlscy9jb21wZXRlbmN5LW5vZGUtZGV0YWlscy5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9sZWFybmluZy1wYXRocy9sZWFybmluZy1wYXRoLWdyYXBoL25vZGUtZGV0YWlscy9jb21wZXRlbmN5LW5vZGUtZGV0YWlscy5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL2xlYXJuaW5nLXBhdGhzL2xlYXJuaW5nLXBhdGgtZ3JhcGgvbm9kZS1kZXRhaWxzL2V4ZXJjaXNlLW5vZGUtZGV0YWlscy5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9sZWFybmluZy1wYXRocy9sZWFybmluZy1wYXRoLWdyYXBoL25vZGUtZGV0YWlscy9leGVyY2lzZS1ub2RlLWRldGFpbHMuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9sZWFybmluZy1wYXRocy9sZWFybmluZy1wYXRoLWdyYXBoL25vZGUtZGV0YWlscy9sZWN0dXJlLXVuaXQtbm9kZS1kZXRhaWxzLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL2xlYXJuaW5nLXBhdGhzL2xlYXJuaW5nLXBhdGgtZ3JhcGgvbm9kZS1kZXRhaWxzL2xlY3R1cmUtdW5pdC1ub2RlLWRldGFpbHMuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9sZWFybmluZy1wYXRocy9sZWFybmluZy1wYXRoLWdyYXBoL2xlYXJuaW5nLXBhdGgtbm9kZS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9sZWFybmluZy1wYXRocy9sZWFybmluZy1wYXRoLWdyYXBoL2xlYXJuaW5nLXBhdGgtbm9kZS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL2xlYXJuaW5nLXBhdGhzL2xlYXJuaW5nLXBhdGgtZ3JhcGgvbGVhcm5pbmctcGF0aC1sZWdlbmQuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC1ncmFwaC9sZWFybmluZy1wYXRoLWxlZ2VuZC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL2xlYXJuaW5nLXBhdGhzL2xlYXJuaW5nLXBhdGgtZ3JhcGgvbGVhcm5pbmctcGF0aC1ncmFwaC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9sZWFybmluZy1wYXRocy9sZWFybmluZy1wYXRoLWdyYXBoL2xlYXJuaW5nLXBhdGgtZ3JhcGguY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9sZWFybmluZy1wYXRocy9sZWFybmluZy1wYXRoLWdyYXBoL2xlYXJuaW5nLXBhdGguY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC1ncmFwaC9sZWFybmluZy1wYXRoLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC1ncmFwaC9sZWFybmluZy1wYXRoLWdyYXBoLm1vZHVsZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL2xlYXJuaW5nLXBhdGhzL3Byb2dyZXNzLW1vZGFsL2xlYXJuaW5nLXBhdGgtcHJvZ3Jlc3MtbmF2LmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL2xlYXJuaW5nLXBhdGhzL3Byb2dyZXNzLW1vZGFsL2xlYXJuaW5nLXBhdGgtcHJvZ3Jlc3MtbmF2LmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvcHJvZ3Jlc3MtbW9kYWwvbGVhcm5pbmctcGF0aC1wcm9ncmVzcy1tb2RhbC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS9sZWFybmluZy1wYXRocy9wcm9ncmVzcy1tb2RhbC9sZWFybmluZy1wYXRoLXByb2dyZXNzLW1vZGFsLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvcHJvZ3Jlc3MtbW9kYWwvbGVhcm5pbmctcGF0aC1wcm9ncmVzcy5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQmFzZUVudGl0eSB9IGZyb20gJ2FwcC9zaGFyZWQvbW9kZWwvYmFzZS1lbnRpdHknO1xuaW1wb3J0IHsgQ291cnNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvdXJzZS5tb2RlbCc7XG5pbXBvcnQgeyBVc2VyLCBVc2VyTmFtZUFuZExvZ2luRFRPIH0gZnJvbSAnYXBwL2NvcmUvdXNlci91c2VyLm1vZGVsJztcbmltcG9ydCB7IENvbXBldGVuY3kgfSBmcm9tICdhcHAvZW50aXRpZXMvY29tcGV0ZW5jeS5tb2RlbCc7XG5pbXBvcnQgeyBFZGdlLCBOb2RlLCBOb2RlRGltZW5zaW9uIH0gZnJvbSAnQHN3aW1sYW5lL25neC1ncmFwaCc7XG5pbXBvcnQgeyBmYUNoZWNrQ2lyY2xlLCBmYUNpcmNsZSwgZmFGbGFnLCBmYUZsYWdDaGVja2VyZWQsIGZhUGxheUNpcmNsZSwgZmFTaWduc1Bvc3QgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuXG5leHBvcnQgY2xhc3MgTGVhcm5pbmdQYXRoIGltcGxlbWVudHMgQmFzZUVudGl0eSB7XG4gICAgcHVibGljIGlkPzogbnVtYmVyO1xuICAgIHB1YmxpYyBwcm9ncmVzcz86IG51bWJlcjtcbiAgICBwdWJsaWMgdXNlcj86IFVzZXI7XG4gICAgcHVibGljIGNvdXJzZT86IENvdXJzZTtcbiAgICBwdWJsaWMgY29tcGV0ZW5jaWVzPzogQ29tcGV0ZW5jeVtdO1xuXG4gICAgY29uc3RydWN0b3IoKSB7fVxufVxuXG5leHBvcnQgY2xhc3MgTGVhcm5pbmdQYXRoSW5mb3JtYXRpb25EVE8ge1xuICAgIHB1YmxpYyBpZD86IG51bWJlcjtcbiAgICBwdWJsaWMgdXNlcj86IFVzZXJOYW1lQW5kTG9naW5EVE87XG4gICAgcHVibGljIHByb2dyZXNzPzogbnVtYmVyO1xufVxuXG5leHBvcnQgY2xhc3MgTmd4TGVhcm5pbmdQYXRoRFRPIHtcbiAgICBwdWJsaWMgbm9kZXM6IE5neExlYXJuaW5nUGF0aE5vZGVbXTtcbiAgICBwdWJsaWMgZWRnZXM6IE5neExlYXJuaW5nUGF0aEVkZ2VbXTtcbn1cblxuZXhwb3J0IGNsYXNzIE5neExlYXJuaW5nUGF0aE5vZGUgaW1wbGVtZW50cyBOb2RlIHtcbiAgICBwdWJsaWMgaWQ6IHN0cmluZztcbiAgICBwdWJsaWMgdHlwZT86IE5vZGVUeXBlO1xuICAgIHB1YmxpYyBsaW5rZWRSZXNvdXJjZT86IG51bWJlcjtcbiAgICBwdWJsaWMgbGlua2VkUmVzb3VyY2VQYXJlbnQ/OiBudW1iZXI7XG4gICAgcHVibGljIGNvbXBsZXRlZD86IGJvb2xlYW47XG4gICAgcHVibGljIGxhYmVsPzogc3RyaW5nO1xuICAgIGRpbWVuc2lvbj86IE5vZGVEaW1lbnNpb247XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRJY29uKG5vZGU6IE5neExlYXJuaW5nUGF0aE5vZGUpIHtcbiAgICAvLyByZXR1cm4gZ2VuZXJpYyBpY29uIGlmIG5vIHR5cGUgcHJlc2VudFxuICAgIGlmICghbm9kZS50eXBlKSB7XG4gICAgICAgIHJldHVybiBmYUNpcmNsZTtcbiAgICB9XG5cbiAgICAvLyByZXR1cm4gZGlmZmVyZW50IGljb25zIGZvciBjb21wbGV0ZWQgbGVhcm5pbmcgb2JqZWN0c1xuICAgIGlmIChub2RlLnR5cGUgPT09IE5vZGVUeXBlLkVYRVJDSVNFIHx8IG5vZGUudHlwZSA9PT0gTm9kZVR5cGUuTEVDVFVSRV9VTklUKSB7XG4gICAgICAgIGlmIChub2RlLmNvbXBsZXRlZCkge1xuICAgICAgICAgICAgcmV0dXJuIGZhQ2hlY2tDaXJjbGU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gZmFQbGF5Q2lyY2xlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgaWNvbnMgPSB7XG4gICAgICAgIFtOb2RlVHlwZS5DT01QRVRFTkNZX1NUQVJUXTogZmFGbGFnLFxuICAgICAgICBbTm9kZVR5cGUuQ09NUEVURU5DWV9FTkRdOiBmYUZsYWdDaGVja2VyZWQsXG4gICAgICAgIFtOb2RlVHlwZS5NQVRDSF9TVEFSVF06IGZhU2lnbnNQb3N0LFxuICAgICAgICBbTm9kZVR5cGUuTUFUQ0hfRU5EXTogZmFDaXJjbGUsXG4gICAgfTtcbiAgICByZXR1cm4gaWNvbnNbbm9kZS50eXBlXTtcbn1cblxuZXhwb3J0IGNsYXNzIE5neExlYXJuaW5nUGF0aEVkZ2UgaW1wbGVtZW50cyBFZGdlIHtcbiAgICBwdWJsaWMgaWQ/OiBzdHJpbmc7XG4gICAgcHVibGljIHNvdXJjZTogc3RyaW5nO1xuICAgIHB1YmxpYyB0YXJnZXQ6IHN0cmluZztcbn1cblxuZXhwb3J0IGVudW0gTm9kZVR5cGUge1xuICAgIENPTVBFVEVOQ1lfU1RBUlQgPSAnQ09NUEVURU5DWV9TVEFSVCcsXG4gICAgQ09NUEVURU5DWV9FTkQgPSAnQ09NUEVURU5DWV9FTkQnLFxuICAgIE1BVENIX1NUQVJUID0gJ01BVENIX1NUQVJUJyxcbiAgICBNQVRDSF9FTkQgPSAnTUFUQ0hfRU5EJyxcbiAgICBFWEVSQ0lTRSA9ICdFWEVSQ0lTRScsXG4gICAgTEVDVFVSRV9VTklUID0gJ0xFQ1RVUkVfVU5JVCcsXG59XG5cbmV4cG9ydCBjbGFzcyBDb21wZXRlbmN5UHJvZ3Jlc3NGb3JMZWFybmluZ1BhdGhEVE8ge1xuICAgIHB1YmxpYyBjb21wZXRlbmN5SWQ/OiBudW1iZXI7XG4gICAgcHVibGljIG1hc3RlcnlUaHJlc2hvbGQ/OiBudW1iZXI7XG4gICAgcHVibGljIHByb2dyZXNzPzogbnVtYmVyO1xuICAgIHB1YmxpYyBjb25maWRlbmNlPzogbnVtYmVyO1xufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmd4TGVhcm5pbmdQYXRoRFRPLCBOb2RlVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb21wZXRlbmN5L2xlYXJuaW5nLXBhdGgubW9kZWwnO1xuXG4vKipcbiAqIFRoaXMgc2VydmljZSBpcyB1c2VkIHRvIHN0b3JlIHRoZSByZWNvbW1lbmRhdGlvbnMgb2YgbGVhcm5pbmcgcGF0aCBwYXJ0aWNpcGF0aW9uIGZvciB0aGUgY3VycmVudGx5IGxvZ2dlZC1pbiB1c2VyLlxuICovXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIExlYXJuaW5nUGF0aFN0b3JhZ2VTZXJ2aWNlIHtcbiAgICBwcml2YXRlIHJlYWRvbmx5IGxlYXJuaW5nUGF0aFJlY29tbWVuZGF0aW9uczogTWFwPG51bWJlciwgU3RvcmFnZUVudHJ5W10+ID0gbmV3IE1hcCgpO1xuXG4gICAgLyoqXG4gICAgICogU2ltcGxpZmllcyBhbmQgc3RvcmVzIHRoZSByZWNvbW1lbmRlZCBvcmRlciBvZiBsZWFybmluZyBvYmplY3RzIGZvciB0aGUgZ2l2ZW4gbGVhcm5pbmcgcGF0aFxuICAgICAqXG4gICAgICogQHBhcmFtIGxlYXJuaW5nUGF0aElkIHRoZSBpZCBvZiB0aGUgbGVhcm5pbmcgcGF0aFxuICAgICAqIEBwYXJhbSBsZWFybmluZ1BhdGggdGhlIGxlYXJuaW5nIHBhdGggZHRvIHRoYXQgc2hvdWxkIGJlIHN0b3JlZFxuICAgICAqL1xuICAgIHN0b3JlUmVjb21tZW5kYXRpb25zKGxlYXJuaW5nUGF0aElkOiBudW1iZXIsIGxlYXJuaW5nUGF0aDogTmd4TGVhcm5pbmdQYXRoRFRPKSB7XG4gICAgICAgIHRoaXMubGVhcm5pbmdQYXRoUmVjb21tZW5kYXRpb25zLnNldChsZWFybmluZ1BhdGhJZCwgW10pO1xuICAgICAgICBsZXQgY3VycmVudElkID0gbGVhcm5pbmdQYXRoLm5vZGVzLm1hcCgobm9kZSkgPT4gbm9kZS5pZCkuZmluZCgoaWQpID0+ICFsZWFybmluZ1BhdGguZWRnZXMuZmluZCgoZWRnZSkgPT4gZWRnZS50YXJnZXQgPT0gaWQpKTtcbiAgICAgICAgd2hpbGUgKGN1cnJlbnRJZCkge1xuICAgICAgICAgICAgY29uc3QgY3VycmVudE5vZGUgPSBsZWFybmluZ1BhdGgubm9kZXMuZmluZCgobm9kZSkgPT4gbm9kZS5pZCA9PSBjdXJyZW50SWQpITtcbiAgICAgICAgICAgIGlmIChjdXJyZW50Tm9kZS50eXBlID09PSBOb2RlVHlwZS5MRUNUVVJFX1VOSVQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmxlYXJuaW5nUGF0aFJlY29tbWVuZGF0aW9ucy5nZXQobGVhcm5pbmdQYXRoSWQpIS5wdXNoKG5ldyBMZWN0dXJlVW5pdEVudHJ5KGN1cnJlbnROb2RlLmxpbmtlZFJlc291cmNlUGFyZW50ISwgY3VycmVudE5vZGUubGlua2VkUmVzb3VyY2UhKSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGN1cnJlbnROb2RlLnR5cGUgPT09IE5vZGVUeXBlLkVYRVJDSVNFKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sZWFybmluZ1BhdGhSZWNvbW1lbmRhdGlvbnMuZ2V0KGxlYXJuaW5nUGF0aElkKSEucHVzaChuZXcgRXhlcmNpc2VFbnRyeShjdXJyZW50Tm9kZS5saW5rZWRSZXNvdXJjZSEpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGVkZ2UgPSBsZWFybmluZ1BhdGguZWRnZXMuZmluZCgoZWRnZSkgPT4gZWRnZS5zb3VyY2UgPT0gY3VycmVudElkKTtcbiAgICAgICAgICAgIGlmIChlZGdlKSB7XG4gICAgICAgICAgICAgICAgY3VycmVudElkID0gZWRnZS50YXJnZXQ7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGN1cnJlbnRJZCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldHMgYWxsIHJlY29tbWVuZGF0aW9ucyBvZiB0aGUgbGVhcm5pbmcgcGF0aCBpbiByZWNvbW1lbmRlZCBvcmRlclxuICAgICAqXG4gICAgICogQHBhcmFtIGxlYXJuaW5nUGF0aElkIHRoZSBpZCBvZiB0aGUgbGVhcm5pbmcgcGF0aFxuICAgICAqL1xuICAgIGdldFJlY29tbWVuZGF0aW9ucyhsZWFybmluZ1BhdGhJZDogbnVtYmVyKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmxlYXJuaW5nUGF0aFJlY29tbWVuZGF0aW9ucy5nZXQobGVhcm5pbmdQYXRoSWQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldHMgaWYgdGhlIGdpdmVuIGxlYXJuaW5nIG9iamVjdCBoYXMgYSBzdWNjZXNzb3IuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbGVhcm5pbmdQYXRoSWQgdGhlIGlkIG9mIHRoZSBsZWFybmluZyBwYXRoXG4gICAgICogQHBhcmFtIGVudHJ5IHRoZSBlbnRyeSBmb3Igd2hpY2ggdGhlIHN1Y2Nlc3NvciBzaG91bGQgYmUgY2hlY2tlZFxuICAgICAqL1xuICAgIGhhc05leHRSZWNvbW1lbmRhdGlvbihsZWFybmluZ1BhdGhJZDogbnVtYmVyLCBlbnRyeT86IFN0b3JhZ2VFbnRyeSk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAoIXRoaXMubGVhcm5pbmdQYXRoUmVjb21tZW5kYXRpb25zLmhhcyhsZWFybmluZ1BhdGhJZCkpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWVudHJ5KSB7XG4gICAgICAgICAgICByZXR1cm4gISF0aGlzLmxlYXJuaW5nUGF0aFJlY29tbWVuZGF0aW9ucy5nZXQobGVhcm5pbmdQYXRoSWQpPy5sZW5ndGg7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgaW5kZXggPSB0aGlzLmdldEluZGV4T2YobGVhcm5pbmdQYXRoSWQsIGVudHJ5KTtcbiAgICAgICAgcmV0dXJuIDAgPD0gaW5kZXggJiYgaW5kZXggKyAxIDwgdGhpcy5sZWFybmluZ1BhdGhSZWNvbW1lbmRhdGlvbnMuZ2V0KGxlYXJuaW5nUGF0aElkKSEubGVuZ3RoO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldHMgdGhlIG5leHQgcmVjb21tZW5kZWQgZW50cnkgZm9yIGEgbGVhcm5pbmcgb2JqZWN0LlxuICAgICAqIDxwPlxuICAgICAqIEZpcnN0IGVudHJ5LCBpZiBnaXZlbiBlbnRyeSB1bmRlZmluZWQuXG4gICAgICogVW5kZWZpbmVkIGlmIHRoZSBjdXJyZW50IGVudHJ5IGhhcyBubyBzdWNjZXNzb3IuXG4gICAgICogQHBhcmFtIGxlYXJuaW5nUGF0aElkIHRoZSBpZCBvZiB0aGUgbGVhcm5pbmcgcGF0aFxuICAgICAqIEBwYXJhbSBlbnRyeSB0aGUgZW50cnkgZm9yIHdoaWNoIHRoZSBzdWNjZXNzb3Igc2hvdWxkIGJlIHJldHVybmVkXG4gICAgICovXG4gICAgZ2V0TmV4dFJlY29tbWVuZGF0aW9uKGxlYXJuaW5nUGF0aElkOiBudW1iZXIsIGVudHJ5PzogU3RvcmFnZUVudHJ5KTogU3RvcmFnZUVudHJ5IHwgdW5kZWZpbmVkIHtcbiAgICAgICAgaWYgKCF0aGlzLmhhc05leHRSZWNvbW1lbmRhdGlvbihsZWFybmluZ1BhdGhJZCwgZW50cnkpKSB7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZW50cnkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmxlYXJuaW5nUGF0aFJlY29tbWVuZGF0aW9ucy5nZXQobGVhcm5pbmdQYXRoSWQpIVswXTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBuZXh0SW5kZXggPSB0aGlzLmdldEluZGV4T2YobGVhcm5pbmdQYXRoSWQsIGVudHJ5KSArIDE7XG4gICAgICAgIHJldHVybiB0aGlzLmxlYXJuaW5nUGF0aFJlY29tbWVuZGF0aW9ucy5nZXQobGVhcm5pbmdQYXRoSWQpIVtuZXh0SW5kZXhdO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldHMgaWYgdGhlIGdpdmVuIGxlYXJuaW5nIG9iamVjdCBoYXMgYSBwcmVkZWNlc3Nvci5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBsZWFybmluZ1BhdGhJZCB0aGUgaWQgb2YgdGhlIGxlYXJuaW5nIHBhdGhcbiAgICAgKiBAcGFyYW0gZW50cnkgdGhlIGVudHJ5IGZvciB3aGljaCB0aGUgcHJlZGVjZXNzb3Igc2hvdWxkIGJlIGNoZWNrZWRcbiAgICAgKi9cbiAgICBoYXNQcmV2UmVjb21tZW5kYXRpb24obGVhcm5pbmdQYXRoSWQ6IG51bWJlciwgZW50cnk/OiBTdG9yYWdlRW50cnkpOiBib29sZWFuIHtcbiAgICAgICAgaWYgKCF0aGlzLmxlYXJuaW5nUGF0aFJlY29tbWVuZGF0aW9ucy5oYXMobGVhcm5pbmdQYXRoSWQpIHx8ICFlbnRyeSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAwIDwgdGhpcy5nZXRJbmRleE9mKGxlYXJuaW5nUGF0aElkLCBlbnRyeSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0cyB0aGUgcHJpb3IgcmVjb21tZW5kZWQgZW50cnkgZm9yIGEgbGVhcm5pbmcgb2JqZWN0LlxuICAgICAqIDxwPlxuICAgICAqIFVuZGVmaW5lZCBpZiB0aGUgY3VycmVudCBlbnRyeSBoYXMgbm8gcHJlZGVjZXNzb3IuXG4gICAgICogQHBhcmFtIGxlYXJuaW5nUGF0aElkIHRoZSBpZCBvZiB0aGUgbGVhcm5pbmcgcGF0aFxuICAgICAqIEBwYXJhbSBlbnRyeSB0aGUgZW50cnkgZm9yIHdoaWNoIHRoZSBwcmVkZWNlc3NvciBzaG91bGQgYmUgcmV0dXJuZWRcbiAgICAgKi9cbiAgICBnZXRQcmV2UmVjb21tZW5kYXRpb24obGVhcm5pbmdQYXRoSWQ6IG51bWJlciwgZW50cnk/OiBTdG9yYWdlRW50cnkpOiBTdG9yYWdlRW50cnkgfCB1bmRlZmluZWQge1xuICAgICAgICBpZiAoIXRoaXMuaGFzUHJldlJlY29tbWVuZGF0aW9uKGxlYXJuaW5nUGF0aElkLCBlbnRyeSkpIHtcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcHJldkluZGV4ID0gdGhpcy5nZXRJbmRleE9mKGxlYXJuaW5nUGF0aElkLCBlbnRyeSEpIC0gMTtcbiAgICAgICAgcmV0dXJuIHRoaXMubGVhcm5pbmdQYXRoUmVjb21tZW5kYXRpb25zLmdldChsZWFybmluZ1BhdGhJZCkhW3ByZXZJbmRleF07XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBnZXRJbmRleE9mKGxlYXJuaW5nUGF0aElkOiBudW1iZXIsIGVudHJ5OiBTdG9yYWdlRW50cnkpIHtcbiAgICAgICAgaWYgKCF0aGlzLmxlYXJuaW5nUGF0aFJlY29tbWVuZGF0aW9ucy5oYXMobGVhcm5pbmdQYXRoSWQpKSB7XG4gICAgICAgICAgICByZXR1cm4gLTE7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMubGVhcm5pbmdQYXRoUmVjb21tZW5kYXRpb25zLmdldChsZWFybmluZ1BhdGhJZCkhLmZpbmRJbmRleCgoZTogU3RvcmFnZUVudHJ5KSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gZW50cnkuZXF1YWxzKGUpO1xuICAgICAgICB9KTtcbiAgICB9XG59XG5cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBTdG9yYWdlRW50cnkge1xuICAgIGFic3RyYWN0IGVxdWFscyhvdGhlcjogU3RvcmFnZUVudHJ5KTogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGNsYXNzIExlY3R1cmVVbml0RW50cnkgZXh0ZW5kcyBTdG9yYWdlRW50cnkge1xuICAgIHJlYWRvbmx5IGxlY3R1cmVVbml0SWQ6IG51bWJlcjtcbiAgICByZWFkb25seSBsZWN0dXJlSWQ6IG51bWJlcjtcblxuICAgIGNvbnN0cnVjdG9yKGxlY3R1cmVJZDogbnVtYmVyLCBsZWN0dXJlVW5pdElkOiBudW1iZXIpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy5sZWN0dXJlSWQgPSBsZWN0dXJlSWQ7XG4gICAgICAgIHRoaXMubGVjdHVyZVVuaXRJZCA9IGxlY3R1cmVVbml0SWQ7XG4gICAgfVxuXG4gICAgZXF1YWxzKG90aGVyOiBTdG9yYWdlRW50cnkpOiBib29sZWFuIHtcbiAgICAgICAgaWYgKG90aGVyIGluc3RhbmNlb2YgTGVjdHVyZVVuaXRFbnRyeSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMubGVjdHVyZUlkID09PSBvdGhlci5sZWN0dXJlSWQgJiYgdGhpcy5sZWN0dXJlVW5pdElkID09PSBvdGhlci5sZWN0dXJlVW5pdElkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG59XG5cbmV4cG9ydCBjbGFzcyBFeGVyY2lzZUVudHJ5IGV4dGVuZHMgU3RvcmFnZUVudHJ5IHtcbiAgICByZWFkb25seSBleGVyY2lzZUlkOiBudW1iZXI7XG5cbiAgICBjb25zdHJ1Y3RvcihleGVyY2lzZUlkOiBudW1iZXIpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy5leGVyY2lzZUlkID0gZXhlcmNpc2VJZDtcbiAgICB9XG5cbiAgICBlcXVhbHMob3RoZXI6IFN0b3JhZ2VFbnRyeSk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAob3RoZXIgaW5zdGFuY2VvZiBFeGVyY2lzZUVudHJ5KSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5leGVyY2lzZUlkID09PSBvdGhlci5leGVyY2lzZUlkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50LCBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBMZWFybmluZ1BhdGhIZWFsdGhEVE8gfSBmcm9tICdhcHAvZW50aXRpZXMvY29tcGV0ZW5jeS9sZWFybmluZy1wYXRoLWhlYWx0aC5tb2RlbCc7XG5pbXBvcnQgeyBDb21wZXRlbmN5UHJvZ3Jlc3NGb3JMZWFybmluZ1BhdGhEVE8sIExlYXJuaW5nUGF0aEluZm9ybWF0aW9uRFRPLCBOZ3hMZWFybmluZ1BhdGhEVE8gfSBmcm9tICdhcHAvZW50aXRpZXMvY29tcGV0ZW5jeS9sZWFybmluZy1wYXRoLm1vZGVsJztcbmltcG9ydCB7IG1hcCwgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgTGVhcm5pbmdQYXRoU3RvcmFnZVNlcnZpY2UgfSBmcm9tICdhcHAvY291cnNlL2xlYXJuaW5nLXBhdGhzL3BhcnRpY2lwYXRlL2xlYXJuaW5nLXBhdGgtc3RvcmFnZS5zZXJ2aWNlJztcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBMZWFybmluZ1BhdGhTZXJ2aWNlIHtcbiAgICBwcml2YXRlIHJlc291cmNlVVJMID0gJ2FwaSc7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBodHRwQ2xpZW50OiBIdHRwQ2xpZW50LFxuICAgICAgICBwcml2YXRlIGxlYXJuaW5nUGF0aFN0b3JhZ2VTZXJ2aWNlOiBMZWFybmluZ1BhdGhTdG9yYWdlU2VydmljZSxcbiAgICApIHt9XG5cbiAgICBlbmFibGVMZWFybmluZ1BhdGhzKGNvdXJzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTx2b2lkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwQ2xpZW50LnB1dDx2b2lkPihgJHt0aGlzLnJlc291cmNlVVJMfS9jb3Vyc2VzLyR7Y291cnNlSWR9L2xlYXJuaW5nLXBhdGhzL2VuYWJsZWAsIG51bGwsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG5cbiAgICBnZW5lcmF0ZU1pc3NpbmdMZWFybmluZ1BhdGhzRm9yQ291cnNlKGNvdXJzZUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTx2b2lkPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwQ2xpZW50LnB1dDx2b2lkPihgJHt0aGlzLnJlc291cmNlVVJMfS9jb3Vyc2VzLyR7Y291cnNlSWR9L2xlYXJuaW5nLXBhdGhzL2dlbmVyYXRlLW1pc3NpbmdgLCBudWxsLCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgZ2V0SGVhbHRoU3RhdHVzRm9yQ291cnNlKGNvdXJzZUlkOiBudW1iZXIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cENsaWVudC5nZXQ8TGVhcm5pbmdQYXRoSGVhbHRoRFRPPihgJHt0aGlzLnJlc291cmNlVVJMfS9jb3Vyc2VzLyR7Y291cnNlSWR9L2xlYXJuaW5nLXBhdGgtaGVhbHRoYCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pO1xuICAgIH1cblxuICAgIGdldExlYXJuaW5nUGF0aChsZWFybmluZ1BhdGhJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8TGVhcm5pbmdQYXRoSW5mb3JtYXRpb25EVE8+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBDbGllbnQuZ2V0PExlYXJuaW5nUGF0aEluZm9ybWF0aW9uRFRPPihgJHt0aGlzLnJlc291cmNlVVJMfS9sZWFybmluZy1wYXRoLyR7bGVhcm5pbmdQYXRoSWR9YCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnIH0pO1xuICAgIH1cblxuICAgIGdldExlYXJuaW5nUGF0aE5neEdyYXBoKGxlYXJuaW5nUGF0aElkOiBudW1iZXIpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxOZ3hMZWFybmluZ1BhdGhEVE8+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBDbGllbnQuZ2V0PE5neExlYXJuaW5nUGF0aERUTz4oYCR7dGhpcy5yZXNvdXJjZVVSTH0vbGVhcm5pbmctcGF0aC8ke2xlYXJuaW5nUGF0aElkfS9ncmFwaGAsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KS5waXBlKFxuICAgICAgICAgICAgbWFwKChuZ3hMZWFybmluZ1BhdGhSZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnNhbml0aXplTmd4TGVhcm5pbmdQYXRoUmVzcG9uc2Uobmd4TGVhcm5pbmdQYXRoUmVzcG9uc2UpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZ2V0TGVhcm5pbmdQYXRoTmd4UGF0aChsZWFybmluZ1BhdGhJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8Tmd4TGVhcm5pbmdQYXRoRFRPPj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwQ2xpZW50LmdldDxOZ3hMZWFybmluZ1BhdGhEVE8+KGAke3RoaXMucmVzb3VyY2VVUkx9L2xlYXJuaW5nLXBhdGgvJHtsZWFybmluZ1BhdGhJZH0vcGF0aGAsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KS5waXBlKFxuICAgICAgICAgICAgbWFwKChuZ3hMZWFybmluZ1BhdGhSZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnNhbml0aXplTmd4TGVhcm5pbmdQYXRoUmVzcG9uc2Uobmd4TGVhcm5pbmdQYXRoUmVzcG9uc2UpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKG5neExlYXJuaW5nUGF0aFJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5sZWFybmluZ1BhdGhTdG9yYWdlU2VydmljZS5zdG9yZVJlY29tbWVuZGF0aW9ucyhsZWFybmluZ1BhdGhJZCwgbmd4TGVhcm5pbmdQYXRoUmVzcG9uc2UuYm9keSEpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzYW5pdGl6ZU5neExlYXJuaW5nUGF0aFJlc3BvbnNlKG5neExlYXJuaW5nUGF0aFJlc3BvbnNlOiBIdHRwUmVzcG9uc2U8Tmd4TGVhcm5pbmdQYXRoRFRPPikge1xuICAgICAgICBuZ3hMZWFybmluZ1BhdGhSZXNwb25zZS5ib2R5IS5ub2RlcyA/Pz0gW107XG4gICAgICAgIG5neExlYXJuaW5nUGF0aFJlc3BvbnNlLmJvZHkhLmVkZ2VzID8/PSBbXTtcbiAgICAgICAgcmV0dXJuIG5neExlYXJuaW5nUGF0aFJlc3BvbnNlO1xuICAgIH1cblxuICAgIGdldExlYXJuaW5nUGF0aElkKGNvdXJzZUlkOiBudW1iZXIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cENsaWVudC5nZXQ8bnVtYmVyPihgJHt0aGlzLnJlc291cmNlVVJMfS9jb3Vyc2VzLyR7Y291cnNlSWR9L2xlYXJuaW5nLXBhdGgtaWRgLCB7IG9ic2VydmU6ICdyZXNwb25zZScgfSk7XG4gICAgfVxuXG4gICAgZ2V0Q29tcGV0ZW5jeVByb2dyZXNzRm9yTGVhcm5pbmdQYXRoKGxlYXJuaW5nUGF0aElkOiBudW1iZXIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cENsaWVudC5nZXQ8Q29tcGV0ZW5jeVByb2dyZXNzRm9yTGVhcm5pbmdQYXRoRFRPW10+KGAke3RoaXMucmVzb3VyY2VVUkx9L2xlYXJuaW5nLXBhdGgvJHtsZWFybmluZ1BhdGhJZH0vY29tcGV0ZW5jeS1wcm9ncmVzc2AsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IG9uRXJyb3IgfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvZ2xvYmFsLnV0aWxzJztcbmltcG9ydCB7IENvbXBldGVuY3lTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvdXJzZS9jb21wZXRlbmNpZXMvY29tcGV0ZW5jeS5zZXJ2aWNlJztcbmltcG9ydCB7IENvbXBldGVuY3ksIENvbXBldGVuY3lQcm9ncmVzcywgZ2V0Q29uZmlkZW5jZSwgZ2V0SWNvbiwgZ2V0SWNvblRvb2x0aXAsIGdldE1hc3RlcnksIGdldFByb2dyZXNzIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvbXBldGVuY3kubW9kZWwnO1xuaW1wb3J0IHsgQWxlcnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvdXRpbC9hbGVydC5zZXJ2aWNlJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktY29tcGV0ZW5jeS1ub2RlLWRldGFpbHMnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9jb21wZXRlbmN5LW5vZGUtZGV0YWlscy5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIENvbXBldGVuY3lOb2RlRGV0YWlsc0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgQElucHV0KCkgY291cnNlSWQ6IG51bWJlcjtcbiAgICBASW5wdXQoKSBjb21wZXRlbmN5SWQ6IG51bWJlcjtcbiAgICBASW5wdXQoKSBjb21wZXRlbmN5PzogQ29tcGV0ZW5jeTtcbiAgICBAT3V0cHV0KCkgY29tcGV0ZW5jeUNoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8Q29tcGV0ZW5jeT4oKTtcbiAgICBASW5wdXQoKSBjb21wZXRlbmN5UHJvZ3Jlc3M6IENvbXBldGVuY3lQcm9ncmVzcztcblxuICAgIGlzTG9hZGluZyA9IGZhbHNlO1xuXG4gICAgcHJvdGVjdGVkIHJlYWRvbmx5IGdldEljb24gPSBnZXRJY29uO1xuICAgIHByb3RlY3RlZCByZWFkb25seSBnZXRJY29uVG9vbHRpcCA9IGdldEljb25Ub29sdGlwO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgY29tcGV0ZW5jeVNlcnZpY2U6IENvbXBldGVuY3lTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFsZXJ0U2VydmljZTogQWxlcnRTZXJ2aWNlLFxuICAgICkge31cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICBpZiAoIXRoaXMuY29tcGV0ZW5jeSkge1xuICAgICAgICAgICAgdGhpcy5sb2FkRGF0YSgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHByaXZhdGUgbG9hZERhdGEoKSB7XG4gICAgICAgIHRoaXMuaXNMb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5jb21wZXRlbmN5U2VydmljZS5maW5kQnlJZCh0aGlzLmNvbXBldGVuY3lJZCEsIHRoaXMuY291cnNlSWQhKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKHJlc3ApID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbXBldGVuY3kgPSByZXNwLmJvZHkhO1xuICAgICAgICAgICAgICAgIHRoaXMuaXNMb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhpcy5jb21wZXRlbmN5Q2hhbmdlLmVtaXQodGhpcy5jb21wZXRlbmN5KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogKGVycm9yUmVzcG9uc2U6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiBvbkVycm9yKHRoaXMuYWxlcnRTZXJ2aWNlLCBlcnJvclJlc3BvbnNlKSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgZ2V0IHByb2dyZXNzKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiBnZXRQcm9ncmVzcyh0aGlzLmNvbXBldGVuY3lQcm9ncmVzcyEpO1xuICAgIH1cblxuICAgIGdldCBjb25maWRlbmNlKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiBnZXRDb25maWRlbmNlKHRoaXMuY29tcGV0ZW5jeVByb2dyZXNzISwgdGhpcy5jb21wZXRlbmN5IS5tYXN0ZXJ5VGhyZXNob2xkISk7XG4gICAgfVxuXG4gICAgZ2V0IG1hc3RlcnkoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIGdldE1hc3RlcnkodGhpcy5jb21wZXRlbmN5UHJvZ3Jlc3MhLCB0aGlzLmNvbXBldGVuY3khLm1hc3RlcnlUaHJlc2hvbGQhKTtcbiAgICB9XG59XG4iLCJAaWYgKGNvbXBldGVuY3kpIHtcbiAgICA8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtOVwiPlxuICAgICAgICAgICAgPGgzIGNsYXNzPVwibWItMFwiPlxuICAgICAgICAgICAgICAgIEBpZiAoY29tcGV0ZW5jeS50YXhvbm9teSkge1xuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvblxuICAgICAgICAgICAgICAgICAgICAgICAgW2ljb25dPVwiZ2V0SWNvbihjb21wZXRlbmN5LnRheG9ub215KVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbZml4ZWRXaWR0aF09XCJ0cnVlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtuZ2JUb29sdGlwXT1cImdldEljb25Ub29sdGlwKGNvbXBldGVuY3kudGF4b25vbXkpIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250YWluZXI9XCJib2R5XCJcbiAgICAgICAgICAgICAgICAgICAgPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPHNwYW4+e3sgY29tcGV0ZW5jeS50aXRsZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICBAaWYgKHRoaXMubWFzdGVyeSA+PSAxMDApIHtcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSB0ZXh0LXdoaXRlIHRleHQtYmctc3VjY2Vzc1wiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAuY29tcGV0ZW5jeS5tYXN0ZXJlZFwiPk1hc3RlcmVkPC9zcGFuPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKGNvbXBldGVuY3kub3B0aW9uYWwpIHtcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSB0ZXh0LXdoaXRlIGJnLXdhcm5pbmdcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvbXBldGVuY3kub3B0aW9uYWxcIj5PcHRpb25hbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgQGlmIChjb21wZXRlbmN5LmRlc2NyaXB0aW9uKSB7XG4gICAgICAgICAgICAgICAgPGRpdiBbaW5uZXJIVE1MXT1cImNvbXBldGVuY3kuZGVzY3JpcHRpb25cIj48L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtM1wiPjxqaGktY29tcGV0ZW5jeS1yaW5ncyBbcHJvZ3Jlc3NdPVwicHJvZ3Jlc3NcIiBbY29uZmlkZW5jZV09XCJjb25maWRlbmNlXCIgW21hc3RlcnldPVwibWFzdGVyeVwiPjwvamhpLWNvbXBldGVuY3ktcmluZ3M+PC9kaXY+XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IG9uRXJyb3IgfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvZ2xvYmFsLnV0aWxzJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5pbXBvcnQgeyBFeGVyY2lzZSwgZ2V0SWNvbiwgZ2V0SWNvblRvb2x0aXAgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgRXhlcmNpc2VTZXJ2aWNlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhlcmNpc2UvZXhlcmNpc2Uuc2VydmljZSc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWV4ZXJjaXNlLW5vZGUtZGV0YWlscycsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2V4ZXJjaXNlLW5vZGUtZGV0YWlscy5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIEV4ZXJjaXNlTm9kZURldGFpbHNDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlSWQ6IG51bWJlcjtcbiAgICBASW5wdXQoKSBleGVyY2lzZT86IEV4ZXJjaXNlO1xuICAgIEBPdXRwdXQoKSBleGVyY2lzZUNoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8RXhlcmNpc2U+KCk7XG5cbiAgICBpc0xvYWRpbmcgPSBmYWxzZTtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGV4ZXJjaXNlU2VydmljZTogRXhlcmNpc2VTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFsZXJ0U2VydmljZTogQWxlcnRTZXJ2aWNlLFxuICAgICkge31cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICBpZiAoIXRoaXMuZXhlcmNpc2UpIHtcbiAgICAgICAgICAgIHRoaXMubG9hZERhdGEoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBwcml2YXRlIGxvYWREYXRhKCkge1xuICAgICAgICB0aGlzLmlzTG9hZGluZyA9IHRydWU7XG4gICAgICAgIHRoaXMuZXhlcmNpc2VTZXJ2aWNlLmZpbmQodGhpcy5leGVyY2lzZUlkKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKGV4ZXJjaXNlUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmV4ZXJjaXNlID0gZXhlcmNpc2VSZXNwb25zZS5ib2R5ITtcbiAgICAgICAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHRoaXMuZXhlcmNpc2VDaGFuZ2UuZW1pdCh0aGlzLmV4ZXJjaXNlKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogKGVycm9yUmVzcG9uc2U6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiBvbkVycm9yKHRoaXMuYWxlcnRTZXJ2aWNlLCBlcnJvclJlc3BvbnNlKSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHJlYWRvbmx5IGdldEljb24gPSBnZXRJY29uO1xuICAgIHByb3RlY3RlZCByZWFkb25seSBnZXRJY29uVG9vbHRpcCA9IGdldEljb25Ub29sdGlwO1xufVxuIiwiQGlmIChleGVyY2lzZSkge1xuICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNvbFwiPlxuICAgICAgICAgICAgPGgzIGNsYXNzPVwibWItMFwiPlxuICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2UudHlwZSkge1xuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJnZXRJY29uKGV4ZXJjaXNlLnR5cGUpXCIgW2ZpeGVkV2lkdGhdPVwidHJ1ZVwiIFtuZ2JUb29sdGlwXT1cImdldEljb25Ub29sdGlwKGV4ZXJjaXNlLnR5cGUpIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiIGNvbnRhaW5lcj1cImJvZHlcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDxzcGFuPnt7IGV4ZXJjaXNlLnRpdGxlIH19PC9zcGFuPlxuICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IG9uRXJyb3IgfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvZ2xvYmFsLnV0aWxzJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5pbXBvcnQgeyBMZWN0dXJlVW5pdCwgZ2V0SWNvbiwgZ2V0SWNvblRvb2x0aXAgfSBmcm9tICdhcHAvZW50aXRpZXMvbGVjdHVyZS11bml0L2xlY3R1cmVVbml0Lm1vZGVsJztcbmltcG9ydCB7IExlY3R1cmVVbml0U2VydmljZSB9IGZyb20gJ2FwcC9sZWN0dXJlL2xlY3R1cmUtdW5pdC9sZWN0dXJlLXVuaXQtbWFuYWdlbWVudC9sZWN0dXJlVW5pdC5zZXJ2aWNlJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbGVjdHVyZS11bml0LW5vZGUtZGV0YWlscycsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2xlY3R1cmUtdW5pdC1ub2RlLWRldGFpbHMuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBMZWN0dXJlVW5pdE5vZGVEZXRhaWxzQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICBASW5wdXQoKSBsZWN0dXJlVW5pdElkOiBudW1iZXI7XG5cbiAgICBASW5wdXQoKSBsZWN0dXJlVW5pdD86IExlY3R1cmVVbml0O1xuICAgIEBPdXRwdXQoKSBsZWN0dXJlVW5pdENoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8TGVjdHVyZVVuaXQ+KCk7XG5cbiAgICBpc0xvYWRpbmcgPSBmYWxzZTtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGxlY3R1cmVVbml0U2VydmljZTogTGVjdHVyZVVuaXRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFsZXJ0U2VydmljZTogQWxlcnRTZXJ2aWNlLFxuICAgICkge31cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICBpZiAoIXRoaXMubGVjdHVyZVVuaXQpIHtcbiAgICAgICAgICAgIHRoaXMubG9hZERhdGEoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBwcml2YXRlIGxvYWREYXRhKCkge1xuICAgICAgICB0aGlzLmlzTG9hZGluZyA9IHRydWU7XG5cbiAgICAgICAgdGhpcy5sZWN0dXJlVW5pdFNlcnZpY2UuZ2V0TGVjdHVyZVVuaXRGb3JMZWFybmluZ1BhdGhOb2RlRGV0YWlscyh0aGlzLmxlY3R1cmVVbml0SWQhKS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKGxlY3R1cmVVbml0UmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5sZWN0dXJlVW5pdCA9IGxlY3R1cmVVbml0UmVzdWx0LmJvZHkhO1xuICAgICAgICAgICAgICAgIHRoaXMuaXNMb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhpcy5sZWN0dXJlVW5pdENoYW5nZS5lbWl0KHRoaXMubGVjdHVyZVVuaXQpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yOiAoZXJyb3JSZXNwb25zZTogSHR0cEVycm9yUmVzcG9uc2UpID0+IG9uRXJyb3IodGhpcy5hbGVydFNlcnZpY2UsIGVycm9yUmVzcG9uc2UpLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgcmVhZG9ubHkgZ2V0SWNvbiA9IGdldEljb247XG4gICAgcHJvdGVjdGVkIHJlYWRvbmx5IGdldEljb25Ub29sdGlwID0gZ2V0SWNvblRvb2x0aXA7XG59XG4iLCJAaWYgKGxlY3R1cmVVbml0KSB7XG4gICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiY29sXCI+XG4gICAgICAgICAgICA8aDMgY2xhc3M9XCJtYi0wXCI+XG4gICAgICAgICAgICAgICAgQGlmIChsZWN0dXJlVW5pdC50eXBlKSB7XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImdldEljb24obGVjdHVyZVVuaXQudHlwZSEpXCIgW2ZpeGVkV2lkdGhdPVwidHJ1ZVwiIFtuZ2JUb29sdGlwXT1cImdldEljb25Ub29sdGlwKGxlY3R1cmVVbml0LnR5cGUhKSB8IGFydGVtaXNUcmFuc2xhdGVcIiBjb250YWluZXI9XCJib2R5XCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8c3Bhbj57eyBsZWN0dXJlVW5pdC5uYW1lIH19PC9zcGFuPlxuICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbXBldGVuY3lQcm9ncmVzc0ZvckxlYXJuaW5nUGF0aERUTywgTmd4TGVhcm5pbmdQYXRoTm9kZSwgTm9kZVR5cGUsIGdldEljb24gfSBmcm9tICdhcHAvZW50aXRpZXMvY29tcGV0ZW5jeS9sZWFybmluZy1wYXRoLm1vZGVsJztcbmltcG9ydCB7IENvbXBldGVuY3ksIENvbXBldGVuY3lQcm9ncmVzcywgZ2V0Q29uZmlkZW5jZSwgZ2V0TWFzdGVyeSwgZ2V0UHJvZ3Jlc3MgfSBmcm9tICdhcHAvZW50aXRpZXMvY29tcGV0ZW5jeS5tb2RlbCc7XG5pbXBvcnQgeyBFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBMZWN0dXJlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2xlY3R1cmUubW9kZWwnO1xuaW1wb3J0IHsgTGVjdHVyZVVuaXRGb3JMZWFybmluZ1BhdGhOb2RlRGV0YWlsc0RUTyB9IGZyb20gJ2FwcC9lbnRpdGllcy9sZWN0dXJlLXVuaXQvbGVjdHVyZVVuaXQubW9kZWwnO1xuXG5jbGFzcyBOb2RlRGV0YWlsc0RhdGEge1xuICAgIGNvbXBldGVuY3k/OiBDb21wZXRlbmN5O1xuICAgIGNvbXBldGVuY3lQcm9ncmVzcz86IENvbXBldGVuY3lQcm9ncmVzcztcbiAgICBleGVyY2lzZT86IEV4ZXJjaXNlO1xuICAgIGxlY3R1cmU/OiBMZWN0dXJlO1xuICAgIGxlY3R1cmVVbml0PzogTGVjdHVyZVVuaXRGb3JMZWFybmluZ1BhdGhOb2RlRGV0YWlsc0RUTztcbn1cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbGVhcm5pbmctcGF0aC1ncmFwaC1ub2RlJyxcbiAgICBzdHlsZVVybHM6IFsnLi9sZWFybmluZy1wYXRoLWdyYXBoLmNvbXBvbmVudC5zY3NzJ10sXG4gICAgdGVtcGxhdGVVcmw6ICcuL2xlYXJuaW5nLXBhdGgtbm9kZS5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIExlYXJuaW5nUGF0aE5vZGVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEBJbnB1dCgpIGNvdXJzZUlkOiBudW1iZXI7XG4gICAgQElucHV0KCkgbm9kZTogTmd4TGVhcm5pbmdQYXRoTm9kZTtcbiAgICBASW5wdXQoKSBjb21wZXRlbmN5UHJvZ3Jlc3NEVE8/OiBDb21wZXRlbmN5UHJvZ3Jlc3NGb3JMZWFybmluZ1BhdGhEVE87XG5cbiAgICBub2RlRGV0YWlsc0RhdGEgPSBuZXcgTm9kZURldGFpbHNEYXRhKCk7XG5cbiAgICBwcm90ZWN0ZWQgcmVhZG9ubHkgTm9kZVR5cGUgPSBOb2RlVHlwZTtcbiAgICBwcm90ZWN0ZWQgcmVhZG9ubHkgZ2V0SWNvbiA9IGdldEljb247XG5cbiAgICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgaWYgKHRoaXMuY29tcGV0ZW5jeVByb2dyZXNzRFRPKSB7XG4gICAgICAgICAgICB0aGlzLm5vZGVEZXRhaWxzRGF0YS5jb21wZXRlbmN5UHJvZ3Jlc3MgPSB7IHByb2dyZXNzOiB0aGlzLmNvbXBldGVuY3lQcm9ncmVzc0RUTy5wcm9ncmVzcywgY29uZmlkZW5jZTogdGhpcy5jb21wZXRlbmN5UHJvZ3Jlc3NEVE8uY29uZmlkZW5jZSB9O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZ2V0IHByb2dyZXNzKCkge1xuICAgICAgICByZXR1cm4gZ2V0UHJvZ3Jlc3ModGhpcy5ub2RlRGV0YWlsc0RhdGEuY29tcGV0ZW5jeVByb2dyZXNzISk7XG4gICAgfVxuXG4gICAgZ2V0IGNvbmZpZGVuY2UoKSB7XG4gICAgICAgIHJldHVybiBnZXRDb25maWRlbmNlKHRoaXMubm9kZURldGFpbHNEYXRhLmNvbXBldGVuY3lQcm9ncmVzcyEsIHRoaXMuY29tcGV0ZW5jeVByb2dyZXNzRFRPIS5tYXN0ZXJ5VGhyZXNob2xkISk7XG4gICAgfVxuXG4gICAgZ2V0IG1hc3RlcnkoKSB7XG4gICAgICAgIHJldHVybiBnZXRNYXN0ZXJ5KHRoaXMubm9kZURldGFpbHNEYXRhLmNvbXBldGVuY3lQcm9ncmVzcyEsIHRoaXMuY29tcGV0ZW5jeVByb2dyZXNzRFRPIS5tYXN0ZXJ5VGhyZXNob2xkISk7XG4gICAgfVxufVxuIiwiQGlmIChub2RlLnR5cGUgPT09IE5vZGVUeXBlLkVYRVJDSVNFIHx8IG5vZGUudHlwZSA9PT0gTm9kZVR5cGUuTEVDVFVSRV9VTklUKSB7XG4gICAgPGRpdiBjbGFzcz1cIm5vZGUtaWNvbi1jb250YWluZXJcIiBbamhpU3RpY2t5UG9wb3Zlcl09XCJwb3BDb250ZW50VGFza1wiIHBsYWNlbWVudD1cInJpZ2h0XCIgdHJpZ2dlcnM9XCJtYW51YWxcIj5cbiAgICAgICAgPGZhLWljb24gaWQ9XCJsZWFybmluZy1vYmplY3RcIiBbaWNvbl09XCJnZXRJY29uKG5vZGUpXCIgW2NsYXNzLmNvbXBsZXRlZF09XCJub2RlLmNvbXBsZXRlZFwiPjwvZmEtaWNvbj5cbiAgICA8L2Rpdj5cbn0gQGVsc2Uge1xuICAgIEBpZiAobm9kZS50eXBlID09PSBOb2RlVHlwZS5DT01QRVRFTkNZX1NUQVJUIHx8IG5vZGUudHlwZSA9PT0gTm9kZVR5cGUuQ09NUEVURU5DWV9FTkQpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cIm5vZGUtaWNvbi1jb250YWluZXJcIiBbY2xhc3Mubm9kZS1zXT1cIm5vZGUudHlwZSA9PT0gTm9kZVR5cGUuQ09NUEVURU5DWV9FTkRcIiBbamhpU3RpY2t5UG9wb3Zlcl09XCJwb3BDb250ZW50Q29tcGV0ZW5jeVwiIHBsYWNlbWVudD1cInJpZ2h0XCIgdHJpZ2dlcnM9XCJtYW51YWxcIj5cbiAgICAgICAgICAgIEBpZiAobm9kZS50eXBlID09PSBOb2RlVHlwZS5DT01QRVRFTkNZX1NUQVJUKSB7XG4gICAgICAgICAgICAgICAgPGpoaS1jb21wZXRlbmN5LXJpbmdzXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwibS0xXCJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb21wZXRlbmN5LXN0YXJ0XCJcbiAgICAgICAgICAgICAgICAgICAgW3Byb2dyZXNzXT1cInByb2dyZXNzXCJcbiAgICAgICAgICAgICAgICAgICAgW2NvbmZpZGVuY2VdPVwiY29uZmlkZW5jZVwiXG4gICAgICAgICAgICAgICAgICAgIFttYXN0ZXJ5XT1cIm1hc3RlcnlcIlxuICAgICAgICAgICAgICAgICAgICBbaGlkZVRvb2x0aXBdPVwidHJ1ZVwiXG4gICAgICAgICAgICAgICAgPjwvamhpLWNvbXBldGVuY3ktcmluZ3M+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKG5vZGUudHlwZSA9PT0gTm9kZVR5cGUuQ09NUEVURU5DWV9FTkQpIHtcbiAgICAgICAgICAgICAgICA8ZmEtaWNvbiBpZD1cImNvbXBldGVuY3ktZW5kXCIgW2ljb25dPVwiZ2V0SWNvbihub2RlKVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgfSBAZWxzZSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJub2RlLXhzIG5vZGUtaWNvbi1jb250YWluZXJcIj5cbiAgICAgICAgICAgIDxmYS1pY29uIGlkPVwibWF0Y2hcIiBbaWNvbl09XCJnZXRJY29uKG5vZGUpXCI+PC9mYS1pY29uPlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG59XG48bmctdGVtcGxhdGUgI3BvcENvbnRlbnRUYXNrPlxuICAgIEBpZiAobm9kZS50eXBlID09PSBOb2RlVHlwZS5FWEVSQ0lTRSkge1xuICAgICAgICA8amhpLWV4ZXJjaXNlLW5vZGUtZGV0YWlscyBjbGFzcz1cIm5vZGUtZGV0YWlsc1wiIFtleGVyY2lzZUlkXT1cIm5vZGUubGlua2VkUmVzb3VyY2UhXCIgWyhleGVyY2lzZSldPVwibm9kZURldGFpbHNEYXRhLmV4ZXJjaXNlXCI+PC9qaGktZXhlcmNpc2Utbm9kZS1kZXRhaWxzPlxuICAgIH1cbiAgICBAaWYgKG5vZGUudHlwZSA9PT0gTm9kZVR5cGUuTEVDVFVSRV9VTklUKSB7XG4gICAgICAgIDxqaGktbGVjdHVyZS11bml0LW5vZGUtZGV0YWlscyBjbGFzcz1cIm5vZGUtZGV0YWlsc1wiIFtsZWN0dXJlVW5pdElkXT1cIm5vZGUubGlua2VkUmVzb3VyY2UhXCIgWyhsZWN0dXJlVW5pdCldPVwibm9kZURldGFpbHNEYXRhLmxlY3R1cmVVbml0XCI+PC9qaGktbGVjdHVyZS11bml0LW5vZGUtZGV0YWlscz5cbiAgICB9XG48L25nLXRlbXBsYXRlPlxuPG5nLXRlbXBsYXRlICNwb3BDb250ZW50Q29tcGV0ZW5jeT5cbiAgICA8amhpLWNvbXBldGVuY3ktbm9kZS1kZXRhaWxzXG4gICAgICAgIGNsYXNzPVwibm9kZS1kZXRhaWxzXCJcbiAgICAgICAgW2NvdXJzZUlkXT1cImNvdXJzZUlkXCJcbiAgICAgICAgW2NvbXBldGVuY3lJZF09XCJub2RlLmxpbmtlZFJlc291cmNlIVwiXG4gICAgICAgIFsoY29tcGV0ZW5jeSldPVwibm9kZURldGFpbHNEYXRhLmNvbXBldGVuY3lcIlxuICAgICAgICBbY29tcGV0ZW5jeVByb2dyZXNzXT1cIm5vZGVEZXRhaWxzRGF0YS5jb21wZXRlbmN5UHJvZ3Jlc3MhXCJcbiAgICA+PC9qaGktY29tcGV0ZW5jeS1ub2RlLWRldGFpbHM+XG48L25nLXRlbXBsYXRlPlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmd4TGVhcm5pbmdQYXRoTm9kZSwgTm9kZVR5cGUsIGdldEljb24gfSBmcm9tICdhcHAvZW50aXRpZXMvY29tcGV0ZW5jeS9sZWFybmluZy1wYXRoLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbGVhcm5pbmctcGF0aC1sZWdlbmQnLFxuICAgIHN0eWxlVXJsczogWycuL2xlYXJuaW5nLXBhdGgtZ3JhcGguY29tcG9uZW50LnNjc3MnXSxcbiAgICB0ZW1wbGF0ZVVybDogJy4vbGVhcm5pbmctcGF0aC1sZWdlbmQuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBMZWFybmluZ1BhdGhMZWdlbmRDb21wb25lbnQge1xuICAgIEBJbnB1dCgpIG5vZGVUeXBlczogU2V0PE5vZGVUeXBlPjtcblxuICAgIHByb3RlY3RlZCByZWFkb25seSBnZXRJY29uID0gZ2V0SWNvbjtcbiAgICBwcm90ZWN0ZWQgcmVhZG9ubHkgY29tcGV0ZW5jeUVuZCA9IHsgaWQ6ICcnLCB0eXBlOiBOb2RlVHlwZS5DT01QRVRFTkNZX0VORCB9IGFzIE5neExlYXJuaW5nUGF0aE5vZGU7XG4gICAgcHJvdGVjdGVkIHJlYWRvbmx5IG1hdGNoU3RhcnQgPSB7IGlkOiAnJywgdHlwZTogTm9kZVR5cGUuTUFUQ0hfU1RBUlQgfSBhcyBOZ3hMZWFybmluZ1BhdGhOb2RlO1xuICAgIHByb3RlY3RlZCByZWFkb25seSBtYXRjaEVuZCA9IHsgaWQ6ICcnLCB0eXBlOiBOb2RlVHlwZS5NQVRDSF9FTkQgfSBhcyBOZ3hMZWFybmluZ1BhdGhOb2RlO1xuICAgIHByb3RlY3RlZCByZWFkb25seSBsZWFybmluZ09iamVjdCA9IHsgaWQ6ICcnLCB0eXBlOiBOb2RlVHlwZS5MRUNUVVJFX1VOSVQgfSBhcyBOZ3hMZWFybmluZ1BhdGhOb2RlO1xuICAgIHByb3RlY3RlZCByZWFkb25seSBjb21wbGV0ZWRMZWFybmluZ09iamVjdCA9IHsgaWQ6ICcnLCB0eXBlOiBOb2RlVHlwZS5MRUNUVVJFX1VOSVQsIGNvbXBsZXRlZDogdHJ1ZSB9IGFzIE5neExlYXJuaW5nUGF0aE5vZGU7XG4gICAgcHJvdGVjdGVkIHJlYWRvbmx5IE5vZGVUeXBlID0gTm9kZVR5cGU7XG59XG4iLCI8ZGl2IGNsYXNzPVwiY29udGFpbmVyIGxlZ2VuZC13cmFwcGVyXCI+XG4gICAgQGlmIChub2RlVHlwZXMuaGFzKE5vZGVUeXBlLkNPTVBFVEVOQ1lfRU5EKSkge1xuICAgICAgICA8ZGl2IGlkPVwiY29tcGV0ZW5jeS1lbmRcIiBjbGFzcz1cInJvd1wiIG5nYlRvb2x0aXA9XCJ7eyAnYXJ0ZW1pc0FwcC5sZWFybmluZ1BhdGguZ3JhcGgubGVnZW5kLmNvbXBldGVuY3lFbmQudG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLWF1dG9cIj48ZmEtaWNvbiBjbGFzcz1cImxlZ2VuZC1pY29uXCIgW2ljb25dPVwiZ2V0SWNvbihjb21wZXRlbmN5RW5kKVwiPjwvZmEtaWNvbj48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0b1wiPlxuICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5sZWFybmluZ1BhdGguZ3JhcGgubGVnZW5kLmNvbXBldGVuY3lFbmQudGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmIChub2RlVHlwZXMuaGFzKE5vZGVUeXBlLk1BVENIX1NUQVJUKSkge1xuICAgICAgICA8ZGl2IGlkPVwibWF0Y2gtc3RhcnRcIiBjbGFzcz1cInJvd1wiIG5nYlRvb2x0aXA9XCJ7eyAnYXJ0ZW1pc0FwcC5sZWFybmluZ1BhdGguZ3JhcGgubGVnZW5kLm1hdGNoU3RhcnQudG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLWF1dG9cIj48ZmEtaWNvbiBjbGFzcz1cImxlZ2VuZC1pY29uXCIgW2ljb25dPVwiZ2V0SWNvbihtYXRjaFN0YXJ0KVwiPjwvZmEtaWNvbj48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0b1wiPlxuICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5sZWFybmluZ1BhdGguZ3JhcGgubGVnZW5kLm1hdGNoU3RhcnQudGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmIChub2RlVHlwZXMuaGFzKE5vZGVUeXBlLk1BVENIX0VORCkpIHtcbiAgICAgICAgPGRpdiBpZD1cIm1hdGNoLWVuZFwiIGNsYXNzPVwicm93XCIgbmdiVG9vbHRpcD1cInt7ICdhcnRlbWlzQXBwLmxlYXJuaW5nUGF0aC5ncmFwaC5sZWdlbmQubWF0Y2hFbmQudG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLWF1dG9cIj48ZmEtaWNvbiBjbGFzcz1cImxlZ2VuZC1pY29uXCIgW2ljb25dPVwiZ2V0SWNvbihtYXRjaEVuZClcIj48L2ZhLWljb24+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLWF1dG9cIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAubGVhcm5pbmdQYXRoLmdyYXBoLmxlZ2VuZC5tYXRjaEVuZC50aXRsZScgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICBAaWYgKG5vZGVUeXBlcy5oYXMoTm9kZVR5cGUuTEVDVFVSRV9VTklUKSB8fCBub2RlVHlwZXMuaGFzKE5vZGVUeXBlLkVYRVJDSVNFKSkge1xuICAgICAgICA8ZGl2IGlkPVwibGVhcm5pbmctb2JqZWN0XCIgY2xhc3M9XCJyb3dcIiBuZ2JUb29sdGlwPVwie3sgJ2FydGVtaXNBcHAubGVhcm5pbmdQYXRoLmdyYXBoLmxlZ2VuZC5sZWFybmluZ09iamVjdC50b29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0b1wiPjxmYS1pY29uIGNsYXNzPVwibGVnZW5kLWljb25cIiBbaWNvbl09XCJnZXRJY29uKGxlYXJuaW5nT2JqZWN0KVwiPjwvZmEtaWNvbj48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0b1wiPlxuICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5sZWFybmluZ1BhdGguZ3JhcGgubGVnZW5kLmxlYXJuaW5nT2JqZWN0LnRpdGxlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuICAgIEBpZiAobm9kZVR5cGVzLmhhcyhOb2RlVHlwZS5MRUNUVVJFX1VOSVQpIHx8IG5vZGVUeXBlcy5oYXMoTm9kZVR5cGUuRVhFUkNJU0UpKSB7XG4gICAgICAgIDxkaXYgaWQ9XCJjb21wbGV0ZWQtbGVhcm5pbmctb2JqZWN0XCIgY2xhc3M9XCJyb3dcIiBuZ2JUb29sdGlwPVwie3sgJ2FydGVtaXNBcHAubGVhcm5pbmdQYXRoLmdyYXBoLmxlZ2VuZC5jb21wbGV0ZWRMZWFybmluZ09iamVjdC50b29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0b1wiPjxmYS1pY29uIGNsYXNzPVwibGVnZW5kLWljb25cIiBbaWNvbl09XCJnZXRJY29uKGNvbXBsZXRlZExlYXJuaW5nT2JqZWN0KVwiPjwvZmEtaWNvbj48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0b1wiPlxuICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5sZWFybmluZ1BhdGguZ3JhcGgubGVnZW5kLmNvbXBsZXRlZExlYXJuaW5nT2JqZWN0LnRpdGxlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgfVxuPC9kaXY+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBMYXlvdXQgfSBmcm9tICdAc3dpbWxhbmUvbmd4LWdyYXBoJztcbmltcG9ydCAqIGFzIHNoYXBlIGZyb20gJ2QzLXNoYXBlJztcbmltcG9ydCB7IFN1YmplY3QgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IExlYXJuaW5nUGF0aFNlcnZpY2UgfSBmcm9tICdhcHAvY291cnNlL2xlYXJuaW5nLXBhdGhzL2xlYXJuaW5nLXBhdGguc2VydmljZSc7XG5pbXBvcnQgeyBDb21wZXRlbmN5UHJvZ3Jlc3NGb3JMZWFybmluZ1BhdGhEVE8sIE5neExlYXJuaW5nUGF0aERUTywgTmd4TGVhcm5pbmdQYXRoTm9kZSwgTm9kZVR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvY29tcGV0ZW5jeS9sZWFybmluZy1wYXRoLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbGVhcm5pbmctcGF0aC1ncmFwaCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vbGVhcm5pbmctcGF0aC1ncmFwaC5jb21wb25lbnQuc2NzcyddLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9sZWFybmluZy1wYXRoLWdyYXBoLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgTGVhcm5pbmdQYXRoR3JhcGhDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIGlzTG9hZGluZyA9IGZhbHNlO1xuICAgIEBJbnB1dCgpIGxlYXJuaW5nUGF0aElkOiBudW1iZXI7XG4gICAgQElucHV0KCkgY291cnNlSWQ6IG51bWJlcjtcbiAgICBAT3V0cHV0KCkgbm9kZUNsaWNrZWQ6IEV2ZW50RW1pdHRlcjxOZ3hMZWFybmluZ1BhdGhOb2RlPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgICBuZ3hMZWFybmluZ1BhdGg6IE5neExlYXJuaW5nUGF0aERUTztcbiAgICBub2RlVHlwZXM6IFNldDxOb2RlVHlwZT4gPSBuZXcgU2V0KCk7XG4gICAgY29tcGV0ZW5jeVByb2dyZXNzOiBNYXA8bnVtYmVyLCBDb21wZXRlbmN5UHJvZ3Jlc3NGb3JMZWFybmluZ1BhdGhEVE8+ID0gbmV3IE1hcCgpO1xuXG4gICAgbGF5b3V0OiBzdHJpbmcgfCBMYXlvdXQgPSAnZGFncmVDbHVzdGVyJztcbiAgICBjdXJ2ZSA9IHNoYXBlLmN1cnZlQnVuZGxlO1xuXG4gICAgcHJpdmF0ZSBfZHJhZ2dpbmdFbmFibGVkID0gZmFsc2U7XG4gICAgcHJpdmF0ZSBfcGFubmluZ0VuYWJsZWQgPSBmYWxzZTtcbiAgICBwcml2YXRlIF96b29tRW5hYmxlZCA9IGZhbHNlO1xuICAgIHByaXZhdGUgX3Bhbk9uWm9vbSA9IGZhbHNlO1xuICAgIHByaXZhdGUgX3Nob3dNaW5pTWFwID0gZmFsc2U7XG5cbiAgICB1cGRhdGUkOiBTdWJqZWN0PGJvb2xlYW4+ID0gbmV3IFN1YmplY3Q8Ym9vbGVhbj4oKTtcbiAgICBjZW50ZXIkOiBTdWJqZWN0PGJvb2xlYW4+ID0gbmV3IFN1YmplY3Q8Ym9vbGVhbj4oKTtcbiAgICB6b29tVG9GaXQkOiBTdWJqZWN0PGJvb2xlYW4+ID0gbmV3IFN1YmplY3Q8Ym9vbGVhbj4oKTtcblxuICAgIHByb3RlY3RlZCByZWFkb25seSBOb2RlVHlwZSA9IE5vZGVUeXBlO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBsZWFybmluZ1BhdGhTZXJ2aWNlOiBMZWFybmluZ1BhdGhTZXJ2aWNlKSB7fVxuXG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIGlmICh0aGlzLmxlYXJuaW5nUGF0aElkKSB7XG4gICAgICAgICAgICB0aGlzLmxvYWREYXRhQW5kUmVuZGVyKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBASW5wdXQoKSBzZXQgZHJhZ2dpbmdFbmFibGVkKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuX2RyYWdnaW5nRW5hYmxlZCA9IHZhbHVlO1xuICAgIH1cblxuICAgIGdldCBkcmFnZ2luZ0VuYWJsZWQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9kcmFnZ2luZ0VuYWJsZWQ7XG4gICAgfVxuXG4gICAgQElucHV0KCkgc2V0IHBhbm5pbmdFbmFibGVkKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuX3Bhbm5pbmdFbmFibGVkID0gdmFsdWU7XG4gICAgfVxuXG4gICAgZ2V0IHBhbm5pbmdFbmFibGVkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcGFubmluZ0VuYWJsZWQ7XG4gICAgfVxuXG4gICAgQElucHV0KCkgc2V0IHpvb21FbmFibGVkKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuX3pvb21FbmFibGVkID0gdmFsdWU7XG4gICAgfVxuXG4gICAgZ2V0IHpvb21FbmFibGVkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fem9vbUVuYWJsZWQ7XG4gICAgfVxuXG4gICAgQElucHV0KCkgc2V0IHBhbk9uWm9vbSh2YWx1ZSkge1xuICAgICAgICB0aGlzLl9wYW5Pblpvb20gPSB2YWx1ZTtcbiAgICB9XG5cbiAgICBnZXQgcGFuT25ab29tKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcGFuT25ab29tO1xuICAgIH1cblxuICAgIEBJbnB1dCgpIHNldCBzaG93TWluaU1hcCh2YWx1ZSkge1xuICAgICAgICB0aGlzLl9zaG93TWluaU1hcCA9IHZhbHVlO1xuICAgIH1cblxuICAgIGdldCBzaG93TWluaU1hcCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3Nob3dNaW5pTWFwO1xuICAgIH1cblxuICAgIHJlZnJlc2hEYXRhKCkge1xuICAgICAgICB0aGlzLmxvYWREYXRhQW5kUmVuZGVyKCk7XG4gICAgfVxuXG4gICAgbG9hZERhdGFBbmRSZW5kZXIoKSB7XG4gICAgICAgIHRoaXMubGVhcm5pbmdQYXRoU2VydmljZS5nZXRDb21wZXRlbmN5UHJvZ3Jlc3NGb3JMZWFybmluZ1BhdGgodGhpcy5sZWFybmluZ1BhdGhJZCkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5leHQ6IChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlLmJvZHkhLmZvckVhY2goKHByb2dyZXNzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29tcGV0ZW5jeVByb2dyZXNzLnNldChwcm9ncmVzcy5jb21wZXRlbmN5SWQhLCBwcm9ncmVzcyk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY29tcGxldGU6ICgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmxvYWRHcmFwaFJlcHJlc2VudGF0aW9uKHRydWUpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgbG9hZEdyYXBoUmVwcmVzZW50YXRpb24ocmVuZGVyOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMuaXNMb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5sZWFybmluZ1BhdGhTZXJ2aWNlLmdldExlYXJuaW5nUGF0aE5neEdyYXBoKHRoaXMubGVhcm5pbmdQYXRoSWQpLnN1YnNjcmliZSgobmd4TGVhcm5pbmdQYXRoUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgIG5neExlYXJuaW5nUGF0aFJlc3BvbnNlLmJvZHkhLm5vZGVzLmZvckVhY2goKG5vZGUpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmRlZmluZU5vZGVEaW1lbnNpb25zKG5vZGUpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLm5neExlYXJuaW5nUGF0aCA9IG5neExlYXJuaW5nUGF0aFJlc3BvbnNlLmJvZHkhO1xuXG4gICAgICAgICAgICAvLyB1cGRhdGUgY29udGFpbmVkIG5vZGUgdHlwZXNcbiAgICAgICAgICAgIHRoaXMubm9kZVR5cGVzID0gbmV3IFNldCgpO1xuICAgICAgICAgICAgdGhpcy5uZ3hMZWFybmluZ1BhdGgubm9kZXMuZm9yRWFjaCgobm9kZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMubm9kZVR5cGVzLmFkZChub2RlLnR5cGUhKTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBpZiAocmVuZGVyKSB7XG4gICAgICAgICAgICAgICAgdGhpcy51cGRhdGUkLm5leHQodHJ1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBkZWZpbmVOb2RlRGltZW5zaW9ucyhub2RlOiBOZ3hMZWFybmluZ1BhdGhOb2RlKSB7XG4gICAgICAgIGlmIChub2RlLnR5cGUgPT09IE5vZGVUeXBlLkNPTVBFVEVOQ1lfU1RBUlQpIHtcbiAgICAgICAgICAgIG5vZGUuZGltZW5zaW9uID0geyB3aWR0aDogNzUsIGhlaWdodDogNzUgfTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5vZGUuZGltZW5zaW9uID0geyB3aWR0aDogNTAsIGhlaWdodDogNTAgfTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG9uUmVzaXplKCkge1xuICAgICAgICB0aGlzLnVwZGF0ZSQubmV4dCh0cnVlKTtcbiAgICAgICAgdGhpcy5jZW50ZXIkLm5leHQodHJ1ZSk7XG4gICAgICAgIHRoaXMuem9vbVRvRml0JC5uZXh0KHRydWUpO1xuICAgIH1cblxuICAgIG9uQ2VudGVyVmlldygpIHtcbiAgICAgICAgdGhpcy56b29tVG9GaXQkLm5leHQodHJ1ZSk7XG4gICAgICAgIHRoaXMuY2VudGVyJC5uZXh0KHRydWUpO1xuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJncmFwaC1jb250YWluZXJcIj5cbiAgICBAaWYgKG5neExlYXJuaW5nUGF0aCkge1xuICAgICAgICA8bmd4LWdyYXBoXG4gICAgICAgICAgICBbbGlua3NdPVwibmd4TGVhcm5pbmdQYXRoLmVkZ2VzXCJcbiAgICAgICAgICAgIFtub2Rlc109XCJuZ3hMZWFybmluZ1BhdGgubm9kZXNcIlxuICAgICAgICAgICAgW2xheW91dF09XCJsYXlvdXRcIlxuICAgICAgICAgICAgW2xheW91dFNldHRpbmdzXT1cInsgb3JpZW50YXRpb246ICdUQicgfVwiXG4gICAgICAgICAgICBbY3VydmVdPVwiY3VydmVcIlxuICAgICAgICAgICAgW2RyYWdnaW5nRW5hYmxlZF09XCJkcmFnZ2luZ0VuYWJsZWRcIlxuICAgICAgICAgICAgW3Bhbm5pbmdFbmFibGVkXT1cInBhbm5pbmdFbmFibGVkXCJcbiAgICAgICAgICAgIFtlbmFibGVab29tXT1cInpvb21FbmFibGVkXCJcbiAgICAgICAgICAgIFtwYW5Pblpvb21dPVwicGFuT25ab29tXCJcbiAgICAgICAgICAgIFtzaG93TWluaU1hcF09XCJzaG93TWluaU1hcFwiXG4gICAgICAgICAgICBbbWluaU1hcE1heFdpZHRoXT1cIjI1MFwiXG4gICAgICAgICAgICBbbWluaU1hcE1heEhlaWdodF09XCIyNTBcIlxuICAgICAgICAgICAgW3VwZGF0ZSRdPVwidXBkYXRlJFwiXG4gICAgICAgICAgICBbY2VudGVyJF09XCJjZW50ZXIkXCJcbiAgICAgICAgICAgIFt6b29tVG9GaXQkXT1cInpvb21Ub0ZpdCRcIlxuICAgICAgICA+XG4gICAgICAgICAgICA8bmctdGVtcGxhdGUgI2RlZnNUZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICA8c3ZnOm1hcmtlciBpZD1cImFycm93XCIgdmlld0JveD1cIjAgLTUgMTAgMTBcIiByZWZYPVwiOFwiIHJlZlk9XCIwXCIgbWFya2VyV2lkdGg9XCI0XCIgbWFya2VySGVpZ2h0PVwiNFwiIG9yaWVudD1cImF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgPHN2ZzpwYXRoIGQ9XCJNMCwtNUwxMCwwTDAsNVwiIGNsYXNzPVwiYXJyb3ctaGVhZFwiIC8+XG4gICAgICAgICAgICAgICAgPC9zdmc6bWFya2VyPlxuICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSAjbm9kZVRlbXBsYXRlIGxldC1ub2RlPlxuICAgICAgICAgICAgICAgIDxzdmc6ZyBbYXR0ci53aWR0aF09XCJub2RlLmRpbWVuc2lvbi53aWR0aFwiIFthdHRyLmhlaWdodF09XCJub2RlLmRpbWVuc2lvbi5oZWlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHN2Zzpmb3JlaWduT2JqZWN0IFthdHRyLndpZHRoXT1cIm5vZGUuZGltZW5zaW9uLndpZHRoXCIgW2F0dHIuaGVpZ2h0XT1cIm5vZGUuZGltZW5zaW9uLmhlaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1sZWFybmluZy1wYXRoLWdyYXBoLW5vZGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInt7IG5vZGUuaWQgfX1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwibm9kZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NvdXJzZUlkXT1cImNvdXJzZUlkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbm9kZV09XCJub2RlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY29tcGV0ZW5jeVByb2dyZXNzRFRPXT1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBub2RlLnR5cGUgPT09IE5vZGVUeXBlLkNPTVBFVEVOQ1lfU1RBUlQgfHwgbm9kZS50eXBlID09PSBOb2RlVHlwZS5DT01QRVRFTkNZX0VORCA/IGNvbXBldGVuY3lQcm9ncmVzcy5nZXQobm9kZS5saW5rZWRSZXNvdXJjZSkgOiB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJub2RlQ2xpY2tlZC5lbWl0KG5vZGUpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID48L2poaS1sZWFybmluZy1wYXRoLWdyYXBoLW5vZGU+XG4gICAgICAgICAgICAgICAgICAgIDwvc3ZnOmZvcmVpZ25PYmplY3Q+XG4gICAgICAgICAgICAgICAgPC9zdmc6Zz5cbiAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICA8bmctdGVtcGxhdGUgI2xpbmtUZW1wbGF0ZSBsZXQtbGluaz5cbiAgICAgICAgICAgICAgICA8c3ZnOmcgY2xhc3M9XCJlZGdlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzdmc6cGF0aCBjbGFzcz1cImxpbmVcIiBzdHJva2Utd2lkdGg9XCIyXCIgbWFya2VyLWVuZD1cInVybCgjYXJyb3cpXCI+PC9zdmc6cGF0aD5cbiAgICAgICAgICAgICAgICA8L3N2ZzpnPlxuICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSAjY2x1c3RlclRlbXBsYXRlIGxldC1jbHVzdGVyPlxuICAgICAgICAgICAgICAgIDxzdmc6ZyBjbGFzcz1cIm5vZGUgY2x1c3RlclwiPlxuICAgICAgICAgICAgICAgICAgICA8c3ZnOnJlY3Qgcng9XCI1XCIgcnk9XCI1XCIgW2F0dHIud2lkdGhdPVwiY2x1c3Rlci5kaW1lbnNpb24ud2lkdGhcIiBbYXR0ci5oZWlnaHRdPVwiY2x1c3Rlci5kaW1lbnNpb24uaGVpZ2h0XCIgW2F0dHIuZmlsbF09XCJjbHVzdGVyLmRhdGEuY29sb3JcIiAvPlxuICAgICAgICAgICAgICAgIDwvc3ZnOmc+XG4gICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICA8L25neC1ncmFwaD5cbiAgICB9XG4gICAgPGpoaS1sZWFybmluZy1wYXRoLWxlZ2VuZCBjbGFzcz1cImxlZ2VuZFwiIFtub2RlVHlwZXNdPVwibm9kZVR5cGVzXCIgLz5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIElucHV0LCBPbkluaXQsIE91dHB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmd4TGVhcm5pbmdQYXRoTm9kZSwgZ2V0SWNvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb21wZXRlbmN5L2xlYXJuaW5nLXBhdGgubW9kZWwnO1xuaW1wb3J0IHsgTGVhcm5pbmdQYXRoU2VydmljZSB9IGZyb20gJ2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC5zZXJ2aWNlJztcbmltcG9ydCB7IEV4ZXJjaXNlRW50cnksIExlYXJuaW5nUGF0aFN0b3JhZ2VTZXJ2aWNlLCBMZWN0dXJlVW5pdEVudHJ5IH0gZnJvbSAnYXBwL2NvdXJzZS9sZWFybmluZy1wYXRocy9wYXJ0aWNpcGF0ZS9sZWFybmluZy1wYXRoLXN0b3JhZ2Uuc2VydmljZSc7XG5pbXBvcnQgeyBmYUNoZXZyb25Eb3duIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbGVhcm5pbmctcGF0aCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vbGVhcm5pbmctcGF0aC5jb21wb25lbnQuc2NzcyddLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9sZWFybmluZy1wYXRoLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgTGVhcm5pbmdQYXRoQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICBASW5wdXQoKSBsZWFybmluZ1BhdGhJZDogbnVtYmVyO1xuICAgIEBJbnB1dCgpIGNvdXJzZUlkOiBudW1iZXI7XG4gICAgQE91dHB1dCgpIG5vZGVDbGlja2VkOiBFdmVudEVtaXR0ZXI8Tmd4TGVhcm5pbmdQYXRoTm9kZT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5cbiAgICBpc0xvYWRpbmcgPSBmYWxzZTtcbiAgICBwYXRoOiBOZ3hMZWFybmluZ1BhdGhOb2RlW10gPSBbXTtcbiAgICBoaWdobGlnaHRlZE5vZGU/OiBOZ3hMZWFybmluZ1BhdGhOb2RlO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUNoZXZyb25Eb3duID0gZmFDaGV2cm9uRG93bjtcblxuICAgIHByb3RlY3RlZCByZWFkb25seSBnZXRJY29uID0gZ2V0SWNvbjtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGxlYXJuaW5nUGF0aFNlcnZpY2U6IExlYXJuaW5nUGF0aFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgbGVhcm5pbmdQYXRoU3RvcmFnZVNlcnZpY2U6IExlYXJuaW5nUGF0aFN0b3JhZ2VTZXJ2aWNlLFxuICAgICkge31cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICB0aGlzLmxvYWREYXRhKCk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBsb2FkRGF0YSgpIHtcbiAgICAgICAgaWYgKCF0aGlzLmxlYXJuaW5nUGF0aElkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5pc0xvYWRpbmcgPSB0cnVlO1xuICAgICAgICB0aGlzLmxlYXJuaW5nUGF0aFNlcnZpY2UuZ2V0TGVhcm5pbmdQYXRoTmd4UGF0aCh0aGlzLmxlYXJuaW5nUGF0aElkKS5zdWJzY3JpYmUoKG5neExlYXJuaW5nUGF0aFJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBib2R5ID0gbmd4TGVhcm5pbmdQYXRoUmVzcG9uc2UuYm9keSE7XG4gICAgICAgICAgICB0aGlzLmxlYXJuaW5nUGF0aFN0b3JhZ2VTZXJ2aWNlLmdldFJlY29tbWVuZGF0aW9ucyh0aGlzLmxlYXJuaW5nUGF0aElkKT8uZm9yRWFjaCgoZW50cnkpID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgbm9kZTtcbiAgICAgICAgICAgICAgICBpZiAoZW50cnkgaW5zdGFuY2VvZiBMZWN0dXJlVW5pdEVudHJ5KSB7XG4gICAgICAgICAgICAgICAgICAgIG5vZGUgPSBib2R5Lm5vZGVzLmZpbmQoKG5vZGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBub2RlLmxpbmtlZFJlc291cmNlID09PSBlbnRyeS5sZWN0dXJlVW5pdElkICYmIG5vZGUubGlua2VkUmVzb3VyY2VQYXJlbnQgPT09IGVudHJ5LmxlY3R1cmVJZDtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChlbnRyeSBpbnN0YW5jZW9mIEV4ZXJjaXNlRW50cnkpIHtcbiAgICAgICAgICAgICAgICAgICAgbm9kZSA9IGJvZHkubm9kZXMuZmluZCgobm9kZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5vZGUubGlua2VkUmVzb3VyY2UgPT09IGVudHJ5LmV4ZXJjaXNlSWQgJiYgIW5vZGUubGlua2VkUmVzb3VyY2VQYXJlbnQ7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAobm9kZSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnBhdGgucHVzaChub2RlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuaXNMb2FkaW5nID0gZmFsc2U7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGhpZ2hsaWdodE5vZGUobGVhcm5pbmdPYmplY3Q6IExlY3R1cmVVbml0RW50cnkgfCBFeGVyY2lzZUVudHJ5KSB7XG4gICAgICAgIGlmIChsZWFybmluZ09iamVjdCBpbnN0YW5jZW9mIExlY3R1cmVVbml0RW50cnkpIHtcbiAgICAgICAgICAgIHRoaXMuaGlnaGxpZ2h0ZWROb2RlID0gdGhpcy5wYXRoLmZpbmQoKG5vZGUpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbm9kZS5saW5rZWRSZXNvdXJjZSA9PT0gbGVhcm5pbmdPYmplY3QubGVjdHVyZVVuaXRJZCAmJiBub2RlLmxpbmtlZFJlc291cmNlUGFyZW50ID09PSBsZWFybmluZ09iamVjdC5sZWN0dXJlSWQ7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuaGlnaGxpZ2h0ZWROb2RlID0gdGhpcy5wYXRoLmZpbmQoKG5vZGUpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbm9kZS5saW5rZWRSZXNvdXJjZSA9PT0gbGVhcm5pbmdPYmplY3QuZXhlcmNpc2VJZCAmJiAhbm9kZS5saW5rZWRSZXNvdXJjZVBhcmVudDtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgY2xlYXJIaWdobGlnaHRpbmcoKSB7XG4gICAgICAgIHRoaXMuaGlnaGxpZ2h0ZWROb2RlID0gdW5kZWZpbmVkO1xuICAgIH1cbn1cbiIsIkBpZiAoaXNMb2FkaW5nKSB7XG4gICAgPGRpdiBjbGFzcz1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyLWJvcmRlclwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwic3Itb25seVwiPnt7ICdsb2FkaW5nJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxufVxuQGlmICghaXNMb2FkaW5nKSB7XG4gICAgPGRpdj5cbiAgICAgICAgQGZvciAobm9kZSBvZiBwYXRoOyB0cmFjayBub2RlOyBsZXQgbGFzdCA9ICRsYXN0KSB7XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwYXRoLW5vZGVcIj5cbiAgICAgICAgICAgICAgICAgICAgPGpoaS1sZWFybmluZy1wYXRoLWdyYXBoLW5vZGVcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwie3sgbm9kZS5pZCB9fVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuaGlnaGxpZ2h0ZWQtbm9kZV09XCJub2RlLmlkID09PSBoaWdobGlnaHRlZE5vZGU/LmlkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjb3Vyc2VJZF09XCJjb3Vyc2VJZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbbm9kZV09XCJub2RlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJub2RlQ2xpY2tlZC5lbWl0KG5vZGUpXCJcbiAgICAgICAgICAgICAgICAgICAgPjwvamhpLWxlYXJuaW5nLXBhdGgtZ3JhcGgtbm9kZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICBAaWYgKCFsYXN0KSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwYXRoLWVkZ2VcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQ2hldnJvbkRvd25cIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBOZ3hHcmFwaE1vZHVsZSB9IGZyb20gJ0Bzd2ltbGFuZS9uZ3gtZ3JhcGgnO1xuaW1wb3J0IHsgTGVhcm5pbmdQYXRoR3JhcGhDb21wb25lbnQgfSBmcm9tICdhcHAvY291cnNlL2xlYXJuaW5nLXBhdGhzL2xlYXJuaW5nLXBhdGgtZ3JhcGgvbGVhcm5pbmctcGF0aC1ncmFwaC5jb21wb25lbnQnO1xuaW1wb3J0IHsgTGVhcm5pbmdQYXRoTm9kZUNvbXBvbmVudCB9IGZyb20gJ2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC1ncmFwaC9sZWFybmluZy1wYXRoLW5vZGUuY29tcG9uZW50JztcbmltcG9ydCB7IENvbXBldGVuY3lOb2RlRGV0YWlsc0NvbXBvbmVudCB9IGZyb20gJ2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC1ncmFwaC9ub2RlLWRldGFpbHMvY29tcGV0ZW5jeS1ub2RlLWRldGFpbHMuY29tcG9uZW50JztcbmltcG9ydCB7IEV4ZXJjaXNlTm9kZURldGFpbHNDb21wb25lbnQgfSBmcm9tICdhcHAvY291cnNlL2xlYXJuaW5nLXBhdGhzL2xlYXJuaW5nLXBhdGgtZ3JhcGgvbm9kZS1kZXRhaWxzL2V4ZXJjaXNlLW5vZGUtZGV0YWlscy5jb21wb25lbnQnO1xuaW1wb3J0IHsgTGVjdHVyZVVuaXROb2RlRGV0YWlsc0NvbXBvbmVudCB9IGZyb20gJ2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC1ncmFwaC9ub2RlLWRldGFpbHMvbGVjdHVyZS11bml0LW5vZGUtZGV0YWlscy5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc0NvbXBldGVuY2llc01vZHVsZSB9IGZyb20gJ2FwcC9jb3Vyc2UvY29tcGV0ZW5jaWVzL2NvbXBldGVuY3kubW9kdWxlJztcbmltcG9ydCB7IExlYXJuaW5nUGF0aENvbXBvbmVudCB9IGZyb20gJ2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC1ncmFwaC9sZWFybmluZy1wYXRoLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBMZWFybmluZ1BhdGhMZWdlbmRDb21wb25lbnQgfSBmcm9tICdhcHAvY291cnNlL2xlYXJuaW5nLXBhdGhzL2xlYXJuaW5nLXBhdGgtZ3JhcGgvbGVhcm5pbmctcGF0aC1sZWdlbmQuY29tcG9uZW50JztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZSwgTmd4R3JhcGhNb2R1bGUsIEFydGVtaXNDb21wZXRlbmNpZXNNb2R1bGVdLFxuICAgIGRlY2xhcmF0aW9uczogW1xuICAgICAgICBMZWFybmluZ1BhdGhHcmFwaENvbXBvbmVudCxcbiAgICAgICAgTGVhcm5pbmdQYXRoTm9kZUNvbXBvbmVudCxcbiAgICAgICAgQ29tcGV0ZW5jeU5vZGVEZXRhaWxzQ29tcG9uZW50LFxuICAgICAgICBFeGVyY2lzZU5vZGVEZXRhaWxzQ29tcG9uZW50LFxuICAgICAgICBMZWN0dXJlVW5pdE5vZGVEZXRhaWxzQ29tcG9uZW50LFxuICAgICAgICBMZWFybmluZ1BhdGhDb21wb25lbnQsXG4gICAgICAgIExlYXJuaW5nUGF0aExlZ2VuZENvbXBvbmVudCxcbiAgICBdLFxuICAgIGV4cG9ydHM6IFtMZWFybmluZ1BhdGhHcmFwaENvbXBvbmVudCwgTGVhcm5pbmdQYXRoQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc0xlYXJuaW5nUGF0aEdyYXBoTW9kdWxlIHt9XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE91dHB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZmFBcnJvd3NSb3RhdGUsIGZhQXJyb3dzVG9FeWUsIGZhWG1hcmsgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgTGVhcm5pbmdQYXRoSW5mb3JtYXRpb25EVE8gfSBmcm9tICdhcHAvZW50aXRpZXMvY29tcGV0ZW5jeS9sZWFybmluZy1wYXRoLm1vZGVsJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbGVhcm5pbmctcGF0aC1wcm9ncmVzcy1uYXYnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9sZWFybmluZy1wYXRoLXByb2dyZXNzLW5hdi5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIExlYXJuaW5nUGF0aFByb2dyZXNzTmF2Q29tcG9uZW50IHtcbiAgICBASW5wdXQoKSBsZWFybmluZ1BhdGg6IExlYXJuaW5nUGF0aEluZm9ybWF0aW9uRFRPO1xuICAgIEBPdXRwdXQoKSBvblJlZnJlc2g6IEV2ZW50RW1pdHRlcjx2b2lkPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgICBAT3V0cHV0KCkgb25DZW50ZXJWaWV3OiBFdmVudEVtaXR0ZXI8dm9pZD4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gICAgQE91dHB1dCgpIG9uQ2xvc2U6IEV2ZW50RW1pdHRlcjx2b2lkPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICAgIGZhWG1hcmsgPSBmYVhtYXJrO1xuICAgIGZhQXJyb3dzVG9FeWUgPSBmYUFycm93c1RvRXllO1xuICAgIGZhQXJyb3dzUm90YXRlID0gZmFBcnJvd3NSb3RhdGU7XG59XG4iLCI8ZGl2IGNsYXNzPVwicm93XCI+XG4gICAgPGRpdiBjbGFzcz1cImNvbFwiPlxuICAgICAgICBAaWYgKGxlYXJuaW5nUGF0aCkge1xuICAgICAgICAgICAgPGgzPnt7IGxlYXJuaW5nUGF0aC51c2VyPy5uYW1lIH19ICh7eyBsZWFybmluZ1BhdGgudXNlcj8ubG9naW4gfX0pPC9oMz5cbiAgICAgICAgfVxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0b1wiPlxuICAgICAgICA8YnV0dG9uIGlkPVwicmVmcmVzaC1idXR0b25cIiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBtLTFcIiAoY2xpY2spPVwib25SZWZyZXNoLmVtaXQoKVwiPlxuICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFBcnJvd3NSb3RhdGVcIiBuZ2JUb29sdGlwPVwie3sgJ2FydGVtaXNBcHAubGVhcm5pbmdQYXRoLmdyYXBoLnByb2dyZXNzTmF2LnJlZnJlc2gnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVwiPjwvZmEtaWNvbj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxidXR0b24gaWQ9XCJjZW50ZXItYnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgbS0xXCIgKGNsaWNrKT1cIm9uQ2VudGVyVmlldy5lbWl0KClcIj5cbiAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhQXJyb3dzVG9FeWVcIiBuZ2JUb29sdGlwPVwie3sgJ2FydGVtaXNBcHAubGVhcm5pbmdQYXRoLmdyYXBoLnByb2dyZXNzTmF2LmNlbnRlcicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XCI+PC9mYS1pY29uPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvbiBpZD1cImNsb3NlLWJ1dHRvblwiIGNsYXNzPVwiYnRuIGJ0bi1kYW5nZXIgbS0xXCIgKGNsaWNrKT1cIm9uQ2xvc2UuZW1pdCgpXCI+XG4gICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVhtYXJrXCIgbmdiVG9vbHRpcD1cInt7ICdlbnRpdHkuYWN0aW9uLmNsb3NlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cIj48L2ZhLWljb24+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBWaWV3Q2hpbGQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBOZ2JBY3RpdmVNb2RhbCB9IGZyb20gJ0BuZy1ib290c3RyYXAvbmctYm9vdHN0cmFwJztcbmltcG9ydCB7IExlYXJuaW5nUGF0aEdyYXBoQ29tcG9uZW50IH0gZnJvbSAnYXBwL2NvdXJzZS9sZWFybmluZy1wYXRocy9sZWFybmluZy1wYXRoLWdyYXBoL2xlYXJuaW5nLXBhdGgtZ3JhcGguY29tcG9uZW50JztcbmltcG9ydCB7IExlYXJuaW5nUGF0aEluZm9ybWF0aW9uRFRPLCBOZ3hMZWFybmluZ1BhdGhOb2RlLCBOb2RlVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb21wZXRlbmN5L2xlYXJuaW5nLXBhdGgubW9kZWwnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1sZWFybmluZy1wYXRoLXByb2dyZXNzLW1vZGFsJyxcbiAgICBzdHlsZVVybHM6IFsnLi9sZWFybmluZy1wYXRoLXByb2dyZXNzLW1vZGFsLmNvbXBvbmVudC5zY3NzJ10sXG4gICAgdGVtcGxhdGVVcmw6ICcuL2xlYXJuaW5nLXBhdGgtcHJvZ3Jlc3MtbW9kYWwuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBMZWFybmluZ1BhdGhQcm9ncmVzc01vZGFsQ29tcG9uZW50IHtcbiAgICBASW5wdXQoKSBjb3Vyc2VJZDogbnVtYmVyO1xuICAgIEBJbnB1dCgpIGxlYXJuaW5nUGF0aDogTGVhcm5pbmdQYXRoSW5mb3JtYXRpb25EVE87XG4gICAgQFZpZXdDaGlsZCgnbGVhcm5pbmdQYXRoR3JhcGhDb21wb25lbnQnKSBsZWFybmluZ1BhdGhHcmFwaENvbXBvbmVudDogTGVhcm5pbmdQYXRoR3JhcGhDb21wb25lbnQ7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBhY3RpdmVNb2RhbDogTmdiQWN0aXZlTW9kYWwsXG4gICAgICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgKSB7fVxuXG4gICAgY2xvc2UoKSB7XG4gICAgICAgIHRoaXMuYWN0aXZlTW9kYWwuY2xvc2UoKTtcbiAgICB9XG5cbiAgICBvbk5vZGVDbGlja2VkKG5vZGU6IE5neExlYXJuaW5nUGF0aE5vZGUpIHtcbiAgICAgICAgaWYgKG5vZGUudHlwZSA9PT0gTm9kZVR5cGUuQ09NUEVURU5DWV9TVEFSVCB8fCBub2RlLnR5cGUgPT09IE5vZGVUeXBlLkNPTVBFVEVOQ1lfRU5EKSB7XG4gICAgICAgICAgICB0aGlzLm5hdmlnYXRlVG9Db21wZXRlbmN5KG5vZGUpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbmF2aWdhdGVUb0NvbXBldGVuY3kobm9kZTogTmd4TGVhcm5pbmdQYXRoTm9kZSkge1xuICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJ2NvdXJzZXMnLCB0aGlzLmNvdXJzZUlkLCAnY29tcGV0ZW5jaWVzJywgbm9kZS5saW5rZWRSZXNvdXJjZV0pO1xuICAgICAgICB0aGlzLmNsb3NlKCk7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cIm1vZGFsLWNvbnRhaW5lclwiPlxuICAgIDxkaXYgY2xhc3M9XCJyb3cgbW9kYWwtbmF2XCI+XG4gICAgICAgIDxqaGktbGVhcm5pbmctcGF0aC1wcm9ncmVzcy1uYXZcbiAgICAgICAgICAgIFtsZWFybmluZ1BhdGhdPVwibGVhcm5pbmdQYXRoXCJcbiAgICAgICAgICAgIChvblJlZnJlc2gpPVwibGVhcm5pbmdQYXRoR3JhcGhDb21wb25lbnQucmVmcmVzaERhdGEoKTsgbGVhcm5pbmdQYXRoR3JhcGhDb21wb25lbnQub25DZW50ZXJWaWV3KClcIlxuICAgICAgICAgICAgKG9uQ2VudGVyVmlldyk9XCJsZWFybmluZ1BhdGhHcmFwaENvbXBvbmVudC5vbkNlbnRlclZpZXcoKVwiXG4gICAgICAgICAgICAob25DbG9zZSk9XCJjbG9zZSgpXCJcbiAgICAgICAgPjwvamhpLWxlYXJuaW5nLXBhdGgtcHJvZ3Jlc3MtbmF2PlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgQGlmIChjb3Vyc2VJZCAmJiBsZWFybmluZ1BhdGgpIHtcbiAgICAgICAgICAgIDxqaGktbGVhcm5pbmctcGF0aC1ncmFwaFxuICAgICAgICAgICAgICAgICNsZWFybmluZ1BhdGhHcmFwaENvbXBvbmVudFxuICAgICAgICAgICAgICAgIGNsYXNzPVwiZ3JhcGhcIlxuICAgICAgICAgICAgICAgIFtjb3Vyc2VJZF09XCJjb3Vyc2VJZFwiXG4gICAgICAgICAgICAgICAgW2xlYXJuaW5nUGF0aElkXT1cImxlYXJuaW5nUGF0aC5pZCFcIlxuICAgICAgICAgICAgICAgIFtwYW5uaW5nRW5hYmxlZF09XCJ0cnVlXCJcbiAgICAgICAgICAgICAgICBbem9vbUVuYWJsZWRdPVwidHJ1ZVwiXG4gICAgICAgICAgICAgICAgW3Bhbk9uWm9vbV09XCJ0cnVlXCJcbiAgICAgICAgICAgICAgICBbc2hvd01pbmlNYXBdPVwidHJ1ZVwiXG4gICAgICAgICAgICAgICAgKG5vZGVDbGlja2VkKT1cIm9uTm9kZUNsaWNrZWQoJGV2ZW50KVwiXG4gICAgICAgICAgICA+PC9qaGktbGVhcm5pbmctcGF0aC1ncmFwaD5cbiAgICAgICAgfVxuICAgIDwvZGl2PlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBMZWFybmluZ1BhdGhQcm9ncmVzc05hdkNvbXBvbmVudCB9IGZyb20gJ2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvcHJvZ3Jlc3MtbW9kYWwvbGVhcm5pbmctcGF0aC1wcm9ncmVzcy1uYXYuY29tcG9uZW50JztcbmltcG9ydCB7IExlYXJuaW5nUGF0aFByb2dyZXNzTW9kYWxDb21wb25lbnQgfSBmcm9tICdhcHAvY291cnNlL2xlYXJuaW5nLXBhdGhzL3Byb2dyZXNzLW1vZGFsL2xlYXJuaW5nLXBhdGgtcHJvZ3Jlc3MtbW9kYWwuY29tcG9uZW50JztcbmltcG9ydCB7IEFydGVtaXNMZWFybmluZ1BhdGhHcmFwaE1vZHVsZSB9IGZyb20gJ2FwcC9jb3Vyc2UvbGVhcm5pbmctcGF0aHMvbGVhcm5pbmctcGF0aC1ncmFwaC9sZWFybmluZy1wYXRoLWdyYXBoLm1vZHVsZSc7XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW0FydGVtaXNTaGFyZWRNb2R1bGUsIEFydGVtaXNMZWFybmluZ1BhdGhHcmFwaE1vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbTGVhcm5pbmdQYXRoUHJvZ3Jlc3NOYXZDb21wb25lbnQsIExlYXJuaW5nUGF0aFByb2dyZXNzTW9kYWxDb21wb25lbnRdLFxuICAgIGV4cG9ydHM6IFtMZWFybmluZ1BhdGhQcm9ncmVzc01vZGFsQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc0xlYXJuaW5nUGF0aFByb2dyZXNzTW9kdWxlIHt9XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLQSxTQUFTLGVBQWUsVUFBVSxRQUFRLGlCQUFpQixjQUFjLG1CQUFtQjtBQWlDdEYsU0FBVUEsU0FBUSxNQUF5QjtBQUU3QyxNQUFJLENBQUMsS0FBSyxNQUFNO0FBQ1osV0FBTzs7QUFJWCxNQUFJLEtBQUssU0FBUyxTQUFTLFlBQVksS0FBSyxTQUFTLFNBQVMsY0FBYztBQUN4RSxRQUFJLEtBQUssV0FBVztBQUNoQixhQUFPO1dBQ0o7QUFDSCxhQUFPOzs7QUFJZixRQUFNLFFBQVE7SUFDVixDQUFDLFNBQVMsZ0JBQWdCLEdBQUc7SUFDN0IsQ0FBQyxTQUFTLGNBQWMsR0FBRztJQUMzQixDQUFDLFNBQVMsV0FBVyxHQUFHO0lBQ3hCLENBQUMsU0FBUyxTQUFTLEdBQUc7O0FBRTFCLFNBQU8sTUFBTSxLQUFLLElBQUk7QUFDMUI7QUF2REEsSUErRFk7QUEvRFo7O0FBK0RBLEtBQUEsU0FBWUMsV0FBUTtBQUNoQixNQUFBQSxVQUFBLGtCQUFBLElBQUE7QUFDQSxNQUFBQSxVQUFBLGdCQUFBLElBQUE7QUFDQSxNQUFBQSxVQUFBLGFBQUEsSUFBQTtBQUNBLE1BQUFBLFVBQUEsV0FBQSxJQUFBO0FBQ0EsTUFBQUEsVUFBQSxVQUFBLElBQUE7QUFDQSxNQUFBQSxVQUFBLGNBQUEsSUFBQTtJQUNKLEdBUFksYUFBQSxXQUFRLENBQUEsRUFBQTs7Ozs7QUNwRXBCLFNBQVMsa0JBQWtCOztBQUEzQixJQU9hLDRCQStHUyxjQUlULGtCQWtCQTtBQTVJYjs7QUFDQTtBQU1NLElBQU8sNkJBQVAsTUFBTyw0QkFBMEI7TUFDbEIsOEJBQTJELG9CQUFJLElBQUc7TUFRbkYscUJBQXFCLGdCQUF3QixjQUFnQztBQUN6RSxhQUFLLDRCQUE0QixJQUFJLGdCQUFnQixDQUFBLENBQUU7QUFDdkQsWUFBSSxZQUFZLGFBQWEsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLEVBQUUsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLGFBQWEsTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLFVBQVUsRUFBRSxDQUFDO0FBQzVILGVBQU8sV0FBVztBQUNkLGdCQUFNLGNBQWMsYUFBYSxNQUFNLEtBQUssQ0FBQyxTQUFTLEtBQUssTUFBTSxTQUFTO0FBQzFFLGNBQUksWUFBWSxTQUFTLFNBQVMsY0FBYztBQUM1QyxpQkFBSyw0QkFBNEIsSUFBSSxjQUFjLEVBQUcsS0FBSyxJQUFJLGlCQUFpQixZQUFZLHNCQUF1QixZQUFZLGNBQWUsQ0FBQztxQkFDeEksWUFBWSxTQUFTLFNBQVMsVUFBVTtBQUMvQyxpQkFBSyw0QkFBNEIsSUFBSSxjQUFjLEVBQUcsS0FBSyxJQUFJLGNBQWMsWUFBWSxjQUFlLENBQUM7O0FBRTdHLGdCQUFNLE9BQU8sYUFBYSxNQUFNLEtBQUssQ0FBQ0MsVUFBU0EsTUFBSyxVQUFVLFNBQVM7QUFDdkUsY0FBSSxNQUFNO0FBQ04sd0JBQVksS0FBSztpQkFDZDtBQUNILHdCQUFZOzs7TUFHeEI7TUFPQSxtQkFBbUIsZ0JBQXNCO0FBQ3JDLGVBQU8sS0FBSyw0QkFBNEIsSUFBSSxjQUFjO01BQzlEO01BUUEsc0JBQXNCLGdCQUF3QixPQUFvQjtBQUM5RCxZQUFJLENBQUMsS0FBSyw0QkFBNEIsSUFBSSxjQUFjLEdBQUc7QUFDdkQsaUJBQU87O0FBRVgsWUFBSSxDQUFDLE9BQU87QUFDUixpQkFBTyxDQUFDLENBQUMsS0FBSyw0QkFBNEIsSUFBSSxjQUFjLEdBQUc7O0FBRW5FLGNBQU0sUUFBUSxLQUFLLFdBQVcsZ0JBQWdCLEtBQUs7QUFDbkQsZUFBTyxLQUFLLFNBQVMsUUFBUSxJQUFJLEtBQUssNEJBQTRCLElBQUksY0FBYyxFQUFHO01BQzNGO01BVUEsc0JBQXNCLGdCQUF3QixPQUFvQjtBQUM5RCxZQUFJLENBQUMsS0FBSyxzQkFBc0IsZ0JBQWdCLEtBQUssR0FBRztBQUNwRCxpQkFBTzs7QUFFWCxZQUFJLENBQUMsT0FBTztBQUNSLGlCQUFPLEtBQUssNEJBQTRCLElBQUksY0FBYyxFQUFHLENBQUM7O0FBRWxFLGNBQU0sWUFBWSxLQUFLLFdBQVcsZ0JBQWdCLEtBQUssSUFBSTtBQUMzRCxlQUFPLEtBQUssNEJBQTRCLElBQUksY0FBYyxFQUFHLFNBQVM7TUFDMUU7TUFRQSxzQkFBc0IsZ0JBQXdCLE9BQW9CO0FBQzlELFlBQUksQ0FBQyxLQUFLLDRCQUE0QixJQUFJLGNBQWMsS0FBSyxDQUFDLE9BQU87QUFDakUsaUJBQU87O0FBRVgsZUFBTyxJQUFJLEtBQUssV0FBVyxnQkFBZ0IsS0FBSztNQUNwRDtNQVNBLHNCQUFzQixnQkFBd0IsT0FBb0I7QUFDOUQsWUFBSSxDQUFDLEtBQUssc0JBQXNCLGdCQUFnQixLQUFLLEdBQUc7QUFDcEQsaUJBQU87O0FBRVgsY0FBTSxZQUFZLEtBQUssV0FBVyxnQkFBZ0IsS0FBTSxJQUFJO0FBQzVELGVBQU8sS0FBSyw0QkFBNEIsSUFBSSxjQUFjLEVBQUcsU0FBUztNQUMxRTtNQUVRLFdBQVcsZ0JBQXdCLE9BQW1CO0FBQzFELFlBQUksQ0FBQyxLQUFLLDRCQUE0QixJQUFJLGNBQWMsR0FBRztBQUN2RCxpQkFBTzs7QUFFWCxlQUFPLEtBQUssNEJBQTRCLElBQUksY0FBYyxFQUFHLFVBQVUsQ0FBQyxNQUFtQjtBQUN2RixpQkFBTyxNQUFNLE9BQU8sQ0FBQztRQUN6QixDQUFDO01BQ0w7O3lCQTVHUyw2QkFBMEI7TUFBQTttRUFBMUIsNkJBQTBCLFNBQTFCLDRCQUEwQixXQUFBLFlBRGIsT0FBTSxDQUFBOztBQWdIMUIsSUFBZ0IsZUFBaEIsTUFBNEI7O0FBSTVCLElBQU8sbUJBQVAsTUFBTywwQkFBeUIsYUFBWTtNQUNyQztNQUNBO01BRVQsWUFBWSxXQUFtQixlQUFxQjtBQUNoRCxjQUFLO0FBQ0wsYUFBSyxZQUFZO0FBQ2pCLGFBQUssZ0JBQWdCO01BQ3pCO01BRUEsT0FBTyxPQUFtQjtBQUN0QixZQUFJLGlCQUFpQixtQkFBa0I7QUFDbkMsaUJBQU8sS0FBSyxjQUFjLE1BQU0sYUFBYSxLQUFLLGtCQUFrQixNQUFNOztBQUU5RSxlQUFPO01BQ1g7O0FBR0UsSUFBTyxnQkFBUCxNQUFPLHVCQUFzQixhQUFZO01BQ2xDO01BRVQsWUFBWSxZQUFrQjtBQUMxQixjQUFLO0FBQ0wsYUFBSyxhQUFhO01BQ3RCO01BRUEsT0FBTyxPQUFtQjtBQUN0QixZQUFJLGlCQUFpQixnQkFBZTtBQUNoQyxpQkFBTyxLQUFLLGVBQWUsTUFBTTs7QUFFckMsZUFBTztNQUNYOzs7Ozs7QUN6SkosU0FBUyxjQUFBQyxtQkFBa0I7QUFFM0IsU0FBUyxrQkFBZ0M7QUFHekMsU0FBUyxLQUFLLFdBQVc7OztBQUx6QixJQVNhO0FBVGI7O0FBTUE7O0FBR00sSUFBTyxzQkFBUCxNQUFPLHFCQUFtQjtNQUloQjtNQUNBO01BSkosY0FBYztNQUV0QixZQUNZLFlBQ0EsNEJBQXNEO0FBRHRELGFBQUEsYUFBQTtBQUNBLGFBQUEsNkJBQUE7TUFDVDtNQUVILG9CQUFvQixVQUFnQjtBQUNoQyxlQUFPLEtBQUssV0FBVyxJQUFVLEdBQUcsS0FBSyxXQUFXLFlBQVksUUFBUSwwQkFBMEIsTUFBTSxFQUFFLFNBQVMsV0FBVSxDQUFFO01BQ25JO01BRUEsc0NBQXNDLFVBQWdCO0FBQ2xELGVBQU8sS0FBSyxXQUFXLElBQVUsR0FBRyxLQUFLLFdBQVcsWUFBWSxRQUFRLG9DQUFvQyxNQUFNLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDN0k7TUFFQSx5QkFBeUIsVUFBZ0I7QUFDckMsZUFBTyxLQUFLLFdBQVcsSUFBMkIsR0FBRyxLQUFLLFdBQVcsWUFBWSxRQUFRLHlCQUF5QixFQUFFLFNBQVMsV0FBVSxDQUFFO01BQzdJO01BRUEsZ0JBQWdCLGdCQUFzQjtBQUNsQyxlQUFPLEtBQUssV0FBVyxJQUFnQyxHQUFHLEtBQUssV0FBVyxrQkFBa0IsY0FBYyxJQUFJLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDekk7TUFFQSx3QkFBd0IsZ0JBQXNCO0FBQzFDLGVBQU8sS0FBSyxXQUFXLElBQXdCLEdBQUcsS0FBSyxXQUFXLGtCQUFrQixjQUFjLFVBQVUsRUFBRSxTQUFTLFdBQVUsQ0FBRSxFQUFFLEtBQ2pJLElBQUksQ0FBQyw0QkFBMkI7QUFDNUIsaUJBQU8sS0FBSyxnQ0FBZ0MsdUJBQXVCO1FBQ3ZFLENBQUMsQ0FBQztNQUVWO01BRUEsdUJBQXVCLGdCQUFzQjtBQUN6QyxlQUFPLEtBQUssV0FBVyxJQUF3QixHQUFHLEtBQUssV0FBVyxrQkFBa0IsY0FBYyxTQUFTLEVBQUUsU0FBUyxXQUFVLENBQUUsRUFBRSxLQUNoSSxJQUFJLENBQUMsNEJBQTJCO0FBQzVCLGlCQUFPLEtBQUssZ0NBQWdDLHVCQUF1QjtRQUN2RSxDQUFDLEdBQ0QsSUFBSSxDQUFDLDRCQUEyQjtBQUM1QixlQUFLLDJCQUEyQixxQkFBcUIsZ0JBQWdCLHdCQUF3QixJQUFLO1FBQ3RHLENBQUMsQ0FBQztNQUVWO01BRVEsZ0NBQWdDLHlCQUF5RDtBQUM3RixnQ0FBd0IsS0FBTSxVQUFVLENBQUE7QUFDeEMsZ0NBQXdCLEtBQU0sVUFBVSxDQUFBO0FBQ3hDLGVBQU87TUFDWDtNQUVBLGtCQUFrQixVQUFnQjtBQUM5QixlQUFPLEtBQUssV0FBVyxJQUFZLEdBQUcsS0FBSyxXQUFXLFlBQVksUUFBUSxxQkFBcUIsRUFBRSxTQUFTLFdBQVUsQ0FBRTtNQUMxSDtNQUVBLHFDQUFxQyxnQkFBc0I7QUFDdkQsZUFBTyxLQUFLLFdBQVcsSUFBNEMsR0FBRyxLQUFLLFdBQVcsa0JBQWtCLGNBQWMsd0JBQXdCLEVBQUUsU0FBUyxXQUFVLENBQUU7TUFDeks7O3lCQXZEUyxzQkFBbUIsdUJBQUEsYUFBQSxHQUFBLHVCQUFBLDBCQUFBLENBQUE7TUFBQTtvRUFBbkIsc0JBQW1CLFNBQW5CLHFCQUFtQixXQUFBLFlBRE4sT0FBTSxDQUFBOzs7Ozs7QUNSaEMsU0FBUyxXQUFXLGNBQWMsT0FBZSxjQUFjOzs7Ozs7QUNLM0MsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTs7QUFNSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUFMUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxRQUFBLE9BQUEsV0FBQSxRQUFBLENBQUEsRUFBcUMsY0FBQSxJQUFBLEVBQUEsY0FBQSwwQkFBQSxHQUFBLEdBQUEsT0FBQSxlQUFBLE9BQUEsV0FBQSxRQUFBLENBQUEsQ0FBQTs7Ozs7QUFRekMsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUE2RixJQUFBLHFCQUFBLEdBQUEsVUFBQTtBQUFRLElBQUEsMkJBQUE7QUFDekcsSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFBd0YsSUFBQSxxQkFBQSxHQUFBLFVBQUE7QUFBUSxJQUFBLDJCQUFBO0FBQ3BHLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7Ozs7QUFHQSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBRFMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLE9BQUEsV0FBQSxhQUFBLDRCQUFBOzs7OztBQXBCakIsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxxRUFBQSxHQUFBLENBQUE7QUFRQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUFzQixJQUFBLDJCQUFBO0FBQzVCLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxzRUFBQSxHQUFBLENBQUEsRUFFQyxJQUFBLHNFQUFBLEdBQUEsQ0FBQTtBQUlMLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsc0VBQUEsR0FBQSxDQUFBO0FBR0osSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUFtQixJQUFBLHdCQUFBLElBQUEsd0JBQUEsQ0FBQTtBQUFpSCxJQUFBLDJCQUFBO0FBQ3hJLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxJQUFBOzs7O0FBdEJnQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxXQUFBLFdBQUEsSUFBQSxFQUFBO0FBUU0sSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxPQUFBLFdBQUEsS0FBQTtBQUNOLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLFdBQUEsTUFBQSxLQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxXQUFBLFdBQUEsS0FBQSxFQUFBO0FBSUosSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsV0FBQSxjQUFBLEtBQUEsRUFBQTtBQUlxQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsT0FBQSxRQUFBLEVBQXFCLGNBQUEsT0FBQSxVQUFBLEVBQUEsV0FBQSxPQUFBLE9BQUE7OztBRHhCdEUsSUFXYTtBQVhiOztBQUVBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7QUFNTSxJQUFPLGlDQUFQLE1BQU8sZ0NBQThCO01BYTNCO01BQ0E7TUFiSDtNQUNBO01BQ0E7TUFDQyxtQkFBbUIsSUFBSSxhQUFZO01BQ3BDO01BRVQsWUFBWTtNQUVPLFVBQVVDO01BQ1YsaUJBQWlCQztNQUVwQyxZQUNZLG1CQUNBLGNBQTBCO0FBRDFCLGFBQUEsb0JBQUE7QUFDQSxhQUFBLGVBQUE7TUFDVDtNQUVILFdBQVE7QUFDSixZQUFJLENBQUMsS0FBSyxZQUFZO0FBQ2xCLGVBQUssU0FBUTs7TUFFckI7TUFDUSxXQUFRO0FBQ1osYUFBSyxZQUFZO0FBQ2pCLGFBQUssa0JBQWtCLFNBQVMsS0FBSyxjQUFlLEtBQUssUUFBUyxFQUFFLFVBQVU7VUFDMUUsTUFBTSxDQUFDLFNBQVE7QUFDWCxpQkFBSyxhQUFhLEtBQUs7QUFDdkIsaUJBQUssWUFBWTtBQUNqQixpQkFBSyxpQkFBaUIsS0FBSyxLQUFLLFVBQVU7VUFDOUM7VUFDQSxPQUFPLENBQUMsa0JBQXFDLFFBQVEsS0FBSyxjQUFjLGFBQWE7U0FDeEY7TUFDTDtNQUVBLElBQUksV0FBUTtBQUNSLGVBQU8sWUFBWSxLQUFLLGtCQUFtQjtNQUMvQztNQUVBLElBQUksYUFBVTtBQUNWLGVBQU8sY0FBYyxLQUFLLG9CQUFxQixLQUFLLFdBQVksZ0JBQWlCO01BQ3JGO01BRUEsSUFBSSxVQUFPO0FBQ1AsZUFBTyxXQUFXLEtBQUssb0JBQXFCLEtBQUssV0FBWSxnQkFBaUI7TUFDbEY7O3lCQTVDUyxpQ0FBOEIsZ0NBQUEsaUJBQUEsR0FBQSxnQ0FBQSxZQUFBLENBQUE7TUFBQTtpRUFBOUIsaUNBQThCLFdBQUEsQ0FBQSxDQUFBLDZCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLGNBQUEsZ0JBQUEsWUFBQSxjQUFBLG9CQUFBLHFCQUFBLEdBQUEsU0FBQSxFQUFBLGtCQUFBLG1CQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxjQUFBLFNBQUEsR0FBQSxDQUFBLGFBQUEsUUFBQSxHQUFBLFFBQUEsY0FBQSxZQUFBLEdBQUEsQ0FBQSxnQkFBQSxrQ0FBQSxHQUFBLFNBQUEsY0FBQSxpQkFBQSxHQUFBLENBQUEsZ0JBQUEsa0NBQUEsR0FBQSxTQUFBLGNBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsd0NBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNYM0MsVUFBQSx5QkFBQSxHQUFBLHVEQUFBLElBQUEsQ0FBQTs7O0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsYUFBQSxJQUFBLEVBQUE7Ozs7O3FGRFdhLGdDQUE4QixFQUFBLFdBQUEsaUNBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFWDNDLFNBQVMsYUFBQUMsWUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFlLFVBQUFDLGVBQWM7Ozs7OztBQ0szQyxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBOztBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQURhLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLFFBQUEsT0FBQSxTQUFBLElBQUEsQ0FBQSxFQUErQixjQUFBLElBQUEsRUFBQSxjQUFBLDBCQUFBLEdBQUEsR0FBQSxPQUFBLGVBQUEsT0FBQSxTQUFBLElBQUEsQ0FBQSxDQUFBOzs7OztBQUp4RCxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLG1FQUFBLEdBQUEsQ0FBQTtBQUdBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBO0FBQW9CLElBQUEsMkJBQUE7QUFDOUIsSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxJQUFBOzs7O0FBUGdCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLFNBQUEsT0FBQSxJQUFBLEVBQUE7QUFHTSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLE9BQUEsU0FBQSxLQUFBOzs7QURQdEIsSUFXYTtBQVhiOztBQUVBO0FBQ0E7QUFDQTtBQUNBOzs7O0FBTU0sSUFBTywrQkFBUCxNQUFPLDhCQUE0QjtNQVF6QjtNQUNBO01BUkg7TUFDQTtNQUNDLGlCQUFpQixJQUFJRixjQUFZO01BRTNDLFlBQVk7TUFFWixZQUNZLGlCQUNBLGNBQTBCO0FBRDFCLGFBQUEsa0JBQUE7QUFDQSxhQUFBLGVBQUE7TUFDVDtNQUVILFdBQVE7QUFDSixZQUFJLENBQUMsS0FBSyxVQUFVO0FBQ2hCLGVBQUssU0FBUTs7TUFFckI7TUFDUSxXQUFRO0FBQ1osYUFBSyxZQUFZO0FBQ2pCLGFBQUssZ0JBQWdCLEtBQUssS0FBSyxVQUFVLEVBQUUsVUFBVTtVQUNqRCxNQUFNLENBQUMscUJBQW9CO0FBQ3ZCLGlCQUFLLFdBQVcsaUJBQWlCO0FBQ2pDLGlCQUFLLFlBQVk7QUFDakIsaUJBQUssZUFBZSxLQUFLLEtBQUssUUFBUTtVQUMxQztVQUNBLE9BQU8sQ0FBQyxrQkFBcUMsUUFBUSxLQUFLLGNBQWMsYUFBYTtTQUN4RjtNQUNMO01BRW1CLFVBQVU7TUFDVixpQkFBaUI7O3lCQTlCM0IsK0JBQTRCLGdDQUFBLGVBQUEsR0FBQSxnQ0FBQSxZQUFBLENBQUE7TUFBQTtpRUFBNUIsK0JBQTRCLFdBQUEsQ0FBQSxDQUFBLDJCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsWUFBQSxjQUFBLFVBQUEsV0FBQSxHQUFBLFNBQUEsRUFBQSxnQkFBQSxpQkFBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsYUFBQSxRQUFBLEdBQUEsUUFBQSxjQUFBLFlBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxzQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1h6QyxVQUFBLHlCQUFBLEdBQUEscURBQUEsSUFBQSxDQUFBOzs7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxXQUFBLElBQUEsRUFBQTs7Ozs7cUZEV2EsOEJBQTRCLEVBQUEsV0FBQSwrQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVYekMsU0FBUyxhQUFBRyxZQUFXLGdCQUFBQyxlQUFjLFNBQUFDLFFBQWUsVUFBQUMsZUFBYzs7Ozs7O0FDSzNDLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7O0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsUUFBQSxPQUFBLFlBQUEsSUFBQSxDQUFBLEVBQW1DLGNBQUEsSUFBQSxFQUFBLGNBQUEsMEJBQUEsR0FBQSxHQUFBLE9BQUEsZUFBQSxPQUFBLFlBQUEsSUFBQSxDQUFBLENBQUE7Ozs7O0FBSjVELElBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsc0VBQUEsR0FBQSxDQUFBO0FBR0EsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBc0IsSUFBQSwyQkFBQTtBQUNoQyxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLElBQUE7Ozs7QUFQZ0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsWUFBQSxPQUFBLElBQUEsRUFBQTtBQUdNLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsT0FBQSxZQUFBLElBQUE7OztBRFB0QixJQVdhO0FBWGI7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFNTSxJQUFPLGtDQUFQLE1BQU8saUNBQStCO01BUzVCO01BQ0E7TUFUSDtNQUVBO01BQ0Msb0JBQW9CLElBQUlGLGNBQVk7TUFFOUMsWUFBWTtNQUVaLFlBQ1ksb0JBQ0EsY0FBMEI7QUFEMUIsYUFBQSxxQkFBQTtBQUNBLGFBQUEsZUFBQTtNQUNUO01BRUgsV0FBUTtBQUNKLFlBQUksQ0FBQyxLQUFLLGFBQWE7QUFDbkIsZUFBSyxTQUFROztNQUVyQjtNQUNRLFdBQVE7QUFDWixhQUFLLFlBQVk7QUFFakIsYUFBSyxtQkFBbUIseUNBQXlDLEtBQUssYUFBYyxFQUFFLFVBQVU7VUFDNUYsTUFBTSxDQUFDLHNCQUFxQjtBQUN4QixpQkFBSyxjQUFjLGtCQUFrQjtBQUNyQyxpQkFBSyxZQUFZO0FBQ2pCLGlCQUFLLGtCQUFrQixLQUFLLEtBQUssV0FBVztVQUNoRDtVQUNBLE9BQU8sQ0FBQyxrQkFBcUMsUUFBUSxLQUFLLGNBQWMsYUFBYTtTQUN4RjtNQUNMO01BRW1CLFVBQVVHO01BQ1YsaUJBQWlCQzs7eUJBaEMzQixrQ0FBK0IsZ0NBQUEsa0JBQUEsR0FBQSxnQ0FBQSxZQUFBLENBQUE7TUFBQTtpRUFBL0Isa0NBQStCLFdBQUEsQ0FBQSxDQUFBLCtCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsZUFBQSxpQkFBQSxhQUFBLGNBQUEsR0FBQSxTQUFBLEVBQUEsbUJBQUEsb0JBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLGFBQUEsUUFBQSxHQUFBLFFBQUEsY0FBQSxZQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEseUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNYNUMsVUFBQSx5QkFBQSxHQUFBLHdEQUFBLElBQUEsQ0FBQTs7O0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsY0FBQSxJQUFBLEVBQUE7Ozs7O3FGRFdhLGlDQUErQixFQUFBLFdBQUEsa0NBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFWDVDLFNBQVMsYUFBQUMsWUFBVyxTQUFBQyxjQUFxQjs7Ozs7QUNDckMsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLElBQUE7Ozs7O0FBSHFDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsb0JBQUEsR0FBQTtBQUN3QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGFBQUEsT0FBQSxLQUFBLFNBQUE7QUFBdkIsSUFBQSx5QkFBQSxRQUFBLE9BQUEsUUFBQSxPQUFBLElBQUEsQ0FBQTs7Ozs7QUFNdEIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLHdCQUFBLENBQUE7QUFRSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFMUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsT0FBQSxRQUFBLEVBQXFCLGNBQUEsT0FBQSxVQUFBLEVBQUEsV0FBQSxPQUFBLE9BQUEsRUFBQSxlQUFBLElBQUE7Ozs7O0FBT3pCLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFEaUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsUUFBQSxPQUFBLElBQUEsQ0FBQTs7Ozs7QUFackMsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDhFQUFBLEdBQUEsQ0FBQSxFQVNDLEdBQUEsOEVBQUEsR0FBQSxDQUFBO0FBSUwsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7OztBQWZxQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFVBQUEsT0FBQSxLQUFBLFNBQUEsT0FBQSxTQUFBLGNBQUE7QUFBdUQsSUFBQSx5QkFBQSxvQkFBQSxHQUFBO0FBQ3BGLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEtBQUEsU0FBQSxPQUFBLFNBQUEsbUJBQUEsSUFBQSxFQUFBO0FBVUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsS0FBQSxTQUFBLE9BQUEsU0FBQSxpQkFBQSxJQUFBLEVBQUE7Ozs7O0FBS0osSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBRjRCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLFFBQUEsT0FBQSxJQUFBLENBQUE7Ozs7O0FBbEI1QixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxnRUFBQSxHQUFBLENBQUEsRUFnQkMsR0FBQSxnRUFBQSxHQUFBLENBQUE7Ozs7QUFoQkQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsS0FBQSxTQUFBLE9BQUEsU0FBQSxvQkFBQSxPQUFBLEtBQUEsU0FBQSxPQUFBLFNBQUEsaUJBQUEsSUFBQSxDQUFBOzs7Ozs7QUF3QkksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsNkJBQUEsQ0FBQTtBQUFvRixJQUFBLHlCQUFBLGtCQUFBLFNBQUEsbUhBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBYywwQkFBQSxRQUFBLGdCQUFBLFdBQUEsTUFBQTtJQUFnQyxDQUFBO0FBQU4sSUFBQSwyQkFBQTtBQUNoSSxJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQURvRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGNBQUEsUUFBQSxLQUFBLGNBQUEsRUFBbUMsWUFBQSxRQUFBLGdCQUFBLFFBQUE7Ozs7OztBQUduRixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxpQ0FBQSxDQUFBO0FBQTJGLElBQUEseUJBQUEscUJBQUEsU0FBQSwwSEFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFpQiwwQkFBQSxRQUFBLGdCQUFBLGNBQUEsTUFBQTtJQUFtQyxDQUFBO0FBQU4sSUFBQSwyQkFBQTtBQUM3SSxJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQUR3RCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGlCQUFBLFFBQUEsS0FBQSxjQUFBLEVBQXNDLGVBQUEsUUFBQSxnQkFBQSxXQUFBOzs7OztBQUo5RixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxnRUFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLGdFQUFBLEdBQUEsQ0FBQTs7OztBQUZELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEtBQUEsU0FBQSxPQUFBLFNBQUEsV0FBQSxJQUFBLEVBQUE7QUFHQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxLQUFBLFNBQUEsT0FBQSxTQUFBLGVBQUEsSUFBQSxFQUFBOzs7Ozs7QUFLQSxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSwrQkFBQSxFQUFBO0FBSUksSUFBQSx5QkFBQSxvQkFBQSxTQUFBLHlHQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUE7QUFBQSxhQUFnQiwwQkFBQSxRQUFBLGdCQUFBLGFBQUEsTUFBQTtJQUNsQixDQUFBO0FBQ0QsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSxJQUFBOzs7O0FBTFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLE9BQUEsUUFBQSxFQUFxQixnQkFBQSxPQUFBLEtBQUEsY0FBQSxFQUFBLGNBQUEsT0FBQSxnQkFBQSxVQUFBLEVBQUEsc0JBQUEsT0FBQSxnQkFBQSxrQkFBQTs7O0FEdEM3QixJQU9NLGlCQWFPO0FBcEJiOztBQUNBO0FBQ0E7Ozs7OztBQUtBLElBQU0sa0JBQU4sTUFBcUI7TUFDakI7TUFDQTtNQUNBO01BQ0E7TUFDQTs7QUFRRSxJQUFPLDRCQUFQLE1BQU8sMkJBQXlCO01BQ3pCO01BQ0E7TUFDQTtNQUVULGtCQUFrQixJQUFJLGdCQUFlO01BRWxCLFdBQVc7TUFDWCxVQUFVQztNQUU3QixjQUFBO01BQWU7TUFFZixXQUFRO0FBQ0osWUFBSSxLQUFLLHVCQUF1QjtBQUM1QixlQUFLLGdCQUFnQixxQkFBcUIsRUFBRSxVQUFVLEtBQUssc0JBQXNCLFVBQVUsWUFBWSxLQUFLLHNCQUFzQixXQUFVOztNQUVwSjtNQUVBLElBQUksV0FBUTtBQUNSLGVBQU8sWUFBWSxLQUFLLGdCQUFnQixrQkFBbUI7TUFDL0Q7TUFFQSxJQUFJLGFBQVU7QUFDVixlQUFPLGNBQWMsS0FBSyxnQkFBZ0Isb0JBQXFCLEtBQUssc0JBQXVCLGdCQUFpQjtNQUNoSDtNQUVBLElBQUksVUFBTztBQUNQLGVBQU8sV0FBVyxLQUFLLGdCQUFnQixvQkFBcUIsS0FBSyxzQkFBdUIsZ0JBQWlCO01BQzdHOzt5QkE1QlMsNEJBQXlCO01BQUE7aUVBQXpCLDRCQUF5QixXQUFBLENBQUEsQ0FBQSw4QkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFVBQUEsWUFBQSxNQUFBLFFBQUEsdUJBQUEsd0JBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLGtCQUFBLEVBQUEsR0FBQSxDQUFBLHdCQUFBLEVBQUEsR0FBQSxDQUFBLGFBQUEsU0FBQSxZQUFBLFVBQUEsR0FBQSx1QkFBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxNQUFBLG1CQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsTUFBQSxvQkFBQSxHQUFBLE9BQUEsR0FBQSxZQUFBLGNBQUEsV0FBQSxhQUFBLEdBQUEsQ0FBQSxNQUFBLGtCQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLHFCQUFBLEdBQUEsQ0FBQSxNQUFBLFNBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsY0FBQSxZQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsaUJBQUEsZUFBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLFlBQUEsZ0JBQUEsY0FBQSxzQkFBQSxrQkFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLG1DQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDcEJ0QyxVQUFBLHlCQUFBLEdBQUEsa0RBQUEsR0FBQSxDQUFBLEVBSUMsR0FBQSxrREFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLGtEQUFBLEdBQUEsR0FBQSxlQUFBLE1BQUEsR0FBQSxvQ0FBQTtBQStCRCxVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxrREFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUE7QUFTQSxVQUFBLHFCQUFBLEdBQUEsSUFBQTs7O0FBNUNBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLEtBQUEsU0FBQSxJQUFBLFNBQUEsWUFBQSxJQUFBLEtBQUEsU0FBQSxJQUFBLFNBQUEsZUFBQSxJQUFBLENBQUE7Ozs7O3FGRG9CYSwyQkFBeUIsRUFBQSxXQUFBLDRCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRXBCdEMsU0FBUyxhQUFBQyxZQUFXLFNBQUFDLGNBQWE7Ozs7OztBQ0V6QixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7O0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUFzQixJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQXVFLElBQUEsMkJBQUE7QUFDN0YsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxFQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7Ozs7QUFSeUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxjQUFBLDBCQUFBLEdBQUEsR0FBQSw0REFBQSxDQUFBO0FBQ2tCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLFFBQUEsT0FBQSxhQUFBLENBQUE7QUFHM0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQkFBQSwwQkFBQSxJQUFBLEdBQUEsMERBQUEsR0FBQSxvQkFBQTs7Ozs7QUFNWixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7O0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUFzQixJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQW9FLElBQUEsMkJBQUE7QUFDMUYsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxFQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7Ozs7QUFSc0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxjQUFBLDBCQUFBLEdBQUEsR0FBQSx5REFBQSxDQUFBO0FBQ3FCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLFFBQUEsT0FBQSxVQUFBLENBQUE7QUFHM0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQkFBQSwwQkFBQSxJQUFBLEdBQUEsdURBQUEsR0FBQSxvQkFBQTs7Ozs7QUFNWixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7O0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUFzQixJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQWtFLElBQUEsMkJBQUE7QUFDeEYsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxFQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7Ozs7QUFSb0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxjQUFBLDBCQUFBLEdBQUEsR0FBQSx1REFBQSxDQUFBO0FBQ3VCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLFFBQUEsT0FBQSxRQUFBLENBQUE7QUFHM0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQkFBQSwwQkFBQSxJQUFBLEdBQUEscURBQUEsR0FBQSxvQkFBQTs7Ozs7QUFNWixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7O0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUFzQixJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQXdFLElBQUEsMkJBQUE7QUFDOUYsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxFQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7Ozs7QUFSMEMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxjQUFBLDBCQUFBLEdBQUEsR0FBQSw2REFBQSxDQUFBO0FBQ2lCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLFFBQUEsT0FBQSxjQUFBLENBQUE7QUFHM0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQkFBQSwwQkFBQSxJQUFBLEdBQUEsMkRBQUEsR0FBQSxvQkFBQTs7Ozs7QUFNWixJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7O0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUFzQixJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQWlGLElBQUEsMkJBQUE7QUFDdkcsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQ0ksSUFBQSxxQkFBQSxFQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7Ozs7QUFSb0QsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxjQUFBLDBCQUFBLEdBQUEsR0FBQSxzRUFBQSxDQUFBO0FBQ08sSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsUUFBQSxPQUFBLHVCQUFBLENBQUE7QUFHM0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQkFBQSwwQkFBQSxJQUFBLEdBQUEsb0VBQUEsR0FBQSxvQkFBQTs7O0FEOUNwQixJQVFhO0FBUmI7O0FBQ0E7O0FBT00sSUFBTyw4QkFBUCxNQUFPLDZCQUEyQjtNQUMzQjtNQUVVLFVBQVVDO01BQ1YsZ0JBQWdCLEVBQUUsSUFBSSxJQUFJLE1BQU0sU0FBUyxlQUFjO01BQ3ZELGFBQWEsRUFBRSxJQUFJLElBQUksTUFBTSxTQUFTLFlBQVc7TUFDakQsV0FBVyxFQUFFLElBQUksSUFBSSxNQUFNLFNBQVMsVUFBUztNQUM3QyxpQkFBaUIsRUFBRSxJQUFJLElBQUksTUFBTSxTQUFTLGFBQVk7TUFDdEQsMEJBQTBCLEVBQUUsSUFBSSxJQUFJLE1BQU0sU0FBUyxjQUFjLFdBQVcsS0FBSTtNQUNoRixXQUFXOzt5QkFUckIsOEJBQTJCO01BQUE7aUVBQTNCLDhCQUEyQixXQUFBLENBQUEsQ0FBQSwwQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLFdBQUEsWUFBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxhQUFBLGdCQUFBLEdBQUEsQ0FBQSxNQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsTUFBQSxlQUFBLEdBQUEsT0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLE1BQUEsYUFBQSxHQUFBLE9BQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxNQUFBLG1CQUFBLEdBQUEsT0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLE1BQUEsNkJBQUEsR0FBQSxPQUFBLEdBQUEsWUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLHFDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDUnhDLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxvREFBQSxJQUFBLENBQUEsRUFTQyxHQUFBLG9EQUFBLElBQUEsQ0FBQSxFQUFBLEdBQUEsb0RBQUEsSUFBQSxDQUFBLEVBQUEsR0FBQSxvREFBQSxJQUFBLENBQUEsRUFBQSxHQUFBLG9EQUFBLElBQUEsQ0FBQTtBQXlDTCxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLElBQUE7OztBQW5ESSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxVQUFBLElBQUEsSUFBQSxTQUFBLGNBQUEsSUFBQSxJQUFBLEVBQUE7QUFVQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxVQUFBLElBQUEsSUFBQSxTQUFBLFdBQUEsSUFBQSxJQUFBLEVBQUE7QUFVQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxVQUFBLElBQUEsSUFBQSxTQUFBLFNBQUEsSUFBQSxJQUFBLEVBQUE7QUFVQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxVQUFBLElBQUEsSUFBQSxTQUFBLFlBQUEsS0FBQSxJQUFBLFVBQUEsSUFBQSxJQUFBLFNBQUEsUUFBQSxJQUFBLElBQUEsRUFBQTtBQVVBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLFVBQUEsSUFBQSxJQUFBLFNBQUEsWUFBQSxLQUFBLElBQUEsVUFBQSxJQUFBLElBQUEsU0FBQSxRQUFBLElBQUEsSUFBQSxFQUFBOzs7OztxRkRqQ1MsNkJBQTJCLEVBQUEsV0FBQSw4QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVSeEMsU0FBUyxhQUFBQyxZQUFXLGdCQUFBQyxlQUFjLFNBQUFDLFFBQWUsVUFBQUMsZUFBYztBQUUvRCxZQUFZLFdBQVc7QUFDdkIsU0FBUyxlQUFlOzs7OztBQ2lCUixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7Ozs7QUFFSSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEdBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsZUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsOEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsZ0NBQUEsQ0FBQTtBQVFJLElBQUEseUJBQUEsU0FBQSxTQUFBLGdIQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsWUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxRQUFBLFlBQUEsS0FBQSxPQUFBLENBQXNCO0lBQUEsQ0FBQTtBQUNsQyxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7O0FBZFcsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxTQUFBLFFBQUEsVUFBQSxLQUFBLEVBQW1DLFVBQUEsUUFBQSxVQUFBLE1BQUE7QUFDbkIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxTQUFBLFFBQUEsVUFBQSxLQUFBLEVBQW1DLFVBQUEsUUFBQSxVQUFBLE1BQUE7QUFFOUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxvQ0FBQSxNQUFBLFFBQUEsRUFBQTtBQUVBLElBQUEseUJBQUEsWUFBQSxPQUFBLFFBQUEsRUFBcUIsUUFBQSxPQUFBLEVBQUEseUJBQUEsUUFBQSxTQUFBLE9BQUEsU0FBQSxvQkFBQSxRQUFBLFNBQUEsT0FBQSxTQUFBLGlCQUFBLE9BQUEsbUJBQUEsSUFBQSxRQUFBLGNBQUEsSUFBQSxNQUFBOzs7OztBQVdqQyxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7OztBQUVJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFGZ0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxTQUFBLFlBQUEsVUFBQSxLQUFBLEVBQXNDLFVBQUEsWUFBQSxVQUFBLE1BQUEsRUFBQSxRQUFBLFlBQUEsS0FBQSxLQUFBOzs7OztBQTdDMUUsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsYUFBQSxDQUFBO0FBaUJJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxpRUFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUE7QUFLQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsaUVBQUEsR0FBQSxHQUFBLGVBQUEsTUFBQSxHQUFBLG9DQUFBO0FBZ0JBLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxpRUFBQSxHQUFBLEdBQUEsZUFBQSxNQUFBLEdBQUEsb0NBQUE7QUFLQSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsa0VBQUEsR0FBQSxHQUFBLGVBQUEsTUFBQSxHQUFBLG9DQUFBO0FBS0osSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7Ozs7QUFoRFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxTQUFBLE9BQUEsZ0JBQUEsS0FBQSxFQUErQixTQUFBLE9BQUEsZ0JBQUEsS0FBQSxFQUFBLFVBQUEsT0FBQSxNQUFBLEVBQUEsa0JBQUEsOEJBQUEsSUFBQSxHQUFBLENBQUEsRUFBQSxTQUFBLE9BQUEsS0FBQSxFQUFBLG1CQUFBLE9BQUEsZUFBQSxFQUFBLGtCQUFBLE9BQUEsY0FBQSxFQUFBLGNBQUEsT0FBQSxXQUFBLEVBQUEsYUFBQSxPQUFBLFNBQUEsRUFBQSxlQUFBLE9BQUEsV0FBQSxFQUFBLG1CQUFBLEdBQUEsRUFBQSxvQkFBQSxHQUFBLEVBQUEsV0FBQSxPQUFBLE9BQUEsRUFBQSxXQUFBLE9BQUEsT0FBQSxFQUFBLGNBQUEsT0FBQSxVQUFBOzs7QURIM0MsU0FZYTtBQVpiOztBQUlBO0FBQ0E7Ozs7O0FBT00sSUFBTyw2QkFBUCxNQUFPLDRCQUEwQjtNQXdCZjtNQXZCcEIsWUFBWTtNQUNIO01BQ0E7TUFDQyxjQUFpRCxJQUFJRixjQUFZO01BQzNFO01BQ0EsWUFBMkIsb0JBQUksSUFBRztNQUNsQyxxQkFBd0Usb0JBQUksSUFBRztNQUUvRSxTQUEwQjtNQUMxQixRQUFjO01BRU4sbUJBQW1CO01BQ25CLGtCQUFrQjtNQUNsQixlQUFlO01BQ2YsYUFBYTtNQUNiLGVBQWU7TUFFdkIsVUFBNEIsSUFBSSxRQUFPO01BQ3ZDLFVBQTRCLElBQUksUUFBTztNQUN2QyxhQUErQixJQUFJLFFBQU87TUFFdkIsV0FBVztNQUU5QixZQUFvQixxQkFBd0M7QUFBeEMsYUFBQSxzQkFBQTtNQUEyQztNQUUvRCxXQUFRO0FBQ0osWUFBSSxLQUFLLGdCQUFnQjtBQUNyQixlQUFLLGtCQUFpQjs7TUFFOUI7TUFFQSxJQUFhLGdCQUFnQixPQUFLO0FBQzlCLGFBQUssbUJBQW1CO01BQzVCO01BRUEsSUFBSSxrQkFBZTtBQUNmLGVBQU8sS0FBSztNQUNoQjtNQUVBLElBQWEsZUFBZSxPQUFLO0FBQzdCLGFBQUssa0JBQWtCO01BQzNCO01BRUEsSUFBSSxpQkFBYztBQUNkLGVBQU8sS0FBSztNQUNoQjtNQUVBLElBQWEsWUFBWSxPQUFLO0FBQzFCLGFBQUssZUFBZTtNQUN4QjtNQUVBLElBQUksY0FBVztBQUNYLGVBQU8sS0FBSztNQUNoQjtNQUVBLElBQWEsVUFBVSxPQUFLO0FBQ3hCLGFBQUssYUFBYTtNQUN0QjtNQUVBLElBQUksWUFBUztBQUNULGVBQU8sS0FBSztNQUNoQjtNQUVBLElBQWEsWUFBWSxPQUFLO0FBQzFCLGFBQUssZUFBZTtNQUN4QjtNQUVBLElBQUksY0FBVztBQUNYLGVBQU8sS0FBSztNQUNoQjtNQUVBLGNBQVc7QUFDUCxhQUFLLGtCQUFpQjtNQUMxQjtNQUVBLG9CQUFpQjtBQUNiLGFBQUssb0JBQW9CLHFDQUFxQyxLQUFLLGNBQWMsRUFBRSxVQUFVO1VBQ3pGLE1BQU0sQ0FBQyxhQUFZO0FBQ2YscUJBQVMsS0FBTSxRQUFRLENBQUMsYUFBWTtBQUNoQyxtQkFBSyxtQkFBbUIsSUFBSSxTQUFTLGNBQWUsUUFBUTtZQUNoRSxDQUFDO1VBQ0w7VUFDQSxVQUFVLE1BQUs7QUFDWCxpQkFBSyx3QkFBd0IsSUFBSTtVQUNyQztTQUNIO01BQ0w7TUFFQSx3QkFBd0IsUUFBZTtBQUNuQyxhQUFLLFlBQVk7QUFDakIsYUFBSyxvQkFBb0Isd0JBQXdCLEtBQUssY0FBYyxFQUFFLFVBQVUsQ0FBQyw0QkFBMkI7QUFDeEcsa0NBQXdCLEtBQU0sTUFBTSxRQUFRLENBQUMsU0FBUTtBQUNqRCxpQkFBSyxxQkFBcUIsSUFBSTtVQUNsQyxDQUFDO0FBQ0QsZUFBSyxrQkFBa0Isd0JBQXdCO0FBRy9DLGVBQUssWUFBWSxvQkFBSSxJQUFHO0FBQ3hCLGVBQUssZ0JBQWdCLE1BQU0sUUFBUSxDQUFDLFNBQVE7QUFDeEMsaUJBQUssVUFBVSxJQUFJLEtBQUssSUFBSztVQUNqQyxDQUFDO0FBRUQsY0FBSSxRQUFRO0FBQ1IsaUJBQUssUUFBUSxLQUFLLElBQUk7O0FBRTFCLGVBQUssWUFBWTtRQUNyQixDQUFDO01BQ0w7TUFFQSxxQkFBcUIsTUFBeUI7QUFDMUMsWUFBSSxLQUFLLFNBQVMsU0FBUyxrQkFBa0I7QUFDekMsZUFBSyxZQUFZLEVBQUUsT0FBTyxJQUFJLFFBQVEsR0FBRTtlQUNyQztBQUNILGVBQUssWUFBWSxFQUFFLE9BQU8sSUFBSSxRQUFRLEdBQUU7O01BRWhEO01BRUEsV0FBUTtBQUNKLGFBQUssUUFBUSxLQUFLLElBQUk7QUFDdEIsYUFBSyxRQUFRLEtBQUssSUFBSTtBQUN0QixhQUFLLFdBQVcsS0FBSyxJQUFJO01BQzdCO01BRUEsZUFBWTtBQUNSLGFBQUssV0FBVyxLQUFLLElBQUk7QUFDekIsYUFBSyxRQUFRLEtBQUssSUFBSTtNQUMxQjs7eUJBL0hTLDZCQUEwQixnQ0FBQSxtQkFBQSxDQUFBO01BQUE7aUVBQTFCLDZCQUEwQixXQUFBLENBQUEsQ0FBQSx5QkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLGdCQUFBLGtCQUFBLFVBQUEsWUFBQSxpQkFBQSxtQkFBQSxnQkFBQSxrQkFBQSxhQUFBLGVBQUEsV0FBQSxhQUFBLGFBQUEsY0FBQSxHQUFBLFNBQUEsRUFBQSxhQUFBLGNBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxTQUFBLFVBQUEsa0JBQUEsU0FBQSxtQkFBQSxrQkFBQSxjQUFBLGFBQUEsZUFBQSxtQkFBQSxvQkFBQSxXQUFBLFdBQUEsWUFBQSxHQUFBLENBQUEsZ0JBQUEsRUFBQSxHQUFBLENBQUEsZ0JBQUEsRUFBQSxHQUFBLENBQUEsZ0JBQUEsRUFBQSxHQUFBLENBQUEsbUJBQUEsRUFBQSxHQUFBLENBQUEsTUFBQSxTQUFBLFdBQUEsY0FBQSxRQUFBLEtBQUEsUUFBQSxLQUFBLGVBQUEsS0FBQSxnQkFBQSxLQUFBLFVBQUEsTUFBQSxHQUFBLENBQUEsS0FBQSxrQkFBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLE1BQUEsWUFBQSxRQUFBLHlCQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsS0FBQSxjQUFBLGVBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsU0FBQSxHQUFBLENBQUEsTUFBQSxLQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLG9DQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDWnZDLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxtREFBQSxJQUFBLEVBQUE7QUFtREEsVUFBQSx3QkFBQSxHQUFBLDRCQUFBLENBQUE7QUFDSixVQUFBLHFCQUFBLEdBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLEdBQUEsSUFBQTs7O0FBckRJLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsR0FBQSxJQUFBLGtCQUFBLElBQUEsRUFBQTtBQW1EeUMsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxhQUFBLElBQUEsU0FBQTs7Ozs7cUZEeENoQyw0QkFBMEIsRUFBQSxXQUFBLDZCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVp2QyxTQUFTLGFBQUFHLFlBQVcsZ0JBQUFDLGVBQWMsU0FBQUMsUUFBZSxVQUFBQyxlQUFjO0FBSS9ELFNBQVMscUJBQXFCOzs7OztBQ0gxQixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQXNCLElBQUEscUJBQUEsQ0FBQTs7QUFBa0MsSUFBQSwyQkFBQTtBQUM1RCxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBSGtDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsR0FBQSxHQUFBLFNBQUEsQ0FBQTs7Ozs7QUFrQmQsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7O0FBRmlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLGFBQUE7Ozs7OztBQVpyQixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsZ0NBQUEsQ0FBQTtBQUtJLElBQUEseUJBQUEsU0FBQSxTQUFBLG1HQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsWUFBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxPQUFBLFlBQUEsS0FBQSxPQUFBLENBQXNCO0lBQUEsQ0FBQTtBQUNsQyxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSxrRUFBQSxHQUFBLENBQUE7QUFLSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLFlBQUE7Ozs7Ozs7QUFaZ0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxvQkFBQSxRQUFBLFFBQUEsT0FBQSxtQkFBQSxPQUFBLE9BQUEsT0FBQSxnQkFBQSxHQUFBO0FBREEsSUFBQSxvQ0FBQSxNQUFBLFFBQUEsRUFBQTtBQUVBLElBQUEseUJBQUEsWUFBQSxPQUFBLFFBQUEsRUFBcUIsUUFBQSxPQUFBO0FBSzdCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxFQUFBLGNBQUEsWUFBQSxLQUFBLElBQUEsRUFBQTs7Ozs7QUFaWixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEsb0RBQUEsSUFBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQWtCSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLElBQUE7Ozs7QUFuQlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxPQUFBLElBQUE7OztBRFRSLElBV2E7QUFYYjs7QUFDQTtBQUNBO0FBQ0E7Ozs7O0FBUU0sSUFBTyx3QkFBUCxNQUFPLHVCQUFxQjtNQWVsQjtNQUNBO01BZkg7TUFDQTtNQUNDLGNBQWlELElBQUlGLGNBQVk7TUFFM0UsWUFBWTtNQUNaLE9BQThCLENBQUE7TUFDOUI7TUFHQSxnQkFBZ0I7TUFFRyxVQUFVRztNQUU3QixZQUNZLHFCQUNBLDRCQUFzRDtBQUR0RCxhQUFBLHNCQUFBO0FBQ0EsYUFBQSw2QkFBQTtNQUNUO01BRUgsV0FBUTtBQUNKLGFBQUssU0FBUTtNQUNqQjtNQUVRLFdBQVE7QUFDWixZQUFJLENBQUMsS0FBSyxnQkFBZ0I7QUFDdEI7O0FBRUosYUFBSyxZQUFZO0FBQ2pCLGFBQUssb0JBQW9CLHVCQUF1QixLQUFLLGNBQWMsRUFBRSxVQUFVLENBQUMsNEJBQTJCO0FBQ3ZHLGdCQUFNLE9BQU8sd0JBQXdCO0FBQ3JDLGVBQUssMkJBQTJCLG1CQUFtQixLQUFLLGNBQWMsR0FBRyxRQUFRLENBQUMsVUFBUztBQUN2RixnQkFBSTtBQUNKLGdCQUFJLGlCQUFpQixrQkFBa0I7QUFDbkMscUJBQU8sS0FBSyxNQUFNLEtBQUssQ0FBQ0MsVUFBUTtBQUM1Qix1QkFBT0EsTUFBSyxtQkFBbUIsTUFBTSxpQkFBaUJBLE1BQUsseUJBQXlCLE1BQU07Y0FDOUYsQ0FBQzt1QkFDTSxpQkFBaUIsZUFBZTtBQUN2QyxxQkFBTyxLQUFLLE1BQU0sS0FBSyxDQUFDQSxVQUFRO0FBQzVCLHVCQUFPQSxNQUFLLG1CQUFtQixNQUFNLGNBQWMsQ0FBQ0EsTUFBSztjQUM3RCxDQUFDOztBQUVMLGdCQUFJLE1BQU07QUFDTixtQkFBSyxLQUFLLEtBQUssSUFBSTs7VUFFM0IsQ0FBQztBQUNELGVBQUssWUFBWTtRQUNyQixDQUFDO01BQ0w7TUFFQSxjQUFjLGdCQUFnRDtBQUMxRCxZQUFJLDBCQUEwQixrQkFBa0I7QUFDNUMsZUFBSyxrQkFBa0IsS0FBSyxLQUFLLEtBQUssQ0FBQyxTQUFRO0FBQzNDLG1CQUFPLEtBQUssbUJBQW1CLGVBQWUsaUJBQWlCLEtBQUsseUJBQXlCLGVBQWU7VUFDaEgsQ0FBQztlQUNFO0FBQ0gsZUFBSyxrQkFBa0IsS0FBSyxLQUFLLEtBQUssQ0FBQyxTQUFRO0FBQzNDLG1CQUFPLEtBQUssbUJBQW1CLGVBQWUsY0FBYyxDQUFDLEtBQUs7VUFDdEUsQ0FBQzs7TUFFVDtNQUVBLG9CQUFpQjtBQUNiLGFBQUssa0JBQWtCO01BQzNCOzt5QkEvRFMsd0JBQXFCLGdDQUFBLG1CQUFBLEdBQUEsZ0NBQUEsMEJBQUEsQ0FBQTtNQUFBO2lFQUFyQix3QkFBcUIsV0FBQSxDQUFBLENBQUEsbUJBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxnQkFBQSxrQkFBQSxVQUFBLFdBQUEsR0FBQSxTQUFBLEVBQUEsYUFBQSxjQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFVBQUEsd0JBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLFlBQUEsUUFBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLCtCQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDWGxDLFVBQUEseUJBQUEsR0FBQSw4Q0FBQSxJQUFBLENBQUEsRUFNQyxHQUFBLDhDQUFBLEdBQUEsQ0FBQTs7O0FBTkQsVUFBQSw0QkFBQSxHQUFBLElBQUEsWUFBQSxJQUFBLEVBQUE7QUFPQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsQ0FBQSxJQUFBLFlBQUEsSUFBQSxFQUFBOzs7OztxRkRJYSx1QkFBcUIsRUFBQSxXQUFBLHdCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVhsQyxTQUFTLGdCQUFnQjtBQUV6QixTQUFTLHNCQUFzQjs7QUFGL0IsSUF5QmE7QUF6QmI7O0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZU0sSUFBTyxpQ0FBUCxNQUFPLGdDQUE4Qjs7eUJBQTlCLGlDQUE4QjtNQUFBO2lFQUE5QixnQ0FBOEIsQ0FBQTtxRUFaN0IscUJBQXFCLGdCQUFnQix5QkFBeUIsRUFBQSxDQUFBOzs7Ozs7QUNiNUUsU0FBUyxhQUFBQyxZQUFXLGdCQUFBQyxlQUFjLFNBQUFDLFFBQU8sVUFBQUMsZUFBYztBQUN2RCxTQUFTLGdCQUFnQixlQUFlLGVBQWU7Ozs7OztBQ0UzQyxJQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsQ0FBQTtBQUE4RCxJQUFBLDRCQUFBO0FBQ3RFLElBQUEsc0JBQUEsR0FBQSxZQUFBOzs7O0FBRFEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxrQ0FBQSxJQUFBLE9BQUEsYUFBQSxRQUFBLE9BQUEsT0FBQSxPQUFBLGFBQUEsS0FBQSxNQUFBLE1BQUEsT0FBQSxhQUFBLFFBQUEsT0FBQSxPQUFBLE9BQUEsYUFBQSxLQUFBLE9BQUEsR0FBQTs7O0FESGhCLElBUWE7QUFSYjs7QUFFQTs7QUFNTSxJQUFPLG1DQUFQLE1BQU8sa0NBQWdDO01BQ2hDO01BQ0MsWUFBZ0MsSUFBSUYsY0FBWTtNQUNoRCxlQUFtQyxJQUFJQSxjQUFZO01BQ25ELFVBQThCLElBQUlBLGNBQVk7TUFFeEQsVUFBVTtNQUNWLGdCQUFnQjtNQUNoQixpQkFBaUI7O3lCQVJSLG1DQUFnQztNQUFBO2tFQUFoQyxtQ0FBZ0MsV0FBQSxDQUFBLENBQUEsZ0NBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxjQUFBLGVBQUEsR0FBQSxTQUFBLEVBQUEsV0FBQSxhQUFBLGNBQUEsZ0JBQUEsU0FBQSxVQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxNQUFBLGtCQUFBLEdBQUEsT0FBQSxlQUFBLE9BQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsWUFBQSxHQUFBLENBQUEsTUFBQSxpQkFBQSxHQUFBLE9BQUEsZUFBQSxPQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSxnQkFBQSxHQUFBLE9BQUEsY0FBQSxPQUFBLEdBQUEsT0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDBDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDUjdDLFVBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsMEJBQUEsR0FBQSx5REFBQSxHQUFBLENBQUE7QUFHSixVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxzQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDhCQUFBLEdBQUEsVUFBQSxDQUFBO0FBQXdELFVBQUEsMEJBQUEsU0FBQSxTQUFBLG9FQUFBO0FBQUEsbUJBQVMsSUFBQSxVQUFBLEtBQUE7VUFBZ0IsQ0FBQTtBQUM3RSxVQUFBLHNCQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsV0FBQSxDQUFBOztBQUNKLFVBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw0QkFBQTtBQUNBLFVBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUF1RCxVQUFBLDBCQUFBLFNBQUEsU0FBQSxxRUFBQTtBQUFBLG1CQUFTLElBQUEsYUFBQSxLQUFBO1VBQW1CLENBQUE7QUFDL0UsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLFdBQUEsQ0FBQTs7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsOEJBQUEsSUFBQSxVQUFBLENBQUE7QUFBcUQsVUFBQSwwQkFBQSxTQUFBLFNBQUEscUVBQUE7QUFBQSxtQkFBUyxJQUFBLFFBQUEsS0FBQTtVQUFjLENBQUE7QUFDeEUsVUFBQSxzQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLFdBQUEsQ0FBQTs7QUFDSixVQUFBLHNCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDSixVQUFBLHNCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLElBQUEsSUFBQTs7O0FBaEJRLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxJQUFBLGVBQUEsSUFBQSxFQUFBO0FBTXFDLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEscUNBQUEsY0FBQSwyQkFBQSxJQUFBLEdBQUEsbURBQUEsQ0FBQTtBQUF4QixVQUFBLDBCQUFBLFFBQUEsSUFBQSxjQUFBO0FBR3VCLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEscUNBQUEsY0FBQSwyQkFBQSxJQUFBLEdBQUEsa0RBQUEsQ0FBQTtBQUF2QixVQUFBLDBCQUFBLFFBQUEsSUFBQSxhQUFBO0FBR2lCLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEscUNBQUEsY0FBQSwyQkFBQSxJQUFBLElBQUEscUJBQUEsQ0FBQTtBQUFqQixVQUFBLDBCQUFBLFFBQUEsSUFBQSxPQUFBOzs7OztzRkROUixrQ0FBZ0MsRUFBQSxXQUFBLG1DQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVI3QyxTQUFTLGFBQUFHLFlBQVcsU0FBQUMsUUFBTyxpQkFBaUI7QUFDNUMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsc0JBQXNCOzs7Ozs7O0FDU25CLElBQUEsc0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsOEJBQUEsR0FBQSwyQkFBQSxHQUFBLENBQUE7QUFTSSxJQUFBLDBCQUFBLGVBQUEsU0FBQSx5R0FBQSxRQUFBO0FBQUEsTUFBQSw2QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBO0FBQUEsYUFBZSwyQkFBQSxPQUFBLGNBQUEsTUFBQSxDQUFxQjtJQUFBLENBQUE7QUFDdkMsSUFBQSw0QkFBQTtBQUNMLElBQUEsc0JBQUEsR0FBQSxZQUFBOzs7O0FBUlEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxZQUFBLE9BQUEsUUFBQSxFQUFxQixrQkFBQSxPQUFBLGFBQUEsRUFBQSxFQUFBLGtCQUFBLElBQUEsRUFBQSxlQUFBLElBQUEsRUFBQSxhQUFBLElBQUEsRUFBQSxlQUFBLElBQUE7OztBRGRyQyxVQVdhO0FBWGI7O0FBR0E7QUFDQTs7OztBQU9NLElBQU8scUNBQVAsTUFBTyxvQ0FBa0M7TUFNL0I7TUFDQTtNQU5IO01BQ0E7TUFDZ0M7TUFFekMsWUFDWSxhQUNBLFFBQWM7QUFEZCxhQUFBLGNBQUE7QUFDQSxhQUFBLFNBQUE7TUFDVDtNQUVILFFBQUs7QUFDRCxhQUFLLFlBQVksTUFBSztNQUMxQjtNQUVBLGNBQWMsTUFBeUI7QUFDbkMsWUFBSSxLQUFLLFNBQVMsU0FBUyxvQkFBb0IsS0FBSyxTQUFTLFNBQVMsZ0JBQWdCO0FBQ2xGLGVBQUsscUJBQXFCLElBQUk7O01BRXRDO01BRUEscUJBQXFCLE1BQXlCO0FBQzFDLGFBQUssT0FBTyxTQUFTLENBQUMsV0FBVyxLQUFLLFVBQVUsZ0JBQWdCLEtBQUssY0FBYyxDQUFDO0FBQ3BGLGFBQUssTUFBSztNQUNkOzt5QkF2QlMscUNBQWtDLGlDQUFBLGtCQUFBLEdBQUEsaUNBQUEsVUFBQSxDQUFBO01BQUE7a0VBQWxDLHFDQUFrQyxXQUFBLENBQUEsQ0FBQSxrQ0FBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLHlDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBOzs7Ozs7Ozs7QUNYL0MsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEsc0JBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw4QkFBQSxHQUFBLGtDQUFBLENBQUE7QUFFSSxVQUFBLDBCQUFBLGFBQUEsU0FBQSxrR0FBQTtBQUFhLGdCQUFBLDJCQUFBLFlBQUE7QUFBd0MsbUJBQUUsSUFBQSwyQkFBQSxhQUFBO1VBQXlDLENBQUEsRUFBQyxnQkFBQSxTQUFBLHFHQUFBO0FBQUEsbUJBQ2pGLElBQUEsMkJBQUEsYUFBQTtVQUF5QyxDQUFBLEVBRHdDLFdBQUEsU0FBQSxnR0FBQTtBQUFBLG1CQUV0RixJQUFBLE1BQUE7VUFBTyxDQUFBO0FBQ3JCLFVBQUEsNEJBQUE7QUFDTCxVQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNEJBQUE7QUFDQSxVQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsOEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHNCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsMEJBQUEsR0FBQSwyREFBQSxHQUFBLENBQUE7QUFhSixVQUFBLDRCQUFBO0FBQ0osVUFBQSxzQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDRCQUFBO0FBQ0EsVUFBQSxzQkFBQSxJQUFBLElBQUE7OztBQXRCWSxVQUFBLHlCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLGdCQUFBLElBQUEsWUFBQTtBQU9KLFVBQUEseUJBQUEsQ0FBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxJQUFBLFlBQUEsSUFBQSxlQUFBLElBQUEsRUFBQTs7Ozs7c0ZEQ0ssb0NBQWtDLEVBQUEsV0FBQSxxQ0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVYL0MsU0FBUyxZQUFBQyxpQkFBZ0I7O0FBQXpCLElBV2E7QUFYYjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU9NLElBQU8sb0NBQVAsTUFBTyxtQ0FBaUM7O3lCQUFqQyxvQ0FBaUM7TUFBQTtpRUFBakMsbUNBQWlDLENBQUE7cUVBSmhDLHFCQUFxQiw4QkFBOEIsRUFBQSxDQUFBOzs7OyIsIm5hbWVzIjpbImdldEljb24iLCJOb2RlVHlwZSIsImVkZ2UiLCJJbmplY3RhYmxlIiwiZ2V0SWNvbiIsImdldEljb25Ub29sdGlwIiwiQ29tcG9uZW50IiwiRXZlbnRFbWl0dGVyIiwiSW5wdXQiLCJPdXRwdXQiLCJDb21wb25lbnQiLCJFdmVudEVtaXR0ZXIiLCJJbnB1dCIsIk91dHB1dCIsImdldEljb24iLCJnZXRJY29uVG9vbHRpcCIsIkNvbXBvbmVudCIsIklucHV0IiwiZ2V0SWNvbiIsIkNvbXBvbmVudCIsIklucHV0IiwiZ2V0SWNvbiIsIkNvbXBvbmVudCIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwiQ29tcG9uZW50IiwiRXZlbnRFbWl0dGVyIiwiSW5wdXQiLCJPdXRwdXQiLCJnZXRJY29uIiwibm9kZSIsIkNvbXBvbmVudCIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwiQ29tcG9uZW50IiwiSW5wdXQiLCJOZ01vZHVsZSJdfQ==