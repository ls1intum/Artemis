import {
  SortService,
  init_sort_service
} from "/chunk-H46RESQY.js";
import {
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  TranslateDirective,
  __esm,
  init_artemis_translate_pipe,
  init_shared_module,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/data-table/data-table.component.ts
import { Component, ContentChild, ElementRef, EventEmitter, Input, Output, TemplateRef, ViewChild, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { debounceTime, distinctUntilChanged, map, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { ColumnMode, SortType } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@flaviosantoro92_ngx-datatable.js?v=1d0d9ead";
import { flatten, get, isNumber } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import { LocalStorageService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import { faCircleNotch, faSort, faSortDown, faSortUp } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function DataTableComponent_Conditional_2_Conditional_3_For_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                            ");
    i0.\u0275\u0275elementStart(1, "button", 4);
    i0.\u0275\u0275listener("click", function DataTableComponent_Conditional_2_Conditional_3_For_10_Template_button_click_1_listener() {
      const restoredCtx = i0.\u0275\u0275restoreView(_r12);
      const pagingOption_r6 = restoredCtx.$implicit;
      const ctx_r11 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r11.setEntitiesPerPage(pagingOption_r6));
    });
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275pipe(3, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(4, "\n                        ");
  }
  if (rf & 2) {
    const pagingOption_r6 = ctx.$implicit;
    const ctx_r5 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275classProp("selected", pagingOption_r6 === ctx_r5.pagingValue);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate1("\n                                ", i0.\u0275\u0275pipeBind2(3, 3, ctx_r5.perPageTranslation(pagingOption_r6), i0.\u0275\u0275pureFunction1(6, _c1, pagingOption_r6)), "\n                            ");
  }
}
function DataTableComponent_Conditional_2_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                ");
    i0.\u0275\u0275elementStart(1, "div", 1);
    i0.\u0275\u0275text(2, "\n                    ");
    i0.\u0275\u0275elementStart(3, "button", 2);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275pipe(5, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n                    ");
    i0.\u0275\u0275elementStart(7, "div", 3);
    i0.\u0275\u0275text(8, "\n                        ");
    i0.\u0275\u0275repeaterCreate(9, DataTableComponent_Conditional_2_Conditional_3_For_10_Template, 5, 8, null, null, i0.\u0275\u0275repeaterTrackByIdentity);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12, "\n            ");
  }
  if (rf & 2) {
    const ctx_r3 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate1("\n                        ", i0.\u0275\u0275pipeBind2(5, 1, ctx_r3.perPageTranslation(ctx_r3.pagingValue), i0.\u0275\u0275pureFunction1(4, _c1, ctx_r3.pagingValue)), "\n                    ");
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275repeater(ctx_r3.PAGING_VALUES);
  }
}
function DataTableComponent_Conditional_2_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275text(0, "\n                ");
    i0.\u0275\u0275elementStart(1, "div", 5);
    i0.\u0275\u0275text(2, "\n                    ");
    i0.\u0275\u0275elementStart(3, "input", 6, 7);
    i0.\u0275\u0275listener("selectItem", function DataTableComponent_Conditional_2_Conditional_4_Template_input_selectItem_3_listener($event) {
      i0.\u0275\u0275restoreView(_r15);
      const ctx_r14 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r14.onAutocompleteSelect($event.item));
    })("blur", function DataTableComponent_Conditional_2_Conditional_4_Template_input_blur_3_listener() {
      i0.\u0275\u0275restoreView(_r15);
      const ctx_r16 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r16.onSearchInputBlur());
    });
    i0.\u0275\u0275pipe(5, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(6, "\n                    ");
    i0.\u0275\u0275elementStart(7, "div", 8);
    i0.\u0275\u0275text(8, "\n                        ");
    i0.\u0275\u0275element(9, "fa-icon", 9);
    i0.\u0275\u0275text(10, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11, "\n                    ");
    i0.\u0275\u0275elementStart(12, "div", 8);
    i0.\u0275\u0275text(13, "\n                        ");
    i0.\u0275\u0275elementStart(14, "span", 10);
    i0.\u0275\u0275text(15, " Search failed ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(16, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(17, "\n                    ");
    i0.\u0275\u0275elementStart(18, "div", 8);
    i0.\u0275\u0275text(19, "\n                        ");
    i0.\u0275\u0275elementStart(20, "span", 11);
    i0.\u0275\u0275text(21, " No results ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(22, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(23, "\n                    ");
    i0.\u0275\u0275elementStart(24, "div", 8);
    i0.\u0275\u0275text(25, "\n                        ");
    i0.\u0275\u0275elementStart(26, "span", 12);
    i0.\u0275\u0275text(27);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(28, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(29, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(30, "\n            ");
  }
  if (rf & 2) {
    const ctx_r4 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("placeholder", i0.\u0275\u0275pipeBind1(5, 18, ctx_r4.searchPlaceholderTranslation))("ngbTypeahead", ctx_r4.onSearch)("resultFormatter", ctx_r4.searchResultFormatter)("inputFormatter", ctx_r4.searchInputFormatter);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275classProp("active", ctx_r4.isSearching);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r4.faCircleNotch)("spin", true);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275classProp("active", ctx_r4.searchFailed);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275classProp("active", ctx_r4.searchNoResults);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("jhiTranslate", ctx_r4.searchNoResultsTranslation);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275classProp("active", ctx_r4.searchQueryTooShort);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("jhiTranslate", ctx_r4.minQueryLengthHintTranslation)("translateValues", i0.\u0275\u0275pureFunction1(20, _c2, ctx_r4.minSearchQueryLength));
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275textInterpolate1("\n                            Please enter at least ", ctx_r4.minSearchQueryLength, " characters\n                        ");
  }
}
function DataTableComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "div", 0);
    i0.\u0275\u0275text(2, "\n            ");
    i0.\u0275\u0275template(3, DataTableComponent_Conditional_2_Conditional_3_Template, 13, 6)(4, DataTableComponent_Conditional_2_Conditional_4_Template, 31, 22);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(3, ctx_r0.showPageSizeDropdown ? 3 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(4, ctx_r0.searchEnabled ? 4 : -1);
  }
}
function DataTableComponent_Conditional_3_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementContainer(0);
  }
}
function DataTableComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "div", 13);
    i0.\u0275\u0275text(2, "\n            ");
    i0.\u0275\u0275template(3, DataTableComponent_Conditional_3_ng_container_3_Template, 1, 0, "ng-container", 14);
    i0.\u0275\u0275text(4, "\n            ");
    i0.\u0275\u0275elementStart(5, "div", 15);
    i0.\u0275\u0275text(6, "\n                ");
    i0.\u0275\u0275element(7, "fa-icon", 9);
    i0.\u0275\u0275text(8, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("ngTemplateOutlet", ctx_r1.templateRef)("ngTemplateOutletContext", ctx_r1.context);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275classProp("active", ctx_r1.isTransitioning);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r1.faCircleNotch)("spin", true);
  }
}
function DataTableComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "div", 16);
    i0.\u0275\u0275text(2, "\n            ");
    i0.\u0275\u0275element(3, "fa-icon", 9);
    i0.\u0275\u0275text(4, "\n        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r2 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("icon", ctx_r2.faCircleNotch)("spin", true);
  }
}
var _c0, _c1, _c2, SortOrder, SortIcon, SortOrderIcon, DataTableComponent, entityToString, onSearchDefaultWrapper, onAutocompleteSelectDefaultWrapper;
var init_data_table_component = __esm({
  "src/main/webapp/app/shared/data-table/data-table.component.ts"() {
    init_sort_service();
    init_sort_service();
    init_translate_directive();
    init_artemis_translate_pipe();
    _c0 = ["ngbTypeahead"];
    _c1 = (a0) => ({ number: a0 });
    _c2 = (a0) => ({ length: a0 });
    (function(SortOrder2) {
      SortOrder2["ASC"] = "asc";
      SortOrder2["DESC"] = "desc";
    })(SortOrder || (SortOrder = {}));
    SortIcon = {
      NONE: faSort,
      ASC: faSortUp,
      DESC: faSortDown
    };
    SortOrderIcon = {
      [SortOrder.ASC]: SortIcon.ASC,
      [SortOrder.DESC]: SortIcon.DESC
    };
    DataTableComponent = class _DataTableComponent {
      sortService;
      localStorage;
      templateRef;
      ngbTypeahead;
      isLoading = false;
      isSearching = false;
      searchFailed = false;
      searchNoResults = false;
      isTransitioning = false;
      showPageSizeDropdown = true;
      showSearchField = true;
      entityType = "entity";
      allEntities = [];
      entitiesPerPageTranslation;
      showAllEntitiesTranslation;
      searchNoResultsTranslation = "artemisApp.dataTable.search.noResults";
      searchPlaceholderTranslation;
      minQueryLengthHintTranslation = "artemisApp.dataTable.search.minQueryLengthHint";
      searchFields = [];
      searchEnabled = true;
      searchEntityFilterEnabled = true;
      searchTextFromEntity = entityToString;
      searchResultFormatter = entityToString;
      onSearchWrapper = onSearchDefaultWrapper;
      onAutocompleteSelectWrapper = onAutocompleteSelectDefaultWrapper;
      customFilter = () => true;
      customFilterKey = {};
      entitiesSizeChange = new EventEmitter();
      PAGING_VALUES = [10, 20, 50, 100, 200, 500, 1e3, "all"];
      DEFAULT_PAGING_VALUE = 50;
      isRendering;
      entities;
      pagingValue;
      entityCriteria;
      searchQueryTooShort;
      minSearchQueryLength = 3;
      faCircleNotch = faCircleNotch;
      constructor(sortService, localStorage) {
        this.sortService = sortService;
        this.localStorage = localStorage;
        this.entities = [];
        this.entityCriteria = {
          textSearch: [],
          sortProp: { field: "id", order: SortOrder.ASC }
        };
      }
      ngOnInit() {
        this.pagingValue = this.getCachedEntitiesPerPage();
        this.onSort = this.onSort.bind(this);
        this.iconForSortPropField = this.iconForSortPropField.bind(this);
      }
      ngOnChanges(changes) {
        if (changes.allEntities || changes.customFilterKey) {
          this.updateEntities();
        }
      }
      get context() {
        return {
          settings: {
            limit: this.pageLimit,
            sortType: SortType.multi,
            columnMode: ColumnMode.force,
            headerHeight: 50,
            footerHeight: 50,
            rowHeight: "auto",
            rows: this.entities,
            rowClass: "",
            scrollbarH: true
          },
          controls: {
            iconForSortPropField: this.iconForSortPropField,
            onSort: this.onSort
          }
        };
      }
      get isPreparing() {
        return this.isLoading || this.isRendering;
      }
      get pageLimit() {
        return isNumber(this.pagingValue) ? this.pagingValue : void 0;
      }
      perPageTranslation(quantifier) {
        return isNumber(quantifier) ? this.entitiesPerPageTranslation : this.showAllEntitiesTranslation;
      }
      get perPageCacheKey() {
        return `${this.entityType}-items-per-page`;
      }
      getCachedEntitiesPerPage = () => {
        const cachedValue = this.localStorage.retrieve(this.perPageCacheKey);
        if (cachedValue) {
          const parsedValue = parseInt(cachedValue, 10) || cachedValue;
          if (this.PAGING_VALUES.includes(parsedValue)) {
            return parsedValue;
          }
        }
        return this.DEFAULT_PAGING_VALUE;
      };
      setEntitiesPerPage = (paging) => {
        this.isRendering = true;
        setTimeout(() => {
          this.pagingValue = paging;
          this.isRendering = false;
        }, 500);
        this.localStorage.store(this.perPageCacheKey, paging.toString());
      };
      updateEntities() {
        const searchPredicate = (entity) => {
          return !this.searchEntityFilterEnabled || this.filterEntityByTextSearch(this.entityCriteria.textSearch, entity, this.searchFields);
        };
        const filteredEntities = this.allEntities.filter((entity) => this.customFilter(entity) && searchPredicate(entity));
        this.entities = this.sortService.sortByProperty(filteredEntities, this.entityCriteria.sortProp.field, this.entityCriteria.sortProp.order === SortOrder.ASC);
        setTimeout(() => this.entitiesSizeChange.emit(this.entities.length));
      }
      filterEntityByTextSearch = (searchWords, entity, searchFields) => {
        if (!searchWords.length) {
          return true;
        }
        const containsSearchWord = (fieldValue) => searchWords.some(this.foundIn(fieldValue));
        return this.entityFieldValues(entity, searchFields).some(containsSearchWord);
      };
      entityFieldValues = (entity, fields) => {
        return flatten(fields.map((field) => this.collectEntityFieldValues(entity, field))).filter(Boolean);
      };
      collectEntityFieldValues = (entity, field) => {
        const separator = ".";
        const [head, ...tail] = field.split(separator);
        if (tail.length > 0) {
          const resolved = get(entity, head);
          if (Array.isArray(resolved)) {
            return flatten(resolved.map((subEntity) => this.collectEntityFieldValues(subEntity, tail.join(separator))));
          }
          return this.collectEntityFieldValues(resolved, tail.join(separator));
        }
        return [get(entity, head, false)];
      };
      foundIn = (text) => (word) => {
        const segments = word.toLowerCase().split(" ");
        return text && word && segments.every((segment) => {
          const regex = segment.replace(/[.+\-^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".");
          return new RegExp(regex).test(text.toLowerCase());
        });
      };
      onSearch = (text$) => {
        return this.onSearchWrapper(text$.pipe(debounceTime(200), distinctUntilChanged(), tap(() => {
          this.searchQueryTooShort = false;
        }), map((text) => {
          const searchWords = text.split(",").map((word) => word.trim());
          return { text, searchWords: searchWords.length === 1 && !searchWords[0] ? [] : searchWords };
        }), tap(({ searchWords }) => {
          this.entityCriteria.textSearch = searchWords;
          this.updateEntities();
        }), map(({ text, searchWords }) => {
          const lastSearchWord = searchWords.last();
          if (!lastSearchWord || lastSearchWord.length < this.minSearchQueryLength) {
            this.searchQueryTooShort = true;
            return { text, entities: [] };
          }
          return {
            text,
            entities: this.entities.filter((entity) => {
              const fieldValues = this.entityFieldValues(entity, this.searchFields);
              return fieldValues.some((fieldValue) => this.foundIn(fieldValue)(lastSearchWord));
            })
          };
        })));
      };
      onSearchInputBlur() {
        this.searchQueryTooShort = false;
      }
      get typeaheadButtons() {
        return get(this.ngbTypeahead, "nativeElement.nextSibling.children", []);
      }
      onAutocompleteSelect = (entity) => {
        this.entityCriteria.textSearch[this.entityCriteria.textSearch.length - 1] = this.searchTextFromEntity(entity);
        this.onAutocompleteSelectWrapper(entity, this.filterAfterAutocompleteSelect);
      };
      filterAfterAutocompleteSelect = () => {
        this.updateEntities();
      };
      searchInputFormatter = () => {
        return this.entityCriteria.textSearch.join(", ");
      };
      onSort(field) {
        const sameField = this.entityCriteria.sortProp && this.entityCriteria.sortProp.field === field;
        const order = sameField ? this.invertSort(this.entityCriteria.sortProp.order) : SortOrder.ASC;
        this.entityCriteria.sortProp = { field, order };
        this.updateEntities();
      }
      invertSort = (order) => {
        return order === SortOrder.ASC ? SortOrder.DESC : SortOrder.ASC;
      };
      iconForSortPropField(field) {
        if (this.entityCriteria.sortProp.field !== field) {
          return SortIcon.NONE;
        }
        return SortOrderIcon[this.entityCriteria.sortProp.order];
      }
      static \u0275fac = function DataTableComponent_Factory(t) {
        return new (t || _DataTableComponent)(i0.\u0275\u0275directiveInject(SortService), i0.\u0275\u0275directiveInject(i2.LocalStorageService));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _DataTableComponent, selectors: [["jhi-data-table"]], contentQueries: function DataTableComponent_ContentQueries(rf, ctx, dirIndex) {
        if (rf & 1) {
          i0.\u0275\u0275contentQuery(dirIndex, TemplateRef, 5, TemplateRef);
        }
        if (rf & 2) {
          let _t;
          i0.\u0275\u0275queryRefresh(_t = i0.\u0275\u0275loadQuery()) && (ctx.templateRef = _t.first);
        }
      }, viewQuery: function DataTableComponent_Query(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275viewQuery(_c0, 5);
        }
        if (rf & 2) {
          let _t;
          i0.\u0275\u0275queryRefresh(_t = i0.\u0275\u0275loadQuery()) && (ctx.ngbTypeahead = _t.first);
        }
      }, inputs: { isLoading: "isLoading", isSearching: "isSearching", searchFailed: "searchFailed", searchNoResults: "searchNoResults", isTransitioning: "isTransitioning", showPageSizeDropdown: "showPageSizeDropdown", showSearchField: "showSearchField", entityType: "entityType", allEntities: "allEntities", entitiesPerPageTranslation: "entitiesPerPageTranslation", showAllEntitiesTranslation: "showAllEntitiesTranslation", searchNoResultsTranslation: "searchNoResultsTranslation", searchPlaceholderTranslation: "searchPlaceholderTranslation", minQueryLengthHintTranslation: "minQueryLengthHintTranslation", searchFields: "searchFields", searchEnabled: "searchEnabled", searchEntityFilterEnabled: "searchEntityFilterEnabled", searchTextFromEntity: "searchTextFromEntity", searchResultFormatter: "searchResultFormatter", onSearchWrapper: "onSearchWrapper", onAutocompleteSelectWrapper: "onAutocompleteSelectWrapper", customFilter: "customFilter", customFilterKey: "customFilterKey" }, outputs: { entitiesSizeChange: "entitiesSizeChange" }, features: [i0.\u0275\u0275NgOnChangesFeature], decls: 6, vars: 2, consts: [[1, "d-flex", "mb-2", "gap-1", "flex-column", "flex-md-row"], ["ngbDropdown", "", 1, "d-inline-block", "me-2"], ["id", "dropdownBasic1", "ngbDropdownToggle", "", 1, "btn", "btn-outline-primary", "w-100"], ["ngbDropdownMenu", "", "aria-labelledby", "dropdownBasic1"], ["ngbDropdownItem", "", 3, "click"], [1, "search-container"], ["id", "typeahead-basic", "type", "text", 1, "form-control", 3, "placeholder", "ngbTypeahead", "resultFormatter", "inputFormatter", "selectItem", "blur"], ["ngbTypeahead", ""], [1, "search-info"], ["size", "lg", 3, "icon", "spin"], ["jhiTranslate", "artemisApp.dataTable.search.failed", 1, "badge", "bg-danger"], [1, "badge", "bg-warning", 3, "jhiTranslate"], [1, "badge", "bg-info", 3, "jhiTranslate", "translateValues"], [1, "table-responsive", "data-table-container"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "transitioning-container"], [1, "loading-container", "d-flex", "justify-content-center", "align-items-center"]], template: function DataTableComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "div");
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275template(2, DataTableComponent_Conditional_2_Template, 6, 2)(3, DataTableComponent_Conditional_3_Template, 11, 6)(4, DataTableComponent_Conditional_4_Template, 6, 2);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(5, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275conditional(2, ctx.showPageSizeDropdown || ctx.showSearchField ? 2 : -1);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275conditional(3, ctx.entities && !ctx.isPreparing ? 3 : 4);
        }
      }, dependencies: [i3.NgTemplateOutlet, i4.NgbDropdown, i4.NgbDropdownToggle, i4.NgbDropdownMenu, i4.NgbDropdownItem, i4.NgbDropdownButtonItem, i4.NgbTypeahead, i5.FaIconComponent, TranslateDirective, ArtemisTranslatePipe], styles: ['@charset "UTF-8";\n\n/* src/main/webapp/app/shared/data-table/data-table.component.scss */\n[class^=datatable-icon-]::before,\n[class*=" datatable-icon-"]::before {\n  display: inline-block;\n  position: relative;\n  transform: scale(1.5, 0.6);\n  top: -0.2rem;\n  font-family:\n    "Helvetica Neue",\n    Helvetica,\n    Arial,\n    sans-serif !important;\n  font-style: normal !important;\n  font-weight: normal !important;\n  font-variant: normal !important;\n  text-transform: none !important;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  speak: none;\n}\n.datatable-icon-left::before {\n  content: "\\27e8";\n}\n.datatable-icon-right::before {\n  content: "\\27e9";\n}\n.datatable-icon-down::before {\n  content: "\\2228";\n}\n.datatable-icon-skip::before {\n  content: "\\27eb";\n}\n.datatable-icon-prev::before {\n  content: "\\27ea";\n}\n.datatable-scroll {\n  width: 100% !important;\n}\n.loading-container {\n  height: 40vh;\n}\n.data-table-container {\n  position: relative;\n}\n.transitioning-container {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  opacity: 0;\n  pointer-events: none;\n  transition: 0.05s ease-out opacity;\n}\n.transitioning-container.active {\n  background-color: var(--data-table-transitioning-container-active-background-color);\n  opacity: 1;\n  pointer-events: auto;\n  transition: 0.15s ease-in opacity;\n}\n.search-container {\n  position: relative;\n  flex: 1;\n}\n.search-info {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  padding: 0 0.75rem;\n  font-size: 18px;\n  pointer-events: none;\n  opacity: 0;\n  transition: 0.1s ease-out opacity;\n}\n.search-info.active {\n  opacity: 1;\n  transition: 0.2s ease-in opacity;\n}\nngb-typeahead-window.dropdown-menu.show {\n  max-height: calc(100vh - 380px);\n  overflow-y: auto !important;\n  will-change: unset !important;\n}\n.dropdown-item.selected {\n  background-color: var(--data-table-dropdown-item-selected-background-color);\n}\n.datatable-body-cell-label {\n  display: flex;\n  align-items: center;\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2NvbnRlbnQvc2Nzcy9fZGF0YS10YWJsZS1pY29ucy5zY3NzIiwgInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2RhdGEtdGFibGUvZGF0YS10YWJsZS5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiW2NsYXNzXj0nZGF0YXRhYmxlLWljb24tJ106OmJlZm9yZSxcbltjbGFzcyo9JyBkYXRhdGFibGUtaWNvbi0nXTo6YmVmb3JlIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHRyYW5zZm9ybTogc2NhbGUoMS41LCAwLjYpO1xuICAgIHRvcDogLTAuMnJlbTtcbiAgICBmb250LWZhbWlseTogJ0hlbHZldGljYSBOZXVlJywgSGVsdmV0aWNhLCBBcmlhbCwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbCAhaW1wb3J0YW50O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWwgIWltcG9ydGFudDtcbiAgICBmb250LXZhcmlhbnQ6IG5vcm1hbCAhaW1wb3J0YW50O1xuICAgIHRleHQtdHJhbnNmb3JtOiBub25lICFpbXBvcnRhbnQ7XG4gICAgLXdlYmtpdC1mb250LXNtb290aGluZzogYW50aWFsaWFzZWQ7XG4gICAgLW1vei1vc3gtZm9udC1zbW9vdGhpbmc6IGdyYXlzY2FsZTtcbiAgICBzcGVhazogbm9uZTtcbn1cblxuLmRhdGF0YWJsZS1pY29uLWxlZnQ6OmJlZm9yZSB7XG4gICAgY29udGVudDogJ+KfqCc7XG59XG5cbi5kYXRhdGFibGUtaWNvbi1yaWdodDo6YmVmb3JlIHtcbiAgICBjb250ZW50OiAn4p+pJztcbn1cblxuLmRhdGF0YWJsZS1pY29uLWRvd246OmJlZm9yZSB7XG4gICAgY29udGVudDogJ+KIqCc7XG59XG5cbi5kYXRhdGFibGUtaWNvbi1za2lwOjpiZWZvcmUge1xuICAgIGNvbnRlbnQ6ICfin6snO1xufVxuXG4uZGF0YXRhYmxlLWljb24tcHJldjo6YmVmb3JlIHtcbiAgICBjb250ZW50OiAn4p+qJztcbn1cbiIsICJAaW1wb3J0ICdzcmMvbWFpbi93ZWJhcHAvY29udGVudC9zY3NzL2RhdGEtdGFibGUtaWNvbnMnO1xuXG4uZGF0YXRhYmxlLXNjcm9sbCB7XG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbn1cblxuLmxvYWRpbmctY29udGFpbmVyIHtcbiAgICBoZWlnaHQ6IDQwdmg7XG59XG5cbi5kYXRhLXRhYmxlLWNvbnRhaW5lciB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4udHJhbnNpdGlvbmluZy1jb250YWluZXIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDA7XG4gICAgbGVmdDogMDtcbiAgICByaWdodDogMDtcbiAgICBib3R0b206IDA7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgb3BhY2l0eTogMDtcbiAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICB0cmFuc2l0aW9uOiAwLjA1cyBlYXNlLW91dCBvcGFjaXR5O1xuXG4gICAgJi5hY3RpdmUge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1kYXRhLXRhYmxlLXRyYW5zaXRpb25pbmctY29udGFpbmVyLWFjdGl2ZS1iYWNrZ3JvdW5kLWNvbG9yKTtcblxuICAgICAgICBvcGFjaXR5OiAxO1xuICAgICAgICBwb2ludGVyLWV2ZW50czogYXV0bztcbiAgICAgICAgdHJhbnNpdGlvbjogMC4xNXMgZWFzZS1pbiBvcGFjaXR5O1xuICAgIH1cbn1cblxuLnNlYXJjaC1jb250YWluZXIge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBmbGV4OiAxO1xufVxuXG4uc2VhcmNoLWluZm8ge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDA7XG4gICAgcmlnaHQ6IDA7XG4gICAgYm90dG9tOiAwO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBwYWRkaW5nOiAwIDAuNzVyZW07XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuXG4gICAgb3BhY2l0eTogMDtcbiAgICB0cmFuc2l0aW9uOiAwLjFzIGVhc2Utb3V0IG9wYWNpdHk7XG5cbiAgICAmLmFjdGl2ZSB7XG4gICAgICAgIG9wYWNpdHk6IDE7XG4gICAgICAgIHRyYW5zaXRpb246IDAuMnMgZWFzZS1pbiBvcGFjaXR5O1xuICAgIH1cbn1cblxubmdiLXR5cGVhaGVhZC13aW5kb3cuZHJvcGRvd24tbWVudS5zaG93IHtcbiAgICBtYXgtaGVpZ2h0OiBjYWxjKDEwMHZoIC0gMzgwcHgpO1xuICAgIG92ZXJmbG93LXk6IGF1dG8gIWltcG9ydGFudDtcbiAgICB3aWxsLWNoYW5nZTogdW5zZXQgIWltcG9ydGFudDtcbn1cblxuLmRyb3Bkb3duLWl0ZW0uc2VsZWN0ZWQge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWRhdGEtdGFibGUtZHJvcGRvd24taXRlbS1zZWxlY3RlZC1iYWNrZ3JvdW5kLWNvbG9yKTtcbn1cblxuLmRhdGF0YWJsZS1ib2R5LWNlbGwtbGFiZWwge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBoZWlnaHQ6IDEwMCU7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFBQSxDQUFBLHVCQUFBO0FBQUEsQ0FBQSwwQkFBQTtBQUVJLFdBQUE7QUFDQSxZQUFBO0FBQ0EsYUFBQSxNQUFBLEdBQUEsRUFBQTtBQUNBLE9BQUE7QUFDQTtJQUFBLGdCQUFBO0lBQUEsU0FBQTtJQUFBLEtBQUE7SUFBQTtBQUNBLGNBQUE7QUFDQSxlQUFBO0FBQ0EsZ0JBQUE7QUFDQSxrQkFBQTtBQUNBLDBCQUFBO0FBQ0EsMkJBQUE7QUFDQSxTQUFBOztBQUdKLENBQUEsbUJBQUE7QUFDSSxXQUFBOztBQUdKLENBQUEsb0JBQUE7QUFDSSxXQUFBOztBQUdKLENBQUEsbUJBQUE7QUFDSSxXQUFBOztBQUdKLENBQUEsbUJBQUE7QUFDSSxXQUFBOztBQUdKLENBQUEsbUJBQUE7QUFDSSxXQUFBOztBQy9CSixDQUFBO0FBQ0ksU0FBQTs7QUFHSixDQUFBO0FBQ0ksVUFBQTs7QUFHSixDQUFBO0FBQ0ksWUFBQTs7QUFHSixDQUFBO0FBQ0ksWUFBQTtBQUNBLE9BQUE7QUFDQSxRQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxXQUFBO0FBQ0EsbUJBQUE7QUFDQSxlQUFBO0FBRUEsV0FBQTtBQUNBLGtCQUFBO0FBQ0EsY0FBQSxNQUFBLFNBQUE7O0FBRUEsQ0FkSix1QkFjSSxDQUFBO0FBQ0ksb0JBQUEsSUFBQTtBQUVBLFdBQUE7QUFDQSxrQkFBQTtBQUNBLGNBQUEsTUFBQSxRQUFBOztBQUlSLENBQUE7QUFDSSxZQUFBO0FBQ0EsUUFBQTs7QUFHSixDQUFBO0FBQ0ksWUFBQTtBQUNBLE9BQUE7QUFDQSxTQUFBO0FBQ0EsVUFBQTtBQUNBLFdBQUE7QUFDQSxtQkFBQTtBQUNBLGVBQUE7QUFDQSxXQUFBLEVBQUE7QUFDQSxhQUFBO0FBQ0Esa0JBQUE7QUFFQSxXQUFBO0FBQ0EsY0FBQSxLQUFBLFNBQUE7O0FBRUEsQ0FmSixXQWVJLENBN0JBO0FBOEJJLFdBQUE7QUFDQSxjQUFBLEtBQUEsUUFBQTs7QUFJUixvQkFBQSxDQUFBLGFBQUEsQ0FBQTtBQUNJLGNBQUEsS0FBQSxNQUFBLEVBQUE7QUFDQSxjQUFBO0FBQ0EsZUFBQTs7QUFHSixDQUFBLGFBQUEsQ0FBQTtBQUNJLG9CQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLFdBQUE7QUFDQSxlQUFBO0FBQ0EsVUFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */\n'], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(DataTableComponent, { className: "DataTableComponent" });
    })();
    entityToString = (entity) => entity.id.toString();
    onSearchDefaultWrapper = (stream$) => {
      return stream$.pipe(map(({ entities }) => {
        return entities;
      }));
    };
    onAutocompleteSelectDefaultWrapper = (entity, callback) => {
      callback(entity);
    };
  }
});

// src/main/webapp/app/shared/data-table/data-table.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgxDatatableModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@flaviosantoro92_ngx-datatable.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisDataTableModule;
var init_data_table_module = __esm({
  "src/main/webapp/app/shared/data-table/data-table.module.ts"() {
    init_shared_module();
    init_data_table_component();
    ArtemisDataTableModule = class _ArtemisDataTableModule {
      static \u0275fac = function ArtemisDataTableModule_Factory(t) {
        return new (t || _ArtemisDataTableModule)();
      };
      static \u0275mod = i02.\u0275\u0275defineNgModule({ type: _ArtemisDataTableModule });
      static \u0275inj = i02.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, NgxDatatableModule] });
    };
  }
});

export {
  DataTableComponent,
  init_data_table_component,
  ArtemisDataTableModule,
  init_data_table_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2RhdGEtdGFibGUvZGF0YS10YWJsZS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9kYXRhLXRhYmxlL2RhdGEtdGFibGUuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9kYXRhLXRhYmxlL2RhdGEtdGFibGUubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgQ29udGVudENoaWxkLCBFbGVtZW50UmVmLCBFdmVudEVtaXR0ZXIsIElucHV0LCBPbkNoYW5nZXMsIE9uSW5pdCwgT3V0cHV0LCBTaW1wbGVDaGFuZ2VzLCBUZW1wbGF0ZVJlZiwgVmlld0NoaWxkLCBWaWV3RW5jYXBzdWxhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZGVib3VuY2VUaW1lLCBkaXN0aW5jdFVudGlsQ2hhbmdlZCwgbWFwLCB0YXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBDb2x1bW5Nb2RlLCBTb3J0VHlwZSB9IGZyb20gJ0BmbGF2aW9zYW50b3JvOTIvbmd4LWRhdGF0YWJsZSc7XG5pbXBvcnQgeyBmbGF0dGVuLCBnZXQsIGlzTnVtYmVyIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IEJhc2VFbnRpdHkgfSBmcm9tICdhcHAvc2hhcmVkL21vZGVsL2Jhc2UtZW50aXR5JztcbmltcG9ydCB7IExvY2FsU3RvcmFnZVNlcnZpY2UgfSBmcm9tICduZ3gtd2Vic3RvcmFnZSc7XG5pbXBvcnQgeyBTb3J0U2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2VydmljZS9zb3J0LnNlcnZpY2UnO1xuaW1wb3J0IHsgZmFDaXJjbGVOb3RjaCwgZmFTb3J0LCBmYVNvcnREb3duLCBmYVNvcnRVcCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5cbi8qKlxuICogRW51bSBmb3IgYXNjZW5kaW5nIGFuZCBkZXNjZW5kaW5nIG9yZGVyLlxuICogQHJlYWRvbmx5XG4gKiBAZW51bSB7c3RyaW5nfVxuICovXG5lbnVtIFNvcnRPcmRlciB7XG4gICAgQVNDID0gJ2FzYycsXG4gICAgREVTQyA9ICdkZXNjJyxcbn1cblxuLyoqXG4gKiBFbnVtIGZvciB0aGUgc29ydCBpY29uLlxuICogQHJlYWRvbmx5XG4gKiBAZW51bSB7c3RyaW5nfVxuICovXG5jb25zdCBTb3J0SWNvbiA9IHtcbiAgICBOT05FOiBmYVNvcnQsXG4gICAgQVNDOiBmYVNvcnRVcCxcbiAgICBERVNDOiBmYVNvcnREb3duLFxufTtcblxuY29uc3QgU29ydE9yZGVySWNvbiA9IHtcbiAgICBbU29ydE9yZGVyLkFTQ106IFNvcnRJY29uLkFTQyxcbiAgICBbU29ydE9yZGVyLkRFU0NdOiBTb3J0SWNvbi5ERVNDLFxufTtcblxudHlwZSBTb3J0UHJvcCA9IHtcbiAgICBmaWVsZDogc3RyaW5nO1xuICAgIG9yZGVyOiBTb3J0T3JkZXI7XG59O1xuXG50eXBlIFBhZ2luZ1ZhbHVlID0gbnVtYmVyIHwgJ2FsbCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWRhdGEtdGFibGUnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9kYXRhLXRhYmxlLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnZGF0YS10YWJsZS5jb21wb25lbnQuc2NzcyddLFxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXG59KVxuZXhwb3J0IGNsYXNzIERhdGFUYWJsZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcbiAgICAvKipcbiAgICAgKiBAcHJvcGVydHkgdGVtcGxhdGVSZWYgUmVmIHRvIHRoZSBjb250ZW50IGNoaWxkIG9mIHRoaXMgY29tcG9uZW50ICh3aGljaCBpcyBuZ3gtZGF0YXRhYmxlKVxuICAgICAqL1xuICAgIEBDb250ZW50Q2hpbGQoVGVtcGxhdGVSZWYsIHsgcmVhZDogVGVtcGxhdGVSZWYsIHN0YXRpYzogZmFsc2UgfSkgdGVtcGxhdGVSZWY6IFRlbXBsYXRlUmVmPGFueT47XG5cbiAgICAvKipcbiAgICAgKiBAcHJvcGVydHkgbmdiVHlwZWFoZWFkIFJlZiB0byB0aGUgYXV0b2NvbXBsZXRlIGNvbXBvbmVudCBmcm9tIEFuZ3VsYXJcbiAgICAgKi9cbiAgICBAVmlld0NoaWxkKCduZ2JUeXBlYWhlYWQnLCB7IHN0YXRpYzogZmFsc2UgfSkgbmdiVHlwZWFoZWFkOiBFbGVtZW50UmVmO1xuXG4gICAgLyoqXG4gICAgICogQHByb3BlcnR5IGlzTG9hZGluZyBMb2FkaW5nIHN0YXRlIG9mIHRoZSBkYXRhIHRoYXQgaXMgZmV0Y2hlZCBieSB0aGUgYW5jZXN0cmFsIGNvbXBvbmVudFxuICAgICAqIEBwcm9wZXJ0eSBpc1NlYXJjaGluZyBXaGV0aGVyIHRvIHNob3cgYSBzcGlubmVyIGluc2lkZSBvZiB0aGUgaW5wdXQgZmllbGQgb24gdGhlIHJpZ2h0IHNpZGUgKGluZGljYXRpbmcgYSBzZXJ2ZXIgc2VhcmNoKVxuICAgICAqIEBwcm9wZXJ0eSBzZWFyY2hGYWlsZWQgV2hldGhlciB0byBzaG93IGEgYmFkZ2UgdGhhdCBpbmRpY2F0ZXMgdGhhdCB0aGUgc2VhcmNoIGhhcyBmYWlsZWRcbiAgICAgKiBAcHJvcGVydHkgc2VhcmNoTm9SZXN1bHRzIFdoZXRoZXIgdG8gc2hvdyBhIGJhZGdlIHRoYXQgaW5kaWNhdGVzIHRoYXQgdGhlIHNlYXJjaCBkaWQgbm90IHJldHVybiBhbnkgcmVzdWx0c1xuICAgICAqIEBwcm9wZXJ0eSBpc1RyYW5zaXRpb25pbmcgTG9hZGluZyBvdmVybGF5IG9uIHRvcCBvZiB0aGUgdGFibGUgaW5kaWNhdGluZyB0aGF0IHRoZSBjb250ZW50IGlzIGNoYW5naW5nXG4gICAgICogQHByb3BlcnR5IHNob3dQYWdlU2l6ZURyb3Bkb3duIEZsYWcgd2hldGhlciB0byBzaG93IHRoZSBcImVudGl0aWVzIHBlciBwYWdlXCIgZHJvcGRvd25cbiAgICAgKiBAcHJvcGVydHkgc2hvd1NlYXJjaEZpZWxkIEZsYWcgd2hldGhlciB0byBzaG93IHRoZSBzZWFyY2ggaW5wdXQgZmllbGRcbiAgICAgKiBAcHJvcGVydHkgZW50aXR5VHlwZSBFbnRpdHkgaWRlbnRpZmllciAoZS5nLiAncmVzdWx0JyBvciAncGFydGljaXBhdGlvbicpIHVzZWQgYXMgYSBrZXkgdG8gZGlmZmVyZW50aWF0ZSBmcm9tIG90aGVyIHRhYmxlc1xuICAgICAqIEBwcm9wZXJ0eSBhbGxFbnRpdGllcyBMaXN0IG9mIGFsbCBlbnRpdGllcyB0aGF0IHNob3VsZCBiZSBkaXNwbGF5ZWQgaW4gdGhlIHRhYmxlIChvbmUgZW50aXR5IHBlciByb3cpXG4gICAgICogQHByb3BlcnR5IGVudGl0aWVzUGVyUGFnZVRyYW5zbGF0aW9uIFRyYW5zbGF0aW9uIHN0cmluZyB0aGF0IGhhcyB0aGUgdmFyaWFibGUge3sgbnVtYmVyIH19IGluIGl0IChlLmcuICdhcnRlbWlzQXBwLmV4ZXJjaXNlLnJlc3VsdHNQZXJQYWdlJylcbiAgICAgKiBAcHJvcGVydHkgc2hvd0FsbEVudGl0aWVzVHJhbnNsYXRpb24gVHJhbnNsYXRpb24gc3RyaW5nIGlmIGFsbCBlbnRpdGllcyBzaG91bGQgYmUgZGlzcGxheWVkIChlLmcuICdhcnRlbWlzQXBwLmV4ZXJjaXNlLnNob3dBbGwnKVxuICAgICAqIEBwcm9wZXJ0eSBzZWFyY2hOb1Jlc3VsdHNUcmFuc2xhdGlvbiBUcmFuc2xhdGlvbiBzdHJpbmcgdGhhdCBoYXMgdGhlIHZhcmlhYmxlIHt7IGxlbmd0aCB9fSBpbiBpdCAoZGVmYXVsdDogJ2FydGVtaXNBcHAuZGF0YVRhYmxlLnNlYXJjaC5ub1Jlc3VsdHMnKVxuICAgICAqIEBwcm9wZXJ0eSBzZWFyY2hQbGFjZWhvbGRlclRyYW5zbGF0aW9uIFRyYW5zbGF0aW9uIHN0cmluZyB0aGF0IGlzIHVzZWQgZm9yIHRoZSBwbGFjZWhvbGRlciBpbiB0aGUgc2VhcmNoIGlucHV0IGZpZWxkXG4gICAgICogQHByb3BlcnR5IG1pblF1ZXJ5TGVuZ3RoSGludFRyYW5zbGF0aW9uIFRyYW5zbGF0aW9uIHN0cmluZyB0aGF0IGlzIHVzZWQgdG8gaW5mb3JtIHRoZSB1c2VyIGFib3V0IHRoZSBtaW4uIG51bWJlciBvZiBjaGFyYWN0ZXJzIHRoYXQgbXVzdCBiZSBpbnB1dCB0byB0cmlnZ2VyIGEgc2VhcmNoXG4gICAgICogQHByb3BlcnR5IHNlYXJjaEZpZWxkcyBGaWVsZHMgb2YgZW50aXR5IHdob3NlIHZhbHVlcyB3aWxsIGJlIGNvbXBhcmVkIHRvIHRoZSB1c2VyJ3Mgc2VhcmNoIHN0cmluZyAoYWxsb3dzIG5lc3RlZCBhdHRyaWJ1dGVzLCBlLmcuIFsnc3R1ZGVudC5sb2dpbicsICdzdHVkZW50Lm5hbWUnXSlcbiAgICAgKiBAcHJvcGVydHkgc2VhcmNoRW5hYmxlZCBGbGFnIHdoZXRoZXIgc2VhcmNoaW5nIGlzIGVuYWJsZWQgKGRlZmF1bHQ6IHRydWUpXG4gICAgICogQHByb3BlcnR5IHNlYXJjaEVudGl0eUZpbHRlckVuYWJsZWQgRmxhZyB3aGV0aGVyIHNlYXJjaGluZyBzaG91bGQgY2F1c2UgYSBmaWx0ZXJpbmcgb2YgdGhlIGVudGl0aWVzIChkZWZhdWx0OiB0cnVlKVxuICAgICAqIEBmdW5jdGlvbiBzZWFyY2hUZXh0RnJvbUVudGl0eSBGdW5jdGlvbiB0aGF0IHRha2VzIGFuIGVudGl0eSBhbmQgcmV0dXJucyBhIHRleHQgdGhhdCBpcyBpbnNlcnRlZCBpbnRvIHRoZSBzZWFyY2ggaW5wdXQgZmllbGQgd2hlbiBjbGlja2luZyBvbiBhbiBhdXRvY29tcGxldGUgc3VnZ2VzdGlvblxuICAgICAqIEBmdW5jdGlvbiBzZWFyY2hSZXN1bHRGb3JtYXR0ZXIgRnVuY3Rpb24gdGhhdCB0YWtlcyBhbiBlbnRpdHkgYW5kIHJldHVybnMgdGhlIHRleHQgZm9yIHRoZSBhdXRvY29tcGxldGUgc3VnZ2VzdGlvbiByZXN1bHQgcm93XG4gICAgICogQGZ1bmN0aW9uIG9uU2VhcmNoV3JhcHBlciBXcmFwcGVyIGFyb3VuZCB0aGUgb25TZWFyY2ggbWV0aG9kIHRoYXQgY2FuIGJlIHVzZWQgdG8gbW9kaWZ5IHRoZSBpdGVtcyBkaXNwbGF5ZWQgaW4gdGhlIGF1dG9jb21wbGV0ZVxuICAgICAqIEBmdW5jdGlvbiBvbkF1dG9jb21wbGV0ZVNlbGVjdFdyYXBwZXIgV3JhcHBlciB0aGF0IGNhbiBiZSB1c2VkIHRvIGhvb2sgaW50byB0aGUgcHJvY2VzcyB3aGVuIGFuIGVudGl0eSB3YXMgc2VsZWN0ZWQgaW4gdGhlIGF1dG9jb21wbGV0ZVxuICAgICAqIEBmdW5jdGlvbiBjdXN0b21GaWx0ZXIgRnVuY3Rpb24gdGhhdCB0YWtlcyBhbiBlbnRpdHkgYW5kIHJldHVybnMgdHJ1ZSBvciBmYWxzZSBkZXBlbmRpbmcgb24gd2hldGhlciB0aGlzIGVudGl0eSBzaG91bGQgYmUgc2hvd24gKGNvbWJpbmUgd2l0aCBjdXN0b21GaWx0ZXJLZXkpXG4gICAgICogQHByb3BlcnR5IGN1c3RvbUZpbHRlcktleSBGaWx0ZXIgc3RhdGUgb2YgYW4gYW5jZXN0cmFsIGNvbXBvbmVudCB3aGljaCB0cmlnZ2VycyBhIHRhYmxlIHJlLXJlbmRlcmluZyBpZiBpdCBjaGFuZ2VzXG4gICAgICovXG4gICAgQElucHV0KCkgaXNMb2FkaW5nID0gZmFsc2U7XG4gICAgQElucHV0KCkgaXNTZWFyY2hpbmcgPSBmYWxzZTtcbiAgICBASW5wdXQoKSBzZWFyY2hGYWlsZWQgPSBmYWxzZTtcbiAgICBASW5wdXQoKSBzZWFyY2hOb1Jlc3VsdHMgPSBmYWxzZTtcbiAgICBASW5wdXQoKSBpc1RyYW5zaXRpb25pbmcgPSBmYWxzZTtcbiAgICBASW5wdXQoKSBzaG93UGFnZVNpemVEcm9wZG93biA9IHRydWU7XG4gICAgQElucHV0KCkgc2hvd1NlYXJjaEZpZWxkID0gdHJ1ZTtcbiAgICBASW5wdXQoKSBlbnRpdHlUeXBlID0gJ2VudGl0eSc7XG4gICAgQElucHV0KCkgYWxsRW50aXRpZXM6IEJhc2VFbnRpdHlbXSA9IFtdO1xuICAgIEBJbnB1dCgpIGVudGl0aWVzUGVyUGFnZVRyYW5zbGF0aW9uOiBzdHJpbmc7XG4gICAgQElucHV0KCkgc2hvd0FsbEVudGl0aWVzVHJhbnNsYXRpb246IHN0cmluZztcbiAgICBASW5wdXQoKSBzZWFyY2hOb1Jlc3VsdHNUcmFuc2xhdGlvbiA9ICdhcnRlbWlzQXBwLmRhdGFUYWJsZS5zZWFyY2gubm9SZXN1bHRzJztcbiAgICBASW5wdXQoKSBzZWFyY2hQbGFjZWhvbGRlclRyYW5zbGF0aW9uOiBzdHJpbmc7XG4gICAgQElucHV0KCkgbWluUXVlcnlMZW5ndGhIaW50VHJhbnNsYXRpb24gPSAnYXJ0ZW1pc0FwcC5kYXRhVGFibGUuc2VhcmNoLm1pblF1ZXJ5TGVuZ3RoSGludCc7XG4gICAgQElucHV0KCkgc2VhcmNoRmllbGRzOiBzdHJpbmdbXSA9IFtdO1xuICAgIEBJbnB1dCgpIHNlYXJjaEVuYWJsZWQgPSB0cnVlO1xuICAgIEBJbnB1dCgpIHNlYXJjaEVudGl0eUZpbHRlckVuYWJsZWQgPSB0cnVlO1xuICAgIEBJbnB1dCgpIHNlYXJjaFRleHRGcm9tRW50aXR5OiAoZW50aXR5OiBCYXNlRW50aXR5KSA9PiBzdHJpbmcgPSBlbnRpdHlUb1N0cmluZztcbiAgICBASW5wdXQoKSBzZWFyY2hSZXN1bHRGb3JtYXR0ZXI6IChlbnRpdHk6IEJhc2VFbnRpdHkpID0+IHN0cmluZyA9IGVudGl0eVRvU3RyaW5nO1xuICAgIEBJbnB1dCgpIG9uU2VhcmNoV3JhcHBlcjogKHN0cmVhbTogT2JzZXJ2YWJsZTx7IHRleHQ6IHN0cmluZzsgZW50aXRpZXM6IEJhc2VFbnRpdHlbXSB9PikgPT4gT2JzZXJ2YWJsZTxCYXNlRW50aXR5W10+ID0gb25TZWFyY2hEZWZhdWx0V3JhcHBlcjtcbiAgICBASW5wdXQoKSBvbkF1dG9jb21wbGV0ZVNlbGVjdFdyYXBwZXI6IChlbnRpdHk6IEJhc2VFbnRpdHksIGNhbGxiYWNrOiAoZW50aXR5OiBCYXNlRW50aXR5KSA9PiB2b2lkKSA9PiB2b2lkID0gb25BdXRvY29tcGxldGVTZWxlY3REZWZhdWx0V3JhcHBlcjtcbiAgICBASW5wdXQoKSBjdXN0b21GaWx0ZXI6IChlbnRpdHk6IEJhc2VFbnRpdHkpID0+IGJvb2xlYW4gPSAoKSA9PiB0cnVlO1xuICAgIEBJbnB1dCgpIGN1c3RvbUZpbHRlcktleTogYW55ID0ge307XG5cbiAgICAvKipcbiAgICAgKiBAcHJvcGVydHkgZW50aXRpZXNTaXplQ2hhbmdlIEVtaXRzIGFuIGV2ZW50IHdoZW4gdGhlIG51bWJlciBvZiBlbnRpdGllcyBkaXNwbGF5ZWQgY2hhbmdlcyAoZS5nLiBieSBmaWx0ZXJpbmcpXG4gICAgICovXG4gICAgQE91dHB1dCgpIGVudGl0aWVzU2l6ZUNoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8bnVtYmVyPigpO1xuXG4gICAgLyoqXG4gICAgICogQHByb3BlcnR5IFBBR0lOR19WQUxVRVMgUG9zc2libGUgdmFsdWVzIGZvciB0aGUgbnVtYmVyIG9mIGVudGl0aWVzIHNob3duIHBlciBwYWdlIG9mIHRoZSB0YWJsZVxuICAgICAqIEBwcm9wZXJ0eSBERUZBVUxUX1BBR0lOR19WQUxVRSBEZWZhdWx0IG51bWJlciBvZiBlbnRpdGllcyBzaG93biBwZXIgcGFnZSBpZiB0aGUgdXNlciBoYXMgbm8gdmFsdWUgc2V0IGZvciB0aGlzIHlldCBpbiBsb2NhbCBzdG9yYWdlXG4gICAgICovXG4gICAgcmVhZG9ubHkgUEFHSU5HX1ZBTFVFUzogUGFnaW5nVmFsdWVbXSA9IFsxMCwgMjAsIDUwLCAxMDAsIDIwMCwgNTAwLCAxMDAwLCAnYWxsJ107XG4gICAgcmVhZG9ubHkgREVGQVVMVF9QQUdJTkdfVkFMVUUgPSA1MDtcblxuICAgIC8qKlxuICAgICAqIEBwcm9wZXJ0eSBpc1JlbmRlcmluZyBSZW5kZXJpbmcgc3RhdGUgb2YgdGhlIHRhYmxlICh1c2VkIGZvciBjb25kaXRpb25hbCBkaXNwbGF5IG9mIHRoZSBsb2FkaW5nIGluZGljYXRvcilcbiAgICAgKiBAcHJvcGVydHkgZW50aXRpZXMgKFNvcnRlZCkgTGlzdCBvZiBlbnRpdGllcyB0aGF0IGFyZSBzaG93biBpbiB0aGUgdGFibGUgKGlzIGEgc3Vic2V0IG9mIGFsbEVudGl0aWVzIGFmdGVyIGZpbHRlcnMgd2VyZSBhcHBsaWVkKVxuICAgICAqIEBwcm9wZXJ0eSBwYWdpbmdWYWx1ZSBDdXJyZW50IG51bWJlciAob3IgJ2FsbCcpIG9mIGVudGl0aWVzIGRpc3BsYXllZCBwZXIgcGFnZSAoY2FuIGJlIGNoYW5nZWQgYW5kIHNhdmVkIHRvIGxvY2FsIHN0b3JhZ2UgYnkgdGhlIHVzZXIpXG4gICAgICogQHByb3BlcnR5IGVudGl0eUNyaXRlcmlhIENvbnRhaW5zIGEgbGlzdCBvZiBzZWFyY2ggdGVybXNcbiAgICAgKi9cbiAgICBpc1JlbmRlcmluZzogYm9vbGVhbjtcbiAgICBlbnRpdGllczogQmFzZUVudGl0eVtdO1xuICAgIHBhZ2luZ1ZhbHVlOiBQYWdpbmdWYWx1ZTtcbiAgICBlbnRpdHlDcml0ZXJpYToge1xuICAgICAgICB0ZXh0U2VhcmNoOiBzdHJpbmdbXTtcbiAgICAgICAgc29ydFByb3A6IFNvcnRQcm9wO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBAcHJvcGVydHkgc2VhcmNoUXVlcnlUb29TaG9ydCBXaGV0aGVyIHRoZSBlbnRlcmVkIHNlYXJjaCB0ZXJtXG4gICAgICogQHByb3BlcnR5IG1pblNlYXJjaFF1ZXJ5TGVuZ3RoIE1pbmltdW0gbnVtYmVyIG9mIGNoYXJhY3RlcnMgYmVmb3JlIGEgc2VhcmNoIGlzIHRyaWdnZXJlZFxuICAgICAqL1xuICAgIHNlYXJjaFF1ZXJ5VG9vU2hvcnQ6IGJvb2xlYW47XG4gICAgcmVhZG9ubHkgbWluU2VhcmNoUXVlcnlMZW5ndGggPSAzO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUNpcmNsZU5vdGNoID0gZmFDaXJjbGVOb3RjaDtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIHNvcnRTZXJ2aWNlOiBTb3J0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBsb2NhbFN0b3JhZ2U6IExvY2FsU3RvcmFnZVNlcnZpY2UsXG4gICAgKSB7XG4gICAgICAgIHRoaXMuZW50aXRpZXMgPSBbXTtcbiAgICAgICAgdGhpcy5lbnRpdHlDcml0ZXJpYSA9IHtcbiAgICAgICAgICAgIHRleHRTZWFyY2g6IFtdLFxuICAgICAgICAgICAgc29ydFByb3A6IHsgZmllbGQ6ICdpZCcsIG9yZGVyOiBTb3J0T3JkZXIuQVNDIH0sXG4gICAgICAgIH07XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTGlmZSBjeWNsZSBob29rIGNhbGxlZCBieSBBbmd1bGFyIHRvIGluZGljYXRlIHRoYXQgQW5ndWxhciBpcyBkb25lIGNyZWF0aW5nIHRoZSBjb21wb25lbnRcbiAgICAgKi9cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5wYWdpbmdWYWx1ZSA9IHRoaXMuZ2V0Q2FjaGVkRW50aXRpZXNQZXJQYWdlKCk7XG5cbiAgICAgICAgLy8gZXhwbGljaXRseSBiaW5kIHRoZXNlIGNhbGxiYWNrcyB0byB0aGVpciBjdXJyZW50IGNvbnRleHRcbiAgICAgICAgLy8gc28gdGhhdCB0aGV5IGNhbiBiZSB1c2VkIGZyb20gY2hpbGQgY29tcG9uZW50c1xuICAgICAgICB0aGlzLm9uU29ydCA9IHRoaXMub25Tb3J0LmJpbmQodGhpcyk7XG4gICAgICAgIHRoaXMuaWNvbkZvclNvcnRQcm9wRmllbGQgPSB0aGlzLmljb25Gb3JTb3J0UHJvcEZpZWxkLmJpbmQodGhpcyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTWV0aG9kIGlzIGNhbGxlZCB3aGVuIElucHV0cyBvZiB0aGlzIGNvbXBvbmVudCBoYXZlIGNoYW5nZWQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gY2hhbmdlcyBMaXN0IG9mIElucHV0cyB0aGF0IHdlcmUgY2hhbmdlZFxuICAgICAqL1xuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcbiAgICAgICAgaWYgKGNoYW5nZXMuYWxsRW50aXRpZXMgfHwgY2hhbmdlcy5jdXN0b21GaWx0ZXJLZXkpIHtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlRW50aXRpZXMoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFRoaXMgY29udGV4dCB3aWxsIGJlIHBhc3NlZCBkb3duIHRvIHRlbXBsYXRlUmVmIGFuZCB3aWxsIGJlXG4gICAgICogYXZhaWxhYmxlIGZvciBiaW5kaW5nIGJ5IHRoZSBsb2NhbCB0ZW1wbGF0ZSBsZXQgZGVjbGFyYXRpb25zXG4gICAgICovXG4gICAgZ2V0IGNvbnRleHQoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzZXR0aW5nczoge1xuICAgICAgICAgICAgICAgIGxpbWl0OiB0aGlzLnBhZ2VMaW1pdCxcbiAgICAgICAgICAgICAgICBzb3J0VHlwZTogU29ydFR5cGUubXVsdGksXG4gICAgICAgICAgICAgICAgY29sdW1uTW9kZTogQ29sdW1uTW9kZS5mb3JjZSxcbiAgICAgICAgICAgICAgICBoZWFkZXJIZWlnaHQ6IDUwLFxuICAgICAgICAgICAgICAgIGZvb3RlckhlaWdodDogNTAsXG4gICAgICAgICAgICAgICAgcm93SGVpZ2h0OiAnYXV0bycsXG4gICAgICAgICAgICAgICAgcm93czogdGhpcy5lbnRpdGllcyxcbiAgICAgICAgICAgICAgICByb3dDbGFzczogJycsXG4gICAgICAgICAgICAgICAgc2Nyb2xsYmFySDogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjb250cm9sczoge1xuICAgICAgICAgICAgICAgIGljb25Gb3JTb3J0UHJvcEZpZWxkOiB0aGlzLmljb25Gb3JTb3J0UHJvcEZpZWxkLFxuICAgICAgICAgICAgICAgIG9uU29ydDogdGhpcy5vblNvcnQsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFRoZSBjb21wb25lbnQgaXMgcHJlcGFyaW5nIGlmIHRoZSBkYXRhIGlzIGxvYWRpbmcgKG1hbmFnZWQgYnkgdGhlIHBhcmVudCBjb21wb25lbnQpXG4gICAgICogb3IgcmVuZGVyaW5nIChtYW5hZ2VkIGJ5IHRoaXMgY29tcG9uZW50KS5cbiAgICAgKi9cbiAgICBnZXQgaXNQcmVwYXJpbmcoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlzTG9hZGluZyB8fCB0aGlzLmlzUmVuZGVyaW5nO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE51bWJlciBvZiBlbnRpdGllcyBkaXNwbGF5ZWQgcGVyIHBhZ2UuIENhbiBiZSB1bmRlZmluZWQgdG8gc2hvdyBhbGwgZW50aXRpZXMgd2l0aG91dCBwYWdpbmF0aW9uLlxuICAgICAqL1xuICAgIGdldCBwYWdlTGltaXQoKSB7XG4gICAgICAgIHJldHVybiBpc051bWJlcih0aGlzLnBhZ2luZ1ZhbHVlKSA/IHRoaXMucGFnaW5nVmFsdWUgOiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgdHJhbnNsYXRpb24gYmFzZWQgb24gd2hldGhlciBhIGxpbWl0ZWQgbnVtYmVyIG9mIGVudGl0aWVzIGlzIGRpc3BsYXllZCBvciBhbGxcbiAgICAgKlxuICAgICAqIEBwYXJhbSBxdWFudGlmaWVyIE51bWJlciBvZiBlbnRpdGllcyBwZXIgcGFnZSBvciAnYWxsJ1xuICAgICAqL1xuICAgIHBlclBhZ2VUcmFuc2xhdGlvbihxdWFudGlmaWVyOiBQYWdpbmdWYWx1ZSkge1xuICAgICAgICByZXR1cm4gaXNOdW1iZXIocXVhbnRpZmllcikgPyB0aGlzLmVudGl0aWVzUGVyUGFnZVRyYW5zbGF0aW9uIDogdGhpcy5zaG93QWxsRW50aXRpZXNUcmFuc2xhdGlvbjtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBLZXkgdGhhdCBpcyB1c2VkIGZvciBzdG9yaW5nIHRoaXMgXCJpdGVtcyBwZXIgcGFnZVwiIHNldHRpbmcgaW4gbG9jYWwgc3RvcmFnZVxuICAgICAqL1xuICAgIHByaXZhdGUgZ2V0IHBlclBhZ2VDYWNoZUtleSgpIHtcbiAgICAgICAgcmV0dXJuIGAke3RoaXMuZW50aXR5VHlwZX0taXRlbXMtcGVyLXBhZ2VgO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBcIml0ZW1zIHBlciBwYWdlXCIgc2V0dGluZyBmcm9tIGxvY2FsIHN0b3JhZ2UuIElmIGl0IGRvZXMgbm90IGV4aXN0LCB1c2UgdGhlIGRlZmF1bHQuXG4gICAgICovXG4gICAgcHJpdmF0ZSBnZXRDYWNoZWRFbnRpdGllc1BlclBhZ2UgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNhY2hlZFZhbHVlID0gdGhpcy5sb2NhbFN0b3JhZ2UucmV0cmlldmUodGhpcy5wZXJQYWdlQ2FjaGVLZXkpO1xuICAgICAgICBpZiAoY2FjaGVkVmFsdWUpIHtcbiAgICAgICAgICAgIGNvbnN0IHBhcnNlZFZhbHVlID0gcGFyc2VJbnQoY2FjaGVkVmFsdWUsIDEwKSB8fCBjYWNoZWRWYWx1ZTtcbiAgICAgICAgICAgIGlmICh0aGlzLlBBR0lOR19WQUxVRVMuaW5jbHVkZXMocGFyc2VkVmFsdWUgYXMgYW55KSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBwYXJzZWRWYWx1ZSBhcyBQYWdpbmdWYWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5ERUZBVUxUX1BBR0lOR19WQUxVRTtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogU2V0IHRoZSBudW1iZXIgb2YgZW50aXRpZXMgc2hvd24gcGVyIHBhZ2UgKGFuZCBwZXJzaXN0IGl0IGluIGxvY2FsIHN0b3JhZ2UpLlxuICAgICAqIFNpbmNlIHRoZSByZW5kZXJpbmcgdGFrZXMgYSBiaXQsIHNob3cgdGhlIGxvYWRpbmcgYW5pbWF0aW9uIHVudGlsIGl0IGNvbXBsZXRlcy5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBwYWdpbmcgTnVtYmVyIG9mIGVudGl0aWVzIHBlciBwYWdlXG4gICAgICovXG4gICAgc2V0RW50aXRpZXNQZXJQYWdlID0gKHBhZ2luZzogUGFnaW5nVmFsdWUpID0+IHtcbiAgICAgICAgdGhpcy5pc1JlbmRlcmluZyA9IHRydWU7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5wYWdpbmdWYWx1ZSA9IHBhZ2luZztcbiAgICAgICAgICAgIHRoaXMuaXNSZW5kZXJpbmcgPSBmYWxzZTtcbiAgICAgICAgfSwgNTAwKTtcbiAgICAgICAgdGhpcy5sb2NhbFN0b3JhZ2Uuc3RvcmUodGhpcy5wZXJQYWdlQ2FjaGVLZXksIHBhZ2luZy50b1N0cmluZygpKTtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogVXBkYXRlcyB0aGUgVUkgd2l0aCBhbGwgYXZhaWxhYmxlIGZpbHRlci9zb3J0IHNldHRpbmdzLlxuICAgICAqIEZpcnN0IHBlcmZvcm1zIHRoZSBmaWx0ZXJpbmcsIHRoZW4gc29ydHMgdGhlIHJlbWFpbmluZyBlbnRpdGllcy5cbiAgICAgKi9cbiAgICBwcml2YXRlIHVwZGF0ZUVudGl0aWVzKCkge1xuICAgICAgICBjb25zdCBzZWFyY2hQcmVkaWNhdGUgPSAoZW50aXR5OiBCYXNlRW50aXR5KSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gIXRoaXMuc2VhcmNoRW50aXR5RmlsdGVyRW5hYmxlZCB8fCB0aGlzLmZpbHRlckVudGl0eUJ5VGV4dFNlYXJjaCh0aGlzLmVudGl0eUNyaXRlcmlhLnRleHRTZWFyY2gsIGVudGl0eSwgdGhpcy5zZWFyY2hGaWVsZHMpO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBmaWx0ZXJlZEVudGl0aWVzID0gdGhpcy5hbGxFbnRpdGllcy5maWx0ZXIoKGVudGl0eSkgPT4gdGhpcy5jdXN0b21GaWx0ZXIoZW50aXR5KSAmJiBzZWFyY2hQcmVkaWNhdGUoZW50aXR5KSk7XG4gICAgICAgIHRoaXMuZW50aXRpZXMgPSB0aGlzLnNvcnRTZXJ2aWNlLnNvcnRCeVByb3BlcnR5KGZpbHRlcmVkRW50aXRpZXMsIHRoaXMuZW50aXR5Q3JpdGVyaWEuc29ydFByb3AuZmllbGQsIHRoaXMuZW50aXR5Q3JpdGVyaWEuc29ydFByb3Aub3JkZXIgPT09IFNvcnRPcmRlci5BU0MpO1xuICAgICAgICAvLyBkZWZlciBleGVjdXRpb24gb2YgY2hhbmdlIGVtaXQgdG8gcHJldmVudCBFeHByZXNzaW9uQ2hhbmdlZEFmdGVySXRIYXNCZWVuQ2hlY2tlZEVycm9yLCBzZWUgZXhwbGFuYXRpb24gYXQgaHR0cHM6Ly9ibG9nLmFuZ3VsYXItdW5pdmVyc2l0eS5pby9hbmd1bGFyLWRlYnVnZ2luZy9cbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB0aGlzLmVudGl0aWVzU2l6ZUNoYW5nZS5lbWl0KHRoaXMuZW50aXRpZXMubGVuZ3RoKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRmlsdGVyIHRoZSBnaXZlbiBlbnRpdGllcyBieSB0aGUgcHJvdmlkZWQgc2VhcmNoIHdvcmRzLlxuICAgICAqIFJldHVybnMgZW50aXRpZXMgdGhhdCBtYXRjaCBhbnkgb2YgdGhlIHByb3ZpZGVzIHNlYXJjaCB3b3JkcywgaWYgc2VhcmNoV29yZHMgaXMgZW1wdHkgcmV0dXJucyBhbGwgZW50aXRpZXMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gc2VhcmNoV29yZHMgbGlzdCBvZiBzdHVkZW50IGxvZ2lucyBvciBuYW1lc1xuICAgICAqIEBwYXJhbSBlbnRpdHkgQmFzZUVudGl0eVxuICAgICAqIEBwYXJhbSBzZWFyY2hGaWVsZHMgbGlzdCBvZiBwYXRocyBpbiBlbnRpdHkgdG8gc2VhcmNoXG4gICAgICovXG4gICAgcHJpdmF0ZSBmaWx0ZXJFbnRpdHlCeVRleHRTZWFyY2ggPSAoc2VhcmNoV29yZHM6IHN0cmluZ1tdLCBlbnRpdHk6IEJhc2VFbnRpdHksIHNlYXJjaEZpZWxkczogc3RyaW5nW10pID0+IHtcbiAgICAgICAgLy8gV2hlbiBubyBzZWFyY2ggd29yZCBpcyBpbnB1dHRlZCwgd2UgcmV0dXJuIGFsbCBlbnRpdGllcy5cbiAgICAgICAgaWYgKCFzZWFyY2hXb3Jkcy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIC8vIE90aGVyd2lzZSB3ZSBkbyBhIGZ1enp5IHNlYXJjaCBvbiB0aGUgaW5wdXR0ZWQgc2VhcmNoIHdvcmRzLlxuICAgICAgICBjb25zdCBjb250YWluc1NlYXJjaFdvcmQgPSAoZmllbGRWYWx1ZTogc3RyaW5nKSA9PiBzZWFyY2hXb3Jkcy5zb21lKHRoaXMuZm91bmRJbihmaWVsZFZhbHVlKSk7XG4gICAgICAgIHJldHVybiB0aGlzLmVudGl0eUZpZWxkVmFsdWVzKGVudGl0eSwgc2VhcmNoRmllbGRzKS5zb21lKGNvbnRhaW5zU2VhcmNoV29yZCk7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIHZhbHVlcyB0aGF0IHRoZSBnaXZlbiBlbnRpdHkgaGFzIGluIHRoZSBnaXZlbiBmaWVsZHNcbiAgICAgKlxuICAgICAqIEBwYXJhbSBlbnRpdHkgRW50aXR5IHdob3NlIGZpZWxkIHZhbHVlcyBhcmUgZXh0cmFjdGVkXG4gICAgICogQHBhcmFtIGZpZWxkcyBGaWVsZHMgdG8gZXh0cmFjdCBmcm9tIGVudGl0eSAoY2FuIGJlIHBhdGhzIHN1Y2ggYXMgXCJzdHVkZW50LmxvZ2luXCIpXG4gICAgICovXG4gICAgcHJpdmF0ZSBlbnRpdHlGaWVsZFZhbHVlcyA9IChlbnRpdHk6IEJhc2VFbnRpdHksIGZpZWxkczogc3RyaW5nW10pID0+IHtcbiAgICAgICAgcmV0dXJuIGZsYXR0ZW4oZmllbGRzLm1hcCgoZmllbGQpID0+IHRoaXMuY29sbGVjdEVudGl0eUZpZWxkVmFsdWVzKGVudGl0eSwgZmllbGQpKSkuZmlsdGVyKEJvb2xlYW4pIGFzIHN0cmluZ1tdO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSB2YWx1ZXMgdGhhdCB0aGUgZ2l2ZW4gZW50aXR5IGhhcyBpbiB0aGUgZ2l2ZW4gZmllbGQuXG4gICAgICogVXN1YWxseSwgdGhpcyB3aWxsIGJlIG9uZSB2YWx1ZSBidXQgaWYgdGhlIGZpZWxkIHBhdGggY29udGFpbnMgYW4gYXJyYXksIHRoZSByZXN0IG9mIHRoZSBwYXRoIHdpbGwgYmUgcmVzb2x2ZWQgZm9yIGVhY2ggYXJyYXkgZWxlbWVudC5cbiAgICAgKiBWYWx1ZXMgYXJlIG1lcmdlZCByZWN1cnNpdmVseSBpbnRvIGEgZmxhdCBsaXN0LlxuICAgICAqXG4gICAgICogQHBhcmFtIGVudGl0eSBFbnRpdHkgd2hvc2UgZmllbGQgdmFsdWVzIGFyZSBleHRyYWN0ZWRcbiAgICAgKiBAcGFyYW0gZmllbGQgRmllbGQgdG8gZXh0cmFjdCBmcm9tIGVudGl0eSAoY2FuIGJlIHBhdGhzIHN1Y2ggYXMgXCJzdHVkZW50LmxvZ2luXCIgb3IgYXJyYXkgcGF0aCBzdWNoIGFzIFwic3R1ZGVudHMubG9naW5cIilcbiAgICAgKi9cbiAgICBwcml2YXRlIGNvbGxlY3RFbnRpdHlGaWVsZFZhbHVlcyA9IChlbnRpdHk6IEJhc2VFbnRpdHksIGZpZWxkOiBzdHJpbmcpOiBhbnlbXSA9PiB7XG4gICAgICAgIGNvbnN0IHNlcGFyYXRvciA9ICcuJztcbiAgICAgICAgY29uc3QgW2hlYWQsIC4uLnRhaWxdID0gZmllbGQuc3BsaXQoc2VwYXJhdG9yKTtcbiAgICAgICAgaWYgKHRhaWwubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgY29uc3QgcmVzb2x2ZWQgPSBnZXQoZW50aXR5LCBoZWFkKTtcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHJlc29sdmVkKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmbGF0dGVuKHJlc29sdmVkLm1hcCgoc3ViRW50aXR5KSA9PiB0aGlzLmNvbGxlY3RFbnRpdHlGaWVsZFZhbHVlcyhzdWJFbnRpdHksIHRhaWwuam9pbihzZXBhcmF0b3IpKSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29sbGVjdEVudGl0eUZpZWxkVmFsdWVzKHJlc29sdmVkLCB0YWlsLmpvaW4oc2VwYXJhdG9yKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFtnZXQoZW50aXR5LCBoZWFkLCBmYWxzZSldO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBQZXJmb3JtcyBhIGNhc2UtaW5zZW5zaXRpdmUgc2VhcmNoIG9mIFwid29yZFwiIGluc2lkZSBvZiBcInRleHRcIi5cbiAgICAgKiBJZiBcIndvcmRcIiBjb25zaXN0cyBvZiBtdWx0aXBsZSBzZWdtZW50cyBzZXBhcmF0ZWQgYnkgYSBzcGFjZSwgZWFjaCBvbmUgb2YgdGhlbSBtdXN0IGFwcGVhciBpbiBcInRleHRcIi5cbiAgICAgKiBUaGlzIHJlbGF4YXRpb24gaGFzIHRoZSBiZW5lZml0IHRoYXQgc2VhcmNoaW5nIGZvciBcIk1heCBNdXN0ZXJtYW5uXCIgd2lsbCBzdGlsbCBmaW5kIFwiTWF4IEdyZWdvciBNdXN0ZXJtYW5uXCIuXG4gICAgICogQWRkaXRpb25hbGx5LCB0aGUgd2lsZGNhcmQgc3ltYm9scyBcIipcIiBhbmQgXCI/XCIgYXJlIHN1cHBvcnRlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB0ZXh0IHN0cmluZyB0aGF0IGlzIHNlYXJjaGVkIGZvciBwYXJhbSBcIndvcmRcIlxuICAgICAqL1xuICAgIHByaXZhdGUgZm91bmRJbiA9ICh0ZXh0OiBzdHJpbmcpID0+ICh3b3JkOiBzdHJpbmcpID0+IHtcbiAgICAgICAgY29uc3Qgc2VnbWVudHMgPSB3b3JkLnRvTG93ZXJDYXNlKCkuc3BsaXQoJyAnKTtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIHRleHQgJiZcbiAgICAgICAgICAgIHdvcmQgJiZcbiAgICAgICAgICAgIHNlZ21lbnRzLmV2ZXJ5KChzZWdtZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVnZXggPSBzZWdtZW50XG4gICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9bLitcXC1eJHt9KCl8W1xcXVxcXFxdL2csICdcXFxcJCYnKSAvLyBlc2NhcGVcbiAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcKi9nLCAnLionKSAvLyBtdWx0aXBsZSBjaGFyYWN0ZXJzXG4gICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9cXD8vZywgJy4nKTsgLy8gc2luZ2xlIGNoYXJhY3RlclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgUmVnRXhwKHJlZ2V4KS50ZXN0KHRleHQudG9Mb3dlckNhc2UoKSk7XG4gICAgICAgICAgICB9KVxuICAgICAgICApO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBTcGxpdHMgdGhlIHByb3ZpZGVzIHNlYXJjaCB3b3JkcyBieSBjb21tYSBhbmQgdXBkYXRlcyB0aGUgYXV0b2NvbXBsZXRpb24gb3ZlcmxheS5cbiAgICAgKiBBbHNvIHVwZGF0ZXMgdGhlIGF2YWlsYWJsZSBlbnRpdGllcyBpbiB0aGUgVUkuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdGV4dCQgc3RyZWFtIG9mIHRleHQgaW5wdXQuXG4gICAgICovXG4gICAgb25TZWFyY2ggPSAodGV4dCQ6IE9ic2VydmFibGU8c3RyaW5nPik6IE9ic2VydmFibGU8QmFzZUVudGl0eVtdPiA9PiB7XG4gICAgICAgIHJldHVybiB0aGlzLm9uU2VhcmNoV3JhcHBlcihcbiAgICAgICAgICAgIHRleHQkLnBpcGUoXG4gICAgICAgICAgICAgICAgZGVib3VuY2VUaW1lKDIwMCksXG4gICAgICAgICAgICAgICAgZGlzdGluY3RVbnRpbENoYW5nZWQoKSxcbiAgICAgICAgICAgICAgICB0YXAoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNlYXJjaFF1ZXJ5VG9vU2hvcnQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICBtYXAoKHRleHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2VhcmNoV29yZHMgPSB0ZXh0LnNwbGl0KCcsJykubWFwKCh3b3JkKSA9PiB3b3JkLnRyaW0oKSk7XG4gICAgICAgICAgICAgICAgICAgIC8vIFdoZW4gdGhlIGVudGl0eSBmaWVsZCBpcyBjbGVhcmVkLCB3ZSB0cmFuc2xhdGUgdGhlIHJlc3VsdGluZyBlbXB0eSBzdHJpbmcgdG8gYW4gZW1wdHkgYXJyYXkgKG90aGVyd2lzZSBubyBlbnRpdGllcyB3b3VsZCBiZSBmb3VuZCkuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7IHRleHQsIHNlYXJjaFdvcmRzOiBzZWFyY2hXb3Jkcy5sZW5ndGggPT09IDEgJiYgIXNlYXJjaFdvcmRzWzBdID8gW10gOiBzZWFyY2hXb3JkcyB9O1xuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgIC8vIEZvciBhdmFpbGFibGUgZW50aXRpZXMgaW4gdGFibGUuXG4gICAgICAgICAgICAgICAgdGFwKCh7IHNlYXJjaFdvcmRzIH0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5lbnRpdHlDcml0ZXJpYS50ZXh0U2VhcmNoID0gc2VhcmNoV29yZHM7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlRW50aXRpZXMoKTtcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAvLyBGb3IgYXV0b2NvbXBsZXRlLlxuICAgICAgICAgICAgICAgIG1hcCgoeyB0ZXh0LCBzZWFyY2hXb3JkcyB9KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFdlIG9ubHkgZXhlY3V0ZSB0aGUgYXV0b2NvbXBsZXRlIGZvciB0aGUgbGFzdCBrZXl3b3JkIGluIHRoZSBwcm92aWRlZCBsaXN0LlxuICAgICAgICAgICAgICAgICAgICBjb25zdCBsYXN0U2VhcmNoV29yZCA9IHNlYXJjaFdvcmRzLmxhc3QoKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gRG9uJ3QgZXhlY3V0ZSBhdXRvY29tcGxldGUgZm9yIGxlc3MgdGhhbiB0d28gaW5wdXR0ZWQgY2hhcmFjdGVycy5cbiAgICAgICAgICAgICAgICAgICAgaWYgKCFsYXN0U2VhcmNoV29yZCB8fCBsYXN0U2VhcmNoV29yZC5sZW5ndGggPCB0aGlzLm1pblNlYXJjaFF1ZXJ5TGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNlYXJjaFF1ZXJ5VG9vU2hvcnQgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgdGV4dCwgZW50aXRpZXM6IFtdIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRleHQsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbnRpdGllczogdGhpcy5lbnRpdGllcy5maWx0ZXIoKGVudGl0eSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkVmFsdWVzID0gdGhpcy5lbnRpdHlGaWVsZFZhbHVlcyhlbnRpdHksIHRoaXMuc2VhcmNoRmllbGRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmllbGRWYWx1ZXMuc29tZSgoZmllbGRWYWx1ZSkgPT4gdGhpcy5mb3VuZEluKGZpZWxkVmFsdWUpKGxhc3RTZWFyY2hXb3JkKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICksXG4gICAgICAgICk7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIEZ1bmN0aW9uIHRoYXQgaXMgY2FsbGVkIHdoZW4gdGhlIHNlYXJjaCBpbnB1dCBlbWl0cyBhIGJsdXIgZXZlbnQuXG4gICAgICogQ2FuIGJlIHVzZWQgdG8gY2xlYXIgdXAgc2VhcmNoLXJlbGF0ZWQgaW5mbyBtZXNzYWdlcy5cbiAgICAgKi9cbiAgICBvblNlYXJjaElucHV0Qmx1cigpIHtcbiAgICAgICAgdGhpcy5zZWFyY2hRdWVyeVRvb1Nob3J0ID0gZmFsc2U7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUHJvcGVydHkgdGhhdCBleHBvc2VzIHRoZSB0eXBlYWhlYWQgYnV0dG9ucyAoPSBhdXRvY29tcGxldGUgc3VnZ2VzdGlvbiBvcHRpb25zKSBhcyBET00gZWxlbWVudHNcbiAgICAgKi9cbiAgICBnZXQgdHlwZWFoZWFkQnV0dG9ucygpIHtcbiAgICAgICAgcmV0dXJuIGdldCh0aGlzLm5nYlR5cGVhaGVhZCwgJ25hdGl2ZUVsZW1lbnQubmV4dFNpYmxpbmcuY2hpbGRyZW4nLCBbXSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTWV0aG9kIGlzIGNhbGxlZCB3aGVuIHVzZXIgY2xpY2tzIG9uIGFuIGF1dG9jb21wbGV0ZSBzdWdnZXN0aW9uLiBUaGUgaW5wdXQgbWV0aG9kXG4gICAgICogc2VhcmNoVGV4dEZyb21FbnRpdHkgZGV0ZXJtaW5lcyBob3cgdGhlIGVudGl0eSBpcyBjb252ZXJ0ZWQgdG8gYSBzZWFyY2hhYmxlIHN0cmluZy5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBlbnRpdHkgRW50aXR5IHRoYXQgd2FzIHNlbGVjdGVkIHZpYSBhdXRvY29tcGxldGVcbiAgICAgKi9cbiAgICBvbkF1dG9jb21wbGV0ZVNlbGVjdCA9IChlbnRpdHk6IEJhc2VFbnRpdHkpID0+IHtcbiAgICAgICAgdGhpcy5lbnRpdHlDcml0ZXJpYS50ZXh0U2VhcmNoW3RoaXMuZW50aXR5Q3JpdGVyaWEudGV4dFNlYXJjaC5sZW5ndGggLSAxXSA9IHRoaXMuc2VhcmNoVGV4dEZyb21FbnRpdHkoZW50aXR5KTtcbiAgICAgICAgdGhpcy5vbkF1dG9jb21wbGV0ZVNlbGVjdFdyYXBwZXIoZW50aXR5LCB0aGlzLmZpbHRlckFmdGVyQXV0b2NvbXBsZXRlU2VsZWN0KTtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogTWV0aG9kIHVwZGF0ZXMgdGhlIGRpc3BsYXllZCBlbnRpdGllcyAod2lsbCBiZSBvbmx5IG9uZSBlbnRpdHkgaWYgdGhlIHNlYXJjaCB0ZXh0IGlzIHVuaXF1ZSBwZXIgZW50aXR5KS5cbiAgICAgKi9cbiAgICBmaWx0ZXJBZnRlckF1dG9jb21wbGV0ZVNlbGVjdCA9ICgpID0+IHtcbiAgICAgICAgdGhpcy51cGRhdGVFbnRpdGllcygpO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBGb3JtYXRzIHRoZSBzZWFyY2ggaW5wdXQuXG4gICAgICovXG4gICAgc2VhcmNoSW5wdXRGb3JtYXR0ZXIgPSAoKSA9PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmVudGl0eUNyaXRlcmlhLnRleHRTZWFyY2guam9pbignLCAnKTtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogU2V0cyB0aGUgc2VsZWN0ZWQgc29ydCBmaWVsZCwgdGhlbiB1cGRhdGVzIHRoZSBhdmFpbGFibGUgZW50aXRpZXMgaW4gdGhlIFVJLlxuICAgICAqIFRvZ2dsZXMgdGhlIG9yZGVyIGRpcmVjdGlvbiAoYXNjLCBkZXNjKSB3aGVuIHRoZSBmaWVsZCBoYXMgbm90IGNoYW5nZWQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZmllbGQgRW50aXR5IGZpZWxkXG4gICAgICovXG4gICAgb25Tb3J0KGZpZWxkOiBzdHJpbmcpIHtcbiAgICAgICAgY29uc3Qgc2FtZUZpZWxkID0gdGhpcy5lbnRpdHlDcml0ZXJpYS5zb3J0UHJvcCAmJiB0aGlzLmVudGl0eUNyaXRlcmlhLnNvcnRQcm9wLmZpZWxkID09PSBmaWVsZDtcbiAgICAgICAgY29uc3Qgb3JkZXIgPSBzYW1lRmllbGQgPyB0aGlzLmludmVydFNvcnQodGhpcy5lbnRpdHlDcml0ZXJpYS5zb3J0UHJvcC5vcmRlcikgOiBTb3J0T3JkZXIuQVNDO1xuICAgICAgICB0aGlzLmVudGl0eUNyaXRlcmlhLnNvcnRQcm9wID0geyBmaWVsZCwgb3JkZXIgfTtcbiAgICAgICAgdGhpcy51cGRhdGVFbnRpdGllcygpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIG9wcG9zaXRlIHNvcnQgb3JkZXIgb2YgdGhlIGdpdmVuIHNvcnQgb3JkZXIuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gb3JkZXIgU29ydE9yZGVyXG4gICAgICovXG4gICAgcHJpdmF0ZSBpbnZlcnRTb3J0ID0gKG9yZGVyOiBTb3J0T3JkZXIpID0+IHtcbiAgICAgICAgcmV0dXJuIG9yZGVyID09PSBTb3J0T3JkZXIuQVNDID8gU29ydE9yZGVyLkRFU0MgOiBTb3J0T3JkZXIuQVNDO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBGb250IEF3ZXNvbWUgaWNvbiBuYW1lIGZvciBhIGNvbHVtbiBoZWFkZXIncyBzb3J0aW5nIGljb25cbiAgICAgKiBiYXNlZCBvbiB0aGUgY3VycmVudGx5IGFjdGl2ZSBzb3J0UHJvcCBmaWVsZCBhbmQgb3JkZXIuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZmllbGQgRW50aXR5IGZpZWxkXG4gICAgICovXG4gICAgaWNvbkZvclNvcnRQcm9wRmllbGQoZmllbGQ6IHN0cmluZykge1xuICAgICAgICBpZiAodGhpcy5lbnRpdHlDcml0ZXJpYS5zb3J0UHJvcC5maWVsZCAhPT0gZmllbGQpIHtcbiAgICAgICAgICAgIHJldHVybiBTb3J0SWNvbi5OT05FO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBTb3J0T3JkZXJJY29uW3RoaXMuZW50aXR5Q3JpdGVyaWEuc29ydFByb3Aub3JkZXJdO1xuICAgIH1cbn1cblxuY29uc3QgZW50aXR5VG9TdHJpbmcgPSAoZW50aXR5OiBCYXNlRW50aXR5KSA9PiBlbnRpdHkuaWQhLnRvU3RyaW5nKCk7XG5cbi8qKlxuICogRGVmYXVsdCBvbiBzZWFyY2ggd3JhcHBlciB0aGF0IHNpbXBseSBzdHJpcHMgdGhlIHNlYXJjaCB0ZXh0IGFuZCBwYXNzZXMgb24gdGhlIHJlc3VsdHMuXG4gKiBUaGlzIGNhbiBiZSBjdXN0b21pemVkIGJ5IHN1cHBseWluZyB5b3VyIG93biBvblNlYXJjaFdyYXBwZXIgYXMgYW4gSW5wdXQgdGhhdCBlLmcuIG1vZGlmaWVzIHRoZSByZXN1bHRzLlxuICogSnVzdCBjb3B5IHRoZSBkZWZhdWx0IHdyYXBwZXIgYmVsb3cgaW50byB5b3VyIGNvbnN1bWVyIGNvbXBvbmVudCAodGhhdCB1c2VzIHRoaXMgY29tcG9uZW50KSBhcyBhIGJsdWVwcmludCBhbmQgYWRhcHQgaXQuXG4gKlxuICogQHBhcmFtIHN0cmVhbSQgc3RyZWFtIG9mIHNlYXJjaGVzIG9mIHRoZSBmb3JtYXQge3RleHQsIGVudGl0aWVzfSB3aGVyZSBlbnRpdGllcyBhcmUgdGhlIHJlc3VsdHNcbiAqL1xuY29uc3Qgb25TZWFyY2hEZWZhdWx0V3JhcHBlciA9IChzdHJlYW0kOiBPYnNlcnZhYmxlPHsgdGV4dDogc3RyaW5nOyBlbnRpdGllczogQmFzZUVudGl0eVtdIH0+KTogT2JzZXJ2YWJsZTxCYXNlRW50aXR5W10+ID0+IHtcbiAgICByZXR1cm4gc3RyZWFtJC5waXBlKFxuICAgICAgICBtYXAoKHsgZW50aXRpZXMgfSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIGVudGl0aWVzO1xuICAgICAgICB9KSxcbiAgICApO1xufTtcblxuLyoqXG4gKiBEZWZhdWx0IG9uIGF1dG9jb21wbGV0ZSBzZWxlY3Qgd3JhcHBlciB0aGF0IHNpbXBseSBjYWxscyB0aGUgcHJvdmlkZWQgY2FsbGJhY2sgKHdoaWNoIGlzIHRoaXMgY29tcG9uZW50cyBvbkF1dG9jb21wbGV0ZVNlbGVjdCkuXG4gKiBUaGlzIGNhbiBiZSBjdXN0b21pemVkIGJ5IHN1cHBseWluZyB5b3VyIG93biBvbkF1dG9jb21wbGV0ZVNlbGVjdFdyYXBwZXIgYXMgYW4gSW5wdXQgdGhhdCBjaGFuZ2VzIG9yIGFkZHMgYmVoYXZpb3IuXG4gKiBKdXN0IGNvcHkgdGhlIGRlZmF1bHQgd3JhcHBlciBiZWxvdyBpbnRvIHlvdXIgY29uc3VtZXIgY29tcG9uZW50ICh0aGF0IHVzZXMgdGhpcyBjb21wb25lbnQpIGFzIGEgYmx1ZXByaW50IGFuZCBhZGFwdCBpdC5cbiAqXG4gKiBAcGFyYW0gZW50aXR5IFRoZSBzZWxlY3RlZCBlbnRpdHkgZnJvbSB0aGUgYXV0b2NvbXBsZXRlIHN1Z2dlc3Rpb25zXG4gKiBAcGFyYW0gY2FsbGJhY2sgRnVuY3Rpb24gdGhhdCBjYW4gYmUgY2FsbGVkIHdpdGggdGhlIHNlbGVjdGVkIGVudGl0eSB0byB0cmlnZ2VyIHRoaXMgY29tcG9uZW50J3MgZGVmYXVsdCBiZWhhdmlvciBmb3Igb24gc2VsZWN0XG4gKi9cbmNvbnN0IG9uQXV0b2NvbXBsZXRlU2VsZWN0RGVmYXVsdFdyYXBwZXIgPSAoZW50aXR5OiBCYXNlRW50aXR5LCBjYWxsYmFjazogKGVudGl0eTogQmFzZUVudGl0eSkgPT4gdm9pZCk6IHZvaWQgPT4ge1xuICAgIGNhbGxiYWNrKGVudGl0eSk7XG59O1xuIiwiPGRpdj5cbiAgICBAaWYgKHNob3dQYWdlU2l6ZURyb3Bkb3duIHx8IHNob3dTZWFyY2hGaWVsZCkge1xuICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IG1iLTIgZ2FwLTEgZmxleC1jb2x1bW4gZmxleC1tZC1yb3dcIj5cbiAgICAgICAgICAgIEBpZiAoc2hvd1BhZ2VTaXplRHJvcGRvd24pIHtcbiAgICAgICAgICAgICAgICA8ZGl2IG5nYkRyb3Bkb3duIGNsYXNzPVwiZC1pbmxpbmUtYmxvY2sgbWUtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1vdXRsaW5lLXByaW1hcnkgdy0xMDBcIiBpZD1cImRyb3Bkb3duQmFzaWMxXCIgbmdiRHJvcGRvd25Ub2dnbGU+XG4gICAgICAgICAgICAgICAgICAgICAgICB7eyBwZXJQYWdlVHJhbnNsYXRpb24ocGFnaW5nVmFsdWUpIHwgYXJ0ZW1pc1RyYW5zbGF0ZTogeyBudW1iZXI6IHBhZ2luZ1ZhbHVlIH0gfX1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgbmdiRHJvcGRvd25NZW51IGFyaWEtbGFiZWxsZWRieT1cImRyb3Bkb3duQmFzaWMxXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBAZm9yIChwYWdpbmdPcHRpb24gb2YgUEFHSU5HX1ZBTFVFUzsgdHJhY2sgcGFnaW5nT3B0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwic2V0RW50aXRpZXNQZXJQYWdlKHBhZ2luZ09wdGlvbilcIiBbY2xhc3Muc2VsZWN0ZWRdPVwicGFnaW5nT3B0aW9uID09PSBwYWdpbmdWYWx1ZVwiIG5nYkRyb3Bkb3duSXRlbT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgcGVyUGFnZVRyYW5zbGF0aW9uKHBhZ2luZ09wdGlvbikgfCBhcnRlbWlzVHJhbnNsYXRlOiB7IG51bWJlcjogcGFnaW5nT3B0aW9uIH0gfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKHNlYXJjaEVuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2VhcmNoLWNvbnRhaW5lclwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICNuZ2JUeXBlYWhlYWRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwidHlwZWFoZWFkLWJhc2ljXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIChzZWxlY3RJdGVtKT1cIm9uQXV0b2NvbXBsZXRlU2VsZWN0KCRldmVudC5pdGVtKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbcGxhY2Vob2xkZXJdPVwic2VhcmNoUGxhY2Vob2xkZXJUcmFuc2xhdGlvbiB8IGFydGVtaXNUcmFuc2xhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgW25nYlR5cGVhaGVhZF09XCJvblNlYXJjaFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbcmVzdWx0Rm9ybWF0dGVyXT1cInNlYXJjaFJlc3VsdEZvcm1hdHRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICBbaW5wdXRGb3JtYXR0ZXJdPVwic2VhcmNoSW5wdXRGb3JtYXR0ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKGJsdXIpPVwib25TZWFyY2hJbnB1dEJsdXIoKVwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2gtaW5mb1wiIFtjbGFzcy5hY3RpdmVdPVwiaXNTZWFyY2hpbmdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIHNpemU9XCJsZ1wiIFtpY29uXT1cImZhQ2lyY2xlTm90Y2hcIiBbc3Bpbl09XCJ0cnVlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNlYXJjaC1pbmZvXCIgW2NsYXNzLmFjdGl2ZV09XCJzZWFyY2hGYWlsZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctZGFuZ2VyXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5kYXRhVGFibGUuc2VhcmNoLmZhaWxlZFwiPiBTZWFyY2ggZmFpbGVkIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2gtaW5mb1wiIFtjbGFzcy5hY3RpdmVdPVwic2VhcmNoTm9SZXN1bHRzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLXdhcm5pbmdcIiBbamhpVHJhbnNsYXRlXT1cInNlYXJjaE5vUmVzdWx0c1RyYW5zbGF0aW9uXCI+IE5vIHJlc3VsdHMgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNlYXJjaC1pbmZvXCIgW2NsYXNzLmFjdGl2ZV09XCJzZWFyY2hRdWVyeVRvb1Nob3J0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLWluZm9cIiBbamhpVHJhbnNsYXRlXT1cIm1pblF1ZXJ5TGVuZ3RoSGludFRyYW5zbGF0aW9uXCIgW3RyYW5zbGF0ZVZhbHVlc109XCJ7IGxlbmd0aDogbWluU2VhcmNoUXVlcnlMZW5ndGggfVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBsZWFzZSBlbnRlciBhdCBsZWFzdCB7eyBtaW5TZWFyY2hRdWVyeUxlbmd0aCB9fSBjaGFyYWN0ZXJzXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgQGlmIChlbnRpdGllcyAmJiAhaXNQcmVwYXJpbmcpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cInRhYmxlLXJlc3BvbnNpdmUgZGF0YS10YWJsZS1jb250YWluZXJcIj5cbiAgICAgICAgICAgIDxuZy1jb250YWluZXIgKm5nVGVtcGxhdGVPdXRsZXQ9XCJ0ZW1wbGF0ZVJlZjsgY29udGV4dDogY29udGV4dFwiPjwvbmctY29udGFpbmVyPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRyYW5zaXRpb25pbmctY29udGFpbmVyXCIgW2NsYXNzLmFjdGl2ZV09XCJpc1RyYW5zaXRpb25pbmdcIj5cbiAgICAgICAgICAgICAgICA8ZmEtaWNvbiBzaXplPVwibGdcIiBbaWNvbl09XCJmYUNpcmNsZU5vdGNoXCIgW3NwaW5dPVwidHJ1ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICB9IEBlbHNlIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cImxvYWRpbmctY29udGFpbmVyIGQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgPGZhLWljb24gc2l6ZT1cImxnXCIgW2ljb25dPVwiZmFDaXJjbGVOb3RjaFwiIFtzcGluXT1cInRydWVcIj48L2ZhLWljb24+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbjwvZGl2PlxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgTmd4RGF0YXRhYmxlTW9kdWxlIH0gZnJvbSAnQGZsYXZpb3NhbnRvcm85Mi9uZ3gtZGF0YXRhYmxlJztcbmltcG9ydCB7IERhdGFUYWJsZUNvbXBvbmVudCB9IGZyb20gJy4vZGF0YS10YWJsZS5jb21wb25lbnQnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlLCBOZ3hEYXRhdGFibGVNb2R1bGVdLFxuICAgIGRlY2xhcmF0aW9uczogW0RhdGFUYWJsZUNvbXBvbmVudF0sXG4gICAgZXhwb3J0czogW0RhdGFUYWJsZUNvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNEYXRhVGFibGVNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsU0FBUyxXQUFXLGNBQWMsWUFBWSxjQUFjLE9BQTBCLFFBQXVCLGFBQWEsV0FBVyx5QkFBeUI7QUFDOUosU0FBUyxjQUFjLHNCQUFzQixLQUFLLFdBQVc7QUFFN0QsU0FBUyxZQUFZLGdCQUFnQjtBQUNyQyxTQUFTLFNBQVMsS0FBSyxnQkFBZ0I7QUFFdkMsU0FBUywyQkFBMkI7QUFFcEMsU0FBUyxlQUFlLFFBQVEsWUFBWSxnQkFBZ0I7Ozs7Ozs7OztBQ0VoQyxJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsVUFBQSxDQUFBO0FBQVEsSUFBQSx3QkFBQSxTQUFBLFNBQUEseUZBQUE7QUFBQSxZQUFBLGNBQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsa0JBQUEsWUFBQTtBQUFBLFlBQUEsVUFBQSwyQkFBQSxDQUFBO0FBQUEsYUFBUyx5QkFBQSxRQUFBLG1CQUFBLGVBQUEsQ0FBZ0M7SUFBQSxDQUFBO0FBQzdDLElBQUEsb0JBQUEsQ0FBQTs7QUFDSixJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLDRCQUFBOzs7OztBQUh1RCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsb0JBQUEsT0FBQSxXQUFBO0FBQy9DLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsc0NBQUEseUJBQUEsR0FBQSxHQUFBLE9BQUEsbUJBQUEsZUFBQSxHQUFBLDZCQUFBLEdBQUEsS0FBQSxlQUFBLENBQUEsR0FBQSxnQ0FBQTs7Ozs7QUFQaEIsSUFBQSxvQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxVQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLENBQUE7O0FBQ0osSUFBQSwwQkFBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDhCQUFBLEdBQUEsZ0VBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSxzQ0FBQTtBQUtKLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLGdCQUFBOzs7O0FBVlksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSw4QkFBQSx5QkFBQSxHQUFBLEdBQUEsT0FBQSxtQkFBQSxPQUFBLFdBQUEsR0FBQSw2QkFBQSxHQUFBLEtBQUEsT0FBQSxXQUFBLENBQUEsR0FBQSx3QkFBQTtBQUdBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsT0FBQSxhQUFBOzs7Ozs7QUFTUixJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBO0FBS0ksSUFBQSx3QkFBQSxjQUFBLFNBQUEsb0ZBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSwyQkFBQSxDQUFBO0FBQUEsYUFBYyx5QkFBQSxRQUFBLHFCQUFBLE9BQUEsSUFBQSxDQUFpQztJQUFBLENBQUEsRUFBQyxRQUFBLFNBQUEsZ0ZBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBS3hDLHlCQUFBLFFBQUEsa0JBQUEsQ0FBbUI7SUFBQSxDQUFBOztBQVYvQixJQUFBLDBCQUFBO0FBWUEsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsdUJBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBaUYsSUFBQSxvQkFBQSxJQUFBLGlCQUFBO0FBQWMsSUFBQSwwQkFBQTtBQUNuRyxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBNEUsSUFBQSxvQkFBQSxJQUFBLGNBQUE7QUFBVyxJQUFBLDBCQUFBO0FBQzNGLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsRUFBQTtBQUNKLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxnQkFBQTs7OztBQXJCWSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGVBQUEseUJBQUEsR0FBQSxJQUFBLE9BQUEsNEJBQUEsQ0FBQSxFQUErRCxnQkFBQSxPQUFBLFFBQUEsRUFBQSxtQkFBQSxPQUFBLHFCQUFBLEVBQUEsa0JBQUEsT0FBQSxvQkFBQTtBQU0xQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFVBQUEsT0FBQSxXQUFBO0FBQ0YsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxRQUFBLE9BQUEsYUFBQSxFQUFzQixRQUFBLElBQUE7QUFFcEIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxVQUFBLE9BQUEsWUFBQTtBQUdBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsVUFBQSxPQUFBLGVBQUE7QUFDVSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLGdCQUFBLE9BQUEsMEJBQUE7QUFFVixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFVBQUEsT0FBQSxtQkFBQTtBQUNPLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsZ0JBQUEsT0FBQSw2QkFBQSxFQUE4QyxtQkFBQSw2QkFBQSxJQUFBLEtBQUEsT0FBQSxvQkFBQSxDQUFBO0FBQ3RFLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsd0RBQUEsT0FBQSxzQkFBQSx1Q0FBQTs7Ozs7QUF4Q3BCLElBQUEsb0JBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSx5REFBQSxJQUFBLENBQUEsRUFhQyxHQUFBLHlEQUFBLElBQUEsRUFBQTtBQStCTCxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFFBQUE7Ozs7QUE3Q1EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLE9BQUEsdUJBQUEsSUFBQSxFQUFBO0FBY0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxHQUFBLE9BQUEsZ0JBQUEsSUFBQSxFQUFBOzs7OztBQWtDQSxJQUFBLGdDQUFBLENBQUE7Ozs7O0FBREosSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLDBEQUFBLEdBQUEsR0FBQSxnQkFBQSxFQUFBO0FBQ0EsSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsdUJBQUEsR0FBQSxXQUFBLENBQUE7QUFDSixJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLFFBQUE7Ozs7QUFMdUIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxvQkFBQSxPQUFBLFdBQUEsRUFBK0IsMkJBQUEsT0FBQSxPQUFBO0FBQ1QsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxVQUFBLE9BQUEsZUFBQTtBQUNkLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsUUFBQSxPQUFBLGFBQUEsRUFBc0IsUUFBQSxJQUFBOzs7OztBQUlqRCxJQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxHQUFBLFFBQUE7Ozs7QUFGMkIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxRQUFBLE9BQUEsYUFBQSxFQUFzQixRQUFBLElBQUE7OztBRDFEckQsbUJBZUssV0FVQyxVQU1BLGVBa0JPLG9CQXFhUCxnQkFTQSx3QkFnQkE7QUEvZU47O0FBT0E7Ozs7Ozs7QUFRQSxLQUFBLFNBQUtBLFlBQVM7QUFDVixNQUFBQSxXQUFBLEtBQUEsSUFBQTtBQUNBLE1BQUFBLFdBQUEsTUFBQSxJQUFBO0lBQ0osR0FISyxjQUFBLFlBQVMsQ0FBQSxFQUFBO0FBVWQsSUFBTSxXQUFXO01BQ2IsTUFBTTtNQUNOLEtBQUs7TUFDTCxNQUFNOztBQUdWLElBQU0sZ0JBQWdCO01BQ2xCLENBQUMsVUFBVSxHQUFHLEdBQUcsU0FBUztNQUMxQixDQUFDLFVBQVUsSUFBSSxHQUFHLFNBQVM7O0FBZ0J6QixJQUFPLHFCQUFQLE1BQU8sb0JBQWtCO01BaUdmO01BQ0E7TUE5RnFEO01BS25CO01BMkJyQyxZQUFZO01BQ1osY0FBYztNQUNkLGVBQWU7TUFDZixrQkFBa0I7TUFDbEIsa0JBQWtCO01BQ2xCLHVCQUF1QjtNQUN2QixrQkFBa0I7TUFDbEIsYUFBYTtNQUNiLGNBQTRCLENBQUE7TUFDNUI7TUFDQTtNQUNBLDZCQUE2QjtNQUM3QjtNQUNBLGdDQUFnQztNQUNoQyxlQUF5QixDQUFBO01BQ3pCLGdCQUFnQjtNQUNoQiw0QkFBNEI7TUFDNUIsdUJBQXVEO01BQ3ZELHdCQUF3RDtNQUN4RCxrQkFBOEc7TUFDOUcsOEJBQW9HO01BQ3BHLGVBQWdELE1BQU07TUFDdEQsa0JBQXVCLENBQUE7TUFLdEIscUJBQXFCLElBQUksYUFBWTtNQU10QyxnQkFBK0IsQ0FBQyxJQUFJLElBQUksSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFNLEtBQUs7TUFDdEUsdUJBQXVCO01BUWhDO01BQ0E7TUFDQTtNQUNBO01BU0E7TUFDUyx1QkFBdUI7TUFHaEMsZ0JBQWdCO01BRWhCLFlBQ1ksYUFDQSxjQUFpQztBQURqQyxhQUFBLGNBQUE7QUFDQSxhQUFBLGVBQUE7QUFFUixhQUFLLFdBQVcsQ0FBQTtBQUNoQixhQUFLLGlCQUFpQjtVQUNsQixZQUFZLENBQUE7VUFDWixVQUFVLEVBQUUsT0FBTyxNQUFNLE9BQU8sVUFBVSxJQUFHOztNQUVyRDtNQUtBLFdBQVE7QUFDSixhQUFLLGNBQWMsS0FBSyx5QkFBd0I7QUFJaEQsYUFBSyxTQUFTLEtBQUssT0FBTyxLQUFLLElBQUk7QUFDbkMsYUFBSyx1QkFBdUIsS0FBSyxxQkFBcUIsS0FBSyxJQUFJO01BQ25FO01BT0EsWUFBWSxTQUFzQjtBQUM5QixZQUFJLFFBQVEsZUFBZSxRQUFRLGlCQUFpQjtBQUNoRCxlQUFLLGVBQWM7O01BRTNCO01BTUEsSUFBSSxVQUFPO0FBQ1AsZUFBTztVQUNILFVBQVU7WUFDTixPQUFPLEtBQUs7WUFDWixVQUFVLFNBQVM7WUFDbkIsWUFBWSxXQUFXO1lBQ3ZCLGNBQWM7WUFDZCxjQUFjO1lBQ2QsV0FBVztZQUNYLE1BQU0sS0FBSztZQUNYLFVBQVU7WUFDVixZQUFZOztVQUVoQixVQUFVO1lBQ04sc0JBQXNCLEtBQUs7WUFDM0IsUUFBUSxLQUFLOzs7TUFHekI7TUFNQSxJQUFJLGNBQVc7QUFDWCxlQUFPLEtBQUssYUFBYSxLQUFLO01BQ2xDO01BS0EsSUFBSSxZQUFTO0FBQ1QsZUFBTyxTQUFTLEtBQUssV0FBVyxJQUFJLEtBQUssY0FBYztNQUMzRDtNQU9BLG1CQUFtQixZQUF1QjtBQUN0QyxlQUFPLFNBQVMsVUFBVSxJQUFJLEtBQUssNkJBQTZCLEtBQUs7TUFDekU7TUFLQSxJQUFZLGtCQUFlO0FBQ3ZCLGVBQU8sR0FBRyxLQUFLLFVBQVU7TUFDN0I7TUFLUSwyQkFBMkIsTUFBSztBQUNwQyxjQUFNLGNBQWMsS0FBSyxhQUFhLFNBQVMsS0FBSyxlQUFlO0FBQ25FLFlBQUksYUFBYTtBQUNiLGdCQUFNLGNBQWMsU0FBUyxhQUFhLEVBQUUsS0FBSztBQUNqRCxjQUFJLEtBQUssY0FBYyxTQUFTLFdBQWtCLEdBQUc7QUFDakQsbUJBQU87OztBQUdmLGVBQU8sS0FBSztNQUNoQjtNQVFBLHFCQUFxQixDQUFDLFdBQXVCO0FBQ3pDLGFBQUssY0FBYztBQUNuQixtQkFBVyxNQUFLO0FBQ1osZUFBSyxjQUFjO0FBQ25CLGVBQUssY0FBYztRQUN2QixHQUFHLEdBQUc7QUFDTixhQUFLLGFBQWEsTUFBTSxLQUFLLGlCQUFpQixPQUFPLFNBQVEsQ0FBRTtNQUNuRTtNQU1RLGlCQUFjO0FBQ2xCLGNBQU0sa0JBQWtCLENBQUMsV0FBc0I7QUFDM0MsaUJBQU8sQ0FBQyxLQUFLLDZCQUE2QixLQUFLLHlCQUF5QixLQUFLLGVBQWUsWUFBWSxRQUFRLEtBQUssWUFBWTtRQUNySTtBQUNBLGNBQU0sbUJBQW1CLEtBQUssWUFBWSxPQUFPLENBQUMsV0FBVyxLQUFLLGFBQWEsTUFBTSxLQUFLLGdCQUFnQixNQUFNLENBQUM7QUFDakgsYUFBSyxXQUFXLEtBQUssWUFBWSxlQUFlLGtCQUFrQixLQUFLLGVBQWUsU0FBUyxPQUFPLEtBQUssZUFBZSxTQUFTLFVBQVUsVUFBVSxHQUFHO0FBRTFKLG1CQUFXLE1BQU0sS0FBSyxtQkFBbUIsS0FBSyxLQUFLLFNBQVMsTUFBTSxDQUFDO01BQ3ZFO01BVVEsMkJBQTJCLENBQUMsYUFBdUIsUUFBb0IsaUJBQTBCO0FBRXJHLFlBQUksQ0FBQyxZQUFZLFFBQVE7QUFDckIsaUJBQU87O0FBR1gsY0FBTSxxQkFBcUIsQ0FBQyxlQUF1QixZQUFZLEtBQUssS0FBSyxRQUFRLFVBQVUsQ0FBQztBQUM1RixlQUFPLEtBQUssa0JBQWtCLFFBQVEsWUFBWSxFQUFFLEtBQUssa0JBQWtCO01BQy9FO01BUVEsb0JBQW9CLENBQUMsUUFBb0IsV0FBb0I7QUFDakUsZUFBTyxRQUFRLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyx5QkFBeUIsUUFBUSxLQUFLLENBQUMsQ0FBQyxFQUFFLE9BQU8sT0FBTztNQUN0RztNQVVRLDJCQUEyQixDQUFDLFFBQW9CLFVBQXdCO0FBQzVFLGNBQU0sWUFBWTtBQUNsQixjQUFNLENBQUMsTUFBTSxHQUFHLElBQUksSUFBSSxNQUFNLE1BQU0sU0FBUztBQUM3QyxZQUFJLEtBQUssU0FBUyxHQUFHO0FBQ2pCLGdCQUFNLFdBQVcsSUFBSSxRQUFRLElBQUk7QUFDakMsY0FBSSxNQUFNLFFBQVEsUUFBUSxHQUFHO0FBQ3pCLG1CQUFPLFFBQVEsU0FBUyxJQUFJLENBQUMsY0FBYyxLQUFLLHlCQUF5QixXQUFXLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDOztBQUU5RyxpQkFBTyxLQUFLLHlCQUF5QixVQUFVLEtBQUssS0FBSyxTQUFTLENBQUM7O0FBRXZFLGVBQU8sQ0FBQyxJQUFJLFFBQVEsTUFBTSxLQUFLLENBQUM7TUFDcEM7TUFVUSxVQUFVLENBQUMsU0FBaUIsQ0FBQyxTQUFnQjtBQUNqRCxjQUFNLFdBQVcsS0FBSyxZQUFXLEVBQUcsTUFBTSxHQUFHO0FBQzdDLGVBQ0ksUUFDQSxRQUNBLFNBQVMsTUFBTSxDQUFDLFlBQVc7QUFDdkIsZ0JBQU0sUUFBUSxRQUNULFFBQVEsdUJBQXVCLE1BQU0sRUFDckMsUUFBUSxPQUFPLElBQUksRUFDbkIsUUFBUSxPQUFPLEdBQUc7QUFDdkIsaUJBQU8sSUFBSSxPQUFPLEtBQUssRUFBRSxLQUFLLEtBQUssWUFBVyxDQUFFO1FBQ3BELENBQUM7TUFFVDtNQVFBLFdBQVcsQ0FBQyxVQUF1RDtBQUMvRCxlQUFPLEtBQUssZ0JBQ1IsTUFBTSxLQUNGLGFBQWEsR0FBRyxHQUNoQixxQkFBb0IsR0FDcEIsSUFBSSxNQUFLO0FBQ0wsZUFBSyxzQkFBc0I7UUFDL0IsQ0FBQyxHQUNELElBQUksQ0FBQyxTQUFRO0FBQ1QsZ0JBQU0sY0FBYyxLQUFLLE1BQU0sR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLEtBQUssS0FBSSxDQUFFO0FBRTdELGlCQUFPLEVBQUUsTUFBTSxhQUFhLFlBQVksV0FBVyxLQUFLLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQSxJQUFLLFlBQVc7UUFDOUYsQ0FBQyxHQUVELElBQUksQ0FBQyxFQUFFLFlBQVcsTUFBTTtBQUNwQixlQUFLLGVBQWUsYUFBYTtBQUNqQyxlQUFLLGVBQWM7UUFDdkIsQ0FBQyxHQUVELElBQUksQ0FBQyxFQUFFLE1BQU0sWUFBVyxNQUFNO0FBRTFCLGdCQUFNLGlCQUFpQixZQUFZLEtBQUk7QUFFdkMsY0FBSSxDQUFDLGtCQUFrQixlQUFlLFNBQVMsS0FBSyxzQkFBc0I7QUFDdEUsaUJBQUssc0JBQXNCO0FBQzNCLG1CQUFPLEVBQUUsTUFBTSxVQUFVLENBQUEsRUFBRTs7QUFFL0IsaUJBQU87WUFDSDtZQUNBLFVBQVUsS0FBSyxTQUFTLE9BQU8sQ0FBQyxXQUFVO0FBQ3RDLG9CQUFNLGNBQWMsS0FBSyxrQkFBa0IsUUFBUSxLQUFLLFlBQVk7QUFDcEUscUJBQU8sWUFBWSxLQUFLLENBQUMsZUFBZSxLQUFLLFFBQVEsVUFBVSxFQUFFLGNBQWMsQ0FBQztZQUNwRixDQUFDOztRQUVULENBQUMsQ0FBQyxDQUNMO01BRVQ7TUFNQSxvQkFBaUI7QUFDYixhQUFLLHNCQUFzQjtNQUMvQjtNQUtBLElBQUksbUJBQWdCO0FBQ2hCLGVBQU8sSUFBSSxLQUFLLGNBQWMsc0NBQXNDLENBQUEsQ0FBRTtNQUMxRTtNQVFBLHVCQUF1QixDQUFDLFdBQXNCO0FBQzFDLGFBQUssZUFBZSxXQUFXLEtBQUssZUFBZSxXQUFXLFNBQVMsQ0FBQyxJQUFJLEtBQUsscUJBQXFCLE1BQU07QUFDNUcsYUFBSyw0QkFBNEIsUUFBUSxLQUFLLDZCQUE2QjtNQUMvRTtNQUtBLGdDQUFnQyxNQUFLO0FBQ2pDLGFBQUssZUFBYztNQUN2QjtNQUtBLHVCQUF1QixNQUFLO0FBQ3hCLGVBQU8sS0FBSyxlQUFlLFdBQVcsS0FBSyxJQUFJO01BQ25EO01BUUEsT0FBTyxPQUFhO0FBQ2hCLGNBQU0sWUFBWSxLQUFLLGVBQWUsWUFBWSxLQUFLLGVBQWUsU0FBUyxVQUFVO0FBQ3pGLGNBQU0sUUFBUSxZQUFZLEtBQUssV0FBVyxLQUFLLGVBQWUsU0FBUyxLQUFLLElBQUksVUFBVTtBQUMxRixhQUFLLGVBQWUsV0FBVyxFQUFFLE9BQU8sTUFBSztBQUM3QyxhQUFLLGVBQWM7TUFDdkI7TUFPUSxhQUFhLENBQUMsVUFBb0I7QUFDdEMsZUFBTyxVQUFVLFVBQVUsTUFBTSxVQUFVLE9BQU8sVUFBVTtNQUNoRTtNQVFBLHFCQUFxQixPQUFhO0FBQzlCLFlBQUksS0FBSyxlQUFlLFNBQVMsVUFBVSxPQUFPO0FBQzlDLGlCQUFPLFNBQVM7O0FBRXBCLGVBQU8sY0FBYyxLQUFLLGVBQWUsU0FBUyxLQUFLO01BQzNEOzt5QkFsYVMscUJBQWtCLCtCQUFBLFdBQUEsR0FBQSwrQkFBQSxzQkFBQSxDQUFBO01BQUE7Z0VBQWxCLHFCQUFrQixXQUFBLENBQUEsQ0FBQSxnQkFBQSxDQUFBLEdBQUEsZ0JBQUEsU0FBQSxrQ0FBQSxJQUFBLEtBQUEsVUFBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO2dEQUliLGFBQVcsR0FBVSxXQUFXOzs7Ozs7Ozs7Ozs7Ozs7O0FDckRsRCxVQUFBLDRCQUFBLEdBQUEsS0FBQTtBQUNJLFVBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx3QkFBQSxHQUFBLDJDQUFBLEdBQUEsQ0FBQSxFQStDQyxHQUFBLDJDQUFBLElBQUEsQ0FBQSxFQUFBLEdBQUEsMkNBQUEsR0FBQSxDQUFBO0FBYUwsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsR0FBQSxJQUFBOzs7QUE3REksVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSwyQkFBQSxHQUFBLElBQUEsd0JBQUEsSUFBQSxrQkFBQSxJQUFBLEVBQUE7QUFnREEsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSwyQkFBQSxHQUFBLElBQUEsWUFBQSxDQUFBLElBQUEsY0FBQSxJQUFBLENBQUE7Ozs7O29GREFTLG9CQUFrQixFQUFBLFdBQUEscUJBQUEsQ0FBQTtJQUFBLEdBQUE7QUFxYS9CLElBQU0saUJBQWlCLENBQUMsV0FBdUIsT0FBTyxHQUFJLFNBQVE7QUFTbEUsSUFBTSx5QkFBeUIsQ0FBQyxZQUEyRjtBQUN2SCxhQUFPLFFBQVEsS0FDWCxJQUFJLENBQUMsRUFBRSxTQUFRLE1BQU07QUFDakIsZUFBTztNQUNYLENBQUMsQ0FBQztJQUVWO0FBVUEsSUFBTSxxQ0FBcUMsQ0FBQyxRQUFvQixhQUFnRDtBQUM1RyxlQUFTLE1BQU07SUFDbkI7Ozs7O0FFamZBLFNBQVMsZ0JBQWdCO0FBRXpCLFNBQVMsMEJBQTBCOztBQUZuQyxJQVVhO0FBVmI7O0FBQ0E7QUFFQTtBQU9NLElBQU8seUJBQVAsTUFBTyx3QkFBc0I7O3lCQUF0Qix5QkFBc0I7TUFBQTtnRUFBdEIsd0JBQXNCLENBQUE7b0VBSnJCLHFCQUFxQixrQkFBa0IsRUFBQSxDQUFBOzs7OyIsIm5hbWVzIjpbIlNvcnRPcmRlciJdfQ==