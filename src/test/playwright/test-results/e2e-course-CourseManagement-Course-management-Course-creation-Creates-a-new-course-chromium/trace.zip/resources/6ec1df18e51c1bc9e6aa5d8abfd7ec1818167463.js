import {
  ComplaintService,
  init_complaint_service
} from "/chunk-G2ISVTQO.js";
import {
  SubmissionResultStatusModule,
  init_submission_result_status_module
} from "/chunk-KZDJAYFO.js";
import {
  ArtemisSharedComponentModule,
  DifficultyBadgeComponent,
  ExerciseCategoriesComponent,
  IncludedInScoreBadgeComponent,
  SubmissionResultStatusComponent,
  init_difficulty_badge_component,
  init_exam_model,
  init_exercise_categories_component,
  init_included_in_score_badge_component,
  init_shared_component_module,
  init_submission_result_status_component
} from "/chunk-ORYTP7RT.js";
import {
  SortService,
  init_sort_service
} from "/chunk-H46RESQY.js";
import {
  ArtemisDatePipe,
  ArtemisSharedModule,
  ArtemisTimeAgoPipe,
  ArtemisTranslatePipe,
  AssessmentType,
  ButtonType,
  ExerciseType,
  IncludedInOverallScore,
  __esm,
  getCourseFromExercise,
  getExerciseDueDate,
  getIcon,
  getIconTooltip,
  hasExerciseDueDatePassed,
  init_artemis_date_pipe,
  init_artemis_time_ago_pipe,
  init_artemis_translate_pipe,
  init_assessment_type_model,
  init_button_component,
  init_course_model,
  init_exercise_model,
  init_exercise_utils,
  init_shared_module,
  init_student_participation_model,
  init_utils,
  roundValueSpecifiedByCourseSettings
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/exercise-categories/exercise-categories.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { RouterModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ExerciseCategoriesModule;
var init_exercise_categories_module = __esm({
  "src/main/webapp/app/shared/exercise-categories/exercise-categories.module.ts"() {
    init_shared_module();
    init_shared_component_module();
    init_exercise_categories_component();
    ExerciseCategoriesModule = class _ExerciseCategoriesModule {
      static \u0275fac = function ExerciseCategoriesModule_Factory(t) {
        return new (t || _ExerciseCategoriesModule)();
      };
      static \u0275mod = i0.\u0275\u0275defineNgModule({ type: _ExerciseCategoriesModule });
      static \u0275inj = i0.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, RouterModule, ArtemisSharedComponentModule] });
    };
  }
});

// src/main/webapp/app/entities/submission-policy.model.ts
var SubmissionPolicyType, SubmissionPolicy, LockRepositoryPolicy, SubmissionPenaltyPolicy;
var init_submission_policy_model = __esm({
  "src/main/webapp/app/entities/submission-policy.model.ts"() {
    (function(SubmissionPolicyType2) {
      SubmissionPolicyType2["NONE"] = "none";
      SubmissionPolicyType2["LOCK_REPOSITORY"] = "lock_repository";
      SubmissionPolicyType2["SUBMISSION_PENALTY"] = "submission_penalty";
    })(SubmissionPolicyType || (SubmissionPolicyType = {}));
    SubmissionPolicy = class {
      id;
      programmingExercise;
      active;
      submissionLimit;
      exceedingPenalty;
      type;
      constructor(type) {
        this.type = type;
      }
    };
    LockRepositoryPolicy = class extends SubmissionPolicy {
      constructor() {
        super(SubmissionPolicyType.LOCK_REPOSITORY);
        this.exceedingPenalty = void 0;
      }
    };
    SubmissionPenaltyPolicy = class extends SubmissionPolicy {
      constructor() {
        super(SubmissionPolicyType.SUBMISSION_PENALTY);
      }
    };
  }
});

// src/main/webapp/app/exercises/shared/exercise-headers/header-exercise-page-with-details.component.ts
import { Component, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import { faQuestionCircle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275element(1, "fa-icon", 5);
    i02.\u0275\u0275pipe(2, "artemisTranslate");
    i02.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r1 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("icon", ctx_r1.getIcon(ctx_r1.exercise.type))("ngbTooltip", i02.\u0275\u0275pipeBind1(2, 2, ctx_r1.getIconTooltip(ctx_r1.exercise.type)));
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275element(1, "jhi-exercise-categories", 6);
    i02.\u0275\u0275text(2, "\n                ");
  }
  if (rf & 2) {
    const ctx_r2 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("exercise", ctx_r2.exercise)("showTags", i02.\u0275\u0275pureFunction0(3, _c0))("ngClass", "badge-row");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_15_Conditional_3_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0);
    i02.\u0275\u0275pipe(1, "artemisTranslate");
  }
  if (rf & 2) {
    const ctx_r13 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275textInterpolate1("\n                                    ", ctx_r13.achievedPoints + i02.\u0275\u0275pipeBind1(1, 1, "artemisApp.courseOverview.exerciseDetails.of"), "\n                                ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_15_Conditional_3_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                    ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r14 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate2("(", i02.\u0275\u0275pipeBind1(3, 2, "artemisApp.courseOverview.exerciseDetails.bonus"), " ", ctx_r14.exercise.bonusPoints, ")");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_15_Conditional_3_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275element(1, "jhi-included-in-score-badge", 9);
    i02.\u0275\u0275text(2, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r15 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("includedInOverallScore", ctx_r15.exercise.includedInOverallScore);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_15_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "span", 8);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275template(6, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_15_Conditional_3_Conditional_6_Template, 2, 3);
    i02.\u0275\u0275text(7);
    i02.\u0275\u0275template(8, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_15_Conditional_3_Conditional_8_Template, 5, 4);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n                            ");
    i02.\u0275\u0275template(10, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_15_Conditional_3_Conditional_10_Template, 3, 1);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r11 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275styleProp("margin-right", ctx_r11.exercise.maxPoints ? "30px" : null);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate1("\n                                ", i02.\u0275\u0275pipeBind1(5, 7, "artemisApp.courseOverview.exerciseDetails.points"), "\n                                ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(6, ctx_r11.achievedPoints !== void 0 ? 6 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275textInterpolate1("\n                                ", ctx_r11.exercise.maxPoints, "\n                                ");
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(8, ctx_r11.exercise.bonusPoints ? 8 : -1);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(10, ctx_r11.exercise.includedInOverallScore !== ctx_r11.IncludedInOverallScore.INCLUDED_COMPLETELY ? 10 : -1);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_15_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span");
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "div");
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275pipe(6, "artemisTranslate");
    i02.\u0275\u0275element(7, "fa-icon", 5);
    i02.\u0275\u0275pipe(8, "artemisTranslate");
    i02.\u0275\u0275text(9, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r12 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate2("\n                                ", i02.\u0275\u0275pipeBind1(5, 4, "artemisApp.courseOverview.exerciseDetails.assessmentType"), "\n                                ", i02.\u0275\u0275pipeBind1(6, 6, "artemisApp.AssessmentType.forExerciseHeader." + ctx_r12.exercise.assessmentType), "\n                                ");
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275propertyInterpolate("ngbTooltip", i02.\u0275\u0275pipeBind1(8, 8, "artemisApp.AssessmentType.tooltip." + ctx_r12.exercise.assessmentType));
    i02.\u0275\u0275property("icon", ctx_r12.faQuestionCircle);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275elementStart(1, "div", 7);
    i02.\u0275\u0275text(2, "\n                    ");
    i02.\u0275\u0275template(3, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_15_Conditional_3_Template, 12, 9)(4, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_15_Conditional_4_Template, 12, 10);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r3 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, ctx_r3.exercise.maxPoints ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(4, ctx_r3.exercise.assessmentType && ctx_r3.exercise.type === ctx_r3.ExerciseType.PROGRAMMING ? 4 : -1);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275elementStart(1, "div", 10);
    i02.\u0275\u0275text(2, "\n                    ");
    i02.\u0275\u0275elementStart(3, "div");
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                    ");
    i02.\u0275\u0275elementStart(7, "div");
    i02.\u0275\u0275text(8);
    i02.\u0275\u0275pipe(9, "artemisTranslate");
    i02.\u0275\u0275element(10, "fa-icon", 5);
    i02.\u0275\u0275pipe(11, "artemisTranslate");
    i02.\u0275\u0275text(12, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(13, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(14, "\n            ");
  }
  if (rf & 2) {
    const ctx_r4 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate1("", i02.\u0275\u0275pipeBind1(5, 4, "artemisApp.programmingExercise.submissionPolicy.submissionLimitTitle"), ":");
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate1("\n                        ", ctx_r4.numberOfSubmissions + "/" + ctx_r4.submissionPolicy.submissionLimit + (ctx_r4.submissionPolicy.exceedingPenalty ? i02.\u0275\u0275pipeBind2(9, 6, "artemisApp.programmingExercise.submissionPolicy.submissionPenalty.penaltyInfoLabel", i02.\u0275\u0275pureFunction1(11, _c1, ctx_r4.submissionPolicy.exceedingPenalty)) : ""), "\n                        ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275propertyInterpolate("ngbTooltip", i02.\u0275\u0275pipeBind1(11, 9, "artemisApp.programmingExercise.submissionPolicy.submissionPolicyType." + ctx_r4.submissionPolicy.type + ".tooltip"));
    i02.\u0275\u0275property("icon", ctx_r4.faQuestionCircle);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n            ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "div", 11);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementStart(4, "span", 12);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275pipe(6, "artemisDate");
    i02.\u0275\u0275text(7);
    i02.\u0275\u0275pipe(8, "artemisTimeAgo");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n                ");
  }
  if (rf & 2) {
    const ctx_r16 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                        ", i02.\u0275\u0275pipeBind1(3, 4, "artemisApp.courseOverview.exerciseDetails." + ctx_r16.nextRelevantDateLabel), "\n                        ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("ngClass", ctx_r16.nextRelevantDateStatusBadge)("ngbTooltip", i02.\u0275\u0275pipeBind2(5, 6, "artemisApp.courseOverview.exerciseDetails." + ctx_r16.nextRelevantDateLabel + "Tooltip", i02.\u0275\u0275pureFunction1(13, _c2, i02.\u0275\u0275pipeBind1(6, 9, ctx_r16.nextRelevantDate))));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate1("\n                            ", i02.\u0275\u0275pipeBind1(8, 11, ctx_r16.nextRelevantDate), "\n                        ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Conditional_3_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "span", 13);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                    ", i02.\u0275\u0275pipeBind1(3, 1, "global.generic.yes"), "\n                                ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Conditional_3_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "span", 14);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                    ", i02.\u0275\u0275pipeBind1(3, 1, "global.generic.no"), "\n                                ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0);
    i02.\u0275\u0275pipe(1, "artemisTranslate");
    i02.\u0275\u0275template(2, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Conditional_3_Conditional_2_Template, 5, 3)(3, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Conditional_3_Conditional_3_Template, 5, 3);
  }
  if (rf & 2) {
    const ctx_r18 = i02.\u0275\u0275nextContext(4);
    let tmp_1_0;
    let tmp_2_0;
    i02.\u0275\u0275textInterpolate1("\n                            ", i02.\u0275\u0275pipeBind1(1, 3, "artemisApp.courseOverview.exerciseDetails.presented"), "\n                            ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(2, ((tmp_1_0 = ctx_r18.studentParticipation == null ? null : ctx_r18.studentParticipation.presentationScore) !== null && tmp_1_0 !== void 0 ? tmp_1_0 : 0) > 0 ? 2 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(3, ((tmp_2_0 = ctx_r18.studentParticipation == null ? null : ctx_r18.studentParticipation.presentationScore) !== null && tmp_2_0 !== void 0 ? tmp_2_0 : 0) <= 0 ? 3 : -1);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Conditional_4_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "span", 13);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r22 = i02.\u0275\u0275nextContext(5);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                    ", ctx_r22.studentParticipation.presentationScore + "%", "\n                                ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Conditional_4_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "span", 14);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                    ", i02.\u0275\u0275pipeBind1(3, 1, "global.generic.unset"), "\n                                ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0);
    i02.\u0275\u0275pipe(1, "artemisTranslate");
    i02.\u0275\u0275template(2, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Conditional_4_Conditional_2_Template, 4, 1)(3, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Conditional_4_Conditional_3_Template, 5, 3);
  }
  if (rf & 2) {
    const ctx_r19 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275textInterpolate1("\n                            ", i02.\u0275\u0275pipeBind1(1, 3, "artemisApp.courseOverview.exerciseDetails.presentation"), "\n                            ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(2, (ctx_r19.studentParticipation == null ? null : ctx_r19.studentParticipation.presentationScore) ? 2 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(3, !(ctx_r19.studentParticipation == null ? null : ctx_r19.studentParticipation.presentationScore) ? 3 : -1);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                        ");
    i02.\u0275\u0275template(3, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Conditional_3_Template, 4, 5)(4, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Conditional_4_Template, 4, 5);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r17 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, (ctx_r17.course == null ? null : ctx_r17.course.presentationScore) ? 3 : 4);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275template(1, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_1_Template, 11, 15)(2, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Conditional_2_Template, 6, 1);
  }
  if (rf & 2) {
    const ctx_r6 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(1, ctx_r6.nextRelevantDate && (!ctx_r6.exam || !ctx_r6.isTestRun) ? 1 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(2, ctx_r6.exercise.presentationScoreEnabled ? 2 : -1);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275elementStart(1, "div", 11);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementStart(4, "span", 12);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275pipe(6, "artemisDate");
    i02.\u0275\u0275text(7);
    i02.\u0275\u0275pipe(8, "artemisTimeAgo");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n            ");
  }
  if (rf & 2) {
    const ctx_r7 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                    ", i02.\u0275\u0275pipeBind1(3, 4, "artemisApp.courseOverview.exerciseDetails.submissionDue"), "\n                    ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("ngClass", ctx_r7.dueDateStatusBadge)("ngbTooltip", i02.\u0275\u0275pipeBind2(5, 6, "artemisApp.courseOverview.exerciseDetails.submissionDueTooltip", i02.\u0275\u0275pureFunction1(13, _c2, i02.\u0275\u0275pipeBind1(6, 9, ctx_r7.dueDate))));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate1("\n                        ", i02.\u0275\u0275pipeBind1(8, 11, ctx_r7.dueDate), "\n                    ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n            ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "div", 11);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementStart(4, "span", 12);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275pipe(6, "artemisDate");
    i02.\u0275\u0275text(7);
    i02.\u0275\u0275pipe(8, "artemisTimeAgo");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(10, "\n                ");
  }
  if (rf & 2) {
    const ctx_r24 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                        ", i02.\u0275\u0275pipeBind1(3, 4, "artemisApp.courseOverview.exerciseDetails." + ctx_r24.nextRelevantDateLabel), "\n                        ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("ngClass", ctx_r24.nextRelevantDateStatusBadge)("ngbTooltip", i02.\u0275\u0275pipeBind2(5, 6, "artemisApp.courseOverview.exerciseDetails." + ctx_r24.nextRelevantDateLabel + "Tooltip", i02.\u0275\u0275pureFunction1(13, _c2, i02.\u0275\u0275pipeBind1(6, 9, ctx_r24.nextRelevantDate))));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate1("\n                            ", i02.\u0275\u0275pipeBind1(8, 11, ctx_r24.nextRelevantDate), "\n                        ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Conditional_3_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "span", 13);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                    ", i02.\u0275\u0275pipeBind1(3, 1, "global.generic.yes"), "\n                                ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Conditional_3_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "span", 14);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                    ", i02.\u0275\u0275pipeBind1(3, 1, "global.generic.no"), "\n                                ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0);
    i02.\u0275\u0275pipe(1, "artemisTranslate");
    i02.\u0275\u0275template(2, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Conditional_3_Conditional_2_Template, 5, 3)(3, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Conditional_3_Conditional_3_Template, 5, 3);
  }
  if (rf & 2) {
    const ctx_r26 = i02.\u0275\u0275nextContext(4);
    let tmp_1_0;
    let tmp_2_0;
    i02.\u0275\u0275textInterpolate1("\n                            ", i02.\u0275\u0275pipeBind1(1, 3, "artemisApp.courseOverview.exerciseDetails.presented"), "\n                            ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(2, ((tmp_1_0 = ctx_r26.studentParticipation == null ? null : ctx_r26.studentParticipation.presentationScore) !== null && tmp_1_0 !== void 0 ? tmp_1_0 : 0) > 0 ? 2 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(3, ((tmp_2_0 = ctx_r26.studentParticipation == null ? null : ctx_r26.studentParticipation.presentationScore) !== null && tmp_2_0 !== void 0 ? tmp_2_0 : 0) <= 0 ? 3 : -1);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Conditional_4_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "span", 13);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                            ");
  }
  if (rf & 2) {
    const ctx_r30 = i02.\u0275\u0275nextContext(5);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                    ", ctx_r30.studentParticipation.presentationScore + "%", "\n                                ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Conditional_4_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "span", 14);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                    ", i02.\u0275\u0275pipeBind1(3, 1, "global.generic.unset"), "\n                                ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0);
    i02.\u0275\u0275pipe(1, "artemisTranslate");
    i02.\u0275\u0275template(2, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Conditional_4_Conditional_2_Template, 4, 1)(3, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Conditional_4_Conditional_3_Template, 5, 3);
  }
  if (rf & 2) {
    const ctx_r27 = i02.\u0275\u0275nextContext(4);
    i02.\u0275\u0275textInterpolate1("\n                            ", i02.\u0275\u0275pipeBind1(1, 3, "artemisApp.courseOverview.exerciseDetails.presentation"), "\n                            ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(2, (ctx_r27.studentParticipation == null ? null : ctx_r27.studentParticipation.presentationScore) ? 2 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(3, !(ctx_r27.studentParticipation == null ? null : ctx_r27.studentParticipation.presentationScore) ? 3 : -1);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                        ");
    i02.\u0275\u0275template(3, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Conditional_3_Template, 4, 5)(4, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Conditional_4_Template, 4, 5);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r25 = i02.\u0275\u0275nextContext(3);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, (ctx_r25.course == null ? null : ctx_r25.course.presentationScore) ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(4, !(ctx_r25.course == null ? null : ctx_r25.course.presentationScore) ? 4 : -1);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275template(1, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_1_Template, 11, 15)(2, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Conditional_2_Template, 6, 2);
  }
  if (rf & 2) {
    const ctx_r9 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(1, ctx_r9.nextRelevantDate && (!ctx_r9.exam || !ctx_r9.isTestRun) ? 1 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(2, ctx_r9.exercise.presentationScoreEnabled ? 2 : -1);
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275elementStart(1, "div", 11);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementStart(4, "span", 15);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275text(6);
    i02.\u0275\u0275pipe(7, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n            ");
  }
  if (rf & 2) {
    const ctx_r10 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                    ", i02.\u0275\u0275pipeBind1(3, 3, "artemisApp.courseOverview.exerciseDetails.complaintPossible"), "\n                    ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("ngbTooltip", i02.\u0275\u0275pipeBind2(5, 5, "artemisApp.courseOverview.exerciseDetails.complaintPossibleTooltip", i02.\u0275\u0275pureFunction1(10, _c3, ctx_r10.course == null ? null : ctx_r10.course.maxComplaintTimeDays)));
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                        ", i02.\u0275\u0275pipeBind1(7, 8, "global.generic.yes"), "\n                    ");
  }
}
function HeaderExercisePageWithDetailsComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n    ");
    i02.\u0275\u0275elementStart(1, "div", 0);
    i02.\u0275\u0275text(2, "\n        ");
    i02.\u0275\u0275elementStart(3, "div", 1);
    i02.\u0275\u0275text(4, "\n            ");
    i02.\u0275\u0275elementStart(5, "div", 2);
    i02.\u0275\u0275text(6, "\n                ");
    i02.\u0275\u0275elementStart(7, "div", 3);
    i02.\u0275\u0275text(8, "\n                    ");
    i02.\u0275\u0275template(9, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_9_Template, 4, 4);
    i02.\u0275\u0275projection(10);
    i02.\u0275\u0275text(11, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(12, "\n                ");
    i02.\u0275\u0275template(13, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_13_Template, 3, 4);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(14, "\n            ");
    i02.\u0275\u0275template(15, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_15_Template, 6, 2)(16, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_16_Template, 15, 13);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(17, "\n        ");
    i02.\u0275\u0275elementStart(18, "div", 4);
    i02.\u0275\u0275text(19, "\n            ");
    i02.\u0275\u0275template(20, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_20_Template, 1, 0)(21, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_21_Template, 3, 2)(22, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_22_Template, 11, 15)(23, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_23_Template, 1, 0)(24, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_24_Template, 3, 2)(25, HeaderExercisePageWithDetailsComponent_Conditional_0_Conditional_25_Template, 10, 12);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(26, "\n    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(27, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(9);
    i02.\u0275\u0275conditional(9, ctx_r0.exercise.type ? 9 : -1);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275conditional(13, ctx_r0.exercise.releaseDate && ctx_r0.dayjs(ctx_r0.exercise.releaseDate).isAfter(ctx_r0.dayjs()) || ctx_r0.exercise.difficulty || (ctx_r0.exerciseCategories == null ? null : ctx_r0.exerciseCategories.length) ? 13 : -1);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(15, ctx_r0.exercise.maxPoints || ctx_r0.exercise.assessmentType && ctx_r0.exercise.type === ctx_r0.ExerciseType.PROGRAMMING ? 15 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(16, ctx_r0.submissionPolicy && ctx_r0.submissionPolicy.active ? 16 : -1);
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275conditional(20, !ctx_r0.nextRelevantDateLabel || ctx_r0.nextRelevantDateLabel !== "releaseDate" && ctx_r0.nextRelevantDateLabel !== "startDate" ? 20 : 21);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(22, ctx_r0.dueDate ? 22 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(23, !ctx_r0.nextRelevantDateLabel || ctx_r0.nextRelevantDateLabel !== "assessmentDue" && ctx_r0.nextRelevantDateLabel !== "complaintDue" ? 23 : 24);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275conditional(25, !ctx_r0.nextRelevantDate && ctx_r0.canComplainLaterOn ? 25 : -1);
  }
}
var _c0, _c1, _c2, _c3, _c4, _c5, HeaderExercisePageWithDetailsComponent;
var init_header_exercise_page_with_details_component = __esm({
  "src/main/webapp/app/exercises/shared/exercise-headers/header-exercise-page-with-details.component.ts"() {
    init_sort_service();
    init_exercise_model();
    init_exam_model();
    init_submission_policy_model();
    init_student_participation_model();
    init_exercise_utils();
    init_course_model();
    init_assessment_type_model();
    init_complaint_service();
    init_utils();
    init_sort_service();
    init_included_in_score_badge_component();
    init_exercise_categories_component();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    init_artemis_time_ago_pipe();
    _c0 = () => ({ difficulty: true, notReleased: true });
    _c1 = (a0) => ({ points: a0 });
    _c2 = (a0) => ({ date: a0 });
    _c3 = (a0) => ({ days: a0 });
    _c4 = [[["", "pagetitle", ""]]];
    _c5 = ["[pagetitle]"];
    HeaderExercisePageWithDetailsComponent = class _HeaderExercisePageWithDetailsComponent {
      sortService;
      IncludedInOverallScore = IncludedInOverallScore;
      AssessmentType = AssessmentType;
      ExerciseType = ExerciseType;
      getIcon = getIcon;
      getIconTooltip = getIconTooltip;
      dayjs = dayjs;
      exercise;
      studentParticipation;
      title;
      exam;
      course;
      isTestRun = false;
      submissionPolicy;
      exerciseCategories;
      dueDate;
      isBeforeStartDate;
      programmingExercise;
      individualComplaintDueDate;
      nextRelevantDate;
      nextRelevantDateLabel;
      nextRelevantDateStatusBadge;
      dueDateStatusBadge;
      canComplainLaterOn;
      achievedPoints;
      numberOfSubmissions;
      icon;
      faQuestionCircle = faQuestionCircle;
      constructor(sortService) {
        this.sortService = sortService;
      }
      ngOnInit() {
        this.exerciseCategories = this.exercise.categories || [];
        if (this.exercise.type) {
          this.icon = getIcon(this.exercise.type);
        }
        this.programmingExercise = this.exercise.type === ExerciseType.PROGRAMMING ? this.exercise : void 0;
        if (this.exam) {
          this.determineNextRelevantDateExamMode();
        } else {
          this.dueDate = getExerciseDueDate(this.exercise, this.studentParticipation);
          this.isBeforeStartDate = this.exercise.startDate ? this.exercise.startDate.isAfter(dayjs()) : !!this.exercise.releaseDate?.isAfter(dayjs());
          if (this.course?.maxComplaintTimeDays) {
            this.individualComplaintDueDate = ComplaintService.getIndividualComplaintDueDate(this.exercise, this.course.maxComplaintTimeDays, this.studentParticipation?.results?.last(), this.studentParticipation);
          }
          this.canComplainLaterOn = !!this.studentParticipation?.submissionCount && !this.individualComplaintDueDate && (this.exercise.allowComplaintsForAutomaticAssessments || this.exercise.assessmentType !== AssessmentType.AUTOMATIC);
          this.determineNextRelevantDateCourseMode();
        }
        if (this.dueDate) {
          this.dueDateStatusBadge = dayjs().isBefore(this.dueDate) ? "bg-success" : "bg-danger";
        }
      }
      ngOnChanges() {
        this.course = this.course ?? getCourseFromExercise(this.exercise);
        if (this.submissionPolicy?.active) {
          this.countSubmissions();
        }
        if (this.studentParticipation?.results?.length) {
          this.sortService.sortByProperty(this.studentParticipation.results, "id", false);
          const latestRatedResult = this.studentParticipation.results.filter((result) => result.rated).first();
          if (latestRatedResult) {
            this.achievedPoints = roundValueSpecifiedByCourseSettings(latestRatedResult.score * this.exercise.maxPoints / 100, this.course);
          }
        }
      }
      determineNextRelevantDateExamMode() {
        const possibleDates = [this.exam?.endDate, this.exam?.publishResultsDate];
        const possibleDatesLabels = ["endDate", "publishResultsDate"];
        this.determineNextDate(possibleDates, possibleDatesLabels, dayjs());
      }
      determineNextRelevantDateCourseMode() {
        const possibleDates = [this.exercise.releaseDate, this.exercise.startDate, this.exercise.assessmentDueDate, this.individualComplaintDueDate];
        const possibleDatesLabels = ["releaseDate", "startDate", "assessmentDue", "complaintDue"];
        this.determineNextDate(possibleDates, possibleDatesLabels, dayjs());
      }
      determineNextDate(dates, dateLabels, now) {
        this.nextRelevantDate = void 0;
        this.nextRelevantDateLabel = void 0;
        this.nextRelevantDateStatusBadge = void 0;
        for (let i = 0; i < dates.length; i++) {
          if (dates[i] && now.isBefore(dates[i])) {
            this.nextRelevantDate = dates[i];
            this.nextRelevantDateLabel = dateLabels[i];
            this.nextRelevantDateStatusBadge = "bg-success";
            return;
          }
        }
        if (this.canComplainLaterOn) {
          return;
        }
        for (let i = dates.length - 1; i >= 0; i--) {
          if (dates[i]) {
            if (this.dueDate && this.dueDate.isAfter(dates[i])) {
              return;
            }
            this.nextRelevantDate = dates[i];
            this.nextRelevantDateLabel = dateLabels[i];
            this.nextRelevantDateStatusBadge = "bg-danger";
            return;
          }
        }
      }
      countSubmissions() {
        const commitHashSet = /* @__PURE__ */ new Set();
        this.studentParticipation?.results?.map((result) => result.submission).filter((submission) => submission?.type === "MANUAL").map((submission) => submission.commitHash).forEach((commitHash) => commitHashSet.add(commitHash));
        this.numberOfSubmissions = commitHashSet.size;
      }
      static \u0275fac = function HeaderExercisePageWithDetailsComponent_Factory(t) {
        return new (t || _HeaderExercisePageWithDetailsComponent)(i02.\u0275\u0275directiveInject(SortService));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _HeaderExercisePageWithDetailsComponent, selectors: [["jhi-header-exercise-page-with-details"]], inputs: { exercise: "exercise", studentParticipation: "studentParticipation", title: "title", exam: "exam", course: "course", isTestRun: "isTestRun", submissionPolicy: "submissionPolicy" }, features: [i02.\u0275\u0275NgOnChangesFeature], ngContentSelectors: _c5, decls: 1, vars: 1, consts: [["id", "exercise-header", 1, "course-info-bar"], [1, "left-col"], [1, "title-row"], [1, "inner-row"], [1, "right-col"], [3, "icon", "ngbTooltip"], [3, "exercise", "showTags", "ngClass"], [1, "points-assessment-row"], [1, "me-2"], [1, "me-2", 3, "includedInOverallScore"], [1, "submission-row"], [1, "fw-500"], [1, "badge", 3, "ngClass", "ngbTooltip"], [1, "badge", "bg-success"], [1, "badge", "bg-secondary"], [1, "badge", "bg-success", 3, "ngbTooltip"]], template: function HeaderExercisePageWithDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275projectionDef(_c4);
          i02.\u0275\u0275template(0, HeaderExercisePageWithDetailsComponent_Conditional_0_Template, 28, 8);
        }
        if (rf & 2) {
          i02.\u0275\u0275conditional(0, ctx.exercise ? 0 : -1);
        }
      }, dependencies: [i2.NgClass, i3.NgbTooltip, i4.FaIconComponent, IncludedInScoreBadgeComponent, ExerciseCategoriesComponent, ArtemisDatePipe, ArtemisTranslatePipe, ArtemisTimeAgoPipe], styles: ["\n\n#exercise-header[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  flex-direction: row;\n  justify-content: flex-start;\n  gap: 10px;\n  font-size: 1.3rem;\n  line-height: 1.2;\n  font-weight: 400;\n}\n#exercise-header[_ngcontent-%COMP%]   .right-col[_ngcontent-%COMP%] {\n  flex: 0 0 auto;\n}\n#exercise-header[_ngcontent-%COMP%]   .right-col[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%] {\n  display: flex;\n  width: 100%;\n  justify-content: space-between;\n  gap: 10px;\n}\n#exercise-header[_ngcontent-%COMP%]   .right-col[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:not(:last-child) {\n  margin-bottom: 5px;\n}\n#exercise-header[_ngcontent-%COMP%]   .left-col[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n  min-width: 0;\n  display: flex;\n  flex-direction: column;\n  gap: 5px;\n}\n@supports (flex-basis: min-content) {\n  #exercise-header[_ngcontent-%COMP%]   .left-col[_ngcontent-%COMP%] {\n    flex: 1 1 min-content;\n  }\n}\n#exercise-header[_ngcontent-%COMP%]   .left-col[_ngcontent-%COMP%]   .title-row[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 5px;\n  flex-wrap: wrap;\n}\n#exercise-header[_ngcontent-%COMP%]   .left-col[_ngcontent-%COMP%]   .title-row[_ngcontent-%COMP%]   .inner-row[_ngcontent-%COMP%] {\n  margin-bottom: 0;\n  margin-right: 10px;\n  font-size: 1.575rem;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  overflow: hidden;\n}\n#exercise-header[_ngcontent-%COMP%]   .left-col[_ngcontent-%COMP%]   .title-row[_ngcontent-%COMP%]     .badge-row {\n  display: flex;\n  flex-wrap: wrap;\n}\n#exercise-header[_ngcontent-%COMP%]   .left-col[_ngcontent-%COMP%]   .points-assessment-row[_ngcontent-%COMP%], #exercise-header[_ngcontent-%COMP%]   .left-col[_ngcontent-%COMP%]   .submission-row[_ngcontent-%COMP%] {\n  white-space: nowrap;\n  display: flex;\n  flex-wrap: wrap;\n  gap: 0.25em;\n  align-items: center;\n}\n#exercise-header[_ngcontent-%COMP%]   .fw-500[_ngcontent-%COMP%] {\n  font-weight: 500;\n}\n@media (max-width: 575px) {\n  #exercise-header[_ngcontent-%COMP%] {\n    font-size: 1.1rem;\n  }\n  #exercise-header[_ngcontent-%COMP%]   .left-col[_ngcontent-%COMP%]   .title-row[_ngcontent-%COMP%]   .inner-row[_ngcontent-%COMP%] {\n    font-size: 1.3em;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlLWhlYWRlcnMvaGVhZGVyLWV4ZXJjaXNlLXBhZ2Utd2l0aC1kZXRhaWxzLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIjZXhlcmNpc2UtaGVhZGVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtd3JhcDogd3JhcDtcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgIGp1c3RpZnktY29udGVudDogZmxleC1zdGFydDtcbiAgICBnYXA6IDEwcHg7XG4gICAgZm9udC1zaXplOiAxLjNyZW07XG4gICAgbGluZS1oZWlnaHQ6IDEuMjtcbiAgICBmb250LXdlaWdodDogNDAwO1xuXG4gICAgLnJpZ2h0LWNvbCB7XG4gICAgICAgIGZsZXg6IDAgMCBhdXRvO1xuXG4gICAgICAgID4gZGl2IHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgICAgIGdhcDogMTBweDtcbiAgICAgICAgfVxuXG4gICAgICAgID4gZGl2Om5vdCg6bGFzdC1jaGlsZCkge1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmxlZnQtY29sIHtcbiAgICAgICAgZmxleDogMSAxIGF1dG87XG5cbiAgICAgICAgQHN1cHBvcnRzIChmbGV4LWJhc2lzOiBtaW4tY29udGVudCkge1xuICAgICAgICAgICAgZmxleDogMSAxIG1pbi1jb250ZW50O1xuICAgICAgICB9XG5cbiAgICAgICAgbWluLXdpZHRoOiAwO1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICBnYXA6IDVweDtcblxuICAgICAgICAudGl0bGUtcm93IHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBnYXA6IDVweDtcbiAgICAgICAgICAgIGZsZXgtd3JhcDogd3JhcDtcblxuICAgICAgICAgICAgLmlubmVyLXJvdyB7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxLjU3NXJlbTtcbiAgICAgICAgICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgICAgICAgICAgICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICAgICAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIDo6bmctZGVlcCAuYmFkZ2Utcm93IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGZsZXgtd3JhcDogd3JhcDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5wb2ludHMtYXNzZXNzbWVudC1yb3csXG4gICAgICAgIC5zdWJtaXNzaW9uLXJvdyB7XG4gICAgICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGZsZXgtd3JhcDogd3JhcDtcbiAgICAgICAgICAgIGdhcDogMC4yNWVtO1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5mdy01MDAge1xuICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgIH1cblxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA1NzVweCkge1xuICAgICAgICBmb250LXNpemU6IDEuMXJlbTtcblxuICAgICAgICAubGVmdC1jb2wgLnRpdGxlLXJvdyAuaW5uZXItcm93IHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMS4zZW07XG4gICAgICAgIH1cbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxhQUFBO0FBQ0Esa0JBQUE7QUFDQSxtQkFBQTtBQUNBLE9BQUE7QUFDQSxhQUFBO0FBQ0EsZUFBQTtBQUNBLGVBQUE7O0FBRUEsQ0FWSixnQkFVSSxDQUFBO0FBQ0ksUUFBQSxFQUFBLEVBQUE7O0FBRUEsQ0FiUixnQkFhUSxDQUhKLFVBR0ksRUFBQTtBQUNJLFdBQUE7QUFDQSxTQUFBO0FBQ0EsbUJBQUE7QUFDQSxPQUFBOztBQUdKLENBcEJSLGdCQW9CUSxDQVZKLFVBVUksRUFBQSxHQUFBLEtBQUE7QUFDSSxpQkFBQTs7QUFJUixDQXpCSixnQkF5QkksQ0FBQTtBQUNJLFFBQUEsRUFBQSxFQUFBO0FBTUEsYUFBQTtBQUNBLFdBQUE7QUFDQSxrQkFBQTtBQUNBLE9BQUE7O0FBUEEsVUFBQSxDQUFBLFVBQUEsRUFBQTtBQUhKLEdBekJKLGdCQXlCSSxDQUFBO0FBSVEsVUFBQSxFQUFBLEVBQUE7OztBQVFKLENBckNSLGdCQXFDUSxDQVpKLFNBWUksQ0FBQTtBQUNJLFdBQUE7QUFDQSxPQUFBO0FBQ0EsYUFBQTs7QUFFQSxDQTFDWixnQkEwQ1ksQ0FqQlIsU0FpQlEsQ0FMSixVQUtJLENBQUE7QUFDSSxpQkFBQTtBQUNBLGdCQUFBO0FBQ0EsYUFBQTtBQUNBLGVBQUE7QUFDQSxpQkFBQTtBQUNBLFlBQUE7O0FBR0osQ0FuRFosZ0JBbURZLENBMUJSLFNBMEJRLENBZEosVUFjSSxVQUFBLENBQUE7QUFDSSxXQUFBO0FBQ0EsYUFBQTs7QUFJUixDQXpEUixnQkF5RFEsQ0FoQ0osU0FnQ0ksQ0FBQTtBQUFBLENBekRSLGdCQXlEUSxDQWhDSixTQWdDSSxDQUFBO0FBRUksZUFBQTtBQUNBLFdBQUE7QUFDQSxhQUFBO0FBQ0EsT0FBQTtBQUNBLGVBQUE7O0FBSVIsQ0FuRUosZ0JBbUVJLENBQUE7QUFDSSxlQUFBOztBQUdKLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUF2RUosR0FBQTtBQXdFUSxlQUFBOztBQUVBLEdBMUVSLGdCQTBFUSxDQWpESixTQWlESSxDQXJDQSxVQXFDQSxDQWhDSTtBQWlDQSxlQUFBOzs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(HeaderExercisePageWithDetailsComponent, { className: "HeaderExercisePageWithDetailsComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/exercise-headers/header-participation-page.component.ts
import { Component as Component2, Input as Input2, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import dayjs2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
function HeaderParticipationPageComponent_Conditional_0_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                        ");
    i03.\u0275\u0275elementStart(1, "span", 10);
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275pipe(3, "artemisTimeAgo");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(4, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r1 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("ngClass", ctx_r1.exerciseStatusBadge);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(3, 2, ctx_r1.dueDate));
  }
}
function HeaderParticipationPageComponent_Conditional_0_Conditional_22_For_8_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                            ");
    i03.\u0275\u0275elementStart(1, "h6", 3);
    i03.\u0275\u0275text(2, "\n                                ");
    i03.\u0275\u0275elementStart(3, "span", 13);
    i03.\u0275\u0275text(4);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(6, "\n                        ");
  }
  if (rf & 2) {
    const category_r7 = ctx.$implicit;
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("ngStyle", i03.\u0275\u0275pureFunction1(2, _c02, category_r7.color));
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275textInterpolate(category_r7.category);
  }
}
function HeaderParticipationPageComponent_Conditional_0_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "div", 11);
    i03.\u0275\u0275text(2, "\n                        ");
    i03.\u0275\u0275elementStart(3, "h6", 12);
    i03.\u0275\u0275text(4);
    i03.\u0275\u0275pipe(5, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(6, "\n                        ");
    i03.\u0275\u0275repeaterCreate(7, HeaderParticipationPageComponent_Conditional_0_Conditional_22_For_8_Template, 7, 4, null, null, i03.\u0275\u0275repeaterTrackByIdentity);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(9, "\n                ");
  }
  if (rf & 2) {
    const ctx_r2 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(4);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(5, 1, "artemisApp.courseOverview.exerciseDetails.categories"));
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275repeater(ctx_r2.exerciseCategories);
  }
}
function HeaderParticipationPageComponent_Conditional_0_Conditional_28_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0);
    i03.\u0275\u0275pipe(1, "artemisTranslate");
  }
  if (rf & 2) {
    const ctx_r12 = i03.\u0275\u0275nextContext(3);
    i03.\u0275\u0275textInterpolate1("\n                                        ", ctx_r12.achievedPoints + i03.\u0275\u0275pipeBind1(1, 1, "artemisApp.courseOverview.exerciseDetails.of"), "\n                                    ");
  }
}
function HeaderParticipationPageComponent_Conditional_0_Conditional_28_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                                        ");
    i03.\u0275\u0275elementStart(1, "span");
    i03.\u0275\u0275text(2);
    i03.\u0275\u0275pipe(3, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(4, "\n                                    ");
  }
  if (rf & 2) {
    const ctx_r13 = i03.\u0275\u0275nextContext(3);
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275textInterpolate2("(", i03.\u0275\u0275pipeBind1(3, 2, "artemisApp.courseOverview.exerciseDetails.bonus"), " ", ctx_r13.exercise.bonusPoints, ")");
  }
}
function HeaderParticipationPageComponent_Conditional_0_Conditional_28_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                                    ");
    i03.\u0275\u0275element(1, "jhi-difficulty-badge", 14);
    i03.\u0275\u0275text(2, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r14 = i03.\u0275\u0275nextContext(3);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("exercise", ctx_r14.exercise);
  }
}
function HeaderParticipationPageComponent_Conditional_0_Conditional_28_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                                    ");
    i03.\u0275\u0275element(1, "jhi-included-in-score-badge", 15);
    i03.\u0275\u0275text(2, "\n                                ");
  }
  if (rf & 2) {
    const ctx_r15 = i03.\u0275\u0275nextContext(3);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("includedInOverallScore", ctx_r15.exercise.includedInOverallScore);
  }
}
function HeaderParticipationPageComponent_Conditional_0_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                        ");
    i03.\u0275\u0275elementStart(1, "tr");
    i03.\u0275\u0275text(2, "\n                            ");
    i03.\u0275\u0275elementStart(3, "td");
    i03.\u0275\u0275text(4, "\n                                ");
    i03.\u0275\u0275elementStart(5, "h6", 3);
    i03.\u0275\u0275text(6);
    i03.\u0275\u0275pipe(7, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n                            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(9, "\n                            ");
    i03.\u0275\u0275elementStart(10, "td");
    i03.\u0275\u0275text(11, "\n                                ");
    i03.\u0275\u0275elementStart(12, "span");
    i03.\u0275\u0275text(13, "\n                                    ");
    i03.\u0275\u0275template(14, HeaderParticipationPageComponent_Conditional_0_Conditional_28_Conditional_14_Template, 2, 3);
    i03.\u0275\u0275text(15);
    i03.\u0275\u0275template(16, HeaderParticipationPageComponent_Conditional_0_Conditional_28_Conditional_16_Template, 5, 4);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(17, "\n                                ");
    i03.\u0275\u0275template(18, HeaderParticipationPageComponent_Conditional_0_Conditional_28_Conditional_18_Template, 3, 1)(19, HeaderParticipationPageComponent_Conditional_0_Conditional_28_Conditional_19_Template, 3, 1);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(20, "\n                        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(21, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r3 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(6);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(7, 6, "artemisApp.courseOverview.exerciseDetails.points"));
    i03.\u0275\u0275advance(8);
    i03.\u0275\u0275conditional(14, ctx_r3.achievedPoints !== void 0 ? 14 : -1);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275textInterpolate1("\n                                    ", ctx_r3.exercise.maxPoints, "\n                                    ");
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(16, ctx_r3.exercise.bonusPoints ? 16 : -1);
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275conditional(18, ctx_r3.exercise.difficulty ? 18 : -1);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(19, ctx_r3.exercise.includedInOverallScore && ctx_r3.exercise.includedInOverallScore != ctx_r3.IncludedInOverallScore.INCLUDED_COMPLETELY ? 19 : -1);
  }
}
function HeaderParticipationPageComponent_Conditional_0_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                        ");
    i03.\u0275\u0275elementStart(1, "tr");
    i03.\u0275\u0275text(2, "\n                            ");
    i03.\u0275\u0275elementStart(3, "td");
    i03.\u0275\u0275text(4, "\n                                ");
    i03.\u0275\u0275elementStart(5, "h6", 3);
    i03.\u0275\u0275text(6);
    i03.\u0275\u0275pipe(7, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n                            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(9, "\n                            ");
    i03.\u0275\u0275elementStart(10, "td");
    i03.\u0275\u0275text(11, "\n                                ");
    i03.\u0275\u0275elementStart(12, "span");
    i03.\u0275\u0275text(13);
    i03.\u0275\u0275pipe(14, "artemisDate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(15, "\n                                ");
    i03.\u0275\u0275elementStart(16, "span", 16);
    i03.\u0275\u0275text(17);
    i03.\u0275\u0275pipe(18, "artemisTimeAgo");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(19, "\n                            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(20, "\n                        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(21, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r4 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(6);
    i03.\u0275\u0275textInterpolate1("", i03.\u0275\u0275pipeBind1(7, 4, "artemisApp.exercise.assessmentDueDate"), ":");
    i03.\u0275\u0275advance(7);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(14, 6, ctx_r4.exercise.assessmentDueDate) || "N/A");
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("ngClass", ctx_r4.exerciseStatusBadge);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(18, 8, ctx_r4.exercise.assessmentDueDate));
  }
}
function HeaderParticipationPageComponent_Conditional_0_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                    ");
    i03.\u0275\u0275elementStart(1, "div", 1);
    i03.\u0275\u0275text(2, "\n                        ");
    i03.\u0275\u0275element(3, "jhi-submission-result-status", 17);
    i03.\u0275\u0275text(4, "\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r5 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("exercise", ctx_r5.exercise)("studentParticipation", ctx_r5.participation);
  }
}
function HeaderParticipationPageComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n    ");
    i03.\u0275\u0275elementStart(1, "div", 0);
    i03.\u0275\u0275text(2, "\n        ");
    i03.\u0275\u0275elementStart(3, "div", 1);
    i03.\u0275\u0275text(4, "\n            ");
    i03.\u0275\u0275elementStart(5, "div", 2);
    i03.\u0275\u0275text(6, "\n                ");
    i03.\u0275\u0275elementStart(7, "h4", 3);
    i03.\u0275\u0275projection(8);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(9, "\n                ");
    i03.\u0275\u0275elementStart(10, "div", 4);
    i03.\u0275\u0275text(11, "\n                    ");
    i03.\u0275\u0275elementStart(12, "h6", 5);
    i03.\u0275\u0275text(13);
    i03.\u0275\u0275pipe(14, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(15, "\n                    ");
    i03.\u0275\u0275elementStart(16, "span");
    i03.\u0275\u0275text(17);
    i03.\u0275\u0275pipe(18, "artemisDate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(19, "\n                    ");
    i03.\u0275\u0275template(20, HeaderParticipationPageComponent_Conditional_0_Conditional_20_Template, 5, 4);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(21, "\n                ");
    i03.\u0275\u0275template(22, HeaderParticipationPageComponent_Conditional_0_Conditional_22_Template, 10, 3);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(23, "\n            ");
    i03.\u0275\u0275elementStart(24, "div", 6);
    i03.\u0275\u0275text(25, "\n                ");
    i03.\u0275\u0275elementStart(26, "table", 7);
    i03.\u0275\u0275text(27, "\n                    ");
    i03.\u0275\u0275template(28, HeaderParticipationPageComponent_Conditional_0_Conditional_28_Template, 22, 8)(29, HeaderParticipationPageComponent_Conditional_0_Conditional_29_Template, 22, 10);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(30, "\n            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(31, "\n            ");
    i03.\u0275\u0275elementStart(32, "div", 8);
    i03.\u0275\u0275text(33, "\n                ");
    i03.\u0275\u0275template(34, HeaderParticipationPageComponent_Conditional_0_Conditional_34_Template, 6, 2);
    i03.\u0275\u0275elementStart(35, "div", 9);
    i03.\u0275\u0275text(36, "\n                    ");
    i03.\u0275\u0275projection(37, 1);
    i03.\u0275\u0275text(38, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(39, "\n            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(40, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(41, "\n    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(42, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(13);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(14, 7, "artemisApp.courseOverview.exerciseDetails.dueDate"));
    i03.\u0275\u0275advance(4);
    i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(18, 9, ctx_r0.dueDate) || "N/A");
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275conditional(20, ctx_r0.dueDate ? 20 : -1);
    i03.\u0275\u0275advance(2);
    i03.\u0275\u0275conditional(22, ctx_r0.exercise.categories ? 22 : -1);
    i03.\u0275\u0275advance(6);
    i03.\u0275\u0275conditional(28, ctx_r0.exercise.maxPoints ? 28 : -1);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(29, ctx_r0.exercise.assessmentDueDate ? 29 : -1);
    i03.\u0275\u0275advance(5);
    i03.\u0275\u0275conditional(34, ctx_r0.participation && ctx_r0.resultsPublished ? 34 : -1);
  }
}
var _c02, _c12, _c22, HeaderParticipationPageComponent;
var init_header_participation_page_component = __esm({
  "src/main/webapp/app/exercises/shared/exercise-headers/header-participation-page.component.ts"() {
    init_exercise_model();
    init_student_participation_model();
    init_button_component();
    init_exercise_utils();
    init_utils();
    init_difficulty_badge_component();
    init_included_in_score_badge_component();
    init_submission_result_status_component();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    init_artemis_time_ago_pipe();
    _c02 = (a0) => ({ backgroundColor: a0 });
    _c12 = [[["", "pagetitle", ""]], [["", "submitbutton", ""]]];
    _c22 = ["[pagetitle]", "[submitbutton]"];
    HeaderParticipationPageComponent = class _HeaderParticipationPageComponent {
      ButtonType = ButtonType;
      IncludedInOverallScore = IncludedInOverallScore;
      title;
      exercise;
      participation;
      exerciseStatusBadge = "bg-success";
      exerciseCategories;
      achievedPoints;
      dueDate;
      getIcon = getIcon;
      ngOnInit() {
        this.ngOnChanges();
      }
      get resultsPublished() {
        if (this.exercise?.exerciseGroup?.exam) {
          if (this.exercise.exerciseGroup.exam.publishResultsDate) {
            return dayjs2().isAfter(this.exercise.exerciseGroup.exam.publishResultsDate);
          }
          return false;
        }
        return true;
      }
      ngOnChanges() {
        if (this.exercise) {
          this.exerciseStatusBadge = hasExerciseDueDatePassed(this.exercise, this.participation) ? "bg-danger" : "bg-success";
          this.exerciseCategories = this.exercise.categories || [];
          this.dueDate = getExerciseDueDate(this.exercise, this.participation);
          if (this.participation?.results?.[0]?.rated) {
            this.achievedPoints = roundValueSpecifiedByCourseSettings(this.participation.results?.[0].score * this.exercise.maxPoints / 100, getCourseFromExercise(this.exercise));
          }
        }
      }
      static \u0275fac = function HeaderParticipationPageComponent_Factory(t) {
        return new (t || _HeaderParticipationPageComponent)();
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _HeaderParticipationPageComponent, selectors: [["jhi-header-participation-page"]], inputs: { title: "title", exercise: "exercise", participation: "participation" }, features: [i03.\u0275\u0275NgOnChangesFeature], ngContentSelectors: _c22, decls: 1, vars: 1, consts: [["id", "participation-header", 1, "course-info-bar", "course-info-bar--participation"], [1, "row"], [1, "col-12", "col-sm-12", "col-lg-5", "d-flex", "flex-column", "justify-content-center"], [1, "fw-medium"], [1, "d-flex", "align-items-center"], [1, "me-2", "mb-0", "fw-medium"], [1, "col-12", "col-sm-auto", "flex-sm-shrink-0", "col-lg-4", "mt-4", "mt-lg-0", "d-flex", "flex-column", "justify-content-center", "align-items-start"], [1, "exercise-details-table"], [1, "col-12", "col-sm-auto", "flex-sm-grow-1", "col-lg-3", "mt-4", "mt-md-0", "d-flex", "flex-column", "justify-content-center", "align-items-end"], [1, "mt-2"], [1, "badge", "ms-2", 3, "ngClass"], [1, "d-sm-flex"], [1, "me-1", "fw-medium"], [1, "badge", "text-white", "me-1", 3, "ngStyle"], [1, "ms-1", 3, "exercise"], [1, "ms-1", 3, "includedInOverallScore"], [1, "badge", "ms-1", 3, "ngClass"], [3, "exercise", "studentParticipation"]], template: function HeaderParticipationPageComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275projectionDef(_c12);
          i03.\u0275\u0275template(0, HeaderParticipationPageComponent_Conditional_0_Template, 43, 11);
        }
        if (rf & 2) {
          i03.\u0275\u0275conditional(0, ctx.exercise ? 0 : -1);
        }
      }, dependencies: [i1.NgClass, i1.NgStyle, DifficultyBadgeComponent, IncludedInScoreBadgeComponent, SubmissionResultStatusComponent, ArtemisDatePipe, ArtemisTranslatePipe, ArtemisTimeAgoPipe], styles: ["/* src/main/webapp/app/exercises/shared/exercise-headers/header-participation-page.component.scss */\n.course-info-bar--participation {\n  min-height: unset;\n  margin: calc(-1rem - 1px) calc(-1rem - 1px) 0 calc(-1rem - 1px);\n  background-color: var(--header-participation-page-info-bar-background);\n  border-top-left-radius: 3px;\n  border-top-right-radius: 3px;\n}\n.course-info-bar--participation h6 {\n  margin-bottom: 0.25rem;\n}\n.course-info-bar--participation h6:last-child {\n  margin-bottom: 0;\n}\n.course-info-bar--participation .text-body-secondary {\n  color: var(--white) !important;\n}\n.course-info-bar--participation button[disabled] {\n  cursor: not-allowed;\n}\n.course-info-bar--participation .exercise-details-table td:not(:first-child) {\n  padding-left: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlLWhlYWRlcnMvaGVhZGVyLXBhcnRpY2lwYXRpb24tcGFnZS5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiQGltcG9ydCAnc3JjL21haW4vd2ViYXBwL2NvbnRlbnQvc2Nzcy9hcnRlbWlzLXZhcmlhYmxlcyc7XG5cbi5jb3Vyc2UtaW5mby1iYXItLXBhcnRpY2lwYXRpb24ge1xuICAgICRtYXJnaW46IGNhbGMoLTFyZW0gLSAxcHgpO1xuICAgICR0b3AtYm9yZGVyLXJhZGl1czogM3B4O1xuXG4gICAgbWluLWhlaWdodDogdW5zZXQ7XG4gICAgbWFyZ2luOiAkbWFyZ2luICRtYXJnaW4gMCAkbWFyZ2luO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWhlYWRlci1wYXJ0aWNpcGF0aW9uLXBhZ2UtaW5mby1iYXItYmFja2dyb3VuZCk7XG4gICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogJHRvcC1ib3JkZXItcmFkaXVzO1xuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAkdG9wLWJvcmRlci1yYWRpdXM7XG5cbiAgICBoNiB7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDAuMjVyZW07XG5cbiAgICAgICAgJjpsYXN0LWNoaWxkIHtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDA7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAudGV4dC1ib2R5LXNlY29uZGFyeSB7XG4gICAgICAgIGNvbG9yOiB2YXIoLS13aGl0ZSkgIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICBidXR0b25bZGlzYWJsZWRdIHtcbiAgICAgICAgY3Vyc29yOiBub3QtYWxsb3dlZDtcbiAgICB9XG5cbiAgICAuZXhlcmNpc2UtZGV0YWlscy10YWJsZSB7XG4gICAgICAgIHRkOm5vdCg6Zmlyc3QtY2hpbGQpIHtcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMXJlbTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFFQSxDQUFBO0FBSUksY0FBQTtBQUNBLFVBQUEsS0FBQSxNQUFBLEVBQUEsS0FBQSxLQUFBLE1BQUEsRUFBQSxLQUFBLEVBQUEsS0FBQSxNQUFBLEVBQUE7QUFDQSxvQkFBQSxJQUFBO0FBQ0EsMEJBTG9CO0FBTXBCLDJCQU5vQjs7QUFRcEIsQ0FWSiwrQkFVSTtBQUNJLGlCQUFBOztBQUVBLENBYlIsK0JBYVEsRUFBQTtBQUNJLGlCQUFBOztBQUlSLENBbEJKLCtCQWtCSSxDQUFBO0FBQ0ksU0FBQSxJQUFBOztBQUdKLENBdEJKLCtCQXNCSSxNQUFBLENBQUE7QUFDSSxVQUFBOztBQUlBLENBM0JSLCtCQTJCUSxDQUFBLHVCQUFBLEVBQUEsS0FBQTtBQUNJLGdCQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(HeaderParticipationPageComponent, { className: "HeaderParticipationPageComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/shared/exercise-headers/exercise-headers.module.ts
import { NgModule as NgModule2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisHeaderExercisePageWithDetailsModule;
var init_exercise_headers_module = __esm({
  "src/main/webapp/app/exercises/shared/exercise-headers/exercise-headers.module.ts"() {
    init_header_exercise_page_with_details_component();
    init_header_participation_page_component();
    init_shared_module();
    init_shared_component_module();
    init_submission_result_status_module();
    init_exercise_categories_module();
    ArtemisHeaderExercisePageWithDetailsModule = class _ArtemisHeaderExercisePageWithDetailsModule {
      static \u0275fac = function ArtemisHeaderExercisePageWithDetailsModule_Factory(t) {
        return new (t || _ArtemisHeaderExercisePageWithDetailsModule)();
      };
      static \u0275mod = i04.\u0275\u0275defineNgModule({ type: _ArtemisHeaderExercisePageWithDetailsModule });
      static \u0275inj = i04.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, ArtemisSharedComponentModule, SubmissionResultStatusModule, ExerciseCategoriesModule] });
    };
  }
});

export {
  SubmissionPolicyType,
  LockRepositoryPolicy,
  SubmissionPenaltyPolicy,
  init_submission_policy_model,
  HeaderExercisePageWithDetailsComponent,
  init_header_exercise_page_with_details_component,
  HeaderParticipationPageComponent,
  init_header_participation_page_component,
  ExerciseCategoriesModule,
  init_exercise_categories_module,
  ArtemisHeaderExercisePageWithDetailsModule,
  init_exercise_headers_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2V4ZXJjaXNlLWNhdGVnb3JpZXMvZXhlcmNpc2UtY2F0ZWdvcmllcy5tb2R1bGUudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2VudGl0aWVzL3N1Ym1pc3Npb24tcG9saWN5Lm1vZGVsLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlLWhlYWRlcnMvaGVhZGVyLWV4ZXJjaXNlLXBhZ2Utd2l0aC1kZXRhaWxzLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oZWFkZXJzL2hlYWRlci1leGVyY2lzZS1wYWdlLXdpdGgtZGV0YWlscy5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oZWFkZXJzL2hlYWRlci1wYXJ0aWNpcGF0aW9uLXBhZ2UuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlLWhlYWRlcnMvaGVhZGVyLXBhcnRpY2lwYXRpb24tcGFnZS5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oZWFkZXJzL2V4ZXJjaXNlLWhlYWRlcnMubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBSb3V0ZXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL3NoYXJlZC1jb21wb25lbnQubW9kdWxlJztcbmltcG9ydCB7IEV4ZXJjaXNlQ2F0ZWdvcmllc0NvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvZXhlcmNpc2UtY2F0ZWdvcmllcy9leGVyY2lzZS1jYXRlZ29yaWVzLmNvbXBvbmVudCc7XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW0FydGVtaXNTaGFyZWRNb2R1bGUsIFJvdXRlck1vZHVsZSwgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbRXhlcmNpc2VDYXRlZ29yaWVzQ29tcG9uZW50XSxcbiAgICBleHBvcnRzOiBbRXhlcmNpc2VDYXRlZ29yaWVzQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgRXhlcmNpc2VDYXRlZ29yaWVzTW9kdWxlIHt9XG4iLCJpbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3Byb2dyYW1taW5nLWV4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IEJhc2VFbnRpdHkgfSBmcm9tICdhcHAvc2hhcmVkL21vZGVsL2Jhc2UtZW50aXR5JztcblxuZXhwb3J0IGVudW0gU3VibWlzc2lvblBvbGljeVR5cGUge1xuICAgIE5PTkUgPSAnbm9uZScsXG4gICAgTE9DS19SRVBPU0lUT1JZID0gJ2xvY2tfcmVwb3NpdG9yeScsXG4gICAgU1VCTUlTU0lPTl9QRU5BTFRZID0gJ3N1Ym1pc3Npb25fcGVuYWx0eScsXG59XG5cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBTdWJtaXNzaW9uUG9saWN5IGltcGxlbWVudHMgQmFzZUVudGl0eSB7XG4gICAgcHVibGljIGlkPzogbnVtYmVyO1xuXG4gICAgcHVibGljIHByb2dyYW1taW5nRXhlcmNpc2U/OiBQcm9ncmFtbWluZ0V4ZXJjaXNlO1xuICAgIHB1YmxpYyBhY3RpdmU/OiBib29sZWFuO1xuICAgIHB1YmxpYyBzdWJtaXNzaW9uTGltaXQ/OiBudW1iZXI7XG4gICAgcHVibGljIGV4Y2VlZGluZ1BlbmFsdHk/OiBudW1iZXI7XG4gICAgcHVibGljIHR5cGU/OiBTdWJtaXNzaW9uUG9saWN5VHlwZTtcblxuICAgIHByb3RlY3RlZCBjb25zdHJ1Y3Rvcih0eXBlOiBTdWJtaXNzaW9uUG9saWN5VHlwZSkge1xuICAgICAgICB0aGlzLnR5cGUgPSB0eXBlO1xuICAgIH1cbn1cblxuZXhwb3J0IGNsYXNzIExvY2tSZXBvc2l0b3J5UG9saWN5IGV4dGVuZHMgU3VibWlzc2lvblBvbGljeSB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKFN1Ym1pc3Npb25Qb2xpY3lUeXBlLkxPQ0tfUkVQT1NJVE9SWSk7XG4gICAgICAgIHRoaXMuZXhjZWVkaW5nUGVuYWx0eSA9IHVuZGVmaW5lZDtcbiAgICB9XG59XG5cbmV4cG9ydCBjbGFzcyBTdWJtaXNzaW9uUGVuYWx0eVBvbGljeSBleHRlbmRzIFN1Ym1pc3Npb25Qb2xpY3kge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihTdWJtaXNzaW9uUG9saWN5VHlwZS5TVUJNSVNTSU9OX1BFTkFMVFkpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uQ2hhbmdlcywgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTb3J0U2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2VydmljZS9zb3J0LnNlcnZpY2UnO1xuaW1wb3J0IGRheWpzIGZyb20gJ2RheWpzL2VzbSc7XG5pbXBvcnQgeyBFeGVyY2lzZSwgRXhlcmNpc2VUeXBlLCBJbmNsdWRlZEluT3ZlcmFsbFNjb3JlLCBnZXRDb3Vyc2VGcm9tRXhlcmNpc2UsIGdldEljb24sIGdldEljb25Ub29sdGlwIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IEV4YW0gfSBmcm9tICdhcHAvZW50aXRpZXMvZXhhbS5tb2RlbCc7XG5pbXBvcnQgeyBJY29uUHJvcCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1zdmctY29yZSc7XG5pbXBvcnQgeyBFeGVyY2lzZUNhdGVnb3J5IH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLWNhdGVnb3J5Lm1vZGVsJztcbmltcG9ydCB7IFN1Ym1pc3Npb25Qb2xpY3kgfSBmcm9tICdhcHAvZW50aXRpZXMvc3VibWlzc2lvbi1wb2xpY3kubW9kZWwnO1xuaW1wb3J0IHsgU3R1ZGVudFBhcnRpY2lwYXRpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvcGFydGljaXBhdGlvbi9zdHVkZW50LXBhcnRpY2lwYXRpb24ubW9kZWwnO1xuaW1wb3J0IHsgZ2V0RXhlcmNpc2VEdWVEYXRlIH0gZnJvbSAnYXBwL2V4ZXJjaXNlcy9zaGFyZWQvZXhlcmNpc2UvZXhlcmNpc2UudXRpbHMnO1xuaW1wb3J0IHsgZmFRdWVzdGlvbkNpcmNsZSB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBQcm9ncmFtbWluZ0V4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL3Byb2dyYW1taW5nLWV4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IENvdXJzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb3Vyc2UubW9kZWwnO1xuaW1wb3J0IHsgQXNzZXNzbWVudFR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvYXNzZXNzbWVudC10eXBlLm1vZGVsJztcbmltcG9ydCB7IENvbXBsYWludFNlcnZpY2UgfSBmcm9tICdhcHAvY29tcGxhaW50cy9jb21wbGFpbnQuc2VydmljZSc7XG5pbXBvcnQgeyBTdWJtaXNzaW9uVHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IFByb2dyYW1taW5nU3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9wcm9ncmFtbWluZy1zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IHJvdW5kVmFsdWVTcGVjaWZpZWRCeUNvdXJzZVNldHRpbmdzIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL3V0aWxzJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktaGVhZGVyLWV4ZXJjaXNlLXBhZ2Utd2l0aC1kZXRhaWxzJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vaGVhZGVyLWV4ZXJjaXNlLXBhZ2Utd2l0aC1kZXRhaWxzLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9oZWFkZXItZXhlcmNpc2UtcGFnZS13aXRoLWRldGFpbHMuY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgSGVhZGVyRXhlcmNpc2VQYWdlV2l0aERldGFpbHNDb21wb25lbnQgaW1wbGVtZW50cyBPbkNoYW5nZXMsIE9uSW5pdCB7XG4gICAgcmVhZG9ubHkgSW5jbHVkZWRJbk92ZXJhbGxTY29yZSA9IEluY2x1ZGVkSW5PdmVyYWxsU2NvcmU7XG4gICAgcmVhZG9ubHkgQXNzZXNzbWVudFR5cGUgPSBBc3Nlc3NtZW50VHlwZTtcbiAgICByZWFkb25seSBFeGVyY2lzZVR5cGUgPSBFeGVyY2lzZVR5cGU7XG4gICAgcmVhZG9ubHkgZ2V0SWNvbiA9IGdldEljb247XG4gICAgcmVhZG9ubHkgZ2V0SWNvblRvb2x0aXAgPSBnZXRJY29uVG9vbHRpcDtcbiAgICByZWFkb25seSBkYXlqcyA9IGRheWpzO1xuXG4gICAgQElucHV0KCkgcHVibGljIGV4ZXJjaXNlOiBFeGVyY2lzZTtcbiAgICBASW5wdXQoKSBwdWJsaWMgc3R1ZGVudFBhcnRpY2lwYXRpb24/OiBTdHVkZW50UGFydGljaXBhdGlvbjtcbiAgICBASW5wdXQoKSBwdWJsaWMgdGl0bGU6IHN0cmluZztcbiAgICBASW5wdXQoKSBwdWJsaWMgZXhhbT86IEV4YW07XG4gICAgQElucHV0KCkgcHVibGljIGNvdXJzZT86IENvdXJzZTtcbiAgICBASW5wdXQoKSBwdWJsaWMgaXNUZXN0UnVuID0gZmFsc2U7XG4gICAgQElucHV0KCkgcHVibGljIHN1Ym1pc3Npb25Qb2xpY3k/OiBTdWJtaXNzaW9uUG9saWN5O1xuXG4gICAgcHVibGljIGV4ZXJjaXNlQ2F0ZWdvcmllczogRXhlcmNpc2VDYXRlZ29yeVtdO1xuICAgIHB1YmxpYyBkdWVEYXRlPzogZGF5anMuRGF5anM7XG4gICAgcHVibGljIGlzQmVmb3JlU3RhcnREYXRlOiBib29sZWFuO1xuICAgIHB1YmxpYyBwcm9ncmFtbWluZ0V4ZXJjaXNlPzogUHJvZ3JhbW1pbmdFeGVyY2lzZTtcbiAgICBwdWJsaWMgaW5kaXZpZHVhbENvbXBsYWludER1ZURhdGU/OiBkYXlqcy5EYXlqcztcbiAgICBwdWJsaWMgbmV4dFJlbGV2YW50RGF0ZT86IGRheWpzLkRheWpzO1xuICAgIHB1YmxpYyBuZXh0UmVsZXZhbnREYXRlTGFiZWw/OiBzdHJpbmc7XG4gICAgcHVibGljIG5leHRSZWxldmFudERhdGVTdGF0dXNCYWRnZT86IHN0cmluZztcbiAgICBwdWJsaWMgZHVlRGF0ZVN0YXR1c0JhZGdlPzogc3RyaW5nO1xuICAgIHB1YmxpYyBjYW5Db21wbGFpbkxhdGVyT246IGJvb2xlYW47XG4gICAgcHVibGljIGFjaGlldmVkUG9pbnRzPzogbnVtYmVyO1xuICAgIHB1YmxpYyBudW1iZXJPZlN1Ym1pc3Npb25zOiBudW1iZXI7XG5cbiAgICBpY29uOiBJY29uUHJvcDtcblxuICAgIC8vIEljb25zXG4gICAgZmFRdWVzdGlvbkNpcmNsZSA9IGZhUXVlc3Rpb25DaXJjbGU7XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIHNvcnRTZXJ2aWNlOiBTb3J0U2VydmljZSkge31cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICB0aGlzLmV4ZXJjaXNlQ2F0ZWdvcmllcyA9IHRoaXMuZXhlcmNpc2UuY2F0ZWdvcmllcyB8fCBbXTtcblxuICAgICAgICBpZiAodGhpcy5leGVyY2lzZS50eXBlKSB7XG4gICAgICAgICAgICB0aGlzLmljb24gPSBnZXRJY29uKHRoaXMuZXhlcmNpc2UudHlwZSk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLnByb2dyYW1taW5nRXhlcmNpc2UgPSB0aGlzLmV4ZXJjaXNlLnR5cGUgPT09IEV4ZXJjaXNlVHlwZS5QUk9HUkFNTUlORyA/ICh0aGlzLmV4ZXJjaXNlIGFzIFByb2dyYW1taW5nRXhlcmNpc2UpIDogdW5kZWZpbmVkO1xuXG4gICAgICAgIGlmICh0aGlzLmV4YW0pIHtcbiAgICAgICAgICAgIHRoaXMuZGV0ZXJtaW5lTmV4dFJlbGV2YW50RGF0ZUV4YW1Nb2RlKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmR1ZURhdGUgPSBnZXRFeGVyY2lzZUR1ZURhdGUodGhpcy5leGVyY2lzZSwgdGhpcy5zdHVkZW50UGFydGljaXBhdGlvbik7XG4gICAgICAgICAgICB0aGlzLmlzQmVmb3JlU3RhcnREYXRlID0gdGhpcy5leGVyY2lzZS5zdGFydERhdGUgPyB0aGlzLmV4ZXJjaXNlLnN0YXJ0RGF0ZS5pc0FmdGVyKGRheWpzKCkpIDogISF0aGlzLmV4ZXJjaXNlLnJlbGVhc2VEYXRlPy5pc0FmdGVyKGRheWpzKCkpO1xuICAgICAgICAgICAgaWYgKHRoaXMuY291cnNlPy5tYXhDb21wbGFpbnRUaW1lRGF5cykge1xuICAgICAgICAgICAgICAgIHRoaXMuaW5kaXZpZHVhbENvbXBsYWludER1ZURhdGUgPSBDb21wbGFpbnRTZXJ2aWNlLmdldEluZGl2aWR1YWxDb21wbGFpbnREdWVEYXRlKFxuICAgICAgICAgICAgICAgICAgICB0aGlzLmV4ZXJjaXNlLFxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZS5tYXhDb21wbGFpbnRUaW1lRGF5cyxcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zdHVkZW50UGFydGljaXBhdGlvbj8ucmVzdWx0cz8ubGFzdCgpLFxuICAgICAgICAgICAgICAgICAgICB0aGlzLnN0dWRlbnRQYXJ0aWNpcGF0aW9uLFxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBUaGVyZSBpcyBhIHN1Ym1pc3Npb24gd2hlcmUgdGhlIHN0dWRlbnQgZGlkIG5vdCBoYXZlIHRoZSBjaGFuY2UgdG8gY29tcGxhaW4geWV0XG4gICAgICAgICAgICB0aGlzLmNhbkNvbXBsYWluTGF0ZXJPbiA9XG4gICAgICAgICAgICAgICAgISF0aGlzLnN0dWRlbnRQYXJ0aWNpcGF0aW9uPy5zdWJtaXNzaW9uQ291bnQgJiZcbiAgICAgICAgICAgICAgICAhdGhpcy5pbmRpdmlkdWFsQ29tcGxhaW50RHVlRGF0ZSAmJlxuICAgICAgICAgICAgICAgICh0aGlzLmV4ZXJjaXNlLmFsbG93Q29tcGxhaW50c0ZvckF1dG9tYXRpY0Fzc2Vzc21lbnRzIHx8IHRoaXMuZXhlcmNpc2UuYXNzZXNzbWVudFR5cGUgIT09IEFzc2Vzc21lbnRUeXBlLkFVVE9NQVRJQyk7XG5cbiAgICAgICAgICAgIHRoaXMuZGV0ZXJtaW5lTmV4dFJlbGV2YW50RGF0ZUNvdXJzZU1vZGUoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLmR1ZURhdGUpIHtcbiAgICAgICAgICAgIHRoaXMuZHVlRGF0ZVN0YXR1c0JhZGdlID0gZGF5anMoKS5pc0JlZm9yZSh0aGlzLmR1ZURhdGUpID8gJ2JnLXN1Y2Nlc3MnIDogJ2JnLWRhbmdlcic7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBuZ09uQ2hhbmdlcygpIHtcbiAgICAgICAgdGhpcy5jb3Vyc2UgPSB0aGlzLmNvdXJzZSA/PyBnZXRDb3Vyc2VGcm9tRXhlcmNpc2UodGhpcy5leGVyY2lzZSk7XG5cbiAgICAgICAgaWYgKHRoaXMuc3VibWlzc2lvblBvbGljeT8uYWN0aXZlKSB7XG4gICAgICAgICAgICB0aGlzLmNvdW50U3VibWlzc2lvbnMoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5zdHVkZW50UGFydGljaXBhdGlvbj8ucmVzdWx0cz8ubGVuZ3RoKSB7XG4gICAgICAgICAgICAvLyBUaGUgdXBkYXRlZCBwYXJ0aWNpcGF0aW9uIGJ5IHRoZSB3ZWJzb2NrZXQgaXMgbm90IGd1YXJhbnRlZWQgdG8gYmUgc29ydGVkLCBmaW5kIHRoZSBuZXdlc3QgcmVzdWx0IChoaWdoZXN0IGlkKVxuICAgICAgICAgICAgdGhpcy5zb3J0U2VydmljZS5zb3J0QnlQcm9wZXJ0eSh0aGlzLnN0dWRlbnRQYXJ0aWNpcGF0aW9uLnJlc3VsdHMsICdpZCcsIGZhbHNlKTtcblxuICAgICAgICAgICAgY29uc3QgbGF0ZXN0UmF0ZWRSZXN1bHQgPSB0aGlzLnN0dWRlbnRQYXJ0aWNpcGF0aW9uLnJlc3VsdHMuZmlsdGVyKChyZXN1bHQpID0+IHJlc3VsdC5yYXRlZCkuZmlyc3QoKTtcbiAgICAgICAgICAgIGlmIChsYXRlc3RSYXRlZFJlc3VsdCkge1xuICAgICAgICAgICAgICAgIHRoaXMuYWNoaWV2ZWRQb2ludHMgPSByb3VuZFZhbHVlU3BlY2lmaWVkQnlDb3Vyc2VTZXR0aW5ncygobGF0ZXN0UmF0ZWRSZXN1bHQuc2NvcmUhICogdGhpcy5leGVyY2lzZS5tYXhQb2ludHMhKSAvIDEwMCwgdGhpcy5jb3Vyc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGV0ZXJtaW5lcyB0aGUgbmV4dCBkYXRlIG9mIHRoZSBleGFtIGN5Y2xlLiBJZiBub25lIGV4aXN0cyB0aGUgbGF0ZXN0IGRhdGUgaW4gdGhlIHBhc3QgaXMgZGV0ZXJtaW5lZFxuICAgICAqL1xuICAgIHByaXZhdGUgZGV0ZXJtaW5lTmV4dFJlbGV2YW50RGF0ZUV4YW1Nb2RlKCkge1xuICAgICAgICBjb25zdCBwb3NzaWJsZURhdGVzID0gW3RoaXMuZXhhbT8uZW5kRGF0ZSwgdGhpcy5leGFtPy5wdWJsaXNoUmVzdWx0c0RhdGVdO1xuICAgICAgICBjb25zdCBwb3NzaWJsZURhdGVzTGFiZWxzID0gWydlbmREYXRlJywgJ3B1Ymxpc2hSZXN1bHRzRGF0ZSddO1xuXG4gICAgICAgIHRoaXMuZGV0ZXJtaW5lTmV4dERhdGUocG9zc2libGVEYXRlcywgcG9zc2libGVEYXRlc0xhYmVscywgZGF5anMoKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRGV0ZXJtaW5lcyB0aGUgbmV4dCBkYXRlIG9mIHRoZSBjb3Vyc2UgZXhlcmNpc2UgY3ljbGUuIElmIG5vbmUgZXhpc3RzIHRoZSBsYXRlc3QgZGF0ZSBpbiB0aGUgcGFzdCBpcyBkZXRlcm1pbmVkXG4gICAgICovXG4gICAgcHJpdmF0ZSBkZXRlcm1pbmVOZXh0UmVsZXZhbnREYXRlQ291cnNlTW9kZSgpIHtcbiAgICAgICAgY29uc3QgcG9zc2libGVEYXRlcyA9IFt0aGlzLmV4ZXJjaXNlLnJlbGVhc2VEYXRlLCB0aGlzLmV4ZXJjaXNlLnN0YXJ0RGF0ZSwgdGhpcy5leGVyY2lzZS5hc3Nlc3NtZW50RHVlRGF0ZSwgdGhpcy5pbmRpdmlkdWFsQ29tcGxhaW50RHVlRGF0ZV07XG4gICAgICAgIGNvbnN0IHBvc3NpYmxlRGF0ZXNMYWJlbHMgPSBbJ3JlbGVhc2VEYXRlJywgJ3N0YXJ0RGF0ZScsICdhc3Nlc3NtZW50RHVlJywgJ2NvbXBsYWludER1ZSddO1xuXG4gICAgICAgIHRoaXMuZGV0ZXJtaW5lTmV4dERhdGUocG9zc2libGVEYXRlcywgcG9zc2libGVEYXRlc0xhYmVscywgZGF5anMoKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSXRlcmF0ZXMgb3ZlciB0aGUgZ2l2ZW4gZGF0ZXMgYW5kIGRldGVybWluZXMgdGhlIGZpcnN0IGRhdGUgdGhhdCBpcyBpbiB0aGUgZnV0dXJlLlxuICAgICAqIElmIG5vIHN1Y2ggZGF0ZSBleGlzdHMsIGl0IGlzIGRldGVybWluZWQgaWYgdGhlIHN0dWRlbnQgY2FuIGNvbXBsYWludCBsYXRlciBvbi5cbiAgICAgKiBJZiB0aGF0IGlzIGFsc28gbm90IHRoZSBjYXNlLCB0aGUgbGF0ZXN0IGRhdGUgaW4gdGhlIHBhc3QgaXMgY2hvc2VuIHRoYXQgaXMgYWZ0ZXIgdGhlIGR1ZSBkYXRlLlxuICAgICAqIEBwYXJhbSBkYXRlcyB0aGF0IHNob3VsZCBiZSBpdGVyYXRlZCBvdmVyLiBDYW4gY29udGFpbiB1bmRlZmluZWQgaWYgdGhhdCBkYXRlIGRvZXMgbm90IGV4aXN0XG4gICAgICogQHBhcmFtIGRhdGVMYWJlbHMgdGhlIGxhYmVscyB1c2VkIHRvIHRyYW5zbGF0ZSB0aGUgZ2l2ZW4gZGF0ZXNcbiAgICAgKiBAcGFyYW0gbm93IHRoZSBjdXJyZW50IGRhdGUgYW5kIHRpbWVcbiAgICAgKi9cbiAgICBwcml2YXRlIGRldGVybWluZU5leHREYXRlKGRhdGVzOiAoZGF5anMuRGF5anMgfCB1bmRlZmluZWQpW10sIGRhdGVMYWJlbHM6IHN0cmluZ1tdLCBub3c6IGRheWpzLkRheWpzKSB7XG4gICAgICAgIHRoaXMubmV4dFJlbGV2YW50RGF0ZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgdGhpcy5uZXh0UmVsZXZhbnREYXRlTGFiZWwgPSB1bmRlZmluZWQ7XG4gICAgICAgIHRoaXMubmV4dFJlbGV2YW50RGF0ZVN0YXR1c0JhZGdlID0gdW5kZWZpbmVkO1xuXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0ZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChkYXRlc1tpXSAmJiBub3cuaXNCZWZvcmUoZGF0ZXNbaV0pKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5uZXh0UmVsZXZhbnREYXRlID0gZGF0ZXNbaV0hO1xuICAgICAgICAgICAgICAgIHRoaXMubmV4dFJlbGV2YW50RGF0ZUxhYmVsID0gZGF0ZUxhYmVsc1tpXTtcbiAgICAgICAgICAgICAgICB0aGlzLm5leHRSZWxldmFudERhdGVTdGF0dXNCYWRnZSA9ICdiZy1zdWNjZXNzJztcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuY2FuQ29tcGxhaW5MYXRlck9uKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaSA9IGRhdGVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgICBpZiAoZGF0ZXNbaV0pIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5kdWVEYXRlICYmIHRoaXMuZHVlRGF0ZS5pc0FmdGVyKGRhdGVzW2ldKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdGhpcy5uZXh0UmVsZXZhbnREYXRlID0gZGF0ZXNbaV0hO1xuICAgICAgICAgICAgICAgIHRoaXMubmV4dFJlbGV2YW50RGF0ZUxhYmVsID0gZGF0ZUxhYmVsc1tpXTtcbiAgICAgICAgICAgICAgICB0aGlzLm5leHRSZWxldmFudERhdGVTdGF0dXNCYWRnZSA9ICdiZy1kYW5nZXInO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgY291bnRTdWJtaXNzaW9ucygpIHtcbiAgICAgICAgY29uc3QgY29tbWl0SGFzaFNldCA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuXG4gICAgICAgIHRoaXMuc3R1ZGVudFBhcnRpY2lwYXRpb24/LnJlc3VsdHNcbiAgICAgICAgICAgID8ubWFwKChyZXN1bHQpID0+IHJlc3VsdC5zdWJtaXNzaW9uKVxuICAgICAgICAgICAgLmZpbHRlcigoc3VibWlzc2lvbikgPT4gc3VibWlzc2lvbj8udHlwZSA9PT0gU3VibWlzc2lvblR5cGUuTUFOVUFMKVxuICAgICAgICAgICAgLm1hcCgoc3VibWlzc2lvbikgPT4gKHN1Ym1pc3Npb24gYXMgUHJvZ3JhbW1pbmdTdWJtaXNzaW9uKS5jb21taXRIYXNoKVxuICAgICAgICAgICAgLmZvckVhY2goKGNvbW1pdEhhc2g6IHN0cmluZykgPT4gY29tbWl0SGFzaFNldC5hZGQoY29tbWl0SGFzaCkpO1xuXG4gICAgICAgIHRoaXMubnVtYmVyT2ZTdWJtaXNzaW9ucyA9IGNvbW1pdEhhc2hTZXQuc2l6ZTtcbiAgICB9XG59XG4iLCJAaWYgKGV4ZXJjaXNlKSB7XG4gICAgPGRpdiBjbGFzcz1cImNvdXJzZS1pbmZvLWJhclwiIGlkPVwiZXhlcmNpc2UtaGVhZGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsZWZ0LWNvbFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRpdGxlLXJvd1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbm5lci1yb3dcIj5cbiAgICAgICAgICAgICAgICAgICAgQGlmIChleGVyY2lzZS50eXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJnZXRJY29uKGV4ZXJjaXNlLnR5cGUpXCIgW25nYlRvb2x0aXBdPVwiZ2V0SWNvblRvb2x0aXAoZXhlcmNpc2UudHlwZSkgfCBhcnRlbWlzVHJhbnNsYXRlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICZuYnNwO1xuICAgICAgICAgICAgICAgICAgICA8bmctY29udGVudCBzZWxlY3Q9XCJbcGFnZXRpdGxlXVwiPjwvbmctY29udGVudD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICBAaWYgKChleGVyY2lzZS5yZWxlYXNlRGF0ZSAmJiBkYXlqcyhleGVyY2lzZS5yZWxlYXNlRGF0ZSkuaXNBZnRlcihkYXlqcygpKSkgfHwgZXhlcmNpc2UuZGlmZmljdWx0eSB8fCBleGVyY2lzZUNhdGVnb3JpZXM/Lmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICA8amhpLWV4ZXJjaXNlLWNhdGVnb3JpZXMgW2V4ZXJjaXNlXT1cImV4ZXJjaXNlXCIgW3Nob3dUYWdzXT1cInsgZGlmZmljdWx0eTogdHJ1ZSwgbm90UmVsZWFzZWQ6IHRydWUgfVwiIFtuZ0NsYXNzXT1cIidiYWRnZS1yb3cnXCI+PC9qaGktZXhlcmNpc2UtY2F0ZWdvcmllcz5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIEBpZiAoZXhlcmNpc2UubWF4UG9pbnRzIHx8IChleGVyY2lzZS5hc3Nlc3NtZW50VHlwZSAmJiBleGVyY2lzZS50eXBlID09PSBFeGVyY2lzZVR5cGUuUFJPR1JBTU1JTkcpKSB7XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInBvaW50cy1hc3Nlc3NtZW50LXJvd1wiPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKGV4ZXJjaXNlLm1heFBvaW50cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gW3N0eWxlLm1hcmdpbi1yaWdodF09XCJleGVyY2lzZS5tYXhQb2ludHMgPyAnMzBweCcgOiBudWxsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJtZS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlRGV0YWlscy5wb2ludHMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGFjaGlldmVkUG9pbnRzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGFjaGlldmVkUG9pbnRzICsgKCdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlRGV0YWlscy5vZicgfCBhcnRlbWlzVHJhbnNsYXRlKSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGV4ZXJjaXNlLm1heFBvaW50cyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGV4ZXJjaXNlLmJvbnVzUG9pbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4oe3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VEZXRhaWxzLmJvbnVzJyB8IGFydGVtaXNUcmFuc2xhdGUgfX0ge3sgZXhlcmNpc2UuYm9udXNQb2ludHMgfX0pPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2UuaW5jbHVkZWRJbk92ZXJhbGxTY29yZSAhPT0gSW5jbHVkZWRJbk92ZXJhbGxTY29yZS5JTkNMVURFRF9DT01QTEVURUxZKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktaW5jbHVkZWQtaW4tc2NvcmUtYmFkZ2UgW2luY2x1ZGVkSW5PdmVyYWxsU2NvcmVdPVwiZXhlcmNpc2UuaW5jbHVkZWRJbk92ZXJhbGxTY29yZVwiIGNsYXNzPVwibWUtMlwiPjwvamhpLWluY2x1ZGVkLWluLXNjb3JlLWJhZGdlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBAaWYgKGV4ZXJjaXNlLmFzc2Vzc21lbnRUeXBlICYmIGV4ZXJjaXNlLnR5cGUgPT09IEV4ZXJjaXNlVHlwZS5QUk9HUkFNTUlORykge1xuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VEZXRhaWxzLmFzc2Vzc21lbnRUeXBlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuQXNzZXNzbWVudFR5cGUuZm9yRXhlcmNpc2VIZWFkZXIuJyArIGV4ZXJjaXNlLmFzc2Vzc21lbnRUeXBlIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVF1ZXN0aW9uQ2lyY2xlXCIgbmdiVG9vbHRpcD1cInt7ICdhcnRlbWlzQXBwLkFzc2Vzc21lbnRUeXBlLnRvb2x0aXAuJyArIGV4ZXJjaXNlLmFzc2Vzc21lbnRUeXBlIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmIChzdWJtaXNzaW9uUG9saWN5ICYmIHN1Ym1pc3Npb25Qb2xpY3kuYWN0aXZlKSB7XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN1Ym1pc3Npb24tcm93XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+e3sgJ2FydGVtaXNBcHAucHJvZ3JhbW1pbmdFeGVyY2lzZS5zdWJtaXNzaW9uUG9saWN5LnN1Ym1pc3Npb25MaW1pdFRpdGxlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX06PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB7e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bWJlck9mU3VibWlzc2lvbnMgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnLycgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdWJtaXNzaW9uUG9saWN5LnN1Ym1pc3Npb25MaW1pdCArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChzdWJtaXNzaW9uUG9saWN5LmV4Y2VlZGluZ1BlbmFsdHlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gKCdhcnRlbWlzQXBwLnByb2dyYW1taW5nRXhlcmNpc2Uuc3VibWlzc2lvblBvbGljeS5zdWJtaXNzaW9uUGVuYWx0eS5wZW5hbHR5SW5mb0xhYmVsJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8IGFydGVtaXNUcmFuc2xhdGU6IHsgcG9pbnRzOiBzdWJtaXNzaW9uUG9saWN5LmV4Y2VlZGluZ1BlbmFsdHkgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJycpXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbaWNvbl09XCJmYVF1ZXN0aW9uQ2lyY2xlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuZ2JUb29sdGlwPVwie3sgJ2FydGVtaXNBcHAucHJvZ3JhbW1pbmdFeGVyY2lzZS5zdWJtaXNzaW9uUG9saWN5LnN1Ym1pc3Npb25Qb2xpY3lUeXBlLicgKyBzdWJtaXNzaW9uUG9saWN5LnR5cGUgKyAnLnRvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJyaWdodC1jb2xcIj5cbiAgICAgICAgICAgIEBpZiAoIW5leHRSZWxldmFudERhdGVMYWJlbCB8fCAobmV4dFJlbGV2YW50RGF0ZUxhYmVsICE9PSAncmVsZWFzZURhdGUnICYmIG5leHRSZWxldmFudERhdGVMYWJlbCAhPT0gJ3N0YXJ0RGF0ZScpKSB7XG4gICAgICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICAgICAgICBAaWYgKG5leHRSZWxldmFudERhdGUgJiYgKCFleGFtIHx8ICFpc1Rlc3RSdW4pKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmdy01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlRGV0YWlscy4nICsgbmV4dFJlbGV2YW50RGF0ZUxhYmVsIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbmdDbGFzc109XCJuZXh0UmVsZXZhbnREYXRlU3RhdHVzQmFkZ2VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYmFkZ2VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ2JUb29sdGlwXT1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnYXJ0ZW1pc0FwcC5jb3Vyc2VPdmVydmlldy5leGVyY2lzZURldGFpbHMuJyArIG5leHRSZWxldmFudERhdGVMYWJlbCArICdUb29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGU6IHsgZGF0ZTogbmV4dFJlbGV2YW50RGF0ZSB8IGFydGVtaXNEYXRlIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IG5leHRSZWxldmFudERhdGUgfCBhcnRlbWlzVGltZUFnbyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgQGlmIChleGVyY2lzZS5wcmVzZW50YXRpb25TY29yZUVuYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY291cnNlPy5wcmVzZW50YXRpb25TY29yZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlRGV0YWlscy5wcmVzZW50ZWQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoKHN0dWRlbnRQYXJ0aWNpcGF0aW9uPy5wcmVzZW50YXRpb25TY29yZSA/PyAwKSA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSBiZy1zdWNjZXNzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnZ2xvYmFsLmdlbmVyaWMueWVzJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKChzdHVkZW50UGFydGljaXBhdGlvbj8ucHJlc2VudGF0aW9uU2NvcmUgPz8gMCkgPD0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLXNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2dsb2JhbC5nZW5lcmljLm5vJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlRGV0YWlscy5wcmVzZW50YXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc3R1ZGVudFBhcnRpY2lwYXRpb24/LnByZXNlbnRhdGlvblNjb3JlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctc3VjY2Vzc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgc3R1ZGVudFBhcnRpY2lwYXRpb24hLnByZXNlbnRhdGlvblNjb3JlICsgJyUnIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghc3R1ZGVudFBhcnRpY2lwYXRpb24/LnByZXNlbnRhdGlvblNjb3JlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnZ2xvYmFsLmdlbmVyaWMudW5zZXQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKGR1ZURhdGUpIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZnctNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlRGV0YWlscy5zdWJtaXNzaW9uRHVlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgIFtuZ0NsYXNzXT1cImR1ZURhdGVTdGF0dXNCYWRnZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJhZGdlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtuZ2JUb29sdGlwXT1cIidhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlRGV0YWlscy5zdWJtaXNzaW9uRHVlVG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlOiB7IGRhdGU6IGR1ZURhdGUgfCBhcnRlbWlzRGF0ZSB9XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge3sgZHVlRGF0ZSB8IGFydGVtaXNUaW1lQWdvIH19XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAoIW5leHRSZWxldmFudERhdGVMYWJlbCB8fCAobmV4dFJlbGV2YW50RGF0ZUxhYmVsICE9PSAnYXNzZXNzbWVudER1ZScgJiYgbmV4dFJlbGV2YW50RGF0ZUxhYmVsICE9PSAnY29tcGxhaW50RHVlJykpIHtcbiAgICAgICAgICAgIH0gQGVsc2Uge1xuICAgICAgICAgICAgICAgIEBpZiAobmV4dFJlbGV2YW50RGF0ZSAmJiAoIWV4YW0gfHwgIWlzVGVzdFJ1bikpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZ3LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VEZXRhaWxzLicgKyBuZXh0UmVsZXZhbnREYXRlTGFiZWwgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ0NsYXNzXT1cIm5leHRSZWxldmFudERhdGVTdGF0dXNCYWRnZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJiYWRnZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nYlRvb2x0aXBdPVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlRGV0YWlscy4nICsgbmV4dFJlbGV2YW50RGF0ZUxhYmVsICsgJ1Rvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZTogeyBkYXRlOiBuZXh0UmVsZXZhbnREYXRlIHwgYXJ0ZW1pc0RhdGUgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgbmV4dFJlbGV2YW50RGF0ZSB8IGFydGVtaXNUaW1lQWdvIH19XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBAaWYgKGV4ZXJjaXNlLnByZXNlbnRhdGlvblNjb3JlRW5hYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChjb3Vyc2U/LnByZXNlbnRhdGlvblNjb3JlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VEZXRhaWxzLnByZXNlbnRlZCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICgoc3R1ZGVudFBhcnRpY2lwYXRpb24/LnByZXNlbnRhdGlvblNjb3JlID8/IDApID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlIGJnLXN1Y2Nlc3NcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdnbG9iYWwuZ2VuZXJpYy55ZXMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoKHN0dWRlbnRQYXJ0aWNpcGF0aW9uPy5wcmVzZW50YXRpb25TY29yZSA/PyAwKSA8PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnZ2xvYmFsLmdlbmVyaWMubm8nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghY291cnNlPy5wcmVzZW50YXRpb25TY29yZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlRGV0YWlscy5wcmVzZW50YXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc3R1ZGVudFBhcnRpY2lwYXRpb24/LnByZXNlbnRhdGlvblNjb3JlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctc3VjY2Vzc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgc3R1ZGVudFBhcnRpY2lwYXRpb24hLnByZXNlbnRhdGlvblNjb3JlICsgJyUnIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghc3R1ZGVudFBhcnRpY2lwYXRpb24/LnByZXNlbnRhdGlvblNjb3JlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYmctc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnZ2xvYmFsLmdlbmVyaWMudW5zZXQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKCFuZXh0UmVsZXZhbnREYXRlICYmIGNhbkNvbXBsYWluTGF0ZXJPbikge1xuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmdy01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VEZXRhaWxzLmNvbXBsYWludFBvc3NpYmxlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYmFkZ2UgYmctc3VjY2Vzc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICBbbmdiVG9vbHRpcF09XCInYXJ0ZW1pc0FwcC5jb3Vyc2VPdmVydmlldy5leGVyY2lzZURldGFpbHMuY29tcGxhaW50UG9zc2libGVUb29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGU6IHsgZGF5czogY291cnNlPy5tYXhDb21wbGFpbnRUaW1lRGF5cyB9XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2dsb2JhbC5nZW5lcmljLnllcycgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkNoYW5nZXMsIE9uSW5pdCwgVmlld0VuY2Fwc3VsYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCBkYXlqcyBmcm9tICdkYXlqcy9lc20nO1xuaW1wb3J0IHsgRXhlcmNpc2UsIEluY2x1ZGVkSW5PdmVyYWxsU2NvcmUsIGdldENvdXJzZUZyb21FeGVyY2lzZSwgZ2V0SWNvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBTdHVkZW50UGFydGljaXBhdGlvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9wYXJ0aWNpcGF0aW9uL3N0dWRlbnQtcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBCdXR0b25UeXBlIH0gZnJvbSAnYXBwL3NoYXJlZC9jb21wb25lbnRzL2J1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgRXhlcmNpc2VDYXRlZ29yeSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS1jYXRlZ29yeS5tb2RlbCc7XG5pbXBvcnQgeyBnZXRFeGVyY2lzZUR1ZURhdGUsIGhhc0V4ZXJjaXNlRHVlRGF0ZVBhc3NlZCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlL2V4ZXJjaXNlLnV0aWxzJztcbmltcG9ydCB7IHJvdW5kVmFsdWVTcGVjaWZpZWRCeUNvdXJzZVNldHRpbmdzIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL3V0aWxzJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktaGVhZGVyLXBhcnRpY2lwYXRpb24tcGFnZScsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2hlYWRlci1wYXJ0aWNpcGF0aW9uLXBhZ2UuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL2hlYWRlci1wYXJ0aWNpcGF0aW9uLXBhZ2UuY29tcG9uZW50LnNjc3MnXSxcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxufSlcbmV4cG9ydCBjbGFzcyBIZWFkZXJQYXJ0aWNpcGF0aW9uUGFnZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcbiAgICByZWFkb25seSBCdXR0b25UeXBlID0gQnV0dG9uVHlwZTtcbiAgICByZWFkb25seSBJbmNsdWRlZEluT3ZlcmFsbFNjb3JlID0gSW5jbHVkZWRJbk92ZXJhbGxTY29yZTtcbiAgICBASW5wdXQoKSB0aXRsZTogc3RyaW5nO1xuICAgIEBJbnB1dCgpIGV4ZXJjaXNlOiBFeGVyY2lzZTtcbiAgICBASW5wdXQoKSBwYXJ0aWNpcGF0aW9uOiBTdHVkZW50UGFydGljaXBhdGlvbjtcblxuICAgIHB1YmxpYyBleGVyY2lzZVN0YXR1c0JhZGdlID0gJ2JnLXN1Y2Nlc3MnO1xuICAgIHB1YmxpYyBleGVyY2lzZUNhdGVnb3JpZXM6IEV4ZXJjaXNlQ2F0ZWdvcnlbXTtcbiAgICBwdWJsaWMgYWNoaWV2ZWRQb2ludHM/OiBudW1iZXI7XG5cbiAgICBkdWVEYXRlPzogZGF5anMuRGF5anM7XG4gICAgZ2V0SWNvbiA9IGdldEljb247XG5cbiAgICAvKipcbiAgICAgKiBTZXRzIHRoZSBzdGF0dXMgYmFkZ2UgYW5kIGNhdGVnb3JpZXMgb2YgdGhlIGV4ZXJjaXNlIG9uIGluaXRcbiAgICAgKi9cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5uZ09uQ2hhbmdlcygpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgZmFsc2UgaWYgaXQgaXMgYW4gZXhhbSBleGVyY2lzZSBhbmQgdGhlIHB1Ymxpc2hSZXN1bHRzRGF0ZSBpcyBpbiB0aGUgZnV0dXJlLCB0cnVlIG90aGVyd2lzZVxuICAgICAqL1xuICAgIGdldCByZXN1bHRzUHVibGlzaGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAodGhpcy5leGVyY2lzZT8uZXhlcmNpc2VHcm91cD8uZXhhbSkge1xuICAgICAgICAgICAgaWYgKHRoaXMuZXhlcmNpc2UuZXhlcmNpc2VHcm91cC5leGFtLnB1Ymxpc2hSZXN1bHRzRGF0ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBkYXlqcygpLmlzQWZ0ZXIodGhpcy5leGVyY2lzZS5leGVyY2lzZUdyb3VwLmV4YW0ucHVibGlzaFJlc3VsdHNEYXRlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIGRlZmF1bHQgdG8gZmFsc2UgaWYgaXQgaXMgYW4gZXhhbSBleGVyY2lzZSBidXQgdGhlIHB1Ymxpc2hSZXN1bHRzRGF0ZSBpcyBub3Qgc2V0XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2V0cyB0aGUgc3RhdHVzIGJhZGdlIGFuZCBjYXRlZ29yaWVzIG9mIHRoZSBleGVyY2lzZSBvbiBjaGFuZ2VzXG4gICAgICovXG4gICAgbmdPbkNoYW5nZXMoKTogdm9pZCB7XG4gICAgICAgIGlmICh0aGlzLmV4ZXJjaXNlKSB7XG4gICAgICAgICAgICB0aGlzLmV4ZXJjaXNlU3RhdHVzQmFkZ2UgPSBoYXNFeGVyY2lzZUR1ZURhdGVQYXNzZWQodGhpcy5leGVyY2lzZSwgdGhpcy5wYXJ0aWNpcGF0aW9uKSA/ICdiZy1kYW5nZXInIDogJ2JnLXN1Y2Nlc3MnO1xuICAgICAgICAgICAgdGhpcy5leGVyY2lzZUNhdGVnb3JpZXMgPSB0aGlzLmV4ZXJjaXNlLmNhdGVnb3JpZXMgfHwgW107XG4gICAgICAgICAgICB0aGlzLmR1ZURhdGUgPSBnZXRFeGVyY2lzZUR1ZURhdGUodGhpcy5leGVyY2lzZSwgdGhpcy5wYXJ0aWNpcGF0aW9uKTtcbiAgICAgICAgICAgIGlmICh0aGlzLnBhcnRpY2lwYXRpb24/LnJlc3VsdHM/LlswXT8ucmF0ZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmFjaGlldmVkUG9pbnRzID0gcm91bmRWYWx1ZVNwZWNpZmllZEJ5Q291cnNlU2V0dGluZ3MoXG4gICAgICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tbm9uLW51bGwtYXNzZXJ0ZWQtb3B0aW9uYWwtY2hhaW5cbiAgICAgICAgICAgICAgICAgICAgKHRoaXMucGFydGljaXBhdGlvbi5yZXN1bHRzPy5bMF0uc2NvcmUhICogdGhpcy5leGVyY2lzZS5tYXhQb2ludHMhKSAvIDEwMCxcbiAgICAgICAgICAgICAgICAgICAgZ2V0Q291cnNlRnJvbUV4ZXJjaXNlKHRoaXMuZXhlcmNpc2UpLFxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJAaWYgKGV4ZXJjaXNlKSB7XG4gICAgPGRpdiBjbGFzcz1cImNvdXJzZS1pbmZvLWJhciBjb3Vyc2UtaW5mby1iYXItLXBhcnRpY2lwYXRpb25cIiBpZD1cInBhcnRpY2lwYXRpb24taGVhZGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtMTIgY29sLXNtLTEyIGNvbC1sZy01IGQtZmxleCBmbGV4LWNvbHVtbiBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzPVwiZnctbWVkaXVtXCI+PG5nLWNvbnRlbnQgc2VsZWN0PVwiW3BhZ2V0aXRsZV1cIj48L25nLWNvbnRlbnQ+PC9oND5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8aDYgY2xhc3M9XCJtZS0yIG1iLTAgZnctbWVkaXVtXCI+e3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VEZXRhaWxzLmR1ZURhdGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvaDY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IChkdWVEYXRlIHwgYXJ0ZW1pc0RhdGUpIHx8ICdOL0EnIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKGR1ZURhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIFtuZ0NsYXNzXT1cImV4ZXJjaXNlU3RhdHVzQmFkZ2VcIiBjbGFzcz1cImJhZGdlIG1zLTJcIj57eyBkdWVEYXRlIHwgYXJ0ZW1pc1RpbWVBZ28gfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICBAaWYgKGV4ZXJjaXNlLmNhdGVnb3JpZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImQtc20tZmxleFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzPVwibWUtMSBmdy1tZWRpdW1cIj57eyAnYXJ0ZW1pc0FwcC5jb3Vyc2VPdmVydmlldy5leGVyY2lzZURldGFpbHMuY2F0ZWdvcmllcycgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9oNj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKGNhdGVnb3J5IG9mIGV4ZXJjaXNlQ2F0ZWdvcmllczsgdHJhY2sgY2F0ZWdvcnkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDYgY2xhc3M9XCJmdy1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSB0ZXh0LXdoaXRlIG1lLTFcIiBbbmdTdHlsZV09XCJ7IGJhY2tncm91bmRDb2xvcjogY2F0ZWdvcnkuY29sb3IgfVwiPnt7IGNhdGVnb3J5LmNhdGVnb3J5IH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC0xMiBjb2wtc20tYXV0byBmbGV4LXNtLXNocmluay0wIGNvbC1sZy00IG10LTQgbXQtbGctMCBkLWZsZXggZmxleC1jb2x1bW4ganVzdGlmeS1jb250ZW50LWNlbnRlciBhbGlnbi1pdGVtcy1zdGFydFwiPlxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzcz1cImV4ZXJjaXNlLWRldGFpbHMtdGFibGVcIj5cbiAgICAgICAgICAgICAgICAgICAgQGlmIChleGVyY2lzZS5tYXhQb2ludHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNiBjbGFzcz1cImZ3LW1lZGl1bVwiPnt7ICdhcnRlbWlzQXBwLmNvdXJzZU92ZXJ2aWV3LmV4ZXJjaXNlRGV0YWlscy5wb2ludHMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvaDY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChhY2hpZXZlZFBvaW50cyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgYWNoaWV2ZWRQb2ludHMgKyAoJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VEZXRhaWxzLm9mJyB8IGFydGVtaXNUcmFuc2xhdGUpIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBleGVyY2lzZS5tYXhQb2ludHMgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2UuYm9udXNQb2ludHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4oe3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VEZXRhaWxzLmJvbnVzJyB8IGFydGVtaXNUcmFuc2xhdGUgfX0ge3sgZXhlcmNpc2UuYm9udXNQb2ludHMgfX0pPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2UuZGlmZmljdWx0eSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1kaWZmaWN1bHR5LWJhZGdlIGNsYXNzPVwibXMtMVwiIFtleGVyY2lzZV09XCJleGVyY2lzZVwiPjwvamhpLWRpZmZpY3VsdHktYmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChleGVyY2lzZS5pbmNsdWRlZEluT3ZlcmFsbFNjb3JlICYmIGV4ZXJjaXNlLmluY2x1ZGVkSW5PdmVyYWxsU2NvcmUgIT0gSW5jbHVkZWRJbk92ZXJhbGxTY29yZS5JTkNMVURFRF9DT01QTEVURUxZKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLWluY2x1ZGVkLWluLXNjb3JlLWJhZGdlIGNsYXNzPVwibXMtMVwiIFtpbmNsdWRlZEluT3ZlcmFsbFNjb3JlXT1cImV4ZXJjaXNlLmluY2x1ZGVkSW5PdmVyYWxsU2NvcmVcIj48L2poaS1pbmNsdWRlZC1pbi1zY29yZS1iYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoZXhlcmNpc2UuYXNzZXNzbWVudER1ZURhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNiBjbGFzcz1cImZ3LW1lZGl1bVwiPnt7ICdhcnRlbWlzQXBwLmV4ZXJjaXNlLmFzc2Vzc21lbnREdWVEYXRlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX06PC9oNj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgKGV4ZXJjaXNlLmFzc2Vzc21lbnREdWVEYXRlIHwgYXJ0ZW1pc0RhdGUpIHx8ICdOL0EnIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBbbmdDbGFzc109XCJleGVyY2lzZVN0YXR1c0JhZGdlXCIgY2xhc3M9XCJiYWRnZSBtcy0xXCI+e3sgZXhlcmNpc2UuYXNzZXNzbWVudER1ZURhdGUgfCBhcnRlbWlzVGltZUFnbyB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtMTIgY29sLXNtLWF1dG8gZmxleC1zbS1ncm93LTEgY29sLWxnLTMgbXQtNCBtdC1tZC0wIGQtZmxleCBmbGV4LWNvbHVtbiBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIGFsaWduLWl0ZW1zLWVuZFwiPlxuICAgICAgICAgICAgICAgIEBpZiAocGFydGljaXBhdGlvbiAmJiByZXN1bHRzUHVibGlzaGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3dcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxqaGktc3VibWlzc2lvbi1yZXN1bHQtc3RhdHVzIFtleGVyY2lzZV09XCJleGVyY2lzZVwiIFtzdHVkZW50UGFydGljaXBhdGlvbl09XCJwYXJ0aWNpcGF0aW9uXCI+PC9qaGktc3VibWlzc2lvbi1yZXN1bHQtc3RhdHVzPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPG5nLWNvbnRlbnQgc2VsZWN0PVwiW3N1Ym1pdGJ1dHRvbl1cIj48L25nLWNvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG59XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSGVhZGVyRXhlcmNpc2VQYWdlV2l0aERldGFpbHNDb21wb25lbnQgfSBmcm9tICcuL2hlYWRlci1leGVyY2lzZS1wYWdlLXdpdGgtZGV0YWlscy5jb21wb25lbnQnO1xuaW1wb3J0IHsgSGVhZGVyUGFydGljaXBhdGlvblBhZ2VDb21wb25lbnQgfSBmcm9tICdhcHAvZXhlcmNpc2VzL3NoYXJlZC9leGVyY2lzZS1oZWFkZXJzL2hlYWRlci1wYXJ0aWNpcGF0aW9uLXBhZ2UuY29tcG9uZW50JztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvY29tcG9uZW50cy9zaGFyZWQtY29tcG9uZW50Lm1vZHVsZSc7XG5pbXBvcnQgeyBTdWJtaXNzaW9uUmVzdWx0U3RhdHVzTW9kdWxlIH0gZnJvbSAnYXBwL292ZXJ2aWV3L3N1Ym1pc3Npb24tcmVzdWx0LXN0YXR1cy5tb2R1bGUnO1xuaW1wb3J0IHsgRXhlcmNpc2VDYXRlZ29yaWVzTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9leGVyY2lzZS1jYXRlZ29yaWVzL2V4ZXJjaXNlLWNhdGVnb3JpZXMubW9kdWxlJztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZSwgQXJ0ZW1pc1NoYXJlZENvbXBvbmVudE1vZHVsZSwgU3VibWlzc2lvblJlc3VsdFN0YXR1c01vZHVsZSwgRXhlcmNpc2VDYXRlZ29yaWVzTW9kdWxlXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtIZWFkZXJFeGVyY2lzZVBhZ2VXaXRoRGV0YWlsc0NvbXBvbmVudCwgSGVhZGVyUGFydGljaXBhdGlvblBhZ2VDb21wb25lbnRdLFxuICAgIGV4cG9ydHM6IFtIZWFkZXJFeGVyY2lzZVBhZ2VXaXRoRGV0YWlsc0NvbXBvbmVudCwgSGVhZGVyUGFydGljaXBhdGlvblBhZ2VDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBBcnRlbWlzSGVhZGVyRXhlcmNpc2VQYWdlV2l0aERldGFpbHNNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsb0JBQW9COztBQUQ3QixJQVdhO0FBWGI7O0FBRUE7QUFDQTtBQUNBO0FBT00sSUFBTywyQkFBUCxNQUFPLDBCQUF3Qjs7eUJBQXhCLDJCQUF3QjtNQUFBOytEQUF4QiwwQkFBd0IsQ0FBQTttRUFKdkIscUJBQXFCLGNBQWMsNEJBQTRCLEVBQUEsQ0FBQTs7Ozs7O0FDSjdFLElBQVksc0JBTVUsa0JBY1Qsc0JBT0E7QUEzQmI7O0FBQUEsS0FBQSxTQUFZQSx1QkFBb0I7QUFDNUIsTUFBQUEsc0JBQUEsTUFBQSxJQUFBO0FBQ0EsTUFBQUEsc0JBQUEsaUJBQUEsSUFBQTtBQUNBLE1BQUFBLHNCQUFBLG9CQUFBLElBQUE7SUFDSixHQUpZLHlCQUFBLHVCQUFvQixDQUFBLEVBQUE7QUFNMUIsSUFBZ0IsbUJBQWhCLE1BQWdDO01BQzNCO01BRUE7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUVQLFlBQXNCLE1BQTBCO0FBQzVDLGFBQUssT0FBTztNQUNoQjs7QUFHRSxJQUFPLHVCQUFQLGNBQW9DLGlCQUFnQjtNQUN0RCxjQUFBO0FBQ0ksY0FBTSxxQkFBcUIsZUFBZTtBQUMxQyxhQUFLLG1CQUFtQjtNQUM1Qjs7QUFHRSxJQUFPLDBCQUFQLGNBQXVDLGlCQUFnQjtNQUN6RCxjQUFBO0FBQ0ksY0FBTSxxQkFBcUIsa0JBQWtCO01BQ2pEOzs7Ozs7QUNqQ0osU0FBUyxXQUFXLGFBQWdDO0FBRXBELE9BQU8sV0FBVztBQVFsQixTQUFTLHdCQUF3Qjs7Ozs7OztBQ0pULElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLENBQUE7O0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRGEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsUUFBQSxPQUFBLFNBQUEsSUFBQSxDQUFBLEVBQStCLGNBQUEsMEJBQUEsR0FBQSxHQUFBLE9BQUEsZUFBQSxPQUFBLFNBQUEsSUFBQSxDQUFBLENBQUE7Ozs7O0FBTTVDLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSwyQkFBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7O0FBRDZCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxPQUFBLFFBQUEsRUFBcUIsWUFBQSw4QkFBQSxHQUFBLEdBQUEsQ0FBQSxFQUFBLFdBQUEsV0FBQTs7Ozs7QUFVOUIsSUFBQSxxQkFBQSxDQUFBOzs7OztBQUFBLElBQUEsaUNBQUEsMENBQUEsUUFBQSxpQkFBQSwwQkFBQSxHQUFBLEdBQUEsOENBQUEsR0FBQSxvQ0FBQTs7Ozs7QUFJQSxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTs7QUFBdUcsSUFBQSwyQkFBQTtBQUNqSCxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7Ozs7QUFEVSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsMEJBQUEsR0FBQSxHQUFBLGlEQUFBLEdBQUEsS0FBQSxRQUFBLFNBQUEsYUFBQSxHQUFBOzs7OztBQUlWLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSwrQkFBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7O0FBRGlDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsMEJBQUEsUUFBQSxTQUFBLHNCQUFBOzs7OztBQVpyQyxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0EsSUFBQSx5QkFBQSxHQUFBLDBHQUFBLEdBQUEsQ0FBQTtBQUdBLElBQUEscUJBQUEsQ0FBQTtBQUNBLElBQUEseUJBQUEsR0FBQSwwR0FBQSxHQUFBLENBQUE7QUFHSixJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDJHQUFBLEdBQUEsQ0FBQTtBQUdKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7Ozs7QUFmVSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGdCQUFBLFFBQUEsU0FBQSxZQUFBLFNBQUEsSUFBQTtBQUVFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsc0NBQUEsMEJBQUEsR0FBQSxHQUFBLGtEQUFBLEdBQUEsb0NBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxtQkFBQSxTQUFBLElBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsc0NBQUEsUUFBQSxTQUFBLFdBQUEsb0NBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxTQUFBLGNBQUEsSUFBQSxFQUFBO0FBSUosSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsU0FBQSwyQkFBQSxRQUFBLHVCQUFBLHNCQUFBLEtBQUEsRUFBQTs7Ozs7QUFNSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOzs7QUFFQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBOztBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBOzs7O0FBTFksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxzQ0FBQSwwQkFBQSxHQUFBLEdBQUEsMERBQUEsR0FBQSxzQ0FBQSwwQkFBQSxHQUFBLEdBQUEsaURBQUEsUUFBQSxTQUFBLGNBQUEsR0FBQSxvQ0FBQTtBQUVtQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLG9DQUFBLGNBQUEsMEJBQUEsR0FBQSxHQUFBLHVDQUFBLFFBQUEsU0FBQSxjQUFBLENBQUE7QUFBMUIsSUFBQSx5QkFBQSxRQUFBLFFBQUEsZ0JBQUE7Ozs7O0FBdkJ6QixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDRGQUFBLElBQUEsQ0FBQSxFQWdCQyxHQUFBLDRGQUFBLElBQUEsRUFBQTtBQVVMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUEzQlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsU0FBQSxZQUFBLElBQUEsRUFBQTtBQWlCQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxTQUFBLGtCQUFBLE9BQUEsU0FBQSxTQUFBLE9BQUEsYUFBQSxjQUFBLElBQUEsRUFBQTs7Ozs7QUFZSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFBSyxJQUFBLHFCQUFBLENBQUE7O0FBQWdHLElBQUEsMkJBQUE7QUFDckcsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBU0EsSUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTs7QUFJSixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTs7OztBQWpCYSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLElBQUEsMEJBQUEsR0FBQSxHQUFBLHNFQUFBLEdBQUEsR0FBQTtBQUVELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsOEJBQUEsT0FBQSxzQkFBQSxNQUFBLE9BQUEsaUJBQUEsbUJBQUEsT0FBQSxpQkFBQSxtQkFBQSwwQkFBQSxHQUFBLEdBQUEsc0ZBQUEsOEJBQUEsSUFBQSxLQUFBLE9BQUEsaUJBQUEsZ0JBQUEsQ0FBQSxJQUFBLEtBQUEsNEJBQUE7QUFXSSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLG9DQUFBLGNBQUEsMEJBQUEsSUFBQSxHQUFBLDBFQUFBLE9BQUEsaUJBQUEsT0FBQSxVQUFBLENBQUE7QUFEQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxnQkFBQTs7Ozs7QUFTaEIsSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7OztBQUVRLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0EsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTs7O0FBT0ksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBOzs7O0FBWFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSw4QkFBQSwwQkFBQSxHQUFBLEdBQUEsK0NBQUEsUUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBRUksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLFFBQUEsMkJBQUEsRUFBdUMsY0FBQSwwQkFBQSxHQUFBLEdBQUEsK0NBQUEsUUFBQSx3QkFBQSxXQUFBLDhCQUFBLElBQUEsS0FBQSwwQkFBQSxHQUFBLEdBQUEsUUFBQSxnQkFBQSxDQUFBLENBQUEsQ0FBQTtBQU12QyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtDQUFBLDBCQUFBLEdBQUEsSUFBQSxRQUFBLGdCQUFBLEdBQUEsNEJBQUE7Ozs7O0FBU0ksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDBDQUFBLDBCQUFBLEdBQUEsR0FBQSxvQkFBQSxHQUFBLG9DQUFBOzs7OztBQUlKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7O0FBRlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQ0FBQSwwQkFBQSxHQUFBLEdBQUEsbUJBQUEsR0FBQSxvQ0FBQTs7Ozs7QUFSUixJQUFBLHFCQUFBLENBQUE7O0FBQ0EsSUFBQSx5QkFBQSxHQUFBLHdIQUFBLEdBQUEsQ0FBQSxFQUlDLEdBQUEsd0hBQUEsR0FBQSxDQUFBOzs7Ozs7QUFMRCxJQUFBLGlDQUFBLGtDQUFBLDBCQUFBLEdBQUEsR0FBQSxxREFBQSxHQUFBLGdDQUFBO0FBQ0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxLQUFBLFVBQUEsUUFBQSx3QkFBQSxPQUFBLE9BQUEsUUFBQSxxQkFBQSx1QkFBQSxRQUFBLFlBQUEsU0FBQSxVQUFBLEtBQUEsSUFBQSxJQUFBLEVBQUE7QUFLQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEtBQUEsVUFBQSxRQUFBLHdCQUFBLE9BQUEsT0FBQSxRQUFBLHFCQUFBLHVCQUFBLFFBQUEsWUFBQSxTQUFBLFVBQUEsTUFBQSxJQUFBLElBQUEsRUFBQTs7Ozs7QUFRSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7OztBQUZRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMENBQUEsUUFBQSxxQkFBQSxvQkFBQSxLQUFBLG9DQUFBOzs7OztBQUlKLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7O0FBRlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQ0FBQSwwQkFBQSxHQUFBLEdBQUEsc0JBQUEsR0FBQSxvQ0FBQTs7Ozs7QUFSUixJQUFBLHFCQUFBLENBQUE7O0FBQ0EsSUFBQSx5QkFBQSxHQUFBLHdIQUFBLEdBQUEsQ0FBQSxFQUlDLEdBQUEsd0hBQUEsR0FBQSxDQUFBOzs7O0FBTEQsSUFBQSxpQ0FBQSxrQ0FBQSwwQkFBQSxHQUFBLEdBQUEsd0RBQUEsR0FBQSxnQ0FBQTtBQUNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLHdCQUFBLE9BQUEsT0FBQSxRQUFBLHFCQUFBLHFCQUFBLElBQUEsRUFBQTtBQUtBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxFQUFBLFFBQUEsd0JBQUEsT0FBQSxPQUFBLFFBQUEscUJBQUEscUJBQUEsSUFBQSxFQUFBOzs7OztBQXBCUixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwwR0FBQSxHQUFBLENBQUEsRUFZQyxHQUFBLDBHQUFBLEdBQUEsQ0FBQTtBQWFMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUExQlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFFBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxPQUFBLHFCQUFBLElBQUEsQ0FBQTs7Ozs7QUFoQlIsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDRGQUFBLElBQUEsRUFBQSxFQWFDLEdBQUEsNEZBQUEsR0FBQSxDQUFBOzs7O0FBYkQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEscUJBQUEsQ0FBQSxPQUFBLFFBQUEsQ0FBQSxPQUFBLGFBQUEsSUFBQSxFQUFBO0FBY0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsU0FBQSwyQkFBQSxJQUFBLEVBQUE7Ozs7O0FBK0JBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0EsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTs7O0FBS0ksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBOzs7O0FBVFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQkFBQSwwQkFBQSxHQUFBLEdBQUEseURBQUEsR0FBQSx3QkFBQTtBQUVJLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxPQUFBLGtCQUFBLEVBQThCLGNBQUEsMEJBQUEsR0FBQSxHQUFBLGtFQUFBLDhCQUFBLElBQUEsS0FBQSwwQkFBQSxHQUFBLEdBQUEsT0FBQSxPQUFBLENBQUEsQ0FBQSxDQUFBO0FBSTlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsOEJBQUEsMEJBQUEsR0FBQSxJQUFBLE9BQUEsT0FBQSxHQUFBLHdCQUFBOzs7OztBQUtaLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7Ozs7QUFFUSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOztBQUNBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7OztBQU9JLElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTs7OztBQVhRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsOEJBQUEsMEJBQUEsR0FBQSxHQUFBLCtDQUFBLFFBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUVJLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxRQUFBLDJCQUFBLEVBQXVDLGNBQUEsMEJBQUEsR0FBQSxHQUFBLCtDQUFBLFFBQUEsd0JBQUEsV0FBQSw4QkFBQSxJQUFBLEtBQUEsMEJBQUEsR0FBQSxHQUFBLFFBQUEsZ0JBQUEsQ0FBQSxDQUFBLENBQUE7QUFNdkMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxrQ0FBQSwwQkFBQSxHQUFBLElBQUEsUUFBQSxnQkFBQSxHQUFBLDRCQUFBOzs7OztBQVNJLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7O0FBRlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQ0FBQSwwQkFBQSxHQUFBLEdBQUEsb0JBQUEsR0FBQSxvQ0FBQTs7Ozs7QUFJSixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7OztBQUZRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMENBQUEsMEJBQUEsR0FBQSxHQUFBLG1CQUFBLEdBQUEsb0NBQUE7Ozs7O0FBUlIsSUFBQSxxQkFBQSxDQUFBOztBQUNBLElBQUEseUJBQUEsR0FBQSx3SEFBQSxHQUFBLENBQUEsRUFJQyxHQUFBLHdIQUFBLEdBQUEsQ0FBQTs7Ozs7O0FBTEQsSUFBQSxpQ0FBQSxrQ0FBQSwwQkFBQSxHQUFBLEdBQUEscURBQUEsR0FBQSxnQ0FBQTtBQUNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsS0FBQSxVQUFBLFFBQUEsd0JBQUEsT0FBQSxPQUFBLFFBQUEscUJBQUEsdUJBQUEsUUFBQSxZQUFBLFNBQUEsVUFBQSxLQUFBLElBQUEsSUFBQSxFQUFBO0FBS0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxLQUFBLFVBQUEsUUFBQSx3QkFBQSxPQUFBLE9BQUEsUUFBQSxxQkFBQSx1QkFBQSxRQUFBLFlBQUEsU0FBQSxVQUFBLE1BQUEsSUFBQSxJQUFBLEVBQUE7Ozs7O0FBU0ksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7Ozs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDBDQUFBLFFBQUEscUJBQUEsb0JBQUEsS0FBQSxvQ0FBQTs7Ozs7QUFJSixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7OztBQUZRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMENBQUEsMEJBQUEsR0FBQSxHQUFBLHNCQUFBLEdBQUEsb0NBQUE7Ozs7O0FBUlIsSUFBQSxxQkFBQSxDQUFBOztBQUNBLElBQUEseUJBQUEsR0FBQSx3SEFBQSxHQUFBLENBQUEsRUFJQyxHQUFBLHdIQUFBLEdBQUEsQ0FBQTs7OztBQUxELElBQUEsaUNBQUEsa0NBQUEsMEJBQUEsR0FBQSxHQUFBLHdEQUFBLEdBQUEsZ0NBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsUUFBQSx3QkFBQSxPQUFBLE9BQUEsUUFBQSxxQkFBQSxxQkFBQSxJQUFBLEVBQUE7QUFLQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsRUFBQSxRQUFBLHdCQUFBLE9BQUEsT0FBQSxRQUFBLHFCQUFBLHFCQUFBLElBQUEsRUFBQTs7Ozs7QUFyQlIsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsMEdBQUEsR0FBQSxDQUFBLEVBWUMsR0FBQSwwR0FBQSxHQUFBLENBQUE7QUFjTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7O0FBM0JRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxRQUFBLFVBQUEsT0FBQSxPQUFBLFFBQUEsT0FBQSxxQkFBQSxJQUFBLEVBQUE7QUFhQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsRUFBQSxRQUFBLFVBQUEsT0FBQSxPQUFBLFFBQUEsT0FBQSxxQkFBQSxJQUFBLEVBQUE7Ozs7O0FBN0JSLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSw0RkFBQSxJQUFBLEVBQUEsRUFhQyxHQUFBLDRGQUFBLEdBQUEsQ0FBQTs7OztBQWJELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLHFCQUFBLENBQUEsT0FBQSxRQUFBLENBQUEsT0FBQSxhQUFBLElBQUEsRUFBQTtBQWNBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLFNBQUEsMkJBQUEsSUFBQSxFQUFBOzs7OztBQWdDQSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOztBQUNBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7O0FBSUksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBUlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQkFBQSwwQkFBQSxHQUFBLEdBQUEsNkRBQUEsR0FBQSx3QkFBQTtBQUdJLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSwwQkFBQSxHQUFBLEdBQUEsc0VBQUEsOEJBQUEsSUFBQSxLQUFBLFFBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxPQUFBLG9CQUFBLENBQUEsQ0FBQTtBQUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsOEJBQUEsMEJBQUEsR0FBQSxHQUFBLG9CQUFBLEdBQUEsd0JBQUE7Ozs7O0FBbExwQixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSw2RUFBQSxHQUFBLENBQUE7QUFJQSxJQUFBLDJCQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDhFQUFBLEdBQUEsQ0FBQTtBQUdKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsOEVBQUEsR0FBQSxDQUFBLEVBNkJDLElBQUEsOEVBQUEsSUFBQSxFQUFBO0FBcUJMLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsOEVBQUEsR0FBQSxDQUFBLEVBQ0MsSUFBQSw4RUFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLDhFQUFBLElBQUEsRUFBQSxFQUFBLElBQUEsOEVBQUEsR0FBQSxDQUFBLEVBQUEsSUFBQSw4RUFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLDhFQUFBLElBQUEsRUFBQTtBQW1ITCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLElBQUE7Ozs7QUFwTG9CLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLFNBQUEsT0FBQSxJQUFBLEVBQUE7QUFNSixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxTQUFBLGVBQUEsT0FBQSxNQUFBLE9BQUEsU0FBQSxXQUFBLEVBQUEsUUFBQSxPQUFBLE1BQUEsQ0FBQSxLQUFBLE9BQUEsU0FBQSxlQUFBLE9BQUEsc0JBQUEsT0FBQSxPQUFBLE9BQUEsbUJBQUEsVUFBQSxLQUFBLEVBQUE7QUFJSixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxTQUFBLGFBQUEsT0FBQSxTQUFBLGtCQUFBLE9BQUEsU0FBQSxTQUFBLE9BQUEsYUFBQSxjQUFBLEtBQUEsRUFBQTtBQThCQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxvQkFBQSxPQUFBLGlCQUFBLFNBQUEsS0FBQSxFQUFBO0FBc0JBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxDQUFBLE9BQUEseUJBQUEsT0FBQSwwQkFBQSxpQkFBQSxPQUFBLDBCQUFBLGNBQUEsS0FBQSxFQUFBO0FBOENBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLFVBQUEsS0FBQSxFQUFBO0FBWUEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLENBQUEsT0FBQSx5QkFBQSxPQUFBLDBCQUFBLG1CQUFBLE9BQUEsMEJBQUEsaUJBQUEsS0FBQSxFQUFBO0FBK0NBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxDQUFBLE9BQUEsb0JBQUEsT0FBQSxxQkFBQSxLQUFBLEVBQUE7OztBRDVLWixrQ0F3QmE7QUF4QmI7O0FBQ0E7QUFFQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBR0E7Ozs7Ozs7Ozs7Ozs7QUFPTSxJQUFPLHlDQUFQLE1BQU8sd0NBQXNDO01Ba0MzQjtNQWpDWCx5QkFBeUI7TUFDekIsaUJBQWlCO01BQ2pCLGVBQWU7TUFDZixVQUFVO01BQ1YsaUJBQWlCO01BQ2pCLFFBQVE7TUFFRDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0EsWUFBWTtNQUNaO01BRVQ7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BRVA7TUFHQSxtQkFBbUI7TUFFbkIsWUFBb0IsYUFBd0I7QUFBeEIsYUFBQSxjQUFBO01BQTJCO01BRS9DLFdBQVE7QUFDSixhQUFLLHFCQUFxQixLQUFLLFNBQVMsY0FBYyxDQUFBO0FBRXRELFlBQUksS0FBSyxTQUFTLE1BQU07QUFDcEIsZUFBSyxPQUFPLFFBQVEsS0FBSyxTQUFTLElBQUk7O0FBRzFDLGFBQUssc0JBQXNCLEtBQUssU0FBUyxTQUFTLGFBQWEsY0FBZSxLQUFLLFdBQW1DO0FBRXRILFlBQUksS0FBSyxNQUFNO0FBQ1gsZUFBSyxrQ0FBaUM7ZUFDbkM7QUFDSCxlQUFLLFVBQVUsbUJBQW1CLEtBQUssVUFBVSxLQUFLLG9CQUFvQjtBQUMxRSxlQUFLLG9CQUFvQixLQUFLLFNBQVMsWUFBWSxLQUFLLFNBQVMsVUFBVSxRQUFRLE1BQUssQ0FBRSxJQUFJLENBQUMsQ0FBQyxLQUFLLFNBQVMsYUFBYSxRQUFRLE1BQUssQ0FBRTtBQUMxSSxjQUFJLEtBQUssUUFBUSxzQkFBc0I7QUFDbkMsaUJBQUssNkJBQTZCLGlCQUFpQiw4QkFDL0MsS0FBSyxVQUNMLEtBQUssT0FBTyxzQkFDWixLQUFLLHNCQUFzQixTQUFTLEtBQUksR0FDeEMsS0FBSyxvQkFBb0I7O0FBSWpDLGVBQUsscUJBQ0QsQ0FBQyxDQUFDLEtBQUssc0JBQXNCLG1CQUM3QixDQUFDLEtBQUssK0JBQ0wsS0FBSyxTQUFTLDBDQUEwQyxLQUFLLFNBQVMsbUJBQW1CLGVBQWU7QUFFN0csZUFBSyxvQ0FBbUM7O0FBRzVDLFlBQUksS0FBSyxTQUFTO0FBQ2QsZUFBSyxxQkFBcUIsTUFBSyxFQUFHLFNBQVMsS0FBSyxPQUFPLElBQUksZUFBZTs7TUFFbEY7TUFFQSxjQUFXO0FBQ1AsYUFBSyxTQUFTLEtBQUssVUFBVSxzQkFBc0IsS0FBSyxRQUFRO0FBRWhFLFlBQUksS0FBSyxrQkFBa0IsUUFBUTtBQUMvQixlQUFLLGlCQUFnQjs7QUFFekIsWUFBSSxLQUFLLHNCQUFzQixTQUFTLFFBQVE7QUFFNUMsZUFBSyxZQUFZLGVBQWUsS0FBSyxxQkFBcUIsU0FBUyxNQUFNLEtBQUs7QUFFOUUsZ0JBQU0sb0JBQW9CLEtBQUsscUJBQXFCLFFBQVEsT0FBTyxDQUFDLFdBQVcsT0FBTyxLQUFLLEVBQUUsTUFBSztBQUNsRyxjQUFJLG1CQUFtQjtBQUNuQixpQkFBSyxpQkFBaUIsb0NBQXFDLGtCQUFrQixRQUFTLEtBQUssU0FBUyxZQUFjLEtBQUssS0FBSyxNQUFNOzs7TUFHOUk7TUFLUSxvQ0FBaUM7QUFDckMsY0FBTSxnQkFBZ0IsQ0FBQyxLQUFLLE1BQU0sU0FBUyxLQUFLLE1BQU0sa0JBQWtCO0FBQ3hFLGNBQU0sc0JBQXNCLENBQUMsV0FBVyxvQkFBb0I7QUFFNUQsYUFBSyxrQkFBa0IsZUFBZSxxQkFBcUIsTUFBSyxDQUFFO01BQ3RFO01BS1Esc0NBQW1DO0FBQ3ZDLGNBQU0sZ0JBQWdCLENBQUMsS0FBSyxTQUFTLGFBQWEsS0FBSyxTQUFTLFdBQVcsS0FBSyxTQUFTLG1CQUFtQixLQUFLLDBCQUEwQjtBQUMzSSxjQUFNLHNCQUFzQixDQUFDLGVBQWUsYUFBYSxpQkFBaUIsY0FBYztBQUV4RixhQUFLLGtCQUFrQixlQUFlLHFCQUFxQixNQUFLLENBQUU7TUFDdEU7TUFVUSxrQkFBa0IsT0FBb0MsWUFBc0IsS0FBZ0I7QUFDaEcsYUFBSyxtQkFBbUI7QUFDeEIsYUFBSyx3QkFBd0I7QUFDN0IsYUFBSyw4QkFBOEI7QUFFbkMsaUJBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7QUFDbkMsY0FBSSxNQUFNLENBQUMsS0FBSyxJQUFJLFNBQVMsTUFBTSxDQUFDLENBQUMsR0FBRztBQUNwQyxpQkFBSyxtQkFBbUIsTUFBTSxDQUFDO0FBQy9CLGlCQUFLLHdCQUF3QixXQUFXLENBQUM7QUFDekMsaUJBQUssOEJBQThCO0FBQ25DOzs7QUFHUixZQUFJLEtBQUssb0JBQW9CO0FBQ3pCOztBQUVKLGlCQUFTLElBQUksTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7QUFDeEMsY0FBSSxNQUFNLENBQUMsR0FBRztBQUNWLGdCQUFJLEtBQUssV0FBVyxLQUFLLFFBQVEsUUFBUSxNQUFNLENBQUMsQ0FBQyxHQUFHO0FBQ2hEOztBQUdKLGlCQUFLLG1CQUFtQixNQUFNLENBQUM7QUFDL0IsaUJBQUssd0JBQXdCLFdBQVcsQ0FBQztBQUN6QyxpQkFBSyw4QkFBOEI7QUFDbkM7OztNQUdaO01BRVEsbUJBQWdCO0FBQ3BCLGNBQU0sZ0JBQWdCLG9CQUFJLElBQUc7QUFFN0IsYUFBSyxzQkFBc0IsU0FDckIsSUFBSSxDQUFDLFdBQVcsT0FBTyxVQUFVLEVBQ2xDLE9BQU8sQ0FBQyxlQUFlLFlBQVksU0FBSSxRQUEwQixFQUNqRSxJQUFJLENBQUMsZUFBZ0IsV0FBcUMsVUFBVSxFQUNwRSxRQUFRLENBQUMsZUFBdUIsY0FBYyxJQUFJLFVBQVUsQ0FBQztBQUVsRSxhQUFLLHNCQUFzQixjQUFjO01BQzdDOzt5QkE3SlMseUNBQXNDLGdDQUFBLFdBQUEsQ0FBQTtNQUFBO2lFQUF0Qyx5Q0FBc0MsV0FBQSxDQUFBLENBQUEsdUNBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsc0JBQUEsd0JBQUEsT0FBQSxTQUFBLE1BQUEsUUFBQSxRQUFBLFVBQUEsV0FBQSxhQUFBLGtCQUFBLG1CQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUFBLEdBQUEsb0JBQUEsS0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLE1BQUEsbUJBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFlBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSx1QkFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsR0FBQSx3QkFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxXQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLGNBQUEsR0FBQSxZQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsZ0RBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7O0FDeEJuRCxVQUFBLHlCQUFBLEdBQUEsK0RBQUEsSUFBQSxDQUFBOzs7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxXQUFBLElBQUEsRUFBQTs7Ozs7cUZEd0JhLHdDQUFzQyxFQUFBLFdBQUEseUNBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFeEJuRCxTQUFTLGFBQUFDLFlBQVcsU0FBQUMsUUFBMEIseUJBQXlCO0FBQ3ZFLE9BQU9DLFlBQVc7Ozs7O0FDUU0sSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUF5RCxJQUFBLHFCQUFBLENBQUE7O0FBQThCLElBQUEsMkJBQUE7QUFDM0YsSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLE9BQUEsbUJBQUE7QUFBbUQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsT0FBQSxPQUFBLENBQUE7Ozs7O0FBT3JELElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQW9GLElBQUEscUJBQUEsQ0FBQTtBQUF1QixJQUFBLDJCQUFBO0FBQy9HLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7QUFGNEMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLDhCQUFBLEdBQUFDLE1BQUEsWUFBQSxLQUFBLENBQUE7QUFBZ0QsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxZQUFBLFFBQUE7Ozs7O0FBSmhHLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQTJCLElBQUEscUJBQUEsQ0FBQTs7QUFBK0UsSUFBQSwyQkFBQTtBQUMxRyxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLCtCQUFBLEdBQUEsOEVBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSx1Q0FBQTtBQUtKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUFQbUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsc0RBQUEsQ0FBQTtBQUMzQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsa0JBQUE7Ozs7O0FBa0JnQixJQUFBLHFCQUFBLENBQUE7Ozs7O0FBQUEsSUFBQSxpQ0FBQSw4Q0FBQSxRQUFBLGlCQUFBLDBCQUFBLEdBQUEsR0FBQSw4Q0FBQSxHQUFBLHdDQUFBOzs7OztBQUlBLElBQUEscUJBQUEsR0FBQSw0Q0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBOztBQUF1RyxJQUFBLDJCQUFBO0FBQ2pILElBQUEscUJBQUEsR0FBQSx3Q0FBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSwwQkFBQSxHQUFBLEdBQUEsaURBQUEsR0FBQSxLQUFBLFFBQUEsU0FBQSxhQUFBLEdBQUE7Ozs7O0FBSVYsSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLHdCQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7Ozs7QUFEdUMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLFFBQUEsUUFBQTs7Ozs7QUFHbkMsSUFBQSxxQkFBQSxHQUFBLHdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLCtCQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7Ozs7QUFEOEMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSwwQkFBQSxRQUFBLFNBQUEsc0JBQUE7Ozs7O0FBbEJ0RCxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUFzQixJQUFBLHFCQUFBLENBQUE7O0FBQTJFLElBQUEsMkJBQUE7QUFDckcsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0NBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsdUZBQUEsR0FBQSxDQUFBO0FBR0EsSUFBQSxxQkFBQSxFQUFBO0FBQ0EsSUFBQSx5QkFBQSxJQUFBLHVGQUFBLEdBQUEsQ0FBQTtBQUdKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsdUZBQUEsR0FBQSxDQUFBLEVBRUMsSUFBQSx1RkFBQSxHQUFBLENBQUE7QUFJTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTs7OztBQXBCa0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsa0RBQUEsQ0FBQTtBQUlsQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxtQkFBQSxTQUFBLEtBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMENBQUEsT0FBQSxTQUFBLFdBQUEsd0NBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxTQUFBLGNBQUEsS0FBQSxFQUFBO0FBSUosSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsU0FBQSxhQUFBLEtBQUEsRUFBQTtBQUdBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLFNBQUEsMEJBQUEsT0FBQSxTQUFBLDBCQUFBLE9BQUEsdUJBQUEsc0JBQUEsS0FBQSxFQUFBOzs7OztBQU9SLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQXNCLElBQUEscUJBQUEsQ0FBQTs7QUFBaUUsSUFBQSwyQkFBQTtBQUMzRixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsRUFBQTs7QUFBeUQsSUFBQSwyQkFBQTtBQUMvRCxJQUFBLHFCQUFBLElBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQXlELElBQUEscUJBQUEsRUFBQTs7QUFBaUQsSUFBQSwyQkFBQTtBQUM5RyxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTs7OztBQVBrQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLElBQUEsMEJBQUEsR0FBQSxHQUFBLHVDQUFBLEdBQUEsR0FBQTtBQUdoQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLElBQUEsR0FBQSxPQUFBLFNBQUEsaUJBQUEsS0FBQSxLQUFBO0FBQ0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLE9BQUEsbUJBQUE7QUFBbUQsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxJQUFBLEdBQUEsT0FBQSxTQUFBLGlCQUFBLENBQUE7Ozs7O0FBUXJFLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsZ0NBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7Ozs7QUFGc0MsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLE9BQUEsUUFBQSxFQUFxQix3QkFBQSxPQUFBLGFBQUE7Ozs7O0FBaEV2RSxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUFzQixJQUFBLDJCQUFBLENBQUE7QUFBOEMsSUFBQSwyQkFBQTtBQUNwRSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUFnQyxJQUFBLHFCQUFBLEVBQUE7O0FBQTRFLElBQUEsMkJBQUE7QUFDNUcsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEVBQUE7O0FBQXNDLElBQUEsMkJBQUE7QUFDNUMsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLHdFQUFBLEdBQUEsQ0FBQTtBQUdKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsd0VBQUEsSUFBQSxDQUFBO0FBVUosSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsU0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLHdFQUFBLElBQUEsQ0FBQSxFQXVCQyxJQUFBLHdFQUFBLElBQUEsRUFBQTtBQVlMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSx3RUFBQSxHQUFBLENBQUE7QUFLQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQSxJQUFBLENBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxJQUFBOzs7O0FBcEVvRCxJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLElBQUEsR0FBQSxtREFBQSxDQUFBO0FBQzFCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxLQUFBLEtBQUE7QUFDTixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxVQUFBLEtBQUEsRUFBQTtBQUlKLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLFNBQUEsYUFBQSxLQUFBLEVBQUE7QUFhSSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxTQUFBLFlBQUEsS0FBQSxFQUFBO0FBd0JBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLFNBQUEsb0JBQUEsS0FBQSxFQUFBO0FBY0osSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsaUJBQUEsT0FBQSxtQkFBQSxLQUFBLEVBQUE7OztBRC9EaEIsc0JBZWE7QUFmYjs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOzs7Ozs7Ozs7O0FBUU0sSUFBTyxtQ0FBUCxNQUFPLGtDQUFnQztNQUNoQyxhQUFhO01BQ2IseUJBQXlCO01BQ3pCO01BQ0E7TUFDQTtNQUVGLHNCQUFzQjtNQUN0QjtNQUNBO01BRVA7TUFDQSxVQUFVO01BS1YsV0FBUTtBQUNKLGFBQUssWUFBVztNQUNwQjtNQUtBLElBQUksbUJBQWdCO0FBQ2hCLFlBQUksS0FBSyxVQUFVLGVBQWUsTUFBTTtBQUNwQyxjQUFJLEtBQUssU0FBUyxjQUFjLEtBQUssb0JBQW9CO0FBQ3JELG1CQUFPRCxPQUFLLEVBQUcsUUFBUSxLQUFLLFNBQVMsY0FBYyxLQUFLLGtCQUFrQjs7QUFHOUUsaUJBQU87O0FBRVgsZUFBTztNQUNYO01BS0EsY0FBVztBQUNQLFlBQUksS0FBSyxVQUFVO0FBQ2YsZUFBSyxzQkFBc0IseUJBQXlCLEtBQUssVUFBVSxLQUFLLGFBQWEsSUFBSSxjQUFjO0FBQ3ZHLGVBQUsscUJBQXFCLEtBQUssU0FBUyxjQUFjLENBQUE7QUFDdEQsZUFBSyxVQUFVLG1CQUFtQixLQUFLLFVBQVUsS0FBSyxhQUFhO0FBQ25FLGNBQUksS0FBSyxlQUFlLFVBQVUsQ0FBQyxHQUFHLE9BQU87QUFDekMsaUJBQUssaUJBQWlCLG9DQUVqQixLQUFLLGNBQWMsVUFBVSxDQUFDLEVBQUUsUUFBUyxLQUFLLFNBQVMsWUFBYyxLQUN0RSxzQkFBc0IsS0FBSyxRQUFRLENBQUM7OztNQUlwRDs7eUJBbkRTLG1DQUFnQztNQUFBO2lFQUFoQyxtQ0FBZ0MsV0FBQSxDQUFBLENBQUEsK0JBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxPQUFBLFNBQUEsVUFBQSxZQUFBLGVBQUEsZ0JBQUEsR0FBQSxVQUFBLENBQUEsa0NBQUEsR0FBQSxvQkFBQUUsTUFBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLE1BQUEsd0JBQUEsR0FBQSxtQkFBQSxnQ0FBQSxHQUFBLENBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsYUFBQSxZQUFBLFVBQUEsZUFBQSx3QkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsb0JBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxRQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxlQUFBLG9CQUFBLFlBQUEsUUFBQSxXQUFBLFVBQUEsZUFBQSwwQkFBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSx3QkFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLGVBQUEsa0JBQUEsWUFBQSxRQUFBLFdBQUEsVUFBQSxlQUFBLDBCQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxRQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLGNBQUEsUUFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLHdCQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsUUFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxzQkFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDBDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBOztBQ2Y3QyxVQUFBLHlCQUFBLEdBQUEseURBQUEsSUFBQSxFQUFBOzs7QUFBQSxVQUFBLDRCQUFBLEdBQUEsSUFBQSxXQUFBLElBQUEsRUFBQTs7Ozs7cUZEZWEsa0NBQWdDLEVBQUEsV0FBQSxtQ0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVmN0MsU0FBUyxZQUFBQyxpQkFBZ0I7O0FBQXpCLElBYWE7QUFiYjs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFPTSxJQUFPLDZDQUFQLE1BQU8sNENBQTBDOzt5QkFBMUMsNkNBQTBDO01BQUE7Z0VBQTFDLDRDQUEwQyxDQUFBO29FQUp6QyxxQkFBcUIsOEJBQThCLDhCQUE4Qix3QkFBd0IsRUFBQSxDQUFBOzs7OyIsIm5hbWVzIjpbIlN1Ym1pc3Npb25Qb2xpY3lUeXBlIiwiQ29tcG9uZW50IiwiSW5wdXQiLCJkYXlqcyIsIl9jMCIsIl9jMiIsIk5nTW9kdWxlIl19