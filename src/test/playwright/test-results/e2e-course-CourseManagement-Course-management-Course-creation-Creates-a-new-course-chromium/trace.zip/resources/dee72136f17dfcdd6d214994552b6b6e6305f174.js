import {
  init_fullscreen_util,
  isFullScreen
} from "/chunk-KPWFZEYZ.js";
import {
  GuidedTourService,
  associationUML,
  init_guided_tour_service,
  init_guided_tour_task_model,
  personUML,
  studentUML
} from "/chunk-ORYTP7RT.js";
import {
  MAX_SUBMISSION_TEXT_LENGTH,
  init_input_constants
} from "/chunk-HFO42WCR.js";
import {
  ArtemisSharedModule,
  TranslateDirective,
  __esm,
  init_shared_module,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/constants/modeling.constants.ts
var MODELING_EDITOR_MIN_WIDTH, MODELING_EDITOR_MAX_WIDTH, MODELING_EDITOR_MIN_HEIGHT, MODELING_EDITOR_MAX_HEIGHT;
var init_modeling_constants = __esm({
  "src/main/webapp/app/shared/constants/modeling.constants.ts"() {
    MODELING_EDITOR_MIN_WIDTH = 15;
    MODELING_EDITOR_MAX_WIDTH = 2500;
    MODELING_EDITOR_MIN_HEIGHT = 750;
    MODELING_EDITOR_MAX_HEIGHT = 1e4;
  }
});

// src/main/webapp/app/exercises/modeling/shared/modeling.component.ts
import { Component, ElementRef, Input, ViewChild } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faGripLines, faGripLinesVertical } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { UMLDiagramType } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ls1intum_apollon.js?v=1d0d9ead";
import __vite__cjsImport7_interactjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/interactjs.js?v=1d0d9ead"; const interact = __vite__cjsImport7_interactjs.__esModule ? __vite__cjsImport7_interactjs.default : __vite__cjsImport7_interactjs;
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var _c0, _c1, ModelingComponent;
var init_modeling_component = __esm({
  "src/main/webapp/app/exercises/modeling/shared/modeling.component.ts"() {
    init_modeling_constants();
    _c0 = ["editorContainer"];
    _c1 = ["resizeContainer"];
    ModelingComponent = class _ModelingComponent {
      editorContainer;
      resizeContainer;
      resizeOptions;
      umlModel;
      diagramType;
      explanation;
      readOnly = false;
      apollonEditor;
      faGripLines = faGripLines;
      faGripLinesVertical = faGripLinesVertical;
      constructor() {
      }
      setupInteract() {
        if (this.resizeOptions) {
          interact(".resizable").resizable({
            edges: { left: false, right: this.resizeOptions.horizontalResize && ".draggable-right", bottom: this.resizeOptions.verticalResize, top: false },
            modifiers: [
              interact.modifiers.restrictSize({
                min: { width: MODELING_EDITOR_MIN_WIDTH, height: MODELING_EDITOR_MIN_HEIGHT },
                max: { width: MODELING_EDITOR_MAX_WIDTH, height: MODELING_EDITOR_MAX_HEIGHT }
              })
            ],
            inertia: true
          }).on("resizestart", function(event) {
            event.target.classList.add("card-resizable");
          }).on("resizeend", function(event) {
            event.target.classList.remove("card-resizable");
          }).on("resizemove", (event) => {
            const target = event.target;
            if (this.resizeOptions.horizontalResize) {
              target.style.width = event.rect.width + "px";
            }
            if (this.resizeOptions.verticalResize) {
              target.style.height = event.rect.height + "px";
            }
          });
        }
      }
      static \u0275fac = function ModelingComponent_Factory(t) {
        return new (t || _ModelingComponent)();
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _ModelingComponent, selectors: [["ng-component"]], viewQuery: function ModelingComponent_Query(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275viewQuery(_c0, 5);
          i0.\u0275\u0275viewQuery(_c1, 5);
        }
        if (rf & 2) {
          let _t;
          i0.\u0275\u0275queryRefresh(_t = i0.\u0275\u0275loadQuery()) && (ctx.editorContainer = _t.first);
          i0.\u0275\u0275queryRefresh(_t = i0.\u0275\u0275loadQuery()) && (ctx.resizeContainer = _t.first);
        }
      }, inputs: { resizeOptions: "resizeOptions", umlModel: "umlModel", diagramType: "diagramType", explanation: "explanation", readOnly: "readOnly" }, decls: 0, vars: 0, template: function ModelingComponent_Template(rf, ctx) {
      }, encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(ModelingComponent, { className: "ModelingComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/modeling/shared/modeling-explanation-editor.component.ts
import { Component as Component2, EventEmitter, Input as Input2, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
var ModelingExplanationEditorComponent;
var init_modeling_explanation_editor_component = __esm({
  "src/main/webapp/app/exercises/modeling/shared/modeling-explanation-editor.component.ts"() {
    init_input_constants();
    init_translate_directive();
    ModelingExplanationEditorComponent = class _ModelingExplanationEditorComponent {
      readOnly = false;
      explanation;
      explanationChange = new EventEmitter();
      maxCharacterCount = MAX_SUBMISSION_TEXT_LENGTH;
      onTextEditorTab(editor, event) {
        event.preventDefault();
        const value = editor.value;
        const start = editor.selectionStart;
        const end = editor.selectionEnd;
        editor.value = value.substring(0, start) + "	" + value.substring(end);
        editor.selectionStart = editor.selectionEnd = start + 1;
      }
      onExplanationInput(newValue) {
        this.explanationChange.emit(newValue);
      }
      static \u0275fac = function ModelingExplanationEditorComponent_Factory(t) {
        return new (t || _ModelingExplanationEditorComponent)();
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _ModelingExplanationEditorComponent, selectors: [["jhi-modeling-explanation-editor"]], inputs: { readOnly: "readOnly", explanation: "explanation" }, outputs: { explanationChange: "explanationChange" }, decls: 6, vars: 3, consts: [["for", "explanationText", "jhiTranslate", "artemisApp.modelingSubmission.explanationText"], ["id", "explanationText", 1, "text-editor-textarea", 3, "maxLength", "ngModel", "readOnly", "ngModelChange", "keydown.tab"], ["textEditor", ""]], template: function ModelingExplanationEditorComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = i02.\u0275\u0275getCurrentView();
          i02.\u0275\u0275elementStart(0, "label", 0);
          i02.\u0275\u0275text(1, "Explanation");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(2, "\n");
          i02.\u0275\u0275elementStart(3, "textarea", 1, 2);
          i02.\u0275\u0275listener("ngModelChange", function ModelingExplanationEditorComponent_Template_textarea_ngModelChange_3_listener($event) {
            return ctx.explanation = $event;
          })("keydown.tab", function ModelingExplanationEditorComponent_Template_textarea_keydown_tab_3_listener($event) {
            i02.\u0275\u0275restoreView(_r1);
            const _r0 = i02.\u0275\u0275reference(4);
            return i02.\u0275\u0275resetView(ctx.onTextEditorTab(_r0, $event));
          })("ngModelChange", function ModelingExplanationEditorComponent_Template_textarea_ngModelChange_3_listener($event) {
            return ctx.onExplanationInput($event);
          });
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(5, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275property("maxLength", ctx.maxCharacterCount)("ngModel", ctx.explanation)("readOnly", ctx.readOnly);
        }
      }, dependencies: [i1.DefaultValueAccessor, i1.NgControlStatus, i1.NgModel, TranslateDirective], styles: ["\n\n[_nghost-%COMP%] {\n  margin-top: 15px;\n}\n.text-editor-textarea[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 200px;\n  padding: 10px 12px;\n  border: 1px solid var(--text-editor-border-color);\n  border-radius: 2px;\n  background-color: var(--text-editor-background);\n  color: var(--text-editor-color);\n  resize: none;\n}\n.text-editor-textarea[_ngcontent-%COMP%]:focus {\n  outline: none;\n  border: 1px solid var(--artemis-dark);\n  background-color: var(--text-editor-focus-background);\n  box-shadow: 0 0 20px rgba(0, 0, 200, 0.04);\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvbW9kZWxpbmcvc2hhcmVkL21vZGVsaW5nLWV4cGxhbmF0aW9uLWVkaXRvci5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiJHRleHRhcmVhSGVpZ2h0OiAyMDBweDtcblxuOmhvc3Qge1xuICAgIG1hcmdpbi10b3A6IDE1cHg7XG59XG5cbi50ZXh0LWVkaXRvci10ZXh0YXJlYSB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAkdGV4dGFyZWFIZWlnaHQ7XG4gICAgcGFkZGluZzogMTBweCAxMnB4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLXRleHQtZWRpdG9yLWJvcmRlci1jb2xvcik7XG4gICAgYm9yZGVyLXJhZGl1czogMnB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXRleHQtZWRpdG9yLWJhY2tncm91bmQpO1xuICAgIGNvbG9yOiB2YXIoLS10ZXh0LWVkaXRvci1jb2xvcik7XG4gICAgcmVzaXplOiBub25lO1xuXG4gICAgJjpmb2N1cyB7XG4gICAgICAgIG91dGxpbmU6IG5vbmU7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWFydGVtaXMtZGFyayk7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXRleHQtZWRpdG9yLWZvY3VzLWJhY2tncm91bmQpO1xuICAgICAgICBib3gtc2hhZG93OiAwIDAgMjBweCByZ2JhKDAsIDAsIDIwMCwgMC4wNCk7XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUVBO0FBQ0ksY0FBQTs7QUFHSixDQUFBO0FBQ0ksU0FBQTtBQUNBLFVBUmE7QUFTYixXQUFBLEtBQUE7QUFDQSxVQUFBLElBQUEsTUFBQSxJQUFBO0FBQ0EsaUJBQUE7QUFDQSxvQkFBQSxJQUFBO0FBQ0EsU0FBQSxJQUFBO0FBQ0EsVUFBQTs7QUFFQSxDQVZKLG9CQVVJO0FBQ0ksV0FBQTtBQUNBLFVBQUEsSUFBQSxNQUFBLElBQUE7QUFDQSxvQkFBQSxJQUFBO0FBQ0EsY0FBQSxFQUFBLEVBQUEsS0FBQSxLQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBOzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(ModelingExplanationEditorComponent, { className: "ModelingExplanationEditorComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/modeling/shared/modeling-editor.component.ts
import { Component as Component3, EventEmitter as EventEmitter2, Input as Input3, Output as Output2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ApollonEditor, ApollonMode, UMLDiagramType as UMLDiagramType2, UMLElementType, UMLRelationshipType } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ls1intum_apollon.js?v=1d0d9ead";
import { NgbModal } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { faCheck, faCircleNotch, faTimes } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { faQuestionCircle } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function ModelingEditorComponent_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275elementStart(1, "div", 6);
    i03.\u0275\u0275text(2, "\n            ");
    i03.\u0275\u0275elementStart(3, "h4", 7);
    i03.\u0275\u0275text(4, "How to use the modeling editor");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n            ");
    i03.\u0275\u0275elementStart(6, "button", 8);
    i03.\u0275\u0275listener("click", function ModelingEditorComponent_ng_template_2_Template_button_click_6_listener() {
      const restoredCtx = i03.\u0275\u0275restoreView(_r11);
      const dismiss_r9 = restoredCtx.dismiss;
      return i03.\u0275\u0275resetView(dismiss_r9());
    });
    i03.\u0275\u0275element(7, "span", 9);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(9, "\n        ");
    i03.\u0275\u0275elementStart(10, "div", 10);
    i03.\u0275\u0275text(11, "\n            ");
    i03.\u0275\u0275elementStart(12, "table", 11);
    i03.\u0275\u0275text(13, "\n                ");
    i03.\u0275\u0275elementStart(14, "tr");
    i03.\u0275\u0275text(15, "\n                    ");
    i03.\u0275\u0275elementStart(16, "th", 12);
    i03.\u0275\u0275text(17, "Add Class");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(18, "\n                    ");
    i03.\u0275\u0275elementStart(19, "td", 13);
    i03.\u0275\u0275text(20, "\n                        To add a class, simply drag and drop one of the elements on the right side into the editor area on the left side.\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(21, "\n                    ");
    i03.\u0275\u0275elementStart(22, "td");
    i03.\u0275\u0275element(23, "img", 14);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(24, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(25, "\n                ");
    i03.\u0275\u0275elementStart(26, "tr");
    i03.\u0275\u0275text(27, "\n                    ");
    i03.\u0275\u0275elementStart(28, "th", 15);
    i03.\u0275\u0275text(29, "Add Association");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(30, "\n                    ");
    i03.\u0275\u0275elementStart(31, "td", 16);
    i03.\u0275\u0275text(32, "\n                        To add an association, select the source class with a single click and you will see four blue circles. Those are the possible connection points for\n                        associations. Click and hold on one of those and drag it to another blue circle to create an association.\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(33, "\n                    ");
    i03.\u0275\u0275elementStart(34, "td");
    i03.\u0275\u0275element(35, "img", 17);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(36, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(37, "\n                ");
    i03.\u0275\u0275elementStart(38, "tr");
    i03.\u0275\u0275text(39, "\n                    ");
    i03.\u0275\u0275elementStart(40, "th", 18);
    i03.\u0275\u0275text(41, "Edit Class");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(42, "\n                    ");
    i03.\u0275\u0275elementStart(43, "td", 19);
    i03.\u0275\u0275text(44, "\n                        To edit a class, double click it and a popup will open up, in which you can edit its components, e.g. name, attributes, methods, etc.\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(45, "\n                    ");
    i03.\u0275\u0275elementStart(46, "td");
    i03.\u0275\u0275element(47, "img", 20);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(48, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(49, "\n                ");
    i03.\u0275\u0275elementStart(50, "tr");
    i03.\u0275\u0275text(51, "\n                    ");
    i03.\u0275\u0275elementStart(52, "th", 21);
    i03.\u0275\u0275text(53, "Delete Class");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(54, "\n                    ");
    i03.\u0275\u0275elementStart(55, "td", 22);
    i03.\u0275\u0275text(56, "\n                        To delete a class, select it with a single click and either press ");
    i03.\u0275\u0275elementStart(57, "code");
    i03.\u0275\u0275text(58, "Delete");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(59, " or ");
    i03.\u0275\u0275elementStart(60, "code");
    i03.\u0275\u0275text(61, "Backspace");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(62, " on your keyboard.\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(63, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(64, "\n                ");
    i03.\u0275\u0275elementStart(65, "tr");
    i03.\u0275\u0275text(66, "\n                    ");
    i03.\u0275\u0275elementStart(67, "th", 23);
    i03.\u0275\u0275text(68, "Move Class");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(69, "\n                    ");
    i03.\u0275\u0275elementStart(70, "td", 24);
    i03.\u0275\u0275text(71, "\n                        To move a class, select it with a single click and either use your keyboard arrows or drag and drop it.\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(72, "\n                    ");
    i03.\u0275\u0275elementStart(73, "td");
    i03.\u0275\u0275element(74, "img", 25);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(75, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(76, "\n                ");
    i03.\u0275\u0275elementStart(77, "tr");
    i03.\u0275\u0275text(78, "\n                    ");
    i03.\u0275\u0275elementStart(79, "th", 26);
    i03.\u0275\u0275text(80, "Move Class");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(81, "\n                    ");
    i03.\u0275\u0275elementStart(82, "td", 27);
    i03.\u0275\u0275text(83, "\n                        To move a class, select it with a single click and either use your keyboard arrows or drag and drop it.\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(84, "\n                    ");
    i03.\u0275\u0275elementStart(85, "td");
    i03.\u0275\u0275element(86, "img", 28);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(87, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(88, "\n                ");
    i03.\u0275\u0275elementStart(89, "tr");
    i03.\u0275\u0275text(90, "\n                    ");
    i03.\u0275\u0275elementStart(91, "th", 29);
    i03.\u0275\u0275text(92, "Move Class");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(93, "\n                    ");
    i03.\u0275\u0275elementStart(94, "td", 30);
    i03.\u0275\u0275text(95, "\n                        To move a class, select it with a single click and either use your keyboard arrows or drag and drop it.\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(96, "\n                    ");
    i03.\u0275\u0275elementStart(97, "td");
    i03.\u0275\u0275element(98, "img", 31);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(99, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(100, "\n                ");
    i03.\u0275\u0275elementStart(101, "tr");
    i03.\u0275\u0275text(102, "\n                    ");
    i03.\u0275\u0275elementStart(103, "th", 32);
    i03.\u0275\u0275text(104, "Undo & Redo");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(105, "\n                    ");
    i03.\u0275\u0275elementStart(106, "td", 33);
    i03.\u0275\u0275text(107, "\n                        With ");
    i03.\u0275\u0275elementStart(108, "code");
    i03.\u0275\u0275text(109, "Ctrl+Z");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(110, " and ");
    i03.\u0275\u0275elementStart(111, "code");
    i03.\u0275\u0275text(112, "Ctrl+Y");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(113, " you can undo and redo your changes.\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(114, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(115, "\n                ");
    i03.\u0275\u0275elementStart(116, "tr");
    i03.\u0275\u0275text(117, "\n                    ");
    i03.\u0275\u0275elementStart(118, "th", 34);
    i03.\u0275\u0275text(119, "Undo & Redo");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(120, "\n                    ");
    i03.\u0275\u0275elementStart(121, "td", 35);
    i03.\u0275\u0275text(122, "\n                        With ");
    i03.\u0275\u0275elementStart(123, "code");
    i03.\u0275\u0275text(124, "Ctrl+Z");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(125, " and ");
    i03.\u0275\u0275elementStart(126, "code");
    i03.\u0275\u0275text(127, "Ctrl+Y");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(128, " you can undo and redo your changes.\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(129, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(130, "\n                ");
    i03.\u0275\u0275elementStart(131, "tr");
    i03.\u0275\u0275text(132, "\n                    ");
    i03.\u0275\u0275elementStart(133, "th", 36);
    i03.\u0275\u0275text(134, "Undo & Redo");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(135, "\n                    ");
    i03.\u0275\u0275elementStart(136, "td", 37);
    i03.\u0275\u0275text(137, "\n                        With ");
    i03.\u0275\u0275elementStart(138, "code");
    i03.\u0275\u0275text(139, "Ctrl+Z");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(140, " and ");
    i03.\u0275\u0275elementStart(141, "code");
    i03.\u0275\u0275text(142, "Ctrl+Y");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(143, " you can undo and redo your changes.\n                    ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(144, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(145, "\n            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(146, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(147, "\n        ");
    i03.\u0275\u0275elementStart(148, "div", 38);
    i03.\u0275\u0275text(149, "\n            ");
    i03.\u0275\u0275elementStart(150, "button", 39);
    i03.\u0275\u0275listener("click", function ModelingEditorComponent_ng_template_2_Template_button_click_150_listener() {
      const restoredCtx = i03.\u0275\u0275restoreView(_r11);
      const close_r8 = restoredCtx.close;
      return i03.\u0275\u0275resetView(close_r8());
    });
    i03.\u0275\u0275text(151, "Close");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(152, "\n        ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(153, "\n    ");
  }
}
function ModelingEditorComponent_Conditional_5_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275elementStart(1, "button", 41);
    i03.\u0275\u0275listener("click", function ModelingEditorComponent_Conditional_5_Conditional_3_Template_button_click_1_listener() {
      i03.\u0275\u0275restoreView(_r18);
      const ctx_r17 = i03.\u0275\u0275nextContext(2);
      const _r1 = i03.\u0275\u0275reference(3);
      return i03.\u0275\u0275resetView(ctx_r17.open(_r1));
    });
    i03.\u0275\u0275text(2, "\n                    ");
    i03.\u0275\u0275element(3, "fa-icon", 42);
    i03.\u0275\u0275text(4, "\xA0\n                    ");
    i03.\u0275\u0275elementStart(5, "span", 43);
    i03.\u0275\u0275text(6, "Help");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(7, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n            ");
  }
  if (rf & 2) {
    const ctx_r13 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("icon", ctx_r13.farQuestionCircle);
  }
}
function ModelingEditorComponent_Conditional_5_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275elementStart(1, "div", 44);
    i03.\u0275\u0275text(2, "\n                    ");
    i03.\u0275\u0275element(3, "fa-icon", 42);
    i03.\u0275\u0275text(4, "\n                    ");
    i03.\u0275\u0275elementStart(5, "span", 45);
    i03.\u0275\u0275text(6, "All changes saved");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(7, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n            ");
  }
  if (rf & 2) {
    const ctx_r14 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("icon", ctx_r14.faCheck);
  }
}
function ModelingEditorComponent_Conditional_5_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275elementStart(1, "div", 46);
    i03.\u0275\u0275text(2, "\n                    ");
    i03.\u0275\u0275element(3, "fa-icon", 42);
    i03.\u0275\u0275text(4, "\n                    ");
    i03.\u0275\u0275elementStart(5, "span", 47);
    i03.\u0275\u0275text(6, "Unsaved changes");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(7, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n            ");
  }
  if (rf & 2) {
    const ctx_r15 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("icon", ctx_r15.faTimes);
  }
}
function ModelingEditorComponent_Conditional_5_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275elementStart(1, "div", 48);
    i03.\u0275\u0275text(2, "\n                    ");
    i03.\u0275\u0275element(3, "fa-icon", 49);
    i03.\u0275\u0275text(4, "\n                    ");
    i03.\u0275\u0275elementStart(5, "span", 50);
    i03.\u0275\u0275text(6, "Saving...");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(7, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(8, "\n            ");
  }
  if (rf & 2) {
    const ctx_r16 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("icon", ctx_r16.faCircleNotch);
  }
}
function ModelingEditorComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275elementStart(1, "div", 40);
    i03.\u0275\u0275text(2, "\n            ");
    i03.\u0275\u0275template(3, ModelingEditorComponent_Conditional_5_Conditional_3_Template, 9, 1)(4, ModelingEditorComponent_Conditional_5_Conditional_4_Template, 9, 1)(5, ModelingEditorComponent_Conditional_5_Conditional_5_Template, 9, 1)(6, ModelingEditorComponent_Conditional_5_Conditional_6_Template, 9, 1);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(7, "\n    ");
  }
  if (rf & 2) {
    const ctx_r2 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275conditional(3, !ctx_r2.readOnly && ctx_r2.showHelpButton ? 3 : -1);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(4, ctx_r2.savedStatus && !ctx_r2.savedStatus.isChanged && !ctx_r2.savedStatus.isSaving ? 4 : -1);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(5, ctx_r2.savedStatus && ctx_r2.savedStatus.isChanged && !ctx_r2.savedStatus.isSaving ? 5 : -1);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275conditional(6, ctx_r2.savedStatus && ctx_r2.savedStatus.isSaving ? 6 : -1);
  }
}
function ModelingEditorComponent_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n            ");
    i03.\u0275\u0275elementStart(1, "div", 51);
    i03.\u0275\u0275text(2, "\n                ");
    i03.\u0275\u0275element(3, "fa-icon", 42);
    i03.\u0275\u0275text(4, "\n            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r5 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("icon", ctx_r5.faGripLinesVertical);
  }
}
function ModelingEditorComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n            ");
    i03.\u0275\u0275elementStart(1, "div", 52);
    i03.\u0275\u0275text(2, "\n                ");
    i03.\u0275\u0275element(3, "fa-icon", 42);
    i03.\u0275\u0275text(4, "\n            ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r6 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("icon", ctx_r6.faGripLines);
  }
}
function ModelingEditorComponent_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n        ");
    i03.\u0275\u0275elementStart(1, "jhi-modeling-explanation-editor", 53);
    i03.\u0275\u0275listener("explanationChange", function ModelingEditorComponent_Conditional_15_Template_jhi_modeling_explanation_editor_explanationChange_1_listener($event) {
      i03.\u0275\u0275restoreView(_r20);
      const ctx_r19 = i03.\u0275\u0275nextContext();
      return i03.\u0275\u0275resetView(ctx_r19.onExplanationInput($event));
    });
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(2, "\n    ");
  }
  if (rf & 2) {
    const ctx_r7 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("explanation", ctx_r7.explanation)("readOnly", ctx_r7.readOnly);
  }
}
var _c02, ModelingEditorComponent;
var init_modeling_editor_component = __esm({
  "src/main/webapp/app/exercises/modeling/shared/modeling-editor.component.ts"() {
    init_guided_tour_task_model();
    init_guided_tour_service();
    init_fullscreen_util();
    init_modeling_component();
    init_guided_tour_service();
    init_translate_directive();
    init_modeling_explanation_editor_component();
    _c02 = (a0) => ({ marginTop: a0 });
    ModelingEditorComponent = class _ModelingEditorComponent extends ModelingComponent {
      modalService;
      guidedTourService;
      showHelpButton = true;
      withExplanation = false;
      savedStatus;
      onModelChanged = new EventEmitter2();
      explanationChange = new EventEmitter2();
      modelSubscription;
      faCheck = faCheck;
      faTimes = faTimes;
      faCircleNotch = faCircleNotch;
      farQuestionCircle = faQuestionCircle;
      htmlScroll = 0;
      mouseDownListener;
      scrollListener;
      constructor(modalService, guidedTourService) {
        super();
        this.modalService = modalService;
        this.guidedTourService = guidedTourService;
      }
      ngAfterViewInit() {
        this.initializeApollonEditor();
        this.guidedTourService.checkModelingComponent().subscribe((key) => {
          if (key) {
            this.assessModelForGuidedTour(key, this.getCurrentModel());
          }
        });
        this.setupInteract();
        this.setupSafariScrollFix();
      }
      initializeApollonEditor() {
        if (this.apollonEditor) {
          this.apollonEditor.unsubscribeFromModelChange(this.modelSubscription);
          this.apollonEditor.destroy();
        }
        _ModelingEditorComponent.removeAssessments(this.umlModel);
        if (this.editorContainer) {
          this.apollonEditor = new ApollonEditor(this.editorContainer.nativeElement, {
            model: this.umlModel,
            mode: ApollonMode.Modelling,
            readonly: this.readOnly,
            type: this.diagramType || UMLDiagramType2.ClassDiagram,
            scale: 0.8
          });
          this.modelSubscription = this.apollonEditor.subscribeToModelChange((model) => {
            this.onModelChanged.emit(model);
          });
        }
      }
      setupSafariScrollFix() {
        const isSafariDesktop = /Safari/i.test(navigator.userAgent) && /Apple Computer/.test(navigator.vendor) && !/Mobi|Android/i.test(navigator.userAgent);
        if (this.readOnly || !isSafariDesktop) {
          return;
        }
        console.log("Warning: Installing hack to prevent UI scroll jumps in Safari while using Apollon!");
        console.log("Warning: If you experience problems regarding the scrolling behavior, please report them at https://github.com/ls1intum/Artemis");
        this.mouseDownListener = () => {
          const newScroll = document.getElementsByTagName("html")[0].scrollTop;
          if (newScroll !== this.htmlScroll) {
            const copy = this.htmlScroll;
            requestAnimationFrame(() => window.scrollTo({ top: copy, left: 0, behavior: "instant" }));
          }
        };
        this.scrollListener = () => {
          this.htmlScroll = document.getElementsByTagName("html")[0].scrollTop;
        };
        document.addEventListener("mousedown", this.mouseDownListener);
        document.addEventListener("scroll", this.scrollListener);
      }
      get isApollonEditorMounted() {
        return this.apollonEditor != void 0;
      }
      static removeAssessments(umlModel) {
        if (umlModel) {
          umlModel.assessments = {};
        }
      }
      getCurrentModel() {
        const currentModel = this.apollonEditor.model;
        _ModelingEditorComponent.removeAssessments(currentModel);
        return currentModel;
      }
      open(content) {
        this.modalService.open(content, { size: "lg" });
      }
      ngOnChanges(changes) {
        if (changes.diagramType) {
          this.initializeApollonEditor();
        }
        if (changes.umlModel && changes.umlModel.currentValue && this.apollonEditor) {
          this.umlModel = changes.umlModel.currentValue;
          _ModelingEditorComponent.removeAssessments(this.umlModel);
          this.apollonEditor.model = this.umlModel;
        }
      }
      ngOnDestroy() {
        if (this.apollonEditor) {
          if (this.modelSubscription) {
            this.apollonEditor.unsubscribeFromModelChange(this.modelSubscription);
          }
          this.apollonEditor.destroy();
          this.apollonEditor = void 0;
        }
        if (this.mouseDownListener) {
          document.removeEventListener("mousedown", this.mouseDownListener);
          document.removeEventListener("scroll", this.scrollListener);
        }
      }
      assessModelForGuidedTour(umlName, umlModel) {
        const personClass = this.elementWithClass(personUML.name, umlModel);
        const studentClass = this.elementWithClass(studentUML.name, umlModel);
        let personStudentAssociation;
        switch (umlName) {
          case personUML.name: {
            const nameAttribute = this.elementWithAttribute(personUML.attribute, umlModel);
            const personClassCorrect = personClass && nameAttribute ? nameAttribute.owner === personClass.id : false;
            this.guidedTourService.updateModelingResult(umlName, personClassCorrect);
            break;
          }
          case studentUML.name: {
            const majorAttribute = this.elementWithAttribute(studentUML.attribute, umlModel);
            const visitLectureMethod = this.elementWithMethod(studentUML.method, umlModel);
            const studentClassCorrect = studentClass && majorAttribute && visitLectureMethod ? majorAttribute.owner === studentClass.id && visitLectureMethod.owner === studentClass.id : false;
            this.guidedTourService.updateModelingResult(umlName, studentClassCorrect);
            break;
          }
          case associationUML.name: {
            personStudentAssociation = Object.values(umlModel.relationships).find((relationship) => relationship.source.element === studentClass.id && relationship.target.element === personClass.id && relationship.type === UMLRelationshipType.ClassInheritance);
            this.guidedTourService.updateModelingResult(umlName, !!personStudentAssociation);
            break;
          }
        }
      }
      elementWithClass(name, umlModel) {
        return Object.values(umlModel.elements).find((element) => element.name.trim() === name && element.type === UMLElementType.Class);
      }
      elementWithAttribute(attribute, umlModel) {
        return Object.values(umlModel.elements).find((element) => element.name.includes(attribute) && element.type === UMLElementType.ClassAttribute);
      }
      elementWithMethod(method, umlModel) {
        return Object.values(umlModel.elements).find((element) => element.name.includes(method) && element.type === UMLElementType.ClassMethod);
      }
      get isFullScreen() {
        return isFullScreen();
      }
      onExplanationInput(newValue) {
        this.explanationChange.emit(newValue);
        this.explanation = newValue;
      }
      static \u0275fac = function ModelingEditorComponent_Factory(t) {
        return new (t || _ModelingEditorComponent)(i03.\u0275\u0275directiveInject(i12.NgbModal), i03.\u0275\u0275directiveInject(GuidedTourService));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _ModelingEditorComponent, selectors: [["jhi-modeling-editor"]], inputs: { showHelpButton: "showHelpButton", withExplanation: "withExplanation", savedStatus: "savedStatus" }, outputs: { onModelChanged: "onModelChanged", explanationChange: "explanationChange" }, features: [i03.\u0275\u0275InheritDefinitionFeature, i03.\u0275\u0275NgOnChangesFeature], decls: 17, vars: 9, consts: [[1, "guided-tour", "modeling-editor"], ["help", ""], [1, "modeling-editor", 3, "ngStyle"], ["resizeContainer", ""], [1, "apollon-container"], ["editorContainer", ""], [1, "modal-header"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.title", 1, "modal-title"], ["type", "button", "aria-label", "Close", 1, "btn-close", 3, "click"], ["aria-hidden", "true"], [1, "modal-body"], [1, "table"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.createElement.title"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.createElement.text"], ["width", "300", "src", "/content/images/help-create-element.png"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.createRelationship.title"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.createRelationship.text"], ["width", "300", "src", "/content/images/help-create-relationship.jpg"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.updateElement.title"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.updateElement.text"], ["width", "300", "src", "/content/images/help-update-element.jpg"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.deleteElement.title"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.deleteElement.text", "colspan", "2"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.moveElement.title"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.moveElement.text"], ["width", "300", "src", "/content/images/help-move-element.jpg"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.resizeElement.title"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.resizeElement.text"], ["width", "300", "src", "/content/images/help-resize-element.jpg"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.reconnectRelationship.title"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.reconnectRelationship.text"], ["width", "300", "src", "/content/images/help-reconnect-relationship.jpg"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.select.title"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.select.text", "colspan", "2"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.duplicate.title"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.duplicate.text", "colspan", "2"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.undo.title"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.undo.text", "colspan", "2"], [1, "modal-footer"], ["type", "button", "jhiTranslate", "entity.action.close", 1, "btn", "btn-outline", 3, "click"], [1, "help-and-status"], [1, "btn", "btn-warning", 3, "click"], [3, "icon"], ["jhiTranslate", "artemisApp.modelingEditor.helpModal.help"], [1, "status-hint", "text-success"], ["jhiTranslate", "artemisApp.modelingEditor.allSaved"], [1, "status-hint", "text-warning"], ["jhiTranslate", "artemisApp.modelingEditor.unsavedChanges"], [1, "status-hint", "text-info"], [1, "spin", 3, "icon"], ["jhiTranslate", "artemisApp.modelingEditor.saving"], [1, "draggable-right"], [1, "draggable-bottom"], [3, "explanation", "readOnly", "explanationChange"]], template: function ModelingEditorComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "div", 0);
          i03.\u0275\u0275text(1, "\n    ");
          i03.\u0275\u0275template(2, ModelingEditorComponent_ng_template_2_Template, 154, 0, "ng-template", null, 1, i03.\u0275\u0275templateRefExtractor);
          i03.\u0275\u0275text(4, "\n    ");
          i03.\u0275\u0275template(5, ModelingEditorComponent_Conditional_5_Template, 8, 4);
          i03.\u0275\u0275elementStart(6, "div", 2, 3);
          i03.\u0275\u0275text(8, "\n        ");
          i03.\u0275\u0275element(9, "div", 4, 5);
          i03.\u0275\u0275text(11, "\n        ");
          i03.\u0275\u0275template(12, ModelingEditorComponent_Conditional_12_Template, 6, 1)(13, ModelingEditorComponent_Conditional_13_Template, 6, 1);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(14, "\n    ");
          i03.\u0275\u0275template(15, ModelingEditorComponent_Conditional_15_Template, 3, 2);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(16, "\n");
        }
        if (rf & 2) {
          i03.\u0275\u0275advance(5);
          i03.\u0275\u0275conditional(5, !ctx.readOnly && !ctx.isFullScreen ? 5 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275classProp("resizable", ctx.resizeOptions);
          i03.\u0275\u0275property("ngStyle", i03.\u0275\u0275pureFunction1(7, _c02, ctx.isFullScreen ? "30px" : ""));
          i03.\u0275\u0275advance(6);
          i03.\u0275\u0275conditional(12, ctx.resizeOptions && ctx.resizeOptions.horizontalResize ? 12 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(13, ctx.resizeOptions && ctx.resizeOptions.verticalResize ? 13 : -1);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275conditional(15, ctx.withExplanation ? 15 : -1);
        }
      }, dependencies: [i3.NgStyle, i4.FaIconComponent, TranslateDirective, ModelingExplanationEditorComponent], styles: ["\n\n.modeling-editor[_ngcontent-%COMP%] {\n  position: relative;\n  height: 100%;\n  display: flex;\n  flex-flow: column nowrap;\n}\n.modeling-editor[_ngcontent-%COMP%]   .help-and-status[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: nowrap;\n  align-items: center;\n  margin-bottom: 5px;\n  gap: 20px;\n}\n.modeling-editor[_ngcontent-%COMP%]   .help-and-status[_ngcontent-%COMP%]   .spin[_ngcontent-%COMP%] {\n  display: inline-block;\n  animation: _ngcontent-%COMP%_spin 4s linear infinite;\n}\n@media screen and (max-width: 400px) {\n  .modeling-editor[_ngcontent-%COMP%]   .help-and-status[_ngcontent-%COMP%]   .status-hint[_ngcontent-%COMP%]    > span[_ngcontent-%COMP%] {\n    display: none;\n  }\n}\n.resizable[_ngcontent-%COMP%] {\n  display: flex;\n}\n.resizable[_ngcontent-%COMP%]   .draggable-right[_ngcontent-%COMP%], .resizable[_ngcontent-%COMP%]   .draggable-bottom[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  min-width: 15px;\n}\n.apollon-container[_ngcontent-%COMP%] {\n  height: 100%;\n  min-height: 750px;\n  overflow: hidden;\n}\n@keyframes _ngcontent-%COMP%_spin {\n  0% {\n    transform: rotate(0);\n  }\n  100% {\n    transform: rotate(360deg);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvbW9kZWxpbmcvc2hhcmVkL21vZGVsaW5nLWVkaXRvci5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiJGRyYWdnYWJsZS13aWR0aDogMTVweDtcblxuLm1vZGVsaW5nLWVkaXRvciB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZmxvdzogY29sdW1uIG5vd3JhcDtcblxuICAgIC5oZWxwLWFuZC1zdGF0dXMge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LXdyYXA6IG5vd3JhcDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgICAgICBnYXA6IDIwcHg7XG5cbiAgICAgICAgLnNwaW4ge1xuICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgICAgICAgICAgYW5pbWF0aW9uOiBzcGluIDRzIGxpbmVhciBpbmZpbml0ZTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDAwcHgpIHtcbiAgICAubW9kZWxpbmctZWRpdG9yIC5oZWxwLWFuZC1zdGF0dXMgLnN0YXR1cy1oaW50ID4gc3BhbiB7XG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgfVxufVxuXG4ucmVzaXphYmxlIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIC5kcmFnZ2FibGUtcmlnaHQsXG4gICAgLmRyYWdnYWJsZS1ib3R0b20ge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgbWluLXdpZHRoOiAkZHJhZ2dhYmxlLXdpZHRoO1xuICAgIH1cbn1cblxuLmFwb2xsb24tY29udGFpbmVyIHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWluLWhlaWdodDogNzUwcHg7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuQGtleWZyYW1lcyBzcGluIHtcbiAgICAwJSB7XG4gICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDApO1xuICAgIH1cbiAgICAxMDAlIHtcbiAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMzYwZGVnKTtcbiAgICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRUEsQ0FBQTtBQUNJLFlBQUE7QUFDQSxVQUFBO0FBQ0EsV0FBQTtBQUNBLGFBQUEsT0FBQTs7QUFFQSxDQU5KLGdCQU1JLENBQUE7QUFDSSxXQUFBO0FBQ0EsYUFBQTtBQUNBLGVBQUE7QUFDQSxpQkFBQTtBQUNBLE9BQUE7O0FBRUEsQ0FiUixnQkFhUSxDQVBKLGdCQU9JLENBQUE7QUFDSSxXQUFBO0FBQ0EsYUFBQSxLQUFBLEdBQUEsT0FBQTs7QUFLWixPQUFBLE9BQUEsSUFBQSxDQUFBLFNBQUEsRUFBQTtBQUNJLEdBckJKLGdCQXFCSSxDQWZBLGdCQWVBLENBQUEsWUFBQSxFQUFBO0FBQ0ksYUFBQTs7O0FBSVIsQ0FBQTtBQUNJLFdBQUE7O0FBQ0EsQ0FGSixVQUVJLENBQUE7QUFBQSxDQUZKLFVBRUksQ0FBQTtBQUVJLFdBQUE7QUFDQSxlQUFBO0FBQ0EsbUJBQUE7QUFDQSxhQW5DVTs7QUF1Q2xCLENBQUE7QUFDSSxVQUFBO0FBQ0EsY0FBQTtBQUNBLFlBQUE7O0FBR0osV0E5QlE7QUErQko7QUFDSSxlQUFBLE9BQUE7O0FBRUo7QUFDSSxlQUFBLE9BQUE7OzsiLAogICJuYW1lcyI6IFtdCn0K */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(ModelingEditorComponent, { className: "ModelingEditorComponent" });
    })();
  }
});

// src/main/webapp/app/exercises/modeling/shared/modeling-editor.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisModelingEditorModule;
var init_modeling_editor_module = __esm({
  "src/main/webapp/app/exercises/modeling/shared/modeling-editor.module.ts"() {
    init_modeling_editor_component();
    init_shared_module();
    init_modeling_explanation_editor_component();
    ArtemisModelingEditorModule = class _ArtemisModelingEditorModule {
      static \u0275fac = function ArtemisModelingEditorModule_Factory(t) {
        return new (t || _ArtemisModelingEditorModule)();
      };
      static \u0275mod = i04.\u0275\u0275defineNgModule({ type: _ArtemisModelingEditorModule });
      static \u0275inj = i04.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule] });
    };
  }
});

export {
  ModelingComponent,
  init_modeling_component,
  ModelingExplanationEditorComponent,
  init_modeling_explanation_editor_component,
  ModelingEditorComponent,
  init_modeling_editor_component,
  ArtemisModelingEditorModule,
  init_modeling_editor_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2NvbnN0YW50cy9tb2RlbGluZy5jb25zdGFudHMudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9tb2RlbGluZy9zaGFyZWQvbW9kZWxpbmcuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvbW9kZWxpbmcvc2hhcmVkL21vZGVsaW5nLWV4cGxhbmF0aW9uLWVkaXRvci5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9tb2RlbGluZy9zaGFyZWQvbW9kZWxpbmctZXhwbGFuYXRpb24tZWRpdG9yLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvbW9kZWxpbmcvc2hhcmVkL21vZGVsaW5nLWVkaXRvci5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2V4ZXJjaXNlcy9tb2RlbGluZy9zaGFyZWQvbW9kZWxpbmctZWRpdG9yLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9leGVyY2lzZXMvbW9kZWxpbmcvc2hhcmVkL21vZGVsaW5nLWVkaXRvci5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IE1PREVMSU5HX0VESVRPUl9NSU5fV0lEVEggPSAxNTtcbmV4cG9ydCBjb25zdCBNT0RFTElOR19FRElUT1JfTUFYX1dJRFRIID0gMjUwMDtcbmV4cG9ydCBjb25zdCBNT0RFTElOR19FRElUT1JfTUlOX0hFSUdIVCA9IDc1MDtcbmV4cG9ydCBjb25zdCBNT0RFTElOR19FRElUT1JfTUFYX0hFSUdIVCA9IDEwMDAwO1xuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBFbGVtZW50UmVmLCBJbnB1dCwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBmYUdyaXBMaW5lcywgZmFHcmlwTGluZXNWZXJ0aWNhbCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBBcG9sbG9uRWRpdG9yLCBVTUxEaWFncmFtVHlwZSwgVU1MTW9kZWwgfSBmcm9tICdAbHMxaW50dW0vYXBvbGxvbic7XG5pbXBvcnQgeyBNT0RFTElOR19FRElUT1JfTUFYX0hFSUdIVCwgTU9ERUxJTkdfRURJVE9SX01BWF9XSURUSCwgTU9ERUxJTkdfRURJVE9SX01JTl9IRUlHSFQsIE1PREVMSU5HX0VESVRPUl9NSU5fV0lEVEggfSBmcm9tICdhcHAvc2hhcmVkL2NvbnN0YW50cy9tb2RlbGluZy5jb25zdGFudHMnO1xuaW1wb3J0IGludGVyYWN0IGZyb20gJ2ludGVyYWN0anMnO1xuXG5AQ29tcG9uZW50KHsgdGVtcGxhdGU6ICcnIH0pXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgTW9kZWxpbmdDb21wb25lbnQge1xuICAgIEBWaWV3Q2hpbGQoJ2VkaXRvckNvbnRhaW5lcicsIHsgc3RhdGljOiBmYWxzZSB9KSBlZGl0b3JDb250YWluZXI6IEVsZW1lbnRSZWY7XG4gICAgQFZpZXdDaGlsZCgncmVzaXplQ29udGFpbmVyJywgeyBzdGF0aWM6IGZhbHNlIH0pIHJlc2l6ZUNvbnRhaW5lcjogRWxlbWVudFJlZjtcbiAgICBASW5wdXQoKSByZXNpemVPcHRpb25zOiB7IGhvcml6b250YWxSZXNpemU/OiBib29sZWFuOyB2ZXJ0aWNhbFJlc2l6ZT86IGJvb2xlYW4gfTtcbiAgICBASW5wdXQoKSB1bWxNb2RlbDogVU1MTW9kZWw7XG4gICAgQElucHV0KCkgZGlhZ3JhbVR5cGU/OiBVTUxEaWFncmFtVHlwZTtcbiAgICBASW5wdXQoKSBleHBsYW5hdGlvbjogc3RyaW5nO1xuICAgIEBJbnB1dCgpIHJlYWRPbmx5ID0gZmFsc2U7XG5cbiAgICBhcG9sbG9uRWRpdG9yPzogQXBvbGxvbkVkaXRvcjtcblxuICAgIC8vIEljb25zXG4gICAgZmFHcmlwTGluZXMgPSBmYUdyaXBMaW5lcztcbiAgICBmYUdyaXBMaW5lc1ZlcnRpY2FsID0gZmFHcmlwTGluZXNWZXJ0aWNhbDtcblxuICAgIHByb3RlY3RlZCBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgICBwcm90ZWN0ZWQgc2V0dXBJbnRlcmFjdCgpOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMucmVzaXplT3B0aW9ucykge1xuICAgICAgICAgICAgaW50ZXJhY3QoJy5yZXNpemFibGUnKVxuICAgICAgICAgICAgICAgIC5yZXNpemFibGUoe1xuICAgICAgICAgICAgICAgICAgICBlZGdlczogeyBsZWZ0OiBmYWxzZSwgcmlnaHQ6IHRoaXMucmVzaXplT3B0aW9ucy5ob3Jpem9udGFsUmVzaXplICYmICcuZHJhZ2dhYmxlLXJpZ2h0JywgYm90dG9tOiB0aGlzLnJlc2l6ZU9wdGlvbnMudmVydGljYWxSZXNpemUsIHRvcDogZmFsc2UgfSxcbiAgICAgICAgICAgICAgICAgICAgbW9kaWZpZXJzOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICBpbnRlcmFjdC5tb2RpZmllcnMhLnJlc3RyaWN0U2l6ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluOiB7IHdpZHRoOiBNT0RFTElOR19FRElUT1JfTUlOX1dJRFRILCBoZWlnaHQ6IE1PREVMSU5HX0VESVRPUl9NSU5fSEVJR0hUIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4OiB7IHdpZHRoOiBNT0RFTElOR19FRElUT1JfTUFYX1dJRFRILCBoZWlnaHQ6IE1PREVMSU5HX0VESVRPUl9NQVhfSEVJR0hUIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgaW5lcnRpYTogdHJ1ZSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIC5vbigncmVzaXplc3RhcnQnLCBmdW5jdGlvbiAoZXZlbnQ6IGFueSkge1xuICAgICAgICAgICAgICAgICAgICBldmVudC50YXJnZXQuY2xhc3NMaXN0LmFkZCgnY2FyZC1yZXNpemFibGUnKTtcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIC5vbigncmVzaXplZW5kJywgZnVuY3Rpb24gKGV2ZW50OiBhbnkpIHtcbiAgICAgICAgICAgICAgICAgICAgZXZlbnQudGFyZ2V0LmNsYXNzTGlzdC5yZW1vdmUoJ2NhcmQtcmVzaXphYmxlJyk7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAub24oJ3Jlc2l6ZW1vdmUnLCAoZXZlbnQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnJlc2l6ZU9wdGlvbnMuaG9yaXpvbnRhbFJlc2l6ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LnN0eWxlLndpZHRoID0gZXZlbnQucmVjdC53aWR0aCArICdweCc7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMucmVzaXplT3B0aW9ucy52ZXJ0aWNhbFJlc2l6ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LnN0eWxlLmhlaWdodCA9IGV2ZW50LnJlY3QuaGVpZ2h0ICsgJ3B4JztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIElucHV0LCBPdXRwdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE1BWF9TVUJNSVNTSU9OX1RFWFRfTEVOR1RIIH0gZnJvbSAnYXBwL3NoYXJlZC9jb25zdGFudHMvaW5wdXQuY29uc3RhbnRzJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktbW9kZWxpbmctZXhwbGFuYXRpb24tZWRpdG9yJyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vbW9kZWxpbmctZXhwbGFuYXRpb24tZWRpdG9yLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi9tb2RlbGluZy1leHBsYW5hdGlvbi1lZGl0b3IuY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgTW9kZWxpbmdFeHBsYW5hdGlvbkVkaXRvckNvbXBvbmVudCB7XG4gICAgQElucHV0KClcbiAgICByZWFkT25seSA9IGZhbHNlO1xuXG4gICAgQElucHV0KClcbiAgICBleHBsYW5hdGlvbjogc3RyaW5nO1xuXG4gICAgQE91dHB1dCgpXG4gICAgZXhwbGFuYXRpb25DaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5cbiAgICByZWFkb25seSBtYXhDaGFyYWN0ZXJDb3VudCA9IE1BWF9TVUJNSVNTSU9OX1RFWFRfTEVOR1RIO1xuXG4gICAgLy8gQWRkIHRhYiB0byB0aGUgdmFsdWUgb2YgdGV4dGFyZWEgaW5zdGVhZCBvZiBtb3ZpbmcgdG8gdGhlIG5leHQgZWxlbWVudCBpbiBET01cbiAgICBvblRleHRFZGl0b3JUYWIoZWRpdG9yOiBIVE1MVGV4dEFyZWFFbGVtZW50LCBldmVudDogRXZlbnQpIHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBlZGl0b3IudmFsdWU7XG4gICAgICAgIGNvbnN0IHN0YXJ0ID0gZWRpdG9yLnNlbGVjdGlvblN0YXJ0O1xuICAgICAgICBjb25zdCBlbmQgPSBlZGl0b3Iuc2VsZWN0aW9uRW5kO1xuXG4gICAgICAgIGVkaXRvci52YWx1ZSA9IHZhbHVlLnN1YnN0cmluZygwLCBzdGFydCkgKyAnXFx0JyArIHZhbHVlLnN1YnN0cmluZyhlbmQpO1xuICAgICAgICBlZGl0b3Iuc2VsZWN0aW9uU3RhcnQgPSBlZGl0b3Iuc2VsZWN0aW9uRW5kID0gc3RhcnQgKyAxO1xuICAgIH1cblxuICAgIG9uRXhwbGFuYXRpb25JbnB1dChuZXdWYWx1ZTogc3RyaW5nKSB7XG4gICAgICAgIHRoaXMuZXhwbGFuYXRpb25DaGFuZ2UuZW1pdChuZXdWYWx1ZSk7XG4gICAgfVxufVxuIiwiPGxhYmVsIGZvcj1cImV4cGxhbmF0aW9uVGV4dFwiIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAubW9kZWxpbmdTdWJtaXNzaW9uLmV4cGxhbmF0aW9uVGV4dFwiPkV4cGxhbmF0aW9uPC9sYWJlbD5cbjx0ZXh0YXJlYVxuICAgICN0ZXh0RWRpdG9yXG4gICAgaWQ9XCJleHBsYW5hdGlvblRleHRcIlxuICAgIGNsYXNzPVwidGV4dC1lZGl0b3ItdGV4dGFyZWFcIlxuICAgIFttYXhMZW5ndGhdPVwibWF4Q2hhcmFjdGVyQ291bnRcIlxuICAgIFsobmdNb2RlbCldPVwiZXhwbGFuYXRpb25cIlxuICAgIChrZXlkb3duLnRhYik9XCJvblRleHRFZGl0b3JUYWIodGV4dEVkaXRvciwgJGV2ZW50KVwiXG4gICAgKG5nTW9kZWxDaGFuZ2UpPVwib25FeHBsYW5hdGlvbklucHV0KCRldmVudClcIlxuICAgIFtyZWFkT25seV09XCJyZWFkT25seVwiXG4+PC90ZXh0YXJlYT5cbiIsImltcG9ydCB7IEFmdGVyVmlld0luaXQsIENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT25DaGFuZ2VzLCBPbkRlc3Ryb3ksIE91dHB1dCwgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQXBvbGxvbkVkaXRvciwgQXBvbGxvbk1vZGUsIFVNTERpYWdyYW1UeXBlLCBVTUxFbGVtZW50VHlwZSwgVU1MTW9kZWwsIFVNTFJlbGF0aW9uc2hpcCwgVU1MUmVsYXRpb25zaGlwVHlwZSB9IGZyb20gJ0BsczFpbnR1bS9hcG9sbG9uJztcbmltcG9ydCB7IE5nYk1vZGFsIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xuaW1wb3J0IHsgYXNzb2NpYXRpb25VTUwsIHBlcnNvblVNTCwgc3R1ZGVudFVNTCB9IGZyb20gJ2FwcC9ndWlkZWQtdG91ci9ndWlkZWQtdG91ci10YXNrLm1vZGVsJztcbmltcG9ydCB7IEd1aWRlZFRvdXJTZXJ2aWNlIH0gZnJvbSAnYXBwL2d1aWRlZC10b3VyL2d1aWRlZC10b3VyLnNlcnZpY2UnO1xuaW1wb3J0IHsgaXNGdWxsU2NyZWVuIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2Z1bGxzY3JlZW4udXRpbCc7XG5pbXBvcnQgeyBmYUNoZWNrLCBmYUNpcmNsZU5vdGNoLCBmYVRpbWVzIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IGZhUXVlc3Rpb25DaXJjbGUgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1yZWd1bGFyLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBNb2RlbGluZ0NvbXBvbmVudCB9IGZyb20gJ2FwcC9leGVyY2lzZXMvbW9kZWxpbmcvc2hhcmVkL21vZGVsaW5nLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLW1vZGVsaW5nLWVkaXRvcicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL21vZGVsaW5nLWVkaXRvci5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vbW9kZWxpbmctZWRpdG9yLmNvbXBvbmVudC5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIE1vZGVsaW5nRWRpdG9yQ29tcG9uZW50IGV4dGVuZHMgTW9kZWxpbmdDb21wb25lbnQgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3ksIE9uQ2hhbmdlcyB7XG4gICAgQElucHV0KCkgc2hvd0hlbHBCdXR0b24gPSB0cnVlO1xuICAgIEBJbnB1dCgpIHdpdGhFeHBsYW5hdGlvbiA9IGZhbHNlO1xuICAgIEBJbnB1dCgpIHNhdmVkU3RhdHVzPzogeyBpc0NoYW5nZWQ/OiBib29sZWFuOyBpc1NhdmluZz86IGJvb2xlYW4gfTtcblxuICAgIEBPdXRwdXQoKSBwcml2YXRlIG9uTW9kZWxDaGFuZ2VkOiBFdmVudEVtaXR0ZXI8VU1MTW9kZWw+ID0gbmV3IEV2ZW50RW1pdHRlcjxVTUxNb2RlbD4oKTtcblxuICAgIEBPdXRwdXQoKSBleHBsYW5hdGlvbkNoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICAgIHByaXZhdGUgbW9kZWxTdWJzY3JpcHRpb246IG51bWJlcjtcblxuICAgIC8vIEljb25zXG4gICAgZmFDaGVjayA9IGZhQ2hlY2s7XG4gICAgZmFUaW1lcyA9IGZhVGltZXM7XG4gICAgZmFDaXJjbGVOb3RjaCA9IGZhQ2lyY2xlTm90Y2g7XG4gICAgZmFyUXVlc3Rpb25DaXJjbGUgPSBmYVF1ZXN0aW9uQ2lyY2xlO1xuXG4gICAgaHRtbFNjcm9sbCA9IDA7XG4gICAgbW91c2VEb3duTGlzdGVuZXI6ICgodGhpczogRG9jdW1lbnQsIGV2OiBNb3VzZUV2ZW50KSA9PiBhbnkpIHwgdW5kZWZpbmVkO1xuICAgIHNjcm9sbExpc3RlbmVyOiAoKHRoaXM6IERvY3VtZW50LCBldjogRXZlbnQpID0+IGFueSkgfCB1bmRlZmluZWQ7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBtb2RhbFNlcnZpY2U6IE5nYk1vZGFsLFxuICAgICAgICBwcml2YXRlIGd1aWRlZFRvdXJTZXJ2aWNlOiBHdWlkZWRUb3VyU2VydmljZSxcbiAgICApIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBJbml0aWFsaXplcyB0aGUgQXBvbGxvbiBlZGl0b3IuXG4gICAgICogSWYgdGhpcyBpcyBhIGd1aWRlZCB0b3VyLCB0aGVuIGNhbGxzIGFzc2Vzc01vZGVsRm9yR3VpZGVkVG91ci5cbiAgICAgKiBJZiByZXNpemVPcHRpb25zIGlzIHNldCB0byB0cnVlLCByZXNpemVzIHRoZSBlZGl0b3IgYWNjb3JkaW5nIHRvIGludGVyYWN0aW9ucy5cbiAgICAgKi9cbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuaW5pdGlhbGl6ZUFwb2xsb25FZGl0b3IoKTtcbiAgICAgICAgdGhpcy5ndWlkZWRUb3VyU2VydmljZS5jaGVja01vZGVsaW5nQ29tcG9uZW50KCkuc3Vic2NyaWJlKChrZXkpID0+IHtcbiAgICAgICAgICAgIGlmIChrZXkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmFzc2Vzc01vZGVsRm9yR3VpZGVkVG91cihrZXksIHRoaXMuZ2V0Q3VycmVudE1vZGVsKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5zZXR1cEludGVyYWN0KCk7XG4gICAgICAgIHRoaXMuc2V0dXBTYWZhcmlTY3JvbGxGaXgoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUaGlzIGZ1bmN0aW9uIGluaXRpYWxpemVzIHRoZSBBcG9sbG9uIGVkaXRvciBpbiBNb2RlbGluZyBtb2RlLlxuICAgICAqL1xuICAgIHByaXZhdGUgaW5pdGlhbGl6ZUFwb2xsb25FZGl0b3IoKTogdm9pZCB7XG4gICAgICAgIGlmICh0aGlzLmFwb2xsb25FZGl0b3IpIHtcbiAgICAgICAgICAgIHRoaXMuYXBvbGxvbkVkaXRvci51bnN1YnNjcmliZUZyb21Nb2RlbENoYW5nZSh0aGlzLm1vZGVsU3Vic2NyaXB0aW9uKTtcbiAgICAgICAgICAgIHRoaXMuYXBvbGxvbkVkaXRvci5kZXN0cm95KCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBBcG9sbG9uIGRvZXNuJ3QgbmVlZCBhc3Nlc3NtZW50cyBpbiBNb2RlbGluZyBtb2RlXG4gICAgICAgIE1vZGVsaW5nRWRpdG9yQ29tcG9uZW50LnJlbW92ZUFzc2Vzc21lbnRzKHRoaXMudW1sTW9kZWwpO1xuXG4gICAgICAgIGlmICh0aGlzLmVkaXRvckNvbnRhaW5lcikge1xuICAgICAgICAgICAgdGhpcy5hcG9sbG9uRWRpdG9yID0gbmV3IEFwb2xsb25FZGl0b3IodGhpcy5lZGl0b3JDb250YWluZXIubmF0aXZlRWxlbWVudCwge1xuICAgICAgICAgICAgICAgIG1vZGVsOiB0aGlzLnVtbE1vZGVsLFxuICAgICAgICAgICAgICAgIG1vZGU6IEFwb2xsb25Nb2RlLk1vZGVsbGluZyxcbiAgICAgICAgICAgICAgICByZWFkb25seTogdGhpcy5yZWFkT25seSxcbiAgICAgICAgICAgICAgICB0eXBlOiB0aGlzLmRpYWdyYW1UeXBlIHx8IFVNTERpYWdyYW1UeXBlLkNsYXNzRGlhZ3JhbSxcbiAgICAgICAgICAgICAgICBzY2FsZTogMC44LFxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHRoaXMubW9kZWxTdWJzY3JpcHRpb24gPSB0aGlzLmFwb2xsb25FZGl0b3Iuc3Vic2NyaWJlVG9Nb2RlbENoYW5nZSgobW9kZWw6IFVNTE1vZGVsKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5vbk1vZGVsQ2hhbmdlZC5lbWl0KG1vZGVsKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVGhpcyBpcyBhIGhhY2sgdG8gcHJldmVudCB0aGUgVUkganVtcGluZyB0byBib3R0b20gd2hlbiB1c2luZyBwb3BvdmVycyBpbiBBcG9sbG9uIHdoaWxlIHVzaW5nIFNhZmFyaS5cbiAgICAgKiBPdGhlciBicm93c2VycyBkbyBub3Qgc2hvdyB0aGlzIGJlaGF2aW9yLlxuICAgICAqL1xuICAgIHByaXZhdGUgc2V0dXBTYWZhcmlTY3JvbGxGaXgoKSB7XG4gICAgICAgIC8vIERldGVjdCBTYWZhcmkgZGVza3RvcDogaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9hLzUyMjA1MDQ5Lzc0NDE4NTBcbiAgICAgICAgY29uc3QgaXNTYWZhcmlEZXNrdG9wID0gL1NhZmFyaS9pLnRlc3QobmF2aWdhdG9yLnVzZXJBZ2VudCkgJiYgL0FwcGxlIENvbXB1dGVyLy50ZXN0KG5hdmlnYXRvci52ZW5kb3IpICYmICEvTW9iaXxBbmRyb2lkL2kudGVzdChuYXZpZ2F0b3IudXNlckFnZW50KTtcblxuICAgICAgICBpZiAodGhpcy5yZWFkT25seSB8fCAhaXNTYWZhcmlEZXNrdG9wKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zb2xlLmxvZygnV2FybmluZzogSW5zdGFsbGluZyBoYWNrIHRvIHByZXZlbnQgVUkgc2Nyb2xsIGp1bXBzIGluIFNhZmFyaSB3aGlsZSB1c2luZyBBcG9sbG9uIScpO1xuICAgICAgICBjb25zb2xlLmxvZygnV2FybmluZzogSWYgeW91IGV4cGVyaWVuY2UgcHJvYmxlbXMgcmVnYXJkaW5nIHRoZSBzY3JvbGxpbmcgYmVoYXZpb3IsIHBsZWFzZSByZXBvcnQgdGhlbSBhdCBodHRwczovL2dpdGh1Yi5jb20vbHMxaW50dW0vQXJ0ZW1pcycpO1xuXG4gICAgICAgIHRoaXMubW91c2VEb3duTGlzdGVuZXIgPSAoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXdTY3JvbGwgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZSgnaHRtbCcpWzBdLnNjcm9sbFRvcDtcbiAgICAgICAgICAgIGlmIChuZXdTY3JvbGwgIT09IHRoaXMuaHRtbFNjcm9sbCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvcHkgPSB0aGlzLmh0bWxTY3JvbGw7XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAgICAgICAgIC8vIEB0cy1pZ25vcmUgKGJlaGF2aW9yICdpbnN0YW50JyB3b3JrcyB3aXRoIHNhZmFyaSlcbiAgICAgICAgICAgICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gd2luZG93LnNjcm9sbFRvKHsgdG9wOiBjb3B5LCBsZWZ0OiAwLCBiZWhhdmlvcjogJ2luc3RhbnQnIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICB0aGlzLnNjcm9sbExpc3RlbmVyID0gKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5odG1sU2Nyb2xsID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2h0bWwnKVswXS5zY3JvbGxUb3A7XG4gICAgICAgIH07XG5cbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgdGhpcy5tb3VzZURvd25MaXN0ZW5lcik7XG4gICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIHRoaXMuc2Nyb2xsTGlzdGVuZXIpO1xuICAgIH1cblxuICAgIGdldCBpc0Fwb2xsb25FZGl0b3JNb3VudGVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5hcG9sbG9uRWRpdG9yICE9IHVuZGVmaW5lZDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZW1vdmVzIHRoZSBBc3Nlc3NtZW50cyBmcm9tIGEgZ2l2ZW4gVU1MTW9kZWwuIEluIG1vZGVsaW5nIG1vZGUgdGhlIGFzc2Vzc21lbnRzIGFyZSBub3QgbmVlZGVkLlxuICAgICAqIEFsc28sIHRoZXkgc2hvdWxkIG5vdCBiZSBzZW50IHRvIHRoZSBzZXJ2ZXIgYW5kIHBlcnNpc3RlZCBhcyBwYXJ0IG9mIHRoZSBtb2RlbCBKU09OLlxuICAgICAqXG4gICAgICogQHBhcmFtIHVtbE1vZGVsIHRoZSBtb2RlbCBmb3Igd2hpY2ggdGhlIGFzc2Vzc21lbnRzIHNob3VsZCBiZSByZW1vdmVkXG4gICAgICovXG4gICAgcHJpdmF0ZSBzdGF0aWMgcmVtb3ZlQXNzZXNzbWVudHModW1sTW9kZWw6IFVNTE1vZGVsKSB7XG4gICAgICAgIGlmICh1bWxNb2RlbCkge1xuICAgICAgICAgICAgdW1sTW9kZWwuYXNzZXNzbWVudHMgPSB7fTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIGN1cnJlbnQgbW9kZWwgb2YgdGhlIEFwb2xsb24gZWRpdG9yLiBJdCByZW1vdmVzIHRoZSBhc3Nlc3NtZW50IGZpcnN0LCBhcyBpdCBzaG91bGQgbm90IGJlIHBhcnRcbiAgICAgKiBvZiB0aGUgbW9kZWwgb3V0c2lkZSBBcG9sbG9uLlxuICAgICAqL1xuICAgIGdldEN1cnJlbnRNb2RlbCgpOiBVTUxNb2RlbCB7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRNb2RlbCA9IHRoaXMuYXBvbGxvbkVkaXRvciEubW9kZWw7XG4gICAgICAgIE1vZGVsaW5nRWRpdG9yQ29tcG9uZW50LnJlbW92ZUFzc2Vzc21lbnRzKGN1cnJlbnRNb2RlbCk7XG4gICAgICAgIHJldHVybiBjdXJyZW50TW9kZWw7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVGhpcyBmdW5jdGlvbiBvcGVucyB0aGUgbW9kYWwgZm9yIHRoZSBoZWxwIGRpYWxvZy5cbiAgICAgKi9cbiAgICBvcGVuKGNvbnRlbnQ6IGFueSk6IHZvaWQge1xuICAgICAgICB0aGlzLm1vZGFsU2VydmljZS5vcGVuKGNvbnRlbnQsIHsgc2l6ZTogJ2xnJyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBJZiBjaGFuZ2VzIGFyZSBtYWRlIHRvIHRoZSB1bWwgbW9kZWwsIHVwZGF0ZSB0aGUgbW9kZWwgYW5kIHJlbW92ZSBhc3Nlc3NtZW50c1xuICAgICAqIEBwYXJhbSB7U2ltcGxlQ2hhbmdlc30gY2hhbmdlcyAtIENoYW5nZXMgbWFkZVxuICAgICAqL1xuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcbiAgICAgICAgaWYgKGNoYW5nZXMuZGlhZ3JhbVR5cGUpIHtcbiAgICAgICAgICAgIC8vIGlmIGRpYWdyYW0gdHlwZSBjaGFuZ2VkIC0+IHJlY3JlYXRlIHRoZSBlZGl0b3JcbiAgICAgICAgICAgIHRoaXMuaW5pdGlhbGl6ZUFwb2xsb25FZGl0b3IoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjaGFuZ2VzLnVtbE1vZGVsICYmIGNoYW5nZXMudW1sTW9kZWwuY3VycmVudFZhbHVlICYmIHRoaXMuYXBvbGxvbkVkaXRvcikge1xuICAgICAgICAgICAgdGhpcy51bWxNb2RlbCA9IGNoYW5nZXMudW1sTW9kZWwuY3VycmVudFZhbHVlO1xuICAgICAgICAgICAgLy8gQXBvbGxvbiBkb2Vzbid0IG5lZWQgYXNzZXNzbWVudHMgaW4gTW9kZWxpbmcgbW9kZVxuICAgICAgICAgICAgTW9kZWxpbmdFZGl0b3JDb21wb25lbnQucmVtb3ZlQXNzZXNzbWVudHModGhpcy51bWxNb2RlbCk7XG4gICAgICAgICAgICB0aGlzLmFwb2xsb25FZGl0b3IubW9kZWwgPSB0aGlzLnVtbE1vZGVsO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSWYgdGhlIGFwb2xsb24gZWRpdG9yIGlzIG5vdCBudWxsLCBkZXN0cm95IGl0IGFuZCBzZXQgaXQgdG8gbnVsbCwgb24gY29tcG9uZW50IGRlc3RydWN0aW9uXG4gICAgICovXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgICAgIGlmICh0aGlzLmFwb2xsb25FZGl0b3IpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLm1vZGVsU3Vic2NyaXB0aW9uKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5hcG9sbG9uRWRpdG9yLnVuc3Vic2NyaWJlRnJvbU1vZGVsQ2hhbmdlKHRoaXMubW9kZWxTdWJzY3JpcHRpb24pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5hcG9sbG9uRWRpdG9yLmRlc3Ryb3koKTtcbiAgICAgICAgICAgIHRoaXMuYXBvbGxvbkVkaXRvciA9IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLm1vdXNlRG93bkxpc3RlbmVyKSB7XG4gICAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCB0aGlzLm1vdXNlRG93bkxpc3RlbmVyKTtcbiAgICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIHRoaXMuc2Nyb2xsTGlzdGVuZXIhKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEFzc2VzcyB0aGUgbW9kZWwgZm9yIHRoZSBtb2RlbGluZyBndWlkZWQgdHV0b3JpYWxcbiAgICAgKiBAcGFyYW0gdW1sTmFtZSAgdGhlIGlkZW50aWZpZXIgb2YgdGhlIFVNTCBlbGVtZW50IHRoYXQgaGFzIHRvIGJlIGFzc2Vzc2VkXG4gICAgICogQHBhcmFtIHVtbE1vZGVsICB0aGUgY3VycmVudCBVTUwgbW9kZWwgaW4gdGhlIGVkaXRvclxuICAgICAqL1xuICAgIGFzc2Vzc01vZGVsRm9yR3VpZGVkVG91cih1bWxOYW1lOiBzdHJpbmcsIHVtbE1vZGVsOiBVTUxNb2RlbCk6IHZvaWQge1xuICAgICAgICAvLyBGaW5kIHRoZSByZXF1aXJlZCBVTUwgY2xhc3Nlc1xuICAgICAgICBjb25zdCBwZXJzb25DbGFzcyA9IHRoaXMuZWxlbWVudFdpdGhDbGFzcyhwZXJzb25VTUwubmFtZSwgdW1sTW9kZWwpO1xuICAgICAgICBjb25zdCBzdHVkZW50Q2xhc3MgPSB0aGlzLmVsZW1lbnRXaXRoQ2xhc3Moc3R1ZGVudFVNTC5uYW1lLCB1bWxNb2RlbCk7XG4gICAgICAgIGxldCBwZXJzb25TdHVkZW50QXNzb2NpYXRpb246IFVNTFJlbGF0aW9uc2hpcCB8IHVuZGVmaW5lZDtcblxuICAgICAgICBzd2l0Y2ggKHVtbE5hbWUpIHtcbiAgICAgICAgICAgIC8vIENoZWNrIGlmIHRoZSBQZXJzb24gY2xhc3MgaXMgY29ycmVjdFxuICAgICAgICAgICAgY2FzZSBwZXJzb25VTUwubmFtZToge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5hbWVBdHRyaWJ1dGUgPSB0aGlzLmVsZW1lbnRXaXRoQXR0cmlidXRlKHBlcnNvblVNTC5hdHRyaWJ1dGUsIHVtbE1vZGVsKTtcbiAgICAgICAgICAgICAgICBjb25zdCBwZXJzb25DbGFzc0NvcnJlY3QgPSBwZXJzb25DbGFzcyAmJiBuYW1lQXR0cmlidXRlID8gbmFtZUF0dHJpYnV0ZS5vd25lciA9PT0gcGVyc29uQ2xhc3MuaWQgOiBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLmd1aWRlZFRvdXJTZXJ2aWNlLnVwZGF0ZU1vZGVsaW5nUmVzdWx0KHVtbE5hbWUsIHBlcnNvbkNsYXNzQ29ycmVjdCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBDaGVjayBpZiB0aGUgU3R1ZGVudCBjbGFzcyBpcyBjb3JyZWN0XG4gICAgICAgICAgICBjYXNlIHN0dWRlbnRVTUwubmFtZToge1xuICAgICAgICAgICAgICAgIGNvbnN0IG1ham9yQXR0cmlidXRlID0gdGhpcy5lbGVtZW50V2l0aEF0dHJpYnV0ZShzdHVkZW50VU1MLmF0dHJpYnV0ZSwgdW1sTW9kZWwpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHZpc2l0TGVjdHVyZU1ldGhvZCA9IHRoaXMuZWxlbWVudFdpdGhNZXRob2Qoc3R1ZGVudFVNTC5tZXRob2QsIHVtbE1vZGVsKTtcbiAgICAgICAgICAgICAgICBjb25zdCBzdHVkZW50Q2xhc3NDb3JyZWN0ID1cbiAgICAgICAgICAgICAgICAgICAgc3R1ZGVudENsYXNzICYmIG1ham9yQXR0cmlidXRlICYmIHZpc2l0TGVjdHVyZU1ldGhvZCA/IG1ham9yQXR0cmlidXRlLm93bmVyID09PSBzdHVkZW50Q2xhc3MuaWQgJiYgdmlzaXRMZWN0dXJlTWV0aG9kLm93bmVyID09PSBzdHVkZW50Q2xhc3MuaWQgOiBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLmd1aWRlZFRvdXJTZXJ2aWNlLnVwZGF0ZU1vZGVsaW5nUmVzdWx0KHVtbE5hbWUsIHN0dWRlbnRDbGFzc0NvcnJlY3QpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gQ2hlY2sgaWYgdGhlIEluaGVyaXRhbmNlIGFzc29jaWF0aW9uIGlzIGNvcnJlY3RcbiAgICAgICAgICAgIGNhc2UgYXNzb2NpYXRpb25VTUwubmFtZToge1xuICAgICAgICAgICAgICAgIHBlcnNvblN0dWRlbnRBc3NvY2lhdGlvbiA9IE9iamVjdC52YWx1ZXModW1sTW9kZWwucmVsYXRpb25zaGlwcykuZmluZChcbiAgICAgICAgICAgICAgICAgICAgKHJlbGF0aW9uc2hpcCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbGF0aW9uc2hpcC5zb3VyY2UuZWxlbWVudCA9PT0gc3R1ZGVudENsYXNzIS5pZCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgcmVsYXRpb25zaGlwLnRhcmdldC5lbGVtZW50ID09PSBwZXJzb25DbGFzcyEuaWQgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbGF0aW9uc2hpcC50eXBlID09PSBVTUxSZWxhdGlvbnNoaXBUeXBlLkNsYXNzSW5oZXJpdGFuY2UsXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB0aGlzLmd1aWRlZFRvdXJTZXJ2aWNlLnVwZGF0ZU1vZGVsaW5nUmVzdWx0KHVtbE5hbWUsICEhcGVyc29uU3R1ZGVudEFzc29jaWF0aW9uKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybiB0aGUgVU1MTW9kZWxFbGVtZW50IG9mIHRoZSB0eXBlIGNsYXNzIHdpdGggdGhlIEBwYXJhbSBuYW1lXG4gICAgICogQHBhcmFtIG5hbWUgY2xhc3MgbmFtZVxuICAgICAqIEBwYXJhbSB1bWxNb2RlbCBjdXJyZW50IG1vZGVsIHRoYXQgaXMgYXNzZXNzZWRcbiAgICAgKi9cbiAgICBlbGVtZW50V2l0aENsYXNzKG5hbWU6IHN0cmluZywgdW1sTW9kZWw6IFVNTE1vZGVsKSB7XG4gICAgICAgIHJldHVybiBPYmplY3QudmFsdWVzKHVtbE1vZGVsLmVsZW1lbnRzKS5maW5kKChlbGVtZW50KSA9PiBlbGVtZW50Lm5hbWUudHJpbSgpID09PSBuYW1lICYmIGVsZW1lbnQudHlwZSA9PT0gVU1MRWxlbWVudFR5cGUuQ2xhc3MpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybiB0aGUgVU1MTW9kZWxFbGVtZW50IG9mIHRoZSB0eXBlIENsYXNzQXR0cmlidXRlIHdpdGggdGhlIEBwYXJhbSBhdHRyaWJ1dGVcbiAgICAgKiBAcGFyYW0gYXR0cmlidXRlIG5hbWVcbiAgICAgKiBAcGFyYW0gdW1sTW9kZWwgY3VycmVudCBtb2RlbCB0aGF0IGlzIGFzc2Vzc2VkXG4gICAgICovXG4gICAgZWxlbWVudFdpdGhBdHRyaWJ1dGUoYXR0cmlidXRlOiBzdHJpbmcsIHVtbE1vZGVsOiBVTUxNb2RlbCkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LnZhbHVlcyh1bWxNb2RlbC5lbGVtZW50cykuZmluZCgoZWxlbWVudCkgPT4gZWxlbWVudC5uYW1lLmluY2x1ZGVzKGF0dHJpYnV0ZSkgJiYgZWxlbWVudC50eXBlID09PSBVTUxFbGVtZW50VHlwZS5DbGFzc0F0dHJpYnV0ZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJuIHRoZSBVTUxNb2RlbEVsZW1lbnQgb2YgdGhlIHR5cGUgQ2xhc3NNZXRob2Qgd2l0aCB0aGUgQHBhcmFtIG1ldGhvZFxuICAgICAqIEBwYXJhbSBtZXRob2QgbmFtZVxuICAgICAqIEBwYXJhbSB1bWxNb2RlbCBjdXJyZW50IG1vZGVsIHRoYXQgaXMgYXNzZXNzZWRcbiAgICAgKi9cbiAgICBlbGVtZW50V2l0aE1ldGhvZChtZXRob2Q6IHN0cmluZywgdW1sTW9kZWw6IFVNTE1vZGVsKSB7XG4gICAgICAgIHJldHVybiBPYmplY3QudmFsdWVzKHVtbE1vZGVsLmVsZW1lbnRzKS5maW5kKChlbGVtZW50KSA9PiBlbGVtZW50Lm5hbWUuaW5jbHVkZXMobWV0aG9kKSAmJiBlbGVtZW50LnR5cGUgPT09IFVNTEVsZW1lbnRUeXBlLkNsYXNzTWV0aG9kKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjaGVja3MgaWYgdGhpcyBjb21wb25lbnQgaXMgdGhlIGN1cnJlbnQgZnVsbHNjcmVlbiBjb21wb25lbnRcbiAgICAgKi9cbiAgICBnZXQgaXNGdWxsU2NyZWVuKCkge1xuICAgICAgICByZXR1cm4gaXNGdWxsU2NyZWVuKCk7XG4gICAgfVxuXG4gICAgLy8gRW1pdCBleHBsYW5hdGlvbiBjaGFuZ2Ugd2hlbiB0ZXh0YXJlYSBpbnB1dCBjaGFuZ2VzXG4gICAgb25FeHBsYW5hdGlvbklucHV0KG5ld1ZhbHVlOiBzdHJpbmcpIHtcbiAgICAgICAgdGhpcy5leHBsYW5hdGlvbkNoYW5nZS5lbWl0KG5ld1ZhbHVlKTtcbiAgICAgICAgdGhpcy5leHBsYW5hdGlvbiA9IG5ld1ZhbHVlO1xuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJndWlkZWQtdG91ciBtb2RlbGluZy1lZGl0b3JcIj5cbiAgICA8bmctdGVtcGxhdGUgI2hlbHAgbGV0LWNsb3NlPVwiY2xvc2VcIiBsZXQtZGlzbWlzcz1cImRpc21pc3NcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWhlYWRlclwiPlxuICAgICAgICAgICAgPGg0IGNsYXNzPVwibW9kYWwtdGl0bGVcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLm1vZGVsaW5nRWRpdG9yLmhlbHBNb2RhbC50aXRsZVwiPkhvdyB0byB1c2UgdGhlIG1vZGVsaW5nIGVkaXRvcjwvaDQ+XG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1jbG9zZVwiIGFyaWEtbGFiZWw9XCJDbG9zZVwiIChjbGljayk9XCJkaXNtaXNzKClcIj48c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj48L3NwYW4+PC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtYm9keVwiPlxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzPVwidGFibGVcIj5cbiAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLm1vZGVsaW5nRWRpdG9yLmhlbHBNb2RhbC5jcmVhdGVFbGVtZW50LnRpdGxlXCI+QWRkIENsYXNzPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAubW9kZWxpbmdFZGl0b3IuaGVscE1vZGFsLmNyZWF0ZUVsZW1lbnQudGV4dFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgVG8gYWRkIGEgY2xhc3MsIHNpbXBseSBkcmFnIGFuZCBkcm9wIG9uZSBvZiB0aGUgZWxlbWVudHMgb24gdGhlIHJpZ2h0IHNpZGUgaW50byB0aGUgZWRpdG9yIGFyZWEgb24gdGhlIGxlZnQgc2lkZS5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkPjxpbWcgd2lkdGg9XCIzMDBcIiBzcmM9XCIvY29udGVudC9pbWFnZXMvaGVscC1jcmVhdGUtZWxlbWVudC5wbmdcIiAvPjwvdGQ+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLm1vZGVsaW5nRWRpdG9yLmhlbHBNb2RhbC5jcmVhdGVSZWxhdGlvbnNoaXAudGl0bGVcIj5BZGQgQXNzb2NpYXRpb248L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGQgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5tb2RlbGluZ0VkaXRvci5oZWxwTW9kYWwuY3JlYXRlUmVsYXRpb25zaGlwLnRleHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFRvIGFkZCBhbiBhc3NvY2lhdGlvbiwgc2VsZWN0IHRoZSBzb3VyY2UgY2xhc3Mgd2l0aCBhIHNpbmdsZSBjbGljayBhbmQgeW91IHdpbGwgc2VlIGZvdXIgYmx1ZSBjaXJjbGVzLiBUaG9zZSBhcmUgdGhlIHBvc3NpYmxlIGNvbm5lY3Rpb24gcG9pbnRzIGZvclxuICAgICAgICAgICAgICAgICAgICAgICAgYXNzb2NpYXRpb25zLiBDbGljayBhbmQgaG9sZCBvbiBvbmUgb2YgdGhvc2UgYW5kIGRyYWcgaXQgdG8gYW5vdGhlciBibHVlIGNpcmNsZSB0byBjcmVhdGUgYW4gYXNzb2NpYXRpb24uXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZD48aW1nIHdpZHRoPVwiMzAwXCIgc3JjPVwiL2NvbnRlbnQvaW1hZ2VzL2hlbHAtY3JlYXRlLXJlbGF0aW9uc2hpcC5qcGdcIiAvPjwvdGQ+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLm1vZGVsaW5nRWRpdG9yLmhlbHBNb2RhbC51cGRhdGVFbGVtZW50LnRpdGxlXCI+RWRpdCBDbGFzczwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLm1vZGVsaW5nRWRpdG9yLmhlbHBNb2RhbC51cGRhdGVFbGVtZW50LnRleHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFRvIGVkaXQgYSBjbGFzcywgZG91YmxlIGNsaWNrIGl0IGFuZCBhIHBvcHVwIHdpbGwgb3BlbiB1cCwgaW4gd2hpY2ggeW91IGNhbiBlZGl0IGl0cyBjb21wb25lbnRzLCBlLmcuIG5hbWUsIGF0dHJpYnV0ZXMsIG1ldGhvZHMsIGV0Yy5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkPjxpbWcgd2lkdGg9XCIzMDBcIiBzcmM9XCIvY29udGVudC9pbWFnZXMvaGVscC11cGRhdGUtZWxlbWVudC5qcGdcIiAvPjwvdGQ+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLm1vZGVsaW5nRWRpdG9yLmhlbHBNb2RhbC5kZWxldGVFbGVtZW50LnRpdGxlXCI+RGVsZXRlIENsYXNzPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAubW9kZWxpbmdFZGl0b3IuaGVscE1vZGFsLmRlbGV0ZUVsZW1lbnQudGV4dFwiIGNvbHNwYW49XCIyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBUbyBkZWxldGUgYSBjbGFzcywgc2VsZWN0IGl0IHdpdGggYSBzaW5nbGUgY2xpY2sgYW5kIGVpdGhlciBwcmVzcyA8Y29kZT5EZWxldGU8L2NvZGU+IG9yIDxjb2RlPkJhY2tzcGFjZTwvY29kZT4gb24geW91ciBrZXlib2FyZC5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAubW9kZWxpbmdFZGl0b3IuaGVscE1vZGFsLm1vdmVFbGVtZW50LnRpdGxlXCI+TW92ZSBDbGFzczwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLm1vZGVsaW5nRWRpdG9yLmhlbHBNb2RhbC5tb3ZlRWxlbWVudC50ZXh0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBUbyBtb3ZlIGEgY2xhc3MsIHNlbGVjdCBpdCB3aXRoIGEgc2luZ2xlIGNsaWNrIGFuZCBlaXRoZXIgdXNlIHlvdXIga2V5Ym9hcmQgYXJyb3dzIG9yIGRyYWcgYW5kIGRyb3AgaXQuXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZD48aW1nIHdpZHRoPVwiMzAwXCIgc3JjPVwiL2NvbnRlbnQvaW1hZ2VzL2hlbHAtbW92ZS1lbGVtZW50LmpwZ1wiIC8+PC90ZD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAubW9kZWxpbmdFZGl0b3IuaGVscE1vZGFsLnJlc2l6ZUVsZW1lbnQudGl0bGVcIj5Nb3ZlIENsYXNzPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAubW9kZWxpbmdFZGl0b3IuaGVscE1vZGFsLnJlc2l6ZUVsZW1lbnQudGV4dFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgVG8gbW92ZSBhIGNsYXNzLCBzZWxlY3QgaXQgd2l0aCBhIHNpbmdsZSBjbGljayBhbmQgZWl0aGVyIHVzZSB5b3VyIGtleWJvYXJkIGFycm93cyBvciBkcmFnIGFuZCBkcm9wIGl0LlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQ+PGltZyB3aWR0aD1cIjMwMFwiIHNyYz1cIi9jb250ZW50L2ltYWdlcy9oZWxwLXJlc2l6ZS1lbGVtZW50LmpwZ1wiIC8+PC90ZD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAubW9kZWxpbmdFZGl0b3IuaGVscE1vZGFsLnJlY29ubmVjdFJlbGF0aW9uc2hpcC50aXRsZVwiPk1vdmUgQ2xhc3M8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGQgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5tb2RlbGluZ0VkaXRvci5oZWxwTW9kYWwucmVjb25uZWN0UmVsYXRpb25zaGlwLnRleHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFRvIG1vdmUgYSBjbGFzcywgc2VsZWN0IGl0IHdpdGggYSBzaW5nbGUgY2xpY2sgYW5kIGVpdGhlciB1c2UgeW91ciBrZXlib2FyZCBhcnJvd3Mgb3IgZHJhZyBhbmQgZHJvcCBpdC5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkPjxpbWcgd2lkdGg9XCIzMDBcIiBzcmM9XCIvY29udGVudC9pbWFnZXMvaGVscC1yZWNvbm5lY3QtcmVsYXRpb25zaGlwLmpwZ1wiIC8+PC90ZD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAubW9kZWxpbmdFZGl0b3IuaGVscE1vZGFsLnNlbGVjdC50aXRsZVwiPlVuZG8gJiBSZWRvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAubW9kZWxpbmdFZGl0b3IuaGVscE1vZGFsLnNlbGVjdC50ZXh0XCIgY29sc3Bhbj1cIjJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFdpdGggPGNvZGU+Q3RybCtaPC9jb2RlPiBhbmQgPGNvZGU+Q3RybCtZPC9jb2RlPiB5b3UgY2FuIHVuZG8gYW5kIHJlZG8geW91ciBjaGFuZ2VzLlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICA8dGggamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5tb2RlbGluZ0VkaXRvci5oZWxwTW9kYWwuZHVwbGljYXRlLnRpdGxlXCI+VW5kbyAmIFJlZG88L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGQgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5tb2RlbGluZ0VkaXRvci5oZWxwTW9kYWwuZHVwbGljYXRlLnRleHRcIiBjb2xzcGFuPVwiMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgV2l0aCA8Y29kZT5DdHJsK1o8L2NvZGU+IGFuZCA8Y29kZT5DdHJsK1k8L2NvZGU+IHlvdSBjYW4gdW5kbyBhbmQgcmVkbyB5b3VyIGNoYW5nZXMuXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLm1vZGVsaW5nRWRpdG9yLmhlbHBNb2RhbC51bmRvLnRpdGxlXCI+VW5kbyAmIFJlZG88L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGQgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5tb2RlbGluZ0VkaXRvci5oZWxwTW9kYWwudW5kby50ZXh0XCIgY29sc3Bhbj1cIjJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFdpdGggPGNvZGU+Q3RybCtaPC9jb2RlPiBhbmQgPGNvZGU+Q3RybCtZPC9jb2RlPiB5b3UgY2FuIHVuZG8gYW5kIHJlZG8geW91ciBjaGFuZ2VzLlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWZvb3RlclwiPlxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLW91dGxpbmVcIiAoY2xpY2spPVwiY2xvc2UoKVwiIGpoaVRyYW5zbGF0ZT1cImVudGl0eS5hY3Rpb24uY2xvc2VcIj5DbG9zZTwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICA8L25nLXRlbXBsYXRlPlxuICAgIEBpZiAoIXJlYWRPbmx5ICYmICFpc0Z1bGxTY3JlZW4pIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cImhlbHAtYW5kLXN0YXR1c1wiPlxuICAgICAgICAgICAgQGlmICghcmVhZE9ubHkgJiYgc2hvd0hlbHBCdXR0b24pIHtcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi13YXJuaW5nXCIgKGNsaWNrKT1cIm9wZW4oaGVscClcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFyUXVlc3Rpb25DaXJjbGVcIj48L2ZhLWljb24+Jm5ic3A7XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGpoaVRyYW5zbGF0ZT1cImFydGVtaXNBcHAubW9kZWxpbmdFZGl0b3IuaGVscE1vZGFsLmhlbHBcIj5IZWxwPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmIChzYXZlZFN0YXR1cyAmJiAhc2F2ZWRTdGF0dXMuaXNDaGFuZ2VkICYmICFzYXZlZFN0YXR1cy5pc1NhdmluZykge1xuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGF0dXMtaGludCB0ZXh0LXN1Y2Nlc3NcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFDaGVja1wiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5tb2RlbGluZ0VkaXRvci5hbGxTYXZlZFwiPkFsbCBjaGFuZ2VzIHNhdmVkPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmIChzYXZlZFN0YXR1cyAmJiBzYXZlZFN0YXR1cy5pc0NoYW5nZWQgJiYgIXNhdmVkU3RhdHVzLmlzU2F2aW5nKSB7XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN0YXR1cy1oaW50IHRleHQtd2FybmluZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYVRpbWVzXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLm1vZGVsaW5nRWRpdG9yLnVuc2F2ZWRDaGFuZ2VzXCI+VW5zYXZlZCBjaGFuZ2VzPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmIChzYXZlZFN0YXR1cyAmJiBzYXZlZFN0YXR1cy5pc1NhdmluZykge1xuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGF0dXMtaGludCB0ZXh0LWluZm9cIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gY2xhc3M9XCJzcGluXCIgW2ljb25dPVwiZmFDaXJjbGVOb3RjaFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5tb2RlbGluZ0VkaXRvci5zYXZpbmdcIj5TYXZpbmcuLi48L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbiAgICA8ZGl2ICNyZXNpemVDb250YWluZXIgY2xhc3M9XCJtb2RlbGluZy1lZGl0b3JcIiBbY2xhc3MucmVzaXphYmxlXT1cInJlc2l6ZU9wdGlvbnNcIiBbbmdTdHlsZV09XCJ7IG1hcmdpblRvcDogaXNGdWxsU2NyZWVuID8gJzMwcHgnIDogJycgfVwiPlxuICAgICAgICA8ZGl2ICNlZGl0b3JDb250YWluZXIgY2xhc3M9XCJhcG9sbG9uLWNvbnRhaW5lclwiPjwvZGl2PlxuICAgICAgICBAaWYgKHJlc2l6ZU9wdGlvbnMgJiYgcmVzaXplT3B0aW9ucy5ob3Jpem9udGFsUmVzaXplKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZHJhZ2dhYmxlLXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFHcmlwTGluZXNWZXJ0aWNhbFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICAgIEBpZiAocmVzaXplT3B0aW9ucyAmJiByZXNpemVPcHRpb25zLnZlcnRpY2FsUmVzaXplKSB7XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZHJhZ2dhYmxlLWJvdHRvbVwiPlxuICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhR3JpcExpbmVzXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICA8L2Rpdj5cbiAgICBAaWYgKHdpdGhFeHBsYW5hdGlvbikge1xuICAgICAgICA8amhpLW1vZGVsaW5nLWV4cGxhbmF0aW9uLWVkaXRvciBbZXhwbGFuYXRpb25dPVwiZXhwbGFuYXRpb25cIiAoZXhwbGFuYXRpb25DaGFuZ2UpPVwib25FeHBsYW5hdGlvbklucHV0KCRldmVudClcIiBbcmVhZE9ubHldPVwicmVhZE9ubHlcIj48L2poaS1tb2RlbGluZy1leHBsYW5hdGlvbi1lZGl0b3I+XG4gICAgfVxuPC9kaXY+XG4iLCJpbXBvcnQgeyBNb2RlbGluZ0VkaXRvckNvbXBvbmVudCB9IGZyb20gJy4vbW9kZWxpbmctZWRpdG9yLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZE1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvc2hhcmVkLm1vZHVsZSc7XG5pbXBvcnQgeyBNb2RlbGluZ0V4cGxhbmF0aW9uRWRpdG9yQ29tcG9uZW50IH0gZnJvbSAnLi9tb2RlbGluZy1leHBsYW5hdGlvbi1lZGl0b3IuY29tcG9uZW50JztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc1NoYXJlZE1vZHVsZV0sXG4gICAgZGVjbGFyYXRpb25zOiBbTW9kZWxpbmdFZGl0b3JDb21wb25lbnQsIE1vZGVsaW5nRXhwbGFuYXRpb25FZGl0b3JDb21wb25lbnRdLFxuICAgIGV4cG9ydHM6IFtNb2RlbGluZ0VkaXRvckNvbXBvbmVudCwgTW9kZWxpbmdFeHBsYW5hdGlvbkVkaXRvckNvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNNb2RlbGluZ0VkaXRvck1vZHVsZSB7fVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBYSwyQkFDQSwyQkFDQSw0QkFDQTtBQUhiOztBQUFPLElBQU0sNEJBQTRCO0FBQ2xDLElBQU0sNEJBQTRCO0FBQ2xDLElBQU0sNkJBQTZCO0FBQ25DLElBQU0sNkJBQTZCOzs7OztBQ0gxQyxTQUFTLFdBQVcsWUFBWSxPQUFPLGlCQUFpQjtBQUN4RCxTQUFTLGFBQWEsMkJBQTJCO0FBQ2pELFNBQXdCLHNCQUFnQztBQUV4RCxPQUFPLGNBQWM7O0FBSnJCLGNBT3NCO0FBUHRCOztBQUdBOzs7QUFJTSxJQUFnQixvQkFBaEIsTUFBZ0IsbUJBQWlCO01BQ2M7TUFDQTtNQUN4QztNQUNBO01BQ0E7TUFDQTtNQUNBLFdBQVc7TUFFcEI7TUFHQSxjQUFjO01BQ2Qsc0JBQXNCO01BRXRCLGNBQUE7TUFBeUI7TUFFZixnQkFBYTtBQUNuQixZQUFJLEtBQUssZUFBZTtBQUNwQixtQkFBUyxZQUFZLEVBQ2hCLFVBQVU7WUFDUCxPQUFPLEVBQUUsTUFBTSxPQUFPLE9BQU8sS0FBSyxjQUFjLG9CQUFvQixvQkFBb0IsUUFBUSxLQUFLLGNBQWMsZ0JBQWdCLEtBQUssTUFBSztZQUM3SSxXQUFXO2NBQ1AsU0FBUyxVQUFXLGFBQWE7Z0JBQzdCLEtBQUssRUFBRSxPQUFPLDJCQUEyQixRQUFRLDJCQUEwQjtnQkFDM0UsS0FBSyxFQUFFLE9BQU8sMkJBQTJCLFFBQVEsMkJBQTBCO2VBQzlFOztZQUVMLFNBQVM7V0FDWixFQUNBLEdBQUcsZUFBZSxTQUFVLE9BQVU7QUFDbkMsa0JBQU0sT0FBTyxVQUFVLElBQUksZ0JBQWdCO1VBQy9DLENBQUMsRUFDQSxHQUFHLGFBQWEsU0FBVSxPQUFVO0FBQ2pDLGtCQUFNLE9BQU8sVUFBVSxPQUFPLGdCQUFnQjtVQUNsRCxDQUFDLEVBQ0EsR0FBRyxjQUFjLENBQUMsVUFBYztBQUM3QixrQkFBTSxTQUFTLE1BQU07QUFDckIsZ0JBQUksS0FBSyxjQUFjLGtCQUFrQjtBQUNyQyxxQkFBTyxNQUFNLFFBQVEsTUFBTSxLQUFLLFFBQVE7O0FBRTVDLGdCQUFJLEtBQUssY0FBYyxnQkFBZ0I7QUFDbkMscUJBQU8sTUFBTSxTQUFTLE1BQU0sS0FBSyxTQUFTOztVQUVsRCxDQUFDOztNQUViOzt5QkE5Q2tCLG9CQUFpQjtNQUFBO2dFQUFqQixvQkFBaUIsV0FBQSxDQUFBLENBQUEsY0FBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLHdCQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBOzs7Ozs7Ozs7Ozs7O29GQUFqQixtQkFBaUIsRUFBQSxXQUFBLG9CQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBQ1B2QyxTQUFTLGFBQUFBLFlBQVcsY0FBYyxTQUFBQyxRQUFPLGNBQWM7OztBQUF2RCxJQVFhO0FBUmI7O0FBQ0E7O0FBT00sSUFBTyxxQ0FBUCxNQUFPLG9DQUFrQztNQUUzQyxXQUFXO01BR1g7TUFHQSxvQkFBb0IsSUFBSSxhQUFZO01BRTNCLG9CQUFvQjtNQUc3QixnQkFBZ0IsUUFBNkIsT0FBWTtBQUNyRCxjQUFNLGVBQWM7QUFDcEIsY0FBTSxRQUFRLE9BQU87QUFDckIsY0FBTSxRQUFRLE9BQU87QUFDckIsY0FBTSxNQUFNLE9BQU87QUFFbkIsZUFBTyxRQUFRLE1BQU0sVUFBVSxHQUFHLEtBQUssSUFBSSxNQUFPLE1BQU0sVUFBVSxHQUFHO0FBQ3JFLGVBQU8saUJBQWlCLE9BQU8sZUFBZSxRQUFRO01BQzFEO01BRUEsbUJBQW1CLFVBQWdCO0FBQy9CLGFBQUssa0JBQWtCLEtBQUssUUFBUTtNQUN4Qzs7eUJBekJTLHFDQUFrQztNQUFBO2lFQUFsQyxxQ0FBa0MsV0FBQSxDQUFBLENBQUEsaUNBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxVQUFBLFlBQUEsYUFBQSxjQUFBLEdBQUEsU0FBQSxFQUFBLG1CQUFBLG9CQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxPQUFBLG1CQUFBLGdCQUFBLCtDQUFBLEdBQUEsQ0FBQSxNQUFBLG1CQUFBLEdBQUEsd0JBQUEsR0FBQSxhQUFBLFdBQUEsWUFBQSxpQkFBQSxhQUFBLEdBQUEsQ0FBQSxjQUFBLEVBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSw0Q0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTs7QUNSL0MsVUFBQSw2QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQUEwRixVQUFBLHFCQUFBLEdBQUEsYUFBQTtBQUFXLFVBQUEsMkJBQUE7QUFDckcsVUFBQSxxQkFBQSxHQUFBLElBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsWUFBQSxHQUFBLENBQUE7QUFLSSxVQUFBLHlCQUFBLGlCQUFBLFNBQUEsOEVBQUEsUUFBQTtBQUFBLG1CQUFBLElBQUEsY0FBQTtVQUFBLENBQUEsRUFBeUIsZUFBQSxTQUFBLDRFQUFBLFFBQUE7QUFBQSxZQUFBLDRCQUFBLEdBQUE7QUFBQSxrQkFBQSxNQUFBLDBCQUFBLENBQUE7QUFBQSxtQkFDViwwQkFBQSxJQUFBLGdCQUFBLEtBQUEsTUFBQSxDQUFtQztVQUFBLENBQUEsRUFEekIsaUJBQUEsU0FBQSw4RUFBQSxRQUFBO0FBQUEsbUJBRVIsSUFBQSxtQkFBQSxNQUFBO1VBQTBCLENBQUE7QUFFOUMsVUFBQSwyQkFBQTtBQUNELFVBQUEscUJBQUEsR0FBQSxJQUFBOzs7QUFOSSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLGFBQUEsSUFBQSxpQkFBQSxFQUErQixXQUFBLElBQUEsV0FBQSxFQUFBLFlBQUEsSUFBQSxRQUFBOzs7OztxRkRHdEIsb0NBQWtDLEVBQUEsV0FBQSxxQ0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVSL0MsU0FBd0IsYUFBQUMsWUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUE2QixVQUFBQyxlQUE2QjtBQUMzRyxTQUFTLGVBQWUsYUFBYSxrQkFBQUMsaUJBQWdCLGdCQUEyQywyQkFBMkI7QUFDM0gsU0FBUyxnQkFBZ0I7QUFJekIsU0FBUyxTQUFTLGVBQWUsZUFBZTtBQUNoRCxTQUFTLHdCQUF3Qjs7Ozs7Ozs7QUNMekIsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUFpRixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBOEIsSUFBQSwyQkFBQTtBQUMvRyxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxDQUFBO0FBQTJELElBQUEseUJBQUEsU0FBQSxTQUFBLHlFQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGFBQUEsWUFBQTtBQUFBLGFBQVMsMEJBQUEsV0FBQSxDQUFTO0lBQUEsQ0FBQTtBQUFFLElBQUEsd0JBQUEsR0FBQSxRQUFBLENBQUE7QUFBZ0MsSUFBQSwyQkFBQTtBQUNuSCxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsU0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQTJFLElBQUEscUJBQUEsSUFBQSxXQUFBO0FBQVMsSUFBQSwyQkFBQTtBQUNwRixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLG1LQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSx3QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUFpRSxJQUFBLDJCQUFBO0FBQ3pFLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBLEVBQUE7QUFBZ0YsSUFBQSxxQkFBQSxJQUFBLGlCQUFBO0FBQWUsSUFBQSwyQkFBQTtBQUMvRixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdVQUFBO0FBRUosSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSx3QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUFzRSxJQUFBLDJCQUFBO0FBQzlFLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBLEVBQUE7QUFBMkUsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBVSxJQUFBLDJCQUFBO0FBQ3JGLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsdUxBQUE7QUFDSixJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLHdCQUFBLElBQUEsT0FBQSxFQUFBO0FBQWlFLElBQUEsMkJBQUE7QUFDekUsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUEyRSxJQUFBLHFCQUFBLElBQUEsY0FBQTtBQUFZLElBQUEsMkJBQUE7QUFDdkYsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSw4RkFBQTtBQUFrRSxJQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQU0sSUFBQSwyQkFBQTtBQUFRLElBQUEscUJBQUEsSUFBQSxNQUFBO0FBQUcsSUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLElBQUEsV0FBQTtBQUFTLElBQUEsMkJBQUE7QUFBUSxJQUFBLHFCQUFBLElBQUEsMENBQUE7QUFDcEgsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBLEVBQUE7QUFBeUUsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBVSxJQUFBLDJCQUFBO0FBQ25GLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEseUpBQUE7QUFDSixJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLHdCQUFBLElBQUEsT0FBQSxFQUFBO0FBQStELElBQUEsMkJBQUE7QUFDdkUsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUEyRSxJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFVLElBQUEsMkJBQUE7QUFDckYsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx5SkFBQTtBQUNKLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsd0JBQUEsSUFBQSxPQUFBLEVBQUE7QUFBaUUsSUFBQSwyQkFBQTtBQUN6RSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQW1GLElBQUEscUJBQUEsSUFBQSxZQUFBO0FBQVUsSUFBQSwyQkFBQTtBQUM3RixJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHlKQUFBO0FBQ0osSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSx3QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUF5RSxJQUFBLDJCQUFBO0FBQ2pGLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEtBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEtBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsS0FBQSxNQUFBLEVBQUE7QUFBb0UsSUFBQSxxQkFBQSxLQUFBLGFBQUE7QUFBVyxJQUFBLDJCQUFBO0FBQy9FLElBQUEscUJBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsS0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEtBQUEsaUNBQUE7QUFBSyxJQUFBLDZCQUFBLEtBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsS0FBQSxRQUFBO0FBQU0sSUFBQSwyQkFBQTtBQUFRLElBQUEscUJBQUEsS0FBQSxPQUFBO0FBQUksSUFBQSw2QkFBQSxLQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEtBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUE7QUFBUSxJQUFBLHFCQUFBLEtBQUEsNERBQUE7QUFDckQsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsS0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEtBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEtBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsS0FBQSxNQUFBLEVBQUE7QUFBdUUsSUFBQSxxQkFBQSxLQUFBLGFBQUE7QUFBVyxJQUFBLDJCQUFBO0FBQ2xGLElBQUEscUJBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsS0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEtBQUEsaUNBQUE7QUFBSyxJQUFBLDZCQUFBLEtBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsS0FBQSxRQUFBO0FBQU0sSUFBQSwyQkFBQTtBQUFRLElBQUEscUJBQUEsS0FBQSxPQUFBO0FBQUksSUFBQSw2QkFBQSxLQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEtBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUE7QUFBUSxJQUFBLHFCQUFBLEtBQUEsNERBQUE7QUFDckQsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsS0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEtBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEtBQUEsSUFBQTtBQUNJLElBQUEscUJBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsS0FBQSxNQUFBLEVBQUE7QUFBa0UsSUFBQSxxQkFBQSxLQUFBLGFBQUE7QUFBVyxJQUFBLDJCQUFBO0FBQzdFLElBQUEscUJBQUEsS0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsS0FBQSxNQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEtBQUEsaUNBQUE7QUFBSyxJQUFBLDZCQUFBLEtBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsS0FBQSxRQUFBO0FBQU0sSUFBQSwyQkFBQTtBQUFRLElBQUEscUJBQUEsS0FBQSxPQUFBO0FBQUksSUFBQSw2QkFBQSxLQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEtBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUE7QUFBUSxJQUFBLHFCQUFBLEtBQUEsNERBQUE7QUFDckQsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsS0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEtBQUEsZ0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxLQUFBLFlBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxLQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxLQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxLQUFBLFVBQUEsRUFBQTtBQUE4QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSwyRUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxXQUFBLFlBQUE7QUFBQSxhQUFTLDBCQUFBLFNBQUEsQ0FBTztJQUFBLENBQUE7QUFBcUMsSUFBQSxxQkFBQSxLQUFBLE9BQUE7QUFBSyxJQUFBLDJCQUFBO0FBQzVHLElBQUEscUJBQUEsS0FBQSxZQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsS0FBQSxRQUFBOzs7Ozs7QUFJWSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQWdDLElBQUEseUJBQUEsU0FBQSxTQUFBLHVGQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxZQUFBLE1BQUEsMEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsUUFBQSxLQUFBLEdBQUEsQ0FBVTtJQUFBLENBQUE7QUFDL0MsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUE4QyxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFDOUMsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE4RCxJQUFBLHFCQUFBLEdBQUEsTUFBQTtBQUFJLElBQUEsMkJBQUE7QUFDdEUsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQUhpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxpQkFBQTs7Ozs7QUFLYixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBd0QsSUFBQSxxQkFBQSxHQUFBLG1CQUFBO0FBQWlCLElBQUEsMkJBQUE7QUFDN0UsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQUhpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsUUFBQSxPQUFBOzs7OztBQUtiLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE4RCxJQUFBLHFCQUFBLEdBQUEsaUJBQUE7QUFBZSxJQUFBLDJCQUFBO0FBQ2pGLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFIaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsT0FBQTs7Ozs7QUFLYixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBc0QsSUFBQSxxQkFBQSxHQUFBLFdBQUE7QUFBUyxJQUFBLDJCQUFBO0FBQ25FLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFIOEIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFFBQUEsYUFBQTs7Ozs7QUFyQmxDLElBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSw4REFBQSxHQUFBLENBQUEsRUFLQyxHQUFBLDhEQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsOERBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSw4REFBQSxHQUFBLENBQUE7QUFtQkwsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxRQUFBOzs7O0FBekJRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxDQUFBLE9BQUEsWUFBQSxPQUFBLGlCQUFBLElBQUEsRUFBQTtBQU1BLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLGVBQUEsQ0FBQSxPQUFBLFlBQUEsYUFBQSxDQUFBLE9BQUEsWUFBQSxXQUFBLElBQUEsRUFBQTtBQU1BLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLGVBQUEsT0FBQSxZQUFBLGFBQUEsQ0FBQSxPQUFBLFlBQUEsV0FBQSxJQUFBLEVBQUE7QUFNQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxlQUFBLE9BQUEsWUFBQSxXQUFBLElBQUEsRUFBQTs7Ozs7QUFXQSxJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxtQkFBQTs7Ozs7QUFJYixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsWUFBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxXQUFBOzs7Ozs7QUFLakIsSUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsbUNBQUEsRUFBQTtBQUE2RCxJQUFBLHlCQUFBLHFCQUFBLFNBQUEsNkdBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQTtBQUFBLGFBQXFCLDBCQUFBLFFBQUEsbUJBQUEsTUFBQSxDQUEwQjtJQUFBLENBQUE7QUFBd0IsSUFBQSwyQkFBQTtBQUN4SSxJQUFBLHFCQUFBLEdBQUEsUUFBQTs7OztBQURxQyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGVBQUEsT0FBQSxXQUFBLEVBQTJCLFlBQUEsT0FBQSxRQUFBOzs7QUQzSHBFLFVBZWE7QUFmYjs7QUFHQTtBQUNBO0FBQ0E7QUFHQTs7Ozs7QUFPTSxJQUFPLDBCQUFQLE1BQU8saUNBQWdDLGtCQUFpQjtNQXNCOUM7TUFDQTtNQXRCSCxpQkFBaUI7TUFDakIsa0JBQWtCO01BQ2xCO01BRVMsaUJBQXlDLElBQUlILGNBQVk7TUFFakUsb0JBQW9CLElBQUlBLGNBQVk7TUFFdEM7TUFHUixVQUFVO01BQ1YsVUFBVTtNQUNWLGdCQUFnQjtNQUNoQixvQkFBb0I7TUFFcEIsYUFBYTtNQUNiO01BQ0E7TUFFQSxZQUNZLGNBQ0EsbUJBQW9DO0FBRTVDLGNBQUs7QUFIRyxhQUFBLGVBQUE7QUFDQSxhQUFBLG9CQUFBO01BR1o7TUFPQSxrQkFBZTtBQUNYLGFBQUssd0JBQXVCO0FBQzVCLGFBQUssa0JBQWtCLHVCQUFzQixFQUFHLFVBQVUsQ0FBQyxRQUFPO0FBQzlELGNBQUksS0FBSztBQUNMLGlCQUFLLHlCQUF5QixLQUFLLEtBQUssZ0JBQWUsQ0FBRTs7UUFFakUsQ0FBQztBQUNELGFBQUssY0FBYTtBQUNsQixhQUFLLHFCQUFvQjtNQUM3QjtNQUtRLDBCQUF1QjtBQUMzQixZQUFJLEtBQUssZUFBZTtBQUNwQixlQUFLLGNBQWMsMkJBQTJCLEtBQUssaUJBQWlCO0FBQ3BFLGVBQUssY0FBYyxRQUFPOztBQUk5QixpQ0FBd0Isa0JBQWtCLEtBQUssUUFBUTtBQUV2RCxZQUFJLEtBQUssaUJBQWlCO0FBQ3RCLGVBQUssZ0JBQWdCLElBQUksY0FBYyxLQUFLLGdCQUFnQixlQUFlO1lBQ3ZFLE9BQU8sS0FBSztZQUNaLE1BQU0sWUFBWTtZQUNsQixVQUFVLEtBQUs7WUFDZixNQUFNLEtBQUssZUFBZUcsZ0JBQWU7WUFDekMsT0FBTztXQUNWO0FBRUQsZUFBSyxvQkFBb0IsS0FBSyxjQUFjLHVCQUF1QixDQUFDLFVBQW1CO0FBQ25GLGlCQUFLLGVBQWUsS0FBSyxLQUFLO1VBQ2xDLENBQUM7O01BRVQ7TUFNUSx1QkFBb0I7QUFFeEIsY0FBTSxrQkFBa0IsVUFBVSxLQUFLLFVBQVUsU0FBUyxLQUFLLGlCQUFpQixLQUFLLFVBQVUsTUFBTSxLQUFLLENBQUMsZ0JBQWdCLEtBQUssVUFBVSxTQUFTO0FBRW5KLFlBQUksS0FBSyxZQUFZLENBQUMsaUJBQWlCO0FBQ25DOztBQUdKLGdCQUFRLElBQUksb0ZBQW9GO0FBQ2hHLGdCQUFRLElBQUksaUlBQWlJO0FBRTdJLGFBQUssb0JBQW9CLE1BQUs7QUFDMUIsZ0JBQU0sWUFBWSxTQUFTLHFCQUFxQixNQUFNLEVBQUUsQ0FBQyxFQUFFO0FBQzNELGNBQUksY0FBYyxLQUFLLFlBQVk7QUFDL0Isa0JBQU0sT0FBTyxLQUFLO0FBR2xCLGtDQUFzQixNQUFNLE9BQU8sU0FBUyxFQUFFLEtBQUssTUFBTSxNQUFNLEdBQUcsVUFBVSxVQUFTLENBQUUsQ0FBQzs7UUFFaEc7QUFFQSxhQUFLLGlCQUFpQixNQUFLO0FBQ3ZCLGVBQUssYUFBYSxTQUFTLHFCQUFxQixNQUFNLEVBQUUsQ0FBQyxFQUFFO1FBQy9EO0FBRUEsaUJBQVMsaUJBQWlCLGFBQWEsS0FBSyxpQkFBaUI7QUFDN0QsaUJBQVMsaUJBQWlCLFVBQVUsS0FBSyxjQUFjO01BQzNEO01BRUEsSUFBSSx5QkFBc0I7QUFDdEIsZUFBTyxLQUFLLGlCQUFpQjtNQUNqQztNQVFRLE9BQU8sa0JBQWtCLFVBQWtCO0FBQy9DLFlBQUksVUFBVTtBQUNWLG1CQUFTLGNBQWMsQ0FBQTs7TUFFL0I7TUFNQSxrQkFBZTtBQUNYLGNBQU0sZUFBZSxLQUFLLGNBQWU7QUFDekMsaUNBQXdCLGtCQUFrQixZQUFZO0FBQ3RELGVBQU87TUFDWDtNQUtBLEtBQUssU0FBWTtBQUNiLGFBQUssYUFBYSxLQUFLLFNBQVMsRUFBRSxNQUFNLEtBQUksQ0FBRTtNQUNsRDtNQU1BLFlBQVksU0FBc0I7QUFDOUIsWUFBSSxRQUFRLGFBQWE7QUFFckIsZUFBSyx3QkFBdUI7O0FBR2hDLFlBQUksUUFBUSxZQUFZLFFBQVEsU0FBUyxnQkFBZ0IsS0FBSyxlQUFlO0FBQ3pFLGVBQUssV0FBVyxRQUFRLFNBQVM7QUFFakMsbUNBQXdCLGtCQUFrQixLQUFLLFFBQVE7QUFDdkQsZUFBSyxjQUFjLFFBQVEsS0FBSzs7TUFFeEM7TUFLQSxjQUFXO0FBQ1AsWUFBSSxLQUFLLGVBQWU7QUFDcEIsY0FBSSxLQUFLLG1CQUFtQjtBQUN4QixpQkFBSyxjQUFjLDJCQUEyQixLQUFLLGlCQUFpQjs7QUFFeEUsZUFBSyxjQUFjLFFBQU87QUFDMUIsZUFBSyxnQkFBZ0I7O0FBR3pCLFlBQUksS0FBSyxtQkFBbUI7QUFDeEIsbUJBQVMsb0JBQW9CLGFBQWEsS0FBSyxpQkFBaUI7QUFDaEUsbUJBQVMsb0JBQW9CLFVBQVUsS0FBSyxjQUFlOztNQUVuRTtNQU9BLHlCQUF5QixTQUFpQixVQUFrQjtBQUV4RCxjQUFNLGNBQWMsS0FBSyxpQkFBaUIsVUFBVSxNQUFNLFFBQVE7QUFDbEUsY0FBTSxlQUFlLEtBQUssaUJBQWlCLFdBQVcsTUFBTSxRQUFRO0FBQ3BFLFlBQUk7QUFFSixnQkFBUSxTQUFTO1VBRWIsS0FBSyxVQUFVLE1BQU07QUFDakIsa0JBQU0sZ0JBQWdCLEtBQUsscUJBQXFCLFVBQVUsV0FBVyxRQUFRO0FBQzdFLGtCQUFNLHFCQUFxQixlQUFlLGdCQUFnQixjQUFjLFVBQVUsWUFBWSxLQUFLO0FBQ25HLGlCQUFLLGtCQUFrQixxQkFBcUIsU0FBUyxrQkFBa0I7QUFDdkU7O1VBR0osS0FBSyxXQUFXLE1BQU07QUFDbEIsa0JBQU0saUJBQWlCLEtBQUsscUJBQXFCLFdBQVcsV0FBVyxRQUFRO0FBQy9FLGtCQUFNLHFCQUFxQixLQUFLLGtCQUFrQixXQUFXLFFBQVEsUUFBUTtBQUM3RSxrQkFBTSxzQkFDRixnQkFBZ0Isa0JBQWtCLHFCQUFxQixlQUFlLFVBQVUsYUFBYSxNQUFNLG1CQUFtQixVQUFVLGFBQWEsS0FBSztBQUN0SixpQkFBSyxrQkFBa0IscUJBQXFCLFNBQVMsbUJBQW1CO0FBQ3hFOztVQUdKLEtBQUssZUFBZSxNQUFNO0FBQ3RCLHVDQUEyQixPQUFPLE9BQU8sU0FBUyxhQUFhLEVBQUUsS0FDN0QsQ0FBQyxpQkFDRyxhQUFhLE9BQU8sWUFBWSxhQUFjLE1BQzlDLGFBQWEsT0FBTyxZQUFZLFlBQWEsTUFDN0MsYUFBYSxTQUFTLG9CQUFvQixnQkFBZ0I7QUFFbEUsaUJBQUssa0JBQWtCLHFCQUFxQixTQUFTLENBQUMsQ0FBQyx3QkFBd0I7QUFDL0U7OztNQUdaO01BT0EsaUJBQWlCLE1BQWMsVUFBa0I7QUFDN0MsZUFBTyxPQUFPLE9BQU8sU0FBUyxRQUFRLEVBQUUsS0FBSyxDQUFDLFlBQVksUUFBUSxLQUFLLEtBQUksTUFBTyxRQUFRLFFBQVEsU0FBUyxlQUFlLEtBQUs7TUFDbkk7TUFPQSxxQkFBcUIsV0FBbUIsVUFBa0I7QUFDdEQsZUFBTyxPQUFPLE9BQU8sU0FBUyxRQUFRLEVBQUUsS0FBSyxDQUFDLFlBQVksUUFBUSxLQUFLLFNBQVMsU0FBUyxLQUFLLFFBQVEsU0FBUyxlQUFlLGNBQWM7TUFDaEo7TUFPQSxrQkFBa0IsUUFBZ0IsVUFBa0I7QUFDaEQsZUFBTyxPQUFPLE9BQU8sU0FBUyxRQUFRLEVBQUUsS0FBSyxDQUFDLFlBQVksUUFBUSxLQUFLLFNBQVMsTUFBTSxLQUFLLFFBQVEsU0FBUyxlQUFlLFdBQVc7TUFDMUk7TUFLQSxJQUFJLGVBQVk7QUFDWixlQUFPLGFBQVk7TUFDdkI7TUFHQSxtQkFBbUIsVUFBZ0I7QUFDL0IsYUFBSyxrQkFBa0IsS0FBSyxRQUFRO0FBQ3BDLGFBQUssY0FBYztNQUN2Qjs7eUJBN1BTLDBCQUF1QixnQ0FBQSxZQUFBLEdBQUEsZ0NBQUEsaUJBQUEsQ0FBQTtNQUFBO2lFQUF2QiwwQkFBdUIsV0FBQSxDQUFBLENBQUEscUJBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxnQkFBQSxrQkFBQSxpQkFBQSxtQkFBQSxhQUFBLGNBQUEsR0FBQSxTQUFBLEVBQUEsZ0JBQUEsa0JBQUEsbUJBQUEsb0JBQUEsR0FBQSxVQUFBLENBQUEsMENBQUEsa0NBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsZUFBQSxpQkFBQSxHQUFBLENBQUEsUUFBQSxFQUFBLEdBQUEsQ0FBQSxHQUFBLG1CQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsbUJBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxHQUFBLENBQUEsbUJBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxnQkFBQSw2Q0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxjQUFBLFNBQUEsR0FBQSxhQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEseURBQUEsR0FBQSxDQUFBLGdCQUFBLHdEQUFBLEdBQUEsQ0FBQSxTQUFBLE9BQUEsT0FBQSx5Q0FBQSxHQUFBLENBQUEsZ0JBQUEsOERBQUEsR0FBQSxDQUFBLGdCQUFBLDZEQUFBLEdBQUEsQ0FBQSxTQUFBLE9BQUEsT0FBQSw4Q0FBQSxHQUFBLENBQUEsZ0JBQUEseURBQUEsR0FBQSxDQUFBLGdCQUFBLHdEQUFBLEdBQUEsQ0FBQSxTQUFBLE9BQUEsT0FBQSx5Q0FBQSxHQUFBLENBQUEsZ0JBQUEseURBQUEsR0FBQSxDQUFBLGdCQUFBLDBEQUFBLFdBQUEsR0FBQSxHQUFBLENBQUEsZ0JBQUEsdURBQUEsR0FBQSxDQUFBLGdCQUFBLHNEQUFBLEdBQUEsQ0FBQSxTQUFBLE9BQUEsT0FBQSx1Q0FBQSxHQUFBLENBQUEsZ0JBQUEseURBQUEsR0FBQSxDQUFBLGdCQUFBLHdEQUFBLEdBQUEsQ0FBQSxTQUFBLE9BQUEsT0FBQSx5Q0FBQSxHQUFBLENBQUEsZ0JBQUEsaUVBQUEsR0FBQSxDQUFBLGdCQUFBLGdFQUFBLEdBQUEsQ0FBQSxTQUFBLE9BQUEsT0FBQSxpREFBQSxHQUFBLENBQUEsZ0JBQUEsa0RBQUEsR0FBQSxDQUFBLGdCQUFBLG1EQUFBLFdBQUEsR0FBQSxHQUFBLENBQUEsZ0JBQUEscURBQUEsR0FBQSxDQUFBLGdCQUFBLHNEQUFBLFdBQUEsR0FBQSxHQUFBLENBQUEsZ0JBQUEsZ0RBQUEsR0FBQSxDQUFBLGdCQUFBLGlEQUFBLFdBQUEsR0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsZ0JBQUEsdUJBQUEsR0FBQSxPQUFBLGVBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsZUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsMENBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxjQUFBLEdBQUEsQ0FBQSxnQkFBQSxvQ0FBQSxHQUFBLENBQUEsR0FBQSxlQUFBLGNBQUEsR0FBQSxDQUFBLGdCQUFBLDBDQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsa0NBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxZQUFBLG1CQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsaUNBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNmcEMsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSx5QkFBQSxHQUFBLGdEQUFBLEtBQUEsR0FBQSxlQUFBLE1BQUEsR0FBQSxvQ0FBQTtBQWdGQSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxnREFBQSxHQUFBLENBQUE7QUE0QkEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLHdCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxpREFBQSxHQUFBLENBQUEsRUFJQyxJQUFBLGlEQUFBLEdBQUEsQ0FBQTtBQU1MLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSxpREFBQSxHQUFBLENBQUE7QUFHSixVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQTdDSSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsQ0FBQSxJQUFBLFlBQUEsQ0FBQSxJQUFBLGVBQUEsSUFBQSxFQUFBO0FBNEI4QyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDBCQUFBLGFBQUEsSUFBQSxhQUFBO0FBQWtDLFVBQUEseUJBQUEsV0FBQSw4QkFBQSxHQUFBQyxNQUFBLElBQUEsZUFBQSxTQUFBLEVBQUEsQ0FBQTtBQUU1RSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsSUFBQSxpQkFBQSxJQUFBLGNBQUEsbUJBQUEsS0FBQSxFQUFBO0FBS0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsaUJBQUEsSUFBQSxjQUFBLGlCQUFBLEtBQUEsRUFBQTtBQU1KLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLGtCQUFBLEtBQUEsRUFBQTs7Ozs7cUZEM0dTLHlCQUF1QixFQUFBLFdBQUEsMEJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFZHBDLFNBQVMsZ0JBQWdCOztBQUR6QixJQVVhO0FBVmI7OztBQUVBO0FBQ0E7QUFPTSxJQUFPLDhCQUFQLE1BQU8sNkJBQTJCOzt5QkFBM0IsOEJBQTJCO01BQUE7Z0VBQTNCLDZCQUEyQixDQUFBO29FQUoxQixtQkFBbUIsRUFBQSxDQUFBOzs7OyIsIm5hbWVzIjpbIkNvbXBvbmVudCIsIklucHV0IiwiQ29tcG9uZW50IiwiRXZlbnRFbWl0dGVyIiwiSW5wdXQiLCJPdXRwdXQiLCJVTUxEaWFncmFtVHlwZSIsIl9jMCJdfQ==