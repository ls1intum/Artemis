import {
  ArtemisCourseExerciseRowModule,
  init_course_exercise_row_module
} from "/chunk-O2UXKYID.js";
import {
  FileService,
  init_file_service
} from "/chunk-5FFTG5V3.js";
import {
  ArtemisMarkdownModule,
  init_markdown_module
} from "/chunk-UF4UUZTK.js";
import {
  ArtemisMarkdownService,
  init_markdown_service
} from "/chunk-7FP3FWGI.js";
import {
  ArtemisSharedComponentModule,
  CourseExerciseRowComponent,
  init_course_exercise_row_component,
  init_shared_component_module
} from "/chunk-ORYTP7RT.js";
import {
  htmlForMarkdown,
  init_markdown_conversion_util
} from "/chunk-EI7VZDEV.js";
import {
  ArtemisDatePipe,
  ArtemisSharedModule,
  ArtemisSharedPipesModule,
  ArtemisTranslatePipe,
  LectureUnit,
  LectureUnitType,
  SafeResourceUrlPipe,
  TranslateDirective,
  __esm,
  init_artemis_date_pipe,
  init_artemis_translate_pipe,
  init_course_model,
  init_lectureUnit_model,
  init_safe_resource_url_pipe,
  init_shared_module,
  init_shared_pipes_module,
  init_translate_directive
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/entities/lecture-unit/exerciseUnit.model.ts
var ExerciseUnit;
var init_exerciseUnit_model = __esm({
  "src/main/webapp/app/entities/lecture-unit/exerciseUnit.model.ts"() {
    init_lectureUnit_model();
    ExerciseUnit = class extends LectureUnit {
      exercise;
      constructor() {
        super(LectureUnitType.EXERCISE);
      }
    };
  }
});

// src/main/webapp/app/overview/course-lectures/exercise-unit/exercise-unit.component.ts
import { Component, HostBinding, Input, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
function ExerciseUnitComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n    ");
    i0.\u0275\u0275element(1, "jhi-course-exercise-row", 0);
    i0.\u0275\u0275text(2, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275property("exercise", ctx_r0.exerciseUnit.exercise)("course", ctx_r0.course)("hasGuidedTour", false)("isPresentationMode", ctx_r0.isPresentationMode);
  }
}
var ExerciseUnitComponent;
var init_exercise_unit_component = __esm({
  "src/main/webapp/app/overview/course-lectures/exercise-unit/exercise-unit.component.ts"() {
    init_course_model();
    init_exerciseUnit_model();
    init_course_exercise_row_component();
    ExerciseUnitComponent = class _ExerciseUnitComponent {
      componentClass;
      constructor() {
        this.componentClass = "exercise-unit";
      }
      exerciseUnit;
      course;
      isPresentationMode = false;
      static \u0275fac = function ExerciseUnitComponent_Factory(t) {
        return new (t || _ExerciseUnitComponent)();
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _ExerciseUnitComponent, selectors: [["jhi-exercise-unit"]], hostVars: 1, hostBindings: function ExerciseUnitComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.\u0275\u0275hostProperty("className", ctx.componentClass);
        }
      }, inputs: { exerciseUnit: "exerciseUnit", course: "course", isPresentationMode: "isPresentationMode" }, decls: 1, vars: 1, consts: [[1, "exercise-row", 3, "exercise", "course", "hasGuidedTour", "isPresentationMode"]], template: function ExerciseUnitComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275template(0, ExerciseUnitComponent_Conditional_0_Template, 3, 4);
        }
        if (rf & 2) {
          i0.\u0275\u0275conditional(0, (ctx.exerciseUnit == null ? null : ctx.exerciseUnit.exercise) && ctx.course ? 0 : -1);
        }
      }, dependencies: [CourseExerciseRowComponent], styles: ["/* src/main/webapp/app/overview/course-lectures/exercise-unit/exercise-unit.component.scss */\n.exercise-unit .exercise-row .course-exercise-row {\n  border: none !important;\n  box-shadow: 0 2px 6px 0 var(--lecture-unit-card-shadow) !important;\n}\n.exercise-unit .exercise-row .course-exercise-row:hover {\n  box-shadow: 0 2px 4px 0 var(--lecture-unit-card-hover-shadow) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9jb3Vyc2UtbGVjdHVyZXMvZXhlcmNpc2UtdW5pdC9leGVyY2lzZS11bml0LmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuZXhlcmNpc2UtdW5pdCB7XG4gICAgLmV4ZXJjaXNlLXJvdyB7XG4gICAgICAgIC5jb3Vyc2UtZXhlcmNpc2Utcm93IHtcbiAgICAgICAgICAgIGJvcmRlcjogbm9uZSAhaW1wb3J0YW50O1xuICAgICAgICAgICAgYm94LXNoYWRvdzogMCAycHggNnB4IDAgdmFyKC0tbGVjdHVyZS11bml0LWNhcmQtc2hhZG93KSAhaW1wb3J0YW50O1xuICAgICAgICB9XG5cbiAgICAgICAgLmNvdXJzZS1leGVyY2lzZS1yb3c6aG92ZXIge1xuICAgICAgICAgICAgYm94LXNoYWRvdzogMCAycHggNHB4IDAgdmFyKC0tbGVjdHVyZS11bml0LWNhcmQtaG92ZXItc2hhZG93KSAhaW1wb3J0YW50O1xuICAgICAgICB9XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUVRLENBQUEsY0FBQSxDQUFBLGFBQUEsQ0FBQTtBQUNJLFVBQUE7QUFDQSxjQUFBLEVBQUEsSUFBQSxJQUFBLEVBQUEsSUFBQTs7QUFHSixDQUxBLGNBS0EsQ0FMQSxhQUtBLENBTEEsbUJBS0E7QUFDSSxjQUFBLEVBQUEsSUFBQSxJQUFBLEVBQUEsSUFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(ExerciseUnitComponent, { className: "ExerciseUnitComponent" });
    })();
  }
});

// src/main/webapp/app/entities/lecture-unit/attachmentUnit.model.ts
var AttachmentUnit;
var init_attachmentUnit_model = __esm({
  "src/main/webapp/app/entities/lecture-unit/attachmentUnit.model.ts"() {
    init_lectureUnit_model();
    AttachmentUnit = class extends LectureUnit {
      description;
      attachment;
      slides;
      constructor() {
        super(LectureUnitType.ATTACHMENT);
      }
    };
  }
});

// src/main/webapp/app/overview/course-lectures/attachment-unit/attachment-unit.component.ts
import { Component as Component2, EventEmitter, Input as Input2, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faDownload, faFile, faFileArchive, faFileCode, faFileCsv, faFileExcel, faFileImage, faFileLines, faFilePdf, faFilePen, faFilePowerpoint, faFileWord } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { faSquare, faSquareCheck } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function AttachmentUnitComponent_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "span", 11);
    i02.\u0275\u0275pipe(2, "artemisTranslate");
    i02.\u0275\u0275pipe(3, "artemisDate");
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275propertyInterpolate2("ngbTooltip", "", i02.\u0275\u0275pipeBind1(2, 3, "artemisApp.attachmentUnit.notReleasedTooltip"), " ", i02.\u0275\u0275pipeBind1(3, 5, ctx_r0.attachmentUnit == null ? null : ctx_r0.attachmentUnit.attachment == null ? null : ctx_r0.attachmentUnit.attachment.releaseDate), "");
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate1("\n                            ", i02.\u0275\u0275pipeBind1(5, 7, "artemisApp.courseOverview.exerciseList.notReleased"), "\n                        ");
  }
}
function AttachmentUnitComponent_Conditional_27_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "fa-icon", 13);
    i02.\u0275\u0275listener("click", function AttachmentUnitComponent_Conditional_27_Conditional_3_Template_fa_icon_click_1_listener($event) {
      i02.\u0275\u0275restoreView(_r9);
      const ctx_r8 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r8.handleClick($event, false));
    });
    i02.\u0275\u0275pipe(2, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r6 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("icon", ctx_r6.faSquareCheck)("ngbTooltip", i02.\u0275\u0275pipeBind1(2, 2, "artemisApp.lectureUnit.completedTooltip"));
  }
}
function AttachmentUnitComponent_Conditional_27_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n                            ");
    i02.\u0275\u0275elementStart(1, "fa-icon", 14);
    i02.\u0275\u0275listener("click", function AttachmentUnitComponent_Conditional_27_Conditional_4_Template_fa_icon_click_1_listener($event) {
      i02.\u0275\u0275restoreView(_r11);
      const ctx_r10 = i02.\u0275\u0275nextContext(2);
      return i02.\u0275\u0275resetView(ctx_r10.handleClick($event, true));
    });
    i02.\u0275\u0275pipe(2, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r7 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("icon", ctx_r7.faSquare)("ngbTooltip", i02.\u0275\u0275pipeBind1(2, 2, "artemisApp.lectureUnit.uncompletedTooltip"));
  }
}
function AttachmentUnitComponent_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                    ");
    i02.\u0275\u0275elementStart(1, "div", 12);
    i02.\u0275\u0275text(2, "\n                        ");
    i02.\u0275\u0275template(3, AttachmentUnitComponent_Conditional_27_Conditional_3_Template, 4, 4)(4, AttachmentUnitComponent_Conditional_27_Conditional_4_Template, 4, 4);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r1 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, ctx_r1.attachmentUnit.completed ? 3 : 4);
  }
}
function AttachmentUnitComponent_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                    ");
    i02.\u0275\u0275elementStart(3, "span", 15);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6);
    i02.\u0275\u0275pipe(7, "artemisDate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n            ");
  }
  if (rf & 2) {
    const ctx_r2 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate1(" ", i02.\u0275\u0275pipeBind1(5, 2, "artemisApp.attachmentUnit.uploadDate"), ": ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                    ", i02.\u0275\u0275pipeBind1(7, 4, ctx_r2.attachmentUnit == null ? null : ctx_r2.attachmentUnit.attachment == null ? null : ctx_r2.attachmentUnit.attachment.uploadDate), "\n                ");
  }
}
function AttachmentUnitComponent_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                    ");
    i02.\u0275\u0275elementStart(3, "span", 15);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n            ");
  }
  if (rf & 2) {
    const ctx_r3 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate1(" ", i02.\u0275\u0275pipeBind1(5, 2, "artemisApp.attachmentUnit.version"), ": ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                    ", ctx_r3.attachmentUnit == null ? null : ctx_r3.attachmentUnit.attachment == null ? null : ctx_r3.attachmentUnit.attachment.version, "\n                ");
  }
}
function AttachmentUnitComponent_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                    ");
    i02.\u0275\u0275elementStart(3, "span", 15);
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275pipe(5, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n            ");
  }
  if (rf & 2) {
    const ctx_r4 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate1(" ", i02.\u0275\u0275pipeBind1(5, 2, "artemisApp.attachmentUnit.FileName"), ": ");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                    ", ctx_r4.getFileName(), "\n                ");
  }
}
function AttachmentUnitComponent_Conditional_35_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2, "\n                    ");
    i02.\u0275\u0275element(3, "hr");
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r5 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate1("\n                    ", ctx_r5.attachmentUnit == null ? null : ctx_r5.attachmentUnit.description, "\n                ");
  }
}
var AttachmentUnitComponent;
var init_attachment_unit_component = __esm({
  "src/main/webapp/app/overview/course-lectures/attachment-unit/attachment-unit.component.ts"() {
    init_attachmentUnit_model();
    init_file_service();
    init_file_service();
    init_translate_directive();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    AttachmentUnitComponent = class _AttachmentUnitComponent {
      fileService;
      attachmentUnit;
      isPresentationMode = false;
      onCompletion = new EventEmitter();
      isCollapsed = true;
      faDownload = faDownload;
      faSquare = faSquare;
      faSquareCheck = faSquareCheck;
      constructor(fileService) {
        this.fileService = fileService;
      }
      handleCollapse(event) {
        event.stopPropagation();
        this.isCollapsed = !this.isCollapsed;
      }
      downloadAttachment(event) {
        event.stopPropagation();
        if (this.attachmentUnit?.attachment?.link) {
          this.fileService.downloadFile(this.attachmentUnit?.attachment?.link);
          this.onCompletion.emit({ lectureUnit: this.attachmentUnit, completed: true });
        }
      }
      handleClick(event, completed) {
        event.stopPropagation();
        this.onCompletion.emit({ lectureUnit: this.attachmentUnit, completed });
      }
      getFileName() {
        if (this.attachmentUnit?.attachment?.link) {
          return this.attachmentUnit?.attachment?.link.substring(this.attachmentUnit?.attachment?.link.lastIndexOf("/") + 1);
        } else {
          return "";
        }
      }
      getAttachmentIcon() {
        if (this.attachmentUnit?.attachment?.link) {
          const fileExtension = this.attachmentUnit?.attachment?.link.split(".").pop().toLocaleLowerCase();
          switch (fileExtension) {
            case "png":
            case "jpg":
            case "jpeg":
            case "gif":
            case "svg":
              return faFileImage;
            case "pdf":
              return faFilePdf;
            case "zip":
            case "tar":
              return faFileArchive;
            case "txt":
            case "rtf":
            case "md":
              return faFileLines;
            case "htm":
            case "html":
            case "json":
              return faFileCode;
            case "doc":
            case "docx":
            case "pages":
            case "pages-tef":
            case "odt":
              return faFileWord;
            case "csv":
              return faFileCsv;
            case "xls":
            case "xlsx":
            case "numbers":
            case "ods":
              return faFileExcel;
            case "ppt":
            case "pptx":
            case "key":
            case "odp":
              return faFilePowerpoint;
            case "odg":
            case "odc":
            case "odi":
            case "odf":
              return faFilePen;
            default:
              return faFile;
          }
        }
        return faFile;
      }
      static \u0275fac = function AttachmentUnitComponent_Factory(t) {
        return new (t || _AttachmentUnitComponent)(i02.\u0275\u0275directiveInject(FileService));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _AttachmentUnitComponent, selectors: [["jhi-attachment-unit"]], inputs: { attachmentUnit: "attachmentUnit", isPresentationMode: "isPresentationMode" }, outputs: { onCompletion: "onCompletion" }, decls: 39, vars: 13, consts: [[1, "row", "align-items-center", "my-2", "px-2"], [1, "card", "unit-card"], [1, "card-header", "unit-card-header", "row", "align-content-center", "justify-content-between", 3, "click"], [1, "col-auto", "row", "align-content-center", "flex-shrink-1"], [1, "m-0", "fw-medium"], [1, "me-2", 3, "icon", "ngbTooltip"], [1, "col-auto", "d-flex", "align-items-center", "gap-3", "pe-2"], ["id", "downloadButton", 1, "btn", "btn-primary", "btn-sm", 3, "click"], [3, "icon"], ["jhiTranslate", "artemisApp.attachmentUnit.download", 1, "d-none", "d-md-inline"], [1, "card-body", "unit-card-body", 3, "ngbCollapse"], [1, "badge", "bg-warning", "ms-2", 3, "ngbTooltip"], [1, "col-auto"], ["size", "lg", 1, "text-success", 3, "icon", "ngbTooltip", "click"], ["size", "lg", 1, "text-body-secondary", 3, "icon", "ngbTooltip", "click"], [1, "font-weight-bold"]], template: function AttachmentUnitComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div", 0);
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275elementStart(2, "div", 1);
          i02.\u0275\u0275text(3, "\n        ");
          i02.\u0275\u0275elementStart(4, "div", 2);
          i02.\u0275\u0275listener("click", function AttachmentUnitComponent_Template_div_click_4_listener($event) {
            return ctx.handleCollapse($event);
          });
          i02.\u0275\u0275text(5, "\n            ");
          i02.\u0275\u0275elementStart(6, "div", 3);
          i02.\u0275\u0275text(7, "\n                ");
          i02.\u0275\u0275elementStart(8, "h5", 4);
          i02.\u0275\u0275text(9, "\n                    ");
          i02.\u0275\u0275elementStart(10, "fa-icon", 5);
          i02.\u0275\u0275pipe(11, "artemisTranslate");
          i02.\u0275\u0275text(12, " ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(13);
          i02.\u0275\u0275template(14, AttachmentUnitComponent_Conditional_14_Template, 7, 9);
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(15, "\n            ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(16, "\n            ");
          i02.\u0275\u0275elementStart(17, "div", 6);
          i02.\u0275\u0275text(18, "\n                ");
          i02.\u0275\u0275elementStart(19, "button", 7);
          i02.\u0275\u0275listener("click", function AttachmentUnitComponent_Template_button_click_19_listener($event) {
            return ctx.downloadAttachment($event);
          });
          i02.\u0275\u0275text(20, "\n                    ");
          i02.\u0275\u0275element(21, "fa-icon", 8);
          i02.\u0275\u0275text(22, "\n                    ");
          i02.\u0275\u0275elementStart(23, "span", 9);
          i02.\u0275\u0275text(24, "Download");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(25, "\n                ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(26, "\n                ");
          i02.\u0275\u0275template(27, AttachmentUnitComponent_Conditional_27_Template, 6, 1);
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(28, "\n        ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(29, "\n        ");
          i02.\u0275\u0275elementStart(30, "div", 10);
          i02.\u0275\u0275text(31, "\n            ");
          i02.\u0275\u0275template(32, AttachmentUnitComponent_Conditional_32_Template, 9, 6)(33, AttachmentUnitComponent_Conditional_33_Template, 8, 4)(34, AttachmentUnitComponent_Conditional_34_Template, 8, 4)(35, AttachmentUnitComponent_Conditional_35_Template, 6, 1);
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(36, "\n    ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(37, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(38, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(10);
          i02.\u0275\u0275property("icon", ctx.getAttachmentIcon())("ngbTooltip", i02.\u0275\u0275pipeBind1(11, 11, "artemisApp.attachmentUnit.tooltip"));
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275textInterpolate1("\n                    ", (ctx.attachmentUnit == null ? null : ctx.attachmentUnit.attachment == null ? null : ctx.attachmentUnit.attachment.name) ? ctx.attachmentUnit == null ? null : ctx.attachmentUnit.attachment == null ? null : ctx.attachmentUnit.attachment.name : "", "\n                    ");
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(14, !(ctx.attachmentUnit == null ? null : ctx.attachmentUnit.visibleToStudents) ? 14 : -1);
          i02.\u0275\u0275advance(7);
          i02.\u0275\u0275property("icon", ctx.faDownload);
          i02.\u0275\u0275advance(6);
          i02.\u0275\u0275conditional(27, !ctx.isPresentationMode && ctx.attachmentUnit.visibleToStudents ? 27 : -1);
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275property("ngbCollapse", ctx.isCollapsed);
          i02.\u0275\u0275advance(2);
          i02.\u0275\u0275conditional(32, (ctx.attachmentUnit == null ? null : ctx.attachmentUnit.attachment == null ? null : ctx.attachmentUnit.attachment.uploadDate) ? 32 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(33, (ctx.attachmentUnit == null ? null : ctx.attachmentUnit.attachment == null ? null : ctx.attachmentUnit.attachment.version) ? 33 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(34, (ctx.attachmentUnit == null ? null : ctx.attachmentUnit.attachment == null ? null : ctx.attachmentUnit.attachment.link) ? 34 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(35, (ctx.attachmentUnit == null ? null : ctx.attachmentUnit.description) ? 35 : -1);
        }
      }, dependencies: [i2.NgbCollapse, i2.NgbTooltip, i3.FaIconComponent, TranslateDirective, ArtemisDatePipe, ArtemisTranslatePipe], styles: ["\n\n.unit-card[_ngcontent-%COMP%] {\n  border-radius: 3px;\n  box-shadow: 0 2px 6px 0 var(--lecture-unit-card-shadow);\n  min-width: 100%;\n  border: none;\n  transition: box-shadow 0.1s linear;\n}\n.unit-card[_ngcontent-%COMP%]:hover {\n  box-shadow: 0 2px 4px 0 var(--lecture-unit-card-hover-shadow);\n}\n.unit-card-body[_ngcontent-%COMP%] {\n  background-color: var(--lecture-unit-card-body-background);\n  border-radius: 0 0 8px 8px;\n}\n.unit-card-header[_ngcontent-%COMP%] {\n  min-height: 50px;\n  min-width: 100%;\n  border-radius: 3px 3px 0 0;\n  background-color: var(--overview-light-background-color);\n  cursor: pointer;\n  flex-wrap: nowrap !important;\n}\n.unit-card-header[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child {\n  padding-left: 0.5rem;\n}\n@media (max-width: 575.98px) {\n  .unit-card-header[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child {\n    padding: 0 !important;\n  }\n}\n.rounded[_ngcontent-%COMP%] {\n  border-radius: 3px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9jb3Vyc2UtbGVjdHVyZXMvbGVjdHVyZS11bml0LmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIudW5pdC1jYXJkIHtcbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgYm94LXNoYWRvdzogMCAycHggNnB4IDAgdmFyKC0tbGVjdHVyZS11bml0LWNhcmQtc2hhZG93KTtcbiAgICBtaW4td2lkdGg6IDEwMCU7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIHRyYW5zaXRpb246IGJveC1zaGFkb3cgMC4xcyBsaW5lYXI7XG59XG5cbi51bml0LWNhcmQ6aG92ZXIge1xuICAgIGJveC1zaGFkb3c6IDAgMnB4IDRweCAwIHZhcigtLWxlY3R1cmUtdW5pdC1jYXJkLWhvdmVyLXNoYWRvdyk7XG59XG5cbi51bml0LWNhcmQtYm9keSB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbGVjdHVyZS11bml0LWNhcmQtYm9keS1iYWNrZ3JvdW5kKTtcbiAgICBib3JkZXItcmFkaXVzOiAwIDAgOHB4IDhweDtcbn1cblxuLnVuaXQtY2FyZC1oZWFkZXIge1xuICAgIG1pbi1oZWlnaHQ6IDUwcHg7XG4gICAgbWluLXdpZHRoOiAxMDAlO1xuICAgIGJvcmRlci1yYWRpdXM6IDNweCAzcHggMCAwO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLW92ZXJ2aWV3LWxpZ2h0LWJhY2tncm91bmQtY29sb3IpO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBmbGV4LXdyYXA6IG5vd3JhcCAhaW1wb3J0YW50O1xuXG4gICAgPiBkaXY6Zmlyc3QtY2hpbGQge1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDAuNXJlbTtcblxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNTc1Ljk4cHgpIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnJvdW5kZWQge1xuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksaUJBQUE7QUFDQSxjQUFBLEVBQUEsSUFBQSxJQUFBLEVBQUEsSUFBQTtBQUNBLGFBQUE7QUFDQSxVQUFBO0FBQ0EsY0FBQSxXQUFBLEtBQUE7O0FBR0osQ0FSQSxTQVFBO0FBQ0ksY0FBQSxFQUFBLElBQUEsSUFBQSxFQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxpQkFBQSxFQUFBLEVBQUEsSUFBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQTtBQUNBLGFBQUE7QUFDQSxpQkFBQSxJQUFBLElBQUEsRUFBQTtBQUNBLG9CQUFBLElBQUE7QUFDQSxVQUFBO0FBQ0EsYUFBQTs7QUFFQSxDQVJKLGlCQVFJLEVBQUEsR0FBQTtBQUNJLGdCQUFBOztBQUVBLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFISixHQVJKLGlCQVFJLEVBQUEsR0FBQTtBQUlRLGFBQUE7OztBQUtaLENBQUE7QUFDSSxpQkFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(AttachmentUnitComponent, { className: "AttachmentUnitComponent" });
    })();
  }
});

// src/main/webapp/app/entities/lecture-unit/videoUnit.model.ts
var VideoUnit;
var init_videoUnit_model = __esm({
  "src/main/webapp/app/entities/lecture-unit/videoUnit.model.ts"() {
    init_lectureUnit_model();
    VideoUnit = class extends LectureUnit {
      description;
      source;
      constructor() {
        super(LectureUnitType.VIDEO);
      }
    };
  }
});

// src/main/webapp/app/overview/course-lectures/video-unit/video-unit.component.ts
import { Component as Component3, EventEmitter as EventEmitter2, Input as Input3, Output as Output2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faVideo } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import __vite__cjsImport17_jsVideoUrlParser from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/js-video-url-parser.js?v=1d0d9ead"; const urlParser = __vite__cjsImport17_jsVideoUrlParser.__esModule ? __vite__cjsImport17_jsVideoUrlParser.default : __vite__cjsImport17_jsVideoUrlParser;
import { faSquare as faSquare2, faSquareCheck as faSquareCheck2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function VideoUnitComponent_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                        ");
    i03.\u0275\u0275elementStart(1, "span", 7);
    i03.\u0275\u0275pipe(2, "artemisTranslate");
    i03.\u0275\u0275pipe(3, "artemisDate");
    i03.\u0275\u0275text(4);
    i03.\u0275\u0275pipe(5, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(6, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r0 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275propertyInterpolate2("ngbTooltip", "", i03.\u0275\u0275pipeBind1(2, 3, "artemisApp.videoUnit.notReleasedTooltip"), " ", i03.\u0275\u0275pipeBind1(3, 5, ctx_r0.videoUnit == null ? null : ctx_r0.videoUnit.releaseDate), "");
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275textInterpolate1("\n                            ", i03.\u0275\u0275pipeBind1(5, 7, "artemisApp.courseOverview.exerciseList.notReleased"), "\n                        ");
  }
}
function VideoUnitComponent_Conditional_17_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n                        ");
    i03.\u0275\u0275elementStart(1, "fa-icon", 9);
    i03.\u0275\u0275listener("click", function VideoUnitComponent_Conditional_17_Conditional_3_Template_fa_icon_click_1_listener($event) {
      i03.\u0275\u0275restoreView(_r6);
      const ctx_r5 = i03.\u0275\u0275nextContext(2);
      return i03.\u0275\u0275resetView(ctx_r5.handleClick($event, false));
    });
    i03.\u0275\u0275pipe(2, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r3 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("icon", ctx_r3.faSquareCheck)("ngbTooltip", i03.\u0275\u0275pipeBind1(2, 2, "artemisApp.lectureUnit.completedTooltip"));
  }
}
function VideoUnitComponent_Conditional_17_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i03.\u0275\u0275getCurrentView();
    i03.\u0275\u0275text(0, "\n                        ");
    i03.\u0275\u0275elementStart(1, "fa-icon", 10);
    i03.\u0275\u0275listener("click", function VideoUnitComponent_Conditional_17_Conditional_4_Template_fa_icon_click_1_listener($event) {
      i03.\u0275\u0275restoreView(_r8);
      const ctx_r7 = i03.\u0275\u0275nextContext(2);
      return i03.\u0275\u0275resetView(ctx_r7.handleClick($event, true));
    });
    i03.\u0275\u0275pipe(2, "artemisTranslate");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r4 = i03.\u0275\u0275nextContext(2);
    i03.\u0275\u0275advance(1);
    i03.\u0275\u0275property("icon", ctx_r4.faSquare)("ngbTooltip", i03.\u0275\u0275pipeBind1(2, 2, "artemisApp.lectureUnit.uncompletedTooltip"));
  }
}
function VideoUnitComponent_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275elementStart(1, "div", 8);
    i03.\u0275\u0275text(2, "\n                    ");
    i03.\u0275\u0275template(3, VideoUnitComponent_Conditional_17_Conditional_3_Template, 4, 4)(4, VideoUnitComponent_Conditional_17_Conditional_4_Template, 4, 4);
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r1 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275conditional(3, ctx_r1.videoUnit.completed ? 3 : 4);
  }
}
function VideoUnitComponent_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    i03.\u0275\u0275text(0, "\n                ");
    i03.\u0275\u0275elementStart(1, "div", 11);
    i03.\u0275\u0275text(2, "\n                    ");
    i03.\u0275\u0275element(3, "iframe", 12);
    i03.\u0275\u0275pipe(4, "safeResourceUrl");
    i03.\u0275\u0275text(5, "\n                ");
    i03.\u0275\u0275elementEnd();
    i03.\u0275\u0275text(6, "\n            ");
  }
  if (rf & 2) {
    const ctx_r2 = i03.\u0275\u0275nextContext();
    i03.\u0275\u0275advance(3);
    i03.\u0275\u0275property("src", i03.\u0275\u0275pipeBind1(4, 1, ctx_r2.videoUrl), i03.\u0275\u0275sanitizeResourceUrl);
  }
}
var VideoUnitComponent;
var init_video_unit_component = __esm({
  "src/main/webapp/app/overview/course-lectures/video-unit/video-unit.component.ts"() {
    init_videoUnit_model();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    init_safe_resource_url_pipe();
    VideoUnitComponent = class _VideoUnitComponent {
      videoUnit;
      isPresentationMode = false;
      onCompletion = new EventEmitter2();
      videoUrl;
      isCollapsed = true;
      completionTimeout;
      videoUrlAllowList = [
        RegExp("^https://live\\.rbg\\.tum\\.de/w/\\w+/\\d+(/(CAM|COMB|PRES))?\\?video_only=1$")
      ];
      faVideo = faVideo;
      faSquare = faSquare2;
      faSquareCheck = faSquareCheck2;
      constructor() {
      }
      ngOnInit() {
        if (this.videoUnit?.source) {
          if (this.videoUrlAllowList.some((r) => r.test(this.videoUnit.source)) || !urlParser || urlParser.parse(this.videoUnit.source)) {
            this.videoUrl = this.videoUnit.source;
          }
        }
      }
      handleCollapse(event) {
        event.stopPropagation();
        this.isCollapsed = !this.isCollapsed;
        if (!this.isCollapsed) {
          this.completionTimeout = setTimeout(() => {
            this.onCompletion.emit({ lectureUnit: this.videoUnit, completed: true });
          }, 1e3 * 60 * 5);
        } else {
          clearTimeout(this.completionTimeout);
        }
      }
      handleClick(event, completed) {
        event.stopPropagation();
        this.onCompletion.emit({ lectureUnit: this.videoUnit, completed });
      }
      static \u0275fac = function VideoUnitComponent_Factory(t) {
        return new (t || _VideoUnitComponent)();
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _VideoUnitComponent, selectors: [["jhi-video-unit"]], inputs: { videoUnit: "videoUnit", isPresentationMode: "isPresentationMode" }, outputs: { onCompletion: "onCompletion" }, decls: 26, vars: 10, consts: [[1, "row", "align-items-center", "my-2", "px-2"], [1, "card", "unit-card"], [1, "card-header", "unit-card-header", "row", "align-content-center", "justify-content-between", 3, "click"], [1, "col-auto", "row", "align-content-center", "flex-shrink-1"], [1, "m-0", "fw-medium"], [1, "me-2", 3, "icon", "ngbTooltip"], [1, "card-body", "unit-card-body", 3, "ngbCollapse"], [1, "badge", "bg-warning", "ms-2", 3, "ngbTooltip"], [1, "col-auto", "d-flex", "align-items-center", "gap-3", "pe-2"], ["size", "lg", 1, "text-success", 3, "icon", "ngbTooltip", "click"], ["size", "lg", 1, "text-body-secondary", 3, "icon", "ngbTooltip", "click"], [1, "ratio", "ratio-16x9"], ["id", "videoFrame", "allow", "fullscreen", 1, "rounded", 3, "src"]], template: function VideoUnitComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "div", 0);
          i03.\u0275\u0275text(1, "\n    ");
          i03.\u0275\u0275elementStart(2, "div", 1);
          i03.\u0275\u0275text(3, "\n        ");
          i03.\u0275\u0275elementStart(4, "div", 2);
          i03.\u0275\u0275listener("click", function VideoUnitComponent_Template_div_click_4_listener($event) {
            return ctx.handleCollapse($event);
          });
          i03.\u0275\u0275text(5, "\n            ");
          i03.\u0275\u0275elementStart(6, "div", 3);
          i03.\u0275\u0275text(7, "\n                ");
          i03.\u0275\u0275elementStart(8, "h5", 4);
          i03.\u0275\u0275text(9, "\n                    ");
          i03.\u0275\u0275elementStart(10, "fa-icon", 5);
          i03.\u0275\u0275pipe(11, "artemisTranslate");
          i03.\u0275\u0275text(12, " ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(13);
          i03.\u0275\u0275template(14, VideoUnitComponent_Conditional_14_Template, 7, 9);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(15, "\n            ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(16, "\n            ");
          i03.\u0275\u0275template(17, VideoUnitComponent_Conditional_17_Template, 6, 1);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(18, "\n        ");
          i03.\u0275\u0275elementStart(19, "div", 6);
          i03.\u0275\u0275text(20, "\n            ");
          i03.\u0275\u0275template(21, VideoUnitComponent_Conditional_21_Template, 7, 3);
          i03.\u0275\u0275text(22);
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(23, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(24, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(25, "\n");
        }
        if (rf & 2) {
          i03.\u0275\u0275advance(10);
          i03.\u0275\u0275property("icon", ctx.faVideo)("ngbTooltip", i03.\u0275\u0275pipeBind1(11, 8, "artemisApp.videoUnit.tooltip"));
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275textInterpolate1("\n                    ", (ctx.videoUnit == null ? null : ctx.videoUnit.name) ? ctx.videoUnit.name : "", "\n                    ");
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275conditional(14, !(ctx.videoUnit == null ? null : ctx.videoUnit.visibleToStudents) ? 14 : -1);
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275conditional(17, !ctx.isPresentationMode && ctx.videoUnit.visibleToStudents ? 17 : -1);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275property("ngbCollapse", ctx.isCollapsed);
          i03.\u0275\u0275advance(2);
          i03.\u0275\u0275conditional(21, !ctx.isCollapsed ? 21 : -1);
          i03.\u0275\u0275advance(1);
          i03.\u0275\u0275textInterpolate1("\n            ", ctx.videoUnit == null ? null : ctx.videoUnit.description, "\n        ");
        }
      }, dependencies: [i1.NgbCollapse, i1.NgbTooltip, i22.FaIconComponent, ArtemisDatePipe, ArtemisTranslatePipe, SafeResourceUrlPipe], styles: ["\n\n.unit-card[_ngcontent-%COMP%] {\n  border-radius: 3px;\n  box-shadow: 0 2px 6px 0 var(--lecture-unit-card-shadow);\n  min-width: 100%;\n  border: none;\n  transition: box-shadow 0.1s linear;\n}\n.unit-card[_ngcontent-%COMP%]:hover {\n  box-shadow: 0 2px 4px 0 var(--lecture-unit-card-hover-shadow);\n}\n.unit-card-body[_ngcontent-%COMP%] {\n  background-color: var(--lecture-unit-card-body-background);\n  border-radius: 0 0 8px 8px;\n}\n.unit-card-header[_ngcontent-%COMP%] {\n  min-height: 50px;\n  min-width: 100%;\n  border-radius: 3px 3px 0 0;\n  background-color: var(--overview-light-background-color);\n  cursor: pointer;\n  flex-wrap: nowrap !important;\n}\n.unit-card-header[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child {\n  padding-left: 0.5rem;\n}\n@media (max-width: 575.98px) {\n  .unit-card-header[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child {\n    padding: 0 !important;\n  }\n}\n.rounded[_ngcontent-%COMP%] {\n  border-radius: 3px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9jb3Vyc2UtbGVjdHVyZXMvbGVjdHVyZS11bml0LmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIudW5pdC1jYXJkIHtcbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgYm94LXNoYWRvdzogMCAycHggNnB4IDAgdmFyKC0tbGVjdHVyZS11bml0LWNhcmQtc2hhZG93KTtcbiAgICBtaW4td2lkdGg6IDEwMCU7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIHRyYW5zaXRpb246IGJveC1zaGFkb3cgMC4xcyBsaW5lYXI7XG59XG5cbi51bml0LWNhcmQ6aG92ZXIge1xuICAgIGJveC1zaGFkb3c6IDAgMnB4IDRweCAwIHZhcigtLWxlY3R1cmUtdW5pdC1jYXJkLWhvdmVyLXNoYWRvdyk7XG59XG5cbi51bml0LWNhcmQtYm9keSB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbGVjdHVyZS11bml0LWNhcmQtYm9keS1iYWNrZ3JvdW5kKTtcbiAgICBib3JkZXItcmFkaXVzOiAwIDAgOHB4IDhweDtcbn1cblxuLnVuaXQtY2FyZC1oZWFkZXIge1xuICAgIG1pbi1oZWlnaHQ6IDUwcHg7XG4gICAgbWluLXdpZHRoOiAxMDAlO1xuICAgIGJvcmRlci1yYWRpdXM6IDNweCAzcHggMCAwO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLW92ZXJ2aWV3LWxpZ2h0LWJhY2tncm91bmQtY29sb3IpO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBmbGV4LXdyYXA6IG5vd3JhcCAhaW1wb3J0YW50O1xuXG4gICAgPiBkaXY6Zmlyc3QtY2hpbGQge1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDAuNXJlbTtcblxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNTc1Ljk4cHgpIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnJvdW5kZWQge1xuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksaUJBQUE7QUFDQSxjQUFBLEVBQUEsSUFBQSxJQUFBLEVBQUEsSUFBQTtBQUNBLGFBQUE7QUFDQSxVQUFBO0FBQ0EsY0FBQSxXQUFBLEtBQUE7O0FBR0osQ0FSQSxTQVFBO0FBQ0ksY0FBQSxFQUFBLElBQUEsSUFBQSxFQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxpQkFBQSxFQUFBLEVBQUEsSUFBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQTtBQUNBLGFBQUE7QUFDQSxpQkFBQSxJQUFBLElBQUEsRUFBQTtBQUNBLG9CQUFBLElBQUE7QUFDQSxVQUFBO0FBQ0EsYUFBQTs7QUFFQSxDQVJKLGlCQVFJLEVBQUEsR0FBQTtBQUNJLGdCQUFBOztBQUVBLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFISixHQVJKLGlCQVFJLEVBQUEsR0FBQTtBQUlRLGFBQUE7OztBQUtaLENBQUE7QUFDSSxpQkFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(VideoUnitComponent, { className: "VideoUnitComponent" });
    })();
  }
});

// src/main/webapp/app/entities/lecture-unit/textUnit.model.ts
var TextUnit;
var init_textUnit_model = __esm({
  "src/main/webapp/app/entities/lecture-unit/textUnit.model.ts"() {
    init_lectureUnit_model();
    TextUnit = class extends LectureUnit {
      content;
      constructor() {
        super(LectureUnitType.TEXT);
      }
    };
  }
});

// src/main/webapp/app/overview/course-lectures/text-unit/text-unit.component.ts
import { Component as Component4, EventEmitter as EventEmitter3, Input as Input4, Output as Output3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faExternalLinkAlt, faScroll } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { faSquare as faSquare3, faSquareCheck as faSquareCheck3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i23 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function TextUnitComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span", 11);
    i04.\u0275\u0275pipe(2, "artemisTranslate");
    i04.\u0275\u0275pipe(3, "artemisDate");
    i04.\u0275\u0275text(4);
    i04.\u0275\u0275pipe(5, "artemisTranslate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(6, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275propertyInterpolate2("ngbTooltip", "", i04.\u0275\u0275pipeBind1(2, 3, "artemisApp.textUnit.notReleasedTooltip"), " ", i04.\u0275\u0275pipeBind1(3, 5, ctx_r0.textUnit == null ? null : ctx_r0.textUnit.releaseDate), "");
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275textInterpolate1("\n                            ", i04.\u0275\u0275pipeBind1(5, 7, "artemisApp.courseOverview.exerciseList.notReleased"), "\n                        ");
  }
}
function TextUnitComponent_Conditional_26_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                            ");
    i04.\u0275\u0275elementStart(1, "fa-icon", 13);
    i04.\u0275\u0275listener("click", function TextUnitComponent_Conditional_26_Conditional_3_Template_fa_icon_click_1_listener($event) {
      i04.\u0275\u0275restoreView(_r6);
      const ctx_r5 = i04.\u0275\u0275nextContext(2);
      return i04.\u0275\u0275resetView(ctx_r5.handleClick($event, false));
    });
    i04.\u0275\u0275pipe(2, "artemisTranslate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r3 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("icon", ctx_r3.faSquareCheck)("ngbTooltip", i04.\u0275\u0275pipeBind1(2, 2, "artemisApp.lectureUnit.completedTooltip"));
  }
}
function TextUnitComponent_Conditional_26_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                            ");
    i04.\u0275\u0275elementStart(1, "fa-icon", 14);
    i04.\u0275\u0275listener("click", function TextUnitComponent_Conditional_26_Conditional_4_Template_fa_icon_click_1_listener($event) {
      i04.\u0275\u0275restoreView(_r8);
      const ctx_r7 = i04.\u0275\u0275nextContext(2);
      return i04.\u0275\u0275resetView(ctx_r7.handleClick($event, true));
    });
    i04.\u0275\u0275pipe(2, "artemisTranslate");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r4 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("icon", ctx_r4.faSquare)("ngbTooltip", i04.\u0275\u0275pipeBind1(2, 2, "artemisApp.lectureUnit.uncompletedTooltip"));
  }
}
function TextUnitComponent_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                    ");
    i04.\u0275\u0275elementStart(1, "div", 12);
    i04.\u0275\u0275text(2, "\n                        ");
    i04.\u0275\u0275template(3, TextUnitComponent_Conditional_26_Conditional_3_Template, 4, 4)(4, TextUnitComponent_Conditional_26_Conditional_4_Template, 4, 4);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r1 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275conditional(3, ctx_r1.textUnit.completed ? 3 : 4);
  }
}
function TextUnitComponent_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "div");
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275element(3, "div", 15);
    i04.\u0275\u0275text(4, "\n                ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n            ");
  }
  if (rf & 2) {
    const ctx_r2 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("innerHtml", ctx_r2.formattedContent, i04.\u0275\u0275sanitizeHtml);
  }
}
var TextUnitComponent;
var init_text_unit_component = __esm({
  "src/main/webapp/app/overview/course-lectures/text-unit/text-unit.component.ts"() {
    init_textUnit_model();
    init_markdown_service();
    init_markdown_conversion_util();
    init_markdown_service();
    init_translate_directive();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    TextUnitComponent = class _TextUnitComponent {
      artemisMarkdown;
      textUnit;
      isPresentationMode = false;
      onCompletion = new EventEmitter3();
      isCollapsed = true;
      formattedContent;
      faExternalLinkAlt = faExternalLinkAlt;
      faScroll = faScroll;
      faSquare = faSquare3;
      faSquareCheck = faSquareCheck3;
      constructor(artemisMarkdown) {
        this.artemisMarkdown = artemisMarkdown;
      }
      ngOnInit() {
        if (this.textUnit?.content) {
          this.formattedContent = this.artemisMarkdown.safeHtmlForMarkdown(this.textUnit.content);
        }
      }
      handleCollapse(event) {
        event.stopPropagation();
        this.isCollapsed = !this.isCollapsed;
        if (!this.isCollapsed) {
          this.onCompletion.emit({ lectureUnit: this.textUnit, completed: true });
        }
      }
      handleClick(event, completed) {
        event.stopPropagation();
        this.onCompletion.emit({ lectureUnit: this.textUnit, completed });
      }
      openPopup(event) {
        event.stopPropagation();
        const win = window.open("about:blank", "_blank");
        win.document.write(`<html><head><title>${this.textUnit.name}</title>`);
        win.document.write('<link rel="stylesheet" href="public/content/github-markdown.css">');
        win.document.write('</head><body class="markdown-body">');
        win.document.write("</body></html>");
        win.document.close();
        win.document.body.innerHTML = htmlForMarkdown(this.textUnit.content, []);
        win.focus();
      }
      static \u0275fac = function TextUnitComponent_Factory(t) {
        return new (t || _TextUnitComponent)(i04.\u0275\u0275directiveInject(ArtemisMarkdownService));
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _TextUnitComponent, selectors: [["jhi-text-unit"]], inputs: { textUnit: "textUnit", isPresentationMode: "isPresentationMode" }, outputs: { onCompletion: "onCompletion" }, decls: 35, vars: 10, consts: [[1, "row", "align-items-center", "my-2", "px-2"], [1, "card", "unit-card"], [1, "card-header", "unit-card-header", "row", "align-content-center", "justify-content-between", 3, "click"], [1, "col-auto", "row", "align-content-center", "flex-shrink-1"], [1, "m-0", "fw-medium"], [1, "me-2", 3, "icon", "ngbTooltip"], [1, "col-auto", "d-flex", "align-items-center", "gap-3", "pe-2"], ["id", "popupButton", 1, "btn", "btn-sm", "btn-primary", 3, "click"], [3, "icon"], ["jhiTranslate", "artemisApp.textUnit.isolated", 1, "d-none", "d-md-inline"], [1, "card-body", "unit-card-body", 3, "ngbCollapse"], [1, "badge", "bg-warning", "ms-2", 3, "ngbTooltip"], [1, "col-auto"], ["size", "lg", 1, "text-success", 3, "icon", "ngbTooltip", "click"], ["size", "lg", 1, "text-body-secondary", 3, "icon", "ngbTooltip", "click"], ["id", "printContent", 1, "markdown-preview", 3, "innerHtml"]], template: function TextUnitComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275elementStart(0, "div", 0);
          i04.\u0275\u0275text(1, "\n    ");
          i04.\u0275\u0275elementStart(2, "div", 1);
          i04.\u0275\u0275text(3, "\n        ");
          i04.\u0275\u0275elementStart(4, "div", 2);
          i04.\u0275\u0275listener("click", function TextUnitComponent_Template_div_click_4_listener($event) {
            return ctx.handleCollapse($event);
          });
          i04.\u0275\u0275text(5, "\n            ");
          i04.\u0275\u0275elementStart(6, "div", 3);
          i04.\u0275\u0275text(7, "\n                ");
          i04.\u0275\u0275elementStart(8, "h5", 4);
          i04.\u0275\u0275text(9, "\n                    ");
          i04.\u0275\u0275element(10, "fa-icon", 5);
          i04.\u0275\u0275pipe(11, "artemisTranslate");
          i04.\u0275\u0275text(12);
          i04.\u0275\u0275template(13, TextUnitComponent_Conditional_13_Template, 7, 9);
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(14, "\n            ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(15, "\n            ");
          i04.\u0275\u0275elementStart(16, "div", 6);
          i04.\u0275\u0275text(17, "\n                ");
          i04.\u0275\u0275elementStart(18, "button", 7);
          i04.\u0275\u0275listener("click", function TextUnitComponent_Template_button_click_18_listener($event) {
            return ctx.openPopup($event);
          });
          i04.\u0275\u0275text(19, "\n                    ");
          i04.\u0275\u0275element(20, "fa-icon", 8);
          i04.\u0275\u0275text(21, "\n                    ");
          i04.\u0275\u0275elementStart(22, "span", 9);
          i04.\u0275\u0275text(23, "View Isolated");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(24, "\n                ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(25, "\n                ");
          i04.\u0275\u0275template(26, TextUnitComponent_Conditional_26_Template, 6, 1);
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(27, "\n        ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(28, "\n        ");
          i04.\u0275\u0275elementStart(29, "div", 10);
          i04.\u0275\u0275text(30, "\n            ");
          i04.\u0275\u0275template(31, TextUnitComponent_Conditional_31_Template, 6, 1);
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(32, "\n    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(33, "\n");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(34, "\n");
        }
        if (rf & 2) {
          i04.\u0275\u0275advance(10);
          i04.\u0275\u0275property("icon", ctx.faScroll)("ngbTooltip", i04.\u0275\u0275pipeBind1(11, 8, "artemisApp.textUnit.tooltip"));
          i04.\u0275\u0275advance(2);
          i04.\u0275\u0275textInterpolate1("\n                    ", (ctx.textUnit == null ? null : ctx.textUnit.name) ? ctx.textUnit.name : "", "\n                    ");
          i04.\u0275\u0275advance(1);
          i04.\u0275\u0275conditional(13, !(ctx.textUnit == null ? null : ctx.textUnit.visibleToStudents) ? 13 : -1);
          i04.\u0275\u0275advance(7);
          i04.\u0275\u0275property("icon", ctx.faExternalLinkAlt);
          i04.\u0275\u0275advance(6);
          i04.\u0275\u0275conditional(26, !ctx.isPresentationMode && ctx.textUnit.visibleToStudents ? 26 : -1);
          i04.\u0275\u0275advance(3);
          i04.\u0275\u0275property("ngbCollapse", ctx.isCollapsed);
          i04.\u0275\u0275advance(2);
          i04.\u0275\u0275conditional(31, ctx.formattedContent ? 31 : -1);
        }
      }, dependencies: [i23.NgbCollapse, i23.NgbTooltip, i32.FaIconComponent, TranslateDirective, ArtemisDatePipe, ArtemisTranslatePipe], styles: ["\n\n.unit-card[_ngcontent-%COMP%] {\n  border-radius: 3px;\n  box-shadow: 0 2px 6px 0 var(--lecture-unit-card-shadow);\n  min-width: 100%;\n  border: none;\n  transition: box-shadow 0.1s linear;\n}\n.unit-card[_ngcontent-%COMP%]:hover {\n  box-shadow: 0 2px 4px 0 var(--lecture-unit-card-hover-shadow);\n}\n.unit-card-body[_ngcontent-%COMP%] {\n  background-color: var(--lecture-unit-card-body-background);\n  border-radius: 0 0 8px 8px;\n}\n.unit-card-header[_ngcontent-%COMP%] {\n  min-height: 50px;\n  min-width: 100%;\n  border-radius: 3px 3px 0 0;\n  background-color: var(--overview-light-background-color);\n  cursor: pointer;\n  flex-wrap: nowrap !important;\n}\n.unit-card-header[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child {\n  padding-left: 0.5rem;\n}\n@media (max-width: 575.98px) {\n  .unit-card-header[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child {\n    padding: 0 !important;\n  }\n}\n.rounded[_ngcontent-%COMP%] {\n  border-radius: 3px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9jb3Vyc2UtbGVjdHVyZXMvbGVjdHVyZS11bml0LmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIudW5pdC1jYXJkIHtcbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgYm94LXNoYWRvdzogMCAycHggNnB4IDAgdmFyKC0tbGVjdHVyZS11bml0LWNhcmQtc2hhZG93KTtcbiAgICBtaW4td2lkdGg6IDEwMCU7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIHRyYW5zaXRpb246IGJveC1zaGFkb3cgMC4xcyBsaW5lYXI7XG59XG5cbi51bml0LWNhcmQ6aG92ZXIge1xuICAgIGJveC1zaGFkb3c6IDAgMnB4IDRweCAwIHZhcigtLWxlY3R1cmUtdW5pdC1jYXJkLWhvdmVyLXNoYWRvdyk7XG59XG5cbi51bml0LWNhcmQtYm9keSB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbGVjdHVyZS11bml0LWNhcmQtYm9keS1iYWNrZ3JvdW5kKTtcbiAgICBib3JkZXItcmFkaXVzOiAwIDAgOHB4IDhweDtcbn1cblxuLnVuaXQtY2FyZC1oZWFkZXIge1xuICAgIG1pbi1oZWlnaHQ6IDUwcHg7XG4gICAgbWluLXdpZHRoOiAxMDAlO1xuICAgIGJvcmRlci1yYWRpdXM6IDNweCAzcHggMCAwO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLW92ZXJ2aWV3LWxpZ2h0LWJhY2tncm91bmQtY29sb3IpO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBmbGV4LXdyYXA6IG5vd3JhcCAhaW1wb3J0YW50O1xuXG4gICAgPiBkaXY6Zmlyc3QtY2hpbGQge1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDAuNXJlbTtcblxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNTc1Ljk4cHgpIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnJvdW5kZWQge1xuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksaUJBQUE7QUFDQSxjQUFBLEVBQUEsSUFBQSxJQUFBLEVBQUEsSUFBQTtBQUNBLGFBQUE7QUFDQSxVQUFBO0FBQ0EsY0FBQSxXQUFBLEtBQUE7O0FBR0osQ0FSQSxTQVFBO0FBQ0ksY0FBQSxFQUFBLElBQUEsSUFBQSxFQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxpQkFBQSxFQUFBLEVBQUEsSUFBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQTtBQUNBLGFBQUE7QUFDQSxpQkFBQSxJQUFBLElBQUEsRUFBQTtBQUNBLG9CQUFBLElBQUE7QUFDQSxVQUFBO0FBQ0EsYUFBQTs7QUFFQSxDQVJKLGlCQVFJLEVBQUEsR0FBQTtBQUNJLGdCQUFBOztBQUVBLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFISixHQVJKLGlCQVFJLEVBQUEsR0FBQTtBQUlRLGFBQUE7OztBQUtaLENBQUE7QUFDSSxpQkFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(TextUnitComponent, { className: "TextUnitComponent" });
    })();
  }
});

// src/main/webapp/app/entities/lecture-unit/onlineUnit.model.ts
var OnlineUnit;
var init_onlineUnit_model = __esm({
  "src/main/webapp/app/entities/lecture-unit/onlineUnit.model.ts"() {
    init_lectureUnit_model();
    OnlineUnit = class extends LectureUnit {
      description;
      source;
      constructor() {
        super(LectureUnitType.ONLINE);
      }
    };
  }
});

// src/main/webapp/app/overview/course-lectures/online-unit/online-unit.component.ts
import { Component as Component5, EventEmitter as EventEmitter4, Input as Input5, Output as Output4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { faSquare as faSquare4, faSquareCheck as faSquareCheck4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-regular-svg-icons.js?v=1d0d9ead";
import { faLink, faUpRightFromSquare } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i24 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function OnlineUnitComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                        ");
    i05.\u0275\u0275elementStart(1, "span", 12);
    i05.\u0275\u0275pipe(2, "artemisTranslate");
    i05.\u0275\u0275pipe(3, "artemisDate");
    i05.\u0275\u0275text(4);
    i05.\u0275\u0275pipe(5, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(6, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r0 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275propertyInterpolate2("ngbTooltip", "", i05.\u0275\u0275pipeBind1(2, 3, "artemisApp.onlineUnit.notReleasedTooltip"), " ", i05.\u0275\u0275pipeBind1(3, 5, ctx_r0.onlineUnit == null ? null : ctx_r0.onlineUnit.releaseDate), "");
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275textInterpolate1("\n                            ", i05.\u0275\u0275pipeBind1(5, 7, "artemisApp.courseOverview.exerciseList.notReleased"), "\n                        ");
  }
}
function OnlineUnitComponent_Conditional_26_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n                            ");
    i05.\u0275\u0275elementStart(1, "fa-icon", 14);
    i05.\u0275\u0275listener("click", function OnlineUnitComponent_Conditional_26_Conditional_3_Template_fa_icon_click_1_listener($event) {
      i05.\u0275\u0275restoreView(_r5);
      const ctx_r4 = i05.\u0275\u0275nextContext(2);
      return i05.\u0275\u0275resetView(ctx_r4.handleClick($event, false));
    });
    i05.\u0275\u0275pipe(2, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r2 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("icon", ctx_r2.faSquareCheck)("ngbTooltip", i05.\u0275\u0275pipeBind1(2, 2, "artemisApp.lectureUnit.completedTooltip"));
  }
}
function OnlineUnitComponent_Conditional_26_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = i05.\u0275\u0275getCurrentView();
    i05.\u0275\u0275text(0, "\n                            ");
    i05.\u0275\u0275elementStart(1, "fa-icon", 15);
    i05.\u0275\u0275listener("click", function OnlineUnitComponent_Conditional_26_Conditional_4_Template_fa_icon_click_1_listener($event) {
      i05.\u0275\u0275restoreView(_r7);
      const ctx_r6 = i05.\u0275\u0275nextContext(2);
      return i05.\u0275\u0275resetView(ctx_r6.handleClick($event, true));
    });
    i05.\u0275\u0275pipe(2, "artemisTranslate");
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const ctx_r3 = i05.\u0275\u0275nextContext(2);
    i05.\u0275\u0275advance(1);
    i05.\u0275\u0275property("icon", ctx_r3.faSquare)("ngbTooltip", i05.\u0275\u0275pipeBind1(2, 2, "artemisApp.lectureUnit.uncompletedTooltip"));
  }
}
function OnlineUnitComponent_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275text(0, "\n                    ");
    i05.\u0275\u0275elementStart(1, "div", 13);
    i05.\u0275\u0275text(2, "\n                        ");
    i05.\u0275\u0275template(3, OnlineUnitComponent_Conditional_26_Conditional_3_Template, 4, 4)(4, OnlineUnitComponent_Conditional_26_Conditional_4_Template, 4, 4);
    i05.\u0275\u0275elementEnd();
    i05.\u0275\u0275text(5, "\n                ");
  }
  if (rf & 2) {
    const ctx_r1 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance(3);
    i05.\u0275\u0275conditional(3, ctx_r1.onlineUnit.completed ? 3 : 4);
  }
}
var OnlineUnitComponent;
var init_online_unit_component = __esm({
  "src/main/webapp/app/overview/course-lectures/online-unit/online-unit.component.ts"() {
    init_onlineUnit_model();
    init_translate_directive();
    init_artemis_date_pipe();
    init_artemis_translate_pipe();
    OnlineUnitComponent = class _OnlineUnitComponent {
      onlineUnit;
      isPresentationMode = false;
      onCompletion = new EventEmitter4();
      isCollapsed = true;
      faLink = faLink;
      faUpRightFromSquare = faUpRightFromSquare;
      faSquare = faSquare4;
      faSquareCheck = faSquareCheck4;
      constructor() {
      }
      handleCollapse(event) {
        event.stopPropagation();
        this.isCollapsed = !this.isCollapsed;
      }
      handleClick(event, completed) {
        event.stopPropagation();
        this.onCompletion.emit({ lectureUnit: this.onlineUnit, completed });
      }
      openLink(event) {
        event.stopPropagation();
        if (this.onlineUnit?.source) {
          window.open(this.onlineUnit.source, "_blank");
          this.onCompletion.emit({ lectureUnit: this.onlineUnit, completed: true });
        }
      }
      get domainName() {
        if (this.onlineUnit?.source) {
          return new URL(this.onlineUnit.source).hostname.replace("www.", "");
        }
        return "";
      }
      static \u0275fac = function OnlineUnitComponent_Factory(t) {
        return new (t || _OnlineUnitComponent)();
      };
      static \u0275cmp = i05.\u0275\u0275defineComponent({ type: _OnlineUnitComponent, selectors: [["jhi-online-unit"]], inputs: { onlineUnit: "onlineUnit", isPresentationMode: "isPresentationMode" }, outputs: { onCompletion: "onCompletion" }, decls: 37, vars: 11, consts: [[1, "row", "align-items-center", "my-2", "px-2"], [1, "card", "unit-card"], [1, "card-header", "unit-card-header", "row", "align-content-center", "justify-content-between", 3, "click"], [1, "col-auto", "row", "align-content-center", "flex-shrink-1"], [1, "m-0", "fw-medium"], [1, "me-2", "col-auto", 3, "icon", "ngbTooltip"], [1, "col-auto", "d-flex", "align-items-center", "gap-3", "pe-2"], [1, "btn", "btn-sm", "btn-primary", 3, "ngbTooltip", "click"], [3, "icon"], ["jhiTranslate", "artemisApp.onlineUnit.doOpen", 1, "d-none", "d-md-inline"], [1, "card-body", "unit-card-body", 3, "ngbCollapse"], [1, "mb-0"], [1, "badge", "bg-warning", "ms-2", 3, "ngbTooltip"], [1, "col-auto", "my-auto"], ["size", "lg", 1, "text-success", 3, "icon", "ngbTooltip", "click"], ["size", "lg", 1, "text-body-secondary", 3, "icon", "ngbTooltip", "click"]], template: function OnlineUnitComponent_Template(rf, ctx) {
        if (rf & 1) {
          i05.\u0275\u0275elementStart(0, "div", 0);
          i05.\u0275\u0275text(1, "\n    ");
          i05.\u0275\u0275elementStart(2, "div", 1);
          i05.\u0275\u0275text(3, "\n        ");
          i05.\u0275\u0275elementStart(4, "div", 2);
          i05.\u0275\u0275listener("click", function OnlineUnitComponent_Template_div_click_4_listener($event) {
            return ctx.handleCollapse($event);
          });
          i05.\u0275\u0275text(5, "\n            ");
          i05.\u0275\u0275elementStart(6, "div", 3);
          i05.\u0275\u0275text(7, "\n                ");
          i05.\u0275\u0275elementStart(8, "h5", 4);
          i05.\u0275\u0275text(9, "\n                    ");
          i05.\u0275\u0275element(10, "fa-icon", 5);
          i05.\u0275\u0275pipe(11, "artemisTranslate");
          i05.\u0275\u0275text(12);
          i05.\u0275\u0275template(13, OnlineUnitComponent_Conditional_13_Template, 7, 9);
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(14, "\n            ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(15, "\n            ");
          i05.\u0275\u0275elementStart(16, "div", 6);
          i05.\u0275\u0275text(17, "\n                ");
          i05.\u0275\u0275elementStart(18, "button", 7);
          i05.\u0275\u0275listener("click", function OnlineUnitComponent_Template_button_click_18_listener($event) {
            return ctx.openLink($event);
          });
          i05.\u0275\u0275text(19, "\n                    ");
          i05.\u0275\u0275element(20, "fa-icon", 8);
          i05.\u0275\u0275text(21, "\n                    ");
          i05.\u0275\u0275elementStart(22, "span", 9);
          i05.\u0275\u0275text(23, "Open link");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(24, "\n                ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(25, "\n                ");
          i05.\u0275\u0275template(26, OnlineUnitComponent_Conditional_26_Template, 6, 1);
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(27, "\n        ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(28, "\n        ");
          i05.\u0275\u0275elementStart(29, "div", 10);
          i05.\u0275\u0275text(30, "\n            ");
          i05.\u0275\u0275elementStart(31, "p", 11);
          i05.\u0275\u0275text(32);
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(33, "\n        ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(34, "\n    ");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(35, "\n");
          i05.\u0275\u0275elementEnd();
          i05.\u0275\u0275text(36, "\n");
        }
        if (rf & 2) {
          i05.\u0275\u0275advance(10);
          i05.\u0275\u0275property("icon", ctx.faLink)("ngbTooltip", i05.\u0275\u0275pipeBind1(11, 9, "artemisApp.onlineUnit.tooltip"));
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275textInterpolate1("\n                    ", ctx.onlineUnit == null ? null : ctx.onlineUnit.name, "\n                    ");
          i05.\u0275\u0275advance(1);
          i05.\u0275\u0275conditional(13, !(ctx.onlineUnit == null ? null : ctx.onlineUnit.visibleToStudents) ? 13 : -1);
          i05.\u0275\u0275advance(5);
          i05.\u0275\u0275property("ngbTooltip", ctx.domainName);
          i05.\u0275\u0275advance(2);
          i05.\u0275\u0275property("icon", ctx.faUpRightFromSquare);
          i05.\u0275\u0275advance(6);
          i05.\u0275\u0275conditional(26, !ctx.isPresentationMode && ctx.onlineUnit.visibleToStudents ? 26 : -1);
          i05.\u0275\u0275advance(3);
          i05.\u0275\u0275property("ngbCollapse", ctx.isCollapsed);
          i05.\u0275\u0275advance(3);
          i05.\u0275\u0275textInterpolate(ctx.onlineUnit == null ? null : ctx.onlineUnit.description);
        }
      }, dependencies: [i12.NgbCollapse, i12.NgbTooltip, i24.FaIconComponent, TranslateDirective, ArtemisDatePipe, ArtemisTranslatePipe], styles: ["\n\n.unit-card[_ngcontent-%COMP%] {\n  border-radius: 3px;\n  box-shadow: 0 2px 6px 0 var(--lecture-unit-card-shadow);\n  min-width: 100%;\n  border: none;\n  transition: box-shadow 0.1s linear;\n}\n.unit-card[_ngcontent-%COMP%]:hover {\n  box-shadow: 0 2px 4px 0 var(--lecture-unit-card-hover-shadow);\n}\n.unit-card-body[_ngcontent-%COMP%] {\n  background-color: var(--lecture-unit-card-body-background);\n  border-radius: 0 0 8px 8px;\n}\n.unit-card-header[_ngcontent-%COMP%] {\n  min-height: 50px;\n  min-width: 100%;\n  border-radius: 3px 3px 0 0;\n  background-color: var(--overview-light-background-color);\n  cursor: pointer;\n  flex-wrap: nowrap !important;\n}\n.unit-card-header[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child {\n  padding-left: 0.5rem;\n}\n@media (max-width: 575.98px) {\n  .unit-card-header[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:first-child {\n    padding: 0 !important;\n  }\n}\n.rounded[_ngcontent-%COMP%] {\n  border-radius: 3px;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9jb3Vyc2UtbGVjdHVyZXMvbGVjdHVyZS11bml0LmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIudW5pdC1jYXJkIHtcbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgYm94LXNoYWRvdzogMCAycHggNnB4IDAgdmFyKC0tbGVjdHVyZS11bml0LWNhcmQtc2hhZG93KTtcbiAgICBtaW4td2lkdGg6IDEwMCU7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIHRyYW5zaXRpb246IGJveC1zaGFkb3cgMC4xcyBsaW5lYXI7XG59XG5cbi51bml0LWNhcmQ6aG92ZXIge1xuICAgIGJveC1zaGFkb3c6IDAgMnB4IDRweCAwIHZhcigtLWxlY3R1cmUtdW5pdC1jYXJkLWhvdmVyLXNoYWRvdyk7XG59XG5cbi51bml0LWNhcmQtYm9keSB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbGVjdHVyZS11bml0LWNhcmQtYm9keS1iYWNrZ3JvdW5kKTtcbiAgICBib3JkZXItcmFkaXVzOiAwIDAgOHB4IDhweDtcbn1cblxuLnVuaXQtY2FyZC1oZWFkZXIge1xuICAgIG1pbi1oZWlnaHQ6IDUwcHg7XG4gICAgbWluLXdpZHRoOiAxMDAlO1xuICAgIGJvcmRlci1yYWRpdXM6IDNweCAzcHggMCAwO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLW92ZXJ2aWV3LWxpZ2h0LWJhY2tncm91bmQtY29sb3IpO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBmbGV4LXdyYXA6IG5vd3JhcCAhaW1wb3J0YW50O1xuXG4gICAgPiBkaXY6Zmlyc3QtY2hpbGQge1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDAuNXJlbTtcblxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNTc1Ljk4cHgpIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnJvdW5kZWQge1xuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksaUJBQUE7QUFDQSxjQUFBLEVBQUEsSUFBQSxJQUFBLEVBQUEsSUFBQTtBQUNBLGFBQUE7QUFDQSxVQUFBO0FBQ0EsY0FBQSxXQUFBLEtBQUE7O0FBR0osQ0FSQSxTQVFBO0FBQ0ksY0FBQSxFQUFBLElBQUEsSUFBQSxFQUFBLElBQUE7O0FBR0osQ0FBQTtBQUNJLG9CQUFBLElBQUE7QUFDQSxpQkFBQSxFQUFBLEVBQUEsSUFBQTs7QUFHSixDQUFBO0FBQ0ksY0FBQTtBQUNBLGFBQUE7QUFDQSxpQkFBQSxJQUFBLElBQUEsRUFBQTtBQUNBLG9CQUFBLElBQUE7QUFDQSxVQUFBO0FBQ0EsYUFBQTs7QUFFQSxDQVJKLGlCQVFJLEVBQUEsR0FBQTtBQUNJLGdCQUFBOztBQUVBLE9BQUEsQ0FBQSxTQUFBLEVBQUE7QUFISixHQVJKLGlCQVFJLEVBQUEsR0FBQTtBQUlRLGFBQUE7OztBQUtaLENBQUE7QUFDSSxpQkFBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */"] });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(OnlineUnitComponent, { className: "OnlineUnitComponent" });
    })();
  }
});

// src/main/webapp/app/overview/course-lectures/lecture-units.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisLectureUnitsModule;
var init_lecture_units_module = __esm({
  "src/main/webapp/app/overview/course-lectures/lecture-units.module.ts"() {
    init_shared_module();
    init_shared_component_module();
    init_shared_pipes_module();
    init_course_exercise_row_module();
    init_exercise_unit_component();
    init_attachment_unit_component();
    init_video_unit_component();
    init_text_unit_component();
    init_markdown_module();
    init_online_unit_component();
    ArtemisLectureUnitsModule = class _ArtemisLectureUnitsModule {
      static \u0275fac = function ArtemisLectureUnitsModule_Factory(t) {
        return new (t || _ArtemisLectureUnitsModule)();
      };
      static \u0275mod = i06.\u0275\u0275defineNgModule({ type: _ArtemisLectureUnitsModule });
      static \u0275inj = i06.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule, ArtemisSharedComponentModule, ArtemisSharedPipesModule, ArtemisCourseExerciseRowModule, ArtemisMarkdownModule] });
    };
  }
});

export {
  ExerciseUnit,
  init_exerciseUnit_model,
  ExerciseUnitComponent,
  init_exercise_unit_component,
  AttachmentUnit,
  init_attachmentUnit_model,
  AttachmentUnitComponent,
  init_attachment_unit_component,
  VideoUnit,
  init_videoUnit_model,
  VideoUnitComponent,
  init_video_unit_component,
  TextUnit,
  init_textUnit_model,
  TextUnitComponent,
  init_text_unit_component,
  OnlineUnit,
  init_onlineUnit_model,
  OnlineUnitComponent,
  init_online_unit_component,
  ArtemisLectureUnitsModule,
  init_lecture_units_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvbGVjdHVyZS11bml0L2V4ZXJjaXNlVW5pdC5tb2RlbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvb3ZlcnZpZXcvY291cnNlLWxlY3R1cmVzL2V4ZXJjaXNlLXVuaXQvZXhlcmNpc2UtdW5pdC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL292ZXJ2aWV3L2NvdXJzZS1sZWN0dXJlcy9leGVyY2lzZS11bml0L2V4ZXJjaXNlLXVuaXQuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2VudGl0aWVzL2xlY3R1cmUtdW5pdC9hdHRhY2htZW50VW5pdC5tb2RlbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvb3ZlcnZpZXcvY291cnNlLWxlY3R1cmVzL2F0dGFjaG1lbnQtdW5pdC9hdHRhY2htZW50LXVuaXQuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9jb3Vyc2UtbGVjdHVyZXMvYXR0YWNobWVudC11bml0L2F0dGFjaG1lbnQtdW5pdC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvbGVjdHVyZS11bml0L3ZpZGVvVW5pdC5tb2RlbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvb3ZlcnZpZXcvY291cnNlLWxlY3R1cmVzL3ZpZGVvLXVuaXQvdmlkZW8tdW5pdC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL292ZXJ2aWV3L2NvdXJzZS1sZWN0dXJlcy92aWRlby11bml0L3ZpZGVvLXVuaXQuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2VudGl0aWVzL2xlY3R1cmUtdW5pdC90ZXh0VW5pdC5tb2RlbC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvb3ZlcnZpZXcvY291cnNlLWxlY3R1cmVzL3RleHQtdW5pdC90ZXh0LXVuaXQuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9vdmVydmlldy9jb3Vyc2UtbGVjdHVyZXMvdGV4dC11bml0L3RleHQtdW5pdC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvbGVjdHVyZS11bml0L29ubGluZVVuaXQubW9kZWwudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL292ZXJ2aWV3L2NvdXJzZS1sZWN0dXJlcy9vbmxpbmUtdW5pdC9vbmxpbmUtdW5pdC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL292ZXJ2aWV3L2NvdXJzZS1sZWN0dXJlcy9vbmxpbmUtdW5pdC9vbmxpbmUtdW5pdC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvb3ZlcnZpZXcvY291cnNlLWxlY3R1cmVzL2xlY3R1cmUtdW5pdHMubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExlY3R1cmVVbml0LCBMZWN0dXJlVW5pdFR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvbGVjdHVyZS11bml0L2xlY3R1cmVVbml0Lm1vZGVsJztcbmltcG9ydCB7IEV4ZXJjaXNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcblxuZXhwb3J0IGNsYXNzIEV4ZXJjaXNlVW5pdCBleHRlbmRzIExlY3R1cmVVbml0IHtcbiAgICBwdWJsaWMgZXhlcmNpc2U/OiBFeGVyY2lzZTtcblxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihMZWN0dXJlVW5pdFR5cGUuRVhFUkNJU0UpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSG9zdEJpbmRpbmcsIElucHV0LCBWaWV3RW5jYXBzdWxhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ291cnNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvdXJzZS5tb2RlbCc7XG5pbXBvcnQgeyBFeGVyY2lzZVVuaXQgfSBmcm9tICdhcHAvZW50aXRpZXMvbGVjdHVyZS11bml0L2V4ZXJjaXNlVW5pdC5tb2RlbCc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWV4ZXJjaXNlLXVuaXQnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9leGVyY2lzZS11bml0LmNvbXBvbmVudC5odG1sJyxcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxuICAgIHN0eWxlVXJsczogWycuL2V4ZXJjaXNlLXVuaXQuY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgRXhlcmNpc2VVbml0Q29tcG9uZW50IHtcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzTmFtZScpIGNvbXBvbmVudENsYXNzOiBzdHJpbmc7XG5cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5jb21wb25lbnRDbGFzcyA9ICdleGVyY2lzZS11bml0JztcbiAgICB9XG5cbiAgICBASW5wdXQoKSBleGVyY2lzZVVuaXQ6IEV4ZXJjaXNlVW5pdDtcbiAgICBASW5wdXQoKSBjb3Vyc2U6IENvdXJzZTtcbiAgICBASW5wdXQoKSBpc1ByZXNlbnRhdGlvbk1vZGUgPSBmYWxzZTtcbn1cbiIsIkBpZiAoZXhlcmNpc2VVbml0Py5leGVyY2lzZSAmJiBjb3Vyc2UpIHtcbiAgICA8amhpLWNvdXJzZS1leGVyY2lzZS1yb3dcbiAgICAgICAgY2xhc3M9XCJleGVyY2lzZS1yb3dcIlxuICAgICAgICBbZXhlcmNpc2VdPVwiZXhlcmNpc2VVbml0LmV4ZXJjaXNlIVwiXG4gICAgICAgIFtjb3Vyc2VdPVwiY291cnNlXCJcbiAgICAgICAgW2hhc0d1aWRlZFRvdXJdPVwiZmFsc2VcIlxuICAgICAgICBbaXNQcmVzZW50YXRpb25Nb2RlXT1cImlzUHJlc2VudGF0aW9uTW9kZVwiXG4gICAgPjwvamhpLWNvdXJzZS1leGVyY2lzZS1yb3c+XG59XG4iLCJpbXBvcnQgeyBMZWN0dXJlVW5pdCwgTGVjdHVyZVVuaXRUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2xlY3R1cmUtdW5pdC9sZWN0dXJlVW5pdC5tb2RlbCc7XG5pbXBvcnQgeyBBdHRhY2htZW50IH0gZnJvbSAnYXBwL2VudGl0aWVzL2F0dGFjaG1lbnQubW9kZWwnO1xuaW1wb3J0IHsgU2xpZGUgfSBmcm9tICdhcHAvZW50aXRpZXMvbGVjdHVyZS11bml0L3NsaWRlLm1vZGVsJztcblxuZXhwb3J0IGNsYXNzIEF0dGFjaG1lbnRVbml0IGV4dGVuZHMgTGVjdHVyZVVuaXQge1xuICAgIHB1YmxpYyBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgICBwdWJsaWMgYXR0YWNobWVudD86IEF0dGFjaG1lbnQ7XG4gICAgcHVibGljIHNsaWRlcz86IFNsaWRlW107XG5cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoTGVjdHVyZVVuaXRUeXBlLkFUVEFDSE1FTlQpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge1xuICAgIGZhRG93bmxvYWQsXG4gICAgZmFGaWxlLFxuICAgIGZhRmlsZUFyY2hpdmUsXG4gICAgZmFGaWxlQ29kZSxcbiAgICBmYUZpbGVDc3YsXG4gICAgZmFGaWxlRXhjZWwsXG4gICAgZmFGaWxlSW1hZ2UsXG4gICAgZmFGaWxlTGluZXMsXG4gICAgZmFGaWxlUGRmLFxuICAgIGZhRmlsZVBlbixcbiAgICBmYUZpbGVQb3dlcnBvaW50LFxuICAgIGZhRmlsZVdvcmQsXG59IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXNvbGlkLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBBdHRhY2htZW50VW5pdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9sZWN0dXJlLXVuaXQvYXR0YWNobWVudFVuaXQubW9kZWwnO1xuaW1wb3J0IHsgRmlsZVNlcnZpY2UgfSBmcm9tICdhcHAvc2hhcmVkL2h0dHAvZmlsZS5zZXJ2aWNlJztcbmltcG9ydCB7IExlY3R1cmVVbml0Q29tcGxldGlvbkV2ZW50IH0gZnJvbSAnYXBwL292ZXJ2aWV3L2NvdXJzZS1sZWN0dXJlcy9jb3Vyc2UtbGVjdHVyZS1kZXRhaWxzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBmYVNxdWFyZSwgZmFTcXVhcmVDaGVjayB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mcmVlLXJlZ3VsYXItc3ZnLWljb25zJztcbmltcG9ydCB7IEljb25EZWZpbml0aW9uIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktYXR0YWNobWVudC11bml0JyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vYXR0YWNobWVudC11bml0LmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi4vbGVjdHVyZS11bml0LmNvbXBvbmVudC5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIEF0dGFjaG1lbnRVbml0Q29tcG9uZW50IHtcbiAgICBASW5wdXQoKSBhdHRhY2htZW50VW5pdDogQXR0YWNobWVudFVuaXQ7XG4gICAgQElucHV0KCkgaXNQcmVzZW50YXRpb25Nb2RlID0gZmFsc2U7XG4gICAgQE91dHB1dCgpIG9uQ29tcGxldGlvbjogRXZlbnRFbWl0dGVyPExlY3R1cmVVbml0Q29tcGxldGlvbkV2ZW50PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICAgIGlzQ29sbGFwc2VkID0gdHJ1ZTtcblxuICAgIC8vIEljb25zXG4gICAgZmFEb3dubG9hZCA9IGZhRG93bmxvYWQ7XG4gICAgZmFTcXVhcmUgPSBmYVNxdWFyZTtcbiAgICBmYVNxdWFyZUNoZWNrID0gZmFTcXVhcmVDaGVjaztcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgZmlsZVNlcnZpY2U6IEZpbGVTZXJ2aWNlKSB7fVxuXG4gICAgaGFuZGxlQ29sbGFwc2UoZXZlbnQ6IEV2ZW50KSB7XG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICB0aGlzLmlzQ29sbGFwc2VkID0gIXRoaXMuaXNDb2xsYXBzZWQ7XG4gICAgfVxuXG4gICAgZG93bmxvYWRBdHRhY2htZW50KGV2ZW50OiBFdmVudCkge1xuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgaWYgKHRoaXMuYXR0YWNobWVudFVuaXQ/LmF0dGFjaG1lbnQ/LmxpbmspIHtcbiAgICAgICAgICAgIHRoaXMuZmlsZVNlcnZpY2UuZG93bmxvYWRGaWxlKHRoaXMuYXR0YWNobWVudFVuaXQ/LmF0dGFjaG1lbnQ/LmxpbmspO1xuICAgICAgICAgICAgdGhpcy5vbkNvbXBsZXRpb24uZW1pdCh7IGxlY3R1cmVVbml0OiB0aGlzLmF0dGFjaG1lbnRVbml0LCBjb21wbGV0ZWQ6IHRydWUgfSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBoYW5kbGVDbGljayhldmVudDogRXZlbnQsIGNvbXBsZXRlZDogYm9vbGVhbikge1xuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgdGhpcy5vbkNvbXBsZXRpb24uZW1pdCh7IGxlY3R1cmVVbml0OiB0aGlzLmF0dGFjaG1lbnRVbml0LCBjb21wbGV0ZWQgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgbmFtZSBvZiB0aGUgYXR0YWNobWVudCBmaWxlIChpbmNsdWRpbmcgaXRzIGZpbGUgZXh0ZW5zaW9uKVxuICAgICAqL1xuICAgIGdldEZpbGVOYW1lKCk6IHN0cmluZyB7XG4gICAgICAgIGlmICh0aGlzLmF0dGFjaG1lbnRVbml0Py5hdHRhY2htZW50Py5saW5rKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5hdHRhY2htZW50VW5pdD8uYXR0YWNobWVudD8ubGluay5zdWJzdHJpbmcodGhpcy5hdHRhY2htZW50VW5pdD8uYXR0YWNobWVudD8ubGluay5sYXN0SW5kZXhPZignLycpICsgMSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBtYXRjaGluZyBpY29uIGZvciB0aGUgZmlsZSBleHRlbnNpb24gb2YgdGhlIGF0dGFjaG1lbnRcbiAgICAgKi9cbiAgICBnZXRBdHRhY2htZW50SWNvbigpOiBJY29uRGVmaW5pdGlvbiB7XG4gICAgICAgIGlmICh0aGlzLmF0dGFjaG1lbnRVbml0Py5hdHRhY2htZW50Py5saW5rKSB7XG4gICAgICAgICAgICBjb25zdCBmaWxlRXh0ZW5zaW9uID0gdGhpcy5hdHRhY2htZW50VW5pdD8uYXR0YWNobWVudD8ubGluay5zcGxpdCgnLicpLnBvcCgpIS50b0xvY2FsZUxvd2VyQ2FzZSgpO1xuICAgICAgICAgICAgc3dpdGNoIChmaWxlRXh0ZW5zaW9uKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAncG5nJzpcbiAgICAgICAgICAgICAgICBjYXNlICdqcGcnOlxuICAgICAgICAgICAgICAgIGNhc2UgJ2pwZWcnOlxuICAgICAgICAgICAgICAgIGNhc2UgJ2dpZic6XG4gICAgICAgICAgICAgICAgY2FzZSAnc3ZnJzpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhRmlsZUltYWdlO1xuICAgICAgICAgICAgICAgIGNhc2UgJ3BkZic6XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYUZpbGVQZGY7XG4gICAgICAgICAgICAgICAgY2FzZSAnemlwJzpcbiAgICAgICAgICAgICAgICBjYXNlICd0YXInOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFGaWxlQXJjaGl2ZTtcbiAgICAgICAgICAgICAgICBjYXNlICd0eHQnOlxuICAgICAgICAgICAgICAgIGNhc2UgJ3J0Zic6XG4gICAgICAgICAgICAgICAgY2FzZSAnbWQnOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFGaWxlTGluZXM7XG4gICAgICAgICAgICAgICAgY2FzZSAnaHRtJzpcbiAgICAgICAgICAgICAgICBjYXNlICdodG1sJzpcbiAgICAgICAgICAgICAgICBjYXNlICdqc29uJzpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhRmlsZUNvZGU7XG4gICAgICAgICAgICAgICAgY2FzZSAnZG9jJzpcbiAgICAgICAgICAgICAgICBjYXNlICdkb2N4JzpcbiAgICAgICAgICAgICAgICBjYXNlICdwYWdlcyc6XG4gICAgICAgICAgICAgICAgY2FzZSAncGFnZXMtdGVmJzpcbiAgICAgICAgICAgICAgICBjYXNlICdvZHQnOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFGaWxlV29yZDtcbiAgICAgICAgICAgICAgICBjYXNlICdjc3YnOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFGaWxlQ3N2O1xuICAgICAgICAgICAgICAgIGNhc2UgJ3hscyc6XG4gICAgICAgICAgICAgICAgY2FzZSAneGxzeCc6XG4gICAgICAgICAgICAgICAgY2FzZSAnbnVtYmVycyc6XG4gICAgICAgICAgICAgICAgY2FzZSAnb2RzJzpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhRmlsZUV4Y2VsO1xuICAgICAgICAgICAgICAgIGNhc2UgJ3BwdCc6XG4gICAgICAgICAgICAgICAgY2FzZSAncHB0eCc6XG4gICAgICAgICAgICAgICAgY2FzZSAna2V5JzpcbiAgICAgICAgICAgICAgICBjYXNlICdvZHAnOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFGaWxlUG93ZXJwb2ludDtcbiAgICAgICAgICAgICAgICBjYXNlICdvZGcnOlxuICAgICAgICAgICAgICAgIGNhc2UgJ29kYyc6XG4gICAgICAgICAgICAgICAgY2FzZSAnb2RpJzpcbiAgICAgICAgICAgICAgICBjYXNlICdvZGYnOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFGaWxlUGVuO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYUZpbGU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhRmlsZTtcbiAgICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwicm93IGFsaWduLWl0ZW1zLWNlbnRlciBteS0yIHB4LTJcIj5cbiAgICA8ZGl2IGNsYXNzPVwiY2FyZCB1bml0LWNhcmRcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtaGVhZGVyIHVuaXQtY2FyZC1oZWFkZXIgcm93IGFsaWduLWNvbnRlbnQtY2VudGVyIGp1c3RpZnktY29udGVudC1iZXR3ZWVuXCIgKGNsaWNrKT1cImhhbmRsZUNvbGxhcHNlKCRldmVudClcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0byByb3cgYWxpZ24tY29udGVudC1jZW50ZXIgZmxleC1zaHJpbmstMVwiPlxuICAgICAgICAgICAgICAgIDxoNSBjbGFzcz1cIm0tMCBmdy1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gY2xhc3M9XCJtZS0yXCIgW2ljb25dPVwiZ2V0QXR0YWNobWVudEljb24oKVwiIFtuZ2JUb29sdGlwXT1cIidhcnRlbWlzQXBwLmF0dGFjaG1lbnRVbml0LnRvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiPiA8L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIHt7IGF0dGFjaG1lbnRVbml0Py5hdHRhY2htZW50Py5uYW1lID8gYXR0YWNobWVudFVuaXQ/LmF0dGFjaG1lbnQ/Lm5hbWUgOiAnJyB9fVxuICAgICAgICAgICAgICAgICAgICBAaWYgKCFhdHRhY2htZW50VW5pdD8udmlzaWJsZVRvU3R1ZGVudHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJiYWRnZSBiZy13YXJuaW5nIG1zLTJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5nYlRvb2x0aXA9XCJ7eyAnYXJ0ZW1pc0FwcC5hdHRhY2htZW50VW5pdC5ub3RSZWxlYXNlZFRvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fSB7eyBhdHRhY2htZW50VW5pdD8uYXR0YWNobWVudD8ucmVsZWFzZURhdGUgfCBhcnRlbWlzRGF0ZSB9fVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VMaXN0Lm5vdFJlbGVhc2VkJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvaDU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0byBkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyIGdhcC0zIHBlLTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiZG93bmxvYWRCdXR0b25cIiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tc21cIiAoY2xpY2spPVwiZG93bmxvYWRBdHRhY2htZW50KCRldmVudClcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFEb3dubG9hZFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkLW5vbmUgZC1tZC1pbmxpbmVcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmF0dGFjaG1lbnRVbml0LmRvd25sb2FkXCI+RG93bmxvYWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgQGlmICghaXNQcmVzZW50YXRpb25Nb2RlICYmIGF0dGFjaG1lbnRVbml0LnZpc2libGVUb1N0dWRlbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChhdHRhY2htZW50VW5pdC5jb21wbGV0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInRleHQtc3VjY2Vzc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsZ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtpY29uXT1cImZhU3F1YXJlQ2hlY2tcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbmdiVG9vbHRpcF09XCInYXJ0ZW1pc0FwcC5sZWN0dXJlVW5pdC5jb21wbGV0ZWRUb29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwiaGFuZGxlQ2xpY2soJGV2ZW50LCBmYWxzZSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInRleHQtYm9keS1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGdcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbaWNvbl09XCJmYVNxdWFyZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ2JUb29sdGlwXT1cIidhcnRlbWlzQXBwLmxlY3R1cmVVbml0LnVuY29tcGxldGVkVG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cImhhbmRsZUNsaWNrKCRldmVudCwgdHJ1ZSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtYm9keSB1bml0LWNhcmQtYm9keVwiIFtuZ2JDb2xsYXBzZV09XCJpc0NvbGxhcHNlZFwiPlxuICAgICAgICAgICAgQGlmIChhdHRhY2htZW50VW5pdD8uYXR0YWNobWVudD8udXBsb2FkRGF0ZSkge1xuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC13ZWlnaHQtYm9sZFwiPiB7eyAnYXJ0ZW1pc0FwcC5hdHRhY2htZW50VW5pdC51cGxvYWREYXRlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX06IDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge3sgYXR0YWNobWVudFVuaXQ/LmF0dGFjaG1lbnQ/LnVwbG9hZERhdGUgfCBhcnRlbWlzRGF0ZSB9fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgQGlmIChhdHRhY2htZW50VW5pdD8uYXR0YWNobWVudD8udmVyc2lvbikge1xuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC13ZWlnaHQtYm9sZFwiPiB7eyAnYXJ0ZW1pc0FwcC5hdHRhY2htZW50VW5pdC52ZXJzaW9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX06IDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge3sgYXR0YWNobWVudFVuaXQ/LmF0dGFjaG1lbnQ/LnZlcnNpb24gfX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIEBpZiAoYXR0YWNobWVudFVuaXQ/LmF0dGFjaG1lbnQ/LmxpbmspIHtcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImZvbnQtd2VpZ2h0LWJvbGRcIj4ge3sgJ2FydGVtaXNBcHAuYXR0YWNobWVudFVuaXQuRmlsZU5hbWUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTogPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB7eyBnZXRGaWxlTmFtZSgpIH19XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKGF0dGFjaG1lbnRVbml0Py5kZXNjcmlwdGlvbikge1xuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxociAvPlxuICAgICAgICAgICAgICAgICAgICB7eyBhdHRhY2htZW50VW5pdD8uZGVzY3JpcHRpb24gfX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IExlY3R1cmVVbml0LCBMZWN0dXJlVW5pdFR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvbGVjdHVyZS11bml0L2xlY3R1cmVVbml0Lm1vZGVsJztcblxuZXhwb3J0IGNsYXNzIFZpZGVvVW5pdCBleHRlbmRzIExlY3R1cmVVbml0IHtcbiAgICBwdWJsaWMgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gICAgLy8gc3JjIGxpbmsgb2YgYSB2aWRlb1xuICAgIHB1YmxpYyBzb3VyY2U/OiBzdHJpbmc7XG5cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoTGVjdHVyZVVuaXRUeXBlLlZJREVPKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBmYVZpZGVvIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IFZpZGVvVW5pdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9sZWN0dXJlLXVuaXQvdmlkZW9Vbml0Lm1vZGVsJztcbmltcG9ydCB1cmxQYXJzZXIgZnJvbSAnanMtdmlkZW8tdXJsLXBhcnNlcic7XG5pbXBvcnQgeyBMZWN0dXJlVW5pdENvbXBsZXRpb25FdmVudCB9IGZyb20gJ2FwcC9vdmVydmlldy9jb3Vyc2UtbGVjdHVyZXMvY291cnNlLWxlY3R1cmUtZGV0YWlscy5jb21wb25lbnQnO1xuaW1wb3J0IHsgZmFTcXVhcmUsIGZhU3F1YXJlQ2hlY2sgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1yZWd1bGFyLXN2Zy1pY29ucyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXZpZGVvLXVuaXQnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi92aWRlby11bml0LmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi4vbGVjdHVyZS11bml0LmNvbXBvbmVudC5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIFZpZGVvVW5pdENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgQElucHV0KCkgdmlkZW9Vbml0OiBWaWRlb1VuaXQ7XG4gICAgQElucHV0KCkgaXNQcmVzZW50YXRpb25Nb2RlID0gZmFsc2U7XG4gICAgQE91dHB1dCgpIG9uQ29tcGxldGlvbjogRXZlbnRFbWl0dGVyPExlY3R1cmVVbml0Q29tcGxldGlvbkV2ZW50PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICAgIHZpZGVvVXJsOiBzdHJpbmc7XG4gICAgaXNDb2xsYXBzZWQgPSB0cnVlO1xuICAgIGNvbXBsZXRpb25UaW1lb3V0OiBOb2RlSlMuVGltZW91dDtcblxuICAgIC8vIExpc3Qgb2YgcmVnZXhlcyB0aGF0IHNob3VsZCBub3QgYmUgYmxvY2tlZCBieSBqcy12aWRlby11cmwtcGFyc2VyXG4gICAgdmlkZW9VcmxBbGxvd0xpc3QgPSBbXG4gICAgICAgIC8vIFRVTS1MaXZlLiBFeGFtcGxlOiAnaHR0cHM6Ly9saXZlLnJiZy50dW0uZGUvdy90ZXN0LzI2P3ZpZGVvX29ubHk9MSdcbiAgICAgICAgUmVnRXhwKCdeaHR0cHM6Ly9saXZlXFxcXC5yYmdcXFxcLnR1bVxcXFwuZGUvdy9cXFxcdysvXFxcXGQrKC8oQ0FNfENPTUJ8UFJFUykpP1xcXFw/dmlkZW9fb25seT0xJCcpLFxuICAgIF07XG5cbiAgICAvLyBJY29uc1xuICAgIGZhVmlkZW8gPSBmYVZpZGVvO1xuICAgIGZhU3F1YXJlID0gZmFTcXVhcmU7XG4gICAgZmFTcXVhcmVDaGVjayA9IGZhU3F1YXJlQ2hlY2s7XG5cbiAgICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgaWYgKHRoaXMudmlkZW9Vbml0Py5zb3VyY2UpIHtcbiAgICAgICAgICAgIC8vIFZhbGlkYXRlIHRoZSBVUkwgYmVmb3JlIGRpc3BsYXlpbmcgaXRcbiAgICAgICAgICAgIGlmICh0aGlzLnZpZGVvVXJsQWxsb3dMaXN0LnNvbWUoKHIpID0+IHIudGVzdCh0aGlzLnZpZGVvVW5pdC5zb3VyY2UhKSkgfHwgIXVybFBhcnNlciB8fCB1cmxQYXJzZXIucGFyc2UodGhpcy52aWRlb1VuaXQuc291cmNlKSkge1xuICAgICAgICAgICAgICAgIHRoaXMudmlkZW9VcmwgPSB0aGlzLnZpZGVvVW5pdC5zb3VyY2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBoYW5kbGVDb2xsYXBzZShldmVudDogRXZlbnQpIHtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIHRoaXMuaXNDb2xsYXBzZWQgPSAhdGhpcy5pc0NvbGxhcHNlZDtcblxuICAgICAgICBpZiAoIXRoaXMuaXNDb2xsYXBzZWQpIHtcbiAgICAgICAgICAgIC8vIE1hcmsgdGhlIHVuaXQgYXMgY29tcGxldGVkIHdoZW4gdGhlIHVzZXIgaGFzIGl0IG9wZW4gZm9yIGF0IGxlYXN0IDUgbWludXRlc1xuICAgICAgICAgICAgdGhpcy5jb21wbGV0aW9uVGltZW91dCA9IHNldFRpbWVvdXQoXG4gICAgICAgICAgICAgICAgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uQ29tcGxldGlvbi5lbWl0KHsgbGVjdHVyZVVuaXQ6IHRoaXMudmlkZW9Vbml0LCBjb21wbGV0ZWQ6IHRydWUgfSk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAxMDAwICogNjAgKiA1LFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLmNvbXBsZXRpb25UaW1lb3V0KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGhhbmRsZUNsaWNrKGV2ZW50OiBFdmVudCwgY29tcGxldGVkOiBib29sZWFuKSB7XG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICB0aGlzLm9uQ29tcGxldGlvbi5lbWl0KHsgbGVjdHVyZVVuaXQ6IHRoaXMudmlkZW9Vbml0LCBjb21wbGV0ZWQgfSk7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInJvdyBhbGlnbi1pdGVtcy1jZW50ZXIgbXktMiBweC0yXCI+XG4gICAgPGRpdiBjbGFzcz1cImNhcmQgdW5pdC1jYXJkXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWhlYWRlciB1bml0LWNhcmQtaGVhZGVyIHJvdyBhbGlnbi1jb250ZW50LWNlbnRlciBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblwiIChjbGljayk9XCJoYW5kbGVDb2xsYXBzZSgkZXZlbnQpXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLWF1dG8gcm93IGFsaWduLWNvbnRlbnQtY2VudGVyIGZsZXgtc2hyaW5rLTFcIj5cbiAgICAgICAgICAgICAgICA8aDUgY2xhc3M9XCJtLTAgZnctbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIGNsYXNzPVwibWUtMlwiIFtpY29uXT1cImZhVmlkZW9cIiBbbmdiVG9vbHRpcF09XCInYXJ0ZW1pc0FwcC52aWRlb1VuaXQudG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlXCI+IDwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAge3sgdmlkZW9Vbml0Py5uYW1lID8gdmlkZW9Vbml0Lm5hbWUgOiAnJyB9fVxuICAgICAgICAgICAgICAgICAgICBAaWYgKCF2aWRlb1VuaXQ/LnZpc2libGVUb1N0dWRlbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYmFkZ2UgYmctd2FybmluZyBtcy0yXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuZ2JUb29sdGlwPVwie3sgJ2FydGVtaXNBcHAudmlkZW9Vbml0Lm5vdFJlbGVhc2VkVG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19IHt7IHZpZGVvVW5pdD8ucmVsZWFzZURhdGUgfCBhcnRlbWlzRGF0ZSB9fVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VMaXN0Lm5vdFJlbGVhc2VkJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvaDU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIEBpZiAoIWlzUHJlc2VudGF0aW9uTW9kZSAmJiB2aWRlb1VuaXQudmlzaWJsZVRvU3R1ZGVudHMpIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLWF1dG8gZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlciBnYXAtMyBwZS0yXCI+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAodmlkZW9Vbml0LmNvbXBsZXRlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInRleHQtc3VjY2Vzc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxnXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbaWNvbl09XCJmYVNxdWFyZUNoZWNrXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbmdiVG9vbHRpcF09XCInYXJ0ZW1pc0FwcC5sZWN0dXJlVW5pdC5jb21wbGV0ZWRUb29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJoYW5kbGVDbGljaygkZXZlbnQsIGZhbHNlKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJ0ZXh0LWJvZHktc2Vjb25kYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGdcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtpY29uXT1cImZhU3F1YXJlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbmdiVG9vbHRpcF09XCInYXJ0ZW1pc0FwcC5sZWN0dXJlVW5pdC51bmNvbXBsZXRlZFRvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cImhhbmRsZUNsaWNrKCRldmVudCwgdHJ1ZSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtYm9keSB1bml0LWNhcmQtYm9keVwiIFtuZ2JDb2xsYXBzZV09XCJpc0NvbGxhcHNlZFwiPlxuICAgICAgICAgICAgQGlmICghaXNDb2xsYXBzZWQpIHtcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicmF0aW8gcmF0aW8tMTZ4OVwiPlxuICAgICAgICAgICAgICAgICAgICA8aWZyYW1lIGlkPVwidmlkZW9GcmFtZVwiIGNsYXNzPVwicm91bmRlZFwiIFtzcmNdPVwidmlkZW9VcmwgfCBzYWZlUmVzb3VyY2VVcmxcIiBhbGxvdz1cImZ1bGxzY3JlZW5cIj48L2lmcmFtZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHt7IHZpZGVvVW5pdD8uZGVzY3JpcHRpb24gfX1cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IExlY3R1cmVVbml0LCBMZWN0dXJlVW5pdFR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvbGVjdHVyZS11bml0L2xlY3R1cmVVbml0Lm1vZGVsJztcblxuZXhwb3J0IGNsYXNzIFRleHRVbml0IGV4dGVuZHMgTGVjdHVyZVVuaXQge1xuICAgIHB1YmxpYyBjb250ZW50Pzogc3RyaW5nO1xuXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKExlY3R1cmVVbml0VHlwZS5URVhUKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTYWZlSHRtbCB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xuaW1wb3J0IHsgZmFFeHRlcm5hbExpbmtBbHQsIGZhU2Nyb2xsIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IFRleHRVbml0IH0gZnJvbSAnYXBwL2VudGl0aWVzL2xlY3R1cmUtdW5pdC90ZXh0VW5pdC5tb2RlbCc7XG5pbXBvcnQgeyBBcnRlbWlzTWFya2Rvd25TZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9tYXJrZG93bi5zZXJ2aWNlJztcbmltcG9ydCB7IGh0bWxGb3JNYXJrZG93biB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC9tYXJrZG93bi5jb252ZXJzaW9uLnV0aWwnO1xuaW1wb3J0IHsgTGVjdHVyZVVuaXRDb21wbGV0aW9uRXZlbnQgfSBmcm9tICdhcHAvb3ZlcnZpZXcvY291cnNlLWxlY3R1cmVzL2NvdXJzZS1sZWN0dXJlLWRldGFpbHMuY29tcG9uZW50JztcbmltcG9ydCB7IGZhU3F1YXJlLCBmYVNxdWFyZUNoZWNrIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtcmVndWxhci1zdmctaWNvbnMnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS10ZXh0LXVuaXQnLFxuICAgIHRlbXBsYXRlVXJsOiAnLi90ZXh0LXVuaXQuY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuLi9sZWN0dXJlLXVuaXQuY29tcG9uZW50LnNjc3MnXSxcbn0pXG5leHBvcnQgY2xhc3MgVGV4dFVuaXRDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEBJbnB1dCgpIHRleHRVbml0OiBUZXh0VW5pdDtcbiAgICBASW5wdXQoKSBpc1ByZXNlbnRhdGlvbk1vZGUgPSBmYWxzZTtcbiAgICBAT3V0cHV0KCkgb25Db21wbGV0aW9uOiBFdmVudEVtaXR0ZXI8TGVjdHVyZVVuaXRDb21wbGV0aW9uRXZlbnQ+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gICAgaXNDb2xsYXBzZWQgPSB0cnVlO1xuXG4gICAgZm9ybWF0dGVkQ29udGVudD86IFNhZmVIdG1sO1xuXG4gICAgLy8gSWNvbnNcbiAgICBmYUV4dGVybmFsTGlua0FsdCA9IGZhRXh0ZXJuYWxMaW5rQWx0O1xuICAgIGZhU2Nyb2xsID0gZmFTY3JvbGw7XG4gICAgZmFTcXVhcmUgPSBmYVNxdWFyZTtcbiAgICBmYVNxdWFyZUNoZWNrID0gZmFTcXVhcmVDaGVjaztcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgYXJ0ZW1pc01hcmtkb3duOiBBcnRlbWlzTWFya2Rvd25TZXJ2aWNlKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIGlmICh0aGlzLnRleHRVbml0Py5jb250ZW50KSB7XG4gICAgICAgICAgICB0aGlzLmZvcm1hdHRlZENvbnRlbnQgPSB0aGlzLmFydGVtaXNNYXJrZG93bi5zYWZlSHRtbEZvck1hcmtkb3duKHRoaXMudGV4dFVuaXQuY29udGVudCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBoYW5kbGVDb2xsYXBzZShldmVudDogRXZlbnQpIHtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIHRoaXMuaXNDb2xsYXBzZWQgPSAhdGhpcy5pc0NvbGxhcHNlZDtcblxuICAgICAgICBpZiAoIXRoaXMuaXNDb2xsYXBzZWQpIHtcbiAgICAgICAgICAgIC8vIE1hcmsgdGhlIHVuaXQgYXMgY29tcGxldGVkIHdoZW4gdGhlIHVzZXIgb3BlbnMgdGhlIHVuaXRcbiAgICAgICAgICAgIHRoaXMub25Db21wbGV0aW9uLmVtaXQoeyBsZWN0dXJlVW5pdDogdGhpcy50ZXh0VW5pdCwgY29tcGxldGVkOiB0cnVlIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgaGFuZGxlQ2xpY2soZXZlbnQ6IEV2ZW50LCBjb21wbGV0ZWQ6IGJvb2xlYW4pIHtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIHRoaXMub25Db21wbGV0aW9uLmVtaXQoeyBsZWN0dXJlVW5pdDogdGhpcy50ZXh0VW5pdCwgY29tcGxldGVkIH0pO1xuICAgIH1cblxuICAgIG9wZW5Qb3B1cChldmVudDogRXZlbnQpIHtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG5cbiAgICAgICAgY29uc3Qgd2luID0gd2luZG93Lm9wZW4oJ2Fib3V0OmJsYW5rJywgJ19ibGFuaycpITtcbiAgICAgICAgd2luLmRvY3VtZW50LndyaXRlKGA8aHRtbD48aGVhZD48dGl0bGU+JHt0aGlzLnRleHRVbml0Lm5hbWV9PC90aXRsZT5gKTtcbiAgICAgICAgd2luLmRvY3VtZW50LndyaXRlKCc8bGluayByZWw9XCJzdHlsZXNoZWV0XCIgaHJlZj1cInB1YmxpYy9jb250ZW50L2dpdGh1Yi1tYXJrZG93bi5jc3NcIj4nKTtcbiAgICAgICAgd2luLmRvY3VtZW50LndyaXRlKCc8L2hlYWQ+PGJvZHkgY2xhc3M9XCJtYXJrZG93bi1ib2R5XCI+Jyk7XG4gICAgICAgIHdpbi5kb2N1bWVudC53cml0ZSgnPC9ib2R5PjwvaHRtbD4nKTtcbiAgICAgICAgd2luLmRvY3VtZW50LmNsb3NlKCk7XG4gICAgICAgIHdpbi5kb2N1bWVudC5ib2R5LmlubmVySFRNTCA9IGh0bWxGb3JNYXJrZG93bih0aGlzLnRleHRVbml0LmNvbnRlbnQsIFtdKTtcbiAgICAgICAgd2luLmZvY3VzKCk7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInJvdyBhbGlnbi1pdGVtcy1jZW50ZXIgbXktMiBweC0yXCI+XG4gICAgPGRpdiBjbGFzcz1cImNhcmQgdW5pdC1jYXJkXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWhlYWRlciB1bml0LWNhcmQtaGVhZGVyIHJvdyBhbGlnbi1jb250ZW50LWNlbnRlciBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblwiIChjbGljayk9XCJoYW5kbGVDb2xsYXBzZSgkZXZlbnQpXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLWF1dG8gcm93IGFsaWduLWNvbnRlbnQtY2VudGVyIGZsZXgtc2hyaW5rLTFcIj5cbiAgICAgICAgICAgICAgICA8aDUgY2xhc3M9XCJtLTAgZnctbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIGNsYXNzPVwibWUtMlwiIFtpY29uXT1cImZhU2Nyb2xsXCIgW25nYlRvb2x0aXBdPVwiJ2FydGVtaXNBcHAudGV4dFVuaXQudG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICB7eyB0ZXh0VW5pdD8ubmFtZSA/IHRleHRVbml0Lm5hbWUgOiAnJyB9fVxuICAgICAgICAgICAgICAgICAgICBAaWYgKCF0ZXh0VW5pdD8udmlzaWJsZVRvU3R1ZGVudHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJiYWRnZSBiZy13YXJuaW5nIG1zLTJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5nYlRvb2x0aXA9XCJ7eyAnYXJ0ZW1pc0FwcC50ZXh0VW5pdC5ub3RSZWxlYXNlZFRvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fSB7eyB0ZXh0VW5pdD8ucmVsZWFzZURhdGUgfCBhcnRlbWlzRGF0ZSB9fVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuY291cnNlT3ZlcnZpZXcuZXhlcmNpc2VMaXN0Lm5vdFJlbGVhc2VkJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvaDU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0byBkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyIGdhcC0zIHBlLTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwicG9wdXBCdXR0b25cIiBjbGFzcz1cImJ0biBidG4tc20gYnRuLXByaW1hcnlcIiAoY2xpY2spPVwib3BlblBvcHVwKCRldmVudClcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFFeHRlcm5hbExpbmtBbHRcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZC1ub25lIGQtbWQtaW5saW5lXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC50ZXh0VW5pdC5pc29sYXRlZFwiPlZpZXcgSXNvbGF0ZWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgQGlmICghaXNQcmVzZW50YXRpb25Nb2RlICYmIHRleHRVbml0LnZpc2libGVUb1N0dWRlbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmICh0ZXh0VW5pdC5jb21wbGV0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInRleHQtc3VjY2Vzc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsZ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtpY29uXT1cImZhU3F1YXJlQ2hlY2tcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbmdiVG9vbHRpcF09XCInYXJ0ZW1pc0FwcC5sZWN0dXJlVW5pdC5jb21wbGV0ZWRUb29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwiaGFuZGxlQ2xpY2soJGV2ZW50LCBmYWxzZSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInRleHQtYm9keS1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGdcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbaWNvbl09XCJmYVNxdWFyZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ2JUb29sdGlwXT1cIidhcnRlbWlzQXBwLmxlY3R1cmVVbml0LnVuY29tcGxldGVkVG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cImhhbmRsZUNsaWNrKCRldmVudCwgdHJ1ZSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtYm9keSB1bml0LWNhcmQtYm9keVwiIFtuZ2JDb2xsYXBzZV09XCJpc0NvbGxhcHNlZFwiPlxuICAgICAgICAgICAgQGlmIChmb3JtYXR0ZWRDb250ZW50KSB7XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1hcmtkb3duLXByZXZpZXdcIiBpZD1cInByaW50Q29udGVudFwiIFtpbm5lckh0bWxdPVwiZm9ybWF0dGVkQ29udGVudFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgTGVjdHVyZVVuaXQsIExlY3R1cmVVbml0VHlwZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9sZWN0dXJlLXVuaXQvbGVjdHVyZVVuaXQubW9kZWwnO1xuXG5leHBvcnQgY2xhc3MgT25saW5lVW5pdCBleHRlbmRzIExlY3R1cmVVbml0IHtcbiAgICBwdWJsaWMgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gICAgcHVibGljIHNvdXJjZT86IHN0cmluZztcblxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihMZWN0dXJlVW5pdFR5cGUuT05MSU5FKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE91dHB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZmFTcXVhcmUsIGZhU3F1YXJlQ2hlY2sgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1yZWd1bGFyLXN2Zy1pY29ucyc7XG5pbXBvcnQgeyBmYUxpbmssIGZhVXBSaWdodEZyb21TcXVhcmUgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgT25saW5lVW5pdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9sZWN0dXJlLXVuaXQvb25saW5lVW5pdC5tb2RlbCc7XG5pbXBvcnQgeyBMZWN0dXJlVW5pdENvbXBsZXRpb25FdmVudCB9IGZyb20gJ2FwcC9vdmVydmlldy9jb3Vyc2UtbGVjdHVyZXMvY291cnNlLWxlY3R1cmUtZGV0YWlscy5jb21wb25lbnQnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1vbmxpbmUtdW5pdCcsXG4gICAgdGVtcGxhdGVVcmw6ICcuL29ubGluZS11bml0LmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi4vbGVjdHVyZS11bml0LmNvbXBvbmVudC5zY3NzJ10sXG59KVxuZXhwb3J0IGNsYXNzIE9ubGluZVVuaXRDb21wb25lbnQge1xuICAgIEBJbnB1dCgpIG9ubGluZVVuaXQ6IE9ubGluZVVuaXQ7XG4gICAgQElucHV0KCkgaXNQcmVzZW50YXRpb25Nb2RlID0gZmFsc2U7XG4gICAgQE91dHB1dCgpIG9uQ29tcGxldGlvbjogRXZlbnRFbWl0dGVyPExlY3R1cmVVbml0Q29tcGxldGlvbkV2ZW50PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICAgIGlzQ29sbGFwc2VkID0gdHJ1ZTtcblxuICAgIC8vIEljb25zXG4gICAgZmFMaW5rID0gZmFMaW5rO1xuICAgIGZhVXBSaWdodEZyb21TcXVhcmUgPSBmYVVwUmlnaHRGcm9tU3F1YXJlO1xuICAgIGZhU3F1YXJlID0gZmFTcXVhcmU7XG4gICAgZmFTcXVhcmVDaGVjayA9IGZhU3F1YXJlQ2hlY2s7XG5cbiAgICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgICBoYW5kbGVDb2xsYXBzZShldmVudDogRXZlbnQpIHtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIHRoaXMuaXNDb2xsYXBzZWQgPSAhdGhpcy5pc0NvbGxhcHNlZDtcbiAgICB9XG5cbiAgICBoYW5kbGVDbGljayhldmVudDogRXZlbnQsIGNvbXBsZXRlZDogYm9vbGVhbikge1xuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgdGhpcy5vbkNvbXBsZXRpb24uZW1pdCh7IGxlY3R1cmVVbml0OiB0aGlzLm9ubGluZVVuaXQsIGNvbXBsZXRlZCB9KTtcbiAgICB9XG5cbiAgICBvcGVuTGluayhldmVudDogRXZlbnQpIHtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIGlmICh0aGlzLm9ubGluZVVuaXQ/LnNvdXJjZSkge1xuICAgICAgICAgICAgd2luZG93Lm9wZW4odGhpcy5vbmxpbmVVbml0LnNvdXJjZSwgJ19ibGFuaycpO1xuICAgICAgICAgICAgdGhpcy5vbkNvbXBsZXRpb24uZW1pdCh7IGxlY3R1cmVVbml0OiB0aGlzLm9ubGluZVVuaXQsIGNvbXBsZXRlZDogdHJ1ZSB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGdldCBkb21haW5OYW1lKCk6IHN0cmluZyB7XG4gICAgICAgIGlmICh0aGlzLm9ubGluZVVuaXQ/LnNvdXJjZSkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVUkwodGhpcy5vbmxpbmVVbml0LnNvdXJjZSkuaG9zdG5hbWUucmVwbGFjZSgnd3d3LicsICcnKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gJyc7XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInJvdyBhbGlnbi1pdGVtcy1jZW50ZXIgbXktMiBweC0yXCI+XG4gICAgPGRpdiBjbGFzcz1cImNhcmQgdW5pdC1jYXJkXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWhlYWRlciB1bml0LWNhcmQtaGVhZGVyIHJvdyBhbGlnbi1jb250ZW50LWNlbnRlciBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblwiIChjbGljayk9XCJoYW5kbGVDb2xsYXBzZSgkZXZlbnQpXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLWF1dG8gcm93IGFsaWduLWNvbnRlbnQtY2VudGVyIGZsZXgtc2hyaW5rLTFcIj5cbiAgICAgICAgICAgICAgICA8aDUgY2xhc3M9XCJtLTAgZnctbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIGNsYXNzPVwibWUtMiBjb2wtYXV0b1wiIFtpY29uXT1cImZhTGlua1wiIFtuZ2JUb29sdGlwXT1cIidhcnRlbWlzQXBwLm9ubGluZVVuaXQudG9vbHRpcCcgfCBhcnRlbWlzVHJhbnNsYXRlXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICB7eyBvbmxpbmVVbml0Py5uYW1lIH19XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoIW9ubGluZVVuaXQ/LnZpc2libGVUb1N0dWRlbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYmFkZ2UgYmctd2FybmluZyBtcy0yXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuZ2JUb29sdGlwPVwie3sgJ2FydGVtaXNBcHAub25saW5lVW5pdC5ub3RSZWxlYXNlZFRvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fSB7eyBvbmxpbmVVbml0Py5yZWxlYXNlRGF0ZSB8IGFydGVtaXNEYXRlIH19XCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5jb3Vyc2VPdmVydmlldy5leGVyY2lzZUxpc3Qubm90UmVsZWFzZWQnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPC9oNT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1hdXRvIGQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIgZ2FwLTMgcGUtMlwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNtIGJ0bi1wcmltYXJ5XCIgKGNsaWNrKT1cIm9wZW5MaW5rKCRldmVudClcIiBbbmdiVG9vbHRpcF09XCJkb21haW5OYW1lXCI+XG4gICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhVXBSaWdodEZyb21TcXVhcmVcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZC1ub25lIGQtbWQtaW5saW5lXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5vbmxpbmVVbml0LmRvT3BlblwiPk9wZW4gbGluazwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICBAaWYgKCFpc1ByZXNlbnRhdGlvbk1vZGUgJiYgb25saW5lVW5pdC52aXNpYmxlVG9TdHVkZW50cykge1xuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLWF1dG8gbXktYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChvbmxpbmVVbml0LmNvbXBsZXRlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwidGV4dC1zdWNjZXNzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxnXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2ljb25dPVwiZmFTcXVhcmVDaGVja1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ2JUb29sdGlwXT1cIidhcnRlbWlzQXBwLmxlY3R1cmVVbml0LmNvbXBsZXRlZFRvb2x0aXAnIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJoYW5kbGVDbGljaygkZXZlbnQsIGZhbHNlKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwidGV4dC1ib2R5LXNlY29uZGFyeVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsZ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtpY29uXT1cImZhU3F1YXJlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nYlRvb2x0aXBdPVwiJ2FydGVtaXNBcHAubGVjdHVyZVVuaXQudW5jb21wbGV0ZWRUb29sdGlwJyB8IGFydGVtaXNUcmFuc2xhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwiaGFuZGxlQ2xpY2soJGV2ZW50LCB0cnVlKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1ib2R5IHVuaXQtY2FyZC1ib2R5XCIgW25nYkNvbGxhcHNlXT1cImlzQ29sbGFwc2VkXCI+XG4gICAgICAgICAgICA8cCBjbGFzcz1cIm1iLTBcIj57eyBvbmxpbmVVbml0Py5kZXNjcmlwdGlvbiB9fTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG48L2Rpdj5cbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBcnRlbWlzU2hhcmVkTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9zaGFyZWQubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRDb21wb25lbnRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL2NvbXBvbmVudHMvc2hhcmVkLWNvbXBvbmVudC5tb2R1bGUnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NoYXJlZFBpcGVzTW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC9waXBlcy9zaGFyZWQtcGlwZXMubW9kdWxlJztcbmltcG9ydCB7IEFydGVtaXNDb3Vyc2VFeGVyY2lzZVJvd01vZHVsZSB9IGZyb20gJ2FwcC9vdmVydmlldy9jb3Vyc2UtZXhlcmNpc2VzL2NvdXJzZS1leGVyY2lzZS1yb3cubW9kdWxlJztcbmltcG9ydCB7IEV4ZXJjaXNlVW5pdENvbXBvbmVudCB9IGZyb20gJ2FwcC9vdmVydmlldy9jb3Vyc2UtbGVjdHVyZXMvZXhlcmNpc2UtdW5pdC9leGVyY2lzZS11bml0LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBdHRhY2htZW50VW5pdENvbXBvbmVudCB9IGZyb20gJ2FwcC9vdmVydmlldy9jb3Vyc2UtbGVjdHVyZXMvYXR0YWNobWVudC11bml0L2F0dGFjaG1lbnQtdW5pdC5jb21wb25lbnQnO1xuaW1wb3J0IHsgVmlkZW9Vbml0Q29tcG9uZW50IH0gZnJvbSAnYXBwL292ZXJ2aWV3L2NvdXJzZS1sZWN0dXJlcy92aWRlby11bml0L3ZpZGVvLXVuaXQuY29tcG9uZW50JztcbmltcG9ydCB7IFRleHRVbml0Q29tcG9uZW50IH0gZnJvbSAnYXBwL292ZXJ2aWV3L2NvdXJzZS1sZWN0dXJlcy90ZXh0LXVuaXQvdGV4dC11bml0LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBBcnRlbWlzTWFya2Rvd25Nb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL21hcmtkb3duLm1vZHVsZSc7XG5pbXBvcnQgeyBPbmxpbmVVbml0Q29tcG9uZW50IH0gZnJvbSAnYXBwL292ZXJ2aWV3L2NvdXJzZS1sZWN0dXJlcy9vbmxpbmUtdW5pdC9vbmxpbmUtdW5pdC5jb21wb25lbnQnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlLCBBcnRlbWlzU2hhcmVkQ29tcG9uZW50TW9kdWxlLCBBcnRlbWlzU2hhcmVkUGlwZXNNb2R1bGUsIEFydGVtaXNDb3Vyc2VFeGVyY2lzZVJvd01vZHVsZSwgQXJ0ZW1pc01hcmtkb3duTW9kdWxlXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtFeGVyY2lzZVVuaXRDb21wb25lbnQsIEF0dGFjaG1lbnRVbml0Q29tcG9uZW50LCBWaWRlb1VuaXRDb21wb25lbnQsIFRleHRVbml0Q29tcG9uZW50LCBPbmxpbmVVbml0Q29tcG9uZW50XSxcbiAgICBleHBvcnRzOiBbRXhlcmNpc2VVbml0Q29tcG9uZW50LCBBdHRhY2htZW50VW5pdENvbXBvbmVudCwgVmlkZW9Vbml0Q29tcG9uZW50LCBUZXh0VW5pdENvbXBvbmVudCwgT25saW5lVW5pdENvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIEFydGVtaXNMZWN0dXJlVW5pdHNNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUdhO0FBSGI7OztBQUdNLElBQU8sZUFBUCxjQUE0QixZQUFXO01BQ2xDO01BRVAsY0FBQTtBQUNJLGNBQU0sZ0JBQWdCLFFBQVE7TUFDbEM7Ozs7OztBQ1JKLFNBQVMsV0FBVyxhQUFhLE9BQU8seUJBQXlCOzs7O0FDQzdELElBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsSUFBQSx1QkFBQSxHQUFBLDJCQUFBLENBQUE7QUFPSixJQUFBLG9CQUFBLEdBQUEsSUFBQTs7OztBQUxRLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsWUFBQSxPQUFBLGFBQUEsUUFBQSxFQUFtQyxVQUFBLE9BQUEsTUFBQSxFQUFBLGlCQUFBLEtBQUEsRUFBQSxzQkFBQSxPQUFBLGtCQUFBOzs7QURIM0MsSUFVYTtBQVZiOztBQUNBO0FBQ0E7O0FBUU0sSUFBTyx3QkFBUCxNQUFPLHVCQUFxQjtNQUNKO01BRTFCLGNBQUE7QUFDSSxhQUFLLGlCQUFpQjtNQUMxQjtNQUVTO01BQ0E7TUFDQSxxQkFBcUI7O3lCQVRyQix3QkFBcUI7TUFBQTtnRUFBckIsd0JBQXFCLFdBQUEsQ0FBQSxDQUFBLG1CQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsY0FBQSxTQUFBLG1DQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBOzs7OztBQ1ZsQyxVQUFBLHdCQUFBLEdBQUEsOENBQUEsR0FBQSxDQUFBOzs7QUFBQSxVQUFBLDJCQUFBLElBQUEsSUFBQSxnQkFBQSxPQUFBLE9BQUEsSUFBQSxhQUFBLGFBQUEsSUFBQSxTQUFBLElBQUEsRUFBQTs7Ozs7b0ZEVWEsdUJBQXFCLEVBQUEsV0FBQSx3QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVWbEMsSUFJYTtBQUpiOzs7QUFJTSxJQUFPLGlCQUFQLGNBQThCLFlBQVc7TUFDcEM7TUFDQTtNQUNBO01BRVAsY0FBQTtBQUNJLGNBQU0sZ0JBQWdCLFVBQVU7TUFDcEM7Ozs7OztBQ1hKLFNBQVMsYUFBQUEsWUFBVyxjQUFjLFNBQUFDLFFBQU8sY0FBYztBQUN2RCxTQUNJLFlBQ0EsUUFDQSxlQUNBLFlBQ0EsV0FDQSxhQUNBLGFBQ0EsYUFDQSxXQUNBLFdBQ0Esa0JBQ0Esa0JBQ0c7QUFJUCxTQUFTLFVBQVUscUJBQXFCOzs7Ozs7QUNWaEIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTs7O0FBSUksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFKUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHFDQUFBLGNBQUEsSUFBQSwwQkFBQSxHQUFBLEdBQUEsOENBQUEsR0FBQSxLQUFBLDBCQUFBLEdBQUEsR0FBQSxPQUFBLGtCQUFBLE9BQUEsT0FBQSxPQUFBLGVBQUEsY0FBQSxPQUFBLE9BQUEsT0FBQSxlQUFBLFdBQUEsV0FBQSxHQUFBLEVBQUE7QUFFQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtDQUFBLDBCQUFBLEdBQUEsR0FBQSxvREFBQSxHQUFBLDRCQUFBOzs7Ozs7QUFhQSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsV0FBQSxFQUFBO0FBS0ksSUFBQSx5QkFBQSxTQUFBLFNBQUEsdUZBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxPQUFBLFlBQUEsUUFBb0IsS0FBSyxDQUFDO0lBQUEsQ0FBQTs7QUFDdEMsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQUpRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLGFBQUEsRUFBc0IsY0FBQSwwQkFBQSxHQUFBLEdBQUEseUNBQUEsQ0FBQTs7Ozs7O0FBSzFCLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxXQUFBLEVBQUE7QUFLSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSx1RkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLFFBQUEsWUFBQSxRQUFvQixJQUFJLENBQUM7SUFBQSxDQUFBOztBQUNyQyxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBSlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsUUFBQSxFQUFpQixjQUFBLDBCQUFBLEdBQUEsR0FBQSwyQ0FBQSxDQUFBOzs7OztBQWI3QixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLCtEQUFBLEdBQUEsQ0FBQSxFQVFDLEdBQUEsK0RBQUEsR0FBQSxDQUFBO0FBU0wsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQWxCUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxlQUFBLFlBQUEsSUFBQSxDQUFBOzs7OztBQXVCUixJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBZ0MsSUFBQSxxQkFBQSxDQUFBOztBQUFpRSxJQUFBLDJCQUFBO0FBQ2pHLElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBSHdDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSwwQkFBQSxHQUFBLEdBQUEsc0NBQUEsR0FBQSxJQUFBO0FBQ2hDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMEJBQUEsMEJBQUEsR0FBQSxHQUFBLE9BQUEsa0JBQUEsT0FBQSxPQUFBLE9BQUEsZUFBQSxjQUFBLE9BQUEsT0FBQSxPQUFBLGVBQUEsV0FBQSxVQUFBLEdBQUEsb0JBQUE7Ozs7O0FBSUosSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQWdDLElBQUEscUJBQUEsQ0FBQTs7QUFBOEQsSUFBQSwyQkFBQTtBQUM5RixJQUFBLHFCQUFBLENBQUE7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBSHdDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSwwQkFBQSxHQUFBLEdBQUEsbUNBQUEsR0FBQSxJQUFBO0FBQ2hDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMEJBQUEsT0FBQSxrQkFBQSxPQUFBLE9BQUEsT0FBQSxlQUFBLGNBQUEsT0FBQSxPQUFBLE9BQUEsZUFBQSxXQUFBLFNBQUEsb0JBQUE7Ozs7O0FBSUosSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQWdDLElBQUEscUJBQUEsQ0FBQTs7QUFBK0QsSUFBQSwyQkFBQTtBQUMvRixJQUFBLHFCQUFBLENBQUE7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBSHdDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSwwQkFBQSxHQUFBLEdBQUEsb0NBQUEsR0FBQSxJQUFBO0FBQ2hDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMEJBQUEsT0FBQSxZQUFBLEdBQUEsb0JBQUE7Ozs7O0FBSUosSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsSUFBQTtBQUNBLElBQUEscUJBQUEsQ0FBQTtBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDBCQUFBLE9BQUEsa0JBQUEsT0FBQSxPQUFBLE9BQUEsZUFBQSxhQUFBLG9CQUFBOzs7QURuRXBCLElBMEJhO0FBMUJiOztBQWVBO0FBQ0E7Ozs7O0FBVU0sSUFBTywwQkFBUCxNQUFPLHlCQUF1QjtNQVlaO01BWFg7TUFDQSxxQkFBcUI7TUFDcEIsZUFBeUQsSUFBSSxhQUFZO01BRW5GLGNBQWM7TUFHZCxhQUFhO01BQ2IsV0FBVztNQUNYLGdCQUFnQjtNQUVoQixZQUFvQixhQUF3QjtBQUF4QixhQUFBLGNBQUE7TUFBMkI7TUFFL0MsZUFBZSxPQUFZO0FBQ3ZCLGNBQU0sZ0JBQWU7QUFDckIsYUFBSyxjQUFjLENBQUMsS0FBSztNQUM3QjtNQUVBLG1CQUFtQixPQUFZO0FBQzNCLGNBQU0sZ0JBQWU7QUFDckIsWUFBSSxLQUFLLGdCQUFnQixZQUFZLE1BQU07QUFDdkMsZUFBSyxZQUFZLGFBQWEsS0FBSyxnQkFBZ0IsWUFBWSxJQUFJO0FBQ25FLGVBQUssYUFBYSxLQUFLLEVBQUUsYUFBYSxLQUFLLGdCQUFnQixXQUFXLEtBQUksQ0FBRTs7TUFFcEY7TUFFQSxZQUFZLE9BQWMsV0FBa0I7QUFDeEMsY0FBTSxnQkFBZTtBQUNyQixhQUFLLGFBQWEsS0FBSyxFQUFFLGFBQWEsS0FBSyxnQkFBZ0IsVUFBUyxDQUFFO01BQzFFO01BS0EsY0FBVztBQUNQLFlBQUksS0FBSyxnQkFBZ0IsWUFBWSxNQUFNO0FBQ3ZDLGlCQUFPLEtBQUssZ0JBQWdCLFlBQVksS0FBSyxVQUFVLEtBQUssZ0JBQWdCLFlBQVksS0FBSyxZQUFZLEdBQUcsSUFBSSxDQUFDO2VBQzlHO0FBQ0gsaUJBQU87O01BRWY7TUFLQSxvQkFBaUI7QUFDYixZQUFJLEtBQUssZ0JBQWdCLFlBQVksTUFBTTtBQUN2QyxnQkFBTSxnQkFBZ0IsS0FBSyxnQkFBZ0IsWUFBWSxLQUFLLE1BQU0sR0FBRyxFQUFFLElBQUcsRUFBSSxrQkFBaUI7QUFDL0Ysa0JBQVEsZUFBZTtZQUNuQixLQUFLO1lBQ0wsS0FBSztZQUNMLEtBQUs7WUFDTCxLQUFLO1lBQ0wsS0FBSztBQUNELHFCQUFPO1lBQ1gsS0FBSztBQUNELHFCQUFPO1lBQ1gsS0FBSztZQUNMLEtBQUs7QUFDRCxxQkFBTztZQUNYLEtBQUs7WUFDTCxLQUFLO1lBQ0wsS0FBSztBQUNELHFCQUFPO1lBQ1gsS0FBSztZQUNMLEtBQUs7WUFDTCxLQUFLO0FBQ0QscUJBQU87WUFDWCxLQUFLO1lBQ0wsS0FBSztZQUNMLEtBQUs7WUFDTCxLQUFLO1lBQ0wsS0FBSztBQUNELHFCQUFPO1lBQ1gsS0FBSztBQUNELHFCQUFPO1lBQ1gsS0FBSztZQUNMLEtBQUs7WUFDTCxLQUFLO1lBQ0wsS0FBSztBQUNELHFCQUFPO1lBQ1gsS0FBSztZQUNMLEtBQUs7WUFDTCxLQUFLO1lBQ0wsS0FBSztBQUNELHFCQUFPO1lBQ1gsS0FBSztZQUNMLEtBQUs7WUFDTCxLQUFLO1lBQ0wsS0FBSztBQUNELHFCQUFPO1lBQ1g7QUFDSSxxQkFBTzs7O0FBR25CLGVBQU87TUFDWDs7eUJBakdTLDBCQUF1QixnQ0FBQSxXQUFBLENBQUE7TUFBQTtpRUFBdkIsMEJBQXVCLFdBQUEsQ0FBQSxDQUFBLHFCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsZ0JBQUEsa0JBQUEsb0JBQUEscUJBQUEsR0FBQSxTQUFBLEVBQUEsY0FBQSxlQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLE9BQUEsc0JBQUEsUUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxlQUFBLG9CQUFBLE9BQUEsd0JBQUEsMkJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsT0FBQSx3QkFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLEdBQUEsUUFBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsVUFBQSxzQkFBQSxTQUFBLE1BQUEsR0FBQSxDQUFBLE1BQUEsa0JBQUEsR0FBQSxPQUFBLGVBQUEsVUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsc0NBQUEsR0FBQSxVQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxrQkFBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxjQUFBLFFBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxHQUFBLGdCQUFBLEdBQUEsUUFBQSxjQUFBLE9BQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxHQUFBLHVCQUFBLEdBQUEsUUFBQSxjQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxpQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQzFCcEMsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUEyRixVQUFBLHlCQUFBLFNBQUEsU0FBQSxzREFBQSxRQUFBO0FBQUEsbUJBQVMsSUFBQSxlQUFBLE1BQUE7VUFBc0IsQ0FBQTtBQUN0SCxVQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxXQUFBLENBQUE7O0FBQTBILFVBQUEscUJBQUEsSUFBQSxHQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUMxSCxVQUFBLHFCQUFBLEVBQUE7QUFDQSxVQUFBLHlCQUFBLElBQUEsaURBQUEsR0FBQSxDQUFBO0FBUUosVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUEyRCxVQUFBLHlCQUFBLFNBQUEsU0FBQSwwREFBQSxRQUFBO0FBQUEsbUJBQVMsSUFBQSxtQkFBQSxNQUFBO1VBQTBCLENBQUE7QUFDMUYsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxRQUFBLENBQUE7QUFBbUYsVUFBQSxxQkFBQSxJQUFBLFVBQUE7QUFBUSxVQUFBLDJCQUFBO0FBQy9GLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsaURBQUEsR0FBQSxDQUFBO0FBcUJKLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsaURBQUEsR0FBQSxDQUFBLEVBS0MsSUFBQSxpREFBQSxHQUFBLENBQUEsRUFBQSxJQUFBLGlEQUFBLEdBQUEsQ0FBQSxFQUFBLElBQUEsaURBQUEsR0FBQSxDQUFBO0FBbUJMLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBcEUwQyxVQUFBLHdCQUFBLEVBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxrQkFBQSxDQUFBLEVBQTRCLGNBQUEsMEJBQUEsSUFBQSxJQUFBLG1DQUFBLENBQUE7QUFDbEQsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSwyQkFBQSxJQUFBLGtCQUFBLE9BQUEsT0FBQSxJQUFBLGVBQUEsY0FBQSxPQUFBLE9BQUEsSUFBQSxlQUFBLFdBQUEsUUFBQSxJQUFBLGtCQUFBLE9BQUEsT0FBQSxJQUFBLGVBQUEsY0FBQSxPQUFBLE9BQUEsSUFBQSxlQUFBLFdBQUEsT0FBQSxJQUFBLHdCQUFBO0FBQ0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLEVBQUEsSUFBQSxrQkFBQSxPQUFBLE9BQUEsSUFBQSxlQUFBLHFCQUFBLEtBQUEsRUFBQTtBQVlTLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLFVBQUE7QUFHYixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLHNCQUFBLElBQUEsZUFBQSxvQkFBQSxLQUFBLEVBQUE7QUF1QjhCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsZUFBQSxJQUFBLFdBQUE7QUFDbEMsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxLQUFBLElBQUEsa0JBQUEsT0FBQSxPQUFBLElBQUEsZUFBQSxjQUFBLE9BQUEsT0FBQSxJQUFBLGVBQUEsV0FBQSxjQUFBLEtBQUEsRUFBQTtBQU1BLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsS0FBQSxJQUFBLGtCQUFBLE9BQUEsT0FBQSxJQUFBLGVBQUEsY0FBQSxPQUFBLE9BQUEsSUFBQSxlQUFBLFdBQUEsV0FBQSxLQUFBLEVBQUE7QUFNQSxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLEtBQUEsSUFBQSxrQkFBQSxPQUFBLE9BQUEsSUFBQSxlQUFBLGNBQUEsT0FBQSxPQUFBLElBQUEsZUFBQSxXQUFBLFFBQUEsS0FBQSxFQUFBO0FBTUEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxLQUFBLElBQUEsa0JBQUEsT0FBQSxPQUFBLElBQUEsZUFBQSxlQUFBLEtBQUEsRUFBQTs7Ozs7cUZEdENDLHlCQUF1QixFQUFBLFdBQUEsMEJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFMUJwQyxJQUVhO0FBRmI7OztBQUVNLElBQU8sWUFBUCxjQUF5QixZQUFXO01BQy9CO01BRUE7TUFFUCxjQUFBO0FBQ0ksY0FBTSxnQkFBZ0IsS0FBSztNQUMvQjs7Ozs7O0FDVEosU0FBUyxhQUFBQyxZQUFXLGdCQUFBQyxlQUFjLFNBQUFDLFFBQWUsVUFBQUMsZUFBYztBQUMvRCxTQUFTLGVBQWU7QUFFeEIsT0FBTyxlQUFlO0FBRXRCLFNBQVMsWUFBQUMsV0FBVSxpQkFBQUMsc0JBQXFCOzs7Ozs7QUNHaEIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTs7O0FBSUksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFKUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHFDQUFBLGNBQUEsSUFBQSwwQkFBQSxHQUFBLEdBQUEseUNBQUEsR0FBQSxLQUFBLDBCQUFBLEdBQUEsR0FBQSxPQUFBLGFBQUEsT0FBQSxPQUFBLE9BQUEsVUFBQSxXQUFBLEdBQUEsRUFBQTtBQUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsa0NBQUEsMEJBQUEsR0FBQSxHQUFBLG9EQUFBLEdBQUEsNEJBQUE7Ozs7OztBQVFKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxXQUFBLENBQUE7QUFLSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSxrRkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLE9BQUEsWUFBQSxRQUFvQixLQUFLLENBQUM7SUFBQSxDQUFBOztBQUN0QyxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBSlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsYUFBQSxFQUFzQixjQUFBLDBCQUFBLEdBQUEsR0FBQSx5Q0FBQSxDQUFBOzs7Ozs7QUFLMUIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUtJLElBQUEseUJBQUEsU0FBQSxTQUFBLGtGQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsT0FBQSxZQUFBLFFBQW9CLElBQUksQ0FBQztJQUFBLENBQUE7O0FBQ3JDLElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFKUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxRQUFBLEVBQWlCLGNBQUEsMEJBQUEsR0FBQSxHQUFBLDJDQUFBLENBQUE7Ozs7O0FBYjdCLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsMERBQUEsR0FBQSxDQUFBLEVBUUMsR0FBQSwwREFBQSxHQUFBLENBQUE7QUFTTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBbEJRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLFVBQUEsWUFBQSxJQUFBLENBQUE7Ozs7O0FBc0JKLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsVUFBQSxFQUFBOztBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFGZ0QsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxPQUFBLDBCQUFBLEdBQUEsR0FBQSxPQUFBLFFBQUEsR0FBQSxtQ0FBQTs7O0FEMUM1RCxJQVlhO0FBWmI7O0FBRUE7Ozs7QUFVTSxJQUFPLHFCQUFQLE1BQU8sb0JBQWtCO01BQ2xCO01BQ0EscUJBQXFCO01BQ3BCLGVBQXlELElBQUlKLGNBQVk7TUFFbkY7TUFDQSxjQUFjO01BQ2Q7TUFHQSxvQkFBb0I7UUFFaEIsT0FBTywrRUFBK0U7O01BSTFGLFVBQVU7TUFDVixXQUFXRztNQUNYLGdCQUFnQkM7TUFFaEIsY0FBQTtNQUFlO01BRWYsV0FBUTtBQUNKLFlBQUksS0FBSyxXQUFXLFFBQVE7QUFFeEIsY0FBSSxLQUFLLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssS0FBSyxVQUFVLE1BQU8sQ0FBQyxLQUFLLENBQUMsYUFBYSxVQUFVLE1BQU0sS0FBSyxVQUFVLE1BQU0sR0FBRztBQUM1SCxpQkFBSyxXQUFXLEtBQUssVUFBVTs7O01BRzNDO01BRUEsZUFBZSxPQUFZO0FBQ3ZCLGNBQU0sZ0JBQWU7QUFDckIsYUFBSyxjQUFjLENBQUMsS0FBSztBQUV6QixZQUFJLENBQUMsS0FBSyxhQUFhO0FBRW5CLGVBQUssb0JBQW9CLFdBQ3JCLE1BQUs7QUFDRCxpQkFBSyxhQUFhLEtBQUssRUFBRSxhQUFhLEtBQUssV0FBVyxXQUFXLEtBQUksQ0FBRTtVQUMzRSxHQUNBLE1BQU8sS0FBSyxDQUFDO2VBRWQ7QUFDSCx1QkFBYSxLQUFLLGlCQUFpQjs7TUFFM0M7TUFFQSxZQUFZLE9BQWMsV0FBa0I7QUFDeEMsY0FBTSxnQkFBZTtBQUNyQixhQUFLLGFBQWEsS0FBSyxFQUFFLGFBQWEsS0FBSyxXQUFXLFVBQVMsQ0FBRTtNQUNyRTs7eUJBbkRTLHFCQUFrQjtNQUFBO2lFQUFsQixxQkFBa0IsV0FBQSxDQUFBLENBQUEsZ0JBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxXQUFBLGFBQUEsb0JBQUEscUJBQUEsR0FBQSxTQUFBLEVBQUEsY0FBQSxlQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLE9BQUEsc0JBQUEsUUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxlQUFBLG9CQUFBLE9BQUEsd0JBQUEsMkJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsT0FBQSx3QkFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLEdBQUEsUUFBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsa0JBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsY0FBQSxRQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFVBQUEsc0JBQUEsU0FBQSxNQUFBLEdBQUEsQ0FBQSxRQUFBLE1BQUEsR0FBQSxnQkFBQSxHQUFBLFFBQUEsY0FBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLE1BQUEsR0FBQSx1QkFBQSxHQUFBLFFBQUEsY0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsWUFBQSxHQUFBLENBQUEsTUFBQSxjQUFBLFNBQUEsY0FBQSxHQUFBLFdBQUEsR0FBQSxLQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsNEJBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNaL0IsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUEyRixVQUFBLHlCQUFBLFNBQUEsU0FBQSxpREFBQSxRQUFBO0FBQUEsbUJBQVMsSUFBQSxlQUFBLE1BQUE7VUFBc0IsQ0FBQTtBQUN0SCxVQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxXQUFBLENBQUE7O0FBQXlHLFVBQUEscUJBQUEsSUFBQSxHQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUN6RyxVQUFBLHFCQUFBLEVBQUE7QUFDQSxVQUFBLHlCQUFBLElBQUEsNENBQUEsR0FBQSxDQUFBO0FBUUosVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsNENBQUEsR0FBQSxDQUFBO0FBcUJKLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsNENBQUEsR0FBQSxDQUFBO0FBS0EsVUFBQSxxQkFBQSxFQUFBO0FBQ0osVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUE1QzBDLFVBQUEsd0JBQUEsRUFBQTtBQUFBLFVBQUEseUJBQUEsUUFBQSxJQUFBLE9BQUEsRUFBZ0IsY0FBQSwwQkFBQSxJQUFBLEdBQUEsOEJBQUEsQ0FBQTtBQUN0QyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLGlDQUFBLDJCQUFBLElBQUEsYUFBQSxPQUFBLE9BQUEsSUFBQSxVQUFBLFFBQUEsSUFBQSxVQUFBLE9BQUEsSUFBQSx3QkFBQTtBQUNBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxFQUFBLElBQUEsYUFBQSxPQUFBLE9BQUEsSUFBQSxVQUFBLHFCQUFBLEtBQUEsRUFBQTtBQVVSLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxDQUFBLElBQUEsc0JBQUEsSUFBQSxVQUFBLG9CQUFBLEtBQUEsRUFBQTtBQXNCa0MsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxlQUFBLElBQUEsV0FBQTtBQUNsQyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLGNBQUEsS0FBQSxFQUFBO0FBS0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSxrQkFBQSxJQUFBLGFBQUEsT0FBQSxPQUFBLElBQUEsVUFBQSxhQUFBLFlBQUE7Ozs7O3FGRGpDQyxvQkFBa0IsRUFBQSxXQUFBLHFCQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRVovQixJQUVhO0FBRmI7OztBQUVNLElBQU8sV0FBUCxjQUF3QixZQUFXO01BQzlCO01BRVAsY0FBQTtBQUNJLGNBQU0sZ0JBQWdCLElBQUk7TUFDOUI7Ozs7OztBQ1BKLFNBQVMsYUFBQUMsWUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFlLFVBQUFDLGVBQWM7QUFFL0QsU0FBUyxtQkFBbUIsZ0JBQWdCO0FBSzVDLFNBQVMsWUFBQUMsV0FBVSxpQkFBQUMsc0JBQXFCOzs7Ozs7QUNDaEIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTs7O0FBSUksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFKUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHFDQUFBLGNBQUEsSUFBQSwwQkFBQSxHQUFBLEdBQUEsd0NBQUEsR0FBQSxLQUFBLDBCQUFBLEdBQUEsR0FBQSxPQUFBLFlBQUEsT0FBQSxPQUFBLE9BQUEsU0FBQSxXQUFBLEdBQUEsRUFBQTtBQUVBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsa0NBQUEsMEJBQUEsR0FBQSxHQUFBLG9EQUFBLEdBQUEsNEJBQUE7Ozs7OztBQWFBLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxXQUFBLEVBQUE7QUFLSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSxpRkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLE9BQUEsWUFBQSxRQUFvQixLQUFLLENBQUM7SUFBQSxDQUFBOztBQUN0QyxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBSlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsYUFBQSxFQUFzQixjQUFBLDBCQUFBLEdBQUEsR0FBQSx5Q0FBQSxDQUFBOzs7Ozs7QUFLMUIsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUtJLElBQUEseUJBQUEsU0FBQSxTQUFBLGlGQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQVMsMEJBQUEsT0FBQSxZQUFBLFFBQW9CLElBQUksQ0FBQztJQUFBLENBQUE7O0FBQ3JDLElBQUEsMkJBQUE7QUFDTCxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7Ozs7QUFKUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxRQUFBLEVBQWlCLGNBQUEsMEJBQUEsR0FBQSxHQUFBLDJDQUFBLENBQUE7Ozs7O0FBYjdCLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEseURBQUEsR0FBQSxDQUFBLEVBUUMsR0FBQSx5REFBQSxHQUFBLENBQUE7QUFTTCxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLG9CQUFBOzs7O0FBbEJRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLFNBQUEsWUFBQSxJQUFBLENBQUE7Ozs7O0FBdUJSLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7Ozs7QUFGd0QsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLE9BQUEsa0JBQUEsNEJBQUE7OztBRGhEcEUsSUFjYTtBQWRiOztBQUdBO0FBQ0E7QUFDQTs7Ozs7QUFTTSxJQUFPLG9CQUFQLE1BQU8sbUJBQWlCO01BZU47TUFkWDtNQUNBLHFCQUFxQjtNQUNwQixlQUF5RCxJQUFJSixjQUFZO01BRW5GLGNBQWM7TUFFZDtNQUdBLG9CQUFvQjtNQUNwQixXQUFXO01BQ1gsV0FBV0c7TUFDWCxnQkFBZ0JDO01BRWhCLFlBQW9CLGlCQUF1QztBQUF2QyxhQUFBLGtCQUFBO01BQTBDO01BRTlELFdBQVE7QUFDSixZQUFJLEtBQUssVUFBVSxTQUFTO0FBQ3hCLGVBQUssbUJBQW1CLEtBQUssZ0JBQWdCLG9CQUFvQixLQUFLLFNBQVMsT0FBTzs7TUFFOUY7TUFFQSxlQUFlLE9BQVk7QUFDdkIsY0FBTSxnQkFBZTtBQUNyQixhQUFLLGNBQWMsQ0FBQyxLQUFLO0FBRXpCLFlBQUksQ0FBQyxLQUFLLGFBQWE7QUFFbkIsZUFBSyxhQUFhLEtBQUssRUFBRSxhQUFhLEtBQUssVUFBVSxXQUFXLEtBQUksQ0FBRTs7TUFFOUU7TUFFQSxZQUFZLE9BQWMsV0FBa0I7QUFDeEMsY0FBTSxnQkFBZTtBQUNyQixhQUFLLGFBQWEsS0FBSyxFQUFFLGFBQWEsS0FBSyxVQUFVLFVBQVMsQ0FBRTtNQUNwRTtNQUVBLFVBQVUsT0FBWTtBQUNsQixjQUFNLGdCQUFlO0FBRXJCLGNBQU0sTUFBTSxPQUFPLEtBQUssZUFBZSxRQUFRO0FBQy9DLFlBQUksU0FBUyxNQUFNLHNCQUFzQixLQUFLLFNBQVMsSUFBSSxVQUFVO0FBQ3JFLFlBQUksU0FBUyxNQUFNLG1FQUFtRTtBQUN0RixZQUFJLFNBQVMsTUFBTSxxQ0FBcUM7QUFDeEQsWUFBSSxTQUFTLE1BQU0sZ0JBQWdCO0FBQ25DLFlBQUksU0FBUyxNQUFLO0FBQ2xCLFlBQUksU0FBUyxLQUFLLFlBQVksZ0JBQWdCLEtBQUssU0FBUyxTQUFTLENBQUEsQ0FBRTtBQUN2RSxZQUFJLE1BQUs7TUFDYjs7eUJBakRTLG9CQUFpQixnQ0FBQSxzQkFBQSxDQUFBO01BQUE7aUVBQWpCLG9CQUFpQixXQUFBLENBQUEsQ0FBQSxlQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLG9CQUFBLHFCQUFBLEdBQUEsU0FBQSxFQUFBLGNBQUEsZUFBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxPQUFBLHNCQUFBLFFBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxvQkFBQSxPQUFBLHdCQUFBLDJCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLE9BQUEsd0JBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLFFBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFVBQUEsc0JBQUEsU0FBQSxNQUFBLEdBQUEsQ0FBQSxNQUFBLGVBQUEsR0FBQSxPQUFBLFVBQUEsZUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsZ0NBQUEsR0FBQSxVQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxrQkFBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxjQUFBLFFBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxHQUFBLGdCQUFBLEdBQUEsUUFBQSxjQUFBLE9BQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxHQUFBLHVCQUFBLEdBQUEsUUFBQSxjQUFBLE9BQUEsR0FBQSxDQUFBLE1BQUEsZ0JBQUEsR0FBQSxvQkFBQSxHQUFBLFdBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSwyQkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ2Q5QixVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQTJGLFVBQUEseUJBQUEsU0FBQSxTQUFBLGdEQUFBLFFBQUE7QUFBQSxtQkFBUyxJQUFBLGVBQUEsTUFBQTtVQUFzQixDQUFBO0FBQ3RILFVBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTs7QUFDQSxVQUFBLHFCQUFBLEVBQUE7QUFDQSxVQUFBLHlCQUFBLElBQUEsMkNBQUEsR0FBQSxDQUFBO0FBUUosVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUF3RCxVQUFBLHlCQUFBLFNBQUEsU0FBQSxvREFBQSxRQUFBO0FBQUEsbUJBQVMsSUFBQSxVQUFBLE1BQUE7VUFBaUIsQ0FBQTtBQUM5RSxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsV0FBQSxDQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUE2RSxVQUFBLHFCQUFBLElBQUEsZUFBQTtBQUFhLFVBQUEsMkJBQUE7QUFDOUYsVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSwyQ0FBQSxHQUFBLENBQUE7QUFxQkosVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSwyQ0FBQSxHQUFBLENBQUE7QUFLSixVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQWpEMEMsVUFBQSx3QkFBQSxFQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsUUFBQSxFQUFpQixjQUFBLDBCQUFBLElBQUEsR0FBQSw2QkFBQSxDQUFBO0FBQ3ZDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsaUNBQUEsMkJBQUEsSUFBQSxZQUFBLE9BQUEsT0FBQSxJQUFBLFNBQUEsUUFBQSxJQUFBLFNBQUEsT0FBQSxJQUFBLHdCQUFBO0FBQ0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLEVBQUEsSUFBQSxZQUFBLE9BQUEsT0FBQSxJQUFBLFNBQUEscUJBQUEsS0FBQSxFQUFBO0FBWVMsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsaUJBQUE7QUFHYixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLHNCQUFBLElBQUEsU0FBQSxvQkFBQSxLQUFBLEVBQUE7QUF1QjhCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsZUFBQSxJQUFBLFdBQUE7QUFDbEMsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsbUJBQUEsS0FBQSxFQUFBOzs7OztxRkRoQ0MsbUJBQWlCLEVBQUEsV0FBQSxvQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVkOUIsSUFFYTtBQUZiOzs7QUFFTSxJQUFPLGFBQVAsY0FBMEIsWUFBVztNQUNoQztNQUNBO01BRVAsY0FBQTtBQUNJLGNBQU0sZ0JBQWdCLE1BQU07TUFDaEM7Ozs7OztBQ1JKLFNBQVMsYUFBQUMsWUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFPLFVBQUFDLGVBQWM7QUFDdkQsU0FBUyxZQUFBQyxXQUFVLGlCQUFBQyxzQkFBcUI7QUFDeEMsU0FBUyxRQUFRLDJCQUEyQjs7Ozs7O0FDTXBCLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7OztBQUlJLElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBSlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxxQ0FBQSxjQUFBLElBQUEsMEJBQUEsR0FBQSxHQUFBLDBDQUFBLEdBQUEsS0FBQSwwQkFBQSxHQUFBLEdBQUEsT0FBQSxjQUFBLE9BQUEsT0FBQSxPQUFBLFdBQUEsV0FBQSxHQUFBLEVBQUE7QUFFQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLGtDQUFBLDBCQUFBLEdBQUEsR0FBQSxvREFBQSxHQUFBLDRCQUFBOzs7Ozs7QUFhQSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsV0FBQSxFQUFBO0FBS0ksSUFBQSx5QkFBQSxTQUFBLFNBQUEsbUZBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQSxDQUFBO0FBQUEsYUFBUywwQkFBQSxPQUFBLFlBQUEsUUFBb0IsS0FBSyxDQUFDO0lBQUEsQ0FBQTs7QUFDdEMsSUFBQSwyQkFBQTtBQUNMLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQUpRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxPQUFBLGFBQUEsRUFBc0IsY0FBQSwwQkFBQSxHQUFBLEdBQUEseUNBQUEsQ0FBQTs7Ozs7O0FBSzFCLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxXQUFBLEVBQUE7QUFLSSxJQUFBLHlCQUFBLFNBQUEsU0FBQSxtRkFBQSxRQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFTLDBCQUFBLE9BQUEsWUFBQSxRQUFvQixJQUFJLENBQUM7SUFBQSxDQUFBOztBQUNyQyxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLDRCQUFBOzs7O0FBSlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsUUFBQSxFQUFpQixjQUFBLDBCQUFBLEdBQUEsR0FBQSwyQ0FBQSxDQUFBOzs7OztBQWI3QixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDJEQUFBLEdBQUEsQ0FBQSxFQVFDLEdBQUEsMkRBQUEsR0FBQSxDQUFBO0FBU0wsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxvQkFBQTs7OztBQWxCUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxXQUFBLFlBQUEsSUFBQSxDQUFBOzs7QUR4QnhCLElBV2E7QUFYYjs7QUFHQTs7OztBQVFNLElBQU8sc0JBQVAsTUFBTyxxQkFBbUI7TUFDbkI7TUFDQSxxQkFBcUI7TUFDcEIsZUFBeUQsSUFBSUosY0FBWTtNQUVuRixjQUFjO01BR2QsU0FBUztNQUNULHNCQUFzQjtNQUN0QixXQUFXRztNQUNYLGdCQUFnQkM7TUFFaEIsY0FBQTtNQUFlO01BRWYsZUFBZSxPQUFZO0FBQ3ZCLGNBQU0sZ0JBQWU7QUFDckIsYUFBSyxjQUFjLENBQUMsS0FBSztNQUM3QjtNQUVBLFlBQVksT0FBYyxXQUFrQjtBQUN4QyxjQUFNLGdCQUFlO0FBQ3JCLGFBQUssYUFBYSxLQUFLLEVBQUUsYUFBYSxLQUFLLFlBQVksVUFBUyxDQUFFO01BQ3RFO01BRUEsU0FBUyxPQUFZO0FBQ2pCLGNBQU0sZ0JBQWU7QUFDckIsWUFBSSxLQUFLLFlBQVksUUFBUTtBQUN6QixpQkFBTyxLQUFLLEtBQUssV0FBVyxRQUFRLFFBQVE7QUFDNUMsZUFBSyxhQUFhLEtBQUssRUFBRSxhQUFhLEtBQUssWUFBWSxXQUFXLEtBQUksQ0FBRTs7TUFFaEY7TUFFQSxJQUFJLGFBQVU7QUFDVixZQUFJLEtBQUssWUFBWSxRQUFRO0FBQ3pCLGlCQUFPLElBQUksSUFBSSxLQUFLLFdBQVcsTUFBTSxFQUFFLFNBQVMsUUFBUSxRQUFRLEVBQUU7O0FBRXRFLGVBQU87TUFDWDs7eUJBdENTLHNCQUFtQjtNQUFBO2lFQUFuQixzQkFBbUIsV0FBQSxDQUFBLENBQUEsaUJBQUEsQ0FBQSxHQUFBLFFBQUEsRUFBQSxZQUFBLGNBQUEsb0JBQUEscUJBQUEsR0FBQSxTQUFBLEVBQUEsY0FBQSxlQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLE9BQUEsc0JBQUEsUUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxlQUFBLG9CQUFBLE9BQUEsd0JBQUEsMkJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsT0FBQSx3QkFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFlBQUEsR0FBQSxRQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxVQUFBLHNCQUFBLFNBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLFVBQUEsZUFBQSxHQUFBLGNBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxnQkFBQSxnQ0FBQSxHQUFBLFVBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLGtCQUFBLEdBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsY0FBQSxRQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFNBQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxHQUFBLGdCQUFBLEdBQUEsUUFBQSxjQUFBLE9BQUEsR0FBQSxDQUFBLFFBQUEsTUFBQSxHQUFBLHVCQUFBLEdBQUEsUUFBQSxjQUFBLE9BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSw2QkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1hoQyxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQTJGLFVBQUEseUJBQUEsU0FBQSxTQUFBLGtEQUFBLFFBQUE7QUFBQSxtQkFBUyxJQUFBLGVBQUEsTUFBQTtVQUFzQixDQUFBO0FBQ3RILFVBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsVUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTs7QUFDQSxVQUFBLHFCQUFBLEVBQUE7QUFDQSxVQUFBLHlCQUFBLElBQUEsNkNBQUEsR0FBQSxDQUFBO0FBUUosVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUF1QyxVQUFBLHlCQUFBLFNBQUEsU0FBQSxzREFBQSxRQUFBO0FBQUEsbUJBQVMsSUFBQSxTQUFBLE1BQUE7VUFBZ0IsQ0FBQTtBQUM1RCxVQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxVQUFBLHdCQUFBLElBQUEsV0FBQSxDQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUE2RSxVQUFBLHFCQUFBLElBQUEsV0FBQTtBQUFTLFVBQUEsMkJBQUE7QUFDMUYsVUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSw2Q0FBQSxHQUFBLENBQUE7QUFxQkosVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLFVBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLFVBQUEsNkJBQUEsSUFBQSxLQUFBLEVBQUE7QUFBZ0IsVUFBQSxxQkFBQSxFQUFBO0FBQTZCLFVBQUEsMkJBQUE7QUFDakQsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQTdDbUQsVUFBQSx3QkFBQSxFQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsTUFBQSxFQUFlLGNBQUEsMEJBQUEsSUFBQSxHQUFBLCtCQUFBLENBQUE7QUFDOUMsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxpQ0FBQSwwQkFBQSxJQUFBLGNBQUEsT0FBQSxPQUFBLElBQUEsV0FBQSxNQUFBLHdCQUFBO0FBQ0EsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLEVBQUEsSUFBQSxjQUFBLE9BQUEsT0FBQSxJQUFBLFdBQUEscUJBQUEsS0FBQSxFQUFBO0FBVzhELFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsY0FBQSxJQUFBLFVBQUE7QUFDckQsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxRQUFBLElBQUEsbUJBQUE7QUFHYixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLDRCQUFBLElBQUEsQ0FBQSxJQUFBLHNCQUFBLElBQUEsV0FBQSxvQkFBQSxLQUFBLEVBQUE7QUF1QjhCLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsZUFBQSxJQUFBLFdBQUE7QUFDbEIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSxJQUFBLGNBQUEsT0FBQSxPQUFBLElBQUEsV0FBQSxXQUFBOzs7OztxRkRuQ2YscUJBQW1CLEVBQUEsV0FBQSxzQkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVYaEMsU0FBUyxnQkFBZ0I7O0FBQXpCLElBaUJhO0FBakJiOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBT00sSUFBTyw0QkFBUCxNQUFPLDJCQUF5Qjs7eUJBQXpCLDRCQUF5QjtNQUFBO2dFQUF6QiwyQkFBeUIsQ0FBQTtvRUFKeEIscUJBQXFCLDhCQUE4QiwwQkFBMEIsZ0NBQWdDLHFCQUFxQixFQUFBLENBQUE7Ozs7IiwibmFtZXMiOlsiQ29tcG9uZW50IiwiSW5wdXQiLCJDb21wb25lbnQiLCJFdmVudEVtaXR0ZXIiLCJJbnB1dCIsIk91dHB1dCIsImZhU3F1YXJlIiwiZmFTcXVhcmVDaGVjayIsIkNvbXBvbmVudCIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwiZmFTcXVhcmUiLCJmYVNxdWFyZUNoZWNrIiwiQ29tcG9uZW50IiwiRXZlbnRFbWl0dGVyIiwiSW5wdXQiLCJPdXRwdXQiLCJmYVNxdWFyZSIsImZhU3F1YXJlQ2hlY2siXX0=