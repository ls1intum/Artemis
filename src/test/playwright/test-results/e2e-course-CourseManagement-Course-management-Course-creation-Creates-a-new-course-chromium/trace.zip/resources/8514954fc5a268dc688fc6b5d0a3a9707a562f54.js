import {
  Theme,
  ThemeService,
  init_theme_service
} from "/chunk-PVIIR7SL.js";
import {
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  ExerciseType,
  __esm,
  init_artemis_translate_pipe,
  init_due_date_stat_model,
  init_exercise_model,
  init_shared_module,
  init_utils,
  round
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/dashboards/tutor-participation-graph/progress-bar/progress-bar.component.ts
import { ChangeDetectorRef, Component, Input } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
var ProgressBarComponent;
var init_progress_bar_component = __esm({
  "src/main/webapp/app/shared/dashboards/tutor-participation-graph/progress-bar/progress-bar.component.ts"() {
    init_utils();
    init_theme_service();
    init_theme_service();
    ProgressBarComponent = class _ProgressBarComponent {
      themeService;
      ref;
      tooltip;
      percentage;
      numerator;
      denominator;
      foregroundColorClass;
      backgroundColorClass;
      themeSubscription;
      constructor(themeService, ref) {
        this.themeService = themeService;
        this.ref = ref;
      }
      ngOnInit() {
        this.themeSubscription = this.themeService.getCurrentThemeObservable().subscribe(() => {
          this.chooseProgressBarTextColor();
          this.ref.detectChanges();
        });
      }
      ngOnChanges(changes) {
        if (changes.percentage) {
          this.percentage = round(this.percentage);
          this.chooseProgressBarTextColor();
          this.calculateProgressBarClass();
        }
      }
      ngOnDestroy() {
        this.themeSubscription.unsubscribe();
      }
      calculateProgressBarClass() {
        if (this.percentage < 50) {
          this.backgroundColorClass = "bg-danger";
        } else if (this.percentage < 100) {
          this.backgroundColorClass = "bg-warning";
        } else {
          this.backgroundColorClass = "bg-success";
        }
      }
      chooseProgressBarTextColor() {
        switch (this.themeService.getCurrentTheme()) {
          case Theme.DARK:
            this.foregroundColorClass = "text-white";
            break;
          case Theme.LIGHT:
          default:
            if (this.percentage < 100) {
              this.foregroundColorClass = "text-dark";
            } else {
              this.foregroundColorClass = "text-white";
            }
        }
      }
      static \u0275fac = function ProgressBarComponent_Factory(t) {
        return new (t || _ProgressBarComponent)(i0.\u0275\u0275directiveInject(ThemeService), i0.\u0275\u0275directiveInject(i0.ChangeDetectorRef));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _ProgressBarComponent, selectors: [["jhi-progress-bar"]], inputs: { tooltip: "tooltip", percentage: "percentage", numerator: "numerator", denominator: "denominator" }, features: [i0.\u0275\u0275NgOnChangesFeature], decls: 9, vars: 9, consts: [[1, "progress", "position-relative", 3, "ngbTooltip"], ["role", "progressbar", "aria-valuemin", "0", "aria-valuemax", "100", 1, "progress-bar", 3, "ngClass"], [1, "justify-content-center", "d-flex", "position-absolute", "w-100", 3, "ngClass"]], template: function ProgressBarComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "div", 0);
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275elementStart(2, "div", 1);
          i0.\u0275\u0275text(3, "\n        ");
          i0.\u0275\u0275elementStart(4, "span", 2);
          i0.\u0275\u0275text(5);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(6, "\n    ");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(7, "\n");
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(8, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275property("ngbTooltip", ctx.tooltip);
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275styleProp("width", ctx.percentage + "%");
          i0.\u0275\u0275property("ngClass", ctx.backgroundColorClass);
          i0.\u0275\u0275attribute("aria-valuenow", ctx.percentage);
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275property("ngClass", ctx.foregroundColorClass);
          i0.\u0275\u0275advance(1);
          i0.\u0275\u0275textInterpolate3(" ", ctx.numerator, " / ", ctx.denominator, " (", ctx.percentage + "%", ") ");
        }
      }, dependencies: [i2.NgClass, i3.NgbTooltip], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(ProgressBarComponent, { className: "ProgressBarComponent" });
    })();
  }
});

// src/main/webapp/app/entities/participation/tutor-participation.model.ts
var init_tutor_participation_model = __esm({
  "src/main/webapp/app/entities/participation/tutor-participation.model.ts"() {
  }
});

// src/main/webapp/app/shared/dashboards/tutor-participation-graph/tutor-participation-graph.component.ts
import { Component as Component2, Input as Input2, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { get } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import { faBook, faChalkboardTeacher } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function TutorParticipationGraphComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275elementStart(1, "li", 6);
    i02.\u0275\u0275listener("click", function TutorParticipationGraphComponent_Conditional_13_Template_li_click_1_listener() {
      i02.\u0275\u0275restoreView(_r3);
      const ctx_r2 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r2.navigate());
    });
    i02.\u0275\u0275pipe(2, "artemisTranslate");
    i02.\u0275\u0275text(3, "\n                ");
    i02.\u0275\u0275element(4, "fa-icon", 3);
    i02.\u0275\u0275text(5, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n        ");
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("ngClass", ctx_r0.calculateClasses(ctx_r0.TRAINED))("ngbTooltip", i02.\u0275\u0275pipeBind1(2, 3, "artemisApp.assessmentDashboard.trainOnExampleSubmissions"));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("icon", ctx_r0.faChalkboardTeacher);
  }
}
function TutorParticipationGraphComponent_Conditional_14_For_2_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "div", 8);
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275elementStart(3, "jhi-progress-bar", 5);
    i02.\u0275\u0275pipe(4, "artemisTranslate");
    i02.\u0275\u0275text(5, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(7, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r11 = i02.\u0275\u0275nextContext();
    const i_r6 = ctx_r11.$index;
    const numberOfAssessedSubmissions_r5 = ctx_r11.$implicit;
    const ctx_r10 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("tooltip", i02.\u0275\u0275pipeBind1(4, 4, "artemisApp.assessmentDashboard.assessStudentsLateSubmissions"))("percentage", ctx_r10.percentageLateAssessmentProgressOfCorrectionRound[i_r6])("numerator", numberOfAssessedSubmissions_r5.late)("denominator", (ctx_r10.numberOfSubmissions == null ? null : ctx_r10.numberOfSubmissions.late) || 0);
  }
}
function TutorParticipationGraphComponent_Conditional_14_For_2_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                ");
    i02.\u0275\u0275elementStart(1, "li", 7);
    i02.\u0275\u0275text(2, "\n                    ");
    i02.\u0275\u0275elementStart(3, "div", 8);
    i02.\u0275\u0275text(4, "\n                        ");
    i02.\u0275\u0275elementStart(5, "jhi-progress-bar", 5);
    i02.\u0275\u0275pipe(6, "artemisTranslate");
    i02.\u0275\u0275text(7, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(8, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n                    ");
    i02.\u0275\u0275template(10, TutorParticipationGraphComponent_Conditional_14_For_2_Conditional_10_Template, 8, 6);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(11, "\n            ");
  }
  if (rf & 2) {
    const numberOfAssessedSubmissions_r5 = ctx.$implicit;
    const i_r6 = ctx.$index;
    const ctx_r4 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("ngClass", ctx_r4.calculateClassProgressBar());
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275property("tooltip", i02.\u0275\u0275pipeBind1(6, 6, "artemisApp.assessmentDashboard.assessStudentsSubmissions"))("percentage", ctx_r4.percentageInTimeAssessmentProgressOfCorrectionRound[i_r6])("numerator", numberOfAssessedSubmissions_r5.inTime)("denominator", (ctx_r4.numberOfSubmissions == null ? null : ctx_r4.numberOfSubmissions.inTime) || 0);
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275conditional(10, ctx_r4.numberOfSubmissions && ctx_r4.numberOfSubmissions.late > 0 ? 10 : -1);
  }
}
function TutorParticipationGraphComponent_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275repeaterCreate(1, TutorParticipationGraphComponent_Conditional_14_For_2_Template, 12, 8, null, null, i02.\u0275\u0275repeaterTrackByIdentity);
  }
  if (rf & 2) {
    const ctx_r1 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275repeater(ctx_r1.numberOfAssessmentsOfCorrectionRounds);
  }
}
var TutorParticipationGraphComponent;
var init_tutor_participation_graph_component = __esm({
  "src/main/webapp/app/shared/dashboards/tutor-participation-graph/tutor-participation-graph.component.ts"() {
    init_exercise_model();
    init_tutor_participation_model();
    init_due_date_stat_model();
    init_progress_bar_component();
    init_artemis_translate_pipe();
    TutorParticipationGraphComponent = class _TutorParticipationGraphComponent {
      router;
      tutorParticipation;
      numberOfSubmissions;
      totalNumberOfAssessments;
      numberOfComplaints;
      numberOfOpenComplaints;
      numberOfMoreFeedbackRequests;
      numberOfOpenMoreFeedbackRequests;
      exercise;
      numberOfAssessmentsOfCorrectionRounds;
      tutorParticipationStatus = "NOT_PARTICIPATED";
      ExerciseType = ExerciseType;
      NOT_PARTICIPATED = "NOT_PARTICIPATED";
      REVIEWED_INSTRUCTIONS = "REVIEWED_INSTRUCTIONS";
      TRAINED = "TRAINED";
      COMPLETED = "COMPLETED";
      percentageComplaintsProgress = 0;
      percentageInTimeAssessmentProgressOfCorrectionRound = [];
      percentageLateAssessmentProgressOfCorrectionRound = [];
      routerLink;
      shouldShowManualAssessments = true;
      faBook = faBook;
      faChalkboardTeacher = faChalkboardTeacher;
      constructor(router) {
        this.router = router;
      }
      ngOnInit() {
        this.tutorParticipationStatus = this.tutorParticipation.status;
        const exerciseId = get(this.tutorParticipation, "trainedExampleSubmissions[0].exercise.id");
        const courseId = get(this.tutorParticipation, "trainedExampleSubmissions[0].exercise.course.id");
        if (courseId && exerciseId) {
          this.routerLink = `/course-management/${courseId}/assessment-dashboard/${exerciseId}`;
        }
        this.calculatePercentageAssessmentProgress();
        this.calculatePercentageComplaintsProgress();
        if (this.exercise && this.exercise.type === ExerciseType.PROGRAMMING) {
          this.shouldShowManualAssessments = !this.exercise.allowComplaintsForAutomaticAssessments;
        }
      }
      navigate() {
        if (this.routerLink && this.routerLink.length > 0) {
          this.router.navigate([this.routerLink]);
        }
      }
      ngOnChanges(changes) {
        if (changes.tutorParticipation) {
          this.tutorParticipation = changes.tutorParticipation.currentValue;
          this.tutorParticipationStatus = this.tutorParticipation.status;
        }
        this.calculatePercentageAssessmentProgress();
        this.calculatePercentageComplaintsProgress();
      }
      calculatePercentageAssessmentProgress() {
        for (const [index, numberOfAssessments] of this.numberOfAssessmentsOfCorrectionRounds.entries()) {
          this.percentageInTimeAssessmentProgressOfCorrectionRound[index] = 0;
          this.percentageLateAssessmentProgressOfCorrectionRound[index] = 0;
          if (this.numberOfSubmissions && this.numberOfSubmissions.inTime !== 0) {
            this.percentageInTimeAssessmentProgressOfCorrectionRound[index] = Math.floor(numberOfAssessments.inTime / this.numberOfSubmissions.inTime * 100);
          }
          if (this.numberOfSubmissions && this.numberOfSubmissions?.late !== 0) {
            this.percentageLateAssessmentProgressOfCorrectionRound[index] = Math.floor(numberOfAssessments.late / this.numberOfSubmissions.late * 100);
          }
        }
      }
      calculatePercentageComplaintsProgress() {
        if (this.numberOfComplaints + this.numberOfMoreFeedbackRequests !== 0) {
          this.percentageComplaintsProgress = Math.floor((this.numberOfComplaints - this.numberOfOpenComplaints + (this.numberOfMoreFeedbackRequests - this.numberOfOpenMoreFeedbackRequests)) / (this.numberOfComplaints + this.numberOfMoreFeedbackRequests) * 100);
        }
      }
      calculateClasses(step) {
        if (step === this.tutorParticipationStatus && step !== this.TRAINED) {
          return "active";
        }
        if (step === this.TRAINED && this.tutorParticipationStatus === this.NOT_PARTICIPATED) {
          return "opaque";
        }
        if (step === this.TRAINED && this.exercise.exampleSubmissions && this.tutorParticipation.trainedExampleSubmissions) {
          const reviewedByTutor = this.tutorParticipation.trainedExampleSubmissions.filter((exampleSubmission) => !exampleSubmission.usedForTutorial);
          const exercisesToReview = this.exercise.exampleSubmissions.filter((exampleSubmission) => !exampleSubmission.usedForTutorial);
          const assessedByTutor = this.tutorParticipation.trainedExampleSubmissions.filter((exampleSubmission) => exampleSubmission.usedForTutorial);
          const exercisesToAssess = this.exercise.exampleSubmissions.filter((exampleSubmission) => exampleSubmission.usedForTutorial);
          if (exercisesToReview.length > 0 && exercisesToReview.length !== reviewedByTutor.length || exercisesToAssess.length > 0 && exercisesToAssess.length !== assessedByTutor.length) {
            return "orange";
          }
        }
        return "";
      }
      calculateClassProgressBar() {
        if (this.tutorParticipationStatus !== this.TRAINED && this.tutorParticipationStatus !== this.COMPLETED) {
          return "opaque";
        }
        if (this.tutorParticipationStatus === this.COMPLETED || this.numberOfSubmissions && this.totalNumberOfAssessments && this.numberOfSubmissions.inTime === this.totalNumberOfAssessments.inTime || this.numberOfOpenComplaints + this.numberOfOpenMoreFeedbackRequests === 0) {
          return "active";
        }
        return "orange";
      }
      calculateComplaintsNumerator() {
        return this.numberOfComplaints - this.numberOfOpenComplaints + (this.numberOfMoreFeedbackRequests - this.numberOfOpenMoreFeedbackRequests);
      }
      calculateComplaintsDenominator() {
        return this.numberOfComplaints + this.numberOfMoreFeedbackRequests;
      }
      static \u0275fac = function TutorParticipationGraphComponent_Factory(t) {
        return new (t || _TutorParticipationGraphComponent)(i02.\u0275\u0275directiveInject(i1.Router));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _TutorParticipationGraphComponent, selectors: [["jhi-tutor-participation-graph"]], inputs: { tutorParticipation: "tutorParticipation", numberOfSubmissions: "numberOfSubmissions", totalNumberOfAssessments: "totalNumberOfAssessments", numberOfComplaints: "numberOfComplaints", numberOfOpenComplaints: "numberOfOpenComplaints", numberOfMoreFeedbackRequests: "numberOfMoreFeedbackRequests", numberOfOpenMoreFeedbackRequests: "numberOfOpenMoreFeedbackRequests", exercise: "exercise", numberOfAssessmentsOfCorrectionRounds: "numberOfAssessmentsOfCorrectionRounds" }, features: [i02.\u0275\u0275NgOnChangesFeature], decls: 24, vars: 15, consts: [[1, "row", "justify-content-center", "overflow-hidden"], [1, "not_participated", 3, "ngClass"], [1, "ms-0", 3, "ngClass", "ngbTooltip", "click"], [3, "icon"], [1, "progress-bar-li", "me-0", 3, "ngClass"], [3, "tooltip", "percentage", "numerator", "denominator"], [3, "ngClass", "ngbTooltip", "click"], [1, "progress-bar-li", "stacked-li", 3, "ngClass"], [1, "stacked-item"]], template: function TutorParticipationGraphComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div", 0);
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275elementStart(2, "ul");
          i02.\u0275\u0275text(3, "\n        ");
          i02.\u0275\u0275elementStart(4, "li", 1);
          i02.\u0275\u0275text(5, "0");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(6, "\n        ");
          i02.\u0275\u0275elementStart(7, "li", 2);
          i02.\u0275\u0275listener("click", function TutorParticipationGraphComponent_Template_li_click_7_listener() {
            return ctx.navigate();
          });
          i02.\u0275\u0275pipe(8, "artemisTranslate");
          i02.\u0275\u0275text(9, "\n            ");
          i02.\u0275\u0275element(10, "fa-icon", 3);
          i02.\u0275\u0275text(11, "\n        ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(12, "\n        ");
          i02.\u0275\u0275template(13, TutorParticipationGraphComponent_Conditional_13_Template, 7, 5)(14, TutorParticipationGraphComponent_Conditional_14_Template, 3, 0);
          i02.\u0275\u0275elementStart(15, "li", 4);
          i02.\u0275\u0275text(16, "\n            ");
          i02.\u0275\u0275elementStart(17, "jhi-progress-bar", 5);
          i02.\u0275\u0275pipe(18, "artemisTranslate");
          i02.\u0275\u0275text(19, "\n            ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(20, "\n        ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(21, "\n    ");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(22, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(23, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(4);
          i02.\u0275\u0275property("ngClass", ctx.calculateClasses(ctx.NOT_PARTICIPATED));
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275property("ngClass", ctx.calculateClasses(ctx.REVIEWED_INSTRUCTIONS))("ngbTooltip", i02.\u0275\u0275pipeBind1(8, 11, "artemisApp.assessmentDashboard.readGradingInstructions"));
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275property("icon", ctx.faBook);
          i02.\u0275\u0275advance(3);
          i02.\u0275\u0275conditional(13, ctx.exercise.type !== ctx.ExerciseType.PROGRAMMING ? 13 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275conditional(14, ctx.shouldShowManualAssessments ? 14 : -1);
          i02.\u0275\u0275advance(1);
          i02.\u0275\u0275property("ngClass", ctx.calculateClassProgressBar());
          i02.\u0275\u0275advance(2);
          i02.\u0275\u0275property("tooltip", i02.\u0275\u0275pipeBind1(18, 13, "artemisApp.assessmentDashboard.evaluateStudentsComplaints"))("percentage", ctx.percentageComplaintsProgress)("numerator", ctx.calculateComplaintsNumerator())("denominator", ctx.calculateComplaintsDenominator());
        }
      }, dependencies: [i22.NgClass, i32.NgbTooltip, i4.FaIconComponent, ProgressBarComponent, ArtemisTranslatePipe], styles: ['/* src/main/webapp/app/shared/dashboards/tutor-participation-graph/tutor-participation-graph.component.scss */\njhi-tutor-participation-graph ul {\n  padding-left: 0;\n  z-index: 1;\n  position: relative;\n  white-space: nowrap;\n}\njhi-tutor-participation-graph li {\n  width: 2em;\n  height: 2em;\n  text-align: center;\n  line-height: 2em;\n  border-radius: 1rem;\n  background: green;\n  margin: 0 1rem;\n  display: inline-block;\n  color: white;\n  position: relative;\n}\njhi-tutor-participation-graph li::before {\n  content: "";\n  position: absolute;\n  top: 0.9em;\n  left: -4em;\n  width: 4em;\n  height: 0.2em;\n  background: green;\n  z-index: -1;\n}\njhi-tutor-participation-graph li:first-child::before {\n  display: none;\n}\njhi-tutor-participation-graph .active {\n  background: green;\n}\njhi-tutor-participation-graph .active + .tooltip + li,\njhi-tutor-participation-graph .active + li {\n  background: red;\n}\njhi-tutor-participation-graph .not_participated {\n  display: none;\n}\njhi-tutor-participation-graph .not_participated.active + li + li::before,\njhi-tutor-participation-graph .not_participated.active + li + ngb-tooltip-window + li::before {\n  background: red !important;\n}\njhi-tutor-participation-graph .not_participated + li::before {\n  display: none !important;\n}\njhi-tutor-participation-graph .opaque {\n  background: darkred !important;\n}\njhi-tutor-participation-graph .opaque::before {\n  background: darkred;\n}\njhi-tutor-participation-graph .orange {\n  background: orange !important;\n}\njhi-tutor-participation-graph .orange ~ li::before,\njhi-tutor-participation-graph .orange ~ li::after {\n  background: orange !important;\n}\njhi-tutor-participation-graph .progress-bar-li {\n  width: 8em;\n  background: transparent !important;\n  top: 0.2em;\n}\njhi-tutor-participation-graph .progress-bar-li::before {\n  top: 0.5em;\n}\njhi-tutor-participation-graph .stacked-li {\n  display: inline-flex;\n  flex-flow: column nowrap;\n  height: auto;\n  margin-bottom: 1rem;\n}\njhi-tutor-participation-graph .stacked-li .stacked-item {\n  margin-top: 0.5em;\n  position: relative;\n}\njhi-tutor-participation-graph .stacked-li .stacked-item:first-child {\n  margin-top: 0;\n}\njhi-tutor-participation-graph .stacked-li .stacked-item:first-child::before {\n  width: 4em;\n  left: -4em;\n}\njhi-tutor-participation-graph .stacked-li .stacked-item:first-child::after {\n  width: 2em;\n  right: -2em;\n}\njhi-tutor-participation-graph .stacked-li .stacked-item::before,\njhi-tutor-participation-graph .stacked-li .stacked-item::after {\n  content: "";\n  position: absolute;\n  top: 0.5em;\n  width: 1rem;\n  height: 0.2em;\n  background: green;\n  z-index: -1;\n}\njhi-tutor-participation-graph .stacked-li .stacked-item::before {\n  left: -1rem;\n}\njhi-tutor-participation-graph .stacked-li .stacked-item::after {\n  right: -1rem;\n}\njhi-tutor-participation-graph .stacked-li::before {\n  width: 0.2em;\n  left: -1rem;\n  height: calc(100% - 1rem);\n}\njhi-tutor-participation-graph .stacked-li::after {\n  content: "";\n  position: absolute;\n  top: 0.5em;\n  width: 0.2em;\n  right: -1rem;\n  height: calc(100% - 1rem);\n  background: green;\n  z-index: -1;\n}\njhi-tutor-participation-graph .opaque::after,\njhi-tutor-participation-graph .opaque .stacked-item::before,\njhi-tutor-participation-graph .opaque .stacked-item::after {\n  background: darkred;\n}\njhi-tutor-participation-graph .orange ~ li .stacked-item::before,\njhi-tutor-participation-graph .orange ~ li .stacked-item::after,\njhi-tutor-participation-graph .orange::after,\njhi-tutor-participation-graph .orange .stacked-item::after {\n  background: orange !important;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvZGFzaGJvYXJkcy90dXRvci1wYXJ0aWNpcGF0aW9uLWdyYXBoL3R1dG9yLXBhcnRpY2lwYXRpb24tZ3JhcGguY29tcG9uZW50LnNjc3MiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImpoaS10dXRvci1wYXJ0aWNpcGF0aW9uLWdyYXBoIHtcbiAgICB1bCB7XG4gICAgICAgIHBhZGRpbmctbGVmdDogMDtcbiAgICAgICAgei1pbmRleDogMTtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgIH1cblxuICAgIGxpIHtcbiAgICAgICAgd2lkdGg6IDJlbTtcbiAgICAgICAgaGVpZ2h0OiAyZW07XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgbGluZS1oZWlnaHQ6IDJlbTtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMXJlbTtcbiAgICAgICAgYmFja2dyb3VuZDogZ3JlZW47XG4gICAgICAgIG1hcmdpbjogMCAxcmVtO1xuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAvKnotaW5kZXg6IDE7Ki9cbiAgICB9XG5cbiAgICBsaTo6YmVmb3JlIHtcbiAgICAgICAgY29udGVudDogJyc7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdG9wOiAwLjllbTtcbiAgICAgICAgbGVmdDogLTRlbTtcbiAgICAgICAgd2lkdGg6IDRlbTtcbiAgICAgICAgaGVpZ2h0OiAwLjJlbTtcbiAgICAgICAgYmFja2dyb3VuZDogZ3JlZW47XG4gICAgICAgIHotaW5kZXg6IC0xO1xuICAgIH1cblxuICAgIGxpOmZpcnN0LWNoaWxkOjpiZWZvcmUge1xuICAgICAgICBkaXNwbGF5OiBub25lO1xuICAgIH1cblxuICAgIC5hY3RpdmUge1xuICAgICAgICBiYWNrZ3JvdW5kOiBncmVlbjtcbiAgICB9XG5cbiAgICAuYWN0aXZlICsgLnRvb2x0aXAgKyBsaSxcbiAgICAuYWN0aXZlICsgbGkge1xuICAgICAgICBiYWNrZ3JvdW5kOiByZWQ7XG4gICAgfVxuXG4gICAgLm5vdF9wYXJ0aWNpcGF0ZWQge1xuICAgICAgICBkaXNwbGF5OiBub25lO1xuXG4gICAgICAgICYuYWN0aXZlICsgbGkgKyBsaTo6YmVmb3JlLFxuICAgICAgICAmLmFjdGl2ZSArIGxpICsgbmdiLXRvb2x0aXAtd2luZG93ICsgbGk6OmJlZm9yZSB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiByZWQgIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5ub3RfcGFydGljaXBhdGVkICsgbGk6OmJlZm9yZSB7XG4gICAgICAgIGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICAub3BhcXVlIHtcbiAgICAgICAgYmFja2dyb3VuZDogZGFya3JlZCAhaW1wb3J0YW50O1xuICAgIH1cblxuICAgIC5vcGFxdWU6OmJlZm9yZSB7XG4gICAgICAgIGJhY2tncm91bmQ6IGRhcmtyZWQ7XG4gICAgfVxuXG4gICAgLm9yYW5nZSB7XG4gICAgICAgIGJhY2tncm91bmQ6IG9yYW5nZSAhaW1wb3J0YW50O1xuICAgIH1cblxuICAgIC5vcmFuZ2UgfiBsaTo6YmVmb3JlLFxuICAgIC5vcmFuZ2UgfiBsaTo6YWZ0ZXIge1xuICAgICAgICBiYWNrZ3JvdW5kOiBvcmFuZ2UgIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICAucHJvZ3Jlc3MtYmFyLWxpIHtcbiAgICAgICAgd2lkdGg6IDhlbTtcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgICAgICAgdG9wOiAwLjJlbTtcbiAgICB9XG5cbiAgICAucHJvZ3Jlc3MtYmFyLWxpOjpiZWZvcmUge1xuICAgICAgICB0b3A6IDAuNWVtO1xuICAgIH1cblxuICAgIC5zdGFja2VkLWxpIHtcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgICAgIGZsZXgtZmxvdzogY29sdW1uIG5vd3JhcDtcbiAgICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAxcmVtO1xuXG4gICAgICAgIC5zdGFja2VkLWl0ZW0ge1xuICAgICAgICAgICAgJjpmaXJzdC1jaGlsZCB7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMDtcblxuICAgICAgICAgICAgICAgICY6OmJlZm9yZSB7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiA0ZW07XG4gICAgICAgICAgICAgICAgICAgIGxlZnQ6IC00ZW07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICY6OmFmdGVyIHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDJlbTtcbiAgICAgICAgICAgICAgICAgICAgcmlnaHQ6IC0yZW07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAwLjVlbTtcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICAgICAgICAgJjo6YmVmb3JlLFxuICAgICAgICAgICAgJjo6YWZ0ZXIge1xuICAgICAgICAgICAgICAgIGNvbnRlbnQ6ICcnO1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICB0b3A6IDAuNWVtO1xuICAgICAgICAgICAgICAgIHdpZHRoOiAxcmVtO1xuICAgICAgICAgICAgICAgIGhlaWdodDogMC4yZW07XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogZ3JlZW47XG4gICAgICAgICAgICAgICAgei1pbmRleDogLTE7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICY6OmJlZm9yZSB7XG4gICAgICAgICAgICAgICAgbGVmdDogLTFyZW07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAmOjphZnRlciB7XG4gICAgICAgICAgICAgICAgcmlnaHQ6IC0xcmVtO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnN0YWNrZWQtbGk6OmJlZm9yZSB7XG4gICAgICAgIHdpZHRoOiAwLjJlbTtcbiAgICAgICAgbGVmdDogLTFyZW07XG4gICAgICAgIGhlaWdodDogY2FsYygxMDAlIC0gMXJlbSk7XG4gICAgfVxuXG4gICAgLnN0YWNrZWQtbGk6OmFmdGVyIHtcbiAgICAgICAgY29udGVudDogJyc7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdG9wOiAwLjVlbTtcbiAgICAgICAgd2lkdGg6IDAuMmVtO1xuICAgICAgICByaWdodDogLTFyZW07XG4gICAgICAgIGhlaWdodDogY2FsYygxMDAlIC0gMXJlbSk7XG4gICAgICAgIGJhY2tncm91bmQ6IGdyZWVuO1xuICAgICAgICB6LWluZGV4OiAtMTtcbiAgICB9XG5cbiAgICAub3BhcXVlOjphZnRlcixcbiAgICAub3BhcXVlIC5zdGFja2VkLWl0ZW06OmJlZm9yZSxcbiAgICAub3BhcXVlIC5zdGFja2VkLWl0ZW06OmFmdGVyIHtcbiAgICAgICAgYmFja2dyb3VuZDogZGFya3JlZDtcbiAgICB9XG5cbiAgICAub3JhbmdlIH4gbGkgLnN0YWNrZWQtaXRlbTo6YmVmb3JlLFxuICAgIC5vcmFuZ2UgfiBsaSAuc3RhY2tlZC1pdGVtOjphZnRlcixcbiAgICAub3JhbmdlOjphZnRlcixcbiAgICAub3JhbmdlIC5zdGFja2VkLWl0ZW06OmFmdGVyIHtcbiAgICAgICAgYmFja2dyb3VuZDogb3JhbmdlICFpbXBvcnRhbnQ7XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUNJLDhCQUFBO0FBQ0ksZ0JBQUE7QUFDQSxXQUFBO0FBQ0EsWUFBQTtBQUNBLGVBQUE7O0FBR0osOEJBQUE7QUFDSSxTQUFBO0FBQ0EsVUFBQTtBQUNBLGNBQUE7QUFDQSxlQUFBO0FBQ0EsaUJBQUE7QUFDQSxjQUFBO0FBQ0EsVUFBQSxFQUFBO0FBQ0EsV0FBQTtBQUNBLFNBQUE7QUFDQSxZQUFBOztBQUlKLDhCQUFBLEVBQUE7QUFDSSxXQUFBO0FBQ0EsWUFBQTtBQUNBLE9BQUE7QUFDQSxRQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxjQUFBO0FBQ0EsV0FBQTs7QUFHSiw4QkFBQSxFQUFBLFlBQUE7QUFDSSxXQUFBOztBQUdKLDhCQUFBLENBQUE7QUFDSSxjQUFBOztBQUdKLDhCQUFBLENBSkEsT0FJQSxFQUFBLENBQUEsUUFBQSxFQUFBO0FBQUEsOEJBQUEsQ0FKQSxPQUlBLEVBQUE7QUFFSSxjQUFBOztBQUdKLDhCQUFBLENBQUE7QUFDSSxXQUFBOztBQUVBLDhCQUFBLENBSEosZ0JBR0ksQ0FaSixPQVlJLEVBQUEsR0FBQSxFQUFBLEVBQUE7QUFBQSw4QkFBQSxDQUhKLGdCQUdJLENBWkosT0FZSSxFQUFBLEdBQUEsRUFBQSxtQkFBQSxFQUFBLEVBQUE7QUFFSSxjQUFBOztBQUlSLDhCQUFBLENBVEEsaUJBU0EsRUFBQSxFQUFBO0FBQ0ksV0FBQTs7QUFHSiw4QkFBQSxDQUFBO0FBQ0ksY0FBQTs7QUFHSiw4QkFBQSxDQUpBLE1BSUE7QUFDSSxjQUFBOztBQUdKLDhCQUFBLENBQUE7QUFDSSxjQUFBOztBQUdKLDhCQUFBLENBSkEsT0FJQSxFQUFBLEVBQUE7QUFBQSw4QkFBQSxDQUpBLE9BSUEsRUFBQSxFQUFBO0FBRUksY0FBQTs7QUFHSiw4QkFBQSxDQUFBO0FBQ0ksU0FBQTtBQUNBLGNBQUE7QUFDQSxPQUFBOztBQUdKLDhCQUFBLENBTkEsZUFNQTtBQUNJLE9BQUE7O0FBR0osOEJBQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxhQUFBLE9BQUE7QUFDQSxVQUFBO0FBQ0EsaUJBQUE7O0FBRUEsOEJBQUEsQ0FOSixXQU1JLENBQUE7QUFjSSxjQUFBO0FBQ0EsWUFBQTs7QUFkQSw4QkFBQSxDQVBSLFdBT1EsQ0FESixZQUNJO0FBQ0ksY0FBQTs7QUFFQSw4QkFBQSxDQVZaLFdBVVksQ0FKUixZQUlRLFlBQUE7QUFDSSxTQUFBO0FBQ0EsUUFBQTs7QUFFSiw4QkFBQSxDQWRaLFdBY1ksQ0FSUixZQVFRLFlBQUE7QUFDSSxTQUFBO0FBQ0EsU0FBQTs7QUFPUiw4QkFBQSxDQXZCUixXQXVCUSxDQWpCSixZQWlCSTtBQUFBLDhCQUFBLENBdkJSLFdBdUJRLENBakJKLFlBaUJJO0FBRUksV0FBQTtBQUNBLFlBQUE7QUFDQSxPQUFBO0FBQ0EsU0FBQTtBQUNBLFVBQUE7QUFDQSxjQUFBO0FBQ0EsV0FBQTs7QUFHSiw4QkFBQSxDQWxDUixXQWtDUSxDQTVCSixZQTRCSTtBQUNJLFFBQUE7O0FBRUosOEJBQUEsQ0FyQ1IsV0FxQ1EsQ0EvQkosWUErQkk7QUFDSSxTQUFBOztBQUtaLDhCQUFBLENBM0NBLFVBMkNBO0FBQ0ksU0FBQTtBQUNBLFFBQUE7QUFDQSxVQUFBLEtBQUEsS0FBQSxFQUFBOztBQUdKLDhCQUFBLENBakRBLFVBaURBO0FBQ0ksV0FBQTtBQUNBLFlBQUE7QUFDQSxPQUFBO0FBQ0EsU0FBQTtBQUNBLFNBQUE7QUFDQSxVQUFBLEtBQUEsS0FBQSxFQUFBO0FBQ0EsY0FBQTtBQUNBLFdBQUE7O0FBR0osOEJBQUEsQ0F2RkEsTUF1RkE7QUFBQSw4QkFBQSxDQXZGQSxPQXVGQSxDQXRESSxZQXNESjtBQUFBLDhCQUFBLENBdkZBLE9BdUZBLENBdERJLFlBc0RKO0FBR0ksY0FBQTs7QUFHSiw4QkFBQSxDQXJGQSxPQXFGQSxFQUFBLEdBQUEsQ0E1REksWUE0REo7QUFBQSw4QkFBQSxDQXJGQSxPQXFGQSxFQUFBLEdBQUEsQ0E1REksWUE0REo7QUFBQSw4QkFBQSxDQXJGQSxNQXFGQTtBQUFBLDhCQUFBLENBckZBLE9BcUZBLENBNURJLFlBNERKO0FBSUksY0FBQTs7IiwKICAibmFtZXMiOiBbXQp9Cg== */\n'], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(TutorParticipationGraphComponent, { className: "TutorParticipationGraphComponent" });
    })();
  }
});

// src/main/webapp/app/shared/dashboards/tutor-participation-graph/tutor-participation-graph.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisTutorParticipationGraphModule;
var init_tutor_participation_graph_module = __esm({
  "src/main/webapp/app/shared/dashboards/tutor-participation-graph/tutor-participation-graph.module.ts"() {
    init_progress_bar_component();
    init_tutor_participation_graph_component();
    init_shared_module();
    ArtemisTutorParticipationGraphModule = class _ArtemisTutorParticipationGraphModule {
      static \u0275fac = function ArtemisTutorParticipationGraphModule_Factory(t) {
        return new (t || _ArtemisTutorParticipationGraphModule)();
      };
      static \u0275mod = i03.\u0275\u0275defineNgModule({ type: _ArtemisTutorParticipationGraphModule });
      static \u0275inj = i03.\u0275\u0275defineInjector({ imports: [ArtemisSharedModule] });
    };
  }
});

export {
  ProgressBarComponent,
  init_progress_bar_component,
  TutorParticipationGraphComponent,
  init_tutor_participation_graph_component,
  ArtemisTutorParticipationGraphModule,
  init_tutor_participation_graph_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2Rhc2hib2FyZHMvdHV0b3ItcGFydGljaXBhdGlvbi1ncmFwaC9wcm9ncmVzcy1iYXIvcHJvZ3Jlc3MtYmFyLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2Rhc2hib2FyZHMvdHV0b3ItcGFydGljaXBhdGlvbi1ncmFwaC9wcm9ncmVzcy1iYXIvcHJvZ3Jlc3MtYmFyLmNvbXBvbmVudC5odG1sIiwic3JjL21haW4vd2ViYXBwL2FwcC9lbnRpdGllcy9wYXJ0aWNpcGF0aW9uL3R1dG9yLXBhcnRpY2lwYXRpb24ubW9kZWwudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9kYXNoYm9hcmRzL3R1dG9yLXBhcnRpY2lwYXRpb24tZ3JhcGgvdHV0b3ItcGFydGljaXBhdGlvbi1ncmFwaC5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9kYXNoYm9hcmRzL3R1dG9yLXBhcnRpY2lwYXRpb24tZ3JhcGgvdHV0b3ItcGFydGljaXBhdGlvbi1ncmFwaC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2Rhc2hib2FyZHMvdHV0b3ItcGFydGljaXBhdGlvbi1ncmFwaC90dXRvci1wYXJ0aWNpcGF0aW9uLWdyYXBoLm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDaGFuZ2VEZXRlY3RvclJlZiwgQ29tcG9uZW50LCBJbnB1dCwgT25DaGFuZ2VzLCBPbkRlc3Ryb3ksIE9uSW5pdCwgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgcm91bmQgfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvdXRpbHMnO1xuaW1wb3J0IHsgVGhlbWUsIFRoZW1lU2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3RoZW1lL3RoZW1lLnNlcnZpY2UnO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXByb2dyZXNzLWJhcicsXG4gICAgdGVtcGxhdGVVcmw6ICcuL3Byb2dyZXNzLWJhci5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIFByb2dyZXNzQmFyQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIE9uRGVzdHJveSB7XG4gICAgQElucHV0KCkgcHVibGljIHRvb2x0aXA6IHN0cmluZztcbiAgICBASW5wdXQoKSBwdWJsaWMgcGVyY2VudGFnZTogbnVtYmVyO1xuICAgIEBJbnB1dCgpIHB1YmxpYyBudW1lcmF0b3I6IG51bWJlcjtcbiAgICBASW5wdXQoKSBwdWJsaWMgZGVub21pbmF0b3I6IG51bWJlcjtcblxuICAgIGZvcmVncm91bmRDb2xvckNsYXNzOiBzdHJpbmc7XG4gICAgYmFja2dyb3VuZENvbG9yQ2xhc3M6IHN0cmluZztcbiAgICB0aGVtZVN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgdGhlbWVTZXJ2aWNlOiBUaGVtZVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgcmVmOiBDaGFuZ2VEZXRlY3RvclJlZixcbiAgICApIHt9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy50aGVtZVN1YnNjcmlwdGlvbiA9IHRoaXMudGhlbWVTZXJ2aWNlLmdldEN1cnJlbnRUaGVtZU9ic2VydmFibGUoKS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5jaG9vc2VQcm9ncmVzc0JhclRleHRDb2xvcigpO1xuXG4gICAgICAgICAgICAvLyBNYW51YWxseSBydW4gY2hhbmdlIGRldGVjdGlvbiBhcyBpdCBkb2Vzbid0IGRvIGl0IGF1dG9tYXRpY2FsbHkgZm9yIHNvbWUgcmVhc29uXG4gICAgICAgICAgICB0aGlzLnJlZi5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcbiAgICAgICAgaWYgKGNoYW5nZXMucGVyY2VudGFnZSkge1xuICAgICAgICAgICAgdGhpcy5wZXJjZW50YWdlID0gcm91bmQodGhpcy5wZXJjZW50YWdlKTtcbiAgICAgICAgICAgIHRoaXMuY2hvb3NlUHJvZ3Jlc3NCYXJUZXh0Q29sb3IoKTtcbiAgICAgICAgICAgIHRoaXMuY2FsY3VsYXRlUHJvZ3Jlc3NCYXJDbGFzcygpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMudGhlbWVTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBGdW5jdGlvbiB0byByZW5kZXIgdGhlIGNvcnJlY3QgcHJvZ3Jlc3MgYmFyIGNsYXNzXG4gICAgICovXG4gICAgY2FsY3VsYXRlUHJvZ3Jlc3NCYXJDbGFzcygpOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMucGVyY2VudGFnZSA8IDUwKSB7XG4gICAgICAgICAgICB0aGlzLmJhY2tncm91bmRDb2xvckNsYXNzID0gJ2JnLWRhbmdlcic7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5wZXJjZW50YWdlIDwgMTAwKSB7XG4gICAgICAgICAgICB0aGlzLmJhY2tncm91bmRDb2xvckNsYXNzID0gJ2JnLXdhcm5pbmcnO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5iYWNrZ3JvdW5kQ29sb3JDbGFzcyA9ICdiZy1zdWNjZXNzJztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEZ1bmN0aW9uIHRvIGNoYW5nZSB0aGUgdGV4dCBjb2xvciB0byBpbmRpY2F0ZSBhIGZpbmlzaGVkIHN0YXR1c1xuICAgICAqL1xuICAgIGNob29zZVByb2dyZXNzQmFyVGV4dENvbG9yKCkge1xuICAgICAgICBzd2l0Y2ggKHRoaXMudGhlbWVTZXJ2aWNlLmdldEN1cnJlbnRUaGVtZSgpKSB7XG4gICAgICAgICAgICBjYXNlIFRoZW1lLkRBUks6XG4gICAgICAgICAgICAgICAgdGhpcy5mb3JlZ3JvdW5kQ29sb3JDbGFzcyA9ICd0ZXh0LXdoaXRlJztcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgVGhlbWUuTElHSFQ6XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIGlmICh0aGlzLnBlcmNlbnRhZ2UgPCAxMDApIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5mb3JlZ3JvdW5kQ29sb3JDbGFzcyA9ICd0ZXh0LWRhcmsnO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZm9yZWdyb3VuZENvbG9yQ2xhc3MgPSAndGV4dC13aGl0ZSc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInByb2dyZXNzIHBvc2l0aW9uLXJlbGF0aXZlXCIgW25nYlRvb2x0aXBdPVwidG9vbHRpcFwiPlxuICAgIDxkaXZcbiAgICAgICAgY2xhc3M9XCJwcm9ncmVzcy1iYXJcIlxuICAgICAgICByb2xlPVwicHJvZ3Jlc3NiYXJcIlxuICAgICAgICBbbmdDbGFzc109XCJiYWNrZ3JvdW5kQ29sb3JDbGFzc1wiXG4gICAgICAgIFtzdHlsZS53aWR0aF09XCJwZXJjZW50YWdlICsgJyUnXCJcbiAgICAgICAgYXR0ci5hcmlhLXZhbHVlbm93PVwie3sgcGVyY2VudGFnZSB9fVwiXG4gICAgICAgIGFyaWEtdmFsdWVtaW49XCIwXCJcbiAgICAgICAgYXJpYS12YWx1ZW1heD1cIjEwMFwiXG4gICAgPlxuICAgICAgICA8c3BhbiBjbGFzcz1cImp1c3RpZnktY29udGVudC1jZW50ZXIgZC1mbGV4IHBvc2l0aW9uLWFic29sdXRlIHctMTAwXCIgW25nQ2xhc3NdPVwiZm9yZWdyb3VuZENvbG9yQ2xhc3NcIj4ge3sgbnVtZXJhdG9yIH19IC8ge3sgZGVub21pbmF0b3IgfX0gKHt7IHBlcmNlbnRhZ2UgKyAnJScgfX0pIDwvc3Bhbj5cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgVXNlciB9IGZyb20gJ2FwcC9jb3JlL3VzZXIvdXNlci5tb2RlbCc7XG5pbXBvcnQgeyBCYXNlRW50aXR5IH0gZnJvbSAnYXBwL3NoYXJlZC9tb2RlbC9iYXNlLWVudGl0eSc7XG5pbXBvcnQgeyBFeGVyY2lzZSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGVyY2lzZS5tb2RlbCc7XG5pbXBvcnQgeyBFeGFtcGxlU3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGFtcGxlLXN1Ym1pc3Npb24ubW9kZWwnO1xuXG5leHBvcnQgY29uc3QgZW51bSBUdXRvclBhcnRpY2lwYXRpb25TdGF0dXMge1xuICAgIE5PVF9QQVJUSUNJUEFURUQgPSAnTk9UX1BBUlRJQ0lQQVRFRCcsXG4gICAgUkVWSUVXRURfSU5TVFJVQ1RJT05TID0gJ1JFVklFV0VEX0lOU1RSVUNUSU9OUycsXG4gICAgVFJBSU5FRCA9ICdUUkFJTkVEJyxcbiAgICBDT01QTEVURUQgPSAnQ09NUExFVEVEJyxcbn1cblxuZXhwb3J0IGNsYXNzIFR1dG9yUGFydGljaXBhdGlvbiBpbXBsZW1lbnRzIEJhc2VFbnRpdHkge1xuICAgIHB1YmxpYyBpZD86IG51bWJlcjtcblxuICAgIHB1YmxpYyBzdGF0dXM/OiBUdXRvclBhcnRpY2lwYXRpb25TdGF0dXM7XG4gICAgcHVibGljIGFzc2Vzc2VkRXhlcmNpc2U/OiBFeGVyY2lzZTtcbiAgICBwdWJsaWMgdHV0b3I/OiBVc2VyO1xuICAgIHB1YmxpYyB0cmFpbmVkRXhhbXBsZVN1Ym1pc3Npb25zPzogRXhhbXBsZVN1Ym1pc3Npb25bXTtcblxuICAgIGNvbnN0cnVjdG9yKCkge31cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uQ2hhbmdlcywgT25Jbml0LCBTaW1wbGVDaGFuZ2VzLCBWaWV3RW5jYXBzdWxhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IGdldCB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBFeGVyY2lzZSwgRXhlcmNpc2VUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IFR1dG9yUGFydGljaXBhdGlvbiwgVHV0b3JQYXJ0aWNpcGF0aW9uU3RhdHVzIH0gZnJvbSAnYXBwL2VudGl0aWVzL3BhcnRpY2lwYXRpb24vdHV0b3ItcGFydGljaXBhdGlvbi5tb2RlbCc7XG5pbXBvcnQgeyBEdWVEYXRlU3RhdCB9IGZyb20gJ2FwcC9jb3Vyc2UvZGFzaGJvYXJkcy9kdWUtZGF0ZS1zdGF0Lm1vZGVsJztcbmltcG9ydCB7IFByb2dyYW1taW5nRXhlcmNpc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvcHJvZ3JhbW1pbmctZXhlcmNpc2UubW9kZWwnO1xuaW1wb3J0IHsgZmFCb29rLCBmYUNoYWxrYm9hcmRUZWFjaGVyIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdqaGktdHV0b3ItcGFydGljaXBhdGlvbi1ncmFwaCcsXG4gICAgdGVtcGxhdGVVcmw6ICcuL3R1dG9yLXBhcnRpY2lwYXRpb24tZ3JhcGguY29tcG9uZW50Lmh0bWwnLFxuICAgIHN0eWxlVXJsczogWycuL3R1dG9yLXBhcnRpY2lwYXRpb24tZ3JhcGguY29tcG9uZW50LnNjc3MnXSxcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxufSlcbmV4cG9ydCBjbGFzcyBUdXRvclBhcnRpY2lwYXRpb25HcmFwaENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcbiAgICBASW5wdXQoKSBwdWJsaWMgdHV0b3JQYXJ0aWNpcGF0aW9uOiBUdXRvclBhcnRpY2lwYXRpb247XG4gICAgQElucHV0KCkgcHVibGljIG51bWJlck9mU3VibWlzc2lvbnM/OiBEdWVEYXRlU3RhdDtcbiAgICBASW5wdXQoKSBwdWJsaWMgdG90YWxOdW1iZXJPZkFzc2Vzc21lbnRzPzogRHVlRGF0ZVN0YXQ7XG4gICAgQElucHV0KCkgcHVibGljIG51bWJlck9mQ29tcGxhaW50czogbnVtYmVyO1xuICAgIEBJbnB1dCgpIHB1YmxpYyBudW1iZXJPZk9wZW5Db21wbGFpbnRzOiBudW1iZXI7XG4gICAgQElucHV0KCkgcHVibGljIG51bWJlck9mTW9yZUZlZWRiYWNrUmVxdWVzdHM6IG51bWJlcjtcbiAgICBASW5wdXQoKSBwdWJsaWMgbnVtYmVyT2ZPcGVuTW9yZUZlZWRiYWNrUmVxdWVzdHM6IG51bWJlcjtcbiAgICBASW5wdXQoKSBleGVyY2lzZTogRXhlcmNpc2U7XG4gICAgQElucHV0KCkgcHVibGljIG51bWJlck9mQXNzZXNzbWVudHNPZkNvcnJlY3Rpb25Sb3VuZHM6IER1ZURhdGVTdGF0W107XG5cbiAgICB0dXRvclBhcnRpY2lwYXRpb25TdGF0dXM6IFR1dG9yUGFydGljaXBhdGlvblN0YXR1cyA9IFR1dG9yUGFydGljaXBhdGlvblN0YXR1cy5OT1RfUEFSVElDSVBBVEVEO1xuXG4gICAgRXhlcmNpc2VUeXBlID0gRXhlcmNpc2VUeXBlO1xuICAgIE5PVF9QQVJUSUNJUEFURUQgPSBUdXRvclBhcnRpY2lwYXRpb25TdGF0dXMuTk9UX1BBUlRJQ0lQQVRFRDtcbiAgICBSRVZJRVdFRF9JTlNUUlVDVElPTlMgPSBUdXRvclBhcnRpY2lwYXRpb25TdGF0dXMuUkVWSUVXRURfSU5TVFJVQ1RJT05TO1xuICAgIFRSQUlORUQgPSBUdXRvclBhcnRpY2lwYXRpb25TdGF0dXMuVFJBSU5FRDtcbiAgICBDT01QTEVURUQgPSBUdXRvclBhcnRpY2lwYXRpb25TdGF0dXMuQ09NUExFVEVEO1xuXG4gICAgcGVyY2VudGFnZUNvbXBsYWludHNQcm9ncmVzcyA9IDA7XG5cbiAgICBwZXJjZW50YWdlSW5UaW1lQXNzZXNzbWVudFByb2dyZXNzT2ZDb3JyZWN0aW9uUm91bmQ6IG51bWJlcltdID0gW107XG4gICAgcGVyY2VudGFnZUxhdGVBc3Nlc3NtZW50UHJvZ3Jlc3NPZkNvcnJlY3Rpb25Sb3VuZDogbnVtYmVyW10gPSBbXTtcblxuICAgIHJvdXRlckxpbms6IHN0cmluZztcblxuICAgIHNob3VsZFNob3dNYW51YWxBc3Nlc3NtZW50cyA9IHRydWU7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhQm9vayA9IGZhQm9vaztcbiAgICBmYUNoYWxrYm9hcmRUZWFjaGVyID0gZmFDaGFsa2JvYXJkVGVhY2hlcjtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgcm91dGVyOiBSb3V0ZXIpIHt9XG5cbiAgICAvKipcbiAgICAgKiBMaWZlIGN5Y2xlIGhvb2sgY2FsbGVkIGJ5IEFuZ3VsYXIgdG8gaW5kaWNhdGUgdGhhdCBBbmd1bGFyIGlzIGRvbmUgY3JlYXRpbmcgdGhlIGNvbXBvbmVudFxuICAgICAqL1xuICAgIG5nT25Jbml0KCkge1xuICAgICAgICB0aGlzLnR1dG9yUGFydGljaXBhdGlvblN0YXR1cyA9IHRoaXMudHV0b3JQYXJ0aWNpcGF0aW9uLnN0YXR1cyE7XG4gICAgICAgIGNvbnN0IGV4ZXJjaXNlSWQgPSBnZXQodGhpcy50dXRvclBhcnRpY2lwYXRpb24sICd0cmFpbmVkRXhhbXBsZVN1Ym1pc3Npb25zWzBdLmV4ZXJjaXNlLmlkJyk7XG4gICAgICAgIGNvbnN0IGNvdXJzZUlkID0gZ2V0KHRoaXMudHV0b3JQYXJ0aWNpcGF0aW9uLCAndHJhaW5lZEV4YW1wbGVTdWJtaXNzaW9uc1swXS5leGVyY2lzZS5jb3Vyc2UuaWQnKTtcblxuICAgICAgICBpZiAoY291cnNlSWQgJiYgZXhlcmNpc2VJZCkge1xuICAgICAgICAgICAgdGhpcy5yb3V0ZXJMaW5rID0gYC9jb3Vyc2UtbWFuYWdlbWVudC8ke2NvdXJzZUlkfS9hc3Nlc3NtZW50LWRhc2hib2FyZC8ke2V4ZXJjaXNlSWR9YDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNhbGN1bGF0ZVBlcmNlbnRhZ2VBc3Nlc3NtZW50UHJvZ3Jlc3MoKTtcbiAgICAgICAgdGhpcy5jYWxjdWxhdGVQZXJjZW50YWdlQ29tcGxhaW50c1Byb2dyZXNzKCk7XG5cbiAgICAgICAgaWYgKHRoaXMuZXhlcmNpc2UgJiYgdGhpcy5leGVyY2lzZS50eXBlID09PSBFeGVyY2lzZVR5cGUuUFJPR1JBTU1JTkcpIHtcbiAgICAgICAgICAgIHRoaXMuc2hvdWxkU2hvd01hbnVhbEFzc2Vzc21lbnRzID0gISh0aGlzLmV4ZXJjaXNlIGFzIFByb2dyYW1taW5nRXhlcmNpc2UpLmFsbG93Q29tcGxhaW50c0ZvckF1dG9tYXRpY0Fzc2Vzc21lbnRzO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRnVuY3Rpb24gd3JhcHBpbmcgcm91dGVyLm5hdmlnYXRlIHNhZmVseSBieSBjaGVja2luZyBmb3IgbnVsbCBhbmQgZW1wdHkgc3RyaW5nXG4gICAgICovXG4gICAgbmF2aWdhdGUoKSB7XG4gICAgICAgIGlmICh0aGlzLnJvdXRlckxpbmsgJiYgdGhpcy5yb3V0ZXJMaW5rLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFt0aGlzLnJvdXRlckxpbmtdKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEEgbGlmZWN5Y2xlIGhvb2sgY2FsbGVkIGJ5IEFuZ3VsYXIgd2hlbiBhbnkgZGF0YS1ib3VuZCBwcm9wZXJ0eSBvZiBhIGNvbXBvbmVudCBjaGFuZ2VzXG4gICAgICpcbiAgICAgKiBAcGFyYW0gY2hhbmdlcyBDaGFuZ2VzIG1hZGVcbiAgICAgKi9cbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XG4gICAgICAgIGlmIChjaGFuZ2VzLnR1dG9yUGFydGljaXBhdGlvbikge1xuICAgICAgICAgICAgdGhpcy50dXRvclBhcnRpY2lwYXRpb24gPSBjaGFuZ2VzLnR1dG9yUGFydGljaXBhdGlvbi5jdXJyZW50VmFsdWU7XG4gICAgICAgICAgICB0aGlzLnR1dG9yUGFydGljaXBhdGlvblN0YXR1cyA9IHRoaXMudHV0b3JQYXJ0aWNpcGF0aW9uLnN0YXR1cyE7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jYWxjdWxhdGVQZXJjZW50YWdlQXNzZXNzbWVudFByb2dyZXNzKCk7XG4gICAgICAgIHRoaXMuY2FsY3VsYXRlUGVyY2VudGFnZUNvbXBsYWludHNQcm9ncmVzcygpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEZ1bmN0aW9uIHRvIGNhbGN1bGF0ZSB0aGUgcGVyY2VudGFnZSBvZiB0aGUgbnVtYmVyIG9mIGFzc2Vzc21lbnRzIGRpdmlkZWQgYnkgdGhlIG51bWJlciBvZiBwYXJ0aWNpcGF0aW9uc1xuICAgICAqL1xuICAgIGNhbGN1bGF0ZVBlcmNlbnRhZ2VBc3Nlc3NtZW50UHJvZ3Jlc3MoKSB7XG4gICAgICAgIGZvciAoY29uc3QgW2luZGV4LCBudW1iZXJPZkFzc2Vzc21lbnRzXSBvZiB0aGlzLm51bWJlck9mQXNzZXNzbWVudHNPZkNvcnJlY3Rpb25Sb3VuZHMuZW50cmllcygpKSB7XG4gICAgICAgICAgICB0aGlzLnBlcmNlbnRhZ2VJblRpbWVBc3Nlc3NtZW50UHJvZ3Jlc3NPZkNvcnJlY3Rpb25Sb3VuZFtpbmRleF0gPSAwO1xuICAgICAgICAgICAgdGhpcy5wZXJjZW50YWdlTGF0ZUFzc2Vzc21lbnRQcm9ncmVzc09mQ29ycmVjdGlvblJvdW5kW2luZGV4XSA9IDA7XG4gICAgICAgICAgICBpZiAodGhpcy5udW1iZXJPZlN1Ym1pc3Npb25zICYmIHRoaXMubnVtYmVyT2ZTdWJtaXNzaW9ucy5pblRpbWUgIT09IDApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnBlcmNlbnRhZ2VJblRpbWVBc3Nlc3NtZW50UHJvZ3Jlc3NPZkNvcnJlY3Rpb25Sb3VuZFtpbmRleF0gPSBNYXRoLmZsb29yKChudW1iZXJPZkFzc2Vzc21lbnRzLmluVGltZSAvIHRoaXMubnVtYmVyT2ZTdWJtaXNzaW9ucy5pblRpbWUpICogMTAwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0aGlzLm51bWJlck9mU3VibWlzc2lvbnMgJiYgdGhpcy5udW1iZXJPZlN1Ym1pc3Npb25zPy5sYXRlICE9PSAwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wZXJjZW50YWdlTGF0ZUFzc2Vzc21lbnRQcm9ncmVzc09mQ29ycmVjdGlvblJvdW5kW2luZGV4XSA9IE1hdGguZmxvb3IoKG51bWJlck9mQXNzZXNzbWVudHMubGF0ZSAvIHRoaXMubnVtYmVyT2ZTdWJtaXNzaW9ucy5sYXRlKSAqIDEwMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBGdW5jdGlvbiB0byBjYWxjdWxhdGUgdGhlIHBlcmNlbnRhZ2Ugb2YgcmVzcG9uZGVkIGNvbXBsYWludHNcbiAgICAgKiBUaGlzIGlzIGNhbGN1bGF0ZWQgYWRkaW5nIHRoZSBudW1iZXIgb2Ygbm90IGV2YWx1YXRlZCBjb21wbGFpbnRzIGFuZCBmZWVkYmFjayByZXF1ZXN0cyBhbmQgZGl2aWRpbmdcbiAgICAgKiBieSB0aGUgdG90YWwgbnVtYmVyIG9mIGNvbXBsYWludHMgYW5kIGZlZWRiYWNrcyBhbmQgcm91bmRpbmcgaXQgdHB3YXJkcyB6ZXJvLlxuICAgICAqL1xuICAgIGNhbGN1bGF0ZVBlcmNlbnRhZ2VDb21wbGFpbnRzUHJvZ3Jlc3MoKSB7XG4gICAgICAgIGlmICh0aGlzLm51bWJlck9mQ29tcGxhaW50cyArIHRoaXMubnVtYmVyT2ZNb3JlRmVlZGJhY2tSZXF1ZXN0cyAhPT0gMCkge1xuICAgICAgICAgICAgdGhpcy5wZXJjZW50YWdlQ29tcGxhaW50c1Byb2dyZXNzID0gTWF0aC5mbG9vcihcbiAgICAgICAgICAgICAgICAoKHRoaXMubnVtYmVyT2ZDb21wbGFpbnRzIC1cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5udW1iZXJPZk9wZW5Db21wbGFpbnRzICsgLy8gbnIgb2YgZXZhbHVhdGVkIGNvbXBsYWludHNcbiAgICAgICAgICAgICAgICAgICAgKHRoaXMubnVtYmVyT2ZNb3JlRmVlZGJhY2tSZXF1ZXN0cyAtIHRoaXMubnVtYmVyT2ZPcGVuTW9yZUZlZWRiYWNrUmVxdWVzdHMpKSAvIC8vIG5yIG9mIGV2YWx1YXRlZCBtb3JlIGZlZWRiYWNrIHJlcXVlc3RzXG4gICAgICAgICAgICAgICAgICAgICh0aGlzLm51bWJlck9mQ29tcGxhaW50cyArIHRoaXMubnVtYmVyT2ZNb3JlRmVlZGJhY2tSZXF1ZXN0cykpICogLy8gdG90YWwgbnIgb2YgY29tcGxhaW50cyBhbmQgZmVlZGJhY2sgcmVxdWVzdHNcbiAgICAgICAgICAgICAgICAgICAgMTAwLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENhbGN1bGF0ZXMgdGhlIGNsYXNzZXMgZm9yIHRoZSBzdGVwcyAoY2lyY2xlcykgaW4gdGhlIHR1dG9yIHBhcnRpY2lwYXRpb24gZ3JhcGhcbiAgICAgKiBAcGFyYW0gc3RlcCBmb3Igd2hpY2ggdGhlIGNsYXNzIHNob3VsZCBiZSBjYWxjdWxhdGVkIGZvciAoTk9UX1BBUlRJQ0lQQVRFRCwgUkVWSUVXRURfSU5TVFJVQ1RJT05TLCBUUkFJTkVEKVxuICAgICAqL1xuICAgIGNhbGN1bGF0ZUNsYXNzZXMoc3RlcDogVHV0b3JQYXJ0aWNpcGF0aW9uU3RhdHVzKTogc3RyaW5nIHtcbiAgICAgICAgLy8gUmV0dXJucyAnYWN0aXZlJyBpZiB0aGUgY3VycmVudCBwYXJ0aWNpcGF0aW9uIHN0YXR1cyBpcyBub3QgdHJhaW5lZFxuICAgICAgICBpZiAoc3RlcCA9PT0gdGhpcy50dXRvclBhcnRpY2lwYXRpb25TdGF0dXMgJiYgc3RlcCAhPT0gdGhpcy5UUkFJTkVEKSB7XG4gICAgICAgICAgICByZXR1cm4gJ2FjdGl2ZSc7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBSZXR1cm5zICdvcGFxdWUnIGlmIHRoZSB0dXRvciBoYXMgbm90IHBhcnRpY2lwYXRlZCB5ZXRcbiAgICAgICAgaWYgKHN0ZXAgPT09IHRoaXMuVFJBSU5FRCAmJiB0aGlzLnR1dG9yUGFydGljaXBhdGlvblN0YXR1cyA9PT0gdGhpcy5OT1RfUEFSVElDSVBBVEVEKSB7XG4gICAgICAgICAgICByZXR1cm4gJ29wYXF1ZSc7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoc3RlcCA9PT0gdGhpcy5UUkFJTkVEICYmIHRoaXMuZXhlcmNpc2UuZXhhbXBsZVN1Ym1pc3Npb25zICYmIHRoaXMudHV0b3JQYXJ0aWNpcGF0aW9uLnRyYWluZWRFeGFtcGxlU3VibWlzc2lvbnMpIHtcbiAgICAgICAgICAgIGNvbnN0IHJldmlld2VkQnlUdXRvciA9IHRoaXMudHV0b3JQYXJ0aWNpcGF0aW9uLnRyYWluZWRFeGFtcGxlU3VibWlzc2lvbnMuZmlsdGVyKChleGFtcGxlU3VibWlzc2lvbikgPT4gIWV4YW1wbGVTdWJtaXNzaW9uLnVzZWRGb3JUdXRvcmlhbCk7XG4gICAgICAgICAgICBjb25zdCBleGVyY2lzZXNUb1JldmlldyA9IHRoaXMuZXhlcmNpc2UuZXhhbXBsZVN1Ym1pc3Npb25zLmZpbHRlcigoZXhhbXBsZVN1Ym1pc3Npb24pID0+ICFleGFtcGxlU3VibWlzc2lvbi51c2VkRm9yVHV0b3JpYWwpO1xuICAgICAgICAgICAgY29uc3QgYXNzZXNzZWRCeVR1dG9yID0gdGhpcy50dXRvclBhcnRpY2lwYXRpb24udHJhaW5lZEV4YW1wbGVTdWJtaXNzaW9ucy5maWx0ZXIoKGV4YW1wbGVTdWJtaXNzaW9uKSA9PiBleGFtcGxlU3VibWlzc2lvbi51c2VkRm9yVHV0b3JpYWwpO1xuICAgICAgICAgICAgY29uc3QgZXhlcmNpc2VzVG9Bc3Nlc3MgPSB0aGlzLmV4ZXJjaXNlLmV4YW1wbGVTdWJtaXNzaW9ucy5maWx0ZXIoKGV4YW1wbGVTdWJtaXNzaW9uKSA9PiBleGFtcGxlU3VibWlzc2lvbi51c2VkRm9yVHV0b3JpYWwpO1xuXG4gICAgICAgICAgICAvLyBSZXR1cm5zICdvcmFuZ2UnIGlmIHRoZXJlIGFyZSBzdGlsbCBvcGVuIGV4YW1wbGUgcmV2aWV3cyBvciBhc3Nlc3NtZW50c1xuICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgIChleGVyY2lzZXNUb1Jldmlldy5sZW5ndGggPiAwICYmIGV4ZXJjaXNlc1RvUmV2aWV3Lmxlbmd0aCAhPT0gcmV2aWV3ZWRCeVR1dG9yLmxlbmd0aCkgfHxcbiAgICAgICAgICAgICAgICAoZXhlcmNpc2VzVG9Bc3Nlc3MubGVuZ3RoID4gMCAmJiBleGVyY2lzZXNUb0Fzc2Vzcy5sZW5ndGggIT09IGFzc2Vzc2VkQnlUdXRvci5sZW5ndGgpXG4gICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJ29yYW5nZSc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gJyc7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiB0aGUgcHJvZ3Jlc3MgYmFyIGNsYXNzIGJhc2VkIG9uIHRoZSBjdXJyZW50IHN0YXR1c1xuICAgICAqL1xuICAgIGNhbGN1bGF0ZUNsYXNzUHJvZ3Jlc3NCYXIoKSB7XG4gICAgICAgIGlmICh0aGlzLnR1dG9yUGFydGljaXBhdGlvblN0YXR1cyAhPT0gdGhpcy5UUkFJTkVEICYmIHRoaXMudHV0b3JQYXJ0aWNpcGF0aW9uU3RhdHVzICE9PSB0aGlzLkNPTVBMRVRFRCkge1xuICAgICAgICAgICAgcmV0dXJuICdvcGFxdWUnO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKFxuICAgICAgICAgICAgdGhpcy50dXRvclBhcnRpY2lwYXRpb25TdGF0dXMgPT09IHRoaXMuQ09NUExFVEVEIHx8XG4gICAgICAgICAgICAodGhpcy5udW1iZXJPZlN1Ym1pc3Npb25zICYmIHRoaXMudG90YWxOdW1iZXJPZkFzc2Vzc21lbnRzICYmIHRoaXMubnVtYmVyT2ZTdWJtaXNzaW9ucy5pblRpbWUgPT09IHRoaXMudG90YWxOdW1iZXJPZkFzc2Vzc21lbnRzLmluVGltZSkgfHxcbiAgICAgICAgICAgIHRoaXMubnVtYmVyT2ZPcGVuQ29tcGxhaW50cyArIHRoaXMubnVtYmVyT2ZPcGVuTW9yZUZlZWRiYWNrUmVxdWVzdHMgPT09IDBcbiAgICAgICAgKSB7XG4gICAgICAgICAgICByZXR1cm4gJ2FjdGl2ZSc7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gJ29yYW5nZSc7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgdG90YWwgbnVtYmVyIG9mIGV2YWx1YXRlZCBjb21wbGFpbnRzIGFuZCBmZWVkYmFjayByZXF1ZXN0c1xuICAgICAqL1xuICAgIGNhbGN1bGF0ZUNvbXBsYWludHNOdW1lcmF0b3IoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLm51bWJlck9mQ29tcGxhaW50cyAtIHRoaXMubnVtYmVyT2ZPcGVuQ29tcGxhaW50cyArICh0aGlzLm51bWJlck9mTW9yZUZlZWRiYWNrUmVxdWVzdHMgLSB0aGlzLm51bWJlck9mT3Blbk1vcmVGZWVkYmFja1JlcXVlc3RzKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSB0b3RhbCBudW1iZXIgb2YgY29tcGxhaW50cyBhbmQgZmVlZGJhY2sgcmVxdWVzdHNcbiAgICAgKi9cbiAgICBjYWxjdWxhdGVDb21wbGFpbnRzRGVub21pbmF0b3IoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLm51bWJlck9mQ29tcGxhaW50cyArIHRoaXMubnVtYmVyT2ZNb3JlRmVlZGJhY2tSZXF1ZXN0cztcbiAgICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwicm93IGp1c3RpZnktY29udGVudC1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgPHVsPlxuICAgICAgICA8bGkgY2xhc3M9XCJub3RfcGFydGljaXBhdGVkXCIgW25nQ2xhc3NdPVwiY2FsY3VsYXRlQ2xhc3NlcyhOT1RfUEFSVElDSVBBVEVEKVwiPjA8L2xpPlxuICAgICAgICA8bGlcbiAgICAgICAgICAgIGNsYXNzPVwibXMtMFwiXG4gICAgICAgICAgICBbbmdDbGFzc109XCJjYWxjdWxhdGVDbGFzc2VzKFJFVklFV0VEX0lOU1RSVUNUSU9OUylcIlxuICAgICAgICAgICAgKGNsaWNrKT1cIm5hdmlnYXRlKClcIlxuICAgICAgICAgICAgW25nYlRvb2x0aXBdPVwiJ2FydGVtaXNBcHAuYXNzZXNzbWVudERhc2hib2FyZC5yZWFkR3JhZGluZ0luc3RydWN0aW9ucycgfCBhcnRlbWlzVHJhbnNsYXRlXCJcbiAgICAgICAgPlxuICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFCb29rXCI+PC9mYS1pY29uPlxuICAgICAgICA8L2xpPlxuICAgICAgICBAaWYgKGV4ZXJjaXNlLnR5cGUgIT09IEV4ZXJjaXNlVHlwZS5QUk9HUkFNTUlORykge1xuICAgICAgICAgICAgPGxpIFtuZ0NsYXNzXT1cImNhbGN1bGF0ZUNsYXNzZXMoVFJBSU5FRClcIiAoY2xpY2spPVwibmF2aWdhdGUoKVwiIFtuZ2JUb29sdGlwXT1cIidhcnRlbWlzQXBwLmFzc2Vzc21lbnREYXNoYm9hcmQudHJhaW5PbkV4YW1wbGVTdWJtaXNzaW9ucycgfCBhcnRlbWlzVHJhbnNsYXRlXCI+XG4gICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFDaGFsa2JvYXJkVGVhY2hlclwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgIH1cbiAgICAgICAgQGlmIChzaG91bGRTaG93TWFudWFsQXNzZXNzbWVudHMpIHtcbiAgICAgICAgICAgIEBmb3IgKG51bWJlck9mQXNzZXNzZWRTdWJtaXNzaW9ucyBvZiBudW1iZXJPZkFzc2Vzc21lbnRzT2ZDb3JyZWN0aW9uUm91bmRzOyB0cmFjayBudW1iZXJPZkFzc2Vzc2VkU3VibWlzc2lvbnM7IGxldCBpID0gJGluZGV4KSB7XG4gICAgICAgICAgICAgICAgPGxpIGNsYXNzPVwicHJvZ3Jlc3MtYmFyLWxpIHN0YWNrZWQtbGlcIiBbbmdDbGFzc109XCJjYWxjdWxhdGVDbGFzc1Byb2dyZXNzQmFyKClcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInN0YWNrZWQtaXRlbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGpoaS1wcm9ncmVzcy1iYXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdG9vbHRpcF09XCInYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50RGFzaGJvYXJkLmFzc2Vzc1N0dWRlbnRzU3VibWlzc2lvbnMnIHwgYXJ0ZW1pc1RyYW5zbGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW3BlcmNlbnRhZ2VdPVwicGVyY2VudGFnZUluVGltZUFzc2Vzc21lbnRQcm9ncmVzc09mQ29ycmVjdGlvblJvdW5kW2ldXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbnVtZXJhdG9yXT1cIm51bWJlck9mQXNzZXNzZWRTdWJtaXNzaW9ucy5pblRpbWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtkZW5vbWluYXRvcl09XCJudW1iZXJPZlN1Ym1pc3Npb25zPy5pblRpbWUgfHwgMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2poaS1wcm9ncmVzcy1iYXI+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICBAaWYgKG51bWJlck9mU3VibWlzc2lvbnMgJiYgbnVtYmVyT2ZTdWJtaXNzaW9ucyEubGF0ZSA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGFja2VkLWl0ZW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8amhpLXByb2dyZXNzLWJhclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbdG9vbHRpcF09XCInYXJ0ZW1pc0FwcC5hc3Nlc3NtZW50RGFzaGJvYXJkLmFzc2Vzc1N0dWRlbnRzTGF0ZVN1Ym1pc3Npb25zJyB8IGFydGVtaXNUcmFuc2xhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbcGVyY2VudGFnZV09XCJwZXJjZW50YWdlTGF0ZUFzc2Vzc21lbnRQcm9ncmVzc09mQ29ycmVjdGlvblJvdW5kW2ldXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW251bWVyYXRvcl09XCJudW1iZXJPZkFzc2Vzc2VkU3VibWlzc2lvbnMubGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtkZW5vbWluYXRvcl09XCJudW1iZXJPZlN1Ym1pc3Npb25zPy5sYXRlIHx8IDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2poaS1wcm9ncmVzcy1iYXI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgPGxpIGNsYXNzPVwicHJvZ3Jlc3MtYmFyLWxpIG1lLTBcIiBbbmdDbGFzc109XCJjYWxjdWxhdGVDbGFzc1Byb2dyZXNzQmFyKClcIj5cbiAgICAgICAgICAgIDxqaGktcHJvZ3Jlc3MtYmFyXG4gICAgICAgICAgICAgICAgW3Rvb2x0aXBdPVwiJ2FydGVtaXNBcHAuYXNzZXNzbWVudERhc2hib2FyZC5ldmFsdWF0ZVN0dWRlbnRzQ29tcGxhaW50cycgfCBhcnRlbWlzVHJhbnNsYXRlXCJcbiAgICAgICAgICAgICAgICBbcGVyY2VudGFnZV09XCJwZXJjZW50YWdlQ29tcGxhaW50c1Byb2dyZXNzXCJcbiAgICAgICAgICAgICAgICBbbnVtZXJhdG9yXT1cImNhbGN1bGF0ZUNvbXBsYWludHNOdW1lcmF0b3IoKVwiXG4gICAgICAgICAgICAgICAgW2Rlbm9taW5hdG9yXT1cImNhbGN1bGF0ZUNvbXBsYWludHNEZW5vbWluYXRvcigpXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgIDwvamhpLXByb2dyZXNzLWJhcj5cbiAgICAgICAgPC9saT5cbiAgICA8L3VsPlxuPC9kaXY+XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUHJvZ3Jlc3NCYXJDb21wb25lbnQgfSBmcm9tICdhcHAvc2hhcmVkL2Rhc2hib2FyZHMvdHV0b3ItcGFydGljaXBhdGlvbi1ncmFwaC9wcm9ncmVzcy1iYXIvcHJvZ3Jlc3MtYmFyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBUdXRvclBhcnRpY2lwYXRpb25HcmFwaENvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvZGFzaGJvYXJkcy90dXRvci1wYXJ0aWNpcGF0aW9uLWdyYXBoL3R1dG9yLXBhcnRpY2lwYXRpb24tZ3JhcGguY29tcG9uZW50JztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtBcnRlbWlzU2hhcmVkTW9kdWxlXSxcbiAgICBkZWNsYXJhdGlvbnM6IFtQcm9ncmVzc0JhckNvbXBvbmVudCwgVHV0b3JQYXJ0aWNpcGF0aW9uR3JhcGhDb21wb25lbnRdLFxuICAgIGV4cG9ydHM6IFtUdXRvclBhcnRpY2lwYXRpb25HcmFwaENvbXBvbmVudCwgUHJvZ3Jlc3NCYXJDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBBcnRlbWlzVHV0b3JQYXJ0aWNpcGF0aW9uR3JhcGhNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsbUJBQW1CLFdBQVcsYUFBMEQ7Ozs7QUFBakcsSUFTYTtBQVRiOztBQUNBO0FBQ0E7O0FBT00sSUFBTyx1QkFBUCxNQUFPLHNCQUFvQjtNQVdqQjtNQUNBO01BWEk7TUFDQTtNQUNBO01BQ0E7TUFFaEI7TUFDQTtNQUNBO01BRUEsWUFDWSxjQUNBLEtBQXNCO0FBRHRCLGFBQUEsZUFBQTtBQUNBLGFBQUEsTUFBQTtNQUNUO01BRUgsV0FBUTtBQUNKLGFBQUssb0JBQW9CLEtBQUssYUFBYSwwQkFBeUIsRUFBRyxVQUFVLE1BQUs7QUFDbEYsZUFBSywyQkFBMEI7QUFHL0IsZUFBSyxJQUFJLGNBQWE7UUFDMUIsQ0FBQztNQUNMO01BRUEsWUFBWSxTQUFzQjtBQUM5QixZQUFJLFFBQVEsWUFBWTtBQUNwQixlQUFLLGFBQWEsTUFBTSxLQUFLLFVBQVU7QUFDdkMsZUFBSywyQkFBMEI7QUFDL0IsZUFBSywwQkFBeUI7O01BRXRDO01BRUEsY0FBVztBQUNQLGFBQUssa0JBQWtCLFlBQVc7TUFDdEM7TUFLQSw0QkFBeUI7QUFDckIsWUFBSSxLQUFLLGFBQWEsSUFBSTtBQUN0QixlQUFLLHVCQUF1QjttQkFDckIsS0FBSyxhQUFhLEtBQUs7QUFDOUIsZUFBSyx1QkFBdUI7ZUFDekI7QUFDSCxlQUFLLHVCQUF1Qjs7TUFFcEM7TUFLQSw2QkFBMEI7QUFDdEIsZ0JBQVEsS0FBSyxhQUFhLGdCQUFlLEdBQUk7VUFDekMsS0FBSyxNQUFNO0FBQ1AsaUJBQUssdUJBQXVCO0FBQzVCO1VBQ0osS0FBSyxNQUFNO1VBQ1g7QUFDSSxnQkFBSSxLQUFLLGFBQWEsS0FBSztBQUN2QixtQkFBSyx1QkFBdUI7bUJBQ3pCO0FBQ0gsbUJBQUssdUJBQXVCOzs7TUFHNUM7O3lCQWpFUyx1QkFBb0IsK0JBQUEsWUFBQSxHQUFBLCtCQUFBLG9CQUFBLENBQUE7TUFBQTtnRUFBcEIsdUJBQW9CLFdBQUEsQ0FBQSxDQUFBLGtCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsU0FBQSxXQUFBLFlBQUEsY0FBQSxXQUFBLGFBQUEsYUFBQSxjQUFBLEdBQUEsVUFBQSxDQUFBLGlDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFlBQUEscUJBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxRQUFBLGVBQUEsaUJBQUEsS0FBQSxpQkFBQSxPQUFBLEdBQUEsZ0JBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLDBCQUFBLFVBQUEscUJBQUEsU0FBQSxHQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSw4QkFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ1RqQyxVQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBU0ksVUFBQSxvQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDRCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQXNHLFVBQUEsb0JBQUEsQ0FBQTtBQUE2RCxVQUFBLDBCQUFBO0FBQ3ZLLFVBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSwwQkFBQTtBQUNKLFVBQUEsb0JBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsR0FBQSxJQUFBOzs7QUFid0MsVUFBQSx3QkFBQSxjQUFBLElBQUEsT0FBQTtBQUtoQyxVQUFBLHVCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFNBQUEsSUFBQSxhQUFBLEdBQUE7QUFEQSxVQUFBLHdCQUFBLFdBQUEsSUFBQSxvQkFBQTtBQUVBLFVBQUEseUJBQUEsaUJBQUEsSUFBQSxVQUFBO0FBSW9FLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsd0JBQUEsV0FBQSxJQUFBLG9CQUFBO0FBQWtDLFVBQUEsdUJBQUEsQ0FBQTtBQUFBLFVBQUEsZ0NBQUEsS0FBQSxJQUFBLFdBQUEsT0FBQSxJQUFBLGFBQUEsTUFBQSxJQUFBLGFBQUEsS0FBQSxJQUFBOzs7OztvRkREakcsc0JBQW9CLEVBQUEsV0FBQSx1QkFBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVHakM7Ozs7OztBQ1pBLFNBQVMsYUFBQUEsWUFBVyxTQUFBQyxRQUF5Qyx5QkFBeUI7QUFDdEYsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsV0FBVztBQUtwQixTQUFTLFFBQVEsMkJBQTJCOzs7Ozs7Ozs7QUNLaEMsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUEwQyxJQUFBLHlCQUFBLFNBQUEsU0FBQSwrRUFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsT0FBQSxTQUFBLENBQVU7SUFBQSxDQUFBOztBQUN6RCxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxZQUFBOzs7O0FBSFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLE9BQUEsaUJBQUEsT0FBQSxPQUFBLENBQUEsRUFBcUMsY0FBQSwwQkFBQSxHQUFBLEdBQUEsMERBQUEsQ0FBQTtBQUM1QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxtQkFBQTs7Ozs7QUFnQkQsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxvQkFBQSxDQUFBOztBQU1BLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7Ozs7O0FBUFksSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLDBCQUFBLEdBQUEsR0FBQSw4REFBQSxDQUFBLEVBQTZGLGNBQUEsUUFBQSxrREFBQSxJQUFBLENBQUEsRUFBQSxhQUFBLCtCQUFBLElBQUEsRUFBQSxnQkFBQSxRQUFBLHVCQUFBLE9BQUEsT0FBQSxRQUFBLG9CQUFBLFNBQUEsQ0FBQTs7Ozs7QUFiN0csSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsb0JBQUEsQ0FBQTs7QUFNQSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSwrRUFBQSxHQUFBLENBQUE7QUFXSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBOzs7Ozs7QUF0QjJDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsV0FBQSxPQUFBLDBCQUFBLENBQUE7QUFHM0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLDBCQUFBLEdBQUEsR0FBQSwwREFBQSxDQUFBLEVBQXlGLGNBQUEsT0FBQSxvREFBQSxJQUFBLENBQUEsRUFBQSxhQUFBLCtCQUFBLE1BQUEsRUFBQSxnQkFBQSxPQUFBLHVCQUFBLE9BQUEsT0FBQSxPQUFBLG9CQUFBLFdBQUEsQ0FBQTtBQU9qRyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSx1QkFBQSxPQUFBLG9CQUFBLE9BQUEsSUFBQSxLQUFBLEVBQUE7Ozs7O0FBWFIsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSwrQkFBQSxHQUFBLGdFQUFBLElBQUEsR0FBQSxNQUFBLE1BQUEsdUNBQUE7Ozs7QUFBQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEscUNBQUE7OztBRGpCWixJQWVhO0FBZmI7O0FBR0E7QUFDQTtBQUNBOzs7QUFVTSxJQUFPLG1DQUFQLE1BQU8sa0NBQWdDO01BZ0NyQjtNQS9CSjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNQO01BQ087TUFFaEIsMkJBQXdCO01BRXhCLGVBQWU7TUFDZixtQkFBZ0I7TUFDaEIsd0JBQXFCO01BQ3JCLFVBQU87TUFDUCxZQUFTO01BRVQsK0JBQStCO01BRS9CLHNEQUFnRSxDQUFBO01BQ2hFLG9EQUE4RCxDQUFBO01BRTlEO01BRUEsOEJBQThCO01BRzlCLFNBQVM7TUFDVCxzQkFBc0I7TUFFdEIsWUFBb0IsUUFBYztBQUFkLGFBQUEsU0FBQTtNQUFpQjtNQUtyQyxXQUFRO0FBQ0osYUFBSywyQkFBMkIsS0FBSyxtQkFBbUI7QUFDeEQsY0FBTSxhQUFhLElBQUksS0FBSyxvQkFBb0IsMENBQTBDO0FBQzFGLGNBQU0sV0FBVyxJQUFJLEtBQUssb0JBQW9CLGlEQUFpRDtBQUUvRixZQUFJLFlBQVksWUFBWTtBQUN4QixlQUFLLGFBQWEsc0JBQXNCLFFBQVEseUJBQXlCLFVBQVU7O0FBRXZGLGFBQUssc0NBQXFDO0FBQzFDLGFBQUssc0NBQXFDO0FBRTFDLFlBQUksS0FBSyxZQUFZLEtBQUssU0FBUyxTQUFTLGFBQWEsYUFBYTtBQUNsRSxlQUFLLDhCQUE4QixDQUFFLEtBQUssU0FBaUM7O01BRW5GO01BS0EsV0FBUTtBQUNKLFlBQUksS0FBSyxjQUFjLEtBQUssV0FBVyxTQUFTLEdBQUc7QUFDL0MsZUFBSyxPQUFPLFNBQVMsQ0FBQyxLQUFLLFVBQVUsQ0FBQzs7TUFFOUM7TUFPQSxZQUFZLFNBQXNCO0FBQzlCLFlBQUksUUFBUSxvQkFBb0I7QUFDNUIsZUFBSyxxQkFBcUIsUUFBUSxtQkFBbUI7QUFDckQsZUFBSywyQkFBMkIsS0FBSyxtQkFBbUI7O0FBRTVELGFBQUssc0NBQXFDO0FBQzFDLGFBQUssc0NBQXFDO01BQzlDO01BS0Esd0NBQXFDO0FBQ2pDLG1CQUFXLENBQUMsT0FBTyxtQkFBbUIsS0FBSyxLQUFLLHNDQUFzQyxRQUFPLEdBQUk7QUFDN0YsZUFBSyxvREFBb0QsS0FBSyxJQUFJO0FBQ2xFLGVBQUssa0RBQWtELEtBQUssSUFBSTtBQUNoRSxjQUFJLEtBQUssdUJBQXVCLEtBQUssb0JBQW9CLFdBQVcsR0FBRztBQUNuRSxpQkFBSyxvREFBb0QsS0FBSyxJQUFJLEtBQUssTUFBTyxvQkFBb0IsU0FBUyxLQUFLLG9CQUFvQixTQUFVLEdBQUc7O0FBRXJKLGNBQUksS0FBSyx1QkFBdUIsS0FBSyxxQkFBcUIsU0FBUyxHQUFHO0FBQ2xFLGlCQUFLLGtEQUFrRCxLQUFLLElBQUksS0FBSyxNQUFPLG9CQUFvQixPQUFPLEtBQUssb0JBQW9CLE9BQVEsR0FBRzs7O01BR3ZKO01BT0Esd0NBQXFDO0FBQ2pDLFlBQUksS0FBSyxxQkFBcUIsS0FBSyxpQ0FBaUMsR0FBRztBQUNuRSxlQUFLLCtCQUErQixLQUFLLE9BQ25DLEtBQUsscUJBQ0gsS0FBSywwQkFDSixLQUFLLCtCQUErQixLQUFLLHNDQUN6QyxLQUFLLHFCQUFxQixLQUFLLGdDQUNoQyxHQUFHOztNQUduQjtNQU1BLGlCQUFpQixNQUE4QjtBQUUzQyxZQUFJLFNBQVMsS0FBSyw0QkFBNEIsU0FBUyxLQUFLLFNBQVM7QUFDakUsaUJBQU87O0FBSVgsWUFBSSxTQUFTLEtBQUssV0FBVyxLQUFLLDZCQUE2QixLQUFLLGtCQUFrQjtBQUNsRixpQkFBTzs7QUFHWCxZQUFJLFNBQVMsS0FBSyxXQUFXLEtBQUssU0FBUyxzQkFBc0IsS0FBSyxtQkFBbUIsMkJBQTJCO0FBQ2hILGdCQUFNLGtCQUFrQixLQUFLLG1CQUFtQiwwQkFBMEIsT0FBTyxDQUFDLHNCQUFzQixDQUFDLGtCQUFrQixlQUFlO0FBQzFJLGdCQUFNLG9CQUFvQixLQUFLLFNBQVMsbUJBQW1CLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxrQkFBa0IsZUFBZTtBQUMzSCxnQkFBTSxrQkFBa0IsS0FBSyxtQkFBbUIsMEJBQTBCLE9BQU8sQ0FBQyxzQkFBc0Isa0JBQWtCLGVBQWU7QUFDekksZ0JBQU0sb0JBQW9CLEtBQUssU0FBUyxtQkFBbUIsT0FBTyxDQUFDLHNCQUFzQixrQkFBa0IsZUFBZTtBQUcxSCxjQUNLLGtCQUFrQixTQUFTLEtBQUssa0JBQWtCLFdBQVcsZ0JBQWdCLFVBQzdFLGtCQUFrQixTQUFTLEtBQUssa0JBQWtCLFdBQVcsZ0JBQWdCLFFBQ2hGO0FBQ0UsbUJBQU87OztBQUlmLGVBQU87TUFDWDtNQUtBLDRCQUF5QjtBQUNyQixZQUFJLEtBQUssNkJBQTZCLEtBQUssV0FBVyxLQUFLLDZCQUE2QixLQUFLLFdBQVc7QUFDcEcsaUJBQU87O0FBR1gsWUFDSSxLQUFLLDZCQUE2QixLQUFLLGFBQ3RDLEtBQUssdUJBQXVCLEtBQUssNEJBQTRCLEtBQUssb0JBQW9CLFdBQVcsS0FBSyx5QkFBeUIsVUFDaEksS0FBSyx5QkFBeUIsS0FBSyxxQ0FBcUMsR0FDMUU7QUFDRSxpQkFBTzs7QUFHWCxlQUFPO01BQ1g7TUFLQSwrQkFBNEI7QUFDeEIsZUFBTyxLQUFLLHFCQUFxQixLQUFLLDBCQUEwQixLQUFLLCtCQUErQixLQUFLO01BQzdHO01BS0EsaUNBQThCO0FBQzFCLGVBQU8sS0FBSyxxQkFBcUIsS0FBSztNQUMxQzs7eUJBN0tTLG1DQUFnQyxnQ0FBQSxTQUFBLENBQUE7TUFBQTtpRUFBaEMsbUNBQWdDLFdBQUEsQ0FBQSxDQUFBLCtCQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsb0JBQUEsc0JBQUEscUJBQUEsdUJBQUEsMEJBQUEsNEJBQUEsb0JBQUEsc0JBQUEsd0JBQUEsMEJBQUEsOEJBQUEsZ0NBQUEsa0NBQUEsb0NBQUEsVUFBQSxZQUFBLHVDQUFBLHdDQUFBLEdBQUEsVUFBQSxDQUFBLGtDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLE9BQUEsMEJBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsb0JBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsR0FBQSxXQUFBLGNBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLG1CQUFBLFFBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsY0FBQSxhQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxjQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsY0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDBDQUFBLElBQUEsS0FBQTtBQUFBLFlBQUEsS0FBQSxHQUFBO0FDZjdDLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQTRFLFVBQUEscUJBQUEsR0FBQSxHQUFBO0FBQUMsVUFBQSwyQkFBQTtBQUM3RSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxNQUFBLENBQUE7QUFHSSxVQUFBLHlCQUFBLFNBQUEsU0FBQSxnRUFBQTtBQUFBLG1CQUFTLElBQUEsU0FBQTtVQUFVLENBQUE7O0FBR25CLFVBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFBLFVBQUEsd0JBQUEsSUFBQSxXQUFBLENBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsSUFBQSwwREFBQSxHQUFBLENBQUEsRUFJQyxJQUFBLDBEQUFBLEdBQUEsQ0FBQTtBQTJCRCxVQUFBLDZCQUFBLElBQUEsTUFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLG9CQUFBLENBQUE7O0FBTUEsVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxZQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxJQUFBOzs7QUFuRHFDLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsV0FBQSxJQUFBLGlCQUFBLElBQUEsZ0JBQUEsQ0FBQTtBQUd6QixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsSUFBQSxpQkFBQSxJQUFBLHFCQUFBLENBQUEsRUFBbUQsY0FBQSwwQkFBQSxHQUFBLElBQUEsd0RBQUEsQ0FBQTtBQUkxQyxVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFFBQUEsSUFBQSxNQUFBO0FBRWIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxJQUFBLElBQUEsU0FBQSxTQUFBLElBQUEsYUFBQSxjQUFBLEtBQUEsRUFBQTtBQUtBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsNEJBQUEsSUFBQSxJQUFBLDhCQUFBLEtBQUEsRUFBQTtBQTBCaUMsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxXQUFBLElBQUEsMEJBQUEsQ0FBQTtBQUV6QixVQUFBLHdCQUFBLENBQUE7QUFBQSxVQUFBLHlCQUFBLFdBQUEsMEJBQUEsSUFBQSxJQUFBLDJEQUFBLENBQUEsRUFBMEYsY0FBQSxJQUFBLDRCQUFBLEVBQUEsYUFBQSxJQUFBLDZCQUFBLENBQUEsRUFBQSxlQUFBLElBQUEsK0JBQUEsQ0FBQTs7Ozs7cUZEN0I3RixrQ0FBZ0MsRUFBQSxXQUFBLG1DQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRWY3QyxTQUFTLGdCQUFnQjs7QUFBekIsSUFVYTtBQVZiOztBQUNBO0FBQ0E7QUFDQTtBQU9NLElBQU8sdUNBQVAsTUFBTyxzQ0FBb0M7O3lCQUFwQyx1Q0FBb0M7TUFBQTtnRUFBcEMsc0NBQW9DLENBQUE7b0VBSm5DLG1CQUFtQixFQUFBLENBQUE7Ozs7IiwibmFtZXMiOlsiQ29tcG9uZW50IiwiSW5wdXQiXX0=