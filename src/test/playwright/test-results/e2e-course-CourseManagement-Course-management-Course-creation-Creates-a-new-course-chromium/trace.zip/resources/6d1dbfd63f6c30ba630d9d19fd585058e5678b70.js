import {
  init_crypto_utils,
  sha1Hex
} from "/chunk-SE7ZOI4O.js";
import {
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/entities/text-block.model.ts
var TextBlockType, TextBlock;
var init_text_block_model = __esm({
  "src/main/webapp/app/entities/text-block.model.ts"() {
    init_crypto_utils();
    (function(TextBlockType2) {
      TextBlockType2["AUTOMATIC"] = "AUTOMATIC";
      TextBlockType2["MANUAL"] = "MANUAL";
    })(TextBlockType || (TextBlockType = {}));
    TextBlock = class {
      id;
      type;
      _submissionId;
      _startIndex;
      _endIndex;
      _text;
      set submissionId(value) {
        this._submissionId = value;
        this.computeId();
      }
      get submissionId() {
        return this._submissionId;
      }
      set startIndex(value) {
        this._startIndex = value;
        this.computeId();
      }
      get startIndex() {
        return this._startIndex;
      }
      set endIndex(value) {
        this._endIndex = value;
        this.computeId();
      }
      get endIndex() {
        return this._endIndex;
      }
      set text(value) {
        this._text = value;
        this.computeId();
      }
      get text() {
        return this._text;
      }
      computeId() {
        const submissionId = this.submissionId ?? 0;
        const idString = `${submissionId};${this.startIndex}-${this.endIndex};${this.text}`;
        this.id = sha1Hex(idString);
      }
      setTextFromSubmission(submission) {
        this.submissionId ??= submission?.id;
        if (submission && this.startIndex != void 0) {
          this.text = submission.text?.substring(this.startIndex, this.endIndex) || "";
        }
      }
    };
  }
});

export {
  TextBlockType,
  TextBlock,
  init_text_block_model
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZW50aXRpZXMvdGV4dC1ibG9jay5tb2RlbC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzaGExSGV4IH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2NyeXB0by51dGlscyc7XG5pbXBvcnQgeyBUZXh0U3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy90ZXh0LXN1Ym1pc3Npb24ubW9kZWwnO1xuXG5leHBvcnQgZW51bSBUZXh0QmxvY2tUeXBlIHtcbiAgICBBVVRPTUFUSUMgPSAnQVVUT01BVElDJyxcbiAgICBNQU5VQUwgPSAnTUFOVUFMJyxcbn1cblxuZXhwb3J0IGNsYXNzIFRleHRCbG9jayB7XG4gICAgaWQ/OiBzdHJpbmc7XG4gICAgdHlwZT86IFRleHRCbG9ja1R5cGU7XG5cbiAgICAvLyBUaGUgSUQgb2YgdGhlIHRleHQgYmxvY2sgaXMgY29tcHV0ZWQgYXMgYSBoYXNoIG9mIHRoZSBzdWJtaXNzaW9uIElELCB0aGUgc3RhcnQgYW5kIGVuZCBpbmRleCBhbmQgdGhlIHRleHQuXG4gICAgLy8gV2UgbmVlZCB0byBrZWVwIGl0IHVwIHRvIGRhdGUgd2l0aCB0aGUgbGF0ZXN0IHZhbHVlcyBvZiB0aGVzZSBwcm9wZXJ0aWVzLiBUaGVyZWZvcmUsIHdlIHVzZSBzZXR0ZXIgcHJvcGVydGllcyB0byBuZXZlciBmb3JnZXQgdG8gdXBkYXRlIHRoZSBJRC5cbiAgICBwcml2YXRlIF9zdWJtaXNzaW9uSWQ/OiBudW1iZXI7XG4gICAgcHJpdmF0ZSBfc3RhcnRJbmRleD86IG51bWJlcjtcbiAgICBwcml2YXRlIF9lbmRJbmRleD86IG51bWJlcjtcbiAgICBwcml2YXRlIF90ZXh0Pzogc3RyaW5nO1xuXG4gICAgc2V0IHN1Ym1pc3Npb25JZCh2YWx1ZTogbnVtYmVyIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3N1Ym1pc3Npb25JZCA9IHZhbHVlO1xuICAgICAgICB0aGlzLmNvbXB1dGVJZCgpO1xuICAgIH1cblxuICAgIGdldCBzdWJtaXNzaW9uSWQoKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3N1Ym1pc3Npb25JZDtcbiAgICB9XG5cbiAgICBzZXQgc3RhcnRJbmRleCh2YWx1ZTogbnVtYmVyIHwgdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX3N0YXJ0SW5kZXggPSB2YWx1ZTtcbiAgICAgICAgdGhpcy5jb21wdXRlSWQoKTtcbiAgICB9XG5cbiAgICBnZXQgc3RhcnRJbmRleCgpOiBudW1iZXIgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fc3RhcnRJbmRleDtcbiAgICB9XG5cbiAgICBzZXQgZW5kSW5kZXgodmFsdWU6IG51bWJlciB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl9lbmRJbmRleCA9IHZhbHVlO1xuICAgICAgICB0aGlzLmNvbXB1dGVJZCgpO1xuICAgIH1cblxuICAgIGdldCBlbmRJbmRleCgpOiBudW1iZXIgfCB1bmRlZmluZWQge1xuICAgICAgICByZXR1cm4gdGhpcy5fZW5kSW5kZXg7XG4gICAgfVxuXG4gICAgc2V0IHRleHQodmFsdWU6IHN0cmluZyB8IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLl90ZXh0ID0gdmFsdWU7XG4gICAgICAgIHRoaXMuY29tcHV0ZUlkKCk7XG4gICAgfVxuXG4gICAgZ2V0IHRleHQoKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3RleHQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ29tcHV0ZXMgdGhlIElEIG9mIHRoZSB0ZXh0IGJsb2NrLiBUaGUgSUQgaXMgYSBoYXNoIG9mIHRoZSBzdWJtaXNzaW9uIElELCB0aGUgc3RhcnQgYW5kIGVuZCBpbmRleCBhbmQgdGhlIHRleHQuXG4gICAgICovXG4gICAgcHJpdmF0ZSBjb21wdXRlSWQoKTogdm9pZCB7XG4gICAgICAgIGNvbnN0IHN1Ym1pc3Npb25JZCA9IHRoaXMuc3VibWlzc2lvbklkID8/IDA7XG4gICAgICAgIGNvbnN0IGlkU3RyaW5nID0gYCR7c3VibWlzc2lvbklkfTske3RoaXMuc3RhcnRJbmRleH0tJHt0aGlzLmVuZEluZGV4fTske3RoaXMudGV4dH1gO1xuICAgICAgICB0aGlzLmlkID0gc2hhMUhleChpZFN0cmluZyk7XG4gICAgfVxuXG4gICAgc2V0VGV4dEZyb21TdWJtaXNzaW9uKHN1Ym1pc3Npb24/OiBUZXh0U3VibWlzc2lvbik6IHZvaWQge1xuICAgICAgICB0aGlzLnN1Ym1pc3Npb25JZCA/Pz0gc3VibWlzc2lvbj8uaWQ7XG4gICAgICAgIGlmIChzdWJtaXNzaW9uICYmIHRoaXMuc3RhcnRJbmRleCAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRoaXMudGV4dCA9IHN1Ym1pc3Npb24udGV4dD8uc3Vic3RyaW5nKHRoaXMuc3RhcnRJbmRleCwgdGhpcy5lbmRJbmRleCkgfHwgJyc7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLElBR1ksZUFLQztBQVJiOzs7QUFHQSxLQUFBLFNBQVlBLGdCQUFhO0FBQ3JCLE1BQUFBLGVBQUEsV0FBQSxJQUFBO0FBQ0EsTUFBQUEsZUFBQSxRQUFBLElBQUE7SUFDSixHQUhZLGtCQUFBLGdCQUFhLENBQUEsRUFBQTtBQUtuQixJQUFPLFlBQVAsTUFBZ0I7TUFDbEI7TUFDQTtNQUlRO01BQ0E7TUFDQTtNQUNBO01BRVIsSUFBSSxhQUFhLE9BQXlCO0FBQ3RDLGFBQUssZ0JBQWdCO0FBQ3JCLGFBQUssVUFBUztNQUNsQjtNQUVBLElBQUksZUFBWTtBQUNaLGVBQU8sS0FBSztNQUNoQjtNQUVBLElBQUksV0FBVyxPQUF5QjtBQUNwQyxhQUFLLGNBQWM7QUFDbkIsYUFBSyxVQUFTO01BQ2xCO01BRUEsSUFBSSxhQUFVO0FBQ1YsZUFBTyxLQUFLO01BQ2hCO01BRUEsSUFBSSxTQUFTLE9BQXlCO0FBQ2xDLGFBQUssWUFBWTtBQUNqQixhQUFLLFVBQVM7TUFDbEI7TUFFQSxJQUFJLFdBQVE7QUFDUixlQUFPLEtBQUs7TUFDaEI7TUFFQSxJQUFJLEtBQUssT0FBeUI7QUFDOUIsYUFBSyxRQUFRO0FBQ2IsYUFBSyxVQUFTO01BQ2xCO01BRUEsSUFBSSxPQUFJO0FBQ0osZUFBTyxLQUFLO01BQ2hCO01BS1EsWUFBUztBQUNiLGNBQU0sZUFBZSxLQUFLLGdCQUFnQjtBQUMxQyxjQUFNLFdBQVcsR0FBRyxZQUFZLElBQUksS0FBSyxVQUFVLElBQUksS0FBSyxRQUFRLElBQUksS0FBSyxJQUFJO0FBQ2pGLGFBQUssS0FBSyxRQUFRLFFBQVE7TUFDOUI7TUFFQSxzQkFBc0IsWUFBMkI7QUFDN0MsYUFBSyxpQkFBaUIsWUFBWTtBQUNsQyxZQUFJLGNBQWMsS0FBSyxjQUFjLFFBQVc7QUFDNUMsZUFBSyxPQUFPLFdBQVcsTUFBTSxVQUFVLEtBQUssWUFBWSxLQUFLLFFBQVEsS0FBSzs7TUFFbEY7Ozs7IiwibmFtZXMiOlsiVGV4dEJsb2NrVHlwZSJdfQ==