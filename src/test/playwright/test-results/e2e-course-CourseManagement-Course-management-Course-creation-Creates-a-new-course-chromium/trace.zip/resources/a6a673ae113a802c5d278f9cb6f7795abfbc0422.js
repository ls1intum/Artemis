import {
  MIN,
  MS
} from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NQN5E7X4.js?v=b97f8625";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NI5XS6XH.js?v=b97f8625";

// node_modules/dayjs/esm/plugin/timezone/index.js
var typeToPos = {
  year: 0,
  month: 1,
  day: 2,
  hour: 3,
  minute: 4,
  second: 5
};
var dtfCache = {};
var getDateTimeFormat = function getDateTimeFormat2(timezone, options) {
  if (options === void 0) {
    options = {};
  }
  var timeZoneName = options.timeZoneName || "short";
  var key = timezone + "|" + timeZoneName;
  var dtf = dtfCache[key];
  if (!dtf) {
    dtf = new Intl.DateTimeFormat("en-US", {
      hour12: false,
      timeZone: timezone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      timeZoneName
    });
    dtfCache[key] = dtf;
  }
  return dtf;
};
var timezone_default = function(o, c, d) {
  var defaultTimezone;
  var makeFormatParts = function makeFormatParts2(timestamp, timezone, options) {
    if (options === void 0) {
      options = {};
    }
    var date = new Date(timestamp);
    var dtf = getDateTimeFormat(timezone, options);
    return dtf.formatToParts(date);
  };
  var tzOffset = function tzOffset2(timestamp, timezone) {
    var formatResult = makeFormatParts(timestamp, timezone);
    var filled = [];
    for (var i = 0; i < formatResult.length; i += 1) {
      var _formatResult$i = formatResult[i], type = _formatResult$i.type, value = _formatResult$i.value;
      var pos = typeToPos[type];
      if (pos >= 0) {
        filled[pos] = parseInt(value, 10);
      }
    }
    var hour = filled[3];
    var fixedHour = hour === 24 ? 0 : hour;
    var utcString = filled[0] + "-" + filled[1] + "-" + filled[2] + " " + fixedHour + ":" + filled[4] + ":" + filled[5] + ":000";
    var utcTs = d.utc(utcString).valueOf();
    var asTS = +timestamp;
    var over = asTS % 1e3;
    asTS -= over;
    return (utcTs - asTS) / (60 * 1e3);
  };
  var fixOffset = function fixOffset2(localTS, o0, tz) {
    var utcGuess = localTS - o0 * 60 * 1e3;
    var o2 = tzOffset(utcGuess, tz);
    if (o0 === o2) {
      return [utcGuess, o0];
    }
    utcGuess -= (o2 - o0) * 60 * 1e3;
    var o3 = tzOffset(utcGuess, tz);
    if (o2 === o3) {
      return [utcGuess, o2];
    }
    return [localTS - Math.min(o2, o3) * 60 * 1e3, Math.max(o2, o3)];
  };
  var proto = c.prototype;
  proto.tz = function(timezone, keepLocalTime) {
    if (timezone === void 0) {
      timezone = defaultTimezone;
    }
    var oldOffset = this.utcOffset();
    var date = this.toDate();
    var target = date.toLocaleString("en-US", {
      timeZone: timezone
    });
    var diff = Math.round((date - new Date(target)) / 1e3 / 60);
    var ins = d(target, {
      locale: this.$L
    }).$set(MS, this.$ms).utcOffset(-Math.round(date.getTimezoneOffset() / 15) * 15 - diff, true);
    if (keepLocalTime) {
      var newOffset = ins.utcOffset();
      ins = ins.add(oldOffset - newOffset, MIN);
    }
    ins.$x.$timezone = timezone;
    return ins;
  };
  proto.offsetName = function(type) {
    var zone = this.$x.$timezone || d.tz.guess();
    var result = makeFormatParts(this.valueOf(), zone, {
      timeZoneName: type
    }).find(function(m) {
      return m.type.toLowerCase() === "timezonename";
    });
    return result && result.value;
  };
  var oldStartOf = proto.startOf;
  proto.startOf = function(units, startOf) {
    if (!this.$x || !this.$x.$timezone) {
      return oldStartOf.call(this, units, startOf);
    }
    var withoutTz = d(this.format("YYYY-MM-DD HH:mm:ss:SSS"), {
      locale: this.$L
    });
    var startOfWithoutTz = oldStartOf.call(withoutTz, units, startOf);
    return startOfWithoutTz.tz(this.$x.$timezone, true);
  };
  d.tz = function(input, arg1, arg2) {
    var parseFormat = arg2 && arg1;
    var timezone = arg2 || arg1 || defaultTimezone;
    var previousOffset = tzOffset(+d(), timezone);
    if (typeof input !== "string") {
      return d(input).tz(timezone);
    }
    var localTs = d.utc(input, parseFormat).valueOf();
    var _fixOffset = fixOffset(localTs, previousOffset, timezone), targetTs = _fixOffset[0], targetOffset = _fixOffset[1];
    var ins = d(targetTs).utcOffset(targetOffset);
    ins.$x.$timezone = timezone;
    return ins;
  };
  d.tz.guess = function() {
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
  };
  d.tz.setDefault = function(timezone) {
    defaultTimezone = timezone;
  };
};
export {
  timezone_default as default
};
//# sourceMappingURL=dayjs_esm_plugin_timezone.js.map
