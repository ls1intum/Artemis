import {
  UserImportModule,
  UsersImportButtonComponent,
  init_user_import_module,
  init_users_import_button_component
} from "/chunk-DIXFAAG2.js";
import {
  iconsAsHTML,
  init_icons_utils
} from "/chunk-WQTVRJBQ.js";
import {
  ArtemisDataTableModule,
  DataTableComponent,
  init_data_table_component,
  init_data_table_module
} from "/chunk-KUURZL6B.js";
import {
  TutorialGroupsConfiguration,
  init_tutorial_groups_configuration_model
} from "/chunk-T6WBGNNS.js";
import {
  ChecklistCheckComponent,
  init_checklist_check_component
} from "/chunk-ORYTP7RT.js";
import {
  init_global_utils,
  onError
} from "/chunk-LW4WH7EZ.js";
import {
  ActionType,
  AlertService,
  ArtemisDateRangePipe,
  ArtemisSharedModule,
  ArtemisTranslatePipe,
  CourseManagementService,
  CourseStorageService,
  DeleteButtonDirective,
  LoadingIndicatorContainerComponent,
  TranslateDirective,
  TutorialGroupsConfigurationService,
  __esm,
  __spreadValues,
  init_alert_service,
  init_artemis_date_range_pipe,
  init_artemis_translate_pipe,
  init_course_management_service,
  init_course_model,
  init_course_storage_service,
  init_delete_button_directive,
  init_delete_dialog_model,
  init_loading_indicator_container_component,
  init_shared_module,
  init_translate_directive,
  init_tutorial_groups_configuration_service,
  isMessagingEnabled
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/course/tutorial-groups/tutorial-groups-management/tutorial-groups-checklist/tutorial-groups-checklist.component.ts
import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { Subject, combineLatest, finalize, switchMap, take } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { faPlus, faWrench } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import { takeUntil } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i5 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
function TutorialGroupsChecklistComponent_Conditional_2_Conditional_57_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "a", 10);
    i0.\u0275\u0275text(2, "\n                            ");
    i0.\u0275\u0275element(3, "fa-icon", 6);
    i0.\u0275\u0275text(4, "\xA0");
    i0.\u0275\u0275elementStart(5, "span");
    i0.\u0275\u0275text(6);
    i0.\u0275\u0275pipe(7, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275classProp("disabled", !ctx_r1.isTimeZoneConfigured);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction2(7, _c0, ctx_r1.course.id, ctx_r1.course.tutorialGroupsConfiguration.id));
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r1.faPlus);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(7, 5, "artemisApp.pages.tutorialGroupsManagement.editConfigurationButton"));
  }
}
function TutorialGroupsChecklistComponent_Conditional_2_Conditional_58_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n                        ");
    i0.\u0275\u0275elementStart(1, "a", 10);
    i0.\u0275\u0275text(2, "\n                            ");
    i0.\u0275\u0275element(3, "fa-icon", 6);
    i0.\u0275\u0275text(4, "\xA0");
    i0.\u0275\u0275elementStart(5, "span");
    i0.\u0275\u0275text(6);
    i0.\u0275\u0275pipe(7, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(9, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r2 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275classProp("disabled", !ctx_r2.isTimeZoneConfigured);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction1(7, _c1, ctx_r2.course.id));
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r2.faPlus);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(7, 5, "artemisApp.pages.checklist.createConfiguration"));
  }
}
function TutorialGroupsChecklistComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, "\n        ");
    i0.\u0275\u0275elementStart(1, "div", 1);
    i0.\u0275\u0275text(2, "\n            ");
    i0.\u0275\u0275elementStart(3, "div", 2);
    i0.\u0275\u0275text(4, "\n                ");
    i0.\u0275\u0275elementStart(5, "h1");
    i0.\u0275\u0275text(6);
    i0.\u0275\u0275pipe(7, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, "\n                ");
    i0.\u0275\u0275elementStart(9, "p");
    i0.\u0275\u0275text(10);
    i0.\u0275\u0275pipe(11, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(13, "\n            ");
    i0.\u0275\u0275element(14, "hr");
    i0.\u0275\u0275text(15, "\n            ");
    i0.\u0275\u0275elementStart(16, "div", 2);
    i0.\u0275\u0275text(17, "\n                ");
    i0.\u0275\u0275elementStart(18, "p");
    i0.\u0275\u0275text(19);
    i0.\u0275\u0275pipe(20, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(21, "\n                ");
    i0.\u0275\u0275elementStart(22, "div");
    i0.\u0275\u0275text(23, "\n                    ");
    i0.\u0275\u0275element(24, "jhi-checklist-check", 3);
    i0.\u0275\u0275text(25, "\n                    ");
    i0.\u0275\u0275elementStart(26, "label", 4);
    i0.\u0275\u0275text(27);
    i0.\u0275\u0275pipe(28, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(29, "\n                    ");
    i0.\u0275\u0275elementStart(30, "a", 5);
    i0.\u0275\u0275text(31, "\n                        ");
    i0.\u0275\u0275element(32, "fa-icon", 6);
    i0.\u0275\u0275text(33, "\xA0");
    i0.\u0275\u0275elementStart(34, "span");
    i0.\u0275\u0275text(35);
    i0.\u0275\u0275pipe(36, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(37, "\n                    ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(38, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(39, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(40, "\n            ");
    i0.\u0275\u0275element(41, "hr");
    i0.\u0275\u0275text(42, "\n            ");
    i0.\u0275\u0275elementStart(43, "div", 2);
    i0.\u0275\u0275text(44, "\n                ");
    i0.\u0275\u0275elementStart(45, "p");
    i0.\u0275\u0275text(46);
    i0.\u0275\u0275pipe(47, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(48, "\n                ");
    i0.\u0275\u0275elementStart(49, "table");
    i0.\u0275\u0275text(50, "\n                    ");
    i0.\u0275\u0275element(51, "jhi-checklist-check", 7);
    i0.\u0275\u0275text(52, "\n                    ");
    i0.\u0275\u0275elementStart(53, "label", 8);
    i0.\u0275\u0275text(54);
    i0.\u0275\u0275pipe(55, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(56, "\n                    ");
    i0.\u0275\u0275template(57, TutorialGroupsChecklistComponent_Conditional_2_Conditional_57_Template, 10, 10)(58, TutorialGroupsChecklistComponent_Conditional_2_Conditional_58_Template, 10, 9);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(59, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(60, "\n            ");
    i0.\u0275\u0275element(61, "hr");
    i0.\u0275\u0275text(62, "\n            ");
    i0.\u0275\u0275elementStart(63, "div", 2);
    i0.\u0275\u0275text(64, "\n                ");
    i0.\u0275\u0275elementStart(65, "button", 9);
    i0.\u0275\u0275text(66, "\n                    ");
    i0.\u0275\u0275elementStart(67, "span");
    i0.\u0275\u0275text(68);
    i0.\u0275\u0275pipe(69, "artemisTranslate");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(70, "\n                ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(71, "\n            ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(72, "\n        ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(73, "\n    ");
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(7, 16, "artemisApp.pages.checklist.title"));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate1("\n                    ", i0.\u0275\u0275pipeBind1(11, 18, "artemisApp.pages.checklist.explanation"), "\n                ");
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(20, 20, "artemisApp.pages.checklist.timeZoneExplanation"));
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275property("checkAttribute", ctx_r0.isTimeZoneConfigured);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate1("\n                        ", i0.\u0275\u0275pipeBind1(28, 22, "artemisApp.pages.checklist.timeZone"), "\n                    ");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction1(32, _c2, ctx_r0.course.id));
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("icon", ctx_r0.faWrench);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(36, 24, "artemisApp.pages.checklist.editCourse"));
    i0.\u0275\u0275advance(11);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(47, 26, "artemisApp.pages.checklist.configurationExplanation"));
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275property("checkAttribute", ctx_r0.isTutorialGroupConfigurationCreated);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate1("\n                        ", i0.\u0275\u0275pipeBind1(55, 28, "artemisApp.pages.checklist.configuration"), "\n                    ");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(57, ctx_r0.isTutorialGroupConfigurationCreated ? 57 : -1);
    i0.\u0275\u0275advance(1);
    i0.\u0275\u0275conditional(58, !ctx_r0.isTutorialGroupConfigurationCreated ? 58 : -1);
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction1(34, _c3, ctx_r0.course.id))("disabled", !ctx_r0.isFullyConfigured);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(69, 30, "artemisApp.pages.checklist.continueToManagement"));
  }
}
var _c0, _c1, _c2, _c3, TutorialGroupsChecklistComponent;
var init_tutorial_groups_checklist_component = __esm({
  "src/main/webapp/app/course/tutorial-groups/tutorial-groups-management/tutorial-groups-checklist/tutorial-groups-checklist.component.ts"() {
    init_course_management_service();
    init_alert_service();
    init_global_utils();
    init_tutorial_groups_configuration_service();
    init_course_management_service();
    init_alert_service();
    init_tutorial_groups_configuration_service();
    init_loading_indicator_container_component();
    init_checklist_check_component();
    init_artemis_translate_pipe();
    _c0 = (a1, a4) => ["/course-management", a1, "tutorial-groups", "configuration", a4, "edit"];
    _c1 = (a1) => ["/course-management", a1, "create-tutorial-groups-configuration"];
    _c2 = (a1) => ["/course-management", a1, "edit"];
    _c3 = (a1) => ["/course-management", a1, "tutorial-groups"];
    TutorialGroupsChecklistComponent = class _TutorialGroupsChecklistComponent {
      activatedRoute;
      courseManagementService;
      alertService;
      tutorialGroupsConfigurationService;
      cdr;
      isLoading = false;
      course;
      isTimeZoneConfigured = false;
      isTutorialGroupConfigurationCreated = false;
      faWrench = faWrench;
      faPlus = faPlus;
      ngUnsubscribe = new Subject();
      constructor(activatedRoute, courseManagementService, alertService, tutorialGroupsConfigurationService, cdr) {
        this.activatedRoute = activatedRoute;
        this.courseManagementService = courseManagementService;
        this.alertService = alertService;
        this.tutorialGroupsConfigurationService = tutorialGroupsConfigurationService;
        this.cdr = cdr;
      }
      get isFullyConfigured() {
        return this.isTimeZoneConfigured && this.isTutorialGroupConfigurationCreated;
      }
      ngOnInit() {
        this.isLoading = true;
        this.activatedRoute.paramMap.pipe(take(1), switchMap((params) => {
          const courseId = Number(params.get("courseId"));
          return combineLatest([this.courseManagementService.find(courseId), this.tutorialGroupsConfigurationService.getOneOfCourse(courseId)]);
        }), finalize(() => this.isLoading = false), takeUntil(this.ngUnsubscribe)).subscribe({
          next: ([courseResult, configurationResult]) => {
            if (courseResult.body) {
              this.course = courseResult.body;
              this.isTimeZoneConfigured = !!this.course.timeZone;
            }
            if (configurationResult.body) {
              this.course.tutorialGroupsConfiguration = configurationResult.body;
              this.isTutorialGroupConfigurationCreated = !!this.course.tutorialGroupsConfiguration;
            }
          },
          error: (res) => onError(this.alertService, res)
        }).add(() => this.cdr.detectChanges());
      }
      ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
      }
      static \u0275fac = function TutorialGroupsChecklistComponent_Factory(t) {
        return new (t || _TutorialGroupsChecklistComponent)(i0.\u0275\u0275directiveInject(i1.ActivatedRoute), i0.\u0275\u0275directiveInject(CourseManagementService), i0.\u0275\u0275directiveInject(AlertService), i0.\u0275\u0275directiveInject(TutorialGroupsConfigurationService), i0.\u0275\u0275directiveInject(i0.ChangeDetectorRef));
      };
      static \u0275cmp = i0.\u0275\u0275defineComponent({ type: _TutorialGroupsChecklistComponent, selectors: [["jhi-tutorial-groups-checklist"]], decls: 4, vars: 2, consts: [[3, "isLoading"], [1, "row"], [1, "col-12"], ["id", "timeZone", 3, "checkAttribute"], ["for", "timeZone", 1, "form-check-label", "pe-4"], [1, "btn", "btn-warning", "btn-md", "my-2", 3, "routerLink"], [3, "icon"], ["id", "configuration", 3, "checkAttribute"], ["for", "configuration", 1, "form-check-label", "pe-4"], [1, "btn", "btn-primary", "btn-md", "my-2", 3, "routerLink", "disabled"], [1, "btn", "btn-primary", "btn-md", "my-2", 3, "routerLink"]], template: function TutorialGroupsChecklistComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.\u0275\u0275elementStart(0, "jhi-loading-indicator-container", 0);
          i0.\u0275\u0275text(1, "\n    ");
          i0.\u0275\u0275template(2, TutorialGroupsChecklistComponent_Conditional_2_Template, 74, 36);
          i0.\u0275\u0275elementEnd();
          i0.\u0275\u0275text(3, "\n");
        }
        if (rf & 2) {
          i0.\u0275\u0275property("isLoading", ctx.isLoading);
          i0.\u0275\u0275advance(2);
          i0.\u0275\u0275conditional(2, ctx.course ? 2 : -1);
        }
      }, dependencies: [i1.RouterLink, i5.FaIconComponent, LoadingIndicatorContainerComponent, ChecklistCheckComponent, ArtemisTranslatePipe], encapsulation: 2, changeDetection: 0 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(TutorialGroupsChecklistComponent, { className: "TutorialGroupsChecklistComponent" });
    })();
  }
});

// src/main/webapp/app/course/tutorial-groups/tutorial-groups-management/tutorial-groups-configuration/crud/tutorial-groups-configuration-form/tutorial-groups-configuration-form.component.ts
import { ChangeDetectionStrategy as ChangeDetectionStrategy2, Component as Component2, EventEmitter, Input, Output } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { FormBuilder, Validators } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import { faCalendarAlt } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_forms.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@danielmoncada_angular-datetime-picker.js?v=1d0d9ead";
function TutorialGroupsConfigurationFormComponent_Conditional_4_Conditional_30_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                    ", i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.forms.configurationForm.periodInput.requiredValidationError"), "\n                                ");
  }
}
function TutorialGroupsConfigurationFormComponent_Conditional_4_Conditional_30_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                    ", i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.forms.configurationForm.periodInput.parseError"), "\n                                ");
  }
}
function TutorialGroupsConfigurationFormComponent_Conditional_4_Conditional_30_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "div");
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                    ", i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.forms.configurationForm.periodInput.invalidRangeError"), "\n                                ");
  }
}
function TutorialGroupsConfigurationFormComponent_Conditional_4_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                        ");
    i02.\u0275\u0275elementStart(1, "div", 28);
    i02.\u0275\u0275text(2, "\n                            ");
    i02.\u0275\u0275template(3, TutorialGroupsConfigurationFormComponent_Conditional_4_Conditional_30_Conditional_3_Template, 5, 3)(4, TutorialGroupsConfigurationFormComponent_Conditional_4_Conditional_30_Conditional_4_Template, 5, 3)(5, TutorialGroupsConfigurationFormComponent_Conditional_4_Conditional_30_Conditional_5_Template, 5, 3);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(6, "\n                    ");
  }
  if (rf & 2) {
    const ctx_r2 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(3, (ctx_r2.periodControl == null ? null : ctx_r2.periodControl.errors == null ? null : ctx_r2.periodControl.errors.owlRequiredDateTimeRange) || (ctx_r2.periodControl == null ? null : ctx_r2.periodControl.errors == null ? null : ctx_r2.periodControl.errors.required) ? 3 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(4, (ctx_r2.periodControl == null ? null : ctx_r2.periodControl.errors == null ? null : ctx_r2.periodControl.errors.owlDateTimeParse) ? 4 : -1);
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275conditional(5, (ctx_r2.periodControl == null ? null : ctx_r2.periodControl.errors == null ? null : ctx_r2.periodControl.errors.owlDateTimeRange) ? 5 : -1);
  }
}
function TutorialGroupsConfigurationFormComponent_Conditional_4_Conditional_46_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, "\n                                ");
    i02.\u0275\u0275elementStart(1, "div", 29);
    i02.\u0275\u0275text(2);
    i02.\u0275\u0275pipe(3, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(4, "\n                            ");
  }
  if (rf & 2) {
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1("\n                                    ", i02.\u0275\u0275pipeBind1(3, 1, "artemisApp.forms.configurationForm.useTutorialGroupChannelsInput.channelDeletionWarning"), "\n                                ");
  }
}
function TutorialGroupsConfigurationFormComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275text(0, "\n            ");
    i02.\u0275\u0275elementStart(1, "form", 2);
    i02.\u0275\u0275listener("ngSubmit", function TutorialGroupsConfigurationFormComponent_Conditional_4_Template_form_ngSubmit_1_listener() {
      i02.\u0275\u0275restoreView(_r8);
      const ctx_r7 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r7.submitForm());
    });
    i02.\u0275\u0275text(2, "\n                ");
    i02.\u0275\u0275text(3, "\n                ");
    i02.\u0275\u0275elementStart(4, "div", 3);
    i02.\u0275\u0275text(5, "\n                    ");
    i02.\u0275\u0275elementStart(6, "label", 4);
    i02.\u0275\u0275text(7);
    i02.\u0275\u0275pipe(8, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(9, "\n                    ");
    i02.\u0275\u0275elementStart(10, "div", 5);
    i02.\u0275\u0275text(11, "\n                        ");
    i02.\u0275\u0275elementStart(12, "input", 6);
    i02.\u0275\u0275listener("focus", function TutorialGroupsConfigurationFormComponent_Conditional_4_Template_input_focus_12_listener() {
      i02.\u0275\u0275restoreView(_r8);
      const ctx_r9 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r9.markPeriodAsTouched());
    });
    i02.\u0275\u0275pipe(13, "artemisDateRange");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(14, "\n                        ");
    i02.\u0275\u0275element(15, "input", 7);
    i02.\u0275\u0275text(16, "\n                        ");
    i02.\u0275\u0275elementStart(17, "button", 8);
    i02.\u0275\u0275text(18, "\n                            ");
    i02.\u0275\u0275element(19, "fa-icon", 9);
    i02.\u0275\u0275text(20, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(21, "\n                        ");
    i02.\u0275\u0275element(22, "owl-date-time", 10, 11);
    i02.\u0275\u0275text(24, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(25, "\n                    ");
    i02.\u0275\u0275elementStart(26, "div", 12);
    i02.\u0275\u0275text(27);
    i02.\u0275\u0275pipe(28, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(29, "\n                    ");
    i02.\u0275\u0275template(30, TutorialGroupsConfigurationFormComponent_Conditional_4_Conditional_30_Template, 7, 3);
    i02.\u0275\u0275text(31, "\n                    ");
    i02.\u0275\u0275elementStart(32, "div", 13);
    i02.\u0275\u0275text(33, "\n                        ");
    i02.\u0275\u0275elementStart(34, "div", 14);
    i02.\u0275\u0275text(35, "\n                            ");
    i02.\u0275\u0275element(36, "input", 15);
    i02.\u0275\u0275text(37, "\n                            ");
    i02.\u0275\u0275elementStart(38, "label", 16);
    i02.\u0275\u0275text(39);
    i02.\u0275\u0275pipe(40, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(41, "\n                            ");
    i02.\u0275\u0275elementStart(42, "small", 17);
    i02.\u0275\u0275text(43);
    i02.\u0275\u0275pipe(44, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(45, "\n                            ");
    i02.\u0275\u0275template(46, TutorialGroupsConfigurationFormComponent_Conditional_4_Conditional_46_Template, 5, 3);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(47, "\n                        ");
    i02.\u0275\u0275text(48, "\n                        ");
    i02.\u0275\u0275elementStart(49, "div", 18);
    i02.\u0275\u0275text(50, "\n                            ");
    i02.\u0275\u0275elementStart(51, "label", 19);
    i02.\u0275\u0275text(52);
    i02.\u0275\u0275pipe(53, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(54, "\n                            ");
    i02.\u0275\u0275elementStart(55, "div", 20);
    i02.\u0275\u0275text(56, "\n                                ");
    i02.\u0275\u0275element(57, "input", 21);
    i02.\u0275\u0275text(58, "\n                                ");
    i02.\u0275\u0275elementStart(59, "label", 22);
    i02.\u0275\u0275text(60);
    i02.\u0275\u0275pipe(61, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(62, "\n                                ");
    i02.\u0275\u0275element(63, "input", 23);
    i02.\u0275\u0275text(64, "\n                                ");
    i02.\u0275\u0275elementStart(65, "label", 24);
    i02.\u0275\u0275text(66);
    i02.\u0275\u0275pipe(67, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(68, "\n                            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(69, "\n                            ");
    i02.\u0275\u0275elementStart(70, "small", 25);
    i02.\u0275\u0275text(71);
    i02.\u0275\u0275pipe(72, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(73, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(74, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(75, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(76, "\n                ");
    i02.\u0275\u0275elementStart(77, "div", 26);
    i02.\u0275\u0275text(78, "\n                    ");
    i02.\u0275\u0275elementStart(79, "div", 1);
    i02.\u0275\u0275text(80, "\n                        ");
    i02.\u0275\u0275elementStart(81, "button", 27);
    i02.\u0275\u0275text(82, "\n                            ");
    i02.\u0275\u0275elementStart(83, "span");
    i02.\u0275\u0275text(84);
    i02.\u0275\u0275pipe(85, "artemisTranslate");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(86, "\n                        ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(87, "\n                    ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(88, "\n                ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(89, "\n            ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(90, "\n        ");
  }
  if (rf & 2) {
    const _r1 = i02.\u0275\u0275reference(23);
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(1);
    i02.\u0275\u0275property("formGroup", ctx_r0.form);
    i02.\u0275\u0275advance(6);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(8, 27, "artemisApp.forms.configurationForm.periodInput.label"));
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275classProp("is-invalid", ctx_r0.isPeriodInvalid);
    i02.\u0275\u0275property("value", i02.\u0275\u0275pipeBind4(13, 29, ctx_r0.periodControl == null ? null : ctx_r0.periodControl.value, "long-date", void 0, true))("owlDateTimeTrigger", _r1);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("owlDateTime", _r1)("selectMode", "range");
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("owlDateTimeTrigger", _r1);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("icon", ctx_r0.faCalendarAlt);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("firstDayOfWeek", 1)("pickerType", "calendar");
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275textInterpolate1("\n                        ", i02.\u0275\u0275pipeBind1(28, 34, "artemisApp.forms.configurationForm.periodInput.explanation"), "\n                    ");
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(30, (ctx_r0.periodControl == null ? null : ctx_r0.periodControl.invalid) && ((ctx_r0.periodControl == null ? null : ctx_r0.periodControl.dirty) || (ctx_r0.periodControl == null ? null : ctx_r0.periodControl.touched)) ? 30 : -1);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275property("hidden", !ctx_r0.isMessagingEnabled(ctx_r0.course));
    i02.\u0275\u0275advance(7);
    i02.\u0275\u0275textInterpolate1("\n                                ", i02.\u0275\u0275pipeBind1(40, 36, "artemisApp.forms.configurationForm.useTutorialGroupChannelsInput.label"), "\n                            ");
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(44, 38, "artemisApp.forms.configurationForm.useTutorialGroupChannelsInput.explanation"));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(46, ctx_r0.showChannelDeletionWarning ? 46 : -1);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("hidden", !(ctx_r0.useTutorialGroupChannelsControl == null ? null : ctx_r0.useTutorialGroupChannelsControl.value));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(53, 40, "artemisApp.dialogs.createChannel.channelForm.isPublicInput.label"));
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275property("value", true);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(61, 42, "artemisApp.dialogs.createChannel.channelForm.isPublicInput.public"));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("value", false);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(67, 44, "artemisApp.dialogs.createChannel.channelForm.isPublicInput.private"));
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(72, 46, "artemisApp.dialogs.createChannel.channelForm.isPublicInput.explanation"));
    i02.\u0275\u0275advance(10);
    i02.\u0275\u0275property("disabled", !ctx_r0.isSubmitPossible);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(i02.\u0275\u0275pipeBind1(85, 48, ctx_r0.isEditMode ? "global.generic.edit" : "global.generic.create"));
  }
}
var TutorialGroupsConfigurationFormComponent;
var init_tutorial_groups_configuration_form_component = __esm({
  "src/main/webapp/app/course/tutorial-groups/tutorial-groups-management/tutorial-groups-configuration/crud/tutorial-groups-configuration-form/tutorial-groups-configuration-form.component.ts"() {
    init_course_model();
    init_artemis_date_range_pipe();
    init_artemis_translate_pipe();
    TutorialGroupsConfigurationFormComponent = class _TutorialGroupsConfigurationFormComponent {
      fb;
      formData = {
        period: void 0,
        usePublicTutorialGroupChannels: false,
        useTutorialGroupChannels: false
      };
      isEditMode = false;
      formSubmitted = new EventEmitter();
      course;
      faCalendarAlt = faCalendarAlt;
      isMessagingEnabled = isMessagingEnabled;
      existingChannelSetting;
      form;
      constructor(fb) {
        this.fb = fb;
      }
      get periodControl() {
        return this.form.get("period");
      }
      get useTutorialGroupChannelsControl() {
        return this.form.get("useTutorialGroupChannels");
      }
      get usePublicTutorialGroupChannelsControl() {
        return this.form.get("usePublicTutorialGroupChannels");
      }
      get isSubmitPossible() {
        return !this.form.invalid;
      }
      ngOnInit() {
        this.initializeForm();
      }
      ngOnChanges() {
        this.initializeForm();
        if (this.isEditMode && this.formData) {
          this.setFormValues(this.formData);
        }
      }
      setFormValues(formData) {
        this.existingChannelSetting = formData.useTutorialGroupChannels;
        this.form.patchValue(formData);
      }
      get showChannelDeletionWarning() {
        if (!this.isEditMode) {
          return false;
        }
        if (this.existingChannelSetting === void 0) {
          return false;
        }
        return this.existingChannelSetting && this.useTutorialGroupChannelsControl?.value === false;
      }
      initializeForm() {
        if (this.form) {
          return;
        }
        this.form = this.fb.group({
          period: [void 0, Validators.required],
          useTutorialGroupChannels: [false],
          usePublicTutorialGroupChannels: [false]
        });
      }
      submitForm() {
        this.formSubmitted.emit(__spreadValues({}, this.form.value));
      }
      get isPeriodInvalid() {
        if (this.periodControl) {
          return this.periodControl.invalid && (this.periodControl.touched || this.periodControl.dirty);
        } else {
          return false;
        }
      }
      markPeriodAsTouched() {
        if (this.periodControl) {
          this.periodControl.markAsTouched();
        }
      }
      static \u0275fac = function TutorialGroupsConfigurationFormComponent_Factory(t) {
        return new (t || _TutorialGroupsConfigurationFormComponent)(i02.\u0275\u0275directiveInject(i12.FormBuilder));
      };
      static \u0275cmp = i02.\u0275\u0275defineComponent({ type: _TutorialGroupsConfigurationFormComponent, selectors: [["jhi-tutorial-groups-configuration-form"]], inputs: { formData: "formData", isEditMode: "isEditMode", course: "course" }, outputs: { formSubmitted: "formSubmitted" }, features: [i02.\u0275\u0275NgOnChangesFeature], decls: 7, vars: 1, consts: [[1, "row"], [1, "col-12"], [1, "row", 3, "formGroup", "ngSubmit"], [1, "col-auto"], ["for", "period", 1, "form-label"], [1, "input-group"], ["name", "period", "id", "period", "required", "", "readonly", "", 1, "form-control", 3, "value", "owlDateTimeTrigger", "focus"], ["formControlName", "period", 1, "date-time-picker-anchor", 3, "owlDateTime", "selectMode"], ["type", "button", 1, "btn", "btn-secondary", 3, "owlDateTimeTrigger"], [3, "icon"], [3, "firstDayOfWeek", "pickerType"], ["period", ""], [1, "form-text"], [3, "hidden"], [1, "form-check"], ["type", "checkbox", "formControlName", "useTutorialGroupChannels", "id", "useTutorialGroupChannels", 1, "form-check-input"], ["for", "useTutorialGroupChannels", 1, "form-check-label"], ["id", "channelHelp", 1, "form-text", "text-body-secondary", "d-block"], [1, "form-group", 3, "hidden"], [1, "d-block"], ["role", "group", 1, "btn-group"], ["formControlName", "usePublicTutorialGroupChannels", "type", "radio", "id", "public", "autocomplete", "off", "checked", "", 1, "btn-check", 3, "value"], ["for", "public", 1, "btn", "btn-outline-secondary"], ["formControlName", "usePublicTutorialGroupChannels", "type", "radio", "id", "private", "autocomplete", "off", 1, "btn-check", 3, "value"], ["for", "private", 1, "btn", "btn-outline-secondary"], ["id", "isPublicHelp", 1, "form-text", "text-body-secondary", "d-block"], [1, "row", "mt-2"], ["id", "submitButton", "type", "submit", 1, "btn", "btn-primary", 3, "disabled"], [1, "alert", "alert-danger"], ["role", "alert", "id", "channelDeletionWarning", 1, "alert", "alert-danger"]], template: function TutorialGroupsConfigurationFormComponent_Template(rf, ctx) {
        if (rf & 1) {
          i02.\u0275\u0275elementStart(0, "div", 0);
          i02.\u0275\u0275text(1, "\n    ");
          i02.\u0275\u0275elementStart(2, "div", 1);
          i02.\u0275\u0275text(3, "\n        ");
          i02.\u0275\u0275template(4, TutorialGroupsConfigurationFormComponent_Conditional_4_Template, 91, 50);
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(5, "\n");
          i02.\u0275\u0275elementEnd();
          i02.\u0275\u0275text(6, "\n");
        }
        if (rf & 2) {
          i02.\u0275\u0275advance(4);
          i02.\u0275\u0275conditional(4, ctx.form ? 4 : -1);
        }
      }, dependencies: [i12.\u0275NgNoValidate, i12.DefaultValueAccessor, i12.CheckboxControlValueAccessor, i12.RadioControlValueAccessor, i12.NgControlStatus, i12.NgControlStatusGroup, i2.FaIconComponent, i12.FormGroupDirective, i12.FormControlName, i3.OwlDateTimeTriggerDirective, i3.OwlDateTimeInputDirective, i3.OwlDateTimeComponent, ArtemisDateRangePipe, ArtemisTranslatePipe], styles: ["\n\n.date-time-picker-anchor[_ngcontent-%COMP%] {\n  visibility: hidden;\n  width: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvdHV0b3JpYWwtZ3JvdXBzL3R1dG9yaWFsLWdyb3Vwcy1tYW5hZ2VtZW50L3R1dG9yaWFsLWdyb3Vwcy1jb25maWd1cmF0aW9uL2NydWQvdHV0b3JpYWwtZ3JvdXBzLWNvbmZpZ3VyYXRpb24tZm9ybS90dXRvcmlhbC1ncm91cHMtY29uZmlndXJhdGlvbi1mb3JtLmNvbXBvbmVudC5zY3NzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIuZGF0ZS10aW1lLXBpY2tlci1hbmNob3Ige1xuICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcbiAgICB3aWR0aDogMDtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxDQUFBO0FBQ0ksY0FBQTtBQUNBLFNBQUE7OyIsCiAgIm5hbWVzIjogW10KfQo= */"], changeDetection: 0 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(TutorialGroupsConfigurationFormComponent, { className: "TutorialGroupsConfigurationFormComponent" });
    })();
  }
});

// src/main/webapp/app/course/tutorial-groups/tutorial-groups-management/tutorial-groups-configuration/crud/create-tutorial-groups-configuration/create-tutorial-groups-configuration.component.ts
import { ChangeDetectionStrategy as ChangeDetectionStrategy3, ChangeDetectorRef as ChangeDetectorRef3, Component as Component3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { ActivatedRoute as ActivatedRoute3, Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { finalize as finalize2, switchMap as switchMap2, take as take2, takeUntil as takeUntil2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { Subject as Subject2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
var CreateTutorialGroupsConfigurationComponent;
var init_create_tutorial_groups_configuration_component = __esm({
  "src/main/webapp/app/course/tutorial-groups/tutorial-groups-management/tutorial-groups-configuration/crud/create-tutorial-groups-configuration/create-tutorial-groups-configuration.component.ts"() {
    init_alert_service();
    init_tutorial_groups_configuration_model();
    init_global_utils();
    init_tutorial_groups_configuration_service();
    init_course_management_service();
    init_course_storage_service();
    init_tutorial_groups_configuration_service();
    init_course_management_service();
    init_alert_service();
    init_course_storage_service();
    init_loading_indicator_container_component();
    init_tutorial_groups_configuration_form_component();
    init_artemis_translate_pipe();
    CreateTutorialGroupsConfigurationComponent = class _CreateTutorialGroupsConfigurationComponent {
      activatedRoute;
      router;
      tutorialGroupsConfigurationService;
      courseManagementService;
      alertService;
      courseStorageService;
      cdr;
      ngUnsubscribe = new Subject2();
      newTutorialGroupsConfiguration = new TutorialGroupsConfiguration();
      isLoading;
      course;
      constructor(activatedRoute, router, tutorialGroupsConfigurationService, courseManagementService, alertService, courseStorageService, cdr) {
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.tutorialGroupsConfigurationService = tutorialGroupsConfigurationService;
        this.courseManagementService = courseManagementService;
        this.alertService = alertService;
        this.courseStorageService = courseStorageService;
        this.cdr = cdr;
      }
      ngOnInit() {
        this.isLoading = true;
        this.activatedRoute.paramMap.pipe(take2(1), switchMap2((params) => {
          const courseId = Number(params.get("courseId"));
          return this.courseManagementService.find(courseId);
        }), finalize2(() => this.isLoading = false), takeUntil2(this.ngUnsubscribe)).subscribe({
          next: (courseResult) => {
            if (courseResult.body) {
              this.course = courseResult.body;
              this.newTutorialGroupsConfiguration = new TutorialGroupsConfiguration();
            }
          },
          error: (res) => onError(this.alertService, res)
        }).add(() => this.cdr.detectChanges());
      }
      createTutorialsGroupConfiguration(formData) {
        const { period, usePublicTutorialGroupChannels, useTutorialGroupChannels } = formData;
        this.isLoading = true;
        this.newTutorialGroupsConfiguration.useTutorialGroupChannels = useTutorialGroupChannels;
        this.newTutorialGroupsConfiguration.usePublicTutorialGroupChannels = usePublicTutorialGroupChannels;
        this.tutorialGroupsConfigurationService.create(this.newTutorialGroupsConfiguration, this.course.id, period ?? []).pipe(finalize2(() => {
          this.isLoading = false;
        }), takeUntil2(this.ngUnsubscribe)).subscribe({
          next: (resp) => {
            this.course.tutorialGroupsConfiguration = resp.body;
            this.courseStorageService.updateCourse(this.course);
            this.router.navigate(["/course-management", this.course.id, "tutorial-groups-checklist"]);
          },
          error: (res) => onError(this.alertService, res)
        });
      }
      ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
      }
      static \u0275fac = function CreateTutorialGroupsConfigurationComponent_Factory(t) {
        return new (t || _CreateTutorialGroupsConfigurationComponent)(i03.\u0275\u0275directiveInject(i13.ActivatedRoute), i03.\u0275\u0275directiveInject(i13.Router), i03.\u0275\u0275directiveInject(TutorialGroupsConfigurationService), i03.\u0275\u0275directiveInject(CourseManagementService), i03.\u0275\u0275directiveInject(AlertService), i03.\u0275\u0275directiveInject(CourseStorageService), i03.\u0275\u0275directiveInject(i03.ChangeDetectorRef));
      };
      static \u0275cmp = i03.\u0275\u0275defineComponent({ type: _CreateTutorialGroupsConfigurationComponent, selectors: [["jhi-create-tutorial-groups-configuration"]], decls: 14, vars: 9, consts: [[3, "isLoading"], ["role", "alert", 1, "alert", "alert-info"], [3, "isEditMode", "course", "formSubmitted"]], template: function CreateTutorialGroupsConfigurationComponent_Template(rf, ctx) {
        if (rf & 1) {
          i03.\u0275\u0275elementStart(0, "jhi-loading-indicator-container", 0);
          i03.\u0275\u0275text(1, "\n    ");
          i03.\u0275\u0275elementStart(2, "h3");
          i03.\u0275\u0275text(3);
          i03.\u0275\u0275pipe(4, "artemisTranslate");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(5, "\n    ");
          i03.\u0275\u0275elementStart(6, "div", 1);
          i03.\u0275\u0275text(7);
          i03.\u0275\u0275pipe(8, "artemisTranslate");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(9, "\n    ");
          i03.\u0275\u0275elementStart(10, "jhi-tutorial-groups-configuration-form", 2);
          i03.\u0275\u0275listener("formSubmitted", function CreateTutorialGroupsConfigurationComponent_Template_jhi_tutorial_groups_configuration_form_formSubmitted_10_listener($event) {
            return ctx.createTutorialsGroupConfiguration($event);
          });
          i03.\u0275\u0275text(11, "\n    ");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(12, "\n");
          i03.\u0275\u0275elementEnd();
          i03.\u0275\u0275text(13, "\n");
        }
        if (rf & 2) {
          i03.\u0275\u0275property("isLoading", ctx.isLoading);
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275textInterpolate(i03.\u0275\u0275pipeBind1(4, 5, "artemisApp.pages.createTutorialGroupsConfiguration.title"));
          i03.\u0275\u0275advance(4);
          i03.\u0275\u0275textInterpolate1("\n        ", i03.\u0275\u0275pipeBind1(8, 7, "artemisApp.pages.createTutorialGroupsConfiguration.explanation"), "\n    ");
          i03.\u0275\u0275advance(3);
          i03.\u0275\u0275property("isEditMode", false)("course", ctx.course);
        }
      }, dependencies: [LoadingIndicatorContainerComponent, TutorialGroupsConfigurationFormComponent, ArtemisTranslatePipe], encapsulation: 2, changeDetection: 0 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(CreateTutorialGroupsConfigurationComponent, { className: "CreateTutorialGroupsConfigurationComponent" });
    })();
  }
});

// src/main/webapp/app/shared/course-group/course-group.component.ts
import { Component as Component4, EventEmitter as EventEmitter2, Input as Input2, Output as Output2, ViewChild, ViewEncapsulation } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject as Subject3, of } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { HttpResponse } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { catchError, map, switchMap as switchMap3, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import __vite__cjsImport32_exportToCsv from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/export-to-csv.js?v=1d0d9ead"; const ExportToCsv = __vite__cjsImport32_exportToCsv["ExportToCsv"];
import { faDownload, faUserSlash } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_free-solid-svg-icons.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@flaviosantoro92_ngx-datatable.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@fortawesome_angular-fontawesome.js?v=1d0d9ead";
import * as i7 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
function CourseGroupComponent_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "jhi-user-import-button", 4);
    i04.\u0275\u0275listener("finish", function CourseGroupComponent_Conditional_12_Template_jhi_user_import_button_finish_1_listener() {
      i04.\u0275\u0275restoreView(_r4);
      const ctx_r3 = i04.\u0275\u0275nextContext();
      return i04.\u0275\u0275resetView(ctx_r3.importFinish.emit());
    });
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(2, "\n            ");
  }
  if (rf & 2) {
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("courseId", ctx_r0.course.id)("courseGroup", ctx_r0.courseGroup)("tutorialGroup", ctx_r0.tutorialGroup);
  }
}
function CourseGroupComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                ");
    i04.\u0275\u0275elementStart(1, "button", 5);
    i04.\u0275\u0275listener("click", function CourseGroupComponent_Conditional_13_Template_button_click_1_listener() {
      i04.\u0275\u0275restoreView(_r6);
      const ctx_r5 = i04.\u0275\u0275nextContext();
      return i04.\u0275\u0275resetView(ctx_r5.exportUserInformation());
    });
    i04.\u0275\u0275text(2, "\n                    ");
    i04.\u0275\u0275element(3, "fa-icon", 6);
    i04.\u0275\u0275text(4, "\n                    ");
    i04.\u0275\u0275elementStart(5, "span", 7);
    i04.\u0275\u0275text(6, "\xA0Export Users");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(8, "\n            ");
  }
  if (rf & 2) {
    const ctx_r1 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("icon", ctx_r1.faDownload)("fixedWidth", true);
  }
}
function CourseGroupComponent_ng_template_18_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span", 17);
    i04.\u0275\u0275listener("click", function CourseGroupComponent_ng_template_18_ng_template_5_Template_span_click_1_listener() {
      i04.\u0275\u0275restoreView(_r23);
      const controls_r8 = i04.\u0275\u0275nextContext().controls;
      return i04.\u0275\u0275resetView(controls_r8.onSort("id"));
    });
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275elementStart(3, "span", 18);
    i04.\u0275\u0275text(4, " ID ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n                            ");
    i04.\u0275\u0275element(6, "fa-icon", 19);
    i04.\u0275\u0275text(7, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r8 = i04.\u0275\u0275nextContext().controls;
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275property("icon", controls_r8.iconForSortPropField("id"));
  }
}
function CourseGroupComponent_ng_template_18_ng_template_7_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                            ");
    i04.\u0275\u0275elementStart(1, "a", 20);
    i04.\u0275\u0275text(2);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(3, "\n                        ");
  }
  if (rf & 2) {
    const value_r25 = i04.\u0275\u0275nextContext().value;
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275propertyInterpolate1("routerLink", "/admin/user-management/", value_r25 == null ? null : value_r25.login, "");
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275textInterpolate1(" ", value_r25.id, " ");
  }
}
function CourseGroupComponent_ng_template_18_ng_template_7_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0);
  }
  if (rf & 2) {
    const value_r25 = i04.\u0275\u0275nextContext().value;
    i04.\u0275\u0275textInterpolate1("\n                            ", value_r25 == null ? null : value_r25.id, "\n                        ");
  }
}
function CourseGroupComponent_ng_template_18_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275template(1, CourseGroupComponent_ng_template_18_ng_template_7_Conditional_1_Template, 4, 2)(2, CourseGroupComponent_ng_template_18_ng_template_7_Conditional_2_Template, 1, 1);
  }
  if (rf & 2) {
    const ctx_r10 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275conditional(1, ctx_r10.isAdmin ? 1 : 2);
  }
}
function CourseGroupComponent_ng_template_18_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span", 17);
    i04.\u0275\u0275listener("click", function CourseGroupComponent_ng_template_18_ng_template_12_Template_span_click_1_listener() {
      i04.\u0275\u0275restoreView(_r32);
      const controls_r8 = i04.\u0275\u0275nextContext().controls;
      return i04.\u0275\u0275resetView(controls_r8.onSort("login"));
    });
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275elementStart(3, "span", 21);
    i04.\u0275\u0275text(4, " Login ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n                            ");
    i04.\u0275\u0275element(6, "fa-icon", 19);
    i04.\u0275\u0275text(7, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r8 = i04.\u0275\u0275nextContext().controls;
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275property("icon", controls_r8.iconForSortPropField("login"));
  }
}
function CourseGroupComponent_ng_template_18_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r34 = ctx.value;
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate(value_r34);
  }
}
function CourseGroupComponent_ng_template_18_ng_template_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r37 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span", 17);
    i04.\u0275\u0275listener("click", function CourseGroupComponent_ng_template_18_ng_template_19_Template_span_click_1_listener() {
      i04.\u0275\u0275restoreView(_r37);
      const controls_r8 = i04.\u0275\u0275nextContext().controls;
      return i04.\u0275\u0275resetView(controls_r8.onSort("visibleRegistrationNumber"));
    });
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275elementStart(3, "span", 22);
    i04.\u0275\u0275text(4, " Registration Number ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n                            ");
    i04.\u0275\u0275element(6, "fa-icon", 19);
    i04.\u0275\u0275text(7, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r8 = i04.\u0275\u0275nextContext().controls;
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275property("icon", controls_r8.iconForSortPropField("visibleRegistrationNumber"));
  }
}
function CourseGroupComponent_ng_template_18_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r39 = ctx.value;
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate(value_r39);
  }
}
function CourseGroupComponent_ng_template_18_ng_template_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r42 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span", 17);
    i04.\u0275\u0275listener("click", function CourseGroupComponent_ng_template_18_ng_template_26_Template_span_click_1_listener() {
      i04.\u0275\u0275restoreView(_r42);
      const controls_r8 = i04.\u0275\u0275nextContext().controls;
      return i04.\u0275\u0275resetView(controls_r8.onSort("name"));
    });
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275elementStart(3, "span", 23);
    i04.\u0275\u0275text(4, " Name ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n                            ");
    i04.\u0275\u0275element(6, "fa-icon", 19);
    i04.\u0275\u0275text(7, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r8 = i04.\u0275\u0275nextContext().controls;
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275property("icon", controls_r8.iconForSortPropField("name"));
  }
}
function CourseGroupComponent_ng_template_18_ng_template_28_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r44 = ctx.value;
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate(value_r44);
  }
}
function CourseGroupComponent_ng_template_18_ng_template_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r47 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span", 17);
    i04.\u0275\u0275listener("click", function CourseGroupComponent_ng_template_18_ng_template_33_Template_span_click_1_listener() {
      i04.\u0275\u0275restoreView(_r47);
      const controls_r8 = i04.\u0275\u0275nextContext().controls;
      return i04.\u0275\u0275resetView(controls_r8.onSort("email"));
    });
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275elementStart(3, "span", 24);
    i04.\u0275\u0275text(4, " Email ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(5, "\n                            ");
    i04.\u0275\u0275element(6, "fa-icon", 19);
    i04.\u0275\u0275text(7, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const controls_r8 = i04.\u0275\u0275nextContext().controls;
    i04.\u0275\u0275advance(6);
    i04.\u0275\u0275property("icon", controls_r8.iconForSortPropField("email"));
  }
}
function CourseGroupComponent_ng_template_18_ng_template_35_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "span");
    i04.\u0275\u0275text(2);
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(3, "\n                    ");
  }
  if (rf & 2) {
    const value_r49 = ctx.value;
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275textInterpolate(value_r49);
  }
}
function CourseGroupComponent_ng_template_18_ng_template_40_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, " ");
  }
}
function CourseGroupComponent_ng_template_18_ng_template_42_Template(rf, ctx) {
  if (rf & 1) {
    const _r52 = i04.\u0275\u0275getCurrentView();
    i04.\u0275\u0275text(0, "\n                        ");
    i04.\u0275\u0275elementStart(1, "div", 25);
    i04.\u0275\u0275text(2, "\n                            ");
    i04.\u0275\u0275elementStart(3, "button", 26);
    i04.\u0275\u0275listener("delete", function CourseGroupComponent_ng_template_18_ng_template_42_Template_button_delete_3_listener() {
      const restoredCtx = i04.\u0275\u0275restoreView(_r52);
      const value_r50 = restoredCtx.value;
      const ctx_r51 = i04.\u0275\u0275nextContext(2);
      return i04.\u0275\u0275resetView(ctx_r51.removeFromGroup(value_r50));
    });
    i04.\u0275\u0275text(4, "\n                                ");
    i04.\u0275\u0275element(5, "fa-icon", 27);
    i04.\u0275\u0275text(6, "\n                            ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(7, "\n                        ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(8, "\n                    ");
  }
  if (rf & 2) {
    const value_r50 = ctx.value;
    const ctx_r20 = i04.\u0275\u0275nextContext(2);
    i04.\u0275\u0275advance(3);
    i04.\u0275\u0275property("actionType", ctx_r20.ActionType.Remove)("entityTitle", value_r50.login)("dialogError", ctx_r20.dialogError$);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275property("icon", ctx_r20.faUserSlash);
  }
}
function CourseGroupComponent_ng_template_18_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275text(0, "\n            ");
    i04.\u0275\u0275elementStart(1, "ngx-datatable", 8);
    i04.\u0275\u0275text(2, "\n                ");
    i04.\u0275\u0275elementStart(3, "ngx-datatable-column", 9);
    i04.\u0275\u0275text(4, "\n                    ");
    i04.\u0275\u0275template(5, CourseGroupComponent_ng_template_18_ng_template_5_Template, 9, 1, "ng-template", 10);
    i04.\u0275\u0275text(6, "\n                    ");
    i04.\u0275\u0275template(7, CourseGroupComponent_ng_template_18_ng_template_7_Template, 3, 1, "ng-template", 11);
    i04.\u0275\u0275text(8, "\n                ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(9, "\n                ");
    i04.\u0275\u0275elementStart(10, "ngx-datatable-column", 12);
    i04.\u0275\u0275text(11, "\n                    ");
    i04.\u0275\u0275template(12, CourseGroupComponent_ng_template_18_ng_template_12_Template, 9, 1, "ng-template", 10);
    i04.\u0275\u0275text(13, "\n                    ");
    i04.\u0275\u0275template(14, CourseGroupComponent_ng_template_18_ng_template_14_Template, 4, 1, "ng-template", 11);
    i04.\u0275\u0275text(15, "\n                ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(16, "\n                ");
    i04.\u0275\u0275elementStart(17, "ngx-datatable-column", 13);
    i04.\u0275\u0275text(18, "\n                    ");
    i04.\u0275\u0275template(19, CourseGroupComponent_ng_template_18_ng_template_19_Template, 9, 1, "ng-template", 10);
    i04.\u0275\u0275text(20, "\n                    ");
    i04.\u0275\u0275template(21, CourseGroupComponent_ng_template_18_ng_template_21_Template, 4, 1, "ng-template", 11);
    i04.\u0275\u0275text(22, "\n                ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(23, "\n                ");
    i04.\u0275\u0275elementStart(24, "ngx-datatable-column", 14);
    i04.\u0275\u0275text(25, "\n                    ");
    i04.\u0275\u0275template(26, CourseGroupComponent_ng_template_18_ng_template_26_Template, 9, 1, "ng-template", 10);
    i04.\u0275\u0275text(27, "\n                    ");
    i04.\u0275\u0275template(28, CourseGroupComponent_ng_template_18_ng_template_28_Template, 4, 1, "ng-template", 11);
    i04.\u0275\u0275text(29, "\n                ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(30, "\n                ");
    i04.\u0275\u0275elementStart(31, "ngx-datatable-column", 15);
    i04.\u0275\u0275text(32, "\n                    ");
    i04.\u0275\u0275template(33, CourseGroupComponent_ng_template_18_ng_template_33_Template, 9, 1, "ng-template", 10);
    i04.\u0275\u0275text(34, "\n                    ");
    i04.\u0275\u0275template(35, CourseGroupComponent_ng_template_18_ng_template_35_Template, 4, 1, "ng-template", 11);
    i04.\u0275\u0275text(36, "\n                ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(37, "\n                ");
    i04.\u0275\u0275elementStart(38, "ngx-datatable-column", 16);
    i04.\u0275\u0275text(39, "\n                    ");
    i04.\u0275\u0275template(40, CourseGroupComponent_ng_template_18_ng_template_40_Template, 1, 0, "ng-template", 10);
    i04.\u0275\u0275text(41, "\n                    ");
    i04.\u0275\u0275template(42, CourseGroupComponent_ng_template_18_ng_template_42_Template, 9, 4, "ng-template", 11);
    i04.\u0275\u0275text(43, "\n                ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(44, "\n            ");
    i04.\u0275\u0275elementEnd();
    i04.\u0275\u0275text(45, "\n        ");
  }
  if (rf & 2) {
    const settings_r7 = ctx.settings;
    const ctx_r2 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance(1);
    i04.\u0275\u0275property("limit", settings_r7.limit)("sortType", settings_r7.sortType)("columnMode", settings_r7.columnMode)("headerHeight", settings_r7.headerHeight)("footerHeight", settings_r7.footerHeight)("rowHeight", settings_r7.rowHeight)("rows", settings_r7.rows)("rowClass", ctx_r2.dataTableRowClass)("scrollbarH", settings_r7.scrollbarH);
    i04.\u0275\u0275advance(2);
    i04.\u0275\u0275property("minWidth", 60)("width", 80)("maxWidth", 100);
    i04.\u0275\u0275advance(7);
    i04.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i04.\u0275\u0275advance(7);
    i04.\u0275\u0275property("minWidth", 150)("width", 200)("maxWidth", 200);
    i04.\u0275\u0275advance(7);
    i04.\u0275\u0275property("minWidth", 150)("width", 250)("maxWidth", 250);
    i04.\u0275\u0275advance(7);
    i04.\u0275\u0275property("minWidth", 150)("width", 250);
    i04.\u0275\u0275advance(7);
    i04.\u0275\u0275property("minWidth", 150)("width", 200);
  }
}
var _c02, _c12, NAME_KEY, USERNAME_KEY, EMAIL_KEY, REGISTRATION_NUMBER_KEY, cssClasses, CourseGroupComponent;
var init_course_group_component = __esm({
  "src/main/webapp/app/shared/course-group/course-group.component.ts"() {
    init_course_model();
    init_delete_dialog_model();
    init_data_table_component();
    init_icons_utils();
    init_data_table_component();
    init_users_import_button_component();
    init_translate_directive();
    init_delete_button_directive();
    _c02 = () => ["login", "name"];
    _c12 = ["*"];
    NAME_KEY = "Name";
    USERNAME_KEY = "Username";
    EMAIL_KEY = "Email";
    REGISTRATION_NUMBER_KEY = "Registration Number";
    cssClasses = {
      alreadyMember: "already-member",
      newlyAddedMember: "newly-added-member"
    };
    CourseGroupComponent = class _CourseGroupComponent {
      dataTable;
      allGroupUsers = [];
      isLoadingAllGroupUsers = false;
      isAdmin = false;
      course;
      tutorialGroup = void 0;
      courseGroup;
      exportFileName;
      userSearch = () => of(new HttpResponse({ body: [] }));
      addUserToGroup = () => of(new HttpResponse());
      removeUserFromGroup = () => of(new HttpResponse());
      handleUsersSizeChange = () => {
      };
      importFinish = new EventEmitter2();
      ActionType = ActionType;
      dialogErrorSource = new Subject3();
      dialogError$ = this.dialogErrorSource.asObservable();
      isSearching = false;
      searchFailed = false;
      searchNoResults = false;
      isTransitioning = false;
      rowClass = void 0;
      faDownload = faDownload;
      faUserSlash = faUserSlash;
      ngOnDestroy() {
        this.dialogErrorSource.unsubscribe();
      }
      searchAllUsers = (stream$) => {
        return stream$.pipe(switchMap3(({ text: loginOrName }) => {
          this.searchFailed = false;
          this.searchNoResults = false;
          if (loginOrName.length < 3) {
            return of([]);
          }
          this.isSearching = true;
          return this.userSearch(loginOrName).pipe(map((usersResponse) => usersResponse.body)).pipe(tap((users) => {
            if (users.length === 0) {
              this.searchNoResults = true;
            }
          }), catchError(() => {
            this.searchFailed = true;
            return of([]);
          }));
        }), tap(() => {
          this.isSearching = false;
        }), tap((users) => {
          setTimeout(() => {
            for (let i = 0; i < this.dataTable.typeaheadButtons.length; i++) {
              const isAlreadyInGroup = this.allGroupUsers.map((user) => user.id).includes(users[i].id);
              this.dataTable.typeaheadButtons[i].insertAdjacentHTML("beforeend", iconsAsHTML[isAlreadyInGroup ? "users" : "users-plus"]);
              if (isAlreadyInGroup) {
                this.dataTable.typeaheadButtons[i].classList.add(cssClasses.alreadyMember);
              }
            }
          });
        }));
      };
      onAutocompleteSelect = (user, callback) => {
        if (!this.allGroupUsers.map((u) => u.id).includes(user.id) && user.login) {
          this.isTransitioning = true;
          this.addUserToGroup(user.login).subscribe({
            next: () => {
              this.isTransitioning = false;
              this.allGroupUsers.push(user);
              callback(user);
              this.flashRowClass(cssClasses.newlyAddedMember);
            },
            error: () => {
              this.isTransitioning = false;
            }
          });
        } else {
          callback(user);
        }
      };
      removeFromGroup(user) {
        if (user.login) {
          this.removeUserFromGroup(user.login).subscribe({
            next: () => {
              this.allGroupUsers = this.allGroupUsers.filter((u) => u.login !== user.login);
              this.dialogErrorSource.next("");
            },
            error: (error) => this.dialogErrorSource.next(error.message)
          });
        }
      }
      searchResultFormatter = (user) => {
        const { name, login } = user;
        return `${name} (${login})`;
      };
      searchTextFromUser = (user) => {
        return user.login || "";
      };
      dataTableRowClass = () => {
        return this.rowClass;
      };
      flashRowClass = (className) => {
        this.rowClass = className;
        setTimeout(() => this.rowClass = void 0);
      };
      exportUserInformation = () => {
        if (this.allGroupUsers.length > 0) {
          const rows = this.allGroupUsers.map((user) => {
            const data = {};
            data[NAME_KEY] = user.name?.trim() ?? "";
            data[USERNAME_KEY] = user.login?.trim() ?? "";
            data[EMAIL_KEY] = user.email?.trim() ?? "";
            data[REGISTRATION_NUMBER_KEY] = user.visibleRegistrationNumber?.trim() ?? "";
            return data;
          });
          const keys = [NAME_KEY, USERNAME_KEY, EMAIL_KEY, REGISTRATION_NUMBER_KEY];
          this.exportAsCsv(rows, keys);
        }
      };
      exportAsCsv = (rows, keys) => {
        const options = {
          fieldSeparator: ";",
          quoteStrings: '"',
          showLabels: true,
          showTitle: false,
          filename: this.exportFileName,
          useTextFile: false,
          useBom: true,
          headers: keys
        };
        const csvExporter = new ExportToCsv(options);
        csvExporter.generateCsv(rows);
      };
      static \u0275fac = function CourseGroupComponent_Factory(t) {
        return new (t || _CourseGroupComponent)();
      };
      static \u0275cmp = i04.\u0275\u0275defineComponent({ type: _CourseGroupComponent, selectors: [["jhi-course-group"]], viewQuery: function CourseGroupComponent_Query(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275viewQuery(DataTableComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i04.\u0275\u0275queryRefresh(_t = i04.\u0275\u0275loadQuery()) && (ctx.dataTable = _t.first);
        }
      }, inputs: { allGroupUsers: "allGroupUsers", isLoadingAllGroupUsers: "isLoadingAllGroupUsers", isAdmin: "isAdmin", course: "course", tutorialGroup: "tutorialGroup", courseGroup: "courseGroup", exportFileName: "exportFileName", userSearch: "userSearch", addUserToGroup: "addUserToGroup", removeUserFromGroup: "removeUserFromGroup", handleUsersSizeChange: "handleUsersSizeChange" }, outputs: { importFinish: "importFinish" }, ngContentSelectors: _c12, decls: 22, vars: 14, consts: [[1, "d-flex", "flex-wrap", "justify-content-between", "align-items-center", "mb-1"], [1, "mb-1"], [1, "d-flex", "mt-1", "mb-1", "gap-1"], ["id", "registered-students", "entityType", "user", "entitiesPerPageTranslation", "artemisApp.course.courseGroup.usersPerPage", "showAllEntitiesTranslation", "artemisApp.course.courseGroup.showAllUsers", "searchNoResultsTranslation", "artemisApp.course.courseGroup.searchNoResults", "searchPlaceholderTranslation", "artemisApp.course.courseGroup.searchForUsers", 3, "isLoading", "isSearching", "searchFailed", "searchNoResults", "isTransitioning", "allEntities", "searchFields", "searchTextFromEntity", "searchResultFormatter", "onSearchWrapper", "onAutocompleteSelectWrapper", "entitiesSizeChange"], [3, "courseId", "courseGroup", "tutorialGroup", "finish"], [1, "btn", "btn-primary", "btn-sm", 3, "click"], [3, "icon", "fixedWidth"], ["jhiTranslate", "artemisApp.instructorDashboard.exportCSV"], [1, "bootstrap", 3, "limit", "sortType", "columnMode", "headerHeight", "footerHeight", "rowHeight", "rows", "rowClass", "scrollbarH"], ["prop", "", 3, "minWidth", "width", "maxWidth"], ["ngx-datatable-header-template", ""], ["ngx-datatable-cell-template", ""], ["prop", "login", 3, "minWidth", "width", "maxWidth"], ["prop", "visibleRegistrationNumber", 3, "minWidth", "width", "maxWidth"], ["prop", "name", 3, "minWidth", "width", "maxWidth"], ["prop", "email", 3, "minWidth", "width"], ["prop", "", 3, "minWidth", "width"], [1, "datatable-header-cell-wrapper", 3, "click"], ["jhiTranslate", "global.field.id", 1, "datatable-header-cell-label", "bold", "sortable"], [3, "icon"], [3, "routerLink"], ["jhiTranslate", "artemisApp.course.courseGroup.login", 1, "datatable-header-cell-label", "bold", "sortable"], ["jhiTranslate", "artemisApp.course.courseGroup.registrationNumber", 1, "datatable-header-cell-label", "bold", "sortable"], ["jhiTranslate", "artemisApp.course.courseGroup.name", 1, "datatable-header-cell-label", "bold", "sortable"], ["jhiTranslate", "artemisApp.course.courseGroup.email", 1, "datatable-header-cell-label", "bold", "sortable"], [1, "w-100", "text-end"], ["jhiDeleteButton", "", "deleteQuestion", "artemisApp.course.courseGroup.removeFromGroup.modalQuestion", 3, "actionType", "entityTitle", "dialogError", "delete"], [1, "me-1", 3, "icon"]], template: function CourseGroupComponent_Template(rf, ctx) {
        if (rf & 1) {
          i04.\u0275\u0275projectionDef();
          i04.\u0275\u0275elementStart(0, "div");
          i04.\u0275\u0275text(1, "\n    ");
          i04.\u0275\u0275elementStart(2, "div", 0);
          i04.\u0275\u0275text(3, "\n        ");
          i04.\u0275\u0275elementStart(4, "h2", 1);
          i04.\u0275\u0275text(5, "\n            ");
          i04.\u0275\u0275text(6, "\n            ");
          i04.\u0275\u0275projection(7);
          i04.\u0275\u0275text(8, "\n        ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(9, "\n        ");
          i04.\u0275\u0275elementStart(10, "div", 2);
          i04.\u0275\u0275text(11, "\n            ");
          i04.\u0275\u0275template(12, CourseGroupComponent_Conditional_12_Template, 3, 3)(13, CourseGroupComponent_Conditional_13_Template, 9, 2);
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(14, "\n    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(15, "\n    ");
          i04.\u0275\u0275elementStart(16, "jhi-data-table", 3);
          i04.\u0275\u0275listener("entitiesSizeChange", function CourseGroupComponent_Template_jhi_data_table_entitiesSizeChange_16_listener($event) {
            return ctx.handleUsersSizeChange($event);
          });
          i04.\u0275\u0275text(17, "\n        ");
          i04.\u0275\u0275template(18, CourseGroupComponent_ng_template_18_Template, 46, 25, "ng-template");
          i04.\u0275\u0275text(19, "\n    ");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(20, "\n");
          i04.\u0275\u0275elementEnd();
          i04.\u0275\u0275text(21, "\n");
        }
        if (rf & 2) {
          i04.\u0275\u0275advance(12);
          i04.\u0275\u0275conditional(12, (ctx.course == null ? null : ctx.course.isAtLeastInstructor) ? 12 : -1);
          i04.\u0275\u0275advance(1);
          i04.\u0275\u0275conditional(13, (ctx.course == null ? null : ctx.course.isAtLeastInstructor) && ctx.allGroupUsers.length > 0 ? 13 : -1);
          i04.\u0275\u0275advance(3);
          i04.\u0275\u0275property("isLoading", ctx.isLoadingAllGroupUsers)("isSearching", ctx.isSearching)("searchFailed", ctx.searchFailed)("searchNoResults", ctx.searchNoResults)("isTransitioning", ctx.isTransitioning)("allEntities", ctx.allGroupUsers)("searchFields", i04.\u0275\u0275pureFunction0(13, _c02))("searchTextFromEntity", ctx.searchTextFromUser)("searchResultFormatter", ctx.searchResultFormatter)("onSearchWrapper", ctx.searchAllUsers)("onAutocompleteSelectWrapper", ctx.onAutocompleteSelect);
        }
      }, dependencies: [DataTableComponent, UsersImportButtonComponent, i32.DatatableComponent, i32.DataTableColumnDirective, i32.DataTableColumnHeaderDirective, i32.DataTableColumnCellDirective, i4.FaIconComponent, TranslateDirective, DeleteButtonDirective, i7.RouterLink], styles: ["/* src/main/webapp/app/shared/course-group/course-group.component.scss */\njhi-course-group ngb-typeahead-window {\n  min-width: 400px;\n}\njhi-course-group ngb-typeahead-window .dropdown-item {\n  display: flex;\n  justify-content: space-between;\n}\njhi-course-group ngb-typeahead-window .dropdown-item.active {\n  background-color: #28a745;\n}\njhi-course-group ngb-typeahead-window .dropdown-item.already-member {\n  color: #212529;\n  background-color: #e9f6ec;\n  opacity: 0.5;\n}\njhi-course-group ngb-typeahead-window .dropdown-item.already-member.active {\n  background-color: #daf2e0;\n  opacity: 0.8;\n}\njhi-course-group .datatable-body-row.newly-added-member {\n  animation-name: flash-animation;\n  animation-delay: 150ms;\n  animation-duration: 1.5s;\n  animation-timing-function: ease-out;\n}\n@keyframes flash-animation {\n  30% {\n    background-color: #c4e7cc;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvY291cnNlLWdyb3VwL2NvdXJzZS1ncm91cC5jb21wb25lbnQuc2NzcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLy8gb25seSBwbGFjZSBkZWNsYXJhdGlvbnMgd2l0aGluIHRoaXMgbWFudWFsIHNjb3BlIChvdGhlcndpc2Ugb3RoZXIgY29tcG9uZW50cyBjb3VsZCBiZSBhZmZlY3RlZClcbmpoaS1jb3Vyc2UtZ3JvdXAge1xuICAgICRkcm9wZG93bi1pdGVtOiAoXG4gICAgICAgIGFjdGl2ZS1jb2xvcjogIzI4YTc0NSxcbiAgICAgICAgYWxyZWFkeS1tZW1iZXI6IChcbiAgICAgICAgICAgIGNvbG9yOiAjMjEyNTI5LFxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2U5ZjZlYyxcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3ItaG92ZXI6ICNkYWYyZTAsXG4gICAgICAgICksXG4gICAgKTtcblxuICAgICRkYXRhdGFibGUtcm93OiAoXG4gICAgICAgIG5ld2x5LWFkZGVkLW1lbWJlcjogKFxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2M0ZTdjYyxcbiAgICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMTUwbXMsXG4gICAgICAgICAgICBhbmltYXRpb24tZHVyYXRpb246IDEuNXMsXG4gICAgICAgICksXG4gICAgKTtcblxuICAgIG5nYi10eXBlYWhlYWQtd2luZG93IHtcbiAgICAgICAgbWluLXdpZHRoOiA0MDBweDtcblxuICAgICAgICAuZHJvcGRvd24taXRlbSB7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXG4gICAgICAgICAgICAmLmFjdGl2ZSB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogbWFwLWdldCgkZHJvcGRvd24taXRlbSwgYWN0aXZlLWNvbG9yKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgJi5hbHJlYWR5LW1lbWJlciB7XG4gICAgICAgICAgICAgICAgJHZhcnM6IG1hcC1nZXQoJGRyb3Bkb3duLWl0ZW0sIGFscmVhZHktbWVtYmVyKTtcblxuICAgICAgICAgICAgICAgIGNvbG9yOiBtYXAtZ2V0KCR2YXJzLCBjb2xvcik7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogbWFwLWdldCgkdmFycywgYmFja2dyb3VuZC1jb2xvcik7XG4gICAgICAgICAgICAgICAgb3BhY2l0eTogMC41O1xuXG4gICAgICAgICAgICAgICAgJi5hY3RpdmUge1xuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBtYXAtZ2V0KCR2YXJzLCBiYWNrZ3JvdW5kLWNvbG9yLWhvdmVyKTtcbiAgICAgICAgICAgICAgICAgICAgb3BhY2l0eTogMC44O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5kYXRhdGFibGUtYm9keS1yb3cge1xuICAgICAgICAmLm5ld2x5LWFkZGVkLW1lbWJlciB7XG4gICAgICAgICAgICAkdmFyczogbWFwLWdldCgkZGF0YXRhYmxlLXJvdywgbmV3bHktYWRkZWQtbWVtYmVyKTtcblxuICAgICAgICAgICAgQGtleWZyYW1lcyBmbGFzaC1hbmltYXRpb24ge1xuICAgICAgICAgICAgICAgIDMwJSB7XG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IG1hcC1nZXQoJHZhcnMsIGJhY2tncm91bmQtY29sb3IpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgYW5pbWF0aW9uLW5hbWU6IGZsYXNoLWFuaW1hdGlvbjtcbiAgICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogbWFwLWdldCgkdmFycywgYW5pbWF0aW9uLWRlbGF5KTtcbiAgICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogbWFwLWdldCgkdmFycywgYW5pbWF0aW9uLWR1cmF0aW9uKTtcbiAgICAgICAgICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2Utb3V0O1xuICAgICAgICB9XG4gICAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQW1CSSxpQkFBQTtBQUNJLGFBQUE7O0FBRUEsaUJBQUEscUJBQUEsQ0FBQTtBQUNJLFdBQUE7QUFDQSxtQkFBQTs7QUFFQSxpQkFBQSxxQkFBQSxDQUpKLGFBSUksQ0FBQTtBQUNJLG9CQUFBOztBQUdKLGlCQUFBLHFCQUFBLENBUkosYUFRSSxDQUFBO0FBR0ksU0FBQTtBQUNBLG9CQUFBO0FBQ0EsV0FBQTs7QUFFQSxpQkFBQSxxQkFBQSxDQWZSLGFBZVEsQ0FQSixjQU9JLENBWEo7QUFZUSxvQkFBQTtBQUNBLFdBQUE7O0FBT1osaUJBQUEsQ0FBQSxrQkFBQSxDQUFBO0FBU0ksa0JBQUE7QUFDQSxtQkFBQTtBQUNBLHNCQUFBO0FBQ0EsNkJBQUE7O0FBVEEsV0FNQTtBQUxJO0FBQ0ksc0JBQUE7OzsiLAogICJuYW1lcyI6IFtdCn0K */\n"], encapsulation: 2 });
    };
    (() => {
      (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(CourseGroupComponent, { className: "CourseGroupComponent" });
    })();
  }
});

// src/main/webapp/app/shared/course-group/course-group.module.ts
import { NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgxDatatableModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@flaviosantoro92_ngx-datatable.js?v=1d0d9ead";
import { RouterModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ArtemisCourseGroupModule;
var init_course_group_module = __esm({
  "src/main/webapp/app/shared/course-group/course-group.module.ts"() {
    init_course_group_component();
    init_data_table_module();
    init_user_import_module();
    init_shared_module();
    ArtemisCourseGroupModule = class _ArtemisCourseGroupModule {
      static \u0275fac = function ArtemisCourseGroupModule_Factory(t) {
        return new (t || _ArtemisCourseGroupModule)();
      };
      static \u0275mod = i05.\u0275\u0275defineNgModule({ type: _ArtemisCourseGroupModule });
      static \u0275inj = i05.\u0275\u0275defineInjector({ imports: [ArtemisDataTableModule, UserImportModule, NgxDatatableModule, ArtemisSharedModule, RouterModule] });
    };
  }
});

export {
  CourseGroupComponent,
  init_course_group_component,
  TutorialGroupsChecklistComponent,
  init_tutorial_groups_checklist_component,
  TutorialGroupsConfigurationFormComponent,
  init_tutorial_groups_configuration_form_component,
  CreateTutorialGroupsConfigurationComponent,
  init_create_tutorial_groups_configuration_component,
  ArtemisCourseGroupModule,
  init_course_group_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL3R1dG9yaWFsLWdyb3Vwcy90dXRvcmlhbC1ncm91cHMtbWFuYWdlbWVudC90dXRvcmlhbC1ncm91cHMtY2hlY2tsaXN0L3R1dG9yaWFsLWdyb3Vwcy1jaGVja2xpc3QuY29tcG9uZW50LnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3Vyc2UvdHV0b3JpYWwtZ3JvdXBzL3R1dG9yaWFsLWdyb3Vwcy1tYW5hZ2VtZW50L3R1dG9yaWFsLWdyb3Vwcy1jaGVja2xpc3QvdHV0b3JpYWwtZ3JvdXBzLWNoZWNrbGlzdC5jb21wb25lbnQuaHRtbCIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL3R1dG9yaWFsLWdyb3Vwcy90dXRvcmlhbC1ncm91cHMtbWFuYWdlbWVudC90dXRvcmlhbC1ncm91cHMtY29uZmlndXJhdGlvbi9jcnVkL3R1dG9yaWFsLWdyb3Vwcy1jb25maWd1cmF0aW9uLWZvcm0vdHV0b3JpYWwtZ3JvdXBzLWNvbmZpZ3VyYXRpb24tZm9ybS5jb21wb25lbnQudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS90dXRvcmlhbC1ncm91cHMvdHV0b3JpYWwtZ3JvdXBzLW1hbmFnZW1lbnQvdHV0b3JpYWwtZ3JvdXBzLWNvbmZpZ3VyYXRpb24vY3J1ZC90dXRvcmlhbC1ncm91cHMtY29uZmlndXJhdGlvbi1mb3JtL3R1dG9yaWFsLWdyb3Vwcy1jb25maWd1cmF0aW9uLWZvcm0uY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvdXJzZS90dXRvcmlhbC1ncm91cHMvdHV0b3JpYWwtZ3JvdXBzLW1hbmFnZW1lbnQvdHV0b3JpYWwtZ3JvdXBzLWNvbmZpZ3VyYXRpb24vY3J1ZC9jcmVhdGUtdHV0b3JpYWwtZ3JvdXBzLWNvbmZpZ3VyYXRpb24vY3JlYXRlLXR1dG9yaWFsLWdyb3Vwcy1jb25maWd1cmF0aW9uLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvY291cnNlL3R1dG9yaWFsLWdyb3Vwcy90dXRvcmlhbC1ncm91cHMtbWFuYWdlbWVudC90dXRvcmlhbC1ncm91cHMtY29uZmlndXJhdGlvbi9jcnVkL2NyZWF0ZS10dXRvcmlhbC1ncm91cHMtY29uZmlndXJhdGlvbi9jcmVhdGUtdHV0b3JpYWwtZ3JvdXBzLWNvbmZpZ3VyYXRpb24uY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9jb3Vyc2UtZ3JvdXAvY291cnNlLWdyb3VwLmNvbXBvbmVudC50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2NvdXJzZS1ncm91cC9jb3Vyc2UtZ3JvdXAuY29tcG9uZW50Lmh0bWwiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL3NoYXJlZC9jb3Vyc2UtZ3JvdXAvY291cnNlLWdyb3VwLm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSwgQ2hhbmdlRGV0ZWN0b3JSZWYsIENvbXBvbmVudCwgT25EZXN0cm95LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IENvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvdXJzZS9tYW5hZ2UvY291cnNlLW1hbmFnZW1lbnQuc2VydmljZSc7XG5pbXBvcnQgeyBDb3Vyc2UgfSBmcm9tICdhcHAvZW50aXRpZXMvY291cnNlLm1vZGVsJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5pbXBvcnQgeyBvbkVycm9yIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2dsb2JhbC51dGlscyc7XG5pbXBvcnQgeyBTdWJqZWN0LCBjb21iaW5lTGF0ZXN0LCBmaW5hbGl6ZSwgc3dpdGNoTWFwLCB0YWtlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IGZhUGx1cywgZmFXcmVuY2ggfSBmcm9tICdAZm9ydGF3ZXNvbWUvZnJlZS1zb2xpZC1zdmctaWNvbnMnO1xuaW1wb3J0IHsgVHV0b3JpYWxHcm91cHNDb25maWd1cmF0aW9uU2VydmljZSB9IGZyb20gJ2FwcC9jb3Vyc2UvdHV0b3JpYWwtZ3JvdXBzL3NlcnZpY2VzL3R1dG9yaWFsLWdyb3Vwcy1jb25maWd1cmF0aW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgdGFrZVVudGlsIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS10dXRvcmlhbC1ncm91cHMtY2hlY2tsaXN0JyxcbiAgICB0ZW1wbGF0ZVVybDogJy4vdHV0b3JpYWwtZ3JvdXBzLWNoZWNrbGlzdC5jb21wb25lbnQuaHRtbCcsXG4gICAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIFR1dG9yaWFsR3JvdXBzQ2hlY2tsaXN0Q29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xuICAgIGlzTG9hZGluZyA9IGZhbHNlO1xuICAgIGNvdXJzZTogQ291cnNlO1xuICAgIGlzVGltZVpvbmVDb25maWd1cmVkID0gZmFsc2U7XG4gICAgaXNUdXRvcmlhbEdyb3VwQ29uZmlndXJhdGlvbkNyZWF0ZWQgPSBmYWxzZTtcblxuICAgIGZhV3JlbmNoID0gZmFXcmVuY2g7XG4gICAgZmFQbHVzID0gZmFQbHVzO1xuXG4gICAgbmdVbnN1YnNjcmliZSA9IG5ldyBTdWJqZWN0PHZvaWQ+KCk7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgYWN0aXZhdGVkUm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgICAgICBwcml2YXRlIGNvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlOiBDb3Vyc2VNYW5hZ2VtZW50U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBhbGVydFNlcnZpY2U6IEFsZXJ0U2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSB0dXRvcmlhbEdyb3Vwc0NvbmZpZ3VyYXRpb25TZXJ2aWNlOiBUdXRvcmlhbEdyb3Vwc0NvbmZpZ3VyYXRpb25TZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGNkcjogQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gICAgKSB7fVxuXG4gICAgZ2V0IGlzRnVsbHlDb25maWd1cmVkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5pc1RpbWVab25lQ29uZmlndXJlZCAmJiB0aGlzLmlzVHV0b3JpYWxHcm91cENvbmZpZ3VyYXRpb25DcmVhdGVkO1xuICAgIH1cblxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICB0aGlzLmlzTG9hZGluZyA9IHRydWU7XG4gICAgICAgIHRoaXMuYWN0aXZhdGVkUm91dGUucGFyYW1NYXBcbiAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgIHRha2UoMSksXG4gICAgICAgICAgICAgICAgc3dpdGNoTWFwKChwYXJhbXMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY291cnNlSWQgPSBOdW1iZXIocGFyYW1zLmdldCgnY291cnNlSWQnKSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjb21iaW5lTGF0ZXN0KFt0aGlzLmNvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlLmZpbmQoY291cnNlSWQpLCB0aGlzLnR1dG9yaWFsR3JvdXBzQ29uZmlndXJhdGlvblNlcnZpY2UuZ2V0T25lT2ZDb3Vyc2UoY291cnNlSWQpXSk7XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgZmluYWxpemUoKCkgPT4gKHRoaXMuaXNMb2FkaW5nID0gZmFsc2UpKSxcbiAgICAgICAgICAgICAgICB0YWtlVW50aWwodGhpcy5uZ1Vuc3Vic2NyaWJlKSxcbiAgICAgICAgICAgIClcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgICAgIG5leHQ6IChbY291cnNlUmVzdWx0LCBjb25maWd1cmF0aW9uUmVzdWx0XSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoY291cnNlUmVzdWx0LmJvZHkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY291cnNlID0gY291cnNlUmVzdWx0LmJvZHk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmlzVGltZVpvbmVDb25maWd1cmVkID0gISF0aGlzLmNvdXJzZS50aW1lWm9uZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoY29uZmlndXJhdGlvblJlc3VsdC5ib2R5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZS50dXRvcmlhbEdyb3Vwc0NvbmZpZ3VyYXRpb24gPSBjb25maWd1cmF0aW9uUmVzdWx0LmJvZHk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmlzVHV0b3JpYWxHcm91cENvbmZpZ3VyYXRpb25DcmVhdGVkID0gISF0aGlzLmNvdXJzZS50dXRvcmlhbEdyb3Vwc0NvbmZpZ3VyYXRpb247XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGVycm9yOiAocmVzOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4gb25FcnJvcih0aGlzLmFsZXJ0U2VydmljZSwgcmVzKSxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuYWRkKCgpID0+IHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKSk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgICAgIHRoaXMubmdVbnN1YnNjcmliZS5uZXh0KCk7XG4gICAgICAgIHRoaXMubmdVbnN1YnNjcmliZS5jb21wbGV0ZSgpO1xuICAgIH1cbn1cbiIsIjxqaGktbG9hZGluZy1pbmRpY2F0b3ItY29udGFpbmVyIFtpc0xvYWRpbmddPVwiaXNMb2FkaW5nXCI+XG4gICAgQGlmIChjb3Vyc2UpIHtcbiAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC0xMlwiPlxuICAgICAgICAgICAgICAgIDxoMT57eyAnYXJ0ZW1pc0FwcC5wYWdlcy5jaGVja2xpc3QudGl0bGUnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fTwvaDE+XG4gICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICAgIHt7ICdhcnRlbWlzQXBwLnBhZ2VzLmNoZWNrbGlzdC5leHBsYW5hdGlvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8aHIgLz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtMTJcIj5cbiAgICAgICAgICAgICAgICA8cD57eyAnYXJ0ZW1pc0FwcC5wYWdlcy5jaGVja2xpc3QudGltZVpvbmVFeHBsYW5hdGlvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9wPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxqaGktY2hlY2tsaXN0LWNoZWNrIGlkPVwidGltZVpvbmVcIiBbY2hlY2tBdHRyaWJ1dGVdPVwiaXNUaW1lWm9uZUNvbmZpZ3VyZWRcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJmb3JtLWNoZWNrLWxhYmVsIHBlLTRcIiBmb3I9XCJ0aW1lWm9uZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAucGFnZXMuY2hlY2tsaXN0LnRpbWVab25lJyB8IGFydGVtaXNUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWycvY291cnNlLW1hbmFnZW1lbnQnLCBjb3Vyc2UuaWQhLCAnZWRpdCddXCIgY2xhc3M9XCJidG4gYnRuLXdhcm5pbmcgYnRuLW1kIG15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImZhV3JlbmNoXCI+PC9mYS1pY29uPiZuYnNwOzxzcGFuPnt7ICdhcnRlbWlzQXBwLnBhZ2VzLmNoZWNrbGlzdC5lZGl0Q291cnNlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGhyIC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLTEyXCI+XG4gICAgICAgICAgICAgICAgPHA+e3sgJ2FydGVtaXNBcHAucGFnZXMuY2hlY2tsaXN0LmNvbmZpZ3VyYXRpb25FeHBsYW5hdGlvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9wPlxuICAgICAgICAgICAgICAgIDx0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGpoaS1jaGVja2xpc3QtY2hlY2sgaWQ9XCJjb25maWd1cmF0aW9uXCIgW2NoZWNrQXR0cmlidXRlXT1cImlzVHV0b3JpYWxHcm91cENvbmZpZ3VyYXRpb25DcmVhdGVkXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1jaGVjay1sYWJlbCBwZS00XCIgZm9yPVwiY29uZmlndXJhdGlvblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAucGFnZXMuY2hlY2tsaXN0LmNvbmZpZ3VyYXRpb24nIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICBAaWYgKGlzVHV0b3JpYWxHcm91cENvbmZpZ3VyYXRpb25DcmVhdGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtyb3V0ZXJMaW5rXT1cIlsnL2NvdXJzZS1tYW5hZ2VtZW50JywgY291cnNlLmlkISwgJ3R1dG9yaWFsLWdyb3VwcycsICdjb25maWd1cmF0aW9uJywgY291cnNlLnR1dG9yaWFsR3JvdXBzQ29uZmlndXJhdGlvbiEuaWQhLCAnZWRpdCddXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tbWQgbXktMlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmRpc2FibGVkXT1cIiFpc1RpbWVab25lQ29uZmlndXJlZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFQbHVzXCI+PC9mYS1pY29uPiZuYnNwOzxzcGFuPnt7ICdhcnRlbWlzQXBwLnBhZ2VzLnR1dG9yaWFsR3JvdXBzTWFuYWdlbWVudC5lZGl0Q29uZmlndXJhdGlvbkJ1dHRvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoIWlzVHV0b3JpYWxHcm91cENvbmZpZ3VyYXRpb25DcmVhdGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtyb3V0ZXJMaW5rXT1cIlsnL2NvdXJzZS1tYW5hZ2VtZW50JywgY291cnNlLmlkISwgJ2NyZWF0ZS10dXRvcmlhbC1ncm91cHMtY29uZmlndXJhdGlvbiddXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tbWQgbXktMlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmRpc2FibGVkXT1cIiFpc1RpbWVab25lQ29uZmlndXJlZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFQbHVzXCI+PC9mYS1pY29uPiZuYnNwOzxzcGFuPnt7ICdhcnRlbWlzQXBwLnBhZ2VzLmNoZWNrbGlzdC5jcmVhdGVDb25maWd1cmF0aW9uJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8aHIgLz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtMTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFtyb3V0ZXJMaW5rXT1cIlsnL2NvdXJzZS1tYW5hZ2VtZW50JywgY291cnNlLmlkISwgJ3R1dG9yaWFsLWdyb3VwcyddXCIgY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgYnRuLW1kIG15LTJcIiBbZGlzYWJsZWRdPVwiIWlzRnVsbHlDb25maWd1cmVkXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7ICdhcnRlbWlzQXBwLnBhZ2VzLmNoZWNrbGlzdC5jb250aW51ZVRvTWFuYWdlbWVudCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIH1cbjwvamhpLWxvYWRpbmctaW5kaWNhdG9yLWNvbnRhaW5lcj5cbiIsImltcG9ydCB7IENoYW5nZURldGVjdGlvblN0cmF0ZWd5LCBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uQ2hhbmdlcywgT25Jbml0LCBPdXRwdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZvcm1CdWlsZGVyLCBGb3JtR3JvdXAsIFZhbGlkYXRvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBmYUNhbGVuZGFyQWx0IH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IENvdXJzZSwgaXNNZXNzYWdpbmdFbmFibGVkIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvdXJzZS5tb2RlbCc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgVHV0b3JpYWxHcm91cHNDb25maWd1cmF0aW9uRm9ybURhdGEge1xuICAgIHBlcmlvZD86IERhdGVbXTtcbiAgICB1c2VQdWJsaWNUdXRvcmlhbEdyb3VwQ2hhbm5lbHM/OiBib29sZWFuO1xuICAgIHVzZVR1dG9yaWFsR3JvdXBDaGFubmVscz86IGJvb2xlYW47XG59XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLXR1dG9yaWFsLWdyb3Vwcy1jb25maWd1cmF0aW9uLWZvcm0nLFxuICAgIHRlbXBsYXRlVXJsOiAnLi90dXRvcmlhbC1ncm91cHMtY29uZmlndXJhdGlvbi1mb3JtLmNvbXBvbmVudC5odG1sJyxcbiAgICBzdHlsZVVybHM6IFsnLi90dXRvcmlhbC1ncm91cHMtY29uZmlndXJhdGlvbi1mb3JtLmNvbXBvbmVudC5zY3NzJ10sXG4gICAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIFR1dG9yaWFsR3JvdXBzQ29uZmlndXJhdGlvbkZvcm1Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcyB7XG4gICAgQElucHV0KClcbiAgICBmb3JtRGF0YTogVHV0b3JpYWxHcm91cHNDb25maWd1cmF0aW9uRm9ybURhdGEgPSB7XG4gICAgICAgIHBlcmlvZDogdW5kZWZpbmVkLFxuICAgICAgICB1c2VQdWJsaWNUdXRvcmlhbEdyb3VwQ2hhbm5lbHM6IGZhbHNlLFxuICAgICAgICB1c2VUdXRvcmlhbEdyb3VwQ2hhbm5lbHM6IGZhbHNlLFxuICAgIH07XG4gICAgQElucHV0KCkgaXNFZGl0TW9kZSA9IGZhbHNlO1xuICAgIEBPdXRwdXQoKSBmb3JtU3VibWl0dGVkOiBFdmVudEVtaXR0ZXI8VHV0b3JpYWxHcm91cHNDb25maWd1cmF0aW9uRm9ybURhdGE+ID0gbmV3IEV2ZW50RW1pdHRlcjxUdXRvcmlhbEdyb3Vwc0NvbmZpZ3VyYXRpb25Gb3JtRGF0YT4oKTtcblxuICAgIEBJbnB1dCgpXG4gICAgY291cnNlOiBDb3Vyc2U7XG5cbiAgICBmYUNhbGVuZGFyQWx0ID0gZmFDYWxlbmRhckFsdDtcblxuICAgIHJlYWRvbmx5IGlzTWVzc2FnaW5nRW5hYmxlZCA9IGlzTWVzc2FnaW5nRW5hYmxlZDtcblxuICAgIGV4aXN0aW5nQ2hhbm5lbFNldHRpbmc/OiBib29sZWFuO1xuXG4gICAgZm9ybTogRm9ybUdyb3VwO1xuXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBmYjogRm9ybUJ1aWxkZXIpIHt9XG5cbiAgICBnZXQgcGVyaW9kQ29udHJvbCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZm9ybS5nZXQoJ3BlcmlvZCcpO1xuICAgIH1cblxuICAgIGdldCB1c2VUdXRvcmlhbEdyb3VwQ2hhbm5lbHNDb250cm9sKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5mb3JtLmdldCgndXNlVHV0b3JpYWxHcm91cENoYW5uZWxzJyk7XG4gICAgfVxuXG4gICAgZ2V0IHVzZVB1YmxpY1R1dG9yaWFsR3JvdXBDaGFubmVsc0NvbnRyb2woKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmZvcm0uZ2V0KCd1c2VQdWJsaWNUdXRvcmlhbEdyb3VwQ2hhbm5lbHMnKTtcbiAgICB9XG5cbiAgICBnZXQgaXNTdWJtaXRQb3NzaWJsZSgpIHtcbiAgICAgICAgcmV0dXJuICF0aGlzLmZvcm0uaW52YWxpZDtcbiAgICB9XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5pbml0aWFsaXplRm9ybSgpO1xuICAgIH1cbiAgICBuZ09uQ2hhbmdlcygpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5pbml0aWFsaXplRm9ybSgpO1xuICAgICAgICBpZiAodGhpcy5pc0VkaXRNb2RlICYmIHRoaXMuZm9ybURhdGEpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0Rm9ybVZhbHVlcyh0aGlzLmZvcm1EYXRhKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBwcml2YXRlIHNldEZvcm1WYWx1ZXMoZm9ybURhdGE6IFR1dG9yaWFsR3JvdXBzQ29uZmlndXJhdGlvbkZvcm1EYXRhKSB7XG4gICAgICAgIHRoaXMuZXhpc3RpbmdDaGFubmVsU2V0dGluZyA9IGZvcm1EYXRhLnVzZVR1dG9yaWFsR3JvdXBDaGFubmVscztcbiAgICAgICAgdGhpcy5mb3JtLnBhdGNoVmFsdWUoZm9ybURhdGEpO1xuICAgIH1cblxuICAgIGdldCBzaG93Q2hhbm5lbERlbGV0aW9uV2FybmluZygpIHtcbiAgICAgICAgaWYgKCF0aGlzLmlzRWRpdE1vZGUpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5leGlzdGluZ0NoYW5uZWxTZXR0aW5nID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5leGlzdGluZ0NoYW5uZWxTZXR0aW5nICYmIHRoaXMudXNlVHV0b3JpYWxHcm91cENoYW5uZWxzQ29udHJvbD8udmFsdWUgPT09IGZhbHNlO1xuICAgIH1cblxuICAgIHByaXZhdGUgaW5pdGlhbGl6ZUZvcm0oKSB7XG4gICAgICAgIGlmICh0aGlzLmZvcm0pIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuZm9ybSA9IHRoaXMuZmIuZ3JvdXAoe1xuICAgICAgICAgICAgcGVyaW9kOiBbdW5kZWZpbmVkLCBWYWxpZGF0b3JzLnJlcXVpcmVkXSxcbiAgICAgICAgICAgIHVzZVR1dG9yaWFsR3JvdXBDaGFubmVsczogW2ZhbHNlXSxcbiAgICAgICAgICAgIHVzZVB1YmxpY1R1dG9yaWFsR3JvdXBDaGFubmVsczogW2ZhbHNlXSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgc3VibWl0Rm9ybSgpIHtcbiAgICAgICAgdGhpcy5mb3JtU3VibWl0dGVkLmVtaXQoeyAuLi50aGlzLmZvcm0udmFsdWUgfSk7XG4gICAgfVxuXG4gICAgZ2V0IGlzUGVyaW9kSW52YWxpZCgpIHtcbiAgICAgICAgaWYgKHRoaXMucGVyaW9kQ29udHJvbCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMucGVyaW9kQ29udHJvbC5pbnZhbGlkICYmICh0aGlzLnBlcmlvZENvbnRyb2wudG91Y2hlZCB8fCB0aGlzLnBlcmlvZENvbnRyb2wuZGlydHkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbWFya1BlcmlvZEFzVG91Y2hlZCgpIHtcbiAgICAgICAgaWYgKHRoaXMucGVyaW9kQ29udHJvbCkge1xuICAgICAgICAgICAgdGhpcy5wZXJpb2RDb250cm9sLm1hcmtBc1RvdWNoZWQoKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJyb3dcIj5cbiAgICA8ZGl2IGNsYXNzPVwiY29sLTEyXCI+XG4gICAgICAgIEBpZiAoZm9ybSkge1xuICAgICAgICAgICAgPGZvcm0gY2xhc3M9XCJyb3dcIiBbZm9ybUdyb3VwXT1cImZvcm1cIiAobmdTdWJtaXQpPVwic3VibWl0Rm9ybSgpXCI+XG4gICAgICAgICAgICAgICAgPCEtLSBQZXJpb2QgLS0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImZvcm0tbGFiZWxcIiBmb3I9XCJwZXJpb2RcIj57eyAnYXJ0ZW1pc0FwcC5mb3Jtcy5jb25maWd1cmF0aW9uRm9ybS5wZXJpb2RJbnB1dC5sYWJlbCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImlucHV0LWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGVyaW9kXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBlcmlvZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuaXMtaW52YWxpZF09XCJpc1BlcmlvZEludmFsaWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChmb2N1cyk9XCJtYXJrUGVyaW9kQXNUb3VjaGVkKClcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt2YWx1ZV09XCJwZXJpb2RDb250cm9sPy52YWx1ZSB8IGFydGVtaXNEYXRlUmFuZ2U6ICdsb25nLWRhdGUnIDogdW5kZWZpbmVkIDogdHJ1ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW293bERhdGVUaW1lVHJpZ2dlcl09XCJwZXJpb2RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRvbmx5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBmb3JtQ29udHJvbE5hbWU9XCJwZXJpb2RcIiBbb3dsRGF0ZVRpbWVdPVwicGVyaW9kXCIgY2xhc3M9XCJkYXRlLXRpbWUtcGlja2VyLWFuY2hvclwiIFtzZWxlY3RNb2RlXT1cIidyYW5nZSdcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeVwiIFtvd2xEYXRlVGltZVRyaWdnZXJdPVwicGVyaW9kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFDYWxlbmRhckFsdFwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG93bC1kYXRlLXRpbWUgW2ZpcnN0RGF5T2ZXZWVrXT1cIjFcIiBbcGlja2VyVHlwZV09XCInY2FsZW5kYXInXCIgI3BlcmlvZD48L293bC1kYXRlLXRpbWU+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS10ZXh0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5mb3Jtcy5jb25maWd1cmF0aW9uRm9ybS5wZXJpb2RJbnB1dC5leHBsYW5hdGlvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICBAaWYgKHBlcmlvZENvbnRyb2w/LmludmFsaWQgJiYgKHBlcmlvZENvbnRyb2w/LmRpcnR5IHx8IHBlcmlvZENvbnRyb2w/LnRvdWNoZWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWxlcnQgYWxlcnQtZGFuZ2VyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChwZXJpb2RDb250cm9sPy5lcnJvcnM/Lm93bFJlcXVpcmVkRGF0ZVRpbWVSYW5nZSB8fCBwZXJpb2RDb250cm9sPy5lcnJvcnM/LnJlcXVpcmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAnYXJ0ZW1pc0FwcC5mb3Jtcy5jb25maWd1cmF0aW9uRm9ybS5wZXJpb2RJbnB1dC5yZXF1aXJlZFZhbGlkYXRpb25FcnJvcicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHBlcmlvZENvbnRyb2w/LmVycm9ycz8ub3dsRGF0ZVRpbWVQYXJzZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuZm9ybXMuY29uZmlndXJhdGlvbkZvcm0ucGVyaW9kSW5wdXQucGFyc2VFcnJvcicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHBlcmlvZENvbnRyb2w/LmVycm9ycz8ub3dsRGF0ZVRpbWVSYW5nZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuZm9ybXMuY29uZmlndXJhdGlvbkZvcm0ucGVyaW9kSW5wdXQuaW52YWxpZFJhbmdlRXJyb3InIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8IS0tIERvIG5vdCBzaG93IG9wdGlvbnMgaWYgdGhlIGNvdXJzZSBoYXMgY29tbXVuaWNhdGlvbiBkaXNhYmxlZCAtLT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBbaGlkZGVuXT1cIiFpc01lc3NhZ2luZ0VuYWJsZWQoY291cnNlKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tY2hlY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgY2xhc3M9XCJmb3JtLWNoZWNrLWlucHV0XCIgdHlwZT1cImNoZWNrYm94XCIgZm9ybUNvbnRyb2xOYW1lPVwidXNlVHV0b3JpYWxHcm91cENoYW5uZWxzXCIgaWQ9XCJ1c2VUdXRvcmlhbEdyb3VwQ2hhbm5lbHNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImZvcm0tY2hlY2stbGFiZWxcIiBmb3I9XCJ1c2VUdXRvcmlhbEdyb3VwQ2hhbm5lbHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuZm9ybXMuY29uZmlndXJhdGlvbkZvcm0udXNlVHV0b3JpYWxHcm91cENoYW5uZWxzSW5wdXQubGFiZWwnIHwgYXJ0ZW1pc1RyYW5zbGF0ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNtYWxsIGlkPVwiY2hhbm5lbEhlbHBcIiBjbGFzcz1cImZvcm0tdGV4dCB0ZXh0LWJvZHktc2Vjb25kYXJ5IGQtYmxvY2tcIj57e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnYXJ0ZW1pc0FwcC5mb3Jtcy5jb25maWd1cmF0aW9uRm9ybS51c2VUdXRvcmlhbEdyb3VwQ2hhbm5lbHNJbnB1dC5leHBsYW5hdGlvbicgfCBhcnRlbWlzVHJhbnNsYXRlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX08L3NtYWxsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc2hvd0NoYW5uZWxEZWxldGlvbldhcm5pbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFsZXJ0IGFsZXJ0LWRhbmdlclwiIHJvbGU9XCJhbGVydFwiIGlkPVwiY2hhbm5lbERlbGV0aW9uV2FybmluZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgJ2FydGVtaXNBcHAuZm9ybXMuY29uZmlndXJhdGlvbkZvcm0udXNlVHV0b3JpYWxHcm91cENoYW5uZWxzSW5wdXQuY2hhbm5lbERlbGV0aW9uV2FybmluZycgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPCEtLVB1YmxpYyBDaGFubmVsIC8gUHJpdmF0ZSBDaGFubmVsIC0tPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIiBbaGlkZGVuXT1cIiF1c2VUdXRvcmlhbEdyb3VwQ2hhbm5lbHNDb250cm9sPy52YWx1ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImQtYmxvY2tcIj57eyAnYXJ0ZW1pc0FwcC5kaWFsb2dzLmNyZWF0ZUNoYW5uZWwuY2hhbm5lbEZvcm0uaXNQdWJsaWNJbnB1dC5sYWJlbCcgfCBhcnRlbWlzVHJhbnNsYXRlIH19PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYnRuLWdyb3VwXCIgcm9sZT1cImdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBmb3JtQ29udHJvbE5hbWU9XCJ1c2VQdWJsaWNUdXRvcmlhbEdyb3VwQ2hhbm5lbHNcIiB0eXBlPVwicmFkaW9cIiBjbGFzcz1cImJ0bi1jaGVja1wiIGlkPVwicHVibGljXCIgYXV0b2NvbXBsZXRlPVwib2ZmXCIgY2hlY2tlZCBbdmFsdWVdPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1zZWNvbmRhcnlcIiBmb3I9XCJwdWJsaWNcIj57e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2FydGVtaXNBcHAuZGlhbG9ncy5jcmVhdGVDaGFubmVsLmNoYW5uZWxGb3JtLmlzUHVibGljSW5wdXQucHVibGljJyB8IGFydGVtaXNUcmFuc2xhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgZm9ybUNvbnRyb2xOYW1lPVwidXNlUHVibGljVHV0b3JpYWxHcm91cENoYW5uZWxzXCIgdHlwZT1cInJhZGlvXCIgY2xhc3M9XCJidG4tY2hlY2tcIiBpZD1cInByaXZhdGVcIiBhdXRvY29tcGxldGU9XCJvZmZcIiBbdmFsdWVdPVwiZmFsc2VcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJidG4gYnRuLW91dGxpbmUtc2Vjb25kYXJ5XCIgZm9yPVwicHJpdmF0ZVwiPnt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnYXJ0ZW1pc0FwcC5kaWFsb2dzLmNyZWF0ZUNoYW5uZWwuY2hhbm5lbEZvcm0uaXNQdWJsaWNJbnB1dC5wcml2YXRlJyB8IGFydGVtaXNUcmFuc2xhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzbWFsbCBpZD1cImlzUHVibGljSGVscFwiIGNsYXNzPVwiZm9ybS10ZXh0IHRleHQtYm9keS1zZWNvbmRhcnkgZC1ibG9ja1wiPnt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdhcnRlbWlzQXBwLmRpYWxvZ3MuY3JlYXRlQ2hhbm5lbC5jaGFubmVsRm9ybS5pc1B1YmxpY0lucHV0LmV4cGxhbmF0aW9uJyB8IGFydGVtaXNUcmFuc2xhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fTwvc21hbGw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvdyBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtMTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJzdWJtaXRCdXR0b25cIiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeVwiIHR5cGU9XCJzdWJtaXRcIiBbZGlzYWJsZWRdPVwiIWlzU3VibWl0UG9zc2libGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAoaXNFZGl0TW9kZSA/ICdnbG9iYWwuZ2VuZXJpYy5lZGl0JyA6ICdnbG9iYWwuZ2VuZXJpYy5jcmVhdGUnKSB8IGFydGVtaXNUcmFuc2xhdGUgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgIH1cbiAgICA8L2Rpdj5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIENoYW5nZURldGVjdG9yUmVmLCBDb21wb25lbnQsIE9uRGVzdHJveSwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBbGVydFNlcnZpY2UgfSBmcm9tICdhcHAvY29yZS91dGlsL2FsZXJ0LnNlcnZpY2UnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUsIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBUdXRvcmlhbEdyb3Vwc0NvbmZpZ3VyYXRpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvdHV0b3JpYWwtZ3JvdXAvdHV0b3JpYWwtZ3JvdXBzLWNvbmZpZ3VyYXRpb24ubW9kZWwnO1xuaW1wb3J0IHsgb25FcnJvciB9IGZyb20gJ2FwcC9zaGFyZWQvdXRpbC9nbG9iYWwudXRpbHMnO1xuaW1wb3J0IHsgVHV0b3JpYWxHcm91cHNDb25maWd1cmF0aW9uRm9ybURhdGEgfSBmcm9tICdhcHAvY291cnNlL3R1dG9yaWFsLWdyb3Vwcy90dXRvcmlhbC1ncm91cHMtbWFuYWdlbWVudC90dXRvcmlhbC1ncm91cHMtY29uZmlndXJhdGlvbi9jcnVkL3R1dG9yaWFsLWdyb3Vwcy1jb25maWd1cmF0aW9uLWZvcm0vdHV0b3JpYWwtZ3JvdXBzLWNvbmZpZ3VyYXRpb24tZm9ybS5jb21wb25lbnQnO1xuaW1wb3J0IHsgVHV0b3JpYWxHcm91cHNDb25maWd1cmF0aW9uU2VydmljZSB9IGZyb20gJ2FwcC9jb3Vyc2UvdHV0b3JpYWwtZ3JvdXBzL3NlcnZpY2VzL3R1dG9yaWFsLWdyb3Vwcy1jb25maWd1cmF0aW9uLnNlcnZpY2UnO1xuaW1wb3J0IHsgZmluYWxpemUsIHN3aXRjaE1hcCwgdGFrZSwgdGFrZVVudGlsIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBDb3Vyc2VNYW5hZ2VtZW50U2VydmljZSB9IGZyb20gJ2FwcC9jb3Vyc2UvbWFuYWdlL2NvdXJzZS1tYW5hZ2VtZW50LnNlcnZpY2UnO1xuaW1wb3J0IHsgQ291cnNlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2NvdXJzZS5tb2RlbCc7XG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBDb3Vyc2VTdG9yYWdlU2VydmljZSB9IGZyb20gJ2FwcC9jb3Vyc2UvbWFuYWdlL2NvdXJzZS1zdG9yYWdlLnNlcnZpY2UnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2poaS1jcmVhdGUtdHV0b3JpYWwtZ3JvdXBzLWNvbmZpZ3VyYXRpb24nLFxuICAgIHRlbXBsYXRlVXJsOiAnLi9jcmVhdGUtdHV0b3JpYWwtZ3JvdXBzLWNvbmZpZ3VyYXRpb24uY29tcG9uZW50Lmh0bWwnLFxuICAgIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBDcmVhdGVUdXRvcmlhbEdyb3Vwc0NvbmZpZ3VyYXRpb25Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gICAgbmdVbnN1YnNjcmliZSA9IG5ldyBTdWJqZWN0PHZvaWQ+KCk7XG5cbiAgICBuZXdUdXRvcmlhbEdyb3Vwc0NvbmZpZ3VyYXRpb24gPSBuZXcgVHV0b3JpYWxHcm91cHNDb25maWd1cmF0aW9uKCk7XG4gICAgaXNMb2FkaW5nOiBib29sZWFuO1xuICAgIGNvdXJzZTogQ291cnNlO1xuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgYWN0aXZhdGVkUm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgICAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgICAgICBwcml2YXRlIHR1dG9yaWFsR3JvdXBzQ29uZmlndXJhdGlvblNlcnZpY2U6IFR1dG9yaWFsR3JvdXBzQ29uZmlndXJhdGlvblNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgY291cnNlTWFuYWdlbWVudFNlcnZpY2U6IENvdXJzZU1hbmFnZW1lbnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGFsZXJ0U2VydmljZTogQWxlcnRTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIGNvdXJzZVN0b3JhZ2VTZXJ2aWNlOiBDb3Vyc2VTdG9yYWdlU2VydmljZSxcblxuICAgICAgICBwcml2YXRlIGNkcjogQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gICAgKSB7fVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuaXNMb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5hY3RpdmF0ZWRSb3V0ZS5wYXJhbU1hcFxuICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgdGFrZSgxKSxcbiAgICAgICAgICAgICAgICBzd2l0Y2hNYXAoKHBhcmFtcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjb3Vyc2VJZCA9IE51bWJlcihwYXJhbXMuZ2V0KCdjb3Vyc2VJZCcpKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY291cnNlTWFuYWdlbWVudFNlcnZpY2UuZmluZChjb3Vyc2VJZCk7XG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgZmluYWxpemUoKCkgPT4gKHRoaXMuaXNMb2FkaW5nID0gZmFsc2UpKSxcbiAgICAgICAgICAgICAgICB0YWtlVW50aWwodGhpcy5uZ1Vuc3Vic2NyaWJlKSxcbiAgICAgICAgICAgIClcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgICAgIG5leHQ6IChjb3Vyc2VSZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvdXJzZVJlc3VsdC5ib2R5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZSA9IGNvdXJzZVJlc3VsdC5ib2R5O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uZXdUdXRvcmlhbEdyb3Vwc0NvbmZpZ3VyYXRpb24gPSBuZXcgVHV0b3JpYWxHcm91cHNDb25maWd1cmF0aW9uKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGVycm9yOiAocmVzOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4gb25FcnJvcih0aGlzLmFsZXJ0U2VydmljZSwgcmVzKSxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuYWRkKCgpID0+IHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKSk7XG4gICAgfVxuXG4gICAgY3JlYXRlVHV0b3JpYWxzR3JvdXBDb25maWd1cmF0aW9uKGZvcm1EYXRhOiBUdXRvcmlhbEdyb3Vwc0NvbmZpZ3VyYXRpb25Gb3JtRGF0YSkge1xuICAgICAgICBjb25zdCB7IHBlcmlvZCwgdXNlUHVibGljVHV0b3JpYWxHcm91cENoYW5uZWxzLCB1c2VUdXRvcmlhbEdyb3VwQ2hhbm5lbHMgfSA9IGZvcm1EYXRhO1xuICAgICAgICB0aGlzLmlzTG9hZGluZyA9IHRydWU7XG4gICAgICAgIHRoaXMubmV3VHV0b3JpYWxHcm91cHNDb25maWd1cmF0aW9uLnVzZVR1dG9yaWFsR3JvdXBDaGFubmVscyA9IHVzZVR1dG9yaWFsR3JvdXBDaGFubmVscztcbiAgICAgICAgdGhpcy5uZXdUdXRvcmlhbEdyb3Vwc0NvbmZpZ3VyYXRpb24udXNlUHVibGljVHV0b3JpYWxHcm91cENoYW5uZWxzID0gdXNlUHVibGljVHV0b3JpYWxHcm91cENoYW5uZWxzO1xuICAgICAgICB0aGlzLnR1dG9yaWFsR3JvdXBzQ29uZmlndXJhdGlvblNlcnZpY2VcbiAgICAgICAgICAgIC5jcmVhdGUodGhpcy5uZXdUdXRvcmlhbEdyb3Vwc0NvbmZpZ3VyYXRpb24sIHRoaXMuY291cnNlLmlkISwgcGVyaW9kID8/IFtdKVxuICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgZmluYWxpemUoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgIHRha2VVbnRpbCh0aGlzLm5nVW5zdWJzY3JpYmUpLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKHJlc3ApID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb3Vyc2UudHV0b3JpYWxHcm91cHNDb25maWd1cmF0aW9uID0gcmVzcC5ib2R5ITtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb3Vyc2VTdG9yYWdlU2VydmljZS51cGRhdGVDb3Vyc2UodGhpcy5jb3Vyc2UpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9jb3Vyc2UtbWFuYWdlbWVudCcsIHRoaXMuY291cnNlLmlkISwgJ3R1dG9yaWFsLWdyb3Vwcy1jaGVja2xpc3QnXSk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBlcnJvcjogKHJlczogSHR0cEVycm9yUmVzcG9uc2UpID0+IG9uRXJyb3IodGhpcy5hbGVydFNlcnZpY2UsIHJlcyksXG4gICAgICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5uZ1Vuc3Vic2NyaWJlLm5leHQoKTtcbiAgICAgICAgdGhpcy5uZ1Vuc3Vic2NyaWJlLmNvbXBsZXRlKCk7XG4gICAgfVxufVxuIiwiPGpoaS1sb2FkaW5nLWluZGljYXRvci1jb250YWluZXIgW2lzTG9hZGluZ109XCJpc0xvYWRpbmdcIj5cbiAgICA8aDM+e3sgJ2FydGVtaXNBcHAucGFnZXMuY3JlYXRlVHV0b3JpYWxHcm91cHNDb25maWd1cmF0aW9uLnRpdGxlJyB8IGFydGVtaXNUcmFuc2xhdGUgfX08L2gzPlxuICAgIDxkaXYgY2xhc3M9XCJhbGVydCBhbGVydC1pbmZvXCIgcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgIHt7ICdhcnRlbWlzQXBwLnBhZ2VzLmNyZWF0ZVR1dG9yaWFsR3JvdXBzQ29uZmlndXJhdGlvbi5leHBsYW5hdGlvbicgfCBhcnRlbWlzVHJhbnNsYXRlIH19XG4gICAgPC9kaXY+XG4gICAgPGpoaS10dXRvcmlhbC1ncm91cHMtY29uZmlndXJhdGlvbi1mb3JtIFtpc0VkaXRNb2RlXT1cImZhbHNlXCIgKGZvcm1TdWJtaXR0ZWQpPVwiY3JlYXRlVHV0b3JpYWxzR3JvdXBDb25maWd1cmF0aW9uKCRldmVudClcIiBbY291cnNlXT1cImNvdXJzZVwiPlxuICAgIDwvamhpLXR1dG9yaWFsLWdyb3Vwcy1jb25maWd1cmF0aW9uLWZvcm0+XG48L2poaS1sb2FkaW5nLWluZGljYXRvci1jb250YWluZXI+XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uRGVzdHJveSwgT3V0cHV0LCBWaWV3Q2hpbGQsIFZpZXdFbmNhcHN1bGF0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBTdWJqZWN0LCBvZiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IFVzZXIgfSBmcm9tICdhcHAvY29yZS91c2VyL3VzZXIubW9kZWwnO1xuaW1wb3J0IHsgQ291cnNlLCBDb3Vyc2VHcm91cCB9IGZyb20gJ2FwcC9lbnRpdGllcy9jb3Vyc2UubW9kZWwnO1xuaW1wb3J0IHsgQWN0aW9uVHlwZSB9IGZyb20gJ2FwcC9zaGFyZWQvZGVsZXRlLWRpYWxvZy9kZWxldGUtZGlhbG9nLm1vZGVsJztcbmltcG9ydCB7IGNhdGNoRXJyb3IsIG1hcCwgc3dpdGNoTWFwLCB0YXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBEYXRhVGFibGVDb21wb25lbnQgfSBmcm9tICdhcHAvc2hhcmVkL2RhdGEtdGFibGUvZGF0YS10YWJsZS5jb21wb25lbnQnO1xuaW1wb3J0IHsgaWNvbnNBc0hUTUwgfSBmcm9tICdhcHAvdXRpbHMvaWNvbnMudXRpbHMnO1xuaW1wb3J0IHsgRXhwb3J0VG9Dc3YgfSBmcm9tICdleHBvcnQtdG8tY3N2JztcbmltcG9ydCB7IGZhRG93bmxvYWQsIGZhVXNlclNsYXNoIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZyZWUtc29saWQtc3ZnLWljb25zJztcbmltcG9ydCB7IFR1dG9yaWFsR3JvdXAgfSBmcm9tICdhcHAvZW50aXRpZXMvdHV0b3JpYWwtZ3JvdXAvdHV0b3JpYWwtZ3JvdXAubW9kZWwnO1xuXG5jb25zdCBOQU1FX0tFWSA9ICdOYW1lJztcbmNvbnN0IFVTRVJOQU1FX0tFWSA9ICdVc2VybmFtZSc7XG5jb25zdCBFTUFJTF9LRVkgPSAnRW1haWwnO1xuY29uc3QgUkVHSVNUUkFUSU9OX05VTUJFUl9LRVkgPSAnUmVnaXN0cmF0aW9uIE51bWJlcic7XG5cbmNvbnN0IGNzc0NsYXNzZXMgPSB7XG4gICAgYWxyZWFkeU1lbWJlcjogJ2FscmVhZHktbWVtYmVyJyxcbiAgICBuZXdseUFkZGVkTWVtYmVyOiAnbmV3bHktYWRkZWQtbWVtYmVyJyxcbn07XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnamhpLWNvdXJzZS1ncm91cCcsXG4gICAgdGVtcGxhdGVVcmw6ICcuL2NvdXJzZS1ncm91cC5jb21wb25lbnQuaHRtbCcsXG4gICAgc3R5bGVVcmxzOiBbJy4vY291cnNlLWdyb3VwLmNvbXBvbmVudC5zY3NzJ10sXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcbn0pXG5leHBvcnQgY2xhc3MgQ291cnNlR3JvdXBDb21wb25lbnQgaW1wbGVtZW50cyBPbkRlc3Ryb3kge1xuICAgIEBWaWV3Q2hpbGQoRGF0YVRhYmxlQ29tcG9uZW50KSBkYXRhVGFibGU6IERhdGFUYWJsZUNvbXBvbmVudDtcblxuICAgIEBJbnB1dCgpXG4gICAgYWxsR3JvdXBVc2VyczogVXNlcltdID0gW107XG4gICAgQElucHV0KClcbiAgICBpc0xvYWRpbmdBbGxHcm91cFVzZXJzID0gZmFsc2U7XG4gICAgQElucHV0KClcbiAgICBpc0FkbWluID0gZmFsc2U7XG4gICAgQElucHV0KClcbiAgICBjb3Vyc2U6IENvdXJzZTtcbiAgICBASW5wdXQoKVxuICAgIHR1dG9yaWFsR3JvdXA6IFR1dG9yaWFsR3JvdXAgfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG4gICAgQElucHV0KClcbiAgICBjb3Vyc2VHcm91cDogQ291cnNlR3JvdXA7XG4gICAgQElucHV0KClcbiAgICBleHBvcnRGaWxlTmFtZTogc3RyaW5nO1xuXG4gICAgQElucHV0KClcbiAgICB1c2VyU2VhcmNoOiAobG9naW5Pck5hbWU6IHN0cmluZykgPT4gT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VXNlcltdPj4gPSAoKSA9PiBvZihuZXcgSHR0cFJlc3BvbnNlPFVzZXJbXT4oeyBib2R5OiBbXSB9KSk7XG4gICAgQElucHV0KClcbiAgICBhZGRVc2VyVG9Hcm91cDogKGxvZ2luOiBzdHJpbmcpID0+IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPHZvaWQ+PiA9ICgpID0+IG9mKG5ldyBIdHRwUmVzcG9uc2U8dm9pZD4oKSk7XG4gICAgQElucHV0KClcbiAgICByZW1vdmVVc2VyRnJvbUdyb3VwOiAobG9naW46IHN0cmluZykgPT4gT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8dm9pZD4+ID0gKCkgPT4gb2YobmV3IEh0dHBSZXNwb25zZTx2b2lkPigpKTtcbiAgICBASW5wdXQoKVxuICAgIGhhbmRsZVVzZXJzU2l6ZUNoYW5nZTogKGZpbHRlcmVkVXNlcnNTaXplOiBudW1iZXIpID0+IHZvaWQgPSAoKSA9PiB7fTtcblxuICAgIEBPdXRwdXQoKVxuICAgIGltcG9ydEZpbmlzaDogRXZlbnRFbWl0dGVyPHZvaWQ+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gICAgcmVhZG9ubHkgQWN0aW9uVHlwZSA9IEFjdGlvblR5cGU7XG5cbiAgICBwcml2YXRlIGRpYWxvZ0Vycm9yU291cmNlID0gbmV3IFN1YmplY3Q8c3RyaW5nPigpO1xuICAgIGRpYWxvZ0Vycm9yJCA9IHRoaXMuZGlhbG9nRXJyb3JTb3VyY2UuYXNPYnNlcnZhYmxlKCk7XG5cbiAgICBpc1NlYXJjaGluZyA9IGZhbHNlO1xuICAgIHNlYXJjaEZhaWxlZCA9IGZhbHNlO1xuICAgIHNlYXJjaE5vUmVzdWx0cyA9IGZhbHNlO1xuICAgIGlzVHJhbnNpdGlvbmluZyA9IGZhbHNlO1xuICAgIHJvd0NsYXNzOiBzdHJpbmcgfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG5cbiAgICAvLyBJY29uc1xuICAgIGZhRG93bmxvYWQgPSBmYURvd25sb2FkO1xuICAgIGZhVXNlclNsYXNoID0gZmFVc2VyU2xhc2g7XG5cbiAgICAvKipcbiAgICAgKiBVbnN1YnNjcmliZSBkaWFsb2cgZXJyb3Igc291cmNlIG9uIGNvbXBvbmVudCBkZXN0cnVjdGlvbi5cbiAgICAgKi9cbiAgICBuZ09uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5kaWFsb2dFcnJvclNvdXJjZS51bnN1YnNjcmliZSgpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJlY2VpdmVzIHRoZSBzZWFyY2ggdGV4dCBhbmQgZmlsdGVyIHJlc3VsdHMgZnJvbSBEYXRhVGFibGVDb21wb25lbnQsIG1vZGlmaWVzIHRoZW0gYW5kIHJldHVybnMgdGhlIHJlc3VsdCB3aGljaCB3aWxsIGJlIHVzZWQgYnkgbmdiVHlwZWFoZWFkLlxuICAgICAqXG4gICAgICogMS4gUGVyZm9ybSBzZXJ2ZXItc2lkZSBzZWFyY2ggdXNpbmcgdGhlIHNlYXJjaCB0ZXh0XG4gICAgICogMi4gUmV0dXJuIHJlc3VsdHMgZnJvbSBzZXJ2ZXIgcXVlcnkgdGhhdCBjb250YWluIGFsbCB1c2VycyAoaW5zdGVhZCBvZiBvbmx5IHRoZSBjbGllbnQtc2lkZSB1c2VycyB3aG8gYXJlIGdyb3VwIG1lbWJlcnMgYWxyZWFkeSlcbiAgICAgKlxuICAgICAqIEBwYXJhbSBzdHJlYW0kIHN0cmVhbSBvZiBzZWFyY2hlcyBvZiB0aGUgZm9ybWF0IHt0ZXh0LCBlbnRpdGllc30gd2hlcmUgZW50aXRpZXMgYXJlIHRoZSByZXN1bHRzXG4gICAgICogQHJldHVybiBzdHJlYW0gb2YgdXNlcnMgZm9yIHRoZSBhdXRvY29tcGxldGVcbiAgICAgKi9cbiAgICBzZWFyY2hBbGxVc2VycyA9IChzdHJlYW0kOiBPYnNlcnZhYmxlPHsgdGV4dDogc3RyaW5nOyBlbnRpdGllczogVXNlcltdIH0+KTogT2JzZXJ2YWJsZTxVc2VyW10+ID0+IHtcbiAgICAgICAgcmV0dXJuIHN0cmVhbSQucGlwZShcbiAgICAgICAgICAgIHN3aXRjaE1hcCgoeyB0ZXh0OiBsb2dpbk9yTmFtZSB9KSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZWFyY2hGYWlsZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLnNlYXJjaE5vUmVzdWx0cyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGlmIChsb2dpbk9yTmFtZS5sZW5ndGggPCAzKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBvZihbXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMuaXNTZWFyY2hpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnVzZXJTZWFyY2gobG9naW5Pck5hbWUpXG4gICAgICAgICAgICAgICAgICAgIC5waXBlKG1hcCgodXNlcnNSZXNwb25zZSkgPT4gdXNlcnNSZXNwb25zZS5ib2R5ISkpXG4gICAgICAgICAgICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgICAgICAgICAgICAgdGFwKCh1c2VycykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh1c2Vycy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZWFyY2hOb1Jlc3VsdHMgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgY2F0Y2hFcnJvcigoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZWFyY2hGYWlsZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvZihbXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgdGFwKCgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmlzU2VhcmNoaW5nID0gZmFsc2U7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRhcCgodXNlcnMpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLmRhdGFUYWJsZS50eXBlYWhlYWRCdXR0b25zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0FscmVhZHlJbkdyb3VwID0gdGhpcy5hbGxHcm91cFVzZXJzLm1hcCgodXNlcikgPT4gdXNlci5pZCkuaW5jbHVkZXModXNlcnNbaV0uaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kYXRhVGFibGUudHlwZWFoZWFkQnV0dG9uc1tpXS5pbnNlcnRBZGphY2VudEhUTUwoJ2JlZm9yZWVuZCcsIGljb25zQXNIVE1MW2lzQWxyZWFkeUluR3JvdXAgPyAndXNlcnMnIDogJ3VzZXJzLXBsdXMnXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNBbHJlYWR5SW5Hcm91cCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGF0YVRhYmxlLnR5cGVhaGVhZEJ1dHRvbnNbaV0uY2xhc3NMaXN0LmFkZChjc3NDbGFzc2VzLmFscmVhZHlNZW1iZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgKTtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogUmVjZWl2ZXMgdGhlIHVzZXIgdGhhdCB3YXMgc2VsZWN0ZWQgaW4gdGhlIGF1dG9jb21wbGV0ZSBhbmQgdGhlIGNhbGxiYWNrIGZyb20gRGF0YVRhYmxlQ29tcG9uZW50LlxuICAgICAqIFRoZSBjYWxsYmFjayBpbnNlcnRzIHRoZSBzZWFyY2ggdGVybSBvZiB0aGUgc2VsZWN0ZWQgZW50aXR5IGludG8gdGhlIHNlYXJjaCBmaWVsZCBhbmQgdXBkYXRlcyB0aGUgZGlzcGxheWVkIHVzZXJzLlxuICAgICAqXG4gICAgICogQHBhcmFtIHVzZXIgVGhlIHNlbGVjdGVkIHVzZXIgZnJvbSB0aGUgYXV0b2NvbXBsZXRlIHN1Z2dlc3Rpb25zXG4gICAgICogQHBhcmFtIGNhbGxiYWNrIEZ1bmN0aW9uIHRoYXQgY2FuIGJlIGNhbGxlZCB3aXRoIHRoZSBzZWxlY3RlZCB1c2VyIHRvIHRyaWdnZXIgdGhlIERhdGFUYWJsZUNvbXBvbmVudCBkZWZhdWx0IGJlaGF2aW9yXG4gICAgICovXG4gICAgb25BdXRvY29tcGxldGVTZWxlY3QgPSAodXNlcjogVXNlciwgY2FsbGJhY2s6ICh1c2VyOiBVc2VyKSA9PiB2b2lkKTogdm9pZCA9PiB7XG4gICAgICAgIC8vIElmIHRoZSB1c2VyIGlzIG5vdCBwYXJ0IG9mIHRoaXMgY291cnNlIGdyb3VwIHlldCwgcGVyZm9ybSB0aGUgc2VydmVyIGNhbGwgdG8gYWRkIHRoZW1cbiAgICAgICAgaWYgKCF0aGlzLmFsbEdyb3VwVXNlcnMubWFwKCh1KSA9PiB1LmlkKS5pbmNsdWRlcyh1c2VyLmlkKSAmJiB1c2VyLmxvZ2luKSB7XG4gICAgICAgICAgICB0aGlzLmlzVHJhbnNpdGlvbmluZyA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLmFkZFVzZXJUb0dyb3VwKHVzZXIubG9naW4pLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzVHJhbnNpdGlvbmluZyA9IGZhbHNlO1xuXG4gICAgICAgICAgICAgICAgICAgIC8vIEFkZCBuZXdseSBhZGRlZCB1c2VyIHRvIHRoZSBsaXN0IG9mIGFsbCB1c2VycyBpbiB0aGUgY291cnNlIGdyb3VwXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWxsR3JvdXBVc2Vycy5wdXNoKHVzZXIpO1xuXG4gICAgICAgICAgICAgICAgICAgIC8vIEhhbmQgYmFjayBvdmVyIHRvIHRoZSBkYXRhIHRhYmxlIGZvciB1cGRhdGluZ1xuICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayh1c2VyKTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBGbGFzaCBncmVlbiBiYWNrZ3JvdW5kIGNvbG9yIHRvIHNpZ25hbCB0byB0aGUgdXNlciB0aGF0IHRoaXMgcmVjb3JkIHdhcyBhZGRlZFxuICAgICAgICAgICAgICAgICAgICB0aGlzLmZsYXNoUm93Q2xhc3MoY3NzQ2xhc3Nlcy5uZXdseUFkZGVkTWVtYmVyKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGVycm9yOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXNUcmFuc2l0aW9uaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gSGFuZCBiYWNrIG92ZXIgdG8gdGhlIGRhdGEgdGFibGVcbiAgICAgICAgICAgIGNhbGxiYWNrKHVzZXIpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIFJlbW92ZSB1c2VyIGZyb20gY291cnNlIGdyb3VwXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdXNlciBVc2VyIHRoYXQgc2hvdWxkIGJlIHJlbW92ZWQgZnJvbSB0aGUgY3VycmVudGx5IHZpZXdlZCBjb3Vyc2UgZ3JvdXBcbiAgICAgKi9cbiAgICByZW1vdmVGcm9tR3JvdXAodXNlcjogVXNlcikge1xuICAgICAgICBpZiAodXNlci5sb2dpbikge1xuICAgICAgICAgICAgdGhpcy5yZW1vdmVVc2VyRnJvbUdyb3VwKHVzZXIubG9naW4pLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFsbEdyb3VwVXNlcnMgPSB0aGlzLmFsbEdyb3VwVXNlcnMuZmlsdGVyKCh1KSA9PiB1LmxvZ2luICE9PSB1c2VyLmxvZ2luKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kaWFsb2dFcnJvclNvdXJjZS5uZXh0KCcnKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGVycm9yOiAoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiB0aGlzLmRpYWxvZ0Vycm9yU291cmNlLm5leHQoZXJyb3IubWVzc2FnZSksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEZvcm1hdHMgdGhlIHJlc3VsdHMgaW4gdGhlIGF1dG9jb21wbGV0ZSBvdmVybGF5LlxuICAgICAqXG4gICAgICogQHBhcmFtIHVzZXJcbiAgICAgKi9cbiAgICBzZWFyY2hSZXN1bHRGb3JtYXR0ZXIgPSAodXNlcjogVXNlcikgPT4ge1xuICAgICAgICBjb25zdCB7IG5hbWUsIGxvZ2luIH0gPSB1c2VyO1xuICAgICAgICByZXR1cm4gYCR7bmFtZX0gKCR7bG9naW59KWA7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIENvbnZlcnRzIGEgdXNlciBvYmplY3QgdG8gYSBzdHJpbmcgdGhhdCBjYW4gYmUgc2VhcmNoZWQgZm9yLiBUaGlzIGlzXG4gICAgICogdXNlZCBieSB0aGUgYXV0b2NvbXBsZXRlIHNlbGVjdCBpbnNpZGUgdGhlIGRhdGEgdGFibGUuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gdXNlciBVc2VyXG4gICAgICovXG4gICAgc2VhcmNoVGV4dEZyb21Vc2VyID0gKHVzZXI6IFVzZXIpOiBzdHJpbmcgPT4ge1xuICAgICAgICByZXR1cm4gdXNlci5sb2dpbiB8fCAnJztcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogQ29tcHV0ZXMgdGhlIHJvdyBjbGFzcyB0aGF0IGlzIGJlaW5nIGFkZGVkIHRvIGFsbCByb3dzIG9mIHRoZSBkYXRhdGFibGVcbiAgICAgKi9cbiAgICBkYXRhVGFibGVSb3dDbGFzcyA9ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMucm93Q2xhc3M7XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIENhbiBiZSB1c2VkIHRvIGhpZ2hsaWdodCByb3dzIHRlbXBvcmFyaWx5IGJ5IGZsYXNoaW5nIGEgY2VydGFpbiBjc3MgY2xhc3NcbiAgICAgKlxuICAgICAqIEBwYXJhbSBjbGFzc05hbWUgTmFtZSBvZiB0aGUgY2xhc3MgdG8gYmUgYXBwbGllZCB0byBhbGwgcm93c1xuICAgICAqL1xuICAgIGZsYXNoUm93Q2xhc3MgPSAoY2xhc3NOYW1lOiBzdHJpbmcpID0+IHtcbiAgICAgICAgdGhpcy5yb3dDbGFzcyA9IGNsYXNzTmFtZTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiAodGhpcy5yb3dDbGFzcyA9IHVuZGVmaW5lZCkpO1xuICAgIH07XG5cbiAgICAvKipcbiAgICAgKiBNZXRob2QgZm9yIGV4cG9ydGluZyB0aGUgY3N2IHdpdGggdGhlIG5lZWRlZCBkYXRhXG4gICAgICovXG4gICAgZXhwb3J0VXNlckluZm9ybWF0aW9uID0gKCkgPT4ge1xuICAgICAgICBpZiAodGhpcy5hbGxHcm91cFVzZXJzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGNvbnN0IHJvd3M6IGFueVtdID0gdGhpcy5hbGxHcm91cFVzZXJzLm1hcCgodXNlcjogVXNlcikgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGRhdGEgPSB7fTtcbiAgICAgICAgICAgICAgICBkYXRhW05BTUVfS0VZXSA9IHVzZXIubmFtZT8udHJpbSgpID8/ICcnO1xuICAgICAgICAgICAgICAgIGRhdGFbVVNFUk5BTUVfS0VZXSA9IHVzZXIubG9naW4/LnRyaW0oKSA/PyAnJztcbiAgICAgICAgICAgICAgICBkYXRhW0VNQUlMX0tFWV0gPSB1c2VyLmVtYWlsPy50cmltKCkgPz8gJyc7XG4gICAgICAgICAgICAgICAgZGF0YVtSRUdJU1RSQVRJT05fTlVNQkVSX0tFWV0gPSB1c2VyLnZpc2libGVSZWdpc3RyYXRpb25OdW1iZXI/LnRyaW0oKSA/PyAnJztcbiAgICAgICAgICAgICAgICByZXR1cm4gZGF0YTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgY29uc3Qga2V5cyA9IFtOQU1FX0tFWSwgVVNFUk5BTUVfS0VZLCBFTUFJTF9LRVksIFJFR0lTVFJBVElPTl9OVU1CRVJfS0VZXTtcbiAgICAgICAgICAgIHRoaXMuZXhwb3J0QXNDc3Yocm93cywga2V5cyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogTWV0aG9kIGZvciBnZW5lcmF0aW5nIHRoZSBjc3YgZmlsZSBjb250YWluaW5nIHRoZSB1c2VyIGluZm9ybWF0aW9uXG4gICAgICpcbiAgICAgKiBAcGFyYW0gcm93cyB0aGUgZGF0YSB0byBleHBvcnRcbiAgICAgKiBAcGFyYW0ga2V5cyB0aGUga2V5cyBvZiB0aGUgZGF0YVxuICAgICAqL1xuICAgIGV4cG9ydEFzQ3N2ID0gKHJvd3M6IGFueVtdLCBrZXlzOiBzdHJpbmdbXSkgPT4ge1xuICAgICAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgICAgICAgZmllbGRTZXBhcmF0b3I6ICc7JyxcbiAgICAgICAgICAgIHF1b3RlU3RyaW5nczogJ1wiJyxcbiAgICAgICAgICAgIHNob3dMYWJlbHM6IHRydWUsXG4gICAgICAgICAgICBzaG93VGl0bGU6IGZhbHNlLFxuICAgICAgICAgICAgZmlsZW5hbWU6IHRoaXMuZXhwb3J0RmlsZU5hbWUsXG4gICAgICAgICAgICB1c2VUZXh0RmlsZTogZmFsc2UsXG4gICAgICAgICAgICB1c2VCb206IHRydWUsXG4gICAgICAgICAgICBoZWFkZXJzOiBrZXlzLFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBjc3ZFeHBvcnRlciA9IG5ldyBFeHBvcnRUb0NzdihvcHRpb25zKTtcbiAgICAgICAgY3N2RXhwb3J0ZXIuZ2VuZXJhdGVDc3Yocm93cyk7XG4gICAgfTtcbn1cbiIsIjxkaXY+XG4gICAgPGRpdiBjbGFzcz1cImQtZmxleCBmbGV4LXdyYXAganVzdGlmeS1jb250ZW50LWJldHdlZW4gYWxpZ24taXRlbXMtY2VudGVyIG1iLTFcIj5cbiAgICAgICAgPGgyIGNsYXNzPVwibWItMVwiPlxuICAgICAgICAgICAgPCEtLSBBZGRpdGlvbmFsIEhlYWRlciBORy1Db250ZW50LS0+XG4gICAgICAgICAgICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG4gICAgICAgIDwvaDI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXggbXQtMSBtYi0xIGdhcC0xXCI+XG4gICAgICAgICAgICBAaWYgKGNvdXJzZT8uaXNBdExlYXN0SW5zdHJ1Y3Rvcikge1xuICAgICAgICAgICAgICAgIDxqaGktdXNlci1pbXBvcnQtYnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIFtjb3Vyc2VJZF09XCJjb3Vyc2UuaWQhXCJcbiAgICAgICAgICAgICAgICAgICAgW2NvdXJzZUdyb3VwXT1cImNvdXJzZUdyb3VwIVwiXG4gICAgICAgICAgICAgICAgICAgIChmaW5pc2gpPVwiaW1wb3J0RmluaXNoLmVtaXQoKVwiXG4gICAgICAgICAgICAgICAgICAgIFt0dXRvcmlhbEdyb3VwXT1cInR1dG9yaWFsR3JvdXBcIlxuICAgICAgICAgICAgICAgID48L2poaS11c2VyLWltcG9ydC1idXR0b24+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBAaWYgKGNvdXJzZT8uaXNBdExlYXN0SW5zdHJ1Y3RvciAmJiBhbGxHcm91cFVzZXJzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbVwiIChjbGljayk9XCJleHBvcnRVc2VySW5mb3JtYXRpb24oKVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJmYURvd25sb2FkXCIgW2ZpeGVkV2lkdGhdPVwidHJ1ZVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5pbnN0cnVjdG9yRGFzaGJvYXJkLmV4cG9ydENTVlwiPiZuYnNwO0V4cG9ydCBVc2Vyczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgPGpoaS1kYXRhLXRhYmxlXG4gICAgICAgIGlkPVwicmVnaXN0ZXJlZC1zdHVkZW50c1wiXG4gICAgICAgIFtpc0xvYWRpbmddPVwiaXNMb2FkaW5nQWxsR3JvdXBVc2Vyc1wiXG4gICAgICAgIFtpc1NlYXJjaGluZ109XCJpc1NlYXJjaGluZ1wiXG4gICAgICAgIFtzZWFyY2hGYWlsZWRdPVwic2VhcmNoRmFpbGVkXCJcbiAgICAgICAgW3NlYXJjaE5vUmVzdWx0c109XCJzZWFyY2hOb1Jlc3VsdHNcIlxuICAgICAgICBbaXNUcmFuc2l0aW9uaW5nXT1cImlzVHJhbnNpdGlvbmluZ1wiXG4gICAgICAgIGVudGl0eVR5cGU9XCJ1c2VyXCJcbiAgICAgICAgW2FsbEVudGl0aWVzXT1cImFsbEdyb3VwVXNlcnNcIlxuICAgICAgICBlbnRpdGllc1BlclBhZ2VUcmFuc2xhdGlvbj1cImFydGVtaXNBcHAuY291cnNlLmNvdXJzZUdyb3VwLnVzZXJzUGVyUGFnZVwiXG4gICAgICAgIHNob3dBbGxFbnRpdGllc1RyYW5zbGF0aW9uPVwiYXJ0ZW1pc0FwcC5jb3Vyc2UuY291cnNlR3JvdXAuc2hvd0FsbFVzZXJzXCJcbiAgICAgICAgc2VhcmNoTm9SZXN1bHRzVHJhbnNsYXRpb249XCJhcnRlbWlzQXBwLmNvdXJzZS5jb3Vyc2VHcm91cC5zZWFyY2hOb1Jlc3VsdHNcIlxuICAgICAgICBzZWFyY2hQbGFjZWhvbGRlclRyYW5zbGF0aW9uPVwiYXJ0ZW1pc0FwcC5jb3Vyc2UuY291cnNlR3JvdXAuc2VhcmNoRm9yVXNlcnNcIlxuICAgICAgICBbc2VhcmNoRmllbGRzXT1cIlsnbG9naW4nLCAnbmFtZSddXCJcbiAgICAgICAgW3NlYXJjaFRleHRGcm9tRW50aXR5XT1cInNlYXJjaFRleHRGcm9tVXNlclwiXG4gICAgICAgIFtzZWFyY2hSZXN1bHRGb3JtYXR0ZXJdPVwic2VhcmNoUmVzdWx0Rm9ybWF0dGVyXCJcbiAgICAgICAgW29uU2VhcmNoV3JhcHBlcl09XCJzZWFyY2hBbGxVc2Vyc1wiXG4gICAgICAgIFtvbkF1dG9jb21wbGV0ZVNlbGVjdFdyYXBwZXJdPVwib25BdXRvY29tcGxldGVTZWxlY3RcIlxuICAgICAgICAoZW50aXRpZXNTaXplQ2hhbmdlKT1cImhhbmRsZVVzZXJzU2l6ZUNoYW5nZSgkZXZlbnQpXCJcbiAgICA+XG4gICAgICAgIDxuZy10ZW1wbGF0ZSBsZXQtc2V0dGluZ3M9XCJzZXR0aW5nc1wiIGxldC1jb250cm9scz1cImNvbnRyb2xzXCI+XG4gICAgICAgICAgICA8bmd4LWRhdGF0YWJsZVxuICAgICAgICAgICAgICAgIGNsYXNzPVwiYm9vdHN0cmFwXCJcbiAgICAgICAgICAgICAgICBbbGltaXRdPVwic2V0dGluZ3MubGltaXRcIlxuICAgICAgICAgICAgICAgIFtzb3J0VHlwZV09XCJzZXR0aW5ncy5zb3J0VHlwZVwiXG4gICAgICAgICAgICAgICAgW2NvbHVtbk1vZGVdPVwic2V0dGluZ3MuY29sdW1uTW9kZVwiXG4gICAgICAgICAgICAgICAgW2hlYWRlckhlaWdodF09XCJzZXR0aW5ncy5oZWFkZXJIZWlnaHRcIlxuICAgICAgICAgICAgICAgIFtmb290ZXJIZWlnaHRdPVwic2V0dGluZ3MuZm9vdGVySGVpZ2h0XCJcbiAgICAgICAgICAgICAgICBbcm93SGVpZ2h0XT1cInNldHRpbmdzLnJvd0hlaWdodFwiXG4gICAgICAgICAgICAgICAgW3Jvd3NdPVwic2V0dGluZ3Mucm93c1wiXG4gICAgICAgICAgICAgICAgW3Jvd0NsYXNzXT1cImRhdGFUYWJsZVJvd0NsYXNzXCJcbiAgICAgICAgICAgICAgICBbc2Nyb2xsYmFySF09XCJzZXR0aW5ncy5zY3JvbGxiYXJIXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8bmd4LWRhdGF0YWJsZS1jb2x1bW4gcHJvcD1cIlwiIFttaW5XaWR0aF09XCI2MFwiIFt3aWR0aF09XCI4MFwiIFttYXhXaWR0aF09XCIxMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtaGVhZGVyLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJkYXRhdGFibGUtaGVhZGVyLWNlbGwtd3JhcHBlclwiIChjbGljayk9XCJjb250cm9scy5vblNvcnQoJ2lkJylcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC1sYWJlbCBib2xkIHNvcnRhYmxlXCIgamhpVHJhbnNsYXRlPVwiZ2xvYmFsLmZpZWxkLmlkXCI+IElEIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJjb250cm9scy5pY29uRm9yU29ydFByb3BGaWVsZCgnaWQnKVwiPjwvZmEtaWNvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZSBsZXQtdmFsdWU9XCJ2YWx1ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChpc0FkbWluKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgcm91dGVyTGluaz1cIi9hZG1pbi91c2VyLW1hbmFnZW1lbnQve3sgdmFsdWU/LmxvZ2luIH19XCI+IHt7IHZhbHVlLmlkIH19IDwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IHZhbHVlPy5pZCB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XG4gICAgICAgICAgICAgICAgPG5neC1kYXRhdGFibGUtY29sdW1uIHByb3A9XCJsb2dpblwiIFttaW5XaWR0aF09XCIxNTBcIiBbd2lkdGhdPVwiMjAwXCIgW21heFdpZHRoXT1cIjIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVyXCIgKGNsaWNrKT1cImNvbnRyb2xzLm9uU29ydCgnbG9naW4nKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLWxhYmVsIGJvbGQgc29ydGFibGVcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvdXJzZS5jb3Vyc2VHcm91cC5sb2dpblwiPiBMb2dpbiA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiY29udHJvbHMuaWNvbkZvclNvcnRQcm9wRmllbGQoJ2xvZ2luJylcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwidmFsdWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IHZhbHVlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XG4gICAgICAgICAgICAgICAgPG5neC1kYXRhdGFibGUtY29sdW1uIHByb3A9XCJ2aXNpYmxlUmVnaXN0cmF0aW9uTnVtYmVyXCIgW21pbldpZHRoXT1cIjE1MFwiIFt3aWR0aF09XCIyMDBcIiBbbWF4V2lkdGhdPVwiMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWhlYWRlci10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLXdyYXBwZXJcIiAoY2xpY2spPVwiY29udHJvbHMub25Tb3J0KCd2aXNpYmxlUmVnaXN0cmF0aW9uTnVtYmVyJylcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC1sYWJlbCBib2xkIHNvcnRhYmxlXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb3Vyc2UuY291cnNlR3JvdXAucmVnaXN0cmF0aW9uTnVtYmVyXCI+IFJlZ2lzdHJhdGlvbiBOdW1iZXIgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmYS1pY29uIFtpY29uXT1cImNvbnRyb2xzLmljb25Gb3JTb3J0UHJvcEZpZWxkKCd2aXNpYmxlUmVnaXN0cmF0aW9uTnVtYmVyJylcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwidmFsdWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IHZhbHVlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XG4gICAgICAgICAgICAgICAgPG5neC1kYXRhdGFibGUtY29sdW1uIHByb3A9XCJuYW1lXCIgW21pbldpZHRoXT1cIjE1MFwiIFt3aWR0aF09XCIyNTBcIiBbbWF4V2lkdGhdPVwiMjUwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWhlYWRlci10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLXdyYXBwZXJcIiAoY2xpY2spPVwiY29udHJvbHMub25Tb3J0KCduYW1lJylcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC1sYWJlbCBib2xkIHNvcnRhYmxlXCIgamhpVHJhbnNsYXRlPVwiYXJ0ZW1pc0FwcC5jb3Vyc2UuY291cnNlR3JvdXAubmFtZVwiPiBOYW1lIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZmEtaWNvbiBbaWNvbl09XCJjb250cm9scy5pY29uRm9yU29ydFByb3BGaWVsZCgnbmFtZScpXCI+PC9mYS1pY29uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1jZWxsLXRlbXBsYXRlIGxldC12YWx1ZT1cInZhbHVlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyB2YWx1ZSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICA8L25neC1kYXRhdGFibGUtY29sdW1uPlxuICAgICAgICAgICAgICAgIDxuZ3gtZGF0YXRhYmxlLWNvbHVtbiBwcm9wPVwiZW1haWxcIiBbbWluV2lkdGhdPVwiMTUwXCIgW3dpZHRoXT1cIjI1MFwiPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVyXCIgKGNsaWNrKT1cImNvbnRyb2xzLm9uU29ydCgnZW1haWwnKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZGF0YXRhYmxlLWhlYWRlci1jZWxsLWxhYmVsIGJvbGQgc29ydGFibGVcIiBqaGlUcmFuc2xhdGU9XCJhcnRlbWlzQXBwLmNvdXJzZS5jb3Vyc2VHcm91cC5lbWFpbFwiPiBFbWFpbCA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiY29udHJvbHMuaWNvbkZvclNvcnRQcm9wRmllbGQoJ2VtYWlsJylcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwidmFsdWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IHZhbHVlIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XG4gICAgICAgICAgICAgICAgPG5neC1kYXRhdGFibGUtY29sdW1uIHByb3A9XCJcIiBbbWluV2lkdGhdPVwiMTUwXCIgW3dpZHRoXT1cIjIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+IDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXZhbHVlPVwidmFsdWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LTEwMCB0ZXh0LWVuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamhpRGVsZXRlQnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFthY3Rpb25UeXBlXT1cIkFjdGlvblR5cGUuUmVtb3ZlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2VudGl0eVRpdGxlXT1cInZhbHVlLmxvZ2luXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlUXVlc3Rpb249XCJhcnRlbWlzQXBwLmNvdXJzZS5jb3Vyc2VHcm91cC5yZW1vdmVGcm9tR3JvdXAubW9kYWxRdWVzdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChkZWxldGUpPVwicmVtb3ZlRnJvbUdyb3VwKHZhbHVlKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtkaWFsb2dFcnJvcl09XCJkaWFsb2dFcnJvciRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZhLWljb24gW2ljb25dPVwiZmFVc2VyU2xhc2hcIiBjbGFzcz1cIm1lLTFcIj48L2ZhLWljb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICA8L25neC1kYXRhdGFibGUtY29sdW1uPlxuICAgICAgICAgICAgPC9uZ3gtZGF0YXRhYmxlPlxuICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgIDwvamhpLWRhdGEtdGFibGU+XG48L2Rpdj5cbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb3Vyc2VHcm91cENvbXBvbmVudCB9IGZyb20gJ2FwcC9zaGFyZWQvY291cnNlLWdyb3VwL2NvdXJzZS1ncm91cC5jb21wb25lbnQnO1xuaW1wb3J0IHsgQXJ0ZW1pc0RhdGFUYWJsZU1vZHVsZSB9IGZyb20gJ2FwcC9zaGFyZWQvZGF0YS10YWJsZS9kYXRhLXRhYmxlLm1vZHVsZSc7XG5pbXBvcnQgeyBVc2VySW1wb3J0TW9kdWxlIH0gZnJvbSAnYXBwL3NoYXJlZC91c2VyLWltcG9ydC91c2VyLWltcG9ydC5tb2R1bGUnO1xuaW1wb3J0IHsgTmd4RGF0YXRhYmxlTW9kdWxlIH0gZnJvbSAnQGZsYXZpb3NhbnRvcm85Mi9uZ3gtZGF0YXRhYmxlJztcbmltcG9ydCB7IEFydGVtaXNTaGFyZWRNb2R1bGUgfSBmcm9tICdhcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUnO1xuaW1wb3J0IHsgUm91dGVyTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbQXJ0ZW1pc0RhdGFUYWJsZU1vZHVsZSwgVXNlckltcG9ydE1vZHVsZSwgTmd4RGF0YXRhYmxlTW9kdWxlLCBBcnRlbWlzU2hhcmVkTW9kdWxlLCBSb3V0ZXJNb2R1bGVdLFxuICAgIGRlY2xhcmF0aW9uczogW0NvdXJzZUdyb3VwQ29tcG9uZW50XSxcbiAgICBleHBvcnRzOiBbQ291cnNlR3JvdXBDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBBcnRlbWlzQ291cnNlR3JvdXBNb2R1bGUge31cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMseUJBQXlCLG1CQUFtQixpQkFBb0M7QUFDekYsU0FBUyxzQkFBc0I7QUFLL0IsU0FBUyxTQUFTLGVBQWUsVUFBVSxXQUFXLFlBQVk7QUFFbEUsU0FBUyxRQUFRLGdCQUFnQjtBQUVqQyxTQUFTLGlCQUFpQjs7Ozs7O0FDcUJGLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFLSSxJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQW1DLElBQUEsb0JBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLENBQUE7O0FBQTRGLElBQUEsMEJBQUE7QUFDL0ksSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSx3QkFBQTs7OztBQUpRLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxDQUFBLE9BQUEsb0JBQUE7QUFGQSxJQUFBLHdCQUFBLGNBQUEsNkJBQUEsR0FBQSxLQUFBLE9BQUEsT0FBQSxJQUFBLE9BQUEsT0FBQSw0QkFBQSxFQUFBLENBQUE7QUFJUyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFFBQUEsT0FBQSxNQUFBO0FBQXNDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsR0FBQSxHQUFBLG1FQUFBLENBQUE7Ozs7O0FBSW5ELElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFLSSxJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHVCQUFBLEdBQUEsV0FBQSxDQUFBO0FBQW1DLElBQUEsb0JBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLENBQUE7O0FBQXlFLElBQUEsMEJBQUE7QUFDNUgsSUFBQSxvQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSx3QkFBQTs7OztBQUpRLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxDQUFBLE9BQUEsb0JBQUE7QUFGQSxJQUFBLHdCQUFBLGNBQUEsNkJBQUEsR0FBQSxLQUFBLE9BQUEsT0FBQSxFQUFBLENBQUE7QUFJUyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFFBQUEsT0FBQSxNQUFBO0FBQXNDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsR0FBQSxHQUFBLGdEQUFBLENBQUE7Ozs7O0FBM0NuRSxJQUFBLG9CQUFBLEdBQUEsWUFBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLENBQUE7O0FBQTJELElBQUEsMEJBQUE7QUFDL0QsSUFBQSxvQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw0QkFBQSxHQUFBLEdBQUE7QUFDSSxJQUFBLG9CQUFBLEVBQUE7O0FBQ0osSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHVCQUFBLElBQUEsSUFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsR0FBQTtBQUFHLElBQUEsb0JBQUEsRUFBQTs7QUFBeUUsSUFBQSwwQkFBQTtBQUM1RSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsS0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsdUJBQUEsSUFBQSx1QkFBQSxDQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsRUFBQTs7QUFDSixJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLEtBQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsdUJBQUEsSUFBQSxXQUFBLENBQUE7QUFBcUMsSUFBQSxvQkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsRUFBQTs7QUFBZ0UsSUFBQSwwQkFBQTtBQUNySCxJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDBCQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHVCQUFBLElBQUEsSUFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsR0FBQTtBQUFHLElBQUEsb0JBQUEsRUFBQTs7QUFBOEUsSUFBQSwwQkFBQTtBQUNqRixJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsdUJBQUEsSUFBQSx1QkFBQSxDQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUNJLElBQUEsb0JBQUEsRUFBQTs7QUFDSixJQUFBLDBCQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLHdFQUFBLElBQUEsRUFBQSxFQVFDLElBQUEsd0VBQUEsSUFBQSxDQUFBO0FBVUwsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFBQSxJQUFBLHVCQUFBLElBQUEsSUFBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsVUFBQSxDQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLEVBQUE7O0FBQTBFLElBQUEsMEJBQUE7QUFDcEYsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwwQkFBQTtBQUNKLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsWUFBQTtBQUFBLElBQUEsMEJBQUE7QUFDSixJQUFBLG9CQUFBLElBQUEsUUFBQTs7OztBQXJEZ0IsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxHQUFBLElBQUEsa0NBQUEsQ0FBQTtBQUVBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEseUJBQUEsSUFBQSxJQUFBLHdDQUFBLEdBQUEsb0JBQUE7QUFLRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLElBQUEsSUFBQSxnREFBQSxDQUFBO0FBRW9DLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsa0JBQUEsT0FBQSxvQkFBQTtBQUUvQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDhCQUFBLHlCQUFBLElBQUEsSUFBQSxxQ0FBQSxHQUFBLHdCQUFBO0FBRUQsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxjQUFBLDZCQUFBLElBQUEsS0FBQSxPQUFBLE9BQUEsRUFBQSxDQUFBO0FBQ1UsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxRQUFBLE9BQUEsUUFBQTtBQUF3QyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLElBQUEsSUFBQSx1Q0FBQSxDQUFBO0FBTXRELElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsK0JBQUEseUJBQUEsSUFBQSxJQUFBLHFEQUFBLENBQUE7QUFFeUMsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxrQkFBQSxPQUFBLG1DQUFBO0FBRXBDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsOEJBQUEseUJBQUEsSUFBQSxJQUFBLDBDQUFBLEdBQUEsd0JBQUE7QUFFSixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLElBQUEsT0FBQSxzQ0FBQSxLQUFBLEVBQUE7QUFTQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLElBQUEsQ0FBQSxPQUFBLHNDQUFBLEtBQUEsRUFBQTtBQWFJLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsY0FBQSw2QkFBQSxJQUFBLEtBQUEsT0FBQSxPQUFBLEVBQUEsQ0FBQSxFQUFvRSxZQUFBLENBQUEsT0FBQSxpQkFBQTtBQUNsRSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLElBQUEsSUFBQSxpREFBQSxDQUFBOzs7QURyRDFCLHdCQWlCYTtBQWpCYjs7QUFFQTtBQUVBO0FBQ0E7QUFJQTs7Ozs7Ozs7Ozs7QUFRTSxJQUFPLG1DQUFQLE1BQU8sa0NBQWdDO01BVzdCO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFkWixZQUFZO01BQ1o7TUFDQSx1QkFBdUI7TUFDdkIsc0NBQXNDO01BRXRDLFdBQVc7TUFDWCxTQUFTO01BRVQsZ0JBQWdCLElBQUksUUFBTztNQUMzQixZQUNZLGdCQUNBLHlCQUNBLGNBQ0Esb0NBQ0EsS0FBc0I7QUFKdEIsYUFBQSxpQkFBQTtBQUNBLGFBQUEsMEJBQUE7QUFDQSxhQUFBLGVBQUE7QUFDQSxhQUFBLHFDQUFBO0FBQ0EsYUFBQSxNQUFBO01BQ1Q7TUFFSCxJQUFJLG9CQUFpQjtBQUNqQixlQUFPLEtBQUssd0JBQXdCLEtBQUs7TUFDN0M7TUFFQSxXQUFRO0FBQ0osYUFBSyxZQUFZO0FBQ2pCLGFBQUssZUFBZSxTQUNmLEtBQ0csS0FBSyxDQUFDLEdBQ04sVUFBVSxDQUFDLFdBQVU7QUFDakIsZ0JBQU0sV0FBVyxPQUFPLE9BQU8sSUFBSSxVQUFVLENBQUM7QUFDOUMsaUJBQU8sY0FBYyxDQUFDLEtBQUssd0JBQXdCLEtBQUssUUFBUSxHQUFHLEtBQUssbUNBQW1DLGVBQWUsUUFBUSxDQUFDLENBQUM7UUFDeEksQ0FBQyxHQUNELFNBQVMsTUFBTyxLQUFLLFlBQVksS0FBTSxHQUN2QyxVQUFVLEtBQUssYUFBYSxDQUFDLEVBRWhDLFVBQVU7VUFDUCxNQUFNLENBQUMsQ0FBQyxjQUFjLG1CQUFtQixNQUFLO0FBQzFDLGdCQUFJLGFBQWEsTUFBTTtBQUNuQixtQkFBSyxTQUFTLGFBQWE7QUFDM0IsbUJBQUssdUJBQXVCLENBQUMsQ0FBQyxLQUFLLE9BQU87O0FBRTlDLGdCQUFJLG9CQUFvQixNQUFNO0FBQzFCLG1CQUFLLE9BQU8sOEJBQThCLG9CQUFvQjtBQUM5RCxtQkFBSyxzQ0FBc0MsQ0FBQyxDQUFDLEtBQUssT0FBTzs7VUFFakU7VUFDQSxPQUFPLENBQUMsUUFBMkIsUUFBUSxLQUFLLGNBQWMsR0FBRztTQUNwRSxFQUNBLElBQUksTUFBTSxLQUFLLElBQUksY0FBYSxDQUFFO01BQzNDO01BRUEsY0FBVztBQUNQLGFBQUssY0FBYyxLQUFJO0FBQ3ZCLGFBQUssY0FBYyxTQUFRO01BQy9COzt5QkFyRFMsbUNBQWdDLCtCQUFBLGlCQUFBLEdBQUEsK0JBQUEsdUJBQUEsR0FBQSwrQkFBQSxZQUFBLEdBQUEsK0JBQUEsa0NBQUEsR0FBQSwrQkFBQSxvQkFBQSxDQUFBO01BQUE7Z0VBQWhDLG1DQUFnQyxXQUFBLENBQUEsQ0FBQSwrQkFBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLEdBQUEsQ0FBQSxNQUFBLFlBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsT0FBQSxZQUFBLEdBQUEsb0JBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLGVBQUEsVUFBQSxRQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxNQUFBLGlCQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLE9BQUEsaUJBQUEsR0FBQSxvQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsZUFBQSxVQUFBLFFBQUEsR0FBQSxjQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxlQUFBLFVBQUEsUUFBQSxHQUFBLFlBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSwwQ0FBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ2pCN0MsVUFBQSw0QkFBQSxHQUFBLG1DQUFBLENBQUE7QUFDSSxVQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsd0JBQUEsR0FBQSx5REFBQSxJQUFBLEVBQUE7QUF5REosVUFBQSwwQkFBQTtBQUNBLFVBQUEsb0JBQUEsR0FBQSxJQUFBOzs7QUEzRGlDLFVBQUEsd0JBQUEsYUFBQSxJQUFBLFNBQUE7QUFDN0IsVUFBQSx1QkFBQSxDQUFBO0FBQUEsVUFBQSwyQkFBQSxHQUFBLElBQUEsU0FBQSxJQUFBLEVBQUE7Ozs7O29GRGdCUyxrQ0FBZ0MsRUFBQSxXQUFBLG1DQUFBLENBQUE7SUFBQSxHQUFBOzs7OztBRWpCN0MsU0FBUywyQkFBQUEsMEJBQXlCLGFBQUFDLFlBQVcsY0FBYyxPQUEwQixjQUFjO0FBQ25HLFNBQVMsYUFBd0Isa0JBQWtCO0FBQ25ELFNBQVMscUJBQXFCOzs7Ozs7O0FDNkJFLElBQUEscUJBQUEsR0FBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7OztBQUZRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMENBQUEsMEJBQUEsR0FBQSxHQUFBLHdFQUFBLEdBQUEsb0NBQUE7Ozs7O0FBSUosSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLHFCQUFBLENBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTs7O0FBRlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSwwQ0FBQSwwQkFBQSxHQUFBLEdBQUEsMkRBQUEsR0FBQSxvQ0FBQTs7Ozs7QUFJSixJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsS0FBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLGdDQUFBOzs7QUFGUSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLDBDQUFBLDBCQUFBLEdBQUEsR0FBQSxrRUFBQSxHQUFBLG9DQUFBOzs7OztBQWJaLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsOEZBQUEsR0FBQSxDQUFBLEVBSUMsR0FBQSw4RkFBQSxHQUFBLENBQUEsRUFBQSxHQUFBLDhGQUFBLEdBQUEsQ0FBQTtBQVdMLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFoQlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsaUJBQUEsT0FBQSxPQUFBLE9BQUEsY0FBQSxVQUFBLE9BQUEsT0FBQSxPQUFBLGNBQUEsT0FBQSw4QkFBQSxPQUFBLGlCQUFBLE9BQUEsT0FBQSxPQUFBLGNBQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxjQUFBLE9BQUEsWUFBQSxJQUFBLEVBQUE7QUFLQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxpQkFBQSxPQUFBLE9BQUEsT0FBQSxjQUFBLFVBQUEsT0FBQSxPQUFBLE9BQUEsY0FBQSxPQUFBLG9CQUFBLElBQUEsRUFBQTtBQUtBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsSUFBQSxPQUFBLGlCQUFBLE9BQUEsT0FBQSxPQUFBLGNBQUEsVUFBQSxPQUFBLE9BQUEsT0FBQSxjQUFBLE9BQUEsb0JBQUEsSUFBQSxFQUFBOzs7OztBQWtCSSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxDQUFBOztBQUNKLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7OztBQUZRLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsMENBQUEsMEJBQUEsR0FBQSxHQUFBLHlGQUFBLEdBQUEsb0NBQUE7Ozs7OztBQXhEeEIsSUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUFxQyxJQUFBLHlCQUFBLFlBQUEsU0FBQSwyRkFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQVksMEJBQUEsT0FBQSxXQUFBLENBQVk7SUFBQSxDQUFBO0FBQ3pELElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQXVDLElBQUEscUJBQUEsQ0FBQTs7QUFBK0UsSUFBQSwyQkFBQTtBQUN0SCxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUtJLElBQUEseUJBQUEsU0FBQSxTQUFBLDBGQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBUywwQkFBQSxPQUFBLG9CQUFBLENBQXFCO0lBQUEsQ0FBQTs7QUFMbEMsSUFBQSwyQkFBQTtBQVdBLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsd0JBQUEsSUFBQSxTQUFBLENBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsVUFBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFdBQUEsQ0FBQTtBQUNKLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsaUJBQUEsSUFBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEVBQUE7O0FBQ0osSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSxnRkFBQSxHQUFBLENBQUE7QUFvQkEsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLElBQUEsU0FBQSxFQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsRUFBQTs7QUFDSixJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFzRSxJQUFBLHFCQUFBLEVBQUE7O0FBRXBFLElBQUEsMkJBQUE7QUFDRixJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsZ0ZBQUEsR0FBQSxDQUFBO0FBS0osSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsU0FBQSxFQUFBO0FBQXVCLElBQUEscUJBQUEsRUFBQTs7QUFBMkYsSUFBQSwyQkFBQTtBQUNsSCxJQUFBLHFCQUFBLElBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBc0QsSUFBQSxxQkFBQSxFQUFBOztBQUVwRCxJQUFBLDJCQUFBO0FBQ0YsSUFBQSxxQkFBQSxJQUFBLG9DQUFBO0FBQUEsSUFBQSx3QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBdUQsSUFBQSxxQkFBQSxFQUFBOztBQUVyRCxJQUFBLDJCQUFBO0FBQ04sSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBdUUsSUFBQSxxQkFBQSxFQUFBOztBQUVyRSxJQUFBLDJCQUFBO0FBQ04sSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEVBQUE7O0FBQXVGLElBQUEsMkJBQUE7QUFDakcsSUFBQSxxQkFBQSxJQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxZQUFBOzs7OztBQXZGc0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxhQUFBLE9BQUEsSUFBQTtBQUc2QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLEdBQUEsSUFBQSxzREFBQSxDQUFBO0FBTS9CLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEsY0FBQSxPQUFBLGVBQUE7QUFFQSxJQUFBLHlCQUFBLFNBQUEsMEJBQUEsSUFBQSxJQUFBLE9BQUEsaUJBQUEsT0FBQSxPQUFBLE9BQUEsY0FBQSxPQUFBLGFBQUEsUUFBQSxJQUFBLENBQUEsRUFBaUYsc0JBQUEsR0FBQTtBQUtyRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGVBQUEsR0FBQSxFQUFzQixjQUFBLE9BQUE7QUFDTixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLHNCQUFBLEdBQUE7QUFDbkMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLE9BQUEsYUFBQTtBQUVFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsa0JBQUEsQ0FBQSxFQUFvQixjQUFBLFVBQUE7QUFHbkMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSw4QkFBQSwwQkFBQSxJQUFBLElBQUEsNERBQUEsR0FBQSx3QkFBQTtBQUVKLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsS0FBQSxPQUFBLGlCQUFBLE9BQUEsT0FBQSxPQUFBLGNBQUEsY0FBQSxPQUFBLGlCQUFBLE9BQUEsT0FBQSxPQUFBLGNBQUEsV0FBQSxPQUFBLGlCQUFBLE9BQUEsT0FBQSxPQUFBLGNBQUEsWUFBQSxLQUFBLEVBQUE7QUFvQkssSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxVQUFBLENBQUEsT0FBQSxtQkFBQSxPQUFBLE1BQUEsQ0FBQTtBQUlPLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsc0NBQUEsMEJBQUEsSUFBQSxJQUFBLHdFQUFBLEdBQUEsZ0NBQUE7QUFFa0UsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxJQUFBLElBQUEsOEVBQUEsQ0FBQTtBQUd0RSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLElBQUEsT0FBQSw2QkFBQSxLQUFBLEVBQUE7QUFPb0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxVQUFBLEVBQUEsT0FBQSxtQ0FBQSxPQUFBLE9BQUEsT0FBQSxnQ0FBQSxNQUFBO0FBQ0csSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSwwQkFBQSxJQUFBLElBQUEsa0VBQUEsQ0FBQTtBQUUyRyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFNBQUEsSUFBQTtBQUN4RSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSxtRUFBQSxDQUFBO0FBR2lFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsU0FBQSxLQUFBO0FBQ2hFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsMEJBQUEsSUFBQSxJQUFBLG9FQUFBLENBQUE7QUFJWSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSx3RUFBQSxDQUFBO0FBUVgsSUFBQSx3QkFBQSxFQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLENBQUEsT0FBQSxnQkFBQTtBQUN0RCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDBCQUFBLElBQUEsSUFBQSxPQUFBLGFBQUEsd0JBQUEsdUJBQUEsQ0FBQTs7O0FEckZsQyxJQWlCYTtBQWpCYjs7QUFHQTs7O0FBY00sSUFBTywyQ0FBUCxNQUFPLDBDQUF3QztNQXFCN0I7TUFuQnBCLFdBQWdEO1FBQzVDLFFBQVE7UUFDUixnQ0FBZ0M7UUFDaEMsMEJBQTBCOztNQUVyQixhQUFhO01BQ1osZ0JBQW1FLElBQUksYUFBWTtNQUc3RjtNQUVBLGdCQUFnQjtNQUVQLHFCQUFxQjtNQUU5QjtNQUVBO01BRUEsWUFBb0IsSUFBZTtBQUFmLGFBQUEsS0FBQTtNQUFrQjtNQUV0QyxJQUFJLGdCQUFhO0FBQ2IsZUFBTyxLQUFLLEtBQUssSUFBSSxRQUFRO01BQ2pDO01BRUEsSUFBSSxrQ0FBK0I7QUFDL0IsZUFBTyxLQUFLLEtBQUssSUFBSSwwQkFBMEI7TUFDbkQ7TUFFQSxJQUFJLHdDQUFxQztBQUNyQyxlQUFPLEtBQUssS0FBSyxJQUFJLGdDQUFnQztNQUN6RDtNQUVBLElBQUksbUJBQWdCO0FBQ2hCLGVBQU8sQ0FBQyxLQUFLLEtBQUs7TUFDdEI7TUFFQSxXQUFRO0FBQ0osYUFBSyxlQUFjO01BQ3ZCO01BQ0EsY0FBVztBQUNQLGFBQUssZUFBYztBQUNuQixZQUFJLEtBQUssY0FBYyxLQUFLLFVBQVU7QUFDbEMsZUFBSyxjQUFjLEtBQUssUUFBUTs7TUFFeEM7TUFDUSxjQUFjLFVBQTZDO0FBQy9ELGFBQUsseUJBQXlCLFNBQVM7QUFDdkMsYUFBSyxLQUFLLFdBQVcsUUFBUTtNQUNqQztNQUVBLElBQUksNkJBQTBCO0FBQzFCLFlBQUksQ0FBQyxLQUFLLFlBQVk7QUFDbEIsaUJBQU87O0FBRVgsWUFBSSxLQUFLLDJCQUEyQixRQUFXO0FBQzNDLGlCQUFPOztBQUVYLGVBQU8sS0FBSywwQkFBMEIsS0FBSyxpQ0FBaUMsVUFBVTtNQUMxRjtNQUVRLGlCQUFjO0FBQ2xCLFlBQUksS0FBSyxNQUFNO0FBQ1g7O0FBR0osYUFBSyxPQUFPLEtBQUssR0FBRyxNQUFNO1VBQ3RCLFFBQVEsQ0FBQyxRQUFXLFdBQVcsUUFBUTtVQUN2QywwQkFBMEIsQ0FBQyxLQUFLO1VBQ2hDLGdDQUFnQyxDQUFDLEtBQUs7U0FDekM7TUFDTDtNQUVBLGFBQVU7QUFDTixhQUFLLGNBQWMsS0FBSyxtQkFBSyxLQUFLLEtBQUssTUFBTztNQUNsRDtNQUVBLElBQUksa0JBQWU7QUFDZixZQUFJLEtBQUssZUFBZTtBQUNwQixpQkFBTyxLQUFLLGNBQWMsWUFBWSxLQUFLLGNBQWMsV0FBVyxLQUFLLGNBQWM7ZUFDcEY7QUFDSCxpQkFBTzs7TUFFZjtNQUVBLHNCQUFtQjtBQUNmLFlBQUksS0FBSyxlQUFlO0FBQ3BCLGVBQUssY0FBYyxjQUFhOztNQUV4Qzs7eUJBM0ZTLDJDQUF3QyxnQ0FBQSxlQUFBLENBQUE7TUFBQTtpRUFBeEMsMkNBQXdDLFdBQUEsQ0FBQSxDQUFBLHdDQUFBLENBQUEsR0FBQSxRQUFBLEVBQUEsVUFBQSxZQUFBLFlBQUEsY0FBQSxRQUFBLFNBQUEsR0FBQSxTQUFBLEVBQUEsZUFBQSxnQkFBQSxHQUFBLFVBQUEsQ0FBQSxrQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLGFBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxPQUFBLFVBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxNQUFBLFVBQUEsWUFBQSxJQUFBLFlBQUEsSUFBQSxHQUFBLGdCQUFBLEdBQUEsU0FBQSxzQkFBQSxPQUFBLEdBQUEsQ0FBQSxtQkFBQSxVQUFBLEdBQUEsMkJBQUEsR0FBQSxlQUFBLFlBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLE9BQUEsaUJBQUEsR0FBQSxvQkFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLFlBQUEsR0FBQSxDQUFBLFVBQUEsRUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsUUFBQSxZQUFBLG1CQUFBLDRCQUFBLE1BQUEsNEJBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsT0FBQSw0QkFBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxNQUFBLGVBQUEsR0FBQSxhQUFBLHVCQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsUUFBQSxTQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsbUJBQUEsa0NBQUEsUUFBQSxTQUFBLE1BQUEsVUFBQSxnQkFBQSxPQUFBLFdBQUEsSUFBQSxHQUFBLGFBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxPQUFBLFVBQUEsR0FBQSxPQUFBLHVCQUFBLEdBQUEsQ0FBQSxtQkFBQSxrQ0FBQSxRQUFBLFNBQUEsTUFBQSxXQUFBLGdCQUFBLE9BQUEsR0FBQSxhQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsT0FBQSxXQUFBLEdBQUEsT0FBQSx1QkFBQSxHQUFBLENBQUEsTUFBQSxnQkFBQSxHQUFBLGFBQUEsdUJBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxPQUFBLE1BQUEsR0FBQSxDQUFBLE1BQUEsZ0JBQUEsUUFBQSxVQUFBLEdBQUEsT0FBQSxlQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLGNBQUEsR0FBQSxDQUFBLFFBQUEsU0FBQSxNQUFBLDBCQUFBLEdBQUEsU0FBQSxjQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsa0RBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7QUNqQnJELFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUFBLFVBQUEseUJBQUEsR0FBQSxpRUFBQSxJQUFBLEVBQUE7QUF5RkosVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsR0FBQSxJQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsR0FBQSxJQUFBOzs7QUEzRlEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxHQUFBLElBQUEsT0FBQSxJQUFBLEVBQUE7Ozs7O3FGRGVLLDBDQUF3QyxFQUFBLFdBQUEsMkNBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFakJyRCxTQUFTLDJCQUFBQywwQkFBeUIscUJBQUFDLG9CQUFtQixhQUFBQyxrQkFBb0M7QUFFekYsU0FBUyxrQkFBQUMsaUJBQWdCLGNBQWM7QUFLdkMsU0FBUyxZQUFBQyxXQUFVLGFBQUFDLFlBQVcsUUFBQUMsT0FBTSxhQUFBQyxrQkFBaUI7QUFJckQsU0FBUyxXQUFBQyxnQkFBZTs7O0FBWHhCLElBbUJhO0FBbkJiOztBQUNBO0FBRUE7QUFDQTtBQUVBO0FBR0E7QUFHQTs7Ozs7Ozs7QUFPTSxJQUFPLDZDQUFQLE1BQU8sNENBQTBDO01BUXZDO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUVBO01BZFosZ0JBQWdCLElBQUlBLFNBQU87TUFFM0IsaUNBQWlDLElBQUksNEJBQTJCO01BQ2hFO01BQ0E7TUFFQSxZQUNZLGdCQUNBLFFBQ0Esb0NBQ0EseUJBQ0EsY0FDQSxzQkFFQSxLQUFzQjtBQVB0QixhQUFBLGlCQUFBO0FBQ0EsYUFBQSxTQUFBO0FBQ0EsYUFBQSxxQ0FBQTtBQUNBLGFBQUEsMEJBQUE7QUFDQSxhQUFBLGVBQUE7QUFDQSxhQUFBLHVCQUFBO0FBRUEsYUFBQSxNQUFBO01BQ1Q7TUFFSCxXQUFRO0FBQ0osYUFBSyxZQUFZO0FBQ2pCLGFBQUssZUFBZSxTQUNmLEtBQ0dGLE1BQUssQ0FBQyxHQUNORCxXQUFVLENBQUMsV0FBVTtBQUNqQixnQkFBTSxXQUFXLE9BQU8sT0FBTyxJQUFJLFVBQVUsQ0FBQztBQUM5QyxpQkFBTyxLQUFLLHdCQUF3QixLQUFLLFFBQVE7UUFDckQsQ0FBQyxHQUNERCxVQUFTLE1BQU8sS0FBSyxZQUFZLEtBQU0sR0FDdkNHLFdBQVUsS0FBSyxhQUFhLENBQUMsRUFFaEMsVUFBVTtVQUNQLE1BQU0sQ0FBQyxpQkFBZ0I7QUFDbkIsZ0JBQUksYUFBYSxNQUFNO0FBQ25CLG1CQUFLLFNBQVMsYUFBYTtBQUMzQixtQkFBSyxpQ0FBaUMsSUFBSSw0QkFBMkI7O1VBRTdFO1VBQ0EsT0FBTyxDQUFDLFFBQTJCLFFBQVEsS0FBSyxjQUFjLEdBQUc7U0FDcEUsRUFDQSxJQUFJLE1BQU0sS0FBSyxJQUFJLGNBQWEsQ0FBRTtNQUMzQztNQUVBLGtDQUFrQyxVQUE2QztBQUMzRSxjQUFNLEVBQUUsUUFBUSxnQ0FBZ0MseUJBQXdCLElBQUs7QUFDN0UsYUFBSyxZQUFZO0FBQ2pCLGFBQUssK0JBQStCLDJCQUEyQjtBQUMvRCxhQUFLLCtCQUErQixpQ0FBaUM7QUFDckUsYUFBSyxtQ0FDQSxPQUFPLEtBQUssZ0NBQWdDLEtBQUssT0FBTyxJQUFLLFVBQVUsQ0FBQSxDQUFFLEVBQ3pFLEtBQ0dILFVBQVMsTUFBSztBQUNWLGVBQUssWUFBWTtRQUNyQixDQUFDLEdBQ0RHLFdBQVUsS0FBSyxhQUFhLENBQUMsRUFFaEMsVUFBVTtVQUNQLE1BQU0sQ0FBQyxTQUFRO0FBQ1gsaUJBQUssT0FBTyw4QkFBOEIsS0FBSztBQUMvQyxpQkFBSyxxQkFBcUIsYUFBYSxLQUFLLE1BQU07QUFDbEQsaUJBQUssT0FBTyxTQUFTLENBQUMsc0JBQXNCLEtBQUssT0FBTyxJQUFLLDJCQUEyQixDQUFDO1VBQzdGO1VBQ0EsT0FBTyxDQUFDLFFBQTJCLFFBQVEsS0FBSyxjQUFjLEdBQUc7U0FDcEU7TUFDVDtNQUVBLGNBQVc7QUFDUCxhQUFLLGNBQWMsS0FBSTtBQUN2QixhQUFLLGNBQWMsU0FBUTtNQUMvQjs7eUJBcEVTLDZDQUEwQyxnQ0FBQSxrQkFBQSxHQUFBLGdDQUFBLFVBQUEsR0FBQSxnQ0FBQSxrQ0FBQSxHQUFBLGdDQUFBLHVCQUFBLEdBQUEsZ0NBQUEsWUFBQSxHQUFBLGdDQUFBLG9CQUFBLEdBQUEsZ0NBQUEscUJBQUEsQ0FBQTtNQUFBO2lFQUExQyw2Q0FBMEMsV0FBQSxDQUFBLENBQUEsMENBQUEsQ0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxRQUFBLFNBQUEsR0FBQSxTQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxVQUFBLGVBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxvREFBQSxJQUFBLEtBQUE7QUFBQSxZQUFBLEtBQUEsR0FBQTtBQ25CdkQsVUFBQSw2QkFBQSxHQUFBLG1DQUFBLENBQUE7QUFDSSxVQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFBLFVBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQUksVUFBQSxxQkFBQSxDQUFBOztBQUFtRixVQUFBLDJCQUFBO0FBQ3ZGLFVBQUEscUJBQUEsR0FBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNJLFVBQUEscUJBQUEsQ0FBQTs7QUFDSixVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsMENBQUEsQ0FBQTtBQUE2RCxVQUFBLHlCQUFBLGlCQUFBLFNBQUEscUhBQUEsUUFBQTtBQUFBLG1CQUFpQixJQUFBLGtDQUFBLE1BQUE7VUFBeUMsQ0FBQTtBQUN2SCxVQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDSixVQUFBLHFCQUFBLElBQUEsSUFBQTtBQUFBLFVBQUEsMkJBQUE7QUFDQSxVQUFBLHFCQUFBLElBQUEsSUFBQTs7O0FBUmlDLFVBQUEseUJBQUEsYUFBQSxJQUFBLFNBQUE7QUFDekIsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSxnQ0FBQSwwQkFBQSxHQUFBLEdBQUEsMERBQUEsQ0FBQTtBQUVBLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEsaUNBQUEsY0FBQSwwQkFBQSxHQUFBLEdBQUEsZ0VBQUEsR0FBQSxRQUFBO0FBRW9DLFVBQUEsd0JBQUEsQ0FBQTtBQUFBLFVBQUEseUJBQUEsY0FBQSxLQUFBLEVBQW9CLFVBQUEsSUFBQSxNQUFBOzs7OztxRkRjbkQsNENBQTBDLEVBQUEsV0FBQSw2Q0FBQSxDQUFBO0lBQUEsR0FBQTs7Ozs7QUVuQnZELFNBQVMsYUFBQUUsWUFBVyxnQkFBQUMsZUFBYyxTQUFBQyxRQUFrQixVQUFBQyxTQUFRLFdBQVcseUJBQXlCO0FBQ2hHLFNBQXFCLFdBQUFDLFVBQVMsVUFBVTtBQUN4QyxTQUE0QixvQkFBb0I7QUFJaEQsU0FBUyxZQUFZLEtBQUssYUFBQUMsWUFBVyxXQUFXO0FBR2hELFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsWUFBWSxtQkFBbUI7Ozs7Ozs7O0FDRnhCLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSwwQkFBQSxDQUFBO0FBR0ksSUFBQSx5QkFBQSxVQUFBLFNBQUEsd0ZBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFVLDBCQUFBLE9BQUEsYUFBQSxLQUFBLENBQW1CO0lBQUEsQ0FBQTtBQUVoQyxJQUFBLDJCQUFBO0FBQ0wsSUFBQSxxQkFBQSxHQUFBLGdCQUFBOzs7O0FBTFEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLE9BQUEsT0FBQSxFQUFBLEVBQXVCLGVBQUEsT0FBQSxXQUFBLEVBQUEsaUJBQUEsT0FBQSxhQUFBOzs7Ozs7QUFPM0IsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUF1QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSx1RUFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQVMsMEJBQUEsT0FBQSxzQkFBQSxDQUF1QjtJQUFBLENBQUE7QUFDbkUsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsQ0FBQTtBQUNBLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLENBQUE7QUFBOEQsSUFBQSxxQkFBQSxHQUFBLGtCQUFBO0FBQWtCLElBQUEsMkJBQUE7QUFDcEYsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQkFBQTs7OztBQUhpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsT0FBQSxVQUFBLEVBQW1CLGNBQUEsSUFBQTs7Ozs7O0FBeUN4QixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTRDLElBQUEseUJBQUEsU0FBQSxTQUFBLG1GQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLEVBQUE7QUFBQSxhQUFTLDBCQUFBLFlBQUEsT0FBZ0IsSUFBSSxDQUFDO0lBQUEsQ0FBQTtBQUN0RSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXdGLElBQUEscUJBQUEsR0FBQSxNQUFBO0FBQUcsSUFBQSwyQkFBQTtBQUMzRixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsWUFBQSxxQkFBQSxJQUFBLENBQUE7Ozs7O0FBS1QsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUEyRCxJQUFBLHFCQUFBLENBQUE7QUFBZSxJQUFBLDJCQUFBO0FBQzlFLElBQUEscUJBQUEsR0FBQSw0QkFBQTs7OztBQURPLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEscUNBQUEsY0FBQSwyQkFBQSxhQUFBLE9BQUEsT0FBQSxVQUFBLE9BQUEsRUFBQTtBQUF3RCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsVUFBQSxJQUFBLEdBQUE7Ozs7O0FBRTNELElBQUEscUJBQUEsQ0FBQTs7OztBQUFBLElBQUEsaUNBQUEsa0NBQUEsYUFBQSxPQUFBLE9BQUEsVUFBQSxJQUFBLDRCQUFBOzs7OztBQUhKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEseUJBQUEsR0FBQSwwRUFBQSxHQUFBLENBQUEsRUFFQyxHQUFBLDBFQUFBLEdBQUEsQ0FBQTs7OztBQUZELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsR0FBQSxRQUFBLFVBQUEsSUFBQSxDQUFBOzs7Ozs7QUFTQSxJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTRDLElBQUEseUJBQUEsU0FBQSxTQUFBLG9GQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxjQUFBLDRCQUFBLEVBQUE7QUFBQSxhQUFTLDBCQUFBLFlBQUEsT0FBZ0IsT0FBTyxDQUFDO0lBQUEsQ0FBQTtBQUN6RSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTRHLElBQUEscUJBQUEsR0FBQSxTQUFBO0FBQU0sSUFBQSwyQkFBQTtBQUNsSCxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLHdCQUFBLEdBQUEsV0FBQSxFQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQUZpQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsWUFBQSxxQkFBQSxPQUFBLENBQUE7Ozs7O0FBSWIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBVyxJQUFBLDJCQUFBO0FBQ3JCLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsU0FBQTs7Ozs7O0FBS04sSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE0QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSxvRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxFQUFBO0FBQUEsYUFBUywwQkFBQSxZQUFBLE9BQWdCLDJCQUEyQixDQUFDO0lBQUEsQ0FBQTtBQUM3RixJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXlILElBQUEscUJBQUEsR0FBQSx1QkFBQTtBQUFvQixJQUFBLDJCQUFBO0FBQzdJLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRmlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxZQUFBLHFCQUFBLDJCQUFBLENBQUE7Ozs7O0FBSWIsSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLENBQUE7QUFBVyxJQUFBLDJCQUFBO0FBQ3JCLElBQUEscUJBQUEsR0FBQSx3QkFBQTs7OztBQURVLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsU0FBQTs7Ozs7O0FBS04sSUFBQSxxQkFBQSxHQUFBLDRCQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE0QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSxvRkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsY0FBQSw0QkFBQSxFQUFBO0FBQUEsYUFBUywwQkFBQSxZQUFBLE9BQWdCLE1BQU0sQ0FBQztJQUFBLENBQUE7QUFDeEUsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUEyRyxJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFLLElBQUEsMkJBQUE7QUFDaEgsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFGaUIsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxRQUFBLFlBQUEscUJBQUEsTUFBQSxDQUFBOzs7OztBQUliLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxDQUFBO0FBQVcsSUFBQSwyQkFBQTtBQUNyQixJQUFBLHFCQUFBLEdBQUEsd0JBQUE7Ozs7QUFEVSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFNBQUE7Ozs7OztBQUtOLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEMsSUFBQSx5QkFBQSxTQUFBLFNBQUEsb0ZBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUE7QUFBQSxZQUFBLGNBQUEsNEJBQUEsRUFBQTtBQUFBLGFBQVMsMEJBQUEsWUFBQSxPQUFnQixPQUFPLENBQUM7SUFBQSxDQUFBO0FBQ3pFLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBNEcsSUFBQSxxQkFBQSxHQUFBLFNBQUE7QUFBTSxJQUFBLDJCQUFBO0FBQ2xILElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsd0JBQUEsR0FBQSxXQUFBLEVBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRmlCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxZQUFBLHFCQUFBLE9BQUEsQ0FBQTs7Ozs7QUFJYixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsQ0FBQTtBQUFXLElBQUEsMkJBQUE7QUFDckIsSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7O0FBRFUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxTQUFBOzs7OztBQUlrQyxJQUFBLHFCQUFBLEdBQUEsR0FBQTs7Ozs7O0FBRXhDLElBQUEscUJBQUEsR0FBQSw0QkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLEdBQUEsZ0NBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBS0ksSUFBQSx5QkFBQSxVQUFBLFNBQUEsdUZBQUE7QUFBQSxZQUFBLGNBQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsWUFBQSxZQUFBO0FBQUEsWUFBQSxVQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFVLDBCQUFBLFFBQUEsZ0JBQUEsU0FBQSxDQUFzQjtJQUFBLENBQUE7QUFHaEMsSUFBQSxxQkFBQSxHQUFBLG9DQUFBO0FBQUEsSUFBQSx3QkFBQSxHQUFBLFdBQUEsRUFBQTtBQUNKLElBQUEscUJBQUEsR0FBQSxnQ0FBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLEdBQUEsNEJBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0osSUFBQSxxQkFBQSxHQUFBLHdCQUFBOzs7OztBQVRZLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsY0FBQSxRQUFBLFdBQUEsTUFBQSxFQUFnQyxlQUFBLFVBQUEsS0FBQSxFQUFBLGVBQUEsUUFBQSxZQUFBO0FBTXZCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsUUFBQSxRQUFBLFdBQUE7Ozs7O0FBbkY3QixJQUFBLHFCQUFBLEdBQUEsZ0JBQUE7QUFBQSxJQUFBLDZCQUFBLEdBQUEsaUJBQUEsQ0FBQTtBQVlJLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsR0FBQSx3QkFBQSxDQUFBO0FBQ0ksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxHQUFBLDREQUFBLEdBQUEsR0FBQSxlQUFBLEVBQUE7QUFNQSxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLEdBQUEsNERBQUEsR0FBQSxHQUFBLGVBQUEsRUFBQTtBQU9KLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsd0JBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSw2REFBQSxHQUFBLEdBQUEsZUFBQSxFQUFBO0FBTUEsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDZEQUFBLEdBQUEsR0FBQSxlQUFBLEVBQUE7QUFHSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLHdCQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsNkRBQUEsR0FBQSxHQUFBLGVBQUEsRUFBQTtBQU1BLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSw2REFBQSxHQUFBLEdBQUEsZUFBQSxFQUFBO0FBR0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsNkJBQUEsSUFBQSx3QkFBQSxFQUFBO0FBQ0ksSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDZEQUFBLEdBQUEsR0FBQSxlQUFBLEVBQUE7QUFNQSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsNkRBQUEsR0FBQSxHQUFBLGVBQUEsRUFBQTtBQUdKLElBQUEscUJBQUEsSUFBQSxvQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDZCQUFBLElBQUEsd0JBQUEsRUFBQTtBQUNJLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSw2REFBQSxHQUFBLEdBQUEsZUFBQSxFQUFBO0FBTUEsSUFBQSxxQkFBQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxJQUFBLDZEQUFBLEdBQUEsR0FBQSxlQUFBLEVBQUE7QUFHSixJQUFBLHFCQUFBLElBQUEsb0JBQUE7QUFBQSxJQUFBLDJCQUFBO0FBQ0EsSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSw2QkFBQSxJQUFBLHdCQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLElBQUEsNkRBQUEsR0FBQSxHQUFBLGVBQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsSUFBQSw2REFBQSxHQUFBLEdBQUEsZUFBQSxFQUFBO0FBY0osSUFBQSxxQkFBQSxJQUFBLG9CQUFBO0FBQUEsSUFBQSwyQkFBQTtBQUNKLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFBLElBQUEsMkJBQUE7QUFDSixJQUFBLHFCQUFBLElBQUEsWUFBQTs7Ozs7QUF2RlEsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxTQUFBLFlBQUEsS0FBQSxFQUF3QixZQUFBLFlBQUEsUUFBQSxFQUFBLGNBQUEsWUFBQSxVQUFBLEVBQUEsZ0JBQUEsWUFBQSxZQUFBLEVBQUEsZ0JBQUEsWUFBQSxZQUFBLEVBQUEsYUFBQSxZQUFBLFNBQUEsRUFBQSxRQUFBLFlBQUEsSUFBQSxFQUFBLFlBQUEsT0FBQSxpQkFBQSxFQUFBLGNBQUEsWUFBQSxVQUFBO0FBVU0sSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLEVBQUEsRUFBZSxTQUFBLEVBQUEsRUFBQSxZQUFBLEdBQUE7QUFlVixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsR0FBQSxFQUFnQixTQUFBLEdBQUEsRUFBQSxZQUFBLEdBQUE7QUFXSSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFlBQUEsR0FBQSxFQUFnQixTQUFBLEdBQUEsRUFBQSxZQUFBLEdBQUE7QUFXckMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLEdBQUEsRUFBZ0IsU0FBQSxHQUFBLEVBQUEsWUFBQSxHQUFBO0FBV2YsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLEdBQUEsRUFBZ0IsU0FBQSxHQUFBO0FBV3JCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxHQUFBLEVBQWdCLFNBQUEsR0FBQTs7O0FEbkg5RCxnQkFhTSxVQUNBLGNBQ0EsV0FDQSx5QkFFQSxZQVdPO0FBN0JiOztBQUlBO0FBQ0E7QUFFQTtBQUNBOzs7Ozs7O0FBS0EsSUFBTSxXQUFXO0FBQ2pCLElBQU0sZUFBZTtBQUNyQixJQUFNLFlBQVk7QUFDbEIsSUFBTSwwQkFBMEI7QUFFaEMsSUFBTSxhQUFhO01BQ2YsZUFBZTtNQUNmLGtCQUFrQjs7QUFTaEIsSUFBTyx1QkFBUCxNQUFPLHNCQUFvQjtNQUNFO01BRy9CLGdCQUF3QixDQUFBO01BRXhCLHlCQUF5QjtNQUV6QixVQUFVO01BRVY7TUFFQSxnQkFBMkM7TUFFM0M7TUFFQTtNQUdBLGFBQXdFLE1BQU0sR0FBRyxJQUFJLGFBQXFCLEVBQUUsTUFBTSxDQUFBLEVBQUUsQ0FBRSxDQUFDO01BRXZILGlCQUFvRSxNQUFNLEdBQUcsSUFBSSxhQUFZLENBQVE7TUFFckcsc0JBQXlFLE1BQU0sR0FBRyxJQUFJLGFBQVksQ0FBUTtNQUUxRyx3QkFBNkQsTUFBSztNQUFFO01BR3BFLGVBQW1DLElBQUlKLGNBQVk7TUFFMUMsYUFBYTtNQUVkLG9CQUFvQixJQUFJRyxTQUFPO01BQ3ZDLGVBQWUsS0FBSyxrQkFBa0IsYUFBWTtNQUVsRCxjQUFjO01BQ2QsZUFBZTtNQUNmLGtCQUFrQjtNQUNsQixrQkFBa0I7TUFDbEIsV0FBK0I7TUFHL0IsYUFBYTtNQUNiLGNBQWM7TUFLZCxjQUFXO0FBQ1AsYUFBSyxrQkFBa0IsWUFBVztNQUN0QztNQVdBLGlCQUFpQixDQUFDLFlBQStFO0FBQzdGLGVBQU8sUUFBUSxLQUNYQyxXQUFVLENBQUMsRUFBRSxNQUFNLFlBQVcsTUFBTTtBQUNoQyxlQUFLLGVBQWU7QUFDcEIsZUFBSyxrQkFBa0I7QUFDdkIsY0FBSSxZQUFZLFNBQVMsR0FBRztBQUN4QixtQkFBTyxHQUFHLENBQUEsQ0FBRTs7QUFFaEIsZUFBSyxjQUFjO0FBQ25CLGlCQUFPLEtBQUssV0FBVyxXQUFXLEVBQzdCLEtBQUssSUFBSSxDQUFDLGtCQUFrQixjQUFjLElBQUssQ0FBQyxFQUNoRCxLQUNHLElBQUksQ0FBQyxVQUFTO0FBQ1YsZ0JBQUksTUFBTSxXQUFXLEdBQUc7QUFDcEIsbUJBQUssa0JBQWtCOztVQUUvQixDQUFDLEdBQ0QsV0FBVyxNQUFLO0FBQ1osaUJBQUssZUFBZTtBQUNwQixtQkFBTyxHQUFHLENBQUEsQ0FBRTtVQUNoQixDQUFDLENBQUM7UUFFZCxDQUFDLEdBQ0QsSUFBSSxNQUFLO0FBQ0wsZUFBSyxjQUFjO1FBQ3ZCLENBQUMsR0FDRCxJQUFJLENBQUMsVUFBUztBQUNWLHFCQUFXLE1BQUs7QUFDWixxQkFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFVBQVUsaUJBQWlCLFFBQVEsS0FBSztBQUM3RCxvQkFBTSxtQkFBbUIsS0FBSyxjQUFjLElBQUksQ0FBQyxTQUFTLEtBQUssRUFBRSxFQUFFLFNBQVMsTUFBTSxDQUFDLEVBQUUsRUFBRTtBQUN2RixtQkFBSyxVQUFVLGlCQUFpQixDQUFDLEVBQUUsbUJBQW1CLGFBQWEsWUFBWSxtQkFBbUIsVUFBVSxZQUFZLENBQUM7QUFDekgsa0JBQUksa0JBQWtCO0FBQ2xCLHFCQUFLLFVBQVUsaUJBQWlCLENBQUMsRUFBRSxVQUFVLElBQUksV0FBVyxhQUFhOzs7VUFHckYsQ0FBQztRQUNMLENBQUMsQ0FBQztNQUVWO01BU0EsdUJBQXVCLENBQUMsTUFBWSxhQUF3QztBQUV4RSxZQUFJLENBQUMsS0FBSyxjQUFjLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLFNBQVMsS0FBSyxFQUFFLEtBQUssS0FBSyxPQUFPO0FBQ3RFLGVBQUssa0JBQWtCO0FBQ3ZCLGVBQUssZUFBZSxLQUFLLEtBQUssRUFBRSxVQUFVO1lBQ3RDLE1BQU0sTUFBSztBQUNQLG1CQUFLLGtCQUFrQjtBQUd2QixtQkFBSyxjQUFjLEtBQUssSUFBSTtBQUc1Qix1QkFBUyxJQUFJO0FBR2IsbUJBQUssY0FBYyxXQUFXLGdCQUFnQjtZQUNsRDtZQUNBLE9BQU8sTUFBSztBQUNSLG1CQUFLLGtCQUFrQjtZQUMzQjtXQUNIO2VBQ0U7QUFFSCxtQkFBUyxJQUFJOztNQUVyQjtNQU9BLGdCQUFnQixNQUFVO0FBQ3RCLFlBQUksS0FBSyxPQUFPO0FBQ1osZUFBSyxvQkFBb0IsS0FBSyxLQUFLLEVBQUUsVUFBVTtZQUMzQyxNQUFNLE1BQUs7QUFDUCxtQkFBSyxnQkFBZ0IsS0FBSyxjQUFjLE9BQU8sQ0FBQyxNQUFNLEVBQUUsVUFBVSxLQUFLLEtBQUs7QUFDNUUsbUJBQUssa0JBQWtCLEtBQUssRUFBRTtZQUNsQztZQUNBLE9BQU8sQ0FBQyxVQUE2QixLQUFLLGtCQUFrQixLQUFLLE1BQU0sT0FBTztXQUNqRjs7TUFFVDtNQU9BLHdCQUF3QixDQUFDLFNBQWM7QUFDbkMsY0FBTSxFQUFFLE1BQU0sTUFBSyxJQUFLO0FBQ3hCLGVBQU8sR0FBRyxJQUFJLEtBQUssS0FBSztNQUM1QjtNQVFBLHFCQUFxQixDQUFDLFNBQXNCO0FBQ3hDLGVBQU8sS0FBSyxTQUFTO01BQ3pCO01BS0Esb0JBQW9CLE1BQUs7QUFDckIsZUFBTyxLQUFLO01BQ2hCO01BT0EsZ0JBQWdCLENBQUMsY0FBcUI7QUFDbEMsYUFBSyxXQUFXO0FBQ2hCLG1CQUFXLE1BQU8sS0FBSyxXQUFXLE1BQVU7TUFDaEQ7TUFLQSx3QkFBd0IsTUFBSztBQUN6QixZQUFJLEtBQUssY0FBYyxTQUFTLEdBQUc7QUFDL0IsZ0JBQU0sT0FBYyxLQUFLLGNBQWMsSUFBSSxDQUFDLFNBQWM7QUFDdEQsa0JBQU0sT0FBTyxDQUFBO0FBQ2IsaUJBQUssUUFBUSxJQUFJLEtBQUssTUFBTSxLQUFJLEtBQU07QUFDdEMsaUJBQUssWUFBWSxJQUFJLEtBQUssT0FBTyxLQUFJLEtBQU07QUFDM0MsaUJBQUssU0FBUyxJQUFJLEtBQUssT0FBTyxLQUFJLEtBQU07QUFDeEMsaUJBQUssdUJBQXVCLElBQUksS0FBSywyQkFBMkIsS0FBSSxLQUFNO0FBQzFFLG1CQUFPO1VBQ1gsQ0FBQztBQUNELGdCQUFNLE9BQU8sQ0FBQyxVQUFVLGNBQWMsV0FBVyx1QkFBdUI7QUFDeEUsZUFBSyxZQUFZLE1BQU0sSUFBSTs7TUFFbkM7TUFRQSxjQUFjLENBQUMsTUFBYSxTQUFrQjtBQUMxQyxjQUFNLFVBQVU7VUFDWixnQkFBZ0I7VUFDaEIsY0FBYztVQUNkLFlBQVk7VUFDWixXQUFXO1VBQ1gsVUFBVSxLQUFLO1VBQ2YsYUFBYTtVQUNiLFFBQVE7VUFDUixTQUFTOztBQUViLGNBQU0sY0FBYyxJQUFJLFlBQVksT0FBTztBQUMzQyxvQkFBWSxZQUFZLElBQUk7TUFDaEM7O3lCQWxPUyx1QkFBb0I7TUFBQTtpRUFBcEIsdUJBQW9CLFdBQUEsQ0FBQSxDQUFBLGtCQUFBLENBQUEsR0FBQSxXQUFBLFNBQUEsMkJBQUEsSUFBQSxLQUFBO0FBQUEsWUFBQSxLQUFBLEdBQUE7b0NBQ2xCLG9CQUFrQixDQUFBOzs7Ozs7Ozs7QUM5QmpDLFVBQUEsNkJBQUEsR0FBQSxLQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLGdCQUFBO0FBQUEsVUFBQSwyQkFBQSxDQUFBO0FBQ0osVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxHQUFBLFlBQUE7QUFBQSxVQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBQ0ksVUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBQUEsVUFBQSx5QkFBQSxJQUFBLDhDQUFBLEdBQUEsQ0FBQSxFQU9DLElBQUEsOENBQUEsR0FBQSxDQUFBO0FBT0wsVUFBQSwyQkFBQTtBQUNKLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSwyQkFBQTtBQUNBLFVBQUEscUJBQUEsSUFBQSxRQUFBO0FBQUEsVUFBQSw2QkFBQSxJQUFBLGtCQUFBLENBQUE7QUFrQkksVUFBQSx5QkFBQSxzQkFBQSxTQUFBLDRFQUFBLFFBQUE7QUFBQSxtQkFBc0IsSUFBQSxzQkFBQSxNQUFBO1VBQTZCLENBQUE7QUFFbkQsVUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBQSxVQUFBLHlCQUFBLElBQUEsOENBQUEsSUFBQSxJQUFBLGFBQUE7QUEyRkosVUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0osVUFBQSxxQkFBQSxJQUFBLElBQUE7QUFBQSxVQUFBLDJCQUFBO0FBQ0EsVUFBQSxxQkFBQSxJQUFBLElBQUE7OztBQWpJWSxVQUFBLHdCQUFBLEVBQUE7QUFBQSxVQUFBLDRCQUFBLEtBQUEsSUFBQSxVQUFBLE9BQUEsT0FBQSxJQUFBLE9BQUEsdUJBQUEsS0FBQSxFQUFBO0FBUUEsVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSw0QkFBQSxLQUFBLElBQUEsVUFBQSxPQUFBLE9BQUEsSUFBQSxPQUFBLHdCQUFBLElBQUEsY0FBQSxTQUFBLElBQUEsS0FBQSxFQUFBO0FBVUosVUFBQSx3QkFBQSxDQUFBO0FBQUEsVUFBQSx5QkFBQSxhQUFBLElBQUEsc0JBQUEsRUFBb0MsZUFBQSxJQUFBLFdBQUEsRUFBQSxnQkFBQSxJQUFBLFlBQUEsRUFBQSxtQkFBQSxJQUFBLGVBQUEsRUFBQSxtQkFBQSxJQUFBLGVBQUEsRUFBQSxlQUFBLElBQUEsYUFBQSxFQUFBLGdCQUFBLDhCQUFBLElBQUFDLElBQUEsQ0FBQSxFQUFBLHdCQUFBLElBQUEsa0JBQUEsRUFBQSx5QkFBQSxJQUFBLHFCQUFBLEVBQUEsbUJBQUEsSUFBQSxjQUFBLEVBQUEsK0JBQUEsSUFBQSxvQkFBQTs7Ozs7cUZESS9CLHNCQUFvQixFQUFBLFdBQUEsdUJBQUEsQ0FBQTtJQUFBLEdBQUE7Ozs7O0FFN0JqQyxTQUFTLGdCQUFnQjtBQUl6QixTQUFTLDBCQUEwQjtBQUVuQyxTQUFTLG9CQUFvQjs7QUFON0IsSUFhYTtBQWJiOztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBUU0sSUFBTywyQkFBUCxNQUFPLDBCQUF3Qjs7eUJBQXhCLDJCQUF3QjtNQUFBO2dFQUF4QiwwQkFBd0IsQ0FBQTtvRUFKdkIsd0JBQXdCLGtCQUFrQixvQkFBb0IscUJBQXFCLFlBQVksRUFBQSxDQUFBOzs7OyIsIm5hbWVzIjpbIkNoYW5nZURldGVjdGlvblN0cmF0ZWd5IiwiQ29tcG9uZW50IiwiQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kiLCJDaGFuZ2VEZXRlY3RvclJlZiIsIkNvbXBvbmVudCIsIkFjdGl2YXRlZFJvdXRlIiwiZmluYWxpemUiLCJzd2l0Y2hNYXAiLCJ0YWtlIiwidGFrZVVudGlsIiwiU3ViamVjdCIsIkNvbXBvbmVudCIsIkV2ZW50RW1pdHRlciIsIklucHV0IiwiT3V0cHV0IiwiU3ViamVjdCIsInN3aXRjaE1hcCIsIl9jMCJdfQ==