import {
  isPlatformBrowser
} from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-AUZKQX33.js?v=b97f8625";
import {
  APP_INITIALIZER,
  Inject,
  Injectable,
  InjectionToken,
  NgModule,
  NgZone,
  Optional,
  PLATFORM_ID,
  setClassMetadata,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵinject
} from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-Z3IUVWPC.js?v=b97f8625";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-TCDXYYBP.js?v=b97f8625";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-Y5GOFOG4.js?v=b97f8625";
import {
  Subject,
  distinctUntilChanged,
  filter,
  map,
  of,
  shareReplay,
  switchMap
} from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-PWQY6O7T.js?v=b97f8625";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-URW6DBRY.js?v=b97f8625";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/chunk-NI5XS6XH.js?v=b97f8625";

// node_modules/ngx-webstorage/fesm2022/ngx-webstorage.mjs
var StorageStrategies;
(function(StorageStrategies2) {
  StorageStrategies2["Local"] = "local_strategy";
  StorageStrategies2["Session"] = "session_strategy";
  StorageStrategies2["InMemory"] = "in_memory_strategy";
})(StorageStrategies || (StorageStrategies = {}));
var CompatHelper = class {
  static isStorageAvailable(storage) {
    let available = true;
    try {
      if (typeof storage === "object") {
        storage.setItem("test-storage", "foobar");
        storage.removeItem("test-storage");
      } else
        available = false;
    } catch (e) {
      available = false;
    }
    return available;
  }
};
function noop() {
}
var DefaultPrefix = "ngx-webstorage";
var DefaultSeparator = "|";
var DefaultIsCaseSensitive = false;
var _StorageKeyManager = class _StorageKeyManager {
  static normalize(raw) {
    raw = _StorageKeyManager.isCaseSensitive ? raw : raw.toLowerCase();
    return `${_StorageKeyManager.prefix}${_StorageKeyManager.separator}${raw}`;
  }
  static isNormalizedKey(key) {
    return key.indexOf(_StorageKeyManager.prefix + _StorageKeyManager.separator) === 0;
  }
  static setPrefix(prefix) {
    _StorageKeyManager.prefix = prefix;
  }
  static setSeparator(separator) {
    _StorageKeyManager.separator = separator;
  }
  static setCaseSensitive(enable) {
    _StorageKeyManager.isCaseSensitive = enable;
  }
  static consumeConfiguration(config) {
    if ("prefix" in config)
      this.setPrefix(config.prefix);
    if ("separator" in config)
      this.setSeparator(config.separator);
    if ("caseSensitive" in config)
      this.setCaseSensitive(config.caseSensitive);
  }
};
_StorageKeyManager.prefix = DefaultPrefix;
_StorageKeyManager.separator = DefaultSeparator;
_StorageKeyManager.isCaseSensitive = DefaultIsCaseSensitive;
var StorageKeyManager = _StorageKeyManager;
var SyncStorage = class {
  constructor(strategy) {
    this.strategy = strategy;
  }
  retrieve(key) {
    let value;
    this.strategy.get(StorageKeyManager.normalize(key)).subscribe((result) => value = typeof result === "undefined" ? null : result);
    return value;
  }
  store(key, value) {
    this.strategy.set(StorageKeyManager.normalize(key), value).subscribe(noop);
    return value;
  }
  clear(key) {
    if (key !== void 0)
      this.strategy.del(StorageKeyManager.normalize(key)).subscribe(noop);
    else
      this.strategy.clear().subscribe(noop);
  }
  getStrategyName() {
    return this.strategy.name;
  }
  observe(key) {
    key = StorageKeyManager.normalize(key);
    return this.strategy.keyChanges.pipe(filter((changed) => changed === null || changed === key), switchMap(() => this.strategy.get(key)), distinctUntilChanged(), shareReplay({
      refCount: true,
      bufferSize: 1
    }));
  }
};
var AsyncStorage = class {
  constructor(strategy) {
    this.strategy = strategy;
  }
  retrieve(key) {
    return this.strategy.get(StorageKeyManager.normalize(key)).pipe(map((value) => typeof value === "undefined" ? null : value));
  }
  store(key, value) {
    return this.strategy.set(StorageKeyManager.normalize(key), value);
  }
  clear(key) {
    return key !== void 0 ? this.strategy.del(StorageKeyManager.normalize(key)) : this.strategy.clear();
  }
  getStrategyName() {
    return this.strategy.name;
  }
  observe(key) {
    key = StorageKeyManager.normalize(key);
    return this.strategy.keyChanges.pipe(filter((changed) => changed === null || changed === key), switchMap(() => this.strategy.get(key)), distinctUntilChanged(), shareReplay({
      refCount: true,
      bufferSize: 1
    }));
  }
};
var _StrategyCacheService = class _StrategyCacheService {
  constructor() {
    this.caches = {};
  }
  get(strategyName, key) {
    return this.getCacheStore(strategyName)[key];
  }
  set(strategyName, key, value) {
    this.getCacheStore(strategyName)[key] = value;
  }
  del(strategyName, key) {
    delete this.getCacheStore(strategyName)[key];
  }
  clear(strategyName) {
    this.caches[strategyName] = {};
  }
  getCacheStore(strategyName) {
    if (strategyName in this.caches)
      return this.caches[strategyName];
    return this.caches[strategyName] = {};
  }
};
_StrategyCacheService.ɵfac = function StrategyCacheService_Factory(t) {
  return new (t || _StrategyCacheService)();
};
_StrategyCacheService.ɵprov = ɵɵdefineInjectable({
  token: _StrategyCacheService,
  factory: _StrategyCacheService.ɵfac,
  providedIn: "root"
});
var StrategyCacheService = _StrategyCacheService;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StrategyCacheService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();
var LOCAL_STORAGE = new InjectionToken("window_local_storage");
function getLocalStorage() {
  return typeof window !== "undefined" ? window.localStorage : null;
}
var LocalStorageProvider = {
  provide: LOCAL_STORAGE,
  useFactory: getLocalStorage
};
var SESSION_STORAGE = new InjectionToken("window_session_storage");
function getSessionStorage() {
  return typeof window !== "undefined" ? window.sessionStorage : null;
}
var SessionStorageProvider = {
  provide: SESSION_STORAGE,
  useFactory: getSessionStorage
};
var BaseSyncStorageStrategy = class {
  constructor(storage, cache) {
    this.storage = storage;
    this.cache = cache;
    this.keyChanges = new Subject();
  }
  get isAvailable() {
    if (this._isAvailable === void 0)
      this._isAvailable = CompatHelper.isStorageAvailable(this.storage);
    return this._isAvailable;
  }
  get(key) {
    let data = this.cache.get(this.name, key);
    if (data !== void 0)
      return of(data);
    try {
      const item = this.storage.getItem(key);
      if (item !== null) {
        data = JSON.parse(item);
        this.cache.set(this.name, key, data);
      }
    } catch (err) {
      console.warn(err);
    }
    return of(data);
  }
  set(key, value) {
    const data = JSON.stringify(value);
    this.storage.setItem(key, data);
    this.cache.set(this.name, key, value);
    this.keyChanges.next(key);
    return of(value);
  }
  del(key) {
    this.storage.removeItem(key);
    this.cache.del(this.name, key);
    this.keyChanges.next(key);
    return of(null);
  }
  clear() {
    this.storage.clear();
    this.cache.clear(this.name);
    this.keyChanges.next(null);
    return of(null);
  }
};
var _LocalStorageStrategy = class _LocalStorageStrategy extends BaseSyncStorageStrategy {
  constructor(storage, cache, platformId, zone) {
    super(storage, cache);
    this.storage = storage;
    this.cache = cache;
    this.platformId = platformId;
    this.zone = zone;
    this.name = _LocalStorageStrategy.strategyName;
    if (isPlatformBrowser(this.platformId))
      this.listenExternalChanges();
  }
  listenExternalChanges() {
    window.addEventListener("storage", (event) => this.zone.run(() => {
      if (event.storageArea !== this.storage)
        return;
      const key = event.key;
      if (key !== null)
        this.cache.del(this.name, event.key);
      else
        this.cache.clear(this.name);
      this.keyChanges.next(key);
    }));
  }
};
_LocalStorageStrategy.strategyName = StorageStrategies.Local;
_LocalStorageStrategy.ɵfac = function LocalStorageStrategy_Factory(t) {
  return new (t || _LocalStorageStrategy)(ɵɵinject(LOCAL_STORAGE), ɵɵinject(StrategyCacheService), ɵɵinject(PLATFORM_ID), ɵɵinject(NgZone));
};
_LocalStorageStrategy.ɵprov = ɵɵdefineInjectable({
  token: _LocalStorageStrategy,
  factory: _LocalStorageStrategy.ɵfac
});
var LocalStorageStrategy = _LocalStorageStrategy;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LocalStorageStrategy, [{
    type: Injectable
  }], () => [{
    type: void 0,
    decorators: [{
      type: Inject,
      args: [LOCAL_STORAGE]
    }]
  }, {
    type: StrategyCacheService
  }, {
    type: void 0,
    decorators: [{
      type: Inject,
      args: [PLATFORM_ID]
    }]
  }, {
    type: NgZone
  }], null);
})();
var _SessionStorageStrategy = class _SessionStorageStrategy extends BaseSyncStorageStrategy {
  constructor(storage, cache, platformId, zone) {
    super(storage, cache);
    this.storage = storage;
    this.cache = cache;
    this.platformId = platformId;
    this.zone = zone;
    this.name = _SessionStorageStrategy.strategyName;
    if (isPlatformBrowser(this.platformId))
      this.listenExternalChanges();
  }
  listenExternalChanges() {
    window.addEventListener("storage", (event) => this.zone.run(() => {
      if (event.storageArea !== this.storage)
        return;
      const key = event.key;
      if (event.key !== null)
        this.cache.del(this.name, event.key);
      else
        this.cache.clear(this.name);
      this.keyChanges.next(key);
    }));
  }
};
_SessionStorageStrategy.strategyName = StorageStrategies.Session;
_SessionStorageStrategy.ɵfac = function SessionStorageStrategy_Factory(t) {
  return new (t || _SessionStorageStrategy)(ɵɵinject(SESSION_STORAGE), ɵɵinject(StrategyCacheService), ɵɵinject(PLATFORM_ID), ɵɵinject(NgZone));
};
_SessionStorageStrategy.ɵprov = ɵɵdefineInjectable({
  token: _SessionStorageStrategy,
  factory: _SessionStorageStrategy.ɵfac
});
var SessionStorageStrategy = _SessionStorageStrategy;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SessionStorageStrategy, [{
    type: Injectable
  }], () => [{
    type: void 0,
    decorators: [{
      type: Inject,
      args: [SESSION_STORAGE]
    }]
  }, {
    type: StrategyCacheService
  }, {
    type: void 0,
    decorators: [{
      type: Inject,
      args: [PLATFORM_ID]
    }]
  }, {
    type: NgZone
  }], null);
})();
var _InMemoryStorageStrategy = class _InMemoryStorageStrategy {
  constructor(cache) {
    this.cache = cache;
    this.keyChanges = new Subject();
    this.isAvailable = true;
    this.name = _InMemoryStorageStrategy.strategyName;
  }
  get(key) {
    return of(this.cache.get(this.name, key));
  }
  set(key, value) {
    this.cache.set(this.name, key, value);
    this.keyChanges.next(key);
    return of(value);
  }
  del(key) {
    this.cache.del(this.name, key);
    this.keyChanges.next(key);
    return of(null);
  }
  clear() {
    this.cache.clear(this.name);
    this.keyChanges.next(null);
    return of(null);
  }
};
_InMemoryStorageStrategy.strategyName = StorageStrategies.InMemory;
_InMemoryStorageStrategy.ɵfac = function InMemoryStorageStrategy_Factory(t) {
  return new (t || _InMemoryStorageStrategy)(ɵɵinject(StrategyCacheService));
};
_InMemoryStorageStrategy.ɵprov = ɵɵdefineInjectable({
  token: _InMemoryStorageStrategy,
  factory: _InMemoryStorageStrategy.ɵfac
});
var InMemoryStorageStrategy = _InMemoryStorageStrategy;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(InMemoryStorageStrategy, [{
    type: Injectable
  }], () => [{
    type: StrategyCacheService,
    decorators: [{
      type: Inject,
      args: [StrategyCacheService]
    }]
  }], null);
})();
var STORAGE_STRATEGIES = new InjectionToken("STORAGE_STRATEGIES");
var Strategies = [{
  provide: STORAGE_STRATEGIES,
  useClass: InMemoryStorageStrategy,
  multi: true
}, {
  provide: STORAGE_STRATEGIES,
  useClass: LocalStorageStrategy,
  multi: true
}, {
  provide: STORAGE_STRATEGIES,
  useClass: SessionStorageStrategy,
  multi: true
}];
var StorageStrategyStubName = "stub_strategy";
var StorageStrategyStub = class {
  constructor(name) {
    this.keyChanges = new Subject();
    this.store = {};
    this._available = true;
    this.name = name || StorageStrategyStubName;
  }
  get isAvailable() {
    return this._available;
  }
  get(key) {
    return of(this.store[key]);
  }
  set(key, value) {
    this.store[key] = value;
    this.keyChanges.next(key);
    return of(value);
  }
  del(key) {
    delete this.store[key];
    this.keyChanges.next(key);
    return of(null);
  }
  clear() {
    this.store = {};
    this.keyChanges.next(null);
    return of(null);
  }
};
var StorageStub = class {
  constructor() {
    this.store = {};
  }
  get length() {
    return Object.keys(this.store).length;
  }
  clear() {
    this.store = {};
  }
  getItem(key) {
    return this.store[key] || null;
  }
  key(index) {
    return Object.keys(this.store)[index];
  }
  removeItem(key) {
    delete this.store[key];
  }
  setItem(key, value) {
    this.store[key] = value;
  }
};
var InvalidStrategyError = "invalid_strategy";
var _StrategyIndex = class _StrategyIndex {
  constructor(strategies) {
    this.strategies = strategies;
    this.registration$ = new Subject();
    if (!strategies)
      strategies = [];
    this.strategies = strategies.reverse().map((strategy, index, arr) => strategy.name).map((name, index, arr) => arr.indexOf(name) === index ? index : null).filter((index) => index !== null).map((index) => strategies[index]);
  }
  static get(name) {
    if (!this.isStrategyRegistered(name))
      throw Error(InvalidStrategyError);
    let strategy = this.index[name];
    if (!strategy.isAvailable) {
      strategy = this.index[StorageStrategies.InMemory];
    }
    return strategy;
  }
  static set(name, strategy) {
    this.index[name] = strategy;
  }
  static clear(name) {
    if (name !== void 0)
      delete this.index[name];
    else
      this.index = {};
  }
  static isStrategyRegistered(name) {
    return name in this.index;
  }
  static hasRegistredStrategies() {
    return Object.keys(this.index).length > 0;
  }
  getStrategy(name) {
    return _StrategyIndex.get(name);
  }
  indexStrategies() {
    this.strategies.forEach((strategy) => this.register(strategy.name, strategy));
  }
  indexStrategy(name, overrideIfExists = false) {
    if (_StrategyIndex.isStrategyRegistered(name) && !overrideIfExists)
      return _StrategyIndex.get(name);
    const strategy = this.strategies.find((strategy2) => strategy2.name === name);
    if (!strategy)
      throw new Error(InvalidStrategyError);
    this.register(name, strategy, overrideIfExists);
    return strategy;
  }
  register(name, strategy, overrideIfExists = false) {
    if (!_StrategyIndex.isStrategyRegistered(name) || overrideIfExists) {
      _StrategyIndex.set(name, strategy);
      this.registration$.next(name);
    }
  }
};
_StrategyIndex.index = {};
_StrategyIndex.ɵfac = function StrategyIndex_Factory(t) {
  return new (t || _StrategyIndex)(ɵɵinject(STORAGE_STRATEGIES, 8));
};
_StrategyIndex.ɵprov = ɵɵdefineInjectable({
  token: _StrategyIndex,
  factory: _StrategyIndex.ɵfac,
  providedIn: "root"
});
var StrategyIndex = _StrategyIndex;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StrategyIndex, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: void 0,
    decorators: [{
      type: Optional
    }, {
      type: Inject,
      args: [STORAGE_STRATEGIES]
    }]
  }], null);
})();
var LocalStorageService = class extends SyncStorage {
};
function buildService$1(index) {
  const strategy = index.indexStrategy(StorageStrategies.Local);
  return new SyncStorage(strategy);
}
var LocalStorageServiceProvider = {
  provide: LocalStorageService,
  useFactory: buildService$1,
  deps: [StrategyIndex]
};
var SessionStorageService = class extends SyncStorage {
};
function buildService(index) {
  const strategy = index.indexStrategy(StorageStrategies.Session);
  return new SyncStorage(strategy);
}
var SessionStorageServiceProvider = {
  provide: SessionStorageService,
  useFactory: buildService,
  deps: [StrategyIndex]
};
var DecoratorBuilder = class {
  static buildSyncStrategyDecorator(strategyName, prototype, propName, key, defaultValue = null) {
    const rawKey = key || propName;
    let storageKey;
    Object.defineProperty(prototype, propName, {
      get: function() {
        let value;
        StrategyIndex.get(strategyName).get(getKey()).subscribe((result) => value = result);
        return value === void 0 ? defaultValue : value;
      },
      set: function(value) {
        StrategyIndex.get(strategyName).set(getKey(), value).subscribe(noop);
      }
    });
    function getKey() {
      if (storageKey !== void 0)
        return storageKey;
      return storageKey = StorageKeyManager.normalize(rawKey);
    }
  }
};
function LocalStorage(key, defaultValue) {
  return function(prototype, propName) {
    DecoratorBuilder.buildSyncStrategyDecorator(StorageStrategies.Local, prototype, propName, key, defaultValue);
  };
}
function SessionStorage(key, defaultValue) {
  return function(prototype, propName) {
    DecoratorBuilder.buildSyncStrategyDecorator(StorageStrategies.Session, prototype, propName, key, defaultValue);
  };
}
var Services = [LocalStorageServiceProvider, SessionStorageServiceProvider];
var LIB_CONFIG = new InjectionToken("ngx_webstorage_config");
function appInit(index) {
  index.indexStrategies();
  return () => {
    return StrategyIndex.index;
  };
}
var _NgxWebstorageModule = class _NgxWebstorageModule {
  constructor(index, config) {
    if (config)
      StorageKeyManager.consumeConfiguration(config);
    else
      console.error("NgxWebstorage : Possible misconfiguration (The forRoot method usage is mandatory since the 3.0.0)");
  }
  static forRoot(config = {}) {
    return {
      ngModule: _NgxWebstorageModule,
      providers: [{
        provide: LIB_CONFIG,
        useValue: config
      }, LocalStorageProvider, SessionStorageProvider, ...Services, ...Strategies, {
        provide: APP_INITIALIZER,
        useFactory: appInit,
        deps: [StrategyIndex],
        multi: true
      }]
    };
  }
};
_NgxWebstorageModule.ɵfac = function NgxWebstorageModule_Factory(t) {
  return new (t || _NgxWebstorageModule)(ɵɵinject(StrategyIndex), ɵɵinject(LIB_CONFIG, 8));
};
_NgxWebstorageModule.ɵmod = ɵɵdefineNgModule({
  type: _NgxWebstorageModule
});
_NgxWebstorageModule.ɵinj = ɵɵdefineInjector({});
var NgxWebstorageModule = _NgxWebstorageModule;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgxWebstorageModule, [{
    type: NgModule,
    args: [{}]
  }], () => [{
    type: StrategyIndex
  }, {
    type: void 0,
    decorators: [{
      type: Optional
    }, {
      type: Inject,
      args: [LIB_CONFIG]
    }]
  }], null);
})();
export {
  AsyncStorage,
  CompatHelper,
  InMemoryStorageStrategy,
  InvalidStrategyError,
  LIB_CONFIG,
  LOCAL_STORAGE,
  LocalStorage,
  LocalStorageService,
  LocalStorageStrategy,
  NgxWebstorageModule,
  SESSION_STORAGE,
  STORAGE_STRATEGIES,
  SessionStorage,
  SessionStorageService,
  SessionStorageStrategy,
  StorageStrategies,
  StorageStrategyStub,
  StorageStrategyStubName,
  StorageStub,
  StrategyCacheService,
  StrategyIndex,
  SyncStorage,
  appInit
};
//# sourceMappingURL=ngx-webstorage.js.map
