import {
  SubmissionService,
  __esm,
  createRequestOption,
  getLatestSubmissionResult,
  init_request_util,
  init_submission_model,
  init_submission_service,
  init_utils,
  setLatestSubmissionResult,
  stringifyCircular
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exercises/text/participate/text-submission.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient, HttpParams } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { map } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var TextSubmissionService;
var init_text_submission_service = __esm({
  "src/main/webapp/app/exercises/text/participate/text-submission.service.ts"() {
    init_request_util();
    init_utils();
    init_submission_model();
    init_submission_service();
    init_submission_service();
    TextSubmissionService = class _TextSubmissionService {
      http;
      submissionService;
      constructor(http, submissionService) {
        this.http = http;
        this.submissionService = submissionService;
      }
      create(textSubmission, exerciseId) {
        const copy = this.submissionService.convert(textSubmission);
        return this.http.post(`api/exercises/${exerciseId}/text-submissions`, copy, {
          observe: "response"
        }).pipe(map((res) => this.submissionService.convertResponse(res)));
      }
      update(textSubmission, exerciseId) {
        const copy = this.submissionService.convert(textSubmission);
        return this.http.put(`api/exercises/${exerciseId}/text-submissions`, stringifyCircular(copy), {
          headers: { "Content-Type": "application/json" },
          observe: "response"
        }).pipe(map((res) => this.submissionService.convertResponse(res)));
      }
      getTextSubmission(submissionId) {
        return this.http.get(`api/text-submissions/${submissionId}`, {
          observe: "response"
        }).pipe(map((res) => res.body));
      }
      getSubmissions(exerciseId, req, correctionRound = 0) {
        const url = `api/exercises/${exerciseId}/text-submissions`;
        let params = createRequestOption(req);
        if (correctionRound !== 0) {
          params = params.set("correction-round", correctionRound.toString());
        }
        return this.http.get(url, { observe: "response", params }).pipe(map((res) => this.submissionService.convertArrayResponse(res)));
      }
      getSubmissionWithoutAssessment(exerciseId, option, correctionRound = 0) {
        const url = `api/exercises/${exerciseId}/text-submission-without-assessment`;
        let params = new HttpParams();
        if (correctionRound !== 0) {
          params = params.set("correction-round", correctionRound.toString());
        }
        if (option) {
          params = params.set(option, "true");
        }
        return this.http.get(url, { observe: "response", params }).pipe(map((response) => {
          const submission = response.body;
          if (!submission) {
            return void 0;
          }
          setLatestSubmissionResult(submission, getLatestSubmissionResult(submission));
          submission.participation.submissions = [submission];
          submission.participation.results = [submission.latestResult];
          return submission;
        }));
      }
      static \u0275fac = function TextSubmissionService_Factory(t) {
        return new (t || _TextSubmissionService)(i0.\u0275\u0275inject(i1.HttpClient), i0.\u0275\u0275inject(SubmissionService));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _TextSubmissionService, factory: _TextSubmissionService.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  TextSubmissionService,
  init_text_submission_service
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhlcmNpc2VzL3RleHQvcGFydGljaXBhdGUvdGV4dC1zdWJtaXNzaW9uLnNlcnZpY2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cFBhcmFtcywgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgVGV4dFN1Ym1pc3Npb24gfSBmcm9tICdhcHAvZW50aXRpZXMvdGV4dC1zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IGNyZWF0ZVJlcXVlc3RPcHRpb24gfSBmcm9tICdhcHAvc2hhcmVkL3V0aWwvcmVxdWVzdC51dGlsJztcbmltcG9ydCB7IHN0cmluZ2lmeUNpcmN1bGFyIH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL3V0aWxzJztcbmltcG9ydCB7IGdldExhdGVzdFN1Ym1pc3Npb25SZXN1bHQsIHNldExhdGVzdFN1Ym1pc3Npb25SZXN1bHQgfSBmcm9tICdhcHAvZW50aXRpZXMvc3VibWlzc2lvbi5tb2RlbCc7XG5pbXBvcnQgeyBTdWJtaXNzaW9uU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL3N1Ym1pc3Npb24vc3VibWlzc2lvbi5zZXJ2aWNlJztcblxuZXhwb3J0IHR5cGUgRW50aXR5UmVzcG9uc2VUeXBlID0gSHR0cFJlc3BvbnNlPFRleHRTdWJtaXNzaW9uPjtcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBUZXh0U3VibWlzc2lvblNlcnZpY2Uge1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQsXG4gICAgICAgIHByaXZhdGUgc3VibWlzc2lvblNlcnZpY2U6IFN1Ym1pc3Npb25TZXJ2aWNlLFxuICAgICkge31cblxuICAgIGNyZWF0ZSh0ZXh0U3VibWlzc2lvbjogVGV4dFN1Ym1pc3Npb24sIGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIGNvbnN0IGNvcHkgPSB0aGlzLnN1Ym1pc3Npb25TZXJ2aWNlLmNvbnZlcnQodGV4dFN1Ym1pc3Npb24pO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAucG9zdDxUZXh0U3VibWlzc2lvbj4oYGFwaS9leGVyY2lzZXMvJHtleGVyY2lzZUlkfS90ZXh0LXN1Ym1pc3Npb25zYCwgY29weSwge1xuICAgICAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEVudGl0eVJlc3BvbnNlVHlwZSkgPT4gdGhpcy5zdWJtaXNzaW9uU2VydmljZS5jb252ZXJ0UmVzcG9uc2UocmVzKSkpO1xuICAgIH1cblxuICAgIHVwZGF0ZSh0ZXh0U3VibWlzc2lvbjogVGV4dFN1Ym1pc3Npb24sIGV4ZXJjaXNlSWQ6IG51bWJlcik6IE9ic2VydmFibGU8RW50aXR5UmVzcG9uc2VUeXBlPiB7XG4gICAgICAgIGNvbnN0IGNvcHkgPSB0aGlzLnN1Ym1pc3Npb25TZXJ2aWNlLmNvbnZlcnQodGV4dFN1Ym1pc3Npb24pO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAucHV0PFRleHRTdWJtaXNzaW9uPihgYXBpL2V4ZXJjaXNlcy8ke2V4ZXJjaXNlSWR9L3RleHQtc3VibWlzc2lvbnNgLCBzdHJpbmdpZnlDaXJjdWxhcihjb3B5KSwge1xuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgICAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEVudGl0eVJlc3BvbnNlVHlwZSkgPT4gdGhpcy5zdWJtaXNzaW9uU2VydmljZS5jb252ZXJ0UmVzcG9uc2UocmVzKSkpO1xuICAgIH1cblxuICAgIGdldFRleHRTdWJtaXNzaW9uKHN1Ym1pc3Npb25JZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxUZXh0U3VibWlzc2lvbj4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAuZ2V0PFRleHRTdWJtaXNzaW9uPihgYXBpL3RleHQtc3VibWlzc2lvbnMvJHtzdWJtaXNzaW9uSWR9YCwge1xuICAgICAgICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXM6IEh0dHBSZXNwb25zZTxUZXh0U3VibWlzc2lvbj4pID0+IHJlcy5ib2R5ISkpO1xuICAgIH1cblxuICAgIGdldFN1Ym1pc3Npb25zKGV4ZXJjaXNlSWQ6IG51bWJlciwgcmVxOiB7IHN1Ym1pdHRlZE9ubHk/OiBib29sZWFuOyBhc3Nlc3NlZEJ5VHV0b3I/OiBib29sZWFuIH0sIGNvcnJlY3Rpb25Sb3VuZCA9IDApOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUZXh0U3VibWlzc2lvbltdPj4ge1xuICAgICAgICBjb25zdCB1cmwgPSBgYXBpL2V4ZXJjaXNlcy8ke2V4ZXJjaXNlSWR9L3RleHQtc3VibWlzc2lvbnNgO1xuICAgICAgICBsZXQgcGFyYW1zID0gY3JlYXRlUmVxdWVzdE9wdGlvbihyZXEpO1xuICAgICAgICBpZiAoY29ycmVjdGlvblJvdW5kICE9PSAwKSB7XG4gICAgICAgICAgICBwYXJhbXMgPSBwYXJhbXMuc2V0KCdjb3JyZWN0aW9uLXJvdW5kJywgY29ycmVjdGlvblJvdW5kLnRvU3RyaW5nKCkpO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgICAgICAgLmdldDxUZXh0U3VibWlzc2lvbltdPih1cmwsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJywgcGFyYW1zIH0pXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlczogSHR0cFJlc3BvbnNlPFRleHRTdWJtaXNzaW9uW10+KSA9PiB0aGlzLnN1Ym1pc3Npb25TZXJ2aWNlLmNvbnZlcnRBcnJheVJlc3BvbnNlKHJlcykpKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKlxuICAgICAqIEBwYXJhbSBleGVyY2lzZUlkIGlkIG9mIHRoZSBleGVyY2lzZXJcbiAgICAgKiBAcGFyYW0gb3B0aW9uICdoZWFkJzogRG8gbm90IG9wdGltaXplIGFzc2Vzc21lbnQgb3JkZXIuIE9ubHkgdXNlZCB0byBjaGVjayBpZiBhc3Nlc3NtZW50cyBhdmFpbGFibGUuXG4gICAgICogQHBhcmFtIGNvcnJlY3Rpb25Sb3VuZDogVGhlIGNvcnJlY3Rpb24gcm91bmQgZm9yIHdoaWNoIHdlIHdhbnQgdG8gZ2V0IGEgbmV3IGFzc2Vzc21lbnRcbiAgICAgKi9cbiAgICBnZXRTdWJtaXNzaW9uV2l0aG91dEFzc2Vzc21lbnQoZXhlcmNpc2VJZDogbnVtYmVyLCBvcHRpb24/OiAnbG9jaycgfCAnaGVhZCcsIGNvcnJlY3Rpb25Sb3VuZCA9IDApOiBPYnNlcnZhYmxlPFRleHRTdWJtaXNzaW9uIHwgdW5kZWZpbmVkPiB7XG4gICAgICAgIGNvbnN0IHVybCA9IGBhcGkvZXhlcmNpc2VzLyR7ZXhlcmNpc2VJZH0vdGV4dC1zdWJtaXNzaW9uLXdpdGhvdXQtYXNzZXNzbWVudGA7XG4gICAgICAgIGxldCBwYXJhbXMgPSBuZXcgSHR0cFBhcmFtcygpO1xuICAgICAgICBpZiAoY29ycmVjdGlvblJvdW5kICE9PSAwKSB7XG4gICAgICAgICAgICBwYXJhbXMgPSBwYXJhbXMuc2V0KCdjb3JyZWN0aW9uLXJvdW5kJywgY29ycmVjdGlvblJvdW5kLnRvU3RyaW5nKCkpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChvcHRpb24pIHtcbiAgICAgICAgICAgIHBhcmFtcyA9IHBhcmFtcy5zZXQob3B0aW9uLCAndHJ1ZScpO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8VGV4dFN1Ym1pc3Npb24gfCB1bmRlZmluZWQ+KHVybCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnLCBwYXJhbXMgfSkucGlwZShcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBzdWJtaXNzaW9uID0gcmVzcG9uc2UuYm9keTtcbiAgICAgICAgICAgICAgICBpZiAoIXN1Ym1pc3Npb24pIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc2V0TGF0ZXN0U3VibWlzc2lvblJlc3VsdChzdWJtaXNzaW9uLCBnZXRMYXRlc3RTdWJtaXNzaW9uUmVzdWx0KHN1Ym1pc3Npb24pKTtcblxuICAgICAgICAgICAgICAgIHN1Ym1pc3Npb24ucGFydGljaXBhdGlvbiEuc3VibWlzc2lvbnMgPSBbc3VibWlzc2lvbl07XG4gICAgICAgICAgICAgICAgc3VibWlzc2lvbi5wYXJ0aWNpcGF0aW9uIS5yZXN1bHRzID0gW3N1Ym1pc3Npb24ubGF0ZXN0UmVzdWx0IV07XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gc3VibWlzc2lvbjtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLFlBQVksa0JBQWdDO0FBRXJELFNBQVMsV0FBVzs7O0FBSHBCLElBYWE7QUFiYjs7QUFLQTtBQUNBO0FBQ0E7QUFDQTs7QUFLTSxJQUFPLHdCQUFQLE1BQU8sdUJBQXFCO01BRWxCO01BQ0E7TUFGWixZQUNZLE1BQ0EsbUJBQW9DO0FBRHBDLGFBQUEsT0FBQTtBQUNBLGFBQUEsb0JBQUE7TUFDVDtNQUVILE9BQU8sZ0JBQWdDLFlBQWtCO0FBQ3JELGNBQU0sT0FBTyxLQUFLLGtCQUFrQixRQUFRLGNBQWM7QUFDMUQsZUFBTyxLQUFLLEtBQ1AsS0FBcUIsaUJBQWlCLFVBQVUscUJBQXFCLE1BQU07VUFDeEUsU0FBUztTQUNaLEVBQ0EsS0FBSyxJQUFJLENBQUMsUUFBNEIsS0FBSyxrQkFBa0IsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO01BQzNGO01BRUEsT0FBTyxnQkFBZ0MsWUFBa0I7QUFDckQsY0FBTSxPQUFPLEtBQUssa0JBQWtCLFFBQVEsY0FBYztBQUMxRCxlQUFPLEtBQUssS0FDUCxJQUFvQixpQkFBaUIsVUFBVSxxQkFBcUIsa0JBQWtCLElBQUksR0FBRztVQUMxRixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFrQjtVQUM3QyxTQUFTO1NBQ1osRUFDQSxLQUFLLElBQUksQ0FBQyxRQUE0QixLQUFLLGtCQUFrQixnQkFBZ0IsR0FBRyxDQUFDLENBQUM7TUFDM0Y7TUFFQSxrQkFBa0IsY0FBb0I7QUFDbEMsZUFBTyxLQUFLLEtBQ1AsSUFBb0Isd0JBQXdCLFlBQVksSUFBSTtVQUN6RCxTQUFTO1NBQ1osRUFDQSxLQUFLLElBQUksQ0FBQyxRQUFzQyxJQUFJLElBQUssQ0FBQztNQUNuRTtNQUVBLGVBQWUsWUFBb0IsS0FBNkQsa0JBQWtCLEdBQUM7QUFDL0csY0FBTSxNQUFNLGlCQUFpQixVQUFVO0FBQ3ZDLFlBQUksU0FBUyxvQkFBb0IsR0FBRztBQUNwQyxZQUFJLG9CQUFvQixHQUFHO0FBQ3ZCLG1CQUFTLE9BQU8sSUFBSSxvQkFBb0IsZ0JBQWdCLFNBQVEsQ0FBRTs7QUFHdEUsZUFBTyxLQUFLLEtBQ1AsSUFBc0IsS0FBSyxFQUFFLFNBQVMsWUFBWSxPQUFNLENBQUUsRUFDMUQsS0FBSyxJQUFJLENBQUMsUUFBd0MsS0FBSyxrQkFBa0IscUJBQXFCLEdBQUcsQ0FBQyxDQUFDO01BQzVHO01BUUEsK0JBQStCLFlBQW9CLFFBQTBCLGtCQUFrQixHQUFDO0FBQzVGLGNBQU0sTUFBTSxpQkFBaUIsVUFBVTtBQUN2QyxZQUFJLFNBQVMsSUFBSSxXQUFVO0FBQzNCLFlBQUksb0JBQW9CLEdBQUc7QUFDdkIsbUJBQVMsT0FBTyxJQUFJLG9CQUFvQixnQkFBZ0IsU0FBUSxDQUFFOztBQUV0RSxZQUFJLFFBQVE7QUFDUixtQkFBUyxPQUFPLElBQUksUUFBUSxNQUFNOztBQUd0QyxlQUFPLEtBQUssS0FBSyxJQUFnQyxLQUFLLEVBQUUsU0FBUyxZQUFZLE9BQU0sQ0FBRSxFQUFFLEtBQ25GLElBQUksQ0FBQyxhQUFZO0FBQ2IsZ0JBQU0sYUFBYSxTQUFTO0FBQzVCLGNBQUksQ0FBQyxZQUFZO0FBQ2IsbUJBQU87O0FBRVgsb0NBQTBCLFlBQVksMEJBQTBCLFVBQVUsQ0FBQztBQUUzRSxxQkFBVyxjQUFlLGNBQWMsQ0FBQyxVQUFVO0FBQ25ELHFCQUFXLGNBQWUsVUFBVSxDQUFDLFdBQVcsWUFBYTtBQUU3RCxpQkFBTztRQUNYLENBQUMsQ0FBQztNQUVWOzt5QkEzRVMsd0JBQXFCLHNCQUFBLGFBQUEsR0FBQSxzQkFBQSxpQkFBQSxDQUFBO01BQUE7bUVBQXJCLHdCQUFxQixTQUFyQix1QkFBcUIsV0FBQSxZQURSLE9BQU0sQ0FBQTs7OzsiLCJuYW1lcyI6W119