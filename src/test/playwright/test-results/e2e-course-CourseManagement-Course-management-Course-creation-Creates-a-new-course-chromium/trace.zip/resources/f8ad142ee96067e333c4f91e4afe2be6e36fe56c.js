import {
  __async,
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/shared/http/file.service.ts
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { lastValueFrom } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { v4 as uuid } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/uuid.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
var FileService;
var init_file_service = __esm({
  "src/main/webapp/app/shared/http/file.service.ts"() {
    FileService = class _FileService {
      http;
      resourceUrl = "api/files";
      constructor(http) {
        this.http = http;
      }
      getTemplateFile(language, projectType) {
        const urlParts = [language];
        if (projectType) {
          urlParts.push(projectType);
        }
        return this.http.get(`${this.resourceUrl}/templates/` + urlParts.join("/"), { responseType: "text" });
      }
      getFile(filePath, mapOfFiles) {
        return __async(this, null, function* () {
          const blob = yield lastValueFrom(this.http.get(filePath, { responseType: "blob" }));
          const file = new File([blob], this.getUniqueFileName(this.getExtension(filePath), mapOfFiles));
          return Promise.resolve(file);
        });
      }
      getAeolusTemplateFile(language, projectType, staticAnalysis, sequentialRuns, coverage) {
        const urlParts = [language];
        const params = [];
        if (projectType) {
          urlParts.push(projectType);
        }
        params.push("staticAnalysis=" + (staticAnalysis == void 0 ? false : staticAnalysis));
        params.push("sequentialRuns=" + (sequentialRuns == void 0 ? false : sequentialRuns));
        params.push("testCoverage=" + (coverage == void 0 ? false : coverage));
        return this.http.get(`${this.resourceUrl}/aeolus/templates/` + urlParts.join("/") + "?" + params.join("&"), { responseType: "text" });
      }
      getTemplateCodeOfCondcut() {
        return this.http.get(`api/files/templates/code-of-conduct`, { observe: "response", responseType: "text" });
      }
      downloadFile(downloadUrl) {
        const downloadUrlComponents = downloadUrl.split("/");
        const fileName = downloadUrlComponents.pop();
        const restOfUrl = downloadUrlComponents.join("/");
        const normalizedDownloadUrl = restOfUrl + "/" + encodeURIComponent(fileName);
        const newWindow = window.open("about:blank");
        newWindow.location.href = normalizedDownloadUrl;
        return newWindow;
      }
      downloadMergedFile(courseId, lectureId) {
        const newWindow = window.open("about:blank");
        newWindow.location.href = `api/files/attachments/lecture/${lectureId}/merge-pdf`;
        return newWindow;
      }
      getExtension(filename) {
        return filename.split(".").pop();
      }
      getUniqueFileName(extension, mapOfFiles) {
        let name;
        do {
          name = uuid() + "." + extension;
        } while (mapOfFiles && mapOfFiles.has(name));
        return name;
      }
      static \u0275fac = function FileService_Factory(t) {
        return new (t || _FileService)(i0.\u0275\u0275inject(i1.HttpClient));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _FileService, factory: _FileService.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  FileService,
  init_file_service
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL2h0dHAvZmlsZS5zZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGxhc3RWYWx1ZUZyb20gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IHY0IGFzIHV1aWQgfSBmcm9tICd1dWlkJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcblxuaW1wb3J0IHsgUHJvZ3JhbW1pbmdMYW5ndWFnZSwgUHJvamVjdFR5cGUgfSBmcm9tICdhcHAvZW50aXRpZXMvcHJvZ3JhbW1pbmctZXhlcmNpc2UubW9kZWwnO1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIEZpbGVTZXJ2aWNlIHtcbiAgICBwcml2YXRlIHJlc291cmNlVXJsID0gJ2FwaS9maWxlcyc7XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQpIHt9XG5cbiAgICAvKipcbiAgICAgKiBGZXRjaGVzIHRoZSB0ZW1wbGF0ZSBmaWxlIGZvciB0aGUgZ2l2ZW4gcHJvZ3JhbW1pbmcgbGFuZ3VhZ2VcbiAgICAgKiBAcGFyYW0ge1Byb2dyYW1taW5nTGFuZ3VhZ2V9IGxhbmd1YWdlXG4gICAgICogQHBhcmFtIHtQcm9qZWN0VHlwZX0gcHJvamVjdFR5cGUgKGlmIGF2YWlsYWJsZSlcbiAgICAgKiBAcmV0dXJucyBqc29uIHRlc3QgZmlsZVxuICAgICAqL1xuICAgIGdldFRlbXBsYXRlRmlsZShsYW5ndWFnZTogUHJvZ3JhbW1pbmdMYW5ndWFnZSwgcHJvamVjdFR5cGU/OiBQcm9qZWN0VHlwZSk6IE9ic2VydmFibGU8c3RyaW5nPiB7XG4gICAgICAgIGNvbnN0IHVybFBhcnRzOiBzdHJpbmdbXSA9IFtsYW5ndWFnZV07XG4gICAgICAgIGlmIChwcm9qZWN0VHlwZSkge1xuICAgICAgICAgICAgdXJsUGFydHMucHVzaChwcm9qZWN0VHlwZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8c3RyaW5nPihgJHt0aGlzLnJlc291cmNlVXJsfS90ZW1wbGF0ZXMvYCArIHVybFBhcnRzLmpvaW4oJy8nKSwgeyByZXNwb25zZVR5cGU6ICd0ZXh0JyBhcyAnanNvbicgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRmV0Y2hlcyB0aGUgZmlsZSBmcm9tIHRoZSBnaXZlbiBwYXRoIGFuZCByZXR1cm5zIGl0IGFzIGEgRmlsZSBvYmplY3Qgd2l0aCBhIHVuaXF1ZSBmaWxlIG5hbWUuXG4gICAgICogQHBhcmFtIGZpbGVQYXRoIHBhdGggb2YgdGhlIGZpbGVcbiAgICAgKiBAcGFyYW0gbWFwT2ZGaWxlcyBvcHRpb25hbCBtYXAgdG8gY2hlY2sgaWYgdGhlIGdlbmVyYXRlZCBmaWxlIG5hbWUgYWxyZWFkeSBleGlzdHNcbiAgICAgKi9cbiAgICBhc3luYyBnZXRGaWxlKGZpbGVQYXRoOiBzdHJpbmcsIG1hcE9mRmlsZXM/OiBNYXA8c3RyaW5nLCB7IHBhdGg/OiBzdHJpbmc7IGZpbGU6IEZpbGUgfT4pOiBQcm9taXNlPEZpbGU+IHtcbiAgICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IGxhc3RWYWx1ZUZyb20odGhpcy5odHRwLmdldChmaWxlUGF0aCwgeyByZXNwb25zZVR5cGU6ICdibG9iJyB9KSk7XG4gICAgICAgIGNvbnN0IGZpbGUgPSBuZXcgRmlsZShbYmxvYl0sIHRoaXMuZ2V0VW5pcXVlRmlsZU5hbWUodGhpcy5nZXRFeHRlbnNpb24oZmlsZVBhdGgpLCBtYXBPZkZpbGVzKSk7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoZmlsZSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRmV0Y2hlcyB0aGUgYWVvbHVzIHRlbXBsYXRlIGZpbGUgZm9yIHRoZSBnaXZlbiBwcm9ncmFtbWluZyBsYW5ndWFnZVxuICAgICAqIEBwYXJhbSB7UHJvZ3JhbW1pbmdMYW5ndWFnZX0gbGFuZ3VhZ2VcbiAgICAgKiBAcGFyYW0ge1Byb2plY3RUeXBlfSBwcm9qZWN0VHlwZSAoaWYgYXZhaWxhYmxlKVxuICAgICAqIEBwYXJhbSBzdGF0aWNBbmFseXNpcyAoaWYgYXZhaWxhYmxlKSB3aGV0aGVyIHN0YXRpYyBjb2RlIGFuYWx5c2lzIHNob3VsZCBiZSBlbmFibGVkXG4gICAgICogQHBhcmFtIHNlcXVlbnRpYWxSdW5zIChpZiBhdmFpbGFibGUpIHdoZXRoZXIgc2VxdWVudGlhbCB0ZXN0IHJ1bnMgc2hvdWxkIGJlIGVuYWJsZWRcbiAgICAgKiBAcGFyYW0gY292ZXJhZ2UgKGlmIGF2YWlsYWJsZSkgd2hldGhlciB0ZXN0IGNvdmVyYWdlIHNob3VsZCBiZSBlbmFibGVkXG4gICAgICogQHJldHVybnMganNvbiB0ZXN0IGZpbGVcbiAgICAgKi9cbiAgICBnZXRBZW9sdXNUZW1wbGF0ZUZpbGUobGFuZ3VhZ2U6IFByb2dyYW1taW5nTGFuZ3VhZ2UsIHByb2plY3RUeXBlPzogUHJvamVjdFR5cGUsIHN0YXRpY0FuYWx5c2lzPzogYm9vbGVhbiwgc2VxdWVudGlhbFJ1bnM/OiBib29sZWFuLCBjb3ZlcmFnZT86IGJvb2xlYW4pOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xuICAgICAgICBjb25zdCB1cmxQYXJ0czogc3RyaW5nW10gPSBbbGFuZ3VhZ2VdO1xuICAgICAgICBjb25zdCBwYXJhbXM6IHN0cmluZ1tdID0gW107XG4gICAgICAgIGlmIChwcm9qZWN0VHlwZSkge1xuICAgICAgICAgICAgdXJsUGFydHMucHVzaChwcm9qZWN0VHlwZSk7XG4gICAgICAgIH1cbiAgICAgICAgcGFyYW1zLnB1c2goJ3N0YXRpY0FuYWx5c2lzPScgKyAoc3RhdGljQW5hbHlzaXMgPT0gdW5kZWZpbmVkID8gZmFsc2UgOiBzdGF0aWNBbmFseXNpcykpO1xuICAgICAgICBwYXJhbXMucHVzaCgnc2VxdWVudGlhbFJ1bnM9JyArIChzZXF1ZW50aWFsUnVucyA9PSB1bmRlZmluZWQgPyBmYWxzZSA6IHNlcXVlbnRpYWxSdW5zKSk7XG4gICAgICAgIHBhcmFtcy5wdXNoKCd0ZXN0Q292ZXJhZ2U9JyArIChjb3ZlcmFnZSA9PSB1bmRlZmluZWQgPyBmYWxzZSA6IGNvdmVyYWdlKSk7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PHN0cmluZz4oYCR7dGhpcy5yZXNvdXJjZVVybH0vYWVvbHVzL3RlbXBsYXRlcy9gICsgdXJsUGFydHMuam9pbignLycpICsgJz8nICsgcGFyYW1zLmpvaW4oJyYnKSwgeyByZXNwb25zZVR5cGU6ICd0ZXh0JyBhcyAnanNvbicgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRmV0Y2hlcyB0aGUgdGVtcGxhdGUgY29kZSBvZiBjb25kdWN0XG4gICAgICogQHJldHVybnMgbWFya2Rvd24gZmlsZVxuICAgICAqL1xuICAgIGdldFRlbXBsYXRlQ29kZU9mQ29uZGN1dCgpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxzdHJpbmc+PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PHN0cmluZz4oYGFwaS9maWxlcy90ZW1wbGF0ZXMvY29kZS1vZi1jb25kdWN0YCwgeyBvYnNlcnZlOiAncmVzcG9uc2UnLCByZXNwb25zZVR5cGU6ICd0ZXh0JyBhcyAnanNvbicgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRG93bmxvYWRzIHRoZSBmaWxlIGZyb20gdGhlIHByb3ZpZGVkIGRvd25sb2FkVXJsLlxuICAgICAqXG4gICAgICogQHBhcmFtIGRvd25sb2FkVXJsIHVybCB0aGF0IGlzIHN0b3JlZCBpbiB0aGUgYXR0YWNobWVudCBtb2RlbFxuICAgICAqL1xuICAgIGRvd25sb2FkRmlsZShkb3dubG9hZFVybDogc3RyaW5nKSB7XG4gICAgICAgIGNvbnN0IGRvd25sb2FkVXJsQ29tcG9uZW50cyA9IGRvd25sb2FkVXJsLnNwbGl0KCcvJyk7XG4gICAgICAgIC8vIHRha2UgdGhlIGxhc3QgZWxlbWVudFxuICAgICAgICBjb25zdCBmaWxlTmFtZSA9IGRvd25sb2FkVXJsQ29tcG9uZW50cy5wb3AoKSE7XG4gICAgICAgIGNvbnN0IHJlc3RPZlVybCA9IGRvd25sb2FkVXJsQ29tcG9uZW50cy5qb2luKCcvJyk7XG4gICAgICAgIGNvbnN0IG5vcm1hbGl6ZWREb3dubG9hZFVybCA9IHJlc3RPZlVybCArICcvJyArIGVuY29kZVVSSUNvbXBvbmVudChmaWxlTmFtZSk7XG4gICAgICAgIGNvbnN0IG5ld1dpbmRvdyA9IHdpbmRvdy5vcGVuKCdhYm91dDpibGFuaycpO1xuICAgICAgICBuZXdXaW5kb3chLmxvY2F0aW9uLmhyZWYgPSBub3JtYWxpemVkRG93bmxvYWRVcmw7XG4gICAgICAgIHJldHVybiBuZXdXaW5kb3c7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRG93bmxvYWRzIHRoZSBtZXJnZWQgUERGIGZpbGUuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gY291cnNlSWQgdGhlIGlkIG9mIHRoZSBjb3Vyc2VcbiAgICAgKiBAcGFyYW0gbGVjdHVyZUlkIHRoZSBpZCBvZiB0aGUgbGVjdHVyZVxuICAgICAqL1xuICAgIGRvd25sb2FkTWVyZ2VkRmlsZShjb3Vyc2VJZDogbnVtYmVyLCBsZWN0dXJlSWQ6IG51bWJlcikge1xuICAgICAgICBjb25zdCBuZXdXaW5kb3cgPSB3aW5kb3cub3BlbignYWJvdXQ6YmxhbmsnKTtcbiAgICAgICAgbmV3V2luZG93IS5sb2NhdGlvbi5ocmVmID0gYGFwaS9maWxlcy9hdHRhY2htZW50cy9sZWN0dXJlLyR7bGVjdHVyZUlkfS9tZXJnZS1wZGZgO1xuICAgICAgICByZXR1cm4gbmV3V2luZG93O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIGZpbGUgZXh0ZW5zaW9uIG9mIHRoZSBnaXZlbiBmaWxlbmFtZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBmaWxlbmFtZSB0aGUgZmlsZW5hbWVcbiAgICAgKi9cbiAgICBnZXRFeHRlbnNpb24oZmlsZW5hbWU6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiBmaWxlbmFtZS5zcGxpdCgnLicpLnBvcCgpITtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGEgdW5pcXVlIGZpbGUgbmFtZSB3aXRoIHRoZSBnaXZlbiBleHRlbnNpb24uXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZXh0ZW5zaW9uIHRoZSBmaWxlIGV4dGVuc2lvbiB0byBhZGRcbiAgICAgKiBAcGFyYW0gbWFwT2ZGaWxlcyBvcHRpb25hbCBtYXAgdG8gY2hlY2sgaWYgdGhlIGdlbmVyYXRlZCBmaWxlIG5hbWUgYWxyZWFkeSBleGlzdHNcbiAgICAgKi9cbiAgICBnZXRVbmlxdWVGaWxlTmFtZShleHRlbnNpb246IHN0cmluZywgbWFwT2ZGaWxlcz86IE1hcDxzdHJpbmcsIHsgcGF0aD86IHN0cmluZzsgZmlsZTogRmlsZSB9Pik6IHN0cmluZyB7XG4gICAgICAgIGxldCBuYW1lO1xuICAgICAgICBkbyB7XG4gICAgICAgICAgICBuYW1lID0gdXVpZCgpICsgJy4nICsgZXh0ZW5zaW9uO1xuICAgICAgICB9IHdoaWxlIChtYXBPZkZpbGVzICYmIG1hcE9mRmlsZXMuaGFzKG5hbWUpKTtcbiAgICAgICAgcmV0dXJuIG5hbWU7XG4gICAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxTQUFTLGtCQUFnQztBQUN6QyxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLE1BQU0sWUFBWTs7O0FBSDNCLElBU2E7QUFUYjs7QUFTTSxJQUFPLGNBQVAsTUFBTyxhQUFXO01BR0E7TUFGWixjQUFjO01BRXRCLFlBQW9CLE1BQWdCO0FBQWhCLGFBQUEsT0FBQTtNQUFtQjtNQVF2QyxnQkFBZ0IsVUFBK0IsYUFBeUI7QUFDcEUsY0FBTSxXQUFxQixDQUFDLFFBQVE7QUFDcEMsWUFBSSxhQUFhO0FBQ2IsbUJBQVMsS0FBSyxXQUFXOztBQUU3QixlQUFPLEtBQUssS0FBSyxJQUFZLEdBQUcsS0FBSyxXQUFXLGdCQUFnQixTQUFTLEtBQUssR0FBRyxHQUFHLEVBQUUsY0FBYyxPQUFnQixDQUFFO01BQzFIO01BT00sUUFBUSxVQUFrQixZQUF1RDs7QUFDbkYsZ0JBQU0sT0FBTyxNQUFNLGNBQWMsS0FBSyxLQUFLLElBQUksVUFBVSxFQUFFLGNBQWMsT0FBTSxDQUFFLENBQUM7QUFDbEYsZ0JBQU0sT0FBTyxJQUFJLEtBQUssQ0FBQyxJQUFJLEdBQUcsS0FBSyxrQkFBa0IsS0FBSyxhQUFhLFFBQVEsR0FBRyxVQUFVLENBQUM7QUFDN0YsaUJBQU8sUUFBUSxRQUFRLElBQUk7UUFDL0I7O01BV0Esc0JBQXNCLFVBQStCLGFBQTJCLGdCQUEwQixnQkFBMEIsVUFBa0I7QUFDbEosY0FBTSxXQUFxQixDQUFDLFFBQVE7QUFDcEMsY0FBTSxTQUFtQixDQUFBO0FBQ3pCLFlBQUksYUFBYTtBQUNiLG1CQUFTLEtBQUssV0FBVzs7QUFFN0IsZUFBTyxLQUFLLHFCQUFxQixrQkFBa0IsU0FBWSxRQUFRLGVBQWU7QUFDdEYsZUFBTyxLQUFLLHFCQUFxQixrQkFBa0IsU0FBWSxRQUFRLGVBQWU7QUFDdEYsZUFBTyxLQUFLLG1CQUFtQixZQUFZLFNBQVksUUFBUSxTQUFTO0FBQ3hFLGVBQU8sS0FBSyxLQUFLLElBQVksR0FBRyxLQUFLLFdBQVcsdUJBQXVCLFNBQVMsS0FBSyxHQUFHLElBQUksTUFBTSxPQUFPLEtBQUssR0FBRyxHQUFHLEVBQUUsY0FBYyxPQUFnQixDQUFFO01BQzFKO01BTUEsMkJBQXdCO0FBQ3BCLGVBQU8sS0FBSyxLQUFLLElBQVksdUNBQXVDLEVBQUUsU0FBUyxZQUFZLGNBQWMsT0FBZ0IsQ0FBRTtNQUMvSDtNQU9BLGFBQWEsYUFBbUI7QUFDNUIsY0FBTSx3QkFBd0IsWUFBWSxNQUFNLEdBQUc7QUFFbkQsY0FBTSxXQUFXLHNCQUFzQixJQUFHO0FBQzFDLGNBQU0sWUFBWSxzQkFBc0IsS0FBSyxHQUFHO0FBQ2hELGNBQU0sd0JBQXdCLFlBQVksTUFBTSxtQkFBbUIsUUFBUTtBQUMzRSxjQUFNLFlBQVksT0FBTyxLQUFLLGFBQWE7QUFDM0Msa0JBQVcsU0FBUyxPQUFPO0FBQzNCLGVBQU87TUFDWDtNQVFBLG1CQUFtQixVQUFrQixXQUFpQjtBQUNsRCxjQUFNLFlBQVksT0FBTyxLQUFLLGFBQWE7QUFDM0Msa0JBQVcsU0FBUyxPQUFPLGlDQUFpQyxTQUFTO0FBQ3JFLGVBQU87TUFDWDtNQU9BLGFBQWEsVUFBZ0I7QUFDekIsZUFBTyxTQUFTLE1BQU0sR0FBRyxFQUFFLElBQUc7TUFDbEM7TUFRQSxrQkFBa0IsV0FBbUIsWUFBdUQ7QUFDeEYsWUFBSTtBQUNKLFdBQUc7QUFDQyxpQkFBTyxLQUFJLElBQUssTUFBTTtpQkFDakIsY0FBYyxXQUFXLElBQUksSUFBSTtBQUMxQyxlQUFPO01BQ1g7O3lCQTVHUyxjQUFXLHNCQUFBLGFBQUEsQ0FBQTtNQUFBO21FQUFYLGNBQVcsU0FBWCxhQUFXLFdBQUEsWUFERSxPQUFNLENBQUE7Ozs7IiwibmFtZXMiOltdfQ==