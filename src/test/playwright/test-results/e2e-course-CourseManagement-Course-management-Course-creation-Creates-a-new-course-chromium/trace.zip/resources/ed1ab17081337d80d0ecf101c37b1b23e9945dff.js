import {
  ExerciseService,
  ExerciseType,
  __esm,
  __spreadProps,
  __spreadValues,
  getLatestSubmissionResult,
  init_exercise_model,
  init_exercise_service,
  init_submission_model
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/exam/participate/exam-participation.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject, of, throwError } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { HttpClient, HttpParams } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { LocalStorageService, SessionStorageService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import { catchError, map, tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import { cloneDeep } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/lodash-es.js?v=1d0d9ead";
import { captureException } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@sentry_angular-ivy.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
var ExamParticipationService;
var init_exam_participation_service = __esm({
  "src/main/webapp/app/exam/participate/exam-participation.service.ts"() {
    init_exercise_service();
    init_submission_model();
    init_exercise_model();
    ExamParticipationService = class _ExamParticipationService {
      httpClient;
      localStorageService;
      sessionStorage;
      currentlyLoadedStudentExam = new Subject();
      examExerciseIds;
      getResourceURL(courseId, examId) {
        return `api/courses/${courseId}/exams/${examId}`;
      }
      constructor(httpClient, localStorageService, sessionStorage) {
        this.httpClient = httpClient;
        this.localStorageService = localStorageService;
        this.sessionStorage = sessionStorage;
      }
      static getLocalStorageKeyForStudentExam(courseId, examId) {
        const prefix = "artemis_student_exam";
        return `${prefix}_${courseId}_${examId}`;
      }
      loadStudentExamWithExercisesForConduction(courseId, examId, studentExamId) {
        const url = this.getResourceURL(courseId, examId) + "/student-exams/" + studentExamId + "/conduction";
        return this.getStudentExamFromServer(url, courseId, examId);
      }
      loadStudentExamWithExercisesForConductionFromLocalStorage(courseId, examId) {
        const localStoredExam = JSON.parse(this.localStorageService.retrieve(_ExamParticipationService.getLocalStorageKeyForStudentExam(courseId, examId)));
        return of(localStoredExam);
      }
      loadStudentExamWithExercisesForSummary(courseId, examId, studentExamId) {
        const url = this.getResourceURL(courseId, examId) + "/student-exams/" + studentExamId + "/summary";
        return this.getStudentExamFromServer(url, courseId, examId);
      }
      getStudentExamFromServer(url, courseId, examId) {
        return this.httpClient.get(url).pipe(map((studentExam) => {
          if (studentExam.examSessions && studentExam.examSessions.length > 0 && studentExam.examSessions[0].sessionToken) {
            this.saveExamSessionTokenToSessionStorage(studentExam.examSessions[0].sessionToken);
          }
          return _ExamParticipationService.convertStudentExamFromServer(studentExam);
        }), tap((studentExam) => {
          this.currentlyLoadedStudentExam.next(studentExam);
        }), catchError(() => {
          const localStoredExam = JSON.parse(this.localStorageService.retrieve(_ExamParticipationService.getLocalStorageKeyForStudentExam(courseId, examId)));
          return of(localStoredExam);
        }));
      }
      loadStudentExamGradeInfoForSummary(courseId, examId, userId, isTestRun) {
        let params = new HttpParams();
        if (userId) {
          params = params.set("userId", userId.toString());
        }
        params = params.append("isTestRun", !!isTestRun);
        const url = this.getResourceURL(courseId, examId) + "/student-exams/grade-summary";
        return this.httpClient.get(url, { params });
      }
      getOwnStudentExam(courseId, examId) {
        const url = this.getResourceURL(courseId, examId) + "/own-student-exam";
        return this.httpClient.get(url).pipe(map((studentExam) => {
          const convertedStudentExam = _ExamParticipationService.convertStudentExamDateFromServer(studentExam);
          this.currentlyLoadedStudentExam.next(convertedStudentExam);
          return convertedStudentExam;
        }));
      }
      loadTestRunWithExercisesForConduction(courseId, examId, testRunId) {
        const url = this.getResourceURL(courseId, examId) + "/test-run/" + testRunId + "/conduction";
        return this.httpClient.get(url).pipe(map((studentExam) => {
          const convertedStudentExam = _ExamParticipationService.convertStudentExamDateFromServer(studentExam);
          this.currentlyLoadedStudentExam.next(convertedStudentExam);
          return convertedStudentExam;
        }));
      }
      loadStudentExamsForTestExamsPerCourseAndPerUserForOverviewPage(courseId) {
        const url = `api/courses/${courseId}/test-exams-per-user`;
        return this.httpClient.get(url, { observe: "response" }).pipe(map((studentExam) => this.processListOfStudentExamsFromServer(studentExam)));
      }
      processListOfStudentExamsFromServer(studentExamsResponse) {
        studentExamsResponse.body.forEach((studentExam) => {
          return _ExamParticipationService.convertStudentExamDateFromServer(studentExam);
        });
        return studentExamsResponse.body;
      }
      submitStudentExam(courseId, examId, studentExam) {
        const url = this.getResourceURL(courseId, examId) + "/student-exams/submit";
        const studentExamCopy = cloneDeep(studentExam);
        _ExamParticipationService.breakCircularDependency(studentExamCopy);
        return this.httpClient.post(url, studentExamCopy).pipe(catchError((error) => {
          if (error.status === 403 && error.headers.get("x-null-error") === "error.submissionNotInTime") {
            return throwError(() => new Error("artemisApp.studentExam.submissionNotInTime"));
          } else if (error.status === 409 && error.headers.get("x-null-error") === "error.alreadySubmitted") {
            return throwError(() => new Error("artemisApp.studentExam.alreadySubmitted"));
          } else {
            return throwError(() => new Error("artemisApp.studentExam.handInFailed"));
          }
        }));
      }
      static breakCircularDependency(studentExam) {
        studentExam.exercises.forEach((exercise) => {
          if (exercise.studentParticipations) {
            for (const participation of exercise.studentParticipations) {
              if (participation.results) {
                for (const result of participation.results) {
                  delete result.participation;
                  if (result.feedbacks) {
                    for (const feedback of result.feedbacks) {
                      delete feedback.result;
                    }
                  }
                }
              }
              if (participation.submissions) {
                for (const submission of participation.submissions) {
                  delete submission.participation;
                  const result = getLatestSubmissionResult(submission);
                  if (result) {
                    delete result.participation;
                    delete result.submission;
                  }
                }
              }
              delete participation.exercise;
            }
          }
        });
      }
      saveStudentExamToLocalStorage(courseId, examId, studentExam) {
        try {
          const studentExamCopy = cloneDeep(studentExam);
          _ExamParticipationService.breakCircularDependency(studentExamCopy);
          this.localStorageService.store(_ExamParticipationService.getLocalStorageKeyForStudentExam(courseId, examId), JSON.stringify(studentExamCopy));
        } catch (error) {
          captureException(error);
        }
      }
      saveExamSessionTokenToSessionStorage(examSessionToken) {
        this.sessionStorage.store("ExamSessionToken", examSessionToken);
      }
      updateQuizSubmission(exerciseId, quizSubmission) {
        const url = `api/exercises/${exerciseId}/submissions/exam`;
        return this.httpClient.put(url, quizSubmission);
      }
      setLastSaveFailed(saveFailed, courseId, examId) {
        const key = _ExamParticipationService.getLocalStorageKeyForStudentExam(courseId, examId) + "-save-failed";
        this.localStorageService.store(key, saveFailed);
      }
      lastSaveFailed(courseId, examId) {
        const key = _ExamParticipationService.getLocalStorageKeyForStudentExam(courseId, examId) + "-save-failed";
        return this.localStorageService.retrieve(key);
      }
      static convertStudentExamFromServer(studentExam) {
        studentExam.exercises = ExerciseService.convertExercisesDateFromServer(studentExam.exercises);
        studentExam.exam = _ExamParticipationService.convertExamDateFromServer(studentExam.exam);
        studentExam.exercises = studentExam.exercises.map((exercise) => {
          exercise.exerciseGroup = __spreadProps(__spreadValues({}, exercise.exerciseGroup), { exam: studentExam.exam });
          return exercise;
        });
        return studentExam;
      }
      static convertExamDateFromServer(exam) {
        if (exam) {
          exam.visibleDate = exam.visibleDate ? dayjs(exam.visibleDate) : void 0;
          exam.startDate = exam.startDate ? dayjs(exam.startDate) : void 0;
          exam.endDate = exam.endDate ? dayjs(exam.endDate) : void 0;
          exam.publishResultsDate = exam.publishResultsDate ? dayjs(exam.publishResultsDate) : void 0;
          exam.examStudentReviewStart = exam.examStudentReviewStart ? dayjs(exam.examStudentReviewStart) : void 0;
          exam.examStudentReviewEnd = exam.examStudentReviewEnd ? dayjs(exam.examStudentReviewEnd) : void 0;
        }
        return exam;
      }
      static convertStudentExamDateFromServer(studentExam) {
        studentExam.exam = _ExamParticipationService.convertExamDateFromServer(studentExam.exam);
        studentExam.submissionDate = studentExam.submissionDate && dayjs(studentExam.submissionDate);
        studentExam.startedDate = studentExam.startedDate && dayjs(studentExam.startedDate);
        return studentExam;
      }
      static getSubmissionForExercise(exercise) {
        const studentParticipation = _ExamParticipationService.getParticipationForExercise(exercise);
        if (studentParticipation && studentParticipation.submissions) {
          return studentParticipation.submissions.last();
        }
      }
      static getParticipationForExercise(exercise) {
        if (exercise && exercise.studentParticipations && exercise.studentParticipations.length > 0) {
          return exercise.studentParticipations[0];
        }
      }
      getExerciseButtonTooltip(exercise) {
        const submission = _ExamParticipationService.getSubmissionForExercise(exercise);
        if (!submission) {
          return "synced";
        }
        if (exercise.type !== ExerciseType.PROGRAMMING) {
          return submission.isSynced ? "synced" : "notSynced";
        }
        if (submission.submitted && submission.isSynced) {
          return "submitted";
        } else if (!submission.submitted && submission.isSynced) {
          return "notSubmitted";
        } else {
          return "notSavedOrSubmitted";
        }
      }
      getExamExerciseIds() {
        return this.examExerciseIds;
      }
      setExamExerciseIds(examExerciseIds) {
        this.examExerciseIds = examExerciseIds;
      }
      static \u0275fac = function ExamParticipationService_Factory(t) {
        return new (t || _ExamParticipationService)(i0.\u0275\u0275inject(i1.HttpClient), i0.\u0275\u0275inject(i2.LocalStorageService), i0.\u0275\u0275inject(i2.SessionStorageService));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _ExamParticipationService, factory: _ExamParticipationService.\u0275fac, providedIn: "root" });
    };
  }
});

export {
  ExamParticipationService,
  init_exam_participation_service
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvZXhhbS9wYXJ0aWNpcGF0ZS9leGFtLXBhcnRpY2lwYXRpb24uc2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBTdWJqZWN0LCBvZiwgdGhyb3dFcnJvciB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgU3R1ZGVudEV4YW0gfSBmcm9tICdhcHAvZW50aXRpZXMvc3R1ZGVudC1leGFtLm1vZGVsJztcbmltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBFcnJvclJlc3BvbnNlLCBIdHRwUGFyYW1zLCBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBMb2NhbFN0b3JhZ2VTZXJ2aWNlLCBTZXNzaW9uU3RvcmFnZVNlcnZpY2UgfSBmcm9tICduZ3gtd2Vic3RvcmFnZSc7XG5pbXBvcnQgeyBRdWl6U3VibWlzc2lvbiB9IGZyb20gJ2FwcC9lbnRpdGllcy9xdWl6L3F1aXotc3VibWlzc2lvbi5tb2RlbCc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBtYXAsIHRhcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IEV4ZXJjaXNlU2VydmljZSB9IGZyb20gJ2FwcC9leGVyY2lzZXMvc2hhcmVkL2V4ZXJjaXNlL2V4ZXJjaXNlLnNlcnZpY2UnO1xuaW1wb3J0IHsgRXhhbSB9IGZyb20gJ2FwcC9lbnRpdGllcy9leGFtLm1vZGVsJztcbmltcG9ydCBkYXlqcyBmcm9tICdkYXlqcy9lc20nO1xuaW1wb3J0IHsgU3VibWlzc2lvbiwgZ2V0TGF0ZXN0U3VibWlzc2lvblJlc3VsdCB9IGZyb20gJ2FwcC9lbnRpdGllcy9zdWJtaXNzaW9uLm1vZGVsJztcbmltcG9ydCB7IGNsb25lRGVlcCB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBFeGVyY2lzZSwgRXhlcmNpc2VUeXBlIH0gZnJvbSAnYXBwL2VudGl0aWVzL2V4ZXJjaXNlLm1vZGVsJztcbmltcG9ydCB7IEV4ZXJjaXNlR3JvdXAgfSBmcm9tICdhcHAvZW50aXRpZXMvZXhlcmNpc2UtZ3JvdXAubW9kZWwnO1xuaW1wb3J0IHsgU3R1ZGVudEV4YW1XaXRoR3JhZGVEVE8gfSBmcm9tICdhcHAvZXhhbS9leGFtLXNjb3Jlcy9leGFtLXNjb3JlLWR0b3MubW9kZWwnO1xuaW1wb3J0IHsgY2FwdHVyZUV4Y2VwdGlvbiB9IGZyb20gJ0BzZW50cnkvYW5ndWxhci1pdnknO1xuaW1wb3J0IHsgU3R1ZGVudFBhcnRpY2lwYXRpb24gfSBmcm9tICdhcHAvZW50aXRpZXMvcGFydGljaXBhdGlvbi9zdHVkZW50LXBhcnRpY2lwYXRpb24ubW9kZWwnO1xuXG5leHBvcnQgdHlwZSBCdXR0b25Ub29sdGlwVHlwZSA9ICdzdWJtaXR0ZWQnIHwgJ3N1Ym1pdHRlZFN1Ym1pc3Npb25MaW1pdFJlYWNoZWQnIHwgJ25vdFN1Ym1pdHRlZCcgfCAnc3luY2VkJyB8ICdub3RTeW5jZWQnIHwgJ25vdFNhdmVkT3JTdWJtaXR0ZWQnO1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIEV4YW1QYXJ0aWNpcGF0aW9uU2VydmljZSB7XG4gICAgcHVibGljIGN1cnJlbnRseUxvYWRlZFN0dWRlbnRFeGFtID0gbmV3IFN1YmplY3Q8U3R1ZGVudEV4YW0+KCk7XG5cbiAgICBwcml2YXRlIGV4YW1FeGVyY2lzZUlkczogbnVtYmVyW107XG5cbiAgICBwdWJsaWMgZ2V0UmVzb3VyY2VVUkwoY291cnNlSWQ6IG51bWJlciwgZXhhbUlkOiBudW1iZXIpOiBzdHJpbmcge1xuICAgICAgICByZXR1cm4gYGFwaS9jb3Vyc2VzLyR7Y291cnNlSWR9L2V4YW1zLyR7ZXhhbUlkfWA7XG4gICAgfVxuXG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgaHR0cENsaWVudDogSHR0cENsaWVudCxcbiAgICAgICAgcHJpdmF0ZSBsb2NhbFN0b3JhZ2VTZXJ2aWNlOiBMb2NhbFN0b3JhZ2VTZXJ2aWNlLFxuICAgICAgICBwcml2YXRlIHNlc3Npb25TdG9yYWdlOiBTZXNzaW9uU3RvcmFnZVNlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgcHJpdmF0ZSBzdGF0aWMgZ2V0TG9jYWxTdG9yYWdlS2V5Rm9yU3R1ZGVudEV4YW0oY291cnNlSWQ6IG51bWJlciwgZXhhbUlkOiBudW1iZXIpOiBzdHJpbmcge1xuICAgICAgICBjb25zdCBwcmVmaXggPSAnYXJ0ZW1pc19zdHVkZW50X2V4YW0nO1xuICAgICAgICByZXR1cm4gYCR7cHJlZml4fV8ke2NvdXJzZUlkfV8ke2V4YW1JZH1gO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHJpZXZlcyBhIHtAbGluayBTdHVkZW50RXhhbX0gZnJvbSBzZXJ2ZXIgb3IgbG9jYWxzdG9yYWdlLiBXaWxsIGFsc28gbWFyayB0aGUgc3R1ZGVudCBleGFtIGFzIHN0YXJ0ZWRcbiAgICAgKiBAcGFyYW0gY291cnNlSWQgdGhlIGlkIG9mIHRoZSBjb3Vyc2UgdGhlIGV4YW0gaXMgY3JlYXRlZCBpblxuICAgICAqIEBwYXJhbSBleGFtSWQgdGhlIGlkIG9mIHRoZSBleGFtXG4gICAgICogQHBhcmFtIHN0dWRlbnRFeGFtSWQgdGhlIGlkIG9mIHRoZSBzdHVkZW50IEV4YW0gd2hpY2ggc2hvdWxkIGJlIGxvYWRlZFxuICAgICAqIEByZXR1cm5zIHRoZSBzdHVkZW50RXhhbSB3aXRoIEV4ZXJjaXNlcyBmb3IgdGhlIGNvbmR1Y3Rpb24tcGhhc2VcbiAgICAgKi9cbiAgICBwdWJsaWMgbG9hZFN0dWRlbnRFeGFtV2l0aEV4ZXJjaXNlc0ZvckNvbmR1Y3Rpb24oY291cnNlSWQ6IG51bWJlciwgZXhhbUlkOiBudW1iZXIsIHN0dWRlbnRFeGFtSWQ6IG51bWJlcik6IE9ic2VydmFibGU8U3R1ZGVudEV4YW0+IHtcbiAgICAgICAgY29uc3QgdXJsID0gdGhpcy5nZXRSZXNvdXJjZVVSTChjb3Vyc2VJZCwgZXhhbUlkKSArICcvc3R1ZGVudC1leGFtcy8nICsgc3R1ZGVudEV4YW1JZCArICcvY29uZHVjdGlvbic7XG4gICAgICAgIHJldHVybiB0aGlzLmdldFN0dWRlbnRFeGFtRnJvbVNlcnZlcih1cmwsIGNvdXJzZUlkLCBleGFtSWQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHJpZXZlcyBhIHtAbGluayBTdHVkZW50RXhhbX0gZnJvbSB0aGUgbG9jYWxzdG9yYWdlLiBXaWxsIGFsc28gbWFyayB0aGUgc3R1ZGVudCBleGFtIGFzIHN0YXJ0ZWRcbiAgICAgKlxuICAgICAqIEBwYXJhbSBjb3Vyc2VJZCB0aGUgaWQgb2YgdGhlIGNvdXJzZSB0aGUgZXhhbSBpcyBjcmVhdGVkIGluXG4gICAgICogQHBhcmFtIGV4YW1JZCB0aGUgaWQgb2YgdGhlIGV4YW1cbiAgICAgKi9cbiAgICBwdWJsaWMgbG9hZFN0dWRlbnRFeGFtV2l0aEV4ZXJjaXNlc0ZvckNvbmR1Y3Rpb25Gcm9tTG9jYWxTdG9yYWdlKGNvdXJzZUlkOiBudW1iZXIsIGV4YW1JZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxTdHVkZW50RXhhbT4ge1xuICAgICAgICBjb25zdCBsb2NhbFN0b3JlZEV4YW06IFN0dWRlbnRFeGFtID0gSlNPTi5wYXJzZSh0aGlzLmxvY2FsU3RvcmFnZVNlcnZpY2UucmV0cmlldmUoRXhhbVBhcnRpY2lwYXRpb25TZXJ2aWNlLmdldExvY2FsU3RvcmFnZUtleUZvclN0dWRlbnRFeGFtKGNvdXJzZUlkLCBleGFtSWQpKSk7XG4gICAgICAgIHJldHVybiBvZihsb2NhbFN0b3JlZEV4YW0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHJpZXZlcyBhIHtAbGluayBTdHVkZW50RXhhbX0gZnJvbSBzZXJ2ZXIgb3IgbG9jYWxzdG9yYWdlIGZvciBkaXNwbGF5IG9mIHRoZSBzdW1tYXJ5LlxuICAgICAqIEBwYXJhbSBjb3Vyc2VJZCB0aGUgaWQgb2YgdGhlIGNvdXJzZSB0aGUgZXhhbSBpcyBjcmVhdGVkIGluXG4gICAgICogQHBhcmFtIGV4YW1JZCB0aGUgaWQgb2YgdGhlIGV4YW1cbiAgICAgKiBAcGFyYW0gc3R1ZGVudEV4YW1JZCB0aGUgaWQgb2YgdGhlIHN0dWRlbnRFeGFtXG4gICAgICogQHJldHVybnMgYSBzdHVkZW50RXhhbSB3aXRoIEV4ZXJjaXNlcyBmb3IgdGhlIHN1bW1hcnktcGhhc2VcbiAgICAgKi9cbiAgICBwdWJsaWMgbG9hZFN0dWRlbnRFeGFtV2l0aEV4ZXJjaXNlc0ZvclN1bW1hcnkoY291cnNlSWQ6IG51bWJlciwgZXhhbUlkOiBudW1iZXIsIHN0dWRlbnRFeGFtSWQ6IG51bWJlcik6IE9ic2VydmFibGU8U3R1ZGVudEV4YW0+IHtcbiAgICAgICAgY29uc3QgdXJsID0gdGhpcy5nZXRSZXNvdXJjZVVSTChjb3Vyc2VJZCwgZXhhbUlkKSArICcvc3R1ZGVudC1leGFtcy8nICsgc3R1ZGVudEV4YW1JZCArICcvc3VtbWFyeSc7XG4gICAgICAgIHJldHVybiB0aGlzLmdldFN0dWRlbnRFeGFtRnJvbVNlcnZlcih1cmwsIGNvdXJzZUlkLCBleGFtSWQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHJpZXZlcyBhIHtAbGluayBTdHVkZW50RXhhbX0gZnJvbSBzZXJ2ZXIgb3IgbG9jYWxzdG9yYWdlLlxuICAgICAqL1xuICAgIHByaXZhdGUgZ2V0U3R1ZGVudEV4YW1Gcm9tU2VydmVyKHVybDogc3RyaW5nLCBjb3Vyc2VJZDogbnVtYmVyLCBleGFtSWQ6IG51bWJlcik6IE9ic2VydmFibGU8U3R1ZGVudEV4YW0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cENsaWVudC5nZXQ8U3R1ZGVudEV4YW0+KHVybCkucGlwZShcbiAgICAgICAgICAgIG1hcCgoc3R1ZGVudEV4YW06IFN0dWRlbnRFeGFtKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHN0dWRlbnRFeGFtLmV4YW1TZXNzaW9ucyAmJiBzdHVkZW50RXhhbS5leGFtU2Vzc2lvbnMubGVuZ3RoID4gMCAmJiBzdHVkZW50RXhhbS5leGFtU2Vzc2lvbnNbMF0uc2Vzc2lvblRva2VuKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2F2ZUV4YW1TZXNzaW9uVG9rZW5Ub1Nlc3Npb25TdG9yYWdlKHN0dWRlbnRFeGFtLmV4YW1TZXNzaW9uc1swXS5zZXNzaW9uVG9rZW4pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gRXhhbVBhcnRpY2lwYXRpb25TZXJ2aWNlLmNvbnZlcnRTdHVkZW50RXhhbUZyb21TZXJ2ZXIoc3R1ZGVudEV4YW0pO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0YXAoKHN0dWRlbnRFeGFtOiBTdHVkZW50RXhhbSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudGx5TG9hZGVkU3R1ZGVudEV4YW0ubmV4dChzdHVkZW50RXhhbSk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGxvY2FsU3RvcmVkRXhhbTogU3R1ZGVudEV4YW0gPSBKU09OLnBhcnNlKHRoaXMubG9jYWxTdG9yYWdlU2VydmljZS5yZXRyaWV2ZShFeGFtUGFydGljaXBhdGlvblNlcnZpY2UuZ2V0TG9jYWxTdG9yYWdlS2V5Rm9yU3R1ZGVudEV4YW0oY291cnNlSWQsIGV4YW1JZCkpKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gb2YobG9jYWxTdG9yZWRFeGFtKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHJpZXZlcyBhIHtAbGluayBTdHVkZW50RXhhbVdpdGhHcmFkZURUT30gd2l0aG91dCB7QGxpbmsgU3R1ZGVudEV4YW1XaXRoR3JhZGVEVE8jc3R1ZGVudEV4YW19IGZyb20gc2VydmVyIGZvciBkaXNwbGF5IG9mIHRoZSBzdW1tYXJ5LlxuICAgICAqIHtAbGluayBTdHVkZW50RXhhbVdpdGhHcmFkZURUTyNzdHVkZW50RXhhbX0gaXMgZXhjbHVkZWQgZnJvbSByZXNwb25zZSB0byBzYXZlIGJhbmR3aWR0aC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBjb3Vyc2VJZCB0aGUgaWQgb2YgdGhlIGNvdXJzZSB0aGUgZXhhbSBpcyBjcmVhdGVkIGluXG4gICAgICogQHBhcmFtIGV4YW1JZCB0aGUgaWQgb2YgdGhlIGV4YW1cbiAgICAgKiBAcGFyYW0gdXNlcklkIHRoZSBpZCBvZiB0aGUgc3R1ZGVudCBpZiB0aGUgY3VycmVudCBjYWxsZXIgaXMgYW4gaW5zdHJ1Y3RvciwgdGhlIGdyYWRlIGluZm8gZm9yIGN1cnJlbnQgdXNlcidzIGV4YW0gd2lsbCBiZSByZXRyaWV2ZWQgaWYgdGhpcyBhcmd1bWVudCBpcyBlbXB0eVxuICAgICAqIEBwYXJhbSBpc1Rlc3RSdW5cbiAgICAgKi9cbiAgICBwdWJsaWMgbG9hZFN0dWRlbnRFeGFtR3JhZGVJbmZvRm9yU3VtbWFyeShjb3Vyc2VJZDogbnVtYmVyLCBleGFtSWQ6IG51bWJlciwgdXNlcklkPzogbnVtYmVyLCBpc1Rlc3RSdW4/OiBib29sZWFuKTogT2JzZXJ2YWJsZTxTdHVkZW50RXhhbVdpdGhHcmFkZURUTz4ge1xuICAgICAgICBsZXQgcGFyYW1zID0gbmV3IEh0dHBQYXJhbXMoKTtcbiAgICAgICAgaWYgKHVzZXJJZCkge1xuICAgICAgICAgICAgcGFyYW1zID0gcGFyYW1zLnNldCgndXNlcklkJywgdXNlcklkLnRvU3RyaW5nKCkpO1xuICAgICAgICB9XG4gICAgICAgIHBhcmFtcyA9IHBhcmFtcy5hcHBlbmQoJ2lzVGVzdFJ1bicsICEhaXNUZXN0UnVuKTtcblxuICAgICAgICBjb25zdCB1cmwgPSB0aGlzLmdldFJlc291cmNlVVJMKGNvdXJzZUlkLCBleGFtSWQpICsgJy9zdHVkZW50LWV4YW1zL2dyYWRlLXN1bW1hcnknO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwQ2xpZW50LmdldDxTdHVkZW50RXhhbVdpdGhHcmFkZURUTz4odXJsLCB7IHBhcmFtcyB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBMb2FkcyB7QGxpbmsgU3R1ZGVudEV4YW19IG9iamVjdCBmcm9tIHNlcnZlclxuICAgICAqIEBwYXJhbSBjb3Vyc2VJZCB0aGUgaWQgb2YgdGhlIGNvdXJzZSB0aGUgZXhhbSBpcyBjcmVhdGVkIGluXG4gICAgICogQHBhcmFtIGV4YW1JZCB0aGUgaWQgb2YgdGhlIGV4YW1cbiAgICAgKi9cbiAgICBwdWJsaWMgZ2V0T3duU3R1ZGVudEV4YW0oY291cnNlSWQ6IG51bWJlciwgZXhhbUlkOiBudW1iZXIpOiBPYnNlcnZhYmxlPFN0dWRlbnRFeGFtPiB7XG4gICAgICAgIGNvbnN0IHVybCA9IHRoaXMuZ2V0UmVzb3VyY2VVUkwoY291cnNlSWQsIGV4YW1JZCkgKyAnL293bi1zdHVkZW50LWV4YW0nO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwQ2xpZW50LmdldDxTdHVkZW50RXhhbT4odXJsKS5waXBlKFxuICAgICAgICAgICAgbWFwKChzdHVkZW50RXhhbTogU3R1ZGVudEV4YW0pID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBjb252ZXJ0ZWRTdHVkZW50RXhhbSA9IEV4YW1QYXJ0aWNpcGF0aW9uU2VydmljZS5jb252ZXJ0U3R1ZGVudEV4YW1EYXRlRnJvbVNlcnZlcihzdHVkZW50RXhhbSk7XG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50bHlMb2FkZWRTdHVkZW50RXhhbS5uZXh0KGNvbnZlcnRlZFN0dWRlbnRFeGFtKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udmVydGVkU3R1ZGVudEV4YW07XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgbG9hZFRlc3RSdW5XaXRoRXhlcmNpc2VzRm9yQ29uZHVjdGlvbihjb3Vyc2VJZDogbnVtYmVyLCBleGFtSWQ6IG51bWJlciwgdGVzdFJ1bklkOiBudW1iZXIpOiBPYnNlcnZhYmxlPFN0dWRlbnRFeGFtPiB7XG4gICAgICAgIGNvbnN0IHVybCA9IHRoaXMuZ2V0UmVzb3VyY2VVUkwoY291cnNlSWQsIGV4YW1JZCkgKyAnL3Rlc3QtcnVuLycgKyB0ZXN0UnVuSWQgKyAnL2NvbmR1Y3Rpb24nO1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwQ2xpZW50LmdldDxTdHVkZW50RXhhbT4odXJsKS5waXBlKFxuICAgICAgICAgICAgbWFwKChzdHVkZW50RXhhbTogU3R1ZGVudEV4YW0pID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBjb252ZXJ0ZWRTdHVkZW50RXhhbSA9IEV4YW1QYXJ0aWNpcGF0aW9uU2VydmljZS5jb252ZXJ0U3R1ZGVudEV4YW1EYXRlRnJvbVNlcnZlcihzdHVkZW50RXhhbSk7XG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50bHlMb2FkZWRTdHVkZW50RXhhbS5uZXh0KGNvbnZlcnRlZFN0dWRlbnRFeGFtKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udmVydGVkU3R1ZGVudEV4YW07XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBMb2FkcyB7QGxpbmsgU3R1ZGVudEV4YW19IG9iamVjdHMgbGlua2VkIHRvIGEgdGVzdCBleGFtIHBlciB1c2VyIGFuZCBwZXIgY291cnNlIGZyb20gc2VydmVyXG4gICAgICogQHBhcmFtIGNvdXJzZUlkIHRoZSBpZCBvZiB0aGUgY291cnNlIHdlIGFyZSBpbnRlcmVzdGVkXG4gICAgICogQHJldHVybnMgYSBMaXN0IG9mIGFsbCBTdHVkZW50RXhhbXMgd2l0aG91dCBFeGVyY2lzZXMgcGVyIFVzZXIgYW5kIENvdXJzZVxuICAgICAqL1xuICAgIHB1YmxpYyBsb2FkU3R1ZGVudEV4YW1zRm9yVGVzdEV4YW1zUGVyQ291cnNlQW5kUGVyVXNlckZvck92ZXJ2aWV3UGFnZShjb3Vyc2VJZDogbnVtYmVyKTogT2JzZXJ2YWJsZTxTdHVkZW50RXhhbVtdPiB7XG4gICAgICAgIGNvbnN0IHVybCA9IGBhcGkvY291cnNlcy8ke2NvdXJzZUlkfS90ZXN0LWV4YW1zLXBlci11c2VyYDtcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cENsaWVudFxuICAgICAgICAgICAgLmdldDxTdHVkZW50RXhhbVtdPih1cmwsIHsgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyB9KVxuICAgICAgICAgICAgLnBpcGUobWFwKChzdHVkZW50RXhhbTogSHR0cFJlc3BvbnNlPFN0dWRlbnRFeGFtW10+KSA9PiB0aGlzLnByb2Nlc3NMaXN0T2ZTdHVkZW50RXhhbXNGcm9tU2VydmVyKHN0dWRlbnRFeGFtKSkpO1xuICAgIH1cblxuICAgIHByaXZhdGUgcHJvY2Vzc0xpc3RPZlN0dWRlbnRFeGFtc0Zyb21TZXJ2ZXIoc3R1ZGVudEV4YW1zUmVzcG9uc2U6IEh0dHBSZXNwb25zZTxTdHVkZW50RXhhbVtdPikge1xuICAgICAgICBzdHVkZW50RXhhbXNSZXNwb25zZS5ib2R5IS5mb3JFYWNoKChzdHVkZW50RXhhbSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIEV4YW1QYXJ0aWNpcGF0aW9uU2VydmljZS5jb252ZXJ0U3R1ZGVudEV4YW1EYXRlRnJvbVNlcnZlcihzdHVkZW50RXhhbSk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gc3R1ZGVudEV4YW1zUmVzcG9uc2UuYm9keSE7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU3VibWl0cyB7QGxpbmsgU3R1ZGVudEV4YW19IC0gdGhlIGV4YW0gY2Fubm90IGJlIHVwZGF0ZWQgYWZ0ZXJ3YXJkcyBhbnltb3JlXG4gICAgICogQHBhcmFtIGNvdXJzZUlkIHRoZSBpZCBvZiB0aGUgY291cnNlIHRoZSBleGFtIGlzIGNyZWF0ZWQgaW5cbiAgICAgKiBAcGFyYW0gZXhhbUlkIHRoZSBpZCBvZiB0aGUgZXhhbVxuICAgICAqIEBwYXJhbSBzdHVkZW50RXhhbSB0aGUgc3R1ZGVudCBleGFtIHRvIHN1Ym1pdFxuICAgICAqL1xuICAgIHB1YmxpYyBzdWJtaXRTdHVkZW50RXhhbShjb3Vyc2VJZDogbnVtYmVyLCBleGFtSWQ6IG51bWJlciwgc3R1ZGVudEV4YW06IFN0dWRlbnRFeGFtKTogT2JzZXJ2YWJsZTx2b2lkPiB7XG4gICAgICAgIGNvbnN0IHVybCA9IHRoaXMuZ2V0UmVzb3VyY2VVUkwoY291cnNlSWQsIGV4YW1JZCkgKyAnL3N0dWRlbnQtZXhhbXMvc3VibWl0JztcbiAgICAgICAgY29uc3Qgc3R1ZGVudEV4YW1Db3B5ID0gY2xvbmVEZWVwKHN0dWRlbnRFeGFtKTtcbiAgICAgICAgRXhhbVBhcnRpY2lwYXRpb25TZXJ2aWNlLmJyZWFrQ2lyY3VsYXJEZXBlbmRlbmN5KHN0dWRlbnRFeGFtQ29weSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cENsaWVudC5wb3N0PHZvaWQ+KHVybCwgc3R1ZGVudEV4YW1Db3B5KS5waXBlKFxuICAgICAgICAgICAgY2F0Y2hFcnJvcigoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGVycm9yLnN0YXR1cyA9PT0gNDAzICYmIGVycm9yLmhlYWRlcnMuZ2V0KCd4LW51bGwtZXJyb3InKSA9PT0gJ2Vycm9yLnN1Ym1pc3Npb25Ob3RJblRpbWUnKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aHJvd0Vycm9yKCgpID0+IG5ldyBFcnJvcignYXJ0ZW1pc0FwcC5zdHVkZW50RXhhbS5zdWJtaXNzaW9uTm90SW5UaW1lJykpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MDkgJiYgZXJyb3IuaGVhZGVycy5nZXQoJ3gtbnVsbC1lcnJvcicpID09PSAnZXJyb3IuYWxyZWFkeVN1Ym1pdHRlZCcpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoKCkgPT4gbmV3IEVycm9yKCdhcnRlbWlzQXBwLnN0dWRlbnRFeGFtLmFscmVhZHlTdWJtaXR0ZWQnKSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoKCkgPT4gbmV3IEVycm9yKCdhcnRlbWlzQXBwLnN0dWRlbnRFeGFtLmhhbmRJbkZhaWxlZCcpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHN0YXRpYyBicmVha0NpcmN1bGFyRGVwZW5kZW5jeShzdHVkZW50RXhhbTogU3R1ZGVudEV4YW0pIHtcbiAgICAgICAgc3R1ZGVudEV4YW0uZXhlcmNpc2VzIS5mb3JFYWNoKChleGVyY2lzZSkgPT4ge1xuICAgICAgICAgICAgaWYgKGV4ZXJjaXNlLnN0dWRlbnRQYXJ0aWNpcGF0aW9ucykge1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgcGFydGljaXBhdGlvbiBvZiBleGVyY2lzZS5zdHVkZW50UGFydGljaXBhdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhcnRpY2lwYXRpb24ucmVzdWx0cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCByZXN1bHQgb2YgcGFydGljaXBhdGlvbi5yZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlIHJlc3VsdC5wYXJ0aWNpcGF0aW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQuZmVlZGJhY2tzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3QgZmVlZGJhY2sgb2YgcmVzdWx0LmZlZWRiYWNrcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlIGZlZWRiYWNrLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAocGFydGljaXBhdGlvbi5zdWJtaXNzaW9ucykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBzdWJtaXNzaW9uIG9mIHBhcnRpY2lwYXRpb24uc3VibWlzc2lvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGUgc3VibWlzc2lvbi5wYXJ0aWNpcGF0aW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGdldExhdGVzdFN1Ym1pc3Npb25SZXN1bHQoc3VibWlzc2lvbik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGUgcmVzdWx0LnBhcnRpY2lwYXRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZSByZXN1bHQuc3VibWlzc2lvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIHBhcnRpY2lwYXRpb24uZXhlcmNpc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBzYXZlIHRoZSBzdHVkZW50RXhhbSB0byB0aGUgbG9jYWwgU3RvcmFnZVxuICAgICAqXG4gICAgICogQHBhcmFtIGNvdXJzZUlkXG4gICAgICogQHBhcmFtIGV4YW1JZFxuICAgICAqIEBwYXJhbSBzdHVkZW50RXhhbVxuICAgICAqL1xuICAgIHB1YmxpYyBzYXZlU3R1ZGVudEV4YW1Ub0xvY2FsU3RvcmFnZShjb3Vyc2VJZDogbnVtYmVyLCBleGFtSWQ6IG51bWJlciwgc3R1ZGVudEV4YW06IFN0dWRlbnRFeGFtKTogdm9pZCB7XG4gICAgICAgIC8vIGlmIHRoZSBmb2xsb3dpbmcgY29kZSBmYWlscywgdGhpcyBzaG91bGQgbmV2ZXIgYWZmZWN0IHRoZSBleGFtXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBzdHVkZW50RXhhbUNvcHkgPSBjbG9uZURlZXAoc3R1ZGVudEV4YW0pO1xuICAgICAgICAgICAgRXhhbVBhcnRpY2lwYXRpb25TZXJ2aWNlLmJyZWFrQ2lyY3VsYXJEZXBlbmRlbmN5KHN0dWRlbnRFeGFtQ29weSk7XG4gICAgICAgICAgICB0aGlzLmxvY2FsU3RvcmFnZVNlcnZpY2Uuc3RvcmUoRXhhbVBhcnRpY2lwYXRpb25TZXJ2aWNlLmdldExvY2FsU3RvcmFnZUtleUZvclN0dWRlbnRFeGFtKGNvdXJzZUlkLCBleGFtSWQpLCBKU09OLnN0cmluZ2lmeShzdHVkZW50RXhhbUNvcHkpKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNhcHR1cmVFeGNlcHRpb24oZXJyb3IpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogc2F2ZXMgbGF0ZXN0IGV4YW1TZXNzaW9uVG9rZW4gdG8gc2Vzc2lvblN0b3JhZ2VcbiAgICAgKiBAcGFyYW0gZXhhbVNlc3Npb25Ub2tlbiBsYXRlc3QgZXhhbVNlc3Npb25Ub2tlblxuICAgICAqL1xuICAgIHB1YmxpYyBzYXZlRXhhbVNlc3Npb25Ub2tlblRvU2Vzc2lvblN0b3JhZ2UoZXhhbVNlc3Npb25Ub2tlbjogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIHRoaXMuc2Vzc2lvblN0b3JhZ2Uuc3RvcmUoJ0V4YW1TZXNzaW9uVG9rZW4nLCBleGFtU2Vzc2lvblRva2VuKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBVcGRhdGUgYSBxdWl6U3VibWlzc2lvblxuICAgICAqXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlSWRcbiAgICAgKiBAcGFyYW0gcXVpelN1Ym1pc3Npb25cbiAgICAgKi9cbiAgICBwdWJsaWMgdXBkYXRlUXVpelN1Ym1pc3Npb24oZXhlcmNpc2VJZDogbnVtYmVyLCBxdWl6U3VibWlzc2lvbjogUXVpelN1Ym1pc3Npb24pOiBPYnNlcnZhYmxlPFF1aXpTdWJtaXNzaW9uPiB7XG4gICAgICAgIGNvbnN0IHVybCA9IGBhcGkvZXhlcmNpc2VzLyR7ZXhlcmNpc2VJZH0vc3VibWlzc2lvbnMvZXhhbWA7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBDbGllbnQucHV0PFF1aXpTdWJtaXNzaW9uPih1cmwsIHF1aXpTdWJtaXNzaW9uKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgc2V0TGFzdFNhdmVGYWlsZWQoc2F2ZUZhaWxlZDogYm9vbGVhbiwgY291cnNlSWQ6IG51bWJlciwgZXhhbUlkOiBudW1iZXIpOiB2b2lkIHtcbiAgICAgICAgY29uc3Qga2V5ID0gRXhhbVBhcnRpY2lwYXRpb25TZXJ2aWNlLmdldExvY2FsU3RvcmFnZUtleUZvclN0dWRlbnRFeGFtKGNvdXJzZUlkLCBleGFtSWQpICsgJy1zYXZlLWZhaWxlZCc7XG4gICAgICAgIHRoaXMubG9jYWxTdG9yYWdlU2VydmljZS5zdG9yZShrZXksIHNhdmVGYWlsZWQpO1xuICAgIH1cblxuICAgIHB1YmxpYyBsYXN0U2F2ZUZhaWxlZChjb3Vyc2VJZDogbnVtYmVyLCBleGFtSWQ6IG51bWJlcik6IGJvb2xlYW4ge1xuICAgICAgICBjb25zdCBrZXkgPSBFeGFtUGFydGljaXBhdGlvblNlcnZpY2UuZ2V0TG9jYWxTdG9yYWdlS2V5Rm9yU3R1ZGVudEV4YW0oY291cnNlSWQsIGV4YW1JZCkgKyAnLXNhdmUtZmFpbGVkJztcbiAgICAgICAgcmV0dXJuIHRoaXMubG9jYWxTdG9yYWdlU2VydmljZS5yZXRyaWV2ZShrZXkpO1xuICAgIH1cblxuICAgIHByaXZhdGUgc3RhdGljIGNvbnZlcnRTdHVkZW50RXhhbUZyb21TZXJ2ZXIoc3R1ZGVudEV4YW06IFN0dWRlbnRFeGFtKTogU3R1ZGVudEV4YW0ge1xuICAgICAgICBzdHVkZW50RXhhbS5leGVyY2lzZXMgPSBFeGVyY2lzZVNlcnZpY2UuY29udmVydEV4ZXJjaXNlc0RhdGVGcm9tU2VydmVyKHN0dWRlbnRFeGFtLmV4ZXJjaXNlcyk7XG4gICAgICAgIHN0dWRlbnRFeGFtLmV4YW0gPSBFeGFtUGFydGljaXBhdGlvblNlcnZpY2UuY29udmVydEV4YW1EYXRlRnJvbVNlcnZlcihzdHVkZW50RXhhbS5leGFtKTtcbiAgICAgICAgLy8gQWRkIGEgZGVmYXVsdCBleGVyY2lzZSBncm91cCB0byBjb25uZWN0IGV4ZXJjaXNlcyB3aXRoIHRoZSBleGFtLlxuICAgICAgICBzdHVkZW50RXhhbS5leGVyY2lzZXMgPSBzdHVkZW50RXhhbS5leGVyY2lzZXMubWFwKChleGVyY2lzZTogRXhlcmNpc2UpID0+IHtcbiAgICAgICAgICAgIGV4ZXJjaXNlLmV4ZXJjaXNlR3JvdXAgPSB7IC4uLmV4ZXJjaXNlLmV4ZXJjaXNlR3JvdXAhLCBleGFtOiBzdHVkZW50RXhhbS5leGFtIH0gYXMgRXhlcmNpc2VHcm91cDtcbiAgICAgICAgICAgIHJldHVybiBleGVyY2lzZTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBzdHVkZW50RXhhbTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHN0YXRpYyBjb252ZXJ0RXhhbURhdGVGcm9tU2VydmVyKGV4YW0/OiBFeGFtKSB7XG4gICAgICAgIGlmIChleGFtKSB7XG4gICAgICAgICAgICBleGFtLnZpc2libGVEYXRlID0gZXhhbS52aXNpYmxlRGF0ZSA/IGRheWpzKGV4YW0udmlzaWJsZURhdGUpIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgZXhhbS5zdGFydERhdGUgPSBleGFtLnN0YXJ0RGF0ZSA/IGRheWpzKGV4YW0uc3RhcnREYXRlKSA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGV4YW0uZW5kRGF0ZSA9IGV4YW0uZW5kRGF0ZSA/IGRheWpzKGV4YW0uZW5kRGF0ZSkgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgICBleGFtLnB1Ymxpc2hSZXN1bHRzRGF0ZSA9IGV4YW0ucHVibGlzaFJlc3VsdHNEYXRlID8gZGF5anMoZXhhbS5wdWJsaXNoUmVzdWx0c0RhdGUpIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgZXhhbS5leGFtU3R1ZGVudFJldmlld1N0YXJ0ID0gZXhhbS5leGFtU3R1ZGVudFJldmlld1N0YXJ0ID8gZGF5anMoZXhhbS5leGFtU3R1ZGVudFJldmlld1N0YXJ0KSA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGV4YW0uZXhhbVN0dWRlbnRSZXZpZXdFbmQgPSBleGFtLmV4YW1TdHVkZW50UmV2aWV3RW5kID8gZGF5anMoZXhhbS5leGFtU3R1ZGVudFJldmlld0VuZCkgOiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGV4YW07XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBzdGF0aWMgY29udmVydFN0dWRlbnRFeGFtRGF0ZUZyb21TZXJ2ZXIoc3R1ZGVudEV4YW06IFN0dWRlbnRFeGFtKTogU3R1ZGVudEV4YW0ge1xuICAgICAgICBzdHVkZW50RXhhbS5leGFtID0gRXhhbVBhcnRpY2lwYXRpb25TZXJ2aWNlLmNvbnZlcnRFeGFtRGF0ZUZyb21TZXJ2ZXIoc3R1ZGVudEV4YW0uZXhhbSk7XG4gICAgICAgIHN0dWRlbnRFeGFtLnN1Ym1pc3Npb25EYXRlID0gc3R1ZGVudEV4YW0uc3VibWlzc2lvbkRhdGUgJiYgZGF5anMoc3R1ZGVudEV4YW0uc3VibWlzc2lvbkRhdGUpO1xuICAgICAgICBzdHVkZW50RXhhbS5zdGFydGVkRGF0ZSA9IHN0dWRlbnRFeGFtLnN0YXJ0ZWREYXRlICYmIGRheWpzKHN0dWRlbnRFeGFtLnN0YXJ0ZWREYXRlKTtcbiAgICAgICAgcmV0dXJuIHN0dWRlbnRFeGFtO1xuICAgIH1cblxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0U3VibWlzc2lvbkZvckV4ZXJjaXNlKGV4ZXJjaXNlOiBFeGVyY2lzZSk6IFN1Ym1pc3Npb24gfCB1bmRlZmluZWQge1xuICAgICAgICBjb25zdCBzdHVkZW50UGFydGljaXBhdGlvbiA9IEV4YW1QYXJ0aWNpcGF0aW9uU2VydmljZS5nZXRQYXJ0aWNpcGF0aW9uRm9yRXhlcmNpc2UoZXhlcmNpc2UpO1xuICAgICAgICBpZiAoc3R1ZGVudFBhcnRpY2lwYXRpb24gJiYgc3R1ZGVudFBhcnRpY2lwYXRpb24uc3VibWlzc2lvbnMpIHtcbiAgICAgICAgICAgIC8vIE5PVEU6IHVzaW5nIFwic3VibWlzc2lvbnNbMF1cIiBtaWdodCBub3Qgd29yayBmb3IgcHJvZ3JhbW1pbmcgZXhlcmNpc2VzIHdpdGggbXVsdGlwbGUgc3VibWlzc2lvbnMsIGl0IGlzIGJldHRlciB0byBhbHdheXMgdGFrZSB0aGUgbGFzdCBzdWJtaXNzaW9uXG4gICAgICAgICAgICByZXR1cm4gc3R1ZGVudFBhcnRpY2lwYXRpb24uc3VibWlzc2lvbnMubGFzdCgpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IHRoZSBmaXJzdCBwYXJ0aWNpcGF0aW9uIGZvciB0aGUgZ2l2ZW4gZXhlcmNpc2UuXG4gICAgICogQHBhcmFtIGV4ZXJjaXNlIHRoZSBleGVyY2lzZSBmb3Igd2hpY2ggdG8gZ2V0IHRoZSBwYXJ0aWNpcGF0aW9uXG4gICAgICogQHJldHVybiB0aGUgZmlyc3QgcGFydGljaXBhdGlvbiBvZiB0aGUgZ2l2ZW4gZXhlcmNpc2VcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGdldFBhcnRpY2lwYXRpb25Gb3JFeGVyY2lzZShleGVyY2lzZTogRXhlcmNpc2UpOiBTdHVkZW50UGFydGljaXBhdGlvbiB8IHVuZGVmaW5lZCB7XG4gICAgICAgIGlmIChleGVyY2lzZSAmJiBleGVyY2lzZS5zdHVkZW50UGFydGljaXBhdGlvbnMgJiYgZXhlcmNpc2Uuc3R1ZGVudFBhcnRpY2lwYXRpb25zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiBleGVyY2lzZS5zdHVkZW50UGFydGljaXBhdGlvbnNbMF07XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBnZXRFeGVyY2lzZUJ1dHRvblRvb2x0aXAoZXhlcmNpc2U6IEV4ZXJjaXNlKTogQnV0dG9uVG9vbHRpcFR5cGUge1xuICAgICAgICBjb25zdCBzdWJtaXNzaW9uID0gRXhhbVBhcnRpY2lwYXRpb25TZXJ2aWNlLmdldFN1Ym1pc3Npb25Gb3JFeGVyY2lzZShleGVyY2lzZSk7XG4gICAgICAgIC8vIFRoZSBzdWJtaXNzaW9uIG1pZ2h0IG5vdCB5ZXQgZXhpc3QgZm9yIHRoaXMgZXhlcmNpc2UuXG4gICAgICAgIC8vIFdoZW4gdGhlIHBhcnRpY2lwYW50IG5hdmlnYXRlcyB0byB0aGUgZXhlcmNpc2UgdGhlIHN1Ym1pc3Npb25zIGFyZSBjcmVhdGVkLlxuICAgICAgICAvLyBVbnRpbCB0aGVuIHNob3csIHRoYXQgdGhlIGV4ZXJjaXNlIGlzIHN5bmNlZFxuICAgICAgICBpZiAoIXN1Ym1pc3Npb24pIHtcbiAgICAgICAgICAgIHJldHVybiAnc3luY2VkJztcbiAgICAgICAgfVxuICAgICAgICBpZiAoZXhlcmNpc2UudHlwZSAhPT0gRXhlcmNpc2VUeXBlLlBST0dSQU1NSU5HKSB7XG4gICAgICAgICAgICByZXR1cm4gc3VibWlzc2lvbi5pc1N5bmNlZCA/ICdzeW5jZWQnIDogJ25vdFN5bmNlZCc7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN1Ym1pc3Npb24uc3VibWl0dGVkICYmIHN1Ym1pc3Npb24uaXNTeW5jZWQpIHtcbiAgICAgICAgICAgIHJldHVybiAnc3VibWl0dGVkJzsgLy8gWW91IGhhdmUgc3VibWl0dGVkIGFuIGV4ZXJjaXNlLiBZb3UgY2FuIHN1Ym1pdCBhZ2FpblxuICAgICAgICB9IGVsc2UgaWYgKCFzdWJtaXNzaW9uLnN1Ym1pdHRlZCAmJiBzdWJtaXNzaW9uLmlzU3luY2VkKSB7XG4gICAgICAgICAgICByZXR1cm4gJ25vdFN1Ym1pdHRlZCc7IC8vIHN0YXJ0aW5nIHBvaW50XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gJ25vdFNhdmVkT3JTdWJtaXR0ZWQnO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHVibGljIGdldEV4YW1FeGVyY2lzZUlkcygpOiBudW1iZXJbXSB7XG4gICAgICAgIHJldHVybiB0aGlzLmV4YW1FeGVyY2lzZUlkcztcbiAgICB9XG5cbiAgICBwdWJsaWMgc2V0RXhhbUV4ZXJjaXNlSWRzKGV4YW1FeGVyY2lzZUlkczogbnVtYmVyW10pIHtcbiAgICAgICAgdGhpcy5leGFtRXhlcmNpc2VJZHMgPSBleGFtRXhlcmNpc2VJZHM7XG4gICAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBcUIsU0FBUyxJQUFJLGtCQUFrQjtBQUVwRCxTQUFTLFlBQStCLGtCQUFnQztBQUN4RSxTQUFTLHFCQUFxQiw2QkFBNkI7QUFFM0QsU0FBUyxZQUFZLEtBQUssV0FBVztBQUdyQyxPQUFPLFdBQVc7QUFFbEIsU0FBUyxpQkFBaUI7QUFJMUIsU0FBUyx3QkFBd0I7Ozs7QUFmakMsSUFxQmE7QUFyQmI7O0FBT0E7QUFHQTtBQUVBO0FBU00sSUFBTywyQkFBUCxNQUFPLDBCQUF3QjtNQVVyQjtNQUNBO01BQ0E7TUFYTCw2QkFBNkIsSUFBSSxRQUFPO01BRXZDO01BRUQsZUFBZSxVQUFrQixRQUFjO0FBQ2xELGVBQU8sZUFBZSxRQUFRLFVBQVUsTUFBTTtNQUNsRDtNQUVBLFlBQ1ksWUFDQSxxQkFDQSxnQkFBcUM7QUFGckMsYUFBQSxhQUFBO0FBQ0EsYUFBQSxzQkFBQTtBQUNBLGFBQUEsaUJBQUE7TUFDVDtNQUVLLE9BQU8saUNBQWlDLFVBQWtCLFFBQWM7QUFDNUUsY0FBTSxTQUFTO0FBQ2YsZUFBTyxHQUFHLE1BQU0sSUFBSSxRQUFRLElBQUksTUFBTTtNQUMxQztNQVNPLDBDQUEwQyxVQUFrQixRQUFnQixlQUFxQjtBQUNwRyxjQUFNLE1BQU0sS0FBSyxlQUFlLFVBQVUsTUFBTSxJQUFJLG9CQUFvQixnQkFBZ0I7QUFDeEYsZUFBTyxLQUFLLHlCQUF5QixLQUFLLFVBQVUsTUFBTTtNQUM5RDtNQVFPLDBEQUEwRCxVQUFrQixRQUFjO0FBQzdGLGNBQU0sa0JBQStCLEtBQUssTUFBTSxLQUFLLG9CQUFvQixTQUFTLDBCQUF5QixpQ0FBaUMsVUFBVSxNQUFNLENBQUMsQ0FBQztBQUM5SixlQUFPLEdBQUcsZUFBZTtNQUM3QjtNQVNPLHVDQUF1QyxVQUFrQixRQUFnQixlQUFxQjtBQUNqRyxjQUFNLE1BQU0sS0FBSyxlQUFlLFVBQVUsTUFBTSxJQUFJLG9CQUFvQixnQkFBZ0I7QUFDeEYsZUFBTyxLQUFLLHlCQUF5QixLQUFLLFVBQVUsTUFBTTtNQUM5RDtNQUtRLHlCQUF5QixLQUFhLFVBQWtCLFFBQWM7QUFDMUUsZUFBTyxLQUFLLFdBQVcsSUFBaUIsR0FBRyxFQUFFLEtBQ3pDLElBQUksQ0FBQyxnQkFBNEI7QUFDN0IsY0FBSSxZQUFZLGdCQUFnQixZQUFZLGFBQWEsU0FBUyxLQUFLLFlBQVksYUFBYSxDQUFDLEVBQUUsY0FBYztBQUM3RyxpQkFBSyxxQ0FBcUMsWUFBWSxhQUFhLENBQUMsRUFBRSxZQUFZOztBQUV0RixpQkFBTywwQkFBeUIsNkJBQTZCLFdBQVc7UUFDNUUsQ0FBQyxHQUNELElBQUksQ0FBQyxnQkFBNEI7QUFDN0IsZUFBSywyQkFBMkIsS0FBSyxXQUFXO1FBQ3BELENBQUMsR0FDRCxXQUFXLE1BQUs7QUFDWixnQkFBTSxrQkFBK0IsS0FBSyxNQUFNLEtBQUssb0JBQW9CLFNBQVMsMEJBQXlCLGlDQUFpQyxVQUFVLE1BQU0sQ0FBQyxDQUFDO0FBQzlKLGlCQUFPLEdBQUcsZUFBZTtRQUM3QixDQUFDLENBQUM7TUFFVjtNQVdPLG1DQUFtQyxVQUFrQixRQUFnQixRQUFpQixXQUFtQjtBQUM1RyxZQUFJLFNBQVMsSUFBSSxXQUFVO0FBQzNCLFlBQUksUUFBUTtBQUNSLG1CQUFTLE9BQU8sSUFBSSxVQUFVLE9BQU8sU0FBUSxDQUFFOztBQUVuRCxpQkFBUyxPQUFPLE9BQU8sYUFBYSxDQUFDLENBQUMsU0FBUztBQUUvQyxjQUFNLE1BQU0sS0FBSyxlQUFlLFVBQVUsTUFBTSxJQUFJO0FBQ3BELGVBQU8sS0FBSyxXQUFXLElBQTZCLEtBQUssRUFBRSxPQUFNLENBQUU7TUFDdkU7TUFPTyxrQkFBa0IsVUFBa0IsUUFBYztBQUNyRCxjQUFNLE1BQU0sS0FBSyxlQUFlLFVBQVUsTUFBTSxJQUFJO0FBQ3BELGVBQU8sS0FBSyxXQUFXLElBQWlCLEdBQUcsRUFBRSxLQUN6QyxJQUFJLENBQUMsZ0JBQTRCO0FBQzdCLGdCQUFNLHVCQUF1QiwwQkFBeUIsaUNBQWlDLFdBQVc7QUFDbEcsZUFBSywyQkFBMkIsS0FBSyxvQkFBb0I7QUFDekQsaUJBQU87UUFDWCxDQUFDLENBQUM7TUFFVjtNQUVPLHNDQUFzQyxVQUFrQixRQUFnQixXQUFpQjtBQUM1RixjQUFNLE1BQU0sS0FBSyxlQUFlLFVBQVUsTUFBTSxJQUFJLGVBQWUsWUFBWTtBQUMvRSxlQUFPLEtBQUssV0FBVyxJQUFpQixHQUFHLEVBQUUsS0FDekMsSUFBSSxDQUFDLGdCQUE0QjtBQUM3QixnQkFBTSx1QkFBdUIsMEJBQXlCLGlDQUFpQyxXQUFXO0FBQ2xHLGVBQUssMkJBQTJCLEtBQUssb0JBQW9CO0FBQ3pELGlCQUFPO1FBQ1gsQ0FBQyxDQUFDO01BRVY7TUFPTywrREFBK0QsVUFBZ0I7QUFDbEYsY0FBTSxNQUFNLGVBQWUsUUFBUTtBQUNuQyxlQUFPLEtBQUssV0FDUCxJQUFtQixLQUFLLEVBQUUsU0FBUyxXQUFVLENBQUUsRUFDL0MsS0FBSyxJQUFJLENBQUMsZ0JBQTZDLEtBQUssb0NBQW9DLFdBQVcsQ0FBQyxDQUFDO01BQ3RIO01BRVEsb0NBQW9DLHNCQUFpRDtBQUN6Riw2QkFBcUIsS0FBTSxRQUFRLENBQUMsZ0JBQWU7QUFDL0MsaUJBQU8sMEJBQXlCLGlDQUFpQyxXQUFXO1FBQ2hGLENBQUM7QUFDRCxlQUFPLHFCQUFxQjtNQUNoQztNQVFPLGtCQUFrQixVQUFrQixRQUFnQixhQUF3QjtBQUMvRSxjQUFNLE1BQU0sS0FBSyxlQUFlLFVBQVUsTUFBTSxJQUFJO0FBQ3BELGNBQU0sa0JBQWtCLFVBQVUsV0FBVztBQUM3QyxrQ0FBeUIsd0JBQXdCLGVBQWU7QUFFaEUsZUFBTyxLQUFLLFdBQVcsS0FBVyxLQUFLLGVBQWUsRUFBRSxLQUNwRCxXQUFXLENBQUMsVUFBNEI7QUFDcEMsY0FBSSxNQUFNLFdBQVcsT0FBTyxNQUFNLFFBQVEsSUFBSSxjQUFjLE1BQU0sNkJBQTZCO0FBQzNGLG1CQUFPLFdBQVcsTUFBTSxJQUFJLE1BQU0sNENBQTRDLENBQUM7cUJBQ3hFLE1BQU0sV0FBVyxPQUFPLE1BQU0sUUFBUSxJQUFJLGNBQWMsTUFBTSwwQkFBMEI7QUFDL0YsbUJBQU8sV0FBVyxNQUFNLElBQUksTUFBTSx5Q0FBeUMsQ0FBQztpQkFDekU7QUFDSCxtQkFBTyxXQUFXLE1BQU0sSUFBSSxNQUFNLHFDQUFxQyxDQUFDOztRQUVoRixDQUFDLENBQUM7TUFFVjtNQUVRLE9BQU8sd0JBQXdCLGFBQXdCO0FBQzNELG9CQUFZLFVBQVcsUUFBUSxDQUFDLGFBQVk7QUFDeEMsY0FBSSxTQUFTLHVCQUF1QjtBQUNoQyx1QkFBVyxpQkFBaUIsU0FBUyx1QkFBdUI7QUFDeEQsa0JBQUksY0FBYyxTQUFTO0FBQ3ZCLDJCQUFXLFVBQVUsY0FBYyxTQUFTO0FBQ3hDLHlCQUFPLE9BQU87QUFDZCxzQkFBSSxPQUFPLFdBQVc7QUFDbEIsK0JBQVcsWUFBWSxPQUFPLFdBQVc7QUFDckMsNkJBQU8sU0FBUzs7Ozs7QUFLaEMsa0JBQUksY0FBYyxhQUFhO0FBQzNCLDJCQUFXLGNBQWMsY0FBYyxhQUFhO0FBQ2hELHlCQUFPLFdBQVc7QUFDbEIsd0JBQU0sU0FBUywwQkFBMEIsVUFBVTtBQUNuRCxzQkFBSSxRQUFRO0FBQ1IsMkJBQU8sT0FBTztBQUNkLDJCQUFPLE9BQU87Ozs7QUFJMUIscUJBQU8sY0FBYzs7O1FBR2pDLENBQUM7TUFDTDtNQVNPLDhCQUE4QixVQUFrQixRQUFnQixhQUF3QjtBQUUzRixZQUFJO0FBQ0EsZ0JBQU0sa0JBQWtCLFVBQVUsV0FBVztBQUM3QyxvQ0FBeUIsd0JBQXdCLGVBQWU7QUFDaEUsZUFBSyxvQkFBb0IsTUFBTSwwQkFBeUIsaUNBQWlDLFVBQVUsTUFBTSxHQUFHLEtBQUssVUFBVSxlQUFlLENBQUM7aUJBQ3RJLE9BQU87QUFDWiwyQkFBaUIsS0FBSzs7TUFFOUI7TUFNTyxxQ0FBcUMsa0JBQXdCO0FBQ2hFLGFBQUssZUFBZSxNQUFNLG9CQUFvQixnQkFBZ0I7TUFDbEU7TUFRTyxxQkFBcUIsWUFBb0IsZ0JBQThCO0FBQzFFLGNBQU0sTUFBTSxpQkFBaUIsVUFBVTtBQUN2QyxlQUFPLEtBQUssV0FBVyxJQUFvQixLQUFLLGNBQWM7TUFDbEU7TUFFTyxrQkFBa0IsWUFBcUIsVUFBa0IsUUFBYztBQUMxRSxjQUFNLE1BQU0sMEJBQXlCLGlDQUFpQyxVQUFVLE1BQU0sSUFBSTtBQUMxRixhQUFLLG9CQUFvQixNQUFNLEtBQUssVUFBVTtNQUNsRDtNQUVPLGVBQWUsVUFBa0IsUUFBYztBQUNsRCxjQUFNLE1BQU0sMEJBQXlCLGlDQUFpQyxVQUFVLE1BQU0sSUFBSTtBQUMxRixlQUFPLEtBQUssb0JBQW9CLFNBQVMsR0FBRztNQUNoRDtNQUVRLE9BQU8sNkJBQTZCLGFBQXdCO0FBQ2hFLG9CQUFZLFlBQVksZ0JBQWdCLCtCQUErQixZQUFZLFNBQVM7QUFDNUYsb0JBQVksT0FBTywwQkFBeUIsMEJBQTBCLFlBQVksSUFBSTtBQUV0RixvQkFBWSxZQUFZLFlBQVksVUFBVSxJQUFJLENBQUMsYUFBc0I7QUFDckUsbUJBQVMsZ0JBQWdCLGlDQUFLLFNBQVMsZ0JBQWQsRUFBOEIsTUFBTSxZQUFZLEtBQUk7QUFDN0UsaUJBQU87UUFDWCxDQUFDO0FBQ0QsZUFBTztNQUNYO01BRVEsT0FBTywwQkFBMEIsTUFBVztBQUNoRCxZQUFJLE1BQU07QUFDTixlQUFLLGNBQWMsS0FBSyxjQUFjLE1BQU0sS0FBSyxXQUFXLElBQUk7QUFDaEUsZUFBSyxZQUFZLEtBQUssWUFBWSxNQUFNLEtBQUssU0FBUyxJQUFJO0FBQzFELGVBQUssVUFBVSxLQUFLLFVBQVUsTUFBTSxLQUFLLE9BQU8sSUFBSTtBQUNwRCxlQUFLLHFCQUFxQixLQUFLLHFCQUFxQixNQUFNLEtBQUssa0JBQWtCLElBQUk7QUFDckYsZUFBSyx5QkFBeUIsS0FBSyx5QkFBeUIsTUFBTSxLQUFLLHNCQUFzQixJQUFJO0FBQ2pHLGVBQUssdUJBQXVCLEtBQUssdUJBQXVCLE1BQU0sS0FBSyxvQkFBb0IsSUFBSTs7QUFFL0YsZUFBTztNQUNYO01BRVEsT0FBTyxpQ0FBaUMsYUFBd0I7QUFDcEUsb0JBQVksT0FBTywwQkFBeUIsMEJBQTBCLFlBQVksSUFBSTtBQUN0RixvQkFBWSxpQkFBaUIsWUFBWSxrQkFBa0IsTUFBTSxZQUFZLGNBQWM7QUFDM0Ysb0JBQVksY0FBYyxZQUFZLGVBQWUsTUFBTSxZQUFZLFdBQVc7QUFDbEYsZUFBTztNQUNYO01BRU8sT0FBTyx5QkFBeUIsVUFBa0I7QUFDckQsY0FBTSx1QkFBdUIsMEJBQXlCLDRCQUE0QixRQUFRO0FBQzFGLFlBQUksd0JBQXdCLHFCQUFxQixhQUFhO0FBRTFELGlCQUFPLHFCQUFxQixZQUFZLEtBQUk7O01BRXBEO01BT08sT0FBTyw0QkFBNEIsVUFBa0I7QUFDeEQsWUFBSSxZQUFZLFNBQVMseUJBQXlCLFNBQVMsc0JBQXNCLFNBQVMsR0FBRztBQUN6RixpQkFBTyxTQUFTLHNCQUFzQixDQUFDOztNQUUvQztNQUVBLHlCQUF5QixVQUFrQjtBQUN2QyxjQUFNLGFBQWEsMEJBQXlCLHlCQUF5QixRQUFRO0FBSTdFLFlBQUksQ0FBQyxZQUFZO0FBQ2IsaUJBQU87O0FBRVgsWUFBSSxTQUFTLFNBQVMsYUFBYSxhQUFhO0FBQzVDLGlCQUFPLFdBQVcsV0FBVyxXQUFXOztBQUU1QyxZQUFJLFdBQVcsYUFBYSxXQUFXLFVBQVU7QUFDN0MsaUJBQU87bUJBQ0EsQ0FBQyxXQUFXLGFBQWEsV0FBVyxVQUFVO0FBQ3JELGlCQUFPO2VBQ0o7QUFDSCxpQkFBTzs7TUFFZjtNQUVPLHFCQUFrQjtBQUNyQixlQUFPLEtBQUs7TUFDaEI7TUFFTyxtQkFBbUIsaUJBQXlCO0FBQy9DLGFBQUssa0JBQWtCO01BQzNCOzt5QkE5VFMsMkJBQXdCLHNCQUFBLGFBQUEsR0FBQSxzQkFBQSxzQkFBQSxHQUFBLHNCQUFBLHdCQUFBLENBQUE7TUFBQTttRUFBeEIsMkJBQXdCLFNBQXhCLDBCQUF3QixXQUFBLFlBRFgsT0FBTSxDQUFBOzs7OyIsIm5hbWVzIjpbXX0=