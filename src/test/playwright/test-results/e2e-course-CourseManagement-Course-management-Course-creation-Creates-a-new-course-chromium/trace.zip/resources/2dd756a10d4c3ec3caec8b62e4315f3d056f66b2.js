import {
  init_crypto_utils,
  sha1Hex
} from "/chunk-SE7ZOI4O.js";
import {
  JhiLanguageHelper,
  init_language_helper
} from "/chunk-TAMMSE46.js";
import {
  ArtemisServerDateService,
  init_server_date_service
} from "/chunk-ORYTP7RT.js";
import {
  ARTEMIS_VERSION_HEADER,
  VERSION,
  init_app_constants
} from "/chunk-FM4KGV2V.js";
import {
  StateStorageService,
  init_state_storage_service
} from "/chunk-KQ77WIWP.js";
import {
  AccountService,
  AlertService,
  AlertType,
  BrowserFingerprintService,
  EventManager,
  __async,
  __esm,
  __spreadProps,
  __spreadValues,
  init_account_service,
  init_alert_service,
  init_browser_fingerprint_service,
  init_event_manager_service,
  init_translation_config,
  missingTranslationHandler,
  translatePartialLoader
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/core/auth/auth-jwt.service.ts
import { Injectable } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpClient } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { of } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { LocalStorageService, SessionStorageService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import * as i0 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i1 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import * as i2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
var AuthServerProvider;
var init_auth_jwt_service = __esm({
  "src/main/webapp/app/core/auth/auth-jwt.service.ts"() {
    AuthServerProvider = class _AuthServerProvider {
      http;
      localStorage;
      sessionStorage;
      constructor(http, localStorage, sessionStorage) {
        this.http = http;
        this.localStorage = localStorage;
        this.sessionStorage = sessionStorage;
      }
      login(credentials) {
        return this.http.post("api/public/authenticate", credentials);
      }
      loginSAML2(rememberMe) {
        return this.http.post("api/public/saml2", rememberMe.toString());
      }
      logout() {
        return this.http.post("api/public/logout", null);
      }
      clearCaches() {
        this.localStorage.clear();
        this.sessionStorage.clear();
        return of(void 0);
      }
      static \u0275fac = function AuthServerProvider_Factory(t) {
        return new (t || _AuthServerProvider)(i0.\u0275\u0275inject(i1.HttpClient), i0.\u0275\u0275inject(i2.LocalStorageService), i0.\u0275\u0275inject(i2.SessionStorageService));
      };
      static \u0275prov = i0.\u0275\u0275defineInjectable({ token: _AuthServerProvider, factory: _AuthServerProvider.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/core/login/login.service.ts
import { Injectable as Injectable2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Router } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import { finalize } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i02 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
var LoginService;
var init_login_service = __esm({
  "src/main/webapp/app/core/login/login.service.ts"() {
    init_alert_service();
    init_auth_jwt_service();
    init_account_service();
    init_account_service();
    init_auth_jwt_service();
    init_alert_service();
    LoginService = class _LoginService {
      accountService;
      authServerProvider;
      router;
      alertService;
      logoutWasForceful = false;
      constructor(accountService, authServerProvider, router, alertService) {
        this.accountService = accountService;
        this.authServerProvider = authServerProvider;
        this.router = router;
        this.alertService = alertService;
      }
      login(credentials) {
        return new Promise((resolve, reject) => {
          this.authServerProvider.login(credentials).subscribe({
            next: () => {
              this.accountService.identity(true).then(() => {
                resolve();
              });
            },
            error: (err) => {
              this.logout(false);
              reject(err);
            }
          });
        });
      }
      loginSAML2(rememberMe) {
        return new Promise((resolve, reject) => {
          this.authServerProvider.loginSAML2(rememberMe).subscribe({
            next: () => {
              this.accountService.identity(true).then(() => {
                resolve();
              });
            },
            error: (err) => {
              this.logout(false);
              reject(err);
            }
          });
        });
      }
      logout(wasInitiatedByUser) {
        this.logoutWasForceful = !wasInitiatedByUser;
        if (wasInitiatedByUser) {
          this.authServerProvider.logout().pipe(finalize(() => {
            this.onLogout();
          })).subscribe();
        } else {
          this.onLogout();
        }
      }
      onLogout() {
        this.accountService.authenticate(void 0);
        this.alertService.closeAll();
        this.router.navigateByUrl("/");
      }
      lastLogoutWasForceful() {
        return this.logoutWasForceful;
      }
      static \u0275fac = function LoginService_Factory(t) {
        return new (t || _LoginService)(i02.\u0275\u0275inject(AccountService), i02.\u0275\u0275inject(AuthServerProvider), i02.\u0275\u0275inject(i3.Router), i02.\u0275\u0275inject(AlertService));
      };
      static \u0275prov = i02.\u0275\u0275defineInjectable({ token: _LoginService, factory: _LoginService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/core/interceptor/auth-expired.interceptor.ts
import { Injectable as Injectable3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpErrorResponse } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { tap } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { Router as Router3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i03 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i32 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
var AuthExpiredInterceptor;
var init_auth_expired_interceptor = __esm({
  "src/main/webapp/app/core/interceptor/auth-expired.interceptor.ts"() {
    init_login_service();
    init_state_storage_service();
    init_account_service();
    init_login_service();
    init_state_storage_service();
    init_account_service();
    AuthExpiredInterceptor = class _AuthExpiredInterceptor {
      loginService;
      stateStorageService;
      router;
      accountService;
      constructor(loginService, stateStorageService, router, accountService) {
        this.loginService = loginService;
        this.stateStorageService = stateStorageService;
        this.router = router;
        this.accountService = accountService;
      }
      intercept(request, next) {
        return next.handle(request).pipe(tap({
          error: (err) => {
            if (err instanceof HttpErrorResponse) {
              if (err.status === 401 && this.accountService.isAuthenticated()) {
                const currentUrl = this.router.routerState.snapshot.url;
                this.loginService.logout(false);
                this.stateStorageService.storeUrl(currentUrl);
              }
            }
          }
        }));
      }
      static \u0275fac = function AuthExpiredInterceptor_Factory(t) {
        return new (t || _AuthExpiredInterceptor)(i03.\u0275\u0275inject(LoginService), i03.\u0275\u0275inject(StateStorageService), i03.\u0275\u0275inject(i32.Router), i03.\u0275\u0275inject(AccountService));
      };
      static \u0275prov = i03.\u0275\u0275defineInjectable({ token: _AuthExpiredInterceptor, factory: _AuthExpiredInterceptor.\u0275fac });
    };
  }
});

// src/main/webapp/app/core/interceptor/errorhandler.interceptor.ts
import { Injectable as Injectable4 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpErrorResponse as HttpErrorResponse2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { tap as tap2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i04 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var ErrorHandlerInterceptor;
var init_errorhandler_interceptor = __esm({
  "src/main/webapp/app/core/interceptor/errorhandler.interceptor.ts"() {
    init_event_manager_service();
    init_account_service();
    init_event_manager_service();
    init_account_service();
    ErrorHandlerInterceptor = class _ErrorHandlerInterceptor {
      eventManager;
      accountService;
      constructor(eventManager, accountService) {
        this.eventManager = eventManager;
        this.accountService = accountService;
      }
      intercept(request, next) {
        return next.handle(request).pipe(tap2({
          error: (err) => {
            if (err instanceof HttpErrorResponse2) {
              if (!(err.status === 401 && !this.accountService.isAuthenticated())) {
                this.eventManager.broadcast({ name: "artemisApp.httpError", content: err });
              }
            }
          }
        }));
      }
      static \u0275fac = function ErrorHandlerInterceptor_Factory(t) {
        return new (t || _ErrorHandlerInterceptor)(i04.\u0275\u0275inject(EventManager), i04.\u0275\u0275inject(AccountService));
      };
      static \u0275prov = i04.\u0275\u0275defineInjectable({ token: _ErrorHandlerInterceptor, factory: _ErrorHandlerInterceptor.\u0275fac });
    };
  }
});

// src/main/webapp/app/core/interceptor/notification.interceptor.ts
import { HttpResponse } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { Injectable as Injectable5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { tap as tap3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i05 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var NotificationInterceptor;
var init_notification_interceptor = __esm({
  "src/main/webapp/app/core/interceptor/notification.interceptor.ts"() {
    init_alert_service();
    init_alert_service();
    NotificationInterceptor = class _NotificationInterceptor {
      alertService;
      constructor(alertService) {
        this.alertService = alertService;
      }
      intercept(request, next) {
        return next.handle(request).pipe(tap3((event) => {
          if (event instanceof HttpResponse) {
            let alert = null;
            let alertParams = null;
            event.headers.keys().forEach((entry) => {
              if (entry.toLowerCase().endsWith("app-alert")) {
                alert = event.headers.get(entry);
              } else if (entry.toLowerCase().endsWith("app-params")) {
                alertParams = decodeURIComponent(event.headers.get(entry).replace(/\+/g, " "));
              }
            });
            if (alert) {
              this.alertService.success(alert, { param: alertParams });
            }
          }
        }));
      }
      static \u0275fac = function NotificationInterceptor_Factory(t) {
        return new (t || _NotificationInterceptor)(i05.\u0275\u0275inject(AlertService));
      };
      static \u0275prov = i05.\u0275\u0275defineInjectable({ token: _NotificationInterceptor, factory: _NotificationInterceptor.\u0275fac });
    };
  }
});

// src/main/webapp/app/core/sentry/deduplicate.sentry-integration.ts
function computeEventHash(event) {
  let valueSequence = event.message ?? "";
  const exception = event.exception?.values?.[0];
  if (exception) {
    valueSequence += exception.type ?? "";
    valueSequence += exception.value ?? "";
  }
  const frames = exception?.stacktrace?.frames;
  if (frames) {
    frames.forEach((frame) => valueSequence += frame.filename ?? "");
    frames.forEach((frame) => valueSequence += frame.lineno ?? "");
  }
  return sha1Hex(valueSequence);
}
var ArtemisDeduplicate;
var init_deduplicate_sentry_integration = __esm({
  "src/main/webapp/app/core/sentry/deduplicate.sentry-integration.ts"() {
    init_crypto_utils();
    ArtemisDeduplicate = class _ArtemisDeduplicate {
      static id = "ArtemisDeduplicate";
      name = _ArtemisDeduplicate.id;
      observedEventHashes = [];
      setupOnce(addGlobalEventProcessor, getCurrentHub) {
        addGlobalEventProcessor((currentEvent) => {
          const self = getCurrentHub().getIntegration(_ArtemisDeduplicate);
          if (self) {
            try {
              const eventHash = computeEventHash(currentEvent);
              if (this.observedEventHashes.includes(eventHash)) {
                return null;
              } else {
                this.observedEventHashes.push(eventHash);
                setTimeout(() => {
                  const index = this.observedEventHashes.indexOf(eventHash);
                  if (index >= 0) {
                    this.observedEventHashes.splice(index, 1);
                  }
                }, 5 * 60 * 1e3);
              }
            } catch (e) {
              console.error(e);
            }
          }
          return currentEvent;
        });
      }
    };
  }
});

// src/main/webapp/app/core/sentry/sentry.error-handler.ts
import { ErrorHandler, Injectable as Injectable6 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { captureException, init, instrumentAngularRouting } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@sentry_angular-ivy.js?v=1d0d9ead";
import { BrowserTracing } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@sentry_tracing.js?v=1d0d9ead";
import * as i06 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var SentryErrorHandler;
var init_sentry_error_handler = __esm({
  "src/main/webapp/app/core/sentry/sentry.error-handler.ts"() {
    init_app_constants();
    init_deduplicate_sentry_integration();
    SentryErrorHandler = class _SentryErrorHandler extends ErrorHandler {
      environment;
      initSentry(profileInfo) {
        return __async(this, null, function* () {
          if (!profileInfo || !profileInfo.sentry) {
            return;
          }
          if (profileInfo.testServer != void 0) {
            if (profileInfo.testServer) {
              this.environment = "test";
            } else {
              this.environment = "prod";
            }
          } else {
            this.environment = "local";
          }
          init({
            dsn: profileInfo.sentry.dsn,
            release: VERSION,
            environment: this.environment,
            integrations: (integrations) => {
              integrations.push(new ArtemisDeduplicate());
              if (this.environment !== "local") {
                integrations.push(new BrowserTracing({
                  routingInstrumentation: instrumentAngularRouting,
                  beforeNavigate: (context) => {
                    return __spreadProps(__spreadValues({}, context), {
                      name: location.pathname.replace(/\/[a-f0-9]{32}/g, "/<hash>").replace(/\/\d+/g, "/<digits>")
                    });
                  }
                }));
              }
              return integrations;
            },
            tracesSampleRate: this.environment !== "prod" ? 1 : 0.2
          });
        });
      }
      constructor() {
        super();
      }
      handleError(error) {
        if (error && error.name === "HttpErrorResponse" && error.status < 500 && error.status >= 400) {
          super.handleError(error);
          return;
        }
        if (this.environment !== "local") {
          const exception = error.error || error.message || error.originalError || error;
          captureException(exception);
        }
        super.handleError(error);
      }
      static \u0275fac = function SentryErrorHandler_Factory(t) {
        return new (t || _SentryErrorHandler)();
      };
      static \u0275prov = i06.\u0275\u0275defineInjectable({ token: _SentryErrorHandler, factory: _SentryErrorHandler.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/shared/notification/loading-notification/loading-notification.service.ts
import { Injectable as Injectable7 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { Subject } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import * as i07 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var LoadingNotificationService;
var init_loading_notification_service = __esm({
  "src/main/webapp/app/shared/notification/loading-notification/loading-notification.service.ts"() {
    LoadingNotificationService = class _LoadingNotificationService {
      loadingStatus = new Subject();
      startLoading() {
        this.loadingStatus.next(true);
      }
      stopLoading() {
        this.loadingStatus.next(false);
      }
      static \u0275fac = function LoadingNotificationService_Factory(t) {
        return new (t || _LoadingNotificationService)();
      };
      static \u0275prov = i07.\u0275\u0275defineInjectable({ token: _LoadingNotificationService, factory: _LoadingNotificationService.\u0275fac, providedIn: "root" });
    };
  }
});

// src/main/webapp/app/shared/notification/loading-notification/loading-notification.interceptor.ts
import { Injectable as Injectable8 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { finalize as finalize2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import * as i08 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var LoadingNotificationInterceptor;
var init_loading_notification_interceptor = __esm({
  "src/main/webapp/app/shared/notification/loading-notification/loading-notification.interceptor.ts"() {
    init_loading_notification_service();
    init_loading_notification_service();
    LoadingNotificationInterceptor = class _LoadingNotificationInterceptor {
      loadingNotificationService;
      activeRequests = 0;
      constructor(loadingNotificationService) {
        this.loadingNotificationService = loadingNotificationService;
      }
      intercept(request, next) {
        if (this.activeRequests === 0) {
          this.loadingNotificationService.startLoading();
        }
        this.activeRequests++;
        return next.handle(request).pipe(finalize2(() => {
          this.activeRequests--;
          if (this.activeRequests === 0) {
            this.loadingNotificationService.stopLoading();
          }
        }));
      }
      static \u0275fac = function LoadingNotificationInterceptor_Factory(t) {
        return new (t || _LoadingNotificationInterceptor)(i08.\u0275\u0275inject(LoadingNotificationService));
      };
      static \u0275prov = i08.\u0275\u0275defineInjectable({ token: _LoadingNotificationInterceptor, factory: _LoadingNotificationInterceptor.\u0275fac });
    };
  }
});

// src/main/webapp/app/core/interceptor/interceptor.util.ts
var isRequestToArtemisServer;
var init_interceptor_util = __esm({
  "src/main/webapp/app/core/interceptor/interceptor.util.ts"() {
    isRequestToArtemisServer = (request) => !(!request || !request.url || /^http/.test(request.url));
  }
});

// src/main/webapp/app/core/interceptor/browser-fingerprint.interceptor.service.ts
import { Injectable as Injectable9 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i09 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var BrowserFingerprintInterceptor;
var init_browser_fingerprint_interceptor_service = __esm({
  "src/main/webapp/app/core/interceptor/browser-fingerprint.interceptor.service.ts"() {
    init_browser_fingerprint_service();
    init_interceptor_util();
    init_browser_fingerprint_service();
    BrowserFingerprintInterceptor = class _BrowserFingerprintInterceptor {
      browserFingerprintService;
      fingerprint;
      instanceIdentifier;
      constructor(browserFingerprintService) {
        this.browserFingerprintService = browserFingerprintService;
        browserFingerprintService.fingerprint.subscribe((fingerprint) => this.fingerprint = fingerprint);
        browserFingerprintService.instanceIdentifier.subscribe((instanceIdentifier) => this.instanceIdentifier = instanceIdentifier);
      }
      intercept(request, next) {
        if (isRequestToArtemisServer(request) && (this.instanceIdentifier || this.fingerprint)) {
          request = request.clone({
            setHeaders: {
              "X-Artemis-Client-Instance-ID": this.instanceIdentifier ?? "",
              "X-Artemis-Client-Fingerprint": this.fingerprint ?? ""
            }
          });
        }
        return next.handle(request);
      }
      static \u0275fac = function BrowserFingerprintInterceptor_Factory(t) {
        return new (t || _BrowserFingerprintInterceptor)(i09.\u0275\u0275inject(BrowserFingerprintService));
      };
      static \u0275prov = i09.\u0275\u0275defineInjectable({ token: _BrowserFingerprintInterceptor, factory: _BrowserFingerprintInterceptor.\u0275fac });
    };
  }
});

// src/main/webapp/app/core/interceptor/artemis-version.interceptor.ts
import { ApplicationRef, Inject, Injectable as Injectable10, InjectionToken } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { HttpResponse as HttpResponse2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { concat, interval, of as of2 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs.js?v=1d0d9ead";
import { catchError, first, tap as tap4, timeout } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/rxjs_operators.js?v=1d0d9ead";
import { SwUpdate } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_service-worker.js?v=1d0d9ead";
import * as i010 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i12 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_service-worker.js?v=1d0d9ead";
var WINDOW_INJECTOR_TOKEN, ArtemisVersionInterceptor;
var init_artemis_version_interceptor = __esm({
  "src/main/webapp/app/core/interceptor/artemis-version.interceptor.ts"() {
    init_app_constants();
    init_server_date_service();
    init_alert_service();
    init_server_date_service();
    init_alert_service();
    WINDOW_INJECTOR_TOKEN = new InjectionToken("Window");
    ArtemisVersionInterceptor = class _ArtemisVersionInterceptor {
      appRef;
      updates;
      serverDateService;
      alertService;
      injectedWindow;
      alert;
      hasSeenOutdatedInThisSession = false;
      constructor(appRef, updates, serverDateService, alertService, injectedWindow) {
        this.appRef = appRef;
        this.updates = updates;
        this.serverDateService = serverDateService;
        this.alertService = alertService;
        this.injectedWindow = injectedWindow;
        const appIsStableOrTimeout = appRef.isStable.pipe(first((isStable) => isStable === true), timeout(3e4), catchError(() => of2(true)));
        const updateInterval = interval(60 * 1e3);
        const updateIntervalOnceAppIsStable$ = concat(appIsStableOrTimeout, updateInterval);
        updateIntervalOnceAppIsStable$.subscribe(() => this.checkForUpdates(false));
      }
      intercept(request, nextHandler) {
        return nextHandler.handle(request).pipe(tap4((response) => {
          if (response instanceof HttpResponse2) {
            const isTranslationStringsRequest = response.url?.includes("/i18n/");
            const serverVersion = response.headers.get(ARTEMIS_VERSION_HEADER);
            if (VERSION && serverVersion && VERSION !== serverVersion && !isTranslationStringsRequest) {
              this.checkForUpdates(true);
            }
            if (!request.url.includes("time")) {
              this.serverDateService.updateTime();
            }
          }
        }));
      }
      checkForUpdates(hasUpdate) {
        const update = this.updates.isEnabled ? this.updates.checkForUpdate() : Promise.resolve(hasUpdate);
        update.then((updateAvailable) => {
          if (this.hasSeenOutdatedInThisSession || updateAvailable) {
            this.hasSeenOutdatedInThisSession = true;
            if (!this.alert?.isOpen) {
              this.alert = this.alertService.addAlert({
                type: AlertType.INFO,
                message: "artemisApp.outdatedAlert",
                timeout: 0,
                action: {
                  label: "artemisApp.outdatedAction",
                  callback: () => this.updates.activateUpdate().catch(() => {
                  }).then(() => this.injectedWindow.location.reload())
                }
              });
            }
          }
        });
      }
      static \u0275fac = function ArtemisVersionInterceptor_Factory(t) {
        return new (t || _ArtemisVersionInterceptor)(i010.\u0275\u0275inject(i010.ApplicationRef), i010.\u0275\u0275inject(i12.SwUpdate), i010.\u0275\u0275inject(ArtemisServerDateService), i010.\u0275\u0275inject(AlertService), i010.\u0275\u0275inject(WINDOW_INJECTOR_TOKEN));
      };
      static \u0275prov = i010.\u0275\u0275defineInjectable({ token: _ArtemisVersionInterceptor, factory: _ArtemisVersionInterceptor.\u0275fac });
    };
  }
});

// src/main/webapp/app/core/config/dayjs.ts
import dayjs from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import customParseFormat from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_customParseFormat.js?v=1d0d9ead";
import duration from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_duration.js?v=1d0d9ead";
import relativeTime from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_relativeTime.js?v=1d0d9ead";
import isoWeek from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_isoWeek.js?v=1d0d9ead";
import utc from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_utc.js?v=1d0d9ead";
import isSameOrBefore from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_isSameOrBefore.js?v=1d0d9ead";
import isSameOrAfter from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_isSameOrAfter.js?v=1d0d9ead";
import isBetween from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_isBetween.js?v=1d0d9ead";
import minMax from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_minMax.js?v=1d0d9ead";
import localizedFormat from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_localizedFormat.js?v=1d0d9ead";
import isoWeeksInYear from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_isoWeeksInYear.js?v=1d0d9ead";
import isLeapYear from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_isLeapYear.js?v=1d0d9ead";
import timezone from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_plugin_timezone.js?v=1d0d9ead";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_locale_en.js?v=1d0d9ead";
import "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm_locale_de.js?v=1d0d9ead";
var init_dayjs = __esm({
  "src/main/webapp/app/core/config/dayjs.ts"() {
    dayjs.extend(customParseFormat);
    dayjs.extend(duration);
    dayjs.extend(relativeTime);
    dayjs.extend(isoWeek);
    dayjs.extend(utc);
    dayjs.extend(isSameOrBefore);
    dayjs.extend(isSameOrAfter);
    dayjs.extend(isBetween);
    dayjs.extend(minMax);
    dayjs.extend(localizedFormat);
    dayjs.extend(isoWeeksInYear);
    dayjs.extend(isLeapYear);
    dayjs.extend(timezone);
  }
});

// src/main/webapp/app/core/config/datepicker-adapter.ts
import { Injectable as Injectable11 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { NgbDateAdapter } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import dayjs2 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import * as i011 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
var NgbDateDayjsAdapter;
var init_datepicker_adapter = __esm({
  "src/main/webapp/app/core/config/datepicker-adapter.ts"() {
    NgbDateDayjsAdapter = class _NgbDateDayjsAdapter extends NgbDateAdapter {
      fromModel(date) {
        if (date && dayjs2.isDayjs(date) && date.isValid()) {
          return { year: date.year(), month: date.month() + 1, day: date.date() };
        }
        return null;
      }
      toModel(date) {
        return date ? dayjs2(`${date.year}-${date.month}-${date.day}`) : null;
      }
      static \u0275fac = (() => {
        let \u0275NgbDateDayjsAdapter_BaseFactory;
        return function NgbDateDayjsAdapter_Factory(t) {
          return (\u0275NgbDateDayjsAdapter_BaseFactory || (\u0275NgbDateDayjsAdapter_BaseFactory = i011.\u0275\u0275getInheritedFactory(_NgbDateDayjsAdapter)))(t || _NgbDateDayjsAdapter);
        };
      })();
      static \u0275prov = i011.\u0275\u0275defineInjectable({ token: _NgbDateDayjsAdapter, factory: _NgbDateDayjsAdapter.\u0275fac });
    };
  }
});

// src/main/webapp/app/core/core.module.ts
import { APP_INITIALIZER, ErrorHandler as ErrorHandler2, LOCALE_ID, NgModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import { DatePipe, registerLocaleData } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common.js?v=1d0d9ead";
import { HTTP_INTERCEPTORS, HttpClient as HttpClient3, HttpClientModule } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_http.js?v=1d0d9ead";
import { Title } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_platform-browser.js?v=1d0d9ead";
import { NgbDateAdapter as NgbDateAdapter2, NgbDatepickerConfig, NgbTooltipConfig } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import { NgxWebstorageModule, SessionStorageService as SessionStorageService3 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
import locale from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_common_locales_en.js?v=1d0d9ead";
import { MissingTranslationHandler, TranslateLoader, TranslateModule, TranslateService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import dayjs3 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/dayjs_esm.js?v=1d0d9ead";
import { TraceService } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@sentry_angular-ivy.js?v=1d0d9ead";
import { Router as Router5 } from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_router.js?v=1d0d9ead";
import * as i012 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@angular_core.js?v=1d0d9ead";
import * as i13 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ng-bootstrap_ng-bootstrap.js?v=1d0d9ead";
import * as i22 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/@ngx-translate_core.js?v=1d0d9ead";
import * as i4 from "/@fs/Users/muradium/Desktop/Murad/Projects/iOS/Artemis/.cache/17.0.9/vite/deps/ngx-webstorage.js?v=1d0d9ead";
var ArtemisCoreModule;
var init_core_module = __esm({
  "src/main/webapp/app/core/core.module.ts"() {
    init_auth_expired_interceptor();
    init_errorhandler_interceptor();
    init_notification_interceptor();
    init_sentry_error_handler();
    init_loading_notification_interceptor();
    init_browser_fingerprint_interceptor_service();
    init_artemis_version_interceptor();
    init_translation_config();
    init_dayjs();
    init_datepicker_adapter();
    init_language_helper();
    init_language_helper();
    ArtemisCoreModule = class _ArtemisCoreModule {
      constructor(dpConfig, tooltipConfig, translateService, languageHelper, sessionStorageService) {
        registerLocaleData(locale);
        dpConfig.minDate = { year: dayjs3().subtract(100, "year").year(), month: 1, day: 1 };
        translateService.setDefaultLang("en");
        const languageKey = sessionStorageService.retrieve("locale") || languageHelper.determinePreferredLanguage();
        translateService.use(languageKey);
        tooltipConfig.container = "body";
      }
      static \u0275fac = function ArtemisCoreModule_Factory(t) {
        return new (t || _ArtemisCoreModule)(i012.\u0275\u0275inject(i13.NgbDatepickerConfig), i012.\u0275\u0275inject(i13.NgbTooltipConfig), i012.\u0275\u0275inject(i22.TranslateService), i012.\u0275\u0275inject(JhiLanguageHelper), i012.\u0275\u0275inject(i4.SessionStorageService));
      };
      static \u0275mod = i012.\u0275\u0275defineNgModule({ type: _ArtemisCoreModule });
      static \u0275inj = i012.\u0275\u0275defineInjector({ providers: [
        Title,
        {
          provide: LOCALE_ID,
          useValue: "en"
        },
        { provide: NgbDateAdapter2, useClass: NgbDateDayjsAdapter },
        { provide: TraceService, deps: [Router5] },
        { provide: ErrorHandler2, useClass: SentryErrorHandler },
        { provide: WINDOW_INJECTOR_TOKEN, useValue: window },
        DatePipe,
        {
          provide: APP_INITIALIZER,
          useFactory: () => () => {
          },
          deps: [TraceService],
          multi: true
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: AuthExpiredInterceptor,
          multi: true
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: ErrorHandlerInterceptor,
          multi: true
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: BrowserFingerprintInterceptor,
          multi: true
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: NotificationInterceptor,
          multi: true
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: LoadingNotificationInterceptor,
          multi: true
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: ArtemisVersionInterceptor,
          multi: true
        }
      ], imports: [
        HttpClientModule,
        NgxWebstorageModule.forRoot({ prefix: "jhi", separator: "-" }),
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: translatePartialLoader,
            deps: [HttpClient3]
          },
          missingTranslationHandler: {
            provide: MissingTranslationHandler,
            useFactory: missingTranslationHandler
          }
        })
      ] });
    };
  }
});

export {
  LoginService,
  init_login_service,
  LoadingNotificationService,
  init_loading_notification_service,
  SentryErrorHandler,
  init_sentry_error_handler,
  ArtemisCoreModule,
  init_core_module
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvY29yZS9hdXRoL2F1dGgtand0LnNlcnZpY2UudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvcmUvbG9naW4vbG9naW4uc2VydmljZS50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvY29yZS9pbnRlcmNlcHRvci9hdXRoLWV4cGlyZWQuaW50ZXJjZXB0b3IudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvcmUvaW50ZXJjZXB0b3IvZXJyb3JoYW5kbGVyLmludGVyY2VwdG9yLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3JlL2ludGVyY2VwdG9yL25vdGlmaWNhdGlvbi5pbnRlcmNlcHRvci50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvY29yZS9zZW50cnkvZGVkdXBsaWNhdGUuc2VudHJ5LWludGVncmF0aW9uLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3JlL3NlbnRyeS9zZW50cnkuZXJyb3ItaGFuZGxlci50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvc2hhcmVkL25vdGlmaWNhdGlvbi9sb2FkaW5nLW5vdGlmaWNhdGlvbi9sb2FkaW5nLW5vdGlmaWNhdGlvbi5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL2xvYWRpbmctbm90aWZpY2F0aW9uL2xvYWRpbmctbm90aWZpY2F0aW9uLmludGVyY2VwdG9yLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3JlL2ludGVyY2VwdG9yL2ludGVyY2VwdG9yLnV0aWwudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvcmUvaW50ZXJjZXB0b3IvYnJvd3Nlci1maW5nZXJwcmludC5pbnRlcmNlcHRvci5zZXJ2aWNlLnRzIiwic3JjL21haW4vd2ViYXBwL2FwcC9jb3JlL2ludGVyY2VwdG9yL2FydGVtaXMtdmVyc2lvbi5pbnRlcmNlcHRvci50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvY29yZS9jb25maWcvZGF5anMudHMiLCJzcmMvbWFpbi93ZWJhcHAvYXBwL2NvcmUvY29uZmlnL2RhdGVwaWNrZXItYWRhcHRlci50cyIsInNyYy9tYWluL3dlYmFwcC9hcHAvY29yZS9jb3JlLm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgb2YgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IExvY2FsU3RvcmFnZVNlcnZpY2UsIFNlc3Npb25TdG9yYWdlU2VydmljZSB9IGZyb20gJ25neC13ZWJzdG9yYWdlJztcblxuZXhwb3J0IGNsYXNzIENyZWRlbnRpYWxzIHtcbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHVibGljIHVzZXJuYW1lOiBzdHJpbmcsXG4gICAgICAgIHB1YmxpYyBwYXNzd29yZDogc3RyaW5nLFxuICAgICAgICBwdWJsaWMgcmVtZW1iZXJNZTogYm9vbGVhbixcbiAgICApIHt9XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSUF1dGhTZXJ2ZXJQcm92aWRlciB7XG4gICAgbG9naW46IChjcmVkZW50aWFsczogQ3JlZGVudGlhbHMpID0+IE9ic2VydmFibGU8YW55PjtcbiAgICBsb2dpblNBTUwyOiAocmVtZW1iZXJNZTogYm9vbGVhbikgPT4gT2JzZXJ2YWJsZTxhbnk+O1xuICAgIGxvZ291dDogKCkgPT4gT2JzZXJ2YWJsZTxhbnk+O1xuICAgIGNsZWFyQ2FjaGVzOiAoKSA9PiBPYnNlcnZhYmxlPHVuZGVmaW5lZD47XG59XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgQXV0aFNlcnZlclByb3ZpZGVyIGltcGxlbWVudHMgSUF1dGhTZXJ2ZXJQcm92aWRlciB7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgaHR0cDogSHR0cENsaWVudCxcbiAgICAgICAgcHJpdmF0ZSBsb2NhbFN0b3JhZ2U6IExvY2FsU3RvcmFnZVNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgc2Vzc2lvblN0b3JhZ2U6IFNlc3Npb25TdG9yYWdlU2VydmljZSxcbiAgICApIHt9XG5cbiAgICBsb2dpbihjcmVkZW50aWFsczogQ3JlZGVudGlhbHMpOiBPYnNlcnZhYmxlPG9iamVjdD4ge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QoJ2FwaS9wdWJsaWMvYXV0aGVudGljYXRlJywgY3JlZGVudGlhbHMpO1xuICAgIH1cblxuICAgIGxvZ2luU0FNTDIocmVtZW1iZXJNZTogYm9vbGVhbik6IE9ic2VydmFibGU8b2JqZWN0PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdCgnYXBpL3B1YmxpYy9zYW1sMicsIHJlbWVtYmVyTWUudG9TdHJpbmcoKSk7XG4gICAgfVxuXG4gICAgbG9nb3V0KCk6IE9ic2VydmFibGU8b2JqZWN0PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdCgnYXBpL3B1YmxpYy9sb2dvdXQnLCBudWxsKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDbGVhcnMgYWxsIHRoZSBjYWNoZXMsIHNob3VsZCBiZSBpbnZva2VkIGR1cmluZyBsb2dvdXRcbiAgICAgKi9cbiAgICBjbGVhckNhY2hlcygpOiBPYnNlcnZhYmxlPHVuZGVmaW5lZD4ge1xuICAgICAgICB0aGlzLmxvY2FsU3RvcmFnZS5jbGVhcigpO1xuICAgICAgICB0aGlzLnNlc3Npb25TdG9yYWdlLmNsZWFyKCk7XG4gICAgICAgIC8vIFRoZSBsb2NhbCBvciBzZXNzaW9uIHN0b3JhZ2UgbWlnaHQgaGF2ZSB0byBiZSBjbGVhcmVkIGFzeW5jaHJvbm91c2x5IGluIGZ1dHVyZSBkdWUgdG8gdXBkYXRlZCBicm93c2VyIGFwaXMuIFRoaXMgaXMgd2h5IHRoaXMgbWV0aG9kIGlzIGFscmVhZHkgYWN0aW5nIGFzeW5jaHJvbm91cy5cbiAgICAgICAgcmV0dXJuIG9mKHVuZGVmaW5lZCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQWxlcnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvdXRpbC9hbGVydC5zZXJ2aWNlJztcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBmaW5hbGl6ZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcblxuaW1wb3J0IHsgQXV0aFNlcnZlclByb3ZpZGVyLCBDcmVkZW50aWFscyB9IGZyb20gJ2FwcC9jb3JlL2F1dGgvYXV0aC1qd3Quc2VydmljZSc7XG5pbXBvcnQgeyBBY2NvdW50U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL2F1dGgvYWNjb3VudC5zZXJ2aWNlJztcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBMb2dpblNlcnZpY2Uge1xuICAgIGxvZ291dFdhc0ZvcmNlZnVsID0gZmFsc2U7XG5cbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgcHJpdmF0ZSBhY2NvdW50U2VydmljZTogQWNjb3VudFNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgYXV0aFNlcnZlclByb3ZpZGVyOiBBdXRoU2VydmVyUHJvdmlkZXIsXG4gICAgICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgICAgIHByaXZhdGUgYWxlcnRTZXJ2aWNlOiBBbGVydFNlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogTG9naW4gdGhlIHVzZXIgd2l0aCB0aGUgZ2l2ZW4gY3JlZGVudGlhbHMuXG4gICAgICogQHBhcmFtIGNyZWRlbnRpYWxzIHtDcmVkZW50aWFsc30gQ3JlZGVudGlhbHMgb2YgdGhlIHVzZXIgdG8gbG9naW4uXG4gICAgICovXG4gICAgbG9naW4oY3JlZGVudGlhbHM6IENyZWRlbnRpYWxzKSB7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICB0aGlzLmF1dGhTZXJ2ZXJQcm92aWRlci5sb2dpbihjcmVkZW50aWFscykuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWNjb3VudFNlcnZpY2UuaWRlbnRpdHkodHJ1ZSkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgZXJyb3I6IChlcnIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2dvdXQoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIExvZ2luIHRoZSB1c2VyIHdpdGggU0FNTDIuXG4gICAgICogQHBhcmFtIHJlbWVtYmVyTWUgd2hldGhlciBvciBub3QgdG8gcmVtZW1iZXIgdGhlIHVzZXJcbiAgICAgKi9cbiAgICBsb2dpblNBTUwyKHJlbWVtYmVyTWU6IGJvb2xlYW4pIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYXV0aFNlcnZlclByb3ZpZGVyLmxvZ2luU0FNTDIocmVtZW1iZXJNZSkuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgICAgICBuZXh0OiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWNjb3VudFNlcnZpY2UuaWRlbnRpdHkodHJ1ZSkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgZXJyb3I6IChlcnIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2dvdXQoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIExvZyBvdXQgdGhlIHVzZXIgYW5kIHJlbW92ZSBhbGwgdHJhY2VzIG9mIHRoZSBsb2dpbiBmcm9tIHRoZSBicm93c2VyOlxuICAgICAqIFRva2VucywgQWxlcnRzLCBVc2VyIG9iamVjdCBpbiBtZW1vcnkuXG4gICAgICogV2lsbCByZWRpcmVjdCB0byBob21lIHdoZW4gZG9uZS5cbiAgICAgKi9cbiAgICBsb2dvdXQod2FzSW5pdGlhdGVkQnlVc2VyOiBib29sZWFuKSB7XG4gICAgICAgIHRoaXMubG9nb3V0V2FzRm9yY2VmdWwgPSAhd2FzSW5pdGlhdGVkQnlVc2VyO1xuXG4gICAgICAgIGlmICh3YXNJbml0aWF0ZWRCeVVzZXIpIHtcbiAgICAgICAgICAgIHRoaXMuYXV0aFNlcnZlclByb3ZpZGVyXG4gICAgICAgICAgICAgICAgLmxvZ291dCgpXG4gICAgICAgICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICAgICAgICAgIGZpbmFsaXplKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub25Mb2dvdXQoKTtcbiAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIC5zdWJzY3JpYmUoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMub25Mb2dvdXQoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgb25Mb2dvdXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuYWNjb3VudFNlcnZpY2UuYXV0aGVudGljYXRlKHVuZGVmaW5lZCk7XG4gICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLmNsb3NlQWxsKCk7XG4gICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlQnlVcmwoJy8nKTtcbiAgICB9XG5cbiAgICBsYXN0TG9nb3V0V2FzRm9yY2VmdWwoKTogYm9vbGVhbiB7XG4gICAgICAgIHJldHVybiB0aGlzLmxvZ291dFdhc0ZvcmNlZnVsO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBFcnJvclJlc3BvbnNlLCBIdHRwRXZlbnQsIEh0dHBIYW5kbGVyLCBIdHRwSW50ZXJjZXB0b3IsIEh0dHBSZXF1ZXN0IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgTG9naW5TZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvbG9naW4vbG9naW4uc2VydmljZSc7XG5pbXBvcnQgeyBTdGF0ZVN0b3JhZ2VTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvYXV0aC9zdGF0ZS1zdG9yYWdlLnNlcnZpY2UnO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IEFjY291bnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvYXV0aC9hY2NvdW50LnNlcnZpY2UnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgQXV0aEV4cGlyZWRJbnRlcmNlcHRvciBpbXBsZW1lbnRzIEh0dHBJbnRlcmNlcHRvciB7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHByaXZhdGUgbG9naW5TZXJ2aWNlOiBMb2dpblNlcnZpY2UsXG4gICAgICAgIHByaXZhdGUgc3RhdGVTdG9yYWdlU2VydmljZTogU3RhdGVTdG9yYWdlU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcbiAgICAgICAgcHJpdmF0ZSBhY2NvdW50U2VydmljZTogQWNjb3VudFNlcnZpY2UsXG4gICAgKSB7fVxuXG4gICAgLyoqXG4gICAgICogSWRlbnRpZmllcyBhbmQgaGFuZGxlcyBhIGdpdmVuIEhUVFAgcmVxdWVzdC4gSWYgdGhlIHJlcXVlc3QncyBlcnJvciBzdGF0dXMgaXMgNDAxLCB0aGUgY3VycmVudCB1c2VyIHdpbGwgYmUgbG9nZ2VkIG91dC5cbiAgICAgKiBAcGFyYW0gcmVxdWVzdCBUaGUgb3V0Z29pbmcgcmVxdWVzdCBvYmplY3QgdG8gaGFuZGxlLlxuICAgICAqIEBwYXJhbSBuZXh0IFRoZSBuZXh0IGludGVyY2VwdG9yIGluIHRoZSBjaGFpbiwgb3IgdGhlIHNlcnZlclxuICAgICAqIGlmIG5vIGludGVyY2VwdG9ycyByZW1haW4gaW4gdGhlIGNoYWluLlxuICAgICAqIEByZXR1cm5zIEFuIG9ic2VydmFibGUgb2YgdGhlIGV2ZW50IHN0cmVhbS5cbiAgICAgKi9cbiAgICBpbnRlcmNlcHQocmVxdWVzdDogSHR0cFJlcXVlc3Q8YW55PiwgbmV4dDogSHR0cEhhbmRsZXIpOiBPYnNlcnZhYmxlPEh0dHBFdmVudDxhbnk+PiB7XG4gICAgICAgIHJldHVybiBuZXh0LmhhbmRsZShyZXF1ZXN0KS5waXBlKFxuICAgICAgICAgICAgdGFwKHtcbiAgICAgICAgICAgICAgICBlcnJvcjogKGVycjogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBIdHRwRXJyb3JSZXNwb25zZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVyci5zdGF0dXMgPT09IDQwMSAmJiB0aGlzLmFjY291bnRTZXJ2aWNlLmlzQXV0aGVudGljYXRlZCgpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gc2F2ZSB0aGUgdXJsIGJlZm9yZSB0aGUgbG9nb3V0IG5hdmlnYXRlcyB0byBhbm90aGVyIHBhZ2UgaW4gYSBjb25zdGFudFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRVcmwgPSB0aGlzLnJvdXRlci5yb3V0ZXJTdGF0ZS5zbmFwc2hvdC51cmw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2dpblNlcnZpY2UubG9nb3V0KGZhbHNlKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRPRE86IGxvZ2dpbmcgb3V0IHRoZSB1c2VyIGF1dG9tYXRpY2FsbHkgaW50ZXJmZXJlcyB3aXRoIHRoZSBjYW5EZWFjdGl2YXRlIGZ1bmN0aW9uYWxpdHkuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSW4gc3VjaCBhIGNhc2UgdGhlIGVycm9yIG1lc3NhZ2Ugc2hvdWxkIGJlIGRpZmZlcmVudCBvciB3ZSBzaG91bGQgZXZlbiBzZW5kIG9uZSBhZGRpdGlvbmFsIG1lc3NhZ2UgdG8gdGhlIHVzZXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBzdG9yZSB1cmwgc28gdGhhdCB0aGUgdXNlciBjb3VsZCBuYXZpZ2F0ZSBkaXJlY3RseSB0byBpdCBhZnRlciBsb2dpblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHN0b3JlIHRoZSB1cmwgaW4gdGhlIHNlc3Npb24gc3RvcmFnZSBhZnRlciB0aGUgbG9nb3V0LCBiZWNhdXNlIHRoZSBsb2dvdXQgd2lsbCByZWRpcmVjdCB0aGUgdXNlclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGVTdG9yYWdlU2VydmljZS5zdG9yZVVybChjdXJyZW50VXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSwgSHR0cEV2ZW50LCBIdHRwSGFuZGxlciwgSHR0cEludGVyY2VwdG9yLCBIdHRwUmVxdWVzdCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IHRhcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IEV2ZW50TWFuYWdlciB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvZXZlbnQtbWFuYWdlci5zZXJ2aWNlJztcbmltcG9ydCB7IEFjY291bnRTZXJ2aWNlIH0gZnJvbSAnYXBwL2NvcmUvYXV0aC9hY2NvdW50LnNlcnZpY2UnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgRXJyb3JIYW5kbGVySW50ZXJjZXB0b3IgaW1wbGVtZW50cyBIdHRwSW50ZXJjZXB0b3Ige1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGV2ZW50TWFuYWdlcjogRXZlbnRNYW5hZ2VyLFxuICAgICAgICBwcml2YXRlIGFjY291bnRTZXJ2aWNlOiBBY2NvdW50U2VydmljZSxcbiAgICApIHt9XG5cbiAgICAvKipcbiAgICAgKiBJZGVudGlmaWVzIGFuZCBoYW5kbGVzIGEgZ2l2ZW4gSFRUUCByZXF1ZXN0LiBJZiB0aGUgcmVxdWVzdCdzIGVycm9yIHN0YXR1cyBpcyBub3QgNDAxIHdoaWxlIHRoZSB1c2VyIGlzIG5vdFxuICAgICAqIGF1dGhlbnRpY2F0ZWQsIHRoZSBodHRwRXJyb3IgaXMgYnJvYWRjYXN0ZWQgdG8gdGhlIG9ic2VydmVyLlxuICAgICAqIEBwYXJhbSByZXF1ZXN0IFRoZSBvdXRnb2luZyByZXF1ZXN0IG9iamVjdCB0byBoYW5kbGUuXG4gICAgICogQHBhcmFtIG5leHQgVGhlIG5leHQgaW50ZXJjZXB0b3IgaW4gdGhlIGNoYWluLCBvciB0aGUgc2VydmVyXG4gICAgICogaWYgbm8gaW50ZXJjZXB0b3JzIHJlbWFpbiBpbiB0aGUgY2hhaW4uXG4gICAgICogQHJldHVybnMgQW4gb2JzZXJ2YWJsZSBvZiB0aGUgZXZlbnQgc3RyZWFtLlxuICAgICAqL1xuICAgIGludGVyY2VwdChyZXF1ZXN0OiBIdHRwUmVxdWVzdDxhbnk+LCBuZXh0OiBIdHRwSGFuZGxlcik6IE9ic2VydmFibGU8SHR0cEV2ZW50PGFueT4+IHtcbiAgICAgICAgcmV0dXJuIG5leHQuaGFuZGxlKHJlcXVlc3QpLnBpcGUoXG4gICAgICAgICAgICB0YXAoe1xuICAgICAgICAgICAgICAgIGVycm9yOiAoZXJyOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEh0dHBFcnJvclJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIShlcnIuc3RhdHVzID09PSA0MDEgJiYgIXRoaXMuYWNjb3VudFNlcnZpY2UuaXNBdXRoZW50aWNhdGVkKCkpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5ldmVudE1hbmFnZXIuYnJvYWRjYXN0KHsgbmFtZTogJ2FydGVtaXNBcHAuaHR0cEVycm9yJywgY29udGVudDogZXJyIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEh0dHBFdmVudCwgSHR0cEhhbmRsZXIsIEh0dHBJbnRlcmNlcHRvciwgSHR0cFJlcXVlc3QsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IHRhcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IEFsZXJ0U2VydmljZSB9IGZyb20gJ2FwcC9jb3JlL3V0aWwvYWxlcnQuc2VydmljZSc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBOb3RpZmljYXRpb25JbnRlcmNlcHRvciBpbXBsZW1lbnRzIEh0dHBJbnRlcmNlcHRvciB7XG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBhbGVydFNlcnZpY2U6IEFsZXJ0U2VydmljZSkge31cblxuICAgIC8qKlxuICAgICAqIElkZW50aWZpZXMgYW5kIGhhbmRsZXMgYSBnaXZlbiBIVFRQIHJlcXVlc3QuIElmIHRoZSBldmVudCBpcyBhIEh0dHBSZXNwb25zZSBhbmQgY29udGFpbnMgYW4gYWxlcnQsIHRoZSBhbGVydFxuICAgICAqIGFuZCBpdHMgcGFyYW1ldGVycyBhcmUgYnJvYWRjYXN0ZWQgdG8gdGhlIEFsZXJ0U2VydmljZS5cbiAgICAgKiBAcGFyYW0gcmVxdWVzdCBUaGUgb3V0Z29pbmcgcmVxdWVzdCBvYmplY3QgdG8gaGFuZGxlLlxuICAgICAqIEBwYXJhbSBuZXh0IFRoZSBuZXh0IGludGVyY2VwdG9yIGluIHRoZSBjaGFpbiwgb3IgdGhlIHNlcnZlclxuICAgICAqIGlmIG5vIGludGVyY2VwdG9ycyByZW1haW4gaW4gdGhlIGNoYWluLlxuICAgICAqIEByZXR1cm5zIEFuIG9ic2VydmFibGUgb2YgdGhlIGV2ZW50IHN0cmVhbS5cbiAgICAgKi9cbiAgICBpbnRlcmNlcHQocmVxdWVzdDogSHR0cFJlcXVlc3Q8YW55PiwgbmV4dDogSHR0cEhhbmRsZXIpOiBPYnNlcnZhYmxlPEh0dHBFdmVudDxhbnk+PiB7XG4gICAgICAgIHJldHVybiBuZXh0LmhhbmRsZShyZXF1ZXN0KS5waXBlKFxuICAgICAgICAgICAgdGFwKChldmVudDogSHR0cEV2ZW50PGFueT4pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoZXZlbnQgaW5zdGFuY2VvZiBIdHRwUmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGFsZXJ0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGFsZXJ0UGFyYW1zOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuICAgICAgICAgICAgICAgICAgICBldmVudC5oZWFkZXJzLmtleXMoKS5mb3JFYWNoKChlbnRyeSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVudHJ5LnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJ2FwcC1hbGVydCcpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxlcnQgPSBldmVudC5oZWFkZXJzLmdldChlbnRyeSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGVudHJ5LnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJ2FwcC1wYXJhbXMnKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsZXJ0UGFyYW1zID0gZGVjb2RlVVJJQ29tcG9uZW50KGV2ZW50LmhlYWRlcnMuZ2V0KGVudHJ5KSEucmVwbGFjZSgvXFwrL2csICcgJykpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgICAgICBpZiAoYWxlcnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxlcnRTZXJ2aWNlLnN1Y2Nlc3MoYWxlcnQsIHsgcGFyYW06IGFsZXJ0UGFyYW1zIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgRXZlbnQsIEh1YiB9IGZyb20gJ0BzZW50cnkvYW5ndWxhci1pdnknO1xuaW1wb3J0IHsgRXZlbnRQcm9jZXNzb3IsIEludGVncmF0aW9uIH0gZnJvbSAnQHNlbnRyeS90eXBlcyc7XG5pbXBvcnQgeyBzaGExSGV4IH0gZnJvbSAnYXBwL3NoYXJlZC91dGlsL2NyeXB0by51dGlscyc7XG5cbmV4cG9ydCBjbGFzcyBBcnRlbWlzRGVkdXBsaWNhdGUgaW1wbGVtZW50cyBJbnRlZ3JhdGlvbiB7XG4gICAgcHVibGljIHN0YXRpYyBpZCA9ICdBcnRlbWlzRGVkdXBsaWNhdGUnO1xuICAgIHB1YmxpYyBuYW1lOiBzdHJpbmcgPSBBcnRlbWlzRGVkdXBsaWNhdGUuaWQ7XG5cbiAgICBwcml2YXRlIG9ic2VydmVkRXZlbnRIYXNoZXM6IHN0cmluZ1tdID0gW107XG5cbiAgICBwdWJsaWMgc2V0dXBPbmNlKGFkZEdsb2JhbEV2ZW50UHJvY2Vzc29yOiAoY2FsbGJhY2s6IEV2ZW50UHJvY2Vzc29yKSA9PiB2b2lkLCBnZXRDdXJyZW50SHViOiAoKSA9PiBIdWIpOiB2b2lkIHtcbiAgICAgICAgYWRkR2xvYmFsRXZlbnRQcm9jZXNzb3IoKGN1cnJlbnRFdmVudDogRXZlbnQpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHNlbGYgPSBnZXRDdXJyZW50SHViKCkuZ2V0SW50ZWdyYXRpb24oQXJ0ZW1pc0RlZHVwbGljYXRlKTtcbiAgICAgICAgICAgIGlmIChzZWxmKSB7XG4gICAgICAgICAgICAgICAgLy8gVHJ5LWNhdGNoIHRvIG1ha2Ugc3VyZSB0aGF0IHdlIHN1Ym1pdCB0aGUgZXZlbnQgaWYgc29tZXRoaW5nIGdvZXMgd3JvbmcgZHVyaW5nIGRlZHVwbGljYXRpb25cbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAvLyBIYXNoIHRoZSBjdXJyZW50IGV2ZW50IGFuZCBjaGVjayBpZiBoYXNoIGlzIHByZXNlbnQgaW4gYWxyZWFkeSBzZWVuIGV2ZW50IGhhc2hlc1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBldmVudEhhc2ggPSBjb21wdXRlRXZlbnRIYXNoKGN1cnJlbnRFdmVudCk7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm9ic2VydmVkRXZlbnRIYXNoZXMuaW5jbHVkZXMoZXZlbnRIYXNoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7IC8vIERyb3AgZXZlbnRcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFkZCBldmVudCB0byBzZWVuIGV2ZW50cyBhbmQgc2NoZWR1bGUgcmVtb3ZhbCBpbiA1IG1pbnV0ZXMgKHRocm90dGxlKVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vYnNlcnZlZEV2ZW50SGFzaGVzLnB1c2goZXZlbnRIYXNoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpbmRleCA9IHRoaXMub2JzZXJ2ZWRFdmVudEhhc2hlcy5pbmRleE9mKGV2ZW50SGFzaCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpbmRleCA+PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9ic2VydmVkRXZlbnRIYXNoZXMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgNSAqIDYwICogMTAwMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGN1cnJlbnRFdmVudDtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuXG4vKipcbiAqIFN0aWNrcyB0b2dldGhlciBhIHNpbXBsZSBzdHJpbmcgd2l0aCBpbXBvcnRhbnQgdmFsdWVzIG9mIHRoZSBldmVudCBhbmQgaGFzaGVzIGl0IHRvIHByb2R1Y2UgYW4gZWFzaWx5IGNvbXBhcmFibGUgdmFsdWVcbiAqIEBwYXJhbSBldmVudCB0aGUgc2VudHJ5IGV2ZW50IHRvIGhhc2hcbiAqL1xuZnVuY3Rpb24gY29tcHV0ZUV2ZW50SGFzaChldmVudDogRXZlbnQpOiBzdHJpbmcge1xuICAgIC8vIEFkZCB0aGUgbWVzc2FnZVxuICAgIGxldCB2YWx1ZVNlcXVlbmNlID0gZXZlbnQubWVzc2FnZSA/PyAnJztcblxuICAgIC8vIElmIHRoZSBldmVudCBoYXMgYW4gZXhjZXB0aW9uLCBhZGQgdHlwZSwgdmFsdWVcbiAgICBjb25zdCBleGNlcHRpb24gPSBldmVudC5leGNlcHRpb24/LnZhbHVlcz8uWzBdO1xuICAgIGlmIChleGNlcHRpb24pIHtcbiAgICAgICAgdmFsdWVTZXF1ZW5jZSArPSBleGNlcHRpb24udHlwZSA/PyAnJztcbiAgICAgICAgdmFsdWVTZXF1ZW5jZSArPSBleGNlcHRpb24udmFsdWUgPz8gJyc7XG4gICAgfVxuXG4gICAgLy8gSWYgZXZlbnQgaGFzIHN0YWNrIHRyYWNlLCBhZGQgZmlsZW5hbWUgYW5kIGxpbmUgb2YgZWFjaCBmcmFtZVxuICAgIGNvbnN0IGZyYW1lcyA9IGV4Y2VwdGlvbj8uc3RhY2t0cmFjZT8uZnJhbWVzO1xuICAgIGlmIChmcmFtZXMpIHtcbiAgICAgICAgZnJhbWVzLmZvckVhY2goKGZyYW1lKSA9PiAodmFsdWVTZXF1ZW5jZSArPSBmcmFtZS5maWxlbmFtZSA/PyAnJykpO1xuICAgICAgICBmcmFtZXMuZm9yRWFjaCgoZnJhbWUpID0+ICh2YWx1ZVNlcXVlbmNlICs9IGZyYW1lLmxpbmVubyA/PyAnJykpO1xuICAgIH1cblxuICAgIHJldHVybiBzaGExSGV4KHZhbHVlU2VxdWVuY2UpO1xufVxuIiwiaW1wb3J0IHsgRXJyb3JIYW5kbGVyLCBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBjYXB0dXJlRXhjZXB0aW9uLCBpbml0LCBpbnN0cnVtZW50QW5ndWxhclJvdXRpbmcgfSBmcm9tICdAc2VudHJ5L2FuZ3VsYXItaXZ5JztcbmltcG9ydCB7IEJyb3dzZXJUcmFjaW5nIH0gZnJvbSAnQHNlbnRyeS90cmFjaW5nJztcbmltcG9ydCB7IFZFUlNJT04gfSBmcm9tICdhcHAvYXBwLmNvbnN0YW50cyc7XG5pbXBvcnQgeyBQcm9maWxlSW5mbyB9IGZyb20gJ2FwcC9zaGFyZWQvbGF5b3V0cy9wcm9maWxlcy9wcm9maWxlLWluZm8ubW9kZWwnO1xuaW1wb3J0IHsgQXJ0ZW1pc0RlZHVwbGljYXRlIH0gZnJvbSAnYXBwL2NvcmUvc2VudHJ5L2RlZHVwbGljYXRlLnNlbnRyeS1pbnRlZ3JhdGlvbic7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgU2VudHJ5RXJyb3JIYW5kbGVyIGV4dGVuZHMgRXJyb3JIYW5kbGVyIHtcbiAgICBwcml2YXRlIGVudmlyb25tZW50OiBzdHJpbmc7XG5cbiAgICAvKipcbiAgICAgKiBJbml0aWFsaXplIFNlbnRyeSB3aXRoIHByb2ZpbGUgaW5mb3JtYXRpb24uXG4gICAgICogQHBhcmFtIHByb2ZpbGVJbmZvXG4gICAgICovXG4gICAgcHVibGljIGFzeW5jIGluaXRTZW50cnkocHJvZmlsZUluZm86IFByb2ZpbGVJbmZvKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgICAgIGlmICghcHJvZmlsZUluZm8gfHwgIXByb2ZpbGVJbmZvLnNlbnRyeSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHByb2ZpbGVJbmZvLnRlc3RTZXJ2ZXIgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBpZiAocHJvZmlsZUluZm8udGVzdFNlcnZlcikge1xuICAgICAgICAgICAgICAgIHRoaXMuZW52aXJvbm1lbnQgPSAndGVzdCc7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMuZW52aXJvbm1lbnQgPSAncHJvZCc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmVudmlyb25tZW50ID0gJ2xvY2FsJztcbiAgICAgICAgfVxuXG4gICAgICAgIGluaXQoe1xuICAgICAgICAgICAgZHNuOiBwcm9maWxlSW5mby5zZW50cnkuZHNuLFxuICAgICAgICAgICAgcmVsZWFzZTogVkVSU0lPTixcbiAgICAgICAgICAgIGVudmlyb25tZW50OiB0aGlzLmVudmlyb25tZW50LFxuICAgICAgICAgICAgaW50ZWdyYXRpb25zOiAoaW50ZWdyYXRpb25zKSA9PiB7XG4gICAgICAgICAgICAgICAgaW50ZWdyYXRpb25zLnB1c2gobmV3IEFydGVtaXNEZWR1cGxpY2F0ZSgpKTtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5lbnZpcm9ubWVudCAhPT0gJ2xvY2FsJykge1xuICAgICAgICAgICAgICAgICAgICBpbnRlZ3JhdGlvbnMucHVzaChcbiAgICAgICAgICAgICAgICAgICAgICAgIG5ldyBCcm93c2VyVHJhY2luZyh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcm91dGluZ0luc3RydW1lbnRhdGlvbjogaW5zdHJ1bWVudEFuZ3VsYXJSb3V0aW5nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJlZm9yZU5hdmlnYXRlOiAoY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uY29udGV4dCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IGxvY2F0aW9uLnBhdGhuYW1lLnJlcGxhY2UoL1xcL1thLWYwLTldezMyfS9nLCAnLzxoYXNoPicpLnJlcGxhY2UoL1xcL1xcZCsvZywgJy88ZGlnaXRzPicpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGludGVncmF0aW9ucztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0cmFjZXNTYW1wbGVSYXRlOiB0aGlzLmVudmlyb25tZW50ICE9PSAncHJvZCcgPyAxLjAgOiAwLjIsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcigpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFNlbmQgYW4gSHR0cEVycm9yIHRvIFNlbnRyeS4gT25seSBpZiBpdCdzIG5vdCBpbiB0aGUgcmFuZ2UgNDAwLTQ5OS5cbiAgICAgKiBAcGFyYW0gZXJyb3JcbiAgICAgKi9cbiAgICBvdmVycmlkZSBoYW5kbGVFcnJvcihlcnJvcjogYW55KTogdm9pZCB7XG4gICAgICAgIGlmIChlcnJvciAmJiBlcnJvci5uYW1lID09PSAnSHR0cEVycm9yUmVzcG9uc2UnICYmIGVycm9yLnN0YXR1cyA8IDUwMCAmJiBlcnJvci5zdGF0dXMgPj0gNDAwKSB7XG4gICAgICAgICAgICBzdXBlci5oYW5kbGVFcnJvcihlcnJvcik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuZW52aXJvbm1lbnQgIT09ICdsb2NhbCcpIHtcbiAgICAgICAgICAgIGNvbnN0IGV4Y2VwdGlvbiA9IGVycm9yLmVycm9yIHx8IGVycm9yLm1lc3NhZ2UgfHwgZXJyb3Iub3JpZ2luYWxFcnJvciB8fCBlcnJvcjtcbiAgICAgICAgICAgIGNhcHR1cmVFeGNlcHRpb24oZXhjZXB0aW9uKTtcbiAgICAgICAgfVxuICAgICAgICBzdXBlci5oYW5kbGVFcnJvcihlcnJvcik7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuXG5ASW5qZWN0YWJsZSh7XG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxufSlcbmV4cG9ydCBjbGFzcyBMb2FkaW5nTm90aWZpY2F0aW9uU2VydmljZSB7XG4gICAgbG9hZGluZ1N0YXR1czogU3ViamVjdDxib29sZWFuPiA9IG5ldyBTdWJqZWN0KCk7XG5cbiAgICAvKipcbiAgICAgKiBFbWl0IHZhbHVlIHRvIGRpc3BsYXkgbG9hZGluZyBzY3JlZW5cbiAgICAgKi9cbiAgICBzdGFydExvYWRpbmcoKSB7XG4gICAgICAgIHRoaXMubG9hZGluZ1N0YXR1cy5uZXh0KHRydWUpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEVtaXQgdmFsdWUgdG8gY2xvc2UgbG9hZGluZyBzY3JlZW5cbiAgICAgKi9cbiAgICBzdG9wTG9hZGluZygpIHtcbiAgICAgICAgdGhpcy5sb2FkaW5nU3RhdHVzLm5leHQoZmFsc2UpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBFdmVudCwgSHR0cEhhbmRsZXIsIEh0dHBJbnRlcmNlcHRvciwgSHR0cFJlcXVlc3QgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBmaW5hbGl6ZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IExvYWRpbmdOb3RpZmljYXRpb25TZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9ub3RpZmljYXRpb24vbG9hZGluZy1ub3RpZmljYXRpb24vbG9hZGluZy1ub3RpZmljYXRpb24uc2VydmljZSc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBMb2FkaW5nTm90aWZpY2F0aW9uSW50ZXJjZXB0b3IgaW1wbGVtZW50cyBIdHRwSW50ZXJjZXB0b3Ige1xuICAgIGFjdGl2ZVJlcXVlc3RzID0gMDtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgbG9hZGluZ05vdGlmaWNhdGlvblNlcnZpY2U6IExvYWRpbmdOb3RpZmljYXRpb25TZXJ2aWNlKSB7fVxuXG4gICAgLyoqXG4gICAgICogSWRlbnRpZmllcyBhbmQgaGFuZGxlcyBhIGdpdmVuIEhUVFAgcmVxdWVzdC4gSWYgYW55IEhUVFAgcmVxdWVzdCBpcyBzZW50IHdlIGVuYWJsZSB0aGUgbG9hZGluZyBzY3JlZW4gYW5kIGNvdW50IHVwIHRoZSBhY3RpdmUgcmVxdWVzdHMuXG4gICAgICogV2hpbGUgYWxsIEhUVFAgcmVxdWVzdCBjb21wbGV0ZSB3ZSBjb3VudCBkb3duIHRoZSBhY3RpdmUgcmVxdWVzdHMgYW5kIHdoZW4gYWxsIEhUVFAgcmVxdWVzdHMgYXJlIGNvbXBsZXRlZCB3ZSBkaXNhYmxlIHRoZSBsb2FkaW5nIHNjcmVlbi5cbiAgICAgKiBAcGFyYW0gcmVxdWVzdCBUaGUgb3V0Z29pbmcgcmVxdWVzdCBvYmplY3QgdG8gaGFuZGxlLlxuICAgICAqIEBwYXJhbSBuZXh0IFRoZSBuZXh0IGludGVyY2VwdG9yIGluIHRoZSBjaGFpbiwgb3IgdGhlIHNlcnZlclxuICAgICAqIGlmIG5vIGludGVyY2VwdG9ycyByZW1haW4gaW4gdGhlIGNoYWluLlxuICAgICAqIEByZXR1cm5zIEFuIG9ic2VydmFibGUgb2YgdGhlIGV2ZW50IHN0cmVhbS5cbiAgICAgKi9cbiAgICBpbnRlcmNlcHQocmVxdWVzdDogSHR0cFJlcXVlc3Q8YW55PiwgbmV4dDogSHR0cEhhbmRsZXIpOiBPYnNlcnZhYmxlPEh0dHBFdmVudDxhbnk+PiB7XG4gICAgICAgIGlmICh0aGlzLmFjdGl2ZVJlcXVlc3RzID09PSAwKSB7XG4gICAgICAgICAgICB0aGlzLmxvYWRpbmdOb3RpZmljYXRpb25TZXJ2aWNlLnN0YXJ0TG9hZGluZygpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYWN0aXZlUmVxdWVzdHMrKztcblxuICAgICAgICByZXR1cm4gbmV4dC5oYW5kbGUocmVxdWVzdCkucGlwZShcbiAgICAgICAgICAgIGZpbmFsaXplKCgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmFjdGl2ZVJlcXVlc3RzLS07XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuYWN0aXZlUmVxdWVzdHMgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nTm90aWZpY2F0aW9uU2VydmljZS5zdG9wTG9hZGluZygpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEh0dHBSZXF1ZXN0IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuXG4vKipcbiAqIFRlc3RzIGlmIGdpdmVuIFJlcXVlc3QgaXMgc2VudCB0byBBcnRlbWlzIFNlcnZlclxuICogQHBhcmFtIHJlcXVlc3QgUmVxdWVzdCB0byB0ZXN0XG4gKi9cbmV4cG9ydCBjb25zdCBpc1JlcXVlc3RUb0FydGVtaXNTZXJ2ZXIgPSAocmVxdWVzdDogSHR0cFJlcXVlc3Q8YW55Pik6IGJvb2xlYW4gPT4gISghcmVxdWVzdCB8fCAhcmVxdWVzdC51cmwgfHwgL15odHRwLy50ZXN0KHJlcXVlc3QudXJsKSk7XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwRXZlbnQsIEh0dHBIYW5kbGVyLCBIdHRwSW50ZXJjZXB0b3IsIEh0dHBSZXF1ZXN0IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgQnJvd3NlckZpbmdlcnByaW50U2VydmljZSB9IGZyb20gJ2FwcC9zaGFyZWQvZmluZ2VycHJpbnQvYnJvd3Nlci1maW5nZXJwcmludC5zZXJ2aWNlJztcbmltcG9ydCB7IGlzUmVxdWVzdFRvQXJ0ZW1pc1NlcnZlciB9IGZyb20gJy4vaW50ZXJjZXB0b3IudXRpbCc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBCcm93c2VyRmluZ2VycHJpbnRJbnRlcmNlcHRvciBpbXBsZW1lbnRzIEh0dHBJbnRlcmNlcHRvciB7XG4gICAgcHJpdmF0ZSBmaW5nZXJwcmludD86IHN0cmluZztcbiAgICBwcml2YXRlIGluc3RhbmNlSWRlbnRpZmllcj86IHN0cmluZztcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgYnJvd3NlckZpbmdlcnByaW50U2VydmljZTogQnJvd3NlckZpbmdlcnByaW50U2VydmljZSkge1xuICAgICAgICBicm93c2VyRmluZ2VycHJpbnRTZXJ2aWNlLmZpbmdlcnByaW50LnN1YnNjcmliZSgoZmluZ2VycHJpbnQpID0+ICh0aGlzLmZpbmdlcnByaW50ID0gZmluZ2VycHJpbnQpKTtcbiAgICAgICAgYnJvd3NlckZpbmdlcnByaW50U2VydmljZS5pbnN0YW5jZUlkZW50aWZpZXIuc3Vic2NyaWJlKChpbnN0YW5jZUlkZW50aWZpZXIpID0+ICh0aGlzLmluc3RhbmNlSWRlbnRpZmllciA9IGluc3RhbmNlSWRlbnRpZmllcikpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEludGVyY2VwdHMgYWxsIEhUVFAgUmVxdWVzdHMgdG8gdGhlIEFydGVtaXMgU2VydmVyIGFuZCBhZGRzIEZpbmdlcnByaW50ICsgSW5zdGFuY2UgSUQgYXMgSFRUUCBIZWFkZXJzXG4gICAgICpcbiAgICAgKiBAcGFyYW0gcmVxdWVzdCBUaGUgb3V0Z29pbmcgcmVxdWVzdCBvYmplY3QgdG8gaGFuZGxlLlxuICAgICAqIEBwYXJhbSBuZXh0IFRoZSBuZXh0IGludGVyY2VwdG9yIGluIHRoZSBjaGFpbiwgb3IgdGhlIHNlcnZlciBpZiBubyBpbnRlcmNlcHRvcnMgcmVtYWluIGluIHRoZSBjaGFpbi5cbiAgICAgKiBAcmV0dXJucyBBbiBvYnNlcnZhYmxlIG9mIHRoZSBldmVudCBzdHJlYW0uXG4gICAgICovXG4gICAgaW50ZXJjZXB0KHJlcXVlc3Q6IEh0dHBSZXF1ZXN0PGFueT4sIG5leHQ6IEh0dHBIYW5kbGVyKTogT2JzZXJ2YWJsZTxIdHRwRXZlbnQ8YW55Pj4ge1xuICAgICAgICBpZiAoaXNSZXF1ZXN0VG9BcnRlbWlzU2VydmVyKHJlcXVlc3QpICYmICh0aGlzLmluc3RhbmNlSWRlbnRpZmllciB8fCB0aGlzLmZpbmdlcnByaW50KSkge1xuICAgICAgICAgICAgcmVxdWVzdCA9IHJlcXVlc3QuY2xvbmUoe1xuICAgICAgICAgICAgICAgIHNldEhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAgICAgJ1gtQXJ0ZW1pcy1DbGllbnQtSW5zdGFuY2UtSUQnOiB0aGlzLmluc3RhbmNlSWRlbnRpZmllciA/PyAnJyxcbiAgICAgICAgICAgICAgICAgICAgJ1gtQXJ0ZW1pcy1DbGllbnQtRmluZ2VycHJpbnQnOiB0aGlzLmZpbmdlcnByaW50ID8/ICcnLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBuZXh0LmhhbmRsZShyZXF1ZXN0KTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBBcHBsaWNhdGlvblJlZiwgSW5qZWN0LCBJbmplY3RhYmxlLCBJbmplY3Rpb25Ub2tlbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cEV2ZW50LCBIdHRwSGFuZGxlciwgSHR0cEludGVyY2VwdG9yLCBIdHRwUmVxdWVzdCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgY29uY2F0LCBpbnRlcnZhbCwgb2YgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IGNhdGNoRXJyb3IsIGZpcnN0LCB0YXAsIHRpbWVvdXQgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBBUlRFTUlTX1ZFUlNJT05fSEVBREVSLCBWRVJTSU9OIH0gZnJvbSAnYXBwL2FwcC5jb25zdGFudHMnO1xuaW1wb3J0IHsgQXJ0ZW1pc1NlcnZlckRhdGVTZXJ2aWNlIH0gZnJvbSAnYXBwL3NoYXJlZC9zZXJ2ZXItZGF0ZS5zZXJ2aWNlJztcbmltcG9ydCB7IFN3VXBkYXRlIH0gZnJvbSAnQGFuZ3VsYXIvc2VydmljZS13b3JrZXInO1xuaW1wb3J0IHsgQWxlcnQsIEFsZXJ0U2VydmljZSwgQWxlcnRUeXBlIH0gZnJvbSAnYXBwL2NvcmUvdXRpbC9hbGVydC5zZXJ2aWNlJztcblxuZXhwb3J0IGNvbnN0IFdJTkRPV19JTkpFQ1RPUl9UT0tFTiA9IG5ldyBJbmplY3Rpb25Ub2tlbjxXaW5kb3c+KCdXaW5kb3cnKTtcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIEFydGVtaXNWZXJzaW9uSW50ZXJjZXB0b3IgaW1wbGVtZW50cyBIdHRwSW50ZXJjZXB0b3Ige1xuICAgIC8vIFRoZSBjdXJyZW50bHkgZGlzcGxheWVkIGFsZXJ0XG4gICAgcHJpdmF0ZSBhbGVydDogQWxlcnQ7XG4gICAgLy8gSW5kaWNhdGVzIHdoZXRoZXIgd2UgZXZlciBzYXcgYW4gb3V0ZGF0ZWQgc3RhdGUgc2luY2UgbGFzdCByZWxvYWRcbiAgICBwcml2YXRlIGhhc1NlZW5PdXRkYXRlZEluVGhpc1Nlc3Npb24gPSBmYWxzZTtcblxuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwcml2YXRlIGFwcFJlZjogQXBwbGljYXRpb25SZWYsXG4gICAgICAgIHByaXZhdGUgdXBkYXRlczogU3dVcGRhdGUsXG4gICAgICAgIHByaXZhdGUgc2VydmVyRGF0ZVNlcnZpY2U6IEFydGVtaXNTZXJ2ZXJEYXRlU2VydmljZSxcbiAgICAgICAgcHJpdmF0ZSBhbGVydFNlcnZpY2U6IEFsZXJ0U2VydmljZSxcbiAgICAgICAgQEluamVjdChXSU5ET1dfSU5KRUNUT1JfVE9LRU4pIHByaXZhdGUgaW5qZWN0ZWRXaW5kb3c6IFdpbmRvdyxcbiAgICApIHtcbiAgICAgICAgLy8gQWxsb3cgdGhlIGFwcCB0byBzdGFiaWxpemUgZmlyc3QsIGJlZm9yZSBzdGFydGluZ1xuICAgICAgICAvLyBwb2xsaW5nIGZvciB1cGRhdGVzIHdpdGggYGludGVydmFsKClgLlxuICAgICAgICBjb25zdCBhcHBJc1N0YWJsZU9yVGltZW91dCA9IGFwcFJlZi5pc1N0YWJsZS5waXBlKFxuICAgICAgICAgICAgZmlyc3QoKGlzU3RhYmxlKSA9PiBpc1N0YWJsZSA9PT0gdHJ1ZSksXG4gICAgICAgICAgICAvLyBTb21ldGltZXMsIHRoZSBhcHBsaWNhdGlvbiBkb2VzIG5vdCBiZWNvbWUgc3RhYmxlIGFwcGFyZW50bHkuXG4gICAgICAgICAgICAvLyBUaGlzIGlzIGEgd29ya2Fyb3VuZC4gVXNpbmcgdGhlIHNhbWUgdGltZW91dCBhcyB0aGUgc2VydmljZSB3b3JrZXIgYXMgd2VsbC5cbiAgICAgICAgICAgIC8vIFRPRE86IExvb2sgZm9yIHRoZSBjYXVzZSB3aHkgdGhlIGFwcCBkb2Vzbid0IGJlY29tZSBzdGFibGVcbiAgICAgICAgICAgIHRpbWVvdXQoMzAwMDApLFxuICAgICAgICAgICAgLy8gSWdub3JlIGVycm9yIHRocm93biBieSB0aW1lb3V0XG4gICAgICAgICAgICBjYXRjaEVycm9yKCgpID0+IG9mKHRydWUpKSxcbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgdXBkYXRlSW50ZXJ2YWwgPSBpbnRlcnZhbCg2MCAqIDEwMDApOyAvLyBldmVyeSA2MHNcbiAgICAgICAgY29uc3QgdXBkYXRlSW50ZXJ2YWxPbmNlQXBwSXNTdGFibGUkID0gY29uY2F0KGFwcElzU3RhYmxlT3JUaW1lb3V0LCB1cGRhdGVJbnRlcnZhbCk7XG5cbiAgICAgICAgdXBkYXRlSW50ZXJ2YWxPbmNlQXBwSXNTdGFibGUkLnN1YnNjcmliZSgoKSA9PiB0aGlzLmNoZWNrRm9yVXBkYXRlcyhmYWxzZSkpO1xuICAgIH1cblxuICAgIGludGVyY2VwdChyZXF1ZXN0OiBIdHRwUmVxdWVzdDxhbnk+LCBuZXh0SGFuZGxlcjogSHR0cEhhbmRsZXIpOiBPYnNlcnZhYmxlPEh0dHBFdmVudDxhbnk+PiB7XG4gICAgICAgIHJldHVybiBuZXh0SGFuZGxlci5oYW5kbGUocmVxdWVzdCkucGlwZShcbiAgICAgICAgICAgIHRhcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UgaW5zdGFuY2VvZiBIdHRwUmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNUcmFuc2xhdGlvblN0cmluZ3NSZXF1ZXN0ID0gcmVzcG9uc2UudXJsPy5pbmNsdWRlcygnL2kxOG4vJyk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNlcnZlclZlcnNpb24gPSByZXNwb25zZS5oZWFkZXJzLmdldChBUlRFTUlTX1ZFUlNJT05fSEVBREVSKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKFZFUlNJT04gJiYgc2VydmVyVmVyc2lvbiAmJiBWRVJTSU9OICE9PSBzZXJ2ZXJWZXJzaW9uICYmICFpc1RyYW5zbGF0aW9uU3RyaW5nc1JlcXVlc3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFZlcnNpb24gbWlzbWF0Y2ggZGV0ZWN0ZWQgZnJvbSBIVFRQIGhlYWRlcnMuIExldCBTVyBsb29rIGZvciB1cGRhdGVzIVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGVja0ZvclVwZGF0ZXModHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvLyBvbmx5IGludm9rZSB0aGUgdGltZSBjYWxsIGlmIHRoZSBjYWxsIHdhcyBub3QgYWxyZWFkeSB0aGUgdGltZSBjYWxsIHRvIHByZXZlbnQgcmVjdXJzaW9uIGhlcmVcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFyZXF1ZXN0LnVybC5pbmNsdWRlcygndGltZScpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNlcnZlckRhdGVTZXJ2aWNlLnVwZGF0ZVRpbWUoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFRlbGxzIHRoZSBzZXJ2aWNlIHdvcmtlciB0byBjaGVjayBmb3IgdXBkYXRlcyBhbmQgZGlzcGxheSBhbiB1cGRhdGUgYWxlcnQgaWYgYW4gdXBkYXRlIGlzIGF2YWlsYWJsZS5cbiAgICAgKiBUaGlzIGlzIGVpdGhlciBleGFjdGx5IGlmXG4gICAgICogLSB0aGUgc2VydmljZSB3b3JrZXIgZGV0ZWN0cyBhbiB1cGRhdGUgcmlnaHQgbm93LCBvclxuICAgICAqIC0gdGhlIGZpcnN0IGNvbmRpdGlvbiB3YXMgZXZlciB0cnVlIHNpbmNlIHRoZSBhcHAgbG9hZGVkIChha2EgbGFzdCByZWxvYWQpXG4gICAgICpcbiAgICAgKiBXZSBuZWVkIHRvIGhhdmUgdGhpcyBzZWNvbmQgb3B0aW9uIGJlY2F1c2UgdGhlIFwiY2hlY2tGb3JVcGRhdGUoKVwiIGNhbGwgc29tZXRpbWVzIHN0YXJ0cyB0byByZXR1cm4gZmFsc2UgYWZ0ZXIgYSB3aGlsZSwgZXZlbiB0aG91Z2ggd2UgZGlkbid0IHJlbG9hZCAvIHVwZGF0ZSB5ZXQuXG4gICAgICogQW5kIGlmIHNlcnZpY2Ugd29ya2VycyBhcmUgbm90IGF2YWlsYWJsZSB3ZSBjYW4ndCBhY3R1YWxseSBjaGVjayBmb3IgdXBkYXRlcywgc28gd2UgaGF2ZSB0byByZWx5IG9uIGV2ZXIgaGF2aW5nIHNlZW4gYSBkaWZmZXJlbnQgdmVyc2lvbiBudW1iZXIgaW4gYSByZXF1ZXN0XG4gICAgICpcbiAgICAgKiBAcGFyYW0gaGFzVXBkYXRlIGlmIGl0IGlzIGtub3duIHRoYXQgdGhlcmUgaXMgYW4gdXBkYXRlLCBvbmx5IHJlbGV2YW50IGlmIHNlcnZpY2Ugd29ya2VycyBhcmUgbm90IGF2YWlsYWJsZVxuICAgICAqL1xuICAgIHByaXZhdGUgY2hlY2tGb3JVcGRhdGVzKGhhc1VwZGF0ZTogYm9vbGVhbikge1xuICAgICAgICAvLyBkb24ndCBzcGFtIGVycm9ycyB3aGVuIHNlcnZpY2Ugd29ya2VycyBhcmUgbm90IGF2YWlsYWJsZSwgaW5zdGVhZCByZWx5IG9uIHRoZSBDb250ZW50LVZlcnNpb24gaGVhZGVyIG9mIHJlc3BvbnNlc1xuICAgICAgICBjb25zdCB1cGRhdGUgPSB0aGlzLnVwZGF0ZXMuaXNFbmFibGVkID8gdGhpcy51cGRhdGVzLmNoZWNrRm9yVXBkYXRlKCkgOiBQcm9taXNlLnJlc29sdmUoaGFzVXBkYXRlKTtcblxuICAgICAgICAvLyBmaXJzdCB1cGRhdGUgdGhlIHNlcnZpY2Ugd29ya2VyXG4gICAgICAgIHVwZGF0ZS50aGVuKCh1cGRhdGVBdmFpbGFibGU6IGJvb2xlYW4pID0+IHtcbiAgICAgICAgICAgIGlmICh0aGlzLmhhc1NlZW5PdXRkYXRlZEluVGhpc1Nlc3Npb24gfHwgdXBkYXRlQXZhaWxhYmxlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5oYXNTZWVuT3V0ZGF0ZWRJblRoaXNTZXNzaW9uID0gdHJ1ZTtcblxuICAgICAgICAgICAgICAgIC8vIElmIHdlIGhhdmVuJ3Qgc2hvd24gYW4gYWxlcnQgeWV0IG9yIHRoZSBhbGVydCBoYXMgYmVlbiBjbG9zZWQ6IFNwYXduIG5ldyBhbGVydFxuICAgICAgICAgICAgICAgIGlmICghdGhpcy5hbGVydD8uaXNPcGVuKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWxlcnQgPSB0aGlzLmFsZXJ0U2VydmljZS5hZGRBbGVydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBBbGVydFR5cGUuSU5GTyxcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICdhcnRlbWlzQXBwLm91dGRhdGVkQWxlcnQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGltZW91dDogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnYXJ0ZW1pc0FwcC5vdXRkYXRlZEFjdGlvbicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2s6ICgpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFwcGx5IHRoZSB1cGRhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy51cGRhdGVzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuYWN0aXZhdGVVcGRhdGUoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSWdub3JlIGFueSBlcnJvci4gQW55IGVycm9yIGhhcHBlbmluZyBoZXJlIGRvZXNuJ3QgbWF0dGVyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBJZiB3ZSByZWFjaCB0aGlzIHBvaW50LCB3ZSB3YW50IHRvIGxvYWQgYW4gdXBkYXRlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBzbyBpbiBhbnkgY2FzZSwgd2Ugc2hvdWxkIHJlbG9hZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKCgpID0+IHt9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVsb2FkIHRoZSBwYWdlIHdpdGggdGhlIG5ldyB2ZXJzaW9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbigoKSA9PiB0aGlzLmluamVjdGVkV2luZG93LmxvY2F0aW9uLnJlbG9hZCgpKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IGRheWpzIGZyb20gJ2RheWpzL2VzbSc7XG5pbXBvcnQgY3VzdG9tUGFyc2VGb3JtYXQgZnJvbSAnZGF5anMvZXNtL3BsdWdpbi9jdXN0b21QYXJzZUZvcm1hdCc7XG5pbXBvcnQgZHVyYXRpb24gZnJvbSAnZGF5anMvZXNtL3BsdWdpbi9kdXJhdGlvbic7XG5pbXBvcnQgcmVsYXRpdmVUaW1lIGZyb20gJ2RheWpzL2VzbS9wbHVnaW4vcmVsYXRpdmVUaW1lJztcbmltcG9ydCBpc29XZWVrIGZyb20gJ2RheWpzL2VzbS9wbHVnaW4vaXNvV2Vlayc7XG5pbXBvcnQgdXRjIGZyb20gJ2RheWpzL2VzbS9wbHVnaW4vdXRjJztcbmltcG9ydCBpc1NhbWVPckJlZm9yZSBmcm9tICdkYXlqcy9lc20vcGx1Z2luL2lzU2FtZU9yQmVmb3JlJztcbmltcG9ydCBpc1NhbWVPckFmdGVyIGZyb20gJ2RheWpzL2VzbS9wbHVnaW4vaXNTYW1lT3JBZnRlcic7XG5pbXBvcnQgaXNCZXR3ZWVuIGZyb20gJ2RheWpzL2VzbS9wbHVnaW4vaXNCZXR3ZWVuJztcbmltcG9ydCBtaW5NYXggZnJvbSAnZGF5anMvZXNtL3BsdWdpbi9taW5NYXgnO1xuaW1wb3J0IGxvY2FsaXplZEZvcm1hdCBmcm9tICdkYXlqcy9lc20vcGx1Z2luL2xvY2FsaXplZEZvcm1hdCc7XG5pbXBvcnQgaXNvV2Vla3NJblllYXIgZnJvbSAnZGF5anMvZXNtL3BsdWdpbi9pc29XZWVrc0luWWVhcic7XG5pbXBvcnQgaXNMZWFwWWVhciBmcm9tICdkYXlqcy9lc20vcGx1Z2luL2lzTGVhcFllYXInO1xuaW1wb3J0IHRpbWV6b25lIGZyb20gJ2RheWpzL2VzbS9wbHVnaW4vdGltZXpvbmUnO1xuXG5pbXBvcnQgJ2RheWpzL2VzbS9sb2NhbGUvZW4nO1xuaW1wb3J0ICdkYXlqcy9lc20vbG9jYWxlL2RlJztcblxuZGF5anMuZXh0ZW5kKGN1c3RvbVBhcnNlRm9ybWF0KTtcbmRheWpzLmV4dGVuZChkdXJhdGlvbik7XG5kYXlqcy5leHRlbmQocmVsYXRpdmVUaW1lKTtcbmRheWpzLmV4dGVuZChpc29XZWVrKTtcbmRheWpzLmV4dGVuZCh1dGMpO1xuZGF5anMuZXh0ZW5kKGlzU2FtZU9yQmVmb3JlKTtcbmRheWpzLmV4dGVuZChpc1NhbWVPckFmdGVyKTtcbmRheWpzLmV4dGVuZChpc0JldHdlZW4pO1xuZGF5anMuZXh0ZW5kKG1pbk1heCk7XG5kYXlqcy5leHRlbmQobG9jYWxpemVkRm9ybWF0KTtcbmRheWpzLmV4dGVuZChpc29XZWVrc0luWWVhcik7XG5kYXlqcy5leHRlbmQoaXNMZWFwWWVhcik7XG5kYXlqcy5leHRlbmQodGltZXpvbmUpO1xuIiwiLyoqXG4gKiBBbmd1bGFyIGJvb3RzdHJhcCBEYXRlIGFkYXB0ZXJcbiAqL1xuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmdiRGF0ZUFkYXB0ZXIsIE5nYkRhdGVTdHJ1Y3QgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XG5pbXBvcnQgZGF5anMgZnJvbSAnZGF5anMvZXNtJztcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIE5nYkRhdGVEYXlqc0FkYXB0ZXIgZXh0ZW5kcyBOZ2JEYXRlQWRhcHRlcjxkYXlqcy5EYXlqcz4ge1xuICAgIGZyb21Nb2RlbChkYXRlOiBkYXlqcy5EYXlqcyB8IG51bGwpOiBOZ2JEYXRlU3RydWN0IHwgbnVsbCB7XG4gICAgICAgIGlmIChkYXRlICYmIGRheWpzLmlzRGF5anMoZGF0ZSkgJiYgZGF0ZS5pc1ZhbGlkKCkpIHtcbiAgICAgICAgICAgIHJldHVybiB7IHllYXI6IGRhdGUueWVhcigpLCBtb250aDogZGF0ZS5tb250aCgpICsgMSwgZGF5OiBkYXRlLmRhdGUoKSB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIHRvTW9kZWwoZGF0ZTogTmdiRGF0ZVN0cnVjdCB8IG51bGwpOiBkYXlqcy5EYXlqcyB8IG51bGwge1xuICAgICAgICByZXR1cm4gZGF0ZSA/IGRheWpzKGAke2RhdGUueWVhcn0tJHtkYXRlLm1vbnRofS0ke2RhdGUuZGF5fWApIDogbnVsbDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBBUFBfSU5JVElBTElaRVIsIEVycm9ySGFuZGxlciwgTE9DQUxFX0lELCBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRGF0ZVBpcGUsIHJlZ2lzdGVyTG9jYWxlRGF0YSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBIVFRQX0lOVEVSQ0VQVE9SUywgSHR0cENsaWVudCwgSHR0cENsaWVudE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IFRpdGxlIH0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlcic7XG5pbXBvcnQgeyBBdXRoRXhwaXJlZEludGVyY2VwdG9yIH0gZnJvbSAnYXBwL2NvcmUvaW50ZXJjZXB0b3IvYXV0aC1leHBpcmVkLmludGVyY2VwdG9yJztcbmltcG9ydCB7IEVycm9ySGFuZGxlckludGVyY2VwdG9yIH0gZnJvbSAnYXBwL2NvcmUvaW50ZXJjZXB0b3IvZXJyb3JoYW5kbGVyLmludGVyY2VwdG9yJztcbmltcG9ydCB7IE5vdGlmaWNhdGlvbkludGVyY2VwdG9yIH0gZnJvbSAnYXBwL2NvcmUvaW50ZXJjZXB0b3Ivbm90aWZpY2F0aW9uLmludGVyY2VwdG9yJztcbmltcG9ydCB7IE5nYkRhdGVBZGFwdGVyLCBOZ2JEYXRlcGlja2VyQ29uZmlnLCBOZ2JUb29sdGlwQ29uZmlnIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xuaW1wb3J0IHsgTmd4V2Vic3RvcmFnZU1vZHVsZSwgU2Vzc2lvblN0b3JhZ2VTZXJ2aWNlIH0gZnJvbSAnbmd4LXdlYnN0b3JhZ2UnO1xuaW1wb3J0IGxvY2FsZSBmcm9tICdAYW5ndWxhci9jb21tb24vbG9jYWxlcy9lbic7XG5pbXBvcnQgeyBNaXNzaW5nVHJhbnNsYXRpb25IYW5kbGVyLCBUcmFuc2xhdGVMb2FkZXIsIFRyYW5zbGF0ZU1vZHVsZSwgVHJhbnNsYXRlU2VydmljZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xuaW1wb3J0IHsgU2VudHJ5RXJyb3JIYW5kbGVyIH0gZnJvbSAnYXBwL2NvcmUvc2VudHJ5L3NlbnRyeS5lcnJvci1oYW5kbGVyJztcbmltcG9ydCB7IExvYWRpbmdOb3RpZmljYXRpb25JbnRlcmNlcHRvciB9IGZyb20gJ2FwcC9zaGFyZWQvbm90aWZpY2F0aW9uL2xvYWRpbmctbm90aWZpY2F0aW9uL2xvYWRpbmctbm90aWZpY2F0aW9uLmludGVyY2VwdG9yJztcbmltcG9ydCB7IEJyb3dzZXJGaW5nZXJwcmludEludGVyY2VwdG9yIH0gZnJvbSAnYXBwL2NvcmUvaW50ZXJjZXB0b3IvYnJvd3Nlci1maW5nZXJwcmludC5pbnRlcmNlcHRvci5zZXJ2aWNlJztcbmltcG9ydCB7IEFydGVtaXNWZXJzaW9uSW50ZXJjZXB0b3IsIFdJTkRPV19JTkpFQ1RPUl9UT0tFTiB9IGZyb20gJ2FwcC9jb3JlL2ludGVyY2VwdG9yL2FydGVtaXMtdmVyc2lvbi5pbnRlcmNlcHRvcic7XG5pbXBvcnQgeyBtaXNzaW5nVHJhbnNsYXRpb25IYW5kbGVyLCB0cmFuc2xhdGVQYXJ0aWFsTG9hZGVyIH0gZnJvbSAnLi9jb25maWcvdHJhbnNsYXRpb24uY29uZmlnJztcbmltcG9ydCBkYXlqcyBmcm9tICdkYXlqcy9lc20nO1xuaW1wb3J0ICcuL2NvbmZpZy9kYXlqcyc7XG5pbXBvcnQgeyBOZ2JEYXRlRGF5anNBZGFwdGVyIH0gZnJvbSAnYXBwL2NvcmUvY29uZmlnL2RhdGVwaWNrZXItYWRhcHRlcic7XG5pbXBvcnQgeyBKaGlMYW5ndWFnZUhlbHBlciB9IGZyb20gJ2FwcC9jb3JlL2xhbmd1YWdlL2xhbmd1YWdlLmhlbHBlcic7XG5pbXBvcnQgeyBUcmFjZVNlcnZpY2UgfSBmcm9tICdAc2VudHJ5L2FuZ3VsYXItaXZ5JztcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW1xuICAgICAgICBIdHRwQ2xpZW50TW9kdWxlLFxuICAgICAgICBOZ3hXZWJzdG9yYWdlTW9kdWxlLmZvclJvb3QoeyBwcmVmaXg6ICdqaGknLCBzZXBhcmF0b3I6ICctJyB9KSxcbiAgICAgICAgVHJhbnNsYXRlTW9kdWxlLmZvclJvb3Qoe1xuICAgICAgICAgICAgbG9hZGVyOiB7XG4gICAgICAgICAgICAgICAgcHJvdmlkZTogVHJhbnNsYXRlTG9hZGVyLFxuICAgICAgICAgICAgICAgIHVzZUZhY3Rvcnk6IHRyYW5zbGF0ZVBhcnRpYWxMb2FkZXIsXG4gICAgICAgICAgICAgICAgZGVwczogW0h0dHBDbGllbnRdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG1pc3NpbmdUcmFuc2xhdGlvbkhhbmRsZXI6IHtcbiAgICAgICAgICAgICAgICBwcm92aWRlOiBNaXNzaW5nVHJhbnNsYXRpb25IYW5kbGVyLFxuICAgICAgICAgICAgICAgIHVzZUZhY3Rvcnk6IG1pc3NpbmdUcmFuc2xhdGlvbkhhbmRsZXIsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KSxcbiAgICBdLFxuICAgIHByb3ZpZGVyczogW1xuICAgICAgICBUaXRsZSxcbiAgICAgICAge1xuICAgICAgICAgICAgcHJvdmlkZTogTE9DQUxFX0lELFxuICAgICAgICAgICAgdXNlVmFsdWU6ICdlbicsXG4gICAgICAgIH0sXG4gICAgICAgIHsgcHJvdmlkZTogTmdiRGF0ZUFkYXB0ZXIsIHVzZUNsYXNzOiBOZ2JEYXRlRGF5anNBZGFwdGVyIH0sXG4gICAgICAgIHsgcHJvdmlkZTogVHJhY2VTZXJ2aWNlLCBkZXBzOiBbUm91dGVyXSB9LFxuICAgICAgICB7IHByb3ZpZGU6IEVycm9ySGFuZGxlciwgdXNlQ2xhc3M6IFNlbnRyeUVycm9ySGFuZGxlciB9LFxuICAgICAgICB7IHByb3ZpZGU6IFdJTkRPV19JTkpFQ1RPUl9UT0tFTiwgdXNlVmFsdWU6IHdpbmRvdyB9LFxuICAgICAgICBEYXRlUGlwZSxcbiAgICAgICAge1xuICAgICAgICAgICAgcHJvdmlkZTogQVBQX0lOSVRJQUxJWkVSLFxuICAgICAgICAgICAgdXNlRmFjdG9yeTogKCkgPT4gKCkgPT4ge30sXG4gICAgICAgICAgICBkZXBzOiBbVHJhY2VTZXJ2aWNlXSxcbiAgICAgICAgICAgIG11bHRpOiB0cnVlLFxuICAgICAgICB9LFxuICAgICAgICAvKipcbiAgICAgICAgICogQGRlc2NyaXB0aW9uIEludGVyY2VwdG9yIGRlY2xhcmF0aW9uczpcbiAgICAgICAgICogSW50ZXJjZXB0b3JzIGFyZSBsb2NhdGVkIGF0ICdibG9ja3MvaW50ZXJjZXB0b3IvLlxuICAgICAgICAgKiBBbGwgb2YgdGhlbSBpbXBsZW1lbnQgdGhlIEh0dHBJbnRlcmNlcHRvciBpbnRlcmZhY2UuXG4gICAgICAgICAqIFRoZXkgY2FuIGJlIHVzZWQgdG8gbW9kaWZ5IEFQSSBjYWxscyBvciB0cmlnZ2VyIGFkZGl0aW9uYWwgZnVuY3Rpb24gY2FsbHMuXG4gICAgICAgICAqIE1vc3QgaW50ZXJjZXB0b3JzIHdpbGwgdHJhbnNmb3JtIHRoZSBvdXRnb2luZyByZXF1ZXN0IGJlZm9yZSBwYXNzaW5nIGl0IHRvXG4gICAgICAgICAqIHRoZSBuZXh0IGludGVyY2VwdG9yIGluIHRoZSBjaGFpbiwgYnkgY2FsbGluZyBuZXh0LmhhbmRsZSh0cmFuc2Zvcm1lZFJlcSkuXG4gICAgICAgICAqIERvY3VtZW50YXRpb246IGh0dHBzOi8vYW5ndWxhci5pby9hcGkvY29tbW9uL2h0dHAvSHR0cEludGVyY2VwdG9yXG4gICAgICAgICAqL1xuICAgICAgICB7XG4gICAgICAgICAgICBwcm92aWRlOiBIVFRQX0lOVEVSQ0VQVE9SUyxcbiAgICAgICAgICAgIHVzZUNsYXNzOiBBdXRoRXhwaXJlZEludGVyY2VwdG9yLFxuICAgICAgICAgICAgbXVsdGk6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIHByb3ZpZGU6IEhUVFBfSU5URVJDRVBUT1JTLFxuICAgICAgICAgICAgdXNlQ2xhc3M6IEVycm9ySGFuZGxlckludGVyY2VwdG9yLFxuICAgICAgICAgICAgbXVsdGk6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIHByb3ZpZGU6IEhUVFBfSU5URVJDRVBUT1JTLFxuICAgICAgICAgICAgdXNlQ2xhc3M6IEJyb3dzZXJGaW5nZXJwcmludEludGVyY2VwdG9yLFxuICAgICAgICAgICAgbXVsdGk6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIHByb3ZpZGU6IEhUVFBfSU5URVJDRVBUT1JTLFxuICAgICAgICAgICAgdXNlQ2xhc3M6IE5vdGlmaWNhdGlvbkludGVyY2VwdG9yLFxuICAgICAgICAgICAgbXVsdGk6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIHByb3ZpZGU6IEhUVFBfSU5URVJDRVBUT1JTLFxuICAgICAgICAgICAgdXNlQ2xhc3M6IExvYWRpbmdOb3RpZmljYXRpb25JbnRlcmNlcHRvcixcbiAgICAgICAgICAgIG11bHRpOiB0cnVlLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICBwcm92aWRlOiBIVFRQX0lOVEVSQ0VQVE9SUyxcbiAgICAgICAgICAgIHVzZUNsYXNzOiBBcnRlbWlzVmVyc2lvbkludGVyY2VwdG9yLFxuICAgICAgICAgICAgbXVsdGk6IHRydWUsXG4gICAgICAgIH0sXG4gICAgXSxcbn0pXG5leHBvcnQgY2xhc3MgQXJ0ZW1pc0NvcmVNb2R1bGUge1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBkcENvbmZpZzogTmdiRGF0ZXBpY2tlckNvbmZpZyxcbiAgICAgICAgdG9vbHRpcENvbmZpZzogTmdiVG9vbHRpcENvbmZpZyxcbiAgICAgICAgdHJhbnNsYXRlU2VydmljZTogVHJhbnNsYXRlU2VydmljZSxcbiAgICAgICAgbGFuZ3VhZ2VIZWxwZXI6IEpoaUxhbmd1YWdlSGVscGVyLFxuICAgICAgICBzZXNzaW9uU3RvcmFnZVNlcnZpY2U6IFNlc3Npb25TdG9yYWdlU2VydmljZSxcbiAgICApIHtcbiAgICAgICAgcmVnaXN0ZXJMb2NhbGVEYXRhKGxvY2FsZSk7XG4gICAgICAgIGRwQ29uZmlnLm1pbkRhdGUgPSB7IHllYXI6IGRheWpzKCkuc3VidHJhY3QoMTAwLCAneWVhcicpLnllYXIoKSwgbW9udGg6IDEsIGRheTogMSB9O1xuICAgICAgICB0cmFuc2xhdGVTZXJ2aWNlLnNldERlZmF1bHRMYW5nKCdlbicpO1xuICAgICAgICBjb25zdCBsYW5ndWFnZUtleSA9IHNlc3Npb25TdG9yYWdlU2VydmljZS5yZXRyaWV2ZSgnbG9jYWxlJykgfHwgbGFuZ3VhZ2VIZWxwZXIuZGV0ZXJtaW5lUHJlZmVycmVkTGFuZ3VhZ2UoKTtcbiAgICAgICAgdHJhbnNsYXRlU2VydmljZS51c2UobGFuZ3VhZ2VLZXkpO1xuICAgICAgICB0b29sdGlwQ29uZmlnLmNvbnRhaW5lciA9ICdib2R5JztcbiAgICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBcUIsVUFBVTtBQUMvQixTQUFTLHFCQUFxQiw2QkFBNkI7Ozs7QUFIM0QsSUFxQmE7QUFyQmI7O0FBcUJNLElBQU8scUJBQVAsTUFBTyxvQkFBa0I7TUFFZjtNQUNBO01BQ0E7TUFIWixZQUNZLE1BQ0EsY0FDQSxnQkFBcUM7QUFGckMsYUFBQSxPQUFBO0FBQ0EsYUFBQSxlQUFBO0FBQ0EsYUFBQSxpQkFBQTtNQUNUO01BRUgsTUFBTSxhQUF3QjtBQUMxQixlQUFPLEtBQUssS0FBSyxLQUFLLDJCQUEyQixXQUFXO01BQ2hFO01BRUEsV0FBVyxZQUFtQjtBQUMxQixlQUFPLEtBQUssS0FBSyxLQUFLLG9CQUFvQixXQUFXLFNBQVEsQ0FBRTtNQUNuRTtNQUVBLFNBQU07QUFDRixlQUFPLEtBQUssS0FBSyxLQUFLLHFCQUFxQixJQUFJO01BQ25EO01BS0EsY0FBVztBQUNQLGFBQUssYUFBYSxNQUFLO0FBQ3ZCLGFBQUssZUFBZSxNQUFLO0FBRXpCLGVBQU8sR0FBRyxNQUFTO01BQ3ZCOzt5QkEzQlMscUJBQWtCLHNCQUFBLGFBQUEsR0FBQSxzQkFBQSxzQkFBQSxHQUFBLHNCQUFBLHdCQUFBLENBQUE7TUFBQTttRUFBbEIscUJBQWtCLFNBQWxCLG9CQUFrQixXQUFBLFlBREwsT0FBTSxDQUFBOzs7Ozs7QUNwQmhDLFNBQVMsY0FBQUEsbUJBQWtCO0FBRTNCLFNBQVMsY0FBYztBQUN2QixTQUFTLGdCQUFnQjs7O0FBSHpCLElBU2E7QUFUYjs7QUFDQTtBQUlBO0FBQ0E7Ozs7QUFHTSxJQUFPLGVBQVAsTUFBTyxjQUFZO01BSVQ7TUFDQTtNQUNBO01BQ0E7TUFOWixvQkFBb0I7TUFFcEIsWUFDWSxnQkFDQSxvQkFDQSxRQUNBLGNBQTBCO0FBSDFCLGFBQUEsaUJBQUE7QUFDQSxhQUFBLHFCQUFBO0FBQ0EsYUFBQSxTQUFBO0FBQ0EsYUFBQSxlQUFBO01BQ1Q7TUFNSCxNQUFNLGFBQXdCO0FBQzFCLGVBQU8sSUFBSSxRQUFjLENBQUMsU0FBUyxXQUFVO0FBQ3pDLGVBQUssbUJBQW1CLE1BQU0sV0FBVyxFQUFFLFVBQVU7WUFDakQsTUFBTSxNQUFLO0FBQ1AsbUJBQUssZUFBZSxTQUFTLElBQUksRUFBRSxLQUFLLE1BQUs7QUFDekMsd0JBQU87Y0FDWCxDQUFDO1lBQ0w7WUFDQSxPQUFPLENBQUMsUUFBTztBQUNYLG1CQUFLLE9BQU8sS0FBSztBQUNqQixxQkFBTyxHQUFHO1lBQ2Q7V0FDSDtRQUNMLENBQUM7TUFDTDtNQU1BLFdBQVcsWUFBbUI7QUFDMUIsZUFBTyxJQUFJLFFBQWMsQ0FBQyxTQUFTLFdBQVU7QUFDekMsZUFBSyxtQkFBbUIsV0FBVyxVQUFVLEVBQUUsVUFBVTtZQUNyRCxNQUFNLE1BQUs7QUFDUCxtQkFBSyxlQUFlLFNBQVMsSUFBSSxFQUFFLEtBQUssTUFBSztBQUN6Qyx3QkFBTztjQUNYLENBQUM7WUFDTDtZQUNBLE9BQU8sQ0FBQyxRQUFPO0FBQ1gsbUJBQUssT0FBTyxLQUFLO0FBQ2pCLHFCQUFPLEdBQUc7WUFDZDtXQUNIO1FBQ0wsQ0FBQztNQUNMO01BT0EsT0FBTyxvQkFBMkI7QUFDOUIsYUFBSyxvQkFBb0IsQ0FBQztBQUUxQixZQUFJLG9CQUFvQjtBQUNwQixlQUFLLG1CQUNBLE9BQU0sRUFDTixLQUNHLFNBQVMsTUFBSztBQUNWLGlCQUFLLFNBQVE7VUFDakIsQ0FBQyxDQUFDLEVBRUwsVUFBUztlQUNYO0FBQ0gsZUFBSyxTQUFROztNQUVyQjtNQUVRLFdBQVE7QUFDWixhQUFLLGVBQWUsYUFBYSxNQUFTO0FBQzFDLGFBQUssYUFBYSxTQUFRO0FBQzFCLGFBQUssT0FBTyxjQUFjLEdBQUc7TUFDakM7TUFFQSx3QkFBcUI7QUFDakIsZUFBTyxLQUFLO01BQ2hCOzt5QkFoRlMsZUFBWSx1QkFBQSxjQUFBLEdBQUEsdUJBQUEsa0JBQUEsR0FBQSx1QkFBQSxTQUFBLEdBQUEsdUJBQUEsWUFBQSxDQUFBO01BQUE7b0VBQVosZUFBWSxTQUFaLGNBQVksV0FBQSxZQURDLE9BQU0sQ0FBQTs7Ozs7O0FDUmhDLFNBQVMsY0FBQUMsbUJBQWtCO0FBQzNCLFNBQVMseUJBQStFO0FBRXhGLFNBQVMsV0FBVztBQUdwQixTQUFTLFVBQUFDLGVBQWM7OztBQU52QixJQVVhO0FBVmI7O0FBSUE7QUFDQTtBQUVBOzs7O0FBR00sSUFBTyx5QkFBUCxNQUFPLHdCQUFzQjtNQUVuQjtNQUNBO01BQ0E7TUFDQTtNQUpaLFlBQ1ksY0FDQSxxQkFDQSxRQUNBLGdCQUE4QjtBQUg5QixhQUFBLGVBQUE7QUFDQSxhQUFBLHNCQUFBO0FBQ0EsYUFBQSxTQUFBO0FBQ0EsYUFBQSxpQkFBQTtNQUNUO01BU0gsVUFBVSxTQUEyQixNQUFpQjtBQUNsRCxlQUFPLEtBQUssT0FBTyxPQUFPLEVBQUUsS0FDeEIsSUFBSTtVQUNBLE9BQU8sQ0FBQyxRQUFZO0FBQ2hCLGdCQUFJLGVBQWUsbUJBQW1CO0FBQ2xDLGtCQUFJLElBQUksV0FBVyxPQUFPLEtBQUssZUFBZSxnQkFBZSxHQUFJO0FBRTdELHNCQUFNLGFBQWEsS0FBSyxPQUFPLFlBQVksU0FBUztBQUNwRCxxQkFBSyxhQUFhLE9BQU8sS0FBSztBQU05QixxQkFBSyxvQkFBb0IsU0FBUyxVQUFVOzs7VUFHeEQ7U0FDSCxDQUFDO01BRVY7O3lCQW5DUyx5QkFBc0IsdUJBQUEsWUFBQSxHQUFBLHVCQUFBLG1CQUFBLEdBQUEsdUJBQUEsVUFBQSxHQUFBLHVCQUFBLGNBQUEsQ0FBQTtNQUFBO29FQUF0Qix5QkFBc0IsU0FBdEIsd0JBQXNCLFVBQUEsQ0FBQTs7Ozs7O0FDVm5DLFNBQVMsY0FBQUMsbUJBQWtCO0FBQzNCLFNBQVMscUJBQUFDLDBCQUErRTtBQUV4RixTQUFTLE9BQUFDLFlBQVc7O0FBSHBCLElBUWE7QUFSYjs7QUFJQTtBQUNBOzs7QUFHTSxJQUFPLDBCQUFQLE1BQU8seUJBQXVCO01BRXBCO01BQ0E7TUFGWixZQUNZLGNBQ0EsZ0JBQThCO0FBRDlCLGFBQUEsZUFBQTtBQUNBLGFBQUEsaUJBQUE7TUFDVDtNQVVILFVBQVUsU0FBMkIsTUFBaUI7QUFDbEQsZUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLEtBQ3hCQSxLQUFJO1VBQ0EsT0FBTyxDQUFDLFFBQVk7QUFDaEIsZ0JBQUksZUFBZUQsb0JBQW1CO0FBQ2xDLGtCQUFJLEVBQUUsSUFBSSxXQUFXLE9BQU8sQ0FBQyxLQUFLLGVBQWUsZ0JBQWUsSUFBSztBQUNqRSxxQkFBSyxhQUFhLFVBQVUsRUFBRSxNQUFNLHdCQUF3QixTQUFTLElBQUcsQ0FBRTs7O1VBR3RGO1NBQ0gsQ0FBQztNQUVWOzt5QkExQlMsMEJBQXVCLHVCQUFBLFlBQUEsR0FBQSx1QkFBQSxjQUFBLENBQUE7TUFBQTtvRUFBdkIsMEJBQXVCLFNBQXZCLHlCQUF1QixVQUFBLENBQUE7Ozs7OztBQ1JwQyxTQUErRCxvQkFBb0I7QUFDbkYsU0FBUyxjQUFBRSxtQkFBa0I7QUFFM0IsU0FBUyxPQUFBQyxZQUFXOztBQUhwQixJQU9hO0FBUGI7O0FBSUE7O0FBR00sSUFBTywwQkFBUCxNQUFPLHlCQUF1QjtNQUNaO01BQXBCLFlBQW9CLGNBQTBCO0FBQTFCLGFBQUEsZUFBQTtNQUE2QjtNQVVqRCxVQUFVLFNBQTJCLE1BQWlCO0FBQ2xELGVBQU8sS0FBSyxPQUFPLE9BQU8sRUFBRSxLQUN4QkEsS0FBSSxDQUFDLFVBQXlCO0FBQzFCLGNBQUksaUJBQWlCLGNBQWM7QUFDL0IsZ0JBQUksUUFBdUI7QUFDM0IsZ0JBQUksY0FBNkI7QUFFakMsa0JBQU0sUUFBUSxLQUFJLEVBQUcsUUFBUSxDQUFDLFVBQVM7QUFDbkMsa0JBQUksTUFBTSxZQUFXLEVBQUcsU0FBUyxXQUFXLEdBQUc7QUFDM0Msd0JBQVEsTUFBTSxRQUFRLElBQUksS0FBSzt5QkFDeEIsTUFBTSxZQUFXLEVBQUcsU0FBUyxZQUFZLEdBQUc7QUFDbkQsOEJBQWMsbUJBQW1CLE1BQU0sUUFBUSxJQUFJLEtBQUssRUFBRyxRQUFRLE9BQU8sR0FBRyxDQUFDOztZQUV0RixDQUFDO0FBRUQsZ0JBQUksT0FBTztBQUNQLG1CQUFLLGFBQWEsUUFBUSxPQUFPLEVBQUUsT0FBTyxZQUFXLENBQUU7OztRQUduRSxDQUFDLENBQUM7TUFFVjs7eUJBaENTLDBCQUF1Qix1QkFBQSxZQUFBLENBQUE7TUFBQTtvRUFBdkIsMEJBQXVCLFNBQXZCLHlCQUF1QixVQUFBLENBQUE7Ozs7OztBQ3VDcEMsU0FBUyxpQkFBaUIsT0FBWTtBQUVsQyxNQUFJLGdCQUFnQixNQUFNLFdBQVc7QUFHckMsUUFBTSxZQUFZLE1BQU0sV0FBVyxTQUFTLENBQUM7QUFDN0MsTUFBSSxXQUFXO0FBQ1gscUJBQWlCLFVBQVUsUUFBUTtBQUNuQyxxQkFBaUIsVUFBVSxTQUFTOztBQUl4QyxRQUFNLFNBQVMsV0FBVyxZQUFZO0FBQ3RDLE1BQUksUUFBUTtBQUNSLFdBQU8sUUFBUSxDQUFDLFVBQVcsaUJBQWlCLE1BQU0sWUFBWSxFQUFHO0FBQ2pFLFdBQU8sUUFBUSxDQUFDLFVBQVcsaUJBQWlCLE1BQU0sVUFBVSxFQUFHOztBQUduRSxTQUFPLFFBQVEsYUFBYTtBQUNoQztBQS9EQSxJQUVhO0FBRmI7OztBQUVNLElBQU8scUJBQVAsTUFBTyxvQkFBa0I7TUFDcEIsT0FBTyxLQUFLO01BQ1osT0FBZSxvQkFBbUI7TUFFakMsc0JBQWdDLENBQUE7TUFFakMsVUFBVSx5QkFBNkQsZUFBd0I7QUFDbEcsZ0NBQXdCLENBQUMsaUJBQXVCO0FBQzVDLGdCQUFNLE9BQU8sY0FBYSxFQUFHLGVBQWUsbUJBQWtCO0FBQzlELGNBQUksTUFBTTtBQUVOLGdCQUFJO0FBRUEsb0JBQU0sWUFBWSxpQkFBaUIsWUFBWTtBQUMvQyxrQkFBSSxLQUFLLG9CQUFvQixTQUFTLFNBQVMsR0FBRztBQUM5Qyx1QkFBTztxQkFDSjtBQUVILHFCQUFLLG9CQUFvQixLQUFLLFNBQVM7QUFDdkMsMkJBQ0ksTUFBSztBQUNELHdCQUFNLFFBQVEsS0FBSyxvQkFBb0IsUUFBUSxTQUFTO0FBQ3hELHNCQUFJLFNBQVMsR0FBRztBQUNaLHlCQUFLLG9CQUFvQixPQUFPLE9BQU8sQ0FBQzs7Z0JBRWhELEdBQ0EsSUFBSSxLQUFLLEdBQUk7O3FCQUdoQixHQUFHO0FBQ1Isc0JBQVEsTUFBTSxDQUFDOzs7QUFHdkIsaUJBQU87UUFDWCxDQUFDO01BQ0w7Ozs7OztBQ3ZDSixTQUFTLGNBQWMsY0FBQUMsbUJBQWtCO0FBQ3pDLFNBQVMsa0JBQWtCLE1BQU0sZ0NBQWdDO0FBQ2pFLFNBQVMsc0JBQXNCOztBQUYvQixJQVFhO0FBUmI7O0FBR0E7QUFFQTtBQUdNLElBQU8scUJBQVAsTUFBTyw0QkFBMkIsYUFBWTtNQUN4QztNQU1LLFdBQVcsYUFBd0I7O0FBQzVDLGNBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxRQUFRO0FBQ3JDOztBQUdKLGNBQUksWUFBWSxjQUFjLFFBQVc7QUFDckMsZ0JBQUksWUFBWSxZQUFZO0FBQ3hCLG1CQUFLLGNBQWM7bUJBQ2hCO0FBQ0gsbUJBQUssY0FBYzs7aUJBRXBCO0FBQ0gsaUJBQUssY0FBYzs7QUFHdkIsZUFBSztZQUNELEtBQUssWUFBWSxPQUFPO1lBQ3hCLFNBQVM7WUFDVCxhQUFhLEtBQUs7WUFDbEIsY0FBYyxDQUFDLGlCQUFnQjtBQUMzQiwyQkFBYSxLQUFLLElBQUksbUJBQWtCLENBQUU7QUFDMUMsa0JBQUksS0FBSyxnQkFBZ0IsU0FBUztBQUM5Qiw2QkFBYSxLQUNULElBQUksZUFBZTtrQkFDZix3QkFBd0I7a0JBQ3hCLGdCQUFnQixDQUFDLFlBQVc7QUFDeEIsMkJBQU8saUNBQ0EsVUFEQTtzQkFFSCxNQUFNLFNBQVMsU0FBUyxRQUFRLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxVQUFVLFdBQVc7O2tCQUVuRztpQkFDSCxDQUFDOztBQUdWLHFCQUFPO1lBQ1g7WUFDQSxrQkFBa0IsS0FBSyxnQkFBZ0IsU0FBUyxJQUFNO1dBQ3pEO1FBQ0w7O01BRUEsY0FBQTtBQUNJLGNBQUs7TUFDVDtNQU1TLFlBQVksT0FBVTtBQUMzQixZQUFJLFNBQVMsTUFBTSxTQUFTLHVCQUF1QixNQUFNLFNBQVMsT0FBTyxNQUFNLFVBQVUsS0FBSztBQUMxRixnQkFBTSxZQUFZLEtBQUs7QUFDdkI7O0FBRUosWUFBSSxLQUFLLGdCQUFnQixTQUFTO0FBQzlCLGdCQUFNLFlBQVksTUFBTSxTQUFTLE1BQU0sV0FBVyxNQUFNLGlCQUFpQjtBQUN6RSwyQkFBaUIsU0FBUzs7QUFFOUIsY0FBTSxZQUFZLEtBQUs7TUFDM0I7O3lCQWpFUyxxQkFBa0I7TUFBQTtvRUFBbEIscUJBQWtCLFNBQWxCLG9CQUFrQixXQUFBLFlBREwsT0FBTSxDQUFBOzs7Ozs7QUNQaEMsU0FBUyxjQUFBQyxtQkFBa0I7QUFDM0IsU0FBUyxlQUFlOztBQUR4QixJQU1hO0FBTmI7O0FBTU0sSUFBTyw2QkFBUCxNQUFPLDRCQUEwQjtNQUNuQyxnQkFBa0MsSUFBSSxRQUFPO01BSzdDLGVBQVk7QUFDUixhQUFLLGNBQWMsS0FBSyxJQUFJO01BQ2hDO01BS0EsY0FBVztBQUNQLGFBQUssY0FBYyxLQUFLLEtBQUs7TUFDakM7O3lCQWZTLDZCQUEwQjtNQUFBO29FQUExQiw2QkFBMEIsU0FBMUIsNEJBQTBCLFdBQUEsWUFGdkIsT0FBTSxDQUFBOzs7Ozs7QUNKdEIsU0FBUyxjQUFBQyxtQkFBa0I7QUFHM0IsU0FBUyxZQUFBQyxpQkFBZ0I7O0FBSHpCLElBT2E7QUFQYjs7QUFJQTs7QUFHTSxJQUFPLGlDQUFQLE1BQU8sZ0NBQThCO01BR25CO01BRnBCLGlCQUFpQjtNQUVqQixZQUFvQiw0QkFBc0Q7QUFBdEQsYUFBQSw2QkFBQTtNQUF5RDtNQVU3RSxVQUFVLFNBQTJCLE1BQWlCO0FBQ2xELFlBQUksS0FBSyxtQkFBbUIsR0FBRztBQUMzQixlQUFLLDJCQUEyQixhQUFZOztBQUVoRCxhQUFLO0FBRUwsZUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLEtBQ3hCQSxVQUFTLE1BQUs7QUFDVixlQUFLO0FBQ0wsY0FBSSxLQUFLLG1CQUFtQixHQUFHO0FBQzNCLGlCQUFLLDJCQUEyQixZQUFXOztRQUVuRCxDQUFDLENBQUM7TUFFVjs7eUJBM0JTLGlDQUE4Qix1QkFBQSwwQkFBQSxDQUFBO01BQUE7b0VBQTlCLGlDQUE4QixTQUE5QixnQ0FBOEIsVUFBQSxDQUFBOzs7Ozs7QUNEM0MsSUFBYTtBQUFiOztBQUFPLElBQU0sMkJBQTJCLENBQUMsWUFBdUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxRQUFRLE9BQU8sUUFBUSxLQUFLLFFBQVEsR0FBRzs7Ozs7QUNOdEksU0FBUyxjQUFBQyxtQkFBa0I7O0FBQTNCLElBT2E7QUFQYjs7QUFHQTtBQUNBOztBQUdNLElBQU8sZ0NBQVAsTUFBTywrQkFBNkI7TUFJbEI7TUFIWjtNQUNBO01BRVIsWUFBb0IsMkJBQW9EO0FBQXBELGFBQUEsNEJBQUE7QUFDaEIsa0NBQTBCLFlBQVksVUFBVSxDQUFDLGdCQUFpQixLQUFLLGNBQWMsV0FBWTtBQUNqRyxrQ0FBMEIsbUJBQW1CLFVBQVUsQ0FBQyx1QkFBd0IsS0FBSyxxQkFBcUIsa0JBQW1CO01BQ2pJO01BU0EsVUFBVSxTQUEyQixNQUFpQjtBQUNsRCxZQUFJLHlCQUF5QixPQUFPLE1BQU0sS0FBSyxzQkFBc0IsS0FBSyxjQUFjO0FBQ3BGLG9CQUFVLFFBQVEsTUFBTTtZQUNwQixZQUFZO2NBQ1IsZ0NBQWdDLEtBQUssc0JBQXNCO2NBQzNELGdDQUFnQyxLQUFLLGVBQWU7O1dBRTNEOztBQUdMLGVBQU8sS0FBSyxPQUFPLE9BQU87TUFDOUI7O3lCQTNCUyxnQ0FBNkIsdUJBQUEseUJBQUEsQ0FBQTtNQUFBO29FQUE3QixnQ0FBNkIsU0FBN0IsK0JBQTZCLFVBQUEsQ0FBQTs7Ozs7O0FDUDFDLFNBQVMsZ0JBQWdCLFFBQVEsY0FBQUMsY0FBWSxzQkFBc0I7QUFDbkUsU0FBK0QsZ0JBQUFDLHFCQUFvQjtBQUNuRixTQUFxQixRQUFRLFVBQVUsTUFBQUMsV0FBVTtBQUNqRCxTQUFTLFlBQVksT0FBTyxPQUFBQyxNQUFLLGVBQWU7QUFHaEQsU0FBUyxnQkFBZ0I7OztBQU56QixJQVNhLHVCQUdBO0FBWmI7O0FBSUE7QUFDQTtBQUVBOzs7QUFFTyxJQUFNLHdCQUF3QixJQUFJLGVBQXVCLFFBQVE7QUFHbEUsSUFBTyw0QkFBUCxNQUFPLDJCQUF5QjtNQU90QjtNQUNBO01BQ0E7TUFDQTtNQUMrQjtNQVRuQztNQUVBLCtCQUErQjtNQUV2QyxZQUNZLFFBQ0EsU0FDQSxtQkFDQSxjQUMrQixnQkFBc0I7QUFKckQsYUFBQSxTQUFBO0FBQ0EsYUFBQSxVQUFBO0FBQ0EsYUFBQSxvQkFBQTtBQUNBLGFBQUEsZUFBQTtBQUMrQixhQUFBLGlCQUFBO0FBSXZDLGNBQU0sdUJBQXVCLE9BQU8sU0FBUyxLQUN6QyxNQUFNLENBQUMsYUFBYSxhQUFhLElBQUksR0FJckMsUUFBUSxHQUFLLEdBRWIsV0FBVyxNQUFNRCxJQUFHLElBQUksQ0FBQyxDQUFDO0FBRTlCLGNBQU0saUJBQWlCLFNBQVMsS0FBSyxHQUFJO0FBQ3pDLGNBQU0saUNBQWlDLE9BQU8sc0JBQXNCLGNBQWM7QUFFbEYsdUNBQStCLFVBQVUsTUFBTSxLQUFLLGdCQUFnQixLQUFLLENBQUM7TUFDOUU7TUFFQSxVQUFVLFNBQTJCLGFBQXdCO0FBQ3pELGVBQU8sWUFBWSxPQUFPLE9BQU8sRUFBRSxLQUMvQkMsS0FBSSxDQUFDLGFBQVk7QUFDYixjQUFJLG9CQUFvQkYsZUFBYztBQUNsQyxrQkFBTSw4QkFBOEIsU0FBUyxLQUFLLFNBQVMsUUFBUTtBQUNuRSxrQkFBTSxnQkFBZ0IsU0FBUyxRQUFRLElBQUksc0JBQXNCO0FBQ2pFLGdCQUFJLFdBQVcsaUJBQWlCLFlBQVksaUJBQWlCLENBQUMsNkJBQTZCO0FBRXZGLG1CQUFLLGdCQUFnQixJQUFJOztBQUk3QixnQkFBSSxDQUFDLFFBQVEsSUFBSSxTQUFTLE1BQU0sR0FBRztBQUMvQixtQkFBSyxrQkFBa0IsV0FBVTs7O1FBRzdDLENBQUMsQ0FBQztNQUVWO01BYVEsZ0JBQWdCLFdBQWtCO0FBRXRDLGNBQU0sU0FBUyxLQUFLLFFBQVEsWUFBWSxLQUFLLFFBQVEsZUFBYyxJQUFLLFFBQVEsUUFBUSxTQUFTO0FBR2pHLGVBQU8sS0FBSyxDQUFDLG9CQUE0QjtBQUNyQyxjQUFJLEtBQUssZ0NBQWdDLGlCQUFpQjtBQUN0RCxpQkFBSywrQkFBK0I7QUFHcEMsZ0JBQUksQ0FBQyxLQUFLLE9BQU8sUUFBUTtBQUNyQixtQkFBSyxRQUFRLEtBQUssYUFBYSxTQUFTO2dCQUNwQyxNQUFNLFVBQVU7Z0JBQ2hCLFNBQVM7Z0JBQ1QsU0FBUztnQkFDVCxRQUFRO2tCQUNKLE9BQU87a0JBQ1AsVUFBVSxNQUVOLEtBQUssUUFDQSxlQUFjLEVBSWQsTUFBTSxNQUFLO2tCQUFFLENBQUMsRUFFZCxLQUFLLE1BQU0sS0FBSyxlQUFlLFNBQVMsT0FBTSxDQUFFOztlQUVoRTs7O1FBR2IsQ0FBQztNQUNMOzt5QkE3RlMsNEJBQXlCLHdCQUFBLG1CQUFBLEdBQUEsd0JBQUEsWUFBQSxHQUFBLHdCQUFBLHdCQUFBLEdBQUEsd0JBQUEsWUFBQSxHQUFBLHdCQVd0QixxQkFBcUIsQ0FBQTtNQUFBO3FFQVh4Qiw0QkFBeUIsU0FBekIsMkJBQXlCLFVBQUEsQ0FBQTs7Ozs7O0FDWnRDLE9BQU8sV0FBVztBQUNsQixPQUFPLHVCQUF1QjtBQUM5QixPQUFPLGNBQWM7QUFDckIsT0FBTyxrQkFBa0I7QUFDekIsT0FBTyxhQUFhO0FBQ3BCLE9BQU8sU0FBUztBQUNoQixPQUFPLG9CQUFvQjtBQUMzQixPQUFPLG1CQUFtQjtBQUMxQixPQUFPLGVBQWU7QUFDdEIsT0FBTyxZQUFZO0FBQ25CLE9BQU8scUJBQXFCO0FBQzVCLE9BQU8sb0JBQW9CO0FBQzNCLE9BQU8sZ0JBQWdCO0FBQ3ZCLE9BQU8sY0FBYztBQUVyQixPQUFPO0FBQ1AsT0FBTztBQWhCUDs7QUFrQkEsVUFBTSxPQUFPLGlCQUFpQjtBQUM5QixVQUFNLE9BQU8sUUFBUTtBQUNyQixVQUFNLE9BQU8sWUFBWTtBQUN6QixVQUFNLE9BQU8sT0FBTztBQUNwQixVQUFNLE9BQU8sR0FBRztBQUNoQixVQUFNLE9BQU8sY0FBYztBQUMzQixVQUFNLE9BQU8sYUFBYTtBQUMxQixVQUFNLE9BQU8sU0FBUztBQUN0QixVQUFNLE9BQU8sTUFBTTtBQUNuQixVQUFNLE9BQU8sZUFBZTtBQUM1QixVQUFNLE9BQU8sY0FBYztBQUMzQixVQUFNLE9BQU8sVUFBVTtBQUN2QixVQUFNLE9BQU8sUUFBUTs7Ozs7QUMzQnJCLFNBQVMsY0FBQUcsb0JBQWtCO0FBQzNCLFNBQVMsc0JBQXFDO0FBQzlDLE9BQU9DLFlBQVc7O0FBRmxCLElBS2E7QUFMYjs7QUFLTSxJQUFPLHNCQUFQLE1BQU8sNkJBQTRCLGVBQTJCO01BQ2hFLFVBQVUsTUFBd0I7QUFDOUIsWUFBSSxRQUFRQSxPQUFNLFFBQVEsSUFBSSxLQUFLLEtBQUssUUFBTyxHQUFJO0FBQy9DLGlCQUFPLEVBQUUsTUFBTSxLQUFLLEtBQUksR0FBSSxPQUFPLEtBQUssTUFBSyxJQUFLLEdBQUcsS0FBSyxLQUFLLEtBQUksRUFBRTs7QUFFekUsZUFBTztNQUNYO01BRUEsUUFBUSxNQUEwQjtBQUM5QixlQUFPLE9BQU9BLE9BQU0sR0FBRyxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLLEdBQUcsRUFBRSxJQUFJO01BQ3BFOzs7O3lJQVZTLG9CQUFtQixJQUFBLEtBQW5CLG9CQUFtQjtRQUFBO01BQUEsR0FBQTtxRUFBbkIsc0JBQW1CLFNBQW5CLHFCQUFtQixVQUFBLENBQUE7Ozs7OztBQ1JoQyxTQUFTLGlCQUFpQixnQkFBQUMsZUFBYyxXQUFXLGdCQUFnQjtBQUNuRSxTQUFTLFVBQVUsMEJBQTBCO0FBQzdDLFNBQVMsbUJBQW1CLGNBQUFDLGFBQVksd0JBQXdCO0FBQ2hFLFNBQVMsYUFBYTtBQUl0QixTQUFTLGtCQUFBQyxpQkFBZ0IscUJBQXFCLHdCQUF3QjtBQUN0RSxTQUFTLHFCQUFxQix5QkFBQUMsOEJBQTZCO0FBQzNELE9BQU8sWUFBWTtBQUNuQixTQUFTLDJCQUEyQixpQkFBaUIsaUJBQWlCLHdCQUF3QjtBQU05RixPQUFPQyxZQUFXO0FBSWxCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsVUFBQUMsZUFBYzs7Ozs7QUFyQnZCLElBaUdhO0FBakdiOztBQUlBO0FBQ0E7QUFDQTtBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBOEVNLElBQU8sb0JBQVAsTUFBTyxtQkFBaUI7TUFDMUIsWUFDSSxVQUNBLGVBQ0Esa0JBQ0EsZ0JBQ0EsdUJBQTRDO0FBRTVDLDJCQUFtQixNQUFNO0FBQ3pCLGlCQUFTLFVBQVUsRUFBRSxNQUFNRCxPQUFLLEVBQUcsU0FBUyxLQUFLLE1BQU0sRUFBRSxLQUFJLEdBQUksT0FBTyxHQUFHLEtBQUssRUFBQztBQUNqRix5QkFBaUIsZUFBZSxJQUFJO0FBQ3BDLGNBQU0sY0FBYyxzQkFBc0IsU0FBUyxRQUFRLEtBQUssZUFBZSwyQkFBMEI7QUFDekcseUJBQWlCLElBQUksV0FBVztBQUNoQyxzQkFBYyxZQUFZO01BQzlCOzt5QkFkUyxvQkFBaUIsd0JBQUEsdUJBQUEsR0FBQSx3QkFBQSxvQkFBQSxHQUFBLHdCQUFBLG9CQUFBLEdBQUEsd0JBQUEsaUJBQUEsR0FBQSx3QkFBQSx3QkFBQSxDQUFBO01BQUE7aUVBQWpCLG1CQUFpQixDQUFBO3NFQTFEZjtRQUNQO1FBQ0E7VUFDSSxTQUFTO1VBQ1QsVUFBVTs7UUFFZCxFQUFFLFNBQVNGLGlCQUFnQixVQUFVLG9CQUFtQjtRQUN4RCxFQUFFLFNBQVMsY0FBYyxNQUFNLENBQUNHLE9BQU0sRUFBQztRQUN2QyxFQUFFLFNBQVNMLGVBQWMsVUFBVSxtQkFBa0I7UUFDckQsRUFBRSxTQUFTLHVCQUF1QixVQUFVLE9BQU07UUFDbEQ7UUFDQTtVQUNJLFNBQVM7VUFDVCxZQUFZLE1BQU0sTUFBSztVQUFFO1VBQ3pCLE1BQU0sQ0FBQyxZQUFZO1VBQ25CLE9BQU87O1FBV1g7VUFDSSxTQUFTO1VBQ1QsVUFBVTtVQUNWLE9BQU87O1FBRVg7VUFDSSxTQUFTO1VBQ1QsVUFBVTtVQUNWLE9BQU87O1FBRVg7VUFDSSxTQUFTO1VBQ1QsVUFBVTtVQUNWLE9BQU87O1FBRVg7VUFDSSxTQUFTO1VBQ1QsVUFBVTtVQUNWLE9BQU87O1FBRVg7VUFDSSxTQUFTO1VBQ1QsVUFBVTtVQUNWLE9BQU87O1FBRVg7VUFDSSxTQUFTO1VBQ1QsVUFBVTtVQUNWLE9BQU87O1NBRWQsU0FBQTtRQXRFRztRQUNBLG9CQUFvQixRQUFRLEVBQUUsUUFBUSxPQUFPLFdBQVcsSUFBRyxDQUFFO1FBQzdELGdCQUFnQixRQUFRO1VBQ3BCLFFBQVE7WUFDSixTQUFTO1lBQ1QsWUFBWTtZQUNaLE1BQU0sQ0FBQ0MsV0FBVTs7VUFFckIsMkJBQTJCO1lBQ3ZCLFNBQVM7WUFDVCxZQUFZOztTQUVuQjtNQUFDLEVBQUEsQ0FBQTs7OzsiLCJuYW1lcyI6WyJJbmplY3RhYmxlIiwiSW5qZWN0YWJsZSIsIlJvdXRlciIsIkluamVjdGFibGUiLCJIdHRwRXJyb3JSZXNwb25zZSIsInRhcCIsIkluamVjdGFibGUiLCJ0YXAiLCJJbmplY3RhYmxlIiwiSW5qZWN0YWJsZSIsIkluamVjdGFibGUiLCJmaW5hbGl6ZSIsIkluamVjdGFibGUiLCJJbmplY3RhYmxlIiwiSHR0cFJlc3BvbnNlIiwib2YiLCJ0YXAiLCJJbmplY3RhYmxlIiwiZGF5anMiLCJFcnJvckhhbmRsZXIiLCJIdHRwQ2xpZW50IiwiTmdiRGF0ZUFkYXB0ZXIiLCJTZXNzaW9uU3RvcmFnZVNlcnZpY2UiLCJkYXlqcyIsIlJvdXRlciJdfQ==