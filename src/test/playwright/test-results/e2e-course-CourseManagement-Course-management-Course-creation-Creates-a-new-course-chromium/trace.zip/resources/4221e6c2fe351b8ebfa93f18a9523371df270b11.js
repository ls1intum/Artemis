import {
  __esm
} from "/chunk-ZBX4HTBS.js";

// src/main/webapp/app/core/language/language.constants.ts
var LANGUAGES;
var init_language_constants = __esm({
  "src/main/webapp/app/core/language/language.constants.ts"() {
    LANGUAGES = [
      "en",
      "de"
    ];
  }
});

export {
  LANGUAGES,
  init_language_constants
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluL3dlYmFwcC9hcHAvY29yZS9sYW5ndWFnZS9sYW5ndWFnZS5jb25zdGFudHMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAgICBMYW5ndWFnZXMgY29kZXMgYXJlIElTT182MzktMSBjb2Rlcywgc2VlIGh0dHA6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvTGlzdF9vZl9JU09fNjM5LTFfY29kZXNcbiAgICBUaGV5IGFyZSB3cml0dGVuIGluIEVuZ2xpc2ggdG8gYXZvaWQgY2hhcmFjdGVyIGVuY29kaW5nIGlzc3VlcyAobm90IGEgcGVyZmVjdCBzb2x1dGlvbilcbiovXG5leHBvcnQgY29uc3QgTEFOR1VBR0VTOiBzdHJpbmdbXSA9IFtcbiAgICAnZW4nLFxuICAgICdkZScsXG4gICAgLy8gamhpcHN0ZXItbmVlZGxlLWkxOG4tbGFuZ3VhZ2UtY29uc3RhbnQgLSBKSGlwc3RlciB3aWxsIGFkZC9yZW1vdmUgbGFuZ3VhZ2VzIGluIHRoaXMgYXJyYXlcbl07XG4iXSwibWFwcGluZ3MiOiI7Ozs7O0FBSUEsSUFBYTtBQUFiOztBQUFPLElBQU0sWUFBc0I7TUFDL0I7TUFDQTs7OzsiLCJuYW1lcyI6W119